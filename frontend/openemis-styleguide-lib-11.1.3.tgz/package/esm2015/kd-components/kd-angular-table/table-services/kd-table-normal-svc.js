import { Injectable } from '@angular/core';
import { KdTableSvcBase } from './kd-table-svc';
/**
 * -- Documentation for kd-table-normal-svc.ts --
 *
 * Public function:
 *     - Grid Options function
 *         - generateGridOptions (GridOption generation with gridConfig)
 *         - setGridOptions
 *     - Column definition functions
 *         - setColumnDef (Column Definitions based on columnConfig and gridConfig)
 *         - generateColumnDefinitions
 *     - Row data functions
 *         - setRowData (Set the rowData to the grid)
 *
 * Private functions:
 *     - Grid Options function
 *         - _generateConfigOptions (additional GridOption from table config)
 *     - Row height functions
 *         - _getRowHeight
 *         - _calculateRowHeight
 *         - _getQuestionHeight
 */
export class KdTableNormalSvc extends KdTableSvcBase {
    constructor() {
        super(...arguments);
        this._movableColumn = false;
        /************************* End of private functions **************************/
    }
    /***************************** Public functions ******************************/
    ////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// Grid options functions
    ////////////////////////////////////////////////////////////////////////////////////////////////////////
    generateGridOptions(_gridConfig, _direction) {
        let tempGridOptions = super.getDefaultGridOptions(_direction, _gridConfig.rowContentHeight);
        // delete tempGridOptions.rowHeight;
        let configOptions = this._generateConfigOptions(_gridConfig);
        Object.assign(tempGridOptions, configOptions);
        return tempGridOptions;
    }
    setGridOptions(_gridOptions) {
        this.gridOptions = _gridOptions;
    }
    ////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// Column definition functions
    ////////////////////////////////////////////////////////////////////////////////////////////////////////
    setColumnDef(_colDefConfig, _gridConfig, _suppressMovableColumns = true) {
        let updatedColumn = this.generateColumnDefinitions(_colDefConfig, _gridConfig, _suppressMovableColumns);
        this.gridOptions.columnDefs = updatedColumn;
        if (super.isApiReady(this.gridOptions)) {
            this.gridOptions.api.setColumnDefs(updatedColumn);
        }
    }
    generateColumnDefinitions(_colDefConfig, _gridConfig, _suppressMovableColumns = true) {
        return super.generateColumnDefinitions(_colDefConfig, _gridConfig, _suppressMovableColumns);
    }
    ////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// Row Data functions
    ////////////////////////////////////////////////////////////////////////////////////////////////////////
    setRowData(_rowData) {
        this.gridOptions.rowData = _rowData;
        if (super.isApiReady(this.gridOptions)) {
            this.gridOptions.api.setRowData(_rowData);
        }
    }
    /************ End of public functions / Start of private functions ***********/
    ////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// Grid options functions
    ////////////////////////////////////////////////////////////////////////////////////////////////////////
    _generateConfigOptions(_config) {
        let sidebarValue = false;
        if ('pivot' in _config) {
            sidebarValue = _config.pivot.state.pivotMode;
        }
        let configOptions = {
            rowModelType: 'clientSide',
            enableSorting: true,
            enableFilter: true,
            getRowHeight: (_params) => {
                if (_config.rowContentHeight) {
                    return _config.rowContentHeight;
                }
                else {
                    return this._getRowHeight(_params);
                }
            },
            sideBar: sidebarValue,
            context: _config.context
        };
        if (typeof _config.rowIdKey !== 'undefined') {
            this.rowKey = _config.rowIdKey;
            configOptions.getRowNodeId = (_data) => {
                if (_data.hasOwnProperty(_config.rowIdKey)) {
                    let id = _data[_config.rowIdKey];
                    if (typeof _data[_config.rowIdKey] === 'number') {
                        id = id.toString();
                    }
                    return id;
                }
                else if (_data.hasOwnProperty('data')) {
                    let id = _data.data[_config.rowIdKey];
                    if (typeof _data.data[_config.rowIdKey] === 'number') {
                        id = id.toString();
                    }
                    return id;
                }
                return '';
            };
        }
        return configOptions;
    }
    ////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// Row Height functions
    ////////////////////////////////////////////////////////////////////////////////////////////////////////
    _getRowHeight(_params) {
        let maxHeight = this.ROW_HEIGHT;
        let allColumns = _params.node.columnApi.getAllColumns();
        let columnHeight = 0;
        for (let i = 0; i < allColumns.length; ++i) {
            columnHeight = this.ROW_HEIGHT;
            if (super.isColDefOfType(allColumns[i].getColDef(), this.GIRD_PARAMS_KEY.input)) {
                let contextKey = super.generateContextKey(_params.context.gridId, allColumns[i].getColDef().colId, _params.node.id);
                if (_params.context[this.TABLE_INPUT_CONTEXT_KEY].hasOwnProperty(contextKey)) {
                    columnHeight = this._calculateRowHeight(_params.context[this.TABLE_INPUT_CONTEXT_KEY][contextKey]);
                }
            }
            if (super.isColDefOfType(allColumns[i].getColDef(), this.GIRD_PARAMS_KEY.image)) {
                const defaultColHeight = 150;
                if (typeof allColumns[i].getColDef().cellRendererParams.params.imageConfig.height !== 'undefined') {
                    columnHeight = allColumns[i].getColDef().cellRendererParams.params.imageConfig.height + this.IMAGE_PADDING;
                }
                else {
                    columnHeight = defaultColHeight + this.IMAGE_PADDING;
                }
            }
            if (columnHeight > maxHeight) {
                maxHeight = columnHeight;
            }
        }
        return maxHeight;
    }
    _calculateRowHeight(_contextData) {
        let height = 0;
        for (let item in _contextData) {
            if (_contextData.hasOwnProperty(item)) {
                height += this._getQuestionHeight(_contextData[item]);
            }
        }
        return height;
    }
    _getQuestionHeight(_tableDataItem) {
        let height = 0;
        if (_tableDataItem.visible) {
            height += 50;
        }
        if (_tableDataItem.visible && _tableDataItem.controlType === 'textarea') {
            height += 70;
        }
        return height;
    }
}
KdTableNormalSvc.decorators = [
    { type: Injectable }
];
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoia2QtdGFibGUtbm9ybWFsLXN2Yy5qcyIsInNvdXJjZVJvb3QiOiJEOi9vcGVuRU1JUy9zdHlsZWd1aWRlL2lvc3RnLW9wZW5lbWlzLXN0eWxlZ3VpZGUvcHJvamVjdHMvb3BlbmVtaXMtc3R5bGVndWlkZS1saWIvc3JjLyIsInNvdXJjZXMiOlsia2QtY29tcG9uZW50cy9rZC1hbmd1bGFyLXRhYmxlL3RhYmxlLXNlcnZpY2VzL2tkLXRhYmxlLW5vcm1hbC1zdmMudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsT0FBTyxFQUFFLFVBQVUsRUFBRSxNQUFNLGVBQWUsQ0FBQztBQVkzQyxPQUFPLEVBQUUsY0FBYyxFQUFFLE1BQU0sZ0JBQWdCLENBQUM7QUFFaEQ7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0dBb0JHO0FBR0gsTUFBTSxPQUFPLGdCQUFpQixTQUFRLGNBQWM7SUFEcEQ7O1FBRVksbUJBQWMsR0FBWSxLQUFLLENBQUM7UUFvS3hDLCtFQUErRTtJQUNuRixDQUFDO0lBcEtHLCtFQUErRTtJQUMvRSx3R0FBd0c7SUFDeEcsMEJBQTBCO0lBQzFCLHdHQUF3RztJQUNqRyxtQkFBbUIsQ0FBQyxXQUF5QixFQUFFLFVBQXlCO1FBQzNFLElBQUksZUFBZSxHQUFnQixLQUFLLENBQUMscUJBQXFCLENBQUMsVUFBVSxFQUFFLFdBQVcsQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDO1FBRXpHLG9DQUFvQztRQUNwQyxJQUFJLGFBQWEsR0FBZ0IsSUFBSSxDQUFDLHNCQUFzQixDQUFDLFdBQVcsQ0FBQyxDQUFDO1FBRXBFLE1BQU8sQ0FBQyxNQUFNLENBQUMsZUFBZSxFQUFFLGFBQWEsQ0FBQyxDQUFDO1FBRXJELE9BQU8sZUFBZSxDQUFDO0lBQzNCLENBQUM7SUFFTSxjQUFjLENBQUMsWUFBeUI7UUFDM0MsSUFBSSxDQUFDLFdBQVcsR0FBRyxZQUFZLENBQUM7SUFDcEMsQ0FBQztJQUVELHdHQUF3RztJQUN4RywrQkFBK0I7SUFDL0Isd0dBQXdHO0lBQ2pHLFlBQVksQ0FBQyxhQUFrQyxFQUFFLFdBQXlCLEVBQUUsMEJBQW1DLElBQUk7UUFDdEgsSUFBSSxhQUFhLEdBQWtCLElBQUksQ0FBQyx5QkFBeUIsQ0FBQyxhQUFhLEVBQUUsV0FBVyxFQUFFLHVCQUF1QixDQUFDLENBQUM7UUFFdkgsSUFBSSxDQUFDLFdBQVcsQ0FBQyxVQUFVLEdBQUcsYUFBYSxDQUFDO1FBRTVDLElBQUksS0FBSyxDQUFDLFVBQVUsQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFDLEVBQUU7WUFDcEMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxHQUFHLENBQUMsYUFBYSxDQUFDLGFBQWEsQ0FBQyxDQUFDO1NBQ3JEO0lBQ0wsQ0FBQztJQUVNLHlCQUF5QixDQUFDLGFBQWtDLEVBQUUsV0FBeUIsRUFBRSwwQkFBbUMsSUFBSTtRQUNuSSxPQUFPLEtBQUssQ0FBQyx5QkFBeUIsQ0FBQyxhQUFhLEVBQUUsV0FBVyxFQUFFLHVCQUF1QixDQUFDLENBQUM7SUFDaEcsQ0FBQztJQUVELHdHQUF3RztJQUN4RyxzQkFBc0I7SUFDdEIsd0dBQXdHO0lBQ2pHLFVBQVUsQ0FBQyxRQUFvQjtRQUNsQyxJQUFJLENBQUMsV0FBVyxDQUFDLE9BQU8sR0FBRyxRQUFRLENBQUM7UUFDcEMsSUFBSSxLQUFLLENBQUMsVUFBVSxDQUFDLElBQUksQ0FBQyxXQUFXLENBQUMsRUFBRTtZQUNwQyxJQUFJLENBQUMsV0FBVyxDQUFDLEdBQUcsQ0FBQyxVQUFVLENBQUMsUUFBUSxDQUFDLENBQUM7U0FDN0M7SUFDTCxDQUFDO0lBRUQsK0VBQStFO0lBQy9FLHdHQUF3RztJQUN4RywwQkFBMEI7SUFDMUIsd0dBQXdHO0lBQ2hHLHNCQUFzQixDQUFDLE9BQXFCO1FBQ2hELElBQUksWUFBWSxHQUFHLEtBQUssQ0FBQztRQUN6QixJQUFHLE9BQU8sSUFBSSxPQUFPLEVBQUU7WUFDbkIsWUFBWSxHQUFHLE9BQU8sQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLFNBQVMsQ0FBQztTQUNoRDtRQUNELElBQUksYUFBYSxHQUFnQjtZQUM3QixZQUFZLEVBQUUsWUFBWTtZQUMxQixhQUFhLEVBQUUsSUFBSTtZQUNuQixZQUFZLEVBQUUsSUFBSTtZQUNsQixZQUFZLEVBQUUsQ0FBQyxPQUFZLEVBQVUsRUFBRTtnQkFDbkMsSUFBSSxPQUFPLENBQUMsZ0JBQWdCLEVBQUU7b0JBQzFCLE9BQU8sT0FBTyxDQUFDLGdCQUFnQixDQUFBO2lCQUNsQztxQkFBTTtvQkFDSCxPQUFPLElBQUksQ0FBQyxhQUFhLENBQUMsT0FBTyxDQUFDLENBQUM7aUJBQ3RDO1lBQ0wsQ0FBQztZQUNELE9BQU8sRUFBRSxZQUFZO1lBQ3JCLE9BQU8sRUFBRSxPQUFPLENBQUMsT0FBTztTQUMzQixDQUFDO1FBRUYsSUFBSSxPQUFPLE9BQU8sQ0FBQyxRQUFRLEtBQUssV0FBVyxFQUFFO1lBQ3pDLElBQUksQ0FBQyxNQUFNLEdBQUcsT0FBTyxDQUFDLFFBQVEsQ0FBQztZQUUvQixhQUFhLENBQUMsWUFBWSxHQUFHLENBQUMsS0FBVSxFQUFVLEVBQUU7Z0JBQ2hELElBQUksS0FBSyxDQUFDLGNBQWMsQ0FBQyxPQUFPLENBQUMsUUFBUSxDQUFDLEVBQUU7b0JBQ3hDLElBQUksRUFBRSxHQUFXLEtBQUssQ0FBQyxPQUFPLENBQUMsUUFBUSxDQUFDLENBQUM7b0JBRXpDLElBQUksT0FBTyxLQUFLLENBQUMsT0FBTyxDQUFDLFFBQVEsQ0FBQyxLQUFLLFFBQVEsRUFBRTt3QkFDN0MsRUFBRSxHQUFHLEVBQUUsQ0FBQyxRQUFRLEVBQUUsQ0FBQztxQkFDdEI7b0JBRUQsT0FBTyxFQUFFLENBQUM7aUJBQ2I7cUJBQU0sSUFBSSxLQUFLLENBQUMsY0FBYyxDQUFDLE1BQU0sQ0FBQyxFQUFFO29CQUNyQyxJQUFJLEVBQUUsR0FBVyxLQUFLLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxRQUFRLENBQUMsQ0FBQztvQkFFOUMsSUFBSSxPQUFPLEtBQUssQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLFFBQVEsQ0FBQyxLQUFLLFFBQVEsRUFBRTt3QkFDbEQsRUFBRSxHQUFHLEVBQUUsQ0FBQyxRQUFRLEVBQUUsQ0FBQztxQkFDdEI7b0JBRUQsT0FBTyxFQUFFLENBQUM7aUJBQ2I7Z0JBRUQsT0FBTyxFQUFFLENBQUM7WUFDZCxDQUFDLENBQUM7U0FDTDtRQUVELE9BQU8sYUFBYSxDQUFDO0lBQ3pCLENBQUM7SUFFRCx3R0FBd0c7SUFDeEcsd0JBQXdCO0lBQ3hCLHdHQUF3RztJQUNoRyxhQUFhLENBQUMsT0FBaUU7UUFDbkYsSUFBSSxTQUFTLEdBQVcsSUFBSSxDQUFDLFVBQVUsQ0FBQztRQUN4QyxJQUFJLFVBQVUsR0FBd0IsT0FBTyxDQUFDLElBQUssQ0FBQyxTQUFTLENBQUMsYUFBYSxFQUFFLENBQUM7UUFDOUUsSUFBSSxZQUFZLEdBQVcsQ0FBQyxDQUFDO1FBRTdCLEtBQUssSUFBSSxDQUFDLEdBQVcsQ0FBQyxFQUFFLENBQUMsR0FBRyxVQUFVLENBQUMsTUFBTSxFQUFFLEVBQUUsQ0FBQyxFQUFFO1lBQ2hELFlBQVksR0FBRyxJQUFJLENBQUMsVUFBVSxDQUFDO1lBRS9CLElBQUksS0FBSyxDQUFDLGNBQWMsQ0FBQyxVQUFVLENBQUMsQ0FBQyxDQUFDLENBQUMsU0FBUyxFQUFFLEVBQUUsSUFBSSxDQUFDLGVBQWUsQ0FBQyxLQUFLLENBQUMsRUFBRTtnQkFDN0UsSUFBSSxVQUFVLEdBQVcsS0FBSyxDQUFDLGtCQUFrQixDQUFDLE9BQU8sQ0FBQyxPQUFPLENBQUMsTUFBTSxFQUFFLFVBQVUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxTQUFTLEVBQUUsQ0FBQyxLQUFLLEVBQUUsT0FBTyxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsQ0FBQztnQkFFNUgsSUFBSSxPQUFPLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyx1QkFBdUIsQ0FBQyxDQUFDLGNBQWMsQ0FBQyxVQUFVLENBQUMsRUFBRTtvQkFDMUUsWUFBWSxHQUFHLElBQUksQ0FBQyxtQkFBbUIsQ0FBQyxPQUFPLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyx1QkFBdUIsQ0FBQyxDQUFDLFVBQVUsQ0FBQyxDQUFDLENBQUM7aUJBQ3RHO2FBQ0o7WUFFRCxJQUFJLEtBQUssQ0FBQyxjQUFjLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQyxDQUFDLFNBQVMsRUFBRSxFQUFFLElBQUksQ0FBQyxlQUFlLENBQUMsS0FBSyxDQUFDLEVBQUU7Z0JBQzdFLE1BQU0sZ0JBQWdCLEdBQVcsR0FBRyxDQUFDO2dCQUVyQyxJQUFJLE9BQU8sVUFBVSxDQUFDLENBQUMsQ0FBQyxDQUFDLFNBQVMsRUFBRSxDQUFDLGtCQUFrQixDQUFDLE1BQU0sQ0FBQyxXQUFXLENBQUMsTUFBTSxLQUFLLFdBQVcsRUFBRTtvQkFDL0YsWUFBWSxHQUFHLFVBQVUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxTQUFTLEVBQUUsQ0FBQyxrQkFBa0IsQ0FBQyxNQUFNLENBQUMsV0FBVyxDQUFDLE1BQU0sR0FBRyxJQUFJLENBQUMsYUFBYSxDQUFDO2lCQUM5RztxQkFDSTtvQkFDRCxZQUFZLEdBQUcsZ0JBQWdCLEdBQUcsSUFBSSxDQUFDLGFBQWEsQ0FBQztpQkFDeEQ7YUFDSjtZQUVELElBQUksWUFBWSxHQUFHLFNBQVMsRUFBRTtnQkFDMUIsU0FBUyxHQUFHLFlBQVksQ0FBQzthQUM1QjtTQUNKO1FBRUQsT0FBTyxTQUFTLENBQUM7SUFDckIsQ0FBQztJQUVPLG1CQUFtQixDQUFDLFlBQWlCO1FBQ3pDLElBQUksTUFBTSxHQUFXLENBQUMsQ0FBQztRQUV2QixLQUFLLElBQUksSUFBSSxJQUFJLFlBQVksRUFBRTtZQUMzQixJQUFJLFlBQVksQ0FBQyxjQUFjLENBQUMsSUFBSSxDQUFDLEVBQUU7Z0JBQ25DLE1BQU0sSUFBSSxJQUFJLENBQUMsa0JBQWtCLENBQUMsWUFBWSxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUM7YUFDekQ7U0FDSjtRQUVELE9BQU8sTUFBTSxDQUFDO0lBQ2xCLENBQUM7SUFFTyxrQkFBa0IsQ0FBQyxjQUFtQjtRQUMxQyxJQUFJLE1BQU0sR0FBVyxDQUFDLENBQUM7UUFFdkIsSUFBSSxjQUFjLENBQUMsT0FBTyxFQUFFO1lBQ3hCLE1BQU0sSUFBSSxFQUFFLENBQUM7U0FDaEI7UUFFRCxJQUFJLGNBQWMsQ0FBQyxPQUFPLElBQUksY0FBYyxDQUFDLFdBQVcsS0FBSyxVQUFVLEVBQUU7WUFDckUsTUFBTSxJQUFJLEVBQUUsQ0FBQztTQUNoQjtRQUVELE9BQU8sTUFBTSxDQUFDO0lBQ2xCLENBQUM7OztZQXBLSixVQUFVIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgSW5qZWN0YWJsZSB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xyXG5pbXBvcnQge1xyXG4gICAgR3JpZE9wdGlvbnMsXHJcbiAgICBDb2xEZWYsXHJcbiAgICBDb2x1bW4sXHJcbiAgICBSb3dOb2RlLFxyXG4gICAgR3JpZEFwaVxyXG59IGZyb20gJ2FnLWdyaWQtY29tbXVuaXR5JztcclxuaW1wb3J0IHtcclxuICAgIElUYWJsZUNvbHVtbixcclxuICAgIElUYWJsZUNvbmZpZ1xyXG59IGZyb20gJy4uL2tkLWFuZ3VsYXItdGFibGUtaW50ZXJmYWNlJztcclxuaW1wb3J0IHsgS2RUYWJsZVN2Y0Jhc2UgfSBmcm9tICcuL2tkLXRhYmxlLXN2Yyc7XHJcblxyXG4vKipcclxuICogLS0gRG9jdW1lbnRhdGlvbiBmb3Iga2QtdGFibGUtbm9ybWFsLXN2Yy50cyAtLVxyXG4gKlxyXG4gKiBQdWJsaWMgZnVuY3Rpb246XHJcbiAqICAgICAtIEdyaWQgT3B0aW9ucyBmdW5jdGlvblxyXG4gKiAgICAgICAgIC0gZ2VuZXJhdGVHcmlkT3B0aW9ucyAoR3JpZE9wdGlvbiBnZW5lcmF0aW9uIHdpdGggZ3JpZENvbmZpZylcclxuICogICAgICAgICAtIHNldEdyaWRPcHRpb25zXHJcbiAqICAgICAtIENvbHVtbiBkZWZpbml0aW9uIGZ1bmN0aW9uc1xyXG4gKiAgICAgICAgIC0gc2V0Q29sdW1uRGVmIChDb2x1bW4gRGVmaW5pdGlvbnMgYmFzZWQgb24gY29sdW1uQ29uZmlnIGFuZCBncmlkQ29uZmlnKVxyXG4gKiAgICAgICAgIC0gZ2VuZXJhdGVDb2x1bW5EZWZpbml0aW9uc1xyXG4gKiAgICAgLSBSb3cgZGF0YSBmdW5jdGlvbnNcclxuICogICAgICAgICAtIHNldFJvd0RhdGEgKFNldCB0aGUgcm93RGF0YSB0byB0aGUgZ3JpZClcclxuICpcclxuICogUHJpdmF0ZSBmdW5jdGlvbnM6XHJcbiAqICAgICAtIEdyaWQgT3B0aW9ucyBmdW5jdGlvblxyXG4gKiAgICAgICAgIC0gX2dlbmVyYXRlQ29uZmlnT3B0aW9ucyAoYWRkaXRpb25hbCBHcmlkT3B0aW9uIGZyb20gdGFibGUgY29uZmlnKVxyXG4gKiAgICAgLSBSb3cgaGVpZ2h0IGZ1bmN0aW9uc1xyXG4gKiAgICAgICAgIC0gX2dldFJvd0hlaWdodFxyXG4gKiAgICAgICAgIC0gX2NhbGN1bGF0ZVJvd0hlaWdodFxyXG4gKiAgICAgICAgIC0gX2dldFF1ZXN0aW9uSGVpZ2h0XHJcbiAqL1xyXG5cclxuQEluamVjdGFibGUoKVxyXG5leHBvcnQgY2xhc3MgS2RUYWJsZU5vcm1hbFN2YyBleHRlbmRzIEtkVGFibGVTdmNCYXNlIHtcclxuICAgIHByaXZhdGUgX21vdmFibGVDb2x1bW46IGJvb2xlYW4gPSBmYWxzZTtcclxuICAgIC8qKioqKioqKioqKioqKioqKioqKioqKioqKioqKiBQdWJsaWMgZnVuY3Rpb25zICoqKioqKioqKioqKioqKioqKioqKioqKioqKioqKi9cclxuICAgIC8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vXHJcbiAgICAvLy8gR3JpZCBvcHRpb25zIGZ1bmN0aW9uc1xyXG4gICAgLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy9cclxuICAgIHB1YmxpYyBnZW5lcmF0ZUdyaWRPcHRpb25zKF9ncmlkQ29uZmlnOiBJVGFibGVDb25maWcsIF9kaXJlY3Rpb246ICdsdHInIHwgJ3J0bCcpOiBHcmlkT3B0aW9ucyB7XHJcbiAgICAgICAgbGV0IHRlbXBHcmlkT3B0aW9uczogR3JpZE9wdGlvbnMgPSBzdXBlci5nZXREZWZhdWx0R3JpZE9wdGlvbnMoX2RpcmVjdGlvbiwgX2dyaWRDb25maWcucm93Q29udGVudEhlaWdodCk7XHJcblxyXG4gICAgICAgIC8vIGRlbGV0ZSB0ZW1wR3JpZE9wdGlvbnMucm93SGVpZ2h0O1xyXG4gICAgICAgIGxldCBjb25maWdPcHRpb25zOiBHcmlkT3B0aW9ucyA9IHRoaXMuX2dlbmVyYXRlQ29uZmlnT3B0aW9ucyhfZ3JpZENvbmZpZyk7XHJcblxyXG4gICAgICAgICg8YW55Pk9iamVjdCkuYXNzaWduKHRlbXBHcmlkT3B0aW9ucywgY29uZmlnT3B0aW9ucyk7XHJcblxyXG4gICAgICAgIHJldHVybiB0ZW1wR3JpZE9wdGlvbnM7XHJcbiAgICB9XHJcblxyXG4gICAgcHVibGljIHNldEdyaWRPcHRpb25zKF9ncmlkT3B0aW9uczogR3JpZE9wdGlvbnMpOiB2b2lkIHtcclxuICAgICAgICB0aGlzLmdyaWRPcHRpb25zID0gX2dyaWRPcHRpb25zO1xyXG4gICAgfVxyXG5cclxuICAgIC8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vXHJcbiAgICAvLy8gQ29sdW1uIGRlZmluaXRpb24gZnVuY3Rpb25zXHJcbiAgICAvLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vL1xyXG4gICAgcHVibGljIHNldENvbHVtbkRlZihfY29sRGVmQ29uZmlnOiBBcnJheTxJVGFibGVDb2x1bW4+LCBfZ3JpZENvbmZpZzogSVRhYmxlQ29uZmlnLCBfc3VwcHJlc3NNb3ZhYmxlQ29sdW1uczogYm9vbGVhbiA9IHRydWUpOiB2b2lkIHtcclxuICAgICAgICBsZXQgdXBkYXRlZENvbHVtbjogQXJyYXk8Q29sRGVmPiA9IHRoaXMuZ2VuZXJhdGVDb2x1bW5EZWZpbml0aW9ucyhfY29sRGVmQ29uZmlnLCBfZ3JpZENvbmZpZywgX3N1cHByZXNzTW92YWJsZUNvbHVtbnMpO1xyXG5cclxuICAgICAgICB0aGlzLmdyaWRPcHRpb25zLmNvbHVtbkRlZnMgPSB1cGRhdGVkQ29sdW1uO1xyXG5cclxuICAgICAgICBpZiAoc3VwZXIuaXNBcGlSZWFkeSh0aGlzLmdyaWRPcHRpb25zKSkge1xyXG4gICAgICAgICAgICB0aGlzLmdyaWRPcHRpb25zLmFwaS5zZXRDb2x1bW5EZWZzKHVwZGF0ZWRDb2x1bW4pO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICBwdWJsaWMgZ2VuZXJhdGVDb2x1bW5EZWZpbml0aW9ucyhfY29sRGVmQ29uZmlnOiBBcnJheTxJVGFibGVDb2x1bW4+LCBfZ3JpZENvbmZpZzogSVRhYmxlQ29uZmlnLCBfc3VwcHJlc3NNb3ZhYmxlQ29sdW1uczogYm9vbGVhbiA9IHRydWUpOiBBcnJheTxDb2xEZWY+IHtcclxuICAgICAgICByZXR1cm4gc3VwZXIuZ2VuZXJhdGVDb2x1bW5EZWZpbml0aW9ucyhfY29sRGVmQ29uZmlnLCBfZ3JpZENvbmZpZywgX3N1cHByZXNzTW92YWJsZUNvbHVtbnMpO1xyXG4gICAgfVxyXG5cclxuICAgIC8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vXHJcbiAgICAvLy8gUm93IERhdGEgZnVuY3Rpb25zXHJcbiAgICAvLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vL1xyXG4gICAgcHVibGljIHNldFJvd0RhdGEoX3Jvd0RhdGE6IEFycmF5PGFueT4pOiB2b2lkIHtcclxuICAgICAgICB0aGlzLmdyaWRPcHRpb25zLnJvd0RhdGEgPSBfcm93RGF0YTtcclxuICAgICAgICBpZiAoc3VwZXIuaXNBcGlSZWFkeSh0aGlzLmdyaWRPcHRpb25zKSkge1xyXG4gICAgICAgICAgICB0aGlzLmdyaWRPcHRpb25zLmFwaS5zZXRSb3dEYXRhKF9yb3dEYXRhKTtcclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgLyoqKioqKioqKioqKiBFbmQgb2YgcHVibGljIGZ1bmN0aW9ucyAvIFN0YXJ0IG9mIHByaXZhdGUgZnVuY3Rpb25zICoqKioqKioqKioqL1xyXG4gICAgLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy9cclxuICAgIC8vLyBHcmlkIG9wdGlvbnMgZnVuY3Rpb25zXHJcbiAgICAvLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vL1xyXG4gICAgcHJpdmF0ZSBfZ2VuZXJhdGVDb25maWdPcHRpb25zKF9jb25maWc6IElUYWJsZUNvbmZpZyk6IEdyaWRPcHRpb25zIHtcclxuICAgICAgICBsZXQgc2lkZWJhclZhbHVlID0gZmFsc2U7XHJcbiAgICAgICAgaWYoJ3Bpdm90JyBpbiBfY29uZmlnKSB7XHJcbiAgICAgICAgICAgIHNpZGViYXJWYWx1ZSA9IF9jb25maWcucGl2b3Quc3RhdGUucGl2b3RNb2RlO1xyXG4gICAgICAgIH1cclxuICAgICAgICBsZXQgY29uZmlnT3B0aW9uczogR3JpZE9wdGlvbnMgPSB7XHJcbiAgICAgICAgICAgIHJvd01vZGVsVHlwZTogJ2NsaWVudFNpZGUnLFxyXG4gICAgICAgICAgICBlbmFibGVTb3J0aW5nOiB0cnVlLFxyXG4gICAgICAgICAgICBlbmFibGVGaWx0ZXI6IHRydWUsXHJcbiAgICAgICAgICAgIGdldFJvd0hlaWdodDogKF9wYXJhbXM6IGFueSk6IG51bWJlciA9PiB7XHJcbiAgICAgICAgICAgICAgICBpZiAoX2NvbmZpZy5yb3dDb250ZW50SGVpZ2h0KSB7XHJcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIF9jb25maWcucm93Q29udGVudEhlaWdodFxyXG4gICAgICAgICAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgICAgICAgICByZXR1cm4gdGhpcy5fZ2V0Um93SGVpZ2h0KF9wYXJhbXMpO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICBzaWRlQmFyOiBzaWRlYmFyVmFsdWUsXHJcbiAgICAgICAgICAgIGNvbnRleHQ6IF9jb25maWcuY29udGV4dFxyXG4gICAgICAgIH07XHJcblxyXG4gICAgICAgIGlmICh0eXBlb2YgX2NvbmZpZy5yb3dJZEtleSAhPT0gJ3VuZGVmaW5lZCcpIHtcclxuICAgICAgICAgICAgdGhpcy5yb3dLZXkgPSBfY29uZmlnLnJvd0lkS2V5O1xyXG5cclxuICAgICAgICAgICAgY29uZmlnT3B0aW9ucy5nZXRSb3dOb2RlSWQgPSAoX2RhdGE6IGFueSk6IHN0cmluZyA9PiB7XHJcbiAgICAgICAgICAgICAgICBpZiAoX2RhdGEuaGFzT3duUHJvcGVydHkoX2NvbmZpZy5yb3dJZEtleSkpIHtcclxuICAgICAgICAgICAgICAgICAgICBsZXQgaWQ6IHN0cmluZyA9IF9kYXRhW19jb25maWcucm93SWRLZXldO1xyXG5cclxuICAgICAgICAgICAgICAgICAgICBpZiAodHlwZW9mIF9kYXRhW19jb25maWcucm93SWRLZXldID09PSAnbnVtYmVyJykge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBpZCA9IGlkLnRvU3RyaW5nKCk7XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgICAgICAgICByZXR1cm4gaWQ7XHJcbiAgICAgICAgICAgICAgICB9IGVsc2UgaWYgKF9kYXRhLmhhc093blByb3BlcnR5KCdkYXRhJykpIHtcclxuICAgICAgICAgICAgICAgICAgICBsZXQgaWQ6IHN0cmluZyA9IF9kYXRhLmRhdGFbX2NvbmZpZy5yb3dJZEtleV07XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIGlmICh0eXBlb2YgX2RhdGEuZGF0YVtfY29uZmlnLnJvd0lkS2V5XSA9PT0gJ251bWJlcicpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgaWQgPSBpZC50b1N0cmluZygpO1xyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIGlkO1xyXG4gICAgICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgICAgIHJldHVybiAnJztcclxuICAgICAgICAgICAgfTtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIHJldHVybiBjb25maWdPcHRpb25zO1xyXG4gICAgfVxyXG5cclxuICAgIC8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vXHJcbiAgICAvLy8gUm93IEhlaWdodCBmdW5jdGlvbnNcclxuICAgIC8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vXHJcbiAgICBwcml2YXRlIF9nZXRSb3dIZWlnaHQoX3BhcmFtczogeyBub2RlOiBSb3dOb2RlLCBkYXRhOiBhbnksIGFwaTogR3JpZEFwaSwgY29udGV4dDogYW55IH0pOiBudW1iZXIge1xyXG4gICAgICAgIGxldCBtYXhIZWlnaHQ6IG51bWJlciA9IHRoaXMuUk9XX0hFSUdIVDtcclxuICAgICAgICBsZXQgYWxsQ29sdW1uczogQXJyYXk8Q29sdW1uPiA9ICg8YW55Pl9wYXJhbXMubm9kZSkuY29sdW1uQXBpLmdldEFsbENvbHVtbnMoKTtcclxuICAgICAgICBsZXQgY29sdW1uSGVpZ2h0OiBudW1iZXIgPSAwO1xyXG5cclxuICAgICAgICBmb3IgKGxldCBpOiBudW1iZXIgPSAwOyBpIDwgYWxsQ29sdW1ucy5sZW5ndGg7ICsraSkge1xyXG4gICAgICAgICAgICBjb2x1bW5IZWlnaHQgPSB0aGlzLlJPV19IRUlHSFQ7XHJcblxyXG4gICAgICAgICAgICBpZiAoc3VwZXIuaXNDb2xEZWZPZlR5cGUoYWxsQ29sdW1uc1tpXS5nZXRDb2xEZWYoKSwgdGhpcy5HSVJEX1BBUkFNU19LRVkuaW5wdXQpKSB7XHJcbiAgICAgICAgICAgICAgICBsZXQgY29udGV4dEtleTogc3RyaW5nID0gc3VwZXIuZ2VuZXJhdGVDb250ZXh0S2V5KF9wYXJhbXMuY29udGV4dC5ncmlkSWQsIGFsbENvbHVtbnNbaV0uZ2V0Q29sRGVmKCkuY29sSWQsIF9wYXJhbXMubm9kZS5pZCk7XHJcblxyXG4gICAgICAgICAgICAgICAgaWYgKF9wYXJhbXMuY29udGV4dFt0aGlzLlRBQkxFX0lOUFVUX0NPTlRFWFRfS0VZXS5oYXNPd25Qcm9wZXJ0eShjb250ZXh0S2V5KSkge1xyXG4gICAgICAgICAgICAgICAgICAgIGNvbHVtbkhlaWdodCA9IHRoaXMuX2NhbGN1bGF0ZVJvd0hlaWdodChfcGFyYW1zLmNvbnRleHRbdGhpcy5UQUJMRV9JTlBVVF9DT05URVhUX0tFWV1bY29udGV4dEtleV0pO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICBpZiAoc3VwZXIuaXNDb2xEZWZPZlR5cGUoYWxsQ29sdW1uc1tpXS5nZXRDb2xEZWYoKSwgdGhpcy5HSVJEX1BBUkFNU19LRVkuaW1hZ2UpKSB7XHJcbiAgICAgICAgICAgICAgICBjb25zdCBkZWZhdWx0Q29sSGVpZ2h0OiBudW1iZXIgPSAxNTA7XHJcblxyXG4gICAgICAgICAgICAgICAgaWYgKHR5cGVvZiBhbGxDb2x1bW5zW2ldLmdldENvbERlZigpLmNlbGxSZW5kZXJlclBhcmFtcy5wYXJhbXMuaW1hZ2VDb25maWcuaGVpZ2h0ICE9PSAndW5kZWZpbmVkJykge1xyXG4gICAgICAgICAgICAgICAgICAgIGNvbHVtbkhlaWdodCA9IGFsbENvbHVtbnNbaV0uZ2V0Q29sRGVmKCkuY2VsbFJlbmRlcmVyUGFyYW1zLnBhcmFtcy5pbWFnZUNvbmZpZy5oZWlnaHQgKyB0aGlzLklNQUdFX1BBRERJTkc7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgICAgICAgICBjb2x1bW5IZWlnaHQgPSBkZWZhdWx0Q29sSGVpZ2h0ICsgdGhpcy5JTUFHRV9QQURESU5HO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICBpZiAoY29sdW1uSGVpZ2h0ID4gbWF4SGVpZ2h0KSB7XHJcbiAgICAgICAgICAgICAgICBtYXhIZWlnaHQgPSBjb2x1bW5IZWlnaHQ7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIHJldHVybiBtYXhIZWlnaHQ7XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfY2FsY3VsYXRlUm93SGVpZ2h0KF9jb250ZXh0RGF0YTogYW55KTogbnVtYmVyIHtcclxuICAgICAgICBsZXQgaGVpZ2h0OiBudW1iZXIgPSAwO1xyXG5cclxuICAgICAgICBmb3IgKGxldCBpdGVtIGluIF9jb250ZXh0RGF0YSkge1xyXG4gICAgICAgICAgICBpZiAoX2NvbnRleHREYXRhLmhhc093blByb3BlcnR5KGl0ZW0pKSB7XHJcbiAgICAgICAgICAgICAgICBoZWlnaHQgKz0gdGhpcy5fZ2V0UXVlc3Rpb25IZWlnaHQoX2NvbnRleHREYXRhW2l0ZW1dKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgcmV0dXJuIGhlaWdodDtcclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF9nZXRRdWVzdGlvbkhlaWdodChfdGFibGVEYXRhSXRlbTogYW55KTogbnVtYmVyIHtcclxuICAgICAgICBsZXQgaGVpZ2h0OiBudW1iZXIgPSAwO1xyXG5cclxuICAgICAgICBpZiAoX3RhYmxlRGF0YUl0ZW0udmlzaWJsZSkge1xyXG4gICAgICAgICAgICBoZWlnaHQgKz0gNTA7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICBpZiAoX3RhYmxlRGF0YUl0ZW0udmlzaWJsZSAmJiBfdGFibGVEYXRhSXRlbS5jb250cm9sVHlwZSA9PT0gJ3RleHRhcmVhJykge1xyXG4gICAgICAgICAgICBoZWlnaHQgKz0gNzA7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICByZXR1cm4gaGVpZ2h0O1xyXG4gICAgfVxyXG5cclxuICAgIC8qKioqKioqKioqKioqKioqKioqKioqKioqIEVuZCBvZiBwcml2YXRlIGZ1bmN0aW9ucyAqKioqKioqKioqKioqKioqKioqKioqKioqKi9cclxufVxyXG4iXX0=