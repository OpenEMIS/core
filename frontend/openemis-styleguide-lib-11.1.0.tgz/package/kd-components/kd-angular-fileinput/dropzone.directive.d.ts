import { EventEmitter } from '@angular/core';
export declare class DragDropDirective {
    _enabled: boolean;
    _dragInProgress: boolean;
    set appDragDrop(value: any);
    get dragInProgress(): boolean;
    dropped: EventEmitter<any>;
    constructor();
    handleDragOver(event: DragEvent): void;
    handleDragEnd(event: DragEvent): void;
    handleDrop(event: UIEvent): void;
    stopAndPreventDefault(e: UIEvent): void;
}
