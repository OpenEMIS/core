import { OnInit, EventEmitter, ViewContainerRef, ElementRef } from '@angular/core';
import { IFileResult } from './kd-fileinput-interface';
export declare class KdFileInput implements OnInit {
    private _vcr;
    _leftButton: string;
    _fileResult: IFileResult;
    dragDropEnabled: boolean;
    config: any;
    value: any;
    result: EventEmitter<any>;
    myFiles: any;
    inputRef: ElementRef<HTMLInputElement>;
    constructor(_vcr: ViewContainerRef);
    ngOnInit(): void;
    handleFileSelect(event: any): void;
    handleFileMultipleSelect(event: any): void;
    removeSelectedFile(file: any, index: any): void;
    handleFileDrop(event: DragEvent): void;
    removeFile(_event: Event): void;
    buttonCallback(_event: Event, _button: any): void;
    private _checkInitFile;
    private _setFileType;
    private _setLeftBtn;
}
