export { KdChat } from './kd-angular-chat';
