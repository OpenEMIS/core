import { OnInit, OnDestroy, EventEmitter, ChangeDetectorRef } from '@angular/core';
export declare class KdChat implements OnInit, OnDestroy {
    private cdr;
    messageArray: any[];
    dropdownData: any[];
    inputMessage: EventEmitter<any>;
    messageData: any;
    chatForm: any;
    showChatBot: boolean;
    recordCount: number;
    disableInput: boolean;
    countRecord: number;
    tooltipData: any;
    displaySubmit: boolean;
    dropdownWithoutLabel: Array<any>;
    filterButtons: Array<any>;
    recordingInterval: any;
    startTime: any;
    constructor(cdr: ChangeDetectorRef);
    ngOnInit(): void;
    sendMessage(): void;
    getEditMessage(event: any): void;
    toggleRecording(): void;
    updateRecordingTime(messageData: any): void;
    _changeEvent(event: any): void;
    ngOnDestroy(): void;
}
