import { Component, ViewEncapsulation, Input } from '@angular/core';
import { KdChartBaseClass } from '../kd-angular-chart-base-class';
import { KdChartsSvc } from '../kd-angular-charts-svc';
import { KdDomElemSvc } from '../../kd-common/index';
import { KdBarChartSvc } from './kd-angular-bar-chart-svc';
export class KdBarChart extends KdChartBaseClass {
    constructor(_chartSvc, _domSvc, _barSvc) {
        super(_chartSvc, _domSvc);
        this._chartSvc = _chartSvc;
        this._domSvc = _domSvc;
        this._barSvc = _barSvc;
        this._isStartAtSum = false;
    }
    ngOnInit() {
        this._redrawChart(true, { data: this.allData, config: this.barConfig });
        this.api.legendClick = (_data) => {
            this._redrawChart(false, { data: _data });
        };
        this.api.redraw = () => {
            clearTimeout(this._resizeTimeout);
            this._resizeTimeout = setTimeout(() => {
                this._redrawChart(false, {});
            });
        };
    }
    ngOnChanges(_simpleChanges) {
        if (_simpleChanges.hasOwnProperty('allData') && !_simpleChanges['allData'].firstChange) {
            this._redrawChart(false, { data: _simpleChanges.allData.currentValue });
        }
        if (_simpleChanges.hasOwnProperty('barConfig') && !_simpleChanges['barConfig'].firstChange) {
            this._redrawChart(false, { config: _simpleChanges.barConfig.currentValue });
        }
    }
    ngOnDestroy() {
        this._resetChart();
    }
    _redrawChart(isFirstChange, _changes = {}) {
        if (!isFirstChange) {
            this._resetChart();
        }
        this.legendData = Object.assign({}, this.legend);
        if (_changes.hasOwnProperty('data'))
            this._setData(_changes.data);
        if (_changes.hasOwnProperty('config'))
            this._setConfig(_changes.config);
        super.chartTimeout(() => this._setChart());
    }
    _setData(_data) {
        this.data = Object.assign([], _data.data);
        // saving original data somewhere before trimming this.data. when no trimming, then this.data will just be initData
        this.initData = JSON.parse(JSON.stringify(this.data));
        this.chartCategory = 'bar';
        this.chartType = _data.layout.split('-');
        this._chartSvc.isInvert = this.chartType[0] === 'bar';
        this.bar.isInvert = this.chartType[0] === 'bar';
        this._chartSvc.isNegativeStack = this.chartType[1] === 'stack' && this.chartType[2] === 'negative';
        // range and negative flag calculated by kdChart, used in domain, recalculated when change graph type and legend
        this.dataRange = _data.range;
        this.haveNegative = _data.haveNegative;
        this._barSvc.originalDataRange = _data.range;
    }
    _setConfig(_config) {
        this.config = Object.assign({}, _config);
    }
    _setChart() {
        if (this.chartType[1] === '100' && this.haveNegative)
            return;
        if (this._chartSvc.isNegativeStack)
            this.negativeStackSymmetryLogic();
        super.setSvg();
        super.setDomain('band');
        this._drawChart();
    }
    _resetChart() {
        super.removeChart();
        if (this._barGraph) {
            this._barGraph.remove();
            this._barGraph = null;
        }
    }
    _drawChartContainer() {
        this._barGraph = this.graph.append('g').attr('class', 'bar-graph-container');
        this._barGraph.attr('clip-path', 'url(#kd-charts-clip-path-' + this.config.id + ')');
    }
    _drawChart() {
        if (!this._barGraph)
            this._drawChartContainer();
        this._isStartAtSum = this.bar.isInvert === this._chartSvc.isYReversed;
        let rectPosInfo = this._getRectPosInfo();
        this.data.forEach((d, i) => {
            let groups = this._setRectGroup(d, i, d.y, this._barGraph, rectPosInfo);
            super._initMouseEvents(groups.rectGroup, { data: d, index: i });
            if (this.config.chart.labels.enabled) {
                this._setBarChartLabel(d, i, groups);
                if (this.config.animation) {
                    groups.rectGroupTransite.on('end', (yData, yIndex) => {
                        // when the last rect transite ends
                        if ((yData.xIndex === this.data.length - 1)
                            && (yIndex === this.data[this.data.length - 1].y.length - 1)) {
                            this._displayAllLabel();
                        }
                    });
                }
                else {
                    this._displayAllLabel();
                }
            }
        });
    }
    _setRectGroup(_d, _xIndex, _yDataArr, _container, _rectPosInfo) {
        let rectGroup = _container.selectAll('rectGroup')
            .data(_yDataArr, (d) => { d['xIndex'] = _xIndex; return d; })
            .enter()
            .append('rect');
        let offset = 0, rectGroupTransite, xPosArr = [], yPosArr = [], widthArr = [], heightArr = [];
        rectGroup
            .attr('class', (yData) => 'bar x-' + _xIndex + ' y-' + yData.id)
            .attr('fill', (yData, yIndex) => this.legend.hasOwnProperty(yData.id) ? this.legend[yData.id].color || '' : '')
            .attr('aria-x-value', _d.x.value)
            .attr('aria-y-value', (yData) => yData.sum);
        if (this.chartType[0] === 'column') {
            rectGroup
                .attr('width', pushAndReturn(widthArr, _rectPosInfo.width))
                .attr('x', (yData, yIndex) => {
                if (this.chartType[1] === 'cluster')
                    offset = _rectPosInfo.width * yIndex + _rectPosInfo.padding * yIndex;
                return pushAndReturn(xPosArr, this.x(_d.x.value) + offset);
            });
            if (!this.config.animation) {
                rectGroup
                    .attr('y', (yData) => pushAndReturn(yPosArr, this._getVal('y', yData)))
                    .attr('height', (yData) => pushAndReturn(heightArr, this._getVal('height', yData)));
            }
            else {
                rectGroup
                    .attr('y', this.y(0))
                    .attr('height', 0);
                rectGroupTransite = rectGroup.transition().duration(this.lengthOfTransition)
                    .attr('y', (yData) => pushAndReturn(yPosArr, this._getVal('y', yData)))
                    .attr('height', (yData) => pushAndReturn(heightArr, this._getVal('height', yData)));
            }
        }
        else {
            rectGroup
                .attr('height', pushAndReturn(heightArr, _rectPosInfo.width))
                .attr('y', (yData, yIndex) => {
                if (this.chartType[1] === 'cluster')
                    offset = _rectPosInfo.width * yIndex + _rectPosInfo.padding * yIndex;
                return pushAndReturn(yPosArr, this.x(_d.x.value) + offset);
            });
            if (!this.config.animation) {
                rectGroup
                    .attr('x', (yData) => pushAndReturn(xPosArr, this._getVal('x', yData)))
                    .attr('width', (yData) => pushAndReturn(widthArr, this._getVal('width', yData)));
            }
            else {
                rectGroup
                    .attr('x', this.y(0))
                    .attr('width', 0);
                rectGroupTransite = rectGroup.transition().duration(this.lengthOfTransition)
                    .attr('x', (yData) => pushAndReturn(xPosArr, this._getVal('x', yData)))
                    .attr('width', (yData) => pushAndReturn(widthArr, this._getVal('width', yData)));
            }
        }
        return {
            rectGroup: rectGroup,
            rectGroupTransite: rectGroupTransite,
            xPosArr: xPosArr,
            yPosArr: yPosArr,
            widthArr: widthArr,
            heightArr: heightArr
        };
        function pushAndReturn(target, value) {
            target.push(value);
            return value;
        }
    }
    _getVal(_type, _yData) {
        let value = this.chartType[1] === '100' ? _yData.renderVal : _yData.value;
        let offset = value ? 1 : 0;
        if (_type === 'x' || _type === 'y') {
            return this._isStartAtSum ? this.y(negativeRecal(_yData.sum, value)) : this.y(negativeRecal(_yData.sum, value) - Math.abs(value));
        }
        if (_type === 'height')
            return Math.abs(this.y(negativeRecal(_yData.sum, value) - value) - this.y(negativeRecal(_yData.sum, value))) + offset;
        if (_type === 'width')
            return Math.abs(this.y(negativeRecal(_yData.sum, value)) - this.y(negativeRecal(_yData.sum, value) - value)) + offset;
        // rendering rect for negative uses values lesser by one index. eg: first value = -2, sum = -2, renders 0.... second value = -4, sum = -6, renders -2
        function negativeRecal(_sum, _value) {
            return Math.sign(_sum) < 0 ? _sum - _value : _sum;
        }
    }
    _setBarChartLabel(_d, _xIndex, _group) {
        for (let yIndex = 0; yIndex < _d.y.length; ++yIndex) {
            if (_d.y[yIndex].value === null)
                continue;
            let yData = Object.assign({}, _d.y[yIndex]), dimensions = {
                yPos: _group.yPosArr[yIndex],
                xPos: _group.xPosArr[yIndex],
                height: this.chartType[0] === 'column' ? _group.heightArr[yIndex] : _group.heightArr[0],
                width: this.chartType[0] === 'column' ? _group.widthArr[0] : _group.widthArr[yIndex]
            };
            if (!this.config.chart.labels.inside) {
                if (this.chartType[0] === 'column') {
                    if ((yData.value < 0 && !this._chartSvc.isYReversed) || (yData.value > 0 && this._chartSvc.isYReversed)) {
                        dimensions.yPos += _group.heightArr[yIndex];
                    }
                    // when rtl, div starts at top right of rect
                    if (this.isRtl)
                        dimensions.xPos += _group.widthArr[0];
                }
                else {
                    if ((yData.value > 0 && !this._chartSvc.isYReversed) || (yData.value < 0 && this._chartSvc.isYReversed)) {
                        dimensions.xPos += _group.widthArr[yIndex];
                    }
                }
            }
            else {
                if (this.isRtl) {
                    // when rtl,
                    // for Column, div starts at top right of rect
                    // for Bar, div start at end of rect and take the width of bars
                    let index = this.chartType[0] === 'column' ? 0 : yIndex;
                    dimensions.xPos += _group.widthArr[index];
                }
            }
            if (this._chartSvc.isNegativeStack)
                yData.value = this._chartSvc.checkAndReturnLabelsPositive(yData.value);
            let labelContainer = super.setLabel(yData, _xIndex, dimensions.xPos, dimensions.yPos);
            // value here is rawValue (negativeStackBar may have changed yData.value)
            this._setLabelStyle(labelContainer, _d.y[yIndex].value, dimensions);
        }
    }
    // for column, width is constant, height is vary
    // for bar, height is constant, width is vary
    _setLabelStyle(_labelContainer, _value, _dimensions) {
        let labelText = _labelContainer.select('.kdx-charts-data-label-text');
        let verticalAlign = this.config.chart.labels.verticalAlign;
        let inside = this.config.chart.labels.inside;
        let sign = Math.sign(_value);
        if (!verticalAlign)
            verticalAlign = this.chartType[0] === 'column' ? 'top' : 'middle';
        this._barSvc.setLabelContainerWidthOrHeight(_labelContainer, this.chartType[0], inside, _dimensions);
        // if label is higher than bar's/column's height
        let isLabelHigherThanRect = this._chartSvc._getLabelTextHeight() > _dimensions.height;
        if (isLabelHigherThanRect) {
            if (this.chartType[0] === 'bar') {
                verticalAlign = 'middle';
            }
            else if (inside) {
                // if column and inside, to make sure label will not hit into axis,
                // if axis is at bottom of chart, set to flex-end so that text will be placed above
                // if axis is at top of chart, set to flex-start so that text will be placed below
                verticalAlign = this._chartSvc.isYReversed ? 'top' : 'bottom';
            }
        }
        if (!inside) {
            if (this.chartType[0] === 'bar') {
                this._barSvc._setLabelTextPosHorizontal(labelText, this._chartSvc.isYReversed, { xPos: _dimensions.xPos, chartWidth: this.width, valueSign: sign });
            }
            else {
                let params = { valueSign: sign };
                let yPos = _dimensions.yPos; // used for boundary checking.
                if (isLabelHigherThanRect && this.chartType[1] === 'cluster') {
                    params['dimensions'] = _dimensions;
                    let needOffset = this._chartSvc.needOffsetForColumn(verticalAlign, params);
                    if (needOffset)
                        yPos += needOffset * _dimensions.height;
                }
                super.setLabelTextPosition(labelText, yPos, params);
            }
        }
        this._barSvc.setVerticalAlignCSS(_labelContainer, verticalAlign);
    }
    _displayAllLabel() {
        this.dataLabelContainer
            .selectAll('.kdx-charts-data-label')
            .style('visibility', 'visible');
    }
    _getRectPosInfo() {
        if (this.chartType[1] === 'cluster') {
            // the amount of yData for each x value will always be the same (if we don't remove null values)
            // hence this calculation only needs to run once
            let yArrLength = this.data[0] && this.data[0].y ? this.data[0].y.length : 0;
            return this._barSvc.getRectWidth(this.x.bandwidth(), this.bar.clusterPaddingPercent, yArrLength);
        }
        return {
            width: this.x.bandwidth(),
            padding: 0
        };
    }
    negativeStackSymmetryLogic() {
        let result = this._barSvc.applySymmetricAxis(this.dataRange, this.config.plotOptions, this.config.yAxis);
        if (result.hasOwnProperty('dataRange'))
            this.dataRange = result.dataRange;
        if (result.hasOwnProperty('yAxis')) {
            this.config.yAxis = Object.assign({}, this.config.yAxis, result.yAxis);
        }
    }
}
KdBarChart.decorators = [
    { type: Component, args: [{
                selector: 'kd-bar-chart',
                template: `
        <div *ngIf="chartType[1] === '100' && haveNegative" class="kdx-charts-error-msg">
            {{errorMsg}}
        </div>
    `,
                encapsulation: ViewEncapsulation.None,
                providers: [KdChartsSvc, KdDomElemSvc, KdBarChartSvc],
                host: {
                    'class': 'kdx-bar-chart',
                }
            },] }
];
KdBarChart.ctorParameters = () => [
    { type: KdChartsSvc },
    { type: KdDomElemSvc },
    { type: KdBarChartSvc }
];
KdBarChart.propDecorators = {
    allData: [{ type: Input, args: ['data',] }],
    barConfig: [{ type: Input, args: ['config',] }],
    legend: [{ type: Input }],
    api: [{ type: Input }]
};
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoia2QtYW5ndWxhci1iYXItY2hhcnQuanMiLCJzb3VyY2VSb290IjoiQzovUHJvamVjdHMvQW5ndWxhci9pb3N0Zy1vcGVuZW1pcy1zdHlsZWd1aWRlL3Byb2plY3RzL29wZW5lbWlzLXN0eWxlZ3VpZGUtbGliL3NyYy8iLCJzb3VyY2VzIjpbImtkLWNvbXBvbmVudHMva2QtYW5ndWxhci1jaGFydHMva2QtYW5ndWxhci1iYXItY2hhcnQva2QtYW5ndWxhci1iYXItY2hhcnQudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsT0FBTyxFQUNILFNBQVMsRUFDVCxpQkFBaUIsRUFDakIsS0FBSyxFQUtSLE1BQU0sZUFBZSxDQUFDO0FBQ3ZCLE9BQU8sRUFBRSxnQkFBZ0IsRUFBRSxNQUFNLGdDQUFnQyxDQUFDO0FBQ2xFLE9BQU8sRUFBRSxXQUFXLEVBQUUsTUFBTSwwQkFBMEIsQ0FBQztBQUd2RCxPQUFPLEVBQUUsWUFBWSxFQUFFLE1BQU0sdUJBQXVCLENBQUM7QUFDckQsT0FBTyxFQUFFLGFBQWEsRUFBRSxNQUFNLDRCQUE0QixDQUFDO0FBZ0IzRCxNQUFNLE9BQU8sVUFBVyxTQUFRLGdCQUFnQjtJQVc1QyxZQUNXLFNBQXNCLEVBQ3RCLE9BQXFCLEVBQ3JCLE9BQXNCO1FBRTdCLEtBQUssQ0FBQyxTQUFTLEVBQUUsT0FBTyxDQUFDLENBQUM7UUFKbkIsY0FBUyxHQUFULFNBQVMsQ0FBYTtRQUN0QixZQUFPLEdBQVAsT0FBTyxDQUFjO1FBQ3JCLFlBQU8sR0FBUCxPQUFPLENBQWU7UUFWekIsa0JBQWEsR0FBWSxLQUFLLENBQUM7SUFhdkMsQ0FBQztJQUVELFFBQVE7UUFDSixJQUFJLENBQUMsWUFBWSxDQUFDLElBQUksRUFBRSxFQUFFLElBQUksRUFBRSxJQUFJLENBQUMsT0FBTyxFQUFFLE1BQU0sRUFBRSxJQUFJLENBQUMsU0FBUyxFQUFFLENBQUMsQ0FBQztRQUN4RSxJQUFJLENBQUMsR0FBRyxDQUFDLFdBQVcsR0FBRyxDQUFDLEtBQVUsRUFBRSxFQUFFO1lBQ2xDLElBQUksQ0FBQyxZQUFZLENBQUMsS0FBSyxFQUFFLEVBQUUsSUFBSSxFQUFFLEtBQUssRUFBRSxDQUFDLENBQUM7UUFDOUMsQ0FBQyxDQUFDO1FBQ0YsSUFBSSxDQUFDLEdBQUcsQ0FBQyxNQUFNLEdBQUcsR0FBRyxFQUFFO1lBQ25CLFlBQVksQ0FBQyxJQUFJLENBQUMsY0FBYyxDQUFDLENBQUM7WUFDbEMsSUFBSSxDQUFDLGNBQWMsR0FBRyxVQUFVLENBQUMsR0FBRyxFQUFFO2dCQUNsQyxJQUFJLENBQUMsWUFBWSxDQUFDLEtBQUssRUFBRSxFQUFFLENBQUMsQ0FBQztZQUNqQyxDQUFDLENBQUMsQ0FBQztRQUNQLENBQUMsQ0FBQztJQUNOLENBQUM7SUFFRCxXQUFXLENBQUMsY0FBNkI7UUFDckMsSUFBSSxjQUFjLENBQUMsY0FBYyxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsY0FBYyxDQUFDLFNBQVMsQ0FBQyxDQUFDLFdBQVcsRUFBRTtZQUNwRixJQUFJLENBQUMsWUFBWSxDQUFDLEtBQUssRUFBRSxFQUFFLElBQUksRUFBRSxjQUFjLENBQUMsT0FBTyxDQUFDLFlBQVksRUFBRSxDQUFDLENBQUM7U0FDM0U7UUFDRCxJQUFJLGNBQWMsQ0FBQyxjQUFjLENBQUMsV0FBVyxDQUFDLElBQUksQ0FBQyxjQUFjLENBQUMsV0FBVyxDQUFDLENBQUMsV0FBVyxFQUFFO1lBQ3hGLElBQUksQ0FBQyxZQUFZLENBQUMsS0FBSyxFQUFFLEVBQUUsTUFBTSxFQUFFLGNBQWMsQ0FBQyxTQUFTLENBQUMsWUFBWSxFQUFFLENBQUMsQ0FBQztTQUMvRTtJQUNMLENBQUM7SUFFRCxXQUFXO1FBQ1AsSUFBSSxDQUFDLFdBQVcsRUFBRSxDQUFDO0lBQ3ZCLENBQUM7SUFFTyxZQUFZLENBQUMsYUFBc0IsRUFBRSxXQUFzRCxFQUFFO1FBQ2pHLElBQUksQ0FBQyxhQUFhLEVBQUU7WUFDaEIsSUFBSSxDQUFDLFdBQVcsRUFBRSxDQUFDO1NBQ3RCO1FBQ0QsSUFBSSxDQUFDLFVBQVUsR0FBRyxNQUFNLENBQUMsTUFBTSxDQUFDLEVBQUUsRUFBRSxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUM7UUFDakQsSUFBSSxRQUFRLENBQUMsY0FBYyxDQUFDLE1BQU0sQ0FBQztZQUFFLElBQUksQ0FBQyxRQUFRLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxDQUFDO1FBQ2xFLElBQUksUUFBUSxDQUFDLGNBQWMsQ0FBQyxRQUFRLENBQUM7WUFBRSxJQUFJLENBQUMsVUFBVSxDQUFDLFFBQVEsQ0FBQyxNQUFNLENBQUMsQ0FBQztRQUN4RSxLQUFLLENBQUMsWUFBWSxDQUFDLEdBQUcsRUFBRSxDQUFDLElBQUksQ0FBQyxTQUFTLEVBQUUsQ0FBQyxDQUFDO0lBQy9DLENBQUM7SUFFTyxRQUFRLENBQUMsS0FBYztRQUMzQixJQUFJLENBQUMsSUFBSSxHQUFHLE1BQU0sQ0FBQyxNQUFNLENBQUMsRUFBRSxFQUFFLEtBQUssQ0FBQyxJQUFJLENBQUMsQ0FBQztRQUMxQyxtSEFBbUg7UUFDbkgsSUFBSSxDQUFDLFFBQVEsR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUM7UUFFdEQsSUFBSSxDQUFDLGFBQWEsR0FBRyxLQUFLLENBQUM7UUFDM0IsSUFBSSxDQUFDLFNBQVMsR0FBRyxLQUFLLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FBQztRQUN6QyxJQUFJLENBQUMsU0FBUyxDQUFDLFFBQVEsR0FBRyxJQUFJLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxLQUFLLEtBQUssQ0FBQztRQUN0RCxJQUFJLENBQUMsR0FBRyxDQUFDLFFBQVEsR0FBRyxJQUFJLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxLQUFLLEtBQUssQ0FBQztRQUNoRCxJQUFJLENBQUMsU0FBUyxDQUFDLGVBQWUsR0FBRyxJQUFJLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxLQUFLLE9BQU8sSUFBSSxJQUFJLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxLQUFLLFVBQVUsQ0FBQztRQUVuRyxnSEFBZ0g7UUFDaEgsSUFBSSxDQUFDLFNBQVMsR0FBRyxLQUFLLENBQUMsS0FBSyxDQUFDO1FBQzdCLElBQUksQ0FBQyxZQUFZLEdBQUcsS0FBSyxDQUFDLFlBQVksQ0FBQztRQUN2QyxJQUFJLENBQUMsT0FBTyxDQUFDLGlCQUFpQixHQUFHLEtBQUssQ0FBQyxLQUFLLENBQUM7SUFDakQsQ0FBQztJQUVPLFVBQVUsQ0FBQyxPQUFxQjtRQUNwQyxJQUFJLENBQUMsTUFBTSxHQUFHLE1BQU0sQ0FBQyxNQUFNLENBQUMsRUFBRSxFQUFFLE9BQU8sQ0FBQyxDQUFDO0lBQzdDLENBQUM7SUFFTyxTQUFTO1FBQ2IsSUFBSSxJQUFJLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxLQUFLLEtBQUssSUFBSSxJQUFJLENBQUMsWUFBWTtZQUFFLE9BQU87UUFDN0QsSUFBSSxJQUFJLENBQUMsU0FBUyxDQUFDLGVBQWU7WUFBRSxJQUFJLENBQUMsMEJBQTBCLEVBQUUsQ0FBQztRQUN0RSxLQUFLLENBQUMsTUFBTSxFQUFFLENBQUM7UUFDZixLQUFLLENBQUMsU0FBUyxDQUFDLE1BQU0sQ0FBQyxDQUFDO1FBQ3hCLElBQUksQ0FBQyxVQUFVLEVBQUUsQ0FBQztJQUN0QixDQUFDO0lBRU8sV0FBVztRQUNmLEtBQUssQ0FBQyxXQUFXLEVBQUUsQ0FBQztRQUNwQixJQUFJLElBQUksQ0FBQyxTQUFTLEVBQUU7WUFDaEIsSUFBSSxDQUFDLFNBQVMsQ0FBQyxNQUFNLEVBQUUsQ0FBQztZQUN4QixJQUFJLENBQUMsU0FBUyxHQUFHLElBQUksQ0FBQztTQUN6QjtJQUNMLENBQUM7SUFFTyxtQkFBbUI7UUFDdkIsSUFBSSxDQUFDLFNBQVMsR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsQ0FBQyxJQUFJLENBQUMsT0FBTyxFQUFFLHFCQUFxQixDQUFDLENBQUM7UUFDN0UsSUFBSSxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsV0FBVyxFQUFFLDJCQUEyQixHQUFHLElBQUksQ0FBQyxNQUFNLENBQUMsRUFBRSxHQUFHLEdBQUcsQ0FBQyxDQUFDO0lBQ3pGLENBQUM7SUFFTyxVQUFVO1FBQ2QsSUFBSSxDQUFDLElBQUksQ0FBQyxTQUFTO1lBQUUsSUFBSSxDQUFDLG1CQUFtQixFQUFFLENBQUM7UUFFaEQsSUFBSSxDQUFDLGFBQWEsR0FBRyxJQUFJLENBQUMsR0FBRyxDQUFDLFFBQVEsS0FBSyxJQUFJLENBQUMsU0FBUyxDQUFDLFdBQVcsQ0FBQztRQUV0RSxJQUFJLFdBQVcsR0FBdUMsSUFBSSxDQUFDLGVBQWUsRUFBRSxDQUFDO1FBRTdFLElBQUksQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBYyxFQUFFLENBQVMsRUFBRSxFQUFFO1lBQzVDLElBQUksTUFBTSxHQUFlLElBQUksQ0FBQyxhQUFhLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxFQUFFLElBQUksQ0FBQyxTQUFTLEVBQUUsV0FBVyxDQUFDLENBQUM7WUFFcEYsS0FBSyxDQUFDLGdCQUFnQixDQUFDLE1BQU0sQ0FBQyxTQUFTLEVBQUUsRUFBRSxJQUFJLEVBQUUsQ0FBQyxFQUFFLEtBQUssRUFBRSxDQUFDLEVBQUUsQ0FBQyxDQUFDO1lBRWhFLElBQUksSUFBSSxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLE9BQU8sRUFBRTtnQkFDbEMsSUFBSSxDQUFDLGlCQUFpQixDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsTUFBTSxDQUFDLENBQUM7Z0JBRXJDLElBQUksSUFBSSxDQUFDLE1BQU0sQ0FBQyxTQUFTLEVBQUU7b0JBQ3ZCLE1BQU0sQ0FBQyxpQkFBaUIsQ0FBQyxFQUFFLENBQUMsS0FBSyxFQUFFLENBQUMsS0FBSyxFQUFFLE1BQU0sRUFBRSxFQUFFO3dCQUNqRCxtQ0FBbUM7d0JBQ25DLElBQUksQ0FBQyxLQUFLLENBQUMsTUFBTSxLQUFLLElBQUksQ0FBQyxJQUFJLENBQUMsTUFBTSxHQUFHLENBQUMsQ0FBQzsrQkFDcEMsQ0FBQyxNQUFNLEtBQUssSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLE1BQU0sR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxHQUFHLENBQUMsQ0FBQyxFQUFFOzRCQUM5RCxJQUFJLENBQUMsZ0JBQWdCLEVBQUUsQ0FBQzt5QkFDM0I7b0JBQ0wsQ0FBQyxDQUFDLENBQUM7aUJBQ047cUJBQU07b0JBQ0gsSUFBSSxDQUFDLGdCQUFnQixFQUFFLENBQUM7aUJBQzNCO2FBRUo7UUFDTCxDQUFDLENBQUMsQ0FBQztJQUNQLENBQUM7SUFFTyxhQUFhLENBQUMsRUFBZSxFQUFFLE9BQWUsRUFBRSxTQUEwQixFQUFFLFVBQWUsRUFBRSxZQUEwQjtRQUMzSCxJQUFJLFNBQVMsR0FBRyxVQUFVLENBQUMsU0FBUyxDQUFDLFdBQVcsQ0FBQzthQUM1QyxJQUFJLENBQUMsU0FBUyxFQUFFLENBQUMsQ0FBQyxFQUFFLEVBQUUsR0FBRyxDQUFDLENBQUMsUUFBUSxDQUFDLEdBQUcsT0FBTyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7YUFDNUQsS0FBSyxFQUFFO2FBQ1AsTUFBTSxDQUFDLE1BQU0sQ0FBQyxDQUFDO1FBQ3BCLElBQUksTUFBTSxHQUFHLENBQUMsRUFBRSxpQkFBc0IsRUFBRSxPQUFPLEdBQWtCLEVBQUUsRUFBRSxPQUFPLEdBQWtCLEVBQUUsRUFBRSxRQUFRLEdBQWtCLEVBQUUsRUFBRSxTQUFTLEdBQWtCLEVBQUUsQ0FBQztRQUU5SixTQUFTO2FBQ0osSUFBSSxDQUFDLE9BQU8sRUFBRSxDQUFDLEtBQUssRUFBRSxFQUFFLENBQUMsUUFBUSxHQUFHLE9BQU8sR0FBRyxLQUFLLEdBQUcsS0FBSyxDQUFDLEVBQUUsQ0FBQzthQUMvRCxJQUFJLENBQUMsTUFBTSxFQUFFLENBQUMsS0FBSyxFQUFFLE1BQU0sRUFBRSxFQUFFLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxjQUFjLENBQUMsS0FBSyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxFQUFFLENBQUMsQ0FBQyxLQUFLLElBQUksRUFBRSxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUM7YUFDOUcsSUFBSSxDQUFDLGNBQWMsRUFBRSxFQUFFLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQzthQUNoQyxJQUFJLENBQUMsY0FBYyxFQUFFLENBQUMsS0FBSyxFQUFFLEVBQUUsQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLENBQUM7UUFFaEQsSUFBSSxJQUFJLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxLQUFLLFFBQVEsRUFBRTtZQUNoQyxTQUFTO2lCQUNKLElBQUksQ0FBQyxPQUFPLEVBQUUsYUFBYSxDQUFDLFFBQVEsRUFBRSxZQUFZLENBQUMsS0FBSyxDQUFDLENBQUM7aUJBQzFELElBQUksQ0FBQyxHQUFHLEVBQUUsQ0FBQyxLQUFLLEVBQUUsTUFBTSxFQUFFLEVBQUU7Z0JBQ3pCLElBQUksSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsS0FBSyxTQUFTO29CQUFFLE1BQU0sR0FBRyxZQUFZLENBQUMsS0FBSyxHQUFHLE1BQU0sR0FBRyxZQUFZLENBQUMsT0FBTyxHQUFHLE1BQU0sQ0FBQztnQkFDMUcsT0FBTyxhQUFhLENBQUMsT0FBTyxFQUFFLElBQUksQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsR0FBRyxNQUFNLENBQUMsQ0FBQztZQUMvRCxDQUFDLENBQUMsQ0FBQztZQUVQLElBQUksQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLFNBQVMsRUFBRTtnQkFDeEIsU0FBUztxQkFDSixJQUFJLENBQUMsR0FBRyxFQUFFLENBQUMsS0FBSyxFQUFFLEVBQUUsQ0FBQyxhQUFhLENBQUMsT0FBTyxFQUFFLElBQUksQ0FBQyxPQUFPLENBQUMsR0FBRyxFQUFFLEtBQUssQ0FBQyxDQUFDLENBQUM7cUJBQ3RFLElBQUksQ0FBQyxRQUFRLEVBQUUsQ0FBQyxLQUFLLEVBQUUsRUFBRSxDQUFDLGFBQWEsQ0FBQyxTQUFTLEVBQUUsSUFBSSxDQUFDLE9BQU8sQ0FBQyxRQUFRLEVBQUUsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDO2FBQzNGO2lCQUFNO2dCQUNILFNBQVM7cUJBQ0osSUFBSSxDQUFDLEdBQUcsRUFBRSxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO3FCQUNwQixJQUFJLENBQUMsUUFBUSxFQUFFLENBQUMsQ0FBQyxDQUFDO2dCQUV2QixpQkFBaUIsR0FBRyxTQUFTLENBQUMsVUFBVSxFQUFFLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxrQkFBa0IsQ0FBQztxQkFDdkUsSUFBSSxDQUFDLEdBQUcsRUFBRSxDQUFDLEtBQUssRUFBRSxFQUFFLENBQUMsYUFBYSxDQUFDLE9BQU8sRUFBRSxJQUFJLENBQUMsT0FBTyxDQUFDLEdBQUcsRUFBRSxLQUFLLENBQUMsQ0FBQyxDQUFDO3FCQUN0RSxJQUFJLENBQUMsUUFBUSxFQUFFLENBQUMsS0FBSyxFQUFFLEVBQUUsQ0FBQyxhQUFhLENBQUMsU0FBUyxFQUFFLElBQUksQ0FBQyxPQUFPLENBQUMsUUFBUSxFQUFFLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQzthQUMzRjtTQUVKO2FBQU07WUFDSCxTQUFTO2lCQUNKLElBQUksQ0FBQyxRQUFRLEVBQUUsYUFBYSxDQUFDLFNBQVMsRUFBRSxZQUFZLENBQUMsS0FBSyxDQUFDLENBQUM7aUJBQzVELElBQUksQ0FBQyxHQUFHLEVBQUUsQ0FBQyxLQUFLLEVBQUUsTUFBTSxFQUFFLEVBQUU7Z0JBQ3pCLElBQUksSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsS0FBSyxTQUFTO29CQUFFLE1BQU0sR0FBRyxZQUFZLENBQUMsS0FBSyxHQUFHLE1BQU0sR0FBRyxZQUFZLENBQUMsT0FBTyxHQUFHLE1BQU0sQ0FBQztnQkFDMUcsT0FBTyxhQUFhLENBQUMsT0FBTyxFQUFFLElBQUksQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsR0FBRyxNQUFNLENBQUMsQ0FBQztZQUMvRCxDQUFDLENBQUMsQ0FBQztZQUVQLElBQUksQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLFNBQVMsRUFBRTtnQkFDeEIsU0FBUztxQkFDSixJQUFJLENBQUMsR0FBRyxFQUFFLENBQUMsS0FBSyxFQUFFLEVBQUUsQ0FBQyxhQUFhLENBQUMsT0FBTyxFQUFFLElBQUksQ0FBQyxPQUFPLENBQUMsR0FBRyxFQUFFLEtBQUssQ0FBQyxDQUFDLENBQUM7cUJBQ3RFLElBQUksQ0FBQyxPQUFPLEVBQUUsQ0FBQyxLQUFLLEVBQUUsRUFBRSxDQUFDLGFBQWEsQ0FBQyxRQUFRLEVBQUUsSUFBSSxDQUFDLE9BQU8sQ0FBQyxPQUFPLEVBQUUsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDO2FBQ3hGO2lCQUFNO2dCQUNILFNBQVM7cUJBQ0osSUFBSSxDQUFDLEdBQUcsRUFBRSxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO3FCQUNwQixJQUFJLENBQUMsT0FBTyxFQUFFLENBQUMsQ0FBQyxDQUFDO2dCQUV0QixpQkFBaUIsR0FBRyxTQUFTLENBQUMsVUFBVSxFQUFFLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxrQkFBa0IsQ0FBQztxQkFDdkUsSUFBSSxDQUFDLEdBQUcsRUFBRSxDQUFDLEtBQUssRUFBRSxFQUFFLENBQUMsYUFBYSxDQUFDLE9BQU8sRUFBRSxJQUFJLENBQUMsT0FBTyxDQUFDLEdBQUcsRUFBRSxLQUFLLENBQUMsQ0FBQyxDQUFDO3FCQUN0RSxJQUFJLENBQUMsT0FBTyxFQUFFLENBQUMsS0FBSyxFQUFFLEVBQUUsQ0FBQyxhQUFhLENBQUMsUUFBUSxFQUFFLElBQUksQ0FBQyxPQUFPLENBQUMsT0FBTyxFQUFFLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQzthQUN4RjtTQUVKO1FBRUQsT0FBTztZQUNILFNBQVMsRUFBRSxTQUFTO1lBQ3BCLGlCQUFpQixFQUFFLGlCQUFpQjtZQUNwQyxPQUFPLEVBQUUsT0FBTztZQUNoQixPQUFPLEVBQUUsT0FBTztZQUNoQixRQUFRLEVBQUUsUUFBUTtZQUNsQixTQUFTLEVBQUUsU0FBUztTQUN2QixDQUFDO1FBRUYsU0FBUyxhQUFhLENBQUMsTUFBcUIsRUFBRSxLQUFhO1lBQ3ZELE1BQU0sQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLENBQUM7WUFDbkIsT0FBTyxLQUFLLENBQUM7UUFDakIsQ0FBQztJQUNMLENBQUM7SUFFTyxPQUFPLENBQUMsS0FBcUMsRUFBRSxNQUFnQjtRQUNuRSxJQUFJLEtBQUssR0FBRyxJQUFJLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxLQUFLLEtBQUssQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQztRQUMxRSxJQUFJLE1BQU0sR0FBVyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO1FBRW5DLElBQUksS0FBSyxLQUFLLEdBQUcsSUFBSSxLQUFLLEtBQUssR0FBRyxFQUFFO1lBQ2hDLE9BQU8sSUFBSSxDQUFDLGFBQWEsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxhQUFhLENBQUMsTUFBTSxDQUFDLEdBQUcsRUFBRSxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLGFBQWEsQ0FBQyxNQUFNLENBQUMsR0FBRyxFQUFFLEtBQUssQ0FBQyxHQUFHLElBQUksQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQztTQUNySTtRQUNELElBQUksS0FBSyxLQUFLLFFBQVE7WUFBRSxPQUFPLElBQUksQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxhQUFhLENBQUMsTUFBTSxDQUFDLEdBQUcsRUFBRSxLQUFLLENBQUMsR0FBRyxLQUFLLENBQUMsR0FBRyxJQUFJLENBQUMsQ0FBQyxDQUFDLGFBQWEsQ0FBQyxNQUFNLENBQUMsR0FBRyxFQUFFLEtBQUssQ0FBQyxDQUFDLENBQUMsR0FBRyxNQUFNLENBQUM7UUFDOUksSUFBSSxLQUFLLEtBQUssT0FBTztZQUFFLE9BQU8sSUFBSSxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLGFBQWEsQ0FBQyxNQUFNLENBQUMsR0FBRyxFQUFFLEtBQUssQ0FBQyxDQUFDLEdBQUcsSUFBSSxDQUFDLENBQUMsQ0FBQyxhQUFhLENBQUMsTUFBTSxDQUFDLEdBQUcsRUFBRSxLQUFLLENBQUMsR0FBRyxLQUFLLENBQUMsQ0FBQyxHQUFHLE1BQU0sQ0FBQztRQUU3SSxxSkFBcUo7UUFDckosU0FBUyxhQUFhLENBQUMsSUFBWSxFQUFFLE1BQWM7WUFDL0MsT0FBTyxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxHQUFHLE1BQU0sQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDO1FBQ3RELENBQUM7SUFDTCxDQUFDO0lBRU8saUJBQWlCLENBQUMsRUFBZSxFQUFFLE9BQWUsRUFBRSxNQUFrQjtRQUMxRSxLQUFLLElBQUksTUFBTSxHQUFHLENBQUMsRUFBRSxNQUFNLEdBQUcsRUFBRSxDQUFDLENBQUMsQ0FBQyxNQUFNLEVBQUUsRUFBRSxNQUFNLEVBQUU7WUFDakQsSUFBSSxFQUFFLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLEtBQUssS0FBSyxJQUFJO2dCQUFFLFNBQVM7WUFFMUMsSUFBSSxLQUFLLEdBQWEsTUFBTSxDQUFDLE1BQU0sQ0FBQyxFQUFFLEVBQUUsRUFBRSxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxFQUNqRCxVQUFVLEdBQXVCO2dCQUM3QixJQUFJLEVBQUUsTUFBTSxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUM7Z0JBQzVCLElBQUksRUFBRSxNQUFNLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQztnQkFDNUIsTUFBTSxFQUFFLElBQUksQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLEtBQUssUUFBUSxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsU0FBUyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQztnQkFDdkYsS0FBSyxFQUFFLElBQUksQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLEtBQUssUUFBUSxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsUUFBUSxDQUFDLE1BQU0sQ0FBQzthQUN2RixDQUFDO1lBRU4sSUFBSSxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxNQUFNLEVBQUU7Z0JBQ2xDLElBQUksSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsS0FBSyxRQUFRLEVBQUU7b0JBQ2hDLElBQUksQ0FBQyxLQUFLLENBQUMsS0FBSyxHQUFHLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsV0FBVyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsS0FBSyxHQUFHLENBQUMsSUFBSSxJQUFJLENBQUMsU0FBUyxDQUFDLFdBQVcsQ0FBQyxFQUFFO3dCQUNyRyxVQUFVLENBQUMsSUFBSSxJQUFJLE1BQU0sQ0FBQyxTQUFTLENBQUMsTUFBTSxDQUFDLENBQUM7cUJBQy9DO29CQUNELDRDQUE0QztvQkFDNUMsSUFBSSxJQUFJLENBQUMsS0FBSzt3QkFBRSxVQUFVLENBQUMsSUFBSSxJQUFJLE1BQU0sQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUM7aUJBQ3pEO3FCQUFNO29CQUNILElBQUksQ0FBQyxLQUFLLENBQUMsS0FBSyxHQUFHLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsV0FBVyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsS0FBSyxHQUFHLENBQUMsSUFBSSxJQUFJLENBQUMsU0FBUyxDQUFDLFdBQVcsQ0FBQyxFQUFFO3dCQUNyRyxVQUFVLENBQUMsSUFBSSxJQUFJLE1BQU0sQ0FBQyxRQUFRLENBQUMsTUFBTSxDQUFDLENBQUM7cUJBQzlDO2lCQUNKO2FBQ0o7aUJBQU07Z0JBQ0gsSUFBSSxJQUFJLENBQUMsS0FBSyxFQUFFO29CQUNaLFlBQVk7b0JBQ1osOENBQThDO29CQUM5QywrREFBK0Q7b0JBQy9ELElBQUksS0FBSyxHQUFHLElBQUksQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLEtBQUssUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQztvQkFDeEQsVUFBVSxDQUFDLElBQUksSUFBSSxNQUFNLENBQUMsUUFBUSxDQUFDLEtBQUssQ0FBQyxDQUFDO2lCQUM3QzthQUNKO1lBQ0QsSUFBSSxJQUFJLENBQUMsU0FBUyxDQUFDLGVBQWU7Z0JBQUUsS0FBSyxDQUFDLEtBQUssR0FBRyxJQUFJLENBQUMsU0FBUyxDQUFDLDRCQUE0QixDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsQ0FBQztZQUUzRyxJQUFJLGNBQWMsR0FBUSxLQUFLLENBQUMsUUFBUSxDQUFDLEtBQUssRUFBRSxPQUFPLEVBQUUsVUFBVSxDQUFDLElBQUksRUFBRSxVQUFVLENBQUMsSUFBSSxDQUFDLENBQUM7WUFFM0YseUVBQXlFO1lBQ3pFLElBQUksQ0FBQyxjQUFjLENBQUMsY0FBYyxFQUFFLEVBQUUsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsS0FBSyxFQUFFLFVBQVUsQ0FBQyxDQUFDO1NBQ3ZFO0lBQ0wsQ0FBQztJQUVELGdEQUFnRDtJQUNoRCw2Q0FBNkM7SUFDckMsY0FBYyxDQUFDLGVBQWUsRUFBRSxNQUFjLEVBQUUsV0FBK0I7UUFDbkYsSUFBSSxTQUFTLEdBQVEsZUFBZSxDQUFDLE1BQU0sQ0FBQyw2QkFBNkIsQ0FBQyxDQUFDO1FBQzNFLElBQUksYUFBYSxHQUFHLElBQUksQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxhQUFhLENBQUM7UUFDM0QsSUFBSSxNQUFNLEdBQVksSUFBSSxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQztRQUN0RCxJQUFJLElBQUksR0FBVyxJQUFJLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDO1FBQ3JDLElBQUksQ0FBQyxhQUFhO1lBQUUsYUFBYSxHQUFHLElBQUksQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLEtBQUssUUFBUSxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQztRQUV0RixJQUFJLENBQUMsT0FBTyxDQUFDLDhCQUE4QixDQUFDLGVBQWUsRUFBRSxJQUFJLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxFQUFFLE1BQU0sRUFBRSxXQUFXLENBQUMsQ0FBQztRQUVyRyxnREFBZ0Q7UUFDaEQsSUFBSSxxQkFBcUIsR0FBRyxJQUFJLENBQUMsU0FBUyxDQUFDLG1CQUFtQixFQUFFLEdBQUcsV0FBVyxDQUFDLE1BQU0sQ0FBQztRQUN0RixJQUFJLHFCQUFxQixFQUFFO1lBQ3ZCLElBQUksSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsS0FBSyxLQUFLLEVBQUU7Z0JBQzdCLGFBQWEsR0FBRyxRQUFRLENBQUM7YUFDNUI7aUJBQU0sSUFBSSxNQUFNLEVBQUU7Z0JBQ2YsbUVBQW1FO2dCQUNuRSxtRkFBbUY7Z0JBQ25GLGtGQUFrRjtnQkFDbEYsYUFBYSxHQUFHLElBQUksQ0FBQyxTQUFTLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQzthQUNqRTtTQUNKO1FBRUQsSUFBSSxDQUFDLE1BQU0sRUFBRTtZQUNULElBQUksSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsS0FBSyxLQUFLLEVBQUU7Z0JBQzdCLElBQUksQ0FBQyxPQUFPLENBQUMsMEJBQTBCLENBQ25DLFNBQVMsRUFDVCxJQUFJLENBQUMsU0FBUyxDQUFDLFdBQVcsRUFDMUIsRUFBRSxJQUFJLEVBQUUsV0FBVyxDQUFDLElBQUksRUFBRSxVQUFVLEVBQUUsSUFBSSxDQUFDLEtBQUssRUFBRSxTQUFTLEVBQUUsSUFBSSxFQUFFLENBQ3RFLENBQUM7YUFDTDtpQkFBTTtnQkFDSCxJQUFJLE1BQU0sR0FBRyxFQUFFLFNBQVMsRUFBRSxJQUFJLEVBQUUsQ0FBQztnQkFDakMsSUFBSSxJQUFJLEdBQUcsV0FBVyxDQUFDLElBQUksQ0FBQyxDQUFDLDhCQUE4QjtnQkFDM0QsSUFBSSxxQkFBcUIsSUFBSSxJQUFJLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxLQUFLLFNBQVMsRUFBRTtvQkFDMUQsTUFBTSxDQUFDLFlBQVksQ0FBQyxHQUFHLFdBQVcsQ0FBQztvQkFDbkMsSUFBSSxVQUFVLEdBQVEsSUFBSSxDQUFDLFNBQVMsQ0FBQyxtQkFBbUIsQ0FBQyxhQUFhLEVBQUUsTUFBTSxDQUFDLENBQUM7b0JBQ2hGLElBQUksVUFBVTt3QkFBRSxJQUFJLElBQUksVUFBVSxHQUFHLFdBQVcsQ0FBQyxNQUFNLENBQUM7aUJBQzNEO2dCQUNELEtBQUssQ0FBQyxvQkFBb0IsQ0FBQyxTQUFTLEVBQUUsSUFBSSxFQUFFLE1BQU0sQ0FBQyxDQUFDO2FBQ3ZEO1NBQ0o7UUFHRCxJQUFJLENBQUMsT0FBTyxDQUFDLG1CQUFtQixDQUFDLGVBQWUsRUFBRSxhQUFhLENBQUMsQ0FBQztJQUNyRSxDQUFDO0lBRU8sZ0JBQWdCO1FBQ3BCLElBQUksQ0FBQyxrQkFBa0I7YUFDbEIsU0FBUyxDQUFDLHdCQUF3QixDQUFDO2FBQ25DLEtBQUssQ0FBQyxZQUFZLEVBQUUsU0FBUyxDQUFDLENBQUM7SUFDeEMsQ0FBQztJQUVPLGVBQWU7UUFDbkIsSUFBSSxJQUFJLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxLQUFLLFNBQVMsRUFBRTtZQUNqQyxnR0FBZ0c7WUFDaEcsZ0RBQWdEO1lBQ2hELElBQUksVUFBVSxHQUFHLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLElBQUksSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO1lBQzVFLE9BQU8sSUFBSSxDQUFDLE9BQU8sQ0FBQyxZQUFZLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxTQUFTLEVBQUUsRUFBRSxJQUFJLENBQUMsR0FBRyxDQUFDLHFCQUFxQixFQUFFLFVBQVUsQ0FBQyxDQUFDO1NBQ3BHO1FBQ0QsT0FBTztZQUNILEtBQUssRUFBRSxJQUFJLENBQUMsQ0FBQyxDQUFDLFNBQVMsRUFBRTtZQUN6QixPQUFPLEVBQUUsQ0FBQztTQUNiLENBQUM7SUFDTixDQUFDO0lBRU8sMEJBQTBCO1FBQzlCLElBQUksTUFBTSxHQUE4QixJQUFJLENBQUMsT0FBTyxDQUFDLGtCQUFrQixDQUFDLElBQUksQ0FBQyxTQUFTLEVBQUUsSUFBSSxDQUFDLE1BQU0sQ0FBQyxXQUFXLEVBQUUsSUFBSSxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsQ0FBQztRQUNwSSxJQUFJLE1BQU0sQ0FBQyxjQUFjLENBQUMsV0FBVyxDQUFDO1lBQUUsSUFBSSxDQUFDLFNBQVMsR0FBRyxNQUFNLENBQUMsU0FBUyxDQUFDO1FBQzFFLElBQUksTUFBTSxDQUFDLGNBQWMsQ0FBQyxPQUFPLENBQUMsRUFBRTtZQUNoQyxJQUFJLENBQUMsTUFBTSxDQUFDLEtBQUssR0FBRyxNQUFNLENBQUMsTUFBTSxDQUFDLEVBQUUsRUFBRSxJQUFJLENBQUMsTUFBTSxDQUFDLEtBQUssRUFBRSxNQUFNLENBQUMsS0FBSyxDQUFDLENBQUM7U0FDMUU7SUFDTCxDQUFDOzs7WUExVkosU0FBUyxTQUFDO2dCQUNQLFFBQVEsRUFBRSxjQUFjO2dCQUN4QixRQUFRLEVBQUU7Ozs7S0FJVDtnQkFDRCxhQUFhLEVBQUUsaUJBQWlCLENBQUMsSUFBSTtnQkFDckMsU0FBUyxFQUFFLENBQUMsV0FBVyxFQUFFLFlBQVksRUFBRSxhQUFhLENBQUM7Z0JBQ3JELElBQUksRUFBRTtvQkFDRixPQUFPLEVBQUUsZUFBZTtpQkFDM0I7YUFDSjs7O1lBbEJRLFdBQVc7WUFHWCxZQUFZO1lBQ1osYUFBYTs7O3NCQXNCakIsS0FBSyxTQUFDLE1BQU07d0JBQ1osS0FBSyxTQUFDLFFBQVE7cUJBQ2QsS0FBSztrQkFDTCxLQUFLIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHtcclxuICAgIENvbXBvbmVudCxcclxuICAgIFZpZXdFbmNhcHN1bGF0aW9uLFxyXG4gICAgSW5wdXQsXHJcbiAgICBPbkluaXQsXHJcbiAgICBPbkNoYW5nZXMsXHJcbiAgICBTaW1wbGVDaGFuZ2VzLFxyXG4gICAgT25EZXN0cm95XHJcbn0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XHJcbmltcG9ydCB7IEtkQ2hhcnRCYXNlQ2xhc3MgfSBmcm9tICcuLi9rZC1hbmd1bGFyLWNoYXJ0LWJhc2UtY2xhc3MnO1xyXG5pbXBvcnQgeyBLZENoYXJ0c1N2YyB9IGZyb20gJy4uL2tkLWFuZ3VsYXItY2hhcnRzLXN2Yyc7XHJcbmltcG9ydCB7IElEM0RhdGEsIElDaGFydENvbmZpZywgSUQzRGF0YURhdGEsIElEM1lEYXRhLCBJTGVnZW5kRGF0YSB9IGZyb20gJy4uL2tkLWFuZ3VsYXItY2hhcnRzLWludGVyZmFjZSc7XHJcbmltcG9ydCB7IElSZWN0UG9zSW5mbywgSVJlY3RHcm91cCwgSUJhclJlY3REaW1lbnNpb25zLCBJTmVnYXRpdmVTdGFja0xvZ2ljUmV0dXJuIH0gZnJvbSAnLi9rZC1hbmd1bGFyLWJhci1jaGFydC1pbnRlcmZhY2UnO1xyXG5pbXBvcnQgeyBLZERvbUVsZW1TdmMgfSBmcm9tICcuLi8uLi9rZC1jb21tb24vaW5kZXgnO1xyXG5pbXBvcnQgeyBLZEJhckNoYXJ0U3ZjIH0gZnJvbSAnLi9rZC1hbmd1bGFyLWJhci1jaGFydC1zdmMnO1xyXG5cclxuQENvbXBvbmVudCh7XHJcbiAgICBzZWxlY3RvcjogJ2tkLWJhci1jaGFydCcsXHJcbiAgICB0ZW1wbGF0ZTogYFxyXG4gICAgICAgIDxkaXYgKm5nSWY9XCJjaGFydFR5cGVbMV0gPT09ICcxMDAnICYmIGhhdmVOZWdhdGl2ZVwiIGNsYXNzPVwia2R4LWNoYXJ0cy1lcnJvci1tc2dcIj5cclxuICAgICAgICAgICAge3tlcnJvck1zZ319XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICBgLFxyXG4gICAgZW5jYXBzdWxhdGlvbjogVmlld0VuY2Fwc3VsYXRpb24uTm9uZSxcclxuICAgIHByb3ZpZGVyczogW0tkQ2hhcnRzU3ZjLCBLZERvbUVsZW1TdmMsIEtkQmFyQ2hhcnRTdmNdLFxyXG4gICAgaG9zdDoge1xyXG4gICAgICAgICdjbGFzcyc6ICdrZHgtYmFyLWNoYXJ0JyxcclxuICAgIH1cclxufSlcclxuXHJcbmV4cG9ydCBjbGFzcyBLZEJhckNoYXJ0IGV4dGVuZHMgS2RDaGFydEJhc2VDbGFzcyBpbXBsZW1lbnRzIE9uSW5pdCwgT25DaGFuZ2VzLCBPbkRlc3Ryb3kge1xyXG5cclxuICAgIHByaXZhdGUgX2JhckdyYXBoOiBhbnk7XHJcbiAgICBwcml2YXRlIF9yZXNpemVUaW1lb3V0OiBhbnk7XHJcbiAgICBwcml2YXRlIF9pc1N0YXJ0QXRTdW06IGJvb2xlYW4gPSBmYWxzZTtcclxuXHJcbiAgICBASW5wdXQoJ2RhdGEnKSBhbGxEYXRhOiBJRDNEYXRhO1xyXG4gICAgQElucHV0KCdjb25maWcnKSBiYXJDb25maWc6IElDaGFydENvbmZpZztcclxuICAgIEBJbnB1dCgpIGxlZ2VuZDogeyBba2V5OiBzdHJpbmddOiBJTGVnZW5kRGF0YSB9O1xyXG4gICAgQElucHV0KCkgYXBpOiBhbnk7XHJcblxyXG4gICAgY29uc3RydWN0b3IoXHJcbiAgICAgICAgcHVibGljIF9jaGFydFN2YzogS2RDaGFydHNTdmMsXHJcbiAgICAgICAgcHVibGljIF9kb21TdmM6IEtkRG9tRWxlbVN2YyxcclxuICAgICAgICBwdWJsaWMgX2JhclN2YzogS2RCYXJDaGFydFN2Y1xyXG4gICAgKSB7XHJcbiAgICAgICAgc3VwZXIoX2NoYXJ0U3ZjLCBfZG9tU3ZjKTtcclxuICAgIH1cclxuXHJcbiAgICBuZ09uSW5pdCgpOiB2b2lkIHtcclxuICAgICAgICB0aGlzLl9yZWRyYXdDaGFydCh0cnVlLCB7IGRhdGE6IHRoaXMuYWxsRGF0YSwgY29uZmlnOiB0aGlzLmJhckNvbmZpZyB9KTtcclxuICAgICAgICB0aGlzLmFwaS5sZWdlbmRDbGljayA9IChfZGF0YTogYW55KSA9PiB7XHJcbiAgICAgICAgICAgIHRoaXMuX3JlZHJhd0NoYXJ0KGZhbHNlLCB7IGRhdGE6IF9kYXRhIH0pO1xyXG4gICAgICAgIH07XHJcbiAgICAgICAgdGhpcy5hcGkucmVkcmF3ID0gKCkgPT4ge1xyXG4gICAgICAgICAgICBjbGVhclRpbWVvdXQodGhpcy5fcmVzaXplVGltZW91dCk7XHJcbiAgICAgICAgICAgIHRoaXMuX3Jlc2l6ZVRpbWVvdXQgPSBzZXRUaW1lb3V0KCgpID0+IHtcclxuICAgICAgICAgICAgICAgIHRoaXMuX3JlZHJhd0NoYXJ0KGZhbHNlLCB7fSk7XHJcbiAgICAgICAgICAgIH0pO1xyXG4gICAgICAgIH07XHJcbiAgICB9XHJcblxyXG4gICAgbmdPbkNoYW5nZXMoX3NpbXBsZUNoYW5nZXM6IFNpbXBsZUNoYW5nZXMpOiB2b2lkIHtcclxuICAgICAgICBpZiAoX3NpbXBsZUNoYW5nZXMuaGFzT3duUHJvcGVydHkoJ2FsbERhdGEnKSAmJiAhX3NpbXBsZUNoYW5nZXNbJ2FsbERhdGEnXS5maXJzdENoYW5nZSkge1xyXG4gICAgICAgICAgICB0aGlzLl9yZWRyYXdDaGFydChmYWxzZSwgeyBkYXRhOiBfc2ltcGxlQ2hhbmdlcy5hbGxEYXRhLmN1cnJlbnRWYWx1ZSB9KTtcclxuICAgICAgICB9XHJcbiAgICAgICAgaWYgKF9zaW1wbGVDaGFuZ2VzLmhhc093blByb3BlcnR5KCdiYXJDb25maWcnKSAmJiAhX3NpbXBsZUNoYW5nZXNbJ2JhckNvbmZpZyddLmZpcnN0Q2hhbmdlKSB7XHJcbiAgICAgICAgICAgIHRoaXMuX3JlZHJhd0NoYXJ0KGZhbHNlLCB7IGNvbmZpZzogX3NpbXBsZUNoYW5nZXMuYmFyQ29uZmlnLmN1cnJlbnRWYWx1ZSB9KTtcclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgbmdPbkRlc3Ryb3koKTogdm9pZCB7XHJcbiAgICAgICAgdGhpcy5fcmVzZXRDaGFydCgpO1xyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX3JlZHJhd0NoYXJ0KGlzRmlyc3RDaGFuZ2U6IGJvb2xlYW4sIF9jaGFuZ2VzOiB7IGRhdGE/OiBJRDNEYXRhLCBjb25maWc/OiBJQ2hhcnRDb25maWcgfSA9IHt9KSB7XHJcbiAgICAgICAgaWYgKCFpc0ZpcnN0Q2hhbmdlKSB7XHJcbiAgICAgICAgICAgIHRoaXMuX3Jlc2V0Q2hhcnQoKTtcclxuICAgICAgICB9XHJcbiAgICAgICAgdGhpcy5sZWdlbmREYXRhID0gT2JqZWN0LmFzc2lnbih7fSwgdGhpcy5sZWdlbmQpO1xyXG4gICAgICAgIGlmIChfY2hhbmdlcy5oYXNPd25Qcm9wZXJ0eSgnZGF0YScpKSB0aGlzLl9zZXREYXRhKF9jaGFuZ2VzLmRhdGEpO1xyXG4gICAgICAgIGlmIChfY2hhbmdlcy5oYXNPd25Qcm9wZXJ0eSgnY29uZmlnJykpIHRoaXMuX3NldENvbmZpZyhfY2hhbmdlcy5jb25maWcpO1xyXG4gICAgICAgIHN1cGVyLmNoYXJ0VGltZW91dCgoKSA9PiB0aGlzLl9zZXRDaGFydCgpKTtcclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF9zZXREYXRhKF9kYXRhOiBJRDNEYXRhKTogdm9pZCB7XHJcbiAgICAgICAgdGhpcy5kYXRhID0gT2JqZWN0LmFzc2lnbihbXSwgX2RhdGEuZGF0YSk7XHJcbiAgICAgICAgLy8gc2F2aW5nIG9yaWdpbmFsIGRhdGEgc29tZXdoZXJlIGJlZm9yZSB0cmltbWluZyB0aGlzLmRhdGEuIHdoZW4gbm8gdHJpbW1pbmcsIHRoZW4gdGhpcy5kYXRhIHdpbGwganVzdCBiZSBpbml0RGF0YVxyXG4gICAgICAgIHRoaXMuaW5pdERhdGEgPSBKU09OLnBhcnNlKEpTT04uc3RyaW5naWZ5KHRoaXMuZGF0YSkpO1xyXG5cclxuICAgICAgICB0aGlzLmNoYXJ0Q2F0ZWdvcnkgPSAnYmFyJztcclxuICAgICAgICB0aGlzLmNoYXJ0VHlwZSA9IF9kYXRhLmxheW91dC5zcGxpdCgnLScpO1xyXG4gICAgICAgIHRoaXMuX2NoYXJ0U3ZjLmlzSW52ZXJ0ID0gdGhpcy5jaGFydFR5cGVbMF0gPT09ICdiYXInO1xyXG4gICAgICAgIHRoaXMuYmFyLmlzSW52ZXJ0ID0gdGhpcy5jaGFydFR5cGVbMF0gPT09ICdiYXInO1xyXG4gICAgICAgIHRoaXMuX2NoYXJ0U3ZjLmlzTmVnYXRpdmVTdGFjayA9IHRoaXMuY2hhcnRUeXBlWzFdID09PSAnc3RhY2snICYmIHRoaXMuY2hhcnRUeXBlWzJdID09PSAnbmVnYXRpdmUnO1xyXG5cclxuICAgICAgICAvLyByYW5nZSBhbmQgbmVnYXRpdmUgZmxhZyBjYWxjdWxhdGVkIGJ5IGtkQ2hhcnQsIHVzZWQgaW4gZG9tYWluLCByZWNhbGN1bGF0ZWQgd2hlbiBjaGFuZ2UgZ3JhcGggdHlwZSBhbmQgbGVnZW5kXHJcbiAgICAgICAgdGhpcy5kYXRhUmFuZ2UgPSBfZGF0YS5yYW5nZTtcclxuICAgICAgICB0aGlzLmhhdmVOZWdhdGl2ZSA9IF9kYXRhLmhhdmVOZWdhdGl2ZTtcclxuICAgICAgICB0aGlzLl9iYXJTdmMub3JpZ2luYWxEYXRhUmFuZ2UgPSBfZGF0YS5yYW5nZTtcclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF9zZXRDb25maWcoX2NvbmZpZzogSUNoYXJ0Q29uZmlnKTogdm9pZCB7XHJcbiAgICAgICAgdGhpcy5jb25maWcgPSBPYmplY3QuYXNzaWduKHt9LCBfY29uZmlnKTtcclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF9zZXRDaGFydCgpOiB2b2lkIHtcclxuICAgICAgICBpZiAodGhpcy5jaGFydFR5cGVbMV0gPT09ICcxMDAnICYmIHRoaXMuaGF2ZU5lZ2F0aXZlKSByZXR1cm47XHJcbiAgICAgICAgaWYgKHRoaXMuX2NoYXJ0U3ZjLmlzTmVnYXRpdmVTdGFjaykgdGhpcy5uZWdhdGl2ZVN0YWNrU3ltbWV0cnlMb2dpYygpO1xyXG4gICAgICAgIHN1cGVyLnNldFN2ZygpO1xyXG4gICAgICAgIHN1cGVyLnNldERvbWFpbignYmFuZCcpO1xyXG4gICAgICAgIHRoaXMuX2RyYXdDaGFydCgpO1xyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX3Jlc2V0Q2hhcnQoKTogdm9pZCB7XHJcbiAgICAgICAgc3VwZXIucmVtb3ZlQ2hhcnQoKTtcclxuICAgICAgICBpZiAodGhpcy5fYmFyR3JhcGgpIHtcclxuICAgICAgICAgICAgdGhpcy5fYmFyR3JhcGgucmVtb3ZlKCk7XHJcbiAgICAgICAgICAgIHRoaXMuX2JhckdyYXBoID0gbnVsbDtcclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfZHJhd0NoYXJ0Q29udGFpbmVyKCk6IHZvaWQge1xyXG4gICAgICAgIHRoaXMuX2JhckdyYXBoID0gdGhpcy5ncmFwaC5hcHBlbmQoJ2cnKS5hdHRyKCdjbGFzcycsICdiYXItZ3JhcGgtY29udGFpbmVyJyk7XHJcbiAgICAgICAgdGhpcy5fYmFyR3JhcGguYXR0cignY2xpcC1wYXRoJywgJ3VybCgja2QtY2hhcnRzLWNsaXAtcGF0aC0nICsgdGhpcy5jb25maWcuaWQgKyAnKScpO1xyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX2RyYXdDaGFydCgpOiB2b2lkIHtcclxuICAgICAgICBpZiAoIXRoaXMuX2JhckdyYXBoKSB0aGlzLl9kcmF3Q2hhcnRDb250YWluZXIoKTtcclxuXHJcbiAgICAgICAgdGhpcy5faXNTdGFydEF0U3VtID0gdGhpcy5iYXIuaXNJbnZlcnQgPT09IHRoaXMuX2NoYXJ0U3ZjLmlzWVJldmVyc2VkO1xyXG5cclxuICAgICAgICBsZXQgcmVjdFBvc0luZm86IHsgd2lkdGg6IG51bWJlciwgcGFkZGluZzogbnVtYmVyIH0gPSB0aGlzLl9nZXRSZWN0UG9zSW5mbygpO1xyXG5cclxuICAgICAgICB0aGlzLmRhdGEuZm9yRWFjaCgoZDogSUQzRGF0YURhdGEsIGk6IG51bWJlcikgPT4ge1xyXG4gICAgICAgICAgICBsZXQgZ3JvdXBzOiBJUmVjdEdyb3VwID0gdGhpcy5fc2V0UmVjdEdyb3VwKGQsIGksIGQueSwgdGhpcy5fYmFyR3JhcGgsIHJlY3RQb3NJbmZvKTtcclxuXHJcbiAgICAgICAgICAgIHN1cGVyLl9pbml0TW91c2VFdmVudHMoZ3JvdXBzLnJlY3RHcm91cCwgeyBkYXRhOiBkLCBpbmRleDogaSB9KTtcclxuXHJcbiAgICAgICAgICAgIGlmICh0aGlzLmNvbmZpZy5jaGFydC5sYWJlbHMuZW5hYmxlZCkge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5fc2V0QmFyQ2hhcnRMYWJlbChkLCBpLCBncm91cHMpO1xyXG5cclxuICAgICAgICAgICAgICAgIGlmICh0aGlzLmNvbmZpZy5hbmltYXRpb24pIHtcclxuICAgICAgICAgICAgICAgICAgICBncm91cHMucmVjdEdyb3VwVHJhbnNpdGUub24oJ2VuZCcsICh5RGF0YSwgeUluZGV4KSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC8vIHdoZW4gdGhlIGxhc3QgcmVjdCB0cmFuc2l0ZSBlbmRzXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGlmICgoeURhdGEueEluZGV4ID09PSB0aGlzLmRhdGEubGVuZ3RoIC0gMSlcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICYmICh5SW5kZXggPT09IHRoaXMuZGF0YVt0aGlzLmRhdGEubGVuZ3RoIC0gMV0ueS5sZW5ndGggLSAxKSkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5fZGlzcGxheUFsbExhYmVsKCk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5fZGlzcGxheUFsbExhYmVsKCk7XHJcbiAgICAgICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfSk7XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfc2V0UmVjdEdyb3VwKF9kOiBJRDNEYXRhRGF0YSwgX3hJbmRleDogbnVtYmVyLCBfeURhdGFBcnI6IEFycmF5PElEM1lEYXRhPiwgX2NvbnRhaW5lcjogYW55LCBfcmVjdFBvc0luZm86IElSZWN0UG9zSW5mbyk6IElSZWN0R3JvdXAge1xyXG4gICAgICAgIGxldCByZWN0R3JvdXAgPSBfY29udGFpbmVyLnNlbGVjdEFsbCgncmVjdEdyb3VwJylcclxuICAgICAgICAgICAgLmRhdGEoX3lEYXRhQXJyLCAoZCkgPT4geyBkWyd4SW5kZXgnXSA9IF94SW5kZXg7IHJldHVybiBkOyB9KVxyXG4gICAgICAgICAgICAuZW50ZXIoKVxyXG4gICAgICAgICAgICAuYXBwZW5kKCdyZWN0Jyk7XHJcbiAgICAgICAgbGV0IG9mZnNldCA9IDAsIHJlY3RHcm91cFRyYW5zaXRlOiBhbnksIHhQb3NBcnI6IEFycmF5PG51bWJlcj4gPSBbXSwgeVBvc0FycjogQXJyYXk8bnVtYmVyPiA9IFtdLCB3aWR0aEFycjogQXJyYXk8bnVtYmVyPiA9IFtdLCBoZWlnaHRBcnI6IEFycmF5PG51bWJlcj4gPSBbXTtcclxuXHJcbiAgICAgICAgcmVjdEdyb3VwXHJcbiAgICAgICAgICAgIC5hdHRyKCdjbGFzcycsICh5RGF0YSkgPT4gJ2JhciB4LScgKyBfeEluZGV4ICsgJyB5LScgKyB5RGF0YS5pZClcclxuICAgICAgICAgICAgLmF0dHIoJ2ZpbGwnLCAoeURhdGEsIHlJbmRleCkgPT4gdGhpcy5sZWdlbmQuaGFzT3duUHJvcGVydHkoeURhdGEuaWQpID8gdGhpcy5sZWdlbmRbeURhdGEuaWRdLmNvbG9yIHx8ICcnIDogJycpXHJcbiAgICAgICAgICAgIC5hdHRyKCdhcmlhLXgtdmFsdWUnLCBfZC54LnZhbHVlKVxyXG4gICAgICAgICAgICAuYXR0cignYXJpYS15LXZhbHVlJywgKHlEYXRhKSA9PiB5RGF0YS5zdW0pO1xyXG5cclxuICAgICAgICBpZiAodGhpcy5jaGFydFR5cGVbMF0gPT09ICdjb2x1bW4nKSB7XHJcbiAgICAgICAgICAgIHJlY3RHcm91cFxyXG4gICAgICAgICAgICAgICAgLmF0dHIoJ3dpZHRoJywgcHVzaEFuZFJldHVybih3aWR0aEFyciwgX3JlY3RQb3NJbmZvLndpZHRoKSlcclxuICAgICAgICAgICAgICAgIC5hdHRyKCd4JywgKHlEYXRhLCB5SW5kZXgpID0+IHtcclxuICAgICAgICAgICAgICAgICAgICBpZiAodGhpcy5jaGFydFR5cGVbMV0gPT09ICdjbHVzdGVyJykgb2Zmc2V0ID0gX3JlY3RQb3NJbmZvLndpZHRoICogeUluZGV4ICsgX3JlY3RQb3NJbmZvLnBhZGRpbmcgKiB5SW5kZXg7XHJcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIHB1c2hBbmRSZXR1cm4oeFBvc0FyciwgdGhpcy54KF9kLngudmFsdWUpICsgb2Zmc2V0KTtcclxuICAgICAgICAgICAgICAgIH0pO1xyXG5cclxuICAgICAgICAgICAgaWYgKCF0aGlzLmNvbmZpZy5hbmltYXRpb24pIHtcclxuICAgICAgICAgICAgICAgIHJlY3RHcm91cFxyXG4gICAgICAgICAgICAgICAgICAgIC5hdHRyKCd5JywgKHlEYXRhKSA9PiBwdXNoQW5kUmV0dXJuKHlQb3NBcnIsIHRoaXMuX2dldFZhbCgneScsIHlEYXRhKSkpXHJcbiAgICAgICAgICAgICAgICAgICAgLmF0dHIoJ2hlaWdodCcsICh5RGF0YSkgPT4gcHVzaEFuZFJldHVybihoZWlnaHRBcnIsIHRoaXMuX2dldFZhbCgnaGVpZ2h0JywgeURhdGEpKSk7XHJcbiAgICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgICAgICByZWN0R3JvdXBcclxuICAgICAgICAgICAgICAgICAgICAuYXR0cigneScsIHRoaXMueSgwKSlcclxuICAgICAgICAgICAgICAgICAgICAuYXR0cignaGVpZ2h0JywgMCk7XHJcblxyXG4gICAgICAgICAgICAgICAgcmVjdEdyb3VwVHJhbnNpdGUgPSByZWN0R3JvdXAudHJhbnNpdGlvbigpLmR1cmF0aW9uKHRoaXMubGVuZ3RoT2ZUcmFuc2l0aW9uKVxyXG4gICAgICAgICAgICAgICAgICAgIC5hdHRyKCd5JywgKHlEYXRhKSA9PiBwdXNoQW5kUmV0dXJuKHlQb3NBcnIsIHRoaXMuX2dldFZhbCgneScsIHlEYXRhKSkpXHJcbiAgICAgICAgICAgICAgICAgICAgLmF0dHIoJ2hlaWdodCcsICh5RGF0YSkgPT4gcHVzaEFuZFJldHVybihoZWlnaHRBcnIsIHRoaXMuX2dldFZhbCgnaGVpZ2h0JywgeURhdGEpKSk7XHJcbiAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgcmVjdEdyb3VwXHJcbiAgICAgICAgICAgICAgICAuYXR0cignaGVpZ2h0JywgcHVzaEFuZFJldHVybihoZWlnaHRBcnIsIF9yZWN0UG9zSW5mby53aWR0aCkpXHJcbiAgICAgICAgICAgICAgICAuYXR0cigneScsICh5RGF0YSwgeUluZGV4KSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKHRoaXMuY2hhcnRUeXBlWzFdID09PSAnY2x1c3RlcicpIG9mZnNldCA9IF9yZWN0UG9zSW5mby53aWR0aCAqIHlJbmRleCArIF9yZWN0UG9zSW5mby5wYWRkaW5nICogeUluZGV4O1xyXG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBwdXNoQW5kUmV0dXJuKHlQb3NBcnIsIHRoaXMueChfZC54LnZhbHVlKSArIG9mZnNldCk7XHJcbiAgICAgICAgICAgICAgICB9KTtcclxuXHJcbiAgICAgICAgICAgIGlmICghdGhpcy5jb25maWcuYW5pbWF0aW9uKSB7XHJcbiAgICAgICAgICAgICAgICByZWN0R3JvdXBcclxuICAgICAgICAgICAgICAgICAgICAuYXR0cigneCcsICh5RGF0YSkgPT4gcHVzaEFuZFJldHVybih4UG9zQXJyLCB0aGlzLl9nZXRWYWwoJ3gnLCB5RGF0YSkpKVxyXG4gICAgICAgICAgICAgICAgICAgIC5hdHRyKCd3aWR0aCcsICh5RGF0YSkgPT4gcHVzaEFuZFJldHVybih3aWR0aEFyciwgdGhpcy5fZ2V0VmFsKCd3aWR0aCcsIHlEYXRhKSkpO1xyXG4gICAgICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgcmVjdEdyb3VwXHJcbiAgICAgICAgICAgICAgICAgICAgLmF0dHIoJ3gnLCB0aGlzLnkoMCkpXHJcbiAgICAgICAgICAgICAgICAgICAgLmF0dHIoJ3dpZHRoJywgMCk7XHJcblxyXG4gICAgICAgICAgICAgICAgcmVjdEdyb3VwVHJhbnNpdGUgPSByZWN0R3JvdXAudHJhbnNpdGlvbigpLmR1cmF0aW9uKHRoaXMubGVuZ3RoT2ZUcmFuc2l0aW9uKVxyXG4gICAgICAgICAgICAgICAgICAgIC5hdHRyKCd4JywgKHlEYXRhKSA9PiBwdXNoQW5kUmV0dXJuKHhQb3NBcnIsIHRoaXMuX2dldFZhbCgneCcsIHlEYXRhKSkpXHJcbiAgICAgICAgICAgICAgICAgICAgLmF0dHIoJ3dpZHRoJywgKHlEYXRhKSA9PiBwdXNoQW5kUmV0dXJuKHdpZHRoQXJyLCB0aGlzLl9nZXRWYWwoJ3dpZHRoJywgeURhdGEpKSk7XHJcbiAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICByZXR1cm4ge1xyXG4gICAgICAgICAgICByZWN0R3JvdXA6IHJlY3RHcm91cCxcclxuICAgICAgICAgICAgcmVjdEdyb3VwVHJhbnNpdGU6IHJlY3RHcm91cFRyYW5zaXRlLFxyXG4gICAgICAgICAgICB4UG9zQXJyOiB4UG9zQXJyLFxyXG4gICAgICAgICAgICB5UG9zQXJyOiB5UG9zQXJyLFxyXG4gICAgICAgICAgICB3aWR0aEFycjogd2lkdGhBcnIsXHJcbiAgICAgICAgICAgIGhlaWdodEFycjogaGVpZ2h0QXJyXHJcbiAgICAgICAgfTtcclxuXHJcbiAgICAgICAgZnVuY3Rpb24gcHVzaEFuZFJldHVybih0YXJnZXQ6IEFycmF5PG51bWJlcj4sIHZhbHVlOiBudW1iZXIpOiBudW1iZXIge1xyXG4gICAgICAgICAgICB0YXJnZXQucHVzaCh2YWx1ZSk7XHJcbiAgICAgICAgICAgIHJldHVybiB2YWx1ZTtcclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfZ2V0VmFsKF90eXBlOiAneCcgfCAneScgfCAnaGVpZ2h0JyB8ICd3aWR0aCcsIF95RGF0YTogSUQzWURhdGEpOiBudW1iZXIge1xyXG4gICAgICAgIGxldCB2YWx1ZSA9IHRoaXMuY2hhcnRUeXBlWzFdID09PSAnMTAwJyA/IF95RGF0YS5yZW5kZXJWYWwgOiBfeURhdGEudmFsdWU7XHJcbiAgICAgICAgbGV0IG9mZnNldDogbnVtYmVyID0gdmFsdWUgPyAxIDogMDtcclxuXHJcbiAgICAgICAgaWYgKF90eXBlID09PSAneCcgfHwgX3R5cGUgPT09ICd5Jykge1xyXG4gICAgICAgICAgICByZXR1cm4gdGhpcy5faXNTdGFydEF0U3VtID8gdGhpcy55KG5lZ2F0aXZlUmVjYWwoX3lEYXRhLnN1bSwgdmFsdWUpKSA6IHRoaXMueShuZWdhdGl2ZVJlY2FsKF95RGF0YS5zdW0sIHZhbHVlKSAtIE1hdGguYWJzKHZhbHVlKSk7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGlmIChfdHlwZSA9PT0gJ2hlaWdodCcpIHJldHVybiBNYXRoLmFicyh0aGlzLnkobmVnYXRpdmVSZWNhbChfeURhdGEuc3VtLCB2YWx1ZSkgLSB2YWx1ZSkgLSB0aGlzLnkobmVnYXRpdmVSZWNhbChfeURhdGEuc3VtLCB2YWx1ZSkpKSArIG9mZnNldDtcclxuICAgICAgICBpZiAoX3R5cGUgPT09ICd3aWR0aCcpIHJldHVybiBNYXRoLmFicyh0aGlzLnkobmVnYXRpdmVSZWNhbChfeURhdGEuc3VtLCB2YWx1ZSkpIC0gdGhpcy55KG5lZ2F0aXZlUmVjYWwoX3lEYXRhLnN1bSwgdmFsdWUpIC0gdmFsdWUpKSArIG9mZnNldDtcclxuXHJcbiAgICAgICAgLy8gcmVuZGVyaW5nIHJlY3QgZm9yIG5lZ2F0aXZlIHVzZXMgdmFsdWVzIGxlc3NlciBieSBvbmUgaW5kZXguIGVnOiBmaXJzdCB2YWx1ZSA9IC0yLCBzdW0gPSAtMiwgcmVuZGVycyAwLi4uLiBzZWNvbmQgdmFsdWUgPSAtNCwgc3VtID0gLTYsIHJlbmRlcnMgLTJcclxuICAgICAgICBmdW5jdGlvbiBuZWdhdGl2ZVJlY2FsKF9zdW06IG51bWJlciwgX3ZhbHVlOiBudW1iZXIpOiBudW1iZXIge1xyXG4gICAgICAgICAgICByZXR1cm4gTWF0aC5zaWduKF9zdW0pIDwgMCA/IF9zdW0gLSBfdmFsdWUgOiBfc3VtO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF9zZXRCYXJDaGFydExhYmVsKF9kOiBJRDNEYXRhRGF0YSwgX3hJbmRleDogbnVtYmVyLCBfZ3JvdXA6IElSZWN0R3JvdXApOiB2b2lkIHtcclxuICAgICAgICBmb3IgKGxldCB5SW5kZXggPSAwOyB5SW5kZXggPCBfZC55Lmxlbmd0aDsgKyt5SW5kZXgpIHtcclxuICAgICAgICAgICAgaWYgKF9kLnlbeUluZGV4XS52YWx1ZSA9PT0gbnVsbCkgY29udGludWU7XHJcblxyXG4gICAgICAgICAgICBsZXQgeURhdGE6IElEM1lEYXRhID0gT2JqZWN0LmFzc2lnbih7fSwgX2QueVt5SW5kZXhdKSxcclxuICAgICAgICAgICAgICAgIGRpbWVuc2lvbnM6IElCYXJSZWN0RGltZW5zaW9ucyA9IHtcclxuICAgICAgICAgICAgICAgICAgICB5UG9zOiBfZ3JvdXAueVBvc0Fyclt5SW5kZXhdLFxyXG4gICAgICAgICAgICAgICAgICAgIHhQb3M6IF9ncm91cC54UG9zQXJyW3lJbmRleF0sXHJcbiAgICAgICAgICAgICAgICAgICAgaGVpZ2h0OiB0aGlzLmNoYXJ0VHlwZVswXSA9PT0gJ2NvbHVtbicgPyBfZ3JvdXAuaGVpZ2h0QXJyW3lJbmRleF0gOiBfZ3JvdXAuaGVpZ2h0QXJyWzBdLFxyXG4gICAgICAgICAgICAgICAgICAgIHdpZHRoOiB0aGlzLmNoYXJ0VHlwZVswXSA9PT0gJ2NvbHVtbicgPyBfZ3JvdXAud2lkdGhBcnJbMF0gOiBfZ3JvdXAud2lkdGhBcnJbeUluZGV4XVxyXG4gICAgICAgICAgICAgICAgfTtcclxuXHJcbiAgICAgICAgICAgIGlmICghdGhpcy5jb25maWcuY2hhcnQubGFiZWxzLmluc2lkZSkge1xyXG4gICAgICAgICAgICAgICAgaWYgKHRoaXMuY2hhcnRUeXBlWzBdID09PSAnY29sdW1uJykge1xyXG4gICAgICAgICAgICAgICAgICAgIGlmICgoeURhdGEudmFsdWUgPCAwICYmICF0aGlzLl9jaGFydFN2Yy5pc1lSZXZlcnNlZCkgfHwgKHlEYXRhLnZhbHVlID4gMCAmJiB0aGlzLl9jaGFydFN2Yy5pc1lSZXZlcnNlZCkpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgZGltZW5zaW9ucy55UG9zICs9IF9ncm91cC5oZWlnaHRBcnJbeUluZGV4XTtcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgLy8gd2hlbiBydGwsIGRpdiBzdGFydHMgYXQgdG9wIHJpZ2h0IG9mIHJlY3RcclxuICAgICAgICAgICAgICAgICAgICBpZiAodGhpcy5pc1J0bCkgZGltZW5zaW9ucy54UG9zICs9IF9ncm91cC53aWR0aEFyclswXTtcclxuICAgICAgICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKCh5RGF0YS52YWx1ZSA+IDAgJiYgIXRoaXMuX2NoYXJ0U3ZjLmlzWVJldmVyc2VkKSB8fCAoeURhdGEudmFsdWUgPCAwICYmIHRoaXMuX2NoYXJ0U3ZjLmlzWVJldmVyc2VkKSkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBkaW1lbnNpb25zLnhQb3MgKz0gX2dyb3VwLndpZHRoQXJyW3lJbmRleF07XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgaWYgKHRoaXMuaXNSdGwpIHtcclxuICAgICAgICAgICAgICAgICAgICAvLyB3aGVuIHJ0bCxcclxuICAgICAgICAgICAgICAgICAgICAvLyBmb3IgQ29sdW1uLCBkaXYgc3RhcnRzIGF0IHRvcCByaWdodCBvZiByZWN0XHJcbiAgICAgICAgICAgICAgICAgICAgLy8gZm9yIEJhciwgZGl2IHN0YXJ0IGF0IGVuZCBvZiByZWN0IGFuZCB0YWtlIHRoZSB3aWR0aCBvZiBiYXJzXHJcbiAgICAgICAgICAgICAgICAgICAgbGV0IGluZGV4ID0gdGhpcy5jaGFydFR5cGVbMF0gPT09ICdjb2x1bW4nID8gMCA6IHlJbmRleDtcclxuICAgICAgICAgICAgICAgICAgICBkaW1lbnNpb25zLnhQb3MgKz0gX2dyb3VwLndpZHRoQXJyW2luZGV4XTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBpZiAodGhpcy5fY2hhcnRTdmMuaXNOZWdhdGl2ZVN0YWNrKSB5RGF0YS52YWx1ZSA9IHRoaXMuX2NoYXJ0U3ZjLmNoZWNrQW5kUmV0dXJuTGFiZWxzUG9zaXRpdmUoeURhdGEudmFsdWUpO1xyXG5cclxuICAgICAgICAgICAgbGV0IGxhYmVsQ29udGFpbmVyOiBhbnkgPSBzdXBlci5zZXRMYWJlbCh5RGF0YSwgX3hJbmRleCwgZGltZW5zaW9ucy54UG9zLCBkaW1lbnNpb25zLnlQb3MpO1xyXG5cclxuICAgICAgICAgICAgLy8gdmFsdWUgaGVyZSBpcyByYXdWYWx1ZSAobmVnYXRpdmVTdGFja0JhciBtYXkgaGF2ZSBjaGFuZ2VkIHlEYXRhLnZhbHVlKVxyXG4gICAgICAgICAgICB0aGlzLl9zZXRMYWJlbFN0eWxlKGxhYmVsQ29udGFpbmVyLCBfZC55W3lJbmRleF0udmFsdWUsIGRpbWVuc2lvbnMpO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICAvLyBmb3IgY29sdW1uLCB3aWR0aCBpcyBjb25zdGFudCwgaGVpZ2h0IGlzIHZhcnlcclxuICAgIC8vIGZvciBiYXIsIGhlaWdodCBpcyBjb25zdGFudCwgd2lkdGggaXMgdmFyeVxyXG4gICAgcHJpdmF0ZSBfc2V0TGFiZWxTdHlsZShfbGFiZWxDb250YWluZXIsIF92YWx1ZTogbnVtYmVyLCBfZGltZW5zaW9uczogSUJhclJlY3REaW1lbnNpb25zKTogdm9pZCB7XHJcbiAgICAgICAgbGV0IGxhYmVsVGV4dDogYW55ID0gX2xhYmVsQ29udGFpbmVyLnNlbGVjdCgnLmtkeC1jaGFydHMtZGF0YS1sYWJlbC10ZXh0Jyk7XHJcbiAgICAgICAgbGV0IHZlcnRpY2FsQWxpZ24gPSB0aGlzLmNvbmZpZy5jaGFydC5sYWJlbHMudmVydGljYWxBbGlnbjtcclxuICAgICAgICBsZXQgaW5zaWRlOiBib29sZWFuID0gdGhpcy5jb25maWcuY2hhcnQubGFiZWxzLmluc2lkZTtcclxuICAgICAgICBsZXQgc2lnbjogbnVtYmVyID0gTWF0aC5zaWduKF92YWx1ZSk7XHJcbiAgICAgICAgaWYgKCF2ZXJ0aWNhbEFsaWduKSB2ZXJ0aWNhbEFsaWduID0gdGhpcy5jaGFydFR5cGVbMF0gPT09ICdjb2x1bW4nID8gJ3RvcCcgOiAnbWlkZGxlJztcclxuXHJcbiAgICAgICAgdGhpcy5fYmFyU3ZjLnNldExhYmVsQ29udGFpbmVyV2lkdGhPckhlaWdodChfbGFiZWxDb250YWluZXIsIHRoaXMuY2hhcnRUeXBlWzBdLCBpbnNpZGUsIF9kaW1lbnNpb25zKTtcclxuXHJcbiAgICAgICAgLy8gaWYgbGFiZWwgaXMgaGlnaGVyIHRoYW4gYmFyJ3MvY29sdW1uJ3MgaGVpZ2h0XHJcbiAgICAgICAgbGV0IGlzTGFiZWxIaWdoZXJUaGFuUmVjdCA9IHRoaXMuX2NoYXJ0U3ZjLl9nZXRMYWJlbFRleHRIZWlnaHQoKSA+IF9kaW1lbnNpb25zLmhlaWdodDtcclxuICAgICAgICBpZiAoaXNMYWJlbEhpZ2hlclRoYW5SZWN0KSB7XHJcbiAgICAgICAgICAgIGlmICh0aGlzLmNoYXJ0VHlwZVswXSA9PT0gJ2JhcicpIHtcclxuICAgICAgICAgICAgICAgIHZlcnRpY2FsQWxpZ24gPSAnbWlkZGxlJztcclxuICAgICAgICAgICAgfSBlbHNlIGlmIChpbnNpZGUpIHtcclxuICAgICAgICAgICAgICAgIC8vIGlmIGNvbHVtbiBhbmQgaW5zaWRlLCB0byBtYWtlIHN1cmUgbGFiZWwgd2lsbCBub3QgaGl0IGludG8gYXhpcyxcclxuICAgICAgICAgICAgICAgIC8vIGlmIGF4aXMgaXMgYXQgYm90dG9tIG9mIGNoYXJ0LCBzZXQgdG8gZmxleC1lbmQgc28gdGhhdCB0ZXh0IHdpbGwgYmUgcGxhY2VkIGFib3ZlXHJcbiAgICAgICAgICAgICAgICAvLyBpZiBheGlzIGlzIGF0IHRvcCBvZiBjaGFydCwgc2V0IHRvIGZsZXgtc3RhcnQgc28gdGhhdCB0ZXh0IHdpbGwgYmUgcGxhY2VkIGJlbG93XHJcbiAgICAgICAgICAgICAgICB2ZXJ0aWNhbEFsaWduID0gdGhpcy5fY2hhcnRTdmMuaXNZUmV2ZXJzZWQgPyAndG9wJyA6ICdib3R0b20nO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICBpZiAoIWluc2lkZSkge1xyXG4gICAgICAgICAgICBpZiAodGhpcy5jaGFydFR5cGVbMF0gPT09ICdiYXInKSB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLl9iYXJTdmMuX3NldExhYmVsVGV4dFBvc0hvcml6b250YWwoXHJcbiAgICAgICAgICAgICAgICAgICAgbGFiZWxUZXh0LFxyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuX2NoYXJ0U3ZjLmlzWVJldmVyc2VkLFxyXG4gICAgICAgICAgICAgICAgICAgIHsgeFBvczogX2RpbWVuc2lvbnMueFBvcywgY2hhcnRXaWR0aDogdGhpcy53aWR0aCwgdmFsdWVTaWduOiBzaWduIH1cclxuICAgICAgICAgICAgICAgICk7XHJcbiAgICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgICAgICBsZXQgcGFyYW1zID0geyB2YWx1ZVNpZ246IHNpZ24gfTtcclxuICAgICAgICAgICAgICAgIGxldCB5UG9zID0gX2RpbWVuc2lvbnMueVBvczsgLy8gdXNlZCBmb3IgYm91bmRhcnkgY2hlY2tpbmcuXHJcbiAgICAgICAgICAgICAgICBpZiAoaXNMYWJlbEhpZ2hlclRoYW5SZWN0ICYmIHRoaXMuY2hhcnRUeXBlWzFdID09PSAnY2x1c3RlcicpIHtcclxuICAgICAgICAgICAgICAgICAgICBwYXJhbXNbJ2RpbWVuc2lvbnMnXSA9IF9kaW1lbnNpb25zO1xyXG4gICAgICAgICAgICAgICAgICAgIGxldCBuZWVkT2Zmc2V0OiBhbnkgPSB0aGlzLl9jaGFydFN2Yy5uZWVkT2Zmc2V0Rm9yQ29sdW1uKHZlcnRpY2FsQWxpZ24sIHBhcmFtcyk7XHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKG5lZWRPZmZzZXQpIHlQb3MgKz0gbmVlZE9mZnNldCAqIF9kaW1lbnNpb25zLmhlaWdodDtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIHN1cGVyLnNldExhYmVsVGV4dFBvc2l0aW9uKGxhYmVsVGV4dCwgeVBvcywgcGFyYW1zKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuXHJcblxyXG4gICAgICAgIHRoaXMuX2JhclN2Yy5zZXRWZXJ0aWNhbEFsaWduQ1NTKF9sYWJlbENvbnRhaW5lciwgdmVydGljYWxBbGlnbik7XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfZGlzcGxheUFsbExhYmVsKCk6IHZvaWQge1xyXG4gICAgICAgIHRoaXMuZGF0YUxhYmVsQ29udGFpbmVyXHJcbiAgICAgICAgICAgIC5zZWxlY3RBbGwoJy5rZHgtY2hhcnRzLWRhdGEtbGFiZWwnKVxyXG4gICAgICAgICAgICAuc3R5bGUoJ3Zpc2liaWxpdHknLCAndmlzaWJsZScpO1xyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX2dldFJlY3RQb3NJbmZvKCk6IElSZWN0UG9zSW5mbyB7XHJcbiAgICAgICAgaWYgKHRoaXMuY2hhcnRUeXBlWzFdID09PSAnY2x1c3RlcicpIHtcclxuICAgICAgICAgICAgLy8gdGhlIGFtb3VudCBvZiB5RGF0YSBmb3IgZWFjaCB4IHZhbHVlIHdpbGwgYWx3YXlzIGJlIHRoZSBzYW1lIChpZiB3ZSBkb24ndCByZW1vdmUgbnVsbCB2YWx1ZXMpXHJcbiAgICAgICAgICAgIC8vIGhlbmNlIHRoaXMgY2FsY3VsYXRpb24gb25seSBuZWVkcyB0byBydW4gb25jZVxyXG4gICAgICAgICAgICBsZXQgeUFyckxlbmd0aCA9IHRoaXMuZGF0YVswXSAmJiB0aGlzLmRhdGFbMF0ueSA/IHRoaXMuZGF0YVswXS55Lmxlbmd0aCA6IDA7XHJcbiAgICAgICAgICAgIHJldHVybiB0aGlzLl9iYXJTdmMuZ2V0UmVjdFdpZHRoKHRoaXMueC5iYW5kd2lkdGgoKSwgdGhpcy5iYXIuY2x1c3RlclBhZGRpbmdQZXJjZW50LCB5QXJyTGVuZ3RoKTtcclxuICAgICAgICB9XHJcbiAgICAgICAgcmV0dXJuIHtcclxuICAgICAgICAgICAgd2lkdGg6IHRoaXMueC5iYW5kd2lkdGgoKSxcclxuICAgICAgICAgICAgcGFkZGluZzogMFxyXG4gICAgICAgIH07XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBuZWdhdGl2ZVN0YWNrU3ltbWV0cnlMb2dpYygpOiB2b2lkIHtcclxuICAgICAgICBsZXQgcmVzdWx0OiBJTmVnYXRpdmVTdGFja0xvZ2ljUmV0dXJuID0gdGhpcy5fYmFyU3ZjLmFwcGx5U3ltbWV0cmljQXhpcyh0aGlzLmRhdGFSYW5nZSwgdGhpcy5jb25maWcucGxvdE9wdGlvbnMsIHRoaXMuY29uZmlnLnlBeGlzKTtcclxuICAgICAgICBpZiAocmVzdWx0Lmhhc093blByb3BlcnR5KCdkYXRhUmFuZ2UnKSkgdGhpcy5kYXRhUmFuZ2UgPSByZXN1bHQuZGF0YVJhbmdlO1xyXG4gICAgICAgIGlmIChyZXN1bHQuaGFzT3duUHJvcGVydHkoJ3lBeGlzJykpIHtcclxuICAgICAgICAgICAgdGhpcy5jb25maWcueUF4aXMgPSBPYmplY3QuYXNzaWduKHt9LCB0aGlzLmNvbmZpZy55QXhpcywgcmVzdWx0LnlBeGlzKTtcclxuICAgICAgICB9XHJcbiAgICB9XHJcbn1cclxuIl19