import { Injectable } from '@angular/core';
// import { KdBroadcaster } from '../kd-broadcaster/kd-broadcaster-svc';
// import { KdBroadcaster } from '../../';
import { KdBroadcaster } from '../index';
import * as i0 from "@angular/core";
import * as i1 from "../kd-broadcaster-svc";
export class KdPageBaseEvent {
    // public broadcaster: KdBroadcaster;
    constructor(broadcaster) {
        this.broadcaster = broadcaster;
    }
    updatePageHeader(data) {
        this.broadcaster.broadcast('Template_UpdatePageHeader', data);
    }
    onUpdatePageHeader() {
        return this.broadcaster.on('Template_UpdatePageHeader');
    }
    updateHeader(data) {
        this.broadcaster.broadcast('Template_UpdateHeader', data);
    }
    onUpdateHeader() {
        return this.broadcaster.on('Template_UpdateHeader');
    }
    updateBreadcrumb(data) {
        this.broadcaster.broadcast('Template_UpdateBreadcrumb', data);
    }
    onUpdateBreadcrumb() {
        return this.broadcaster.on('Template_UpdateBreadcrumb');
    }
    updateLeftmenu(data) {
        this.broadcaster.broadcast('Template_UpdateLeftMenu', data);
    }
    onUpdateLeftmenu() {
        return this.broadcaster.on('Template_UpdateLeftMenu');
    }
    appReady() {
        // this.broadcaster.broadcastReplay('AppReady');
        this.broadcaster.broadcastAsync('AppReady');
    }
    onAppReady() {
        // return this.broadcaster.onReplay<any>('AppReady');
        return this.broadcaster.onAsync('AppReady');
    }
    onAppReadyComplete() {
        this.broadcaster.completeAsync('AppReady');
    }
    // loadV2(data: any): void {
    //     this.broadcaster.broadcast('LoadV2', data);
    // }
    // onLoadV2(): Observable<any> {
    //     return this.broadcaster.on<any>('LoadV2');
    // }
    updateModal(data) {
        this.broadcaster.broadcast('ShowModal', data);
    }
    onUpdateModal() {
        return this.broadcaster.on('ShowModal');
    }
}
KdPageBaseEvent.ɵprov = i0.ɵɵdefineInjectable({ factory: function KdPageBaseEvent_Factory() { return new KdPageBaseEvent(i0.ɵɵinject(i1.KdBroadcaster)); }, token: KdPageBaseEvent, providedIn: "root" });
KdPageBaseEvent.decorators = [
    { type: Injectable, args: [{
                providedIn: 'root'
            },] }
];
KdPageBaseEvent.ctorParameters = () => [
    { type: KdBroadcaster }
];
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoia2QtcGFnZS1iYXNlLmV2ZW50LmpzIiwic291cmNlUm9vdCI6IkM6L1Byb2plY3RzL0FuZ3VsYXIvaW9zdGctb3BlbmVtaXMtc3R5bGVndWlkZS9wcm9qZWN0cy9vcGVuZW1pcy1zdHlsZWd1aWRlLWxpYi9zcmMvIiwic291cmNlcyI6WyJrZC1jb21wb25lbnRzL2tkLWNvbW1vbi9rZC1wYWdlLWJhc2Uva2QtcGFnZS1iYXNlLmV2ZW50LnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBLE9BQU8sRUFBRSxVQUFVLEVBQUUsTUFBTSxlQUFlLENBQUM7QUFFM0Msd0VBQXdFO0FBQ3hFLDBDQUEwQztBQUMxQyxPQUFPLEVBQUUsYUFBYSxFQUFFLE1BQU0sVUFBVSxDQUFDOzs7QUFLekMsTUFBTSxPQUFPLGVBQWU7SUFDeEIscUNBQXFDO0lBQ3JDLFlBQXNCLFdBQTBCO1FBQTFCLGdCQUFXLEdBQVgsV0FBVyxDQUFlO0lBQUksQ0FBQztJQUVyRCxnQkFBZ0IsQ0FBQyxJQUFTO1FBQ3RCLElBQUksQ0FBQyxXQUFXLENBQUMsU0FBUyxDQUFDLDJCQUEyQixFQUFFLElBQUksQ0FBQyxDQUFDO0lBQ2xFLENBQUM7SUFFRCxrQkFBa0I7UUFDZCxPQUFPLElBQUksQ0FBQyxXQUFXLENBQUMsRUFBRSxDQUFNLDJCQUEyQixDQUFDLENBQUM7SUFDakUsQ0FBQztJQUVELFlBQVksQ0FBQyxJQUFTO1FBQ2xCLElBQUksQ0FBQyxXQUFXLENBQUMsU0FBUyxDQUFDLHVCQUF1QixFQUFFLElBQUksQ0FBQyxDQUFDO0lBQzlELENBQUM7SUFFRCxjQUFjO1FBQ1YsT0FBTyxJQUFJLENBQUMsV0FBVyxDQUFDLEVBQUUsQ0FBTSx1QkFBdUIsQ0FBQyxDQUFDO0lBQzdELENBQUM7SUFFRCxnQkFBZ0IsQ0FBQyxJQUFTO1FBQ3RCLElBQUksQ0FBQyxXQUFXLENBQUMsU0FBUyxDQUFDLDJCQUEyQixFQUFFLElBQUksQ0FBQyxDQUFDO0lBQ2xFLENBQUM7SUFFRCxrQkFBa0I7UUFDZCxPQUFPLElBQUksQ0FBQyxXQUFXLENBQUMsRUFBRSxDQUFNLDJCQUEyQixDQUFDLENBQUM7SUFDakUsQ0FBQztJQUVELGNBQWMsQ0FBQyxJQUFTO1FBQ3BCLElBQUksQ0FBQyxXQUFXLENBQUMsU0FBUyxDQUFDLHlCQUF5QixFQUFFLElBQUksQ0FBQyxDQUFDO0lBQ2hFLENBQUM7SUFFRCxnQkFBZ0I7UUFDWixPQUFPLElBQUksQ0FBQyxXQUFXLENBQUMsRUFBRSxDQUFNLHlCQUF5QixDQUFDLENBQUM7SUFDL0QsQ0FBQztJQUVELFFBQVE7UUFDSixnREFBZ0Q7UUFDaEQsSUFBSSxDQUFDLFdBQVcsQ0FBQyxjQUFjLENBQUMsVUFBVSxDQUFDLENBQUM7SUFDaEQsQ0FBQztJQUVELFVBQVU7UUFDTixxREFBcUQ7UUFDckQsT0FBTyxJQUFJLENBQUMsV0FBVyxDQUFDLE9BQU8sQ0FBTSxVQUFVLENBQUMsQ0FBQztJQUNyRCxDQUFDO0lBRUQsa0JBQWtCO1FBQ2QsSUFBSSxDQUFDLFdBQVcsQ0FBQyxhQUFhLENBQUMsVUFBVSxDQUFDLENBQUM7SUFDL0MsQ0FBQztJQUVELDRCQUE0QjtJQUM1QixrREFBa0Q7SUFDbEQsSUFBSTtJQUVKLGdDQUFnQztJQUNoQyxpREFBaUQ7SUFDakQsSUFBSTtJQUVKLFdBQVcsQ0FBQyxJQUFTO1FBQ2pCLElBQUksQ0FBQyxXQUFXLENBQUMsU0FBUyxDQUFDLFdBQVcsRUFBRSxJQUFJLENBQUMsQ0FBQztJQUNsRCxDQUFDO0lBRUQsYUFBYTtRQUNULE9BQU8sSUFBSSxDQUFDLFdBQVcsQ0FBQyxFQUFFLENBQU0sV0FBVyxDQUFDLENBQUM7SUFDakQsQ0FBQzs7OztZQW5FSixVQUFVLFNBQUU7Z0JBQ1IsVUFBVSxFQUFFLE1BQU07YUFDdEI7OztZQUpRLGFBQWEiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBJbmplY3RhYmxlIH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XHJcbmltcG9ydCB7IE9ic2VydmFibGUgfSBmcm9tICdyeGpzJztcclxuLy8gaW1wb3J0IHsgS2RCcm9hZGNhc3RlciB9IGZyb20gJy4uL2tkLWJyb2FkY2FzdGVyL2tkLWJyb2FkY2FzdGVyLXN2Yyc7XHJcbi8vIGltcG9ydCB7IEtkQnJvYWRjYXN0ZXIgfSBmcm9tICcuLi8uLi8nO1xyXG5pbXBvcnQgeyBLZEJyb2FkY2FzdGVyIH0gZnJvbSAnLi4vaW5kZXgnO1xyXG5cclxuQEluamVjdGFibGUoIHtcclxuICAgICBwcm92aWRlZEluOiAncm9vdCdcclxufSApXHJcbmV4cG9ydCBjbGFzcyBLZFBhZ2VCYXNlRXZlbnQge1xyXG4gICAgLy8gcHVibGljIGJyb2FkY2FzdGVyOiBLZEJyb2FkY2FzdGVyO1xyXG4gICAgY29uc3RydWN0b3IocHJvdGVjdGVkIGJyb2FkY2FzdGVyOiBLZEJyb2FkY2FzdGVyKSB7IH1cclxuXHJcbiAgICB1cGRhdGVQYWdlSGVhZGVyKGRhdGE6IGFueSk6IHZvaWQge1xyXG4gICAgICAgIHRoaXMuYnJvYWRjYXN0ZXIuYnJvYWRjYXN0KCdUZW1wbGF0ZV9VcGRhdGVQYWdlSGVhZGVyJywgZGF0YSk7XHJcbiAgICB9XHJcblxyXG4gICAgb25VcGRhdGVQYWdlSGVhZGVyKCk6IE9ic2VydmFibGU8YW55PiB7XHJcbiAgICAgICAgcmV0dXJuIHRoaXMuYnJvYWRjYXN0ZXIub248YW55PignVGVtcGxhdGVfVXBkYXRlUGFnZUhlYWRlcicpO1xyXG4gICAgfVxyXG5cclxuICAgIHVwZGF0ZUhlYWRlcihkYXRhOiBhbnkpOiB2b2lkIHtcclxuICAgICAgICB0aGlzLmJyb2FkY2FzdGVyLmJyb2FkY2FzdCgnVGVtcGxhdGVfVXBkYXRlSGVhZGVyJywgZGF0YSk7XHJcbiAgICB9XHJcblxyXG4gICAgb25VcGRhdGVIZWFkZXIoKTogT2JzZXJ2YWJsZTxhbnk+IHtcclxuICAgICAgICByZXR1cm4gdGhpcy5icm9hZGNhc3Rlci5vbjxhbnk+KCdUZW1wbGF0ZV9VcGRhdGVIZWFkZXInKTtcclxuICAgIH1cclxuXHJcbiAgICB1cGRhdGVCcmVhZGNydW1iKGRhdGE6IGFueSk6IHZvaWQge1xyXG4gICAgICAgIHRoaXMuYnJvYWRjYXN0ZXIuYnJvYWRjYXN0KCdUZW1wbGF0ZV9VcGRhdGVCcmVhZGNydW1iJywgZGF0YSk7XHJcbiAgICB9XHJcblxyXG4gICAgb25VcGRhdGVCcmVhZGNydW1iKCk6IE9ic2VydmFibGU8YW55PiB7XHJcbiAgICAgICAgcmV0dXJuIHRoaXMuYnJvYWRjYXN0ZXIub248YW55PignVGVtcGxhdGVfVXBkYXRlQnJlYWRjcnVtYicpO1xyXG4gICAgfVxyXG5cclxuICAgIHVwZGF0ZUxlZnRtZW51KGRhdGE6IGFueSk6IHZvaWQge1xyXG4gICAgICAgIHRoaXMuYnJvYWRjYXN0ZXIuYnJvYWRjYXN0KCdUZW1wbGF0ZV9VcGRhdGVMZWZ0TWVudScsIGRhdGEpO1xyXG4gICAgfVxyXG5cclxuICAgIG9uVXBkYXRlTGVmdG1lbnUoKTogT2JzZXJ2YWJsZTxhbnk+IHtcclxuICAgICAgICByZXR1cm4gdGhpcy5icm9hZGNhc3Rlci5vbjxhbnk+KCdUZW1wbGF0ZV9VcGRhdGVMZWZ0TWVudScpO1xyXG4gICAgfVxyXG5cclxuICAgIGFwcFJlYWR5KCk6IHZvaWQge1xyXG4gICAgICAgIC8vIHRoaXMuYnJvYWRjYXN0ZXIuYnJvYWRjYXN0UmVwbGF5KCdBcHBSZWFkeScpO1xyXG4gICAgICAgIHRoaXMuYnJvYWRjYXN0ZXIuYnJvYWRjYXN0QXN5bmMoJ0FwcFJlYWR5Jyk7XHJcbiAgICB9XHJcblxyXG4gICAgb25BcHBSZWFkeSgpOiBPYnNlcnZhYmxlPGFueT4ge1xyXG4gICAgICAgIC8vIHJldHVybiB0aGlzLmJyb2FkY2FzdGVyLm9uUmVwbGF5PGFueT4oJ0FwcFJlYWR5Jyk7XHJcbiAgICAgICAgcmV0dXJuIHRoaXMuYnJvYWRjYXN0ZXIub25Bc3luYzxhbnk+KCdBcHBSZWFkeScpO1xyXG4gICAgfVxyXG5cclxuICAgIG9uQXBwUmVhZHlDb21wbGV0ZSgpOiB2b2lkIHtcclxuICAgICAgICB0aGlzLmJyb2FkY2FzdGVyLmNvbXBsZXRlQXN5bmMoJ0FwcFJlYWR5Jyk7XHJcbiAgICB9XHJcblxyXG4gICAgLy8gbG9hZFYyKGRhdGE6IGFueSk6IHZvaWQge1xyXG4gICAgLy8gICAgIHRoaXMuYnJvYWRjYXN0ZXIuYnJvYWRjYXN0KCdMb2FkVjInLCBkYXRhKTtcclxuICAgIC8vIH1cclxuXHJcbiAgICAvLyBvbkxvYWRWMigpOiBPYnNlcnZhYmxlPGFueT4ge1xyXG4gICAgLy8gICAgIHJldHVybiB0aGlzLmJyb2FkY2FzdGVyLm9uPGFueT4oJ0xvYWRWMicpO1xyXG4gICAgLy8gfVxyXG5cclxuICAgIHVwZGF0ZU1vZGFsKGRhdGE6IGFueSk6IHZvaWQge1xyXG4gICAgICAgIHRoaXMuYnJvYWRjYXN0ZXIuYnJvYWRjYXN0KCdTaG93TW9kYWwnLCBkYXRhKTtcclxuICAgIH1cclxuXHJcbiAgICBvblVwZGF0ZU1vZGFsKCk6IE9ic2VydmFibGU8YW55PiB7XHJcbiAgICAgICAgcmV0dXJuIHRoaXMuYnJvYWRjYXN0ZXIub248YW55PignU2hvd01vZGFsJyk7XHJcbiAgICB9XHJcbn1cclxuIl19