import { NavigationEnd } from '@angular/router';
import { KdConvertionSvc, KdDataSvc } from '../index';
export class KdPageBase {
    constructor(options) {
        this.options = options;
        this._textOmitted = '';
        this._header = {
            brandLogo: {},
            userInfo: {
                name: '',
                imgType: 'icon',
                imgSrc: '',
                path: ''
            },
            btnGroup: []
        };
        this._pageheader = {
            pageheaderText: '',
            leftBtn: [],
            // leftBtn: [{
            //     type: 'add'
            // }],
            moreBtn: false,
            moreAction: [],
            searchBtn: false,
            searchEvent: ['change', 'keyup']
        };
        this._breadcrumbList = {
            home: { icon: 'fa fa-home', url: '', path: '/App/InstitutionClasses/list' },
            list: []
        };
        this._pageParams = {};
        this._prevPageURL = '';
        this._currentURL = '';
        this.convertionSvc = new KdConvertionSvc();
        this.dataSvc = new KdDataSvc();
        // this._prevPageInfo = this.initPrevHistory();
        // this.options.router.events
        //     .filter(e => e instanceof RoutesRecognized)
        //     // .filter(e => (e.constructor.name === 'RoutesRecognized') || ( e.constructor.name === 'NavigationEnd'))
        //     .pairwise()
        //     .subscribe((e: any[]): void => {
        //         console.log('1 on init > url info ', e);
        //         console.log(new Date());
        //         console.log(e[0]);
        //         console.log(e[e.length - 1]);
        //         this._prevPageInfo = e[0].urlAfterRedirects;
        //         // console.log('this._prevPageInfo = > ', this._prevPageInfo);
        //         // this._routerHistorySub.unsubscribe();
        //     });
        // console.log('constructor >> ',this._prevPageInfo);
        this._routerSub = this.options.router.events
            .subscribe(event => {
            // if (event instanceof RoutesRecognized) {
            // console.log('RoutesRecognized > event - ', Object.assign({}, event));
            // }
            if (event instanceof NavigationEnd) {
                // console.log('>>', event);
                this._prevPageURL = JSON.stringify(this._currentURL);
                this._currentURL = event.urlAfterRedirects;
                this._breadcrumbList.list = this.convertionSvc.urlToArray(event.urlAfterRedirects, this._textOmitted);
                // console.log('this._breadcrumbList.list',this._breadcrumbList.list);
                if (typeof this.options.pageEvent !== 'undefined') {
                    this.options.pageEvent.appReady();
                    this.options.pageEvent.onAppReadyComplete();
                }
                if (typeof this.options.pageBaseEvent !== 'undefined') {
                    console.error('please change to PageEvent instead of PageBaseEvent');
                }
            }
        });
        this._activatedRouteSub = this.options.activatedRoute.params.subscribe((_params) => {
            this._pageParams = _params;
        });
    }
    // protected enableLoadV2(_bool: boolean) {
    //     // this.options.pageEvent.loadV2(_bool);
    // }
    /**
     * [destroyPageBaseSub - Manually discard the all the subscriptions]
     */
    destroyPageBaseSub() {
        if (typeof this._routerSub !== 'undefined')
            this._routerSub.unsubscribe();
        if (typeof this._activatedRouteSub !== 'undefined')
            this._activatedRouteSub.unsubscribe();
    }
    /**
     * Application Header (Product Header)
     */
    getHeaderConfig() {
        return this._header.userInfo;
    }
    setHeaderConfig(_conf) {
        this._header.userInfo = _conf;
    }
    updateHeader() {
        this.options.pageEvent.updateHeader(this._header);
    }
    /**
     * Left Navigation
     */
    setLeftMenuList(_leftMenuObj) {
        this.options.pageEvent.updateLeftmenu(_leftMenuObj);
    }
    /**
     * Page Header
     */
    getPageTitle() {
        return this._pageheader.pageheaderText;
    }
    setPageTitle(_title, _humanize = true) {
        let tempStr = _title.replace(this._textOmitted, '');
        if (_humanize) {
            tempStr = this.humanize(this.underscore(tempStr));
        }
        // console.log('setPageTitle=',tempStr);
        this._pageheader.pageheaderText = tempStr;
    }
    getToolbarMainBtns() {
        return JSON.parse(JSON.stringify(this._pageheader.leftBtn));
    }
    setToolbarMainBtns(_buttons) {
        this._pageheader.leftBtn = _buttons;
    }
    getToolbarMoreActionBtns() {
        return this._pageheader.moreAction;
    }
    enableMoreActionBtns(_enable, _buttons) {
        this._pageheader.moreBtn = _enable;
        if (_buttons) {
            this._pageheader.moreAction = _buttons;
        }
    }
    enableToolbarSearch(_enable, _callback) {
        this._pageheader.searchBtn = _enable;
        if (_enable && _callback) {
            this._pageheader.searchCallback = _callback;
        }
    }
    updateSearchText(_searchText) {
        this._pageheader.searchText = _searchText;
    }
    updatePageHeader() {
        console.log('broadcast updatePageHeader', this._pageheader);
        this.options.pageEvent.updatePageHeader(this._pageheader);
    }
    /**
     * Breadcrumbs
     */
    setBreadcrumbsList(_list) {
        this._breadcrumbList.list = _list;
        this.updateBreadcrumb();
    }
    getBreadcrumbsList() {
        return this._breadcrumbList.list;
    }
    updateBreadcrumb() {
        this.options.pageEvent.updateBreadcrumb(JSON.parse(JSON.stringify(this._breadcrumbList)));
    }
    /**
     * Alerts
     */
    setAlert(_config, _type) {
        if (this.options.alertEvent) {
            this.options.alertEvent[_type](_config);
        }
        else {
            console.warn('Missing event - KdAlertEvent');
        }
    }
    /**
     * [setModal Creating modal view]
     *  _configConfimation {
     *              header: '',
     *              message: '',
     *              buttonConfirm: {
     *                  text: 'test text',
     *                  callback: () =>{
     *
     *                  }
     *              }
     *          }
     */
    setModal() {
        let _pageBaseEvent;
        if (this.options.pageEvent) {
            _pageBaseEvent = this.options.pageEvent;
        }
        else {
            console.warn('Please import \'PageBaseEvent\' to use modal');
        }
        /**
         * [confirmation a modal dialog with 2 buttons: 'Confirm' and 'Cancel']
         */
        function confirmation(_config) {
            if (_pageBaseEvent) {
                let updatedConfig = {};
                let defaultConfig = {
                    suspendClose: true,
                    title: 'Alert',
                    body: 'Dummy text - confirmation',
                    button: [{
                            text: 'Confirm',
                            class: 'btn-text',
                            callback: () => { }
                        },
                        {
                            text: 'Cancel',
                            class: 'btn-outline',
                            callback: () => { _pageBaseEvent.updateModal({ close: true }); }
                        }]
                };
                updatedConfig = applyConfig(_config, defaultConfig);
                _pageBaseEvent.updateModal({ enabled: true, config: updatedConfig });
            }
        }
        /**
         * [notify a modal dialog with 1 button: 'Done']
         */
        function notify(_config) {
            if (_pageBaseEvent) {
                let updatedConfig = {};
                let defaultConfig = {
                    suspendClose: true,
                    title: 'Alert',
                    body: 'Dummy text - notify',
                    button: [{
                            text: 'Done',
                            class: 'btn-text',
                            callback: () => { _pageBaseEvent.updateModal({ close: true }); }
                        }]
                };
                updatedConfig = applyConfig(_config, defaultConfig);
                _pageBaseEvent.updateModal({ enabled: true, config: updatedConfig });
            }
        }
        function disabled() {
            if (_pageBaseEvent)
                _pageBaseEvent.updateModal({ enabled: false });
        }
        function close() {
            if (_pageBaseEvent)
                _pageBaseEvent.updateModal({ close: true });
        }
        function applyConfig(_sourceConfig, _targetConfig) {
            let updatedConfig = {};
            Object.assign(updatedConfig, _targetConfig);
            if (_sourceConfig.header)
                updatedConfig.title = _sourceConfig.header;
            if (_sourceConfig.message)
                updatedConfig.body = _sourceConfig.message;
            if (_sourceConfig.buttonConfirm) {
                if (_sourceConfig.buttonConfirm.text)
                    updatedConfig.button[0].text = _sourceConfig.buttonConfirm.text;
                if (_sourceConfig.buttonConfirm.callback)
                    updatedConfig.button[0].callback = _sourceConfig.buttonConfirm.callback;
            }
            return updatedConfig;
        }
        return {
            confirmation: confirmation,
            notify: notify,
            disabled: disabled,
            close: close
        };
    }
    /**
     * Utils Methods
     */
    // private initPrevHistory(){
    //     // this._routerHistorySub = this.options.router.events
    //     return this.options.router.events
    //         .filter(e => e instanceof RoutesRecognized)
    //         // .filter(e => (e.constructor.name === 'RoutesRecognized') || ( e.constructor.name === 'NavigationEnd'))
    //         .pairwise()
    //         .subscribe((e: any[]): void => {
    //             console.log('1 on init > url info ', e);
    //             console.log(new Date());
    //             console.log(e[0]);
    //             console.log(e[e.length - 1]);
    //             return e[0];
    //             // console.log('this._prevPageInfo = > ', this._prevPageInfo);
    //             // this._routerHistorySub.unsubscribe();
    //         });
    // }
    getCurrentURL() {
        return this._currentURL;
    }
    setTextOmit(_text) {
        this._textOmitted = _text;
    }
    getParams() {
        return this._pageParams;
    }
    getPrevPageInfo() {
        console.log('getPrevPageInfo . >> ', this._prevPageURL);
        return this._prevPageURL;
    }
    underscore(_camelCase) {
        return this.convertionSvc.underscore(_camelCase);
    }
    humanize(_underscored) {
        return this.convertionSvc.humanize(_underscored);
    }
    camelCase(_text) {
        return this.convertionSvc.camelCase(_text, ' ');
    }
    slug(_word) {
        return this.convertionSvc.slug(_word);
    }
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoia2QtcGFnZS1iYXNlLmpzIiwic291cmNlUm9vdCI6IkM6L1Byb2plY3RzL0FuZ3VsYXIvaW9zdGctb3BlbmVtaXMtc3R5bGVndWlkZS9wcm9qZWN0cy9vcGVuZW1pcy1zdHlsZWd1aWRlLWxpYi9zcmMvIiwic291cmNlcyI6WyJrZC1jb21wb25lbnRzL2tkLWNvbW1vbi9rZC1wYWdlLWJhc2Uva2QtcGFnZS1iYXNlLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUNBLE9BQU8sRUFBVSxhQUFhLEVBQTBCLE1BQU0saUJBQWlCLENBQUM7QUFFaEYsT0FBTyxFQUFFLGVBQWUsRUFBRSxTQUFTLEVBQUUsTUFBTSxVQUFVLENBQUM7QUFjdEQsTUFBTSxPQUFPLFVBQVU7SUFzQ25CLFlBQ1csT0FBeUI7UUFBekIsWUFBTyxHQUFQLE9BQU8sQ0FBa0I7UUF0QzVCLGlCQUFZLEdBQVcsRUFBRSxDQUFDO1FBQzFCLFlBQU8sR0FBUTtZQUNuQixTQUFTLEVBQUUsRUFBRTtZQUNiLFFBQVEsRUFBRTtnQkFDTixJQUFJLEVBQUUsRUFBRTtnQkFDUixPQUFPLEVBQUUsTUFBTTtnQkFDZixNQUFNLEVBQUUsRUFBRTtnQkFDVixJQUFJLEVBQUUsRUFBRTthQUNYO1lBQ0QsUUFBUSxFQUFFLEVBQUU7U0FDZixDQUFDO1FBRU0sZ0JBQVcsR0FBc0I7WUFDckMsY0FBYyxFQUFFLEVBQUU7WUFDbEIsT0FBTyxFQUFFLEVBQUU7WUFDWCxjQUFjO1lBQ2Qsa0JBQWtCO1lBQ2xCLE1BQU07WUFDTixPQUFPLEVBQUUsS0FBSztZQUNkLFVBQVUsRUFBRSxFQUFFO1lBQ2QsU0FBUyxFQUFFLEtBQUs7WUFDaEIsV0FBVyxFQUFFLENBQUMsUUFBUSxFQUFFLE9BQU8sQ0FBQztTQUNuQyxDQUFDO1FBRU0sb0JBQWUsR0FBUTtZQUMzQixJQUFJLEVBQUUsRUFBRSxJQUFJLEVBQUUsWUFBWSxFQUFFLEdBQUcsRUFBRSxFQUFFLEVBQUUsSUFBSSxFQUFFLDhCQUE4QixFQUFFO1lBQzNFLElBQUksRUFBRSxFQUFFO1NBQ1gsQ0FBQztRQUNNLGdCQUFXLEdBQVEsRUFBRSxDQUFDO1FBQ3RCLGlCQUFZLEdBQVcsRUFBRSxDQUFDO1FBTzFCLGdCQUFXLEdBQVcsRUFBRSxDQUFDO1FBSTdCLElBQUksQ0FBQyxhQUFhLEdBQUcsSUFBSSxlQUFlLEVBQUUsQ0FBQztRQUMzQyxJQUFJLENBQUMsT0FBTyxHQUFHLElBQUksU0FBUyxFQUFFLENBQUM7UUFFL0IsK0NBQStDO1FBQy9DLDZCQUE2QjtRQUM3QixrREFBa0Q7UUFDbEQsZ0hBQWdIO1FBQ2hILGtCQUFrQjtRQUNsQix1Q0FBdUM7UUFDdkMsbURBQW1EO1FBQ25ELG1DQUFtQztRQUNuQyw2QkFBNkI7UUFDN0Isd0NBQXdDO1FBQ3hDLHVEQUF1RDtRQUN2RCx5RUFBeUU7UUFDekUsbURBQW1EO1FBQ25ELFVBQVU7UUFFVixxREFBcUQ7UUFDckQsSUFBSSxDQUFDLFVBQVUsR0FBRyxJQUFJLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxNQUFNO2FBQ3ZDLFNBQVMsQ0FBQyxLQUFLLENBQUMsRUFBRTtZQUNmLDJDQUEyQztZQUMzQyx3RUFBd0U7WUFDeEUsSUFBSTtZQUNKLElBQUksS0FBSyxZQUFZLGFBQWEsRUFBRTtnQkFDaEMsNEJBQTRCO2dCQUM1QixJQUFJLENBQUMsWUFBWSxHQUFHLElBQUksQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxDQUFDO2dCQUNyRCxJQUFJLENBQUMsV0FBVyxHQUFHLEtBQUssQ0FBQyxpQkFBaUIsQ0FBQztnQkFDM0MsSUFBSSxDQUFDLGVBQWUsQ0FBQyxJQUFJLEdBQUcsSUFBSSxDQUFDLGFBQWEsQ0FBQyxVQUFVLENBQUMsS0FBSyxDQUFDLGlCQUFpQixFQUFFLElBQUksQ0FBQyxZQUFZLENBQUMsQ0FBQztnQkFDdEcsc0VBQXNFO2dCQUN0RSxJQUFJLE9BQU8sSUFBSSxDQUFDLE9BQU8sQ0FBQyxTQUFTLEtBQUssV0FBVyxFQUFFO29CQUMvQyxJQUFJLENBQUMsT0FBTyxDQUFDLFNBQVMsQ0FBQyxRQUFRLEVBQUUsQ0FBQztvQkFDbEMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxTQUFTLENBQUMsa0JBQWtCLEVBQUUsQ0FBQztpQkFDL0M7Z0JBRUQsSUFBSSxPQUFPLElBQUksQ0FBQyxPQUFPLENBQUMsYUFBYSxLQUFLLFdBQVcsRUFBRTtvQkFDbkQsT0FBTyxDQUFDLEtBQUssQ0FBQyxxREFBcUQsQ0FBQyxDQUFDO2lCQUN4RTthQUNKO1FBQ0wsQ0FBQyxDQUFDLENBQUM7UUFFUCxJQUFJLENBQUMsa0JBQWtCLEdBQUcsSUFBSSxDQUFDLE9BQU8sQ0FBQyxjQUFjLENBQUMsTUFBTSxDQUFDLFNBQVMsQ0FBQyxDQUFDLE9BQWUsRUFBUSxFQUFFO1lBQzdGLElBQUksQ0FBQyxXQUFXLEdBQUcsT0FBTyxDQUFDO1FBQy9CLENBQUMsQ0FBQyxDQUFDO0lBQ1AsQ0FBQztJQUNELDJDQUEyQztJQUMzQywrQ0FBK0M7SUFDL0MsSUFBSTtJQUVKOztPQUVHO0lBQ08sa0JBQWtCO1FBQ3hCLElBQUksT0FBTyxJQUFJLENBQUMsVUFBVSxLQUFLLFdBQVc7WUFBRSxJQUFJLENBQUMsVUFBVSxDQUFDLFdBQVcsRUFBRSxDQUFDO1FBQzFFLElBQUksT0FBTyxJQUFJLENBQUMsa0JBQWtCLEtBQUssV0FBVztZQUFFLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxXQUFXLEVBQUUsQ0FBQztJQUM5RixDQUFDO0lBRUQ7O09BRUc7SUFFTyxlQUFlO1FBQ3JCLE9BQU8sSUFBSSxDQUFDLE9BQU8sQ0FBQyxRQUFRLENBQUM7SUFDakMsQ0FBQztJQUVTLGVBQWUsQ0FBQyxLQUFVO1FBQ2hDLElBQUksQ0FBQyxPQUFPLENBQUMsUUFBUSxHQUFHLEtBQUssQ0FBQztJQUNsQyxDQUFDO0lBRVMsWUFBWTtRQUNsQixJQUFJLENBQUMsT0FBTyxDQUFDLFNBQVMsQ0FBQyxZQUFZLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxDQUFDO0lBQ3RELENBQUM7SUFFRDs7T0FFRztJQUVPLGVBQWUsQ0FBQyxZQUFpQjtRQUN2QyxJQUFJLENBQUMsT0FBTyxDQUFDLFNBQVMsQ0FBQyxjQUFjLENBQUMsWUFBWSxDQUFDLENBQUM7SUFDeEQsQ0FBQztJQUVEOztPQUVHO0lBRU8sWUFBWTtRQUNsQixPQUFPLElBQUksQ0FBQyxXQUFXLENBQUMsY0FBYyxDQUFDO0lBQzNDLENBQUM7SUFFUyxZQUFZLENBQUMsTUFBYyxFQUFFLFlBQXFCLElBQUk7UUFDNUQsSUFBSSxPQUFPLEdBQVcsTUFBTSxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsWUFBWSxFQUFFLEVBQUUsQ0FBQyxDQUFDO1FBQzVELElBQUksU0FBUyxFQUFFO1lBQ1gsT0FBTyxHQUFHLElBQUksQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDO1NBQ3JEO1FBQ0Qsd0NBQXdDO1FBQ3hDLElBQUksQ0FBQyxXQUFXLENBQUMsY0FBYyxHQUFHLE9BQU8sQ0FBQztJQUM5QyxDQUFDO0lBRVMsa0JBQWtCO1FBQ3hCLE9BQU8sSUFBSSxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQyxXQUFXLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQztJQUNoRSxDQUFDO0lBRVMsa0JBQWtCLENBQUMsUUFBb0I7UUFDN0MsSUFBSSxDQUFDLFdBQVcsQ0FBQyxPQUFPLEdBQUcsUUFBUSxDQUFDO0lBQ3hDLENBQUM7SUFFUyx3QkFBd0I7UUFDOUIsT0FBTyxJQUFJLENBQUMsV0FBVyxDQUFDLFVBQVUsQ0FBQztJQUN2QyxDQUFDO0lBRVMsb0JBQW9CLENBQUMsT0FBZ0IsRUFBRSxRQUFxQjtRQUNsRSxJQUFJLENBQUMsV0FBVyxDQUFDLE9BQU8sR0FBRyxPQUFPLENBQUM7UUFDbkMsSUFBSSxRQUFRLEVBQUU7WUFDVixJQUFJLENBQUMsV0FBVyxDQUFDLFVBQVUsR0FBRyxRQUFRLENBQUM7U0FDMUM7SUFDTCxDQUFDO0lBRVMsbUJBQW1CLENBQUMsT0FBZ0IsRUFBRSxTQUFtQztRQUMvRSxJQUFJLENBQUMsV0FBVyxDQUFDLFNBQVMsR0FBRyxPQUFPLENBQUM7UUFDckMsSUFBSSxPQUFPLElBQUksU0FBUyxFQUFFO1lBQ3RCLElBQUksQ0FBQyxXQUFXLENBQUMsY0FBYyxHQUFHLFNBQVMsQ0FBQztTQUMvQztJQUNMLENBQUM7SUFFUyxnQkFBZ0IsQ0FBQyxXQUFtQjtRQUMxQyxJQUFJLENBQUMsV0FBVyxDQUFDLFVBQVUsR0FBRyxXQUFXLENBQUM7SUFDOUMsQ0FBQztJQUVTLGdCQUFnQjtRQUN0QixPQUFPLENBQUMsR0FBRyxDQUFDLDRCQUE0QixFQUFFLElBQUksQ0FBQyxXQUFXLENBQUMsQ0FBQztRQUM1RCxJQUFJLENBQUMsT0FBTyxDQUFDLFNBQVMsQ0FBQyxnQkFBZ0IsQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFDLENBQUM7SUFDOUQsQ0FBQztJQUVEOztPQUVHO0lBRU8sa0JBQWtCLENBQUMsS0FBaUI7UUFDMUMsSUFBSSxDQUFDLGVBQWUsQ0FBQyxJQUFJLEdBQUcsS0FBSyxDQUFDO1FBQ2xDLElBQUksQ0FBQyxnQkFBZ0IsRUFBRSxDQUFDO0lBQzVCLENBQUM7SUFFUyxrQkFBa0I7UUFDeEIsT0FBTyxJQUFJLENBQUMsZUFBZSxDQUFDLElBQUksQ0FBQztJQUNyQyxDQUFDO0lBRVMsZ0JBQWdCO1FBQ3RCLElBQUksQ0FBQyxPQUFPLENBQUMsU0FBUyxDQUFDLGdCQUFnQixDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsZUFBZSxDQUFDLENBQUMsQ0FBQyxDQUFDO0lBQzlGLENBQUM7SUFFRDs7T0FFRztJQUVPLFFBQVEsQ0FBQyxPQUFZLEVBQUUsS0FBYTtRQUMxQyxJQUFJLElBQUksQ0FBQyxPQUFPLENBQUMsVUFBVSxFQUFFO1lBQ3pCLElBQUksQ0FBQyxPQUFPLENBQUMsVUFBVSxDQUFDLEtBQUssQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDO1NBQzNDO2FBQ0k7WUFDRCxPQUFPLENBQUMsSUFBSSxDQUFDLDhCQUE4QixDQUFDLENBQUM7U0FDaEQ7SUFDTCxDQUFDO0lBRUQ7Ozs7Ozs7Ozs7OztPQVlHO0lBQ08sUUFBUTtRQUNkLElBQUksY0FBK0IsQ0FBQztRQUNwQyxJQUFJLElBQUksQ0FBQyxPQUFPLENBQUMsU0FBUyxFQUFFO1lBQ3hCLGNBQWMsR0FBRyxJQUFJLENBQUMsT0FBTyxDQUFDLFNBQVMsQ0FBQztTQUMzQzthQUNJO1lBQ0QsT0FBTyxDQUFDLElBQUksQ0FBQyw4Q0FBOEMsQ0FBQyxDQUFDO1NBQ2hFO1FBRUQ7O1dBRUc7UUFDSCxTQUFTLFlBQVksQ0FBQyxPQUFhO1lBQy9CLElBQUksY0FBYyxFQUFFO2dCQUNoQixJQUFJLGFBQWEsR0FBUSxFQUFFLENBQUM7Z0JBQzVCLElBQUksYUFBYSxHQUFRO29CQUNyQixZQUFZLEVBQUUsSUFBSTtvQkFDbEIsS0FBSyxFQUFFLE9BQU87b0JBQ2QsSUFBSSxFQUFFLDJCQUEyQjtvQkFDakMsTUFBTSxFQUFFLENBQUM7NEJBQ0wsSUFBSSxFQUFFLFNBQVM7NEJBQ2YsS0FBSyxFQUFFLFVBQVU7NEJBQ2pCLFFBQVEsRUFBRSxHQUFTLEVBQUUsR0FBRyxDQUFDO3lCQUM1Qjt3QkFDRDs0QkFDSSxJQUFJLEVBQUUsUUFBUTs0QkFDZCxLQUFLLEVBQUUsYUFBYTs0QkFDcEIsUUFBUSxFQUFFLEdBQVMsRUFBRSxHQUFHLGNBQWMsQ0FBQyxXQUFXLENBQUMsRUFBRSxLQUFLLEVBQUUsSUFBSSxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUM7eUJBQ3pFLENBQUM7aUJBQ0wsQ0FBQztnQkFFRixhQUFhLEdBQUcsV0FBVyxDQUFDLE9BQU8sRUFBRSxhQUFhLENBQUMsQ0FBQztnQkFDcEQsY0FBYyxDQUFDLFdBQVcsQ0FBQyxFQUFFLE9BQU8sRUFBRSxJQUFJLEVBQUUsTUFBTSxFQUFFLGFBQWEsRUFBRSxDQUFDLENBQUM7YUFDeEU7UUFDTCxDQUFDO1FBRUQ7O1dBRUc7UUFDSCxTQUFTLE1BQU0sQ0FBQyxPQUFhO1lBQ3pCLElBQUksY0FBYyxFQUFFO2dCQUNoQixJQUFJLGFBQWEsR0FBUSxFQUFFLENBQUM7Z0JBQzVCLElBQUksYUFBYSxHQUFRO29CQUNyQixZQUFZLEVBQUUsSUFBSTtvQkFDbEIsS0FBSyxFQUFFLE9BQU87b0JBQ2QsSUFBSSxFQUFFLHFCQUFxQjtvQkFDM0IsTUFBTSxFQUFFLENBQUM7NEJBQ0wsSUFBSSxFQUFFLE1BQU07NEJBQ1osS0FBSyxFQUFFLFVBQVU7NEJBQ2pCLFFBQVEsRUFBRSxHQUFTLEVBQUUsR0FBRyxjQUFjLENBQUMsV0FBVyxDQUFDLEVBQUUsS0FBSyxFQUFFLElBQUksRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDO3lCQUN6RSxDQUFDO2lCQUNMLENBQUM7Z0JBRUYsYUFBYSxHQUFHLFdBQVcsQ0FBQyxPQUFPLEVBQUUsYUFBYSxDQUFDLENBQUM7Z0JBQ3BELGNBQWMsQ0FBQyxXQUFXLENBQUMsRUFBRSxPQUFPLEVBQUUsSUFBSSxFQUFFLE1BQU0sRUFBRSxhQUFhLEVBQUUsQ0FBQyxDQUFDO2FBQ3hFO1FBQ0wsQ0FBQztRQUVELFNBQVMsUUFBUTtZQUNiLElBQUksY0FBYztnQkFBRSxjQUFjLENBQUMsV0FBVyxDQUFDLEVBQUUsT0FBTyxFQUFFLEtBQUssRUFBRSxDQUFDLENBQUM7UUFDdkUsQ0FBQztRQUVELFNBQVMsS0FBSztZQUNWLElBQUksY0FBYztnQkFBRSxjQUFjLENBQUMsV0FBVyxDQUFDLEVBQUUsS0FBSyxFQUFFLElBQUksRUFBRSxDQUFDLENBQUM7UUFDcEUsQ0FBQztRQUVELFNBQVMsV0FBVyxDQUFDLGFBQWtCLEVBQUUsYUFBa0I7WUFDdkQsSUFBSSxhQUFhLEdBQVEsRUFBRSxDQUFDO1lBQ3RCLE1BQU8sQ0FBQyxNQUFNLENBQUMsYUFBYSxFQUFFLGFBQWEsQ0FBQyxDQUFDO1lBRW5ELElBQUksYUFBYSxDQUFDLE1BQU07Z0JBQUUsYUFBYSxDQUFDLEtBQUssR0FBRyxhQUFhLENBQUMsTUFBTSxDQUFDO1lBQ3JFLElBQUksYUFBYSxDQUFDLE9BQU87Z0JBQUUsYUFBYSxDQUFDLElBQUksR0FBRyxhQUFhLENBQUMsT0FBTyxDQUFDO1lBQ3RFLElBQUksYUFBYSxDQUFDLGFBQWEsRUFBRTtnQkFDN0IsSUFBSSxhQUFhLENBQUMsYUFBYSxDQUFDLElBQUk7b0JBQUUsYUFBYSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLEdBQUcsYUFBYSxDQUFDLGFBQWEsQ0FBQyxJQUFJLENBQUM7Z0JBQ3RHLElBQUksYUFBYSxDQUFDLGFBQWEsQ0FBQyxRQUFRO29CQUFFLGFBQWEsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxHQUFHLGFBQWEsQ0FBQyxhQUFhLENBQUMsUUFBUSxDQUFDO2FBQ3JIO1lBRUQsT0FBTyxhQUFhLENBQUM7UUFDekIsQ0FBQztRQUVELE9BQU87WUFDSCxZQUFZLEVBQUUsWUFBWTtZQUMxQixNQUFNLEVBQUUsTUFBTTtZQUNkLFFBQVEsRUFBRSxRQUFRO1lBQ2xCLEtBQUssRUFBRSxLQUFLO1NBQ2YsQ0FBQztJQUNOLENBQUM7SUFJRDs7T0FFRztJQUVILDZCQUE2QjtJQUM3Qiw2REFBNkQ7SUFDN0Qsd0NBQXdDO0lBQ3hDLHNEQUFzRDtJQUN0RCxvSEFBb0g7SUFDcEgsc0JBQXNCO0lBQ3RCLDJDQUEyQztJQUMzQyx1REFBdUQ7SUFDdkQsdUNBQXVDO0lBQ3ZDLGlDQUFpQztJQUNqQyw0Q0FBNEM7SUFDNUMsMkJBQTJCO0lBQzNCLDZFQUE2RTtJQUM3RSx1REFBdUQ7SUFDdkQsY0FBYztJQUNkLElBQUk7SUFFTSxhQUFhO1FBQ25CLE9BQU8sSUFBSSxDQUFDLFdBQVcsQ0FBQztJQUM1QixDQUFDO0lBRVMsV0FBVyxDQUFDLEtBQWE7UUFDL0IsSUFBSSxDQUFDLFlBQVksR0FBRyxLQUFLLENBQUM7SUFDOUIsQ0FBQztJQUVTLFNBQVM7UUFDZixPQUFPLElBQUksQ0FBQyxXQUFXLENBQUM7SUFDNUIsQ0FBQztJQUVTLGVBQWU7UUFDckIsT0FBTyxDQUFDLEdBQUcsQ0FBQyx1QkFBdUIsRUFBRSxJQUFJLENBQUMsWUFBWSxDQUFDLENBQUM7UUFDeEQsT0FBTyxJQUFJLENBQUMsWUFBWSxDQUFDO0lBQzdCLENBQUM7SUFFUyxVQUFVLENBQUMsVUFBa0I7UUFDbkMsT0FBTyxJQUFJLENBQUMsYUFBYSxDQUFDLFVBQVUsQ0FBQyxVQUFVLENBQUMsQ0FBQztJQUNyRCxDQUFDO0lBRVMsUUFBUSxDQUFDLFlBQW9CO1FBQ25DLE9BQU8sSUFBSSxDQUFDLGFBQWEsQ0FBQyxRQUFRLENBQUMsWUFBWSxDQUFDLENBQUM7SUFDckQsQ0FBQztJQUVTLFNBQVMsQ0FBQyxLQUFhO1FBQzdCLE9BQU8sSUFBSSxDQUFDLGFBQWEsQ0FBQyxTQUFTLENBQUMsS0FBSyxFQUFFLEdBQUcsQ0FBQyxDQUFDO0lBQ3BELENBQUM7SUFHUyxJQUFJLENBQUMsS0FBYTtRQUN4QixPQUFPLElBQUksQ0FBQyxhQUFhLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFDO0lBQzFDLENBQUM7Q0FDSiIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IFN1YnNjcmlwdGlvbiB9IGZyb20gJ3J4anMnO1xyXG5pbXBvcnQgeyBSb3V0ZXIsIE5hdmlnYXRpb25FbmQsIEFjdGl2YXRlZFJvdXRlLCBQYXJhbXMgfSBmcm9tICdAYW5ndWxhci9yb3V0ZXInO1xyXG5pbXBvcnQgeyBLZEFsZXJ0RXZlbnQgfSBmcm9tICcuLi8uLi9rZC1hbmd1bGFyLWFsZXJ0L2luZGV4JztcclxuaW1wb3J0IHsgS2RDb252ZXJ0aW9uU3ZjLCBLZERhdGFTdmMgfSBmcm9tICcuLi9pbmRleCc7XHJcbmltcG9ydCB7IElQYWdlaGVhZGVyQ29uZmlnIH0gZnJvbSAnLi4vLi4vaW5kZXgnO1xyXG5cclxuaW1wb3J0IHsgS2RQYWdlQmFzZUV2ZW50IH0gZnJvbSAnLi9rZC1wYWdlLWJhc2UuZXZlbnQnO1xyXG5cclxuZXhwb3J0IGludGVyZmFjZSBJUGFnZUJhc2VPcHRpb25zIHtcclxuICAgIHJvdXRlcjogUm91dGVyO1xyXG4gICAgYWN0aXZhdGVkUm91dGU6IEFjdGl2YXRlZFJvdXRlO1xyXG4gICAgcGFnZUV2ZW50PzogS2RQYWdlQmFzZUV2ZW50IHwgYW55O1xyXG4gICAgcGFnZUJhc2VFdmVudD86IEtkUGFnZUJhc2VFdmVudDtcclxuICAgIGFsZXJ0RXZlbnQ/OiBLZEFsZXJ0RXZlbnQ7XHJcbiAgICAvLyBtb2RhbEV2ZW50PzogS2RNb2RhbEV2ZW50O1xyXG59XHJcblxyXG5leHBvcnQgY2xhc3MgS2RQYWdlQmFzZSB7XHJcbiAgICBwcml2YXRlIF90ZXh0T21pdHRlZDogc3RyaW5nID0gJyc7XHJcbiAgICBwcml2YXRlIF9oZWFkZXI6IGFueSA9IHtcclxuICAgICAgICBicmFuZExvZ286IHt9LFxyXG4gICAgICAgIHVzZXJJbmZvOiB7XHJcbiAgICAgICAgICAgIG5hbWU6ICcnLFxyXG4gICAgICAgICAgICBpbWdUeXBlOiAnaWNvbicsXHJcbiAgICAgICAgICAgIGltZ1NyYzogJycsXHJcbiAgICAgICAgICAgIHBhdGg6ICcnXHJcbiAgICAgICAgfSxcclxuICAgICAgICBidG5Hcm91cDogW11cclxuICAgIH07XHJcblxyXG4gICAgcHJpdmF0ZSBfcGFnZWhlYWRlcjogSVBhZ2VoZWFkZXJDb25maWcgPSB7XHJcbiAgICAgICAgcGFnZWhlYWRlclRleHQ6ICcnLFxyXG4gICAgICAgIGxlZnRCdG46IFtdLFxyXG4gICAgICAgIC8vIGxlZnRCdG46IFt7XHJcbiAgICAgICAgLy8gICAgIHR5cGU6ICdhZGQnXHJcbiAgICAgICAgLy8gfV0sXHJcbiAgICAgICAgbW9yZUJ0bjogZmFsc2UsXHJcbiAgICAgICAgbW9yZUFjdGlvbjogW10sXHJcbiAgICAgICAgc2VhcmNoQnRuOiBmYWxzZSxcclxuICAgICAgICBzZWFyY2hFdmVudDogWydjaGFuZ2UnLCAna2V5dXAnXVxyXG4gICAgfTtcclxuXHJcbiAgICBwcml2YXRlIF9icmVhZGNydW1iTGlzdDogYW55ID0ge1xyXG4gICAgICAgIGhvbWU6IHsgaWNvbjogJ2ZhIGZhLWhvbWUnLCB1cmw6ICcnLCBwYXRoOiAnL0FwcC9JbnN0aXR1dGlvbkNsYXNzZXMvbGlzdCcgfSxcclxuICAgICAgICBsaXN0OiBbXVxyXG4gICAgfTtcclxuICAgIHByaXZhdGUgX3BhZ2VQYXJhbXM6IGFueSA9IHt9O1xyXG4gICAgcHJpdmF0ZSBfcHJldlBhZ2VVUkw6IHN0cmluZyA9ICcnO1xyXG4gICAgcHVibGljIGNvbnZlcnRpb25TdmM6IEtkQ29udmVydGlvblN2YztcclxuICAgIHB1YmxpYyBkYXRhU3ZjOiBLZERhdGFTdmM7XHJcbiAgICAvLyBwcml2YXRlIF9hbGVydEV2ZW50OiBLZEFsZXJ0RXZlbnQ7XHJcblxyXG4gICAgcHJpdmF0ZSBfcm91dGVyU3ViOiBTdWJzY3JpcHRpb247XHJcbiAgICBwcml2YXRlIF9hY3RpdmF0ZWRSb3V0ZVN1YjogU3Vic2NyaXB0aW9uO1xyXG4gICAgcHJpdmF0ZSBfY3VycmVudFVSTDogc3RyaW5nID0gJyc7XHJcbiAgICBjb25zdHJ1Y3RvcihcclxuICAgICAgICBwdWJsaWMgb3B0aW9uczogSVBhZ2VCYXNlT3B0aW9uc1xyXG4gICAgKSB7XHJcbiAgICAgICAgdGhpcy5jb252ZXJ0aW9uU3ZjID0gbmV3IEtkQ29udmVydGlvblN2YygpO1xyXG4gICAgICAgIHRoaXMuZGF0YVN2YyA9IG5ldyBLZERhdGFTdmMoKTtcclxuXHJcbiAgICAgICAgLy8gdGhpcy5fcHJldlBhZ2VJbmZvID0gdGhpcy5pbml0UHJldkhpc3RvcnkoKTtcclxuICAgICAgICAvLyB0aGlzLm9wdGlvbnMucm91dGVyLmV2ZW50c1xyXG4gICAgICAgIC8vICAgICAuZmlsdGVyKGUgPT4gZSBpbnN0YW5jZW9mIFJvdXRlc1JlY29nbml6ZWQpXHJcbiAgICAgICAgLy8gICAgIC8vIC5maWx0ZXIoZSA9PiAoZS5jb25zdHJ1Y3Rvci5uYW1lID09PSAnUm91dGVzUmVjb2duaXplZCcpIHx8ICggZS5jb25zdHJ1Y3Rvci5uYW1lID09PSAnTmF2aWdhdGlvbkVuZCcpKVxyXG4gICAgICAgIC8vICAgICAucGFpcndpc2UoKVxyXG4gICAgICAgIC8vICAgICAuc3Vic2NyaWJlKChlOiBhbnlbXSk6IHZvaWQgPT4ge1xyXG4gICAgICAgIC8vICAgICAgICAgY29uc29sZS5sb2coJzEgb24gaW5pdCA+IHVybCBpbmZvICcsIGUpO1xyXG4gICAgICAgIC8vICAgICAgICAgY29uc29sZS5sb2cobmV3IERhdGUoKSk7XHJcbiAgICAgICAgLy8gICAgICAgICBjb25zb2xlLmxvZyhlWzBdKTtcclxuICAgICAgICAvLyAgICAgICAgIGNvbnNvbGUubG9nKGVbZS5sZW5ndGggLSAxXSk7XHJcbiAgICAgICAgLy8gICAgICAgICB0aGlzLl9wcmV2UGFnZUluZm8gPSBlWzBdLnVybEFmdGVyUmVkaXJlY3RzO1xyXG4gICAgICAgIC8vICAgICAgICAgLy8gY29uc29sZS5sb2coJ3RoaXMuX3ByZXZQYWdlSW5mbyA9ID4gJywgdGhpcy5fcHJldlBhZ2VJbmZvKTtcclxuICAgICAgICAvLyAgICAgICAgIC8vIHRoaXMuX3JvdXRlckhpc3RvcnlTdWIudW5zdWJzY3JpYmUoKTtcclxuICAgICAgICAvLyAgICAgfSk7XHJcblxyXG4gICAgICAgIC8vIGNvbnNvbGUubG9nKCdjb25zdHJ1Y3RvciA+PiAnLHRoaXMuX3ByZXZQYWdlSW5mbyk7XHJcbiAgICAgICAgdGhpcy5fcm91dGVyU3ViID0gdGhpcy5vcHRpb25zLnJvdXRlci5ldmVudHNcclxuICAgICAgICAgICAgLnN1YnNjcmliZShldmVudCA9PiB7XHJcbiAgICAgICAgICAgICAgICAvLyBpZiAoZXZlbnQgaW5zdGFuY2VvZiBSb3V0ZXNSZWNvZ25pemVkKSB7XHJcbiAgICAgICAgICAgICAgICAvLyBjb25zb2xlLmxvZygnUm91dGVzUmVjb2duaXplZCA+IGV2ZW50IC0gJywgT2JqZWN0LmFzc2lnbih7fSwgZXZlbnQpKTtcclxuICAgICAgICAgICAgICAgIC8vIH1cclxuICAgICAgICAgICAgICAgIGlmIChldmVudCBpbnN0YW5jZW9mIE5hdmlnYXRpb25FbmQpIHtcclxuICAgICAgICAgICAgICAgICAgICAvLyBjb25zb2xlLmxvZygnPj4nLCBldmVudCk7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5fcHJldlBhZ2VVUkwgPSBKU09OLnN0cmluZ2lmeSh0aGlzLl9jdXJyZW50VVJMKTtcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLl9jdXJyZW50VVJMID0gZXZlbnQudXJsQWZ0ZXJSZWRpcmVjdHM7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5fYnJlYWRjcnVtYkxpc3QubGlzdCA9IHRoaXMuY29udmVydGlvblN2Yy51cmxUb0FycmF5KGV2ZW50LnVybEFmdGVyUmVkaXJlY3RzLCB0aGlzLl90ZXh0T21pdHRlZCk7XHJcbiAgICAgICAgICAgICAgICAgICAgLy8gY29uc29sZS5sb2coJ3RoaXMuX2JyZWFkY3J1bWJMaXN0Lmxpc3QnLHRoaXMuX2JyZWFkY3J1bWJMaXN0Lmxpc3QpO1xyXG4gICAgICAgICAgICAgICAgICAgIGlmICh0eXBlb2YgdGhpcy5vcHRpb25zLnBhZ2VFdmVudCAhPT0gJ3VuZGVmaW5lZCcpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5vcHRpb25zLnBhZ2VFdmVudC5hcHBSZWFkeSgpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLm9wdGlvbnMucGFnZUV2ZW50Lm9uQXBwUmVhZHlDb21wbGV0ZSgpO1xyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKHR5cGVvZiB0aGlzLm9wdGlvbnMucGFnZUJhc2VFdmVudCAhPT0gJ3VuZGVmaW5lZCcpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgY29uc29sZS5lcnJvcigncGxlYXNlIGNoYW5nZSB0byBQYWdlRXZlbnQgaW5zdGVhZCBvZiBQYWdlQmFzZUV2ZW50Jyk7XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9KTtcclxuXHJcbiAgICAgICAgdGhpcy5fYWN0aXZhdGVkUm91dGVTdWIgPSB0aGlzLm9wdGlvbnMuYWN0aXZhdGVkUm91dGUucGFyYW1zLnN1YnNjcmliZSgoX3BhcmFtczogUGFyYW1zKTogdm9pZCA9PiB7XHJcbiAgICAgICAgICAgIHRoaXMuX3BhZ2VQYXJhbXMgPSBfcGFyYW1zO1xyXG4gICAgICAgIH0pO1xyXG4gICAgfVxyXG4gICAgLy8gcHJvdGVjdGVkIGVuYWJsZUxvYWRWMihfYm9vbDogYm9vbGVhbikge1xyXG4gICAgLy8gICAgIC8vIHRoaXMub3B0aW9ucy5wYWdlRXZlbnQubG9hZFYyKF9ib29sKTtcclxuICAgIC8vIH1cclxuXHJcbiAgICAvKipcclxuICAgICAqIFtkZXN0cm95UGFnZUJhc2VTdWIgLSBNYW51YWxseSBkaXNjYXJkIHRoZSBhbGwgdGhlIHN1YnNjcmlwdGlvbnNdXHJcbiAgICAgKi9cclxuICAgIHByb3RlY3RlZCBkZXN0cm95UGFnZUJhc2VTdWIoKTogdm9pZCB7XHJcbiAgICAgICAgaWYgKHR5cGVvZiB0aGlzLl9yb3V0ZXJTdWIgIT09ICd1bmRlZmluZWQnKSB0aGlzLl9yb3V0ZXJTdWIudW5zdWJzY3JpYmUoKTtcclxuICAgICAgICBpZiAodHlwZW9mIHRoaXMuX2FjdGl2YXRlZFJvdXRlU3ViICE9PSAndW5kZWZpbmVkJykgdGhpcy5fYWN0aXZhdGVkUm91dGVTdWIudW5zdWJzY3JpYmUoKTtcclxuICAgIH1cclxuXHJcbiAgICAvKipcclxuICAgICAqIEFwcGxpY2F0aW9uIEhlYWRlciAoUHJvZHVjdCBIZWFkZXIpXHJcbiAgICAgKi9cclxuXHJcbiAgICBwcm90ZWN0ZWQgZ2V0SGVhZGVyQ29uZmlnKCk6IGFueSB7XHJcbiAgICAgICAgcmV0dXJuIHRoaXMuX2hlYWRlci51c2VySW5mbztcclxuICAgIH1cclxuXHJcbiAgICBwcm90ZWN0ZWQgc2V0SGVhZGVyQ29uZmlnKF9jb25mOiBhbnkpIHtcclxuICAgICAgICB0aGlzLl9oZWFkZXIudXNlckluZm8gPSBfY29uZjtcclxuICAgIH1cclxuXHJcbiAgICBwcm90ZWN0ZWQgdXBkYXRlSGVhZGVyKCkge1xyXG4gICAgICAgIHRoaXMub3B0aW9ucy5wYWdlRXZlbnQudXBkYXRlSGVhZGVyKHRoaXMuX2hlYWRlcik7XHJcbiAgICB9XHJcblxyXG4gICAgLyoqXHJcbiAgICAgKiBMZWZ0IE5hdmlnYXRpb25cclxuICAgICAqL1xyXG5cclxuICAgIHByb3RlY3RlZCBzZXRMZWZ0TWVudUxpc3QoX2xlZnRNZW51T2JqOiBhbnkpIHtcclxuICAgICAgICB0aGlzLm9wdGlvbnMucGFnZUV2ZW50LnVwZGF0ZUxlZnRtZW51KF9sZWZ0TWVudU9iaik7XHJcbiAgICB9XHJcblxyXG4gICAgLyoqXHJcbiAgICAgKiBQYWdlIEhlYWRlclxyXG4gICAgICovXHJcblxyXG4gICAgcHJvdGVjdGVkIGdldFBhZ2VUaXRsZSgpOiBzdHJpbmcge1xyXG4gICAgICAgIHJldHVybiB0aGlzLl9wYWdlaGVhZGVyLnBhZ2VoZWFkZXJUZXh0O1xyXG4gICAgfVxyXG5cclxuICAgIHByb3RlY3RlZCBzZXRQYWdlVGl0bGUoX3RpdGxlOiBzdHJpbmcsIF9odW1hbml6ZTogYm9vbGVhbiA9IHRydWUpIHtcclxuICAgICAgICBsZXQgdGVtcFN0cjogc3RyaW5nID0gX3RpdGxlLnJlcGxhY2UodGhpcy5fdGV4dE9taXR0ZWQsICcnKTtcclxuICAgICAgICBpZiAoX2h1bWFuaXplKSB7XHJcbiAgICAgICAgICAgIHRlbXBTdHIgPSB0aGlzLmh1bWFuaXplKHRoaXMudW5kZXJzY29yZSh0ZW1wU3RyKSk7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIC8vIGNvbnNvbGUubG9nKCdzZXRQYWdlVGl0bGU9Jyx0ZW1wU3RyKTtcclxuICAgICAgICB0aGlzLl9wYWdlaGVhZGVyLnBhZ2VoZWFkZXJUZXh0ID0gdGVtcFN0cjtcclxuICAgIH1cclxuXHJcbiAgICBwcm90ZWN0ZWQgZ2V0VG9vbGJhck1haW5CdG5zKCk6IEFycmF5PGFueT4ge1xyXG4gICAgICAgIHJldHVybiBKU09OLnBhcnNlKEpTT04uc3RyaW5naWZ5KHRoaXMuX3BhZ2VoZWFkZXIubGVmdEJ0bikpO1xyXG4gICAgfVxyXG5cclxuICAgIHByb3RlY3RlZCBzZXRUb29sYmFyTWFpbkJ0bnMoX2J1dHRvbnM6IEFycmF5PGFueT4pIHtcclxuICAgICAgICB0aGlzLl9wYWdlaGVhZGVyLmxlZnRCdG4gPSBfYnV0dG9ucztcclxuICAgIH1cclxuXHJcbiAgICBwcm90ZWN0ZWQgZ2V0VG9vbGJhck1vcmVBY3Rpb25CdG5zKCk6IEFycmF5PGFueT4ge1xyXG4gICAgICAgIHJldHVybiB0aGlzLl9wYWdlaGVhZGVyLm1vcmVBY3Rpb247XHJcbiAgICB9XHJcblxyXG4gICAgcHJvdGVjdGVkIGVuYWJsZU1vcmVBY3Rpb25CdG5zKF9lbmFibGU6IGJvb2xlYW4sIF9idXR0b25zPzogQXJyYXk8YW55Pikge1xyXG4gICAgICAgIHRoaXMuX3BhZ2VoZWFkZXIubW9yZUJ0biA9IF9lbmFibGU7XHJcbiAgICAgICAgaWYgKF9idXR0b25zKSB7XHJcbiAgICAgICAgICAgIHRoaXMuX3BhZ2VoZWFkZXIubW9yZUFjdGlvbiA9IF9idXR0b25zO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICBwcm90ZWN0ZWQgZW5hYmxlVG9vbGJhclNlYXJjaChfZW5hYmxlOiBib29sZWFuLCBfY2FsbGJhY2s/OiAoX3RleHQ6IHN0cmluZykgPT4gdm9pZCkge1xyXG4gICAgICAgIHRoaXMuX3BhZ2VoZWFkZXIuc2VhcmNoQnRuID0gX2VuYWJsZTtcclxuICAgICAgICBpZiAoX2VuYWJsZSAmJiBfY2FsbGJhY2spIHtcclxuICAgICAgICAgICAgdGhpcy5fcGFnZWhlYWRlci5zZWFyY2hDYWxsYmFjayA9IF9jYWxsYmFjaztcclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgcHJvdGVjdGVkIHVwZGF0ZVNlYXJjaFRleHQoX3NlYXJjaFRleHQ6IHN0cmluZykge1xyXG4gICAgICAgIHRoaXMuX3BhZ2VoZWFkZXIuc2VhcmNoVGV4dCA9IF9zZWFyY2hUZXh0O1xyXG4gICAgfVxyXG5cclxuICAgIHByb3RlY3RlZCB1cGRhdGVQYWdlSGVhZGVyKCkge1xyXG4gICAgICAgIGNvbnNvbGUubG9nKCdicm9hZGNhc3QgdXBkYXRlUGFnZUhlYWRlcicsIHRoaXMuX3BhZ2VoZWFkZXIpO1xyXG4gICAgICAgIHRoaXMub3B0aW9ucy5wYWdlRXZlbnQudXBkYXRlUGFnZUhlYWRlcih0aGlzLl9wYWdlaGVhZGVyKTtcclxuICAgIH1cclxuXHJcbiAgICAvKipcclxuICAgICAqIEJyZWFkY3J1bWJzXHJcbiAgICAgKi9cclxuXHJcbiAgICBwcm90ZWN0ZWQgc2V0QnJlYWRjcnVtYnNMaXN0KF9saXN0OiBBcnJheTxhbnk+KTogdm9pZCB7XHJcbiAgICAgICAgdGhpcy5fYnJlYWRjcnVtYkxpc3QubGlzdCA9IF9saXN0O1xyXG4gICAgICAgIHRoaXMudXBkYXRlQnJlYWRjcnVtYigpO1xyXG4gICAgfVxyXG5cclxuICAgIHByb3RlY3RlZCBnZXRCcmVhZGNydW1ic0xpc3QoKTogQXJyYXk8YW55PiB7XHJcbiAgICAgICAgcmV0dXJuIHRoaXMuX2JyZWFkY3J1bWJMaXN0Lmxpc3Q7XHJcbiAgICB9XHJcblxyXG4gICAgcHJvdGVjdGVkIHVwZGF0ZUJyZWFkY3J1bWIoKTogdm9pZCB7XHJcbiAgICAgICAgdGhpcy5vcHRpb25zLnBhZ2VFdmVudC51cGRhdGVCcmVhZGNydW1iKEpTT04ucGFyc2UoSlNPTi5zdHJpbmdpZnkodGhpcy5fYnJlYWRjcnVtYkxpc3QpKSk7XHJcbiAgICB9XHJcblxyXG4gICAgLyoqXHJcbiAgICAgKiBBbGVydHNcclxuICAgICAqL1xyXG5cclxuICAgIHByb3RlY3RlZCBzZXRBbGVydChfY29uZmlnOiBhbnksIF90eXBlOiBzdHJpbmcpOiB2b2lkIHtcclxuICAgICAgICBpZiAodGhpcy5vcHRpb25zLmFsZXJ0RXZlbnQpIHtcclxuICAgICAgICAgICAgdGhpcy5vcHRpb25zLmFsZXJ0RXZlbnRbX3R5cGVdKF9jb25maWcpO1xyXG4gICAgICAgIH1cclxuICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgY29uc29sZS53YXJuKCdNaXNzaW5nIGV2ZW50IC0gS2RBbGVydEV2ZW50Jyk7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIC8qKlxyXG4gICAgICogW3NldE1vZGFsIENyZWF0aW5nIG1vZGFsIHZpZXddXHJcbiAgICAgKiAgX2NvbmZpZ0NvbmZpbWF0aW9uIHtcclxuICAgICAqICAgICAgICAgICAgICBoZWFkZXI6ICcnLFxyXG4gICAgICogICAgICAgICAgICAgIG1lc3NhZ2U6ICcnLFxyXG4gICAgICogICAgICAgICAgICAgIGJ1dHRvbkNvbmZpcm06IHtcclxuICAgICAqICAgICAgICAgICAgICAgICAgdGV4dDogJ3Rlc3QgdGV4dCcsXHJcbiAgICAgKiAgICAgICAgICAgICAgICAgIGNhbGxiYWNrOiAoKSA9PntcclxuICAgICAqXHJcbiAgICAgKiAgICAgICAgICAgICAgICAgIH1cclxuICAgICAqICAgICAgICAgICAgICB9XHJcbiAgICAgKiAgICAgICAgICB9XHJcbiAgICAgKi9cclxuICAgIHByb3RlY3RlZCBzZXRNb2RhbCgpOiB7IGNvbmZpcm1hdGlvbjogRnVuY3Rpb24sIG5vdGlmeTogRnVuY3Rpb24sIGRpc2FibGVkOiBGdW5jdGlvbiwgY2xvc2U6IEZ1bmN0aW9uIH0ge1xyXG4gICAgICAgIGxldCBfcGFnZUJhc2VFdmVudDogS2RQYWdlQmFzZUV2ZW50O1xyXG4gICAgICAgIGlmICh0aGlzLm9wdGlvbnMucGFnZUV2ZW50KSB7XHJcbiAgICAgICAgICAgIF9wYWdlQmFzZUV2ZW50ID0gdGhpcy5vcHRpb25zLnBhZ2VFdmVudDtcclxuICAgICAgICB9XHJcbiAgICAgICAgZWxzZSB7XHJcbiAgICAgICAgICAgIGNvbnNvbGUud2FybignUGxlYXNlIGltcG9ydCBcXCdQYWdlQmFzZUV2ZW50XFwnIHRvIHVzZSBtb2RhbCcpO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgLyoqXHJcbiAgICAgICAgICogW2NvbmZpcm1hdGlvbiBhIG1vZGFsIGRpYWxvZyB3aXRoIDIgYnV0dG9uczogJ0NvbmZpcm0nIGFuZCAnQ2FuY2VsJ11cclxuICAgICAgICAgKi9cclxuICAgICAgICBmdW5jdGlvbiBjb25maXJtYXRpb24oX2NvbmZpZz86IGFueSk6IHZvaWQge1xyXG4gICAgICAgICAgICBpZiAoX3BhZ2VCYXNlRXZlbnQpIHtcclxuICAgICAgICAgICAgICAgIGxldCB1cGRhdGVkQ29uZmlnOiBhbnkgPSB7fTtcclxuICAgICAgICAgICAgICAgIGxldCBkZWZhdWx0Q29uZmlnOiBhbnkgPSB7XHJcbiAgICAgICAgICAgICAgICAgICAgc3VzcGVuZENsb3NlOiB0cnVlLFxyXG4gICAgICAgICAgICAgICAgICAgIHRpdGxlOiAnQWxlcnQnLFxyXG4gICAgICAgICAgICAgICAgICAgIGJvZHk6ICdEdW1teSB0ZXh0IC0gY29uZmlybWF0aW9uJyxcclxuICAgICAgICAgICAgICAgICAgICBidXR0b246IFt7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHRleHQ6ICdDb25maXJtJyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3M6ICdidG4tdGV4dCcsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNhbGxiYWNrOiAoKTogdm9pZCA9PiB7IH1cclxuICAgICAgICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgdGV4dDogJ0NhbmNlbCcsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzOiAnYnRuLW91dGxpbmUnLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBjYWxsYmFjazogKCk6IHZvaWQgPT4geyBfcGFnZUJhc2VFdmVudC51cGRhdGVNb2RhbCh7IGNsb3NlOiB0cnVlIH0pOyB9XHJcbiAgICAgICAgICAgICAgICAgICAgfV1cclxuICAgICAgICAgICAgICAgIH07XHJcblxyXG4gICAgICAgICAgICAgICAgdXBkYXRlZENvbmZpZyA9IGFwcGx5Q29uZmlnKF9jb25maWcsIGRlZmF1bHRDb25maWcpO1xyXG4gICAgICAgICAgICAgICAgX3BhZ2VCYXNlRXZlbnQudXBkYXRlTW9kYWwoeyBlbmFibGVkOiB0cnVlLCBjb25maWc6IHVwZGF0ZWRDb25maWcgfSk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIC8qKlxyXG4gICAgICAgICAqIFtub3RpZnkgYSBtb2RhbCBkaWFsb2cgd2l0aCAxIGJ1dHRvbjogJ0RvbmUnXVxyXG4gICAgICAgICAqL1xyXG4gICAgICAgIGZ1bmN0aW9uIG5vdGlmeShfY29uZmlnPzogYW55KTogdm9pZCB7XHJcbiAgICAgICAgICAgIGlmIChfcGFnZUJhc2VFdmVudCkge1xyXG4gICAgICAgICAgICAgICAgbGV0IHVwZGF0ZWRDb25maWc6IGFueSA9IHt9O1xyXG4gICAgICAgICAgICAgICAgbGV0IGRlZmF1bHRDb25maWc6IGFueSA9IHtcclxuICAgICAgICAgICAgICAgICAgICBzdXNwZW5kQ2xvc2U6IHRydWUsXHJcbiAgICAgICAgICAgICAgICAgICAgdGl0bGU6ICdBbGVydCcsXHJcbiAgICAgICAgICAgICAgICAgICAgYm9keTogJ0R1bW15IHRleHQgLSBub3RpZnknLFxyXG4gICAgICAgICAgICAgICAgICAgIGJ1dHRvbjogW3tcclxuICAgICAgICAgICAgICAgICAgICAgICAgdGV4dDogJ0RvbmUnLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBjbGFzczogJ2J0bi10ZXh0JyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgY2FsbGJhY2s6ICgpOiB2b2lkID0+IHsgX3BhZ2VCYXNlRXZlbnQudXBkYXRlTW9kYWwoeyBjbG9zZTogdHJ1ZSB9KTsgfVxyXG4gICAgICAgICAgICAgICAgICAgIH1dXHJcbiAgICAgICAgICAgICAgICB9O1xyXG5cclxuICAgICAgICAgICAgICAgIHVwZGF0ZWRDb25maWcgPSBhcHBseUNvbmZpZyhfY29uZmlnLCBkZWZhdWx0Q29uZmlnKTtcclxuICAgICAgICAgICAgICAgIF9wYWdlQmFzZUV2ZW50LnVwZGF0ZU1vZGFsKHsgZW5hYmxlZDogdHJ1ZSwgY29uZmlnOiB1cGRhdGVkQ29uZmlnIH0pO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICBmdW5jdGlvbiBkaXNhYmxlZCgpOiB2b2lkIHtcclxuICAgICAgICAgICAgaWYgKF9wYWdlQmFzZUV2ZW50KSBfcGFnZUJhc2VFdmVudC51cGRhdGVNb2RhbCh7IGVuYWJsZWQ6IGZhbHNlIH0pO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgZnVuY3Rpb24gY2xvc2UoKTogdm9pZCB7XHJcbiAgICAgICAgICAgIGlmIChfcGFnZUJhc2VFdmVudCkgX3BhZ2VCYXNlRXZlbnQudXBkYXRlTW9kYWwoeyBjbG9zZTogdHJ1ZSB9KTtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIGZ1bmN0aW9uIGFwcGx5Q29uZmlnKF9zb3VyY2VDb25maWc6IGFueSwgX3RhcmdldENvbmZpZzogYW55KToge30ge1xyXG4gICAgICAgICAgICBsZXQgdXBkYXRlZENvbmZpZzogYW55ID0ge307XHJcbiAgICAgICAgICAgICg8YW55Pk9iamVjdCkuYXNzaWduKHVwZGF0ZWRDb25maWcsIF90YXJnZXRDb25maWcpO1xyXG5cclxuICAgICAgICAgICAgaWYgKF9zb3VyY2VDb25maWcuaGVhZGVyKSB1cGRhdGVkQ29uZmlnLnRpdGxlID0gX3NvdXJjZUNvbmZpZy5oZWFkZXI7XHJcbiAgICAgICAgICAgIGlmIChfc291cmNlQ29uZmlnLm1lc3NhZ2UpIHVwZGF0ZWRDb25maWcuYm9keSA9IF9zb3VyY2VDb25maWcubWVzc2FnZTtcclxuICAgICAgICAgICAgaWYgKF9zb3VyY2VDb25maWcuYnV0dG9uQ29uZmlybSkge1xyXG4gICAgICAgICAgICAgICAgaWYgKF9zb3VyY2VDb25maWcuYnV0dG9uQ29uZmlybS50ZXh0KSB1cGRhdGVkQ29uZmlnLmJ1dHRvblswXS50ZXh0ID0gX3NvdXJjZUNvbmZpZy5idXR0b25Db25maXJtLnRleHQ7XHJcbiAgICAgICAgICAgICAgICBpZiAoX3NvdXJjZUNvbmZpZy5idXR0b25Db25maXJtLmNhbGxiYWNrKSB1cGRhdGVkQ29uZmlnLmJ1dHRvblswXS5jYWxsYmFjayA9IF9zb3VyY2VDb25maWcuYnV0dG9uQ29uZmlybS5jYWxsYmFjaztcclxuICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgcmV0dXJuIHVwZGF0ZWRDb25maWc7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICByZXR1cm4ge1xyXG4gICAgICAgICAgICBjb25maXJtYXRpb246IGNvbmZpcm1hdGlvbixcclxuICAgICAgICAgICAgbm90aWZ5OiBub3RpZnksXHJcbiAgICAgICAgICAgIGRpc2FibGVkOiBkaXNhYmxlZCxcclxuICAgICAgICAgICAgY2xvc2U6IGNsb3NlXHJcbiAgICAgICAgfTtcclxuICAgIH1cclxuXHJcblxyXG5cclxuICAgIC8qKlxyXG4gICAgICogVXRpbHMgTWV0aG9kc1xyXG4gICAgICovXHJcblxyXG4gICAgLy8gcHJpdmF0ZSBpbml0UHJldkhpc3RvcnkoKXtcclxuICAgIC8vICAgICAvLyB0aGlzLl9yb3V0ZXJIaXN0b3J5U3ViID0gdGhpcy5vcHRpb25zLnJvdXRlci5ldmVudHNcclxuICAgIC8vICAgICByZXR1cm4gdGhpcy5vcHRpb25zLnJvdXRlci5ldmVudHNcclxuICAgIC8vICAgICAgICAgLmZpbHRlcihlID0+IGUgaW5zdGFuY2VvZiBSb3V0ZXNSZWNvZ25pemVkKVxyXG4gICAgLy8gICAgICAgICAvLyAuZmlsdGVyKGUgPT4gKGUuY29uc3RydWN0b3IubmFtZSA9PT0gJ1JvdXRlc1JlY29nbml6ZWQnKSB8fCAoIGUuY29uc3RydWN0b3IubmFtZSA9PT0gJ05hdmlnYXRpb25FbmQnKSlcclxuICAgIC8vICAgICAgICAgLnBhaXJ3aXNlKClcclxuICAgIC8vICAgICAgICAgLnN1YnNjcmliZSgoZTogYW55W10pOiB2b2lkID0+IHtcclxuICAgIC8vICAgICAgICAgICAgIGNvbnNvbGUubG9nKCcxIG9uIGluaXQgPiB1cmwgaW5mbyAnLCBlKTtcclxuICAgIC8vICAgICAgICAgICAgIGNvbnNvbGUubG9nKG5ldyBEYXRlKCkpO1xyXG4gICAgLy8gICAgICAgICAgICAgY29uc29sZS5sb2coZVswXSk7XHJcbiAgICAvLyAgICAgICAgICAgICBjb25zb2xlLmxvZyhlW2UubGVuZ3RoIC0gMV0pO1xyXG4gICAgLy8gICAgICAgICAgICAgcmV0dXJuIGVbMF07XHJcbiAgICAvLyAgICAgICAgICAgICAvLyBjb25zb2xlLmxvZygndGhpcy5fcHJldlBhZ2VJbmZvID0gPiAnLCB0aGlzLl9wcmV2UGFnZUluZm8pO1xyXG4gICAgLy8gICAgICAgICAgICAgLy8gdGhpcy5fcm91dGVySGlzdG9yeVN1Yi51bnN1YnNjcmliZSgpO1xyXG4gICAgLy8gICAgICAgICB9KTtcclxuICAgIC8vIH1cclxuXHJcbiAgICBwcm90ZWN0ZWQgZ2V0Q3VycmVudFVSTCgpOiBzdHJpbmcge1xyXG4gICAgICAgIHJldHVybiB0aGlzLl9jdXJyZW50VVJMO1xyXG4gICAgfVxyXG5cclxuICAgIHByb3RlY3RlZCBzZXRUZXh0T21pdChfdGV4dDogc3RyaW5nKSB7XHJcbiAgICAgICAgdGhpcy5fdGV4dE9taXR0ZWQgPSBfdGV4dDtcclxuICAgIH1cclxuXHJcbiAgICBwcm90ZWN0ZWQgZ2V0UGFyYW1zKCk6IGFueSB7XHJcbiAgICAgICAgcmV0dXJuIHRoaXMuX3BhZ2VQYXJhbXM7XHJcbiAgICB9XHJcblxyXG4gICAgcHJvdGVjdGVkIGdldFByZXZQYWdlSW5mbygpOiBzdHJpbmcge1xyXG4gICAgICAgIGNvbnNvbGUubG9nKCdnZXRQcmV2UGFnZUluZm8gLiA+PiAnLCB0aGlzLl9wcmV2UGFnZVVSTCk7XHJcbiAgICAgICAgcmV0dXJuIHRoaXMuX3ByZXZQYWdlVVJMO1xyXG4gICAgfVxyXG5cclxuICAgIHByb3RlY3RlZCB1bmRlcnNjb3JlKF9jYW1lbENhc2U6IHN0cmluZyk6IHN0cmluZyB7XHJcbiAgICAgICAgcmV0dXJuIHRoaXMuY29udmVydGlvblN2Yy51bmRlcnNjb3JlKF9jYW1lbENhc2UpO1xyXG4gICAgfVxyXG5cclxuICAgIHByb3RlY3RlZCBodW1hbml6ZShfdW5kZXJzY29yZWQ6IHN0cmluZyk6IHN0cmluZyB7XHJcbiAgICAgICAgcmV0dXJuIHRoaXMuY29udmVydGlvblN2Yy5odW1hbml6ZShfdW5kZXJzY29yZWQpO1xyXG4gICAgfVxyXG5cclxuICAgIHByb3RlY3RlZCBjYW1lbENhc2UoX3RleHQ6IHN0cmluZyk6IHN0cmluZyB7XHJcbiAgICAgICAgcmV0dXJuIHRoaXMuY29udmVydGlvblN2Yy5jYW1lbENhc2UoX3RleHQsICcgJyk7XHJcbiAgICB9XHJcblxyXG5cclxuICAgIHByb3RlY3RlZCBzbHVnKF93b3JkOiBzdHJpbmcpIHtcclxuICAgICAgICByZXR1cm4gdGhpcy5jb252ZXJ0aW9uU3ZjLnNsdWcoX3dvcmQpO1xyXG4gICAgfVxyXG59XHJcbiJdfQ==