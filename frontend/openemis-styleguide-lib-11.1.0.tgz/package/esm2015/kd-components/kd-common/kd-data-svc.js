import { Injectable } from '@angular/core';
import * as i0 from "@angular/core";
export class KdDataSvc {
    getDataValue(_fromObject, _key) {
        let splitArray = _key.split('.');
        let data = _fromObject;
        if (typeof data === 'undefined' || data === null)
            return null;
        for (let i = 0; i < splitArray.length; i++) {
            if (data.hasOwnProperty(splitArray[i]))
                data = data[splitArray[i]];
            else
                return null;
        }
        return data;
    }
    getPlaceholder(_fromObject, _queryString) {
        let updatedString = _queryString.slice();
        let search = _queryString.match(/\$\((.*?)\)/g);
        if (search !== null) {
            for (let i = 0; i < search.length; i++) {
                let searchString = search[i].substring(2, search[i].length - 1);
                let replacedString = this.getDataValue(_fromObject, searchString);
                if (replacedString !== null) {
                    updatedString = updatedString.replace(search[i], replacedString);
                }
            }
        }
        return updatedString;
    }
    /**
     * [deepMergeObject]
     * target        : merge to
     * source        : merge from
     * _returnNewObj : by default is true. It will return a new object. If is false, it will do a direct merge/combine
     *                 a new object. (Optional)
     */
    deepMergeObject(target, source, _returnNewObj) {
        let output = {};
        _returnNewObj = (typeof _returnNewObj === 'undefined') ? true : _returnNewObj;
        output = (_returnNewObj) ? Object.assign({}, target) : target;
        for (let key in source) {
            if (key in output) {
                if (output[key] && typeof output[key] === 'object' && !Array.isArray(output[key])) {
                    output[key] = typeof source[key] !== 'object' ? source[key] : this.deepMergeObject(output[key], source[key]);
                }
                else {
                    Object.assign(output, { [key]: source[key] });
                }
            }
            else {
                Object.assign(output, { [key]: source[key] });
            }
        }
        if (_returnNewObj)
            return output;
    }
    /**
     * combines the source to the target, changing target's key values directly. source key values takes proprioty
     * target        : merge to
     * source        : merge from
     */
    deepCombineObject(target, source) {
        for (let key in source) {
            if (source[key] && typeof source[key] === 'object') {
                if (target[key] && typeof target[key] === 'object' && key in target) {
                    this.deepCombineObject(target[key], source[key]);
                }
                else {
                    Object.assign(target, { [key]: source[key] });
                }
            }
            else {
                target[key] = source[key];
            }
        }
    }
}
KdDataSvc.ɵprov = i0.ɵɵdefineInjectable({ factory: function KdDataSvc_Factory() { return new KdDataSvc(); }, token: KdDataSvc, providedIn: "root" });
KdDataSvc.decorators = [
    { type: Injectable, args: [{
                providedIn: 'root'
            },] }
];
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoia2QtZGF0YS1zdmMuanMiLCJzb3VyY2VSb290IjoiQzovUHJvamVjdHMvQW5ndWxhci9pb3N0Zy1vcGVuZW1pcy1zdHlsZWd1aWRlL3Byb2plY3RzL29wZW5lbWlzLXN0eWxlZ3VpZGUtbGliL3NyYy8iLCJzb3VyY2VzIjpbImtkLWNvbXBvbmVudHMva2QtY29tbW9uL2tkLWRhdGEtc3ZjLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBLE9BQU8sRUFBRSxVQUFVLEVBQUUsTUFBTSxlQUFlLENBQUM7O0FBSzNDLE1BQU0sT0FBTyxTQUFTO0lBQ2xCLFlBQVksQ0FBQyxXQUFnQixFQUFFLElBQVk7UUFDdkMsSUFBSSxVQUFVLEdBQWUsSUFBSSxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FBQztRQUM3QyxJQUFJLElBQUksR0FBUSxXQUFXLENBQUM7UUFDNUIsSUFBSSxPQUFPLElBQUksS0FBSyxXQUFXLElBQUksSUFBSSxLQUFLLElBQUk7WUFBRSxPQUFPLElBQUksQ0FBQztRQUM5RCxLQUFLLElBQUksQ0FBQyxHQUFXLENBQUMsRUFBRSxDQUFDLEdBQUcsVUFBVSxDQUFDLE1BQU0sRUFBRSxDQUFDLEVBQUUsRUFBRTtZQUNoRCxJQUFJLElBQUksQ0FBQyxjQUFjLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQyxDQUFDO2dCQUFFLElBQUksR0FBRyxJQUFJLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7O2dCQUM5RCxPQUFPLElBQUksQ0FBQztTQUNwQjtRQUNELE9BQU8sSUFBSSxDQUFDO0lBQ2hCLENBQUM7SUFFRCxjQUFjLENBQUMsV0FBZ0IsRUFBRSxZQUFvQjtRQUNqRCxJQUFJLGFBQWEsR0FBVyxZQUFZLENBQUMsS0FBSyxFQUFFLENBQUM7UUFDakQsSUFBSSxNQUFNLEdBQWtCLFlBQVksQ0FBQyxLQUFLLENBQUMsY0FBYyxDQUFDLENBQUM7UUFDL0QsSUFBSSxNQUFNLEtBQUssSUFBSSxFQUFFO1lBQ2pCLEtBQUssSUFBSSxDQUFDLEdBQVcsQ0FBQyxFQUFFLENBQUMsR0FBRyxNQUFNLENBQUMsTUFBTSxFQUFFLENBQUMsRUFBRSxFQUFFO2dCQUM1QyxJQUFJLFlBQVksR0FBVyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDLENBQUMsRUFBRSxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxHQUFHLENBQUMsQ0FBQyxDQUFDO2dCQUN4RSxJQUFJLGNBQWMsR0FBVyxJQUFJLENBQUMsWUFBWSxDQUFDLFdBQVcsRUFBRSxZQUFZLENBQUMsQ0FBQztnQkFDMUUsSUFBSSxjQUFjLEtBQUssSUFBSSxFQUFFO29CQUN6QixhQUFhLEdBQUcsYUFBYSxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLEVBQUUsY0FBYyxDQUFDLENBQUM7aUJBQ3BFO2FBQ0o7U0FDSjtRQUNELE9BQU8sYUFBYSxDQUFDO0lBQ3pCLENBQUM7SUFFRDs7Ozs7O09BTUc7SUFDSCxlQUFlLENBQUMsTUFBVyxFQUFFLE1BQVcsRUFBRSxhQUF1QjtRQUM3RCxJQUFJLE1BQU0sR0FBUSxFQUFFLENBQUM7UUFDckIsYUFBYSxHQUFHLENBQUMsT0FBTyxhQUFhLEtBQUssV0FBVyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsYUFBYSxDQUFDO1FBQzlFLE1BQU0sR0FBRyxDQUFDLGFBQWEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLEVBQUUsRUFBRSxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDO1FBRTlELEtBQUssSUFBSSxHQUFHLElBQUksTUFBTSxFQUFFO1lBQ3BCLElBQUksR0FBRyxJQUFJLE1BQU0sRUFBRTtnQkFDZixJQUFJLE1BQU0sQ0FBQyxHQUFHLENBQUMsSUFBSSxPQUFPLE1BQU0sQ0FBQyxHQUFHLENBQUMsS0FBSyxRQUFRLElBQUksQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsQ0FBQyxFQUFFO29CQUMvRSxNQUFNLENBQUMsR0FBRyxDQUFDLEdBQUcsT0FBTyxNQUFNLENBQUMsR0FBRyxDQUFDLEtBQUssUUFBUSxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxlQUFlLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxFQUFFLE1BQU0sQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDO2lCQUNoSDtxQkFBTTtvQkFDSCxNQUFNLENBQUMsTUFBTSxDQUFDLE1BQU0sRUFBRSxFQUFFLENBQUMsR0FBRyxDQUFDLEVBQUUsTUFBTSxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsQ0FBQztpQkFDakQ7YUFDSjtpQkFBTTtnQkFDSCxNQUFNLENBQUMsTUFBTSxDQUFDLE1BQU0sRUFBRSxFQUFFLENBQUMsR0FBRyxDQUFDLEVBQUUsTUFBTSxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsQ0FBQzthQUNqRDtTQUNKO1FBQ0QsSUFBSSxhQUFhO1lBQUUsT0FBTyxNQUFNLENBQUM7SUFDckMsQ0FBQztJQUVEOzs7O09BSUc7SUFDSCxpQkFBaUIsQ0FBQyxNQUFXLEVBQUUsTUFBVztRQUN0QyxLQUFLLElBQUksR0FBRyxJQUFJLE1BQU0sRUFBRTtZQUNwQixJQUFJLE1BQU0sQ0FBQyxHQUFHLENBQUMsSUFBSSxPQUFPLE1BQU0sQ0FBQyxHQUFHLENBQUMsS0FBSyxRQUFRLEVBQUU7Z0JBQ2hELElBQUksTUFBTSxDQUFDLEdBQUcsQ0FBQyxJQUFJLE9BQU8sTUFBTSxDQUFDLEdBQUcsQ0FBQyxLQUFLLFFBQVEsSUFBSSxHQUFHLElBQUksTUFBTSxFQUFFO29CQUNqRSxJQUFJLENBQUMsaUJBQWlCLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxFQUFFLE1BQU0sQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDO2lCQUNwRDtxQkFBTTtvQkFDSCxNQUFNLENBQUMsTUFBTSxDQUFDLE1BQU0sRUFBRSxFQUFFLENBQUMsR0FBRyxDQUFDLEVBQUUsTUFBTSxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsQ0FBQztpQkFDakQ7YUFDSjtpQkFBTTtnQkFDSCxNQUFNLENBQUMsR0FBRyxDQUFDLEdBQUcsTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDO2FBQzdCO1NBQ0o7SUFDTCxDQUFDOzs7O1lBekVKLFVBQVUsU0FBQztnQkFDUixVQUFVLEVBQUUsTUFBTTthQUNyQiIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IEluamVjdGFibGUgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcclxuXHJcbkBJbmplY3RhYmxlKHtcclxuICAgIHByb3ZpZGVkSW46ICdyb290J1xyXG59KVxyXG5leHBvcnQgY2xhc3MgS2REYXRhU3ZjIHtcclxuICAgIGdldERhdGFWYWx1ZShfZnJvbU9iamVjdDogYW55LCBfa2V5OiBzdHJpbmcpOiBhbnkge1xyXG4gICAgICAgIGxldCBzcGxpdEFycmF5OiBBcnJheTxhbnk+ID0gX2tleS5zcGxpdCgnLicpO1xyXG4gICAgICAgIGxldCBkYXRhOiBhbnkgPSBfZnJvbU9iamVjdDtcclxuICAgICAgICBpZiAodHlwZW9mIGRhdGEgPT09ICd1bmRlZmluZWQnIHx8IGRhdGEgPT09IG51bGwpIHJldHVybiBudWxsO1xyXG4gICAgICAgIGZvciAobGV0IGk6IG51bWJlciA9IDA7IGkgPCBzcGxpdEFycmF5Lmxlbmd0aDsgaSsrKSB7XHJcbiAgICAgICAgICAgIGlmIChkYXRhLmhhc093blByb3BlcnR5KHNwbGl0QXJyYXlbaV0pKSBkYXRhID0gZGF0YVtzcGxpdEFycmF5W2ldXTtcclxuICAgICAgICAgICAgZWxzZSByZXR1cm4gbnVsbDtcclxuICAgICAgICB9XHJcbiAgICAgICAgcmV0dXJuIGRhdGE7XHJcbiAgICB9XHJcblxyXG4gICAgZ2V0UGxhY2Vob2xkZXIoX2Zyb21PYmplY3Q6IGFueSwgX3F1ZXJ5U3RyaW5nOiBzdHJpbmcpOiBhbnkge1xyXG4gICAgICAgIGxldCB1cGRhdGVkU3RyaW5nOiBzdHJpbmcgPSBfcXVlcnlTdHJpbmcuc2xpY2UoKTtcclxuICAgICAgICBsZXQgc2VhcmNoOiBBcnJheTxzdHJpbmc+ID0gX3F1ZXJ5U3RyaW5nLm1hdGNoKC9cXCRcXCgoLio/KVxcKS9nKTtcclxuICAgICAgICBpZiAoc2VhcmNoICE9PSBudWxsKSB7XHJcbiAgICAgICAgICAgIGZvciAobGV0IGk6IG51bWJlciA9IDA7IGkgPCBzZWFyY2gubGVuZ3RoOyBpKyspIHtcclxuICAgICAgICAgICAgICAgIGxldCBzZWFyY2hTdHJpbmc6IHN0cmluZyA9IHNlYXJjaFtpXS5zdWJzdHJpbmcoMiwgc2VhcmNoW2ldLmxlbmd0aCAtIDEpO1xyXG4gICAgICAgICAgICAgICAgbGV0IHJlcGxhY2VkU3RyaW5nOiBzdHJpbmcgPSB0aGlzLmdldERhdGFWYWx1ZShfZnJvbU9iamVjdCwgc2VhcmNoU3RyaW5nKTtcclxuICAgICAgICAgICAgICAgIGlmIChyZXBsYWNlZFN0cmluZyAhPT0gbnVsbCkge1xyXG4gICAgICAgICAgICAgICAgICAgIHVwZGF0ZWRTdHJpbmcgPSB1cGRhdGVkU3RyaW5nLnJlcGxhY2Uoc2VhcmNoW2ldLCByZXBsYWNlZFN0cmluZyk7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICAgICAgcmV0dXJuIHVwZGF0ZWRTdHJpbmc7XHJcbiAgICB9XHJcblxyXG4gICAgLyoqXHJcbiAgICAgKiBbZGVlcE1lcmdlT2JqZWN0XVxyXG4gICAgICogdGFyZ2V0ICAgICAgICA6IG1lcmdlIHRvXHJcbiAgICAgKiBzb3VyY2UgICAgICAgIDogbWVyZ2UgZnJvbVxyXG4gICAgICogX3JldHVybk5ld09iaiA6IGJ5IGRlZmF1bHQgaXMgdHJ1ZS4gSXQgd2lsbCByZXR1cm4gYSBuZXcgb2JqZWN0LiBJZiBpcyBmYWxzZSwgaXQgd2lsbCBkbyBhIGRpcmVjdCBtZXJnZS9jb21iaW5lXHJcbiAgICAgKiAgICAgICAgICAgICAgICAgYSBuZXcgb2JqZWN0LiAoT3B0aW9uYWwpXHJcbiAgICAgKi9cclxuICAgIGRlZXBNZXJnZU9iamVjdCh0YXJnZXQ6IGFueSwgc291cmNlOiBhbnksIF9yZXR1cm5OZXdPYmo/OiBib29sZWFuKTogYW55IHtcclxuICAgICAgICBsZXQgb3V0cHV0OiBhbnkgPSB7fTtcclxuICAgICAgICBfcmV0dXJuTmV3T2JqID0gKHR5cGVvZiBfcmV0dXJuTmV3T2JqID09PSAndW5kZWZpbmVkJykgPyB0cnVlIDogX3JldHVybk5ld09iajtcclxuICAgICAgICBvdXRwdXQgPSAoX3JldHVybk5ld09iaikgPyBPYmplY3QuYXNzaWduKHt9LCB0YXJnZXQpIDogdGFyZ2V0O1xyXG5cclxuICAgICAgICBmb3IgKGxldCBrZXkgaW4gc291cmNlKSB7XHJcbiAgICAgICAgICAgIGlmIChrZXkgaW4gb3V0cHV0KSB7XHJcbiAgICAgICAgICAgICAgICBpZiAob3V0cHV0W2tleV0gJiYgdHlwZW9mIG91dHB1dFtrZXldID09PSAnb2JqZWN0JyAmJiAhQXJyYXkuaXNBcnJheShvdXRwdXRba2V5XSkpIHtcclxuICAgICAgICAgICAgICAgICAgICBvdXRwdXRba2V5XSA9IHR5cGVvZiBzb3VyY2Vba2V5XSAhPT0gJ29iamVjdCcgPyBzb3VyY2Vba2V5XSA6IHRoaXMuZGVlcE1lcmdlT2JqZWN0KG91dHB1dFtrZXldLCBzb3VyY2Vba2V5XSk7XHJcbiAgICAgICAgICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgICAgIE9iamVjdC5hc3NpZ24ob3V0cHV0LCB7IFtrZXldOiBzb3VyY2Vba2V5XSB9KTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgICAgIE9iamVjdC5hc3NpZ24ob3V0cHV0LCB7IFtrZXldOiBzb3VyY2Vba2V5XSB9KTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgICAgICBpZiAoX3JldHVybk5ld09iaikgcmV0dXJuIG91dHB1dDtcclxuICAgIH1cclxuXHJcbiAgICAvKipcclxuICAgICAqIGNvbWJpbmVzIHRoZSBzb3VyY2UgdG8gdGhlIHRhcmdldCwgY2hhbmdpbmcgdGFyZ2V0J3Mga2V5IHZhbHVlcyBkaXJlY3RseS4gc291cmNlIGtleSB2YWx1ZXMgdGFrZXMgcHJvcHJpb3R5XHJcbiAgICAgKiB0YXJnZXQgICAgICAgIDogbWVyZ2UgdG9cclxuICAgICAqIHNvdXJjZSAgICAgICAgOiBtZXJnZSBmcm9tXHJcbiAgICAgKi9cclxuICAgIGRlZXBDb21iaW5lT2JqZWN0KHRhcmdldDogYW55LCBzb3VyY2U6IGFueSk6IHZvaWQge1xyXG4gICAgICAgIGZvciAobGV0IGtleSBpbiBzb3VyY2UpIHtcclxuICAgICAgICAgICAgaWYgKHNvdXJjZVtrZXldICYmIHR5cGVvZiBzb3VyY2Vba2V5XSA9PT0gJ29iamVjdCcpIHtcclxuICAgICAgICAgICAgICAgIGlmICh0YXJnZXRba2V5XSAmJiB0eXBlb2YgdGFyZ2V0W2tleV0gPT09ICdvYmplY3QnICYmIGtleSBpbiB0YXJnZXQpIHtcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLmRlZXBDb21iaW5lT2JqZWN0KHRhcmdldFtrZXldLCBzb3VyY2Vba2V5XSk7XHJcbiAgICAgICAgICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgICAgIE9iamVjdC5hc3NpZ24odGFyZ2V0LCB7IFtrZXldOiBzb3VyY2Vba2V5XSB9KTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgICAgIHRhcmdldFtrZXldID0gc291cmNlW2tleV07XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICB9XHJcbn1cclxuIl19