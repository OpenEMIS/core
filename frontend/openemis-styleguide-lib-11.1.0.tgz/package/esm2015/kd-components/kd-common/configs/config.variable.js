/*******************************************************************************
    File: config.variable.ts
    Version: 1.0
    Purpose: General variables usage for kd-component libraries

    Last change:
        -

 ******************************************************************************/
// Standard delay timing for all components
export const DELAY_TIME = 300;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiY29uZmlnLnZhcmlhYmxlLmpzIiwic291cmNlUm9vdCI6IkM6L1Byb2plY3RzL0FuZ3VsYXIvaW9zdGctb3BlbmVtaXMtc3R5bGVndWlkZS9wcm9qZWN0cy9vcGVuZW1pcy1zdHlsZWd1aWRlLWxpYi9zcmMvIiwic291cmNlcyI6WyJrZC1jb21wb25lbnRzL2tkLWNvbW1vbi9jb25maWdzL2NvbmZpZy52YXJpYWJsZS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTs7Ozs7Ozs7Z0ZBUWdGO0FBRWhGLDJDQUEyQztBQUMzQyxNQUFNLENBQUMsTUFBTSxVQUFVLEdBQVcsR0FBRyxDQUFDIiwic291cmNlc0NvbnRlbnQiOlsiLyoqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKipcclxuXHRGaWxlOiBjb25maWcudmFyaWFibGUudHNcclxuXHRWZXJzaW9uOiAxLjBcclxuXHRQdXJwb3NlOiBHZW5lcmFsIHZhcmlhYmxlcyB1c2FnZSBmb3Iga2QtY29tcG9uZW50IGxpYnJhcmllc1xyXG5cclxuXHRMYXN0IGNoYW5nZTpcclxuXHRcdC1cclxuXHJcbiAqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKiovXHJcblxyXG4vLyBTdGFuZGFyZCBkZWxheSB0aW1pbmcgZm9yIGFsbCBjb21wb25lbnRzXHJcbmV4cG9ydCBjb25zdCBERUxBWV9USU1FOiBudW1iZXIgPSAzMDA7XHJcbiJdfQ==