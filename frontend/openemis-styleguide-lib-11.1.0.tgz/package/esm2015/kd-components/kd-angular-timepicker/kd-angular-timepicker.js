import { Component, ViewEncapsulation, Input, Output, EventEmitter } from '@angular/core';
import { NgbTimepickerConfig } from '@ng-bootstrap/ng-bootstrap';
export class KdTimepicker {
    constructor() {
        this._defaultConfig = new NgbTimepickerConfig();
        this.timeConfig = new EventEmitter();
    }
    ngOnInit() {
        if (typeof this.inputVal !== 'undefined')
            this.newVal = this.inputVal;
        this.timepickerConfig();
    }
    timepickerConfig() {
        for (let i in this.config) {
            if (this.config.hasOwnProperty(i)) {
                this._defaultConfig[i] = this.config[i];
            }
        }
    }
    emitValue() {
        this.timeConfig.emit(this.newVal);
    }
}
KdTimepicker.decorators = [
    { type: Component, args: [{
                selector: 'kd-timepicker',
                template: "<div class=\"kdx-timepicker-wrapper\">\r\n\t<ngb-timepicker\r\n\t\t[(ngModel)]=\"newVal\"\r\n\t\t(ngModelChange)=\"emitValue()\"\r\n\t\t[disabled]=\"_defaultConfig.disabled\"\r\n\t\t[hourStep]=\"_defaultConfig.hourStep\"\r\n\t\t[meridian]=\"_defaultConfig.meridian\"\r\n\t\t[minuteStep]=\"_defaultConfig.minuteStep\"\r\n\t\t[readonlyInputs]=\"_defaultConfig.readonlyInputs\"\r\n\t\t[secondStep]=\"_defaultConfig.secondStep\"\r\n\t\t[seconds]=\"_defaultConfig.seconds\"\r\n\t\t[spinners]=\"_defaultConfig.spinners\"\r\n\t></ngb-timepicker>\r\n\t<ng-content></ng-content>\r\n</div>\r\n\r\n",
                encapsulation: ViewEncapsulation.None,
                host: { 'class': 'kdx kdx-timepicker' }
            },] }
];
KdTimepicker.propDecorators = {
    config: [{ type: Input }],
    inputVal: [{ type: Input }],
    timeConfig: [{ type: Output }]
};
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoia2QtYW5ndWxhci10aW1lcGlja2VyLmpzIiwic291cmNlUm9vdCI6IkM6L1Byb2plY3RzL0FuZ3VsYXIvaW9zdGctb3BlbmVtaXMtc3R5bGVndWlkZS9wcm9qZWN0cy9vcGVuZW1pcy1zdHlsZWd1aWRlLWxpYi9zcmMvIiwic291cmNlcyI6WyJrZC1jb21wb25lbnRzL2tkLWFuZ3VsYXItdGltZXBpY2tlci9rZC1hbmd1bGFyLXRpbWVwaWNrZXIudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsT0FBTyxFQUNILFNBQVMsRUFDVCxpQkFBaUIsRUFDakIsS0FBSyxFQUNMLE1BQU0sRUFDTixZQUFZLEVBRWYsTUFBTSxlQUFlLENBQUM7QUFDdkIsT0FBTyxFQUFFLG1CQUFtQixFQUFFLE1BQU0sNEJBQTRCLENBQUM7QUFTakUsTUFBTSxPQUFPLFlBQVk7SUFQekI7UUFTVyxtQkFBYyxHQUF3QixJQUFJLG1CQUFtQixFQUFFLENBQUM7UUFJN0QsZUFBVSxHQUFxQixJQUFJLFlBQVksRUFBRSxDQUFDO0lBa0JoRSxDQUFDO0lBaEJHLFFBQVE7UUFDSixJQUFJLE9BQU8sSUFBSSxDQUFDLFFBQVEsS0FBSyxXQUFXO1lBQUUsSUFBSSxDQUFDLE1BQU0sR0FBRyxJQUFJLENBQUMsUUFBUSxDQUFDO1FBQ3RFLElBQUksQ0FBQyxnQkFBZ0IsRUFBRSxDQUFDO0lBQzVCLENBQUM7SUFFRCxnQkFBZ0I7UUFDWixLQUFLLElBQUksQ0FBQyxJQUFJLElBQUksQ0FBQyxNQUFNLEVBQUU7WUFDdkIsSUFBSSxJQUFJLENBQUMsTUFBTSxDQUFDLGNBQWMsQ0FBQyxDQUFDLENBQUMsRUFBRTtnQkFDL0IsSUFBSSxDQUFDLGNBQWMsQ0FBQyxDQUFDLENBQUMsR0FBRyxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDO2FBQzNDO1NBQ0o7SUFDTCxDQUFDO0lBRUQsU0FBUztRQUNMLElBQUksQ0FBQyxVQUFVLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQztJQUN0QyxDQUFDOzs7WUE5QkosU0FBUyxTQUFDO2dCQUNQLFFBQVEsRUFBRSxlQUFlO2dCQUN6Qix1bEJBQTJDO2dCQUMzQyxhQUFhLEVBQUUsaUJBQWlCLENBQUMsSUFBSTtnQkFDckMsSUFBSSxFQUFHLEVBQUUsT0FBTyxFQUFHLG9CQUFvQixFQUFFO2FBQzVDOzs7cUJBTUksS0FBSzt1QkFDTCxLQUFLO3lCQUNMLE1BQU0iLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQge1xyXG4gICAgQ29tcG9uZW50LFxyXG4gICAgVmlld0VuY2Fwc3VsYXRpb24sXHJcbiAgICBJbnB1dCxcclxuICAgIE91dHB1dCxcclxuICAgIEV2ZW50RW1pdHRlcixcclxuICAgIE9uSW5pdFxyXG59IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xyXG5pbXBvcnQgeyBOZ2JUaW1lcGlja2VyQ29uZmlnIH0gZnJvbSAnQG5nLWJvb3RzdHJhcC9uZy1ib290c3RyYXAnO1xyXG5cclxuQENvbXBvbmVudCh7XHJcbiAgICBzZWxlY3RvcjogJ2tkLXRpbWVwaWNrZXInLFxyXG4gICAgdGVtcGxhdGVVcmw6ICcuL2tkLWFuZ3VsYXItdGltZXBpY2tlci5odG1sJyxcclxuICAgIGVuY2Fwc3VsYXRpb246IFZpZXdFbmNhcHN1bGF0aW9uLk5vbmUsXHJcbiAgICBob3N0IDogeyAnY2xhc3MnIDogJ2tkeCBrZHgtdGltZXBpY2tlcicgfVxyXG59KVxyXG5cclxuZXhwb3J0IGNsYXNzIEtkVGltZXBpY2tlciBpbXBsZW1lbnRzIE9uSW5pdCB7XHJcbiAgICBwdWJsaWMgbmV3VmFsOiBhbnk7XHJcbiAgICBwdWJsaWMgX2RlZmF1bHRDb25maWc6IE5nYlRpbWVwaWNrZXJDb25maWcgPSBuZXcgTmdiVGltZXBpY2tlckNvbmZpZygpO1xyXG5cclxuICAgIEBJbnB1dCgpIGNvbmZpZzogYW55O1xyXG4gICAgQElucHV0KCkgaW5wdXRWYWw6IGFueTtcclxuICAgIEBPdXRwdXQoKSB0aW1lQ29uZmlnOiBFdmVudEVtaXR0ZXI8e30+ID0gbmV3IEV2ZW50RW1pdHRlcigpO1xyXG5cclxuICAgIG5nT25Jbml0KCk6IHZvaWQge1xyXG4gICAgICAgIGlmICh0eXBlb2YgdGhpcy5pbnB1dFZhbCAhPT0gJ3VuZGVmaW5lZCcpIHRoaXMubmV3VmFsID0gdGhpcy5pbnB1dFZhbDtcclxuICAgICAgICB0aGlzLnRpbWVwaWNrZXJDb25maWcoKTtcclxuICAgIH1cclxuXHJcbiAgICB0aW1lcGlja2VyQ29uZmlnKCkge1xyXG4gICAgICAgIGZvciAobGV0IGkgaW4gdGhpcy5jb25maWcpIHtcclxuICAgICAgICAgICAgaWYgKHRoaXMuY29uZmlnLmhhc093blByb3BlcnR5KGkpKSB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLl9kZWZhdWx0Q29uZmlnW2ldID0gdGhpcy5jb25maWdbaV07XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgZW1pdFZhbHVlKCkge1xyXG4gICAgICAgIHRoaXMudGltZUNvbmZpZy5lbWl0KHRoaXMubmV3VmFsKTtcclxuICAgIH1cclxufVxyXG4iXX0=