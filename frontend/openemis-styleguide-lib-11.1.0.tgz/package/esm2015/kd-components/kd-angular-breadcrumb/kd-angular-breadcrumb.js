import { Component, Input, ViewEncapsulation, ViewContainerRef, } from '@angular/core';
import { timer, fromEvent } from 'rxjs';
import { debounceTime } from 'rxjs/operators';
import { KdBreadcrumbSvc } from './kd-angular-breadcrumb-svc';
import { KdDomElemSvc } from '../kd-common/index';
export class KdBreadcrumb {
    constructor(_vcr, _breadcrumbSvc) {
        this._vcr = _vcr;
        this._breadcrumbSvc = _breadcrumbSvc;
        this.breadcrumbResult = [];
    }
    ngOnInit() {
        this.resizeSub = fromEvent(window, 'resize')
            .pipe(debounceTime(500))
            .subscribe(e => {
            this.breadcrumbResult = this._breadcrumbSvc.renderBreadcrumbView(this._vcr, this.breadcrumbConfig);
        });
        this._initApi();
    }
    ngOnChanges(_simpleChanges) {
        if (_simpleChanges.hasOwnProperty('breadcrumbConfig')) {
            timer().subscribe(() => {
                this.breadcrumbResult = this._breadcrumbSvc.renderBreadcrumbView(this._vcr, this.breadcrumbConfig);
            });
        }
    }
    ngAfterViewInit() { }
    _initApi() {
        if (!this.api)
            return;
        this.api.addBreadcrumb = (_item) => {
            this.breadcrumbConfig.list.push(_item);
            this.breadcrumbResult = this._breadcrumbSvc.renderBreadcrumbView(this._vcr, this.breadcrumbConfig);
        };
        this.api.updateBreadcrumb = (_pos, _item) => {
            this.breadcrumbConfig.list[_pos - 1] = _item;
            this.breadcrumbResult = this._breadcrumbSvc.renderBreadcrumbView(this._vcr, this.breadcrumbConfig);
        };
        this.api.getBreadcrumbs = () => {
            return this.breadcrumbConfig;
        };
    }
}
KdBreadcrumb.decorators = [
    { type: Component, args: [{
                selector: 'kd-breadcrumb',
                template: `
        <ul class="breadcrumb panel-breadcrumb">
            <ng-template ngFor let-crumb [ngForOf]="breadcrumbResult">
                <li *ngIf="crumb.toEllipsis">
                    <i class="fa kd-ellipsis ellipsis fa-rotate-90"></i>
                </li>
                <li *ngIf="!crumb.toEllipsis" [class.list-hide]="!crumb.toRender" >
                    <a  *ngIf="crumb.path && crumb.path !== ''" [routerLink]="crumb.path">
                        <i *ngIf="crumb.icon && crumb.icon !=''" class="{{crumb.icon}}"></i>
                        <span *ngIf="crumb.name && crumb.name !== ''">{{crumb.name}}</span>
                    </a>
                    <a *ngIf="crumb.url && crumb.url !== ''" [href]="crumb.url">
                        <i *ngIf="crumb.icon && crumb.icon !=''" class="{{crumb.icon}}"></i>
                        <span *ngIf="crumb.name && crumb.name !== ''">{{crumb.name}}</span>
                    </a>
                    <div *ngIf="(!crumb.path || crumb.path=='') && (crumb.url=='' || !crumb.url)">
                        <i *ngIf="crumb.icon && crumb.icon !=''" class="{{crumb.icon}}"></i>
                        <span *ngIf="crumb.name && crumb.name !== ''">{{crumb.name}}</span>
                    </div>
                </li>
            </ng-template>
        </ul>
    `,
                encapsulation: ViewEncapsulation.None,
                providers: [KdBreadcrumbSvc, KdDomElemSvc],
                host: { 'class': 'kdx-breadcrumb' }
            },] }
];
KdBreadcrumb.ctorParameters = () => [
    { type: ViewContainerRef },
    { type: KdBreadcrumbSvc }
];
KdBreadcrumb.propDecorators = {
    breadcrumbConfig: [{ type: Input, args: ['config',] }],
    api: [{ type: Input }]
};
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoia2QtYW5ndWxhci1icmVhZGNydW1iLmpzIiwic291cmNlUm9vdCI6IkM6L1Byb2plY3RzL0FuZ3VsYXIvaW9zdGctb3BlbmVtaXMtc3R5bGVndWlkZS9wcm9qZWN0cy9vcGVuZW1pcy1zdHlsZWd1aWRlLWxpYi9zcmMvIiwic291cmNlcyI6WyJrZC1jb21wb25lbnRzL2tkLWFuZ3VsYXItYnJlYWRjcnVtYi9rZC1hbmd1bGFyLWJyZWFkY3J1bWIudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsT0FBTyxFQUNILFNBQVMsRUFDVCxLQUFLLEVBQ0wsaUJBQWlCLEVBSWpCLGdCQUFnQixHQUVuQixNQUFNLGVBQWUsQ0FBQztBQUN2QixPQUFPLEVBQUUsS0FBSyxFQUFnQixTQUFTLEVBQUUsTUFBTSxNQUFNLENBQUM7QUFDdEQsT0FBTyxFQUFFLFlBQVksRUFBRSxNQUFNLGdCQUFnQixDQUFDO0FBQzlDLE9BQU8sRUFBRSxlQUFlLEVBQUUsTUFBTSw2QkFBNkIsQ0FBQztBQUM5RCxPQUFPLEVBQUUsWUFBWSxFQUFFLE1BQU0sb0JBQW9CLENBQUM7QUFpQ2xELE1BQU0sT0FBTyxZQUFZO0lBTXJCLFlBQ1ksSUFBc0IsRUFDdEIsY0FBK0I7UUFEL0IsU0FBSSxHQUFKLElBQUksQ0FBa0I7UUFDdEIsbUJBQWMsR0FBZCxjQUFjLENBQWlCO1FBUHBDLHFCQUFnQixHQUErQixFQUFFLENBQUM7SUFRckQsQ0FBQztJQUVMLFFBQVE7UUFDSixJQUFJLENBQUMsU0FBUyxHQUFHLFNBQVMsQ0FBQyxNQUFNLEVBQUUsUUFBUSxDQUFDO2FBQ3ZDLElBQUksQ0FDRCxZQUFZLENBQUMsR0FBRyxDQUFDLENBQ3BCO2FBQ0EsU0FBUyxDQUFDLENBQUMsQ0FBQyxFQUFFO1lBQ1gsSUFBSSxDQUFDLGdCQUFnQixHQUFHLElBQUksQ0FBQyxjQUFjLENBQUMsb0JBQW9CLENBQUMsSUFBSSxDQUFDLElBQUksRUFBRSxJQUFJLENBQUMsZ0JBQWdCLENBQUMsQ0FBQztRQUN2RyxDQUFDLENBQUMsQ0FBQztRQUVQLElBQUksQ0FBQyxRQUFRLEVBQUUsQ0FBQztJQUNwQixDQUFDO0lBRUQsV0FBVyxDQUFDLGNBQTZCO1FBQ3JDLElBQUksY0FBYyxDQUFDLGNBQWMsQ0FBQyxrQkFBa0IsQ0FBQyxFQUFFO1lBQ25ELEtBQUssRUFBRSxDQUFDLFNBQVMsQ0FBQyxHQUFTLEVBQUU7Z0JBQ3pCLElBQUksQ0FBQyxnQkFBZ0IsR0FBRyxJQUFJLENBQUMsY0FBYyxDQUFDLG9CQUFvQixDQUFDLElBQUksQ0FBQyxJQUFJLEVBQUUsSUFBSSxDQUFDLGdCQUFnQixDQUFDLENBQUM7WUFDdkcsQ0FBQyxDQUFDLENBQUM7U0FDTjtJQUNMLENBQUM7SUFFRCxlQUFlLEtBQVcsQ0FBQztJQUVuQixRQUFRO1FBQ1osSUFBSSxDQUFDLElBQUksQ0FBQyxHQUFHO1lBQUUsT0FBTztRQUV0QixJQUFJLENBQUMsR0FBRyxDQUFDLGFBQWEsR0FBRyxDQUFDLEtBQWtCLEVBQUUsRUFBRTtZQUM1QyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQztZQUN2QyxJQUFJLENBQUMsZ0JBQWdCLEdBQUcsSUFBSSxDQUFDLGNBQWMsQ0FBQyxvQkFBb0IsQ0FBQyxJQUFJLENBQUMsSUFBSSxFQUFFLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDO1FBQ3ZHLENBQUMsQ0FBQztRQUVGLElBQUksQ0FBQyxHQUFHLENBQUMsZ0JBQWdCLEdBQUcsQ0FBQyxJQUFZLEVBQUUsS0FBa0IsRUFBRSxFQUFFO1lBQzdELElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxJQUFJLENBQUMsSUFBSSxHQUFHLENBQUMsQ0FBQyxHQUFHLEtBQUssQ0FBQztZQUM3QyxJQUFJLENBQUMsZ0JBQWdCLEdBQUcsSUFBSSxDQUFDLGNBQWMsQ0FBQyxvQkFBb0IsQ0FBQyxJQUFJLENBQUMsSUFBSSxFQUFFLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDO1FBQ3ZHLENBQUMsQ0FBQztRQUVGLElBQUksQ0FBQyxHQUFHLENBQUMsY0FBYyxHQUFHLEdBQXNCLEVBQUU7WUFDOUMsT0FBTyxJQUFJLENBQUMsZ0JBQWdCLENBQUM7UUFDakMsQ0FBQyxDQUFDO0lBQ04sQ0FBQzs7O1lBL0VKLFNBQVMsU0FBQztnQkFDUCxRQUFRLEVBQUUsZUFBZTtnQkFDekIsUUFBUSxFQUFFOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0tBc0JUO2dCQUNELGFBQWEsRUFBRSxpQkFBaUIsQ0FBQyxJQUFJO2dCQUNyQyxTQUFTLEVBQUUsQ0FBQyxlQUFlLEVBQUUsWUFBWSxDQUFDO2dCQUMxQyxJQUFJLEVBQUUsRUFBRSxPQUFPLEVBQUUsZ0JBQWdCLEVBQUU7YUFDdEM7OztZQXJDRyxnQkFBZ0I7WUFLWCxlQUFlOzs7K0JBcUNuQixLQUFLLFNBQUMsUUFBUTtrQkFDZCxLQUFLIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHtcclxuICAgIENvbXBvbmVudCxcclxuICAgIElucHV0LFxyXG4gICAgVmlld0VuY2Fwc3VsYXRpb24sXHJcbiAgICBPbkluaXQsXHJcbiAgICBPbkNoYW5nZXMsXHJcbiAgICBBZnRlclZpZXdJbml0LFxyXG4gICAgVmlld0NvbnRhaW5lclJlZixcclxuICAgIFNpbXBsZUNoYW5nZXMsXHJcbn0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XHJcbmltcG9ydCB7IHRpbWVyLCBTdWJzY3JpcHRpb24sIGZyb21FdmVudCB9IGZyb20gJ3J4anMnO1xyXG5pbXBvcnQgeyBkZWJvdW5jZVRpbWUgfSBmcm9tICdyeGpzL29wZXJhdG9ycyc7XHJcbmltcG9ydCB7IEtkQnJlYWRjcnVtYlN2YyB9IGZyb20gJy4va2QtYW5ndWxhci1icmVhZGNydW1iLXN2Yyc7XHJcbmltcG9ydCB7IEtkRG9tRWxlbVN2YyB9IGZyb20gJy4uL2tkLWNvbW1vbi9pbmRleCc7XHJcbmltcG9ydCB7IElCcmVhZGNydW1iLCBJQnJlYWRjcnVtYkludGVybmFsLCBJQnJlYWRjcnVtYkNvbmZpZyB9IGZyb20gJy4va2QtYW5ndWxhci1icmVhZGNydW1iLWludGVyZmFjZSc7XHJcblxyXG5AQ29tcG9uZW50KHtcclxuICAgIHNlbGVjdG9yOiAna2QtYnJlYWRjcnVtYicsXHJcbiAgICB0ZW1wbGF0ZTogYFxyXG4gICAgICAgIDx1bCBjbGFzcz1cImJyZWFkY3J1bWIgcGFuZWwtYnJlYWRjcnVtYlwiPlxyXG4gICAgICAgICAgICA8bmctdGVtcGxhdGUgbmdGb3IgbGV0LWNydW1iIFtuZ0Zvck9mXT1cImJyZWFkY3J1bWJSZXN1bHRcIj5cclxuICAgICAgICAgICAgICAgIDxsaSAqbmdJZj1cImNydW1iLnRvRWxsaXBzaXNcIj5cclxuICAgICAgICAgICAgICAgICAgICA8aSBjbGFzcz1cImZhIGtkLWVsbGlwc2lzIGVsbGlwc2lzIGZhLXJvdGF0ZS05MFwiPjwvaT5cclxuICAgICAgICAgICAgICAgIDwvbGk+XHJcbiAgICAgICAgICAgICAgICA8bGkgKm5nSWY9XCIhY3J1bWIudG9FbGxpcHNpc1wiIFtjbGFzcy5saXN0LWhpZGVdPVwiIWNydW1iLnRvUmVuZGVyXCIgPlxyXG4gICAgICAgICAgICAgICAgICAgIDxhICAqbmdJZj1cImNydW1iLnBhdGggJiYgY3J1bWIucGF0aCAhPT0gJydcIiBbcm91dGVyTGlua109XCJjcnVtYi5wYXRoXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxpICpuZ0lmPVwiY3J1bWIuaWNvbiAmJiBjcnVtYi5pY29uICE9JydcIiBjbGFzcz1cInt7Y3J1bWIuaWNvbn19XCI+PC9pPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiAqbmdJZj1cImNydW1iLm5hbWUgJiYgY3J1bWIubmFtZSAhPT0gJydcIj57e2NydW1iLm5hbWV9fTwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICA8L2E+XHJcbiAgICAgICAgICAgICAgICAgICAgPGEgKm5nSWY9XCJjcnVtYi51cmwgJiYgY3J1bWIudXJsICE9PSAnJ1wiIFtocmVmXT1cImNydW1iLnVybFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8aSAqbmdJZj1cImNydW1iLmljb24gJiYgY3J1bWIuaWNvbiAhPScnXCIgY2xhc3M9XCJ7e2NydW1iLmljb259fVwiPjwvaT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gKm5nSWY9XCJjcnVtYi5uYW1lICYmIGNydW1iLm5hbWUgIT09ICcnXCI+e3tjcnVtYi5uYW1lfX08L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9hPlxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgKm5nSWY9XCIoIWNydW1iLnBhdGggfHwgY3J1bWIucGF0aD09JycpICYmIChjcnVtYi51cmw9PScnIHx8ICFjcnVtYi51cmwpXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxpICpuZ0lmPVwiY3J1bWIuaWNvbiAmJiBjcnVtYi5pY29uICE9JydcIiBjbGFzcz1cInt7Y3J1bWIuaWNvbn19XCI+PC9pPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiAqbmdJZj1cImNydW1iLm5hbWUgJiYgY3J1bWIubmFtZSAhPT0gJydcIj57e2NydW1iLm5hbWV9fTwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDwvbGk+XHJcbiAgICAgICAgICAgIDwvbmctdGVtcGxhdGU+XHJcbiAgICAgICAgPC91bD5cclxuICAgIGAsXHJcbiAgICBlbmNhcHN1bGF0aW9uOiBWaWV3RW5jYXBzdWxhdGlvbi5Ob25lLFxyXG4gICAgcHJvdmlkZXJzOiBbS2RCcmVhZGNydW1iU3ZjLCBLZERvbUVsZW1TdmNdLFxyXG4gICAgaG9zdDogeyAnY2xhc3MnOiAna2R4LWJyZWFkY3J1bWInIH1cclxufSlcclxuXHJcbmV4cG9ydCBjbGFzcyBLZEJyZWFkY3J1bWIgaW1wbGVtZW50cyBPbkluaXQsIE9uQ2hhbmdlcywgQWZ0ZXJWaWV3SW5pdCB7XHJcbiAgICBwdWJsaWMgYnJlYWRjcnVtYlJlc3VsdDogQXJyYXk8SUJyZWFkY3J1bWJJbnRlcm5hbD4gPSBbXTtcclxuICAgIHByaXZhdGUgcmVzaXplU3ViOiBTdWJzY3JpcHRpb247XHJcbiAgICBASW5wdXQoJ2NvbmZpZycpIGJyZWFkY3J1bWJDb25maWc6IElCcmVhZGNydW1iQ29uZmlnO1xyXG4gICAgQElucHV0KCkgYXBpOiBhbnk7XHJcblxyXG4gICAgY29uc3RydWN0b3IoXHJcbiAgICAgICAgcHJpdmF0ZSBfdmNyOiBWaWV3Q29udGFpbmVyUmVmLFxyXG4gICAgICAgIHByaXZhdGUgX2JyZWFkY3J1bWJTdmM6IEtkQnJlYWRjcnVtYlN2Y1xyXG4gICAgKSB7IH1cclxuXHJcbiAgICBuZ09uSW5pdCgpOiB2b2lkIHtcclxuICAgICAgICB0aGlzLnJlc2l6ZVN1YiA9IGZyb21FdmVudCh3aW5kb3csICdyZXNpemUnKVxyXG4gICAgICAgICAgICAucGlwZShcclxuICAgICAgICAgICAgICAgIGRlYm91bmNlVGltZSg1MDApXHJcbiAgICAgICAgICAgIClcclxuICAgICAgICAgICAgLnN1YnNjcmliZShlID0+IHtcclxuICAgICAgICAgICAgICAgIHRoaXMuYnJlYWRjcnVtYlJlc3VsdCA9IHRoaXMuX2JyZWFkY3J1bWJTdmMucmVuZGVyQnJlYWRjcnVtYlZpZXcodGhpcy5fdmNyLCB0aGlzLmJyZWFkY3J1bWJDb25maWcpO1xyXG4gICAgICAgICAgICB9KTtcclxuXHJcbiAgICAgICAgdGhpcy5faW5pdEFwaSgpO1xyXG4gICAgfVxyXG5cclxuICAgIG5nT25DaGFuZ2VzKF9zaW1wbGVDaGFuZ2VzOiBTaW1wbGVDaGFuZ2VzKTogdm9pZCB7XHJcbiAgICAgICAgaWYgKF9zaW1wbGVDaGFuZ2VzLmhhc093blByb3BlcnR5KCdicmVhZGNydW1iQ29uZmlnJykpIHtcclxuICAgICAgICAgICAgdGltZXIoKS5zdWJzY3JpYmUoKCk6IHZvaWQgPT4ge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5icmVhZGNydW1iUmVzdWx0ID0gdGhpcy5fYnJlYWRjcnVtYlN2Yy5yZW5kZXJCcmVhZGNydW1iVmlldyh0aGlzLl92Y3IsIHRoaXMuYnJlYWRjcnVtYkNvbmZpZyk7XHJcbiAgICAgICAgICAgIH0pO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICBuZ0FmdGVyVmlld0luaXQoKTogdm9pZCB7IH1cclxuXHJcbiAgICBwcml2YXRlIF9pbml0QXBpKCk6IHZvaWQge1xyXG4gICAgICAgIGlmICghdGhpcy5hcGkpIHJldHVybjtcclxuXHJcbiAgICAgICAgdGhpcy5hcGkuYWRkQnJlYWRjcnVtYiA9IChfaXRlbTogSUJyZWFkY3J1bWIpID0+IHtcclxuICAgICAgICAgICAgdGhpcy5icmVhZGNydW1iQ29uZmlnLmxpc3QucHVzaChfaXRlbSk7XHJcbiAgICAgICAgICAgIHRoaXMuYnJlYWRjcnVtYlJlc3VsdCA9IHRoaXMuX2JyZWFkY3J1bWJTdmMucmVuZGVyQnJlYWRjcnVtYlZpZXcodGhpcy5fdmNyLCB0aGlzLmJyZWFkY3J1bWJDb25maWcpO1xyXG4gICAgICAgIH07XHJcblxyXG4gICAgICAgIHRoaXMuYXBpLnVwZGF0ZUJyZWFkY3J1bWIgPSAoX3BvczogbnVtYmVyLCBfaXRlbTogSUJyZWFkY3J1bWIpID0+IHtcclxuICAgICAgICAgICAgdGhpcy5icmVhZGNydW1iQ29uZmlnLmxpc3RbX3BvcyAtIDFdID0gX2l0ZW07XHJcbiAgICAgICAgICAgIHRoaXMuYnJlYWRjcnVtYlJlc3VsdCA9IHRoaXMuX2JyZWFkY3J1bWJTdmMucmVuZGVyQnJlYWRjcnVtYlZpZXcodGhpcy5fdmNyLCB0aGlzLmJyZWFkY3J1bWJDb25maWcpO1xyXG4gICAgICAgIH07XHJcblxyXG4gICAgICAgIHRoaXMuYXBpLmdldEJyZWFkY3J1bWJzID0gKCk6IElCcmVhZGNydW1iQ29uZmlnID0+IHtcclxuICAgICAgICAgICAgcmV0dXJuIHRoaXMuYnJlYWRjcnVtYkNvbmZpZztcclxuICAgICAgICB9O1xyXG4gICAgfVxyXG59XHJcbiJdfQ==