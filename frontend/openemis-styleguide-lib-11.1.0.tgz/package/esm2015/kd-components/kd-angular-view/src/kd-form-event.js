import { Injectable } from '@angular/core';
import { KdBroadcaster } from '../../kd-common/index';
import * as i0 from "@angular/core";
import * as i1 from "../../kd-common/kd-broadcaster-svc";
export class KdFormEvent {
    constructor(_broadcaster) {
        this._broadcaster = _broadcaster;
    }
    setDropdownList(data) {
        this._broadcaster.broadcast('KdSetDropdownList', data);
    }
    onSetDropdownList() {
        return this._broadcaster.on('KdSetDropdownList');
    }
    setVisiableInput(data) {
        this._broadcaster.broadcast('KdSetVisiableInput', data);
    }
    onSetVisiableInput() {
        return this._broadcaster.on('KdSetVisiableInput');
    }
}
KdFormEvent.ɵprov = i0.ɵɵdefineInjectable({ factory: function KdFormEvent_Factory() { return new KdFormEvent(i0.ɵɵinject(i1.KdBroadcaster)); }, token: KdFormEvent, providedIn: "root" });
KdFormEvent.decorators = [
    { type: Injectable, args: [{
                providedIn: 'root'
            },] }
];
KdFormEvent.ctorParameters = () => [
    { type: KdBroadcaster }
];
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoia2QtZm9ybS1ldmVudC5qcyIsInNvdXJjZVJvb3QiOiJDOi9Qcm9qZWN0cy9Bbmd1bGFyL2lvc3RnLW9wZW5lbWlzLXN0eWxlZ3VpZGUvcHJvamVjdHMvb3BlbmVtaXMtc3R5bGVndWlkZS1saWIvc3JjLyIsInNvdXJjZXMiOlsia2QtY29tcG9uZW50cy9rZC1hbmd1bGFyLXZpZXcvc3JjL2tkLWZvcm0tZXZlbnQudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsT0FBTyxFQUFFLFVBQVUsRUFBRSxNQUFNLGVBQWUsQ0FBQztBQUUzQyxPQUFPLEVBQUUsYUFBYSxFQUFFLE1BQU0sdUJBQXVCLENBQUM7OztBQUt0RCxNQUFNLE9BQU8sV0FBVztJQUNwQixZQUFvQixZQUEyQjtRQUEzQixpQkFBWSxHQUFaLFlBQVksQ0FBZTtJQUFJLENBQUM7SUFFcEQsZUFBZSxDQUFDLElBQVU7UUFDdEIsSUFBSSxDQUFDLFlBQVksQ0FBQyxTQUFTLENBQUMsbUJBQW1CLEVBQUUsSUFBSSxDQUFDLENBQUM7SUFDM0QsQ0FBQztJQUVELGlCQUFpQjtRQUNiLE9BQU8sSUFBSSxDQUFDLFlBQVksQ0FBQyxFQUFFLENBQU0sbUJBQW1CLENBQUMsQ0FBQztJQUMxRCxDQUFDO0lBRUQsZ0JBQWdCLENBQUMsSUFBVTtRQUN2QixJQUFJLENBQUMsWUFBWSxDQUFDLFNBQVMsQ0FBQyxvQkFBb0IsRUFBRSxJQUFJLENBQUMsQ0FBQztJQUM1RCxDQUFDO0lBRUQsa0JBQWtCO1FBQ2QsT0FBTyxJQUFJLENBQUMsWUFBWSxDQUFDLEVBQUUsQ0FBTSxvQkFBb0IsQ0FBQyxDQUFDO0lBQzNELENBQUM7Ozs7WUFwQkosVUFBVSxTQUFDO2dCQUNSLFVBQVUsRUFBRSxNQUFNO2FBQ3JCOzs7WUFKUSxhQUFhIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgSW5qZWN0YWJsZSB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xyXG5pbXBvcnQgeyBPYnNlcnZhYmxlIH0gZnJvbSAncnhqcyc7XHJcbmltcG9ydCB7IEtkQnJvYWRjYXN0ZXIgfSBmcm9tICcuLi8uLi9rZC1jb21tb24vaW5kZXgnO1xyXG5cclxuQEluamVjdGFibGUoe1xyXG4gICAgcHJvdmlkZWRJbjogJ3Jvb3QnXHJcbn0pXHJcbmV4cG9ydCBjbGFzcyBLZEZvcm1FdmVudCB7XHJcbiAgICBjb25zdHJ1Y3Rvcihwcml2YXRlIF9icm9hZGNhc3RlcjogS2RCcm9hZGNhc3RlcikgeyB9XHJcblxyXG4gICAgc2V0RHJvcGRvd25MaXN0KGRhdGE/OiBhbnkpOiB2b2lkIHtcclxuICAgICAgICB0aGlzLl9icm9hZGNhc3Rlci5icm9hZGNhc3QoJ0tkU2V0RHJvcGRvd25MaXN0JywgZGF0YSk7XHJcbiAgICB9XHJcblxyXG4gICAgb25TZXREcm9wZG93bkxpc3QoKTogT2JzZXJ2YWJsZTxhbnk+IHtcclxuICAgICAgICByZXR1cm4gdGhpcy5fYnJvYWRjYXN0ZXIub248YW55PignS2RTZXREcm9wZG93bkxpc3QnKTtcclxuICAgIH1cclxuXHJcbiAgICBzZXRWaXNpYWJsZUlucHV0KGRhdGE/OiBhbnkpOiB2b2lkIHtcclxuICAgICAgICB0aGlzLl9icm9hZGNhc3Rlci5icm9hZGNhc3QoJ0tkU2V0VmlzaWFibGVJbnB1dCcsIGRhdGEpO1xyXG4gICAgfVxyXG5cclxuICAgIG9uU2V0VmlzaWFibGVJbnB1dCgpOiBPYnNlcnZhYmxlPGFueT4ge1xyXG4gICAgICAgIHJldHVybiB0aGlzLl9icm9hZGNhc3Rlci5vbjxhbnk+KCdLZFNldFZpc2lhYmxlSW5wdXQnKTtcclxuICAgIH1cclxufVxyXG4iXX0=