import { Directive, HostListener, Input, Output, EventEmitter, HostBinding } from '@angular/core';
export class DragDropDirective {
    constructor() {
        this.dropped = new EventEmitter();
    }
    set appDragDrop(value) {
        this._enabled = value === '' ? true : !!value;
    }
    get dragInProgress() {
        return this._dragInProgress;
    }
    handleDragOver(event) {
        if (!this._enabled) {
            return;
        }
        event.dataTransfer.dropEffect = 'move';
        this.stopAndPreventDefault(event);
        this._dragInProgress = true;
    }
    handleDragEnd(event) {
        if (!this._enabled) {
            return;
        }
        this.stopAndPreventDefault(event);
        event.dataTransfer.effectAllowed = 'copy';
        this._dragInProgress = false;
    }
    handleDrop(event) {
        this.stopAndPreventDefault(event);
        this._dragInProgress = false;
        this.dropped.emit(event);
    }
    stopAndPreventDefault(e) {
        e.stopPropagation();
        e.preventDefault();
    }
}
DragDropDirective.decorators = [
    { type: Directive, args: [{
                selector: '[appDragDrop]'
            },] }
];
DragDropDirective.ctorParameters = () => [];
DragDropDirective.propDecorators = {
    appDragDrop: [{ type: Input }],
    dragInProgress: [{ type: HostBinding, args: ['class.dragging',] }],
    dropped: [{ type: Output }],
    handleDragOver: [{ type: HostListener, args: ['dragenter', ['$event'],] }, { type: HostListener, args: ['dragover', ['$event'],] }],
    handleDragEnd: [{ type: HostListener, args: ['dragleave', ['$event'],] }, { type: HostListener, args: ['dragend', ['$event'],] }],
    handleDrop: [{ type: HostListener, args: ['drop', ['$event'],] }]
};
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZHJvcHpvbmUuZGlyZWN0aXZlLmpzIiwic291cmNlUm9vdCI6IkM6L1Byb2plY3RzL0FuZ3VsYXIvaW9zdGctb3BlbmVtaXMtc3R5bGVndWlkZS9wcm9qZWN0cy9vcGVuZW1pcy1zdHlsZWd1aWRlLWxpYi9zcmMvIiwic291cmNlcyI6WyJrZC1jb21wb25lbnRzL2tkLWFuZ3VsYXItZmlsZWlucHV0L2Ryb3B6b25lLmRpcmVjdGl2ZS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQSxPQUFPLEVBQUUsU0FBUyxFQUFFLFlBQVksRUFBRSxLQUFLLEVBQUUsTUFBTSxFQUFFLFlBQVksRUFBRSxXQUFXLEVBQUUsTUFBTSxlQUFlLENBQUM7QUFLbEcsTUFBTSxPQUFPLGlCQUFpQjtJQWdCNUI7UUFDRSxJQUFJLENBQUMsT0FBTyxHQUFHLElBQUksWUFBWSxFQUFFLENBQUM7SUFDcEMsQ0FBQztJQWJELElBQWEsV0FBVyxDQUFDLEtBQVU7UUFDakMsSUFBSSxDQUFDLFFBQVEsR0FBRyxLQUFLLEtBQUssRUFBRSxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUM7SUFDaEQsQ0FBQztJQUdELElBQW1DLGNBQWM7UUFDL0MsT0FBTyxJQUFJLENBQUMsZUFBZSxDQUFDO0lBQzlCLENBQUM7SUFVTSxjQUFjLENBQUMsS0FBZ0I7UUFDcEMsSUFBSSxDQUFDLElBQUksQ0FBQyxRQUFRLEVBQUU7WUFDbEIsT0FBTztTQUNSO1FBQ0QsS0FBSyxDQUFDLFlBQVksQ0FBQyxVQUFVLEdBQUcsTUFBTSxDQUFDO1FBQ3ZDLElBQUksQ0FBQyxxQkFBcUIsQ0FBQyxLQUFLLENBQUMsQ0FBQztRQUNsQyxJQUFJLENBQUMsZUFBZSxHQUFHLElBQUksQ0FBQztJQUM5QixDQUFDO0lBSU0sYUFBYSxDQUFDLEtBQWdCO1FBQ25DLElBQUksQ0FBQyxJQUFJLENBQUMsUUFBUSxFQUFFO1lBQ2xCLE9BQU87U0FDUjtRQUNELElBQUksQ0FBQyxxQkFBcUIsQ0FBQyxLQUFLLENBQUMsQ0FBQztRQUNsQyxLQUFLLENBQUMsWUFBWSxDQUFDLGFBQWEsR0FBRyxNQUFNLENBQUM7UUFDMUMsSUFBSSxDQUFDLGVBQWUsR0FBRyxLQUFLLENBQUM7SUFDL0IsQ0FBQztJQUdNLFVBQVUsQ0FBQyxLQUFjO1FBQzlCLElBQUksQ0FBQyxxQkFBcUIsQ0FBQyxLQUFLLENBQUMsQ0FBQztRQUNsQyxJQUFJLENBQUMsZUFBZSxHQUFHLEtBQUssQ0FBQztRQUM3QixJQUFJLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQztJQUMzQixDQUFDO0lBRUQscUJBQXFCLENBQUMsQ0FBVTtRQUM5QixDQUFDLENBQUMsZUFBZSxFQUFFLENBQUM7UUFDcEIsQ0FBQyxDQUFDLGNBQWMsRUFBRSxDQUFDO0lBQ3JCLENBQUM7OztZQXZERixTQUFTLFNBQUM7Z0JBQ1QsUUFBUSxFQUFFLGVBQWU7YUFDMUI7Ozs7MEJBTUUsS0FBSzs2QkFLTCxXQUFXLFNBQUMsZ0JBQWdCO3NCQUk1QixNQUFNOzZCQU1OLFlBQVksU0FBQyxXQUFXLEVBQUUsQ0FBQyxRQUFRLENBQUMsY0FDcEMsWUFBWSxTQUFDLFVBQVUsRUFBRSxDQUFDLFFBQVEsQ0FBQzs0QkFVbkMsWUFBWSxTQUFDLFdBQVcsRUFBRSxDQUFDLFFBQVEsQ0FBQyxjQUNwQyxZQUFZLFNBQUMsU0FBUyxFQUFFLENBQUMsUUFBUSxDQUFDO3lCQVVsQyxZQUFZLFNBQUMsTUFBTSxFQUFFLENBQUMsUUFBUSxDQUFDIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgRGlyZWN0aXZlLCBIb3N0TGlzdGVuZXIsIElucHV0LCBPdXRwdXQsIEV2ZW50RW1pdHRlciwgSG9zdEJpbmRpbmcgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcclxuXHJcbkBEaXJlY3RpdmUoe1xyXG4gIHNlbGVjdG9yOiAnW2FwcERyYWdEcm9wXSdcclxufSlcclxuZXhwb3J0IGNsYXNzIERyYWdEcm9wRGlyZWN0aXZlIHtcclxuXHJcbiAgcHVibGljIF9lbmFibGVkOiBib29sZWFuO1xyXG4gIHB1YmxpYyBfZHJhZ0luUHJvZ3Jlc3M6IGJvb2xlYW47XHJcblxyXG4gIEBJbnB1dCgpIHNldCBhcHBEcmFnRHJvcCh2YWx1ZTogYW55KSB7XHJcbiAgICB0aGlzLl9lbmFibGVkID0gdmFsdWUgPT09ICcnID8gdHJ1ZSA6ICEhdmFsdWU7XHJcbiAgfVxyXG5cclxuXHJcbiAgQEhvc3RCaW5kaW5nKCdjbGFzcy5kcmFnZ2luZycpIGdldCBkcmFnSW5Qcm9ncmVzcygpIHtcclxuICAgIHJldHVybiB0aGlzLl9kcmFnSW5Qcm9ncmVzcztcclxuICB9XHJcblxyXG4gIEBPdXRwdXQoKSBkcm9wcGVkOiBFdmVudEVtaXR0ZXI8YW55PjtcclxuXHJcbiAgY29uc3RydWN0b3IoKSB7XHJcbiAgICB0aGlzLmRyb3BwZWQgPSBuZXcgRXZlbnRFbWl0dGVyKCk7XHJcbiAgfVxyXG5cclxuICBASG9zdExpc3RlbmVyKCdkcmFnZW50ZXInLCBbJyRldmVudCddKVxyXG4gIEBIb3N0TGlzdGVuZXIoJ2RyYWdvdmVyJywgWyckZXZlbnQnXSlcclxuICBwdWJsaWMgaGFuZGxlRHJhZ092ZXIoZXZlbnQ6IERyYWdFdmVudCk6IHZvaWQge1xyXG4gICAgaWYgKCF0aGlzLl9lbmFibGVkKSB7XHJcbiAgICAgIHJldHVybjtcclxuICAgIH1cclxuICAgIGV2ZW50LmRhdGFUcmFuc2Zlci5kcm9wRWZmZWN0ID0gJ21vdmUnO1xyXG4gICAgdGhpcy5zdG9wQW5kUHJldmVudERlZmF1bHQoZXZlbnQpO1xyXG4gICAgdGhpcy5fZHJhZ0luUHJvZ3Jlc3MgPSB0cnVlO1xyXG4gIH1cclxuXHJcbiAgQEhvc3RMaXN0ZW5lcignZHJhZ2xlYXZlJywgWyckZXZlbnQnXSlcclxuICBASG9zdExpc3RlbmVyKCdkcmFnZW5kJywgWyckZXZlbnQnXSlcclxuICBwdWJsaWMgaGFuZGxlRHJhZ0VuZChldmVudDogRHJhZ0V2ZW50KTogdm9pZCB7XHJcbiAgICBpZiAoIXRoaXMuX2VuYWJsZWQpIHtcclxuICAgICAgcmV0dXJuO1xyXG4gICAgfVxyXG4gICAgdGhpcy5zdG9wQW5kUHJldmVudERlZmF1bHQoZXZlbnQpO1xyXG4gICAgZXZlbnQuZGF0YVRyYW5zZmVyLmVmZmVjdEFsbG93ZWQgPSAnY29weSc7XHJcbiAgICB0aGlzLl9kcmFnSW5Qcm9ncmVzcyA9IGZhbHNlO1xyXG4gIH1cclxuXHJcbiAgQEhvc3RMaXN0ZW5lcignZHJvcCcsIFsnJGV2ZW50J10pXHJcbiAgcHVibGljIGhhbmRsZURyb3AoZXZlbnQ6IFVJRXZlbnQpOiB2b2lkIHtcclxuICAgIHRoaXMuc3RvcEFuZFByZXZlbnREZWZhdWx0KGV2ZW50KTtcclxuICAgIHRoaXMuX2RyYWdJblByb2dyZXNzID0gZmFsc2U7XHJcbiAgICB0aGlzLmRyb3BwZWQuZW1pdChldmVudCk7XHJcbiAgfVxyXG5cclxuICBzdG9wQW5kUHJldmVudERlZmF1bHQoZTogVUlFdmVudCk6IHZvaWQge1xyXG4gICAgZS5zdG9wUHJvcGFnYXRpb24oKTtcclxuICAgIGUucHJldmVudERlZmF1bHQoKTtcclxuICB9XHJcblxyXG59XHJcbiJdfQ==