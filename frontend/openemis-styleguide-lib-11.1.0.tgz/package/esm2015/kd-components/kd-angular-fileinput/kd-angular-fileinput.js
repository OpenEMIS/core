import { Component, Input, Output, EventEmitter, ViewContainerRef, ElementRef, ViewChild } from '@angular/core';
export class KdFileInput {
    constructor(_vcr) {
        this._vcr = _vcr;
        this._fileResult = {
            src: '',
            filename: '',
            extension: '',
            data: ''
        };
        this.dragDropEnabled = true;
        this.result = new EventEmitter();
        this.myFiles = [];
    }
    ngOnInit() {
        this._setFileType();
        this._setLeftBtn();
        this._checkInitFile();
    }
    handleFileSelect(event) {
        let files = event.target.files;
        let file = files[0];
        if (typeof this.config.fileName === 'undefined' || this.config.fileName === '') {
            this.config.fileName = file.name;
        }
        // if (files && file) {
        if (typeof files !== 'undefined' && typeof file !== 'undefined') {
            let reader = new FileReader();
            reader.onload = () => {
                let dataUrl = reader.result;
                // console.log('dataUrl - ', dataUrl);
                let findExtension = file.name.split('.');
                this._fileResult = {
                    src: dataUrl,
                    data: file,
                    filename: file.name,
                    extension: findExtension[findExtension.length - 1]
                };
                this.result.emit(this._fileResult.data);
            };
            reader.readAsDataURL(file);
        }
    }
    handleFileMultipleSelect(event) {
        for (var i = 0; i < event.target.files.length; i++) {
            this.myFiles.push(event.target.files[i]);
        }
        this._fileResult.filename = `${this.myFiles.length} files selected`;
        console.log(this.myFiles, "myFiles");
        this.result.emit(this.myFiles);
    }
    removeSelectedFile(file, index) {
        this.myFiles.splice(index, 1);
        this._fileResult.filename = `${this.myFiles.length} files selected`;
        console.log(this.myFiles, "myFiles");
    }
    handleFileDrop(event) {
        var _a, _b;
        if ((_b = (_a = event === null || event === void 0 ? void 0 : event.dataTransfer) === null || _a === void 0 ? void 0 : _a.files) === null || _b === void 0 ? void 0 : _b.length) {
            const files = event.dataTransfer.files;
            this.inputRef.nativeElement.files = files;
            for (var i = 0; i < files.length; i++) {
                this.myFiles.push(files[i]);
            }
            this._fileResult.filename = `${this.myFiles.length} files selected`;
            console.log(this.myFiles.length, "this.myFiles.length");
        }
    }
    // public handleFileSelect(event: any): void {
    //     let files = event.target.files;
    //     let file = files[0];
    //     if (typeof this.config.fileName === 'undefined' || this.config.fileName === '') {
    //         this.config.fileName = file.name;
    //     }
    //     // if (files && file) {
    //     if (typeof files !== 'undefined' && typeof file !== 'undefined') {
    //         let reader = new FileReader();
    //         reader.onload = (): void => {
    //             // check the file type in format --> data:image/png;base64,
    //             // this._dataUri = 'data:' + file.type + ';base64,';
    //             let binaryString: string = reader.result;
    //             this._fileResult = this._getResult(binaryString, file);
    //             this.result.emit(this._fileResult);
    //         }
    //         reader.readAsBinaryString(file);
    //     }
    // }
    removeFile(_event) {
        _event.preventDefault();
        let fileinput = this._vcr.element.nativeElement.querySelector('#filePicker');
        fileinput.value = '';
        this._fileResult = {
            data: '',
            extension: '',
            filename: '',
            src: ''
        };
        this.myFiles = [];
        // this._fileResult.data = '';
        // this._fileResult.extension = '';
        // this._fileResult.filename = '';
        // this._fileResult.src = '';
        this.result.emit(this._fileResult);
    }
    buttonCallback(_event, _button) {
        _event.preventDefault();
        if (typeof _button.callback === 'function') {
            _button.callback(_event, _button);
        }
    }
    _checkInitFile() {
        if (typeof this.value !== 'undefined') {
            this._fileResult.data = this.value.data;
            this._fileResult.extension = this.value.extension;
            this._fileResult.filename = this.value.filename;
            this._fileResult.src = this.value.src;
        }
    }
    // private _getResult(binaryString: string, file: any): IFileResult {
    //     let dataUri: string = 'data:' + file.type + ';base64,';
    //     let base64String: string = btoa(binaryString);
    //     let findExtension: Array<string> = file.name.split('.');
    //     // let newResult: IFileResult =
    //     // newResult.data = base64String;
    //     // newResult.src = dataUri + base64String;
    //     // newResult.filename = file.name;
    //     // newResult.extension = findExtension[findExtension.length - 1];
    //     return {
    //         data: base64String,
    //         src: dataUri + base64String,
    //         filename: file.name,
    //         extension: findExtension[findExtension.length - 1],
    //     };
    // }
    _setFileType() {
        if (typeof this.config !== 'undefined' && typeof this.config.fileType === 'undefined') {
            this.config['fileType'] = 'file_extension, media_type';
        }
        else if (this.config.fileType === 'image') {
            this.config.fileType = 'image/*';
        }
        else if (this.config.fileType === 'media') {
            this.config.fileType = 'audio/*, video/*';
        }
        else if (this.config.fileType === 'text') {
            this.config.fileType = '.csv, .pdf, .xl, .xla, .xlb, .xlc, .xld, .xlk, .xll, .xlm, .xls, .xlt, .xlv, .xlw, .doc, .dot';
        }
    }
    _setLeftBtn() {
        if (typeof this.config.leftButton !== 'undefined' && this.config.leftToolbar === true) {
            if (this.config.leftButton.length === 1) {
                this._leftButton = 'input-single-btn';
            }
            else {
                this._leftButton = 'input-double-btn';
            }
        }
    }
}
KdFileInput.decorators = [
    { type: Component, args: [{
                selector: 'kd-fileinput',
                template: "<div class=\"kdx-fileinput-wrapper\">\r\n    <div class=\"kdx-file-preview\" *ngIf=\"config.preview\">\r\n        <kd-placeholder [config]='config.imageConfig' [value]='_fileResult'></kd-placeholder>\r\n    </div>\r\n\r\n    <label class=\"kdx-wrapper\" [appDragDrop]=\"dragDropEnabled\" (dropped)=\"handleFileDrop($event)\">\r\n        <ng-container *ngIf=\"config?.multiple\">\r\n            <!-- <label class=\"drag-zone\" [appDragDrop]=\"dragDropEnabled\" (dropped)=\"handleFileDrop($event)\" style=\"height: 25px; width: 221px;\"> -->\r\n                <input type=\"file\" class=\"hidden\" id=\"filePicker\" accept=\"{{config.fileType}}\" #fileInput multiple=\"true\"\r\n                    (change)=\"handleFileMultipleSelect($event)\">\r\n            <!-- </label> -->\r\n        </ng-container>\r\n        <ng-container *ngIf=\"!config?.multiple\">\r\n            <input type=\"file\" class=\"hidden\" id=\"filePicker\" accept=\"{{config.fileType}}\"\r\n                (change)=\"handleFileSelect($event)\">\r\n        </ng-container>\r\n        <ng-content></ng-content>\r\n        <div class=\"btn btn-icon btn-browse\" placement=\"bottom\" ngbTooltip=\"Browse\">\r\n            <i class=\"fa fa-folder\"></i>\r\n        </div>\r\n        <div *ngIf=\"config.leftToolbar\" class=\"{{_leftButton}}\">\r\n            <button *ngFor=\"let button of config.leftButton | slice:0:2;\" class=\"btn btn-icon\" placement=\"bottom\"\r\n                ngbTooltip=\"{{button.label}}\" (click)=\"buttonCallback($event, button)\" type=\"button\">\r\n                <i class=\"fa {{button.icon}}\"></i>\r\n            </button>\r\n        </div>\r\n        <div *ngIf=\"_fileResult.filename\" class=\"kdx-input-text\">\r\n            <i class=\"fa fa-file-o\"></i>\r\n            <p>{{_fileResult.filename}}</p>\r\n        </div>\r\n        <button *ngIf=\"_fileResult.filename\" class=\"btn btn-remove\" (click)=\"removeFile($event)\" placement=\"bottom\"\r\n            ngbTooltip=\"Remove\" type=\"button\">\r\n            <i class=\"kd-close-round\"></i>\r\n        </button>\r\n    </label>\r\n\r\n    <div *ngIf=\"config.infoText\" class=\"kdx-fileinput-text\">\r\n        <div *ngFor=\"let list of config.infoText | slice:0:3;\">* {{list.text}}</div>\r\n    </div>\r\n\r\n    <div class=\"selected-file mt-2\" *ngIf=\"myFiles.length > 0\">\r\n        <ng-container *ngFor=\"let file of myFiles; let i = index\">\r\n            <div class=\"d-flex\" style=\"width: fit-content;\">\r\n                <p>{{ file.name }}</p>\r\n                <i class=\"fa fa-trash ml-2\" style=\"cursor: pointer; position: relative; top: 3px;\" (click)=\"removeSelectedFile(file, i)\"\r\n                    placement=\"top\" ngbTooltip=\"Delete\"></i>\r\n            </div>\r\n        </ng-container>\r\n    </div>\r\n</div>"
            },] }
];
KdFileInput.ctorParameters = () => [
    { type: ViewContainerRef }
];
KdFileInput.propDecorators = {
    config: [{ type: Input }],
    value: [{ type: Input }],
    result: [{ type: Output }],
    inputRef: [{ type: ViewChild, args: ['fileInput',] }]
};
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoia2QtYW5ndWxhci1maWxlaW5wdXQuanMiLCJzb3VyY2VSb290IjoiQzovUHJvamVjdHMvQW5ndWxhci9pb3N0Zy1vcGVuZW1pcy1zdHlsZWd1aWRlL3Byb2plY3RzL29wZW5lbWlzLXN0eWxlZ3VpZGUtbGliL3NyYy8iLCJzb3VyY2VzIjpbImtkLWNvbXBvbmVudHMva2QtYW5ndWxhci1maWxlaW5wdXQva2QtYW5ndWxhci1maWxlaW5wdXQudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsT0FBTyxFQUNILFNBQVMsRUFFVCxLQUFLLEVBQ0wsTUFBTSxFQUNOLFlBQVksRUFDWixnQkFBZ0IsRUFDaEIsVUFBVSxFQUNWLFNBQVMsRUFDWixNQUFNLGVBQWUsQ0FBQztBQVN2QixNQUFNLE9BQU8sV0FBVztJQW1CcEIsWUFDWSxJQUFzQjtRQUF0QixTQUFJLEdBQUosSUFBSSxDQUFrQjtRQWxCM0IsZ0JBQVcsR0FBZ0I7WUFDOUIsR0FBRyxFQUFFLEVBQUU7WUFDUCxRQUFRLEVBQUUsRUFBRTtZQUNaLFNBQVMsRUFBRSxFQUFFO1lBQ2IsSUFBSSxFQUFFLEVBQUU7U0FDWCxDQUFDO1FBRUYsb0JBQWUsR0FBRyxJQUFJLENBQUM7UUFLYixXQUFNLEdBQUcsSUFBSSxZQUFZLEVBQUUsQ0FBQztRQUN0QyxZQUFPLEdBQVEsRUFBRSxDQUFDO0lBTWQsQ0FBQztJQUVMLFFBQVE7UUFDSixJQUFJLENBQUMsWUFBWSxFQUFFLENBQUM7UUFDcEIsSUFBSSxDQUFDLFdBQVcsRUFBRSxDQUFDO1FBQ25CLElBQUksQ0FBQyxjQUFjLEVBQUUsQ0FBQztJQUMxQixDQUFDO0lBRU0sZ0JBQWdCLENBQUMsS0FBVTtRQUM5QixJQUFJLEtBQUssR0FBYSxLQUFLLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQztRQUN6QyxJQUFJLElBQUksR0FBUyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUM7UUFFMUIsSUFBSSxPQUFPLElBQUksQ0FBQyxNQUFNLENBQUMsUUFBUSxLQUFLLFdBQVcsSUFBSSxJQUFJLENBQUMsTUFBTSxDQUFDLFFBQVEsS0FBSyxFQUFFLEVBQUU7WUFDNUUsSUFBSSxDQUFDLE1BQU0sQ0FBQyxRQUFRLEdBQUcsSUFBSSxDQUFDLElBQUksQ0FBQztTQUNwQztRQUVELHVCQUF1QjtRQUN2QixJQUFJLE9BQU8sS0FBSyxLQUFLLFdBQVcsSUFBSSxPQUFPLElBQUksS0FBSyxXQUFXLEVBQUU7WUFDN0QsSUFBSSxNQUFNLEdBQWUsSUFBSSxVQUFVLEVBQUUsQ0FBQztZQUUxQyxNQUFNLENBQUMsTUFBTSxHQUFHLEdBQUcsRUFBRTtnQkFDakIsSUFBSSxPQUFPLEdBQVcsTUFBTSxDQUFDLE1BQWdCLENBQUM7Z0JBQzlDLHNDQUFzQztnQkFDdEMsSUFBSSxhQUFhLEdBQWtCLElBQUksQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDO2dCQUN4RCxJQUFJLENBQUMsV0FBVyxHQUFHO29CQUNmLEdBQUcsRUFBRSxPQUFPO29CQUNaLElBQUksRUFBRSxJQUFJO29CQUNWLFFBQVEsRUFBRSxJQUFJLENBQUMsSUFBSTtvQkFDbkIsU0FBUyxFQUFFLGFBQWEsQ0FBQyxhQUFhLENBQUMsTUFBTSxHQUFHLENBQUMsQ0FBQztpQkFDckQsQ0FBQztnQkFDRixJQUFJLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFDLElBQUksQ0FBQyxDQUFDO1lBQzVDLENBQUMsQ0FBQztZQUVGLE1BQU0sQ0FBQyxhQUFhLENBQUMsSUFBSSxDQUFDLENBQUM7U0FDOUI7SUFDTCxDQUFDO0lBRU0sd0JBQXdCLENBQUMsS0FBVTtRQUV0QyxLQUFLLElBQUksQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLEdBQUcsS0FBSyxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsTUFBTSxFQUFFLENBQUMsRUFBRSxFQUFFO1lBQ2hELElBQUksQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7U0FDNUM7UUFDRCxJQUFJLENBQUMsV0FBVyxDQUFDLFFBQVEsR0FBRyxHQUFHLElBQUksQ0FBQyxPQUFPLENBQUMsTUFBTSxpQkFBaUIsQ0FBQztRQUNwRSxPQUFPLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxPQUFPLEVBQUUsU0FBUyxDQUFDLENBQUM7UUFDckMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxDQUFDO0lBRW5DLENBQUM7SUFFTSxrQkFBa0IsQ0FBQyxJQUFTLEVBQUUsS0FBVTtRQUMzQyxJQUFJLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxLQUFLLEVBQUUsQ0FBQyxDQUFDLENBQUM7UUFDOUIsSUFBSSxDQUFDLFdBQVcsQ0FBQyxRQUFRLEdBQUcsR0FBRyxJQUFJLENBQUMsT0FBTyxDQUFDLE1BQU0saUJBQWlCLENBQUM7UUFDcEUsT0FBTyxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsT0FBTyxFQUFFLFNBQVMsQ0FBQyxDQUFDO0lBQ3pDLENBQUM7SUFFRCxjQUFjLENBQUMsS0FBZ0I7O1FBQzNCLGdCQUFJLEtBQUssYUFBTCxLQUFLLHVCQUFMLEtBQUssQ0FBRSxZQUFZLDBDQUFFLEtBQUssMENBQUUsTUFBTSxFQUFFO1lBQ3BDLE1BQU0sS0FBSyxHQUFHLEtBQUssQ0FBQyxZQUFZLENBQUMsS0FBSyxDQUFDO1lBQ3ZDLElBQUksQ0FBQyxRQUFRLENBQUMsYUFBYSxDQUFDLEtBQUssR0FBRyxLQUFLLENBQUM7WUFDMUMsS0FBSyxJQUFJLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxHQUFHLEtBQUssQ0FBQyxNQUFNLEVBQUUsQ0FBQyxFQUFFLEVBQUU7Z0JBQ25DLElBQUksQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO2FBQy9CO1lBQ0QsSUFBSSxDQUFDLFdBQVcsQ0FBQyxRQUFRLEdBQUcsR0FBRyxJQUFJLENBQUMsT0FBTyxDQUFDLE1BQU0saUJBQWlCLENBQUM7WUFDcEUsT0FBTyxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLE1BQU0sRUFBQyxxQkFBcUIsQ0FBQyxDQUFDO1NBRTFEO0lBQ0wsQ0FBQztJQUVELDhDQUE4QztJQUM5QyxzQ0FBc0M7SUFDdEMsMkJBQTJCO0lBRTNCLHdGQUF3RjtJQUN4Riw0Q0FBNEM7SUFDNUMsUUFBUTtJQUVSLDhCQUE4QjtJQUM5Qix5RUFBeUU7SUFDekUseUNBQXlDO0lBRXpDLHdDQUF3QztJQUN4QywwRUFBMEU7SUFDMUUsbUVBQW1FO0lBRW5FLHdEQUF3RDtJQUN4RCxzRUFBc0U7SUFDdEUsa0RBQWtEO0lBQ2xELFlBQVk7SUFFWiwyQ0FBMkM7SUFDM0MsUUFBUTtJQUNSLElBQUk7SUFFRyxVQUFVLENBQUMsTUFBYTtRQUMzQixNQUFNLENBQUMsY0FBYyxFQUFFLENBQUM7UUFFeEIsSUFBSSxTQUFTLEdBQUcsSUFBSSxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsYUFBYSxDQUFDLGFBQWEsQ0FBQyxhQUFhLENBQUMsQ0FBQztRQUM3RSxTQUFTLENBQUMsS0FBSyxHQUFHLEVBQUUsQ0FBQztRQUVyQixJQUFJLENBQUMsV0FBVyxHQUFHO1lBQ2YsSUFBSSxFQUFFLEVBQUU7WUFDUixTQUFTLEVBQUUsRUFBRTtZQUNiLFFBQVEsRUFBRSxFQUFFO1lBQ1osR0FBRyxFQUFFLEVBQUU7U0FDVixDQUFDO1FBRUYsSUFBSSxDQUFDLE9BQU8sR0FBRyxFQUFFLENBQUM7UUFFbEIsOEJBQThCO1FBQzlCLG1DQUFtQztRQUNuQyxrQ0FBa0M7UUFDbEMsNkJBQTZCO1FBQzdCLElBQUksQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxXQUFXLENBQUMsQ0FBQztJQUN2QyxDQUFDO0lBRU0sY0FBYyxDQUFDLE1BQWEsRUFBRSxPQUFZO1FBQzdDLE1BQU0sQ0FBQyxjQUFjLEVBQUUsQ0FBQztRQUN4QixJQUFJLE9BQU8sT0FBTyxDQUFDLFFBQVEsS0FBSyxVQUFVLEVBQUU7WUFDeEMsT0FBTyxDQUFDLFFBQVEsQ0FBQyxNQUFNLEVBQUUsT0FBTyxDQUFDLENBQUM7U0FDckM7SUFDTCxDQUFDO0lBRU8sY0FBYztRQUNsQixJQUFJLE9BQU8sSUFBSSxDQUFDLEtBQUssS0FBSyxXQUFXLEVBQUU7WUFDbkMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxJQUFJLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUM7WUFDeEMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxTQUFTLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQyxTQUFTLENBQUM7WUFDbEQsSUFBSSxDQUFDLFdBQVcsQ0FBQyxRQUFRLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQyxRQUFRLENBQUM7WUFDaEQsSUFBSSxDQUFDLFdBQVcsQ0FBQyxHQUFHLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUM7U0FDekM7SUFDTCxDQUFDO0lBRUQscUVBQXFFO0lBQ3JFLDhEQUE4RDtJQUM5RCxxREFBcUQ7SUFDckQsK0RBQStEO0lBRS9ELHNDQUFzQztJQUV0Qyx3Q0FBd0M7SUFDeEMsaURBQWlEO0lBQ2pELHlDQUF5QztJQUN6Qyx3RUFBd0U7SUFDeEUsZUFBZTtJQUNmLDhCQUE4QjtJQUM5Qix1Q0FBdUM7SUFDdkMsK0JBQStCO0lBQy9CLDhEQUE4RDtJQUM5RCxTQUFTO0lBQ1QsSUFBSTtJQUVJLFlBQVk7UUFDaEIsSUFBSSxPQUFPLElBQUksQ0FBQyxNQUFNLEtBQUssV0FBVyxJQUFJLE9BQU8sSUFBSSxDQUFDLE1BQU0sQ0FBQyxRQUFRLEtBQUssV0FBVyxFQUFFO1lBQ25GLElBQUksQ0FBQyxNQUFNLENBQUMsVUFBVSxDQUFDLEdBQUcsNEJBQTRCLENBQUM7U0FDMUQ7YUFDSSxJQUFJLElBQUksQ0FBQyxNQUFNLENBQUMsUUFBUSxLQUFLLE9BQU8sRUFBRTtZQUN2QyxJQUFJLENBQUMsTUFBTSxDQUFDLFFBQVEsR0FBRyxTQUFTLENBQUM7U0FDcEM7YUFDSSxJQUFJLElBQUksQ0FBQyxNQUFNLENBQUMsUUFBUSxLQUFLLE9BQU8sRUFBRTtZQUN2QyxJQUFJLENBQUMsTUFBTSxDQUFDLFFBQVEsR0FBRyxrQkFBa0IsQ0FBQztTQUM3QzthQUNJLElBQUksSUFBSSxDQUFDLE1BQU0sQ0FBQyxRQUFRLEtBQUssTUFBTSxFQUFFO1lBQ3RDLElBQUksQ0FBQyxNQUFNLENBQUMsUUFBUSxHQUFHLCtGQUErRixDQUFDO1NBQzFIO0lBQ0wsQ0FBQztJQUVPLFdBQVc7UUFDZixJQUFJLE9BQU8sSUFBSSxDQUFDLE1BQU0sQ0FBQyxVQUFVLEtBQUssV0FBVyxJQUFJLElBQUksQ0FBQyxNQUFNLENBQUMsV0FBVyxLQUFLLElBQUksRUFBRTtZQUNuRixJQUFJLElBQUksQ0FBQyxNQUFNLENBQUMsVUFBVSxDQUFDLE1BQU0sS0FBSyxDQUFDLEVBQUU7Z0JBQ3JDLElBQUksQ0FBQyxXQUFXLEdBQUcsa0JBQWtCLENBQUM7YUFDekM7aUJBQ0k7Z0JBQ0QsSUFBSSxDQUFDLFdBQVcsR0FBRyxrQkFBa0IsQ0FBQzthQUN6QztTQUNKO0lBQ0wsQ0FBQzs7O1lBdk1KLFNBQVMsU0FBQztnQkFDUCxRQUFRLEVBQUUsY0FBYztnQkFDeEIsMndGQUEwQzthQUM3Qzs7O1lBVkcsZ0JBQWdCOzs7cUJBd0JmLEtBQUs7b0JBQ0wsS0FBSztxQkFDTCxNQUFNO3VCQUdOLFNBQVMsU0FBQyxXQUFXIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHtcclxuICAgIENvbXBvbmVudCxcclxuICAgIE9uSW5pdCxcclxuICAgIElucHV0LFxyXG4gICAgT3V0cHV0LFxyXG4gICAgRXZlbnRFbWl0dGVyLFxyXG4gICAgVmlld0NvbnRhaW5lclJlZixcclxuICAgIEVsZW1lbnRSZWYsXHJcbiAgICBWaWV3Q2hpbGRcclxufSBmcm9tICdAYW5ndWxhci9jb3JlJztcclxuXHJcbmltcG9ydCB7IElGaWxlUmVzdWx0IH0gZnJvbSAnLi9rZC1maWxlaW5wdXQtaW50ZXJmYWNlJztcclxuXHJcbkBDb21wb25lbnQoe1xyXG4gICAgc2VsZWN0b3I6ICdrZC1maWxlaW5wdXQnLFxyXG4gICAgdGVtcGxhdGVVcmw6ICcuL2tkLWFuZ3VsYXItZmlsZWlucHV0Lmh0bWwnXHJcbn0pXHJcblxyXG5leHBvcnQgY2xhc3MgS2RGaWxlSW5wdXQgaW1wbGVtZW50cyBPbkluaXQge1xyXG4gICAgcHVibGljIF9sZWZ0QnV0dG9uOiBzdHJpbmc7XHJcbiAgICBwdWJsaWMgX2ZpbGVSZXN1bHQ6IElGaWxlUmVzdWx0ID0ge1xyXG4gICAgICAgIHNyYzogJycsXHJcbiAgICAgICAgZmlsZW5hbWU6ICcnLFxyXG4gICAgICAgIGV4dGVuc2lvbjogJycsXHJcbiAgICAgICAgZGF0YTogJydcclxuICAgIH07XHJcblxyXG4gICAgZHJhZ0Ryb3BFbmFibGVkID0gdHJ1ZTtcclxuXHJcblxyXG4gICAgQElucHV0KCkgY29uZmlnOiBhbnk7XHJcbiAgICBASW5wdXQoKSB2YWx1ZTogYW55O1xyXG4gICAgQE91dHB1dCgpIHJlc3VsdCA9IG5ldyBFdmVudEVtaXR0ZXIoKTtcclxuICAgIG15RmlsZXM6IGFueSA9IFtdO1xyXG5cclxuICAgIEBWaWV3Q2hpbGQoJ2ZpbGVJbnB1dCcpIGlucHV0UmVmOiBFbGVtZW50UmVmPEhUTUxJbnB1dEVsZW1lbnQ+O1xyXG5cclxuICAgIGNvbnN0cnVjdG9yKFxyXG4gICAgICAgIHByaXZhdGUgX3ZjcjogVmlld0NvbnRhaW5lclJlZlxyXG4gICAgKSB7IH1cclxuXHJcbiAgICBuZ09uSW5pdCgpOiB2b2lkIHtcclxuICAgICAgICB0aGlzLl9zZXRGaWxlVHlwZSgpO1xyXG4gICAgICAgIHRoaXMuX3NldExlZnRCdG4oKTtcclxuICAgICAgICB0aGlzLl9jaGVja0luaXRGaWxlKCk7XHJcbiAgICB9XHJcblxyXG4gICAgcHVibGljIGhhbmRsZUZpbGVTZWxlY3QoZXZlbnQ6IGFueSk6IHZvaWQge1xyXG4gICAgICAgIGxldCBmaWxlczogRmlsZUxpc3QgPSBldmVudC50YXJnZXQuZmlsZXM7XHJcbiAgICAgICAgbGV0IGZpbGU6IEZpbGUgPSBmaWxlc1swXTtcclxuXHJcbiAgICAgICAgaWYgKHR5cGVvZiB0aGlzLmNvbmZpZy5maWxlTmFtZSA9PT0gJ3VuZGVmaW5lZCcgfHwgdGhpcy5jb25maWcuZmlsZU5hbWUgPT09ICcnKSB7XHJcbiAgICAgICAgICAgIHRoaXMuY29uZmlnLmZpbGVOYW1lID0gZmlsZS5uYW1lO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgLy8gaWYgKGZpbGVzICYmIGZpbGUpIHtcclxuICAgICAgICBpZiAodHlwZW9mIGZpbGVzICE9PSAndW5kZWZpbmVkJyAmJiB0eXBlb2YgZmlsZSAhPT0gJ3VuZGVmaW5lZCcpIHtcclxuICAgICAgICAgICAgbGV0IHJlYWRlcjogRmlsZVJlYWRlciA9IG5ldyBGaWxlUmVhZGVyKCk7XHJcblxyXG4gICAgICAgICAgICByZWFkZXIub25sb2FkID0gKCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgbGV0IGRhdGFVcmw6IHN0cmluZyA9IHJlYWRlci5yZXN1bHQgYXMgc3RyaW5nO1xyXG4gICAgICAgICAgICAgICAgLy8gY29uc29sZS5sb2coJ2RhdGFVcmwgLSAnLCBkYXRhVXJsKTtcclxuICAgICAgICAgICAgICAgIGxldCBmaW5kRXh0ZW5zaW9uOiBBcnJheTxzdHJpbmc+ID0gZmlsZS5uYW1lLnNwbGl0KCcuJyk7XHJcbiAgICAgICAgICAgICAgICB0aGlzLl9maWxlUmVzdWx0ID0ge1xyXG4gICAgICAgICAgICAgICAgICAgIHNyYzogZGF0YVVybCxcclxuICAgICAgICAgICAgICAgICAgICBkYXRhOiBmaWxlLFxyXG4gICAgICAgICAgICAgICAgICAgIGZpbGVuYW1lOiBmaWxlLm5hbWUsXHJcbiAgICAgICAgICAgICAgICAgICAgZXh0ZW5zaW9uOiBmaW5kRXh0ZW5zaW9uW2ZpbmRFeHRlbnNpb24ubGVuZ3RoIC0gMV1cclxuICAgICAgICAgICAgICAgIH07XHJcbiAgICAgICAgICAgICAgICB0aGlzLnJlc3VsdC5lbWl0KHRoaXMuX2ZpbGVSZXN1bHQuZGF0YSk7XHJcbiAgICAgICAgICAgIH07XHJcblxyXG4gICAgICAgICAgICByZWFkZXIucmVhZEFzRGF0YVVSTChmaWxlKTtcclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgcHVibGljIGhhbmRsZUZpbGVNdWx0aXBsZVNlbGVjdChldmVudDogYW55KTogdm9pZCB7XHJcblxyXG4gICAgICAgIGZvciAodmFyIGkgPSAwOyBpIDwgZXZlbnQudGFyZ2V0LmZpbGVzLmxlbmd0aDsgaSsrKSB7XHJcbiAgICAgICAgICAgIHRoaXMubXlGaWxlcy5wdXNoKGV2ZW50LnRhcmdldC5maWxlc1tpXSk7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIHRoaXMuX2ZpbGVSZXN1bHQuZmlsZW5hbWUgPSBgJHt0aGlzLm15RmlsZXMubGVuZ3RofSBmaWxlcyBzZWxlY3RlZGA7XHJcbiAgICAgICAgY29uc29sZS5sb2codGhpcy5teUZpbGVzLCBcIm15RmlsZXNcIik7XHJcbiAgICAgICAgdGhpcy5yZXN1bHQuZW1pdCh0aGlzLm15RmlsZXMpO1xyXG5cclxuICAgIH1cclxuXHJcbiAgICBwdWJsaWMgcmVtb3ZlU2VsZWN0ZWRGaWxlKGZpbGU6IGFueSwgaW5kZXg6IGFueSkge1xyXG4gICAgICAgIHRoaXMubXlGaWxlcy5zcGxpY2UoaW5kZXgsIDEpO1xyXG4gICAgICAgIHRoaXMuX2ZpbGVSZXN1bHQuZmlsZW5hbWUgPSBgJHt0aGlzLm15RmlsZXMubGVuZ3RofSBmaWxlcyBzZWxlY3RlZGA7XHJcbiAgICAgICAgY29uc29sZS5sb2codGhpcy5teUZpbGVzLCBcIm15RmlsZXNcIik7XHJcbiAgICB9XHJcblxyXG4gICAgaGFuZGxlRmlsZURyb3AoZXZlbnQ6IERyYWdFdmVudCkge1xyXG4gICAgICAgIGlmIChldmVudD8uZGF0YVRyYW5zZmVyPy5maWxlcz8ubGVuZ3RoKSB7XHJcbiAgICAgICAgICAgIGNvbnN0IGZpbGVzID0gZXZlbnQuZGF0YVRyYW5zZmVyLmZpbGVzO1xyXG4gICAgICAgICAgICB0aGlzLmlucHV0UmVmLm5hdGl2ZUVsZW1lbnQuZmlsZXMgPSBmaWxlcztcclxuICAgICAgICAgICAgZm9yICh2YXIgaSA9IDA7IGkgPCBmaWxlcy5sZW5ndGg7IGkrKykge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5teUZpbGVzLnB1c2goZmlsZXNbaV0pO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIHRoaXMuX2ZpbGVSZXN1bHQuZmlsZW5hbWUgPSBgJHt0aGlzLm15RmlsZXMubGVuZ3RofSBmaWxlcyBzZWxlY3RlZGA7XHJcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKHRoaXMubXlGaWxlcy5sZW5ndGgsXCJ0aGlzLm15RmlsZXMubGVuZ3RoXCIpO1xyXG4gICAgICAgICAgICBcclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgLy8gcHVibGljIGhhbmRsZUZpbGVTZWxlY3QoZXZlbnQ6IGFueSk6IHZvaWQge1xyXG4gICAgLy8gICAgIGxldCBmaWxlcyA9IGV2ZW50LnRhcmdldC5maWxlcztcclxuICAgIC8vICAgICBsZXQgZmlsZSA9IGZpbGVzWzBdO1xyXG5cclxuICAgIC8vICAgICBpZiAodHlwZW9mIHRoaXMuY29uZmlnLmZpbGVOYW1lID09PSAndW5kZWZpbmVkJyB8fCB0aGlzLmNvbmZpZy5maWxlTmFtZSA9PT0gJycpIHtcclxuICAgIC8vICAgICAgICAgdGhpcy5jb25maWcuZmlsZU5hbWUgPSBmaWxlLm5hbWU7XHJcbiAgICAvLyAgICAgfVxyXG5cclxuICAgIC8vICAgICAvLyBpZiAoZmlsZXMgJiYgZmlsZSkge1xyXG4gICAgLy8gICAgIGlmICh0eXBlb2YgZmlsZXMgIT09ICd1bmRlZmluZWQnICYmIHR5cGVvZiBmaWxlICE9PSAndW5kZWZpbmVkJykge1xyXG4gICAgLy8gICAgICAgICBsZXQgcmVhZGVyID0gbmV3IEZpbGVSZWFkZXIoKTtcclxuXHJcbiAgICAvLyAgICAgICAgIHJlYWRlci5vbmxvYWQgPSAoKTogdm9pZCA9PiB7XHJcbiAgICAvLyAgICAgICAgICAgICAvLyBjaGVjayB0aGUgZmlsZSB0eXBlIGluIGZvcm1hdCAtLT4gZGF0YTppbWFnZS9wbmc7YmFzZTY0LFxyXG4gICAgLy8gICAgICAgICAgICAgLy8gdGhpcy5fZGF0YVVyaSA9ICdkYXRhOicgKyBmaWxlLnR5cGUgKyAnO2Jhc2U2NCwnO1xyXG5cclxuICAgIC8vICAgICAgICAgICAgIGxldCBiaW5hcnlTdHJpbmc6IHN0cmluZyA9IHJlYWRlci5yZXN1bHQ7XHJcbiAgICAvLyAgICAgICAgICAgICB0aGlzLl9maWxlUmVzdWx0ID0gdGhpcy5fZ2V0UmVzdWx0KGJpbmFyeVN0cmluZywgZmlsZSk7XHJcbiAgICAvLyAgICAgICAgICAgICB0aGlzLnJlc3VsdC5lbWl0KHRoaXMuX2ZpbGVSZXN1bHQpO1xyXG4gICAgLy8gICAgICAgICB9XHJcblxyXG4gICAgLy8gICAgICAgICByZWFkZXIucmVhZEFzQmluYXJ5U3RyaW5nKGZpbGUpO1xyXG4gICAgLy8gICAgIH1cclxuICAgIC8vIH1cclxuXHJcbiAgICBwdWJsaWMgcmVtb3ZlRmlsZShfZXZlbnQ6IEV2ZW50KTogdm9pZCB7XHJcbiAgICAgICAgX2V2ZW50LnByZXZlbnREZWZhdWx0KCk7XHJcblxyXG4gICAgICAgIGxldCBmaWxlaW5wdXQgPSB0aGlzLl92Y3IuZWxlbWVudC5uYXRpdmVFbGVtZW50LnF1ZXJ5U2VsZWN0b3IoJyNmaWxlUGlja2VyJyk7XHJcbiAgICAgICAgZmlsZWlucHV0LnZhbHVlID0gJyc7XHJcblxyXG4gICAgICAgIHRoaXMuX2ZpbGVSZXN1bHQgPSB7XHJcbiAgICAgICAgICAgIGRhdGE6ICcnLFxyXG4gICAgICAgICAgICBleHRlbnNpb246ICcnLFxyXG4gICAgICAgICAgICBmaWxlbmFtZTogJycsXHJcbiAgICAgICAgICAgIHNyYzogJydcclxuICAgICAgICB9O1xyXG5cclxuICAgICAgICB0aGlzLm15RmlsZXMgPSBbXTtcclxuXHJcbiAgICAgICAgLy8gdGhpcy5fZmlsZVJlc3VsdC5kYXRhID0gJyc7XHJcbiAgICAgICAgLy8gdGhpcy5fZmlsZVJlc3VsdC5leHRlbnNpb24gPSAnJztcclxuICAgICAgICAvLyB0aGlzLl9maWxlUmVzdWx0LmZpbGVuYW1lID0gJyc7XHJcbiAgICAgICAgLy8gdGhpcy5fZmlsZVJlc3VsdC5zcmMgPSAnJztcclxuICAgICAgICB0aGlzLnJlc3VsdC5lbWl0KHRoaXMuX2ZpbGVSZXN1bHQpO1xyXG4gICAgfVxyXG5cclxuICAgIHB1YmxpYyBidXR0b25DYWxsYmFjayhfZXZlbnQ6IEV2ZW50LCBfYnV0dG9uOiBhbnkpOiB2b2lkIHtcclxuICAgICAgICBfZXZlbnQucHJldmVudERlZmF1bHQoKTtcclxuICAgICAgICBpZiAodHlwZW9mIF9idXR0b24uY2FsbGJhY2sgPT09ICdmdW5jdGlvbicpIHtcclxuICAgICAgICAgICAgX2J1dHRvbi5jYWxsYmFjayhfZXZlbnQsIF9idXR0b24pO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF9jaGVja0luaXRGaWxlKCk6IHZvaWQge1xyXG4gICAgICAgIGlmICh0eXBlb2YgdGhpcy52YWx1ZSAhPT0gJ3VuZGVmaW5lZCcpIHtcclxuICAgICAgICAgICAgdGhpcy5fZmlsZVJlc3VsdC5kYXRhID0gdGhpcy52YWx1ZS5kYXRhO1xyXG4gICAgICAgICAgICB0aGlzLl9maWxlUmVzdWx0LmV4dGVuc2lvbiA9IHRoaXMudmFsdWUuZXh0ZW5zaW9uO1xyXG4gICAgICAgICAgICB0aGlzLl9maWxlUmVzdWx0LmZpbGVuYW1lID0gdGhpcy52YWx1ZS5maWxlbmFtZTtcclxuICAgICAgICAgICAgdGhpcy5fZmlsZVJlc3VsdC5zcmMgPSB0aGlzLnZhbHVlLnNyYztcclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgLy8gcHJpdmF0ZSBfZ2V0UmVzdWx0KGJpbmFyeVN0cmluZzogc3RyaW5nLCBmaWxlOiBhbnkpOiBJRmlsZVJlc3VsdCB7XHJcbiAgICAvLyAgICAgbGV0IGRhdGFVcmk6IHN0cmluZyA9ICdkYXRhOicgKyBmaWxlLnR5cGUgKyAnO2Jhc2U2NCwnO1xyXG4gICAgLy8gICAgIGxldCBiYXNlNjRTdHJpbmc6IHN0cmluZyA9IGJ0b2EoYmluYXJ5U3RyaW5nKTtcclxuICAgIC8vICAgICBsZXQgZmluZEV4dGVuc2lvbjogQXJyYXk8c3RyaW5nPiA9IGZpbGUubmFtZS5zcGxpdCgnLicpO1xyXG5cclxuICAgIC8vICAgICAvLyBsZXQgbmV3UmVzdWx0OiBJRmlsZVJlc3VsdCA9XHJcblxyXG4gICAgLy8gICAgIC8vIG5ld1Jlc3VsdC5kYXRhID0gYmFzZTY0U3RyaW5nO1xyXG4gICAgLy8gICAgIC8vIG5ld1Jlc3VsdC5zcmMgPSBkYXRhVXJpICsgYmFzZTY0U3RyaW5nO1xyXG4gICAgLy8gICAgIC8vIG5ld1Jlc3VsdC5maWxlbmFtZSA9IGZpbGUubmFtZTtcclxuICAgIC8vICAgICAvLyBuZXdSZXN1bHQuZXh0ZW5zaW9uID0gZmluZEV4dGVuc2lvbltmaW5kRXh0ZW5zaW9uLmxlbmd0aCAtIDFdO1xyXG4gICAgLy8gICAgIHJldHVybiB7XHJcbiAgICAvLyAgICAgICAgIGRhdGE6IGJhc2U2NFN0cmluZyxcclxuICAgIC8vICAgICAgICAgc3JjOiBkYXRhVXJpICsgYmFzZTY0U3RyaW5nLFxyXG4gICAgLy8gICAgICAgICBmaWxlbmFtZTogZmlsZS5uYW1lLFxyXG4gICAgLy8gICAgICAgICBleHRlbnNpb246IGZpbmRFeHRlbnNpb25bZmluZEV4dGVuc2lvbi5sZW5ndGggLSAxXSxcclxuICAgIC8vICAgICB9O1xyXG4gICAgLy8gfVxyXG5cclxuICAgIHByaXZhdGUgX3NldEZpbGVUeXBlKCkge1xyXG4gICAgICAgIGlmICh0eXBlb2YgdGhpcy5jb25maWcgIT09ICd1bmRlZmluZWQnICYmIHR5cGVvZiB0aGlzLmNvbmZpZy5maWxlVHlwZSA9PT0gJ3VuZGVmaW5lZCcpIHtcclxuICAgICAgICAgICAgdGhpcy5jb25maWdbJ2ZpbGVUeXBlJ10gPSAnZmlsZV9leHRlbnNpb24sIG1lZGlhX3R5cGUnO1xyXG4gICAgICAgIH1cclxuICAgICAgICBlbHNlIGlmICh0aGlzLmNvbmZpZy5maWxlVHlwZSA9PT0gJ2ltYWdlJykge1xyXG4gICAgICAgICAgICB0aGlzLmNvbmZpZy5maWxlVHlwZSA9ICdpbWFnZS8qJztcclxuICAgICAgICB9XHJcbiAgICAgICAgZWxzZSBpZiAodGhpcy5jb25maWcuZmlsZVR5cGUgPT09ICdtZWRpYScpIHtcclxuICAgICAgICAgICAgdGhpcy5jb25maWcuZmlsZVR5cGUgPSAnYXVkaW8vKiwgdmlkZW8vKic7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGVsc2UgaWYgKHRoaXMuY29uZmlnLmZpbGVUeXBlID09PSAndGV4dCcpIHtcclxuICAgICAgICAgICAgdGhpcy5jb25maWcuZmlsZVR5cGUgPSAnLmNzdiwgLnBkZiwgLnhsLCAueGxhLCAueGxiLCAueGxjLCAueGxkLCAueGxrLCAueGxsLCAueGxtLCAueGxzLCAueGx0LCAueGx2LCAueGx3LCAuZG9jLCAuZG90JztcclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfc2V0TGVmdEJ0bigpIHtcclxuICAgICAgICBpZiAodHlwZW9mIHRoaXMuY29uZmlnLmxlZnRCdXR0b24gIT09ICd1bmRlZmluZWQnICYmIHRoaXMuY29uZmlnLmxlZnRUb29sYmFyID09PSB0cnVlKSB7XHJcbiAgICAgICAgICAgIGlmICh0aGlzLmNvbmZpZy5sZWZ0QnV0dG9uLmxlbmd0aCA9PT0gMSkge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5fbGVmdEJ1dHRvbiA9ICdpbnB1dC1zaW5nbGUtYnRuJztcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgICAgIHRoaXMuX2xlZnRCdXR0b24gPSAnaW5wdXQtZG91YmxlLWJ0bic7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICB9XHJcbn1cclxuIl19