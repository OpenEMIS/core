import { Component, ViewContainerRef, Input, Output, EventEmitter, ViewChild, ViewEncapsulation, Renderer2 } from '@angular/core';
import { timer } from 'rxjs';
import { KdTextInputSvc } from './kd-angular-textinput-svc';
import { KdDomElemSvc } from '../kd-common/index';
import { AutoComplete } from 'primeng/autocomplete';
export class KdTextInput {
    constructor(_renderer, _vcr, _textInputSvc) {
        this._renderer = _renderer;
        this._vcr = _vcr;
        this._textInputSvc = _textInputSvc;
        this._textSetting = {};
        this._isLoading = false;
        this.updatedValue = new EventEmitter();
    }
    ngOnInit() {
        this._textSetting = this._textInputSvc.setInitSetting(this.config);
        this._textValue = (typeof this.value !== 'undefined') ? this.value : '';
        if (typeof this.options !== 'undefined' && this.options !== null) {
            let currentSelected = typeof this._textValue !== 'undefined' ? this._textValue : [];
            this._resultList = this._textInputSvc.checkMultiSelect(this.options, currentSelected);
        }
        else if (typeof this.config.dropdownCallback === 'undefined') {
            this._textSetting.multiselect = false;
            this._textSetting.autocomplete = false;
        }
    }
    ngOnChanges(changes) {
        if (changes.hasOwnProperty('options') && typeof changes['options'].currentValue !== 'undefined') {
            let currentSelected = typeof this._textValue !== 'undefined' ? this._textValue : [];
            this._resultList = this._textInputSvc.checkMultiSelect(changes['options'].currentValue, currentSelected);
        }
        if (changes.hasOwnProperty('value')) {
            if (typeof changes['value'] !== 'undefined' && typeof changes['value'].currentValue !== 'undefined') {
                if (changes['value'].currentValue !== '') {
                    this._textValue = changes['value'].currentValue;
                }
                else {
                    if (this._textSetting.multiselect) {
                        this._textValue = [];
                    }
                    else {
                        this._textValue = '';
                    }
                }
            }
            else {
                this._textValue = '';
            }
            // this._textValue = (typeof changes["value"].currentValue != "undefined") ? changes["value"].currentValue : "";
        }
    }
    ngAfterViewInit() {
        timer().subscribe(() => {
            if (this._textSetting.multiselect && this._textSetting.dropdownToggle) {
                let queryString = '.ui-autocomplete-multiple .ui-autocomplete-input-token input';
                this._addClickListener(queryString);
            }
            else if (this._textSetting.autocomplete && this._textSetting.dropdownToggle) {
                let queryString = '.ui-autocomplete input.ui-inputtext';
                this._addClickListener(queryString);
            }
        });
    }
    ngOnDestroy() {
        if (typeof this._subscription !== 'undefined')
            this._subscription.unsubscribe();
        if (typeof this._rendererListenFunc !== 'undefined')
            this._rendererListenFunc();
    }
    emitValue() {
        this.updatedValue.emit(this._textValue);
    }
    searchMulti(_event, _state) {
        let query = this._textInputSvc.checkQuery(_event);
        if (typeof this._resultList !== 'undefined') {
            let searchResult = this._textInputSvc.searchList(query, this._resultList);
            this._checkSearchResult(searchResult, query);
        }
        else {
            this._checkLoadingFunc(query);
        }
    }
    multiSelection(val, state) {
        if (this._textSetting.multiselect && typeof this._resultList !== 'undefined') {
            this._updateResultList(val, state);
        }
    }
    checkEnterAndError(event) {
        let inputVal = event.target.value;
        if (inputVal.length < this._textSetting.minLength) {
            this.config.errors = undefined;
        }
        if (event.key === 'Backspace' && typeof this.config.dropdownCallback !== 'undefined' && !this._textSetting.enter) {
            if (typeof this._subscription !== 'undefined') {
                this._subscription.unsubscribe();
            }
            this._isLoading = false;
        }
        if (event.key === 'Enter' && typeof inputVal !== 'undefined' && inputVal !== '') {
            if (this._textSetting.multiselect) {
                this.searchMulti(inputVal, 'selected');
            }
            else if (!this._textSetting.multiselect && typeof this.config.value !== 'undefined' && typeof this.config.value !== 'object') {
                this.searchMulti(inputVal, 'selected');
            }
        }
    }
    _addClickListener(_queryString) {
        let clickEventEle = this._vcr.element.nativeElement.querySelector(_queryString);
        this._rendererListenFunc = this._renderer.listen(clickEventEle, 'click', (_event) => {
            this.autocompleteComponent.handleDropdownClick(_event);
        });
    }
    _updateResultList(_val, _state) {
        if (_state === 'selected') {
            for (let i = 0; i < this._resultList.length; i++) {
                if (_val.value === this._resultList[i].value) {
                    this._resultList.splice(i, 1);
                    break;
                }
            }
        }
        else {
            let sortFunc = (a, b) => {
                if (a.value < b.value)
                    return -1;
                else if (a.value > b.value)
                    return 1;
                return 0;
            };
            this._resultList.push(_val);
            this._resultList.sort(sortFunc);
        }
    }
    _checkSearchResult(_value, _query) {
        let filteredOptions = this._textInputSvc.filterOptionList(_value, this._textValue);
        timer().subscribe(() => {
            this._suggestionList = filteredOptions.slice();
            let checkedResult = this._textInputSvc.checkError(this._suggestionList, _query);
            if (typeof checkedResult !== 'undefined') {
                let result = [];
                result.push(checkedResult.dialogueMessage);
                this.config.errors = result;
            }
        });
    }
    _checkLoadingFunc(_query) {
        this._isLoading = true;
        let selectedVal = (typeof this.config.value !== 'undefined') ? this.config.value : [];
        let params = { query: _query, currentSelected: selectedVal };
        if (typeof this._subscription !== 'undefined') {
            this._subscription.unsubscribe();
        }
        this._subscription = this.config.dropdownCallback(params).subscribe((_value) => {
            // console.log(">>> value", _value);
            this._checkSearchResult(_value, _query);
            this._isLoading = false;
        });
    }
}
KdTextInput.decorators = [
    { type: Component, args: [{
                selector: 'kd-text-input',
                template: "<p-autoComplete \r\n\t*ngIf=\"_textSetting.multiselect && !_textSetting.enter\" \r\n\t[multiple]=\"_textSetting.multiselect\" \r\n\t[suggestions]=\"_suggestionList\" \r\n\t(keyup)=\"checkEnterAndError($event)\" \r\n\t(completeMethod)=\"searchMulti($event, 'complete')\" \r\n\t(onSelect)=\"multiSelection($event, 'selected')\" \r\n\t(onUnselect)=\"multiSelection($event, 'unselected')\" \r\n\t[minLength]=\"_textSetting.minLength\" \r\n\t(onDropdownClick)=\"searchMulti($event, 'dropdown')\" \r\n\t[(ngModel)]=\"_textValue\" \r\n\t(ngModelChange)=\"emitValue()\" \r\n\t[disabled]=\"disabled || readonly\" \r\n\t[placeholder]=\"_textSetting.placeholder\"\r\n\tfield=\"value\"\r\n\tclass=\"kdx-p-autocomplete\"\r\n>\r\n</p-autoComplete>\r\n\r\n<p-autoComplete  \r\n\t*ngIf=\"_textSetting.autocomplete && !_textSetting.enter\"\r\n\t[suggestions]=\"_suggestionList\"\r\n\t(keyup)=\"checkEnterAndError($event)\"\r\n\t(completeMethod)=\"searchMulti($event, 'complete')\"\r\n\t(onSelect)=\"multiSelection($event, 'selected')\"\r\n\t[minLength]=\"_textSetting.minLength\"\r\n\t[placeholder]=\"_textSetting.placeholder\"\r\n\t(onDropdownClick)=\"searchMulti($event, 'dropdown')\"\r\n\t[(ngModel)]=\"_textValue\" \r\n\t(ngModelChange)=\"emitValue()\"\r\n\t[disabled]=\"disabled\"\r\n\t[readonly]=\"readonly\" \r\n\tfield=\"value\"\r\n\tclass=\"kdx-p-autocomplete\"\r\n>\r\n</p-autoComplete>\r\n\r\n<div *ngIf=\"_textSetting.multiselect && _textSetting.enter\" class=\"kdx-input-with-btn\">\r\n\t<p-autoComplete \r\n\t\t[multiple]=\"_textSetting.multiselect\"\r\n\t\t(keyup)=\"checkEnterAndError($event)\"\r\n\t\t[dropdown]=\"true\"\r\n\t\t(completeMethod)=\"searchMulti($event, 'complete')\"\r\n\t\t[suggestions]=\"_suggestionList\"\r\n\t\t(onSelect)=\"multiSelection($event, 'selected')\"\r\n\t\t(onUnselect)=\"multiSelection($event, 'unselected')\"\r\n\t\t(onDropdownClick)=\"searchMulti($event, 'dropdown')\"\r\n\t\t[placeholder]=\"_textSetting.placeholder\"\r\n\t\t[(ngModel)]=\"_textValue\" \r\n\t\t(ngModelChange)=\"emitValue()\"\r\n\t\t[disabled]=\"disabled || readonly\"\r\n\t\t[readonly]=\"readonly\"\r\n\t\tfield=\"value\"\r\n\t\tclass=\"kdx-p-autocomplete\"\r\n\t>\r\n\t</p-autoComplete>\r\n</div>\r\n\r\n<div *ngIf=\"_textSetting.autocomplete && _textSetting.enter\" class=\"kdx-input-with-btn\">\r\n\t<p-autoComplete \r\n\t\t(keyup)=\"checkEnterAndError($event)\"\r\n\t\t[dropdown]=\"true\"\r\n\t\t[suggestions]=\"_suggestionList\"\r\n\t\t(completeMethod)=\"searchMulti($event, 'complete')\"\r\n\t\t(onDropdownClick)=\"searchMulti($event, 'dropdown')\"\r\n\t\t(onSelect)=\"multiSelection($event, 'selected')\"\r\n\t\t[placeholder]=\"_textSetting.placeholder\"\r\n\t\t[(ngModel)]=\"_textValue\" \r\n\t\t(ngModelChange)=\"emitValue()\"\r\n\t\t[disabled]=\"disabled\"\r\n\t\t[readonly]=\"readonly\" \r\n\t\tfield=\"value\"\r\n\t\tclass=\"kdx-p-autocomplete\"\r\n\t>\r\n\t</p-autoComplete>\r\n</div>\r\n\r\n<div [hidden]=\"!_isLoading\" class=\"kdx-input-loader-wrapper\">\r\n\t<i class=\"fa fa-spinner fa-pulse fa-lg fa-fw input-loader\"></i>\r\n</div>\r\n\r\n<input \r\n\t*ngIf=\"!_textSetting.autocomplete && !_textSetting.multiselect\" \r\n\ttype=\"text\" \r\n\t[placeholder]=\"_textSetting.placeholder\" \r\n\t[(ngModel)]=\"_textValue\" \r\n\t[attr.maxlength]=\"maxLength\" \r\n\t[attr.disabled]=\"disabled ? disabled : null\" \r\n\t[attr.readonly]=\"readonly ? readonly : null\" \r\n\t(ngModelChange)=\"emitValue()\"\r\n/>\r\n\r\n<ng-content></ng-content>",
                encapsulation: ViewEncapsulation.None,
                providers: [KdTextInputSvc, KdDomElemSvc],
                host: { 'class': 'kdx kdx-text-input' }
            },] }
];
KdTextInput.ctorParameters = () => [
    { type: Renderer2 },
    { type: ViewContainerRef },
    { type: KdTextInputSvc }
];
KdTextInput.propDecorators = {
    config: [{ type: Input }],
    options: [{ type: Input }],
    disabled: [{ type: Input }],
    readonly: [{ type: Input }],
    value: [{ type: Input }],
    maxLength: [{ type: Input }],
    updatedValue: [{ type: Output }],
    autocompleteComponent: [{ type: ViewChild, args: [AutoComplete,] }]
};
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoia2QtYW5ndWxhci10ZXh0LWlucHV0LmpzIiwic291cmNlUm9vdCI6IkM6L1Byb2plY3RzL0FuZ3VsYXIvaW9zdGctb3BlbmVtaXMtc3R5bGVndWlkZS9wcm9qZWN0cy9vcGVuZW1pcy1zdHlsZWd1aWRlLWxpYi9zcmMvIiwic291cmNlcyI6WyJrZC1jb21wb25lbnRzL2tkLWFuZ3VsYXItdGV4dC1pbnB1dC9rZC1hbmd1bGFyLXRleHQtaW5wdXQudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsT0FBTyxFQUFFLFNBQVMsRUFBRSxnQkFBZ0IsRUFBRSxLQUFLLEVBQWEsTUFBTSxFQUFFLFlBQVksRUFBRSxTQUFTLEVBQUUsaUJBQWlCLEVBQW1ELFNBQVMsRUFBRSxNQUFNLGVBQWUsQ0FBQztBQUM5TCxPQUFPLEVBQUUsS0FBSyxFQUFrQixNQUFNLE1BQU0sQ0FBQztBQUM3QyxPQUFPLEVBQUUsY0FBYyxFQUFFLE1BQU0sNEJBQTRCLENBQUM7QUFDNUQsT0FBTyxFQUFFLFlBQVksRUFBRSxNQUFNLG9CQUFvQixDQUFDO0FBQ2xELE9BQU8sRUFBRSxZQUFZLEVBQUUsTUFBTSxzQkFBc0IsQ0FBQztBQVdwRCxNQUFNLE9BQU8sV0FBVztJQWtCcEIsWUFDWSxTQUFvQixFQUNwQixJQUFzQixFQUN0QixhQUE2QjtRQUY3QixjQUFTLEdBQVQsU0FBUyxDQUFXO1FBQ3BCLFNBQUksR0FBSixJQUFJLENBQWtCO1FBQ3RCLGtCQUFhLEdBQWIsYUFBYSxDQUFnQjtRQXBCbEMsaUJBQVksR0FBUSxFQUFFLENBQUM7UUFDdkIsZUFBVSxHQUFZLEtBQUssQ0FBQztRQWF6QixpQkFBWSxHQUFzQixJQUFJLFlBQVksRUFBRSxDQUFDO0lBTzNELENBQUM7SUFFTCxRQUFRO1FBQ0osSUFBSSxDQUFDLFlBQVksR0FBRyxJQUFJLENBQUMsYUFBYSxDQUFDLGNBQWMsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUM7UUFDbkUsSUFBSSxDQUFDLFVBQVUsR0FBRyxDQUFDLE9BQU8sSUFBSSxDQUFDLEtBQUssS0FBSyxXQUFXLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDO1FBRXhFLElBQUksT0FBTyxJQUFJLENBQUMsT0FBTyxLQUFLLFdBQVcsSUFBSSxJQUFJLENBQUMsT0FBTyxLQUFLLElBQUksRUFBRTtZQUM5RCxJQUFJLGVBQWUsR0FBZSxPQUFPLElBQUksQ0FBQyxVQUFVLEtBQUssV0FBVyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUM7WUFDaEcsSUFBSSxDQUFDLFdBQVcsR0FBRyxJQUFJLENBQUMsYUFBYSxDQUFDLGdCQUFnQixDQUFDLElBQUksQ0FBQyxPQUFPLEVBQUUsZUFBZSxDQUFDLENBQUM7U0FDekY7YUFDSSxJQUFJLE9BQU8sSUFBSSxDQUFDLE1BQU0sQ0FBQyxnQkFBZ0IsS0FBSyxXQUFXLEVBQUU7WUFDMUQsSUFBSSxDQUFDLFlBQVksQ0FBQyxXQUFXLEdBQUcsS0FBSyxDQUFDO1lBQ3RDLElBQUksQ0FBQyxZQUFZLENBQUMsWUFBWSxHQUFHLEtBQUssQ0FBQztTQUMxQztJQUNMLENBQUM7SUFFRCxXQUFXLENBQUMsT0FBc0I7UUFDOUIsSUFBSSxPQUFPLENBQUMsY0FBYyxDQUFDLFNBQVMsQ0FBQyxJQUFJLE9BQU8sT0FBTyxDQUFDLFNBQVMsQ0FBQyxDQUFDLFlBQVksS0FBSyxXQUFXLEVBQUU7WUFDN0YsSUFBSSxlQUFlLEdBQWUsT0FBTyxJQUFJLENBQUMsVUFBVSxLQUFLLFdBQVcsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDO1lBQ2hHLElBQUksQ0FBQyxXQUFXLEdBQUcsSUFBSSxDQUFDLGFBQWEsQ0FBQyxnQkFBZ0IsQ0FBQyxPQUFPLENBQUMsU0FBUyxDQUFDLENBQUMsWUFBWSxFQUFFLGVBQWUsQ0FBQyxDQUFDO1NBQzVHO1FBRUQsSUFBSSxPQUFPLENBQUMsY0FBYyxDQUFDLE9BQU8sQ0FBQyxFQUFFO1lBQ2pDLElBQUksT0FBTyxPQUFPLENBQUMsT0FBTyxDQUFDLEtBQUssV0FBVyxJQUFJLE9BQU8sT0FBTyxDQUFDLE9BQU8sQ0FBQyxDQUFDLFlBQVksS0FBSyxXQUFXLEVBQUU7Z0JBQ2pHLElBQUksT0FBTyxDQUFDLE9BQU8sQ0FBQyxDQUFDLFlBQVksS0FBSyxFQUFFLEVBQUU7b0JBQ3RDLElBQUksQ0FBQyxVQUFVLEdBQUcsT0FBTyxDQUFDLE9BQU8sQ0FBQyxDQUFDLFlBQVksQ0FBQztpQkFDbkQ7cUJBQ0k7b0JBQ0QsSUFBSSxJQUFJLENBQUMsWUFBWSxDQUFDLFdBQVcsRUFBRTt3QkFDL0IsSUFBSSxDQUFDLFVBQVUsR0FBRyxFQUFFLENBQUM7cUJBQ3hCO3lCQUNJO3dCQUNELElBQUksQ0FBQyxVQUFVLEdBQUcsRUFBRSxDQUFDO3FCQUN4QjtpQkFDSjthQUNKO2lCQUFNO2dCQUNILElBQUksQ0FBQyxVQUFVLEdBQUcsRUFBRSxDQUFDO2FBQ3hCO1lBRUQsZ0hBQWdIO1NBQ25IO0lBQ0wsQ0FBQztJQUVELGVBQWU7UUFDWCxLQUFLLEVBQUUsQ0FBQyxTQUFTLENBQUMsR0FBUyxFQUFFO1lBQ3pCLElBQUksSUFBSSxDQUFDLFlBQVksQ0FBQyxXQUFXLElBQUksSUFBSSxDQUFDLFlBQVksQ0FBQyxjQUFjLEVBQUU7Z0JBQ25FLElBQUksV0FBVyxHQUFXLDhEQUE4RCxDQUFDO2dCQUN6RixJQUFJLENBQUMsaUJBQWlCLENBQUMsV0FBVyxDQUFDLENBQUM7YUFDdkM7aUJBQ0ksSUFBSSxJQUFJLENBQUMsWUFBWSxDQUFDLFlBQVksSUFBSSxJQUFJLENBQUMsWUFBWSxDQUFDLGNBQWMsRUFBRTtnQkFDekUsSUFBSSxXQUFXLEdBQVcscUNBQXFDLENBQUM7Z0JBQ2hFLElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxXQUFXLENBQUMsQ0FBQzthQUN2QztRQUNMLENBQUMsQ0FBQyxDQUFDO0lBRVAsQ0FBQztJQUVELFdBQVc7UUFDUCxJQUFJLE9BQU8sSUFBSSxDQUFDLGFBQWEsS0FBSyxXQUFXO1lBQUUsSUFBSSxDQUFDLGFBQWEsQ0FBQyxXQUFXLEVBQUUsQ0FBQztRQUNoRixJQUFJLE9BQU8sSUFBSSxDQUFDLG1CQUFtQixLQUFLLFdBQVc7WUFBRSxJQUFJLENBQUMsbUJBQW1CLEVBQUUsQ0FBQztJQUNwRixDQUFDO0lBRUQsU0FBUztRQUNMLElBQUksQ0FBQyxZQUFZLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsQ0FBQztJQUM1QyxDQUFDO0lBRUQsV0FBVyxDQUFDLE1BQVcsRUFBRSxNQUFjO1FBQ25DLElBQUksS0FBSyxHQUFXLElBQUksQ0FBQyxhQUFhLENBQUMsVUFBVSxDQUFDLE1BQU0sQ0FBQyxDQUFDO1FBRTFELElBQUksT0FBTyxJQUFJLENBQUMsV0FBVyxLQUFLLFdBQVcsRUFBRTtZQUN6QyxJQUFJLFlBQVksR0FBZSxJQUFJLENBQUMsYUFBYSxDQUFDLFVBQVUsQ0FBQyxLQUFLLEVBQUUsSUFBSSxDQUFDLFdBQVcsQ0FBQyxDQUFDO1lBQ3RGLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxZQUFZLEVBQUUsS0FBSyxDQUFDLENBQUM7U0FDaEQ7YUFDSTtZQUNELElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxLQUFLLENBQUMsQ0FBQztTQUNqQztJQUNMLENBQUM7SUFFRCxjQUFjLENBQUMsR0FBUSxFQUFFLEtBQWE7UUFDbEMsSUFBSSxJQUFJLENBQUMsWUFBWSxDQUFDLFdBQVcsSUFBSSxPQUFPLElBQUksQ0FBQyxXQUFXLEtBQUssV0FBVyxFQUFFO1lBQzFFLElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxHQUFHLEVBQUUsS0FBSyxDQUFDLENBQUM7U0FDdEM7SUFDTCxDQUFDO0lBRUQsa0JBQWtCLENBQUMsS0FBVTtRQUN6QixJQUFJLFFBQVEsR0FBVyxLQUFLLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQztRQUUxQyxJQUFJLFFBQVEsQ0FBQyxNQUFNLEdBQUcsSUFBSSxDQUFDLFlBQVksQ0FBQyxTQUFTLEVBQUU7WUFDL0MsSUFBSSxDQUFDLE1BQU0sQ0FBQyxNQUFNLEdBQUcsU0FBUyxDQUFDO1NBQ2xDO1FBRUQsSUFBSSxLQUFLLENBQUMsR0FBRyxLQUFLLFdBQVcsSUFBSSxPQUFPLElBQUksQ0FBQyxNQUFNLENBQUMsZ0JBQWdCLEtBQUssV0FBVyxJQUFJLENBQUMsSUFBSSxDQUFDLFlBQVksQ0FBQyxLQUFLLEVBQUU7WUFDOUcsSUFBSSxPQUFPLElBQUksQ0FBQyxhQUFhLEtBQUssV0FBVyxFQUFFO2dCQUMzQyxJQUFJLENBQUMsYUFBYSxDQUFDLFdBQVcsRUFBRSxDQUFDO2FBQ3BDO1lBRUQsSUFBSSxDQUFDLFVBQVUsR0FBRyxLQUFLLENBQUM7U0FDM0I7UUFFRCxJQUFJLEtBQUssQ0FBQyxHQUFHLEtBQUssT0FBTyxJQUFJLE9BQU8sUUFBUSxLQUFLLFdBQVcsSUFBSSxRQUFRLEtBQUssRUFBRSxFQUFFO1lBQzdFLElBQUksSUFBSSxDQUFDLFlBQVksQ0FBQyxXQUFXLEVBQUU7Z0JBQy9CLElBQUksQ0FBQyxXQUFXLENBQUMsUUFBUSxFQUFFLFVBQVUsQ0FBQyxDQUFDO2FBQzFDO2lCQUVJLElBQUksQ0FBQyxJQUFJLENBQUMsWUFBWSxDQUFDLFdBQVcsSUFBSSxPQUFPLElBQUksQ0FBQyxNQUFNLENBQUMsS0FBSyxLQUFLLFdBQVcsSUFBSSxPQUFPLElBQUksQ0FBQyxNQUFNLENBQUMsS0FBSyxLQUFLLFFBQVEsRUFBRTtnQkFDMUgsSUFBSSxDQUFDLFdBQVcsQ0FBQyxRQUFRLEVBQUUsVUFBVSxDQUFDLENBQUM7YUFDMUM7U0FDSjtJQUNMLENBQUM7SUFFTyxpQkFBaUIsQ0FBQyxZQUFvQjtRQUMxQyxJQUFJLGFBQWEsR0FBZ0IsSUFBSSxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsYUFBYSxDQUFDLGFBQWEsQ0FBQyxZQUFZLENBQUMsQ0FBQztRQUU3RixJQUFJLENBQUMsbUJBQW1CLEdBQUcsSUFBSSxDQUFDLFNBQVMsQ0FBQyxNQUFNLENBQUMsYUFBYSxFQUFFLE9BQU8sRUFBRSxDQUFDLE1BQVcsRUFBUSxFQUFFO1lBQ25HLElBQUksQ0FBQyxxQkFBcUIsQ0FBQyxtQkFBbUIsQ0FBQyxNQUFNLENBQUMsQ0FBQztRQUMzRCxDQUFDLENBQUMsQ0FBQztJQUNDLENBQUM7SUFFTyxpQkFBaUIsQ0FBQyxJQUFTLEVBQUUsTUFBYztRQUMvQyxJQUFJLE1BQU0sS0FBSyxVQUFVLEVBQUU7WUFDdkIsS0FBSyxJQUFJLENBQUMsR0FBVyxDQUFDLEVBQUUsQ0FBQyxHQUFHLElBQUksQ0FBQyxXQUFXLENBQUMsTUFBTSxFQUFFLENBQUMsRUFBRSxFQUFFO2dCQUN0RCxJQUFJLElBQUksQ0FBQyxLQUFLLEtBQUssSUFBSSxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLEVBQUU7b0JBQzFDLElBQUksQ0FBQyxXQUFXLENBQUMsTUFBTSxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQztvQkFDOUIsTUFBTTtpQkFDVDthQUNKO1NBQ0o7YUFDSTtZQUNELElBQUksUUFBUSxHQUErQixDQUFDLENBQU0sRUFBRSxDQUFNLEVBQVUsRUFBRTtnQkFDbEUsSUFBSSxDQUFDLENBQUMsS0FBSyxHQUFHLENBQUMsQ0FBQyxLQUFLO29CQUFFLE9BQU8sQ0FBQyxDQUFDLENBQUM7cUJBQzVCLElBQUksQ0FBQyxDQUFDLEtBQUssR0FBRyxDQUFDLENBQUMsS0FBSztvQkFBRSxPQUFPLENBQUMsQ0FBQztnQkFDckMsT0FBTyxDQUFDLENBQUM7WUFDYixDQUFDLENBQUM7WUFFRixJQUFJLENBQUMsV0FBVyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQztZQUM1QixJQUFJLENBQUMsV0FBVyxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsQ0FBQztTQUNuQztJQUNMLENBQUM7SUFFTyxrQkFBa0IsQ0FBQyxNQUFrQixFQUFFLE1BQWM7UUFDekQsSUFBSSxlQUFlLEdBQWUsSUFBSSxDQUFDLGFBQWEsQ0FBQyxnQkFBZ0IsQ0FBQyxNQUFNLEVBQUUsSUFBSSxDQUFDLFVBQVUsQ0FBQyxDQUFDO1FBRS9GLEtBQUssRUFBRSxDQUFDLFNBQVMsQ0FBQyxHQUFTLEVBQUU7WUFDekIsSUFBSSxDQUFDLGVBQWUsR0FBRyxlQUFlLENBQUMsS0FBSyxFQUFFLENBQUM7WUFFL0MsSUFBSSxhQUFhLEdBQUcsSUFBSSxDQUFDLGFBQWEsQ0FBQyxVQUFVLENBQUMsSUFBSSxDQUFDLGVBQWUsRUFBRSxNQUFNLENBQUMsQ0FBQztZQUVoRixJQUFJLE9BQU8sYUFBYSxLQUFLLFdBQVcsRUFBRTtnQkFDdEMsSUFBSSxNQUFNLEdBQWtCLEVBQUUsQ0FBQztnQkFDL0IsTUFBTSxDQUFDLElBQUksQ0FBQyxhQUFhLENBQUMsZUFBZSxDQUFDLENBQUM7Z0JBQzNDLElBQUksQ0FBQyxNQUFNLENBQUMsTUFBTSxHQUFHLE1BQU0sQ0FBQzthQUMvQjtRQUNMLENBQUMsQ0FBQyxDQUFDO0lBQ1AsQ0FBQztJQUVPLGlCQUFpQixDQUFDLE1BQWM7UUFDcEMsSUFBSSxDQUFDLFVBQVUsR0FBRyxJQUFJLENBQUM7UUFFdkIsSUFBSSxXQUFXLEdBQUcsQ0FBQyxPQUFPLElBQUksQ0FBQyxNQUFNLENBQUMsS0FBSyxLQUFLLFdBQVcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDO1FBQ3RGLElBQUksTUFBTSxHQUFHLEVBQUMsS0FBSyxFQUFFLE1BQU0sRUFBRSxlQUFlLEVBQUUsV0FBVyxFQUFDLENBQUM7UUFFM0QsSUFBSSxPQUFPLElBQUksQ0FBQyxhQUFhLEtBQUssV0FBVyxFQUFFO1lBQzNDLElBQUksQ0FBQyxhQUFhLENBQUMsV0FBVyxFQUFFLENBQUM7U0FDcEM7UUFFRCxJQUFJLENBQUMsYUFBYSxHQUFHLElBQUksQ0FBQyxNQUFNLENBQUMsZ0JBQWdCLENBQUMsTUFBTSxDQUFDLENBQUMsU0FBUyxDQUFDLENBQUMsTUFBVyxFQUFRLEVBQUU7WUFDdEYsb0NBQW9DO1lBQ3BDLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxNQUFNLEVBQUUsTUFBTSxDQUFDLENBQUM7WUFDeEMsSUFBSSxDQUFDLFVBQVUsR0FBRyxLQUFLLENBQUM7UUFDNUIsQ0FBQyxDQUFDLENBQUM7SUFDUCxDQUFDOzs7WUF4TUosU0FBUyxTQUFDO2dCQUNQLFFBQVEsRUFBRSxlQUFlO2dCQUN6QiwrNEdBQTJDO2dCQUMzQyxhQUFhLEVBQUUsaUJBQWlCLENBQUMsSUFBSTtnQkFDckMsU0FBUyxFQUFFLENBQUMsY0FBYyxFQUFFLFlBQVksQ0FBQztnQkFDekMsSUFBSSxFQUFHLEVBQUUsT0FBTyxFQUFHLG9CQUFvQixFQUFFO2FBQzVDOzs7WUFiNEosU0FBUztZQUFsSixnQkFBZ0I7WUFFM0IsY0FBYzs7O3FCQXNCbEIsS0FBSztzQkFDTCxLQUFLO3VCQUNMLEtBQUs7dUJBQ0wsS0FBSztvQkFDTCxLQUFLO3dCQUNMLEtBQUs7MkJBQ0wsTUFBTTtvQ0FDTixTQUFTLFNBQUMsWUFBWSIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IENvbXBvbmVudCwgVmlld0NvbnRhaW5lclJlZiwgSW5wdXQsIE9uQ2hhbmdlcywgT3V0cHV0LCBFdmVudEVtaXR0ZXIsIFZpZXdDaGlsZCwgVmlld0VuY2Fwc3VsYXRpb24sIE9uSW5pdCwgQWZ0ZXJWaWV3SW5pdCwgT25EZXN0cm95LCBTaW1wbGVDaGFuZ2VzLCBSZW5kZXJlcjIgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcclxuaW1wb3J0IHsgdGltZXIgLCAgU3Vic2NyaXB0aW9uIH0gZnJvbSAncnhqcyc7XHJcbmltcG9ydCB7IEtkVGV4dElucHV0U3ZjIH0gZnJvbSAnLi9rZC1hbmd1bGFyLXRleHRpbnB1dC1zdmMnO1xyXG5pbXBvcnQgeyBLZERvbUVsZW1TdmMgfSBmcm9tICcuLi9rZC1jb21tb24vaW5kZXgnO1xyXG5pbXBvcnQgeyBBdXRvQ29tcGxldGUgfSBmcm9tICdwcmltZW5nL2F1dG9jb21wbGV0ZSc7XHJcblxyXG5cclxuQENvbXBvbmVudCh7XHJcbiAgICBzZWxlY3RvcjogJ2tkLXRleHQtaW5wdXQnLFxyXG4gICAgdGVtcGxhdGVVcmw6ICcuL2tkLWFuZ3VsYXItdGV4dC1pbnB1dC5odG1sJyxcclxuICAgIGVuY2Fwc3VsYXRpb246IFZpZXdFbmNhcHN1bGF0aW9uLk5vbmUsXHJcbiAgICBwcm92aWRlcnM6IFtLZFRleHRJbnB1dFN2YywgS2REb21FbGVtU3ZjXSxcclxuICAgIGhvc3QgOiB7ICdjbGFzcycgOiAna2R4IGtkeC10ZXh0LWlucHV0JyB9XHJcbn0pXHJcblxyXG5leHBvcnQgY2xhc3MgS2RUZXh0SW5wdXQgaW1wbGVtZW50cyBPbkluaXQsIE9uQ2hhbmdlcywgQWZ0ZXJWaWV3SW5pdCwgT25EZXN0cm95IHtcclxuICAgIHB1YmxpYyBfdGV4dFNldHRpbmc6IGFueSA9IHt9O1xyXG4gICAgcHVibGljIF9pc0xvYWRpbmc6IGJvb2xlYW4gPSBmYWxzZTtcclxuICAgIHByaXZhdGUgX3Jlc3VsdExpc3Q6IEFycmF5PGFueT47XHJcbiAgICBwdWJsaWMgX3N1Z2dlc3Rpb25MaXN0OiBBcnJheTxzdHJpbmc+O1xyXG4gICAgcHJpdmF0ZSBfc3Vic2NyaXB0aW9uOiBTdWJzY3JpcHRpb247XHJcbiAgICBwcml2YXRlIF9yZW5kZXJlckxpc3RlbkZ1bmM6IEZ1bmN0aW9uO1xyXG4gICAgcHVibGljIF90ZXh0VmFsdWU6IGFueTtcclxuXHJcbiAgICBASW5wdXQoKSBjb25maWc6IGFueTtcclxuICAgIEBJbnB1dCgpIG9wdGlvbnM6IGFueTtcclxuICAgIEBJbnB1dCgpIGRpc2FibGVkOiBib29sZWFuO1xyXG4gICAgQElucHV0KCkgcmVhZG9ubHk6IGJvb2xlYW47XHJcbiAgICBASW5wdXQoKSB2YWx1ZTogYW55O1xyXG4gICAgQElucHV0KCkgbWF4TGVuZ3RoOiBudW1iZXI7XHJcbiAgICBAT3V0cHV0KCkgdXBkYXRlZFZhbHVlOiBFdmVudEVtaXR0ZXI8YW55PiA9IG5ldyBFdmVudEVtaXR0ZXIoKTtcclxuICAgIEBWaWV3Q2hpbGQoQXV0b0NvbXBsZXRlKSBhdXRvY29tcGxldGVDb21wb25lbnQ6IEF1dG9Db21wbGV0ZTtcclxuXHJcbiAgICBjb25zdHJ1Y3RvcihcclxuICAgICAgICBwcml2YXRlIF9yZW5kZXJlcjogUmVuZGVyZXIyLFxyXG4gICAgICAgIHByaXZhdGUgX3ZjcjogVmlld0NvbnRhaW5lclJlZixcclxuICAgICAgICBwcml2YXRlIF90ZXh0SW5wdXRTdmM6IEtkVGV4dElucHV0U3ZjXHJcbiAgICApIHsgfVxyXG5cclxuICAgIG5nT25Jbml0KCk6IHZvaWQge1xyXG4gICAgICAgIHRoaXMuX3RleHRTZXR0aW5nID0gdGhpcy5fdGV4dElucHV0U3ZjLnNldEluaXRTZXR0aW5nKHRoaXMuY29uZmlnKTtcclxuICAgICAgICB0aGlzLl90ZXh0VmFsdWUgPSAodHlwZW9mIHRoaXMudmFsdWUgIT09ICd1bmRlZmluZWQnKSA/IHRoaXMudmFsdWUgOiAnJztcclxuXHJcbiAgICAgICAgaWYgKHR5cGVvZiB0aGlzLm9wdGlvbnMgIT09ICd1bmRlZmluZWQnICYmIHRoaXMub3B0aW9ucyAhPT0gbnVsbCkge1xyXG4gICAgICAgICAgICBsZXQgY3VycmVudFNlbGVjdGVkOiBBcnJheTxhbnk+ID0gdHlwZW9mIHRoaXMuX3RleHRWYWx1ZSAhPT0gJ3VuZGVmaW5lZCcgPyB0aGlzLl90ZXh0VmFsdWUgOiBbXTtcclxuICAgICAgICAgICAgdGhpcy5fcmVzdWx0TGlzdCA9IHRoaXMuX3RleHRJbnB1dFN2Yy5jaGVja011bHRpU2VsZWN0KHRoaXMub3B0aW9ucywgY3VycmVudFNlbGVjdGVkKTtcclxuICAgICAgICB9XHJcbiAgICAgICAgZWxzZSBpZiAodHlwZW9mIHRoaXMuY29uZmlnLmRyb3Bkb3duQ2FsbGJhY2sgPT09ICd1bmRlZmluZWQnKSB7XHJcbiAgICAgICAgICAgIHRoaXMuX3RleHRTZXR0aW5nLm11bHRpc2VsZWN0ID0gZmFsc2U7XHJcbiAgICAgICAgICAgIHRoaXMuX3RleHRTZXR0aW5nLmF1dG9jb21wbGV0ZSA9IGZhbHNlO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICBuZ09uQ2hhbmdlcyhjaGFuZ2VzOiBTaW1wbGVDaGFuZ2VzKTogdm9pZCB7XHJcbiAgICAgICAgaWYgKGNoYW5nZXMuaGFzT3duUHJvcGVydHkoJ29wdGlvbnMnKSAmJiB0eXBlb2YgY2hhbmdlc1snb3B0aW9ucyddLmN1cnJlbnRWYWx1ZSAhPT0gJ3VuZGVmaW5lZCcpIHtcclxuICAgICAgICAgICAgbGV0IGN1cnJlbnRTZWxlY3RlZDogQXJyYXk8YW55PiA9IHR5cGVvZiB0aGlzLl90ZXh0VmFsdWUgIT09ICd1bmRlZmluZWQnID8gdGhpcy5fdGV4dFZhbHVlIDogW107XHJcbiAgICAgICAgICAgIHRoaXMuX3Jlc3VsdExpc3QgPSB0aGlzLl90ZXh0SW5wdXRTdmMuY2hlY2tNdWx0aVNlbGVjdChjaGFuZ2VzWydvcHRpb25zJ10uY3VycmVudFZhbHVlLCBjdXJyZW50U2VsZWN0ZWQpO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgaWYgKGNoYW5nZXMuaGFzT3duUHJvcGVydHkoJ3ZhbHVlJykpIHtcclxuICAgICAgICAgICAgaWYgKHR5cGVvZiBjaGFuZ2VzWyd2YWx1ZSddICE9PSAndW5kZWZpbmVkJyAmJiB0eXBlb2YgY2hhbmdlc1sndmFsdWUnXS5jdXJyZW50VmFsdWUgIT09ICd1bmRlZmluZWQnKSB7XHJcbiAgICAgICAgICAgICAgICBpZiAoY2hhbmdlc1sndmFsdWUnXS5jdXJyZW50VmFsdWUgIT09ICcnKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5fdGV4dFZhbHVlID0gY2hhbmdlc1sndmFsdWUnXS5jdXJyZW50VmFsdWU7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgICAgICAgICBpZiAodGhpcy5fdGV4dFNldHRpbmcubXVsdGlzZWxlY3QpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5fdGV4dFZhbHVlID0gW107XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLl90ZXh0VmFsdWUgPSAnJztcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLl90ZXh0VmFsdWUgPSAnJztcclxuICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgLy8gdGhpcy5fdGV4dFZhbHVlID0gKHR5cGVvZiBjaGFuZ2VzW1widmFsdWVcIl0uY3VycmVudFZhbHVlICE9IFwidW5kZWZpbmVkXCIpID8gY2hhbmdlc1tcInZhbHVlXCJdLmN1cnJlbnRWYWx1ZSA6IFwiXCI7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIG5nQWZ0ZXJWaWV3SW5pdCgpOiB2b2lkIHtcclxuICAgICAgICB0aW1lcigpLnN1YnNjcmliZSgoKTogdm9pZCA9PiB7XHJcbiAgICAgICAgICAgIGlmICh0aGlzLl90ZXh0U2V0dGluZy5tdWx0aXNlbGVjdCAmJiB0aGlzLl90ZXh0U2V0dGluZy5kcm9wZG93blRvZ2dsZSkge1xyXG4gICAgICAgICAgICAgICAgbGV0IHF1ZXJ5U3RyaW5nOiBzdHJpbmcgPSAnLnVpLWF1dG9jb21wbGV0ZS1tdWx0aXBsZSAudWktYXV0b2NvbXBsZXRlLWlucHV0LXRva2VuIGlucHV0JztcclxuICAgICAgICAgICAgICAgIHRoaXMuX2FkZENsaWNrTGlzdGVuZXIocXVlcnlTdHJpbmcpO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIGVsc2UgaWYgKHRoaXMuX3RleHRTZXR0aW5nLmF1dG9jb21wbGV0ZSAmJiB0aGlzLl90ZXh0U2V0dGluZy5kcm9wZG93blRvZ2dsZSkge1xyXG4gICAgICAgICAgICAgICAgbGV0IHF1ZXJ5U3RyaW5nOiBzdHJpbmcgPSAnLnVpLWF1dG9jb21wbGV0ZSBpbnB1dC51aS1pbnB1dHRleHQnO1xyXG4gICAgICAgICAgICAgICAgdGhpcy5fYWRkQ2xpY2tMaXN0ZW5lcihxdWVyeVN0cmluZyk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9KTtcclxuXHJcbiAgICB9XHJcblxyXG4gICAgbmdPbkRlc3Ryb3koKTogdm9pZCB7XHJcbiAgICAgICAgaWYgKHR5cGVvZiB0aGlzLl9zdWJzY3JpcHRpb24gIT09ICd1bmRlZmluZWQnKSB0aGlzLl9zdWJzY3JpcHRpb24udW5zdWJzY3JpYmUoKTtcclxuICAgICAgICBpZiAodHlwZW9mIHRoaXMuX3JlbmRlcmVyTGlzdGVuRnVuYyAhPT0gJ3VuZGVmaW5lZCcpIHRoaXMuX3JlbmRlcmVyTGlzdGVuRnVuYygpO1xyXG4gICAgfVxyXG5cclxuICAgIGVtaXRWYWx1ZSgpOiB2b2lkIHtcclxuICAgICAgICB0aGlzLnVwZGF0ZWRWYWx1ZS5lbWl0KHRoaXMuX3RleHRWYWx1ZSk7XHJcbiAgICB9XHJcblxyXG4gICAgc2VhcmNoTXVsdGkoX2V2ZW50OiBhbnksIF9zdGF0ZTogc3RyaW5nKTogdm9pZCB7XHJcbiAgICAgICAgbGV0IHF1ZXJ5OiBzdHJpbmcgPSB0aGlzLl90ZXh0SW5wdXRTdmMuY2hlY2tRdWVyeShfZXZlbnQpO1xyXG5cclxuICAgICAgICBpZiAodHlwZW9mIHRoaXMuX3Jlc3VsdExpc3QgIT09ICd1bmRlZmluZWQnKSB7XHJcbiAgICAgICAgICAgIGxldCBzZWFyY2hSZXN1bHQ6IEFycmF5PGFueT4gPSB0aGlzLl90ZXh0SW5wdXRTdmMuc2VhcmNoTGlzdChxdWVyeSwgdGhpcy5fcmVzdWx0TGlzdCk7XHJcbiAgICAgICAgICAgIHRoaXMuX2NoZWNrU2VhcmNoUmVzdWx0KHNlYXJjaFJlc3VsdCwgcXVlcnkpO1xyXG4gICAgICAgIH1cclxuICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgdGhpcy5fY2hlY2tMb2FkaW5nRnVuYyhxdWVyeSk7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIG11bHRpU2VsZWN0aW9uKHZhbDogYW55LCBzdGF0ZTogc3RyaW5nKTogdm9pZCB7XHJcbiAgICAgICAgaWYgKHRoaXMuX3RleHRTZXR0aW5nLm11bHRpc2VsZWN0ICYmIHR5cGVvZiB0aGlzLl9yZXN1bHRMaXN0ICE9PSAndW5kZWZpbmVkJykge1xyXG4gICAgICAgICAgICB0aGlzLl91cGRhdGVSZXN1bHRMaXN0KHZhbCwgc3RhdGUpO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICBjaGVja0VudGVyQW5kRXJyb3IoZXZlbnQ6IGFueSk6IHZvaWQge1xyXG4gICAgICAgIGxldCBpbnB1dFZhbDogc3RyaW5nID0gZXZlbnQudGFyZ2V0LnZhbHVlO1xyXG5cclxuICAgICAgICBpZiAoaW5wdXRWYWwubGVuZ3RoIDwgdGhpcy5fdGV4dFNldHRpbmcubWluTGVuZ3RoKSB7XHJcbiAgICAgICAgICAgIHRoaXMuY29uZmlnLmVycm9ycyA9IHVuZGVmaW5lZDtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIGlmIChldmVudC5rZXkgPT09ICdCYWNrc3BhY2UnICYmIHR5cGVvZiB0aGlzLmNvbmZpZy5kcm9wZG93bkNhbGxiYWNrICE9PSAndW5kZWZpbmVkJyAmJiAhdGhpcy5fdGV4dFNldHRpbmcuZW50ZXIpIHtcclxuICAgICAgICAgICAgaWYgKHR5cGVvZiB0aGlzLl9zdWJzY3JpcHRpb24gIT09ICd1bmRlZmluZWQnKSB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLl9zdWJzY3JpcHRpb24udW5zdWJzY3JpYmUoKTtcclxuICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgdGhpcy5faXNMb2FkaW5nID0gZmFsc2U7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICBpZiAoZXZlbnQua2V5ID09PSAnRW50ZXInICYmIHR5cGVvZiBpbnB1dFZhbCAhPT0gJ3VuZGVmaW5lZCcgJiYgaW5wdXRWYWwgIT09ICcnKSB7XHJcbiAgICAgICAgICAgIGlmICh0aGlzLl90ZXh0U2V0dGluZy5tdWx0aXNlbGVjdCkge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5zZWFyY2hNdWx0aShpbnB1dFZhbCwgJ3NlbGVjdGVkJyk7XHJcbiAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgIGVsc2UgaWYgKCF0aGlzLl90ZXh0U2V0dGluZy5tdWx0aXNlbGVjdCAmJiB0eXBlb2YgdGhpcy5jb25maWcudmFsdWUgIT09ICd1bmRlZmluZWQnICYmIHR5cGVvZiB0aGlzLmNvbmZpZy52YWx1ZSAhPT0gJ29iamVjdCcpIHtcclxuICAgICAgICAgICAgICAgIHRoaXMuc2VhcmNoTXVsdGkoaW5wdXRWYWwsICdzZWxlY3RlZCcpO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX2FkZENsaWNrTGlzdGVuZXIoX3F1ZXJ5U3RyaW5nOiBzdHJpbmcpOiB2b2lkIHtcclxuICAgICAgICBsZXQgY2xpY2tFdmVudEVsZTogSFRNTEVsZW1lbnQgPSB0aGlzLl92Y3IuZWxlbWVudC5uYXRpdmVFbGVtZW50LnF1ZXJ5U2VsZWN0b3IoX3F1ZXJ5U3RyaW5nKTtcclxuXHJcbiAgICAgICAgdGhpcy5fcmVuZGVyZXJMaXN0ZW5GdW5jID0gdGhpcy5fcmVuZGVyZXIubGlzdGVuKGNsaWNrRXZlbnRFbGUsICdjbGljaycsIChfZXZlbnQ6IGFueSk6IHZvaWQgPT4ge1xyXG4gICAgdGhpcy5hdXRvY29tcGxldGVDb21wb25lbnQuaGFuZGxlRHJvcGRvd25DbGljayhfZXZlbnQpO1xyXG59KTtcclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF91cGRhdGVSZXN1bHRMaXN0KF92YWw6IGFueSwgX3N0YXRlOiBzdHJpbmcpOiB2b2lkIHtcclxuICAgICAgICBpZiAoX3N0YXRlID09PSAnc2VsZWN0ZWQnKSB7XHJcbiAgICAgICAgICAgIGZvciAobGV0IGk6IG51bWJlciA9IDA7IGkgPCB0aGlzLl9yZXN1bHRMaXN0Lmxlbmd0aDsgaSsrKSB7XHJcbiAgICAgICAgICAgICAgICBpZiAoX3ZhbC52YWx1ZSA9PT0gdGhpcy5fcmVzdWx0TGlzdFtpXS52YWx1ZSkge1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuX3Jlc3VsdExpc3Quc3BsaWNlKGksIDEpO1xyXG4gICAgICAgICAgICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICBsZXQgc29ydEZ1bmM6IChhOiBhbnksIGI6IGFueSkgPT4gbnVtYmVyID0gKGE6IGFueSwgYjogYW55KTogbnVtYmVyID0+IHtcclxuICAgICAgICAgICAgICAgIGlmIChhLnZhbHVlIDwgYi52YWx1ZSkgcmV0dXJuIC0xO1xyXG4gICAgICAgICAgICAgICAgZWxzZSBpZiAoYS52YWx1ZSA+IGIudmFsdWUpIHJldHVybiAxO1xyXG4gICAgICAgICAgICAgICAgcmV0dXJuIDA7XHJcbiAgICAgICAgICAgIH07XHJcblxyXG4gICAgICAgICAgICB0aGlzLl9yZXN1bHRMaXN0LnB1c2goX3ZhbCk7XHJcbiAgICAgICAgICAgIHRoaXMuX3Jlc3VsdExpc3Quc29ydChzb3J0RnVuYyk7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX2NoZWNrU2VhcmNoUmVzdWx0KF92YWx1ZTogQXJyYXk8YW55PiwgX3F1ZXJ5OiBzdHJpbmcpOiB2b2lkIHtcclxuICAgICAgICBsZXQgZmlsdGVyZWRPcHRpb25zOiBBcnJheTxhbnk+ID0gdGhpcy5fdGV4dElucHV0U3ZjLmZpbHRlck9wdGlvbkxpc3QoX3ZhbHVlLCB0aGlzLl90ZXh0VmFsdWUpO1xyXG5cclxuICAgICAgICB0aW1lcigpLnN1YnNjcmliZSgoKTogdm9pZCA9PiB7XHJcbiAgICAgICAgICAgIHRoaXMuX3N1Z2dlc3Rpb25MaXN0ID0gZmlsdGVyZWRPcHRpb25zLnNsaWNlKCk7XHJcblxyXG4gICAgICAgICAgICBsZXQgY2hlY2tlZFJlc3VsdCA9IHRoaXMuX3RleHRJbnB1dFN2Yy5jaGVja0Vycm9yKHRoaXMuX3N1Z2dlc3Rpb25MaXN0LCBfcXVlcnkpO1xyXG5cclxuICAgICAgICAgICAgaWYgKHR5cGVvZiBjaGVja2VkUmVzdWx0ICE9PSAndW5kZWZpbmVkJykge1xyXG4gICAgICAgICAgICAgICAgbGV0IHJlc3VsdDogQXJyYXk8c3RyaW5nPiA9IFtdO1xyXG4gICAgICAgICAgICAgICAgcmVzdWx0LnB1c2goY2hlY2tlZFJlc3VsdC5kaWFsb2d1ZU1lc3NhZ2UpO1xyXG4gICAgICAgICAgICAgICAgdGhpcy5jb25maWcuZXJyb3JzID0gcmVzdWx0O1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfSk7XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfY2hlY2tMb2FkaW5nRnVuYyhfcXVlcnk6IHN0cmluZyk6IHZvaWQge1xyXG4gICAgICAgIHRoaXMuX2lzTG9hZGluZyA9IHRydWU7XHJcblxyXG4gICAgICAgIGxldCBzZWxlY3RlZFZhbCA9ICh0eXBlb2YgdGhpcy5jb25maWcudmFsdWUgIT09ICd1bmRlZmluZWQnKSA/IHRoaXMuY29uZmlnLnZhbHVlIDogW107XHJcbiAgICAgICAgbGV0IHBhcmFtcyA9IHtxdWVyeTogX3F1ZXJ5LCBjdXJyZW50U2VsZWN0ZWQ6IHNlbGVjdGVkVmFsfTtcclxuXHJcbiAgICAgICAgaWYgKHR5cGVvZiB0aGlzLl9zdWJzY3JpcHRpb24gIT09ICd1bmRlZmluZWQnKSB7XHJcbiAgICAgICAgICAgIHRoaXMuX3N1YnNjcmlwdGlvbi51bnN1YnNjcmliZSgpO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgdGhpcy5fc3Vic2NyaXB0aW9uID0gdGhpcy5jb25maWcuZHJvcGRvd25DYWxsYmFjayhwYXJhbXMpLnN1YnNjcmliZSgoX3ZhbHVlOiBhbnkpOiB2b2lkID0+IHtcclxuICAgICAgICAgICAgLy8gY29uc29sZS5sb2coXCI+Pj4gdmFsdWVcIiwgX3ZhbHVlKTtcclxuICAgICAgICAgICAgdGhpcy5fY2hlY2tTZWFyY2hSZXN1bHQoX3ZhbHVlLCBfcXVlcnkpO1xyXG4gICAgICAgICAgICB0aGlzLl9pc0xvYWRpbmcgPSBmYWxzZTtcclxuICAgICAgICB9KTtcclxuICAgIH1cclxufVxyXG4iXX0=