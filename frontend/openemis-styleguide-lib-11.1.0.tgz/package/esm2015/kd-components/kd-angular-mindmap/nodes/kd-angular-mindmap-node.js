import { Component, Input, Output, ViewEncapsulation, ElementRef, EventEmitter } from '@angular/core';
import { KdDomElemSvc } from '../../kd-common/index';
import { KdMindmapSvc } from '../kd-angular-mindmap-svc';
import { KdMindmapEvent } from '../kd-angular-mindmap-event';
export class KdMindmapNode {
    constructor(_mindmapSvc, _mindmapEvent, _elemRef, _domSvc) {
        this._mindmapSvc = _mindmapSvc;
        this._mindmapEvent = _mindmapEvent;
        this._elemRef = _elemRef;
        this._domSvc = _domSvc;
        this.config = {};
        this._nodeActive = false;
        this.selectedNodeEmitter = new EventEmitter();
    }
    ngOnInit() {
        this._setConfig(this.nodeConfig, this.node);
        this._setActiveNode();
        this._nodeSelectedSub = this._mindmapEvent
            .onNodeSelected(this.mindmapId)
            .subscribe((_node) => this._clearNodeSelection(_node));
    }
    ngAfterViewInit() {
        setTimeout(() => this._setHeight());
    }
    ngOnChanges(_simpleChanges) {
        if ((_simpleChanges.hasOwnProperty('node') && !_simpleChanges['node'].firstChange) ||
            (_simpleChanges.hasOwnProperty('nodeConfig') && !_simpleChanges['nodeConfig'].firstChange)) {
            this._setConfig(this.nodeConfig, this.node);
            this._setActiveNode();
        }
    }
    ngOnDestroy() {
        this._nodeSelectedSub.unsubscribe();
    }
    onClick() {
        this._nodeSelected();
    }
    _nodeSelected() {
        if (this._nodeActive)
            return;
        this._domSvc.addClass(this._elemRef.nativeElement, this.config.activeClass);
        this._mindmapEvent.nodeSelected(this.mindmapId, this.node);
        this.selectedNodeEmitter.emit(this.node);
        this._nodeActive = true;
    }
    _clearNodeSelection(_nodeToClear) {
        if (this._nodeActive) {
            this._domSvc.removeClass(this._elemRef.nativeElement, this.config.activeClass);
            this._nodeActive = false;
        }
    }
    _setConfig(_config, _node) {
        this.config = Object.assign({}, _config);
        this.config.icon = Object.assign({}, _config.icon);
        this.config.title = Object.assign({}, _config.title);
        this.config.description = Object.assign({}, _config.description);
        if (this.config.class)
            this._domSvc.addClass(this._elemRef.nativeElement, this.config.class);
        this.config.title.textClass += ' ' + 'node-' + _node.index;
        this.config.description.textClass += ' ' + 'node-' + _node.index;
        if (!_config.typeConfig || !this.node.type) {
            this.config.icon.size = 0;
            return;
        }
        if (_config.typeConfig.hasOwnProperty(_node.type)) {
            let typeConfig = _config.typeConfig[_node.type];
            if (typeConfig.hasOwnProperty('class'))
                this._domSvc.addClass(this._elemRef.nativeElement, typeConfig.class);
            if (typeConfig.hasOwnProperty('iconType')) {
                this._setIcon(typeConfig.iconType, typeConfig.icon, typeConfig.iconClass);
            }
            else {
                this.config.icon.size = 0;
            }
        }
    }
    _setActiveNode() {
        if (this.config.hasOwnProperty('selectOnLoadId') && this.config['selectOnLoadId'] === this.node.index) {
            this._nodeSelected();
        }
    }
    _setIcon(_type, _icon, _iconClass) {
        this.config.icon.type = _type;
        if (_type === 'icon')
            this.config.icon.link += _icon;
        if (_type === 'image')
            this.config.icon.link = _icon;
    }
    _setHeight() {
        this.config.title.textHeight = this._mindmapSvc.textWrap(this.node.title, this.config.title.textClass, this.config);
        this.config.title.height = this._mindmapSvc.setSVGContainerHeight(this.config, 'title');
        if (this.node.description)
            this.config.description.textHeight = this._mindmapSvc.textWrap(this.node.description, this.config.description.textClass, this.config);
        this.config.height = this._mindmapSvc.setSVGContainerHeight(this.config, 'node');
        if (typeof this.node.parents !== 'undefined')
            this.internalApi.setNodeHeight(this.node, this.config.height);
    }
}
KdMindmapNode.decorators = [
    { type: Component, args: [{
                selector: '[kdx-mindmap-node]',
                template: "<svg:g \r\n    [attr.transform]=\"'translate(' + (node.x - config.width/2)+ ',' + (node.y - config.height/2)+ ')'\"\r\n    [attr.node-x]=\"node.x\"\r\n    [attr.node-y]=\"node.y\">\r\n    <svg:rect #nodeWrapper\r\n        class=\"kdx-mindmap-node-wrapper\"\r\n        id=\"rectALeftResize\"\r\n        rx=\"1\"\r\n        ry=\"1\"\r\n        x=\"0\"\r\n        y=\"0\"\r\n        [attr.width]=\"config.width\"\r\n        [attr.height]=\"config.height\"\r\n        stroke=\"black\"\r\n        stroke-width=\"0.25\">\r\n    </svg:rect>\r\n    <svg:g>\r\n        <svg:rect\r\n            class=\"kdx-mindmap-node-title-container\"\r\n            rx=\"1\"\r\n            ry=\"1\"\r\n            x=\"0\"\r\n            y=\"0\"\r\n            [attr.width]=\"config.width\"\r\n            [attr.height]=\"config.title.height\">\r\n        </svg:rect>\r\n        <svg:line\r\n            class=\"kdx-mindmap-node-title-bottom-border\"\r\n            x1=\"0\"\r\n            [attr.x2]=\"config.width\"\r\n            [attr.y1]=\"config.title.height\"\r\n            [attr.y2]=\"config.title.height\">\r\n        </svg:line>\r\n        <svg:text \r\n            [attr.class]=\"config.title.textClass\"\r\n            text-anchor=\"middle\"\r\n            dy=\"0\"\r\n            [attr.font-size]=\"config.fontSize\"\r\n            [attr.x]=\"config.width/2\"\r\n            [attr.y]=\"config.title.paddingTop + config.fontSize\">\r\n        </svg:text>\r\n    </svg:g>\r\n    <svg *ngIf=\"config.icon.type\"\r\n        [attr.width]=\"config.icon.size\" \r\n        [attr.height]=\"config.icon.size\" \r\n        [attr.x]=\"config.width/2 - config.icon.size/2\" \r\n        [attr.y]=\"config.title.height + config.icon.marginTop\">\r\n        <use *ngIf=\"config.icon.type === 'icon'\"\r\n            class=\"kdx-mindmap-node-icon\" \r\n            [attr.href]=\"config.icon.link\" ></use>\r\n        <svg:image *ngIf=\"config.icon.type === 'image'\" \r\n            class=\"kdx-mindmap-node-image\" \r\n            [attr.href]=\"config.icon.link\" \r\n            [attr.width]=\"config.icon.size\" \r\n            [attr.height]=\"config.icon.size\" ></svg:image>\r\n    \r\n    </svg>\r\n    <svg:text *ngIf=\"node.description\" \r\n        [attr.class]=\"config.description.textClass\"\r\n        dy=\"0\"\r\n        text-anchor=\"middle\"\r\n        [attr.font-size]=\"config.fontSize\"\r\n        [attr.x]=\"config.width/2\"\r\n        [attr.y]=\"config.title.height + config.icon.size + config.icon.marginTop + config.icon.marginBottom + config.description.marginTop + config.fontSize\">\r\n    </svg:text>\r\n</svg:g>\r\n",
                encapsulation: ViewEncapsulation.None,
                providers: [KdMindmapSvc, KdMindmapEvent, KdDomElemSvc],
                host: {
                    'class': 'kdx-mindmap-node',
                    '(click)': 'onClick()',
                }
            },] }
];
KdMindmapNode.ctorParameters = () => [
    { type: KdMindmapSvc },
    { type: KdMindmapEvent },
    { type: ElementRef },
    { type: KdDomElemSvc }
];
KdMindmapNode.propDecorators = {
    mindmapId: [{ type: Input }],
    node: [{ type: Input, args: ['kdx-mindmap-node',] }],
    nodeConfig: [{ type: Input, args: ['config',] }],
    internalApi: [{ type: Input, args: ['api',] }],
    selectedNodeEmitter: [{ type: Output }]
};
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoia2QtYW5ndWxhci1taW5kbWFwLW5vZGUuanMiLCJzb3VyY2VSb290IjoiQzovUHJvamVjdHMvQW5ndWxhci9pb3N0Zy1vcGVuZW1pcy1zdHlsZWd1aWRlL3Byb2plY3RzL29wZW5lbWlzLXN0eWxlZ3VpZGUtbGliL3NyYy8iLCJzb3VyY2VzIjpbImtkLWNvbXBvbmVudHMva2QtYW5ndWxhci1taW5kbWFwL25vZGVzL2tkLWFuZ3VsYXItbWluZG1hcC1ub2RlLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBLE9BQU8sRUFDSCxTQUFTLEVBQ1QsS0FBSyxFQUNMLE1BQU0sRUFJTixpQkFBaUIsRUFDakIsVUFBVSxFQUdWLFlBQVksRUFDZixNQUFNLGVBQWUsQ0FBQztBQUV2QixPQUFPLEVBQUUsWUFBWSxFQUFFLE1BQU0sdUJBQXVCLENBQUM7QUFDckQsT0FBTyxFQUFFLFlBQVksRUFBRSxNQUFNLDJCQUEyQixDQUFDO0FBQ3pELE9BQU8sRUFBRSxjQUFjLEVBQUUsTUFBTSw2QkFBNkIsQ0FBQztBQWlCN0QsTUFBTSxPQUFPLGFBQWE7SUFZdEIsWUFDWSxXQUF5QixFQUN6QixhQUE2QixFQUM3QixRQUFvQixFQUNwQixPQUFxQjtRQUhyQixnQkFBVyxHQUFYLFdBQVcsQ0FBYztRQUN6QixrQkFBYSxHQUFiLGFBQWEsQ0FBZ0I7UUFDN0IsYUFBUSxHQUFSLFFBQVEsQ0FBWTtRQUNwQixZQUFPLEdBQVAsT0FBTyxDQUFjO1FBZDFCLFdBQU0sR0FBd0IsRUFBRSxDQUFDO1FBRWhDLGdCQUFXLEdBQVksS0FBSyxDQUFDO1FBTTNCLHdCQUFtQixHQUErQixJQUFJLFlBQVksRUFBRSxDQUFDO0lBTzNFLENBQUM7SUFFTCxRQUFRO1FBQ0osSUFBSSxDQUFDLFVBQVUsQ0FBQyxJQUFJLENBQUMsVUFBVSxFQUFFLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQztRQUM1QyxJQUFJLENBQUMsY0FBYyxFQUFFLENBQUM7UUFDdEIsSUFBSSxDQUFDLGdCQUFnQixHQUFHLElBQUksQ0FBQyxhQUFhO2FBQ3JDLGNBQWMsQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDO2FBQzlCLFNBQVMsQ0FBQyxDQUFDLEtBQW1CLEVBQVEsRUFBRSxDQUFDLElBQUksQ0FBQyxtQkFBbUIsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDO0lBQ25GLENBQUM7SUFFRCxlQUFlO1FBQ1gsVUFBVSxDQUFDLEdBQUcsRUFBRSxDQUFDLElBQUksQ0FBQyxVQUFVLEVBQUUsQ0FBQyxDQUFDO0lBQ3hDLENBQUM7SUFFRCxXQUFXLENBQUMsY0FBNkI7UUFDckMsSUFBSSxDQUFDLGNBQWMsQ0FBQyxjQUFjLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxjQUFjLENBQUMsTUFBTSxDQUFDLENBQUMsV0FBVyxDQUFDO1lBQzlFLENBQUMsY0FBYyxDQUFDLGNBQWMsQ0FBQyxZQUFZLENBQUMsSUFBSSxDQUFDLGNBQWMsQ0FBQyxZQUFZLENBQUMsQ0FBQyxXQUFXLENBQUMsRUFBRTtZQUM1RixJQUFJLENBQUMsVUFBVSxDQUFDLElBQUksQ0FBQyxVQUFVLEVBQUUsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDO1lBQzVDLElBQUksQ0FBQyxjQUFjLEVBQUUsQ0FBQztTQUN6QjtJQUNMLENBQUM7SUFFRCxXQUFXO1FBQ1AsSUFBSSxDQUFDLGdCQUFnQixDQUFDLFdBQVcsRUFBRSxDQUFDO0lBQ3hDLENBQUM7SUFFTSxPQUFPO1FBQ1YsSUFBSSxDQUFDLGFBQWEsRUFBRSxDQUFDO0lBQ3pCLENBQUM7SUFFTyxhQUFhO1FBQ2pCLElBQUksSUFBSSxDQUFDLFdBQVc7WUFBRSxPQUFPO1FBQzdCLElBQUksQ0FBQyxPQUFPLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsYUFBYSxFQUFFLElBQUksQ0FBQyxNQUFNLENBQUMsV0FBVyxDQUFDLENBQUM7UUFDNUUsSUFBSSxDQUFDLGFBQWEsQ0FBQyxZQUFZLENBQUMsSUFBSSxDQUFDLFNBQVMsRUFBRSxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUM7UUFDM0QsSUFBSSxDQUFDLG1CQUFtQixDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUM7UUFDekMsSUFBSSxDQUFDLFdBQVcsR0FBRyxJQUFJLENBQUM7SUFDNUIsQ0FBQztJQUVPLG1CQUFtQixDQUFDLFlBQTBCO1FBQ2xELElBQUksSUFBSSxDQUFDLFdBQVcsRUFBRTtZQUNsQixJQUFJLENBQUMsT0FBTyxDQUFDLFdBQVcsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLGFBQWEsRUFBRSxJQUFJLENBQUMsTUFBTSxDQUFDLFdBQVcsQ0FBQyxDQUFDO1lBQy9FLElBQUksQ0FBQyxXQUFXLEdBQUcsS0FBSyxDQUFDO1NBQzVCO0lBQ0wsQ0FBQztJQUVPLFVBQVUsQ0FBQyxPQUE0QixFQUFFLEtBQW1CO1FBQ2hFLElBQUksQ0FBQyxNQUFNLEdBQUcsTUFBTSxDQUFDLE1BQU0sQ0FBQyxFQUFFLEVBQUUsT0FBTyxDQUFDLENBQUM7UUFDekMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxJQUFJLEdBQUcsTUFBTSxDQUFDLE1BQU0sQ0FBQyxFQUFFLEVBQUUsT0FBTyxDQUFDLElBQUksQ0FBQyxDQUFDO1FBQ25ELElBQUksQ0FBQyxNQUFNLENBQUMsS0FBSyxHQUFHLE1BQU0sQ0FBQyxNQUFNLENBQUMsRUFBRSxFQUFFLE9BQU8sQ0FBQyxLQUFLLENBQUMsQ0FBQztRQUNyRCxJQUFJLENBQUMsTUFBTSxDQUFDLFdBQVcsR0FBRyxNQUFNLENBQUMsTUFBTSxDQUFDLEVBQUUsRUFBRSxPQUFPLENBQUMsV0FBVyxDQUFDLENBQUM7UUFFakUsSUFBSSxJQUFJLENBQUMsTUFBTSxDQUFDLEtBQUs7WUFBRSxJQUFJLENBQUMsT0FBTyxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLGFBQWEsRUFBRSxJQUFJLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxDQUFDO1FBRTdGLElBQUksQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLFNBQVMsSUFBSSxHQUFHLEdBQUcsT0FBTyxHQUFHLEtBQUssQ0FBQyxLQUFLLENBQUM7UUFDM0QsSUFBSSxDQUFDLE1BQU0sQ0FBQyxXQUFXLENBQUMsU0FBUyxJQUFJLEdBQUcsR0FBRyxPQUFPLEdBQUcsS0FBSyxDQUFDLEtBQUssQ0FBQztRQUVqRSxJQUFJLENBQUMsT0FBTyxDQUFDLFVBQVUsSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxFQUFFO1lBQ3hDLElBQUksQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLElBQUksR0FBRyxDQUFDLENBQUM7WUFDMUIsT0FBTztTQUNWO1FBRUQsSUFBSSxPQUFPLENBQUMsVUFBVSxDQUFDLGNBQWMsQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLEVBQUU7WUFDL0MsSUFBSSxVQUFVLEdBQUcsT0FBTyxDQUFDLFVBQVUsQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLENBQUM7WUFFaEQsSUFBSSxVQUFVLENBQUMsY0FBYyxDQUFDLE9BQU8sQ0FBQztnQkFBRSxJQUFJLENBQUMsT0FBTyxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLGFBQWEsRUFBRSxVQUFVLENBQUMsS0FBSyxDQUFDLENBQUM7WUFDN0csSUFBSSxVQUFVLENBQUMsY0FBYyxDQUFDLFVBQVUsQ0FBQyxFQUFFO2dCQUN2QyxJQUFJLENBQUMsUUFBUSxDQUFDLFVBQVUsQ0FBQyxRQUFRLEVBQUUsVUFBVSxDQUFDLElBQUksRUFBRSxVQUFVLENBQUMsU0FBUyxDQUFDLENBQUM7YUFDN0U7aUJBQU07Z0JBQ0gsSUFBSSxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsSUFBSSxHQUFHLENBQUMsQ0FBQzthQUM3QjtTQUNKO0lBQ0wsQ0FBQztJQUVPLGNBQWM7UUFDbEIsSUFBSSxJQUFJLENBQUMsTUFBTSxDQUFDLGNBQWMsQ0FBQyxnQkFBZ0IsQ0FBQyxJQUFJLElBQUksQ0FBQyxNQUFNLENBQUMsZ0JBQWdCLENBQUMsS0FBSyxJQUFJLENBQUMsSUFBSSxDQUFDLEtBQUssRUFBRTtZQUNuRyxJQUFJLENBQUMsYUFBYSxFQUFFLENBQUM7U0FDeEI7SUFDTCxDQUFDO0lBRU8sUUFBUSxDQUFDLEtBQXVCLEVBQUUsS0FBYSxFQUFFLFVBQWtCO1FBQ3ZFLElBQUksQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLElBQUksR0FBRyxLQUFLLENBQUM7UUFDOUIsSUFBSSxLQUFLLEtBQUssTUFBTTtZQUFFLElBQUksQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLElBQUksSUFBSSxLQUFLLENBQUM7UUFDckQsSUFBSSxLQUFLLEtBQUssT0FBTztZQUFFLElBQUksQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLElBQUksR0FBRyxLQUFLLENBQUM7SUFDekQsQ0FBQztJQUVPLFVBQVU7UUFDZCxJQUFJLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxVQUFVLEdBQUcsSUFBSSxDQUFDLFdBQVcsQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxLQUFLLEVBQUUsSUFBSSxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsU0FBUyxFQUFFLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQztRQUNwSCxJQUFJLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxNQUFNLEdBQUcsSUFBSSxDQUFDLFdBQVcsQ0FBQyxxQkFBcUIsQ0FBQyxJQUFJLENBQUMsTUFBTSxFQUFFLE9BQU8sQ0FBQyxDQUFDO1FBQ3hGLElBQUksSUFBSSxDQUFDLElBQUksQ0FBQyxXQUFXO1lBQUUsSUFBSSxDQUFDLE1BQU0sQ0FBQyxXQUFXLENBQUMsVUFBVSxHQUFHLElBQUksQ0FBQyxXQUFXLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsV0FBVyxFQUFFLElBQUksQ0FBQyxNQUFNLENBQUMsV0FBVyxDQUFDLFNBQVMsRUFBRSxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUM7UUFDakssSUFBSSxDQUFDLE1BQU0sQ0FBQyxNQUFNLEdBQUcsSUFBSSxDQUFDLFdBQVcsQ0FBQyxxQkFBcUIsQ0FBQyxJQUFJLENBQUMsTUFBTSxFQUFFLE1BQU0sQ0FBQyxDQUFDO1FBQ2pGLElBQUksT0FBTyxJQUFJLENBQUMsSUFBSSxDQUFDLE9BQU8sS0FBSyxXQUFXO1lBQUUsSUFBSSxDQUFDLFdBQVcsQ0FBQyxhQUFhLENBQUMsSUFBSSxDQUFDLElBQUksRUFBRSxJQUFJLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxDQUFDO0lBQ2hILENBQUM7OztZQXRISixTQUFTLFNBQUM7Z0JBQ1AsUUFBUSxFQUFFLG9CQUFvQjtnQkFDOUIsb2tGQUE2QztnQkFDN0MsYUFBYSxFQUFFLGlCQUFpQixDQUFDLElBQUk7Z0JBQ3JDLFNBQVMsRUFBRSxDQUFDLFlBQVksRUFBRSxjQUFjLEVBQUUsWUFBWSxDQUFDO2dCQUN2RCxJQUFJLEVBQUU7b0JBQ0YsT0FBTyxFQUFFLGtCQUFrQjtvQkFDM0IsU0FBUyxFQUFFLFdBQVc7aUJBQ3pCO2FBQ0o7OztZQWpCUSxZQUFZO1lBQ1osY0FBYztZQVJuQixVQUFVO1lBTUwsWUFBWTs7O3dCQXlCaEIsS0FBSzttQkFDTCxLQUFLLFNBQUMsa0JBQWtCO3lCQUN4QixLQUFLLFNBQUMsUUFBUTswQkFDZCxLQUFLLFNBQUMsS0FBSztrQ0FDWCxNQUFNIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHtcclxuICAgIENvbXBvbmVudCxcclxuICAgIElucHV0LFxyXG4gICAgT3V0cHV0LFxyXG4gICAgT25Jbml0LFxyXG4gICAgT25DaGFuZ2VzLFxyXG4gICAgQWZ0ZXJWaWV3SW5pdCxcclxuICAgIFZpZXdFbmNhcHN1bGF0aW9uLFxyXG4gICAgRWxlbWVudFJlZixcclxuICAgIFNpbXBsZUNoYW5nZXMsXHJcbiAgICBPbkRlc3Ryb3ksXHJcbiAgICBFdmVudEVtaXR0ZXJcclxufSBmcm9tICdAYW5ndWxhci9jb3JlJztcclxuaW1wb3J0IHsgU3Vic2NyaXB0aW9uIH0gZnJvbSAncnhqcyc7XHJcbmltcG9ydCB7IEtkRG9tRWxlbVN2YyB9IGZyb20gJy4uLy4uL2tkLWNvbW1vbi9pbmRleCc7XHJcbmltcG9ydCB7IEtkTWluZG1hcFN2YyB9IGZyb20gJy4uL2tkLWFuZ3VsYXItbWluZG1hcC1zdmMnO1xyXG5pbXBvcnQgeyBLZE1pbmRtYXBFdmVudCB9IGZyb20gJy4uL2tkLWFuZ3VsYXItbWluZG1hcC1ldmVudCc7XHJcbmltcG9ydCB7IFxyXG4gICAgSU1pbmRtYXBJbnRlcm5hbEFwaSxcclxuICAgIElJbnRlcm5hbE5vZGVDb25maWcsIFxyXG4gICAgSU1pbmRtYXBOb2RlIFxyXG59IGZyb20gJy4uL2tkLWFuZ3VsYXItbWluZG1hcC1pbnRlcmZhY2UnO1xyXG5cclxuQENvbXBvbmVudCh7XHJcbiAgICBzZWxlY3RvcjogJ1trZHgtbWluZG1hcC1ub2RlXScsXHJcbiAgICB0ZW1wbGF0ZVVybDogJy4va2QtYW5ndWxhci1taW5kbWFwLW5vZGUuaHRtbCcsXHJcbiAgICBlbmNhcHN1bGF0aW9uOiBWaWV3RW5jYXBzdWxhdGlvbi5Ob25lLFxyXG4gICAgcHJvdmlkZXJzOiBbS2RNaW5kbWFwU3ZjLCBLZE1pbmRtYXBFdmVudCwgS2REb21FbGVtU3ZjXSxcclxuICAgIGhvc3Q6IHtcclxuICAgICAgICAnY2xhc3MnOiAna2R4LW1pbmRtYXAtbm9kZScsXHJcbiAgICAgICAgJyhjbGljayknOiAnb25DbGljaygpJyxcclxuICAgIH1cclxufSlcclxuZXhwb3J0IGNsYXNzIEtkTWluZG1hcE5vZGUgaW1wbGVtZW50cyBPbkluaXQsIEFmdGVyVmlld0luaXQsIE9uQ2hhbmdlcywgT25EZXN0cm95IHtcclxuXHJcbiAgICBwdWJsaWMgY29uZmlnOiBJSW50ZXJuYWxOb2RlQ29uZmlnID0ge307XHJcbiAgICBwcml2YXRlIF9ub2RlU2VsZWN0ZWRTdWI6IFN1YnNjcmlwdGlvbjtcclxuICAgIHByaXZhdGUgX25vZGVBY3RpdmU6IGJvb2xlYW4gPSBmYWxzZTtcclxuXHJcbiAgICBASW5wdXQoKSBtaW5kbWFwSWQ6IHN0cmluZztcclxuICAgIEBJbnB1dCgna2R4LW1pbmRtYXAtbm9kZScpIG5vZGU6IElNaW5kbWFwTm9kZTtcclxuICAgIEBJbnB1dCgnY29uZmlnJykgbm9kZUNvbmZpZzogSUludGVybmFsTm9kZUNvbmZpZztcclxuICAgIEBJbnB1dCgnYXBpJykgaW50ZXJuYWxBcGk6IElNaW5kbWFwSW50ZXJuYWxBcGk7XHJcbiAgICBAT3V0cHV0KCkgc2VsZWN0ZWROb2RlRW1pdHRlcjogRXZlbnRFbWl0dGVyPElNaW5kbWFwTm9kZT4gPSBuZXcgRXZlbnRFbWl0dGVyKCk7XHJcblxyXG4gICAgY29uc3RydWN0b3IoXHJcbiAgICAgICAgcHJpdmF0ZSBfbWluZG1hcFN2YzogS2RNaW5kbWFwU3ZjLFxyXG4gICAgICAgIHByaXZhdGUgX21pbmRtYXBFdmVudDogS2RNaW5kbWFwRXZlbnQsXHJcbiAgICAgICAgcHJpdmF0ZSBfZWxlbVJlZjogRWxlbWVudFJlZixcclxuICAgICAgICBwcml2YXRlIF9kb21TdmM6IEtkRG9tRWxlbVN2Y1xyXG4gICAgKSB7IH1cclxuXHJcbiAgICBuZ09uSW5pdCgpOiB2b2lkIHtcclxuICAgICAgICB0aGlzLl9zZXRDb25maWcodGhpcy5ub2RlQ29uZmlnLCB0aGlzLm5vZGUpO1xyXG4gICAgICAgIHRoaXMuX3NldEFjdGl2ZU5vZGUoKTtcclxuICAgICAgICB0aGlzLl9ub2RlU2VsZWN0ZWRTdWIgPSB0aGlzLl9taW5kbWFwRXZlbnRcclxuICAgICAgICAgICAgLm9uTm9kZVNlbGVjdGVkKHRoaXMubWluZG1hcElkKVxyXG4gICAgICAgICAgICAuc3Vic2NyaWJlKChfbm9kZTogSU1pbmRtYXBOb2RlKTogdm9pZCA9PiB0aGlzLl9jbGVhck5vZGVTZWxlY3Rpb24oX25vZGUpKTtcclxuICAgIH1cclxuXHJcbiAgICBuZ0FmdGVyVmlld0luaXQoKTogdm9pZCB7XHJcbiAgICAgICAgc2V0VGltZW91dCgoKSA9PiB0aGlzLl9zZXRIZWlnaHQoKSk7XHJcbiAgICB9XHJcblxyXG4gICAgbmdPbkNoYW5nZXMoX3NpbXBsZUNoYW5nZXM6IFNpbXBsZUNoYW5nZXMpOiB2b2lkIHtcclxuICAgICAgICBpZiAoKF9zaW1wbGVDaGFuZ2VzLmhhc093blByb3BlcnR5KCdub2RlJykgJiYgIV9zaW1wbGVDaGFuZ2VzWydub2RlJ10uZmlyc3RDaGFuZ2UpIHx8XHJcbiAgICAgICAgICAgIChfc2ltcGxlQ2hhbmdlcy5oYXNPd25Qcm9wZXJ0eSgnbm9kZUNvbmZpZycpICYmICFfc2ltcGxlQ2hhbmdlc1snbm9kZUNvbmZpZyddLmZpcnN0Q2hhbmdlKSkge1xyXG4gICAgICAgICAgICB0aGlzLl9zZXRDb25maWcodGhpcy5ub2RlQ29uZmlnLCB0aGlzLm5vZGUpO1xyXG4gICAgICAgICAgICB0aGlzLl9zZXRBY3RpdmVOb2RlKCk7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIG5nT25EZXN0cm95KCk6IHZvaWQge1xyXG4gICAgICAgIHRoaXMuX25vZGVTZWxlY3RlZFN1Yi51bnN1YnNjcmliZSgpO1xyXG4gICAgfVxyXG5cclxuICAgIHB1YmxpYyBvbkNsaWNrKCk6IHZvaWQge1xyXG4gICAgICAgIHRoaXMuX25vZGVTZWxlY3RlZCgpO1xyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX25vZGVTZWxlY3RlZCgpOiB2b2lkIHtcclxuICAgICAgICBpZiAodGhpcy5fbm9kZUFjdGl2ZSkgcmV0dXJuO1xyXG4gICAgICAgIHRoaXMuX2RvbVN2Yy5hZGRDbGFzcyh0aGlzLl9lbGVtUmVmLm5hdGl2ZUVsZW1lbnQsIHRoaXMuY29uZmlnLmFjdGl2ZUNsYXNzKTtcclxuICAgICAgICB0aGlzLl9taW5kbWFwRXZlbnQubm9kZVNlbGVjdGVkKHRoaXMubWluZG1hcElkLCB0aGlzLm5vZGUpO1xyXG4gICAgICAgIHRoaXMuc2VsZWN0ZWROb2RlRW1pdHRlci5lbWl0KHRoaXMubm9kZSk7XHJcbiAgICAgICAgdGhpcy5fbm9kZUFjdGl2ZSA9IHRydWU7XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfY2xlYXJOb2RlU2VsZWN0aW9uKF9ub2RlVG9DbGVhcjogSU1pbmRtYXBOb2RlKTogdm9pZCB7XHJcbiAgICAgICAgaWYgKHRoaXMuX25vZGVBY3RpdmUpIHtcclxuICAgICAgICAgICAgdGhpcy5fZG9tU3ZjLnJlbW92ZUNsYXNzKHRoaXMuX2VsZW1SZWYubmF0aXZlRWxlbWVudCwgdGhpcy5jb25maWcuYWN0aXZlQ2xhc3MpO1xyXG4gICAgICAgICAgICB0aGlzLl9ub2RlQWN0aXZlID0gZmFsc2U7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX3NldENvbmZpZyhfY29uZmlnOiBJSW50ZXJuYWxOb2RlQ29uZmlnLCBfbm9kZTogSU1pbmRtYXBOb2RlKTogdm9pZCB7XHJcbiAgICAgICAgdGhpcy5jb25maWcgPSBPYmplY3QuYXNzaWduKHt9LCBfY29uZmlnKTtcclxuICAgICAgICB0aGlzLmNvbmZpZy5pY29uID0gT2JqZWN0LmFzc2lnbih7fSwgX2NvbmZpZy5pY29uKTtcclxuICAgICAgICB0aGlzLmNvbmZpZy50aXRsZSA9IE9iamVjdC5hc3NpZ24oe30sIF9jb25maWcudGl0bGUpO1xyXG4gICAgICAgIHRoaXMuY29uZmlnLmRlc2NyaXB0aW9uID0gT2JqZWN0LmFzc2lnbih7fSwgX2NvbmZpZy5kZXNjcmlwdGlvbik7XHJcblxyXG4gICAgICAgIGlmICh0aGlzLmNvbmZpZy5jbGFzcykgdGhpcy5fZG9tU3ZjLmFkZENsYXNzKHRoaXMuX2VsZW1SZWYubmF0aXZlRWxlbWVudCwgdGhpcy5jb25maWcuY2xhc3MpO1xyXG5cclxuICAgICAgICB0aGlzLmNvbmZpZy50aXRsZS50ZXh0Q2xhc3MgKz0gJyAnICsgJ25vZGUtJyArIF9ub2RlLmluZGV4O1xyXG4gICAgICAgIHRoaXMuY29uZmlnLmRlc2NyaXB0aW9uLnRleHRDbGFzcyArPSAnICcgKyAnbm9kZS0nICsgX25vZGUuaW5kZXg7XHJcblxyXG4gICAgICAgIGlmICghX2NvbmZpZy50eXBlQ29uZmlnIHx8ICF0aGlzLm5vZGUudHlwZSkge1xyXG4gICAgICAgICAgICB0aGlzLmNvbmZpZy5pY29uLnNpemUgPSAwO1xyXG4gICAgICAgICAgICByZXR1cm47XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICBpZiAoX2NvbmZpZy50eXBlQ29uZmlnLmhhc093blByb3BlcnR5KF9ub2RlLnR5cGUpKSB7XHJcbiAgICAgICAgICAgIGxldCB0eXBlQ29uZmlnID0gX2NvbmZpZy50eXBlQ29uZmlnW19ub2RlLnR5cGVdO1xyXG5cclxuICAgICAgICAgICAgaWYgKHR5cGVDb25maWcuaGFzT3duUHJvcGVydHkoJ2NsYXNzJykpIHRoaXMuX2RvbVN2Yy5hZGRDbGFzcyh0aGlzLl9lbGVtUmVmLm5hdGl2ZUVsZW1lbnQsIHR5cGVDb25maWcuY2xhc3MpO1xyXG4gICAgICAgICAgICBpZiAodHlwZUNvbmZpZy5oYXNPd25Qcm9wZXJ0eSgnaWNvblR5cGUnKSkge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5fc2V0SWNvbih0eXBlQ29uZmlnLmljb25UeXBlLCB0eXBlQ29uZmlnLmljb24sIHR5cGVDb25maWcuaWNvbkNsYXNzKTtcclxuICAgICAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgICAgIHRoaXMuY29uZmlnLmljb24uc2l6ZSA9IDA7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfc2V0QWN0aXZlTm9kZSgpOiB2b2lkIHtcclxuICAgICAgICBpZiAodGhpcy5jb25maWcuaGFzT3duUHJvcGVydHkoJ3NlbGVjdE9uTG9hZElkJykgJiYgdGhpcy5jb25maWdbJ3NlbGVjdE9uTG9hZElkJ10gPT09IHRoaXMubm9kZS5pbmRleCkge1xyXG4gICAgICAgICAgICB0aGlzLl9ub2RlU2VsZWN0ZWQoKTtcclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfc2V0SWNvbihfdHlwZTogJ2ljb24nIHwgJ2ltYWdlJywgX2ljb246IHN0cmluZywgX2ljb25DbGFzczogc3RyaW5nKTogdm9pZCB7XHJcbiAgICAgICAgdGhpcy5jb25maWcuaWNvbi50eXBlID0gX3R5cGU7XHJcbiAgICAgICAgaWYgKF90eXBlID09PSAnaWNvbicpIHRoaXMuY29uZmlnLmljb24ubGluayArPSBfaWNvbjtcclxuICAgICAgICBpZiAoX3R5cGUgPT09ICdpbWFnZScpIHRoaXMuY29uZmlnLmljb24ubGluayA9IF9pY29uO1xyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX3NldEhlaWdodCgpOiB2b2lkIHtcclxuICAgICAgICB0aGlzLmNvbmZpZy50aXRsZS50ZXh0SGVpZ2h0ID0gdGhpcy5fbWluZG1hcFN2Yy50ZXh0V3JhcCh0aGlzLm5vZGUudGl0bGUsIHRoaXMuY29uZmlnLnRpdGxlLnRleHRDbGFzcywgdGhpcy5jb25maWcpO1xyXG4gICAgICAgIHRoaXMuY29uZmlnLnRpdGxlLmhlaWdodCA9IHRoaXMuX21pbmRtYXBTdmMuc2V0U1ZHQ29udGFpbmVySGVpZ2h0KHRoaXMuY29uZmlnLCAndGl0bGUnKTtcclxuICAgICAgICBpZiAodGhpcy5ub2RlLmRlc2NyaXB0aW9uKSB0aGlzLmNvbmZpZy5kZXNjcmlwdGlvbi50ZXh0SGVpZ2h0ID0gdGhpcy5fbWluZG1hcFN2Yy50ZXh0V3JhcCh0aGlzLm5vZGUuZGVzY3JpcHRpb24sIHRoaXMuY29uZmlnLmRlc2NyaXB0aW9uLnRleHRDbGFzcywgdGhpcy5jb25maWcpO1xyXG4gICAgICAgIHRoaXMuY29uZmlnLmhlaWdodCA9IHRoaXMuX21pbmRtYXBTdmMuc2V0U1ZHQ29udGFpbmVySGVpZ2h0KHRoaXMuY29uZmlnLCAnbm9kZScpO1xyXG4gICAgICAgIGlmICh0eXBlb2YgdGhpcy5ub2RlLnBhcmVudHMgIT09ICd1bmRlZmluZWQnKSB0aGlzLmludGVybmFsQXBpLnNldE5vZGVIZWlnaHQodGhpcy5ub2RlLCB0aGlzLmNvbmZpZy5oZWlnaHQpO1xyXG4gICAgfVxyXG59XHJcbiJdfQ==