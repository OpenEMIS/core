import { Component, Input, ViewEncapsulation, ElementRef, } from '@angular/core';
import { KdDomElemSvc } from '../../kd-common/index';
import { KdMindmapEvent } from '../kd-angular-mindmap-event';
export class KdMindmapLink {
    constructor(_mindmapEvent, _domSvc, _elemRef) {
        this._mindmapEvent = _mindmapEvent;
        this._domSvc = _domSvc;
        this._elemRef = _elemRef;
        this.offset = 0;
        this._linkActive = false;
    }
    ngOnInit() {
        this._initApi();
        this._setConfig(this.allConfig);
        this._nodeSelectedSub = this._mindmapEvent
            .onNodeSelected(this.mindmapId)
            .subscribe((_node) => this._linkActiveSwitch(_node));
    }
    ngOnChanges(_simpleChanges) {
        if (_simpleChanges.hasOwnProperty('allConfig') && !_simpleChanges['allConfig'].firstChange) {
            this._setConfig(this.allConfig);
        }
    }
    ngOnDestroy() {
        this._nodeSelectedSub.unsubscribe();
    }
    _initApi() {
        if (typeof this.internalLinkApiRef !== 'undefined') {
            this.internalLinkApiRef[this.link.index] = {};
            this.internalLinkApiRef[this.link.index].setLinkOffset = (_offset) => { this.offset = _offset || 0; };
        }
    }
    _linkActiveSwitch(_node) {
        if (this.link.target.index !== _node.index && this.link.source.index !== _node.index) {
            if (this._linkActive) {
                this._domSvc.removeClass(this._elemRef.nativeElement, this.config.link.activeClass);
                if (this.config.link.type)
                    this._setMarkerType(this.config.link.type, 'url(#arrowStart)', 'url(#arrowEnd)');
                this._linkActive = false;
            }
        }
        else {
            if (!this._linkActive) {
                this._domSvc.addClass(this._elemRef.nativeElement, this.config.link.activeClass);
                if (this.config.link.type)
                    this._setMarkerType(this.config.link.type, 'url(#arrowStartActive)', 'url(#arrowEndActive)');
                this._linkActive = true;
            }
        }
    }
    _setConfig(_config) {
        this.config = Object.assign({}, _config);
        this.config.link = Object.assign({}, _config.link);
        this._setMarker();
        if (this.config.link.class)
            this._domSvc.addClass(this._elemRef.nativeElement, this.config.link.class);
    }
    /**
     * [_setMarker is setting whether the arrow heads should appear]
     */
    _setMarker() {
        if (this.link.type)
            this.config.link.type = this.link.type;
        if (!this.config.link.type)
            return;
        this._setMarkerType(this.config.link.type, 'url(#arrowStart)', 'url(#arrowEnd)');
    }
    _setMarkerType(_configType, _urlStart, _urlEnd) {
        if (_configType === 'direction' || _configType === 'two-direction') {
            this._domSvc.setAttribute(this._elemRef.nativeElement.querySelector('.kdx-mindmap-link-line'), 'marker-end', _urlEnd);
        }
        if (_configType === 'two-direction') {
            this._domSvc.setAttribute(this._elemRef.nativeElement.querySelector('.kdx-mindmap-link-line'), 'marker-start', _urlStart);
        }
    }
}
KdMindmapLink.decorators = [
    { type: Component, args: [{
                selector: '[kdx-mindmap-link]',
                template: `
        <svg:line
            class="kdx-mindmap-link-line"
            [attr.aria-source]="link.source.title"
            [attr.aria-target]="link.target.title"
            [attr.x1]="link.source.x + config.node.width/2"
            [attr.y1]="link.source.y"
            [attr.x2]="link.target.x - config.node.width/2"
            [attr.y2]="link.target.y + offset"
            [attr.stroke-dasharray]="config.link.dash || link.dash? config.link.dashArray : []"
        ></svg:line>
    `,
                encapsulation: ViewEncapsulation.None,
                providers: [KdMindmapEvent, KdDomElemSvc],
                host: {
                    'class': 'kdx-mindmap-link'
                }
            },] }
];
KdMindmapLink.ctorParameters = () => [
    { type: KdMindmapEvent },
    { type: KdDomElemSvc },
    { type: ElementRef }
];
KdMindmapLink.propDecorators = {
    mindmapId: [{ type: Input }],
    link: [{ type: Input, args: ['kdx-mindmap-link',] }],
    allConfig: [{ type: Input, args: ['config',] }],
    internalLinkApiRef: [{ type: Input, args: ['api',] }]
};
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoia2QtYW5ndWxhci1taW5kbWFwLWxpbmsuanMiLCJzb3VyY2VSb290IjoiQzovUHJvamVjdHMvQW5ndWxhci9pb3N0Zy1vcGVuZW1pcy1zdHlsZWd1aWRlL3Byb2plY3RzL29wZW5lbWlzLXN0eWxlZ3VpZGUtbGliL3NyYy8iLCJzb3VyY2VzIjpbImtkLWNvbXBvbmVudHMva2QtYW5ndWxhci1taW5kbWFwL2xpbmtzL2tkLWFuZ3VsYXItbWluZG1hcC1saW5rLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBLE9BQU8sRUFDSCxTQUFTLEVBQ1QsS0FBSyxFQUNMLGlCQUFpQixFQUtqQixVQUFVLEdBQ2IsTUFBTSxlQUFlLENBQUM7QUFFdkIsT0FBTyxFQUFFLFlBQVksRUFBRSxNQUFNLHVCQUF1QixDQUFDO0FBQ3JELE9BQU8sRUFBRSxjQUFjLEVBQUUsTUFBTSw2QkFBNkIsQ0FBQztBQTJCN0QsTUFBTSxPQUFPLGFBQWE7SUFXdEIsWUFDWSxhQUE2QixFQUM3QixPQUFxQixFQUNyQixRQUFvQjtRQUZwQixrQkFBYSxHQUFiLGFBQWEsQ0FBZ0I7UUFDN0IsWUFBTyxHQUFQLE9BQU8sQ0FBYztRQUNyQixhQUFRLEdBQVIsUUFBUSxDQUFZO1FBWnpCLFdBQU0sR0FBVyxDQUFDLENBQUM7UUFFbEIsZ0JBQVcsR0FBWSxLQUFLLENBQUM7SUFXakMsQ0FBQztJQUVMLFFBQVE7UUFDSixJQUFJLENBQUMsUUFBUSxFQUFFLENBQUM7UUFDaEIsSUFBSSxDQUFDLFVBQVUsQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLENBQUM7UUFDaEMsSUFBSSxDQUFDLGdCQUFnQixHQUFHLElBQUksQ0FBQyxhQUFhO2FBQ3JDLGNBQWMsQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDO2FBQzlCLFNBQVMsQ0FBQyxDQUFDLEtBQW1CLEVBQVEsRUFBRSxDQUFDLElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDO0lBQ2pGLENBQUM7SUFFRCxXQUFXLENBQUMsY0FBNkI7UUFDckMsSUFBSSxjQUFjLENBQUMsY0FBYyxDQUFDLFdBQVcsQ0FBQyxJQUFJLENBQUMsY0FBYyxDQUFDLFdBQVcsQ0FBQyxDQUFDLFdBQVcsRUFBRTtZQUN4RixJQUFJLENBQUMsVUFBVSxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsQ0FBQztTQUNuQztJQUNMLENBQUM7SUFFRCxXQUFXO1FBQ1AsSUFBSSxDQUFDLGdCQUFnQixDQUFDLFdBQVcsRUFBRSxDQUFDO0lBQ3hDLENBQUM7SUFFTyxRQUFRO1FBQ1osSUFBSSxPQUFPLElBQUksQ0FBQyxrQkFBa0IsS0FBSyxXQUFXLEVBQUU7WUFDaEQsSUFBSSxDQUFDLGtCQUFrQixDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLEdBQUcsRUFBRSxDQUFDO1lBQzlDLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFDLGFBQWEsR0FBRyxDQUFDLE9BQWUsRUFBUSxFQUFFLEdBQUcsSUFBSSxDQUFDLE1BQU0sR0FBRyxPQUFPLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO1NBQ3ZIO0lBQ0wsQ0FBQztJQUVPLGlCQUFpQixDQUFDLEtBQW1CO1FBQ3pDLElBQUksSUFBSSxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsS0FBSyxLQUFLLEtBQUssQ0FBQyxLQUFLLElBQUksSUFBSSxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsS0FBSyxLQUFLLEtBQUssQ0FBQyxLQUFLLEVBQUU7WUFDbEYsSUFBSSxJQUFJLENBQUMsV0FBVyxFQUFFO2dCQUNsQixJQUFJLENBQUMsT0FBTyxDQUFDLFdBQVcsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLGFBQWEsRUFBRSxJQUFJLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxXQUFXLENBQUMsQ0FBQztnQkFDcEYsSUFBSSxJQUFJLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxJQUFJO29CQUFFLElBQUksQ0FBQyxjQUFjLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsSUFBSSxFQUFFLGtCQUFrQixFQUFFLGdCQUFnQixDQUFDLENBQUM7Z0JBQzVHLElBQUksQ0FBQyxXQUFXLEdBQUcsS0FBSyxDQUFDO2FBQzVCO1NBQ0o7YUFBTTtZQUNILElBQUksQ0FBQyxJQUFJLENBQUMsV0FBVyxFQUFFO2dCQUNuQixJQUFJLENBQUMsT0FBTyxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLGFBQWEsRUFBRSxJQUFJLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxXQUFXLENBQUMsQ0FBQztnQkFDakYsSUFBSSxJQUFJLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxJQUFJO29CQUFFLElBQUksQ0FBQyxjQUFjLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsSUFBSSxFQUFFLHdCQUF3QixFQUFFLHNCQUFzQixDQUFDLENBQUM7Z0JBQ3hILElBQUksQ0FBQyxXQUFXLEdBQUcsSUFBSSxDQUFDO2FBQzNCO1NBQ0o7SUFDTCxDQUFDO0lBRU8sVUFBVSxDQUFDLE9BQU87UUFDdEIsSUFBSSxDQUFDLE1BQU0sR0FBRyxNQUFNLENBQUMsTUFBTSxDQUFDLEVBQUUsRUFBRSxPQUFPLENBQUMsQ0FBQztRQUN6QyxJQUFJLENBQUMsTUFBTSxDQUFDLElBQUksR0FBRyxNQUFNLENBQUMsTUFBTSxDQUFDLEVBQUUsRUFBRSxPQUFPLENBQUMsSUFBSSxDQUFDLENBQUM7UUFDbkQsSUFBSSxDQUFDLFVBQVUsRUFBRSxDQUFDO1FBQ2xCLElBQUksSUFBSSxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsS0FBSztZQUFFLElBQUksQ0FBQyxPQUFPLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsYUFBYSxFQUFFLElBQUksQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFDO0lBQzNHLENBQUM7SUFFRDs7T0FFRztJQUNLLFVBQVU7UUFDZCxJQUFJLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSTtZQUFFLElBQUksQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLElBQUksR0FBRyxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQztRQUMzRCxJQUFJLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsSUFBSTtZQUFFLE9BQU87UUFDbkMsSUFBSSxDQUFDLGNBQWMsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxJQUFJLEVBQUUsa0JBQWtCLEVBQUUsZ0JBQWdCLENBQUMsQ0FBQztJQUNyRixDQUFDO0lBRU8sY0FBYyxDQUFDLFdBQW1CLEVBQUUsU0FBaUIsRUFBRSxPQUFlO1FBQzFFLElBQUksV0FBVyxLQUFLLFdBQVcsSUFBSSxXQUFXLEtBQUssZUFBZSxFQUFFO1lBQ2hFLElBQUksQ0FBQyxPQUFPLENBQUMsWUFBWSxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsYUFBYSxDQUFDLGFBQWEsQ0FBQyx3QkFBd0IsQ0FBQyxFQUFFLFlBQVksRUFBRSxPQUFPLENBQUMsQ0FBQztTQUN6SDtRQUNELElBQUksV0FBVyxLQUFLLGVBQWUsRUFBRTtZQUNqQyxJQUFJLENBQUMsT0FBTyxDQUFDLFlBQVksQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLGFBQWEsQ0FBQyxhQUFhLENBQUMsd0JBQXdCLENBQUMsRUFBRSxjQUFjLEVBQUUsU0FBUyxDQUFDLENBQUM7U0FDN0g7SUFDTCxDQUFDOzs7WUFyR0osU0FBUyxTQUFDO2dCQUNQLFFBQVEsRUFBRSxvQkFBb0I7Z0JBQzlCLFFBQVEsRUFBRTs7Ozs7Ozs7Ozs7S0FXVDtnQkFDRCxhQUFhLEVBQUUsaUJBQWlCLENBQUMsSUFBSTtnQkFDckMsU0FBUyxFQUFFLENBQUMsY0FBYyxFQUFFLFlBQVksQ0FBQztnQkFDekMsSUFBSSxFQUFFO29CQUNGLE9BQU8sRUFBRSxrQkFBa0I7aUJBQzlCO2FBQ0o7OztZQTFCUSxjQUFjO1lBRGQsWUFBWTtZQUhqQixVQUFVOzs7d0JBcUNULEtBQUs7bUJBQ0wsS0FBSyxTQUFDLGtCQUFrQjt3QkFDeEIsS0FBSyxTQUFDLFFBQVE7aUNBQ2QsS0FBSyxTQUFDLEtBQUsiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQge1xyXG4gICAgQ29tcG9uZW50LFxyXG4gICAgSW5wdXQsXHJcbiAgICBWaWV3RW5jYXBzdWxhdGlvbixcclxuICAgIE9uSW5pdCxcclxuICAgIE9uQ2hhbmdlcyxcclxuICAgIFNpbXBsZUNoYW5nZXMsXHJcbiAgICBPbkRlc3Ryb3ksXHJcbiAgICBFbGVtZW50UmVmLFxyXG59IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xyXG5pbXBvcnQgeyBTdWJzY3JpcHRpb24gfSBmcm9tICdyeGpzJztcclxuaW1wb3J0IHsgS2REb21FbGVtU3ZjIH0gZnJvbSAnLi4vLi4va2QtY29tbW9uL2luZGV4JztcclxuaW1wb3J0IHsgS2RNaW5kbWFwRXZlbnQgfSBmcm9tICcuLi9rZC1hbmd1bGFyLW1pbmRtYXAtZXZlbnQnO1xyXG5pbXBvcnQgeyBcclxuICAgIElNaW5kbWFwTm9kZSwgXHJcbiAgICBJSW50ZXJuYWxBbGxDb25maWcsIFxyXG4gICAgSU1pbmRtYXBJbnRlcm5hbExpbmtBcGlSZWYgXHJcbn0gZnJvbSAnLi4va2QtYW5ndWxhci1taW5kbWFwLWludGVyZmFjZSc7XHJcblxyXG5AQ29tcG9uZW50KHtcclxuICAgIHNlbGVjdG9yOiAnW2tkeC1taW5kbWFwLWxpbmtdJyxcclxuICAgIHRlbXBsYXRlOiBgXHJcbiAgICAgICAgPHN2ZzpsaW5lXHJcbiAgICAgICAgICAgIGNsYXNzPVwia2R4LW1pbmRtYXAtbGluay1saW5lXCJcclxuICAgICAgICAgICAgW2F0dHIuYXJpYS1zb3VyY2VdPVwibGluay5zb3VyY2UudGl0bGVcIlxyXG4gICAgICAgICAgICBbYXR0ci5hcmlhLXRhcmdldF09XCJsaW5rLnRhcmdldC50aXRsZVwiXHJcbiAgICAgICAgICAgIFthdHRyLngxXT1cImxpbmsuc291cmNlLnggKyBjb25maWcubm9kZS53aWR0aC8yXCJcclxuICAgICAgICAgICAgW2F0dHIueTFdPVwibGluay5zb3VyY2UueVwiXHJcbiAgICAgICAgICAgIFthdHRyLngyXT1cImxpbmsudGFyZ2V0LnggLSBjb25maWcubm9kZS53aWR0aC8yXCJcclxuICAgICAgICAgICAgW2F0dHIueTJdPVwibGluay50YXJnZXQueSArIG9mZnNldFwiXHJcbiAgICAgICAgICAgIFthdHRyLnN0cm9rZS1kYXNoYXJyYXldPVwiY29uZmlnLmxpbmsuZGFzaCB8fCBsaW5rLmRhc2g/IGNvbmZpZy5saW5rLmRhc2hBcnJheSA6IFtdXCJcclxuICAgICAgICA+PC9zdmc6bGluZT5cclxuICAgIGAsXHJcbiAgICBlbmNhcHN1bGF0aW9uOiBWaWV3RW5jYXBzdWxhdGlvbi5Ob25lLFxyXG4gICAgcHJvdmlkZXJzOiBbS2RNaW5kbWFwRXZlbnQsIEtkRG9tRWxlbVN2Y10sXHJcbiAgICBob3N0OiB7XHJcbiAgICAgICAgJ2NsYXNzJzogJ2tkeC1taW5kbWFwLWxpbmsnXHJcbiAgICB9XHJcbn0pXHJcbmV4cG9ydCBjbGFzcyBLZE1pbmRtYXBMaW5rIGltcGxlbWVudHMgT25Jbml0LCBPbkNoYW5nZXMsIE9uRGVzdHJveSB7XHJcbiAgICBwdWJsaWMgY29uZmlnOiBJSW50ZXJuYWxBbGxDb25maWc7XHJcbiAgICBwdWJsaWMgb2Zmc2V0OiBudW1iZXIgPSAwO1xyXG4gICAgcHJpdmF0ZSBfbm9kZVNlbGVjdGVkU3ViOiBTdWJzY3JpcHRpb247XHJcbiAgICBwcml2YXRlIF9saW5rQWN0aXZlOiBib29sZWFuID0gZmFsc2U7XHJcblxyXG4gICAgQElucHV0KCkgbWluZG1hcElkOiBzdHJpbmc7XHJcbiAgICBASW5wdXQoJ2tkeC1taW5kbWFwLWxpbmsnKSBsaW5rOiBhbnk7XHJcbiAgICBASW5wdXQoJ2NvbmZpZycpIGFsbENvbmZpZzogSUludGVybmFsQWxsQ29uZmlnO1xyXG4gICAgQElucHV0KCdhcGknKSBpbnRlcm5hbExpbmtBcGlSZWY6IElNaW5kbWFwSW50ZXJuYWxMaW5rQXBpUmVmO1xyXG5cclxuICAgIGNvbnN0cnVjdG9yKFxyXG4gICAgICAgIHByaXZhdGUgX21pbmRtYXBFdmVudDogS2RNaW5kbWFwRXZlbnQsXHJcbiAgICAgICAgcHJpdmF0ZSBfZG9tU3ZjOiBLZERvbUVsZW1TdmMsXHJcbiAgICAgICAgcHJpdmF0ZSBfZWxlbVJlZjogRWxlbWVudFJlZlxyXG4gICAgKSB7IH1cclxuXHJcbiAgICBuZ09uSW5pdCgpOiB2b2lkIHtcclxuICAgICAgICB0aGlzLl9pbml0QXBpKCk7XHJcbiAgICAgICAgdGhpcy5fc2V0Q29uZmlnKHRoaXMuYWxsQ29uZmlnKTtcclxuICAgICAgICB0aGlzLl9ub2RlU2VsZWN0ZWRTdWIgPSB0aGlzLl9taW5kbWFwRXZlbnRcclxuICAgICAgICAgICAgLm9uTm9kZVNlbGVjdGVkKHRoaXMubWluZG1hcElkKVxyXG4gICAgICAgICAgICAuc3Vic2NyaWJlKChfbm9kZTogSU1pbmRtYXBOb2RlKTogdm9pZCA9PiB0aGlzLl9saW5rQWN0aXZlU3dpdGNoKF9ub2RlKSk7XHJcbiAgICB9XHJcblxyXG4gICAgbmdPbkNoYW5nZXMoX3NpbXBsZUNoYW5nZXM6IFNpbXBsZUNoYW5nZXMpOiB2b2lkIHtcclxuICAgICAgICBpZiAoX3NpbXBsZUNoYW5nZXMuaGFzT3duUHJvcGVydHkoJ2FsbENvbmZpZycpICYmICFfc2ltcGxlQ2hhbmdlc1snYWxsQ29uZmlnJ10uZmlyc3RDaGFuZ2UpIHtcclxuICAgICAgICAgICAgdGhpcy5fc2V0Q29uZmlnKHRoaXMuYWxsQ29uZmlnKTtcclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgbmdPbkRlc3Ryb3koKTogdm9pZCB7XHJcbiAgICAgICAgdGhpcy5fbm9kZVNlbGVjdGVkU3ViLnVuc3Vic2NyaWJlKCk7XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfaW5pdEFwaSgpOiB2b2lkIHtcclxuICAgICAgICBpZiAodHlwZW9mIHRoaXMuaW50ZXJuYWxMaW5rQXBpUmVmICE9PSAndW5kZWZpbmVkJykge1xyXG4gICAgICAgICAgICB0aGlzLmludGVybmFsTGlua0FwaVJlZlt0aGlzLmxpbmsuaW5kZXhdID0ge307XHJcbiAgICAgICAgICAgIHRoaXMuaW50ZXJuYWxMaW5rQXBpUmVmW3RoaXMubGluay5pbmRleF0uc2V0TGlua09mZnNldCA9IChfb2Zmc2V0OiBudW1iZXIpOiB2b2lkID0+IHsgdGhpcy5vZmZzZXQgPSBfb2Zmc2V0IHx8IDA7IH07XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX2xpbmtBY3RpdmVTd2l0Y2goX25vZGU6IElNaW5kbWFwTm9kZSk6IHZvaWQge1xyXG4gICAgICAgIGlmICh0aGlzLmxpbmsudGFyZ2V0LmluZGV4ICE9PSBfbm9kZS5pbmRleCAmJiB0aGlzLmxpbmsuc291cmNlLmluZGV4ICE9PSBfbm9kZS5pbmRleCkge1xyXG4gICAgICAgICAgICBpZiAodGhpcy5fbGlua0FjdGl2ZSkge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5fZG9tU3ZjLnJlbW92ZUNsYXNzKHRoaXMuX2VsZW1SZWYubmF0aXZlRWxlbWVudCwgdGhpcy5jb25maWcubGluay5hY3RpdmVDbGFzcyk7XHJcbiAgICAgICAgICAgICAgICBpZiAodGhpcy5jb25maWcubGluay50eXBlKSB0aGlzLl9zZXRNYXJrZXJUeXBlKHRoaXMuY29uZmlnLmxpbmsudHlwZSwgJ3VybCgjYXJyb3dTdGFydCknLCAndXJsKCNhcnJvd0VuZCknKTtcclxuICAgICAgICAgICAgICAgIHRoaXMuX2xpbmtBY3RpdmUgPSBmYWxzZTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgIGlmICghdGhpcy5fbGlua0FjdGl2ZSkge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5fZG9tU3ZjLmFkZENsYXNzKHRoaXMuX2VsZW1SZWYubmF0aXZlRWxlbWVudCwgdGhpcy5jb25maWcubGluay5hY3RpdmVDbGFzcyk7XHJcbiAgICAgICAgICAgICAgICBpZiAodGhpcy5jb25maWcubGluay50eXBlKSB0aGlzLl9zZXRNYXJrZXJUeXBlKHRoaXMuY29uZmlnLmxpbmsudHlwZSwgJ3VybCgjYXJyb3dTdGFydEFjdGl2ZSknLCAndXJsKCNhcnJvd0VuZEFjdGl2ZSknKTtcclxuICAgICAgICAgICAgICAgIHRoaXMuX2xpbmtBY3RpdmUgPSB0cnVlO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX3NldENvbmZpZyhfY29uZmlnKTogdm9pZCB7XHJcbiAgICAgICAgdGhpcy5jb25maWcgPSBPYmplY3QuYXNzaWduKHt9LCBfY29uZmlnKTtcclxuICAgICAgICB0aGlzLmNvbmZpZy5saW5rID0gT2JqZWN0LmFzc2lnbih7fSwgX2NvbmZpZy5saW5rKTtcclxuICAgICAgICB0aGlzLl9zZXRNYXJrZXIoKTtcclxuICAgICAgICBpZiAodGhpcy5jb25maWcubGluay5jbGFzcykgdGhpcy5fZG9tU3ZjLmFkZENsYXNzKHRoaXMuX2VsZW1SZWYubmF0aXZlRWxlbWVudCwgdGhpcy5jb25maWcubGluay5jbGFzcyk7XHJcbiAgICB9XHJcblxyXG4gICAgLyoqXHJcbiAgICAgKiBbX3NldE1hcmtlciBpcyBzZXR0aW5nIHdoZXRoZXIgdGhlIGFycm93IGhlYWRzIHNob3VsZCBhcHBlYXJdXHJcbiAgICAgKi9cclxuICAgIHByaXZhdGUgX3NldE1hcmtlcigpOiB2b2lkIHtcclxuICAgICAgICBpZiAodGhpcy5saW5rLnR5cGUpIHRoaXMuY29uZmlnLmxpbmsudHlwZSA9IHRoaXMubGluay50eXBlO1xyXG4gICAgICAgIGlmICghdGhpcy5jb25maWcubGluay50eXBlKSByZXR1cm47XHJcbiAgICAgICAgdGhpcy5fc2V0TWFya2VyVHlwZSh0aGlzLmNvbmZpZy5saW5rLnR5cGUsICd1cmwoI2Fycm93U3RhcnQpJywgJ3VybCgjYXJyb3dFbmQpJyk7XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfc2V0TWFya2VyVHlwZShfY29uZmlnVHlwZTogc3RyaW5nLCBfdXJsU3RhcnQ6IHN0cmluZywgX3VybEVuZDogc3RyaW5nKTogdm9pZCB7XHJcbiAgICAgICAgaWYgKF9jb25maWdUeXBlID09PSAnZGlyZWN0aW9uJyB8fCBfY29uZmlnVHlwZSA9PT0gJ3R3by1kaXJlY3Rpb24nKSB7XHJcbiAgICAgICAgICAgIHRoaXMuX2RvbVN2Yy5zZXRBdHRyaWJ1dGUodGhpcy5fZWxlbVJlZi5uYXRpdmVFbGVtZW50LnF1ZXJ5U2VsZWN0b3IoJy5rZHgtbWluZG1hcC1saW5rLWxpbmUnKSwgJ21hcmtlci1lbmQnLCBfdXJsRW5kKTtcclxuICAgICAgICB9XHJcbiAgICAgICAgaWYgKF9jb25maWdUeXBlID09PSAndHdvLWRpcmVjdGlvbicpIHtcclxuICAgICAgICAgICAgdGhpcy5fZG9tU3ZjLnNldEF0dHJpYnV0ZSh0aGlzLl9lbGVtUmVmLm5hdGl2ZUVsZW1lbnQucXVlcnlTZWxlY3RvcignLmtkeC1taW5kbWFwLWxpbmstbGluZScpLCAnbWFya2VyLXN0YXJ0JywgX3VybFN0YXJ0KTtcclxuICAgICAgICB9XHJcbiAgICB9XHJcbn1cclxuIl19