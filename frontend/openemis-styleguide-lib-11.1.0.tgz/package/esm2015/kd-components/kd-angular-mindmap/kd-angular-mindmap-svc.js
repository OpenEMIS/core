import { Injectable } from '@angular/core';
import * as d3 from 'd3';
import { ForceDirectedGraph } from './kd-angular-mindmap-force-logic';
import { ZoomClass } from './zoom/kd-angular-mindmap-zoom-logic';
export class KdMindmapSvc {
    constructor() {
        this._dataMessagingInfo = {
            highestCount: 1,
            count: 1,
            linksStored: {}
        };
        this._nodesObj = {};
        this._newLinks = [];
    }
    /**
     * A method to bind a draggable behaviour to an svg element
     *          element [element to attach drag behaviour]
     *        node    [node info]
     *  graph   [object connecting to d3 force logic]
     */
    applyDraggableBehaviour(element, node, graph) {
        const d3element = d3.select(element);
        function started() {
            /** Preventing propagation of dragstart to parent elements */
            d3.event.sourceEvent.stopPropagation();
            if (!d3.event.active) {
                graph.simulation.alphaTarget(0.3).restart();
            }
            d3.event.on('drag', dragged).on('end', ended);
            function dragged() {
                node.fx = d3.event.x;
                node.fy = d3.event.y;
            }
            function ended() {
                if (!d3.event.active) {
                    graph.simulation.alphaTarget(0);
                }
                node.fx = null;
                node.fy = null;
            }
        }
        d3element.call(d3.drag()
            .on('start', started));
    }
    /**
     * [getZoomClass returns the zoom class]
     *   _svg       [the main svg element]
     *  _container [the g tag that contains the nodes and links]
     *               [zoom class contains d3 codes and stores the _svg and _container variables for d3 zooming]
     */
    getZoomClass(_svg, _container) {
        const zoomClass = new ZoomClass(_svg, _container);
        return zoomClass;
    }
    /**
     * [getForceDirectedGraph The interactable graph we will simulate in this article. This method does not interact with the document, purely physical calculations with d3]
     *      nodes   [description]
     *      links   [description]
     *     options [contains info of width, height of main svg container and levelPosition]
     *          [ForceDirectedGraph class]
     */
    getForceDirectedGraph(nodes, links, options) {
        const sg = new ForceDirectedGraph(nodes, links, options);
        return sg;
    }
    /**
     * textWrap handles text wrapping in svg
     *  _text   text to display
     *     _config [description]
     *          total text height
     */
    textWrap(_text, _class, _config) {
        let textElement = d3.select('.' + _class.replace(/ /g, '.')), words = _text.split(' ').reverse(), word, line = [], lineNumber = 0, lineHeight = _config.fontSize + 2, // in px
        y = textElement.attr('y'), x = textElement.attr('x'), dy = parseFloat(textElement.attr('dy')), tspan = textElement.text(null).append('tspan').attr('x', x).attr('y', y).attr('dy', dy);
        while (word = words.pop()) {
            line.push(word);
            tspan.text(line.join(' '));
            if (tspan.node().getComputedTextLength() > (_config.width - 2 * _config.textPadding)) {
                line.pop();
                tspan.text(line.join(' '));
                line = [word];
                tspan = textElement.append('tspan')
                    .attr('x', x)
                    .attr('y', y)
                    .attr('dy', ++lineNumber * lineHeight + dy)
                    .text(word);
            }
        }
        return (lineNumber + 1) * lineHeight + dy;
    }
    /**
     * [set height of node's title wrapper and node wrapper's height.
     *  Note: title's height have to be calculated and updated to html first
     *  before appending the description text]
     *  _config [node's Config]
     *               _type   [for title or node]
     *                       [height of title or node]
     */
    setSVGContainerHeight(_config, _type) {
        if (_type === 'title') {
            return _config.title.textHeight + _config.title.paddingTop + _config.title.paddingBottom;
        }
        if (_type === 'node') {
            return _config.description.textHeight + _config.title.height + _config.icon.size + _config.icon.marginBottom + _config.icon.marginTop + _config.description.marginBottom + _config.description.marginTop;
        }
    }
    /**
     * [setData appending index, pushing nodes to Array for d3, calling recursive loop this._setLinksAndLevel]
     * } _nodes [description]
     *   [height of title or node]
     */
    setData(_nodes) {
        this._nodesObj = {};
        let newNodes = [], index = 0, haveLoner = false;
        // appending a new key called index to each node.
        // d3 v4 requires link source and target to point to index of node in nodeArr.
        // Hence the below for loop will (1) create a clean copy of object (2) append index to each node
        for (let key in _nodes) {
            if (_nodes.hasOwnProperty(key)) {
                this._nodesObj[key] = Object.assign({}, _nodes[key]);
                this._nodesObj[key].index = index;
                newNodes.push(this._nodesObj[key]);
                index++;
            }
        }
        // this for loop will look for ONLY nodes that have no parents (ie. ancestor nodes and loner nodes)
        // using these nodes as starting points, we start 'walking the branch' via this._setLinksAndLevel to update the links with the relationships of the nodes
        // at this stage, index of all nodes must be defined within the node obj so that the links can be set up correctly
        for (let key in this._nodesObj) {
            if (typeof this._nodesObj[key].parents === 'undefined' || this._nodesObj[key].parents.length === 0) {
                this._setLinksAndLevel(this._nodesObj[key], key);
                // this._setLinksAndLevel did not set level of these starting nodes
                // manually setting their levels now
                this._nodesObj[key].level = 1;
                if (typeof this._nodesObj[key].childs === 'undefined' || this._nodesObj[key].childs.length === 0) {
                    this._nodesObj[key].level = 0;
                    haveLoner = true;
                }
            }
        }
        return {
            nodes: newNodes,
            links: this._newLinks,
            highestCount: this._dataMessagingInfo.highestCount,
            haveLoner: haveLoner
        };
    }
    /**
     * [setFx will set fx coordinate of each node]
     *         _nodes
     * }   position      [fx coordinate of each level]
     *                    _haveLoner     [whether there exist loner in the graph]
     *        _nodes        [nodes with fx value]
     */
    setFx(_nodes, _position, _haveLoner) {
        for (let i = 0; i < _nodes.length; ++i) {
            _nodes[i].fx = _haveLoner ? _position[_nodes[i].level] : _position[_nodes[i].level - 1];
        }
        return _nodes;
    }
    /**
     * [translateSvgToXPos translate node to center, right edge or left edge of main svg container]
     * }   _config      [widths of main svg, node and padding]
     *  _nodeToFocus
     *  _placement
     *                     [x-coordinate for ]
     */
    translateSvgToXPos(_config, _nodeToFocus, _placement) {
        let xPos = 0;
        if (_placement === 'right') {
            xPos = _config.svgWidth;
            return xPos - _nodeToFocus.fx - _config.nodeWidth / 2 - _config.padding;
        }
        if (_placement === 'center') {
            xPos = _config.svgWidth / 2;
            return xPos - _nodeToFocus.fx;
        }
        if (_placement === 'left') {
            return -_nodeToFocus.fx + _config.nodeWidth / 2 + _config.padding;
        }
    }
    /**
     * [setLinkSpreadDistance calculate offset needed for links to spread evenly across height of node]
     *    _links
     *  _node       [node that have finished height calculation. (these nodes must have parents)]
     *        _nodeHeight [Height of node]
     *                     [return index of link and offset value]
     */
    setLinkSpreadDistance(_links, _node, _nodeHeight) {
        let noOfParents = _node.parents.length;
        if (noOfParents === 1)
            return [];
        let dist = (_nodeHeight - 20) / (noOfParents - 1);
        let affectedLinks = [];
        for (let i = 0; i < _links.length; ++i) {
            if (_links[i].target.id === _node.id) {
                affectedLinks.push({ index: _links[i].index });
            }
        }
        for (let i = 0; i < affectedLinks.length; ++i) {
            affectedLinks[i].offset = -_nodeHeight / 2 + i * dist + 10;
        }
        return affectedLinks;
    }
    foundSelectedNode(_nodes, _selectOnLoadId) {
        return _nodes[_selectOnLoadId] !== null && _nodes[_selectOnLoadId] !== undefined;
    }
    /**
     * [_setLinksAndLevel is to generate the level, level's record highestCount, links Array, parents array]
     *  _node [Object containing all info of a node, to be passed to component kd-mindmap-node]
     *        key   [key of the node object in the master object]
     */
    _setLinksAndLevel(_node, key) {
        // if node have no child, do not run the following
        if (!_node.childs || _node.childs.length === 0)
            return;
        this._dataMessagingInfo.count++;
        for (let i = 0; i < _node.childs.length; i++) {
            let linkString = '(' + key + ',' + _node.childs[i] + ')';
            if (!this._dataMessagingInfo.linksStored.hasOwnProperty(linkString)) {
                this._dataMessagingInfo.linksStored[linkString] = '';
                this._newLinks.push({ source: _node.index, target: this._nodesObj[_node.childs[i]].index });
            }
            if (this._nodesObj[_node.childs[i]].level > this._dataMessagingInfo.count)
                continue;
            if (this._dataMessagingInfo.count === 1) {
                this._nodesObj[_node.childs[i]].level = _node.level + 1 || 2;
                this._dataMessagingInfo.count = _node.level + 1 || 2;
            }
            else {
                this._nodesObj[_node.childs[i]].level = this._dataMessagingInfo.count;
                if (this._dataMessagingInfo.highestCount < this._dataMessagingInfo.count) {
                    this._dataMessagingInfo.highestCount = this._dataMessagingInfo.count;
                }
            }
            // if node have grandchild, continue the loop and set node of next cycle to be current node's child
            this._setLinksAndLevel(this._nodesObj[_node.childs[i]], _node.childs[i]);
        }
        this._dataMessagingInfo.count = 1;
    }
}
KdMindmapSvc.decorators = [
    { type: Injectable }
];
KdMindmapSvc.ctorParameters = () => [];
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoia2QtYW5ndWxhci1taW5kbWFwLXN2Yy5qcyIsInNvdXJjZVJvb3QiOiJDOi9Qcm9qZWN0cy9Bbmd1bGFyL2lvc3RnLW9wZW5lbWlzLXN0eWxlZ3VpZGUvcHJvamVjdHMvb3BlbmVtaXMtc3R5bGVndWlkZS1saWIvc3JjLyIsInNvdXJjZXMiOlsia2QtY29tcG9uZW50cy9rZC1hbmd1bGFyLW1pbmRtYXAva2QtYW5ndWxhci1taW5kbWFwLXN2Yy50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQSxPQUFPLEVBQUUsVUFBVSxFQUFjLE1BQU0sZUFBZSxDQUFDO0FBQ3ZELE9BQU8sS0FBSyxFQUFFLE1BQU0sSUFBSSxDQUFDO0FBQ3pCLE9BQU8sRUFBRSxrQkFBa0IsRUFBRSxNQUFNLGtDQUFrQyxDQUFDO0FBQ3RFLE9BQU8sRUFBRSxTQUFTLEVBQUUsTUFBTSxzQ0FBc0MsQ0FBQztBQVNqRSxNQUFNLE9BQU8sWUFBWTtJQVVyQjtRQVJRLHVCQUFrQixHQUFvRjtZQUMxRyxZQUFZLEVBQUUsQ0FBQztZQUNmLEtBQUssRUFBRSxDQUFDO1lBQ1IsV0FBVyxFQUFFLEVBQUU7U0FDbEIsQ0FBQztRQUNNLGNBQVMsR0FBb0MsRUFBRSxDQUFDO1FBQ2hELGNBQVMsR0FBd0IsRUFBRSxDQUFDO0lBRTVCLENBQUM7SUFDakI7Ozs7O09BS0c7SUFDSSx1QkFBdUIsQ0FBQyxPQUFtQixFQUFFLElBQWtCLEVBQUUsS0FBeUI7UUFDN0YsTUFBTSxTQUFTLEdBQUcsRUFBRSxDQUFDLE1BQU0sQ0FBQyxPQUFPLENBQUMsQ0FBQztRQUVyQyxTQUFTLE9BQU87WUFDWiw2REFBNkQ7WUFDN0QsRUFBRSxDQUFDLEtBQUssQ0FBQyxXQUFXLENBQUMsZUFBZSxFQUFFLENBQUM7WUFFdkMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxLQUFLLENBQUMsTUFBTSxFQUFFO2dCQUNsQixLQUFLLENBQUMsVUFBVSxDQUFDLFdBQVcsQ0FBQyxHQUFHLENBQUMsQ0FBQyxPQUFPLEVBQUUsQ0FBQzthQUMvQztZQUVELEVBQUUsQ0FBQyxLQUFLLENBQUMsRUFBRSxDQUFDLE1BQU0sRUFBRSxPQUFPLENBQUMsQ0FBQyxFQUFFLENBQUMsS0FBSyxFQUFFLEtBQUssQ0FBQyxDQUFDO1lBRTlDLFNBQVMsT0FBTztnQkFDWixJQUFJLENBQUMsRUFBRSxHQUFHLEVBQUUsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDO2dCQUNyQixJQUFJLENBQUMsRUFBRSxHQUFHLEVBQUUsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDO1lBQ3pCLENBQUM7WUFFRCxTQUFTLEtBQUs7Z0JBQ1YsSUFBSSxDQUFDLEVBQUUsQ0FBQyxLQUFLLENBQUMsTUFBTSxFQUFFO29CQUNsQixLQUFLLENBQUMsVUFBVSxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUMsQ0FBQztpQkFDbkM7Z0JBRUQsSUFBSSxDQUFDLEVBQUUsR0FBRyxJQUFJLENBQUM7Z0JBQ2YsSUFBSSxDQUFDLEVBQUUsR0FBRyxJQUFJLENBQUM7WUFDbkIsQ0FBQztRQUNMLENBQUM7UUFFRCxTQUFTLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxJQUFJLEVBQUU7YUFDbkIsRUFBRSxDQUFDLE9BQU8sRUFBRSxPQUFPLENBQUMsQ0FBQyxDQUFDO0lBQy9CLENBQUM7SUFFRDs7Ozs7T0FLRztJQUNJLFlBQVksQ0FBQyxJQUFnQixFQUFFLFVBQXVCO1FBQ3pELE1BQU0sU0FBUyxHQUFHLElBQUksU0FBUyxDQUFDLElBQUksRUFBRSxVQUFVLENBQUMsQ0FBQztRQUNsRCxPQUFPLFNBQVMsQ0FBQztJQUNyQixDQUFDO0lBRUQ7Ozs7OztPQU1HO0lBQ0kscUJBQXFCLENBQUMsS0FBcUIsRUFBRSxLQUFxQixFQUFFLE9BQXdCO1FBQy9GLE1BQU0sRUFBRSxHQUFHLElBQUksa0JBQWtCLENBQUMsS0FBSyxFQUFFLEtBQUssRUFBRSxPQUFPLENBQUMsQ0FBQztRQUN6RCxPQUFPLEVBQUUsQ0FBQztJQUNkLENBQUM7SUFFRDs7Ozs7T0FLRztJQUNJLFFBQVEsQ0FBQyxLQUFhLEVBQUUsTUFBYyxFQUFFLE9BQTRCO1FBQ3ZFLElBQUksV0FBVyxHQUFHLEVBQUUsQ0FBQyxNQUFNLENBQUMsR0FBRyxHQUFHLE1BQU0sQ0FBQyxPQUFPLENBQUMsSUFBSSxFQUFFLEdBQUcsQ0FBQyxDQUFDLEVBQ3hELEtBQUssR0FBRyxLQUFLLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDLE9BQU8sRUFBRSxFQUNsQyxJQUFJLEVBQ0osSUFBSSxHQUFHLEVBQUUsRUFDVCxVQUFVLEdBQUcsQ0FBQyxFQUNkLFVBQVUsR0FBRyxPQUFPLENBQUMsUUFBUSxHQUFHLENBQUMsRUFBRSxRQUFRO1FBQzNDLENBQUMsR0FBRyxXQUFXLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxFQUN6QixDQUFDLEdBQUcsV0FBVyxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsRUFDekIsRUFBRSxHQUFHLFVBQVUsQ0FBQyxXQUFXLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDLEVBQ3ZDLEtBQUssR0FBRyxXQUFXLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDLE1BQU0sQ0FBQyxPQUFPLENBQUMsQ0FBQyxJQUFJLENBQUMsR0FBRyxFQUFFLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxHQUFHLEVBQUUsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLElBQUksRUFBRSxFQUFFLENBQUMsQ0FBQztRQUU1RixPQUFPLElBQUksR0FBRyxLQUFLLENBQUMsR0FBRyxFQUFFLEVBQUU7WUFDdkIsSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQztZQUNoQixLQUFLLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQztZQUMzQixJQUFJLEtBQUssQ0FBQyxJQUFJLEVBQUUsQ0FBQyxxQkFBcUIsRUFBRSxHQUFHLENBQUMsT0FBTyxDQUFDLEtBQUssR0FBRyxDQUFDLEdBQUcsT0FBTyxDQUFDLFdBQVcsQ0FBQyxFQUFFO2dCQUNsRixJQUFJLENBQUMsR0FBRyxFQUFFLENBQUM7Z0JBQ1gsS0FBSyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUM7Z0JBQzNCLElBQUksR0FBRyxDQUFDLElBQUksQ0FBQyxDQUFDO2dCQUNkLEtBQUssR0FBRyxXQUFXLENBQUMsTUFBTSxDQUFDLE9BQU8sQ0FBQztxQkFDOUIsSUFBSSxDQUFDLEdBQUcsRUFBRSxDQUFDLENBQUM7cUJBQ1osSUFBSSxDQUFDLEdBQUcsRUFBRSxDQUFDLENBQUM7cUJBQ1osSUFBSSxDQUFDLElBQUksRUFBRSxFQUFFLFVBQVUsR0FBRyxVQUFVLEdBQUcsRUFBRSxDQUFDO3FCQUMxQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUM7YUFDbkI7U0FDSjtRQUNELE9BQU8sQ0FBQyxVQUFVLEdBQUcsQ0FBQyxDQUFDLEdBQUcsVUFBVSxHQUFHLEVBQUUsQ0FBQztJQUM5QyxDQUFDO0lBRUQ7Ozs7Ozs7T0FPRztJQUNJLHFCQUFxQixDQUFDLE9BQTRCLEVBQUUsS0FBYTtRQUNwRSxJQUFJLEtBQUssS0FBSyxPQUFPLEVBQUU7WUFDbkIsT0FBTyxPQUFPLENBQUMsS0FBSyxDQUFDLFVBQVUsR0FBRyxPQUFPLENBQUMsS0FBSyxDQUFDLFVBQVUsR0FBRyxPQUFPLENBQUMsS0FBSyxDQUFDLGFBQWEsQ0FBQztTQUM1RjtRQUNELElBQUksS0FBSyxLQUFLLE1BQU0sRUFBRTtZQUNsQixPQUFPLE9BQU8sQ0FBQyxXQUFXLENBQUMsVUFBVSxHQUFHLE9BQU8sQ0FBQyxLQUFLLENBQUMsTUFBTSxHQUFHLE9BQU8sQ0FBQyxJQUFJLENBQUMsSUFBSSxHQUFHLE9BQU8sQ0FBQyxJQUFJLENBQUMsWUFBWSxHQUFHLE9BQU8sQ0FBQyxJQUFJLENBQUMsU0FBUyxHQUFHLE9BQU8sQ0FBQyxXQUFXLENBQUMsWUFBWSxHQUFHLE9BQU8sQ0FBQyxXQUFXLENBQUMsU0FBUyxDQUFDO1NBQzVNO0lBQ0wsQ0FBQztJQUVEOzs7O09BSUc7SUFDSSxPQUFPLENBQUMsTUFBdUM7UUFNbEQsSUFBSSxDQUFDLFNBQVMsR0FBRyxFQUFFLENBQUM7UUFDcEIsSUFBSSxRQUFRLEdBQUcsRUFBRSxFQUFFLEtBQUssR0FBRyxDQUFDLEVBQUUsU0FBUyxHQUFHLEtBQUssQ0FBQztRQUVoRCxpREFBaUQ7UUFDakQsOEVBQThFO1FBQzlFLGdHQUFnRztRQUNoRyxLQUFLLElBQUksR0FBRyxJQUFJLE1BQU0sRUFBRTtZQUNwQixJQUFJLE1BQU0sQ0FBQyxjQUFjLENBQUMsR0FBRyxDQUFDLEVBQUU7Z0JBQzVCLElBQUksQ0FBQyxTQUFTLENBQUMsR0FBRyxDQUFDLEdBQUcsTUFBTSxDQUFDLE1BQU0sQ0FBQyxFQUFFLEVBQUUsTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUM7Z0JBQ3JELElBQUksQ0FBQyxTQUFTLENBQUMsR0FBRyxDQUFDLENBQUMsS0FBSyxHQUFHLEtBQUssQ0FBQztnQkFDbEMsUUFBUSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUM7Z0JBQ25DLEtBQUssRUFBRSxDQUFDO2FBQ1g7U0FDSjtRQUVELG1HQUFtRztRQUNuRyx5SkFBeUo7UUFDekosa0hBQWtIO1FBQ2xILEtBQUssSUFBSSxHQUFHLElBQUksSUFBSSxDQUFDLFNBQVMsRUFBRTtZQUM1QixJQUFJLE9BQU8sSUFBSSxDQUFDLFNBQVMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxPQUFPLEtBQUssV0FBVyxJQUFJLElBQUksQ0FBQyxTQUFTLENBQUMsR0FBRyxDQUFDLENBQUMsT0FBTyxDQUFDLE1BQU0sS0FBSyxDQUFDLEVBQUU7Z0JBQ2hHLElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLEdBQUcsQ0FBQyxFQUFFLEdBQUcsQ0FBQyxDQUFDO2dCQUVqRCxtRUFBbUU7Z0JBQ25FLG9DQUFvQztnQkFDcEMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxLQUFLLEdBQUcsQ0FBQyxDQUFDO2dCQUM5QixJQUFJLE9BQU8sSUFBSSxDQUFDLFNBQVMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxNQUFNLEtBQUssV0FBVyxJQUFJLElBQUksQ0FBQyxTQUFTLENBQUMsR0FBRyxDQUFDLENBQUMsTUFBTSxDQUFDLE1BQU0sS0FBSyxDQUFDLEVBQUU7b0JBQzlGLElBQUksQ0FBQyxTQUFTLENBQUMsR0FBRyxDQUFDLENBQUMsS0FBSyxHQUFHLENBQUMsQ0FBQztvQkFDOUIsU0FBUyxHQUFHLElBQUksQ0FBQztpQkFDcEI7YUFDSjtTQUNKO1FBRUQsT0FBTztZQUNILEtBQUssRUFBRSxRQUFRO1lBQ2YsS0FBSyxFQUFFLElBQUksQ0FBQyxTQUFTO1lBQ3JCLFlBQVksRUFBRSxJQUFJLENBQUMsa0JBQWtCLENBQUMsWUFBWTtZQUNsRCxTQUFTLEVBQUUsU0FBUztTQUN2QixDQUFDO0lBQ04sQ0FBQztJQUVEOzs7Ozs7T0FNRztJQUNJLEtBQUssQ0FBQyxNQUEyQixFQUFFLFNBQW9DLEVBQUUsVUFBbUI7UUFDL0YsS0FBSyxJQUFJLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxHQUFHLE1BQU0sQ0FBQyxNQUFNLEVBQUUsRUFBRSxDQUFDLEVBQUU7WUFDcEMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsR0FBRyxVQUFVLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxHQUFHLENBQUMsQ0FBQyxDQUFDO1NBQzNGO1FBQ0QsT0FBTyxNQUFNLENBQUM7SUFDbEIsQ0FBQztJQUVEOzs7Ozs7T0FNRztJQUNJLGtCQUFrQixDQUFDLE9BQWlFLEVBQUUsWUFBMEIsRUFBRSxVQUF1QztRQUM1SixJQUFJLElBQUksR0FBVyxDQUFDLENBQUM7UUFDckIsSUFBSSxVQUFVLEtBQUssT0FBTyxFQUFFO1lBQ3hCLElBQUksR0FBRyxPQUFPLENBQUMsUUFBUSxDQUFDO1lBQ3hCLE9BQU8sSUFBSSxHQUFHLFlBQVksQ0FBQyxFQUFFLEdBQUcsT0FBTyxDQUFDLFNBQVMsR0FBRyxDQUFDLEdBQUcsT0FBTyxDQUFDLE9BQU8sQ0FBQztTQUMzRTtRQUNELElBQUksVUFBVSxLQUFLLFFBQVEsRUFBRTtZQUN6QixJQUFJLEdBQUcsT0FBTyxDQUFDLFFBQVEsR0FBRyxDQUFDLENBQUM7WUFDNUIsT0FBTyxJQUFJLEdBQUcsWUFBWSxDQUFDLEVBQUUsQ0FBQztTQUNqQztRQUNELElBQUksVUFBVSxLQUFLLE1BQU0sRUFBRTtZQUN2QixPQUFPLENBQUUsWUFBWSxDQUFDLEVBQUUsR0FBRyxPQUFPLENBQUMsU0FBUyxHQUFHLENBQUMsR0FBRyxPQUFPLENBQUMsT0FBTyxDQUFDO1NBQ3RFO0lBQ0wsQ0FBQztJQUVEOzs7Ozs7T0FNRztJQUNJLHFCQUFxQixDQUFDLE1BQWtCLEVBQUUsS0FBbUIsRUFBRSxXQUFtQjtRQUNyRixJQUFJLFdBQVcsR0FBVyxLQUFLLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQztRQUMvQyxJQUFJLFdBQVcsS0FBSyxDQUFDO1lBQUUsT0FBTyxFQUFFLENBQUM7UUFDakMsSUFBSSxJQUFJLEdBQVcsQ0FBQyxXQUFXLEdBQUcsRUFBRSxDQUFDLEdBQUcsQ0FBQyxXQUFXLEdBQUcsQ0FBQyxDQUFDLENBQUM7UUFDMUQsSUFBSSxhQUFhLEdBQUcsRUFBRSxDQUFDO1FBRXZCLEtBQUssSUFBSSxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsR0FBRyxNQUFNLENBQUMsTUFBTSxFQUFFLEVBQUUsQ0FBQyxFQUFFO1lBQ3BDLElBQUksTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxFQUFFLEtBQUssS0FBSyxDQUFDLEVBQUUsRUFBRTtnQkFDbEMsYUFBYSxDQUFDLElBQUksQ0FBQyxFQUFFLEtBQUssRUFBRSxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxFQUFFLENBQUMsQ0FBQzthQUNsRDtTQUNKO1FBQ0QsS0FBSyxJQUFJLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxHQUFHLGFBQWEsQ0FBQyxNQUFNLEVBQUUsRUFBRSxDQUFDLEVBQUU7WUFDM0MsYUFBYSxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sR0FBRyxDQUFDLFdBQVcsR0FBRyxDQUFDLEdBQUcsQ0FBQyxHQUFHLElBQUksR0FBRyxFQUFFLENBQUM7U0FDOUQ7UUFDRCxPQUFPLGFBQWEsQ0FBQztJQUN6QixDQUFDO0lBRU0saUJBQWlCLENBQUMsTUFBc0IsRUFBRSxlQUF1QjtRQUNwRSxPQUFPLE1BQU0sQ0FBQyxlQUFlLENBQUMsS0FBSyxJQUFJLElBQUksTUFBTSxDQUFDLGVBQWUsQ0FBQyxLQUFLLFNBQVMsQ0FBQztJQUNyRixDQUFDO0lBRUQ7Ozs7T0FJRztJQUNLLGlCQUFpQixDQUFDLEtBQW1CLEVBQUUsR0FBVztRQUN0RCxrREFBa0Q7UUFDbEQsSUFBSSxDQUFDLEtBQUssQ0FBQyxNQUFNLElBQUksS0FBSyxDQUFDLE1BQU0sQ0FBQyxNQUFNLEtBQUssQ0FBQztZQUFFLE9BQU87UUFDdkQsSUFBSSxDQUFDLGtCQUFrQixDQUFDLEtBQUssRUFBRSxDQUFDO1FBRWhDLEtBQUssSUFBSSxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsR0FBRyxLQUFLLENBQUMsTUFBTSxDQUFDLE1BQU0sRUFBRSxDQUFDLEVBQUUsRUFBRTtZQUUxQyxJQUFJLFVBQVUsR0FBVyxHQUFHLEdBQUcsR0FBRyxHQUFHLEdBQUcsR0FBRyxLQUFLLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxHQUFHLEdBQUcsQ0FBQztZQUNqRSxJQUFJLENBQUMsSUFBSSxDQUFDLGtCQUFrQixDQUFDLFdBQVcsQ0FBQyxjQUFjLENBQUMsVUFBVSxDQUFDLEVBQUU7Z0JBQ2pFLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxXQUFXLENBQUMsVUFBVSxDQUFDLEdBQUcsRUFBRSxDQUFDO2dCQUNyRCxJQUFJLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQyxFQUFFLE1BQU0sRUFBRSxLQUFLLENBQUMsS0FBSyxFQUFFLE1BQU0sRUFBRSxJQUFJLENBQUMsU0FBUyxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLEVBQUUsQ0FBQyxDQUFDO2FBQy9GO1lBRUQsSUFBSSxJQUFJLENBQUMsU0FBUyxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLEdBQUcsSUFBSSxDQUFDLGtCQUFrQixDQUFDLEtBQUs7Z0JBQUUsU0FBUztZQUVwRixJQUFJLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxLQUFLLEtBQUssQ0FBQyxFQUFFO2dCQUNyQyxJQUFJLENBQUMsU0FBUyxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLEdBQUcsS0FBSyxDQUFDLEtBQUssR0FBRyxDQUFDLElBQUksQ0FBQyxDQUFDO2dCQUM3RCxJQUFJLENBQUMsa0JBQWtCLENBQUMsS0FBSyxHQUFHLEtBQUssQ0FBQyxLQUFLLEdBQUcsQ0FBQyxJQUFJLENBQUMsQ0FBQzthQUN4RDtpQkFBTTtnQkFDSCxJQUFJLENBQUMsU0FBUyxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLEdBQUcsSUFBSSxDQUFDLGtCQUFrQixDQUFDLEtBQUssQ0FBQztnQkFDdEUsSUFBSSxJQUFJLENBQUMsa0JBQWtCLENBQUMsWUFBWSxHQUFHLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxLQUFLLEVBQUU7b0JBQ3RFLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxZQUFZLEdBQUcsSUFBSSxDQUFDLGtCQUFrQixDQUFDLEtBQUssQ0FBQztpQkFDeEU7YUFDSjtZQUVELG1HQUFtRztZQUNuRyxJQUFJLENBQUMsaUJBQWlCLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsS0FBSyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO1NBQzVFO1FBRUQsSUFBSSxDQUFDLGtCQUFrQixDQUFDLEtBQUssR0FBRyxDQUFDLENBQUM7SUFDdEMsQ0FBQzs7O1lBblJKLFVBQVUiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBJbmplY3RhYmxlLCBFbGVtZW50UmVmIH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XHJcbmltcG9ydCAqIGFzIGQzIGZyb20gJ2QzJztcclxuaW1wb3J0IHsgRm9yY2VEaXJlY3RlZEdyYXBoIH0gZnJvbSAnLi9rZC1hbmd1bGFyLW1pbmRtYXAtZm9yY2UtbG9naWMnO1xyXG5pbXBvcnQgeyBab29tQ2xhc3MgfSBmcm9tICcuL3pvb20va2QtYW5ndWxhci1taW5kbWFwLXpvb20tbG9naWMnO1xyXG5pbXBvcnQgeyBcclxuICAgIElNaW5kbWFwTGluaywgXHJcbiAgICBJTWluZG1hcE5vZGUgLCBcclxuICAgIElJbnRlcm5hbE5vZGVDb25maWcsIFxyXG4gICAgSU1pbmRtYXBPcHRpb25zIFxyXG59IGZyb20gJy4va2QtYW5ndWxhci1taW5kbWFwLWludGVyZmFjZSc7XHJcblxyXG5ASW5qZWN0YWJsZSgpXHJcbmV4cG9ydCBjbGFzcyBLZE1pbmRtYXBTdmMge1xyXG5cclxuICAgIHByaXZhdGUgX2RhdGFNZXNzYWdpbmdJbmZvOiB7IGhpZ2hlc3RDb3VudDogbnVtYmVyLCBjb3VudDogbnVtYmVyLCBsaW5rc1N0b3JlZDogeyBba2V5OiBzdHJpbmddOiBzdHJpbmcgfSB9ID0ge1xyXG4gICAgICAgIGhpZ2hlc3RDb3VudDogMSxcclxuICAgICAgICBjb3VudDogMSxcclxuICAgICAgICBsaW5rc1N0b3JlZDoge31cclxuICAgIH07XHJcbiAgICBwcml2YXRlIF9ub2Rlc09iajogeyBba2V5OiBzdHJpbmddOiBJTWluZG1hcE5vZGUgfSA9IHt9O1xyXG4gICAgcHJpdmF0ZSBfbmV3TGlua3M6IEFycmF5PElNaW5kbWFwTGluaz4gPSBbXTtcclxuXHJcbiAgICBjb25zdHJ1Y3RvcigpIHsgfVxyXG4gICAgLyoqXHJcbiAgICAgKiBBIG1ldGhvZCB0byBiaW5kIGEgZHJhZ2dhYmxlIGJlaGF2aW91ciB0byBhbiBzdmcgZWxlbWVudFxyXG4gICAgICogICAgICAgICAgZWxlbWVudCBbZWxlbWVudCB0byBhdHRhY2ggZHJhZyBiZWhhdmlvdXJdXHJcbiAgICAgKiAgICAgICAgbm9kZSAgICBbbm9kZSBpbmZvXVxyXG4gICAgICogIGdyYXBoICAgW29iamVjdCBjb25uZWN0aW5nIHRvIGQzIGZvcmNlIGxvZ2ljXVxyXG4gICAgICovXHJcbiAgICBwdWJsaWMgYXBwbHlEcmFnZ2FibGVCZWhhdmlvdXIoZWxlbWVudDogRWxlbWVudFJlZiwgbm9kZTogSU1pbmRtYXBOb2RlLCBncmFwaDogRm9yY2VEaXJlY3RlZEdyYXBoKTogdm9pZCB7XHJcbiAgICAgICAgY29uc3QgZDNlbGVtZW50ID0gZDMuc2VsZWN0KGVsZW1lbnQpO1xyXG5cclxuICAgICAgICBmdW5jdGlvbiBzdGFydGVkKCkge1xyXG4gICAgICAgICAgICAvKiogUHJldmVudGluZyBwcm9wYWdhdGlvbiBvZiBkcmFnc3RhcnQgdG8gcGFyZW50IGVsZW1lbnRzICovXHJcbiAgICAgICAgICAgIGQzLmV2ZW50LnNvdXJjZUV2ZW50LnN0b3BQcm9wYWdhdGlvbigpO1xyXG5cclxuICAgICAgICAgICAgaWYgKCFkMy5ldmVudC5hY3RpdmUpIHtcclxuICAgICAgICAgICAgICAgIGdyYXBoLnNpbXVsYXRpb24uYWxwaGFUYXJnZXQoMC4zKS5yZXN0YXJ0KCk7XHJcbiAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgIGQzLmV2ZW50Lm9uKCdkcmFnJywgZHJhZ2dlZCkub24oJ2VuZCcsIGVuZGVkKTtcclxuXHJcbiAgICAgICAgICAgIGZ1bmN0aW9uIGRyYWdnZWQoKSB7XHJcbiAgICAgICAgICAgICAgICBub2RlLmZ4ID0gZDMuZXZlbnQueDtcclxuICAgICAgICAgICAgICAgIG5vZGUuZnkgPSBkMy5ldmVudC55O1xyXG4gICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICBmdW5jdGlvbiBlbmRlZCgpIHtcclxuICAgICAgICAgICAgICAgIGlmICghZDMuZXZlbnQuYWN0aXZlKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgZ3JhcGguc2ltdWxhdGlvbi5hbHBoYVRhcmdldCgwKTtcclxuICAgICAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgICAgICBub2RlLmZ4ID0gbnVsbDtcclxuICAgICAgICAgICAgICAgIG5vZGUuZnkgPSBudWxsO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICBkM2VsZW1lbnQuY2FsbChkMy5kcmFnKClcclxuICAgICAgICAgICAgLm9uKCdzdGFydCcsIHN0YXJ0ZWQpKTtcclxuICAgIH1cclxuXHJcbiAgICAvKipcclxuICAgICAqIFtnZXRab29tQ2xhc3MgcmV0dXJucyB0aGUgem9vbSBjbGFzc11cclxuICAgICAqICAgX3N2ZyAgICAgICBbdGhlIG1haW4gc3ZnIGVsZW1lbnRdXHJcbiAgICAgKiAgX2NvbnRhaW5lciBbdGhlIGcgdGFnIHRoYXQgY29udGFpbnMgdGhlIG5vZGVzIGFuZCBsaW5rc11cclxuICAgICAqICAgICAgICAgICAgICAgW3pvb20gY2xhc3MgY29udGFpbnMgZDMgY29kZXMgYW5kIHN0b3JlcyB0aGUgX3N2ZyBhbmQgX2NvbnRhaW5lciB2YXJpYWJsZXMgZm9yIGQzIHpvb21pbmddXHJcbiAgICAgKi9cclxuICAgIHB1YmxpYyBnZXRab29tQ2xhc3MoX3N2ZzogRWxlbWVudFJlZiwgX2NvbnRhaW5lcjogSFRNTEVsZW1lbnQpOiBab29tQ2xhc3Mge1xyXG4gICAgICAgIGNvbnN0IHpvb21DbGFzcyA9IG5ldyBab29tQ2xhc3MoX3N2ZywgX2NvbnRhaW5lcik7XHJcbiAgICAgICAgcmV0dXJuIHpvb21DbGFzcztcclxuICAgIH1cclxuXHJcbiAgICAvKipcclxuICAgICAqIFtnZXRGb3JjZURpcmVjdGVkR3JhcGggVGhlIGludGVyYWN0YWJsZSBncmFwaCB3ZSB3aWxsIHNpbXVsYXRlIGluIHRoaXMgYXJ0aWNsZS4gVGhpcyBtZXRob2QgZG9lcyBub3QgaW50ZXJhY3Qgd2l0aCB0aGUgZG9jdW1lbnQsIHB1cmVseSBwaHlzaWNhbCBjYWxjdWxhdGlvbnMgd2l0aCBkM11cclxuICAgICAqICAgICAgbm9kZXMgICBbZGVzY3JpcHRpb25dXHJcbiAgICAgKiAgICAgIGxpbmtzICAgW2Rlc2NyaXB0aW9uXVxyXG4gICAgICogICAgIG9wdGlvbnMgW2NvbnRhaW5zIGluZm8gb2Ygd2lkdGgsIGhlaWdodCBvZiBtYWluIHN2ZyBjb250YWluZXIgYW5kIGxldmVsUG9zaXRpb25dXHJcbiAgICAgKiAgICAgICAgICBbRm9yY2VEaXJlY3RlZEdyYXBoIGNsYXNzXVxyXG4gICAgICovXHJcbiAgICBwdWJsaWMgZ2V0Rm9yY2VEaXJlY3RlZEdyYXBoKG5vZGVzOiBJTWluZG1hcE5vZGVbXSwgbGlua3M6IElNaW5kbWFwTGlua1tdLCBvcHRpb25zOiBJTWluZG1hcE9wdGlvbnMpOiBGb3JjZURpcmVjdGVkR3JhcGgge1xyXG4gICAgICAgIGNvbnN0IHNnID0gbmV3IEZvcmNlRGlyZWN0ZWRHcmFwaChub2RlcywgbGlua3MsIG9wdGlvbnMpO1xyXG4gICAgICAgIHJldHVybiBzZztcclxuICAgIH1cclxuXHJcbiAgICAvKipcclxuICAgICAqIHRleHRXcmFwIGhhbmRsZXMgdGV4dCB3cmFwcGluZyBpbiBzdmdcclxuICAgICAqICBfdGV4dCAgIHRleHQgdG8gZGlzcGxheVxyXG4gICAgICogICAgIF9jb25maWcgW2Rlc2NyaXB0aW9uXVxyXG4gICAgICogICAgICAgICAgdG90YWwgdGV4dCBoZWlnaHRcclxuICAgICAqL1xyXG4gICAgcHVibGljIHRleHRXcmFwKF90ZXh0OiBzdHJpbmcsIF9jbGFzczogc3RyaW5nLCBfY29uZmlnOiBJSW50ZXJuYWxOb2RlQ29uZmlnKTogbnVtYmVyIHtcclxuICAgICAgICBsZXQgdGV4dEVsZW1lbnQgPSBkMy5zZWxlY3QoJy4nICsgX2NsYXNzLnJlcGxhY2UoLyAvZywgJy4nKSksXHJcbiAgICAgICAgICAgIHdvcmRzID0gX3RleHQuc3BsaXQoJyAnKS5yZXZlcnNlKCksXHJcbiAgICAgICAgICAgIHdvcmQsXHJcbiAgICAgICAgICAgIGxpbmUgPSBbXSxcclxuICAgICAgICAgICAgbGluZU51bWJlciA9IDAsXHJcbiAgICAgICAgICAgIGxpbmVIZWlnaHQgPSBfY29uZmlnLmZvbnRTaXplICsgMiwgLy8gaW4gcHhcclxuICAgICAgICAgICAgeSA9IHRleHRFbGVtZW50LmF0dHIoJ3knKSxcclxuICAgICAgICAgICAgeCA9IHRleHRFbGVtZW50LmF0dHIoJ3gnKSxcclxuICAgICAgICAgICAgZHkgPSBwYXJzZUZsb2F0KHRleHRFbGVtZW50LmF0dHIoJ2R5JykpLFxyXG4gICAgICAgICAgICB0c3BhbiA9IHRleHRFbGVtZW50LnRleHQobnVsbCkuYXBwZW5kKCd0c3BhbicpLmF0dHIoJ3gnLCB4KS5hdHRyKCd5JywgeSkuYXR0cignZHknLCBkeSk7XHJcblxyXG4gICAgICAgIHdoaWxlICh3b3JkID0gd29yZHMucG9wKCkpIHtcclxuICAgICAgICAgICAgbGluZS5wdXNoKHdvcmQpO1xyXG4gICAgICAgICAgICB0c3Bhbi50ZXh0KGxpbmUuam9pbignICcpKTtcclxuICAgICAgICAgICAgaWYgKHRzcGFuLm5vZGUoKS5nZXRDb21wdXRlZFRleHRMZW5ndGgoKSA+IChfY29uZmlnLndpZHRoIC0gMiAqIF9jb25maWcudGV4dFBhZGRpbmcpKSB7XHJcbiAgICAgICAgICAgICAgICBsaW5lLnBvcCgpO1xyXG4gICAgICAgICAgICAgICAgdHNwYW4udGV4dChsaW5lLmpvaW4oJyAnKSk7XHJcbiAgICAgICAgICAgICAgICBsaW5lID0gW3dvcmRdO1xyXG4gICAgICAgICAgICAgICAgdHNwYW4gPSB0ZXh0RWxlbWVudC5hcHBlbmQoJ3RzcGFuJylcclxuICAgICAgICAgICAgICAgICAgICAuYXR0cigneCcsIHgpXHJcbiAgICAgICAgICAgICAgICAgICAgLmF0dHIoJ3knLCB5KVxyXG4gICAgICAgICAgICAgICAgICAgIC5hdHRyKCdkeScsICsrbGluZU51bWJlciAqIGxpbmVIZWlnaHQgKyBkeSlcclxuICAgICAgICAgICAgICAgICAgICAudGV4dCh3b3JkKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgICAgICByZXR1cm4gKGxpbmVOdW1iZXIgKyAxKSAqIGxpbmVIZWlnaHQgKyBkeTtcclxuICAgIH1cclxuXHJcbiAgICAvKipcclxuICAgICAqIFtzZXQgaGVpZ2h0IG9mIG5vZGUncyB0aXRsZSB3cmFwcGVyIGFuZCBub2RlIHdyYXBwZXIncyBoZWlnaHQuXHJcbiAgICAgKiAgTm90ZTogdGl0bGUncyBoZWlnaHQgaGF2ZSB0byBiZSBjYWxjdWxhdGVkIGFuZCB1cGRhdGVkIHRvIGh0bWwgZmlyc3RcclxuICAgICAqICBiZWZvcmUgYXBwZW5kaW5nIHRoZSBkZXNjcmlwdGlvbiB0ZXh0XVxyXG4gICAgICogIF9jb25maWcgW25vZGUncyBDb25maWddXHJcbiAgICAgKiAgICAgICAgICAgICAgIF90eXBlICAgW2ZvciB0aXRsZSBvciBub2RlXVxyXG4gICAgICogICAgICAgICAgICAgICAgICAgICAgIFtoZWlnaHQgb2YgdGl0bGUgb3Igbm9kZV1cclxuICAgICAqL1xyXG4gICAgcHVibGljIHNldFNWR0NvbnRhaW5lckhlaWdodChfY29uZmlnOiBJSW50ZXJuYWxOb2RlQ29uZmlnLCBfdHlwZTogc3RyaW5nKTogbnVtYmVyIHtcclxuICAgICAgICBpZiAoX3R5cGUgPT09ICd0aXRsZScpIHtcclxuICAgICAgICAgICAgcmV0dXJuIF9jb25maWcudGl0bGUudGV4dEhlaWdodCArIF9jb25maWcudGl0bGUucGFkZGluZ1RvcCArIF9jb25maWcudGl0bGUucGFkZGluZ0JvdHRvbTtcclxuICAgICAgICB9XHJcbiAgICAgICAgaWYgKF90eXBlID09PSAnbm9kZScpIHtcclxuICAgICAgICAgICAgcmV0dXJuIF9jb25maWcuZGVzY3JpcHRpb24udGV4dEhlaWdodCArIF9jb25maWcudGl0bGUuaGVpZ2h0ICsgX2NvbmZpZy5pY29uLnNpemUgKyBfY29uZmlnLmljb24ubWFyZ2luQm90dG9tICsgX2NvbmZpZy5pY29uLm1hcmdpblRvcCArIF9jb25maWcuZGVzY3JpcHRpb24ubWFyZ2luQm90dG9tICsgX2NvbmZpZy5kZXNjcmlwdGlvbi5tYXJnaW5Ub3A7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIC8qKlxyXG4gICAgICogW3NldERhdGEgYXBwZW5kaW5nIGluZGV4LCBwdXNoaW5nIG5vZGVzIHRvIEFycmF5IGZvciBkMywgY2FsbGluZyByZWN1cnNpdmUgbG9vcCB0aGlzLl9zZXRMaW5rc0FuZExldmVsXVxyXG4gICAgICogfSBfbm9kZXMgW2Rlc2NyaXB0aW9uXVxyXG4gICAgICogICBbaGVpZ2h0IG9mIHRpdGxlIG9yIG5vZGVdXHJcbiAgICAgKi9cclxuICAgIHB1YmxpYyBzZXREYXRhKF9ub2RlczogeyBba2V5OiBzdHJpbmddOiBJTWluZG1hcE5vZGUgfSk6IHtcclxuICAgICAgICBub2RlczogQXJyYXk8SU1pbmRtYXBOb2RlPixcclxuICAgICAgICBsaW5rczogQXJyYXk8SU1pbmRtYXBMaW5rPixcclxuICAgICAgICBoaWdoZXN0Q291bnQ6IG51bWJlcixcclxuICAgICAgICBoYXZlTG9uZXI6IGJvb2xlYW5cclxuICAgIH0ge1xyXG4gICAgICAgIHRoaXMuX25vZGVzT2JqID0ge307XHJcbiAgICAgICAgbGV0IG5ld05vZGVzID0gW10sIGluZGV4ID0gMCwgaGF2ZUxvbmVyID0gZmFsc2U7XHJcblxyXG4gICAgICAgIC8vIGFwcGVuZGluZyBhIG5ldyBrZXkgY2FsbGVkIGluZGV4IHRvIGVhY2ggbm9kZS5cclxuICAgICAgICAvLyBkMyB2NCByZXF1aXJlcyBsaW5rIHNvdXJjZSBhbmQgdGFyZ2V0IHRvIHBvaW50IHRvIGluZGV4IG9mIG5vZGUgaW4gbm9kZUFyci5cclxuICAgICAgICAvLyBIZW5jZSB0aGUgYmVsb3cgZm9yIGxvb3Agd2lsbCAoMSkgY3JlYXRlIGEgY2xlYW4gY29weSBvZiBvYmplY3QgKDIpIGFwcGVuZCBpbmRleCB0byBlYWNoIG5vZGVcclxuICAgICAgICBmb3IgKGxldCBrZXkgaW4gX25vZGVzKSB7XHJcbiAgICAgICAgICAgIGlmIChfbm9kZXMuaGFzT3duUHJvcGVydHkoa2V5KSkge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5fbm9kZXNPYmpba2V5XSA9IE9iamVjdC5hc3NpZ24oe30sIF9ub2Rlc1trZXldKTtcclxuICAgICAgICAgICAgICAgIHRoaXMuX25vZGVzT2JqW2tleV0uaW5kZXggPSBpbmRleDtcclxuICAgICAgICAgICAgICAgIG5ld05vZGVzLnB1c2godGhpcy5fbm9kZXNPYmpba2V5XSk7XHJcbiAgICAgICAgICAgICAgICBpbmRleCsrO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICAvLyB0aGlzIGZvciBsb29wIHdpbGwgbG9vayBmb3IgT05MWSBub2RlcyB0aGF0IGhhdmUgbm8gcGFyZW50cyAoaWUuIGFuY2VzdG9yIG5vZGVzIGFuZCBsb25lciBub2RlcylcclxuICAgICAgICAvLyB1c2luZyB0aGVzZSBub2RlcyBhcyBzdGFydGluZyBwb2ludHMsIHdlIHN0YXJ0ICd3YWxraW5nIHRoZSBicmFuY2gnIHZpYSB0aGlzLl9zZXRMaW5rc0FuZExldmVsIHRvIHVwZGF0ZSB0aGUgbGlua3Mgd2l0aCB0aGUgcmVsYXRpb25zaGlwcyBvZiB0aGUgbm9kZXNcclxuICAgICAgICAvLyBhdCB0aGlzIHN0YWdlLCBpbmRleCBvZiBhbGwgbm9kZXMgbXVzdCBiZSBkZWZpbmVkIHdpdGhpbiB0aGUgbm9kZSBvYmogc28gdGhhdCB0aGUgbGlua3MgY2FuIGJlIHNldCB1cCBjb3JyZWN0bHlcclxuICAgICAgICBmb3IgKGxldCBrZXkgaW4gdGhpcy5fbm9kZXNPYmopIHtcclxuICAgICAgICAgICAgaWYgKHR5cGVvZiB0aGlzLl9ub2Rlc09ialtrZXldLnBhcmVudHMgPT09ICd1bmRlZmluZWQnIHx8IHRoaXMuX25vZGVzT2JqW2tleV0ucGFyZW50cy5sZW5ndGggPT09IDApIHtcclxuICAgICAgICAgICAgICAgIHRoaXMuX3NldExpbmtzQW5kTGV2ZWwodGhpcy5fbm9kZXNPYmpba2V5XSwga2V5KTtcclxuXHJcbiAgICAgICAgICAgICAgICAvLyB0aGlzLl9zZXRMaW5rc0FuZExldmVsIGRpZCBub3Qgc2V0IGxldmVsIG9mIHRoZXNlIHN0YXJ0aW5nIG5vZGVzXHJcbiAgICAgICAgICAgICAgICAvLyBtYW51YWxseSBzZXR0aW5nIHRoZWlyIGxldmVscyBub3dcclxuICAgICAgICAgICAgICAgIHRoaXMuX25vZGVzT2JqW2tleV0ubGV2ZWwgPSAxO1xyXG4gICAgICAgICAgICAgICAgaWYgKHR5cGVvZiB0aGlzLl9ub2Rlc09ialtrZXldLmNoaWxkcyA9PT0gJ3VuZGVmaW5lZCcgfHwgdGhpcy5fbm9kZXNPYmpba2V5XS5jaGlsZHMubGVuZ3RoID09PSAwKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5fbm9kZXNPYmpba2V5XS5sZXZlbCA9IDA7XHJcbiAgICAgICAgICAgICAgICAgICAgaGF2ZUxvbmVyID0gdHJ1ZTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgcmV0dXJuIHtcclxuICAgICAgICAgICAgbm9kZXM6IG5ld05vZGVzLFxyXG4gICAgICAgICAgICBsaW5rczogdGhpcy5fbmV3TGlua3MsXHJcbiAgICAgICAgICAgIGhpZ2hlc3RDb3VudDogdGhpcy5fZGF0YU1lc3NhZ2luZ0luZm8uaGlnaGVzdENvdW50LFxyXG4gICAgICAgICAgICBoYXZlTG9uZXI6IGhhdmVMb25lclxyXG4gICAgICAgIH07XHJcbiAgICB9XHJcblxyXG4gICAgLyoqXHJcbiAgICAgKiBbc2V0Rnggd2lsbCBzZXQgZnggY29vcmRpbmF0ZSBvZiBlYWNoIG5vZGVdXHJcbiAgICAgKiAgICAgICAgIF9ub2Rlc1xyXG4gICAgICogfSAgIHBvc2l0aW9uICAgICAgW2Z4IGNvb3JkaW5hdGUgb2YgZWFjaCBsZXZlbF1cclxuICAgICAqICAgICAgICAgICAgICAgICAgICBfaGF2ZUxvbmVyICAgICBbd2hldGhlciB0aGVyZSBleGlzdCBsb25lciBpbiB0aGUgZ3JhcGhdXHJcbiAgICAgKiAgICAgICAgX25vZGVzICAgICAgICBbbm9kZXMgd2l0aCBmeCB2YWx1ZV1cclxuICAgICAqL1xyXG4gICAgcHVibGljIHNldEZ4KF9ub2RlczogQXJyYXk8SU1pbmRtYXBOb2RlPiwgX3Bvc2l0aW9uOiB7IFtrZXk6IHN0cmluZ106IG51bWJlciB9LCBfaGF2ZUxvbmVyOiBib29sZWFuKTogQXJyYXk8SU1pbmRtYXBOb2RlPiB7XHJcbiAgICAgICAgZm9yIChsZXQgaSA9IDA7IGkgPCBfbm9kZXMubGVuZ3RoOyArK2kpIHtcclxuICAgICAgICAgICAgX25vZGVzW2ldLmZ4ID0gX2hhdmVMb25lciA/IF9wb3NpdGlvbltfbm9kZXNbaV0ubGV2ZWxdIDogX3Bvc2l0aW9uW19ub2Rlc1tpXS5sZXZlbCAtIDFdO1xyXG4gICAgICAgIH1cclxuICAgICAgICByZXR1cm4gX25vZGVzO1xyXG4gICAgfVxyXG5cclxuICAgIC8qKlxyXG4gICAgICogW3RyYW5zbGF0ZVN2Z1RvWFBvcyB0cmFuc2xhdGUgbm9kZSB0byBjZW50ZXIsIHJpZ2h0IGVkZ2Ugb3IgbGVmdCBlZGdlIG9mIG1haW4gc3ZnIGNvbnRhaW5lcl1cclxuICAgICAqIH0gICBfY29uZmlnICAgICAgW3dpZHRocyBvZiBtYWluIHN2Zywgbm9kZSBhbmQgcGFkZGluZ11cclxuICAgICAqICBfbm9kZVRvRm9jdXNcclxuICAgICAqICBfcGxhY2VtZW50XHJcbiAgICAgKiAgICAgICAgICAgICAgICAgICAgIFt4LWNvb3JkaW5hdGUgZm9yIF1cclxuICAgICAqL1xyXG4gICAgcHVibGljIHRyYW5zbGF0ZVN2Z1RvWFBvcyhfY29uZmlnOiB7IHN2Z1dpZHRoOiBudW1iZXIsIG5vZGVXaWR0aDogbnVtYmVyLCBwYWRkaW5nOiBudW1iZXIgfSwgX25vZGVUb0ZvY3VzOiBJTWluZG1hcE5vZGUsIF9wbGFjZW1lbnQ6ICdjZW50ZXInIHwgJ3JpZ2h0JyB8ICdsZWZ0Jyk6IG51bWJlciB7XHJcbiAgICAgICAgbGV0IHhQb3M6IG51bWJlciA9IDA7XHJcbiAgICAgICAgaWYgKF9wbGFjZW1lbnQgPT09ICdyaWdodCcpIHtcclxuICAgICAgICAgICAgeFBvcyA9IF9jb25maWcuc3ZnV2lkdGg7XHJcbiAgICAgICAgICAgIHJldHVybiB4UG9zIC0gX25vZGVUb0ZvY3VzLmZ4IC0gX2NvbmZpZy5ub2RlV2lkdGggLyAyIC0gX2NvbmZpZy5wYWRkaW5nO1xyXG4gICAgICAgIH1cclxuICAgICAgICBpZiAoX3BsYWNlbWVudCA9PT0gJ2NlbnRlcicpIHtcclxuICAgICAgICAgICAgeFBvcyA9IF9jb25maWcuc3ZnV2lkdGggLyAyO1xyXG4gICAgICAgICAgICByZXR1cm4geFBvcyAtIF9ub2RlVG9Gb2N1cy5meDtcclxuICAgICAgICB9XHJcbiAgICAgICAgaWYgKF9wbGFjZW1lbnQgPT09ICdsZWZ0Jykge1xyXG4gICAgICAgICAgICByZXR1cm4gLSBfbm9kZVRvRm9jdXMuZnggKyBfY29uZmlnLm5vZGVXaWR0aCAvIDIgKyBfY29uZmlnLnBhZGRpbmc7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIC8qKlxyXG4gICAgICogW3NldExpbmtTcHJlYWREaXN0YW5jZSBjYWxjdWxhdGUgb2Zmc2V0IG5lZWRlZCBmb3IgbGlua3MgdG8gc3ByZWFkIGV2ZW5seSBhY3Jvc3MgaGVpZ2h0IG9mIG5vZGVdXHJcbiAgICAgKiAgICBfbGlua3NcclxuICAgICAqICBfbm9kZSAgICAgICBbbm9kZSB0aGF0IGhhdmUgZmluaXNoZWQgaGVpZ2h0IGNhbGN1bGF0aW9uLiAodGhlc2Ugbm9kZXMgbXVzdCBoYXZlIHBhcmVudHMpXVxyXG4gICAgICogICAgICAgIF9ub2RlSGVpZ2h0IFtIZWlnaHQgb2Ygbm9kZV1cclxuICAgICAqICAgICAgICAgICAgICAgICAgICAgW3JldHVybiBpbmRleCBvZiBsaW5rIGFuZCBvZmZzZXQgdmFsdWVdXHJcbiAgICAgKi9cclxuICAgIHB1YmxpYyBzZXRMaW5rU3ByZWFkRGlzdGFuY2UoX2xpbmtzOiBBcnJheTxhbnk+LCBfbm9kZTogSU1pbmRtYXBOb2RlLCBfbm9kZUhlaWdodDogbnVtYmVyKTogQXJyYXk8eyBpbmRleD86IG51bWJlciwgb2Zmc2V0PzogbnVtYmVyIH0+IHtcclxuICAgICAgICBsZXQgbm9PZlBhcmVudHM6IG51bWJlciA9IF9ub2RlLnBhcmVudHMubGVuZ3RoO1xyXG4gICAgICAgIGlmIChub09mUGFyZW50cyA9PT0gMSkgcmV0dXJuIFtdO1xyXG4gICAgICAgIGxldCBkaXN0OiBudW1iZXIgPSAoX25vZGVIZWlnaHQgLSAyMCkgLyAobm9PZlBhcmVudHMgLSAxKTtcclxuICAgICAgICBsZXQgYWZmZWN0ZWRMaW5rcyA9IFtdO1xyXG5cclxuICAgICAgICBmb3IgKGxldCBpID0gMDsgaSA8IF9saW5rcy5sZW5ndGg7ICsraSkge1xyXG4gICAgICAgICAgICBpZiAoX2xpbmtzW2ldLnRhcmdldC5pZCA9PT0gX25vZGUuaWQpIHtcclxuICAgICAgICAgICAgICAgIGFmZmVjdGVkTGlua3MucHVzaCh7IGluZGV4OiBfbGlua3NbaV0uaW5kZXggfSk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICAgICAgZm9yIChsZXQgaSA9IDA7IGkgPCBhZmZlY3RlZExpbmtzLmxlbmd0aDsgKytpKSB7XHJcbiAgICAgICAgICAgIGFmZmVjdGVkTGlua3NbaV0ub2Zmc2V0ID0gLV9ub2RlSGVpZ2h0IC8gMiArIGkgKiBkaXN0ICsgMTA7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIHJldHVybiBhZmZlY3RlZExpbmtzO1xyXG4gICAgfVxyXG5cclxuICAgIHB1YmxpYyBmb3VuZFNlbGVjdGVkTm9kZShfbm9kZXM6IElNaW5kbWFwTm9kZVtdLCBfc2VsZWN0T25Mb2FkSWQ6IG51bWJlcikge1xyXG4gICAgICAgIHJldHVybiBfbm9kZXNbX3NlbGVjdE9uTG9hZElkXSAhPT0gbnVsbCAmJiBfbm9kZXNbX3NlbGVjdE9uTG9hZElkXSAhPT0gdW5kZWZpbmVkO1xyXG4gICAgfVxyXG5cclxuICAgIC8qKlxyXG4gICAgICogW19zZXRMaW5rc0FuZExldmVsIGlzIHRvIGdlbmVyYXRlIHRoZSBsZXZlbCwgbGV2ZWwncyByZWNvcmQgaGlnaGVzdENvdW50LCBsaW5rcyBBcnJheSwgcGFyZW50cyBhcnJheV1cclxuICAgICAqICBfbm9kZSBbT2JqZWN0IGNvbnRhaW5pbmcgYWxsIGluZm8gb2YgYSBub2RlLCB0byBiZSBwYXNzZWQgdG8gY29tcG9uZW50IGtkLW1pbmRtYXAtbm9kZV1cclxuICAgICAqICAgICAgICBrZXkgICBba2V5IG9mIHRoZSBub2RlIG9iamVjdCBpbiB0aGUgbWFzdGVyIG9iamVjdF1cclxuICAgICAqL1xyXG4gICAgcHJpdmF0ZSBfc2V0TGlua3NBbmRMZXZlbChfbm9kZTogSU1pbmRtYXBOb2RlLCBrZXk6IHN0cmluZyk6IHZvaWQge1xyXG4gICAgICAgIC8vIGlmIG5vZGUgaGF2ZSBubyBjaGlsZCwgZG8gbm90IHJ1biB0aGUgZm9sbG93aW5nXHJcbiAgICAgICAgaWYgKCFfbm9kZS5jaGlsZHMgfHwgX25vZGUuY2hpbGRzLmxlbmd0aCA9PT0gMCkgcmV0dXJuO1xyXG4gICAgICAgIHRoaXMuX2RhdGFNZXNzYWdpbmdJbmZvLmNvdW50Kys7XHJcblxyXG4gICAgICAgIGZvciAobGV0IGkgPSAwOyBpIDwgX25vZGUuY2hpbGRzLmxlbmd0aDsgaSsrKSB7XHJcblxyXG4gICAgICAgICAgICBsZXQgbGlua1N0cmluZzogc3RyaW5nID0gJygnICsga2V5ICsgJywnICsgX25vZGUuY2hpbGRzW2ldICsgJyknO1xyXG4gICAgICAgICAgICBpZiAoIXRoaXMuX2RhdGFNZXNzYWdpbmdJbmZvLmxpbmtzU3RvcmVkLmhhc093blByb3BlcnR5KGxpbmtTdHJpbmcpKSB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLl9kYXRhTWVzc2FnaW5nSW5mby5saW5rc1N0b3JlZFtsaW5rU3RyaW5nXSA9ICcnO1xyXG4gICAgICAgICAgICAgICAgdGhpcy5fbmV3TGlua3MucHVzaCh7IHNvdXJjZTogX25vZGUuaW5kZXgsIHRhcmdldDogdGhpcy5fbm9kZXNPYmpbX25vZGUuY2hpbGRzW2ldXS5pbmRleCB9KTtcclxuICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgaWYgKHRoaXMuX25vZGVzT2JqW19ub2RlLmNoaWxkc1tpXV0ubGV2ZWwgPiB0aGlzLl9kYXRhTWVzc2FnaW5nSW5mby5jb3VudCkgY29udGludWU7XHJcblxyXG4gICAgICAgICAgICBpZiAodGhpcy5fZGF0YU1lc3NhZ2luZ0luZm8uY291bnQgPT09IDEpIHtcclxuICAgICAgICAgICAgICAgIHRoaXMuX25vZGVzT2JqW19ub2RlLmNoaWxkc1tpXV0ubGV2ZWwgPSBfbm9kZS5sZXZlbCArIDEgfHwgMjtcclxuICAgICAgICAgICAgICAgIHRoaXMuX2RhdGFNZXNzYWdpbmdJbmZvLmNvdW50ID0gX25vZGUubGV2ZWwgKyAxIHx8IDI7XHJcbiAgICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLl9ub2Rlc09ialtfbm9kZS5jaGlsZHNbaV1dLmxldmVsID0gdGhpcy5fZGF0YU1lc3NhZ2luZ0luZm8uY291bnQ7XHJcbiAgICAgICAgICAgICAgICBpZiAodGhpcy5fZGF0YU1lc3NhZ2luZ0luZm8uaGlnaGVzdENvdW50IDwgdGhpcy5fZGF0YU1lc3NhZ2luZ0luZm8uY291bnQpIHtcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLl9kYXRhTWVzc2FnaW5nSW5mby5oaWdoZXN0Q291bnQgPSB0aGlzLl9kYXRhTWVzc2FnaW5nSW5mby5jb3VudDtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgLy8gaWYgbm9kZSBoYXZlIGdyYW5kY2hpbGQsIGNvbnRpbnVlIHRoZSBsb29wIGFuZCBzZXQgbm9kZSBvZiBuZXh0IGN5Y2xlIHRvIGJlIGN1cnJlbnQgbm9kZSdzIGNoaWxkXHJcbiAgICAgICAgICAgIHRoaXMuX3NldExpbmtzQW5kTGV2ZWwodGhpcy5fbm9kZXNPYmpbX25vZGUuY2hpbGRzW2ldXSwgX25vZGUuY2hpbGRzW2ldKTtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIHRoaXMuX2RhdGFNZXNzYWdpbmdJbmZvLmNvdW50ID0gMTtcclxuICAgIH1cclxufVxyXG4iXX0=