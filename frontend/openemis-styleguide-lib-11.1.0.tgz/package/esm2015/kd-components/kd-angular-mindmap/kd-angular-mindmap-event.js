import { Injectable } from '@angular/core';
import { KdBroadcaster, } from '../kd-common/index';
import * as i0 from "@angular/core";
import * as i1 from "../kd-common/kd-broadcaster-svc";
export class KdMindmapEvent {
    constructor(_broadcaster) {
        this._broadcaster = _broadcaster;
    }
    nodeSelected(_mindmapId, _selectedNode) {
        this._broadcaster.broadcast(_mindmapId + 'kdMindmapNodeClicked', _selectedNode);
    }
    onNodeSelected(_mindmapId) {
        return this._broadcaster.on(_mindmapId + 'kdMindmapNodeClicked');
    }
}
KdMindmapEvent.ɵprov = i0.ɵɵdefineInjectable({ factory: function KdMindmapEvent_Factory() { return new KdMindmapEvent(i0.ɵɵinject(i1.KdBroadcaster)); }, token: KdMindmapEvent, providedIn: "root" });
KdMindmapEvent.decorators = [
    { type: Injectable, args: [{
                providedIn: 'root'
            },] }
];
KdMindmapEvent.ctorParameters = () => [
    { type: KdBroadcaster }
];
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoia2QtYW5ndWxhci1taW5kbWFwLWV2ZW50LmpzIiwic291cmNlUm9vdCI6IkM6L1Byb2plY3RzL0FuZ3VsYXIvaW9zdGctb3BlbmVtaXMtc3R5bGVndWlkZS9wcm9qZWN0cy9vcGVuZW1pcy1zdHlsZWd1aWRlLWxpYi9zcmMvIiwic291cmNlcyI6WyJrZC1jb21wb25lbnRzL2tkLWFuZ3VsYXItbWluZG1hcC9rZC1hbmd1bGFyLW1pbmRtYXAtZXZlbnQudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsT0FBTyxFQUFFLFVBQVUsRUFBRSxNQUFNLGVBQWUsQ0FBQztBQUczQyxPQUFPLEVBQUUsYUFBYSxHQUFHLE1BQU0sb0JBQW9CLENBQUM7OztBQUtwRCxNQUFNLE9BQU8sY0FBYztJQUV2QixZQUFvQixZQUEyQjtRQUEzQixpQkFBWSxHQUFaLFlBQVksQ0FBZTtJQUFJLENBQUM7SUFFN0MsWUFBWSxDQUFDLFVBQWtCLEVBQUUsYUFBNEI7UUFDaEUsSUFBSSxDQUFDLFlBQVksQ0FBQyxTQUFTLENBQUMsVUFBVSxHQUFHLHNCQUFzQixFQUFFLGFBQWEsQ0FBQyxDQUFDO0lBQ3BGLENBQUM7SUFFTSxjQUFjLENBQUMsVUFBa0I7UUFDcEMsT0FBTyxJQUFJLENBQUMsWUFBWSxDQUFDLEVBQUUsQ0FBTSxVQUFVLEdBQUcsc0JBQXNCLENBQUMsQ0FBQztJQUMxRSxDQUFDOzs7O1lBYkosVUFBVSxTQUFDO2dCQUNSLFVBQVUsRUFBRSxNQUFNO2FBQ3JCOzs7WUFKUSxhQUFhIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgSW5qZWN0YWJsZSB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xyXG5pbXBvcnQgeyBPYnNlcnZhYmxlIH0gZnJvbSAncnhqcyc7XHJcbmltcG9ydCB7IElNaW5kbWFwTm9kZSB9IGZyb20gJy4va2QtYW5ndWxhci1taW5kbWFwLWludGVyZmFjZSc7XHJcbmltcG9ydCB7IEtkQnJvYWRjYXN0ZXIsIH0gZnJvbSAnLi4va2QtY29tbW9uL2luZGV4JztcclxuXHJcbkBJbmplY3RhYmxlKHtcclxuICAgIHByb3ZpZGVkSW46ICdyb290J1xyXG59KVxyXG5leHBvcnQgY2xhc3MgS2RNaW5kbWFwRXZlbnQge1xyXG5cclxuICAgIGNvbnN0cnVjdG9yKHByaXZhdGUgX2Jyb2FkY2FzdGVyOiBLZEJyb2FkY2FzdGVyKSB7IH1cclxuXHJcbiAgICBwdWJsaWMgbm9kZVNlbGVjdGVkKF9taW5kbWFwSWQ6IHN0cmluZywgX3NlbGVjdGVkTm9kZT86IElNaW5kbWFwTm9kZSk6IHZvaWQge1xyXG4gICAgICAgIHRoaXMuX2Jyb2FkY2FzdGVyLmJyb2FkY2FzdChfbWluZG1hcElkICsgJ2tkTWluZG1hcE5vZGVDbGlja2VkJywgX3NlbGVjdGVkTm9kZSk7XHJcbiAgICB9XHJcblxyXG4gICAgcHVibGljIG9uTm9kZVNlbGVjdGVkKF9taW5kbWFwSWQ6IHN0cmluZyk6IE9ic2VydmFibGU8YW55PiB7XHJcbiAgICAgICAgcmV0dXJuIHRoaXMuX2Jyb2FkY2FzdGVyLm9uPGFueT4oX21pbmRtYXBJZCArICdrZE1pbmRtYXBOb2RlQ2xpY2tlZCcpO1xyXG4gICAgfVxyXG59XHJcblxyXG4iXX0=