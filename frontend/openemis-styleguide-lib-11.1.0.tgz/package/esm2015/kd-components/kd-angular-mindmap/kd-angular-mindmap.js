import { Component, ViewEncapsulation, Input, Output, ChangeDetectorRef, ElementRef, ChangeDetectionStrategy, EventEmitter } from '@angular/core';
import { KdDataSvc } from '../kd-common/index';
import { KdMindmapSvc } from './kd-angular-mindmap-svc';
import { defaultConfig } from './kd-angular-mindmap-config';
export class KdMindmap {
    constructor(_mindmapSvc, _dataSvc, _elemRef, _ref) {
        this._mindmapSvc = _mindmapSvc;
        this._dataSvc = _dataSvc;
        this._elemRef = _elemRef;
        this._ref = _ref;
        this.internalApi = {};
        this.internalLinkApiRef = {};
        this.displayGraph = true;
        this.linkClass = '';
        this.options = { width: 0, height: 600, levelPosition: { '0': 10 } };
        this.showLoader = true;
        this.smallLoaderValue = null;
        this.buttonConfig = {
            coord: { x: 25, y: 25 },
            size: 30,
            iconSize: 20,
            marginBottom: 10,
        };
        this._simulationEnd = false;
        this._translationEnd = false;
        this._hasSelectedNode = false;
        this.selectedNodeEmitter = new EventEmitter();
    }
    ngOnInit() {
        this._setConfig(this.mainConfig);
        this._initApi();
        this._initInternalApi();
        if (typeof this.inputNodes === 'undefined' || Object.keys(this.inputNodes).length === 0) {
            this.displayGraph = false;
            return;
        }
        this._startSetDataAndGraph();
    }
    ngOnChanges(_simpleChanges) {
        if (_simpleChanges.hasOwnProperty('mainConfig') && !_simpleChanges['mainConfig'].firstChange) {
            this._setConfig(this.mainConfig);
        }
        if (_simpleChanges.hasOwnProperty('inputNodes') && !_simpleChanges['inputNodes'].firstChange && Object.keys(this.inputNodes).length !== 0) {
            if (!this.displayGraph)
                this.displayGraph = true;
            this._startSetDataAndGraph();
            this._graph.initSimulation(this.options);
            if (this._hasSelectedNode) {
                if (this.internalApi.hasOwnProperty('translate'))
                    this._setInitPosX();
                else
                    setTimeout(() => this._setInitPosX());
            }
        }
    }
    ngAfterViewInit() {
        if (typeof this.inputNodes === 'undefined' || Object.keys(this.inputNodes).length === 0)
            return;
        this._graph.initSimulation(this.options);
        if (this._hasSelectedNode)
            setTimeout(() => this._setInitPosX());
    }
    outputSelectedNode(_selectedNode) {
        this.selectedNodeEmitter.emit(_selectedNode);
    }
    _initApi() {
        if (typeof this.api !== 'undefined') {
            this.api.zoom = (_action) => this.internalApi.zoom(_action);
        }
    }
    _initInternalApi() {
        if (typeof this.internalApi !== 'undefined') {
            this.internalApi.setNodeHeight = (_node, _nodeHeight) => {
                let affectedLinks = this._mindmapSvc.setLinkSpreadDistance(this.links, _node, _nodeHeight);
                for (let i = 0; i < affectedLinks.length; ++i) {
                    this.internalApi.accessInternalLinkApi(affectedLinks[i].index.toString()).setLinkOffset(affectedLinks[i].offset);
                }
            };
            this.internalApi.accessInternalLinkApi = (_key) => this.internalLinkApiRef[_key];
        }
    }
    _setConfig(_config) {
        this.config = this._dataSvc.deepMergeObject(defaultConfig, this.mainConfig);
        this.config.node.width = this.config.node.width || 200;
        if (this.config.link.class)
            this.linkClass = this.config.link.class;
        this.buttonConfig.iconLinkPath = this.config.iconLinkPath;
        this.config.node.icon.link = this.config.iconLinkPath;
        if (this.config.node.selectOnLoadId && typeof this.config.node.selectOnLoadId === 'number')
            this._hasSelectedNode = true;
    }
    _startSetDataAndGraph() {
        this._setDataAndOptions(this.inputNodes);
        this._hasSelectedNode = this._hasSelectedNode && this._mindmapSvc.foundSelectedNode(this.nodes, this.config.node.selectOnLoadId);
        /** Receiving an initialized simulated graph from our custom d3 service */
        this._graph = this._mindmapSvc.getForceDirectedGraph(this.nodes, this.links, this.options);
        /** Binding change detection check on each tick
         * This along with an onPush change detection strategy should enforce checking only when relevant!
         * This improves scripting computation duration in a couple of tests I've made, consistently.
         * Also, it makes sense to avoid unnecessary checks when we are dealing only with simulations data binding.
         */
        this._graph.ticker.subscribe((d) => {
            this._ref.markForCheck();
        });
        this._graph.onSimulationEnd.subscribe((_flag) => {
            this.onSimulationEnd();
        });
    }
    _setDataAndOptions(_inputNodes) {
        let newData;
        newData = this._mindmapSvc.setData(_inputNodes);
        this.highestCount = newData.highestCount;
        this.links = newData.links;
        this.options.width = this._calculateWidth();
        this.options.levelPosition = this._calculateLevelPosition();
        this.nodes = this._mindmapSvc.setFx(newData.nodes, this.options.levelPosition, newData.haveLoner);
    }
    _calculateWidth() {
        return (this.config.levelRightMargin + this.config.node.width) * this.highestCount + this.config.node.width + 2 * this.config.padding;
    }
    _calculateLevelPosition() {
        let position = {};
        for (let i = 0; i < this.highestCount + 1; ++i) {
            position[i.toString()] = i * (this.config.node.width + this.config.levelRightMargin) + this.config.padding + this.config.node.width / 2;
        }
        return position;
    }
    /* _setInitPosX sometimes needs setTimeout for 2 reasons:
    * 1) on first load, getBoundingClientRect is not ready
    * 2) on subsequent load, need to make sure internalApi.translate is present (may not be present becos displayGraph was set to false)
    */
    _setInitPosX() {
        let config = {
            svgWidth: this._elemRef.nativeElement.querySelector('.kdx-mindmap #kdx-mindmap-wrapper').getBoundingClientRect().width,
            nodeWidth: this.config.node.width,
            padding: this.config.padding
        };
        let _initPosX = this._mindmapSvc.translateSvgToXPos(config, this.nodes[this.mainConfig.node.selectOnLoadId], 'right');
        this.internalApi.translate(_initPosX).on('end', () => this.onTranslationEnd());
    }
    onSimulationEnd() {
        this._simulationEnd = true;
        if (this._translationEnd || !this._hasSelectedNode)
            this.showLoader = false;
    }
    onTranslationEnd() {
        this._translationEnd = true;
        if (this._simulationEnd)
            this.showLoader = false;
    }
}
KdMindmap.decorators = [
    { type: Component, args: [{
                selector: 'kd-mindmap',
                template: "<div class=\"kdx-mindmap-outer-wrapper\">\r\n    <svg #svg id=\"kdx-mindmap-wrapper\" [attr.width]=\"config.width\" [attr.height]=\"config.height\">\r\n        <svg:defs>\r\n            <svg:marker id=\"arrowEnd\" viewBox=\"0 0 10 10\" refX=\"9\" refY=\"5\"\r\n                markerWidth=\"10\" markerHeight=\"10\" orient=\"auto\" [attr.class]=\"linkClass\">\r\n                <path d=\"M 0 0 L 10 5 L 0 10 z\" />\r\n            </svg:marker>\r\n            <svg:marker id=\"arrowStart\" viewBox=\"0 0 10 10\" refX=\"1\" refY=\"5\"\r\n                markerWidth=\"10\" markerHeight=\"10\" orient=\"auto\" [attr.class]=\"linkClass\">\r\n                <svg>\r\n                    <path transform=\"matrix(-1,0,0,1,10,0)\" d=\"M 0 0 L 10 5 L 0 10 z\" />\r\n                </svg>\r\n            </svg:marker>\r\n            <svg:marker id=\"arrowEndActive\" viewBox=\"0 0 10 10\" refX=\"9\" refY=\"5\"\r\n                markerWidth=\"10\" markerHeight=\"10\" orient=\"auto\" [attr.class]=\"config.link.activeClass\">\r\n                <path d=\"M 0 0 L 10 5 L 0 10 z\" />\r\n            </svg:marker>\r\n            <svg:marker id=\"arrowStartActive\" viewBox=\"0 0 10 10\" refX=\"1\" refY=\"5\"\r\n                markerWidth=\"10\" markerHeight=\"10\" orient=\"auto\" [attr.class]=\"config.link.activeClass\">\r\n                <svg>\r\n                    <path transform=\"matrix(-1,0,0,1,10,0)\" d=\"M 0 0 L 10 5 L 0 10 z\" />\r\n                </svg>\r\n            </svg:marker>\r\n        </svg:defs>\r\n        <svg:g class=\"kdx-mindmap-group\" *ngIf=\"displayGraph\" [zoomableOf]=\"svg\" [api]=\"internalApi\">\r\n            <svg:g class=\"kdx-mindmap-link-group\" >\r\n                <svg:g id=\"link\" *ngFor=\"let link of links\" \r\n                    [kdx-mindmap-link]=\"link\"\r\n                    [config]=\"config\" \r\n                    [mindmapId]=\"config.id\"\r\n                    [api]=\"internalLinkApiRef\"></svg:g>\r\n            </svg:g>\r\n            <svg:g class=\"kdx-mindmap-node-group\">\r\n                <svg:g *ngFor=\"let node of nodes\" \r\n                    [kdx-mindmap-node]=\"node\" \r\n                    [config]=\"config.node\" \r\n                    [mindmapId]=\"config.id\"\r\n                    [api]=\"internalApi\"\r\n                    (selectedNodeEmitter)=\"outputSelectedNode($event)\"></svg:g>\r\n            </svg:g>\r\n        </svg:g>\r\n        <svg:g *ngIf=\"config.zoomButton\" [attr.transform]=\"'translate(' + buttonConfig.coord.x + ',' + buttonConfig.coord.y + ')'\">\r\n            <svg:g [zoomButton]=\"'zoom_in'\" [config]=\"buttonConfig\" [api]=\"internalApi\"></svg:g>\r\n            <svg:g [attr.transform]=\"'translate(' + 0 + ',' + (buttonConfig.size + buttonConfig.marginBottom) + ')'\" [zoomButton]=\"'zoom_out'\" [config]=\"buttonConfig\" [api]=\"internalApi\" ></svg:g>\r\n        </svg:g>\r\n        <svg:rect *ngIf=\"config.border\"\r\n            class=\"kdx-mindmap-wrapper-border\"\r\n            x=\"0\"\r\n            y=\"0\"\r\n            rx=\"4\"\r\n            ry=\"4\"\r\n            width=\"100%\"\r\n            height=\"100%\"\r\n        ></svg:rect>\r\n    </svg>\r\n    <kd-progressloader *ngIf=\"showLoader\" configtype=\"small-spinner\" [configvalue]=\"smallLoaderValue\"></kd-progressloader>\r\n</div>\r\n",
                providers: [KdMindmapSvc, KdDataSvc],
                encapsulation: ViewEncapsulation.None,
                changeDetection: ChangeDetectionStrategy.OnPush,
                host: {
                    'class': 'kdx-mindmap',
                    '[attr.id]': 'config.id',
                }
            },] }
];
KdMindmap.ctorParameters = () => [
    { type: KdMindmapSvc },
    { type: KdDataSvc },
    { type: ElementRef },
    { type: ChangeDetectorRef }
];
KdMindmap.propDecorators = {
    inputNodes: [{ type: Input, args: ['nodes',] }],
    mainConfig: [{ type: Input, args: ['config',] }],
    api: [{ type: Input }],
    selectedNodeEmitter: [{ type: Output }]
};
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoia2QtYW5ndWxhci1taW5kbWFwLmpzIiwic291cmNlUm9vdCI6IkM6L1Byb2plY3RzL0FuZ3VsYXIvaW9zdGctb3BlbmVtaXMtc3R5bGVndWlkZS9wcm9qZWN0cy9vcGVuZW1pcy1zdHlsZWd1aWRlLWxpYi9zcmMvIiwic291cmNlcyI6WyJrZC1jb21wb25lbnRzL2tkLWFuZ3VsYXItbWluZG1hcC9rZC1hbmd1bGFyLW1pbmRtYXAudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsT0FBTyxFQUNILFNBQVMsRUFDVCxpQkFBaUIsRUFDakIsS0FBSyxFQUNMLE1BQU0sRUFJTixpQkFBaUIsRUFDakIsVUFBVSxFQUNWLHVCQUF1QixFQUN2QixZQUFZLEVBQ2YsTUFBTSxlQUFlLENBQUM7QUFDdkIsT0FBTyxFQUFFLFNBQVMsRUFBRSxNQUFNLG9CQUFvQixDQUFDO0FBRS9DLE9BQU8sRUFBRSxZQUFZLEVBQUUsTUFBTSwwQkFBMEIsQ0FBQztBQVl4RCxPQUFPLEVBQUUsYUFBYSxFQUFFLE1BQU0sNkJBQTZCLENBQUM7QUFjNUQsTUFBTSxPQUFPLFNBQVM7SUE2QmxCLFlBQ1ksV0FBeUIsRUFDekIsUUFBbUIsRUFDbkIsUUFBb0IsRUFDcEIsSUFBdUI7UUFIdkIsZ0JBQVcsR0FBWCxXQUFXLENBQWM7UUFDekIsYUFBUSxHQUFSLFFBQVEsQ0FBVztRQUNuQixhQUFRLEdBQVIsUUFBUSxDQUFZO1FBQ3BCLFNBQUksR0FBSixJQUFJLENBQW1CO1FBNUI1QixnQkFBVyxHQUF3QixFQUFFLENBQUM7UUFDdEMsdUJBQWtCLEdBQStCLEVBQUUsQ0FBQztRQUNwRCxpQkFBWSxHQUFZLElBQUksQ0FBQztRQUM3QixjQUFTLEdBQVcsRUFBRSxDQUFDO1FBQ3ZCLFlBQU8sR0FBb0IsRUFBRSxLQUFLLEVBQUUsQ0FBQyxFQUFFLE1BQU0sRUFBRSxHQUFHLEVBQUUsYUFBYSxFQUFFLEVBQUUsR0FBRyxFQUFFLEVBQUUsRUFBRSxFQUFFLENBQUM7UUFDakYsZUFBVSxHQUFZLElBQUksQ0FBQztRQUMzQixxQkFBZ0IsR0FBUSxJQUFJLENBQUM7UUFFN0IsaUJBQVksR0FBc0I7WUFDckMsS0FBSyxFQUFFLEVBQUUsQ0FBQyxFQUFFLEVBQUUsRUFBRSxDQUFDLEVBQUUsRUFBRSxFQUFFO1lBQ3ZCLElBQUksRUFBRSxFQUFFO1lBQ1IsUUFBUSxFQUFFLEVBQUU7WUFDWixZQUFZLEVBQUUsRUFBRTtTQUNuQixDQUFDO1FBRU0sbUJBQWMsR0FBWSxLQUFLLENBQUM7UUFDaEMsb0JBQWUsR0FBWSxLQUFLLENBQUM7UUFDakMscUJBQWdCLEdBQVksS0FBSyxDQUFDO1FBS2hDLHdCQUFtQixHQUErQixJQUFJLFlBQVksRUFBRSxDQUFDO0lBTzNFLENBQUM7SUFFTCxRQUFRO1FBQ0osSUFBSSxDQUFDLFVBQVUsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLENBQUM7UUFDakMsSUFBSSxDQUFDLFFBQVEsRUFBRSxDQUFDO1FBQ2hCLElBQUksQ0FBQyxnQkFBZ0IsRUFBRSxDQUFDO1FBQ3hCLElBQUksT0FBTyxJQUFJLENBQUMsVUFBVSxLQUFLLFdBQVcsSUFBSSxNQUFNLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsQ0FBQyxNQUFNLEtBQUssQ0FBQyxFQUFFO1lBQ3JGLElBQUksQ0FBQyxZQUFZLEdBQUcsS0FBSyxDQUFDO1lBQzFCLE9BQU87U0FDVjtRQUNELElBQUksQ0FBQyxxQkFBcUIsRUFBRSxDQUFDO0lBQ2pDLENBQUM7SUFFRCxXQUFXLENBQUMsY0FBNkI7UUFDckMsSUFBSSxjQUFjLENBQUMsY0FBYyxDQUFDLFlBQVksQ0FBQyxJQUFJLENBQUMsY0FBYyxDQUFDLFlBQVksQ0FBQyxDQUFDLFdBQVcsRUFBRTtZQUMxRixJQUFJLENBQUMsVUFBVSxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsQ0FBQztTQUNwQztRQUNELElBQUksY0FBYyxDQUFDLGNBQWMsQ0FBQyxZQUFZLENBQUMsSUFBSSxDQUFDLGNBQWMsQ0FBQyxZQUFZLENBQUMsQ0FBQyxXQUFXLElBQUksTUFBTSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLENBQUMsTUFBTSxLQUFLLENBQUMsRUFBRTtZQUN2SSxJQUFJLENBQUMsSUFBSSxDQUFDLFlBQVk7Z0JBQUUsSUFBSSxDQUFDLFlBQVksR0FBRyxJQUFJLENBQUM7WUFDakQsSUFBSSxDQUFDLHFCQUFxQixFQUFFLENBQUM7WUFDN0IsSUFBSSxDQUFDLE1BQU0sQ0FBQyxjQUFjLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxDQUFDO1lBQ3pDLElBQUksSUFBSSxDQUFDLGdCQUFnQixFQUFFO2dCQUN2QixJQUFJLElBQUksQ0FBQyxXQUFXLENBQUMsY0FBYyxDQUFDLFdBQVcsQ0FBQztvQkFBRSxJQUFJLENBQUMsWUFBWSxFQUFFLENBQUM7O29CQUNqRSxVQUFVLENBQUMsR0FBRyxFQUFFLENBQUMsSUFBSSxDQUFDLFlBQVksRUFBRSxDQUFDLENBQUM7YUFDOUM7U0FDSjtJQUNMLENBQUM7SUFFRCxlQUFlO1FBQ1gsSUFBSSxPQUFPLElBQUksQ0FBQyxVQUFVLEtBQUssV0FBVyxJQUFJLE1BQU0sQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxDQUFDLE1BQU0sS0FBSyxDQUFDO1lBQUUsT0FBTztRQUNoRyxJQUFJLENBQUMsTUFBTSxDQUFDLGNBQWMsQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLENBQUM7UUFDekMsSUFBSSxJQUFJLENBQUMsZ0JBQWdCO1lBQUUsVUFBVSxDQUFDLEdBQUcsRUFBRSxDQUFDLElBQUksQ0FBQyxZQUFZLEVBQUUsQ0FBQyxDQUFDO0lBQ3JFLENBQUM7SUFFTSxrQkFBa0IsQ0FBQyxhQUEyQjtRQUNqRCxJQUFJLENBQUMsbUJBQW1CLENBQUMsSUFBSSxDQUFDLGFBQWEsQ0FBQyxDQUFDO0lBQ2pELENBQUM7SUFFTyxRQUFRO1FBQ1osSUFBSSxPQUFPLElBQUksQ0FBQyxHQUFHLEtBQUssV0FBVyxFQUFFO1lBQ2pDLElBQUksQ0FBQyxHQUFHLENBQUMsSUFBSSxHQUFHLENBQUMsT0FBZSxFQUFRLEVBQUUsQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsQ0FBQztTQUM3RTtJQUNMLENBQUM7SUFFTyxnQkFBZ0I7UUFDcEIsSUFBSSxPQUFPLElBQUksQ0FBQyxXQUFXLEtBQUssV0FBVyxFQUFFO1lBQ3pDLElBQUksQ0FBQyxXQUFXLENBQUMsYUFBYSxHQUFHLENBQUMsS0FBbUIsRUFBRSxXQUFtQixFQUFRLEVBQUU7Z0JBQ2hGLElBQUksYUFBYSxHQUErQyxJQUFJLENBQUMsV0FBVyxDQUFDLHFCQUFxQixDQUFDLElBQUksQ0FBQyxLQUFLLEVBQUUsS0FBSyxFQUFFLFdBQVcsQ0FBQyxDQUFDO2dCQUN2SSxLQUFLLElBQUksQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLEdBQUcsYUFBYSxDQUFDLE1BQU0sRUFBRSxFQUFFLENBQUMsRUFBRTtvQkFDM0MsSUFBSSxDQUFDLFdBQVcsQ0FBQyxxQkFBcUIsQ0FBQyxhQUFhLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLFFBQVEsRUFBRSxDQUFDLENBQUMsYUFBYSxDQUFDLGFBQWEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQztpQkFDcEg7WUFDTCxDQUFDLENBQUM7WUFDRixJQUFJLENBQUMsV0FBVyxDQUFDLHFCQUFxQixHQUFHLENBQUMsSUFBWSxFQUEyQixFQUFFLENBQUMsSUFBSSxDQUFDLGtCQUFrQixDQUFDLElBQUksQ0FBQyxDQUFDO1NBQ3JIO0lBQ0wsQ0FBQztJQUVPLFVBQVUsQ0FBQyxPQUEyQjtRQUMxQyxJQUFJLENBQUMsTUFBTSxHQUFHLElBQUksQ0FBQyxRQUFRLENBQUMsZUFBZSxDQUFDLGFBQWEsRUFBRSxJQUFJLENBQUMsVUFBVSxDQUFDLENBQUM7UUFDNUUsSUFBSSxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsS0FBSyxHQUFHLElBQUksQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLEtBQUssSUFBSSxHQUFHLENBQUM7UUFDdkQsSUFBSSxJQUFJLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxLQUFLO1lBQUUsSUFBSSxDQUFDLFNBQVMsR0FBRyxJQUFJLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUM7UUFDcEUsSUFBSSxDQUFDLFlBQVksQ0FBQyxZQUFZLEdBQUcsSUFBSSxDQUFDLE1BQU0sQ0FBQyxZQUFZLENBQUM7UUFDMUQsSUFBSSxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksR0FBRyxJQUFJLENBQUMsTUFBTSxDQUFDLFlBQVksQ0FBQztRQUN0RCxJQUFJLElBQUksQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLGNBQWMsSUFBSSxPQUFPLElBQUksQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLGNBQWMsS0FBSyxRQUFRO1lBQUUsSUFBSSxDQUFDLGdCQUFnQixHQUFHLElBQUksQ0FBQztJQUM3SCxDQUFDO0lBRU8scUJBQXFCO1FBQ3pCLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLENBQUM7UUFDekMsSUFBSSxDQUFDLGdCQUFnQixHQUFHLElBQUksQ0FBQyxnQkFBZ0IsSUFBSSxJQUFJLENBQUMsV0FBVyxDQUFDLGlCQUFpQixDQUFDLElBQUksQ0FBQyxLQUFLLEVBQUUsSUFBSSxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsY0FBYyxDQUFDLENBQUM7UUFFakksMEVBQTBFO1FBQzFFLElBQUksQ0FBQyxNQUFNLEdBQUcsSUFBSSxDQUFDLFdBQVcsQ0FBQyxxQkFBcUIsQ0FBQyxJQUFJLENBQUMsS0FBSyxFQUFFLElBQUksQ0FBQyxLQUFLLEVBQUUsSUFBSSxDQUFDLE9BQU8sQ0FBQyxDQUFDO1FBRTNGOzs7O1dBSUc7UUFDSCxJQUFJLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLEVBQUUsRUFBRTtZQUMvQixJQUFJLENBQUMsSUFBSSxDQUFDLFlBQVksRUFBRSxDQUFDO1FBQzdCLENBQUMsQ0FBQyxDQUFDO1FBRUgsSUFBSSxDQUFDLE1BQU0sQ0FBQyxlQUFlLENBQUMsU0FBUyxDQUFDLENBQUMsS0FBSyxFQUFFLEVBQUU7WUFDNUMsSUFBSSxDQUFDLGVBQWUsRUFBRSxDQUFDO1FBQzNCLENBQUMsQ0FBQyxDQUFDO0lBQ1AsQ0FBQztJQUVPLGtCQUFrQixDQUFDLFdBQTRDO1FBQ25FLElBQUksT0FBNkcsQ0FBQztRQUNsSCxPQUFPLEdBQUcsSUFBSSxDQUFDLFdBQVcsQ0FBQyxPQUFPLENBQUMsV0FBVyxDQUFDLENBQUM7UUFDaEQsSUFBSSxDQUFDLFlBQVksR0FBRyxPQUFPLENBQUMsWUFBWSxDQUFDO1FBQ3pDLElBQUksQ0FBQyxLQUFLLEdBQUcsT0FBTyxDQUFDLEtBQUssQ0FBQztRQUMzQixJQUFJLENBQUMsT0FBTyxDQUFDLEtBQUssR0FBRyxJQUFJLENBQUMsZUFBZSxFQUFFLENBQUM7UUFDNUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxhQUFhLEdBQUcsSUFBSSxDQUFDLHVCQUF1QixFQUFFLENBQUM7UUFDNUQsSUFBSSxDQUFDLEtBQUssR0FBRyxJQUFJLENBQUMsV0FBVyxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsS0FBSyxFQUFFLElBQUksQ0FBQyxPQUFPLENBQUMsYUFBYSxFQUFFLE9BQU8sQ0FBQyxTQUFTLENBQUMsQ0FBQztJQUN0RyxDQUFDO0lBRU8sZUFBZTtRQUNuQixPQUFPLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxnQkFBZ0IsR0FBRyxJQUFJLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsR0FBRyxJQUFJLENBQUMsWUFBWSxHQUFHLElBQUksQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLEtBQUssR0FBRyxDQUFDLEdBQUcsSUFBSSxDQUFDLE1BQU0sQ0FBQyxPQUFPLENBQUM7SUFDMUksQ0FBQztJQUVPLHVCQUF1QjtRQUMzQixJQUFJLFFBQVEsR0FBOEIsRUFBRSxDQUFDO1FBQzdDLEtBQUssSUFBSSxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsR0FBRyxJQUFJLENBQUMsWUFBWSxHQUFHLENBQUMsRUFBRSxFQUFFLENBQUMsRUFBRTtZQUM1QyxRQUFRLENBQUMsQ0FBQyxDQUFDLFFBQVEsRUFBRSxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsS0FBSyxHQUFHLElBQUksQ0FBQyxNQUFNLENBQUMsZ0JBQWdCLENBQUMsR0FBRyxJQUFJLENBQUMsTUFBTSxDQUFDLE9BQU8sR0FBRyxJQUFJLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxLQUFLLEdBQUcsQ0FBQyxDQUFDO1NBQzNJO1FBQ0QsT0FBTyxRQUFRLENBQUM7SUFDcEIsQ0FBQztJQUVEOzs7TUFHRTtJQUNNLFlBQVk7UUFDaEIsSUFBSSxNQUFNLEdBQUc7WUFDVCxRQUFRLEVBQUUsSUFBSSxDQUFDLFFBQVEsQ0FBQyxhQUFhLENBQUMsYUFBYSxDQUFDLG1DQUFtQyxDQUFDLENBQUMscUJBQXFCLEVBQUUsQ0FBQyxLQUFLO1lBQ3RILFNBQVMsRUFBRSxJQUFJLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxLQUFLO1lBQ2pDLE9BQU8sRUFBRSxJQUFJLENBQUMsTUFBTSxDQUFDLE9BQU87U0FDL0IsQ0FBQztRQUNGLElBQUksU0FBUyxHQUFXLElBQUksQ0FBQyxXQUFXLENBQUMsa0JBQWtCLENBQUMsTUFBTSxFQUFFLElBQUksQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxJQUFJLENBQUMsY0FBYyxDQUFDLEVBQUUsT0FBTyxDQUFDLENBQUM7UUFDOUgsSUFBSSxDQUFDLFdBQVcsQ0FBQyxTQUFTLENBQUMsU0FBUyxDQUFDLENBQUMsRUFBRSxDQUFDLEtBQUssRUFBRSxHQUFHLEVBQUUsQ0FBQyxJQUFJLENBQUMsZ0JBQWdCLEVBQUUsQ0FBQyxDQUFDO0lBQ25GLENBQUM7SUFFTyxlQUFlO1FBQ25CLElBQUksQ0FBQyxjQUFjLEdBQUcsSUFBSSxDQUFDO1FBQzNCLElBQUksSUFBSSxDQUFDLGVBQWUsSUFBSSxDQUFDLElBQUksQ0FBQyxnQkFBZ0I7WUFBRSxJQUFJLENBQUMsVUFBVSxHQUFHLEtBQUssQ0FBQztJQUNoRixDQUFDO0lBRU8sZ0JBQWdCO1FBQ3BCLElBQUksQ0FBQyxlQUFlLEdBQUcsSUFBSSxDQUFDO1FBQzVCLElBQUksSUFBSSxDQUFDLGNBQWM7WUFBRSxJQUFJLENBQUMsVUFBVSxHQUFHLEtBQUssQ0FBQztJQUNyRCxDQUFDOzs7WUFoTEosU0FBUyxTQUFDO2dCQUNQLFFBQVEsRUFBRSxZQUFZO2dCQUN0Qiwyd0dBQXdDO2dCQUN4QyxTQUFTLEVBQUUsQ0FBQyxZQUFZLEVBQUUsU0FBUyxDQUFDO2dCQUNwQyxhQUFhLEVBQUUsaUJBQWlCLENBQUMsSUFBSTtnQkFDckMsZUFBZSxFQUFFLHVCQUF1QixDQUFDLE1BQU07Z0JBQy9DLElBQUksRUFBRTtvQkFDRixPQUFPLEVBQUUsYUFBYTtvQkFDdEIsV0FBVyxFQUFFLFdBQVc7aUJBQzNCO2FBQ0o7OztZQXhCUSxZQUFZO1lBRlosU0FBUztZQUpkLFVBQVU7WUFEVixpQkFBaUI7Ozt5QkF5RGhCLEtBQUssU0FBQyxPQUFPO3lCQUNiLEtBQUssU0FBQyxRQUFRO2tCQUNkLEtBQUs7a0NBQ0wsTUFBTSIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7XHJcbiAgICBDb21wb25lbnQsXHJcbiAgICBWaWV3RW5jYXBzdWxhdGlvbixcclxuICAgIElucHV0LFxyXG4gICAgT3V0cHV0LFxyXG4gICAgT25Jbml0LFxyXG4gICAgT25DaGFuZ2VzLFxyXG4gICAgU2ltcGxlQ2hhbmdlcyxcclxuICAgIENoYW5nZURldGVjdG9yUmVmLFxyXG4gICAgRWxlbWVudFJlZixcclxuICAgIENoYW5nZURldGVjdGlvblN0cmF0ZWd5LFxyXG4gICAgRXZlbnRFbWl0dGVyXHJcbn0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XHJcbmltcG9ydCB7IEtkRGF0YVN2YyB9IGZyb20gJy4uL2tkLWNvbW1vbi9pbmRleCc7XHJcbmltcG9ydCB7IEZvcmNlRGlyZWN0ZWRHcmFwaCB9IGZyb20gJy4va2QtYW5ndWxhci1taW5kbWFwLWZvcmNlLWxvZ2ljJztcclxuaW1wb3J0IHsgS2RNaW5kbWFwU3ZjIH0gZnJvbSAnLi9rZC1hbmd1bGFyLW1pbmRtYXAtc3ZjJztcclxuaW1wb3J0IHtcclxuICAgIElNaW5kbWFwT3B0aW9ucyxcclxuICAgIElab29tQnV0dG9uQ29uZmlnLFxyXG4gICAgSU1pbmRtYXBJbnRlcm5hbEFwaSxcclxuICAgIElJbnRlcm5hbEFsbENvbmZpZyxcclxuICAgIElNaW5kbWFwSW50ZXJuYWxMaW5rQXBpUmVmLFxyXG4gICAgSU1pbmRtYXBJbnRlcm5hbExpbmtBcGksXHJcbiAgICBJTWluZG1hcE5vZGUsIFxyXG4gICAgSU1pbmRtYXBMaW5rLCBcclxuICAgIElNaW5kbWFwQXBpXHJcbn0gZnJvbSAnLi9rZC1hbmd1bGFyLW1pbmRtYXAtaW50ZXJmYWNlJztcclxuaW1wb3J0IHsgZGVmYXVsdENvbmZpZyB9IGZyb20gJy4va2QtYW5ndWxhci1taW5kbWFwLWNvbmZpZyc7XHJcblxyXG5AQ29tcG9uZW50KHtcclxuICAgIHNlbGVjdG9yOiAna2QtbWluZG1hcCcsXHJcbiAgICB0ZW1wbGF0ZVVybDogJy4va2QtYW5ndWxhci1taW5kbWFwLmh0bWwnLFxyXG4gICAgcHJvdmlkZXJzOiBbS2RNaW5kbWFwU3ZjLCBLZERhdGFTdmNdLFxyXG4gICAgZW5jYXBzdWxhdGlvbjogVmlld0VuY2Fwc3VsYXRpb24uTm9uZSxcclxuICAgIGNoYW5nZURldGVjdGlvbjogQ2hhbmdlRGV0ZWN0aW9uU3RyYXRlZ3kuT25QdXNoLFxyXG4gICAgaG9zdDoge1xyXG4gICAgICAgICdjbGFzcyc6ICdrZHgtbWluZG1hcCcsXHJcbiAgICAgICAgJ1thdHRyLmlkXSc6ICdjb25maWcuaWQnLFxyXG4gICAgfVxyXG59KVxyXG5cclxuZXhwb3J0IGNsYXNzIEtkTWluZG1hcCBpbXBsZW1lbnRzIE9uSW5pdCwgT25DaGFuZ2VzIHtcclxuICAgIHB1YmxpYyBjb25maWc6IElJbnRlcm5hbEFsbENvbmZpZztcclxuICAgIHB1YmxpYyBub2RlczogQXJyYXk8SU1pbmRtYXBOb2RlPjtcclxuICAgIHB1YmxpYyBsaW5rczogQXJyYXk8SU1pbmRtYXBMaW5rPjtcclxuICAgIHB1YmxpYyBoaWdoZXN0Q291bnQ6IG51bWJlcjtcclxuICAgIHB1YmxpYyBpbnRlcm5hbEFwaTogSU1pbmRtYXBJbnRlcm5hbEFwaSA9IHt9O1xyXG4gICAgcHVibGljIGludGVybmFsTGlua0FwaVJlZjogSU1pbmRtYXBJbnRlcm5hbExpbmtBcGlSZWYgPSB7fTtcclxuICAgIHB1YmxpYyBkaXNwbGF5R3JhcGg6IGJvb2xlYW4gPSB0cnVlO1xyXG4gICAgcHVibGljIGxpbmtDbGFzczogc3RyaW5nID0gJyc7XHJcbiAgICBwdWJsaWMgb3B0aW9uczogSU1pbmRtYXBPcHRpb25zID0geyB3aWR0aDogMCwgaGVpZ2h0OiA2MDAsIGxldmVsUG9zaXRpb246IHsgJzAnOiAxMCB9IH07XHJcbiAgICBwdWJsaWMgc2hvd0xvYWRlcjogYm9vbGVhbiA9IHRydWU7XHJcbiAgICBwdWJsaWMgc21hbGxMb2FkZXJWYWx1ZTogYW55ID0gbnVsbDtcclxuXHJcbiAgICBwdWJsaWMgYnV0dG9uQ29uZmlnOiBJWm9vbUJ1dHRvbkNvbmZpZyA9IHtcclxuICAgICAgICBjb29yZDogeyB4OiAyNSwgeTogMjUgfSxcclxuICAgICAgICBzaXplOiAzMCxcclxuICAgICAgICBpY29uU2l6ZTogMjAsXHJcbiAgICAgICAgbWFyZ2luQm90dG9tOiAxMCxcclxuICAgIH07XHJcbiAgICBwcml2YXRlIF9ncmFwaDogRm9yY2VEaXJlY3RlZEdyYXBoO1xyXG4gICAgcHJpdmF0ZSBfc2ltdWxhdGlvbkVuZDogYm9vbGVhbiA9IGZhbHNlO1xyXG4gICAgcHJpdmF0ZSBfdHJhbnNsYXRpb25FbmQ6IGJvb2xlYW4gPSBmYWxzZTtcclxuICAgIHByaXZhdGUgX2hhc1NlbGVjdGVkTm9kZTogYm9vbGVhbiA9IGZhbHNlO1xyXG5cclxuICAgIEBJbnB1dCgnbm9kZXMnKSBpbnB1dE5vZGVzOiBhbnk7XHJcbiAgICBASW5wdXQoJ2NvbmZpZycpIG1haW5Db25maWc6IGFueTtcclxuICAgIEBJbnB1dCgpIGFwaTogSU1pbmRtYXBBcGk7XHJcbiAgICBAT3V0cHV0KCkgc2VsZWN0ZWROb2RlRW1pdHRlcjogRXZlbnRFbWl0dGVyPElNaW5kbWFwTm9kZT4gPSBuZXcgRXZlbnRFbWl0dGVyKCk7XHJcblxyXG4gICAgY29uc3RydWN0b3IoXHJcbiAgICAgICAgcHJpdmF0ZSBfbWluZG1hcFN2YzogS2RNaW5kbWFwU3ZjLFxyXG4gICAgICAgIHByaXZhdGUgX2RhdGFTdmM6IEtkRGF0YVN2YyxcclxuICAgICAgICBwcml2YXRlIF9lbGVtUmVmOiBFbGVtZW50UmVmLFxyXG4gICAgICAgIHByaXZhdGUgX3JlZjogQ2hhbmdlRGV0ZWN0b3JSZWYsXHJcbiAgICApIHsgfVxyXG5cclxuICAgIG5nT25Jbml0KCk6IHZvaWQge1xyXG4gICAgICAgIHRoaXMuX3NldENvbmZpZyh0aGlzLm1haW5Db25maWcpO1xyXG4gICAgICAgIHRoaXMuX2luaXRBcGkoKTtcclxuICAgICAgICB0aGlzLl9pbml0SW50ZXJuYWxBcGkoKTtcclxuICAgICAgICBpZiAodHlwZW9mIHRoaXMuaW5wdXROb2RlcyA9PT0gJ3VuZGVmaW5lZCcgfHwgT2JqZWN0LmtleXModGhpcy5pbnB1dE5vZGVzKS5sZW5ndGggPT09IDApIHtcclxuICAgICAgICAgICAgdGhpcy5kaXNwbGF5R3JhcGggPSBmYWxzZTtcclxuICAgICAgICAgICAgcmV0dXJuO1xyXG4gICAgICAgIH1cclxuICAgICAgICB0aGlzLl9zdGFydFNldERhdGFBbmRHcmFwaCgpO1xyXG4gICAgfVxyXG5cclxuICAgIG5nT25DaGFuZ2VzKF9zaW1wbGVDaGFuZ2VzOiBTaW1wbGVDaGFuZ2VzKTogdm9pZCB7XHJcbiAgICAgICAgaWYgKF9zaW1wbGVDaGFuZ2VzLmhhc093blByb3BlcnR5KCdtYWluQ29uZmlnJykgJiYgIV9zaW1wbGVDaGFuZ2VzWydtYWluQ29uZmlnJ10uZmlyc3RDaGFuZ2UpIHtcclxuICAgICAgICAgICAgdGhpcy5fc2V0Q29uZmlnKHRoaXMubWFpbkNvbmZpZyk7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGlmIChfc2ltcGxlQ2hhbmdlcy5oYXNPd25Qcm9wZXJ0eSgnaW5wdXROb2RlcycpICYmICFfc2ltcGxlQ2hhbmdlc1snaW5wdXROb2RlcyddLmZpcnN0Q2hhbmdlICYmIE9iamVjdC5rZXlzKHRoaXMuaW5wdXROb2RlcykubGVuZ3RoICE9PSAwKSB7XHJcbiAgICAgICAgICAgIGlmICghdGhpcy5kaXNwbGF5R3JhcGgpIHRoaXMuZGlzcGxheUdyYXBoID0gdHJ1ZTtcclxuICAgICAgICAgICAgdGhpcy5fc3RhcnRTZXREYXRhQW5kR3JhcGgoKTtcclxuICAgICAgICAgICAgdGhpcy5fZ3JhcGguaW5pdFNpbXVsYXRpb24odGhpcy5vcHRpb25zKTtcclxuICAgICAgICAgICAgaWYgKHRoaXMuX2hhc1NlbGVjdGVkTm9kZSkge1xyXG4gICAgICAgICAgICAgICAgaWYgKHRoaXMuaW50ZXJuYWxBcGkuaGFzT3duUHJvcGVydHkoJ3RyYW5zbGF0ZScpKSB0aGlzLl9zZXRJbml0UG9zWCgpO1xyXG4gICAgICAgICAgICAgICAgZWxzZSBzZXRUaW1lb3V0KCgpID0+IHRoaXMuX3NldEluaXRQb3NYKCkpO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIG5nQWZ0ZXJWaWV3SW5pdCgpOiB2b2lkIHtcclxuICAgICAgICBpZiAodHlwZW9mIHRoaXMuaW5wdXROb2RlcyA9PT0gJ3VuZGVmaW5lZCcgfHwgT2JqZWN0LmtleXModGhpcy5pbnB1dE5vZGVzKS5sZW5ndGggPT09IDApIHJldHVybjtcclxuICAgICAgICB0aGlzLl9ncmFwaC5pbml0U2ltdWxhdGlvbih0aGlzLm9wdGlvbnMpO1xyXG4gICAgICAgIGlmICh0aGlzLl9oYXNTZWxlY3RlZE5vZGUpIHNldFRpbWVvdXQoKCkgPT4gdGhpcy5fc2V0SW5pdFBvc1goKSk7XHJcbiAgICB9XHJcblxyXG4gICAgcHVibGljIG91dHB1dFNlbGVjdGVkTm9kZShfc2VsZWN0ZWROb2RlOiBJTWluZG1hcE5vZGUpOiB2b2lkIHtcclxuICAgICAgICB0aGlzLnNlbGVjdGVkTm9kZUVtaXR0ZXIuZW1pdChfc2VsZWN0ZWROb2RlKTtcclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF9pbml0QXBpKCk6IHZvaWQge1xyXG4gICAgICAgIGlmICh0eXBlb2YgdGhpcy5hcGkgIT09ICd1bmRlZmluZWQnKSB7XHJcbiAgICAgICAgICAgIHRoaXMuYXBpLnpvb20gPSAoX2FjdGlvbjogc3RyaW5nKTogdm9pZCA9PiB0aGlzLmludGVybmFsQXBpLnpvb20oX2FjdGlvbik7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX2luaXRJbnRlcm5hbEFwaSgpOiB2b2lkIHtcclxuICAgICAgICBpZiAodHlwZW9mIHRoaXMuaW50ZXJuYWxBcGkgIT09ICd1bmRlZmluZWQnKSB7XHJcbiAgICAgICAgICAgIHRoaXMuaW50ZXJuYWxBcGkuc2V0Tm9kZUhlaWdodCA9IChfbm9kZTogSU1pbmRtYXBOb2RlLCBfbm9kZUhlaWdodDogbnVtYmVyKTogdm9pZCA9PiB7XHJcbiAgICAgICAgICAgICAgICBsZXQgYWZmZWN0ZWRMaW5rczogQXJyYXk8eyBpbmRleD86IG51bWJlciwgb2Zmc2V0PzogbnVtYmVyIH0+ID0gdGhpcy5fbWluZG1hcFN2Yy5zZXRMaW5rU3ByZWFkRGlzdGFuY2UodGhpcy5saW5rcywgX25vZGUsIF9ub2RlSGVpZ2h0KTtcclxuICAgICAgICAgICAgICAgIGZvciAobGV0IGkgPSAwOyBpIDwgYWZmZWN0ZWRMaW5rcy5sZW5ndGg7ICsraSkge1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuaW50ZXJuYWxBcGkuYWNjZXNzSW50ZXJuYWxMaW5rQXBpKGFmZmVjdGVkTGlua3NbaV0uaW5kZXgudG9TdHJpbmcoKSkuc2V0TGlua09mZnNldChhZmZlY3RlZExpbmtzW2ldLm9mZnNldCk7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH07XHJcbiAgICAgICAgICAgIHRoaXMuaW50ZXJuYWxBcGkuYWNjZXNzSW50ZXJuYWxMaW5rQXBpID0gKF9rZXk6IHN0cmluZyk6IElNaW5kbWFwSW50ZXJuYWxMaW5rQXBpID0+IHRoaXMuaW50ZXJuYWxMaW5rQXBpUmVmW19rZXldO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF9zZXRDb25maWcoX2NvbmZpZzogSUludGVybmFsQWxsQ29uZmlnKTogdm9pZCB7XHJcbiAgICAgICAgdGhpcy5jb25maWcgPSB0aGlzLl9kYXRhU3ZjLmRlZXBNZXJnZU9iamVjdChkZWZhdWx0Q29uZmlnLCB0aGlzLm1haW5Db25maWcpO1xyXG4gICAgICAgIHRoaXMuY29uZmlnLm5vZGUud2lkdGggPSB0aGlzLmNvbmZpZy5ub2RlLndpZHRoIHx8IDIwMDtcclxuICAgICAgICBpZiAodGhpcy5jb25maWcubGluay5jbGFzcykgdGhpcy5saW5rQ2xhc3MgPSB0aGlzLmNvbmZpZy5saW5rLmNsYXNzO1xyXG4gICAgICAgIHRoaXMuYnV0dG9uQ29uZmlnLmljb25MaW5rUGF0aCA9IHRoaXMuY29uZmlnLmljb25MaW5rUGF0aDtcclxuICAgICAgICB0aGlzLmNvbmZpZy5ub2RlLmljb24ubGluayA9IHRoaXMuY29uZmlnLmljb25MaW5rUGF0aDtcclxuICAgICAgICBpZiAodGhpcy5jb25maWcubm9kZS5zZWxlY3RPbkxvYWRJZCAmJiB0eXBlb2YgdGhpcy5jb25maWcubm9kZS5zZWxlY3RPbkxvYWRJZCA9PT0gJ251bWJlcicpIHRoaXMuX2hhc1NlbGVjdGVkTm9kZSA9IHRydWU7XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfc3RhcnRTZXREYXRhQW5kR3JhcGgoKTogdm9pZCB7XHJcbiAgICAgICAgdGhpcy5fc2V0RGF0YUFuZE9wdGlvbnModGhpcy5pbnB1dE5vZGVzKTtcclxuICAgICAgICB0aGlzLl9oYXNTZWxlY3RlZE5vZGUgPSB0aGlzLl9oYXNTZWxlY3RlZE5vZGUgJiYgdGhpcy5fbWluZG1hcFN2Yy5mb3VuZFNlbGVjdGVkTm9kZSh0aGlzLm5vZGVzLCB0aGlzLmNvbmZpZy5ub2RlLnNlbGVjdE9uTG9hZElkKTtcclxuXHJcbiAgICAgICAgLyoqIFJlY2VpdmluZyBhbiBpbml0aWFsaXplZCBzaW11bGF0ZWQgZ3JhcGggZnJvbSBvdXIgY3VzdG9tIGQzIHNlcnZpY2UgKi9cclxuICAgICAgICB0aGlzLl9ncmFwaCA9IHRoaXMuX21pbmRtYXBTdmMuZ2V0Rm9yY2VEaXJlY3RlZEdyYXBoKHRoaXMubm9kZXMsIHRoaXMubGlua3MsIHRoaXMub3B0aW9ucyk7XHJcblxyXG4gICAgICAgIC8qKiBCaW5kaW5nIGNoYW5nZSBkZXRlY3Rpb24gY2hlY2sgb24gZWFjaCB0aWNrXHJcbiAgICAgICAgICogVGhpcyBhbG9uZyB3aXRoIGFuIG9uUHVzaCBjaGFuZ2UgZGV0ZWN0aW9uIHN0cmF0ZWd5IHNob3VsZCBlbmZvcmNlIGNoZWNraW5nIG9ubHkgd2hlbiByZWxldmFudCFcclxuICAgICAgICAgKiBUaGlzIGltcHJvdmVzIHNjcmlwdGluZyBjb21wdXRhdGlvbiBkdXJhdGlvbiBpbiBhIGNvdXBsZSBvZiB0ZXN0cyBJJ3ZlIG1hZGUsIGNvbnNpc3RlbnRseS5cclxuICAgICAgICAgKiBBbHNvLCBpdCBtYWtlcyBzZW5zZSB0byBhdm9pZCB1bm5lY2Vzc2FyeSBjaGVja3Mgd2hlbiB3ZSBhcmUgZGVhbGluZyBvbmx5IHdpdGggc2ltdWxhdGlvbnMgZGF0YSBiaW5kaW5nLlxyXG4gICAgICAgICAqL1xyXG4gICAgICAgIHRoaXMuX2dyYXBoLnRpY2tlci5zdWJzY3JpYmUoKGQpID0+IHtcclxuICAgICAgICAgICAgdGhpcy5fcmVmLm1hcmtGb3JDaGVjaygpO1xyXG4gICAgICAgIH0pO1xyXG5cclxuICAgICAgICB0aGlzLl9ncmFwaC5vblNpbXVsYXRpb25FbmQuc3Vic2NyaWJlKChfZmxhZykgPT4ge1xyXG4gICAgICAgICAgICB0aGlzLm9uU2ltdWxhdGlvbkVuZCgpO1xyXG4gICAgICAgIH0pO1xyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX3NldERhdGFBbmRPcHRpb25zKF9pbnB1dE5vZGVzOiB7IFtrZXk6IHN0cmluZ106IElNaW5kbWFwTm9kZSB9KTogdm9pZCB7XHJcbiAgICAgICAgbGV0IG5ld0RhdGE6IHsgbm9kZXM6IEFycmF5PElNaW5kbWFwTm9kZT4sIGxpbmtzOiBBcnJheTxJTWluZG1hcExpbms+LCBoaWdoZXN0Q291bnQ6IG51bWJlciwgaGF2ZUxvbmVyOiBib29sZWFuIH07XHJcbiAgICAgICAgbmV3RGF0YSA9IHRoaXMuX21pbmRtYXBTdmMuc2V0RGF0YShfaW5wdXROb2Rlcyk7XHJcbiAgICAgICAgdGhpcy5oaWdoZXN0Q291bnQgPSBuZXdEYXRhLmhpZ2hlc3RDb3VudDtcclxuICAgICAgICB0aGlzLmxpbmtzID0gbmV3RGF0YS5saW5rcztcclxuICAgICAgICB0aGlzLm9wdGlvbnMud2lkdGggPSB0aGlzLl9jYWxjdWxhdGVXaWR0aCgpO1xyXG4gICAgICAgIHRoaXMub3B0aW9ucy5sZXZlbFBvc2l0aW9uID0gdGhpcy5fY2FsY3VsYXRlTGV2ZWxQb3NpdGlvbigpO1xyXG4gICAgICAgIHRoaXMubm9kZXMgPSB0aGlzLl9taW5kbWFwU3ZjLnNldEZ4KG5ld0RhdGEubm9kZXMsIHRoaXMub3B0aW9ucy5sZXZlbFBvc2l0aW9uLCBuZXdEYXRhLmhhdmVMb25lcik7XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfY2FsY3VsYXRlV2lkdGgoKTogbnVtYmVyIHtcclxuICAgICAgICByZXR1cm4gKHRoaXMuY29uZmlnLmxldmVsUmlnaHRNYXJnaW4gKyB0aGlzLmNvbmZpZy5ub2RlLndpZHRoKSAqIHRoaXMuaGlnaGVzdENvdW50ICsgdGhpcy5jb25maWcubm9kZS53aWR0aCArIDIgKiB0aGlzLmNvbmZpZy5wYWRkaW5nO1xyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX2NhbGN1bGF0ZUxldmVsUG9zaXRpb24oKTogeyBba2V5OiBzdHJpbmddOiBudW1iZXIgfSB7XHJcbiAgICAgICAgbGV0IHBvc2l0aW9uOiB7IFtrZXk6IHN0cmluZ106IG51bWJlciB9ID0ge307XHJcbiAgICAgICAgZm9yIChsZXQgaSA9IDA7IGkgPCB0aGlzLmhpZ2hlc3RDb3VudCArIDE7ICsraSkge1xyXG4gICAgICAgICAgICBwb3NpdGlvbltpLnRvU3RyaW5nKCldID0gaSAqICh0aGlzLmNvbmZpZy5ub2RlLndpZHRoICsgdGhpcy5jb25maWcubGV2ZWxSaWdodE1hcmdpbikgKyB0aGlzLmNvbmZpZy5wYWRkaW5nICsgdGhpcy5jb25maWcubm9kZS53aWR0aCAvIDI7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIHJldHVybiBwb3NpdGlvbjtcclxuICAgIH1cclxuXHJcbiAgICAvKiBfc2V0SW5pdFBvc1ggc29tZXRpbWVzIG5lZWRzIHNldFRpbWVvdXQgZm9yIDIgcmVhc29uczpcclxuICAgICogMSkgb24gZmlyc3QgbG9hZCwgZ2V0Qm91bmRpbmdDbGllbnRSZWN0IGlzIG5vdCByZWFkeVxyXG4gICAgKiAyKSBvbiBzdWJzZXF1ZW50IGxvYWQsIG5lZWQgdG8gbWFrZSBzdXJlIGludGVybmFsQXBpLnRyYW5zbGF0ZSBpcyBwcmVzZW50IChtYXkgbm90IGJlIHByZXNlbnQgYmVjb3MgZGlzcGxheUdyYXBoIHdhcyBzZXQgdG8gZmFsc2UpXHJcbiAgICAqL1xyXG4gICAgcHJpdmF0ZSBfc2V0SW5pdFBvc1goKTogdm9pZCB7XHJcbiAgICAgICAgbGV0IGNvbmZpZyA9IHtcclxuICAgICAgICAgICAgc3ZnV2lkdGg6IHRoaXMuX2VsZW1SZWYubmF0aXZlRWxlbWVudC5xdWVyeVNlbGVjdG9yKCcua2R4LW1pbmRtYXAgI2tkeC1taW5kbWFwLXdyYXBwZXInKS5nZXRCb3VuZGluZ0NsaWVudFJlY3QoKS53aWR0aCxcclxuICAgICAgICAgICAgbm9kZVdpZHRoOiB0aGlzLmNvbmZpZy5ub2RlLndpZHRoLFxyXG4gICAgICAgICAgICBwYWRkaW5nOiB0aGlzLmNvbmZpZy5wYWRkaW5nXHJcbiAgICAgICAgfTtcclxuICAgICAgICBsZXQgX2luaXRQb3NYOiBudW1iZXIgPSB0aGlzLl9taW5kbWFwU3ZjLnRyYW5zbGF0ZVN2Z1RvWFBvcyhjb25maWcsIHRoaXMubm9kZXNbdGhpcy5tYWluQ29uZmlnLm5vZGUuc2VsZWN0T25Mb2FkSWRdLCAncmlnaHQnKTtcclxuICAgICAgICB0aGlzLmludGVybmFsQXBpLnRyYW5zbGF0ZShfaW5pdFBvc1gpLm9uKCdlbmQnLCAoKSA9PiB0aGlzLm9uVHJhbnNsYXRpb25FbmQoKSk7XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBvblNpbXVsYXRpb25FbmQoKSB7XHJcbiAgICAgICAgdGhpcy5fc2ltdWxhdGlvbkVuZCA9IHRydWU7XHJcbiAgICAgICAgaWYgKHRoaXMuX3RyYW5zbGF0aW9uRW5kIHx8ICF0aGlzLl9oYXNTZWxlY3RlZE5vZGUpIHRoaXMuc2hvd0xvYWRlciA9IGZhbHNlO1xyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgb25UcmFuc2xhdGlvbkVuZCgpIHtcclxuICAgICAgICB0aGlzLl90cmFuc2xhdGlvbkVuZCA9IHRydWU7XHJcbiAgICAgICAgaWYgKHRoaXMuX3NpbXVsYXRpb25FbmQpIHRoaXMuc2hvd0xvYWRlciA9IGZhbHNlO1xyXG4gICAgfVxyXG59XHJcbiJdfQ==