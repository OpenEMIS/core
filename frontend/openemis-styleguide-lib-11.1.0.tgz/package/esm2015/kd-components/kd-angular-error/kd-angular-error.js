import { Component, Input } from '@angular/core';
import { Location } from '@angular/common';
import { Router } from '@angular/router';
export class KdError {
    constructor(_location, _router) {
        this._location = _location;
        this._router = _router;
        this._finalConfig = {};
        this._defaultConfig = {
            homePath: '',
            email: 'support@openemis.org',
            backPath: '',
            forbiddenPath: ''
        };
    }
    ngOnInit() {
        if (typeof this.errorType === 'undefined')
            this.errorType = '403';
        switch (this.errorType) {
            case '404':
                this._defaultConfig.icon = 'kd-404-error';
                break;
            default:
                this._defaultConfig.icon = 'kd-403-error';
                break;
        }
        this._finalConfig = Object.assign(this._defaultConfig, this.config);
    }
    redirect() {
        if (this._finalConfig.homePath !== '') {
            this._router.navigate(['.' + this._finalConfig.homePath]);
        }
        else {
            console.log('Please specify the home path');
        }
    }
    back() {
        // if(typeof this.config.backbtn === 'undefined' || this.config.backbtn =='') {
        //     this._location.back();
        // } else {
        //     this._router.navigate(['.'+this.config.backbtn]);
        // }
        if (this._finalConfig.backPath !== '') {
            this._router.navigate(['.' + this._finalConfig.backPath]);
        }
        else {
            console.log('Please specify the back path');
        }
    }
}
KdError.decorators = [
    { type: Component, args: [{
                selector: 'kd-error',
                template: "<div class=\"kdx-error\">\r\n    <div class=\"kdx-error-page-icon\">\r\n        <i class=\"fa fa-5x\" [ngClass]=\"_finalConfig.icon\"></i>\r\n    </div>\r\n    <div class=\"kdx-error-page-text\" [ngSwitch]=\"errorType\">\r\n        <div *ngSwitchCase=\"'403'\">\r\n            <h1>403 Forbidden: No Permission to Access</h1>\r\n            <h5>You don't have permission to access \"{{_finalConfig.forbiddenPath}}\" on this server. If you believe you should be able to view this directory or page, please contact the administrator <a href=\"mailto:{{_finalConfig.email}}\">here</a>.</h5>\r\n        </div>\r\n        <div *ngSwitchCase=\"'404'\">\r\n            <h1>404 Forbidden: Page Not Found</h1>\r\n            <h5>The page you are looking for might have been removed, renamed or is temporarily unavailable. If you have any enquiries, please contact the administrator <a href=\"mailto:{{_finalConfig.email}}\">here</a>.</h5>\r\n        </div>\r\n    </div>\r\n    <div class=\"kdx-error-page-buttons\">\r\n    \t<button class=\"btn btn-icon btn-outline\" type=\"button\" (click)=\"back()\">\r\n            <i class=\"fa fa-caret-left\" aria-hidden=\"true\"></i> Back\r\n        </button>\r\n        <button class=\"btn btn-icon\" type=\"button\" (click)=\"redirect()\">\r\n            <i class=\"fa fa-home\" aria-hidden=\"true\"></i> Home\r\n        </button>\r\n    </div>\r\n</div>"
            },] }
];
KdError.ctorParameters = () => [
    { type: Location },
    { type: Router }
];
KdError.propDecorators = {
    config: [{ type: Input }],
    errorType: [{ type: Input, args: ['error-type',] }]
};
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoia2QtYW5ndWxhci1lcnJvci5qcyIsInNvdXJjZVJvb3QiOiJDOi9Qcm9qZWN0cy9Bbmd1bGFyL2lvc3RnLW9wZW5lbWlzLXN0eWxlZ3VpZGUvcHJvamVjdHMvb3BlbmVtaXMtc3R5bGVndWlkZS1saWIvc3JjLyIsInNvdXJjZXMiOlsia2QtY29tcG9uZW50cy9rZC1hbmd1bGFyLWVycm9yL2tkLWFuZ3VsYXItZXJyb3IudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsT0FBTyxFQUFFLFNBQVMsRUFBRSxLQUFLLEVBQVUsTUFBTSxlQUFlLENBQUM7QUFDekQsT0FBTyxFQUFFLFFBQVEsRUFBRSxNQUFNLGlCQUFpQixDQUFDO0FBQzNDLE9BQU8sRUFBRSxNQUFNLEVBQUUsTUFBTSxpQkFBaUIsQ0FBQztBQU96QyxNQUFNLE9BQU8sT0FBTztJQVloQixZQUNjLFNBQW1CLEVBQ25CLE9BQWU7UUFEZixjQUFTLEdBQVQsU0FBUyxDQUFVO1FBQ25CLFlBQU8sR0FBUCxPQUFPLENBQVE7UUFidEIsaUJBQVksR0FBUSxFQUFFLENBQUM7UUFDdEIsbUJBQWMsR0FBUTtZQUMxQixRQUFRLEVBQUUsRUFBRTtZQUNaLEtBQUssRUFBRSxzQkFBc0I7WUFDN0IsUUFBUSxFQUFFLEVBQUU7WUFDWixhQUFhLEVBQUUsRUFBRTtTQUNwQixDQUFDO0lBUUUsQ0FBQztJQUVMLFFBQVE7UUFFSixJQUFJLE9BQU8sSUFBSSxDQUFDLFNBQVMsS0FBSyxXQUFXO1lBQUUsSUFBSSxDQUFDLFNBQVMsR0FBRyxLQUFLLENBQUM7UUFFbEUsUUFBUSxJQUFJLENBQUMsU0FBUyxFQUFFO1lBQ3BCLEtBQUssS0FBSztnQkFDTixJQUFJLENBQUMsY0FBYyxDQUFDLElBQUksR0FBRyxjQUFjLENBQUM7Z0JBQzFDLE1BQU07WUFDVjtnQkFDSSxJQUFJLENBQUMsY0FBYyxDQUFDLElBQUksR0FBRyxjQUFjLENBQUM7Z0JBQzFDLE1BQU07U0FDYjtRQUVELElBQUksQ0FBQyxZQUFZLEdBQUcsTUFBTSxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsY0FBYyxFQUFFLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQztJQUN4RSxDQUFDO0lBRUQsUUFBUTtRQUNKLElBQUksSUFBSSxDQUFDLFlBQVksQ0FBQyxRQUFRLEtBQUssRUFBRSxFQUFFO1lBQ25DLElBQUksQ0FBQyxPQUFPLENBQUMsUUFBUSxDQUFDLENBQUMsR0FBRyxHQUFHLElBQUksQ0FBQyxZQUFZLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQztTQUM3RDthQUNJO1lBQ0QsT0FBTyxDQUFDLEdBQUcsQ0FBQyw4QkFBOEIsQ0FBQyxDQUFDO1NBQy9DO0lBQ0wsQ0FBQztJQUVELElBQUk7UUFDQSwrRUFBK0U7UUFDL0UsNkJBQTZCO1FBQzdCLFdBQVc7UUFDWCx3REFBd0Q7UUFDeEQsSUFBSTtRQUNKLElBQUksSUFBSSxDQUFDLFlBQVksQ0FBQyxRQUFRLEtBQUssRUFBRSxFQUFFO1lBQ25DLElBQUksQ0FBQyxPQUFPLENBQUMsUUFBUSxDQUFDLENBQUMsR0FBRyxHQUFHLElBQUksQ0FBQyxZQUFZLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQztTQUM3RDthQUFNO1lBQ0gsT0FBTyxDQUFDLEdBQUcsQ0FBQyw4QkFBOEIsQ0FBQyxDQUFDO1NBQy9DO0lBQ0wsQ0FBQzs7O1lBMURKLFNBQVMsU0FBQztnQkFDUCxRQUFRLEVBQUUsVUFBVTtnQkFDcEIsdzNDQUFzQzthQUN6Qzs7O1lBTlEsUUFBUTtZQUNSLE1BQU07OztxQkFnQlYsS0FBSzt3QkFDTCxLQUFLLFNBQUMsWUFBWSIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IENvbXBvbmVudCwgSW5wdXQsIE9uSW5pdCB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xyXG5pbXBvcnQgeyBMb2NhdGlvbiB9IGZyb20gJ0Bhbmd1bGFyL2NvbW1vbic7XHJcbmltcG9ydCB7IFJvdXRlciB9IGZyb20gJ0Bhbmd1bGFyL3JvdXRlcic7XHJcblxyXG5AQ29tcG9uZW50KHtcclxuICAgIHNlbGVjdG9yOiAna2QtZXJyb3InLFxyXG4gICAgdGVtcGxhdGVVcmw6ICcuL2tkLWFuZ3VsYXItZXJyb3IuaHRtbCcsXHJcbn0pXHJcblxyXG5leHBvcnQgY2xhc3MgS2RFcnJvciBpbXBsZW1lbnRzIE9uSW5pdCB7XHJcbiAgICBwdWJsaWMgX2ZpbmFsQ29uZmlnOiBhbnkgPSB7fTtcclxuICAgIHByaXZhdGUgX2RlZmF1bHRDb25maWc6IGFueSA9IHtcclxuICAgICAgICBob21lUGF0aDogJycsXHJcbiAgICAgICAgZW1haWw6ICdzdXBwb3J0QG9wZW5lbWlzLm9yZycsXHJcbiAgICAgICAgYmFja1BhdGg6ICcnLFxyXG4gICAgICAgIGZvcmJpZGRlblBhdGg6ICcnXHJcbiAgICB9O1xyXG5cclxuICAgIEBJbnB1dCgpIGNvbmZpZzogYW55O1xyXG4gICAgQElucHV0KCdlcnJvci10eXBlJykgZXJyb3JUeXBlOiBzdHJpbmc7XHJcblxyXG4gICAgY29uc3RydWN0b3IoXHJcbiAgICAgICAgcHJvdGVjdGVkIF9sb2NhdGlvbjogTG9jYXRpb24sXHJcbiAgICAgICAgcHJvdGVjdGVkIF9yb3V0ZXI6IFJvdXRlclxyXG4gICAgKSB7IH1cclxuXHJcbiAgICBuZ09uSW5pdCgpOiB2b2lkIHtcclxuXHJcbiAgICAgICAgaWYgKHR5cGVvZiB0aGlzLmVycm9yVHlwZSA9PT0gJ3VuZGVmaW5lZCcpIHRoaXMuZXJyb3JUeXBlID0gJzQwMyc7XHJcblxyXG4gICAgICAgIHN3aXRjaCAodGhpcy5lcnJvclR5cGUpIHtcclxuICAgICAgICAgICAgY2FzZSAnNDA0JzpcclxuICAgICAgICAgICAgICAgIHRoaXMuX2RlZmF1bHRDb25maWcuaWNvbiA9ICdrZC00MDQtZXJyb3InO1xyXG4gICAgICAgICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgICAgIGRlZmF1bHQ6XHJcbiAgICAgICAgICAgICAgICB0aGlzLl9kZWZhdWx0Q29uZmlnLmljb24gPSAna2QtNDAzLWVycm9yJztcclxuICAgICAgICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgdGhpcy5fZmluYWxDb25maWcgPSBPYmplY3QuYXNzaWduKHRoaXMuX2RlZmF1bHRDb25maWcsIHRoaXMuY29uZmlnKTtcclxuICAgIH1cclxuXHJcbiAgICByZWRpcmVjdCgpIHtcclxuICAgICAgICBpZiAodGhpcy5fZmluYWxDb25maWcuaG9tZVBhdGggIT09ICcnKSB7XHJcbiAgICAgICAgICAgIHRoaXMuX3JvdXRlci5uYXZpZ2F0ZShbJy4nICsgdGhpcy5fZmluYWxDb25maWcuaG9tZVBhdGhdKTtcclxuICAgICAgICB9XHJcbiAgICAgICAgZWxzZSB7XHJcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKCdQbGVhc2Ugc3BlY2lmeSB0aGUgaG9tZSBwYXRoJyk7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIGJhY2soKSB7XHJcbiAgICAgICAgLy8gaWYodHlwZW9mIHRoaXMuY29uZmlnLmJhY2tidG4gPT09ICd1bmRlZmluZWQnIHx8IHRoaXMuY29uZmlnLmJhY2tidG4gPT0nJykge1xyXG4gICAgICAgIC8vICAgICB0aGlzLl9sb2NhdGlvbi5iYWNrKCk7XHJcbiAgICAgICAgLy8gfSBlbHNlIHtcclxuICAgICAgICAvLyAgICAgdGhpcy5fcm91dGVyLm5hdmlnYXRlKFsnLicrdGhpcy5jb25maWcuYmFja2J0bl0pO1xyXG4gICAgICAgIC8vIH1cclxuICAgICAgICBpZiAodGhpcy5fZmluYWxDb25maWcuYmFja1BhdGggIT09ICcnKSB7XHJcbiAgICAgICAgICAgIHRoaXMuX3JvdXRlci5uYXZpZ2F0ZShbJy4nICsgdGhpcy5fZmluYWxDb25maWcuYmFja1BhdGhdKTtcclxuICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICBjb25zb2xlLmxvZygnUGxlYXNlIHNwZWNpZnkgdGhlIGJhY2sgcGF0aCcpO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxufVxyXG4iXX0=