import { Injectable } from '@angular/core';
import { KdBroadcaster } from '../kd-common/index';
export class KdLeftmenuSvc {
    constructor(broadcaster) {
        this.broadcaster = broadcaster;
    }
    // set isOpen property to objects with list (lv1, lv2, lv3) - nested navs
    setIsOpen(_sideConfig) {
        if (typeof _sideConfig === 'undefined')
            return [];
        let updateResult = _sideConfig.slice();
        this._processNavItem(updateResult);
        return updateResult;
    }
    isArrayEqual(currentItem, previousItem) {
        if (currentItem.length !== previousItem.length) {
            return false;
        }
        for (let i = 0; i < currentItem.length; i++) {
            if (currentItem[i] !== previousItem[i]) {
                return false;
            }
        }
        return true;
    }
    getId(item) {
        let nav_id = (typeof item === 'string') ? item : item.nav_id;
        let currentId = nav_id.split('-');
        currentId.splice(0, 1);
        for (let i = 0; i < currentId.length; i++) {
            currentId[i] = +currentId[i];
        }
        return currentId;
    }
    closeDifferent(currentItem, previousItem, _navItems) {
        let currentNode = {};
        let previousCurrentNode = {};
        let previousNode;
        let diffBranch = false;
        for (let i = 0; i < previousItem.length; i++) {
            if (i === 0) {
                previousCurrentNode = _navItems[previousItem[i]];
                currentNode = _navItems[currentItem[i]];
            }
            else {
                previousCurrentNode = previousCurrentNode.list[previousItem[i]];
                if (typeof currentItem[i] !== 'undefined') {
                    currentNode = currentNode.list[currentItem[i]];
                }
                else {
                    currentNode = undefined;
                }
            }
            /**********set the previous node to true only when there is next node*******************
            e.g.
              previous node open -    0 0 0          previous node open -  0 0 0
              current node open  -    0              current node open  -  0 0
              current node should be closed          current node at index 0 is open, index 1 is closed
            *********************************************************************************/
            if (previousCurrentNode.hasOwnProperty('isOpen')) {
                if (typeof previousNode !== 'undefined' && typeof currentItem[i] !== 'undefined') {
                    previousNode.isOpen = true;
                }
                if (currentItem[i] === previousItem[i] && diffBranch === false) {
                    previousNode = previousCurrentNode;
                    previousCurrentNode.isOpen = false;
                }
                else {
                    diffBranch = true;
                    previousCurrentNode.isOpen = false;
                    if (typeof currentNode !== 'undefined') {
                        if (typeof currentNode.isOpen !== 'undefined')
                            currentNode.isOpen = true;
                        else
                            currentNode.isSelected = true;
                    }
                }
            }
        }
    }
    toggleState(currentId, state, _navItems) {
        let currentNode = {};
        for (let i = 0; i < currentId.length; i++) {
            currentNode = (i === 0) ? _navItems[currentId[i]] : currentNode.list[currentId[i]];
            if (typeof currentNode.isOpen !== 'undefined') {
                if (state === 'open') {
                    currentNode.isOpen = true;
                }
                else if (state === 'close') {
                    currentNode.isOpen = false;
                }
                else if (state === 'toggle' && i === currentId.length - 1) {
                    currentNode.isOpen = !currentNode.isOpen;
                }
            }
            else if (typeof currentNode.isSelected !== 'undefined' && i === currentId.length - 1) {
                currentNode.isSelected = false;
            }
        }
    }
    _processNavItem(_navItems, _prefix) {
        for (let i = 0; i < _navItems.length; i++) {
            let itemId = this._idFormatter(i, _prefix);
            _navItems[i]['nav_id'] = itemId;
            this._checkNavItem(_navItems[i], itemId);
        }
    }
    _checkNavItem(_item, _prefix) {
        if (typeof _item.list !== 'undefined') {
            _item.isOpen = false;
            this._processNavItem(_item.list, _prefix);
        }
        else {
            _item.isSelected = false;
            if (typeof _item.basePath === 'undefined') {
                _item.basePath = _item.path;
            }
        }
    }
    _idFormatter(_number, _prefix) {
        let prefix = (typeof _prefix === 'undefined') ? 'nav' : _prefix;
        let formatString = prefix;
        formatString += '-' + _number.toString();
        return formatString;
    }
    /* For API Usage  */
    onMenuItemClicked() {
        return this.broadcaster.on('KdGridsterEvent_onRemoved');
    }
    menuItemClicked(_item) {
        this.broadcaster.broadcast('KdGridsterEvent_onRemoved');
    }
}
KdLeftmenuSvc.decorators = [
    { type: Injectable }
];
KdLeftmenuSvc.ctorParameters = () => [
    { type: KdBroadcaster }
];
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoia2QtYW5ndWxhci1sZWZ0bWVudS1zdmMuanMiLCJzb3VyY2VSb290IjoiQzovUHJvamVjdHMvQW5ndWxhci9pb3N0Zy1vcGVuZW1pcy1zdHlsZWd1aWRlL3Byb2plY3RzL29wZW5lbWlzLXN0eWxlZ3VpZGUtbGliL3NyYy8iLCJzb3VyY2VzIjpbImtkLWNvbXBvbmVudHMva2QtYW5ndWxhci1sZWZ0bWVudS9rZC1hbmd1bGFyLWxlZnRtZW51LXN2Yy50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQSxPQUFPLEVBQUUsVUFBVSxFQUFFLE1BQU0sZUFBZSxDQUFDO0FBQzNDLE9BQU8sRUFBRSxhQUFhLEVBQUUsTUFBTSxvQkFBb0IsQ0FBQztBQUluRCxNQUFNLE9BQU8sYUFBYTtJQUN0QixZQUFvQixXQUEwQjtRQUExQixnQkFBVyxHQUFYLFdBQVcsQ0FBZTtJQUFJLENBQUM7SUFFbkQseUVBQXlFO0lBQ2xFLFNBQVMsQ0FBQyxXQUF1QjtRQUNwQyxJQUFJLE9BQU8sV0FBVyxLQUFLLFdBQVc7WUFBRSxPQUFPLEVBQUUsQ0FBQztRQUVsRCxJQUFJLFlBQVksR0FBZSxXQUFXLENBQUMsS0FBSyxFQUFFLENBQUM7UUFDbkQsSUFBSSxDQUFDLGVBQWUsQ0FBQyxZQUFZLENBQUMsQ0FBQztRQUVuQyxPQUFPLFlBQVksQ0FBQztJQUN4QixDQUFDO0lBRU0sWUFBWSxDQUFDLFdBQTBCLEVBQUUsWUFBMkI7UUFDdkUsSUFBSSxXQUFXLENBQUMsTUFBTSxLQUFLLFlBQVksQ0FBQyxNQUFNLEVBQUU7WUFDNUMsT0FBTyxLQUFLLENBQUM7U0FDaEI7UUFDRCxLQUFLLElBQUksQ0FBQyxHQUFXLENBQUMsRUFBRSxDQUFDLEdBQUcsV0FBVyxDQUFDLE1BQU0sRUFBRSxDQUFDLEVBQUUsRUFBRTtZQUNqRCxJQUFJLFdBQVcsQ0FBQyxDQUFDLENBQUMsS0FBSyxZQUFZLENBQUMsQ0FBQyxDQUFDLEVBQUU7Z0JBQ3BDLE9BQU8sS0FBSyxDQUFDO2FBQ2hCO1NBQ0o7UUFDRCxPQUFPLElBQUksQ0FBQztJQUNoQixDQUFDO0lBR00sS0FBSyxDQUFDLElBQWtCO1FBQzNCLElBQUksTUFBTSxHQUFXLENBQUMsT0FBTyxJQUFJLEtBQUssUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQztRQUNyRSxJQUFJLFNBQVMsR0FBZSxNQUFNLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDO1FBQzlDLFNBQVMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDO1FBRXZCLEtBQUssSUFBSSxDQUFDLEdBQVcsQ0FBQyxFQUFFLENBQUMsR0FBRyxTQUFTLENBQUMsTUFBTSxFQUFFLENBQUMsRUFBRSxFQUFFO1lBQy9DLFNBQVMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQztTQUNoQztRQUNELE9BQU8sU0FBUyxDQUFDO0lBQ3JCLENBQUM7SUFFTSxjQUFjLENBQUMsV0FBMEIsRUFBRSxZQUEyQixFQUFFLFNBQXFCO1FBQ2hHLElBQUksV0FBVyxHQUFRLEVBQUUsQ0FBQztRQUMxQixJQUFJLG1CQUFtQixHQUFRLEVBQUUsQ0FBQztRQUNsQyxJQUFJLFlBQWlCLENBQUM7UUFDdEIsSUFBSSxVQUFVLEdBQVksS0FBSyxDQUFDO1FBRWhDLEtBQUssSUFBSSxDQUFDLEdBQVcsQ0FBQyxFQUFFLENBQUMsR0FBRyxZQUFZLENBQUMsTUFBTSxFQUFFLENBQUMsRUFBRSxFQUFFO1lBQ2xELElBQUksQ0FBQyxLQUFLLENBQUMsRUFBRTtnQkFDVCxtQkFBbUIsR0FBRyxTQUFTLENBQUMsWUFBWSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7Z0JBQ2pELFdBQVcsR0FBRyxTQUFTLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7YUFDM0M7aUJBQ0k7Z0JBQ0QsbUJBQW1CLEdBQUcsbUJBQW1CLENBQUMsSUFBSSxDQUFDLFlBQVksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO2dCQUNoRSxJQUFJLE9BQU8sV0FBVyxDQUFDLENBQUMsQ0FBQyxLQUFLLFdBQVcsRUFBRTtvQkFDdkMsV0FBVyxHQUFHLFdBQVcsQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7aUJBQ2xEO3FCQUNJO29CQUNELFdBQVcsR0FBRyxTQUFTLENBQUM7aUJBQzNCO2FBQ0o7WUFFRDs7Ozs7OEZBS2tGO1lBR2xGLElBQUksbUJBQW1CLENBQUMsY0FBYyxDQUFDLFFBQVEsQ0FBQyxFQUFFO2dCQUM5QyxJQUFJLE9BQU8sWUFBWSxLQUFLLFdBQVcsSUFBSSxPQUFPLFdBQVcsQ0FBQyxDQUFDLENBQUMsS0FBSyxXQUFXLEVBQUU7b0JBQzlFLFlBQVksQ0FBQyxNQUFNLEdBQUcsSUFBSSxDQUFDO2lCQUM5QjtnQkFFRCxJQUFJLFdBQVcsQ0FBQyxDQUFDLENBQUMsS0FBSyxZQUFZLENBQUMsQ0FBQyxDQUFDLElBQUksVUFBVSxLQUFLLEtBQUssRUFBRTtvQkFDNUQsWUFBWSxHQUFHLG1CQUFtQixDQUFDO29CQUNuQyxtQkFBbUIsQ0FBQyxNQUFNLEdBQUcsS0FBSyxDQUFDO2lCQUN0QztxQkFDSTtvQkFDRCxVQUFVLEdBQUcsSUFBSSxDQUFDO29CQUNsQixtQkFBbUIsQ0FBQyxNQUFNLEdBQUcsS0FBSyxDQUFDO29CQUNuQyxJQUFJLE9BQU8sV0FBVyxLQUFLLFdBQVcsRUFBRTt3QkFDcEMsSUFBSSxPQUFPLFdBQVcsQ0FBQyxNQUFNLEtBQUssV0FBVzs0QkFBRSxXQUFXLENBQUMsTUFBTSxHQUFHLElBQUksQ0FBQzs7NEJBQ3BFLFdBQVcsQ0FBQyxVQUFVLEdBQUcsSUFBSSxDQUFDO3FCQUN0QztpQkFDSjthQUNKO1NBQ0o7SUFDTCxDQUFDO0lBRU0sV0FBVyxDQUFDLFNBQXFCLEVBQUUsS0FBYSxFQUFFLFNBQXFCO1FBQzFFLElBQUksV0FBVyxHQUFRLEVBQUUsQ0FBQztRQUMxQixLQUFLLElBQUksQ0FBQyxHQUFXLENBQUMsRUFBRSxDQUFDLEdBQUcsU0FBUyxDQUFDLE1BQU0sRUFBRSxDQUFDLEVBQUUsRUFBRTtZQUUvQyxXQUFXLEdBQUcsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsV0FBVyxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztZQUduRixJQUFJLE9BQU8sV0FBVyxDQUFDLE1BQU0sS0FBSyxXQUFXLEVBQUU7Z0JBQzNDLElBQUksS0FBSyxLQUFLLE1BQU0sRUFBRTtvQkFDbEIsV0FBVyxDQUFDLE1BQU0sR0FBRyxJQUFJLENBQUM7aUJBQzdCO3FCQUVJLElBQUksS0FBSyxLQUFLLE9BQU8sRUFBRTtvQkFDeEIsV0FBVyxDQUFDLE1BQU0sR0FBRyxLQUFLLENBQUM7aUJBQzlCO3FCQUVJLElBQUksS0FBSyxLQUFLLFFBQVEsSUFBSSxDQUFDLEtBQUssU0FBUyxDQUFDLE1BQU0sR0FBRyxDQUFDLEVBQUU7b0JBQ3ZELFdBQVcsQ0FBQyxNQUFNLEdBQUcsQ0FBQyxXQUFXLENBQUMsTUFBTSxDQUFDO2lCQUM1QzthQUNKO2lCQUNJLElBQUksT0FBTyxXQUFXLENBQUMsVUFBVSxLQUFLLFdBQVcsSUFBSSxDQUFDLEtBQUssU0FBUyxDQUFDLE1BQU0sR0FBRyxDQUFDLEVBQUU7Z0JBQ2xGLFdBQVcsQ0FBQyxVQUFVLEdBQUcsS0FBSyxDQUFDO2FBQ2xDO1NBQ0o7SUFDTCxDQUFDO0lBR08sZUFBZSxDQUFDLFNBQXFCLEVBQUUsT0FBZ0I7UUFDM0QsS0FBSyxJQUFJLENBQUMsR0FBVyxDQUFDLEVBQUUsQ0FBQyxHQUFHLFNBQVMsQ0FBQyxNQUFNLEVBQUUsQ0FBQyxFQUFFLEVBQUU7WUFDL0MsSUFBSSxNQUFNLEdBQVcsSUFBSSxDQUFDLFlBQVksQ0FBQyxDQUFDLEVBQUUsT0FBTyxDQUFDLENBQUM7WUFDbkQsU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxHQUFHLE1BQU0sQ0FBQztZQUNoQyxJQUFJLENBQUMsYUFBYSxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsRUFBRSxNQUFNLENBQUMsQ0FBQztTQUM1QztJQUNMLENBQUM7SUFFTyxhQUFhLENBQUMsS0FBVSxFQUFFLE9BQWdCO1FBQzlDLElBQUksT0FBTyxLQUFLLENBQUMsSUFBSSxLQUFLLFdBQVcsRUFBRTtZQUNuQyxLQUFLLENBQUMsTUFBTSxHQUFHLEtBQUssQ0FBQztZQUNyQixJQUFJLENBQUMsZUFBZSxDQUFDLEtBQUssQ0FBQyxJQUFJLEVBQUUsT0FBTyxDQUFDLENBQUM7U0FDN0M7YUFDSTtZQUNELEtBQUssQ0FBQyxVQUFVLEdBQUcsS0FBSyxDQUFDO1lBQ3pCLElBQUksT0FBTyxLQUFLLENBQUMsUUFBUSxLQUFLLFdBQVcsRUFBRTtnQkFDdkMsS0FBSyxDQUFDLFFBQVEsR0FBRyxLQUFLLENBQUMsSUFBSSxDQUFDO2FBQy9CO1NBQ0o7SUFDTCxDQUFDO0lBRU8sWUFBWSxDQUFDLE9BQWUsRUFBRSxPQUFnQjtRQUNsRCxJQUFJLE1BQU0sR0FBVyxDQUFDLE9BQU8sT0FBTyxLQUFLLFdBQVcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQztRQUN4RSxJQUFJLFlBQVksR0FBRyxNQUFNLENBQUM7UUFDMUIsWUFBWSxJQUFJLEdBQUcsR0FBRyxPQUFPLENBQUMsUUFBUSxFQUFFLENBQUM7UUFDekMsT0FBTyxZQUFZLENBQUM7SUFDeEIsQ0FBQztJQUdELG9CQUFvQjtJQUViLGlCQUFpQjtRQUNwQixPQUFPLElBQUksQ0FBQyxXQUFXLENBQUMsRUFBRSxDQUFNLDJCQUEyQixDQUFDLENBQUM7SUFDakUsQ0FBQztJQUVNLGVBQWUsQ0FBQyxLQUFVO1FBQzdCLElBQUksQ0FBQyxXQUFXLENBQUMsU0FBUyxDQUFDLDJCQUEyQixDQUFDLENBQUM7SUFDNUQsQ0FBQzs7O1lBeEpKLFVBQVU7OztZQUhGLGFBQWEiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBJbmplY3RhYmxlIH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XHJcbmltcG9ydCB7IEtkQnJvYWRjYXN0ZXIgfSBmcm9tICcuLi9rZC1jb21tb24vaW5kZXgnO1xyXG5pbXBvcnQgeyBPYnNlcnZhYmxlIH0gZnJvbSAncnhqcyc7XHJcblxyXG5ASW5qZWN0YWJsZSgpXHJcbmV4cG9ydCBjbGFzcyBLZExlZnRtZW51U3ZjIHtcclxuICAgIGNvbnN0cnVjdG9yKHByaXZhdGUgYnJvYWRjYXN0ZXI6IEtkQnJvYWRjYXN0ZXIpIHsgfVxyXG5cclxuICAgIC8vIHNldCBpc09wZW4gcHJvcGVydHkgdG8gb2JqZWN0cyB3aXRoIGxpc3QgKGx2MSwgbHYyLCBsdjMpIC0gbmVzdGVkIG5hdnNcclxuICAgIHB1YmxpYyBzZXRJc09wZW4oX3NpZGVDb25maWc6IEFycmF5PGFueT4pOiBBcnJheTxhbnk+IHtcclxuICAgICAgICBpZiAodHlwZW9mIF9zaWRlQ29uZmlnID09PSAndW5kZWZpbmVkJykgcmV0dXJuIFtdO1xyXG5cclxuICAgICAgICBsZXQgdXBkYXRlUmVzdWx0OiBBcnJheTxhbnk+ID0gX3NpZGVDb25maWcuc2xpY2UoKTtcclxuICAgICAgICB0aGlzLl9wcm9jZXNzTmF2SXRlbSh1cGRhdGVSZXN1bHQpO1xyXG5cclxuICAgICAgICByZXR1cm4gdXBkYXRlUmVzdWx0O1xyXG4gICAgfVxyXG5cclxuICAgIHB1YmxpYyBpc0FycmF5RXF1YWwoY3VycmVudEl0ZW06IEFycmF5PG51bWJlcj4sIHByZXZpb3VzSXRlbTogQXJyYXk8bnVtYmVyPik6IGJvb2xlYW4ge1xyXG4gICAgICAgIGlmIChjdXJyZW50SXRlbS5sZW5ndGggIT09IHByZXZpb3VzSXRlbS5sZW5ndGgpIHtcclxuICAgICAgICAgICAgcmV0dXJuIGZhbHNlO1xyXG4gICAgICAgIH1cclxuICAgICAgICBmb3IgKGxldCBpOiBudW1iZXIgPSAwOyBpIDwgY3VycmVudEl0ZW0ubGVuZ3RoOyBpKyspIHtcclxuICAgICAgICAgICAgaWYgKGN1cnJlbnRJdGVtW2ldICE9PSBwcmV2aW91c0l0ZW1baV0pIHtcclxuICAgICAgICAgICAgICAgIHJldHVybiBmYWxzZTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgICAgICByZXR1cm4gdHJ1ZTtcclxuICAgIH1cclxuXHJcblxyXG4gICAgcHVibGljIGdldElkKGl0ZW06IGFueSB8IHN0cmluZyk6IEFycmF5PG51bWJlcj4ge1xyXG4gICAgICAgIGxldCBuYXZfaWQ6IHN0cmluZyA9ICh0eXBlb2YgaXRlbSA9PT0gJ3N0cmluZycpID8gaXRlbSA6IGl0ZW0ubmF2X2lkO1xyXG4gICAgICAgIGxldCBjdXJyZW50SWQ6IEFycmF5PGFueT4gPSBuYXZfaWQuc3BsaXQoJy0nKTtcclxuICAgICAgICBjdXJyZW50SWQuc3BsaWNlKDAsIDEpO1xyXG5cclxuICAgICAgICBmb3IgKGxldCBpOiBudW1iZXIgPSAwOyBpIDwgY3VycmVudElkLmxlbmd0aDsgaSsrKSB7XHJcbiAgICAgICAgICAgIGN1cnJlbnRJZFtpXSA9ICtjdXJyZW50SWRbaV07XHJcbiAgICAgICAgfVxyXG4gICAgICAgIHJldHVybiBjdXJyZW50SWQ7XHJcbiAgICB9XHJcblxyXG4gICAgcHVibGljIGNsb3NlRGlmZmVyZW50KGN1cnJlbnRJdGVtOiBBcnJheTxudW1iZXI+LCBwcmV2aW91c0l0ZW06IEFycmF5PG51bWJlcj4sIF9uYXZJdGVtczogQXJyYXk8YW55Pik6IHZvaWQge1xyXG4gICAgICAgIGxldCBjdXJyZW50Tm9kZTogYW55ID0ge307XHJcbiAgICAgICAgbGV0IHByZXZpb3VzQ3VycmVudE5vZGU6IGFueSA9IHt9O1xyXG4gICAgICAgIGxldCBwcmV2aW91c05vZGU6IGFueTtcclxuICAgICAgICBsZXQgZGlmZkJyYW5jaDogYm9vbGVhbiA9IGZhbHNlO1xyXG5cclxuICAgICAgICBmb3IgKGxldCBpOiBudW1iZXIgPSAwOyBpIDwgcHJldmlvdXNJdGVtLmxlbmd0aDsgaSsrKSB7XHJcbiAgICAgICAgICAgIGlmIChpID09PSAwKSB7XHJcbiAgICAgICAgICAgICAgICBwcmV2aW91c0N1cnJlbnROb2RlID0gX25hdkl0ZW1zW3ByZXZpb3VzSXRlbVtpXV07XHJcbiAgICAgICAgICAgICAgICBjdXJyZW50Tm9kZSA9IF9uYXZJdGVtc1tjdXJyZW50SXRlbVtpXV07XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgZWxzZSB7XHJcbiAgICAgICAgICAgICAgICBwcmV2aW91c0N1cnJlbnROb2RlID0gcHJldmlvdXNDdXJyZW50Tm9kZS5saXN0W3ByZXZpb3VzSXRlbVtpXV07XHJcbiAgICAgICAgICAgICAgICBpZiAodHlwZW9mIGN1cnJlbnRJdGVtW2ldICE9PSAndW5kZWZpbmVkJykge1xyXG4gICAgICAgICAgICAgICAgICAgIGN1cnJlbnROb2RlID0gY3VycmVudE5vZGUubGlzdFtjdXJyZW50SXRlbVtpXV07XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgICAgICAgICBjdXJyZW50Tm9kZSA9IHVuZGVmaW5lZDtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgLyoqKioqKioqKipzZXQgdGhlIHByZXZpb3VzIG5vZGUgdG8gdHJ1ZSBvbmx5IHdoZW4gdGhlcmUgaXMgbmV4dCBub2RlKioqKioqKioqKioqKioqKioqKlxyXG4gICAgICAgICAgICBlLmcuXHJcbiAgICAgICAgICAgICAgcHJldmlvdXMgbm9kZSBvcGVuIC0gICAgMCAwIDAgICAgICAgICAgcHJldmlvdXMgbm9kZSBvcGVuIC0gIDAgMCAwXHJcbiAgICAgICAgICAgICAgY3VycmVudCBub2RlIG9wZW4gIC0gICAgMCAgICAgICAgICAgICAgY3VycmVudCBub2RlIG9wZW4gIC0gIDAgMFxyXG4gICAgICAgICAgICAgIGN1cnJlbnQgbm9kZSBzaG91bGQgYmUgY2xvc2VkICAgICAgICAgIGN1cnJlbnQgbm9kZSBhdCBpbmRleCAwIGlzIG9wZW4sIGluZGV4IDEgaXMgY2xvc2VkXHJcbiAgICAgICAgICAgICoqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKi9cclxuXHJcblxyXG4gICAgICAgICAgICBpZiAocHJldmlvdXNDdXJyZW50Tm9kZS5oYXNPd25Qcm9wZXJ0eSgnaXNPcGVuJykpIHtcclxuICAgICAgICAgICAgICAgIGlmICh0eXBlb2YgcHJldmlvdXNOb2RlICE9PSAndW5kZWZpbmVkJyAmJiB0eXBlb2YgY3VycmVudEl0ZW1baV0gIT09ICd1bmRlZmluZWQnKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgcHJldmlvdXNOb2RlLmlzT3BlbiA9IHRydWU7XHJcbiAgICAgICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICAgICAgaWYgKGN1cnJlbnRJdGVtW2ldID09PSBwcmV2aW91c0l0ZW1baV0gJiYgZGlmZkJyYW5jaCA9PT0gZmFsc2UpIHtcclxuICAgICAgICAgICAgICAgICAgICBwcmV2aW91c05vZGUgPSBwcmV2aW91c0N1cnJlbnROb2RlO1xyXG4gICAgICAgICAgICAgICAgICAgIHByZXZpb3VzQ3VycmVudE5vZGUuaXNPcGVuID0gZmFsc2U7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgICAgICAgICBkaWZmQnJhbmNoID0gdHJ1ZTtcclxuICAgICAgICAgICAgICAgICAgICBwcmV2aW91c0N1cnJlbnROb2RlLmlzT3BlbiA9IGZhbHNlO1xyXG4gICAgICAgICAgICAgICAgICAgIGlmICh0eXBlb2YgY3VycmVudE5vZGUgIT09ICd1bmRlZmluZWQnKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGlmICh0eXBlb2YgY3VycmVudE5vZGUuaXNPcGVuICE9PSAndW5kZWZpbmVkJykgY3VycmVudE5vZGUuaXNPcGVuID0gdHJ1ZTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgZWxzZSBjdXJyZW50Tm9kZS5pc1NlbGVjdGVkID0gdHJ1ZTtcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgcHVibGljIHRvZ2dsZVN0YXRlKGN1cnJlbnRJZDogQXJyYXk8YW55Piwgc3RhdGU6IHN0cmluZywgX25hdkl0ZW1zOiBBcnJheTxhbnk+KTogdm9pZCB7XHJcbiAgICAgICAgbGV0IGN1cnJlbnROb2RlOiBhbnkgPSB7fTtcclxuICAgICAgICBmb3IgKGxldCBpOiBudW1iZXIgPSAwOyBpIDwgY3VycmVudElkLmxlbmd0aDsgaSsrKSB7XHJcblxyXG4gICAgICAgICAgICBjdXJyZW50Tm9kZSA9IChpID09PSAwKSA/IF9uYXZJdGVtc1tjdXJyZW50SWRbaV1dIDogY3VycmVudE5vZGUubGlzdFtjdXJyZW50SWRbaV1dO1xyXG5cclxuXHJcbiAgICAgICAgICAgIGlmICh0eXBlb2YgY3VycmVudE5vZGUuaXNPcGVuICE9PSAndW5kZWZpbmVkJykge1xyXG4gICAgICAgICAgICAgICAgaWYgKHN0YXRlID09PSAnb3BlbicpIHtcclxuICAgICAgICAgICAgICAgICAgICBjdXJyZW50Tm9kZS5pc09wZW4gPSB0cnVlO1xyXG4gICAgICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgICAgIGVsc2UgaWYgKHN0YXRlID09PSAnY2xvc2UnKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgY3VycmVudE5vZGUuaXNPcGVuID0gZmFsc2U7XHJcbiAgICAgICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICAgICAgZWxzZSBpZiAoc3RhdGUgPT09ICd0b2dnbGUnICYmIGkgPT09IGN1cnJlbnRJZC5sZW5ndGggLSAxKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgY3VycmVudE5vZGUuaXNPcGVuID0gIWN1cnJlbnROb2RlLmlzT3BlbjtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBlbHNlIGlmICh0eXBlb2YgY3VycmVudE5vZGUuaXNTZWxlY3RlZCAhPT0gJ3VuZGVmaW5lZCcgJiYgaSA9PT0gY3VycmVudElkLmxlbmd0aCAtIDEpIHtcclxuICAgICAgICAgICAgICAgIGN1cnJlbnROb2RlLmlzU2VsZWN0ZWQgPSBmYWxzZTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcblxyXG4gICAgcHJpdmF0ZSBfcHJvY2Vzc05hdkl0ZW0oX25hdkl0ZW1zOiBBcnJheTxhbnk+LCBfcHJlZml4Pzogc3RyaW5nKTogdm9pZCB7XHJcbiAgICAgICAgZm9yIChsZXQgaTogbnVtYmVyID0gMDsgaSA8IF9uYXZJdGVtcy5sZW5ndGg7IGkrKykge1xyXG4gICAgICAgICAgICBsZXQgaXRlbUlkOiBzdHJpbmcgPSB0aGlzLl9pZEZvcm1hdHRlcihpLCBfcHJlZml4KTtcclxuICAgICAgICAgICAgX25hdkl0ZW1zW2ldWyduYXZfaWQnXSA9IGl0ZW1JZDtcclxuICAgICAgICAgICAgdGhpcy5fY2hlY2tOYXZJdGVtKF9uYXZJdGVtc1tpXSwgaXRlbUlkKTtcclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfY2hlY2tOYXZJdGVtKF9pdGVtOiBhbnksIF9wcmVmaXg/OiBzdHJpbmcpOiB2b2lkIHtcclxuICAgICAgICBpZiAodHlwZW9mIF9pdGVtLmxpc3QgIT09ICd1bmRlZmluZWQnKSB7XHJcbiAgICAgICAgICAgIF9pdGVtLmlzT3BlbiA9IGZhbHNlO1xyXG4gICAgICAgICAgICB0aGlzLl9wcm9jZXNzTmF2SXRlbShfaXRlbS5saXN0LCBfcHJlZml4KTtcclxuICAgICAgICB9XHJcbiAgICAgICAgZWxzZSB7XHJcbiAgICAgICAgICAgIF9pdGVtLmlzU2VsZWN0ZWQgPSBmYWxzZTtcclxuICAgICAgICAgICAgaWYgKHR5cGVvZiBfaXRlbS5iYXNlUGF0aCA9PT0gJ3VuZGVmaW5lZCcpIHtcclxuICAgICAgICAgICAgICAgIF9pdGVtLmJhc2VQYXRoID0gX2l0ZW0ucGF0aDtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF9pZEZvcm1hdHRlcihfbnVtYmVyOiBudW1iZXIsIF9wcmVmaXg/OiBzdHJpbmcpOiBzdHJpbmcge1xyXG4gICAgICAgIGxldCBwcmVmaXg6IHN0cmluZyA9ICh0eXBlb2YgX3ByZWZpeCA9PT0gJ3VuZGVmaW5lZCcpID8gJ25hdicgOiBfcHJlZml4O1xyXG4gICAgICAgIGxldCBmb3JtYXRTdHJpbmcgPSBwcmVmaXg7XHJcbiAgICAgICAgZm9ybWF0U3RyaW5nICs9ICctJyArIF9udW1iZXIudG9TdHJpbmcoKTtcclxuICAgICAgICByZXR1cm4gZm9ybWF0U3RyaW5nO1xyXG4gICAgfVxyXG5cclxuXHJcbiAgICAvKiBGb3IgQVBJIFVzYWdlICAqL1xyXG5cclxuICAgIHB1YmxpYyBvbk1lbnVJdGVtQ2xpY2tlZCgpOiBPYnNlcnZhYmxlPGFueT4ge1xyXG4gICAgICAgIHJldHVybiB0aGlzLmJyb2FkY2FzdGVyLm9uPGFueT4oJ0tkR3JpZHN0ZXJFdmVudF9vblJlbW92ZWQnKTtcclxuICAgIH1cclxuXHJcbiAgICBwdWJsaWMgbWVudUl0ZW1DbGlja2VkKF9pdGVtOiBhbnkpOiB2b2lkIHtcclxuICAgICAgICB0aGlzLmJyb2FkY2FzdGVyLmJyb2FkY2FzdCgnS2RHcmlkc3RlckV2ZW50X29uUmVtb3ZlZCcpO1xyXG4gICAgfVxyXG59XHJcbiJdfQ==