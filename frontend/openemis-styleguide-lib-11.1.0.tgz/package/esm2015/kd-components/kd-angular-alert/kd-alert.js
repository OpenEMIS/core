import { Component, ViewEncapsulation } from '@angular/core';
import { ToasterService, ToasterConfig } from 'angular2-toaster';
import { KdAlertEvent } from './kd-alert-event';
export class KdAlert {
    constructor(_toasterService, _kdAlertEvent) {
        this._toasterService = _toasterService;
        this._kdAlertEvent = _kdAlertEvent;
        this._toasterDefaultConfig = {
            showCloseButton: true,
            tapToDismiss: false,
            timeout: -1,
            limit: 5,
            positionClass: 'toast-top-right'
        };
    }
    ngOnInit() {
        this.registerAlertBroadcast();
    }
    registerAlertBroadcast() {
        this._kdAlertEvent.on()
            .subscribe(_toast => {
            this._config = Object.assign({}, this._toasterDefaultConfig, _toast);
            this._toasterconfig = new ToasterConfig(this._config);
            this._toasterService.pop(_toast);
            // this._toasterService.pop('success', 'Args Title', 'Args Body');;
        });
    }
}
KdAlert.decorators = [
    { type: Component, args: [{
                selector: 'kd-alert',
                providers: [ToasterService, KdAlertEvent],
                encapsulation: ViewEncapsulation.None,
                template: `
        <toaster-container [toasterconfig]='_toasterconfig'>
        </toaster-container>
       `
            },] }
];
KdAlert.ctorParameters = () => [
    { type: ToasterService },
    { type: KdAlertEvent }
];
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoia2QtYWxlcnQuanMiLCJzb3VyY2VSb290IjoiQzovUHJvamVjdHMvQW5ndWxhci9pb3N0Zy1vcGVuZW1pcy1zdHlsZWd1aWRlL3Byb2plY3RzL29wZW5lbWlzLXN0eWxlZ3VpZGUtbGliL3NyYy8iLCJzb3VyY2VzIjpbImtkLWNvbXBvbmVudHMva2QtYW5ndWxhci1hbGVydC9rZC1hbGVydC50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQSxPQUFPLEVBQUUsU0FBUyxFQUFFLGlCQUFpQixFQUFVLE1BQU0sZUFBZSxDQUFDO0FBQ3JFLE9BQU8sRUFBRSxjQUFjLEVBQUUsYUFBYSxFQUFDLE1BQU0sa0JBQWtCLENBQUM7QUFDaEUsT0FBTyxFQUFFLFlBQVksRUFBRSxNQUFNLGtCQUFrQixDQUFDO0FBWWhELE1BQU0sT0FBTyxPQUFPO0lBV2hCLFlBQ1ksZUFBK0IsRUFDL0IsYUFBMkI7UUFEM0Isb0JBQWUsR0FBZixlQUFlLENBQWdCO1FBQy9CLGtCQUFhLEdBQWIsYUFBYSxDQUFjO1FBVi9CLDBCQUFxQixHQUFRO1lBQ2pDLGVBQWUsRUFBRSxJQUFJO1lBQ3JCLFlBQVksRUFBRSxLQUFLO1lBQ25CLE9BQU8sRUFBRSxDQUFDLENBQUM7WUFDWCxLQUFLLEVBQUUsQ0FBQztZQUNSLGFBQWEsRUFBRSxpQkFBaUI7U0FDbkMsQ0FBQztJQUtFLENBQUM7SUFFTCxRQUFRO1FBQ0osSUFBSSxDQUFDLHNCQUFzQixFQUFFLENBQUM7SUFDbEMsQ0FBQztJQUVELHNCQUFzQjtRQUNsQixJQUFJLENBQUMsYUFBYSxDQUFDLEVBQUUsRUFBRTthQUNsQixTQUFTLENBQUMsTUFBTSxDQUFDLEVBQUU7WUFDaEIsSUFBSSxDQUFDLE9BQU8sR0FBRyxNQUFNLENBQUMsTUFBTSxDQUFDLEVBQUUsRUFBRSxJQUFJLENBQUMscUJBQXFCLEVBQUUsTUFBTSxDQUFDLENBQUM7WUFDckUsSUFBSSxDQUFDLGNBQWMsR0FBRyxJQUFJLGFBQWEsQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLENBQUM7WUFDdEQsSUFBSSxDQUFDLGVBQWUsQ0FBQyxHQUFHLENBQUMsTUFBTSxDQUFDLENBQUM7WUFDakMsbUVBQW1FO1FBQ3ZFLENBQUMsQ0FBQyxDQUFDO0lBQ1gsQ0FBQzs7O1lBdENKLFNBQVMsU0FBQztnQkFDUCxRQUFRLEVBQUUsVUFBVTtnQkFDcEIsU0FBUyxFQUFFLENBQUMsY0FBYyxFQUFFLFlBQVksQ0FBQztnQkFDekMsYUFBYSxFQUFFLGlCQUFpQixDQUFDLElBQUk7Z0JBQ3JDLFFBQVEsRUFBRTs7O1FBR047YUFDUDs7O1lBWFEsY0FBYztZQUNkLFlBQVkiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBDb21wb25lbnQsIFZpZXdFbmNhcHN1bGF0aW9uLCBPbkluaXQgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcclxuaW1wb3J0IHsgVG9hc3RlclNlcnZpY2UsIFRvYXN0ZXJDb25maWd9IGZyb20gJ2FuZ3VsYXIyLXRvYXN0ZXInO1xyXG5pbXBvcnQgeyBLZEFsZXJ0RXZlbnQgfSBmcm9tICcuL2tkLWFsZXJ0LWV2ZW50JztcclxuXHJcbkBDb21wb25lbnQoe1xyXG4gICAgc2VsZWN0b3I6ICdrZC1hbGVydCcsXHJcbiAgICBwcm92aWRlcnM6IFtUb2FzdGVyU2VydmljZSwgS2RBbGVydEV2ZW50XSxcclxuICAgIGVuY2Fwc3VsYXRpb246IFZpZXdFbmNhcHN1bGF0aW9uLk5vbmUsXHJcbiAgICB0ZW1wbGF0ZTogYFxyXG4gICAgICAgIDx0b2FzdGVyLWNvbnRhaW5lciBbdG9hc3RlcmNvbmZpZ109J190b2FzdGVyY29uZmlnJz5cclxuICAgICAgICA8L3RvYXN0ZXItY29udGFpbmVyPlxyXG4gICAgICAgYCxcclxufSlcclxuXHJcbmV4cG9ydCBjbGFzcyBLZEFsZXJ0IGltcGxlbWVudHMgT25Jbml0IHtcclxuICAgIHB1YmxpYyBfdG9hc3RlcmNvbmZpZzogVG9hc3RlckNvbmZpZztcclxuICAgIHByaXZhdGUgX2NvbmZpZzogYW55O1xyXG4gICAgcHJpdmF0ZSBfdG9hc3RlckRlZmF1bHRDb25maWc6IGFueSA9IHtcclxuICAgICAgICBzaG93Q2xvc2VCdXR0b246IHRydWUsXHJcbiAgICAgICAgdGFwVG9EaXNtaXNzOiBmYWxzZSxcclxuICAgICAgICB0aW1lb3V0OiAtMSxcclxuICAgICAgICBsaW1pdDogNSxcclxuICAgICAgICBwb3NpdGlvbkNsYXNzOiAndG9hc3QtdG9wLXJpZ2h0J1xyXG4gICAgfTtcclxuXHJcbiAgICBjb25zdHJ1Y3RvcihcclxuICAgICAgICBwcml2YXRlIF90b2FzdGVyU2VydmljZTogVG9hc3RlclNlcnZpY2UsXHJcbiAgICAgICAgcHJpdmF0ZSBfa2RBbGVydEV2ZW50OiBLZEFsZXJ0RXZlbnRcclxuICAgICkgeyB9XHJcblxyXG4gICAgbmdPbkluaXQoKTogdm9pZCB7XHJcbiAgICAgICAgdGhpcy5yZWdpc3RlckFsZXJ0QnJvYWRjYXN0KCk7XHJcbiAgICB9XHJcblxyXG4gICAgcmVnaXN0ZXJBbGVydEJyb2FkY2FzdCgpOiB2b2lkIHtcclxuICAgICAgICB0aGlzLl9rZEFsZXJ0RXZlbnQub24oKVxyXG4gICAgICAgICAgICAuc3Vic2NyaWJlKF90b2FzdCA9PiB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLl9jb25maWcgPSBPYmplY3QuYXNzaWduKHt9LCB0aGlzLl90b2FzdGVyRGVmYXVsdENvbmZpZywgX3RvYXN0KTtcclxuICAgICAgICAgICAgICAgIHRoaXMuX3RvYXN0ZXJjb25maWcgPSBuZXcgVG9hc3RlckNvbmZpZyh0aGlzLl9jb25maWcpO1xyXG4gICAgICAgICAgICAgICAgdGhpcy5fdG9hc3RlclNlcnZpY2UucG9wKF90b2FzdCk7XHJcbiAgICAgICAgICAgICAgICAvLyB0aGlzLl90b2FzdGVyU2VydmljZS5wb3AoJ3N1Y2Nlc3MnLCAnQXJncyBUaXRsZScsICdBcmdzIEJvZHknKTs7XHJcbiAgICAgICAgICAgIH0pO1xyXG4gICAgfVxyXG5cclxufVxyXG4iXX0=