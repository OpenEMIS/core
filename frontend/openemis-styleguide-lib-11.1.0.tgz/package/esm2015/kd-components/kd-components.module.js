import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
// third party plugins
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { ToasterModule } from 'angular2-toaster';
import { AgGridModule } from 'ag-grid-angular';
import { CalendarModule, DateAdapter } from 'angular-calendar';
import { GridsterModule } from 'angular-gridster2';
import { AutoCompleteModule } from 'primeng/autocomplete';
import { DropdownModule } from 'primeng/dropdown';
import { MenuModule } from 'primeng/menu';
import { ButtonModule } from 'primeng/button';
import { TooltipModule } from 'primeng/tooltip';
import { ChartModule } from 'primeng/chart';
import { TreeModule } from 'primeng/tree';
import { SharedModule } from 'primeng/api';
import { SliderModule } from 'primeng/slider';
import { PaginatorModule } from 'primeng/paginator';
// OpenEMIS component list
// import { KD_COMPONENTS_PVDERS, getProdInfo } from './kd-components.provider';
import { KdHeader } from './kd-angular-header/index';
import { KdSplitter, KdPane } from './kd-angular-splitter/index';
import { KdFooter } from './kd-angular-footer/index';
import { KdLeftMenu } from './kd-angular-leftmenu/index';
import { KdBreadcrumb } from './kd-angular-breadcrumb/index';
import { KdPageheader, KdToolbar } from './kd-angular-pageheader/index';
import { KdAlert } from './kd-angular-alert/index';
import { KdTemplateLayout } from './kd-angular-template-layout/index';
import { KdCodeblock } from './kd-angular-codeblock/kd-angular-codeblock';
import { KdTabs } from './kd-angular-tabs/index';
import { KdLogin, KdLoginForm } from './kd-angular-login/index';
import { KdError } from './kd-angular-error/index';
import { KdAdvFilter } from './kd-angular-adv-filter/index';
import { KdView } from './kd-angular-view/index';
import { KdSlider, KdSliderContent } from './kd-angular-slider/index';
import { KdTable, KdTableAction, KdTableCheckboxRadio, KdTableInput, KdTableImage } from './kd-angular-table/index';
import { KdTooltip, KdTooltipDirective } from './kd-angular-tooltip/index';
import { KdInput } from './kd-angular-input/kd-angular-input';
import { KdButtonGroup } from './kd-angular-button-group/index';
import { KdPlaceholder } from './kd-angular-placeholder/index';
import { KdModal } from './kd-angular-modal/index';
import { KdTextInput } from './kd-angular-text-input/index';
import { KdMultiSelectTable } from './kd-angular-multiselect-table/index';
import { KdCheckboxRadio } from './kd-angular-checkbox-radio/index';
import { KdDatepicker } from './kd-angular-datepicker/index';
import { KdTimepicker } from './kd-angular-timepicker/index';
import { KdTreeDropdown } from './kd-angular-treedropdown/index';
import { KdProgressloader } from './kd-angular-progressloader/index';
import { KdFileInput } from './kd-angular-fileinput/index';
import { KdMap } from './kd-angular-map/index';
import { KdFilter } from './kd-angular-filter/index';
import { KdSearch } from './kd-angular-search/index';
import { KdDelete } from './kd-angular-delete-comp/index';
import { KdFonts, FilterArrayPipe } from './kd-angular-fonts/index';
import { KdMiniDashboard, KdMiniDashboardChart } from './kd-angular-mini-dashboard/index';
import { KdWizard } from './kd-angular-wizard/index';
import { KdCalendar } from './kd-angular-calendar/index';
import { KdMindmap, KdMindmapNode, KdMindmapLink, KdMindmapZoomDirective, KdMindmapDragDirective, KdMindmapZoomButton } from './kd-angular-mindmap/index';
import { KdGridster, KdGridsterToolbar } from './kd-angular-gridster/index';
import { KdCharts, KdBarChart, KdLineChart, KdPieChart, KdMapChart } from './kd-angular-charts/index';
import { KdVisualization } from './kd-angular-visualization/index';
import { adapterFactory } from 'angular-calendar/date-adapters/date-fns';
import { KdChat } from './kd-angular-chat/kd-angular-chat';
import { DragDropDirective } from './kd-angular-fileinput/dropzone.directive';
const ɵ0 = adapterFactory;
export class KdComponentsModule {
}
KdComponentsModule.decorators = [
    { type: NgModule, args: [{
                imports: [
                    CommonModule,
                    FormsModule,
                    ReactiveFormsModule,
                    NgbModule,
                    ToasterModule,
                    TreeModule,
                    SharedModule,
                    AutoCompleteModule,
                    DropdownModule,
                    MenuModule,
                    ButtonModule,
                    TooltipModule,
                    ChartModule,
                    SliderModule,
                    PaginatorModule,
                    AgGridModule.withComponents([
                        KdTableAction,
                        KdTableCheckboxRadio,
                        KdTableInput,
                        KdTableImage
                    ]),
                    CalendarModule.forRoot({
                        provide: DateAdapter,
                        useFactory: ɵ0
                    }),
                    GridsterModule
                ],
                declarations: [
                    KdHeader,
                    KdFooter,
                    KdSplitter,
                    KdPane,
                    KdBreadcrumb,
                    KdLeftMenu,
                    KdPageheader,
                    KdToolbar,
                    KdAlert,
                    KdTemplateLayout,
                    KdCodeblock,
                    KdTabs,
                    KdLogin,
                    KdLoginForm,
                    KdError,
                    KdAdvFilter,
                    KdView,
                    KdSlider,
                    KdSliderContent,
                    KdTable,
                    KdChat,
                    KdTableAction,
                    KdTableCheckboxRadio,
                    KdTableImage,
                    KdTableInput,
                    KdTooltip,
                    KdTooltipDirective,
                    KdInput,
                    KdTextInput,
                    KdButtonGroup,
                    KdPlaceholder,
                    KdModal,
                    KdMultiSelectTable,
                    KdCheckboxRadio,
                    KdDatepicker,
                    KdTimepicker,
                    KdTreeDropdown,
                    KdProgressloader,
                    KdFileInput,
                    DragDropDirective,
                    KdMap,
                    KdFilter,
                    KdSearch,
                    KdDelete,
                    KdFonts,
                    FilterArrayPipe,
                    KdMiniDashboard,
                    KdMiniDashboardChart,
                    KdWizard,
                    KdCalendar,
                    KdMindmap,
                    KdMindmapNode,
                    KdMindmapLink,
                    KdMindmapZoomDirective,
                    KdMindmapDragDirective,
                    KdMindmapZoomButton,
                    KdGridster,
                    KdGridsterToolbar,
                    KdCharts,
                    KdBarChart,
                    KdLineChart,
                    KdPieChart,
                    KdMapChart,
                    KdVisualization,
                ],
                exports: [
                    PaginatorModule,
                    MenuModule,
                    CommonModule,
                    FormsModule,
                    ReactiveFormsModule,
                    KdHeader,
                    KdFooter,
                    KdSplitter,
                    KdPane,
                    KdBreadcrumb,
                    KdLeftMenu,
                    KdPageheader,
                    KdToolbar,
                    KdAlert,
                    KdTemplateLayout,
                    KdCodeblock,
                    KdTabs,
                    KdLogin,
                    KdLoginForm,
                    KdError,
                    KdAdvFilter,
                    KdView,
                    KdSlider,
                    KdSliderContent,
                    KdTable,
                    KdChat,
                    KdTableAction,
                    KdTableCheckboxRadio,
                    KdTableInput,
                    KdTableImage,
                    KdTooltip,
                    KdTooltipDirective,
                    KdInput,
                    KdTextInput,
                    KdButtonGroup,
                    KdPlaceholder,
                    KdModal,
                    KdMultiSelectTable,
                    KdCheckboxRadio,
                    KdDatepicker,
                    KdTimepicker,
                    KdTreeDropdown,
                    KdProgressloader,
                    KdFileInput,
                    DragDropDirective,
                    KdMap,
                    KdFilter,
                    KdSearch,
                    KdDelete,
                    KdFonts,
                    FilterArrayPipe,
                    KdMiniDashboard,
                    KdMiniDashboardChart,
                    KdWizard,
                    KdCalendar,
                    KdMindmap,
                    KdMindmapNode,
                    KdMindmapLink,
                    KdMindmapZoomDirective,
                    KdMindmapDragDirective,
                    KdMindmapZoomButton,
                    KdGridster,
                    KdGridsterToolbar,
                    KdCharts,
                    KdBarChart,
                    KdLineChart,
                    KdPieChart,
                    KdMapChart,
                    KdVisualization
                ]
            },] }
];
export { ɵ0 };
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoia2QtY29tcG9uZW50cy5tb2R1bGUuanMiLCJzb3VyY2VSb290IjoiQzovUHJvamVjdHMvQW5ndWxhci9pb3N0Zy1vcGVuZW1pcy1zdHlsZWd1aWRlL3Byb2plY3RzL29wZW5lbWlzLXN0eWxlZ3VpZGUtbGliL3NyYy8iLCJzb3VyY2VzIjpbImtkLWNvbXBvbmVudHMva2QtY29tcG9uZW50cy5tb2R1bGUudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsT0FBTyxFQUFFLFFBQVEsRUFBMEMsTUFBTSxlQUFlLENBQUM7QUFDakYsT0FBTyxFQUFFLFlBQVksRUFBRSxNQUFNLGlCQUFpQixDQUFDO0FBQy9DLE9BQU8sRUFBRSxXQUFXLEVBQUUsbUJBQW1CLEVBQUUsTUFBTSxnQkFBZ0IsQ0FBQztBQUVsRSxzQkFBc0I7QUFDdEIsT0FBTyxFQUFFLFNBQVMsRUFBRSxNQUFNLDRCQUE0QixDQUFDO0FBQ3ZELE9BQU8sRUFBRSxhQUFhLEVBQUUsTUFBTSxrQkFBa0IsQ0FBQztBQUNqRCxPQUFPLEVBQUUsWUFBWSxFQUFFLE1BQU0saUJBQWlCLENBQUM7QUFDL0MsT0FBTyxFQUFFLGNBQWMsRUFBRSxXQUFXLEVBQUUsTUFBTSxrQkFBa0IsQ0FBQztBQUMvRCxPQUFPLEVBQUUsY0FBYyxFQUFFLE1BQU0sbUJBQW1CLENBQUM7QUFDbkQsT0FBTyxFQUFFLGtCQUFrQixFQUFFLE1BQU0sc0JBQXNCLENBQUM7QUFDMUQsT0FBTyxFQUFFLGNBQWMsRUFBRSxNQUFNLGtCQUFrQixDQUFDO0FBQ2xELE9BQU8sRUFBRSxVQUFVLEVBQUUsTUFBTSxjQUFjLENBQUM7QUFDMUMsT0FBTyxFQUFFLFlBQVksRUFBRSxNQUFNLGdCQUFnQixDQUFDO0FBQzlDLE9BQU8sRUFBRSxhQUFhLEVBQUUsTUFBTSxpQkFBaUIsQ0FBQztBQUNoRCxPQUFPLEVBQUUsV0FBVyxFQUFFLE1BQU0sZUFBZSxDQUFDO0FBQzVDLE9BQU8sRUFBRSxVQUFVLEVBQUUsTUFBTSxjQUFjLENBQUM7QUFFMUMsT0FBTyxFQUFFLFlBQVksRUFBRSxNQUFNLGFBQWEsQ0FBQztBQUMzQyxPQUFPLEVBQUUsWUFBWSxFQUFFLE1BQU0sZ0JBQWdCLENBQUM7QUFDOUMsT0FBTyxFQUFFLGVBQWUsRUFBRSxNQUFNLG1CQUFtQixDQUFDO0FBSXBELDBCQUEwQjtBQUMxQixnRkFBZ0Y7QUFFaEYsT0FBTyxFQUFFLFFBQVEsRUFBRSxNQUFNLDJCQUEyQixDQUFDO0FBQ3JELE9BQU8sRUFBRSxVQUFVLEVBQUUsTUFBTSxFQUFFLE1BQU0sNkJBQTZCLENBQUM7QUFDakUsT0FBTyxFQUFFLFFBQVEsRUFBRSxNQUFNLDJCQUEyQixDQUFDO0FBQ3JELE9BQU8sRUFBRSxVQUFVLEVBQUUsTUFBTSw2QkFBNkIsQ0FBQztBQUN6RCxPQUFPLEVBQUUsWUFBWSxFQUFFLE1BQU0sK0JBQStCLENBQUM7QUFDN0QsT0FBTyxFQUFFLFlBQVksRUFBRSxTQUFTLEVBQUUsTUFBTSwrQkFBK0IsQ0FBQztBQUN4RSxPQUFPLEVBQUUsT0FBTyxFQUFFLE1BQU0sMEJBQTBCLENBQUM7QUFDbkQsT0FBTyxFQUFFLGdCQUFnQixFQUFFLE1BQU0sb0NBQW9DLENBQUM7QUFDdEUsT0FBTyxFQUFFLFdBQVcsRUFBRSxNQUFNLDZDQUE2QyxDQUFDO0FBQzFFLE9BQU8sRUFBRSxNQUFNLEVBQUUsTUFBTSx5QkFBeUIsQ0FBQztBQUNqRCxPQUFPLEVBQUUsT0FBTyxFQUFFLFdBQVcsRUFBRSxNQUFNLDBCQUEwQixDQUFDO0FBQ2hFLE9BQU8sRUFBRSxPQUFPLEVBQUUsTUFBTSwwQkFBMEIsQ0FBQztBQUVuRCxPQUFPLEVBQUUsV0FBVyxFQUFFLE1BQU0sK0JBQStCLENBQUM7QUFDNUQsT0FBTyxFQUFFLE1BQU0sRUFBRSxNQUFNLHlCQUF5QixDQUFDO0FBQ2pELE9BQU8sRUFBRSxRQUFRLEVBQUUsZUFBZSxFQUFFLE1BQU0sMkJBQTJCLENBQUM7QUFDdEUsT0FBTyxFQUNILE9BQU8sRUFDUCxhQUFhLEVBQ2Isb0JBQW9CLEVBQ3BCLFlBQVksRUFDWixZQUFZLEVBQ2YsTUFBTSwwQkFBMEIsQ0FBQztBQUNsQyxPQUFPLEVBQUUsU0FBUyxFQUFFLGtCQUFrQixFQUFFLE1BQU0sNEJBQTRCLENBQUM7QUFDM0UsT0FBTyxFQUFFLE9BQU8sRUFBRSxNQUFNLHFDQUFxQyxDQUFDO0FBQzlELE9BQU8sRUFBRSxhQUFhLEVBQUUsTUFBTSxpQ0FBaUMsQ0FBQztBQUNoRSxPQUFPLEVBQUUsYUFBYSxFQUFFLE1BQU0sZ0NBQWdDLENBQUM7QUFDL0QsT0FBTyxFQUFFLE9BQU8sRUFBRSxNQUFNLDBCQUEwQixDQUFDO0FBQ25ELE9BQU8sRUFBRSxXQUFXLEVBQUUsTUFBTSwrQkFBK0IsQ0FBQztBQUM1RCxPQUFPLEVBQUUsa0JBQWtCLEVBQUUsTUFBTSxzQ0FBc0MsQ0FBQztBQUUxRSxPQUFPLEVBQUUsZUFBZSxFQUFFLE1BQU0sbUNBQW1DLENBQUM7QUFDcEUsT0FBTyxFQUFFLFlBQVksRUFBRSxNQUFNLCtCQUErQixDQUFDO0FBQzdELE9BQU8sRUFBRSxZQUFZLEVBQUUsTUFBTSwrQkFBK0IsQ0FBQztBQUM3RCxPQUFPLEVBQUUsY0FBYyxFQUFFLE1BQU0saUNBQWlDLENBQUM7QUFDakUsT0FBTyxFQUFFLGdCQUFnQixFQUFFLE1BQU0sbUNBQW1DLENBQUM7QUFDckUsT0FBTyxFQUFFLFdBQVcsRUFBRSxNQUFNLDhCQUE4QixDQUFDO0FBQzNELE9BQU8sRUFBRSxLQUFLLEVBQUUsTUFBTSx3QkFBd0IsQ0FBQztBQUMvQyxPQUFPLEVBQUUsUUFBUSxFQUFFLE1BQU0sMkJBQTJCLENBQUM7QUFDckQsT0FBTyxFQUFFLFFBQVEsRUFBRSxNQUFNLDJCQUEyQixDQUFDO0FBRXJELE9BQU8sRUFBRSxRQUFRLEVBQUUsTUFBTSxnQ0FBZ0MsQ0FBQztBQUUxRCxPQUFPLEVBQUUsT0FBTyxFQUFFLGVBQWUsRUFBRSxNQUFNLDBCQUEwQixDQUFDO0FBRXBFLE9BQU8sRUFBRSxlQUFlLEVBQUUsb0JBQW9CLEVBQUUsTUFBTSxtQ0FBbUMsQ0FBQztBQUMxRixPQUFPLEVBQUUsUUFBUSxFQUFFLE1BQU0sMkJBQTJCLENBQUM7QUFDckQsT0FBTyxFQUFFLFVBQVUsRUFBRSxNQUFNLDZCQUE2QixDQUFDO0FBQ3pELE9BQU8sRUFDSCxTQUFTLEVBQ1QsYUFBYSxFQUNiLGFBQWEsRUFDYixzQkFBc0IsRUFDdEIsc0JBQXNCLEVBQ3RCLG1CQUFtQixFQUN0QixNQUFNLDRCQUE0QixDQUFDO0FBQ3BDLE9BQU8sRUFBRSxVQUFVLEVBQUUsaUJBQWlCLEVBQUUsTUFBTSw2QkFBNkIsQ0FBQztBQUM1RSxPQUFPLEVBQ0gsUUFBUSxFQUNSLFVBQVUsRUFDVixXQUFXLEVBQ1gsVUFBVSxFQUNWLFVBQVUsRUFDYixNQUFNLDJCQUEyQixDQUFDO0FBQ25DLE9BQU8sRUFBRSxlQUFlLEVBQUUsTUFBTSxrQ0FBa0MsQ0FBQztBQUNuRSxPQUFPLEVBQUUsY0FBYyxFQUFFLE1BQU0seUNBQXlDLENBQUM7QUFDekUsT0FBTyxFQUFFLE1BQU0sRUFBRSxNQUFNLG1DQUFtQyxDQUFDO0FBQzNELE9BQU8sRUFBRSxpQkFBaUIsRUFBRSxNQUFNLDJDQUEyQyxDQUFDO1dBMkJ0RCxjQUFjO0FBK0t0QyxNQUFNLE9BQU8sa0JBQWtCOzs7WUF4TTlCLFFBQVEsU0FBQztnQkFDTixPQUFPLEVBQUU7b0JBQ0wsWUFBWTtvQkFDWixXQUFXO29CQUNYLG1CQUFtQjtvQkFDbkIsU0FBUztvQkFDVCxhQUFhO29CQUNiLFVBQVU7b0JBQ1YsWUFBWTtvQkFDWixrQkFBa0I7b0JBQ2xCLGNBQWM7b0JBQ2QsVUFBVTtvQkFDVixZQUFZO29CQUNaLGFBQWE7b0JBQ2IsV0FBVztvQkFDWCxZQUFZO29CQUNaLGVBQWU7b0JBQ2YsWUFBWSxDQUFDLGNBQWMsQ0FBQzt3QkFDeEIsYUFBYTt3QkFDYixvQkFBb0I7d0JBQ3BCLFlBQVk7d0JBQ1osWUFBWTtxQkFDZixDQUFDO29CQUNGLGNBQWMsQ0FBQyxPQUFPLENBQUM7d0JBQ25CLE9BQU8sRUFBRSxXQUFXO3dCQUNwQixVQUFVLElBQWdCO3FCQUMzQixDQUFDO29CQUVKLGNBQWM7aUJBQ2pCO2dCQUNELFlBQVksRUFBRTtvQkFDVixRQUFRO29CQUNSLFFBQVE7b0JBQ1IsVUFBVTtvQkFDVixNQUFNO29CQUNOLFlBQVk7b0JBQ1osVUFBVTtvQkFDVixZQUFZO29CQUNaLFNBQVM7b0JBQ1QsT0FBTztvQkFDUCxnQkFBZ0I7b0JBQ2hCLFdBQVc7b0JBRVgsTUFBTTtvQkFFTixPQUFPO29CQUNQLFdBQVc7b0JBRVgsT0FBTztvQkFFUCxXQUFXO29CQUNYLE1BQU07b0JBQ04sUUFBUTtvQkFDUixlQUFlO29CQUNmLE9BQU87b0JBQ1AsTUFBTTtvQkFDTixhQUFhO29CQUNiLG9CQUFvQjtvQkFDcEIsWUFBWTtvQkFDWixZQUFZO29CQUVaLFNBQVM7b0JBQ1Qsa0JBQWtCO29CQUVsQixPQUFPO29CQUNQLFdBQVc7b0JBQ1gsYUFBYTtvQkFDYixhQUFhO29CQUNiLE9BQU87b0JBQ1Asa0JBQWtCO29CQUNsQixlQUFlO29CQUNmLFlBQVk7b0JBQ1osWUFBWTtvQkFDWixjQUFjO29CQUNkLGdCQUFnQjtvQkFDaEIsV0FBVztvQkFDWCxpQkFBaUI7b0JBQ2pCLEtBQUs7b0JBRUwsUUFBUTtvQkFDUixRQUFRO29CQUVSLFFBQVE7b0JBRVIsT0FBTztvQkFDUCxlQUFlO29CQUVmLGVBQWU7b0JBQ2Ysb0JBQW9CO29CQUVwQixRQUFRO29CQUVSLFVBQVU7b0JBRVYsU0FBUztvQkFDVCxhQUFhO29CQUNiLGFBQWE7b0JBQ2Isc0JBQXNCO29CQUN0QixzQkFBc0I7b0JBQ3RCLG1CQUFtQjtvQkFFbkIsVUFBVTtvQkFDVixpQkFBaUI7b0JBRWpCLFFBQVE7b0JBQ1IsVUFBVTtvQkFDVixXQUFXO29CQUNYLFVBQVU7b0JBQ1YsVUFBVTtvQkFDVixlQUFlO2lCQUNsQjtnQkFDRCxPQUFPLEVBQUU7b0JBQ0wsZUFBZTtvQkFDZixVQUFVO29CQUNWLFlBQVk7b0JBQ1osV0FBVztvQkFDWCxtQkFBbUI7b0JBRW5CLFFBQVE7b0JBQ1IsUUFBUTtvQkFDUixVQUFVO29CQUNWLE1BQU07b0JBQ04sWUFBWTtvQkFDWixVQUFVO29CQUNWLFlBQVk7b0JBQ1osU0FBUztvQkFDVCxPQUFPO29CQUNQLGdCQUFnQjtvQkFDaEIsV0FBVztvQkFFWCxNQUFNO29CQUVOLE9BQU87b0JBQ1AsV0FBVztvQkFFWCxPQUFPO29CQUVQLFdBQVc7b0JBQ1gsTUFBTTtvQkFDTixRQUFRO29CQUNSLGVBQWU7b0JBRWYsT0FBTztvQkFDUCxNQUFNO29CQUNOLGFBQWE7b0JBQ2Isb0JBQW9CO29CQUNwQixZQUFZO29CQUNaLFlBQVk7b0JBRVosU0FBUztvQkFDVCxrQkFBa0I7b0JBQ2xCLE9BQU87b0JBQ1AsV0FBVztvQkFDWCxhQUFhO29CQUNiLGFBQWE7b0JBQ2IsT0FBTztvQkFDUCxrQkFBa0I7b0JBR2xCLGVBQWU7b0JBQ2YsWUFBWTtvQkFDWixZQUFZO29CQUNaLGNBQWM7b0JBQ2QsZ0JBQWdCO29CQUNoQixXQUFXO29CQUNYLGlCQUFpQjtvQkFDakIsS0FBSztvQkFFTCxRQUFRO29CQUNSLFFBQVE7b0JBRVIsUUFBUTtvQkFFUixPQUFPO29CQUNQLGVBQWU7b0JBRWYsZUFBZTtvQkFDZixvQkFBb0I7b0JBQ3BCLFFBQVE7b0JBRVIsVUFBVTtvQkFFVixTQUFTO29CQUNULGFBQWE7b0JBQ2IsYUFBYTtvQkFDYixzQkFBc0I7b0JBQ3RCLHNCQUFzQjtvQkFDdEIsbUJBQW1CO29CQUVuQixVQUFVO29CQUNWLGlCQUFpQjtvQkFFakIsUUFBUTtvQkFDUixVQUFVO29CQUNWLFdBQVc7b0JBQ1gsVUFBVTtvQkFDVixVQUFVO29CQUNWLGVBQWU7aUJBQ2xCO2FBQ0oiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBOZ01vZHVsZSwgTW9kdWxlV2l0aFByb3ZpZGVycy8qLCBWYWx1ZVByb3ZpZGVyKi8gfSBmcm9tICdAYW5ndWxhci9jb3JlJztcclxuaW1wb3J0IHsgQ29tbW9uTW9kdWxlIH0gZnJvbSAnQGFuZ3VsYXIvY29tbW9uJztcclxuaW1wb3J0IHsgRm9ybXNNb2R1bGUsIFJlYWN0aXZlRm9ybXNNb2R1bGUgfSBmcm9tICdAYW5ndWxhci9mb3Jtcyc7XHJcblxyXG4vLyB0aGlyZCBwYXJ0eSBwbHVnaW5zXHJcbmltcG9ydCB7IE5nYk1vZHVsZSB9IGZyb20gJ0BuZy1ib290c3RyYXAvbmctYm9vdHN0cmFwJztcclxuaW1wb3J0IHsgVG9hc3Rlck1vZHVsZSB9IGZyb20gJ2FuZ3VsYXIyLXRvYXN0ZXInO1xyXG5pbXBvcnQgeyBBZ0dyaWRNb2R1bGUgfSBmcm9tICdhZy1ncmlkLWFuZ3VsYXInO1xyXG5pbXBvcnQgeyBDYWxlbmRhck1vZHVsZSwgRGF0ZUFkYXB0ZXIgfSBmcm9tICdhbmd1bGFyLWNhbGVuZGFyJztcclxuaW1wb3J0IHsgR3JpZHN0ZXJNb2R1bGUgfSBmcm9tICdhbmd1bGFyLWdyaWRzdGVyMic7XHJcbmltcG9ydCB7IEF1dG9Db21wbGV0ZU1vZHVsZSB9IGZyb20gJ3ByaW1lbmcvYXV0b2NvbXBsZXRlJztcclxuaW1wb3J0IHsgRHJvcGRvd25Nb2R1bGUgfSBmcm9tICdwcmltZW5nL2Ryb3Bkb3duJztcclxuaW1wb3J0IHsgTWVudU1vZHVsZSB9IGZyb20gJ3ByaW1lbmcvbWVudSc7XHJcbmltcG9ydCB7IEJ1dHRvbk1vZHVsZSB9IGZyb20gJ3ByaW1lbmcvYnV0dG9uJztcclxuaW1wb3J0IHsgVG9vbHRpcE1vZHVsZSB9IGZyb20gJ3ByaW1lbmcvdG9vbHRpcCc7XHJcbmltcG9ydCB7IENoYXJ0TW9kdWxlIH0gZnJvbSAncHJpbWVuZy9jaGFydCc7XHJcbmltcG9ydCB7IFRyZWVNb2R1bGUgfSBmcm9tICdwcmltZW5nL3RyZWUnO1xyXG5pbXBvcnQgeyBUcmVlTm9kZSB9IGZyb20gJ3ByaW1lbmcvYXBpJztcclxuaW1wb3J0IHsgU2hhcmVkTW9kdWxlIH0gZnJvbSAncHJpbWVuZy9hcGknO1xyXG5pbXBvcnQgeyBTbGlkZXJNb2R1bGUgfSBmcm9tICdwcmltZW5nL3NsaWRlcic7XHJcbmltcG9ydCB7IFBhZ2luYXRvck1vZHVsZSB9IGZyb20gJ3ByaW1lbmcvcGFnaW5hdG9yJztcclxuXHJcblxyXG5cclxuLy8gT3BlbkVNSVMgY29tcG9uZW50IGxpc3RcclxuLy8gaW1wb3J0IHsgS0RfQ09NUE9ORU5UU19QVkRFUlMsIGdldFByb2RJbmZvIH0gZnJvbSAnLi9rZC1jb21wb25lbnRzLnByb3ZpZGVyJztcclxuXHJcbmltcG9ydCB7IEtkSGVhZGVyIH0gZnJvbSAnLi9rZC1hbmd1bGFyLWhlYWRlci9pbmRleCc7XHJcbmltcG9ydCB7IEtkU3BsaXR0ZXIsIEtkUGFuZSB9IGZyb20gJy4va2QtYW5ndWxhci1zcGxpdHRlci9pbmRleCc7XHJcbmltcG9ydCB7IEtkRm9vdGVyIH0gZnJvbSAnLi9rZC1hbmd1bGFyLWZvb3Rlci9pbmRleCc7XHJcbmltcG9ydCB7IEtkTGVmdE1lbnUgfSBmcm9tICcuL2tkLWFuZ3VsYXItbGVmdG1lbnUvaW5kZXgnO1xyXG5pbXBvcnQgeyBLZEJyZWFkY3J1bWIgfSBmcm9tICcuL2tkLWFuZ3VsYXItYnJlYWRjcnVtYi9pbmRleCc7XHJcbmltcG9ydCB7IEtkUGFnZWhlYWRlciwgS2RUb29sYmFyIH0gZnJvbSAnLi9rZC1hbmd1bGFyLXBhZ2VoZWFkZXIvaW5kZXgnO1xyXG5pbXBvcnQgeyBLZEFsZXJ0IH0gZnJvbSAnLi9rZC1hbmd1bGFyLWFsZXJ0L2luZGV4JztcclxuaW1wb3J0IHsgS2RUZW1wbGF0ZUxheW91dCB9IGZyb20gJy4va2QtYW5ndWxhci10ZW1wbGF0ZS1sYXlvdXQvaW5kZXgnO1xyXG5pbXBvcnQgeyBLZENvZGVibG9jayB9IGZyb20gJy4va2QtYW5ndWxhci1jb2RlYmxvY2sva2QtYW5ndWxhci1jb2RlYmxvY2snO1xyXG5pbXBvcnQgeyBLZFRhYnMgfSBmcm9tICcuL2tkLWFuZ3VsYXItdGFicy9pbmRleCc7XHJcbmltcG9ydCB7IEtkTG9naW4sIEtkTG9naW5Gb3JtIH0gZnJvbSAnLi9rZC1hbmd1bGFyLWxvZ2luL2luZGV4JztcclxuaW1wb3J0IHsgS2RFcnJvciB9IGZyb20gJy4va2QtYW5ndWxhci1lcnJvci9pbmRleCc7XHJcblxyXG5pbXBvcnQgeyBLZEFkdkZpbHRlciB9IGZyb20gJy4va2QtYW5ndWxhci1hZHYtZmlsdGVyL2luZGV4JztcclxuaW1wb3J0IHsgS2RWaWV3IH0gZnJvbSAnLi9rZC1hbmd1bGFyLXZpZXcvaW5kZXgnO1xyXG5pbXBvcnQgeyBLZFNsaWRlciwgS2RTbGlkZXJDb250ZW50IH0gZnJvbSAnLi9rZC1hbmd1bGFyLXNsaWRlci9pbmRleCc7XHJcbmltcG9ydCB7XHJcbiAgICBLZFRhYmxlLFxyXG4gICAgS2RUYWJsZUFjdGlvbixcclxuICAgIEtkVGFibGVDaGVja2JveFJhZGlvLFxyXG4gICAgS2RUYWJsZUlucHV0LFxyXG4gICAgS2RUYWJsZUltYWdlXHJcbn0gZnJvbSAnLi9rZC1hbmd1bGFyLXRhYmxlL2luZGV4JztcclxuaW1wb3J0IHsgS2RUb29sdGlwLCBLZFRvb2x0aXBEaXJlY3RpdmUgfSBmcm9tICcuL2tkLWFuZ3VsYXItdG9vbHRpcC9pbmRleCc7XHJcbmltcG9ydCB7IEtkSW5wdXQgfSBmcm9tICcuL2tkLWFuZ3VsYXItaW5wdXQva2QtYW5ndWxhci1pbnB1dCc7XHJcbmltcG9ydCB7IEtkQnV0dG9uR3JvdXAgfSBmcm9tICcuL2tkLWFuZ3VsYXItYnV0dG9uLWdyb3VwL2luZGV4JztcclxuaW1wb3J0IHsgS2RQbGFjZWhvbGRlciB9IGZyb20gJy4va2QtYW5ndWxhci1wbGFjZWhvbGRlci9pbmRleCc7XHJcbmltcG9ydCB7IEtkTW9kYWwgfSBmcm9tICcuL2tkLWFuZ3VsYXItbW9kYWwvaW5kZXgnO1xyXG5pbXBvcnQgeyBLZFRleHRJbnB1dCB9IGZyb20gJy4va2QtYW5ndWxhci10ZXh0LWlucHV0L2luZGV4JztcclxuaW1wb3J0IHsgS2RNdWx0aVNlbGVjdFRhYmxlIH0gZnJvbSAnLi9rZC1hbmd1bGFyLW11bHRpc2VsZWN0LXRhYmxlL2luZGV4JztcclxuXHJcbmltcG9ydCB7IEtkQ2hlY2tib3hSYWRpbyB9IGZyb20gJy4va2QtYW5ndWxhci1jaGVja2JveC1yYWRpby9pbmRleCc7XHJcbmltcG9ydCB7IEtkRGF0ZXBpY2tlciB9IGZyb20gJy4va2QtYW5ndWxhci1kYXRlcGlja2VyL2luZGV4JztcclxuaW1wb3J0IHsgS2RUaW1lcGlja2VyIH0gZnJvbSAnLi9rZC1hbmd1bGFyLXRpbWVwaWNrZXIvaW5kZXgnO1xyXG5pbXBvcnQgeyBLZFRyZWVEcm9wZG93biB9IGZyb20gJy4va2QtYW5ndWxhci10cmVlZHJvcGRvd24vaW5kZXgnO1xyXG5pbXBvcnQgeyBLZFByb2dyZXNzbG9hZGVyIH0gZnJvbSAnLi9rZC1hbmd1bGFyLXByb2dyZXNzbG9hZGVyL2luZGV4JztcclxuaW1wb3J0IHsgS2RGaWxlSW5wdXQgfSBmcm9tICcuL2tkLWFuZ3VsYXItZmlsZWlucHV0L2luZGV4JztcclxuaW1wb3J0IHsgS2RNYXAgfSBmcm9tICcuL2tkLWFuZ3VsYXItbWFwL2luZGV4JztcclxuaW1wb3J0IHsgS2RGaWx0ZXIgfSBmcm9tICcuL2tkLWFuZ3VsYXItZmlsdGVyL2luZGV4JztcclxuaW1wb3J0IHsgS2RTZWFyY2ggfSBmcm9tICcuL2tkLWFuZ3VsYXItc2VhcmNoL2luZGV4JztcclxuXHJcbmltcG9ydCB7IEtkRGVsZXRlIH0gZnJvbSAnLi9rZC1hbmd1bGFyLWRlbGV0ZS1jb21wL2luZGV4JztcclxuXHJcbmltcG9ydCB7IEtkRm9udHMsIEZpbHRlckFycmF5UGlwZSB9IGZyb20gJy4va2QtYW5ndWxhci1mb250cy9pbmRleCc7XHJcblxyXG5pbXBvcnQgeyBLZE1pbmlEYXNoYm9hcmQsIEtkTWluaURhc2hib2FyZENoYXJ0IH0gZnJvbSAnLi9rZC1hbmd1bGFyLW1pbmktZGFzaGJvYXJkL2luZGV4JztcclxuaW1wb3J0IHsgS2RXaXphcmQgfSBmcm9tICcuL2tkLWFuZ3VsYXItd2l6YXJkL2luZGV4JztcclxuaW1wb3J0IHsgS2RDYWxlbmRhciB9IGZyb20gJy4va2QtYW5ndWxhci1jYWxlbmRhci9pbmRleCc7XHJcbmltcG9ydCB7XHJcbiAgICBLZE1pbmRtYXAsXHJcbiAgICBLZE1pbmRtYXBOb2RlLFxyXG4gICAgS2RNaW5kbWFwTGluayxcclxuICAgIEtkTWluZG1hcFpvb21EaXJlY3RpdmUsXHJcbiAgICBLZE1pbmRtYXBEcmFnRGlyZWN0aXZlLFxyXG4gICAgS2RNaW5kbWFwWm9vbUJ1dHRvblxyXG59IGZyb20gJy4va2QtYW5ndWxhci1taW5kbWFwL2luZGV4JztcclxuaW1wb3J0IHsgS2RHcmlkc3RlciwgS2RHcmlkc3RlclRvb2xiYXIgfSBmcm9tICcuL2tkLWFuZ3VsYXItZ3JpZHN0ZXIvaW5kZXgnO1xyXG5pbXBvcnQge1xyXG4gICAgS2RDaGFydHMsXHJcbiAgICBLZEJhckNoYXJ0LFxyXG4gICAgS2RMaW5lQ2hhcnQsXHJcbiAgICBLZFBpZUNoYXJ0LFxyXG4gICAgS2RNYXBDaGFydFxyXG59IGZyb20gJy4va2QtYW5ndWxhci1jaGFydHMvaW5kZXgnO1xyXG5pbXBvcnQgeyBLZFZpc3VhbGl6YXRpb24gfSBmcm9tICcuL2tkLWFuZ3VsYXItdmlzdWFsaXphdGlvbi9pbmRleCc7XHJcbmltcG9ydCB7IGFkYXB0ZXJGYWN0b3J5IH0gZnJvbSAnYW5ndWxhci1jYWxlbmRhci9kYXRlLWFkYXB0ZXJzL2RhdGUtZm5zJztcclxuaW1wb3J0IHsgS2RDaGF0IH0gZnJvbSAnLi9rZC1hbmd1bGFyLWNoYXQva2QtYW5ndWxhci1jaGF0JztcclxuaW1wb3J0IHsgRHJhZ0Ryb3BEaXJlY3RpdmUgfSBmcm9tICcuL2tkLWFuZ3VsYXItZmlsZWlucHV0L2Ryb3B6b25lLmRpcmVjdGl2ZSc7XHJcblxyXG5ATmdNb2R1bGUoe1xyXG4gICAgaW1wb3J0czogW1xyXG4gICAgICAgIENvbW1vbk1vZHVsZSxcclxuICAgICAgICBGb3Jtc01vZHVsZSxcclxuICAgICAgICBSZWFjdGl2ZUZvcm1zTW9kdWxlLFxyXG4gICAgICAgIE5nYk1vZHVsZSxcclxuICAgICAgICBUb2FzdGVyTW9kdWxlLFxyXG4gICAgICAgIFRyZWVNb2R1bGUsXHJcbiAgICAgICAgU2hhcmVkTW9kdWxlLFxyXG4gICAgICAgIEF1dG9Db21wbGV0ZU1vZHVsZSxcclxuICAgICAgICBEcm9wZG93bk1vZHVsZSxcclxuICAgICAgICBNZW51TW9kdWxlLFxyXG4gICAgICAgIEJ1dHRvbk1vZHVsZSxcclxuICAgICAgICBUb29sdGlwTW9kdWxlLFxyXG4gICAgICAgIENoYXJ0TW9kdWxlLFxyXG4gICAgICAgIFNsaWRlck1vZHVsZSxcclxuICAgICAgICBQYWdpbmF0b3JNb2R1bGUsIFxyXG4gICAgICAgIEFnR3JpZE1vZHVsZS53aXRoQ29tcG9uZW50cyhbXHJcbiAgICAgICAgICAgIEtkVGFibGVBY3Rpb24sXHJcbiAgICAgICAgICAgIEtkVGFibGVDaGVja2JveFJhZGlvLFxyXG4gICAgICAgICAgICBLZFRhYmxlSW5wdXQsXHJcbiAgICAgICAgICAgIEtkVGFibGVJbWFnZVxyXG4gICAgICAgIF0pLFxyXG4gICAgICAgIENhbGVuZGFyTW9kdWxlLmZvclJvb3Qoe1xyXG4gICAgICAgICAgICBwcm92aWRlOiBEYXRlQWRhcHRlcixcclxuICAgICAgICAgICAgdXNlRmFjdG9yeTogYWRhcHRlckZhY3RvcnlcclxuICAgICAgICAgIH0pLFxyXG5cclxuICAgICAgICBHcmlkc3Rlck1vZHVsZVxyXG4gICAgXSxcclxuICAgIGRlY2xhcmF0aW9uczogW1xyXG4gICAgICAgIEtkSGVhZGVyLFxyXG4gICAgICAgIEtkRm9vdGVyLFxyXG4gICAgICAgIEtkU3BsaXR0ZXIsXHJcbiAgICAgICAgS2RQYW5lLFxyXG4gICAgICAgIEtkQnJlYWRjcnVtYixcclxuICAgICAgICBLZExlZnRNZW51LFxyXG4gICAgICAgIEtkUGFnZWhlYWRlcixcclxuICAgICAgICBLZFRvb2xiYXIsXHJcbiAgICAgICAgS2RBbGVydCxcclxuICAgICAgICBLZFRlbXBsYXRlTGF5b3V0LFxyXG4gICAgICAgIEtkQ29kZWJsb2NrLFxyXG5cclxuICAgICAgICBLZFRhYnMsXHJcblxyXG4gICAgICAgIEtkTG9naW4sXHJcbiAgICAgICAgS2RMb2dpbkZvcm0sXHJcblxyXG4gICAgICAgIEtkRXJyb3IsXHJcblxyXG4gICAgICAgIEtkQWR2RmlsdGVyLFxyXG4gICAgICAgIEtkVmlldyxcclxuICAgICAgICBLZFNsaWRlcixcclxuICAgICAgICBLZFNsaWRlckNvbnRlbnQsXHJcbiAgICAgICAgS2RUYWJsZSxcclxuICAgICAgICBLZENoYXQsXHJcbiAgICAgICAgS2RUYWJsZUFjdGlvbixcclxuICAgICAgICBLZFRhYmxlQ2hlY2tib3hSYWRpbyxcclxuICAgICAgICBLZFRhYmxlSW1hZ2UsXHJcbiAgICAgICAgS2RUYWJsZUlucHV0LFxyXG5cclxuICAgICAgICBLZFRvb2x0aXAsXHJcbiAgICAgICAgS2RUb29sdGlwRGlyZWN0aXZlLFxyXG5cclxuICAgICAgICBLZElucHV0LFxyXG4gICAgICAgIEtkVGV4dElucHV0LFxyXG4gICAgICAgIEtkQnV0dG9uR3JvdXAsXHJcbiAgICAgICAgS2RQbGFjZWhvbGRlcixcclxuICAgICAgICBLZE1vZGFsLFxyXG4gICAgICAgIEtkTXVsdGlTZWxlY3RUYWJsZSxcclxuICAgICAgICBLZENoZWNrYm94UmFkaW8sXHJcbiAgICAgICAgS2REYXRlcGlja2VyLFxyXG4gICAgICAgIEtkVGltZXBpY2tlcixcclxuICAgICAgICBLZFRyZWVEcm9wZG93bixcclxuICAgICAgICBLZFByb2dyZXNzbG9hZGVyLFxyXG4gICAgICAgIEtkRmlsZUlucHV0LFxyXG4gICAgICAgIERyYWdEcm9wRGlyZWN0aXZlLFxyXG4gICAgICAgIEtkTWFwLFxyXG5cclxuICAgICAgICBLZEZpbHRlcixcclxuICAgICAgICBLZFNlYXJjaCxcclxuXHJcbiAgICAgICAgS2REZWxldGUsXHJcblxyXG4gICAgICAgIEtkRm9udHMsXHJcbiAgICAgICAgRmlsdGVyQXJyYXlQaXBlLFxyXG5cclxuICAgICAgICBLZE1pbmlEYXNoYm9hcmQsXHJcbiAgICAgICAgS2RNaW5pRGFzaGJvYXJkQ2hhcnQsXHJcblxyXG4gICAgICAgIEtkV2l6YXJkLFxyXG5cclxuICAgICAgICBLZENhbGVuZGFyLFxyXG5cclxuICAgICAgICBLZE1pbmRtYXAsXHJcbiAgICAgICAgS2RNaW5kbWFwTm9kZSxcclxuICAgICAgICBLZE1pbmRtYXBMaW5rLFxyXG4gICAgICAgIEtkTWluZG1hcFpvb21EaXJlY3RpdmUsXHJcbiAgICAgICAgS2RNaW5kbWFwRHJhZ0RpcmVjdGl2ZSxcclxuICAgICAgICBLZE1pbmRtYXBab29tQnV0dG9uLFxyXG5cclxuICAgICAgICBLZEdyaWRzdGVyLFxyXG4gICAgICAgIEtkR3JpZHN0ZXJUb29sYmFyLFxyXG5cclxuICAgICAgICBLZENoYXJ0cyxcclxuICAgICAgICBLZEJhckNoYXJ0LFxyXG4gICAgICAgIEtkTGluZUNoYXJ0LFxyXG4gICAgICAgIEtkUGllQ2hhcnQsXHJcbiAgICAgICAgS2RNYXBDaGFydCxcclxuICAgICAgICBLZFZpc3VhbGl6YXRpb24sXHJcbiAgICBdLFxyXG4gICAgZXhwb3J0czogW1xyXG4gICAgICAgIFBhZ2luYXRvck1vZHVsZSxcclxuICAgICAgICBNZW51TW9kdWxlLFxyXG4gICAgICAgIENvbW1vbk1vZHVsZSxcclxuICAgICAgICBGb3Jtc01vZHVsZSxcclxuICAgICAgICBSZWFjdGl2ZUZvcm1zTW9kdWxlLFxyXG5cclxuICAgICAgICBLZEhlYWRlcixcclxuICAgICAgICBLZEZvb3RlcixcclxuICAgICAgICBLZFNwbGl0dGVyLFxyXG4gICAgICAgIEtkUGFuZSxcclxuICAgICAgICBLZEJyZWFkY3J1bWIsXHJcbiAgICAgICAgS2RMZWZ0TWVudSxcclxuICAgICAgICBLZFBhZ2VoZWFkZXIsXHJcbiAgICAgICAgS2RUb29sYmFyLFxyXG4gICAgICAgIEtkQWxlcnQsXHJcbiAgICAgICAgS2RUZW1wbGF0ZUxheW91dCxcclxuICAgICAgICBLZENvZGVibG9jayxcclxuICAgICAgICAgICAgICAgIFxyXG4gICAgICAgIEtkVGFicyxcclxuICAgICAgICBcclxuICAgICAgICBLZExvZ2luLFxyXG4gICAgICAgIEtkTG9naW5Gb3JtLFxyXG5cclxuICAgICAgICBLZEVycm9yLFxyXG5cclxuICAgICAgICBLZEFkdkZpbHRlcixcclxuICAgICAgICBLZFZpZXcsXHJcbiAgICAgICAgS2RTbGlkZXIsXHJcbiAgICAgICAgS2RTbGlkZXJDb250ZW50LFxyXG5cclxuICAgICAgICBLZFRhYmxlLFxyXG4gICAgICAgIEtkQ2hhdCxcclxuICAgICAgICBLZFRhYmxlQWN0aW9uLFxyXG4gICAgICAgIEtkVGFibGVDaGVja2JveFJhZGlvLFxyXG4gICAgICAgIEtkVGFibGVJbnB1dCxcclxuICAgICAgICBLZFRhYmxlSW1hZ2UsXHJcblxyXG4gICAgICAgIEtkVG9vbHRpcCxcclxuICAgICAgICBLZFRvb2x0aXBEaXJlY3RpdmUsXHJcbiAgICAgICAgS2RJbnB1dCxcclxuICAgICAgICBLZFRleHRJbnB1dCxcclxuICAgICAgICBLZEJ1dHRvbkdyb3VwLFxyXG4gICAgICAgIEtkUGxhY2Vob2xkZXIsXHJcbiAgICAgICAgS2RNb2RhbCxcclxuICAgICAgICBLZE11bHRpU2VsZWN0VGFibGUsXHJcblxyXG5cclxuICAgICAgICBLZENoZWNrYm94UmFkaW8sXHJcbiAgICAgICAgS2REYXRlcGlja2VyLFxyXG4gICAgICAgIEtkVGltZXBpY2tlcixcclxuICAgICAgICBLZFRyZWVEcm9wZG93bixcclxuICAgICAgICBLZFByb2dyZXNzbG9hZGVyLFxyXG4gICAgICAgIEtkRmlsZUlucHV0LFxyXG4gICAgICAgIERyYWdEcm9wRGlyZWN0aXZlLFxyXG4gICAgICAgIEtkTWFwLFxyXG5cclxuICAgICAgICBLZEZpbHRlcixcclxuICAgICAgICBLZFNlYXJjaCxcclxuXHJcbiAgICAgICAgS2REZWxldGUsXHJcbiAgICAgICAgXHJcbiAgICAgICAgS2RGb250cyxcclxuICAgICAgICBGaWx0ZXJBcnJheVBpcGUsXHJcblxyXG4gICAgICAgIEtkTWluaURhc2hib2FyZCxcclxuICAgICAgICBLZE1pbmlEYXNoYm9hcmRDaGFydCxcclxuICAgICAgICBLZFdpemFyZCxcclxuXHJcbiAgICAgICAgS2RDYWxlbmRhcixcclxuXHJcbiAgICAgICAgS2RNaW5kbWFwLFxyXG4gICAgICAgIEtkTWluZG1hcE5vZGUsXHJcbiAgICAgICAgS2RNaW5kbWFwTGluayxcclxuICAgICAgICBLZE1pbmRtYXBab29tRGlyZWN0aXZlLFxyXG4gICAgICAgIEtkTWluZG1hcERyYWdEaXJlY3RpdmUsXHJcbiAgICAgICAgS2RNaW5kbWFwWm9vbUJ1dHRvbixcclxuXHJcbiAgICAgICAgS2RHcmlkc3RlcixcclxuICAgICAgICBLZEdyaWRzdGVyVG9vbGJhcixcclxuXHJcbiAgICAgICAgS2RDaGFydHMsXHJcbiAgICAgICAgS2RCYXJDaGFydCxcclxuICAgICAgICBLZExpbmVDaGFydCxcclxuICAgICAgICBLZFBpZUNoYXJ0LFxyXG4gICAgICAgIEtkTWFwQ2hhcnQsXHJcbiAgICAgICAgS2RWaXN1YWxpemF0aW9uXHJcbiAgICBdXHJcbn0pXHJcbmV4cG9ydCBjbGFzcyBLZENvbXBvbmVudHNNb2R1bGUge1xyXG4gICAgLy8gc3RhdGljIGZvclJvb3QoKTogTW9kdWxlV2l0aFByb3ZpZGVycyB7XHJcbiAgICAvLyAgICAgcmV0dXJuIHtcclxuICAgIC8vICAgICAgICAgbmdNb2R1bGU6IEtkQ29tcG9uZW50c01vZHVsZSxcclxuICAgIC8vICAgICAgICAgcHJvdmlkZXJzOiBLRF9DT01QT05FTlRTX1BWREVSU1xyXG4gICAgLy8gICAgIH07XHJcbiAgICAvLyB9XHJcbn1cclxuIl19