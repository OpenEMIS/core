import { Component, Input, Output, ViewContainerRef, EventEmitter, HostListener, Renderer2 } from '@angular/core';
import { timer } from 'rxjs';
import { Router, NavigationEnd } from '@angular/router';
import { KdDomElemSvc } from '../kd-common/index';
export class KdFooter {
    constructor(_vcr, _router, _renderer, _domSvc) {
        this._vcr = _vcr;
        this._router = _router;
        this._renderer = _renderer;
        this._domSvc = _domSvc;
        this._currentYear = new Date().getFullYear();
        this.checkFloat = new EventEmitter();
        this._el = this._vcr.element;
    }
    onResize(event) {
        this.onMobileView();
    }
    ngOnInit() {
        this._float = (typeof this.enableFloat !== 'undefined' && this.enableFloat === 'false') ? false : true;
        this._setVersioning();
    }
    ngAfterViewInit() {
        this._router.events.subscribe(event => {
            if (event instanceof NavigationEnd) {
                timer(200).subscribe(() => {
                    this.onMobileView();
                });
            }
        });
    }
    onMobileView() {
        // let windowSize: number = window.innerWidth;
        let contentArea = this._el.nativeElement.previousElementSibling;
        let contentHeight = contentArea.getBoundingClientRect().height;
        let spliterWrapper = document.querySelector('kd-splitter.main');
        // console.log(spliterWrapper);
        if (spliterWrapper === null)
            return false;
        // let contentWrapperHeight = this._el.nativeElement.parentElement.parentElement.getBoundingClientRect().height;
        // let kdPaneHeight = this._el.nativeElement.parentElement.parentElement.parentElement.parentElement.getBoundingClientRect().height;
        let kdPaneHeight = spliterWrapper.querySelector('.pane-2').getBoundingClientRect().height;
        // let wrapperElement = this._el.nativeElement.parentElement.parentElement.parentElement;
        let wrapperElement = spliterWrapper.querySelector('.main-wrapper');
        // let contentWrapperHeight: number = spliterWrapper.querySelector('.content-wrapper').getBoundingClientRect().height;
        // console.log(spliterWrapper.querySelector('.pane-2'));
        // console.log(this._el.nativeElement.parentElement.parentElement.parentElement);
        // console.log('Content Height,' + contentHeight);
        // console.log('contentWrapperHeight,' + contentWrapperHeight);
        // console.log(this._el.nativeElement.parentElement.parentElement);
        if (contentArea !== undefined) {
            if (this._domSvc.isMobile()) {
                if (contentHeight < kdPaneHeight) {
                    this.checkFloat.emit('absolute');
                    this._renderer.setStyle(this._el.nativeElement, 'position', 'absolute');
                    // this._renderer.setElementStyle(wrapperElement, 'height', '100%');
                    // this._renderer.setElementClass(this._el.nativeElement.parentElement.parentElement.parentElement, 'has-footer', true);
                    // this._renderer.setElementStyle(wrapperElement, 'height', '100%');
                    // this._renderer.setElementClass(this._el.nativeElement.parentElement.parentElement.parentElement, 'has-footer', true);
                    this._renderer.addClass(wrapperElement, 'has-footer');
                }
                else {
                    if (this._float) {
                        this.checkFloat.emit('float');
                        this._renderer.setStyle(this._el.nativeElement, 'position', 'relative');
                        // this._renderer.setElementStyle(wrapperElement, 'height', 'auto');
                        // this._renderer.setElementClass(this._el.nativeElement.parentElement.parentElement.parentElement, 'has-footer', false);
                        // this._renderer.setElementStyle(wrapperElement, 'height', 'auto');
                        // this._renderer.setElementClass(this._el.nativeElement.parentElement.parentElement.parentElement, 'has-footer', false);
                        this._renderer.removeClass(wrapperElement, 'has-footer');
                    }
                }
            }
            else {
                this.checkFloat.emit('fixed');
                this._renderer.setStyle(this._el.nativeElement, 'position', 'fixed');
                // this._renderer.setElementClass(this._el.nativeElement.parentElement.parentElement.parentElement, 'has-footer', true);
                // this._renderer.setElementClass(this._el.nativeElement.parentElement.parentElement.parentElement, 'has-footer', true);
                this._renderer.addClass(wrapperElement, 'has-footer');
            }
        }
        return true;
    }
    _setVersioning() {
        try {
            // console.log('in try');
            this._latestVersion = app_version;
        }
        catch (err) {
            // console.log(err);
            this._latestVersion = (typeof this.version !== 'undefined') ? this.version : '1.0.0';
        }
    }
}
KdFooter.decorators = [
    { type: Component, args: [{
                selector: 'kd-footer',
                template: `
        <footer>
            <p *ngIf="!enableCustom">Copyright © {{_currentYear}} OpenEMIS. All rights reserved. | Version {{_latestVersion}}</p>
            <p *ngIf="enableCustom">{{customMessage}} | Version {{_latestVersion}}</p>
        </footer>
    `,
                providers: [KdDomElemSvc],
                host: { 'class': 'kdx-footer' }
            },] }
];
KdFooter.ctorParameters = () => [
    { type: ViewContainerRef },
    { type: Router },
    { type: Renderer2 },
    { type: KdDomElemSvc }
];
KdFooter.propDecorators = {
    version: [{ type: Input }],
    enableCustom: [{ type: Input }],
    customMessage: [{ type: Input }],
    enableFloat: [{ type: Input }],
    checkFloat: [{ type: Output }],
    onResize: [{ type: HostListener, args: ['window:resize', ['$event'],] }]
};
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoia2QtYW5ndWxhci1mb290ZXIuanMiLCJzb3VyY2VSb290IjoiQzovUHJvamVjdHMvQW5ndWxhci9pb3N0Zy1vcGVuZW1pcy1zdHlsZWd1aWRlL3Byb2plY3RzL29wZW5lbWlzLXN0eWxlZ3VpZGUtbGliL3NyYy8iLCJzb3VyY2VzIjpbImtkLWNvbXBvbmVudHMva2QtYW5ndWxhci1mb290ZXIva2QtYW5ndWxhci1mb290ZXIudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsT0FBTyxFQUFFLFNBQVMsRUFBRSxLQUFLLEVBQUUsTUFBTSxFQUFFLGdCQUFnQixFQUFxQyxZQUFZLEVBQUUsWUFBWSxFQUFFLFNBQVMsRUFBRSxNQUFNLGVBQWUsQ0FBQztBQUNySixPQUFPLEVBQUUsS0FBSyxFQUFFLE1BQU0sTUFBTSxDQUFDO0FBQzdCLE9BQU8sRUFBRSxNQUFNLEVBQUUsYUFBYSxFQUFFLE1BQU0saUJBQWlCLENBQUM7QUFDeEQsT0FBTyxFQUFFLFlBQVksRUFBRSxNQUFNLG9CQUFvQixDQUFDO0FBZ0JsRCxNQUFNLE9BQU8sUUFBUTtJQWFqQixZQUNZLElBQXNCLEVBQ3RCLE9BQWUsRUFDZixTQUFvQixFQUNwQixPQUFxQjtRQUhyQixTQUFJLEdBQUosSUFBSSxDQUFrQjtRQUN0QixZQUFPLEdBQVAsT0FBTyxDQUFRO1FBQ2YsY0FBUyxHQUFULFNBQVMsQ0FBVztRQUNwQixZQUFPLEdBQVAsT0FBTyxDQUFjO1FBaEIxQixpQkFBWSxHQUFXLElBQUksSUFBSSxFQUFFLENBQUMsV0FBVyxFQUFFLENBQUM7UUFVN0MsZUFBVSxHQUFHLElBQUksWUFBWSxFQUFFLENBQUM7UUFPdEMsSUFBSSxDQUFDLEdBQUcsR0FBRyxJQUFJLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQztJQUNqQyxDQUFDO0lBR0QsUUFBUSxDQUFDLEtBQVU7UUFDZixJQUFJLENBQUMsWUFBWSxFQUFFLENBQUM7SUFDeEIsQ0FBQztJQUVELFFBQVE7UUFDSixJQUFJLENBQUMsTUFBTSxHQUFHLENBQUMsT0FBTyxJQUFJLENBQUMsV0FBVyxLQUFLLFdBQVcsSUFBSSxJQUFJLENBQUMsV0FBVyxLQUFLLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQztRQUN2RyxJQUFJLENBQUMsY0FBYyxFQUFFLENBQUM7SUFDMUIsQ0FBQztJQUVELGVBQWU7UUFDWCxJQUFJLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxTQUFTLENBQUMsS0FBSyxDQUFDLEVBQUU7WUFDbEMsSUFBSSxLQUFLLFlBQVksYUFBYSxFQUFFO2dCQUNoQyxLQUFLLENBQUMsR0FBRyxDQUFDLENBQUMsU0FBUyxDQUFDLEdBQVMsRUFBRTtvQkFDNUIsSUFBSSxDQUFDLFlBQVksRUFBRSxDQUFDO2dCQUN4QixDQUFDLENBQUMsQ0FBQzthQUNOO1FBQ0wsQ0FBQyxDQUFDLENBQUM7SUFDUCxDQUFDO0lBRUQsWUFBWTtRQUNSLDhDQUE4QztRQUM5QyxJQUFJLFdBQVcsR0FBWSxJQUFJLENBQUMsR0FBRyxDQUFDLGFBQWEsQ0FBQyxzQkFBc0IsQ0FBQztRQUN6RSxJQUFJLGFBQWEsR0FBVyxXQUFXLENBQUMscUJBQXFCLEVBQUUsQ0FBQyxNQUFNLENBQUM7UUFDdkUsSUFBSSxjQUFjLEdBQVksUUFBUSxDQUFDLGFBQWEsQ0FBQyxrQkFBa0IsQ0FBQyxDQUFDO1FBQ3pFLCtCQUErQjtRQUMvQixJQUFJLGNBQWMsS0FBSyxJQUFJO1lBQUUsT0FBTyxLQUFLLENBQUM7UUFDMUMsZ0hBQWdIO1FBQ2hILG9JQUFvSTtRQUNwSSxJQUFJLFlBQVksR0FBVyxjQUFjLENBQUMsYUFBYSxDQUFDLFNBQVMsQ0FBQyxDQUFDLHFCQUFxQixFQUFFLENBQUMsTUFBTSxDQUFDO1FBQ2xHLHlGQUF5RjtRQUN6RixJQUFJLGNBQWMsR0FBWSxjQUFjLENBQUMsYUFBYSxDQUFDLGVBQWUsQ0FBQyxDQUFDO1FBQzVFLHNIQUFzSDtRQUN0SCx3REFBd0Q7UUFDeEQsaUZBQWlGO1FBQ2pGLGtEQUFrRDtRQUNsRCwrREFBK0Q7UUFDL0QsbUVBQW1FO1FBQ25FLElBQUksV0FBVyxLQUFLLFNBQVMsRUFBRTtZQUMzQixJQUFJLElBQUksQ0FBQyxPQUFPLENBQUMsUUFBUSxFQUFFLEVBQUU7Z0JBQ3pCLElBQUksYUFBYSxHQUFHLFlBQVksRUFBRTtvQkFDOUIsSUFBSSxDQUFDLFVBQVUsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLENBQUM7b0JBRWpDLElBQUksQ0FBQyxTQUFTLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsYUFBYSxFQUFFLFVBQVUsRUFBRSxVQUFVLENBQUMsQ0FBQztvQkFDeEUsb0VBQW9FO29CQUNwRSx3SEFBd0g7b0JBQ3hILG9FQUFvRTtvQkFDeEYsd0hBQXdIO29CQUN4SCxJQUFJLENBQUMsU0FBUyxDQUFDLFFBQVEsQ0FBQyxjQUFjLEVBQUUsWUFBWSxDQUFDLENBQUM7aUJBQ3JDO3FCQUFNO29CQUNILElBQUksSUFBSSxDQUFDLE1BQU0sRUFBRTt3QkFDYixJQUFJLENBQUMsVUFBVSxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsQ0FBQzt3QkFFOUIsSUFBSSxDQUFDLFNBQVMsQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxhQUFhLEVBQUUsVUFBVSxFQUFFLFVBQVUsQ0FBQyxDQUFDO3dCQUN4RSxvRUFBb0U7d0JBQ3BFLHlIQUF5SDt3QkFDekgsb0VBQW9FO3dCQUM1Rix5SEFBeUg7d0JBQ3pILElBQUksQ0FBQyxTQUFTLENBQUMsV0FBVyxDQUFDLGNBQWMsRUFBRSxZQUFZLENBQUMsQ0FBQztxQkFDcEM7aUJBQ0o7YUFDSjtpQkFBTTtnQkFDSCxJQUFJLENBQUMsVUFBVSxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsQ0FBQztnQkFFOUIsSUFBSSxDQUFDLFNBQVMsQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxhQUFhLEVBQUUsVUFBVSxFQUFFLE9BQU8sQ0FBQyxDQUFDO2dCQUNyRSx3SEFBd0g7Z0JBQ3hILHdIQUF3SDtnQkFDeEksSUFBSSxDQUFDLFNBQVMsQ0FBQyxRQUFRLENBQUMsY0FBYyxFQUFFLFlBQVksQ0FBQyxDQUFDO2FBRXpDO1NBQ0o7UUFFRCxPQUFPLElBQUksQ0FBQztJQUNoQixDQUFDO0lBRU8sY0FBYztRQUNsQixJQUFJO1lBQ0EseUJBQXlCO1lBQ3pCLElBQUksQ0FBQyxjQUFjLEdBQUcsV0FBVyxDQUFDO1NBRXJDO1FBQUMsT0FBTyxHQUFHLEVBQUU7WUFDVixvQkFBb0I7WUFDcEIsSUFBSSxDQUFDLGNBQWMsR0FBRyxDQUFDLE9BQU8sSUFBSSxDQUFDLE9BQU8sS0FBSyxXQUFXLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDO1NBQ3hGO0lBQ0wsQ0FBQzs7O1lBckhKLFNBQVMsU0FBQztnQkFDUCxRQUFRLEVBQUUsV0FBVztnQkFDckIsUUFBUSxFQUFFOzs7OztLQUtUO2dCQUNELFNBQVMsRUFBRSxDQUFDLFlBQVksQ0FBQztnQkFDekIsSUFBSSxFQUFHLEVBQUUsT0FBTyxFQUFHLFlBQVksRUFBRTthQUNwQzs7O1lBakJrQyxnQkFBZ0I7WUFFMUMsTUFBTTtZQUZxRyxTQUFTO1lBR3BILFlBQVk7OztzQkF1QmhCLEtBQUs7MkJBQ0wsS0FBSzs0QkFDTCxLQUFLOzBCQUNMLEtBQUs7eUJBQ0wsTUFBTTt1QkFVTixZQUFZLFNBQUMsZUFBZSxFQUFFLENBQUMsUUFBUSxDQUFDIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgQ29tcG9uZW50LCBJbnB1dCwgT3V0cHV0LCBWaWV3Q29udGFpbmVyUmVmLCBFbGVtZW50UmVmLCBPbkluaXQsIEFmdGVyVmlld0luaXQsIEV2ZW50RW1pdHRlciwgSG9zdExpc3RlbmVyLCBSZW5kZXJlcjIgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcclxuaW1wb3J0IHsgdGltZXIgfSBmcm9tICdyeGpzJztcclxuaW1wb3J0IHsgUm91dGVyLCBOYXZpZ2F0aW9uRW5kIH0gZnJvbSAnQGFuZ3VsYXIvcm91dGVyJztcclxuaW1wb3J0IHsgS2REb21FbGVtU3ZjIH0gZnJvbSAnLi4va2QtY29tbW9uL2luZGV4JztcclxuXHJcbmRlY2xhcmUgbGV0IGFwcF92ZXJzaW9uOiBzdHJpbmc7XHJcblxyXG5AQ29tcG9uZW50KHtcclxuICAgIHNlbGVjdG9yOiAna2QtZm9vdGVyJyxcclxuICAgIHRlbXBsYXRlOiBgXHJcbiAgICAgICAgPGZvb3Rlcj5cclxuICAgICAgICAgICAgPHAgKm5nSWY9XCIhZW5hYmxlQ3VzdG9tXCI+Q29weXJpZ2h0IMKpIHt7X2N1cnJlbnRZZWFyfX0gT3BlbkVNSVMuIEFsbCByaWdodHMgcmVzZXJ2ZWQuIHwgVmVyc2lvbiB7e19sYXRlc3RWZXJzaW9ufX08L3A+XHJcbiAgICAgICAgICAgIDxwICpuZ0lmPVwiZW5hYmxlQ3VzdG9tXCI+e3tjdXN0b21NZXNzYWdlfX0gfCBWZXJzaW9uIHt7X2xhdGVzdFZlcnNpb259fTwvcD5cclxuICAgICAgICA8L2Zvb3Rlcj5cclxuICAgIGAsXHJcbiAgICBwcm92aWRlcnM6IFtLZERvbUVsZW1TdmNdLFxyXG4gICAgaG9zdCA6IHsgJ2NsYXNzJyA6ICdrZHgtZm9vdGVyJyB9XHJcbn0pXHJcblxyXG5leHBvcnQgY2xhc3MgS2RGb290ZXIgaW1wbGVtZW50cyBPbkluaXQsIEFmdGVyVmlld0luaXQge1xyXG4gICAgcHVibGljIF9jdXJyZW50WWVhcjogbnVtYmVyID0gbmV3IERhdGUoKS5nZXRGdWxsWWVhcigpO1xyXG4gICAgcHVibGljIF9sYXRlc3RWZXJzaW9uOiBzdHJpbmc7XHJcblxyXG4gICAgcHJpdmF0ZSBfZWw6IEVsZW1lbnRSZWY7XHJcbiAgICBwcml2YXRlIF9mbG9hdDogYm9vbGVhbjtcclxuXHJcbiAgICBASW5wdXQoKSB2ZXJzaW9uOiBzdHJpbmc7XHJcbiAgICBASW5wdXQoKSBlbmFibGVDdXN0b206IGJvb2xlYW47XHJcbiAgICBASW5wdXQoKSBjdXN0b21NZXNzYWdlOiBzdHJpbmc7XHJcbiAgICBASW5wdXQoKSBlbmFibGVGbG9hdDogc3RyaW5nO1xyXG4gICAgQE91dHB1dCgpIGNoZWNrRmxvYXQgPSBuZXcgRXZlbnRFbWl0dGVyKCk7XHJcblxyXG4gICAgY29uc3RydWN0b3IoXHJcbiAgICAgICAgcHJpdmF0ZSBfdmNyOiBWaWV3Q29udGFpbmVyUmVmLFxyXG4gICAgICAgIHByaXZhdGUgX3JvdXRlcjogUm91dGVyLFxyXG4gICAgICAgIHByaXZhdGUgX3JlbmRlcmVyOiBSZW5kZXJlcjIsXHJcbiAgICAgICAgcHJpdmF0ZSBfZG9tU3ZjOiBLZERvbUVsZW1TdmMpIHtcclxuICAgICAgICB0aGlzLl9lbCA9IHRoaXMuX3Zjci5lbGVtZW50O1xyXG4gICAgfVxyXG5cclxuICAgIEBIb3N0TGlzdGVuZXIoJ3dpbmRvdzpyZXNpemUnLCBbJyRldmVudCddKVxyXG4gICAgb25SZXNpemUoZXZlbnQ6IGFueSkge1xyXG4gICAgICAgIHRoaXMub25Nb2JpbGVWaWV3KCk7XHJcbiAgICB9XHJcblxyXG4gICAgbmdPbkluaXQoKTogdm9pZCB7XHJcbiAgICAgICAgdGhpcy5fZmxvYXQgPSAodHlwZW9mIHRoaXMuZW5hYmxlRmxvYXQgIT09ICd1bmRlZmluZWQnICYmIHRoaXMuZW5hYmxlRmxvYXQgPT09ICdmYWxzZScpID8gZmFsc2UgOiB0cnVlO1xyXG4gICAgICAgIHRoaXMuX3NldFZlcnNpb25pbmcoKTtcclxuICAgIH1cclxuXHJcbiAgICBuZ0FmdGVyVmlld0luaXQoKTogdm9pZCB7XHJcbiAgICAgICAgdGhpcy5fcm91dGVyLmV2ZW50cy5zdWJzY3JpYmUoZXZlbnQgPT4ge1xyXG4gICAgICAgICAgICBpZiAoZXZlbnQgaW5zdGFuY2VvZiBOYXZpZ2F0aW9uRW5kKSB7XHJcbiAgICAgICAgICAgICAgICB0aW1lcigyMDApLnN1YnNjcmliZSgoKTogdm9pZCA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5vbk1vYmlsZVZpZXcoKTtcclxuICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfSk7XHJcbiAgICB9XHJcblxyXG4gICAgb25Nb2JpbGVWaWV3KCk6IGJvb2xlYW4ge1xyXG4gICAgICAgIC8vIGxldCB3aW5kb3dTaXplOiBudW1iZXIgPSB3aW5kb3cuaW5uZXJXaWR0aDtcclxuICAgICAgICBsZXQgY29udGVudEFyZWE6IEVsZW1lbnQgPSB0aGlzLl9lbC5uYXRpdmVFbGVtZW50LnByZXZpb3VzRWxlbWVudFNpYmxpbmc7XHJcbiAgICAgICAgbGV0IGNvbnRlbnRIZWlnaHQ6IG51bWJlciA9IGNvbnRlbnRBcmVhLmdldEJvdW5kaW5nQ2xpZW50UmVjdCgpLmhlaWdodDtcclxuICAgICAgICBsZXQgc3BsaXRlcldyYXBwZXI6IEVsZW1lbnQgPSBkb2N1bWVudC5xdWVyeVNlbGVjdG9yKCdrZC1zcGxpdHRlci5tYWluJyk7XHJcbiAgICAgICAgLy8gY29uc29sZS5sb2coc3BsaXRlcldyYXBwZXIpO1xyXG4gICAgICAgIGlmIChzcGxpdGVyV3JhcHBlciA9PT0gbnVsbCkgcmV0dXJuIGZhbHNlO1xyXG4gICAgICAgIC8vIGxldCBjb250ZW50V3JhcHBlckhlaWdodCA9IHRoaXMuX2VsLm5hdGl2ZUVsZW1lbnQucGFyZW50RWxlbWVudC5wYXJlbnRFbGVtZW50LmdldEJvdW5kaW5nQ2xpZW50UmVjdCgpLmhlaWdodDtcclxuICAgICAgICAvLyBsZXQga2RQYW5lSGVpZ2h0ID0gdGhpcy5fZWwubmF0aXZlRWxlbWVudC5wYXJlbnRFbGVtZW50LnBhcmVudEVsZW1lbnQucGFyZW50RWxlbWVudC5wYXJlbnRFbGVtZW50LmdldEJvdW5kaW5nQ2xpZW50UmVjdCgpLmhlaWdodDtcclxuICAgICAgICBsZXQga2RQYW5lSGVpZ2h0OiBudW1iZXIgPSBzcGxpdGVyV3JhcHBlci5xdWVyeVNlbGVjdG9yKCcucGFuZS0yJykuZ2V0Qm91bmRpbmdDbGllbnRSZWN0KCkuaGVpZ2h0O1xyXG4gICAgICAgIC8vIGxldCB3cmFwcGVyRWxlbWVudCA9IHRoaXMuX2VsLm5hdGl2ZUVsZW1lbnQucGFyZW50RWxlbWVudC5wYXJlbnRFbGVtZW50LnBhcmVudEVsZW1lbnQ7XHJcbiAgICAgICAgbGV0IHdyYXBwZXJFbGVtZW50OiBFbGVtZW50ID0gc3BsaXRlcldyYXBwZXIucXVlcnlTZWxlY3RvcignLm1haW4td3JhcHBlcicpO1xyXG4gICAgICAgIC8vIGxldCBjb250ZW50V3JhcHBlckhlaWdodDogbnVtYmVyID0gc3BsaXRlcldyYXBwZXIucXVlcnlTZWxlY3RvcignLmNvbnRlbnQtd3JhcHBlcicpLmdldEJvdW5kaW5nQ2xpZW50UmVjdCgpLmhlaWdodDtcclxuICAgICAgICAvLyBjb25zb2xlLmxvZyhzcGxpdGVyV3JhcHBlci5xdWVyeVNlbGVjdG9yKCcucGFuZS0yJykpO1xyXG4gICAgICAgIC8vIGNvbnNvbGUubG9nKHRoaXMuX2VsLm5hdGl2ZUVsZW1lbnQucGFyZW50RWxlbWVudC5wYXJlbnRFbGVtZW50LnBhcmVudEVsZW1lbnQpO1xyXG4gICAgICAgIC8vIGNvbnNvbGUubG9nKCdDb250ZW50IEhlaWdodCwnICsgY29udGVudEhlaWdodCk7XHJcbiAgICAgICAgLy8gY29uc29sZS5sb2coJ2NvbnRlbnRXcmFwcGVySGVpZ2h0LCcgKyBjb250ZW50V3JhcHBlckhlaWdodCk7XHJcbiAgICAgICAgLy8gY29uc29sZS5sb2codGhpcy5fZWwubmF0aXZlRWxlbWVudC5wYXJlbnRFbGVtZW50LnBhcmVudEVsZW1lbnQpO1xyXG4gICAgICAgIGlmIChjb250ZW50QXJlYSAhPT0gdW5kZWZpbmVkKSB7XHJcbiAgICAgICAgICAgIGlmICh0aGlzLl9kb21TdmMuaXNNb2JpbGUoKSkge1xyXG4gICAgICAgICAgICAgICAgaWYgKGNvbnRlbnRIZWlnaHQgPCBrZFBhbmVIZWlnaHQpIHtcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLmNoZWNrRmxvYXQuZW1pdCgnYWJzb2x1dGUnKTtcclxuXHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5fcmVuZGVyZXIuc2V0U3R5bGUodGhpcy5fZWwubmF0aXZlRWxlbWVudCwgJ3Bvc2l0aW9uJywgJ2Fic29sdXRlJyk7XHJcbiAgICAgICAgICAgICAgICAgICAgLy8gdGhpcy5fcmVuZGVyZXIuc2V0RWxlbWVudFN0eWxlKHdyYXBwZXJFbGVtZW50LCAnaGVpZ2h0JywgJzEwMCUnKTtcclxuICAgICAgICAgICAgICAgICAgICAvLyB0aGlzLl9yZW5kZXJlci5zZXRFbGVtZW50Q2xhc3ModGhpcy5fZWwubmF0aXZlRWxlbWVudC5wYXJlbnRFbGVtZW50LnBhcmVudEVsZW1lbnQucGFyZW50RWxlbWVudCwgJ2hhcy1mb290ZXInLCB0cnVlKTtcclxuICAgICAgICAgICAgICAgICAgICAvLyB0aGlzLl9yZW5kZXJlci5zZXRFbGVtZW50U3R5bGUod3JhcHBlckVsZW1lbnQsICdoZWlnaHQnLCAnMTAwJScpO1xyXG4vLyB0aGlzLl9yZW5kZXJlci5zZXRFbGVtZW50Q2xhc3ModGhpcy5fZWwubmF0aXZlRWxlbWVudC5wYXJlbnRFbGVtZW50LnBhcmVudEVsZW1lbnQucGFyZW50RWxlbWVudCwgJ2hhcy1mb290ZXInLCB0cnVlKTtcclxudGhpcy5fcmVuZGVyZXIuYWRkQ2xhc3Mod3JhcHBlckVsZW1lbnQsICdoYXMtZm9vdGVyJyk7XHJcbiAgICAgICAgICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgICAgIGlmICh0aGlzLl9mbG9hdCkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLmNoZWNrRmxvYXQuZW1pdCgnZmxvYXQnKTtcclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuX3JlbmRlcmVyLnNldFN0eWxlKHRoaXMuX2VsLm5hdGl2ZUVsZW1lbnQsICdwb3NpdGlvbicsICdyZWxhdGl2ZScpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAvLyB0aGlzLl9yZW5kZXJlci5zZXRFbGVtZW50U3R5bGUod3JhcHBlckVsZW1lbnQsICdoZWlnaHQnLCAnYXV0bycpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAvLyB0aGlzLl9yZW5kZXJlci5zZXRFbGVtZW50Q2xhc3ModGhpcy5fZWwubmF0aXZlRWxlbWVudC5wYXJlbnRFbGVtZW50LnBhcmVudEVsZW1lbnQucGFyZW50RWxlbWVudCwgJ2hhcy1mb290ZXInLCBmYWxzZSk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC8vIHRoaXMuX3JlbmRlcmVyLnNldEVsZW1lbnRTdHlsZSh3cmFwcGVyRWxlbWVudCwgJ2hlaWdodCcsICdhdXRvJyk7XHJcbi8vIHRoaXMuX3JlbmRlcmVyLnNldEVsZW1lbnRDbGFzcyh0aGlzLl9lbC5uYXRpdmVFbGVtZW50LnBhcmVudEVsZW1lbnQucGFyZW50RWxlbWVudC5wYXJlbnRFbGVtZW50LCAnaGFzLWZvb3RlcicsIGZhbHNlKTtcclxudGhpcy5fcmVuZGVyZXIucmVtb3ZlQ2xhc3Mod3JhcHBlckVsZW1lbnQsICdoYXMtZm9vdGVyJyk7XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5jaGVja0Zsb2F0LmVtaXQoJ2ZpeGVkJyk7XHJcblxyXG4gICAgICAgICAgICAgICAgdGhpcy5fcmVuZGVyZXIuc2V0U3R5bGUodGhpcy5fZWwubmF0aXZlRWxlbWVudCwgJ3Bvc2l0aW9uJywgJ2ZpeGVkJyk7XHJcbiAgICAgICAgICAgICAgICAvLyB0aGlzLl9yZW5kZXJlci5zZXRFbGVtZW50Q2xhc3ModGhpcy5fZWwubmF0aXZlRWxlbWVudC5wYXJlbnRFbGVtZW50LnBhcmVudEVsZW1lbnQucGFyZW50RWxlbWVudCwgJ2hhcy1mb290ZXInLCB0cnVlKTtcclxuICAgICAgICAgICAgICAgIC8vIHRoaXMuX3JlbmRlcmVyLnNldEVsZW1lbnRDbGFzcyh0aGlzLl9lbC5uYXRpdmVFbGVtZW50LnBhcmVudEVsZW1lbnQucGFyZW50RWxlbWVudC5wYXJlbnRFbGVtZW50LCAnaGFzLWZvb3RlcicsIHRydWUpO1xyXG50aGlzLl9yZW5kZXJlci5hZGRDbGFzcyh3cmFwcGVyRWxlbWVudCwgJ2hhcy1mb290ZXInKTtcclxuXHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIHJldHVybiB0cnVlO1xyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX3NldFZlcnNpb25pbmcoKTogdm9pZCB7XHJcbiAgICAgICAgdHJ5IHtcclxuICAgICAgICAgICAgLy8gY29uc29sZS5sb2coJ2luIHRyeScpO1xyXG4gICAgICAgICAgICB0aGlzLl9sYXRlc3RWZXJzaW9uID0gYXBwX3ZlcnNpb247XHJcblxyXG4gICAgICAgIH0gY2F0Y2ggKGVycikge1xyXG4gICAgICAgICAgICAvLyBjb25zb2xlLmxvZyhlcnIpO1xyXG4gICAgICAgICAgICB0aGlzLl9sYXRlc3RWZXJzaW9uID0gKHR5cGVvZiB0aGlzLnZlcnNpb24gIT09ICd1bmRlZmluZWQnKSA/IHRoaXMudmVyc2lvbiA6ICcxLjAuMCc7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG59XHJcbiJdfQ==