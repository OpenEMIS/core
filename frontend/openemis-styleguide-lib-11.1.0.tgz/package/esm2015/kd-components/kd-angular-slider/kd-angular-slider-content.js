import { timer as observableTimer } from 'rxjs';
import { Component, ViewEncapsulation, Input, ElementRef, EventEmitter, Output, ViewChild, Renderer2 } from '@angular/core';
import { KdDomElemSvc } from '../kd-common/index';
import { KdSliderSvc } from './kd-angular-slider-svc';
export class KdSliderContent {
    constructor(_elementRef, _kdDomElemSvc, _renderer, _sliderSvc) {
        this._elementRef = _elementRef;
        this._renderer = _renderer;
        this._sliderSvc = _sliderSvc;
        this.selectedThumbIndex = 0;
        this.isMobile = false;
        this.config = {};
        this.noValue = false;
        this.tooltipApi = [{}, {}];
        this.tooltipLabel = [0];
        this.tooltipPlacement = 'top';
        this._tooltipAppeared = [false];
        this._isHovered = false;
        /** The percentage of the slider that coincides with the value. */
        this._percent = 0;
        this._percents = [0, 0.1];
        this._direction = 'ltr';
        /** The dimensions of the slider. */
        this._sliderDimensions = null;
        this._isFirstLoad = true;
        /**
        *  Whether or not the slider is clicked.
        *  Used to determine if there should be a show of tooltip via transitionend listener.
        */
        this._isClick = false;
        this.childValue = 0;
        this.isPlay = false;
        this.result = new EventEmitter();
        this.endPlay = new EventEmitter();
        this._direction = _kdDomElemSvc.getDocumentDirection(true) === 'left' ? 'ltr' : 'rtl';
        this._sliderSvc.direction = this._direction;
        this.isMobile = _kdDomElemSvc.isMobileDevice();
    }
    ngOnInit() {
        if (typeof this.childValue === 'undefined') {
            this.noValue = true;
            return;
        }
        this._setConfig(this.childConfig);
        this.value = this._setData(this.childValue);
        this._setFirstLoadPositionAndTooltip(this.childValue);
        this._initApi();
        this._isFirstLoad = false;
    }
    ngOnChanges(_simpleChanges) {
        if (_simpleChanges.hasOwnProperty('isPlay') && !this._isFirstLoad) {
            if (this.isPlay) {
                this._clickPlayBtn();
            }
            else {
                this._clickPauseBtn();
            }
        }
        if (_simpleChanges.hasOwnProperty('childValue') && !this._isFirstLoad) {
            if (_simpleChanges['childValue'].currentValue === this.value)
                return;
            this.value = this._setData(_simpleChanges['childValue'].currentValue);
            if (this.noValue) {
                this._setFirstLoadPositionAndTooltip(_simpleChanges['childValue'].currentValue);
                this.noValue = false;
            }
        }
        if (_simpleChanges.hasOwnProperty('childConfig') && !this._isFirstLoad) {
            if (_simpleChanges['childConfig'].currentValue === this.config)
                return;
            this._setConfig(_simpleChanges['childConfig'].currentValue);
        }
    }
    ngAfterViewInit() {
        if (this.noValue)
            return;
        let iterations = this.config.range ? 2 : 1;
        for (let i = 0; i < iterations; ++i) {
            this.tooltipApi[i].deactivateHostListener();
        }
        this._attachThumbTransitionListener();
        if (this.isMobile) {
            this._attachMobileWindowListener();
        }
        else {
            this._attachWindowListener();
        }
    }
    ngOnDestroy() {
        if (this.noValue)
            return;
        this._tooltipTransitionListener();
        if (this.config.range)
            this._tooltipTransitionListener1();
        if (this.isMobile) {
            this._windowTapListener();
        }
        else {
            this._windowScrollListener();
        }
        this._tooltipAppearControl('all hide');
    }
    _setConfig(_config) {
        this.config = Object.assign({}, _config);
        this._sliderSvc.config = _config;
        this._axis = _config.orientation === 'vertical' ? 'Y' : 'X';
        this._vertical = _config.orientation === 'vertical' ? true : false;
        this._isInvertAxis = this._sliderSvc.invertAxis();
        this._sliderSvc.calculateRoundLabelTo();
        this.tooltipPlacement = this._sliderSvc.setTooltipPlacement(_config.tooltipPlacement);
    }
    _setData(_value) {
        if (Array.isArray(_value))
            return _value.map((el) => { return el; });
        return _value;
    }
    _setFirstLoadPositionAndTooltip(_value) {
        if (Array.isArray(_value)) {
            this._percents = _value.map((el) => { return this._sliderSvc.calculatePercentage(el); });
            this.thumbContainerStyles = this._thumbContainerStyles(this._percents[0]);
            this.thumbContainerStyles1 = this._thumbContainerStyles(this._percents[1]);
            this._tooltipAppeared = [false, false];
            this.tooltipLabel = this._setTooltipLabel(_value);
        }
        else {
            this._percent = this._sliderSvc.calculatePercentage(_value);
            this.thumbContainerStyles = this._thumbContainerStyles(this._percent);
            this.tooltipLabel[0] = this._setTooltipLabel(_value);
        }
        this.trackFillStyles = this._trackFillStyles();
    }
    /***************************************************************************************/
    /* Event Listener
    /***************************************************************************************/
    onMouseEnter(event) {
        if (this.noValue)
            return;
        this._isHovered = true;
        this._tooltipAppearControl('all show');
        if (this.config.disabled) {
            return;
        }
        // We save the dimensions of the slider here so we can use them to update the spacing of the
        // ticks and determine where on the slider click and slide events happen.
        this._sliderDimensions = this._getSliderDimensions();
    }
    onMouseLeave(event) {
        if (this.noValue)
            return;
        if (!this.isMobile)
            this.onEnd('mouseleave');
        this._tooltipAppearControl('all hide');
        this._isHovered = false;
    }
    onClick(event) {
        if (this.noValue)
            return;
        this._onChoosePos({ x: event.clientX, y: event.clientY });
        event.stopPropagation();
    }
    onMouseDown(event, id) {
        if (this.noValue)
            return;
        if (!this.isMobile) {
            this.onStart({ x: event.clientX, y: event.clientY }, id);
        }
        event.preventDefault();
    }
    onMouseMove(event) {
        if (this.noValue)
            return;
        if (!this.isMobile) {
            this.onMove({ x: event.clientX, y: event.clientY });
        }
        event.preventDefault();
    }
    onMouseUp(event) {
        if (this.noValue)
            return;
        if (!this.isMobile)
            this.onEnd('mouseup');
        event.preventDefault();
    }
    onTouchStart(event, id) {
        if (this.noValue)
            return;
        this.onStart({ x: event.touches['0'].clientX, y: event.touches['0'].clientY }, id);
        event.preventDefault();
        event.stopPropagation();
    }
    onTouchMove(event) {
        if (this.noValue)
            return;
        this.onMove({ x: event.touches['0'].clientX, y: event.touches['0'].clientY });
        event.preventDefault();
        event.stopPropagation();
    }
    onTouchEnd(event) {
        if (this.noValue)
            return;
        this.onEnd('touchend');
        event.stopPropagation();
    }
    _attachMobileWindowListener() {
        this._windowTapListener = this._renderer.listen('document', 'touchstart', (event) => {
            this._tooltipAppearControl('all hide');
            this._isHovered = false;
        });
    }
    _attachWindowListener() {
        this._windowScrollListener = this._renderer.listen('window', 'mousewheel', (event) => {
            observableTimer(50).subscribe(() => {
                this._tooltipAppearControl('all hide');
                this._isHovered = false;
            });
        });
        this._windowScrollListener = this._renderer.listen('window', 'DOMMouseScroll', (event) => {
            observableTimer(50).subscribe(() => {
                this._tooltipAppearControl('all hide');
                this._isHovered = false;
            });
        });
    }
    _attachThumbTransitionListener() {
        let thumbContainerElements = this._elementRef.nativeElement.querySelectorAll('.kdx-slider .kdx-slider-content .kdx-slider-content-wrapper .kdx-slider-thumb-container');
        this._tooltipTransitionListener = this._renderer.listen(thumbContainerElements[0], 'transitionend', () => {
            if (this.isPlay && this.config.autoplay)
                this._updateAutoplayValue();
            if (!this.isPlay && this._isClick && !this._isSliding)
                this._tooltipOnThumbTransition();
        });
        if (this.config.range) {
            this._tooltipTransitionListener1 = this._renderer.listen(thumbContainerElements[1], 'transitionend', () => {
                if (!this.config.autoplay && this._isClick && !this._isSliding)
                    this._tooltipOnThumbTransition();
            });
        }
    }
    _tooltipOnThumbTransition() {
        this._tooltipAppearControl('show selected');
        this._isClick = false;
        if (!this._isHovered)
            setTimeout(() => this._tooltipAppearControl('hide selected'), 1000);
    }
    /***************************************************************************************/
    /* Listener Logic
    /***************************************************************************************/
    onStart(pos, id) {
        if (this.config.disabled || this._isSliding) {
            return;
        }
        // Simulate mouseenter in case this is a mobile device.
        this.onMouseEnter();
        this._isSliding = true;
        if (this.config.range) {
            this.selectedThumbIndex = id;
            this._valueOnSlideStart = this.value[this.selectedThumbIndex];
        }
        else {
            this._valueOnSlideStart = this.value;
        }
        this._handleValue(pos);
    }
    onMove(pos) {
        if (this.config.disabled || !this._isSliding) {
            return;
        }
        let oldValue = 0;
        if (this.config.range) {
            oldValue = this.value[this.selectedThumbIndex];
            this._handleValue(pos);
            if (oldValue !== this.value[this.selectedThumbIndex]) {
                this._emitChangeEvent('sliding');
                return;
            }
        }
        oldValue = this.value;
        this._handleValue(pos);
        // Native range elements always emit `input` events when the value changed while sliding.
        if (oldValue !== this.value) {
            this._emitChangeEvent('sliding');
        }
    }
    onEnd(_fromWhere) {
        if (!this._isSliding) {
            return;
        }
        if (_fromWhere === 'mouseleave') {
            this._isSliding = false;
        }
        else if (this.isMobile)
            this._isSliding = false;
        if (this.config.range) {
            if (this._valueOnSlideStart !== this.value[this.selectedThumbIndex])
                this._emitChangeEvent();
        }
        else {
            if (this._valueOnSlideStart !== this.value)
                this._emitChangeEvent();
        }
        this._valueOnSlideStart = null;
    }
    _onChoosePos(pos) {
        if (this.config.disabled) {
            return;
        }
        // Simulate mouseenter in case this is a mobile device.
        this.onMouseEnter();
        this._isClick = true;
        if (this._isClick && !this._isSliding) {
            this._tooltipAppearControl('hide selected');
        }
        this._isSliding = false;
        let oldValue = 0;
        if (this.config.range) {
            oldValue = this.value[this.selectedThumbIndex];
            this._handleValue(pos);
            if (oldValue !== this.value[this.selectedThumbIndex]) {
                this._emitChangeEvent();
                return;
            }
        }
        oldValue = this.value;
        this._handleValue(pos);
        /* Emit a change and input event if the value changed. */
        if (oldValue !== this.value) {
            this._emitChangeEvent();
        }
    }
    /***************************************************************************************/
    /* Autoplay
    /***************************************************************************************/
    _clickPlayBtn() {
        this.config.disabled = true;
        this._updateAutoplayValue();
    }
    _clickPauseBtn() {
        this.config.disabled = false;
    }
    _updateAutoplayValue() {
        this._tooltipAppearControl('show selected');
        setTimeout(() => {
            this._tooltipAppearControl('hide selected');
            if (!this.isPlay)
                return;
            this.value = this.value + (this.config.autoplayStep || 1);
            if (this.value > this.config.max) {
                this.value = this.config.min;
                this.endPlay.emit(true);
                this.tooltipApi[0].hideTooltip();
                this.config.disabled = false;
            }
            this._percent = this._sliderSvc.calculatePercentage(this.value);
            this._handlePosition();
            this._emitChangeEvent();
        }, this.config.autoplayDelay || 500);
    }
    /***************************************************************************************/
    /* Event Emit
    /***************************************************************************************/
    /** Emits a change event if the current value is different from the last emitted value. */
    _emitChangeEvent(_currentAction) {
        this.result.emit({
            value: this.value,
            currentAction: _currentAction
        });
    }
    /***************************************************************************************/
    /* CSS Styles
    /***************************************************************************************/
    _trackFillStyles() {
        if (this.config.range) {
            let invertOffset = (this._direction === 'rtl' && !this._vertical) ? !this._sliderSvc.invertAxis() : this._sliderSvc.invertAxis();
            let sign = invertOffset ? '-' : '';
            let firstThumbPosition = invertOffset ? this._calculateOffset(this._percents[0]) : 100 - this._calculateOffset(this._percents[0]);
            let scalePercent = this._percents[1] - this._percents[0];
            return {
                'transform': `translate${this._axis}(${sign}${firstThumbPosition}%) scale${this._axis}(${scalePercent})`
            };
        }
        return {
            'transform': `scale${this._axis}(${this._percent})`
        };
    }
    _thumbContainerStyles(_percent) {
        let offset = this._calculateOffset(_percent);
        return {
            'transform': `translate${this._axis}(-${offset}%)`
        };
    }
    _calculateOffset(_percent) {
        // For a horizontal slider in RTL languages we push the thumb container off the left edge
        // instead of the right edge to avoid causing a horizontal scrollbar to appear.
        let invertOffset = (this._direction === 'rtl' && !this._vertical) ? !this._sliderSvc.invertAxis() : this._sliderSvc.invertAxis();
        return (invertOffset ? _percent : 1 - _percent) * 100;
    }
    /***************************************************************************************/
    /* Setting Values
    /***************************************************************************************/
    _handleValue(_pos, _value) {
        let newValue = typeof _value !== 'undefined' ? _value : this._updateValueFromPosition(_pos);
        if (this.config.range) {
            this.value[this.selectedThumbIndex] = newValue;
            this._percents[this.selectedThumbIndex] = this._sliderSvc.calculatePercentage(newValue);
        }
        else {
            this.value = newValue;
            this._percent = this._sliderSvc.calculatePercentage(newValue);
        }
        this._handlePosition();
    }
    _updateValueFromPosition(_pos) {
        if (!this._sliderDimensions) {
            return;
        }
        let offset = this._vertical ? this._sliderDimensions.top : this._sliderDimensions.left;
        let size = this._vertical ? this._sliderDimensions.height : this._sliderDimensions.width;
        let posComponent = this._vertical ? _pos.y : _pos.x;
        // The exact value is calculated from the event and used to find the closest snap value.
        let percent = this._sliderSvc.clamp((posComponent - offset) / size);
        if (this._sliderSvc.invertMouseCoords()) {
            percent = 1 - percent;
        }
        let finalValue = this._sliderSvc.calculateValue(percent);
        if (this.config.range) {
            let otherValue = this.value[Math.abs(1 - this.selectedThumbIndex)];
            if (this._sliderSvc.checkValueConflict(finalValue, otherValue, this.selectedThumbIndex)) {
                finalValue = otherValue;
            }
        }
        return finalValue;
    }
    _handlePosition() {
        if (this.config.range) {
            if (this.selectedThumbIndex === 0) {
                this.thumbContainerStyles = this._thumbContainerStyles(this._percents[0]);
            }
            else {
                this.thumbContainerStyles1 = this._thumbContainerStyles(this._percents[1]);
            }
        }
        else {
            this.thumbContainerStyles = this._thumbContainerStyles(this._percent);
        }
        this.tooltipLabel[this.selectedThumbIndex] = this._setTooltipLabel(this.value);
        this.trackFillStyles = this._trackFillStyles();
        if (this._tooltipAppeared[this.selectedThumbIndex])
            this.tooltipApi[this.selectedThumbIndex].align();
    }
    /***************************************************************************************/
    /* Tooltip functions
    /***************************************************************************************/
    _setTooltipLabel(_value) {
        let text = '';
        if (this.config.range) {
            if (this._isFirstLoad) {
                return _value.map((num) => {
                    text = this._sliderSvc.calculateLabelValue(num);
                    return this._sliderSvc.getLabelFormatReplace(text, this.config.tooltipFormat);
                });
            }
            text = this._sliderSvc.calculateLabelValue(_value[this.selectedThumbIndex]);
        }
        else if (this.config.type === 'others') {
            text = this.config.options[_value].description || this.config.options[_value].value.toString();
        }
        else {
            text = this._sliderSvc.calculateLabelValue(_value);
        }
        return this._sliderSvc.getLabelFormatReplace(text, this.config.tooltipFormat);
    }
    /** Logic for tooltip showing and hiding */
    _tooltipAppearControl(_flag) {
        let iterations = this.config.range ? 2 : 1;
        switch (_flag) {
            case 'all show':
                for (let i = 0; i < iterations; ++i) {
                    if (!this._tooltipAppeared[i]) {
                        this.tooltipApi[i].showTooltip();
                        this._tooltipAppeared[i] = true;
                    }
                }
                break;
            case 'all hide':
                for (let i = 0; i < iterations; ++i) {
                    if (this._tooltipAppeared[i]) {
                        this.tooltipApi[i].hideTooltip();
                        this._tooltipAppeared[i] = false;
                    }
                }
                break;
            case 'show selected':
                if (!this._tooltipAppeared[this.selectedThumbIndex]) {
                    this.tooltipApi[this.selectedThumbIndex].showTooltip();
                    this._tooltipAppeared[this.selectedThumbIndex] = true;
                }
                break;
            case 'hide selected':
                if (this._tooltipAppeared[this.selectedThumbIndex]) {
                    this.tooltipApi[this.selectedThumbIndex].hideTooltip();
                    this._tooltipAppeared[this.selectedThumbIndex] = false;
                }
                break;
        }
    }
    /***************************************************************************************/
    /* Api
    /***************************************************************************************/
    _initApi() {
        if (typeof this.api !== 'undefined') {
            this.api.handleValue = (_value, index) => {
                if (typeof index !== 'undefined') {
                    this.selectedThumbIndex = index;
                    this.value[index] = _value;
                }
                else {
                    this.value = _value;
                }
                this._handleValue(null, _value);
                this._emitChangeEvent();
            };
        }
    }
    /***************************************************************************************/
    /* Helper functions for setting values
    /***************************************************************************************/
    /**
    * Get the bounding client rect of the slider track element.
    * The track is used rather than the native element to ignore the extra space that the thumb can
    * take up.
    */
    _getSliderDimensions() {
        return this._sliderWrapper ? this._sliderWrapper.nativeElement.getBoundingClientRect() : null;
    }
}
KdSliderContent.decorators = [
    { type: Component, args: [{
                selector: 'kd-slider-content',
                template: "<div class=\"kdx-slider-content-wrapper\" #sliderWrapper>\r\n  <div class=\"kdx-slider-track-wrapper\">\r\n    <div class=\"kdx-slider-track-background\"></div>\r\n    <div class=\"kdx-slider-track-fill\" [ngStyle]=\"trackFillStyles\"></div>\r\n  </div>\r\n  <div *ngIf=\"!noValue\" class=\"kdx-slider-thumb-container\" [ngStyle]=\"thumbContainerStyles\" id=\"0\">\r\n    <div class=\"kdx-thumb-buffer-container\" [ngClass]=\"{'kdx-selected-thumb': selectedThumbIndex === 0 && config.range}\"\r\n         (mousedown)=\"onMouseDown($event,0)\" (touchstart)=\"onTouchStart($event,0)\">\r\n      <div class=\"kdx-slider-thumb\" [kd-tooltip-dir]=\"tooltipLabel[0]\" [tooltipPosition]=\"tooltipPlacement\"\r\n         tooltipStyleClass=\"kdx-tooltip-default\" [escape]=\"false\" [api]=\"tooltipApi[0]\"\r\n         ></div>\r\n    </div>\r\n  </div>\r\n  <div *ngIf=\"config.range && !noValue\" class=\"kdx-slider-thumb-container\" [ngStyle]=\"thumbContainerStyles1\" id=\"1\" >\r\n    <div class=\"kdx-thumb-buffer-container\" [ngClass]=\"{'kdx-selected-thumb': selectedThumbIndex === 1 && config.range}\"\r\n         (mousedown)=\"onMouseDown($event,1)\" (touchstart)=\"onTouchStart($event,1)\">\r\n      <div class=\"kdx-slider-thumb\" [kd-tooltip-dir]=\"tooltipLabel[1]\" [tooltipPosition]=\"tooltipPlacement\"\r\n         tooltipStyleClass=\"kdx-tooltip-default\" [escape]=\"false\" [api]=\"tooltipApi[1]\"\r\n         ></div>\r\n    </div>\r\n  </div>\r\n</div>",
                encapsulation: ViewEncapsulation.None,
                providers: [KdDomElemSvc, KdSliderSvc],
                host: {
                    '(mouseenter)': 'onMouseEnter($event)',
                    '(mouseleave)': 'onMouseLeave($event)',
                    '(click)': 'onClick($event)',
                    '(mousemove)': 'onMouseMove($event)',
                    '(mouseup)': 'onMouseUp($event)',
                    '(touchmove)': 'onTouchMove($event)',
                    '(touchend)': 'onTouchEnd($event)',
                    'class': 'kdx-slider-content',
                    'role': 'slider',
                    '[attr.aria-disabled]': 'config.disabled',
                    '[attr.aria-valuemax]': 'config.max',
                    '[attr.aria-valuemin]': 'config.min',
                    '[attr.aria-valuenow]': 'value',
                    '[attr.aria-orientation]': '_vertical ? "vertical" : "horizontal"',
                    '[class.kdx-slider-disabled]': 'config.disabled',
                    '[class.kdx-slider-horizontal]': '!_vertical',
                    '[class.kdx-slider-axis-inverted]': '_isInvertAxis',
                    '[class.kdx-slider-sliding]': '_isSliding',
                    '[class.kdx-slider-vertical]': '_vertical',
                    '[class.kdx-slider-hovered]': '_isHovered',
                    '[class.kdx-slider-has-autoplay]': 'config.autoplay',
                    '[class.kdx-slider-has-range]': 'config.range',
                    '[class.kdx-slider-is-mobile]': 'isMobile',
                    '[class.kdx-slider-has-value]': '!noValue',
                }
            },] }
];
KdSliderContent.ctorParameters = () => [
    { type: ElementRef },
    { type: KdDomElemSvc },
    { type: Renderer2 },
    { type: KdSliderSvc }
];
KdSliderContent.propDecorators = {
    childValue: [{ type: Input, args: ['value',] }],
    childConfig: [{ type: Input, args: ['config',] }],
    isPlay: [{ type: Input }],
    api: [{ type: Input }],
    result: [{ type: Output }],
    endPlay: [{ type: Output }],
    _sliderWrapper: [{ type: ViewChild, args: ['sliderWrapper', { static: true },] }]
};
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoia2QtYW5ndWxhci1zbGlkZXItY29udGVudC5qcyIsInNvdXJjZVJvb3QiOiJDOi9Qcm9qZWN0cy9Bbmd1bGFyL2lvc3RnLW9wZW5lbWlzLXN0eWxlZ3VpZGUvcHJvamVjdHMvb3BlbmVtaXMtc3R5bGVndWlkZS1saWIvc3JjLyIsInNvdXJjZXMiOlsia2QtY29tcG9uZW50cy9rZC1hbmd1bGFyLXNsaWRlci9rZC1hbmd1bGFyLXNsaWRlci1jb250ZW50LnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUNBLE9BQU8sRUFBRSxLQUFLLElBQUksZUFBZSxFQUFjLE1BQU0sTUFBTSxDQUFDO0FBRzVELE9BQU8sRUFDSCxTQUFTLEVBQ1QsaUJBQWlCLEVBQ2pCLEtBQUssRUFLTCxVQUFVLEVBRVYsWUFBWSxFQUNaLE1BQU0sRUFDTixTQUFTLEVBQ1QsU0FBUyxFQUNaLE1BQU0sZUFBZSxDQUFDO0FBQ3ZCLE9BQU8sRUFBRSxZQUFZLEVBQUUsTUFBTSxvQkFBb0IsQ0FBQztBQUdsRCxPQUFPLEVBQUUsV0FBVyxFQUFFLE1BQU0seUJBQXlCLENBQUM7QUFtQ3RELE1BQU0sT0FBTyxlQUFlO0lBeUR4QixZQUNZLFdBQXVCLEVBQy9CLGFBQTJCLEVBQ25CLFNBQW9CLEVBQ3BCLFVBQXVCO1FBSHZCLGdCQUFXLEdBQVgsV0FBVyxDQUFZO1FBRXZCLGNBQVMsR0FBVCxTQUFTLENBQVc7UUFDcEIsZUFBVSxHQUFWLFVBQVUsQ0FBYTtRQXhENUIsdUJBQWtCLEdBQVcsQ0FBQyxDQUFDO1FBQy9CLGFBQVEsR0FBWSxLQUFLLENBQUM7UUFDMUIsV0FBTSxHQUFrQixFQUFFLENBQUM7UUFFM0IsWUFBTyxHQUFZLEtBQUssQ0FBQztRQUV6QixlQUFVLEdBQXVCLENBQUMsRUFBRSxFQUFFLEVBQUUsQ0FBQyxDQUFDO1FBQzFDLGlCQUFZLEdBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQztRQUN4QixxQkFBZ0IsR0FBVyxLQUFLLENBQUM7UUFDaEMscUJBQWdCLEdBQW1CLENBQUMsS0FBSyxDQUFDLENBQUM7UUFTNUMsZUFBVSxHQUFZLEtBQUssQ0FBQztRQU9uQyxrRUFBa0U7UUFDMUQsYUFBUSxHQUFXLENBQUMsQ0FBQztRQUNyQixjQUFTLEdBQWtCLENBQUMsQ0FBQyxFQUFFLEdBQUcsQ0FBQyxDQUFDO1FBQ3BDLGVBQVUsR0FBVyxLQUFLLENBQUM7UUFFbkMsb0NBQW9DO1FBQzVCLHNCQUFpQixHQUFzQixJQUFJLENBQUM7UUFHNUMsaUJBQVksR0FBWSxJQUFJLENBQUM7UUFFckM7OztVQUdFO1FBQ00sYUFBUSxHQUFZLEtBQUssQ0FBQztRQUVsQixlQUFVLEdBQVEsQ0FBQyxDQUFDO1FBRTNCLFdBQU0sR0FBWSxLQUFLLENBQUM7UUFFdkIsV0FBTSxHQUFxQixJQUFJLFlBQVksRUFBRSxDQUFDO1FBQzlDLFlBQU8sR0FBcUIsSUFBSSxZQUFZLEVBQUUsQ0FBQztRQVdyRCxJQUFJLENBQUMsVUFBVSxHQUFHLGFBQWEsQ0FBQyxvQkFBb0IsQ0FBQyxJQUFJLENBQUMsS0FBSyxNQUFNLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDO1FBQ3RGLElBQUksQ0FBQyxVQUFVLENBQUMsU0FBUyxHQUFHLElBQUksQ0FBQyxVQUFVLENBQUM7UUFDNUMsSUFBSSxDQUFDLFFBQVEsR0FBRyxhQUFhLENBQUMsY0FBYyxFQUFFLENBQUM7SUFDbkQsQ0FBQztJQUVELFFBQVE7UUFDSixJQUFJLE9BQU8sSUFBSSxDQUFDLFVBQVUsS0FBSyxXQUFXLEVBQUU7WUFDeEMsSUFBSSxDQUFDLE9BQU8sR0FBRyxJQUFJLENBQUM7WUFDcEIsT0FBTztTQUNWO1FBQ0QsSUFBSSxDQUFDLFVBQVUsQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFDLENBQUM7UUFDbEMsSUFBSSxDQUFDLEtBQUssR0FBRyxJQUFJLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsQ0FBQztRQUM1QyxJQUFJLENBQUMsK0JBQStCLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxDQUFDO1FBQ3RELElBQUksQ0FBQyxRQUFRLEVBQUUsQ0FBQztRQUNoQixJQUFJLENBQUMsWUFBWSxHQUFHLEtBQUssQ0FBQztJQUM5QixDQUFDO0lBRUQsV0FBVyxDQUFDLGNBQTZCO1FBQ3JDLElBQUksY0FBYyxDQUFDLGNBQWMsQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxZQUFZLEVBQUU7WUFDL0QsSUFBSSxJQUFJLENBQUMsTUFBTSxFQUFFO2dCQUNiLElBQUksQ0FBQyxhQUFhLEVBQUUsQ0FBQzthQUN4QjtpQkFBTTtnQkFDSCxJQUFJLENBQUMsY0FBYyxFQUFFLENBQUM7YUFDekI7U0FDSjtRQUVELElBQUksY0FBYyxDQUFDLGNBQWMsQ0FBQyxZQUFZLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxZQUFZLEVBQUU7WUFDbkUsSUFBSSxjQUFjLENBQUMsWUFBWSxDQUFDLENBQUMsWUFBWSxLQUFLLElBQUksQ0FBQyxLQUFLO2dCQUFFLE9BQU87WUFDckUsSUFBSSxDQUFDLEtBQUssR0FBRyxJQUFJLENBQUMsUUFBUSxDQUFDLGNBQWMsQ0FBQyxZQUFZLENBQUMsQ0FBQyxZQUFZLENBQUMsQ0FBQztZQUN0RSxJQUFJLElBQUksQ0FBQyxPQUFPLEVBQUU7Z0JBQ2QsSUFBSSxDQUFDLCtCQUErQixDQUFDLGNBQWMsQ0FBQyxZQUFZLENBQUMsQ0FBQyxZQUFZLENBQUMsQ0FBQztnQkFDaEYsSUFBSSxDQUFDLE9BQU8sR0FBRyxLQUFLLENBQUM7YUFDeEI7U0FDSjtRQUVELElBQUksY0FBYyxDQUFDLGNBQWMsQ0FBQyxhQUFhLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxZQUFZLEVBQUU7WUFDcEUsSUFBSSxjQUFjLENBQUMsYUFBYSxDQUFDLENBQUMsWUFBWSxLQUFLLElBQUksQ0FBQyxNQUFNO2dCQUFFLE9BQU87WUFDdkUsSUFBSSxDQUFDLFVBQVUsQ0FBQyxjQUFjLENBQUMsYUFBYSxDQUFDLENBQUMsWUFBWSxDQUFDLENBQUM7U0FDL0Q7SUFDTCxDQUFDO0lBRUQsZUFBZTtRQUNYLElBQUksSUFBSSxDQUFDLE9BQU87WUFBRSxPQUFPO1FBRXpCLElBQUksVUFBVSxHQUFXLElBQUksQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztRQUNuRCxLQUFLLElBQUksQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLEdBQUcsVUFBVSxFQUFFLEVBQUUsQ0FBQyxFQUFFO1lBQ2pDLElBQUksQ0FBQyxVQUFVLENBQUMsQ0FBQyxDQUFDLENBQUMsc0JBQXNCLEVBQUUsQ0FBQztTQUMvQztRQUNELElBQUksQ0FBQyw4QkFBOEIsRUFBRSxDQUFDO1FBQ3RDLElBQUksSUFBSSxDQUFDLFFBQVEsRUFBRTtZQUNmLElBQUksQ0FBQywyQkFBMkIsRUFBRSxDQUFDO1NBQ3RDO2FBQU07WUFDSCxJQUFJLENBQUMscUJBQXFCLEVBQUUsQ0FBQztTQUNoQztJQUNMLENBQUM7SUFFRCxXQUFXO1FBQ1AsSUFBSSxJQUFJLENBQUMsT0FBTztZQUFFLE9BQU87UUFFekIsSUFBSSxDQUFDLDBCQUEwQixFQUFFLENBQUM7UUFDbEMsSUFBSSxJQUFJLENBQUMsTUFBTSxDQUFDLEtBQUs7WUFBRSxJQUFJLENBQUMsMkJBQTJCLEVBQUUsQ0FBQztRQUUxRCxJQUFJLElBQUksQ0FBQyxRQUFRLEVBQUU7WUFDZixJQUFJLENBQUMsa0JBQWtCLEVBQUUsQ0FBQztTQUM3QjthQUFNO1lBQ0gsSUFBSSxDQUFDLHFCQUFxQixFQUFFLENBQUM7U0FDaEM7UUFDRCxJQUFJLENBQUMscUJBQXFCLENBQUMsVUFBVSxDQUFDLENBQUM7SUFDM0MsQ0FBQztJQUVPLFVBQVUsQ0FBQyxPQUFzQjtRQUNyQyxJQUFJLENBQUMsTUFBTSxHQUFHLE1BQU0sQ0FBQyxNQUFNLENBQUMsRUFBRSxFQUFFLE9BQU8sQ0FBQyxDQUFDO1FBQ3pDLElBQUksQ0FBQyxVQUFVLENBQUMsTUFBTSxHQUFHLE9BQU8sQ0FBQztRQUNqQyxJQUFJLENBQUMsS0FBSyxHQUFHLE9BQU8sQ0FBQyxXQUFXLEtBQUssVUFBVSxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQztRQUM1RCxJQUFJLENBQUMsU0FBUyxHQUFHLE9BQU8sQ0FBQyxXQUFXLEtBQUssVUFBVSxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQztRQUNuRSxJQUFJLENBQUMsYUFBYSxHQUFHLElBQUksQ0FBQyxVQUFVLENBQUMsVUFBVSxFQUFFLENBQUM7UUFDbEQsSUFBSSxDQUFDLFVBQVUsQ0FBQyxxQkFBcUIsRUFBRSxDQUFDO1FBQ3hDLElBQUksQ0FBQyxnQkFBZ0IsR0FBRyxJQUFJLENBQUMsVUFBVSxDQUFDLG1CQUFtQixDQUFDLE9BQU8sQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDO0lBQzFGLENBQUM7SUFFTyxRQUFRLENBQUMsTUFBVztRQUN4QixJQUFJLEtBQUssQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDO1lBQUUsT0FBTyxNQUFNLENBQUMsR0FBRyxDQUFDLENBQUMsRUFBRSxFQUFFLEVBQUUsR0FBRyxPQUFPLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO1FBQ3JFLE9BQU8sTUFBTSxDQUFDO0lBQ2xCLENBQUM7SUFFTywrQkFBK0IsQ0FBQyxNQUFNO1FBQzFDLElBQUksS0FBSyxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsRUFBRTtZQUN2QixJQUFJLENBQUMsU0FBUyxHQUFHLE1BQU0sQ0FBQyxHQUFHLENBQUMsQ0FBQyxFQUFFLEVBQUUsRUFBRSxHQUFHLE9BQU8sSUFBSSxDQUFDLFVBQVUsQ0FBQyxtQkFBbUIsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO1lBQ3pGLElBQUksQ0FBQyxvQkFBb0IsR0FBRyxJQUFJLENBQUMscUJBQXFCLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO1lBQzFFLElBQUksQ0FBQyxxQkFBcUIsR0FBRyxJQUFJLENBQUMscUJBQXFCLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO1lBQzNFLElBQUksQ0FBQyxnQkFBZ0IsR0FBRyxDQUFDLEtBQUssRUFBRSxLQUFLLENBQUMsQ0FBQztZQUN2QyxJQUFJLENBQUMsWUFBWSxHQUFHLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxNQUFNLENBQUMsQ0FBQztTQUNyRDthQUFNO1lBQ0gsSUFBSSxDQUFDLFFBQVEsR0FBRyxJQUFJLENBQUMsVUFBVSxDQUFDLG1CQUFtQixDQUFDLE1BQU0sQ0FBQyxDQUFDO1lBQzVELElBQUksQ0FBQyxvQkFBb0IsR0FBRyxJQUFJLENBQUMscUJBQXFCLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxDQUFDO1lBQ3RFLElBQUksQ0FBQyxZQUFZLENBQUMsQ0FBQyxDQUFDLEdBQUcsSUFBSSxDQUFDLGdCQUFnQixDQUFDLE1BQU0sQ0FBQyxDQUFDO1NBQ3hEO1FBQ0QsSUFBSSxDQUFDLGVBQWUsR0FBRyxJQUFJLENBQUMsZ0JBQWdCLEVBQUUsQ0FBQztJQUNuRCxDQUFDO0lBR0QseUZBQXlGO0lBQ3pGOzZGQUN5RjtJQUV6RixZQUFZLENBQUMsS0FBVztRQUNwQixJQUFJLElBQUksQ0FBQyxPQUFPO1lBQUUsT0FBTztRQUN6QixJQUFJLENBQUMsVUFBVSxHQUFHLElBQUksQ0FBQztRQUN2QixJQUFJLENBQUMscUJBQXFCLENBQUMsVUFBVSxDQUFDLENBQUM7UUFDdkMsSUFBSSxJQUFJLENBQUMsTUFBTSxDQUFDLFFBQVEsRUFBRTtZQUN0QixPQUFPO1NBQ1Y7UUFDRCw0RkFBNEY7UUFDNUYseUVBQXlFO1FBQ3pFLElBQUksQ0FBQyxpQkFBaUIsR0FBRyxJQUFJLENBQUMsb0JBQW9CLEVBQUUsQ0FBQztJQUN6RCxDQUFDO0lBQ0QsWUFBWSxDQUFDLEtBQVc7UUFDcEIsSUFBSSxJQUFJLENBQUMsT0FBTztZQUFFLE9BQU87UUFDekIsSUFBSSxDQUFDLElBQUksQ0FBQyxRQUFRO1lBQUUsSUFBSSxDQUFDLEtBQUssQ0FBQyxZQUFZLENBQUMsQ0FBQztRQUM3QyxJQUFJLENBQUMscUJBQXFCLENBQUMsVUFBVSxDQUFDLENBQUM7UUFDdkMsSUFBSSxDQUFDLFVBQVUsR0FBRyxLQUFLLENBQUM7SUFDNUIsQ0FBQztJQUVELE9BQU8sQ0FBQyxLQUFVO1FBQ2QsSUFBSSxJQUFJLENBQUMsT0FBTztZQUFFLE9BQU87UUFDekIsSUFBSSxDQUFDLFlBQVksQ0FBQyxFQUFFLENBQUMsRUFBRSxLQUFLLENBQUMsT0FBTyxFQUFFLENBQUMsRUFBRSxLQUFLLENBQUMsT0FBTyxFQUFFLENBQUMsQ0FBQztRQUMxRCxLQUFLLENBQUMsZUFBZSxFQUFFLENBQUM7SUFDNUIsQ0FBQztJQUVELFdBQVcsQ0FBQyxLQUFVLEVBQUUsRUFBVTtRQUM5QixJQUFJLElBQUksQ0FBQyxPQUFPO1lBQUUsT0FBTztRQUN6QixJQUFJLENBQUMsSUFBSSxDQUFDLFFBQVEsRUFBRTtZQUNoQixJQUFJLENBQUMsT0FBTyxDQUFDLEVBQUUsQ0FBQyxFQUFFLEtBQUssQ0FBQyxPQUFPLEVBQUUsQ0FBQyxFQUFFLEtBQUssQ0FBQyxPQUFPLEVBQUUsRUFBRSxFQUFFLENBQUMsQ0FBQztTQUM1RDtRQUNELEtBQUssQ0FBQyxjQUFjLEVBQUUsQ0FBQztJQUMzQixDQUFDO0lBQ0QsV0FBVyxDQUFDLEtBQVU7UUFDbEIsSUFBSSxJQUFJLENBQUMsT0FBTztZQUFFLE9BQU87UUFDekIsSUFBSSxDQUFDLElBQUksQ0FBQyxRQUFRLEVBQUU7WUFDaEIsSUFBSSxDQUFDLE1BQU0sQ0FBQyxFQUFFLENBQUMsRUFBRSxLQUFLLENBQUMsT0FBTyxFQUFFLENBQUMsRUFBRSxLQUFLLENBQUMsT0FBTyxFQUFFLENBQUMsQ0FBQztTQUN2RDtRQUNELEtBQUssQ0FBQyxjQUFjLEVBQUUsQ0FBQztJQUMzQixDQUFDO0lBQ0QsU0FBUyxDQUFDLEtBQVU7UUFDaEIsSUFBSSxJQUFJLENBQUMsT0FBTztZQUFFLE9BQU87UUFDekIsSUFBSSxDQUFDLElBQUksQ0FBQyxRQUFRO1lBQUUsSUFBSSxDQUFDLEtBQUssQ0FBQyxTQUFTLENBQUMsQ0FBQztRQUMxQyxLQUFLLENBQUMsY0FBYyxFQUFFLENBQUM7SUFDM0IsQ0FBQztJQUVELFlBQVksQ0FBQyxLQUFVLEVBQUUsRUFBRTtRQUN2QixJQUFJLElBQUksQ0FBQyxPQUFPO1lBQUUsT0FBTztRQUN6QixJQUFJLENBQUMsT0FBTyxDQUFDLEVBQUUsQ0FBQyxFQUFFLEtBQUssQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLENBQUMsT0FBTyxFQUFFLENBQUMsRUFBRSxLQUFLLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxDQUFDLE9BQU8sRUFBRSxFQUFFLEVBQUUsQ0FBQyxDQUFDO1FBQ25GLEtBQUssQ0FBQyxjQUFjLEVBQUUsQ0FBQztRQUN2QixLQUFLLENBQUMsZUFBZSxFQUFFLENBQUM7SUFFNUIsQ0FBQztJQUNELFdBQVcsQ0FBQyxLQUFVO1FBQ2xCLElBQUksSUFBSSxDQUFDLE9BQU87WUFBRSxPQUFPO1FBQ3pCLElBQUksQ0FBQyxNQUFNLENBQUMsRUFBRSxDQUFDLEVBQUUsS0FBSyxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsQ0FBQyxPQUFPLEVBQUUsQ0FBQyxFQUFFLEtBQUssQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLENBQUMsT0FBTyxFQUFFLENBQUMsQ0FBQztRQUM5RSxLQUFLLENBQUMsY0FBYyxFQUFFLENBQUM7UUFDdkIsS0FBSyxDQUFDLGVBQWUsRUFBRSxDQUFDO0lBQzVCLENBQUM7SUFDRCxVQUFVLENBQUMsS0FBVTtRQUNqQixJQUFJLElBQUksQ0FBQyxPQUFPO1lBQUUsT0FBTztRQUN6QixJQUFJLENBQUMsS0FBSyxDQUFDLFVBQVUsQ0FBQyxDQUFDO1FBQ3ZCLEtBQUssQ0FBQyxlQUFlLEVBQUUsQ0FBQztJQUM1QixDQUFDO0lBRU8sMkJBQTJCO1FBQy9CLElBQUksQ0FBQyxrQkFBa0IsR0FBRyxJQUFJLENBQUMsU0FBUyxDQUFDLE1BQU0sQ0FBQyxVQUFVLEVBQUUsWUFBWSxFQUFFLENBQUMsS0FBSyxFQUFFLEVBQUU7WUFDaEYsSUFBSSxDQUFDLHFCQUFxQixDQUFDLFVBQVUsQ0FBQyxDQUFDO1lBQ3ZDLElBQUksQ0FBQyxVQUFVLEdBQUcsS0FBSyxDQUFDO1FBQzVCLENBQUMsQ0FBQyxDQUFDO0lBQ1AsQ0FBQztJQUVPLHFCQUFxQjtRQUN6QixJQUFJLENBQUMscUJBQXFCLEdBQUcsSUFBSSxDQUFDLFNBQVMsQ0FBQyxNQUFNLENBQUMsUUFBUSxFQUFFLFlBQVksRUFBRSxDQUFDLEtBQUssRUFBRSxFQUFFO1lBQ2pGLGVBQWUsQ0FBQyxFQUFFLENBQUMsQ0FBQyxTQUFTLENBQUMsR0FBRyxFQUFFO2dCQUMvQixJQUFJLENBQUMscUJBQXFCLENBQUMsVUFBVSxDQUFDLENBQUM7Z0JBQ3ZDLElBQUksQ0FBQyxVQUFVLEdBQUcsS0FBSyxDQUFDO1lBQzVCLENBQUMsQ0FBQyxDQUFDO1FBQ1AsQ0FBQyxDQUFDLENBQUM7UUFDSCxJQUFJLENBQUMscUJBQXFCLEdBQUcsSUFBSSxDQUFDLFNBQVMsQ0FBQyxNQUFNLENBQUMsUUFBUSxFQUFFLGdCQUFnQixFQUFFLENBQUMsS0FBSyxFQUFFLEVBQUU7WUFDckYsZUFBZSxDQUFDLEVBQUUsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxHQUFHLEVBQUU7Z0JBQy9CLElBQUksQ0FBQyxxQkFBcUIsQ0FBQyxVQUFVLENBQUMsQ0FBQztnQkFDdkMsSUFBSSxDQUFDLFVBQVUsR0FBRyxLQUFLLENBQUM7WUFDNUIsQ0FBQyxDQUFDLENBQUM7UUFDUCxDQUFDLENBQUMsQ0FBQztJQUNQLENBQUM7SUFFTyw4QkFBOEI7UUFDbEMsSUFBSSxzQkFBc0IsR0FBRyxJQUFJLENBQUMsV0FBVyxDQUFDLGFBQWEsQ0FBQyxnQkFBZ0IsQ0FBQyx5RkFBeUYsQ0FBQyxDQUFDO1FBQ3hLLElBQUksQ0FBQywwQkFBMEIsR0FBRyxJQUFJLENBQUMsU0FBUyxDQUFDLE1BQU0sQ0FBQyxzQkFBc0IsQ0FBQyxDQUFDLENBQUMsRUFBRSxlQUFlLEVBQUUsR0FBRyxFQUFFO1lBQ3JHLElBQUksSUFBSSxDQUFDLE1BQU0sSUFBSSxJQUFJLENBQUMsTUFBTSxDQUFDLFFBQVE7Z0JBQUUsSUFBSSxDQUFDLG9CQUFvQixFQUFFLENBQUM7WUFFckUsSUFBSSxDQUFDLElBQUksQ0FBQyxNQUFNLElBQUksSUFBSSxDQUFDLFFBQVEsSUFBSSxDQUFDLElBQUksQ0FBQyxVQUFVO2dCQUFFLElBQUksQ0FBQyx5QkFBeUIsRUFBRSxDQUFDO1FBQzVGLENBQUMsQ0FBQyxDQUFDO1FBQ0gsSUFBSSxJQUFJLENBQUMsTUFBTSxDQUFDLEtBQUssRUFBRTtZQUNuQixJQUFJLENBQUMsMkJBQTJCLEdBQUcsSUFBSSxDQUFDLFNBQVMsQ0FBQyxNQUFNLENBQUMsc0JBQXNCLENBQUMsQ0FBQyxDQUFDLEVBQUUsZUFBZSxFQUFFLEdBQUcsRUFBRTtnQkFDdEcsSUFBSSxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsUUFBUSxJQUFJLElBQUksQ0FBQyxRQUFRLElBQUksQ0FBQyxJQUFJLENBQUMsVUFBVTtvQkFBRSxJQUFJLENBQUMseUJBQXlCLEVBQUUsQ0FBQztZQUNyRyxDQUFDLENBQUMsQ0FBQztTQUNOO0lBQ0wsQ0FBQztJQUVPLHlCQUF5QjtRQUM3QixJQUFJLENBQUMscUJBQXFCLENBQUMsZUFBZSxDQUFDLENBQUM7UUFDNUMsSUFBSSxDQUFDLFFBQVEsR0FBRyxLQUFLLENBQUM7UUFDdEIsSUFBSSxDQUFDLElBQUksQ0FBQyxVQUFVO1lBQUUsVUFBVSxDQUFDLEdBQUcsRUFBRSxDQUFDLElBQUksQ0FBQyxxQkFBcUIsQ0FBQyxlQUFlLENBQUMsRUFBRSxJQUFJLENBQUMsQ0FBQztJQUM5RixDQUFDO0lBRUQseUZBQXlGO0lBQ3pGOzZGQUN5RjtJQUVqRixPQUFPLENBQUMsR0FBNkIsRUFBRSxFQUFFO1FBQzdDLElBQUksSUFBSSxDQUFDLE1BQU0sQ0FBQyxRQUFRLElBQUksSUFBSSxDQUFDLFVBQVUsRUFBRTtZQUN6QyxPQUFPO1NBQ1Y7UUFDRCx1REFBdUQ7UUFDdkQsSUFBSSxDQUFDLFlBQVksRUFBRSxDQUFDO1FBRXBCLElBQUksQ0FBQyxVQUFVLEdBQUcsSUFBSSxDQUFDO1FBQ3ZCLElBQUksSUFBSSxDQUFDLE1BQU0sQ0FBQyxLQUFLLEVBQUU7WUFDbkIsSUFBSSxDQUFDLGtCQUFrQixHQUFHLEVBQUUsQ0FBQztZQUM3QixJQUFJLENBQUMsa0JBQWtCLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsa0JBQWtCLENBQUMsQ0FBQztTQUNqRTthQUFNO1lBQ0gsSUFBSSxDQUFDLGtCQUFrQixHQUFHLElBQUksQ0FBQyxLQUFLLENBQUM7U0FDeEM7UUFDRCxJQUFJLENBQUMsWUFBWSxDQUFDLEdBQUcsQ0FBQyxDQUFDO0lBQzNCLENBQUM7SUFFTyxNQUFNLENBQUMsR0FBNkI7UUFDeEMsSUFBSSxJQUFJLENBQUMsTUFBTSxDQUFDLFFBQVEsSUFBSSxDQUFDLElBQUksQ0FBQyxVQUFVLEVBQUU7WUFDMUMsT0FBTztTQUNWO1FBRUQsSUFBSSxRQUFRLEdBQVcsQ0FBQyxDQUFDO1FBRXpCLElBQUksSUFBSSxDQUFDLE1BQU0sQ0FBQyxLQUFLLEVBQUU7WUFDbkIsUUFBUSxHQUFHLElBQUksQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLGtCQUFrQixDQUFDLENBQUM7WUFDL0MsSUFBSSxDQUFDLFlBQVksQ0FBQyxHQUFHLENBQUMsQ0FBQztZQUV2QixJQUFJLFFBQVEsS0FBSyxJQUFJLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxFQUFFO2dCQUNsRCxJQUFJLENBQUMsZ0JBQWdCLENBQUMsU0FBUyxDQUFDLENBQUM7Z0JBQ2pDLE9BQU87YUFDVjtTQUNKO1FBRUQsUUFBUSxHQUFHLElBQUksQ0FBQyxLQUFLLENBQUM7UUFDdEIsSUFBSSxDQUFDLFlBQVksQ0FBQyxHQUFHLENBQUMsQ0FBQztRQUN2Qix5RkFBeUY7UUFDekYsSUFBSSxRQUFRLEtBQUssSUFBSSxDQUFDLEtBQUssRUFBRTtZQUN6QixJQUFJLENBQUMsZ0JBQWdCLENBQUMsU0FBUyxDQUFDLENBQUM7U0FDcEM7SUFDTCxDQUFDO0lBRU8sS0FBSyxDQUFDLFVBQWtCO1FBQzVCLElBQUksQ0FBQyxJQUFJLENBQUMsVUFBVSxFQUFFO1lBQ2xCLE9BQU87U0FDVjtRQUVELElBQUksVUFBVSxLQUFLLFlBQVksRUFBRTtZQUM3QixJQUFJLENBQUMsVUFBVSxHQUFHLEtBQUssQ0FBQztTQUMzQjthQUFNLElBQUksSUFBSSxDQUFDLFFBQVE7WUFBRSxJQUFJLENBQUMsVUFBVSxHQUFHLEtBQUssQ0FBQztRQUVsRCxJQUFJLElBQUksQ0FBQyxNQUFNLENBQUMsS0FBSyxFQUFFO1lBQ25CLElBQUksSUFBSSxDQUFDLGtCQUFrQixLQUFLLElBQUksQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLGtCQUFrQixDQUFDO2dCQUFFLElBQUksQ0FBQyxnQkFBZ0IsRUFBRSxDQUFDO1NBQ2hHO2FBQU07WUFDSCxJQUFJLElBQUksQ0FBQyxrQkFBa0IsS0FBSyxJQUFJLENBQUMsS0FBSztnQkFBRSxJQUFJLENBQUMsZ0JBQWdCLEVBQUUsQ0FBQztTQUN2RTtRQUVELElBQUksQ0FBQyxrQkFBa0IsR0FBRyxJQUFJLENBQUM7SUFDbkMsQ0FBQztJQUVPLFlBQVksQ0FBQyxHQUE2QjtRQUM5QyxJQUFJLElBQUksQ0FBQyxNQUFNLENBQUMsUUFBUSxFQUFFO1lBQ3RCLE9BQU87U0FDVjtRQUVELHVEQUF1RDtRQUN2RCxJQUFJLENBQUMsWUFBWSxFQUFFLENBQUM7UUFFcEIsSUFBSSxDQUFDLFFBQVEsR0FBRyxJQUFJLENBQUM7UUFFckIsSUFBSSxJQUFJLENBQUMsUUFBUSxJQUFJLENBQUMsSUFBSSxDQUFDLFVBQVUsRUFBRTtZQUNuQyxJQUFJLENBQUMscUJBQXFCLENBQUMsZUFBZSxDQUFDLENBQUM7U0FDL0M7UUFDRCxJQUFJLENBQUMsVUFBVSxHQUFHLEtBQUssQ0FBQztRQUV4QixJQUFJLFFBQVEsR0FBVyxDQUFDLENBQUM7UUFFekIsSUFBSSxJQUFJLENBQUMsTUFBTSxDQUFDLEtBQUssRUFBRTtZQUNuQixRQUFRLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsa0JBQWtCLENBQUMsQ0FBQztZQUMvQyxJQUFJLENBQUMsWUFBWSxDQUFDLEdBQUcsQ0FBQyxDQUFDO1lBQ3ZCLElBQUksUUFBUSxLQUFLLElBQUksQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLGtCQUFrQixDQUFDLEVBQUU7Z0JBQ2xELElBQUksQ0FBQyxnQkFBZ0IsRUFBRSxDQUFDO2dCQUN4QixPQUFPO2FBQ1Y7U0FDSjtRQUVELFFBQVEsR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDO1FBQ3RCLElBQUksQ0FBQyxZQUFZLENBQUMsR0FBRyxDQUFDLENBQUM7UUFFdkIseURBQXlEO1FBQ3pELElBQUksUUFBUSxLQUFLLElBQUksQ0FBQyxLQUFLLEVBQUU7WUFDekIsSUFBSSxDQUFDLGdCQUFnQixFQUFFLENBQUM7U0FDM0I7SUFDTCxDQUFDO0lBRUQseUZBQXlGO0lBQ3pGOzZGQUN5RjtJQUVqRixhQUFhO1FBQ2pCLElBQUksQ0FBQyxNQUFNLENBQUMsUUFBUSxHQUFHLElBQUksQ0FBQztRQUM1QixJQUFJLENBQUMsb0JBQW9CLEVBQUUsQ0FBQztJQUNoQyxDQUFDO0lBRU8sY0FBYztRQUNsQixJQUFJLENBQUMsTUFBTSxDQUFDLFFBQVEsR0FBRyxLQUFLLENBQUM7SUFDakMsQ0FBQztJQUVPLG9CQUFvQjtRQUN4QixJQUFJLENBQUMscUJBQXFCLENBQUMsZUFBZSxDQUFDLENBQUM7UUFDNUMsVUFBVSxDQUFDLEdBQUcsRUFBRTtZQUNaLElBQUksQ0FBQyxxQkFBcUIsQ0FBQyxlQUFlLENBQUMsQ0FBQztZQUM1QyxJQUFJLENBQUMsSUFBSSxDQUFDLE1BQU07Z0JBQUUsT0FBTztZQUV6QixJQUFJLENBQUMsS0FBSyxHQUFHLElBQUksQ0FBQyxLQUFLLEdBQUcsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLFlBQVksSUFBSSxDQUFDLENBQUMsQ0FBQztZQUUxRCxJQUFJLElBQUksQ0FBQyxLQUFLLEdBQUcsSUFBSSxDQUFDLE1BQU0sQ0FBQyxHQUFHLEVBQUU7Z0JBQzlCLElBQUksQ0FBQyxLQUFLLEdBQUcsSUFBSSxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUM7Z0JBQzdCLElBQUksQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDO2dCQUN4QixJQUFJLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQyxDQUFDLFdBQVcsRUFBRSxDQUFDO2dCQUNqQyxJQUFJLENBQUMsTUFBTSxDQUFDLFFBQVEsR0FBRyxLQUFLLENBQUM7YUFDaEM7WUFFRCxJQUFJLENBQUMsUUFBUSxHQUFHLElBQUksQ0FBQyxVQUFVLENBQUMsbUJBQW1CLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFDO1lBQ2hFLElBQUksQ0FBQyxlQUFlLEVBQUUsQ0FBQztZQUN2QixJQUFJLENBQUMsZ0JBQWdCLEVBQUUsQ0FBQztRQUM1QixDQUFDLEVBQUUsSUFBSSxDQUFDLE1BQU0sQ0FBQyxhQUFhLElBQUksR0FBRyxDQUFDLENBQUM7SUFDekMsQ0FBQztJQUVELHlGQUF5RjtJQUN6Rjs2RkFDeUY7SUFFekYsMEZBQTBGO0lBQ2xGLGdCQUFnQixDQUFDLGNBQTBCO1FBQy9DLElBQUksQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDO1lBQ2IsS0FBSyxFQUFFLElBQUksQ0FBQyxLQUFLO1lBQ2pCLGFBQWEsRUFBRSxjQUFjO1NBQ2hDLENBQUMsQ0FBQztJQUNQLENBQUM7SUFFRCx5RkFBeUY7SUFDekY7NkZBQ3lGO0lBRWpGLGdCQUFnQjtRQUNwQixJQUFJLElBQUksQ0FBQyxNQUFNLENBQUMsS0FBSyxFQUFFO1lBQ25CLElBQUksWUFBWSxHQUFZLENBQUMsSUFBSSxDQUFDLFVBQVUsS0FBSyxLQUFLLElBQUksQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxVQUFVLEVBQUUsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxVQUFVLEVBQUUsQ0FBQztZQUMxSSxJQUFJLElBQUksR0FBVyxZQUFZLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDO1lBQzNDLElBQUksa0JBQWtCLEdBQVcsWUFBWSxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLEdBQUcsSUFBSSxDQUFDLGdCQUFnQixDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztZQUMxSSxJQUFJLFlBQVksR0FBVyxJQUFJLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxHQUFHLElBQUksQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUM7WUFDakUsT0FBTztnQkFDSCxXQUFXLEVBQUUsWUFBWSxJQUFJLENBQUMsS0FBSyxJQUFJLElBQUksR0FBRyxrQkFBa0IsV0FBVyxJQUFJLENBQUMsS0FBSyxJQUFJLFlBQVksR0FBRzthQUMzRyxDQUFDO1NBQ0w7UUFDRCxPQUFPO1lBQ0gsV0FBVyxFQUFFLFFBQVEsSUFBSSxDQUFDLEtBQUssSUFBSSxJQUFJLENBQUMsUUFBUSxHQUFHO1NBQ3RELENBQUM7SUFDTixDQUFDO0lBRU8scUJBQXFCLENBQUMsUUFBZ0I7UUFDMUMsSUFBSSxNQUFNLEdBQVcsSUFBSSxDQUFDLGdCQUFnQixDQUFDLFFBQVEsQ0FBQyxDQUFDO1FBQ3JELE9BQU87WUFDSCxXQUFXLEVBQUUsWUFBWSxJQUFJLENBQUMsS0FBSyxLQUFLLE1BQU0sSUFBSTtTQUNyRCxDQUFDO0lBQ04sQ0FBQztJQUVPLGdCQUFnQixDQUFDLFFBQWdCO1FBQ3JDLHlGQUF5RjtRQUN6RiwrRUFBK0U7UUFDL0UsSUFBSSxZQUFZLEdBQVksQ0FBQyxJQUFJLENBQUMsVUFBVSxLQUFLLEtBQUssSUFBSSxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLFVBQVUsRUFBRSxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLFVBQVUsRUFBRSxDQUFDO1FBQzFJLE9BQU8sQ0FBQyxZQUFZLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLFFBQVEsQ0FBQyxHQUFHLEdBQUcsQ0FBQztJQUMxRCxDQUFDO0lBRUQseUZBQXlGO0lBQ3pGOzZGQUN5RjtJQUVqRixZQUFZLENBQUMsSUFBK0IsRUFBRSxNQUFlO1FBQ2pFLElBQUksUUFBUSxHQUFXLE9BQU8sTUFBTSxLQUFLLFdBQVcsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsd0JBQXdCLENBQUMsSUFBSSxDQUFDLENBQUM7UUFDcEcsSUFBSSxJQUFJLENBQUMsTUFBTSxDQUFDLEtBQUssRUFBRTtZQUNuQixJQUFJLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxHQUFHLFFBQVEsQ0FBQztZQUMvQyxJQUFJLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxHQUFHLElBQUksQ0FBQyxVQUFVLENBQUMsbUJBQW1CLENBQUMsUUFBUSxDQUFDLENBQUM7U0FDM0Y7YUFBTTtZQUNILElBQUksQ0FBQyxLQUFLLEdBQUcsUUFBUSxDQUFDO1lBQ3RCLElBQUksQ0FBQyxRQUFRLEdBQUcsSUFBSSxDQUFDLFVBQVUsQ0FBQyxtQkFBbUIsQ0FBQyxRQUFRLENBQUMsQ0FBQztTQUNqRTtRQUNELElBQUksQ0FBQyxlQUFlLEVBQUUsQ0FBQztJQUMzQixDQUFDO0lBRU8sd0JBQXdCLENBQUMsSUFBOEI7UUFDM0QsSUFBSSxDQUFDLElBQUksQ0FBQyxpQkFBaUIsRUFBRTtZQUN6QixPQUFPO1NBQ1Y7UUFFRCxJQUFJLE1BQU0sR0FBVyxJQUFJLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsaUJBQWlCLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsaUJBQWlCLENBQUMsSUFBSSxDQUFDO1FBQy9GLElBQUksSUFBSSxHQUFXLElBQUksQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxLQUFLLENBQUM7UUFDakcsSUFBSSxZQUFZLEdBQVcsSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQztRQUU1RCx3RkFBd0Y7UUFDeEYsSUFBSSxPQUFPLEdBQVcsSUFBSSxDQUFDLFVBQVUsQ0FBQyxLQUFLLENBQUMsQ0FBQyxZQUFZLEdBQUcsTUFBTSxDQUFDLEdBQUcsSUFBSSxDQUFDLENBQUM7UUFDNUUsSUFBSSxJQUFJLENBQUMsVUFBVSxDQUFDLGlCQUFpQixFQUFFLEVBQUU7WUFDckMsT0FBTyxHQUFHLENBQUMsR0FBRyxPQUFPLENBQUM7U0FDekI7UUFFRCxJQUFJLFVBQVUsR0FBVyxJQUFJLENBQUMsVUFBVSxDQUFDLGNBQWMsQ0FBQyxPQUFPLENBQUMsQ0FBQztRQUVqRSxJQUFJLElBQUksQ0FBQyxNQUFNLENBQUMsS0FBSyxFQUFFO1lBQ25CLElBQUksVUFBVSxHQUFXLElBQUksQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFDLEdBQUcsSUFBSSxDQUFDLGtCQUFrQixDQUFDLENBQUMsQ0FBQztZQUMzRSxJQUFJLElBQUksQ0FBQyxVQUFVLENBQUMsa0JBQWtCLENBQUMsVUFBVSxFQUFFLFVBQVUsRUFBRSxJQUFJLENBQUMsa0JBQWtCLENBQUMsRUFBRTtnQkFDckYsVUFBVSxHQUFHLFVBQVUsQ0FBQzthQUMzQjtTQUNKO1FBQ0QsT0FBTyxVQUFVLENBQUM7SUFDdEIsQ0FBQztJQUVPLGVBQWU7UUFDbkIsSUFBSSxJQUFJLENBQUMsTUFBTSxDQUFDLEtBQUssRUFBRTtZQUNuQixJQUFJLElBQUksQ0FBQyxrQkFBa0IsS0FBSyxDQUFDLEVBQUU7Z0JBQy9CLElBQUksQ0FBQyxvQkFBb0IsR0FBRyxJQUFJLENBQUMscUJBQXFCLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO2FBQzdFO2lCQUFNO2dCQUNILElBQUksQ0FBQyxxQkFBcUIsR0FBRyxJQUFJLENBQUMscUJBQXFCLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO2FBQzlFO1NBQ0o7YUFBTTtZQUNILElBQUksQ0FBQyxvQkFBb0IsR0FBRyxJQUFJLENBQUMscUJBQXFCLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxDQUFDO1NBQ3pFO1FBQ0QsSUFBSSxDQUFDLFlBQVksQ0FBQyxJQUFJLENBQUMsa0JBQWtCLENBQUMsR0FBRyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFDO1FBQy9FLElBQUksQ0FBQyxlQUFlLEdBQUcsSUFBSSxDQUFDLGdCQUFnQixFQUFFLENBQUM7UUFDL0MsSUFBSSxJQUFJLENBQUMsZ0JBQWdCLENBQUMsSUFBSSxDQUFDLGtCQUFrQixDQUFDO1lBQUUsSUFBSSxDQUFDLFVBQVUsQ0FBQyxJQUFJLENBQUMsa0JBQWtCLENBQUMsQ0FBQyxLQUFLLEVBQUUsQ0FBQztJQUN6RyxDQUFDO0lBRUQseUZBQXlGO0lBQ3pGOzZGQUN5RjtJQUVqRixnQkFBZ0IsQ0FBQyxNQUFNO1FBQzNCLElBQUksSUFBSSxHQUFRLEVBQUUsQ0FBQztRQUNuQixJQUFJLElBQUksQ0FBQyxNQUFNLENBQUMsS0FBSyxFQUFFO1lBQ25CLElBQUksSUFBSSxDQUFDLFlBQVksRUFBRTtnQkFDbkIsT0FBTyxNQUFNLENBQUMsR0FBRyxDQUFDLENBQUMsR0FBRyxFQUFFLEVBQUU7b0JBQ3RCLElBQUksR0FBRyxJQUFJLENBQUMsVUFBVSxDQUFDLG1CQUFtQixDQUFDLEdBQUcsQ0FBQyxDQUFDO29CQUNoRCxPQUFPLElBQUksQ0FBQyxVQUFVLENBQUMscUJBQXFCLENBQUMsSUFBSSxFQUFFLElBQUksQ0FBQyxNQUFNLENBQUMsYUFBYSxDQUFDLENBQUM7Z0JBQ2xGLENBQUMsQ0FBQyxDQUFDO2FBQ047WUFDRCxJQUFJLEdBQUcsSUFBSSxDQUFDLFVBQVUsQ0FBQyxtQkFBbUIsQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLGtCQUFrQixDQUFDLENBQUMsQ0FBQztTQUMvRTthQUFNLElBQUksSUFBSSxDQUFDLE1BQU0sQ0FBQyxJQUFJLEtBQUssUUFBUSxFQUFFO1lBQ3RDLElBQUksR0FBRyxJQUFJLENBQUMsTUFBTSxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsQ0FBQyxXQUFXLElBQUksSUFBSSxDQUFDLE1BQU0sQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLENBQUMsS0FBSyxDQUFDLFFBQVEsRUFBRSxDQUFDO1NBQ2xHO2FBQU07WUFDSCxJQUFJLEdBQUcsSUFBSSxDQUFDLFVBQVUsQ0FBQyxtQkFBbUIsQ0FBQyxNQUFNLENBQUMsQ0FBQztTQUN0RDtRQUNELE9BQU8sSUFBSSxDQUFDLFVBQVUsQ0FBQyxxQkFBcUIsQ0FBQyxJQUFJLEVBQUUsSUFBSSxDQUFDLE1BQU0sQ0FBQyxhQUFhLENBQUMsQ0FBQztJQUNsRixDQUFDO0lBRUQsMkNBQTJDO0lBQ25DLHFCQUFxQixDQUFDLEtBQWtFO1FBQzVGLElBQUksVUFBVSxHQUFXLElBQUksQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztRQUNuRCxRQUFRLEtBQUssRUFBRTtZQUNYLEtBQUssVUFBVTtnQkFDWCxLQUFLLElBQUksQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLEdBQUcsVUFBVSxFQUFFLEVBQUUsQ0FBQyxFQUFFO29CQUNqQyxJQUFJLENBQUMsSUFBSSxDQUFDLGdCQUFnQixDQUFDLENBQUMsQ0FBQyxFQUFFO3dCQUMzQixJQUFJLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQyxDQUFDLFdBQVcsRUFBRSxDQUFDO3dCQUNqQyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsQ0FBQyxDQUFDLEdBQUcsSUFBSSxDQUFDO3FCQUNuQztpQkFDSjtnQkFDRCxNQUFNO1lBQ1YsS0FBSyxVQUFVO2dCQUNYLEtBQUssSUFBSSxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsR0FBRyxVQUFVLEVBQUUsRUFBRSxDQUFDLEVBQUU7b0JBQ2pDLElBQUksSUFBSSxDQUFDLGdCQUFnQixDQUFDLENBQUMsQ0FBQyxFQUFFO3dCQUMxQixJQUFJLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQyxDQUFDLFdBQVcsRUFBRSxDQUFDO3dCQUNqQyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsQ0FBQyxDQUFDLEdBQUcsS0FBSyxDQUFDO3FCQUNwQztpQkFDSjtnQkFDRCxNQUFNO1lBQ1YsS0FBSyxlQUFlO2dCQUNoQixJQUFJLENBQUMsSUFBSSxDQUFDLGdCQUFnQixDQUFDLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxFQUFFO29CQUNqRCxJQUFJLENBQUMsVUFBVSxDQUFDLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxDQUFDLFdBQVcsRUFBRSxDQUFDO29CQUN2RCxJQUFJLENBQUMsZ0JBQWdCLENBQUMsSUFBSSxDQUFDLGtCQUFrQixDQUFDLEdBQUcsSUFBSSxDQUFDO2lCQUN6RDtnQkFDRCxNQUFNO1lBQ1YsS0FBSyxlQUFlO2dCQUNoQixJQUFJLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxJQUFJLENBQUMsa0JBQWtCLENBQUMsRUFBRTtvQkFDaEQsSUFBSSxDQUFDLFVBQVUsQ0FBQyxJQUFJLENBQUMsa0JBQWtCLENBQUMsQ0FBQyxXQUFXLEVBQUUsQ0FBQztvQkFDdkQsSUFBSSxDQUFDLGdCQUFnQixDQUFDLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxHQUFHLEtBQUssQ0FBQztpQkFDMUQ7Z0JBQ0QsTUFBTTtTQUNiO0lBQ0wsQ0FBQztJQUVELHlGQUF5RjtJQUN6Rjs2RkFDeUY7SUFFakYsUUFBUTtRQUNaLElBQUksT0FBTyxJQUFJLENBQUMsR0FBRyxLQUFLLFdBQVcsRUFBRTtZQUNqQyxJQUFJLENBQUMsR0FBRyxDQUFDLFdBQVcsR0FBRyxDQUFDLE1BQWMsRUFBRSxLQUFjLEVBQUUsRUFBRTtnQkFDdEQsSUFBSSxPQUFPLEtBQUssS0FBSyxXQUFXLEVBQUU7b0JBQzlCLElBQUksQ0FBQyxrQkFBa0IsR0FBRyxLQUFLLENBQUM7b0JBQ2hDLElBQUksQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLEdBQUcsTUFBTSxDQUFDO2lCQUM5QjtxQkFBTTtvQkFDSCxJQUFJLENBQUMsS0FBSyxHQUFHLE1BQU0sQ0FBQztpQkFDdkI7Z0JBQ0QsSUFBSSxDQUFDLFlBQVksQ0FBQyxJQUFJLEVBQUUsTUFBTSxDQUFDLENBQUM7Z0JBQ2hDLElBQUksQ0FBQyxnQkFBZ0IsRUFBRSxDQUFDO1lBQzVCLENBQUMsQ0FBQztTQUNMO0lBQ0wsQ0FBQztJQUVELHlGQUF5RjtJQUN6Rjs2RkFDeUY7SUFFekY7Ozs7TUFJRTtJQUNNLG9CQUFvQjtRQUN4QixPQUFPLElBQUksQ0FBQyxjQUFjLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxjQUFjLENBQUMsYUFBYSxDQUFDLHFCQUFxQixFQUFFLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQztJQUNsRyxDQUFDOzs7WUFwbkJKLFNBQVMsU0FBQztnQkFDUCxRQUFRLEVBQUUsbUJBQW1CO2dCQUM3QixpOENBQStDO2dCQUMvQyxhQUFhLEVBQUUsaUJBQWlCLENBQUMsSUFBSTtnQkFDckMsU0FBUyxFQUFFLENBQUMsWUFBWSxFQUFFLFdBQVcsQ0FBQztnQkFDdEMsSUFBSSxFQUFFO29CQUNGLGNBQWMsRUFBRSxzQkFBc0I7b0JBQ3RDLGNBQWMsRUFBRSxzQkFBc0I7b0JBQ3RDLFNBQVMsRUFBRSxpQkFBaUI7b0JBQzVCLGFBQWEsRUFBRSxxQkFBcUI7b0JBQ3BDLFdBQVcsRUFBRSxtQkFBbUI7b0JBQ2hDLGFBQWEsRUFBRSxxQkFBcUI7b0JBQ3BDLFlBQVksRUFBRSxvQkFBb0I7b0JBQ2xDLE9BQU8sRUFBRSxvQkFBb0I7b0JBQzdCLE1BQU0sRUFBRSxRQUFRO29CQUNoQixzQkFBc0IsRUFBRSxpQkFBaUI7b0JBQ3pDLHNCQUFzQixFQUFFLFlBQVk7b0JBQ3BDLHNCQUFzQixFQUFFLFlBQVk7b0JBQ3BDLHNCQUFzQixFQUFFLE9BQU87b0JBQy9CLHlCQUF5QixFQUFFLHVDQUF1QztvQkFDbEUsNkJBQTZCLEVBQUUsaUJBQWlCO29CQUNoRCwrQkFBK0IsRUFBRSxZQUFZO29CQUM3QyxrQ0FBa0MsRUFBRSxlQUFlO29CQUNuRCw0QkFBNEIsRUFBRSxZQUFZO29CQUMxQyw2QkFBNkIsRUFBRSxXQUFXO29CQUMxQyw0QkFBNEIsRUFBRSxZQUFZO29CQUMxQyxpQ0FBaUMsRUFBRSxpQkFBaUI7b0JBQ3BELDhCQUE4QixFQUFFLGNBQWM7b0JBQzlDLDhCQUE4QixFQUFFLFVBQVU7b0JBQzFDLDhCQUE4QixFQUFFLFVBQVU7aUJBQzdDO2FBQ0o7OztZQTNDRyxVQUFVO1lBT0wsWUFBWTtZQUZqQixTQUFTO1lBS0osV0FBVzs7O3lCQWtGZixLQUFLLFNBQUMsT0FBTzswQkFDYixLQUFLLFNBQUMsUUFBUTtxQkFDZCxLQUFLO2tCQUNMLEtBQUs7cUJBQ0wsTUFBTTtzQkFDTixNQUFNOzZCQUdOLFNBQVMsU0FBQyxlQUFlLEVBQUUsRUFBRSxNQUFNLEVBQUUsSUFBSSxFQUFFIiwic291cmNlc0NvbnRlbnQiOlsiXHJcbmltcG9ydCB7IHRpbWVyIGFzIG9ic2VydmFibGVUaW1lciwgT2JzZXJ2YWJsZSB9IGZyb20gJ3J4anMnO1xyXG5cclxuXHJcbmltcG9ydCB7XHJcbiAgICBDb21wb25lbnQsXHJcbiAgICBWaWV3RW5jYXBzdWxhdGlvbixcclxuICAgIElucHV0LFxyXG4gICAgT25Jbml0LFxyXG4gICAgT25DaGFuZ2VzLFxyXG4gICAgU2ltcGxlQ2hhbmdlcyxcclxuICAgIE9uRGVzdHJveSxcclxuICAgIEVsZW1lbnRSZWYsXHJcbiAgICBBZnRlclZpZXdJbml0LFxyXG4gICAgRXZlbnRFbWl0dGVyLFxyXG4gICAgT3V0cHV0LFxyXG4gICAgVmlld0NoaWxkLFxyXG4gICAgUmVuZGVyZXIyXHJcbn0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XHJcbmltcG9ydCB7IEtkRG9tRWxlbVN2YyB9IGZyb20gJy4uL2tkLWNvbW1vbi9pbmRleCc7XHJcbmltcG9ydCB7IElUb29sdGlwQXBpIH0gZnJvbSAnLi4va2QtYW5ndWxhci10b29sdGlwL2luZGV4JztcclxuaW1wb3J0IHsgSVNsaWRlckFwaUludGVybmFsLCBJU2xpZGVyQ29uZmlnIH0gZnJvbSAnLi9rZC1hbmd1bGFyLXNsaWRlci1pbnRlcmZhY2UnO1xyXG5pbXBvcnQgeyBLZFNsaWRlclN2YyB9IGZyb20gJy4va2QtYW5ndWxhci1zbGlkZXItc3ZjJztcclxuXHJcbkBDb21wb25lbnQoe1xyXG4gICAgc2VsZWN0b3I6ICdrZC1zbGlkZXItY29udGVudCcsXHJcbiAgICB0ZW1wbGF0ZVVybDogJy4va2QtYW5ndWxhci1zbGlkZXItY29udGVudC5odG1sJyxcclxuICAgIGVuY2Fwc3VsYXRpb246IFZpZXdFbmNhcHN1bGF0aW9uLk5vbmUsXHJcbiAgICBwcm92aWRlcnM6IFtLZERvbUVsZW1TdmMsIEtkU2xpZGVyU3ZjXSxcclxuICAgIGhvc3Q6IHtcclxuICAgICAgICAnKG1vdXNlZW50ZXIpJzogJ29uTW91c2VFbnRlcigkZXZlbnQpJyxcclxuICAgICAgICAnKG1vdXNlbGVhdmUpJzogJ29uTW91c2VMZWF2ZSgkZXZlbnQpJyxcclxuICAgICAgICAnKGNsaWNrKSc6ICdvbkNsaWNrKCRldmVudCknLFxyXG4gICAgICAgICcobW91c2Vtb3ZlKSc6ICdvbk1vdXNlTW92ZSgkZXZlbnQpJyxcclxuICAgICAgICAnKG1vdXNldXApJzogJ29uTW91c2VVcCgkZXZlbnQpJyxcclxuICAgICAgICAnKHRvdWNobW92ZSknOiAnb25Ub3VjaE1vdmUoJGV2ZW50KScsXHJcbiAgICAgICAgJyh0b3VjaGVuZCknOiAnb25Ub3VjaEVuZCgkZXZlbnQpJyxcclxuICAgICAgICAnY2xhc3MnOiAna2R4LXNsaWRlci1jb250ZW50JyxcclxuICAgICAgICAncm9sZSc6ICdzbGlkZXInLFxyXG4gICAgICAgICdbYXR0ci5hcmlhLWRpc2FibGVkXSc6ICdjb25maWcuZGlzYWJsZWQnLFxyXG4gICAgICAgICdbYXR0ci5hcmlhLXZhbHVlbWF4XSc6ICdjb25maWcubWF4JyxcclxuICAgICAgICAnW2F0dHIuYXJpYS12YWx1ZW1pbl0nOiAnY29uZmlnLm1pbicsXHJcbiAgICAgICAgJ1thdHRyLmFyaWEtdmFsdWVub3ddJzogJ3ZhbHVlJyxcclxuICAgICAgICAnW2F0dHIuYXJpYS1vcmllbnRhdGlvbl0nOiAnX3ZlcnRpY2FsID8gXCJ2ZXJ0aWNhbFwiIDogXCJob3Jpem9udGFsXCInLFxyXG4gICAgICAgICdbY2xhc3Mua2R4LXNsaWRlci1kaXNhYmxlZF0nOiAnY29uZmlnLmRpc2FibGVkJyxcclxuICAgICAgICAnW2NsYXNzLmtkeC1zbGlkZXItaG9yaXpvbnRhbF0nOiAnIV92ZXJ0aWNhbCcsXHJcbiAgICAgICAgJ1tjbGFzcy5rZHgtc2xpZGVyLWF4aXMtaW52ZXJ0ZWRdJzogJ19pc0ludmVydEF4aXMnLFxyXG4gICAgICAgICdbY2xhc3Mua2R4LXNsaWRlci1zbGlkaW5nXSc6ICdfaXNTbGlkaW5nJyxcclxuICAgICAgICAnW2NsYXNzLmtkeC1zbGlkZXItdmVydGljYWxdJzogJ192ZXJ0aWNhbCcsXHJcbiAgICAgICAgJ1tjbGFzcy5rZHgtc2xpZGVyLWhvdmVyZWRdJzogJ19pc0hvdmVyZWQnLFxyXG4gICAgICAgICdbY2xhc3Mua2R4LXNsaWRlci1oYXMtYXV0b3BsYXldJzogJ2NvbmZpZy5hdXRvcGxheScsXHJcbiAgICAgICAgJ1tjbGFzcy5rZHgtc2xpZGVyLWhhcy1yYW5nZV0nOiAnY29uZmlnLnJhbmdlJyxcclxuICAgICAgICAnW2NsYXNzLmtkeC1zbGlkZXItaXMtbW9iaWxlXSc6ICdpc01vYmlsZScsXHJcbiAgICAgICAgJ1tjbGFzcy5rZHgtc2xpZGVyLWhhcy12YWx1ZV0nOiAnIW5vVmFsdWUnLFxyXG4gICAgfSxcclxufSlcclxuXHJcbmV4cG9ydCBjbGFzcyBLZFNsaWRlckNvbnRlbnQgaW1wbGVtZW50cyBPbkluaXQsIE9uQ2hhbmdlcywgQWZ0ZXJWaWV3SW5pdCwgT25EZXN0cm95IHtcclxuXHJcbiAgICBwdWJsaWMgdHJhY2tGaWxsU3R5bGVzOiB7IFtrZXk6IHN0cmluZ106IHN0cmluZyB9O1xyXG4gICAgcHVibGljIHRodW1iQ29udGFpbmVyU3R5bGVzOiB7IFtrZXk6IHN0cmluZ106IHN0cmluZyB9O1xyXG4gICAgcHVibGljIHRodW1iQ29udGFpbmVyU3R5bGVzMTogeyBba2V5OiBzdHJpbmddOiBzdHJpbmcgfTtcclxuICAgIHB1YmxpYyBzZWxlY3RlZFRodW1iSW5kZXg6IG51bWJlciA9IDA7XHJcbiAgICBwdWJsaWMgaXNNb2JpbGU6IGJvb2xlYW4gPSBmYWxzZTtcclxuICAgIHB1YmxpYyBjb25maWc6IElTbGlkZXJDb25maWcgPSB7fTtcclxuICAgIHB1YmxpYyB2YWx1ZTogYW55O1xyXG4gICAgcHVibGljIG5vVmFsdWU6IGJvb2xlYW4gPSBmYWxzZTtcclxuXHJcbiAgICBwdWJsaWMgdG9vbHRpcEFwaTogQXJyYXk8SVRvb2x0aXBBcGk+ID0gW3t9LCB7fV07XHJcbiAgICBwdWJsaWMgdG9vbHRpcExhYmVsOiBhbnkgPSBbMF07XHJcbiAgICBwdWJsaWMgdG9vbHRpcFBsYWNlbWVudDogc3RyaW5nID0gJ3RvcCc7XHJcbiAgICBwcml2YXRlIF90b29sdGlwQXBwZWFyZWQ6IEFycmF5PGJvb2xlYW4+ID0gW2ZhbHNlXTtcclxuICAgIHByaXZhdGUgX3Rvb2x0aXBUcmFuc2l0aW9uTGlzdGVuZXI6IGFueTtcclxuICAgIHByaXZhdGUgX3Rvb2x0aXBUcmFuc2l0aW9uTGlzdGVuZXIxOiBhbnk7XHJcblxyXG4gICAgcHJpdmF0ZSBfd2luZG93VGFwTGlzdGVuZXI6IGFueTtcclxuICAgIHByaXZhdGUgX3dpbmRvd1Njcm9sbExpc3RlbmVyOiBhbnk7XHJcblxyXG4gICAgcHVibGljIF92ZXJ0aWNhbDogYm9vbGVhbjtcclxuICAgIHB1YmxpYyBfaXNJbnZlcnRBeGlzOiBib29sZWFuO1xyXG4gICAgcHVibGljIF9pc0hvdmVyZWQ6IGJvb2xlYW4gPSBmYWxzZTtcclxuXHJcbiAgICAvKipcclxuICAgICogIFdoZXRoZXIgb3Igbm90IHRoZSB0aHVtYiBpcyBzbGlkaW5nLlxyXG4gICAgKiAgVXNlZCB0byBkZXRlcm1pbmUgaWYgdGhlcmUgc2hvdWxkIGJlIGEgdHJhbnNpdGlvbiBmb3IgdGhlIHRodW1iIGFuZCBmaWxsIHRyYWNrLlxyXG4gICAgKi9cclxuICAgIHB1YmxpYyBfaXNTbGlkaW5nOiBib29sZWFuO1xyXG4gICAgLyoqIFRoZSBwZXJjZW50YWdlIG9mIHRoZSBzbGlkZXIgdGhhdCBjb2luY2lkZXMgd2l0aCB0aGUgdmFsdWUuICovXHJcbiAgICBwcml2YXRlIF9wZXJjZW50OiBudW1iZXIgPSAwO1xyXG4gICAgcHJpdmF0ZSBfcGVyY2VudHM6IEFycmF5PG51bWJlcj4gPSBbMCwgMC4xXTtcclxuICAgIHByaXZhdGUgX2RpcmVjdGlvbjogc3RyaW5nID0gJ2x0cic7XHJcbiAgICBwcml2YXRlIF9heGlzOiBzdHJpbmc7XHJcbiAgICAvKiogVGhlIGRpbWVuc2lvbnMgb2YgdGhlIHNsaWRlci4gKi9cclxuICAgIHByaXZhdGUgX3NsaWRlckRpbWVuc2lvbnM6IENsaWVudFJlY3QgfCBudWxsID0gbnVsbDtcclxuICAgIC8qKiBUaGUgdmFsdWUgb2YgdGhlIHNsaWRlciB3aGVuIHRoZSBzbGlkZSBzdGFydCBldmVudCBmaXJlcy4gKi9cclxuICAgIHByaXZhdGUgX3ZhbHVlT25TbGlkZVN0YXJ0OiBudW1iZXIgfCBudWxsIHwgQXJyYXk8bnVtYmVyPjtcclxuICAgIHByaXZhdGUgX2lzRmlyc3RMb2FkOiBib29sZWFuID0gdHJ1ZTtcclxuXHJcbiAgICAvKipcclxuICAgICogIFdoZXRoZXIgb3Igbm90IHRoZSBzbGlkZXIgaXMgY2xpY2tlZC5cclxuICAgICogIFVzZWQgdG8gZGV0ZXJtaW5lIGlmIHRoZXJlIHNob3VsZCBiZSBhIHNob3cgb2YgdG9vbHRpcCB2aWEgdHJhbnNpdGlvbmVuZCBsaXN0ZW5lci5cclxuICAgICovXHJcbiAgICBwcml2YXRlIF9pc0NsaWNrOiBib29sZWFuID0gZmFsc2U7XHJcblxyXG4gICAgQElucHV0KCd2YWx1ZScpIGNoaWxkVmFsdWU6IGFueSA9IDA7XHJcbiAgICBASW5wdXQoJ2NvbmZpZycpIGNoaWxkQ29uZmlnOiBJU2xpZGVyQ29uZmlnO1xyXG4gICAgQElucHV0KCkgaXNQbGF5OiBib29sZWFuID0gZmFsc2U7XHJcbiAgICBASW5wdXQoKSBhcGk6IElTbGlkZXJBcGlJbnRlcm5hbDtcclxuICAgIEBPdXRwdXQoKSByZXN1bHQ6IEV2ZW50RW1pdHRlcjx7fT4gPSBuZXcgRXZlbnRFbWl0dGVyKCk7XHJcbiAgICBAT3V0cHV0KCkgZW5kUGxheTogRXZlbnRFbWl0dGVyPHt9PiA9IG5ldyBFdmVudEVtaXR0ZXIoKTtcclxuXHJcbiAgICAvKiogUmVmZXJlbmNlIHRvIHRoZSBpbm5lciBzbGlkZXIgd3JhcHBlciBlbGVtZW50LiAqL1xyXG4gICAgQFZpZXdDaGlsZCgnc2xpZGVyV3JhcHBlcicsIHsgc3RhdGljOiB0cnVlIH0pIHByaXZhdGUgX3NsaWRlcldyYXBwZXI6IEVsZW1lbnRSZWY7XHJcblxyXG4gICAgY29uc3RydWN0b3IoXHJcbiAgICAgICAgcHJpdmF0ZSBfZWxlbWVudFJlZjogRWxlbWVudFJlZixcclxuICAgICAgICBfa2REb21FbGVtU3ZjOiBLZERvbUVsZW1TdmMsXHJcbiAgICAgICAgcHJpdmF0ZSBfcmVuZGVyZXI6IFJlbmRlcmVyMixcclxuICAgICAgICBwcml2YXRlIF9zbGlkZXJTdmM6IEtkU2xpZGVyU3ZjXHJcbiAgICApIHtcclxuICAgICAgICB0aGlzLl9kaXJlY3Rpb24gPSBfa2REb21FbGVtU3ZjLmdldERvY3VtZW50RGlyZWN0aW9uKHRydWUpID09PSAnbGVmdCcgPyAnbHRyJyA6ICdydGwnO1xyXG4gICAgICAgIHRoaXMuX3NsaWRlclN2Yy5kaXJlY3Rpb24gPSB0aGlzLl9kaXJlY3Rpb247XHJcbiAgICAgICAgdGhpcy5pc01vYmlsZSA9IF9rZERvbUVsZW1TdmMuaXNNb2JpbGVEZXZpY2UoKTtcclxuICAgIH1cclxuXHJcbiAgICBuZ09uSW5pdCgpOiB2b2lkIHtcclxuICAgICAgICBpZiAodHlwZW9mIHRoaXMuY2hpbGRWYWx1ZSA9PT0gJ3VuZGVmaW5lZCcpIHtcclxuICAgICAgICAgICAgdGhpcy5ub1ZhbHVlID0gdHJ1ZTtcclxuICAgICAgICAgICAgcmV0dXJuO1xyXG4gICAgICAgIH1cclxuICAgICAgICB0aGlzLl9zZXRDb25maWcodGhpcy5jaGlsZENvbmZpZyk7XHJcbiAgICAgICAgdGhpcy52YWx1ZSA9IHRoaXMuX3NldERhdGEodGhpcy5jaGlsZFZhbHVlKTtcclxuICAgICAgICB0aGlzLl9zZXRGaXJzdExvYWRQb3NpdGlvbkFuZFRvb2x0aXAodGhpcy5jaGlsZFZhbHVlKTtcclxuICAgICAgICB0aGlzLl9pbml0QXBpKCk7XHJcbiAgICAgICAgdGhpcy5faXNGaXJzdExvYWQgPSBmYWxzZTtcclxuICAgIH1cclxuXHJcbiAgICBuZ09uQ2hhbmdlcyhfc2ltcGxlQ2hhbmdlczogU2ltcGxlQ2hhbmdlcyk6IHZvaWQge1xyXG4gICAgICAgIGlmIChfc2ltcGxlQ2hhbmdlcy5oYXNPd25Qcm9wZXJ0eSgnaXNQbGF5JykgJiYgIXRoaXMuX2lzRmlyc3RMb2FkKSB7XHJcbiAgICAgICAgICAgIGlmICh0aGlzLmlzUGxheSkge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5fY2xpY2tQbGF5QnRuKCk7XHJcbiAgICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLl9jbGlja1BhdXNlQnRuKCk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIGlmIChfc2ltcGxlQ2hhbmdlcy5oYXNPd25Qcm9wZXJ0eSgnY2hpbGRWYWx1ZScpICYmICF0aGlzLl9pc0ZpcnN0TG9hZCkge1xyXG4gICAgICAgICAgICBpZiAoX3NpbXBsZUNoYW5nZXNbJ2NoaWxkVmFsdWUnXS5jdXJyZW50VmFsdWUgPT09IHRoaXMudmFsdWUpIHJldHVybjtcclxuICAgICAgICAgICAgdGhpcy52YWx1ZSA9IHRoaXMuX3NldERhdGEoX3NpbXBsZUNoYW5nZXNbJ2NoaWxkVmFsdWUnXS5jdXJyZW50VmFsdWUpO1xyXG4gICAgICAgICAgICBpZiAodGhpcy5ub1ZhbHVlKSB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLl9zZXRGaXJzdExvYWRQb3NpdGlvbkFuZFRvb2x0aXAoX3NpbXBsZUNoYW5nZXNbJ2NoaWxkVmFsdWUnXS5jdXJyZW50VmFsdWUpO1xyXG4gICAgICAgICAgICAgICAgdGhpcy5ub1ZhbHVlID0gZmFsc2U7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIGlmIChfc2ltcGxlQ2hhbmdlcy5oYXNPd25Qcm9wZXJ0eSgnY2hpbGRDb25maWcnKSAmJiAhdGhpcy5faXNGaXJzdExvYWQpIHtcclxuICAgICAgICAgICAgaWYgKF9zaW1wbGVDaGFuZ2VzWydjaGlsZENvbmZpZyddLmN1cnJlbnRWYWx1ZSA9PT0gdGhpcy5jb25maWcpIHJldHVybjtcclxuICAgICAgICAgICAgdGhpcy5fc2V0Q29uZmlnKF9zaW1wbGVDaGFuZ2VzWydjaGlsZENvbmZpZyddLmN1cnJlbnRWYWx1ZSk7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIG5nQWZ0ZXJWaWV3SW5pdCgpOiB2b2lkIHtcclxuICAgICAgICBpZiAodGhpcy5ub1ZhbHVlKSByZXR1cm47XHJcblxyXG4gICAgICAgIGxldCBpdGVyYXRpb25zOiBudW1iZXIgPSB0aGlzLmNvbmZpZy5yYW5nZSA/IDIgOiAxO1xyXG4gICAgICAgIGZvciAobGV0IGkgPSAwOyBpIDwgaXRlcmF0aW9uczsgKytpKSB7XHJcbiAgICAgICAgICAgIHRoaXMudG9vbHRpcEFwaVtpXS5kZWFjdGl2YXRlSG9zdExpc3RlbmVyKCk7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIHRoaXMuX2F0dGFjaFRodW1iVHJhbnNpdGlvbkxpc3RlbmVyKCk7XHJcbiAgICAgICAgaWYgKHRoaXMuaXNNb2JpbGUpIHtcclxuICAgICAgICAgICAgdGhpcy5fYXR0YWNoTW9iaWxlV2luZG93TGlzdGVuZXIoKTtcclxuICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICB0aGlzLl9hdHRhY2hXaW5kb3dMaXN0ZW5lcigpO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICBuZ09uRGVzdHJveSgpOiB2b2lkIHtcclxuICAgICAgICBpZiAodGhpcy5ub1ZhbHVlKSByZXR1cm47XHJcblxyXG4gICAgICAgIHRoaXMuX3Rvb2x0aXBUcmFuc2l0aW9uTGlzdGVuZXIoKTtcclxuICAgICAgICBpZiAodGhpcy5jb25maWcucmFuZ2UpIHRoaXMuX3Rvb2x0aXBUcmFuc2l0aW9uTGlzdGVuZXIxKCk7XHJcblxyXG4gICAgICAgIGlmICh0aGlzLmlzTW9iaWxlKSB7XHJcbiAgICAgICAgICAgIHRoaXMuX3dpbmRvd1RhcExpc3RlbmVyKCk7XHJcbiAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgdGhpcy5fd2luZG93U2Nyb2xsTGlzdGVuZXIoKTtcclxuICAgICAgICB9XHJcbiAgICAgICAgdGhpcy5fdG9vbHRpcEFwcGVhckNvbnRyb2woJ2FsbCBoaWRlJyk7XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfc2V0Q29uZmlnKF9jb25maWc6IElTbGlkZXJDb25maWcpOiB2b2lkIHtcclxuICAgICAgICB0aGlzLmNvbmZpZyA9IE9iamVjdC5hc3NpZ24oe30sIF9jb25maWcpO1xyXG4gICAgICAgIHRoaXMuX3NsaWRlclN2Yy5jb25maWcgPSBfY29uZmlnO1xyXG4gICAgICAgIHRoaXMuX2F4aXMgPSBfY29uZmlnLm9yaWVudGF0aW9uID09PSAndmVydGljYWwnID8gJ1knIDogJ1gnO1xyXG4gICAgICAgIHRoaXMuX3ZlcnRpY2FsID0gX2NvbmZpZy5vcmllbnRhdGlvbiA9PT0gJ3ZlcnRpY2FsJyA/IHRydWUgOiBmYWxzZTtcclxuICAgICAgICB0aGlzLl9pc0ludmVydEF4aXMgPSB0aGlzLl9zbGlkZXJTdmMuaW52ZXJ0QXhpcygpO1xyXG4gICAgICAgIHRoaXMuX3NsaWRlclN2Yy5jYWxjdWxhdGVSb3VuZExhYmVsVG8oKTtcclxuICAgICAgICB0aGlzLnRvb2x0aXBQbGFjZW1lbnQgPSB0aGlzLl9zbGlkZXJTdmMuc2V0VG9vbHRpcFBsYWNlbWVudChfY29uZmlnLnRvb2x0aXBQbGFjZW1lbnQpO1xyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX3NldERhdGEoX3ZhbHVlOiBhbnkpOiBhbnkge1xyXG4gICAgICAgIGlmIChBcnJheS5pc0FycmF5KF92YWx1ZSkpIHJldHVybiBfdmFsdWUubWFwKChlbCkgPT4geyByZXR1cm4gZWw7IH0pO1xyXG4gICAgICAgIHJldHVybiBfdmFsdWU7XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfc2V0Rmlyc3RMb2FkUG9zaXRpb25BbmRUb29sdGlwKF92YWx1ZSk6IHZvaWQge1xyXG4gICAgICAgIGlmIChBcnJheS5pc0FycmF5KF92YWx1ZSkpIHtcclxuICAgICAgICAgICAgdGhpcy5fcGVyY2VudHMgPSBfdmFsdWUubWFwKChlbCkgPT4geyByZXR1cm4gdGhpcy5fc2xpZGVyU3ZjLmNhbGN1bGF0ZVBlcmNlbnRhZ2UoZWwpOyB9KTtcclxuICAgICAgICAgICAgdGhpcy50aHVtYkNvbnRhaW5lclN0eWxlcyA9IHRoaXMuX3RodW1iQ29udGFpbmVyU3R5bGVzKHRoaXMuX3BlcmNlbnRzWzBdKTtcclxuICAgICAgICAgICAgdGhpcy50aHVtYkNvbnRhaW5lclN0eWxlczEgPSB0aGlzLl90aHVtYkNvbnRhaW5lclN0eWxlcyh0aGlzLl9wZXJjZW50c1sxXSk7XHJcbiAgICAgICAgICAgIHRoaXMuX3Rvb2x0aXBBcHBlYXJlZCA9IFtmYWxzZSwgZmFsc2VdO1xyXG4gICAgICAgICAgICB0aGlzLnRvb2x0aXBMYWJlbCA9IHRoaXMuX3NldFRvb2x0aXBMYWJlbChfdmFsdWUpO1xyXG4gICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgIHRoaXMuX3BlcmNlbnQgPSB0aGlzLl9zbGlkZXJTdmMuY2FsY3VsYXRlUGVyY2VudGFnZShfdmFsdWUpO1xyXG4gICAgICAgICAgICB0aGlzLnRodW1iQ29udGFpbmVyU3R5bGVzID0gdGhpcy5fdGh1bWJDb250YWluZXJTdHlsZXModGhpcy5fcGVyY2VudCk7XHJcbiAgICAgICAgICAgIHRoaXMudG9vbHRpcExhYmVsWzBdID0gdGhpcy5fc2V0VG9vbHRpcExhYmVsKF92YWx1ZSk7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIHRoaXMudHJhY2tGaWxsU3R5bGVzID0gdGhpcy5fdHJhY2tGaWxsU3R5bGVzKCk7XHJcbiAgICB9XHJcblxyXG5cclxuICAgIC8qKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKiovXHJcbiAgICAvKiBFdmVudCBMaXN0ZW5lclxyXG4gICAgLyoqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKi9cclxuXHJcbiAgICBvbk1vdXNlRW50ZXIoZXZlbnQ/OiBhbnkpOiB2b2lkIHtcclxuICAgICAgICBpZiAodGhpcy5ub1ZhbHVlKSByZXR1cm47XHJcbiAgICAgICAgdGhpcy5faXNIb3ZlcmVkID0gdHJ1ZTtcclxuICAgICAgICB0aGlzLl90b29sdGlwQXBwZWFyQ29udHJvbCgnYWxsIHNob3cnKTtcclxuICAgICAgICBpZiAodGhpcy5jb25maWcuZGlzYWJsZWQpIHtcclxuICAgICAgICAgICAgcmV0dXJuO1xyXG4gICAgICAgIH1cclxuICAgICAgICAvLyBXZSBzYXZlIHRoZSBkaW1lbnNpb25zIG9mIHRoZSBzbGlkZXIgaGVyZSBzbyB3ZSBjYW4gdXNlIHRoZW0gdG8gdXBkYXRlIHRoZSBzcGFjaW5nIG9mIHRoZVxyXG4gICAgICAgIC8vIHRpY2tzIGFuZCBkZXRlcm1pbmUgd2hlcmUgb24gdGhlIHNsaWRlciBjbGljayBhbmQgc2xpZGUgZXZlbnRzIGhhcHBlbi5cclxuICAgICAgICB0aGlzLl9zbGlkZXJEaW1lbnNpb25zID0gdGhpcy5fZ2V0U2xpZGVyRGltZW5zaW9ucygpO1xyXG4gICAgfVxyXG4gICAgb25Nb3VzZUxlYXZlKGV2ZW50PzogYW55KTogdm9pZCB7XHJcbiAgICAgICAgaWYgKHRoaXMubm9WYWx1ZSkgcmV0dXJuO1xyXG4gICAgICAgIGlmICghdGhpcy5pc01vYmlsZSkgdGhpcy5vbkVuZCgnbW91c2VsZWF2ZScpO1xyXG4gICAgICAgIHRoaXMuX3Rvb2x0aXBBcHBlYXJDb250cm9sKCdhbGwgaGlkZScpO1xyXG4gICAgICAgIHRoaXMuX2lzSG92ZXJlZCA9IGZhbHNlO1xyXG4gICAgfVxyXG5cclxuICAgIG9uQ2xpY2soZXZlbnQ6IGFueSk6IHZvaWQge1xyXG4gICAgICAgIGlmICh0aGlzLm5vVmFsdWUpIHJldHVybjtcclxuICAgICAgICB0aGlzLl9vbkNob29zZVBvcyh7IHg6IGV2ZW50LmNsaWVudFgsIHk6IGV2ZW50LmNsaWVudFkgfSk7XHJcbiAgICAgICAgZXZlbnQuc3RvcFByb3BhZ2F0aW9uKCk7XHJcbiAgICB9XHJcblxyXG4gICAgb25Nb3VzZURvd24oZXZlbnQ6IGFueSwgaWQ6IG51bWJlcik6IHZvaWQge1xyXG4gICAgICAgIGlmICh0aGlzLm5vVmFsdWUpIHJldHVybjtcclxuICAgICAgICBpZiAoIXRoaXMuaXNNb2JpbGUpIHtcclxuICAgICAgICAgICAgdGhpcy5vblN0YXJ0KHsgeDogZXZlbnQuY2xpZW50WCwgeTogZXZlbnQuY2xpZW50WSB9LCBpZCk7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGV2ZW50LnByZXZlbnREZWZhdWx0KCk7XHJcbiAgICB9XHJcbiAgICBvbk1vdXNlTW92ZShldmVudDogYW55KTogdm9pZCB7XHJcbiAgICAgICAgaWYgKHRoaXMubm9WYWx1ZSkgcmV0dXJuO1xyXG4gICAgICAgIGlmICghdGhpcy5pc01vYmlsZSkge1xyXG4gICAgICAgICAgICB0aGlzLm9uTW92ZSh7IHg6IGV2ZW50LmNsaWVudFgsIHk6IGV2ZW50LmNsaWVudFkgfSk7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGV2ZW50LnByZXZlbnREZWZhdWx0KCk7XHJcbiAgICB9XHJcbiAgICBvbk1vdXNlVXAoZXZlbnQ6IGFueSk6IHZvaWQge1xyXG4gICAgICAgIGlmICh0aGlzLm5vVmFsdWUpIHJldHVybjtcclxuICAgICAgICBpZiAoIXRoaXMuaXNNb2JpbGUpIHRoaXMub25FbmQoJ21vdXNldXAnKTtcclxuICAgICAgICBldmVudC5wcmV2ZW50RGVmYXVsdCgpO1xyXG4gICAgfVxyXG5cclxuICAgIG9uVG91Y2hTdGFydChldmVudDogYW55LCBpZCk6IHZvaWQge1xyXG4gICAgICAgIGlmICh0aGlzLm5vVmFsdWUpIHJldHVybjtcclxuICAgICAgICB0aGlzLm9uU3RhcnQoeyB4OiBldmVudC50b3VjaGVzWycwJ10uY2xpZW50WCwgeTogZXZlbnQudG91Y2hlc1snMCddLmNsaWVudFkgfSwgaWQpO1xyXG4gICAgICAgIGV2ZW50LnByZXZlbnREZWZhdWx0KCk7XHJcbiAgICAgICAgZXZlbnQuc3RvcFByb3BhZ2F0aW9uKCk7XHJcblxyXG4gICAgfVxyXG4gICAgb25Ub3VjaE1vdmUoZXZlbnQ6IGFueSk6IHZvaWQge1xyXG4gICAgICAgIGlmICh0aGlzLm5vVmFsdWUpIHJldHVybjtcclxuICAgICAgICB0aGlzLm9uTW92ZSh7IHg6IGV2ZW50LnRvdWNoZXNbJzAnXS5jbGllbnRYLCB5OiBldmVudC50b3VjaGVzWycwJ10uY2xpZW50WSB9KTtcclxuICAgICAgICBldmVudC5wcmV2ZW50RGVmYXVsdCgpO1xyXG4gICAgICAgIGV2ZW50LnN0b3BQcm9wYWdhdGlvbigpO1xyXG4gICAgfVxyXG4gICAgb25Ub3VjaEVuZChldmVudDogYW55KTogdm9pZCB7XHJcbiAgICAgICAgaWYgKHRoaXMubm9WYWx1ZSkgcmV0dXJuO1xyXG4gICAgICAgIHRoaXMub25FbmQoJ3RvdWNoZW5kJyk7XHJcbiAgICAgICAgZXZlbnQuc3RvcFByb3BhZ2F0aW9uKCk7XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfYXR0YWNoTW9iaWxlV2luZG93TGlzdGVuZXIoKSB7XHJcbiAgICAgICAgdGhpcy5fd2luZG93VGFwTGlzdGVuZXIgPSB0aGlzLl9yZW5kZXJlci5saXN0ZW4oJ2RvY3VtZW50JywgJ3RvdWNoc3RhcnQnLCAoZXZlbnQpID0+IHtcclxuICAgICAgICAgICAgdGhpcy5fdG9vbHRpcEFwcGVhckNvbnRyb2woJ2FsbCBoaWRlJyk7XHJcbiAgICAgICAgICAgIHRoaXMuX2lzSG92ZXJlZCA9IGZhbHNlO1xyXG4gICAgICAgIH0pO1xyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX2F0dGFjaFdpbmRvd0xpc3RlbmVyKCkge1xyXG4gICAgICAgIHRoaXMuX3dpbmRvd1Njcm9sbExpc3RlbmVyID0gdGhpcy5fcmVuZGVyZXIubGlzdGVuKCd3aW5kb3cnLCAnbW91c2V3aGVlbCcsIChldmVudCkgPT4ge1xyXG4gICAgICAgICAgICBvYnNlcnZhYmxlVGltZXIoNTApLnN1YnNjcmliZSgoKSA9PiB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLl90b29sdGlwQXBwZWFyQ29udHJvbCgnYWxsIGhpZGUnKTtcclxuICAgICAgICAgICAgICAgIHRoaXMuX2lzSG92ZXJlZCA9IGZhbHNlO1xyXG4gICAgICAgICAgICB9KTtcclxuICAgICAgICB9KTtcclxuICAgICAgICB0aGlzLl93aW5kb3dTY3JvbGxMaXN0ZW5lciA9IHRoaXMuX3JlbmRlcmVyLmxpc3Rlbignd2luZG93JywgJ0RPTU1vdXNlU2Nyb2xsJywgKGV2ZW50KSA9PiB7XHJcbiAgICAgICAgICAgIG9ic2VydmFibGVUaW1lcig1MCkuc3Vic2NyaWJlKCgpID0+IHtcclxuICAgICAgICAgICAgICAgIHRoaXMuX3Rvb2x0aXBBcHBlYXJDb250cm9sKCdhbGwgaGlkZScpO1xyXG4gICAgICAgICAgICAgICAgdGhpcy5faXNIb3ZlcmVkID0gZmFsc2U7XHJcbiAgICAgICAgICAgIH0pO1xyXG4gICAgICAgIH0pO1xyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX2F0dGFjaFRodW1iVHJhbnNpdGlvbkxpc3RlbmVyKCkge1xyXG4gICAgICAgIGxldCB0aHVtYkNvbnRhaW5lckVsZW1lbnRzID0gdGhpcy5fZWxlbWVudFJlZi5uYXRpdmVFbGVtZW50LnF1ZXJ5U2VsZWN0b3JBbGwoJy5rZHgtc2xpZGVyIC5rZHgtc2xpZGVyLWNvbnRlbnQgLmtkeC1zbGlkZXItY29udGVudC13cmFwcGVyIC5rZHgtc2xpZGVyLXRodW1iLWNvbnRhaW5lcicpO1xyXG4gICAgICAgIHRoaXMuX3Rvb2x0aXBUcmFuc2l0aW9uTGlzdGVuZXIgPSB0aGlzLl9yZW5kZXJlci5saXN0ZW4odGh1bWJDb250YWluZXJFbGVtZW50c1swXSwgJ3RyYW5zaXRpb25lbmQnLCAoKSA9PiB7XHJcbiAgICAgICAgICAgIGlmICh0aGlzLmlzUGxheSAmJiB0aGlzLmNvbmZpZy5hdXRvcGxheSkgdGhpcy5fdXBkYXRlQXV0b3BsYXlWYWx1ZSgpO1xyXG5cclxuICAgICAgICAgICAgaWYgKCF0aGlzLmlzUGxheSAmJiB0aGlzLl9pc0NsaWNrICYmICF0aGlzLl9pc1NsaWRpbmcpIHRoaXMuX3Rvb2x0aXBPblRodW1iVHJhbnNpdGlvbigpO1xyXG4gICAgICAgIH0pO1xyXG4gICAgICAgIGlmICh0aGlzLmNvbmZpZy5yYW5nZSkge1xyXG4gICAgICAgICAgICB0aGlzLl90b29sdGlwVHJhbnNpdGlvbkxpc3RlbmVyMSA9IHRoaXMuX3JlbmRlcmVyLmxpc3Rlbih0aHVtYkNvbnRhaW5lckVsZW1lbnRzWzFdLCAndHJhbnNpdGlvbmVuZCcsICgpID0+IHtcclxuICAgICAgICAgICAgICAgIGlmICghdGhpcy5jb25maWcuYXV0b3BsYXkgJiYgdGhpcy5faXNDbGljayAmJiAhdGhpcy5faXNTbGlkaW5nKSB0aGlzLl90b29sdGlwT25UaHVtYlRyYW5zaXRpb24oKTtcclxuICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX3Rvb2x0aXBPblRodW1iVHJhbnNpdGlvbigpIHtcclxuICAgICAgICB0aGlzLl90b29sdGlwQXBwZWFyQ29udHJvbCgnc2hvdyBzZWxlY3RlZCcpO1xyXG4gICAgICAgIHRoaXMuX2lzQ2xpY2sgPSBmYWxzZTtcclxuICAgICAgICBpZiAoIXRoaXMuX2lzSG92ZXJlZCkgc2V0VGltZW91dCgoKSA9PiB0aGlzLl90b29sdGlwQXBwZWFyQ29udHJvbCgnaGlkZSBzZWxlY3RlZCcpLCAxMDAwKTtcclxuICAgIH1cclxuXHJcbiAgICAvKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqL1xyXG4gICAgLyogTGlzdGVuZXIgTG9naWNcclxuICAgIC8qKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKiovXHJcblxyXG4gICAgcHJpdmF0ZSBvblN0YXJ0KHBvczogeyB4OiBudW1iZXIsIHk6IG51bWJlciB9LCBpZCk6IHZvaWQge1xyXG4gICAgICAgIGlmICh0aGlzLmNvbmZpZy5kaXNhYmxlZCB8fCB0aGlzLl9pc1NsaWRpbmcpIHtcclxuICAgICAgICAgICAgcmV0dXJuO1xyXG4gICAgICAgIH1cclxuICAgICAgICAvLyBTaW11bGF0ZSBtb3VzZWVudGVyIGluIGNhc2UgdGhpcyBpcyBhIG1vYmlsZSBkZXZpY2UuXHJcbiAgICAgICAgdGhpcy5vbk1vdXNlRW50ZXIoKTtcclxuXHJcbiAgICAgICAgdGhpcy5faXNTbGlkaW5nID0gdHJ1ZTtcclxuICAgICAgICBpZiAodGhpcy5jb25maWcucmFuZ2UpIHtcclxuICAgICAgICAgICAgdGhpcy5zZWxlY3RlZFRodW1iSW5kZXggPSBpZDtcclxuICAgICAgICAgICAgdGhpcy5fdmFsdWVPblNsaWRlU3RhcnQgPSB0aGlzLnZhbHVlW3RoaXMuc2VsZWN0ZWRUaHVtYkluZGV4XTtcclxuICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICB0aGlzLl92YWx1ZU9uU2xpZGVTdGFydCA9IHRoaXMudmFsdWU7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIHRoaXMuX2hhbmRsZVZhbHVlKHBvcyk7XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBvbk1vdmUocG9zOiB7IHg6IG51bWJlciwgeTogbnVtYmVyIH0pOiB2b2lkIHtcclxuICAgICAgICBpZiAodGhpcy5jb25maWcuZGlzYWJsZWQgfHwgIXRoaXMuX2lzU2xpZGluZykge1xyXG4gICAgICAgICAgICByZXR1cm47XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICBsZXQgb2xkVmFsdWU6IG51bWJlciA9IDA7XHJcblxyXG4gICAgICAgIGlmICh0aGlzLmNvbmZpZy5yYW5nZSkge1xyXG4gICAgICAgICAgICBvbGRWYWx1ZSA9IHRoaXMudmFsdWVbdGhpcy5zZWxlY3RlZFRodW1iSW5kZXhdO1xyXG4gICAgICAgICAgICB0aGlzLl9oYW5kbGVWYWx1ZShwb3MpO1xyXG5cclxuICAgICAgICAgICAgaWYgKG9sZFZhbHVlICE9PSB0aGlzLnZhbHVlW3RoaXMuc2VsZWN0ZWRUaHVtYkluZGV4XSkge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5fZW1pdENoYW5nZUV2ZW50KCdzbGlkaW5nJyk7XHJcbiAgICAgICAgICAgICAgICByZXR1cm47XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIG9sZFZhbHVlID0gdGhpcy52YWx1ZTtcclxuICAgICAgICB0aGlzLl9oYW5kbGVWYWx1ZShwb3MpO1xyXG4gICAgICAgIC8vIE5hdGl2ZSByYW5nZSBlbGVtZW50cyBhbHdheXMgZW1pdCBgaW5wdXRgIGV2ZW50cyB3aGVuIHRoZSB2YWx1ZSBjaGFuZ2VkIHdoaWxlIHNsaWRpbmcuXHJcbiAgICAgICAgaWYgKG9sZFZhbHVlICE9PSB0aGlzLnZhbHVlKSB7XHJcbiAgICAgICAgICAgIHRoaXMuX2VtaXRDaGFuZ2VFdmVudCgnc2xpZGluZycpO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIG9uRW5kKF9mcm9tV2hlcmU6IHN0cmluZyk6IHZvaWQge1xyXG4gICAgICAgIGlmICghdGhpcy5faXNTbGlkaW5nKSB7XHJcbiAgICAgICAgICAgIHJldHVybjtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIGlmIChfZnJvbVdoZXJlID09PSAnbW91c2VsZWF2ZScpIHtcclxuICAgICAgICAgICAgdGhpcy5faXNTbGlkaW5nID0gZmFsc2U7XHJcbiAgICAgICAgfSBlbHNlIGlmICh0aGlzLmlzTW9iaWxlKSB0aGlzLl9pc1NsaWRpbmcgPSBmYWxzZTtcclxuXHJcbiAgICAgICAgaWYgKHRoaXMuY29uZmlnLnJhbmdlKSB7XHJcbiAgICAgICAgICAgIGlmICh0aGlzLl92YWx1ZU9uU2xpZGVTdGFydCAhPT0gdGhpcy52YWx1ZVt0aGlzLnNlbGVjdGVkVGh1bWJJbmRleF0pIHRoaXMuX2VtaXRDaGFuZ2VFdmVudCgpO1xyXG4gICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgIGlmICh0aGlzLl92YWx1ZU9uU2xpZGVTdGFydCAhPT0gdGhpcy52YWx1ZSkgdGhpcy5fZW1pdENoYW5nZUV2ZW50KCk7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICB0aGlzLl92YWx1ZU9uU2xpZGVTdGFydCA9IG51bGw7XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfb25DaG9vc2VQb3MocG9zOiB7IHg6IG51bWJlciwgeTogbnVtYmVyIH0pOiB2b2lkIHtcclxuICAgICAgICBpZiAodGhpcy5jb25maWcuZGlzYWJsZWQpIHtcclxuICAgICAgICAgICAgcmV0dXJuO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgLy8gU2ltdWxhdGUgbW91c2VlbnRlciBpbiBjYXNlIHRoaXMgaXMgYSBtb2JpbGUgZGV2aWNlLlxyXG4gICAgICAgIHRoaXMub25Nb3VzZUVudGVyKCk7XHJcblxyXG4gICAgICAgIHRoaXMuX2lzQ2xpY2sgPSB0cnVlO1xyXG5cclxuICAgICAgICBpZiAodGhpcy5faXNDbGljayAmJiAhdGhpcy5faXNTbGlkaW5nKSB7XHJcbiAgICAgICAgICAgIHRoaXMuX3Rvb2x0aXBBcHBlYXJDb250cm9sKCdoaWRlIHNlbGVjdGVkJyk7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIHRoaXMuX2lzU2xpZGluZyA9IGZhbHNlO1xyXG5cclxuICAgICAgICBsZXQgb2xkVmFsdWU6IG51bWJlciA9IDA7XHJcblxyXG4gICAgICAgIGlmICh0aGlzLmNvbmZpZy5yYW5nZSkge1xyXG4gICAgICAgICAgICBvbGRWYWx1ZSA9IHRoaXMudmFsdWVbdGhpcy5zZWxlY3RlZFRodW1iSW5kZXhdO1xyXG4gICAgICAgICAgICB0aGlzLl9oYW5kbGVWYWx1ZShwb3MpO1xyXG4gICAgICAgICAgICBpZiAob2xkVmFsdWUgIT09IHRoaXMudmFsdWVbdGhpcy5zZWxlY3RlZFRodW1iSW5kZXhdKSB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLl9lbWl0Q2hhbmdlRXZlbnQoKTtcclxuICAgICAgICAgICAgICAgIHJldHVybjtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgb2xkVmFsdWUgPSB0aGlzLnZhbHVlO1xyXG4gICAgICAgIHRoaXMuX2hhbmRsZVZhbHVlKHBvcyk7XHJcblxyXG4gICAgICAgIC8qIEVtaXQgYSBjaGFuZ2UgYW5kIGlucHV0IGV2ZW50IGlmIHRoZSB2YWx1ZSBjaGFuZ2VkLiAqL1xyXG4gICAgICAgIGlmIChvbGRWYWx1ZSAhPT0gdGhpcy52YWx1ZSkge1xyXG4gICAgICAgICAgICB0aGlzLl9lbWl0Q2hhbmdlRXZlbnQoKTtcclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgLyoqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKi9cclxuICAgIC8qIEF1dG9wbGF5XHJcbiAgICAvKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqL1xyXG5cclxuICAgIHByaXZhdGUgX2NsaWNrUGxheUJ0bigpOiB2b2lkIHtcclxuICAgICAgICB0aGlzLmNvbmZpZy5kaXNhYmxlZCA9IHRydWU7XHJcbiAgICAgICAgdGhpcy5fdXBkYXRlQXV0b3BsYXlWYWx1ZSgpO1xyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX2NsaWNrUGF1c2VCdG4oKTogdm9pZCB7XHJcbiAgICAgICAgdGhpcy5jb25maWcuZGlzYWJsZWQgPSBmYWxzZTtcclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF91cGRhdGVBdXRvcGxheVZhbHVlKCk6IHZvaWQge1xyXG4gICAgICAgIHRoaXMuX3Rvb2x0aXBBcHBlYXJDb250cm9sKCdzaG93IHNlbGVjdGVkJyk7XHJcbiAgICAgICAgc2V0VGltZW91dCgoKSA9PiB7XHJcbiAgICAgICAgICAgIHRoaXMuX3Rvb2x0aXBBcHBlYXJDb250cm9sKCdoaWRlIHNlbGVjdGVkJyk7XHJcbiAgICAgICAgICAgIGlmICghdGhpcy5pc1BsYXkpIHJldHVybjtcclxuXHJcbiAgICAgICAgICAgIHRoaXMudmFsdWUgPSB0aGlzLnZhbHVlICsgKHRoaXMuY29uZmlnLmF1dG9wbGF5U3RlcCB8fCAxKTtcclxuXHJcbiAgICAgICAgICAgIGlmICh0aGlzLnZhbHVlID4gdGhpcy5jb25maWcubWF4KSB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLnZhbHVlID0gdGhpcy5jb25maWcubWluO1xyXG4gICAgICAgICAgICAgICAgdGhpcy5lbmRQbGF5LmVtaXQodHJ1ZSk7XHJcbiAgICAgICAgICAgICAgICB0aGlzLnRvb2x0aXBBcGlbMF0uaGlkZVRvb2x0aXAoKTtcclxuICAgICAgICAgICAgICAgIHRoaXMuY29uZmlnLmRpc2FibGVkID0gZmFsc2U7XHJcbiAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgIHRoaXMuX3BlcmNlbnQgPSB0aGlzLl9zbGlkZXJTdmMuY2FsY3VsYXRlUGVyY2VudGFnZSh0aGlzLnZhbHVlKTtcclxuICAgICAgICAgICAgdGhpcy5faGFuZGxlUG9zaXRpb24oKTtcclxuICAgICAgICAgICAgdGhpcy5fZW1pdENoYW5nZUV2ZW50KCk7XHJcbiAgICAgICAgfSwgdGhpcy5jb25maWcuYXV0b3BsYXlEZWxheSB8fCA1MDApO1xyXG4gICAgfVxyXG5cclxuICAgIC8qKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKiovXHJcbiAgICAvKiBFdmVudCBFbWl0XHJcbiAgICAvKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqL1xyXG5cclxuICAgIC8qKiBFbWl0cyBhIGNoYW5nZSBldmVudCBpZiB0aGUgY3VycmVudCB2YWx1ZSBpcyBkaWZmZXJlbnQgZnJvbSB0aGUgbGFzdCBlbWl0dGVkIHZhbHVlLiAqL1xyXG4gICAgcHJpdmF0ZSBfZW1pdENoYW5nZUV2ZW50KF9jdXJyZW50QWN0aW9uPzogJ3NsaWRpbmcnKTogdm9pZCB7XHJcbiAgICAgICAgdGhpcy5yZXN1bHQuZW1pdCh7XHJcbiAgICAgICAgICAgIHZhbHVlOiB0aGlzLnZhbHVlLFxyXG4gICAgICAgICAgICBjdXJyZW50QWN0aW9uOiBfY3VycmVudEFjdGlvblxyXG4gICAgICAgIH0pO1xyXG4gICAgfVxyXG5cclxuICAgIC8qKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKiovXHJcbiAgICAvKiBDU1MgU3R5bGVzXHJcbiAgICAvKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqL1xyXG5cclxuICAgIHByaXZhdGUgX3RyYWNrRmlsbFN0eWxlcygpOiB7IFtrZXk6IHN0cmluZ106IHN0cmluZyB9IHtcclxuICAgICAgICBpZiAodGhpcy5jb25maWcucmFuZ2UpIHtcclxuICAgICAgICAgICAgbGV0IGludmVydE9mZnNldDogYm9vbGVhbiA9ICh0aGlzLl9kaXJlY3Rpb24gPT09ICdydGwnICYmICF0aGlzLl92ZXJ0aWNhbCkgPyAhdGhpcy5fc2xpZGVyU3ZjLmludmVydEF4aXMoKSA6IHRoaXMuX3NsaWRlclN2Yy5pbnZlcnRBeGlzKCk7XHJcbiAgICAgICAgICAgIGxldCBzaWduOiBzdHJpbmcgPSBpbnZlcnRPZmZzZXQgPyAnLScgOiAnJztcclxuICAgICAgICAgICAgbGV0IGZpcnN0VGh1bWJQb3NpdGlvbjogbnVtYmVyID0gaW52ZXJ0T2Zmc2V0ID8gdGhpcy5fY2FsY3VsYXRlT2Zmc2V0KHRoaXMuX3BlcmNlbnRzWzBdKSA6IDEwMCAtIHRoaXMuX2NhbGN1bGF0ZU9mZnNldCh0aGlzLl9wZXJjZW50c1swXSk7XHJcbiAgICAgICAgICAgIGxldCBzY2FsZVBlcmNlbnQ6IG51bWJlciA9IHRoaXMuX3BlcmNlbnRzWzFdIC0gdGhpcy5fcGVyY2VudHNbMF07XHJcbiAgICAgICAgICAgIHJldHVybiB7XHJcbiAgICAgICAgICAgICAgICAndHJhbnNmb3JtJzogYHRyYW5zbGF0ZSR7dGhpcy5fYXhpc30oJHtzaWdufSR7Zmlyc3RUaHVtYlBvc2l0aW9ufSUpIHNjYWxlJHt0aGlzLl9heGlzfSgke3NjYWxlUGVyY2VudH0pYFxyXG4gICAgICAgICAgICB9O1xyXG4gICAgICAgIH1cclxuICAgICAgICByZXR1cm4ge1xyXG4gICAgICAgICAgICAndHJhbnNmb3JtJzogYHNjYWxlJHt0aGlzLl9heGlzfSgke3RoaXMuX3BlcmNlbnR9KWBcclxuICAgICAgICB9O1xyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX3RodW1iQ29udGFpbmVyU3R5bGVzKF9wZXJjZW50OiBudW1iZXIpOiB7IFtrZXk6IHN0cmluZ106IHN0cmluZyB9IHtcclxuICAgICAgICBsZXQgb2Zmc2V0OiBudW1iZXIgPSB0aGlzLl9jYWxjdWxhdGVPZmZzZXQoX3BlcmNlbnQpO1xyXG4gICAgICAgIHJldHVybiB7XHJcbiAgICAgICAgICAgICd0cmFuc2Zvcm0nOiBgdHJhbnNsYXRlJHt0aGlzLl9heGlzfSgtJHtvZmZzZXR9JSlgXHJcbiAgICAgICAgfTtcclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF9jYWxjdWxhdGVPZmZzZXQoX3BlcmNlbnQ6IG51bWJlcik6IG51bWJlciB7XHJcbiAgICAgICAgLy8gRm9yIGEgaG9yaXpvbnRhbCBzbGlkZXIgaW4gUlRMIGxhbmd1YWdlcyB3ZSBwdXNoIHRoZSB0aHVtYiBjb250YWluZXIgb2ZmIHRoZSBsZWZ0IGVkZ2VcclxuICAgICAgICAvLyBpbnN0ZWFkIG9mIHRoZSByaWdodCBlZGdlIHRvIGF2b2lkIGNhdXNpbmcgYSBob3Jpem9udGFsIHNjcm9sbGJhciB0byBhcHBlYXIuXHJcbiAgICAgICAgbGV0IGludmVydE9mZnNldDogYm9vbGVhbiA9ICh0aGlzLl9kaXJlY3Rpb24gPT09ICdydGwnICYmICF0aGlzLl92ZXJ0aWNhbCkgPyAhdGhpcy5fc2xpZGVyU3ZjLmludmVydEF4aXMoKSA6IHRoaXMuX3NsaWRlclN2Yy5pbnZlcnRBeGlzKCk7XHJcbiAgICAgICAgcmV0dXJuIChpbnZlcnRPZmZzZXQgPyBfcGVyY2VudCA6IDEgLSBfcGVyY2VudCkgKiAxMDA7XHJcbiAgICB9XHJcblxyXG4gICAgLyoqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKi9cclxuICAgIC8qIFNldHRpbmcgVmFsdWVzXHJcbiAgICAvKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqL1xyXG5cclxuICAgIHByaXZhdGUgX2hhbmRsZVZhbHVlKF9wb3M/OiB7IHg6IG51bWJlciwgeTogbnVtYmVyIH0sIF92YWx1ZT86IG51bWJlcik6IHZvaWQge1xyXG4gICAgICAgIGxldCBuZXdWYWx1ZTogbnVtYmVyID0gdHlwZW9mIF92YWx1ZSAhPT0gJ3VuZGVmaW5lZCcgPyBfdmFsdWUgOiB0aGlzLl91cGRhdGVWYWx1ZUZyb21Qb3NpdGlvbihfcG9zKTtcclxuICAgICAgICBpZiAodGhpcy5jb25maWcucmFuZ2UpIHtcclxuICAgICAgICAgICAgdGhpcy52YWx1ZVt0aGlzLnNlbGVjdGVkVGh1bWJJbmRleF0gPSBuZXdWYWx1ZTtcclxuICAgICAgICAgICAgdGhpcy5fcGVyY2VudHNbdGhpcy5zZWxlY3RlZFRodW1iSW5kZXhdID0gdGhpcy5fc2xpZGVyU3ZjLmNhbGN1bGF0ZVBlcmNlbnRhZ2UobmV3VmFsdWUpO1xyXG4gICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgIHRoaXMudmFsdWUgPSBuZXdWYWx1ZTtcclxuICAgICAgICAgICAgdGhpcy5fcGVyY2VudCA9IHRoaXMuX3NsaWRlclN2Yy5jYWxjdWxhdGVQZXJjZW50YWdlKG5ld1ZhbHVlKTtcclxuICAgICAgICB9XHJcbiAgICAgICAgdGhpcy5faGFuZGxlUG9zaXRpb24oKTtcclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF91cGRhdGVWYWx1ZUZyb21Qb3NpdGlvbihfcG9zOiB7IHg6IG51bWJlciwgeTogbnVtYmVyIH0pOiBudW1iZXIge1xyXG4gICAgICAgIGlmICghdGhpcy5fc2xpZGVyRGltZW5zaW9ucykge1xyXG4gICAgICAgICAgICByZXR1cm47XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICBsZXQgb2Zmc2V0OiBudW1iZXIgPSB0aGlzLl92ZXJ0aWNhbCA/IHRoaXMuX3NsaWRlckRpbWVuc2lvbnMudG9wIDogdGhpcy5fc2xpZGVyRGltZW5zaW9ucy5sZWZ0O1xyXG4gICAgICAgIGxldCBzaXplOiBudW1iZXIgPSB0aGlzLl92ZXJ0aWNhbCA/IHRoaXMuX3NsaWRlckRpbWVuc2lvbnMuaGVpZ2h0IDogdGhpcy5fc2xpZGVyRGltZW5zaW9ucy53aWR0aDtcclxuICAgICAgICBsZXQgcG9zQ29tcG9uZW50OiBudW1iZXIgPSB0aGlzLl92ZXJ0aWNhbCA/IF9wb3MueSA6IF9wb3MueDtcclxuXHJcbiAgICAgICAgLy8gVGhlIGV4YWN0IHZhbHVlIGlzIGNhbGN1bGF0ZWQgZnJvbSB0aGUgZXZlbnQgYW5kIHVzZWQgdG8gZmluZCB0aGUgY2xvc2VzdCBzbmFwIHZhbHVlLlxyXG4gICAgICAgIGxldCBwZXJjZW50OiBudW1iZXIgPSB0aGlzLl9zbGlkZXJTdmMuY2xhbXAoKHBvc0NvbXBvbmVudCAtIG9mZnNldCkgLyBzaXplKTtcclxuICAgICAgICBpZiAodGhpcy5fc2xpZGVyU3ZjLmludmVydE1vdXNlQ29vcmRzKCkpIHtcclxuICAgICAgICAgICAgcGVyY2VudCA9IDEgLSBwZXJjZW50O1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgbGV0IGZpbmFsVmFsdWU6IG51bWJlciA9IHRoaXMuX3NsaWRlclN2Yy5jYWxjdWxhdGVWYWx1ZShwZXJjZW50KTtcclxuXHJcbiAgICAgICAgaWYgKHRoaXMuY29uZmlnLnJhbmdlKSB7XHJcbiAgICAgICAgICAgIGxldCBvdGhlclZhbHVlOiBudW1iZXIgPSB0aGlzLnZhbHVlW01hdGguYWJzKDEgLSB0aGlzLnNlbGVjdGVkVGh1bWJJbmRleCldO1xyXG4gICAgICAgICAgICBpZiAodGhpcy5fc2xpZGVyU3ZjLmNoZWNrVmFsdWVDb25mbGljdChmaW5hbFZhbHVlLCBvdGhlclZhbHVlLCB0aGlzLnNlbGVjdGVkVGh1bWJJbmRleCkpIHtcclxuICAgICAgICAgICAgICAgIGZpbmFsVmFsdWUgPSBvdGhlclZhbHVlO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgICAgIHJldHVybiBmaW5hbFZhbHVlO1xyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX2hhbmRsZVBvc2l0aW9uKCk6IHZvaWQge1xyXG4gICAgICAgIGlmICh0aGlzLmNvbmZpZy5yYW5nZSkge1xyXG4gICAgICAgICAgICBpZiAodGhpcy5zZWxlY3RlZFRodW1iSW5kZXggPT09IDApIHtcclxuICAgICAgICAgICAgICAgIHRoaXMudGh1bWJDb250YWluZXJTdHlsZXMgPSB0aGlzLl90aHVtYkNvbnRhaW5lclN0eWxlcyh0aGlzLl9wZXJjZW50c1swXSk7XHJcbiAgICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLnRodW1iQ29udGFpbmVyU3R5bGVzMSA9IHRoaXMuX3RodW1iQ29udGFpbmVyU3R5bGVzKHRoaXMuX3BlcmNlbnRzWzFdKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgIHRoaXMudGh1bWJDb250YWluZXJTdHlsZXMgPSB0aGlzLl90aHVtYkNvbnRhaW5lclN0eWxlcyh0aGlzLl9wZXJjZW50KTtcclxuICAgICAgICB9XHJcbiAgICAgICAgdGhpcy50b29sdGlwTGFiZWxbdGhpcy5zZWxlY3RlZFRodW1iSW5kZXhdID0gdGhpcy5fc2V0VG9vbHRpcExhYmVsKHRoaXMudmFsdWUpO1xyXG4gICAgICAgIHRoaXMudHJhY2tGaWxsU3R5bGVzID0gdGhpcy5fdHJhY2tGaWxsU3R5bGVzKCk7XHJcbiAgICAgICAgaWYgKHRoaXMuX3Rvb2x0aXBBcHBlYXJlZFt0aGlzLnNlbGVjdGVkVGh1bWJJbmRleF0pIHRoaXMudG9vbHRpcEFwaVt0aGlzLnNlbGVjdGVkVGh1bWJJbmRleF0uYWxpZ24oKTtcclxuICAgIH1cclxuXHJcbiAgICAvKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqL1xyXG4gICAgLyogVG9vbHRpcCBmdW5jdGlvbnNcclxuICAgIC8qKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKiovXHJcblxyXG4gICAgcHJpdmF0ZSBfc2V0VG9vbHRpcExhYmVsKF92YWx1ZSk6IEFycmF5PG51bWJlcj4gfCBzdHJpbmcge1xyXG4gICAgICAgIGxldCB0ZXh0OiBhbnkgPSAnJztcclxuICAgICAgICBpZiAodGhpcy5jb25maWcucmFuZ2UpIHtcclxuICAgICAgICAgICAgaWYgKHRoaXMuX2lzRmlyc3RMb2FkKSB7XHJcbiAgICAgICAgICAgICAgICByZXR1cm4gX3ZhbHVlLm1hcCgobnVtKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgdGV4dCA9IHRoaXMuX3NsaWRlclN2Yy5jYWxjdWxhdGVMYWJlbFZhbHVlKG51bSk7XHJcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIHRoaXMuX3NsaWRlclN2Yy5nZXRMYWJlbEZvcm1hdFJlcGxhY2UodGV4dCwgdGhpcy5jb25maWcudG9vbHRpcEZvcm1hdCk7XHJcbiAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB0ZXh0ID0gdGhpcy5fc2xpZGVyU3ZjLmNhbGN1bGF0ZUxhYmVsVmFsdWUoX3ZhbHVlW3RoaXMuc2VsZWN0ZWRUaHVtYkluZGV4XSk7XHJcbiAgICAgICAgfSBlbHNlIGlmICh0aGlzLmNvbmZpZy50eXBlID09PSAnb3RoZXJzJykge1xyXG4gICAgICAgICAgICB0ZXh0ID0gdGhpcy5jb25maWcub3B0aW9uc1tfdmFsdWVdLmRlc2NyaXB0aW9uIHx8IHRoaXMuY29uZmlnLm9wdGlvbnNbX3ZhbHVlXS52YWx1ZS50b1N0cmluZygpO1xyXG4gICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgIHRleHQgPSB0aGlzLl9zbGlkZXJTdmMuY2FsY3VsYXRlTGFiZWxWYWx1ZShfdmFsdWUpO1xyXG4gICAgICAgIH1cclxuICAgICAgICByZXR1cm4gdGhpcy5fc2xpZGVyU3ZjLmdldExhYmVsRm9ybWF0UmVwbGFjZSh0ZXh0LCB0aGlzLmNvbmZpZy50b29sdGlwRm9ybWF0KTtcclxuICAgIH1cclxuXHJcbiAgICAvKiogTG9naWMgZm9yIHRvb2x0aXAgc2hvd2luZyBhbmQgaGlkaW5nICovXHJcbiAgICBwcml2YXRlIF90b29sdGlwQXBwZWFyQ29udHJvbChfZmxhZzogJ2FsbCBzaG93JyB8ICdhbGwgaGlkZScgfCAnc2hvdyBzZWxlY3RlZCcgfCAnaGlkZSBzZWxlY3RlZCcpOiB2b2lkIHtcclxuICAgICAgICBsZXQgaXRlcmF0aW9uczogbnVtYmVyID0gdGhpcy5jb25maWcucmFuZ2UgPyAyIDogMTtcclxuICAgICAgICBzd2l0Y2ggKF9mbGFnKSB7XHJcbiAgICAgICAgICAgIGNhc2UgJ2FsbCBzaG93JzpcclxuICAgICAgICAgICAgICAgIGZvciAobGV0IGkgPSAwOyBpIDwgaXRlcmF0aW9uczsgKytpKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKCF0aGlzLl90b29sdGlwQXBwZWFyZWRbaV0pIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy50b29sdGlwQXBpW2ldLnNob3dUb29sdGlwKCk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuX3Rvb2x0aXBBcHBlYXJlZFtpXSA9IHRydWU7XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgICAgIGNhc2UgJ2FsbCBoaWRlJzpcclxuICAgICAgICAgICAgICAgIGZvciAobGV0IGkgPSAwOyBpIDwgaXRlcmF0aW9uczsgKytpKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKHRoaXMuX3Rvb2x0aXBBcHBlYXJlZFtpXSkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLnRvb2x0aXBBcGlbaV0uaGlkZVRvb2x0aXAoKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5fdG9vbHRpcEFwcGVhcmVkW2ldID0gZmFsc2U7XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgICAgIGNhc2UgJ3Nob3cgc2VsZWN0ZWQnOlxyXG4gICAgICAgICAgICAgICAgaWYgKCF0aGlzLl90b29sdGlwQXBwZWFyZWRbdGhpcy5zZWxlY3RlZFRodW1iSW5kZXhdKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy50b29sdGlwQXBpW3RoaXMuc2VsZWN0ZWRUaHVtYkluZGV4XS5zaG93VG9vbHRpcCgpO1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuX3Rvb2x0aXBBcHBlYXJlZFt0aGlzLnNlbGVjdGVkVGh1bWJJbmRleF0gPSB0cnVlO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgICAgIGNhc2UgJ2hpZGUgc2VsZWN0ZWQnOlxyXG4gICAgICAgICAgICAgICAgaWYgKHRoaXMuX3Rvb2x0aXBBcHBlYXJlZFt0aGlzLnNlbGVjdGVkVGh1bWJJbmRleF0pIHtcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLnRvb2x0aXBBcGlbdGhpcy5zZWxlY3RlZFRodW1iSW5kZXhdLmhpZGVUb29sdGlwKCk7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5fdG9vbHRpcEFwcGVhcmVkW3RoaXMuc2VsZWN0ZWRUaHVtYkluZGV4XSA9IGZhbHNlO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIC8qKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKiovXHJcbiAgICAvKiBBcGlcclxuICAgIC8qKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKiovXHJcblxyXG4gICAgcHJpdmF0ZSBfaW5pdEFwaSgpOiB2b2lkIHtcclxuICAgICAgICBpZiAodHlwZW9mIHRoaXMuYXBpICE9PSAndW5kZWZpbmVkJykge1xyXG4gICAgICAgICAgICB0aGlzLmFwaS5oYW5kbGVWYWx1ZSA9IChfdmFsdWU6IG51bWJlciwgaW5kZXg/OiBudW1iZXIpID0+IHtcclxuICAgICAgICAgICAgICAgIGlmICh0eXBlb2YgaW5kZXggIT09ICd1bmRlZmluZWQnKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5zZWxlY3RlZFRodW1iSW5kZXggPSBpbmRleDtcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLnZhbHVlW2luZGV4XSA9IF92YWx1ZTtcclxuICAgICAgICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy52YWx1ZSA9IF92YWx1ZTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIHRoaXMuX2hhbmRsZVZhbHVlKG51bGwsIF92YWx1ZSk7XHJcbiAgICAgICAgICAgICAgICB0aGlzLl9lbWl0Q2hhbmdlRXZlbnQoKTtcclxuICAgICAgICAgICAgfTtcclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgLyoqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKi9cclxuICAgIC8qIEhlbHBlciBmdW5jdGlvbnMgZm9yIHNldHRpbmcgdmFsdWVzXHJcbiAgICAvKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqL1xyXG5cclxuICAgIC8qKlxyXG4gICAgKiBHZXQgdGhlIGJvdW5kaW5nIGNsaWVudCByZWN0IG9mIHRoZSBzbGlkZXIgdHJhY2sgZWxlbWVudC5cclxuICAgICogVGhlIHRyYWNrIGlzIHVzZWQgcmF0aGVyIHRoYW4gdGhlIG5hdGl2ZSBlbGVtZW50IHRvIGlnbm9yZSB0aGUgZXh0cmEgc3BhY2UgdGhhdCB0aGUgdGh1bWIgY2FuXHJcbiAgICAqIHRha2UgdXAuXHJcbiAgICAqL1xyXG4gICAgcHJpdmF0ZSBfZ2V0U2xpZGVyRGltZW5zaW9ucygpIHtcclxuICAgICAgICByZXR1cm4gdGhpcy5fc2xpZGVyV3JhcHBlciA/IHRoaXMuX3NsaWRlcldyYXBwZXIubmF0aXZlRWxlbWVudC5nZXRCb3VuZGluZ0NsaWVudFJlY3QoKSA6IG51bGw7XHJcbiAgICB9XHJcblxyXG59XHJcbiJdfQ==