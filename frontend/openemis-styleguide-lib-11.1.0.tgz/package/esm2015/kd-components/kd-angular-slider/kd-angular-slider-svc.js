import { Injectable } from '@angular/core';
export class KdSliderSvc {
    /**
     * [config description] set config in service
     *  _config [description]
     */
    set config(_config) {
        this._config = _config;
    }
    /**
     * [direction description] set direction in service
     *  _direction [description]
     */
    set direction(_direction) {
        this._direction = _direction;
    }
    /**
     * [setSideValueLabel description] sets the value to show beside the slider
     *     _value [description] value to be emitted from kd-angular-slider
     *         [description] string to be passed to sideValueLabel HTML element
     */
    setSideValueLabel(_value, _format) {
        let finalLabel = '';
        if (!_value) {
            finalLabel = this._setDefaultValueForLabel();
        }
        else if (Array.isArray(_value)) {
            finalLabel = _value[0] + '-' + _value[1];
        }
        else if (typeof _value === 'object') {
            finalLabel = _value.value;
        }
        else {
            finalLabel = _value;
        }
        return this.getLabelFormatReplace(finalLabel, _format);
    }
    /**
     * [setTooltipPlacement description]
     *  _placement [description]
     *             [description]
     */
    setTooltipPlacement(_placement) {
        if (typeof _placement !== 'undefined')
            return _placement;
        if (this._config.orientation === 'vertical') {
            return 'left';
        }
        return 'top';
    }
    /**
     * [invertAxis description] check whether to invert axis when orientation is vertical
     *  [description]
     */
    invertAxis() {
        return this._config.orientation === 'vertical' ? true : false;
    }
    /**
     * [invertMouseCoords description] check whether to invert mouse coords when orientation is vertical and direction is rtl
     *  [description]
     */
    invertMouseCoords() {
        return (this._direction === 'rtl' && !(this._config.orientation === 'vertical')) ? !this.invertAxis() : this.invertAxis();
    }
    /**
     * [calculateRoundLabelTo description] decimal places to round value (to be emitted) and tooltip label to
     */
    calculateRoundLabelTo() {
        this._roundLabelTo = this._config.step.toString().split('.').pop().length;
    }
    /**
     * [checkValueConflict description] for range only. to check the first thumb value is not larger than the second thumb or the second thumb value is not lesser than first
     *   _currentValue [description]
     *   _otherValue   [description]
     *   _currentId    [description]
     *                [description]
     */
    checkValueConflict(_currentValue, _otherValue, _currentId) {
        switch (_currentId) {
            case 0:
                if (_currentValue > _otherValue)
                    return true;
                return false;
            case 1:
                if (_currentValue < _otherValue)
                    return true;
                return false;
            default:
                return false;
        }
    }
    /**
     * [clamp description] Return a number between two numbers.
     *  value [description]
     *  min   =             0 [description]
     *  max   =             1 [description]
     *        [description]
     */
    clamp(value, min = 0, max = 1) {
        return Math.max(min, Math.min(value, max));
    }
    /**
     * [calculateLabelValue description] calculate how many decimals to round the tooltip text to
     *  _value [description]
     *         [description]
     */
    calculateLabelValue(_value) {
        if (this._roundLabelTo && _value && _value % 1 !== 0) {
            return _value.toFixed(this._roundLabelTo);
        }
        else {
            return _value.toString() || '0';
        }
    }
    /**
     * [calculatePercentage description] Calculates the percentage of the slider that a value is.
     *         _value [description]
     *       [description]
     */
    calculatePercentage(_value) {
        return ((_value || 0) - this._config.min) / (this._config.max - this._config.min);
    }
    /**
     * [calculateValue description] Calculates the value a percentage of the slider corresponds to.
     *  _percentage [description]
     *              [description]
     */
    calculateValue(_percentage) {
        let exactValue = this.convertPercentToValue(_percentage);
        let closestValue = parseFloat((Math.round((exactValue - this._config.min) / this._config.step) * this._config.step).toFixed(this._roundLabelTo)) + this._config.min;
        return this.clamp(closestValue, this._config.min, this._config.max);
    }
    /**
     * takes in this.config.labelFormat and replaces {value} to text
     * _format {value} will be replaced by text
     * _text   value
     */
    getLabelFormatReplace(_text, _format) {
        return _format ? _format.replace(/{value}/g, _text) : _text;
    }
    /**
     * [convertPercentToValue description] Converts percent of the slider to value (not rounded)
     *  _percentage [description]
     *              [description]
     */
    convertPercentToValue(_percentage) {
        return this._config.min + _percentage * (this._config.max - this._config.min);
    }
    /**
     * [_setDefaultValueForLabel description]
     *  [description]
     */
    _setDefaultValueForLabel() {
        if (this._config.type === 'others')
            return this._config.options[0];
        if (this._config.range)
            this._config.range = false;
        return 0;
    }
}
KdSliderSvc.decorators = [
    { type: Injectable }
];
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoia2QtYW5ndWxhci1zbGlkZXItc3ZjLmpzIiwic291cmNlUm9vdCI6IkM6L1Byb2plY3RzL0FuZ3VsYXIvaW9zdGctb3BlbmVtaXMtc3R5bGVndWlkZS9wcm9qZWN0cy9vcGVuZW1pcy1zdHlsZWd1aWRlLWxpYi9zcmMvIiwic291cmNlcyI6WyJrZC1jb21wb25lbnRzL2tkLWFuZ3VsYXItc2xpZGVyL2tkLWFuZ3VsYXItc2xpZGVyLXN2Yy50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQSxPQUFPLEVBQUUsVUFBVSxFQUFFLE1BQU0sZUFBZSxDQUFDO0FBSTNDLE1BQU0sT0FBTyxXQUFXO0lBTXBCOzs7T0FHRztJQUNILElBQUksTUFBTSxDQUFDLE9BQXNCO1FBQzdCLElBQUksQ0FBQyxPQUFPLEdBQUcsT0FBTyxDQUFDO0lBQzNCLENBQUM7SUFFRDs7O09BR0c7SUFDSCxJQUFJLFNBQVMsQ0FBQyxVQUFVO1FBQ3BCLElBQUksQ0FBQyxVQUFVLEdBQUcsVUFBVSxDQUFDO0lBQ2pDLENBQUM7SUFFRDs7OztPQUlHO0lBQ0ksaUJBQWlCLENBQUMsTUFBVyxFQUFFLE9BQWU7UUFDakQsSUFBSSxVQUFVLEdBQVEsRUFBRSxDQUFDO1FBQ3pCLElBQUksQ0FBQyxNQUFNLEVBQUU7WUFDVCxVQUFVLEdBQUcsSUFBSSxDQUFDLHdCQUF3QixFQUFFLENBQUM7U0FDaEQ7YUFBTSxJQUFJLEtBQUssQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLEVBQUU7WUFDOUIsVUFBVSxHQUFHLE1BQU0sQ0FBQyxDQUFDLENBQUMsR0FBRyxHQUFHLEdBQUcsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDO1NBQzVDO2FBQU0sSUFBSSxPQUFPLE1BQU0sS0FBSyxRQUFRLEVBQUU7WUFDbkMsVUFBVSxHQUFHLE1BQU0sQ0FBQyxLQUFLLENBQUM7U0FDN0I7YUFBTTtZQUNILFVBQVUsR0FBRyxNQUFNLENBQUE7U0FDdEI7UUFFRCxPQUFPLElBQUksQ0FBQyxxQkFBcUIsQ0FBQyxVQUFVLEVBQUUsT0FBTyxDQUFDLENBQUM7SUFDM0QsQ0FBQztJQUVEOzs7O09BSUc7SUFDSSxtQkFBbUIsQ0FBQyxVQUFrQjtRQUN6QyxJQUFJLE9BQU8sVUFBVSxLQUFLLFdBQVc7WUFBRSxPQUFPLFVBQVUsQ0FBQztRQUN6RCxJQUFJLElBQUksQ0FBQyxPQUFPLENBQUMsV0FBVyxLQUFLLFVBQVUsRUFBRTtZQUN6QyxPQUFPLE1BQU0sQ0FBQztTQUNqQjtRQUNELE9BQU8sS0FBSyxDQUFDO0lBQ2pCLENBQUM7SUFFRDs7O09BR0c7SUFDSSxVQUFVO1FBQ2IsT0FBTyxJQUFJLENBQUMsT0FBTyxDQUFDLFdBQVcsS0FBSyxVQUFVLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDO0lBQ2xFLENBQUM7SUFFRDs7O09BR0c7SUFDSSxpQkFBaUI7UUFDcEIsT0FBTyxDQUFDLElBQUksQ0FBQyxVQUFVLEtBQUssS0FBSyxJQUFJLENBQUMsQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLFdBQVcsS0FBSyxVQUFVLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxVQUFVLEVBQUUsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLFVBQVUsRUFBRSxDQUFDO0lBQzlILENBQUM7SUFFRDs7T0FFRztJQUNJLHFCQUFxQjtRQUN4QixJQUFJLENBQUMsYUFBYSxHQUFHLElBQUksQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLFFBQVEsRUFBRSxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FBQyxHQUFHLEVBQUcsQ0FBQyxNQUFNLENBQUM7SUFDL0UsQ0FBQztJQUVEOzs7Ozs7T0FNRztJQUNJLGtCQUFrQixDQUFDLGFBQXFCLEVBQUUsV0FBbUIsRUFBRSxVQUFrQjtRQUNwRixRQUFRLFVBQVUsRUFBRTtZQUNoQixLQUFLLENBQUM7Z0JBQ0YsSUFBSSxhQUFhLEdBQUcsV0FBVztvQkFBRSxPQUFPLElBQUksQ0FBQztnQkFDN0MsT0FBTyxLQUFLLENBQUM7WUFDakIsS0FBSyxDQUFDO2dCQUNGLElBQUksYUFBYSxHQUFHLFdBQVc7b0JBQUUsT0FBTyxJQUFJLENBQUM7Z0JBQzdDLE9BQU8sS0FBSyxDQUFDO1lBQ2pCO2dCQUNJLE9BQU8sS0FBSyxDQUFDO1NBQ3BCO0lBQ0wsQ0FBQztJQUVEOzs7Ozs7T0FNRztJQUNJLEtBQUssQ0FBQyxLQUFhLEVBQUUsR0FBRyxHQUFHLENBQUMsRUFBRSxHQUFHLEdBQUcsQ0FBQztRQUN4QyxPQUFPLElBQUksQ0FBQyxHQUFHLENBQUMsR0FBRyxFQUFFLElBQUksQ0FBQyxHQUFHLENBQUMsS0FBSyxFQUFFLEdBQUcsQ0FBQyxDQUFDLENBQUM7SUFDL0MsQ0FBQztJQUVEOzs7O09BSUc7SUFDSSxtQkFBbUIsQ0FBQyxNQUFjO1FBQ3JDLElBQUksSUFBSSxDQUFDLGFBQWEsSUFBSSxNQUFNLElBQUksTUFBTSxHQUFHLENBQUMsS0FBSyxDQUFDLEVBQUU7WUFDbEQsT0FBTyxNQUFNLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxhQUFhLENBQUMsQ0FBQztTQUM3QzthQUFNO1lBQ0gsT0FBTyxNQUFNLENBQUMsUUFBUSxFQUFFLElBQUksR0FBRyxDQUFDO1NBQ25DO0lBQ0wsQ0FBQztJQUVEOzs7O09BSUc7SUFDSSxtQkFBbUIsQ0FBQyxNQUFxQjtRQUM1QyxPQUFPLENBQUMsQ0FBQyxNQUFNLElBQUksQ0FBQyxDQUFDLEdBQUcsSUFBSSxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsR0FBRyxHQUFHLElBQUksQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLENBQUM7SUFDdEYsQ0FBQztJQUVEOzs7O09BSUc7SUFDSSxjQUFjLENBQUMsV0FBbUI7UUFDckMsSUFBSSxVQUFVLEdBQVcsSUFBSSxDQUFDLHFCQUFxQixDQUFDLFdBQVcsQ0FBQyxDQUFDO1FBQ2pFLElBQUksWUFBWSxHQUFXLFVBQVUsQ0FBQyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQyxVQUFVLEdBQUcsSUFBSSxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsR0FBRyxJQUFJLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxHQUFHLElBQUksQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxhQUFhLENBQUMsQ0FBQyxHQUFHLElBQUksQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDO1FBQzVLLE9BQU8sSUFBSSxDQUFDLEtBQUssQ0FBQyxZQUFZLEVBQUUsSUFBSSxDQUFDLE9BQU8sQ0FBQyxHQUFHLEVBQUUsSUFBSSxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsQ0FBQztJQUN4RSxDQUFDO0lBRUQ7Ozs7T0FJRztJQUNJLHFCQUFxQixDQUFDLEtBQWEsRUFBRSxPQUFlO1FBQ3ZELE9BQU8sT0FBTyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsT0FBTyxDQUFDLFVBQVUsRUFBRSxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDO0lBQ2hFLENBQUM7SUFFRDs7OztPQUlHO0lBQ0kscUJBQXFCLENBQUMsV0FBbUI7UUFDNUMsT0FBTyxJQUFJLENBQUMsT0FBTyxDQUFDLEdBQUcsR0FBRyxXQUFXLEdBQUcsQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLEdBQUcsR0FBRyxJQUFJLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxDQUFDO0lBQ2xGLENBQUM7SUFFRDs7O09BR0c7SUFDSyx3QkFBd0I7UUFDNUIsSUFBSSxJQUFJLENBQUMsT0FBTyxDQUFDLElBQUksS0FBSyxRQUFRO1lBQUUsT0FBTyxJQUFJLENBQUMsT0FBTyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQztRQUNuRSxJQUFJLElBQUksQ0FBQyxPQUFPLENBQUMsS0FBSztZQUFFLElBQUksQ0FBQyxPQUFPLENBQUMsS0FBSyxHQUFHLEtBQUssQ0FBQztRQUNuRCxPQUFPLENBQUMsQ0FBQztJQUNiLENBQUM7OztZQXpLSixVQUFVIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgSW5qZWN0YWJsZSB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xyXG5pbXBvcnQgeyBJU2xpZGVyQ29uZmlnIH0gZnJvbSAnLi9rZC1hbmd1bGFyLXNsaWRlci1pbnRlcmZhY2UnO1xyXG5cclxuQEluamVjdGFibGUoKVxyXG5leHBvcnQgY2xhc3MgS2RTbGlkZXJTdmMge1xyXG5cclxuICAgIHByaXZhdGUgX3JvdW5kTGFiZWxUbzogbnVtYmVyO1xyXG4gICAgcHJpdmF0ZSBfY29uZmlnOiBJU2xpZGVyQ29uZmlnO1xyXG4gICAgcHJpdmF0ZSBfZGlyZWN0aW9uOiAncnRsJyB8ICdsdHInO1xyXG5cclxuICAgIC8qKlxyXG4gICAgICogW2NvbmZpZyBkZXNjcmlwdGlvbl0gc2V0IGNvbmZpZyBpbiBzZXJ2aWNlXHJcbiAgICAgKiAgX2NvbmZpZyBbZGVzY3JpcHRpb25dXHJcbiAgICAgKi9cclxuICAgIHNldCBjb25maWcoX2NvbmZpZzogSVNsaWRlckNvbmZpZykge1xyXG4gICAgICAgIHRoaXMuX2NvbmZpZyA9IF9jb25maWc7XHJcbiAgICB9XHJcblxyXG4gICAgLyoqXHJcbiAgICAgKiBbZGlyZWN0aW9uIGRlc2NyaXB0aW9uXSBzZXQgZGlyZWN0aW9uIGluIHNlcnZpY2VcclxuICAgICAqICBfZGlyZWN0aW9uIFtkZXNjcmlwdGlvbl1cclxuICAgICAqL1xyXG4gICAgc2V0IGRpcmVjdGlvbihfZGlyZWN0aW9uKSB7XHJcbiAgICAgICAgdGhpcy5fZGlyZWN0aW9uID0gX2RpcmVjdGlvbjtcclxuICAgIH1cclxuXHJcbiAgICAvKipcclxuICAgICAqIFtzZXRTaWRlVmFsdWVMYWJlbCBkZXNjcmlwdGlvbl0gc2V0cyB0aGUgdmFsdWUgdG8gc2hvdyBiZXNpZGUgdGhlIHNsaWRlclxyXG4gICAgICogICAgIF92YWx1ZSBbZGVzY3JpcHRpb25dIHZhbHVlIHRvIGJlIGVtaXR0ZWQgZnJvbSBrZC1hbmd1bGFyLXNsaWRlclxyXG4gICAgICogICAgICAgICBbZGVzY3JpcHRpb25dIHN0cmluZyB0byBiZSBwYXNzZWQgdG8gc2lkZVZhbHVlTGFiZWwgSFRNTCBlbGVtZW50XHJcbiAgICAgKi9cclxuICAgIHB1YmxpYyBzZXRTaWRlVmFsdWVMYWJlbChfdmFsdWU6IGFueSwgX2Zvcm1hdDogc3RyaW5nKTogc3RyaW5nIHtcclxuICAgICAgICBsZXQgZmluYWxMYWJlbDogYW55ID0gJyc7XHJcbiAgICAgICAgaWYgKCFfdmFsdWUpIHtcclxuICAgICAgICAgICAgZmluYWxMYWJlbCA9IHRoaXMuX3NldERlZmF1bHRWYWx1ZUZvckxhYmVsKCk7XHJcbiAgICAgICAgfSBlbHNlIGlmIChBcnJheS5pc0FycmF5KF92YWx1ZSkpIHtcclxuICAgICAgICAgICAgZmluYWxMYWJlbCA9IF92YWx1ZVswXSArICctJyArIF92YWx1ZVsxXTtcclxuICAgICAgICB9IGVsc2UgaWYgKHR5cGVvZiBfdmFsdWUgPT09ICdvYmplY3QnKSB7XHJcbiAgICAgICAgICAgIGZpbmFsTGFiZWwgPSBfdmFsdWUudmFsdWU7XHJcbiAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgZmluYWxMYWJlbCA9IF92YWx1ZVxyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgcmV0dXJuIHRoaXMuZ2V0TGFiZWxGb3JtYXRSZXBsYWNlKGZpbmFsTGFiZWwsIF9mb3JtYXQpO1xyXG4gICAgfVxyXG5cclxuICAgIC8qKlxyXG4gICAgICogW3NldFRvb2x0aXBQbGFjZW1lbnQgZGVzY3JpcHRpb25dXHJcbiAgICAgKiAgX3BsYWNlbWVudCBbZGVzY3JpcHRpb25dXHJcbiAgICAgKiAgICAgICAgICAgICBbZGVzY3JpcHRpb25dXHJcbiAgICAgKi9cclxuICAgIHB1YmxpYyBzZXRUb29sdGlwUGxhY2VtZW50KF9wbGFjZW1lbnQ6IHN0cmluZyk6IHN0cmluZyB7XHJcbiAgICAgICAgaWYgKHR5cGVvZiBfcGxhY2VtZW50ICE9PSAndW5kZWZpbmVkJykgcmV0dXJuIF9wbGFjZW1lbnQ7XHJcbiAgICAgICAgaWYgKHRoaXMuX2NvbmZpZy5vcmllbnRhdGlvbiA9PT0gJ3ZlcnRpY2FsJykge1xyXG4gICAgICAgICAgICByZXR1cm4gJ2xlZnQnO1xyXG4gICAgICAgIH1cclxuICAgICAgICByZXR1cm4gJ3RvcCc7XHJcbiAgICB9XHJcblxyXG4gICAgLyoqXHJcbiAgICAgKiBbaW52ZXJ0QXhpcyBkZXNjcmlwdGlvbl0gY2hlY2sgd2hldGhlciB0byBpbnZlcnQgYXhpcyB3aGVuIG9yaWVudGF0aW9uIGlzIHZlcnRpY2FsXHJcbiAgICAgKiAgW2Rlc2NyaXB0aW9uXVxyXG4gICAgICovXHJcbiAgICBwdWJsaWMgaW52ZXJ0QXhpcygpOiBib29sZWFuIHtcclxuICAgICAgICByZXR1cm4gdGhpcy5fY29uZmlnLm9yaWVudGF0aW9uID09PSAndmVydGljYWwnID8gdHJ1ZSA6IGZhbHNlO1xyXG4gICAgfVxyXG5cclxuICAgIC8qKlxyXG4gICAgICogW2ludmVydE1vdXNlQ29vcmRzIGRlc2NyaXB0aW9uXSBjaGVjayB3aGV0aGVyIHRvIGludmVydCBtb3VzZSBjb29yZHMgd2hlbiBvcmllbnRhdGlvbiBpcyB2ZXJ0aWNhbCBhbmQgZGlyZWN0aW9uIGlzIHJ0bFxyXG4gICAgICogIFtkZXNjcmlwdGlvbl1cclxuICAgICAqL1xyXG4gICAgcHVibGljIGludmVydE1vdXNlQ29vcmRzKCk6IGJvb2xlYW4ge1xyXG4gICAgICAgIHJldHVybiAodGhpcy5fZGlyZWN0aW9uID09PSAncnRsJyAmJiAhKHRoaXMuX2NvbmZpZy5vcmllbnRhdGlvbiA9PT0gJ3ZlcnRpY2FsJykpID8gIXRoaXMuaW52ZXJ0QXhpcygpIDogdGhpcy5pbnZlcnRBeGlzKCk7XHJcbiAgICB9XHJcblxyXG4gICAgLyoqXHJcbiAgICAgKiBbY2FsY3VsYXRlUm91bmRMYWJlbFRvIGRlc2NyaXB0aW9uXSBkZWNpbWFsIHBsYWNlcyB0byByb3VuZCB2YWx1ZSAodG8gYmUgZW1pdHRlZCkgYW5kIHRvb2x0aXAgbGFiZWwgdG9cclxuICAgICAqL1xyXG4gICAgcHVibGljIGNhbGN1bGF0ZVJvdW5kTGFiZWxUbygpIHtcclxuICAgICAgICB0aGlzLl9yb3VuZExhYmVsVG8gPSB0aGlzLl9jb25maWcuc3RlcC50b1N0cmluZygpLnNwbGl0KCcuJykucG9wKCkhLmxlbmd0aDtcclxuICAgIH1cclxuXHJcbiAgICAvKipcclxuICAgICAqIFtjaGVja1ZhbHVlQ29uZmxpY3QgZGVzY3JpcHRpb25dIGZvciByYW5nZSBvbmx5LiB0byBjaGVjayB0aGUgZmlyc3QgdGh1bWIgdmFsdWUgaXMgbm90IGxhcmdlciB0aGFuIHRoZSBzZWNvbmQgdGh1bWIgb3IgdGhlIHNlY29uZCB0aHVtYiB2YWx1ZSBpcyBub3QgbGVzc2VyIHRoYW4gZmlyc3RcclxuICAgICAqICAgX2N1cnJlbnRWYWx1ZSBbZGVzY3JpcHRpb25dXHJcbiAgICAgKiAgIF9vdGhlclZhbHVlICAgW2Rlc2NyaXB0aW9uXVxyXG4gICAgICogICBfY3VycmVudElkICAgIFtkZXNjcmlwdGlvbl1cclxuICAgICAqICAgICAgICAgICAgICAgIFtkZXNjcmlwdGlvbl1cclxuICAgICAqL1xyXG4gICAgcHVibGljIGNoZWNrVmFsdWVDb25mbGljdChfY3VycmVudFZhbHVlOiBudW1iZXIsIF9vdGhlclZhbHVlOiBudW1iZXIsIF9jdXJyZW50SWQ6IG51bWJlcik6IGJvb2xlYW4ge1xyXG4gICAgICAgIHN3aXRjaCAoX2N1cnJlbnRJZCkge1xyXG4gICAgICAgICAgICBjYXNlIDA6XHJcbiAgICAgICAgICAgICAgICBpZiAoX2N1cnJlbnRWYWx1ZSA+IF9vdGhlclZhbHVlKSByZXR1cm4gdHJ1ZTtcclxuICAgICAgICAgICAgICAgIHJldHVybiBmYWxzZTtcclxuICAgICAgICAgICAgY2FzZSAxOlxyXG4gICAgICAgICAgICAgICAgaWYgKF9jdXJyZW50VmFsdWUgPCBfb3RoZXJWYWx1ZSkgcmV0dXJuIHRydWU7XHJcbiAgICAgICAgICAgICAgICByZXR1cm4gZmFsc2U7XHJcbiAgICAgICAgICAgIGRlZmF1bHQ6XHJcbiAgICAgICAgICAgICAgICByZXR1cm4gZmFsc2U7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIC8qKlxyXG4gICAgICogW2NsYW1wIGRlc2NyaXB0aW9uXSBSZXR1cm4gYSBudW1iZXIgYmV0d2VlbiB0d28gbnVtYmVycy5cclxuICAgICAqICB2YWx1ZSBbZGVzY3JpcHRpb25dXHJcbiAgICAgKiAgbWluICAgPSAgICAgICAgICAgICAwIFtkZXNjcmlwdGlvbl1cclxuICAgICAqICBtYXggICA9ICAgICAgICAgICAgIDEgW2Rlc2NyaXB0aW9uXVxyXG4gICAgICogICAgICAgIFtkZXNjcmlwdGlvbl1cclxuICAgICAqL1xyXG4gICAgcHVibGljIGNsYW1wKHZhbHVlOiBudW1iZXIsIG1pbiA9IDAsIG1heCA9IDEpOiBudW1iZXIge1xyXG4gICAgICAgIHJldHVybiBNYXRoLm1heChtaW4sIE1hdGgubWluKHZhbHVlLCBtYXgpKTtcclxuICAgIH1cclxuXHJcbiAgICAvKipcclxuICAgICAqIFtjYWxjdWxhdGVMYWJlbFZhbHVlIGRlc2NyaXB0aW9uXSBjYWxjdWxhdGUgaG93IG1hbnkgZGVjaW1hbHMgdG8gcm91bmQgdGhlIHRvb2x0aXAgdGV4dCB0b1xyXG4gICAgICogIF92YWx1ZSBbZGVzY3JpcHRpb25dXHJcbiAgICAgKiAgICAgICAgIFtkZXNjcmlwdGlvbl1cclxuICAgICAqL1xyXG4gICAgcHVibGljIGNhbGN1bGF0ZUxhYmVsVmFsdWUoX3ZhbHVlOiBudW1iZXIpOiBzdHJpbmcge1xyXG4gICAgICAgIGlmICh0aGlzLl9yb3VuZExhYmVsVG8gJiYgX3ZhbHVlICYmIF92YWx1ZSAlIDEgIT09IDApIHtcclxuICAgICAgICAgICAgcmV0dXJuIF92YWx1ZS50b0ZpeGVkKHRoaXMuX3JvdW5kTGFiZWxUbyk7XHJcbiAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgcmV0dXJuIF92YWx1ZS50b1N0cmluZygpIHx8ICcwJztcclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgLyoqXHJcbiAgICAgKiBbY2FsY3VsYXRlUGVyY2VudGFnZSBkZXNjcmlwdGlvbl0gQ2FsY3VsYXRlcyB0aGUgcGVyY2VudGFnZSBvZiB0aGUgc2xpZGVyIHRoYXQgYSB2YWx1ZSBpcy5cclxuICAgICAqICAgICAgICAgX3ZhbHVlIFtkZXNjcmlwdGlvbl1cclxuICAgICAqICAgICAgIFtkZXNjcmlwdGlvbl1cclxuICAgICAqL1xyXG4gICAgcHVibGljIGNhbGN1bGF0ZVBlcmNlbnRhZ2UoX3ZhbHVlOiBudW1iZXIgfCBudWxsKTogbnVtYmVyIHtcclxuICAgICAgICByZXR1cm4gKChfdmFsdWUgfHwgMCkgLSB0aGlzLl9jb25maWcubWluKSAvICh0aGlzLl9jb25maWcubWF4IC0gdGhpcy5fY29uZmlnLm1pbik7XHJcbiAgICB9XHJcblxyXG4gICAgLyoqXHJcbiAgICAgKiBbY2FsY3VsYXRlVmFsdWUgZGVzY3JpcHRpb25dIENhbGN1bGF0ZXMgdGhlIHZhbHVlIGEgcGVyY2VudGFnZSBvZiB0aGUgc2xpZGVyIGNvcnJlc3BvbmRzIHRvLlxyXG4gICAgICogIF9wZXJjZW50YWdlIFtkZXNjcmlwdGlvbl1cclxuICAgICAqICAgICAgICAgICAgICBbZGVzY3JpcHRpb25dXHJcbiAgICAgKi9cclxuICAgIHB1YmxpYyBjYWxjdWxhdGVWYWx1ZShfcGVyY2VudGFnZTogbnVtYmVyKTogbnVtYmVyIHtcclxuICAgICAgICBsZXQgZXhhY3RWYWx1ZTogbnVtYmVyID0gdGhpcy5jb252ZXJ0UGVyY2VudFRvVmFsdWUoX3BlcmNlbnRhZ2UpO1xyXG4gICAgICAgIGxldCBjbG9zZXN0VmFsdWU6IG51bWJlciA9IHBhcnNlRmxvYXQoKE1hdGgucm91bmQoKGV4YWN0VmFsdWUgLSB0aGlzLl9jb25maWcubWluKSAvIHRoaXMuX2NvbmZpZy5zdGVwKSAqIHRoaXMuX2NvbmZpZy5zdGVwKS50b0ZpeGVkKHRoaXMuX3JvdW5kTGFiZWxUbykpICsgdGhpcy5fY29uZmlnLm1pbjtcclxuICAgICAgICByZXR1cm4gdGhpcy5jbGFtcChjbG9zZXN0VmFsdWUsIHRoaXMuX2NvbmZpZy5taW4sIHRoaXMuX2NvbmZpZy5tYXgpO1xyXG4gICAgfVxyXG5cclxuICAgIC8qKlxyXG4gICAgICogdGFrZXMgaW4gdGhpcy5jb25maWcubGFiZWxGb3JtYXQgYW5kIHJlcGxhY2VzIHt2YWx1ZX0gdG8gdGV4dFxyXG4gICAgICogX2Zvcm1hdCB7dmFsdWV9IHdpbGwgYmUgcmVwbGFjZWQgYnkgdGV4dFxyXG4gICAgICogX3RleHQgICB2YWx1ZVxyXG4gICAgICovXHJcbiAgICBwdWJsaWMgZ2V0TGFiZWxGb3JtYXRSZXBsYWNlKF90ZXh0OiBzdHJpbmcsIF9mb3JtYXQ6IHN0cmluZyk6IHN0cmluZyB7XHJcbiAgICAgICAgcmV0dXJuIF9mb3JtYXQgPyBfZm9ybWF0LnJlcGxhY2UoL3t2YWx1ZX0vZywgX3RleHQpIDogX3RleHQ7XHJcbiAgICB9XHJcblxyXG4gICAgLyoqXHJcbiAgICAgKiBbY29udmVydFBlcmNlbnRUb1ZhbHVlIGRlc2NyaXB0aW9uXSBDb252ZXJ0cyBwZXJjZW50IG9mIHRoZSBzbGlkZXIgdG8gdmFsdWUgKG5vdCByb3VuZGVkKVxyXG4gICAgICogIF9wZXJjZW50YWdlIFtkZXNjcmlwdGlvbl1cclxuICAgICAqICAgICAgICAgICAgICBbZGVzY3JpcHRpb25dXHJcbiAgICAgKi9cclxuICAgIHB1YmxpYyBjb252ZXJ0UGVyY2VudFRvVmFsdWUoX3BlcmNlbnRhZ2U6IG51bWJlcik6IG51bWJlciB7XHJcbiAgICAgICAgcmV0dXJuIHRoaXMuX2NvbmZpZy5taW4gKyBfcGVyY2VudGFnZSAqICh0aGlzLl9jb25maWcubWF4IC0gdGhpcy5fY29uZmlnLm1pbik7XHJcbiAgICB9XHJcblxyXG4gICAgLyoqXHJcbiAgICAgKiBbX3NldERlZmF1bHRWYWx1ZUZvckxhYmVsIGRlc2NyaXB0aW9uXVxyXG4gICAgICogIFtkZXNjcmlwdGlvbl1cclxuICAgICAqL1xyXG4gICAgcHJpdmF0ZSBfc2V0RGVmYXVsdFZhbHVlRm9yTGFiZWwoKTogYW55IHtcclxuICAgICAgICBpZiAodGhpcy5fY29uZmlnLnR5cGUgPT09ICdvdGhlcnMnKSByZXR1cm4gdGhpcy5fY29uZmlnLm9wdGlvbnNbMF07XHJcbiAgICAgICAgaWYgKHRoaXMuX2NvbmZpZy5yYW5nZSkgdGhpcy5fY29uZmlnLnJhbmdlID0gZmFsc2U7XHJcbiAgICAgICAgcmV0dXJuIDA7XHJcbiAgICB9XHJcbn1cclxuIl19