import { Component, Input, EventEmitter, Output, } from '@angular/core';
import { KdSliderSvc } from './kd-angular-slider-svc';
export class KdSlider {
    constructor(_sliderSvc) {
        this._sliderSvc = _sliderSvc;
        this.config = {};
        this.value = 0;
        this.isPlay = false;
        this.wrapperStyle = {};
        this.apiInternal = {};
        this._defaultConfig = {
            orientation: 'horizontal',
            range: false,
            max: 100,
            min: 0,
            step: 1,
            disabled: false,
            autoplay: false,
            autoplayStep: 1,
        };
        this.sliderValue = 0;
        this.result = new EventEmitter();
    }
    ngOnInit() {
        this._setConfig(this.sliderConfig);
        this.value = this._setData(this.sliderValue, this.config);
        this._outputValue = this.value;
        this.sliderId = typeof this.id !== 'undefined' ? this.id : 'slider';
        this._initApi();
    }
    ngOnChanges(_simpleChanges) {
        if (_simpleChanges.hasOwnProperty('sliderConfig') && !_simpleChanges['sliderConfig'].firstChange) {
            if (_simpleChanges['sliderConfig'].currentValue === this.config)
                return;
            this._setConfig(_simpleChanges['sliderConfig'].currentValue);
        }
        if (_simpleChanges.hasOwnProperty('sliderValue') && !_simpleChanges['sliderValue'].firstChange) {
            if (_simpleChanges['sliderValue'].currentValue === this.value)
                return;
            this.value = this._setData(_simpleChanges['sliderValue'].currentValue, this.config);
            this._outputValue = this.value;
        }
        if (_simpleChanges.hasOwnProperty('id') && !_simpleChanges['id'].firstChange) {
            if (_simpleChanges['id'].currentValue === this.sliderId)
                return;
            this.sliderId = typeof _simpleChanges['id'].currentValue !== 'undefined' ? _simpleChanges['id'].currentValue : 'slider';
        }
    }
    /** Emits a change event if the current value is different from the last emitted value. */
    emitChangeEvent(_result) {
        /**type === number | Array<number> | Object with at least the following properties:
        * {
        *   description?: string;
        *   value: string | number;
        * }
        * */
        this._outputValue = this.config.type && this.config.type === 'others' ? this.config.options[Math.round(_result.value)] : _result.value;
        if (_result.currentAction !== 'sliding')
            this.result.emit(this._outputValue);
        this.sideValueLabel = this._sliderSvc.setSideValueLabel(this._outputValue, this.config.sideValueLabelFormat);
    }
    /** Toggle autoplay */
    clickPlayBtn() {
        if (this.config.disabled)
            return;
        this.isPlay = this.isPlay ? false : true;
    }
    /** Update this.isPlay when end of slider is reached */
    endPlay(_end) {
        this.isPlay = _end ? false : true;
    }
    _initApi() {
        if (typeof this.api !== 'undefined') {
            this.api.disable = (_flag) => {
                this.config = Object.assign({}, this.config, { disabled: _flag });
            };
            this.api.getSliderThumbValue = () => {
                return this._outputValue;
            };
            this.api.setSliderThumbValue = (_value, _thumbIndex) => {
                let valueToUpdate = _value;
                if (Array.isArray(_value)) {
                    if (typeof _thumbIndex === 'undefined') {
                        console.log('please pass the _thumbIndex of which to update value to');
                        return;
                    }
                    valueToUpdate = _value[_thumbIndex];
                }
                if (this.config.type === 'others') {
                    for (let i = 0; i < this.sliderValue.length; ++i) {
                        if (this.sliderValue[i].value === _value.value) {
                            valueToUpdate = i;
                            break;
                        }
                    }
                }
                this.apiInternal.handleValue(valueToUpdate, _thumbIndex);
            };
        }
    }
    _setConfig(_config) {
        this.config = Object.assign({}, this._defaultConfig, _config);
        if (this.config.width)
            this.wrapperStyle = { 'width': this.config.width };
        this._sliderSvc.config = this.config;
        this.sideValueLabel = this._sliderSvc.setSideValueLabel(this.sliderValue, this.config.sideValueLabelFormat);
    }
    _setData(_value, _config) {
        if (_config.type === 'others') {
            let newValue;
            this.config.max = _config.options.length - 1;
            this.config.step = 1;
            this.config.min = 0;
            this._sliderSvc.config = this.config;
            for (let i = 0; i < _config.options.length; ++i) {
                if (_config.options[i].value === _value.value) {
                    newValue = i;
                    break;
                }
            }
            return newValue || 0;
        }
        if (!Array.isArray(_value)) {
            this.config.range = false;
            this._sliderSvc.config = this.config;
            return _value;
        }
        if (_config.range) {
            this.config.autoplay = false;
            let newValue = _value.map((el) => {
                if (typeof el !== 'number')
                    el = parseFloat(el);
                return this._sliderSvc.clamp(el, this.config.min, this.config.max);
            });
            return newValue;
        }
        return 0;
    }
}
KdSlider.decorators = [
    { type: Component, args: [{
                selector: 'kd-slider',
                template: `
        <div class="kdx-slider-wrapper" [id]="sliderId" [ngStyle]="wrapperStyle">
            <div class="kdx-slider-container" [ngClass]="{'kdx-slider-container-vertical': config.orientation === 'vertical'}">
                <button *ngIf="config.autoplay" class="btn" (click)="clickPlayBtn()" [attr.disabled]="config.disabled? '': null">
                    <i class="play-icon fa" aria-hidden="true" [ngClass]="{'fa-play': !isPlay, 'fa-pause': isPlay}"></i>
                </button>
                <kd-slider-content [value]="value"
                                   [config]="config"
                                   [isPlay]="isPlay"
                                   [api]="apiInternal"
                                   (endPlay)="endPlay($event)"
                                   (result)="emitChangeEvent($event)">
                </kd-slider-content>
                <div *ngIf="config.sideValueLabel" class="side-value-label kdx-label">{{sideValueLabel}}</div>
            </div>
            <div *ngIf="config.startLabel" class="kdx-label-container">
                <div *ngIf="config.startLabel" class="kdx-label" >
                    {{config.startLabel}}
                </div>
                <div *ngIf="config.endLabel" class="kdx-label" >
                    {{config.endLabel}}
                </div>
            </div>
           <ng-content></ng-content>
        </div>
    `,
                providers: [KdSliderSvc],
                host: {
                    'class': 'kdx-slider',
                    '[class.kdx-slider-has-start-label]': 'config.startLabel',
                }
            },] }
];
KdSlider.ctorParameters = () => [
    { type: KdSliderSvc }
];
KdSlider.propDecorators = {
    id: [{ type: Input }],
    sliderValue: [{ type: Input, args: ['value',] }],
    sliderConfig: [{ type: Input, args: ['config',] }],
    api: [{ type: Input }],
    result: [{ type: Output }]
};
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoia2QtYW5ndWxhci1zbGlkZXIuanMiLCJzb3VyY2VSb290IjoiQzovUHJvamVjdHMvQW5ndWxhci9pb3N0Zy1vcGVuZW1pcy1zdHlsZWd1aWRlL3Byb2plY3RzL29wZW5lbWlzLXN0eWxlZ3VpZGUtbGliL3NyYy8iLCJzb3VyY2VzIjpbImtkLWNvbXBvbmVudHMva2QtYW5ndWxhci1zbGlkZXIva2QtYW5ndWxhci1zbGlkZXIudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsT0FBTyxFQUNILFNBQVMsRUFDVCxLQUFLLEVBSUwsWUFBWSxFQUNaLE1BQU0sR0FDVCxNQUFNLGVBQWUsQ0FBQztBQUN2QixPQUFPLEVBQUUsV0FBVyxFQUFFLE1BQU0seUJBQXlCLENBQUM7QUEwQ3RELE1BQU0sT0FBTyxRQUFRO0lBNEJqQixZQUFvQixVQUF1QjtRQUF2QixlQUFVLEdBQVYsVUFBVSxDQUFhO1FBMUJwQyxXQUFNLEdBQWtCLEVBQUUsQ0FBQztRQUMzQixVQUFLLEdBQVEsQ0FBQyxDQUFDO1FBQ2YsV0FBTSxHQUFZLEtBQUssQ0FBQztRQUV4QixpQkFBWSxHQUE4QixFQUFFLENBQUM7UUFFN0MsZ0JBQVcsR0FBdUIsRUFBRSxDQUFDO1FBRXBDLG1CQUFjLEdBQWtCO1lBQ3BDLFdBQVcsRUFBRSxZQUFZO1lBQ3pCLEtBQUssRUFBRSxLQUFLO1lBQ1osR0FBRyxFQUFFLEdBQUc7WUFDUixHQUFHLEVBQUUsQ0FBQztZQUNOLElBQUksRUFBRSxDQUFDO1lBQ1AsUUFBUSxFQUFFLEtBQUs7WUFDZixRQUFRLEVBQUUsS0FBSztZQUNmLFlBQVksRUFBRSxDQUFDO1NBQ2xCLENBQUM7UUFJYyxnQkFBVyxHQUFRLENBQUMsQ0FBQztRQUczQixXQUFNLEdBQXFCLElBQUksWUFBWSxFQUFFLENBQUM7SUFFVCxDQUFDO0lBRWhELFFBQVE7UUFDSixJQUFJLENBQUMsVUFBVSxDQUFDLElBQUksQ0FBQyxZQUFZLENBQUMsQ0FBQztRQUNuQyxJQUFJLENBQUMsS0FBSyxHQUFHLElBQUksQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLFdBQVcsRUFBRSxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUM7UUFDMUQsSUFBSSxDQUFDLFlBQVksR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDO1FBQy9CLElBQUksQ0FBQyxRQUFRLEdBQUcsT0FBTyxJQUFJLENBQUMsRUFBRSxLQUFLLFdBQVcsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDO1FBQ3BFLElBQUksQ0FBQyxRQUFRLEVBQUUsQ0FBQztJQUNwQixDQUFDO0lBRUQsV0FBVyxDQUFDLGNBQTZCO1FBQ3JDLElBQUksY0FBYyxDQUFDLGNBQWMsQ0FBQyxjQUFjLENBQUMsSUFBSSxDQUFDLGNBQWMsQ0FBQyxjQUFjLENBQUMsQ0FBQyxXQUFXLEVBQUU7WUFDOUYsSUFBSSxjQUFjLENBQUMsY0FBYyxDQUFDLENBQUMsWUFBWSxLQUFLLElBQUksQ0FBQyxNQUFNO2dCQUFFLE9BQU87WUFDeEUsSUFBSSxDQUFDLFVBQVUsQ0FBQyxjQUFjLENBQUMsY0FBYyxDQUFDLENBQUMsWUFBWSxDQUFDLENBQUM7U0FDaEU7UUFDRCxJQUFJLGNBQWMsQ0FBQyxjQUFjLENBQUMsYUFBYSxDQUFDLElBQUksQ0FBQyxjQUFjLENBQUMsYUFBYSxDQUFDLENBQUMsV0FBVyxFQUFFO1lBQzVGLElBQUksY0FBYyxDQUFDLGFBQWEsQ0FBQyxDQUFDLFlBQVksS0FBSyxJQUFJLENBQUMsS0FBSztnQkFBRSxPQUFPO1lBQ3RFLElBQUksQ0FBQyxLQUFLLEdBQUcsSUFBSSxDQUFDLFFBQVEsQ0FBQyxjQUFjLENBQUMsYUFBYSxDQUFDLENBQUMsWUFBWSxFQUFFLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQztZQUNwRixJQUFJLENBQUMsWUFBWSxHQUFHLElBQUksQ0FBQyxLQUFLLENBQUM7U0FDbEM7UUFDRCxJQUFJLGNBQWMsQ0FBQyxjQUFjLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxjQUFjLENBQUMsSUFBSSxDQUFDLENBQUMsV0FBVyxFQUFFO1lBQzFFLElBQUksY0FBYyxDQUFDLElBQUksQ0FBQyxDQUFDLFlBQVksS0FBSyxJQUFJLENBQUMsUUFBUTtnQkFBRSxPQUFPO1lBQ2hFLElBQUksQ0FBQyxRQUFRLEdBQUcsT0FBTyxjQUFjLENBQUMsSUFBSSxDQUFDLENBQUMsWUFBWSxLQUFLLFdBQVcsQ0FBQyxDQUFDLENBQUMsY0FBYyxDQUFDLElBQUksQ0FBQyxDQUFDLFlBQVksQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDO1NBQzNIO0lBQ0wsQ0FBQztJQUVELDBGQUEwRjtJQUNuRixlQUFlLENBQUMsT0FBa0Q7UUFDckU7Ozs7O1lBS0k7UUFDSixJQUFJLENBQUMsWUFBWSxHQUFHLElBQUksQ0FBQyxNQUFNLENBQUMsSUFBSSxJQUFJLElBQUksQ0FBQyxNQUFNLENBQUMsSUFBSSxLQUFLLFFBQVEsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLEtBQUssQ0FBQztRQUN2SSxJQUFJLE9BQU8sQ0FBQyxhQUFhLEtBQUssU0FBUztZQUFFLElBQUksQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxZQUFZLENBQUMsQ0FBQztRQUM3RSxJQUFJLENBQUMsY0FBYyxHQUFHLElBQUksQ0FBQyxVQUFVLENBQUMsaUJBQWlCLENBQUMsSUFBSSxDQUFDLFlBQVksRUFBRSxJQUFJLENBQUMsTUFBTSxDQUFDLG9CQUFvQixDQUFDLENBQUM7SUFDakgsQ0FBQztJQUVELHNCQUFzQjtJQUNmLFlBQVk7UUFDZixJQUFJLElBQUksQ0FBQyxNQUFNLENBQUMsUUFBUTtZQUFFLE9BQU87UUFDakMsSUFBSSxDQUFDLE1BQU0sR0FBRyxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQztJQUM3QyxDQUFDO0lBRUQsdURBQXVEO0lBQ2hELE9BQU8sQ0FBQyxJQUFhO1FBQ3hCLElBQUksQ0FBQyxNQUFNLEdBQUcsSUFBSSxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQztJQUN0QyxDQUFDO0lBR08sUUFBUTtRQUNaLElBQUksT0FBTyxJQUFJLENBQUMsR0FBRyxLQUFLLFdBQVcsRUFBRTtZQUNqQyxJQUFJLENBQUMsR0FBRyxDQUFDLE9BQU8sR0FBRyxDQUFDLEtBQWMsRUFBRSxFQUFFO2dCQUNsQyxJQUFJLENBQUMsTUFBTSxHQUFHLE1BQU0sQ0FBQyxNQUFNLENBQUMsRUFBRSxFQUFFLElBQUksQ0FBQyxNQUFNLEVBQUUsRUFBRSxRQUFRLEVBQUUsS0FBSyxFQUFFLENBQUMsQ0FBQztZQUN0RSxDQUFDLENBQUM7WUFDRixJQUFJLENBQUMsR0FBRyxDQUFDLG1CQUFtQixHQUFHLEdBQUcsRUFBRTtnQkFDaEMsT0FBTyxJQUFJLENBQUMsWUFBWSxDQUFDO1lBQzdCLENBQUMsQ0FBQztZQUNGLElBQUksQ0FBQyxHQUFHLENBQUMsbUJBQW1CLEdBQUcsQ0FBQyxNQUFXLEVBQUUsV0FBb0IsRUFBRSxFQUFFO2dCQUNqRSxJQUFJLGFBQWEsR0FBUSxNQUFNLENBQUM7Z0JBQ2hDLElBQUksS0FBSyxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsRUFBRTtvQkFDdkIsSUFBSSxPQUFPLFdBQVcsS0FBSyxXQUFXLEVBQUU7d0JBQ3BDLE9BQU8sQ0FBQyxHQUFHLENBQUMseURBQXlELENBQUMsQ0FBQzt3QkFDdkUsT0FBTztxQkFDVjtvQkFDRCxhQUFhLEdBQUcsTUFBTSxDQUFDLFdBQVcsQ0FBQyxDQUFDO2lCQUN2QztnQkFFRCxJQUFJLElBQUksQ0FBQyxNQUFNLENBQUMsSUFBSSxLQUFLLFFBQVEsRUFBRTtvQkFDL0IsS0FBSyxJQUFJLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxHQUFHLElBQUksQ0FBQyxXQUFXLENBQUMsTUFBTSxFQUFFLEVBQUUsQ0FBQyxFQUFFO3dCQUM5QyxJQUFJLElBQUksQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxLQUFLLE1BQU0sQ0FBQyxLQUFLLEVBQUU7NEJBQzVDLGFBQWEsR0FBRyxDQUFDLENBQUM7NEJBQ2xCLE1BQU07eUJBQ1Q7cUJBQ0o7aUJBQ0o7Z0JBRUQsSUFBSSxDQUFDLFdBQVcsQ0FBQyxXQUFXLENBQUMsYUFBYSxFQUFFLFdBQVcsQ0FBQyxDQUFDO1lBQzdELENBQUMsQ0FBQztTQUNMO0lBQ0wsQ0FBQztJQUVPLFVBQVUsQ0FBQyxPQUFPO1FBQ3RCLElBQUksQ0FBQyxNQUFNLEdBQUcsTUFBTSxDQUFDLE1BQU0sQ0FBQyxFQUFFLEVBQUUsSUFBSSxDQUFDLGNBQWMsRUFBRSxPQUFPLENBQUMsQ0FBQztRQUM5RCxJQUFJLElBQUksQ0FBQyxNQUFNLENBQUMsS0FBSztZQUFFLElBQUksQ0FBQyxZQUFZLEdBQUcsRUFBRSxPQUFPLEVBQUUsSUFBSSxDQUFDLE1BQU0sQ0FBQyxLQUFLLEVBQUUsQ0FBQztRQUMxRSxJQUFJLENBQUMsVUFBVSxDQUFDLE1BQU0sR0FBRyxJQUFJLENBQUMsTUFBTSxDQUFDO1FBQ3JDLElBQUksQ0FBQyxjQUFjLEdBQUcsSUFBSSxDQUFDLFVBQVUsQ0FBQyxpQkFBaUIsQ0FBQyxJQUFJLENBQUMsV0FBVyxFQUFFLElBQUksQ0FBQyxNQUFNLENBQUMsb0JBQW9CLENBQUMsQ0FBQztJQUNoSCxDQUFDO0lBRU8sUUFBUSxDQUFDLE1BQU0sRUFBRSxPQUFPO1FBRTVCLElBQUksT0FBTyxDQUFDLElBQUksS0FBSyxRQUFRLEVBQUU7WUFDM0IsSUFBSSxRQUFnQixDQUFDO1lBQ3JCLElBQUksQ0FBQyxNQUFNLENBQUMsR0FBRyxHQUFHLE9BQU8sQ0FBQyxPQUFPLENBQUMsTUFBTSxHQUFHLENBQUMsQ0FBQztZQUM3QyxJQUFJLENBQUMsTUFBTSxDQUFDLElBQUksR0FBRyxDQUFDLENBQUM7WUFDckIsSUFBSSxDQUFDLE1BQU0sQ0FBQyxHQUFHLEdBQUcsQ0FBQyxDQUFDO1lBQ3BCLElBQUksQ0FBQyxVQUFVLENBQUMsTUFBTSxHQUFHLElBQUksQ0FBQyxNQUFNLENBQUM7WUFFckMsS0FBSyxJQUFJLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxHQUFHLE9BQU8sQ0FBQyxPQUFPLENBQUMsTUFBTSxFQUFFLEVBQUUsQ0FBQyxFQUFFO2dCQUM3QyxJQUFJLE9BQU8sQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxLQUFLLE1BQU0sQ0FBQyxLQUFLLEVBQUU7b0JBQzNDLFFBQVEsR0FBRyxDQUFDLENBQUM7b0JBQ2IsTUFBTTtpQkFDVDthQUNKO1lBQ0QsT0FBTyxRQUFRLElBQUksQ0FBQyxDQUFDO1NBQ3hCO1FBRUQsSUFBSSxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLEVBQUU7WUFDeEIsSUFBSSxDQUFDLE1BQU0sQ0FBQyxLQUFLLEdBQUcsS0FBSyxDQUFDO1lBQzFCLElBQUksQ0FBQyxVQUFVLENBQUMsTUFBTSxHQUFHLElBQUksQ0FBQyxNQUFNLENBQUM7WUFDckMsT0FBTyxNQUFNLENBQUM7U0FDakI7UUFFRCxJQUFJLE9BQU8sQ0FBQyxLQUFLLEVBQUU7WUFDZixJQUFJLENBQUMsTUFBTSxDQUFDLFFBQVEsR0FBRyxLQUFLLENBQUM7WUFDN0IsSUFBSSxRQUFRLEdBQUcsTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDLEVBQUUsRUFBRSxFQUFFO2dCQUM3QixJQUFJLE9BQU8sRUFBRSxLQUFLLFFBQVE7b0JBQUUsRUFBRSxHQUFHLFVBQVUsQ0FBQyxFQUFFLENBQUMsQ0FBQztnQkFDaEQsT0FBTyxJQUFJLENBQUMsVUFBVSxDQUFDLEtBQUssQ0FBQyxFQUFFLEVBQUUsSUFBSSxDQUFDLE1BQU0sQ0FBQyxHQUFHLEVBQUUsSUFBSSxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsQ0FBQztZQUN2RSxDQUFDLENBQUMsQ0FBQztZQUNILE9BQU8sUUFBUSxDQUFDO1NBQ25CO1FBRUQsT0FBTyxDQUFDLENBQUM7SUFDYixDQUFDOzs7WUEzTEosU0FBUyxTQUFDO2dCQUNQLFFBQVEsRUFBRSxXQUFXO2dCQUNyQixRQUFRLEVBQUU7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7S0F5QlQ7Z0JBQ0QsU0FBUyxFQUFFLENBQUMsV0FBVyxDQUFDO2dCQUN4QixJQUFJLEVBQUU7b0JBQ0YsT0FBTyxFQUFFLFlBQVk7b0JBQ3JCLG9DQUFvQyxFQUFFLG1CQUFtQjtpQkFDNUQ7YUFDSjs7O1lBeENRLFdBQVc7OztpQkFnRWYsS0FBSzswQkFDTCxLQUFLLFNBQUMsT0FBTzsyQkFDYixLQUFLLFNBQUMsUUFBUTtrQkFDZCxLQUFLO3FCQUNMLE1BQU0iLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQge1xyXG4gICAgQ29tcG9uZW50LFxyXG4gICAgSW5wdXQsXHJcbiAgICBPbkluaXQsXHJcbiAgICBPbkNoYW5nZXMsXHJcbiAgICBTaW1wbGVDaGFuZ2VzLFxyXG4gICAgRXZlbnRFbWl0dGVyLFxyXG4gICAgT3V0cHV0LFxyXG59IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xyXG5pbXBvcnQgeyBLZFNsaWRlclN2YyB9IGZyb20gJy4va2QtYW5ndWxhci1zbGlkZXItc3ZjJztcclxuaW1wb3J0IHtcclxuICAgIElTbGlkZXJBcGksXHJcbiAgICBJU2xpZGVyQ29uZmlnLFxyXG4gICAgSVNsaWRlckFwaUludGVybmFsXHJcbn0gZnJvbSAnLi9rZC1hbmd1bGFyLXNsaWRlci1pbnRlcmZhY2UnO1xyXG5cclxuQENvbXBvbmVudCh7XHJcbiAgICBzZWxlY3RvcjogJ2tkLXNsaWRlcicsXHJcbiAgICB0ZW1wbGF0ZTogYFxyXG4gICAgICAgIDxkaXYgY2xhc3M9XCJrZHgtc2xpZGVyLXdyYXBwZXJcIiBbaWRdPVwic2xpZGVySWRcIiBbbmdTdHlsZV09XCJ3cmFwcGVyU3R5bGVcIj5cclxuICAgICAgICAgICAgPGRpdiBjbGFzcz1cImtkeC1zbGlkZXItY29udGFpbmVyXCIgW25nQ2xhc3NdPVwieydrZHgtc2xpZGVyLWNvbnRhaW5lci12ZXJ0aWNhbCc6IGNvbmZpZy5vcmllbnRhdGlvbiA9PT0gJ3ZlcnRpY2FsJ31cIj5cclxuICAgICAgICAgICAgICAgIDxidXR0b24gKm5nSWY9XCJjb25maWcuYXV0b3BsYXlcIiBjbGFzcz1cImJ0blwiIChjbGljayk9XCJjbGlja1BsYXlCdG4oKVwiIFthdHRyLmRpc2FibGVkXT1cImNvbmZpZy5kaXNhYmxlZD8gJyc6IG51bGxcIj5cclxuICAgICAgICAgICAgICAgICAgICA8aSBjbGFzcz1cInBsYXktaWNvbiBmYVwiIGFyaWEtaGlkZGVuPVwidHJ1ZVwiIFtuZ0NsYXNzXT1cInsnZmEtcGxheSc6ICFpc1BsYXksICdmYS1wYXVzZSc6IGlzUGxheX1cIj48L2k+XHJcbiAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICAgIDxrZC1zbGlkZXItY29udGVudCBbdmFsdWVdPVwidmFsdWVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFtjb25maWddPVwiY29uZmlnXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBbaXNQbGF5XT1cImlzUGxheVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgW2FwaV09XCJhcGlJbnRlcm5hbFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKGVuZFBsYXkpPVwiZW5kUGxheSgkZXZlbnQpXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAocmVzdWx0KT1cImVtaXRDaGFuZ2VFdmVudCgkZXZlbnQpXCI+XHJcbiAgICAgICAgICAgICAgICA8L2tkLXNsaWRlci1jb250ZW50PlxyXG4gICAgICAgICAgICAgICAgPGRpdiAqbmdJZj1cImNvbmZpZy5zaWRlVmFsdWVMYWJlbFwiIGNsYXNzPVwic2lkZS12YWx1ZS1sYWJlbCBrZHgtbGFiZWxcIj57e3NpZGVWYWx1ZUxhYmVsfX08L2Rpdj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDxkaXYgKm5nSWY9XCJjb25maWcuc3RhcnRMYWJlbFwiIGNsYXNzPVwia2R4LWxhYmVsLWNvbnRhaW5lclwiPlxyXG4gICAgICAgICAgICAgICAgPGRpdiAqbmdJZj1cImNvbmZpZy5zdGFydExhYmVsXCIgY2xhc3M9XCJrZHgtbGFiZWxcIiA+XHJcbiAgICAgICAgICAgICAgICAgICAge3tjb25maWcuc3RhcnRMYWJlbH19XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDxkaXYgKm5nSWY9XCJjb25maWcuZW5kTGFiZWxcIiBjbGFzcz1cImtkeC1sYWJlbFwiID5cclxuICAgICAgICAgICAgICAgICAgICB7e2NvbmZpZy5lbmRMYWJlbH19XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgPG5nLWNvbnRlbnQ+PC9uZy1jb250ZW50PlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgYCxcclxuICAgIHByb3ZpZGVyczogW0tkU2xpZGVyU3ZjXSxcclxuICAgIGhvc3Q6IHtcclxuICAgICAgICAnY2xhc3MnOiAna2R4LXNsaWRlcicsXHJcbiAgICAgICAgJ1tjbGFzcy5rZHgtc2xpZGVyLWhhcy1zdGFydC1sYWJlbF0nOiAnY29uZmlnLnN0YXJ0TGFiZWwnLFxyXG4gICAgfVxyXG59KVxyXG5cclxuZXhwb3J0IGNsYXNzIEtkU2xpZGVyIGltcGxlbWVudHMgT25Jbml0LCBPbkNoYW5nZXMge1xyXG5cclxuICAgIHB1YmxpYyBjb25maWc6IElTbGlkZXJDb25maWcgPSB7fTtcclxuICAgIHB1YmxpYyB2YWx1ZTogYW55ID0gMDtcclxuICAgIHB1YmxpYyBpc1BsYXk6IGJvb2xlYW4gPSBmYWxzZTtcclxuICAgIHB1YmxpYyBzbGlkZXJJZDogc3RyaW5nO1xyXG4gICAgcHVibGljIHdyYXBwZXJTdHlsZTogeyBba2V5OiBzdHJpbmddOiBzdHJpbmcgfSA9IHt9O1xyXG4gICAgcHVibGljIHNpZGVWYWx1ZUxhYmVsOiBzdHJpbmcgfCBudW1iZXI7XHJcbiAgICBwdWJsaWMgYXBpSW50ZXJuYWw6IElTbGlkZXJBcGlJbnRlcm5hbCA9IHt9O1xyXG5cclxuICAgIHByaXZhdGUgX2RlZmF1bHRDb25maWc6IElTbGlkZXJDb25maWcgPSB7XHJcbiAgICAgICAgb3JpZW50YXRpb246ICdob3Jpem9udGFsJyxcclxuICAgICAgICByYW5nZTogZmFsc2UsXHJcbiAgICAgICAgbWF4OiAxMDAsXHJcbiAgICAgICAgbWluOiAwLFxyXG4gICAgICAgIHN0ZXA6IDEsXHJcbiAgICAgICAgZGlzYWJsZWQ6IGZhbHNlLFxyXG4gICAgICAgIGF1dG9wbGF5OiBmYWxzZSxcclxuICAgICAgICBhdXRvcGxheVN0ZXA6IDEsXHJcbiAgICB9O1xyXG4gICAgcHJpdmF0ZSBfb3V0cHV0VmFsdWU6IGFueTtcclxuXHJcbiAgICBASW5wdXQoKSBpZDogc3RyaW5nO1xyXG4gICAgQElucHV0KCd2YWx1ZScpIHNsaWRlclZhbHVlOiBhbnkgPSAwO1xyXG4gICAgQElucHV0KCdjb25maWcnKSBzbGlkZXJDb25maWc6IElTbGlkZXJDb25maWc7XHJcbiAgICBASW5wdXQoKSBhcGk6IElTbGlkZXJBcGk7XHJcbiAgICBAT3V0cHV0KCkgcmVzdWx0OiBFdmVudEVtaXR0ZXI8e30+ID0gbmV3IEV2ZW50RW1pdHRlcigpO1xyXG5cclxuICAgIGNvbnN0cnVjdG9yKHByaXZhdGUgX3NsaWRlclN2YzogS2RTbGlkZXJTdmMpIHsgfVxyXG5cclxuICAgIG5nT25Jbml0KCk6IHZvaWQge1xyXG4gICAgICAgIHRoaXMuX3NldENvbmZpZyh0aGlzLnNsaWRlckNvbmZpZyk7XHJcbiAgICAgICAgdGhpcy52YWx1ZSA9IHRoaXMuX3NldERhdGEodGhpcy5zbGlkZXJWYWx1ZSwgdGhpcy5jb25maWcpO1xyXG4gICAgICAgIHRoaXMuX291dHB1dFZhbHVlID0gdGhpcy52YWx1ZTtcclxuICAgICAgICB0aGlzLnNsaWRlcklkID0gdHlwZW9mIHRoaXMuaWQgIT09ICd1bmRlZmluZWQnID8gdGhpcy5pZCA6ICdzbGlkZXInO1xyXG4gICAgICAgIHRoaXMuX2luaXRBcGkoKTtcclxuICAgIH1cclxuXHJcbiAgICBuZ09uQ2hhbmdlcyhfc2ltcGxlQ2hhbmdlczogU2ltcGxlQ2hhbmdlcyk6IHZvaWQge1xyXG4gICAgICAgIGlmIChfc2ltcGxlQ2hhbmdlcy5oYXNPd25Qcm9wZXJ0eSgnc2xpZGVyQ29uZmlnJykgJiYgIV9zaW1wbGVDaGFuZ2VzWydzbGlkZXJDb25maWcnXS5maXJzdENoYW5nZSkge1xyXG4gICAgICAgICAgICBpZiAoX3NpbXBsZUNoYW5nZXNbJ3NsaWRlckNvbmZpZyddLmN1cnJlbnRWYWx1ZSA9PT0gdGhpcy5jb25maWcpIHJldHVybjtcclxuICAgICAgICAgICAgdGhpcy5fc2V0Q29uZmlnKF9zaW1wbGVDaGFuZ2VzWydzbGlkZXJDb25maWcnXS5jdXJyZW50VmFsdWUpO1xyXG4gICAgICAgIH1cclxuICAgICAgICBpZiAoX3NpbXBsZUNoYW5nZXMuaGFzT3duUHJvcGVydHkoJ3NsaWRlclZhbHVlJykgJiYgIV9zaW1wbGVDaGFuZ2VzWydzbGlkZXJWYWx1ZSddLmZpcnN0Q2hhbmdlKSB7XHJcbiAgICAgICAgICAgIGlmIChfc2ltcGxlQ2hhbmdlc1snc2xpZGVyVmFsdWUnXS5jdXJyZW50VmFsdWUgPT09IHRoaXMudmFsdWUpIHJldHVybjtcclxuICAgICAgICAgICAgdGhpcy52YWx1ZSA9IHRoaXMuX3NldERhdGEoX3NpbXBsZUNoYW5nZXNbJ3NsaWRlclZhbHVlJ10uY3VycmVudFZhbHVlLCB0aGlzLmNvbmZpZyk7XHJcbiAgICAgICAgICAgIHRoaXMuX291dHB1dFZhbHVlID0gdGhpcy52YWx1ZTtcclxuICAgICAgICB9XHJcbiAgICAgICAgaWYgKF9zaW1wbGVDaGFuZ2VzLmhhc093blByb3BlcnR5KCdpZCcpICYmICFfc2ltcGxlQ2hhbmdlc1snaWQnXS5maXJzdENoYW5nZSkge1xyXG4gICAgICAgICAgICBpZiAoX3NpbXBsZUNoYW5nZXNbJ2lkJ10uY3VycmVudFZhbHVlID09PSB0aGlzLnNsaWRlcklkKSByZXR1cm47XHJcbiAgICAgICAgICAgIHRoaXMuc2xpZGVySWQgPSB0eXBlb2YgX3NpbXBsZUNoYW5nZXNbJ2lkJ10uY3VycmVudFZhbHVlICE9PSAndW5kZWZpbmVkJyA/IF9zaW1wbGVDaGFuZ2VzWydpZCddLmN1cnJlbnRWYWx1ZSA6ICdzbGlkZXInO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICAvKiogRW1pdHMgYSBjaGFuZ2UgZXZlbnQgaWYgdGhlIGN1cnJlbnQgdmFsdWUgaXMgZGlmZmVyZW50IGZyb20gdGhlIGxhc3QgZW1pdHRlZCB2YWx1ZS4gKi9cclxuICAgIHB1YmxpYyBlbWl0Q2hhbmdlRXZlbnQoX3Jlc3VsdDogeyB2YWx1ZTogYW55LCBjdXJyZW50QWN0aW9uPzogJ3NsaWRpbmcnIH0pOiB2b2lkIHtcclxuICAgICAgICAvKip0eXBlID09PSBudW1iZXIgfCBBcnJheTxudW1iZXI+IHwgT2JqZWN0IHdpdGggYXQgbGVhc3QgdGhlIGZvbGxvd2luZyBwcm9wZXJ0aWVzOlxyXG4gICAgICAgICoge1xyXG4gICAgICAgICogICBkZXNjcmlwdGlvbj86IHN0cmluZztcclxuICAgICAgICAqICAgdmFsdWU6IHN0cmluZyB8IG51bWJlcjtcclxuICAgICAgICAqIH1cclxuICAgICAgICAqICovXHJcbiAgICAgICAgdGhpcy5fb3V0cHV0VmFsdWUgPSB0aGlzLmNvbmZpZy50eXBlICYmIHRoaXMuY29uZmlnLnR5cGUgPT09ICdvdGhlcnMnID8gdGhpcy5jb25maWcub3B0aW9uc1tNYXRoLnJvdW5kKF9yZXN1bHQudmFsdWUpXSA6IF9yZXN1bHQudmFsdWU7XHJcbiAgICAgICAgaWYgKF9yZXN1bHQuY3VycmVudEFjdGlvbiAhPT0gJ3NsaWRpbmcnKSB0aGlzLnJlc3VsdC5lbWl0KHRoaXMuX291dHB1dFZhbHVlKTtcclxuICAgICAgICB0aGlzLnNpZGVWYWx1ZUxhYmVsID0gdGhpcy5fc2xpZGVyU3ZjLnNldFNpZGVWYWx1ZUxhYmVsKHRoaXMuX291dHB1dFZhbHVlLCB0aGlzLmNvbmZpZy5zaWRlVmFsdWVMYWJlbEZvcm1hdCk7XHJcbiAgICB9XHJcblxyXG4gICAgLyoqIFRvZ2dsZSBhdXRvcGxheSAqL1xyXG4gICAgcHVibGljIGNsaWNrUGxheUJ0bigpOiB2b2lkIHtcclxuICAgICAgICBpZiAodGhpcy5jb25maWcuZGlzYWJsZWQpIHJldHVybjtcclxuICAgICAgICB0aGlzLmlzUGxheSA9IHRoaXMuaXNQbGF5ID8gZmFsc2UgOiB0cnVlO1xyXG4gICAgfVxyXG5cclxuICAgIC8qKiBVcGRhdGUgdGhpcy5pc1BsYXkgd2hlbiBlbmQgb2Ygc2xpZGVyIGlzIHJlYWNoZWQgKi9cclxuICAgIHB1YmxpYyBlbmRQbGF5KF9lbmQ6IGJvb2xlYW4pOiB2b2lkIHtcclxuICAgICAgICB0aGlzLmlzUGxheSA9IF9lbmQgPyBmYWxzZSA6IHRydWU7XHJcbiAgICB9XHJcblxyXG5cclxuICAgIHByaXZhdGUgX2luaXRBcGkoKTogdm9pZCB7XHJcbiAgICAgICAgaWYgKHR5cGVvZiB0aGlzLmFwaSAhPT0gJ3VuZGVmaW5lZCcpIHtcclxuICAgICAgICAgICAgdGhpcy5hcGkuZGlzYWJsZSA9IChfZmxhZzogYm9vbGVhbikgPT4ge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5jb25maWcgPSBPYmplY3QuYXNzaWduKHt9LCB0aGlzLmNvbmZpZywgeyBkaXNhYmxlZDogX2ZsYWcgfSk7XHJcbiAgICAgICAgICAgIH07XHJcbiAgICAgICAgICAgIHRoaXMuYXBpLmdldFNsaWRlclRodW1iVmFsdWUgPSAoKSA9PiB7XHJcbiAgICAgICAgICAgICAgICByZXR1cm4gdGhpcy5fb3V0cHV0VmFsdWU7XHJcbiAgICAgICAgICAgIH07XHJcbiAgICAgICAgICAgIHRoaXMuYXBpLnNldFNsaWRlclRodW1iVmFsdWUgPSAoX3ZhbHVlOiBhbnksIF90aHVtYkluZGV4PzogbnVtYmVyKSA9PiB7XHJcbiAgICAgICAgICAgICAgICBsZXQgdmFsdWVUb1VwZGF0ZTogYW55ID0gX3ZhbHVlO1xyXG4gICAgICAgICAgICAgICAgaWYgKEFycmF5LmlzQXJyYXkoX3ZhbHVlKSkge1xyXG4gICAgICAgICAgICAgICAgICAgIGlmICh0eXBlb2YgX3RodW1iSW5kZXggPT09ICd1bmRlZmluZWQnKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKCdwbGVhc2UgcGFzcyB0aGUgX3RodW1iSW5kZXggb2Ygd2hpY2ggdG8gdXBkYXRlIHZhbHVlIHRvJyk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybjtcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgdmFsdWVUb1VwZGF0ZSA9IF92YWx1ZVtfdGh1bWJJbmRleF07XHJcbiAgICAgICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICAgICAgaWYgKHRoaXMuY29uZmlnLnR5cGUgPT09ICdvdGhlcnMnKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgZm9yIChsZXQgaSA9IDA7IGkgPCB0aGlzLnNsaWRlclZhbHVlLmxlbmd0aDsgKytpKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGlmICh0aGlzLnNsaWRlclZhbHVlW2ldLnZhbHVlID09PSBfdmFsdWUudmFsdWUpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlVG9VcGRhdGUgPSBpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICAgICAgdGhpcy5hcGlJbnRlcm5hbC5oYW5kbGVWYWx1ZSh2YWx1ZVRvVXBkYXRlLCBfdGh1bWJJbmRleCk7XHJcbiAgICAgICAgICAgIH07XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX3NldENvbmZpZyhfY29uZmlnKTogdm9pZCB7XHJcbiAgICAgICAgdGhpcy5jb25maWcgPSBPYmplY3QuYXNzaWduKHt9LCB0aGlzLl9kZWZhdWx0Q29uZmlnLCBfY29uZmlnKTtcclxuICAgICAgICBpZiAodGhpcy5jb25maWcud2lkdGgpIHRoaXMud3JhcHBlclN0eWxlID0geyAnd2lkdGgnOiB0aGlzLmNvbmZpZy53aWR0aCB9O1xyXG4gICAgICAgIHRoaXMuX3NsaWRlclN2Yy5jb25maWcgPSB0aGlzLmNvbmZpZztcclxuICAgICAgICB0aGlzLnNpZGVWYWx1ZUxhYmVsID0gdGhpcy5fc2xpZGVyU3ZjLnNldFNpZGVWYWx1ZUxhYmVsKHRoaXMuc2xpZGVyVmFsdWUsIHRoaXMuY29uZmlnLnNpZGVWYWx1ZUxhYmVsRm9ybWF0KTtcclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF9zZXREYXRhKF92YWx1ZSwgX2NvbmZpZyk6IEFycmF5PG51bWJlcj4gfCBudW1iZXIge1xyXG5cclxuICAgICAgICBpZiAoX2NvbmZpZy50eXBlID09PSAnb3RoZXJzJykge1xyXG4gICAgICAgICAgICBsZXQgbmV3VmFsdWU6IG51bWJlcjtcclxuICAgICAgICAgICAgdGhpcy5jb25maWcubWF4ID0gX2NvbmZpZy5vcHRpb25zLmxlbmd0aCAtIDE7XHJcbiAgICAgICAgICAgIHRoaXMuY29uZmlnLnN0ZXAgPSAxO1xyXG4gICAgICAgICAgICB0aGlzLmNvbmZpZy5taW4gPSAwO1xyXG4gICAgICAgICAgICB0aGlzLl9zbGlkZXJTdmMuY29uZmlnID0gdGhpcy5jb25maWc7XHJcblxyXG4gICAgICAgICAgICBmb3IgKGxldCBpID0gMDsgaSA8IF9jb25maWcub3B0aW9ucy5sZW5ndGg7ICsraSkge1xyXG4gICAgICAgICAgICAgICAgaWYgKF9jb25maWcub3B0aW9uc1tpXS52YWx1ZSA9PT0gX3ZhbHVlLnZhbHVlKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgbmV3VmFsdWUgPSBpO1xyXG4gICAgICAgICAgICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIHJldHVybiBuZXdWYWx1ZSB8fCAwO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgaWYgKCFBcnJheS5pc0FycmF5KF92YWx1ZSkpIHtcclxuICAgICAgICAgICAgdGhpcy5jb25maWcucmFuZ2UgPSBmYWxzZTtcclxuICAgICAgICAgICAgdGhpcy5fc2xpZGVyU3ZjLmNvbmZpZyA9IHRoaXMuY29uZmlnO1xyXG4gICAgICAgICAgICByZXR1cm4gX3ZhbHVlO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgaWYgKF9jb25maWcucmFuZ2UpIHtcclxuICAgICAgICAgICAgdGhpcy5jb25maWcuYXV0b3BsYXkgPSBmYWxzZTtcclxuICAgICAgICAgICAgbGV0IG5ld1ZhbHVlID0gX3ZhbHVlLm1hcCgoZWwpID0+IHtcclxuICAgICAgICAgICAgICAgIGlmICh0eXBlb2YgZWwgIT09ICdudW1iZXInKSBlbCA9IHBhcnNlRmxvYXQoZWwpO1xyXG4gICAgICAgICAgICAgICAgcmV0dXJuIHRoaXMuX3NsaWRlclN2Yy5jbGFtcChlbCwgdGhpcy5jb25maWcubWluLCB0aGlzLmNvbmZpZy5tYXgpO1xyXG4gICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgcmV0dXJuIG5ld1ZhbHVlO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgcmV0dXJuIDA7XHJcbiAgICB9XHJcbn1cclxuIl19