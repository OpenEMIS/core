import { Injectable } from '@angular/core';
export class KdLoginSvc {
    getHeaderConfigValues(_config, _defaultConfig) {
        let updateHeaderConfig = {};
        if (typeof _config === 'undefined' || typeof _config.header === 'undefined') {
            if (typeof _defaultConfig !== 'undefined')
                updateHeaderConfig = JSON.parse(JSON.stringify(_defaultConfig));
            else
                updateHeaderConfig = { icon: 'kd-openemis', title: 'OpenEMIS' };
        }
        else {
            updateHeaderConfig = _config.header;
            if (typeof updateHeaderConfig.img !== 'undefined' && typeof updateHeaderConfig.icon !== 'undefined')
                updateHeaderConfig.img = '';
            if (typeof updateHeaderConfig.img === 'undefined' && typeof updateHeaderConfig.icon === 'undefined')
                updateHeaderConfig.icon = '';
            if (typeof updateHeaderConfig.icon !== 'undefined' && typeof updateHeaderConfig.title === 'undefined')
                updateHeaderConfig.title = '';
            if (typeof updateHeaderConfig.img !== 'undefined' && typeof updateHeaderConfig.imgSize === 'undefined')
                updateHeaderConfig.imgSize = 'none';
            if (typeof updateHeaderConfig.headerMsg !== 'undefined' && typeof updateHeaderConfig.headerMsg === 'undefined')
                updateHeaderConfig.headerMsg = '';
        }
        return this._setProductAppConfig(updateHeaderConfig);
    }
    /*
        set default language config
            - if config is undefined, langunage undefined, show undefined - return default
                - if config list is defined, list got item, and show is true - set config to show with toggle
                - else if config default is defined - set config with default language and toggle false
        - return config
     */
    getLanguageConfigValues(_config) {
        if (_config.hasOwnProperty('language') && _config.language.hasOwnProperty('options')) {
            return _config.language.options;
        }
        return this.getSixDefaultLanguage();
    }
    getLangageDefaultValue(_config) {
        let returnVal = 'en';
        if (_config.hasOwnProperty('language') && _config.language.hasOwnProperty('value')) {
            return _config.language.value;
        }
        return returnVal;
    }
    getSixDefaultLanguage() {
        let defaultList = [
            {
                value: 'العربية', key: 'ar', dir: 'rtl'
            }, {
                value: '中文', key: 'zh', dir: 'ltr'
            }, {
                value: 'English', key: 'en', dir: 'ltr'
            }, {
                value: 'Français', key: 'fr', dir: 'ltr'
            }, {
                value: 'русский', key: 'ru', dir: 'ltr'
            }, {
                value: 'español', key: 'es', dir: 'ltr'
            } //,
            // value: 'en'
        ];
        return defaultList;
    }
    updateLanguageDir(_config, _selectedIndex) {
        // console.log('Parent svc run: ' + _selectedIndex);
        let langOptions = this.getLanguageConfigValues(_config);
        let dir = this.checkLanguageDir(langOptions, _selectedIndex);
        // console.log('Return this: ' + dir);
        return dir;
    }
    checkLanguageDir(_langOptions, _selectedIndex) {
        for (let i = 0; i < _langOptions.length; i++) {
            if (_langOptions[i].key === _selectedIndex) {
                // console.log('Detected this: ' + _langOptions[i].dir);
                return _langOptions[i].dir;
            }
        }
    }
    getFormInputs(_type, _config) {
        let formInputs = [];
        switch (_type) {
            case "reset-password":
                formInputs = [
                    {
                        'key': 'newpassword',
                        'label': 'Confirm Password',
                        'class': 'input',
                        'iconClass': 'fa fa-key iconSizeS',
                        'controlType': 'password',
                        'type': 'password',
                        'value': ''
                    },
                    {
                        'key': 'confirmpassword',
                        'label': 'New Password',
                        'class': 'input',
                        'iconClass': 'fa fa-key iconSizeS',
                        'controlType': 'password',
                        'type': 'password',
                        'value': ''
                    }
                ];
                break;
            case "forget-username":
                formInputs = [
                    {
                        'key': 'useremail',
                        'label': 'Email',
                        'class': 'input',
                        'iconClass': 'fa fa-envelope-o iconSizeS',
                        'controlType': 'textbox',
                        'value': ''
                    }
                ];
                break;
            case "forget-password":
                formInputs = [
                    {
                        'key': 'userinput',
                        'label': 'User Name or Email',
                        'class': 'input',
                        'iconClass': 'fa fa-user',
                        'controlType': 'textbox',
                        'value': ''
                    }
                    // {
                    //     'key': 'useremail',
                    //     'label': 'Email',
                    //     'class': 'input email',
                    //     'controlType': 'textbox',
                    //     'value': ''
                    // }
                ];
                break;
            case "only-otp":
                formInputs = [
                    {
                        'key': 'userOTP',
                        'label': 'OTP',
                        'class': 'input',
                        'iconClass': 'fa fa-key iconSizeS',
                        'controlType': 'password',
                        'type': 'password',
                        'value': (_config === null || _config === void 0 ? void 0 : _config.value) ? _config === null || _config === void 0 ? void 0 : _config.value : ''
                    }
                ];
                break;
            default:
                formInputs = [
                    {
                        'key': 'username',
                        'label': 'User Name',
                        'class': 'input',
                        'iconClass': 'fa fa-user',
                        'controlType': 'text',
                        'value': ''
                    },
                    {
                        'key': 'password',
                        'label': 'Password',
                        'class': 'input',
                        'iconClass': 'fa fa-key iconSizeS',
                        'controlType': 'text',
                        'type': 'password',
                        'value': ''
                    },
                    {
                        'key': 'language',
                        'class': 'kdx-input-select-wrapper',
                        'iconClass': 'fa fa-globe',
                        'value': _config.value,
                        'options': _config.options,
                        'controlType': 'dropdown'
                    }
                ];
                break;
        }
        return formInputs;
    }
    getButtonLabel(_type, _label) {
        let tempLabel = "Submit";
        switch (_type) {
            case "reset-password":
                if (typeof _label !== 'undefined')
                    tempLabel = _label;
                else
                    tempLabel = 'Update Password';
                break;
            case "forget-username":
                if (typeof _label !== 'undefined')
                    tempLabel = _label;
                else
                    tempLabel = 'Recover Username';
                break;
            case "forget-password":
                if (typeof _label !== 'undefined')
                    tempLabel = _label;
                else
                    tempLabel = 'Reset Password';
                break;
            default:
                if (typeof _label !== 'undefined')
                    tempLabel = _label;
                else
                    tempLabel = 'Login';
                break;
        }
        return tempLabel;
    }
    getFormLinks(_config, _type) {
        let returnData = [];
        let defaultLink = this.getDefaultFormLinks(_type);
        switch (_type) {
            case "reset-password":
                returnData.push(Object.assign(defaultLink.back, _config.formLinks.back));
                break;
            case "forget-username":
                returnData.push(Object.assign(defaultLink.back, _config.formLinks.back));
                break;
            case "forget-password":
                returnData.push(Object.assign(defaultLink.back, _config.formLinks.back));
                break;
            default:
                if (_config.formLinks && _config.formLinks.forgetPassword)
                    returnData.push(Object.assign(defaultLink.forgetPassword, _config.formLinks.forgetPassword));
                if (_config.formLinks && _config.formLinks.forgetUser)
                    returnData.push(Object.assign(defaultLink.forgetUser, _config.formLinks.forgetUser));
                break;
        }
        return returnData;
        // if (_config.hasOwnProperty('formLinks') && _config.formLinks.hasOwnProperty(_linkType) && _config.formLinks[_linkType].hasOwnProperty('path')) {
        //     //return _config.formLinks.forgetPassword.path;
        //     let forgetPassword: any = {
        //         path: _config.formLinks.forgetPassword.path
        //     }
        // return forgetPassword;
        // }
    }
    getDefaultFormLinks(_type) {
        let returnData = {};
        switch (_type) {
            case "reset-password":
                returnData = {
                    back: {
                        label: 'Back to login?'
                    }
                };
                break;
            case "forget-username":
                returnData = {
                    back: {
                        label: 'Back to login?'
                    }
                };
                break;
            case "forget-password":
                returnData = {
                    back: {
                        label: 'Back to login?'
                    }
                };
                break;
            default:
                returnData = {
                    forgetPassword: {
                        label: 'Forget Password?'
                    },
                    forgetUser: {
                        label: 'Forget Username?'
                    }
                };
                break;
        }
        return returnData;
    }
    // public getFormAlerts(_config: ILoginConfig, _type: string): IFormAlertConfig | boolean {
    //     if (_config.hasOwnProperty('alert') && _config.alert.hasOwnProperty('errorMsg')) {
    //         let returnData: IFormAlertConfig = JSON.parse(JSON.stringify(_config.alert));
    //         if (!_config.alert.hasOwnProperty('successMsg') && _type !== 'login') {
    //             returnData['successMsg'] = 'An email will be send shortly. Please check your mailbox.';
    //         }
    //         return returnData;
    //     }
    //     return false;
    // }
    // public setAlertMessage(_value: string, _formAlerts: any): string {
    //     let returnVal: string;
    //     if (_value === 'success') {
    //         returnVal = _formAlerts.successMsg;
    //     } else if (_value === 'danger') {
    //         returnVal = _formAlerts.errorMsg;
    //     }
    //     return returnVal;
    // }
    _setProductAppConfig(_updateHeaderConfig) {
        // let tempHeaderConfig:any = _updateHeaderConfig;
        try {
            if (APP_CONFIGS.hasOwnProperty('product')) {
                let type = (APP_CONFIGS.product.hasOwnProperty('type')) ? APP_CONFIGS.product.type : 'icon';
                if (APP_CONFIGS.product.hasOwnProperty('name')) {
                    _updateHeaderConfig.title = APP_CONFIGS.product.name;
                }
                if (APP_CONFIGS.product.hasOwnProperty('src')) {
                    switch (type) {
                        case 'icon':
                            _updateHeaderConfig.icon = APP_CONFIGS.product.src;
                            break;
                        case 'image':
                            _updateHeaderConfig.img = APP_CONFIGS.product.src;
                            break;
                        default:
                            break;
                    }
                }
            }
        }
        catch (err) {
            // console.log(err);
        }
        return _updateHeaderConfig;
    }
    getLogoSizeClass(headerConfig) {
        if (typeof headerConfig.imgSize !== 'undefined')
            return headerConfig.imgSize;
        if (typeof headerConfig.img !== 'undefined' && typeof headerConfig.title === 'undefined')
            return 'full';
        return 'small';
    }
    getDemoLogin(requestString) {
        let tempString = requestString.replace(' ', '');
        let splitString = tempString.split(',');
        let demoInfo = {};
        if (splitString.length === 2) {
            demoInfo = {
                user: splitString[0],
                pass: splitString[1]
            };
        }
        return demoInfo;
    }
}
KdLoginSvc.decorators = [
    { type: Injectable }
];
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoia2QtYW5ndWxhci1sb2dpbi1zdmMuanMiLCJzb3VyY2VSb290IjoiQzovUHJvamVjdHMvQW5ndWxhci9pb3N0Zy1vcGVuZW1pcy1zdHlsZWd1aWRlL3Byb2plY3RzL29wZW5lbWlzLXN0eWxlZ3VpZGUtbGliL3NyYy8iLCJzb3VyY2VzIjpbImtkLWNvbXBvbmVudHMva2QtYW5ndWxhci1sb2dpbi9rZC1hbmd1bGFyLWxvZ2luLXN2Yy50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQSxPQUFPLEVBQUUsVUFBVSxFQUFhLE1BQU0sZUFBZSxDQUFDO0FBY3RELE1BQU0sT0FBTyxVQUFVO0lBSVoscUJBQXFCLENBQUMsT0FBWSxFQUFFLGNBQW1CO1FBQzFELElBQUksa0JBQWtCLEdBQVEsRUFBRSxDQUFDO1FBQ2pDLElBQUksT0FBTyxPQUFPLEtBQUssV0FBVyxJQUFJLE9BQU8sT0FBTyxDQUFDLE1BQU0sS0FBSyxXQUFXLEVBQUU7WUFDekUsSUFBSSxPQUFPLGNBQWMsS0FBSyxXQUFXO2dCQUFFLGtCQUFrQixHQUFHLElBQUksQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxjQUFjLENBQUMsQ0FBQyxDQUFDOztnQkFDdEcsa0JBQWtCLEdBQUcsRUFBRSxJQUFJLEVBQUUsYUFBYSxFQUFFLEtBQUssRUFBRSxVQUFVLEVBQUUsQ0FBQztTQUN4RTthQUNJO1lBQ0Qsa0JBQWtCLEdBQUcsT0FBTyxDQUFDLE1BQU0sQ0FBQztZQUNwQyxJQUFJLE9BQU8sa0JBQWtCLENBQUMsR0FBRyxLQUFLLFdBQVcsSUFBSSxPQUFPLGtCQUFrQixDQUFDLElBQUksS0FBSyxXQUFXO2dCQUFFLGtCQUFrQixDQUFDLEdBQUcsR0FBRyxFQUFFLENBQUM7WUFDakksSUFBSSxPQUFPLGtCQUFrQixDQUFDLEdBQUcsS0FBSyxXQUFXLElBQUksT0FBTyxrQkFBa0IsQ0FBQyxJQUFJLEtBQUssV0FBVztnQkFBRSxrQkFBa0IsQ0FBQyxJQUFJLEdBQUcsRUFBRSxDQUFDO1lBQ2xJLElBQUksT0FBTyxrQkFBa0IsQ0FBQyxJQUFJLEtBQUssV0FBVyxJQUFJLE9BQU8sa0JBQWtCLENBQUMsS0FBSyxLQUFLLFdBQVc7Z0JBQUUsa0JBQWtCLENBQUMsS0FBSyxHQUFHLEVBQUUsQ0FBQztZQUNySSxJQUFJLE9BQU8sa0JBQWtCLENBQUMsR0FBRyxLQUFLLFdBQVcsSUFBSSxPQUFPLGtCQUFrQixDQUFDLE9BQU8sS0FBSyxXQUFXO2dCQUFFLGtCQUFrQixDQUFDLE9BQU8sR0FBRyxNQUFNLENBQUM7WUFDNUksSUFBSSxPQUFPLGtCQUFrQixDQUFDLFNBQVMsS0FBSyxXQUFXLElBQUksT0FBTyxrQkFBa0IsQ0FBQyxTQUFTLEtBQUssV0FBVztnQkFBRSxrQkFBa0IsQ0FBQyxTQUFTLEdBQUcsRUFBRSxDQUFDO1NBQ3JKO1FBRUQsT0FBTyxJQUFJLENBQUMsb0JBQW9CLENBQUMsa0JBQWtCLENBQUMsQ0FBQztJQUN6RCxDQUFDO0lBRUQ7Ozs7OztPQU1HO0lBQ0ksdUJBQXVCLENBQUMsT0FBcUI7UUFDaEQsSUFBSSxPQUFPLENBQUMsY0FBYyxDQUFDLFVBQVUsQ0FBQyxJQUFJLE9BQU8sQ0FBQyxRQUFRLENBQUMsY0FBYyxDQUFDLFNBQVMsQ0FBQyxFQUFFO1lBQ2xGLE9BQU8sT0FBTyxDQUFDLFFBQVEsQ0FBQyxPQUFPLENBQUM7U0FDbkM7UUFFRCxPQUFPLElBQUksQ0FBQyxxQkFBcUIsRUFBRSxDQUFDO0lBQ3hDLENBQUM7SUFFTSxzQkFBc0IsQ0FBQyxPQUFxQjtRQUMvQyxJQUFJLFNBQVMsR0FBVyxJQUFJLENBQUM7UUFDN0IsSUFBSSxPQUFPLENBQUMsY0FBYyxDQUFDLFVBQVUsQ0FBQyxJQUFJLE9BQU8sQ0FBQyxRQUFRLENBQUMsY0FBYyxDQUFDLE9BQU8sQ0FBQyxFQUFFO1lBQ2hGLE9BQU8sT0FBTyxDQUFDLFFBQVEsQ0FBQyxLQUFLLENBQUM7U0FDakM7UUFFRCxPQUFPLFNBQVMsQ0FBQztJQUNyQixDQUFDO0lBRU0scUJBQXFCO1FBQ3hCLElBQUksV0FBVyxHQUFlO1lBQzFCO2dCQUNJLEtBQUssRUFBRSxTQUFTLEVBQUUsR0FBRyxFQUFFLElBQUksRUFBRSxHQUFHLEVBQUUsS0FBSzthQUMxQyxFQUFFO2dCQUNDLEtBQUssRUFBRSxJQUFJLEVBQUUsR0FBRyxFQUFFLElBQUksRUFBRSxHQUFHLEVBQUUsS0FBSzthQUNyQyxFQUFFO2dCQUNDLEtBQUssRUFBRSxTQUFTLEVBQUUsR0FBRyxFQUFFLElBQUksRUFBRSxHQUFHLEVBQUUsS0FBSzthQUMxQyxFQUFFO2dCQUNDLEtBQUssRUFBRSxVQUFVLEVBQUUsR0FBRyxFQUFFLElBQUksRUFBRSxHQUFHLEVBQUUsS0FBSzthQUMzQyxFQUFFO2dCQUNDLEtBQUssRUFBRSxTQUFTLEVBQUUsR0FBRyxFQUFFLElBQUksRUFBRSxHQUFHLEVBQUUsS0FBSzthQUMxQyxFQUFFO2dCQUNDLEtBQUssRUFBRSxTQUFTLEVBQUUsR0FBRyxFQUFFLElBQUksRUFBRSxHQUFHLEVBQUUsS0FBSzthQUMxQyxDQUFBLEdBQUc7WUFDSixjQUFjO1NBQ2pCLENBQUM7UUFFRixPQUFPLFdBQVcsQ0FBQztJQUN2QixDQUFDO0lBRU0saUJBQWlCLENBQUMsT0FBcUIsRUFBRSxjQUFzQjtRQUNsRSxvREFBb0Q7UUFDcEQsSUFBSSxXQUFXLEdBQUcsSUFBSSxDQUFDLHVCQUF1QixDQUFDLE9BQU8sQ0FBQyxDQUFDO1FBQ3hELElBQUksR0FBRyxHQUFHLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxXQUFXLEVBQUUsY0FBYyxDQUFDLENBQUM7UUFDN0Qsc0NBQXNDO1FBQ3RDLE9BQU8sR0FBRyxDQUFDO0lBR2YsQ0FBQztJQUVNLGdCQUFnQixDQUFDLFlBQWlCLEVBQUUsY0FBc0I7UUFDN0QsS0FBSyxJQUFJLENBQUMsR0FBVyxDQUFDLEVBQUUsQ0FBQyxHQUFHLFlBQVksQ0FBQyxNQUFNLEVBQUUsQ0FBQyxFQUFFLEVBQUU7WUFDbEQsSUFBSSxZQUFZLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxLQUFLLGNBQWMsRUFBRTtnQkFDeEMsd0RBQXdEO2dCQUN4RCxPQUFPLFlBQVksQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUM7YUFFOUI7U0FDSjtJQUNMLENBQUM7SUFFTSxhQUFhLENBQUMsS0FBYSxFQUFFLE9BQWE7UUFDN0MsSUFBSSxVQUFVLEdBQWUsRUFBRSxDQUFDO1FBQ2hDLFFBQVEsS0FBSyxFQUFFO1lBQ1gsS0FBSyxnQkFBZ0I7Z0JBQ2pCLFVBQVUsR0FBRztvQkFDVDt3QkFDSSxLQUFLLEVBQUUsYUFBYTt3QkFDcEIsT0FBTyxFQUFFLGtCQUFrQjt3QkFDM0IsT0FBTyxFQUFFLE9BQU87d0JBQ2hCLFdBQVcsRUFBRSxxQkFBcUI7d0JBQ2xDLGFBQWEsRUFBRSxVQUFVO3dCQUN6QixNQUFNLEVBQUUsVUFBVTt3QkFDbEIsT0FBTyxFQUFFLEVBQUU7cUJBQ2Q7b0JBQ0Q7d0JBQ0ksS0FBSyxFQUFFLGlCQUFpQjt3QkFDeEIsT0FBTyxFQUFFLGNBQWM7d0JBQ3ZCLE9BQU8sRUFBRSxPQUFPO3dCQUNoQixXQUFXLEVBQUUscUJBQXFCO3dCQUNsQyxhQUFhLEVBQUUsVUFBVTt3QkFDekIsTUFBTSxFQUFFLFVBQVU7d0JBQ2xCLE9BQU8sRUFBRSxFQUFFO3FCQUNkO2lCQUNKLENBQUE7Z0JBQ0QsTUFBTTtZQUNWLEtBQUssaUJBQWlCO2dCQUNsQixVQUFVLEdBQUc7b0JBQ1Q7d0JBQ0ksS0FBSyxFQUFFLFdBQVc7d0JBQ2xCLE9BQU8sRUFBRSxPQUFPO3dCQUNoQixPQUFPLEVBQUUsT0FBTzt3QkFDaEIsV0FBVyxFQUFFLDRCQUE0Qjt3QkFDekMsYUFBYSxFQUFFLFNBQVM7d0JBQ3hCLE9BQU8sRUFBRSxFQUFFO3FCQUNkO2lCQUNKLENBQUE7Z0JBQ0QsTUFBTTtZQUNWLEtBQUssaUJBQWlCO2dCQUNsQixVQUFVLEdBQUc7b0JBQ1Q7d0JBQ0ksS0FBSyxFQUFFLFdBQVc7d0JBQ2xCLE9BQU8sRUFBRSxvQkFBb0I7d0JBQzdCLE9BQU8sRUFBRSxPQUFPO3dCQUNoQixXQUFXLEVBQUUsWUFBWTt3QkFDekIsYUFBYSxFQUFFLFNBQVM7d0JBQ3hCLE9BQU8sRUFBRSxFQUFFO3FCQUNkO29CQUNELElBQUk7b0JBQ0osMEJBQTBCO29CQUMxQix3QkFBd0I7b0JBQ3hCLDhCQUE4QjtvQkFDOUIsZ0NBQWdDO29CQUNoQyxrQkFBa0I7b0JBQ2xCLElBQUk7aUJBQ1AsQ0FBQTtnQkFDRCxNQUFNO1lBQ04sS0FBSyxVQUFVO2dCQUNYLFVBQVUsR0FBRztvQkFDVDt3QkFDSSxLQUFLLEVBQUUsU0FBUzt3QkFDaEIsT0FBTyxFQUFFLEtBQUs7d0JBQ2QsT0FBTyxFQUFFLE9BQU87d0JBQ2hCLFdBQVcsRUFBRSxxQkFBcUI7d0JBQ2xDLGFBQWEsRUFBRSxVQUFVO3dCQUN6QixNQUFNLEVBQUUsVUFBVTt3QkFDbEIsT0FBTyxFQUFFLENBQUEsT0FBTyxhQUFQLE9BQU8sdUJBQVAsT0FBTyxDQUFFLEtBQUssRUFBQyxDQUFDLENBQUMsT0FBTyxhQUFQLE9BQU8sdUJBQVAsT0FBTyxDQUFFLEtBQUssQ0FBQyxDQUFDLENBQUMsRUFBRTtxQkFDaEQ7aUJBQ0osQ0FBQTtnQkFDRCxNQUFNO1lBQ2Q7Z0JBQ0ksVUFBVSxHQUFHO29CQUNUO3dCQUNJLEtBQUssRUFBRSxVQUFVO3dCQUNqQixPQUFPLEVBQUUsV0FBVzt3QkFDcEIsT0FBTyxFQUFFLE9BQU87d0JBQ2hCLFdBQVcsRUFBRSxZQUFZO3dCQUN6QixhQUFhLEVBQUUsTUFBTTt3QkFDckIsT0FBTyxFQUFFLEVBQUU7cUJBQ2Q7b0JBQ0Q7d0JBQ0ksS0FBSyxFQUFFLFVBQVU7d0JBQ2pCLE9BQU8sRUFBRSxVQUFVO3dCQUNuQixPQUFPLEVBQUUsT0FBTzt3QkFDaEIsV0FBVyxFQUFFLHFCQUFxQjt3QkFDbEMsYUFBYSxFQUFFLE1BQU07d0JBQ3JCLE1BQU0sRUFBRSxVQUFVO3dCQUNsQixPQUFPLEVBQUUsRUFBRTtxQkFDZDtvQkFDRDt3QkFDSSxLQUFLLEVBQUUsVUFBVTt3QkFDakIsT0FBTyxFQUFFLDBCQUEwQjt3QkFDbkMsV0FBVyxFQUFFLGFBQWE7d0JBQzFCLE9BQU8sRUFBRSxPQUFPLENBQUMsS0FBSzt3QkFDdEIsU0FBUyxFQUFFLE9BQU8sQ0FBQyxPQUFPO3dCQUMxQixhQUFhLEVBQUUsVUFBVTtxQkFDNUI7aUJBQ0osQ0FBQTtnQkFDRCxNQUFNO1NBQ2I7UUFFRCxPQUFPLFVBQVUsQ0FBQztJQUN0QixDQUFDO0lBRU0sY0FBYyxDQUFDLEtBQWEsRUFBRSxNQUFlO1FBQ2hELElBQUksU0FBUyxHQUFXLFFBQVEsQ0FBQztRQUVqQyxRQUFRLEtBQUssRUFBRTtZQUVYLEtBQUssZ0JBQWdCO2dCQUNqQixJQUFJLE9BQU8sTUFBTSxLQUFLLFdBQVc7b0JBQUUsU0FBUyxHQUFHLE1BQU0sQ0FBQzs7b0JBQ2pELFNBQVMsR0FBRyxpQkFBaUIsQ0FBQTtnQkFDbEMsTUFBTTtZQUVWLEtBQUssaUJBQWlCO2dCQUNsQixJQUFJLE9BQU8sTUFBTSxLQUFLLFdBQVc7b0JBQUUsU0FBUyxHQUFHLE1BQU0sQ0FBQzs7b0JBQ2pELFNBQVMsR0FBRyxrQkFBa0IsQ0FBQTtnQkFDbkMsTUFBTTtZQUVWLEtBQUssaUJBQWlCO2dCQUNsQixJQUFJLE9BQU8sTUFBTSxLQUFLLFdBQVc7b0JBQUUsU0FBUyxHQUFHLE1BQU0sQ0FBQzs7b0JBQ2pELFNBQVMsR0FBRyxnQkFBZ0IsQ0FBQTtnQkFDakMsTUFBTTtZQUVWO2dCQUNJLElBQUksT0FBTyxNQUFNLEtBQUssV0FBVztvQkFBRSxTQUFTLEdBQUcsTUFBTSxDQUFDOztvQkFDakQsU0FBUyxHQUFHLE9BQU8sQ0FBQTtnQkFDeEIsTUFBTTtTQUNiO1FBRUQsT0FBTyxTQUFTLENBQUM7SUFDckIsQ0FBQztJQUVNLFlBQVksQ0FBQyxPQUFxQixFQUFFLEtBQWE7UUFDcEQsSUFBSSxVQUFVLEdBQTJCLEVBQUUsQ0FBQTtRQUUzQyxJQUFJLFdBQVcsR0FBUSxJQUFJLENBQUMsbUJBQW1CLENBQUMsS0FBSyxDQUFDLENBQUM7UUFFdkQsUUFBUSxLQUFLLEVBQUU7WUFFWCxLQUFLLGdCQUFnQjtnQkFDakIsVUFBVSxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLFdBQVcsQ0FBQyxJQUFJLEVBQUUsT0FBTyxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFBO2dCQUN4RSxNQUFNO1lBRVYsS0FBSyxpQkFBaUI7Z0JBQ2xCLFVBQVUsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxXQUFXLENBQUMsSUFBSSxFQUFFLE9BQU8sQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQTtnQkFDeEUsTUFBTTtZQUVWLEtBQUssaUJBQWlCO2dCQUNsQixVQUFVLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsV0FBVyxDQUFDLElBQUksRUFBRSxPQUFPLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUE7Z0JBQ3hFLE1BQU07WUFFVjtnQkFDSSxJQUFHLE9BQU8sQ0FBQyxTQUFTLElBQUksT0FBTyxDQUFDLFNBQVMsQ0FBQyxjQUFjO29CQUN4RCxVQUFVLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsV0FBVyxDQUFDLGNBQWMsRUFBRSxPQUFPLENBQUMsU0FBUyxDQUFDLGNBQWMsQ0FBQyxDQUFDLENBQUE7Z0JBQzVGLElBQUcsT0FBTyxDQUFDLFNBQVMsSUFBSSxPQUFPLENBQUMsU0FBUyxDQUFDLFVBQVU7b0JBQ3BELFVBQVUsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxXQUFXLENBQUMsVUFBVSxFQUFFLE9BQU8sQ0FBQyxTQUFTLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQTtnQkFDcEYsTUFBTTtTQUNiO1FBRUQsT0FBTyxVQUFVLENBQUM7UUFFbEIsbUpBQW1KO1FBQ25KLHNEQUFzRDtRQUN0RCxrQ0FBa0M7UUFDbEMsc0RBQXNEO1FBQ3RELFFBQVE7UUFFUix5QkFBeUI7UUFDekIsSUFBSTtJQUNSLENBQUM7SUFFTyxtQkFBbUIsQ0FBQyxLQUFhO1FBQ3JDLElBQUksVUFBVSxHQUFRLEVBQUUsQ0FBQztRQUV6QixRQUFRLEtBQUssRUFBRTtZQUVYLEtBQUssZ0JBQWdCO2dCQUNqQixVQUFVLEdBQUc7b0JBQ1QsSUFBSSxFQUFFO3dCQUNGLEtBQUssRUFBRSxnQkFBZ0I7cUJBQzFCO2lCQUNKLENBQUE7Z0JBQ0QsTUFBTTtZQUVWLEtBQUssaUJBQWlCO2dCQUNsQixVQUFVLEdBQUc7b0JBQ1QsSUFBSSxFQUFFO3dCQUNGLEtBQUssRUFBRSxnQkFBZ0I7cUJBQzFCO2lCQUNKLENBQUE7Z0JBQ0QsTUFBTTtZQUVWLEtBQUssaUJBQWlCO2dCQUNsQixVQUFVLEdBQUc7b0JBQ1QsSUFBSSxFQUFFO3dCQUNGLEtBQUssRUFBRSxnQkFBZ0I7cUJBQzFCO2lCQUNKLENBQUE7Z0JBQ0QsTUFBTTtZQUVWO2dCQUNJLFVBQVUsR0FBRztvQkFDVCxjQUFjLEVBQUU7d0JBQ1osS0FBSyxFQUFFLGtCQUFrQjtxQkFDNUI7b0JBQ0QsVUFBVSxFQUFFO3dCQUNSLEtBQUssRUFBRSxrQkFBa0I7cUJBQzVCO2lCQUNKLENBQUE7Z0JBQ0QsTUFBTTtTQUNiO1FBQ0QsT0FBTyxVQUFVLENBQUM7SUFDdEIsQ0FBQztJQUVELDJGQUEyRjtJQUMzRix5RkFBeUY7SUFDekYsd0ZBQXdGO0lBRXhGLGtGQUFrRjtJQUNsRixzR0FBc0c7SUFDdEcsWUFBWTtJQUNaLDZCQUE2QjtJQUM3QixRQUFRO0lBQ1Isb0JBQW9CO0lBQ3BCLElBQUk7SUFFSixxRUFBcUU7SUFDckUsNkJBQTZCO0lBRTdCLGtDQUFrQztJQUNsQyw4Q0FBOEM7SUFDOUMsd0NBQXdDO0lBQ3hDLDRDQUE0QztJQUM1QyxRQUFRO0lBRVIsd0JBQXdCO0lBQ3hCLElBQUk7SUFLSSxvQkFBb0IsQ0FBQyxtQkFBd0I7UUFDakQsa0RBQWtEO1FBQ2xELElBQUk7WUFDQSxJQUFJLFdBQVcsQ0FBQyxjQUFjLENBQUMsU0FBUyxDQUFDLEVBQUU7Z0JBQ3ZDLElBQUksSUFBSSxHQUFXLENBQUMsV0FBVyxDQUFDLE9BQU8sQ0FBQyxjQUFjLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsV0FBVyxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQztnQkFFcEcsSUFBSSxXQUFXLENBQUMsT0FBTyxDQUFDLGNBQWMsQ0FBQyxNQUFNLENBQUMsRUFBRTtvQkFDNUMsbUJBQW1CLENBQUMsS0FBSyxHQUFHLFdBQVcsQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDO2lCQUN4RDtnQkFFRCxJQUFJLFdBQVcsQ0FBQyxPQUFPLENBQUMsY0FBYyxDQUFDLEtBQUssQ0FBQyxFQUFFO29CQUMzQyxRQUFRLElBQUksRUFBRTt3QkFDVixLQUFLLE1BQU07NEJBQ1AsbUJBQW1CLENBQUMsSUFBSSxHQUFHLFdBQVcsQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDOzRCQUNuRCxNQUFNO3dCQUNWLEtBQUssT0FBTzs0QkFDUixtQkFBbUIsQ0FBQyxHQUFHLEdBQUcsV0FBVyxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUM7NEJBQ2xELE1BQU07d0JBQ1Y7NEJBQ0ksTUFBTTtxQkFDYjtpQkFDSjthQUNKO1NBQ0o7UUFBQyxPQUFPLEdBQUcsRUFBRTtZQUNWLG9CQUFvQjtTQUN2QjtRQUVELE9BQU8sbUJBQW1CLENBQUM7SUFDL0IsQ0FBQztJQUlELGdCQUFnQixDQUFDLFlBQWlCO1FBQzlCLElBQUksT0FBTyxZQUFZLENBQUMsT0FBTyxLQUFLLFdBQVc7WUFBRSxPQUFPLFlBQVksQ0FBQyxPQUFPLENBQUM7UUFDN0UsSUFBSSxPQUFPLFlBQVksQ0FBQyxHQUFHLEtBQUssV0FBVyxJQUFJLE9BQU8sWUFBWSxDQUFDLEtBQUssS0FBSyxXQUFXO1lBQUUsT0FBTyxNQUFNLENBQUM7UUFDeEcsT0FBTyxPQUFPLENBQUM7SUFDbkIsQ0FBQztJQUVELFlBQVksQ0FBQyxhQUFxQjtRQUM5QixJQUFJLFVBQVUsR0FBVyxhQUFhLENBQUMsT0FBTyxDQUFDLEdBQUcsRUFBRSxFQUFFLENBQUMsQ0FBQztRQUN4RCxJQUFJLFdBQVcsR0FBa0IsVUFBVSxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FBQztRQUN2RCxJQUFJLFFBQVEsR0FBUSxFQUFFLENBQUM7UUFDdkIsSUFBSSxXQUFXLENBQUMsTUFBTSxLQUFLLENBQUMsRUFBRTtZQUMxQixRQUFRLEdBQUc7Z0JBQ1AsSUFBSSxFQUFFLFdBQVcsQ0FBQyxDQUFDLENBQUM7Z0JBQ3BCLElBQUksRUFBRSxXQUFXLENBQUMsQ0FBQyxDQUFDO2FBQ3ZCLENBQUM7U0FDTDtRQUNELE9BQU8sUUFBUSxDQUFDO0lBQ3BCLENBQUM7OztZQTFYSixVQUFVIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgSW5qZWN0YWJsZSwgUmVuZGVyZXIyIH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XHJcbmltcG9ydCB7IEtkRG9tRWxlbVN2YyB9IGZyb20gJy4uL2tkLWNvbW1vbi9pbmRleCc7XHJcbmltcG9ydCB7XHJcbiAgICBJTG9naW5Db25maWcsXHJcbiAgICBJTGFuZ3VhZ2VPcHRpb25zQ29uZmlnLFxyXG4gICAgSUZvcm1MaW5rQ29uZmlnLFxyXG4gICAgSUZvcm1BbGVydENvbmZpZyxcclxuICAgIElMYW5ndWFnZUNvbmZpZ1xyXG59IGZyb20gJy4va2QtYW5ndWxhci1sb2dpbi1pbnRlcmZhY2UnO1xyXG5cclxuXHJcbmRlY2xhcmUgbGV0IEFQUF9DT05GSUdTOiBhbnk7XHJcblxyXG5ASW5qZWN0YWJsZSgpXHJcbmV4cG9ydCBjbGFzcyBLZExvZ2luU3ZjIHtcclxuICAgIHByaXZhdGUgX2RvbVN2YzogS2REb21FbGVtU3ZjO1xyXG4gICAgcHJpdmF0ZSBfcmVuZGVyZXI6IFJlbmRlcmVyMjtcclxuXHJcbiAgICBwdWJsaWMgZ2V0SGVhZGVyQ29uZmlnVmFsdWVzKF9jb25maWc6IGFueSwgX2RlZmF1bHRDb25maWc6IGFueSk6IGFueSB7XHJcbiAgICAgICAgbGV0IHVwZGF0ZUhlYWRlckNvbmZpZzogYW55ID0ge307XHJcbiAgICAgICAgaWYgKHR5cGVvZiBfY29uZmlnID09PSAndW5kZWZpbmVkJyB8fCB0eXBlb2YgX2NvbmZpZy5oZWFkZXIgPT09ICd1bmRlZmluZWQnKSB7XHJcbiAgICAgICAgICAgIGlmICh0eXBlb2YgX2RlZmF1bHRDb25maWcgIT09ICd1bmRlZmluZWQnKSB1cGRhdGVIZWFkZXJDb25maWcgPSBKU09OLnBhcnNlKEpTT04uc3RyaW5naWZ5KF9kZWZhdWx0Q29uZmlnKSk7XHJcbiAgICAgICAgICAgIGVsc2UgdXBkYXRlSGVhZGVyQ29uZmlnID0geyBpY29uOiAna2Qtb3BlbmVtaXMnLCB0aXRsZTogJ09wZW5FTUlTJyB9O1xyXG4gICAgICAgIH1cclxuICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgdXBkYXRlSGVhZGVyQ29uZmlnID0gX2NvbmZpZy5oZWFkZXI7XHJcbiAgICAgICAgICAgIGlmICh0eXBlb2YgdXBkYXRlSGVhZGVyQ29uZmlnLmltZyAhPT0gJ3VuZGVmaW5lZCcgJiYgdHlwZW9mIHVwZGF0ZUhlYWRlckNvbmZpZy5pY29uICE9PSAndW5kZWZpbmVkJykgdXBkYXRlSGVhZGVyQ29uZmlnLmltZyA9ICcnO1xyXG4gICAgICAgICAgICBpZiAodHlwZW9mIHVwZGF0ZUhlYWRlckNvbmZpZy5pbWcgPT09ICd1bmRlZmluZWQnICYmIHR5cGVvZiB1cGRhdGVIZWFkZXJDb25maWcuaWNvbiA9PT0gJ3VuZGVmaW5lZCcpIHVwZGF0ZUhlYWRlckNvbmZpZy5pY29uID0gJyc7XHJcbiAgICAgICAgICAgIGlmICh0eXBlb2YgdXBkYXRlSGVhZGVyQ29uZmlnLmljb24gIT09ICd1bmRlZmluZWQnICYmIHR5cGVvZiB1cGRhdGVIZWFkZXJDb25maWcudGl0bGUgPT09ICd1bmRlZmluZWQnKSB1cGRhdGVIZWFkZXJDb25maWcudGl0bGUgPSAnJztcclxuICAgICAgICAgICAgaWYgKHR5cGVvZiB1cGRhdGVIZWFkZXJDb25maWcuaW1nICE9PSAndW5kZWZpbmVkJyAmJiB0eXBlb2YgdXBkYXRlSGVhZGVyQ29uZmlnLmltZ1NpemUgPT09ICd1bmRlZmluZWQnKSB1cGRhdGVIZWFkZXJDb25maWcuaW1nU2l6ZSA9ICdub25lJztcclxuICAgICAgICAgICAgaWYgKHR5cGVvZiB1cGRhdGVIZWFkZXJDb25maWcuaGVhZGVyTXNnICE9PSAndW5kZWZpbmVkJyAmJiB0eXBlb2YgdXBkYXRlSGVhZGVyQ29uZmlnLmhlYWRlck1zZyA9PT0gJ3VuZGVmaW5lZCcpIHVwZGF0ZUhlYWRlckNvbmZpZy5oZWFkZXJNc2cgPSAnJztcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIHJldHVybiB0aGlzLl9zZXRQcm9kdWN0QXBwQ29uZmlnKHVwZGF0ZUhlYWRlckNvbmZpZyk7XHJcbiAgICB9XHJcblxyXG4gICAgLypcclxuICAgICAgICBzZXQgZGVmYXVsdCBsYW5ndWFnZSBjb25maWdcclxuICAgICAgICAgICAgLSBpZiBjb25maWcgaXMgdW5kZWZpbmVkLCBsYW5ndW5hZ2UgdW5kZWZpbmVkLCBzaG93IHVuZGVmaW5lZCAtIHJldHVybiBkZWZhdWx0XHJcbiAgICAgICAgICAgICAgICAtIGlmIGNvbmZpZyBsaXN0IGlzIGRlZmluZWQsIGxpc3QgZ290IGl0ZW0sIGFuZCBzaG93IGlzIHRydWUgLSBzZXQgY29uZmlnIHRvIHNob3cgd2l0aCB0b2dnbGVcclxuICAgICAgICAgICAgICAgIC0gZWxzZSBpZiBjb25maWcgZGVmYXVsdCBpcyBkZWZpbmVkIC0gc2V0IGNvbmZpZyB3aXRoIGRlZmF1bHQgbGFuZ3VhZ2UgYW5kIHRvZ2dsZSBmYWxzZVxyXG4gICAgICAgIC0gcmV0dXJuIGNvbmZpZ1xyXG4gICAgICovXHJcbiAgICBwdWJsaWMgZ2V0TGFuZ3VhZ2VDb25maWdWYWx1ZXMoX2NvbmZpZzogSUxvZ2luQ29uZmlnKTogQXJyYXk8SUxhbmd1YWdlT3B0aW9uc0NvbmZpZz4ge1xyXG4gICAgICAgIGlmIChfY29uZmlnLmhhc093blByb3BlcnR5KCdsYW5ndWFnZScpICYmIF9jb25maWcubGFuZ3VhZ2UuaGFzT3duUHJvcGVydHkoJ29wdGlvbnMnKSkge1xyXG4gICAgICAgICAgICByZXR1cm4gX2NvbmZpZy5sYW5ndWFnZS5vcHRpb25zO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgcmV0dXJuIHRoaXMuZ2V0U2l4RGVmYXVsdExhbmd1YWdlKCk7XHJcbiAgICB9XHJcblxyXG4gICAgcHVibGljIGdldExhbmdhZ2VEZWZhdWx0VmFsdWUoX2NvbmZpZzogSUxvZ2luQ29uZmlnKTogc3RyaW5nIHtcclxuICAgICAgICBsZXQgcmV0dXJuVmFsOiBzdHJpbmcgPSAnZW4nO1xyXG4gICAgICAgIGlmIChfY29uZmlnLmhhc093blByb3BlcnR5KCdsYW5ndWFnZScpICYmIF9jb25maWcubGFuZ3VhZ2UuaGFzT3duUHJvcGVydHkoJ3ZhbHVlJykpIHtcclxuICAgICAgICAgICAgcmV0dXJuIF9jb25maWcubGFuZ3VhZ2UudmFsdWU7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICByZXR1cm4gcmV0dXJuVmFsO1xyXG4gICAgfVxyXG5cclxuICAgIHB1YmxpYyBnZXRTaXhEZWZhdWx0TGFuZ3VhZ2UoKTogQXJyYXk8YW55PiB7XHJcbiAgICAgICAgbGV0IGRlZmF1bHRMaXN0OiBBcnJheTxhbnk+ID0gW1xyXG4gICAgICAgICAgICB7XHJcbiAgICAgICAgICAgICAgICB2YWx1ZTogJ9in2YTYudix2KjZitipJywga2V5OiAnYXInLCBkaXI6ICdydGwnXHJcbiAgICAgICAgICAgIH0sIHtcclxuICAgICAgICAgICAgICAgIHZhbHVlOiAn5Lit5paHJywga2V5OiAnemgnLCBkaXI6ICdsdHInXHJcbiAgICAgICAgICAgIH0sIHtcclxuICAgICAgICAgICAgICAgIHZhbHVlOiAnRW5nbGlzaCcsIGtleTogJ2VuJywgZGlyOiAnbHRyJ1xyXG4gICAgICAgICAgICB9LCB7XHJcbiAgICAgICAgICAgICAgICB2YWx1ZTogJ0ZyYW7Dp2FpcycsIGtleTogJ2ZyJywgZGlyOiAnbHRyJ1xyXG4gICAgICAgICAgICB9LCB7XHJcbiAgICAgICAgICAgICAgICB2YWx1ZTogJ9GA0YPRgdGB0LrQuNC5Jywga2V5OiAncnUnLCBkaXI6ICdsdHInXHJcbiAgICAgICAgICAgIH0sIHtcclxuICAgICAgICAgICAgICAgIHZhbHVlOiAnZXNwYcOxb2wnLCBrZXk6ICdlcycsIGRpcjogJ2x0cidcclxuICAgICAgICAgICAgfS8vLFxyXG4gICAgICAgICAgICAvLyB2YWx1ZTogJ2VuJ1xyXG4gICAgICAgIF07XHJcblxyXG4gICAgICAgIHJldHVybiBkZWZhdWx0TGlzdDtcclxuICAgIH1cclxuXHJcbiAgICBwdWJsaWMgdXBkYXRlTGFuZ3VhZ2VEaXIoX2NvbmZpZzogSUxvZ2luQ29uZmlnLCBfc2VsZWN0ZWRJbmRleDogc3RyaW5nKTogc3RyaW5nIHtcclxuICAgICAgICAvLyBjb25zb2xlLmxvZygnUGFyZW50IHN2YyBydW46ICcgKyBfc2VsZWN0ZWRJbmRleCk7XHJcbiAgICAgICAgbGV0IGxhbmdPcHRpb25zID0gdGhpcy5nZXRMYW5ndWFnZUNvbmZpZ1ZhbHVlcyhfY29uZmlnKTtcclxuICAgICAgICBsZXQgZGlyID0gdGhpcy5jaGVja0xhbmd1YWdlRGlyKGxhbmdPcHRpb25zLCBfc2VsZWN0ZWRJbmRleCk7XHJcbiAgICAgICAgLy8gY29uc29sZS5sb2coJ1JldHVybiB0aGlzOiAnICsgZGlyKTtcclxuICAgICAgICByZXR1cm4gZGlyO1xyXG5cclxuXHJcbiAgICB9XHJcblxyXG4gICAgcHVibGljIGNoZWNrTGFuZ3VhZ2VEaXIoX2xhbmdPcHRpb25zOiBhbnksIF9zZWxlY3RlZEluZGV4OiBzdHJpbmcpOiBzdHJpbmcge1xyXG4gICAgICAgIGZvciAobGV0IGk6IG51bWJlciA9IDA7IGkgPCBfbGFuZ09wdGlvbnMubGVuZ3RoOyBpKyspIHtcclxuICAgICAgICAgICAgaWYgKF9sYW5nT3B0aW9uc1tpXS5rZXkgPT09IF9zZWxlY3RlZEluZGV4KSB7XHJcbiAgICAgICAgICAgICAgICAvLyBjb25zb2xlLmxvZygnRGV0ZWN0ZWQgdGhpczogJyArIF9sYW5nT3B0aW9uc1tpXS5kaXIpO1xyXG4gICAgICAgICAgICAgICAgcmV0dXJuIF9sYW5nT3B0aW9uc1tpXS5kaXI7XHJcblxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIHB1YmxpYyBnZXRGb3JtSW5wdXRzKF90eXBlOiBzdHJpbmcsIF9jb25maWc/OiBhbnkpOiBBcnJheTxhbnk+IHtcclxuICAgICAgICBsZXQgZm9ybUlucHV0czogQXJyYXk8YW55PiA9IFtdO1xyXG4gICAgICAgIHN3aXRjaCAoX3R5cGUpIHtcclxuICAgICAgICAgICAgY2FzZSBcInJlc2V0LXBhc3N3b3JkXCI6XHJcbiAgICAgICAgICAgICAgICBmb3JtSW5wdXRzID0gW1xyXG4gICAgICAgICAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgJ2tleSc6ICduZXdwYXNzd29yZCcsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICdsYWJlbCc6ICdDb25maXJtIFBhc3N3b3JkJyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgJ2NsYXNzJzogJ2lucHV0JyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgJ2ljb25DbGFzcyc6ICdmYSBmYS1rZXkgaWNvblNpemVTJywgXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICdjb250cm9sVHlwZSc6ICdwYXNzd29yZCcsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICd0eXBlJzogJ3Bhc3N3b3JkJyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgJ3ZhbHVlJzogJydcclxuICAgICAgICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgJ2tleSc6ICdjb25maXJtcGFzc3dvcmQnLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAnbGFiZWwnOiAnTmV3IFBhc3N3b3JkJyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgJ2NsYXNzJzogJ2lucHV0JyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgJ2ljb25DbGFzcyc6ICdmYSBmYS1rZXkgaWNvblNpemVTJywgXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICdjb250cm9sVHlwZSc6ICdwYXNzd29yZCcsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICd0eXBlJzogJ3Bhc3N3b3JkJyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgJ3ZhbHVlJzogJydcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICBdXHJcbiAgICAgICAgICAgICAgICBicmVhaztcclxuICAgICAgICAgICAgY2FzZSBcImZvcmdldC11c2VybmFtZVwiOlxyXG4gICAgICAgICAgICAgICAgZm9ybUlucHV0cyA9IFtcclxuICAgICAgICAgICAgICAgICAgICB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICdrZXknOiAndXNlcmVtYWlsJyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgJ2xhYmVsJzogJ0VtYWlsJyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgJ2NsYXNzJzogJ2lucHV0JyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgJ2ljb25DbGFzcyc6ICdmYSBmYS1lbnZlbG9wZS1vIGljb25TaXplUycsIFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAnY29udHJvbFR5cGUnOiAndGV4dGJveCcsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICd2YWx1ZSc6ICcnXHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgXVxyXG4gICAgICAgICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgICAgIGNhc2UgXCJmb3JnZXQtcGFzc3dvcmRcIjpcclxuICAgICAgICAgICAgICAgIGZvcm1JbnB1dHMgPSBbXHJcbiAgICAgICAgICAgICAgICAgICAge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAna2V5JzogJ3VzZXJpbnB1dCcsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICdsYWJlbCc6ICdVc2VyIE5hbWUgb3IgRW1haWwnLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAnY2xhc3MnOiAnaW5wdXQnLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAnaWNvbkNsYXNzJzogJ2ZhIGZhLXVzZXInLCBcclxuICAgICAgICAgICAgICAgICAgICAgICAgJ2NvbnRyb2xUeXBlJzogJ3RleHRib3gnLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAndmFsdWUnOiAnJ1xyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAvLyB7XHJcbiAgICAgICAgICAgICAgICAgICAgLy8gICAgICdrZXknOiAndXNlcmVtYWlsJyxcclxuICAgICAgICAgICAgICAgICAgICAvLyAgICAgJ2xhYmVsJzogJ0VtYWlsJyxcclxuICAgICAgICAgICAgICAgICAgICAvLyAgICAgJ2NsYXNzJzogJ2lucHV0IGVtYWlsJyxcclxuICAgICAgICAgICAgICAgICAgICAvLyAgICAgJ2NvbnRyb2xUeXBlJzogJ3RleHRib3gnLFxyXG4gICAgICAgICAgICAgICAgICAgIC8vICAgICAndmFsdWUnOiAnJ1xyXG4gICAgICAgICAgICAgICAgICAgIC8vIH1cclxuICAgICAgICAgICAgICAgIF1cclxuICAgICAgICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgICAgICAgICAgY2FzZSBcIm9ubHktb3RwXCI6XHJcbiAgICAgICAgICAgICAgICAgICAgZm9ybUlucHV0cyA9IFtcclxuICAgICAgICAgICAgICAgICAgICAgICAge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgJ2tleSc6ICd1c2VyT1RQJyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICdsYWJlbCc6ICdPVFAnLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgJ2NsYXNzJzogJ2lucHV0JyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICdpY29uQ2xhc3MnOiAnZmEgZmEta2V5IGljb25TaXplUycsIFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgJ2NvbnRyb2xUeXBlJzogJ3Bhc3N3b3JkJyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICd0eXBlJzogJ3Bhc3N3b3JkJyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICd2YWx1ZSc6IF9jb25maWc/LnZhbHVlID8gX2NvbmZpZz8udmFsdWUgOiAnJ1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgXVxyXG4gICAgICAgICAgICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgICAgICBkZWZhdWx0OlxyXG4gICAgICAgICAgICAgICAgZm9ybUlucHV0cyA9IFtcclxuICAgICAgICAgICAgICAgICAgICB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICdrZXknOiAndXNlcm5hbWUnLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAnbGFiZWwnOiAnVXNlciBOYW1lJyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgJ2NsYXNzJzogJ2lucHV0JyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgJ2ljb25DbGFzcyc6ICdmYSBmYS11c2VyJywgXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICdjb250cm9sVHlwZSc6ICd0ZXh0JyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgJ3ZhbHVlJzogJydcclxuICAgICAgICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgJ2tleSc6ICdwYXNzd29yZCcsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICdsYWJlbCc6ICdQYXNzd29yZCcsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICdjbGFzcyc6ICdpbnB1dCcsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICdpY29uQ2xhc3MnOiAnZmEgZmEta2V5IGljb25TaXplUycsIFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAnY29udHJvbFR5cGUnOiAndGV4dCcsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICd0eXBlJzogJ3Bhc3N3b3JkJyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgJ3ZhbHVlJzogJydcclxuICAgICAgICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgJ2tleSc6ICdsYW5ndWFnZScsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICdjbGFzcyc6ICdrZHgtaW5wdXQtc2VsZWN0LXdyYXBwZXInLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAnaWNvbkNsYXNzJzogJ2ZhIGZhLWdsb2JlJyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgJ3ZhbHVlJzogX2NvbmZpZy52YWx1ZSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgJ29wdGlvbnMnOiBfY29uZmlnLm9wdGlvbnMsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICdjb250cm9sVHlwZSc6ICdkcm9wZG93bidcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICBdXHJcbiAgICAgICAgICAgICAgICBicmVhaztcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIHJldHVybiBmb3JtSW5wdXRzO1xyXG4gICAgfVxyXG5cclxuICAgIHB1YmxpYyBnZXRCdXR0b25MYWJlbChfdHlwZTogc3RyaW5nLCBfbGFiZWw/OiBzdHJpbmcpOiBzdHJpbmcge1xyXG4gICAgICAgIGxldCB0ZW1wTGFiZWw6IHN0cmluZyA9IFwiU3VibWl0XCI7XHJcblxyXG4gICAgICAgIHN3aXRjaCAoX3R5cGUpIHtcclxuXHJcbiAgICAgICAgICAgIGNhc2UgXCJyZXNldC1wYXNzd29yZFwiOlxyXG4gICAgICAgICAgICAgICAgaWYgKHR5cGVvZiBfbGFiZWwgIT09ICd1bmRlZmluZWQnKSB0ZW1wTGFiZWwgPSBfbGFiZWw7XHJcbiAgICAgICAgICAgICAgICBlbHNlIHRlbXBMYWJlbCA9ICdVcGRhdGUgUGFzc3dvcmQnXHJcbiAgICAgICAgICAgICAgICBicmVhaztcclxuXHJcbiAgICAgICAgICAgIGNhc2UgXCJmb3JnZXQtdXNlcm5hbWVcIjpcclxuICAgICAgICAgICAgICAgIGlmICh0eXBlb2YgX2xhYmVsICE9PSAndW5kZWZpbmVkJykgdGVtcExhYmVsID0gX2xhYmVsO1xyXG4gICAgICAgICAgICAgICAgZWxzZSB0ZW1wTGFiZWwgPSAnUmVjb3ZlciBVc2VybmFtZSdcclxuICAgICAgICAgICAgICAgIGJyZWFrO1xyXG5cclxuICAgICAgICAgICAgY2FzZSBcImZvcmdldC1wYXNzd29yZFwiOlxyXG4gICAgICAgICAgICAgICAgaWYgKHR5cGVvZiBfbGFiZWwgIT09ICd1bmRlZmluZWQnKSB0ZW1wTGFiZWwgPSBfbGFiZWw7XHJcbiAgICAgICAgICAgICAgICBlbHNlIHRlbXBMYWJlbCA9ICdSZXNldCBQYXNzd29yZCdcclxuICAgICAgICAgICAgICAgIGJyZWFrO1xyXG5cclxuICAgICAgICAgICAgZGVmYXVsdDpcclxuICAgICAgICAgICAgICAgIGlmICh0eXBlb2YgX2xhYmVsICE9PSAndW5kZWZpbmVkJykgdGVtcExhYmVsID0gX2xhYmVsO1xyXG4gICAgICAgICAgICAgICAgZWxzZSB0ZW1wTGFiZWwgPSAnTG9naW4nXHJcbiAgICAgICAgICAgICAgICBicmVhaztcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIHJldHVybiB0ZW1wTGFiZWw7XHJcbiAgICB9XHJcblxyXG4gICAgcHVibGljIGdldEZvcm1MaW5rcyhfY29uZmlnOiBJTG9naW5Db25maWcsIF90eXBlOiBzdHJpbmcpOiBBcnJheTxJRm9ybUxpbmtDb25maWc+IHtcclxuICAgICAgICBsZXQgcmV0dXJuRGF0YTogQXJyYXk8SUZvcm1MaW5rQ29uZmlnPiA9IFtdXHJcblxyXG4gICAgICAgIGxldCBkZWZhdWx0TGluazogYW55ID0gdGhpcy5nZXREZWZhdWx0Rm9ybUxpbmtzKF90eXBlKTtcclxuXHJcbiAgICAgICAgc3dpdGNoIChfdHlwZSkge1xyXG5cclxuICAgICAgICAgICAgY2FzZSBcInJlc2V0LXBhc3N3b3JkXCI6XHJcbiAgICAgICAgICAgICAgICByZXR1cm5EYXRhLnB1c2goT2JqZWN0LmFzc2lnbihkZWZhdWx0TGluay5iYWNrLCBfY29uZmlnLmZvcm1MaW5rcy5iYWNrKSlcclxuICAgICAgICAgICAgICAgIGJyZWFrO1xyXG5cclxuICAgICAgICAgICAgY2FzZSBcImZvcmdldC11c2VybmFtZVwiOlxyXG4gICAgICAgICAgICAgICAgcmV0dXJuRGF0YS5wdXNoKE9iamVjdC5hc3NpZ24oZGVmYXVsdExpbmsuYmFjaywgX2NvbmZpZy5mb3JtTGlua3MuYmFjaykpXHJcbiAgICAgICAgICAgICAgICBicmVhaztcclxuXHJcbiAgICAgICAgICAgIGNhc2UgXCJmb3JnZXQtcGFzc3dvcmRcIjpcclxuICAgICAgICAgICAgICAgIHJldHVybkRhdGEucHVzaChPYmplY3QuYXNzaWduKGRlZmF1bHRMaW5rLmJhY2ssIF9jb25maWcuZm9ybUxpbmtzLmJhY2spKVxyXG4gICAgICAgICAgICAgICAgYnJlYWs7XHJcblxyXG4gICAgICAgICAgICBkZWZhdWx0OlxyXG4gICAgICAgICAgICAgICAgaWYoX2NvbmZpZy5mb3JtTGlua3MgJiYgX2NvbmZpZy5mb3JtTGlua3MuZm9yZ2V0UGFzc3dvcmQpXHJcbiAgICAgICAgICAgICAgICByZXR1cm5EYXRhLnB1c2goT2JqZWN0LmFzc2lnbihkZWZhdWx0TGluay5mb3JnZXRQYXNzd29yZCwgX2NvbmZpZy5mb3JtTGlua3MuZm9yZ2V0UGFzc3dvcmQpKVxyXG4gICAgICAgICAgICAgICAgaWYoX2NvbmZpZy5mb3JtTGlua3MgJiYgX2NvbmZpZy5mb3JtTGlua3MuZm9yZ2V0VXNlcilcclxuICAgICAgICAgICAgICAgIHJldHVybkRhdGEucHVzaChPYmplY3QuYXNzaWduKGRlZmF1bHRMaW5rLmZvcmdldFVzZXIsIF9jb25maWcuZm9ybUxpbmtzLmZvcmdldFVzZXIpKVxyXG4gICAgICAgICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICByZXR1cm4gcmV0dXJuRGF0YTtcclxuXHJcbiAgICAgICAgLy8gaWYgKF9jb25maWcuaGFzT3duUHJvcGVydHkoJ2Zvcm1MaW5rcycpICYmIF9jb25maWcuZm9ybUxpbmtzLmhhc093blByb3BlcnR5KF9saW5rVHlwZSkgJiYgX2NvbmZpZy5mb3JtTGlua3NbX2xpbmtUeXBlXS5oYXNPd25Qcm9wZXJ0eSgncGF0aCcpKSB7XHJcbiAgICAgICAgLy8gICAgIC8vcmV0dXJuIF9jb25maWcuZm9ybUxpbmtzLmZvcmdldFBhc3N3b3JkLnBhdGg7XHJcbiAgICAgICAgLy8gICAgIGxldCBmb3JnZXRQYXNzd29yZDogYW55ID0ge1xyXG4gICAgICAgIC8vICAgICAgICAgcGF0aDogX2NvbmZpZy5mb3JtTGlua3MuZm9yZ2V0UGFzc3dvcmQucGF0aFxyXG4gICAgICAgIC8vICAgICB9XHJcblxyXG4gICAgICAgIC8vIHJldHVybiBmb3JnZXRQYXNzd29yZDtcclxuICAgICAgICAvLyB9XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBnZXREZWZhdWx0Rm9ybUxpbmtzKF90eXBlOiBzdHJpbmcpOiBhbnkge1xyXG4gICAgICAgIGxldCByZXR1cm5EYXRhOiBhbnkgPSB7fTtcclxuXHJcbiAgICAgICAgc3dpdGNoIChfdHlwZSkge1xyXG5cclxuICAgICAgICAgICAgY2FzZSBcInJlc2V0LXBhc3N3b3JkXCI6XHJcbiAgICAgICAgICAgICAgICByZXR1cm5EYXRhID0ge1xyXG4gICAgICAgICAgICAgICAgICAgIGJhY2s6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgbGFiZWw6ICdCYWNrIHRvIGxvZ2luPydcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICBicmVhaztcclxuXHJcbiAgICAgICAgICAgIGNhc2UgXCJmb3JnZXQtdXNlcm5hbWVcIjpcclxuICAgICAgICAgICAgICAgIHJldHVybkRhdGEgPSB7XHJcbiAgICAgICAgICAgICAgICAgICAgYmFjazoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBsYWJlbDogJ0JhY2sgdG8gbG9naW4/J1xyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIGJyZWFrO1xyXG5cclxuICAgICAgICAgICAgY2FzZSBcImZvcmdldC1wYXNzd29yZFwiOlxyXG4gICAgICAgICAgICAgICAgcmV0dXJuRGF0YSA9IHtcclxuICAgICAgICAgICAgICAgICAgICBiYWNrOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGxhYmVsOiAnQmFjayB0byBsb2dpbj8nXHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgYnJlYWs7XHJcblxyXG4gICAgICAgICAgICBkZWZhdWx0OlxyXG4gICAgICAgICAgICAgICAgcmV0dXJuRGF0YSA9IHtcclxuICAgICAgICAgICAgICAgICAgICBmb3JnZXRQYXNzd29yZDoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBsYWJlbDogJ0ZvcmdldCBQYXNzd29yZD8nXHJcbiAgICAgICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICAgICAgICBmb3JnZXRVc2VyOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGxhYmVsOiAnRm9yZ2V0IFVzZXJuYW1lPydcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICBicmVhaztcclxuICAgICAgICB9XHJcbiAgICAgICAgcmV0dXJuIHJldHVybkRhdGE7XHJcbiAgICB9XHJcblxyXG4gICAgLy8gcHVibGljIGdldEZvcm1BbGVydHMoX2NvbmZpZzogSUxvZ2luQ29uZmlnLCBfdHlwZTogc3RyaW5nKTogSUZvcm1BbGVydENvbmZpZyB8IGJvb2xlYW4ge1xyXG4gICAgLy8gICAgIGlmIChfY29uZmlnLmhhc093blByb3BlcnR5KCdhbGVydCcpICYmIF9jb25maWcuYWxlcnQuaGFzT3duUHJvcGVydHkoJ2Vycm9yTXNnJykpIHtcclxuICAgIC8vICAgICAgICAgbGV0IHJldHVybkRhdGE6IElGb3JtQWxlcnRDb25maWcgPSBKU09OLnBhcnNlKEpTT04uc3RyaW5naWZ5KF9jb25maWcuYWxlcnQpKTtcclxuXHJcbiAgICAvLyAgICAgICAgIGlmICghX2NvbmZpZy5hbGVydC5oYXNPd25Qcm9wZXJ0eSgnc3VjY2Vzc01zZycpICYmIF90eXBlICE9PSAnbG9naW4nKSB7XHJcbiAgICAvLyAgICAgICAgICAgICByZXR1cm5EYXRhWydzdWNjZXNzTXNnJ10gPSAnQW4gZW1haWwgd2lsbCBiZSBzZW5kIHNob3J0bHkuIFBsZWFzZSBjaGVjayB5b3VyIG1haWxib3guJztcclxuICAgIC8vICAgICAgICAgfVxyXG4gICAgLy8gICAgICAgICByZXR1cm4gcmV0dXJuRGF0YTtcclxuICAgIC8vICAgICB9XHJcbiAgICAvLyAgICAgcmV0dXJuIGZhbHNlO1xyXG4gICAgLy8gfVxyXG5cclxuICAgIC8vIHB1YmxpYyBzZXRBbGVydE1lc3NhZ2UoX3ZhbHVlOiBzdHJpbmcsIF9mb3JtQWxlcnRzOiBhbnkpOiBzdHJpbmcge1xyXG4gICAgLy8gICAgIGxldCByZXR1cm5WYWw6IHN0cmluZztcclxuXHJcbiAgICAvLyAgICAgaWYgKF92YWx1ZSA9PT0gJ3N1Y2Nlc3MnKSB7XHJcbiAgICAvLyAgICAgICAgIHJldHVyblZhbCA9IF9mb3JtQWxlcnRzLnN1Y2Nlc3NNc2c7XHJcbiAgICAvLyAgICAgfSBlbHNlIGlmIChfdmFsdWUgPT09ICdkYW5nZXInKSB7XHJcbiAgICAvLyAgICAgICAgIHJldHVyblZhbCA9IF9mb3JtQWxlcnRzLmVycm9yTXNnO1xyXG4gICAgLy8gICAgIH1cclxuXHJcbiAgICAvLyAgICAgcmV0dXJuIHJldHVyblZhbDtcclxuICAgIC8vIH1cclxuXHJcblxyXG5cclxuXHJcbiAgICBwcml2YXRlIF9zZXRQcm9kdWN0QXBwQ29uZmlnKF91cGRhdGVIZWFkZXJDb25maWc6IGFueSk6IGFueSB7XHJcbiAgICAgICAgLy8gbGV0IHRlbXBIZWFkZXJDb25maWc6YW55ID0gX3VwZGF0ZUhlYWRlckNvbmZpZztcclxuICAgICAgICB0cnkge1xyXG4gICAgICAgICAgICBpZiAoQVBQX0NPTkZJR1MuaGFzT3duUHJvcGVydHkoJ3Byb2R1Y3QnKSkge1xyXG4gICAgICAgICAgICAgICAgbGV0IHR5cGU6IHN0cmluZyA9IChBUFBfQ09ORklHUy5wcm9kdWN0Lmhhc093blByb3BlcnR5KCd0eXBlJykpID8gQVBQX0NPTkZJR1MucHJvZHVjdC50eXBlIDogJ2ljb24nO1xyXG5cclxuICAgICAgICAgICAgICAgIGlmIChBUFBfQ09ORklHUy5wcm9kdWN0Lmhhc093blByb3BlcnR5KCduYW1lJykpIHtcclxuICAgICAgICAgICAgICAgICAgICBfdXBkYXRlSGVhZGVyQ29uZmlnLnRpdGxlID0gQVBQX0NPTkZJR1MucHJvZHVjdC5uYW1lO1xyXG4gICAgICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgICAgIGlmIChBUFBfQ09ORklHUy5wcm9kdWN0Lmhhc093blByb3BlcnR5KCdzcmMnKSkge1xyXG4gICAgICAgICAgICAgICAgICAgIHN3aXRjaCAodHlwZSkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBjYXNlICdpY29uJzpcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIF91cGRhdGVIZWFkZXJDb25maWcuaWNvbiA9IEFQUF9DT05GSUdTLnByb2R1Y3Quc3JjO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNhc2UgJ2ltYWdlJzpcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIF91cGRhdGVIZWFkZXJDb25maWcuaW1nID0gQVBQX0NPTkZJR1MucHJvZHVjdC5zcmM7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBicmVhaztcclxuICAgICAgICAgICAgICAgICAgICAgICAgZGVmYXVsdDpcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH0gY2F0Y2ggKGVycikge1xyXG4gICAgICAgICAgICAvLyBjb25zb2xlLmxvZyhlcnIpO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgcmV0dXJuIF91cGRhdGVIZWFkZXJDb25maWc7XHJcbiAgICB9XHJcblxyXG5cclxuXHJcbiAgICBnZXRMb2dvU2l6ZUNsYXNzKGhlYWRlckNvbmZpZzogYW55KTogc3RyaW5nIHtcclxuICAgICAgICBpZiAodHlwZW9mIGhlYWRlckNvbmZpZy5pbWdTaXplICE9PSAndW5kZWZpbmVkJykgcmV0dXJuIGhlYWRlckNvbmZpZy5pbWdTaXplO1xyXG4gICAgICAgIGlmICh0eXBlb2YgaGVhZGVyQ29uZmlnLmltZyAhPT0gJ3VuZGVmaW5lZCcgJiYgdHlwZW9mIGhlYWRlckNvbmZpZy50aXRsZSA9PT0gJ3VuZGVmaW5lZCcpIHJldHVybiAnZnVsbCc7XHJcbiAgICAgICAgcmV0dXJuICdzbWFsbCc7XHJcbiAgICB9XHJcblxyXG4gICAgZ2V0RGVtb0xvZ2luKHJlcXVlc3RTdHJpbmc6IHN0cmluZyk6IGFueSB7XHJcbiAgICAgICAgbGV0IHRlbXBTdHJpbmc6IHN0cmluZyA9IHJlcXVlc3RTdHJpbmcucmVwbGFjZSgnICcsICcnKTtcclxuICAgICAgICBsZXQgc3BsaXRTdHJpbmc6IEFycmF5PHN0cmluZz4gPSB0ZW1wU3RyaW5nLnNwbGl0KCcsJyk7XHJcbiAgICAgICAgbGV0IGRlbW9JbmZvOiBhbnkgPSB7fTtcclxuICAgICAgICBpZiAoc3BsaXRTdHJpbmcubGVuZ3RoID09PSAyKSB7XHJcbiAgICAgICAgICAgIGRlbW9JbmZvID0ge1xyXG4gICAgICAgICAgICAgICAgdXNlcjogc3BsaXRTdHJpbmdbMF0sXHJcbiAgICAgICAgICAgICAgICBwYXNzOiBzcGxpdFN0cmluZ1sxXVxyXG4gICAgICAgICAgICB9O1xyXG4gICAgICAgIH1cclxuICAgICAgICByZXR1cm4gZGVtb0luZm87XHJcbiAgICB9XHJcblxyXG59XHJcbiJdfQ==