import { Component, Input, Output, EventEmitter, HostListener } from '@angular/core';
import { KdLoginFormControlService } from '../form/kd-loginform-control.service';
import { KdLoginSvc } from '../kd-angular-login-svc';
export class KdLoginForm {
    constructor(_loginSvc, _loginFormSvc) {
        this._loginSvc = _loginSvc;
        this._loginFormSvc = _loginFormSvc;
        this.loginForms = [];
        this.onFormSubmit = new EventEmitter();
        this.onLanguageChange = new EventEmitter();
    }
    onKeyUp(_keyEvent) {
        if (_keyEvent.key === 'Enter') {
            this.buttonSubmit();
        }
    }
    ngOnInit() {
        this.loginForms = this._loginFormSvc.getLoginForm(this.formData);
        this.form = this._loginFormSvc.toFormGroup(this.loginForms);
        //this.defaultVal = this.formData[2].value;
        //console.log('Default value: ' + this.defaultLangVal);
        this.selectedIndex = this.defaultLangVal;
    }
    buttonSubmit() {
        let tempData = {
            formInputs: this.loginForms,
            formValues: this.form.value
        };
        this.onFormSubmit.emit(tempData);
    }
    updateDefaultLanguage() {
        //console.log('From Child: ' + this.selectedIndex);
        this.onLanguageChange.emit(this.selectedIndex);
    }
}
KdLoginForm.decorators = [
    { type: Component, args: [{
                selector: 'kd-loginform',
                template: "<div *ngFor=\"let loginForm of loginForms\">\r\n    <div [formGroup]=\"form\">\r\n        <div [ngSwitch]=\"loginForm.controlType\">\r\n            <div [class]=\"loginForm.class\">\r\n                <!--<i class=\"fa fa-user\"></i>-->\r\n                <input *ngSwitchCase=\"'text'\" [placeholder]=\"loginForm.label\" [formControlName]=\"loginForm.key\" [id]=\"loginForm.key\" [type]=\"loginForm.type\"><i [class]=\"loginForm.iconClass\"></i>\r\n                <div class=\"loginForm.class\" *ngSwitchCase=\"'dropdown'\">\r\n                    <!--<select [id]=\"loginForm.key\" *ngSwitchCase=\"'dropdown'\" [formControlName]=\"loginForm.key\" (ngModelChange)=\"updateLanguage()\">-->\r\n                        <select [id]=\"loginForm.key\" *ngSwitchCase=\"'dropdown'\" [formControlName]=\"loginForm.key\" [(ngModel)]=\"selectedIndex\" (ngModelChange)=\"updateDefaultLanguage()\">\r\n                        <option *ngFor=\"let opt of loginForm.options\" [value]=\"opt.key\">{{opt.value}}</option>\r\n                    </select><i [class]=\"loginForm.iconClass\"></i>\r\n                </div>\r\n            </div>\r\n        </div>\r\n    </div>\r\n</div>\r\n<button name=\"submit\" class=\"btn btn-primary kdx-btn-login\" (click)=\"buttonSubmit()\">{{buttonTitle}}</button>\r\n",
                providers: [
                    KdLoginFormControlService
                ],
                host: { 'class': 'kdx-login' }
            },] }
];
KdLoginForm.ctorParameters = () => [
    { type: KdLoginSvc },
    { type: KdLoginFormControlService }
];
KdLoginForm.propDecorators = {
    formData: [{ type: Input }],
    loginForms: [{ type: Input }],
    config: [{ type: Input }],
    buttonTitle: [{ type: Input }],
    defaultLangVal: [{ type: Input }],
    onFormSubmit: [{ type: Output }],
    onLanguageChange: [{ type: Output }],
    onKeyUp: [{ type: HostListener, args: ['document:keyup', ['$event'],] }]
};
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoia2QtbG9naW5mb3JtLmpzIiwic291cmNlUm9vdCI6IkM6L1Byb2plY3RzL0FuZ3VsYXIvaW9zdGctb3BlbmVtaXMtc3R5bGVndWlkZS9wcm9qZWN0cy9vcGVuZW1pcy1zdHlsZWd1aWRlLWxpYi9zcmMvIiwic291cmNlcyI6WyJrZC1jb21wb25lbnRzL2tkLWFuZ3VsYXItbG9naW4vZm9ybS9rZC1sb2dpbmZvcm0udHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsT0FBTyxFQUNILFNBQVMsRUFDVCxLQUFLLEVBQ0wsTUFBTSxFQUNOLFlBQVksRUFFWixZQUFZLEVBRWYsTUFBTSxlQUFlLENBQUM7QUFHdkIsT0FBTyxFQUFFLHlCQUF5QixFQUFFLE1BQU0sc0NBQXNDLENBQUM7QUFDakYsT0FBTyxFQUFFLFVBQVUsRUFBRSxNQUFNLHlCQUF5QixDQUFDO0FBVXJELE1BQU0sT0FBTyxXQUFXO0lBYXBCLFlBQ1ksU0FBcUIsRUFDckIsYUFBd0M7UUFEeEMsY0FBUyxHQUFULFNBQVMsQ0FBWTtRQUNyQixrQkFBYSxHQUFiLGFBQWEsQ0FBMkI7UUFWM0MsZUFBVSxHQUEyQixFQUFFLENBQUM7UUFLdkMsaUJBQVksR0FBc0IsSUFBSSxZQUFZLEVBQUUsQ0FBQztRQUNyRCxxQkFBZ0IsR0FBc0IsSUFBSSxZQUFZLEVBQUUsQ0FBQztJQUsvRCxDQUFDO0lBR0wsT0FBTyxDQUFDLFNBQXdCO1FBQzVCLElBQUksU0FBUyxDQUFDLEdBQUcsS0FBSyxPQUFPLEVBQUU7WUFDM0IsSUFBSSxDQUFDLFlBQVksRUFBRSxDQUFDO1NBQ3ZCO0lBQ0wsQ0FBQztJQUVELFFBQVE7UUFDSixJQUFJLENBQUMsVUFBVSxHQUFHLElBQUksQ0FBQyxhQUFhLENBQUMsWUFBWSxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsQ0FBQztRQUNqRSxJQUFJLENBQUMsSUFBSSxHQUFHLElBQUksQ0FBQyxhQUFhLENBQUMsV0FBVyxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsQ0FBQztRQUM1RCwyQ0FBMkM7UUFDM0MsdURBQXVEO1FBQ3ZELElBQUksQ0FBQyxhQUFhLEdBQUcsSUFBSSxDQUFDLGNBQWMsQ0FBQztJQUM3QyxDQUFDO0lBRU0sWUFBWTtRQUNmLElBQUksUUFBUSxHQUFRO1lBQ2hCLFVBQVUsRUFBRSxJQUFJLENBQUMsVUFBVTtZQUMzQixVQUFVLEVBQUUsSUFBSSxDQUFDLElBQUksQ0FBQyxLQUFLO1NBQzlCLENBQUE7UUFDRCxJQUFJLENBQUMsWUFBWSxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsQ0FBQztJQUNyQyxDQUFDO0lBRU0scUJBQXFCO1FBQ3hCLG1EQUFtRDtRQUNuRCxJQUFJLENBQUMsZ0JBQWdCLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxhQUFhLENBQUMsQ0FBQztJQUVuRCxDQUFDOzs7WUFyREosU0FBUyxTQUFDO2dCQUNQLFFBQVEsRUFBRSxjQUFjO2dCQUN4Qix1eENBQWtDO2dCQUNsQyxTQUFTLEVBQUU7b0JBQ1AseUJBQXlCO2lCQUFDO2dCQUM5QixJQUFJLEVBQUUsRUFBRSxPQUFPLEVBQUUsV0FBVyxFQUFFO2FBQ2pDOzs7WUFSUSxVQUFVO1lBRFYseUJBQXlCOzs7dUJBZTdCLEtBQUs7eUJBQ0wsS0FBSztxQkFFTCxLQUFLOzBCQUNMLEtBQUs7NkJBQ0wsS0FBSzsyQkFDTCxNQUFNOytCQUNOLE1BQU07c0JBT04sWUFBWSxTQUFDLGdCQUFnQixFQUFFLENBQUMsUUFBUSxDQUFDIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHtcclxuICAgIENvbXBvbmVudCxcclxuICAgIElucHV0LFxyXG4gICAgT3V0cHV0LFxyXG4gICAgRXZlbnRFbWl0dGVyLFxyXG4gICAgSG9zdEJpbmRpbmcsXHJcbiAgICBIb3N0TGlzdGVuZXIsXHJcbiAgICBPbkluaXRcclxufSBmcm9tICdAYW5ndWxhci9jb3JlJztcclxuaW1wb3J0IHsgRm9ybUdyb3VwIH0gZnJvbSAnQGFuZ3VsYXIvZm9ybXMnO1xyXG5pbXBvcnQgeyBLZExvZ2luRm9ybUJhc2UgfSBmcm9tICcuLi9mb3JtL2tkLWxvZ2luZm9ybS1iYXNlJztcclxuaW1wb3J0IHsgS2RMb2dpbkZvcm1Db250cm9sU2VydmljZSB9IGZyb20gJy4uL2Zvcm0va2QtbG9naW5mb3JtLWNvbnRyb2wuc2VydmljZSc7XHJcbmltcG9ydCB7IEtkTG9naW5TdmMgfSBmcm9tICcuLi9rZC1hbmd1bGFyLWxvZ2luLXN2Yyc7XHJcblxyXG5AQ29tcG9uZW50KHtcclxuICAgIHNlbGVjdG9yOiAna2QtbG9naW5mb3JtJyxcclxuICAgIHRlbXBsYXRlVXJsOiAnLi9rZC1sb2dpbmZvcm0uaHRtbCcsXHJcbiAgICBwcm92aWRlcnM6IFtcclxuICAgICAgICBLZExvZ2luRm9ybUNvbnRyb2xTZXJ2aWNlXSxcclxuICAgIGhvc3Q6IHsgJ2NsYXNzJzogJ2tkeC1sb2dpbicgfVxyXG59KVxyXG5cclxuZXhwb3J0IGNsYXNzIEtkTG9naW5Gb3JtIGltcGxlbWVudHMgT25Jbml0IHtcclxuICAgIHB1YmxpYyBmb3JtOiBGb3JtR3JvdXA7XHJcbiAgICBwdWJsaWMgc2VsZWN0ZWRJbmRleDogc3RyaW5nO1xyXG5cclxuICAgIEBJbnB1dCgpIGZvcm1EYXRhOiBBcnJheTxhbnk+O1xyXG4gICAgQElucHV0KCkgbG9naW5Gb3JtczogS2RMb2dpbkZvcm1CYXNlPGFueT5bXSA9IFtdO1xyXG5cclxuICAgIEBJbnB1dCgpIGNvbmZpZzogYW55O1xyXG4gICAgQElucHV0KCkgYnV0dG9uVGl0bGU6IHN0cmluZztcclxuICAgIEBJbnB1dCgpIGRlZmF1bHRMYW5nVmFsOiBzdHJpbmc7XHJcbiAgICBAT3V0cHV0KCkgb25Gb3JtU3VibWl0OiBFdmVudEVtaXR0ZXI8YW55PiA9IG5ldyBFdmVudEVtaXR0ZXIoKTtcclxuICAgIEBPdXRwdXQoKSBvbkxhbmd1YWdlQ2hhbmdlOiBFdmVudEVtaXR0ZXI8YW55PiA9IG5ldyBFdmVudEVtaXR0ZXIoKTtcclxuXHJcbiAgICBjb25zdHJ1Y3RvcihcclxuICAgICAgICBwcml2YXRlIF9sb2dpblN2YzogS2RMb2dpblN2YyxcclxuICAgICAgICBwcml2YXRlIF9sb2dpbkZvcm1TdmM6IEtkTG9naW5Gb3JtQ29udHJvbFNlcnZpY2UsXHJcbiAgICApIHsgfVxyXG5cclxuICAgIEBIb3N0TGlzdGVuZXIoJ2RvY3VtZW50OmtleXVwJywgWyckZXZlbnQnXSlcclxuICAgIG9uS2V5VXAoX2tleUV2ZW50OiBLZXlib2FyZEV2ZW50KSB7XHJcbiAgICAgICAgaWYgKF9rZXlFdmVudC5rZXkgPT09ICdFbnRlcicpIHtcclxuICAgICAgICAgICAgdGhpcy5idXR0b25TdWJtaXQoKTtcclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgbmdPbkluaXQoKTogdm9pZCB7XHJcbiAgICAgICAgdGhpcy5sb2dpbkZvcm1zID0gdGhpcy5fbG9naW5Gb3JtU3ZjLmdldExvZ2luRm9ybSh0aGlzLmZvcm1EYXRhKTtcclxuICAgICAgICB0aGlzLmZvcm0gPSB0aGlzLl9sb2dpbkZvcm1TdmMudG9Gb3JtR3JvdXAodGhpcy5sb2dpbkZvcm1zKTtcclxuICAgICAgICAvL3RoaXMuZGVmYXVsdFZhbCA9IHRoaXMuZm9ybURhdGFbMl0udmFsdWU7XHJcbiAgICAgICAgLy9jb25zb2xlLmxvZygnRGVmYXVsdCB2YWx1ZTogJyArIHRoaXMuZGVmYXVsdExhbmdWYWwpO1xyXG4gICAgICAgIHRoaXMuc2VsZWN0ZWRJbmRleCA9IHRoaXMuZGVmYXVsdExhbmdWYWw7XHJcbiAgICB9XHJcblxyXG4gICAgcHVibGljIGJ1dHRvblN1Ym1pdCgpOiB2b2lkIHtcclxuICAgICAgICBsZXQgdGVtcERhdGE6IGFueSA9IHtcclxuICAgICAgICAgICAgZm9ybUlucHV0czogdGhpcy5sb2dpbkZvcm1zLFxyXG4gICAgICAgICAgICBmb3JtVmFsdWVzOiB0aGlzLmZvcm0udmFsdWVcclxuICAgICAgICB9XHJcbiAgICAgICAgdGhpcy5vbkZvcm1TdWJtaXQuZW1pdCh0ZW1wRGF0YSk7XHJcbiAgICB9XHJcblxyXG4gICAgcHVibGljIHVwZGF0ZURlZmF1bHRMYW5ndWFnZSgpOiB2b2lkIHtcclxuICAgICAgICAvL2NvbnNvbGUubG9nKCdGcm9tIENoaWxkOiAnICsgdGhpcy5zZWxlY3RlZEluZGV4KTtcclxuICAgICAgICB0aGlzLm9uTGFuZ3VhZ2VDaGFuZ2UuZW1pdCh0aGlzLnNlbGVjdGVkSW5kZXgpO1xyXG5cclxuICAgIH1cclxuXHJcblxyXG5cclxufVxyXG4iXX0=