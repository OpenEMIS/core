import { Component, Input } from '@angular/core';
import { FONTAWESOME_FONTS } from './config/config.fa-fonts';
import { KD_FONTS } from './config/config.kd-fonts';
export class KdFonts {
    constructor() {
        this._fontList = [];
    }
    ngOnInit() {
        switch (this.fontType) {
            case 'fa':
                this._fontList = FONTAWESOME_FONTS;
                break;
            default:
                this._fontList = KD_FONTS;
                break;
        }
    }
}
KdFonts.decorators = [
    { type: Component, args: [{
                selector: 'kd-fonts',
                template: `
        <div class="font-containter default-font-size">
            <div *ngFor="let item of _fontList | filter: textFilter" class="col-md-3 col-sm-4" style="height:38px;" [hidden]="item.hidden">
                <i class="fa {{item.text}}"></i> {{item.text}}
            </div>
        </div>
    `
            },] }
];
KdFonts.propDecorators = {
    fontType: [{ type: Input }],
    textFilter: [{ type: Input }]
};
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoia2QtYW5ndWxhci1mb250cy5qcyIsInNvdXJjZVJvb3QiOiJDOi9Qcm9qZWN0cy9Bbmd1bGFyL2lvc3RnLW9wZW5lbWlzLXN0eWxlZ3VpZGUvcHJvamVjdHMvb3BlbmVtaXMtc3R5bGVndWlkZS1saWIvc3JjLyIsInNvdXJjZXMiOlsia2QtY29tcG9uZW50cy9rZC1hbmd1bGFyLWZvbnRzL2tkLWFuZ3VsYXItZm9udHMudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsT0FBTyxFQUFFLFNBQVMsRUFBVSxLQUFLLEVBQUUsTUFBTSxlQUFlLENBQUM7QUFDekQsT0FBTyxFQUFFLGlCQUFpQixFQUFFLE1BQU0sMEJBQTBCLENBQUM7QUFDN0QsT0FBTyxFQUFFLFFBQVEsRUFBRSxNQUFNLDBCQUEwQixDQUFDO0FBYXBELE1BQU0sT0FBTyxPQUFPO0lBWHBCO1FBWVcsY0FBUyxHQUFlLEVBQUUsQ0FBQztJQWV0QyxDQUFDO0lBVkcsUUFBUTtRQUNKLFFBQVEsSUFBSSxDQUFDLFFBQVEsRUFBRTtZQUNuQixLQUFLLElBQUk7Z0JBQ0wsSUFBSSxDQUFDLFNBQVMsR0FBRyxpQkFBaUIsQ0FBQztnQkFDbkMsTUFBTTtZQUNWO2dCQUNJLElBQUksQ0FBQyxTQUFTLEdBQUcsUUFBUSxDQUFDO2dCQUMxQixNQUFNO1NBQ2I7SUFDTCxDQUFDOzs7WUExQkosU0FBUyxTQUFFO2dCQUNSLFFBQVEsRUFBRSxVQUFVO2dCQUNwQixRQUFRLEVBQUU7Ozs7OztLQU1UO2FBQ0o7Ozt1QkFLSSxLQUFLO3lCQUNMLEtBQUsiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBDb21wb25lbnQsIE9uSW5pdCwgSW5wdXQgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcclxuaW1wb3J0IHsgRk9OVEFXRVNPTUVfRk9OVFMgfSBmcm9tICcuL2NvbmZpZy9jb25maWcuZmEtZm9udHMnO1xyXG5pbXBvcnQgeyBLRF9GT05UUyB9IGZyb20gJy4vY29uZmlnL2NvbmZpZy5rZC1mb250cyc7XHJcblxyXG5AQ29tcG9uZW50ICh7XHJcbiAgICBzZWxlY3RvcjogJ2tkLWZvbnRzJyxcclxuICAgIHRlbXBsYXRlOiBgXHJcbiAgICAgICAgPGRpdiBjbGFzcz1cImZvbnQtY29udGFpbnRlciBkZWZhdWx0LWZvbnQtc2l6ZVwiPlxyXG4gICAgICAgICAgICA8ZGl2ICpuZ0Zvcj1cImxldCBpdGVtIG9mIF9mb250TGlzdCB8IGZpbHRlcjogdGV4dEZpbHRlclwiIGNsYXNzPVwiY29sLW1kLTMgY29sLXNtLTRcIiBzdHlsZT1cImhlaWdodDozOHB4O1wiIFtoaWRkZW5dPVwiaXRlbS5oaWRkZW5cIj5cclxuICAgICAgICAgICAgICAgIDxpIGNsYXNzPVwiZmEge3tpdGVtLnRleHR9fVwiPjwvaT4ge3tpdGVtLnRleHR9fVxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8L2Rpdj5cclxuICAgIGBcclxufSlcclxuXHJcbmV4cG9ydCBjbGFzcyBLZEZvbnRzIGltcGxlbWVudHMgT25Jbml0IHtcclxuICAgIHB1YmxpYyBfZm9udExpc3Q6IEFycmF5PGFueT4gPSBbXTtcclxuXHJcbiAgICBASW5wdXQoKSBmb250VHlwZTogc3RyaW5nO1xyXG4gICAgQElucHV0KCkgdGV4dEZpbHRlcjogc3RyaW5nO1xyXG5cclxuICAgIG5nT25Jbml0KCk6IHZvaWQge1xyXG4gICAgICAgIHN3aXRjaCAodGhpcy5mb250VHlwZSkge1xyXG4gICAgICAgICAgICBjYXNlICdmYSc6XHJcbiAgICAgICAgICAgICAgICB0aGlzLl9mb250TGlzdCA9IEZPTlRBV0VTT01FX0ZPTlRTO1xyXG4gICAgICAgICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgICAgIGRlZmF1bHQ6XHJcbiAgICAgICAgICAgICAgICB0aGlzLl9mb250TGlzdCA9IEtEX0ZPTlRTO1xyXG4gICAgICAgICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG59XHJcbiJdfQ==