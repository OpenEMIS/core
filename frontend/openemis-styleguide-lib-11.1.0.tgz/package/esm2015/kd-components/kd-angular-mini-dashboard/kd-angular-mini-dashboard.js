import { Component, ViewEncapsulation, Input, ElementRef, Renderer2, } from '@angular/core';
import { KdDomElemSvc, KdDataSvc } from '../kd-common/index';
import * as types from './kd-angular-mini-dashboard-interface';
import { KdMiniDashboardSvc } from './kd-angular-mini-dashboard-svc';
export class KdMiniDashboard {
    constructor(_kdDomElemSvc, _elementRef, _renderer, _kdMiniDashboardSvc) {
        this._kdMiniDashboardSvc = _kdMiniDashboardSvc;
        this.isOpen = true;
        this.isThreeItem = false;
        this.updatedConfig = {};
        this.direction = 'left';
        this._defaultConfig = {
            closeButtonDisabled: false,
            reopen: true,
        };
        this._item = [];
        this._firstLoad = true;
        this._isWidthChanged = { rowContainer: false };
        this._pChartsFunction = _kdMiniDashboardSvc.pcharts(_elementRef, _renderer);
        this.direction = _kdDomElemSvc.getDocumentDirection(true);
    }
    ngOnInit() {
        this.updatedConfig = Object.assign(this._defaultConfig, this.config);
        this._firstLoad = false;
    }
    ngOnChanges(_simpleChanges) {
        if (_simpleChanges.hasOwnProperty('input'))
            this._item = this._setData(_simpleChanges.input.currentValue);
        if (this._item.length === 3) {
            this._setRowContainerWidthWhenThreeItems();
            this.isThreeItem = true;
        }
        else {
            this.isThreeItem = false;
        }
        if (!this._firstLoad) {
            if (_simpleChanges.hasOwnProperty('config'))
                this.updatedConfig = Object.assign(this.config, _simpleChanges.config.currentValue);
        }
    }
    miniDashboardSwitch() {
        this.isOpen = this.isOpen ? false : true;
    }
    _setData(_item) {
        let processedData = [];
        let noOfLoop = Math.min(_item.length, 4);
        for (let i = 0; i < noOfLoop; i++) {
            if (_item[i].type === 'chart' && _item[i].value) {
                if (!Array.isArray(_item[i].value)) {
                    console.error('value of type: chart must be array');
                    continue;
                }
                let chart = this._pChartsFunction.setChart(_item[i].value, _item[i].config, _item[i].label);
                let final = Object.assign({}, { type: 'chart', isLegendDisplayed: _item[i].config.legend.display }, chart);
                processedData.push(final);
            }
            else if (_item[i].type === 'text') {
                if (typeof _item[i].value !== 'string' && typeof _item[i].value !== 'number') {
                    console.error('value of type: text must be string or number');
                    continue;
                }
                let final = Object.assign({}, _item[i], { value: this._kdMiniDashboardSvc.addThousandSeparator(_item[i].value) });
                processedData.push(final);
            }
        }
        this.itemLength = noOfLoop;
        return processedData;
    }
    _setRowContainerWidthWhenThreeItems() {
        if (480 < window.innerWidth) {
            if (this._isWidthChanged.rowContainer === false) {
                this.isThreeItem = true;
                this._isWidthChanged.rowContainer = true;
            }
        }
        else {
            if (this._isWidthChanged.rowContainer === true) {
                this.isThreeItem = false;
                this._isWidthChanged.rowContainer = false;
            }
        }
    }
}
KdMiniDashboard.decorators = [
    { type: Component, args: [{
                selector: 'kd-mini-dashboard',
                template: "<div *ngIf=\"isOpen\" class=\"kdx-mini-dashboard\" #test>\r\n    <div class=\"kdx-row-container\" *ngFor=\"let item of _item; let i = index \" [ngClass]=\"{'three-item' : isThreeItem }\">\r\n        <ng-container [ngSwitch]=\"item.type\">\r\n            <div class=\"kdx-elem-item chart\" *ngSwitchCase=\"'text'\">\r\n                <div class=\"kdx-item-icon\" *ngIf=\"item.icon\">\r\n                    <i class=\"{{item.icon}}\"></i>\r\n                </div>\r\n                <div class=\"kdx-item-content\">\r\n                    <div class=\"kdx-mini-dashboard-ellipsis item-label\">{{ item.label }}</div>\r\n                    <div class=\"kdx-mini-dashboard-ellipsis item-value\" style=\"margin-top: 20px;font-weight: 400;\">{{ item.value || \"nil\" }}</div>\r\n                </div>\r\n            </div>\r\n            <kd-mini-dashboard-chart \r\n                *ngSwitchCase=\"'chart'\"\r\n                [data]=\"item.data\" \r\n                [options]=\"item.options\" \r\n                [isLegendDisplayed]=\"item.isLegendDisplayed\" \r\n                [itemLength]=\"itemLength\"\r\n                [direction]=\"direction\"\r\n                class=\"kdx-mini-dashboard-chart\"\r\n                >\r\n            </kd-mini-dashboard-chart>\r\n        </ng-container>\r\n    </div>\r\n    <div class=\"kdx-mini-dashboard-button \" *ngIf=\"!updatedConfig.closeButtonDisabled\">\r\n        <button type=\"button\" class=\"kdx-close-mini-dashboard\" (click)=\"miniDashboardSwitch()\"> <i class=\"fa fa-times\"></i> </button>\r\n    </div>\r\n                     \r\n</div>\r\n<button class=\"btn btn-text\" *ngIf=\"!isOpen && updatedConfig.reopen\" (click)=\"miniDashboardSwitch()\"> Open Mini Dashboard</button>\r\n",
                encapsulation: ViewEncapsulation.None,
                providers: [KdMiniDashboardSvc, KdDomElemSvc, KdDataSvc]
            },] }
];
KdMiniDashboard.ctorParameters = () => [
    { type: KdDomElemSvc },
    { type: ElementRef },
    { type: Renderer2 },
    { type: KdMiniDashboardSvc }
];
KdMiniDashboard.propDecorators = {
    config: [{ type: Input }],
    input: [{ type: Input }]
};
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoia2QtYW5ndWxhci1taW5pLWRhc2hib2FyZC5qcyIsInNvdXJjZVJvb3QiOiJDOi9Qcm9qZWN0cy9Bbmd1bGFyL2lvc3RnLW9wZW5lbWlzLXN0eWxlZ3VpZGUvcHJvamVjdHMvb3BlbmVtaXMtc3R5bGVndWlkZS1saWIvc3JjLyIsInNvdXJjZXMiOlsia2QtY29tcG9uZW50cy9rZC1hbmd1bGFyLW1pbmktZGFzaGJvYXJkL2tkLWFuZ3VsYXItbWluaS1kYXNoYm9hcmQudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsT0FBTyxFQUNILFNBQVMsRUFDVCxpQkFBaUIsRUFDakIsS0FBSyxFQUlMLFVBQVUsRUFDVixTQUFTLEdBQ1osTUFBTSxlQUFlLENBQUM7QUFDdkIsT0FBTyxFQUFFLFlBQVksRUFBRSxTQUFTLEVBQUUsTUFBTSxvQkFBb0IsQ0FBQztBQUM3RCxPQUFPLEtBQUssS0FBSyxNQUFNLHVDQUF1QyxDQUFDO0FBQy9ELE9BQU8sRUFBRSxrQkFBa0IsRUFBRSxNQUFNLGlDQUFpQyxDQUFDO0FBU3JFLE1BQU0sT0FBTyxlQUFlO0lBbUJ4QixZQUNJLGFBQTJCLEVBQzNCLFdBQXVCLEVBQ3ZCLFNBQW9CLEVBQ1osbUJBQXVDO1FBQXZDLHdCQUFtQixHQUFuQixtQkFBbUIsQ0FBb0I7UUF0QjVDLFdBQU0sR0FBWSxJQUFJLENBQUM7UUFDdkIsZ0JBQVcsR0FBWSxLQUFLLENBQUM7UUFDN0Isa0JBQWEsR0FBK0IsRUFBRSxDQUFDO1FBQy9DLGNBQVMsR0FBVyxNQUFNLENBQUM7UUFHMUIsbUJBQWMsR0FBK0I7WUFDakQsbUJBQW1CLEVBQUUsS0FBSztZQUMxQixNQUFNLEVBQUUsSUFBSTtTQUNmLENBQUM7UUFDSyxVQUFLLEdBQVEsRUFBRSxDQUFDO1FBQ2YsZUFBVSxHQUFZLElBQUksQ0FBQztRQUUzQixvQkFBZSxHQUE4QixFQUFFLFlBQVksRUFBRSxLQUFLLEVBQUUsQ0FBQztRQVd6RSxJQUFJLENBQUMsZ0JBQWdCLEdBQUcsbUJBQW1CLENBQUMsT0FBTyxDQUFDLFdBQVcsRUFBRSxTQUFTLENBQUMsQ0FBQztRQUM1RSxJQUFJLENBQUMsU0FBUyxHQUFHLGFBQWEsQ0FBQyxvQkFBb0IsQ0FBQyxJQUFJLENBQUMsQ0FBQztJQUM5RCxDQUFDO0lBRUQsUUFBUTtRQUNKLElBQUksQ0FBQyxhQUFhLEdBQUcsTUFBTSxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsY0FBYyxFQUFFLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQztRQUNyRSxJQUFJLENBQUMsVUFBVSxHQUFHLEtBQUssQ0FBQztJQUM1QixDQUFDO0lBRUQsV0FBVyxDQUFDLGNBQTZCO1FBQ3JDLElBQUksY0FBYyxDQUFDLGNBQWMsQ0FBQyxPQUFPLENBQUM7WUFBRSxJQUFJLENBQUMsS0FBSyxHQUFHLElBQUksQ0FBQyxRQUFRLENBQUMsY0FBYyxDQUFDLEtBQUssQ0FBQyxZQUFZLENBQUMsQ0FBQztRQUMxRyxJQUFJLElBQUksQ0FBQyxLQUFLLENBQUMsTUFBTSxLQUFLLENBQUMsRUFBRTtZQUN6QixJQUFJLENBQUMsbUNBQW1DLEVBQUUsQ0FBQztZQUMzQyxJQUFJLENBQUMsV0FBVyxHQUFHLElBQUksQ0FBQztTQUMzQjthQUFNO1lBQUUsSUFBSSxDQUFDLFdBQVcsR0FBRyxLQUFLLENBQUM7U0FBRTtRQUVwQyxJQUFJLENBQUMsSUFBSSxDQUFDLFVBQVUsRUFBRTtZQUNsQixJQUFJLGNBQWMsQ0FBQyxjQUFjLENBQUMsUUFBUSxDQUFDO2dCQUFFLElBQUksQ0FBQyxhQUFhLEdBQUcsTUFBTSxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsTUFBTSxFQUFFLGNBQWMsQ0FBQyxNQUFNLENBQUMsWUFBWSxDQUFDLENBQUM7U0FDcEk7SUFDTCxDQUFDO0lBRU0sbUJBQW1CO1FBQ3RCLElBQUksQ0FBQyxNQUFNLEdBQUcsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUM7SUFDN0MsQ0FBQztJQUVPLFFBQVEsQ0FBQyxLQUFzQztRQUNuRCxJQUFJLGFBQWEsR0FBb0MsRUFBRSxDQUFDO1FBQ3hELElBQUksUUFBUSxHQUFXLElBQUksQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLE1BQU0sRUFBRSxDQUFDLENBQUMsQ0FBQztRQUVqRCxLQUFLLElBQUksQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLEdBQUcsUUFBUSxFQUFFLENBQUMsRUFBRSxFQUFFO1lBQy9CLElBQUksS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksS0FBSyxPQUFPLElBQUksS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssRUFBRTtnQkFDN0MsSUFBSSxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxFQUFFO29CQUNoQyxPQUFPLENBQUMsS0FBSyxDQUFDLG9DQUFvQyxDQUFDLENBQUM7b0JBQ3BELFNBQVM7aUJBQ1o7Z0JBRUQsSUFBSSxLQUFLLEdBQUcsSUFBSSxDQUFDLGdCQUFnQixDQUFDLFFBQVEsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxFQUFFLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLEVBQUUsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDO2dCQUM1RixJQUFJLEtBQUssR0FBRyxNQUFNLENBQUMsTUFBTSxDQUFDLEVBQUUsRUFBRSxFQUFFLElBQUksRUFBRSxPQUFPLEVBQUUsaUJBQWlCLEVBQUUsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsT0FBTyxFQUFFLEVBQUUsS0FBSyxDQUFDLENBQUM7Z0JBQzNHLGFBQWEsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLENBQUM7YUFDN0I7aUJBQ0ksSUFBSSxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxLQUFLLE1BQU0sRUFBRTtnQkFDL0IsSUFBSSxPQUFPLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLEtBQUssUUFBUSxJQUFJLE9BQU8sS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssS0FBSyxRQUFRLEVBQUU7b0JBQzFFLE9BQU8sQ0FBQyxLQUFLLENBQUMsOENBQThDLENBQUMsQ0FBQztvQkFDOUQsU0FBUztpQkFDWjtnQkFDRCxJQUFJLEtBQUssR0FBRyxNQUFNLENBQUMsTUFBTSxDQUFDLEVBQUUsRUFBRSxLQUFLLENBQUMsQ0FBQyxDQUFDLEVBQUUsRUFBRSxLQUFLLEVBQUUsSUFBSSxDQUFDLG1CQUFtQixDQUFDLG9CQUFvQixDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsRUFBRSxDQUFDLENBQUM7Z0JBQ2xILGFBQWEsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLENBQUM7YUFDN0I7U0FDSjtRQUNELElBQUksQ0FBQyxVQUFVLEdBQUcsUUFBUSxDQUFDO1FBQzNCLE9BQU8sYUFBYSxDQUFDO0lBQ3pCLENBQUM7SUFFTyxtQ0FBbUM7UUFDdkMsSUFBSSxHQUFHLEdBQUcsTUFBTSxDQUFDLFVBQVUsRUFBRTtZQUN6QixJQUFJLElBQUksQ0FBQyxlQUFlLENBQUMsWUFBWSxLQUFLLEtBQUssRUFBRTtnQkFDN0MsSUFBSSxDQUFDLFdBQVcsR0FBRyxJQUFJLENBQUM7Z0JBQ3hCLElBQUksQ0FBQyxlQUFlLENBQUMsWUFBWSxHQUFHLElBQUksQ0FBQzthQUM1QztTQUNKO2FBQU07WUFDSCxJQUFJLElBQUksQ0FBQyxlQUFlLENBQUMsWUFBWSxLQUFLLElBQUksRUFBRTtnQkFDNUMsSUFBSSxDQUFDLFdBQVcsR0FBRyxLQUFLLENBQUM7Z0JBQ3pCLElBQUksQ0FBQyxlQUFlLENBQUMsWUFBWSxHQUFHLEtBQUssQ0FBQzthQUM3QztTQUNKO0lBQ0wsQ0FBQzs7O1lBakdKLFNBQVMsU0FBQztnQkFDUCxRQUFRLEVBQUUsbUJBQW1CO2dCQUM3Qiw0dERBQStDO2dCQUMvQyxhQUFhLEVBQUUsaUJBQWlCLENBQUMsSUFBSTtnQkFDckMsU0FBUyxFQUFFLENBQUMsa0JBQWtCLEVBQUUsWUFBWSxFQUFFLFNBQVMsQ0FBQzthQUMzRDs7O1lBVFEsWUFBWTtZQUhqQixVQUFVO1lBQ1YsU0FBUztZQUlKLGtCQUFrQjs7O3FCQXlCdEIsS0FBSztvQkFDTCxLQUFLIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHtcclxuICAgIENvbXBvbmVudCxcclxuICAgIFZpZXdFbmNhcHN1bGF0aW9uLFxyXG4gICAgSW5wdXQsXHJcbiAgICBPbkluaXQsXHJcbiAgICBPbkNoYW5nZXMsXHJcbiAgICBTaW1wbGVDaGFuZ2VzLFxyXG4gICAgRWxlbWVudFJlZixcclxuICAgIFJlbmRlcmVyMixcclxufSBmcm9tICdAYW5ndWxhci9jb3JlJztcclxuaW1wb3J0IHsgS2REb21FbGVtU3ZjLCBLZERhdGFTdmMgfSBmcm9tICcuLi9rZC1jb21tb24vaW5kZXgnO1xyXG5pbXBvcnQgKiBhcyB0eXBlcyBmcm9tICcuL2tkLWFuZ3VsYXItbWluaS1kYXNoYm9hcmQtaW50ZXJmYWNlJztcclxuaW1wb3J0IHsgS2RNaW5pRGFzaGJvYXJkU3ZjIH0gZnJvbSAnLi9rZC1hbmd1bGFyLW1pbmktZGFzaGJvYXJkLXN2Yyc7XHJcblxyXG5AQ29tcG9uZW50KHtcclxuICAgIHNlbGVjdG9yOiAna2QtbWluaS1kYXNoYm9hcmQnLFxyXG4gICAgdGVtcGxhdGVVcmw6ICcuL2tkLWFuZ3VsYXItbWluaS1kYXNoYm9hcmQuaHRtbCcsXHJcbiAgICBlbmNhcHN1bGF0aW9uOiBWaWV3RW5jYXBzdWxhdGlvbi5Ob25lLFxyXG4gICAgcHJvdmlkZXJzOiBbS2RNaW5pRGFzaGJvYXJkU3ZjLCBLZERvbUVsZW1TdmMsIEtkRGF0YVN2Y10sXHJcbn0pXHJcblxyXG5leHBvcnQgY2xhc3MgS2RNaW5pRGFzaGJvYXJkIGltcGxlbWVudHMgT25Jbml0LCBPbkNoYW5nZXMge1xyXG4gICAgcHVibGljIGlzT3BlbjogYm9vbGVhbiA9IHRydWU7XHJcbiAgICBwdWJsaWMgaXNUaHJlZUl0ZW06IGJvb2xlYW4gPSBmYWxzZTtcclxuICAgIHB1YmxpYyB1cGRhdGVkQ29uZmlnOiB0eXBlcy5JTWluaURhc2hib2FyZENvbmZpZyA9IHt9O1xyXG4gICAgcHVibGljIGRpcmVjdGlvbjogc3RyaW5nID0gJ2xlZnQnO1xyXG4gICAgcHVibGljIGl0ZW1MZW5ndGg6IG51bWJlcjtcclxuXHJcbiAgICBwcml2YXRlIF9kZWZhdWx0Q29uZmlnOiB0eXBlcy5JTWluaURhc2hib2FyZENvbmZpZyA9IHtcclxuICAgICAgICBjbG9zZUJ1dHRvbkRpc2FibGVkOiBmYWxzZSxcclxuICAgICAgICByZW9wZW46IHRydWUsXHJcbiAgICB9O1xyXG4gICAgcHVibGljIF9pdGVtOiBhbnkgPSBbXTtcclxuICAgIHByaXZhdGUgX2ZpcnN0TG9hZDogYm9vbGVhbiA9IHRydWU7XHJcbiAgICBwcml2YXRlIF9wQ2hhcnRzRnVuY3Rpb246IHR5cGVzLklDaGFydEZ1bmN0aW9ucztcclxuICAgIHByaXZhdGUgX2lzV2lkdGhDaGFuZ2VkOiB7IHJvd0NvbnRhaW5lcjogYm9vbGVhbiB9ID0geyByb3dDb250YWluZXI6IGZhbHNlIH07XHJcblxyXG4gICAgQElucHV0KCkgY29uZmlnOiB0eXBlcy5JTWluaURhc2hib2FyZENvbmZpZztcclxuICAgIEBJbnB1dCgpIGlucHV0OiBBcnJheTx0eXBlcy5JTWluaURhc2hib2FyZEl0ZW0+O1xyXG5cclxuICAgIGNvbnN0cnVjdG9yKFxyXG4gICAgICAgIF9rZERvbUVsZW1TdmM6IEtkRG9tRWxlbVN2YyxcclxuICAgICAgICBfZWxlbWVudFJlZjogRWxlbWVudFJlZixcclxuICAgICAgICBfcmVuZGVyZXI6IFJlbmRlcmVyMixcclxuICAgICAgICBwcml2YXRlIF9rZE1pbmlEYXNoYm9hcmRTdmM6IEtkTWluaURhc2hib2FyZFN2YyxcclxuICAgICkge1xyXG4gICAgICAgIHRoaXMuX3BDaGFydHNGdW5jdGlvbiA9IF9rZE1pbmlEYXNoYm9hcmRTdmMucGNoYXJ0cyhfZWxlbWVudFJlZiwgX3JlbmRlcmVyKTtcclxuICAgICAgICB0aGlzLmRpcmVjdGlvbiA9IF9rZERvbUVsZW1TdmMuZ2V0RG9jdW1lbnREaXJlY3Rpb24odHJ1ZSk7XHJcbiAgICB9XHJcblxyXG4gICAgbmdPbkluaXQoKTogdm9pZCB7XHJcbiAgICAgICAgdGhpcy51cGRhdGVkQ29uZmlnID0gT2JqZWN0LmFzc2lnbih0aGlzLl9kZWZhdWx0Q29uZmlnLCB0aGlzLmNvbmZpZyk7XHJcbiAgICAgICAgdGhpcy5fZmlyc3RMb2FkID0gZmFsc2U7XHJcbiAgICB9XHJcblxyXG4gICAgbmdPbkNoYW5nZXMoX3NpbXBsZUNoYW5nZXM6IFNpbXBsZUNoYW5nZXMpOiB2b2lkIHtcclxuICAgICAgICBpZiAoX3NpbXBsZUNoYW5nZXMuaGFzT3duUHJvcGVydHkoJ2lucHV0JykpIHRoaXMuX2l0ZW0gPSB0aGlzLl9zZXREYXRhKF9zaW1wbGVDaGFuZ2VzLmlucHV0LmN1cnJlbnRWYWx1ZSk7XHJcbiAgICAgICAgaWYgKHRoaXMuX2l0ZW0ubGVuZ3RoID09PSAzKSB7XHJcbiAgICAgICAgICAgIHRoaXMuX3NldFJvd0NvbnRhaW5lcldpZHRoV2hlblRocmVlSXRlbXMoKTtcclxuICAgICAgICAgICAgdGhpcy5pc1RocmVlSXRlbSA9IHRydWU7XHJcbiAgICAgICAgfSBlbHNlIHsgdGhpcy5pc1RocmVlSXRlbSA9IGZhbHNlOyB9XHJcblxyXG4gICAgICAgIGlmICghdGhpcy5fZmlyc3RMb2FkKSB7XHJcbiAgICAgICAgICAgIGlmIChfc2ltcGxlQ2hhbmdlcy5oYXNPd25Qcm9wZXJ0eSgnY29uZmlnJykpIHRoaXMudXBkYXRlZENvbmZpZyA9IE9iamVjdC5hc3NpZ24odGhpcy5jb25maWcsIF9zaW1wbGVDaGFuZ2VzLmNvbmZpZy5jdXJyZW50VmFsdWUpO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICBwdWJsaWMgbWluaURhc2hib2FyZFN3aXRjaCgpOiB2b2lkIHtcclxuICAgICAgICB0aGlzLmlzT3BlbiA9IHRoaXMuaXNPcGVuID8gZmFsc2UgOiB0cnVlO1xyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX3NldERhdGEoX2l0ZW06IEFycmF5PHR5cGVzLklNaW5pRGFzaGJvYXJkSXRlbT4pOiBBcnJheTx0eXBlcy5JTWluaURhc2hib2FyZEl0ZW0+IHtcclxuICAgICAgICBsZXQgcHJvY2Vzc2VkRGF0YTogQXJyYXk8dHlwZXMuSU1pbmlEYXNoYm9hcmRJdGVtPiA9IFtdO1xyXG4gICAgICAgIGxldCBub09mTG9vcDogbnVtYmVyID0gTWF0aC5taW4oX2l0ZW0ubGVuZ3RoLCA0KTtcclxuXHJcbiAgICAgICAgZm9yIChsZXQgaSA9IDA7IGkgPCBub09mTG9vcDsgaSsrKSB7XHJcbiAgICAgICAgICAgIGlmIChfaXRlbVtpXS50eXBlID09PSAnY2hhcnQnICYmIF9pdGVtW2ldLnZhbHVlKSB7XHJcbiAgICAgICAgICAgICAgICBpZiAoIUFycmF5LmlzQXJyYXkoX2l0ZW1baV0udmFsdWUpKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgY29uc29sZS5lcnJvcigndmFsdWUgb2YgdHlwZTogY2hhcnQgbXVzdCBiZSBhcnJheScpO1xyXG4gICAgICAgICAgICAgICAgICAgIGNvbnRpbnVlO1xyXG4gICAgICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgICAgIGxldCBjaGFydCA9IHRoaXMuX3BDaGFydHNGdW5jdGlvbi5zZXRDaGFydChfaXRlbVtpXS52YWx1ZSwgX2l0ZW1baV0uY29uZmlnLCBfaXRlbVtpXS5sYWJlbCk7XHJcbiAgICAgICAgICAgICAgICBsZXQgZmluYWwgPSBPYmplY3QuYXNzaWduKHt9LCB7IHR5cGU6ICdjaGFydCcsIGlzTGVnZW5kRGlzcGxheWVkOiBfaXRlbVtpXS5jb25maWcubGVnZW5kLmRpc3BsYXkgfSwgY2hhcnQpO1xyXG4gICAgICAgICAgICAgICAgcHJvY2Vzc2VkRGF0YS5wdXNoKGZpbmFsKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBlbHNlIGlmIChfaXRlbVtpXS50eXBlID09PSAndGV4dCcpIHtcclxuICAgICAgICAgICAgICAgIGlmICh0eXBlb2YgX2l0ZW1baV0udmFsdWUgIT09ICdzdHJpbmcnICYmIHR5cGVvZiBfaXRlbVtpXS52YWx1ZSAhPT0gJ251bWJlcicpIHtcclxuICAgICAgICAgICAgICAgICAgICBjb25zb2xlLmVycm9yKCd2YWx1ZSBvZiB0eXBlOiB0ZXh0IG11c3QgYmUgc3RyaW5nIG9yIG51bWJlcicpO1xyXG4gICAgICAgICAgICAgICAgICAgIGNvbnRpbnVlO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgbGV0IGZpbmFsID0gT2JqZWN0LmFzc2lnbih7fSwgX2l0ZW1baV0sIHsgdmFsdWU6IHRoaXMuX2tkTWluaURhc2hib2FyZFN2Yy5hZGRUaG91c2FuZFNlcGFyYXRvcihfaXRlbVtpXS52YWx1ZSkgfSk7XHJcbiAgICAgICAgICAgICAgICBwcm9jZXNzZWREYXRhLnB1c2goZmluYWwpO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgICAgIHRoaXMuaXRlbUxlbmd0aCA9IG5vT2ZMb29wO1xyXG4gICAgICAgIHJldHVybiBwcm9jZXNzZWREYXRhO1xyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX3NldFJvd0NvbnRhaW5lcldpZHRoV2hlblRocmVlSXRlbXMoKTogdm9pZCB7XHJcbiAgICAgICAgaWYgKDQ4MCA8IHdpbmRvdy5pbm5lcldpZHRoKSB7XHJcbiAgICAgICAgICAgIGlmICh0aGlzLl9pc1dpZHRoQ2hhbmdlZC5yb3dDb250YWluZXIgPT09IGZhbHNlKSB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLmlzVGhyZWVJdGVtID0gdHJ1ZTtcclxuICAgICAgICAgICAgICAgIHRoaXMuX2lzV2lkdGhDaGFuZ2VkLnJvd0NvbnRhaW5lciA9IHRydWU7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICBpZiAodGhpcy5faXNXaWR0aENoYW5nZWQucm93Q29udGFpbmVyID09PSB0cnVlKSB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLmlzVGhyZWVJdGVtID0gZmFsc2U7XHJcbiAgICAgICAgICAgICAgICB0aGlzLl9pc1dpZHRoQ2hhbmdlZC5yb3dDb250YWluZXIgPSBmYWxzZTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgIH1cclxufVxyXG4iXX0=