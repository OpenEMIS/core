import { Directive, ElementRef, Input, Renderer2, NgZone, } from '@angular/core';
import { KdDomElemSvc } from '../kd-common/index';
import { DomHandler } from 'primeng/dom';
import { Tooltip } from 'primeng/tooltip';
import { KdSplitterEvent } from '../kd-angular-splitter/index';
export class KdTooltipDirective extends Tooltip {
    // constructor is fully new
    constructor(_el, _zone, _domHandler, _renderer, _kdDomSvc, _kdSplitterEvent) {
        // super(_el, _domHandler, _zone);
        super(_el, _zone);
        this._el = _el;
        this._domHandler = _domHandler;
        this._renderer = _renderer;
        this._isOutOfBounds = false;
        this._deactivateHostListener = false;
        this._offset = { x: 0, y: 0 };
        this._defaultOffset = 10;
        this._isMobile = _kdDomSvc.isMobileDevice();
        this._dragMenuSub = _kdSplitterEvent.onDrag().subscribe(() => {
            super.hide();
        });
        this._toggleMenuSub = _kdSplitterEvent.onToggleMenu().subscribe(() => {
            super.hide();
        });
    }
    ngOnInit() {
        this._initApi();
    }
    onMouseEnter(e) {
        // added extra condition !this._isMobile to if statement
        if (!this._isMobile && !this._deactivateHostListener) {
            if (this.hideTimeout) {
                clearTimeout(this.hideTimeout);
                this.remove();
            }
            super.activate();
        }
    }
    onMouseLeave(e) {
        // added extra condition !this._isMobile to if statement
        if (!this._isMobile && !this._deactivateHostListener) {
            super.deactivate();
        }
    }
    onClick(e) {
        if (!this._deactivateHostListener) {
            // when mobile device, click will activate the tooltip. when web, click will deactivate the tooltip
            if (!this._isMobile) {
                super.deactivate();
            }
            else {
                if (this.hideTimeout) {
                    clearTimeout(this.hideTimeout);
                    this.remove();
                }
                super.activate();
            }
        }
    }
    // changed Input param to 'kd-tooltip-dir' (old input was: pTooltip)
    set Text(text) {
        this._text = text;
        if (this.active) {
            if (this._text) {
                if (this.container && this.container.offsetParent) {
                    super.updateText();
                }
                else {
                    this.show();
                }
            }
            else {
                super.hide();
            }
        }
    }
    show() {
        if (!this._text || this.disabled) {
            return;
        }
        super.create();
        this.align();
        DomHandler.fadeIn(this.container, 250);
        if (this.tooltipZIndex === 'auto') {
            this.container.style.zIndex = ++DomHandler.zindex;
        }
        else {
            this.container.style.zIndex = this.tooltipZIndex;
        }
        if (!this._deactivateHostListener) {
            super.bindDocumentResizeListener();
            // added 1 line. _bindDocumentTouchStartListener()
            if (this._isMobile)
                this._bindDocumentTouchStartListener();
        }
    }
    align() {
        let position = this.tooltipPosition;
        this._widthOutsideViewport = null;
        switch (position) {
            case 'top':
                this.alignTop();
                // added 1 line. _widthOutsideViewport
                // this._isOutofBounds is used instead of super.OutofBounds
                if (this._isOutOfBounds) {
                    this.alignTopRight();
                    if (this._isOutOfBounds) {
                        this.alignTopLeft();
                        if (this._isOutOfBounds) {
                            this._widthOutsideViewport = this._calculateWidthOut();
                            this.alignBottom(this._widthOutsideViewport);
                        }
                    }
                }
                break;
            case 'top-right':
                this.alignTopRight();
                // added 1 line. _widthOutsideViewport
                if (this._isOutOfBounds) {
                    this.alignTop();
                    if (this._isOutOfBounds) {
                        this.alignTopLeft();
                        if (this._isOutOfBounds) {
                            this._widthOutsideViewport = this._calculateWidthOut();
                            this.alignBottom(this._widthOutsideViewport);
                        }
                    }
                }
                break;
            case 'top-left':
                this.alignTopLeft();
                // added 1 line. _widthOutsideViewport
                if (this._isOutOfBounds) {
                    this.alignTop();
                    if (this._isOutOfBounds) {
                        this.alignTopRight();
                        if (this._isOutOfBounds) {
                            this._widthOutsideViewport = this._calculateWidthOut();
                            this.alignBottom(this._widthOutsideViewport);
                        }
                    }
                }
                break;
            case 'bottom':
                this.alignBottom();
                // added 1 line. _widthOutsideViewport
                if (this._isOutOfBounds) {
                    this.alignBottomRight();
                    if (this._isOutOfBounds) {
                        this.alignBottomLeft();
                        if (this._isOutOfBounds) {
                            // added 1 line. edited alignTop with param
                            this._widthOutsideViewport = this._calculateWidthOut();
                            this.alignTop(this._widthOutsideViewport);
                        }
                    }
                }
                break;
            case 'bottom-right':
                this.alignBottomRight();
                // added 1 line. _widthOutsideViewport
                if (this._isOutOfBounds) {
                    this.alignBottom();
                    if (this._isOutOfBounds) {
                        this.alignBottomLeft();
                        if (this._isOutOfBounds) {
                            // added 1 line. edited alignTop with param
                            this._widthOutsideViewport = this._calculateWidthOut();
                            this.alignTop(this._widthOutsideViewport);
                        }
                    }
                }
                break;
            case 'bottom-left':
                this.alignBottomLeft();
                // added 1 line. _widthOutsideViewport
                if (this._isOutOfBounds) {
                    this.alignBottom();
                    if (this._isOutOfBounds) {
                        this.alignBottomRight();
                        if (this._isOutOfBounds) {
                            // added 1 line. edited alignTop with param
                            this._widthOutsideViewport = this._calculateWidthOut();
                            this.alignTop(this._widthOutsideViewport);
                        }
                    }
                }
                break;
            case 'left':
                this.alignLeft();
                if (this._isOutOfBounds) {
                    this.alignRight();
                    if (this._isOutOfBounds) {
                        this.alignTop();
                        if (this._isOutOfBounds) {
                            // added 1 line. edited alignBottom with param
                            this._widthOutsideViewport = this._calculateWidthOut();
                            this.alignBottom(this._calculateWidthOut());
                        }
                    }
                }
                break;
            case 'right':
                this.alignRight();
                if (this._isOutOfBounds) {
                    this.alignLeft();
                    if (this._isOutOfBounds) {
                        this.alignTop();
                        if (this._isOutOfBounds) {
                            // added 1 line. edited alignBottom with param
                            this.alignBottom(this._calculateWidthOut());
                        }
                    }
                }
                break;
        }
    }
    alignRight() {
        // added 1 line. edited preAlign with param
        this.preAlign('right');
        let hostOffset = super.getHostOffset();
        let width = DomHandler.getOuterWidth(this.container);
        let height = DomHandler.getOuterHeight(this.container);
        let left = hostOffset.left + DomHandler.getOuterWidth(this._el.nativeElement) + this._offset.x;
        let top = hostOffset.top + (DomHandler.getOuterHeight(this._el.nativeElement) - DomHandler.getOuterHeight(this.container)) / 2 - 1 + this._offset.y;
        this._isOutOfBounds = this._checkOutOfBounds(left, top, width, height);
        this.container.style.left = left + 'px';
        this.container.style.top = top + 'px';
    }
    alignLeft() {
        // added 1 line. edited preAlign with param
        this.preAlign('left');
        let hostOffset = super.getHostOffset();
        let width = DomHandler.getOuterWidth(this.container);
        let height = DomHandler.getOuterHeight(this.container);
        let left = hostOffset.left - DomHandler.getOuterWidth(this.container) + this._offset.x;
        let top = hostOffset.top + (DomHandler.getOuterHeight(this._el.nativeElement) - DomHandler.getOuterHeight(this.container)) / 2 + this._offset.y;
        this._isOutOfBounds = this._checkOutOfBounds(left, top, width, height);
        this.container.style.left = left + 'px';
        this.container.style.top = top + 'px';
    }
    alignTop(widthOut) {
        // added 2 line. edited preAlign with param and widthOut
        this.preAlign('top');
        if (widthOut !== 0 && typeof widthOut !== 'undefined') {
            this.container.style.maxWidth = (DomHandler.getOuterWidth(this.container) - widthOut * 2).toString() + 'px';
        }
        let hostOffset = super.getHostOffset();
        let width = DomHandler.getOuterWidth(this.container);
        let height = DomHandler.getOuterHeight(this.container);
        let left = hostOffset.left + (DomHandler.getOuterWidth(this._el.nativeElement) - DomHandler.getOuterWidth(this.container)) / 2 + this._offset.x;
        let top = hostOffset.top - DomHandler.getOuterHeight(this.container) + this._offset.y;
        this._isOutOfBounds = this._checkOutOfBounds(left, top, width, height);
        this.container.style.left = left + 'px';
        this.container.style.top = top + 'px';
    }
    // new direction
    alignTopRight(widthOut) {
        this.preAlign('top ui-tooltip-top-right');
        if (widthOut !== 0 && typeof widthOut !== 'undefined')
            this.container.style.maxWidth = (DomHandler.getOuterWidth(this.container) - widthOut * 2).toString() + 'px';
        let hostOffset = super.getHostOffset();
        let width = DomHandler.getOuterWidth(this.container);
        let height = DomHandler.getOuterHeight(this.container);
        let left = hostOffset.left + DomHandler.getOuterWidth(this._el.nativeElement) / 2 - this._defaultOffset + this._offset.x;
        let top = hostOffset.top - DomHandler.getOuterHeight(this.container) + this._offset.y;
        this._isOutOfBounds = this._checkOutOfBounds(left, top, width, height);
        this.container.style.left = left + 'px';
        this.container.style.top = top + 'px';
    }
    // new direction
    alignTopLeft(widthOut) {
        this.preAlign('top ui-tooltip-top-left');
        if (widthOut !== 0 && typeof widthOut !== 'undefined')
            this.container.style.maxWidth = (DomHandler.getOuterWidth(this.container) - widthOut * 2).toString() + 'px';
        let hostOffset = super.getHostOffset();
        let width = DomHandler.getOuterWidth(this.container);
        let height = DomHandler.getOuterHeight(this.container);
        let left = hostOffset.left + DomHandler.getOuterWidth(this._el.nativeElement) / 2 - DomHandler.getOuterWidth(this.container) + this._defaultOffset + this._offset.x;
        let top = hostOffset.top - DomHandler.getOuterHeight(this.container) + this._offset.y;
        this._isOutOfBounds = this._checkOutOfBounds(left, top, width, height);
        this.container.style.left = left + 'px';
        this.container.style.top = top + 'px';
    }
    alignBottom(widthOut) {
        // added 2 line. edited preAlign with param and widthOut
        this.preAlign('bottom');
        if (widthOut !== 0 && typeof widthOut !== 'undefined')
            this.container.style.maxWidth = (DomHandler.getOuterWidth(this.container) - widthOut * 2).toString() + 'px';
        let hostOffset = super.getHostOffset();
        let width = DomHandler.getOuterWidth(this.container);
        let height = DomHandler.getOuterHeight(this.container);
        let left = hostOffset.left + (DomHandler.getOuterWidth(this._el.nativeElement) - DomHandler.getOuterWidth(this.container)) / 2 + this._offset.x;
        let top = hostOffset.top + DomHandler.getOuterHeight(this._el.nativeElement) + this._offset.y;
        this._isOutOfBounds = this._checkOutOfBounds(left, top, width, height);
        this.container.style.left = left + 'px';
        this.container.style.top = top + 'px';
    }
    // new direction
    alignBottomRight(widthOut) {
        this.preAlign('bottom ui-tooltip-bottom-right');
        if (widthOut !== 0 && typeof widthOut !== 'undefined')
            this.container.style.maxWidth = (DomHandler.getOuterWidth(this.container) - widthOut * 2).toString() + 'px';
        let hostOffset = super.getHostOffset();
        let width = DomHandler.getOuterWidth(this.container);
        let height = DomHandler.getOuterHeight(this.container);
        let left = hostOffset.left + DomHandler.getOuterWidth(this._el.nativeElement) / 2 - this._defaultOffset + this._offset.x;
        let top = hostOffset.top + DomHandler.getOuterHeight(this._el.nativeElement) + this._offset.y;
        this._isOutOfBounds = this._checkOutOfBounds(left, top, width, height);
        this.container.style.left = left + 'px';
        this.container.style.top = top + 'px';
    }
    // new direction
    alignBottomLeft(widthOut) {
        this.preAlign('bottom ui-tooltip-bottom-left');
        if (widthOut !== 0 && typeof widthOut !== 'undefined')
            this.container.style.maxWidth = (DomHandler.getOuterWidth(this.container) - widthOut * 2).toString() + 'px';
        let hostOffset = super.getHostOffset();
        let width = DomHandler.getOuterWidth(this.container);
        let height = DomHandler.getOuterHeight(this.container);
        let left = hostOffset.left + DomHandler.getOuterWidth(this._el.nativeElement) / 2 - DomHandler.getOuterWidth(this.container) + this._defaultOffset + this._offset.x;
        let top = hostOffset.top + DomHandler.getOuterHeight(this._el.nativeElement) + this._offset.y;
        this._isOutOfBounds = this._checkOutOfBounds(left, top, width, height);
        this.container.style.left = left + 'px';
        this.container.style.top = top + 'px';
    }
    preAlign(_position) {
        this.container.style.left = -999 + 'px';
        this.container.style.top = -999 + 'px';
        // added 2 line. defaultClassName and container.className
        let defaultClassName = 'ui-tooltip ui-widget ui-tooltip-' + _position;
        this.container.className = this.tooltipStyleClass ? defaultClassName + ' ' + this.tooltipStyleClass : defaultClassName;
    }
    // temp fix: checking out of bounds should happen before wordwrap changes the size on tooltip
    _checkOutOfBounds(_left, _top, _width, _height) {
        let viewport = DomHandler.getViewport();
        return (_left + _width > viewport.width) || (_left < 0) || (_top < 0) || (_top + _height > viewport.height);
    }
    remove() {
        if (!this._deactivateHostListener) {
            // added one line, _unbindDocumentTouchStartListner()
            if (this._isMobile)
                this._unbindDocumentTouchStartListner();
        }
        if (this.container && this.container.parentElement) {
            if (this.appendTo === 'body') {
                document.body.removeChild(this.container);
            }
            else if (this.appendTo === 'target') {
                this._el.nativeElement.removeChild(this.container);
            }
            else {
                DomHandler.removeChild(this.container, this.appendTo);
            }
        }
        this.container = null;
    }
    /********New Functions***********/
    _initApi() {
        if (typeof this.api !== 'undefined') {
            this.api.showTooltip = () => super.activate();
            this.api.hideTooltip = () => super.deactivate();
            this.api.deactivateHostListener = () => { this._deactivateHostListener = true; };
            this.api.activateHostListener = () => { this._deactivateHostListener = false; };
            this.api.align = () => {
                if (!this.container)
                    return;
                this.align();
            };
            this.api.setOffset = (_offset) => { this._offset = _offset; };
        }
    }
    _calculateWidthOut() {
        let offset = this.container.getBoundingClientRect();
        let targetLeft = offset.left;
        let width = DomHandler.getOuterWidth(this.container);
        let viewport = DomHandler.getViewport();
        if (targetLeft + width - viewport.width > 0)
            return targetLeft + width - viewport.width;
        if (targetLeft < 0)
            return targetLeft * -1;
        return 0;
    }
    _bindDocumentTouchStartListener() {
        this._documentTouchStartListener = this._renderer.listen('document', 'touchstart', event => {
            super.hide();
        });
    }
    _unbindDocumentTouchStartListner() {
        if (this._documentTouchStartListener) {
            this._documentTouchStartListener();
            this._documentTouchStartListener = null;
        }
    }
    ngOnDestroy() {
        // super.unbindEvents();
        this.remove();
        // added 2 line. unsubscription
        this._dragMenuSub.unsubscribe();
        this._toggleMenuSub.unsubscribe();
    }
}
KdTooltipDirective.decorators = [
    { type: Directive, args: [{
                selector: '[kd-tooltip-dir]',
                providers: [DomHandler, KdDomElemSvc, KdSplitterEvent],
            },] }
];
KdTooltipDirective.ctorParameters = () => [
    { type: ElementRef },
    { type: NgZone },
    { type: DomHandler },
    { type: Renderer2 },
    { type: KdDomElemSvc },
    { type: KdSplitterEvent }
];
KdTooltipDirective.propDecorators = {
    api: [{ type: Input }],
    Text: [{ type: Input, args: ['kd-tooltip-dir',] }]
};
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoia2QtYW5ndWxhci10b29sdGlwLWRpcmVjdGl2ZS5qcyIsInNvdXJjZVJvb3QiOiJDOi9Qcm9qZWN0cy9Bbmd1bGFyL2lvc3RnLW9wZW5lbWlzLXN0eWxlZ3VpZGUvcHJvamVjdHMvb3BlbmVtaXMtc3R5bGVndWlkZS1saWIvc3JjLyIsInNvdXJjZXMiOlsia2QtY29tcG9uZW50cy9rZC1hbmd1bGFyLXRvb2x0aXAva2QtYW5ndWxhci10b29sdGlwLWRpcmVjdGl2ZS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQSxPQUFPLEVBQ0gsU0FBUyxFQUNULFVBQVUsRUFHVixLQUFLLEVBQ0wsU0FBUyxFQUNULE1BQU0sR0FDVCxNQUFNLGVBQWUsQ0FBQztBQUN2QixPQUFPLEVBQUUsWUFBWSxFQUFFLE1BQU0sb0JBQW9CLENBQUM7QUFDbEQsT0FBTyxFQUFDLFVBQVUsRUFBQyxNQUFNLGFBQWEsQ0FBQztBQUN2QyxPQUFPLEVBQUUsT0FBTyxFQUFFLE1BQU0saUJBQWlCLENBQUM7QUFDMUMsT0FBTyxFQUFFLGVBQWUsRUFBRSxNQUFNLDhCQUE4QixDQUFDO0FBZ0IvRCxNQUFNLE9BQU8sa0JBQW1CLFNBQVEsT0FBTztJQWUzQywyQkFBMkI7SUFDM0IsWUFDWSxHQUFlLEVBQ3ZCLEtBQWEsRUFDTCxXQUF1QixFQUN2QixTQUFvQixFQUM1QixTQUF1QixFQUN2QixnQkFBaUM7UUFFakMsa0NBQWtDO1FBQ2xDLEtBQUssQ0FBQyxHQUFHLEVBQUUsS0FBSyxDQUFDLENBQUM7UUFSVixRQUFHLEdBQUgsR0FBRyxDQUFZO1FBRWYsZ0JBQVcsR0FBWCxXQUFXLENBQVk7UUFDdkIsY0FBUyxHQUFULFNBQVMsQ0FBVztRQWR4QixtQkFBYyxHQUFZLEtBQUssQ0FBQztRQUdoQyw0QkFBdUIsR0FBWSxLQUFLLENBQUM7UUFDekMsWUFBTyxHQUE2QixFQUFFLENBQUMsRUFBRSxDQUFDLEVBQUUsQ0FBQyxFQUFFLENBQUMsRUFBRSxDQUFDO1FBQ25ELG1CQUFjLEdBQVcsRUFBRSxDQUFDO1FBZ0JoQyxJQUFJLENBQUMsU0FBUyxHQUFHLFNBQVMsQ0FBQyxjQUFjLEVBQUUsQ0FBQztRQUM1QyxJQUFJLENBQUMsWUFBWSxHQUFHLGdCQUFnQixDQUFDLE1BQU0sRUFBRSxDQUFDLFNBQVMsQ0FBQyxHQUFTLEVBQUU7WUFDL0QsS0FBSyxDQUFDLElBQUksRUFBRSxDQUFDO1FBQ2pCLENBQUMsQ0FBQyxDQUFDO1FBQ0gsSUFBSSxDQUFDLGNBQWMsR0FBRyxnQkFBZ0IsQ0FBQyxZQUFZLEVBQUUsQ0FBQyxTQUFTLENBQUMsR0FBUyxFQUFFO1lBQ3ZFLEtBQUssQ0FBQyxJQUFJLEVBQUUsQ0FBQztRQUNqQixDQUFDLENBQUMsQ0FBQztJQUNQLENBQUM7SUFFRCxRQUFRO1FBQ0osSUFBSSxDQUFDLFFBQVEsRUFBRSxDQUFDO0lBQ3BCLENBQUM7SUFFRCxZQUFZLENBQUMsQ0FBUTtRQUNqQix3REFBd0Q7UUFDeEQsSUFBSSxDQUFDLElBQUksQ0FBQyxTQUFTLElBQUksQ0FBQyxJQUFJLENBQUMsdUJBQXVCLEVBQUU7WUFDbEQsSUFBSSxJQUFJLENBQUMsV0FBVyxFQUFFO2dCQUNsQixZQUFZLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxDQUFDO2dCQUMvQixJQUFJLENBQUMsTUFBTSxFQUFFLENBQUM7YUFDakI7WUFDRCxLQUFLLENBQUMsUUFBUSxFQUFFLENBQUM7U0FDcEI7SUFDTCxDQUFDO0lBRUQsWUFBWSxDQUFDLENBQVE7UUFDakIsd0RBQXdEO1FBQ3hELElBQUksQ0FBQyxJQUFJLENBQUMsU0FBUyxJQUFJLENBQUMsSUFBSSxDQUFDLHVCQUF1QixFQUFFO1lBQ2xELEtBQUssQ0FBQyxVQUFVLEVBQUUsQ0FBQztTQUN0QjtJQUNMLENBQUM7SUFFRCxPQUFPLENBQUMsQ0FBUTtRQUNaLElBQUksQ0FBQyxJQUFJLENBQUMsdUJBQXVCLEVBQUU7WUFDL0IsbUdBQW1HO1lBQ25HLElBQUksQ0FBQyxJQUFJLENBQUMsU0FBUyxFQUFFO2dCQUNqQixLQUFLLENBQUMsVUFBVSxFQUFFLENBQUM7YUFDdEI7aUJBQU07Z0JBQ0gsSUFBSSxJQUFJLENBQUMsV0FBVyxFQUFFO29CQUNsQixZQUFZLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxDQUFDO29CQUMvQixJQUFJLENBQUMsTUFBTSxFQUFFLENBQUM7aUJBQ2pCO2dCQUVELEtBQUssQ0FBQyxRQUFRLEVBQUUsQ0FBQzthQUNwQjtTQUNKO0lBQ0wsQ0FBQztJQUVELG9FQUFvRTtJQUNwRSxJQUE2QixJQUFJLENBQUMsSUFBWTtRQUMxQyxJQUFJLENBQUMsS0FBSyxHQUFHLElBQUksQ0FBQztRQUNsQixJQUFJLElBQUksQ0FBQyxNQUFNLEVBQUU7WUFDYixJQUFJLElBQUksQ0FBQyxLQUFLLEVBQUU7Z0JBQ1osSUFBSSxJQUFJLENBQUMsU0FBUyxJQUFJLElBQUksQ0FBQyxTQUFTLENBQUMsWUFBWSxFQUFFO29CQUMvQyxLQUFLLENBQUMsVUFBVSxFQUFFLENBQUM7aUJBQ3RCO3FCQUFNO29CQUNILElBQUksQ0FBQyxJQUFJLEVBQUUsQ0FBQztpQkFDZjthQUNKO2lCQUNJO2dCQUNELEtBQUssQ0FBQyxJQUFJLEVBQUUsQ0FBQzthQUNoQjtTQUNKO0lBQ0wsQ0FBQztJQUVNLElBQUk7UUFDUCxJQUFJLENBQUMsSUFBSSxDQUFDLEtBQUssSUFBSSxJQUFJLENBQUMsUUFBUSxFQUFFO1lBQzlCLE9BQU87U0FDVjtRQUNELEtBQUssQ0FBQyxNQUFNLEVBQUUsQ0FBQztRQUNmLElBQUksQ0FBQyxLQUFLLEVBQUUsQ0FBQztRQUViLFVBQVUsQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLFNBQVMsRUFBRSxHQUFHLENBQUMsQ0FBQztRQUN2QyxJQUFJLElBQUksQ0FBQyxhQUFhLEtBQUssTUFBTSxFQUFFO1lBQy9CLElBQUksQ0FBQyxTQUFTLENBQUMsS0FBSyxDQUFDLE1BQU0sR0FBRyxFQUFFLFVBQVUsQ0FBQyxNQUFNLENBQUM7U0FDckQ7YUFBTTtZQUNILElBQUksQ0FBQyxTQUFTLENBQUMsS0FBSyxDQUFDLE1BQU0sR0FBRyxJQUFJLENBQUMsYUFBYSxDQUFDO1NBQ3BEO1FBQ0QsSUFBSSxDQUFDLElBQUksQ0FBQyx1QkFBdUIsRUFBRTtZQUMvQixLQUFLLENBQUMsMEJBQTBCLEVBQUUsQ0FBQztZQUNuQyxrREFBa0Q7WUFDbEQsSUFBSSxJQUFJLENBQUMsU0FBUztnQkFBRSxJQUFJLENBQUMsK0JBQStCLEVBQUUsQ0FBQztTQUM5RDtJQUNMLENBQUM7SUFFTSxLQUFLO1FBQ1IsSUFBSSxRQUFRLEdBQVcsSUFBSSxDQUFDLGVBQWUsQ0FBQztRQUM1QyxJQUFJLENBQUMscUJBQXFCLEdBQUcsSUFBSSxDQUFDO1FBRWxDLFFBQVEsUUFBUSxFQUFFO1lBQ2QsS0FBSyxLQUFLO2dCQUNOLElBQUksQ0FBQyxRQUFRLEVBQUUsQ0FBQztnQkFDaEIsc0NBQXNDO2dCQUN0QywyREFBMkQ7Z0JBQzNELElBQUksSUFBSSxDQUFDLGNBQWMsRUFBRTtvQkFDckIsSUFBSSxDQUFDLGFBQWEsRUFBRSxDQUFDO29CQUVyQixJQUFJLElBQUksQ0FBQyxjQUFjLEVBQUU7d0JBQ3JCLElBQUksQ0FBQyxZQUFZLEVBQUUsQ0FBQzt3QkFFcEIsSUFBSSxJQUFJLENBQUMsY0FBYyxFQUFFOzRCQUNyQixJQUFJLENBQUMscUJBQXFCLEdBQUcsSUFBSSxDQUFDLGtCQUFrQixFQUFFLENBQUM7NEJBQ3ZELElBQUksQ0FBQyxXQUFXLENBQUMsSUFBSSxDQUFDLHFCQUFxQixDQUFDLENBQUM7eUJBQ2hEO3FCQUNKO2lCQUNKO2dCQUNELE1BQU07WUFFVixLQUFLLFdBQVc7Z0JBQ1osSUFBSSxDQUFDLGFBQWEsRUFBRSxDQUFDO2dCQUNyQixzQ0FBc0M7Z0JBQ3RDLElBQUksSUFBSSxDQUFDLGNBQWMsRUFBRTtvQkFDckIsSUFBSSxDQUFDLFFBQVEsRUFBRSxDQUFDO29CQUVoQixJQUFJLElBQUksQ0FBQyxjQUFjLEVBQUU7d0JBQ3JCLElBQUksQ0FBQyxZQUFZLEVBQUUsQ0FBQzt3QkFFcEIsSUFBSSxJQUFJLENBQUMsY0FBYyxFQUFFOzRCQUNyQixJQUFJLENBQUMscUJBQXFCLEdBQUcsSUFBSSxDQUFDLGtCQUFrQixFQUFFLENBQUM7NEJBQ3ZELElBQUksQ0FBQyxXQUFXLENBQUMsSUFBSSxDQUFDLHFCQUFxQixDQUFDLENBQUM7eUJBQ2hEO3FCQUNKO2lCQUNKO2dCQUNELE1BQU07WUFFVixLQUFLLFVBQVU7Z0JBQ1gsSUFBSSxDQUFDLFlBQVksRUFBRSxDQUFDO2dCQUNwQixzQ0FBc0M7Z0JBQ3RDLElBQUksSUFBSSxDQUFDLGNBQWMsRUFBRTtvQkFDckIsSUFBSSxDQUFDLFFBQVEsRUFBRSxDQUFDO29CQUVoQixJQUFJLElBQUksQ0FBQyxjQUFjLEVBQUU7d0JBQ3JCLElBQUksQ0FBQyxhQUFhLEVBQUUsQ0FBQzt3QkFFckIsSUFBSSxJQUFJLENBQUMsY0FBYyxFQUFFOzRCQUNyQixJQUFJLENBQUMscUJBQXFCLEdBQUcsSUFBSSxDQUFDLGtCQUFrQixFQUFFLENBQUM7NEJBQ3ZELElBQUksQ0FBQyxXQUFXLENBQUMsSUFBSSxDQUFDLHFCQUFxQixDQUFDLENBQUM7eUJBQ2hEO3FCQUNKO2lCQUNKO2dCQUNELE1BQU07WUFFVixLQUFLLFFBQVE7Z0JBQ1QsSUFBSSxDQUFDLFdBQVcsRUFBRSxDQUFDO2dCQUNuQixzQ0FBc0M7Z0JBQ3RDLElBQUksSUFBSSxDQUFDLGNBQWMsRUFBRTtvQkFDckIsSUFBSSxDQUFDLGdCQUFnQixFQUFFLENBQUM7b0JBRXhCLElBQUksSUFBSSxDQUFDLGNBQWMsRUFBRTt3QkFDckIsSUFBSSxDQUFDLGVBQWUsRUFBRSxDQUFDO3dCQUV2QixJQUFJLElBQUksQ0FBQyxjQUFjLEVBQUU7NEJBQ3JCLDJDQUEyQzs0QkFDM0MsSUFBSSxDQUFDLHFCQUFxQixHQUFHLElBQUksQ0FBQyxrQkFBa0IsRUFBRSxDQUFDOzRCQUN2RCxJQUFJLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxxQkFBcUIsQ0FBQyxDQUFDO3lCQUM3QztxQkFDSjtpQkFDSjtnQkFDRCxNQUFNO1lBRVYsS0FBSyxjQUFjO2dCQUNmLElBQUksQ0FBQyxnQkFBZ0IsRUFBRSxDQUFDO2dCQUN4QixzQ0FBc0M7Z0JBQ3RDLElBQUksSUFBSSxDQUFDLGNBQWMsRUFBRTtvQkFDckIsSUFBSSxDQUFDLFdBQVcsRUFBRSxDQUFDO29CQUVuQixJQUFJLElBQUksQ0FBQyxjQUFjLEVBQUU7d0JBQ3JCLElBQUksQ0FBQyxlQUFlLEVBQUUsQ0FBQzt3QkFFdkIsSUFBSSxJQUFJLENBQUMsY0FBYyxFQUFFOzRCQUNyQiwyQ0FBMkM7NEJBQzNDLElBQUksQ0FBQyxxQkFBcUIsR0FBRyxJQUFJLENBQUMsa0JBQWtCLEVBQUUsQ0FBQzs0QkFDdkQsSUFBSSxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMscUJBQXFCLENBQUMsQ0FBQzt5QkFDN0M7cUJBQ0o7aUJBQ0o7Z0JBQ0QsTUFBTTtZQUVWLEtBQUssYUFBYTtnQkFDZCxJQUFJLENBQUMsZUFBZSxFQUFFLENBQUM7Z0JBQ3ZCLHNDQUFzQztnQkFDdEMsSUFBSSxJQUFJLENBQUMsY0FBYyxFQUFFO29CQUNyQixJQUFJLENBQUMsV0FBVyxFQUFFLENBQUM7b0JBRW5CLElBQUksSUFBSSxDQUFDLGNBQWMsRUFBRTt3QkFDckIsSUFBSSxDQUFDLGdCQUFnQixFQUFFLENBQUM7d0JBRXhCLElBQUksSUFBSSxDQUFDLGNBQWMsRUFBRTs0QkFDckIsMkNBQTJDOzRCQUMzQyxJQUFJLENBQUMscUJBQXFCLEdBQUcsSUFBSSxDQUFDLGtCQUFrQixFQUFFLENBQUM7NEJBQ3ZELElBQUksQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLHFCQUFxQixDQUFDLENBQUM7eUJBQzdDO3FCQUNKO2lCQUNKO2dCQUNELE1BQU07WUFFVixLQUFLLE1BQU07Z0JBQ1AsSUFBSSxDQUFDLFNBQVMsRUFBRSxDQUFDO2dCQUNqQixJQUFJLElBQUksQ0FBQyxjQUFjLEVBQUU7b0JBQ3JCLElBQUksQ0FBQyxVQUFVLEVBQUUsQ0FBQztvQkFFbEIsSUFBSSxJQUFJLENBQUMsY0FBYyxFQUFFO3dCQUNyQixJQUFJLENBQUMsUUFBUSxFQUFFLENBQUM7d0JBRWhCLElBQUksSUFBSSxDQUFDLGNBQWMsRUFBRTs0QkFDckIsOENBQThDOzRCQUM5QyxJQUFJLENBQUMscUJBQXFCLEdBQUcsSUFBSSxDQUFDLGtCQUFrQixFQUFFLENBQUM7NEJBQ3ZELElBQUksQ0FBQyxXQUFXLENBQUMsSUFBSSxDQUFDLGtCQUFrQixFQUFFLENBQUMsQ0FBQzt5QkFDL0M7cUJBQ0o7aUJBQ0o7Z0JBQ0QsTUFBTTtZQUVWLEtBQUssT0FBTztnQkFDUixJQUFJLENBQUMsVUFBVSxFQUFFLENBQUM7Z0JBQ2xCLElBQUksSUFBSSxDQUFDLGNBQWMsRUFBRTtvQkFDckIsSUFBSSxDQUFDLFNBQVMsRUFBRSxDQUFDO29CQUVqQixJQUFJLElBQUksQ0FBQyxjQUFjLEVBQUU7d0JBQ3JCLElBQUksQ0FBQyxRQUFRLEVBQUUsQ0FBQzt3QkFFaEIsSUFBSSxJQUFJLENBQUMsY0FBYyxFQUFFOzRCQUNyQiw4Q0FBOEM7NEJBQzlDLElBQUksQ0FBQyxXQUFXLENBQUMsSUFBSSxDQUFDLGtCQUFrQixFQUFFLENBQUMsQ0FBQzt5QkFDL0M7cUJBQ0o7aUJBQ0o7Z0JBQ0QsTUFBTTtTQUNiO0lBQ0wsQ0FBQztJQUVNLFVBQVU7UUFDYiwyQ0FBMkM7UUFDM0MsSUFBSSxDQUFDLFFBQVEsQ0FBQyxPQUFPLENBQUMsQ0FBQztRQUN2QixJQUFJLFVBQVUsR0FBa0MsS0FBSyxDQUFDLGFBQWEsRUFBRSxDQUFDO1FBQ3RFLElBQUksS0FBSyxHQUFXLFVBQVUsQ0FBQyxhQUFhLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDO1FBQzdELElBQUksTUFBTSxHQUFXLFVBQVUsQ0FBQyxjQUFjLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDO1FBQy9ELElBQUksSUFBSSxHQUFXLFVBQVUsQ0FBQyxJQUFJLEdBQUcsVUFBVSxDQUFDLGFBQWEsQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLGFBQWEsQ0FBQyxHQUFHLElBQUksQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDO1FBQ3ZHLElBQUksR0FBRyxHQUFXLFVBQVUsQ0FBQyxHQUFHLEdBQUcsQ0FBQyxVQUFVLENBQUMsY0FBYyxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsYUFBYSxDQUFDLEdBQUcsVUFBVSxDQUFDLGNBQWMsQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxHQUFHLElBQUksQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDO1FBRTVKLElBQUksQ0FBQyxjQUFjLEdBQUcsSUFBSSxDQUFDLGlCQUFpQixDQUFDLElBQUksRUFBRSxHQUFHLEVBQUUsS0FBSyxFQUFFLE1BQU0sQ0FBQyxDQUFDO1FBQ3ZFLElBQUksQ0FBQyxTQUFTLENBQUMsS0FBSyxDQUFDLElBQUksR0FBRyxJQUFJLEdBQUcsSUFBSSxDQUFDO1FBQ3hDLElBQUksQ0FBQyxTQUFTLENBQUMsS0FBSyxDQUFDLEdBQUcsR0FBRyxHQUFHLEdBQUcsSUFBSSxDQUFDO0lBQzFDLENBQUM7SUFFTSxTQUFTO1FBQ1osMkNBQTJDO1FBQzNDLElBQUksQ0FBQyxRQUFRLENBQUMsTUFBTSxDQUFDLENBQUM7UUFDdEIsSUFBSSxVQUFVLEdBQWtDLEtBQUssQ0FBQyxhQUFhLEVBQUUsQ0FBQztRQUN0RSxJQUFJLEtBQUssR0FBVyxVQUFVLENBQUMsYUFBYSxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsQ0FBQztRQUM3RCxJQUFJLE1BQU0sR0FBVyxVQUFVLENBQUMsY0FBYyxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsQ0FBQztRQUMvRCxJQUFJLElBQUksR0FBVyxVQUFVLENBQUMsSUFBSSxHQUFHLFVBQVUsQ0FBQyxhQUFhLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxHQUFHLElBQUksQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDO1FBQy9GLElBQUksR0FBRyxHQUFXLFVBQVUsQ0FBQyxHQUFHLEdBQUcsQ0FBQyxVQUFVLENBQUMsY0FBYyxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsYUFBYSxDQUFDLEdBQUcsVUFBVSxDQUFDLGNBQWMsQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLENBQUMsR0FBRyxDQUFDLEdBQUcsSUFBSSxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUM7UUFFeEosSUFBSSxDQUFDLGNBQWMsR0FBRyxJQUFJLENBQUMsaUJBQWlCLENBQUMsSUFBSSxFQUFFLEdBQUcsRUFBRSxLQUFLLEVBQUUsTUFBTSxDQUFDLENBQUM7UUFDdkUsSUFBSSxDQUFDLFNBQVMsQ0FBQyxLQUFLLENBQUMsSUFBSSxHQUFHLElBQUksR0FBRyxJQUFJLENBQUM7UUFDeEMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxLQUFLLENBQUMsR0FBRyxHQUFHLEdBQUcsR0FBRyxJQUFJLENBQUM7SUFDMUMsQ0FBQztJQUVNLFFBQVEsQ0FBQyxRQUFpQjtRQUM3Qix3REFBd0Q7UUFDeEQsSUFBSSxDQUFDLFFBQVEsQ0FBQyxLQUFLLENBQUMsQ0FBQztRQUNyQixJQUFJLFFBQVEsS0FBSyxDQUFDLElBQUksT0FBTyxRQUFRLEtBQUssV0FBVyxFQUFFO1lBQ25ELElBQUksQ0FBQyxTQUFTLENBQUMsS0FBSyxDQUFDLFFBQVEsR0FBRyxDQUFDLFVBQVUsQ0FBQyxhQUFhLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxHQUFHLFFBQVEsR0FBRyxDQUFDLENBQUMsQ0FBQyxRQUFRLEVBQUUsR0FBRyxJQUFJLENBQUM7U0FDL0c7UUFDRCxJQUFJLFVBQVUsR0FBa0MsS0FBSyxDQUFDLGFBQWEsRUFBRSxDQUFDO1FBQ3RFLElBQUksS0FBSyxHQUFXLFVBQVUsQ0FBQyxhQUFhLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDO1FBQzdELElBQUksTUFBTSxHQUFXLFVBQVUsQ0FBQyxjQUFjLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDO1FBQy9ELElBQUksSUFBSSxHQUFXLFVBQVUsQ0FBQyxJQUFJLEdBQUcsQ0FBQyxVQUFVLENBQUMsYUFBYSxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsYUFBYSxDQUFDLEdBQUcsVUFBVSxDQUFDLGFBQWEsQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLENBQUMsR0FBRyxDQUFDLEdBQUcsSUFBSSxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUM7UUFDeEosSUFBSSxHQUFHLEdBQVcsVUFBVSxDQUFDLEdBQUcsR0FBRyxVQUFVLENBQUMsY0FBYyxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsR0FBRyxJQUFJLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQztRQUU5RixJQUFJLENBQUMsY0FBYyxHQUFHLElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxJQUFJLEVBQUUsR0FBRyxFQUFFLEtBQUssRUFBRSxNQUFNLENBQUMsQ0FBQztRQUN2RSxJQUFJLENBQUMsU0FBUyxDQUFDLEtBQUssQ0FBQyxJQUFJLEdBQUcsSUFBSSxHQUFHLElBQUksQ0FBQztRQUN4QyxJQUFJLENBQUMsU0FBUyxDQUFDLEtBQUssQ0FBQyxHQUFHLEdBQUcsR0FBRyxHQUFHLElBQUksQ0FBQztJQUMxQyxDQUFDO0lBRUQsZ0JBQWdCO0lBQ1QsYUFBYSxDQUFDLFFBQWlCO1FBQ2xDLElBQUksQ0FBQyxRQUFRLENBQUMsMEJBQTBCLENBQUMsQ0FBQztRQUMxQyxJQUFJLFFBQVEsS0FBSyxDQUFDLElBQUksT0FBTyxRQUFRLEtBQUssV0FBVztZQUFFLElBQUksQ0FBQyxTQUFTLENBQUMsS0FBSyxDQUFDLFFBQVEsR0FBRyxDQUFDLFVBQVUsQ0FBQyxhQUFhLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxHQUFHLFFBQVEsR0FBRyxDQUFDLENBQUMsQ0FBQyxRQUFRLEVBQUUsR0FBRyxJQUFJLENBQUM7UUFFbkssSUFBSSxVQUFVLEdBQWtDLEtBQUssQ0FBQyxhQUFhLEVBQUUsQ0FBQztRQUN0RSxJQUFJLEtBQUssR0FBVyxVQUFVLENBQUMsYUFBYSxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsQ0FBQztRQUM3RCxJQUFJLE1BQU0sR0FBVyxVQUFVLENBQUMsY0FBYyxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsQ0FBQztRQUMvRCxJQUFJLElBQUksR0FBVyxVQUFVLENBQUMsSUFBSSxHQUFHLFVBQVUsQ0FBQyxhQUFhLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxhQUFhLENBQUMsR0FBRyxDQUFDLEdBQUcsSUFBSSxDQUFDLGNBQWMsR0FBRyxJQUFJLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQztRQUNqSSxJQUFJLEdBQUcsR0FBVyxVQUFVLENBQUMsR0FBRyxHQUFHLFVBQVUsQ0FBQyxjQUFjLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxHQUFHLElBQUksQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDO1FBRTlGLElBQUksQ0FBQyxjQUFjLEdBQUcsSUFBSSxDQUFDLGlCQUFpQixDQUFDLElBQUksRUFBRSxHQUFHLEVBQUUsS0FBSyxFQUFFLE1BQU0sQ0FBQyxDQUFDO1FBQ3ZFLElBQUksQ0FBQyxTQUFTLENBQUMsS0FBSyxDQUFDLElBQUksR0FBRyxJQUFJLEdBQUcsSUFBSSxDQUFDO1FBQ3hDLElBQUksQ0FBQyxTQUFTLENBQUMsS0FBSyxDQUFDLEdBQUcsR0FBRyxHQUFHLEdBQUcsSUFBSSxDQUFDO0lBQzFDLENBQUM7SUFFRCxnQkFBZ0I7SUFDVCxZQUFZLENBQUMsUUFBaUI7UUFDakMsSUFBSSxDQUFDLFFBQVEsQ0FBQyx5QkFBeUIsQ0FBQyxDQUFDO1FBQ3pDLElBQUksUUFBUSxLQUFLLENBQUMsSUFBSSxPQUFPLFFBQVEsS0FBSyxXQUFXO1lBQUUsSUFBSSxDQUFDLFNBQVMsQ0FBQyxLQUFLLENBQUMsUUFBUSxHQUFHLENBQUMsVUFBVSxDQUFDLGFBQWEsQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLEdBQUcsUUFBUSxHQUFHLENBQUMsQ0FBQyxDQUFDLFFBQVEsRUFBRSxHQUFHLElBQUksQ0FBQztRQUVuSyxJQUFJLFVBQVUsR0FBa0MsS0FBSyxDQUFDLGFBQWEsRUFBRSxDQUFDO1FBQ3RFLElBQUksS0FBSyxHQUFXLFVBQVUsQ0FBQyxhQUFhLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDO1FBQzdELElBQUksTUFBTSxHQUFXLFVBQVUsQ0FBQyxjQUFjLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDO1FBQy9ELElBQUksSUFBSSxHQUFXLFVBQVUsQ0FBQyxJQUFJLEdBQUcsVUFBVSxDQUFDLGFBQWEsQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLGFBQWEsQ0FBQyxHQUFHLENBQUMsR0FBRyxVQUFVLENBQUMsYUFBYSxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsR0FBRyxJQUFJLENBQUMsY0FBYyxHQUFHLElBQUksQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDO1FBQzVLLElBQUksR0FBRyxHQUFXLFVBQVUsQ0FBQyxHQUFHLEdBQUcsVUFBVSxDQUFDLGNBQWMsQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLEdBQUcsSUFBSSxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUM7UUFFOUYsSUFBSSxDQUFDLGNBQWMsR0FBRyxJQUFJLENBQUMsaUJBQWlCLENBQUMsSUFBSSxFQUFFLEdBQUcsRUFBRSxLQUFLLEVBQUUsTUFBTSxDQUFDLENBQUM7UUFDdkUsSUFBSSxDQUFDLFNBQVMsQ0FBQyxLQUFLLENBQUMsSUFBSSxHQUFHLElBQUksR0FBRyxJQUFJLENBQUM7UUFDeEMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxLQUFLLENBQUMsR0FBRyxHQUFHLEdBQUcsR0FBRyxJQUFJLENBQUM7SUFDMUMsQ0FBQztJQUdNLFdBQVcsQ0FBQyxRQUFpQjtRQUNoQyx3REFBd0Q7UUFDeEQsSUFBSSxDQUFDLFFBQVEsQ0FBQyxRQUFRLENBQUMsQ0FBQztRQUN4QixJQUFJLFFBQVEsS0FBSyxDQUFDLElBQUksT0FBTyxRQUFRLEtBQUssV0FBVztZQUFFLElBQUksQ0FBQyxTQUFTLENBQUMsS0FBSyxDQUFDLFFBQVEsR0FBRyxDQUFDLFVBQVUsQ0FBQyxhQUFhLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxHQUFHLFFBQVEsR0FBRyxDQUFDLENBQUMsQ0FBQyxRQUFRLEVBQUUsR0FBRyxJQUFJLENBQUM7UUFFbkssSUFBSSxVQUFVLEdBQWtDLEtBQUssQ0FBQyxhQUFhLEVBQUUsQ0FBQztRQUN0RSxJQUFJLEtBQUssR0FBVyxVQUFVLENBQUMsYUFBYSxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsQ0FBQztRQUM3RCxJQUFJLE1BQU0sR0FBVyxVQUFVLENBQUMsY0FBYyxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsQ0FBQztRQUMvRCxJQUFJLElBQUksR0FBVyxVQUFVLENBQUMsSUFBSSxHQUFHLENBQUMsVUFBVSxDQUFDLGFBQWEsQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLGFBQWEsQ0FBQyxHQUFHLFVBQVUsQ0FBQyxhQUFhLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxHQUFHLElBQUksQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDO1FBQ3hKLElBQUksR0FBRyxHQUFXLFVBQVUsQ0FBQyxHQUFHLEdBQUcsVUFBVSxDQUFDLGNBQWMsQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLGFBQWEsQ0FBQyxHQUFHLElBQUksQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDO1FBRXRHLElBQUksQ0FBQyxjQUFjLEdBQUcsSUFBSSxDQUFDLGlCQUFpQixDQUFDLElBQUksRUFBRSxHQUFHLEVBQUUsS0FBSyxFQUFFLE1BQU0sQ0FBQyxDQUFDO1FBQ3ZFLElBQUksQ0FBQyxTQUFTLENBQUMsS0FBSyxDQUFDLElBQUksR0FBRyxJQUFJLEdBQUcsSUFBSSxDQUFDO1FBQ3hDLElBQUksQ0FBQyxTQUFTLENBQUMsS0FBSyxDQUFDLEdBQUcsR0FBRyxHQUFHLEdBQUcsSUFBSSxDQUFDO0lBQzFDLENBQUM7SUFFRCxnQkFBZ0I7SUFDVCxnQkFBZ0IsQ0FBQyxRQUFpQjtRQUNyQyxJQUFJLENBQUMsUUFBUSxDQUFDLGdDQUFnQyxDQUFDLENBQUM7UUFDaEQsSUFBSSxRQUFRLEtBQUssQ0FBQyxJQUFJLE9BQU8sUUFBUSxLQUFLLFdBQVc7WUFBRSxJQUFJLENBQUMsU0FBUyxDQUFDLEtBQUssQ0FBQyxRQUFRLEdBQUcsQ0FBQyxVQUFVLENBQUMsYUFBYSxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsR0FBRyxRQUFRLEdBQUcsQ0FBQyxDQUFDLENBQUMsUUFBUSxFQUFFLEdBQUcsSUFBSSxDQUFDO1FBRW5LLElBQUksVUFBVSxHQUFrQyxLQUFLLENBQUMsYUFBYSxFQUFFLENBQUM7UUFDdEUsSUFBSSxLQUFLLEdBQVcsVUFBVSxDQUFDLGFBQWEsQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLENBQUM7UUFDN0QsSUFBSSxNQUFNLEdBQVcsVUFBVSxDQUFDLGNBQWMsQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLENBQUM7UUFDL0QsSUFBSSxJQUFJLEdBQVcsVUFBVSxDQUFDLElBQUksR0FBRyxVQUFVLENBQUMsYUFBYSxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsYUFBYSxDQUFDLEdBQUcsQ0FBQyxHQUFHLElBQUksQ0FBQyxjQUFjLEdBQUcsSUFBSSxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUM7UUFDakksSUFBSSxHQUFHLEdBQVcsVUFBVSxDQUFDLEdBQUcsR0FBRyxVQUFVLENBQUMsY0FBYyxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsYUFBYSxDQUFDLEdBQUcsSUFBSSxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUM7UUFFdEcsSUFBSSxDQUFDLGNBQWMsR0FBRyxJQUFJLENBQUMsaUJBQWlCLENBQUMsSUFBSSxFQUFFLEdBQUcsRUFBRSxLQUFLLEVBQUUsTUFBTSxDQUFDLENBQUM7UUFDdkUsSUFBSSxDQUFDLFNBQVMsQ0FBQyxLQUFLLENBQUMsSUFBSSxHQUFHLElBQUksR0FBRyxJQUFJLENBQUM7UUFDeEMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxLQUFLLENBQUMsR0FBRyxHQUFHLEdBQUcsR0FBRyxJQUFJLENBQUM7SUFDMUMsQ0FBQztJQUVELGdCQUFnQjtJQUNULGVBQWUsQ0FBQyxRQUFpQjtRQUNwQyxJQUFJLENBQUMsUUFBUSxDQUFDLCtCQUErQixDQUFDLENBQUM7UUFDL0MsSUFBSSxRQUFRLEtBQUssQ0FBQyxJQUFJLE9BQU8sUUFBUSxLQUFLLFdBQVc7WUFBRSxJQUFJLENBQUMsU0FBUyxDQUFDLEtBQUssQ0FBQyxRQUFRLEdBQUcsQ0FBQyxVQUFVLENBQUMsYUFBYSxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsR0FBRyxRQUFRLEdBQUcsQ0FBQyxDQUFDLENBQUMsUUFBUSxFQUFFLEdBQUcsSUFBSSxDQUFDO1FBRW5LLElBQUksVUFBVSxHQUFrQyxLQUFLLENBQUMsYUFBYSxFQUFFLENBQUM7UUFDdEUsSUFBSSxLQUFLLEdBQVcsVUFBVSxDQUFDLGFBQWEsQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLENBQUM7UUFDN0QsSUFBSSxNQUFNLEdBQVcsVUFBVSxDQUFDLGNBQWMsQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLENBQUM7UUFDL0QsSUFBSSxJQUFJLEdBQVcsVUFBVSxDQUFDLElBQUksR0FBRyxVQUFVLENBQUMsYUFBYSxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsYUFBYSxDQUFDLEdBQUcsQ0FBQyxHQUFHLFVBQVUsQ0FBQyxhQUFhLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxHQUFHLElBQUksQ0FBQyxjQUFjLEdBQUcsSUFBSSxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUM7UUFDNUssSUFBSSxHQUFHLEdBQVcsVUFBVSxDQUFDLEdBQUcsR0FBRyxVQUFVLENBQUMsY0FBYyxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsYUFBYSxDQUFDLEdBQUcsSUFBSSxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUM7UUFFdEcsSUFBSSxDQUFDLGNBQWMsR0FBRyxJQUFJLENBQUMsaUJBQWlCLENBQUMsSUFBSSxFQUFFLEdBQUcsRUFBRSxLQUFLLEVBQUUsTUFBTSxDQUFDLENBQUM7UUFDdkUsSUFBSSxDQUFDLFNBQVMsQ0FBQyxLQUFLLENBQUMsSUFBSSxHQUFHLElBQUksR0FBRyxJQUFJLENBQUM7UUFDeEMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxLQUFLLENBQUMsR0FBRyxHQUFHLEdBQUcsR0FBRyxJQUFJLENBQUM7SUFDMUMsQ0FBQztJQUVNLFFBQVEsQ0FBQyxTQUFrQjtRQUM5QixJQUFJLENBQUMsU0FBUyxDQUFDLEtBQUssQ0FBQyxJQUFJLEdBQUcsQ0FBQyxHQUFHLEdBQUcsSUFBSSxDQUFDO1FBQ3hDLElBQUksQ0FBQyxTQUFTLENBQUMsS0FBSyxDQUFDLEdBQUcsR0FBRyxDQUFDLEdBQUcsR0FBRyxJQUFJLENBQUM7UUFFdkMseURBQXlEO1FBQ3pELElBQUksZ0JBQWdCLEdBQVcsa0NBQWtDLEdBQUcsU0FBUyxDQUFDO1FBQzlFLElBQUksQ0FBQyxTQUFTLENBQUMsU0FBUyxHQUFHLElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxDQUFDLENBQUMsZ0JBQWdCLEdBQUcsR0FBRyxHQUFHLElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxDQUFDLENBQUMsZ0JBQWdCLENBQUM7SUFDM0gsQ0FBQztJQUVELDZGQUE2RjtJQUNyRixpQkFBaUIsQ0FBQyxLQUFhLEVBQUUsSUFBWSxFQUFFLE1BQWMsRUFBRSxPQUFlO1FBQ2xGLElBQUksUUFBUSxHQUFHLFVBQVUsQ0FBQyxXQUFXLEVBQUUsQ0FBQztRQUN4QyxPQUFPLENBQUMsS0FBSyxHQUFHLE1BQU0sR0FBRyxRQUFRLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxLQUFLLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQyxJQUFJLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQyxJQUFJLEdBQUcsT0FBTyxHQUFHLFFBQVEsQ0FBQyxNQUFNLENBQUMsQ0FBQztJQUNoSCxDQUFDO0lBRU0sTUFBTTtRQUNULElBQUksQ0FBQyxJQUFJLENBQUMsdUJBQXVCLEVBQUU7WUFDL0IscURBQXFEO1lBQ3JELElBQUksSUFBSSxDQUFDLFNBQVM7Z0JBQUUsSUFBSSxDQUFDLGdDQUFnQyxFQUFFLENBQUM7U0FDL0Q7UUFDRCxJQUFJLElBQUksQ0FBQyxTQUFTLElBQUksSUFBSSxDQUFDLFNBQVMsQ0FBQyxhQUFhLEVBQUU7WUFDaEQsSUFBSSxJQUFJLENBQUMsUUFBUSxLQUFLLE1BQU0sRUFBRTtnQkFDMUIsUUFBUSxDQUFDLElBQUksQ0FBQyxXQUFXLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDO2FBQzdDO2lCQUFNLElBQUksSUFBSSxDQUFDLFFBQVEsS0FBSyxRQUFRLEVBQUU7Z0JBQ25DLElBQUksQ0FBQyxHQUFHLENBQUMsYUFBYSxDQUFDLFdBQVcsQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLENBQUM7YUFDdEQ7aUJBQU07Z0JBQ0gsVUFBVSxDQUFDLFdBQVcsQ0FBQyxJQUFJLENBQUMsU0FBUyxFQUFFLElBQUksQ0FBQyxRQUFRLENBQUMsQ0FBQzthQUN6RDtTQUNKO1FBQ0QsSUFBSSxDQUFDLFNBQVMsR0FBRyxJQUFJLENBQUM7SUFDMUIsQ0FBQztJQUVELGtDQUFrQztJQUMxQixRQUFRO1FBQ1osSUFBSSxPQUFPLElBQUksQ0FBQyxHQUFHLEtBQUssV0FBVyxFQUFFO1lBQ2pDLElBQUksQ0FBQyxHQUFHLENBQUMsV0FBVyxHQUFHLEdBQVMsRUFBRSxDQUFDLEtBQUssQ0FBQyxRQUFRLEVBQUUsQ0FBQztZQUNwRCxJQUFJLENBQUMsR0FBRyxDQUFDLFdBQVcsR0FBRyxHQUFTLEVBQUUsQ0FBQyxLQUFLLENBQUMsVUFBVSxFQUFFLENBQUM7WUFDdEQsSUFBSSxDQUFDLEdBQUcsQ0FBQyxzQkFBc0IsR0FBRyxHQUFTLEVBQUUsR0FBRyxJQUFJLENBQUMsdUJBQXVCLEdBQUcsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDO1lBQ3ZGLElBQUksQ0FBQyxHQUFHLENBQUMsb0JBQW9CLEdBQUcsR0FBUyxFQUFFLEdBQUcsSUFBSSxDQUFDLHVCQUF1QixHQUFHLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQztZQUN0RixJQUFJLENBQUMsR0FBRyxDQUFDLEtBQUssR0FBRyxHQUFTLEVBQUU7Z0JBQ3hCLElBQUksQ0FBQyxJQUFJLENBQUMsU0FBUztvQkFBRSxPQUFPO2dCQUM1QixJQUFJLENBQUMsS0FBSyxFQUFFLENBQUM7WUFDakIsQ0FBQyxDQUFDO1lBQ0YsSUFBSSxDQUFDLEdBQUcsQ0FBQyxTQUFTLEdBQUcsQ0FBQyxPQUFpQyxFQUFRLEVBQUUsR0FBRyxJQUFJLENBQUMsT0FBTyxHQUFHLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQztTQUNqRztJQUNMLENBQUM7SUFFTyxrQkFBa0I7UUFDdEIsSUFBSSxNQUFNLEdBQWUsSUFBSSxDQUFDLFNBQVMsQ0FBQyxxQkFBcUIsRUFBRSxDQUFDO1FBQ2hFLElBQUksVUFBVSxHQUFXLE1BQU0sQ0FBQyxJQUFJLENBQUM7UUFDckMsSUFBSSxLQUFLLEdBQVcsVUFBVSxDQUFDLGFBQWEsQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLENBQUM7UUFDN0QsSUFBSSxRQUFRLEdBQVEsVUFBVSxDQUFDLFdBQVcsRUFBRSxDQUFDO1FBRTdDLElBQUksVUFBVSxHQUFHLEtBQUssR0FBRyxRQUFRLENBQUMsS0FBSyxHQUFHLENBQUM7WUFBRSxPQUFPLFVBQVUsR0FBRyxLQUFLLEdBQUcsUUFBUSxDQUFDLEtBQUssQ0FBQztRQUN4RixJQUFJLFVBQVUsR0FBRyxDQUFDO1lBQUUsT0FBTyxVQUFVLEdBQUcsQ0FBQyxDQUFDLENBQUM7UUFFM0MsT0FBTyxDQUFDLENBQUM7SUFDYixDQUFDO0lBRU8sK0JBQStCO1FBQ25DLElBQUksQ0FBQywyQkFBMkIsR0FBRyxJQUFJLENBQUMsU0FBUyxDQUFDLE1BQU0sQ0FDcEQsVUFBVSxFQUNWLFlBQVksRUFDWixLQUFLLENBQUMsRUFBRTtZQUNKLEtBQUssQ0FBQyxJQUFJLEVBQUUsQ0FBQztRQUNqQixDQUFDLENBQ0osQ0FBQztJQUNOLENBQUM7SUFFTyxnQ0FBZ0M7UUFDcEMsSUFBSSxJQUFJLENBQUMsMkJBQTJCLEVBQUU7WUFDbEMsSUFBSSxDQUFDLDJCQUEyQixFQUFFLENBQUM7WUFDbkMsSUFBSSxDQUFDLDJCQUEyQixHQUFHLElBQUksQ0FBQztTQUMzQztJQUNMLENBQUM7SUFFRCxXQUFXO1FBQ1Asd0JBQXdCO1FBQ3hCLElBQUksQ0FBQyxNQUFNLEVBQUUsQ0FBQztRQUNkLCtCQUErQjtRQUMvQixJQUFJLENBQUMsWUFBWSxDQUFDLFdBQVcsRUFBRSxDQUFDO1FBQ2hDLElBQUksQ0FBQyxjQUFjLENBQUMsV0FBVyxFQUFFLENBQUM7SUFDdEMsQ0FBQzs7O1lBcmRKLFNBQVMsU0FBQztnQkFDUCxRQUFRLEVBQUUsa0JBQWtCO2dCQUM1QixTQUFTLEVBQUUsQ0FBQyxVQUFVLEVBQUUsWUFBWSxFQUFFLGVBQWUsQ0FBQzthQUN6RDs7O1lBekJHLFVBQVU7WUFLVixNQUFNO1lBR0YsVUFBVTtZQUpkLFNBQVM7WUFHSixZQUFZO1lBR1osZUFBZTs7O2tCQTZCbkIsS0FBSzttQkE4REwsS0FBSyxTQUFDLGdCQUFnQiIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7XHJcbiAgICBEaXJlY3RpdmUsXHJcbiAgICBFbGVtZW50UmVmLFxyXG4gICAgT25Jbml0LFxyXG4gICAgT25EZXN0cm95LFxyXG4gICAgSW5wdXQsXHJcbiAgICBSZW5kZXJlcjIsXHJcbiAgICBOZ1pvbmUsXHJcbn0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XHJcbmltcG9ydCB7IEtkRG9tRWxlbVN2YyB9IGZyb20gJy4uL2tkLWNvbW1vbi9pbmRleCc7XHJcbmltcG9ydCB7RG9tSGFuZGxlcn0gZnJvbSAncHJpbWVuZy9kb20nO1xyXG5pbXBvcnQgeyBUb29sdGlwIH0gZnJvbSAncHJpbWVuZy90b29sdGlwJztcclxuaW1wb3J0IHsgS2RTcGxpdHRlckV2ZW50IH0gZnJvbSAnLi4va2QtYW5ndWxhci1zcGxpdHRlci9pbmRleCc7XHJcbmltcG9ydCB7IFN1YnNjcmlwdGlvbiB9IGZyb20gJ3J4anMnO1xyXG5cclxuZXhwb3J0IGludGVyZmFjZSBJVG9vbHRpcEFwaSB7XHJcbiAgICBzaG93VG9vbHRpcD86ICgpID0+IHZvaWQ7XHJcbiAgICBoaWRlVG9vbHRpcD86ICgpID0+IHZvaWQ7XHJcbiAgICBkZWFjdGl2YXRlSG9zdExpc3RlbmVyPzogKCkgPT4gdm9pZDtcclxuICAgIGFjdGl2YXRlSG9zdExpc3RlbmVyPzogKCkgPT4gdm9pZDtcclxuICAgIGFsaWduPzogKCkgPT4gdm9pZDtcclxuICAgIHNldE9mZnNldD86IChfb2Zmc2V0OiB7IHg6IG51bWJlciwgeTogbnVtYmVyIH0pID0+IHZvaWQ7XHJcbn1cclxuXHJcbkBEaXJlY3RpdmUoe1xyXG4gICAgc2VsZWN0b3I6ICdba2QtdG9vbHRpcC1kaXJdJyxcclxuICAgIHByb3ZpZGVyczogW0RvbUhhbmRsZXIsIEtkRG9tRWxlbVN2YywgS2RTcGxpdHRlckV2ZW50XSxcclxufSlcclxuZXhwb3J0IGNsYXNzIEtkVG9vbHRpcERpcmVjdGl2ZSBleHRlbmRzIFRvb2x0aXAgaW1wbGVtZW50cyBPbkluaXQsIE9uRGVzdHJveSB7XHJcblxyXG4gICAgcHJpdmF0ZSBfaXNNb2JpbGU6IGJvb2xlYW47XHJcbiAgICBwcml2YXRlIF93aWR0aE91dHNpZGVWaWV3cG9ydDogbnVtYmVyO1xyXG4gICAgcHJpdmF0ZSBfZHJhZ01lbnVTdWI6IFN1YnNjcmlwdGlvbjtcclxuICAgIHByaXZhdGUgX3RvZ2dsZU1lbnVTdWI6IFN1YnNjcmlwdGlvbjtcclxuICAgIHByaXZhdGUgX2lzT3V0T2ZCb3VuZHM6IGJvb2xlYW4gPSBmYWxzZTtcclxuXHJcbiAgICBwcml2YXRlIF9kb2N1bWVudFRvdWNoU3RhcnRMaXN0ZW5lcjogYW55O1xyXG4gICAgcHJpdmF0ZSBfZGVhY3RpdmF0ZUhvc3RMaXN0ZW5lcjogYm9vbGVhbiA9IGZhbHNlO1xyXG4gICAgcHJpdmF0ZSBfb2Zmc2V0OiB7IHg6IG51bWJlciwgeTogbnVtYmVyIH0gPSB7IHg6IDAsIHk6IDAgfTtcclxuICAgIHByaXZhdGUgX2RlZmF1bHRPZmZzZXQ6IG51bWJlciA9IDEwO1xyXG5cclxuICAgIEBJbnB1dCgpIGFwaTogSVRvb2x0aXBBcGk7XHJcblxyXG4gICAgLy8gY29uc3RydWN0b3IgaXMgZnVsbHkgbmV3XHJcbiAgICBjb25zdHJ1Y3RvcihcclxuICAgICAgICBwcml2YXRlIF9lbDogRWxlbWVudFJlZixcclxuICAgICAgICBfem9uZTogTmdab25lLFxyXG4gICAgICAgIHByaXZhdGUgX2RvbUhhbmRsZXI6IERvbUhhbmRsZXIsXHJcbiAgICAgICAgcHJpdmF0ZSBfcmVuZGVyZXI6IFJlbmRlcmVyMixcclxuICAgICAgICBfa2REb21TdmM6IEtkRG9tRWxlbVN2YyxcclxuICAgICAgICBfa2RTcGxpdHRlckV2ZW50OiBLZFNwbGl0dGVyRXZlbnQsXHJcbiAgICApIHtcclxuICAgICAgICAvLyBzdXBlcihfZWwsIF9kb21IYW5kbGVyLCBfem9uZSk7XHJcbiAgICAgICAgc3VwZXIoX2VsLCBfem9uZSk7XHJcblxyXG4gICAgICAgIHRoaXMuX2lzTW9iaWxlID0gX2tkRG9tU3ZjLmlzTW9iaWxlRGV2aWNlKCk7XHJcbiAgICAgICAgdGhpcy5fZHJhZ01lbnVTdWIgPSBfa2RTcGxpdHRlckV2ZW50Lm9uRHJhZygpLnN1YnNjcmliZSgoKTogdm9pZCA9PiB7XHJcbiAgICAgICAgICAgIHN1cGVyLmhpZGUoKTtcclxuICAgICAgICB9KTtcclxuICAgICAgICB0aGlzLl90b2dnbGVNZW51U3ViID0gX2tkU3BsaXR0ZXJFdmVudC5vblRvZ2dsZU1lbnUoKS5zdWJzY3JpYmUoKCk6IHZvaWQgPT4ge1xyXG4gICAgICAgICAgICBzdXBlci5oaWRlKCk7XHJcbiAgICAgICAgfSk7XHJcbiAgICB9XHJcblxyXG4gICAgbmdPbkluaXQoKTogdm9pZCB7XHJcbiAgICAgICAgdGhpcy5faW5pdEFwaSgpO1xyXG4gICAgfVxyXG5cclxuICAgIG9uTW91c2VFbnRlcihlOiBFdmVudCk6IHZvaWQge1xyXG4gICAgICAgIC8vIGFkZGVkIGV4dHJhIGNvbmRpdGlvbiAhdGhpcy5faXNNb2JpbGUgdG8gaWYgc3RhdGVtZW50XHJcbiAgICAgICAgaWYgKCF0aGlzLl9pc01vYmlsZSAmJiAhdGhpcy5fZGVhY3RpdmF0ZUhvc3RMaXN0ZW5lcikge1xyXG4gICAgICAgICAgICBpZiAodGhpcy5oaWRlVGltZW91dCkge1xyXG4gICAgICAgICAgICAgICAgY2xlYXJUaW1lb3V0KHRoaXMuaGlkZVRpbWVvdXQpO1xyXG4gICAgICAgICAgICAgICAgdGhpcy5yZW1vdmUoKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBzdXBlci5hY3RpdmF0ZSgpO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICBvbk1vdXNlTGVhdmUoZTogRXZlbnQpOiB2b2lkIHtcclxuICAgICAgICAvLyBhZGRlZCBleHRyYSBjb25kaXRpb24gIXRoaXMuX2lzTW9iaWxlIHRvIGlmIHN0YXRlbWVudFxyXG4gICAgICAgIGlmICghdGhpcy5faXNNb2JpbGUgJiYgIXRoaXMuX2RlYWN0aXZhdGVIb3N0TGlzdGVuZXIpIHtcclxuICAgICAgICAgICAgc3VwZXIuZGVhY3RpdmF0ZSgpO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICBvbkNsaWNrKGU6IEV2ZW50KTogdm9pZCB7XHJcbiAgICAgICAgaWYgKCF0aGlzLl9kZWFjdGl2YXRlSG9zdExpc3RlbmVyKSB7XHJcbiAgICAgICAgICAgIC8vIHdoZW4gbW9iaWxlIGRldmljZSwgY2xpY2sgd2lsbCBhY3RpdmF0ZSB0aGUgdG9vbHRpcC4gd2hlbiB3ZWIsIGNsaWNrIHdpbGwgZGVhY3RpdmF0ZSB0aGUgdG9vbHRpcFxyXG4gICAgICAgICAgICBpZiAoIXRoaXMuX2lzTW9iaWxlKSB7XHJcbiAgICAgICAgICAgICAgICBzdXBlci5kZWFjdGl2YXRlKCk7XHJcbiAgICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgICAgICBpZiAodGhpcy5oaWRlVGltZW91dCkge1xyXG4gICAgICAgICAgICAgICAgICAgIGNsZWFyVGltZW91dCh0aGlzLmhpZGVUaW1lb3V0KTtcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLnJlbW92ZSgpO1xyXG4gICAgICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgICAgIHN1cGVyLmFjdGl2YXRlKCk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgLy8gY2hhbmdlZCBJbnB1dCBwYXJhbSB0byAna2QtdG9vbHRpcC1kaXInIChvbGQgaW5wdXQgd2FzOiBwVG9vbHRpcClcclxuICAgIEBJbnB1dCgna2QtdG9vbHRpcC1kaXInKSBzZXQgVGV4dCh0ZXh0OiBzdHJpbmcpIHtcclxuICAgICAgICB0aGlzLl90ZXh0ID0gdGV4dDtcclxuICAgICAgICBpZiAodGhpcy5hY3RpdmUpIHtcclxuICAgICAgICAgICAgaWYgKHRoaXMuX3RleHQpIHtcclxuICAgICAgICAgICAgICAgIGlmICh0aGlzLmNvbnRhaW5lciAmJiB0aGlzLmNvbnRhaW5lci5vZmZzZXRQYXJlbnQpIHtcclxuICAgICAgICAgICAgICAgICAgICBzdXBlci51cGRhdGVUZXh0KCk7XHJcbiAgICAgICAgICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuc2hvdygpO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9IFxyXG4gICAgICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgICAgIHN1cGVyLmhpZGUoKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICBwdWJsaWMgc2hvdygpOiB2b2lkIHtcclxuICAgICAgICBpZiAoIXRoaXMuX3RleHQgfHwgdGhpcy5kaXNhYmxlZCkge1xyXG4gICAgICAgICAgICByZXR1cm47XHJcbiAgICAgICAgfVxyXG4gICAgICAgIHN1cGVyLmNyZWF0ZSgpO1xyXG4gICAgICAgIHRoaXMuYWxpZ24oKTtcclxuXHJcbiAgICAgICAgRG9tSGFuZGxlci5mYWRlSW4odGhpcy5jb250YWluZXIsIDI1MCk7XHJcbiAgICAgICAgaWYgKHRoaXMudG9vbHRpcFpJbmRleCA9PT0gJ2F1dG8nKSB7XHJcbiAgICAgICAgICAgIHRoaXMuY29udGFpbmVyLnN0eWxlLnpJbmRleCA9ICsrRG9tSGFuZGxlci56aW5kZXg7XHJcbiAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgdGhpcy5jb250YWluZXIuc3R5bGUuekluZGV4ID0gdGhpcy50b29sdGlwWkluZGV4O1xyXG4gICAgICAgIH1cclxuICAgICAgICBpZiAoIXRoaXMuX2RlYWN0aXZhdGVIb3N0TGlzdGVuZXIpIHtcclxuICAgICAgICAgICAgc3VwZXIuYmluZERvY3VtZW50UmVzaXplTGlzdGVuZXIoKTtcclxuICAgICAgICAgICAgLy8gYWRkZWQgMSBsaW5lLiBfYmluZERvY3VtZW50VG91Y2hTdGFydExpc3RlbmVyKClcclxuICAgICAgICAgICAgaWYgKHRoaXMuX2lzTW9iaWxlKSB0aGlzLl9iaW5kRG9jdW1lbnRUb3VjaFN0YXJ0TGlzdGVuZXIoKTtcclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgcHVibGljIGFsaWduKCk6IHZvaWQge1xyXG4gICAgICAgIGxldCBwb3NpdGlvbjogc3RyaW5nID0gdGhpcy50b29sdGlwUG9zaXRpb247XHJcbiAgICAgICAgdGhpcy5fd2lkdGhPdXRzaWRlVmlld3BvcnQgPSBudWxsO1xyXG5cclxuICAgICAgICBzd2l0Y2ggKHBvc2l0aW9uKSB7XHJcbiAgICAgICAgICAgIGNhc2UgJ3RvcCc6XHJcbiAgICAgICAgICAgICAgICB0aGlzLmFsaWduVG9wKCk7XHJcbiAgICAgICAgICAgICAgICAvLyBhZGRlZCAxIGxpbmUuIF93aWR0aE91dHNpZGVWaWV3cG9ydFxyXG4gICAgICAgICAgICAgICAgLy8gdGhpcy5faXNPdXRvZkJvdW5kcyBpcyB1c2VkIGluc3RlYWQgb2Ygc3VwZXIuT3V0b2ZCb3VuZHNcclxuICAgICAgICAgICAgICAgIGlmICh0aGlzLl9pc091dE9mQm91bmRzKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5hbGlnblRvcFJpZ2h0KCk7XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIGlmICh0aGlzLl9pc091dE9mQm91bmRzKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuYWxpZ25Ub3BMZWZ0KCk7XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAodGhpcy5faXNPdXRPZkJvdW5kcykge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5fd2lkdGhPdXRzaWRlVmlld3BvcnQgPSB0aGlzLl9jYWxjdWxhdGVXaWR0aE91dCgpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5hbGlnbkJvdHRvbSh0aGlzLl93aWR0aE91dHNpZGVWaWV3cG9ydCk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICBicmVhaztcclxuXHJcbiAgICAgICAgICAgIGNhc2UgJ3RvcC1yaWdodCc6XHJcbiAgICAgICAgICAgICAgICB0aGlzLmFsaWduVG9wUmlnaHQoKTtcclxuICAgICAgICAgICAgICAgIC8vIGFkZGVkIDEgbGluZS4gX3dpZHRoT3V0c2lkZVZpZXdwb3J0XHJcbiAgICAgICAgICAgICAgICBpZiAodGhpcy5faXNPdXRPZkJvdW5kcykge1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuYWxpZ25Ub3AoKTtcclxuXHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKHRoaXMuX2lzT3V0T2ZCb3VuZHMpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5hbGlnblRvcExlZnQoKTtcclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGlmICh0aGlzLl9pc091dE9mQm91bmRzKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0aGlzLl93aWR0aE91dHNpZGVWaWV3cG9ydCA9IHRoaXMuX2NhbGN1bGF0ZVdpZHRoT3V0KCk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0aGlzLmFsaWduQm90dG9tKHRoaXMuX3dpZHRoT3V0c2lkZVZpZXdwb3J0KTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIGJyZWFrO1xyXG5cclxuICAgICAgICAgICAgY2FzZSAndG9wLWxlZnQnOlxyXG4gICAgICAgICAgICAgICAgdGhpcy5hbGlnblRvcExlZnQoKTtcclxuICAgICAgICAgICAgICAgIC8vIGFkZGVkIDEgbGluZS4gX3dpZHRoT3V0c2lkZVZpZXdwb3J0XHJcbiAgICAgICAgICAgICAgICBpZiAodGhpcy5faXNPdXRPZkJvdW5kcykge1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuYWxpZ25Ub3AoKTtcclxuXHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKHRoaXMuX2lzT3V0T2ZCb3VuZHMpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5hbGlnblRvcFJpZ2h0KCk7XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAodGhpcy5faXNPdXRPZkJvdW5kcykge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5fd2lkdGhPdXRzaWRlVmlld3BvcnQgPSB0aGlzLl9jYWxjdWxhdGVXaWR0aE91dCgpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5hbGlnbkJvdHRvbSh0aGlzLl93aWR0aE91dHNpZGVWaWV3cG9ydCk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICBicmVhaztcclxuXHJcbiAgICAgICAgICAgIGNhc2UgJ2JvdHRvbSc6XHJcbiAgICAgICAgICAgICAgICB0aGlzLmFsaWduQm90dG9tKCk7XHJcbiAgICAgICAgICAgICAgICAvLyBhZGRlZCAxIGxpbmUuIF93aWR0aE91dHNpZGVWaWV3cG9ydFxyXG4gICAgICAgICAgICAgICAgaWYgKHRoaXMuX2lzT3V0T2ZCb3VuZHMpIHtcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLmFsaWduQm90dG9tUmlnaHQoKTtcclxuXHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKHRoaXMuX2lzT3V0T2ZCb3VuZHMpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5hbGlnbkJvdHRvbUxlZnQoKTtcclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGlmICh0aGlzLl9pc091dE9mQm91bmRzKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyBhZGRlZCAxIGxpbmUuIGVkaXRlZCBhbGlnblRvcCB3aXRoIHBhcmFtXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0aGlzLl93aWR0aE91dHNpZGVWaWV3cG9ydCA9IHRoaXMuX2NhbGN1bGF0ZVdpZHRoT3V0KCk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0aGlzLmFsaWduVG9wKHRoaXMuX3dpZHRoT3V0c2lkZVZpZXdwb3J0KTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIGJyZWFrO1xyXG5cclxuICAgICAgICAgICAgY2FzZSAnYm90dG9tLXJpZ2h0JzpcclxuICAgICAgICAgICAgICAgIHRoaXMuYWxpZ25Cb3R0b21SaWdodCgpO1xyXG4gICAgICAgICAgICAgICAgLy8gYWRkZWQgMSBsaW5lLiBfd2lkdGhPdXRzaWRlVmlld3BvcnRcclxuICAgICAgICAgICAgICAgIGlmICh0aGlzLl9pc091dE9mQm91bmRzKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5hbGlnbkJvdHRvbSgpO1xyXG5cclxuICAgICAgICAgICAgICAgICAgICBpZiAodGhpcy5faXNPdXRPZkJvdW5kcykge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLmFsaWduQm90dG9tTGVmdCgpO1xyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgaWYgKHRoaXMuX2lzT3V0T2ZCb3VuZHMpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIGFkZGVkIDEgbGluZS4gZWRpdGVkIGFsaWduVG9wIHdpdGggcGFyYW1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuX3dpZHRoT3V0c2lkZVZpZXdwb3J0ID0gdGhpcy5fY2FsY3VsYXRlV2lkdGhPdXQoKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuYWxpZ25Ub3AodGhpcy5fd2lkdGhPdXRzaWRlVmlld3BvcnQpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgYnJlYWs7XHJcblxyXG4gICAgICAgICAgICBjYXNlICdib3R0b20tbGVmdCc6XHJcbiAgICAgICAgICAgICAgICB0aGlzLmFsaWduQm90dG9tTGVmdCgpO1xyXG4gICAgICAgICAgICAgICAgLy8gYWRkZWQgMSBsaW5lLiBfd2lkdGhPdXRzaWRlVmlld3BvcnRcclxuICAgICAgICAgICAgICAgIGlmICh0aGlzLl9pc091dE9mQm91bmRzKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5hbGlnbkJvdHRvbSgpO1xyXG5cclxuICAgICAgICAgICAgICAgICAgICBpZiAodGhpcy5faXNPdXRPZkJvdW5kcykge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLmFsaWduQm90dG9tUmlnaHQoKTtcclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGlmICh0aGlzLl9pc091dE9mQm91bmRzKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyBhZGRlZCAxIGxpbmUuIGVkaXRlZCBhbGlnblRvcCB3aXRoIHBhcmFtXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0aGlzLl93aWR0aE91dHNpZGVWaWV3cG9ydCA9IHRoaXMuX2NhbGN1bGF0ZVdpZHRoT3V0KCk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0aGlzLmFsaWduVG9wKHRoaXMuX3dpZHRoT3V0c2lkZVZpZXdwb3J0KTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIGJyZWFrO1xyXG5cclxuICAgICAgICAgICAgY2FzZSAnbGVmdCc6XHJcbiAgICAgICAgICAgICAgICB0aGlzLmFsaWduTGVmdCgpO1xyXG4gICAgICAgICAgICAgICAgaWYgKHRoaXMuX2lzT3V0T2ZCb3VuZHMpIHtcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLmFsaWduUmlnaHQoKTtcclxuXHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKHRoaXMuX2lzT3V0T2ZCb3VuZHMpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5hbGlnblRvcCgpO1xyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgaWYgKHRoaXMuX2lzT3V0T2ZCb3VuZHMpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIGFkZGVkIDEgbGluZS4gZWRpdGVkIGFsaWduQm90dG9tIHdpdGggcGFyYW1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuX3dpZHRoT3V0c2lkZVZpZXdwb3J0ID0gdGhpcy5fY2FsY3VsYXRlV2lkdGhPdXQoKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuYWxpZ25Cb3R0b20odGhpcy5fY2FsY3VsYXRlV2lkdGhPdXQoKSk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICBicmVhaztcclxuXHJcbiAgICAgICAgICAgIGNhc2UgJ3JpZ2h0JzpcclxuICAgICAgICAgICAgICAgIHRoaXMuYWxpZ25SaWdodCgpO1xyXG4gICAgICAgICAgICAgICAgaWYgKHRoaXMuX2lzT3V0T2ZCb3VuZHMpIHtcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLmFsaWduTGVmdCgpO1xyXG5cclxuICAgICAgICAgICAgICAgICAgICBpZiAodGhpcy5faXNPdXRPZkJvdW5kcykge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLmFsaWduVG9wKCk7XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAodGhpcy5faXNPdXRPZkJvdW5kcykge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gYWRkZWQgMSBsaW5lLiBlZGl0ZWQgYWxpZ25Cb3R0b20gd2l0aCBwYXJhbVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5hbGlnbkJvdHRvbSh0aGlzLl9jYWxjdWxhdGVXaWR0aE91dCgpKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICBwdWJsaWMgYWxpZ25SaWdodCgpIHtcclxuICAgICAgICAvLyBhZGRlZCAxIGxpbmUuIGVkaXRlZCBwcmVBbGlnbiB3aXRoIHBhcmFtXHJcbiAgICAgICAgdGhpcy5wcmVBbGlnbigncmlnaHQnKTtcclxuICAgICAgICBsZXQgaG9zdE9mZnNldDogeyBsZWZ0OiBudW1iZXIsIHRvcDogbnVtYmVyIH0gPSBzdXBlci5nZXRIb3N0T2Zmc2V0KCk7XHJcbiAgICAgICAgbGV0IHdpZHRoOiBudW1iZXIgPSBEb21IYW5kbGVyLmdldE91dGVyV2lkdGgodGhpcy5jb250YWluZXIpO1xyXG4gICAgICAgIGxldCBoZWlnaHQ6IG51bWJlciA9IERvbUhhbmRsZXIuZ2V0T3V0ZXJIZWlnaHQodGhpcy5jb250YWluZXIpO1xyXG4gICAgICAgIGxldCBsZWZ0OiBudW1iZXIgPSBob3N0T2Zmc2V0LmxlZnQgKyBEb21IYW5kbGVyLmdldE91dGVyV2lkdGgodGhpcy5fZWwubmF0aXZlRWxlbWVudCkgKyB0aGlzLl9vZmZzZXQueDtcclxuICAgICAgICBsZXQgdG9wOiBudW1iZXIgPSBob3N0T2Zmc2V0LnRvcCArIChEb21IYW5kbGVyLmdldE91dGVySGVpZ2h0KHRoaXMuX2VsLm5hdGl2ZUVsZW1lbnQpIC0gRG9tSGFuZGxlci5nZXRPdXRlckhlaWdodCh0aGlzLmNvbnRhaW5lcikpIC8gMiAtIDEgKyB0aGlzLl9vZmZzZXQueTtcclxuXHJcbiAgICAgICAgdGhpcy5faXNPdXRPZkJvdW5kcyA9IHRoaXMuX2NoZWNrT3V0T2ZCb3VuZHMobGVmdCwgdG9wLCB3aWR0aCwgaGVpZ2h0KTtcclxuICAgICAgICB0aGlzLmNvbnRhaW5lci5zdHlsZS5sZWZ0ID0gbGVmdCArICdweCc7XHJcbiAgICAgICAgdGhpcy5jb250YWluZXIuc3R5bGUudG9wID0gdG9wICsgJ3B4JztcclxuICAgIH1cclxuXHJcbiAgICBwdWJsaWMgYWxpZ25MZWZ0KCkge1xyXG4gICAgICAgIC8vIGFkZGVkIDEgbGluZS4gZWRpdGVkIHByZUFsaWduIHdpdGggcGFyYW1cclxuICAgICAgICB0aGlzLnByZUFsaWduKCdsZWZ0Jyk7XHJcbiAgICAgICAgbGV0IGhvc3RPZmZzZXQ6IHsgbGVmdDogbnVtYmVyLCB0b3A6IG51bWJlciB9ID0gc3VwZXIuZ2V0SG9zdE9mZnNldCgpO1xyXG4gICAgICAgIGxldCB3aWR0aDogbnVtYmVyID0gRG9tSGFuZGxlci5nZXRPdXRlcldpZHRoKHRoaXMuY29udGFpbmVyKTtcclxuICAgICAgICBsZXQgaGVpZ2h0OiBudW1iZXIgPSBEb21IYW5kbGVyLmdldE91dGVySGVpZ2h0KHRoaXMuY29udGFpbmVyKTtcclxuICAgICAgICBsZXQgbGVmdDogbnVtYmVyID0gaG9zdE9mZnNldC5sZWZ0IC0gRG9tSGFuZGxlci5nZXRPdXRlcldpZHRoKHRoaXMuY29udGFpbmVyKSArIHRoaXMuX29mZnNldC54O1xyXG4gICAgICAgIGxldCB0b3A6IG51bWJlciA9IGhvc3RPZmZzZXQudG9wICsgKERvbUhhbmRsZXIuZ2V0T3V0ZXJIZWlnaHQodGhpcy5fZWwubmF0aXZlRWxlbWVudCkgLSBEb21IYW5kbGVyLmdldE91dGVySGVpZ2h0KHRoaXMuY29udGFpbmVyKSkgLyAyICsgdGhpcy5fb2Zmc2V0Lnk7XHJcblxyXG4gICAgICAgIHRoaXMuX2lzT3V0T2ZCb3VuZHMgPSB0aGlzLl9jaGVja091dE9mQm91bmRzKGxlZnQsIHRvcCwgd2lkdGgsIGhlaWdodCk7XHJcbiAgICAgICAgdGhpcy5jb250YWluZXIuc3R5bGUubGVmdCA9IGxlZnQgKyAncHgnO1xyXG4gICAgICAgIHRoaXMuY29udGFpbmVyLnN0eWxlLnRvcCA9IHRvcCArICdweCc7XHJcbiAgICB9XHJcblxyXG4gICAgcHVibGljIGFsaWduVG9wKHdpZHRoT3V0PzogbnVtYmVyKTogdm9pZCB7XHJcbiAgICAgICAgLy8gYWRkZWQgMiBsaW5lLiBlZGl0ZWQgcHJlQWxpZ24gd2l0aCBwYXJhbSBhbmQgd2lkdGhPdXRcclxuICAgICAgICB0aGlzLnByZUFsaWduKCd0b3AnKTtcclxuICAgICAgICBpZiAod2lkdGhPdXQgIT09IDAgJiYgdHlwZW9mIHdpZHRoT3V0ICE9PSAndW5kZWZpbmVkJykge1xyXG4gICAgICAgICAgICB0aGlzLmNvbnRhaW5lci5zdHlsZS5tYXhXaWR0aCA9IChEb21IYW5kbGVyLmdldE91dGVyV2lkdGgodGhpcy5jb250YWluZXIpIC0gd2lkdGhPdXQgKiAyKS50b1N0cmluZygpICsgJ3B4JztcclxuICAgICAgICB9XHJcbiAgICAgICAgbGV0IGhvc3RPZmZzZXQ6IHsgbGVmdDogbnVtYmVyLCB0b3A6IG51bWJlciB9ID0gc3VwZXIuZ2V0SG9zdE9mZnNldCgpO1xyXG4gICAgICAgIGxldCB3aWR0aDogbnVtYmVyID0gRG9tSGFuZGxlci5nZXRPdXRlcldpZHRoKHRoaXMuY29udGFpbmVyKTtcclxuICAgICAgICBsZXQgaGVpZ2h0OiBudW1iZXIgPSBEb21IYW5kbGVyLmdldE91dGVySGVpZ2h0KHRoaXMuY29udGFpbmVyKTtcclxuICAgICAgICBsZXQgbGVmdDogbnVtYmVyID0gaG9zdE9mZnNldC5sZWZ0ICsgKERvbUhhbmRsZXIuZ2V0T3V0ZXJXaWR0aCh0aGlzLl9lbC5uYXRpdmVFbGVtZW50KSAtIERvbUhhbmRsZXIuZ2V0T3V0ZXJXaWR0aCh0aGlzLmNvbnRhaW5lcikpIC8gMiArIHRoaXMuX29mZnNldC54O1xyXG4gICAgICAgIGxldCB0b3A6IG51bWJlciA9IGhvc3RPZmZzZXQudG9wIC0gRG9tSGFuZGxlci5nZXRPdXRlckhlaWdodCh0aGlzLmNvbnRhaW5lcikgKyB0aGlzLl9vZmZzZXQueTtcclxuXHJcbiAgICAgICAgdGhpcy5faXNPdXRPZkJvdW5kcyA9IHRoaXMuX2NoZWNrT3V0T2ZCb3VuZHMobGVmdCwgdG9wLCB3aWR0aCwgaGVpZ2h0KTtcclxuICAgICAgICB0aGlzLmNvbnRhaW5lci5zdHlsZS5sZWZ0ID0gbGVmdCArICdweCc7XHJcbiAgICAgICAgdGhpcy5jb250YWluZXIuc3R5bGUudG9wID0gdG9wICsgJ3B4JztcclxuICAgIH1cclxuXHJcbiAgICAvLyBuZXcgZGlyZWN0aW9uXHJcbiAgICBwdWJsaWMgYWxpZ25Ub3BSaWdodCh3aWR0aE91dD86IG51bWJlcik6IHZvaWQge1xyXG4gICAgICAgIHRoaXMucHJlQWxpZ24oJ3RvcCB1aS10b29sdGlwLXRvcC1yaWdodCcpO1xyXG4gICAgICAgIGlmICh3aWR0aE91dCAhPT0gMCAmJiB0eXBlb2Ygd2lkdGhPdXQgIT09ICd1bmRlZmluZWQnKSB0aGlzLmNvbnRhaW5lci5zdHlsZS5tYXhXaWR0aCA9IChEb21IYW5kbGVyLmdldE91dGVyV2lkdGgodGhpcy5jb250YWluZXIpIC0gd2lkdGhPdXQgKiAyKS50b1N0cmluZygpICsgJ3B4JztcclxuXHJcbiAgICAgICAgbGV0IGhvc3RPZmZzZXQ6IHsgbGVmdDogbnVtYmVyLCB0b3A6IG51bWJlciB9ID0gc3VwZXIuZ2V0SG9zdE9mZnNldCgpO1xyXG4gICAgICAgIGxldCB3aWR0aDogbnVtYmVyID0gRG9tSGFuZGxlci5nZXRPdXRlcldpZHRoKHRoaXMuY29udGFpbmVyKTtcclxuICAgICAgICBsZXQgaGVpZ2h0OiBudW1iZXIgPSBEb21IYW5kbGVyLmdldE91dGVySGVpZ2h0KHRoaXMuY29udGFpbmVyKTtcclxuICAgICAgICBsZXQgbGVmdDogbnVtYmVyID0gaG9zdE9mZnNldC5sZWZ0ICsgRG9tSGFuZGxlci5nZXRPdXRlcldpZHRoKHRoaXMuX2VsLm5hdGl2ZUVsZW1lbnQpIC8gMiAtIHRoaXMuX2RlZmF1bHRPZmZzZXQgKyB0aGlzLl9vZmZzZXQueDtcclxuICAgICAgICBsZXQgdG9wOiBudW1iZXIgPSBob3N0T2Zmc2V0LnRvcCAtIERvbUhhbmRsZXIuZ2V0T3V0ZXJIZWlnaHQodGhpcy5jb250YWluZXIpICsgdGhpcy5fb2Zmc2V0Lnk7XHJcblxyXG4gICAgICAgIHRoaXMuX2lzT3V0T2ZCb3VuZHMgPSB0aGlzLl9jaGVja091dE9mQm91bmRzKGxlZnQsIHRvcCwgd2lkdGgsIGhlaWdodCk7XHJcbiAgICAgICAgdGhpcy5jb250YWluZXIuc3R5bGUubGVmdCA9IGxlZnQgKyAncHgnO1xyXG4gICAgICAgIHRoaXMuY29udGFpbmVyLnN0eWxlLnRvcCA9IHRvcCArICdweCc7XHJcbiAgICB9XHJcblxyXG4gICAgLy8gbmV3IGRpcmVjdGlvblxyXG4gICAgcHVibGljIGFsaWduVG9wTGVmdCh3aWR0aE91dD86IG51bWJlcik6IHZvaWQge1xyXG4gICAgICAgIHRoaXMucHJlQWxpZ24oJ3RvcCB1aS10b29sdGlwLXRvcC1sZWZ0Jyk7XHJcbiAgICAgICAgaWYgKHdpZHRoT3V0ICE9PSAwICYmIHR5cGVvZiB3aWR0aE91dCAhPT0gJ3VuZGVmaW5lZCcpIHRoaXMuY29udGFpbmVyLnN0eWxlLm1heFdpZHRoID0gKERvbUhhbmRsZXIuZ2V0T3V0ZXJXaWR0aCh0aGlzLmNvbnRhaW5lcikgLSB3aWR0aE91dCAqIDIpLnRvU3RyaW5nKCkgKyAncHgnO1xyXG5cclxuICAgICAgICBsZXQgaG9zdE9mZnNldDogeyBsZWZ0OiBudW1iZXIsIHRvcDogbnVtYmVyIH0gPSBzdXBlci5nZXRIb3N0T2Zmc2V0KCk7XHJcbiAgICAgICAgbGV0IHdpZHRoOiBudW1iZXIgPSBEb21IYW5kbGVyLmdldE91dGVyV2lkdGgodGhpcy5jb250YWluZXIpO1xyXG4gICAgICAgIGxldCBoZWlnaHQ6IG51bWJlciA9IERvbUhhbmRsZXIuZ2V0T3V0ZXJIZWlnaHQodGhpcy5jb250YWluZXIpO1xyXG4gICAgICAgIGxldCBsZWZ0OiBudW1iZXIgPSBob3N0T2Zmc2V0LmxlZnQgKyBEb21IYW5kbGVyLmdldE91dGVyV2lkdGgodGhpcy5fZWwubmF0aXZlRWxlbWVudCkgLyAyIC0gRG9tSGFuZGxlci5nZXRPdXRlcldpZHRoKHRoaXMuY29udGFpbmVyKSArIHRoaXMuX2RlZmF1bHRPZmZzZXQgKyB0aGlzLl9vZmZzZXQueDtcclxuICAgICAgICBsZXQgdG9wOiBudW1iZXIgPSBob3N0T2Zmc2V0LnRvcCAtIERvbUhhbmRsZXIuZ2V0T3V0ZXJIZWlnaHQodGhpcy5jb250YWluZXIpICsgdGhpcy5fb2Zmc2V0Lnk7XHJcblxyXG4gICAgICAgIHRoaXMuX2lzT3V0T2ZCb3VuZHMgPSB0aGlzLl9jaGVja091dE9mQm91bmRzKGxlZnQsIHRvcCwgd2lkdGgsIGhlaWdodCk7XHJcbiAgICAgICAgdGhpcy5jb250YWluZXIuc3R5bGUubGVmdCA9IGxlZnQgKyAncHgnO1xyXG4gICAgICAgIHRoaXMuY29udGFpbmVyLnN0eWxlLnRvcCA9IHRvcCArICdweCc7XHJcbiAgICB9XHJcblxyXG5cclxuICAgIHB1YmxpYyBhbGlnbkJvdHRvbSh3aWR0aE91dD86IG51bWJlcik6IHZvaWQge1xyXG4gICAgICAgIC8vIGFkZGVkIDIgbGluZS4gZWRpdGVkIHByZUFsaWduIHdpdGggcGFyYW0gYW5kIHdpZHRoT3V0XHJcbiAgICAgICAgdGhpcy5wcmVBbGlnbignYm90dG9tJyk7XHJcbiAgICAgICAgaWYgKHdpZHRoT3V0ICE9PSAwICYmIHR5cGVvZiB3aWR0aE91dCAhPT0gJ3VuZGVmaW5lZCcpIHRoaXMuY29udGFpbmVyLnN0eWxlLm1heFdpZHRoID0gKERvbUhhbmRsZXIuZ2V0T3V0ZXJXaWR0aCh0aGlzLmNvbnRhaW5lcikgLSB3aWR0aE91dCAqIDIpLnRvU3RyaW5nKCkgKyAncHgnO1xyXG5cclxuICAgICAgICBsZXQgaG9zdE9mZnNldDogeyBsZWZ0OiBudW1iZXIsIHRvcDogbnVtYmVyIH0gPSBzdXBlci5nZXRIb3N0T2Zmc2V0KCk7XHJcbiAgICAgICAgbGV0IHdpZHRoOiBudW1iZXIgPSBEb21IYW5kbGVyLmdldE91dGVyV2lkdGgodGhpcy5jb250YWluZXIpO1xyXG4gICAgICAgIGxldCBoZWlnaHQ6IG51bWJlciA9IERvbUhhbmRsZXIuZ2V0T3V0ZXJIZWlnaHQodGhpcy5jb250YWluZXIpO1xyXG4gICAgICAgIGxldCBsZWZ0OiBudW1iZXIgPSBob3N0T2Zmc2V0LmxlZnQgKyAoRG9tSGFuZGxlci5nZXRPdXRlcldpZHRoKHRoaXMuX2VsLm5hdGl2ZUVsZW1lbnQpIC0gRG9tSGFuZGxlci5nZXRPdXRlcldpZHRoKHRoaXMuY29udGFpbmVyKSkgLyAyICsgdGhpcy5fb2Zmc2V0Lng7XHJcbiAgICAgICAgbGV0IHRvcDogbnVtYmVyID0gaG9zdE9mZnNldC50b3AgKyBEb21IYW5kbGVyLmdldE91dGVySGVpZ2h0KHRoaXMuX2VsLm5hdGl2ZUVsZW1lbnQpICsgdGhpcy5fb2Zmc2V0Lnk7XHJcblxyXG4gICAgICAgIHRoaXMuX2lzT3V0T2ZCb3VuZHMgPSB0aGlzLl9jaGVja091dE9mQm91bmRzKGxlZnQsIHRvcCwgd2lkdGgsIGhlaWdodCk7XHJcbiAgICAgICAgdGhpcy5jb250YWluZXIuc3R5bGUubGVmdCA9IGxlZnQgKyAncHgnO1xyXG4gICAgICAgIHRoaXMuY29udGFpbmVyLnN0eWxlLnRvcCA9IHRvcCArICdweCc7XHJcbiAgICB9XHJcblxyXG4gICAgLy8gbmV3IGRpcmVjdGlvblxyXG4gICAgcHVibGljIGFsaWduQm90dG9tUmlnaHQod2lkdGhPdXQ/OiBudW1iZXIpOiB2b2lkIHtcclxuICAgICAgICB0aGlzLnByZUFsaWduKCdib3R0b20gdWktdG9vbHRpcC1ib3R0b20tcmlnaHQnKTtcclxuICAgICAgICBpZiAod2lkdGhPdXQgIT09IDAgJiYgdHlwZW9mIHdpZHRoT3V0ICE9PSAndW5kZWZpbmVkJykgdGhpcy5jb250YWluZXIuc3R5bGUubWF4V2lkdGggPSAoRG9tSGFuZGxlci5nZXRPdXRlcldpZHRoKHRoaXMuY29udGFpbmVyKSAtIHdpZHRoT3V0ICogMikudG9TdHJpbmcoKSArICdweCc7XHJcblxyXG4gICAgICAgIGxldCBob3N0T2Zmc2V0OiB7IGxlZnQ6IG51bWJlciwgdG9wOiBudW1iZXIgfSA9IHN1cGVyLmdldEhvc3RPZmZzZXQoKTtcclxuICAgICAgICBsZXQgd2lkdGg6IG51bWJlciA9IERvbUhhbmRsZXIuZ2V0T3V0ZXJXaWR0aCh0aGlzLmNvbnRhaW5lcik7XHJcbiAgICAgICAgbGV0IGhlaWdodDogbnVtYmVyID0gRG9tSGFuZGxlci5nZXRPdXRlckhlaWdodCh0aGlzLmNvbnRhaW5lcik7XHJcbiAgICAgICAgbGV0IGxlZnQ6IG51bWJlciA9IGhvc3RPZmZzZXQubGVmdCArIERvbUhhbmRsZXIuZ2V0T3V0ZXJXaWR0aCh0aGlzLl9lbC5uYXRpdmVFbGVtZW50KSAvIDIgLSB0aGlzLl9kZWZhdWx0T2Zmc2V0ICsgdGhpcy5fb2Zmc2V0Lng7XHJcbiAgICAgICAgbGV0IHRvcDogbnVtYmVyID0gaG9zdE9mZnNldC50b3AgKyBEb21IYW5kbGVyLmdldE91dGVySGVpZ2h0KHRoaXMuX2VsLm5hdGl2ZUVsZW1lbnQpICsgdGhpcy5fb2Zmc2V0Lnk7XHJcblxyXG4gICAgICAgIHRoaXMuX2lzT3V0T2ZCb3VuZHMgPSB0aGlzLl9jaGVja091dE9mQm91bmRzKGxlZnQsIHRvcCwgd2lkdGgsIGhlaWdodCk7XHJcbiAgICAgICAgdGhpcy5jb250YWluZXIuc3R5bGUubGVmdCA9IGxlZnQgKyAncHgnO1xyXG4gICAgICAgIHRoaXMuY29udGFpbmVyLnN0eWxlLnRvcCA9IHRvcCArICdweCc7XHJcbiAgICB9XHJcblxyXG4gICAgLy8gbmV3IGRpcmVjdGlvblxyXG4gICAgcHVibGljIGFsaWduQm90dG9tTGVmdCh3aWR0aE91dD86IG51bWJlcik6IHZvaWQge1xyXG4gICAgICAgIHRoaXMucHJlQWxpZ24oJ2JvdHRvbSB1aS10b29sdGlwLWJvdHRvbS1sZWZ0Jyk7XHJcbiAgICAgICAgaWYgKHdpZHRoT3V0ICE9PSAwICYmIHR5cGVvZiB3aWR0aE91dCAhPT0gJ3VuZGVmaW5lZCcpIHRoaXMuY29udGFpbmVyLnN0eWxlLm1heFdpZHRoID0gKERvbUhhbmRsZXIuZ2V0T3V0ZXJXaWR0aCh0aGlzLmNvbnRhaW5lcikgLSB3aWR0aE91dCAqIDIpLnRvU3RyaW5nKCkgKyAncHgnO1xyXG5cclxuICAgICAgICBsZXQgaG9zdE9mZnNldDogeyBsZWZ0OiBudW1iZXIsIHRvcDogbnVtYmVyIH0gPSBzdXBlci5nZXRIb3N0T2Zmc2V0KCk7XHJcbiAgICAgICAgbGV0IHdpZHRoOiBudW1iZXIgPSBEb21IYW5kbGVyLmdldE91dGVyV2lkdGgodGhpcy5jb250YWluZXIpO1xyXG4gICAgICAgIGxldCBoZWlnaHQ6IG51bWJlciA9IERvbUhhbmRsZXIuZ2V0T3V0ZXJIZWlnaHQodGhpcy5jb250YWluZXIpO1xyXG4gICAgICAgIGxldCBsZWZ0OiBudW1iZXIgPSBob3N0T2Zmc2V0LmxlZnQgKyBEb21IYW5kbGVyLmdldE91dGVyV2lkdGgodGhpcy5fZWwubmF0aXZlRWxlbWVudCkgLyAyIC0gRG9tSGFuZGxlci5nZXRPdXRlcldpZHRoKHRoaXMuY29udGFpbmVyKSArIHRoaXMuX2RlZmF1bHRPZmZzZXQgKyB0aGlzLl9vZmZzZXQueDtcclxuICAgICAgICBsZXQgdG9wOiBudW1iZXIgPSBob3N0T2Zmc2V0LnRvcCArIERvbUhhbmRsZXIuZ2V0T3V0ZXJIZWlnaHQodGhpcy5fZWwubmF0aXZlRWxlbWVudCkgKyB0aGlzLl9vZmZzZXQueTtcclxuXHJcbiAgICAgICAgdGhpcy5faXNPdXRPZkJvdW5kcyA9IHRoaXMuX2NoZWNrT3V0T2ZCb3VuZHMobGVmdCwgdG9wLCB3aWR0aCwgaGVpZ2h0KTtcclxuICAgICAgICB0aGlzLmNvbnRhaW5lci5zdHlsZS5sZWZ0ID0gbGVmdCArICdweCc7XHJcbiAgICAgICAgdGhpcy5jb250YWluZXIuc3R5bGUudG9wID0gdG9wICsgJ3B4JztcclxuICAgIH1cclxuXHJcbiAgICBwdWJsaWMgcHJlQWxpZ24oX3Bvc2l0aW9uPzogc3RyaW5nKTogdm9pZCB7XHJcbiAgICAgICAgdGhpcy5jb250YWluZXIuc3R5bGUubGVmdCA9IC05OTkgKyAncHgnO1xyXG4gICAgICAgIHRoaXMuY29udGFpbmVyLnN0eWxlLnRvcCA9IC05OTkgKyAncHgnO1xyXG5cclxuICAgICAgICAvLyBhZGRlZCAyIGxpbmUuIGRlZmF1bHRDbGFzc05hbWUgYW5kIGNvbnRhaW5lci5jbGFzc05hbWVcclxuICAgICAgICBsZXQgZGVmYXVsdENsYXNzTmFtZTogc3RyaW5nID0gJ3VpLXRvb2x0aXAgdWktd2lkZ2V0IHVpLXRvb2x0aXAtJyArIF9wb3NpdGlvbjtcclxuICAgICAgICB0aGlzLmNvbnRhaW5lci5jbGFzc05hbWUgPSB0aGlzLnRvb2x0aXBTdHlsZUNsYXNzID8gZGVmYXVsdENsYXNzTmFtZSArICcgJyArIHRoaXMudG9vbHRpcFN0eWxlQ2xhc3MgOiBkZWZhdWx0Q2xhc3NOYW1lO1xyXG4gICAgfVxyXG5cclxuICAgIC8vIHRlbXAgZml4OiBjaGVja2luZyBvdXQgb2YgYm91bmRzIHNob3VsZCBoYXBwZW4gYmVmb3JlIHdvcmR3cmFwIGNoYW5nZXMgdGhlIHNpemUgb24gdG9vbHRpcFxyXG4gICAgcHJpdmF0ZSBfY2hlY2tPdXRPZkJvdW5kcyhfbGVmdDogbnVtYmVyLCBfdG9wOiBudW1iZXIsIF93aWR0aDogbnVtYmVyLCBfaGVpZ2h0OiBudW1iZXIpIHtcclxuICAgICAgICBsZXQgdmlld3BvcnQgPSBEb21IYW5kbGVyLmdldFZpZXdwb3J0KCk7XHJcbiAgICAgICAgcmV0dXJuIChfbGVmdCArIF93aWR0aCA+IHZpZXdwb3J0LndpZHRoKSB8fCAoX2xlZnQgPCAwKSB8fCAoX3RvcCA8IDApIHx8IChfdG9wICsgX2hlaWdodCA+IHZpZXdwb3J0LmhlaWdodCk7XHJcbiAgICB9XHJcblxyXG4gICAgcHVibGljIHJlbW92ZSgpOiB2b2lkIHtcclxuICAgICAgICBpZiAoIXRoaXMuX2RlYWN0aXZhdGVIb3N0TGlzdGVuZXIpIHtcclxuICAgICAgICAgICAgLy8gYWRkZWQgb25lIGxpbmUsIF91bmJpbmREb2N1bWVudFRvdWNoU3RhcnRMaXN0bmVyKClcclxuICAgICAgICAgICAgaWYgKHRoaXMuX2lzTW9iaWxlKSB0aGlzLl91bmJpbmREb2N1bWVudFRvdWNoU3RhcnRMaXN0bmVyKCk7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGlmICh0aGlzLmNvbnRhaW5lciAmJiB0aGlzLmNvbnRhaW5lci5wYXJlbnRFbGVtZW50KSB7XHJcbiAgICAgICAgICAgIGlmICh0aGlzLmFwcGVuZFRvID09PSAnYm9keScpIHtcclxuICAgICAgICAgICAgICAgIGRvY3VtZW50LmJvZHkucmVtb3ZlQ2hpbGQodGhpcy5jb250YWluZXIpO1xyXG4gICAgICAgICAgICB9IGVsc2UgaWYgKHRoaXMuYXBwZW5kVG8gPT09ICd0YXJnZXQnKSB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLl9lbC5uYXRpdmVFbGVtZW50LnJlbW92ZUNoaWxkKHRoaXMuY29udGFpbmVyKTtcclxuICAgICAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgICAgIERvbUhhbmRsZXIucmVtb3ZlQ2hpbGQodGhpcy5jb250YWluZXIsIHRoaXMuYXBwZW5kVG8pO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgICAgIHRoaXMuY29udGFpbmVyID0gbnVsbDtcclxuICAgIH1cclxuXHJcbiAgICAvKioqKioqKipOZXcgRnVuY3Rpb25zKioqKioqKioqKiovXHJcbiAgICBwcml2YXRlIF9pbml0QXBpKCk6IHZvaWQge1xyXG4gICAgICAgIGlmICh0eXBlb2YgdGhpcy5hcGkgIT09ICd1bmRlZmluZWQnKSB7XHJcbiAgICAgICAgICAgIHRoaXMuYXBpLnNob3dUb29sdGlwID0gKCk6IHZvaWQgPT4gc3VwZXIuYWN0aXZhdGUoKTtcclxuICAgICAgICAgICAgdGhpcy5hcGkuaGlkZVRvb2x0aXAgPSAoKTogdm9pZCA9PiBzdXBlci5kZWFjdGl2YXRlKCk7XHJcbiAgICAgICAgICAgIHRoaXMuYXBpLmRlYWN0aXZhdGVIb3N0TGlzdGVuZXIgPSAoKTogdm9pZCA9PiB7IHRoaXMuX2RlYWN0aXZhdGVIb3N0TGlzdGVuZXIgPSB0cnVlOyB9O1xyXG4gICAgICAgICAgICB0aGlzLmFwaS5hY3RpdmF0ZUhvc3RMaXN0ZW5lciA9ICgpOiB2b2lkID0+IHsgdGhpcy5fZGVhY3RpdmF0ZUhvc3RMaXN0ZW5lciA9IGZhbHNlOyB9O1xyXG4gICAgICAgICAgICB0aGlzLmFwaS5hbGlnbiA9ICgpOiB2b2lkID0+IHtcclxuICAgICAgICAgICAgICAgIGlmICghdGhpcy5jb250YWluZXIpIHJldHVybjtcclxuICAgICAgICAgICAgICAgIHRoaXMuYWxpZ24oKTtcclxuICAgICAgICAgICAgfTtcclxuICAgICAgICAgICAgdGhpcy5hcGkuc2V0T2Zmc2V0ID0gKF9vZmZzZXQ6IHsgeDogbnVtYmVyLCB5OiBudW1iZXIgfSk6IHZvaWQgPT4geyB0aGlzLl9vZmZzZXQgPSBfb2Zmc2V0OyB9O1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF9jYWxjdWxhdGVXaWR0aE91dCgpOiBudW1iZXIge1xyXG4gICAgICAgIGxldCBvZmZzZXQ6IENsaWVudFJlY3QgPSB0aGlzLmNvbnRhaW5lci5nZXRCb3VuZGluZ0NsaWVudFJlY3QoKTtcclxuICAgICAgICBsZXQgdGFyZ2V0TGVmdDogbnVtYmVyID0gb2Zmc2V0LmxlZnQ7XHJcbiAgICAgICAgbGV0IHdpZHRoOiBudW1iZXIgPSBEb21IYW5kbGVyLmdldE91dGVyV2lkdGgodGhpcy5jb250YWluZXIpO1xyXG4gICAgICAgIGxldCB2aWV3cG9ydDogYW55ID0gRG9tSGFuZGxlci5nZXRWaWV3cG9ydCgpO1xyXG5cclxuICAgICAgICBpZiAodGFyZ2V0TGVmdCArIHdpZHRoIC0gdmlld3BvcnQud2lkdGggPiAwKSByZXR1cm4gdGFyZ2V0TGVmdCArIHdpZHRoIC0gdmlld3BvcnQud2lkdGg7XHJcbiAgICAgICAgaWYgKHRhcmdldExlZnQgPCAwKSByZXR1cm4gdGFyZ2V0TGVmdCAqIC0xO1xyXG5cclxuICAgICAgICByZXR1cm4gMDtcclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF9iaW5kRG9jdW1lbnRUb3VjaFN0YXJ0TGlzdGVuZXIoKTogdm9pZCB7XHJcbiAgICAgICAgdGhpcy5fZG9jdW1lbnRUb3VjaFN0YXJ0TGlzdGVuZXIgPSB0aGlzLl9yZW5kZXJlci5saXN0ZW4oXHJcbiAgICAgICAgICAgICdkb2N1bWVudCcsXHJcbiAgICAgICAgICAgICd0b3VjaHN0YXJ0JyxcclxuICAgICAgICAgICAgZXZlbnQgPT4ge1xyXG4gICAgICAgICAgICAgICAgc3VwZXIuaGlkZSgpO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgKTtcclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF91bmJpbmREb2N1bWVudFRvdWNoU3RhcnRMaXN0bmVyKCk6IHZvaWQge1xyXG4gICAgICAgIGlmICh0aGlzLl9kb2N1bWVudFRvdWNoU3RhcnRMaXN0ZW5lcikge1xyXG4gICAgICAgICAgICB0aGlzLl9kb2N1bWVudFRvdWNoU3RhcnRMaXN0ZW5lcigpO1xyXG4gICAgICAgICAgICB0aGlzLl9kb2N1bWVudFRvdWNoU3RhcnRMaXN0ZW5lciA9IG51bGw7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIG5nT25EZXN0cm95KCk6IHZvaWQge1xyXG4gICAgICAgIC8vIHN1cGVyLnVuYmluZEV2ZW50cygpO1xyXG4gICAgICAgIHRoaXMucmVtb3ZlKCk7XHJcbiAgICAgICAgLy8gYWRkZWQgMiBsaW5lLiB1bnN1YnNjcmlwdGlvblxyXG4gICAgICAgIHRoaXMuX2RyYWdNZW51U3ViLnVuc3Vic2NyaWJlKCk7XHJcbiAgICAgICAgdGhpcy5fdG9nZ2xlTWVudVN1Yi51bnN1YnNjcmliZSgpO1xyXG4gICAgfVxyXG59XHJcbiJdfQ==