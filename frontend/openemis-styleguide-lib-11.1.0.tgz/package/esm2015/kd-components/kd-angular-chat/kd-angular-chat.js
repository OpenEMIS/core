import { Component, Input, EventEmitter, Output, ChangeDetectorRef } from '@angular/core';
export class KdChat {
    constructor(cdr) {
        this.cdr = cdr;
        this.messageArray = [];
        this.dropdownData = [];
        this.inputMessage = new EventEmitter();
        this.showChatBot = true;
        this.recordCount = 0;
        this.disableInput = false;
        this.countRecord = 0;
        this.tooltipData = 'Record Audio';
        this.displaySubmit = false;
        this.dropdownWithoutLabel = [{
                key: 'examination_id',
                visible: true,
                required: true,
                order: 1,
                controlType: 'dropdown',
                'options': [],
                events: true
            }];
        this.filterButtons = [
            {
                name: '',
                class: 'd-none'
            },
            {
                name: '',
                class: 'd-none'
            }
        ];
    }
    ngOnInit() {
        this.dropdownWithoutLabel[0].options = this.dropdownData;
    }
    sendMessage() {
        if (this.messageData == '' || this.messageData == undefined) {
            // alert("Please fill message");
        }
        else {
            this.inputMessage.emit(this.messageData);
            // this.messageArray.push({ to: this.messageData });
            // this.messageArray.push({ from: 'Hi, How are you?' });
            this.messageData = '';
            this.displaySubmit = false;
            console.log(this.messageArray, "this.messageArray");
            this.cdr.detectChanges();
        }
    }
    getEditMessage(event) {
        if (this.messageData == '' || this.messageData == undefined) {
            this.displaySubmit = false;
        }
        else {
            this.displaySubmit = true;
        }
    }
    toggleRecording() {
        if (this.countRecord % 2 == 0) {
            this.disableInput = true;
            this.tooltipData = 'Press to stop';
            this.messageData = 'Recording: 0:00';
            this.startTime = new Date();
            this.recordingInterval = setInterval(() => this.updateRecordingTime(this.messageData), 1000);
        }
        else {
            this.tooltipData = 'Record Audio';
            this.disableInput = false;
            clearInterval(this.recordingInterval);
            this.messageData = '';
        }
        this.countRecord++;
    }
    updateRecordingTime(messageData) {
        const currentTime = new Date();
        const diff = Math.floor((currentTime - this.startTime) / 1000);
        const minutes = Math.floor(diff / 60);
        const seconds = diff % 60;
        this.messageData = `Recording: ${minutes}:${seconds < 10 ? '0' : ''}${seconds}`;
    }
    _changeEvent(event) {
        console.log(event, "event");
        if (event.value) {
            this.showChatBot = false;
            this.messageData = event.value;
            this.sendMessage();
        }
    }
    ngOnDestroy() {
    }
}
KdChat.decorators = [
    { type: Component, args: [{
                selector: 'kd-chat',
                template: "<div class=\"position-relative\">\r\n    <div class=\"\">\r\n        <!-- <kd-view displayType=\"form\" [inputData]=\"dropdownWithoutLabel\" [button]=\"filterButtons\"\r\n            (change)=\"_changeEvent($event)\"></kd-view> -->\r\n        <kd-filter displayType='horizontal-form' [inputData]=\"dropdownWithoutLabel\" (valueUpdate)=\"_changeEvent($event)\"></kd-filter>\r\n    </div>\r\n    <div class=\"main-body-contant\" #scrollMe [scrollTop]=\"scrollMe.scrollHeight\">\r\n        <div class=\"container\">\r\n            <div class=\"message-container pt-2\">\r\n                <div class=\"abs-scroll-div\" *ngIf=\"messageArray.length > 0\">\r\n                    <ng-container *ngFor=\"let message of messageArray\">\r\n                        <div class=\"mr-2\">\r\n                            <p class=\"message-to\" *ngIf=\"message?.to\">\r\n                                {{ message?.to }}\r\n                            </p>\r\n                        </div>\r\n                        <div>\r\n                            <div class=\"d-flex\" *ngIf=\"message?.from\">\r\n                                <img src=\"assets/img/chat_logo.png\" class=\"chat-icon\" />\r\n                                <div class=\"message-from != '' && !message?.isTyping\">\r\n                                    {{ message?.from }}\r\n                                </div>\r\n                            </div>\r\n                            <div class=\"d-flex\" *ngIf=\"message?.from == '' && message?.isTyping\">\r\n                                <img src=\"assets/img/chat_logo.png\" class=\"chat-icon\" />\r\n                                <div class=\"message-from\">\r\n                                    <span class=\"dot\">.</span>\r\n                                    <span class=\"dot\">.</span>\r\n                                    <span class=\"dot\">.</span>\r\n                                </div>\r\n                            </div>\r\n                        </div>\r\n                    </ng-container>\r\n                </div>\r\n            </div>\r\n            <!-- <div class=\"position-relative\"> -->\r\n            <div class=\"\" style=\"position: relative; bottom: 0; left: 0;\" *ngIf=\"messageArray.length > 0\">\r\n                <form #chatForm (ngSubmit)=\"sendMessage()\" class=\"\">\r\n                    <div id=\"input-container\" class=\"input-group input-container\">\r\n                        <input type=\"text\" id=\"user-input\" class=\"form-control input-disabled message-input\"\r\n                            (keyup)=\"getEditMessage($event)\" [(ngModel)]=\"messageData\" name=\"message\"\r\n                            placeholder=\"Type your message...\" [disabled]=\"disableInput\" />\r\n                        <i class='fa fa-microphone microphone-data' placement=\"top\" [ngbTooltip]=\"tooltipData\"\r\n                            (click)=\"toggleRecording()\"></i>\r\n                        <div class=\"input-group-append\" (click)=\"sendMessage()\" *ngIf=\"displaySubmit\">\r\n                            <i class=\"fa fa-arrow-up submit-chat-arrow\"></i>\r\n                        </div>\r\n                        <div class=\"input-group-append\" *ngIf=\"!displaySubmit\">\r\n                            <i class=\"fa fa-arrow-up disable-chat-arrow\"></i>\r\n                        </div>\r\n                    </div>\r\n                </form>\r\n            </div>\r\n            <!-- </div> -->\r\n        </div>\r\n    </div>\r\n</div>",
                styles: [".chat-container{-ms-flex-align:center;-webkit-box-align:center;align-items:center;background-size:cover;height:451px}.ai-driven-data{font-weight:700}.input-container{bottom:0;left:0;padding:15px;position:relative}.audio-button{cursor:pointer}.input-group-prepend{margin:6px}::ng-deep .chatbot-dropdown .kdx .kdx-input-select-wrapper{width:100%!important}.message-container{background:#fff;margin-left:3rem;margin-right:3rem}.abs-scroll-div{min-height:calc(100vh - 300px)}.message-to{background:#d3d3d3;border:1px solid #d3d3d3;border-radius:20px;margin-left:auto}.message-from,.message-to{font-size:14px;max-width:70%;padding:10px;width:-webkit-fit-content;width:-moz-fit-content;width:fit-content}.message-from{margin-right:auto;word-wrap:break-word}.chat-dropdown{background-color:#e0e0e0;height:45px;padding:7px;position:sticky;top:0}::ng-deep .kdx .kdx-input-select-wrapper select{background:#fff!important}.chat-icon{border-radius:5px;height:30px}.microphone-data{color:#000;cursor:pointer;font-size:20px;position:relative;right:30px;top:8px}.message-input{border-radius:5px!important;font-size:13px}.main-body-contant{max-height:calc(100vh - 222px);overflow:auto}.submit-chat-arrow{border-radius:50%;color:#fff;font-size:12px;padding:7px;position:relative;top:1px}.input-group-append{border-radius:1px;cursor:pointer;left:-12px;padding:7px;position:relative}.disable-chat-arrow{background:#e0e0e0;border-radius:50%;color:#fff;cursor:not-allowed;font-size:12px;padding:7px;position:relative;top:1px}@media (max-width:1024px){.main-body-contant{max-height:calc(100vh - 250px)}.abs-scroll-div{min-height:calc(100vh - 340px)}}@media (max-width:768px){.main-body-contant{max-height:calc(100vh - 265px)}.abs-scroll-div{min-height:calc(100vh - 345px)}.message-container{margin-left:25px;margin-right:25px}}@media (max-width:480px){.message-from{padding:0 0 0 6px}}@media (max-width:320px){.message-container{margin-left:18px;margin-right:18px}.message-to{border-radius:12px;padding:8px}.message-from,.message-to,input#user-input{font-size:12px}}.dot{-webkit-animation:blink 1.5s infinite;animation:blink 1.5s infinite;display:inline-block;font-size:18px;font-weight:800;opacity:0}.dot:nth-child(2){-webkit-animation-delay:.2s;animation-delay:.2s}.dot:nth-child(3){-webkit-animation-delay:.4s;animation-delay:.4s}@-webkit-keyframes blink{0%{opacity:0}50%{opacity:1}to{opacity:0}}@keyframes blink{0%{opacity:0}50%{opacity:1}to{opacity:0}}"]
            },] }
];
KdChat.ctorParameters = () => [
    { type: ChangeDetectorRef }
];
KdChat.propDecorators = {
    messageArray: [{ type: Input }],
    dropdownData: [{ type: Input }],
    inputMessage: [{ type: Output }]
};
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoia2QtYW5ndWxhci1jaGF0LmpzIiwic291cmNlUm9vdCI6IkM6L1Byb2plY3RzL0FuZ3VsYXIvaW9zdGctb3BlbmVtaXMtc3R5bGVndWlkZS9wcm9qZWN0cy9vcGVuZW1pcy1zdHlsZWd1aWRlLWxpYi9zcmMvIiwic291cmNlcyI6WyJrZC1jb21wb25lbnRzL2tkLWFuZ3VsYXItY2hhdC9rZC1hbmd1bGFyLWNoYXQudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsT0FBTyxFQUNILFNBQVMsRUFHVCxLQUFLLEVBQ0wsWUFBWSxFQUNaLE1BQU0sRUFDTixpQkFBaUIsRUFDcEIsTUFBTSxlQUFlLENBQUM7QUFRdkIsTUFBTSxPQUFPLE1BQU07SUFvQ2YsWUFBb0IsR0FBc0I7UUFBdEIsUUFBRyxHQUFILEdBQUcsQ0FBbUI7UUFuQ2pDLGlCQUFZLEdBQVUsRUFBRSxDQUFDO1FBQ3pCLGlCQUFZLEdBQVUsRUFBRSxDQUFDO1FBQ3hCLGlCQUFZLEdBQXNCLElBQUksWUFBWSxFQUFFLENBQUM7UUFHL0QsZ0JBQVcsR0FBWSxJQUFJLENBQUM7UUFDNUIsZ0JBQVcsR0FBVyxDQUFDLENBQUM7UUFDeEIsaUJBQVksR0FBWSxLQUFLLENBQUM7UUFDOUIsZ0JBQVcsR0FBVyxDQUFDLENBQUM7UUFDeEIsZ0JBQVcsR0FBUSxjQUFjLENBQUM7UUFDbEMsa0JBQWEsR0FBWSxLQUFLLENBQUM7UUFFeEIseUJBQW9CLEdBQWUsQ0FBQztnQkFDdkMsR0FBRyxFQUFFLGdCQUFnQjtnQkFDckIsT0FBTyxFQUFFLElBQUk7Z0JBQ2IsUUFBUSxFQUFFLElBQUk7Z0JBQ2QsS0FBSyxFQUFFLENBQUM7Z0JBQ1IsV0FBVyxFQUFFLFVBQVU7Z0JBQ3ZCLFNBQVMsRUFBRSxFQUFFO2dCQUNiLE1BQU0sRUFBRSxJQUFJO2FBQ2YsQ0FBQyxDQUFDO1FBRUksa0JBQWEsR0FBZTtZQUMvQjtnQkFDSSxJQUFJLEVBQUUsRUFBRTtnQkFDUixLQUFLLEVBQUUsUUFBUTthQUNsQjtZQUNEO2dCQUNJLElBQUksRUFBRSxFQUFFO2dCQUNSLEtBQUssRUFBRSxRQUFRO2FBQ2xCO1NBQ0osQ0FBQTtJQUk2QyxDQUFDO0lBRS9DLFFBQVE7UUFDSixJQUFJLENBQUMsb0JBQW9CLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxHQUFHLElBQUksQ0FBQyxZQUFZLENBQUM7SUFDN0QsQ0FBQztJQUVELFdBQVc7UUFDUCxJQUFJLElBQUksQ0FBQyxXQUFXLElBQUksRUFBRSxJQUFJLElBQUksQ0FBQyxXQUFXLElBQUksU0FBUyxFQUFFO1lBQ3pELGdDQUFnQztTQUNuQzthQUFNO1lBQ0gsSUFBSSxDQUFDLFlBQVksQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxDQUFDO1lBRXpDLG9EQUFvRDtZQUNwRCx3REFBd0Q7WUFDeEQsSUFBSSxDQUFDLFdBQVcsR0FBRyxFQUFFLENBQUM7WUFDdEIsSUFBSSxDQUFDLGFBQWEsR0FBRyxLQUFLLENBQUM7WUFDM0IsT0FBTyxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsWUFBWSxFQUFFLG1CQUFtQixDQUFDLENBQUM7WUFDcEQsSUFBSSxDQUFDLEdBQUcsQ0FBQyxhQUFhLEVBQUUsQ0FBQztTQUM1QjtJQUNMLENBQUM7SUFFRCxjQUFjLENBQUMsS0FBVTtRQUNyQixJQUFJLElBQUksQ0FBQyxXQUFXLElBQUksRUFBRSxJQUFJLElBQUksQ0FBQyxXQUFXLElBQUksU0FBUyxFQUFFO1lBQ3pELElBQUksQ0FBQyxhQUFhLEdBQUcsS0FBSyxDQUFDO1NBQzlCO2FBQU07WUFDSCxJQUFJLENBQUMsYUFBYSxHQUFHLElBQUksQ0FBQztTQUM3QjtJQUNMLENBQUM7SUFFRCxlQUFlO1FBQ1gsSUFBSSxJQUFJLENBQUMsV0FBVyxHQUFHLENBQUMsSUFBSSxDQUFDLEVBQUU7WUFDM0IsSUFBSSxDQUFDLFlBQVksR0FBRyxJQUFJLENBQUM7WUFDekIsSUFBSSxDQUFDLFdBQVcsR0FBRyxlQUFlLENBQUM7WUFDbkMsSUFBSSxDQUFDLFdBQVcsR0FBRyxpQkFBaUIsQ0FBQztZQUNyQyxJQUFJLENBQUMsU0FBUyxHQUFHLElBQUksSUFBSSxFQUFFLENBQUM7WUFDNUIsSUFBSSxDQUFDLGlCQUFpQixHQUFHLFdBQVcsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxJQUFJLENBQUMsbUJBQW1CLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxFQUFFLElBQUksQ0FBQyxDQUFDO1NBQ2hHO2FBQU07WUFDSCxJQUFJLENBQUMsV0FBVyxHQUFHLGNBQWMsQ0FBQztZQUNsQyxJQUFJLENBQUMsWUFBWSxHQUFHLEtBQUssQ0FBQztZQUMxQixhQUFhLENBQUMsSUFBSSxDQUFDLGlCQUFpQixDQUFDLENBQUM7WUFDdEMsSUFBSSxDQUFDLFdBQVcsR0FBRyxFQUFFLENBQUM7U0FDekI7UUFDRCxJQUFJLENBQUMsV0FBVyxFQUFFLENBQUM7SUFDdkIsQ0FBQztJQUVELG1CQUFtQixDQUFDLFdBQWdCO1FBQ2hDLE1BQU0sV0FBVyxHQUFRLElBQUksSUFBSSxFQUFFLENBQUM7UUFDcEMsTUFBTSxJQUFJLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFDLFdBQVcsR0FBRyxJQUFJLENBQUMsU0FBUyxDQUFDLEdBQUcsSUFBSSxDQUFDLENBQUM7UUFDL0QsTUFBTSxPQUFPLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQyxJQUFJLEdBQUcsRUFBRSxDQUFDLENBQUM7UUFDdEMsTUFBTSxPQUFPLEdBQUcsSUFBSSxHQUFHLEVBQUUsQ0FBQztRQUMxQixJQUFJLENBQUMsV0FBVyxHQUFHLGNBQWMsT0FBTyxJQUFJLE9BQU8sR0FBRyxFQUFFLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsRUFBRSxHQUFHLE9BQU8sRUFBRSxDQUFDO0lBQ3BGLENBQUM7SUFFRCxZQUFZLENBQUMsS0FBVTtRQUNuQixPQUFPLENBQUMsR0FBRyxDQUFDLEtBQUssRUFBRSxPQUFPLENBQUMsQ0FBQztRQUM1QixJQUFJLEtBQUssQ0FBQyxLQUFLLEVBQUU7WUFDYixJQUFJLENBQUMsV0FBVyxHQUFHLEtBQUssQ0FBQztZQUN6QixJQUFJLENBQUMsV0FBVyxHQUFHLEtBQUssQ0FBQyxLQUFLLENBQUM7WUFDL0IsSUFBSSxDQUFDLFdBQVcsRUFBRSxDQUFDO1NBQ3RCO0lBQ0wsQ0FBQztJQUVELFdBQVc7SUFFWCxDQUFDOzs7WUExR0osU0FBUyxTQUFDO2dCQUNQLFFBQVEsRUFBRSxTQUFTO2dCQUNuQiw0OEdBQXFDOzthQUV4Qzs7O1lBUEcsaUJBQWlCOzs7MkJBVWhCLEtBQUs7MkJBQ0wsS0FBSzsyQkFDTCxNQUFNIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHtcclxuICAgIENvbXBvbmVudCxcclxuICAgIE9uSW5pdCxcclxuICAgIE9uRGVzdHJveSxcclxuICAgIElucHV0LFxyXG4gICAgRXZlbnRFbWl0dGVyLFxyXG4gICAgT3V0cHV0LFxyXG4gICAgQ2hhbmdlRGV0ZWN0b3JSZWZcclxufSBmcm9tICdAYW5ndWxhci9jb3JlJztcclxuXHJcbkBDb21wb25lbnQoe1xyXG4gICAgc2VsZWN0b3I6ICdrZC1jaGF0JyxcclxuICAgIHRlbXBsYXRlVXJsOiAnLi9rZC1hbmd1bGFyLWNoYXQuaHRtbCcsXHJcbiAgICBzdHlsZVVybHM6IFsnLi9rZC1hbmd1bGFyLWNoYXQuc2NzcyddLFxyXG59KVxyXG5cclxuZXhwb3J0IGNsYXNzIEtkQ2hhdCBpbXBsZW1lbnRzIE9uSW5pdCwgT25EZXN0cm95IHtcclxuICAgIEBJbnB1dCgpIG1lc3NhZ2VBcnJheTogYW55W10gPSBbXTtcclxuICAgIEBJbnB1dCgpIGRyb3Bkb3duRGF0YTogYW55W10gPSBbXTtcclxuICAgIEBPdXRwdXQoKSBpbnB1dE1lc3NhZ2U6IEV2ZW50RW1pdHRlcjxhbnk+ID0gbmV3IEV2ZW50RW1pdHRlcigpO1xyXG4gICAgbWVzc2FnZURhdGE6IGFueTtcclxuICAgIGNoYXRGb3JtOiBhbnk7XHJcbiAgICBzaG93Q2hhdEJvdDogYm9vbGVhbiA9IHRydWU7XHJcbiAgICByZWNvcmRDb3VudDogbnVtYmVyID0gMDtcclxuICAgIGRpc2FibGVJbnB1dDogYm9vbGVhbiA9IGZhbHNlO1xyXG4gICAgY291bnRSZWNvcmQ6IG51bWJlciA9IDA7XHJcbiAgICB0b29sdGlwRGF0YTogYW55ID0gJ1JlY29yZCBBdWRpbyc7XHJcbiAgICBkaXNwbGF5U3VibWl0OiBib29sZWFuID0gZmFsc2U7XHJcblxyXG4gICAgcHVibGljIGRyb3Bkb3duV2l0aG91dExhYmVsOiBBcnJheTxhbnk+ID0gW3tcclxuICAgICAgICBrZXk6ICdleGFtaW5hdGlvbl9pZCcsXHJcbiAgICAgICAgdmlzaWJsZTogdHJ1ZSxcclxuICAgICAgICByZXF1aXJlZDogdHJ1ZSxcclxuICAgICAgICBvcmRlcjogMSxcclxuICAgICAgICBjb250cm9sVHlwZTogJ2Ryb3Bkb3duJyxcclxuICAgICAgICAnb3B0aW9ucyc6IFtdLFxyXG4gICAgICAgIGV2ZW50czogdHJ1ZVxyXG4gICAgfV07XHJcblxyXG4gICAgcHVibGljIGZpbHRlckJ1dHRvbnM6IEFycmF5PGFueT4gPSBbXHJcbiAgICAgICAge1xyXG4gICAgICAgICAgICBuYW1lOiAnJyxcclxuICAgICAgICAgICAgY2xhc3M6ICdkLW5vbmUnXHJcbiAgICAgICAgfSxcclxuICAgICAgICB7XHJcbiAgICAgICAgICAgIG5hbWU6ICcnLFxyXG4gICAgICAgICAgICBjbGFzczogJ2Qtbm9uZSdcclxuICAgICAgICB9XHJcbiAgICBdXHJcbiAgICByZWNvcmRpbmdJbnRlcnZhbDogYW55O1xyXG4gICAgc3RhcnRUaW1lOiBhbnk7XHJcblxyXG4gICAgY29uc3RydWN0b3IocHJpdmF0ZSBjZHI6IENoYW5nZURldGVjdG9yUmVmKSB7IH1cclxuXHJcbiAgICBuZ09uSW5pdCgpOiB2b2lkIHtcclxuICAgICAgICB0aGlzLmRyb3Bkb3duV2l0aG91dExhYmVsWzBdLm9wdGlvbnMgPSB0aGlzLmRyb3Bkb3duRGF0YTtcclxuICAgIH1cclxuXHJcbiAgICBzZW5kTWVzc2FnZSgpIHtcclxuICAgICAgICBpZiAodGhpcy5tZXNzYWdlRGF0YSA9PSAnJyB8fCB0aGlzLm1lc3NhZ2VEYXRhID09IHVuZGVmaW5lZCkge1xyXG4gICAgICAgICAgICAvLyBhbGVydChcIlBsZWFzZSBmaWxsIG1lc3NhZ2VcIik7XHJcbiAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgdGhpcy5pbnB1dE1lc3NhZ2UuZW1pdCh0aGlzLm1lc3NhZ2VEYXRhKTtcclxuXHJcbiAgICAgICAgICAgIC8vIHRoaXMubWVzc2FnZUFycmF5LnB1c2goeyB0bzogdGhpcy5tZXNzYWdlRGF0YSB9KTtcclxuICAgICAgICAgICAgLy8gdGhpcy5tZXNzYWdlQXJyYXkucHVzaCh7IGZyb206ICdIaSwgSG93IGFyZSB5b3U/JyB9KTtcclxuICAgICAgICAgICAgdGhpcy5tZXNzYWdlRGF0YSA9ICcnO1xyXG4gICAgICAgICAgICB0aGlzLmRpc3BsYXlTdWJtaXQgPSBmYWxzZTtcclxuICAgICAgICAgICAgY29uc29sZS5sb2codGhpcy5tZXNzYWdlQXJyYXksIFwidGhpcy5tZXNzYWdlQXJyYXlcIik7XHJcbiAgICAgICAgICAgIHRoaXMuY2RyLmRldGVjdENoYW5nZXMoKTtcclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgZ2V0RWRpdE1lc3NhZ2UoZXZlbnQ6IGFueSkge1xyXG4gICAgICAgIGlmICh0aGlzLm1lc3NhZ2VEYXRhID09ICcnIHx8IHRoaXMubWVzc2FnZURhdGEgPT0gdW5kZWZpbmVkKSB7XHJcbiAgICAgICAgICAgIHRoaXMuZGlzcGxheVN1Ym1pdCA9IGZhbHNlO1xyXG4gICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgIHRoaXMuZGlzcGxheVN1Ym1pdCA9IHRydWU7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIHRvZ2dsZVJlY29yZGluZygpIHtcclxuICAgICAgICBpZiAodGhpcy5jb3VudFJlY29yZCAlIDIgPT0gMCkge1xyXG4gICAgICAgICAgICB0aGlzLmRpc2FibGVJbnB1dCA9IHRydWU7XHJcbiAgICAgICAgICAgIHRoaXMudG9vbHRpcERhdGEgPSAnUHJlc3MgdG8gc3RvcCc7XHJcbiAgICAgICAgICAgIHRoaXMubWVzc2FnZURhdGEgPSAnUmVjb3JkaW5nOiAwOjAwJztcclxuICAgICAgICAgICAgdGhpcy5zdGFydFRpbWUgPSBuZXcgRGF0ZSgpO1xyXG4gICAgICAgICAgICB0aGlzLnJlY29yZGluZ0ludGVydmFsID0gc2V0SW50ZXJ2YWwoKCkgPT4gdGhpcy51cGRhdGVSZWNvcmRpbmdUaW1lKHRoaXMubWVzc2FnZURhdGEpLCAxMDAwKTtcclxuICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICB0aGlzLnRvb2x0aXBEYXRhID0gJ1JlY29yZCBBdWRpbyc7XHJcbiAgICAgICAgICAgIHRoaXMuZGlzYWJsZUlucHV0ID0gZmFsc2U7XHJcbiAgICAgICAgICAgIGNsZWFySW50ZXJ2YWwodGhpcy5yZWNvcmRpbmdJbnRlcnZhbCk7XHJcbiAgICAgICAgICAgIHRoaXMubWVzc2FnZURhdGEgPSAnJztcclxuICAgICAgICB9XHJcbiAgICAgICAgdGhpcy5jb3VudFJlY29yZCsrO1xyXG4gICAgfVxyXG5cclxuICAgIHVwZGF0ZVJlY29yZGluZ1RpbWUobWVzc2FnZURhdGE6IGFueSkge1xyXG4gICAgICAgIGNvbnN0IGN1cnJlbnRUaW1lOiBhbnkgPSBuZXcgRGF0ZSgpO1xyXG4gICAgICAgIGNvbnN0IGRpZmYgPSBNYXRoLmZsb29yKChjdXJyZW50VGltZSAtIHRoaXMuc3RhcnRUaW1lKSAvIDEwMDApO1xyXG4gICAgICAgIGNvbnN0IG1pbnV0ZXMgPSBNYXRoLmZsb29yKGRpZmYgLyA2MCk7XHJcbiAgICAgICAgY29uc3Qgc2Vjb25kcyA9IGRpZmYgJSA2MDtcclxuICAgICAgICB0aGlzLm1lc3NhZ2VEYXRhID0gYFJlY29yZGluZzogJHttaW51dGVzfToke3NlY29uZHMgPCAxMCA/ICcwJyA6ICcnfSR7c2Vjb25kc31gO1xyXG4gICAgfVxyXG5cclxuICAgIF9jaGFuZ2VFdmVudChldmVudDogYW55KSB7XHJcbiAgICAgICAgY29uc29sZS5sb2coZXZlbnQsIFwiZXZlbnRcIik7XHJcbiAgICAgICAgaWYgKGV2ZW50LnZhbHVlKSB7XHJcbiAgICAgICAgICAgIHRoaXMuc2hvd0NoYXRCb3QgPSBmYWxzZTtcclxuICAgICAgICAgICAgdGhpcy5tZXNzYWdlRGF0YSA9IGV2ZW50LnZhbHVlO1xyXG4gICAgICAgICAgICB0aGlzLnNlbmRNZXNzYWdlKCk7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIG5nT25EZXN0cm95KCk6IHZvaWQge1xyXG5cclxuICAgIH1cclxufSJdfQ==