import { Component, ViewEncapsulation, Input, Output, ContentChild, TemplateRef, ViewChild, ViewContainerRef, EventEmitter } from '@angular/core';
import { KdGridsterSvc } from './kd-gridster-svc';
export class KdGridster {
    constructor(_gridsterSvc) {
        this._gridsterSvc = _gridsterSvc;
        this._gridsterItems = [];
        this.items = [];
        this.getConfig = new EventEmitter();
        this.getGridsterItem = new EventEmitter();
        this.gridsterItemResize = new EventEmitter();
        this.gridsterRemoved = new EventEmitter();
    }
    ngOnInit() {
        // console.log('init');
        this.api.addGridsterItem = (_item, _handleError) => {
            let newItem = this.getValidItem(_item);
            if (newItem) {
                this._gridsterItems.push(newItem);
                this.addGridsterItem(newItem);
            }
            else {
                if (_handleError) {
                    _handleError('KdGridster ERROR: maxCols and maxRows has been reached, item can\'t be placed in the bounds of the dashboard');
                }
                else {
                    console.warn('KdGridster ERROR: maxCols and maxRows has been reached, item can\'t be placed in the bounds of the dashboard');
                }
            }
        };
        this.api.removeGridsterItem = (_id) => this._removeGridsterItem(_id);
        this.api.gridsterResize = () => this.gridsterOptions.api.resize();
        this.api.onGridsterItemReady = this._gridsterSvc.onGridsterItemInit();
        this.api.onGridsterItemResize = this._gridsterSvc.onGridsterItemResize();
        this.api.onGridsterRemoved = this._gridsterSvc.onGridsterRemoved();
        this._gridsterSvc.setEmitter(this.gridsterItemResize, this.getGridsterItem);
    }
    ngOnDestroy() {
        this.gridsterRemoved.emit();
        this._gridsterSvc.gridsterRemoved();
        this.gridsterContainer.clear();
    }
    ngOnChanges(changes) {
        // console.log('kd gridster, changes', changes);
        if (changes.hasOwnProperty('config')) {
            if (!changes.config.isFirstChange()) {
                this._gridsterItems = [];
                this.gridsterContainer.clear();
            }
            // get grister config only
            this.gridsterOptions = this._gridsterSvc.getConfig(changes.config.currentValue);
            this.getConfig.emit(this.gridsterOptions);
            let gridsterItems = this.items.slice();
            // load in the default gridsterItems
            for (let item of gridsterItems) {
                let newItem = this.getValidItem(item);
                if (typeof newItem.enableContentDrag === 'undefined')
                    newItem.enableContentDrag = true;
                this.addGridsterItem(newItem);
                this._gridsterItems.push(newItem);
            }
        }
    }
    /**
     * remove item from ready list, item list and container
     *  _id item.id
     */
    _removeGridsterItem(_id) {
        for (let i = this._gridsterItems.length - 1; i >= 0; i--) {
            if (this._gridsterItems[i].id === _id) {
                this._gridsterItems.splice(i, 1);
                if (!this.config.enableDowngrade)
                    this.gridsterContainer.remove(i);
                break;
            }
        }
    }
    /**
     * check if gridsterItem can be added in the position specified
     * _item IGridsterItem
     */
    getValidItem(_item) {
        let newItem = Object.assign({ x: -1, y: -1, cols: -1, rows: -1 }, _item);
        if (typeof _item.x === 'undefined' || typeof _item.y === 'undefined') {
            Object.assign(newItem, this.gridsterOptions.api.getFirstPossiblePosition(newItem));
        }
        if ((newItem.x + newItem.cols) > this.gridsterOptions.maxCols || (newItem.y + newItem.rows) > this.gridsterOptions.maxRows) {
            return;
        }
        return newItem;
    }
    /**
     * add template of <gridster-item> into <gridster>
     *  _item [description]
     */
    addGridsterItem(_item) {
        if (this.config.enableDowngrade)
            return;
        setTimeout(() => this.gridsterContainer.createEmbeddedView(this.gridsterItemTemplate, { item: _item, gridsterOptions: this.gridsterOptions }));
    }
}
KdGridster.decorators = [
    { type: Component, args: [{
                selector: 'kd-gridster',
                providers: [KdGridsterSvc],
                encapsulation: ViewEncapsulation.None,
                template: "<ng-content *ngIf=\"gridsterOptions.enableDowngrade\">\r\n</ng-content>\r\n<gridster *ngIf=\"!gridsterOptions.enableDowngrade\" class=\"kdx-gridster\" [ngClass]=\"{'bg-dot': gridsterOptions.enableEditMode, 'kdx-center': gridsterOptions.setFixCenter}\" [options]=\"gridsterOptions\">\r\n    <ng-container #gridsterContainer></ng-container>\r\n    <ng-template #gridsterItemTemplate let-gridsterOptions=\"gridsterOptions\" let-item=\"item\">\r\n        <gridster-item [item]=\"item\" class=\"kdx-gridster-item\" [ngClass]=\"{'no-border': !gridsterOptions.border}\">\r\n            <kd-gridster-toolbar [item]=\"item\" [config]=\"gridsterOptions\"></kd-gridster-toolbar>\r\n            <div class=\"kdx-gridster-item-content\" [ngClass]=\"{'no-drag': !item.enableContentDrag}\">\r\n                <ng-container *ngIf=\"!gridsterOptions.enableDowngrade\">\r\n                    <ng-container *ngTemplateOutlet=\"gridsterContentTemplate; context: { $implicit: item }\">\r\n                        <ng-content select=\".gridster-content\"></ng-content>\r\n                    </ng-container>\r\n                </ng-container>\r\n            </div>\r\n        </gridster-item>\r\n    </ng-template>\r\n</gridster>\r\n"
            },] }
];
KdGridster.ctorParameters = () => [
    { type: KdGridsterSvc }
];
KdGridster.propDecorators = {
    config: [{ type: Input }],
    items: [{ type: Input }],
    api: [{ type: Input }],
    getConfig: [{ type: Output }],
    getGridsterItem: [{ type: Output }],
    gridsterItemResize: [{ type: Output }],
    gridsterRemoved: [{ type: Output }],
    gridsterContentTemplate: [{ type: ContentChild, args: [TemplateRef,] }],
    gridsterContainer: [{ type: ViewChild, args: ['gridsterContainer', { read: ViewContainerRef },] }],
    gridsterItemTemplate: [{ type: ViewChild, args: ['gridsterItemTemplate',] }]
};
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoia2QtZ3JpZHN0ZXIuanMiLCJzb3VyY2VSb290IjoiQzovUHJvamVjdHMvQW5ndWxhci9pb3N0Zy1vcGVuZW1pcy1zdHlsZWd1aWRlL3Byb2plY3RzL29wZW5lbWlzLXN0eWxlZ3VpZGUtbGliL3NyYy8iLCJzb3VyY2VzIjpbImtkLWNvbXBvbmVudHMva2QtYW5ndWxhci1ncmlkc3Rlci9rZC1ncmlkc3Rlci50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQSxPQUFPLEVBQ0gsU0FBUyxFQUNULGlCQUFpQixFQUtqQixLQUFLLEVBQ0wsTUFBTSxFQUNOLFlBQVksRUFDWixXQUFXLEVBQ1gsU0FBUyxFQUNULGdCQUFnQixFQUNoQixZQUFZLEVBQ2YsTUFBTSxlQUFlLENBQUM7QUFFdkIsT0FBTyxFQUFFLGFBQWEsRUFBRSxNQUFNLG1CQUFtQixDQUFDO0FBY2xELE1BQU0sT0FBTyxVQUFVO0lBbUJuQixZQUNZLFlBQTJCO1FBQTNCLGlCQUFZLEdBQVosWUFBWSxDQUFlO1FBakIvQixtQkFBYyxHQUF3QixFQUFFLENBQUM7UUFHeEMsVUFBSyxHQUF5QixFQUFFLENBQUM7UUFHaEMsY0FBUyxHQUFrQyxJQUFJLFlBQVksRUFBRSxDQUFDO1FBQzlELG9CQUFlLEdBQStCLElBQUksWUFBWSxFQUFFLENBQUM7UUFDakUsdUJBQWtCLEdBQStCLElBQUksWUFBWSxFQUFnQixDQUFDO1FBQ2xGLG9CQUFlLEdBQXNCLElBQUksWUFBWSxFQUFPLENBQUM7SUFTbkUsQ0FBQztJQUVMLFFBQVE7UUFDSix1QkFBdUI7UUFDdkIsSUFBSSxDQUFDLEdBQUcsQ0FBQyxlQUFlLEdBQUcsQ0FBQyxLQUFvQixFQUFFLFlBQXNDLEVBQUUsRUFBRTtZQUN4RixJQUFJLE9BQU8sR0FBaUIsSUFBSSxDQUFDLFlBQVksQ0FBQyxLQUFLLENBQUMsQ0FBQztZQUNyRCxJQUFJLE9BQU8sRUFBRTtnQkFDVCxJQUFJLENBQUMsY0FBYyxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsQ0FBQztnQkFDbEMsSUFBSSxDQUFDLGVBQWUsQ0FBQyxPQUFPLENBQUMsQ0FBQzthQUNqQztpQkFBTTtnQkFDSCxJQUFJLFlBQVksRUFBRTtvQkFDZCxZQUFZLENBQUMsOEdBQThHLENBQUMsQ0FBQztpQkFDaEk7cUJBQU07b0JBQ0gsT0FBTyxDQUFDLElBQUksQ0FBQyw4R0FBOEcsQ0FBQyxDQUFDO2lCQUNoSTthQUNKO1FBQ0wsQ0FBQyxDQUFDO1FBRUYsSUFBSSxDQUFDLEdBQUcsQ0FBQyxrQkFBa0IsR0FBRyxDQUFDLEdBQVcsRUFBRSxFQUFFLENBQUMsSUFBSSxDQUFDLG1CQUFtQixDQUFDLEdBQUcsQ0FBQyxDQUFDO1FBQzdFLElBQUksQ0FBQyxHQUFHLENBQUMsY0FBYyxHQUFHLEdBQUcsRUFBRSxDQUFDLElBQUksQ0FBQyxlQUFlLENBQUMsR0FBRyxDQUFDLE1BQU0sRUFBRSxDQUFDO1FBQ2xFLElBQUksQ0FBQyxHQUFHLENBQUMsbUJBQW1CLEdBQUcsSUFBSSxDQUFDLFlBQVksQ0FBQyxrQkFBa0IsRUFBRSxDQUFDO1FBQ3RFLElBQUksQ0FBQyxHQUFHLENBQUMsb0JBQW9CLEdBQUcsSUFBSSxDQUFDLFlBQVksQ0FBQyxvQkFBb0IsRUFBRSxDQUFDO1FBQ3pFLElBQUksQ0FBQyxHQUFHLENBQUMsaUJBQWlCLEdBQUcsSUFBSSxDQUFDLFlBQVksQ0FBQyxpQkFBaUIsRUFBRSxDQUFDO1FBRW5FLElBQUksQ0FBQyxZQUFZLENBQUMsVUFBVSxDQUFDLElBQUksQ0FBQyxrQkFBa0IsRUFBRSxJQUFJLENBQUMsZUFBZSxDQUFDLENBQUM7SUFDaEYsQ0FBQztJQUVELFdBQVc7UUFDUCxJQUFJLENBQUMsZUFBZSxDQUFDLElBQUksRUFBRSxDQUFDO1FBQzVCLElBQUksQ0FBQyxZQUFZLENBQUMsZUFBZSxFQUFFLENBQUM7UUFDcEMsSUFBSSxDQUFDLGlCQUFpQixDQUFDLEtBQUssRUFBRSxDQUFDO0lBQ25DLENBQUM7SUFFRCxXQUFXLENBQUMsT0FBc0I7UUFDOUIsZ0RBQWdEO1FBRWhELElBQUksT0FBTyxDQUFDLGNBQWMsQ0FBQyxRQUFRLENBQUMsRUFBRTtZQUVsQyxJQUFJLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxhQUFhLEVBQUUsRUFBRTtnQkFDakMsSUFBSSxDQUFDLGNBQWMsR0FBRyxFQUFFLENBQUM7Z0JBQ3pCLElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxLQUFLLEVBQUUsQ0FBQzthQUNsQztZQUVELDBCQUEwQjtZQUMxQixJQUFJLENBQUMsZUFBZSxHQUFHLElBQUksQ0FBQyxZQUFZLENBQUMsU0FBUyxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsWUFBWSxDQUFDLENBQUM7WUFDaEYsSUFBSSxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLGVBQWUsQ0FBQyxDQUFDO1lBRTFDLElBQUksYUFBYSxHQUFJLElBQUksQ0FBQyxLQUFLLENBQUMsS0FBSyxFQUFFLENBQUM7WUFFeEMsb0NBQW9DO1lBQ3BDLEtBQUssSUFBSSxJQUFJLElBQUksYUFBYSxFQUFFO2dCQUM1QixJQUFJLE9BQU8sR0FBaUIsSUFBSSxDQUFDLFlBQVksQ0FBQyxJQUFJLENBQUMsQ0FBQztnQkFDcEQsSUFBSSxPQUFPLE9BQU8sQ0FBQyxpQkFBaUIsS0FBSyxXQUFXO29CQUFFLE9BQU8sQ0FBQyxpQkFBaUIsR0FBRyxJQUFJLENBQUM7Z0JBQ3ZGLElBQUksQ0FBQyxlQUFlLENBQUMsT0FBTyxDQUFDLENBQUM7Z0JBQzlCLElBQUksQ0FBQyxjQUFjLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxDQUFDO2FBQ3JDO1NBQ0o7SUFDTCxDQUFDO0lBRUQ7OztPQUdHO0lBQ0ssbUJBQW1CLENBQUMsR0FBVztRQUNuQyxLQUFLLElBQUksQ0FBQyxHQUFHLElBQUksQ0FBQyxjQUFjLENBQUMsTUFBTSxHQUFHLENBQUMsRUFBRSxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFO1lBQ3RELElBQUksSUFBSSxDQUFDLGNBQWMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLEtBQUssR0FBRyxFQUFFO2dCQUNuQyxJQUFJLENBQUMsY0FBYyxDQUFDLE1BQU0sQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUM7Z0JBQ2pDLElBQUksQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLGVBQWU7b0JBQUUsSUFBSSxDQUFDLGlCQUFpQixDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQztnQkFDbkUsTUFBTTthQUNUO1NBQ0o7SUFDTCxDQUFDO0lBRUQ7OztPQUdHO0lBQ0ssWUFBWSxDQUFDLEtBQW9CO1FBQ3JDLElBQUksT0FBTyxHQUFpQixNQUFNLENBQUMsTUFBTSxDQUFDLEVBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxDQUFDLENBQUMsRUFBRSxJQUFJLEVBQUUsQ0FBQyxDQUFDLEVBQUUsSUFBSSxFQUFFLENBQUMsQ0FBQyxFQUFDLEVBQUUsS0FBSyxDQUFDLENBQUM7UUFDckYsSUFBSSxPQUFPLEtBQUssQ0FBQyxDQUFDLEtBQUssV0FBVyxJQUFJLE9BQU8sS0FBSyxDQUFDLENBQUMsS0FBSyxXQUFXLEVBQUU7WUFDNUQsTUFBTyxDQUFDLE1BQU0sQ0FBQyxPQUFPLEVBQUUsSUFBSSxDQUFDLGVBQWUsQ0FBQyxHQUFHLENBQUMsd0JBQXdCLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQztTQUM3RjtRQUVELElBQUksQ0FBQyxPQUFPLENBQUMsQ0FBQyxHQUFHLE9BQU8sQ0FBQyxJQUFJLENBQUMsR0FBRyxJQUFJLENBQUMsZUFBZSxDQUFDLE9BQU8sSUFBSSxDQUFDLE9BQU8sQ0FBQyxDQUFDLEdBQUcsT0FBTyxDQUFDLElBQUksQ0FBQyxHQUFHLElBQUksQ0FBQyxlQUFlLENBQUMsT0FBTyxFQUFFO1lBQ3hILE9BQU87U0FDVjtRQUNELE9BQU8sT0FBTyxDQUFDO0lBQ25CLENBQUM7SUFFRDs7O09BR0c7SUFDSyxlQUFlLENBQUMsS0FBbUI7UUFDdkMsSUFBSSxJQUFJLENBQUMsTUFBTSxDQUFDLGVBQWU7WUFBRSxPQUFPO1FBQ3hDLFVBQVUsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxJQUFJLENBQUMsaUJBQWlCLENBQUMsa0JBQWtCLENBQUMsSUFBSSxDQUFDLG9CQUFvQixFQUFFLEVBQUUsSUFBSSxFQUFFLEtBQUssRUFBRSxlQUFlLEVBQUUsSUFBSSxDQUFDLGVBQWUsRUFBRSxDQUFDLENBQUMsQ0FBQztJQUNuSixDQUFDOzs7WUE1SEosU0FBUyxTQUFDO2dCQUNQLFFBQVEsRUFBRSxhQUFhO2dCQUN2QixTQUFTLEVBQUUsQ0FBQyxhQUFhLENBQUM7Z0JBQzFCLGFBQWEsRUFBRSxpQkFBaUIsQ0FBQyxJQUFJO2dCQUNyQyx5c0NBQWlDO2FBQ3BDOzs7WUFaUSxhQUFhOzs7cUJBbUJqQixLQUFLO29CQUNMLEtBQUs7a0JBQ0wsS0FBSzt3QkFFTCxNQUFNOzhCQUNOLE1BQU07aUNBQ04sTUFBTTs4QkFDTixNQUFNO3NDQUVOLFlBQVksU0FBQyxXQUFXO2dDQUV4QixTQUFTLFNBQUMsbUJBQW1CLEVBQUUsRUFBRSxJQUFJLEVBQUUsZ0JBQWdCLEVBQUU7bUNBQ3pELFNBQVMsU0FBQyxzQkFBc0IiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQge1xyXG4gICAgQ29tcG9uZW50LFxyXG4gICAgVmlld0VuY2Fwc3VsYXRpb24sXHJcbiAgICBPbkluaXQsXHJcbiAgICBPbkRlc3Ryb3ksXHJcbiAgICBPbkNoYW5nZXMsXHJcbiAgICBTaW1wbGVDaGFuZ2VzLFxyXG4gICAgSW5wdXQsXHJcbiAgICBPdXRwdXQsXHJcbiAgICBDb250ZW50Q2hpbGQsXHJcbiAgICBUZW1wbGF0ZVJlZixcclxuICAgIFZpZXdDaGlsZCxcclxuICAgIFZpZXdDb250YWluZXJSZWYsXHJcbiAgICBFdmVudEVtaXR0ZXJcclxufSBmcm9tICdAYW5ndWxhci9jb3JlJztcclxuaW1wb3J0IHsgR3JpZHN0ZXJDb25maWcsIEdyaWRzdGVySXRlbSB9IGZyb20gJ2FuZ3VsYXItZ3JpZHN0ZXIyJztcclxuaW1wb3J0IHsgS2RHcmlkc3RlclN2YyB9IGZyb20gJy4va2QtZ3JpZHN0ZXItc3ZjJztcclxuaW1wb3J0IHtcclxuICAgIElHcmlkc3RlckNvbmZpZyxcclxuICAgIElHcmlkc3Rlckl0ZW0sXHJcbiAgICBJR3JpZHN0ZXJBcGlcclxufSBmcm9tICcuL2tkLWdyaWRzdGVyLWludGVyZmFjZSc7XHJcblxyXG5AQ29tcG9uZW50KHtcclxuICAgIHNlbGVjdG9yOiAna2QtZ3JpZHN0ZXInLFxyXG4gICAgcHJvdmlkZXJzOiBbS2RHcmlkc3RlclN2Y10sXHJcbiAgICBlbmNhcHN1bGF0aW9uOiBWaWV3RW5jYXBzdWxhdGlvbi5Ob25lLFxyXG4gICAgdGVtcGxhdGVVcmw6ICcuL2tkLWdyaWRzdGVyLmh0bWwnXHJcbn0pXHJcblxyXG5leHBvcnQgY2xhc3MgS2RHcmlkc3RlciBpbXBsZW1lbnRzIE9uSW5pdCwgT25EZXN0cm95LCBPbkNoYW5nZXMge1xyXG5cclxuICAgIHB1YmxpYyBncmlkc3Rlck9wdGlvbnM6IEdyaWRzdGVyQ29uZmlnO1xyXG4gICAgcHJpdmF0ZSBfZ3JpZHN0ZXJJdGVtczogQXJyYXk8R3JpZHN0ZXJJdGVtPiA9IFtdO1xyXG5cclxuICAgIEBJbnB1dCgpIGNvbmZpZzogSUdyaWRzdGVyQ29uZmlnO1xyXG4gICAgQElucHV0KCkgaXRlbXM6IEFycmF5PElHcmlkc3Rlckl0ZW0+ID0gW107XHJcbiAgICBASW5wdXQoKSBhcGk6IElHcmlkc3RlckFwaTtcclxuXHJcbiAgICBAT3V0cHV0KCkgZ2V0Q29uZmlnOiBFdmVudEVtaXR0ZXI8SUdyaWRzdGVyQ29uZmlnPiA9IG5ldyBFdmVudEVtaXR0ZXIoKTtcclxuICAgIEBPdXRwdXQoKSBnZXRHcmlkc3Rlckl0ZW06IEV2ZW50RW1pdHRlcjxHcmlkc3Rlckl0ZW0+ID0gbmV3IEV2ZW50RW1pdHRlcigpO1xyXG4gICAgQE91dHB1dCgpIGdyaWRzdGVySXRlbVJlc2l6ZTogRXZlbnRFbWl0dGVyPEdyaWRzdGVySXRlbT4gPSBuZXcgRXZlbnRFbWl0dGVyPEdyaWRzdGVySXRlbT4oKTtcclxuICAgIEBPdXRwdXQoKSBncmlkc3RlclJlbW92ZWQ6IEV2ZW50RW1pdHRlcjxhbnk+ID0gbmV3IEV2ZW50RW1pdHRlcjxhbnk+KCk7XHJcblxyXG4gICAgQENvbnRlbnRDaGlsZChUZW1wbGF0ZVJlZikgZ3JpZHN0ZXJDb250ZW50VGVtcGxhdGU6IFRlbXBsYXRlUmVmPGFueT47XHJcblxyXG4gICAgQFZpZXdDaGlsZCgnZ3JpZHN0ZXJDb250YWluZXInLCB7IHJlYWQ6IFZpZXdDb250YWluZXJSZWYgfSkgZ3JpZHN0ZXJDb250YWluZXI6IFZpZXdDb250YWluZXJSZWY7XHJcbiAgICBAVmlld0NoaWxkKCdncmlkc3Rlckl0ZW1UZW1wbGF0ZScpIGdyaWRzdGVySXRlbVRlbXBsYXRlOiBUZW1wbGF0ZVJlZjxhbnk+O1xyXG5cclxuICAgIGNvbnN0cnVjdG9yKFxyXG4gICAgICAgIHByaXZhdGUgX2dyaWRzdGVyU3ZjOiBLZEdyaWRzdGVyU3ZjXHJcbiAgICApIHsgfVxyXG5cclxuICAgIG5nT25Jbml0KCk6IHZvaWQge1xyXG4gICAgICAgIC8vIGNvbnNvbGUubG9nKCdpbml0Jyk7XHJcbiAgICAgICAgdGhpcy5hcGkuYWRkR3JpZHN0ZXJJdGVtID0gKF9pdGVtOiBJR3JpZHN0ZXJJdGVtLCBfaGFuZGxlRXJyb3I/OiAoZXJyb3I6IHN0cmluZykgPT4gdm9pZCkgPT4ge1xyXG4gICAgICAgICAgICBsZXQgbmV3SXRlbTogR3JpZHN0ZXJJdGVtID0gdGhpcy5nZXRWYWxpZEl0ZW0oX2l0ZW0pO1xyXG4gICAgICAgICAgICBpZiAobmV3SXRlbSkge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5fZ3JpZHN0ZXJJdGVtcy5wdXNoKG5ld0l0ZW0pO1xyXG4gICAgICAgICAgICAgICAgdGhpcy5hZGRHcmlkc3Rlckl0ZW0obmV3SXRlbSk7XHJcbiAgICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgICAgICBpZiAoX2hhbmRsZUVycm9yKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgX2hhbmRsZUVycm9yKCdLZEdyaWRzdGVyIEVSUk9SOiBtYXhDb2xzIGFuZCBtYXhSb3dzIGhhcyBiZWVuIHJlYWNoZWQsIGl0ZW0gY2FuXFwndCBiZSBwbGFjZWQgaW4gdGhlIGJvdW5kcyBvZiB0aGUgZGFzaGJvYXJkJyk7XHJcbiAgICAgICAgICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgICAgIGNvbnNvbGUud2FybignS2RHcmlkc3RlciBFUlJPUjogbWF4Q29scyBhbmQgbWF4Um93cyBoYXMgYmVlbiByZWFjaGVkLCBpdGVtIGNhblxcJ3QgYmUgcGxhY2VkIGluIHRoZSBib3VuZHMgb2YgdGhlIGRhc2hib2FyZCcpO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfTtcclxuXHJcbiAgICAgICAgdGhpcy5hcGkucmVtb3ZlR3JpZHN0ZXJJdGVtID0gKF9pZDogc3RyaW5nKSA9PiB0aGlzLl9yZW1vdmVHcmlkc3Rlckl0ZW0oX2lkKTtcclxuICAgICAgICB0aGlzLmFwaS5ncmlkc3RlclJlc2l6ZSA9ICgpID0+IHRoaXMuZ3JpZHN0ZXJPcHRpb25zLmFwaS5yZXNpemUoKTtcclxuICAgICAgICB0aGlzLmFwaS5vbkdyaWRzdGVySXRlbVJlYWR5ID0gdGhpcy5fZ3JpZHN0ZXJTdmMub25Hcmlkc3Rlckl0ZW1Jbml0KCk7XHJcbiAgICAgICAgdGhpcy5hcGkub25Hcmlkc3Rlckl0ZW1SZXNpemUgPSB0aGlzLl9ncmlkc3RlclN2Yy5vbkdyaWRzdGVySXRlbVJlc2l6ZSgpO1xyXG4gICAgICAgIHRoaXMuYXBpLm9uR3JpZHN0ZXJSZW1vdmVkID0gdGhpcy5fZ3JpZHN0ZXJTdmMub25Hcmlkc3RlclJlbW92ZWQoKTtcclxuXHJcbiAgICAgICAgdGhpcy5fZ3JpZHN0ZXJTdmMuc2V0RW1pdHRlcih0aGlzLmdyaWRzdGVySXRlbVJlc2l6ZSwgdGhpcy5nZXRHcmlkc3Rlckl0ZW0pO1xyXG4gICAgfVxyXG5cclxuICAgIG5nT25EZXN0cm95KCk6IHZvaWQge1xyXG4gICAgICAgIHRoaXMuZ3JpZHN0ZXJSZW1vdmVkLmVtaXQoKTtcclxuICAgICAgICB0aGlzLl9ncmlkc3RlclN2Yy5ncmlkc3RlclJlbW92ZWQoKTtcclxuICAgICAgICB0aGlzLmdyaWRzdGVyQ29udGFpbmVyLmNsZWFyKCk7XHJcbiAgICB9XHJcblxyXG4gICAgbmdPbkNoYW5nZXMoY2hhbmdlczogU2ltcGxlQ2hhbmdlcyk6IHZvaWQge1xyXG4gICAgICAgIC8vIGNvbnNvbGUubG9nKCdrZCBncmlkc3RlciwgY2hhbmdlcycsIGNoYW5nZXMpO1xyXG5cclxuICAgICAgICBpZiAoY2hhbmdlcy5oYXNPd25Qcm9wZXJ0eSgnY29uZmlnJykpIHtcclxuXHJcbiAgICAgICAgICAgIGlmICghY2hhbmdlcy5jb25maWcuaXNGaXJzdENoYW5nZSgpKSB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLl9ncmlkc3Rlckl0ZW1zID0gW107XHJcbiAgICAgICAgICAgICAgICB0aGlzLmdyaWRzdGVyQ29udGFpbmVyLmNsZWFyKCk7XHJcbiAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgIC8vIGdldCBncmlzdGVyIGNvbmZpZyBvbmx5XHJcbiAgICAgICAgICAgIHRoaXMuZ3JpZHN0ZXJPcHRpb25zID0gdGhpcy5fZ3JpZHN0ZXJTdmMuZ2V0Q29uZmlnKGNoYW5nZXMuY29uZmlnLmN1cnJlbnRWYWx1ZSk7XHJcbiAgICAgICAgICAgIHRoaXMuZ2V0Q29uZmlnLmVtaXQodGhpcy5ncmlkc3Rlck9wdGlvbnMpO1xyXG5cclxuICAgICAgICAgICAgbGV0IGdyaWRzdGVySXRlbXMgPSAgdGhpcy5pdGVtcy5zbGljZSgpO1xyXG5cclxuICAgICAgICAgICAgLy8gbG9hZCBpbiB0aGUgZGVmYXVsdCBncmlkc3Rlckl0ZW1zXHJcbiAgICAgICAgICAgIGZvciAobGV0IGl0ZW0gb2YgZ3JpZHN0ZXJJdGVtcykge1xyXG4gICAgICAgICAgICAgICAgbGV0IG5ld0l0ZW06IEdyaWRzdGVySXRlbSA9IHRoaXMuZ2V0VmFsaWRJdGVtKGl0ZW0pO1xyXG4gICAgICAgICAgICAgICAgaWYgKHR5cGVvZiBuZXdJdGVtLmVuYWJsZUNvbnRlbnREcmFnID09PSAndW5kZWZpbmVkJykgbmV3SXRlbS5lbmFibGVDb250ZW50RHJhZyA9IHRydWU7XHJcbiAgICAgICAgICAgICAgICB0aGlzLmFkZEdyaWRzdGVySXRlbShuZXdJdGVtKTtcclxuICAgICAgICAgICAgICAgIHRoaXMuX2dyaWRzdGVySXRlbXMucHVzaChuZXdJdGVtKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICAvKipcclxuICAgICAqIHJlbW92ZSBpdGVtIGZyb20gcmVhZHkgbGlzdCwgaXRlbSBsaXN0IGFuZCBjb250YWluZXJcclxuICAgICAqICBfaWQgaXRlbS5pZFxyXG4gICAgICovXHJcbiAgICBwcml2YXRlIF9yZW1vdmVHcmlkc3Rlckl0ZW0oX2lkOiBzdHJpbmcpOiB2b2lkIHtcclxuICAgICAgICBmb3IgKGxldCBpID0gdGhpcy5fZ3JpZHN0ZXJJdGVtcy5sZW5ndGggLSAxOyBpID49IDA7IGktLSkge1xyXG4gICAgICAgICAgICBpZiAodGhpcy5fZ3JpZHN0ZXJJdGVtc1tpXS5pZCA9PT0gX2lkKSB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLl9ncmlkc3Rlckl0ZW1zLnNwbGljZShpLCAxKTtcclxuICAgICAgICAgICAgICAgIGlmICghdGhpcy5jb25maWcuZW5hYmxlRG93bmdyYWRlKSB0aGlzLmdyaWRzdGVyQ29udGFpbmVyLnJlbW92ZShpKTtcclxuICAgICAgICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIC8qKlxyXG4gICAgICogY2hlY2sgaWYgZ3JpZHN0ZXJJdGVtIGNhbiBiZSBhZGRlZCBpbiB0aGUgcG9zaXRpb24gc3BlY2lmaWVkXHJcbiAgICAgKiBfaXRlbSBJR3JpZHN0ZXJJdGVtXHJcbiAgICAgKi9cclxuICAgIHByaXZhdGUgZ2V0VmFsaWRJdGVtKF9pdGVtOiBJR3JpZHN0ZXJJdGVtKTogR3JpZHN0ZXJJdGVtIHtcclxuICAgICAgICBsZXQgbmV3SXRlbTogR3JpZHN0ZXJJdGVtID0gT2JqZWN0LmFzc2lnbih7eDogLTEsIHk6IC0xLCBjb2xzOiAtMSwgcm93czogLTF9LCBfaXRlbSk7XHJcbiAgICAgICAgaWYgKHR5cGVvZiBfaXRlbS54ID09PSAndW5kZWZpbmVkJyB8fCB0eXBlb2YgX2l0ZW0ueSA9PT0gJ3VuZGVmaW5lZCcpIHtcclxuICAgICAgICAgICAgKDxhbnk+T2JqZWN0KS5hc3NpZ24obmV3SXRlbSwgdGhpcy5ncmlkc3Rlck9wdGlvbnMuYXBpLmdldEZpcnN0UG9zc2libGVQb3NpdGlvbihuZXdJdGVtKSk7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICBpZiAoKG5ld0l0ZW0ueCArIG5ld0l0ZW0uY29scykgPiB0aGlzLmdyaWRzdGVyT3B0aW9ucy5tYXhDb2xzIHx8IChuZXdJdGVtLnkgKyBuZXdJdGVtLnJvd3MpID4gdGhpcy5ncmlkc3Rlck9wdGlvbnMubWF4Um93cykge1xyXG4gICAgICAgICAgICByZXR1cm47XHJcbiAgICAgICAgfVxyXG4gICAgICAgIHJldHVybiBuZXdJdGVtO1xyXG4gICAgfVxyXG5cclxuICAgIC8qKlxyXG4gICAgICogYWRkIHRlbXBsYXRlIG9mIDxncmlkc3Rlci1pdGVtPiBpbnRvIDxncmlkc3Rlcj5cclxuICAgICAqICBfaXRlbSBbZGVzY3JpcHRpb25dXHJcbiAgICAgKi9cclxuICAgIHByaXZhdGUgYWRkR3JpZHN0ZXJJdGVtKF9pdGVtOiBHcmlkc3Rlckl0ZW0pOiB2b2lkIHtcclxuICAgICAgICBpZiAodGhpcy5jb25maWcuZW5hYmxlRG93bmdyYWRlKSByZXR1cm47XHJcbiAgICAgICAgc2V0VGltZW91dCgoKSA9PiB0aGlzLmdyaWRzdGVyQ29udGFpbmVyLmNyZWF0ZUVtYmVkZGVkVmlldyh0aGlzLmdyaWRzdGVySXRlbVRlbXBsYXRlLCB7IGl0ZW06IF9pdGVtLCBncmlkc3Rlck9wdGlvbnM6IHRoaXMuZ3JpZHN0ZXJPcHRpb25zIH0pKTtcclxuICAgIH1cclxufVxyXG4iXX0=