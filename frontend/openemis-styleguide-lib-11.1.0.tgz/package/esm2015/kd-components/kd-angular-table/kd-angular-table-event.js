import { Injectable } from '@angular/core';
import { KdBroadcaster } from '../kd-common/index';
import * as i0 from "@angular/core";
import * as i1 from "../kd-common/kd-broadcaster-svc";
export class KdTableEvent {
    constructor(_broadcaster) {
        this._broadcaster = _broadcaster;
    }
    /// For any component using KdTable to capture all the informations KdTable emits
    onKdTableEventList(_gridId) {
        return this._broadcaster.on(_gridId + 'KdTableEvent');
    }
}
KdTableEvent.ɵprov = i0.ɵɵdefineInjectable({ factory: function KdTableEvent_Factory() { return new KdTableEvent(i0.ɵɵinject(i1.KdBroadcaster)); }, token: KdTableEvent, providedIn: "root" });
KdTableEvent.decorators = [
    { type: Injectable, args: [{
                providedIn: 'root'
            },] }
];
KdTableEvent.ctorParameters = () => [
    { type: KdBroadcaster }
];
export class KdIntTableEvent {
    constructor(_broadcaster) {
        this._broadcaster = _broadcaster;
    }
    /// Broadcast any events for components using KdTable
    kdTableEventList(_gridId, _event) {
        this._broadcaster.broadcast(_gridId + 'KdTableEvent', _event);
    }
    /// Used on kd-table-action.ts - For delete node params to update the row data accordingly
    updateEmitRowNodes(_gridId, _action, _rowData) {
        let data = {
            action: _action,
            rowData: _rowData
        };
        this._broadcaster.broadcast(_gridId + 'KdTableRowUpdated', data);
    }
    /// Used on kd-angular-table.ts - For update the delete node params in kd-table-action.ts
    onUpdateEmitRowNodes(_gridId) {
        return this._broadcaster.on(_gridId + 'KdTableRowUpdated');
    }
    /// Used on kd-table-checkbox-radio.ts - Checkbox / radio emit change event
    selectionChanged(_gridId, _data) {
        this._broadcaster.broadcast(_gridId + 'KdTableUpdateNodes', _data);
    }
    /// Used on kd-table-checkbox-radio.ts - To recheck the select all checkbox
    onSelectionChanged(_gridId) {
        return this._broadcaster.on(_gridId + 'KdTableUpdateNodes');
    }
    /// Used on kd-angular-table.ts - Emit on row data / model changed
    modelChanged(_gridId, _data) {
        this._broadcaster.broadcast(_gridId + 'KdModelUpdated', _data);
    }
    /// Used on kd-table-checkbox-radio.ts - To recheck the select all checkbox
    onModelChanged(_gridId) {
        return this._broadcaster.on(_gridId + 'KdModelUpdated');
    }
    /// Used on kd-table-input.ts - For emitting any form changes to output to dynamicForm
    inputChanged(_gridId, _data) {
        this._broadcaster.broadcast(_gridId + 'KdTableInputChanged', _data);
    }
    /// Used on kd-angular-table.ts - Capture the change params and emit to anyone using the output
    onInputChanged(_gridId) {
        return this._broadcaster.on(_gridId + 'KdTableInputChanged');
    }
}
KdIntTableEvent.decorators = [
    { type: Injectable }
];
KdIntTableEvent.ctorParameters = () => [
    { type: KdBroadcaster }
];
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoia2QtYW5ndWxhci10YWJsZS1ldmVudC5qcyIsInNvdXJjZVJvb3QiOiJDOi9Qcm9qZWN0cy9Bbmd1bGFyL2lvc3RnLW9wZW5lbWlzLXN0eWxlZ3VpZGUvcHJvamVjdHMvb3BlbmVtaXMtc3R5bGVndWlkZS1saWIvc3JjLyIsInNvdXJjZXMiOlsia2QtY29tcG9uZW50cy9rZC1hbmd1bGFyLXRhYmxlL2tkLWFuZ3VsYXItdGFibGUtZXZlbnQudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsT0FBTyxFQUFFLFVBQVUsRUFBRSxNQUFNLGVBQWUsQ0FBQztBQUUzQyxPQUFPLEVBQUUsYUFBYSxFQUFFLE1BQU0sb0JBQW9CLENBQUM7OztBQU1uRCxNQUFNLE9BQU8sWUFBWTtJQUNyQixZQUNZLFlBQTJCO1FBQTNCLGlCQUFZLEdBQVosWUFBWSxDQUFlO0lBQ25DLENBQUM7SUFFTCxpRkFBaUY7SUFDMUUsa0JBQWtCLENBQUMsT0FBZTtRQUNyQyxPQUFPLElBQUksQ0FBQyxZQUFZLENBQUMsRUFBRSxDQUFNLE9BQU8sR0FBRyxjQUFjLENBQUMsQ0FBQztJQUMvRCxDQUFDOzs7O1lBWEosVUFBVSxTQUFDO2dCQUNSLFVBQVUsRUFBRSxNQUFNO2FBQ3JCOzs7WUFMUSxhQUFhOztBQWtCdEIsTUFBTSxPQUFPLGVBQWU7SUFDeEIsWUFDWSxZQUEyQjtRQUEzQixpQkFBWSxHQUFaLFlBQVksQ0FBZTtJQUNuQyxDQUFDO0lBRUwscURBQXFEO0lBQzlDLGdCQUFnQixDQUFDLE9BQWUsRUFBRSxNQUFZO1FBQ2pELElBQUksQ0FBQyxZQUFZLENBQUMsU0FBUyxDQUFDLE9BQU8sR0FBRyxjQUFjLEVBQUUsTUFBTSxDQUFDLENBQUM7SUFDbEUsQ0FBQztJQUVELDBGQUEwRjtJQUNuRixrQkFBa0IsQ0FBQyxPQUFlLEVBQUUsT0FBZSxFQUFFLFFBQWE7UUFDckUsSUFBSSxJQUFJLEdBQXFDO1lBQ3pDLE1BQU0sRUFBRSxPQUFPO1lBQ2YsT0FBTyxFQUFFLFFBQVE7U0FDcEIsQ0FBQztRQUNGLElBQUksQ0FBQyxZQUFZLENBQUMsU0FBUyxDQUFDLE9BQU8sR0FBRyxtQkFBbUIsRUFBRSxJQUFJLENBQUMsQ0FBQztJQUNyRSxDQUFDO0lBRUQseUZBQXlGO0lBQ2xGLG9CQUFvQixDQUFDLE9BQWU7UUFDdkMsT0FBTyxJQUFJLENBQUMsWUFBWSxDQUFDLEVBQUUsQ0FBTSxPQUFPLEdBQUcsbUJBQW1CLENBQUMsQ0FBQztJQUNwRSxDQUFDO0lBRUQsMkVBQTJFO0lBQ3BFLGdCQUFnQixDQUFDLE9BQWUsRUFBRSxLQUFXO1FBQ2hELElBQUksQ0FBQyxZQUFZLENBQUMsU0FBUyxDQUFDLE9BQU8sR0FBRyxvQkFBb0IsRUFBRSxLQUFLLENBQUMsQ0FBQztJQUN2RSxDQUFDO0lBRUQsMkVBQTJFO0lBQ3BFLGtCQUFrQixDQUFDLE9BQWU7UUFDckMsT0FBTyxJQUFJLENBQUMsWUFBWSxDQUFDLEVBQUUsQ0FBTSxPQUFPLEdBQUcsb0JBQW9CLENBQUMsQ0FBQztJQUNyRSxDQUFDO0lBRUQsa0VBQWtFO0lBQzNELFlBQVksQ0FBQyxPQUFlLEVBQUUsS0FBVztRQUM1QyxJQUFJLENBQUMsWUFBWSxDQUFDLFNBQVMsQ0FBQyxPQUFPLEdBQUcsZ0JBQWdCLEVBQUUsS0FBSyxDQUFDLENBQUM7SUFDbkUsQ0FBQztJQUVELDJFQUEyRTtJQUNwRSxjQUFjLENBQUMsT0FBZTtRQUNqQyxPQUFPLElBQUksQ0FBQyxZQUFZLENBQUMsRUFBRSxDQUFNLE9BQU8sR0FBRyxnQkFBZ0IsQ0FBQyxDQUFDO0lBQ2pFLENBQUM7SUFFRCxzRkFBc0Y7SUFDL0UsWUFBWSxDQUFDLE9BQWUsRUFBRSxLQUF3QjtRQUN6RCxJQUFJLENBQUMsWUFBWSxDQUFDLFNBQVMsQ0FBQyxPQUFPLEdBQUcscUJBQXFCLEVBQUUsS0FBSyxDQUFDLENBQUM7SUFDeEUsQ0FBQztJQUVELCtGQUErRjtJQUN4RixjQUFjLENBQUMsT0FBZTtRQUNqQyxPQUFPLElBQUksQ0FBQyxZQUFZLENBQUMsRUFBRSxDQUFtQixPQUFPLEdBQUcscUJBQXFCLENBQUMsQ0FBQztJQUNuRixDQUFDOzs7WUFyREosVUFBVTs7O1lBakJGLGFBQWEiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBJbmplY3RhYmxlIH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XHJcbmltcG9ydCB7IE9ic2VydmFibGUgfSBmcm9tICdyeGpzJztcclxuaW1wb3J0IHsgS2RCcm9hZGNhc3RlciB9IGZyb20gJy4uL2tkLWNvbW1vbi9pbmRleCc7XHJcbmltcG9ydCB7IElUYWJsZUZvcm1QYXJhbXMgfSBmcm9tICcuL2tkLWFuZ3VsYXItdGFibGUtaW50ZXJmYWNlJztcclxuXHJcbkBJbmplY3RhYmxlKHtcclxuICAgIHByb3ZpZGVkSW46ICdyb290J1xyXG59KVxyXG5leHBvcnQgY2xhc3MgS2RUYWJsZUV2ZW50IHtcclxuICAgIGNvbnN0cnVjdG9yKFxyXG4gICAgICAgIHByaXZhdGUgX2Jyb2FkY2FzdGVyOiBLZEJyb2FkY2FzdGVyXHJcbiAgICApIHsgfVxyXG5cclxuICAgIC8vLyBGb3IgYW55IGNvbXBvbmVudCB1c2luZyBLZFRhYmxlIHRvIGNhcHR1cmUgYWxsIHRoZSBpbmZvcm1hdGlvbnMgS2RUYWJsZSBlbWl0c1xyXG4gICAgcHVibGljIG9uS2RUYWJsZUV2ZW50TGlzdChfZ3JpZElkOiBzdHJpbmcpOiBPYnNlcnZhYmxlPGFueT4ge1xyXG4gICAgICAgIHJldHVybiB0aGlzLl9icm9hZGNhc3Rlci5vbjxhbnk+KF9ncmlkSWQgKyAnS2RUYWJsZUV2ZW50Jyk7XHJcbiAgICB9XHJcbn1cclxuXHJcbkBJbmplY3RhYmxlKClcclxuZXhwb3J0IGNsYXNzIEtkSW50VGFibGVFdmVudCB7XHJcbiAgICBjb25zdHJ1Y3RvcihcclxuICAgICAgICBwcml2YXRlIF9icm9hZGNhc3RlcjogS2RCcm9hZGNhc3RlclxyXG4gICAgKSB7IH1cclxuXHJcbiAgICAvLy8gQnJvYWRjYXN0IGFueSBldmVudHMgZm9yIGNvbXBvbmVudHMgdXNpbmcgS2RUYWJsZVxyXG4gICAgcHVibGljIGtkVGFibGVFdmVudExpc3QoX2dyaWRJZDogc3RyaW5nLCBfZXZlbnQ/OiBhbnkpOiB2b2lkIHtcclxuICAgICAgICB0aGlzLl9icm9hZGNhc3Rlci5icm9hZGNhc3QoX2dyaWRJZCArICdLZFRhYmxlRXZlbnQnLCBfZXZlbnQpO1xyXG4gICAgfVxyXG5cclxuICAgIC8vLyBVc2VkIG9uIGtkLXRhYmxlLWFjdGlvbi50cyAtIEZvciBkZWxldGUgbm9kZSBwYXJhbXMgdG8gdXBkYXRlIHRoZSByb3cgZGF0YSBhY2NvcmRpbmdseVxyXG4gICAgcHVibGljIHVwZGF0ZUVtaXRSb3dOb2RlcyhfZ3JpZElkOiBzdHJpbmcsIF9hY3Rpb246IHN0cmluZywgX3Jvd0RhdGE6IGFueSk6IHZvaWQge1xyXG4gICAgICAgIGxldCBkYXRhOiB7IGFjdGlvbjogc3RyaW5nLCByb3dEYXRhOiBhbnkgfSA9IHtcclxuICAgICAgICAgICAgYWN0aW9uOiBfYWN0aW9uLFxyXG4gICAgICAgICAgICByb3dEYXRhOiBfcm93RGF0YVxyXG4gICAgICAgIH07XHJcbiAgICAgICAgdGhpcy5fYnJvYWRjYXN0ZXIuYnJvYWRjYXN0KF9ncmlkSWQgKyAnS2RUYWJsZVJvd1VwZGF0ZWQnLCBkYXRhKTtcclxuICAgIH1cclxuXHJcbiAgICAvLy8gVXNlZCBvbiBrZC1hbmd1bGFyLXRhYmxlLnRzIC0gRm9yIHVwZGF0ZSB0aGUgZGVsZXRlIG5vZGUgcGFyYW1zIGluIGtkLXRhYmxlLWFjdGlvbi50c1xyXG4gICAgcHVibGljIG9uVXBkYXRlRW1pdFJvd05vZGVzKF9ncmlkSWQ6IHN0cmluZyk6IE9ic2VydmFibGU8YW55PiB7XHJcbiAgICAgICAgcmV0dXJuIHRoaXMuX2Jyb2FkY2FzdGVyLm9uPGFueT4oX2dyaWRJZCArICdLZFRhYmxlUm93VXBkYXRlZCcpO1xyXG4gICAgfVxyXG5cclxuICAgIC8vLyBVc2VkIG9uIGtkLXRhYmxlLWNoZWNrYm94LXJhZGlvLnRzIC0gQ2hlY2tib3ggLyByYWRpbyBlbWl0IGNoYW5nZSBldmVudFxyXG4gICAgcHVibGljIHNlbGVjdGlvbkNoYW5nZWQoX2dyaWRJZDogc3RyaW5nLCBfZGF0YT86IGFueSk6IHZvaWQge1xyXG4gICAgICAgIHRoaXMuX2Jyb2FkY2FzdGVyLmJyb2FkY2FzdChfZ3JpZElkICsgJ0tkVGFibGVVcGRhdGVOb2RlcycsIF9kYXRhKTtcclxuICAgIH1cclxuXHJcbiAgICAvLy8gVXNlZCBvbiBrZC10YWJsZS1jaGVja2JveC1yYWRpby50cyAtIFRvIHJlY2hlY2sgdGhlIHNlbGVjdCBhbGwgY2hlY2tib3hcclxuICAgIHB1YmxpYyBvblNlbGVjdGlvbkNoYW5nZWQoX2dyaWRJZDogc3RyaW5nKTogT2JzZXJ2YWJsZTxhbnk+IHtcclxuICAgICAgICByZXR1cm4gdGhpcy5fYnJvYWRjYXN0ZXIub248YW55PihfZ3JpZElkICsgJ0tkVGFibGVVcGRhdGVOb2RlcycpO1xyXG4gICAgfVxyXG5cclxuICAgIC8vLyBVc2VkIG9uIGtkLWFuZ3VsYXItdGFibGUudHMgLSBFbWl0IG9uIHJvdyBkYXRhIC8gbW9kZWwgY2hhbmdlZFxyXG4gICAgcHVibGljIG1vZGVsQ2hhbmdlZChfZ3JpZElkOiBzdHJpbmcsIF9kYXRhPzogYW55KTogdm9pZCB7XHJcbiAgICAgICAgdGhpcy5fYnJvYWRjYXN0ZXIuYnJvYWRjYXN0KF9ncmlkSWQgKyAnS2RNb2RlbFVwZGF0ZWQnLCBfZGF0YSk7XHJcbiAgICB9XHJcblxyXG4gICAgLy8vIFVzZWQgb24ga2QtdGFibGUtY2hlY2tib3gtcmFkaW8udHMgLSBUbyByZWNoZWNrIHRoZSBzZWxlY3QgYWxsIGNoZWNrYm94XHJcbiAgICBwdWJsaWMgb25Nb2RlbENoYW5nZWQoX2dyaWRJZDogc3RyaW5nKTogT2JzZXJ2YWJsZTxhbnk+IHtcclxuICAgICAgICByZXR1cm4gdGhpcy5fYnJvYWRjYXN0ZXIub248YW55PihfZ3JpZElkICsgJ0tkTW9kZWxVcGRhdGVkJyk7XHJcbiAgICB9XHJcblxyXG4gICAgLy8vIFVzZWQgb24ga2QtdGFibGUtaW5wdXQudHMgLSBGb3IgZW1pdHRpbmcgYW55IGZvcm0gY2hhbmdlcyB0byBvdXRwdXQgdG8gZHluYW1pY0Zvcm1cclxuICAgIHB1YmxpYyBpbnB1dENoYW5nZWQoX2dyaWRJZDogc3RyaW5nLCBfZGF0YT86IElUYWJsZUZvcm1QYXJhbXMpOiB2b2lkIHtcclxuICAgICAgICB0aGlzLl9icm9hZGNhc3Rlci5icm9hZGNhc3QoX2dyaWRJZCArICdLZFRhYmxlSW5wdXRDaGFuZ2VkJywgX2RhdGEpO1xyXG4gICAgfVxyXG5cclxuICAgIC8vLyBVc2VkIG9uIGtkLWFuZ3VsYXItdGFibGUudHMgLSBDYXB0dXJlIHRoZSBjaGFuZ2UgcGFyYW1zIGFuZCBlbWl0IHRvIGFueW9uZSB1c2luZyB0aGUgb3V0cHV0XHJcbiAgICBwdWJsaWMgb25JbnB1dENoYW5nZWQoX2dyaWRJZDogc3RyaW5nKTogT2JzZXJ2YWJsZTxJVGFibGVGb3JtUGFyYW1zPiB7XHJcbiAgICAgICAgcmV0dXJuIHRoaXMuX2Jyb2FkY2FzdGVyLm9uPElUYWJsZUZvcm1QYXJhbXM+KF9ncmlkSWQgKyAnS2RUYWJsZUlucHV0Q2hhbmdlZCcpO1xyXG4gICAgfVxyXG59XHJcbiJdfQ==