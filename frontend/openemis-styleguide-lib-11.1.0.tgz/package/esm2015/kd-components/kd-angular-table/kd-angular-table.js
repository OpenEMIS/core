import { Component, ViewEncapsulation, Input, HostBinding, HostListener, ViewContainerRef, EventEmitter, Output } from '@angular/core';
import { Router } from '@angular/router';
import { Observable, timer } from 'rxjs';
import 'ag-grid-enterprise';
import * as XLSX from 'xlsx';
import { saveAs } from 'file-saver';
import { KdTableDatasourceEvent, KdTableSelectionUpdateEvent, KdTableInputUpdateEvent, KdTableButtonEvent } from './kd-angular-table-interface';
import { KdIntTableEvent } from './kd-angular-table-event';
import { KdTableNormalSvc } from './table-services/kd-table-normal-svc';
import { KdTableEnterpriseSvc } from './table-services/kd-table-enterprise-svc';
// import { KdSplitterEvent } from '../';
import { KdDomElemSvc, AG_GRID_KEY } from '../kd-common/index';
import { LicenseManager } from "ag-grid-enterprise";
/**
 * -- Documentation for kd-angular-table.ts (kd-table)
 *
 * - HostListener
 *     - onResize
 *
 * - Life cycles:
 *     - ngOnInit
 *     - ngOnChanges
 *     - ngOnDestroy

 * - ag-Grid events function:
 *     - onGridReady
 *     - onModelUpdated
 *     - onRowClicked
 *
 * - kd-table button function:
 *     - onButtonClicekd
 *
 * - Private functions:
 *     - Display / DOM functions:
 *         - _resizeColumn
 *         - _showLoadingOverlay
 *         - _updateParentNodeCSS
 *         - _setHeight
 *         - _setMobileHeight (flatten table)
 *         - _setWebHeighr (user configuration)
 *         - _isClickValid (click configuration)
 *
 *     - Grid Cycles:
 *         - _gridInitCycle
 *         - _gridReadyCycle
 *         - _gridReadyEnterpriseCycle
 *         - _gridReadyDOMCycle
 *         - _gridSelectionCycle
 *         - _gridSetRowCycle
 *         - _gridClickNavigateCycle
 *
 *     - Column / Row / Config generations/processing:
 *         - _setGridOptions
 *         - _setColumnDef
 *         - _setRowData
 *
 *     - Event functions:
 *         - _processEventParams<T>
 *         - _broadcastEventParams
 *         - _broadcastModelChanged
 *         - _setupSubscriptionEvents
 *
 *     - Selection functions:
 *         - _updateSelectionNodes
 *         - _processInitialSelection
 *
 *     - Input functions:
 *         - _processInputChanged
 *         - _emitInputUpdateEvent
 *         - _deleteNodeFromRowData
 *
 *     - Datasource functions:
 *         - _clearDatasource
 *         - _generateEnterpriseDatasource
 *         - _generateDatasourceRows
 *
 *     - API generations:
 *         - _initITableApi (TODO: update api setting all to table service)
 *
 *     - Misc functions:
 *         - _initGridService
 *         - _updateGridConfig
 */
export class KdTable {
    constructor(_vcr, _router, _domSvc, 
    // private _splitterEvent: KdSplitterEvent,
    _tableIntEvent) {
        this._vcr = _vcr;
        this._router = _router;
        this._domSvc = _domSvc;
        this._tableIntEvent = _tableIntEvent;
        this.gridId = '';
        this.displayLoading = true;
        this._singleClickEdit = false;
        this._enterprise = require('ag-grid-enterprise');
        this._subscriptionObj = {};
        this._currentState = {
            columnState: [],
            pivotMode: false,
            groupState: []
        };
        this._isChangingState = false;
        this._pivotElement = {
            'pivot': null,
            'column-drop': null
        };
        this._suppressMovableColumns = true;
        this._direction = 'ltr';
        this.onExportPossible = new EventEmitter();
        this._classKdxTable = true;
        this.editingModeEnabled = false;
        LicenseManager.setLicenseKey(AG_GRID_KEY.value);
    }
    onResize(_event) {
        this._setHeight();
    }
    /************************* Life cycles functions *****************************/
    ngOnInit() {
        // console.log("-- Grid state: Init --", this.row, this.column, this.config, this.api);
        this._showLoadingOverlay(true);
        this._gridInitCycle();
    }
    ngOnChanges(_simpleChanges) {
        this._showLoadingOverlay(true);
        console.log("-- Grid state: Change -- ", _simpleChanges);
        if (typeof _simpleChanges.column !== 'undefined' &&
            !_simpleChanges.column.firstChange) {
            this._setColumnDef(_simpleChanges.column.currentValue);
            this._showLoadingOverlay(false);
        }
        if (typeof _simpleChanges.row !== 'undefined' &&
            !_simpleChanges.row.firstChange) {
            this._setRowData(_simpleChanges.row.currentValue);
            this._showLoadingOverlay(false);
        }
        if (typeof _simpleChanges.config !== 'undefined') {
            this._showLoadingOverlay(false);
            this.updateStyle(_simpleChanges.config.currentValue);
            timer(100).subscribe(() => {
                this._configurePivotDisplay();
                if (typeof this.config.suppressMovableColumns !== 'undefined') {
                    if (this.config.suppressMovableColumns !== this._suppressMovableColumns)
                        this._enableColumnMovable(this.config.suppressMovableColumns);
                }
                else {
                    this.config.suppressMovableColumns = this._suppressMovableColumns;
                }
            });
        }
    }
    ngOnDestroy() {
        // console.log("-- Grid state: Destroying --");
        for (let item in this._subscriptionObj) {
            if (typeof this._subscriptionObj[item] !== 'undefined') {
                this._subscriptionObj[item].unsubscribe();
            }
        }
    }
    setAttendance(displayEditTable, _config) {
        // let allColumns = this.gridOptions.columnApi.getAllColumns()
        // allColumns.forEach((column, index) => {
        //     let currentColumnDef = column.getColDef()
        //     console.log(`column ${index+1}`, currentColumnDef)
        // })
        if (displayEditTable) {
            this.gridOptions.context.mode = 'edit';
        }
        else {
            this.gridOptions.context.mode = 'view';
            _config.context.mode = 'view';
        }
        setTimeout(() => { this.gridApi.resetRowHeights(); }, 100);
        let _columns = this.gridOptions.columnApi.getAllDisplayedColumns();
        // let colDef = _columns[2].getColDef()
        // console.log(colDef);
        // colDef.cellRendererParams = '<p>Hello</p>'
        // let newData = []
        // newData.push(colDef)
        this.gridOptions.columnApi.setValueColumns(_columns);
    }
    toggleEdits(data) {
        if (this.editTable && !this.displayEditable) {
            this.editingModeEnabled = !this.editingModeEnabled;
            this._singleClickEdit = !this._singleClickEdit;
            let _columns = this.gridOptions.columnApi.getAllDisplayedColumns();
            let newColumnData = [];
            _columns.forEach((column) => {
                let columnDef = column === null || column === void 0 ? void 0 : column.getColDef();
                if (columnDef.canEdit == true) {
                    columnDef.cellStyle = function (params) {
                        if (!isNaN(parseFloat(params.value)) && parseFloat(params.value) < 50) {
                            return { color: '#CC5C5C' };
                        }
                        else {
                            return { color: '#333' };
                        }
                    },
                        columnDef.cellClassRules = {
                            'oe-cell-highlight': function (params) {
                                return 1;
                            },
                            'oe-cell-error': function (params) {
                                // return params.data.save_error[params.colDef.field];
                            }
                        },
                        columnDef.cellRendererParams = {
                            shouldBeEditing: () => this.editingModeEnabled,
                        },
                        columnDef.editable = (params) => {
                            var name = params.node.data.name;
                            params.data.name = params.node.data.name;
                            return name;
                        },
                        columnDef.newValueHandler = (params) => {
                            if (data == 'text') {
                                let valueAsFloat = params.newValue;
                                params.data[params.colDef.field] = valueAsFloat;
                            }
                            else {
                                let valueAsFloat = parseFloat(params.newValue);
                                params.data[params.colDef.field] = valueAsFloat;
                            }
                            console.log(params.data[params.colDef.field], "params.data[params.colDef.field]");
                            // return true;
                        };
                }
                newColumnData.push(columnDef);
            });
            this.gridOptions.columnApi.setValueColumns(newColumnData);
        }
        else if (this.displayEditable) {
            this.editingModeEnabled = !this.editingModeEnabled;
            this._singleClickEdit = !this._singleClickEdit;
            let _columns = this.gridOptions.columnApi.getAllDisplayedColumns();
            let newColumnData = [];
            _columns.forEach((column) => {
                let columnDef = column === null || column === void 0 ? void 0 : column.getColDef();
                if (columnDef.canEdit == true) {
                    columnDef.valueGetter = function (params) {
                        var value = params.data[params.colDef.field];
                        if (data == 'text') {
                            return value;
                        }
                        else {
                            if (!isNaN(parseFloat(value))) {
                                return value;
                            }
                            else {
                                return '';
                            }
                        }
                    },
                        columnDef.cellClassRules = {},
                        columnDef.cellRendererParams = {
                            shouldBeEditing: () => this.editingModeEnabled,
                        },
                        columnDef.editable = (params) => {
                            return false;
                        };
                }
                newColumnData.push(columnDef);
            });
            this.gridOptions.columnApi.setValueColumns(newColumnData);
        }
    }
    setAttendanceStaff(displayEditTable) {
        if (displayEditTable) {
            this.gridOptions.context.action = 'edit';
        }
        else {
            this.gridOptions.context.action = 'view';
        }
        let _columns = this.gridOptions.columnApi.getAllDisplayedColumns();
        this.gridOptions.columnApi.setValueColumns(_columns);
        this._showLoadingOverlay(false);
    }
    setStudentMeal(displayEditTable) {
        if (displayEditTable) {
            this.gridOptions.context.mode = 'edit';
        }
        else {
            this.gridOptions.context.mode = 'view';
        }
        let _columns = this.gridOptions.columnApi.getAllDisplayedColumns();
        this.gridOptions.columnApi.setValueColumns(_columns);
        this._showLoadingOverlay(false);
    }
    /******************************* Grid events *********************************/
    onGridReady(_params) {
        // console.log('-- Grid state: Ready --', this.gridOptions);
        this.gridApi = _params.api;
        this._gridReadyCycle();
    }
    onModelUpdated(_event) {
        /// For select all checkbox checking on change pagination/update row data
        if (this._tableService.hasSelectionAll(this.config)) {
            this._broadcastModelChangedEvent();
        }
        if (this._isMobileView) {
            let gridElement = document.querySelector('#' + this.gridId + '.stg-theme');
            if (gridElement !== null) {
                this._setMobileHeight(gridElement);
            }
        }
    }
    onRowClicked(_params) {
        // console.log("-- Grid state: Row clicked --", _params);
        if (this._isClickValid(_params.event) && typeof this.config.click !== 'undefined' && !this.editTable) {
            switch (this.config.click.type) {
                case 'selection':
                    this._gridSelectionCycle(_params.node);
                    break;
                case 'router':
                    this._gridClickNavigateCycle(_params.node);
                    break;
                default:
                    break;
            }
            if (typeof this.config.click.callback !== 'undefined') {
                this.config.click.callback();
            }
        }
    }
    /***************************** Button functions ******************************/
    onButtonClicked(_button) {
        let buttonEvent = new KdTableButtonEvent(_button);
        this._processEventParams('button', buttonEvent);
    }
    /**************************** Private functions ******************************/
    ////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// Grid cycles
    ////////////////////////////////////////////////////////////////////////////////////////////////////////
    _gridInitCycle() {
        if (typeof this.config !== 'undefined') {
            this._initGridService(this.config.loadType);
            this._updateGridConfig(this.config);
            this._setGridOptions(this.config);
            this._setupSubscriptionEvents();
        }
        if (typeof this.column !== 'undefined') {
            this._setColumnDef(this.column);
        }
        if (typeof this.row !== 'undefined') {
            this._setRowData(this.row);
        }
    }
    _gridReadyCycle() {
        this._initITableApi();
        if (this._tableService.isEnterpriseModel(this.config.loadType)) {
            this._gridReadyEnterpriseCycle();
        }
        this._gridReadyDOMCycle();
    }
    _gridReadyEnterpriseCycle() {
        this._clearDatasource();
        this._generateEnterpriseDatasource();
    }
    _gridReadyDOMCycle() {
        this._updateParentNodeCSS();
        this._setHeight();
        this._resizeColumn();
    }
    _gridSelectionCycle(_rowNode) {
        if (typeof this.config.selection === 'undefined') {
            console.error('KdTable error: User have set click type to be selection but no selection is defined. Do you mean click type to router?');
        }
        else if (this.config.selection.type === 'single') {
            if (this.config.selection.value.indexOf(_rowNode.id) < 0) {
                this.gridOptions.api.deselectAll();
                _rowNode.selectThisNode(true);
                this.config.selection.value.splice(0, this.config.selection.value.length);
                this.config.selection.value.push(_rowNode.data.id);
                this._broadcastModelChangedEvent();
                this._updateSelectionNodes(_rowNode);
            }
        }
        else {
            let selection = !_rowNode.isSelected();
            _rowNode.selectThisNode(selection);
            this._broadcastModelChangedEvent();
            if (selection) {
                this.config.selection.value.push(_rowNode.data.id);
            }
            else {
                this.config.selection.value.splice(this.config.selection.value.indexOf(_rowNode.data.id), 1);
            }
            this._updateSelectionNodes(_rowNode);
        }
    }
    _gridSetRowCycle() {
        if (typeof this.config.selection !== 'undefined' && typeof this.config.selection.type !== 'undefined') {
            this._processInitialSelection();
        }
        else if (this._tableService.hasInputType(this.column, 'input')) {
            this._emitInputUpdateEvent();
        }
    }
    _gridClickNavigateCycle(_rowNode) {
        if (typeof this.config.click.pathMap !== 'undefined') {
            if (typeof this.config.action !== 'undefined' &&
                typeof this.config.action.list !== 'undefined') {
                let routerPath = '';
                for (let i = 0; i < this.config.action.list.length; ++i) {
                    let actionItem = this.config.action.list[i];
                    if (actionItem.type.toLowerCase() === this.config.click.pathMap.toLowerCase()) {
                        routerPath = this._tableService.getRouterPlaceholderPath(_rowNode, actionItem.path);
                        break;
                    }
                }
                if (routerPath !== '') {
                    this._router.navigate([routerPath]);
                }
                else {
                    console.warn('KdTable warning: Table router pathMap not found. pathMap set to:', this.config.click.pathMap);
                }
            }
            else {
                console.error('KdTable error: Table click event set to router pathMap but no action list is defined. Do you mean path property instead of pathMap property?');
            }
        }
        else if (typeof this.config.click.path !== 'undefined') {
            this._router.navigate([this.config.click.path]);
        }
        else {
            console.error('KdTable error: Table click event type set at router but no path / pathMap is provided. Do you mean click type selection / none?');
        }
    }
    ////////////////////////////////////////////////////////////////////////////////////////////////////////
    // Display / DOM function
    ////////////////////////////////////////////////////////////////////////////////////////////////////////
    _showLoadingOverlay(_toggle) {
        this.displayLoading = _toggle;
    }
    _updateParentNodeCSS() {
        this._vcr.element.nativeElement.parentNode.className += ' has-aggrid';
        if (this._direction === 'rtl') {
            document.querySelector('body').style.cssText += '--kdtable-header-text-align: right;';
            let pagingButton = document.getElementsByTagName("button");
            for (var i = 0; i < pagingButton.length; i++) {
                if (pagingButton[i].className == 'ag-paging-button-rtl' || pagingButton[i].className == 'ag-paging-button') {
                    pagingButton[i].className = "ag-paging-button-rtl";
                }
            }
            this.rightDirection = 'rtl';
        }
    }
    _setHeight() {
        let domEleQuery = '#' + this.gridId + '.stg-theme';
        let gridElement = this._vcr.element.nativeElement.querySelector(domEleQuery);
        if (gridElement !== null) {
            let windowsWidth = document.body.clientWidth;
            if (windowsWidth <= 1024) {
                if (typeof this._isMobileView === 'undefined' || !this._isMobileView) {
                    this._showLoadingOverlay(true);
                    this._isMobileView = true;
                    this._setMobileHeight(gridElement);
                }
            }
            else if (windowsWidth > 1024) {
                if (typeof this._isMobileView === 'undefined' || this._isMobileView) {
                    this._showLoadingOverlay(true);
                    this._isMobileView = false;
                    this._setWebGridHeight(gridElement, this.config.gridHeight);
                }
                else {
                    this.gridOptions.api.sizeColumnsToFit();
                }
            }
        }
    }
    /**
     * add border bottom dynamically so that when the row is lesser than body-container, there wont be any hanging border bottom
     * when the row is more than container, there will be a border-bottom
     */
    _setTableBorderBottom() {
        let containerEleQuery = ' .ag-body-container';
        let containerEle = this._vcr.element.nativeElement.querySelector(containerEleQuery);
        if (containerEle === null)
            return;
        let viewportEleQuery = ' .ag-body-viewport';
        let viewportEle = this._vcr.element.nativeElement.querySelector(viewportEleQuery);
        if (containerEle.clientHeight > viewportEle.clientHeight &&
            viewportEle.className &&
            viewportEle.className.indexOf('has-border-bottom') === -1) {
            viewportEle.className += ' has-border-bottom';
        }
        else if (containerEle.clientHeight < viewportEle.clientHeight) {
            viewportEle.className = viewportEle.className.replace(/has-border-bottom/gi, '');
        }
    }
    _setMobileHeight(_gridElement) {
        let newHeight = 0;
        if (this.config.loadType !== 'infinite') {
            let agHeaderEle = this._vcr.element.nativeElement.querySelector('.ag-header');
            let agBodyEle = this._vcr.element.nativeElement.querySelector('.ag-body-container');
            let agPagePanelEle = this._vcr.element.nativeElement.querySelector('div[ref="south"]');
            newHeight = 25;
            if (agHeaderEle !== null) {
                newHeight += agHeaderEle.clientHeight;
            }
            if (agBodyEle !== null) {
                newHeight += agBodyEle.clientHeight;
            }
            if (agPagePanelEle !== null) {
                newHeight += agPagePanelEle.clientHeight;
            }
        }
        else {
            newHeight = 400;
        }
        this._domSvc.setElementStyle(_gridElement, 'height', newHeight + 'px');
        timer(10).subscribe(() => {
            this.gridOptions.api.sizeColumnsToFit();
            this._showLoadingOverlay(false);
        });
    }
    /**
     * [_setWebGridHeight number for pixel or string "auto"]
     *  _configHeight [description]
     */
    _setWebGridHeight(_gridElement, _configHeight) {
        if (typeof _configHeight === 'number') {
            let gridHeight = 600;
            if (typeof _configHeight !== 'undefined') {
                gridHeight = _configHeight;
            }
            this._domSvc.setElementStyle(_gridElement, 'height', gridHeight + 'px');
        }
        else if (_configHeight === 'auto') {
            this.displayFull = true;
        }
        // else if (_configHeight === 'rowHeight') {
        //     this.gridOptions.domLayout = 'autoHeight';
        //     delete this.gridOptions.rowHeight;
        //     delete this.gridOptions.getRowHeight;
        // }
        timer().subscribe(() => {
            this.gridOptions.api.sizeColumnsToFit();
            this._showLoadingOverlay(false);
        });
    }
    _isClickValid(_event) {
        let targetElement = _event.target;
        let invalidList = ['action-btn', 'checkbox-radio-input', 'fa-chevron-down'];
        for (let i = 0; i < invalidList.length; i++) {
            if (targetElement.classList.contains(invalidList[i])) {
                return false;
            }
        }
        return true;
    }
    _resizeColumn(_isResizeToContent = false) {
        if (this._tableService.isApiReady(this.gridOptions)) {
            timer(10).subscribe(() => {
                (_isResizeToContent) ? this._resizeColumnToContent() : this.gridOptions.api.sizeColumnsToFit();
                this.onExportPossible.emit(true);
                this._showLoadingOverlay(false);
            });
        }
    }
    /**
     * resize column to colDef width
     */
    _resizeColumnToContent() {
        let allColumnIds = [];
        this.gridOptions.columnApi.getAllDisplayedColumns().forEach((column) => {
            allColumnIds.push(column.getColId());
        });
        this.gridOptions.columnApi.autoSizeColumns(allColumnIds);
    }
    /**
     * populate dynamic styling value
     * param {ITableConfig} _config: tableConfig
     */
    updateStyle(_config) {
        if (!_config || !_config.config) {
            document.querySelector('body').style.cssText = '';
            return;
        }
        let config = _config.config;
        let bodyCss = '';
        bodyCss += this._updateHeaderStyle(config);
        if (config.body) {
            if (config.body.alternateRow === true) {
                if (config.body.odd && config.body.odd.backgroundColor) {
                    bodyCss += '--kdtable-row-odd-background: ' + config.body.odd.backgroundColor + ';';
                }
                if (config.body.even && config.body.even.backgroundColor) {
                    bodyCss += '--kdtable-row-even-background: ' + config.body.even.backgroundColor + ';';
                }
            }
            if (config.body.style) {
                if (config.body.style.borderWidth) {
                    bodyCss += '--kdtable-body-border-width: ' + config.body.style.borderWidth + ';';
                    bodyCss += '--kdtable-header-border-width: ' + config.body.style.borderWidth + ';';
                }
                if (config.body.style.borderColor) {
                    bodyCss += '--kdtable-body-border-color: ' + config.body.style.borderColor + ';';
                    bodyCss += '--kdtable-header-border-color: ' + config.body.style.borderColor + ';';
                }
                if (config.body.style.borderStyle) {
                    bodyCss += '--kdtable-body-border-style: ' + config.body.style.borderStyle + ';';
                    bodyCss += '--kdtable-header-border-style: ' + config.body.style.borderStyle + ';';
                }
            }
        }
        document.querySelector('body').style.cssText = bodyCss;
    }
    _updateHeaderStyle(_config) {
        if (!_config.header || !_config.header.style)
            return '';
        let bodyCss = '';
        let styleNames = [
            'backgroundColor',
            'textAlign',
            'verticalAlign',
            'color',
            'fontFamily',
            'fontSize',
            'fontWeight',
            'fontStyle',
            'textDecoration',
            // 'borderWidth',
            // 'borderColor',
            // 'borderStyle',
            'opacity'
        ];
        for (let i = 0; i < styleNames.length; ++i) {
            let styleName = styleNames[i];
            let value = _config.header.style[styleName];
            if (styleName === 'verticalAlign')
                value = this._getAlignItem(value);
            styleName = (styleName === 'backgroundColor') ? 'background' : styleName.replace(/([a-z])([A-Z])/g, '$1-$2').toLowerCase();
            if (typeof value !== 'undefined') {
                if (styleName === 'borderWidth' &&
                    (typeof value !== 'string' || value.indexOf('px') === -1))
                    value += 'px';
                bodyCss += '--kdtable-header-' + styleName + ': ' + value + ';';
            }
        }
        return bodyCss;
    }
    /**
     * convert text align into flex-box item align
     * param {string} _verticalAlign: text verticalAlign
     */
    _getAlignItem(_verticalAlign) {
        if (_verticalAlign === 'baseline' || _verticalAlign === 'bottom') {
            return 'flex-end';
        }
        else if (_verticalAlign === 'top') {
            return 'flex-start';
        }
        else { // including invalid input
            if (_verticalAlign !== 'middle' && _verticalAlign !== undefined) {
                console.warn('ERROR: the vertical align value of ' + _verticalAlign + ' is not yet recognised by KdTable. Please only use either top, center or bottom');
            }
            return 'center';
        }
    }
    // private _refreshTable(_tableCellParams?: ITableCellParams): void {
    //     if (this._tableService && this._tableService.isApiReady && this._tableService.isApiReady(this.gridOptions)) {
    //         let toUpdateNode: Array<RowNode> = [];
    //         let allColumnIds: Array<string> = [];
    //         if (!_tableCellParams) {
    //             this.gridOptions.columnApi.getAllDisplayedColumns().forEach((column) => {
    //                 allColumnIds.push(column.getColId());
    //             });
    //         }
    //         this.gridOptions.api.forEachNode((_rowNode: RowNode): void => {
    //             if (_tableCellParams && typeof _rowNode.id !== 'undefined' && _rowNode.id === _tableCellParams.rowId) {
    //                 _rowNode.data[_tableCellParams.colId] = _tableCellParams.data;
    //                 toUpdateNode.push(_rowNode);
    //             } else {
    //                 toUpdateNode.push(_rowNode);
    //             }
    //         });
    //         let refreshParams: { rowNodes: Array<RowNode>, columns: Array<any> } = {
    //             rowNodes: toUpdateNode,
    //             columns: (_tableCellParams) ? [_tableCellParams.colId] : allColumnIds
    //         };
    //         this.gridOptions.api.refreshCells(refreshParams);
    //     }
    // }
    ////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// Pivot Function
    ////////////////////////////////////////////////////////////////////////////////////////////////////////
    _isToolpanelTypeChanged() {
        let isTypeChanged = true;
        if (this._previousToolpanelType) {
            if (typeExist(this.config)) {
                isTypeChanged = this._previousToolpanelType !== this.config.pivot.toolpanel.type;
            }
        }
        else {
            if (typeExist(this.config)) {
                this._previousToolpanelType = this.config.pivot.toolpanel.type;
            }
        }
        return isTypeChanged;
        function typeExist(_config) {
            return _config && _config.pivot && _config.pivot.toolpanel && _config.pivot.toolpanel.type;
        }
    }
    _configurePivotDisplay() {
        let isStateChanged = true;
        if (this.config && this.config.pivot && this.config.pivot.state && this.config.pivot.state.columnState) {
            isStateChanged = this.config.pivot.state.columnState.length !== this._currentState.columnState.length;
        }
        if (this.config.loadType !== 'normal' || (this._isToolpanelTypeChanged() === false && isStateChanged === false))
            return;
        let showToolPanel = false;
        let showPivotMode = false;
        if (this.config.pivot && this.config.pivot.toolpanel) {
            showToolPanel = this.config.pivot.toolpanel.type !== 'none';
            showPivotMode = this.config.pivot.toolpanel.type === 'pivot';
        }
        this._showToolPanel(showToolPanel);
        this._showPivotMode(showPivotMode);
    }
    /**
     * resize column to fit table container if the width of the content column is smaller than container
     */
    _pivotResize() {
        let container = this._vcr.element.nativeElement.querySelector('.ag-header-container');
        let header = this._vcr.element.nativeElement.querySelector('.ag-header-container .ag-header-row');
        this._resizeColumn(header.getBoundingClientRect().width > container.getBoundingClientRect().width);
    }
    _resetPivotColumn() {
        this.gridOptions.columnApi.setRowGroupColumns([]);
        this.gridOptions.columnApi.setPivotColumns([]);
        this.gridOptions.columnApi.setValueColumns([]);
        this.gridOptions.columnApi.setSecondaryColumns([]);
    }
    /**
     * pass state to application.
     * (if setState was triggered before), wait until setState has done processing
     * return {ITablePivotState} [description]
     */
    _getPivotState() {
        // if state is changing, wait until state has been updated then get the most updated state
        let getState = () => {
            this._currentState.columnState = this.gridOptions.columnApi.getColumnState();
            this._currentState.pivotMode = this.gridOptions.columnApi.isPivotMode();
            this._currentState.groupState = this.gridOptions.columnApi.getColumnGroupState();
            return this._currentState;
        };
        let check = () => {
            return this._isChangingState === false;
        };
        return this.wait(check, getState);
    }
    /**
     * replace current state if a state is given, expandGroup base on config
     * should wait until column is present.
     * param {ITablePivotState} _state
     */
    _setPivotState(_state) {
        if (typeof (_state) === 'undefined' || !_state.hasOwnProperty('columnState'))
            return;
        let setState = () => {
            this._isChangingState = true;
            if (_state.columnState.length === 0) {
                this._isChangingState = false;
                this._pivotResize();
                return;
            }
            this._currentState = Object.assign(this._currentState, _state);
            this.gridOptions.columnApi.setColumnState(_state.columnState);
            this.gridOptions.columnApi.setPivotMode(_state.pivotMode || false);
            this.gridOptions.columnApi.setColumnGroupState(_state.groupState || []);
            this._isChangingState = false;
            timer(100).subscribe(() => {
                this._setPivotColumns();
                this._expandGroup();
            });
        };
        let check = () => {
            return this.column && this.column.length > 0;
        };
        this.wait(check, setState);
    }
    /**
     * wait for something to finish then do something, breaks at 100th to prevent infinite loop
     * param {ITablePivotState} _state
     * return {any}
     */
    wait(_check, _do, _limitCounter = 0) {
        if ((_check() && this._tableService.isApiReady(this.gridOptions)) || _limitCounter === 100) {
            if (_limitCounter === 100)
                console.log('Timeout: check fails. running', _do);
            return _do();
        }
        else {
            timer(10).subscribe(() => {
                _limitCounter++;
                this.wait(_check, _do, _limitCounter);
            });
        }
    }
    _isPivotElmExist(_pivotElement) {
        return (typeof _pivotElement['pivot'] !== 'undefined' &&
            _pivotElement['pivot'] !== null &&
            typeof _pivotElement['column-drop'] !== 'undefined' &&
            _pivotElement['column-drop'] !== null);
    }
    /**
     * show pivot mode checkbox and label.
     * when pivot mode is hidden, all pivot data has to be reset.
     * param {boolean = true} _show: true to show, false to hide
     */
    _showPivotMode(_show = true) {
        let setPivotMode = () => {
            if (_show === true) {
                this._pivotElement['pivot'].className = this._pivotElement['pivot'].className.replace(/ hidden/gi, '');
                for (let i = 0; i < this._pivotElement['column-drop'].length; ++i) {
                    this._pivotElement['column-drop'][i].className = this._pivotElement['column-drop'][i].className.replace(/ hidden/gi, '');
                }
                this._setPivotState(this.config.pivot && this.config.pivot.state ? this.config.pivot.state : {});
                return;
            }
            if (this._pivotElement['pivot'] &&
                this._pivotElement['pivot'].className &&
                this._pivotElement['pivot'].className.indexOf('hidden') === -1) {
                this._pivotElement['pivot'].className += ' hidden';
                for (let j = 0; j < this._pivotElement['column-drop'].length; ++j) {
                    this._pivotElement['column-drop'][j].className += ' hidden';
                }
            }
            this._enabledPivotMode(false);
            this._setPivotState({
                'columnState': [],
                'pivotMode': false,
                'groupState': []
            });
            this._resetPivotColumn();
        };
        let check = () => {
            // if (this.config.pivot.toolpanel.type === 'none' || !this.config.pivot || !this.config.pivot.toolpanel) return true;
            if (this.config.pivot &&
                this.config.pivot.toolpanel &&
                this.config.pivot.toolpanel.type &&
                this.config.pivot.toolpanel.type !== 'none') {
                let isPivotElmExist = this._isPivotElmExist(this._pivotElement);
                if (isPivotElmExist === true)
                    return isPivotElmExist;
                let domEleQuery = '#' + this.gridId + '.stg-theme .ag-side-bar';
                this._pivotElement['pivot'] = this._vcr.element.nativeElement.querySelector(domEleQuery + ' .ag-pivot-mode-panel');
                this._pivotElement['column-drop'] = this._vcr.element.nativeElement.querySelectorAll(domEleQuery + ' .ag-column-drop');
                return this._isPivotElmExist(this._pivotElement);
            }
            else {
                return true;
            }
        };
        this.wait(check, setPivotMode);
    }
    /**
     * hide and show toolpanel (pivot mode panel)
     * param {boolean} _show: true to show, false to hide
     */
    _showToolPanel(_show) {
        if (this._tableService.isApiReady(this.gridOptions)) {
            timer(10).subscribe(() => {
                this.gridOptions.api.showToolPanel(_show);
            });
        }
    }
    /**
     * expand row group base on the status that passed in
     * param {boolean} _expand: true to expand, false to collapse
     */
    _expandGroup(_expand) {
        if (typeof _expand === 'undefined') {
            _expand = false;
            if (this.config.pivot && this.config.pivot.state && this.config.pivot.state.expandGroup) {
                _expand = this.config.pivot.state.expandGroup;
            }
        }
        if (this._tableService.isApiReady(this.gridOptions)) {
            timer(10).subscribe(() => {
                (_expand) ? this.gridOptions.api.expandAll() : this.gridOptions.api.collapseAll();
                this._pivotResize();
            });
        }
    }
    /**
     * turn on and off pivot mode
     * If on, 'Column Label' will appear
     * If on, tick column name on toolpanel will assign column to 'Row Group' / 'Values' depends on colDef
     * If off, tick column name on toolpanel will trigger column hide and show
     * param {boolean = false} _enabled: true to check, false to uncheck
     */
    _enabledPivotMode(_enabled = false) {
        this.gridOptions.columnApi.setPivotMode(_enabled);
    }
    // TODO: to be revisit
    /**
     * suppressMovableColumns on pivotColumns and rowGroupColumns
     * columns on pivot mode does not listen to colDef.suppressMovableColumns = true
     * hence we need to access their private variable lockPosition and lockPinned to suppress the column movement
     * param {any} _columns [either passed in from gridEvent: column or will getAllDisplayedColumns]
     */
    _setPivotColumns(_columns) {
        let isPinned = false;
        if (!_columns)
            _columns = this.gridOptions.columnApi.getAllDisplayedColumns();
        _columns.forEach((column) => {
            this._setColumn(column);
            let columnDef = column.getColDef();
            if (columnDef.pivotValueColumn) {
                this._setColumn(columnDef.pivotValueColumn);
            }
            else {
                if (column.parent) {
                    isPinned = true;
                    this._setColumn(column.parent, false);
                    column.parent.pinned = 'left';
                    column.pinned = 'left';
                    columnDef.pinned = 'left';
                }
            }
        });
        if (isPinned)
            this._resizeColumn(true);
    }
    _setColumn(_column, _isSetColDef = true) {
        if (_isSetColDef) {
            let columnDef = _column.getColDef();
            columnDef.suppressMovable = this._suppressMovableColumns;
            columnDef.lockPosition = this._suppressMovableColumns;
            columnDef.lockPinned = this._suppressMovableColumns;
        }
        if (_column.setMoving) {
            _column.setMoving(!this._suppressMovableColumns);
        }
        else {
            _column.moving = !this._suppressMovableColumns;
        }
        _column.lockPosition = this._suppressMovableColumns;
        _column.lockPinned = this._suppressMovableColumns;
    }
    // TODO: to be revisit
    ////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// Column/Row/Configuration Generation
    ////////////////////////////////////////////////////////////////////////////////////////////////////////
    _setGridOptions(_tableConfig) {
        if (_tableConfig.hasOwnProperty('suppressMovableColumns'))
            this._suppressMovableColumns = _tableConfig.suppressMovableColumns;
        this._direction = this._domSvc.getDocumentDirection();
        this.gridOptions = this._tableService.generateGridOptions(_tableConfig, this._direction);
        this.gridOptions.context['gridId'] = this.gridId;
        this.gridOptions.suppressMovableColumns = false;
        this.gridOptions.onColumnRowGroupChanged = (params) => {
            this._setPivotColumns(params.columns);
            this._expandGroup();
        };
        this._tableService.setGridOptions(this.gridOptions);
    }
    _setColumnDef(_colDefConfig) {
        this._tableService.setColumnDef(_colDefConfig, this.config, this._suppressMovableColumns);
        this._resizeColumn();
    }
    _enableColumnMovable(_enabled = true) {
        if (this._tableService.isApiReady(this.gridOptions)) {
            this._suppressMovableColumns = _enabled;
            this._setColumnDef(this.column);
            if (this.config.loadType === 'normal' && this.config.pivot.toolpanel.type === 'pivot') {
                this._setPivotState(this._currentState);
            }
            this._pivotResize();
        }
    }
    _setRowData(_rowData, _setToGridOptions = true) {
        // this._tableService.updateRowDataWithColumnConfig(_rowData, this.column, this.gridId);
        this._tableService.updateRowDataWithColumn(_rowData, this.column, this.gridId, this.gridOptions);
        if (_setToGridOptions) {
            this._tableService.setRowData(_rowData);
        }
        if (this._tableService.isEnterpriseModel(this.config.loadType) && this._tableService.isApiReady(this.gridOptions)) {
            this._gridReadyEnterpriseCycle();
        }
        timer().subscribe(() => {
            this._gridSetRowCycle();
            this._setTableBorderBottom();
        });
    }
    ////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// Events - Subscriber / On functions
    ////////////////////////////////////////////////////////////////////////////////////////////////////////
    _processEventParams(_fromEvent, _additionalParams) {
        switch (_fromEvent) {
            case 'datasource':
            case 'selection':
            case 'input':
            case 'button':
                this._broadcastEventParams(_additionalParams);
                break;
            default:
                console.error('KdTable warning: No such event found for: ', _fromEvent);
        }
    }
    _broadcastEventParams(_params) {
        this._tableIntEvent.kdTableEventList(this.config.id, _params);
    }
    _broadcastModelChangedEvent() {
        this._tableIntEvent.modelChanged(this.config.id);
    }
    _setupSubscriptionEvents() {
        this._subscriptionObj.selectNodesSub = this._tableIntEvent.onSelectionChanged(this.config.id).subscribe((_rowNode) => {
            this._updateSelectionNodes(_rowNode);
        });
        this._subscriptionObj.gridQuestionSub = this._tableIntEvent.onInputChanged(this.config.id).subscribe((_formParams) => {
            this._processInputChanged(_formParams);
        });
        this._subscriptionObj.updateEmitRow = this._tableIntEvent.onUpdateEmitRowNodes(this.config.id).subscribe((_data) => {
            if (_data.action === 'delete') {
                let rowKey = (typeof this.config.rowIdKey !== 'undefined') ? this.config.rowIdKey : 'id';
                this._deleteNodeFromRowData([_data.rowData[rowKey]]);
                this._emitInputUpdateEvent();
            }
        });
    }
    ////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// Selection - Checkbox / Radio functions
    ////////////////////////////////////////////////////////////////////////////////////////////////////////
    _updateSelectionNodes(_rowNode, _isInitial) {
        let triggerNode = (typeof _isInitial !== 'undefined' && _isInitial) ? 'initial' : 'all';
        if (typeof _rowNode !== 'undefined') {
            triggerNode = _rowNode.data.id;
        }
        let selectionParams = new KdTableSelectionUpdateEvent();
        selectionParams.triggerNode = triggerNode;
        selectionParams.selectedNodes = this._tableService.updateSelectionValues(this.gridOptions.rowData, this.config.selection.value, this.config.selection.returnKey, this.config.loadType);
        // selectionParams.selection = (_rowNode.isSelected()) ? 'selected' : 'unselected';
        this._processEventParams('selection', selectionParams);
    }
    _processInitialSelection() {
        this._updateSelectionNodes(undefined, true);
    }
    ////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// Input functions
    ////////////////////////////////////////////////////////////////////////////////////////////////////////
    _processInputChanged(_formParams) {
        let inputParams = new KdTableInputUpdateEvent();
        inputParams.colId = _formParams.colId;
        inputParams.rowId = _formParams.rowId;
        inputParams.questionKey = _formParams.questionKey;
        inputParams.question = _formParams.question;
        inputParams.value = _formParams.data;
        this._processEventParams('input', inputParams);
    }
    _emitInputUpdateEvent() {
        let inputParams = new KdTableInputUpdateEvent();
        this._processEventParams('input', inputParams);
    }
    _deleteNodeFromRowData(_dataList) {
        let rowIdKey = (typeof this.config.rowIdKey !== 'undefined') ? this.config.rowIdKey : 'id';
        for (let i = 0; i < _dataList.length; ++i) {
            for (let j = 0; j < this.row.length; ++j) {
                if (_dataList[i].toString() === this.row[j][rowIdKey].toString()) {
                    this.row.splice(j, 1);
                    break;
                }
            }
        }
    }
    ////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// Enterprise datasource functions
    ////////////////////////////////////////////////////////////////////////////////////////////////////////
    _clearDatasource() {
        if (this._tableService.isApiReady(this.gridOptions)) {
            this.gridOptions.api.setEnterpriseDatasource(null);
            this.gridOptions.api.setFilterModel(null);
            this.gridOptions.api.setSortModel(null);
            if (typeof this._subscriptionObj.datasourceSub !== 'undefined') {
                this._subscriptionObj.datasourceSub.unsubscribe();
            }
        }
    }
    _generateEnterpriseDatasource() {
        let datasource = {
            getRows: (_params) => {
                this._showLoadingOverlay(true);
                if (typeof this._subscriptionObj.datasourceSub !== 'undefined') {
                    this._subscriptionObj.datasourceSub.unsubscribe();
                }
                this._subscriptionObj.datasourceSub = this._generateDatasourceRows(_params).subscribe((_response) => {
                    _params.successCallback(_response.rows, _response.total);
                    this._showLoadingOverlay(false);
                });
            }
        };
        this.gridOptions.api.setEnterpriseDatasource(datasource);
    }
    _generateDatasourceRows(_datasourceParams) {
        return new Observable((_observer) => {
            switch (this.config.loadType) {
                case 'infinite':
                case 'oneshot':
                    this._tableService.generateDatasourceRows(_datasourceParams.request, this.gridOptions.rowData.slice()).subscribe((_response) => {
                        _observer.next(_response);
                        _observer.complete();
                    });
                    break;
                case 'server':
                    let serverParams = new KdTableDatasourceEvent(_datasourceParams.request, _observer);
                    this._processEventParams('datasource', serverParams);
                    break;
                default:
                    console.error('KdTable warning: No such loadType find for: ', this.config.loadType);
                    _observer.complete();
            }
        });
    }
    ////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// API functions
    ////////////////////////////////////////////////////////////////////////////////////////////////////////
    _initITableApi() {
        if (typeof this.api !== 'undefined') {
            let apiParams = {
                // gridOptions: this.gridOptions,
                event: this._tableIntEvent,
                id: this.config.id,
                rows: this.row,
                columns: this.column
            };
            this._tableService.generatedApiFunctions(this.api, apiParams);
            /// Temp fix to access loading variable //
            /********* General API **********/
            this.api.general.showLoading = (_toggle) => {
                this.displayLoading = _toggle;
            };
            this.api.general.updateCell = (_tableCellParams) => {
                let toUpdateNode = [];
                this.gridOptions.api.forEachNode((_rowNode) => {
                    if (typeof _rowNode.id !== 'undefined' && _rowNode.id === _tableCellParams.rowId) {
                        _rowNode.data[_tableCellParams.colId] = _tableCellParams.data;
                        toUpdateNode.push(_rowNode);
                    }
                });
                let refreshParams = {
                    rowNodes: toUpdateNode,
                    columns: [_tableCellParams.colId]
                };
                this.gridOptions.api.refreshCells(refreshParams);
            };
            this.api.general.searchRow = (_searchText) => {
                if (this.config.loadType === 'normal') {
                    this.gridOptions.api.setQuickFilter(_searchText);
                }
                else {
                    console.warn('KdTable warning: Quick filtering of data is not supported for oneshot/server/infinite loadType.');
                }
            };
            this.api.general.addRows = (_rows, _scrollToVisible = false) => {
                /*
                    ag-Grid did not export RowDataTransaction interface. Interface as:
                        {
                            add: [],
                            remove: [],
                            update: []
                        }
                 */
                if (typeof this.config.loadType === 'undefined' || this.config.loadType === 'normal') {
                    let rowKey = (typeof this.config.rowIdKey !== 'undefined') ? this.config.rowIdKey : 'id';
                    for (let i = 0; i < _rows.length; ++i) {
                        this.row.push(_rows[i]);
                    }
                    this._setRowData(this.row, false);
                    this.gridOptions.api.updateRowData({ add: _rows.slice() });
                    if (_scrollToVisible) {
                        this.gridOptions.api.ensureIndexVisible(this.gridOptions.api.getRowNode(_rows[0][rowKey].toString()).rowIndex);
                    }
                }
                else {
                    console.warn('KdTable warning: API function: addRows() can only be used for normal loadType.');
                }
            };
            this.api.general.deleteRows = (_id) => {
                if (typeof this.config.loadType === 'undefined' || this.config.loadType === 'normal') {
                    let deleteIdList = [];
                    if (typeof _id === 'string' || typeof _id === 'number') {
                        deleteIdList.push(_id.toString());
                    }
                    else {
                        for (let i = 0; i < _id.length; ++i) {
                            deleteIdList.push(_id.toString());
                        }
                    }
                    this._deleteNodeFromRowData(deleteIdList);
                    let key = typeof this.config.rowIdKey === 'undefined' ? 'id' : this.config.rowIdKey;
                    let deleteRows = [];
                    for (let i = 0; i < deleteIdList.length; ++i) {
                        deleteRows.push({ [key]: deleteIdList[i] });
                    }
                    /*
                        ag-Grid did not export RowDataTransaction interface. Interface as:
                            {
                                add: [],
                                remove: [],
                                update: []
                            }
                     */
                    let transactionObj = {
                        remove: deleteRows
                    };
                    this.gridOptions.api.updateRowData(transactionObj);
                    this._emitInputUpdateEvent();
                }
                else {
                    console.warn('KdTable warning: API function: addRows() can only be used for normal loadType.');
                }
            };
            this.api.general.setButtonDisabled = (_buttonType, _toDisabled) => {
                for (let i = 0; i < this.config.button.length; ++i) {
                    if (this.config.button[i].type === _buttonType) {
                        this.config.button[i].disabled = _toDisabled;
                    }
                }
            };
            this.api.general.exportToExcel = (_params) => {
                let defaultParams = {
                    fileName: 'file',
                    allColumns: true,
                    suppressTextAsCDATA: true,
                };
                // xlsx only allow sheet name to be 31 characters long;
                if (_params.hasOwnProperty('sheetName'))
                    _params.sheetName = _params.sheetName.slice(0, 31);
                let params = Object.assign({}, defaultParams, _params);
                let content = this.gridOptions.api.getDataAsExcel(params);
                let workbook = XLSX.read(content, { type: 'binary' });
                let xlsxContent = XLSX.write(workbook, { bookType: 'xlsx', type: 'base64' });
                let blobObject = this._tableService.b64toBlob(xlsxContent, 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
                saveAs(blobObject, params.fileName + '.xlsx');
            };
            this.api.general.resizeColumn = (_isResizeToContent = false) => {
                this._resizeColumn(_isResizeToContent);
            };
            this.api.general.enableColumnMovable = (_enabled) => {
                this._enableColumnMovable(_enabled);
            };
            /********* Pivot API **********/
            if (typeof (this.api.pivot) === 'undefined')
                this.api.pivot = {};
            this.api.pivot.autoResize = () => {
                this._pivotResize();
            };
            this.api.pivot.showToolPanel = (_show) => {
                this._showToolPanel(_show);
            };
            this.api.pivot.expandGroup = (_expand) => {
                this._expandGroup(_expand);
            };
            this.api.pivot.getPivotState = () => {
                return this._getPivotState();
            };
            this.api.pivot.setPivotState = (_state) => {
                this._setColumnDef(this.column);
                this._setPivotState(_state);
            };
            this.api.pivot.enabledPivotMode = (_enabled) => {
                this._enabledPivotMode(_enabled);
            };
            this.api.pivot.showPivotMode = (_show) => {
                this._showPivotMode(_show);
            };
            /********* Input API **********/
            this.api.dynamicForm.clearAllError = () => {
                let tableContext = this.gridOptions.context[this._tableService.getTableContextKey()];
                for (let item in tableContext) {
                    if (tableContext.hasOwnProperty(item)) {
                        let contextItem = tableContext[item];
                        for (let question in contextItem) {
                            if (contextItem.hasOwnProperty(question)) {
                                if (typeof contextItem[question].errors === 'undefined') {
                                    contextItem[question].errors = [];
                                }
                                contextItem[question].errors.length = 0;
                            }
                        }
                    }
                }
            };
        }
        else {
            console.warn('KdTable warning: No api property / undefined api property is passed in.');
        }
    }
    ////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// Misc functions
    ////////////////////////////////////////////////////////////////////////////////////////////////////////
    _initGridService(_loadType) {
        if (typeof _loadType === 'undefined' || _loadType === 'normal') {
            this._tableService = new KdTableNormalSvc();
        }
        else {
            this._tableService = new KdTableEnterpriseSvc();
        }
    }
    _updateGridConfig(_gridConfig) {
        this.gridId = this._tableService.getGridId(_gridConfig);
        this._tableService.updateGridButtons(_gridConfig);
        this._tableService.updateSelectDefaultValue(_gridConfig);
    }
}
KdTable.decorators = [
    { type: Component, args: [{
                selector: 'kd-table',
                template: "<div class=\"kdx kdx-ag-grid-wrapper\">\r\n    <kd-progressloader *ngIf=\"displayLoading\" configtype=\"small-spinner\" [configvalue]=\"null\"></kd-progressloader>\r\n    <div *ngIf=\"config?.button?.length > 0\" class=\"gird-btn-wrapper\">\r\n        <button *ngFor=\"let item of config.button\" class=\"btn btn-icon\" type='button' [disabled]=\"item.disabled\" (click)=\"onButtonClicked(item)\">\r\n            <i [ngClass]=\"item.icon\"></i>\r\n            <span>{{item.label}}</span>\r\n        </button>\r\n    </div>\r\n    <ag-grid-angular\r\n    \t#agGrid\r\n    \tid=\"{{gridId}}\"\r\n    \tclass=\"stg-theme\"\r\n        [ngClass]=\"rightDirection == 'rtl' ? 'rtl' : '' \"\r\n    \t[ngClass]=\"{'ag-row-clickable': config.click}\"\r\n        [gridOptions]=\"gridOptions\"\r\n        [rowDragManaged]=\"true\"\r\n        [singleClickEdit]=\"_singleClickEdit\"\r\n        (gridReady)=\"onGridReady($event)\"\r\n        (modelUpdated)=\"onModelUpdated($event)\"\r\n        (rowClicked)=\"onRowClicked($event)\"\r\n    ></ag-grid-angular>\r\n</div>",
                encapsulation: ViewEncapsulation.None,
                providers: [KdDomElemSvc, KdIntTableEvent, KdTableNormalSvc, KdTableEnterpriseSvc],
                host: { 'class': 'kdx-table' },
                styles: [""]
            },] }
];
KdTable.ctorParameters = () => [
    { type: ViewContainerRef },
    { type: Router },
    { type: KdDomElemSvc },
    { type: KdIntTableEvent }
];
KdTable.propDecorators = {
    row: [{ type: Input }],
    column: [{ type: Input }],
    config: [{ type: Input }],
    api: [{ type: Input }],
    editTable: [{ type: Input }],
    displayEditable: [{ type: Input }],
    onExportPossible: [{ type: Output }],
    displayFull: [{ type: HostBinding, args: ['class.full-grid',] }],
    _classKdxTable: [{ type: HostBinding, args: ['class.kdx-table',] }],
    onResize: [{ type: HostListener, args: ['window:resize', ['$event'],] }]
};
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoia2QtYW5ndWxhci10YWJsZS5qcyIsInNvdXJjZVJvb3QiOiJDOi9Qcm9qZWN0cy9Bbmd1bGFyL2lvc3RnLW9wZW5lbWlzLXN0eWxlZ3VpZGUvcHJvamVjdHMvb3BlbmVtaXMtc3R5bGVndWlkZS1saWIvc3JjLyIsInNvdXJjZXMiOlsia2QtY29tcG9uZW50cy9rZC1hbmd1bGFyLXRhYmxlL2tkLWFuZ3VsYXItdGFibGUudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsT0FBTyxFQUNILFNBQVMsRUFLVCxpQkFBaUIsRUFDakIsS0FBSyxFQUNMLFdBQVcsRUFDWCxZQUFZLEVBQ1osZ0JBQWdCLEVBQ2hCLFlBQVksRUFDWixNQUFNLEVBQ1QsTUFBTSxlQUFlLENBQUM7QUFDdkIsT0FBTyxFQUFFLE1BQU0sRUFBRSxNQUFNLGlCQUFpQixDQUFDO0FBQ3pDLE9BQU8sRUFBRSxVQUFVLEVBQUUsS0FBSyxFQUE0QixNQUFNLE1BQU0sQ0FBQztBQW9CbkUsT0FBTyxvQkFBb0IsQ0FBQztBQUM1QixPQUFPLEtBQUssSUFBSSxNQUFNLE1BQU0sQ0FBQztBQUM3QixPQUFPLEVBQUUsTUFBTSxFQUFFLE1BQU0sWUFBWSxDQUFDO0FBRXBDLE9BQU8sRUFXSCxzQkFBc0IsRUFDdEIsMkJBQTJCLEVBQzNCLHVCQUF1QixFQUN2QixrQkFBa0IsRUFDckIsTUFBTSw4QkFBOEIsQ0FBQztBQUV0QyxPQUFPLEVBQUUsZUFBZSxFQUFFLE1BQU0sMEJBQTBCLENBQUM7QUFDM0QsT0FBTyxFQUFFLGdCQUFnQixFQUFFLE1BQU0sc0NBQXNDLENBQUM7QUFDeEUsT0FBTyxFQUFFLG9CQUFvQixFQUFFLE1BQU0sMENBQTBDLENBQUM7QUFDaEYseUNBQXlDO0FBQ3pDLE9BQU8sRUFBRSxZQUFZLEVBQUUsV0FBVyxFQUFFLE1BQU0sb0JBQW9CLENBQUM7QUFDL0QsT0FBTyxFQUFFLGNBQWMsRUFBRSxNQUFNLG9CQUFvQixDQUFDO0FBSXBEOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7R0FxRUc7QUFhSCxNQUFNLE9BQU8sT0FBTztJQXlDaEIsWUFDWSxJQUFzQixFQUN0QixPQUFlLEVBQ2YsT0FBcUI7SUFDN0IsMkNBQTJDO0lBQ25DLGNBQStCO1FBSi9CLFNBQUksR0FBSixJQUFJLENBQWtCO1FBQ3RCLFlBQU8sR0FBUCxPQUFPLENBQVE7UUFDZixZQUFPLEdBQVAsT0FBTyxDQUFjO1FBRXJCLG1CQUFjLEdBQWQsY0FBYyxDQUFpQjtRQTdDcEMsV0FBTSxHQUFXLEVBQUUsQ0FBQztRQUdwQixtQkFBYyxHQUFZLElBQUksQ0FBQztRQUMvQixxQkFBZ0IsR0FBWSxLQUFLLENBQUM7UUFDakMsZ0JBQVcsR0FBRyxPQUFPLENBQUMsb0JBQW9CLENBQUMsQ0FBQztRQUc1QyxxQkFBZ0IsR0FBb0MsRUFBRSxDQUFDO1FBRXZELGtCQUFhLEdBQXFCO1lBQ3RDLFdBQVcsRUFBRSxFQUFFO1lBQ2YsU0FBUyxFQUFFLEtBQUs7WUFDaEIsVUFBVSxFQUFFLEVBQUU7U0FDakIsQ0FBQztRQUNNLHFCQUFnQixHQUFZLEtBQUssQ0FBQztRQUNsQyxrQkFBYSxHQUEyQjtZQUM1QyxPQUFPLEVBQUUsSUFBSTtZQUNiLGFBQWEsRUFBRSxJQUFJO1NBQ3RCLENBQUM7UUFFTSw0QkFBdUIsR0FBWSxJQUFJLENBQUM7UUFFeEMsZUFBVSxHQUFrQixLQUFLLENBQUM7UUFVaEMscUJBQWdCLEdBQTBCLElBQUksWUFBWSxFQUFFLENBQUM7UUFFdkMsbUJBQWMsR0FBWSxJQUFJLENBQUM7UUFHeEQsdUJBQWtCLEdBQVksS0FBSyxDQUFDO1FBU3ZDLGNBQWMsQ0FBQyxhQUFhLENBQUMsV0FBVyxDQUFDLEtBQUssQ0FBQyxDQUFDO0lBQ3BELENBQUM7SUFHRCxRQUFRLENBQUMsTUFBYTtRQUNsQixJQUFJLENBQUMsVUFBVSxFQUFFLENBQUM7SUFDdEIsQ0FBQztJQUVELCtFQUErRTtJQUMvRSxRQUFRO1FBQ0osdUZBQXVGO1FBQ3ZGLElBQUksQ0FBQyxtQkFBbUIsQ0FBQyxJQUFJLENBQUMsQ0FBQztRQUMvQixJQUFJLENBQUMsY0FBYyxFQUFFLENBQUM7SUFDMUIsQ0FBQztJQUVELFdBQVcsQ0FBQyxjQUE2QjtRQUNyQyxJQUFJLENBQUMsbUJBQW1CLENBQUMsSUFBSSxDQUFDLENBQUM7UUFDL0IsT0FBTyxDQUFDLEdBQUcsQ0FBQywyQkFBMkIsRUFBRSxjQUFjLENBQUMsQ0FBQztRQUV6RCxJQUFJLE9BQU8sY0FBYyxDQUFDLE1BQU0sS0FBSyxXQUFXO1lBQzVDLENBQUMsY0FBYyxDQUFDLE1BQU0sQ0FBQyxXQUFXLEVBQ3BDO1lBQ0UsSUFBSSxDQUFDLGFBQWEsQ0FBQyxjQUFjLENBQUMsTUFBTSxDQUFDLFlBQVksQ0FBQyxDQUFDO1lBQ3ZELElBQUksQ0FBQyxtQkFBbUIsQ0FBQyxLQUFLLENBQUMsQ0FBQztTQUNuQztRQUVELElBQUksT0FBTyxjQUFjLENBQUMsR0FBRyxLQUFLLFdBQVc7WUFDekMsQ0FBQyxjQUFjLENBQUMsR0FBRyxDQUFDLFdBQVcsRUFDakM7WUFDRSxJQUFJLENBQUMsV0FBVyxDQUFDLGNBQWMsQ0FBQyxHQUFHLENBQUMsWUFBWSxDQUFDLENBQUM7WUFDbEQsSUFBSSxDQUFDLG1CQUFtQixDQUFDLEtBQUssQ0FBQyxDQUFDO1NBQ25DO1FBRUQsSUFBSSxPQUFPLGNBQWMsQ0FBQyxNQUFNLEtBQUssV0FBVyxFQUFFO1lBQzlDLElBQUksQ0FBQyxtQkFBbUIsQ0FBQyxLQUFLLENBQUMsQ0FBQztZQUNoQyxJQUFJLENBQUMsV0FBVyxDQUFDLGNBQWMsQ0FBQyxNQUFNLENBQUMsWUFBWSxDQUFDLENBQUM7WUFFckQsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxHQUFTLEVBQUU7Z0JBQzVCLElBQUksQ0FBQyxzQkFBc0IsRUFBRSxDQUFDO2dCQUU5QixJQUFJLE9BQU8sSUFBSSxDQUFDLE1BQU0sQ0FBQyxzQkFBc0IsS0FBSyxXQUFXLEVBQzNEO29CQUNFLElBQUksSUFBSSxDQUFDLE1BQU0sQ0FBQyxzQkFBc0IsS0FBSyxJQUFJLENBQUMsdUJBQXVCO3dCQUNuRSxJQUFJLENBQUMsb0JBQW9CLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxzQkFBc0IsQ0FBQyxDQUFDO2lCQUNyRTtxQkFBTTtvQkFDSCxJQUFJLENBQUMsTUFBTSxDQUFDLHNCQUFzQixHQUFHLElBQUksQ0FBQyx1QkFBdUIsQ0FBQztpQkFDckU7WUFDTCxDQUFDLENBQUMsQ0FBQztTQUNOO0lBQ0wsQ0FBQztJQUVELFdBQVc7UUFDUCwrQ0FBK0M7UUFDL0MsS0FBSyxJQUFJLElBQUksSUFBSSxJQUFJLENBQUMsZ0JBQWdCLEVBQUU7WUFDcEMsSUFBSSxPQUFPLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxJQUFJLENBQUMsS0FBSyxXQUFXLEVBQUU7Z0JBQ3BELElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxJQUFJLENBQUMsQ0FBQyxXQUFXLEVBQUUsQ0FBQzthQUM3QztTQUNKO0lBQ0wsQ0FBQztJQUVELGFBQWEsQ0FBQyxnQkFBZ0IsRUFBRSxPQUFxQjtRQUNqRCw4REFBOEQ7UUFFOUQsMENBQTBDO1FBQzFDLGdEQUFnRDtRQUNoRCx5REFBeUQ7UUFDekQsS0FBSztRQUVMLElBQUksZ0JBQWdCLEVBQUU7WUFDbEIsSUFBSSxDQUFDLFdBQVcsQ0FBQyxPQUFPLENBQUMsSUFBSSxHQUFHLE1BQU0sQ0FBQTtTQUN6QzthQUFNO1lBQ0gsSUFBSSxDQUFDLFdBQVcsQ0FBQyxPQUFPLENBQUMsSUFBSSxHQUFHLE1BQU0sQ0FBQTtZQUN0QyxPQUFPLENBQUMsT0FBTyxDQUFDLElBQUksR0FBRyxNQUFNLENBQUM7U0FDakM7UUFDRCxVQUFVLENBQUMsR0FBRyxFQUFFLEdBQUcsSUFBSSxDQUFDLE9BQU8sQ0FBQyxlQUFlLEVBQUUsQ0FBQyxDQUFDLENBQUMsRUFBRSxHQUFHLENBQUMsQ0FBQztRQUMzRCxJQUFJLFFBQVEsR0FBRyxJQUFJLENBQUMsV0FBVyxDQUFDLFNBQVMsQ0FBQyxzQkFBc0IsRUFBRSxDQUFDO1FBQ25FLHVDQUF1QztRQUN2Qyx1QkFBdUI7UUFDdkIsNkNBQTZDO1FBQzdDLG1CQUFtQjtRQUNuQix1QkFBdUI7UUFDdkIsSUFBSSxDQUFDLFdBQVcsQ0FBQyxTQUFTLENBQUMsZUFBZSxDQUFDLFFBQVEsQ0FBQyxDQUFBO0lBQ3hELENBQUM7SUFFRCxXQUFXLENBQUMsSUFBSTtRQUNaLElBQUksSUFBSSxDQUFDLFNBQVMsSUFBSSxDQUFDLElBQUksQ0FBQyxlQUFlLEVBQUU7WUFDekMsSUFBSSxDQUFDLGtCQUFrQixHQUFHLENBQUMsSUFBSSxDQUFDLGtCQUFrQixDQUFDO1lBQ25ELElBQUksQ0FBQyxnQkFBZ0IsR0FBRyxDQUFDLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQztZQUMvQyxJQUFJLFFBQVEsR0FBRyxJQUFJLENBQUMsV0FBVyxDQUFDLFNBQVMsQ0FBQyxzQkFBc0IsRUFBRSxDQUFDO1lBQ25FLElBQUksYUFBYSxHQUFHLEVBQUUsQ0FBQztZQUN2QixRQUFRLENBQUMsT0FBTyxDQUFDLENBQUMsTUFBVyxFQUFFLEVBQUU7Z0JBQzdCLElBQUksU0FBUyxHQUFHLE1BQU0sYUFBTixNQUFNLHVCQUFOLE1BQU0sQ0FBRSxTQUFTLEVBQUUsQ0FBQztnQkFDcEMsSUFBSSxTQUFTLENBQUMsT0FBTyxJQUFJLElBQUksRUFBRTtvQkFDM0IsU0FBUyxDQUFDLFNBQVMsR0FBRyxVQUFVLE1BQVc7d0JBQ3ZDLElBQUksQ0FBQyxLQUFLLENBQUMsVUFBVSxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsQ0FBQyxJQUFJLFVBQVUsQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLEdBQUcsRUFBRSxFQUFFOzRCQUNuRSxPQUFPLEVBQUUsS0FBSyxFQUFFLFNBQVMsRUFBRSxDQUFDO3lCQUMvQjs2QkFBTTs0QkFDSCxPQUFPLEVBQUUsS0FBSyxFQUFFLE1BQU0sRUFBRSxDQUFDO3lCQUM1QjtvQkFDTCxDQUFDO3dCQUNHLFNBQVMsQ0FBQyxjQUFjLEdBQUc7NEJBQ3ZCLG1CQUFtQixFQUFFLFVBQVUsTUFBTTtnQ0FDakMsT0FBTyxDQUFDLENBQUM7NEJBQ2IsQ0FBQzs0QkFDRCxlQUFlLEVBQUUsVUFBVSxNQUFNO2dDQUM3QixzREFBc0Q7NEJBQzFELENBQUM7eUJBQ0o7d0JBQ0QsU0FBUyxDQUFDLGtCQUFrQixHQUFHOzRCQUMzQixlQUFlLEVBQUUsR0FBRyxFQUFFLENBQUMsSUFBSSxDQUFDLGtCQUFrQjt5QkFDakQ7d0JBQ0QsU0FBUyxDQUFDLFFBQVEsR0FBRyxDQUFDLE1BQVcsRUFBRSxFQUFFOzRCQUNqQyxJQUFJLElBQUksR0FBRyxNQUFNLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUM7NEJBQ2pDLE1BQU0sQ0FBQyxJQUFJLENBQUMsSUFBSSxHQUFHLE1BQU0sQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQzs0QkFDekMsT0FBTyxJQUFJLENBQUM7d0JBRWhCLENBQUM7d0JBQ0QsU0FBUyxDQUFDLGVBQWUsR0FBRyxDQUFDLE1BQVcsRUFBRSxFQUFFOzRCQUV4QyxJQUFJLElBQUksSUFBSSxNQUFNLEVBQUU7Z0NBQ2hCLElBQUksWUFBWSxHQUFHLE1BQU0sQ0FBQyxRQUFRLENBQUM7Z0NBQ25DLE1BQU0sQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsR0FBRyxZQUFZLENBQUM7NkJBQ25EO2lDQUFNO2dDQUNILElBQUksWUFBWSxHQUFHLFVBQVUsQ0FBQyxNQUFNLENBQUMsUUFBUSxDQUFDLENBQUM7Z0NBQy9DLE1BQU0sQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsR0FBRyxZQUFZLENBQUM7NkJBQ25EOzRCQUNELE9BQU8sQ0FBQyxHQUFHLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxFQUFFLGtDQUFrQyxDQUFDLENBQUM7NEJBRWxGLGVBQWU7d0JBQ25CLENBQUMsQ0FBQTtpQkFDUjtnQkFDRCxhQUFhLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDO1lBQ2xDLENBQUMsQ0FBQyxDQUFDO1lBQ0gsSUFBSSxDQUFDLFdBQVcsQ0FBQyxTQUFTLENBQUMsZUFBZSxDQUFDLGFBQWEsQ0FBQyxDQUFDO1NBQzdEO2FBQU0sSUFBSSxJQUFJLENBQUMsZUFBZSxFQUFFO1lBQzdCLElBQUksQ0FBQyxrQkFBa0IsR0FBRyxDQUFDLElBQUksQ0FBQyxrQkFBa0IsQ0FBQztZQUNuRCxJQUFJLENBQUMsZ0JBQWdCLEdBQUcsQ0FBQyxJQUFJLENBQUMsZ0JBQWdCLENBQUM7WUFDL0MsSUFBSSxRQUFRLEdBQUcsSUFBSSxDQUFDLFdBQVcsQ0FBQyxTQUFTLENBQUMsc0JBQXNCLEVBQUUsQ0FBQztZQUNuRSxJQUFJLGFBQWEsR0FBRyxFQUFFLENBQUM7WUFDdkIsUUFBUSxDQUFDLE9BQU8sQ0FBQyxDQUFDLE1BQVcsRUFBRSxFQUFFO2dCQUM3QixJQUFJLFNBQVMsR0FBRyxNQUFNLGFBQU4sTUFBTSx1QkFBTixNQUFNLENBQUUsU0FBUyxFQUFFLENBQUM7Z0JBQ3BDLElBQUksU0FBUyxDQUFDLE9BQU8sSUFBSSxJQUFJLEVBQUU7b0JBQzNCLFNBQVMsQ0FBQyxXQUFXLEdBQUcsVUFBVSxNQUFNO3dCQUNwQyxJQUFJLEtBQUssR0FBRyxNQUFNLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLENBQUM7d0JBQzdDLElBQUksSUFBSSxJQUFJLE1BQU0sRUFBRTs0QkFDaEIsT0FBTyxLQUFLLENBQUM7eUJBQ2hCOzZCQUFNOzRCQUNILElBQUksQ0FBQyxLQUFLLENBQUMsVUFBVSxDQUFDLEtBQUssQ0FBQyxDQUFDLEVBQUU7Z0NBQzNCLE9BQU8sS0FBSyxDQUFDOzZCQUNoQjtpQ0FBTTtnQ0FDSCxPQUFPLEVBQUUsQ0FBQzs2QkFDYjt5QkFDSjtvQkFDTCxDQUFDO3dCQUNHLFNBQVMsQ0FBQyxjQUFjLEdBQUcsRUFBRTt3QkFDN0IsU0FBUyxDQUFDLGtCQUFrQixHQUFHOzRCQUMzQixlQUFlLEVBQUUsR0FBRyxFQUFFLENBQUMsSUFBSSxDQUFDLGtCQUFrQjt5QkFDakQ7d0JBQ0QsU0FBUyxDQUFDLFFBQVEsR0FBRyxDQUFDLE1BQVcsRUFBRSxFQUFFOzRCQUNqQyxPQUFPLEtBQUssQ0FBQzt3QkFDakIsQ0FBQyxDQUFBO2lCQUNSO2dCQUNELGFBQWEsQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLENBQUM7WUFDbEMsQ0FBQyxDQUFDLENBQUM7WUFDSCxJQUFJLENBQUMsV0FBVyxDQUFDLFNBQVMsQ0FBQyxlQUFlLENBQUMsYUFBYSxDQUFDLENBQUM7U0FDN0Q7SUFDTCxDQUFDO0lBRUQsa0JBQWtCLENBQUMsZ0JBQWdCO1FBQy9CLElBQUksZ0JBQWdCLEVBQUU7WUFDbEIsSUFBSSxDQUFDLFdBQVcsQ0FBQyxPQUFPLENBQUMsTUFBTSxHQUFHLE1BQU0sQ0FBQztTQUM1QzthQUFNO1lBQ0gsSUFBSSxDQUFDLFdBQVcsQ0FBQyxPQUFPLENBQUMsTUFBTSxHQUFHLE1BQU0sQ0FBQztTQUM1QztRQUNELElBQUksUUFBUSxHQUFHLElBQUksQ0FBQyxXQUFXLENBQUMsU0FBUyxDQUFDLHNCQUFzQixFQUFFLENBQUM7UUFDbkUsSUFBSSxDQUFDLFdBQVcsQ0FBQyxTQUFTLENBQUMsZUFBZSxDQUFDLFFBQVEsQ0FBQyxDQUFDO1FBQ3JELElBQUksQ0FBQyxtQkFBbUIsQ0FBQyxLQUFLLENBQUMsQ0FBQztJQUNwQyxDQUFDO0lBRUQsY0FBYyxDQUFDLGdCQUFnQjtRQUMzQixJQUFJLGdCQUFnQixFQUFFO1lBQ2xCLElBQUksQ0FBQyxXQUFXLENBQUMsT0FBTyxDQUFDLElBQUksR0FBRyxNQUFNLENBQUM7U0FDMUM7YUFBTTtZQUNILElBQUksQ0FBQyxXQUFXLENBQUMsT0FBTyxDQUFDLElBQUksR0FBRyxNQUFNLENBQUM7U0FDMUM7UUFDRCxJQUFJLFFBQVEsR0FBRyxJQUFJLENBQUMsV0FBVyxDQUFDLFNBQVMsQ0FBQyxzQkFBc0IsRUFBRSxDQUFDO1FBQ25FLElBQUksQ0FBQyxXQUFXLENBQUMsU0FBUyxDQUFDLGVBQWUsQ0FBQyxRQUFRLENBQUMsQ0FBQztRQUNyRCxJQUFJLENBQUMsbUJBQW1CLENBQUMsS0FBSyxDQUFDLENBQUM7SUFDcEMsQ0FBQztJQUVELCtFQUErRTtJQUN4RSxXQUFXLENBQUMsT0FBWTtRQUMzQiw0REFBNEQ7UUFDNUQsSUFBSSxDQUFDLE9BQU8sR0FBRyxPQUFPLENBQUMsR0FBRyxDQUFDO1FBQzNCLElBQUksQ0FBQyxlQUFlLEVBQUUsQ0FBQztJQUMzQixDQUFDO0lBRU0sY0FBYyxDQUFDLE1BQXlCO1FBQzNDLHlFQUF5RTtRQUN6RSxJQUFJLElBQUksQ0FBQyxhQUFhLENBQUMsZUFBZSxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsRUFBRTtZQUNqRCxJQUFJLENBQUMsMkJBQTJCLEVBQUUsQ0FBQztTQUN0QztRQUVELElBQUksSUFBSSxDQUFDLGFBQWEsRUFBRTtZQUNwQixJQUFJLFdBQVcsR0FBWSxRQUFRLENBQUMsYUFBYSxDQUFDLEdBQUcsR0FBRyxJQUFJLENBQUMsTUFBTSxHQUFHLFlBQVksQ0FBQyxDQUFDO1lBRXBGLElBQUksV0FBVyxLQUFLLElBQUksRUFBRTtnQkFDdEIsSUFBSSxDQUFDLGdCQUFnQixDQUFDLFdBQVcsQ0FBQyxDQUFDO2FBQ3RDO1NBQ0o7SUFDTCxDQUFDO0lBRU0sWUFBWSxDQUFDLE9BQWlCO1FBQ2pDLHlEQUF5RDtRQUN6RCxJQUFJLElBQUksQ0FBQyxhQUFhLENBQUMsT0FBTyxDQUFDLEtBQUssQ0FBQyxJQUFJLE9BQU8sSUFBSSxDQUFDLE1BQU0sQ0FBQyxLQUFLLEtBQUssV0FBVyxJQUFJLENBQUMsSUFBSSxDQUFDLFNBQVMsRUFBRTtZQUNsRyxRQUFRLElBQUksQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLElBQUksRUFBRTtnQkFDNUIsS0FBSyxXQUFXO29CQUNaLElBQUksQ0FBQyxtQkFBbUIsQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLENBQUM7b0JBQ3ZDLE1BQU07Z0JBQ1YsS0FBSyxRQUFRO29CQUNULElBQUksQ0FBQyx1QkFBdUIsQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLENBQUM7b0JBQzNDLE1BQU07Z0JBQ1Y7b0JBQ0ksTUFBTTthQUNiO1lBRUQsSUFBSSxPQUFPLElBQUksQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLFFBQVEsS0FBSyxXQUFXLEVBQUU7Z0JBQ25ELElBQUksQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLFFBQVEsRUFBRSxDQUFDO2FBQ2hDO1NBQ0o7SUFDTCxDQUFDO0lBRUQsK0VBQStFO0lBQ3hFLGVBQWUsQ0FBQyxPQUFxQjtRQUN4QyxJQUFJLFdBQVcsR0FBdUIsSUFBSSxrQkFBa0IsQ0FBQyxPQUFPLENBQUMsQ0FBQztRQUN0RSxJQUFJLENBQUMsbUJBQW1CLENBQXFCLFFBQVEsRUFBRSxXQUFXLENBQUMsQ0FBQztJQUN4RSxDQUFDO0lBRUQsK0VBQStFO0lBQy9FLHdHQUF3RztJQUN4RyxlQUFlO0lBQ2Ysd0dBQXdHO0lBQ2hHLGNBQWM7UUFDbEIsSUFBSSxPQUFPLElBQUksQ0FBQyxNQUFNLEtBQUssV0FBVyxFQUFFO1lBQ3BDLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLFFBQVEsQ0FBQyxDQUFDO1lBQzVDLElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUM7WUFDcEMsSUFBSSxDQUFDLGVBQWUsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUM7WUFDbEMsSUFBSSxDQUFDLHdCQUF3QixFQUFFLENBQUM7U0FDbkM7UUFFRCxJQUFJLE9BQU8sSUFBSSxDQUFDLE1BQU0sS0FBSyxXQUFXLEVBQUU7WUFDcEMsSUFBSSxDQUFDLGFBQWEsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUM7U0FDbkM7UUFFRCxJQUFJLE9BQU8sSUFBSSxDQUFDLEdBQUcsS0FBSyxXQUFXLEVBQUU7WUFDakMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUM7U0FDOUI7SUFDTCxDQUFDO0lBRU8sZUFBZTtRQUNuQixJQUFJLENBQUMsY0FBYyxFQUFFLENBQUM7UUFFdEIsSUFBSSxJQUFJLENBQUMsYUFBYSxDQUFDLGlCQUFpQixDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsUUFBUSxDQUFDLEVBQUU7WUFDNUQsSUFBSSxDQUFDLHlCQUF5QixFQUFFLENBQUM7U0FDcEM7UUFFRCxJQUFJLENBQUMsa0JBQWtCLEVBQUUsQ0FBQztJQUM5QixDQUFDO0lBRU8seUJBQXlCO1FBQzdCLElBQUksQ0FBQyxnQkFBZ0IsRUFBRSxDQUFDO1FBQ3hCLElBQUksQ0FBQyw2QkFBNkIsRUFBRSxDQUFDO0lBQ3pDLENBQUM7SUFFTyxrQkFBa0I7UUFDdEIsSUFBSSxDQUFDLG9CQUFvQixFQUFFLENBQUM7UUFDNUIsSUFBSSxDQUFDLFVBQVUsRUFBRSxDQUFDO1FBQ2xCLElBQUksQ0FBQyxhQUFhLEVBQUUsQ0FBQztJQUN6QixDQUFDO0lBRU8sbUJBQW1CLENBQUMsUUFBaUI7UUFDekMsSUFBSSxPQUFPLElBQUksQ0FBQyxNQUFNLENBQUMsU0FBUyxLQUFLLFdBQVcsRUFBRTtZQUM5QyxPQUFPLENBQUMsS0FBSyxDQUFDLHdIQUF3SCxDQUFDLENBQUM7U0FDM0k7YUFDSSxJQUFJLElBQUksQ0FBQyxNQUFNLENBQUMsU0FBUyxDQUFDLElBQUksS0FBSyxRQUFRLEVBQUU7WUFDOUMsSUFBSSxJQUFJLENBQUMsTUFBTSxDQUFDLFNBQVMsQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLFFBQVEsQ0FBQyxFQUFFLENBQUMsR0FBRyxDQUFDLEVBQUU7Z0JBQ3RELElBQUksQ0FBQyxXQUFXLENBQUMsR0FBRyxDQUFDLFdBQVcsRUFBRSxDQUFDO2dCQUNuQyxRQUFRLENBQUMsY0FBYyxDQUFDLElBQUksQ0FBQyxDQUFDO2dCQUU5QixJQUFJLENBQUMsTUFBTSxDQUFDLFNBQVMsQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLENBQUMsRUFBRSxJQUFJLENBQUMsTUFBTSxDQUFDLFNBQVMsQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLENBQUM7Z0JBQzFFLElBQUksQ0FBQyxNQUFNLENBQUMsU0FBUyxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsQ0FBQztnQkFFbkQsSUFBSSxDQUFDLDJCQUEyQixFQUFFLENBQUM7Z0JBQ25DLElBQUksQ0FBQyxxQkFBcUIsQ0FBQyxRQUFRLENBQUMsQ0FBQzthQUN4QztTQUNKO2FBQ0k7WUFDRCxJQUFJLFNBQVMsR0FBWSxDQUFDLFFBQVEsQ0FBQyxVQUFVLEVBQUUsQ0FBQztZQUNoRCxRQUFRLENBQUMsY0FBYyxDQUFDLFNBQVMsQ0FBQyxDQUFDO1lBRW5DLElBQUksQ0FBQywyQkFBMkIsRUFBRSxDQUFDO1lBRW5DLElBQUksU0FBUyxFQUFFO2dCQUNYLElBQUksQ0FBQyxNQUFNLENBQUMsU0FBUyxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsQ0FBQzthQUN0RDtpQkFDSTtnQkFDRCxJQUFJLENBQUMsTUFBTSxDQUFDLFNBQVMsQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsU0FBUyxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQzthQUNoRztZQUVELElBQUksQ0FBQyxxQkFBcUIsQ0FBQyxRQUFRLENBQUMsQ0FBQztTQUN4QztJQUNMLENBQUM7SUFFTyxnQkFBZ0I7UUFDcEIsSUFBSSxPQUFPLElBQUksQ0FBQyxNQUFNLENBQUMsU0FBUyxLQUFLLFdBQVcsSUFBSSxPQUFPLElBQUksQ0FBQyxNQUFNLENBQUMsU0FBUyxDQUFDLElBQUksS0FBSyxXQUFXLEVBQUU7WUFDbkcsSUFBSSxDQUFDLHdCQUF3QixFQUFFLENBQUM7U0FDbkM7YUFFSSxJQUFJLElBQUksQ0FBQyxhQUFhLENBQUMsWUFBWSxDQUFDLElBQUksQ0FBQyxNQUFNLEVBQUUsT0FBTyxDQUFDLEVBQUU7WUFDNUQsSUFBSSxDQUFDLHFCQUFxQixFQUFFLENBQUM7U0FDaEM7SUFDTCxDQUFDO0lBRU8sdUJBQXVCLENBQUMsUUFBaUI7UUFDN0MsSUFBSSxPQUFPLElBQUksQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLE9BQU8sS0FBSyxXQUFXLEVBQUU7WUFDbEQsSUFBSSxPQUFPLElBQUksQ0FBQyxNQUFNLENBQUMsTUFBTSxLQUFLLFdBQVc7Z0JBQ3pDLE9BQU8sSUFBSSxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsSUFBSSxLQUFLLFdBQVcsRUFBRTtnQkFDaEQsSUFBSSxVQUFVLEdBQVcsRUFBRSxDQUFDO2dCQUU1QixLQUFLLElBQUksQ0FBQyxHQUFXLENBQUMsRUFBRSxDQUFDLEdBQUcsSUFBSSxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLE1BQU0sRUFBRSxFQUFFLENBQUMsRUFBRTtvQkFDN0QsSUFBSSxVQUFVLEdBQXlCLElBQUksQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQztvQkFFbEUsSUFBSSxVQUFVLENBQUMsSUFBSSxDQUFDLFdBQVcsRUFBRSxLQUFLLElBQUksQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxXQUFXLEVBQUUsRUFBRTt3QkFDM0UsVUFBVSxHQUFHLElBQUksQ0FBQyxhQUFhLENBQUMsd0JBQXdCLENBQUMsUUFBUSxFQUFFLFVBQVUsQ0FBQyxJQUFJLENBQUMsQ0FBQzt3QkFDcEYsTUFBTTtxQkFDVDtpQkFDSjtnQkFFRCxJQUFJLFVBQVUsS0FBSyxFQUFFLEVBQUU7b0JBQ25CLElBQUksQ0FBQyxPQUFPLENBQUMsUUFBUSxDQUFDLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQztpQkFDdkM7cUJBQ0k7b0JBQ0QsT0FBTyxDQUFDLElBQUksQ0FBQyxrRUFBa0UsRUFBRSxJQUFJLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsQ0FBQztpQkFDL0c7YUFDSjtpQkFDSTtnQkFDRCxPQUFPLENBQUMsS0FBSyxDQUFDLDhJQUE4SSxDQUFDLENBQUM7YUFDaks7U0FFSjthQUNJLElBQUksT0FBTyxJQUFJLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxJQUFJLEtBQUssV0FBVyxFQUFFO1lBQ3BELElBQUksQ0FBQyxPQUFPLENBQUMsUUFBUSxDQUFDLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQztTQUNuRDthQUNJO1lBQ0QsT0FBTyxDQUFDLEtBQUssQ0FBQyxpSUFBaUksQ0FBQyxDQUFDO1NBQ3BKO0lBQ0wsQ0FBQztJQUVELHdHQUF3RztJQUN4Ryx5QkFBeUI7SUFDekIsd0dBQXdHO0lBRWhHLG1CQUFtQixDQUFDLE9BQWdCO1FBQ3hDLElBQUksQ0FBQyxjQUFjLEdBQUcsT0FBTyxDQUFDO0lBQ2xDLENBQUM7SUFFTyxvQkFBb0I7UUFDeEIsSUFBSSxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsYUFBYSxDQUFDLFVBQVUsQ0FBQyxTQUFTLElBQUksYUFBYSxDQUFDO1FBQ3RFLElBQUksSUFBSSxDQUFDLFVBQVUsS0FBSyxLQUFLLEVBQUU7WUFDM0IsUUFBUSxDQUFDLGFBQWEsQ0FBQyxNQUFNLENBQUMsQ0FBQyxLQUFLLENBQUMsT0FBTyxJQUFJLHFDQUFxQyxDQUFDO1lBQ3RGLElBQUksWUFBWSxHQUFHLFFBQVEsQ0FBQyxvQkFBb0IsQ0FBQyxRQUFRLENBQUMsQ0FBQztZQUUzRCxLQUFLLElBQUksQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLEdBQUcsWUFBWSxDQUFDLE1BQU0sRUFBRSxDQUFDLEVBQUUsRUFBRTtnQkFDMUMsSUFBSSxZQUFZLENBQUMsQ0FBQyxDQUFDLENBQUMsU0FBUyxJQUFJLHNCQUFzQixJQUFJLFlBQVksQ0FBQyxDQUFDLENBQUMsQ0FBQyxTQUFTLElBQUksa0JBQWtCLEVBQUU7b0JBQ3hHLFlBQVksQ0FBQyxDQUFDLENBQUMsQ0FBQyxTQUFTLEdBQUcsc0JBQXNCLENBQUM7aUJBQ3REO2FBQ0o7WUFDRCxJQUFJLENBQUMsY0FBYyxHQUFHLEtBQUssQ0FBQztTQUMvQjtJQUNMLENBQUM7SUFFTyxVQUFVO1FBQ2QsSUFBSSxXQUFXLEdBQVcsR0FBRyxHQUFHLElBQUksQ0FBQyxNQUFNLEdBQUcsWUFBWSxDQUFDO1FBQzNELElBQUksV0FBVyxHQUFZLElBQUksQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLGFBQWEsQ0FBQyxhQUFhLENBQUMsV0FBVyxDQUFDLENBQUM7UUFFdEYsSUFBSSxXQUFXLEtBQUssSUFBSSxFQUFFO1lBQ3RCLElBQUksWUFBWSxHQUFXLFFBQVEsQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFDO1lBRXJELElBQUksWUFBWSxJQUFJLElBQUksRUFBRTtnQkFDdEIsSUFBSSxPQUFPLElBQUksQ0FBQyxhQUFhLEtBQUssV0FBVyxJQUFJLENBQUMsSUFBSSxDQUFDLGFBQWEsRUFBRTtvQkFDbEUsSUFBSSxDQUFDLG1CQUFtQixDQUFDLElBQUksQ0FBQyxDQUFDO29CQUMvQixJQUFJLENBQUMsYUFBYSxHQUFHLElBQUksQ0FBQztvQkFDMUIsSUFBSSxDQUFDLGdCQUFnQixDQUFDLFdBQVcsQ0FBQyxDQUFDO2lCQUN0QzthQUNKO2lCQUNJLElBQUksWUFBWSxHQUFHLElBQUksRUFBRTtnQkFDMUIsSUFBSSxPQUFPLElBQUksQ0FBQyxhQUFhLEtBQUssV0FBVyxJQUFJLElBQUksQ0FBQyxhQUFhLEVBQUU7b0JBQ2pFLElBQUksQ0FBQyxtQkFBbUIsQ0FBQyxJQUFJLENBQUMsQ0FBQztvQkFDL0IsSUFBSSxDQUFDLGFBQWEsR0FBRyxLQUFLLENBQUM7b0JBQzNCLElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxXQUFXLEVBQUUsSUFBSSxDQUFDLE1BQU0sQ0FBQyxVQUFVLENBQUMsQ0FBQztpQkFDL0Q7cUJBQ0k7b0JBQ0QsSUFBSSxDQUFDLFdBQVcsQ0FBQyxHQUFHLENBQUMsZ0JBQWdCLEVBQUUsQ0FBQztpQkFDM0M7YUFDSjtTQUNKO0lBQ0wsQ0FBQztJQUVEOzs7T0FHRztJQUNLLHFCQUFxQjtRQUN6QixJQUFJLGlCQUFpQixHQUFXLHFCQUFxQixDQUFDO1FBQ3RELElBQUksWUFBWSxHQUFZLElBQUksQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLGFBQWEsQ0FBQyxhQUFhLENBQUMsaUJBQWlCLENBQUMsQ0FBQztRQUM3RixJQUFJLFlBQVksS0FBSyxJQUFJO1lBQUUsT0FBTztRQUVsQyxJQUFJLGdCQUFnQixHQUFXLG9CQUFvQixDQUFDO1FBQ3BELElBQUksV0FBVyxHQUFZLElBQUksQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLGFBQWEsQ0FBQyxhQUFhLENBQUMsZ0JBQWdCLENBQUMsQ0FBQztRQUUzRixJQUFJLFlBQVksQ0FBQyxZQUFZLEdBQUcsV0FBVyxDQUFDLFlBQVk7WUFDcEQsV0FBVyxDQUFDLFNBQVM7WUFDckIsV0FBVyxDQUFDLFNBQVMsQ0FBQyxPQUFPLENBQUMsbUJBQW1CLENBQUMsS0FBSyxDQUFDLENBQUMsRUFDM0Q7WUFDRSxXQUFXLENBQUMsU0FBUyxJQUFJLG9CQUFvQixDQUFDO1NBQ2pEO2FBQU0sSUFBSSxZQUFZLENBQUMsWUFBWSxHQUFHLFdBQVcsQ0FBQyxZQUFZLEVBQUU7WUFDN0QsV0FBVyxDQUFDLFNBQVMsR0FBRyxXQUFXLENBQUMsU0FBUyxDQUFDLE9BQU8sQ0FBQyxxQkFBcUIsRUFBRSxFQUFFLENBQUMsQ0FBQztTQUNwRjtJQUNMLENBQUM7SUFFTyxnQkFBZ0IsQ0FBQyxZQUFxQjtRQUMxQyxJQUFJLFNBQVMsR0FBVyxDQUFDLENBQUM7UUFFMUIsSUFBSSxJQUFJLENBQUMsTUFBTSxDQUFDLFFBQVEsS0FBSyxVQUFVLEVBQUU7WUFDckMsSUFBSSxXQUFXLEdBQVksSUFBSSxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsYUFBYSxDQUFDLGFBQWEsQ0FBQyxZQUFZLENBQUMsQ0FBQztZQUN2RixJQUFJLFNBQVMsR0FBWSxJQUFJLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxhQUFhLENBQUMsYUFBYSxDQUFDLG9CQUFvQixDQUFDLENBQUM7WUFDN0YsSUFBSSxjQUFjLEdBQVksSUFBSSxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsYUFBYSxDQUFDLGFBQWEsQ0FBQyxrQkFBa0IsQ0FBQyxDQUFDO1lBQ2hHLFNBQVMsR0FBRyxFQUFFLENBQUM7WUFFZixJQUFJLFdBQVcsS0FBSyxJQUFJLEVBQUU7Z0JBQ3RCLFNBQVMsSUFBSSxXQUFXLENBQUMsWUFBWSxDQUFDO2FBQ3pDO1lBRUQsSUFBSSxTQUFTLEtBQUssSUFBSSxFQUFFO2dCQUNwQixTQUFTLElBQUksU0FBUyxDQUFDLFlBQVksQ0FBQzthQUN2QztZQUVELElBQUksY0FBYyxLQUFLLElBQUksRUFBRTtnQkFDekIsU0FBUyxJQUFJLGNBQWMsQ0FBQyxZQUFZLENBQUM7YUFDNUM7U0FDSjthQUNJO1lBQ0QsU0FBUyxHQUFHLEdBQUcsQ0FBQztTQUNuQjtRQUdELElBQUksQ0FBQyxPQUFPLENBQUMsZUFBZSxDQUFDLFlBQVksRUFBRSxRQUFRLEVBQUUsU0FBUyxHQUFHLElBQUksQ0FBQyxDQUFDO1FBRXZFLEtBQUssQ0FBQyxFQUFFLENBQUMsQ0FBQyxTQUFTLENBQUMsR0FBUyxFQUFFO1lBQzNCLElBQUksQ0FBQyxXQUFXLENBQUMsR0FBRyxDQUFDLGdCQUFnQixFQUFFLENBQUM7WUFDeEMsSUFBSSxDQUFDLG1CQUFtQixDQUFDLEtBQUssQ0FBQyxDQUFDO1FBQ3BDLENBQUMsQ0FBQyxDQUFDO0lBQ1AsQ0FBQztJQUVEOzs7T0FHRztJQUNLLGlCQUFpQixDQUFDLFlBQXFCLEVBQUUsYUFBOEI7UUFDM0UsSUFBSSxPQUFPLGFBQWEsS0FBSyxRQUFRLEVBQUU7WUFDbkMsSUFBSSxVQUFVLEdBQVcsR0FBRyxDQUFDO1lBRTdCLElBQUksT0FBTyxhQUFhLEtBQUssV0FBVyxFQUFFO2dCQUN0QyxVQUFVLEdBQUcsYUFBYSxDQUFDO2FBQzlCO1lBRUQsSUFBSSxDQUFDLE9BQU8sQ0FBQyxlQUFlLENBQUMsWUFBWSxFQUFFLFFBQVEsRUFBRSxVQUFVLEdBQUcsSUFBSSxDQUFDLENBQUM7U0FDM0U7YUFDSSxJQUFJLGFBQWEsS0FBSyxNQUFNLEVBQUU7WUFDL0IsSUFBSSxDQUFDLFdBQVcsR0FBRyxJQUFJLENBQUM7U0FDM0I7UUFDRCw0Q0FBNEM7UUFDNUMsaURBQWlEO1FBQ2pELHlDQUF5QztRQUN6Qyw0Q0FBNEM7UUFDNUMsSUFBSTtRQUVKLEtBQUssRUFBRSxDQUFDLFNBQVMsQ0FBQyxHQUFTLEVBQUU7WUFDekIsSUFBSSxDQUFDLFdBQVcsQ0FBQyxHQUFHLENBQUMsZ0JBQWdCLEVBQUUsQ0FBQztZQUN4QyxJQUFJLENBQUMsbUJBQW1CLENBQUMsS0FBSyxDQUFDLENBQUM7UUFDcEMsQ0FBQyxDQUFDLENBQUM7SUFDUCxDQUFDO0lBRU8sYUFBYSxDQUFDLE1BQWE7UUFDL0IsSUFBSSxhQUFhLEdBQTZCLE1BQU0sQ0FBQyxNQUFNLENBQUM7UUFDNUQsSUFBSSxXQUFXLEdBQWtCLENBQUMsWUFBWSxFQUFFLHNCQUFzQixFQUFFLGlCQUFpQixDQUFDLENBQUM7UUFFM0YsS0FBSyxJQUFJLENBQUMsR0FBVyxDQUFDLEVBQUUsQ0FBQyxHQUFHLFdBQVcsQ0FBQyxNQUFNLEVBQUUsQ0FBQyxFQUFFLEVBQUU7WUFDakQsSUFBSSxhQUFhLENBQUMsU0FBUyxDQUFDLFFBQVEsQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRTtnQkFDbEQsT0FBTyxLQUFLLENBQUM7YUFDaEI7U0FDSjtRQUVELE9BQU8sSUFBSSxDQUFDO0lBQ2hCLENBQUM7SUFFTyxhQUFhLENBQUMscUJBQThCLEtBQUs7UUFDckQsSUFBSSxJQUFJLENBQUMsYUFBYSxDQUFDLFVBQVUsQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFDLEVBQUU7WUFDakQsS0FBSyxDQUFDLEVBQUUsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxHQUFTLEVBQUU7Z0JBQzNCLENBQUMsa0JBQWtCLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLHNCQUFzQixFQUFFLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxXQUFXLENBQUMsR0FBRyxDQUFDLGdCQUFnQixFQUFFLENBQUM7Z0JBQy9GLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUM7Z0JBQ2pDLElBQUksQ0FBQyxtQkFBbUIsQ0FBQyxLQUFLLENBQUMsQ0FBQztZQUNwQyxDQUFDLENBQUMsQ0FBQztTQUNOO0lBQ0wsQ0FBQztJQUVEOztPQUVHO0lBQ0ssc0JBQXNCO1FBQzFCLElBQUksWUFBWSxHQUFrQixFQUFFLENBQUM7UUFDckMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxTQUFTLENBQUMsc0JBQXNCLEVBQUUsQ0FBQyxPQUFPLENBQUMsQ0FBQyxNQUFjLEVBQUUsRUFBRTtZQUMzRSxZQUFZLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxRQUFRLEVBQUUsQ0FBQyxDQUFDO1FBQ3pDLENBQUMsQ0FBQyxDQUFDO1FBQ0gsSUFBSSxDQUFDLFdBQVcsQ0FBQyxTQUFTLENBQUMsZUFBZSxDQUFDLFlBQVksQ0FBQyxDQUFDO0lBQzdELENBQUM7SUFFRDs7O09BR0c7SUFDSSxXQUFXLENBQUMsT0FBcUI7UUFDcEMsSUFBSSxDQUFDLE9BQU8sSUFBSSxDQUFDLE9BQU8sQ0FBQyxNQUFNLEVBQUU7WUFDN0IsUUFBUSxDQUFDLGFBQWEsQ0FBQyxNQUFNLENBQUMsQ0FBQyxLQUFLLENBQUMsT0FBTyxHQUFHLEVBQUUsQ0FBQztZQUNsRCxPQUFPO1NBQ1Y7UUFDRCxJQUFJLE1BQU0sR0FBbUIsT0FBTyxDQUFDLE1BQU0sQ0FBQztRQUU1QyxJQUFJLE9BQU8sR0FBVyxFQUFFLENBQUM7UUFFekIsT0FBTyxJQUFJLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxNQUFNLENBQUMsQ0FBQztRQUUzQyxJQUFJLE1BQU0sQ0FBQyxJQUFJLEVBQUU7WUFDYixJQUFJLE1BQU0sQ0FBQyxJQUFJLENBQUMsWUFBWSxLQUFLLElBQUksRUFBRTtnQkFDbkMsSUFBSSxNQUFNLENBQUMsSUFBSSxDQUFDLEdBQUcsSUFBSSxNQUFNLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxlQUFlLEVBQUU7b0JBQ3BELE9BQU8sSUFBSSxnQ0FBZ0MsR0FBRyxNQUFNLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxlQUFlLEdBQUcsR0FBRyxDQUFDO2lCQUN2RjtnQkFDRCxJQUFJLE1BQU0sQ0FBQyxJQUFJLENBQUMsSUFBSSxJQUFJLE1BQU0sQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLGVBQWUsRUFBRTtvQkFDdEQsT0FBTyxJQUFJLGlDQUFpQyxHQUFHLE1BQU0sQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLGVBQWUsR0FBRyxHQUFHLENBQUM7aUJBQ3pGO2FBQ0o7WUFDRCxJQUFJLE1BQU0sQ0FBQyxJQUFJLENBQUMsS0FBSyxFQUFFO2dCQUNuQixJQUFJLE1BQU0sQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLFdBQVcsRUFBRTtvQkFDL0IsT0FBTyxJQUFJLCtCQUErQixHQUFHLE1BQU0sQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLFdBQVcsR0FBRyxHQUFHLENBQUM7b0JBQ2pGLE9BQU8sSUFBSSxpQ0FBaUMsR0FBRyxNQUFNLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxXQUFXLEdBQUcsR0FBRyxDQUFDO2lCQUN0RjtnQkFDRCxJQUFJLE1BQU0sQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLFdBQVcsRUFBRTtvQkFDL0IsT0FBTyxJQUFJLCtCQUErQixHQUFHLE1BQU0sQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLFdBQVcsR0FBRyxHQUFHLENBQUM7b0JBQ2pGLE9BQU8sSUFBSSxpQ0FBaUMsR0FBRyxNQUFNLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxXQUFXLEdBQUcsR0FBRyxDQUFDO2lCQUN0RjtnQkFDRCxJQUFJLE1BQU0sQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLFdBQVcsRUFBRTtvQkFDL0IsT0FBTyxJQUFJLCtCQUErQixHQUFHLE1BQU0sQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLFdBQVcsR0FBRyxHQUFHLENBQUM7b0JBQ2pGLE9BQU8sSUFBSSxpQ0FBaUMsR0FBRyxNQUFNLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxXQUFXLEdBQUcsR0FBRyxDQUFDO2lCQUN0RjthQUNKO1NBQ0o7UUFFRCxRQUFRLENBQUMsYUFBYSxDQUFDLE1BQU0sQ0FBQyxDQUFDLEtBQUssQ0FBQyxPQUFPLEdBQUcsT0FBTyxDQUFDO0lBQzNELENBQUM7SUFFTyxrQkFBa0IsQ0FBQyxPQUF1QjtRQUM5QyxJQUFJLENBQUMsT0FBTyxDQUFDLE1BQU0sSUFBSSxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsS0FBSztZQUFFLE9BQU8sRUFBRSxDQUFDO1FBRXhELElBQUksT0FBTyxHQUFXLEVBQUUsQ0FBQztRQUN6QixJQUFJLFVBQVUsR0FBa0I7WUFDNUIsaUJBQWlCO1lBQ2pCLFdBQVc7WUFDWCxlQUFlO1lBQ2YsT0FBTztZQUNQLFlBQVk7WUFDWixVQUFVO1lBQ1YsWUFBWTtZQUNaLFdBQVc7WUFDWCxnQkFBZ0I7WUFDaEIsaUJBQWlCO1lBQ2pCLGlCQUFpQjtZQUNqQixpQkFBaUI7WUFDakIsU0FBUztTQUNaLENBQUM7UUFDRixLQUFLLElBQUksQ0FBQyxHQUFXLENBQUMsRUFBRSxDQUFDLEdBQUcsVUFBVSxDQUFDLE1BQU0sRUFBRSxFQUFFLENBQUMsRUFBRTtZQUNoRCxJQUFJLFNBQVMsR0FBVyxVQUFVLENBQUMsQ0FBQyxDQUFDLENBQUM7WUFDdEMsSUFBSSxLQUFLLEdBQVcsT0FBTyxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsU0FBUyxDQUFDLENBQUM7WUFDcEQsSUFBSSxTQUFTLEtBQUssZUFBZTtnQkFBRSxLQUFLLEdBQUcsSUFBSSxDQUFDLGFBQWEsQ0FBQyxLQUFLLENBQUMsQ0FBQztZQUNyRSxTQUFTLEdBQUcsQ0FBQyxTQUFTLEtBQUssaUJBQWlCLENBQUMsQ0FBQyxDQUFDLENBQUMsWUFBWSxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUMsT0FBTyxDQUFDLGlCQUFpQixFQUFFLE9BQU8sQ0FBQyxDQUFDLFdBQVcsRUFBRSxDQUFDO1lBQzNILElBQUksT0FBTyxLQUFLLEtBQUssV0FBVyxFQUFFO2dCQUM5QixJQUFJLFNBQVMsS0FBSyxhQUFhO29CQUMzQixDQUFDLE9BQU8sS0FBSyxLQUFLLFFBQVEsSUFBSSxLQUFLLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDO29CQUMzRCxLQUFLLElBQUksSUFBSSxDQUFDO2dCQUNoQixPQUFPLElBQUksbUJBQW1CLEdBQUcsU0FBUyxHQUFHLElBQUksR0FBRyxLQUFLLEdBQUcsR0FBRyxDQUFDO2FBQ25FO1NBQ0o7UUFDRCxPQUFPLE9BQU8sQ0FBQztJQUNuQixDQUFDO0lBRUQ7OztPQUdHO0lBQ0ssYUFBYSxDQUFDLGNBQXNCO1FBQ3hDLElBQUksY0FBYyxLQUFLLFVBQVUsSUFBSSxjQUFjLEtBQUssUUFBUSxFQUFFO1lBQzlELE9BQU8sVUFBVSxDQUFDO1NBQ3JCO2FBQU0sSUFBSSxjQUFjLEtBQUssS0FBSyxFQUFFO1lBQ2pDLE9BQU8sWUFBWSxDQUFDO1NBQ3ZCO2FBQU0sRUFBRSwwQkFBMEI7WUFDL0IsSUFBSSxjQUFjLEtBQUssUUFBUSxJQUFJLGNBQWMsS0FBSyxTQUFTLEVBQUU7Z0JBQzdELE9BQU8sQ0FBQyxJQUFJLENBQUMscUNBQXFDLEdBQUcsY0FBYyxHQUFHLGlGQUFpRixDQUFDLENBQUM7YUFDNUo7WUFDRCxPQUFPLFFBQVEsQ0FBQztTQUNuQjtJQUNMLENBQUM7SUFFRCxxRUFBcUU7SUFDckUsb0hBQW9IO0lBQ3BILGlEQUFpRDtJQUNqRCxnREFBZ0Q7SUFFaEQsbUNBQW1DO0lBQ25DLHdGQUF3RjtJQUN4Rix3REFBd0Q7SUFDeEQsa0JBQWtCO0lBQ2xCLFlBQVk7SUFFWiwwRUFBMEU7SUFDMUUsc0hBQXNIO0lBQ3RILGlGQUFpRjtJQUNqRiwrQ0FBK0M7SUFDL0MsdUJBQXVCO0lBQ3ZCLCtDQUErQztJQUMvQyxnQkFBZ0I7SUFDaEIsY0FBYztJQUVkLG1GQUFtRjtJQUNuRixzQ0FBc0M7SUFDdEMsb0ZBQW9GO0lBQ3BGLGFBQWE7SUFFYiw0REFBNEQ7SUFDNUQsUUFBUTtJQUNSLElBQUk7SUFFSix3R0FBd0c7SUFDeEcsa0JBQWtCO0lBQ2xCLHdHQUF3RztJQUNoRyx1QkFBdUI7UUFDM0IsSUFBSSxhQUFhLEdBQVksSUFBSSxDQUFDO1FBQ2xDLElBQUksSUFBSSxDQUFDLHNCQUFzQixFQUFFO1lBQzdCLElBQUksU0FBUyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsRUFBRTtnQkFDeEIsYUFBYSxHQUFHLElBQUksQ0FBQyxzQkFBc0IsS0FBSyxJQUFJLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDO2FBQ3BGO1NBQ0o7YUFBTTtZQUNILElBQUksU0FBUyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsRUFBRTtnQkFDeEIsSUFBSSxDQUFDLHNCQUFzQixHQUFHLElBQUksQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUM7YUFDbEU7U0FDSjtRQUNELE9BQU8sYUFBYSxDQUFDO1FBRXJCLFNBQVMsU0FBUyxDQUFDLE9BQU87WUFDdEIsT0FBTyxPQUFPLElBQUksT0FBTyxDQUFDLEtBQUssSUFBSSxPQUFPLENBQUMsS0FBSyxDQUFDLFNBQVMsSUFBSSxPQUFPLENBQUMsS0FBSyxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUE7UUFDOUYsQ0FBQztJQUNMLENBQUM7SUFFTyxzQkFBc0I7UUFDMUIsSUFBSSxjQUFjLEdBQVksSUFBSSxDQUFDO1FBQ25DLElBQUksSUFBSSxDQUFDLE1BQU0sSUFBSSxJQUFJLENBQUMsTUFBTSxDQUFDLEtBQUssSUFBSSxJQUFJLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxLQUFLLElBQUksSUFBSSxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLFdBQVcsRUFBRTtZQUNwRyxjQUFjLEdBQUcsSUFBSSxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLFdBQVcsQ0FBQyxNQUFNLEtBQUssSUFBSSxDQUFDLGFBQWEsQ0FBQyxXQUFXLENBQUMsTUFBTSxDQUFDO1NBQ3pHO1FBQ0QsSUFBSSxJQUFJLENBQUMsTUFBTSxDQUFDLFFBQVEsS0FBSyxRQUFRLElBQUksQ0FBQyxJQUFJLENBQUMsdUJBQXVCLEVBQUUsS0FBSyxLQUFLLElBQUksY0FBYyxLQUFLLEtBQUssQ0FBQztZQUFFLE9BQU87UUFFeEgsSUFBSSxhQUFhLEdBQVksS0FBSyxDQUFDO1FBQ25DLElBQUksYUFBYSxHQUFZLEtBQUssQ0FBQztRQUNuQyxJQUFJLElBQUksQ0FBQyxNQUFNLENBQUMsS0FBSyxJQUFJLElBQUksQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLFNBQVMsRUFBRTtZQUNsRCxhQUFhLEdBQUcsSUFBSSxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsU0FBUyxDQUFDLElBQUksS0FBSyxNQUFNLENBQUM7WUFDNUQsYUFBYSxHQUFHLElBQUksQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLFNBQVMsQ0FBQyxJQUFJLEtBQUssT0FBTyxDQUFDO1NBQ2hFO1FBQ0QsSUFBSSxDQUFDLGNBQWMsQ0FBQyxhQUFhLENBQUMsQ0FBQztRQUNuQyxJQUFJLENBQUMsY0FBYyxDQUFDLGFBQWEsQ0FBQyxDQUFDO0lBQ3ZDLENBQUM7SUFFRDs7T0FFRztJQUNLLFlBQVk7UUFDaEIsSUFBSSxTQUFTLEdBQVksSUFBSSxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsYUFBYSxDQUFDLGFBQWEsQ0FBQyxzQkFBc0IsQ0FBQyxDQUFDO1FBQy9GLElBQUksTUFBTSxHQUFZLElBQUksQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLGFBQWEsQ0FBQyxhQUFhLENBQUMscUNBQXFDLENBQUMsQ0FBQztRQUUzRyxJQUFJLENBQUMsYUFBYSxDQUFDLE1BQU0sQ0FBQyxxQkFBcUIsRUFBRSxDQUFDLEtBQUssR0FBRyxTQUFTLENBQUMscUJBQXFCLEVBQUUsQ0FBQyxLQUFLLENBQUMsQ0FBQztJQUN2RyxDQUFDO0lBRU8saUJBQWlCO1FBQ3JCLElBQUksQ0FBQyxXQUFXLENBQUMsU0FBUyxDQUFDLGtCQUFrQixDQUFDLEVBQUUsQ0FBQyxDQUFDO1FBQ2xELElBQUksQ0FBQyxXQUFXLENBQUMsU0FBUyxDQUFDLGVBQWUsQ0FBQyxFQUFFLENBQUMsQ0FBQztRQUMvQyxJQUFJLENBQUMsV0FBVyxDQUFDLFNBQVMsQ0FBQyxlQUFlLENBQUMsRUFBRSxDQUFDLENBQUM7UUFDL0MsSUFBSSxDQUFDLFdBQVcsQ0FBQyxTQUFTLENBQUMsbUJBQW1CLENBQUMsRUFBRSxDQUFDLENBQUM7SUFDdkQsQ0FBQztJQUVEOzs7O09BSUc7SUFDSyxjQUFjO1FBQ2xCLDBGQUEwRjtRQUMxRixJQUFJLFFBQVEsR0FBRyxHQUFRLEVBQUU7WUFDckIsSUFBSSxDQUFDLGFBQWEsQ0FBQyxXQUFXLEdBQUcsSUFBSSxDQUFDLFdBQVcsQ0FBQyxTQUFTLENBQUMsY0FBYyxFQUFFLENBQUM7WUFDN0UsSUFBSSxDQUFDLGFBQWEsQ0FBQyxTQUFTLEdBQUcsSUFBSSxDQUFDLFdBQVcsQ0FBQyxTQUFTLENBQUMsV0FBVyxFQUFFLENBQUM7WUFDeEUsSUFBSSxDQUFDLGFBQWEsQ0FBQyxVQUFVLEdBQUcsSUFBSSxDQUFDLFdBQVcsQ0FBQyxTQUFTLENBQUMsbUJBQW1CLEVBQUUsQ0FBQztZQUNqRixPQUFPLElBQUksQ0FBQyxhQUFhLENBQUM7UUFDOUIsQ0FBQyxDQUFDO1FBQ0YsSUFBSSxLQUFLLEdBQUcsR0FBWSxFQUFFO1lBQ3RCLE9BQU8sSUFBSSxDQUFDLGdCQUFnQixLQUFLLEtBQUssQ0FBQztRQUMzQyxDQUFDLENBQUM7UUFDRixPQUFPLElBQUksQ0FBQyxJQUFJLENBQUMsS0FBSyxFQUFFLFFBQVEsQ0FBQyxDQUFDO0lBQ3RDLENBQUM7SUFFRDs7OztPQUlHO0lBQ0ssY0FBYyxDQUFDLE1BQXdCO1FBQzNDLElBQUksT0FBTyxDQUFDLE1BQU0sQ0FBQyxLQUFLLFdBQVcsSUFBSSxDQUFDLE1BQU0sQ0FBQyxjQUFjLENBQUMsYUFBYSxDQUFDO1lBQUUsT0FBTztRQUVyRixJQUFJLFFBQVEsR0FBRyxHQUFTLEVBQUU7WUFDdEIsSUFBSSxDQUFDLGdCQUFnQixHQUFHLElBQUksQ0FBQztZQUM3QixJQUFJLE1BQU0sQ0FBQyxXQUFXLENBQUMsTUFBTSxLQUFLLENBQUMsRUFBRTtnQkFDakMsSUFBSSxDQUFDLGdCQUFnQixHQUFHLEtBQUssQ0FBQztnQkFDOUIsSUFBSSxDQUFDLFlBQVksRUFBRSxDQUFDO2dCQUNwQixPQUFPO2FBQ1Y7WUFDRCxJQUFJLENBQUMsYUFBYSxHQUFHLE1BQU0sQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLGFBQWEsRUFBRSxNQUFNLENBQUMsQ0FBQztZQUMvRCxJQUFJLENBQUMsV0FBVyxDQUFDLFNBQVMsQ0FBQyxjQUFjLENBQUMsTUFBTSxDQUFDLFdBQVcsQ0FBQyxDQUFDO1lBQzlELElBQUksQ0FBQyxXQUFXLENBQUMsU0FBUyxDQUFDLFlBQVksQ0FBQyxNQUFNLENBQUMsU0FBUyxJQUFJLEtBQUssQ0FBQyxDQUFDO1lBQ25FLElBQUksQ0FBQyxXQUFXLENBQUMsU0FBUyxDQUFDLG1CQUFtQixDQUFDLE1BQU0sQ0FBQyxVQUFVLElBQUksRUFBRSxDQUFDLENBQUM7WUFDeEUsSUFBSSxDQUFDLGdCQUFnQixHQUFHLEtBQUssQ0FBQztZQUU5QixLQUFLLENBQUMsR0FBRyxDQUFDLENBQUMsU0FBUyxDQUFDLEdBQVMsRUFBRTtnQkFDNUIsSUFBSSxDQUFDLGdCQUFnQixFQUFFLENBQUM7Z0JBQ3hCLElBQUksQ0FBQyxZQUFZLEVBQUUsQ0FBQztZQUN4QixDQUFDLENBQUMsQ0FBQztRQUNQLENBQUMsQ0FBQztRQUNGLElBQUksS0FBSyxHQUFHLEdBQVksRUFBRTtZQUN0QixPQUFPLElBQUksQ0FBQyxNQUFNLElBQUksSUFBSSxDQUFDLE1BQU0sQ0FBQyxNQUFNLEdBQUcsQ0FBQyxDQUFDO1FBQ2pELENBQUMsQ0FBQztRQUNGLElBQUksQ0FBQyxJQUFJLENBQUMsS0FBSyxFQUFFLFFBQVEsQ0FBQyxDQUFDO0lBQy9CLENBQUM7SUFFRDs7OztPQUlHO0lBQ0ssSUFBSSxDQUFDLE1BQWdCLEVBQUUsR0FBYSxFQUFFLGFBQWEsR0FBRyxDQUFDO1FBQzNELElBQUksQ0FBQyxNQUFNLEVBQUUsSUFBSSxJQUFJLENBQUMsYUFBYSxDQUFDLFVBQVUsQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFDLENBQUMsSUFBSSxhQUFhLEtBQUssR0FBRyxFQUFFO1lBQ3hGLElBQUksYUFBYSxLQUFLLEdBQUc7Z0JBQUUsT0FBTyxDQUFDLEdBQUcsQ0FBQywrQkFBK0IsRUFBRSxHQUFHLENBQUMsQ0FBQztZQUM3RSxPQUFPLEdBQUcsRUFBRSxDQUFDO1NBQ2hCO2FBQU07WUFDSCxLQUFLLENBQUMsRUFBRSxDQUFDLENBQUMsU0FBUyxDQUFDLEdBQVMsRUFBRTtnQkFDM0IsYUFBYSxFQUFFLENBQUM7Z0JBQ2hCLElBQUksQ0FBQyxJQUFJLENBQUMsTUFBTSxFQUFFLEdBQUcsRUFBRSxhQUFhLENBQUMsQ0FBQztZQUMxQyxDQUFDLENBQUMsQ0FBQztTQUNOO0lBQ0wsQ0FBQztJQUVPLGdCQUFnQixDQUFDLGFBQWE7UUFDbEMsT0FBTyxDQUNILE9BQU8sYUFBYSxDQUFDLE9BQU8sQ0FBQyxLQUFLLFdBQVc7WUFDN0MsYUFBYSxDQUFDLE9BQU8sQ0FBQyxLQUFLLElBQUk7WUFDL0IsT0FBTyxhQUFhLENBQUMsYUFBYSxDQUFDLEtBQUssV0FBVztZQUNuRCxhQUFhLENBQUMsYUFBYSxDQUFDLEtBQUssSUFBSSxDQUN4QyxDQUFDO0lBQ04sQ0FBQztJQUVEOzs7O09BSUc7SUFDSyxjQUFjLENBQUMsUUFBaUIsSUFBSTtRQUN4QyxJQUFJLFlBQVksR0FBRyxHQUFTLEVBQUU7WUFDMUIsSUFBSSxLQUFLLEtBQUssSUFBSSxFQUFFO2dCQUNoQixJQUFJLENBQUMsYUFBYSxDQUFDLE9BQU8sQ0FBQyxDQUFDLFNBQVMsR0FBRyxJQUFJLENBQUMsYUFBYSxDQUFDLE9BQU8sQ0FBQyxDQUFDLFNBQVMsQ0FBQyxPQUFPLENBQUMsV0FBVyxFQUFFLEVBQUUsQ0FBQyxDQUFDO2dCQUN2RyxLQUFLLElBQUksQ0FBQyxHQUFXLENBQUMsRUFBRSxDQUFDLEdBQUcsSUFBSSxDQUFDLGFBQWEsQ0FBQyxhQUFhLENBQUMsQ0FBQyxNQUFNLEVBQUUsRUFBRSxDQUFDLEVBQUU7b0JBQ3ZFLElBQUksQ0FBQyxhQUFhLENBQUMsYUFBYSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsU0FBUyxHQUFHLElBQUksQ0FBQyxhQUFhLENBQUMsYUFBYSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDLE9BQU8sQ0FBQyxXQUFXLEVBQUUsRUFBRSxDQUFDLENBQUM7aUJBQzVIO2dCQUNELElBQUksQ0FBQyxjQUFjLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxLQUFLLElBQUksSUFBSSxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDO2dCQUNqRyxPQUFPO2FBQ1Y7WUFFRCxJQUFJLElBQUksQ0FBQyxhQUFhLENBQUMsT0FBTyxDQUFDO2dCQUMzQixJQUFJLENBQUMsYUFBYSxDQUFDLE9BQU8sQ0FBQyxDQUFDLFNBQVM7Z0JBQ3JDLElBQUksQ0FBQyxhQUFhLENBQUMsT0FBTyxDQUFDLENBQUMsU0FBUyxDQUFDLE9BQU8sQ0FBQyxRQUFRLENBQUMsS0FBSyxDQUFDLENBQUMsRUFDaEU7Z0JBQ0UsSUFBSSxDQUFDLGFBQWEsQ0FBQyxPQUFPLENBQUMsQ0FBQyxTQUFTLElBQUksU0FBUyxDQUFDO2dCQUNuRCxLQUFLLElBQUksQ0FBQyxHQUFXLENBQUMsRUFBRSxDQUFDLEdBQUcsSUFBSSxDQUFDLGFBQWEsQ0FBQyxhQUFhLENBQUMsQ0FBQyxNQUFNLEVBQUUsRUFBRSxDQUFDLEVBQUU7b0JBQ3ZFLElBQUksQ0FBQyxhQUFhLENBQUMsYUFBYSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsU0FBUyxJQUFJLFNBQVMsQ0FBQztpQkFDL0Q7YUFDSjtZQUNELElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxLQUFLLENBQUMsQ0FBQztZQUU5QixJQUFJLENBQUMsY0FBYyxDQUFDO2dCQUNoQixhQUFhLEVBQUUsRUFBRTtnQkFDakIsV0FBVyxFQUFFLEtBQUs7Z0JBQ2xCLFlBQVksRUFBRSxFQUFFO2FBQ25CLENBQUMsQ0FBQztZQUNILElBQUksQ0FBQyxpQkFBaUIsRUFBRSxDQUFDO1FBQzdCLENBQUMsQ0FBQztRQUNGLElBQUksS0FBSyxHQUFHLEdBQVksRUFBRTtZQUN0QixzSEFBc0g7WUFDdEgsSUFBSSxJQUFJLENBQUMsTUFBTSxDQUFDLEtBQUs7Z0JBQ2pCLElBQUksQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLFNBQVM7Z0JBQzNCLElBQUksQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLFNBQVMsQ0FBQyxJQUFJO2dCQUNoQyxJQUFJLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxTQUFTLENBQUMsSUFBSSxLQUFLLE1BQU0sRUFDN0M7Z0JBQ0UsSUFBSSxlQUFlLEdBQVksSUFBSSxDQUFDLGdCQUFnQixDQUFDLElBQUksQ0FBQyxhQUFhLENBQUMsQ0FBQztnQkFDekUsSUFBSSxlQUFlLEtBQUssSUFBSTtvQkFBRSxPQUFPLGVBQWUsQ0FBQztnQkFFckQsSUFBSSxXQUFXLEdBQVcsR0FBRyxHQUFHLElBQUksQ0FBQyxNQUFNLEdBQUcseUJBQXlCLENBQUM7Z0JBQ3hFLElBQUksQ0FBQyxhQUFhLENBQUMsT0FBTyxDQUFDLEdBQUcsSUFBSSxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsYUFBYSxDQUFDLGFBQWEsQ0FBQyxXQUFXLEdBQUcsdUJBQXVCLENBQUMsQ0FBQztnQkFDbkgsSUFBSSxDQUFDLGFBQWEsQ0FBQyxhQUFhLENBQUMsR0FBRyxJQUFJLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxhQUFhLENBQUMsZ0JBQWdCLENBQUMsV0FBVyxHQUFHLGtCQUFrQixDQUFDLENBQUM7Z0JBQ3ZILE9BQU8sSUFBSSxDQUFDLGdCQUFnQixDQUFDLElBQUksQ0FBQyxhQUFhLENBQUMsQ0FBQzthQUNwRDtpQkFBTTtnQkFDSCxPQUFPLElBQUksQ0FBQzthQUNmO1FBQ0wsQ0FBQyxDQUFDO1FBQ0YsSUFBSSxDQUFDLElBQUksQ0FBQyxLQUFLLEVBQUUsWUFBWSxDQUFDLENBQUM7SUFDbkMsQ0FBQztJQUdEOzs7T0FHRztJQUNLLGNBQWMsQ0FBQyxLQUFjO1FBQ2pDLElBQUksSUFBSSxDQUFDLGFBQWEsQ0FBQyxVQUFVLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxFQUFFO1lBQ2pELEtBQUssQ0FBQyxFQUFFLENBQUMsQ0FBQyxTQUFTLENBQUMsR0FBUyxFQUFFO2dCQUMzQixJQUFJLENBQUMsV0FBVyxDQUFDLEdBQUcsQ0FBQyxhQUFhLENBQUMsS0FBSyxDQUFDLENBQUM7WUFDOUMsQ0FBQyxDQUFDLENBQUM7U0FDTjtJQUNMLENBQUM7SUFFRDs7O09BR0c7SUFDSyxZQUFZLENBQUMsT0FBaUI7UUFDbEMsSUFBSSxPQUFPLE9BQU8sS0FBSyxXQUFXLEVBQUU7WUFDaEMsT0FBTyxHQUFHLEtBQUssQ0FBQztZQUNoQixJQUFJLElBQUksQ0FBQyxNQUFNLENBQUMsS0FBSyxJQUFJLElBQUksQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLEtBQUssSUFBSSxJQUFJLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsV0FBVyxFQUFFO2dCQUNyRixPQUFPLEdBQUcsSUFBSSxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLFdBQVcsQ0FBQzthQUNqRDtTQUNKO1FBQ0QsSUFBSSxJQUFJLENBQUMsYUFBYSxDQUFDLFVBQVUsQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFDLEVBQUU7WUFDakQsS0FBSyxDQUFDLEVBQUUsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxHQUFTLEVBQUU7Z0JBQzNCLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxXQUFXLENBQUMsR0FBRyxDQUFDLFNBQVMsRUFBRSxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFDLEdBQUcsQ0FBQyxXQUFXLEVBQUUsQ0FBQztnQkFDbEYsSUFBSSxDQUFDLFlBQVksRUFBRSxDQUFDO1lBQ3hCLENBQUMsQ0FBQyxDQUFDO1NBQ047SUFDTCxDQUFDO0lBRUQ7Ozs7OztPQU1HO0lBQ0ssaUJBQWlCLENBQUMsV0FBb0IsS0FBSztRQUMvQyxJQUFJLENBQUMsV0FBVyxDQUFDLFNBQVMsQ0FBQyxZQUFZLENBQUMsUUFBUSxDQUFDLENBQUM7SUFDdEQsQ0FBQztJQUVELHNCQUFzQjtJQUN0Qjs7Ozs7T0FLRztJQUNLLGdCQUFnQixDQUFDLFFBQWM7UUFDbkMsSUFBSSxRQUFRLEdBQVksS0FBSyxDQUFDO1FBQzlCLElBQUksQ0FBQyxRQUFRO1lBQUUsUUFBUSxHQUFHLElBQUksQ0FBQyxXQUFXLENBQUMsU0FBUyxDQUFDLHNCQUFzQixFQUFFLENBQUM7UUFDOUUsUUFBUSxDQUFDLE9BQU8sQ0FBQyxDQUFDLE1BQVcsRUFBRSxFQUFFO1lBQzdCLElBQUksQ0FBQyxVQUFVLENBQUMsTUFBTSxDQUFDLENBQUM7WUFDeEIsSUFBSSxTQUFTLEdBQUcsTUFBTSxDQUFDLFNBQVMsRUFBRSxDQUFDO1lBQ25DLElBQUksU0FBUyxDQUFDLGdCQUFnQixFQUFFO2dCQUM1QixJQUFJLENBQUMsVUFBVSxDQUFDLFNBQVMsQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFBO2FBQzlDO2lCQUFNO2dCQUNILElBQUksTUFBTSxDQUFDLE1BQU0sRUFBRTtvQkFDZixRQUFRLEdBQUcsSUFBSSxDQUFDO29CQUNoQixJQUFJLENBQUMsVUFBVSxDQUFDLE1BQU0sQ0FBQyxNQUFNLEVBQUUsS0FBSyxDQUFDLENBQUM7b0JBQ3RDLE1BQU0sQ0FBQyxNQUFNLENBQUMsTUFBTSxHQUFHLE1BQU0sQ0FBQztvQkFDOUIsTUFBTSxDQUFDLE1BQU0sR0FBRyxNQUFNLENBQUM7b0JBQ3ZCLFNBQVMsQ0FBQyxNQUFNLEdBQUcsTUFBTSxDQUFDO2lCQUM3QjthQUNKO1FBQ0wsQ0FBQyxDQUFDLENBQUM7UUFDSCxJQUFJLFFBQVE7WUFBRSxJQUFJLENBQUMsYUFBYSxDQUFDLElBQUksQ0FBQyxDQUFDO0lBQzNDLENBQUM7SUFFTyxVQUFVLENBQUMsT0FBWSxFQUFFLGVBQXdCLElBQUk7UUFDekQsSUFBSSxZQUFZLEVBQUU7WUFDZCxJQUFJLFNBQVMsR0FBRyxPQUFPLENBQUMsU0FBUyxFQUFFLENBQUM7WUFDcEMsU0FBUyxDQUFDLGVBQWUsR0FBRyxJQUFJLENBQUMsdUJBQXVCLENBQUM7WUFDekQsU0FBUyxDQUFDLFlBQVksR0FBRyxJQUFJLENBQUMsdUJBQXVCLENBQUM7WUFDdEQsU0FBUyxDQUFDLFVBQVUsR0FBRyxJQUFJLENBQUMsdUJBQXVCLENBQUM7U0FDdkQ7UUFDRCxJQUFJLE9BQU8sQ0FBQyxTQUFTLEVBQUU7WUFDbkIsT0FBTyxDQUFDLFNBQVMsQ0FBQyxDQUFDLElBQUksQ0FBQyx1QkFBdUIsQ0FBQyxDQUFDO1NBQ3BEO2FBQU07WUFDSCxPQUFPLENBQUMsTUFBTSxHQUFHLENBQUMsSUFBSSxDQUFDLHVCQUF1QixDQUFDO1NBQ2xEO1FBQ0QsT0FBTyxDQUFDLFlBQVksR0FBRyxJQUFJLENBQUMsdUJBQXVCLENBQUM7UUFDcEQsT0FBTyxDQUFDLFVBQVUsR0FBRyxJQUFJLENBQUMsdUJBQXVCLENBQUM7SUFDdEQsQ0FBQztJQUNELHNCQUFzQjtJQUV0Qix3R0FBd0c7SUFDeEcsdUNBQXVDO0lBQ3ZDLHdHQUF3RztJQUNoRyxlQUFlLENBQUMsWUFBMEI7UUFDOUMsSUFBSSxZQUFZLENBQUMsY0FBYyxDQUFDLHdCQUF3QixDQUFDO1lBQUUsSUFBSSxDQUFDLHVCQUF1QixHQUFHLFlBQVksQ0FBQyxzQkFBc0IsQ0FBQztRQUM5SCxJQUFJLENBQUMsVUFBVSxHQUFrQixJQUFJLENBQUMsT0FBTyxDQUFDLG9CQUFvQixFQUFFLENBQUM7UUFDckUsSUFBSSxDQUFDLFdBQVcsR0FBRyxJQUFJLENBQUMsYUFBYSxDQUFDLG1CQUFtQixDQUFDLFlBQVksRUFBRSxJQUFJLENBQUMsVUFBVSxDQUFDLENBQUM7UUFDekYsSUFBSSxDQUFDLFdBQVcsQ0FBQyxPQUFPLENBQUMsUUFBUSxDQUFDLEdBQUcsSUFBSSxDQUFDLE1BQU0sQ0FBQztRQUNqRCxJQUFJLENBQUMsV0FBVyxDQUFDLHNCQUFzQixHQUFHLEtBQUssQ0FBQztRQUNoRCxJQUFJLENBQUMsV0FBVyxDQUFDLHVCQUF1QixHQUFHLENBQUMsTUFBVyxFQUFRLEVBQUU7WUFDN0QsSUFBSSxDQUFDLGdCQUFnQixDQUFDLE1BQU0sQ0FBQyxPQUFPLENBQUMsQ0FBQztZQUN0QyxJQUFJLENBQUMsWUFBWSxFQUFFLENBQUM7UUFDeEIsQ0FBQyxDQUFBO1FBQ0QsSUFBSSxDQUFDLGFBQWEsQ0FBQyxjQUFjLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxDQUFDO0lBQ3hELENBQUM7SUFFTyxhQUFhLENBQUMsYUFBa0M7UUFDcEQsSUFBSSxDQUFDLGFBQWEsQ0FBQyxZQUFZLENBQUMsYUFBYSxFQUFFLElBQUksQ0FBQyxNQUFNLEVBQUUsSUFBSSxDQUFDLHVCQUF1QixDQUFDLENBQUM7UUFDMUYsSUFBSSxDQUFDLGFBQWEsRUFBRSxDQUFDO0lBQ3pCLENBQUM7SUFFTyxvQkFBb0IsQ0FBQyxXQUFvQixJQUFJO1FBQ2pELElBQUksSUFBSSxDQUFDLGFBQWEsQ0FBQyxVQUFVLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxFQUFFO1lBQ2pELElBQUksQ0FBQyx1QkFBdUIsR0FBRyxRQUFRLENBQUM7WUFFeEMsSUFBSSxDQUFDLGFBQWEsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUM7WUFDaEMsSUFBSSxJQUFJLENBQUMsTUFBTSxDQUFDLFFBQVEsS0FBSyxRQUFRLElBQUksSUFBSSxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsU0FBUyxDQUFDLElBQUksS0FBSyxPQUFPLEVBQUU7Z0JBQ25GLElBQUksQ0FBQyxjQUFjLENBQUMsSUFBSSxDQUFDLGFBQWEsQ0FBQyxDQUFDO2FBQzNDO1lBRUQsSUFBSSxDQUFDLFlBQVksRUFBRSxDQUFDO1NBQ3ZCO0lBQ0wsQ0FBQztJQUVPLFdBQVcsQ0FBQyxRQUFvQixFQUFFLG9CQUE2QixJQUFJO1FBQ3ZFLHdGQUF3RjtRQUN4RixJQUFJLENBQUMsYUFBYSxDQUFDLHVCQUF1QixDQUFDLFFBQVEsRUFBRSxJQUFJLENBQUMsTUFBTSxFQUFFLElBQUksQ0FBQyxNQUFNLEVBQUUsSUFBSSxDQUFDLFdBQVcsQ0FBQyxDQUFDO1FBRWpHLElBQUksaUJBQWlCLEVBQUU7WUFDbkIsSUFBSSxDQUFDLGFBQWEsQ0FBQyxVQUFVLENBQUMsUUFBUSxDQUFDLENBQUM7U0FDM0M7UUFFRCxJQUFJLElBQUksQ0FBQyxhQUFhLENBQUMsaUJBQWlCLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxRQUFRLENBQUMsSUFBSSxJQUFJLENBQUMsYUFBYSxDQUFDLFVBQVUsQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFDLEVBQUU7WUFDL0csSUFBSSxDQUFDLHlCQUF5QixFQUFFLENBQUM7U0FDcEM7UUFFRCxLQUFLLEVBQUUsQ0FBQyxTQUFTLENBQUMsR0FBUyxFQUFFO1lBQ3pCLElBQUksQ0FBQyxnQkFBZ0IsRUFBRSxDQUFDO1lBQ3hCLElBQUksQ0FBQyxxQkFBcUIsRUFBRSxDQUFDO1FBQ2pDLENBQUMsQ0FBQyxDQUFDO0lBQ1AsQ0FBQztJQUVELHdHQUF3RztJQUN4RyxzQ0FBc0M7SUFDdEMsd0dBQXdHO0lBQ2hHLG1CQUFtQixDQUFJLFVBQWtCLEVBQUUsaUJBQW9CO1FBQ25FLFFBQVEsVUFBVSxFQUFFO1lBQ2hCLEtBQUssWUFBWSxDQUFDO1lBQ2xCLEtBQUssV0FBVyxDQUFDO1lBQ2pCLEtBQUssT0FBTyxDQUFDO1lBQ2IsS0FBSyxRQUFRO2dCQUNULElBQUksQ0FBQyxxQkFBcUIsQ0FBSSxpQkFBaUIsQ0FBQyxDQUFDO2dCQUNqRCxNQUFNO1lBQ1Y7Z0JBQ0ksT0FBTyxDQUFDLEtBQUssQ0FBQyw0Q0FBNEMsRUFBRSxVQUFVLENBQUMsQ0FBQztTQUMvRTtJQUNMLENBQUM7SUFFTyxxQkFBcUIsQ0FBSSxPQUFVO1FBQ3ZDLElBQUksQ0FBQyxjQUFjLENBQUMsZ0JBQWdCLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxFQUFFLEVBQUUsT0FBTyxDQUFDLENBQUM7SUFDbEUsQ0FBQztJQUVPLDJCQUEyQjtRQUMvQixJQUFJLENBQUMsY0FBYyxDQUFDLFlBQVksQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLEVBQUUsQ0FBQyxDQUFDO0lBQ3JELENBQUM7SUFFTyx3QkFBd0I7UUFDNUIsSUFBSSxDQUFDLGdCQUFnQixDQUFDLGNBQWMsR0FBRyxJQUFJLENBQUMsY0FBYyxDQUFDLGtCQUFrQixDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsRUFBRSxDQUFDLENBQUMsU0FBUyxDQUFDLENBQUMsUUFBaUIsRUFBUSxFQUFFO1lBQ2hJLElBQUksQ0FBQyxxQkFBcUIsQ0FBQyxRQUFRLENBQUMsQ0FBQztRQUN6QyxDQUFDLENBQUMsQ0FBQztRQUVILElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxlQUFlLEdBQUcsSUFBSSxDQUFDLGNBQWMsQ0FBQyxjQUFjLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxFQUFFLENBQUMsQ0FBQyxTQUFTLENBQUMsQ0FBQyxXQUFpQyxFQUFRLEVBQUU7WUFDN0ksSUFBSSxDQUFDLG9CQUFvQixDQUFDLFdBQVcsQ0FBQyxDQUFDO1FBQzNDLENBQUMsQ0FBQyxDQUFDO1FBRUgsSUFBSSxDQUFDLGdCQUFnQixDQUFDLGFBQWEsR0FBRyxJQUFJLENBQUMsY0FBYyxDQUFDLG9CQUFvQixDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsRUFBRSxDQUFDLENBQUMsU0FBUyxDQUFDLENBQUMsS0FBdUMsRUFBUSxFQUFFO1lBQ3ZKLElBQUksS0FBSyxDQUFDLE1BQU0sS0FBSyxRQUFRLEVBQUU7Z0JBQzNCLElBQUksTUFBTSxHQUFXLENBQUMsT0FBTyxJQUFJLENBQUMsTUFBTSxDQUFDLFFBQVEsS0FBSyxXQUFXLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQztnQkFDakcsSUFBSSxDQUFDLHNCQUFzQixDQUFDLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUM7Z0JBQ3JELElBQUksQ0FBQyxxQkFBcUIsRUFBRSxDQUFDO2FBQ2hDO1FBQ0wsQ0FBQyxDQUFDLENBQUM7SUFDUCxDQUFDO0lBRUQsd0dBQXdHO0lBQ3hHLDBDQUEwQztJQUMxQyx3R0FBd0c7SUFDaEcscUJBQXFCLENBQUMsUUFBaUIsRUFBRSxVQUFvQjtRQUNqRSxJQUFJLFdBQVcsR0FBVyxDQUFDLE9BQU8sVUFBVSxLQUFLLFdBQVcsSUFBSSxVQUFVLENBQUMsQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUM7UUFDaEcsSUFBSSxPQUFPLFFBQVEsS0FBSyxXQUFXLEVBQUU7WUFDakMsV0FBVyxHQUFHLFFBQVEsQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDO1NBQ2xDO1FBRUQsSUFBSSxlQUFlLEdBQWdDLElBQUksMkJBQTJCLEVBQUUsQ0FBQztRQUVyRixlQUFlLENBQUMsV0FBVyxHQUFHLFdBQVcsQ0FBQztRQUMxQyxlQUFlLENBQUMsYUFBYSxHQUFHLElBQUksQ0FBQyxhQUFhLENBQUMscUJBQXFCLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxPQUFPLEVBQUUsSUFBSSxDQUFDLE1BQU0sQ0FBQyxTQUFTLENBQUMsS0FBSyxFQUFFLElBQUksQ0FBQyxNQUFNLENBQUMsU0FBUyxDQUFDLFNBQVMsRUFBRSxJQUFJLENBQUMsTUFBTSxDQUFDLFFBQVEsQ0FBQyxDQUFDO1FBQ3ZMLG1GQUFtRjtRQUVuRixJQUFJLENBQUMsbUJBQW1CLENBQThCLFdBQVcsRUFBRSxlQUFlLENBQUMsQ0FBQztJQUN4RixDQUFDO0lBRU8sd0JBQXdCO1FBQzVCLElBQUksQ0FBQyxxQkFBcUIsQ0FBQyxTQUFTLEVBQUUsSUFBSSxDQUFDLENBQUM7SUFDaEQsQ0FBQztJQUVELHdHQUF3RztJQUN4RyxtQkFBbUI7SUFDbkIsd0dBQXdHO0lBQ2hHLG9CQUFvQixDQUFDLFdBQWlDO1FBQzFELElBQUksV0FBVyxHQUE0QixJQUFJLHVCQUF1QixFQUFFLENBQUM7UUFFekUsV0FBVyxDQUFDLEtBQUssR0FBRyxXQUFXLENBQUMsS0FBSyxDQUFDO1FBQ3RDLFdBQVcsQ0FBQyxLQUFLLEdBQUcsV0FBVyxDQUFDLEtBQUssQ0FBQztRQUN0QyxXQUFXLENBQUMsV0FBVyxHQUFHLFdBQVcsQ0FBQyxXQUFXLENBQUM7UUFDbEQsV0FBVyxDQUFDLFFBQVEsR0FBRyxXQUFXLENBQUMsUUFBUSxDQUFDO1FBQzVDLFdBQVcsQ0FBQyxLQUFLLEdBQUcsV0FBVyxDQUFDLElBQUksQ0FBQztRQUVyQyxJQUFJLENBQUMsbUJBQW1CLENBQTBCLE9BQU8sRUFBRSxXQUFXLENBQUMsQ0FBQztJQUM1RSxDQUFDO0lBRU8scUJBQXFCO1FBQ3pCLElBQUksV0FBVyxHQUE0QixJQUFJLHVCQUF1QixFQUFFLENBQUM7UUFDekUsSUFBSSxDQUFDLG1CQUFtQixDQUEwQixPQUFPLEVBQUUsV0FBVyxDQUFDLENBQUM7SUFDNUUsQ0FBQztJQUVPLHNCQUFzQixDQUFDLFNBQXdCO1FBQ25ELElBQUksUUFBUSxHQUFXLENBQUMsT0FBTyxJQUFJLENBQUMsTUFBTSxDQUFDLFFBQVEsS0FBSyxXQUFXLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQztRQUVuRyxLQUFLLElBQUksQ0FBQyxHQUFXLENBQUMsRUFBRSxDQUFDLEdBQUcsU0FBUyxDQUFDLE1BQU0sRUFBRSxFQUFFLENBQUMsRUFBRTtZQUMvQyxLQUFLLElBQUksQ0FBQyxHQUFXLENBQUMsRUFBRSxDQUFDLEdBQUcsSUFBSSxDQUFDLEdBQUcsQ0FBQyxNQUFNLEVBQUUsRUFBRSxDQUFDLEVBQUU7Z0JBQzlDLElBQUksU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsRUFBRSxLQUFLLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsUUFBUSxFQUFFLEVBQUU7b0JBQzlELElBQUksQ0FBQyxHQUFHLENBQUMsTUFBTSxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQztvQkFDdEIsTUFBTTtpQkFDVDthQUNKO1NBQ0o7SUFDTCxDQUFDO0lBRUQsd0dBQXdHO0lBQ3hHLG1DQUFtQztJQUNuQyx3R0FBd0c7SUFDaEcsZ0JBQWdCO1FBQ3BCLElBQUksSUFBSSxDQUFDLGFBQWEsQ0FBQyxVQUFVLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxFQUFFO1lBQ2pELElBQUksQ0FBQyxXQUFXLENBQUMsR0FBRyxDQUFDLHVCQUF1QixDQUFDLElBQUksQ0FBQyxDQUFDO1lBQ25ELElBQUksQ0FBQyxXQUFXLENBQUMsR0FBRyxDQUFDLGNBQWMsQ0FBQyxJQUFJLENBQUMsQ0FBQztZQUMxQyxJQUFJLENBQUMsV0FBVyxDQUFDLEdBQUcsQ0FBQyxZQUFZLENBQUMsSUFBSSxDQUFDLENBQUM7WUFFeEMsSUFBSSxPQUFPLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxhQUFhLEtBQUssV0FBVyxFQUFFO2dCQUM1RCxJQUFJLENBQUMsZ0JBQWdCLENBQUMsYUFBYSxDQUFDLFdBQVcsRUFBRSxDQUFDO2FBQ3JEO1NBQ0o7SUFDTCxDQUFDO0lBRU8sNkJBQTZCO1FBQ2pDLElBQUksVUFBVSxHQUEwQjtZQUNwQyxPQUFPLEVBQUUsQ0FBQyxPQUFpQyxFQUFRLEVBQUU7Z0JBQ2pELElBQUksQ0FBQyxtQkFBbUIsQ0FBQyxJQUFJLENBQUMsQ0FBQztnQkFFL0IsSUFBSSxPQUFPLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxhQUFhLEtBQUssV0FBVyxFQUFFO29CQUM1RCxJQUFJLENBQUMsZ0JBQWdCLENBQUMsYUFBYSxDQUFDLFdBQVcsRUFBRSxDQUFDO2lCQUNyRDtnQkFDRCxJQUFJLENBQUMsZ0JBQWdCLENBQUMsYUFBYSxHQUFHLElBQUksQ0FBQyx1QkFBdUIsQ0FBQyxPQUFPLENBQUMsQ0FBQyxTQUFTLENBQUMsQ0FBQyxTQUFpQyxFQUFRLEVBQUU7b0JBQzlILE9BQU8sQ0FBQyxlQUFlLENBQUMsU0FBUyxDQUFDLElBQUksRUFBRSxTQUFTLENBQUMsS0FBSyxDQUFDLENBQUM7b0JBQ3pELElBQUksQ0FBQyxtQkFBbUIsQ0FBQyxLQUFLLENBQUMsQ0FBQztnQkFDcEMsQ0FBQyxDQUFDLENBQUM7WUFDUCxDQUFDO1NBQ0osQ0FBQztRQUVGLElBQUksQ0FBQyxXQUFXLENBQUMsR0FBRyxDQUFDLHVCQUF1QixDQUFDLFVBQVUsQ0FBQyxDQUFDO0lBQzdELENBQUM7SUFFTyx1QkFBdUIsQ0FBQyxpQkFBMkM7UUFDdkUsT0FBTyxJQUFJLFVBQVUsQ0FBeUIsQ0FBQyxTQUE2QyxFQUFRLEVBQUU7WUFDbEcsUUFBUSxJQUFJLENBQUMsTUFBTSxDQUFDLFFBQVEsRUFBRTtnQkFDMUIsS0FBSyxVQUFVLENBQUM7Z0JBQ2hCLEtBQUssU0FBUztvQkFDYSxJQUFJLENBQUMsYUFBYyxDQUFDLHNCQUFzQixDQUFDLGlCQUFpQixDQUFDLE9BQU8sRUFBRSxJQUFJLENBQUMsV0FBVyxDQUFDLE9BQU8sQ0FBQyxLQUFLLEVBQUUsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxDQUFDLFNBQWlDLEVBQVEsRUFBRTt3QkFDakwsU0FBUyxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsQ0FBQzt3QkFDMUIsU0FBUyxDQUFDLFFBQVEsRUFBRSxDQUFDO29CQUN6QixDQUFDLENBQUMsQ0FBQztvQkFFSCxNQUFNO2dCQUNWLEtBQUssUUFBUTtvQkFDVCxJQUFJLFlBQVksR0FBMkIsSUFBSSxzQkFBc0IsQ0FBQyxpQkFBaUIsQ0FBQyxPQUFPLEVBQUUsU0FBUyxDQUFDLENBQUM7b0JBQzVHLElBQUksQ0FBQyxtQkFBbUIsQ0FBeUIsWUFBWSxFQUFFLFlBQVksQ0FBQyxDQUFDO29CQUU3RSxNQUFNO2dCQUNWO29CQUNJLE9BQU8sQ0FBQyxLQUFLLENBQUMsOENBQThDLEVBQUUsSUFBSSxDQUFDLE1BQU0sQ0FBQyxRQUFRLENBQUMsQ0FBQztvQkFDcEYsU0FBUyxDQUFDLFFBQVEsRUFBRSxDQUFDO2FBQzVCO1FBQ0wsQ0FBQyxDQUFDLENBQUM7SUFDUCxDQUFDO0lBRUQsd0dBQXdHO0lBQ3hHLGlCQUFpQjtJQUNqQix3R0FBd0c7SUFDaEcsY0FBYztRQUNsQixJQUFJLE9BQU8sSUFBSSxDQUFDLEdBQUcsS0FBSyxXQUFXLEVBQUU7WUFDakMsSUFBSSxTQUFTLEdBQVE7Z0JBQ2pCLGlDQUFpQztnQkFDakMsS0FBSyxFQUFFLElBQUksQ0FBQyxjQUFjO2dCQUMxQixFQUFFLEVBQUUsSUFBSSxDQUFDLE1BQU0sQ0FBQyxFQUFFO2dCQUNsQixJQUFJLEVBQUUsSUFBSSxDQUFDLEdBQUc7Z0JBQ2QsT0FBTyxFQUFFLElBQUksQ0FBQyxNQUFNO2FBQ3ZCLENBQUM7WUFFRixJQUFJLENBQUMsYUFBYSxDQUFDLHFCQUFxQixDQUFDLElBQUksQ0FBQyxHQUFHLEVBQUUsU0FBUyxDQUFDLENBQUM7WUFFOUQsMENBQTBDO1lBQzFDLGtDQUFrQztZQUNsQyxJQUFJLENBQUMsR0FBRyxDQUFDLE9BQU8sQ0FBQyxXQUFXLEdBQUcsQ0FBQyxPQUFnQixFQUFRLEVBQUU7Z0JBQ3RELElBQUksQ0FBQyxjQUFjLEdBQUcsT0FBTyxDQUFDO1lBQ2xDLENBQUMsQ0FBQztZQUVGLElBQUksQ0FBQyxHQUFHLENBQUMsT0FBTyxDQUFDLFVBQVUsR0FBRyxDQUFDLGdCQUFrQyxFQUFRLEVBQUU7Z0JBQ3ZFLElBQUksWUFBWSxHQUFtQixFQUFFLENBQUM7Z0JBRXRDLElBQUksQ0FBQyxXQUFXLENBQUMsR0FBRyxDQUFDLFdBQVcsQ0FBQyxDQUFDLFFBQWlCLEVBQVEsRUFBRTtvQkFDekQsSUFBSSxPQUFPLFFBQVEsQ0FBQyxFQUFFLEtBQUssV0FBVyxJQUFJLFFBQVEsQ0FBQyxFQUFFLEtBQUssZ0JBQWdCLENBQUMsS0FBSyxFQUFFO3dCQUM5RSxRQUFRLENBQUMsSUFBSSxDQUFDLGdCQUFnQixDQUFDLEtBQUssQ0FBQyxHQUFHLGdCQUFnQixDQUFDLElBQUksQ0FBQzt3QkFDOUQsWUFBWSxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsQ0FBQztxQkFDL0I7Z0JBQ0wsQ0FBQyxDQUFDLENBQUM7Z0JBRUgsSUFBSSxhQUFhLEdBQXNEO29CQUNuRSxRQUFRLEVBQUUsWUFBWTtvQkFDdEIsT0FBTyxFQUFFLENBQUMsZ0JBQWdCLENBQUMsS0FBSyxDQUFDO2lCQUNwQyxDQUFDO2dCQUVGLElBQUksQ0FBQyxXQUFXLENBQUMsR0FBRyxDQUFDLFlBQVksQ0FBQyxhQUFhLENBQUMsQ0FBQztZQUNyRCxDQUFDLENBQUM7WUFFRixJQUFJLENBQUMsR0FBRyxDQUFDLE9BQU8sQ0FBQyxTQUFTLEdBQUcsQ0FBQyxXQUFtQixFQUFRLEVBQUU7Z0JBQ3ZELElBQUksSUFBSSxDQUFDLE1BQU0sQ0FBQyxRQUFRLEtBQUssUUFBUSxFQUFFO29CQUNuQyxJQUFJLENBQUMsV0FBVyxDQUFDLEdBQUcsQ0FBQyxjQUFjLENBQUMsV0FBVyxDQUFDLENBQUM7aUJBQ3BEO3FCQUNJO29CQUNELE9BQU8sQ0FBQyxJQUFJLENBQUMsaUdBQWlHLENBQUMsQ0FBQztpQkFDbkg7WUFDTCxDQUFDLENBQUM7WUFFRixJQUFJLENBQUMsR0FBRyxDQUFDLE9BQU8sQ0FBQyxPQUFPLEdBQUcsQ0FBQyxLQUFpQixFQUFFLG1CQUE0QixLQUFLLEVBQVEsRUFBRTtnQkFDdEY7Ozs7Ozs7bUJBT0c7Z0JBQ0gsSUFBSSxPQUFPLElBQUksQ0FBQyxNQUFNLENBQUMsUUFBUSxLQUFLLFdBQVcsSUFBSSxJQUFJLENBQUMsTUFBTSxDQUFDLFFBQVEsS0FBSyxRQUFRLEVBQUU7b0JBQ2xGLElBQUksTUFBTSxHQUFXLENBQUMsT0FBTyxJQUFJLENBQUMsTUFBTSxDQUFDLFFBQVEsS0FBSyxXQUFXLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQztvQkFFakcsS0FBSyxJQUFJLENBQUMsR0FBVyxDQUFDLEVBQUUsQ0FBQyxHQUFHLEtBQUssQ0FBQyxNQUFNLEVBQUUsRUFBRSxDQUFDLEVBQUU7d0JBQzNDLElBQUksQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO3FCQUMzQjtvQkFFRCxJQUFJLENBQUMsV0FBVyxDQUFDLElBQUksQ0FBQyxHQUFHLEVBQUUsS0FBSyxDQUFDLENBQUM7b0JBQ2xDLElBQUksQ0FBQyxXQUFXLENBQUMsR0FBRyxDQUFDLGFBQWEsQ0FBQyxFQUFFLEdBQUcsRUFBRSxLQUFLLENBQUMsS0FBSyxFQUFFLEVBQUUsQ0FBQyxDQUFDO29CQUUzRCxJQUFJLGdCQUFnQixFQUFFO3dCQUNsQixJQUFJLENBQUMsV0FBVyxDQUFDLEdBQUcsQ0FBQyxrQkFBa0IsQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFDLEdBQUcsQ0FBQyxVQUFVLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLFFBQVEsRUFBRSxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUM7cUJBQ2xIO2lCQUNKO3FCQUNJO29CQUNELE9BQU8sQ0FBQyxJQUFJLENBQUMsZ0ZBQWdGLENBQUMsQ0FBQztpQkFDbEc7WUFDTCxDQUFDLENBQUM7WUFFRixJQUFJLENBQUMsR0FBRyxDQUFDLE9BQU8sQ0FBQyxVQUFVLEdBQUcsQ0FBQyxHQUE2QyxFQUFRLEVBQUU7Z0JBQ2xGLElBQUksT0FBTyxJQUFJLENBQUMsTUFBTSxDQUFDLFFBQVEsS0FBSyxXQUFXLElBQUksSUFBSSxDQUFDLE1BQU0sQ0FBQyxRQUFRLEtBQUssUUFBUSxFQUFFO29CQUNsRixJQUFJLFlBQVksR0FBa0IsRUFBRSxDQUFDO29CQUVyQyxJQUFJLE9BQU8sR0FBRyxLQUFLLFFBQVEsSUFBSSxPQUFPLEdBQUcsS0FBSyxRQUFRLEVBQUU7d0JBQ3BELFlBQVksQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLFFBQVEsRUFBRSxDQUFDLENBQUM7cUJBQ3JDO3lCQUNJO3dCQUNELEtBQUssSUFBSSxDQUFDLEdBQVcsQ0FBQyxFQUFFLENBQUMsR0FBRyxHQUFHLENBQUMsTUFBTSxFQUFFLEVBQUUsQ0FBQyxFQUFFOzRCQUN6QyxZQUFZLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxRQUFRLEVBQUUsQ0FBQyxDQUFDO3lCQUNyQztxQkFDSjtvQkFFRCxJQUFJLENBQUMsc0JBQXNCLENBQUMsWUFBWSxDQUFDLENBQUM7b0JBRTFDLElBQUksR0FBRyxHQUFXLE9BQU8sSUFBSSxDQUFDLE1BQU0sQ0FBQyxRQUFRLEtBQUssV0FBVyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsUUFBUSxDQUFDO29CQUM1RixJQUFJLFVBQVUsR0FBZSxFQUFFLENBQUM7b0JBRWhDLEtBQUssSUFBSSxDQUFDLEdBQVcsQ0FBQyxFQUFFLENBQUMsR0FBRyxZQUFZLENBQUMsTUFBTSxFQUFFLEVBQUUsQ0FBQyxFQUFFO3dCQUNsRCxVQUFVLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxHQUFHLENBQUMsRUFBRSxZQUFZLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDO3FCQUMvQztvQkFFRDs7Ozs7Ozt1QkFPRztvQkFFSCxJQUFJLGNBQWMsR0FBbUU7d0JBQ2pGLE1BQU0sRUFBRSxVQUFVO3FCQUNyQixDQUFDO29CQUVGLElBQUksQ0FBQyxXQUFXLENBQUMsR0FBRyxDQUFDLGFBQWEsQ0FBQyxjQUFjLENBQUMsQ0FBQztvQkFDbkQsSUFBSSxDQUFDLHFCQUFxQixFQUFFLENBQUM7aUJBQ2hDO3FCQUNJO29CQUNELE9BQU8sQ0FBQyxJQUFJLENBQUMsZ0ZBQWdGLENBQUMsQ0FBQztpQkFDbEc7WUFDTCxDQUFDLENBQUM7WUFFRixJQUFJLENBQUMsR0FBRyxDQUFDLE9BQU8sQ0FBQyxpQkFBaUIsR0FBRyxDQUFDLFdBQW1CLEVBQUUsV0FBb0IsRUFBRSxFQUFFO2dCQUMvRSxLQUFLLElBQUksQ0FBQyxHQUFXLENBQUMsRUFBRSxDQUFDLEdBQUcsSUFBSSxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsTUFBTSxFQUFFLEVBQUUsQ0FBQyxFQUFFO29CQUN4RCxJQUFJLElBQUksQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksS0FBSyxXQUFXLEVBQUU7d0JBQzVDLElBQUksQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsR0FBRyxXQUFXLENBQUM7cUJBQ2hEO2lCQUNKO1lBQ0wsQ0FBQyxDQUFDO1lBRUYsSUFBSSxDQUFDLEdBQUcsQ0FBQyxPQUFPLENBQUMsYUFBYSxHQUFHLENBQUMsT0FBMEIsRUFBUSxFQUFFO2dCQUNsRSxJQUFJLGFBQWEsR0FBc0I7b0JBQ25DLFFBQVEsRUFBRSxNQUFNO29CQUNoQixVQUFVLEVBQUUsSUFBSTtvQkFDaEIsbUJBQW1CLEVBQUUsSUFBSTtpQkFDNUIsQ0FBQztnQkFDRix1REFBdUQ7Z0JBQ3ZELElBQUksT0FBTyxDQUFDLGNBQWMsQ0FBQyxXQUFXLENBQUM7b0JBQUUsT0FBTyxDQUFDLFNBQVMsR0FBRyxPQUFPLENBQUMsU0FBUyxDQUFDLEtBQUssQ0FBQyxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUM7Z0JBQzVGLElBQUksTUFBTSxHQUFzQixNQUFNLENBQUMsTUFBTSxDQUFDLEVBQUUsRUFBRSxhQUFhLEVBQUUsT0FBTyxDQUFDLENBQUM7Z0JBQzFFLElBQUksT0FBTyxHQUFRLElBQUksQ0FBQyxXQUFXLENBQUMsR0FBRyxDQUFDLGNBQWMsQ0FBQyxNQUFNLENBQUMsQ0FBQztnQkFDL0QsSUFBSSxRQUFRLEdBQVEsSUFBSSxDQUFDLElBQUksQ0FBQyxPQUFPLEVBQUUsRUFBRSxJQUFJLEVBQUUsUUFBUSxFQUFFLENBQUMsQ0FBQztnQkFDM0QsSUFBSSxXQUFXLEdBQVEsSUFBSSxDQUFDLEtBQUssQ0FBQyxRQUFRLEVBQUUsRUFBRSxRQUFRLEVBQUUsTUFBTSxFQUFFLElBQUksRUFBRSxRQUFRLEVBQUUsQ0FBQyxDQUFDO2dCQUNsRixJQUFJLFVBQVUsR0FBUyxJQUFJLENBQUMsYUFBYSxDQUFDLFNBQVMsQ0FBQyxXQUFXLEVBQUUsbUVBQW1FLENBQUMsQ0FBQztnQkFDdEksTUFBTSxDQUFDLFVBQVUsRUFBRSxNQUFNLENBQUMsUUFBUSxHQUFHLE9BQU8sQ0FBQyxDQUFDO1lBQ2xELENBQUMsQ0FBQztZQUVGLElBQUksQ0FBQyxHQUFHLENBQUMsT0FBTyxDQUFDLFlBQVksR0FBRyxDQUFDLHFCQUE4QixLQUFLLEVBQVEsRUFBRTtnQkFDMUUsSUFBSSxDQUFDLGFBQWEsQ0FBQyxrQkFBa0IsQ0FBQyxDQUFDO1lBQzNDLENBQUMsQ0FBQztZQUVGLElBQUksQ0FBQyxHQUFHLENBQUMsT0FBTyxDQUFDLG1CQUFtQixHQUFHLENBQUMsUUFBaUIsRUFBUSxFQUFFO2dCQUMvRCxJQUFJLENBQUMsb0JBQW9CLENBQUMsUUFBUSxDQUFDLENBQUM7WUFDeEMsQ0FBQyxDQUFDO1lBRUYsZ0NBQWdDO1lBQ2hDLElBQUksT0FBTyxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLEtBQUssV0FBVztnQkFBRSxJQUFJLENBQUMsR0FBRyxDQUFDLEtBQUssR0FBRyxFQUFFLENBQUM7WUFDakUsSUFBSSxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsVUFBVSxHQUFHLEdBQVMsRUFBRTtnQkFDbkMsSUFBSSxDQUFDLFlBQVksRUFBRSxDQUFDO1lBQ3hCLENBQUMsQ0FBQztZQUVGLElBQUksQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLGFBQWEsR0FBRyxDQUFDLEtBQWMsRUFBUSxFQUFFO2dCQUNwRCxJQUFJLENBQUMsY0FBYyxDQUFDLEtBQUssQ0FBQyxDQUFDO1lBQy9CLENBQUMsQ0FBQztZQUVGLElBQUksQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLFdBQVcsR0FBRyxDQUFDLE9BQWdCLEVBQVEsRUFBRTtnQkFDcEQsSUFBSSxDQUFDLFlBQVksQ0FBQyxPQUFPLENBQUMsQ0FBQztZQUMvQixDQUFDLENBQUM7WUFFRixJQUFJLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxhQUFhLEdBQUcsR0FBcUIsRUFBRTtnQkFDbEQsT0FBTyxJQUFJLENBQUMsY0FBYyxFQUFFLENBQUM7WUFDakMsQ0FBQyxDQUFDO1lBRUYsSUFBSSxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsYUFBYSxHQUFHLENBQUMsTUFBd0IsRUFBUSxFQUFFO2dCQUM5RCxJQUFJLENBQUMsYUFBYSxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQztnQkFDaEMsSUFBSSxDQUFDLGNBQWMsQ0FBQyxNQUFNLENBQUMsQ0FBQztZQUNoQyxDQUFDLENBQUM7WUFFRixJQUFJLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxnQkFBZ0IsR0FBRyxDQUFDLFFBQWlCLEVBQVEsRUFBRTtnQkFDMUQsSUFBSSxDQUFDLGlCQUFpQixDQUFDLFFBQVEsQ0FBQyxDQUFDO1lBQ3JDLENBQUMsQ0FBQztZQUVGLElBQUksQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLGFBQWEsR0FBRyxDQUFDLEtBQWMsRUFBUSxFQUFFO2dCQUNwRCxJQUFJLENBQUMsY0FBYyxDQUFDLEtBQUssQ0FBQyxDQUFDO1lBQy9CLENBQUMsQ0FBQztZQUVGLGdDQUFnQztZQUNoQyxJQUFJLENBQUMsR0FBRyxDQUFDLFdBQVcsQ0FBQyxhQUFhLEdBQUcsR0FBUyxFQUFFO2dCQUM1QyxJQUFJLFlBQVksR0FBMkIsSUFBSSxDQUFDLFdBQVcsQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLGFBQWEsQ0FBQyxrQkFBa0IsRUFBRSxDQUFDLENBQUM7Z0JBRTdHLEtBQUssSUFBSSxJQUFJLElBQUksWUFBWSxFQUFFO29CQUMzQixJQUFJLFlBQVksQ0FBQyxjQUFjLENBQUMsSUFBSSxDQUFDLEVBQUU7d0JBQ25DLElBQUksV0FBVyxHQUFRLFlBQVksQ0FBQyxJQUFJLENBQUMsQ0FBQzt3QkFFMUMsS0FBSyxJQUFJLFFBQVEsSUFBSSxXQUFXLEVBQUU7NEJBQzlCLElBQUksV0FBVyxDQUFDLGNBQWMsQ0FBQyxRQUFRLENBQUMsRUFBRTtnQ0FDdEMsSUFBSSxPQUFPLFdBQVcsQ0FBQyxRQUFRLENBQUMsQ0FBQyxNQUFNLEtBQUssV0FBVyxFQUFFO29DQUNyRCxXQUFXLENBQUMsUUFBUSxDQUFDLENBQUMsTUFBTSxHQUFHLEVBQUUsQ0FBQztpQ0FDckM7Z0NBRUQsV0FBVyxDQUFDLFFBQVEsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxNQUFNLEdBQUcsQ0FBQyxDQUFDOzZCQUMzQzt5QkFDSjtxQkFDSjtpQkFDSjtZQUNMLENBQUMsQ0FBQztTQUNMO2FBQ0k7WUFDRCxPQUFPLENBQUMsSUFBSSxDQUFDLHlFQUF5RSxDQUFDLENBQUM7U0FDM0Y7SUFDTCxDQUFDO0lBRUQsd0dBQXdHO0lBQ3hHLGtCQUFrQjtJQUNsQix3R0FBd0c7SUFDaEcsZ0JBQWdCLENBQUMsU0FBaUI7UUFDdEMsSUFBSSxPQUFPLFNBQVMsS0FBSyxXQUFXLElBQUksU0FBUyxLQUFLLFFBQVEsRUFBRTtZQUM1RCxJQUFJLENBQUMsYUFBYSxHQUFHLElBQUksZ0JBQWdCLEVBQUUsQ0FBQztTQUMvQzthQUNJO1lBQ0QsSUFBSSxDQUFDLGFBQWEsR0FBRyxJQUFJLG9CQUFvQixFQUFFLENBQUM7U0FDbkQ7SUFDTCxDQUFDO0lBRU8saUJBQWlCLENBQUMsV0FBeUI7UUFDL0MsSUFBSSxDQUFDLE1BQU0sR0FBRyxJQUFJLENBQUMsYUFBYSxDQUFDLFNBQVMsQ0FBQyxXQUFXLENBQUMsQ0FBQztRQUV4RCxJQUFJLENBQUMsYUFBYSxDQUFDLGlCQUFpQixDQUFDLFdBQVcsQ0FBQyxDQUFDO1FBQ2xELElBQUksQ0FBQyxhQUFhLENBQUMsd0JBQXdCLENBQUMsV0FBVyxDQUFDLENBQUM7SUFDN0QsQ0FBQzs7O1lBcDRDSixTQUFTLFNBQUM7Z0JBQ1AsUUFBUSxFQUFFLFVBQVU7Z0JBQ3BCLDBpQ0FBc0M7Z0JBRXRDLGFBQWEsRUFBRSxpQkFBaUIsQ0FBQyxJQUFJO2dCQUNyQyxTQUFTLEVBQUUsQ0FBQyxZQUFZLEVBQUUsZUFBZSxFQUFFLGdCQUFnQixFQUFFLG9CQUFvQixDQUFDO2dCQUNsRixJQUFJLEVBQUUsRUFBRSxPQUFPLEVBQUUsV0FBVyxFQUFFOzthQUNqQzs7O1lBdklHLGdCQUFnQjtZQUlYLE1BQU07WUE4Q04sWUFBWTtZQUpaLGVBQWU7OztrQkFxSG5CLEtBQUs7cUJBQ0wsS0FBSztxQkFDTCxLQUFLO2tCQUNMLEtBQUs7d0JBR0wsS0FBSzs4QkFDTCxLQUFLOytCQUNMLE1BQU07MEJBQ04sV0FBVyxTQUFDLGlCQUFpQjs2QkFDN0IsV0FBVyxTQUFDLGlCQUFpQjt1QkFlN0IsWUFBWSxTQUFDLGVBQWUsRUFBRSxDQUFDLFFBQVEsQ0FBQyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7XHJcbiAgICBDb21wb25lbnQsXHJcbiAgICBPbkluaXQsXHJcbiAgICBPbkNoYW5nZXMsXHJcbiAgICBPbkRlc3Ryb3ksXHJcbiAgICBTaW1wbGVDaGFuZ2VzLFxyXG4gICAgVmlld0VuY2Fwc3VsYXRpb24sXHJcbiAgICBJbnB1dCxcclxuICAgIEhvc3RCaW5kaW5nLFxyXG4gICAgSG9zdExpc3RlbmVyLFxyXG4gICAgVmlld0NvbnRhaW5lclJlZixcclxuICAgIEV2ZW50RW1pdHRlcixcclxuICAgIE91dHB1dFxyXG59IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xyXG5pbXBvcnQgeyBSb3V0ZXIgfSBmcm9tICdAYW5ndWxhci9yb3V0ZXInO1xyXG5pbXBvcnQgeyBPYnNlcnZhYmxlLCB0aW1lciwgU3Vic2NyaXB0aW9uLCBTdWJzY3JpYmVyIH0gZnJvbSAncnhqcyc7XHJcbmltcG9ydCB7XHJcbiAgICBHcmlkT3B0aW9ucyxcclxuICAgIFJvd05vZGUsXHJcbiAgICBSb3dFdmVudCxcclxuICAgIE1vZGVsVXBkYXRlZEV2ZW50LFxyXG4gICAgRXhjZWxFeHBvcnRQYXJhbXMsXHJcbiAgICBDb2x1bW4sXHJcbiAgICBHcmlkQXBpLFxyXG4gICAgQ29udGV4dCxcclxuICAgIENvbERlZixcclxuICAgIFZhbHVlU2V0dGVyUGFyYW1zLFxyXG4gICAgLy8gQ29sRGVmLFxyXG4gICAgLy8gSUVudGVycHJpc2VEYXRhc291cmNlLFxyXG4gICAgLy8gSUVudGVycHJpc2VHZXRSb3dzUGFyYW1zLFxyXG59IGZyb20gJ2FnLWdyaWQtY29tbXVuaXR5JztcclxuaW1wb3J0IHtcclxuICAgIElFbnRlcnByaXNlRGF0YXNvdXJjZSxcclxuICAgIElFbnRlcnByaXNlR2V0Um93c1BhcmFtcyxcclxufSBmcm9tICcuL2VudGVycHJpc2UtZGF0YXNvdXJjZSc7XHJcbmltcG9ydCAnYWctZ3JpZC1lbnRlcnByaXNlJztcclxuaW1wb3J0ICogYXMgWExTWCBmcm9tICd4bHN4JztcclxuaW1wb3J0IHsgc2F2ZUFzIH0gZnJvbSAnZmlsZS1zYXZlcic7XHJcblxyXG5pbXBvcnQge1xyXG4gICAgSVRhYmxlQ29sdW1uLFxyXG4gICAgSVRhYmxlQ29uZmlnLFxyXG4gICAgSVN0eWxpbmdDb25maWcsXHJcbiAgICBJVGFibGVQaXZvdFN0YXRlLFxyXG4gICAgSVRhYmxlQnV0dG9uLFxyXG4gICAgSVRhYmxlQ2VsbFBhcmFtcyxcclxuICAgIElUYWJsZUZvcm1FbWl0UGFyYW1zLFxyXG4gICAgSVRhYmxlRGF0YXNvdXJjZVBhcmFtcyxcclxuICAgIElUYWJsZUFwaSxcclxuICAgIElUYWJsZURyb3Bkb3duQWN0aW9uLFxyXG4gICAgS2RUYWJsZURhdGFzb3VyY2VFdmVudCxcclxuICAgIEtkVGFibGVTZWxlY3Rpb25VcGRhdGVFdmVudCxcclxuICAgIEtkVGFibGVJbnB1dFVwZGF0ZUV2ZW50LFxyXG4gICAgS2RUYWJsZUJ1dHRvbkV2ZW50XHJcbn0gZnJvbSAnLi9rZC1hbmd1bGFyLXRhYmxlLWludGVyZmFjZSc7XHJcblxyXG5pbXBvcnQgeyBLZEludFRhYmxlRXZlbnQgfSBmcm9tICcuL2tkLWFuZ3VsYXItdGFibGUtZXZlbnQnO1xyXG5pbXBvcnQgeyBLZFRhYmxlTm9ybWFsU3ZjIH0gZnJvbSAnLi90YWJsZS1zZXJ2aWNlcy9rZC10YWJsZS1ub3JtYWwtc3ZjJztcclxuaW1wb3J0IHsgS2RUYWJsZUVudGVycHJpc2VTdmMgfSBmcm9tICcuL3RhYmxlLXNlcnZpY2VzL2tkLXRhYmxlLWVudGVycHJpc2Utc3ZjJztcclxuLy8gaW1wb3J0IHsgS2RTcGxpdHRlckV2ZW50IH0gZnJvbSAnLi4vJztcclxuaW1wb3J0IHsgS2REb21FbGVtU3ZjLCBBR19HUklEX0tFWSB9IGZyb20gJy4uL2tkLWNvbW1vbi9pbmRleCc7XHJcbmltcG9ydCB7IExpY2Vuc2VNYW5hZ2VyIH0gZnJvbSBcImFnLWdyaWQtZW50ZXJwcmlzZVwiO1xyXG5cclxuZGVjbGFyZSB2YXIgcmVxdWlyZTogYW55O1xyXG5cclxuLyoqXHJcbiAqIC0tIERvY3VtZW50YXRpb24gZm9yIGtkLWFuZ3VsYXItdGFibGUudHMgKGtkLXRhYmxlKVxyXG4gKlxyXG4gKiAtIEhvc3RMaXN0ZW5lclxyXG4gKiAgICAgLSBvblJlc2l6ZVxyXG4gKlxyXG4gKiAtIExpZmUgY3ljbGVzOlxyXG4gKiAgICAgLSBuZ09uSW5pdFxyXG4gKiAgICAgLSBuZ09uQ2hhbmdlc1xyXG4gKiAgICAgLSBuZ09uRGVzdHJveVxyXG5cclxuICogLSBhZy1HcmlkIGV2ZW50cyBmdW5jdGlvbjpcclxuICogICAgIC0gb25HcmlkUmVhZHlcclxuICogICAgIC0gb25Nb2RlbFVwZGF0ZWRcclxuICogICAgIC0gb25Sb3dDbGlja2VkXHJcbiAqXHJcbiAqIC0ga2QtdGFibGUgYnV0dG9uIGZ1bmN0aW9uOlxyXG4gKiAgICAgLSBvbkJ1dHRvbkNsaWNla2RcclxuICpcclxuICogLSBQcml2YXRlIGZ1bmN0aW9uczpcclxuICogICAgIC0gRGlzcGxheSAvIERPTSBmdW5jdGlvbnM6XHJcbiAqICAgICAgICAgLSBfcmVzaXplQ29sdW1uXHJcbiAqICAgICAgICAgLSBfc2hvd0xvYWRpbmdPdmVybGF5XHJcbiAqICAgICAgICAgLSBfdXBkYXRlUGFyZW50Tm9kZUNTU1xyXG4gKiAgICAgICAgIC0gX3NldEhlaWdodFxyXG4gKiAgICAgICAgIC0gX3NldE1vYmlsZUhlaWdodCAoZmxhdHRlbiB0YWJsZSlcclxuICogICAgICAgICAtIF9zZXRXZWJIZWlnaHIgKHVzZXIgY29uZmlndXJhdGlvbilcclxuICogICAgICAgICAtIF9pc0NsaWNrVmFsaWQgKGNsaWNrIGNvbmZpZ3VyYXRpb24pXHJcbiAqXHJcbiAqICAgICAtIEdyaWQgQ3ljbGVzOlxyXG4gKiAgICAgICAgIC0gX2dyaWRJbml0Q3ljbGVcclxuICogICAgICAgICAtIF9ncmlkUmVhZHlDeWNsZVxyXG4gKiAgICAgICAgIC0gX2dyaWRSZWFkeUVudGVycHJpc2VDeWNsZVxyXG4gKiAgICAgICAgIC0gX2dyaWRSZWFkeURPTUN5Y2xlXHJcbiAqICAgICAgICAgLSBfZ3JpZFNlbGVjdGlvbkN5Y2xlXHJcbiAqICAgICAgICAgLSBfZ3JpZFNldFJvd0N5Y2xlXHJcbiAqICAgICAgICAgLSBfZ3JpZENsaWNrTmF2aWdhdGVDeWNsZVxyXG4gKlxyXG4gKiAgICAgLSBDb2x1bW4gLyBSb3cgLyBDb25maWcgZ2VuZXJhdGlvbnMvcHJvY2Vzc2luZzpcclxuICogICAgICAgICAtIF9zZXRHcmlkT3B0aW9uc1xyXG4gKiAgICAgICAgIC0gX3NldENvbHVtbkRlZlxyXG4gKiAgICAgICAgIC0gX3NldFJvd0RhdGFcclxuICpcclxuICogICAgIC0gRXZlbnQgZnVuY3Rpb25zOlxyXG4gKiAgICAgICAgIC0gX3Byb2Nlc3NFdmVudFBhcmFtczxUPlxyXG4gKiAgICAgICAgIC0gX2Jyb2FkY2FzdEV2ZW50UGFyYW1zXHJcbiAqICAgICAgICAgLSBfYnJvYWRjYXN0TW9kZWxDaGFuZ2VkXHJcbiAqICAgICAgICAgLSBfc2V0dXBTdWJzY3JpcHRpb25FdmVudHNcclxuICpcclxuICogICAgIC0gU2VsZWN0aW9uIGZ1bmN0aW9uczpcclxuICogICAgICAgICAtIF91cGRhdGVTZWxlY3Rpb25Ob2Rlc1xyXG4gKiAgICAgICAgIC0gX3Byb2Nlc3NJbml0aWFsU2VsZWN0aW9uXHJcbiAqXHJcbiAqICAgICAtIElucHV0IGZ1bmN0aW9uczpcclxuICogICAgICAgICAtIF9wcm9jZXNzSW5wdXRDaGFuZ2VkXHJcbiAqICAgICAgICAgLSBfZW1pdElucHV0VXBkYXRlRXZlbnRcclxuICogICAgICAgICAtIF9kZWxldGVOb2RlRnJvbVJvd0RhdGFcclxuICpcclxuICogICAgIC0gRGF0YXNvdXJjZSBmdW5jdGlvbnM6XHJcbiAqICAgICAgICAgLSBfY2xlYXJEYXRhc291cmNlXHJcbiAqICAgICAgICAgLSBfZ2VuZXJhdGVFbnRlcnByaXNlRGF0YXNvdXJjZVxyXG4gKiAgICAgICAgIC0gX2dlbmVyYXRlRGF0YXNvdXJjZVJvd3NcclxuICpcclxuICogICAgIC0gQVBJIGdlbmVyYXRpb25zOlxyXG4gKiAgICAgICAgIC0gX2luaXRJVGFibGVBcGkgKFRPRE86IHVwZGF0ZSBhcGkgc2V0dGluZyBhbGwgdG8gdGFibGUgc2VydmljZSlcclxuICpcclxuICogICAgIC0gTWlzYyBmdW5jdGlvbnM6XHJcbiAqICAgICAgICAgLSBfaW5pdEdyaWRTZXJ2aWNlXHJcbiAqICAgICAgICAgLSBfdXBkYXRlR3JpZENvbmZpZ1xyXG4gKi9cclxuXHJcblxyXG5cclxuQENvbXBvbmVudCh7XHJcbiAgICBzZWxlY3RvcjogJ2tkLXRhYmxlJyxcclxuICAgIHRlbXBsYXRlVXJsOiAnLi9rZC1hbmd1bGFyLXRhYmxlLmh0bWwnLFxyXG4gICAgc3R5bGVVcmxzOiBbJy4va2QtYW5ndWxhci10YWJsZS5zY3NzJ10sXHJcbiAgICBlbmNhcHN1bGF0aW9uOiBWaWV3RW5jYXBzdWxhdGlvbi5Ob25lLFxyXG4gICAgcHJvdmlkZXJzOiBbS2REb21FbGVtU3ZjLCBLZEludFRhYmxlRXZlbnQsIEtkVGFibGVOb3JtYWxTdmMsIEtkVGFibGVFbnRlcnByaXNlU3ZjXSxcclxuICAgIGhvc3Q6IHsgJ2NsYXNzJzogJ2tkeC10YWJsZScgfVxyXG59KVxyXG5cclxuZXhwb3J0IGNsYXNzIEtkVGFibGUgaW1wbGVtZW50cyBPbkluaXQsIE9uQ2hhbmdlcywgT25EZXN0cm95IHtcclxuICAgIHB1YmxpYyBncmlkSWQ6IHN0cmluZyA9ICcnO1xyXG4gICAgcHVibGljIGdyaWRPcHRpb25zOiBHcmlkT3B0aW9ucztcclxuICAgIHB1YmxpYyBncmlkQXBpOiBHcmlkQXBpOyBcclxuICAgIHB1YmxpYyBkaXNwbGF5TG9hZGluZzogYm9vbGVhbiA9IHRydWU7XHJcbiAgICBwdWJsaWMgX3NpbmdsZUNsaWNrRWRpdDogYm9vbGVhbiA9IGZhbHNlO1xyXG4gICAgcHJpdmF0ZSBfZW50ZXJwcmlzZSA9IHJlcXVpcmUoJ2FnLWdyaWQtZW50ZXJwcmlzZScpO1xyXG4gICAgcHJpdmF0ZSBfaXNNb2JpbGVWaWV3OiBib29sZWFuO1xyXG4gICAgcHJpdmF0ZSBfdGFibGVTZXJ2aWNlOiBLZFRhYmxlTm9ybWFsU3ZjIHwgS2RUYWJsZUVudGVycHJpc2VTdmM7XHJcbiAgICBwcml2YXRlIF9zdWJzY3JpcHRpb25PYmo6IHsgW2tleTogc3RyaW5nXTogU3Vic2NyaXB0aW9uIH0gPSB7fTtcclxuXHJcbiAgICBwcml2YXRlIF9jdXJyZW50U3RhdGU6IElUYWJsZVBpdm90U3RhdGUgPSB7XHJcbiAgICAgICAgY29sdW1uU3RhdGU6IFtdLFxyXG4gICAgICAgIHBpdm90TW9kZTogZmFsc2UsXHJcbiAgICAgICAgZ3JvdXBTdGF0ZTogW11cclxuICAgIH07XHJcbiAgICBwcml2YXRlIF9pc0NoYW5naW5nU3RhdGU6IGJvb2xlYW4gPSBmYWxzZTtcclxuICAgIHByaXZhdGUgX3Bpdm90RWxlbWVudDogeyBba2V5OiBzdHJpbmddOiBhbnkgfSA9IHtcclxuICAgICAgICAncGl2b3QnOiBudWxsLFxyXG4gICAgICAgICdjb2x1bW4tZHJvcCc6IG51bGxcclxuICAgIH07XHJcbiAgICBwcml2YXRlIF9wcmV2aW91c1Rvb2xwYW5lbFR5cGU6ICdub25lJyB8ICdjb2x1bW5zJyB8ICdwaXZvdCc7XHJcbiAgICBwcml2YXRlIF9zdXBwcmVzc01vdmFibGVDb2x1bW5zOiBib29sZWFuID0gdHJ1ZTtcclxuXHJcbiAgICBwcml2YXRlIF9kaXJlY3Rpb246ICdsdHInIHwgJ3J0bCcgPSAnbHRyJztcclxuXHJcbiAgICBASW5wdXQoKSByb3c6IEFycmF5PGFueT47XHJcbiAgICBASW5wdXQoKSBjb2x1bW46IEFycmF5PElUYWJsZUNvbHVtbj47XHJcbiAgICBASW5wdXQoKSBjb25maWc6IElUYWJsZUNvbmZpZztcclxuICAgIEBJbnB1dCgpIGFwaTogSVRhYmxlQXBpO1xyXG4gICAgLy8gQElucHV0KCkgY29udGV4dDogQ29udGV4dDtcclxuICAgIC8vIEBJbnB1dCgpIGdyaWRPcHRpb246IEdyaWRPcHRpb25zO1xyXG4gICAgQElucHV0KCkgZWRpdFRhYmxlOiBib29sZWFuO1xyXG4gICAgQElucHV0KCkgZGlzcGxheUVkaXRhYmxlOiBib29sZWFuO1xyXG4gICAgQE91dHB1dCgpIG9uRXhwb3J0UG9zc2libGU6IEV2ZW50RW1pdHRlcjxib29sZWFuPiA9IG5ldyBFdmVudEVtaXR0ZXIoKTtcclxuICAgIEBIb3N0QmluZGluZygnY2xhc3MuZnVsbC1ncmlkJykgZGlzcGxheUZ1bGw6IGJvb2xlYW47XHJcbiAgICBASG9zdEJpbmRpbmcoJ2NsYXNzLmtkeC10YWJsZScpIF9jbGFzc0tkeFRhYmxlOiBib29sZWFuID0gdHJ1ZTtcclxuXHJcbiAgICBwdWJsaWMgZGVmYXVsdENvbERlZjogQ29sRGVmO1xyXG4gICAgcHVibGljIGVkaXRpbmdNb2RlRW5hYmxlZDogYm9vbGVhbiA9IGZhbHNlO1xyXG4gICAgcmlnaHREaXJlY3Rpb246IHN0cmluZztcclxuICAgIGNvbnN0cnVjdG9yKFxyXG4gICAgICAgIHByaXZhdGUgX3ZjcjogVmlld0NvbnRhaW5lclJlZixcclxuICAgICAgICBwcml2YXRlIF9yb3V0ZXI6IFJvdXRlcixcclxuICAgICAgICBwcml2YXRlIF9kb21TdmM6IEtkRG9tRWxlbVN2YyxcclxuICAgICAgICAvLyBwcml2YXRlIF9zcGxpdHRlckV2ZW50OiBLZFNwbGl0dGVyRXZlbnQsXHJcbiAgICAgICAgcHJpdmF0ZSBfdGFibGVJbnRFdmVudDogS2RJbnRUYWJsZUV2ZW50LFxyXG4gICAgKSB7XHJcbiAgICAgICAgTGljZW5zZU1hbmFnZXIuc2V0TGljZW5zZUtleShBR19HUklEX0tFWS52YWx1ZSk7XHJcbiAgICB9XHJcblxyXG4gICAgQEhvc3RMaXN0ZW5lcignd2luZG93OnJlc2l6ZScsIFsnJGV2ZW50J10pXHJcbiAgICBvblJlc2l6ZShfZXZlbnQ6IEV2ZW50KTogdm9pZCB7XHJcbiAgICAgICAgdGhpcy5fc2V0SGVpZ2h0KCk7XHJcbiAgICB9XHJcblxyXG4gICAgLyoqKioqKioqKioqKioqKioqKioqKioqKiogTGlmZSBjeWNsZXMgZnVuY3Rpb25zICoqKioqKioqKioqKioqKioqKioqKioqKioqKioqL1xyXG4gICAgbmdPbkluaXQoKTogdm9pZCB7XHJcbiAgICAgICAgLy8gY29uc29sZS5sb2coXCItLSBHcmlkIHN0YXRlOiBJbml0IC0tXCIsIHRoaXMucm93LCB0aGlzLmNvbHVtbiwgdGhpcy5jb25maWcsIHRoaXMuYXBpKTtcclxuICAgICAgICB0aGlzLl9zaG93TG9hZGluZ092ZXJsYXkodHJ1ZSk7XHJcbiAgICAgICAgdGhpcy5fZ3JpZEluaXRDeWNsZSgpO1xyXG4gICAgfVxyXG5cclxuICAgIG5nT25DaGFuZ2VzKF9zaW1wbGVDaGFuZ2VzOiBTaW1wbGVDaGFuZ2VzKTogdm9pZCB7XHJcbiAgICAgICAgdGhpcy5fc2hvd0xvYWRpbmdPdmVybGF5KHRydWUpO1xyXG4gICAgICAgIGNvbnNvbGUubG9nKFwiLS0gR3JpZCBzdGF0ZTogQ2hhbmdlIC0tIFwiLCBfc2ltcGxlQ2hhbmdlcyk7XHJcblxyXG4gICAgICAgIGlmICh0eXBlb2YgX3NpbXBsZUNoYW5nZXMuY29sdW1uICE9PSAndW5kZWZpbmVkJyAmJlxyXG4gICAgICAgICAgICAhX3NpbXBsZUNoYW5nZXMuY29sdW1uLmZpcnN0Q2hhbmdlXHJcbiAgICAgICAgKSB7XHJcbiAgICAgICAgICAgIHRoaXMuX3NldENvbHVtbkRlZihfc2ltcGxlQ2hhbmdlcy5jb2x1bW4uY3VycmVudFZhbHVlKTtcclxuICAgICAgICAgICAgdGhpcy5fc2hvd0xvYWRpbmdPdmVybGF5KGZhbHNlKTtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIGlmICh0eXBlb2YgX3NpbXBsZUNoYW5nZXMucm93ICE9PSAndW5kZWZpbmVkJyAmJlxyXG4gICAgICAgICAgICAhX3NpbXBsZUNoYW5nZXMucm93LmZpcnN0Q2hhbmdlXHJcbiAgICAgICAgKSB7XHJcbiAgICAgICAgICAgIHRoaXMuX3NldFJvd0RhdGEoX3NpbXBsZUNoYW5nZXMucm93LmN1cnJlbnRWYWx1ZSk7XHJcbiAgICAgICAgICAgIHRoaXMuX3Nob3dMb2FkaW5nT3ZlcmxheShmYWxzZSk7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICBpZiAodHlwZW9mIF9zaW1wbGVDaGFuZ2VzLmNvbmZpZyAhPT0gJ3VuZGVmaW5lZCcpIHtcclxuICAgICAgICAgICAgdGhpcy5fc2hvd0xvYWRpbmdPdmVybGF5KGZhbHNlKTtcclxuICAgICAgICAgICAgdGhpcy51cGRhdGVTdHlsZShfc2ltcGxlQ2hhbmdlcy5jb25maWcuY3VycmVudFZhbHVlKTtcclxuXHJcbiAgICAgICAgICAgIHRpbWVyKDEwMCkuc3Vic2NyaWJlKCgpOiB2b2lkID0+IHtcclxuICAgICAgICAgICAgICAgIHRoaXMuX2NvbmZpZ3VyZVBpdm90RGlzcGxheSgpO1xyXG5cclxuICAgICAgICAgICAgICAgIGlmICh0eXBlb2YgdGhpcy5jb25maWcuc3VwcHJlc3NNb3ZhYmxlQ29sdW1ucyAhPT0gJ3VuZGVmaW5lZCdcclxuICAgICAgICAgICAgICAgICkge1xyXG4gICAgICAgICAgICAgICAgICAgIGlmICh0aGlzLmNvbmZpZy5zdXBwcmVzc01vdmFibGVDb2x1bW5zICE9PSB0aGlzLl9zdXBwcmVzc01vdmFibGVDb2x1bW5zKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLl9lbmFibGVDb2x1bW5Nb3ZhYmxlKHRoaXMuY29uZmlnLnN1cHByZXNzTW92YWJsZUNvbHVtbnMpO1xyXG4gICAgICAgICAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLmNvbmZpZy5zdXBwcmVzc01vdmFibGVDb2x1bW5zID0gdGhpcy5fc3VwcHJlc3NNb3ZhYmxlQ29sdW1ucztcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIG5nT25EZXN0cm95KCk6IHZvaWQge1xyXG4gICAgICAgIC8vIGNvbnNvbGUubG9nKFwiLS0gR3JpZCBzdGF0ZTogRGVzdHJveWluZyAtLVwiKTtcclxuICAgICAgICBmb3IgKGxldCBpdGVtIGluIHRoaXMuX3N1YnNjcmlwdGlvbk9iaikge1xyXG4gICAgICAgICAgICBpZiAodHlwZW9mIHRoaXMuX3N1YnNjcmlwdGlvbk9ialtpdGVtXSAhPT0gJ3VuZGVmaW5lZCcpIHtcclxuICAgICAgICAgICAgICAgIHRoaXMuX3N1YnNjcmlwdGlvbk9ialtpdGVtXS51bnN1YnNjcmliZSgpO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIHNldEF0dGVuZGFuY2UoZGlzcGxheUVkaXRUYWJsZSwgX2NvbmZpZzogSVRhYmxlQ29uZmlnKSB7XHJcbiAgICAgICAgLy8gbGV0IGFsbENvbHVtbnMgPSB0aGlzLmdyaWRPcHRpb25zLmNvbHVtbkFwaS5nZXRBbGxDb2x1bW5zKClcclxuXHJcbiAgICAgICAgLy8gYWxsQ29sdW1ucy5mb3JFYWNoKChjb2x1bW4sIGluZGV4KSA9PiB7XHJcbiAgICAgICAgLy8gICAgIGxldCBjdXJyZW50Q29sdW1uRGVmID0gY29sdW1uLmdldENvbERlZigpXHJcbiAgICAgICAgLy8gICAgIGNvbnNvbGUubG9nKGBjb2x1bW4gJHtpbmRleCsxfWAsIGN1cnJlbnRDb2x1bW5EZWYpXHJcbiAgICAgICAgLy8gfSlcclxuICAgICAgICBcclxuICAgICAgICBpZiAoZGlzcGxheUVkaXRUYWJsZSkge1xyXG4gICAgICAgICAgICB0aGlzLmdyaWRPcHRpb25zLmNvbnRleHQubW9kZSA9ICdlZGl0J1xyXG4gICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgIHRoaXMuZ3JpZE9wdGlvbnMuY29udGV4dC5tb2RlID0gJ3ZpZXcnXHJcbiAgICAgICAgICAgIF9jb25maWcuY29udGV4dC5tb2RlID0gJ3ZpZXcnO1xyXG4gICAgICAgIH1cclxuICAgICAgICBzZXRUaW1lb3V0KCgpID0+IHsgdGhpcy5ncmlkQXBpLnJlc2V0Um93SGVpZ2h0cygpOyB9LCAxMDApO1xyXG4gICAgICAgIGxldCBfY29sdW1ucyA9IHRoaXMuZ3JpZE9wdGlvbnMuY29sdW1uQXBpLmdldEFsbERpc3BsYXllZENvbHVtbnMoKTtcclxuICAgICAgICAvLyBsZXQgY29sRGVmID0gX2NvbHVtbnNbMl0uZ2V0Q29sRGVmKClcclxuICAgICAgICAvLyBjb25zb2xlLmxvZyhjb2xEZWYpO1xyXG4gICAgICAgIC8vIGNvbERlZi5jZWxsUmVuZGVyZXJQYXJhbXMgPSAnPHA+SGVsbG88L3A+J1xyXG4gICAgICAgIC8vIGxldCBuZXdEYXRhID0gW11cclxuICAgICAgICAvLyBuZXdEYXRhLnB1c2goY29sRGVmKVxyXG4gICAgICAgIHRoaXMuZ3JpZE9wdGlvbnMuY29sdW1uQXBpLnNldFZhbHVlQ29sdW1ucyhfY29sdW1ucylcclxuICAgIH1cclxuXHJcbiAgICB0b2dnbGVFZGl0cyhkYXRhKSB7XHJcbiAgICAgICAgaWYgKHRoaXMuZWRpdFRhYmxlICYmICF0aGlzLmRpc3BsYXlFZGl0YWJsZSkge1xyXG4gICAgICAgICAgICB0aGlzLmVkaXRpbmdNb2RlRW5hYmxlZCA9ICF0aGlzLmVkaXRpbmdNb2RlRW5hYmxlZDtcclxuICAgICAgICAgICAgdGhpcy5fc2luZ2xlQ2xpY2tFZGl0ID0gIXRoaXMuX3NpbmdsZUNsaWNrRWRpdDtcclxuICAgICAgICAgICAgbGV0IF9jb2x1bW5zID0gdGhpcy5ncmlkT3B0aW9ucy5jb2x1bW5BcGkuZ2V0QWxsRGlzcGxheWVkQ29sdW1ucygpO1xyXG4gICAgICAgICAgICBsZXQgbmV3Q29sdW1uRGF0YSA9IFtdO1xyXG4gICAgICAgICAgICBfY29sdW1ucy5mb3JFYWNoKChjb2x1bW46IGFueSkgPT4ge1xyXG4gICAgICAgICAgICAgICAgbGV0IGNvbHVtbkRlZiA9IGNvbHVtbj8uZ2V0Q29sRGVmKCk7XHJcbiAgICAgICAgICAgICAgICBpZiAoY29sdW1uRGVmLmNhbkVkaXQgPT0gdHJ1ZSkge1xyXG4gICAgICAgICAgICAgICAgICAgIGNvbHVtbkRlZi5jZWxsU3R5bGUgPSBmdW5jdGlvbiAocGFyYW1zOiBhbnkpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgaWYgKCFpc05hTihwYXJzZUZsb2F0KHBhcmFtcy52YWx1ZSkpICYmIHBhcnNlRmxvYXQocGFyYW1zLnZhbHVlKSA8IDUwKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4geyBjb2xvcjogJyNDQzVDNUMnIH07XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4geyBjb2xvcjogJyMzMzMnIH07XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBjb2x1bW5EZWYuY2VsbENsYXNzUnVsZXMgPSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAnb2UtY2VsbC1oaWdobGlnaHQnOiBmdW5jdGlvbiAocGFyYW1zKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIDE7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgJ29lLWNlbGwtZXJyb3InOiBmdW5jdGlvbiAocGFyYW1zKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gcmV0dXJuIHBhcmFtcy5kYXRhLnNhdmVfZXJyb3JbcGFyYW1zLmNvbERlZi5maWVsZF07XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbHVtbkRlZi5jZWxsUmVuZGVyZXJQYXJhbXMgPSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBzaG91bGRCZUVkaXRpbmc6ICgpID0+IHRoaXMuZWRpdGluZ01vZGVFbmFibGVkLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBjb2x1bW5EZWYuZWRpdGFibGUgPSAocGFyYW1zOiBhbnkpID0+IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhciBuYW1lID0gcGFyYW1zLm5vZGUuZGF0YS5uYW1lO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcGFyYW1zLmRhdGEubmFtZSA9IHBhcmFtcy5ub2RlLmRhdGEubmFtZTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiBuYW1lO1xyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgY29sdW1uRGVmLm5ld1ZhbHVlSGFuZGxlciA9IChwYXJhbXM6IGFueSkgPT4ge1xyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmIChkYXRhID09ICd0ZXh0Jykge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxldCB2YWx1ZUFzRmxvYXQgPSBwYXJhbXMubmV3VmFsdWU7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcGFyYW1zLmRhdGFbcGFyYW1zLmNvbERlZi5maWVsZF0gPSB2YWx1ZUFzRmxvYXQ7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxldCB2YWx1ZUFzRmxvYXQgPSBwYXJzZUZsb2F0KHBhcmFtcy5uZXdWYWx1ZSk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcGFyYW1zLmRhdGFbcGFyYW1zLmNvbERlZi5maWVsZF0gPSB2YWx1ZUFzRmxvYXQ7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhwYXJhbXMuZGF0YVtwYXJhbXMuY29sRGVmLmZpZWxkXSwgXCJwYXJhbXMuZGF0YVtwYXJhbXMuY29sRGVmLmZpZWxkXVwiKTtcclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyByZXR1cm4gdHJ1ZTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgbmV3Q29sdW1uRGF0YS5wdXNoKGNvbHVtbkRlZik7XHJcbiAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICB0aGlzLmdyaWRPcHRpb25zLmNvbHVtbkFwaS5zZXRWYWx1ZUNvbHVtbnMobmV3Q29sdW1uRGF0YSk7XHJcbiAgICAgICAgfSBlbHNlIGlmICh0aGlzLmRpc3BsYXlFZGl0YWJsZSkge1xyXG4gICAgICAgICAgICB0aGlzLmVkaXRpbmdNb2RlRW5hYmxlZCA9ICF0aGlzLmVkaXRpbmdNb2RlRW5hYmxlZDtcclxuICAgICAgICAgICAgdGhpcy5fc2luZ2xlQ2xpY2tFZGl0ID0gIXRoaXMuX3NpbmdsZUNsaWNrRWRpdDtcclxuICAgICAgICAgICAgbGV0IF9jb2x1bW5zID0gdGhpcy5ncmlkT3B0aW9ucy5jb2x1bW5BcGkuZ2V0QWxsRGlzcGxheWVkQ29sdW1ucygpO1xyXG4gICAgICAgICAgICBsZXQgbmV3Q29sdW1uRGF0YSA9IFtdO1xyXG4gICAgICAgICAgICBfY29sdW1ucy5mb3JFYWNoKChjb2x1bW46IGFueSkgPT4ge1xyXG4gICAgICAgICAgICAgICAgbGV0IGNvbHVtbkRlZiA9IGNvbHVtbj8uZ2V0Q29sRGVmKCk7XHJcbiAgICAgICAgICAgICAgICBpZiAoY29sdW1uRGVmLmNhbkVkaXQgPT0gdHJ1ZSkge1xyXG4gICAgICAgICAgICAgICAgICAgIGNvbHVtbkRlZi52YWx1ZUdldHRlciA9IGZ1bmN0aW9uIChwYXJhbXMpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgdmFyIHZhbHVlID0gcGFyYW1zLmRhdGFbcGFyYW1zLmNvbERlZi5maWVsZF07XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGlmIChkYXRhID09ICd0ZXh0Jykge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIHZhbHVlO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKCFpc05hTihwYXJzZUZsb2F0KHZhbHVlKSkpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gdmFsdWU7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiAnJztcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbHVtbkRlZi5jZWxsQ2xhc3NSdWxlcyA9IHt9LFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBjb2x1bW5EZWYuY2VsbFJlbmRlcmVyUGFyYW1zID0ge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgc2hvdWxkQmVFZGl0aW5nOiAoKSA9PiB0aGlzLmVkaXRpbmdNb2RlRW5hYmxlZCxcclxuICAgICAgICAgICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgY29sdW1uRGVmLmVkaXRhYmxlID0gKHBhcmFtczogYW55KSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gZmFsc2U7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIG5ld0NvbHVtbkRhdGEucHVzaChjb2x1bW5EZWYpO1xyXG4gICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgdGhpcy5ncmlkT3B0aW9ucy5jb2x1bW5BcGkuc2V0VmFsdWVDb2x1bW5zKG5ld0NvbHVtbkRhdGEpO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICBzZXRBdHRlbmRhbmNlU3RhZmYoZGlzcGxheUVkaXRUYWJsZSkge1xyXG4gICAgICAgIGlmIChkaXNwbGF5RWRpdFRhYmxlKSB7XHJcbiAgICAgICAgICAgIHRoaXMuZ3JpZE9wdGlvbnMuY29udGV4dC5hY3Rpb24gPSAnZWRpdCc7XHJcbiAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgdGhpcy5ncmlkT3B0aW9ucy5jb250ZXh0LmFjdGlvbiA9ICd2aWV3JztcclxuICAgICAgICB9XHJcbiAgICAgICAgbGV0IF9jb2x1bW5zID0gdGhpcy5ncmlkT3B0aW9ucy5jb2x1bW5BcGkuZ2V0QWxsRGlzcGxheWVkQ29sdW1ucygpO1xyXG4gICAgICAgIHRoaXMuZ3JpZE9wdGlvbnMuY29sdW1uQXBpLnNldFZhbHVlQ29sdW1ucyhfY29sdW1ucyk7XHJcbiAgICAgICAgdGhpcy5fc2hvd0xvYWRpbmdPdmVybGF5KGZhbHNlKTtcclxuICAgIH1cclxuXHJcbiAgICBzZXRTdHVkZW50TWVhbChkaXNwbGF5RWRpdFRhYmxlKSB7XHJcbiAgICAgICAgaWYgKGRpc3BsYXlFZGl0VGFibGUpIHtcclxuICAgICAgICAgICAgdGhpcy5ncmlkT3B0aW9ucy5jb250ZXh0Lm1vZGUgPSAnZWRpdCc7XHJcbiAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgdGhpcy5ncmlkT3B0aW9ucy5jb250ZXh0Lm1vZGUgPSAndmlldyc7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGxldCBfY29sdW1ucyA9IHRoaXMuZ3JpZE9wdGlvbnMuY29sdW1uQXBpLmdldEFsbERpc3BsYXllZENvbHVtbnMoKTtcclxuICAgICAgICB0aGlzLmdyaWRPcHRpb25zLmNvbHVtbkFwaS5zZXRWYWx1ZUNvbHVtbnMoX2NvbHVtbnMpO1xyXG4gICAgICAgIHRoaXMuX3Nob3dMb2FkaW5nT3ZlcmxheShmYWxzZSk7XHJcbiAgICB9XHJcblxyXG4gICAgLyoqKioqKioqKioqKioqKioqKioqKioqKioqKioqKiogR3JpZCBldmVudHMgKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqL1xyXG4gICAgcHVibGljIG9uR3JpZFJlYWR5KF9wYXJhbXM6IGFueSk6IHZvaWQge1xyXG4gICAgICAgIC8vIGNvbnNvbGUubG9nKCctLSBHcmlkIHN0YXRlOiBSZWFkeSAtLScsIHRoaXMuZ3JpZE9wdGlvbnMpO1xyXG4gICAgICAgIHRoaXMuZ3JpZEFwaSA9IF9wYXJhbXMuYXBpO1xyXG4gICAgICAgIHRoaXMuX2dyaWRSZWFkeUN5Y2xlKCk7XHJcbiAgICB9XHJcblxyXG4gICAgcHVibGljIG9uTW9kZWxVcGRhdGVkKF9ldmVudDogTW9kZWxVcGRhdGVkRXZlbnQpOiB2b2lkIHtcclxuICAgICAgICAvLy8gRm9yIHNlbGVjdCBhbGwgY2hlY2tib3ggY2hlY2tpbmcgb24gY2hhbmdlIHBhZ2luYXRpb24vdXBkYXRlIHJvdyBkYXRhXHJcbiAgICAgICAgaWYgKHRoaXMuX3RhYmxlU2VydmljZS5oYXNTZWxlY3Rpb25BbGwodGhpcy5jb25maWcpKSB7XHJcbiAgICAgICAgICAgIHRoaXMuX2Jyb2FkY2FzdE1vZGVsQ2hhbmdlZEV2ZW50KCk7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICBpZiAodGhpcy5faXNNb2JpbGVWaWV3KSB7XHJcbiAgICAgICAgICAgIGxldCBncmlkRWxlbWVudDogRWxlbWVudCA9IGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3IoJyMnICsgdGhpcy5ncmlkSWQgKyAnLnN0Zy10aGVtZScpO1xyXG5cclxuICAgICAgICAgICAgaWYgKGdyaWRFbGVtZW50ICE9PSBudWxsKSB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLl9zZXRNb2JpbGVIZWlnaHQoZ3JpZEVsZW1lbnQpO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIHB1YmxpYyBvblJvd0NsaWNrZWQoX3BhcmFtczogUm93RXZlbnQpOiB2b2lkIHtcclxuICAgICAgICAvLyBjb25zb2xlLmxvZyhcIi0tIEdyaWQgc3RhdGU6IFJvdyBjbGlja2VkIC0tXCIsIF9wYXJhbXMpO1xyXG4gICAgICAgIGlmICh0aGlzLl9pc0NsaWNrVmFsaWQoX3BhcmFtcy5ldmVudCkgJiYgdHlwZW9mIHRoaXMuY29uZmlnLmNsaWNrICE9PSAndW5kZWZpbmVkJyAmJiAhdGhpcy5lZGl0VGFibGUpIHtcclxuICAgICAgICAgICAgc3dpdGNoICh0aGlzLmNvbmZpZy5jbGljay50eXBlKSB7XHJcbiAgICAgICAgICAgICAgICBjYXNlICdzZWxlY3Rpb24nOlxyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuX2dyaWRTZWxlY3Rpb25DeWNsZShfcGFyYW1zLm5vZGUpO1xyXG4gICAgICAgICAgICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgICAgICAgICAgY2FzZSAncm91dGVyJzpcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLl9ncmlkQ2xpY2tOYXZpZ2F0ZUN5Y2xlKF9wYXJhbXMubm9kZSk7XHJcbiAgICAgICAgICAgICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgICAgICAgICBkZWZhdWx0OlxyXG4gICAgICAgICAgICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICBpZiAodHlwZW9mIHRoaXMuY29uZmlnLmNsaWNrLmNhbGxiYWNrICE9PSAndW5kZWZpbmVkJykge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5jb25maWcuY2xpY2suY2FsbGJhY2soKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICAvKioqKioqKioqKioqKioqKioqKioqKioqKioqKiogQnV0dG9uIGZ1bmN0aW9ucyAqKioqKioqKioqKioqKioqKioqKioqKioqKioqKiovXHJcbiAgICBwdWJsaWMgb25CdXR0b25DbGlja2VkKF9idXR0b246IElUYWJsZUJ1dHRvbik6IHZvaWQge1xyXG4gICAgICAgIGxldCBidXR0b25FdmVudDogS2RUYWJsZUJ1dHRvbkV2ZW50ID0gbmV3IEtkVGFibGVCdXR0b25FdmVudChfYnV0dG9uKTtcclxuICAgICAgICB0aGlzLl9wcm9jZXNzRXZlbnRQYXJhbXM8S2RUYWJsZUJ1dHRvbkV2ZW50PignYnV0dG9uJywgYnV0dG9uRXZlbnQpO1xyXG4gICAgfVxyXG5cclxuICAgIC8qKioqKioqKioqKioqKioqKioqKioqKioqKioqIFByaXZhdGUgZnVuY3Rpb25zICoqKioqKioqKioqKioqKioqKioqKioqKioqKioqKi9cclxuICAgIC8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vXHJcbiAgICAvLy8gR3JpZCBjeWNsZXNcclxuICAgIC8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vXHJcbiAgICBwcml2YXRlIF9ncmlkSW5pdEN5Y2xlKCk6IHZvaWQge1xyXG4gICAgICAgIGlmICh0eXBlb2YgdGhpcy5jb25maWcgIT09ICd1bmRlZmluZWQnKSB7XHJcbiAgICAgICAgICAgIHRoaXMuX2luaXRHcmlkU2VydmljZSh0aGlzLmNvbmZpZy5sb2FkVHlwZSk7XHJcbiAgICAgICAgICAgIHRoaXMuX3VwZGF0ZUdyaWRDb25maWcodGhpcy5jb25maWcpO1xyXG4gICAgICAgICAgICB0aGlzLl9zZXRHcmlkT3B0aW9ucyh0aGlzLmNvbmZpZyk7XHJcbiAgICAgICAgICAgIHRoaXMuX3NldHVwU3Vic2NyaXB0aW9uRXZlbnRzKCk7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICBpZiAodHlwZW9mIHRoaXMuY29sdW1uICE9PSAndW5kZWZpbmVkJykge1xyXG4gICAgICAgICAgICB0aGlzLl9zZXRDb2x1bW5EZWYodGhpcy5jb2x1bW4pO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgaWYgKHR5cGVvZiB0aGlzLnJvdyAhPT0gJ3VuZGVmaW5lZCcpIHtcclxuICAgICAgICAgICAgdGhpcy5fc2V0Um93RGF0YSh0aGlzLnJvdyk7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX2dyaWRSZWFkeUN5Y2xlKCk6IHZvaWQge1xyXG4gICAgICAgIHRoaXMuX2luaXRJVGFibGVBcGkoKTtcclxuXHJcbiAgICAgICAgaWYgKHRoaXMuX3RhYmxlU2VydmljZS5pc0VudGVycHJpc2VNb2RlbCh0aGlzLmNvbmZpZy5sb2FkVHlwZSkpIHtcclxuICAgICAgICAgICAgdGhpcy5fZ3JpZFJlYWR5RW50ZXJwcmlzZUN5Y2xlKCk7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICB0aGlzLl9ncmlkUmVhZHlET01DeWNsZSgpO1xyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX2dyaWRSZWFkeUVudGVycHJpc2VDeWNsZSgpOiB2b2lkIHtcclxuICAgICAgICB0aGlzLl9jbGVhckRhdGFzb3VyY2UoKTtcclxuICAgICAgICB0aGlzLl9nZW5lcmF0ZUVudGVycHJpc2VEYXRhc291cmNlKCk7XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfZ3JpZFJlYWR5RE9NQ3ljbGUoKTogdm9pZCB7XHJcbiAgICAgICAgdGhpcy5fdXBkYXRlUGFyZW50Tm9kZUNTUygpO1xyXG4gICAgICAgIHRoaXMuX3NldEhlaWdodCgpO1xyXG4gICAgICAgIHRoaXMuX3Jlc2l6ZUNvbHVtbigpO1xyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX2dyaWRTZWxlY3Rpb25DeWNsZShfcm93Tm9kZTogUm93Tm9kZSk6IHZvaWQge1xyXG4gICAgICAgIGlmICh0eXBlb2YgdGhpcy5jb25maWcuc2VsZWN0aW9uID09PSAndW5kZWZpbmVkJykge1xyXG4gICAgICAgICAgICBjb25zb2xlLmVycm9yKCdLZFRhYmxlIGVycm9yOiBVc2VyIGhhdmUgc2V0IGNsaWNrIHR5cGUgdG8gYmUgc2VsZWN0aW9uIGJ1dCBubyBzZWxlY3Rpb24gaXMgZGVmaW5lZC4gRG8geW91IG1lYW4gY2xpY2sgdHlwZSB0byByb3V0ZXI/Jyk7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGVsc2UgaWYgKHRoaXMuY29uZmlnLnNlbGVjdGlvbi50eXBlID09PSAnc2luZ2xlJykge1xyXG4gICAgICAgICAgICBpZiAodGhpcy5jb25maWcuc2VsZWN0aW9uLnZhbHVlLmluZGV4T2YoX3Jvd05vZGUuaWQpIDwgMCkge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5ncmlkT3B0aW9ucy5hcGkuZGVzZWxlY3RBbGwoKTtcclxuICAgICAgICAgICAgICAgIF9yb3dOb2RlLnNlbGVjdFRoaXNOb2RlKHRydWUpO1xyXG5cclxuICAgICAgICAgICAgICAgIHRoaXMuY29uZmlnLnNlbGVjdGlvbi52YWx1ZS5zcGxpY2UoMCwgdGhpcy5jb25maWcuc2VsZWN0aW9uLnZhbHVlLmxlbmd0aCk7XHJcbiAgICAgICAgICAgICAgICB0aGlzLmNvbmZpZy5zZWxlY3Rpb24udmFsdWUucHVzaChfcm93Tm9kZS5kYXRhLmlkKTtcclxuXHJcbiAgICAgICAgICAgICAgICB0aGlzLl9icm9hZGNhc3RNb2RlbENoYW5nZWRFdmVudCgpO1xyXG4gICAgICAgICAgICAgICAgdGhpcy5fdXBkYXRlU2VsZWN0aW9uTm9kZXMoX3Jvd05vZGUpO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICBsZXQgc2VsZWN0aW9uOiBib29sZWFuID0gIV9yb3dOb2RlLmlzU2VsZWN0ZWQoKTtcclxuICAgICAgICAgICAgX3Jvd05vZGUuc2VsZWN0VGhpc05vZGUoc2VsZWN0aW9uKTtcclxuXHJcbiAgICAgICAgICAgIHRoaXMuX2Jyb2FkY2FzdE1vZGVsQ2hhbmdlZEV2ZW50KCk7XHJcblxyXG4gICAgICAgICAgICBpZiAoc2VsZWN0aW9uKSB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLmNvbmZpZy5zZWxlY3Rpb24udmFsdWUucHVzaChfcm93Tm9kZS5kYXRhLmlkKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgICAgIHRoaXMuY29uZmlnLnNlbGVjdGlvbi52YWx1ZS5zcGxpY2UodGhpcy5jb25maWcuc2VsZWN0aW9uLnZhbHVlLmluZGV4T2YoX3Jvd05vZGUuZGF0YS5pZCksIDEpO1xyXG4gICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICB0aGlzLl91cGRhdGVTZWxlY3Rpb25Ob2Rlcyhfcm93Tm9kZSk7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX2dyaWRTZXRSb3dDeWNsZSgpOiB2b2lkIHtcclxuICAgICAgICBpZiAodHlwZW9mIHRoaXMuY29uZmlnLnNlbGVjdGlvbiAhPT0gJ3VuZGVmaW5lZCcgJiYgdHlwZW9mIHRoaXMuY29uZmlnLnNlbGVjdGlvbi50eXBlICE9PSAndW5kZWZpbmVkJykge1xyXG4gICAgICAgICAgICB0aGlzLl9wcm9jZXNzSW5pdGlhbFNlbGVjdGlvbigpO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgZWxzZSBpZiAodGhpcy5fdGFibGVTZXJ2aWNlLmhhc0lucHV0VHlwZSh0aGlzLmNvbHVtbiwgJ2lucHV0JykpIHtcclxuICAgICAgICAgICAgdGhpcy5fZW1pdElucHV0VXBkYXRlRXZlbnQoKTtcclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfZ3JpZENsaWNrTmF2aWdhdGVDeWNsZShfcm93Tm9kZTogUm93Tm9kZSk6IHZvaWQge1xyXG4gICAgICAgIGlmICh0eXBlb2YgdGhpcy5jb25maWcuY2xpY2sucGF0aE1hcCAhPT0gJ3VuZGVmaW5lZCcpIHtcclxuICAgICAgICAgICAgaWYgKHR5cGVvZiB0aGlzLmNvbmZpZy5hY3Rpb24gIT09ICd1bmRlZmluZWQnICYmXHJcbiAgICAgICAgICAgICAgICB0eXBlb2YgdGhpcy5jb25maWcuYWN0aW9uLmxpc3QgIT09ICd1bmRlZmluZWQnKSB7XHJcbiAgICAgICAgICAgICAgICBsZXQgcm91dGVyUGF0aDogc3RyaW5nID0gJyc7XHJcblxyXG4gICAgICAgICAgICAgICAgZm9yIChsZXQgaTogbnVtYmVyID0gMDsgaSA8IHRoaXMuY29uZmlnLmFjdGlvbi5saXN0Lmxlbmd0aDsgKytpKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgbGV0IGFjdGlvbkl0ZW06IElUYWJsZURyb3Bkb3duQWN0aW9uID0gdGhpcy5jb25maWcuYWN0aW9uLmxpc3RbaV07XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIGlmIChhY3Rpb25JdGVtLnR5cGUudG9Mb3dlckNhc2UoKSA9PT0gdGhpcy5jb25maWcuY2xpY2sucGF0aE1hcC50b0xvd2VyQ2FzZSgpKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHJvdXRlclBhdGggPSB0aGlzLl90YWJsZVNlcnZpY2UuZ2V0Um91dGVyUGxhY2Vob2xkZXJQYXRoKF9yb3dOb2RlLCBhY3Rpb25JdGVtLnBhdGgpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBicmVhaztcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICAgICAgaWYgKHJvdXRlclBhdGggIT09ICcnKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5fcm91dGVyLm5hdmlnYXRlKFtyb3V0ZXJQYXRoXSk7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgICAgICAgICBjb25zb2xlLndhcm4oJ0tkVGFibGUgd2FybmluZzogVGFibGUgcm91dGVyIHBhdGhNYXAgbm90IGZvdW5kLiBwYXRoTWFwIHNldCB0bzonLCB0aGlzLmNvbmZpZy5jbGljay5wYXRoTWFwKTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgICAgIGNvbnNvbGUuZXJyb3IoJ0tkVGFibGUgZXJyb3I6IFRhYmxlIGNsaWNrIGV2ZW50IHNldCB0byByb3V0ZXIgcGF0aE1hcCBidXQgbm8gYWN0aW9uIGxpc3QgaXMgZGVmaW5lZC4gRG8geW91IG1lYW4gcGF0aCBwcm9wZXJ0eSBpbnN0ZWFkIG9mIHBhdGhNYXAgcHJvcGVydHk/Jyk7XHJcbiAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgfVxyXG4gICAgICAgIGVsc2UgaWYgKHR5cGVvZiB0aGlzLmNvbmZpZy5jbGljay5wYXRoICE9PSAndW5kZWZpbmVkJykge1xyXG4gICAgICAgICAgICB0aGlzLl9yb3V0ZXIubmF2aWdhdGUoW3RoaXMuY29uZmlnLmNsaWNrLnBhdGhdKTtcclxuICAgICAgICB9XHJcbiAgICAgICAgZWxzZSB7XHJcbiAgICAgICAgICAgIGNvbnNvbGUuZXJyb3IoJ0tkVGFibGUgZXJyb3I6IFRhYmxlIGNsaWNrIGV2ZW50IHR5cGUgc2V0IGF0IHJvdXRlciBidXQgbm8gcGF0aCAvIHBhdGhNYXAgaXMgcHJvdmlkZWQuIERvIHlvdSBtZWFuIGNsaWNrIHR5cGUgc2VsZWN0aW9uIC8gbm9uZT8nKTtcclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy9cclxuICAgIC8vIERpc3BsYXkgLyBET00gZnVuY3Rpb25cclxuICAgIC8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vXHJcblxyXG4gICAgcHJpdmF0ZSBfc2hvd0xvYWRpbmdPdmVybGF5KF90b2dnbGU6IGJvb2xlYW4pOiB2b2lkIHtcclxuICAgICAgICB0aGlzLmRpc3BsYXlMb2FkaW5nID0gX3RvZ2dsZTtcclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF91cGRhdGVQYXJlbnROb2RlQ1NTKCk6IHZvaWQge1xyXG4gICAgICAgIHRoaXMuX3Zjci5lbGVtZW50Lm5hdGl2ZUVsZW1lbnQucGFyZW50Tm9kZS5jbGFzc05hbWUgKz0gJyBoYXMtYWdncmlkJztcclxuICAgICAgICBpZiAodGhpcy5fZGlyZWN0aW9uID09PSAncnRsJykge1xyXG4gICAgICAgICAgICBkb2N1bWVudC5xdWVyeVNlbGVjdG9yKCdib2R5Jykuc3R5bGUuY3NzVGV4dCArPSAnLS1rZHRhYmxlLWhlYWRlci10ZXh0LWFsaWduOiByaWdodDsnO1xyXG4gICAgICAgICAgICBsZXQgcGFnaW5nQnV0dG9uID0gZG9jdW1lbnQuZ2V0RWxlbWVudHNCeVRhZ05hbWUoXCJidXR0b25cIik7XHJcblxyXG4gICAgICAgICAgICBmb3IgKHZhciBpID0gMDsgaSA8IHBhZ2luZ0J1dHRvbi5sZW5ndGg7IGkrKykge1xyXG4gICAgICAgICAgICAgICAgaWYgKHBhZ2luZ0J1dHRvbltpXS5jbGFzc05hbWUgPT0gJ2FnLXBhZ2luZy1idXR0b24tcnRsJyB8fCBwYWdpbmdCdXR0b25baV0uY2xhc3NOYW1lID09ICdhZy1wYWdpbmctYnV0dG9uJykge1xyXG4gICAgICAgICAgICAgICAgICAgIHBhZ2luZ0J1dHRvbltpXS5jbGFzc05hbWUgPSBcImFnLXBhZ2luZy1idXR0b24tcnRsXCI7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgdGhpcy5yaWdodERpcmVjdGlvbiA9ICdydGwnO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF9zZXRIZWlnaHQoKTogdm9pZCB7XHJcbiAgICAgICAgbGV0IGRvbUVsZVF1ZXJ5OiBzdHJpbmcgPSAnIycgKyB0aGlzLmdyaWRJZCArICcuc3RnLXRoZW1lJztcclxuICAgICAgICBsZXQgZ3JpZEVsZW1lbnQ6IEVsZW1lbnQgPSB0aGlzLl92Y3IuZWxlbWVudC5uYXRpdmVFbGVtZW50LnF1ZXJ5U2VsZWN0b3IoZG9tRWxlUXVlcnkpO1xyXG5cclxuICAgICAgICBpZiAoZ3JpZEVsZW1lbnQgIT09IG51bGwpIHtcclxuICAgICAgICAgICAgbGV0IHdpbmRvd3NXaWR0aDogbnVtYmVyID0gZG9jdW1lbnQuYm9keS5jbGllbnRXaWR0aDtcclxuXHJcbiAgICAgICAgICAgIGlmICh3aW5kb3dzV2lkdGggPD0gMTAyNCkge1xyXG4gICAgICAgICAgICAgICAgaWYgKHR5cGVvZiB0aGlzLl9pc01vYmlsZVZpZXcgPT09ICd1bmRlZmluZWQnIHx8ICF0aGlzLl9pc01vYmlsZVZpZXcpIHtcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLl9zaG93TG9hZGluZ092ZXJsYXkodHJ1ZSk7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5faXNNb2JpbGVWaWV3ID0gdHJ1ZTtcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLl9zZXRNb2JpbGVIZWlnaHQoZ3JpZEVsZW1lbnQpO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIGVsc2UgaWYgKHdpbmRvd3NXaWR0aCA+IDEwMjQpIHtcclxuICAgICAgICAgICAgICAgIGlmICh0eXBlb2YgdGhpcy5faXNNb2JpbGVWaWV3ID09PSAndW5kZWZpbmVkJyB8fCB0aGlzLl9pc01vYmlsZVZpZXcpIHtcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLl9zaG93TG9hZGluZ092ZXJsYXkodHJ1ZSk7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5faXNNb2JpbGVWaWV3ID0gZmFsc2U7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5fc2V0V2ViR3JpZEhlaWdodChncmlkRWxlbWVudCwgdGhpcy5jb25maWcuZ3JpZEhlaWdodCk7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLmdyaWRPcHRpb25zLmFwaS5zaXplQ29sdW1uc1RvRml0KCk7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgLyoqXHJcbiAgICAgKiBhZGQgYm9yZGVyIGJvdHRvbSBkeW5hbWljYWxseSBzbyB0aGF0IHdoZW4gdGhlIHJvdyBpcyBsZXNzZXIgdGhhbiBib2R5LWNvbnRhaW5lciwgdGhlcmUgd29udCBiZSBhbnkgaGFuZ2luZyBib3JkZXIgYm90dG9tXHJcbiAgICAgKiB3aGVuIHRoZSByb3cgaXMgbW9yZSB0aGFuIGNvbnRhaW5lciwgdGhlcmUgd2lsbCBiZSBhIGJvcmRlci1ib3R0b21cclxuICAgICAqL1xyXG4gICAgcHJpdmF0ZSBfc2V0VGFibGVCb3JkZXJCb3R0b20oKTogdm9pZCB7XHJcbiAgICAgICAgbGV0IGNvbnRhaW5lckVsZVF1ZXJ5OiBzdHJpbmcgPSAnIC5hZy1ib2R5LWNvbnRhaW5lcic7XHJcbiAgICAgICAgbGV0IGNvbnRhaW5lckVsZTogRWxlbWVudCA9IHRoaXMuX3Zjci5lbGVtZW50Lm5hdGl2ZUVsZW1lbnQucXVlcnlTZWxlY3Rvcihjb250YWluZXJFbGVRdWVyeSk7XHJcbiAgICAgICAgaWYgKGNvbnRhaW5lckVsZSA9PT0gbnVsbCkgcmV0dXJuO1xyXG5cclxuICAgICAgICBsZXQgdmlld3BvcnRFbGVRdWVyeTogc3RyaW5nID0gJyAuYWctYm9keS12aWV3cG9ydCc7XHJcbiAgICAgICAgbGV0IHZpZXdwb3J0RWxlOiBFbGVtZW50ID0gdGhpcy5fdmNyLmVsZW1lbnQubmF0aXZlRWxlbWVudC5xdWVyeVNlbGVjdG9yKHZpZXdwb3J0RWxlUXVlcnkpO1xyXG5cclxuICAgICAgICBpZiAoY29udGFpbmVyRWxlLmNsaWVudEhlaWdodCA+IHZpZXdwb3J0RWxlLmNsaWVudEhlaWdodCAmJlxyXG4gICAgICAgICAgICB2aWV3cG9ydEVsZS5jbGFzc05hbWUgJiZcclxuICAgICAgICAgICAgdmlld3BvcnRFbGUuY2xhc3NOYW1lLmluZGV4T2YoJ2hhcy1ib3JkZXItYm90dG9tJykgPT09IC0xXHJcbiAgICAgICAgKSB7XHJcbiAgICAgICAgICAgIHZpZXdwb3J0RWxlLmNsYXNzTmFtZSArPSAnIGhhcy1ib3JkZXItYm90dG9tJztcclxuICAgICAgICB9IGVsc2UgaWYgKGNvbnRhaW5lckVsZS5jbGllbnRIZWlnaHQgPCB2aWV3cG9ydEVsZS5jbGllbnRIZWlnaHQpIHtcclxuICAgICAgICAgICAgdmlld3BvcnRFbGUuY2xhc3NOYW1lID0gdmlld3BvcnRFbGUuY2xhc3NOYW1lLnJlcGxhY2UoL2hhcy1ib3JkZXItYm90dG9tL2dpLCAnJyk7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX3NldE1vYmlsZUhlaWdodChfZ3JpZEVsZW1lbnQ6IEVsZW1lbnQpOiB2b2lkIHtcclxuICAgICAgICBsZXQgbmV3SGVpZ2h0OiBudW1iZXIgPSAwO1xyXG5cclxuICAgICAgICBpZiAodGhpcy5jb25maWcubG9hZFR5cGUgIT09ICdpbmZpbml0ZScpIHtcclxuICAgICAgICAgICAgbGV0IGFnSGVhZGVyRWxlOiBFbGVtZW50ID0gdGhpcy5fdmNyLmVsZW1lbnQubmF0aXZlRWxlbWVudC5xdWVyeVNlbGVjdG9yKCcuYWctaGVhZGVyJyk7XHJcbiAgICAgICAgICAgIGxldCBhZ0JvZHlFbGU6IEVsZW1lbnQgPSB0aGlzLl92Y3IuZWxlbWVudC5uYXRpdmVFbGVtZW50LnF1ZXJ5U2VsZWN0b3IoJy5hZy1ib2R5LWNvbnRhaW5lcicpO1xyXG4gICAgICAgICAgICBsZXQgYWdQYWdlUGFuZWxFbGU6IEVsZW1lbnQgPSB0aGlzLl92Y3IuZWxlbWVudC5uYXRpdmVFbGVtZW50LnF1ZXJ5U2VsZWN0b3IoJ2RpdltyZWY9XCJzb3V0aFwiXScpO1xyXG4gICAgICAgICAgICBuZXdIZWlnaHQgPSAyNTtcclxuXHJcbiAgICAgICAgICAgIGlmIChhZ0hlYWRlckVsZSAhPT0gbnVsbCkge1xyXG4gICAgICAgICAgICAgICAgbmV3SGVpZ2h0ICs9IGFnSGVhZGVyRWxlLmNsaWVudEhlaWdodDtcclxuICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgaWYgKGFnQm9keUVsZSAhPT0gbnVsbCkge1xyXG4gICAgICAgICAgICAgICAgbmV3SGVpZ2h0ICs9IGFnQm9keUVsZS5jbGllbnRIZWlnaHQ7XHJcbiAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgIGlmIChhZ1BhZ2VQYW5lbEVsZSAhPT0gbnVsbCkge1xyXG4gICAgICAgICAgICAgICAgbmV3SGVpZ2h0ICs9IGFnUGFnZVBhbmVsRWxlLmNsaWVudEhlaWdodDtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgbmV3SGVpZ2h0ID0gNDAwO1xyXG4gICAgICAgIH1cclxuXHJcblxyXG4gICAgICAgIHRoaXMuX2RvbVN2Yy5zZXRFbGVtZW50U3R5bGUoX2dyaWRFbGVtZW50LCAnaGVpZ2h0JywgbmV3SGVpZ2h0ICsgJ3B4Jyk7XHJcblxyXG4gICAgICAgIHRpbWVyKDEwKS5zdWJzY3JpYmUoKCk6IHZvaWQgPT4ge1xyXG4gICAgICAgICAgICB0aGlzLmdyaWRPcHRpb25zLmFwaS5zaXplQ29sdW1uc1RvRml0KCk7XHJcbiAgICAgICAgICAgIHRoaXMuX3Nob3dMb2FkaW5nT3ZlcmxheShmYWxzZSk7XHJcbiAgICAgICAgfSk7XHJcbiAgICB9XHJcblxyXG4gICAgLyoqXHJcbiAgICAgKiBbX3NldFdlYkdyaWRIZWlnaHQgbnVtYmVyIGZvciBwaXhlbCBvciBzdHJpbmcgXCJhdXRvXCJdXHJcbiAgICAgKiAgX2NvbmZpZ0hlaWdodCBbZGVzY3JpcHRpb25dXHJcbiAgICAgKi9cclxuICAgIHByaXZhdGUgX3NldFdlYkdyaWRIZWlnaHQoX2dyaWRFbGVtZW50OiBFbGVtZW50LCBfY29uZmlnSGVpZ2h0OiBudW1iZXIgfCBzdHJpbmcpOiB2b2lkIHtcclxuICAgICAgICBpZiAodHlwZW9mIF9jb25maWdIZWlnaHQgPT09ICdudW1iZXInKSB7XHJcbiAgICAgICAgICAgIGxldCBncmlkSGVpZ2h0OiBudW1iZXIgPSA2MDA7XHJcblxyXG4gICAgICAgICAgICBpZiAodHlwZW9mIF9jb25maWdIZWlnaHQgIT09ICd1bmRlZmluZWQnKSB7XHJcbiAgICAgICAgICAgICAgICBncmlkSGVpZ2h0ID0gX2NvbmZpZ0hlaWdodDtcclxuICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgdGhpcy5fZG9tU3ZjLnNldEVsZW1lbnRTdHlsZShfZ3JpZEVsZW1lbnQsICdoZWlnaHQnLCBncmlkSGVpZ2h0ICsgJ3B4Jyk7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGVsc2UgaWYgKF9jb25maWdIZWlnaHQgPT09ICdhdXRvJykge1xyXG4gICAgICAgICAgICB0aGlzLmRpc3BsYXlGdWxsID0gdHJ1ZTtcclxuICAgICAgICB9XHJcbiAgICAgICAgLy8gZWxzZSBpZiAoX2NvbmZpZ0hlaWdodCA9PT0gJ3Jvd0hlaWdodCcpIHtcclxuICAgICAgICAvLyAgICAgdGhpcy5ncmlkT3B0aW9ucy5kb21MYXlvdXQgPSAnYXV0b0hlaWdodCc7XHJcbiAgICAgICAgLy8gICAgIGRlbGV0ZSB0aGlzLmdyaWRPcHRpb25zLnJvd0hlaWdodDtcclxuICAgICAgICAvLyAgICAgZGVsZXRlIHRoaXMuZ3JpZE9wdGlvbnMuZ2V0Um93SGVpZ2h0O1xyXG4gICAgICAgIC8vIH1cclxuXHJcbiAgICAgICAgdGltZXIoKS5zdWJzY3JpYmUoKCk6IHZvaWQgPT4ge1xyXG4gICAgICAgICAgICB0aGlzLmdyaWRPcHRpb25zLmFwaS5zaXplQ29sdW1uc1RvRml0KCk7XHJcbiAgICAgICAgICAgIHRoaXMuX3Nob3dMb2FkaW5nT3ZlcmxheShmYWxzZSk7XHJcbiAgICAgICAgfSk7XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfaXNDbGlja1ZhbGlkKF9ldmVudDogRXZlbnQpOiBib29sZWFuIHtcclxuICAgICAgICBsZXQgdGFyZ2V0RWxlbWVudDogSFRNTEVsZW1lbnQgPSA8SFRNTEVsZW1lbnQ+X2V2ZW50LnRhcmdldDtcclxuICAgICAgICBsZXQgaW52YWxpZExpc3Q6IEFycmF5PHN0cmluZz4gPSBbJ2FjdGlvbi1idG4nLCAnY2hlY2tib3gtcmFkaW8taW5wdXQnLCAnZmEtY2hldnJvbi1kb3duJ107XHJcblxyXG4gICAgICAgIGZvciAobGV0IGk6IG51bWJlciA9IDA7IGkgPCBpbnZhbGlkTGlzdC5sZW5ndGg7IGkrKykge1xyXG4gICAgICAgICAgICBpZiAodGFyZ2V0RWxlbWVudC5jbGFzc0xpc3QuY29udGFpbnMoaW52YWxpZExpc3RbaV0pKSB7XHJcbiAgICAgICAgICAgICAgICByZXR1cm4gZmFsc2U7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIHJldHVybiB0cnVlO1xyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX3Jlc2l6ZUNvbHVtbihfaXNSZXNpemVUb0NvbnRlbnQ6IGJvb2xlYW4gPSBmYWxzZSk6IHZvaWQge1xyXG4gICAgICAgIGlmICh0aGlzLl90YWJsZVNlcnZpY2UuaXNBcGlSZWFkeSh0aGlzLmdyaWRPcHRpb25zKSkge1xyXG4gICAgICAgICAgICB0aW1lcigxMCkuc3Vic2NyaWJlKCgpOiB2b2lkID0+IHtcclxuICAgICAgICAgICAgICAgIChfaXNSZXNpemVUb0NvbnRlbnQpID8gdGhpcy5fcmVzaXplQ29sdW1uVG9Db250ZW50KCkgOiB0aGlzLmdyaWRPcHRpb25zLmFwaS5zaXplQ29sdW1uc1RvRml0KCk7XHJcbiAgICAgICAgICAgICAgICB0aGlzLm9uRXhwb3J0UG9zc2libGUuZW1pdCh0cnVlKTtcclxuICAgICAgICAgICAgICAgIHRoaXMuX3Nob3dMb2FkaW5nT3ZlcmxheShmYWxzZSk7XHJcbiAgICAgICAgICAgIH0pO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICAvKipcclxuICAgICAqIHJlc2l6ZSBjb2x1bW4gdG8gY29sRGVmIHdpZHRoXHJcbiAgICAgKi9cclxuICAgIHByaXZhdGUgX3Jlc2l6ZUNvbHVtblRvQ29udGVudCgpOiB2b2lkIHtcclxuICAgICAgICBsZXQgYWxsQ29sdW1uSWRzOiBBcnJheTxzdHJpbmc+ID0gW107XHJcbiAgICAgICAgdGhpcy5ncmlkT3B0aW9ucy5jb2x1bW5BcGkuZ2V0QWxsRGlzcGxheWVkQ29sdW1ucygpLmZvckVhY2goKGNvbHVtbjogQ29sdW1uKSA9PiB7XHJcbiAgICAgICAgICAgIGFsbENvbHVtbklkcy5wdXNoKGNvbHVtbi5nZXRDb2xJZCgpKTtcclxuICAgICAgICB9KTtcclxuICAgICAgICB0aGlzLmdyaWRPcHRpb25zLmNvbHVtbkFwaS5hdXRvU2l6ZUNvbHVtbnMoYWxsQ29sdW1uSWRzKTtcclxuICAgIH1cclxuXHJcbiAgICAvKipcclxuICAgICAqIHBvcHVsYXRlIGR5bmFtaWMgc3R5bGluZyB2YWx1ZVxyXG4gICAgICogcGFyYW0ge0lUYWJsZUNvbmZpZ30gX2NvbmZpZzogdGFibGVDb25maWdcclxuICAgICAqL1xyXG4gICAgcHVibGljIHVwZGF0ZVN0eWxlKF9jb25maWc6IElUYWJsZUNvbmZpZyk6IHZvaWQge1xyXG4gICAgICAgIGlmICghX2NvbmZpZyB8fCAhX2NvbmZpZy5jb25maWcpIHtcclxuICAgICAgICAgICAgZG9jdW1lbnQucXVlcnlTZWxlY3RvcignYm9keScpLnN0eWxlLmNzc1RleHQgPSAnJztcclxuICAgICAgICAgICAgcmV0dXJuO1xyXG4gICAgICAgIH1cclxuICAgICAgICBsZXQgY29uZmlnOiBJU3R5bGluZ0NvbmZpZyA9IF9jb25maWcuY29uZmlnO1xyXG5cclxuICAgICAgICBsZXQgYm9keUNzczogc3RyaW5nID0gJyc7XHJcblxyXG4gICAgICAgIGJvZHlDc3MgKz0gdGhpcy5fdXBkYXRlSGVhZGVyU3R5bGUoY29uZmlnKTtcclxuXHJcbiAgICAgICAgaWYgKGNvbmZpZy5ib2R5KSB7XHJcbiAgICAgICAgICAgIGlmIChjb25maWcuYm9keS5hbHRlcm5hdGVSb3cgPT09IHRydWUpIHtcclxuICAgICAgICAgICAgICAgIGlmIChjb25maWcuYm9keS5vZGQgJiYgY29uZmlnLmJvZHkub2RkLmJhY2tncm91bmRDb2xvcikge1xyXG4gICAgICAgICAgICAgICAgICAgIGJvZHlDc3MgKz0gJy0ta2R0YWJsZS1yb3ctb2RkLWJhY2tncm91bmQ6ICcgKyBjb25maWcuYm9keS5vZGQuYmFja2dyb3VuZENvbG9yICsgJzsnO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgaWYgKGNvbmZpZy5ib2R5LmV2ZW4gJiYgY29uZmlnLmJvZHkuZXZlbi5iYWNrZ3JvdW5kQ29sb3IpIHtcclxuICAgICAgICAgICAgICAgICAgICBib2R5Q3NzICs9ICctLWtkdGFibGUtcm93LWV2ZW4tYmFja2dyb3VuZDogJyArIGNvbmZpZy5ib2R5LmV2ZW4uYmFja2dyb3VuZENvbG9yICsgJzsnO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIGlmIChjb25maWcuYm9keS5zdHlsZSkge1xyXG4gICAgICAgICAgICAgICAgaWYgKGNvbmZpZy5ib2R5LnN0eWxlLmJvcmRlcldpZHRoKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgYm9keUNzcyArPSAnLS1rZHRhYmxlLWJvZHktYm9yZGVyLXdpZHRoOiAnICsgY29uZmlnLmJvZHkuc3R5bGUuYm9yZGVyV2lkdGggKyAnOyc7XHJcbiAgICAgICAgICAgICAgICAgICAgYm9keUNzcyArPSAnLS1rZHRhYmxlLWhlYWRlci1ib3JkZXItd2lkdGg6ICcgKyBjb25maWcuYm9keS5zdHlsZS5ib3JkZXJXaWR0aCArICc7JztcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIGlmIChjb25maWcuYm9keS5zdHlsZS5ib3JkZXJDb2xvcikge1xyXG4gICAgICAgICAgICAgICAgICAgIGJvZHlDc3MgKz0gJy0ta2R0YWJsZS1ib2R5LWJvcmRlci1jb2xvcjogJyArIGNvbmZpZy5ib2R5LnN0eWxlLmJvcmRlckNvbG9yICsgJzsnO1xyXG4gICAgICAgICAgICAgICAgICAgIGJvZHlDc3MgKz0gJy0ta2R0YWJsZS1oZWFkZXItYm9yZGVyLWNvbG9yOiAnICsgY29uZmlnLmJvZHkuc3R5bGUuYm9yZGVyQ29sb3IgKyAnOyc7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICBpZiAoY29uZmlnLmJvZHkuc3R5bGUuYm9yZGVyU3R5bGUpIHtcclxuICAgICAgICAgICAgICAgICAgICBib2R5Q3NzICs9ICctLWtkdGFibGUtYm9keS1ib3JkZXItc3R5bGU6ICcgKyBjb25maWcuYm9keS5zdHlsZS5ib3JkZXJTdHlsZSArICc7JztcclxuICAgICAgICAgICAgICAgICAgICBib2R5Q3NzICs9ICctLWtkdGFibGUtaGVhZGVyLWJvcmRlci1zdHlsZTogJyArIGNvbmZpZy5ib2R5LnN0eWxlLmJvcmRlclN0eWxlICsgJzsnO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICBkb2N1bWVudC5xdWVyeVNlbGVjdG9yKCdib2R5Jykuc3R5bGUuY3NzVGV4dCA9IGJvZHlDc3M7XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfdXBkYXRlSGVhZGVyU3R5bGUoX2NvbmZpZzogSVN0eWxpbmdDb25maWcpOiBzdHJpbmcge1xyXG4gICAgICAgIGlmICghX2NvbmZpZy5oZWFkZXIgfHwgIV9jb25maWcuaGVhZGVyLnN0eWxlKSByZXR1cm4gJyc7XHJcblxyXG4gICAgICAgIGxldCBib2R5Q3NzOiBzdHJpbmcgPSAnJztcclxuICAgICAgICBsZXQgc3R5bGVOYW1lczogQXJyYXk8c3RyaW5nPiA9IFtcclxuICAgICAgICAgICAgJ2JhY2tncm91bmRDb2xvcicsXHJcbiAgICAgICAgICAgICd0ZXh0QWxpZ24nLFxyXG4gICAgICAgICAgICAndmVydGljYWxBbGlnbicsXHJcbiAgICAgICAgICAgICdjb2xvcicsXHJcbiAgICAgICAgICAgICdmb250RmFtaWx5JyxcclxuICAgICAgICAgICAgJ2ZvbnRTaXplJyxcclxuICAgICAgICAgICAgJ2ZvbnRXZWlnaHQnLFxyXG4gICAgICAgICAgICAnZm9udFN0eWxlJyxcclxuICAgICAgICAgICAgJ3RleHREZWNvcmF0aW9uJyxcclxuICAgICAgICAgICAgLy8gJ2JvcmRlcldpZHRoJyxcclxuICAgICAgICAgICAgLy8gJ2JvcmRlckNvbG9yJyxcclxuICAgICAgICAgICAgLy8gJ2JvcmRlclN0eWxlJyxcclxuICAgICAgICAgICAgJ29wYWNpdHknXHJcbiAgICAgICAgXTtcclxuICAgICAgICBmb3IgKGxldCBpOiBudW1iZXIgPSAwOyBpIDwgc3R5bGVOYW1lcy5sZW5ndGg7ICsraSkge1xyXG4gICAgICAgICAgICBsZXQgc3R5bGVOYW1lOiBzdHJpbmcgPSBzdHlsZU5hbWVzW2ldO1xyXG4gICAgICAgICAgICBsZXQgdmFsdWU6IHN0cmluZyA9IF9jb25maWcuaGVhZGVyLnN0eWxlW3N0eWxlTmFtZV07XHJcbiAgICAgICAgICAgIGlmIChzdHlsZU5hbWUgPT09ICd2ZXJ0aWNhbEFsaWduJykgdmFsdWUgPSB0aGlzLl9nZXRBbGlnbkl0ZW0odmFsdWUpO1xyXG4gICAgICAgICAgICBzdHlsZU5hbWUgPSAoc3R5bGVOYW1lID09PSAnYmFja2dyb3VuZENvbG9yJykgPyAnYmFja2dyb3VuZCcgOiBzdHlsZU5hbWUucmVwbGFjZSgvKFthLXpdKShbQS1aXSkvZywgJyQxLSQyJykudG9Mb3dlckNhc2UoKTtcclxuICAgICAgICAgICAgaWYgKHR5cGVvZiB2YWx1ZSAhPT0gJ3VuZGVmaW5lZCcpIHtcclxuICAgICAgICAgICAgICAgIGlmIChzdHlsZU5hbWUgPT09ICdib3JkZXJXaWR0aCcgJiZcclxuICAgICAgICAgICAgICAgICAgICAodHlwZW9mIHZhbHVlICE9PSAnc3RyaW5nJyB8fCB2YWx1ZS5pbmRleE9mKCdweCcpID09PSAtMSlcclxuICAgICAgICAgICAgICAgICkgdmFsdWUgKz0gJ3B4JztcclxuICAgICAgICAgICAgICAgIGJvZHlDc3MgKz0gJy0ta2R0YWJsZS1oZWFkZXItJyArIHN0eWxlTmFtZSArICc6ICcgKyB2YWx1ZSArICc7JztcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgICAgICByZXR1cm4gYm9keUNzcztcclxuICAgIH1cclxuXHJcbiAgICAvKipcclxuICAgICAqIGNvbnZlcnQgdGV4dCBhbGlnbiBpbnRvIGZsZXgtYm94IGl0ZW0gYWxpZ25cclxuICAgICAqIHBhcmFtIHtzdHJpbmd9IF92ZXJ0aWNhbEFsaWduOiB0ZXh0IHZlcnRpY2FsQWxpZ25cclxuICAgICAqL1xyXG4gICAgcHJpdmF0ZSBfZ2V0QWxpZ25JdGVtKF92ZXJ0aWNhbEFsaWduOiBzdHJpbmcpOiBzdHJpbmcge1xyXG4gICAgICAgIGlmIChfdmVydGljYWxBbGlnbiA9PT0gJ2Jhc2VsaW5lJyB8fCBfdmVydGljYWxBbGlnbiA9PT0gJ2JvdHRvbScpIHtcclxuICAgICAgICAgICAgcmV0dXJuICdmbGV4LWVuZCc7XHJcbiAgICAgICAgfSBlbHNlIGlmIChfdmVydGljYWxBbGlnbiA9PT0gJ3RvcCcpIHtcclxuICAgICAgICAgICAgcmV0dXJuICdmbGV4LXN0YXJ0JztcclxuICAgICAgICB9IGVsc2UgeyAvLyBpbmNsdWRpbmcgaW52YWxpZCBpbnB1dFxyXG4gICAgICAgICAgICBpZiAoX3ZlcnRpY2FsQWxpZ24gIT09ICdtaWRkbGUnICYmIF92ZXJ0aWNhbEFsaWduICE9PSB1bmRlZmluZWQpIHtcclxuICAgICAgICAgICAgICAgIGNvbnNvbGUud2FybignRVJST1I6IHRoZSB2ZXJ0aWNhbCBhbGlnbiB2YWx1ZSBvZiAnICsgX3ZlcnRpY2FsQWxpZ24gKyAnIGlzIG5vdCB5ZXQgcmVjb2duaXNlZCBieSBLZFRhYmxlLiBQbGVhc2Ugb25seSB1c2UgZWl0aGVyIHRvcCwgY2VudGVyIG9yIGJvdHRvbScpO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIHJldHVybiAnY2VudGVyJztcclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgLy8gcHJpdmF0ZSBfcmVmcmVzaFRhYmxlKF90YWJsZUNlbGxQYXJhbXM/OiBJVGFibGVDZWxsUGFyYW1zKTogdm9pZCB7XHJcbiAgICAvLyAgICAgaWYgKHRoaXMuX3RhYmxlU2VydmljZSAmJiB0aGlzLl90YWJsZVNlcnZpY2UuaXNBcGlSZWFkeSAmJiB0aGlzLl90YWJsZVNlcnZpY2UuaXNBcGlSZWFkeSh0aGlzLmdyaWRPcHRpb25zKSkge1xyXG4gICAgLy8gICAgICAgICBsZXQgdG9VcGRhdGVOb2RlOiBBcnJheTxSb3dOb2RlPiA9IFtdO1xyXG4gICAgLy8gICAgICAgICBsZXQgYWxsQ29sdW1uSWRzOiBBcnJheTxzdHJpbmc+ID0gW107XHJcblxyXG4gICAgLy8gICAgICAgICBpZiAoIV90YWJsZUNlbGxQYXJhbXMpIHtcclxuICAgIC8vICAgICAgICAgICAgIHRoaXMuZ3JpZE9wdGlvbnMuY29sdW1uQXBpLmdldEFsbERpc3BsYXllZENvbHVtbnMoKS5mb3JFYWNoKChjb2x1bW4pID0+IHtcclxuICAgIC8vICAgICAgICAgICAgICAgICBhbGxDb2x1bW5JZHMucHVzaChjb2x1bW4uZ2V0Q29sSWQoKSk7XHJcbiAgICAvLyAgICAgICAgICAgICB9KTtcclxuICAgIC8vICAgICAgICAgfVxyXG5cclxuICAgIC8vICAgICAgICAgdGhpcy5ncmlkT3B0aW9ucy5hcGkuZm9yRWFjaE5vZGUoKF9yb3dOb2RlOiBSb3dOb2RlKTogdm9pZCA9PiB7XHJcbiAgICAvLyAgICAgICAgICAgICBpZiAoX3RhYmxlQ2VsbFBhcmFtcyAmJiB0eXBlb2YgX3Jvd05vZGUuaWQgIT09ICd1bmRlZmluZWQnICYmIF9yb3dOb2RlLmlkID09PSBfdGFibGVDZWxsUGFyYW1zLnJvd0lkKSB7XHJcbiAgICAvLyAgICAgICAgICAgICAgICAgX3Jvd05vZGUuZGF0YVtfdGFibGVDZWxsUGFyYW1zLmNvbElkXSA9IF90YWJsZUNlbGxQYXJhbXMuZGF0YTtcclxuICAgIC8vICAgICAgICAgICAgICAgICB0b1VwZGF0ZU5vZGUucHVzaChfcm93Tm9kZSk7XHJcbiAgICAvLyAgICAgICAgICAgICB9IGVsc2Uge1xyXG4gICAgLy8gICAgICAgICAgICAgICAgIHRvVXBkYXRlTm9kZS5wdXNoKF9yb3dOb2RlKTtcclxuICAgIC8vICAgICAgICAgICAgIH1cclxuICAgIC8vICAgICAgICAgfSk7XHJcblxyXG4gICAgLy8gICAgICAgICBsZXQgcmVmcmVzaFBhcmFtczogeyByb3dOb2RlczogQXJyYXk8Um93Tm9kZT4sIGNvbHVtbnM6IEFycmF5PGFueT4gfSA9IHtcclxuICAgIC8vICAgICAgICAgICAgIHJvd05vZGVzOiB0b1VwZGF0ZU5vZGUsXHJcbiAgICAvLyAgICAgICAgICAgICBjb2x1bW5zOiAoX3RhYmxlQ2VsbFBhcmFtcykgPyBbX3RhYmxlQ2VsbFBhcmFtcy5jb2xJZF0gOiBhbGxDb2x1bW5JZHNcclxuICAgIC8vICAgICAgICAgfTtcclxuXHJcbiAgICAvLyAgICAgICAgIHRoaXMuZ3JpZE9wdGlvbnMuYXBpLnJlZnJlc2hDZWxscyhyZWZyZXNoUGFyYW1zKTtcclxuICAgIC8vICAgICB9XHJcbiAgICAvLyB9XHJcblxyXG4gICAgLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy9cclxuICAgIC8vLyBQaXZvdCBGdW5jdGlvblxyXG4gICAgLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy9cclxuICAgIHByaXZhdGUgX2lzVG9vbHBhbmVsVHlwZUNoYW5nZWQoKTogYm9vbGVhbiB7XHJcbiAgICAgICAgbGV0IGlzVHlwZUNoYW5nZWQ6IGJvb2xlYW4gPSB0cnVlO1xyXG4gICAgICAgIGlmICh0aGlzLl9wcmV2aW91c1Rvb2xwYW5lbFR5cGUpIHtcclxuICAgICAgICAgICAgaWYgKHR5cGVFeGlzdCh0aGlzLmNvbmZpZykpIHtcclxuICAgICAgICAgICAgICAgIGlzVHlwZUNoYW5nZWQgPSB0aGlzLl9wcmV2aW91c1Rvb2xwYW5lbFR5cGUgIT09IHRoaXMuY29uZmlnLnBpdm90LnRvb2xwYW5lbC50eXBlO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgaWYgKHR5cGVFeGlzdCh0aGlzLmNvbmZpZykpIHtcclxuICAgICAgICAgICAgICAgIHRoaXMuX3ByZXZpb3VzVG9vbHBhbmVsVHlwZSA9IHRoaXMuY29uZmlnLnBpdm90LnRvb2xwYW5lbC50eXBlO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgICAgIHJldHVybiBpc1R5cGVDaGFuZ2VkO1xyXG5cclxuICAgICAgICBmdW5jdGlvbiB0eXBlRXhpc3QoX2NvbmZpZykge1xyXG4gICAgICAgICAgICByZXR1cm4gX2NvbmZpZyAmJiBfY29uZmlnLnBpdm90ICYmIF9jb25maWcucGl2b3QudG9vbHBhbmVsICYmIF9jb25maWcucGl2b3QudG9vbHBhbmVsLnR5cGVcclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfY29uZmlndXJlUGl2b3REaXNwbGF5KCk6IHZvaWQge1xyXG4gICAgICAgIGxldCBpc1N0YXRlQ2hhbmdlZDogYm9vbGVhbiA9IHRydWU7XHJcbiAgICAgICAgaWYgKHRoaXMuY29uZmlnICYmIHRoaXMuY29uZmlnLnBpdm90ICYmIHRoaXMuY29uZmlnLnBpdm90LnN0YXRlICYmIHRoaXMuY29uZmlnLnBpdm90LnN0YXRlLmNvbHVtblN0YXRlKSB7XHJcbiAgICAgICAgICAgIGlzU3RhdGVDaGFuZ2VkID0gdGhpcy5jb25maWcucGl2b3Quc3RhdGUuY29sdW1uU3RhdGUubGVuZ3RoICE9PSB0aGlzLl9jdXJyZW50U3RhdGUuY29sdW1uU3RhdGUubGVuZ3RoO1xyXG4gICAgICAgIH1cclxuICAgICAgICBpZiAodGhpcy5jb25maWcubG9hZFR5cGUgIT09ICdub3JtYWwnIHx8ICh0aGlzLl9pc1Rvb2xwYW5lbFR5cGVDaGFuZ2VkKCkgPT09IGZhbHNlICYmIGlzU3RhdGVDaGFuZ2VkID09PSBmYWxzZSkpIHJldHVybjtcclxuXHJcbiAgICAgICAgbGV0IHNob3dUb29sUGFuZWw6IGJvb2xlYW4gPSBmYWxzZTtcclxuICAgICAgICBsZXQgc2hvd1Bpdm90TW9kZTogYm9vbGVhbiA9IGZhbHNlO1xyXG4gICAgICAgIGlmICh0aGlzLmNvbmZpZy5waXZvdCAmJiB0aGlzLmNvbmZpZy5waXZvdC50b29scGFuZWwpIHtcclxuICAgICAgICAgICAgc2hvd1Rvb2xQYW5lbCA9IHRoaXMuY29uZmlnLnBpdm90LnRvb2xwYW5lbC50eXBlICE9PSAnbm9uZSc7XHJcbiAgICAgICAgICAgIHNob3dQaXZvdE1vZGUgPSB0aGlzLmNvbmZpZy5waXZvdC50b29scGFuZWwudHlwZSA9PT0gJ3Bpdm90JztcclxuICAgICAgICB9XHJcbiAgICAgICAgdGhpcy5fc2hvd1Rvb2xQYW5lbChzaG93VG9vbFBhbmVsKTtcclxuICAgICAgICB0aGlzLl9zaG93UGl2b3RNb2RlKHNob3dQaXZvdE1vZGUpO1xyXG4gICAgfVxyXG5cclxuICAgIC8qKlxyXG4gICAgICogcmVzaXplIGNvbHVtbiB0byBmaXQgdGFibGUgY29udGFpbmVyIGlmIHRoZSB3aWR0aCBvZiB0aGUgY29udGVudCBjb2x1bW4gaXMgc21hbGxlciB0aGFuIGNvbnRhaW5lclxyXG4gICAgICovXHJcbiAgICBwcml2YXRlIF9waXZvdFJlc2l6ZSgpOiB2b2lkIHtcclxuICAgICAgICBsZXQgY29udGFpbmVyOiBFbGVtZW50ID0gdGhpcy5fdmNyLmVsZW1lbnQubmF0aXZlRWxlbWVudC5xdWVyeVNlbGVjdG9yKCcuYWctaGVhZGVyLWNvbnRhaW5lcicpO1xyXG4gICAgICAgIGxldCBoZWFkZXI6IEVsZW1lbnQgPSB0aGlzLl92Y3IuZWxlbWVudC5uYXRpdmVFbGVtZW50LnF1ZXJ5U2VsZWN0b3IoJy5hZy1oZWFkZXItY29udGFpbmVyIC5hZy1oZWFkZXItcm93Jyk7XHJcblxyXG4gICAgICAgIHRoaXMuX3Jlc2l6ZUNvbHVtbihoZWFkZXIuZ2V0Qm91bmRpbmdDbGllbnRSZWN0KCkud2lkdGggPiBjb250YWluZXIuZ2V0Qm91bmRpbmdDbGllbnRSZWN0KCkud2lkdGgpO1xyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX3Jlc2V0UGl2b3RDb2x1bW4oKTogdm9pZCB7XHJcbiAgICAgICAgdGhpcy5ncmlkT3B0aW9ucy5jb2x1bW5BcGkuc2V0Um93R3JvdXBDb2x1bW5zKFtdKTtcclxuICAgICAgICB0aGlzLmdyaWRPcHRpb25zLmNvbHVtbkFwaS5zZXRQaXZvdENvbHVtbnMoW10pO1xyXG4gICAgICAgIHRoaXMuZ3JpZE9wdGlvbnMuY29sdW1uQXBpLnNldFZhbHVlQ29sdW1ucyhbXSk7XHJcbiAgICAgICAgdGhpcy5ncmlkT3B0aW9ucy5jb2x1bW5BcGkuc2V0U2Vjb25kYXJ5Q29sdW1ucyhbXSk7XHJcbiAgICB9XHJcblxyXG4gICAgLyoqXHJcbiAgICAgKiBwYXNzIHN0YXRlIHRvIGFwcGxpY2F0aW9uLlxyXG4gICAgICogKGlmIHNldFN0YXRlIHdhcyB0cmlnZ2VyZWQgYmVmb3JlKSwgd2FpdCB1bnRpbCBzZXRTdGF0ZSBoYXMgZG9uZSBwcm9jZXNzaW5nXHJcbiAgICAgKiByZXR1cm4ge0lUYWJsZVBpdm90U3RhdGV9IFtkZXNjcmlwdGlvbl1cclxuICAgICAqL1xyXG4gICAgcHJpdmF0ZSBfZ2V0UGl2b3RTdGF0ZSgpOiBJVGFibGVQaXZvdFN0YXRlIHtcclxuICAgICAgICAvLyBpZiBzdGF0ZSBpcyBjaGFuZ2luZywgd2FpdCB1bnRpbCBzdGF0ZSBoYXMgYmVlbiB1cGRhdGVkIHRoZW4gZ2V0IHRoZSBtb3N0IHVwZGF0ZWQgc3RhdGVcclxuICAgICAgICBsZXQgZ2V0U3RhdGUgPSAoKTogYW55ID0+IHtcclxuICAgICAgICAgICAgdGhpcy5fY3VycmVudFN0YXRlLmNvbHVtblN0YXRlID0gdGhpcy5ncmlkT3B0aW9ucy5jb2x1bW5BcGkuZ2V0Q29sdW1uU3RhdGUoKTtcclxuICAgICAgICAgICAgdGhpcy5fY3VycmVudFN0YXRlLnBpdm90TW9kZSA9IHRoaXMuZ3JpZE9wdGlvbnMuY29sdW1uQXBpLmlzUGl2b3RNb2RlKCk7XHJcbiAgICAgICAgICAgIHRoaXMuX2N1cnJlbnRTdGF0ZS5ncm91cFN0YXRlID0gdGhpcy5ncmlkT3B0aW9ucy5jb2x1bW5BcGkuZ2V0Q29sdW1uR3JvdXBTdGF0ZSgpO1xyXG4gICAgICAgICAgICByZXR1cm4gdGhpcy5fY3VycmVudFN0YXRlO1xyXG4gICAgICAgIH07XHJcbiAgICAgICAgbGV0IGNoZWNrID0gKCk6IGJvb2xlYW4gPT4ge1xyXG4gICAgICAgICAgICByZXR1cm4gdGhpcy5faXNDaGFuZ2luZ1N0YXRlID09PSBmYWxzZTtcclxuICAgICAgICB9O1xyXG4gICAgICAgIHJldHVybiB0aGlzLndhaXQoY2hlY2ssIGdldFN0YXRlKTtcclxuICAgIH1cclxuXHJcbiAgICAvKipcclxuICAgICAqIHJlcGxhY2UgY3VycmVudCBzdGF0ZSBpZiBhIHN0YXRlIGlzIGdpdmVuLCBleHBhbmRHcm91cCBiYXNlIG9uIGNvbmZpZ1xyXG4gICAgICogc2hvdWxkIHdhaXQgdW50aWwgY29sdW1uIGlzIHByZXNlbnQuXHJcbiAgICAgKiBwYXJhbSB7SVRhYmxlUGl2b3RTdGF0ZX0gX3N0YXRlXHJcbiAgICAgKi9cclxuICAgIHByaXZhdGUgX3NldFBpdm90U3RhdGUoX3N0YXRlOiBJVGFibGVQaXZvdFN0YXRlKTogdm9pZCB7XHJcbiAgICAgICAgaWYgKHR5cGVvZiAoX3N0YXRlKSA9PT0gJ3VuZGVmaW5lZCcgfHwgIV9zdGF0ZS5oYXNPd25Qcm9wZXJ0eSgnY29sdW1uU3RhdGUnKSkgcmV0dXJuO1xyXG5cclxuICAgICAgICBsZXQgc2V0U3RhdGUgPSAoKTogdm9pZCA9PiB7XHJcbiAgICAgICAgICAgIHRoaXMuX2lzQ2hhbmdpbmdTdGF0ZSA9IHRydWU7XHJcbiAgICAgICAgICAgIGlmIChfc3RhdGUuY29sdW1uU3RhdGUubGVuZ3RoID09PSAwKSB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLl9pc0NoYW5naW5nU3RhdGUgPSBmYWxzZTtcclxuICAgICAgICAgICAgICAgIHRoaXMuX3Bpdm90UmVzaXplKCk7XHJcbiAgICAgICAgICAgICAgICByZXR1cm47XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgdGhpcy5fY3VycmVudFN0YXRlID0gT2JqZWN0LmFzc2lnbih0aGlzLl9jdXJyZW50U3RhdGUsIF9zdGF0ZSk7XHJcbiAgICAgICAgICAgIHRoaXMuZ3JpZE9wdGlvbnMuY29sdW1uQXBpLnNldENvbHVtblN0YXRlKF9zdGF0ZS5jb2x1bW5TdGF0ZSk7XHJcbiAgICAgICAgICAgIHRoaXMuZ3JpZE9wdGlvbnMuY29sdW1uQXBpLnNldFBpdm90TW9kZShfc3RhdGUucGl2b3RNb2RlIHx8IGZhbHNlKTtcclxuICAgICAgICAgICAgdGhpcy5ncmlkT3B0aW9ucy5jb2x1bW5BcGkuc2V0Q29sdW1uR3JvdXBTdGF0ZShfc3RhdGUuZ3JvdXBTdGF0ZSB8fCBbXSk7XHJcbiAgICAgICAgICAgIHRoaXMuX2lzQ2hhbmdpbmdTdGF0ZSA9IGZhbHNlO1xyXG5cclxuICAgICAgICAgICAgdGltZXIoMTAwKS5zdWJzY3JpYmUoKCk6IHZvaWQgPT4ge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5fc2V0UGl2b3RDb2x1bW5zKCk7XHJcbiAgICAgICAgICAgICAgICB0aGlzLl9leHBhbmRHcm91cCgpO1xyXG4gICAgICAgICAgICB9KTtcclxuICAgICAgICB9O1xyXG4gICAgICAgIGxldCBjaGVjayA9ICgpOiBib29sZWFuID0+IHtcclxuICAgICAgICAgICAgcmV0dXJuIHRoaXMuY29sdW1uICYmIHRoaXMuY29sdW1uLmxlbmd0aCA+IDA7XHJcbiAgICAgICAgfTtcclxuICAgICAgICB0aGlzLndhaXQoY2hlY2ssIHNldFN0YXRlKTtcclxuICAgIH1cclxuXHJcbiAgICAvKipcclxuICAgICAqIHdhaXQgZm9yIHNvbWV0aGluZyB0byBmaW5pc2ggdGhlbiBkbyBzb21ldGhpbmcsIGJyZWFrcyBhdCAxMDB0aCB0byBwcmV2ZW50IGluZmluaXRlIGxvb3BcclxuICAgICAqIHBhcmFtIHtJVGFibGVQaXZvdFN0YXRlfSBfc3RhdGVcclxuICAgICAqIHJldHVybiB7YW55fVxyXG4gICAgICovXHJcbiAgICBwcml2YXRlIHdhaXQoX2NoZWNrOiBGdW5jdGlvbiwgX2RvOiBGdW5jdGlvbiwgX2xpbWl0Q291bnRlciA9IDApOiBhbnkge1xyXG4gICAgICAgIGlmICgoX2NoZWNrKCkgJiYgdGhpcy5fdGFibGVTZXJ2aWNlLmlzQXBpUmVhZHkodGhpcy5ncmlkT3B0aW9ucykpIHx8IF9saW1pdENvdW50ZXIgPT09IDEwMCkge1xyXG4gICAgICAgICAgICBpZiAoX2xpbWl0Q291bnRlciA9PT0gMTAwKSBjb25zb2xlLmxvZygnVGltZW91dDogY2hlY2sgZmFpbHMuIHJ1bm5pbmcnLCBfZG8pO1xyXG4gICAgICAgICAgICByZXR1cm4gX2RvKCk7XHJcbiAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgdGltZXIoMTApLnN1YnNjcmliZSgoKTogdm9pZCA9PiB7XHJcbiAgICAgICAgICAgICAgICBfbGltaXRDb3VudGVyKys7XHJcbiAgICAgICAgICAgICAgICB0aGlzLndhaXQoX2NoZWNrLCBfZG8sIF9saW1pdENvdW50ZXIpO1xyXG4gICAgICAgICAgICB9KTtcclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfaXNQaXZvdEVsbUV4aXN0KF9waXZvdEVsZW1lbnQpOiBib29sZWFuIHtcclxuICAgICAgICByZXR1cm4gKFxyXG4gICAgICAgICAgICB0eXBlb2YgX3Bpdm90RWxlbWVudFsncGl2b3QnXSAhPT0gJ3VuZGVmaW5lZCcgJiZcclxuICAgICAgICAgICAgX3Bpdm90RWxlbWVudFsncGl2b3QnXSAhPT0gbnVsbCAmJlxyXG4gICAgICAgICAgICB0eXBlb2YgX3Bpdm90RWxlbWVudFsnY29sdW1uLWRyb3AnXSAhPT0gJ3VuZGVmaW5lZCcgJiZcclxuICAgICAgICAgICAgX3Bpdm90RWxlbWVudFsnY29sdW1uLWRyb3AnXSAhPT0gbnVsbFxyXG4gICAgICAgICk7XHJcbiAgICB9XHJcblxyXG4gICAgLyoqXHJcbiAgICAgKiBzaG93IHBpdm90IG1vZGUgY2hlY2tib3ggYW5kIGxhYmVsLlxyXG4gICAgICogd2hlbiBwaXZvdCBtb2RlIGlzIGhpZGRlbiwgYWxsIHBpdm90IGRhdGEgaGFzIHRvIGJlIHJlc2V0LlxyXG4gICAgICogcGFyYW0ge2Jvb2xlYW4gPSB0cnVlfSBfc2hvdzogdHJ1ZSB0byBzaG93LCBmYWxzZSB0byBoaWRlXHJcbiAgICAgKi9cclxuICAgIHByaXZhdGUgX3Nob3dQaXZvdE1vZGUoX3Nob3c6IGJvb2xlYW4gPSB0cnVlKTogdm9pZCB7XHJcbiAgICAgICAgbGV0IHNldFBpdm90TW9kZSA9ICgpOiB2b2lkID0+IHtcclxuICAgICAgICAgICAgaWYgKF9zaG93ID09PSB0cnVlKSB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLl9waXZvdEVsZW1lbnRbJ3Bpdm90J10uY2xhc3NOYW1lID0gdGhpcy5fcGl2b3RFbGVtZW50WydwaXZvdCddLmNsYXNzTmFtZS5yZXBsYWNlKC8gaGlkZGVuL2dpLCAnJyk7XHJcbiAgICAgICAgICAgICAgICBmb3IgKGxldCBpOiBudW1iZXIgPSAwOyBpIDwgdGhpcy5fcGl2b3RFbGVtZW50Wydjb2x1bW4tZHJvcCddLmxlbmd0aDsgKytpKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5fcGl2b3RFbGVtZW50Wydjb2x1bW4tZHJvcCddW2ldLmNsYXNzTmFtZSA9IHRoaXMuX3Bpdm90RWxlbWVudFsnY29sdW1uLWRyb3AnXVtpXS5jbGFzc05hbWUucmVwbGFjZSgvIGhpZGRlbi9naSwgJycpO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgdGhpcy5fc2V0UGl2b3RTdGF0ZSh0aGlzLmNvbmZpZy5waXZvdCAmJiB0aGlzLmNvbmZpZy5waXZvdC5zdGF0ZSA/IHRoaXMuY29uZmlnLnBpdm90LnN0YXRlIDoge30pO1xyXG4gICAgICAgICAgICAgICAgcmV0dXJuO1xyXG4gICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICBpZiAodGhpcy5fcGl2b3RFbGVtZW50WydwaXZvdCddICYmXHJcbiAgICAgICAgICAgICAgICB0aGlzLl9waXZvdEVsZW1lbnRbJ3Bpdm90J10uY2xhc3NOYW1lICYmXHJcbiAgICAgICAgICAgICAgICB0aGlzLl9waXZvdEVsZW1lbnRbJ3Bpdm90J10uY2xhc3NOYW1lLmluZGV4T2YoJ2hpZGRlbicpID09PSAtMVxyXG4gICAgICAgICAgICApIHtcclxuICAgICAgICAgICAgICAgIHRoaXMuX3Bpdm90RWxlbWVudFsncGl2b3QnXS5jbGFzc05hbWUgKz0gJyBoaWRkZW4nO1xyXG4gICAgICAgICAgICAgICAgZm9yIChsZXQgajogbnVtYmVyID0gMDsgaiA8IHRoaXMuX3Bpdm90RWxlbWVudFsnY29sdW1uLWRyb3AnXS5sZW5ndGg7ICsraikge1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuX3Bpdm90RWxlbWVudFsnY29sdW1uLWRyb3AnXVtqXS5jbGFzc05hbWUgKz0gJyBoaWRkZW4nO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIHRoaXMuX2VuYWJsZWRQaXZvdE1vZGUoZmFsc2UpO1xyXG5cclxuICAgICAgICAgICAgdGhpcy5fc2V0UGl2b3RTdGF0ZSh7XHJcbiAgICAgICAgICAgICAgICAnY29sdW1uU3RhdGUnOiBbXSxcclxuICAgICAgICAgICAgICAgICdwaXZvdE1vZGUnOiBmYWxzZSxcclxuICAgICAgICAgICAgICAgICdncm91cFN0YXRlJzogW11cclxuICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgIHRoaXMuX3Jlc2V0UGl2b3RDb2x1bW4oKTtcclxuICAgICAgICB9O1xyXG4gICAgICAgIGxldCBjaGVjayA9ICgpOiBib29sZWFuID0+IHtcclxuICAgICAgICAgICAgLy8gaWYgKHRoaXMuY29uZmlnLnBpdm90LnRvb2xwYW5lbC50eXBlID09PSAnbm9uZScgfHwgIXRoaXMuY29uZmlnLnBpdm90IHx8ICF0aGlzLmNvbmZpZy5waXZvdC50b29scGFuZWwpIHJldHVybiB0cnVlO1xyXG4gICAgICAgICAgICBpZiAodGhpcy5jb25maWcucGl2b3QgJiZcclxuICAgICAgICAgICAgICAgIHRoaXMuY29uZmlnLnBpdm90LnRvb2xwYW5lbCAmJlxyXG4gICAgICAgICAgICAgICAgdGhpcy5jb25maWcucGl2b3QudG9vbHBhbmVsLnR5cGUgJiZcclxuICAgICAgICAgICAgICAgIHRoaXMuY29uZmlnLnBpdm90LnRvb2xwYW5lbC50eXBlICE9PSAnbm9uZSdcclxuICAgICAgICAgICAgKSB7XHJcbiAgICAgICAgICAgICAgICBsZXQgaXNQaXZvdEVsbUV4aXN0OiBib29sZWFuID0gdGhpcy5faXNQaXZvdEVsbUV4aXN0KHRoaXMuX3Bpdm90RWxlbWVudCk7XHJcbiAgICAgICAgICAgICAgICBpZiAoaXNQaXZvdEVsbUV4aXN0ID09PSB0cnVlKSByZXR1cm4gaXNQaXZvdEVsbUV4aXN0O1xyXG5cclxuICAgICAgICAgICAgICAgIGxldCBkb21FbGVRdWVyeTogc3RyaW5nID0gJyMnICsgdGhpcy5ncmlkSWQgKyAnLnN0Zy10aGVtZSAuYWctc2lkZS1iYXInO1xyXG4gICAgICAgICAgICAgICAgdGhpcy5fcGl2b3RFbGVtZW50WydwaXZvdCddID0gdGhpcy5fdmNyLmVsZW1lbnQubmF0aXZlRWxlbWVudC5xdWVyeVNlbGVjdG9yKGRvbUVsZVF1ZXJ5ICsgJyAuYWctcGl2b3QtbW9kZS1wYW5lbCcpO1xyXG4gICAgICAgICAgICAgICAgdGhpcy5fcGl2b3RFbGVtZW50Wydjb2x1bW4tZHJvcCddID0gdGhpcy5fdmNyLmVsZW1lbnQubmF0aXZlRWxlbWVudC5xdWVyeVNlbGVjdG9yQWxsKGRvbUVsZVF1ZXJ5ICsgJyAuYWctY29sdW1uLWRyb3AnKTtcclxuICAgICAgICAgICAgICAgIHJldHVybiB0aGlzLl9pc1Bpdm90RWxtRXhpc3QodGhpcy5fcGl2b3RFbGVtZW50KTtcclxuICAgICAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgICAgIHJldHVybiB0cnVlO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfTtcclxuICAgICAgICB0aGlzLndhaXQoY2hlY2ssIHNldFBpdm90TW9kZSk7XHJcbiAgICB9XHJcblxyXG5cclxuICAgIC8qKlxyXG4gICAgICogaGlkZSBhbmQgc2hvdyB0b29scGFuZWwgKHBpdm90IG1vZGUgcGFuZWwpXHJcbiAgICAgKiBwYXJhbSB7Ym9vbGVhbn0gX3Nob3c6IHRydWUgdG8gc2hvdywgZmFsc2UgdG8gaGlkZVxyXG4gICAgICovXHJcbiAgICBwcml2YXRlIF9zaG93VG9vbFBhbmVsKF9zaG93OiBib29sZWFuKTogdm9pZCB7XHJcbiAgICAgICAgaWYgKHRoaXMuX3RhYmxlU2VydmljZS5pc0FwaVJlYWR5KHRoaXMuZ3JpZE9wdGlvbnMpKSB7XHJcbiAgICAgICAgICAgIHRpbWVyKDEwKS5zdWJzY3JpYmUoKCk6IHZvaWQgPT4ge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5ncmlkT3B0aW9ucy5hcGkuc2hvd1Rvb2xQYW5lbChfc2hvdyk7XHJcbiAgICAgICAgICAgIH0pO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICAvKipcclxuICAgICAqIGV4cGFuZCByb3cgZ3JvdXAgYmFzZSBvbiB0aGUgc3RhdHVzIHRoYXQgcGFzc2VkIGluXHJcbiAgICAgKiBwYXJhbSB7Ym9vbGVhbn0gX2V4cGFuZDogdHJ1ZSB0byBleHBhbmQsIGZhbHNlIHRvIGNvbGxhcHNlXHJcbiAgICAgKi9cclxuICAgIHByaXZhdGUgX2V4cGFuZEdyb3VwKF9leHBhbmQ/OiBib29sZWFuKTogdm9pZCB7XHJcbiAgICAgICAgaWYgKHR5cGVvZiBfZXhwYW5kID09PSAndW5kZWZpbmVkJykge1xyXG4gICAgICAgICAgICBfZXhwYW5kID0gZmFsc2U7XHJcbiAgICAgICAgICAgIGlmICh0aGlzLmNvbmZpZy5waXZvdCAmJiB0aGlzLmNvbmZpZy5waXZvdC5zdGF0ZSAmJiB0aGlzLmNvbmZpZy5waXZvdC5zdGF0ZS5leHBhbmRHcm91cCkge1xyXG4gICAgICAgICAgICAgICAgX2V4cGFuZCA9IHRoaXMuY29uZmlnLnBpdm90LnN0YXRlLmV4cGFuZEdyb3VwO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGlmICh0aGlzLl90YWJsZVNlcnZpY2UuaXNBcGlSZWFkeSh0aGlzLmdyaWRPcHRpb25zKSkge1xyXG4gICAgICAgICAgICB0aW1lcigxMCkuc3Vic2NyaWJlKCgpOiB2b2lkID0+IHtcclxuICAgICAgICAgICAgICAgIChfZXhwYW5kKSA/IHRoaXMuZ3JpZE9wdGlvbnMuYXBpLmV4cGFuZEFsbCgpIDogdGhpcy5ncmlkT3B0aW9ucy5hcGkuY29sbGFwc2VBbGwoKTtcclxuICAgICAgICAgICAgICAgIHRoaXMuX3Bpdm90UmVzaXplKCk7XHJcbiAgICAgICAgICAgIH0pO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICAvKipcclxuICAgICAqIHR1cm4gb24gYW5kIG9mZiBwaXZvdCBtb2RlXHJcbiAgICAgKiBJZiBvbiwgJ0NvbHVtbiBMYWJlbCcgd2lsbCBhcHBlYXJcclxuICAgICAqIElmIG9uLCB0aWNrIGNvbHVtbiBuYW1lIG9uIHRvb2xwYW5lbCB3aWxsIGFzc2lnbiBjb2x1bW4gdG8gJ1JvdyBHcm91cCcgLyAnVmFsdWVzJyBkZXBlbmRzIG9uIGNvbERlZlxyXG4gICAgICogSWYgb2ZmLCB0aWNrIGNvbHVtbiBuYW1lIG9uIHRvb2xwYW5lbCB3aWxsIHRyaWdnZXIgY29sdW1uIGhpZGUgYW5kIHNob3dcclxuICAgICAqIHBhcmFtIHtib29sZWFuID0gZmFsc2V9IF9lbmFibGVkOiB0cnVlIHRvIGNoZWNrLCBmYWxzZSB0byB1bmNoZWNrXHJcbiAgICAgKi9cclxuICAgIHByaXZhdGUgX2VuYWJsZWRQaXZvdE1vZGUoX2VuYWJsZWQ6IGJvb2xlYW4gPSBmYWxzZSk6IHZvaWQge1xyXG4gICAgICAgIHRoaXMuZ3JpZE9wdGlvbnMuY29sdW1uQXBpLnNldFBpdm90TW9kZShfZW5hYmxlZCk7XHJcbiAgICB9XHJcblxyXG4gICAgLy8gVE9ETzogdG8gYmUgcmV2aXNpdFxyXG4gICAgLyoqXHJcbiAgICAgKiBzdXBwcmVzc01vdmFibGVDb2x1bW5zIG9uIHBpdm90Q29sdW1ucyBhbmQgcm93R3JvdXBDb2x1bW5zXHJcbiAgICAgKiBjb2x1bW5zIG9uIHBpdm90IG1vZGUgZG9lcyBub3QgbGlzdGVuIHRvIGNvbERlZi5zdXBwcmVzc01vdmFibGVDb2x1bW5zID0gdHJ1ZVxyXG4gICAgICogaGVuY2Ugd2UgbmVlZCB0byBhY2Nlc3MgdGhlaXIgcHJpdmF0ZSB2YXJpYWJsZSBsb2NrUG9zaXRpb24gYW5kIGxvY2tQaW5uZWQgdG8gc3VwcHJlc3MgdGhlIGNvbHVtbiBtb3ZlbWVudFxyXG4gICAgICogcGFyYW0ge2FueX0gX2NvbHVtbnMgW2VpdGhlciBwYXNzZWQgaW4gZnJvbSBncmlkRXZlbnQ6IGNvbHVtbiBvciB3aWxsIGdldEFsbERpc3BsYXllZENvbHVtbnNdXHJcbiAgICAgKi9cclxuICAgIHByaXZhdGUgX3NldFBpdm90Q29sdW1ucyhfY29sdW1ucz86IGFueSk6IHZvaWQge1xyXG4gICAgICAgIGxldCBpc1Bpbm5lZDogYm9vbGVhbiA9IGZhbHNlO1xyXG4gICAgICAgIGlmICghX2NvbHVtbnMpIF9jb2x1bW5zID0gdGhpcy5ncmlkT3B0aW9ucy5jb2x1bW5BcGkuZ2V0QWxsRGlzcGxheWVkQ29sdW1ucygpO1xyXG4gICAgICAgIF9jb2x1bW5zLmZvckVhY2goKGNvbHVtbjogYW55KSA9PiB7XHJcbiAgICAgICAgICAgIHRoaXMuX3NldENvbHVtbihjb2x1bW4pO1xyXG4gICAgICAgICAgICBsZXQgY29sdW1uRGVmID0gY29sdW1uLmdldENvbERlZigpO1xyXG4gICAgICAgICAgICBpZiAoY29sdW1uRGVmLnBpdm90VmFsdWVDb2x1bW4pIHtcclxuICAgICAgICAgICAgICAgIHRoaXMuX3NldENvbHVtbihjb2x1bW5EZWYucGl2b3RWYWx1ZUNvbHVtbilcclxuICAgICAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgICAgIGlmIChjb2x1bW4ucGFyZW50KSB7XHJcbiAgICAgICAgICAgICAgICAgICAgaXNQaW5uZWQgPSB0cnVlO1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuX3NldENvbHVtbihjb2x1bW4ucGFyZW50LCBmYWxzZSk7XHJcbiAgICAgICAgICAgICAgICAgICAgY29sdW1uLnBhcmVudC5waW5uZWQgPSAnbGVmdCc7XHJcbiAgICAgICAgICAgICAgICAgICAgY29sdW1uLnBpbm5lZCA9ICdsZWZ0JztcclxuICAgICAgICAgICAgICAgICAgICBjb2x1bW5EZWYucGlubmVkID0gJ2xlZnQnO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfSk7XHJcbiAgICAgICAgaWYgKGlzUGlubmVkKSB0aGlzLl9yZXNpemVDb2x1bW4odHJ1ZSk7XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfc2V0Q29sdW1uKF9jb2x1bW46IGFueSwgX2lzU2V0Q29sRGVmOiBib29sZWFuID0gdHJ1ZSk6IHZvaWQge1xyXG4gICAgICAgIGlmIChfaXNTZXRDb2xEZWYpIHtcclxuICAgICAgICAgICAgbGV0IGNvbHVtbkRlZiA9IF9jb2x1bW4uZ2V0Q29sRGVmKCk7XHJcbiAgICAgICAgICAgIGNvbHVtbkRlZi5zdXBwcmVzc01vdmFibGUgPSB0aGlzLl9zdXBwcmVzc01vdmFibGVDb2x1bW5zO1xyXG4gICAgICAgICAgICBjb2x1bW5EZWYubG9ja1Bvc2l0aW9uID0gdGhpcy5fc3VwcHJlc3NNb3ZhYmxlQ29sdW1ucztcclxuICAgICAgICAgICAgY29sdW1uRGVmLmxvY2tQaW5uZWQgPSB0aGlzLl9zdXBwcmVzc01vdmFibGVDb2x1bW5zO1xyXG4gICAgICAgIH1cclxuICAgICAgICBpZiAoX2NvbHVtbi5zZXRNb3ZpbmcpIHtcclxuICAgICAgICAgICAgX2NvbHVtbi5zZXRNb3ZpbmcoIXRoaXMuX3N1cHByZXNzTW92YWJsZUNvbHVtbnMpO1xyXG4gICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgIF9jb2x1bW4ubW92aW5nID0gIXRoaXMuX3N1cHByZXNzTW92YWJsZUNvbHVtbnM7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIF9jb2x1bW4ubG9ja1Bvc2l0aW9uID0gdGhpcy5fc3VwcHJlc3NNb3ZhYmxlQ29sdW1ucztcclxuICAgICAgICBfY29sdW1uLmxvY2tQaW5uZWQgPSB0aGlzLl9zdXBwcmVzc01vdmFibGVDb2x1bW5zO1xyXG4gICAgfVxyXG4gICAgLy8gVE9ETzogdG8gYmUgcmV2aXNpdFxyXG5cclxuICAgIC8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vXHJcbiAgICAvLy8gQ29sdW1uL1Jvdy9Db25maWd1cmF0aW9uIEdlbmVyYXRpb25cclxuICAgIC8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vXHJcbiAgICBwcml2YXRlIF9zZXRHcmlkT3B0aW9ucyhfdGFibGVDb25maWc6IElUYWJsZUNvbmZpZyk6IHZvaWQge1xyXG4gICAgICAgIGlmIChfdGFibGVDb25maWcuaGFzT3duUHJvcGVydHkoJ3N1cHByZXNzTW92YWJsZUNvbHVtbnMnKSkgdGhpcy5fc3VwcHJlc3NNb3ZhYmxlQ29sdW1ucyA9IF90YWJsZUNvbmZpZy5zdXBwcmVzc01vdmFibGVDb2x1bW5zO1xyXG4gICAgICAgIHRoaXMuX2RpcmVjdGlvbiA9IDwncnRsJyB8ICdsdHInPnRoaXMuX2RvbVN2Yy5nZXREb2N1bWVudERpcmVjdGlvbigpO1xyXG4gICAgICAgIHRoaXMuZ3JpZE9wdGlvbnMgPSB0aGlzLl90YWJsZVNlcnZpY2UuZ2VuZXJhdGVHcmlkT3B0aW9ucyhfdGFibGVDb25maWcsIHRoaXMuX2RpcmVjdGlvbik7XHJcbiAgICAgICAgdGhpcy5ncmlkT3B0aW9ucy5jb250ZXh0WydncmlkSWQnXSA9IHRoaXMuZ3JpZElkO1xyXG4gICAgICAgIHRoaXMuZ3JpZE9wdGlvbnMuc3VwcHJlc3NNb3ZhYmxlQ29sdW1ucyA9IGZhbHNlO1xyXG4gICAgICAgIHRoaXMuZ3JpZE9wdGlvbnMub25Db2x1bW5Sb3dHcm91cENoYW5nZWQgPSAocGFyYW1zOiBhbnkpOiB2b2lkID0+IHtcclxuICAgICAgICAgICAgdGhpcy5fc2V0UGl2b3RDb2x1bW5zKHBhcmFtcy5jb2x1bW5zKTtcclxuICAgICAgICAgICAgdGhpcy5fZXhwYW5kR3JvdXAoKTtcclxuICAgICAgICB9XHJcbiAgICAgICAgdGhpcy5fdGFibGVTZXJ2aWNlLnNldEdyaWRPcHRpb25zKHRoaXMuZ3JpZE9wdGlvbnMpO1xyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX3NldENvbHVtbkRlZihfY29sRGVmQ29uZmlnOiBBcnJheTxJVGFibGVDb2x1bW4+KTogdm9pZCB7XHJcbiAgICAgICAgdGhpcy5fdGFibGVTZXJ2aWNlLnNldENvbHVtbkRlZihfY29sRGVmQ29uZmlnLCB0aGlzLmNvbmZpZywgdGhpcy5fc3VwcHJlc3NNb3ZhYmxlQ29sdW1ucyk7XHJcbiAgICAgICAgdGhpcy5fcmVzaXplQ29sdW1uKCk7XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfZW5hYmxlQ29sdW1uTW92YWJsZShfZW5hYmxlZDogYm9vbGVhbiA9IHRydWUpOiB2b2lkIHtcclxuICAgICAgICBpZiAodGhpcy5fdGFibGVTZXJ2aWNlLmlzQXBpUmVhZHkodGhpcy5ncmlkT3B0aW9ucykpIHtcclxuICAgICAgICAgICAgdGhpcy5fc3VwcHJlc3NNb3ZhYmxlQ29sdW1ucyA9IF9lbmFibGVkO1xyXG5cclxuICAgICAgICAgICAgdGhpcy5fc2V0Q29sdW1uRGVmKHRoaXMuY29sdW1uKTtcclxuICAgICAgICAgICAgaWYgKHRoaXMuY29uZmlnLmxvYWRUeXBlID09PSAnbm9ybWFsJyAmJiB0aGlzLmNvbmZpZy5waXZvdC50b29scGFuZWwudHlwZSA9PT0gJ3Bpdm90Jykge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5fc2V0UGl2b3RTdGF0ZSh0aGlzLl9jdXJyZW50U3RhdGUpO1xyXG4gICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICB0aGlzLl9waXZvdFJlc2l6ZSgpO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF9zZXRSb3dEYXRhKF9yb3dEYXRhOiBBcnJheTxhbnk+LCBfc2V0VG9HcmlkT3B0aW9uczogYm9vbGVhbiA9IHRydWUpOiB2b2lkIHtcclxuICAgICAgICAvLyB0aGlzLl90YWJsZVNlcnZpY2UudXBkYXRlUm93RGF0YVdpdGhDb2x1bW5Db25maWcoX3Jvd0RhdGEsIHRoaXMuY29sdW1uLCB0aGlzLmdyaWRJZCk7XHJcbiAgICAgICAgdGhpcy5fdGFibGVTZXJ2aWNlLnVwZGF0ZVJvd0RhdGFXaXRoQ29sdW1uKF9yb3dEYXRhLCB0aGlzLmNvbHVtbiwgdGhpcy5ncmlkSWQsIHRoaXMuZ3JpZE9wdGlvbnMpO1xyXG5cclxuICAgICAgICBpZiAoX3NldFRvR3JpZE9wdGlvbnMpIHtcclxuICAgICAgICAgICAgdGhpcy5fdGFibGVTZXJ2aWNlLnNldFJvd0RhdGEoX3Jvd0RhdGEpO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgaWYgKHRoaXMuX3RhYmxlU2VydmljZS5pc0VudGVycHJpc2VNb2RlbCh0aGlzLmNvbmZpZy5sb2FkVHlwZSkgJiYgdGhpcy5fdGFibGVTZXJ2aWNlLmlzQXBpUmVhZHkodGhpcy5ncmlkT3B0aW9ucykpIHtcclxuICAgICAgICAgICAgdGhpcy5fZ3JpZFJlYWR5RW50ZXJwcmlzZUN5Y2xlKCk7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICB0aW1lcigpLnN1YnNjcmliZSgoKTogdm9pZCA9PiB7XHJcbiAgICAgICAgICAgIHRoaXMuX2dyaWRTZXRSb3dDeWNsZSgpO1xyXG4gICAgICAgICAgICB0aGlzLl9zZXRUYWJsZUJvcmRlckJvdHRvbSgpO1xyXG4gICAgICAgIH0pO1xyXG4gICAgfVxyXG5cclxuICAgIC8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vXHJcbiAgICAvLy8gRXZlbnRzIC0gU3Vic2NyaWJlciAvIE9uIGZ1bmN0aW9uc1xyXG4gICAgLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy9cclxuICAgIHByaXZhdGUgX3Byb2Nlc3NFdmVudFBhcmFtczxUPihfZnJvbUV2ZW50OiBzdHJpbmcsIF9hZGRpdGlvbmFsUGFyYW1zOiBUKTogdm9pZCB7XHJcbiAgICAgICAgc3dpdGNoIChfZnJvbUV2ZW50KSB7XHJcbiAgICAgICAgICAgIGNhc2UgJ2RhdGFzb3VyY2UnOlxyXG4gICAgICAgICAgICBjYXNlICdzZWxlY3Rpb24nOlxyXG4gICAgICAgICAgICBjYXNlICdpbnB1dCc6XHJcbiAgICAgICAgICAgIGNhc2UgJ2J1dHRvbic6XHJcbiAgICAgICAgICAgICAgICB0aGlzLl9icm9hZGNhc3RFdmVudFBhcmFtczxUPihfYWRkaXRpb25hbFBhcmFtcyk7XHJcbiAgICAgICAgICAgICAgICBicmVhaztcclxuICAgICAgICAgICAgZGVmYXVsdDpcclxuICAgICAgICAgICAgICAgIGNvbnNvbGUuZXJyb3IoJ0tkVGFibGUgd2FybmluZzogTm8gc3VjaCBldmVudCBmb3VuZCBmb3I6ICcsIF9mcm9tRXZlbnQpO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF9icm9hZGNhc3RFdmVudFBhcmFtczxUPihfcGFyYW1zOiBUKTogdm9pZCB7XHJcbiAgICAgICAgdGhpcy5fdGFibGVJbnRFdmVudC5rZFRhYmxlRXZlbnRMaXN0KHRoaXMuY29uZmlnLmlkLCBfcGFyYW1zKTtcclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF9icm9hZGNhc3RNb2RlbENoYW5nZWRFdmVudCgpOiB2b2lkIHtcclxuICAgICAgICB0aGlzLl90YWJsZUludEV2ZW50Lm1vZGVsQ2hhbmdlZCh0aGlzLmNvbmZpZy5pZCk7XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfc2V0dXBTdWJzY3JpcHRpb25FdmVudHMoKSB7XHJcbiAgICAgICAgdGhpcy5fc3Vic2NyaXB0aW9uT2JqLnNlbGVjdE5vZGVzU3ViID0gdGhpcy5fdGFibGVJbnRFdmVudC5vblNlbGVjdGlvbkNoYW5nZWQodGhpcy5jb25maWcuaWQpLnN1YnNjcmliZSgoX3Jvd05vZGU6IFJvd05vZGUpOiB2b2lkID0+IHtcclxuICAgICAgICAgICAgdGhpcy5fdXBkYXRlU2VsZWN0aW9uTm9kZXMoX3Jvd05vZGUpO1xyXG4gICAgICAgIH0pO1xyXG5cclxuICAgICAgICB0aGlzLl9zdWJzY3JpcHRpb25PYmouZ3JpZFF1ZXN0aW9uU3ViID0gdGhpcy5fdGFibGVJbnRFdmVudC5vbklucHV0Q2hhbmdlZCh0aGlzLmNvbmZpZy5pZCkuc3Vic2NyaWJlKChfZm9ybVBhcmFtczogSVRhYmxlRm9ybUVtaXRQYXJhbXMpOiB2b2lkID0+IHtcclxuICAgICAgICAgICAgdGhpcy5fcHJvY2Vzc0lucHV0Q2hhbmdlZChfZm9ybVBhcmFtcyk7XHJcbiAgICAgICAgfSk7XHJcblxyXG4gICAgICAgIHRoaXMuX3N1YnNjcmlwdGlvbk9iai51cGRhdGVFbWl0Um93ID0gdGhpcy5fdGFibGVJbnRFdmVudC5vblVwZGF0ZUVtaXRSb3dOb2Rlcyh0aGlzLmNvbmZpZy5pZCkuc3Vic2NyaWJlKChfZGF0YTogeyBhY3Rpb246IHN0cmluZywgcm93RGF0YTogYW55IH0pOiB2b2lkID0+IHtcclxuICAgICAgICAgICAgaWYgKF9kYXRhLmFjdGlvbiA9PT0gJ2RlbGV0ZScpIHtcclxuICAgICAgICAgICAgICAgIGxldCByb3dLZXk6IHN0cmluZyA9ICh0eXBlb2YgdGhpcy5jb25maWcucm93SWRLZXkgIT09ICd1bmRlZmluZWQnKSA/IHRoaXMuY29uZmlnLnJvd0lkS2V5IDogJ2lkJztcclxuICAgICAgICAgICAgICAgIHRoaXMuX2RlbGV0ZU5vZGVGcm9tUm93RGF0YShbX2RhdGEucm93RGF0YVtyb3dLZXldXSk7XHJcbiAgICAgICAgICAgICAgICB0aGlzLl9lbWl0SW5wdXRVcGRhdGVFdmVudCgpO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfSk7XHJcbiAgICB9XHJcblxyXG4gICAgLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy9cclxuICAgIC8vLyBTZWxlY3Rpb24gLSBDaGVja2JveCAvIFJhZGlvIGZ1bmN0aW9uc1xyXG4gICAgLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy9cclxuICAgIHByaXZhdGUgX3VwZGF0ZVNlbGVjdGlvbk5vZGVzKF9yb3dOb2RlOiBSb3dOb2RlLCBfaXNJbml0aWFsPzogYm9vbGVhbik6IHZvaWQge1xyXG4gICAgICAgIGxldCB0cmlnZ2VyTm9kZTogc3RyaW5nID0gKHR5cGVvZiBfaXNJbml0aWFsICE9PSAndW5kZWZpbmVkJyAmJiBfaXNJbml0aWFsKSA/ICdpbml0aWFsJyA6ICdhbGwnO1xyXG4gICAgICAgIGlmICh0eXBlb2YgX3Jvd05vZGUgIT09ICd1bmRlZmluZWQnKSB7XHJcbiAgICAgICAgICAgIHRyaWdnZXJOb2RlID0gX3Jvd05vZGUuZGF0YS5pZDtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIGxldCBzZWxlY3Rpb25QYXJhbXM6IEtkVGFibGVTZWxlY3Rpb25VcGRhdGVFdmVudCA9IG5ldyBLZFRhYmxlU2VsZWN0aW9uVXBkYXRlRXZlbnQoKTtcclxuXHJcbiAgICAgICAgc2VsZWN0aW9uUGFyYW1zLnRyaWdnZXJOb2RlID0gdHJpZ2dlck5vZGU7XHJcbiAgICAgICAgc2VsZWN0aW9uUGFyYW1zLnNlbGVjdGVkTm9kZXMgPSB0aGlzLl90YWJsZVNlcnZpY2UudXBkYXRlU2VsZWN0aW9uVmFsdWVzKHRoaXMuZ3JpZE9wdGlvbnMucm93RGF0YSwgdGhpcy5jb25maWcuc2VsZWN0aW9uLnZhbHVlLCB0aGlzLmNvbmZpZy5zZWxlY3Rpb24ucmV0dXJuS2V5LCB0aGlzLmNvbmZpZy5sb2FkVHlwZSk7XHJcbiAgICAgICAgLy8gc2VsZWN0aW9uUGFyYW1zLnNlbGVjdGlvbiA9IChfcm93Tm9kZS5pc1NlbGVjdGVkKCkpID8gJ3NlbGVjdGVkJyA6ICd1bnNlbGVjdGVkJztcclxuXHJcbiAgICAgICAgdGhpcy5fcHJvY2Vzc0V2ZW50UGFyYW1zPEtkVGFibGVTZWxlY3Rpb25VcGRhdGVFdmVudD4oJ3NlbGVjdGlvbicsIHNlbGVjdGlvblBhcmFtcyk7XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfcHJvY2Vzc0luaXRpYWxTZWxlY3Rpb24oKTogdm9pZCB7XHJcbiAgICAgICAgdGhpcy5fdXBkYXRlU2VsZWN0aW9uTm9kZXModW5kZWZpbmVkLCB0cnVlKTtcclxuICAgIH1cclxuXHJcbiAgICAvLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vL1xyXG4gICAgLy8vIElucHV0IGZ1bmN0aW9uc1xyXG4gICAgLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy9cclxuICAgIHByaXZhdGUgX3Byb2Nlc3NJbnB1dENoYW5nZWQoX2Zvcm1QYXJhbXM6IElUYWJsZUZvcm1FbWl0UGFyYW1zKTogdm9pZCB7XHJcbiAgICAgICAgbGV0IGlucHV0UGFyYW1zOiBLZFRhYmxlSW5wdXRVcGRhdGVFdmVudCA9IG5ldyBLZFRhYmxlSW5wdXRVcGRhdGVFdmVudCgpO1xyXG5cclxuICAgICAgICBpbnB1dFBhcmFtcy5jb2xJZCA9IF9mb3JtUGFyYW1zLmNvbElkO1xyXG4gICAgICAgIGlucHV0UGFyYW1zLnJvd0lkID0gX2Zvcm1QYXJhbXMucm93SWQ7XHJcbiAgICAgICAgaW5wdXRQYXJhbXMucXVlc3Rpb25LZXkgPSBfZm9ybVBhcmFtcy5xdWVzdGlvbktleTtcclxuICAgICAgICBpbnB1dFBhcmFtcy5xdWVzdGlvbiA9IF9mb3JtUGFyYW1zLnF1ZXN0aW9uO1xyXG4gICAgICAgIGlucHV0UGFyYW1zLnZhbHVlID0gX2Zvcm1QYXJhbXMuZGF0YTtcclxuXHJcbiAgICAgICAgdGhpcy5fcHJvY2Vzc0V2ZW50UGFyYW1zPEtkVGFibGVJbnB1dFVwZGF0ZUV2ZW50PignaW5wdXQnLCBpbnB1dFBhcmFtcyk7XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfZW1pdElucHV0VXBkYXRlRXZlbnQoKTogdm9pZCB7XHJcbiAgICAgICAgbGV0IGlucHV0UGFyYW1zOiBLZFRhYmxlSW5wdXRVcGRhdGVFdmVudCA9IG5ldyBLZFRhYmxlSW5wdXRVcGRhdGVFdmVudCgpO1xyXG4gICAgICAgIHRoaXMuX3Byb2Nlc3NFdmVudFBhcmFtczxLZFRhYmxlSW5wdXRVcGRhdGVFdmVudD4oJ2lucHV0JywgaW5wdXRQYXJhbXMpO1xyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX2RlbGV0ZU5vZGVGcm9tUm93RGF0YShfZGF0YUxpc3Q6IEFycmF5PHN0cmluZz4pOiB2b2lkIHtcclxuICAgICAgICBsZXQgcm93SWRLZXk6IHN0cmluZyA9ICh0eXBlb2YgdGhpcy5jb25maWcucm93SWRLZXkgIT09ICd1bmRlZmluZWQnKSA/IHRoaXMuY29uZmlnLnJvd0lkS2V5IDogJ2lkJztcclxuXHJcbiAgICAgICAgZm9yIChsZXQgaTogbnVtYmVyID0gMDsgaSA8IF9kYXRhTGlzdC5sZW5ndGg7ICsraSkge1xyXG4gICAgICAgICAgICBmb3IgKGxldCBqOiBudW1iZXIgPSAwOyBqIDwgdGhpcy5yb3cubGVuZ3RoOyArK2opIHtcclxuICAgICAgICAgICAgICAgIGlmIChfZGF0YUxpc3RbaV0udG9TdHJpbmcoKSA9PT0gdGhpcy5yb3dbal1bcm93SWRLZXldLnRvU3RyaW5nKCkpIHtcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLnJvdy5zcGxpY2UoaiwgMSk7XHJcbiAgICAgICAgICAgICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy9cclxuICAgIC8vLyBFbnRlcnByaXNlIGRhdGFzb3VyY2UgZnVuY3Rpb25zXHJcbiAgICAvLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vL1xyXG4gICAgcHJpdmF0ZSBfY2xlYXJEYXRhc291cmNlKCk6IHZvaWQge1xyXG4gICAgICAgIGlmICh0aGlzLl90YWJsZVNlcnZpY2UuaXNBcGlSZWFkeSh0aGlzLmdyaWRPcHRpb25zKSkge1xyXG4gICAgICAgICAgICB0aGlzLmdyaWRPcHRpb25zLmFwaS5zZXRFbnRlcnByaXNlRGF0YXNvdXJjZShudWxsKTtcclxuICAgICAgICAgICAgdGhpcy5ncmlkT3B0aW9ucy5hcGkuc2V0RmlsdGVyTW9kZWwobnVsbCk7XHJcbiAgICAgICAgICAgIHRoaXMuZ3JpZE9wdGlvbnMuYXBpLnNldFNvcnRNb2RlbChudWxsKTtcclxuXHJcbiAgICAgICAgICAgIGlmICh0eXBlb2YgdGhpcy5fc3Vic2NyaXB0aW9uT2JqLmRhdGFzb3VyY2VTdWIgIT09ICd1bmRlZmluZWQnKSB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLl9zdWJzY3JpcHRpb25PYmouZGF0YXNvdXJjZVN1Yi51bnN1YnNjcmliZSgpO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX2dlbmVyYXRlRW50ZXJwcmlzZURhdGFzb3VyY2UoKTogdm9pZCB7XHJcbiAgICAgICAgbGV0IGRhdGFzb3VyY2U6IElFbnRlcnByaXNlRGF0YXNvdXJjZSA9IHtcclxuICAgICAgICAgICAgZ2V0Um93czogKF9wYXJhbXM6IElFbnRlcnByaXNlR2V0Um93c1BhcmFtcyk6IHZvaWQgPT4ge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5fc2hvd0xvYWRpbmdPdmVybGF5KHRydWUpO1xyXG5cclxuICAgICAgICAgICAgICAgIGlmICh0eXBlb2YgdGhpcy5fc3Vic2NyaXB0aW9uT2JqLmRhdGFzb3VyY2VTdWIgIT09ICd1bmRlZmluZWQnKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5fc3Vic2NyaXB0aW9uT2JqLmRhdGFzb3VyY2VTdWIudW5zdWJzY3JpYmUoKTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIHRoaXMuX3N1YnNjcmlwdGlvbk9iai5kYXRhc291cmNlU3ViID0gdGhpcy5fZ2VuZXJhdGVEYXRhc291cmNlUm93cyhfcGFyYW1zKS5zdWJzY3JpYmUoKF9yZXNwb25zZTogSVRhYmxlRGF0YXNvdXJjZVBhcmFtcyk6IHZvaWQgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgIF9wYXJhbXMuc3VjY2Vzc0NhbGxiYWNrKF9yZXNwb25zZS5yb3dzLCBfcmVzcG9uc2UudG90YWwpO1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuX3Nob3dMb2FkaW5nT3ZlcmxheShmYWxzZSk7XHJcbiAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH07XHJcblxyXG4gICAgICAgIHRoaXMuZ3JpZE9wdGlvbnMuYXBpLnNldEVudGVycHJpc2VEYXRhc291cmNlKGRhdGFzb3VyY2UpO1xyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX2dlbmVyYXRlRGF0YXNvdXJjZVJvd3MoX2RhdGFzb3VyY2VQYXJhbXM6IElFbnRlcnByaXNlR2V0Um93c1BhcmFtcyk6IE9ic2VydmFibGU8SVRhYmxlRGF0YXNvdXJjZVBhcmFtcz4ge1xyXG4gICAgICAgIHJldHVybiBuZXcgT2JzZXJ2YWJsZTxJVGFibGVEYXRhc291cmNlUGFyYW1zPigoX29ic2VydmVyOiBTdWJzY3JpYmVyPElUYWJsZURhdGFzb3VyY2VQYXJhbXM+KTogdm9pZCA9PiB7XHJcbiAgICAgICAgICAgIHN3aXRjaCAodGhpcy5jb25maWcubG9hZFR5cGUpIHtcclxuICAgICAgICAgICAgICAgIGNhc2UgJ2luZmluaXRlJzpcclxuICAgICAgICAgICAgICAgIGNhc2UgJ29uZXNob3QnOlxyXG4gICAgICAgICAgICAgICAgICAgICg8S2RUYWJsZUVudGVycHJpc2VTdmM+dGhpcy5fdGFibGVTZXJ2aWNlKS5nZW5lcmF0ZURhdGFzb3VyY2VSb3dzKF9kYXRhc291cmNlUGFyYW1zLnJlcXVlc3QsIHRoaXMuZ3JpZE9wdGlvbnMucm93RGF0YS5zbGljZSgpKS5zdWJzY3JpYmUoKF9yZXNwb25zZTogSVRhYmxlRGF0YXNvdXJjZVBhcmFtcyk6IHZvaWQgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBfb2JzZXJ2ZXIubmV4dChfcmVzcG9uc2UpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBfb2JzZXJ2ZXIuY29tcGxldGUoKTtcclxuICAgICAgICAgICAgICAgICAgICB9KTtcclxuXHJcbiAgICAgICAgICAgICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgICAgICAgICBjYXNlICdzZXJ2ZXInOlxyXG4gICAgICAgICAgICAgICAgICAgIGxldCBzZXJ2ZXJQYXJhbXM6IEtkVGFibGVEYXRhc291cmNlRXZlbnQgPSBuZXcgS2RUYWJsZURhdGFzb3VyY2VFdmVudChfZGF0YXNvdXJjZVBhcmFtcy5yZXF1ZXN0LCBfb2JzZXJ2ZXIpO1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuX3Byb2Nlc3NFdmVudFBhcmFtczxLZFRhYmxlRGF0YXNvdXJjZUV2ZW50PignZGF0YXNvdXJjZScsIHNlcnZlclBhcmFtcyk7XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgICAgICAgICAgZGVmYXVsdDpcclxuICAgICAgICAgICAgICAgICAgICBjb25zb2xlLmVycm9yKCdLZFRhYmxlIHdhcm5pbmc6IE5vIHN1Y2ggbG9hZFR5cGUgZmluZCBmb3I6ICcsIHRoaXMuY29uZmlnLmxvYWRUeXBlKTtcclxuICAgICAgICAgICAgICAgICAgICBfb2JzZXJ2ZXIuY29tcGxldGUoKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH0pO1xyXG4gICAgfVxyXG5cclxuICAgIC8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vXHJcbiAgICAvLy8gQVBJIGZ1bmN0aW9uc1xyXG4gICAgLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy9cclxuICAgIHByaXZhdGUgX2luaXRJVGFibGVBcGkoKTogdm9pZCB7XHJcbiAgICAgICAgaWYgKHR5cGVvZiB0aGlzLmFwaSAhPT0gJ3VuZGVmaW5lZCcpIHtcclxuICAgICAgICAgICAgbGV0IGFwaVBhcmFtczogYW55ID0ge1xyXG4gICAgICAgICAgICAgICAgLy8gZ3JpZE9wdGlvbnM6IHRoaXMuZ3JpZE9wdGlvbnMsXHJcbiAgICAgICAgICAgICAgICBldmVudDogdGhpcy5fdGFibGVJbnRFdmVudCxcclxuICAgICAgICAgICAgICAgIGlkOiB0aGlzLmNvbmZpZy5pZCxcclxuICAgICAgICAgICAgICAgIHJvd3M6IHRoaXMucm93LFxyXG4gICAgICAgICAgICAgICAgY29sdW1uczogdGhpcy5jb2x1bW5cclxuICAgICAgICAgICAgfTtcclxuXHJcbiAgICAgICAgICAgIHRoaXMuX3RhYmxlU2VydmljZS5nZW5lcmF0ZWRBcGlGdW5jdGlvbnModGhpcy5hcGksIGFwaVBhcmFtcyk7XHJcblxyXG4gICAgICAgICAgICAvLy8gVGVtcCBmaXggdG8gYWNjZXNzIGxvYWRpbmcgdmFyaWFibGUgLy9cclxuICAgICAgICAgICAgLyoqKioqKioqKiBHZW5lcmFsIEFQSSAqKioqKioqKioqL1xyXG4gICAgICAgICAgICB0aGlzLmFwaS5nZW5lcmFsLnNob3dMb2FkaW5nID0gKF90b2dnbGU6IGJvb2xlYW4pOiB2b2lkID0+IHtcclxuICAgICAgICAgICAgICAgIHRoaXMuZGlzcGxheUxvYWRpbmcgPSBfdG9nZ2xlO1xyXG4gICAgICAgICAgICB9O1xyXG5cclxuICAgICAgICAgICAgdGhpcy5hcGkuZ2VuZXJhbC51cGRhdGVDZWxsID0gKF90YWJsZUNlbGxQYXJhbXM6IElUYWJsZUNlbGxQYXJhbXMpOiB2b2lkID0+IHtcclxuICAgICAgICAgICAgICAgIGxldCB0b1VwZGF0ZU5vZGU6IEFycmF5PFJvd05vZGU+ID0gW107XHJcblxyXG4gICAgICAgICAgICAgICAgdGhpcy5ncmlkT3B0aW9ucy5hcGkuZm9yRWFjaE5vZGUoKF9yb3dOb2RlOiBSb3dOb2RlKTogdm9pZCA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKHR5cGVvZiBfcm93Tm9kZS5pZCAhPT0gJ3VuZGVmaW5lZCcgJiYgX3Jvd05vZGUuaWQgPT09IF90YWJsZUNlbGxQYXJhbXMucm93SWQpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgX3Jvd05vZGUuZGF0YVtfdGFibGVDZWxsUGFyYW1zLmNvbElkXSA9IF90YWJsZUNlbGxQYXJhbXMuZGF0YTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgdG9VcGRhdGVOb2RlLnB1c2goX3Jvd05vZGUpO1xyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIH0pO1xyXG5cclxuICAgICAgICAgICAgICAgIGxldCByZWZyZXNoUGFyYW1zOiB7IHJvd05vZGVzOiBBcnJheTxSb3dOb2RlPiwgY29sdW1uczogQXJyYXk8YW55PiB9ID0ge1xyXG4gICAgICAgICAgICAgICAgICAgIHJvd05vZGVzOiB0b1VwZGF0ZU5vZGUsXHJcbiAgICAgICAgICAgICAgICAgICAgY29sdW1uczogW190YWJsZUNlbGxQYXJhbXMuY29sSWRdXHJcbiAgICAgICAgICAgICAgICB9O1xyXG5cclxuICAgICAgICAgICAgICAgIHRoaXMuZ3JpZE9wdGlvbnMuYXBpLnJlZnJlc2hDZWxscyhyZWZyZXNoUGFyYW1zKTtcclxuICAgICAgICAgICAgfTtcclxuXHJcbiAgICAgICAgICAgIHRoaXMuYXBpLmdlbmVyYWwuc2VhcmNoUm93ID0gKF9zZWFyY2hUZXh0OiBzdHJpbmcpOiB2b2lkID0+IHtcclxuICAgICAgICAgICAgICAgIGlmICh0aGlzLmNvbmZpZy5sb2FkVHlwZSA9PT0gJ25vcm1hbCcpIHtcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLmdyaWRPcHRpb25zLmFwaS5zZXRRdWlja0ZpbHRlcihfc2VhcmNoVGV4dCk7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgICAgICAgICBjb25zb2xlLndhcm4oJ0tkVGFibGUgd2FybmluZzogUXVpY2sgZmlsdGVyaW5nIG9mIGRhdGEgaXMgbm90IHN1cHBvcnRlZCBmb3Igb25lc2hvdC9zZXJ2ZXIvaW5maW5pdGUgbG9hZFR5cGUuJyk7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH07XHJcblxyXG4gICAgICAgICAgICB0aGlzLmFwaS5nZW5lcmFsLmFkZFJvd3MgPSAoX3Jvd3M6IEFycmF5PGFueT4sIF9zY3JvbGxUb1Zpc2libGU6IGJvb2xlYW4gPSBmYWxzZSk6IHZvaWQgPT4ge1xyXG4gICAgICAgICAgICAgICAgLypcclxuICAgICAgICAgICAgICAgICAgICBhZy1HcmlkIGRpZCBub3QgZXhwb3J0IFJvd0RhdGFUcmFuc2FjdGlvbiBpbnRlcmZhY2UuIEludGVyZmFjZSBhczpcclxuICAgICAgICAgICAgICAgICAgICAgICAge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgYWRkOiBbXSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJlbW92ZTogW10sXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB1cGRhdGU6IFtdXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAqL1xyXG4gICAgICAgICAgICAgICAgaWYgKHR5cGVvZiB0aGlzLmNvbmZpZy5sb2FkVHlwZSA9PT0gJ3VuZGVmaW5lZCcgfHwgdGhpcy5jb25maWcubG9hZFR5cGUgPT09ICdub3JtYWwnKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgbGV0IHJvd0tleTogc3RyaW5nID0gKHR5cGVvZiB0aGlzLmNvbmZpZy5yb3dJZEtleSAhPT0gJ3VuZGVmaW5lZCcpID8gdGhpcy5jb25maWcucm93SWRLZXkgOiAnaWQnO1xyXG5cclxuICAgICAgICAgICAgICAgICAgICBmb3IgKGxldCBpOiBudW1iZXIgPSAwOyBpIDwgX3Jvd3MubGVuZ3RoOyArK2kpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5yb3cucHVzaChfcm93c1tpXSk7XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgICAgICAgICB0aGlzLl9zZXRSb3dEYXRhKHRoaXMucm93LCBmYWxzZSk7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5ncmlkT3B0aW9ucy5hcGkudXBkYXRlUm93RGF0YSh7IGFkZDogX3Jvd3Muc2xpY2UoKSB9KTtcclxuXHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKF9zY3JvbGxUb1Zpc2libGUpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5ncmlkT3B0aW9ucy5hcGkuZW5zdXJlSW5kZXhWaXNpYmxlKHRoaXMuZ3JpZE9wdGlvbnMuYXBpLmdldFJvd05vZGUoX3Jvd3NbMF1bcm93S2V5XS50b1N0cmluZygpKS5yb3dJbmRleCk7XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgZWxzZSB7XHJcbiAgICAgICAgICAgICAgICAgICAgY29uc29sZS53YXJuKCdLZFRhYmxlIHdhcm5pbmc6IEFQSSBmdW5jdGlvbjogYWRkUm93cygpIGNhbiBvbmx5IGJlIHVzZWQgZm9yIG5vcm1hbCBsb2FkVHlwZS4nKTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfTtcclxuXHJcbiAgICAgICAgICAgIHRoaXMuYXBpLmdlbmVyYWwuZGVsZXRlUm93cyA9IChfaWQ6IEFycmF5PHN0cmluZyB8IG51bWJlcj4gfCBzdHJpbmcgfCBudW1iZXIpOiB2b2lkID0+IHtcclxuICAgICAgICAgICAgICAgIGlmICh0eXBlb2YgdGhpcy5jb25maWcubG9hZFR5cGUgPT09ICd1bmRlZmluZWQnIHx8IHRoaXMuY29uZmlnLmxvYWRUeXBlID09PSAnbm9ybWFsJykge1xyXG4gICAgICAgICAgICAgICAgICAgIGxldCBkZWxldGVJZExpc3Q6IEFycmF5PHN0cmluZz4gPSBbXTtcclxuXHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKHR5cGVvZiBfaWQgPT09ICdzdHJpbmcnIHx8IHR5cGVvZiBfaWQgPT09ICdudW1iZXInKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGRlbGV0ZUlkTGlzdC5wdXNoKF9pZC50b1N0cmluZygpKTtcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgZWxzZSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGZvciAobGV0IGk6IG51bWJlciA9IDA7IGkgPCBfaWQubGVuZ3RoOyArK2kpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRlbGV0ZUlkTGlzdC5wdXNoKF9pZC50b1N0cmluZygpKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5fZGVsZXRlTm9kZUZyb21Sb3dEYXRhKGRlbGV0ZUlkTGlzdCk7XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIGxldCBrZXk6IHN0cmluZyA9IHR5cGVvZiB0aGlzLmNvbmZpZy5yb3dJZEtleSA9PT0gJ3VuZGVmaW5lZCcgPyAnaWQnIDogdGhpcy5jb25maWcucm93SWRLZXk7XHJcbiAgICAgICAgICAgICAgICAgICAgbGV0IGRlbGV0ZVJvd3M6IEFycmF5PGFueT4gPSBbXTtcclxuXHJcbiAgICAgICAgICAgICAgICAgICAgZm9yIChsZXQgaTogbnVtYmVyID0gMDsgaSA8IGRlbGV0ZUlkTGlzdC5sZW5ndGg7ICsraSkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBkZWxldGVSb3dzLnB1c2goeyBba2V5XTogZGVsZXRlSWRMaXN0W2ldIH0pO1xyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgLypcclxuICAgICAgICAgICAgICAgICAgICAgICAgYWctR3JpZCBkaWQgbm90IGV4cG9ydCBSb3dEYXRhVHJhbnNhY3Rpb24gaW50ZXJmYWNlLiBJbnRlcmZhY2UgYXM6XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYWRkOiBbXSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICByZW1vdmU6IFtdLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHVwZGF0ZTogW11cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgKi9cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgbGV0IHRyYW5zYWN0aW9uT2JqOiB7IGFkZD86IEFycmF5PGFueT4sIHJlbW92ZT86IEFycmF5PGFueT4sIHVwZGF0ZT86IEFycmF5PGFueT4gfSA9IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgcmVtb3ZlOiBkZWxldGVSb3dzXHJcbiAgICAgICAgICAgICAgICAgICAgfTtcclxuXHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5ncmlkT3B0aW9ucy5hcGkudXBkYXRlUm93RGF0YSh0cmFuc2FjdGlvbk9iaik7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5fZW1pdElucHV0VXBkYXRlRXZlbnQoKTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgICAgIGNvbnNvbGUud2FybignS2RUYWJsZSB3YXJuaW5nOiBBUEkgZnVuY3Rpb246IGFkZFJvd3MoKSBjYW4gb25seSBiZSB1c2VkIGZvciBub3JtYWwgbG9hZFR5cGUuJyk7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH07XHJcblxyXG4gICAgICAgICAgICB0aGlzLmFwaS5nZW5lcmFsLnNldEJ1dHRvbkRpc2FibGVkID0gKF9idXR0b25UeXBlOiBzdHJpbmcsIF90b0Rpc2FibGVkOiBib29sZWFuKSA9PiB7XHJcbiAgICAgICAgICAgICAgICBmb3IgKGxldCBpOiBudW1iZXIgPSAwOyBpIDwgdGhpcy5jb25maWcuYnV0dG9uLmxlbmd0aDsgKytpKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKHRoaXMuY29uZmlnLmJ1dHRvbltpXS50eXBlID09PSBfYnV0dG9uVHlwZSkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLmNvbmZpZy5idXR0b25baV0uZGlzYWJsZWQgPSBfdG9EaXNhYmxlZDtcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH07XHJcblxyXG4gICAgICAgICAgICB0aGlzLmFwaS5nZW5lcmFsLmV4cG9ydFRvRXhjZWwgPSAoX3BhcmFtczogRXhjZWxFeHBvcnRQYXJhbXMpOiB2b2lkID0+IHtcclxuICAgICAgICAgICAgICAgIGxldCBkZWZhdWx0UGFyYW1zOiBFeGNlbEV4cG9ydFBhcmFtcyA9IHtcclxuICAgICAgICAgICAgICAgICAgICBmaWxlTmFtZTogJ2ZpbGUnLFxyXG4gICAgICAgICAgICAgICAgICAgIGFsbENvbHVtbnM6IHRydWUsXHJcbiAgICAgICAgICAgICAgICAgICAgc3VwcHJlc3NUZXh0QXNDREFUQTogdHJ1ZSxcclxuICAgICAgICAgICAgICAgIH07XHJcbiAgICAgICAgICAgICAgICAvLyB4bHN4IG9ubHkgYWxsb3cgc2hlZXQgbmFtZSB0byBiZSAzMSBjaGFyYWN0ZXJzIGxvbmc7XHJcbiAgICAgICAgICAgICAgICBpZiAoX3BhcmFtcy5oYXNPd25Qcm9wZXJ0eSgnc2hlZXROYW1lJykpIF9wYXJhbXMuc2hlZXROYW1lID0gX3BhcmFtcy5zaGVldE5hbWUuc2xpY2UoMCwgMzEpO1xyXG4gICAgICAgICAgICAgICAgbGV0IHBhcmFtczogRXhjZWxFeHBvcnRQYXJhbXMgPSBPYmplY3QuYXNzaWduKHt9LCBkZWZhdWx0UGFyYW1zLCBfcGFyYW1zKTtcclxuICAgICAgICAgICAgICAgIGxldCBjb250ZW50OiBhbnkgPSB0aGlzLmdyaWRPcHRpb25zLmFwaS5nZXREYXRhQXNFeGNlbChwYXJhbXMpO1xyXG4gICAgICAgICAgICAgICAgbGV0IHdvcmtib29rOiBhbnkgPSBYTFNYLnJlYWQoY29udGVudCwgeyB0eXBlOiAnYmluYXJ5JyB9KTtcclxuICAgICAgICAgICAgICAgIGxldCB4bHN4Q29udGVudDogYW55ID0gWExTWC53cml0ZSh3b3JrYm9vaywgeyBib29rVHlwZTogJ3hsc3gnLCB0eXBlOiAnYmFzZTY0JyB9KTtcclxuICAgICAgICAgICAgICAgIGxldCBibG9iT2JqZWN0OiBCbG9iID0gdGhpcy5fdGFibGVTZXJ2aWNlLmI2NHRvQmxvYih4bHN4Q29udGVudCwgJ2FwcGxpY2F0aW9uL3ZuZC5vcGVueG1sZm9ybWF0cy1vZmZpY2Vkb2N1bWVudC5zcHJlYWRzaGVldG1sLnNoZWV0Jyk7XHJcbiAgICAgICAgICAgICAgICBzYXZlQXMoYmxvYk9iamVjdCwgcGFyYW1zLmZpbGVOYW1lICsgJy54bHN4Jyk7XHJcbiAgICAgICAgICAgIH07XHJcblxyXG4gICAgICAgICAgICB0aGlzLmFwaS5nZW5lcmFsLnJlc2l6ZUNvbHVtbiA9IChfaXNSZXNpemVUb0NvbnRlbnQ6IGJvb2xlYW4gPSBmYWxzZSk6IHZvaWQgPT4ge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5fcmVzaXplQ29sdW1uKF9pc1Jlc2l6ZVRvQ29udGVudCk7XHJcbiAgICAgICAgICAgIH07XHJcblxyXG4gICAgICAgICAgICB0aGlzLmFwaS5nZW5lcmFsLmVuYWJsZUNvbHVtbk1vdmFibGUgPSAoX2VuYWJsZWQ6IGJvb2xlYW4pOiB2b2lkID0+IHtcclxuICAgICAgICAgICAgICAgIHRoaXMuX2VuYWJsZUNvbHVtbk1vdmFibGUoX2VuYWJsZWQpO1xyXG4gICAgICAgICAgICB9O1xyXG5cclxuICAgICAgICAgICAgLyoqKioqKioqKiBQaXZvdCBBUEkgKioqKioqKioqKi9cclxuICAgICAgICAgICAgaWYgKHR5cGVvZiAodGhpcy5hcGkucGl2b3QpID09PSAndW5kZWZpbmVkJykgdGhpcy5hcGkucGl2b3QgPSB7fTtcclxuICAgICAgICAgICAgdGhpcy5hcGkucGl2b3QuYXV0b1Jlc2l6ZSA9ICgpOiB2b2lkID0+IHtcclxuICAgICAgICAgICAgICAgIHRoaXMuX3Bpdm90UmVzaXplKCk7XHJcbiAgICAgICAgICAgIH07XHJcblxyXG4gICAgICAgICAgICB0aGlzLmFwaS5waXZvdC5zaG93VG9vbFBhbmVsID0gKF9zaG93OiBib29sZWFuKTogdm9pZCA9PiB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLl9zaG93VG9vbFBhbmVsKF9zaG93KTtcclxuICAgICAgICAgICAgfTtcclxuXHJcbiAgICAgICAgICAgIHRoaXMuYXBpLnBpdm90LmV4cGFuZEdyb3VwID0gKF9leHBhbmQ6IGJvb2xlYW4pOiB2b2lkID0+IHtcclxuICAgICAgICAgICAgICAgIHRoaXMuX2V4cGFuZEdyb3VwKF9leHBhbmQpO1xyXG4gICAgICAgICAgICB9O1xyXG5cclxuICAgICAgICAgICAgdGhpcy5hcGkucGl2b3QuZ2V0UGl2b3RTdGF0ZSA9ICgpOiBJVGFibGVQaXZvdFN0YXRlID0+IHtcclxuICAgICAgICAgICAgICAgIHJldHVybiB0aGlzLl9nZXRQaXZvdFN0YXRlKCk7XHJcbiAgICAgICAgICAgIH07XHJcblxyXG4gICAgICAgICAgICB0aGlzLmFwaS5waXZvdC5zZXRQaXZvdFN0YXRlID0gKF9zdGF0ZTogSVRhYmxlUGl2b3RTdGF0ZSk6IHZvaWQgPT4ge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5fc2V0Q29sdW1uRGVmKHRoaXMuY29sdW1uKTtcclxuICAgICAgICAgICAgICAgIHRoaXMuX3NldFBpdm90U3RhdGUoX3N0YXRlKTtcclxuICAgICAgICAgICAgfTtcclxuXHJcbiAgICAgICAgICAgIHRoaXMuYXBpLnBpdm90LmVuYWJsZWRQaXZvdE1vZGUgPSAoX2VuYWJsZWQ6IGJvb2xlYW4pOiB2b2lkID0+IHtcclxuICAgICAgICAgICAgICAgIHRoaXMuX2VuYWJsZWRQaXZvdE1vZGUoX2VuYWJsZWQpO1xyXG4gICAgICAgICAgICB9O1xyXG5cclxuICAgICAgICAgICAgdGhpcy5hcGkucGl2b3Quc2hvd1Bpdm90TW9kZSA9IChfc2hvdzogYm9vbGVhbik6IHZvaWQgPT4ge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5fc2hvd1Bpdm90TW9kZShfc2hvdyk7XHJcbiAgICAgICAgICAgIH07XHJcblxyXG4gICAgICAgICAgICAvKioqKioqKioqIElucHV0IEFQSSAqKioqKioqKioqL1xyXG4gICAgICAgICAgICB0aGlzLmFwaS5keW5hbWljRm9ybS5jbGVhckFsbEVycm9yID0gKCk6IHZvaWQgPT4ge1xyXG4gICAgICAgICAgICAgICAgbGV0IHRhYmxlQ29udGV4dDogeyBba2V5OiBzdHJpbmddOiBhbnkgfSA9IHRoaXMuZ3JpZE9wdGlvbnMuY29udGV4dFt0aGlzLl90YWJsZVNlcnZpY2UuZ2V0VGFibGVDb250ZXh0S2V5KCldO1xyXG5cclxuICAgICAgICAgICAgICAgIGZvciAobGV0IGl0ZW0gaW4gdGFibGVDb250ZXh0KSB7XHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKHRhYmxlQ29udGV4dC5oYXNPd25Qcm9wZXJ0eShpdGVtKSkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBsZXQgY29udGV4dEl0ZW06IGFueSA9IHRhYmxlQ29udGV4dFtpdGVtXTtcclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGZvciAobGV0IHF1ZXN0aW9uIGluIGNvbnRleHRJdGVtKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAoY29udGV4dEl0ZW0uaGFzT3duUHJvcGVydHkocXVlc3Rpb24pKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKHR5cGVvZiBjb250ZXh0SXRlbVtxdWVzdGlvbl0uZXJyb3JzID09PSAndW5kZWZpbmVkJykge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb250ZXh0SXRlbVtxdWVzdGlvbl0uZXJyb3JzID0gW107XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb250ZXh0SXRlbVtxdWVzdGlvbl0uZXJyb3JzLmxlbmd0aCA9IDA7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH07XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICBjb25zb2xlLndhcm4oJ0tkVGFibGUgd2FybmluZzogTm8gYXBpIHByb3BlcnR5IC8gdW5kZWZpbmVkIGFwaSBwcm9wZXJ0eSBpcyBwYXNzZWQgaW4uJyk7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIC8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vXHJcbiAgICAvLy8gTWlzYyBmdW5jdGlvbnNcclxuICAgIC8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vXHJcbiAgICBwcml2YXRlIF9pbml0R3JpZFNlcnZpY2UoX2xvYWRUeXBlOiBzdHJpbmcpOiB2b2lkIHtcclxuICAgICAgICBpZiAodHlwZW9mIF9sb2FkVHlwZSA9PT0gJ3VuZGVmaW5lZCcgfHwgX2xvYWRUeXBlID09PSAnbm9ybWFsJykge1xyXG4gICAgICAgICAgICB0aGlzLl90YWJsZVNlcnZpY2UgPSBuZXcgS2RUYWJsZU5vcm1hbFN2YygpO1xyXG4gICAgICAgIH1cclxuICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgdGhpcy5fdGFibGVTZXJ2aWNlID0gbmV3IEtkVGFibGVFbnRlcnByaXNlU3ZjKCk7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX3VwZGF0ZUdyaWRDb25maWcoX2dyaWRDb25maWc6IElUYWJsZUNvbmZpZyk6IHZvaWQge1xyXG4gICAgICAgIHRoaXMuZ3JpZElkID0gdGhpcy5fdGFibGVTZXJ2aWNlLmdldEdyaWRJZChfZ3JpZENvbmZpZyk7XHJcblxyXG4gICAgICAgIHRoaXMuX3RhYmxlU2VydmljZS51cGRhdGVHcmlkQnV0dG9ucyhfZ3JpZENvbmZpZyk7XHJcbiAgICAgICAgdGhpcy5fdGFibGVTZXJ2aWNlLnVwZGF0ZVNlbGVjdERlZmF1bHRWYWx1ZShfZ3JpZENvbmZpZyk7XHJcbiAgICB9XHJcbn1cclxuIl19