import { Component, ViewEncapsulation, Input, Output, EventEmitter, ElementRef } from '@angular/core';
import { format, differenceInCalendarDays } from 'date-fns';
import { CalendarEventTitleFormatter, CalendarDateFormatter } from 'angular-calendar';
import { CustomEventTitleFormatter, CustomDateFormatter, CalendarHelper } from './config/kd-calendar-svc';
import { Subject } from 'rxjs';
export class KdCalendar {
    constructor(_calendarHelper, _elRef) {
        this._calendarHelper = _calendarHelper;
        this._elRef = _elRef;
        this.refresh = new Subject();
        this.viewDate = new Date();
        this.activeDayIsOpen = false;
        this._colorTray = {
            'blue': { primary: '#2a6db0', secondary: '#2F79C3' },
            'red': { primary: '#b84242', secondary: '#CB4945' },
            'yellow': { primary: '#d78f32', secondary: '#EF9F38' },
            'green': { primary: '#159e82', secondary: '#17b090' }
        };
        // public eventCalendar: Array<ICalendar>;
        this.calendarType = 'month';
        this.events = [];
        this.onEventClicked = new EventEmitter();
    }
    // init
    ngOnInit() {
        // this.eventCalendar = [];
        for (let i = 0; i < this.events.length; i++) {
            let event = this.events[i];
            let returnData = this._calendarHelper.addMissingRequiredPropertyForEvent(event, this._colorTray);
            if (returnData === false) {
                continue;
            }
        }
        this.initApi();
    }
    ngOnChanges(changes) {
        if (changes.hasOwnProperty('events')) {
            for (let i = 0; i < changes.events.currentValue.length; i++) {
                let event = changes.events.currentValue[i];
                let returnData = this._calendarHelper.addMissingRequiredPropertyForEvent(event, this._colorTray);
                if (returnData === false) {
                    continue;
                }
            }
            this.refresh.next();
        }
    }
    initApi() {
        this.api.getCalendarDate = () => { return format(this._calendarHelper.stringToDate(this.viewDate), 'YYYY-MM-DD'); };
        this.api.setCalendarType = (_type) => this.calendarType = _type;
        this.api.nextMonth = () => this._onViewChange('month', 'next');
        this.api.nextWeek = () => this._onViewChange('week', 'next');
        this.api.nextDay = () => this._onViewChange('day', 'next');
        this.api.previousMonth = () => this._onViewChange('month', 'previous');
        this.api.previousWeek = () => this._onViewChange('week', 'previous');
        this.api.previousDay = () => this._onViewChange('day', 'previous');
        this.api.goDate = (dateString) => { let goWhere = (dateString) ? dateString : 'today'; this._onViewChange(goWhere, 'go'); };
    }
    beforeMonthViewRender({ body }) {
        body.forEach(day => {
            if (this._calendarHelper.getUniqueDateToHighlight(day.date, this.events)) {
                day.cssClass = 'highlight-cell-grey';
            }
        });
    }
    generateViewMoreValue(events) {
        let eventsLength = events.length;
        if (events[0].id === 1) {
            eventsLength = 2000;
        }
        let value = this._calendarHelper.generateViewMoreValue(eventsLength);
        return value;
    }
    dayClicked({ date, events }) {
        let isSameDate = (this.viewDate === date || differenceInCalendarDays(this.viewDate, date) === 0);
        if ((isSameDate === true && this.activeDayIsOpen === true) || events.length === 0) {
            this.activeDayIsOpen = false;
        }
        else {
            this.activeDayIsOpen = true;
            this.viewDate = date;
            this._showCloseIcon();
        }
    }
    _showCloseIcon() {
        let thisController = this;
        let time = 1;
        setTimeout(function () {
            let eventOpenedDrawers = thisController._elRef.nativeElement.querySelectorAll('.cal-open-day-events');
            if (eventOpenedDrawers) {
                let addIcon = thisController._calendarHelper.getOpenedDrawer(eventOpenedDrawers, thisController._currentDrawer);
                thisController._currentDrawer = addIcon.element;
                let isIconAdded = addIcon.isIconAdded;
                if (!isIconAdded) {
                    let spanEl = thisController._calendarHelper.createCloseIconElement();
                    spanEl.onclick = function (event) {
                        thisController.closeEventDetailPanel(event);
                    };
                    thisController._currentDrawer.insertBefore(spanEl, thisController._currentDrawer.firstChild);
                }
            }
            else {
                time++;
                thisController._showCloseIcon();
            }
        }, time);
    }
    closeEventDetailPanel(event) {
        event.stopPropagation();
        this.activeDayIsOpen = false;
    }
    // api
    handleEvent(_event) {
        let eventClean = this._calendarHelper.cleanEventProperty(_event);
        this.onEventClicked.emit(eventClean);
        this._calendarHelper.addMissingRequiredPropertyForEvent(eventClean, this._colorTray);
        this.refresh.next();
    }
    _onViewChange(_calendarType, _action) {
        let newDate = this._calendarHelper.getViewDate(_calendarType, _action, this.viewDate);
        if (typeof newDate !== 'boolean') {
            this.activeDayIsOpen = false;
            this.viewDate = this._calendarHelper.stringToDate(newDate);
            this.api.getCalendarDate(format(this._calendarHelper.stringToDate(this.viewDate), 'YYYY-MM-DD'));
            this.refresh.next();
        }
        else {
            console.warn('Kd-Calendar ERROR: calendarType: ' + _calendarType + ' and action:' + _action + ' for onViewChange function only takes in calendar type: "year" or "month" or "week" or "day", action: "next" or "previous" or "today" as the argument');
        }
    }
}
KdCalendar.decorators = [
    { type: Component, args: [{
                selector: 'kd-calendar',
                template: "<ng-template #customCellTemplate let-day=\"day\" let-locale=\"locale\">\r\n    <div class=\"cal-cell-top\">\r\n        <span class=\"cal-day-number\">{{ day.date | calendarDate:'monthViewDayNumber':locale }}</span>\r\n        <span class=\"kdx-cal-view-more\" *ngIf=\"day.events.length > 4\">{{ generateViewMoreValue(day.events) }}</span>\r\n        <div class=\"kdx-cal-cell-event-top\">\r\n            <ng-container *ngFor=\"let event; of:day.events|slice:0:4; let i=index\">\r\n                <div *ngIf=\"i<4 && event.badge.position === 'top'\" class=\"cal-cell-event-type\">\r\n                    <small class=\"kdx-cal-day-event\" *ngIf=\"event.badge.position === 'top'\" [ngClass]=\"(event.badge.color === 'green') ? 'kdx btn-success' : (event.badge.color === 'red') ? 'kdx btn-error' : (event.badge.color === 'yellow') ? 'kdx btn-warning' : 'kdx btn-info'\">{{ event.badge.label }}</small>\r\n                </div>\r\n            </ng-container>\r\n        </div>\r\n    </div>\r\n    <div class=\"kdx-cal-cell-event-bottom\">\r\n        <ng-container *ngFor=\"let event; of:day.events|slice:0:4; let i=index\">\r\n            <div *ngIf=\"i<4 && event.badge.position === 'bottom'\" class=\"cal-cell-event-type\">\r\n                <small class=\"kdx-cal-day-event\" *ngIf=\"event.badge.position === 'bottom'\" [ngClass]=\"(event.badge.color === 'green') ? 'kdx btn-success' : (event.badge.color === 'red') ? 'kdx btn-error' : (event.badge.color === 'yellow') ? 'kdx btn-warning' : 'kdx btn-info'\">{{ event.badge.label }}</small>\r\n            </div>\r\n        </ng-container>\r\n    </div>\r\n</ng-template>\r\n<div class=\"kdx-calendar\">\r\n    <div [ngSwitch]=\"calendarType\">\r\n        <mwl-calendar-month-view *ngSwitchCase=\"'month'\" class=\"cal-month-view\" [viewDate]=\"viewDate\" [(events)]=\"events\" [refresh]=\"refresh\" [activeDayIsOpen]=\"activeDayIsOpen\" (dayClicked)=\"dayClicked($event.day)\" (eventClicked)=\"handleEvent($event.event)\" (beforeViewRender)=\"beforeMonthViewRender($event)\" [cellTemplate]=\"customCellTemplate\">\r\n        </mwl-calendar-month-view>\r\n        <mwl-calendar-week-view *ngSwitchCase=\"'week'\" class=\"cal-week-view\" [viewDate]=\"viewDate\" [(events)]=\"events\" [refresh]=\"refresh\" (eventClicked)=\"handleEvent($event.event)\">\r\n        </mwl-calendar-week-view>\r\n        <!-- <mwl-calendar-day-view *ngSwitchCase=\"'day'\" class=\"cal-day-view\" [viewDate]=\"viewDate\" [(events)]=\"events\" [refresh]=\"refresh\" (eventClicked)=\"handleEvent($event.event)\">\r\n        </mwl-calendar-day-view> -->\r\n    </div>\r\n</div>\r\n",
                encapsulation: ViewEncapsulation.None,
                providers: [
                    {
                        provide: CalendarEventTitleFormatter,
                        useClass: CustomEventTitleFormatter
                    },
                    {
                        provide: CalendarDateFormatter,
                        useClass: CustomDateFormatter
                    },
                    CalendarHelper
                ]
            },] }
];
KdCalendar.ctorParameters = () => [
    { type: CalendarHelper },
    { type: ElementRef }
];
KdCalendar.propDecorators = {
    calendarType: [{ type: Input }],
    events: [{ type: Input }],
    api: [{ type: Input }],
    onEventClicked: [{ type: Output }]
};
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoia2QtY2FsZW5kYXIuanMiLCJzb3VyY2VSb290IjoiQzovUHJvamVjdHMvQW5ndWxhci9pb3N0Zy1vcGVuZW1pcy1zdHlsZWd1aWRlL3Byb2plY3RzL29wZW5lbWlzLXN0eWxlZ3VpZGUtbGliL3NyYy8iLCJzb3VyY2VzIjpbImtkLWNvbXBvbmVudHMva2QtYW5ndWxhci1jYWxlbmRhci9rZC1jYWxlbmRhci50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQSxPQUFPLEVBQ0gsU0FBUyxFQUNULGlCQUFpQixFQUlqQixLQUFLLEVBQ0wsTUFBTSxFQUNOLFlBQVksRUFDWixVQUFVLEVBQ2IsTUFBTSxlQUFlLENBQUM7QUFDdkIsT0FBTyxFQUNILE1BQU0sRUFDTix3QkFBd0IsRUFDM0IsTUFBTSxVQUFVLENBQUM7QUFDbEIsT0FBTyxFQUVILDJCQUEyQixFQUUzQixxQkFBcUIsRUFDeEIsTUFBTSxrQkFBa0IsQ0FBQztBQUMxQixPQUFPLEVBQUUseUJBQXlCLEVBQUUsbUJBQW1CLEVBQUUsY0FBYyxFQUFFLE1BQU0sMEJBQTBCLENBQUM7QUFDMUcsT0FBTyxFQUFFLE9BQU8sRUFBRSxNQUFNLE1BQU0sQ0FBQztBQXFCL0IsTUFBTSxPQUFPLFVBQVU7SUEwQm5CLFlBQ1ksZUFBK0IsRUFDL0IsTUFBa0I7UUFEbEIsb0JBQWUsR0FBZixlQUFlLENBQWdCO1FBQy9CLFdBQU0sR0FBTixNQUFNLENBQVk7UUExQnZCLFlBQU8sR0FBaUIsSUFBSSxPQUFPLEVBQUUsQ0FBQztRQUV0QyxhQUFRLEdBQVMsSUFBSSxJQUFJLEVBQUUsQ0FBQztRQUU1QixvQkFBZSxHQUFZLEtBQUssQ0FBQztRQUVoQyxlQUFVLEdBQVc7WUFDekIsTUFBTSxFQUFHLEVBQUMsT0FBTyxFQUFFLFNBQVMsRUFBRSxTQUFTLEVBQUUsU0FBUyxFQUFDO1lBQ25ELEtBQUssRUFBRyxFQUFDLE9BQU8sRUFBRSxTQUFTLEVBQUUsU0FBUyxFQUFFLFNBQVMsRUFBQztZQUNsRCxRQUFRLEVBQUcsRUFBQyxPQUFPLEVBQUUsU0FBUyxFQUFFLFNBQVMsRUFBRSxTQUFTLEVBQUM7WUFDckQsT0FBTyxFQUFHLEVBQUMsT0FBTyxFQUFFLFNBQVMsRUFBRSxTQUFTLEVBQUUsU0FBUyxFQUFDO1NBQ3ZELENBQUM7UUFHRiwwQ0FBMEM7UUFFakMsaUJBQVksR0FBVyxPQUFPLENBQUM7UUFFL0IsV0FBTSxHQUFxQixFQUFFLENBQUM7UUFJN0IsbUJBQWMsR0FBNEIsSUFBSSxZQUFZLEVBQWEsQ0FBQztJQUs5RSxDQUFDO0lBRUwsT0FBTztJQUVQLFFBQVE7UUFFSiwyQkFBMkI7UUFFM0IsS0FBTSxJQUFJLENBQUMsR0FBVyxDQUFDLEVBQUUsQ0FBQyxHQUFHLElBQUksQ0FBQyxNQUFNLENBQUMsTUFBTSxFQUFFLENBQUMsRUFBRSxFQUFHO1lBQ25ELElBQUksS0FBSyxHQUFjLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUM7WUFDdEMsSUFBSSxVQUFVLEdBQVksSUFBSSxDQUFDLGVBQWUsQ0FBQyxrQ0FBa0MsQ0FBQyxLQUFLLEVBQUUsSUFBSSxDQUFDLFVBQVUsQ0FBQyxDQUFDO1lBQzFHLElBQUssVUFBVSxLQUFLLEtBQUssRUFBRztnQkFDeEIsU0FBUzthQUNaO1NBQ0o7UUFFRCxJQUFJLENBQUMsT0FBTyxFQUFFLENBQUM7SUFDbkIsQ0FBQztJQUVELFdBQVcsQ0FBQyxPQUFzQjtRQUM5QixJQUFLLE9BQU8sQ0FBQyxjQUFjLENBQUMsUUFBUSxDQUFDLEVBQUc7WUFFcEMsS0FBTSxJQUFJLENBQUMsR0FBVyxDQUFDLEVBQUUsQ0FBQyxHQUFHLE9BQU8sQ0FBQyxNQUFNLENBQUMsWUFBWSxDQUFDLE1BQU0sRUFBRSxDQUFDLEVBQUUsRUFBRztnQkFDbkUsSUFBSSxLQUFLLEdBQWMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxZQUFZLENBQUMsQ0FBQyxDQUFDLENBQUM7Z0JBQ3RELElBQUksVUFBVSxHQUFZLElBQUksQ0FBQyxlQUFlLENBQUMsa0NBQWtDLENBQUMsS0FBSyxFQUFFLElBQUksQ0FBQyxVQUFVLENBQUMsQ0FBQztnQkFDMUcsSUFBSyxVQUFVLEtBQUssS0FBSyxFQUFHO29CQUN4QixTQUFTO2lCQUNaO2FBQ0o7WUFFRCxJQUFJLENBQUMsT0FBTyxDQUFDLElBQUksRUFBRSxDQUFDO1NBQ3ZCO0lBQ0wsQ0FBQztJQUVELE9BQU87UUFDSCxJQUFJLENBQUMsR0FBRyxDQUFDLGVBQWUsR0FBRyxHQUFXLEVBQUUsR0FBRyxPQUFPLE1BQU0sQ0FBQyxJQUFJLENBQUMsZUFBZSxDQUFDLFlBQVksQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLEVBQUUsWUFBWSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7UUFDNUgsSUFBSSxDQUFDLEdBQUcsQ0FBQyxlQUFlLEdBQUcsQ0FBQyxLQUFhLEVBQUUsRUFBRSxDQUFDLElBQUksQ0FBQyxZQUFZLEdBQUcsS0FBSyxDQUFDO1FBQ3hFLElBQUksQ0FBQyxHQUFHLENBQUMsU0FBUyxHQUFHLEdBQUcsRUFBRSxDQUFDLElBQUksQ0FBQyxhQUFhLENBQUMsT0FBTyxFQUFFLE1BQU0sQ0FBQyxDQUFDO1FBQy9ELElBQUksQ0FBQyxHQUFHLENBQUMsUUFBUSxHQUFHLEdBQUcsRUFBRSxDQUFDLElBQUksQ0FBQyxhQUFhLENBQUMsTUFBTSxFQUFFLE1BQU0sQ0FBQyxDQUFDO1FBQzdELElBQUksQ0FBQyxHQUFHLENBQUMsT0FBTyxHQUFHLEdBQUcsRUFBRSxDQUFDLElBQUksQ0FBQyxhQUFhLENBQUMsS0FBSyxFQUFFLE1BQU0sQ0FBQyxDQUFDO1FBQzNELElBQUksQ0FBQyxHQUFHLENBQUMsYUFBYSxHQUFHLEdBQUcsRUFBRSxDQUFDLElBQUksQ0FBQyxhQUFhLENBQUMsT0FBTyxFQUFFLFVBQVUsQ0FBQyxDQUFDO1FBQ3ZFLElBQUksQ0FBQyxHQUFHLENBQUMsWUFBWSxHQUFHLEdBQUcsRUFBRSxDQUFDLElBQUksQ0FBQyxhQUFhLENBQUMsTUFBTSxFQUFFLFVBQVUsQ0FBQyxDQUFDO1FBQ3JFLElBQUksQ0FBQyxHQUFHLENBQUMsV0FBVyxHQUFHLEdBQUcsRUFBRSxDQUFDLElBQUksQ0FBQyxhQUFhLENBQUMsS0FBSyxFQUFFLFVBQVUsQ0FBQyxDQUFDO1FBQ25FLElBQUksQ0FBQyxHQUFHLENBQUMsTUFBTSxHQUFHLENBQUMsVUFBbUIsRUFBRSxFQUFFLEdBQUcsSUFBSSxPQUFPLEdBQVcsQ0FBQyxVQUFVLENBQUMsQ0FBQyxDQUFDLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxJQUFJLENBQUMsYUFBYSxDQUFDLE9BQU8sRUFBRSxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztJQUNqSixDQUFDO0lBRUQscUJBQXFCLENBQUMsRUFBRSxJQUFJLEVBQW9DO1FBQzVELElBQUksQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLEVBQUU7WUFDZixJQUFLLElBQUksQ0FBQyxlQUFlLENBQUMsd0JBQXdCLENBQUMsR0FBRyxDQUFDLElBQUksRUFBRSxJQUFJLENBQUMsTUFBTSxDQUFDLEVBQUc7Z0JBQ3hFLEdBQUcsQ0FBQyxRQUFRLEdBQUcscUJBQXFCLENBQUM7YUFDeEM7UUFDTCxDQUFDLENBQUMsQ0FBQztJQUNQLENBQUM7SUFFRCxxQkFBcUIsQ0FBQyxNQUFtQjtRQUNyQyxJQUFJLFlBQVksR0FBVyxNQUFNLENBQUMsTUFBTSxDQUFDO1FBQ3pDLElBQUssTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsS0FBSyxDQUFDLEVBQUc7WUFDdEIsWUFBWSxHQUFHLElBQUksQ0FBQztTQUN2QjtRQUNELElBQUksS0FBSyxHQUFXLElBQUksQ0FBQyxlQUFlLENBQUMscUJBQXFCLENBQUMsWUFBWSxDQUFDLENBQUM7UUFDN0UsT0FBTyxLQUFLLENBQUM7SUFDakIsQ0FBQztJQUVELFVBQVUsQ0FBQyxFQUFFLElBQUksRUFBRSxNQUFNLEVBQTBDO1FBRS9ELElBQUksVUFBVSxHQUFZLENBQUMsSUFBSSxDQUFDLFFBQVEsS0FBSyxJQUFJLElBQUksd0JBQXdCLENBQUMsSUFBSSxDQUFDLFFBQVEsRUFBRSxJQUFJLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQztRQUMxRyxJQUFJLENBQUUsVUFBVSxLQUFLLElBQUksSUFBSSxJQUFJLENBQUMsZUFBZSxLQUFLLElBQUksQ0FBQyxJQUFJLE1BQU0sQ0FBQyxNQUFNLEtBQUssQ0FBQyxFQUFHO1lBQ2pGLElBQUksQ0FBQyxlQUFlLEdBQUcsS0FBSyxDQUFDO1NBQ2hDO2FBQU07WUFDSCxJQUFJLENBQUMsZUFBZSxHQUFHLElBQUksQ0FBQztZQUM1QixJQUFJLENBQUMsUUFBUSxHQUFHLElBQUksQ0FBQztZQUNyQixJQUFJLENBQUMsY0FBYyxFQUFFLENBQUM7U0FDekI7SUFDTCxDQUFDO0lBRU8sY0FBYztRQUVsQixJQUFJLGNBQWMsR0FBUyxJQUFJLENBQUM7UUFDaEMsSUFBSSxJQUFJLEdBQVcsQ0FBQyxDQUFDO1FBRXJCLFVBQVUsQ0FBQztZQUVQLElBQUksa0JBQWtCLEdBQW1CLGNBQWMsQ0FBQyxNQUFNLENBQUMsYUFBYSxDQUFDLGdCQUFnQixDQUFDLHNCQUFzQixDQUFDLENBQUM7WUFFdEgsSUFBSyxrQkFBa0IsRUFBRztnQkFFdEIsSUFBSSxPQUFPLEdBQXdCLGNBQWMsQ0FBQyxlQUFlLENBQUMsZUFBZSxDQUFDLGtCQUFrQixFQUFFLGNBQWMsQ0FBQyxjQUFjLENBQUMsQ0FBQztnQkFFckksY0FBYyxDQUFDLGNBQWMsR0FBRyxPQUFPLENBQUMsT0FBTyxDQUFDO2dCQUNoRCxJQUFJLFdBQVcsR0FBRyxPQUFPLENBQUMsV0FBVyxDQUFDO2dCQUV0QyxJQUFLLENBQUMsV0FBVyxFQUFHO29CQUNoQixJQUFJLE1BQU0sR0FBb0IsY0FBYyxDQUFDLGVBQWUsQ0FBQyxzQkFBc0IsRUFBRSxDQUFDO29CQUN0RixNQUFNLENBQUMsT0FBTyxHQUFHLFVBQVMsS0FBSzt3QkFDM0IsY0FBYyxDQUFDLHFCQUFxQixDQUFDLEtBQUssQ0FBQyxDQUFDO29CQUNoRCxDQUFDLENBQUM7b0JBRUYsY0FBYyxDQUFDLGNBQWMsQ0FBQyxZQUFZLENBQUMsTUFBTSxFQUFFLGNBQWMsQ0FBQyxjQUFjLENBQUMsVUFBVSxDQUFDLENBQUM7aUJBQ2hHO2FBQ0o7aUJBQU07Z0JBQ0gsSUFBSSxFQUFFLENBQUM7Z0JBQ1AsY0FBYyxDQUFDLGNBQWMsRUFBRSxDQUFDO2FBQ25DO1FBQ0wsQ0FBQyxFQUFFLElBQUksQ0FBQyxDQUFDO0lBQ2IsQ0FBQztJQUVELHFCQUFxQixDQUFDLEtBQUs7UUFDdkIsS0FBSyxDQUFDLGVBQWUsRUFBRSxDQUFDO1FBQ3hCLElBQUksQ0FBQyxlQUFlLEdBQUcsS0FBSyxDQUFDO0lBQ2pDLENBQUM7SUFFRCxNQUFNO0lBRU4sV0FBVyxDQUFDLE1BQWlCO1FBRXpCLElBQUksVUFBVSxHQUFjLElBQUksQ0FBQyxlQUFlLENBQUMsa0JBQWtCLENBQUMsTUFBTSxDQUFDLENBQUM7UUFFNUUsSUFBSSxDQUFDLGNBQWMsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLENBQUM7UUFDckMsSUFBSSxDQUFDLGVBQWUsQ0FBQyxrQ0FBa0MsQ0FBQyxVQUFVLEVBQUUsSUFBSSxDQUFDLFVBQVUsQ0FBQyxDQUFDO1FBRXJGLElBQUksQ0FBQyxPQUFPLENBQUMsSUFBSSxFQUFFLENBQUM7SUFDeEIsQ0FBQztJQUVPLGFBQWEsQ0FBQyxhQUFxQixFQUFFLE9BQWU7UUFFeEQsSUFBSSxPQUFPLEdBQWlCLElBQUksQ0FBQyxlQUFlLENBQUMsV0FBVyxDQUFDLGFBQWEsRUFBRSxPQUFPLEVBQUUsSUFBSSxDQUFDLFFBQVEsQ0FBQyxDQUFDO1FBRXBHLElBQUssT0FBTyxPQUFPLEtBQUssU0FBUyxFQUFHO1lBQ2hDLElBQUksQ0FBQyxlQUFlLEdBQUcsS0FBSyxDQUFDO1lBQzdCLElBQUksQ0FBQyxRQUFRLEdBQUcsSUFBSSxDQUFDLGVBQWUsQ0FBQyxZQUFZLENBQUMsT0FBTyxDQUFDLENBQUM7WUFDM0QsSUFBSSxDQUFDLEdBQUcsQ0FBQyxlQUFlLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxlQUFlLENBQUMsWUFBWSxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsRUFBRSxZQUFZLENBQUMsQ0FBQyxDQUFDO1lBQ2pHLElBQUksQ0FBQyxPQUFPLENBQUMsSUFBSSxFQUFFLENBQUM7U0FDdkI7YUFBTTtZQUNILE9BQU8sQ0FBQyxJQUFJLENBQUMsbUNBQW1DLEdBQUcsYUFBYSxHQUFHLGNBQWMsR0FBRyxPQUFPLEdBQUcsdUpBQXVKLENBQUMsQ0FBQztTQUMxUDtJQUNMLENBQUM7OztZQXRMSixTQUFTLFNBQUM7Z0JBQ1AsUUFBUSxFQUFFLGFBQWE7Z0JBQ3ZCLDJqRkFBaUM7Z0JBQ2pDLGFBQWEsRUFBRSxpQkFBaUIsQ0FBQyxJQUFJO2dCQUNyQyxTQUFTLEVBQUU7b0JBQ1A7d0JBQ0UsT0FBTyxFQUFFLDJCQUEyQjt3QkFDcEMsUUFBUSxFQUFFLHlCQUF5QjtxQkFDcEM7b0JBRUQ7d0JBQ0UsT0FBTyxFQUFFLHFCQUFxQjt3QkFDOUIsUUFBUSxFQUFFLG1CQUFtQjtxQkFDOUI7b0JBQ0QsY0FBYztpQkFDakI7YUFDSjs7O1lBcEJ3RCxjQUFjO1lBWm5FLFVBQVU7OzsyQkFvRFQsS0FBSztxQkFFTCxLQUFLO2tCQUVMLEtBQUs7NkJBRUwsTUFBTSIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7XHJcbiAgICBDb21wb25lbnQsXHJcbiAgICBWaWV3RW5jYXBzdWxhdGlvbixcclxuICAgIE9uSW5pdCxcclxuICAgIE9uQ2hhbmdlcyxcclxuICAgIFNpbXBsZUNoYW5nZXMsXHJcbiAgICBJbnB1dCxcclxuICAgIE91dHB1dCxcclxuICAgIEV2ZW50RW1pdHRlcixcclxuICAgIEVsZW1lbnRSZWZcclxufSBmcm9tICdAYW5ndWxhci9jb3JlJztcclxuaW1wb3J0IHtcclxuICAgIGZvcm1hdCxcclxuICAgIGRpZmZlcmVuY2VJbkNhbGVuZGFyRGF5c1xyXG59IGZyb20gJ2RhdGUtZm5zJztcclxuaW1wb3J0IHtcclxuICAgIENhbGVuZGFyRXZlbnQsXHJcbiAgICBDYWxlbmRhckV2ZW50VGl0bGVGb3JtYXR0ZXIsXHJcbiAgICBDYWxlbmRhck1vbnRoVmlld0RheSxcclxuICAgIENhbGVuZGFyRGF0ZUZvcm1hdHRlclxyXG59IGZyb20gJ2FuZ3VsYXItY2FsZW5kYXInO1xyXG5pbXBvcnQgeyBDdXN0b21FdmVudFRpdGxlRm9ybWF0dGVyLCBDdXN0b21EYXRlRm9ybWF0dGVyLCBDYWxlbmRhckhlbHBlciB9IGZyb20gJy4vY29uZmlnL2tkLWNhbGVuZGFyLXN2Yyc7XHJcbmltcG9ydCB7IFN1YmplY3QgfSBmcm9tICdyeGpzJztcclxuaW1wb3J0IHsgSUNhbGVuZGFyLCBJQ2FsZW5kYXJBcGksIElDYWxlbmRhck9wZW5EcmF3ZXIgfSBmcm9tICcuL2tkLWFuZ3VsYXItY2FsZW5kYXItaW50ZXJmYWNlJztcclxuXHJcbkBDb21wb25lbnQoe1xyXG4gICAgc2VsZWN0b3I6ICdrZC1jYWxlbmRhcicsXHJcbiAgICB0ZW1wbGF0ZVVybDogJy4va2QtY2FsZW5kYXIuaHRtbCcsXHJcbiAgICBlbmNhcHN1bGF0aW9uOiBWaWV3RW5jYXBzdWxhdGlvbi5Ob25lLFxyXG4gICAgcHJvdmlkZXJzOiBbXHJcbiAgICAgICAge1xyXG4gICAgICAgICAgcHJvdmlkZTogQ2FsZW5kYXJFdmVudFRpdGxlRm9ybWF0dGVyLFxyXG4gICAgICAgICAgdXNlQ2xhc3M6IEN1c3RvbUV2ZW50VGl0bGVGb3JtYXR0ZXJcclxuICAgICAgICB9LFxyXG5cclxuICAgICAgICB7XHJcbiAgICAgICAgICBwcm92aWRlOiBDYWxlbmRhckRhdGVGb3JtYXR0ZXIsXHJcbiAgICAgICAgICB1c2VDbGFzczogQ3VzdG9tRGF0ZUZvcm1hdHRlclxyXG4gICAgICAgIH0sXHJcbiAgICAgICAgQ2FsZW5kYXJIZWxwZXJcclxuICAgIF1cclxufSlcclxuXHJcbmV4cG9ydCBjbGFzcyBLZENhbGVuZGFyIGltcGxlbWVudHMgT25Jbml0LCBPbkNoYW5nZXMge1xyXG5cclxuICAgIHB1YmxpYyByZWZyZXNoOiBTdWJqZWN0PGFueT4gPSBuZXcgU3ViamVjdCgpO1xyXG5cclxuICAgIHB1YmxpYyB2aWV3RGF0ZTogRGF0ZSA9IG5ldyBEYXRlKCk7XHJcblxyXG4gICAgcHVibGljIGFjdGl2ZURheUlzT3BlbjogYm9vbGVhbiA9IGZhbHNlO1xyXG5cclxuICAgIHByaXZhdGUgX2NvbG9yVHJheTogb2JqZWN0ID0ge1xyXG4gICAgICAgICdibHVlJyA6IHtwcmltYXJ5OiAnIzJhNmRiMCcsIHNlY29uZGFyeTogJyMyRjc5QzMnfSxcclxuICAgICAgICAncmVkJyA6IHtwcmltYXJ5OiAnI2I4NDI0MicsIHNlY29uZGFyeTogJyNDQjQ5NDUnfSxcclxuICAgICAgICAneWVsbG93JyA6IHtwcmltYXJ5OiAnI2Q3OGYzMicsIHNlY29uZGFyeTogJyNFRjlGMzgnfSxcclxuICAgICAgICAnZ3JlZW4nIDoge3ByaW1hcnk6ICcjMTU5ZTgyJywgc2Vjb25kYXJ5OiAnIzE3YjA5MCd9XHJcbiAgICB9O1xyXG4gICAgcHJpdmF0ZSBfY3VycmVudERyYXdlcjogRWxlbWVudDtcclxuXHJcbiAgICAvLyBwdWJsaWMgZXZlbnRDYWxlbmRhcjogQXJyYXk8SUNhbGVuZGFyPjtcclxuXHJcbiAgICBASW5wdXQoKSBjYWxlbmRhclR5cGU6IHN0cmluZyA9ICdtb250aCc7XHJcblxyXG4gICAgQElucHV0KCkgZXZlbnRzOiBBcnJheTxJQ2FsZW5kYXI+ID0gW107XHJcblxyXG4gICAgQElucHV0KCkgYXBpOiBJQ2FsZW5kYXJBcGk7XHJcblxyXG4gICAgQE91dHB1dCgpIG9uRXZlbnRDbGlja2VkOiBFdmVudEVtaXR0ZXI8SUNhbGVuZGFyPiA9IG5ldyBFdmVudEVtaXR0ZXI8SUNhbGVuZGFyPigpO1xyXG5cclxuICAgIGNvbnN0cnVjdG9yKFxyXG4gICAgICAgIHByaXZhdGUgX2NhbGVuZGFySGVscGVyOiBDYWxlbmRhckhlbHBlcixcclxuICAgICAgICBwcml2YXRlIF9lbFJlZjogRWxlbWVudFJlZlxyXG4gICAgKSB7IH1cclxuXHJcbiAgICAvLyBpbml0XHJcblxyXG4gICAgbmdPbkluaXQoKTogdm9pZCB7XHJcblxyXG4gICAgICAgIC8vIHRoaXMuZXZlbnRDYWxlbmRhciA9IFtdO1xyXG5cclxuICAgICAgICBmb3IgKCBsZXQgaTogbnVtYmVyID0gMDsgaSA8IHRoaXMuZXZlbnRzLmxlbmd0aDsgaSsrICkge1xyXG4gICAgICAgICAgICBsZXQgZXZlbnQ6IElDYWxlbmRhciA9IHRoaXMuZXZlbnRzW2ldO1xyXG4gICAgICAgICAgICBsZXQgcmV0dXJuRGF0YTogYm9vbGVhbiA9IHRoaXMuX2NhbGVuZGFySGVscGVyLmFkZE1pc3NpbmdSZXF1aXJlZFByb3BlcnR5Rm9yRXZlbnQoZXZlbnQsIHRoaXMuX2NvbG9yVHJheSk7XHJcbiAgICAgICAgICAgIGlmICggcmV0dXJuRGF0YSA9PT0gZmFsc2UgKSB7XHJcbiAgICAgICAgICAgICAgICBjb250aW51ZTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgdGhpcy5pbml0QXBpKCk7XHJcbiAgICB9XHJcblxyXG4gICAgbmdPbkNoYW5nZXMoY2hhbmdlczogU2ltcGxlQ2hhbmdlcyk6IHZvaWQge1xyXG4gICAgICAgIGlmICggY2hhbmdlcy5oYXNPd25Qcm9wZXJ0eSgnZXZlbnRzJykgKSB7XHJcblxyXG4gICAgICAgICAgICBmb3IgKCBsZXQgaTogbnVtYmVyID0gMDsgaSA8IGNoYW5nZXMuZXZlbnRzLmN1cnJlbnRWYWx1ZS5sZW5ndGg7IGkrKyApIHtcclxuICAgICAgICAgICAgICAgIGxldCBldmVudDogSUNhbGVuZGFyID0gY2hhbmdlcy5ldmVudHMuY3VycmVudFZhbHVlW2ldO1xyXG4gICAgICAgICAgICAgICAgbGV0IHJldHVybkRhdGE6IGJvb2xlYW4gPSB0aGlzLl9jYWxlbmRhckhlbHBlci5hZGRNaXNzaW5nUmVxdWlyZWRQcm9wZXJ0eUZvckV2ZW50KGV2ZW50LCB0aGlzLl9jb2xvclRyYXkpO1xyXG4gICAgICAgICAgICAgICAgaWYgKCByZXR1cm5EYXRhID09PSBmYWxzZSApIHtcclxuICAgICAgICAgICAgICAgICAgICBjb250aW51ZTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgdGhpcy5yZWZyZXNoLm5leHQoKTtcclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgaW5pdEFwaSgpOiB2b2lkIHtcclxuICAgICAgICB0aGlzLmFwaS5nZXRDYWxlbmRhckRhdGUgPSAoKTogc3RyaW5nID0+IHsgcmV0dXJuIGZvcm1hdCh0aGlzLl9jYWxlbmRhckhlbHBlci5zdHJpbmdUb0RhdGUodGhpcy52aWV3RGF0ZSksICdZWVlZLU1NLUREJyk7IH07XHJcbiAgICAgICAgdGhpcy5hcGkuc2V0Q2FsZW5kYXJUeXBlID0gKF90eXBlOiBzdHJpbmcpID0+IHRoaXMuY2FsZW5kYXJUeXBlID0gX3R5cGU7XHJcbiAgICAgICAgdGhpcy5hcGkubmV4dE1vbnRoID0gKCkgPT4gdGhpcy5fb25WaWV3Q2hhbmdlKCdtb250aCcsICduZXh0Jyk7XHJcbiAgICAgICAgdGhpcy5hcGkubmV4dFdlZWsgPSAoKSA9PiB0aGlzLl9vblZpZXdDaGFuZ2UoJ3dlZWsnLCAnbmV4dCcpO1xyXG4gICAgICAgIHRoaXMuYXBpLm5leHREYXkgPSAoKSA9PiB0aGlzLl9vblZpZXdDaGFuZ2UoJ2RheScsICduZXh0Jyk7XHJcbiAgICAgICAgdGhpcy5hcGkucHJldmlvdXNNb250aCA9ICgpID0+IHRoaXMuX29uVmlld0NoYW5nZSgnbW9udGgnLCAncHJldmlvdXMnKTtcclxuICAgICAgICB0aGlzLmFwaS5wcmV2aW91c1dlZWsgPSAoKSA9PiB0aGlzLl9vblZpZXdDaGFuZ2UoJ3dlZWsnLCAncHJldmlvdXMnKTtcclxuICAgICAgICB0aGlzLmFwaS5wcmV2aW91c0RheSA9ICgpID0+IHRoaXMuX29uVmlld0NoYW5nZSgnZGF5JywgJ3ByZXZpb3VzJyk7XHJcbiAgICAgICAgdGhpcy5hcGkuZ29EYXRlID0gKGRhdGVTdHJpbmc/OiBzdHJpbmcpID0+IHsgbGV0IGdvV2hlcmU6IHN0cmluZyA9IChkYXRlU3RyaW5nKSA/IGRhdGVTdHJpbmcgOiAndG9kYXknOyB0aGlzLl9vblZpZXdDaGFuZ2UoZ29XaGVyZSwgJ2dvJyk7IH07XHJcbiAgICB9XHJcblxyXG4gICAgYmVmb3JlTW9udGhWaWV3UmVuZGVyKHsgYm9keSB9OiB7IGJvZHk6IENhbGVuZGFyTW9udGhWaWV3RGF5W10gfSk6IHZvaWQge1xyXG4gICAgICAgIGJvZHkuZm9yRWFjaChkYXkgPT4ge1xyXG4gICAgICAgICAgICBpZiAoIHRoaXMuX2NhbGVuZGFySGVscGVyLmdldFVuaXF1ZURhdGVUb0hpZ2hsaWdodChkYXkuZGF0ZSwgdGhpcy5ldmVudHMpICkge1xyXG4gICAgICAgICAgICAgICAgZGF5LmNzc0NsYXNzID0gJ2hpZ2hsaWdodC1jZWxsLWdyZXknO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfSk7XHJcbiAgICB9XHJcblxyXG4gICAgZ2VuZXJhdGVWaWV3TW9yZVZhbHVlKGV2ZW50czogSUNhbGVuZGFyW10pOiBzdHJpbmcge1xyXG4gICAgICAgIGxldCBldmVudHNMZW5ndGg6IG51bWJlciA9IGV2ZW50cy5sZW5ndGg7XHJcbiAgICAgICAgaWYgKCBldmVudHNbMF0uaWQgPT09IDEgKSB7XHJcbiAgICAgICAgICAgIGV2ZW50c0xlbmd0aCA9IDIwMDA7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGxldCB2YWx1ZTogc3RyaW5nID0gdGhpcy5fY2FsZW5kYXJIZWxwZXIuZ2VuZXJhdGVWaWV3TW9yZVZhbHVlKGV2ZW50c0xlbmd0aCk7XHJcbiAgICAgICAgcmV0dXJuIHZhbHVlO1xyXG4gICAgfVxyXG5cclxuICAgIGRheUNsaWNrZWQoeyBkYXRlLCBldmVudHN9OiB7IGRhdGU6IERhdGU7IGV2ZW50czogQ2FsZW5kYXJFdmVudFtdIH0pOiB2b2lkIHtcclxuXHJcbiAgICAgICAgbGV0IGlzU2FtZURhdGU6IGJvb2xlYW4gPSAodGhpcy52aWV3RGF0ZSA9PT0gZGF0ZSB8fCBkaWZmZXJlbmNlSW5DYWxlbmRhckRheXModGhpcy52aWV3RGF0ZSwgZGF0ZSkgPT09IDApO1xyXG4gICAgICAgIGlmICgoIGlzU2FtZURhdGUgPT09IHRydWUgJiYgdGhpcy5hY3RpdmVEYXlJc09wZW4gPT09IHRydWUpIHx8IGV2ZW50cy5sZW5ndGggPT09IDAgKSB7XHJcbiAgICAgICAgICAgIHRoaXMuYWN0aXZlRGF5SXNPcGVuID0gZmFsc2U7XHJcbiAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgdGhpcy5hY3RpdmVEYXlJc09wZW4gPSB0cnVlO1xyXG4gICAgICAgICAgICB0aGlzLnZpZXdEYXRlID0gZGF0ZTtcclxuICAgICAgICAgICAgdGhpcy5fc2hvd0Nsb3NlSWNvbigpO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF9zaG93Q2xvc2VJY29uKCk6IHZvaWQge1xyXG5cclxuICAgICAgICBsZXQgdGhpc0NvbnRyb2xsZXI6IHRoaXMgPSB0aGlzO1xyXG4gICAgICAgIGxldCB0aW1lOiBudW1iZXIgPSAxO1xyXG5cclxuICAgICAgICBzZXRUaW1lb3V0KGZ1bmN0aW9uKCkge1xyXG5cclxuICAgICAgICAgICAgbGV0IGV2ZW50T3BlbmVkRHJhd2VyczogQXJyYXk8RWxlbWVudD4gPSB0aGlzQ29udHJvbGxlci5fZWxSZWYubmF0aXZlRWxlbWVudC5xdWVyeVNlbGVjdG9yQWxsKCcuY2FsLW9wZW4tZGF5LWV2ZW50cycpO1xyXG5cclxuICAgICAgICAgICAgaWYgKCBldmVudE9wZW5lZERyYXdlcnMgKSB7XHJcblxyXG4gICAgICAgICAgICAgICAgbGV0IGFkZEljb246IElDYWxlbmRhck9wZW5EcmF3ZXIgPSB0aGlzQ29udHJvbGxlci5fY2FsZW5kYXJIZWxwZXIuZ2V0T3BlbmVkRHJhd2VyKGV2ZW50T3BlbmVkRHJhd2VycywgdGhpc0NvbnRyb2xsZXIuX2N1cnJlbnREcmF3ZXIpO1xyXG5cclxuICAgICAgICAgICAgICAgIHRoaXNDb250cm9sbGVyLl9jdXJyZW50RHJhd2VyID0gYWRkSWNvbi5lbGVtZW50O1xyXG4gICAgICAgICAgICAgICAgbGV0IGlzSWNvbkFkZGVkID0gYWRkSWNvbi5pc0ljb25BZGRlZDtcclxuXHJcbiAgICAgICAgICAgICAgICBpZiAoICFpc0ljb25BZGRlZCApIHtcclxuICAgICAgICAgICAgICAgICAgICBsZXQgc3BhbkVsOiBIVE1MU3BhbkVsZW1lbnQgPSB0aGlzQ29udHJvbGxlci5fY2FsZW5kYXJIZWxwZXIuY3JlYXRlQ2xvc2VJY29uRWxlbWVudCgpO1xyXG4gICAgICAgICAgICAgICAgICAgIHNwYW5FbC5vbmNsaWNrID0gZnVuY3Rpb24oZXZlbnQpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgdGhpc0NvbnRyb2xsZXIuY2xvc2VFdmVudERldGFpbFBhbmVsKGV2ZW50KTtcclxuICAgICAgICAgICAgICAgICAgICB9O1xyXG5cclxuICAgICAgICAgICAgICAgICAgICB0aGlzQ29udHJvbGxlci5fY3VycmVudERyYXdlci5pbnNlcnRCZWZvcmUoc3BhbkVsLCB0aGlzQ29udHJvbGxlci5fY3VycmVudERyYXdlci5maXJzdENoaWxkKTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgICAgIHRpbWUrKztcclxuICAgICAgICAgICAgICAgIHRoaXNDb250cm9sbGVyLl9zaG93Q2xvc2VJY29uKCk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9LCB0aW1lKTtcclxuICAgIH1cclxuXHJcbiAgICBjbG9zZUV2ZW50RGV0YWlsUGFuZWwoZXZlbnQpOiB2b2lkIHtcclxuICAgICAgICBldmVudC5zdG9wUHJvcGFnYXRpb24oKTtcclxuICAgICAgICB0aGlzLmFjdGl2ZURheUlzT3BlbiA9IGZhbHNlO1xyXG4gICAgfVxyXG5cclxuICAgIC8vIGFwaVxyXG5cclxuICAgIGhhbmRsZUV2ZW50KF9ldmVudDogSUNhbGVuZGFyKTogdm9pZCB7XHJcblxyXG4gICAgICAgIGxldCBldmVudENsZWFuOiBJQ2FsZW5kYXIgPSB0aGlzLl9jYWxlbmRhckhlbHBlci5jbGVhbkV2ZW50UHJvcGVydHkoX2V2ZW50KTtcclxuXHJcbiAgICAgICAgdGhpcy5vbkV2ZW50Q2xpY2tlZC5lbWl0KGV2ZW50Q2xlYW4pO1xyXG4gICAgICAgIHRoaXMuX2NhbGVuZGFySGVscGVyLmFkZE1pc3NpbmdSZXF1aXJlZFByb3BlcnR5Rm9yRXZlbnQoZXZlbnRDbGVhbiwgdGhpcy5fY29sb3JUcmF5KTtcclxuXHJcbiAgICAgICAgdGhpcy5yZWZyZXNoLm5leHQoKTtcclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF9vblZpZXdDaGFuZ2UoX2NhbGVuZGFyVHlwZTogc3RyaW5nLCBfYWN0aW9uOiBzdHJpbmcpOiB2b2lkIHtcclxuXHJcbiAgICAgICAgbGV0IG5ld0RhdGU6IGJvb2xlYW58RGF0ZSA9IHRoaXMuX2NhbGVuZGFySGVscGVyLmdldFZpZXdEYXRlKF9jYWxlbmRhclR5cGUsIF9hY3Rpb24sIHRoaXMudmlld0RhdGUpO1xyXG5cclxuICAgICAgICBpZiAoIHR5cGVvZiBuZXdEYXRlICE9PSAnYm9vbGVhbicgKSB7XHJcbiAgICAgICAgICAgIHRoaXMuYWN0aXZlRGF5SXNPcGVuID0gZmFsc2U7XHJcbiAgICAgICAgICAgIHRoaXMudmlld0RhdGUgPSB0aGlzLl9jYWxlbmRhckhlbHBlci5zdHJpbmdUb0RhdGUobmV3RGF0ZSk7XHJcbiAgICAgICAgICAgIHRoaXMuYXBpLmdldENhbGVuZGFyRGF0ZShmb3JtYXQodGhpcy5fY2FsZW5kYXJIZWxwZXIuc3RyaW5nVG9EYXRlKHRoaXMudmlld0RhdGUpLCAnWVlZWS1NTS1ERCcpKTtcclxuICAgICAgICAgICAgdGhpcy5yZWZyZXNoLm5leHQoKTtcclxuICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICBjb25zb2xlLndhcm4oJ0tkLUNhbGVuZGFyIEVSUk9SOiBjYWxlbmRhclR5cGU6ICcgKyBfY2FsZW5kYXJUeXBlICsgJyBhbmQgYWN0aW9uOicgKyBfYWN0aW9uICsgJyBmb3Igb25WaWV3Q2hhbmdlIGZ1bmN0aW9uIG9ubHkgdGFrZXMgaW4gY2FsZW5kYXIgdHlwZTogXCJ5ZWFyXCIgb3IgXCJtb250aFwiIG9yIFwid2Vla1wiIG9yIFwiZGF5XCIsIGFjdGlvbjogXCJuZXh0XCIgb3IgXCJwcmV2aW91c1wiIG9yIFwidG9kYXlcIiBhcyB0aGUgYXJndW1lbnQnKTtcclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG59XHJcbiJdfQ==