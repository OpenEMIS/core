import { Component, Input, Output, EventEmitter, ViewEncapsulation, ViewContainerRef, HostListener, ChangeDetectorRef, Renderer2 } from '@angular/core';
import { timer } from 'rxjs';
import { Router, ActivatedRoute } from '@angular/router';
import { KdTabsSvc } from './kd-angular-tabs-svc';
import { KdDomElemSvc } from '../kd-common/index';
import { KdSplitterEvent } from '../kd-angular-splitter/index';
export class KdTabs {
    constructor(_vcr, _renderer, _cd, _tabSvc, _router, _activeRoute, _domEle, _splitterEvent) {
        this._vcr = _vcr;
        this._renderer = _renderer;
        this._cd = _cd;
        this._tabSvc = _tabSvc;
        this._router = _router;
        this._domEle = _domEle;
        this._splitterEvent = _splitterEvent;
        this._result = [];
        this._hasArray = false;
        this._scrollBtn = false;
        this._disableLeft = false;
        this._disableRight = false;
        this._left = 0;
        this._maxLeft = 0;
        this._ulWidth = 0;
        this._ulMargin = 0;
        this._parentPadding = 30;
        this.activeState = new EventEmitter();
    }
    onResize(event) {
        this._checkWidth();
        this._checkScrollable();
    }
    ngOnInit() {
        this._id = (typeof this.inputId !== 'undefined') ? this.inputId : 'tabs';
        this._result = this._tabSvc.setResult(this.tabsConfig, this.tabType);
        this._hasArray = this._tabSvc.checkHasArray(this._result);
        if (typeof this._result !== 'undefined') {
            for (let i = 0; i < this._result.length; i++) {
                if (this._result[i].isActive === true) {
                    this._previousItem = this._result[i];
                    this.activeState.emit(this._previousItem.tabId);
                    // if (this._previousItem.tabType === 'router') {
                    //     this._router.navigate(['./' + this._previousItem.routerPath], { relativeTo: this._route });
                    // }
                    break;
                }
            }
        }
        this._splitterEvent.onDrag()
            .subscribe(_type => {
            this._checkWidth();
            this._checkScrollable();
        });
        this._splitterEvent.onToggleMenu()
            .subscribe(_type => {
            timer(500).subscribe(() => {
                this._checkWidth();
                this._checkScrollable();
            });
        });
    }
    ngOnChanges() {
        this._result = this._tabSvc.setResult(this.tabsConfig, this.tabType);
        this._hasArray = this._tabSvc.checkHasArray(this._result);
        if (typeof this._result !== 'undefined') {
            for (let i = 0; i < this._result.length; i++) {
                if (this._result[i].isActive === true) {
                    this._previousItem = this._result[i];
                    this.activeState.emit(this._previousItem.tabId);
                    if (this._previousItem.tabType === 'router') {
                        // console.log('Kd-angular-tab - Need to relook this section', this._previousItem.routerPath, this._route );
                        // this._router.navigate(['./' + this._previousItem.routerPath], { relativeTo: this._route });
                        /* Change the navigation on first load to use full router path to match all the path */
                        this._router.navigateByUrl(this._previousItem.routerPath);
                    }
                    break;
                }
            }
        }
        timer(50).subscribe(() => {
            this._checkWidth();
            this._checkScrollable();
        });
    }
    ngAfterViewInit() {
        // this._direction = this._tabSvc.checkDirection();
        this._direction = this._domEle.getDocumentDirection(true);
        this._checkWidth();
        this._cd.detach();
        this._checkScrollable();
        this._cd.detectChanges();
        this._cd.reattach();
    }
    selectTab(item, e) {
        e.preventDefault();
        if (typeof item.disabled !== 'undefined' && item.disabled)
            return;
        if (typeof this._previousItem !== 'undefined' && this._previousItem !== item) {
            this._previousItem.isActive = false;
        }
        if (item.tabType === 'router' && item.isActive === false) {
            this._router.navigateByUrl(item.routerPath);
        }
        item.isActive = true;
        this._previousItem = item;
        this.activeState.emit(this._previousItem.tabId);
        this._setSelected();
    }
    scroll(direction) {
        let offsetX = 200;
        this._left = (direction === 'right') ? this._left - offsetX : this._left + offsetX;
        this._setLeft();
    }
    _checkWidth() {
        this._ulWidth = 0;
        let ulList = this._vcr.element.nativeElement.querySelectorAll('#' + this._id + ' .nav-item');
        // console.log(ulList);
        // console.log(this._result);
        if (typeof ulList !== 'undefined' && ulList.length > 1) {
            if (this._direction === 'left') {
                this._ulMargin = ulList[1].getBoundingClientRect().left - ulList[0].getBoundingClientRect().right;
            }
            else {
                this._ulMargin = ulList[0].getBoundingClientRect().left - ulList[1].getBoundingClientRect().right;
            }
        }
        if (typeof this._result !== 'undefined') {
            for (let i = 0; i < ulList.length; i++) {
                if (typeof this._result[i] === 'undefined')
                    continue;
                this._result[i].width = Math.round(ulList[i].getBoundingClientRect().width);
                if (i !== 0) {
                    this._result[i].width = Math.round(this._result[i].width + this._ulMargin);
                }
                this._ulWidth += this._result[i].width;
            }
        }
    }
    _checkScrollable() {
        let parentWidth = this._vcr.element.nativeElement.parentElement.getBoundingClientRect().width;
        let ulElement = this._vcr.element.nativeElement.querySelector('#' + this._id + ' .nav-tabs');
        this._scrollBtn = (this._ulWidth > parentWidth) ? true : false;
        this._scrollBtn ? this._renderer.addClass(ulElement, 'scrollable') : this._renderer.removeClass(ulElement, 'scrollable');
        timer(100).subscribe(() => {
            if (ulElement.clientWidth < this._ulWidth) {
                if (this._direction === 'left') {
                    this._maxLeft = ulElement.clientWidth - this._ulWidth;
                }
                else {
                    this._maxLeft = this._ulWidth - ulElement.clientWidth;
                }
            }
            if (!this._scrollBtn) {
                this._left = 0;
                this._setLeft();
            }
            else {
                this._setSelected();
            }
        });
    }
    _setSelected() {
        let parentWidth = this._vcr.element.nativeElement.querySelector('#' + this._id + ' .nav-tabs').clientWidth - this._parentPadding;
        let middle = parentWidth / 2;
        let width = 0;
        if (this._scrollBtn) {
            // if (this._direction === 'left') {
            for (let i = 0; i < this._result.length; i++) {
                if (this._previousItem !== this._result[i]) {
                    width += this._result[i].width;
                }
                else {
                    width += (this._result[i].width / 2);
                    if (this._direction === 'left') {
                        this._left = middle - width;
                    }
                    else {
                        this._left = width - middle;
                    }
                    break;
                }
            }
            // }
            // else {
            //     for (let i: number = this._result.length - 1; i >= 0; i--) {
            //         if (this._previousItem !== this._result[i]) {
            //             width += this._result[i].width;
            //         }
            //         else {
            //             width += (this._result[i].width / 2);
            //             this._left = width - middle;
            //             break;
            //         }
            //     }
            // }
        }
        else {
            this._left = 0;
        }
        this._setLeft();
    }
    _setLeft() {
        let item = this._vcr.element.nativeElement.querySelectorAll('#' + this._id + ' .nav-item');
        if (this._direction === 'left') {
            if (this._left < this._maxLeft) {
                this._left = this._maxLeft;
            }
            else if (this._left >= 0) {
                this._left = 0;
            }
            this._disableLeft = (this._left === 0) ? true : false;
            this._disableRight = (this._left === this._maxLeft) ? true : false;
        }
        else {
            if (this._left < 0) {
                this._left = 0;
            }
            else if (this._left > this._maxLeft) {
                this._left = this._maxLeft;
            }
            this._disableLeft = (this._left === this._maxLeft) ? true : false;
            this._disableRight = (this._left === 0) ? true : false;
        }
        let move = this._left + 'px';
        for (let i = 0; i < item.length; i++) {
            this._renderer.setStyle(item[i], 'left', move);
        }
    }
}
KdTabs.decorators = [
    { type: Component, args: [{
                selector: 'kd-tabs',
                template: `
        <div class='nav-bar' [hidden]='!_hasArray' [id]='_id'>
            <button *ngIf='_scrollBtn' (click)='scroll("left")' class='scroll-left' [disabled]='_disableLeft'><</button>
            <ul class='nav nav-tabs'>
                <ng-template ngFor let-item [ngForOf]='_result'>
                    <li class='nav-item' style='left:0px' [ngClass]='{"tab-selected": item.isActive, "tab-disabled": item.disabled}'>
                        <a (click)='selectTab(item, $event)' class='nav-link'>{{item.tabName}}</a>
                        <!-- <a *ngIf='item.tabType !== "router"' (click)='selectTab(item, $event)' class='nav-link'>{{item.tabName}}</a>
                        <a *ngIf='item.tabType === "router"' (click)='selectTab(item, $event)' class='nav-link' [routerLink]='item.routerPath'>{{item.tabName}}</a> -->
                    </li>
                </ng-template>
            </ul>
            <button *ngIf='_scrollBtn' (click)='scroll("right")' class='scroll-right' [disabled]='_disableRight'>></button>
            <div class='tab-divider'></div>
         </div>

        <ng-template [ngIf]='_previousItem && _previousItem.tabType === "content"'>
            <div class='tab-content'>
                <div class='tab-pane' [ngClass]='{"active": _previousItem.isActive}'>{{_previousItem.tabContent}}</div>
            </div>
        </ng-template>

        <ng-template [ngIf]='tabType === "router" || tabType === "html"'>
            <ng-content></ng-content>
        </ng-template>

        <div class='tab-bottom-divider'></div>
    `,
                encapsulation: ViewEncapsulation.None,
                providers: [KdTabsSvc, KdDomElemSvc],
                host: {
                    'class': 'kdx-tabs',
                },
                styles: [`
        .angular-tabs .nav-tabs .nav-item.tab-disabled > a.nav-link:hover {
            color: #333 !important;
            border: 1px solid #DDD !important;
            cursor: not-allowed !important;
            background-color: transparent !important;
        }
    `]
            },] }
];
KdTabs.ctorParameters = () => [
    { type: ViewContainerRef },
    { type: Renderer2 },
    { type: ChangeDetectorRef },
    { type: KdTabsSvc },
    { type: Router },
    { type: ActivatedRoute },
    { type: KdDomElemSvc },
    { type: KdSplitterEvent }
];
KdTabs.propDecorators = {
    inputId: [{ type: Input }],
    tabsConfig: [{ type: Input, args: ['config',] }],
    tabType: [{ type: Input, args: ['type',] }],
    activeState: [{ type: Output }],
    onResize: [{ type: HostListener, args: ['window:resize', ['$event'],] }]
};
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoia2QtYW5ndWxhci10YWJzLmpzIiwic291cmNlUm9vdCI6IkM6L1Byb2plY3RzL0FuZ3VsYXIvaW9zdGctb3BlbmVtaXMtc3R5bGVndWlkZS9wcm9qZWN0cy9vcGVuZW1pcy1zdHlsZWd1aWRlLWxpYi9zcmMvIiwic291cmNlcyI6WyJrZC1jb21wb25lbnRzL2tkLWFuZ3VsYXItdGFicy9rZC1hbmd1bGFyLXRhYnMudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsT0FBTyxFQUFFLFNBQVMsRUFBRSxLQUFLLEVBQUUsTUFBTSxFQUFFLFlBQVksRUFBRSxpQkFBaUIsRUFBb0MsZ0JBQWdCLEVBQUUsWUFBWSxFQUFFLGlCQUFpQixFQUFFLFNBQVMsRUFBRSxNQUFNLGVBQWUsQ0FBQztBQUMxTCxPQUFPLEVBQUUsS0FBSyxFQUFFLE1BQU0sTUFBTSxDQUFDO0FBQzdCLE9BQU8sRUFBRSxNQUFNLEVBQUUsY0FBYyxFQUFFLE1BQU0saUJBQWlCLENBQUM7QUFDekQsT0FBTyxFQUFFLFNBQVMsRUFBRSxNQUFNLHVCQUF1QixDQUFDO0FBQ2xELE9BQU8sRUFBRSxZQUFZLEVBQUUsTUFBTSxvQkFBb0IsQ0FBQztBQUNsRCxPQUFPLEVBQUUsZUFBZSxFQUFFLE1BQU0sOEJBQThCLENBQUM7QUFnRC9ELE1BQU0sT0FBTyxNQUFNO0lBcUJmLFlBQ1ksSUFBc0IsRUFDdEIsU0FBb0IsRUFDcEIsR0FBc0IsRUFDdEIsT0FBa0IsRUFDbEIsT0FBZSxFQUN2QixZQUE0QixFQUNwQixPQUFxQixFQUNyQixjQUErQjtRQVAvQixTQUFJLEdBQUosSUFBSSxDQUFrQjtRQUN0QixjQUFTLEdBQVQsU0FBUyxDQUFXO1FBQ3BCLFFBQUcsR0FBSCxHQUFHLENBQW1CO1FBQ3RCLFlBQU8sR0FBUCxPQUFPLENBQVc7UUFDbEIsWUFBTyxHQUFQLE9BQU8sQ0FBUTtRQUVmLFlBQU8sR0FBUCxPQUFPLENBQWM7UUFDckIsbUJBQWMsR0FBZCxjQUFjLENBQWlCO1FBM0JwQyxZQUFPLEdBQWUsRUFBRSxDQUFDO1FBQ3pCLGNBQVMsR0FBWSxLQUFLLENBQUM7UUFDM0IsZUFBVSxHQUFZLEtBQUssQ0FBQztRQUU1QixpQkFBWSxHQUFZLEtBQUssQ0FBQztRQUM5QixrQkFBYSxHQUFZLEtBQUssQ0FBQztRQUU5QixVQUFLLEdBQVcsQ0FBQyxDQUFDO1FBQ2xCLGFBQVEsR0FBVyxDQUFDLENBQUM7UUFDckIsYUFBUSxHQUFXLENBQUMsQ0FBQztRQUNyQixjQUFTLEdBQVcsQ0FBQyxDQUFDO1FBRXRCLG1CQUFjLEdBQVcsRUFBRSxDQUFDO1FBSzFCLGdCQUFXLEdBQXFCLElBQUksWUFBWSxFQUFFLENBQUM7SUFVZCxDQUFDO0lBR2hELFFBQVEsQ0FBQyxLQUFVO1FBQ2YsSUFBSSxDQUFDLFdBQVcsRUFBRSxDQUFDO1FBQ25CLElBQUksQ0FBQyxnQkFBZ0IsRUFBRSxDQUFDO0lBQzVCLENBQUM7SUFFRCxRQUFRO1FBQ0osSUFBSSxDQUFDLEdBQUcsR0FBRyxDQUFDLE9BQU8sSUFBSSxDQUFDLE9BQU8sS0FBSyxXQUFXLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDO1FBQ3pFLElBQUksQ0FBQyxPQUFPLEdBQUcsSUFBSSxDQUFDLE9BQU8sQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDLFVBQVUsRUFBRSxJQUFJLENBQUMsT0FBTyxDQUFDLENBQUM7UUFFckUsSUFBSSxDQUFDLFNBQVMsR0FBRyxJQUFJLENBQUMsT0FBTyxDQUFDLGFBQWEsQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLENBQUM7UUFFMUQsSUFBSSxPQUFPLElBQUksQ0FBQyxPQUFPLEtBQUssV0FBVyxFQUFFO1lBQ3JDLEtBQUssSUFBSSxDQUFDLEdBQVcsQ0FBQyxFQUFFLENBQUMsR0FBRyxJQUFJLENBQUMsT0FBTyxDQUFDLE1BQU0sRUFBRSxDQUFDLEVBQUUsRUFBRTtnQkFDbEQsSUFBSSxJQUFJLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsS0FBSyxJQUFJLEVBQUU7b0JBQ25DLElBQUksQ0FBQyxhQUFhLEdBQUcsSUFBSSxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQztvQkFDckMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLGFBQWEsQ0FBQyxLQUFLLENBQUMsQ0FBQztvQkFFaEQsaURBQWlEO29CQUNqRCxrR0FBa0c7b0JBQ2xHLElBQUk7b0JBQ0osTUFBTTtpQkFDVDthQUNKO1NBQ0o7UUFFRCxJQUFJLENBQUMsY0FBYyxDQUFDLE1BQU0sRUFBRTthQUN2QixTQUFTLENBQUMsS0FBSyxDQUFDLEVBQUU7WUFDZixJQUFJLENBQUMsV0FBVyxFQUFFLENBQUM7WUFDbkIsSUFBSSxDQUFDLGdCQUFnQixFQUFFLENBQUM7UUFDNUIsQ0FBQyxDQUFDLENBQUM7UUFFUCxJQUFJLENBQUMsY0FBYyxDQUFDLFlBQVksRUFBRTthQUM3QixTQUFTLENBQUMsS0FBSyxDQUFDLEVBQUU7WUFDZixLQUFLLENBQUMsR0FBRyxDQUFDLENBQUMsU0FBUyxDQUFDLEdBQVMsRUFBRTtnQkFDNUIsSUFBSSxDQUFDLFdBQVcsRUFBRSxDQUFDO2dCQUNuQixJQUFJLENBQUMsZ0JBQWdCLEVBQUUsQ0FBQztZQUM1QixDQUFDLENBQUMsQ0FBQztRQUNQLENBQUMsQ0FBQyxDQUFDO0lBQ1gsQ0FBQztJQUVELFdBQVc7UUFDUCxJQUFJLENBQUMsT0FBTyxHQUFHLElBQUksQ0FBQyxPQUFPLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQyxVQUFVLEVBQUUsSUFBSSxDQUFDLE9BQU8sQ0FBQyxDQUFDO1FBQ3JFLElBQUksQ0FBQyxTQUFTLEdBQUcsSUFBSSxDQUFDLE9BQU8sQ0FBQyxhQUFhLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxDQUFDO1FBRTFELElBQUksT0FBTyxJQUFJLENBQUMsT0FBTyxLQUFLLFdBQVcsRUFBRTtZQUNyQyxLQUFLLElBQUksQ0FBQyxHQUFXLENBQUMsRUFBRSxDQUFDLEdBQUcsSUFBSSxDQUFDLE9BQU8sQ0FBQyxNQUFNLEVBQUUsQ0FBQyxFQUFFLEVBQUU7Z0JBQ2xELElBQUksSUFBSSxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLEtBQUssSUFBSSxFQUFFO29CQUNuQyxJQUFJLENBQUMsYUFBYSxHQUFHLElBQUksQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUM7b0JBQ3JDLElBQUksQ0FBQyxXQUFXLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxhQUFhLENBQUMsS0FBSyxDQUFDLENBQUM7b0JBRWhELElBQUksSUFBSSxDQUFDLGFBQWEsQ0FBQyxPQUFPLEtBQUssUUFBUSxFQUFFO3dCQUN6Qyw0R0FBNEc7d0JBQzVHLDhGQUE4Rjt3QkFDOUYsdUZBQXVGO3dCQUN2RixJQUFJLENBQUMsT0FBTyxDQUFDLGFBQWEsQ0FBQyxJQUFJLENBQUMsYUFBYSxDQUFDLFVBQVUsQ0FBQyxDQUFDO3FCQUM3RDtvQkFDRCxNQUFNO2lCQUNUO2FBQ0o7U0FDSjtRQUVELEtBQUssQ0FBQyxFQUFFLENBQUMsQ0FBQyxTQUFTLENBQUMsR0FBUyxFQUFFO1lBQzNCLElBQUksQ0FBQyxXQUFXLEVBQUUsQ0FBQztZQUNuQixJQUFJLENBQUMsZ0JBQWdCLEVBQUUsQ0FBQztRQUM1QixDQUFDLENBQUMsQ0FBQztJQUVQLENBQUM7SUFFRCxlQUFlO1FBQ1gsbURBQW1EO1FBQ25ELElBQUksQ0FBQyxVQUFVLEdBQUcsSUFBSSxDQUFDLE9BQU8sQ0FBQyxvQkFBb0IsQ0FBQyxJQUFJLENBQUMsQ0FBQztRQUMxRCxJQUFJLENBQUMsV0FBVyxFQUFFLENBQUM7UUFFbkIsSUFBSSxDQUFDLEdBQUcsQ0FBQyxNQUFNLEVBQUUsQ0FBQztRQUNsQixJQUFJLENBQUMsZ0JBQWdCLEVBQUUsQ0FBQztRQUN4QixJQUFJLENBQUMsR0FBRyxDQUFDLGFBQWEsRUFBRSxDQUFDO1FBQ3pCLElBQUksQ0FBQyxHQUFHLENBQUMsUUFBUSxFQUFFLENBQUM7SUFDeEIsQ0FBQztJQUVNLFNBQVMsQ0FBQyxJQUFTLEVBQUUsQ0FBUTtRQUNoQyxDQUFDLENBQUMsY0FBYyxFQUFFLENBQUM7UUFDbkIsSUFBSSxPQUFPLElBQUksQ0FBQyxRQUFRLEtBQUssV0FBVyxJQUFJLElBQUksQ0FBQyxRQUFRO1lBQUUsT0FBTztRQUVsRSxJQUFJLE9BQU8sSUFBSSxDQUFDLGFBQWEsS0FBSyxXQUFXLElBQUksSUFBSSxDQUFDLGFBQWEsS0FBSyxJQUFJLEVBQUU7WUFDMUUsSUFBSSxDQUFDLGFBQWEsQ0FBQyxRQUFRLEdBQUcsS0FBSyxDQUFDO1NBQ3ZDO1FBRUQsSUFBSSxJQUFJLENBQUMsT0FBTyxLQUFLLFFBQVEsSUFBSSxJQUFJLENBQUMsUUFBUSxLQUFLLEtBQUssRUFBRTtZQUN0RCxJQUFJLENBQUMsT0FBTyxDQUFDLGFBQWEsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLENBQUM7U0FDL0M7UUFFRCxJQUFJLENBQUMsUUFBUSxHQUFHLElBQUksQ0FBQztRQUNyQixJQUFJLENBQUMsYUFBYSxHQUFHLElBQUksQ0FBQztRQUMxQixJQUFJLENBQUMsV0FBVyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsYUFBYSxDQUFDLEtBQUssQ0FBQyxDQUFDO1FBQ2hELElBQUksQ0FBQyxZQUFZLEVBQUUsQ0FBQztJQUN4QixDQUFDO0lBRU0sTUFBTSxDQUFDLFNBQWlCO1FBQzNCLElBQUksT0FBTyxHQUFXLEdBQUcsQ0FBQztRQUMxQixJQUFJLENBQUMsS0FBSyxHQUFHLENBQUMsU0FBUyxLQUFLLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsS0FBSyxHQUFHLE9BQU8sQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLEtBQUssR0FBRyxPQUFPLENBQUM7UUFDbkYsSUFBSSxDQUFDLFFBQVEsRUFBRSxDQUFDO0lBQ3BCLENBQUM7SUFFTyxXQUFXO1FBQ2YsSUFBSSxDQUFDLFFBQVEsR0FBRyxDQUFDLENBQUM7UUFDbEIsSUFBSSxNQUFNLEdBQXVCLElBQUksQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLGFBQWEsQ0FBQyxnQkFBZ0IsQ0FBQyxHQUFHLEdBQUcsSUFBSSxDQUFDLEdBQUcsR0FBRyxZQUFZLENBQUMsQ0FBQztRQUNqSCx1QkFBdUI7UUFDdkIsNkJBQTZCO1FBQzdCLElBQUksT0FBTyxNQUFNLEtBQUssV0FBVyxJQUFJLE1BQU0sQ0FBQyxNQUFNLEdBQUcsQ0FBQyxFQUFFO1lBQ3BELElBQUksSUFBSSxDQUFDLFVBQVUsS0FBSyxNQUFNLEVBQUU7Z0JBQzVCLElBQUksQ0FBQyxTQUFTLEdBQUcsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLHFCQUFxQixFQUFFLENBQUMsSUFBSSxHQUFHLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxxQkFBcUIsRUFBRSxDQUFDLEtBQUssQ0FBQzthQUNyRztpQkFDSTtnQkFDRCxJQUFJLENBQUMsU0FBUyxHQUFHLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxxQkFBcUIsRUFBRSxDQUFDLElBQUksR0FBRyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMscUJBQXFCLEVBQUUsQ0FBQyxLQUFLLENBQUM7YUFDckc7U0FDSjtRQUVELElBQUksT0FBTyxJQUFJLENBQUMsT0FBTyxLQUFLLFdBQVcsRUFBRTtZQUNyQyxLQUFLLElBQUksQ0FBQyxHQUFXLENBQUMsRUFBRSxDQUFDLEdBQUcsTUFBTSxDQUFDLE1BQU0sRUFBRSxDQUFDLEVBQUUsRUFBRTtnQkFDNUMsSUFBSSxPQUFPLElBQUksQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLEtBQUssV0FBVztvQkFBRSxTQUFTO2dCQUVyRCxJQUFJLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxxQkFBcUIsRUFBRSxDQUFDLEtBQUssQ0FBQyxDQUFDO2dCQUU1RSxJQUFJLENBQUMsS0FBSyxDQUFDLEVBQUU7b0JBQ1QsSUFBSSxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssR0FBRyxJQUFJLENBQUMsU0FBUyxDQUFDLENBQUM7aUJBQzlFO2dCQUNELElBQUksQ0FBQyxRQUFRLElBQUksSUFBSSxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUM7YUFDMUM7U0FDSjtJQUVMLENBQUM7SUFFTyxnQkFBZ0I7UUFDcEIsSUFBSSxXQUFXLEdBQVcsSUFBSSxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsYUFBYSxDQUFDLGFBQWEsQ0FBQyxxQkFBcUIsRUFBRSxDQUFDLEtBQUssQ0FBQztRQUN0RyxJQUFJLFNBQVMsR0FBZ0IsSUFBSSxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsYUFBYSxDQUFDLGFBQWEsQ0FBQyxHQUFHLEdBQUcsSUFBSSxDQUFDLEdBQUcsR0FBRyxZQUFZLENBQUMsQ0FBQztRQUMxRyxJQUFJLENBQUMsVUFBVSxHQUFHLENBQUMsSUFBSSxDQUFDLFFBQVEsR0FBRyxXQUFXLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUM7UUFDL0QsSUFBSSxDQUFDLFVBQVUsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxRQUFRLENBQUMsU0FBUyxFQUFFLFlBQVksQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLFdBQVcsQ0FBQyxTQUFTLEVBQUUsWUFBWSxDQUFDLENBQUM7UUFFekgsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxHQUFTLEVBQUU7WUFDNUIsSUFBSSxTQUFTLENBQUMsV0FBVyxHQUFHLElBQUksQ0FBQyxRQUFRLEVBQUU7Z0JBQ3ZDLElBQUksSUFBSSxDQUFDLFVBQVUsS0FBSyxNQUFNLEVBQUU7b0JBQzVCLElBQUksQ0FBQyxRQUFRLEdBQUcsU0FBUyxDQUFDLFdBQVcsR0FBRyxJQUFJLENBQUMsUUFBUSxDQUFDO2lCQUN6RDtxQkFDSTtvQkFDRCxJQUFJLENBQUMsUUFBUSxHQUFHLElBQUksQ0FBQyxRQUFRLEdBQUcsU0FBUyxDQUFDLFdBQVcsQ0FBQztpQkFDekQ7YUFDSjtZQUVELElBQUksQ0FBQyxJQUFJLENBQUMsVUFBVSxFQUFFO2dCQUNsQixJQUFJLENBQUMsS0FBSyxHQUFHLENBQUMsQ0FBQztnQkFDZixJQUFJLENBQUMsUUFBUSxFQUFFLENBQUM7YUFDbkI7aUJBQ0k7Z0JBQ0QsSUFBSSxDQUFDLFlBQVksRUFBRSxDQUFDO2FBQ3ZCO1FBQ0wsQ0FBQyxDQUFDLENBQUM7SUFDUCxDQUFDO0lBRU8sWUFBWTtRQUNoQixJQUFJLFdBQVcsR0FBVyxJQUFJLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxhQUFhLENBQUMsYUFBYSxDQUFDLEdBQUcsR0FBRyxJQUFJLENBQUMsR0FBRyxHQUFHLFlBQVksQ0FBQyxDQUFDLFdBQVcsR0FBRyxJQUFJLENBQUMsY0FBYyxDQUFDO1FBQ3pJLElBQUksTUFBTSxHQUFHLFdBQVcsR0FBRyxDQUFDLENBQUM7UUFDN0IsSUFBSSxLQUFLLEdBQUcsQ0FBQyxDQUFDO1FBRWQsSUFBSSxJQUFJLENBQUMsVUFBVSxFQUFFO1lBQ2pCLG9DQUFvQztZQUNwQyxLQUFLLElBQUksQ0FBQyxHQUFXLENBQUMsRUFBRSxDQUFDLEdBQUcsSUFBSSxDQUFDLE9BQU8sQ0FBQyxNQUFNLEVBQUUsQ0FBQyxFQUFFLEVBQUU7Z0JBQ2xELElBQUksSUFBSSxDQUFDLGFBQWEsS0FBSyxJQUFJLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxFQUFFO29CQUN4QyxLQUFLLElBQUksSUFBSSxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUM7aUJBQ2xDO3FCQUNJO29CQUNELEtBQUssSUFBSSxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxHQUFHLENBQUMsQ0FBQyxDQUFDO29CQUVyQyxJQUFJLElBQUksQ0FBQyxVQUFVLEtBQUssTUFBTSxFQUFFO3dCQUM1QixJQUFJLENBQUMsS0FBSyxHQUFHLE1BQU0sR0FBRyxLQUFLLENBQUM7cUJBQy9CO3lCQUNJO3dCQUNELElBQUksQ0FBQyxLQUFLLEdBQUcsS0FBSyxHQUFHLE1BQU0sQ0FBQztxQkFDL0I7b0JBQ0QsTUFBTTtpQkFDVDthQUNKO1lBQ0QsSUFBSTtZQUVKLFNBQVM7WUFDVCxtRUFBbUU7WUFDbkUsd0RBQXdEO1lBQ3hELDhDQUE4QztZQUM5QyxZQUFZO1lBQ1osaUJBQWlCO1lBQ2pCLG9EQUFvRDtZQUNwRCwyQ0FBMkM7WUFDM0MscUJBQXFCO1lBQ3JCLFlBQVk7WUFDWixRQUFRO1lBQ1IsSUFBSTtTQUNQO2FBQ0k7WUFDRCxJQUFJLENBQUMsS0FBSyxHQUFHLENBQUMsQ0FBQztTQUNsQjtRQUNELElBQUksQ0FBQyxRQUFRLEVBQUUsQ0FBQztJQUNwQixDQUFDO0lBRU8sUUFBUTtRQUNaLElBQUksSUFBSSxHQUF1QixJQUFJLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxhQUFhLENBQUMsZ0JBQWdCLENBQUMsR0FBRyxHQUFHLElBQUksQ0FBQyxHQUFHLEdBQUcsWUFBWSxDQUFDLENBQUM7UUFFL0csSUFBSSxJQUFJLENBQUMsVUFBVSxLQUFLLE1BQU0sRUFBRTtZQUM1QixJQUFJLElBQUksQ0FBQyxLQUFLLEdBQUcsSUFBSSxDQUFDLFFBQVEsRUFBRTtnQkFDNUIsSUFBSSxDQUFDLEtBQUssR0FBRyxJQUFJLENBQUMsUUFBUSxDQUFDO2FBRTlCO2lCQUNJLElBQUksSUFBSSxDQUFDLEtBQUssSUFBSSxDQUFDLEVBQUU7Z0JBQ3RCLElBQUksQ0FBQyxLQUFLLEdBQUcsQ0FBQyxDQUFDO2FBQ2xCO1lBRUQsSUFBSSxDQUFDLFlBQVksR0FBRyxDQUFDLElBQUksQ0FBQyxLQUFLLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDO1lBQ3RELElBQUksQ0FBQyxhQUFhLEdBQUcsQ0FBQyxJQUFJLENBQUMsS0FBSyxLQUFLLElBQUksQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUM7U0FDdEU7YUFDSTtZQUNELElBQUksSUFBSSxDQUFDLEtBQUssR0FBRyxDQUFDLEVBQUU7Z0JBQ2hCLElBQUksQ0FBQyxLQUFLLEdBQUcsQ0FBQyxDQUFDO2FBQ2xCO2lCQUNJLElBQUksSUFBSSxDQUFDLEtBQUssR0FBRyxJQUFJLENBQUMsUUFBUSxFQUFFO2dCQUNqQyxJQUFJLENBQUMsS0FBSyxHQUFHLElBQUksQ0FBQyxRQUFRLENBQUM7YUFDOUI7WUFFRCxJQUFJLENBQUMsWUFBWSxHQUFHLENBQUMsSUFBSSxDQUFDLEtBQUssS0FBSyxJQUFJLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDO1lBQ2xFLElBQUksQ0FBQyxhQUFhLEdBQUcsQ0FBQyxJQUFJLENBQUMsS0FBSyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQztTQUMxRDtRQUdELElBQUksSUFBSSxHQUFHLElBQUksQ0FBQyxLQUFLLEdBQUcsSUFBSSxDQUFDO1FBRTdCLEtBQUssSUFBSSxDQUFDLEdBQVcsQ0FBQyxFQUFFLENBQUMsR0FBRyxJQUFJLENBQUMsTUFBTSxFQUFFLENBQUMsRUFBRSxFQUFFO1lBQzFDLElBQUksQ0FBQyxTQUFTLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsRUFBRSxNQUFNLEVBQUUsSUFBSSxDQUFDLENBQUM7U0FDbEQ7SUFDTCxDQUFDOzs7WUF6VEosU0FBUyxTQUFDO2dCQUNQLFFBQVEsRUFBRSxTQUFTO2dCQUNmLFFBQVEsRUFBRTs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0tBMkJiO2dCQUNELGFBQWEsRUFBRSxpQkFBaUIsQ0FBQyxJQUFJO2dCQUNyQyxTQUFTLEVBQUUsQ0FBQyxTQUFTLEVBQUUsWUFBWSxDQUFDO2dCQUNwQyxJQUFJLEVBQUU7b0JBQ0YsT0FBTyxFQUFFLFVBQVU7aUJBQ3RCO3lCQUVROzs7Ozs7O0tBT1I7YUFDSjs7O1lBbkRxRyxnQkFBZ0I7WUFBbUMsU0FBUztZQUE1QixpQkFBaUI7WUFHOUksU0FBUztZQURULE1BQU07WUFBRSxjQUFjO1lBRXRCLFlBQVk7WUFDWixlQUFlOzs7c0JBZ0VuQixLQUFLO3lCQUNMLEtBQUssU0FBQyxRQUFRO3NCQUNkLEtBQUssU0FBQyxNQUFNOzBCQUNaLE1BQU07dUJBWU4sWUFBWSxTQUFDLGVBQWUsRUFBRSxDQUFDLFFBQVEsQ0FBQyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IENvbXBvbmVudCwgSW5wdXQsIE91dHB1dCwgRXZlbnRFbWl0dGVyLCBWaWV3RW5jYXBzdWxhdGlvbiwgT25Jbml0LCBPbkNoYW5nZXMsIEFmdGVyVmlld0luaXQsIFZpZXdDb250YWluZXJSZWYsIEhvc3RMaXN0ZW5lciwgQ2hhbmdlRGV0ZWN0b3JSZWYsIFJlbmRlcmVyMiB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xyXG5pbXBvcnQgeyB0aW1lciB9IGZyb20gJ3J4anMnO1xyXG5pbXBvcnQgeyBSb3V0ZXIsIEFjdGl2YXRlZFJvdXRlIH0gZnJvbSAnQGFuZ3VsYXIvcm91dGVyJztcclxuaW1wb3J0IHsgS2RUYWJzU3ZjIH0gZnJvbSAnLi9rZC1hbmd1bGFyLXRhYnMtc3ZjJztcclxuaW1wb3J0IHsgS2REb21FbGVtU3ZjIH0gZnJvbSAnLi4va2QtY29tbW9uL2luZGV4JztcclxuaW1wb3J0IHsgS2RTcGxpdHRlckV2ZW50IH0gZnJvbSAnLi4va2QtYW5ndWxhci1zcGxpdHRlci9pbmRleCc7XHJcblxyXG5AQ29tcG9uZW50KHtcclxuICAgIHNlbGVjdG9yOiAna2QtdGFicycsXHJcbiAgICAgICAgdGVtcGxhdGU6IGBcclxuICAgICAgICA8ZGl2IGNsYXNzPSduYXYtYmFyJyBbaGlkZGVuXT0nIV9oYXNBcnJheScgW2lkXT0nX2lkJz5cclxuICAgICAgICAgICAgPGJ1dHRvbiAqbmdJZj0nX3Njcm9sbEJ0bicgKGNsaWNrKT0nc2Nyb2xsKFwibGVmdFwiKScgY2xhc3M9J3Njcm9sbC1sZWZ0JyBbZGlzYWJsZWRdPSdfZGlzYWJsZUxlZnQnPjw8L2J1dHRvbj5cclxuICAgICAgICAgICAgPHVsIGNsYXNzPSduYXYgbmF2LXRhYnMnPlxyXG4gICAgICAgICAgICAgICAgPG5nLXRlbXBsYXRlIG5nRm9yIGxldC1pdGVtIFtuZ0Zvck9mXT0nX3Jlc3VsdCc+XHJcbiAgICAgICAgICAgICAgICAgICAgPGxpIGNsYXNzPSduYXYtaXRlbScgc3R5bGU9J2xlZnQ6MHB4JyBbbmdDbGFzc109J3tcInRhYi1zZWxlY3RlZFwiOiBpdGVtLmlzQWN0aXZlLCBcInRhYi1kaXNhYmxlZFwiOiBpdGVtLmRpc2FibGVkfSc+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxhIChjbGljayk9J3NlbGVjdFRhYihpdGVtLCAkZXZlbnQpJyBjbGFzcz0nbmF2LWxpbmsnPnt7aXRlbS50YWJOYW1lfX08L2E+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwhLS0gPGEgKm5nSWY9J2l0ZW0udGFiVHlwZSAhPT0gXCJyb3V0ZXJcIicgKGNsaWNrKT0nc2VsZWN0VGFiKGl0ZW0sICRldmVudCknIGNsYXNzPSduYXYtbGluayc+e3tpdGVtLnRhYk5hbWV9fTwvYT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGEgKm5nSWY9J2l0ZW0udGFiVHlwZSA9PT0gXCJyb3V0ZXJcIicgKGNsaWNrKT0nc2VsZWN0VGFiKGl0ZW0sICRldmVudCknIGNsYXNzPSduYXYtbGluaycgW3JvdXRlckxpbmtdPSdpdGVtLnJvdXRlclBhdGgnPnt7aXRlbS50YWJOYW1lfX08L2E+IC0tPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvbGk+XHJcbiAgICAgICAgICAgICAgICA8L25nLXRlbXBsYXRlPlxyXG4gICAgICAgICAgICA8L3VsPlxyXG4gICAgICAgICAgICA8YnV0dG9uICpuZ0lmPSdfc2Nyb2xsQnRuJyAoY2xpY2spPSdzY3JvbGwoXCJyaWdodFwiKScgY2xhc3M9J3Njcm9sbC1yaWdodCcgW2Rpc2FibGVkXT0nX2Rpc2FibGVSaWdodCc+PjwvYnV0dG9uPlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzPSd0YWItZGl2aWRlcic+PC9kaXY+XHJcbiAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICA8bmctdGVtcGxhdGUgW25nSWZdPSdfcHJldmlvdXNJdGVtICYmIF9wcmV2aW91c0l0ZW0udGFiVHlwZSA9PT0gXCJjb250ZW50XCInPlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzPSd0YWItY29udGVudCc+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzPSd0YWItcGFuZScgW25nQ2xhc3NdPSd7XCJhY3RpdmVcIjogX3ByZXZpb3VzSXRlbS5pc0FjdGl2ZX0nPnt7X3ByZXZpb3VzSXRlbS50YWJDb250ZW50fX08L2Rpdj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPC9uZy10ZW1wbGF0ZT5cclxuXHJcbiAgICAgICAgPG5nLXRlbXBsYXRlIFtuZ0lmXT0ndGFiVHlwZSA9PT0gXCJyb3V0ZXJcIiB8fCB0YWJUeXBlID09PSBcImh0bWxcIic+XHJcbiAgICAgICAgICAgIDxuZy1jb250ZW50PjwvbmctY29udGVudD5cclxuICAgICAgICA8L25nLXRlbXBsYXRlPlxyXG5cclxuICAgICAgICA8ZGl2IGNsYXNzPSd0YWItYm90dG9tLWRpdmlkZXInPjwvZGl2PlxyXG4gICAgYCxcclxuICAgIGVuY2Fwc3VsYXRpb246IFZpZXdFbmNhcHN1bGF0aW9uLk5vbmUsXHJcbiAgICBwcm92aWRlcnM6IFtLZFRhYnNTdmMsIEtkRG9tRWxlbVN2Y10sXHJcbiAgICBob3N0OiB7XHJcbiAgICAgICAgJ2NsYXNzJzogJ2tkeC10YWJzJyxcclxuICAgIH0sXHJcbiAgICAvLyBUZW1wIHNjaG9vbCBvdmVyd3JpdGVzIGZvciBzdHlsaW5nIGZvciBkaXNhYmxlZCBhdHRyaWJ1dGUgZm9yIE9wZW5FTUlTIFNjaG9vbCBvbmx5IC0gVG8gcHJvcGVyIHVwZGF0ZXMgc3R5bGUgY2xhc3NlcyBpbiBzdHlsZWd1aWRlIHRvIGhhdmUgdGhlIGRpc2FibGVkIGNsYXNzIHN0eWxpbmdcclxuICAgIHN0eWxlczogW2BcclxuICAgICAgICAuYW5ndWxhci10YWJzIC5uYXYtdGFicyAubmF2LWl0ZW0udGFiLWRpc2FibGVkID4gYS5uYXYtbGluazpob3ZlciB7XHJcbiAgICAgICAgICAgIGNvbG9yOiAjMzMzICFpbXBvcnRhbnQ7XHJcbiAgICAgICAgICAgIGJvcmRlcjogMXB4IHNvbGlkICNEREQgIWltcG9ydGFudDtcclxuICAgICAgICAgICAgY3Vyc29yOiBub3QtYWxsb3dlZCAhaW1wb3J0YW50O1xyXG4gICAgICAgICAgICBiYWNrZ3JvdW5kLWNvbG9yOiB0cmFuc3BhcmVudCAhaW1wb3J0YW50O1xyXG4gICAgICAgIH1cclxuICAgIGBdXHJcbn0pXHJcblxyXG5leHBvcnQgY2xhc3MgS2RUYWJzIGltcGxlbWVudHMgT25Jbml0LCBPbkNoYW5nZXMsIEFmdGVyVmlld0luaXQge1xyXG4gICAgcHVibGljIF9pZDogc3RyaW5nO1xyXG4gICAgcHVibGljIF9yZXN1bHQ6IEFycmF5PGFueT4gPSBbXTtcclxuICAgIHB1YmxpYyBfaGFzQXJyYXk6IGJvb2xlYW4gPSBmYWxzZTtcclxuICAgIHB1YmxpYyBfc2Nyb2xsQnRuOiBib29sZWFuID0gZmFsc2U7XHJcbiAgICBwdWJsaWMgX3ByZXZpb3VzSXRlbTogYW55O1xyXG4gICAgcHVibGljIF9kaXNhYmxlTGVmdDogYm9vbGVhbiA9IGZhbHNlO1xyXG4gICAgcHVibGljIF9kaXNhYmxlUmlnaHQ6IGJvb2xlYW4gPSBmYWxzZTtcclxuXHJcbiAgICBwcml2YXRlIF9sZWZ0OiBudW1iZXIgPSAwO1xyXG4gICAgcHJpdmF0ZSBfbWF4TGVmdDogbnVtYmVyID0gMDtcclxuICAgIHByaXZhdGUgX3VsV2lkdGg6IG51bWJlciA9IDA7XHJcbiAgICBwcml2YXRlIF91bE1hcmdpbjogbnVtYmVyID0gMDtcclxuICAgIHByaXZhdGUgX2RpcmVjdGlvbjogYW55O1xyXG4gICAgcHJpdmF0ZSBfcGFyZW50UGFkZGluZzogbnVtYmVyID0gMzA7XHJcblxyXG4gICAgQElucHV0KCkgaW5wdXRJZDogc3RyaW5nO1xyXG4gICAgQElucHV0KCdjb25maWcnKSB0YWJzQ29uZmlnOiBhbnk7XHJcbiAgICBASW5wdXQoJ3R5cGUnKSB0YWJUeXBlOiBzdHJpbmc7XHJcbiAgICBAT3V0cHV0KCkgYWN0aXZlU3RhdGU6IEV2ZW50RW1pdHRlcjx7fT4gPSBuZXcgRXZlbnRFbWl0dGVyKCk7XHJcblxyXG4gICAgY29uc3RydWN0b3IoXHJcbiAgICAgICAgcHJpdmF0ZSBfdmNyOiBWaWV3Q29udGFpbmVyUmVmLFxyXG4gICAgICAgIHByaXZhdGUgX3JlbmRlcmVyOiBSZW5kZXJlcjIsXHJcbiAgICAgICAgcHJpdmF0ZSBfY2Q6IENoYW5nZURldGVjdG9yUmVmLFxyXG4gICAgICAgIHByaXZhdGUgX3RhYlN2YzogS2RUYWJzU3ZjLFxyXG4gICAgICAgIHByaXZhdGUgX3JvdXRlcjogUm91dGVyLFxyXG4gICAgICAgIF9hY3RpdmVSb3V0ZTogQWN0aXZhdGVkUm91dGUsXHJcbiAgICAgICAgcHJpdmF0ZSBfZG9tRWxlOiBLZERvbUVsZW1TdmMsXHJcbiAgICAgICAgcHJpdmF0ZSBfc3BsaXR0ZXJFdmVudDogS2RTcGxpdHRlckV2ZW50KSB7IH1cclxuXHJcbiAgICBASG9zdExpc3RlbmVyKCd3aW5kb3c6cmVzaXplJywgWyckZXZlbnQnXSlcclxuICAgIG9uUmVzaXplKGV2ZW50OiBhbnkpOiB2b2lkIHtcclxuICAgICAgICB0aGlzLl9jaGVja1dpZHRoKCk7XHJcbiAgICAgICAgdGhpcy5fY2hlY2tTY3JvbGxhYmxlKCk7XHJcbiAgICB9XHJcblxyXG4gICAgbmdPbkluaXQoKTogdm9pZCB7XHJcbiAgICAgICAgdGhpcy5faWQgPSAodHlwZW9mIHRoaXMuaW5wdXRJZCAhPT0gJ3VuZGVmaW5lZCcpID8gdGhpcy5pbnB1dElkIDogJ3RhYnMnO1xyXG4gICAgICAgIHRoaXMuX3Jlc3VsdCA9IHRoaXMuX3RhYlN2Yy5zZXRSZXN1bHQodGhpcy50YWJzQ29uZmlnLCB0aGlzLnRhYlR5cGUpO1xyXG5cclxuICAgICAgICB0aGlzLl9oYXNBcnJheSA9IHRoaXMuX3RhYlN2Yy5jaGVja0hhc0FycmF5KHRoaXMuX3Jlc3VsdCk7XHJcblxyXG4gICAgICAgIGlmICh0eXBlb2YgdGhpcy5fcmVzdWx0ICE9PSAndW5kZWZpbmVkJykge1xyXG4gICAgICAgICAgICBmb3IgKGxldCBpOiBudW1iZXIgPSAwOyBpIDwgdGhpcy5fcmVzdWx0Lmxlbmd0aDsgaSsrKSB7XHJcbiAgICAgICAgICAgICAgICBpZiAodGhpcy5fcmVzdWx0W2ldLmlzQWN0aXZlID09PSB0cnVlKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5fcHJldmlvdXNJdGVtID0gdGhpcy5fcmVzdWx0W2ldO1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuYWN0aXZlU3RhdGUuZW1pdCh0aGlzLl9wcmV2aW91c0l0ZW0udGFiSWQpO1xyXG5cclxuICAgICAgICAgICAgICAgICAgICAvLyBpZiAodGhpcy5fcHJldmlvdXNJdGVtLnRhYlR5cGUgPT09ICdyb3V0ZXInKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgLy8gICAgIHRoaXMuX3JvdXRlci5uYXZpZ2F0ZShbJy4vJyArIHRoaXMuX3ByZXZpb3VzSXRlbS5yb3V0ZXJQYXRoXSwgeyByZWxhdGl2ZVRvOiB0aGlzLl9yb3V0ZSB9KTtcclxuICAgICAgICAgICAgICAgICAgICAvLyB9XHJcbiAgICAgICAgICAgICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIHRoaXMuX3NwbGl0dGVyRXZlbnQub25EcmFnKClcclxuICAgICAgICAgICAgLnN1YnNjcmliZShfdHlwZSA9PiB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLl9jaGVja1dpZHRoKCk7XHJcbiAgICAgICAgICAgICAgICB0aGlzLl9jaGVja1Njcm9sbGFibGUoKTtcclxuICAgICAgICAgICAgfSk7XHJcblxyXG4gICAgICAgIHRoaXMuX3NwbGl0dGVyRXZlbnQub25Ub2dnbGVNZW51KClcclxuICAgICAgICAgICAgLnN1YnNjcmliZShfdHlwZSA9PiB7XHJcbiAgICAgICAgICAgICAgICB0aW1lcig1MDApLnN1YnNjcmliZSgoKTogdm9pZCA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5fY2hlY2tXaWR0aCgpO1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuX2NoZWNrU2Nyb2xsYWJsZSgpO1xyXG4gICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgIH0pO1xyXG4gICAgfVxyXG5cclxuICAgIG5nT25DaGFuZ2VzKCk6IHZvaWQge1xyXG4gICAgICAgIHRoaXMuX3Jlc3VsdCA9IHRoaXMuX3RhYlN2Yy5zZXRSZXN1bHQodGhpcy50YWJzQ29uZmlnLCB0aGlzLnRhYlR5cGUpO1xyXG4gICAgICAgIHRoaXMuX2hhc0FycmF5ID0gdGhpcy5fdGFiU3ZjLmNoZWNrSGFzQXJyYXkodGhpcy5fcmVzdWx0KTtcclxuXHJcbiAgICAgICAgaWYgKHR5cGVvZiB0aGlzLl9yZXN1bHQgIT09ICd1bmRlZmluZWQnKSB7XHJcbiAgICAgICAgICAgIGZvciAobGV0IGk6IG51bWJlciA9IDA7IGkgPCB0aGlzLl9yZXN1bHQubGVuZ3RoOyBpKyspIHtcclxuICAgICAgICAgICAgICAgIGlmICh0aGlzLl9yZXN1bHRbaV0uaXNBY3RpdmUgPT09IHRydWUpIHtcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLl9wcmV2aW91c0l0ZW0gPSB0aGlzLl9yZXN1bHRbaV07XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5hY3RpdmVTdGF0ZS5lbWl0KHRoaXMuX3ByZXZpb3VzSXRlbS50YWJJZCk7XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIGlmICh0aGlzLl9wcmV2aW91c0l0ZW0udGFiVHlwZSA9PT0gJ3JvdXRlcicpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgLy8gY29uc29sZS5sb2coJ0tkLWFuZ3VsYXItdGFiIC0gTmVlZCB0byByZWxvb2sgdGhpcyBzZWN0aW9uJywgdGhpcy5fcHJldmlvdXNJdGVtLnJvdXRlclBhdGgsIHRoaXMuX3JvdXRlICk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC8vIHRoaXMuX3JvdXRlci5uYXZpZ2F0ZShbJy4vJyArIHRoaXMuX3ByZXZpb3VzSXRlbS5yb3V0ZXJQYXRoXSwgeyByZWxhdGl2ZVRvOiB0aGlzLl9yb3V0ZSB9KTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgLyogQ2hhbmdlIHRoZSBuYXZpZ2F0aW9uIG9uIGZpcnN0IGxvYWQgdG8gdXNlIGZ1bGwgcm91dGVyIHBhdGggdG8gbWF0Y2ggYWxsIHRoZSBwYXRoICovXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuX3JvdXRlci5uYXZpZ2F0ZUJ5VXJsKHRoaXMuX3ByZXZpb3VzSXRlbS5yb3V0ZXJQYXRoKTtcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIHRpbWVyKDUwKS5zdWJzY3JpYmUoKCk6IHZvaWQgPT4ge1xyXG4gICAgICAgICAgICB0aGlzLl9jaGVja1dpZHRoKCk7XHJcbiAgICAgICAgICAgIHRoaXMuX2NoZWNrU2Nyb2xsYWJsZSgpO1xyXG4gICAgICAgIH0pO1xyXG5cclxuICAgIH1cclxuXHJcbiAgICBuZ0FmdGVyVmlld0luaXQoKTogdm9pZCB7XHJcbiAgICAgICAgLy8gdGhpcy5fZGlyZWN0aW9uID0gdGhpcy5fdGFiU3ZjLmNoZWNrRGlyZWN0aW9uKCk7XHJcbiAgICAgICAgdGhpcy5fZGlyZWN0aW9uID0gdGhpcy5fZG9tRWxlLmdldERvY3VtZW50RGlyZWN0aW9uKHRydWUpO1xyXG4gICAgICAgIHRoaXMuX2NoZWNrV2lkdGgoKTtcclxuXHJcbiAgICAgICAgdGhpcy5fY2QuZGV0YWNoKCk7XHJcbiAgICAgICAgdGhpcy5fY2hlY2tTY3JvbGxhYmxlKCk7XHJcbiAgICAgICAgdGhpcy5fY2QuZGV0ZWN0Q2hhbmdlcygpO1xyXG4gICAgICAgIHRoaXMuX2NkLnJlYXR0YWNoKCk7XHJcbiAgICB9XHJcblxyXG4gICAgcHVibGljIHNlbGVjdFRhYihpdGVtOiBhbnksIGU6IEV2ZW50KTogdm9pZCB7XHJcbiAgICAgICAgZS5wcmV2ZW50RGVmYXVsdCgpO1xyXG4gICAgICAgIGlmICh0eXBlb2YgaXRlbS5kaXNhYmxlZCAhPT0gJ3VuZGVmaW5lZCcgJiYgaXRlbS5kaXNhYmxlZCkgcmV0dXJuO1xyXG5cclxuICAgICAgICBpZiAodHlwZW9mIHRoaXMuX3ByZXZpb3VzSXRlbSAhPT0gJ3VuZGVmaW5lZCcgJiYgdGhpcy5fcHJldmlvdXNJdGVtICE9PSBpdGVtKSB7XHJcbiAgICAgICAgICAgIHRoaXMuX3ByZXZpb3VzSXRlbS5pc0FjdGl2ZSA9IGZhbHNlO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgaWYgKGl0ZW0udGFiVHlwZSA9PT0gJ3JvdXRlcicgJiYgaXRlbS5pc0FjdGl2ZSA9PT0gZmFsc2UpIHtcclxuICAgICAgICAgICAgdGhpcy5fcm91dGVyLm5hdmlnYXRlQnlVcmwoaXRlbS5yb3V0ZXJQYXRoKTtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIGl0ZW0uaXNBY3RpdmUgPSB0cnVlO1xyXG4gICAgICAgIHRoaXMuX3ByZXZpb3VzSXRlbSA9IGl0ZW07XHJcbiAgICAgICAgdGhpcy5hY3RpdmVTdGF0ZS5lbWl0KHRoaXMuX3ByZXZpb3VzSXRlbS50YWJJZCk7XHJcbiAgICAgICAgdGhpcy5fc2V0U2VsZWN0ZWQoKTtcclxuICAgIH1cclxuXHJcbiAgICBwdWJsaWMgc2Nyb2xsKGRpcmVjdGlvbjogc3RyaW5nKTogdm9pZCB7XHJcbiAgICAgICAgbGV0IG9mZnNldFg6IG51bWJlciA9IDIwMDtcclxuICAgICAgICB0aGlzLl9sZWZ0ID0gKGRpcmVjdGlvbiA9PT0gJ3JpZ2h0JykgPyB0aGlzLl9sZWZ0IC0gb2Zmc2V0WCA6IHRoaXMuX2xlZnQgKyBvZmZzZXRYO1xyXG4gICAgICAgIHRoaXMuX3NldExlZnQoKTtcclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF9jaGVja1dpZHRoKCk6IHZvaWQge1xyXG4gICAgICAgIHRoaXMuX3VsV2lkdGggPSAwO1xyXG4gICAgICAgIGxldCB1bExpc3Q6IEFycmF5PEhUTUxFbGVtZW50PiA9IHRoaXMuX3Zjci5lbGVtZW50Lm5hdGl2ZUVsZW1lbnQucXVlcnlTZWxlY3RvckFsbCgnIycgKyB0aGlzLl9pZCArICcgLm5hdi1pdGVtJyk7XHJcbiAgICAgICAgLy8gY29uc29sZS5sb2codWxMaXN0KTtcclxuICAgICAgICAvLyBjb25zb2xlLmxvZyh0aGlzLl9yZXN1bHQpO1xyXG4gICAgICAgIGlmICh0eXBlb2YgdWxMaXN0ICE9PSAndW5kZWZpbmVkJyAmJiB1bExpc3QubGVuZ3RoID4gMSkge1xyXG4gICAgICAgICAgICBpZiAodGhpcy5fZGlyZWN0aW9uID09PSAnbGVmdCcpIHtcclxuICAgICAgICAgICAgICAgIHRoaXMuX3VsTWFyZ2luID0gdWxMaXN0WzFdLmdldEJvdW5kaW5nQ2xpZW50UmVjdCgpLmxlZnQgLSB1bExpc3RbMF0uZ2V0Qm91bmRpbmdDbGllbnRSZWN0KCkucmlnaHQ7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgZWxzZSB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLl91bE1hcmdpbiA9IHVsTGlzdFswXS5nZXRCb3VuZGluZ0NsaWVudFJlY3QoKS5sZWZ0IC0gdWxMaXN0WzFdLmdldEJvdW5kaW5nQ2xpZW50UmVjdCgpLnJpZ2h0O1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICBpZiAodHlwZW9mIHRoaXMuX3Jlc3VsdCAhPT0gJ3VuZGVmaW5lZCcpIHtcclxuICAgICAgICAgICAgZm9yIChsZXQgaTogbnVtYmVyID0gMDsgaSA8IHVsTGlzdC5sZW5ndGg7IGkrKykge1xyXG4gICAgICAgICAgICAgICAgaWYgKHR5cGVvZiB0aGlzLl9yZXN1bHRbaV0gPT09ICd1bmRlZmluZWQnKSBjb250aW51ZTtcclxuXHJcbiAgICAgICAgICAgICAgICB0aGlzLl9yZXN1bHRbaV0ud2lkdGggPSBNYXRoLnJvdW5kKHVsTGlzdFtpXS5nZXRCb3VuZGluZ0NsaWVudFJlY3QoKS53aWR0aCk7XHJcblxyXG4gICAgICAgICAgICAgICAgaWYgKGkgIT09IDApIHtcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLl9yZXN1bHRbaV0ud2lkdGggPSBNYXRoLnJvdW5kKHRoaXMuX3Jlc3VsdFtpXS53aWR0aCArIHRoaXMuX3VsTWFyZ2luKTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIHRoaXMuX3VsV2lkdGggKz0gdGhpcy5fcmVzdWx0W2ldLndpZHRoO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG5cclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF9jaGVja1Njcm9sbGFibGUoKTogdm9pZCB7XHJcbiAgICAgICAgbGV0IHBhcmVudFdpZHRoOiBudW1iZXIgPSB0aGlzLl92Y3IuZWxlbWVudC5uYXRpdmVFbGVtZW50LnBhcmVudEVsZW1lbnQuZ2V0Qm91bmRpbmdDbGllbnRSZWN0KCkud2lkdGg7XHJcbiAgICAgICAgbGV0IHVsRWxlbWVudDogSFRNTEVsZW1lbnQgPSB0aGlzLl92Y3IuZWxlbWVudC5uYXRpdmVFbGVtZW50LnF1ZXJ5U2VsZWN0b3IoJyMnICsgdGhpcy5faWQgKyAnIC5uYXYtdGFicycpO1xyXG4gICAgICAgIHRoaXMuX3Njcm9sbEJ0biA9ICh0aGlzLl91bFdpZHRoID4gcGFyZW50V2lkdGgpID8gdHJ1ZSA6IGZhbHNlO1xyXG4gICAgICAgIHRoaXMuX3Njcm9sbEJ0biA/IHRoaXMuX3JlbmRlcmVyLmFkZENsYXNzKHVsRWxlbWVudCwgJ3Njcm9sbGFibGUnKSA6IHRoaXMuX3JlbmRlcmVyLnJlbW92ZUNsYXNzKHVsRWxlbWVudCwgJ3Njcm9sbGFibGUnKTtcclxuXHJcbiAgICAgICAgdGltZXIoMTAwKS5zdWJzY3JpYmUoKCk6IHZvaWQgPT4ge1xyXG4gICAgICAgICAgICBpZiAodWxFbGVtZW50LmNsaWVudFdpZHRoIDwgdGhpcy5fdWxXaWR0aCkge1xyXG4gICAgICAgICAgICAgICAgaWYgKHRoaXMuX2RpcmVjdGlvbiA9PT0gJ2xlZnQnKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5fbWF4TGVmdCA9IHVsRWxlbWVudC5jbGllbnRXaWR0aCAtIHRoaXMuX3VsV2lkdGg7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLl9tYXhMZWZ0ID0gdGhpcy5fdWxXaWR0aCAtIHVsRWxlbWVudC5jbGllbnRXaWR0aDtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgaWYgKCF0aGlzLl9zY3JvbGxCdG4pIHtcclxuICAgICAgICAgICAgICAgIHRoaXMuX2xlZnQgPSAwO1xyXG4gICAgICAgICAgICAgICAgdGhpcy5fc2V0TGVmdCgpO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5fc2V0U2VsZWN0ZWQoKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH0pO1xyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX3NldFNlbGVjdGVkKCk6IHZvaWQge1xyXG4gICAgICAgIGxldCBwYXJlbnRXaWR0aDogbnVtYmVyID0gdGhpcy5fdmNyLmVsZW1lbnQubmF0aXZlRWxlbWVudC5xdWVyeVNlbGVjdG9yKCcjJyArIHRoaXMuX2lkICsgJyAubmF2LXRhYnMnKS5jbGllbnRXaWR0aCAtIHRoaXMuX3BhcmVudFBhZGRpbmc7XHJcbiAgICAgICAgbGV0IG1pZGRsZSA9IHBhcmVudFdpZHRoIC8gMjtcclxuICAgICAgICBsZXQgd2lkdGggPSAwO1xyXG5cclxuICAgICAgICBpZiAodGhpcy5fc2Nyb2xsQnRuKSB7XHJcbiAgICAgICAgICAgIC8vIGlmICh0aGlzLl9kaXJlY3Rpb24gPT09ICdsZWZ0Jykge1xyXG4gICAgICAgICAgICBmb3IgKGxldCBpOiBudW1iZXIgPSAwOyBpIDwgdGhpcy5fcmVzdWx0Lmxlbmd0aDsgaSsrKSB7XHJcbiAgICAgICAgICAgICAgICBpZiAodGhpcy5fcHJldmlvdXNJdGVtICE9PSB0aGlzLl9yZXN1bHRbaV0pIHtcclxuICAgICAgICAgICAgICAgICAgICB3aWR0aCArPSB0aGlzLl9yZXN1bHRbaV0ud2lkdGg7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgICAgICAgICB3aWR0aCArPSAodGhpcy5fcmVzdWx0W2ldLndpZHRoIC8gMik7XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIGlmICh0aGlzLl9kaXJlY3Rpb24gPT09ICdsZWZ0Jykge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLl9sZWZ0ID0gbWlkZGxlIC0gd2lkdGg7XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLl9sZWZ0ID0gd2lkdGggLSBtaWRkbGU7XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIC8vIH1cclxuXHJcbiAgICAgICAgICAgIC8vIGVsc2Uge1xyXG4gICAgICAgICAgICAvLyAgICAgZm9yIChsZXQgaTogbnVtYmVyID0gdGhpcy5fcmVzdWx0Lmxlbmd0aCAtIDE7IGkgPj0gMDsgaS0tKSB7XHJcbiAgICAgICAgICAgIC8vICAgICAgICAgaWYgKHRoaXMuX3ByZXZpb3VzSXRlbSAhPT0gdGhpcy5fcmVzdWx0W2ldKSB7XHJcbiAgICAgICAgICAgIC8vICAgICAgICAgICAgIHdpZHRoICs9IHRoaXMuX3Jlc3VsdFtpXS53aWR0aDtcclxuICAgICAgICAgICAgLy8gICAgICAgICB9XHJcbiAgICAgICAgICAgIC8vICAgICAgICAgZWxzZSB7XHJcbiAgICAgICAgICAgIC8vICAgICAgICAgICAgIHdpZHRoICs9ICh0aGlzLl9yZXN1bHRbaV0ud2lkdGggLyAyKTtcclxuICAgICAgICAgICAgLy8gICAgICAgICAgICAgdGhpcy5fbGVmdCA9IHdpZHRoIC0gbWlkZGxlO1xyXG4gICAgICAgICAgICAvLyAgICAgICAgICAgICBicmVhaztcclxuICAgICAgICAgICAgLy8gICAgICAgICB9XHJcbiAgICAgICAgICAgIC8vICAgICB9XHJcbiAgICAgICAgICAgIC8vIH1cclxuICAgICAgICB9XHJcbiAgICAgICAgZWxzZSB7XHJcbiAgICAgICAgICAgIHRoaXMuX2xlZnQgPSAwO1xyXG4gICAgICAgIH1cclxuICAgICAgICB0aGlzLl9zZXRMZWZ0KCk7XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfc2V0TGVmdCgpOiB2b2lkIHtcclxuICAgICAgICBsZXQgaXRlbTogQXJyYXk8SFRNTEVsZW1lbnQ+ID0gdGhpcy5fdmNyLmVsZW1lbnQubmF0aXZlRWxlbWVudC5xdWVyeVNlbGVjdG9yQWxsKCcjJyArIHRoaXMuX2lkICsgJyAubmF2LWl0ZW0nKTtcclxuXHJcbiAgICAgICAgaWYgKHRoaXMuX2RpcmVjdGlvbiA9PT0gJ2xlZnQnKSB7XHJcbiAgICAgICAgICAgIGlmICh0aGlzLl9sZWZ0IDwgdGhpcy5fbWF4TGVmdCkge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5fbGVmdCA9IHRoaXMuX21heExlZnQ7XHJcblxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIGVsc2UgaWYgKHRoaXMuX2xlZnQgPj0gMCkge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5fbGVmdCA9IDA7XHJcbiAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgIHRoaXMuX2Rpc2FibGVMZWZ0ID0gKHRoaXMuX2xlZnQgPT09IDApID8gdHJ1ZSA6IGZhbHNlO1xyXG4gICAgICAgICAgICB0aGlzLl9kaXNhYmxlUmlnaHQgPSAodGhpcy5fbGVmdCA9PT0gdGhpcy5fbWF4TGVmdCkgPyB0cnVlIDogZmFsc2U7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICBpZiAodGhpcy5fbGVmdCA8IDApIHtcclxuICAgICAgICAgICAgICAgIHRoaXMuX2xlZnQgPSAwO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIGVsc2UgaWYgKHRoaXMuX2xlZnQgPiB0aGlzLl9tYXhMZWZ0KSB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLl9sZWZ0ID0gdGhpcy5fbWF4TGVmdDtcclxuICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgdGhpcy5fZGlzYWJsZUxlZnQgPSAodGhpcy5fbGVmdCA9PT0gdGhpcy5fbWF4TGVmdCkgPyB0cnVlIDogZmFsc2U7XHJcbiAgICAgICAgICAgIHRoaXMuX2Rpc2FibGVSaWdodCA9ICh0aGlzLl9sZWZ0ID09PSAwKSA/IHRydWUgOiBmYWxzZTtcclxuICAgICAgICB9XHJcblxyXG5cclxuICAgICAgICBsZXQgbW92ZSA9IHRoaXMuX2xlZnQgKyAncHgnO1xyXG5cclxuICAgICAgICBmb3IgKGxldCBpOiBudW1iZXIgPSAwOyBpIDwgaXRlbS5sZW5ndGg7IGkrKykge1xyXG4gICAgICAgICAgICB0aGlzLl9yZW5kZXJlci5zZXRTdHlsZShpdGVtW2ldLCAnbGVmdCcsIG1vdmUpO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxufVxyXG4iXX0=