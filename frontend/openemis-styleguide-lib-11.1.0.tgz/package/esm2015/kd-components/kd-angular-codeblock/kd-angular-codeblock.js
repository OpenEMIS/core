import { Component, Input } from '@angular/core';
// import { Response } from '@angular/http';
import { HttpClient } from '@angular/common/http';
import { DomSanitizer } from '@angular/platform-browser';
export class KdCodeblock {
    // trustHTMLcode: SafeUrl;
    constructor(_sanitizer, _http) {
        this._sanitizer = _sanitizer;
        this._http = _http;
        this.Prism = require('prismjs');
        this.code = null;
    }
    ngOnInit() {
        // let tempStr = this.code;
        // let regex = new RegExp(this._getSpaces(tempStr), 'g');
        // // tempStr = tempStr.replace(/  +/g, '').trim();
        // tempStr = tempStr.replace(regex, '').trim();
        // tempStr = this.Prism.highlight(tempStr, this._getType(this.language));
        // this._sanitizer.bypassSecurityTrustHtml(tempStr);
        // this.code = tempStr;
        let tempStr;
        if (typeof this.path !== 'undefined') {
            try {
                this._httpSub = this._http.get(this.path)
                    // .pipe(
                    //     map((respond: Response): any => respond.text())
                    // )
                    .subscribe((data) => {
                    console.log('Codeblock', data);
                    tempStr = data.trim();
                    this._updateCodeblock(tempStr);
                }, (error) => { }, () => { });
            }
            catch (err) { }
        }
        else {
            tempStr = this.code;
            this._updateCodeblock(tempStr);
        }
    }
    _updateCodeblock(tempStr) {
        let regex = new RegExp(this._getSpaces(tempStr), 'g');
        tempStr = tempStr.replace(regex, '').trim();
        tempStr = this.Prism.highlight(tempStr, this._getType(this.language));
        this._sanitizer.bypassSecurityTrustHtml(tempStr);
        this._updatedCode = tempStr;
    }
    _getSpaces(_text) {
        let spacesArr = _text.match(/[^\S\n\t]+/g);
        let removeSpace = null;
        if (spacesArr !== null) {
            for (let i = 0; i < spacesArr.length; i++) {
                if (removeSpace === null && spacesArr[i].length > 1) {
                    removeSpace = spacesArr[i];
                }
                else if (spacesArr[i].length > 1 && removeSpace.length > spacesArr[i].length) {
                    removeSpace = spacesArr[i];
                }
            }
        }
        return removeSpace;
    }
    _getType(_type) {
        if (_type === 'javascript' || _type === 'js' || _type === 'typescript') {
            return this.Prism.languages.javascript;
        }
        else if (_type === 'html') {
            return this.Prism.languages.html;
        }
        else if (_type === 'css') {
            return this.Prism.languages.css;
        }
        else {
            return this.Prism.languages.markup;
        }
    }
}
KdCodeblock.decorators = [
    { type: Component, args: [{
                selector: 'kd-codeblock',
                template: `
            <pre class='language-javascript' style='font-size: 12px'><code class='language-javascript' [innerHtml]='_updatedCode'></code></pre>
    `
            },] }
];
KdCodeblock.ctorParameters = () => [
    { type: DomSanitizer },
    { type: HttpClient }
];
KdCodeblock.propDecorators = {
    code: [{ type: Input }],
    path: [{ type: Input }],
    language: [{ type: Input }]
};
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoia2QtYW5ndWxhci1jb2RlYmxvY2suanMiLCJzb3VyY2VSb290IjoiQzovUHJvamVjdHMvQW5ndWxhci9pb3N0Zy1vcGVuZW1pcy1zdHlsZWd1aWRlL3Byb2plY3RzL29wZW5lbWlzLXN0eWxlZ3VpZGUtbGliL3NyYy8iLCJzb3VyY2VzIjpbImtkLWNvbXBvbmVudHMva2QtYW5ndWxhci1jb2RlYmxvY2sva2QtYW5ndWxhci1jb2RlYmxvY2sudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsT0FBTyxFQUNILFNBQVMsRUFDVCxLQUFLLEVBRVIsTUFBTSxlQUFlLENBQUM7QUFDdkIsNENBQTRDO0FBQzVDLE9BQU8sRUFBRSxVQUFVLEVBQUMsTUFBTSxzQkFBc0IsQ0FBQztBQUdqRCxPQUFPLEVBQUUsWUFBWSxFQUFFLE1BQU0sMkJBQTJCLENBQUM7QUFXekQsTUFBTSxPQUFPLFdBQVc7SUFTcEIsMEJBQTBCO0lBQzFCLFlBQW9CLFVBQXdCLEVBQVUsS0FBaUI7UUFBbkQsZUFBVSxHQUFWLFVBQVUsQ0FBYztRQUFVLFVBQUssR0FBTCxLQUFLLENBQVk7UUFSL0QsVUFBSyxHQUFHLE9BQU8sQ0FBQyxTQUFTLENBQUMsQ0FBQztRQUcxQixTQUFJLEdBQVcsSUFBSSxDQUFDO0lBSzhDLENBQUM7SUFFNUUsUUFBUTtRQUNKLDJCQUEyQjtRQUMzQix5REFBeUQ7UUFDekQsbURBQW1EO1FBQ25ELCtDQUErQztRQUMvQyx5RUFBeUU7UUFDekUsb0RBQW9EO1FBQ3BELHVCQUF1QjtRQUV2QixJQUFJLE9BQWUsQ0FBQztRQUNwQixJQUFJLE9BQU8sSUFBSSxDQUFDLElBQUksS0FBSyxXQUFXLEVBQUU7WUFDbEMsSUFBSTtnQkFDQSxJQUFJLENBQUMsUUFBUSxHQUFHLElBQUksQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUM7b0JBQ3JDLFNBQVM7b0JBQ1Qsc0RBQXNEO29CQUN0RCxJQUFJO3FCQUNILFNBQVMsQ0FDTixDQUFDLElBQVMsRUFBUSxFQUFFO29CQUNoQixPQUFPLENBQUMsR0FBRyxDQUFDLFdBQVcsRUFBQyxJQUFJLENBQUMsQ0FBQztvQkFDOUIsT0FBTyxHQUFHLElBQUksQ0FBQyxJQUFJLEVBQUUsQ0FBQztvQkFDdEIsSUFBSSxDQUFDLGdCQUFnQixDQUFDLE9BQU8sQ0FBQyxDQUFDO2dCQUNuQyxDQUFDLEVBQ0QsQ0FBQyxLQUFVLEVBQVEsRUFBRSxHQUFHLENBQUMsRUFDekIsR0FBUyxFQUFFLEdBQUcsQ0FBQyxDQUNsQixDQUFDO2FBQ1Q7WUFBQyxPQUFPLEdBQUcsRUFBRSxHQUFHO1NBQ3BCO2FBQ0k7WUFDRCxPQUFPLEdBQUcsSUFBSSxDQUFDLElBQUksQ0FBQztZQUNwQixJQUFJLENBQUMsZ0JBQWdCLENBQUMsT0FBTyxDQUFDLENBQUM7U0FDbEM7SUFFTCxDQUFDO0lBRU8sZ0JBQWdCLENBQUMsT0FBZTtRQUNwQyxJQUFJLEtBQUssR0FBRyxJQUFJLE1BQU0sQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLE9BQU8sQ0FBQyxFQUFFLEdBQUcsQ0FBQyxDQUFDO1FBQ3RELE9BQU8sR0FBRyxPQUFPLENBQUMsT0FBTyxDQUFDLEtBQUssRUFBRSxFQUFFLENBQUMsQ0FBQyxJQUFJLEVBQUUsQ0FBQztRQUM1QyxPQUFPLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQyxTQUFTLENBQUMsT0FBTyxFQUFFLElBQUksQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUM7UUFDdEUsSUFBSSxDQUFDLFVBQVUsQ0FBQyx1QkFBdUIsQ0FBQyxPQUFPLENBQUMsQ0FBQztRQUNqRCxJQUFJLENBQUMsWUFBWSxHQUFHLE9BQU8sQ0FBQztJQUNoQyxDQUFDO0lBRU8sVUFBVSxDQUFDLEtBQWE7UUFDNUIsSUFBSSxTQUFTLEdBQUcsS0FBSyxDQUFDLEtBQUssQ0FBQyxhQUFhLENBQUMsQ0FBQztRQUMzQyxJQUFJLFdBQVcsR0FBRyxJQUFJLENBQUM7UUFDdkIsSUFBSSxTQUFTLEtBQUssSUFBSSxFQUFFO1lBQ3BCLEtBQUssSUFBSSxDQUFDLEdBQVcsQ0FBQyxFQUFFLENBQUMsR0FBRyxTQUFTLENBQUMsTUFBTSxFQUFFLENBQUMsRUFBRSxFQUFFO2dCQUMvQyxJQUFJLFdBQVcsS0FBSyxJQUFJLElBQUksU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sR0FBRyxDQUFDLEVBQUU7b0JBQ2pELFdBQVcsR0FBRyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUM7aUJBQzlCO3FCQUNJLElBQUksU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sR0FBRyxDQUFDLElBQUksV0FBVyxDQUFDLE1BQU0sR0FBRyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxFQUFFO29CQUMxRSxXQUFXLEdBQUcsU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDO2lCQUM5QjthQUNKO1NBQ0o7UUFDRCxPQUFPLFdBQVcsQ0FBQztJQUN2QixDQUFDO0lBRU8sUUFBUSxDQUFDLEtBQWE7UUFDMUIsSUFBSSxLQUFLLEtBQUssWUFBWSxJQUFJLEtBQUssS0FBSyxJQUFJLElBQUksS0FBSyxLQUFLLFlBQVksRUFBRTtZQUNwRSxPQUFPLElBQUksQ0FBQyxLQUFLLENBQUMsU0FBUyxDQUFDLFVBQVUsQ0FBQztTQUMxQzthQUNJLElBQUksS0FBSyxLQUFLLE1BQU0sRUFBRTtZQUN2QixPQUFPLElBQUksQ0FBQyxLQUFLLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQztTQUNwQzthQUNJLElBQUksS0FBSyxLQUFLLEtBQUssRUFBRTtZQUN0QixPQUFPLElBQUksQ0FBQyxLQUFLLENBQUMsU0FBUyxDQUFDLEdBQUcsQ0FBQztTQUNuQzthQUNJO1lBQ0QsT0FBTyxJQUFJLENBQUMsS0FBSyxDQUFDLFNBQVMsQ0FBQyxNQUFNLENBQUM7U0FDdEM7SUFDTCxDQUFDOzs7WUExRkosU0FBUyxTQUFDO2dCQUNQLFFBQVEsRUFBRSxjQUFjO2dCQUN4QixRQUFRLEVBQUU7O0tBRVQ7YUFDSjs7O1lBVFEsWUFBWTtZQUhaLFVBQVU7OzttQkFtQmQsS0FBSzttQkFDTCxLQUFLO3VCQUNMLEtBQUsiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQge1xyXG4gICAgQ29tcG9uZW50LFxyXG4gICAgSW5wdXQsXHJcbiAgICBPbkluaXRcclxufSBmcm9tICdAYW5ndWxhci9jb3JlJztcclxuLy8gaW1wb3J0IHsgUmVzcG9uc2UgfSBmcm9tICdAYW5ndWxhci9odHRwJztcclxuaW1wb3J0IHsgSHR0cENsaWVudH0gZnJvbSAnQGFuZ3VsYXIvY29tbW9uL2h0dHAnO1xyXG5pbXBvcnQgeyBTdWJzY3JpcHRpb24gfSBmcm9tICdyeGpzJztcclxuaW1wb3J0IHsgbWFwIH0gZnJvbSAncnhqcy9vcGVyYXRvcnMnO1xyXG5pbXBvcnQgeyBEb21TYW5pdGl6ZXIgfSBmcm9tICdAYW5ndWxhci9wbGF0Zm9ybS1icm93c2VyJztcclxuXHJcbmRlY2xhcmUgdmFyIHJlcXVpcmU6IGFueTtcclxuXHJcbkBDb21wb25lbnQoe1xyXG4gICAgc2VsZWN0b3I6ICdrZC1jb2RlYmxvY2snLFxyXG4gICAgdGVtcGxhdGU6IGBcclxuICAgICAgICAgICAgPHByZSBjbGFzcz0nbGFuZ3VhZ2UtamF2YXNjcmlwdCcgc3R5bGU9J2ZvbnQtc2l6ZTogMTJweCc+PGNvZGUgY2xhc3M9J2xhbmd1YWdlLWphdmFzY3JpcHQnIFtpbm5lckh0bWxdPSdfdXBkYXRlZENvZGUnPjwvY29kZT48L3ByZT5cclxuICAgIGAsXHJcbn0pXHJcblxyXG5leHBvcnQgY2xhc3MgS2RDb2RlYmxvY2sgaW1wbGVtZW50cyBPbkluaXQge1xyXG4gICAgcHVibGljIF91cGRhdGVkQ29kZTogc3RyaW5nO1xyXG4gICAgcHJpdmF0ZSBQcmlzbSA9IHJlcXVpcmUoJ3ByaXNtanMnKTtcclxuICAgIHByaXZhdGUgX2h0dHBTdWI6IFN1YnNjcmlwdGlvbjtcclxuXHJcbiAgICBASW5wdXQoKSBjb2RlOiBzdHJpbmcgPSBudWxsO1xyXG4gICAgQElucHV0KCkgcGF0aDogc3RyaW5nO1xyXG4gICAgQElucHV0KCkgbGFuZ3VhZ2U6IHN0cmluZztcclxuXHJcbiAgICAvLyB0cnVzdEhUTUxjb2RlOiBTYWZlVXJsO1xyXG4gICAgY29uc3RydWN0b3IocHJpdmF0ZSBfc2FuaXRpemVyOiBEb21TYW5pdGl6ZXIsIHByaXZhdGUgX2h0dHA6IEh0dHBDbGllbnQpIHsgfVxyXG5cclxuICAgIG5nT25Jbml0KCk6IHZvaWQge1xyXG4gICAgICAgIC8vIGxldCB0ZW1wU3RyID0gdGhpcy5jb2RlO1xyXG4gICAgICAgIC8vIGxldCByZWdleCA9IG5ldyBSZWdFeHAodGhpcy5fZ2V0U3BhY2VzKHRlbXBTdHIpLCAnZycpO1xyXG4gICAgICAgIC8vIC8vIHRlbXBTdHIgPSB0ZW1wU3RyLnJlcGxhY2UoLyAgKy9nLCAnJykudHJpbSgpO1xyXG4gICAgICAgIC8vIHRlbXBTdHIgPSB0ZW1wU3RyLnJlcGxhY2UocmVnZXgsICcnKS50cmltKCk7XHJcbiAgICAgICAgLy8gdGVtcFN0ciA9IHRoaXMuUHJpc20uaGlnaGxpZ2h0KHRlbXBTdHIsIHRoaXMuX2dldFR5cGUodGhpcy5sYW5ndWFnZSkpO1xyXG4gICAgICAgIC8vIHRoaXMuX3Nhbml0aXplci5ieXBhc3NTZWN1cml0eVRydXN0SHRtbCh0ZW1wU3RyKTtcclxuICAgICAgICAvLyB0aGlzLmNvZGUgPSB0ZW1wU3RyO1xyXG5cclxuICAgICAgICBsZXQgdGVtcFN0cjogc3RyaW5nO1xyXG4gICAgICAgIGlmICh0eXBlb2YgdGhpcy5wYXRoICE9PSAndW5kZWZpbmVkJykge1xyXG4gICAgICAgICAgICB0cnkge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5faHR0cFN1YiA9IHRoaXMuX2h0dHAuZ2V0KHRoaXMucGF0aClcclxuICAgICAgICAgICAgICAgICAgICAvLyAucGlwZShcclxuICAgICAgICAgICAgICAgICAgICAvLyAgICAgbWFwKChyZXNwb25kOiBSZXNwb25zZSk6IGFueSA9PiByZXNwb25kLnRleHQoKSlcclxuICAgICAgICAgICAgICAgICAgICAvLyApXHJcbiAgICAgICAgICAgICAgICAgICAgLnN1YnNjcmliZShcclxuICAgICAgICAgICAgICAgICAgICAgICAgKGRhdGE6IGFueSk6IHZvaWQgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc29sZS5sb2coJ0NvZGVibG9jaycsZGF0YSk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0ZW1wU3RyID0gZGF0YS50cmltKCk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0aGlzLl91cGRhdGVDb2RlYmxvY2sodGVtcFN0cik7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIChlcnJvcjogYW55KTogdm9pZCA9PiB7IH0sXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICgpOiB2b2lkID0+IHsgfVxyXG4gICAgICAgICAgICAgICAgICAgICk7XHJcbiAgICAgICAgICAgIH0gY2F0Y2ggKGVycikgeyB9XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICB0ZW1wU3RyID0gdGhpcy5jb2RlO1xyXG4gICAgICAgICAgICB0aGlzLl91cGRhdGVDb2RlYmxvY2sodGVtcFN0cik7XHJcbiAgICAgICAgfVxyXG5cclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF91cGRhdGVDb2RlYmxvY2sodGVtcFN0cjogc3RyaW5nKTogdm9pZCB7XHJcbiAgICAgICAgbGV0IHJlZ2V4ID0gbmV3IFJlZ0V4cCh0aGlzLl9nZXRTcGFjZXModGVtcFN0ciksICdnJyk7XHJcbiAgICAgICAgdGVtcFN0ciA9IHRlbXBTdHIucmVwbGFjZShyZWdleCwgJycpLnRyaW0oKTtcclxuICAgICAgICB0ZW1wU3RyID0gdGhpcy5QcmlzbS5oaWdobGlnaHQodGVtcFN0ciwgdGhpcy5fZ2V0VHlwZSh0aGlzLmxhbmd1YWdlKSk7XHJcbiAgICAgICAgdGhpcy5fc2FuaXRpemVyLmJ5cGFzc1NlY3VyaXR5VHJ1c3RIdG1sKHRlbXBTdHIpO1xyXG4gICAgICAgIHRoaXMuX3VwZGF0ZWRDb2RlID0gdGVtcFN0cjtcclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF9nZXRTcGFjZXMoX3RleHQ6IHN0cmluZyk6IHN0cmluZyB7XHJcbiAgICAgICAgbGV0IHNwYWNlc0FyciA9IF90ZXh0Lm1hdGNoKC9bXlxcU1xcblxcdF0rL2cpO1xyXG4gICAgICAgIGxldCByZW1vdmVTcGFjZSA9IG51bGw7XHJcbiAgICAgICAgaWYgKHNwYWNlc0FyciAhPT0gbnVsbCkge1xyXG4gICAgICAgICAgICBmb3IgKGxldCBpOiBudW1iZXIgPSAwOyBpIDwgc3BhY2VzQXJyLmxlbmd0aDsgaSsrKSB7XHJcbiAgICAgICAgICAgICAgICBpZiAocmVtb3ZlU3BhY2UgPT09IG51bGwgJiYgc3BhY2VzQXJyW2ldLmxlbmd0aCA+IDEpIHtcclxuICAgICAgICAgICAgICAgICAgICByZW1vdmVTcGFjZSA9IHNwYWNlc0FycltpXTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIGVsc2UgaWYgKHNwYWNlc0FycltpXS5sZW5ndGggPiAxICYmIHJlbW92ZVNwYWNlLmxlbmd0aCA+IHNwYWNlc0FycltpXS5sZW5ndGgpIHtcclxuICAgICAgICAgICAgICAgICAgICByZW1vdmVTcGFjZSA9IHNwYWNlc0FycltpXTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgICAgICByZXR1cm4gcmVtb3ZlU3BhY2U7XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfZ2V0VHlwZShfdHlwZTogc3RyaW5nKTogYW55IHtcclxuICAgICAgICBpZiAoX3R5cGUgPT09ICdqYXZhc2NyaXB0JyB8fCBfdHlwZSA9PT0gJ2pzJyB8fCBfdHlwZSA9PT0gJ3R5cGVzY3JpcHQnKSB7XHJcbiAgICAgICAgICAgIHJldHVybiB0aGlzLlByaXNtLmxhbmd1YWdlcy5qYXZhc2NyaXB0O1xyXG4gICAgICAgIH1cclxuICAgICAgICBlbHNlIGlmIChfdHlwZSA9PT0gJ2h0bWwnKSB7XHJcbiAgICAgICAgICAgIHJldHVybiB0aGlzLlByaXNtLmxhbmd1YWdlcy5odG1sO1xyXG4gICAgICAgIH1cclxuICAgICAgICBlbHNlIGlmIChfdHlwZSA9PT0gJ2NzcycpIHtcclxuICAgICAgICAgICAgcmV0dXJuIHRoaXMuUHJpc20ubGFuZ3VhZ2VzLmNzcztcclxuICAgICAgICB9XHJcbiAgICAgICAgZWxzZSB7XHJcbiAgICAgICAgICAgIHJldHVybiB0aGlzLlByaXNtLmxhbmd1YWdlcy5tYXJrdXA7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG59XHJcbiJdfQ==