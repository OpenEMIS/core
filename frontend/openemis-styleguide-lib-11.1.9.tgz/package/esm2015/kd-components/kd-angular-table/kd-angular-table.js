import { Component, ViewEncapsulation, Input, HostBinding, HostListener, ViewContainerRef, EventEmitter, Output } from '@angular/core';
import { Router } from '@angular/router';
import { Observable, timer } from 'rxjs';
import 'ag-grid-enterprise';
import * as XLSX from 'xlsx';
import { saveAs } from 'file-saver';
import { KdTableDatasourceEvent, KdTableSelectionUpdateEvent, KdTableInputUpdateEvent, KdTableButtonEvent } from './kd-angular-table-interface';
import { KdIntTableEvent } from './kd-angular-table-event';
import { KdTableNormalSvc } from './table-services/kd-table-normal-svc';
import { KdTableEnterpriseSvc } from './table-services/kd-table-enterprise-svc';
// import { KdSplitterEvent } from '../';
import { KdDomElemSvc, AG_GRID_KEY } from '../kd-common/index';
import { LicenseManager } from "ag-grid-enterprise";
/**
 * -- Documentation for kd-angular-table.ts (kd-table)
 *
 * - HostListener
 *     - onResize
 *
 * - Life cycles:
 *     - ngOnInit
 *     - ngOnChanges
 *     - ngOnDestroy

 * - ag-Grid events function:
 *     - onGridReady
 *     - onModelUpdated
 *     - onRowClicked
 *
 * - kd-table button function:
 *     - onButtonClicekd
 *
 * - Private functions:
 *     - Display / DOM functions:
 *         - _resizeColumn
 *         - _showLoadingOverlay
 *         - _updateParentNodeCSS
 *         - _setHeight
 *         - _setMobileHeight (flatten table)
 *         - _setWebHeighr (user configuration)
 *         - _isClickValid (click configuration)
 *
 *     - Grid Cycles:
 *         - _gridInitCycle
 *         - _gridReadyCycle
 *         - _gridReadyEnterpriseCycle
 *         - _gridReadyDOMCycle
 *         - _gridSelectionCycle
 *         - _gridSetRowCycle
 *         - _gridClickNavigateCycle
 *
 *     - Column / Row / Config generations/processing:
 *         - _setGridOptions
 *         - _setColumnDef
 *         - _setRowData
 *
 *     - Event functions:
 *         - _processEventParams<T>
 *         - _broadcastEventParams
 *         - _broadcastModelChanged
 *         - _setupSubscriptionEvents
 *
 *     - Selection functions:
 *         - _updateSelectionNodes
 *         - _processInitialSelection
 *
 *     - Input functions:
 *         - _processInputChanged
 *         - _emitInputUpdateEvent
 *         - _deleteNodeFromRowData
 *
 *     - Datasource functions:
 *         - _clearDatasource
 *         - _generateEnterpriseDatasource
 *         - _generateDatasourceRows
 *
 *     - API generations:
 *         - _initITableApi (TODO: update api setting all to table service)
 *
 *     - Misc functions:
 *         - _initGridService
 *         - _updateGridConfig
 */
export class KdTable {
    constructor(_vcr, _router, _domSvc, 
    // private _splitterEvent: KdSplitterEvent,
    _tableIntEvent) {
        this._vcr = _vcr;
        this._router = _router;
        this._domSvc = _domSvc;
        this._tableIntEvent = _tableIntEvent;
        this.gridId = '';
        this.displayLoading = true;
        this._singleClickEdit = false;
        this._enterprise = require('ag-grid-enterprise');
        this._subscriptionObj = {};
        this._currentState = {
            columnState: [],
            pivotMode: false,
            groupState: []
        };
        this._isChangingState = false;
        this._pivotElement = {
            'pivot': null,
            'column-drop': null
        };
        this._suppressMovableColumns = true;
        this._direction = 'ltr';
        this.onExportPossible = new EventEmitter();
        this._classKdxTable = true;
        this.editingModeEnabled = false;
        LicenseManager.setLicenseKey(AG_GRID_KEY.value);
    }
    onResize(_event) {
        this._setHeight();
    }
    /************************* Life cycles functions *****************************/
    ngOnInit() {
        // console.log("-- Grid state: Init --", this.row, this.column, this.config, this.api);
        this._showLoadingOverlay(true);
        this._gridInitCycle();
    }
    ngOnChanges(_simpleChanges) {
        this._showLoadingOverlay(true);
        console.log("-- Grid state: Change -- ", _simpleChanges);
        if (typeof _simpleChanges.column !== 'undefined' &&
            !_simpleChanges.column.firstChange) {
            this._setColumnDef(_simpleChanges.column.currentValue);
            this._showLoadingOverlay(false);
        }
        if (typeof _simpleChanges.row !== 'undefined' &&
            !_simpleChanges.row.firstChange) {
            this._setRowData(_simpleChanges.row.currentValue);
            this._showLoadingOverlay(false);
        }
        if (typeof _simpleChanges.config !== 'undefined') {
            this._showLoadingOverlay(false);
            this.updateStyle(_simpleChanges.config.currentValue);
            timer(100).subscribe(() => {
                this._configurePivotDisplay();
                if (typeof this.config.suppressMovableColumns !== 'undefined') {
                    if (this.config.suppressMovableColumns !== this._suppressMovableColumns)
                        this._enableColumnMovable(this.config.suppressMovableColumns);
                }
                else {
                    this.config.suppressMovableColumns = this._suppressMovableColumns;
                }
            });
        }
    }
    ngOnDestroy() {
        // console.log("-- Grid state: Destroying --");
        for (let item in this._subscriptionObj) {
            if (typeof this._subscriptionObj[item] !== 'undefined') {
                this._subscriptionObj[item].unsubscribe();
            }
        }
    }
    setAttendance(displayEditTable, _config) {
        // let allColumns = this.gridOptions.columnApi.getAllColumns()
        // allColumns.forEach((column, index) => {
        //     let currentColumnDef = column.getColDef()
        //     console.log(`column ${index+1}`, currentColumnDef)
        // })
        if (displayEditTable) {
            this.gridOptions.context.mode = 'edit';
            _config.context.mode = 'edit';
            _config.rowContentHeight = 120;
        }
        else {
            this.gridOptions.context.mode = 'view';
            _config.context.mode = 'view';
        }
        let _columns = this.gridOptions.columnApi.getAllDisplayedColumns();
        // let colDef = _columns[2].getColDef()
        // console.log(colDef);
        // colDef.cellRendererParams = '<p>Hello</p>'
        // let newData = []
        // newData.push(colDef)
        this.gridOptions.columnApi.setValueColumns(_columns);
    }
    toggleEdits(data) {
        if (this.editTable && !this.displayEditable) {
            this.editingModeEnabled = !this.editingModeEnabled;
            this._singleClickEdit = !this._singleClickEdit;
            let _columns = this.gridOptions.columnApi.getAllDisplayedColumns();
            let newColumnData = [];
            _columns.forEach((column) => {
                let columnDef = column === null || column === void 0 ? void 0 : column.getColDef();
                if (columnDef.canEdit == true) {
                    columnDef.cellStyle = function (params) {
                        if (!isNaN(parseFloat(params.value)) && parseFloat(params.value) < 50) {
                            return { color: '#CC5C5C' };
                        }
                        else {
                            return { color: '#333' };
                        }
                    },
                        columnDef.cellClassRules = {
                            'oe-cell-highlight': function (params) {
                                return 1;
                            },
                            'oe-cell-error': function (params) {
                                // return params.data.save_error[params.colDef.field];
                            }
                        },
                        columnDef.cellRendererParams = {
                            shouldBeEditing: () => this.editingModeEnabled,
                        },
                        columnDef.editable = (params) => {
                            var name = params.node.data.name;
                            params.data.name = params.node.data.name;
                            return name;
                        },
                        columnDef.newValueHandler = (params) => {
                            if (data == 'text') {
                                let valueAsFloat = params.newValue;
                                params.data[params.colDef.field] = valueAsFloat;
                            }
                            else {
                                let valueAsFloat = parseFloat(params.newValue);
                                params.data[params.colDef.field] = valueAsFloat;
                            }
                            console.log(params.data[params.colDef.field], "params.data[params.colDef.field]");
                            // return true;
                        };
                }
                newColumnData.push(columnDef);
            });
            this.gridOptions.columnApi.setValueColumns(newColumnData);
        }
        else if (this.displayEditable) {
            this.editingModeEnabled = !this.editingModeEnabled;
            this._singleClickEdit = !this._singleClickEdit;
            let _columns = this.gridOptions.columnApi.getAllDisplayedColumns();
            let newColumnData = [];
            _columns.forEach((column) => {
                let columnDef = column === null || column === void 0 ? void 0 : column.getColDef();
                if (columnDef.canEdit == true) {
                    columnDef.valueGetter = function (params) {
                        var value = params.data[params.colDef.field];
                        if (data == 'text') {
                            return value;
                        }
                        else {
                            if (!isNaN(parseFloat(value))) {
                                return value;
                            }
                            else {
                                return '';
                            }
                        }
                    },
                        columnDef.cellClassRules = {},
                        columnDef.cellRendererParams = {
                            shouldBeEditing: () => this.editingModeEnabled,
                        },
                        columnDef.editable = (params) => {
                            return false;
                        };
                }
                newColumnData.push(columnDef);
            });
            this.gridOptions.columnApi.setValueColumns(newColumnData);
        }
    }
    setAttendanceStaff(displayEditTable) {
        if (displayEditTable) {
            this.gridOptions.context.action = 'edit';
        }
        else {
            this.gridOptions.context.action = 'view';
        }
        let _columns = this.gridOptions.columnApi.getAllDisplayedColumns();
        this.gridOptions.columnApi.setValueColumns(_columns);
        this._showLoadingOverlay(false);
    }
    setStudentMeal(displayEditTable) {
        if (displayEditTable) {
            this.gridOptions.context.mode = 'edit';
        }
        else {
            this.gridOptions.context.mode = 'view';
        }
        let _columns = this.gridOptions.columnApi.getAllDisplayedColumns();
        this.gridOptions.columnApi.setValueColumns(_columns);
        this._showLoadingOverlay(false);
    }
    /******************************* Grid events *********************************/
    onGridReady(_params) {
        // console.log('-- Grid state: Ready --', this.gridOptions);
        this._gridReadyCycle();
    }
    onModelUpdated(_event) {
        /// For select all checkbox checking on change pagination/update row data
        if (this._tableService.hasSelectionAll(this.config)) {
            this._broadcastModelChangedEvent();
        }
        if (this._isMobileView) {
            let gridElement = document.querySelector('#' + this.gridId + '.stg-theme');
            if (gridElement !== null) {
                this._setMobileHeight(gridElement);
            }
        }
    }
    onRowClicked(_params) {
        // console.log("-- Grid state: Row clicked --", _params);
        if (this._isClickValid(_params.event) && typeof this.config.click !== 'undefined' && !this.editTable) {
            switch (this.config.click.type) {
                case 'selection':
                    this._gridSelectionCycle(_params.node);
                    break;
                case 'router':
                    this._gridClickNavigateCycle(_params.node);
                    break;
                default:
                    break;
            }
            if (typeof this.config.click.callback !== 'undefined') {
                this.config.click.callback();
            }
        }
    }
    /***************************** Button functions ******************************/
    onButtonClicked(_button) {
        let buttonEvent = new KdTableButtonEvent(_button);
        this._processEventParams('button', buttonEvent);
    }
    /**************************** Private functions ******************************/
    ////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// Grid cycles
    ////////////////////////////////////////////////////////////////////////////////////////////////////////
    _gridInitCycle() {
        if (typeof this.config !== 'undefined') {
            this._initGridService(this.config.loadType);
            this._updateGridConfig(this.config);
            this._setGridOptions(this.config);
            this._setupSubscriptionEvents();
        }
        if (typeof this.column !== 'undefined') {
            this._setColumnDef(this.column);
        }
        if (typeof this.row !== 'undefined') {
            this._setRowData(this.row);
        }
    }
    _gridReadyCycle() {
        this._initITableApi();
        if (this._tableService.isEnterpriseModel(this.config.loadType)) {
            this._gridReadyEnterpriseCycle();
        }
        this._gridReadyDOMCycle();
    }
    _gridReadyEnterpriseCycle() {
        this._clearDatasource();
        this._generateEnterpriseDatasource();
    }
    _gridReadyDOMCycle() {
        this._updateParentNodeCSS();
        this._setHeight();
        this._resizeColumn();
    }
    _gridSelectionCycle(_rowNode) {
        if (typeof this.config.selection === 'undefined') {
            console.error('KdTable error: User have set click type to be selection but no selection is defined. Do you mean click type to router?');
        }
        else if (this.config.selection.type === 'single') {
            if (this.config.selection.value.indexOf(_rowNode.id) < 0) {
                this.gridOptions.api.deselectAll();
                _rowNode.selectThisNode(true);
                this.config.selection.value.splice(0, this.config.selection.value.length);
                this.config.selection.value.push(_rowNode.data.id);
                this._broadcastModelChangedEvent();
                this._updateSelectionNodes(_rowNode);
            }
        }
        else {
            let selection = !_rowNode.isSelected();
            _rowNode.selectThisNode(selection);
            this._broadcastModelChangedEvent();
            if (selection) {
                this.config.selection.value.push(_rowNode.data.id);
            }
            else {
                this.config.selection.value.splice(this.config.selection.value.indexOf(_rowNode.data.id), 1);
            }
            this._updateSelectionNodes(_rowNode);
        }
    }
    _gridSetRowCycle() {
        if (typeof this.config.selection !== 'undefined' && typeof this.config.selection.type !== 'undefined') {
            this._processInitialSelection();
        }
        else if (this._tableService.hasInputType(this.column, 'input')) {
            this._emitInputUpdateEvent();
        }
    }
    _gridClickNavigateCycle(_rowNode) {
        if (typeof this.config.click.pathMap !== 'undefined') {
            if (typeof this.config.action !== 'undefined' &&
                typeof this.config.action.list !== 'undefined') {
                let routerPath = '';
                for (let i = 0; i < this.config.action.list.length; ++i) {
                    let actionItem = this.config.action.list[i];
                    if (actionItem.type.toLowerCase() === this.config.click.pathMap.toLowerCase()) {
                        routerPath = this._tableService.getRouterPlaceholderPath(_rowNode, actionItem.path);
                        break;
                    }
                }
                if (routerPath !== '') {
                    this._router.navigate([routerPath]);
                }
                else {
                    console.warn('KdTable warning: Table router pathMap not found. pathMap set to:', this.config.click.pathMap);
                }
            }
            else {
                console.error('KdTable error: Table click event set to router pathMap but no action list is defined. Do you mean path property instead of pathMap property?');
            }
        }
        else if (typeof this.config.click.path !== 'undefined') {
            this._router.navigate([this.config.click.path]);
        }
        else {
            console.error('KdTable error: Table click event type set at router but no path / pathMap is provided. Do you mean click type selection / none?');
        }
    }
    ////////////////////////////////////////////////////////////////////////////////////////////////////////
    // Display / DOM function
    ////////////////////////////////////////////////////////////////////////////////////////////////////////
    _showLoadingOverlay(_toggle) {
        this.displayLoading = _toggle;
    }
    _updateParentNodeCSS() {
        this._vcr.element.nativeElement.parentNode.className += ' has-aggrid';
        if (this._direction === 'rtl') {
            document.querySelector('body').style.cssText += '--kdtable-header-text-align: right;';
            let pagingButton = document.getElementsByTagName("button");
            for (var i = 0; i < pagingButton.length; i++) {
                if (pagingButton[i].className == 'ag-paging-button-rtl' || pagingButton[i].className == 'ag-paging-button') {
                    pagingButton[i].className = "ag-paging-button-rtl";
                }
            }
            this.rightDirection = 'rtl';
        }
    }
    _setHeight() {
        let domEleQuery = '#' + this.gridId + '.stg-theme';
        let gridElement = this._vcr.element.nativeElement.querySelector(domEleQuery);
        if (gridElement !== null) {
            let windowsWidth = document.body.clientWidth;
            if (windowsWidth <= 1024) {
                if (typeof this._isMobileView === 'undefined' || !this._isMobileView) {
                    this._showLoadingOverlay(true);
                    this._isMobileView = true;
                    this._setMobileHeight(gridElement);
                }
            }
            else if (windowsWidth > 1024) {
                if (typeof this._isMobileView === 'undefined' || this._isMobileView) {
                    this._showLoadingOverlay(true);
                    this._isMobileView = false;
                    this._setWebGridHeight(gridElement, this.config.gridHeight);
                }
                else {
                    this.gridOptions.api.sizeColumnsToFit();
                }
            }
        }
    }
    /**
     * add border bottom dynamically so that when the row is lesser than body-container, there wont be any hanging border bottom
     * when the row is more than container, there will be a border-bottom
     */
    _setTableBorderBottom() {
        let containerEleQuery = ' .ag-body-container';
        let containerEle = this._vcr.element.nativeElement.querySelector(containerEleQuery);
        if (containerEle === null)
            return;
        let viewportEleQuery = ' .ag-body-viewport';
        let viewportEle = this._vcr.element.nativeElement.querySelector(viewportEleQuery);
        if (containerEle.clientHeight > viewportEle.clientHeight &&
            viewportEle.className &&
            viewportEle.className.indexOf('has-border-bottom') === -1) {
            viewportEle.className += ' has-border-bottom';
        }
        else if (containerEle.clientHeight < viewportEle.clientHeight) {
            viewportEle.className = viewportEle.className.replace(/has-border-bottom/gi, '');
        }
    }
    _setMobileHeight(_gridElement) {
        let newHeight = 0;
        if (this.config.loadType !== 'infinite') {
            let agHeaderEle = this._vcr.element.nativeElement.querySelector('.ag-header');
            let agBodyEle = this._vcr.element.nativeElement.querySelector('.ag-body-container');
            let agPagePanelEle = this._vcr.element.nativeElement.querySelector('div[ref="south"]');
            newHeight = 25;
            if (agHeaderEle !== null) {
                newHeight += agHeaderEle.clientHeight;
            }
            if (agBodyEle !== null) {
                newHeight += agBodyEle.clientHeight;
            }
            if (agPagePanelEle !== null) {
                newHeight += agPagePanelEle.clientHeight;
            }
        }
        else {
            newHeight = 400;
        }
        this._domSvc.setElementStyle(_gridElement, 'height', newHeight + 'px');
        timer(10).subscribe(() => {
            this.gridOptions.api.sizeColumnsToFit();
            this._showLoadingOverlay(false);
        });
    }
    /**
     * [_setWebGridHeight number for pixel or string "auto"]
     *  _configHeight [description]
     */
    _setWebGridHeight(_gridElement, _configHeight) {
        if (typeof _configHeight === 'number') {
            let gridHeight = 600;
            if (typeof _configHeight !== 'undefined') {
                gridHeight = _configHeight;
            }
            this._domSvc.setElementStyle(_gridElement, 'height', gridHeight + 'px');
        }
        else if (_configHeight === 'auto') {
            this.displayFull = true;
        }
        // else if (_configHeight === 'rowHeight') {
        //     this.gridOptions.domLayout = 'autoHeight';
        //     delete this.gridOptions.rowHeight;
        //     delete this.gridOptions.getRowHeight;
        // }
        timer().subscribe(() => {
            this.gridOptions.api.sizeColumnsToFit();
            this._showLoadingOverlay(false);
        });
    }
    _isClickValid(_event) {
        let targetElement = _event.target;
        let invalidList = ['action-btn', 'checkbox-radio-input', 'fa-chevron-down'];
        for (let i = 0; i < invalidList.length; i++) {
            if (targetElement.classList.contains(invalidList[i])) {
                return false;
            }
        }
        return true;
    }
    _resizeColumn(_isResizeToContent = false) {
        if (this._tableService.isApiReady(this.gridOptions)) {
            timer(10).subscribe(() => {
                (_isResizeToContent) ? this._resizeColumnToContent() : this.gridOptions.api.sizeColumnsToFit();
                this.onExportPossible.emit(true);
                this._showLoadingOverlay(false);
            });
        }
    }
    /**
     * resize column to colDef width
     */
    _resizeColumnToContent() {
        let allColumnIds = [];
        this.gridOptions.columnApi.getAllDisplayedColumns().forEach((column) => {
            allColumnIds.push(column.getColId());
        });
        this.gridOptions.columnApi.autoSizeColumns(allColumnIds);
    }
    /**
     * populate dynamic styling value
     * param {ITableConfig} _config: tableConfig
     */
    updateStyle(_config) {
        if (!_config || !_config.config) {
            document.querySelector('body').style.cssText = '';
            return;
        }
        let config = _config.config;
        let bodyCss = '';
        bodyCss += this._updateHeaderStyle(config);
        if (config.body) {
            if (config.body.alternateRow === true) {
                if (config.body.odd && config.body.odd.backgroundColor) {
                    bodyCss += '--kdtable-row-odd-background: ' + config.body.odd.backgroundColor + ';';
                }
                if (config.body.even && config.body.even.backgroundColor) {
                    bodyCss += '--kdtable-row-even-background: ' + config.body.even.backgroundColor + ';';
                }
            }
            if (config.body.style) {
                if (config.body.style.borderWidth) {
                    bodyCss += '--kdtable-body-border-width: ' + config.body.style.borderWidth + ';';
                    bodyCss += '--kdtable-header-border-width: ' + config.body.style.borderWidth + ';';
                }
                if (config.body.style.borderColor) {
                    bodyCss += '--kdtable-body-border-color: ' + config.body.style.borderColor + ';';
                    bodyCss += '--kdtable-header-border-color: ' + config.body.style.borderColor + ';';
                }
                if (config.body.style.borderStyle) {
                    bodyCss += '--kdtable-body-border-style: ' + config.body.style.borderStyle + ';';
                    bodyCss += '--kdtable-header-border-style: ' + config.body.style.borderStyle + ';';
                }
            }
        }
        document.querySelector('body').style.cssText = bodyCss;
    }
    _updateHeaderStyle(_config) {
        if (!_config.header || !_config.header.style)
            return '';
        let bodyCss = '';
        let styleNames = [
            'backgroundColor',
            'textAlign',
            'verticalAlign',
            'color',
            'fontFamily',
            'fontSize',
            'fontWeight',
            'fontStyle',
            'textDecoration',
            // 'borderWidth',
            // 'borderColor',
            // 'borderStyle',
            'opacity'
        ];
        for (let i = 0; i < styleNames.length; ++i) {
            let styleName = styleNames[i];
            let value = _config.header.style[styleName];
            if (styleName === 'verticalAlign')
                value = this._getAlignItem(value);
            styleName = (styleName === 'backgroundColor') ? 'background' : styleName.replace(/([a-z])([A-Z])/g, '$1-$2').toLowerCase();
            if (typeof value !== 'undefined') {
                if (styleName === 'borderWidth' &&
                    (typeof value !== 'string' || value.indexOf('px') === -1))
                    value += 'px';
                bodyCss += '--kdtable-header-' + styleName + ': ' + value + ';';
            }
        }
        return bodyCss;
    }
    /**
     * convert text align into flex-box item align
     * param {string} _verticalAlign: text verticalAlign
     */
    _getAlignItem(_verticalAlign) {
        if (_verticalAlign === 'baseline' || _verticalAlign === 'bottom') {
            return 'flex-end';
        }
        else if (_verticalAlign === 'top') {
            return 'flex-start';
        }
        else { // including invalid input
            if (_verticalAlign !== 'middle' && _verticalAlign !== undefined) {
                console.warn('ERROR: the vertical align value of ' + _verticalAlign + ' is not yet recognised by KdTable. Please only use either top, center or bottom');
            }
            return 'center';
        }
    }
    // private _refreshTable(_tableCellParams?: ITableCellParams): void {
    //     if (this._tableService && this._tableService.isApiReady && this._tableService.isApiReady(this.gridOptions)) {
    //         let toUpdateNode: Array<RowNode> = [];
    //         let allColumnIds: Array<string> = [];
    //         if (!_tableCellParams) {
    //             this.gridOptions.columnApi.getAllDisplayedColumns().forEach((column) => {
    //                 allColumnIds.push(column.getColId());
    //             });
    //         }
    //         this.gridOptions.api.forEachNode((_rowNode: RowNode): void => {
    //             if (_tableCellParams && typeof _rowNode.id !== 'undefined' && _rowNode.id === _tableCellParams.rowId) {
    //                 _rowNode.data[_tableCellParams.colId] = _tableCellParams.data;
    //                 toUpdateNode.push(_rowNode);
    //             } else {
    //                 toUpdateNode.push(_rowNode);
    //             }
    //         });
    //         let refreshParams: { rowNodes: Array<RowNode>, columns: Array<any> } = {
    //             rowNodes: toUpdateNode,
    //             columns: (_tableCellParams) ? [_tableCellParams.colId] : allColumnIds
    //         };
    //         this.gridOptions.api.refreshCells(refreshParams);
    //     }
    // }
    ////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// Pivot Function
    ////////////////////////////////////////////////////////////////////////////////////////////////////////
    _isToolpanelTypeChanged() {
        let isTypeChanged = true;
        if (this._previousToolpanelType) {
            if (typeExist(this.config)) {
                isTypeChanged = this._previousToolpanelType !== this.config.pivot.toolpanel.type;
            }
        }
        else {
            if (typeExist(this.config)) {
                this._previousToolpanelType = this.config.pivot.toolpanel.type;
            }
        }
        return isTypeChanged;
        function typeExist(_config) {
            return _config && _config.pivot && _config.pivot.toolpanel && _config.pivot.toolpanel.type;
        }
    }
    _configurePivotDisplay() {
        let isStateChanged = true;
        if (this.config && this.config.pivot && this.config.pivot.state && this.config.pivot.state.columnState) {
            isStateChanged = this.config.pivot.state.columnState.length !== this._currentState.columnState.length;
        }
        if (this.config.loadType !== 'normal' || (this._isToolpanelTypeChanged() === false && isStateChanged === false))
            return;
        let showToolPanel = false;
        let showPivotMode = false;
        if (this.config.pivot && this.config.pivot.toolpanel) {
            showToolPanel = this.config.pivot.toolpanel.type !== 'none';
            showPivotMode = this.config.pivot.toolpanel.type === 'pivot';
        }
        this._showToolPanel(showToolPanel);
        this._showPivotMode(showPivotMode);
    }
    /**
     * resize column to fit table container if the width of the content column is smaller than container
     */
    _pivotResize() {
        let container = this._vcr.element.nativeElement.querySelector('.ag-header-container');
        let header = this._vcr.element.nativeElement.querySelector('.ag-header-container .ag-header-row');
        this._resizeColumn(header.getBoundingClientRect().width > container.getBoundingClientRect().width);
    }
    _resetPivotColumn() {
        this.gridOptions.columnApi.setRowGroupColumns([]);
        this.gridOptions.columnApi.setPivotColumns([]);
        this.gridOptions.columnApi.setValueColumns([]);
        this.gridOptions.columnApi.setSecondaryColumns([]);
    }
    /**
     * pass state to application.
     * (if setState was triggered before), wait until setState has done processing
     * return {ITablePivotState} [description]
     */
    _getPivotState() {
        // if state is changing, wait until state has been updated then get the most updated state
        let getState = () => {
            this._currentState.columnState = this.gridOptions.columnApi.getColumnState();
            this._currentState.pivotMode = this.gridOptions.columnApi.isPivotMode();
            this._currentState.groupState = this.gridOptions.columnApi.getColumnGroupState();
            return this._currentState;
        };
        let check = () => {
            return this._isChangingState === false;
        };
        return this.wait(check, getState);
    }
    /**
     * replace current state if a state is given, expandGroup base on config
     * should wait until column is present.
     * param {ITablePivotState} _state
     */
    _setPivotState(_state) {
        if (typeof (_state) === 'undefined' || !_state.hasOwnProperty('columnState'))
            return;
        let setState = () => {
            this._isChangingState = true;
            if (_state.columnState.length === 0) {
                this._isChangingState = false;
                this._pivotResize();
                return;
            }
            this._currentState = Object.assign(this._currentState, _state);
            this.gridOptions.columnApi.setColumnState(_state.columnState);
            this.gridOptions.columnApi.setPivotMode(_state.pivotMode || false);
            this.gridOptions.columnApi.setColumnGroupState(_state.groupState || []);
            this._isChangingState = false;
            timer(100).subscribe(() => {
                this._setPivotColumns();
                this._expandGroup();
            });
        };
        let check = () => {
            return this.column && this.column.length > 0;
        };
        this.wait(check, setState);
    }
    /**
     * wait for something to finish then do something, breaks at 100th to prevent infinite loop
     * param {ITablePivotState} _state
     * return {any}
     */
    wait(_check, _do, _limitCounter = 0) {
        if ((_check() && this._tableService.isApiReady(this.gridOptions)) || _limitCounter === 100) {
            if (_limitCounter === 100)
                console.log('Timeout: check fails. running', _do);
            return _do();
        }
        else {
            timer(10).subscribe(() => {
                _limitCounter++;
                this.wait(_check, _do, _limitCounter);
            });
        }
    }
    _isPivotElmExist(_pivotElement) {
        return (typeof _pivotElement['pivot'] !== 'undefined' &&
            _pivotElement['pivot'] !== null &&
            typeof _pivotElement['column-drop'] !== 'undefined' &&
            _pivotElement['column-drop'] !== null);
    }
    /**
     * show pivot mode checkbox and label.
     * when pivot mode is hidden, all pivot data has to be reset.
     * param {boolean = true} _show: true to show, false to hide
     */
    _showPivotMode(_show = true) {
        let setPivotMode = () => {
            if (_show === true) {
                this._pivotElement['pivot'].className = this._pivotElement['pivot'].className.replace(/ hidden/gi, '');
                for (let i = 0; i < this._pivotElement['column-drop'].length; ++i) {
                    this._pivotElement['column-drop'][i].className = this._pivotElement['column-drop'][i].className.replace(/ hidden/gi, '');
                }
                this._setPivotState(this.config.pivot && this.config.pivot.state ? this.config.pivot.state : {});
                return;
            }
            if (this._pivotElement['pivot'] &&
                this._pivotElement['pivot'].className &&
                this._pivotElement['pivot'].className.indexOf('hidden') === -1) {
                this._pivotElement['pivot'].className += ' hidden';
                for (let j = 0; j < this._pivotElement['column-drop'].length; ++j) {
                    this._pivotElement['column-drop'][j].className += ' hidden';
                }
            }
            this._enabledPivotMode(false);
            this._setPivotState({
                'columnState': [],
                'pivotMode': false,
                'groupState': []
            });
            this._resetPivotColumn();
        };
        let check = () => {
            // if (this.config.pivot.toolpanel.type === 'none' || !this.config.pivot || !this.config.pivot.toolpanel) return true;
            if (this.config.pivot &&
                this.config.pivot.toolpanel &&
                this.config.pivot.toolpanel.type &&
                this.config.pivot.toolpanel.type !== 'none') {
                let isPivotElmExist = this._isPivotElmExist(this._pivotElement);
                if (isPivotElmExist === true)
                    return isPivotElmExist;
                let domEleQuery = '#' + this.gridId + '.stg-theme .ag-side-bar';
                this._pivotElement['pivot'] = this._vcr.element.nativeElement.querySelector(domEleQuery + ' .ag-pivot-mode-panel');
                this._pivotElement['column-drop'] = this._vcr.element.nativeElement.querySelectorAll(domEleQuery + ' .ag-column-drop');
                return this._isPivotElmExist(this._pivotElement);
            }
            else {
                return true;
            }
        };
        this.wait(check, setPivotMode);
    }
    /**
     * hide and show toolpanel (pivot mode panel)
     * param {boolean} _show: true to show, false to hide
     */
    _showToolPanel(_show) {
        if (this._tableService.isApiReady(this.gridOptions)) {
            timer(10).subscribe(() => {
                this.gridOptions.api.showToolPanel(_show);
            });
        }
    }
    /**
     * expand row group base on the status that passed in
     * param {boolean} _expand: true to expand, false to collapse
     */
    _expandGroup(_expand) {
        if (typeof _expand === 'undefined') {
            _expand = false;
            if (this.config.pivot && this.config.pivot.state && this.config.pivot.state.expandGroup) {
                _expand = this.config.pivot.state.expandGroup;
            }
        }
        if (this._tableService.isApiReady(this.gridOptions)) {
            timer(10).subscribe(() => {
                (_expand) ? this.gridOptions.api.expandAll() : this.gridOptions.api.collapseAll();
                this._pivotResize();
            });
        }
    }
    /**
     * turn on and off pivot mode
     * If on, 'Column Label' will appear
     * If on, tick column name on toolpanel will assign column to 'Row Group' / 'Values' depends on colDef
     * If off, tick column name on toolpanel will trigger column hide and show
     * param {boolean = false} _enabled: true to check, false to uncheck
     */
    _enabledPivotMode(_enabled = false) {
        this.gridOptions.columnApi.setPivotMode(_enabled);
    }
    // TODO: to be revisit
    /**
     * suppressMovableColumns on pivotColumns and rowGroupColumns
     * columns on pivot mode does not listen to colDef.suppressMovableColumns = true
     * hence we need to access their private variable lockPosition and lockPinned to suppress the column movement
     * param {any} _columns [either passed in from gridEvent: column or will getAllDisplayedColumns]
     */
    _setPivotColumns(_columns) {
        let isPinned = false;
        if (!_columns)
            _columns = this.gridOptions.columnApi.getAllDisplayedColumns();
        _columns.forEach((column) => {
            this._setColumn(column);
            let columnDef = column.getColDef();
            if (columnDef.pivotValueColumn) {
                this._setColumn(columnDef.pivotValueColumn);
            }
            else {
                if (column.parent) {
                    isPinned = true;
                    this._setColumn(column.parent, false);
                    column.parent.pinned = 'left';
                    column.pinned = 'left';
                    columnDef.pinned = 'left';
                }
            }
        });
        if (isPinned)
            this._resizeColumn(true);
    }
    _setColumn(_column, _isSetColDef = true) {
        if (_isSetColDef) {
            let columnDef = _column.getColDef();
            columnDef.suppressMovable = this._suppressMovableColumns;
            columnDef.lockPosition = this._suppressMovableColumns;
            columnDef.lockPinned = this._suppressMovableColumns;
        }
        if (_column.setMoving) {
            _column.setMoving(!this._suppressMovableColumns);
        }
        else {
            _column.moving = !this._suppressMovableColumns;
        }
        _column.lockPosition = this._suppressMovableColumns;
        _column.lockPinned = this._suppressMovableColumns;
    }
    // TODO: to be revisit
    ////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// Column/Row/Configuration Generation
    ////////////////////////////////////////////////////////////////////////////////////////////////////////
    _setGridOptions(_tableConfig) {
        if (_tableConfig.hasOwnProperty('suppressMovableColumns'))
            this._suppressMovableColumns = _tableConfig.suppressMovableColumns;
        this._direction = this._domSvc.getDocumentDirection();
        this.gridOptions = this._tableService.generateGridOptions(_tableConfig, this._direction);
        this.gridOptions.context['gridId'] = this.gridId;
        this.gridOptions.suppressMovableColumns = false;
        this.gridOptions.onColumnRowGroupChanged = (params) => {
            this._setPivotColumns(params.columns);
            this._expandGroup();
        };
        this._tableService.setGridOptions(this.gridOptions);
    }
    _setColumnDef(_colDefConfig) {
        this._tableService.setColumnDef(_colDefConfig, this.config, this._suppressMovableColumns);
        this._resizeColumn();
    }
    _enableColumnMovable(_enabled = true) {
        if (this._tableService.isApiReady(this.gridOptions)) {
            this._suppressMovableColumns = _enabled;
            this._setColumnDef(this.column);
            if (this.config.loadType === 'normal' && this.config.pivot.toolpanel.type === 'pivot') {
                this._setPivotState(this._currentState);
            }
            this._pivotResize();
        }
    }
    _setRowData(_rowData, _setToGridOptions = true) {
        // this._tableService.updateRowDataWithColumnConfig(_rowData, this.column, this.gridId);
        this._tableService.updateRowDataWithColumn(_rowData, this.column, this.gridId, this.gridOptions);
        if (_setToGridOptions) {
            this._tableService.setRowData(_rowData);
        }
        if (this._tableService.isEnterpriseModel(this.config.loadType) && this._tableService.isApiReady(this.gridOptions)) {
            this._gridReadyEnterpriseCycle();
        }
        timer().subscribe(() => {
            this._gridSetRowCycle();
            this._setTableBorderBottom();
        });
    }
    ////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// Events - Subscriber / On functions
    ////////////////////////////////////////////////////////////////////////////////////////////////////////
    _processEventParams(_fromEvent, _additionalParams) {
        switch (_fromEvent) {
            case 'datasource':
            case 'selection':
            case 'input':
            case 'button':
                this._broadcastEventParams(_additionalParams);
                break;
            default:
                console.error('KdTable warning: No such event found for: ', _fromEvent);
        }
    }
    _broadcastEventParams(_params) {
        this._tableIntEvent.kdTableEventList(this.config.id, _params);
    }
    _broadcastModelChangedEvent() {
        this._tableIntEvent.modelChanged(this.config.id);
    }
    _setupSubscriptionEvents() {
        this._subscriptionObj.selectNodesSub = this._tableIntEvent.onSelectionChanged(this.config.id).subscribe((_rowNode) => {
            this._updateSelectionNodes(_rowNode);
        });
        this._subscriptionObj.gridQuestionSub = this._tableIntEvent.onInputChanged(this.config.id).subscribe((_formParams) => {
            this._processInputChanged(_formParams);
        });
        this._subscriptionObj.updateEmitRow = this._tableIntEvent.onUpdateEmitRowNodes(this.config.id).subscribe((_data) => {
            if (_data.action === 'delete') {
                let rowKey = (typeof this.config.rowIdKey !== 'undefined') ? this.config.rowIdKey : 'id';
                this._deleteNodeFromRowData([_data.rowData[rowKey]]);
                this._emitInputUpdateEvent();
            }
        });
    }
    ////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// Selection - Checkbox / Radio functions
    ////////////////////////////////////////////////////////////////////////////////////////////////////////
    _updateSelectionNodes(_rowNode, _isInitial) {
        let triggerNode = (typeof _isInitial !== 'undefined' && _isInitial) ? 'initial' : 'all';
        if (typeof _rowNode !== 'undefined') {
            triggerNode = _rowNode.data.id;
        }
        let selectionParams = new KdTableSelectionUpdateEvent();
        selectionParams.triggerNode = triggerNode;
        selectionParams.selectedNodes = this._tableService.updateSelectionValues(this.gridOptions.rowData, this.config.selection.value, this.config.selection.returnKey, this.config.loadType);
        // selectionParams.selection = (_rowNode.isSelected()) ? 'selected' : 'unselected';
        this._processEventParams('selection', selectionParams);
    }
    _processInitialSelection() {
        this._updateSelectionNodes(undefined, true);
    }
    ////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// Input functions
    ////////////////////////////////////////////////////////////////////////////////////////////////////////
    _processInputChanged(_formParams) {
        let inputParams = new KdTableInputUpdateEvent();
        inputParams.colId = _formParams.colId;
        inputParams.rowId = _formParams.rowId;
        inputParams.questionKey = _formParams.questionKey;
        inputParams.question = _formParams.question;
        inputParams.value = _formParams.data;
        this._processEventParams('input', inputParams);
    }
    _emitInputUpdateEvent() {
        let inputParams = new KdTableInputUpdateEvent();
        this._processEventParams('input', inputParams);
    }
    _deleteNodeFromRowData(_dataList) {
        let rowIdKey = (typeof this.config.rowIdKey !== 'undefined') ? this.config.rowIdKey : 'id';
        for (let i = 0; i < _dataList.length; ++i) {
            for (let j = 0; j < this.row.length; ++j) {
                if (_dataList[i].toString() === this.row[j][rowIdKey].toString()) {
                    this.row.splice(j, 1);
                    break;
                }
            }
        }
    }
    ////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// Enterprise datasource functions
    ////////////////////////////////////////////////////////////////////////////////////////////////////////
    _clearDatasource() {
        if (this._tableService.isApiReady(this.gridOptions)) {
            this.gridOptions.api.setEnterpriseDatasource(null);
            this.gridOptions.api.setFilterModel(null);
            this.gridOptions.api.setSortModel(null);
            if (typeof this._subscriptionObj.datasourceSub !== 'undefined') {
                this._subscriptionObj.datasourceSub.unsubscribe();
            }
        }
    }
    _generateEnterpriseDatasource() {
        let datasource = {
            getRows: (_params) => {
                this._showLoadingOverlay(true);
                if (typeof this._subscriptionObj.datasourceSub !== 'undefined') {
                    this._subscriptionObj.datasourceSub.unsubscribe();
                }
                this._subscriptionObj.datasourceSub = this._generateDatasourceRows(_params).subscribe((_response) => {
                    _params.successCallback(_response.rows, _response.total);
                    this._showLoadingOverlay(false);
                });
            }
        };
        this.gridOptions.api.setEnterpriseDatasource(datasource);
    }
    _generateDatasourceRows(_datasourceParams) {
        return new Observable((_observer) => {
            switch (this.config.loadType) {
                case 'infinite':
                case 'oneshot':
                    this._tableService.generateDatasourceRows(_datasourceParams.request, this.gridOptions.rowData.slice()).subscribe((_response) => {
                        _observer.next(_response);
                        _observer.complete();
                    });
                    break;
                case 'server':
                    let serverParams = new KdTableDatasourceEvent(_datasourceParams.request, _observer);
                    this._processEventParams('datasource', serverParams);
                    break;
                default:
                    console.error('KdTable warning: No such loadType find for: ', this.config.loadType);
                    _observer.complete();
            }
        });
    }
    ////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// API functions
    ////////////////////////////////////////////////////////////////////////////////////////////////////////
    _initITableApi() {
        if (typeof this.api !== 'undefined') {
            let apiParams = {
                // gridOptions: this.gridOptions,
                event: this._tableIntEvent,
                id: this.config.id,
                rows: this.row,
                columns: this.column
            };
            this._tableService.generatedApiFunctions(this.api, apiParams);
            /// Temp fix to access loading variable //
            /********* General API **********/
            this.api.general.showLoading = (_toggle) => {
                this.displayLoading = _toggle;
            };
            this.api.general.updateCell = (_tableCellParams) => {
                let toUpdateNode = [];
                this.gridOptions.api.forEachNode((_rowNode) => {
                    if (typeof _rowNode.id !== 'undefined' && _rowNode.id === _tableCellParams.rowId) {
                        _rowNode.data[_tableCellParams.colId] = _tableCellParams.data;
                        toUpdateNode.push(_rowNode);
                    }
                });
                let refreshParams = {
                    rowNodes: toUpdateNode,
                    columns: [_tableCellParams.colId]
                };
                this.gridOptions.api.refreshCells(refreshParams);
            };
            this.api.general.searchRow = (_searchText) => {
                if (this.config.loadType === 'normal') {
                    this.gridOptions.api.setQuickFilter(_searchText);
                }
                else {
                    console.warn('KdTable warning: Quick filtering of data is not supported for oneshot/server/infinite loadType.');
                }
            };
            this.api.general.addRows = (_rows, _scrollToVisible = false) => {
                /*
                    ag-Grid did not export RowDataTransaction interface. Interface as:
                        {
                            add: [],
                            remove: [],
                            update: []
                        }
                 */
                if (typeof this.config.loadType === 'undefined' || this.config.loadType === 'normal') {
                    let rowKey = (typeof this.config.rowIdKey !== 'undefined') ? this.config.rowIdKey : 'id';
                    for (let i = 0; i < _rows.length; ++i) {
                        this.row.push(_rows[i]);
                    }
                    this._setRowData(this.row, false);
                    this.gridOptions.api.updateRowData({ add: _rows.slice() });
                    if (_scrollToVisible) {
                        this.gridOptions.api.ensureIndexVisible(this.gridOptions.api.getRowNode(_rows[0][rowKey].toString()).rowIndex);
                    }
                }
                else {
                    console.warn('KdTable warning: API function: addRows() can only be used for normal loadType.');
                }
            };
            this.api.general.deleteRows = (_id) => {
                if (typeof this.config.loadType === 'undefined' || this.config.loadType === 'normal') {
                    let deleteIdList = [];
                    if (typeof _id === 'string' || typeof _id === 'number') {
                        deleteIdList.push(_id.toString());
                    }
                    else {
                        for (let i = 0; i < _id.length; ++i) {
                            deleteIdList.push(_id.toString());
                        }
                    }
                    this._deleteNodeFromRowData(deleteIdList);
                    let key = typeof this.config.rowIdKey === 'undefined' ? 'id' : this.config.rowIdKey;
                    let deleteRows = [];
                    for (let i = 0; i < deleteIdList.length; ++i) {
                        deleteRows.push({ [key]: deleteIdList[i] });
                    }
                    /*
                        ag-Grid did not export RowDataTransaction interface. Interface as:
                            {
                                add: [],
                                remove: [],
                                update: []
                            }
                     */
                    let transactionObj = {
                        remove: deleteRows
                    };
                    this.gridOptions.api.updateRowData(transactionObj);
                    this._emitInputUpdateEvent();
                }
                else {
                    console.warn('KdTable warning: API function: addRows() can only be used for normal loadType.');
                }
            };
            this.api.general.setButtonDisabled = (_buttonType, _toDisabled) => {
                for (let i = 0; i < this.config.button.length; ++i) {
                    if (this.config.button[i].type === _buttonType) {
                        this.config.button[i].disabled = _toDisabled;
                    }
                }
            };
            this.api.general.exportToExcel = (_params) => {
                let defaultParams = {
                    fileName: 'file',
                    allColumns: true,
                    suppressTextAsCDATA: true,
                };
                // xlsx only allow sheet name to be 31 characters long;
                if (_params.hasOwnProperty('sheetName'))
                    _params.sheetName = _params.sheetName.slice(0, 31);
                let params = Object.assign({}, defaultParams, _params);
                let content = this.gridOptions.api.getDataAsExcel(params);
                let workbook = XLSX.read(content, { type: 'binary' });
                let xlsxContent = XLSX.write(workbook, { bookType: 'xlsx', type: 'base64' });
                let blobObject = this._tableService.b64toBlob(xlsxContent, 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
                saveAs(blobObject, params.fileName + '.xlsx');
            };
            this.api.general.resizeColumn = (_isResizeToContent = false) => {
                this._resizeColumn(_isResizeToContent);
            };
            this.api.general.enableColumnMovable = (_enabled) => {
                this._enableColumnMovable(_enabled);
            };
            /********* Pivot API **********/
            if (typeof (this.api.pivot) === 'undefined')
                this.api.pivot = {};
            this.api.pivot.autoResize = () => {
                this._pivotResize();
            };
            this.api.pivot.showToolPanel = (_show) => {
                this._showToolPanel(_show);
            };
            this.api.pivot.expandGroup = (_expand) => {
                this._expandGroup(_expand);
            };
            this.api.pivot.getPivotState = () => {
                return this._getPivotState();
            };
            this.api.pivot.setPivotState = (_state) => {
                this._setColumnDef(this.column);
                this._setPivotState(_state);
            };
            this.api.pivot.enabledPivotMode = (_enabled) => {
                this._enabledPivotMode(_enabled);
            };
            this.api.pivot.showPivotMode = (_show) => {
                this._showPivotMode(_show);
            };
            /********* Input API **********/
            this.api.dynamicForm.clearAllError = () => {
                let tableContext = this.gridOptions.context[this._tableService.getTableContextKey()];
                for (let item in tableContext) {
                    if (tableContext.hasOwnProperty(item)) {
                        let contextItem = tableContext[item];
                        for (let question in contextItem) {
                            if (contextItem.hasOwnProperty(question)) {
                                if (typeof contextItem[question].errors === 'undefined') {
                                    contextItem[question].errors = [];
                                }
                                contextItem[question].errors.length = 0;
                            }
                        }
                    }
                }
            };
        }
        else {
            console.warn('KdTable warning: No api property / undefined api property is passed in.');
        }
    }
    ////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// Misc functions
    ////////////////////////////////////////////////////////////////////////////////////////////////////////
    _initGridService(_loadType) {
        if (typeof _loadType === 'undefined' || _loadType === 'normal') {
            this._tableService = new KdTableNormalSvc();
        }
        else {
            this._tableService = new KdTableEnterpriseSvc();
        }
    }
    _updateGridConfig(_gridConfig) {
        this.gridId = this._tableService.getGridId(_gridConfig);
        this._tableService.updateGridButtons(_gridConfig);
        this._tableService.updateSelectDefaultValue(_gridConfig);
    }
}
KdTable.decorators = [
    { type: Component, args: [{
                selector: 'kd-table',
                template: "<div class=\"kdx kdx-ag-grid-wrapper\">\r\n    <kd-progressloader *ngIf=\"displayLoading\" configtype=\"small-spinner\" [configvalue]=\"null\"></kd-progressloader>\r\n    <div *ngIf=\"config?.button?.length > 0\" class=\"gird-btn-wrapper\">\r\n        <button *ngFor=\"let item of config.button\" class=\"btn btn-icon\" type='button' [disabled]=\"item.disabled\" (click)=\"onButtonClicked(item)\">\r\n            <i [ngClass]=\"item.icon\"></i>\r\n            <span>{{item.label}}</span>\r\n        </button>\r\n    </div>\r\n    <ag-grid-angular\r\n    \t#agGrid\r\n    \tid=\"{{gridId}}\"\r\n    \tclass=\"stg-theme\"\r\n        [ngClass]=\"rightDirection == 'rtl' ? 'rtl' : '' \"\r\n    \t[ngClass]=\"{'ag-row-clickable': config.click}\"\r\n        [gridOptions]=\"gridOptions\"\r\n        [rowDragManaged]=\"true\"\r\n        [singleClickEdit]=\"_singleClickEdit\"\r\n        (gridReady)=\"onGridReady($event)\"\r\n        (modelUpdated)=\"onModelUpdated($event)\"\r\n        (rowClicked)=\"onRowClicked($event)\"\r\n    ></ag-grid-angular>\r\n</div>",
                encapsulation: ViewEncapsulation.None,
                providers: [KdDomElemSvc, KdIntTableEvent, KdTableNormalSvc, KdTableEnterpriseSvc],
                host: { 'class': 'kdx-table' },
                styles: [""]
            },] }
];
KdTable.ctorParameters = () => [
    { type: ViewContainerRef },
    { type: Router },
    { type: KdDomElemSvc },
    { type: KdIntTableEvent }
];
KdTable.propDecorators = {
    row: [{ type: Input }],
    column: [{ type: Input }],
    config: [{ type: Input }],
    api: [{ type: Input }],
    editTable: [{ type: Input }],
    displayEditable: [{ type: Input }],
    onExportPossible: [{ type: Output }],
    displayFull: [{ type: HostBinding, args: ['class.full-grid',] }],
    _classKdxTable: [{ type: HostBinding, args: ['class.kdx-table',] }],
    onResize: [{ type: HostListener, args: ['window:resize', ['$event'],] }]
};
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoia2QtYW5ndWxhci10YWJsZS5qcyIsInNvdXJjZVJvb3QiOiJEOi9vcGVuRU1JUy9zdHlsZWd1aWRlL2lvc3RnLW9wZW5lbWlzLXN0eWxlZ3VpZGUvcHJvamVjdHMvb3BlbmVtaXMtc3R5bGVndWlkZS1saWIvc3JjLyIsInNvdXJjZXMiOlsia2QtY29tcG9uZW50cy9rZC1hbmd1bGFyLXRhYmxlL2tkLWFuZ3VsYXItdGFibGUudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsT0FBTyxFQUNILFNBQVMsRUFLVCxpQkFBaUIsRUFDakIsS0FBSyxFQUNMLFdBQVcsRUFDWCxZQUFZLEVBQ1osZ0JBQWdCLEVBQ2hCLFlBQVksRUFDWixNQUFNLEVBQ1QsTUFBTSxlQUFlLENBQUM7QUFDdkIsT0FBTyxFQUFFLE1BQU0sRUFBRSxNQUFNLGlCQUFpQixDQUFDO0FBQ3pDLE9BQU8sRUFBRSxVQUFVLEVBQUUsS0FBSyxFQUE0QixNQUFNLE1BQU0sQ0FBQztBQW9CbkUsT0FBTyxvQkFBb0IsQ0FBQztBQUM1QixPQUFPLEtBQUssSUFBSSxNQUFNLE1BQU0sQ0FBQztBQUM3QixPQUFPLEVBQUUsTUFBTSxFQUFFLE1BQU0sWUFBWSxDQUFDO0FBRXBDLE9BQU8sRUFXSCxzQkFBc0IsRUFDdEIsMkJBQTJCLEVBQzNCLHVCQUF1QixFQUN2QixrQkFBa0IsRUFDckIsTUFBTSw4QkFBOEIsQ0FBQztBQUV0QyxPQUFPLEVBQUUsZUFBZSxFQUFFLE1BQU0sMEJBQTBCLENBQUM7QUFDM0QsT0FBTyxFQUFFLGdCQUFnQixFQUFFLE1BQU0sc0NBQXNDLENBQUM7QUFDeEUsT0FBTyxFQUFFLG9CQUFvQixFQUFFLE1BQU0sMENBQTBDLENBQUM7QUFDaEYseUNBQXlDO0FBQ3pDLE9BQU8sRUFBRSxZQUFZLEVBQUUsV0FBVyxFQUFFLE1BQU0sb0JBQW9CLENBQUM7QUFDL0QsT0FBTyxFQUFFLGNBQWMsRUFBRSxNQUFNLG9CQUFvQixDQUFDO0FBSXBEOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7R0FxRUc7QUFhSCxNQUFNLE9BQU8sT0FBTztJQXlDaEIsWUFDWSxJQUFzQixFQUN0QixPQUFlLEVBQ2YsT0FBcUI7SUFDN0IsMkNBQTJDO0lBQ25DLGNBQStCO1FBSi9CLFNBQUksR0FBSixJQUFJLENBQWtCO1FBQ3RCLFlBQU8sR0FBUCxPQUFPLENBQVE7UUFDZixZQUFPLEdBQVAsT0FBTyxDQUFjO1FBRXJCLG1CQUFjLEdBQWQsY0FBYyxDQUFpQjtRQTdDcEMsV0FBTSxHQUFXLEVBQUUsQ0FBQztRQUdwQixtQkFBYyxHQUFZLElBQUksQ0FBQztRQUMvQixxQkFBZ0IsR0FBWSxLQUFLLENBQUM7UUFDakMsZ0JBQVcsR0FBRyxPQUFPLENBQUMsb0JBQW9CLENBQUMsQ0FBQztRQUc1QyxxQkFBZ0IsR0FBb0MsRUFBRSxDQUFDO1FBRXZELGtCQUFhLEdBQXFCO1lBQ3RDLFdBQVcsRUFBRSxFQUFFO1lBQ2YsU0FBUyxFQUFFLEtBQUs7WUFDaEIsVUFBVSxFQUFFLEVBQUU7U0FDakIsQ0FBQztRQUNNLHFCQUFnQixHQUFZLEtBQUssQ0FBQztRQUNsQyxrQkFBYSxHQUEyQjtZQUM1QyxPQUFPLEVBQUUsSUFBSTtZQUNiLGFBQWEsRUFBRSxJQUFJO1NBQ3RCLENBQUM7UUFFTSw0QkFBdUIsR0FBWSxJQUFJLENBQUM7UUFFeEMsZUFBVSxHQUFrQixLQUFLLENBQUM7UUFVaEMscUJBQWdCLEdBQTBCLElBQUksWUFBWSxFQUFFLENBQUM7UUFFdkMsbUJBQWMsR0FBWSxJQUFJLENBQUM7UUFHeEQsdUJBQWtCLEdBQVksS0FBSyxDQUFDO1FBU3ZDLGNBQWMsQ0FBQyxhQUFhLENBQUMsV0FBVyxDQUFDLEtBQUssQ0FBQyxDQUFDO0lBQ3BELENBQUM7SUFHRCxRQUFRLENBQUMsTUFBYTtRQUNsQixJQUFJLENBQUMsVUFBVSxFQUFFLENBQUM7SUFDdEIsQ0FBQztJQUVELCtFQUErRTtJQUMvRSxRQUFRO1FBQ0osdUZBQXVGO1FBQ3ZGLElBQUksQ0FBQyxtQkFBbUIsQ0FBQyxJQUFJLENBQUMsQ0FBQztRQUMvQixJQUFJLENBQUMsY0FBYyxFQUFFLENBQUM7SUFDMUIsQ0FBQztJQUVELFdBQVcsQ0FBQyxjQUE2QjtRQUNyQyxJQUFJLENBQUMsbUJBQW1CLENBQUMsSUFBSSxDQUFDLENBQUM7UUFDL0IsT0FBTyxDQUFDLEdBQUcsQ0FBQywyQkFBMkIsRUFBRSxjQUFjLENBQUMsQ0FBQztRQUV6RCxJQUFJLE9BQU8sY0FBYyxDQUFDLE1BQU0sS0FBSyxXQUFXO1lBQzVDLENBQUMsY0FBYyxDQUFDLE1BQU0sQ0FBQyxXQUFXLEVBQ3BDO1lBQ0UsSUFBSSxDQUFDLGFBQWEsQ0FBQyxjQUFjLENBQUMsTUFBTSxDQUFDLFlBQVksQ0FBQyxDQUFDO1lBQ3ZELElBQUksQ0FBQyxtQkFBbUIsQ0FBQyxLQUFLLENBQUMsQ0FBQztTQUNuQztRQUVELElBQUksT0FBTyxjQUFjLENBQUMsR0FBRyxLQUFLLFdBQVc7WUFDekMsQ0FBQyxjQUFjLENBQUMsR0FBRyxDQUFDLFdBQVcsRUFDakM7WUFDRSxJQUFJLENBQUMsV0FBVyxDQUFDLGNBQWMsQ0FBQyxHQUFHLENBQUMsWUFBWSxDQUFDLENBQUM7WUFDbEQsSUFBSSxDQUFDLG1CQUFtQixDQUFDLEtBQUssQ0FBQyxDQUFDO1NBQ25DO1FBRUQsSUFBSSxPQUFPLGNBQWMsQ0FBQyxNQUFNLEtBQUssV0FBVyxFQUFFO1lBQzlDLElBQUksQ0FBQyxtQkFBbUIsQ0FBQyxLQUFLLENBQUMsQ0FBQztZQUNoQyxJQUFJLENBQUMsV0FBVyxDQUFDLGNBQWMsQ0FBQyxNQUFNLENBQUMsWUFBWSxDQUFDLENBQUM7WUFFckQsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxHQUFTLEVBQUU7Z0JBQzVCLElBQUksQ0FBQyxzQkFBc0IsRUFBRSxDQUFDO2dCQUU5QixJQUFJLE9BQU8sSUFBSSxDQUFDLE1BQU0sQ0FBQyxzQkFBc0IsS0FBSyxXQUFXLEVBQzNEO29CQUNFLElBQUksSUFBSSxDQUFDLE1BQU0sQ0FBQyxzQkFBc0IsS0FBSyxJQUFJLENBQUMsdUJBQXVCO3dCQUNuRSxJQUFJLENBQUMsb0JBQW9CLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxzQkFBc0IsQ0FBQyxDQUFDO2lCQUNyRTtxQkFBTTtvQkFDSCxJQUFJLENBQUMsTUFBTSxDQUFDLHNCQUFzQixHQUFHLElBQUksQ0FBQyx1QkFBdUIsQ0FBQztpQkFDckU7WUFDTCxDQUFDLENBQUMsQ0FBQztTQUNOO0lBQ0wsQ0FBQztJQUVELFdBQVc7UUFDUCwrQ0FBK0M7UUFDL0MsS0FBSyxJQUFJLElBQUksSUFBSSxJQUFJLENBQUMsZ0JBQWdCLEVBQUU7WUFDcEMsSUFBSSxPQUFPLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxJQUFJLENBQUMsS0FBSyxXQUFXLEVBQUU7Z0JBQ3BELElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxJQUFJLENBQUMsQ0FBQyxXQUFXLEVBQUUsQ0FBQzthQUM3QztTQUNKO0lBQ0wsQ0FBQztJQUVELGFBQWEsQ0FBQyxnQkFBZ0IsRUFBRSxPQUFxQjtRQUNqRCw4REFBOEQ7UUFFOUQsMENBQTBDO1FBQzFDLGdEQUFnRDtRQUNoRCx5REFBeUQ7UUFDekQsS0FBSztRQUNMLElBQUksZ0JBQWdCLEVBQUU7WUFDbEIsSUFBSSxDQUFDLFdBQVcsQ0FBQyxPQUFPLENBQUMsSUFBSSxHQUFHLE1BQU0sQ0FBQTtZQUN0QyxPQUFPLENBQUMsT0FBTyxDQUFDLElBQUksR0FBRyxNQUFNLENBQUM7WUFDOUIsT0FBTyxDQUFDLGdCQUFnQixHQUFHLEdBQUcsQ0FBQTtTQUNqQzthQUFNO1lBQ0gsSUFBSSxDQUFDLFdBQVcsQ0FBQyxPQUFPLENBQUMsSUFBSSxHQUFHLE1BQU0sQ0FBQTtZQUN0QyxPQUFPLENBQUMsT0FBTyxDQUFDLElBQUksR0FBRyxNQUFNLENBQUM7U0FDakM7UUFFRCxJQUFJLFFBQVEsR0FBRyxJQUFJLENBQUMsV0FBVyxDQUFDLFNBQVMsQ0FBQyxzQkFBc0IsRUFBRSxDQUFDO1FBQ25FLHVDQUF1QztRQUN2Qyx1QkFBdUI7UUFDdkIsNkNBQTZDO1FBQzdDLG1CQUFtQjtRQUNuQix1QkFBdUI7UUFDdkIsSUFBSSxDQUFDLFdBQVcsQ0FBQyxTQUFTLENBQUMsZUFBZSxDQUFDLFFBQVEsQ0FBQyxDQUFBO0lBQ3hELENBQUM7SUFFRCxXQUFXLENBQUMsSUFBSTtRQUNaLElBQUksSUFBSSxDQUFDLFNBQVMsSUFBSSxDQUFDLElBQUksQ0FBQyxlQUFlLEVBQUU7WUFDekMsSUFBSSxDQUFDLGtCQUFrQixHQUFHLENBQUMsSUFBSSxDQUFDLGtCQUFrQixDQUFDO1lBQ25ELElBQUksQ0FBQyxnQkFBZ0IsR0FBRyxDQUFDLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQztZQUMvQyxJQUFJLFFBQVEsR0FBRyxJQUFJLENBQUMsV0FBVyxDQUFDLFNBQVMsQ0FBQyxzQkFBc0IsRUFBRSxDQUFDO1lBQ25FLElBQUksYUFBYSxHQUFHLEVBQUUsQ0FBQztZQUN2QixRQUFRLENBQUMsT0FBTyxDQUFDLENBQUMsTUFBVyxFQUFFLEVBQUU7Z0JBQzdCLElBQUksU0FBUyxHQUFHLE1BQU0sYUFBTixNQUFNLHVCQUFOLE1BQU0sQ0FBRSxTQUFTLEVBQUUsQ0FBQztnQkFDcEMsSUFBSSxTQUFTLENBQUMsT0FBTyxJQUFJLElBQUksRUFBRTtvQkFDM0IsU0FBUyxDQUFDLFNBQVMsR0FBRyxVQUFVLE1BQVc7d0JBQ3ZDLElBQUksQ0FBQyxLQUFLLENBQUMsVUFBVSxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsQ0FBQyxJQUFJLFVBQVUsQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLEdBQUcsRUFBRSxFQUFFOzRCQUNuRSxPQUFPLEVBQUUsS0FBSyxFQUFFLFNBQVMsRUFBRSxDQUFDO3lCQUMvQjs2QkFBTTs0QkFDSCxPQUFPLEVBQUUsS0FBSyxFQUFFLE1BQU0sRUFBRSxDQUFDO3lCQUM1QjtvQkFDTCxDQUFDO3dCQUNHLFNBQVMsQ0FBQyxjQUFjLEdBQUc7NEJBQ3ZCLG1CQUFtQixFQUFFLFVBQVUsTUFBTTtnQ0FDakMsT0FBTyxDQUFDLENBQUM7NEJBQ2IsQ0FBQzs0QkFDRCxlQUFlLEVBQUUsVUFBVSxNQUFNO2dDQUM3QixzREFBc0Q7NEJBQzFELENBQUM7eUJBQ0o7d0JBQ0QsU0FBUyxDQUFDLGtCQUFrQixHQUFHOzRCQUMzQixlQUFlLEVBQUUsR0FBRyxFQUFFLENBQUMsSUFBSSxDQUFDLGtCQUFrQjt5QkFDakQ7d0JBQ0QsU0FBUyxDQUFDLFFBQVEsR0FBRyxDQUFDLE1BQVcsRUFBRSxFQUFFOzRCQUNqQyxJQUFJLElBQUksR0FBRyxNQUFNLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUM7NEJBQ2pDLE1BQU0sQ0FBQyxJQUFJLENBQUMsSUFBSSxHQUFHLE1BQU0sQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQzs0QkFDekMsT0FBTyxJQUFJLENBQUM7d0JBRWhCLENBQUM7d0JBQ0QsU0FBUyxDQUFDLGVBQWUsR0FBRyxDQUFDLE1BQVcsRUFBRSxFQUFFOzRCQUV4QyxJQUFJLElBQUksSUFBSSxNQUFNLEVBQUU7Z0NBQ2hCLElBQUksWUFBWSxHQUFHLE1BQU0sQ0FBQyxRQUFRLENBQUM7Z0NBQ25DLE1BQU0sQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsR0FBRyxZQUFZLENBQUM7NkJBQ25EO2lDQUFNO2dDQUNILElBQUksWUFBWSxHQUFHLFVBQVUsQ0FBQyxNQUFNLENBQUMsUUFBUSxDQUFDLENBQUM7Z0NBQy9DLE1BQU0sQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsR0FBRyxZQUFZLENBQUM7NkJBQ25EOzRCQUNELE9BQU8sQ0FBQyxHQUFHLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxFQUFFLGtDQUFrQyxDQUFDLENBQUM7NEJBRWxGLGVBQWU7d0JBQ25CLENBQUMsQ0FBQTtpQkFDUjtnQkFDRCxhQUFhLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDO1lBQ2xDLENBQUMsQ0FBQyxDQUFDO1lBQ0gsSUFBSSxDQUFDLFdBQVcsQ0FBQyxTQUFTLENBQUMsZUFBZSxDQUFDLGFBQWEsQ0FBQyxDQUFDO1NBQzdEO2FBQU0sSUFBSSxJQUFJLENBQUMsZUFBZSxFQUFFO1lBQzdCLElBQUksQ0FBQyxrQkFBa0IsR0FBRyxDQUFDLElBQUksQ0FBQyxrQkFBa0IsQ0FBQztZQUNuRCxJQUFJLENBQUMsZ0JBQWdCLEdBQUcsQ0FBQyxJQUFJLENBQUMsZ0JBQWdCLENBQUM7WUFDL0MsSUFBSSxRQUFRLEdBQUcsSUFBSSxDQUFDLFdBQVcsQ0FBQyxTQUFTLENBQUMsc0JBQXNCLEVBQUUsQ0FBQztZQUNuRSxJQUFJLGFBQWEsR0FBRyxFQUFFLENBQUM7WUFDdkIsUUFBUSxDQUFDLE9BQU8sQ0FBQyxDQUFDLE1BQVcsRUFBRSxFQUFFO2dCQUM3QixJQUFJLFNBQVMsR0FBRyxNQUFNLGFBQU4sTUFBTSx1QkFBTixNQUFNLENBQUUsU0FBUyxFQUFFLENBQUM7Z0JBQ3BDLElBQUksU0FBUyxDQUFDLE9BQU8sSUFBSSxJQUFJLEVBQUU7b0JBQzNCLFNBQVMsQ0FBQyxXQUFXLEdBQUcsVUFBVSxNQUFNO3dCQUNwQyxJQUFJLEtBQUssR0FBRyxNQUFNLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLENBQUM7d0JBQzdDLElBQUksSUFBSSxJQUFJLE1BQU0sRUFBRTs0QkFDaEIsT0FBTyxLQUFLLENBQUM7eUJBQ2hCOzZCQUFNOzRCQUNILElBQUksQ0FBQyxLQUFLLENBQUMsVUFBVSxDQUFDLEtBQUssQ0FBQyxDQUFDLEVBQUU7Z0NBQzNCLE9BQU8sS0FBSyxDQUFDOzZCQUNoQjtpQ0FBTTtnQ0FDSCxPQUFPLEVBQUUsQ0FBQzs2QkFDYjt5QkFDSjtvQkFDTCxDQUFDO3dCQUNHLFNBQVMsQ0FBQyxjQUFjLEdBQUcsRUFBRTt3QkFDN0IsU0FBUyxDQUFDLGtCQUFrQixHQUFHOzRCQUMzQixlQUFlLEVBQUUsR0FBRyxFQUFFLENBQUMsSUFBSSxDQUFDLGtCQUFrQjt5QkFDakQ7d0JBQ0QsU0FBUyxDQUFDLFFBQVEsR0FBRyxDQUFDLE1BQVcsRUFBRSxFQUFFOzRCQUNqQyxPQUFPLEtBQUssQ0FBQzt3QkFDakIsQ0FBQyxDQUFBO2lCQUNSO2dCQUNELGFBQWEsQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLENBQUM7WUFDbEMsQ0FBQyxDQUFDLENBQUM7WUFDSCxJQUFJLENBQUMsV0FBVyxDQUFDLFNBQVMsQ0FBQyxlQUFlLENBQUMsYUFBYSxDQUFDLENBQUM7U0FDN0Q7SUFDTCxDQUFDO0lBRUQsa0JBQWtCLENBQUMsZ0JBQWdCO1FBQy9CLElBQUksZ0JBQWdCLEVBQUU7WUFDbEIsSUFBSSxDQUFDLFdBQVcsQ0FBQyxPQUFPLENBQUMsTUFBTSxHQUFHLE1BQU0sQ0FBQztTQUM1QzthQUFNO1lBQ0gsSUFBSSxDQUFDLFdBQVcsQ0FBQyxPQUFPLENBQUMsTUFBTSxHQUFHLE1BQU0sQ0FBQztTQUM1QztRQUNELElBQUksUUFBUSxHQUFHLElBQUksQ0FBQyxXQUFXLENBQUMsU0FBUyxDQUFDLHNCQUFzQixFQUFFLENBQUM7UUFDbkUsSUFBSSxDQUFDLFdBQVcsQ0FBQyxTQUFTLENBQUMsZUFBZSxDQUFDLFFBQVEsQ0FBQyxDQUFDO1FBQ3JELElBQUksQ0FBQyxtQkFBbUIsQ0FBQyxLQUFLLENBQUMsQ0FBQztJQUNwQyxDQUFDO0lBRUQsY0FBYyxDQUFDLGdCQUFnQjtRQUMzQixJQUFJLGdCQUFnQixFQUFFO1lBQ2xCLElBQUksQ0FBQyxXQUFXLENBQUMsT0FBTyxDQUFDLElBQUksR0FBRyxNQUFNLENBQUM7U0FDMUM7YUFBTTtZQUNILElBQUksQ0FBQyxXQUFXLENBQUMsT0FBTyxDQUFDLElBQUksR0FBRyxNQUFNLENBQUM7U0FDMUM7UUFDRCxJQUFJLFFBQVEsR0FBRyxJQUFJLENBQUMsV0FBVyxDQUFDLFNBQVMsQ0FBQyxzQkFBc0IsRUFBRSxDQUFDO1FBQ25FLElBQUksQ0FBQyxXQUFXLENBQUMsU0FBUyxDQUFDLGVBQWUsQ0FBQyxRQUFRLENBQUMsQ0FBQztRQUNyRCxJQUFJLENBQUMsbUJBQW1CLENBQUMsS0FBSyxDQUFDLENBQUM7SUFDcEMsQ0FBQztJQUVELCtFQUErRTtJQUN4RSxXQUFXLENBQUMsT0FBWTtRQUMzQiw0REFBNEQ7UUFDNUQsSUFBSSxDQUFDLGVBQWUsRUFBRSxDQUFDO0lBQzNCLENBQUM7SUFFTSxjQUFjLENBQUMsTUFBeUI7UUFDM0MseUVBQXlFO1FBQ3pFLElBQUksSUFBSSxDQUFDLGFBQWEsQ0FBQyxlQUFlLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxFQUFFO1lBQ2pELElBQUksQ0FBQywyQkFBMkIsRUFBRSxDQUFDO1NBQ3RDO1FBRUQsSUFBSSxJQUFJLENBQUMsYUFBYSxFQUFFO1lBQ3BCLElBQUksV0FBVyxHQUFZLFFBQVEsQ0FBQyxhQUFhLENBQUMsR0FBRyxHQUFHLElBQUksQ0FBQyxNQUFNLEdBQUcsWUFBWSxDQUFDLENBQUM7WUFFcEYsSUFBSSxXQUFXLEtBQUssSUFBSSxFQUFFO2dCQUN0QixJQUFJLENBQUMsZ0JBQWdCLENBQUMsV0FBVyxDQUFDLENBQUM7YUFDdEM7U0FDSjtJQUNMLENBQUM7SUFFTSxZQUFZLENBQUMsT0FBaUI7UUFDakMseURBQXlEO1FBQ3pELElBQUksSUFBSSxDQUFDLGFBQWEsQ0FBQyxPQUFPLENBQUMsS0FBSyxDQUFDLElBQUksT0FBTyxJQUFJLENBQUMsTUFBTSxDQUFDLEtBQUssS0FBSyxXQUFXLElBQUksQ0FBQyxJQUFJLENBQUMsU0FBUyxFQUFFO1lBQ2xHLFFBQVEsSUFBSSxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsSUFBSSxFQUFFO2dCQUM1QixLQUFLLFdBQVc7b0JBQ1osSUFBSSxDQUFDLG1CQUFtQixDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsQ0FBQztvQkFDdkMsTUFBTTtnQkFDVixLQUFLLFFBQVE7b0JBQ1QsSUFBSSxDQUFDLHVCQUF1QixDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsQ0FBQztvQkFDM0MsTUFBTTtnQkFDVjtvQkFDSSxNQUFNO2FBQ2I7WUFFRCxJQUFJLE9BQU8sSUFBSSxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsUUFBUSxLQUFLLFdBQVcsRUFBRTtnQkFDbkQsSUFBSSxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsUUFBUSxFQUFFLENBQUM7YUFDaEM7U0FDSjtJQUNMLENBQUM7SUFFRCwrRUFBK0U7SUFDeEUsZUFBZSxDQUFDLE9BQXFCO1FBQ3hDLElBQUksV0FBVyxHQUF1QixJQUFJLGtCQUFrQixDQUFDLE9BQU8sQ0FBQyxDQUFDO1FBQ3RFLElBQUksQ0FBQyxtQkFBbUIsQ0FBcUIsUUFBUSxFQUFFLFdBQVcsQ0FBQyxDQUFDO0lBQ3hFLENBQUM7SUFFRCwrRUFBK0U7SUFDL0Usd0dBQXdHO0lBQ3hHLGVBQWU7SUFDZix3R0FBd0c7SUFDaEcsY0FBYztRQUNsQixJQUFJLE9BQU8sSUFBSSxDQUFDLE1BQU0sS0FBSyxXQUFXLEVBQUU7WUFDcEMsSUFBSSxDQUFDLGdCQUFnQixDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsUUFBUSxDQUFDLENBQUM7WUFDNUMsSUFBSSxDQUFDLGlCQUFpQixDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQztZQUNwQyxJQUFJLENBQUMsZUFBZSxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQztZQUNsQyxJQUFJLENBQUMsd0JBQXdCLEVBQUUsQ0FBQztTQUNuQztRQUVELElBQUksT0FBTyxJQUFJLENBQUMsTUFBTSxLQUFLLFdBQVcsRUFBRTtZQUNwQyxJQUFJLENBQUMsYUFBYSxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQztTQUNuQztRQUVELElBQUksT0FBTyxJQUFJLENBQUMsR0FBRyxLQUFLLFdBQVcsRUFBRTtZQUNqQyxJQUFJLENBQUMsV0FBVyxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQztTQUM5QjtJQUNMLENBQUM7SUFFTyxlQUFlO1FBQ25CLElBQUksQ0FBQyxjQUFjLEVBQUUsQ0FBQztRQUV0QixJQUFJLElBQUksQ0FBQyxhQUFhLENBQUMsaUJBQWlCLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxRQUFRLENBQUMsRUFBRTtZQUM1RCxJQUFJLENBQUMseUJBQXlCLEVBQUUsQ0FBQztTQUNwQztRQUVELElBQUksQ0FBQyxrQkFBa0IsRUFBRSxDQUFDO0lBQzlCLENBQUM7SUFFTyx5QkFBeUI7UUFDN0IsSUFBSSxDQUFDLGdCQUFnQixFQUFFLENBQUM7UUFDeEIsSUFBSSxDQUFDLDZCQUE2QixFQUFFLENBQUM7SUFDekMsQ0FBQztJQUVPLGtCQUFrQjtRQUN0QixJQUFJLENBQUMsb0JBQW9CLEVBQUUsQ0FBQztRQUM1QixJQUFJLENBQUMsVUFBVSxFQUFFLENBQUM7UUFDbEIsSUFBSSxDQUFDLGFBQWEsRUFBRSxDQUFDO0lBQ3pCLENBQUM7SUFFTyxtQkFBbUIsQ0FBQyxRQUFpQjtRQUN6QyxJQUFJLE9BQU8sSUFBSSxDQUFDLE1BQU0sQ0FBQyxTQUFTLEtBQUssV0FBVyxFQUFFO1lBQzlDLE9BQU8sQ0FBQyxLQUFLLENBQUMsd0hBQXdILENBQUMsQ0FBQztTQUMzSTthQUNJLElBQUksSUFBSSxDQUFDLE1BQU0sQ0FBQyxTQUFTLENBQUMsSUFBSSxLQUFLLFFBQVEsRUFBRTtZQUM5QyxJQUFJLElBQUksQ0FBQyxNQUFNLENBQUMsU0FBUyxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsUUFBUSxDQUFDLEVBQUUsQ0FBQyxHQUFHLENBQUMsRUFBRTtnQkFDdEQsSUFBSSxDQUFDLFdBQVcsQ0FBQyxHQUFHLENBQUMsV0FBVyxFQUFFLENBQUM7Z0JBQ25DLFFBQVEsQ0FBQyxjQUFjLENBQUMsSUFBSSxDQUFDLENBQUM7Z0JBRTlCLElBQUksQ0FBQyxNQUFNLENBQUMsU0FBUyxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsQ0FBQyxFQUFFLElBQUksQ0FBQyxNQUFNLENBQUMsU0FBUyxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsQ0FBQztnQkFDMUUsSUFBSSxDQUFDLE1BQU0sQ0FBQyxTQUFTLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxDQUFDO2dCQUVuRCxJQUFJLENBQUMsMkJBQTJCLEVBQUUsQ0FBQztnQkFDbkMsSUFBSSxDQUFDLHFCQUFxQixDQUFDLFFBQVEsQ0FBQyxDQUFDO2FBQ3hDO1NBQ0o7YUFDSTtZQUNELElBQUksU0FBUyxHQUFZLENBQUMsUUFBUSxDQUFDLFVBQVUsRUFBRSxDQUFDO1lBQ2hELFFBQVEsQ0FBQyxjQUFjLENBQUMsU0FBUyxDQUFDLENBQUM7WUFFbkMsSUFBSSxDQUFDLDJCQUEyQixFQUFFLENBQUM7WUFFbkMsSUFBSSxTQUFTLEVBQUU7Z0JBQ1gsSUFBSSxDQUFDLE1BQU0sQ0FBQyxTQUFTLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxDQUFDO2FBQ3REO2lCQUNJO2dCQUNELElBQUksQ0FBQyxNQUFNLENBQUMsU0FBUyxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxTQUFTLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDO2FBQ2hHO1lBRUQsSUFBSSxDQUFDLHFCQUFxQixDQUFDLFFBQVEsQ0FBQyxDQUFDO1NBQ3hDO0lBQ0wsQ0FBQztJQUVPLGdCQUFnQjtRQUNwQixJQUFJLE9BQU8sSUFBSSxDQUFDLE1BQU0sQ0FBQyxTQUFTLEtBQUssV0FBVyxJQUFJLE9BQU8sSUFBSSxDQUFDLE1BQU0sQ0FBQyxTQUFTLENBQUMsSUFBSSxLQUFLLFdBQVcsRUFBRTtZQUNuRyxJQUFJLENBQUMsd0JBQXdCLEVBQUUsQ0FBQztTQUNuQzthQUVJLElBQUksSUFBSSxDQUFDLGFBQWEsQ0FBQyxZQUFZLENBQUMsSUFBSSxDQUFDLE1BQU0sRUFBRSxPQUFPLENBQUMsRUFBRTtZQUM1RCxJQUFJLENBQUMscUJBQXFCLEVBQUUsQ0FBQztTQUNoQztJQUNMLENBQUM7SUFFTyx1QkFBdUIsQ0FBQyxRQUFpQjtRQUM3QyxJQUFJLE9BQU8sSUFBSSxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsT0FBTyxLQUFLLFdBQVcsRUFBRTtZQUNsRCxJQUFJLE9BQU8sSUFBSSxDQUFDLE1BQU0sQ0FBQyxNQUFNLEtBQUssV0FBVztnQkFDekMsT0FBTyxJQUFJLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxJQUFJLEtBQUssV0FBVyxFQUFFO2dCQUNoRCxJQUFJLFVBQVUsR0FBVyxFQUFFLENBQUM7Z0JBRTVCLEtBQUssSUFBSSxDQUFDLEdBQVcsQ0FBQyxFQUFFLENBQUMsR0FBRyxJQUFJLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsTUFBTSxFQUFFLEVBQUUsQ0FBQyxFQUFFO29CQUM3RCxJQUFJLFVBQVUsR0FBeUIsSUFBSSxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDO29CQUVsRSxJQUFJLFVBQVUsQ0FBQyxJQUFJLENBQUMsV0FBVyxFQUFFLEtBQUssSUFBSSxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLFdBQVcsRUFBRSxFQUFFO3dCQUMzRSxVQUFVLEdBQUcsSUFBSSxDQUFDLGFBQWEsQ0FBQyx3QkFBd0IsQ0FBQyxRQUFRLEVBQUUsVUFBVSxDQUFDLElBQUksQ0FBQyxDQUFDO3dCQUNwRixNQUFNO3FCQUNUO2lCQUNKO2dCQUVELElBQUksVUFBVSxLQUFLLEVBQUUsRUFBRTtvQkFDbkIsSUFBSSxDQUFDLE9BQU8sQ0FBQyxRQUFRLENBQUMsQ0FBQyxVQUFVLENBQUMsQ0FBQyxDQUFDO2lCQUN2QztxQkFDSTtvQkFDRCxPQUFPLENBQUMsSUFBSSxDQUFDLGtFQUFrRSxFQUFFLElBQUksQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxDQUFDO2lCQUMvRzthQUNKO2lCQUNJO2dCQUNELE9BQU8sQ0FBQyxLQUFLLENBQUMsOElBQThJLENBQUMsQ0FBQzthQUNqSztTQUVKO2FBQ0ksSUFBSSxPQUFPLElBQUksQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLElBQUksS0FBSyxXQUFXLEVBQUU7WUFDcEQsSUFBSSxDQUFDLE9BQU8sQ0FBQyxRQUFRLENBQUMsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDO1NBQ25EO2FBQ0k7WUFDRCxPQUFPLENBQUMsS0FBSyxDQUFDLGlJQUFpSSxDQUFDLENBQUM7U0FDcEo7SUFDTCxDQUFDO0lBRUQsd0dBQXdHO0lBQ3hHLHlCQUF5QjtJQUN6Qix3R0FBd0c7SUFFaEcsbUJBQW1CLENBQUMsT0FBZ0I7UUFDeEMsSUFBSSxDQUFDLGNBQWMsR0FBRyxPQUFPLENBQUM7SUFDbEMsQ0FBQztJQUVPLG9CQUFvQjtRQUN4QixJQUFJLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxhQUFhLENBQUMsVUFBVSxDQUFDLFNBQVMsSUFBSSxhQUFhLENBQUM7UUFDdEUsSUFBSSxJQUFJLENBQUMsVUFBVSxLQUFLLEtBQUssRUFBRTtZQUMzQixRQUFRLENBQUMsYUFBYSxDQUFDLE1BQU0sQ0FBQyxDQUFDLEtBQUssQ0FBQyxPQUFPLElBQUkscUNBQXFDLENBQUM7WUFDdEYsSUFBSSxZQUFZLEdBQUcsUUFBUSxDQUFDLG9CQUFvQixDQUFDLFFBQVEsQ0FBQyxDQUFDO1lBRTNELEtBQUssSUFBSSxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsR0FBRyxZQUFZLENBQUMsTUFBTSxFQUFFLENBQUMsRUFBRSxFQUFFO2dCQUMxQyxJQUFJLFlBQVksQ0FBQyxDQUFDLENBQUMsQ0FBQyxTQUFTLElBQUksc0JBQXNCLElBQUksWUFBWSxDQUFDLENBQUMsQ0FBQyxDQUFDLFNBQVMsSUFBSSxrQkFBa0IsRUFBRTtvQkFDeEcsWUFBWSxDQUFDLENBQUMsQ0FBQyxDQUFDLFNBQVMsR0FBRyxzQkFBc0IsQ0FBQztpQkFDdEQ7YUFDSjtZQUNELElBQUksQ0FBQyxjQUFjLEdBQUcsS0FBSyxDQUFDO1NBQy9CO0lBQ0wsQ0FBQztJQUVPLFVBQVU7UUFDZCxJQUFJLFdBQVcsR0FBVyxHQUFHLEdBQUcsSUFBSSxDQUFDLE1BQU0sR0FBRyxZQUFZLENBQUM7UUFDM0QsSUFBSSxXQUFXLEdBQVksSUFBSSxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsYUFBYSxDQUFDLGFBQWEsQ0FBQyxXQUFXLENBQUMsQ0FBQztRQUV0RixJQUFJLFdBQVcsS0FBSyxJQUFJLEVBQUU7WUFDdEIsSUFBSSxZQUFZLEdBQVcsUUFBUSxDQUFDLElBQUksQ0FBQyxXQUFXLENBQUM7WUFFckQsSUFBSSxZQUFZLElBQUksSUFBSSxFQUFFO2dCQUN0QixJQUFJLE9BQU8sSUFBSSxDQUFDLGFBQWEsS0FBSyxXQUFXLElBQUksQ0FBQyxJQUFJLENBQUMsYUFBYSxFQUFFO29CQUNsRSxJQUFJLENBQUMsbUJBQW1CLENBQUMsSUFBSSxDQUFDLENBQUM7b0JBQy9CLElBQUksQ0FBQyxhQUFhLEdBQUcsSUFBSSxDQUFDO29CQUMxQixJQUFJLENBQUMsZ0JBQWdCLENBQUMsV0FBVyxDQUFDLENBQUM7aUJBQ3RDO2FBQ0o7aUJBQ0ksSUFBSSxZQUFZLEdBQUcsSUFBSSxFQUFFO2dCQUMxQixJQUFJLE9BQU8sSUFBSSxDQUFDLGFBQWEsS0FBSyxXQUFXLElBQUksSUFBSSxDQUFDLGFBQWEsRUFBRTtvQkFDakUsSUFBSSxDQUFDLG1CQUFtQixDQUFDLElBQUksQ0FBQyxDQUFDO29CQUMvQixJQUFJLENBQUMsYUFBYSxHQUFHLEtBQUssQ0FBQztvQkFDM0IsSUFBSSxDQUFDLGlCQUFpQixDQUFDLFdBQVcsRUFBRSxJQUFJLENBQUMsTUFBTSxDQUFDLFVBQVUsQ0FBQyxDQUFDO2lCQUMvRDtxQkFDSTtvQkFDRCxJQUFJLENBQUMsV0FBVyxDQUFDLEdBQUcsQ0FBQyxnQkFBZ0IsRUFBRSxDQUFDO2lCQUMzQzthQUNKO1NBQ0o7SUFDTCxDQUFDO0lBRUQ7OztPQUdHO0lBQ0sscUJBQXFCO1FBQ3pCLElBQUksaUJBQWlCLEdBQVcscUJBQXFCLENBQUM7UUFDdEQsSUFBSSxZQUFZLEdBQVksSUFBSSxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsYUFBYSxDQUFDLGFBQWEsQ0FBQyxpQkFBaUIsQ0FBQyxDQUFDO1FBQzdGLElBQUksWUFBWSxLQUFLLElBQUk7WUFBRSxPQUFPO1FBRWxDLElBQUksZ0JBQWdCLEdBQVcsb0JBQW9CLENBQUM7UUFDcEQsSUFBSSxXQUFXLEdBQVksSUFBSSxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsYUFBYSxDQUFDLGFBQWEsQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDO1FBRTNGLElBQUksWUFBWSxDQUFDLFlBQVksR0FBRyxXQUFXLENBQUMsWUFBWTtZQUNwRCxXQUFXLENBQUMsU0FBUztZQUNyQixXQUFXLENBQUMsU0FBUyxDQUFDLE9BQU8sQ0FBQyxtQkFBbUIsQ0FBQyxLQUFLLENBQUMsQ0FBQyxFQUMzRDtZQUNFLFdBQVcsQ0FBQyxTQUFTLElBQUksb0JBQW9CLENBQUM7U0FDakQ7YUFBTSxJQUFJLFlBQVksQ0FBQyxZQUFZLEdBQUcsV0FBVyxDQUFDLFlBQVksRUFBRTtZQUM3RCxXQUFXLENBQUMsU0FBUyxHQUFHLFdBQVcsQ0FBQyxTQUFTLENBQUMsT0FBTyxDQUFDLHFCQUFxQixFQUFFLEVBQUUsQ0FBQyxDQUFDO1NBQ3BGO0lBQ0wsQ0FBQztJQUVPLGdCQUFnQixDQUFDLFlBQXFCO1FBQzFDLElBQUksU0FBUyxHQUFXLENBQUMsQ0FBQztRQUUxQixJQUFJLElBQUksQ0FBQyxNQUFNLENBQUMsUUFBUSxLQUFLLFVBQVUsRUFBRTtZQUNyQyxJQUFJLFdBQVcsR0FBWSxJQUFJLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxhQUFhLENBQUMsYUFBYSxDQUFDLFlBQVksQ0FBQyxDQUFDO1lBQ3ZGLElBQUksU0FBUyxHQUFZLElBQUksQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLGFBQWEsQ0FBQyxhQUFhLENBQUMsb0JBQW9CLENBQUMsQ0FBQztZQUM3RixJQUFJLGNBQWMsR0FBWSxJQUFJLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxhQUFhLENBQUMsYUFBYSxDQUFDLGtCQUFrQixDQUFDLENBQUM7WUFDaEcsU0FBUyxHQUFHLEVBQUUsQ0FBQztZQUVmLElBQUksV0FBVyxLQUFLLElBQUksRUFBRTtnQkFDdEIsU0FBUyxJQUFJLFdBQVcsQ0FBQyxZQUFZLENBQUM7YUFDekM7WUFFRCxJQUFJLFNBQVMsS0FBSyxJQUFJLEVBQUU7Z0JBQ3BCLFNBQVMsSUFBSSxTQUFTLENBQUMsWUFBWSxDQUFDO2FBQ3ZDO1lBRUQsSUFBSSxjQUFjLEtBQUssSUFBSSxFQUFFO2dCQUN6QixTQUFTLElBQUksY0FBYyxDQUFDLFlBQVksQ0FBQzthQUM1QztTQUNKO2FBQ0k7WUFDRCxTQUFTLEdBQUcsR0FBRyxDQUFDO1NBQ25CO1FBR0QsSUFBSSxDQUFDLE9BQU8sQ0FBQyxlQUFlLENBQUMsWUFBWSxFQUFFLFFBQVEsRUFBRSxTQUFTLEdBQUcsSUFBSSxDQUFDLENBQUM7UUFFdkUsS0FBSyxDQUFDLEVBQUUsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxHQUFTLEVBQUU7WUFDM0IsSUFBSSxDQUFDLFdBQVcsQ0FBQyxHQUFHLENBQUMsZ0JBQWdCLEVBQUUsQ0FBQztZQUN4QyxJQUFJLENBQUMsbUJBQW1CLENBQUMsS0FBSyxDQUFDLENBQUM7UUFDcEMsQ0FBQyxDQUFDLENBQUM7SUFDUCxDQUFDO0lBRUQ7OztPQUdHO0lBQ0ssaUJBQWlCLENBQUMsWUFBcUIsRUFBRSxhQUE4QjtRQUMzRSxJQUFJLE9BQU8sYUFBYSxLQUFLLFFBQVEsRUFBRTtZQUNuQyxJQUFJLFVBQVUsR0FBVyxHQUFHLENBQUM7WUFFN0IsSUFBSSxPQUFPLGFBQWEsS0FBSyxXQUFXLEVBQUU7Z0JBQ3RDLFVBQVUsR0FBRyxhQUFhLENBQUM7YUFDOUI7WUFFRCxJQUFJLENBQUMsT0FBTyxDQUFDLGVBQWUsQ0FBQyxZQUFZLEVBQUUsUUFBUSxFQUFFLFVBQVUsR0FBRyxJQUFJLENBQUMsQ0FBQztTQUMzRTthQUNJLElBQUksYUFBYSxLQUFLLE1BQU0sRUFBRTtZQUMvQixJQUFJLENBQUMsV0FBVyxHQUFHLElBQUksQ0FBQztTQUMzQjtRQUNELDRDQUE0QztRQUM1QyxpREFBaUQ7UUFDakQseUNBQXlDO1FBQ3pDLDRDQUE0QztRQUM1QyxJQUFJO1FBRUosS0FBSyxFQUFFLENBQUMsU0FBUyxDQUFDLEdBQVMsRUFBRTtZQUN6QixJQUFJLENBQUMsV0FBVyxDQUFDLEdBQUcsQ0FBQyxnQkFBZ0IsRUFBRSxDQUFDO1lBQ3hDLElBQUksQ0FBQyxtQkFBbUIsQ0FBQyxLQUFLLENBQUMsQ0FBQztRQUNwQyxDQUFDLENBQUMsQ0FBQztJQUNQLENBQUM7SUFFTyxhQUFhLENBQUMsTUFBYTtRQUMvQixJQUFJLGFBQWEsR0FBNkIsTUFBTSxDQUFDLE1BQU0sQ0FBQztRQUM1RCxJQUFJLFdBQVcsR0FBa0IsQ0FBQyxZQUFZLEVBQUUsc0JBQXNCLEVBQUUsaUJBQWlCLENBQUMsQ0FBQztRQUUzRixLQUFLLElBQUksQ0FBQyxHQUFXLENBQUMsRUFBRSxDQUFDLEdBQUcsV0FBVyxDQUFDLE1BQU0sRUFBRSxDQUFDLEVBQUUsRUFBRTtZQUNqRCxJQUFJLGFBQWEsQ0FBQyxTQUFTLENBQUMsUUFBUSxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFO2dCQUNsRCxPQUFPLEtBQUssQ0FBQzthQUNoQjtTQUNKO1FBRUQsT0FBTyxJQUFJLENBQUM7SUFDaEIsQ0FBQztJQUVPLGFBQWEsQ0FBQyxxQkFBOEIsS0FBSztRQUNyRCxJQUFJLElBQUksQ0FBQyxhQUFhLENBQUMsVUFBVSxDQUFDLElBQUksQ0FBQyxXQUFXLENBQUMsRUFBRTtZQUNqRCxLQUFLLENBQUMsRUFBRSxDQUFDLENBQUMsU0FBUyxDQUFDLEdBQVMsRUFBRTtnQkFDM0IsQ0FBQyxrQkFBa0IsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsc0JBQXNCLEVBQUUsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxHQUFHLENBQUMsZ0JBQWdCLEVBQUUsQ0FBQztnQkFDL0YsSUFBSSxDQUFDLGdCQUFnQixDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQztnQkFDakMsSUFBSSxDQUFDLG1CQUFtQixDQUFDLEtBQUssQ0FBQyxDQUFDO1lBQ3BDLENBQUMsQ0FBQyxDQUFDO1NBQ047SUFDTCxDQUFDO0lBRUQ7O09BRUc7SUFDSyxzQkFBc0I7UUFDMUIsSUFBSSxZQUFZLEdBQWtCLEVBQUUsQ0FBQztRQUNyQyxJQUFJLENBQUMsV0FBVyxDQUFDLFNBQVMsQ0FBQyxzQkFBc0IsRUFBRSxDQUFDLE9BQU8sQ0FBQyxDQUFDLE1BQWMsRUFBRSxFQUFFO1lBQzNFLFlBQVksQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLFFBQVEsRUFBRSxDQUFDLENBQUM7UUFDekMsQ0FBQyxDQUFDLENBQUM7UUFDSCxJQUFJLENBQUMsV0FBVyxDQUFDLFNBQVMsQ0FBQyxlQUFlLENBQUMsWUFBWSxDQUFDLENBQUM7SUFDN0QsQ0FBQztJQUVEOzs7T0FHRztJQUNJLFdBQVcsQ0FBQyxPQUFxQjtRQUNwQyxJQUFJLENBQUMsT0FBTyxJQUFJLENBQUMsT0FBTyxDQUFDLE1BQU0sRUFBRTtZQUM3QixRQUFRLENBQUMsYUFBYSxDQUFDLE1BQU0sQ0FBQyxDQUFDLEtBQUssQ0FBQyxPQUFPLEdBQUcsRUFBRSxDQUFDO1lBQ2xELE9BQU87U0FDVjtRQUNELElBQUksTUFBTSxHQUFtQixPQUFPLENBQUMsTUFBTSxDQUFDO1FBRTVDLElBQUksT0FBTyxHQUFXLEVBQUUsQ0FBQztRQUV6QixPQUFPLElBQUksSUFBSSxDQUFDLGtCQUFrQixDQUFDLE1BQU0sQ0FBQyxDQUFDO1FBRTNDLElBQUksTUFBTSxDQUFDLElBQUksRUFBRTtZQUNiLElBQUksTUFBTSxDQUFDLElBQUksQ0FBQyxZQUFZLEtBQUssSUFBSSxFQUFFO2dCQUNuQyxJQUFJLE1BQU0sQ0FBQyxJQUFJLENBQUMsR0FBRyxJQUFJLE1BQU0sQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLGVBQWUsRUFBRTtvQkFDcEQsT0FBTyxJQUFJLGdDQUFnQyxHQUFHLE1BQU0sQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLGVBQWUsR0FBRyxHQUFHLENBQUM7aUJBQ3ZGO2dCQUNELElBQUksTUFBTSxDQUFDLElBQUksQ0FBQyxJQUFJLElBQUksTUFBTSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsZUFBZSxFQUFFO29CQUN0RCxPQUFPLElBQUksaUNBQWlDLEdBQUcsTUFBTSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsZUFBZSxHQUFHLEdBQUcsQ0FBQztpQkFDekY7YUFDSjtZQUNELElBQUksTUFBTSxDQUFDLElBQUksQ0FBQyxLQUFLLEVBQUU7Z0JBQ25CLElBQUksTUFBTSxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsV0FBVyxFQUFFO29CQUMvQixPQUFPLElBQUksK0JBQStCLEdBQUcsTUFBTSxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsV0FBVyxHQUFHLEdBQUcsQ0FBQztvQkFDakYsT0FBTyxJQUFJLGlDQUFpQyxHQUFHLE1BQU0sQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLFdBQVcsR0FBRyxHQUFHLENBQUM7aUJBQ3RGO2dCQUNELElBQUksTUFBTSxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsV0FBVyxFQUFFO29CQUMvQixPQUFPLElBQUksK0JBQStCLEdBQUcsTUFBTSxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsV0FBVyxHQUFHLEdBQUcsQ0FBQztvQkFDakYsT0FBTyxJQUFJLGlDQUFpQyxHQUFHLE1BQU0sQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLFdBQVcsR0FBRyxHQUFHLENBQUM7aUJBQ3RGO2dCQUNELElBQUksTUFBTSxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsV0FBVyxFQUFFO29CQUMvQixPQUFPLElBQUksK0JBQStCLEdBQUcsTUFBTSxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsV0FBVyxHQUFHLEdBQUcsQ0FBQztvQkFDakYsT0FBTyxJQUFJLGlDQUFpQyxHQUFHLE1BQU0sQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLFdBQVcsR0FBRyxHQUFHLENBQUM7aUJBQ3RGO2FBQ0o7U0FDSjtRQUVELFFBQVEsQ0FBQyxhQUFhLENBQUMsTUFBTSxDQUFDLENBQUMsS0FBSyxDQUFDLE9BQU8sR0FBRyxPQUFPLENBQUM7SUFDM0QsQ0FBQztJQUVPLGtCQUFrQixDQUFDLE9BQXVCO1FBQzlDLElBQUksQ0FBQyxPQUFPLENBQUMsTUFBTSxJQUFJLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxLQUFLO1lBQUUsT0FBTyxFQUFFLENBQUM7UUFFeEQsSUFBSSxPQUFPLEdBQVcsRUFBRSxDQUFDO1FBQ3pCLElBQUksVUFBVSxHQUFrQjtZQUM1QixpQkFBaUI7WUFDakIsV0FBVztZQUNYLGVBQWU7WUFDZixPQUFPO1lBQ1AsWUFBWTtZQUNaLFVBQVU7WUFDVixZQUFZO1lBQ1osV0FBVztZQUNYLGdCQUFnQjtZQUNoQixpQkFBaUI7WUFDakIsaUJBQWlCO1lBQ2pCLGlCQUFpQjtZQUNqQixTQUFTO1NBQ1osQ0FBQztRQUNGLEtBQUssSUFBSSxDQUFDLEdBQVcsQ0FBQyxFQUFFLENBQUMsR0FBRyxVQUFVLENBQUMsTUFBTSxFQUFFLEVBQUUsQ0FBQyxFQUFFO1lBQ2hELElBQUksU0FBUyxHQUFXLFVBQVUsQ0FBQyxDQUFDLENBQUMsQ0FBQztZQUN0QyxJQUFJLEtBQUssR0FBVyxPQUFPLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxTQUFTLENBQUMsQ0FBQztZQUNwRCxJQUFJLFNBQVMsS0FBSyxlQUFlO2dCQUFFLEtBQUssR0FBRyxJQUFJLENBQUMsYUFBYSxDQUFDLEtBQUssQ0FBQyxDQUFDO1lBQ3JFLFNBQVMsR0FBRyxDQUFDLFNBQVMsS0FBSyxpQkFBaUIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxZQUFZLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxPQUFPLENBQUMsaUJBQWlCLEVBQUUsT0FBTyxDQUFDLENBQUMsV0FBVyxFQUFFLENBQUM7WUFDM0gsSUFBSSxPQUFPLEtBQUssS0FBSyxXQUFXLEVBQUU7Z0JBQzlCLElBQUksU0FBUyxLQUFLLGFBQWE7b0JBQzNCLENBQUMsT0FBTyxLQUFLLEtBQUssUUFBUSxJQUFJLEtBQUssQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUM7b0JBQzNELEtBQUssSUFBSSxJQUFJLENBQUM7Z0JBQ2hCLE9BQU8sSUFBSSxtQkFBbUIsR0FBRyxTQUFTLEdBQUcsSUFBSSxHQUFHLEtBQUssR0FBRyxHQUFHLENBQUM7YUFDbkU7U0FDSjtRQUNELE9BQU8sT0FBTyxDQUFDO0lBQ25CLENBQUM7SUFFRDs7O09BR0c7SUFDSyxhQUFhLENBQUMsY0FBc0I7UUFDeEMsSUFBSSxjQUFjLEtBQUssVUFBVSxJQUFJLGNBQWMsS0FBSyxRQUFRLEVBQUU7WUFDOUQsT0FBTyxVQUFVLENBQUM7U0FDckI7YUFBTSxJQUFJLGNBQWMsS0FBSyxLQUFLLEVBQUU7WUFDakMsT0FBTyxZQUFZLENBQUM7U0FDdkI7YUFBTSxFQUFFLDBCQUEwQjtZQUMvQixJQUFJLGNBQWMsS0FBSyxRQUFRLElBQUksY0FBYyxLQUFLLFNBQVMsRUFBRTtnQkFDN0QsT0FBTyxDQUFDLElBQUksQ0FBQyxxQ0FBcUMsR0FBRyxjQUFjLEdBQUcsaUZBQWlGLENBQUMsQ0FBQzthQUM1SjtZQUNELE9BQU8sUUFBUSxDQUFDO1NBQ25CO0lBQ0wsQ0FBQztJQUVELHFFQUFxRTtJQUNyRSxvSEFBb0g7SUFDcEgsaURBQWlEO0lBQ2pELGdEQUFnRDtJQUVoRCxtQ0FBbUM7SUFDbkMsd0ZBQXdGO0lBQ3hGLHdEQUF3RDtJQUN4RCxrQkFBa0I7SUFDbEIsWUFBWTtJQUVaLDBFQUEwRTtJQUMxRSxzSEFBc0g7SUFDdEgsaUZBQWlGO0lBQ2pGLCtDQUErQztJQUMvQyx1QkFBdUI7SUFDdkIsK0NBQStDO0lBQy9DLGdCQUFnQjtJQUNoQixjQUFjO0lBRWQsbUZBQW1GO0lBQ25GLHNDQUFzQztJQUN0QyxvRkFBb0Y7SUFDcEYsYUFBYTtJQUViLDREQUE0RDtJQUM1RCxRQUFRO0lBQ1IsSUFBSTtJQUVKLHdHQUF3RztJQUN4RyxrQkFBa0I7SUFDbEIsd0dBQXdHO0lBQ2hHLHVCQUF1QjtRQUMzQixJQUFJLGFBQWEsR0FBWSxJQUFJLENBQUM7UUFDbEMsSUFBSSxJQUFJLENBQUMsc0JBQXNCLEVBQUU7WUFDN0IsSUFBSSxTQUFTLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxFQUFFO2dCQUN4QixhQUFhLEdBQUcsSUFBSSxDQUFDLHNCQUFzQixLQUFLLElBQUksQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUM7YUFDcEY7U0FDSjthQUFNO1lBQ0gsSUFBSSxTQUFTLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxFQUFFO2dCQUN4QixJQUFJLENBQUMsc0JBQXNCLEdBQUcsSUFBSSxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQzthQUNsRTtTQUNKO1FBQ0QsT0FBTyxhQUFhLENBQUM7UUFFckIsU0FBUyxTQUFTLENBQUMsT0FBTztZQUN0QixPQUFPLE9BQU8sSUFBSSxPQUFPLENBQUMsS0FBSyxJQUFJLE9BQU8sQ0FBQyxLQUFLLENBQUMsU0FBUyxJQUFJLE9BQU8sQ0FBQyxLQUFLLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQTtRQUM5RixDQUFDO0lBQ0wsQ0FBQztJQUVPLHNCQUFzQjtRQUMxQixJQUFJLGNBQWMsR0FBWSxJQUFJLENBQUM7UUFDbkMsSUFBSSxJQUFJLENBQUMsTUFBTSxJQUFJLElBQUksQ0FBQyxNQUFNLENBQUMsS0FBSyxJQUFJLElBQUksQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLEtBQUssSUFBSSxJQUFJLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsV0FBVyxFQUFFO1lBQ3BHLGNBQWMsR0FBRyxJQUFJLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsV0FBVyxDQUFDLE1BQU0sS0FBSyxJQUFJLENBQUMsYUFBYSxDQUFDLFdBQVcsQ0FBQyxNQUFNLENBQUM7U0FDekc7UUFDRCxJQUFJLElBQUksQ0FBQyxNQUFNLENBQUMsUUFBUSxLQUFLLFFBQVEsSUFBSSxDQUFDLElBQUksQ0FBQyx1QkFBdUIsRUFBRSxLQUFLLEtBQUssSUFBSSxjQUFjLEtBQUssS0FBSyxDQUFDO1lBQUUsT0FBTztRQUV4SCxJQUFJLGFBQWEsR0FBWSxLQUFLLENBQUM7UUFDbkMsSUFBSSxhQUFhLEdBQVksS0FBSyxDQUFDO1FBQ25DLElBQUksSUFBSSxDQUFDLE1BQU0sQ0FBQyxLQUFLLElBQUksSUFBSSxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsU0FBUyxFQUFFO1lBQ2xELGFBQWEsR0FBRyxJQUFJLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxTQUFTLENBQUMsSUFBSSxLQUFLLE1BQU0sQ0FBQztZQUM1RCxhQUFhLEdBQUcsSUFBSSxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsU0FBUyxDQUFDLElBQUksS0FBSyxPQUFPLENBQUM7U0FDaEU7UUFDRCxJQUFJLENBQUMsY0FBYyxDQUFDLGFBQWEsQ0FBQyxDQUFDO1FBQ25DLElBQUksQ0FBQyxjQUFjLENBQUMsYUFBYSxDQUFDLENBQUM7SUFDdkMsQ0FBQztJQUVEOztPQUVHO0lBQ0ssWUFBWTtRQUNoQixJQUFJLFNBQVMsR0FBWSxJQUFJLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxhQUFhLENBQUMsYUFBYSxDQUFDLHNCQUFzQixDQUFDLENBQUM7UUFDL0YsSUFBSSxNQUFNLEdBQVksSUFBSSxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsYUFBYSxDQUFDLGFBQWEsQ0FBQyxxQ0FBcUMsQ0FBQyxDQUFDO1FBRTNHLElBQUksQ0FBQyxhQUFhLENBQUMsTUFBTSxDQUFDLHFCQUFxQixFQUFFLENBQUMsS0FBSyxHQUFHLFNBQVMsQ0FBQyxxQkFBcUIsRUFBRSxDQUFDLEtBQUssQ0FBQyxDQUFDO0lBQ3ZHLENBQUM7SUFFTyxpQkFBaUI7UUFDckIsSUFBSSxDQUFDLFdBQVcsQ0FBQyxTQUFTLENBQUMsa0JBQWtCLENBQUMsRUFBRSxDQUFDLENBQUM7UUFDbEQsSUFBSSxDQUFDLFdBQVcsQ0FBQyxTQUFTLENBQUMsZUFBZSxDQUFDLEVBQUUsQ0FBQyxDQUFDO1FBQy9DLElBQUksQ0FBQyxXQUFXLENBQUMsU0FBUyxDQUFDLGVBQWUsQ0FBQyxFQUFFLENBQUMsQ0FBQztRQUMvQyxJQUFJLENBQUMsV0FBVyxDQUFDLFNBQVMsQ0FBQyxtQkFBbUIsQ0FBQyxFQUFFLENBQUMsQ0FBQztJQUN2RCxDQUFDO0lBRUQ7Ozs7T0FJRztJQUNLLGNBQWM7UUFDbEIsMEZBQTBGO1FBQzFGLElBQUksUUFBUSxHQUFHLEdBQVEsRUFBRTtZQUNyQixJQUFJLENBQUMsYUFBYSxDQUFDLFdBQVcsR0FBRyxJQUFJLENBQUMsV0FBVyxDQUFDLFNBQVMsQ0FBQyxjQUFjLEVBQUUsQ0FBQztZQUM3RSxJQUFJLENBQUMsYUFBYSxDQUFDLFNBQVMsR0FBRyxJQUFJLENBQUMsV0FBVyxDQUFDLFNBQVMsQ0FBQyxXQUFXLEVBQUUsQ0FBQztZQUN4RSxJQUFJLENBQUMsYUFBYSxDQUFDLFVBQVUsR0FBRyxJQUFJLENBQUMsV0FBVyxDQUFDLFNBQVMsQ0FBQyxtQkFBbUIsRUFBRSxDQUFDO1lBQ2pGLE9BQU8sSUFBSSxDQUFDLGFBQWEsQ0FBQztRQUM5QixDQUFDLENBQUM7UUFDRixJQUFJLEtBQUssR0FBRyxHQUFZLEVBQUU7WUFDdEIsT0FBTyxJQUFJLENBQUMsZ0JBQWdCLEtBQUssS0FBSyxDQUFDO1FBQzNDLENBQUMsQ0FBQztRQUNGLE9BQU8sSUFBSSxDQUFDLElBQUksQ0FBQyxLQUFLLEVBQUUsUUFBUSxDQUFDLENBQUM7SUFDdEMsQ0FBQztJQUVEOzs7O09BSUc7SUFDSyxjQUFjLENBQUMsTUFBd0I7UUFDM0MsSUFBSSxPQUFPLENBQUMsTUFBTSxDQUFDLEtBQUssV0FBVyxJQUFJLENBQUMsTUFBTSxDQUFDLGNBQWMsQ0FBQyxhQUFhLENBQUM7WUFBRSxPQUFPO1FBRXJGLElBQUksUUFBUSxHQUFHLEdBQVMsRUFBRTtZQUN0QixJQUFJLENBQUMsZ0JBQWdCLEdBQUcsSUFBSSxDQUFDO1lBQzdCLElBQUksTUFBTSxDQUFDLFdBQVcsQ0FBQyxNQUFNLEtBQUssQ0FBQyxFQUFFO2dCQUNqQyxJQUFJLENBQUMsZ0JBQWdCLEdBQUcsS0FBSyxDQUFDO2dCQUM5QixJQUFJLENBQUMsWUFBWSxFQUFFLENBQUM7Z0JBQ3BCLE9BQU87YUFDVjtZQUNELElBQUksQ0FBQyxhQUFhLEdBQUcsTUFBTSxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsYUFBYSxFQUFFLE1BQU0sQ0FBQyxDQUFDO1lBQy9ELElBQUksQ0FBQyxXQUFXLENBQUMsU0FBUyxDQUFDLGNBQWMsQ0FBQyxNQUFNLENBQUMsV0FBVyxDQUFDLENBQUM7WUFDOUQsSUFBSSxDQUFDLFdBQVcsQ0FBQyxTQUFTLENBQUMsWUFBWSxDQUFDLE1BQU0sQ0FBQyxTQUFTLElBQUksS0FBSyxDQUFDLENBQUM7WUFDbkUsSUFBSSxDQUFDLFdBQVcsQ0FBQyxTQUFTLENBQUMsbUJBQW1CLENBQUMsTUFBTSxDQUFDLFVBQVUsSUFBSSxFQUFFLENBQUMsQ0FBQztZQUN4RSxJQUFJLENBQUMsZ0JBQWdCLEdBQUcsS0FBSyxDQUFDO1lBRTlCLEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FBQyxTQUFTLENBQUMsR0FBUyxFQUFFO2dCQUM1QixJQUFJLENBQUMsZ0JBQWdCLEVBQUUsQ0FBQztnQkFDeEIsSUFBSSxDQUFDLFlBQVksRUFBRSxDQUFDO1lBQ3hCLENBQUMsQ0FBQyxDQUFDO1FBQ1AsQ0FBQyxDQUFDO1FBQ0YsSUFBSSxLQUFLLEdBQUcsR0FBWSxFQUFFO1lBQ3RCLE9BQU8sSUFBSSxDQUFDLE1BQU0sSUFBSSxJQUFJLENBQUMsTUFBTSxDQUFDLE1BQU0sR0FBRyxDQUFDLENBQUM7UUFDakQsQ0FBQyxDQUFDO1FBQ0YsSUFBSSxDQUFDLElBQUksQ0FBQyxLQUFLLEVBQUUsUUFBUSxDQUFDLENBQUM7SUFDL0IsQ0FBQztJQUVEOzs7O09BSUc7SUFDSyxJQUFJLENBQUMsTUFBZ0IsRUFBRSxHQUFhLEVBQUUsYUFBYSxHQUFHLENBQUM7UUFDM0QsSUFBSSxDQUFDLE1BQU0sRUFBRSxJQUFJLElBQUksQ0FBQyxhQUFhLENBQUMsVUFBVSxDQUFDLElBQUksQ0FBQyxXQUFXLENBQUMsQ0FBQyxJQUFJLGFBQWEsS0FBSyxHQUFHLEVBQUU7WUFDeEYsSUFBSSxhQUFhLEtBQUssR0FBRztnQkFBRSxPQUFPLENBQUMsR0FBRyxDQUFDLCtCQUErQixFQUFFLEdBQUcsQ0FBQyxDQUFDO1lBQzdFLE9BQU8sR0FBRyxFQUFFLENBQUM7U0FDaEI7YUFBTTtZQUNILEtBQUssQ0FBQyxFQUFFLENBQUMsQ0FBQyxTQUFTLENBQUMsR0FBUyxFQUFFO2dCQUMzQixhQUFhLEVBQUUsQ0FBQztnQkFDaEIsSUFBSSxDQUFDLElBQUksQ0FBQyxNQUFNLEVBQUUsR0FBRyxFQUFFLGFBQWEsQ0FBQyxDQUFDO1lBQzFDLENBQUMsQ0FBQyxDQUFDO1NBQ047SUFDTCxDQUFDO0lBRU8sZ0JBQWdCLENBQUMsYUFBYTtRQUNsQyxPQUFPLENBQ0gsT0FBTyxhQUFhLENBQUMsT0FBTyxDQUFDLEtBQUssV0FBVztZQUM3QyxhQUFhLENBQUMsT0FBTyxDQUFDLEtBQUssSUFBSTtZQUMvQixPQUFPLGFBQWEsQ0FBQyxhQUFhLENBQUMsS0FBSyxXQUFXO1lBQ25ELGFBQWEsQ0FBQyxhQUFhLENBQUMsS0FBSyxJQUFJLENBQ3hDLENBQUM7SUFDTixDQUFDO0lBRUQ7Ozs7T0FJRztJQUNLLGNBQWMsQ0FBQyxRQUFpQixJQUFJO1FBQ3hDLElBQUksWUFBWSxHQUFHLEdBQVMsRUFBRTtZQUMxQixJQUFJLEtBQUssS0FBSyxJQUFJLEVBQUU7Z0JBQ2hCLElBQUksQ0FBQyxhQUFhLENBQUMsT0FBTyxDQUFDLENBQUMsU0FBUyxHQUFHLElBQUksQ0FBQyxhQUFhLENBQUMsT0FBTyxDQUFDLENBQUMsU0FBUyxDQUFDLE9BQU8sQ0FBQyxXQUFXLEVBQUUsRUFBRSxDQUFDLENBQUM7Z0JBQ3ZHLEtBQUssSUFBSSxDQUFDLEdBQVcsQ0FBQyxFQUFFLENBQUMsR0FBRyxJQUFJLENBQUMsYUFBYSxDQUFDLGFBQWEsQ0FBQyxDQUFDLE1BQU0sRUFBRSxFQUFFLENBQUMsRUFBRTtvQkFDdkUsSUFBSSxDQUFDLGFBQWEsQ0FBQyxhQUFhLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxTQUFTLEdBQUcsSUFBSSxDQUFDLGFBQWEsQ0FBQyxhQUFhLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUMsT0FBTyxDQUFDLFdBQVcsRUFBRSxFQUFFLENBQUMsQ0FBQztpQkFDNUg7Z0JBQ0QsSUFBSSxDQUFDLGNBQWMsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLEtBQUssSUFBSSxJQUFJLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUM7Z0JBQ2pHLE9BQU87YUFDVjtZQUVELElBQUksSUFBSSxDQUFDLGFBQWEsQ0FBQyxPQUFPLENBQUM7Z0JBQzNCLElBQUksQ0FBQyxhQUFhLENBQUMsT0FBTyxDQUFDLENBQUMsU0FBUztnQkFDckMsSUFBSSxDQUFDLGFBQWEsQ0FBQyxPQUFPLENBQUMsQ0FBQyxTQUFTLENBQUMsT0FBTyxDQUFDLFFBQVEsQ0FBQyxLQUFLLENBQUMsQ0FBQyxFQUNoRTtnQkFDRSxJQUFJLENBQUMsYUFBYSxDQUFDLE9BQU8sQ0FBQyxDQUFDLFNBQVMsSUFBSSxTQUFTLENBQUM7Z0JBQ25ELEtBQUssSUFBSSxDQUFDLEdBQVcsQ0FBQyxFQUFFLENBQUMsR0FBRyxJQUFJLENBQUMsYUFBYSxDQUFDLGFBQWEsQ0FBQyxDQUFDLE1BQU0sRUFBRSxFQUFFLENBQUMsRUFBRTtvQkFDdkUsSUFBSSxDQUFDLGFBQWEsQ0FBQyxhQUFhLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxTQUFTLElBQUksU0FBUyxDQUFDO2lCQUMvRDthQUNKO1lBQ0QsSUFBSSxDQUFDLGlCQUFpQixDQUFDLEtBQUssQ0FBQyxDQUFDO1lBRTlCLElBQUksQ0FBQyxjQUFjLENBQUM7Z0JBQ2hCLGFBQWEsRUFBRSxFQUFFO2dCQUNqQixXQUFXLEVBQUUsS0FBSztnQkFDbEIsWUFBWSxFQUFFLEVBQUU7YUFDbkIsQ0FBQyxDQUFDO1lBQ0gsSUFBSSxDQUFDLGlCQUFpQixFQUFFLENBQUM7UUFDN0IsQ0FBQyxDQUFDO1FBQ0YsSUFBSSxLQUFLLEdBQUcsR0FBWSxFQUFFO1lBQ3RCLHNIQUFzSDtZQUN0SCxJQUFJLElBQUksQ0FBQyxNQUFNLENBQUMsS0FBSztnQkFDakIsSUFBSSxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsU0FBUztnQkFDM0IsSUFBSSxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsU0FBUyxDQUFDLElBQUk7Z0JBQ2hDLElBQUksQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLFNBQVMsQ0FBQyxJQUFJLEtBQUssTUFBTSxFQUM3QztnQkFDRSxJQUFJLGVBQWUsR0FBWSxJQUFJLENBQUMsZ0JBQWdCLENBQUMsSUFBSSxDQUFDLGFBQWEsQ0FBQyxDQUFDO2dCQUN6RSxJQUFJLGVBQWUsS0FBSyxJQUFJO29CQUFFLE9BQU8sZUFBZSxDQUFDO2dCQUVyRCxJQUFJLFdBQVcsR0FBVyxHQUFHLEdBQUcsSUFBSSxDQUFDLE1BQU0sR0FBRyx5QkFBeUIsQ0FBQztnQkFDeEUsSUFBSSxDQUFDLGFBQWEsQ0FBQyxPQUFPLENBQUMsR0FBRyxJQUFJLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxhQUFhLENBQUMsYUFBYSxDQUFDLFdBQVcsR0FBRyx1QkFBdUIsQ0FBQyxDQUFDO2dCQUNuSCxJQUFJLENBQUMsYUFBYSxDQUFDLGFBQWEsQ0FBQyxHQUFHLElBQUksQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLGFBQWEsQ0FBQyxnQkFBZ0IsQ0FBQyxXQUFXLEdBQUcsa0JBQWtCLENBQUMsQ0FBQztnQkFDdkgsT0FBTyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsSUFBSSxDQUFDLGFBQWEsQ0FBQyxDQUFDO2FBQ3BEO2lCQUFNO2dCQUNILE9BQU8sSUFBSSxDQUFDO2FBQ2Y7UUFDTCxDQUFDLENBQUM7UUFDRixJQUFJLENBQUMsSUFBSSxDQUFDLEtBQUssRUFBRSxZQUFZLENBQUMsQ0FBQztJQUNuQyxDQUFDO0lBR0Q7OztPQUdHO0lBQ0ssY0FBYyxDQUFDLEtBQWM7UUFDakMsSUFBSSxJQUFJLENBQUMsYUFBYSxDQUFDLFVBQVUsQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFDLEVBQUU7WUFDakQsS0FBSyxDQUFDLEVBQUUsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxHQUFTLEVBQUU7Z0JBQzNCLElBQUksQ0FBQyxXQUFXLENBQUMsR0FBRyxDQUFDLGFBQWEsQ0FBQyxLQUFLLENBQUMsQ0FBQztZQUM5QyxDQUFDLENBQUMsQ0FBQztTQUNOO0lBQ0wsQ0FBQztJQUVEOzs7T0FHRztJQUNLLFlBQVksQ0FBQyxPQUFpQjtRQUNsQyxJQUFJLE9BQU8sT0FBTyxLQUFLLFdBQVcsRUFBRTtZQUNoQyxPQUFPLEdBQUcsS0FBSyxDQUFDO1lBQ2hCLElBQUksSUFBSSxDQUFDLE1BQU0sQ0FBQyxLQUFLLElBQUksSUFBSSxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsS0FBSyxJQUFJLElBQUksQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxXQUFXLEVBQUU7Z0JBQ3JGLE9BQU8sR0FBRyxJQUFJLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsV0FBVyxDQUFDO2FBQ2pEO1NBQ0o7UUFDRCxJQUFJLElBQUksQ0FBQyxhQUFhLENBQUMsVUFBVSxDQUFDLElBQUksQ0FBQyxXQUFXLENBQUMsRUFBRTtZQUNqRCxLQUFLLENBQUMsRUFBRSxDQUFDLENBQUMsU0FBUyxDQUFDLEdBQVMsRUFBRTtnQkFDM0IsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxHQUFHLENBQUMsU0FBUyxFQUFFLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxXQUFXLENBQUMsR0FBRyxDQUFDLFdBQVcsRUFBRSxDQUFDO2dCQUNsRixJQUFJLENBQUMsWUFBWSxFQUFFLENBQUM7WUFDeEIsQ0FBQyxDQUFDLENBQUM7U0FDTjtJQUNMLENBQUM7SUFFRDs7Ozs7O09BTUc7SUFDSyxpQkFBaUIsQ0FBQyxXQUFvQixLQUFLO1FBQy9DLElBQUksQ0FBQyxXQUFXLENBQUMsU0FBUyxDQUFDLFlBQVksQ0FBQyxRQUFRLENBQUMsQ0FBQztJQUN0RCxDQUFDO0lBRUQsc0JBQXNCO0lBQ3RCOzs7OztPQUtHO0lBQ0ssZ0JBQWdCLENBQUMsUUFBYztRQUNuQyxJQUFJLFFBQVEsR0FBWSxLQUFLLENBQUM7UUFDOUIsSUFBSSxDQUFDLFFBQVE7WUFBRSxRQUFRLEdBQUcsSUFBSSxDQUFDLFdBQVcsQ0FBQyxTQUFTLENBQUMsc0JBQXNCLEVBQUUsQ0FBQztRQUM5RSxRQUFRLENBQUMsT0FBTyxDQUFDLENBQUMsTUFBVyxFQUFFLEVBQUU7WUFDN0IsSUFBSSxDQUFDLFVBQVUsQ0FBQyxNQUFNLENBQUMsQ0FBQztZQUN4QixJQUFJLFNBQVMsR0FBRyxNQUFNLENBQUMsU0FBUyxFQUFFLENBQUM7WUFDbkMsSUFBSSxTQUFTLENBQUMsZ0JBQWdCLEVBQUU7Z0JBQzVCLElBQUksQ0FBQyxVQUFVLENBQUMsU0FBUyxDQUFDLGdCQUFnQixDQUFDLENBQUE7YUFDOUM7aUJBQU07Z0JBQ0gsSUFBSSxNQUFNLENBQUMsTUFBTSxFQUFFO29CQUNmLFFBQVEsR0FBRyxJQUFJLENBQUM7b0JBQ2hCLElBQUksQ0FBQyxVQUFVLENBQUMsTUFBTSxDQUFDLE1BQU0sRUFBRSxLQUFLLENBQUMsQ0FBQztvQkFDdEMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxNQUFNLEdBQUcsTUFBTSxDQUFDO29CQUM5QixNQUFNLENBQUMsTUFBTSxHQUFHLE1BQU0sQ0FBQztvQkFDdkIsU0FBUyxDQUFDLE1BQU0sR0FBRyxNQUFNLENBQUM7aUJBQzdCO2FBQ0o7UUFDTCxDQUFDLENBQUMsQ0FBQztRQUNILElBQUksUUFBUTtZQUFFLElBQUksQ0FBQyxhQUFhLENBQUMsSUFBSSxDQUFDLENBQUM7SUFDM0MsQ0FBQztJQUVPLFVBQVUsQ0FBQyxPQUFZLEVBQUUsZUFBd0IsSUFBSTtRQUN6RCxJQUFJLFlBQVksRUFBRTtZQUNkLElBQUksU0FBUyxHQUFHLE9BQU8sQ0FBQyxTQUFTLEVBQUUsQ0FBQztZQUNwQyxTQUFTLENBQUMsZUFBZSxHQUFHLElBQUksQ0FBQyx1QkFBdUIsQ0FBQztZQUN6RCxTQUFTLENBQUMsWUFBWSxHQUFHLElBQUksQ0FBQyx1QkFBdUIsQ0FBQztZQUN0RCxTQUFTLENBQUMsVUFBVSxHQUFHLElBQUksQ0FBQyx1QkFBdUIsQ0FBQztTQUN2RDtRQUNELElBQUksT0FBTyxDQUFDLFNBQVMsRUFBRTtZQUNuQixPQUFPLENBQUMsU0FBUyxDQUFDLENBQUMsSUFBSSxDQUFDLHVCQUF1QixDQUFDLENBQUM7U0FDcEQ7YUFBTTtZQUNILE9BQU8sQ0FBQyxNQUFNLEdBQUcsQ0FBQyxJQUFJLENBQUMsdUJBQXVCLENBQUM7U0FDbEQ7UUFDRCxPQUFPLENBQUMsWUFBWSxHQUFHLElBQUksQ0FBQyx1QkFBdUIsQ0FBQztRQUNwRCxPQUFPLENBQUMsVUFBVSxHQUFHLElBQUksQ0FBQyx1QkFBdUIsQ0FBQztJQUN0RCxDQUFDO0lBQ0Qsc0JBQXNCO0lBRXRCLHdHQUF3RztJQUN4Ryx1Q0FBdUM7SUFDdkMsd0dBQXdHO0lBQ2hHLGVBQWUsQ0FBQyxZQUEwQjtRQUM5QyxJQUFJLFlBQVksQ0FBQyxjQUFjLENBQUMsd0JBQXdCLENBQUM7WUFBRSxJQUFJLENBQUMsdUJBQXVCLEdBQUcsWUFBWSxDQUFDLHNCQUFzQixDQUFDO1FBQzlILElBQUksQ0FBQyxVQUFVLEdBQWtCLElBQUksQ0FBQyxPQUFPLENBQUMsb0JBQW9CLEVBQUUsQ0FBQztRQUNyRSxJQUFJLENBQUMsV0FBVyxHQUFHLElBQUksQ0FBQyxhQUFhLENBQUMsbUJBQW1CLENBQUMsWUFBWSxFQUFFLElBQUksQ0FBQyxVQUFVLENBQUMsQ0FBQztRQUN6RixJQUFJLENBQUMsV0FBVyxDQUFDLE9BQU8sQ0FBQyxRQUFRLENBQUMsR0FBRyxJQUFJLENBQUMsTUFBTSxDQUFDO1FBQ2pELElBQUksQ0FBQyxXQUFXLENBQUMsc0JBQXNCLEdBQUcsS0FBSyxDQUFDO1FBQ2hELElBQUksQ0FBQyxXQUFXLENBQUMsdUJBQXVCLEdBQUcsQ0FBQyxNQUFXLEVBQVEsRUFBRTtZQUM3RCxJQUFJLENBQUMsZ0JBQWdCLENBQUMsTUFBTSxDQUFDLE9BQU8sQ0FBQyxDQUFDO1lBQ3RDLElBQUksQ0FBQyxZQUFZLEVBQUUsQ0FBQztRQUN4QixDQUFDLENBQUE7UUFDRCxJQUFJLENBQUMsYUFBYSxDQUFDLGNBQWMsQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFDLENBQUM7SUFDeEQsQ0FBQztJQUVPLGFBQWEsQ0FBQyxhQUFrQztRQUNwRCxJQUFJLENBQUMsYUFBYSxDQUFDLFlBQVksQ0FBQyxhQUFhLEVBQUUsSUFBSSxDQUFDLE1BQU0sRUFBRSxJQUFJLENBQUMsdUJBQXVCLENBQUMsQ0FBQztRQUMxRixJQUFJLENBQUMsYUFBYSxFQUFFLENBQUM7SUFDekIsQ0FBQztJQUVPLG9CQUFvQixDQUFDLFdBQW9CLElBQUk7UUFDakQsSUFBSSxJQUFJLENBQUMsYUFBYSxDQUFDLFVBQVUsQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFDLEVBQUU7WUFDakQsSUFBSSxDQUFDLHVCQUF1QixHQUFHLFFBQVEsQ0FBQztZQUV4QyxJQUFJLENBQUMsYUFBYSxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQztZQUNoQyxJQUFJLElBQUksQ0FBQyxNQUFNLENBQUMsUUFBUSxLQUFLLFFBQVEsSUFBSSxJQUFJLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxTQUFTLENBQUMsSUFBSSxLQUFLLE9BQU8sRUFBRTtnQkFDbkYsSUFBSSxDQUFDLGNBQWMsQ0FBQyxJQUFJLENBQUMsYUFBYSxDQUFDLENBQUM7YUFDM0M7WUFFRCxJQUFJLENBQUMsWUFBWSxFQUFFLENBQUM7U0FDdkI7SUFDTCxDQUFDO0lBRU8sV0FBVyxDQUFDLFFBQW9CLEVBQUUsb0JBQTZCLElBQUk7UUFDdkUsd0ZBQXdGO1FBQ3hGLElBQUksQ0FBQyxhQUFhLENBQUMsdUJBQXVCLENBQUMsUUFBUSxFQUFFLElBQUksQ0FBQyxNQUFNLEVBQUUsSUFBSSxDQUFDLE1BQU0sRUFBRSxJQUFJLENBQUMsV0FBVyxDQUFDLENBQUM7UUFFakcsSUFBSSxpQkFBaUIsRUFBRTtZQUNuQixJQUFJLENBQUMsYUFBYSxDQUFDLFVBQVUsQ0FBQyxRQUFRLENBQUMsQ0FBQztTQUMzQztRQUVELElBQUksSUFBSSxDQUFDLGFBQWEsQ0FBQyxpQkFBaUIsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLFFBQVEsQ0FBQyxJQUFJLElBQUksQ0FBQyxhQUFhLENBQUMsVUFBVSxDQUFDLElBQUksQ0FBQyxXQUFXLENBQUMsRUFBRTtZQUMvRyxJQUFJLENBQUMseUJBQXlCLEVBQUUsQ0FBQztTQUNwQztRQUVELEtBQUssRUFBRSxDQUFDLFNBQVMsQ0FBQyxHQUFTLEVBQUU7WUFDekIsSUFBSSxDQUFDLGdCQUFnQixFQUFFLENBQUM7WUFDeEIsSUFBSSxDQUFDLHFCQUFxQixFQUFFLENBQUM7UUFDakMsQ0FBQyxDQUFDLENBQUM7SUFDUCxDQUFDO0lBRUQsd0dBQXdHO0lBQ3hHLHNDQUFzQztJQUN0Qyx3R0FBd0c7SUFDaEcsbUJBQW1CLENBQUksVUFBa0IsRUFBRSxpQkFBb0I7UUFDbkUsUUFBUSxVQUFVLEVBQUU7WUFDaEIsS0FBSyxZQUFZLENBQUM7WUFDbEIsS0FBSyxXQUFXLENBQUM7WUFDakIsS0FBSyxPQUFPLENBQUM7WUFDYixLQUFLLFFBQVE7Z0JBQ1QsSUFBSSxDQUFDLHFCQUFxQixDQUFJLGlCQUFpQixDQUFDLENBQUM7Z0JBQ2pELE1BQU07WUFDVjtnQkFDSSxPQUFPLENBQUMsS0FBSyxDQUFDLDRDQUE0QyxFQUFFLFVBQVUsQ0FBQyxDQUFDO1NBQy9FO0lBQ0wsQ0FBQztJQUVPLHFCQUFxQixDQUFJLE9BQVU7UUFDdkMsSUFBSSxDQUFDLGNBQWMsQ0FBQyxnQkFBZ0IsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLEVBQUUsRUFBRSxPQUFPLENBQUMsQ0FBQztJQUNsRSxDQUFDO0lBRU8sMkJBQTJCO1FBQy9CLElBQUksQ0FBQyxjQUFjLENBQUMsWUFBWSxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsRUFBRSxDQUFDLENBQUM7SUFDckQsQ0FBQztJQUVPLHdCQUF3QjtRQUM1QixJQUFJLENBQUMsZ0JBQWdCLENBQUMsY0FBYyxHQUFHLElBQUksQ0FBQyxjQUFjLENBQUMsa0JBQWtCLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxFQUFFLENBQUMsQ0FBQyxTQUFTLENBQUMsQ0FBQyxRQUFpQixFQUFRLEVBQUU7WUFDaEksSUFBSSxDQUFDLHFCQUFxQixDQUFDLFFBQVEsQ0FBQyxDQUFDO1FBQ3pDLENBQUMsQ0FBQyxDQUFDO1FBRUgsSUFBSSxDQUFDLGdCQUFnQixDQUFDLGVBQWUsR0FBRyxJQUFJLENBQUMsY0FBYyxDQUFDLGNBQWMsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLEVBQUUsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxDQUFDLFdBQWlDLEVBQVEsRUFBRTtZQUM3SSxJQUFJLENBQUMsb0JBQW9CLENBQUMsV0FBVyxDQUFDLENBQUM7UUFDM0MsQ0FBQyxDQUFDLENBQUM7UUFFSCxJQUFJLENBQUMsZ0JBQWdCLENBQUMsYUFBYSxHQUFHLElBQUksQ0FBQyxjQUFjLENBQUMsb0JBQW9CLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxFQUFFLENBQUMsQ0FBQyxTQUFTLENBQUMsQ0FBQyxLQUF1QyxFQUFRLEVBQUU7WUFDdkosSUFBSSxLQUFLLENBQUMsTUFBTSxLQUFLLFFBQVEsRUFBRTtnQkFDM0IsSUFBSSxNQUFNLEdBQVcsQ0FBQyxPQUFPLElBQUksQ0FBQyxNQUFNLENBQUMsUUFBUSxLQUFLLFdBQVcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDO2dCQUNqRyxJQUFJLENBQUMsc0JBQXNCLENBQUMsQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQztnQkFDckQsSUFBSSxDQUFDLHFCQUFxQixFQUFFLENBQUM7YUFDaEM7UUFDTCxDQUFDLENBQUMsQ0FBQztJQUNQLENBQUM7SUFFRCx3R0FBd0c7SUFDeEcsMENBQTBDO0lBQzFDLHdHQUF3RztJQUNoRyxxQkFBcUIsQ0FBQyxRQUFpQixFQUFFLFVBQW9CO1FBQ2pFLElBQUksV0FBVyxHQUFXLENBQUMsT0FBTyxVQUFVLEtBQUssV0FBVyxJQUFJLFVBQVUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQztRQUNoRyxJQUFJLE9BQU8sUUFBUSxLQUFLLFdBQVcsRUFBRTtZQUNqQyxXQUFXLEdBQUcsUUFBUSxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUM7U0FDbEM7UUFFRCxJQUFJLGVBQWUsR0FBZ0MsSUFBSSwyQkFBMkIsRUFBRSxDQUFDO1FBRXJGLGVBQWUsQ0FBQyxXQUFXLEdBQUcsV0FBVyxDQUFDO1FBQzFDLGVBQWUsQ0FBQyxhQUFhLEdBQUcsSUFBSSxDQUFDLGFBQWEsQ0FBQyxxQkFBcUIsQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFDLE9BQU8sRUFBRSxJQUFJLENBQUMsTUFBTSxDQUFDLFNBQVMsQ0FBQyxLQUFLLEVBQUUsSUFBSSxDQUFDLE1BQU0sQ0FBQyxTQUFTLENBQUMsU0FBUyxFQUFFLElBQUksQ0FBQyxNQUFNLENBQUMsUUFBUSxDQUFDLENBQUM7UUFDdkwsbUZBQW1GO1FBRW5GLElBQUksQ0FBQyxtQkFBbUIsQ0FBOEIsV0FBVyxFQUFFLGVBQWUsQ0FBQyxDQUFDO0lBQ3hGLENBQUM7SUFFTyx3QkFBd0I7UUFDNUIsSUFBSSxDQUFDLHFCQUFxQixDQUFDLFNBQVMsRUFBRSxJQUFJLENBQUMsQ0FBQztJQUNoRCxDQUFDO0lBRUQsd0dBQXdHO0lBQ3hHLG1CQUFtQjtJQUNuQix3R0FBd0c7SUFDaEcsb0JBQW9CLENBQUMsV0FBaUM7UUFDMUQsSUFBSSxXQUFXLEdBQTRCLElBQUksdUJBQXVCLEVBQUUsQ0FBQztRQUV6RSxXQUFXLENBQUMsS0FBSyxHQUFHLFdBQVcsQ0FBQyxLQUFLLENBQUM7UUFDdEMsV0FBVyxDQUFDLEtBQUssR0FBRyxXQUFXLENBQUMsS0FBSyxDQUFDO1FBQ3RDLFdBQVcsQ0FBQyxXQUFXLEdBQUcsV0FBVyxDQUFDLFdBQVcsQ0FBQztRQUNsRCxXQUFXLENBQUMsUUFBUSxHQUFHLFdBQVcsQ0FBQyxRQUFRLENBQUM7UUFDNUMsV0FBVyxDQUFDLEtBQUssR0FBRyxXQUFXLENBQUMsSUFBSSxDQUFDO1FBRXJDLElBQUksQ0FBQyxtQkFBbUIsQ0FBMEIsT0FBTyxFQUFFLFdBQVcsQ0FBQyxDQUFDO0lBQzVFLENBQUM7SUFFTyxxQkFBcUI7UUFDekIsSUFBSSxXQUFXLEdBQTRCLElBQUksdUJBQXVCLEVBQUUsQ0FBQztRQUN6RSxJQUFJLENBQUMsbUJBQW1CLENBQTBCLE9BQU8sRUFBRSxXQUFXLENBQUMsQ0FBQztJQUM1RSxDQUFDO0lBRU8sc0JBQXNCLENBQUMsU0FBd0I7UUFDbkQsSUFBSSxRQUFRLEdBQVcsQ0FBQyxPQUFPLElBQUksQ0FBQyxNQUFNLENBQUMsUUFBUSxLQUFLLFdBQVcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDO1FBRW5HLEtBQUssSUFBSSxDQUFDLEdBQVcsQ0FBQyxFQUFFLENBQUMsR0FBRyxTQUFTLENBQUMsTUFBTSxFQUFFLEVBQUUsQ0FBQyxFQUFFO1lBQy9DLEtBQUssSUFBSSxDQUFDLEdBQVcsQ0FBQyxFQUFFLENBQUMsR0FBRyxJQUFJLENBQUMsR0FBRyxDQUFDLE1BQU0sRUFBRSxFQUFFLENBQUMsRUFBRTtnQkFDOUMsSUFBSSxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxFQUFFLEtBQUssSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxRQUFRLEVBQUUsRUFBRTtvQkFDOUQsSUFBSSxDQUFDLEdBQUcsQ0FBQyxNQUFNLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDO29CQUN0QixNQUFNO2lCQUNUO2FBQ0o7U0FDSjtJQUNMLENBQUM7SUFFRCx3R0FBd0c7SUFDeEcsbUNBQW1DO0lBQ25DLHdHQUF3RztJQUNoRyxnQkFBZ0I7UUFDcEIsSUFBSSxJQUFJLENBQUMsYUFBYSxDQUFDLFVBQVUsQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFDLEVBQUU7WUFDakQsSUFBSSxDQUFDLFdBQVcsQ0FBQyxHQUFHLENBQUMsdUJBQXVCLENBQUMsSUFBSSxDQUFDLENBQUM7WUFDbkQsSUFBSSxDQUFDLFdBQVcsQ0FBQyxHQUFHLENBQUMsY0FBYyxDQUFDLElBQUksQ0FBQyxDQUFDO1lBQzFDLElBQUksQ0FBQyxXQUFXLENBQUMsR0FBRyxDQUFDLFlBQVksQ0FBQyxJQUFJLENBQUMsQ0FBQztZQUV4QyxJQUFJLE9BQU8sSUFBSSxDQUFDLGdCQUFnQixDQUFDLGFBQWEsS0FBSyxXQUFXLEVBQUU7Z0JBQzVELElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxhQUFhLENBQUMsV0FBVyxFQUFFLENBQUM7YUFDckQ7U0FDSjtJQUNMLENBQUM7SUFFTyw2QkFBNkI7UUFDakMsSUFBSSxVQUFVLEdBQTBCO1lBQ3BDLE9BQU8sRUFBRSxDQUFDLE9BQWlDLEVBQVEsRUFBRTtnQkFDakQsSUFBSSxDQUFDLG1CQUFtQixDQUFDLElBQUksQ0FBQyxDQUFDO2dCQUUvQixJQUFJLE9BQU8sSUFBSSxDQUFDLGdCQUFnQixDQUFDLGFBQWEsS0FBSyxXQUFXLEVBQUU7b0JBQzVELElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxhQUFhLENBQUMsV0FBVyxFQUFFLENBQUM7aUJBQ3JEO2dCQUNELElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxhQUFhLEdBQUcsSUFBSSxDQUFDLHVCQUF1QixDQUFDLE9BQU8sQ0FBQyxDQUFDLFNBQVMsQ0FBQyxDQUFDLFNBQWlDLEVBQVEsRUFBRTtvQkFDOUgsT0FBTyxDQUFDLGVBQWUsQ0FBQyxTQUFTLENBQUMsSUFBSSxFQUFFLFNBQVMsQ0FBQyxLQUFLLENBQUMsQ0FBQztvQkFDekQsSUFBSSxDQUFDLG1CQUFtQixDQUFDLEtBQUssQ0FBQyxDQUFDO2dCQUNwQyxDQUFDLENBQUMsQ0FBQztZQUNQLENBQUM7U0FDSixDQUFDO1FBRUYsSUFBSSxDQUFDLFdBQVcsQ0FBQyxHQUFHLENBQUMsdUJBQXVCLENBQUMsVUFBVSxDQUFDLENBQUM7SUFDN0QsQ0FBQztJQUVPLHVCQUF1QixDQUFDLGlCQUEyQztRQUN2RSxPQUFPLElBQUksVUFBVSxDQUF5QixDQUFDLFNBQTZDLEVBQVEsRUFBRTtZQUNsRyxRQUFRLElBQUksQ0FBQyxNQUFNLENBQUMsUUFBUSxFQUFFO2dCQUMxQixLQUFLLFVBQVUsQ0FBQztnQkFDaEIsS0FBSyxTQUFTO29CQUNhLElBQUksQ0FBQyxhQUFjLENBQUMsc0JBQXNCLENBQUMsaUJBQWlCLENBQUMsT0FBTyxFQUFFLElBQUksQ0FBQyxXQUFXLENBQUMsT0FBTyxDQUFDLEtBQUssRUFBRSxDQUFDLENBQUMsU0FBUyxDQUFDLENBQUMsU0FBaUMsRUFBUSxFQUFFO3dCQUNqTCxTQUFTLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDO3dCQUMxQixTQUFTLENBQUMsUUFBUSxFQUFFLENBQUM7b0JBQ3pCLENBQUMsQ0FBQyxDQUFDO29CQUVILE1BQU07Z0JBQ1YsS0FBSyxRQUFRO29CQUNULElBQUksWUFBWSxHQUEyQixJQUFJLHNCQUFzQixDQUFDLGlCQUFpQixDQUFDLE9BQU8sRUFBRSxTQUFTLENBQUMsQ0FBQztvQkFDNUcsSUFBSSxDQUFDLG1CQUFtQixDQUF5QixZQUFZLEVBQUUsWUFBWSxDQUFDLENBQUM7b0JBRTdFLE1BQU07Z0JBQ1Y7b0JBQ0ksT0FBTyxDQUFDLEtBQUssQ0FBQyw4Q0FBOEMsRUFBRSxJQUFJLENBQUMsTUFBTSxDQUFDLFFBQVEsQ0FBQyxDQUFDO29CQUNwRixTQUFTLENBQUMsUUFBUSxFQUFFLENBQUM7YUFDNUI7UUFDTCxDQUFDLENBQUMsQ0FBQztJQUNQLENBQUM7SUFFRCx3R0FBd0c7SUFDeEcsaUJBQWlCO0lBQ2pCLHdHQUF3RztJQUNoRyxjQUFjO1FBQ2xCLElBQUksT0FBTyxJQUFJLENBQUMsR0FBRyxLQUFLLFdBQVcsRUFBRTtZQUNqQyxJQUFJLFNBQVMsR0FBUTtnQkFDakIsaUNBQWlDO2dCQUNqQyxLQUFLLEVBQUUsSUFBSSxDQUFDLGNBQWM7Z0JBQzFCLEVBQUUsRUFBRSxJQUFJLENBQUMsTUFBTSxDQUFDLEVBQUU7Z0JBQ2xCLElBQUksRUFBRSxJQUFJLENBQUMsR0FBRztnQkFDZCxPQUFPLEVBQUUsSUFBSSxDQUFDLE1BQU07YUFDdkIsQ0FBQztZQUVGLElBQUksQ0FBQyxhQUFhLENBQUMscUJBQXFCLENBQUMsSUFBSSxDQUFDLEdBQUcsRUFBRSxTQUFTLENBQUMsQ0FBQztZQUU5RCwwQ0FBMEM7WUFDMUMsa0NBQWtDO1lBQ2xDLElBQUksQ0FBQyxHQUFHLENBQUMsT0FBTyxDQUFDLFdBQVcsR0FBRyxDQUFDLE9BQWdCLEVBQVEsRUFBRTtnQkFDdEQsSUFBSSxDQUFDLGNBQWMsR0FBRyxPQUFPLENBQUM7WUFDbEMsQ0FBQyxDQUFDO1lBRUYsSUFBSSxDQUFDLEdBQUcsQ0FBQyxPQUFPLENBQUMsVUFBVSxHQUFHLENBQUMsZ0JBQWtDLEVBQVEsRUFBRTtnQkFDdkUsSUFBSSxZQUFZLEdBQW1CLEVBQUUsQ0FBQztnQkFFdEMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxHQUFHLENBQUMsV0FBVyxDQUFDLENBQUMsUUFBaUIsRUFBUSxFQUFFO29CQUN6RCxJQUFJLE9BQU8sUUFBUSxDQUFDLEVBQUUsS0FBSyxXQUFXLElBQUksUUFBUSxDQUFDLEVBQUUsS0FBSyxnQkFBZ0IsQ0FBQyxLQUFLLEVBQUU7d0JBQzlFLFFBQVEsQ0FBQyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsS0FBSyxDQUFDLEdBQUcsZ0JBQWdCLENBQUMsSUFBSSxDQUFDO3dCQUM5RCxZQUFZLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxDQUFDO3FCQUMvQjtnQkFDTCxDQUFDLENBQUMsQ0FBQztnQkFFSCxJQUFJLGFBQWEsR0FBc0Q7b0JBQ25FLFFBQVEsRUFBRSxZQUFZO29CQUN0QixPQUFPLEVBQUUsQ0FBQyxnQkFBZ0IsQ0FBQyxLQUFLLENBQUM7aUJBQ3BDLENBQUM7Z0JBRUYsSUFBSSxDQUFDLFdBQVcsQ0FBQyxHQUFHLENBQUMsWUFBWSxDQUFDLGFBQWEsQ0FBQyxDQUFDO1lBQ3JELENBQUMsQ0FBQztZQUVGLElBQUksQ0FBQyxHQUFHLENBQUMsT0FBTyxDQUFDLFNBQVMsR0FBRyxDQUFDLFdBQW1CLEVBQVEsRUFBRTtnQkFDdkQsSUFBSSxJQUFJLENBQUMsTUFBTSxDQUFDLFFBQVEsS0FBSyxRQUFRLEVBQUU7b0JBQ25DLElBQUksQ0FBQyxXQUFXLENBQUMsR0FBRyxDQUFDLGNBQWMsQ0FBQyxXQUFXLENBQUMsQ0FBQztpQkFDcEQ7cUJBQ0k7b0JBQ0QsT0FBTyxDQUFDLElBQUksQ0FBQyxpR0FBaUcsQ0FBQyxDQUFDO2lCQUNuSDtZQUNMLENBQUMsQ0FBQztZQUVGLElBQUksQ0FBQyxHQUFHLENBQUMsT0FBTyxDQUFDLE9BQU8sR0FBRyxDQUFDLEtBQWlCLEVBQUUsbUJBQTRCLEtBQUssRUFBUSxFQUFFO2dCQUN0Rjs7Ozs7OzttQkFPRztnQkFDSCxJQUFJLE9BQU8sSUFBSSxDQUFDLE1BQU0sQ0FBQyxRQUFRLEtBQUssV0FBVyxJQUFJLElBQUksQ0FBQyxNQUFNLENBQUMsUUFBUSxLQUFLLFFBQVEsRUFBRTtvQkFDbEYsSUFBSSxNQUFNLEdBQVcsQ0FBQyxPQUFPLElBQUksQ0FBQyxNQUFNLENBQUMsUUFBUSxLQUFLLFdBQVcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDO29CQUVqRyxLQUFLLElBQUksQ0FBQyxHQUFXLENBQUMsRUFBRSxDQUFDLEdBQUcsS0FBSyxDQUFDLE1BQU0sRUFBRSxFQUFFLENBQUMsRUFBRTt3QkFDM0MsSUFBSSxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7cUJBQzNCO29CQUVELElBQUksQ0FBQyxXQUFXLENBQUMsSUFBSSxDQUFDLEdBQUcsRUFBRSxLQUFLLENBQUMsQ0FBQztvQkFDbEMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxHQUFHLENBQUMsYUFBYSxDQUFDLEVBQUUsR0FBRyxFQUFFLEtBQUssQ0FBQyxLQUFLLEVBQUUsRUFBRSxDQUFDLENBQUM7b0JBRTNELElBQUksZ0JBQWdCLEVBQUU7d0JBQ2xCLElBQUksQ0FBQyxXQUFXLENBQUMsR0FBRyxDQUFDLGtCQUFrQixDQUFDLElBQUksQ0FBQyxXQUFXLENBQUMsR0FBRyxDQUFDLFVBQVUsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsUUFBUSxFQUFFLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQztxQkFDbEg7aUJBQ0o7cUJBQ0k7b0JBQ0QsT0FBTyxDQUFDLElBQUksQ0FBQyxnRkFBZ0YsQ0FBQyxDQUFDO2lCQUNsRztZQUNMLENBQUMsQ0FBQztZQUVGLElBQUksQ0FBQyxHQUFHLENBQUMsT0FBTyxDQUFDLFVBQVUsR0FBRyxDQUFDLEdBQTZDLEVBQVEsRUFBRTtnQkFDbEYsSUFBSSxPQUFPLElBQUksQ0FBQyxNQUFNLENBQUMsUUFBUSxLQUFLLFdBQVcsSUFBSSxJQUFJLENBQUMsTUFBTSxDQUFDLFFBQVEsS0FBSyxRQUFRLEVBQUU7b0JBQ2xGLElBQUksWUFBWSxHQUFrQixFQUFFLENBQUM7b0JBRXJDLElBQUksT0FBTyxHQUFHLEtBQUssUUFBUSxJQUFJLE9BQU8sR0FBRyxLQUFLLFFBQVEsRUFBRTt3QkFDcEQsWUFBWSxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsUUFBUSxFQUFFLENBQUMsQ0FBQztxQkFDckM7eUJBQ0k7d0JBQ0QsS0FBSyxJQUFJLENBQUMsR0FBVyxDQUFDLEVBQUUsQ0FBQyxHQUFHLEdBQUcsQ0FBQyxNQUFNLEVBQUUsRUFBRSxDQUFDLEVBQUU7NEJBQ3pDLFlBQVksQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLFFBQVEsRUFBRSxDQUFDLENBQUM7eUJBQ3JDO3FCQUNKO29CQUVELElBQUksQ0FBQyxzQkFBc0IsQ0FBQyxZQUFZLENBQUMsQ0FBQztvQkFFMUMsSUFBSSxHQUFHLEdBQVcsT0FBTyxJQUFJLENBQUMsTUFBTSxDQUFDLFFBQVEsS0FBSyxXQUFXLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxRQUFRLENBQUM7b0JBQzVGLElBQUksVUFBVSxHQUFlLEVBQUUsQ0FBQztvQkFFaEMsS0FBSyxJQUFJLENBQUMsR0FBVyxDQUFDLEVBQUUsQ0FBQyxHQUFHLFlBQVksQ0FBQyxNQUFNLEVBQUUsRUFBRSxDQUFDLEVBQUU7d0JBQ2xELFVBQVUsQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDLEdBQUcsQ0FBQyxFQUFFLFlBQVksQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUM7cUJBQy9DO29CQUVEOzs7Ozs7O3VCQU9HO29CQUVILElBQUksY0FBYyxHQUFtRTt3QkFDakYsTUFBTSxFQUFFLFVBQVU7cUJBQ3JCLENBQUM7b0JBRUYsSUFBSSxDQUFDLFdBQVcsQ0FBQyxHQUFHLENBQUMsYUFBYSxDQUFDLGNBQWMsQ0FBQyxDQUFDO29CQUNuRCxJQUFJLENBQUMscUJBQXFCLEVBQUUsQ0FBQztpQkFDaEM7cUJBQ0k7b0JBQ0QsT0FBTyxDQUFDLElBQUksQ0FBQyxnRkFBZ0YsQ0FBQyxDQUFDO2lCQUNsRztZQUNMLENBQUMsQ0FBQztZQUVGLElBQUksQ0FBQyxHQUFHLENBQUMsT0FBTyxDQUFDLGlCQUFpQixHQUFHLENBQUMsV0FBbUIsRUFBRSxXQUFvQixFQUFFLEVBQUU7Z0JBQy9FLEtBQUssSUFBSSxDQUFDLEdBQVcsQ0FBQyxFQUFFLENBQUMsR0FBRyxJQUFJLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxNQUFNLEVBQUUsRUFBRSxDQUFDLEVBQUU7b0JBQ3hELElBQUksSUFBSSxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxLQUFLLFdBQVcsRUFBRTt3QkFDNUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxHQUFHLFdBQVcsQ0FBQztxQkFDaEQ7aUJBQ0o7WUFDTCxDQUFDLENBQUM7WUFFRixJQUFJLENBQUMsR0FBRyxDQUFDLE9BQU8sQ0FBQyxhQUFhLEdBQUcsQ0FBQyxPQUEwQixFQUFRLEVBQUU7Z0JBQ2xFLElBQUksYUFBYSxHQUFzQjtvQkFDbkMsUUFBUSxFQUFFLE1BQU07b0JBQ2hCLFVBQVUsRUFBRSxJQUFJO29CQUNoQixtQkFBbUIsRUFBRSxJQUFJO2lCQUM1QixDQUFDO2dCQUNGLHVEQUF1RDtnQkFDdkQsSUFBSSxPQUFPLENBQUMsY0FBYyxDQUFDLFdBQVcsQ0FBQztvQkFBRSxPQUFPLENBQUMsU0FBUyxHQUFHLE9BQU8sQ0FBQyxTQUFTLENBQUMsS0FBSyxDQUFDLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQztnQkFDNUYsSUFBSSxNQUFNLEdBQXNCLE1BQU0sQ0FBQyxNQUFNLENBQUMsRUFBRSxFQUFFLGFBQWEsRUFBRSxPQUFPLENBQUMsQ0FBQztnQkFDMUUsSUFBSSxPQUFPLEdBQVEsSUFBSSxDQUFDLFdBQVcsQ0FBQyxHQUFHLENBQUMsY0FBYyxDQUFDLE1BQU0sQ0FBQyxDQUFDO2dCQUMvRCxJQUFJLFFBQVEsR0FBUSxJQUFJLENBQUMsSUFBSSxDQUFDLE9BQU8sRUFBRSxFQUFFLElBQUksRUFBRSxRQUFRLEVBQUUsQ0FBQyxDQUFDO2dCQUMzRCxJQUFJLFdBQVcsR0FBUSxJQUFJLENBQUMsS0FBSyxDQUFDLFFBQVEsRUFBRSxFQUFFLFFBQVEsRUFBRSxNQUFNLEVBQUUsSUFBSSxFQUFFLFFBQVEsRUFBRSxDQUFDLENBQUM7Z0JBQ2xGLElBQUksVUFBVSxHQUFTLElBQUksQ0FBQyxhQUFhLENBQUMsU0FBUyxDQUFDLFdBQVcsRUFBRSxtRUFBbUUsQ0FBQyxDQUFDO2dCQUN0SSxNQUFNLENBQUMsVUFBVSxFQUFFLE1BQU0sQ0FBQyxRQUFRLEdBQUcsT0FBTyxDQUFDLENBQUM7WUFDbEQsQ0FBQyxDQUFDO1lBRUYsSUFBSSxDQUFDLEdBQUcsQ0FBQyxPQUFPLENBQUMsWUFBWSxHQUFHLENBQUMscUJBQThCLEtBQUssRUFBUSxFQUFFO2dCQUMxRSxJQUFJLENBQUMsYUFBYSxDQUFDLGtCQUFrQixDQUFDLENBQUM7WUFDM0MsQ0FBQyxDQUFDO1lBRUYsSUFBSSxDQUFDLEdBQUcsQ0FBQyxPQUFPLENBQUMsbUJBQW1CLEdBQUcsQ0FBQyxRQUFpQixFQUFRLEVBQUU7Z0JBQy9ELElBQUksQ0FBQyxvQkFBb0IsQ0FBQyxRQUFRLENBQUMsQ0FBQztZQUN4QyxDQUFDLENBQUM7WUFFRixnQ0FBZ0M7WUFDaEMsSUFBSSxPQUFPLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsS0FBSyxXQUFXO2dCQUFFLElBQUksQ0FBQyxHQUFHLENBQUMsS0FBSyxHQUFHLEVBQUUsQ0FBQztZQUNqRSxJQUFJLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxVQUFVLEdBQUcsR0FBUyxFQUFFO2dCQUNuQyxJQUFJLENBQUMsWUFBWSxFQUFFLENBQUM7WUFDeEIsQ0FBQyxDQUFDO1lBRUYsSUFBSSxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsYUFBYSxHQUFHLENBQUMsS0FBYyxFQUFRLEVBQUU7Z0JBQ3BELElBQUksQ0FBQyxjQUFjLENBQUMsS0FBSyxDQUFDLENBQUM7WUFDL0IsQ0FBQyxDQUFDO1lBRUYsSUFBSSxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsV0FBVyxHQUFHLENBQUMsT0FBZ0IsRUFBUSxFQUFFO2dCQUNwRCxJQUFJLENBQUMsWUFBWSxDQUFDLE9BQU8sQ0FBQyxDQUFDO1lBQy9CLENBQUMsQ0FBQztZQUVGLElBQUksQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLGFBQWEsR0FBRyxHQUFxQixFQUFFO2dCQUNsRCxPQUFPLElBQUksQ0FBQyxjQUFjLEVBQUUsQ0FBQztZQUNqQyxDQUFDLENBQUM7WUFFRixJQUFJLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxhQUFhLEdBQUcsQ0FBQyxNQUF3QixFQUFRLEVBQUU7Z0JBQzlELElBQUksQ0FBQyxhQUFhLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDO2dCQUNoQyxJQUFJLENBQUMsY0FBYyxDQUFDLE1BQU0sQ0FBQyxDQUFDO1lBQ2hDLENBQUMsQ0FBQztZQUVGLElBQUksQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLGdCQUFnQixHQUFHLENBQUMsUUFBaUIsRUFBUSxFQUFFO2dCQUMxRCxJQUFJLENBQUMsaUJBQWlCLENBQUMsUUFBUSxDQUFDLENBQUM7WUFDckMsQ0FBQyxDQUFDO1lBRUYsSUFBSSxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsYUFBYSxHQUFHLENBQUMsS0FBYyxFQUFRLEVBQUU7Z0JBQ3BELElBQUksQ0FBQyxjQUFjLENBQUMsS0FBSyxDQUFDLENBQUM7WUFDL0IsQ0FBQyxDQUFDO1lBRUYsZ0NBQWdDO1lBQ2hDLElBQUksQ0FBQyxHQUFHLENBQUMsV0FBVyxDQUFDLGFBQWEsR0FBRyxHQUFTLEVBQUU7Z0JBQzVDLElBQUksWUFBWSxHQUEyQixJQUFJLENBQUMsV0FBVyxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsYUFBYSxDQUFDLGtCQUFrQixFQUFFLENBQUMsQ0FBQztnQkFFN0csS0FBSyxJQUFJLElBQUksSUFBSSxZQUFZLEVBQUU7b0JBQzNCLElBQUksWUFBWSxDQUFDLGNBQWMsQ0FBQyxJQUFJLENBQUMsRUFBRTt3QkFDbkMsSUFBSSxXQUFXLEdBQVEsWUFBWSxDQUFDLElBQUksQ0FBQyxDQUFDO3dCQUUxQyxLQUFLLElBQUksUUFBUSxJQUFJLFdBQVcsRUFBRTs0QkFDOUIsSUFBSSxXQUFXLENBQUMsY0FBYyxDQUFDLFFBQVEsQ0FBQyxFQUFFO2dDQUN0QyxJQUFJLE9BQU8sV0FBVyxDQUFDLFFBQVEsQ0FBQyxDQUFDLE1BQU0sS0FBSyxXQUFXLEVBQUU7b0NBQ3JELFdBQVcsQ0FBQyxRQUFRLENBQUMsQ0FBQyxNQUFNLEdBQUcsRUFBRSxDQUFDO2lDQUNyQztnQ0FFRCxXQUFXLENBQUMsUUFBUSxDQUFDLENBQUMsTUFBTSxDQUFDLE1BQU0sR0FBRyxDQUFDLENBQUM7NkJBQzNDO3lCQUNKO3FCQUNKO2lCQUNKO1lBQ0wsQ0FBQyxDQUFDO1NBQ0w7YUFDSTtZQUNELE9BQU8sQ0FBQyxJQUFJLENBQUMseUVBQXlFLENBQUMsQ0FBQztTQUMzRjtJQUNMLENBQUM7SUFFRCx3R0FBd0c7SUFDeEcsa0JBQWtCO0lBQ2xCLHdHQUF3RztJQUNoRyxnQkFBZ0IsQ0FBQyxTQUFpQjtRQUN0QyxJQUFJLE9BQU8sU0FBUyxLQUFLLFdBQVcsSUFBSSxTQUFTLEtBQUssUUFBUSxFQUFFO1lBQzVELElBQUksQ0FBQyxhQUFhLEdBQUcsSUFBSSxnQkFBZ0IsRUFBRSxDQUFDO1NBQy9DO2FBQ0k7WUFDRCxJQUFJLENBQUMsYUFBYSxHQUFHLElBQUksb0JBQW9CLEVBQUUsQ0FBQztTQUNuRDtJQUNMLENBQUM7SUFFTyxpQkFBaUIsQ0FBQyxXQUF5QjtRQUMvQyxJQUFJLENBQUMsTUFBTSxHQUFHLElBQUksQ0FBQyxhQUFhLENBQUMsU0FBUyxDQUFDLFdBQVcsQ0FBQyxDQUFDO1FBRXhELElBQUksQ0FBQyxhQUFhLENBQUMsaUJBQWlCLENBQUMsV0FBVyxDQUFDLENBQUM7UUFDbEQsSUFBSSxDQUFDLGFBQWEsQ0FBQyx3QkFBd0IsQ0FBQyxXQUFXLENBQUMsQ0FBQztJQUM3RCxDQUFDOzs7WUFwNENKLFNBQVMsU0FBQztnQkFDUCxRQUFRLEVBQUUsVUFBVTtnQkFDcEIsMGlDQUFzQztnQkFFdEMsYUFBYSxFQUFFLGlCQUFpQixDQUFDLElBQUk7Z0JBQ3JDLFNBQVMsRUFBRSxDQUFDLFlBQVksRUFBRSxlQUFlLEVBQUUsZ0JBQWdCLEVBQUUsb0JBQW9CLENBQUM7Z0JBQ2xGLElBQUksRUFBRSxFQUFFLE9BQU8sRUFBRSxXQUFXLEVBQUU7O2FBQ2pDOzs7WUF2SUcsZ0JBQWdCO1lBSVgsTUFBTTtZQThDTixZQUFZO1lBSlosZUFBZTs7O2tCQXFIbkIsS0FBSztxQkFDTCxLQUFLO3FCQUNMLEtBQUs7a0JBQ0wsS0FBSzt3QkFHTCxLQUFLOzhCQUNMLEtBQUs7K0JBQ0wsTUFBTTswQkFDTixXQUFXLFNBQUMsaUJBQWlCOzZCQUM3QixXQUFXLFNBQUMsaUJBQWlCO3VCQWU3QixZQUFZLFNBQUMsZUFBZSxFQUFFLENBQUMsUUFBUSxDQUFDIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHtcclxuICAgIENvbXBvbmVudCxcclxuICAgIE9uSW5pdCxcclxuICAgIE9uQ2hhbmdlcyxcclxuICAgIE9uRGVzdHJveSxcclxuICAgIFNpbXBsZUNoYW5nZXMsXHJcbiAgICBWaWV3RW5jYXBzdWxhdGlvbixcclxuICAgIElucHV0LFxyXG4gICAgSG9zdEJpbmRpbmcsXHJcbiAgICBIb3N0TGlzdGVuZXIsXHJcbiAgICBWaWV3Q29udGFpbmVyUmVmLFxyXG4gICAgRXZlbnRFbWl0dGVyLFxyXG4gICAgT3V0cHV0XHJcbn0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XHJcbmltcG9ydCB7IFJvdXRlciB9IGZyb20gJ0Bhbmd1bGFyL3JvdXRlcic7XHJcbmltcG9ydCB7IE9ic2VydmFibGUsIHRpbWVyLCBTdWJzY3JpcHRpb24sIFN1YnNjcmliZXIgfSBmcm9tICdyeGpzJztcclxuaW1wb3J0IHtcclxuICAgIEdyaWRPcHRpb25zLFxyXG4gICAgUm93Tm9kZSxcclxuICAgIFJvd0V2ZW50LFxyXG4gICAgTW9kZWxVcGRhdGVkRXZlbnQsXHJcbiAgICBFeGNlbEV4cG9ydFBhcmFtcyxcclxuICAgIENvbHVtbixcclxuICAgIEdyaWRBcGksXHJcbiAgICBDb250ZXh0LFxyXG4gICAgQ29sRGVmLFxyXG4gICAgVmFsdWVTZXR0ZXJQYXJhbXMsXHJcbiAgICAvLyBDb2xEZWYsXHJcbiAgICAvLyBJRW50ZXJwcmlzZURhdGFzb3VyY2UsXHJcbiAgICAvLyBJRW50ZXJwcmlzZUdldFJvd3NQYXJhbXMsXHJcbn0gZnJvbSAnYWctZ3JpZC1jb21tdW5pdHknO1xyXG5pbXBvcnQge1xyXG4gICAgSUVudGVycHJpc2VEYXRhc291cmNlLFxyXG4gICAgSUVudGVycHJpc2VHZXRSb3dzUGFyYW1zLFxyXG59IGZyb20gJy4vZW50ZXJwcmlzZS1kYXRhc291cmNlJztcclxuaW1wb3J0ICdhZy1ncmlkLWVudGVycHJpc2UnO1xyXG5pbXBvcnQgKiBhcyBYTFNYIGZyb20gJ3hsc3gnO1xyXG5pbXBvcnQgeyBzYXZlQXMgfSBmcm9tICdmaWxlLXNhdmVyJztcclxuXHJcbmltcG9ydCB7XHJcbiAgICBJVGFibGVDb2x1bW4sXHJcbiAgICBJVGFibGVDb25maWcsXHJcbiAgICBJU3R5bGluZ0NvbmZpZyxcclxuICAgIElUYWJsZVBpdm90U3RhdGUsXHJcbiAgICBJVGFibGVCdXR0b24sXHJcbiAgICBJVGFibGVDZWxsUGFyYW1zLFxyXG4gICAgSVRhYmxlRm9ybUVtaXRQYXJhbXMsXHJcbiAgICBJVGFibGVEYXRhc291cmNlUGFyYW1zLFxyXG4gICAgSVRhYmxlQXBpLFxyXG4gICAgSVRhYmxlRHJvcGRvd25BY3Rpb24sXHJcbiAgICBLZFRhYmxlRGF0YXNvdXJjZUV2ZW50LFxyXG4gICAgS2RUYWJsZVNlbGVjdGlvblVwZGF0ZUV2ZW50LFxyXG4gICAgS2RUYWJsZUlucHV0VXBkYXRlRXZlbnQsXHJcbiAgICBLZFRhYmxlQnV0dG9uRXZlbnRcclxufSBmcm9tICcuL2tkLWFuZ3VsYXItdGFibGUtaW50ZXJmYWNlJztcclxuXHJcbmltcG9ydCB7IEtkSW50VGFibGVFdmVudCB9IGZyb20gJy4va2QtYW5ndWxhci10YWJsZS1ldmVudCc7XHJcbmltcG9ydCB7IEtkVGFibGVOb3JtYWxTdmMgfSBmcm9tICcuL3RhYmxlLXNlcnZpY2VzL2tkLXRhYmxlLW5vcm1hbC1zdmMnO1xyXG5pbXBvcnQgeyBLZFRhYmxlRW50ZXJwcmlzZVN2YyB9IGZyb20gJy4vdGFibGUtc2VydmljZXMva2QtdGFibGUtZW50ZXJwcmlzZS1zdmMnO1xyXG4vLyBpbXBvcnQgeyBLZFNwbGl0dGVyRXZlbnQgfSBmcm9tICcuLi8nO1xyXG5pbXBvcnQgeyBLZERvbUVsZW1TdmMsIEFHX0dSSURfS0VZIH0gZnJvbSAnLi4va2QtY29tbW9uL2luZGV4JztcclxuaW1wb3J0IHsgTGljZW5zZU1hbmFnZXIgfSBmcm9tIFwiYWctZ3JpZC1lbnRlcnByaXNlXCI7XHJcblxyXG5kZWNsYXJlIHZhciByZXF1aXJlOiBhbnk7XHJcblxyXG4vKipcclxuICogLS0gRG9jdW1lbnRhdGlvbiBmb3Iga2QtYW5ndWxhci10YWJsZS50cyAoa2QtdGFibGUpXHJcbiAqXHJcbiAqIC0gSG9zdExpc3RlbmVyXHJcbiAqICAgICAtIG9uUmVzaXplXHJcbiAqXHJcbiAqIC0gTGlmZSBjeWNsZXM6XHJcbiAqICAgICAtIG5nT25Jbml0XHJcbiAqICAgICAtIG5nT25DaGFuZ2VzXHJcbiAqICAgICAtIG5nT25EZXN0cm95XHJcblxyXG4gKiAtIGFnLUdyaWQgZXZlbnRzIGZ1bmN0aW9uOlxyXG4gKiAgICAgLSBvbkdyaWRSZWFkeVxyXG4gKiAgICAgLSBvbk1vZGVsVXBkYXRlZFxyXG4gKiAgICAgLSBvblJvd0NsaWNrZWRcclxuICpcclxuICogLSBrZC10YWJsZSBidXR0b24gZnVuY3Rpb246XHJcbiAqICAgICAtIG9uQnV0dG9uQ2xpY2VrZFxyXG4gKlxyXG4gKiAtIFByaXZhdGUgZnVuY3Rpb25zOlxyXG4gKiAgICAgLSBEaXNwbGF5IC8gRE9NIGZ1bmN0aW9uczpcclxuICogICAgICAgICAtIF9yZXNpemVDb2x1bW5cclxuICogICAgICAgICAtIF9zaG93TG9hZGluZ092ZXJsYXlcclxuICogICAgICAgICAtIF91cGRhdGVQYXJlbnROb2RlQ1NTXHJcbiAqICAgICAgICAgLSBfc2V0SGVpZ2h0XHJcbiAqICAgICAgICAgLSBfc2V0TW9iaWxlSGVpZ2h0IChmbGF0dGVuIHRhYmxlKVxyXG4gKiAgICAgICAgIC0gX3NldFdlYkhlaWdociAodXNlciBjb25maWd1cmF0aW9uKVxyXG4gKiAgICAgICAgIC0gX2lzQ2xpY2tWYWxpZCAoY2xpY2sgY29uZmlndXJhdGlvbilcclxuICpcclxuICogICAgIC0gR3JpZCBDeWNsZXM6XHJcbiAqICAgICAgICAgLSBfZ3JpZEluaXRDeWNsZVxyXG4gKiAgICAgICAgIC0gX2dyaWRSZWFkeUN5Y2xlXHJcbiAqICAgICAgICAgLSBfZ3JpZFJlYWR5RW50ZXJwcmlzZUN5Y2xlXHJcbiAqICAgICAgICAgLSBfZ3JpZFJlYWR5RE9NQ3ljbGVcclxuICogICAgICAgICAtIF9ncmlkU2VsZWN0aW9uQ3ljbGVcclxuICogICAgICAgICAtIF9ncmlkU2V0Um93Q3ljbGVcclxuICogICAgICAgICAtIF9ncmlkQ2xpY2tOYXZpZ2F0ZUN5Y2xlXHJcbiAqXHJcbiAqICAgICAtIENvbHVtbiAvIFJvdyAvIENvbmZpZyBnZW5lcmF0aW9ucy9wcm9jZXNzaW5nOlxyXG4gKiAgICAgICAgIC0gX3NldEdyaWRPcHRpb25zXHJcbiAqICAgICAgICAgLSBfc2V0Q29sdW1uRGVmXHJcbiAqICAgICAgICAgLSBfc2V0Um93RGF0YVxyXG4gKlxyXG4gKiAgICAgLSBFdmVudCBmdW5jdGlvbnM6XHJcbiAqICAgICAgICAgLSBfcHJvY2Vzc0V2ZW50UGFyYW1zPFQ+XHJcbiAqICAgICAgICAgLSBfYnJvYWRjYXN0RXZlbnRQYXJhbXNcclxuICogICAgICAgICAtIF9icm9hZGNhc3RNb2RlbENoYW5nZWRcclxuICogICAgICAgICAtIF9zZXR1cFN1YnNjcmlwdGlvbkV2ZW50c1xyXG4gKlxyXG4gKiAgICAgLSBTZWxlY3Rpb24gZnVuY3Rpb25zOlxyXG4gKiAgICAgICAgIC0gX3VwZGF0ZVNlbGVjdGlvbk5vZGVzXHJcbiAqICAgICAgICAgLSBfcHJvY2Vzc0luaXRpYWxTZWxlY3Rpb25cclxuICpcclxuICogICAgIC0gSW5wdXQgZnVuY3Rpb25zOlxyXG4gKiAgICAgICAgIC0gX3Byb2Nlc3NJbnB1dENoYW5nZWRcclxuICogICAgICAgICAtIF9lbWl0SW5wdXRVcGRhdGVFdmVudFxyXG4gKiAgICAgICAgIC0gX2RlbGV0ZU5vZGVGcm9tUm93RGF0YVxyXG4gKlxyXG4gKiAgICAgLSBEYXRhc291cmNlIGZ1bmN0aW9uczpcclxuICogICAgICAgICAtIF9jbGVhckRhdGFzb3VyY2VcclxuICogICAgICAgICAtIF9nZW5lcmF0ZUVudGVycHJpc2VEYXRhc291cmNlXHJcbiAqICAgICAgICAgLSBfZ2VuZXJhdGVEYXRhc291cmNlUm93c1xyXG4gKlxyXG4gKiAgICAgLSBBUEkgZ2VuZXJhdGlvbnM6XHJcbiAqICAgICAgICAgLSBfaW5pdElUYWJsZUFwaSAoVE9ETzogdXBkYXRlIGFwaSBzZXR0aW5nIGFsbCB0byB0YWJsZSBzZXJ2aWNlKVxyXG4gKlxyXG4gKiAgICAgLSBNaXNjIGZ1bmN0aW9uczpcclxuICogICAgICAgICAtIF9pbml0R3JpZFNlcnZpY2VcclxuICogICAgICAgICAtIF91cGRhdGVHcmlkQ29uZmlnXHJcbiAqL1xyXG5cclxuXHJcblxyXG5AQ29tcG9uZW50KHtcclxuICAgIHNlbGVjdG9yOiAna2QtdGFibGUnLFxyXG4gICAgdGVtcGxhdGVVcmw6ICcuL2tkLWFuZ3VsYXItdGFibGUuaHRtbCcsXHJcbiAgICBzdHlsZVVybHM6IFsnLi9rZC1hbmd1bGFyLXRhYmxlLnNjc3MnXSxcclxuICAgIGVuY2Fwc3VsYXRpb246IFZpZXdFbmNhcHN1bGF0aW9uLk5vbmUsXHJcbiAgICBwcm92aWRlcnM6IFtLZERvbUVsZW1TdmMsIEtkSW50VGFibGVFdmVudCwgS2RUYWJsZU5vcm1hbFN2YywgS2RUYWJsZUVudGVycHJpc2VTdmNdLFxyXG4gICAgaG9zdDogeyAnY2xhc3MnOiAna2R4LXRhYmxlJyB9XHJcbn0pXHJcblxyXG5leHBvcnQgY2xhc3MgS2RUYWJsZSBpbXBsZW1lbnRzIE9uSW5pdCwgT25DaGFuZ2VzLCBPbkRlc3Ryb3kge1xyXG4gICAgcHVibGljIGdyaWRJZDogc3RyaW5nID0gJyc7XHJcbiAgICBwdWJsaWMgZ3JpZE9wdGlvbnM6IEdyaWRPcHRpb25zO1xyXG4gICAgcHVibGljIGdyaWRBcGk6IEdyaWRBcGk7IFxyXG4gICAgcHVibGljIGRpc3BsYXlMb2FkaW5nOiBib29sZWFuID0gdHJ1ZTtcclxuICAgIHB1YmxpYyBfc2luZ2xlQ2xpY2tFZGl0OiBib29sZWFuID0gZmFsc2U7XHJcbiAgICBwcml2YXRlIF9lbnRlcnByaXNlID0gcmVxdWlyZSgnYWctZ3JpZC1lbnRlcnByaXNlJyk7XHJcbiAgICBwcml2YXRlIF9pc01vYmlsZVZpZXc6IGJvb2xlYW47XHJcbiAgICBwcml2YXRlIF90YWJsZVNlcnZpY2U6IEtkVGFibGVOb3JtYWxTdmMgfCBLZFRhYmxlRW50ZXJwcmlzZVN2YztcclxuICAgIHByaXZhdGUgX3N1YnNjcmlwdGlvbk9iajogeyBba2V5OiBzdHJpbmddOiBTdWJzY3JpcHRpb24gfSA9IHt9O1xyXG5cclxuICAgIHByaXZhdGUgX2N1cnJlbnRTdGF0ZTogSVRhYmxlUGl2b3RTdGF0ZSA9IHtcclxuICAgICAgICBjb2x1bW5TdGF0ZTogW10sXHJcbiAgICAgICAgcGl2b3RNb2RlOiBmYWxzZSxcclxuICAgICAgICBncm91cFN0YXRlOiBbXVxyXG4gICAgfTtcclxuICAgIHByaXZhdGUgX2lzQ2hhbmdpbmdTdGF0ZTogYm9vbGVhbiA9IGZhbHNlO1xyXG4gICAgcHJpdmF0ZSBfcGl2b3RFbGVtZW50OiB7IFtrZXk6IHN0cmluZ106IGFueSB9ID0ge1xyXG4gICAgICAgICdwaXZvdCc6IG51bGwsXHJcbiAgICAgICAgJ2NvbHVtbi1kcm9wJzogbnVsbFxyXG4gICAgfTtcclxuICAgIHByaXZhdGUgX3ByZXZpb3VzVG9vbHBhbmVsVHlwZTogJ25vbmUnIHwgJ2NvbHVtbnMnIHwgJ3Bpdm90JztcclxuICAgIHByaXZhdGUgX3N1cHByZXNzTW92YWJsZUNvbHVtbnM6IGJvb2xlYW4gPSB0cnVlO1xyXG5cclxuICAgIHByaXZhdGUgX2RpcmVjdGlvbjogJ2x0cicgfCAncnRsJyA9ICdsdHInO1xyXG5cclxuICAgIEBJbnB1dCgpIHJvdzogQXJyYXk8YW55PjtcclxuICAgIEBJbnB1dCgpIGNvbHVtbjogQXJyYXk8SVRhYmxlQ29sdW1uPjtcclxuICAgIEBJbnB1dCgpIGNvbmZpZzogSVRhYmxlQ29uZmlnO1xyXG4gICAgQElucHV0KCkgYXBpOiBJVGFibGVBcGk7XHJcbiAgICAvLyBASW5wdXQoKSBjb250ZXh0OiBDb250ZXh0O1xyXG4gICAgLy8gQElucHV0KCkgZ3JpZE9wdGlvbjogR3JpZE9wdGlvbnM7XHJcbiAgICBASW5wdXQoKSBlZGl0VGFibGU6IGJvb2xlYW47XHJcbiAgICBASW5wdXQoKSBkaXNwbGF5RWRpdGFibGU6IGJvb2xlYW47XHJcbiAgICBAT3V0cHV0KCkgb25FeHBvcnRQb3NzaWJsZTogRXZlbnRFbWl0dGVyPGJvb2xlYW4+ID0gbmV3IEV2ZW50RW1pdHRlcigpO1xyXG4gICAgQEhvc3RCaW5kaW5nKCdjbGFzcy5mdWxsLWdyaWQnKSBkaXNwbGF5RnVsbDogYm9vbGVhbjtcclxuICAgIEBIb3N0QmluZGluZygnY2xhc3Mua2R4LXRhYmxlJykgX2NsYXNzS2R4VGFibGU6IGJvb2xlYW4gPSB0cnVlO1xyXG5cclxuICAgIHB1YmxpYyBkZWZhdWx0Q29sRGVmOiBDb2xEZWY7XHJcbiAgICBwdWJsaWMgZWRpdGluZ01vZGVFbmFibGVkOiBib29sZWFuID0gZmFsc2U7XHJcbiAgICByaWdodERpcmVjdGlvbjogc3RyaW5nO1xyXG4gICAgY29uc3RydWN0b3IoXHJcbiAgICAgICAgcHJpdmF0ZSBfdmNyOiBWaWV3Q29udGFpbmVyUmVmLFxyXG4gICAgICAgIHByaXZhdGUgX3JvdXRlcjogUm91dGVyLFxyXG4gICAgICAgIHByaXZhdGUgX2RvbVN2YzogS2REb21FbGVtU3ZjLFxyXG4gICAgICAgIC8vIHByaXZhdGUgX3NwbGl0dGVyRXZlbnQ6IEtkU3BsaXR0ZXJFdmVudCxcclxuICAgICAgICBwcml2YXRlIF90YWJsZUludEV2ZW50OiBLZEludFRhYmxlRXZlbnQsXHJcbiAgICApIHtcclxuICAgICAgICBMaWNlbnNlTWFuYWdlci5zZXRMaWNlbnNlS2V5KEFHX0dSSURfS0VZLnZhbHVlKTtcclxuICAgIH1cclxuXHJcbiAgICBASG9zdExpc3RlbmVyKCd3aW5kb3c6cmVzaXplJywgWyckZXZlbnQnXSlcclxuICAgIG9uUmVzaXplKF9ldmVudDogRXZlbnQpOiB2b2lkIHtcclxuICAgICAgICB0aGlzLl9zZXRIZWlnaHQoKTtcclxuICAgIH1cclxuXHJcbiAgICAvKioqKioqKioqKioqKioqKioqKioqKioqKiBMaWZlIGN5Y2xlcyBmdW5jdGlvbnMgKioqKioqKioqKioqKioqKioqKioqKioqKioqKiovXHJcbiAgICBuZ09uSW5pdCgpOiB2b2lkIHtcclxuICAgICAgICAvLyBjb25zb2xlLmxvZyhcIi0tIEdyaWQgc3RhdGU6IEluaXQgLS1cIiwgdGhpcy5yb3csIHRoaXMuY29sdW1uLCB0aGlzLmNvbmZpZywgdGhpcy5hcGkpO1xyXG4gICAgICAgIHRoaXMuX3Nob3dMb2FkaW5nT3ZlcmxheSh0cnVlKTtcclxuICAgICAgICB0aGlzLl9ncmlkSW5pdEN5Y2xlKCk7XHJcbiAgICB9XHJcblxyXG4gICAgbmdPbkNoYW5nZXMoX3NpbXBsZUNoYW5nZXM6IFNpbXBsZUNoYW5nZXMpOiB2b2lkIHtcclxuICAgICAgICB0aGlzLl9zaG93TG9hZGluZ092ZXJsYXkodHJ1ZSk7XHJcbiAgICAgICAgY29uc29sZS5sb2coXCItLSBHcmlkIHN0YXRlOiBDaGFuZ2UgLS0gXCIsIF9zaW1wbGVDaGFuZ2VzKTtcclxuXHJcbiAgICAgICAgaWYgKHR5cGVvZiBfc2ltcGxlQ2hhbmdlcy5jb2x1bW4gIT09ICd1bmRlZmluZWQnICYmXHJcbiAgICAgICAgICAgICFfc2ltcGxlQ2hhbmdlcy5jb2x1bW4uZmlyc3RDaGFuZ2VcclxuICAgICAgICApIHtcclxuICAgICAgICAgICAgdGhpcy5fc2V0Q29sdW1uRGVmKF9zaW1wbGVDaGFuZ2VzLmNvbHVtbi5jdXJyZW50VmFsdWUpO1xyXG4gICAgICAgICAgICB0aGlzLl9zaG93TG9hZGluZ092ZXJsYXkoZmFsc2UpO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgaWYgKHR5cGVvZiBfc2ltcGxlQ2hhbmdlcy5yb3cgIT09ICd1bmRlZmluZWQnICYmXHJcbiAgICAgICAgICAgICFfc2ltcGxlQ2hhbmdlcy5yb3cuZmlyc3RDaGFuZ2VcclxuICAgICAgICApIHtcclxuICAgICAgICAgICAgdGhpcy5fc2V0Um93RGF0YShfc2ltcGxlQ2hhbmdlcy5yb3cuY3VycmVudFZhbHVlKTtcclxuICAgICAgICAgICAgdGhpcy5fc2hvd0xvYWRpbmdPdmVybGF5KGZhbHNlKTtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIGlmICh0eXBlb2YgX3NpbXBsZUNoYW5nZXMuY29uZmlnICE9PSAndW5kZWZpbmVkJykge1xyXG4gICAgICAgICAgICB0aGlzLl9zaG93TG9hZGluZ092ZXJsYXkoZmFsc2UpO1xyXG4gICAgICAgICAgICB0aGlzLnVwZGF0ZVN0eWxlKF9zaW1wbGVDaGFuZ2VzLmNvbmZpZy5jdXJyZW50VmFsdWUpO1xyXG5cclxuICAgICAgICAgICAgdGltZXIoMTAwKS5zdWJzY3JpYmUoKCk6IHZvaWQgPT4ge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5fY29uZmlndXJlUGl2b3REaXNwbGF5KCk7XHJcblxyXG4gICAgICAgICAgICAgICAgaWYgKHR5cGVvZiB0aGlzLmNvbmZpZy5zdXBwcmVzc01vdmFibGVDb2x1bW5zICE9PSAndW5kZWZpbmVkJ1xyXG4gICAgICAgICAgICAgICAgKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKHRoaXMuY29uZmlnLnN1cHByZXNzTW92YWJsZUNvbHVtbnMgIT09IHRoaXMuX3N1cHByZXNzTW92YWJsZUNvbHVtbnMpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuX2VuYWJsZUNvbHVtbk1vdmFibGUodGhpcy5jb25maWcuc3VwcHJlc3NNb3ZhYmxlQ29sdW1ucyk7XHJcbiAgICAgICAgICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuY29uZmlnLnN1cHByZXNzTW92YWJsZUNvbHVtbnMgPSB0aGlzLl9zdXBwcmVzc01vdmFibGVDb2x1bW5zO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9KTtcclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgbmdPbkRlc3Ryb3koKTogdm9pZCB7XHJcbiAgICAgICAgLy8gY29uc29sZS5sb2coXCItLSBHcmlkIHN0YXRlOiBEZXN0cm95aW5nIC0tXCIpO1xyXG4gICAgICAgIGZvciAobGV0IGl0ZW0gaW4gdGhpcy5fc3Vic2NyaXB0aW9uT2JqKSB7XHJcbiAgICAgICAgICAgIGlmICh0eXBlb2YgdGhpcy5fc3Vic2NyaXB0aW9uT2JqW2l0ZW1dICE9PSAndW5kZWZpbmVkJykge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5fc3Vic2NyaXB0aW9uT2JqW2l0ZW1dLnVuc3Vic2NyaWJlKCk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgc2V0QXR0ZW5kYW5jZShkaXNwbGF5RWRpdFRhYmxlLCBfY29uZmlnOiBJVGFibGVDb25maWcpIHtcclxuICAgICAgICAvLyBsZXQgYWxsQ29sdW1ucyA9IHRoaXMuZ3JpZE9wdGlvbnMuY29sdW1uQXBpLmdldEFsbENvbHVtbnMoKVxyXG5cclxuICAgICAgICAvLyBhbGxDb2x1bW5zLmZvckVhY2goKGNvbHVtbiwgaW5kZXgpID0+IHtcclxuICAgICAgICAvLyAgICAgbGV0IGN1cnJlbnRDb2x1bW5EZWYgPSBjb2x1bW4uZ2V0Q29sRGVmKClcclxuICAgICAgICAvLyAgICAgY29uc29sZS5sb2coYGNvbHVtbiAke2luZGV4KzF9YCwgY3VycmVudENvbHVtbkRlZilcclxuICAgICAgICAvLyB9KVxyXG4gICAgICAgIGlmIChkaXNwbGF5RWRpdFRhYmxlKSB7XHJcbiAgICAgICAgICAgIHRoaXMuZ3JpZE9wdGlvbnMuY29udGV4dC5tb2RlID0gJ2VkaXQnXHJcbiAgICAgICAgICAgIF9jb25maWcuY29udGV4dC5tb2RlID0gJ2VkaXQnO1xyXG4gICAgICAgICAgICBfY29uZmlnLnJvd0NvbnRlbnRIZWlnaHQgPSAxMjBcclxuICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICB0aGlzLmdyaWRPcHRpb25zLmNvbnRleHQubW9kZSA9ICd2aWV3J1xyXG4gICAgICAgICAgICBfY29uZmlnLmNvbnRleHQubW9kZSA9ICd2aWV3JztcclxuICAgICAgICB9XHJcbiAgICAgICAgXHJcbiAgICAgICAgbGV0IF9jb2x1bW5zID0gdGhpcy5ncmlkT3B0aW9ucy5jb2x1bW5BcGkuZ2V0QWxsRGlzcGxheWVkQ29sdW1ucygpO1xyXG4gICAgICAgIC8vIGxldCBjb2xEZWYgPSBfY29sdW1uc1syXS5nZXRDb2xEZWYoKVxyXG4gICAgICAgIC8vIGNvbnNvbGUubG9nKGNvbERlZik7XHJcbiAgICAgICAgLy8gY29sRGVmLmNlbGxSZW5kZXJlclBhcmFtcyA9ICc8cD5IZWxsbzwvcD4nXHJcbiAgICAgICAgLy8gbGV0IG5ld0RhdGEgPSBbXVxyXG4gICAgICAgIC8vIG5ld0RhdGEucHVzaChjb2xEZWYpXHJcbiAgICAgICAgdGhpcy5ncmlkT3B0aW9ucy5jb2x1bW5BcGkuc2V0VmFsdWVDb2x1bW5zKF9jb2x1bW5zKVxyXG4gICAgfVxyXG5cclxuICAgIHRvZ2dsZUVkaXRzKGRhdGEpIHtcclxuICAgICAgICBpZiAodGhpcy5lZGl0VGFibGUgJiYgIXRoaXMuZGlzcGxheUVkaXRhYmxlKSB7XHJcbiAgICAgICAgICAgIHRoaXMuZWRpdGluZ01vZGVFbmFibGVkID0gIXRoaXMuZWRpdGluZ01vZGVFbmFibGVkO1xyXG4gICAgICAgICAgICB0aGlzLl9zaW5nbGVDbGlja0VkaXQgPSAhdGhpcy5fc2luZ2xlQ2xpY2tFZGl0O1xyXG4gICAgICAgICAgICBsZXQgX2NvbHVtbnMgPSB0aGlzLmdyaWRPcHRpb25zLmNvbHVtbkFwaS5nZXRBbGxEaXNwbGF5ZWRDb2x1bW5zKCk7XHJcbiAgICAgICAgICAgIGxldCBuZXdDb2x1bW5EYXRhID0gW107XHJcbiAgICAgICAgICAgIF9jb2x1bW5zLmZvckVhY2goKGNvbHVtbjogYW55KSA9PiB7XHJcbiAgICAgICAgICAgICAgICBsZXQgY29sdW1uRGVmID0gY29sdW1uPy5nZXRDb2xEZWYoKTtcclxuICAgICAgICAgICAgICAgIGlmIChjb2x1bW5EZWYuY2FuRWRpdCA9PSB0cnVlKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgY29sdW1uRGVmLmNlbGxTdHlsZSA9IGZ1bmN0aW9uIChwYXJhbXM6IGFueSkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAoIWlzTmFOKHBhcnNlRmxvYXQocGFyYW1zLnZhbHVlKSkgJiYgcGFyc2VGbG9hdChwYXJhbXMudmFsdWUpIDwgNTApIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiB7IGNvbG9yOiAnI0NDNUM1QycgfTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiB7IGNvbG9yOiAnIzMzMycgfTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbHVtbkRlZi5jZWxsQ2xhc3NSdWxlcyA9IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICdvZS1jZWxsLWhpZ2hsaWdodCc6IGZ1bmN0aW9uIChwYXJhbXMpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gMTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAnb2UtY2VsbC1lcnJvcic6IGZ1bmN0aW9uIChwYXJhbXMpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyByZXR1cm4gcGFyYW1zLmRhdGEuc2F2ZV9lcnJvcltwYXJhbXMuY29sRGVmLmZpZWxkXTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgY29sdW1uRGVmLmNlbGxSZW5kZXJlclBhcmFtcyA9IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNob3VsZEJlRWRpdGluZzogKCkgPT4gdGhpcy5lZGl0aW5nTW9kZUVuYWJsZWQsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbHVtbkRlZi5lZGl0YWJsZSA9IChwYXJhbXM6IGFueSkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFyIG5hbWUgPSBwYXJhbXMubm9kZS5kYXRhLm5hbWU7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBwYXJhbXMuZGF0YS5uYW1lID0gcGFyYW1zLm5vZGUuZGF0YS5uYW1lO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIG5hbWU7XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBjb2x1bW5EZWYubmV3VmFsdWVIYW5kbGVyID0gKHBhcmFtczogYW55KSA9PiB7XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKGRhdGEgPT0gJ3RleHQnKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbGV0IHZhbHVlQXNGbG9hdCA9IHBhcmFtcy5uZXdWYWx1ZTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBwYXJhbXMuZGF0YVtwYXJhbXMuY29sRGVmLmZpZWxkXSA9IHZhbHVlQXNGbG9hdDtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbGV0IHZhbHVlQXNGbG9hdCA9IHBhcnNlRmxvYXQocGFyYW1zLm5ld1ZhbHVlKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBwYXJhbXMuZGF0YVtwYXJhbXMuY29sRGVmLmZpZWxkXSA9IHZhbHVlQXNGbG9hdDtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKHBhcmFtcy5kYXRhW3BhcmFtcy5jb2xEZWYuZmllbGRdLCBcInBhcmFtcy5kYXRhW3BhcmFtcy5jb2xEZWYuZmllbGRdXCIpO1xyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIHJldHVybiB0cnVlO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICBuZXdDb2x1bW5EYXRhLnB1c2goY29sdW1uRGVmKTtcclxuICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgIHRoaXMuZ3JpZE9wdGlvbnMuY29sdW1uQXBpLnNldFZhbHVlQ29sdW1ucyhuZXdDb2x1bW5EYXRhKTtcclxuICAgICAgICB9IGVsc2UgaWYgKHRoaXMuZGlzcGxheUVkaXRhYmxlKSB7XHJcbiAgICAgICAgICAgIHRoaXMuZWRpdGluZ01vZGVFbmFibGVkID0gIXRoaXMuZWRpdGluZ01vZGVFbmFibGVkO1xyXG4gICAgICAgICAgICB0aGlzLl9zaW5nbGVDbGlja0VkaXQgPSAhdGhpcy5fc2luZ2xlQ2xpY2tFZGl0O1xyXG4gICAgICAgICAgICBsZXQgX2NvbHVtbnMgPSB0aGlzLmdyaWRPcHRpb25zLmNvbHVtbkFwaS5nZXRBbGxEaXNwbGF5ZWRDb2x1bW5zKCk7XHJcbiAgICAgICAgICAgIGxldCBuZXdDb2x1bW5EYXRhID0gW107XHJcbiAgICAgICAgICAgIF9jb2x1bW5zLmZvckVhY2goKGNvbHVtbjogYW55KSA9PiB7XHJcbiAgICAgICAgICAgICAgICBsZXQgY29sdW1uRGVmID0gY29sdW1uPy5nZXRDb2xEZWYoKTtcclxuICAgICAgICAgICAgICAgIGlmIChjb2x1bW5EZWYuY2FuRWRpdCA9PSB0cnVlKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgY29sdW1uRGVmLnZhbHVlR2V0dGVyID0gZnVuY3Rpb24gKHBhcmFtcykge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB2YXIgdmFsdWUgPSBwYXJhbXMuZGF0YVtwYXJhbXMuY29sRGVmLmZpZWxkXTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgaWYgKGRhdGEgPT0gJ3RleHQnKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gdmFsdWU7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAoIWlzTmFOKHBhcnNlRmxvYXQodmFsdWUpKSkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiB2YWx1ZTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuICcnO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgY29sdW1uRGVmLmNlbGxDbGFzc1J1bGVzID0ge30sXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbHVtbkRlZi5jZWxsUmVuZGVyZXJQYXJhbXMgPSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBzaG91bGRCZUVkaXRpbmc6ICgpID0+IHRoaXMuZWRpdGluZ01vZGVFbmFibGVkLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBjb2x1bW5EZWYuZWRpdGFibGUgPSAocGFyYW1zOiBhbnkpID0+IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiBmYWxzZTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgbmV3Q29sdW1uRGF0YS5wdXNoKGNvbHVtbkRlZik7XHJcbiAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICB0aGlzLmdyaWRPcHRpb25zLmNvbHVtbkFwaS5zZXRWYWx1ZUNvbHVtbnMobmV3Q29sdW1uRGF0YSk7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIHNldEF0dGVuZGFuY2VTdGFmZihkaXNwbGF5RWRpdFRhYmxlKSB7XHJcbiAgICAgICAgaWYgKGRpc3BsYXlFZGl0VGFibGUpIHtcclxuICAgICAgICAgICAgdGhpcy5ncmlkT3B0aW9ucy5jb250ZXh0LmFjdGlvbiA9ICdlZGl0JztcclxuICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICB0aGlzLmdyaWRPcHRpb25zLmNvbnRleHQuYWN0aW9uID0gJ3ZpZXcnO1xyXG4gICAgICAgIH1cclxuICAgICAgICBsZXQgX2NvbHVtbnMgPSB0aGlzLmdyaWRPcHRpb25zLmNvbHVtbkFwaS5nZXRBbGxEaXNwbGF5ZWRDb2x1bW5zKCk7XHJcbiAgICAgICAgdGhpcy5ncmlkT3B0aW9ucy5jb2x1bW5BcGkuc2V0VmFsdWVDb2x1bW5zKF9jb2x1bW5zKTtcclxuICAgICAgICB0aGlzLl9zaG93TG9hZGluZ092ZXJsYXkoZmFsc2UpO1xyXG4gICAgfVxyXG5cclxuICAgIHNldFN0dWRlbnRNZWFsKGRpc3BsYXlFZGl0VGFibGUpIHtcclxuICAgICAgICBpZiAoZGlzcGxheUVkaXRUYWJsZSkge1xyXG4gICAgICAgICAgICB0aGlzLmdyaWRPcHRpb25zLmNvbnRleHQubW9kZSA9ICdlZGl0JztcclxuICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICB0aGlzLmdyaWRPcHRpb25zLmNvbnRleHQubW9kZSA9ICd2aWV3JztcclxuICAgICAgICB9XHJcbiAgICAgICAgbGV0IF9jb2x1bW5zID0gdGhpcy5ncmlkT3B0aW9ucy5jb2x1bW5BcGkuZ2V0QWxsRGlzcGxheWVkQ29sdW1ucygpO1xyXG4gICAgICAgIHRoaXMuZ3JpZE9wdGlvbnMuY29sdW1uQXBpLnNldFZhbHVlQ29sdW1ucyhfY29sdW1ucyk7XHJcbiAgICAgICAgdGhpcy5fc2hvd0xvYWRpbmdPdmVybGF5KGZhbHNlKTtcclxuICAgIH1cclxuXHJcbiAgICAvKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKiBHcmlkIGV2ZW50cyAqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKiovXHJcbiAgICBwdWJsaWMgb25HcmlkUmVhZHkoX3BhcmFtczogYW55KTogdm9pZCB7XHJcbiAgICAgICAgLy8gY29uc29sZS5sb2coJy0tIEdyaWQgc3RhdGU6IFJlYWR5IC0tJywgdGhpcy5ncmlkT3B0aW9ucyk7XHJcbiAgICAgICAgdGhpcy5fZ3JpZFJlYWR5Q3ljbGUoKTtcclxuICAgIH1cclxuXHJcbiAgICBwdWJsaWMgb25Nb2RlbFVwZGF0ZWQoX2V2ZW50OiBNb2RlbFVwZGF0ZWRFdmVudCk6IHZvaWQge1xyXG4gICAgICAgIC8vLyBGb3Igc2VsZWN0IGFsbCBjaGVja2JveCBjaGVja2luZyBvbiBjaGFuZ2UgcGFnaW5hdGlvbi91cGRhdGUgcm93IGRhdGFcclxuICAgICAgICBpZiAodGhpcy5fdGFibGVTZXJ2aWNlLmhhc1NlbGVjdGlvbkFsbCh0aGlzLmNvbmZpZykpIHtcclxuICAgICAgICAgICAgdGhpcy5fYnJvYWRjYXN0TW9kZWxDaGFuZ2VkRXZlbnQoKTtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIGlmICh0aGlzLl9pc01vYmlsZVZpZXcpIHtcclxuICAgICAgICAgICAgbGV0IGdyaWRFbGVtZW50OiBFbGVtZW50ID0gZG9jdW1lbnQucXVlcnlTZWxlY3RvcignIycgKyB0aGlzLmdyaWRJZCArICcuc3RnLXRoZW1lJyk7XHJcblxyXG4gICAgICAgICAgICBpZiAoZ3JpZEVsZW1lbnQgIT09IG51bGwpIHtcclxuICAgICAgICAgICAgICAgIHRoaXMuX3NldE1vYmlsZUhlaWdodChncmlkRWxlbWVudCk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgcHVibGljIG9uUm93Q2xpY2tlZChfcGFyYW1zOiBSb3dFdmVudCk6IHZvaWQge1xyXG4gICAgICAgIC8vIGNvbnNvbGUubG9nKFwiLS0gR3JpZCBzdGF0ZTogUm93IGNsaWNrZWQgLS1cIiwgX3BhcmFtcyk7XHJcbiAgICAgICAgaWYgKHRoaXMuX2lzQ2xpY2tWYWxpZChfcGFyYW1zLmV2ZW50KSAmJiB0eXBlb2YgdGhpcy5jb25maWcuY2xpY2sgIT09ICd1bmRlZmluZWQnICYmICF0aGlzLmVkaXRUYWJsZSkge1xyXG4gICAgICAgICAgICBzd2l0Y2ggKHRoaXMuY29uZmlnLmNsaWNrLnR5cGUpIHtcclxuICAgICAgICAgICAgICAgIGNhc2UgJ3NlbGVjdGlvbic6XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5fZ3JpZFNlbGVjdGlvbkN5Y2xlKF9wYXJhbXMubm9kZSk7XHJcbiAgICAgICAgICAgICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgICAgICAgICBjYXNlICdyb3V0ZXInOlxyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuX2dyaWRDbGlja05hdmlnYXRlQ3ljbGUoX3BhcmFtcy5ub2RlKTtcclxuICAgICAgICAgICAgICAgICAgICBicmVhaztcclxuICAgICAgICAgICAgICAgIGRlZmF1bHQ6XHJcbiAgICAgICAgICAgICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgIGlmICh0eXBlb2YgdGhpcy5jb25maWcuY2xpY2suY2FsbGJhY2sgIT09ICd1bmRlZmluZWQnKSB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLmNvbmZpZy5jbGljay5jYWxsYmFjaygpO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIC8qKioqKioqKioqKioqKioqKioqKioqKioqKioqKiBCdXR0b24gZnVuY3Rpb25zICoqKioqKioqKioqKioqKioqKioqKioqKioqKioqKi9cclxuICAgIHB1YmxpYyBvbkJ1dHRvbkNsaWNrZWQoX2J1dHRvbjogSVRhYmxlQnV0dG9uKTogdm9pZCB7XHJcbiAgICAgICAgbGV0IGJ1dHRvbkV2ZW50OiBLZFRhYmxlQnV0dG9uRXZlbnQgPSBuZXcgS2RUYWJsZUJ1dHRvbkV2ZW50KF9idXR0b24pO1xyXG4gICAgICAgIHRoaXMuX3Byb2Nlc3NFdmVudFBhcmFtczxLZFRhYmxlQnV0dG9uRXZlbnQ+KCdidXR0b24nLCBidXR0b25FdmVudCk7XHJcbiAgICB9XHJcblxyXG4gICAgLyoqKioqKioqKioqKioqKioqKioqKioqKioqKiogUHJpdmF0ZSBmdW5jdGlvbnMgKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqL1xyXG4gICAgLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy9cclxuICAgIC8vLyBHcmlkIGN5Y2xlc1xyXG4gICAgLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy9cclxuICAgIHByaXZhdGUgX2dyaWRJbml0Q3ljbGUoKTogdm9pZCB7XHJcbiAgICAgICAgaWYgKHR5cGVvZiB0aGlzLmNvbmZpZyAhPT0gJ3VuZGVmaW5lZCcpIHtcclxuICAgICAgICAgICAgdGhpcy5faW5pdEdyaWRTZXJ2aWNlKHRoaXMuY29uZmlnLmxvYWRUeXBlKTtcclxuICAgICAgICAgICAgdGhpcy5fdXBkYXRlR3JpZENvbmZpZyh0aGlzLmNvbmZpZyk7XHJcbiAgICAgICAgICAgIHRoaXMuX3NldEdyaWRPcHRpb25zKHRoaXMuY29uZmlnKTtcclxuICAgICAgICAgICAgdGhpcy5fc2V0dXBTdWJzY3JpcHRpb25FdmVudHMoKTtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIGlmICh0eXBlb2YgdGhpcy5jb2x1bW4gIT09ICd1bmRlZmluZWQnKSB7XHJcbiAgICAgICAgICAgIHRoaXMuX3NldENvbHVtbkRlZih0aGlzLmNvbHVtbik7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICBpZiAodHlwZW9mIHRoaXMucm93ICE9PSAndW5kZWZpbmVkJykge1xyXG4gICAgICAgICAgICB0aGlzLl9zZXRSb3dEYXRhKHRoaXMucm93KTtcclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfZ3JpZFJlYWR5Q3ljbGUoKTogdm9pZCB7XHJcbiAgICAgICAgdGhpcy5faW5pdElUYWJsZUFwaSgpO1xyXG5cclxuICAgICAgICBpZiAodGhpcy5fdGFibGVTZXJ2aWNlLmlzRW50ZXJwcmlzZU1vZGVsKHRoaXMuY29uZmlnLmxvYWRUeXBlKSkge1xyXG4gICAgICAgICAgICB0aGlzLl9ncmlkUmVhZHlFbnRlcnByaXNlQ3ljbGUoKTtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIHRoaXMuX2dyaWRSZWFkeURPTUN5Y2xlKCk7XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfZ3JpZFJlYWR5RW50ZXJwcmlzZUN5Y2xlKCk6IHZvaWQge1xyXG4gICAgICAgIHRoaXMuX2NsZWFyRGF0YXNvdXJjZSgpO1xyXG4gICAgICAgIHRoaXMuX2dlbmVyYXRlRW50ZXJwcmlzZURhdGFzb3VyY2UoKTtcclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF9ncmlkUmVhZHlET01DeWNsZSgpOiB2b2lkIHtcclxuICAgICAgICB0aGlzLl91cGRhdGVQYXJlbnROb2RlQ1NTKCk7XHJcbiAgICAgICAgdGhpcy5fc2V0SGVpZ2h0KCk7XHJcbiAgICAgICAgdGhpcy5fcmVzaXplQ29sdW1uKCk7XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfZ3JpZFNlbGVjdGlvbkN5Y2xlKF9yb3dOb2RlOiBSb3dOb2RlKTogdm9pZCB7XHJcbiAgICAgICAgaWYgKHR5cGVvZiB0aGlzLmNvbmZpZy5zZWxlY3Rpb24gPT09ICd1bmRlZmluZWQnKSB7XHJcbiAgICAgICAgICAgIGNvbnNvbGUuZXJyb3IoJ0tkVGFibGUgZXJyb3I6IFVzZXIgaGF2ZSBzZXQgY2xpY2sgdHlwZSB0byBiZSBzZWxlY3Rpb24gYnV0IG5vIHNlbGVjdGlvbiBpcyBkZWZpbmVkLiBEbyB5b3UgbWVhbiBjbGljayB0eXBlIHRvIHJvdXRlcj8nKTtcclxuICAgICAgICB9XHJcbiAgICAgICAgZWxzZSBpZiAodGhpcy5jb25maWcuc2VsZWN0aW9uLnR5cGUgPT09ICdzaW5nbGUnKSB7XHJcbiAgICAgICAgICAgIGlmICh0aGlzLmNvbmZpZy5zZWxlY3Rpb24udmFsdWUuaW5kZXhPZihfcm93Tm9kZS5pZCkgPCAwKSB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLmdyaWRPcHRpb25zLmFwaS5kZXNlbGVjdEFsbCgpO1xyXG4gICAgICAgICAgICAgICAgX3Jvd05vZGUuc2VsZWN0VGhpc05vZGUodHJ1ZSk7XHJcblxyXG4gICAgICAgICAgICAgICAgdGhpcy5jb25maWcuc2VsZWN0aW9uLnZhbHVlLnNwbGljZSgwLCB0aGlzLmNvbmZpZy5zZWxlY3Rpb24udmFsdWUubGVuZ3RoKTtcclxuICAgICAgICAgICAgICAgIHRoaXMuY29uZmlnLnNlbGVjdGlvbi52YWx1ZS5wdXNoKF9yb3dOb2RlLmRhdGEuaWQpO1xyXG5cclxuICAgICAgICAgICAgICAgIHRoaXMuX2Jyb2FkY2FzdE1vZGVsQ2hhbmdlZEV2ZW50KCk7XHJcbiAgICAgICAgICAgICAgICB0aGlzLl91cGRhdGVTZWxlY3Rpb25Ob2Rlcyhfcm93Tm9kZSk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICAgICAgZWxzZSB7XHJcbiAgICAgICAgICAgIGxldCBzZWxlY3Rpb246IGJvb2xlYW4gPSAhX3Jvd05vZGUuaXNTZWxlY3RlZCgpO1xyXG4gICAgICAgICAgICBfcm93Tm9kZS5zZWxlY3RUaGlzTm9kZShzZWxlY3Rpb24pO1xyXG5cclxuICAgICAgICAgICAgdGhpcy5fYnJvYWRjYXN0TW9kZWxDaGFuZ2VkRXZlbnQoKTtcclxuXHJcbiAgICAgICAgICAgIGlmIChzZWxlY3Rpb24pIHtcclxuICAgICAgICAgICAgICAgIHRoaXMuY29uZmlnLnNlbGVjdGlvbi52YWx1ZS5wdXNoKF9yb3dOb2RlLmRhdGEuaWQpO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5jb25maWcuc2VsZWN0aW9uLnZhbHVlLnNwbGljZSh0aGlzLmNvbmZpZy5zZWxlY3Rpb24udmFsdWUuaW5kZXhPZihfcm93Tm9kZS5kYXRhLmlkKSwgMSk7XHJcbiAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgIHRoaXMuX3VwZGF0ZVNlbGVjdGlvbk5vZGVzKF9yb3dOb2RlKTtcclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfZ3JpZFNldFJvd0N5Y2xlKCk6IHZvaWQge1xyXG4gICAgICAgIGlmICh0eXBlb2YgdGhpcy5jb25maWcuc2VsZWN0aW9uICE9PSAndW5kZWZpbmVkJyAmJiB0eXBlb2YgdGhpcy5jb25maWcuc2VsZWN0aW9uLnR5cGUgIT09ICd1bmRlZmluZWQnKSB7XHJcbiAgICAgICAgICAgIHRoaXMuX3Byb2Nlc3NJbml0aWFsU2VsZWN0aW9uKCk7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICBlbHNlIGlmICh0aGlzLl90YWJsZVNlcnZpY2UuaGFzSW5wdXRUeXBlKHRoaXMuY29sdW1uLCAnaW5wdXQnKSkge1xyXG4gICAgICAgICAgICB0aGlzLl9lbWl0SW5wdXRVcGRhdGVFdmVudCgpO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF9ncmlkQ2xpY2tOYXZpZ2F0ZUN5Y2xlKF9yb3dOb2RlOiBSb3dOb2RlKTogdm9pZCB7XHJcbiAgICAgICAgaWYgKHR5cGVvZiB0aGlzLmNvbmZpZy5jbGljay5wYXRoTWFwICE9PSAndW5kZWZpbmVkJykge1xyXG4gICAgICAgICAgICBpZiAodHlwZW9mIHRoaXMuY29uZmlnLmFjdGlvbiAhPT0gJ3VuZGVmaW5lZCcgJiZcclxuICAgICAgICAgICAgICAgIHR5cGVvZiB0aGlzLmNvbmZpZy5hY3Rpb24ubGlzdCAhPT0gJ3VuZGVmaW5lZCcpIHtcclxuICAgICAgICAgICAgICAgIGxldCByb3V0ZXJQYXRoOiBzdHJpbmcgPSAnJztcclxuXHJcbiAgICAgICAgICAgICAgICBmb3IgKGxldCBpOiBudW1iZXIgPSAwOyBpIDwgdGhpcy5jb25maWcuYWN0aW9uLmxpc3QubGVuZ3RoOyArK2kpIHtcclxuICAgICAgICAgICAgICAgICAgICBsZXQgYWN0aW9uSXRlbTogSVRhYmxlRHJvcGRvd25BY3Rpb24gPSB0aGlzLmNvbmZpZy5hY3Rpb24ubGlzdFtpXTtcclxuXHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKGFjdGlvbkl0ZW0udHlwZS50b0xvd2VyQ2FzZSgpID09PSB0aGlzLmNvbmZpZy5jbGljay5wYXRoTWFwLnRvTG93ZXJDYXNlKCkpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgcm91dGVyUGF0aCA9IHRoaXMuX3RhYmxlU2VydmljZS5nZXRSb3V0ZXJQbGFjZWhvbGRlclBhdGgoX3Jvd05vZGUsIGFjdGlvbkl0ZW0ucGF0aCk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgICAgICBpZiAocm91dGVyUGF0aCAhPT0gJycpIHtcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLl9yb3V0ZXIubmF2aWdhdGUoW3JvdXRlclBhdGhdKTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgICAgIGNvbnNvbGUud2FybignS2RUYWJsZSB3YXJuaW5nOiBUYWJsZSByb3V0ZXIgcGF0aE1hcCBub3QgZm91bmQuIHBhdGhNYXAgc2V0IHRvOicsIHRoaXMuY29uZmlnLmNsaWNrLnBhdGhNYXApO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgY29uc29sZS5lcnJvcignS2RUYWJsZSBlcnJvcjogVGFibGUgY2xpY2sgZXZlbnQgc2V0IHRvIHJvdXRlciBwYXRoTWFwIGJ1dCBubyBhY3Rpb24gbGlzdCBpcyBkZWZpbmVkLiBEbyB5b3UgbWVhbiBwYXRoIHByb3BlcnR5IGluc3RlYWQgb2YgcGF0aE1hcCBwcm9wZXJ0eT8nKTtcclxuICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICB9XHJcbiAgICAgICAgZWxzZSBpZiAodHlwZW9mIHRoaXMuY29uZmlnLmNsaWNrLnBhdGggIT09ICd1bmRlZmluZWQnKSB7XHJcbiAgICAgICAgICAgIHRoaXMuX3JvdXRlci5uYXZpZ2F0ZShbdGhpcy5jb25maWcuY2xpY2sucGF0aF0pO1xyXG4gICAgICAgIH1cclxuICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgY29uc29sZS5lcnJvcignS2RUYWJsZSBlcnJvcjogVGFibGUgY2xpY2sgZXZlbnQgdHlwZSBzZXQgYXQgcm91dGVyIGJ1dCBubyBwYXRoIC8gcGF0aE1hcCBpcyBwcm92aWRlZC4gRG8geW91IG1lYW4gY2xpY2sgdHlwZSBzZWxlY3Rpb24gLyBub25lPycpO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICAvLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vL1xyXG4gICAgLy8gRGlzcGxheSAvIERPTSBmdW5jdGlvblxyXG4gICAgLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy9cclxuXHJcbiAgICBwcml2YXRlIF9zaG93TG9hZGluZ092ZXJsYXkoX3RvZ2dsZTogYm9vbGVhbik6IHZvaWQge1xyXG4gICAgICAgIHRoaXMuZGlzcGxheUxvYWRpbmcgPSBfdG9nZ2xlO1xyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX3VwZGF0ZVBhcmVudE5vZGVDU1MoKTogdm9pZCB7XHJcbiAgICAgICAgdGhpcy5fdmNyLmVsZW1lbnQubmF0aXZlRWxlbWVudC5wYXJlbnROb2RlLmNsYXNzTmFtZSArPSAnIGhhcy1hZ2dyaWQnO1xyXG4gICAgICAgIGlmICh0aGlzLl9kaXJlY3Rpb24gPT09ICdydGwnKSB7XHJcbiAgICAgICAgICAgIGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3IoJ2JvZHknKS5zdHlsZS5jc3NUZXh0ICs9ICctLWtkdGFibGUtaGVhZGVyLXRleHQtYWxpZ246IHJpZ2h0Oyc7XHJcbiAgICAgICAgICAgIGxldCBwYWdpbmdCdXR0b24gPSBkb2N1bWVudC5nZXRFbGVtZW50c0J5VGFnTmFtZShcImJ1dHRvblwiKTtcclxuXHJcbiAgICAgICAgICAgIGZvciAodmFyIGkgPSAwOyBpIDwgcGFnaW5nQnV0dG9uLmxlbmd0aDsgaSsrKSB7XHJcbiAgICAgICAgICAgICAgICBpZiAocGFnaW5nQnV0dG9uW2ldLmNsYXNzTmFtZSA9PSAnYWctcGFnaW5nLWJ1dHRvbi1ydGwnIHx8IHBhZ2luZ0J1dHRvbltpXS5jbGFzc05hbWUgPT0gJ2FnLXBhZ2luZy1idXR0b24nKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgcGFnaW5nQnV0dG9uW2ldLmNsYXNzTmFtZSA9IFwiYWctcGFnaW5nLWJ1dHRvbi1ydGxcIjtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB0aGlzLnJpZ2h0RGlyZWN0aW9uID0gJ3J0bCc7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX3NldEhlaWdodCgpOiB2b2lkIHtcclxuICAgICAgICBsZXQgZG9tRWxlUXVlcnk6IHN0cmluZyA9ICcjJyArIHRoaXMuZ3JpZElkICsgJy5zdGctdGhlbWUnO1xyXG4gICAgICAgIGxldCBncmlkRWxlbWVudDogRWxlbWVudCA9IHRoaXMuX3Zjci5lbGVtZW50Lm5hdGl2ZUVsZW1lbnQucXVlcnlTZWxlY3Rvcihkb21FbGVRdWVyeSk7XHJcblxyXG4gICAgICAgIGlmIChncmlkRWxlbWVudCAhPT0gbnVsbCkge1xyXG4gICAgICAgICAgICBsZXQgd2luZG93c1dpZHRoOiBudW1iZXIgPSBkb2N1bWVudC5ib2R5LmNsaWVudFdpZHRoO1xyXG5cclxuICAgICAgICAgICAgaWYgKHdpbmRvd3NXaWR0aCA8PSAxMDI0KSB7XHJcbiAgICAgICAgICAgICAgICBpZiAodHlwZW9mIHRoaXMuX2lzTW9iaWxlVmlldyA9PT0gJ3VuZGVmaW5lZCcgfHwgIXRoaXMuX2lzTW9iaWxlVmlldykge1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuX3Nob3dMb2FkaW5nT3ZlcmxheSh0cnVlKTtcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLl9pc01vYmlsZVZpZXcgPSB0cnVlO1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuX3NldE1vYmlsZUhlaWdodChncmlkRWxlbWVudCk7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgZWxzZSBpZiAod2luZG93c1dpZHRoID4gMTAyNCkge1xyXG4gICAgICAgICAgICAgICAgaWYgKHR5cGVvZiB0aGlzLl9pc01vYmlsZVZpZXcgPT09ICd1bmRlZmluZWQnIHx8IHRoaXMuX2lzTW9iaWxlVmlldykge1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuX3Nob3dMb2FkaW5nT3ZlcmxheSh0cnVlKTtcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLl9pc01vYmlsZVZpZXcgPSBmYWxzZTtcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLl9zZXRXZWJHcmlkSGVpZ2h0KGdyaWRFbGVtZW50LCB0aGlzLmNvbmZpZy5ncmlkSGVpZ2h0KTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuZ3JpZE9wdGlvbnMuYXBpLnNpemVDb2x1bW5zVG9GaXQoKTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICAvKipcclxuICAgICAqIGFkZCBib3JkZXIgYm90dG9tIGR5bmFtaWNhbGx5IHNvIHRoYXQgd2hlbiB0aGUgcm93IGlzIGxlc3NlciB0aGFuIGJvZHktY29udGFpbmVyLCB0aGVyZSB3b250IGJlIGFueSBoYW5naW5nIGJvcmRlciBib3R0b21cclxuICAgICAqIHdoZW4gdGhlIHJvdyBpcyBtb3JlIHRoYW4gY29udGFpbmVyLCB0aGVyZSB3aWxsIGJlIGEgYm9yZGVyLWJvdHRvbVxyXG4gICAgICovXHJcbiAgICBwcml2YXRlIF9zZXRUYWJsZUJvcmRlckJvdHRvbSgpOiB2b2lkIHtcclxuICAgICAgICBsZXQgY29udGFpbmVyRWxlUXVlcnk6IHN0cmluZyA9ICcgLmFnLWJvZHktY29udGFpbmVyJztcclxuICAgICAgICBsZXQgY29udGFpbmVyRWxlOiBFbGVtZW50ID0gdGhpcy5fdmNyLmVsZW1lbnQubmF0aXZlRWxlbWVudC5xdWVyeVNlbGVjdG9yKGNvbnRhaW5lckVsZVF1ZXJ5KTtcclxuICAgICAgICBpZiAoY29udGFpbmVyRWxlID09PSBudWxsKSByZXR1cm47XHJcblxyXG4gICAgICAgIGxldCB2aWV3cG9ydEVsZVF1ZXJ5OiBzdHJpbmcgPSAnIC5hZy1ib2R5LXZpZXdwb3J0JztcclxuICAgICAgICBsZXQgdmlld3BvcnRFbGU6IEVsZW1lbnQgPSB0aGlzLl92Y3IuZWxlbWVudC5uYXRpdmVFbGVtZW50LnF1ZXJ5U2VsZWN0b3Iodmlld3BvcnRFbGVRdWVyeSk7XHJcblxyXG4gICAgICAgIGlmIChjb250YWluZXJFbGUuY2xpZW50SGVpZ2h0ID4gdmlld3BvcnRFbGUuY2xpZW50SGVpZ2h0ICYmXHJcbiAgICAgICAgICAgIHZpZXdwb3J0RWxlLmNsYXNzTmFtZSAmJlxyXG4gICAgICAgICAgICB2aWV3cG9ydEVsZS5jbGFzc05hbWUuaW5kZXhPZignaGFzLWJvcmRlci1ib3R0b20nKSA9PT0gLTFcclxuICAgICAgICApIHtcclxuICAgICAgICAgICAgdmlld3BvcnRFbGUuY2xhc3NOYW1lICs9ICcgaGFzLWJvcmRlci1ib3R0b20nO1xyXG4gICAgICAgIH0gZWxzZSBpZiAoY29udGFpbmVyRWxlLmNsaWVudEhlaWdodCA8IHZpZXdwb3J0RWxlLmNsaWVudEhlaWdodCkge1xyXG4gICAgICAgICAgICB2aWV3cG9ydEVsZS5jbGFzc05hbWUgPSB2aWV3cG9ydEVsZS5jbGFzc05hbWUucmVwbGFjZSgvaGFzLWJvcmRlci1ib3R0b20vZ2ksICcnKTtcclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfc2V0TW9iaWxlSGVpZ2h0KF9ncmlkRWxlbWVudDogRWxlbWVudCk6IHZvaWQge1xyXG4gICAgICAgIGxldCBuZXdIZWlnaHQ6IG51bWJlciA9IDA7XHJcblxyXG4gICAgICAgIGlmICh0aGlzLmNvbmZpZy5sb2FkVHlwZSAhPT0gJ2luZmluaXRlJykge1xyXG4gICAgICAgICAgICBsZXQgYWdIZWFkZXJFbGU6IEVsZW1lbnQgPSB0aGlzLl92Y3IuZWxlbWVudC5uYXRpdmVFbGVtZW50LnF1ZXJ5U2VsZWN0b3IoJy5hZy1oZWFkZXInKTtcclxuICAgICAgICAgICAgbGV0IGFnQm9keUVsZTogRWxlbWVudCA9IHRoaXMuX3Zjci5lbGVtZW50Lm5hdGl2ZUVsZW1lbnQucXVlcnlTZWxlY3RvcignLmFnLWJvZHktY29udGFpbmVyJyk7XHJcbiAgICAgICAgICAgIGxldCBhZ1BhZ2VQYW5lbEVsZTogRWxlbWVudCA9IHRoaXMuX3Zjci5lbGVtZW50Lm5hdGl2ZUVsZW1lbnQucXVlcnlTZWxlY3RvcignZGl2W3JlZj1cInNvdXRoXCJdJyk7XHJcbiAgICAgICAgICAgIG5ld0hlaWdodCA9IDI1O1xyXG5cclxuICAgICAgICAgICAgaWYgKGFnSGVhZGVyRWxlICE9PSBudWxsKSB7XHJcbiAgICAgICAgICAgICAgICBuZXdIZWlnaHQgKz0gYWdIZWFkZXJFbGUuY2xpZW50SGVpZ2h0O1xyXG4gICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICBpZiAoYWdCb2R5RWxlICE9PSBudWxsKSB7XHJcbiAgICAgICAgICAgICAgICBuZXdIZWlnaHQgKz0gYWdCb2R5RWxlLmNsaWVudEhlaWdodDtcclxuICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgaWYgKGFnUGFnZVBhbmVsRWxlICE9PSBudWxsKSB7XHJcbiAgICAgICAgICAgICAgICBuZXdIZWlnaHQgKz0gYWdQYWdlUGFuZWxFbGUuY2xpZW50SGVpZ2h0O1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICBuZXdIZWlnaHQgPSA0MDA7XHJcbiAgICAgICAgfVxyXG5cclxuXHJcbiAgICAgICAgdGhpcy5fZG9tU3ZjLnNldEVsZW1lbnRTdHlsZShfZ3JpZEVsZW1lbnQsICdoZWlnaHQnLCBuZXdIZWlnaHQgKyAncHgnKTtcclxuXHJcbiAgICAgICAgdGltZXIoMTApLnN1YnNjcmliZSgoKTogdm9pZCA9PiB7XHJcbiAgICAgICAgICAgIHRoaXMuZ3JpZE9wdGlvbnMuYXBpLnNpemVDb2x1bW5zVG9GaXQoKTtcclxuICAgICAgICAgICAgdGhpcy5fc2hvd0xvYWRpbmdPdmVybGF5KGZhbHNlKTtcclxuICAgICAgICB9KTtcclxuICAgIH1cclxuXHJcbiAgICAvKipcclxuICAgICAqIFtfc2V0V2ViR3JpZEhlaWdodCBudW1iZXIgZm9yIHBpeGVsIG9yIHN0cmluZyBcImF1dG9cIl1cclxuICAgICAqICBfY29uZmlnSGVpZ2h0IFtkZXNjcmlwdGlvbl1cclxuICAgICAqL1xyXG4gICAgcHJpdmF0ZSBfc2V0V2ViR3JpZEhlaWdodChfZ3JpZEVsZW1lbnQ6IEVsZW1lbnQsIF9jb25maWdIZWlnaHQ6IG51bWJlciB8IHN0cmluZyk6IHZvaWQge1xyXG4gICAgICAgIGlmICh0eXBlb2YgX2NvbmZpZ0hlaWdodCA9PT0gJ251bWJlcicpIHtcclxuICAgICAgICAgICAgbGV0IGdyaWRIZWlnaHQ6IG51bWJlciA9IDYwMDtcclxuXHJcbiAgICAgICAgICAgIGlmICh0eXBlb2YgX2NvbmZpZ0hlaWdodCAhPT0gJ3VuZGVmaW5lZCcpIHtcclxuICAgICAgICAgICAgICAgIGdyaWRIZWlnaHQgPSBfY29uZmlnSGVpZ2h0O1xyXG4gICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICB0aGlzLl9kb21TdmMuc2V0RWxlbWVudFN0eWxlKF9ncmlkRWxlbWVudCwgJ2hlaWdodCcsIGdyaWRIZWlnaHQgKyAncHgnKTtcclxuICAgICAgICB9XHJcbiAgICAgICAgZWxzZSBpZiAoX2NvbmZpZ0hlaWdodCA9PT0gJ2F1dG8nKSB7XHJcbiAgICAgICAgICAgIHRoaXMuZGlzcGxheUZ1bGwgPSB0cnVlO1xyXG4gICAgICAgIH1cclxuICAgICAgICAvLyBlbHNlIGlmIChfY29uZmlnSGVpZ2h0ID09PSAncm93SGVpZ2h0Jykge1xyXG4gICAgICAgIC8vICAgICB0aGlzLmdyaWRPcHRpb25zLmRvbUxheW91dCA9ICdhdXRvSGVpZ2h0JztcclxuICAgICAgICAvLyAgICAgZGVsZXRlIHRoaXMuZ3JpZE9wdGlvbnMucm93SGVpZ2h0O1xyXG4gICAgICAgIC8vICAgICBkZWxldGUgdGhpcy5ncmlkT3B0aW9ucy5nZXRSb3dIZWlnaHQ7XHJcbiAgICAgICAgLy8gfVxyXG5cclxuICAgICAgICB0aW1lcigpLnN1YnNjcmliZSgoKTogdm9pZCA9PiB7XHJcbiAgICAgICAgICAgIHRoaXMuZ3JpZE9wdGlvbnMuYXBpLnNpemVDb2x1bW5zVG9GaXQoKTtcclxuICAgICAgICAgICAgdGhpcy5fc2hvd0xvYWRpbmdPdmVybGF5KGZhbHNlKTtcclxuICAgICAgICB9KTtcclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF9pc0NsaWNrVmFsaWQoX2V2ZW50OiBFdmVudCk6IGJvb2xlYW4ge1xyXG4gICAgICAgIGxldCB0YXJnZXRFbGVtZW50OiBIVE1MRWxlbWVudCA9IDxIVE1MRWxlbWVudD5fZXZlbnQudGFyZ2V0O1xyXG4gICAgICAgIGxldCBpbnZhbGlkTGlzdDogQXJyYXk8c3RyaW5nPiA9IFsnYWN0aW9uLWJ0bicsICdjaGVja2JveC1yYWRpby1pbnB1dCcsICdmYS1jaGV2cm9uLWRvd24nXTtcclxuXHJcbiAgICAgICAgZm9yIChsZXQgaTogbnVtYmVyID0gMDsgaSA8IGludmFsaWRMaXN0Lmxlbmd0aDsgaSsrKSB7XHJcbiAgICAgICAgICAgIGlmICh0YXJnZXRFbGVtZW50LmNsYXNzTGlzdC5jb250YWlucyhpbnZhbGlkTGlzdFtpXSkpIHtcclxuICAgICAgICAgICAgICAgIHJldHVybiBmYWxzZTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgcmV0dXJuIHRydWU7XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfcmVzaXplQ29sdW1uKF9pc1Jlc2l6ZVRvQ29udGVudDogYm9vbGVhbiA9IGZhbHNlKTogdm9pZCB7XHJcbiAgICAgICAgaWYgKHRoaXMuX3RhYmxlU2VydmljZS5pc0FwaVJlYWR5KHRoaXMuZ3JpZE9wdGlvbnMpKSB7XHJcbiAgICAgICAgICAgIHRpbWVyKDEwKS5zdWJzY3JpYmUoKCk6IHZvaWQgPT4ge1xyXG4gICAgICAgICAgICAgICAgKF9pc1Jlc2l6ZVRvQ29udGVudCkgPyB0aGlzLl9yZXNpemVDb2x1bW5Ub0NvbnRlbnQoKSA6IHRoaXMuZ3JpZE9wdGlvbnMuYXBpLnNpemVDb2x1bW5zVG9GaXQoKTtcclxuICAgICAgICAgICAgICAgIHRoaXMub25FeHBvcnRQb3NzaWJsZS5lbWl0KHRydWUpO1xyXG4gICAgICAgICAgICAgICAgdGhpcy5fc2hvd0xvYWRpbmdPdmVybGF5KGZhbHNlKTtcclxuICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIC8qKlxyXG4gICAgICogcmVzaXplIGNvbHVtbiB0byBjb2xEZWYgd2lkdGhcclxuICAgICAqL1xyXG4gICAgcHJpdmF0ZSBfcmVzaXplQ29sdW1uVG9Db250ZW50KCk6IHZvaWQge1xyXG4gICAgICAgIGxldCBhbGxDb2x1bW5JZHM6IEFycmF5PHN0cmluZz4gPSBbXTtcclxuICAgICAgICB0aGlzLmdyaWRPcHRpb25zLmNvbHVtbkFwaS5nZXRBbGxEaXNwbGF5ZWRDb2x1bW5zKCkuZm9yRWFjaCgoY29sdW1uOiBDb2x1bW4pID0+IHtcclxuICAgICAgICAgICAgYWxsQ29sdW1uSWRzLnB1c2goY29sdW1uLmdldENvbElkKCkpO1xyXG4gICAgICAgIH0pO1xyXG4gICAgICAgIHRoaXMuZ3JpZE9wdGlvbnMuY29sdW1uQXBpLmF1dG9TaXplQ29sdW1ucyhhbGxDb2x1bW5JZHMpO1xyXG4gICAgfVxyXG5cclxuICAgIC8qKlxyXG4gICAgICogcG9wdWxhdGUgZHluYW1pYyBzdHlsaW5nIHZhbHVlXHJcbiAgICAgKiBwYXJhbSB7SVRhYmxlQ29uZmlnfSBfY29uZmlnOiB0YWJsZUNvbmZpZ1xyXG4gICAgICovXHJcbiAgICBwdWJsaWMgdXBkYXRlU3R5bGUoX2NvbmZpZzogSVRhYmxlQ29uZmlnKTogdm9pZCB7XHJcbiAgICAgICAgaWYgKCFfY29uZmlnIHx8ICFfY29uZmlnLmNvbmZpZykge1xyXG4gICAgICAgICAgICBkb2N1bWVudC5xdWVyeVNlbGVjdG9yKCdib2R5Jykuc3R5bGUuY3NzVGV4dCA9ICcnO1xyXG4gICAgICAgICAgICByZXR1cm47XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGxldCBjb25maWc6IElTdHlsaW5nQ29uZmlnID0gX2NvbmZpZy5jb25maWc7XHJcblxyXG4gICAgICAgIGxldCBib2R5Q3NzOiBzdHJpbmcgPSAnJztcclxuXHJcbiAgICAgICAgYm9keUNzcyArPSB0aGlzLl91cGRhdGVIZWFkZXJTdHlsZShjb25maWcpO1xyXG5cclxuICAgICAgICBpZiAoY29uZmlnLmJvZHkpIHtcclxuICAgICAgICAgICAgaWYgKGNvbmZpZy5ib2R5LmFsdGVybmF0ZVJvdyA9PT0gdHJ1ZSkge1xyXG4gICAgICAgICAgICAgICAgaWYgKGNvbmZpZy5ib2R5Lm9kZCAmJiBjb25maWcuYm9keS5vZGQuYmFja2dyb3VuZENvbG9yKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgYm9keUNzcyArPSAnLS1rZHRhYmxlLXJvdy1vZGQtYmFja2dyb3VuZDogJyArIGNvbmZpZy5ib2R5Lm9kZC5iYWNrZ3JvdW5kQ29sb3IgKyAnOyc7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICBpZiAoY29uZmlnLmJvZHkuZXZlbiAmJiBjb25maWcuYm9keS5ldmVuLmJhY2tncm91bmRDb2xvcikge1xyXG4gICAgICAgICAgICAgICAgICAgIGJvZHlDc3MgKz0gJy0ta2R0YWJsZS1yb3ctZXZlbi1iYWNrZ3JvdW5kOiAnICsgY29uZmlnLmJvZHkuZXZlbi5iYWNrZ3JvdW5kQ29sb3IgKyAnOyc7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgaWYgKGNvbmZpZy5ib2R5LnN0eWxlKSB7XHJcbiAgICAgICAgICAgICAgICBpZiAoY29uZmlnLmJvZHkuc3R5bGUuYm9yZGVyV2lkdGgpIHtcclxuICAgICAgICAgICAgICAgICAgICBib2R5Q3NzICs9ICctLWtkdGFibGUtYm9keS1ib3JkZXItd2lkdGg6ICcgKyBjb25maWcuYm9keS5zdHlsZS5ib3JkZXJXaWR0aCArICc7JztcclxuICAgICAgICAgICAgICAgICAgICBib2R5Q3NzICs9ICctLWtkdGFibGUtaGVhZGVyLWJvcmRlci13aWR0aDogJyArIGNvbmZpZy5ib2R5LnN0eWxlLmJvcmRlcldpZHRoICsgJzsnO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgaWYgKGNvbmZpZy5ib2R5LnN0eWxlLmJvcmRlckNvbG9yKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgYm9keUNzcyArPSAnLS1rZHRhYmxlLWJvZHktYm9yZGVyLWNvbG9yOiAnICsgY29uZmlnLmJvZHkuc3R5bGUuYm9yZGVyQ29sb3IgKyAnOyc7XHJcbiAgICAgICAgICAgICAgICAgICAgYm9keUNzcyArPSAnLS1rZHRhYmxlLWhlYWRlci1ib3JkZXItY29sb3I6ICcgKyBjb25maWcuYm9keS5zdHlsZS5ib3JkZXJDb2xvciArICc7JztcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIGlmIChjb25maWcuYm9keS5zdHlsZS5ib3JkZXJTdHlsZSkge1xyXG4gICAgICAgICAgICAgICAgICAgIGJvZHlDc3MgKz0gJy0ta2R0YWJsZS1ib2R5LWJvcmRlci1zdHlsZTogJyArIGNvbmZpZy5ib2R5LnN0eWxlLmJvcmRlclN0eWxlICsgJzsnO1xyXG4gICAgICAgICAgICAgICAgICAgIGJvZHlDc3MgKz0gJy0ta2R0YWJsZS1oZWFkZXItYm9yZGVyLXN0eWxlOiAnICsgY29uZmlnLmJvZHkuc3R5bGUuYm9yZGVyU3R5bGUgKyAnOyc7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3IoJ2JvZHknKS5zdHlsZS5jc3NUZXh0ID0gYm9keUNzcztcclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF91cGRhdGVIZWFkZXJTdHlsZShfY29uZmlnOiBJU3R5bGluZ0NvbmZpZyk6IHN0cmluZyB7XHJcbiAgICAgICAgaWYgKCFfY29uZmlnLmhlYWRlciB8fCAhX2NvbmZpZy5oZWFkZXIuc3R5bGUpIHJldHVybiAnJztcclxuXHJcbiAgICAgICAgbGV0IGJvZHlDc3M6IHN0cmluZyA9ICcnO1xyXG4gICAgICAgIGxldCBzdHlsZU5hbWVzOiBBcnJheTxzdHJpbmc+ID0gW1xyXG4gICAgICAgICAgICAnYmFja2dyb3VuZENvbG9yJyxcclxuICAgICAgICAgICAgJ3RleHRBbGlnbicsXHJcbiAgICAgICAgICAgICd2ZXJ0aWNhbEFsaWduJyxcclxuICAgICAgICAgICAgJ2NvbG9yJyxcclxuICAgICAgICAgICAgJ2ZvbnRGYW1pbHknLFxyXG4gICAgICAgICAgICAnZm9udFNpemUnLFxyXG4gICAgICAgICAgICAnZm9udFdlaWdodCcsXHJcbiAgICAgICAgICAgICdmb250U3R5bGUnLFxyXG4gICAgICAgICAgICAndGV4dERlY29yYXRpb24nLFxyXG4gICAgICAgICAgICAvLyAnYm9yZGVyV2lkdGgnLFxyXG4gICAgICAgICAgICAvLyAnYm9yZGVyQ29sb3InLFxyXG4gICAgICAgICAgICAvLyAnYm9yZGVyU3R5bGUnLFxyXG4gICAgICAgICAgICAnb3BhY2l0eSdcclxuICAgICAgICBdO1xyXG4gICAgICAgIGZvciAobGV0IGk6IG51bWJlciA9IDA7IGkgPCBzdHlsZU5hbWVzLmxlbmd0aDsgKytpKSB7XHJcbiAgICAgICAgICAgIGxldCBzdHlsZU5hbWU6IHN0cmluZyA9IHN0eWxlTmFtZXNbaV07XHJcbiAgICAgICAgICAgIGxldCB2YWx1ZTogc3RyaW5nID0gX2NvbmZpZy5oZWFkZXIuc3R5bGVbc3R5bGVOYW1lXTtcclxuICAgICAgICAgICAgaWYgKHN0eWxlTmFtZSA9PT0gJ3ZlcnRpY2FsQWxpZ24nKSB2YWx1ZSA9IHRoaXMuX2dldEFsaWduSXRlbSh2YWx1ZSk7XHJcbiAgICAgICAgICAgIHN0eWxlTmFtZSA9IChzdHlsZU5hbWUgPT09ICdiYWNrZ3JvdW5kQ29sb3InKSA/ICdiYWNrZ3JvdW5kJyA6IHN0eWxlTmFtZS5yZXBsYWNlKC8oW2Etel0pKFtBLVpdKS9nLCAnJDEtJDInKS50b0xvd2VyQ2FzZSgpO1xyXG4gICAgICAgICAgICBpZiAodHlwZW9mIHZhbHVlICE9PSAndW5kZWZpbmVkJykge1xyXG4gICAgICAgICAgICAgICAgaWYgKHN0eWxlTmFtZSA9PT0gJ2JvcmRlcldpZHRoJyAmJlxyXG4gICAgICAgICAgICAgICAgICAgICh0eXBlb2YgdmFsdWUgIT09ICdzdHJpbmcnIHx8IHZhbHVlLmluZGV4T2YoJ3B4JykgPT09IC0xKVxyXG4gICAgICAgICAgICAgICAgKSB2YWx1ZSArPSAncHgnO1xyXG4gICAgICAgICAgICAgICAgYm9keUNzcyArPSAnLS1rZHRhYmxlLWhlYWRlci0nICsgc3R5bGVOYW1lICsgJzogJyArIHZhbHVlICsgJzsnO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgICAgIHJldHVybiBib2R5Q3NzO1xyXG4gICAgfVxyXG5cclxuICAgIC8qKlxyXG4gICAgICogY29udmVydCB0ZXh0IGFsaWduIGludG8gZmxleC1ib3ggaXRlbSBhbGlnblxyXG4gICAgICogcGFyYW0ge3N0cmluZ30gX3ZlcnRpY2FsQWxpZ246IHRleHQgdmVydGljYWxBbGlnblxyXG4gICAgICovXHJcbiAgICBwcml2YXRlIF9nZXRBbGlnbkl0ZW0oX3ZlcnRpY2FsQWxpZ246IHN0cmluZyk6IHN0cmluZyB7XHJcbiAgICAgICAgaWYgKF92ZXJ0aWNhbEFsaWduID09PSAnYmFzZWxpbmUnIHx8IF92ZXJ0aWNhbEFsaWduID09PSAnYm90dG9tJykge1xyXG4gICAgICAgICAgICByZXR1cm4gJ2ZsZXgtZW5kJztcclxuICAgICAgICB9IGVsc2UgaWYgKF92ZXJ0aWNhbEFsaWduID09PSAndG9wJykge1xyXG4gICAgICAgICAgICByZXR1cm4gJ2ZsZXgtc3RhcnQnO1xyXG4gICAgICAgIH0gZWxzZSB7IC8vIGluY2x1ZGluZyBpbnZhbGlkIGlucHV0XHJcbiAgICAgICAgICAgIGlmIChfdmVydGljYWxBbGlnbiAhPT0gJ21pZGRsZScgJiYgX3ZlcnRpY2FsQWxpZ24gIT09IHVuZGVmaW5lZCkge1xyXG4gICAgICAgICAgICAgICAgY29uc29sZS53YXJuKCdFUlJPUjogdGhlIHZlcnRpY2FsIGFsaWduIHZhbHVlIG9mICcgKyBfdmVydGljYWxBbGlnbiArICcgaXMgbm90IHlldCByZWNvZ25pc2VkIGJ5IEtkVGFibGUuIFBsZWFzZSBvbmx5IHVzZSBlaXRoZXIgdG9wLCBjZW50ZXIgb3IgYm90dG9tJyk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgcmV0dXJuICdjZW50ZXInO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICAvLyBwcml2YXRlIF9yZWZyZXNoVGFibGUoX3RhYmxlQ2VsbFBhcmFtcz86IElUYWJsZUNlbGxQYXJhbXMpOiB2b2lkIHtcclxuICAgIC8vICAgICBpZiAodGhpcy5fdGFibGVTZXJ2aWNlICYmIHRoaXMuX3RhYmxlU2VydmljZS5pc0FwaVJlYWR5ICYmIHRoaXMuX3RhYmxlU2VydmljZS5pc0FwaVJlYWR5KHRoaXMuZ3JpZE9wdGlvbnMpKSB7XHJcbiAgICAvLyAgICAgICAgIGxldCB0b1VwZGF0ZU5vZGU6IEFycmF5PFJvd05vZGU+ID0gW107XHJcbiAgICAvLyAgICAgICAgIGxldCBhbGxDb2x1bW5JZHM6IEFycmF5PHN0cmluZz4gPSBbXTtcclxuXHJcbiAgICAvLyAgICAgICAgIGlmICghX3RhYmxlQ2VsbFBhcmFtcykge1xyXG4gICAgLy8gICAgICAgICAgICAgdGhpcy5ncmlkT3B0aW9ucy5jb2x1bW5BcGkuZ2V0QWxsRGlzcGxheWVkQ29sdW1ucygpLmZvckVhY2goKGNvbHVtbikgPT4ge1xyXG4gICAgLy8gICAgICAgICAgICAgICAgIGFsbENvbHVtbklkcy5wdXNoKGNvbHVtbi5nZXRDb2xJZCgpKTtcclxuICAgIC8vICAgICAgICAgICAgIH0pO1xyXG4gICAgLy8gICAgICAgICB9XHJcblxyXG4gICAgLy8gICAgICAgICB0aGlzLmdyaWRPcHRpb25zLmFwaS5mb3JFYWNoTm9kZSgoX3Jvd05vZGU6IFJvd05vZGUpOiB2b2lkID0+IHtcclxuICAgIC8vICAgICAgICAgICAgIGlmIChfdGFibGVDZWxsUGFyYW1zICYmIHR5cGVvZiBfcm93Tm9kZS5pZCAhPT0gJ3VuZGVmaW5lZCcgJiYgX3Jvd05vZGUuaWQgPT09IF90YWJsZUNlbGxQYXJhbXMucm93SWQpIHtcclxuICAgIC8vICAgICAgICAgICAgICAgICBfcm93Tm9kZS5kYXRhW190YWJsZUNlbGxQYXJhbXMuY29sSWRdID0gX3RhYmxlQ2VsbFBhcmFtcy5kYXRhO1xyXG4gICAgLy8gICAgICAgICAgICAgICAgIHRvVXBkYXRlTm9kZS5wdXNoKF9yb3dOb2RlKTtcclxuICAgIC8vICAgICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAvLyAgICAgICAgICAgICAgICAgdG9VcGRhdGVOb2RlLnB1c2goX3Jvd05vZGUpO1xyXG4gICAgLy8gICAgICAgICAgICAgfVxyXG4gICAgLy8gICAgICAgICB9KTtcclxuXHJcbiAgICAvLyAgICAgICAgIGxldCByZWZyZXNoUGFyYW1zOiB7IHJvd05vZGVzOiBBcnJheTxSb3dOb2RlPiwgY29sdW1uczogQXJyYXk8YW55PiB9ID0ge1xyXG4gICAgLy8gICAgICAgICAgICAgcm93Tm9kZXM6IHRvVXBkYXRlTm9kZSxcclxuICAgIC8vICAgICAgICAgICAgIGNvbHVtbnM6IChfdGFibGVDZWxsUGFyYW1zKSA/IFtfdGFibGVDZWxsUGFyYW1zLmNvbElkXSA6IGFsbENvbHVtbklkc1xyXG4gICAgLy8gICAgICAgICB9O1xyXG5cclxuICAgIC8vICAgICAgICAgdGhpcy5ncmlkT3B0aW9ucy5hcGkucmVmcmVzaENlbGxzKHJlZnJlc2hQYXJhbXMpO1xyXG4gICAgLy8gICAgIH1cclxuICAgIC8vIH1cclxuXHJcbiAgICAvLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vL1xyXG4gICAgLy8vIFBpdm90IEZ1bmN0aW9uXHJcbiAgICAvLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vL1xyXG4gICAgcHJpdmF0ZSBfaXNUb29scGFuZWxUeXBlQ2hhbmdlZCgpOiBib29sZWFuIHtcclxuICAgICAgICBsZXQgaXNUeXBlQ2hhbmdlZDogYm9vbGVhbiA9IHRydWU7XHJcbiAgICAgICAgaWYgKHRoaXMuX3ByZXZpb3VzVG9vbHBhbmVsVHlwZSkge1xyXG4gICAgICAgICAgICBpZiAodHlwZUV4aXN0KHRoaXMuY29uZmlnKSkge1xyXG4gICAgICAgICAgICAgICAgaXNUeXBlQ2hhbmdlZCA9IHRoaXMuX3ByZXZpb3VzVG9vbHBhbmVsVHlwZSAhPT0gdGhpcy5jb25maWcucGl2b3QudG9vbHBhbmVsLnR5cGU7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICBpZiAodHlwZUV4aXN0KHRoaXMuY29uZmlnKSkge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5fcHJldmlvdXNUb29scGFuZWxUeXBlID0gdGhpcy5jb25maWcucGl2b3QudG9vbHBhbmVsLnR5cGU7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICAgICAgcmV0dXJuIGlzVHlwZUNoYW5nZWQ7XHJcblxyXG4gICAgICAgIGZ1bmN0aW9uIHR5cGVFeGlzdChfY29uZmlnKSB7XHJcbiAgICAgICAgICAgIHJldHVybiBfY29uZmlnICYmIF9jb25maWcucGl2b3QgJiYgX2NvbmZpZy5waXZvdC50b29scGFuZWwgJiYgX2NvbmZpZy5waXZvdC50b29scGFuZWwudHlwZVxyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF9jb25maWd1cmVQaXZvdERpc3BsYXkoKTogdm9pZCB7XHJcbiAgICAgICAgbGV0IGlzU3RhdGVDaGFuZ2VkOiBib29sZWFuID0gdHJ1ZTtcclxuICAgICAgICBpZiAodGhpcy5jb25maWcgJiYgdGhpcy5jb25maWcucGl2b3QgJiYgdGhpcy5jb25maWcucGl2b3Quc3RhdGUgJiYgdGhpcy5jb25maWcucGl2b3Quc3RhdGUuY29sdW1uU3RhdGUpIHtcclxuICAgICAgICAgICAgaXNTdGF0ZUNoYW5nZWQgPSB0aGlzLmNvbmZpZy5waXZvdC5zdGF0ZS5jb2x1bW5TdGF0ZS5sZW5ndGggIT09IHRoaXMuX2N1cnJlbnRTdGF0ZS5jb2x1bW5TdGF0ZS5sZW5ndGg7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGlmICh0aGlzLmNvbmZpZy5sb2FkVHlwZSAhPT0gJ25vcm1hbCcgfHwgKHRoaXMuX2lzVG9vbHBhbmVsVHlwZUNoYW5nZWQoKSA9PT0gZmFsc2UgJiYgaXNTdGF0ZUNoYW5nZWQgPT09IGZhbHNlKSkgcmV0dXJuO1xyXG5cclxuICAgICAgICBsZXQgc2hvd1Rvb2xQYW5lbDogYm9vbGVhbiA9IGZhbHNlO1xyXG4gICAgICAgIGxldCBzaG93UGl2b3RNb2RlOiBib29sZWFuID0gZmFsc2U7XHJcbiAgICAgICAgaWYgKHRoaXMuY29uZmlnLnBpdm90ICYmIHRoaXMuY29uZmlnLnBpdm90LnRvb2xwYW5lbCkge1xyXG4gICAgICAgICAgICBzaG93VG9vbFBhbmVsID0gdGhpcy5jb25maWcucGl2b3QudG9vbHBhbmVsLnR5cGUgIT09ICdub25lJztcclxuICAgICAgICAgICAgc2hvd1Bpdm90TW9kZSA9IHRoaXMuY29uZmlnLnBpdm90LnRvb2xwYW5lbC50eXBlID09PSAncGl2b3QnO1xyXG4gICAgICAgIH1cclxuICAgICAgICB0aGlzLl9zaG93VG9vbFBhbmVsKHNob3dUb29sUGFuZWwpO1xyXG4gICAgICAgIHRoaXMuX3Nob3dQaXZvdE1vZGUoc2hvd1Bpdm90TW9kZSk7XHJcbiAgICB9XHJcblxyXG4gICAgLyoqXHJcbiAgICAgKiByZXNpemUgY29sdW1uIHRvIGZpdCB0YWJsZSBjb250YWluZXIgaWYgdGhlIHdpZHRoIG9mIHRoZSBjb250ZW50IGNvbHVtbiBpcyBzbWFsbGVyIHRoYW4gY29udGFpbmVyXHJcbiAgICAgKi9cclxuICAgIHByaXZhdGUgX3Bpdm90UmVzaXplKCk6IHZvaWQge1xyXG4gICAgICAgIGxldCBjb250YWluZXI6IEVsZW1lbnQgPSB0aGlzLl92Y3IuZWxlbWVudC5uYXRpdmVFbGVtZW50LnF1ZXJ5U2VsZWN0b3IoJy5hZy1oZWFkZXItY29udGFpbmVyJyk7XHJcbiAgICAgICAgbGV0IGhlYWRlcjogRWxlbWVudCA9IHRoaXMuX3Zjci5lbGVtZW50Lm5hdGl2ZUVsZW1lbnQucXVlcnlTZWxlY3RvcignLmFnLWhlYWRlci1jb250YWluZXIgLmFnLWhlYWRlci1yb3cnKTtcclxuXHJcbiAgICAgICAgdGhpcy5fcmVzaXplQ29sdW1uKGhlYWRlci5nZXRCb3VuZGluZ0NsaWVudFJlY3QoKS53aWR0aCA+IGNvbnRhaW5lci5nZXRCb3VuZGluZ0NsaWVudFJlY3QoKS53aWR0aCk7XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfcmVzZXRQaXZvdENvbHVtbigpOiB2b2lkIHtcclxuICAgICAgICB0aGlzLmdyaWRPcHRpb25zLmNvbHVtbkFwaS5zZXRSb3dHcm91cENvbHVtbnMoW10pO1xyXG4gICAgICAgIHRoaXMuZ3JpZE9wdGlvbnMuY29sdW1uQXBpLnNldFBpdm90Q29sdW1ucyhbXSk7XHJcbiAgICAgICAgdGhpcy5ncmlkT3B0aW9ucy5jb2x1bW5BcGkuc2V0VmFsdWVDb2x1bW5zKFtdKTtcclxuICAgICAgICB0aGlzLmdyaWRPcHRpb25zLmNvbHVtbkFwaS5zZXRTZWNvbmRhcnlDb2x1bW5zKFtdKTtcclxuICAgIH1cclxuXHJcbiAgICAvKipcclxuICAgICAqIHBhc3Mgc3RhdGUgdG8gYXBwbGljYXRpb24uXHJcbiAgICAgKiAoaWYgc2V0U3RhdGUgd2FzIHRyaWdnZXJlZCBiZWZvcmUpLCB3YWl0IHVudGlsIHNldFN0YXRlIGhhcyBkb25lIHByb2Nlc3NpbmdcclxuICAgICAqIHJldHVybiB7SVRhYmxlUGl2b3RTdGF0ZX0gW2Rlc2NyaXB0aW9uXVxyXG4gICAgICovXHJcbiAgICBwcml2YXRlIF9nZXRQaXZvdFN0YXRlKCk6IElUYWJsZVBpdm90U3RhdGUge1xyXG4gICAgICAgIC8vIGlmIHN0YXRlIGlzIGNoYW5naW5nLCB3YWl0IHVudGlsIHN0YXRlIGhhcyBiZWVuIHVwZGF0ZWQgdGhlbiBnZXQgdGhlIG1vc3QgdXBkYXRlZCBzdGF0ZVxyXG4gICAgICAgIGxldCBnZXRTdGF0ZSA9ICgpOiBhbnkgPT4ge1xyXG4gICAgICAgICAgICB0aGlzLl9jdXJyZW50U3RhdGUuY29sdW1uU3RhdGUgPSB0aGlzLmdyaWRPcHRpb25zLmNvbHVtbkFwaS5nZXRDb2x1bW5TdGF0ZSgpO1xyXG4gICAgICAgICAgICB0aGlzLl9jdXJyZW50U3RhdGUucGl2b3RNb2RlID0gdGhpcy5ncmlkT3B0aW9ucy5jb2x1bW5BcGkuaXNQaXZvdE1vZGUoKTtcclxuICAgICAgICAgICAgdGhpcy5fY3VycmVudFN0YXRlLmdyb3VwU3RhdGUgPSB0aGlzLmdyaWRPcHRpb25zLmNvbHVtbkFwaS5nZXRDb2x1bW5Hcm91cFN0YXRlKCk7XHJcbiAgICAgICAgICAgIHJldHVybiB0aGlzLl9jdXJyZW50U3RhdGU7XHJcbiAgICAgICAgfTtcclxuICAgICAgICBsZXQgY2hlY2sgPSAoKTogYm9vbGVhbiA9PiB7XHJcbiAgICAgICAgICAgIHJldHVybiB0aGlzLl9pc0NoYW5naW5nU3RhdGUgPT09IGZhbHNlO1xyXG4gICAgICAgIH07XHJcbiAgICAgICAgcmV0dXJuIHRoaXMud2FpdChjaGVjaywgZ2V0U3RhdGUpO1xyXG4gICAgfVxyXG5cclxuICAgIC8qKlxyXG4gICAgICogcmVwbGFjZSBjdXJyZW50IHN0YXRlIGlmIGEgc3RhdGUgaXMgZ2l2ZW4sIGV4cGFuZEdyb3VwIGJhc2Ugb24gY29uZmlnXHJcbiAgICAgKiBzaG91bGQgd2FpdCB1bnRpbCBjb2x1bW4gaXMgcHJlc2VudC5cclxuICAgICAqIHBhcmFtIHtJVGFibGVQaXZvdFN0YXRlfSBfc3RhdGVcclxuICAgICAqL1xyXG4gICAgcHJpdmF0ZSBfc2V0UGl2b3RTdGF0ZShfc3RhdGU6IElUYWJsZVBpdm90U3RhdGUpOiB2b2lkIHtcclxuICAgICAgICBpZiAodHlwZW9mIChfc3RhdGUpID09PSAndW5kZWZpbmVkJyB8fCAhX3N0YXRlLmhhc093blByb3BlcnR5KCdjb2x1bW5TdGF0ZScpKSByZXR1cm47XHJcblxyXG4gICAgICAgIGxldCBzZXRTdGF0ZSA9ICgpOiB2b2lkID0+IHtcclxuICAgICAgICAgICAgdGhpcy5faXNDaGFuZ2luZ1N0YXRlID0gdHJ1ZTtcclxuICAgICAgICAgICAgaWYgKF9zdGF0ZS5jb2x1bW5TdGF0ZS5sZW5ndGggPT09IDApIHtcclxuICAgICAgICAgICAgICAgIHRoaXMuX2lzQ2hhbmdpbmdTdGF0ZSA9IGZhbHNlO1xyXG4gICAgICAgICAgICAgICAgdGhpcy5fcGl2b3RSZXNpemUoKTtcclxuICAgICAgICAgICAgICAgIHJldHVybjtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB0aGlzLl9jdXJyZW50U3RhdGUgPSBPYmplY3QuYXNzaWduKHRoaXMuX2N1cnJlbnRTdGF0ZSwgX3N0YXRlKTtcclxuICAgICAgICAgICAgdGhpcy5ncmlkT3B0aW9ucy5jb2x1bW5BcGkuc2V0Q29sdW1uU3RhdGUoX3N0YXRlLmNvbHVtblN0YXRlKTtcclxuICAgICAgICAgICAgdGhpcy5ncmlkT3B0aW9ucy5jb2x1bW5BcGkuc2V0UGl2b3RNb2RlKF9zdGF0ZS5waXZvdE1vZGUgfHwgZmFsc2UpO1xyXG4gICAgICAgICAgICB0aGlzLmdyaWRPcHRpb25zLmNvbHVtbkFwaS5zZXRDb2x1bW5Hcm91cFN0YXRlKF9zdGF0ZS5ncm91cFN0YXRlIHx8IFtdKTtcclxuICAgICAgICAgICAgdGhpcy5faXNDaGFuZ2luZ1N0YXRlID0gZmFsc2U7XHJcblxyXG4gICAgICAgICAgICB0aW1lcigxMDApLnN1YnNjcmliZSgoKTogdm9pZCA9PiB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLl9zZXRQaXZvdENvbHVtbnMoKTtcclxuICAgICAgICAgICAgICAgIHRoaXMuX2V4cGFuZEdyb3VwKCk7XHJcbiAgICAgICAgICAgIH0pO1xyXG4gICAgICAgIH07XHJcbiAgICAgICAgbGV0IGNoZWNrID0gKCk6IGJvb2xlYW4gPT4ge1xyXG4gICAgICAgICAgICByZXR1cm4gdGhpcy5jb2x1bW4gJiYgdGhpcy5jb2x1bW4ubGVuZ3RoID4gMDtcclxuICAgICAgICB9O1xyXG4gICAgICAgIHRoaXMud2FpdChjaGVjaywgc2V0U3RhdGUpO1xyXG4gICAgfVxyXG5cclxuICAgIC8qKlxyXG4gICAgICogd2FpdCBmb3Igc29tZXRoaW5nIHRvIGZpbmlzaCB0aGVuIGRvIHNvbWV0aGluZywgYnJlYWtzIGF0IDEwMHRoIHRvIHByZXZlbnQgaW5maW5pdGUgbG9vcFxyXG4gICAgICogcGFyYW0ge0lUYWJsZVBpdm90U3RhdGV9IF9zdGF0ZVxyXG4gICAgICogcmV0dXJuIHthbnl9XHJcbiAgICAgKi9cclxuICAgIHByaXZhdGUgd2FpdChfY2hlY2s6IEZ1bmN0aW9uLCBfZG86IEZ1bmN0aW9uLCBfbGltaXRDb3VudGVyID0gMCk6IGFueSB7XHJcbiAgICAgICAgaWYgKChfY2hlY2soKSAmJiB0aGlzLl90YWJsZVNlcnZpY2UuaXNBcGlSZWFkeSh0aGlzLmdyaWRPcHRpb25zKSkgfHwgX2xpbWl0Q291bnRlciA9PT0gMTAwKSB7XHJcbiAgICAgICAgICAgIGlmIChfbGltaXRDb3VudGVyID09PSAxMDApIGNvbnNvbGUubG9nKCdUaW1lb3V0OiBjaGVjayBmYWlscy4gcnVubmluZycsIF9kbyk7XHJcbiAgICAgICAgICAgIHJldHVybiBfZG8oKTtcclxuICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICB0aW1lcigxMCkuc3Vic2NyaWJlKCgpOiB2b2lkID0+IHtcclxuICAgICAgICAgICAgICAgIF9saW1pdENvdW50ZXIrKztcclxuICAgICAgICAgICAgICAgIHRoaXMud2FpdChfY2hlY2ssIF9kbywgX2xpbWl0Q291bnRlcik7XHJcbiAgICAgICAgICAgIH0pO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF9pc1Bpdm90RWxtRXhpc3QoX3Bpdm90RWxlbWVudCk6IGJvb2xlYW4ge1xyXG4gICAgICAgIHJldHVybiAoXHJcbiAgICAgICAgICAgIHR5cGVvZiBfcGl2b3RFbGVtZW50WydwaXZvdCddICE9PSAndW5kZWZpbmVkJyAmJlxyXG4gICAgICAgICAgICBfcGl2b3RFbGVtZW50WydwaXZvdCddICE9PSBudWxsICYmXHJcbiAgICAgICAgICAgIHR5cGVvZiBfcGl2b3RFbGVtZW50Wydjb2x1bW4tZHJvcCddICE9PSAndW5kZWZpbmVkJyAmJlxyXG4gICAgICAgICAgICBfcGl2b3RFbGVtZW50Wydjb2x1bW4tZHJvcCddICE9PSBudWxsXHJcbiAgICAgICAgKTtcclxuICAgIH1cclxuXHJcbiAgICAvKipcclxuICAgICAqIHNob3cgcGl2b3QgbW9kZSBjaGVja2JveCBhbmQgbGFiZWwuXHJcbiAgICAgKiB3aGVuIHBpdm90IG1vZGUgaXMgaGlkZGVuLCBhbGwgcGl2b3QgZGF0YSBoYXMgdG8gYmUgcmVzZXQuXHJcbiAgICAgKiBwYXJhbSB7Ym9vbGVhbiA9IHRydWV9IF9zaG93OiB0cnVlIHRvIHNob3csIGZhbHNlIHRvIGhpZGVcclxuICAgICAqL1xyXG4gICAgcHJpdmF0ZSBfc2hvd1Bpdm90TW9kZShfc2hvdzogYm9vbGVhbiA9IHRydWUpOiB2b2lkIHtcclxuICAgICAgICBsZXQgc2V0UGl2b3RNb2RlID0gKCk6IHZvaWQgPT4ge1xyXG4gICAgICAgICAgICBpZiAoX3Nob3cgPT09IHRydWUpIHtcclxuICAgICAgICAgICAgICAgIHRoaXMuX3Bpdm90RWxlbWVudFsncGl2b3QnXS5jbGFzc05hbWUgPSB0aGlzLl9waXZvdEVsZW1lbnRbJ3Bpdm90J10uY2xhc3NOYW1lLnJlcGxhY2UoLyBoaWRkZW4vZ2ksICcnKTtcclxuICAgICAgICAgICAgICAgIGZvciAobGV0IGk6IG51bWJlciA9IDA7IGkgPCB0aGlzLl9waXZvdEVsZW1lbnRbJ2NvbHVtbi1kcm9wJ10ubGVuZ3RoOyArK2kpIHtcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLl9waXZvdEVsZW1lbnRbJ2NvbHVtbi1kcm9wJ11baV0uY2xhc3NOYW1lID0gdGhpcy5fcGl2b3RFbGVtZW50Wydjb2x1bW4tZHJvcCddW2ldLmNsYXNzTmFtZS5yZXBsYWNlKC8gaGlkZGVuL2dpLCAnJyk7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICB0aGlzLl9zZXRQaXZvdFN0YXRlKHRoaXMuY29uZmlnLnBpdm90ICYmIHRoaXMuY29uZmlnLnBpdm90LnN0YXRlID8gdGhpcy5jb25maWcucGl2b3Quc3RhdGUgOiB7fSk7XHJcbiAgICAgICAgICAgICAgICByZXR1cm47XHJcbiAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgIGlmICh0aGlzLl9waXZvdEVsZW1lbnRbJ3Bpdm90J10gJiZcclxuICAgICAgICAgICAgICAgIHRoaXMuX3Bpdm90RWxlbWVudFsncGl2b3QnXS5jbGFzc05hbWUgJiZcclxuICAgICAgICAgICAgICAgIHRoaXMuX3Bpdm90RWxlbWVudFsncGl2b3QnXS5jbGFzc05hbWUuaW5kZXhPZignaGlkZGVuJykgPT09IC0xXHJcbiAgICAgICAgICAgICkge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5fcGl2b3RFbGVtZW50WydwaXZvdCddLmNsYXNzTmFtZSArPSAnIGhpZGRlbic7XHJcbiAgICAgICAgICAgICAgICBmb3IgKGxldCBqOiBudW1iZXIgPSAwOyBqIDwgdGhpcy5fcGl2b3RFbGVtZW50Wydjb2x1bW4tZHJvcCddLmxlbmd0aDsgKytqKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5fcGl2b3RFbGVtZW50Wydjb2x1bW4tZHJvcCddW2pdLmNsYXNzTmFtZSArPSAnIGhpZGRlbic7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgdGhpcy5fZW5hYmxlZFBpdm90TW9kZShmYWxzZSk7XHJcblxyXG4gICAgICAgICAgICB0aGlzLl9zZXRQaXZvdFN0YXRlKHtcclxuICAgICAgICAgICAgICAgICdjb2x1bW5TdGF0ZSc6IFtdLFxyXG4gICAgICAgICAgICAgICAgJ3Bpdm90TW9kZSc6IGZhbHNlLFxyXG4gICAgICAgICAgICAgICAgJ2dyb3VwU3RhdGUnOiBbXVxyXG4gICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgdGhpcy5fcmVzZXRQaXZvdENvbHVtbigpO1xyXG4gICAgICAgIH07XHJcbiAgICAgICAgbGV0IGNoZWNrID0gKCk6IGJvb2xlYW4gPT4ge1xyXG4gICAgICAgICAgICAvLyBpZiAodGhpcy5jb25maWcucGl2b3QudG9vbHBhbmVsLnR5cGUgPT09ICdub25lJyB8fCAhdGhpcy5jb25maWcucGl2b3QgfHwgIXRoaXMuY29uZmlnLnBpdm90LnRvb2xwYW5lbCkgcmV0dXJuIHRydWU7XHJcbiAgICAgICAgICAgIGlmICh0aGlzLmNvbmZpZy5waXZvdCAmJlxyXG4gICAgICAgICAgICAgICAgdGhpcy5jb25maWcucGl2b3QudG9vbHBhbmVsICYmXHJcbiAgICAgICAgICAgICAgICB0aGlzLmNvbmZpZy5waXZvdC50b29scGFuZWwudHlwZSAmJlxyXG4gICAgICAgICAgICAgICAgdGhpcy5jb25maWcucGl2b3QudG9vbHBhbmVsLnR5cGUgIT09ICdub25lJ1xyXG4gICAgICAgICAgICApIHtcclxuICAgICAgICAgICAgICAgIGxldCBpc1Bpdm90RWxtRXhpc3Q6IGJvb2xlYW4gPSB0aGlzLl9pc1Bpdm90RWxtRXhpc3QodGhpcy5fcGl2b3RFbGVtZW50KTtcclxuICAgICAgICAgICAgICAgIGlmIChpc1Bpdm90RWxtRXhpc3QgPT09IHRydWUpIHJldHVybiBpc1Bpdm90RWxtRXhpc3Q7XHJcblxyXG4gICAgICAgICAgICAgICAgbGV0IGRvbUVsZVF1ZXJ5OiBzdHJpbmcgPSAnIycgKyB0aGlzLmdyaWRJZCArICcuc3RnLXRoZW1lIC5hZy1zaWRlLWJhcic7XHJcbiAgICAgICAgICAgICAgICB0aGlzLl9waXZvdEVsZW1lbnRbJ3Bpdm90J10gPSB0aGlzLl92Y3IuZWxlbWVudC5uYXRpdmVFbGVtZW50LnF1ZXJ5U2VsZWN0b3IoZG9tRWxlUXVlcnkgKyAnIC5hZy1waXZvdC1tb2RlLXBhbmVsJyk7XHJcbiAgICAgICAgICAgICAgICB0aGlzLl9waXZvdEVsZW1lbnRbJ2NvbHVtbi1kcm9wJ10gPSB0aGlzLl92Y3IuZWxlbWVudC5uYXRpdmVFbGVtZW50LnF1ZXJ5U2VsZWN0b3JBbGwoZG9tRWxlUXVlcnkgKyAnIC5hZy1jb2x1bW4tZHJvcCcpO1xyXG4gICAgICAgICAgICAgICAgcmV0dXJuIHRoaXMuX2lzUGl2b3RFbG1FeGlzdCh0aGlzLl9waXZvdEVsZW1lbnQpO1xyXG4gICAgICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgcmV0dXJuIHRydWU7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9O1xyXG4gICAgICAgIHRoaXMud2FpdChjaGVjaywgc2V0UGl2b3RNb2RlKTtcclxuICAgIH1cclxuXHJcblxyXG4gICAgLyoqXHJcbiAgICAgKiBoaWRlIGFuZCBzaG93IHRvb2xwYW5lbCAocGl2b3QgbW9kZSBwYW5lbClcclxuICAgICAqIHBhcmFtIHtib29sZWFufSBfc2hvdzogdHJ1ZSB0byBzaG93LCBmYWxzZSB0byBoaWRlXHJcbiAgICAgKi9cclxuICAgIHByaXZhdGUgX3Nob3dUb29sUGFuZWwoX3Nob3c6IGJvb2xlYW4pOiB2b2lkIHtcclxuICAgICAgICBpZiAodGhpcy5fdGFibGVTZXJ2aWNlLmlzQXBpUmVhZHkodGhpcy5ncmlkT3B0aW9ucykpIHtcclxuICAgICAgICAgICAgdGltZXIoMTApLnN1YnNjcmliZSgoKTogdm9pZCA9PiB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLmdyaWRPcHRpb25zLmFwaS5zaG93VG9vbFBhbmVsKF9zaG93KTtcclxuICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIC8qKlxyXG4gICAgICogZXhwYW5kIHJvdyBncm91cCBiYXNlIG9uIHRoZSBzdGF0dXMgdGhhdCBwYXNzZWQgaW5cclxuICAgICAqIHBhcmFtIHtib29sZWFufSBfZXhwYW5kOiB0cnVlIHRvIGV4cGFuZCwgZmFsc2UgdG8gY29sbGFwc2VcclxuICAgICAqL1xyXG4gICAgcHJpdmF0ZSBfZXhwYW5kR3JvdXAoX2V4cGFuZD86IGJvb2xlYW4pOiB2b2lkIHtcclxuICAgICAgICBpZiAodHlwZW9mIF9leHBhbmQgPT09ICd1bmRlZmluZWQnKSB7XHJcbiAgICAgICAgICAgIF9leHBhbmQgPSBmYWxzZTtcclxuICAgICAgICAgICAgaWYgKHRoaXMuY29uZmlnLnBpdm90ICYmIHRoaXMuY29uZmlnLnBpdm90LnN0YXRlICYmIHRoaXMuY29uZmlnLnBpdm90LnN0YXRlLmV4cGFuZEdyb3VwKSB7XHJcbiAgICAgICAgICAgICAgICBfZXhwYW5kID0gdGhpcy5jb25maWcucGl2b3Quc3RhdGUuZXhwYW5kR3JvdXA7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICAgICAgaWYgKHRoaXMuX3RhYmxlU2VydmljZS5pc0FwaVJlYWR5KHRoaXMuZ3JpZE9wdGlvbnMpKSB7XHJcbiAgICAgICAgICAgIHRpbWVyKDEwKS5zdWJzY3JpYmUoKCk6IHZvaWQgPT4ge1xyXG4gICAgICAgICAgICAgICAgKF9leHBhbmQpID8gdGhpcy5ncmlkT3B0aW9ucy5hcGkuZXhwYW5kQWxsKCkgOiB0aGlzLmdyaWRPcHRpb25zLmFwaS5jb2xsYXBzZUFsbCgpO1xyXG4gICAgICAgICAgICAgICAgdGhpcy5fcGl2b3RSZXNpemUoKTtcclxuICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIC8qKlxyXG4gICAgICogdHVybiBvbiBhbmQgb2ZmIHBpdm90IG1vZGVcclxuICAgICAqIElmIG9uLCAnQ29sdW1uIExhYmVsJyB3aWxsIGFwcGVhclxyXG4gICAgICogSWYgb24sIHRpY2sgY29sdW1uIG5hbWUgb24gdG9vbHBhbmVsIHdpbGwgYXNzaWduIGNvbHVtbiB0byAnUm93IEdyb3VwJyAvICdWYWx1ZXMnIGRlcGVuZHMgb24gY29sRGVmXHJcbiAgICAgKiBJZiBvZmYsIHRpY2sgY29sdW1uIG5hbWUgb24gdG9vbHBhbmVsIHdpbGwgdHJpZ2dlciBjb2x1bW4gaGlkZSBhbmQgc2hvd1xyXG4gICAgICogcGFyYW0ge2Jvb2xlYW4gPSBmYWxzZX0gX2VuYWJsZWQ6IHRydWUgdG8gY2hlY2ssIGZhbHNlIHRvIHVuY2hlY2tcclxuICAgICAqL1xyXG4gICAgcHJpdmF0ZSBfZW5hYmxlZFBpdm90TW9kZShfZW5hYmxlZDogYm9vbGVhbiA9IGZhbHNlKTogdm9pZCB7XHJcbiAgICAgICAgdGhpcy5ncmlkT3B0aW9ucy5jb2x1bW5BcGkuc2V0UGl2b3RNb2RlKF9lbmFibGVkKTtcclxuICAgIH1cclxuXHJcbiAgICAvLyBUT0RPOiB0byBiZSByZXZpc2l0XHJcbiAgICAvKipcclxuICAgICAqIHN1cHByZXNzTW92YWJsZUNvbHVtbnMgb24gcGl2b3RDb2x1bW5zIGFuZCByb3dHcm91cENvbHVtbnNcclxuICAgICAqIGNvbHVtbnMgb24gcGl2b3QgbW9kZSBkb2VzIG5vdCBsaXN0ZW4gdG8gY29sRGVmLnN1cHByZXNzTW92YWJsZUNvbHVtbnMgPSB0cnVlXHJcbiAgICAgKiBoZW5jZSB3ZSBuZWVkIHRvIGFjY2VzcyB0aGVpciBwcml2YXRlIHZhcmlhYmxlIGxvY2tQb3NpdGlvbiBhbmQgbG9ja1Bpbm5lZCB0byBzdXBwcmVzcyB0aGUgY29sdW1uIG1vdmVtZW50XHJcbiAgICAgKiBwYXJhbSB7YW55fSBfY29sdW1ucyBbZWl0aGVyIHBhc3NlZCBpbiBmcm9tIGdyaWRFdmVudDogY29sdW1uIG9yIHdpbGwgZ2V0QWxsRGlzcGxheWVkQ29sdW1uc11cclxuICAgICAqL1xyXG4gICAgcHJpdmF0ZSBfc2V0UGl2b3RDb2x1bW5zKF9jb2x1bW5zPzogYW55KTogdm9pZCB7XHJcbiAgICAgICAgbGV0IGlzUGlubmVkOiBib29sZWFuID0gZmFsc2U7XHJcbiAgICAgICAgaWYgKCFfY29sdW1ucykgX2NvbHVtbnMgPSB0aGlzLmdyaWRPcHRpb25zLmNvbHVtbkFwaS5nZXRBbGxEaXNwbGF5ZWRDb2x1bW5zKCk7XHJcbiAgICAgICAgX2NvbHVtbnMuZm9yRWFjaCgoY29sdW1uOiBhbnkpID0+IHtcclxuICAgICAgICAgICAgdGhpcy5fc2V0Q29sdW1uKGNvbHVtbik7XHJcbiAgICAgICAgICAgIGxldCBjb2x1bW5EZWYgPSBjb2x1bW4uZ2V0Q29sRGVmKCk7XHJcbiAgICAgICAgICAgIGlmIChjb2x1bW5EZWYucGl2b3RWYWx1ZUNvbHVtbikge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5fc2V0Q29sdW1uKGNvbHVtbkRlZi5waXZvdFZhbHVlQ29sdW1uKVxyXG4gICAgICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgaWYgKGNvbHVtbi5wYXJlbnQpIHtcclxuICAgICAgICAgICAgICAgICAgICBpc1Bpbm5lZCA9IHRydWU7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5fc2V0Q29sdW1uKGNvbHVtbi5wYXJlbnQsIGZhbHNlKTtcclxuICAgICAgICAgICAgICAgICAgICBjb2x1bW4ucGFyZW50LnBpbm5lZCA9ICdsZWZ0JztcclxuICAgICAgICAgICAgICAgICAgICBjb2x1bW4ucGlubmVkID0gJ2xlZnQnO1xyXG4gICAgICAgICAgICAgICAgICAgIGNvbHVtbkRlZi5waW5uZWQgPSAnbGVmdCc7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9KTtcclxuICAgICAgICBpZiAoaXNQaW5uZWQpIHRoaXMuX3Jlc2l6ZUNvbHVtbih0cnVlKTtcclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF9zZXRDb2x1bW4oX2NvbHVtbjogYW55LCBfaXNTZXRDb2xEZWY6IGJvb2xlYW4gPSB0cnVlKTogdm9pZCB7XHJcbiAgICAgICAgaWYgKF9pc1NldENvbERlZikge1xyXG4gICAgICAgICAgICBsZXQgY29sdW1uRGVmID0gX2NvbHVtbi5nZXRDb2xEZWYoKTtcclxuICAgICAgICAgICAgY29sdW1uRGVmLnN1cHByZXNzTW92YWJsZSA9IHRoaXMuX3N1cHByZXNzTW92YWJsZUNvbHVtbnM7XHJcbiAgICAgICAgICAgIGNvbHVtbkRlZi5sb2NrUG9zaXRpb24gPSB0aGlzLl9zdXBwcmVzc01vdmFibGVDb2x1bW5zO1xyXG4gICAgICAgICAgICBjb2x1bW5EZWYubG9ja1Bpbm5lZCA9IHRoaXMuX3N1cHByZXNzTW92YWJsZUNvbHVtbnM7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGlmIChfY29sdW1uLnNldE1vdmluZykge1xyXG4gICAgICAgICAgICBfY29sdW1uLnNldE1vdmluZyghdGhpcy5fc3VwcHJlc3NNb3ZhYmxlQ29sdW1ucyk7XHJcbiAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgX2NvbHVtbi5tb3ZpbmcgPSAhdGhpcy5fc3VwcHJlc3NNb3ZhYmxlQ29sdW1ucztcclxuICAgICAgICB9XHJcbiAgICAgICAgX2NvbHVtbi5sb2NrUG9zaXRpb24gPSB0aGlzLl9zdXBwcmVzc01vdmFibGVDb2x1bW5zO1xyXG4gICAgICAgIF9jb2x1bW4ubG9ja1Bpbm5lZCA9IHRoaXMuX3N1cHByZXNzTW92YWJsZUNvbHVtbnM7XHJcbiAgICB9XHJcbiAgICAvLyBUT0RPOiB0byBiZSByZXZpc2l0XHJcblxyXG4gICAgLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy9cclxuICAgIC8vLyBDb2x1bW4vUm93L0NvbmZpZ3VyYXRpb24gR2VuZXJhdGlvblxyXG4gICAgLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy9cclxuICAgIHByaXZhdGUgX3NldEdyaWRPcHRpb25zKF90YWJsZUNvbmZpZzogSVRhYmxlQ29uZmlnKTogdm9pZCB7XHJcbiAgICAgICAgaWYgKF90YWJsZUNvbmZpZy5oYXNPd25Qcm9wZXJ0eSgnc3VwcHJlc3NNb3ZhYmxlQ29sdW1ucycpKSB0aGlzLl9zdXBwcmVzc01vdmFibGVDb2x1bW5zID0gX3RhYmxlQ29uZmlnLnN1cHByZXNzTW92YWJsZUNvbHVtbnM7XHJcbiAgICAgICAgdGhpcy5fZGlyZWN0aW9uID0gPCdydGwnIHwgJ2x0cic+dGhpcy5fZG9tU3ZjLmdldERvY3VtZW50RGlyZWN0aW9uKCk7XHJcbiAgICAgICAgdGhpcy5ncmlkT3B0aW9ucyA9IHRoaXMuX3RhYmxlU2VydmljZS5nZW5lcmF0ZUdyaWRPcHRpb25zKF90YWJsZUNvbmZpZywgdGhpcy5fZGlyZWN0aW9uKTtcclxuICAgICAgICB0aGlzLmdyaWRPcHRpb25zLmNvbnRleHRbJ2dyaWRJZCddID0gdGhpcy5ncmlkSWQ7XHJcbiAgICAgICAgdGhpcy5ncmlkT3B0aW9ucy5zdXBwcmVzc01vdmFibGVDb2x1bW5zID0gZmFsc2U7XHJcbiAgICAgICAgdGhpcy5ncmlkT3B0aW9ucy5vbkNvbHVtblJvd0dyb3VwQ2hhbmdlZCA9IChwYXJhbXM6IGFueSk6IHZvaWQgPT4ge1xyXG4gICAgICAgICAgICB0aGlzLl9zZXRQaXZvdENvbHVtbnMocGFyYW1zLmNvbHVtbnMpO1xyXG4gICAgICAgICAgICB0aGlzLl9leHBhbmRHcm91cCgpO1xyXG4gICAgICAgIH1cclxuICAgICAgICB0aGlzLl90YWJsZVNlcnZpY2Uuc2V0R3JpZE9wdGlvbnModGhpcy5ncmlkT3B0aW9ucyk7XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfc2V0Q29sdW1uRGVmKF9jb2xEZWZDb25maWc6IEFycmF5PElUYWJsZUNvbHVtbj4pOiB2b2lkIHtcclxuICAgICAgICB0aGlzLl90YWJsZVNlcnZpY2Uuc2V0Q29sdW1uRGVmKF9jb2xEZWZDb25maWcsIHRoaXMuY29uZmlnLCB0aGlzLl9zdXBwcmVzc01vdmFibGVDb2x1bW5zKTtcclxuICAgICAgICB0aGlzLl9yZXNpemVDb2x1bW4oKTtcclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF9lbmFibGVDb2x1bW5Nb3ZhYmxlKF9lbmFibGVkOiBib29sZWFuID0gdHJ1ZSk6IHZvaWQge1xyXG4gICAgICAgIGlmICh0aGlzLl90YWJsZVNlcnZpY2UuaXNBcGlSZWFkeSh0aGlzLmdyaWRPcHRpb25zKSkge1xyXG4gICAgICAgICAgICB0aGlzLl9zdXBwcmVzc01vdmFibGVDb2x1bW5zID0gX2VuYWJsZWQ7XHJcblxyXG4gICAgICAgICAgICB0aGlzLl9zZXRDb2x1bW5EZWYodGhpcy5jb2x1bW4pO1xyXG4gICAgICAgICAgICBpZiAodGhpcy5jb25maWcubG9hZFR5cGUgPT09ICdub3JtYWwnICYmIHRoaXMuY29uZmlnLnBpdm90LnRvb2xwYW5lbC50eXBlID09PSAncGl2b3QnKSB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLl9zZXRQaXZvdFN0YXRlKHRoaXMuX2N1cnJlbnRTdGF0ZSk7XHJcbiAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgIHRoaXMuX3Bpdm90UmVzaXplKCk7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX3NldFJvd0RhdGEoX3Jvd0RhdGE6IEFycmF5PGFueT4sIF9zZXRUb0dyaWRPcHRpb25zOiBib29sZWFuID0gdHJ1ZSk6IHZvaWQge1xyXG4gICAgICAgIC8vIHRoaXMuX3RhYmxlU2VydmljZS51cGRhdGVSb3dEYXRhV2l0aENvbHVtbkNvbmZpZyhfcm93RGF0YSwgdGhpcy5jb2x1bW4sIHRoaXMuZ3JpZElkKTtcclxuICAgICAgICB0aGlzLl90YWJsZVNlcnZpY2UudXBkYXRlUm93RGF0YVdpdGhDb2x1bW4oX3Jvd0RhdGEsIHRoaXMuY29sdW1uLCB0aGlzLmdyaWRJZCwgdGhpcy5ncmlkT3B0aW9ucyk7XHJcblxyXG4gICAgICAgIGlmIChfc2V0VG9HcmlkT3B0aW9ucykge1xyXG4gICAgICAgICAgICB0aGlzLl90YWJsZVNlcnZpY2Uuc2V0Um93RGF0YShfcm93RGF0YSk7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICBpZiAodGhpcy5fdGFibGVTZXJ2aWNlLmlzRW50ZXJwcmlzZU1vZGVsKHRoaXMuY29uZmlnLmxvYWRUeXBlKSAmJiB0aGlzLl90YWJsZVNlcnZpY2UuaXNBcGlSZWFkeSh0aGlzLmdyaWRPcHRpb25zKSkge1xyXG4gICAgICAgICAgICB0aGlzLl9ncmlkUmVhZHlFbnRlcnByaXNlQ3ljbGUoKTtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIHRpbWVyKCkuc3Vic2NyaWJlKCgpOiB2b2lkID0+IHtcclxuICAgICAgICAgICAgdGhpcy5fZ3JpZFNldFJvd0N5Y2xlKCk7XHJcbiAgICAgICAgICAgIHRoaXMuX3NldFRhYmxlQm9yZGVyQm90dG9tKCk7XHJcbiAgICAgICAgfSk7XHJcbiAgICB9XHJcblxyXG4gICAgLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy9cclxuICAgIC8vLyBFdmVudHMgLSBTdWJzY3JpYmVyIC8gT24gZnVuY3Rpb25zXHJcbiAgICAvLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vL1xyXG4gICAgcHJpdmF0ZSBfcHJvY2Vzc0V2ZW50UGFyYW1zPFQ+KF9mcm9tRXZlbnQ6IHN0cmluZywgX2FkZGl0aW9uYWxQYXJhbXM6IFQpOiB2b2lkIHtcclxuICAgICAgICBzd2l0Y2ggKF9mcm9tRXZlbnQpIHtcclxuICAgICAgICAgICAgY2FzZSAnZGF0YXNvdXJjZSc6XHJcbiAgICAgICAgICAgIGNhc2UgJ3NlbGVjdGlvbic6XHJcbiAgICAgICAgICAgIGNhc2UgJ2lucHV0JzpcclxuICAgICAgICAgICAgY2FzZSAnYnV0dG9uJzpcclxuICAgICAgICAgICAgICAgIHRoaXMuX2Jyb2FkY2FzdEV2ZW50UGFyYW1zPFQ+KF9hZGRpdGlvbmFsUGFyYW1zKTtcclxuICAgICAgICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgICAgICBkZWZhdWx0OlxyXG4gICAgICAgICAgICAgICAgY29uc29sZS5lcnJvcignS2RUYWJsZSB3YXJuaW5nOiBObyBzdWNoIGV2ZW50IGZvdW5kIGZvcjogJywgX2Zyb21FdmVudCk7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX2Jyb2FkY2FzdEV2ZW50UGFyYW1zPFQ+KF9wYXJhbXM6IFQpOiB2b2lkIHtcclxuICAgICAgICB0aGlzLl90YWJsZUludEV2ZW50LmtkVGFibGVFdmVudExpc3QodGhpcy5jb25maWcuaWQsIF9wYXJhbXMpO1xyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX2Jyb2FkY2FzdE1vZGVsQ2hhbmdlZEV2ZW50KCk6IHZvaWQge1xyXG4gICAgICAgIHRoaXMuX3RhYmxlSW50RXZlbnQubW9kZWxDaGFuZ2VkKHRoaXMuY29uZmlnLmlkKTtcclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF9zZXR1cFN1YnNjcmlwdGlvbkV2ZW50cygpIHtcclxuICAgICAgICB0aGlzLl9zdWJzY3JpcHRpb25PYmouc2VsZWN0Tm9kZXNTdWIgPSB0aGlzLl90YWJsZUludEV2ZW50Lm9uU2VsZWN0aW9uQ2hhbmdlZCh0aGlzLmNvbmZpZy5pZCkuc3Vic2NyaWJlKChfcm93Tm9kZTogUm93Tm9kZSk6IHZvaWQgPT4ge1xyXG4gICAgICAgICAgICB0aGlzLl91cGRhdGVTZWxlY3Rpb25Ob2Rlcyhfcm93Tm9kZSk7XHJcbiAgICAgICAgfSk7XHJcblxyXG4gICAgICAgIHRoaXMuX3N1YnNjcmlwdGlvbk9iai5ncmlkUXVlc3Rpb25TdWIgPSB0aGlzLl90YWJsZUludEV2ZW50Lm9uSW5wdXRDaGFuZ2VkKHRoaXMuY29uZmlnLmlkKS5zdWJzY3JpYmUoKF9mb3JtUGFyYW1zOiBJVGFibGVGb3JtRW1pdFBhcmFtcyk6IHZvaWQgPT4ge1xyXG4gICAgICAgICAgICB0aGlzLl9wcm9jZXNzSW5wdXRDaGFuZ2VkKF9mb3JtUGFyYW1zKTtcclxuICAgICAgICB9KTtcclxuXHJcbiAgICAgICAgdGhpcy5fc3Vic2NyaXB0aW9uT2JqLnVwZGF0ZUVtaXRSb3cgPSB0aGlzLl90YWJsZUludEV2ZW50Lm9uVXBkYXRlRW1pdFJvd05vZGVzKHRoaXMuY29uZmlnLmlkKS5zdWJzY3JpYmUoKF9kYXRhOiB7IGFjdGlvbjogc3RyaW5nLCByb3dEYXRhOiBhbnkgfSk6IHZvaWQgPT4ge1xyXG4gICAgICAgICAgICBpZiAoX2RhdGEuYWN0aW9uID09PSAnZGVsZXRlJykge1xyXG4gICAgICAgICAgICAgICAgbGV0IHJvd0tleTogc3RyaW5nID0gKHR5cGVvZiB0aGlzLmNvbmZpZy5yb3dJZEtleSAhPT0gJ3VuZGVmaW5lZCcpID8gdGhpcy5jb25maWcucm93SWRLZXkgOiAnaWQnO1xyXG4gICAgICAgICAgICAgICAgdGhpcy5fZGVsZXRlTm9kZUZyb21Sb3dEYXRhKFtfZGF0YS5yb3dEYXRhW3Jvd0tleV1dKTtcclxuICAgICAgICAgICAgICAgIHRoaXMuX2VtaXRJbnB1dFVwZGF0ZUV2ZW50KCk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9KTtcclxuICAgIH1cclxuXHJcbiAgICAvLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vL1xyXG4gICAgLy8vIFNlbGVjdGlvbiAtIENoZWNrYm94IC8gUmFkaW8gZnVuY3Rpb25zXHJcbiAgICAvLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vL1xyXG4gICAgcHJpdmF0ZSBfdXBkYXRlU2VsZWN0aW9uTm9kZXMoX3Jvd05vZGU6IFJvd05vZGUsIF9pc0luaXRpYWw/OiBib29sZWFuKTogdm9pZCB7XHJcbiAgICAgICAgbGV0IHRyaWdnZXJOb2RlOiBzdHJpbmcgPSAodHlwZW9mIF9pc0luaXRpYWwgIT09ICd1bmRlZmluZWQnICYmIF9pc0luaXRpYWwpID8gJ2luaXRpYWwnIDogJ2FsbCc7XHJcbiAgICAgICAgaWYgKHR5cGVvZiBfcm93Tm9kZSAhPT0gJ3VuZGVmaW5lZCcpIHtcclxuICAgICAgICAgICAgdHJpZ2dlck5vZGUgPSBfcm93Tm9kZS5kYXRhLmlkO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgbGV0IHNlbGVjdGlvblBhcmFtczogS2RUYWJsZVNlbGVjdGlvblVwZGF0ZUV2ZW50ID0gbmV3IEtkVGFibGVTZWxlY3Rpb25VcGRhdGVFdmVudCgpO1xyXG5cclxuICAgICAgICBzZWxlY3Rpb25QYXJhbXMudHJpZ2dlck5vZGUgPSB0cmlnZ2VyTm9kZTtcclxuICAgICAgICBzZWxlY3Rpb25QYXJhbXMuc2VsZWN0ZWROb2RlcyA9IHRoaXMuX3RhYmxlU2VydmljZS51cGRhdGVTZWxlY3Rpb25WYWx1ZXModGhpcy5ncmlkT3B0aW9ucy5yb3dEYXRhLCB0aGlzLmNvbmZpZy5zZWxlY3Rpb24udmFsdWUsIHRoaXMuY29uZmlnLnNlbGVjdGlvbi5yZXR1cm5LZXksIHRoaXMuY29uZmlnLmxvYWRUeXBlKTtcclxuICAgICAgICAvLyBzZWxlY3Rpb25QYXJhbXMuc2VsZWN0aW9uID0gKF9yb3dOb2RlLmlzU2VsZWN0ZWQoKSkgPyAnc2VsZWN0ZWQnIDogJ3Vuc2VsZWN0ZWQnO1xyXG5cclxuICAgICAgICB0aGlzLl9wcm9jZXNzRXZlbnRQYXJhbXM8S2RUYWJsZVNlbGVjdGlvblVwZGF0ZUV2ZW50Pignc2VsZWN0aW9uJywgc2VsZWN0aW9uUGFyYW1zKTtcclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF9wcm9jZXNzSW5pdGlhbFNlbGVjdGlvbigpOiB2b2lkIHtcclxuICAgICAgICB0aGlzLl91cGRhdGVTZWxlY3Rpb25Ob2Rlcyh1bmRlZmluZWQsIHRydWUpO1xyXG4gICAgfVxyXG5cclxuICAgIC8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vXHJcbiAgICAvLy8gSW5wdXQgZnVuY3Rpb25zXHJcbiAgICAvLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vL1xyXG4gICAgcHJpdmF0ZSBfcHJvY2Vzc0lucHV0Q2hhbmdlZChfZm9ybVBhcmFtczogSVRhYmxlRm9ybUVtaXRQYXJhbXMpOiB2b2lkIHtcclxuICAgICAgICBsZXQgaW5wdXRQYXJhbXM6IEtkVGFibGVJbnB1dFVwZGF0ZUV2ZW50ID0gbmV3IEtkVGFibGVJbnB1dFVwZGF0ZUV2ZW50KCk7XHJcblxyXG4gICAgICAgIGlucHV0UGFyYW1zLmNvbElkID0gX2Zvcm1QYXJhbXMuY29sSWQ7XHJcbiAgICAgICAgaW5wdXRQYXJhbXMucm93SWQgPSBfZm9ybVBhcmFtcy5yb3dJZDtcclxuICAgICAgICBpbnB1dFBhcmFtcy5xdWVzdGlvbktleSA9IF9mb3JtUGFyYW1zLnF1ZXN0aW9uS2V5O1xyXG4gICAgICAgIGlucHV0UGFyYW1zLnF1ZXN0aW9uID0gX2Zvcm1QYXJhbXMucXVlc3Rpb247XHJcbiAgICAgICAgaW5wdXRQYXJhbXMudmFsdWUgPSBfZm9ybVBhcmFtcy5kYXRhO1xyXG5cclxuICAgICAgICB0aGlzLl9wcm9jZXNzRXZlbnRQYXJhbXM8S2RUYWJsZUlucHV0VXBkYXRlRXZlbnQ+KCdpbnB1dCcsIGlucHV0UGFyYW1zKTtcclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF9lbWl0SW5wdXRVcGRhdGVFdmVudCgpOiB2b2lkIHtcclxuICAgICAgICBsZXQgaW5wdXRQYXJhbXM6IEtkVGFibGVJbnB1dFVwZGF0ZUV2ZW50ID0gbmV3IEtkVGFibGVJbnB1dFVwZGF0ZUV2ZW50KCk7XHJcbiAgICAgICAgdGhpcy5fcHJvY2Vzc0V2ZW50UGFyYW1zPEtkVGFibGVJbnB1dFVwZGF0ZUV2ZW50PignaW5wdXQnLCBpbnB1dFBhcmFtcyk7XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfZGVsZXRlTm9kZUZyb21Sb3dEYXRhKF9kYXRhTGlzdDogQXJyYXk8c3RyaW5nPik6IHZvaWQge1xyXG4gICAgICAgIGxldCByb3dJZEtleTogc3RyaW5nID0gKHR5cGVvZiB0aGlzLmNvbmZpZy5yb3dJZEtleSAhPT0gJ3VuZGVmaW5lZCcpID8gdGhpcy5jb25maWcucm93SWRLZXkgOiAnaWQnO1xyXG5cclxuICAgICAgICBmb3IgKGxldCBpOiBudW1iZXIgPSAwOyBpIDwgX2RhdGFMaXN0Lmxlbmd0aDsgKytpKSB7XHJcbiAgICAgICAgICAgIGZvciAobGV0IGo6IG51bWJlciA9IDA7IGogPCB0aGlzLnJvdy5sZW5ndGg7ICsraikge1xyXG4gICAgICAgICAgICAgICAgaWYgKF9kYXRhTGlzdFtpXS50b1N0cmluZygpID09PSB0aGlzLnJvd1tqXVtyb3dJZEtleV0udG9TdHJpbmcoKSkge1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMucm93LnNwbGljZShqLCAxKTtcclxuICAgICAgICAgICAgICAgICAgICBicmVhaztcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICAvLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vL1xyXG4gICAgLy8vIEVudGVycHJpc2UgZGF0YXNvdXJjZSBmdW5jdGlvbnNcclxuICAgIC8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vXHJcbiAgICBwcml2YXRlIF9jbGVhckRhdGFzb3VyY2UoKTogdm9pZCB7XHJcbiAgICAgICAgaWYgKHRoaXMuX3RhYmxlU2VydmljZS5pc0FwaVJlYWR5KHRoaXMuZ3JpZE9wdGlvbnMpKSB7XHJcbiAgICAgICAgICAgIHRoaXMuZ3JpZE9wdGlvbnMuYXBpLnNldEVudGVycHJpc2VEYXRhc291cmNlKG51bGwpO1xyXG4gICAgICAgICAgICB0aGlzLmdyaWRPcHRpb25zLmFwaS5zZXRGaWx0ZXJNb2RlbChudWxsKTtcclxuICAgICAgICAgICAgdGhpcy5ncmlkT3B0aW9ucy5hcGkuc2V0U29ydE1vZGVsKG51bGwpO1xyXG5cclxuICAgICAgICAgICAgaWYgKHR5cGVvZiB0aGlzLl9zdWJzY3JpcHRpb25PYmouZGF0YXNvdXJjZVN1YiAhPT0gJ3VuZGVmaW5lZCcpIHtcclxuICAgICAgICAgICAgICAgIHRoaXMuX3N1YnNjcmlwdGlvbk9iai5kYXRhc291cmNlU3ViLnVuc3Vic2NyaWJlKCk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfZ2VuZXJhdGVFbnRlcnByaXNlRGF0YXNvdXJjZSgpOiB2b2lkIHtcclxuICAgICAgICBsZXQgZGF0YXNvdXJjZTogSUVudGVycHJpc2VEYXRhc291cmNlID0ge1xyXG4gICAgICAgICAgICBnZXRSb3dzOiAoX3BhcmFtczogSUVudGVycHJpc2VHZXRSb3dzUGFyYW1zKTogdm9pZCA9PiB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLl9zaG93TG9hZGluZ092ZXJsYXkodHJ1ZSk7XHJcblxyXG4gICAgICAgICAgICAgICAgaWYgKHR5cGVvZiB0aGlzLl9zdWJzY3JpcHRpb25PYmouZGF0YXNvdXJjZVN1YiAhPT0gJ3VuZGVmaW5lZCcpIHtcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLl9zdWJzY3JpcHRpb25PYmouZGF0YXNvdXJjZVN1Yi51bnN1YnNjcmliZSgpO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgdGhpcy5fc3Vic2NyaXB0aW9uT2JqLmRhdGFzb3VyY2VTdWIgPSB0aGlzLl9nZW5lcmF0ZURhdGFzb3VyY2VSb3dzKF9wYXJhbXMpLnN1YnNjcmliZSgoX3Jlc3BvbnNlOiBJVGFibGVEYXRhc291cmNlUGFyYW1zKTogdm9pZCA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgX3BhcmFtcy5zdWNjZXNzQ2FsbGJhY2soX3Jlc3BvbnNlLnJvd3MsIF9yZXNwb25zZS50b3RhbCk7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5fc2hvd0xvYWRpbmdPdmVybGF5KGZhbHNlKTtcclxuICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfTtcclxuXHJcbiAgICAgICAgdGhpcy5ncmlkT3B0aW9ucy5hcGkuc2V0RW50ZXJwcmlzZURhdGFzb3VyY2UoZGF0YXNvdXJjZSk7XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfZ2VuZXJhdGVEYXRhc291cmNlUm93cyhfZGF0YXNvdXJjZVBhcmFtczogSUVudGVycHJpc2VHZXRSb3dzUGFyYW1zKTogT2JzZXJ2YWJsZTxJVGFibGVEYXRhc291cmNlUGFyYW1zPiB7XHJcbiAgICAgICAgcmV0dXJuIG5ldyBPYnNlcnZhYmxlPElUYWJsZURhdGFzb3VyY2VQYXJhbXM+KChfb2JzZXJ2ZXI6IFN1YnNjcmliZXI8SVRhYmxlRGF0YXNvdXJjZVBhcmFtcz4pOiB2b2lkID0+IHtcclxuICAgICAgICAgICAgc3dpdGNoICh0aGlzLmNvbmZpZy5sb2FkVHlwZSkge1xyXG4gICAgICAgICAgICAgICAgY2FzZSAnaW5maW5pdGUnOlxyXG4gICAgICAgICAgICAgICAgY2FzZSAnb25lc2hvdCc6XHJcbiAgICAgICAgICAgICAgICAgICAgKDxLZFRhYmxlRW50ZXJwcmlzZVN2Yz50aGlzLl90YWJsZVNlcnZpY2UpLmdlbmVyYXRlRGF0YXNvdXJjZVJvd3MoX2RhdGFzb3VyY2VQYXJhbXMucmVxdWVzdCwgdGhpcy5ncmlkT3B0aW9ucy5yb3dEYXRhLnNsaWNlKCkpLnN1YnNjcmliZSgoX3Jlc3BvbnNlOiBJVGFibGVEYXRhc291cmNlUGFyYW1zKTogdm9pZCA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIF9vYnNlcnZlci5uZXh0KF9yZXNwb25zZSk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIF9vYnNlcnZlci5jb21wbGV0ZSgpO1xyXG4gICAgICAgICAgICAgICAgICAgIH0pO1xyXG5cclxuICAgICAgICAgICAgICAgICAgICBicmVhaztcclxuICAgICAgICAgICAgICAgIGNhc2UgJ3NlcnZlcic6XHJcbiAgICAgICAgICAgICAgICAgICAgbGV0IHNlcnZlclBhcmFtczogS2RUYWJsZURhdGFzb3VyY2VFdmVudCA9IG5ldyBLZFRhYmxlRGF0YXNvdXJjZUV2ZW50KF9kYXRhc291cmNlUGFyYW1zLnJlcXVlc3QsIF9vYnNlcnZlcik7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5fcHJvY2Vzc0V2ZW50UGFyYW1zPEtkVGFibGVEYXRhc291cmNlRXZlbnQ+KCdkYXRhc291cmNlJywgc2VydmVyUGFyYW1zKTtcclxuXHJcbiAgICAgICAgICAgICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgICAgICAgICBkZWZhdWx0OlxyXG4gICAgICAgICAgICAgICAgICAgIGNvbnNvbGUuZXJyb3IoJ0tkVGFibGUgd2FybmluZzogTm8gc3VjaCBsb2FkVHlwZSBmaW5kIGZvcjogJywgdGhpcy5jb25maWcubG9hZFR5cGUpO1xyXG4gICAgICAgICAgICAgICAgICAgIF9vYnNlcnZlci5jb21wbGV0ZSgpO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfSk7XHJcbiAgICB9XHJcblxyXG4gICAgLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy9cclxuICAgIC8vLyBBUEkgZnVuY3Rpb25zXHJcbiAgICAvLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vL1xyXG4gICAgcHJpdmF0ZSBfaW5pdElUYWJsZUFwaSgpOiB2b2lkIHtcclxuICAgICAgICBpZiAodHlwZW9mIHRoaXMuYXBpICE9PSAndW5kZWZpbmVkJykge1xyXG4gICAgICAgICAgICBsZXQgYXBpUGFyYW1zOiBhbnkgPSB7XHJcbiAgICAgICAgICAgICAgICAvLyBncmlkT3B0aW9uczogdGhpcy5ncmlkT3B0aW9ucyxcclxuICAgICAgICAgICAgICAgIGV2ZW50OiB0aGlzLl90YWJsZUludEV2ZW50LFxyXG4gICAgICAgICAgICAgICAgaWQ6IHRoaXMuY29uZmlnLmlkLFxyXG4gICAgICAgICAgICAgICAgcm93czogdGhpcy5yb3csXHJcbiAgICAgICAgICAgICAgICBjb2x1bW5zOiB0aGlzLmNvbHVtblxyXG4gICAgICAgICAgICB9O1xyXG5cclxuICAgICAgICAgICAgdGhpcy5fdGFibGVTZXJ2aWNlLmdlbmVyYXRlZEFwaUZ1bmN0aW9ucyh0aGlzLmFwaSwgYXBpUGFyYW1zKTtcclxuXHJcbiAgICAgICAgICAgIC8vLyBUZW1wIGZpeCB0byBhY2Nlc3MgbG9hZGluZyB2YXJpYWJsZSAvL1xyXG4gICAgICAgICAgICAvKioqKioqKioqIEdlbmVyYWwgQVBJICoqKioqKioqKiovXHJcbiAgICAgICAgICAgIHRoaXMuYXBpLmdlbmVyYWwuc2hvd0xvYWRpbmcgPSAoX3RvZ2dsZTogYm9vbGVhbik6IHZvaWQgPT4ge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5kaXNwbGF5TG9hZGluZyA9IF90b2dnbGU7XHJcbiAgICAgICAgICAgIH07XHJcblxyXG4gICAgICAgICAgICB0aGlzLmFwaS5nZW5lcmFsLnVwZGF0ZUNlbGwgPSAoX3RhYmxlQ2VsbFBhcmFtczogSVRhYmxlQ2VsbFBhcmFtcyk6IHZvaWQgPT4ge1xyXG4gICAgICAgICAgICAgICAgbGV0IHRvVXBkYXRlTm9kZTogQXJyYXk8Um93Tm9kZT4gPSBbXTtcclxuXHJcbiAgICAgICAgICAgICAgICB0aGlzLmdyaWRPcHRpb25zLmFwaS5mb3JFYWNoTm9kZSgoX3Jvd05vZGU6IFJvd05vZGUpOiB2b2lkID0+IHtcclxuICAgICAgICAgICAgICAgICAgICBpZiAodHlwZW9mIF9yb3dOb2RlLmlkICE9PSAndW5kZWZpbmVkJyAmJiBfcm93Tm9kZS5pZCA9PT0gX3RhYmxlQ2VsbFBhcmFtcy5yb3dJZCkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBfcm93Tm9kZS5kYXRhW190YWJsZUNlbGxQYXJhbXMuY29sSWRdID0gX3RhYmxlQ2VsbFBhcmFtcy5kYXRhO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB0b1VwZGF0ZU5vZGUucHVzaChfcm93Tm9kZSk7XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgfSk7XHJcblxyXG4gICAgICAgICAgICAgICAgbGV0IHJlZnJlc2hQYXJhbXM6IHsgcm93Tm9kZXM6IEFycmF5PFJvd05vZGU+LCBjb2x1bW5zOiBBcnJheTxhbnk+IH0gPSB7XHJcbiAgICAgICAgICAgICAgICAgICAgcm93Tm9kZXM6IHRvVXBkYXRlTm9kZSxcclxuICAgICAgICAgICAgICAgICAgICBjb2x1bW5zOiBbX3RhYmxlQ2VsbFBhcmFtcy5jb2xJZF1cclxuICAgICAgICAgICAgICAgIH07XHJcblxyXG4gICAgICAgICAgICAgICAgdGhpcy5ncmlkT3B0aW9ucy5hcGkucmVmcmVzaENlbGxzKHJlZnJlc2hQYXJhbXMpO1xyXG4gICAgICAgICAgICB9O1xyXG5cclxuICAgICAgICAgICAgdGhpcy5hcGkuZ2VuZXJhbC5zZWFyY2hSb3cgPSAoX3NlYXJjaFRleHQ6IHN0cmluZyk6IHZvaWQgPT4ge1xyXG4gICAgICAgICAgICAgICAgaWYgKHRoaXMuY29uZmlnLmxvYWRUeXBlID09PSAnbm9ybWFsJykge1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuZ3JpZE9wdGlvbnMuYXBpLnNldFF1aWNrRmlsdGVyKF9zZWFyY2hUZXh0KTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgICAgIGNvbnNvbGUud2FybignS2RUYWJsZSB3YXJuaW5nOiBRdWljayBmaWx0ZXJpbmcgb2YgZGF0YSBpcyBub3Qgc3VwcG9ydGVkIGZvciBvbmVzaG90L3NlcnZlci9pbmZpbml0ZSBsb2FkVHlwZS4nKTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfTtcclxuXHJcbiAgICAgICAgICAgIHRoaXMuYXBpLmdlbmVyYWwuYWRkUm93cyA9IChfcm93czogQXJyYXk8YW55PiwgX3Njcm9sbFRvVmlzaWJsZTogYm9vbGVhbiA9IGZhbHNlKTogdm9pZCA9PiB7XHJcbiAgICAgICAgICAgICAgICAvKlxyXG4gICAgICAgICAgICAgICAgICAgIGFnLUdyaWQgZGlkIG5vdCBleHBvcnQgUm93RGF0YVRyYW5zYWN0aW9uIGludGVyZmFjZS4gSW50ZXJmYWNlIGFzOlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBhZGQ6IFtdLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcmVtb3ZlOiBbXSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHVwZGF0ZTogW11cclxuICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICovXHJcbiAgICAgICAgICAgICAgICBpZiAodHlwZW9mIHRoaXMuY29uZmlnLmxvYWRUeXBlID09PSAndW5kZWZpbmVkJyB8fCB0aGlzLmNvbmZpZy5sb2FkVHlwZSA9PT0gJ25vcm1hbCcpIHtcclxuICAgICAgICAgICAgICAgICAgICBsZXQgcm93S2V5OiBzdHJpbmcgPSAodHlwZW9mIHRoaXMuY29uZmlnLnJvd0lkS2V5ICE9PSAndW5kZWZpbmVkJykgPyB0aGlzLmNvbmZpZy5yb3dJZEtleSA6ICdpZCc7XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIGZvciAobGV0IGk6IG51bWJlciA9IDA7IGkgPCBfcm93cy5sZW5ndGg7ICsraSkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLnJvdy5wdXNoKF9yb3dzW2ldKTtcclxuICAgICAgICAgICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuX3NldFJvd0RhdGEodGhpcy5yb3csIGZhbHNlKTtcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLmdyaWRPcHRpb25zLmFwaS51cGRhdGVSb3dEYXRhKHsgYWRkOiBfcm93cy5zbGljZSgpIH0pO1xyXG5cclxuICAgICAgICAgICAgICAgICAgICBpZiAoX3Njcm9sbFRvVmlzaWJsZSkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLmdyaWRPcHRpb25zLmFwaS5lbnN1cmVJbmRleFZpc2libGUodGhpcy5ncmlkT3B0aW9ucy5hcGkuZ2V0Um93Tm9kZShfcm93c1swXVtyb3dLZXldLnRvU3RyaW5nKCkpLnJvd0luZGV4KTtcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgICAgICAgICBjb25zb2xlLndhcm4oJ0tkVGFibGUgd2FybmluZzogQVBJIGZ1bmN0aW9uOiBhZGRSb3dzKCkgY2FuIG9ubHkgYmUgdXNlZCBmb3Igbm9ybWFsIGxvYWRUeXBlLicpO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9O1xyXG5cclxuICAgICAgICAgICAgdGhpcy5hcGkuZ2VuZXJhbC5kZWxldGVSb3dzID0gKF9pZDogQXJyYXk8c3RyaW5nIHwgbnVtYmVyPiB8IHN0cmluZyB8IG51bWJlcik6IHZvaWQgPT4ge1xyXG4gICAgICAgICAgICAgICAgaWYgKHR5cGVvZiB0aGlzLmNvbmZpZy5sb2FkVHlwZSA9PT0gJ3VuZGVmaW5lZCcgfHwgdGhpcy5jb25maWcubG9hZFR5cGUgPT09ICdub3JtYWwnKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgbGV0IGRlbGV0ZUlkTGlzdDogQXJyYXk8c3RyaW5nPiA9IFtdO1xyXG5cclxuICAgICAgICAgICAgICAgICAgICBpZiAodHlwZW9mIF9pZCA9PT0gJ3N0cmluZycgfHwgdHlwZW9mIF9pZCA9PT0gJ251bWJlcicpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgZGVsZXRlSWRMaXN0LnB1c2goX2lkLnRvU3RyaW5nKCkpO1xyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgZm9yIChsZXQgaTogbnVtYmVyID0gMDsgaSA8IF9pZC5sZW5ndGg7ICsraSkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgZGVsZXRlSWRMaXN0LnB1c2goX2lkLnRvU3RyaW5nKCkpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgICAgICAgICB0aGlzLl9kZWxldGVOb2RlRnJvbVJvd0RhdGEoZGVsZXRlSWRMaXN0KTtcclxuXHJcbiAgICAgICAgICAgICAgICAgICAgbGV0IGtleTogc3RyaW5nID0gdHlwZW9mIHRoaXMuY29uZmlnLnJvd0lkS2V5ID09PSAndW5kZWZpbmVkJyA/ICdpZCcgOiB0aGlzLmNvbmZpZy5yb3dJZEtleTtcclxuICAgICAgICAgICAgICAgICAgICBsZXQgZGVsZXRlUm93czogQXJyYXk8YW55PiA9IFtdO1xyXG5cclxuICAgICAgICAgICAgICAgICAgICBmb3IgKGxldCBpOiBudW1iZXIgPSAwOyBpIDwgZGVsZXRlSWRMaXN0Lmxlbmd0aDsgKytpKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGRlbGV0ZVJvd3MucHVzaCh7IFtrZXldOiBkZWxldGVJZExpc3RbaV0gfSk7XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgICAgICAgICAvKlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBhZy1HcmlkIGRpZCBub3QgZXhwb3J0IFJvd0RhdGFUcmFuc2FjdGlvbiBpbnRlcmZhY2UuIEludGVyZmFjZSBhczpcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBhZGQ6IFtdLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJlbW92ZTogW10sXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdXBkYXRlOiBbXVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAqL1xyXG5cclxuICAgICAgICAgICAgICAgICAgICBsZXQgdHJhbnNhY3Rpb25PYmo6IHsgYWRkPzogQXJyYXk8YW55PiwgcmVtb3ZlPzogQXJyYXk8YW55PiwgdXBkYXRlPzogQXJyYXk8YW55PiB9ID0ge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICByZW1vdmU6IGRlbGV0ZVJvd3NcclxuICAgICAgICAgICAgICAgICAgICB9O1xyXG5cclxuICAgICAgICAgICAgICAgICAgICB0aGlzLmdyaWRPcHRpb25zLmFwaS51cGRhdGVSb3dEYXRhKHRyYW5zYWN0aW9uT2JqKTtcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLl9lbWl0SW5wdXRVcGRhdGVFdmVudCgpO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgZWxzZSB7XHJcbiAgICAgICAgICAgICAgICAgICAgY29uc29sZS53YXJuKCdLZFRhYmxlIHdhcm5pbmc6IEFQSSBmdW5jdGlvbjogYWRkUm93cygpIGNhbiBvbmx5IGJlIHVzZWQgZm9yIG5vcm1hbCBsb2FkVHlwZS4nKTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfTtcclxuXHJcbiAgICAgICAgICAgIHRoaXMuYXBpLmdlbmVyYWwuc2V0QnV0dG9uRGlzYWJsZWQgPSAoX2J1dHRvblR5cGU6IHN0cmluZywgX3RvRGlzYWJsZWQ6IGJvb2xlYW4pID0+IHtcclxuICAgICAgICAgICAgICAgIGZvciAobGV0IGk6IG51bWJlciA9IDA7IGkgPCB0aGlzLmNvbmZpZy5idXR0b24ubGVuZ3RoOyArK2kpIHtcclxuICAgICAgICAgICAgICAgICAgICBpZiAodGhpcy5jb25maWcuYnV0dG9uW2ldLnR5cGUgPT09IF9idXR0b25UeXBlKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuY29uZmlnLmJ1dHRvbltpXS5kaXNhYmxlZCA9IF90b0Rpc2FibGVkO1xyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfTtcclxuXHJcbiAgICAgICAgICAgIHRoaXMuYXBpLmdlbmVyYWwuZXhwb3J0VG9FeGNlbCA9IChfcGFyYW1zOiBFeGNlbEV4cG9ydFBhcmFtcyk6IHZvaWQgPT4ge1xyXG4gICAgICAgICAgICAgICAgbGV0IGRlZmF1bHRQYXJhbXM6IEV4Y2VsRXhwb3J0UGFyYW1zID0ge1xyXG4gICAgICAgICAgICAgICAgICAgIGZpbGVOYW1lOiAnZmlsZScsXHJcbiAgICAgICAgICAgICAgICAgICAgYWxsQ29sdW1uczogdHJ1ZSxcclxuICAgICAgICAgICAgICAgICAgICBzdXBwcmVzc1RleHRBc0NEQVRBOiB0cnVlLFxyXG4gICAgICAgICAgICAgICAgfTtcclxuICAgICAgICAgICAgICAgIC8vIHhsc3ggb25seSBhbGxvdyBzaGVldCBuYW1lIHRvIGJlIDMxIGNoYXJhY3RlcnMgbG9uZztcclxuICAgICAgICAgICAgICAgIGlmIChfcGFyYW1zLmhhc093blByb3BlcnR5KCdzaGVldE5hbWUnKSkgX3BhcmFtcy5zaGVldE5hbWUgPSBfcGFyYW1zLnNoZWV0TmFtZS5zbGljZSgwLCAzMSk7XHJcbiAgICAgICAgICAgICAgICBsZXQgcGFyYW1zOiBFeGNlbEV4cG9ydFBhcmFtcyA9IE9iamVjdC5hc3NpZ24oe30sIGRlZmF1bHRQYXJhbXMsIF9wYXJhbXMpO1xyXG4gICAgICAgICAgICAgICAgbGV0IGNvbnRlbnQ6IGFueSA9IHRoaXMuZ3JpZE9wdGlvbnMuYXBpLmdldERhdGFBc0V4Y2VsKHBhcmFtcyk7XHJcbiAgICAgICAgICAgICAgICBsZXQgd29ya2Jvb2s6IGFueSA9IFhMU1gucmVhZChjb250ZW50LCB7IHR5cGU6ICdiaW5hcnknIH0pO1xyXG4gICAgICAgICAgICAgICAgbGV0IHhsc3hDb250ZW50OiBhbnkgPSBYTFNYLndyaXRlKHdvcmtib29rLCB7IGJvb2tUeXBlOiAneGxzeCcsIHR5cGU6ICdiYXNlNjQnIH0pO1xyXG4gICAgICAgICAgICAgICAgbGV0IGJsb2JPYmplY3Q6IEJsb2IgPSB0aGlzLl90YWJsZVNlcnZpY2UuYjY0dG9CbG9iKHhsc3hDb250ZW50LCAnYXBwbGljYXRpb24vdm5kLm9wZW54bWxmb3JtYXRzLW9mZmljZWRvY3VtZW50LnNwcmVhZHNoZWV0bWwuc2hlZXQnKTtcclxuICAgICAgICAgICAgICAgIHNhdmVBcyhibG9iT2JqZWN0LCBwYXJhbXMuZmlsZU5hbWUgKyAnLnhsc3gnKTtcclxuICAgICAgICAgICAgfTtcclxuXHJcbiAgICAgICAgICAgIHRoaXMuYXBpLmdlbmVyYWwucmVzaXplQ29sdW1uID0gKF9pc1Jlc2l6ZVRvQ29udGVudDogYm9vbGVhbiA9IGZhbHNlKTogdm9pZCA9PiB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLl9yZXNpemVDb2x1bW4oX2lzUmVzaXplVG9Db250ZW50KTtcclxuICAgICAgICAgICAgfTtcclxuXHJcbiAgICAgICAgICAgIHRoaXMuYXBpLmdlbmVyYWwuZW5hYmxlQ29sdW1uTW92YWJsZSA9IChfZW5hYmxlZDogYm9vbGVhbik6IHZvaWQgPT4ge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5fZW5hYmxlQ29sdW1uTW92YWJsZShfZW5hYmxlZCk7XHJcbiAgICAgICAgICAgIH07XHJcblxyXG4gICAgICAgICAgICAvKioqKioqKioqIFBpdm90IEFQSSAqKioqKioqKioqL1xyXG4gICAgICAgICAgICBpZiAodHlwZW9mICh0aGlzLmFwaS5waXZvdCkgPT09ICd1bmRlZmluZWQnKSB0aGlzLmFwaS5waXZvdCA9IHt9O1xyXG4gICAgICAgICAgICB0aGlzLmFwaS5waXZvdC5hdXRvUmVzaXplID0gKCk6IHZvaWQgPT4ge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5fcGl2b3RSZXNpemUoKTtcclxuICAgICAgICAgICAgfTtcclxuXHJcbiAgICAgICAgICAgIHRoaXMuYXBpLnBpdm90LnNob3dUb29sUGFuZWwgPSAoX3Nob3c6IGJvb2xlYW4pOiB2b2lkID0+IHtcclxuICAgICAgICAgICAgICAgIHRoaXMuX3Nob3dUb29sUGFuZWwoX3Nob3cpO1xyXG4gICAgICAgICAgICB9O1xyXG5cclxuICAgICAgICAgICAgdGhpcy5hcGkucGl2b3QuZXhwYW5kR3JvdXAgPSAoX2V4cGFuZDogYm9vbGVhbik6IHZvaWQgPT4ge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5fZXhwYW5kR3JvdXAoX2V4cGFuZCk7XHJcbiAgICAgICAgICAgIH07XHJcblxyXG4gICAgICAgICAgICB0aGlzLmFwaS5waXZvdC5nZXRQaXZvdFN0YXRlID0gKCk6IElUYWJsZVBpdm90U3RhdGUgPT4ge1xyXG4gICAgICAgICAgICAgICAgcmV0dXJuIHRoaXMuX2dldFBpdm90U3RhdGUoKTtcclxuICAgICAgICAgICAgfTtcclxuXHJcbiAgICAgICAgICAgIHRoaXMuYXBpLnBpdm90LnNldFBpdm90U3RhdGUgPSAoX3N0YXRlOiBJVGFibGVQaXZvdFN0YXRlKTogdm9pZCA9PiB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLl9zZXRDb2x1bW5EZWYodGhpcy5jb2x1bW4pO1xyXG4gICAgICAgICAgICAgICAgdGhpcy5fc2V0UGl2b3RTdGF0ZShfc3RhdGUpO1xyXG4gICAgICAgICAgICB9O1xyXG5cclxuICAgICAgICAgICAgdGhpcy5hcGkucGl2b3QuZW5hYmxlZFBpdm90TW9kZSA9IChfZW5hYmxlZDogYm9vbGVhbik6IHZvaWQgPT4ge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5fZW5hYmxlZFBpdm90TW9kZShfZW5hYmxlZCk7XHJcbiAgICAgICAgICAgIH07XHJcblxyXG4gICAgICAgICAgICB0aGlzLmFwaS5waXZvdC5zaG93UGl2b3RNb2RlID0gKF9zaG93OiBib29sZWFuKTogdm9pZCA9PiB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLl9zaG93UGl2b3RNb2RlKF9zaG93KTtcclxuICAgICAgICAgICAgfTtcclxuXHJcbiAgICAgICAgICAgIC8qKioqKioqKiogSW5wdXQgQVBJICoqKioqKioqKiovXHJcbiAgICAgICAgICAgIHRoaXMuYXBpLmR5bmFtaWNGb3JtLmNsZWFyQWxsRXJyb3IgPSAoKTogdm9pZCA9PiB7XHJcbiAgICAgICAgICAgICAgICBsZXQgdGFibGVDb250ZXh0OiB7IFtrZXk6IHN0cmluZ106IGFueSB9ID0gdGhpcy5ncmlkT3B0aW9ucy5jb250ZXh0W3RoaXMuX3RhYmxlU2VydmljZS5nZXRUYWJsZUNvbnRleHRLZXkoKV07XHJcblxyXG4gICAgICAgICAgICAgICAgZm9yIChsZXQgaXRlbSBpbiB0YWJsZUNvbnRleHQpIHtcclxuICAgICAgICAgICAgICAgICAgICBpZiAodGFibGVDb250ZXh0Lmhhc093blByb3BlcnR5KGl0ZW0pKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGxldCBjb250ZXh0SXRlbTogYW55ID0gdGFibGVDb250ZXh0W2l0ZW1dO1xyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgZm9yIChsZXQgcXVlc3Rpb24gaW4gY29udGV4dEl0ZW0pIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmIChjb250ZXh0SXRlbS5oYXNPd25Qcm9wZXJ0eShxdWVzdGlvbikpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAodHlwZW9mIGNvbnRleHRJdGVtW3F1ZXN0aW9uXS5lcnJvcnMgPT09ICd1bmRlZmluZWQnKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnRleHRJdGVtW3F1ZXN0aW9uXS5lcnJvcnMgPSBbXTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnRleHRJdGVtW3F1ZXN0aW9uXS5lcnJvcnMubGVuZ3RoID0gMDtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfTtcclxuICAgICAgICB9XHJcbiAgICAgICAgZWxzZSB7XHJcbiAgICAgICAgICAgIGNvbnNvbGUud2FybignS2RUYWJsZSB3YXJuaW5nOiBObyBhcGkgcHJvcGVydHkgLyB1bmRlZmluZWQgYXBpIHByb3BlcnR5IGlzIHBhc3NlZCBpbi4nKTtcclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy9cclxuICAgIC8vLyBNaXNjIGZ1bmN0aW9uc1xyXG4gICAgLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy9cclxuICAgIHByaXZhdGUgX2luaXRHcmlkU2VydmljZShfbG9hZFR5cGU6IHN0cmluZyk6IHZvaWQge1xyXG4gICAgICAgIGlmICh0eXBlb2YgX2xvYWRUeXBlID09PSAndW5kZWZpbmVkJyB8fCBfbG9hZFR5cGUgPT09ICdub3JtYWwnKSB7XHJcbiAgICAgICAgICAgIHRoaXMuX3RhYmxlU2VydmljZSA9IG5ldyBLZFRhYmxlTm9ybWFsU3ZjKCk7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICB0aGlzLl90YWJsZVNlcnZpY2UgPSBuZXcgS2RUYWJsZUVudGVycHJpc2VTdmMoKTtcclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfdXBkYXRlR3JpZENvbmZpZyhfZ3JpZENvbmZpZzogSVRhYmxlQ29uZmlnKTogdm9pZCB7XHJcbiAgICAgICAgdGhpcy5ncmlkSWQgPSB0aGlzLl90YWJsZVNlcnZpY2UuZ2V0R3JpZElkKF9ncmlkQ29uZmlnKTtcclxuXHJcbiAgICAgICAgdGhpcy5fdGFibGVTZXJ2aWNlLnVwZGF0ZUdyaWRCdXR0b25zKF9ncmlkQ29uZmlnKTtcclxuICAgICAgICB0aGlzLl90YWJsZVNlcnZpY2UudXBkYXRlU2VsZWN0RGVmYXVsdFZhbHVlKF9ncmlkQ29uZmlnKTtcclxuICAgIH1cclxufVxyXG4iXX0=