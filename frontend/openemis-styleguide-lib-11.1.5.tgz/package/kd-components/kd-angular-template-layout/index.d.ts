export { KdTemplateLayout } from './kd-angular-template-layout';
export { KdTemplateLayoutSvc } from './kd-angular-template-layout-svc';
export { ITemplateLayoutAPI } from './kd-angular-template-layout-interface';
