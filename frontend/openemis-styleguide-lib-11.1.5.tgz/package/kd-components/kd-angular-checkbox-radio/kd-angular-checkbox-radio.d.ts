import { OnInit, ViewContainerRef } from '@angular/core';
export declare class KdCheckboxRadio implements OnInit {
    private _vcr;
    inputText: string;
    constructor(_vcr: ViewContainerRef);
    ngOnInit(): void;
}
