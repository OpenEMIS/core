export { KdMiniDashboard } from './kd-angular-mini-dashboard';
export { KdMiniDashboardChart } from './kd-angular-mini-dashboard-chart';
export { KdMiniDashboardSvc } from './kd-angular-mini-dashboard-svc';
