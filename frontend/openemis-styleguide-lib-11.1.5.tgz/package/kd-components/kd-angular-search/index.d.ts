export { KdSearch } from './kd-angular-search';
export { KdSearchEvent } from './kd-search-event';
