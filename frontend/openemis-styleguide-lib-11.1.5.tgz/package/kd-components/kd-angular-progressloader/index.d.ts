export { KdProgressloader } from './kd-angular-progressloader';
