import { OnInit, OnChanges, SimpleChanges, EventEmitter } from '@angular/core';
import { NgbDateStruct } from '@ng-bootstrap/ng-bootstrap';
export declare class KdDatepicker implements OnInit, OnChanges {
    _updatedConfig: any;
    _minDate: NgbDateStruct;
    _maxDate: NgbDateStruct;
    _model: any;
    _popupPlacement: string;
    private _defaultConfig;
    private _emitVal;
    inputVal: any;
    config: any;
    minDate: any;
    maxDate: any;
    dateConfig: EventEmitter<any>;
    ngOnInit(): void;
    ngOnChanges(_simpleChanges: SimpleChanges): void;
    emitValue(): void;
    private _assignSetting;
    private _getNgbDateStruct;
    private _parseDate;
    private _formatDate;
}
