import { EventEmitter, OnChanges, SimpleChanges } from '@angular/core';
import { KdDomElemSvc } from '../kd-common/index';
import { IBtnGroupConfig, IBtnGroupData } from './kd-angular-button-group-interface';
export declare class KdButtonGroup implements OnChanges {
    private _domElmSvc;
    buttons: Array<{}>;
    disableToolTip: boolean;
    isStringMode: boolean;
    isIconOnly: boolean;
    modalValue: any;
    data: Array<IBtnGroupData>;
    name?: string;
    value: any;
    disabled?: boolean;
    config?: IBtnGroupConfig;
    type?: 'checkbox' | 'radio';
    updatedValue: EventEmitter<any>;
    constructor(_domElmSvc: KdDomElemSvc);
    ngOnChanges(_simpleChanges: SimpleChanges): void;
    emitValue(): void;
    isButtonDisabled(_btnCond: boolean | null): boolean;
    private _validateValueType;
    private _buttonSizeValidation;
}
