export interface IBtnGroupData {
    value: string | number;
    key: string;
    icon?: string;
    disabled?: boolean;
}
export interface IBtnGroupConfig {
    iconOnly?: boolean;
    type: 'checkbox' | 'radio';
    id?: string;
}
