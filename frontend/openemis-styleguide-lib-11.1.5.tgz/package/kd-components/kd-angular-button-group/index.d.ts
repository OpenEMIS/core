export { KdButtonGroup } from './kd-angular-button-group';
export { IBtnGroupConfig, IBtnGroupData } from './kd-angular-button-group-interface';
