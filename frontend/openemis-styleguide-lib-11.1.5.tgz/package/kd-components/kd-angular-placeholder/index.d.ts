export { KdPlaceholder } from './kd-angular-placeholder';
export { IPlaceholderConfig, IPlaceholderValue } from './kd-angular-placeholder-interface';
