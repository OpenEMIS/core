export { KdError } from './kd-angular-error';
