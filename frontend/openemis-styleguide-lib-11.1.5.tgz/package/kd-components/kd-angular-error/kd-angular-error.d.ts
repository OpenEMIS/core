import { OnInit } from '@angular/core';
import { Location } from '@angular/common';
import { Router } from '@angular/router';
export declare class KdError implements OnInit {
    protected _location: Location;
    protected _router: Router;
    _finalConfig: any;
    private _defaultConfig;
    config: any;
    errorType: string;
    constructor(_location: Location, _router: Router);
    ngOnInit(): void;
    redirect(): void;
    back(): void;
}
