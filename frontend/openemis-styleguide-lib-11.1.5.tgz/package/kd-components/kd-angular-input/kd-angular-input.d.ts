import { EventEmitter, OnInit, AfterViewInit, OnDestroy, ChangeDetectorRef } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { KdTableInputUpdateEvent, KdTableButtonEvent, ITableFormUpdateParams, ITableCellParams } from '../kd-angular-table/index';
import { KdTableEvent } from '../kd-angular-table/kd-angular-table-event';
import { KdDomElemSvc } from '../kd-common/index';
export declare class KdInput implements OnInit, AfterViewInit, OnDestroy {
    private _domSvc;
    private _cdf;
    private _tableEvent;
    _tooltipPlacement: string;
    private _toEmit;
    private _subscriptionObj;
    question: any;
    form: FormGroup;
    horizontal: boolean;
    changeDetectFromQuestion: EventEmitter<any>;
    changeDetectFromGrid: EventEmitter<any>;
    gridCellValueChanged: EventEmitter<{
        formKey: string;
        params: KdTableInputUpdateEvent;
    }>;
    gridButtonClicked: EventEmitter<{
        formKey: string;
        params: KdTableButtonEvent;
    }>;
    constructor(_domSvc: KdDomElemSvc, _cdf: ChangeDetectorRef, _tableEvent: KdTableEvent);
    ngOnInit(): void;
    ngAfterViewInit(): void;
    ngOnDestroy(): void;
    changeDetect(): void;
    valueUpdate(data: any): void;
    agCellValueUpdate(_cellObject: any): void;
    getCheckboxArray(event: any, itemVal: any): void;
    resetHeight(): void;
    /************************** Table controlType **************************/
    setTableCellQuestionProperty(_formParams: ITableFormUpdateParams): void;
    setTableCellData(_cellParams: ITableCellParams): void;
    emitCellUpdate(_params: KdTableInputUpdateEvent): void;
    emitGridButtonClicked(_params: KdTableButtonEvent): void;
}
