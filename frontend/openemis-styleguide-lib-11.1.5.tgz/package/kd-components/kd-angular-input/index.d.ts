export { KdInput } from './kd-angular-input';
