import { FormGroup } from '@angular/forms';
import { InputBase } from './kd-input-base';
export declare class KdInputControlService {
    constructor();
    toFormGroup(inputs: InputBase<any>[]): FormGroup;
    emptyFormGroup(): FormGroup;
    private _fileSizeValidator;
}
