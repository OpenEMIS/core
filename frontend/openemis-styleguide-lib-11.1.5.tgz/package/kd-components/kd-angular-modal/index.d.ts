export { KdModal } from './kd-angular-modal';
export { KdModalEvent } from './kd-modal-event';
