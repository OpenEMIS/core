import { EventEmitter, OnInit } from '@angular/core';
import { KdView } from '../kd-angular-view/index';
export declare class KdDelete implements OnInit {
    _questionData: Array<any>;
    _defaultBtn: Array<any>;
    private _sectionHeader;
    question: Array<any>;
    buttonCancelEvent: EventEmitter<any>;
    buttonDeleteEvent: EventEmitter<any>;
    kdViewComponent: KdView;
    ngOnInit(): void;
    btnClick(_button: any): void;
    submitClick(_formVal: any): void;
    setDeleteDisabled(_toDisable: boolean): void;
}
