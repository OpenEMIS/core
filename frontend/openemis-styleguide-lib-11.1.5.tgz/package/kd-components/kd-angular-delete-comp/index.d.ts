export { KdDelete } from './kd-angular-delete-comp';
