/************************ Calendar general interface *************************/
export interface ICalendar {
    id: number;
    name: string;
    note?: string;
    badge: {
        label: string;
        position?: string;
        color?: string;
        highlight?: string;
    };
    start: Date | string;
    end?: Date | string;
    title?: string;
    color?: {
        primary?: string;
        secondary?: string;
    };
    resizable?: {
        beforeStart?: boolean;
        afterEnd?: boolean;
    };
    draggable?: boolean;
    meta?: {
        incrementsBadgeTotal?: boolean;
    };
}
export interface ICalendarApi {
    nextMonth?: Function;
    nextWeek?: Function;
    nextDay?: Function;
    previousMonth?: Function;
    previousWeek?: Function;
    previousDay?: Function;
    goDate?: Function;
    getCalendarDate?: Function;
    getCalendarType?: Function;
    setCalendarType?: Function;
}
export interface ICalendarOpenDrawer {
    element?: Element;
    isIconAdded?: boolean;
}
