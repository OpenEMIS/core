import { OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { DomSanitizer } from '@angular/platform-browser';
export declare class KdCodeblock implements OnInit {
    private _sanitizer;
    private _http;
    _updatedCode: string;
    private Prism;
    private _httpSub;
    code: string;
    path: string;
    language: string;
    constructor(_sanitizer: DomSanitizer, _http: HttpClient);
    ngOnInit(): void;
    private _updateCodeblock;
    private _getSpaces;
    private _getType;
}
