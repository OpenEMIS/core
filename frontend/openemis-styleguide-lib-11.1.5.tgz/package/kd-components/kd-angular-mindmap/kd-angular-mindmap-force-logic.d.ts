import { EventEmitter } from '@angular/core';
import * as d3 from 'd3';
import { IMindmapLink, IMindmapNode, IMindmapOptions } from './kd-angular-mindmap-interface';
export declare class ForceDirectedGraph {
    ticker: EventEmitter<d3.Simulation<IMindmapNode, IMindmapLink>>;
    onSimulationEnd: EventEmitter<boolean>;
    simulation: d3.Simulation<any, any>;
    nodes: Array<IMindmapNode>;
    links: Array<IMindmapLink>;
    constructor(nodes: Array<IMindmapNode>, links: Array<IMindmapLink>, options: IMindmapOptions);
    initNodes(): void;
    initLinks(): void;
    initSimulation(options: IMindmapOptions): void;
}
