import { Observable } from 'rxjs';
import { IMindmapNode } from './kd-angular-mindmap-interface';
import { KdBroadcaster } from '../kd-common/index';
export declare class KdMindmapEvent {
    private _broadcaster;
    constructor(_broadcaster: KdBroadcaster);
    nodeSelected(_mindmapId: string, _selectedNode?: IMindmapNode): void;
    onNodeSelected(_mindmapId: string): Observable<any>;
}
