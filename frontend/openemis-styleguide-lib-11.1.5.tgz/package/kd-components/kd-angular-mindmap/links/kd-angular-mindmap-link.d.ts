import { OnInit, OnChanges, SimpleChanges, OnDestroy, ElementRef } from '@angular/core';
import { KdDomElemSvc } from '../../kd-common/index';
import { KdMindmapEvent } from '../kd-angular-mindmap-event';
import { IInternalAllConfig, IMindmapInternalLinkApiRef } from '../kd-angular-mindmap-interface';
export declare class KdMindmapLink implements OnInit, OnChanges, OnDestroy {
    private _mindmapEvent;
    private _domSvc;
    private _elemRef;
    config: IInternalAllConfig;
    offset: number;
    private _nodeSelectedSub;
    private _linkActive;
    mindmapId: string;
    link: any;
    allConfig: IInternalAllConfig;
    internalLinkApiRef: IMindmapInternalLinkApiRef;
    constructor(_mindmapEvent: KdMindmapEvent, _domSvc: KdDomElemSvc, _elemRef: ElementRef);
    ngOnInit(): void;
    ngOnChanges(_simpleChanges: SimpleChanges): void;
    ngOnDestroy(): void;
    private _initApi;
    private _linkActiveSwitch;
    private _setConfig;
    /**
     * [_setMarker is setting whether the arrow heads should appear]
     */
    private _setMarker;
    private _setMarkerType;
}
