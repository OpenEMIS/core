export interface IMindmapApi {
    zoom?: (_action: string) => void;
}
export interface IMindmapInternalApi {
    setNodeHeight?: (_node: IMindmapNode, _nodeHeight: number) => void;
    zoom?: (_action: string) => void;
    scaleTo?: (_scale: number) => void;
    translate?: (_x: number, _y?: number) => any;
    accessInternalLinkApi?: (_key: string) => IMindmapInternalLinkApi;
}
export interface IMindmapInternalLinkApiRef {
    [key: string]: IMindmapInternalLinkApi;
}
export interface IMindmapInternalLinkApi {
    setLinkOffset?: (_offset: number) => void;
}
/**
 * levelRightMargin: space between nodes of each level
 * iconLinkPath: href for font-awesome.svg. this path differs for different application and styleguidev2
 * and many more ...
 */
export interface IAllConfig {
    id?: string;
    zoomButton?: boolean;
    levelRightMargin?: number;
    padding?: number;
    border?: boolean;
    height?: number | string;
    width?: number | string;
    iconLinkPath?: string;
    link?: IMindMapLinkConfig;
    node?: IMindMapNodeConfig;
}
export interface IInternalAllConfig extends IAllConfig {
    link?: IInternalLinkConfig;
    node?: IInternalNodeConfig;
}
export interface IMindMapLinkConfig {
    activeClass?: string;
    class?: string;
    type?: string;
    dashArray?: Array<number>;
    dash?: boolean;
}
export interface IInternalLinkConfig extends IMindMapLinkConfig {
    markerStartURL?: string;
    markerEndURL?: string;
}
export interface ITypeConfig {
    class?: string;
    icon?: string;
    iconClass?: string;
    iconType?: 'icon' | 'image';
}
export interface IMindMapNodeConfig {
    width?: number;
    fontSize?: number;
    typeConfig?: {
        [key: string]: ITypeConfig;
    };
    selectOnLoadId?: number;
    activeClass?: string;
    class?: string;
    textPadding?: number;
    icon?: {
        marginTop?: number;
        marginBottom?: number;
    };
    title?: {
        paddingTop?: number;
        paddingBottom?: number;
    };
    description?: {
        marginTop?: number;
        marginBottom?: number;
    };
}
export interface IInternalNodeConfig extends IMindMapNodeConfig {
    width?: number;
    height?: number;
    fontSize?: number;
    icon?: {
        size?: number;
        marginTop?: number;
        marginBottom?: number;
        link?: string;
        type?: string;
    };
    title?: {
        height?: number;
        paddingTop?: number;
        paddingBottom?: number;
        textHeight?: number;
        textClass?: string;
    };
    description?: {
        textClass?: string;
        marginTop?: number;
        padding?: number;
        textHeight?: number;
        marginBottom?: number;
    };
    image?: string;
}
export interface D3NodeInfo {
    x?: number;
    y?: number;
    vx?: number;
    vy?: number;
    fx?: number | null;
    fy?: number | null;
    index?: number;
}
export interface IMindmapNode extends D3NodeInfo {
    id?: string | number;
    type?: string;
    level?: number;
    description?: string;
    title?: string;
    icon?: string;
    childs?: Array<string>;
    parents?: Array<string>;
    [key: string]: any;
}
export interface D3LinkInfo {
    source: IMindmapNode | number | string;
    target: IMindmapNode | number | string;
    index?: number;
}
export interface IMindmapLink extends D3LinkInfo {
    type?: 'direction' | 'two-direction' | 'normal';
    dash?: boolean;
    dashArray?: Array<number>;
    offset?: number;
    [key: string]: any;
}
export interface IMindmapOptions {
    width?: number;
    height?: number;
    levelPosition?: {
        [key: string]: number;
    };
}
/**
 *   coord : position of the zoom button (set by developer)
 *   size : size of the zoom button
 *   iconSize : size of the plus/minus icons
 *   marginBottom : margin between the plus and minus zoom buttons
 *   iconLinkPath : font-awesome icons displayed in svg are stored in assests folder, of which path defers depending on application
 */
export interface IZoomButtonConfig {
    coord: {
        x: number;
        y: number;
    };
    size: number;
    iconSize: number;
    marginBottom: number;
    iconLinkPath?: string;
}
