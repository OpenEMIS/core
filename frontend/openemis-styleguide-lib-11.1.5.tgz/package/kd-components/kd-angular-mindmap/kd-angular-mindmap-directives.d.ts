import { ElementRef, OnInit } from '@angular/core';
import { KdMindmapSvc } from './kd-angular-mindmap-svc';
import { ForceDirectedGraph } from './kd-angular-mindmap-force-logic';
import { IMindmapNode, IMindmapInternalApi } from './kd-angular-mindmap-interface';
export declare class KdMindmapZoomDirective implements OnInit {
    private _mindmapSvc;
    private _element;
    private _zoomClass;
    zoomableOf: ElementRef;
    internalApi: IMindmapInternalApi;
    constructor(_mindmapSvc: KdMindmapSvc, _element: ElementRef);
    ngOnInit(): void;
    private _initApi;
}
export declare class KdMindmapDragDirective implements OnInit {
    private _mindmapSvc;
    private _element;
    draggableNode: IMindmapNode;
    draggableInGraph: ForceDirectedGraph;
    constructor(_mindmapSvc: KdMindmapSvc, _element: ElementRef);
    ngOnInit(): void;
}
