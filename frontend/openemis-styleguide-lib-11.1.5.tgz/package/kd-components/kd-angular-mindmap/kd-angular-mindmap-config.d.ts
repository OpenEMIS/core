import { IInternalAllConfig } from './kd-angular-mindmap-interface';
export declare const defaultConfig: IInternalAllConfig;
