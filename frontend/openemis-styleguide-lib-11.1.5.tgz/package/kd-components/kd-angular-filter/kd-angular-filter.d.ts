import { EventEmitter, OnInit } from '@angular/core';
import { KdView } from '../kd-angular-view/index';
export declare class KdFilter implements OnInit {
    _filteredData: Array<any>;
    inputData: any;
    valueUpdate: EventEmitter<any>;
    _updateView: KdView;
    ngOnInit(): void;
    getInputProperty(key: string, propertyName: string): any;
    setInputProperty(_key: string, _propertyName: string, _data: any): void;
    detectValue(_question: any): void;
    private _getUpdatedData;
}
