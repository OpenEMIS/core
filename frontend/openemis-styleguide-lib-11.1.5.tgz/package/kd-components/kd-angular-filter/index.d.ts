export { KdFilter } from './kd-angular-filter';
