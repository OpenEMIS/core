export interface IHeaderAPI {
    setUserInfo?: (_data: IHeaderUserInfo) => void;
    setGroupButton?: (_index: number, _button: IHeaderButton) => void;
}
export interface IHeaderConfig {
    brandLogo?: IHeaderBrandLogo;
    userInfo?: IHeaderUserInfo;
    btnGroup?: Array<IHeaderButton>;
}
export interface IHeaderBrandLogo {
    name: string;
    type: 'icon' | 'image' | null;
    src: string;
    path?: string;
    url?: string;
    target?: string;
}
export interface IHeaderUserInfo {
    showUser: boolean;
    name: string;
    imgType: 'icon' | 'image' | 'none';
    imgSrc: string;
    role?: string;
    path?: string;
    url?: string;
    target?: string;
}
export interface IHeaderButton {
    btnIcon: string;
    dropdownType: 'default' | 'grid' | 'list';
    dropdownContent?: Array<IHeaderDropdownItem>;
}
export interface IHeaderDropdownItem {
    icon?: string;
    imgSrc?: string;
    text: string;
    theme?: string;
}
