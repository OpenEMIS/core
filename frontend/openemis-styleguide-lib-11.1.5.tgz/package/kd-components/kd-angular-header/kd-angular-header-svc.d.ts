import { IHeaderConfig } from './kd-angular-header-interface';
export declare class KdHeaderSvc {
    getDefaultConfig(): IHeaderConfig;
}
