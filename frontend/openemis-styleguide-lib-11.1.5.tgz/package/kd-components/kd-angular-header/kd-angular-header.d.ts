import { OnInit, OnChanges, ViewContainerRef, SimpleChanges, Renderer2 } from '@angular/core';
import { Router } from '@angular/router';
import { KdSplitterEvent } from '../kd-angular-splitter/index';
import { KdHeaderSvc } from './kd-angular-header-svc';
import { KdDataSvc } from '../kd-common/index';
import { IHeaderConfig } from './kd-angular-header-interface';
export declare class KdHeader implements OnInit, OnChanges {
    private _vcr;
    private _router;
    private _renderer;
    private _kdsplitterEvent;
    private _headerSvc;
    private _dataSvc;
    config: any;
    api: any;
    header: IHeaderConfig;
    private _elem;
    constructor(_vcr: ViewContainerRef, _router: Router, _renderer: Renderer2, _kdsplitterEvent: KdSplitterEvent, _headerSvc: KdHeaderSvc, _dataSvc: KdDataSvc);
    ngOnInit(): void;
    ngOnChanges(_simpleChanges: SimpleChanges): void;
    onClickHambugerMenu(): void;
    onClickLogo(): void;
    onClickProfile(): void;
    onClickHeaderButton(button: any): void;
    onClickDropdownItem(item: any): void;
    private _initApi;
    private _setupHeaderConfig;
}
