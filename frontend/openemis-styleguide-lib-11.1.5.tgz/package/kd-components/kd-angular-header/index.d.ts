export { KdHeader } from './kd-angular-header';
export { IHeaderButton, IHeaderBrandLogo, IHeaderDropdownItem, IHeaderUserInfo, IHeaderAPI, IHeaderConfig } from './kd-angular-header-interface';
