export { KdTimepicker } from './kd-angular-timepicker';
