import { ViewContainerRef } from '@angular/core';
import { Router } from '@angular/router';
import { GridOptions, Column, IRowModel } from 'ag-grid-community';
export declare class KdAggridSvc {
    private _resizeableCol;
    getGridOptions(): any;
    setResult(_config: any): any;
    setRowResult(_rowData: Array<any>): Array<any>;
    setColDefs(_colDef: any, _gridOptions: GridOptions, /*_dataSvc: KdDataSvc, */ _router?: Router, _isRecursive?: boolean): any;
    setFilterAndSortOptions(params: any): GridOptions;
    calcColWidth(_gridOptions: GridOptions): Array<{
        width: number;
        id: string;
    }>;
    colTotalWidth(_colArray: Array<{
        width: number;
        id: string;
    }>, column: Array<Column>): number;
    calcUsableWidth(_vcr: ViewContainerRef): number;
    calcResizeableCol(_columns: Array<Column>): number;
    calcGridHeightWeb(_gridHeight: any, _model: IRowModel, _vcr: ViewContainerRef): number;
    calcGridHeightMobile(_vcr: ViewContainerRef): number;
    serverSortAndFilter(_data: Array<any>, _sortModel: Array<any>, _filterModel: any): any[];
    checkColumnDef(_colDef: any, _hasCheckbox: boolean, _hasRadio: boolean): any;
    getActionList(_rowData: any, _column: Array<Column>): Array<any>;
    checkIsTargetClickable(_rowEvent: Event): boolean;
    checkIsConfigColumn(_colDef: any): boolean;
    private _setColumnConfig;
    private _serverFilterData;
    private _serverSortData;
    private _checkGridHeight;
    private _checkPaginationType;
    private _checkLoadType;
    private _checkPagesize;
    private _getRowHeight;
    private _checkBtnConfig;
    private _checkButton;
}
