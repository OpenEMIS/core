export declare class KdChartsTooltipSvc {
    private _tooltipPosOffset;
    /**
     * main entry function to check whether tooltip is out of viewport and renders in opposite direction
     * param {any}     _tooltipElem is d3-selection of the tooltip element
     * param { top: any; left: any; }         _mousePos
     */
    positionTooltip(_tooltipElem: any, _mousePos: {
        top: any;
        left: any;
    }): void;
    private _calcTooltipPos;
    private _setTooltipPos;
    checkOutOfBounds(_element: Element, _width: number, _height: number): boolean;
    private _getViewport;
    private _getOuterWidth;
    private _getOuterHeight;
    private _getHostOffset;
    private _getWindowScrollTop;
    private _getWindowScrollLeft;
}
