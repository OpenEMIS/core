import { IChartConfig } from '../kd-angular-charts-interface';
export declare class KdChartsGridSvc {
    private _dashArray;
    private _config;
    private _isInvert;
    private _graphDimension;
    constructor(_config: IChartConfig);
    set config(_config: IChartConfig);
    set isInvert(_isInvert: boolean);
    set graphDimension(_graphDimension: {
        width: number;
        height: number;
    });
    /**
     * wrapper function around d3.scale so that grid will be drawn in center of paddingInner
     * when scaleBand, this.x gives the start(left corner) of the band (rect). need to recalculate the correct position
     * only scaleBand have _scale.step()
     * param {any} _scale [this.x from base class]
     */
    xAxisGridScale(_scale: any): Function;
    haveGrid(_config: IChartConfig, _dir: 'yAxis' | 'xAxis', _type: 'gridLine' | 'minorGridLine'): boolean;
    drawGridLine(_container: any, _data: Array<number | string>, _dir: 'yAxis' | 'xAxis', _type: 'gridLine' | 'minorGridLine', _scale: any): void;
    private _checkGridLineOverlap;
    private _setGridLinesConfig;
    /**
     * sets the x1,x2,y1,y2 of the svg:line
     * param {[type]}        _container [any]
     * param {any}           _scale     [this.y or xAxisGridScale]
     * param {'vertical' | 'horizontal'} _dir
     */
    private _setGridLineCoordinate;
}
