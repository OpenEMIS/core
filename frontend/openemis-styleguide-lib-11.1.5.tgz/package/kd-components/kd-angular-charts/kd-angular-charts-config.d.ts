import { IChartConfig, ILabelTextVerticalAlignStore } from './kd-angular-charts-interface';
export declare const DEFAULT_CONFIG: IChartConfig;
export declare const LABEL_TEXT_VERTICAL_ALIGN_STORE: ILabelTextVerticalAlignStore;
export declare const GRID_DASH_ARRAY: {
    [key: string]: Array<number>;
};
export declare const TOOLTIP_DEFAULT_STYLE: {
    [key: string]: string | number;
};
