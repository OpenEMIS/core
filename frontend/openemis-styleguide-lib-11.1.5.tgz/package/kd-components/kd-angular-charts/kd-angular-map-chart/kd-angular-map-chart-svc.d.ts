import * as L from 'leaflet';
import 'leaflet.markercluster';
import 'leaflet.awesome-markers/dist/leaflet.awesome-markers';
export interface IFinalValue {
    intervals: number;
    finalStep: number;
    finalMin: number;
}
export declare class KdMapChartSvc {
    static colors: Array<string>;
    private _valueScale;
    private _mapScaleTriangle;
    private _pathIdPrefix;
    get valueScale(): any;
    set valueScale(_valueScale: any);
    set mapScaleTriangle(_mapScaleTriangle: any);
    get pathIdPrefix(): string;
    setScale(_domain: number[], _range: number[] | string[]): any;
    translateMapScaleTriangle(_value: number): void;
    getLegendIntervals(_min?: number, _max?: number): number[];
    private _getInterval;
    private _findPlaces;
    private _getTicks;
    checkValueInBetween(_value: number, _min: number, _max: number): boolean;
    getSeriesPointer(_seriesData: Array<any>): any;
    checkMapLevelExist(_mapLevel: string, _mapData: any): boolean;
    getMapLevelWithAreaFilter(_seriesId: string, _mapData: any): string;
    setIcon(_options?: any): any;
    populateMarkers(_data: any, _map: L.Map, _displayType: string): {
        markersLegend: any[];
        clusterMarkers: {
            [key: string]: any;
        };
    };
    private _iconCreateFunction;
    getTargetGeojsonId(_targetElement: HTMLElement): string;
    getCurrentSelection(_parentElem: any, _id: string, _type?: 'd3' | 'leaflet'): any;
}
