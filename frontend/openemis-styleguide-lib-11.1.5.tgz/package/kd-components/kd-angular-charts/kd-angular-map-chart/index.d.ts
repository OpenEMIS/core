export { KdMapChart } from './kd-angular-map-chart';
