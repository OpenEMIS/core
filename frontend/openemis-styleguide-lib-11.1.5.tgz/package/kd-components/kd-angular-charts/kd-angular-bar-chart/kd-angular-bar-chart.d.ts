import { OnInit, OnChanges, SimpleChanges, OnDestroy } from '@angular/core';
import { KdChartBaseClass } from '../kd-angular-chart-base-class';
import { KdChartsSvc } from '../kd-angular-charts-svc';
import { ID3Data, IChartConfig, ILegendData } from '../kd-angular-charts-interface';
import { KdDomElemSvc } from '../../kd-common/index';
import { KdBarChartSvc } from './kd-angular-bar-chart-svc';
export declare class KdBarChart extends KdChartBaseClass implements OnInit, OnChanges, OnDestroy {
    _chartSvc: KdChartsSvc;
    _domSvc: KdDomElemSvc;
    _barSvc: KdBarChartSvc;
    private _barGraph;
    private _resizeTimeout;
    private _isStartAtSum;
    allData: ID3Data;
    barConfig: IChartConfig;
    legend: {
        [key: string]: ILegendData;
    };
    api: any;
    constructor(_chartSvc: KdChartsSvc, _domSvc: KdDomElemSvc, _barSvc: KdBarChartSvc);
    ngOnInit(): void;
    ngOnChanges(_simpleChanges: SimpleChanges): void;
    ngOnDestroy(): void;
    private _redrawChart;
    private _setData;
    private _setConfig;
    private _setChart;
    private _resetChart;
    private _drawChartContainer;
    private _drawChart;
    private _setRectGroup;
    private _getVal;
    private _setBarChartLabel;
    private _setLabelStyle;
    private _displayAllLabel;
    private _getRectPosInfo;
    private negativeStackSymmetryLogic;
}
