import { ID3DataRange, IYAxisBoundaryConfig } from '../kd-angular-charts-interface';
export interface IRectGroup {
    rectGroup: any;
    rectGroupTransite: any;
    xPosArr: Array<number>;
    yPosArr: Array<number>;
    widthArr: Array<number>;
    heightArr: Array<number>;
}
export interface IRectPosInfo {
    width: number;
    padding: number;
}
export interface IBaseClassBarObj {
    isInvert: boolean;
    clusterPaddingPercent: number;
    bandPadding: number;
}
export interface IVerticalAlignStore {
    top: string;
    bottom: string;
    middle: string;
}
export interface IBarRectDimensions {
    xPos: number;
    yPos: number;
    width: number;
    height: number;
}
export interface ILabelTextPosHorizontalParams {
    xPos: number;
    chartWidth: number;
    valueSign: number;
}
export interface INegativeStackLogicReturn {
    dataRange: ID3DataRange;
    yAxis?: IYAxisBoundaryConfig;
}
