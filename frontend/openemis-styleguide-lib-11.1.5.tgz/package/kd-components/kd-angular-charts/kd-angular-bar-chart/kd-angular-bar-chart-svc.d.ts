import { IPlotOptions, ID3DataRange, IYAxisConfig } from '../kd-angular-charts-interface';
import { IBarRectDimensions, ILabelTextPosHorizontalParams, INegativeStackLogicReturn } from './kd-angular-bar-chart-interface';
export declare class KdBarChartSvc {
    private _allowedPaddingValue;
    private _originalDataRange;
    private _verticalAlignStore;
    set originalDataRange(_originalDataRange: any);
    applySymmetricAxis(_dataRange: ID3DataRange, _plotOptions: IPlotOptions, _yAxisConfig: IYAxisConfig): INegativeStackLogicReturn;
    private _getAbsoluteValue;
    private _setDataRangeToSymmetric;
    private _isSymmetric;
    setLabelContainerWidthOrHeight(_container: any, _type: string, _inside: boolean, _dimensions: IBarRectDimensions): void;
    _setLabelTextPosHorizontal(_labelText: any, _isYReversed: boolean, _params: ILabelTextPosHorizontalParams): void;
    private _isLabelOutside;
    /**
     * used for labels.inside is true. which will change the height of the label div containers
     * then vertically align using flex and align-items
     * param {[type]}                         _labels [Element]
     * param {'top' | 'middle' | 'bottom'}    _verticalAlign
     */
    setVerticalAlignCSS(_labels: any, _verticalAlign: 'top' | 'middle' | 'bottom'): void;
    /**
     * calculates the width of each rect and padding(only applicable to bar-cluster) between each rect in a cluster.
     * param {number} _totalWidth
     * param {number} _paddingPercent percentage of totalWidth allowed for total sum of all padding
     * param {number} _noOfRect
     */
    getRectWidth(_totalWidth: number, _paddingPercent: number, _noOfRect: number): {
        width: number;
        padding: number;
    };
    private _isValueExist;
}
