export { KdBarChart } from './kd-angular-bar-chart';
