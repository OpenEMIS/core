export { KdPieChart } from './kd-angular-pie-chart';
