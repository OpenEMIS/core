import { IButton } from '../kd-common/index';
import { IMapClusterData } from '../index';
export interface IChartApi {
    changeSeriesColor?: (legendId: string, color: string, index?: number) => void;
    redraw?: () => void;
    addMenuItem?: (_menuItemArr: IMenuItem[]) => void;
    hideMenuItemById?: (_id: string, _isHide: boolean) => void;
    hideMenuItemByAction?: (_id: string, _isHide: boolean) => void;
    translationCallback?: (_string: string) => string;
}
export interface IChartInternalApi {
    legendClick?: (_data: ID3Data | string, _legendData?: {
        [key: string]: ILegendData;
    } | boolean) => void;
    clusterClick?: (_data: ID3Data | string, _legendItem?: {
        'legendItemMarker': HTMLElement;
        'legendItemLabel': HTMLElement;
    }) => void;
    redraw?: () => void;
}
export interface ICommonSeries {
    color?: string;
    shape?: 'triangle' | 'triangleR' | 'diamond' | 'circle' | 'square';
}
export interface ISeriesData extends ICommonSeries {
    value: number;
}
export interface IChartMapPosition {
    longitude: number;
    latitude: number;
    zoom?: number;
}
export interface IMapFeatureCollection {
    type?: string;
    properties?: any;
    geometry?: {
        type?: string;
        coordinates?: Array<any>;
    };
}
export interface IMapData {
    [key: string]: {
        type?: string;
        features?: Array<IMapFeatureCollection>;
    };
}
export interface ISeries extends ICommonSeries {
    name: string;
    id?: string;
    data: Array<ISeriesData>;
    dotEnabled?: boolean;
    dotBorderWidth?: number;
    dotBorderColor?: string;
    lineStyle?: string;
}
export interface IChartData {
    chart: {
        type: 'pie' | 'bar' | 'column' | 'line' | 'area' | 'dot' | 'spline' | 'map';
        layout: string;
    };
    xAxis?: {
        categories: Array<string>;
    };
    series: Array<ISeries> | Array<any>;
    position?: IChartMapPosition;
    pointData?: IMapClusterData;
    mapData?: IMapData;
    value?: any;
}
/**
 * possible layouts for IChartData
 * for bar : 'bar-cluster' | 'bar-stack' | 'bar-100'| 'bar-stack-negative'| 'column-stack'| 'column-cluster' | 'column-100' | 'column-stack-negative'
 * for pie : 'pie-full' | 'pie-half' | 'donut-full' | 'donut-half' | 'radial-full' | 'gauge-full' | 'gauge-half'
 * for line: 'line-type1' | 'line-type2' | 'spline-type1' | 'spline-type2' | 'dot-type1' | 'dot-type2'
 * for area: 'area-type1' | 'area-type2' | 'area-spline-type1' | 'area-spline-type2' | 'area-stack-type2' | 'area-stack-spline-type2' | 'area-100-type2' | 'area-100-spline-type2'
 */
export interface ID3YData {
    value: number | null;
    id: string;
    sum?: number;
    renderVal?: number;
    color?: string;
    shape?: 'triangle' | 'triangleR' | 'diamond' | 'circle' | 'square';
}
export interface ID3PieData {
    id: string;
    x: string;
    y: number | null;
    xBase?: string;
    color: string;
}
export interface ID3DataData {
    x: {
        value: string;
        label: string;
    };
    y: Array<ID3YData>;
    z?: string;
}
export interface ID3Data {
    type: 'pie' | 'bar' | 'column' | 'line' | 'area' | 'dot' | 'spline' | 'map';
    layout: string;
    config?: {
        [key: string]: any;
    };
    data: Array<ID3DataData>;
    range?: ID3DataRange;
    haveNegative?: boolean;
}
export interface ID3DataRange {
    max: number;
    min: number;
}
/**
 * current use case for style:
 * {
*         textAlign: 'center',
        fontWeight: '', // bold
        fontStyle: '', // italic
        fontFamily: '', // Times New Roman
        color: '#333333',
        fontSize: '20px',
 * }
 */
export interface IChartConfig {
    id?: string;
    clusterLegend?: IChartLegend;
    animation?: boolean;
    skipMassage?: boolean;
    colors?: Array<string>;
    title?: IChartTitle;
    subtitle?: IChartTitle;
    colorAxis?: {
        dataClasses?: Array<{
            color?: string;
            from?: number;
            to?: number;
        }>;
        max?: number;
        maxColor?: string;
        min?: number;
        minColor?: string;
    };
    chart?: {
        persistentSeriesChange?: boolean;
        style?: {
            [key: string]: string;
        };
        margin?: IChartMargin;
        labels?: IDataLabel;
        mainArea?: {
            style?: {
                [key: string]: string;
            };
        };
        plotArea?: {
            style?: {
                [key: string]: string;
            };
        };
    };
    xAxis?: IXAxisConfig;
    yAxis?: IYAxisConfig;
    legend?: {
        enabled?: boolean;
        float?: boolean;
        enableScroll?: boolean;
        align?: string;
        verticalAlign?: string;
        layout?: string;
        style?: {
            borderColor?: string;
            borderRadius?: string;
            borderWidth?: string;
            maxHeight?: number;
        };
        item?: {
            activeColor?: string;
            inactiveColor?: string;
            hoverColor?: string;
            style?: {
                [key: string]: string;
            };
        };
        title?: {
            text?: string;
            align?: string;
            style?: {
                [key: string]: string;
            };
        };
        valueDecimals?: number;
        valueSuffix?: string;
    };
    mapNavigation?: {
        enabled?: boolean;
        buttons?: {
            zoomIn?: {
                x?: number;
                y?: number;
            };
            zoomOut?: {
                x?: number;
                y?: number;
            };
        };
    };
    plotOptions?: IPlotOptions;
    tooltip?: {
        enabled?: boolean;
        format?: string;
        style?: {
            [key: string]: string;
        };
    };
    export?: IChartExport;
    footer?: {
        enabled?: boolean;
        bottomLabel?: IChartTitle;
        footNote?: IChartTitle;
    };
}
export interface IChartStyle {
    persistentSeriesChange?: boolean;
    style?: {
        [key: string]: string;
    };
    margin?: IChartMargin;
    labels?: IDataLabel;
    mainArea?: {
        style?: {
            [key: string]: string;
        };
    };
    plotArea?: {
        style?: {
            [key: string]: string;
        };
    };
}
export interface IChartMargin {
    top?: string;
    right?: string;
    bottom?: string;
    left?: string;
}
export interface ICommonAxis {
    enabled?: boolean;
    lineWidth?: number;
    lineColor?: string;
    gridLineWidth?: number;
    gridLineColor?: string;
    gridLineDashStyle?: string;
    minorGridLineWidth?: number;
    minorGridLineColor?: string;
    minorGridLineDashStyle?: string;
    labels?: IAxisLabel;
    title?: IChartTitle;
    opposite?: boolean;
    reversed?: boolean;
}
export interface IXAxisConfig extends ICommonAxis {
}
export interface IYAxisBoundaryConfig {
    maxValue?: number | null;
    minValue?: number | null;
    autoRoundToMax?: boolean;
    autoRoundToMin?: boolean;
}
export interface IYAxisConfig extends ICommonAxis, IYAxisBoundaryConfig {
    tickInterval?: number;
    minorTickInterval?: number;
}
export interface IAxisLabel {
    enabled?: boolean;
    format?: string;
    style?: {
        [key: string]: string;
    };
}
export interface IChartTitle {
    enabled?: boolean;
    text?: string;
    align?: string;
    style?: {
        [key: string]: string;
    };
}
export interface IDataLabel {
    enabled?: boolean;
    format?: string;
    style?: {
        [key: string]: any;
    };
    overflow?: string;
    inside?: boolean;
    verticalAlign?: any;
}
export interface ILegendData {
    name: string;
    id: string;
    color: string;
    shape?: string;
    deactive?: boolean;
    x?: string;
    y?: number;
    xBase?: string;
    index?: string;
    mapSeriesId?: string;
    active?: boolean;
    seriesIndex?: number;
    dataIndex?: number;
    dotEnabled?: boolean;
    dotBorderWidth?: number;
    dotBorderColor?: string;
    lineStyle?: string;
}
export interface IChartExport extends IButton {
    enabled: boolean;
    menu?: IMenuItem[];
    btn?: 'top-left' | 'top-right' | 'bottom-left' | 'bottom-right';
    width?: string;
}
export interface IMenuItem extends IButton {
    id: string;
    iconStart?: string;
    iconEnd?: string;
    text?: string;
    operation?: string;
    callback?: Function;
    expanded?: IMenuItem[];
    hidden?: boolean;
}
export interface IPlotOptions {
    pie?: {
        innerRadius?: number;
        borderColor?: string;
        borderWidth?: number;
    };
    map?: {
        borderColor?: string;
        borderWidth?: number;
        nullColor?: string;
        states?: {
            hover?: {
                brightness?: number;
                color?: string;
                marker?: {};
            };
            select?: {
                brightness?: number;
                color?: string;
                marker?: {};
            };
        };
        filter?: {
            border?: number;
            borderHover?: number;
            borderSelected?: number;
        };
        level?: string;
        mapFullChangeLevelDefault?: boolean;
        clusterType?: string;
        zoom?: {
            isZoomButton?: boolean;
            isScrollZoom?: boolean;
            isTouchZoom?: boolean;
            isDoubleClickZoom?: boolean;
            value?: number;
        };
    };
    area?: {
        [key: string]: any;
    };
    bar?: {
        allLabelsPositive?: boolean;
        isSymmetric?: boolean;
    };
}
export interface IChartColorAxis {
    dataClasses?: Array<IChartDataClassesItem>;
    max?: number;
    maxColor?: string;
    min?: number;
    minColor?: string;
}
export interface IChartDataClassesItem {
    color?: string;
    from?: number;
    to?: number;
}
export interface IChartLegend {
    enabled?: boolean;
    float?: boolean;
    enableScroll?: boolean;
    align?: string;
    verticalAlign?: string;
    layout?: string;
    style?: {
        borderColor?: string;
        borderRadius?: string;
        borderWidth?: string;
        maxHeight?: number;
    };
    item?: {
        activeColor?: string;
        inactiveColor?: string;
        hoverColor?: string;
        style?: {
            [key: string]: string;
        };
    };
    title?: {
        text?: string;
        align?: string;
        style?: {
            [key: string]: string;
        };
    };
    valueDecimals?: number;
    valueSuffix?: string;
}
export interface IChartMapNavigation {
    enabled?: boolean;
    buttons?: {
        zoomIn?: {
            x?: number;
            y?: number;
        };
        zoomOut?: {
            x?: number;
            y?: number;
        };
    };
}
export interface IChartTooltip {
    enabled?: boolean;
    format?: string;
    style?: {
        [key: string]: string;
    };
}
export interface IChartFooter {
    enabled?: boolean;
    bottomLabel?: IChartTitle;
    footNote?: IChartTitle;
}
export interface IMaxMinInterval {
    maxValue: number;
    minValue: number;
    interval: number;
}
export interface ILabelTextVerticalAlignStore {
    top: ICommonLabelTextVerticalAlignLogic;
    middle: ICommonLabelTextVerticalAlignLogic;
    bottom: ICommonLabelTextVerticalAlignLogic;
}
export interface ICommonLabelTextVerticalAlignLogic {
    percent?: string;
    check?: string;
    changeTo?: 'top' | 'middle' | 'bottom';
}
export interface ISetTickValueReturn {
    needRedraw: boolean;
    interval: number;
}
export interface IAxisTransformPos {
    right: string;
    left: string;
    top: string;
    bottom: string;
}
export interface IForLoopInfo {
    start: number;
    end: number;
    check: (i: number, end: number) => boolean;
    iterate: (i: number) => number;
}
export interface IAxisLabelBooleanChecks {
    isRotate?: boolean;
    opposite?: boolean;
    isLast?: boolean;
}
export interface IXInfo {
    value: string[];
    longestText: string;
}
export interface IYAxisLabelRange {
    axisMax: number;
    axisMin: number;
}
