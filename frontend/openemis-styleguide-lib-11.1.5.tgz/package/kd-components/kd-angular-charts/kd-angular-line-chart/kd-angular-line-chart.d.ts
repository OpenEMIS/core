import { OnInit, OnChanges, SimpleChanges, OnDestroy } from '@angular/core';
import { KdChartBaseClass } from '../kd-angular-chart-base-class';
import { KdChartsSvc } from '../kd-angular-charts-svc';
import { IChartConfig, ID3DataData, ILegendData, IChartInternalApi } from '../kd-angular-charts-interface';
import { KdDomElemSvc } from '../../kd-common/index';
export declare class KdLineChart extends KdChartBaseClass implements OnInit, OnChanges, OnDestroy {
    _chartSvc: KdChartsSvc;
    _domSvc: KdDomElemSvc;
    private lineChart;
    private _seriesList;
    private _resizeTimeout;
    private _hoverBackground;
    private _shapes;
    private _dotData;
    private _biggestDotSize;
    private _defaultDotPos;
    private _lineStyle;
    data: Array<ID3DataData>;
    config: IChartConfig;
    legendData: {
        [key: string]: ILegendData;
    };
    api: IChartInternalApi;
    constructor(_chartSvc: KdChartsSvc, _domSvc: KdDomElemSvc);
    ngOnInit(): void;
    ngOnChanges(_changes: SimpleChanges): void;
    ngOnDestroy(): void;
    private _redrawChart;
    private _setData;
    private removeLineChart;
    private _setChart;
    private _setAxisDomain;
    private _createChart;
    private _createSeriesContainer;
    private _createHoverDot;
    private _drawChart;
    private _drawPath;
    /**
     * [return path data value. depends on chart type, this function will return line or area path data
     *
     * for _chartData, we need unique data type to return because we are doing a different way of stack area.
     * natural way of line chart is 1 line, 1 series.
     * what we are doing is cut the line/split the stack area into 2 to cater for null value.
     * the data structure that we have coupled strictly to 1 x axis/category match with 1 y data value.
     * for splitting of stack area, we will need 1 x category match with 2 y data value.
     *
     * ]
     * param  {number}                                        _yIndex          [series index as line is drawn per series]
     * param  {Array<ID3DataData> | Array<Array<IDataValue>>} _chartData       [either line data or area data]
     * param  {boolean}                                       _byPassAreaCheck [skip chart type check and draw line. useful for area to draw area and line]
     * return {string}                                                         [return path data value]
     */
    private _setPathValue;
    private _isUsingChartData;
    private _isIDataValue;
    private _validateChartValue;
    private _addDot;
    private _getDotId;
    private _populateDotData;
    private _getDotPosition;
    private triggerHoverFunction;
    private dotHover;
    private _setHoverBackground;
    private _dotHoverPosition;
    private _setLabel;
    private _getLabelTextLength;
    private _setChartAnimation;
    private _setLabelAnimation;
    /**
     * for area stack (not the 100% stack. 100% data massage is the same as bar which
     * the data masssage is done in kd charts).
     *
     * this cannot be done through kd chart data massage because the dot position has to
     * be on the correct sum (same as bar). we will take bar after massage value for dot
     * and remassage for line area.
     *
     * this data massage is catering unique line behaviour when handling null value.
     *
     * line behaviour on null: when a null appear, the line for previous and after current
     * x axis will not be drawn. causing the previous and after x axis to be intepreted as 0
     *
     * as the whole area of this current x axis will be 0 for current series, any series after
     * has to be brought down.
     *
     * we need unique data type to return because we are doing a different way of stack area.
     * natural way of line chart is 1 line, 1 series.
     * what we are doing is cut the line/split the stack area into 2 to cater for null value.
     * the data structure that we have coupled strictly to 1 x axis/category match with 1 y data value.
     * for splitting of stack area, we will need 1 x category match with 2 y data value.
     *
     * param  {Array<ID3DataData>} data after massage data
     * return {Array}                   return as {x, y, y0, valid} as d3 required.
     */
    private _dataMassage;
    /**
     * if the previous series is null, area height calculation start from the series that exist.
     * param  {Array<ID3DataData>} data   [data after massage]
     * param  {number}             xIndex [index of data]
     * param  {number}             yIndex [index of series]
     * param  {number}             adjust [how much point to be bring down (previous)]
     * return {number}                    [return accumulate adjustment point]
     */
    private _getNullHeightValue;
    /**
     * check if the series appearing or disappearing, adjust the position of the line area (stage up/down)
     *
     * appearing is referring to: there is a null on previous x axis but not null on current and after
     *
     * disappering is referring to: there is a value on previous and current x axis but null after
     *
     * param  {Array<ID3DataData>} data   [data after massage]
     * param  {number}             xIndex [index of data]
     * param  {number}             yIndex [index of series]
     * param  {object}             adjust [height to pull down series (if previous series has null) or bring up]
     * return {IDataValue}                [d3 draw path data structure: {x, y, y0, valid}]
     */
    private _getSplitPathData;
}
