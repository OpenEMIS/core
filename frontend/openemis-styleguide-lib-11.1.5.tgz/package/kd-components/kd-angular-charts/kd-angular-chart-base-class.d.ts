import { KdChartsSvc } from './kd-angular-charts-svc';
import { IChartConfig, ID3DataData, ID3DataRange, ID3YData, ILegendData } from './kd-angular-charts-interface';
import { KdDomElemSvc } from '../kd-common/index';
export declare class KdChartBaseClass {
    _chartSvc: KdChartsSvc;
    _domSvc: KdDomElemSvc;
    isRtl: boolean;
    config: IChartConfig;
    data: Array<ID3DataData>;
    initData: Array<ID3DataData>;
    chartType: Array<string>;
    chartCategory: 'pie' | 'bar' | 'column' | 'line' | 'area' | 'dot' | 'spline' | 'map';
    /**
     * max and min value of across all series
     * type {ID3DataRange}
     */
    dataRange: ID3DataRange;
    svg: any;
    svgParent: any;
    svgContainer: any;
    svgRect: any;
    graph: any;
    width: number;
    height: number;
    x: any;
    y: any;
    xAxisArr: Array<any>;
    yAxis: any;
    xAxisFunc: any;
    yAxisFunc: any;
    axisMax: number;
    axisMin: number;
    domainMax: number;
    domainMin: number;
    gridLinesContainer: any;
    axisLabelContainerArr: Array<any>;
    tickValues: Array<number>;
    haveNegative: boolean;
    /**
     * used only by bar.
     * barGroupPadding is used only for cluster --> the padding between each rect in a category
     * bandPadding is given to d3 --> the padding between each category
     * type {IBaseClassBarObj}
     */
    bar: {
        isInvert: boolean;
        clusterPaddingPercent: number;
        bandPadding: number;
    };
    rangeList: object;
    lengthOfTransition: number;
    dataLabelContainer: any;
    legendData: {
        [key: string]: ILegendData;
    };
    errorMsg: string;
    private _setChartTimeout;
    constructor(_chartSvc: KdChartsSvc, _domSvc: KdDomElemSvc);
    setSvg(): void;
    /**
     * set svg width and height. this function is becos of export feature, the export plugins requires svg width and height to be inline attributes with definite number
     * have to be called by all charts
     * param {'x' | 'y'} _axis
     */
    setSvgDimension(_axis: 'x' | 'y'): void;
    private _clearSvgDimension;
    /**
     * set this.width and this.height for axis scales. only called by charts with axis
     * param {'x' |'y'}         _axis
     * param {boolean} _skipCal : skip getSvgOffset calculations
     */
    private _setGraphDimension;
    /**
     * set Chart Service variables
     */
    private _setChartSvc;
    private _setLinearScale;
    private _setBandScale;
    private _getRangeVal;
    private _setRange;
    private _getCenterBandPosition;
    private _setScaleByDirection;
    /**
     * (for line only)
     * happens at first load and on change and may happen if data is sliced during trimX()
     */
    private _setLineScaleX;
    setDomain(_xScaleType: 'string' | 'band'): void;
    private _setDomain;
    private _setWidthHeightScale;
    /**
     * set clip path to this.width and this.height to make sure graph will not be drawn out of graphing region
     */
    private _setClipPath;
    private _setAxisMaxAndMin;
    /**
   * will return an object with following properties
   * needRedraw: to determine whether to redraw the axis (and reset the domain)
   * interval: pass out the lastest interval (that have no overlap) for performance reasons, so that the while loop will only run once on needRedraw
   */
    private _findIntervalForNoOverlap;
    private _setGridLines;
    private _setXAxisGrid;
    private _setYAxisGrid;
    private _setYAxisMinorGrid;
    setAxis(): void;
    private _getEachAxisFunc;
    chartTimeout(_callback: Function): void;
    removeChart(): void;
    private _removeElemInArrayForm;
    private _setXAxisLabel;
    private _setAxisLabelContainer;
    private _calculateXSpacing;
    private _trimX;
    private _calculateMaxNoOfX;
    private _drawAxisLabel;
    /**
     * _params can be ID3DataData or can contain callbacks
     * {
     *     ...
     *     callbacks: {
     *         'mouseover': Function,
     *         'mouseout': Function
     *     }
     * }
     */
    _initMouseEvents(_path: any, _params?: any): void;
    setLabel(_yData: ID3YData, _xData: string | number, _xPosition: number, _yPosition: number): any;
    transformPosition(x: number | string, y: number | string, isAttribute?: boolean): string;
    getDotId(xData: string | number, yId: string): string;
    isDataExist(_item: any, _yIndex: number): boolean;
    private _setLabelContainer;
    /**
     * _params for bar: { valueSign: -1 or 0 or 1, dimensions: width, height, xPos, yPos}
     * _params for line: { dotSize: number, labelLength: number}
     */
    setLabelTextPosition(labelText: any, _yPosition: number, _params?: {
        [key: string]: any;
    }): void;
    private _setLabelPosition;
    private _applyLabelPosition;
}
