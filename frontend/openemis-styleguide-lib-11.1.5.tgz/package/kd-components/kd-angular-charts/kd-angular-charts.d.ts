import { EventEmitter, OnInit, OnChanges, SimpleChanges, ElementRef, OnDestroy } from '@angular/core';
import { DomSanitizer } from '@angular/platform-browser';
import { KdConvertionSvc, KdDataSvc } from '../kd-common/index';
import { KdChartsSvc } from './kd-angular-charts-svc';
import { IChartData, IChartConfig, ILegendData, ID3Data, IChartApi, IChartInternalApi } from './kd-angular-charts-interface';
export declare class KdCharts implements OnInit, OnChanges, OnDestroy {
    private _sanitizer;
    private _elementRef;
    private _chartSvc;
    _convertionSvc: KdConvertionSvc;
    _dataSvc: KdDataSvc;
    isLayerLoading: boolean;
    smallLoaderValue: any;
    pieData: Array<any>;
    pieColor: Array<any>;
    backgroundColor: string;
    config: IChartConfig;
    data: ID3Data;
    legendList: Array<string>;
    checkMapScale: boolean;
    chartCategory: 'pie' | 'bar' | 'column' | 'line' | 'area' | 'dot' | 'spline' | 'map';
    isAxisChart: boolean;
    isNegativeStack: boolean;
    chartType: Array<string>;
    rotateTitleX: boolean;
    rotateTitleY: boolean;
    chartHide: boolean;
    haveAxisPadding: boolean;
    haveAxisSpecialPadding: boolean;
    xAxisOpposite: boolean;
    havekdChartNoBorderClass: boolean;
    htmlClassObj: any;
    api: IChartInternalApi;
    icons: object;
    legendData: {
        [key: string]: ILegendData;
    };
    markersLegend: Array<any>;
    private shapes;
    private legendInactive;
    private _colorListPosition;
    private _resizeTimeout;
    private _resizeListener;
    private _pieDoneFlag;
    chartData: IChartData;
    chartConfig: IChartConfig;
    chartApi: IChartApi;
    xThreshold: number;
    seriesThreshold: number;
    outputLegendData: EventEmitter<{
        [key: string]: ILegendData;
    }>;
    outputData: EventEmitter<ID3Data>;
    outputArea: EventEmitter<ID3Data>;
    constructor(_sanitizer: DomSanitizer, _elementRef: ElementRef, _chartSvc: KdChartsSvc, _convertionSvc: KdConvertionSvc, _dataSvc: KdDataSvc);
    ngOnInit(): void;
    ngOnChanges(_simpleChanges: SimpleChanges): void;
    ngOnDestroy(): void;
    /**
     * For EXPORT. export skips data massage and generateLegendData, hence need to setLegendData separately
     * (accurate as of v3.7.0) as legendData is for internal use, we do not put in Input. this function is accessed via ViewChild from KdVisualization
     * param {ILegendData }} _legendData
     */
    setLegendData(_legendData: {
        [key: string]: ILegendData;
    }): void;
    /**
     * initiate api from outside kd charts component
     */
    private initApi;
    private _setConfig;
    setChartStyle(_config: IChartConfig): void;
    private _setClassNames;
    private _updateLegendIconWithIndex;
    private _populateLegendIcon;
    private _setLabelStyle;
    private _setData;
    private _setChartType;
    private _setDataColorShape;
    private _changeSeries;
    private _isChangeSeries;
    onLegendClick(_id: string): void;
    onClusterClick(_id: any): void;
    getOutputLegend(_legendData: {
        [key: string]: ILegendData;
    }): void;
    getOutputData(_data: any): void;
    getReady(_value: boolean): void;
    private _updateLegendItem;
    private _updateLegendIcon;
    private _toggleDataLabel;
    private _applyLabelStyle;
    private updateConfig;
    private updateData;
    private _generateLegendData;
    private _dataMassage;
    private _dataMassageForPie;
    private _dataMassageForMap;
    private _setLegendForMap;
    private _getTotalSum;
    private _getConfig;
    private _getLegendConfig;
    _getDefaultConfig(_element: any, _seriesIndex?: number): string;
    getOutputMarker(_data: any): void;
}
