import { KdDomElemSvc } from '../kd-common/index';
import * as helper from './helper-svc/index';
import { ISeries, IChartConfig, IYAxisConfig, IChartData, ID3DataData, IMaxMinInterval, ID3DataRange, ILegendData, IForLoopInfo, IAxisLabelBooleanChecks, IAxisTransformPos, IXInfo, IYAxisLabelRange } from './kd-angular-charts-interface';
export declare class KdChartsSvc {
    private _domSvc;
    private _config;
    private _svg;
    private _svgRect;
    private _svgParentRect;
    private _isInvert;
    private _chartType;
    private _chartCategory;
    private _isRotate;
    private _labelLength;
    private _currVertAxisTitle;
    private _isRtl;
    private _defaultSvgMargin;
    private _svgMargin;
    private _yAxisLabelWidth;
    private _axisLabelContainer;
    private _axisLabelDummy;
    private _axisLabelContainerMarginLeft;
    private _minXSpacing;
    private _xSpacing;
    private _xScaleType;
    private _axisD3Format;
    private _isXReversed;
    private _isYReversed;
    private dataLabelPushDownRange;
    private _isNegativeStack;
    gridSvc: helper.KdChartsGridSvc;
    tooltipSvc: helper.KdChartsTooltipSvc;
    constructor(_domSvc: KdDomElemSvc);
    set config(_config: IChartConfig);
    get config(): IChartConfig;
    set svg(_svg: any);
    set svgRect(_svgRect: any);
    set chartType(_chartType: any);
    set chartCategory(_chartCategory: any);
    set isInvert(_isInvert: any);
    set svgParentRect(_svgParentRect: any);
    set isRotate(_isRotate: boolean);
    get isRotate(): boolean;
    set labelLength(_labelLength: number);
    get labelLength(): number;
    get svgMargin(): {
        top: number;
        right: number;
        bottom: number;
        left: number;
    };
    set xScaleType(_xScaleType: "string" | "band");
    get xScaleType(): "string" | "band";
    get xSpacing(): number;
    get axisD3Format(): string;
    get yAxisLabelWidth(): IYAxisLabelRange;
    set isRtl(_isRtl: any);
    set isXReversed(_isXReversed: boolean);
    get isXReversed(): boolean;
    set isYReversed(_isYReversed: boolean);
    get isYReversed(): boolean;
    set isNegativeStack(_isNegativeStack: boolean);
    get isNegativeStack(): boolean;
    /**
     * for rotating vertical axis. if axis is enabled, appends class-name 'rotate-title' to kd charts.
     * param  {Array<string>} _type   chart type: if horizontal bar, use xAxis's(the vertical axis) config
     * param  {any}           _config
     * return {boolean}
     */
    checkRotateTitleEnabled(_type: Array<string>, _config: any): boolean;
    setVertAxisAndChartMargin(_id: string): void;
    repositionVerticalAxisTitle(): void;
    setMaxAndMin(_yAxisConfig: IYAxisConfig, _dataRange: ID3DataRange): IMaxMinInterval;
    setAxisD3Format(_interval: number): void;
    getYAxisLabelText(_yAxisConfig: IYAxisConfig, _value: number): string;
    /**
     * Y axis label dummy. appends text element to svg and returns the width of label
     * param  {number |      string}      _value: label's value
     * param  {string}                    _class: class name for dummy
     * return {number}                    returns actual rendered width of label
     */
    setDummyAxisLabel(_value: number, _class: string): number;
    /**
     * chart width and height have to be calculated based on how long y axis labels are (eg: a lot of space allocated for 1,000,000 as compared to 10)
     * returns this.width or this.height depending on _axis given
     * param  {'x'|'y'}         _axis
     * param  { axisMax: number, axisMin: number } _axisVal
     * return {number}
     */
    getSvgOffset(_axis: 'x' | 'y', _axisVal: IYAxisLabelRange): number;
    /**
     * round axisMax/Min value to interval (eg: Max value is 10 but interval is 3, so max value will be rounded to either 9 or 12)
     * _isAutoRoundToNextInterval is enabled, round to 12
     * _isAutoRoundToNextInterval is disabled, round to 9
     *
     * param  {number}  _value
     * param  {number}  _interval
     * param  {boolean} _isAutoRoundToNextInterval
     * param  {'up' | 'down'}      _roundDir
     * return {number}
     */
    setAxisRoundValue(_value: number, _interval: number, _isAutoRoundToNextInterval: boolean, _roundDir: 'up' | 'down'): number;
    getTickValues(_min: number, _max: number, _interval: number): Array<number>;
    /**
     * set Y axis Label Config
     * param {any}        _axis is Element/d3-selection
     * param {'xAxis' | 'yAxis'}     _direction
     */
    setAxisLabelConfig(_axis: any, _direction: 'x' | 'y'): void;
    getYAxisMaxAndMinLabelWidth(_axisVal: IYAxisLabelRange): IYAxisLabelRange;
    private _getUpperBoundForTickValues;
    /**
     * set axis Label Container (currently only used for X axis)
     * param  {number} _xSpacing
     * param  {string} _extraClassName [same level as .kdx-charts-axis-label-container. Additional className in case of doubleAxis]
     * return {any}
     */
    setAxisLabelContainer(_extraClassName?: string): any;
    /**** Axis Label Dummy *******/
    setAxisLabelDummy(_id: string, _xSpacing: number, _longestText: string): void;
    setAxisLabelDummyText(_longestText: string): void;
    getAxisLabelDummyRect(): any;
    private _setAxisLabelDummyElement;
    private _setAxisLabelDummyHtml;
    private _setAxisLabelDummyStyle;
    /**** Others *******/
    private _checkRotate;
    _setAxisLabelLength(): void;
    private _getAxisMargin;
    setAxisLabelContainerStyle(_container: any): void;
    /**
     * set X axis Label Position
     * param {any}     _labelContainer
     * param {number}  _tickPos
     * param {IAxisLabelBooleanChecks} _booleanChecks
     */
    setAxisLabelPosition(_labelContainer: any, _tickPos: number, _booleanChecks: IAxisLabelBooleanChecks): void;
    /**
     * data labels have to be repositioned according to title and axis Labels's width and position
     * param {any} _dataLabelContainer d3-selection
     * param {any} _axisLabelContainer d3-selection
     */
    repositionDataLabel(_dataLabelContainer: any, _axisLabelContainer?: any): void;
    private _calculateDataLabelLeft;
    private _calculateDataLabelTop;
    private _getHorizTitleHeight;
    /****Vertical Align*****/
    _getLabelTextHeight(): number;
    _checkBoundary(_type: any, _yPosition: number, _chartHeight: number, _dotSize?: number): boolean;
    needOffsetForColumn(_verticalAlign: 'top' | 'middle' | 'bottom', _params?: {
        [key: string]: any;
    }): boolean | number;
    getDefaultVerticalAlign(_config: any, _params: any): 'top' | 'middle' | 'bottom';
    /**
     * in arabic, numbers are in ltr mode (eg: negative sign is typed first)
     * Hence wrapping a div around number (only) with className '.kdx-charts-display-number' to force direction: ltr
     * param  {number} _number
     * return {string}
     */
    wrapNumberInInlineDiv(_number: number | string): string;
    replaceStringWithNumber(_value: string | number): number;
    getForLoopSequence(_chartType: string[]): 'ascending' | 'descending';
    getForLoopInfo(_type: 'ascending' | 'descending', arrLength: number): IForLoopInfo;
    getXInfo(_data: Array<ID3DataData>, _config: IChartConfig): IXInfo;
    checkAndReturnLabelsPositive(_value: number): number;
    findDecimalPlace(_number: number): number;
    getLabelText(_format: string, _value: number | string, _isHTML?: boolean, _d3Format?: string): string;
    getLabelFormatReplace(_format: string, _text: string): string;
    isInterger(_value: number | string): boolean;
    getD3Format(_value: string | number, _toDecimalPlace?: number): string;
    changeValueToD3Format(_value: string | number, _format: string): string;
    getLongerNumber(_num1: number, _num2: number): number;
    setChartContainerMargin(_chartContainer: any): void;
    transformGraphContainer(_container: any): void;
    setSvgAttribute(_element: any, _config: {
        [key: string]: string | number;
    }): void;
    isExist(_yElem: any): boolean;
    isValueExist(_val: any): boolean;
    getD3MaxOrMin(_arr: Array<number>, _type: 'max' | 'min'): number;
    getAxisTransformPos(_axis: 'x' | 'y', _opposite: boolean, _transformPos: IAxisTransformPos): string;
    getLimitedCategories(_initCategories: Array<string>, _xThreshold: number): Array<string>;
    /**
     * return config into css string so can be added into element
     * param  {object}  defaultConfig config
     * param  {boolean} isForTooltip  if tooltip, compare default config with config pass from user
     * return {string}                css styling
     */
    getStyle(defaultConfig: object, isForTooltip?: boolean): string;
    /**
     * check if line missing
     * param {[type]} _data        data
     * param {[type]} _dataIndex   xIndex
     * param {[type]} _seriesIndex yIndex / yValueIndex
     */
    isSeriesNull(_data: IChartData | Array<ID3DataData>, _dataIndex: number, _seriesIndex: number): {
        isPrevNull: boolean;
        isPrevNotNull: boolean;
        isNextNull: boolean;
        isNextNotNull: boolean;
        isAppearing: boolean;
        isDisappearing: boolean;
    };
    _isChartData(object: any): object is IChartData;
    /**
     * required for percentage calculation of 100 stack. returns a array of total sum of data value of each categories.
     * param  {Array<ISeries>} _seriesArr
     * param  {Array<string>}  _categories
     * return {Array<number>}
     */
    getTotalSumArrFromSeries(_seriesArr: Array<ISeries>, _categories: Array<string>, seriesLength: number): Array<number>;
    /**
     * check if line missing
     * param {[key: string]: ILegendData} _legendData pie chart legend data
     * param {any} _data pie chart data
     * param {IChartConfig} _config pie chart legend config
     */
    setPieData(_legendData: {
        [key: string]: ILegendData;
    }, _data: any, _config: IChartConfig, _seriesThreshold: number): {
        pieData: Array<any>;
        pieColor: Array<string>;
        legendData: {
            [key: string]: ILegendData;
        };
    };
    singlePieDataMassage(_legendData: {
        [key: string]: ILegendData;
    }, _data: any, _config: IChartConfig, _seriesThreshold: number): {
        pieData: any[];
        pieColor: string[];
        legendData: {
            [key: string]: ILegendData;
        };
    };
    setMapLegendData(_legendData: {
        [key: string]: ILegendData;
    }, _data: any, _config: IChartConfig): {
        [key: string]: ILegendData;
    };
    getDefaultConfig(_element: any, _seriesIndex: number, _config: IChartConfig): string;
    setSingleLegendLevels(_dataClasses: Array<any>, _decimalPrecison: number, _valueSuffix: string, _originalLegend?: {
        [key: string]: ILegendData;
    }): {
        [key: string]: ILegendData;
    };
}
