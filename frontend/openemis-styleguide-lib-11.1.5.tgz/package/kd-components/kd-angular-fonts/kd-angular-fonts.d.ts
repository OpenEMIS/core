import { OnInit } from '@angular/core';
export declare class KdFonts implements OnInit {
    _fontList: Array<any>;
    fontType: string;
    textFilter: string;
    ngOnInit(): void;
}
