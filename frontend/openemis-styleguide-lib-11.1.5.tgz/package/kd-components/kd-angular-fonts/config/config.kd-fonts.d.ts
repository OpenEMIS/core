export declare const KD_FONTS: Array<any>;
