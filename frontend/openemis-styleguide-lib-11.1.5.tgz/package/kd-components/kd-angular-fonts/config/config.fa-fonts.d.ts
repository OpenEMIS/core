export declare const FONTAWESOME_FONTS: Array<any>;
