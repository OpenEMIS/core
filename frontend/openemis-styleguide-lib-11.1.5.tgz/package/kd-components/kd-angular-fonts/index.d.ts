export { KdFonts } from './kd-angular-fonts';
export { FilterArrayPipe } from './kd-font-pipe.pipe';
