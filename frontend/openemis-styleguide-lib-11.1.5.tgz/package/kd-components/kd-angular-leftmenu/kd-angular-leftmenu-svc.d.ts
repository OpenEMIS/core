import { KdBroadcaster } from '../kd-common/index';
import { Observable } from 'rxjs';
export declare class KdLeftmenuSvc {
    private broadcaster;
    constructor(broadcaster: KdBroadcaster);
    setIsOpen(_sideConfig: Array<any>): Array<any>;
    isArrayEqual(currentItem: Array<number>, previousItem: Array<number>): boolean;
    getId(item: any | string): Array<number>;
    closeDifferent(currentItem: Array<number>, previousItem: Array<number>, _navItems: Array<any>): void;
    toggleState(currentId: Array<any>, state: string, _navItems: Array<any>): void;
    private _processNavItem;
    private _checkNavItem;
    private _idFormatter;
    onMenuItemClicked(): Observable<any>;
    menuItemClicked(_item: any): void;
}
