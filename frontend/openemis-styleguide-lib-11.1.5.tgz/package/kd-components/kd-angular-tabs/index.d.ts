export { KdTabs } from './kd-angular-tabs';
