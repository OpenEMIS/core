export * from './kd-angular-footer';
