import { ViewContainerRef, OnInit, AfterViewInit, EventEmitter, Renderer2 } from '@angular/core';
import { Router } from '@angular/router';
import { KdDomElemSvc } from '../kd-common/index';
export declare class KdFooter implements OnInit, AfterViewInit {
    private _vcr;
    private _router;
    private _renderer;
    private _domSvc;
    _currentYear: number;
    _latestVersion: string;
    private _el;
    private _float;
    version: string;
    enableCustom: boolean;
    customMessage: string;
    enableFloat: string;
    checkFloat: EventEmitter<any>;
    constructor(_vcr: ViewContainerRef, _router: Router, _renderer: Renderer2, _domSvc: KdDomElemSvc);
    onResize(event: any): void;
    ngOnInit(): void;
    ngAfterViewInit(): void;
    onMobileView(): boolean;
    private _setVersioning;
}
