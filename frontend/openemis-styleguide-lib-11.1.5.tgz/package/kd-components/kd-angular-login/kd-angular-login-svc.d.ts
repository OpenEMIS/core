import { ILoginConfig, ILanguageOptionsConfig, IFormLinkConfig } from './kd-angular-login-interface';
export declare class KdLoginSvc {
    private _domSvc;
    private _renderer;
    getHeaderConfigValues(_config: any, _defaultConfig: any): any;
    getLanguageConfigValues(_config: ILoginConfig): Array<ILanguageOptionsConfig>;
    getLangageDefaultValue(_config: ILoginConfig): string;
    getSixDefaultLanguage(): Array<any>;
    updateLanguageDir(_config: ILoginConfig, _selectedIndex: string): string;
    checkLanguageDir(_langOptions: any, _selectedIndex: string): string;
    getFormInputs(_type: string, _config?: any): Array<any>;
    getButtonLabel(_type: string, _label?: string): string;
    getFormLinks(_config: ILoginConfig, _type: string): Array<IFormLinkConfig>;
    private getDefaultFormLinks;
    private _setProductAppConfig;
    getLogoSizeClass(headerConfig: any): string;
    getDemoLogin(requestString: string): any;
}
