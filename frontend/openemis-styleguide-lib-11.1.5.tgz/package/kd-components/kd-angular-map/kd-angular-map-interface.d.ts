export interface IMapZoomConfig {
    value: number;
    isZoomButton?: boolean;
    isScrollZoom?: boolean;
    isTouchZoom?: boolean;
    isDoubleClickZoom?: boolean;
}
export interface IMapMarker {
    icon?: string;
    markerColor?: 'darkred' | 'purple' | 'orange' | 'green' | 'blue' | 'darkgreen' | 'darkblue';
    prefix?: string;
    iconColor?: 'white' | 'black';
    title: string;
    id?: string;
}
export interface IMapPosition {
    lng: number;
    lat: number;
}
export interface IMapClusterMarkerData extends IMapPosition {
    id: string;
    content?: string;
}
export interface IMapClusterData {
    [key: string]: {
        data: IMapClusterMarkerData[];
        marker?: IMapMarker;
    };
}
export interface IMapApi {
    resizeMap?: () => void;
    getZoom?: () => number;
}
export interface ICommonText {
    text?: string;
    align?: 'center' | 'left' | 'right';
    style?: {
        [key: string]: string;
    };
}
export interface IMapConfig {
    id?: string;
    zoom?: IMapZoomConfig;
    errorMessage?: string;
    attribution?: string;
    type?: 'basic' | 'cluster' | 'group-cluster';
    googleLink?: {
        display: boolean;
        position: string;
    };
    marker?: IMapMarker;
    content?: string;
    mapArea?: {
        style?: {
            [key: string]: string;
        };
    };
    title?: ICommonText;
    subtitle?: ICommonText;
    legend?: {
        enabled?: boolean;
        float?: boolean;
        align?: 'left' | 'center' | 'right';
        verticalAlign?: 'top' | 'middle' | 'bottom';
        layout?: 'horizontal' | 'vertical';
        style?: {
            [key: string]: string;
        };
        item?: {
            style?: {
                [key: string]: string;
            };
        };
        title?: ICommonText;
    };
    footer?: {
        enabled?: boolean;
        bottomLabel?: ICommonText;
        footNote?: ICommonText;
    };
}
