export { KdMap } from './kd-angular-map';
export { IMapZoomConfig, IMapApi, IMapConfig, IMapPosition, IMapClusterData } from './kd-angular-map-interface';
