import * as L from 'leaflet';
import 'leaflet.markercluster';
import 'leaflet.awesome-markers/dist/leaflet.awesome-markers';
import { IMapMarker, IMapConfig } from './kd-angular-map-interface';
export interface IMapPopulateClusterData {
    markersLegend: Array<any>;
    clusterMarkers: {
        [key: string]: L.MarkerClusterGroup;
    };
}
export declare class KdMapSvc {
    static colors: Array<string>;
    setIcon(_options?: IMapMarker): L.Icon;
    populateMarkers(_data: any, _map: L.Map, _displayType: string): IMapPopulateClusterData;
    private _iconCreateFunction;
    getDefaultConfig(): IMapConfig;
}
