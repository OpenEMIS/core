import { OnInit, EventEmitter, ViewContainerRef } from '@angular/core';
import { IFileResult } from './kd-fileinput-interface';
export declare class KdFileInput implements OnInit {
    private _vcr;
    _leftButton: string;
    _fileResult: IFileResult;
    config: any;
    value: any;
    result: EventEmitter<any>;
    constructor(_vcr: ViewContainerRef);
    ngOnInit(): void;
    handleFileSelect(event: any): void;
    removeFile(_event: Event): void;
    buttonCallback(_event: Event, _button: any): void;
    private _checkInitFile;
    private _setFileType;
    private _setLeftBtn;
}
