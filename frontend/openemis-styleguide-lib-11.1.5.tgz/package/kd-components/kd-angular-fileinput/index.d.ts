export { KdFileInput } from './kd-angular-fileinput';
export { IFileResult } from './kd-fileinput-interface';
