export { KdSlider } from './kd-angular-slider';
export { KdSliderContent } from './kd-angular-slider-content';
export { ISliderConfig, ISliderApi } from './kd-angular-slider-interface';
