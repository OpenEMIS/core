export declare const AG_GRID_KEY: {
    value: string;
};
