/*******************************************************************************
    File: config.variable.ts
    Version: 1.0
    Purpose: General variables usage for kd-component libraries

    Last change:
        -

 ******************************************************************************/
export declare const DELAY_TIME: number;
