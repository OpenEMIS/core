export { KdPageBase, IPageBaseOptions } from './kd-page-base';
export { KdPageBaseEvent } from './kd-page-base.event';
