import { OnInit } from '@angular/core';
import { ToasterService, ToasterConfig } from 'angular2-toaster';
import { KdAlertEvent } from './kd-alert-event';
export declare class KdAlert implements OnInit {
    private _toasterService;
    private _kdAlertEvent;
    _toasterconfig: ToasterConfig;
    private _config;
    private _toasterDefaultConfig;
    constructor(_toasterService: ToasterService, _kdAlertEvent: KdAlertEvent);
    ngOnInit(): void;
    registerAlertBroadcast(): void;
}
