import { Observable } from 'rxjs';
import { KdBroadcaster } from '../kd-common/index';
export declare class KdAlertEvent {
    private broadcaster;
    constructor(broadcaster: KdBroadcaster);
    show(data: any): void;
    success(data: any): void;
    error(data: any): void;
    info(data: any): void;
    warn(data: any): void;
    on(): Observable<any>;
}
