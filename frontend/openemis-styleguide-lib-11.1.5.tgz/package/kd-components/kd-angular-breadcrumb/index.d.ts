export { KdBreadcrumb } from './kd-angular-breadcrumb';
export { IBreadcrumb, IBreadcrumbConfig, IBreadcrumbsApi } from './kd-angular-breadcrumb-interface';
