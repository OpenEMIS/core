import { ViewContainerRef } from '@angular/core';
import { IBreadcrumbConfig } from './kd-angular-breadcrumb-interface';
import { KdDomElemSvc } from '../kd-common/index';
export declare class KdBreadcrumbSvc {
    private _domeSvc;
    constructor(_domeSvc: KdDomElemSvc);
    /**
     * Returning the list of final breadcrumb which needed to be display.
     */
    renderBreadcrumbView(_vcr: ViewContainerRef, _breadcrumbConfig: IBreadcrumbConfig): Array<any>;
    private _sortInitialBreadcrumb;
    private _sortHome;
    private _sortList;
    private _getFormattedBreadcrumb;
    private _applyLastBreadcrumbFormat;
}
