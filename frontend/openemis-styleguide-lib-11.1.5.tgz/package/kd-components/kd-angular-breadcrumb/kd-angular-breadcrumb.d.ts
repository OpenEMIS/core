import { OnInit, OnChanges, AfterViewInit, ViewContainerRef, SimpleChanges } from '@angular/core';
import { KdBreadcrumbSvc } from './kd-angular-breadcrumb-svc';
import { IBreadcrumbInternal, IBreadcrumbConfig } from './kd-angular-breadcrumb-interface';
export declare class KdBreadcrumb implements OnInit, OnChanges, AfterViewInit {
    private _vcr;
    private _breadcrumbSvc;
    breadcrumbResult: Array<IBreadcrumbInternal>;
    private resizeSub;
    breadcrumbConfig: IBreadcrumbConfig;
    api: any;
    constructor(_vcr: ViewContainerRef, _breadcrumbSvc: KdBreadcrumbSvc);
    ngOnInit(): void;
    ngOnChanges(_simpleChanges: SimpleChanges): void;
    ngAfterViewInit(): void;
    private _initApi;
}
