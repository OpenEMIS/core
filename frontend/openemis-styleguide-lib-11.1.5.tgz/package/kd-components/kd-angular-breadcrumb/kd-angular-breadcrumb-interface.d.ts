export interface IBreadcrumbsApi {
    addBreadcrumb?: (_item: IBreadcrumb) => void;
    updateBreadcrumb?: (_pos: number, _item: IBreadcrumb) => void;
    getBreadcrumbs?: () => IBreadcrumbConfig;
}
export interface IBreadcrumbConfig {
    home?: IBreadcrumb;
    list?: Array<IBreadcrumb>;
}
export interface IBreadcrumb {
    name?: string;
    icon?: string;
    path?: string;
    url?: string;
    [propName: string]: any;
}
export interface IBreadcrumbInternal extends IBreadcrumb {
    toEllipsis?: boolean;
    toRender?: boolean;
}
