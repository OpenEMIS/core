export { KdTooltip } from './kd-angular-tooltip';
export { KdTooltipDirective, ITooltipApi } from './kd-angular-tooltip-directive';
