export { KdMultiSelectTable } from './kd-angular-multiselect-table';
