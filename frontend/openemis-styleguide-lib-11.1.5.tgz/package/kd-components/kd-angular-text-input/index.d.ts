export { KdTextInput } from './kd-angular-text-input';
