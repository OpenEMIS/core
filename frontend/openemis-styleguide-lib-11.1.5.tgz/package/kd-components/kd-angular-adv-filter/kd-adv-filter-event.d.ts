import { Observable } from 'rxjs';
import { KdBroadcaster } from '../kd-common/index';
export declare class KdIntAdvFilterEvent {
    private _broadcaster;
    constructor(_broadcaster: KdBroadcaster);
    onToggleAdvSearch(): Observable<any>;
    onSendData(): Observable<any>;
    sendAdvSearchStatus(data?: any): void;
}
export declare class KdAdvFilterEvent {
    private _broadcaster;
    constructor(_broadcaster: KdBroadcaster);
    toggleAdvSearch(data?: any): void;
    sendData(data?: any): void;
    onSendAdvSearchStatus(data?: any): Observable<any>;
}
