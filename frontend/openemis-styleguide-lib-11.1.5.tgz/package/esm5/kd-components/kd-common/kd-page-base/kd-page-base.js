import { NavigationEnd } from '@angular/router';
import { KdConvertionSvc, KdDataSvc } from '../index';
var KdPageBase = /** @class */ (function () {
    function KdPageBase(options) {
        var _this = this;
        this.options = options;
        this._textOmitted = '';
        this._header = {
            brandLogo: {},
            userInfo: {
                name: '',
                imgType: 'icon',
                imgSrc: '',
                path: ''
            },
            btnGroup: []
        };
        this._pageheader = {
            pageheaderText: '',
            leftBtn: [],
            // leftBtn: [{
            //     type: 'add'
            // }],
            moreBtn: false,
            moreAction: [],
            searchBtn: false,
            searchEvent: ['change', 'keyup']
        };
        this._breadcrumbList = {
            home: { icon: 'fa fa-home', url: '', path: '/App/InstitutionClasses/list' },
            list: []
        };
        this._pageParams = {};
        this._prevPageURL = '';
        this._currentURL = '';
        this.convertionSvc = new KdConvertionSvc();
        this.dataSvc = new KdDataSvc();
        // this._prevPageInfo = this.initPrevHistory();
        // this.options.router.events
        //     .filter(e => e instanceof RoutesRecognized)
        //     // .filter(e => (e.constructor.name === 'RoutesRecognized') || ( e.constructor.name === 'NavigationEnd'))
        //     .pairwise()
        //     .subscribe((e: any[]): void => {
        //         console.log('1 on init > url info ', e);
        //         console.log(new Date());
        //         console.log(e[0]);
        //         console.log(e[e.length - 1]);
        //         this._prevPageInfo = e[0].urlAfterRedirects;
        //         // console.log('this._prevPageInfo = > ', this._prevPageInfo);
        //         // this._routerHistorySub.unsubscribe();
        //     });
        // console.log('constructor >> ',this._prevPageInfo);
        this._routerSub = this.options.router.events
            .subscribe(function (event) {
            // if (event instanceof RoutesRecognized) {
            // console.log('RoutesRecognized > event - ', Object.assign({}, event));
            // }
            if (event instanceof NavigationEnd) {
                // console.log('>>', event);
                _this._prevPageURL = JSON.stringify(_this._currentURL);
                _this._currentURL = event.urlAfterRedirects;
                _this._breadcrumbList.list = _this.convertionSvc.urlToArray(event.urlAfterRedirects, _this._textOmitted);
                // console.log('this._breadcrumbList.list',this._breadcrumbList.list);
                if (typeof _this.options.pageEvent !== 'undefined') {
                    _this.options.pageEvent.appReady();
                    _this.options.pageEvent.onAppReadyComplete();
                }
                if (typeof _this.options.pageBaseEvent !== 'undefined') {
                    console.error('please change to PageEvent instead of PageBaseEvent');
                }
            }
        });
        this._activatedRouteSub = this.options.activatedRoute.params.subscribe(function (_params) {
            _this._pageParams = _params;
        });
    }
    // protected enableLoadV2(_bool: boolean) {
    //     // this.options.pageEvent.loadV2(_bool);
    // }
    /**
     * [destroyPageBaseSub - Manually discard the all the subscriptions]
     */
    KdPageBase.prototype.destroyPageBaseSub = function () {
        if (typeof this._routerSub !== 'undefined')
            this._routerSub.unsubscribe();
        if (typeof this._activatedRouteSub !== 'undefined')
            this._activatedRouteSub.unsubscribe();
    };
    /**
     * Application Header (Product Header)
     */
    KdPageBase.prototype.getHeaderConfig = function () {
        return this._header.userInfo;
    };
    KdPageBase.prototype.setHeaderConfig = function (_conf) {
        this._header.userInfo = _conf;
    };
    KdPageBase.prototype.updateHeader = function () {
        this.options.pageEvent.updateHeader(this._header);
    };
    /**
     * Left Navigation
     */
    KdPageBase.prototype.setLeftMenuList = function (_leftMenuObj) {
        this.options.pageEvent.updateLeftmenu(_leftMenuObj);
    };
    /**
     * Page Header
     */
    KdPageBase.prototype.getPageTitle = function () {
        return this._pageheader.pageheaderText;
    };
    KdPageBase.prototype.setPageTitle = function (_title, _humanize) {
        if (_humanize === void 0) { _humanize = true; }
        var tempStr = _title.replace(this._textOmitted, '');
        if (_humanize) {
            tempStr = this.humanize(this.underscore(tempStr));
        }
        // console.log('setPageTitle=',tempStr);
        this._pageheader.pageheaderText = tempStr;
    };
    KdPageBase.prototype.getToolbarMainBtns = function () {
        return JSON.parse(JSON.stringify(this._pageheader.leftBtn));
    };
    KdPageBase.prototype.setToolbarMainBtns = function (_buttons) {
        this._pageheader.leftBtn = _buttons;
    };
    KdPageBase.prototype.getToolbarMoreActionBtns = function () {
        return this._pageheader.moreAction;
    };
    KdPageBase.prototype.enableMoreActionBtns = function (_enable, _buttons) {
        this._pageheader.moreBtn = _enable;
        if (_buttons) {
            this._pageheader.moreAction = _buttons;
        }
    };
    KdPageBase.prototype.enableToolbarSearch = function (_enable, _callback) {
        this._pageheader.searchBtn = _enable;
        if (_enable && _callback) {
            this._pageheader.searchCallback = _callback;
        }
    };
    KdPageBase.prototype.updateSearchText = function (_searchText) {
        this._pageheader.searchText = _searchText;
    };
    KdPageBase.prototype.updatePageHeader = function () {
        console.log('broadcast updatePageHeader', this._pageheader);
        this.options.pageEvent.updatePageHeader(this._pageheader);
    };
    /**
     * Breadcrumbs
     */
    KdPageBase.prototype.setBreadcrumbsList = function (_list) {
        this._breadcrumbList.list = _list;
        this.updateBreadcrumb();
    };
    KdPageBase.prototype.getBreadcrumbsList = function () {
        return this._breadcrumbList.list;
    };
    KdPageBase.prototype.updateBreadcrumb = function () {
        this.options.pageEvent.updateBreadcrumb(JSON.parse(JSON.stringify(this._breadcrumbList)));
    };
    /**
     * Alerts
     */
    KdPageBase.prototype.setAlert = function (_config, _type) {
        if (this.options.alertEvent) {
            this.options.alertEvent[_type](_config);
        }
        else {
            console.warn('Missing event - KdAlertEvent');
        }
    };
    /**
     * [setModal Creating modal view]
     *  _configConfimation {
     *              header: '',
     *              message: '',
     *              buttonConfirm: {
     *                  text: 'test text',
     *                  callback: () =>{
     *
     *                  }
     *              }
     *          }
     */
    KdPageBase.prototype.setModal = function () {
        var _pageBaseEvent;
        if (this.options.pageEvent) {
            _pageBaseEvent = this.options.pageEvent;
        }
        else {
            console.warn('Please import \'PageBaseEvent\' to use modal');
        }
        /**
         * [confirmation a modal dialog with 2 buttons: 'Confirm' and 'Cancel']
         */
        function confirmation(_config) {
            if (_pageBaseEvent) {
                var updatedConfig = {};
                var defaultConfig = {
                    suspendClose: true,
                    title: 'Alert',
                    body: 'Dummy text - confirmation',
                    button: [{
                            text: 'Confirm',
                            class: 'btn-text',
                            callback: function () { }
                        },
                        {
                            text: 'Cancel',
                            class: 'btn-outline',
                            callback: function () { _pageBaseEvent.updateModal({ close: true }); }
                        }]
                };
                updatedConfig = applyConfig(_config, defaultConfig);
                _pageBaseEvent.updateModal({ enabled: true, config: updatedConfig });
            }
        }
        /**
         * [notify a modal dialog with 1 button: 'Done']
         */
        function notify(_config) {
            if (_pageBaseEvent) {
                var updatedConfig = {};
                var defaultConfig = {
                    suspendClose: true,
                    title: 'Alert',
                    body: 'Dummy text - notify',
                    button: [{
                            text: 'Done',
                            class: 'btn-text',
                            callback: function () { _pageBaseEvent.updateModal({ close: true }); }
                        }]
                };
                updatedConfig = applyConfig(_config, defaultConfig);
                _pageBaseEvent.updateModal({ enabled: true, config: updatedConfig });
            }
        }
        function disabled() {
            if (_pageBaseEvent)
                _pageBaseEvent.updateModal({ enabled: false });
        }
        function close() {
            if (_pageBaseEvent)
                _pageBaseEvent.updateModal({ close: true });
        }
        function applyConfig(_sourceConfig, _targetConfig) {
            var updatedConfig = {};
            Object.assign(updatedConfig, _targetConfig);
            if (_sourceConfig.header)
                updatedConfig.title = _sourceConfig.header;
            if (_sourceConfig.message)
                updatedConfig.body = _sourceConfig.message;
            if (_sourceConfig.buttonConfirm) {
                if (_sourceConfig.buttonConfirm.text)
                    updatedConfig.button[0].text = _sourceConfig.buttonConfirm.text;
                if (_sourceConfig.buttonConfirm.callback)
                    updatedConfig.button[0].callback = _sourceConfig.buttonConfirm.callback;
            }
            return updatedConfig;
        }
        return {
            confirmation: confirmation,
            notify: notify,
            disabled: disabled,
            close: close
        };
    };
    /**
     * Utils Methods
     */
    // private initPrevHistory(){
    //     // this._routerHistorySub = this.options.router.events
    //     return this.options.router.events
    //         .filter(e => e instanceof RoutesRecognized)
    //         // .filter(e => (e.constructor.name === 'RoutesRecognized') || ( e.constructor.name === 'NavigationEnd'))
    //         .pairwise()
    //         .subscribe((e: any[]): void => {
    //             console.log('1 on init > url info ', e);
    //             console.log(new Date());
    //             console.log(e[0]);
    //             console.log(e[e.length - 1]);
    //             return e[0];
    //             // console.log('this._prevPageInfo = > ', this._prevPageInfo);
    //             // this._routerHistorySub.unsubscribe();
    //         });
    // }
    KdPageBase.prototype.getCurrentURL = function () {
        return this._currentURL;
    };
    KdPageBase.prototype.setTextOmit = function (_text) {
        this._textOmitted = _text;
    };
    KdPageBase.prototype.getParams = function () {
        return this._pageParams;
    };
    KdPageBase.prototype.getPrevPageInfo = function () {
        console.log('getPrevPageInfo . >> ', this._prevPageURL);
        return this._prevPageURL;
    };
    KdPageBase.prototype.underscore = function (_camelCase) {
        return this.convertionSvc.underscore(_camelCase);
    };
    KdPageBase.prototype.humanize = function (_underscored) {
        return this.convertionSvc.humanize(_underscored);
    };
    KdPageBase.prototype.camelCase = function (_text) {
        return this.convertionSvc.camelCase(_text, ' ');
    };
    KdPageBase.prototype.slug = function (_word) {
        return this.convertionSvc.slug(_word);
    };
    return KdPageBase;
}());
export { KdPageBase };
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoia2QtcGFnZS1iYXNlLmpzIiwic291cmNlUm9vdCI6Im5nOi8vb3BlbmVtaXMtc3R5bGVndWlkZS1saWIvIiwic291cmNlcyI6WyJrZC1jb21wb25lbnRzL2tkLWNvbW1vbi9rZC1wYWdlLWJhc2Uva2QtcGFnZS1iYXNlLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUNBLE9BQU8sRUFBVSxhQUFhLEVBQTBCLE1BQU0saUJBQWlCLENBQUM7QUFFaEYsT0FBTyxFQUFFLGVBQWUsRUFBRSxTQUFTLEVBQUUsTUFBTSxVQUFVLENBQUM7QUFjdEQ7SUFzQ0ksb0JBQ1csT0FBeUI7UUFEcEMsaUJBK0NDO1FBOUNVLFlBQU8sR0FBUCxPQUFPLENBQWtCO1FBdEM1QixpQkFBWSxHQUFXLEVBQUUsQ0FBQztRQUMxQixZQUFPLEdBQVE7WUFDbkIsU0FBUyxFQUFFLEVBQUU7WUFDYixRQUFRLEVBQUU7Z0JBQ04sSUFBSSxFQUFFLEVBQUU7Z0JBQ1IsT0FBTyxFQUFFLE1BQU07Z0JBQ2YsTUFBTSxFQUFFLEVBQUU7Z0JBQ1YsSUFBSSxFQUFFLEVBQUU7YUFDWDtZQUNELFFBQVEsRUFBRSxFQUFFO1NBQ2YsQ0FBQztRQUVNLGdCQUFXLEdBQXNCO1lBQ3JDLGNBQWMsRUFBRSxFQUFFO1lBQ2xCLE9BQU8sRUFBRSxFQUFFO1lBQ1gsY0FBYztZQUNkLGtCQUFrQjtZQUNsQixNQUFNO1lBQ04sT0FBTyxFQUFFLEtBQUs7WUFDZCxVQUFVLEVBQUUsRUFBRTtZQUNkLFNBQVMsRUFBRSxLQUFLO1lBQ2hCLFdBQVcsRUFBRSxDQUFDLFFBQVEsRUFBRSxPQUFPLENBQUM7U0FDbkMsQ0FBQztRQUVNLG9CQUFlLEdBQVE7WUFDM0IsSUFBSSxFQUFFLEVBQUUsSUFBSSxFQUFFLFlBQVksRUFBRSxHQUFHLEVBQUUsRUFBRSxFQUFFLElBQUksRUFBRSw4QkFBOEIsRUFBRTtZQUMzRSxJQUFJLEVBQUUsRUFBRTtTQUNYLENBQUM7UUFDTSxnQkFBVyxHQUFRLEVBQUUsQ0FBQztRQUN0QixpQkFBWSxHQUFXLEVBQUUsQ0FBQztRQU8xQixnQkFBVyxHQUFXLEVBQUUsQ0FBQztRQUk3QixJQUFJLENBQUMsYUFBYSxHQUFHLElBQUksZUFBZSxFQUFFLENBQUM7UUFDM0MsSUFBSSxDQUFDLE9BQU8sR0FBRyxJQUFJLFNBQVMsRUFBRSxDQUFDO1FBRS9CLCtDQUErQztRQUMvQyw2QkFBNkI7UUFDN0Isa0RBQWtEO1FBQ2xELGdIQUFnSDtRQUNoSCxrQkFBa0I7UUFDbEIsdUNBQXVDO1FBQ3ZDLG1EQUFtRDtRQUNuRCxtQ0FBbUM7UUFDbkMsNkJBQTZCO1FBQzdCLHdDQUF3QztRQUN4Qyx1REFBdUQ7UUFDdkQseUVBQXlFO1FBQ3pFLG1EQUFtRDtRQUNuRCxVQUFVO1FBRVYscURBQXFEO1FBQ3JELElBQUksQ0FBQyxVQUFVLEdBQUcsSUFBSSxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsTUFBTTthQUN2QyxTQUFTLENBQUMsVUFBQSxLQUFLO1lBQ1osMkNBQTJDO1lBQzNDLHdFQUF3RTtZQUN4RSxJQUFJO1lBQ0osSUFBSSxLQUFLLFlBQVksYUFBYSxFQUFFO2dCQUNoQyw0QkFBNEI7Z0JBQzVCLEtBQUksQ0FBQyxZQUFZLEdBQUcsSUFBSSxDQUFDLFNBQVMsQ0FBQyxLQUFJLENBQUMsV0FBVyxDQUFDLENBQUM7Z0JBQ3JELEtBQUksQ0FBQyxXQUFXLEdBQUcsS0FBSyxDQUFDLGlCQUFpQixDQUFDO2dCQUMzQyxLQUFJLENBQUMsZUFBZSxDQUFDLElBQUksR0FBRyxLQUFJLENBQUMsYUFBYSxDQUFDLFVBQVUsQ0FBQyxLQUFLLENBQUMsaUJBQWlCLEVBQUUsS0FBSSxDQUFDLFlBQVksQ0FBQyxDQUFDO2dCQUN0RyxzRUFBc0U7Z0JBQ3RFLElBQUksT0FBTyxLQUFJLENBQUMsT0FBTyxDQUFDLFNBQVMsS0FBSyxXQUFXLEVBQUU7b0JBQy9DLEtBQUksQ0FBQyxPQUFPLENBQUMsU0FBUyxDQUFDLFFBQVEsRUFBRSxDQUFDO29CQUNsQyxLQUFJLENBQUMsT0FBTyxDQUFDLFNBQVMsQ0FBQyxrQkFBa0IsRUFBRSxDQUFDO2lCQUMvQztnQkFFRCxJQUFJLE9BQU8sS0FBSSxDQUFDLE9BQU8sQ0FBQyxhQUFhLEtBQUssV0FBVyxFQUFFO29CQUNuRCxPQUFPLENBQUMsS0FBSyxDQUFDLHFEQUFxRCxDQUFDLENBQUM7aUJBQ3hFO2FBQ0o7UUFDTCxDQUFDLENBQUMsQ0FBQztRQUVQLElBQUksQ0FBQyxrQkFBa0IsR0FBRyxJQUFJLENBQUMsT0FBTyxDQUFDLGNBQWMsQ0FBQyxNQUFNLENBQUMsU0FBUyxDQUFDLFVBQUMsT0FBZTtZQUNuRixLQUFJLENBQUMsV0FBVyxHQUFHLE9BQU8sQ0FBQztRQUMvQixDQUFDLENBQUMsQ0FBQztJQUNQLENBQUM7SUFDRCwyQ0FBMkM7SUFDM0MsK0NBQStDO0lBQy9DLElBQUk7SUFFSjs7T0FFRztJQUNPLHVDQUFrQixHQUE1QjtRQUNJLElBQUksT0FBTyxJQUFJLENBQUMsVUFBVSxLQUFLLFdBQVc7WUFBRSxJQUFJLENBQUMsVUFBVSxDQUFDLFdBQVcsRUFBRSxDQUFDO1FBQzFFLElBQUksT0FBTyxJQUFJLENBQUMsa0JBQWtCLEtBQUssV0FBVztZQUFFLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxXQUFXLEVBQUUsQ0FBQztJQUM5RixDQUFDO0lBRUQ7O09BRUc7SUFFTyxvQ0FBZSxHQUF6QjtRQUNJLE9BQU8sSUFBSSxDQUFDLE9BQU8sQ0FBQyxRQUFRLENBQUM7SUFDakMsQ0FBQztJQUVTLG9DQUFlLEdBQXpCLFVBQTBCLEtBQVU7UUFDaEMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxRQUFRLEdBQUcsS0FBSyxDQUFDO0lBQ2xDLENBQUM7SUFFUyxpQ0FBWSxHQUF0QjtRQUNJLElBQUksQ0FBQyxPQUFPLENBQUMsU0FBUyxDQUFDLFlBQVksQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLENBQUM7SUFDdEQsQ0FBQztJQUVEOztPQUVHO0lBRU8sb0NBQWUsR0FBekIsVUFBMEIsWUFBaUI7UUFDdkMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxTQUFTLENBQUMsY0FBYyxDQUFDLFlBQVksQ0FBQyxDQUFDO0lBQ3hELENBQUM7SUFFRDs7T0FFRztJQUVPLGlDQUFZLEdBQXRCO1FBQ0ksT0FBTyxJQUFJLENBQUMsV0FBVyxDQUFDLGNBQWMsQ0FBQztJQUMzQyxDQUFDO0lBRVMsaUNBQVksR0FBdEIsVUFBdUIsTUFBYyxFQUFFLFNBQXlCO1FBQXpCLDBCQUFBLEVBQUEsZ0JBQXlCO1FBQzVELElBQUksT0FBTyxHQUFXLE1BQU0sQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLFlBQVksRUFBRSxFQUFFLENBQUMsQ0FBQztRQUM1RCxJQUFJLFNBQVMsRUFBRTtZQUNYLE9BQU8sR0FBRyxJQUFJLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQztTQUNyRDtRQUNELHdDQUF3QztRQUN4QyxJQUFJLENBQUMsV0FBVyxDQUFDLGNBQWMsR0FBRyxPQUFPLENBQUM7SUFDOUMsQ0FBQztJQUVTLHVDQUFrQixHQUE1QjtRQUNJLE9BQU8sSUFBSSxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQyxXQUFXLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQztJQUNoRSxDQUFDO0lBRVMsdUNBQWtCLEdBQTVCLFVBQTZCLFFBQW9CO1FBQzdDLElBQUksQ0FBQyxXQUFXLENBQUMsT0FBTyxHQUFHLFFBQVEsQ0FBQztJQUN4QyxDQUFDO0lBRVMsNkNBQXdCLEdBQWxDO1FBQ0ksT0FBTyxJQUFJLENBQUMsV0FBVyxDQUFDLFVBQVUsQ0FBQztJQUN2QyxDQUFDO0lBRVMseUNBQW9CLEdBQTlCLFVBQStCLE9BQWdCLEVBQUUsUUFBcUI7UUFDbEUsSUFBSSxDQUFDLFdBQVcsQ0FBQyxPQUFPLEdBQUcsT0FBTyxDQUFDO1FBQ25DLElBQUksUUFBUSxFQUFFO1lBQ1YsSUFBSSxDQUFDLFdBQVcsQ0FBQyxVQUFVLEdBQUcsUUFBUSxDQUFDO1NBQzFDO0lBQ0wsQ0FBQztJQUVTLHdDQUFtQixHQUE3QixVQUE4QixPQUFnQixFQUFFLFNBQW1DO1FBQy9FLElBQUksQ0FBQyxXQUFXLENBQUMsU0FBUyxHQUFHLE9BQU8sQ0FBQztRQUNyQyxJQUFJLE9BQU8sSUFBSSxTQUFTLEVBQUU7WUFDdEIsSUFBSSxDQUFDLFdBQVcsQ0FBQyxjQUFjLEdBQUcsU0FBUyxDQUFDO1NBQy9DO0lBQ0wsQ0FBQztJQUVTLHFDQUFnQixHQUExQixVQUEyQixXQUFtQjtRQUMxQyxJQUFJLENBQUMsV0FBVyxDQUFDLFVBQVUsR0FBRyxXQUFXLENBQUM7SUFDOUMsQ0FBQztJQUVTLHFDQUFnQixHQUExQjtRQUNJLE9BQU8sQ0FBQyxHQUFHLENBQUMsNEJBQTRCLEVBQUUsSUFBSSxDQUFDLFdBQVcsQ0FBQyxDQUFDO1FBQzVELElBQUksQ0FBQyxPQUFPLENBQUMsU0FBUyxDQUFDLGdCQUFnQixDQUFDLElBQUksQ0FBQyxXQUFXLENBQUMsQ0FBQztJQUM5RCxDQUFDO0lBRUQ7O09BRUc7SUFFTyx1Q0FBa0IsR0FBNUIsVUFBNkIsS0FBaUI7UUFDMUMsSUFBSSxDQUFDLGVBQWUsQ0FBQyxJQUFJLEdBQUcsS0FBSyxDQUFDO1FBQ2xDLElBQUksQ0FBQyxnQkFBZ0IsRUFBRSxDQUFDO0lBQzVCLENBQUM7SUFFUyx1Q0FBa0IsR0FBNUI7UUFDSSxPQUFPLElBQUksQ0FBQyxlQUFlLENBQUMsSUFBSSxDQUFDO0lBQ3JDLENBQUM7SUFFUyxxQ0FBZ0IsR0FBMUI7UUFDSSxJQUFJLENBQUMsT0FBTyxDQUFDLFNBQVMsQ0FBQyxnQkFBZ0IsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDLGVBQWUsQ0FBQyxDQUFDLENBQUMsQ0FBQztJQUM5RixDQUFDO0lBRUQ7O09BRUc7SUFFTyw2QkFBUSxHQUFsQixVQUFtQixPQUFZLEVBQUUsS0FBYTtRQUMxQyxJQUFJLElBQUksQ0FBQyxPQUFPLENBQUMsVUFBVSxFQUFFO1lBQ3pCLElBQUksQ0FBQyxPQUFPLENBQUMsVUFBVSxDQUFDLEtBQUssQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDO1NBQzNDO2FBQ0k7WUFDRCxPQUFPLENBQUMsSUFBSSxDQUFDLDhCQUE4QixDQUFDLENBQUM7U0FDaEQ7SUFDTCxDQUFDO0lBRUQ7Ozs7Ozs7Ozs7OztPQVlHO0lBQ08sNkJBQVEsR0FBbEI7UUFDSSxJQUFJLGNBQStCLENBQUM7UUFDcEMsSUFBSSxJQUFJLENBQUMsT0FBTyxDQUFDLFNBQVMsRUFBRTtZQUN4QixjQUFjLEdBQUcsSUFBSSxDQUFDLE9BQU8sQ0FBQyxTQUFTLENBQUM7U0FDM0M7YUFDSTtZQUNELE9BQU8sQ0FBQyxJQUFJLENBQUMsOENBQThDLENBQUMsQ0FBQztTQUNoRTtRQUVEOztXQUVHO1FBQ0gsU0FBUyxZQUFZLENBQUMsT0FBYTtZQUMvQixJQUFJLGNBQWMsRUFBRTtnQkFDaEIsSUFBSSxhQUFhLEdBQVEsRUFBRSxDQUFDO2dCQUM1QixJQUFJLGFBQWEsR0FBUTtvQkFDckIsWUFBWSxFQUFFLElBQUk7b0JBQ2xCLEtBQUssRUFBRSxPQUFPO29CQUNkLElBQUksRUFBRSwyQkFBMkI7b0JBQ2pDLE1BQU0sRUFBRSxDQUFDOzRCQUNMLElBQUksRUFBRSxTQUFTOzRCQUNmLEtBQUssRUFBRSxVQUFVOzRCQUNqQixRQUFRLEVBQUUsY0FBYyxDQUFDO3lCQUM1Qjt3QkFDRDs0QkFDSSxJQUFJLEVBQUUsUUFBUTs0QkFDZCxLQUFLLEVBQUUsYUFBYTs0QkFDcEIsUUFBUSxFQUFFLGNBQWMsY0FBYyxDQUFDLFdBQVcsQ0FBQyxFQUFFLEtBQUssRUFBRSxJQUFJLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQzt5QkFDekUsQ0FBQztpQkFDTCxDQUFDO2dCQUVGLGFBQWEsR0FBRyxXQUFXLENBQUMsT0FBTyxFQUFFLGFBQWEsQ0FBQyxDQUFDO2dCQUNwRCxjQUFjLENBQUMsV0FBVyxDQUFDLEVBQUUsT0FBTyxFQUFFLElBQUksRUFBRSxNQUFNLEVBQUUsYUFBYSxFQUFFLENBQUMsQ0FBQzthQUN4RTtRQUNMLENBQUM7UUFFRDs7V0FFRztRQUNILFNBQVMsTUFBTSxDQUFDLE9BQWE7WUFDekIsSUFBSSxjQUFjLEVBQUU7Z0JBQ2hCLElBQUksYUFBYSxHQUFRLEVBQUUsQ0FBQztnQkFDNUIsSUFBSSxhQUFhLEdBQVE7b0JBQ3JCLFlBQVksRUFBRSxJQUFJO29CQUNsQixLQUFLLEVBQUUsT0FBTztvQkFDZCxJQUFJLEVBQUUscUJBQXFCO29CQUMzQixNQUFNLEVBQUUsQ0FBQzs0QkFDTCxJQUFJLEVBQUUsTUFBTTs0QkFDWixLQUFLLEVBQUUsVUFBVTs0QkFDakIsUUFBUSxFQUFFLGNBQWMsY0FBYyxDQUFDLFdBQVcsQ0FBQyxFQUFFLEtBQUssRUFBRSxJQUFJLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQzt5QkFDekUsQ0FBQztpQkFDTCxDQUFDO2dCQUVGLGFBQWEsR0FBRyxXQUFXLENBQUMsT0FBTyxFQUFFLGFBQWEsQ0FBQyxDQUFDO2dCQUNwRCxjQUFjLENBQUMsV0FBVyxDQUFDLEVBQUUsT0FBTyxFQUFFLElBQUksRUFBRSxNQUFNLEVBQUUsYUFBYSxFQUFFLENBQUMsQ0FBQzthQUN4RTtRQUNMLENBQUM7UUFFRCxTQUFTLFFBQVE7WUFDYixJQUFJLGNBQWM7Z0JBQUUsY0FBYyxDQUFDLFdBQVcsQ0FBQyxFQUFFLE9BQU8sRUFBRSxLQUFLLEVBQUUsQ0FBQyxDQUFDO1FBQ3ZFLENBQUM7UUFFRCxTQUFTLEtBQUs7WUFDVixJQUFJLGNBQWM7Z0JBQUUsY0FBYyxDQUFDLFdBQVcsQ0FBQyxFQUFFLEtBQUssRUFBRSxJQUFJLEVBQUUsQ0FBQyxDQUFDO1FBQ3BFLENBQUM7UUFFRCxTQUFTLFdBQVcsQ0FBQyxhQUFrQixFQUFFLGFBQWtCO1lBQ3ZELElBQUksYUFBYSxHQUFRLEVBQUUsQ0FBQztZQUN0QixNQUFPLENBQUMsTUFBTSxDQUFDLGFBQWEsRUFBRSxhQUFhLENBQUMsQ0FBQztZQUVuRCxJQUFJLGFBQWEsQ0FBQyxNQUFNO2dCQUFFLGFBQWEsQ0FBQyxLQUFLLEdBQUcsYUFBYSxDQUFDLE1BQU0sQ0FBQztZQUNyRSxJQUFJLGFBQWEsQ0FBQyxPQUFPO2dCQUFFLGFBQWEsQ0FBQyxJQUFJLEdBQUcsYUFBYSxDQUFDLE9BQU8sQ0FBQztZQUN0RSxJQUFJLGFBQWEsQ0FBQyxhQUFhLEVBQUU7Z0JBQzdCLElBQUksYUFBYSxDQUFDLGFBQWEsQ0FBQyxJQUFJO29CQUFFLGFBQWEsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxHQUFHLGFBQWEsQ0FBQyxhQUFhLENBQUMsSUFBSSxDQUFDO2dCQUN0RyxJQUFJLGFBQWEsQ0FBQyxhQUFhLENBQUMsUUFBUTtvQkFBRSxhQUFhLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsR0FBRyxhQUFhLENBQUMsYUFBYSxDQUFDLFFBQVEsQ0FBQzthQUNySDtZQUVELE9BQU8sYUFBYSxDQUFDO1FBQ3pCLENBQUM7UUFFRCxPQUFPO1lBQ0gsWUFBWSxFQUFFLFlBQVk7WUFDMUIsTUFBTSxFQUFFLE1BQU07WUFDZCxRQUFRLEVBQUUsUUFBUTtZQUNsQixLQUFLLEVBQUUsS0FBSztTQUNmLENBQUM7SUFDTixDQUFDO0lBSUQ7O09BRUc7SUFFSCw2QkFBNkI7SUFDN0IsNkRBQTZEO0lBQzdELHdDQUF3QztJQUN4QyxzREFBc0Q7SUFDdEQsb0hBQW9IO0lBQ3BILHNCQUFzQjtJQUN0QiwyQ0FBMkM7SUFDM0MsdURBQXVEO0lBQ3ZELHVDQUF1QztJQUN2QyxpQ0FBaUM7SUFDakMsNENBQTRDO0lBQzVDLDJCQUEyQjtJQUMzQiw2RUFBNkU7SUFDN0UsdURBQXVEO0lBQ3ZELGNBQWM7SUFDZCxJQUFJO0lBRU0sa0NBQWEsR0FBdkI7UUFDSSxPQUFPLElBQUksQ0FBQyxXQUFXLENBQUM7SUFDNUIsQ0FBQztJQUVTLGdDQUFXLEdBQXJCLFVBQXNCLEtBQWE7UUFDL0IsSUFBSSxDQUFDLFlBQVksR0FBRyxLQUFLLENBQUM7SUFDOUIsQ0FBQztJQUVTLDhCQUFTLEdBQW5CO1FBQ0ksT0FBTyxJQUFJLENBQUMsV0FBVyxDQUFDO0lBQzVCLENBQUM7SUFFUyxvQ0FBZSxHQUF6QjtRQUNJLE9BQU8sQ0FBQyxHQUFHLENBQUMsdUJBQXVCLEVBQUUsSUFBSSxDQUFDLFlBQVksQ0FBQyxDQUFDO1FBQ3hELE9BQU8sSUFBSSxDQUFDLFlBQVksQ0FBQztJQUM3QixDQUFDO0lBRVMsK0JBQVUsR0FBcEIsVUFBcUIsVUFBa0I7UUFDbkMsT0FBTyxJQUFJLENBQUMsYUFBYSxDQUFDLFVBQVUsQ0FBQyxVQUFVLENBQUMsQ0FBQztJQUNyRCxDQUFDO0lBRVMsNkJBQVEsR0FBbEIsVUFBbUIsWUFBb0I7UUFDbkMsT0FBTyxJQUFJLENBQUMsYUFBYSxDQUFDLFFBQVEsQ0FBQyxZQUFZLENBQUMsQ0FBQztJQUNyRCxDQUFDO0lBRVMsOEJBQVMsR0FBbkIsVUFBb0IsS0FBYTtRQUM3QixPQUFPLElBQUksQ0FBQyxhQUFhLENBQUMsU0FBUyxDQUFDLEtBQUssRUFBRSxHQUFHLENBQUMsQ0FBQztJQUNwRCxDQUFDO0lBR1MseUJBQUksR0FBZCxVQUFlLEtBQWE7UUFDeEIsT0FBTyxJQUFJLENBQUMsYUFBYSxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQztJQUMxQyxDQUFDO0lBQ0wsaUJBQUM7QUFBRCxDQUFDLEFBeldELElBeVdDIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgU3Vic2NyaXB0aW9uIH0gZnJvbSAncnhqcyc7XHJcbmltcG9ydCB7IFJvdXRlciwgTmF2aWdhdGlvbkVuZCwgQWN0aXZhdGVkUm91dGUsIFBhcmFtcyB9IGZyb20gJ0Bhbmd1bGFyL3JvdXRlcic7XHJcbmltcG9ydCB7IEtkQWxlcnRFdmVudCB9IGZyb20gJy4uLy4uL2tkLWFuZ3VsYXItYWxlcnQvaW5kZXgnO1xyXG5pbXBvcnQgeyBLZENvbnZlcnRpb25TdmMsIEtkRGF0YVN2YyB9IGZyb20gJy4uL2luZGV4JztcclxuaW1wb3J0IHsgSVBhZ2VoZWFkZXJDb25maWcgfSBmcm9tICcuLi8uLi9pbmRleCc7XHJcblxyXG5pbXBvcnQgeyBLZFBhZ2VCYXNlRXZlbnQgfSBmcm9tICcuL2tkLXBhZ2UtYmFzZS5ldmVudCc7XHJcblxyXG5leHBvcnQgaW50ZXJmYWNlIElQYWdlQmFzZU9wdGlvbnMge1xyXG4gICAgcm91dGVyOiBSb3V0ZXI7XHJcbiAgICBhY3RpdmF0ZWRSb3V0ZTogQWN0aXZhdGVkUm91dGU7XHJcbiAgICBwYWdlRXZlbnQ/OiBLZFBhZ2VCYXNlRXZlbnQgfCBhbnk7XHJcbiAgICBwYWdlQmFzZUV2ZW50PzogS2RQYWdlQmFzZUV2ZW50O1xyXG4gICAgYWxlcnRFdmVudD86IEtkQWxlcnRFdmVudDtcclxuICAgIC8vIG1vZGFsRXZlbnQ/OiBLZE1vZGFsRXZlbnQ7XHJcbn1cclxuXHJcbmV4cG9ydCBjbGFzcyBLZFBhZ2VCYXNlIHtcclxuICAgIHByaXZhdGUgX3RleHRPbWl0dGVkOiBzdHJpbmcgPSAnJztcclxuICAgIHByaXZhdGUgX2hlYWRlcjogYW55ID0ge1xyXG4gICAgICAgIGJyYW5kTG9nbzoge30sXHJcbiAgICAgICAgdXNlckluZm86IHtcclxuICAgICAgICAgICAgbmFtZTogJycsXHJcbiAgICAgICAgICAgIGltZ1R5cGU6ICdpY29uJyxcclxuICAgICAgICAgICAgaW1nU3JjOiAnJyxcclxuICAgICAgICAgICAgcGF0aDogJydcclxuICAgICAgICB9LFxyXG4gICAgICAgIGJ0bkdyb3VwOiBbXVxyXG4gICAgfTtcclxuXHJcbiAgICBwcml2YXRlIF9wYWdlaGVhZGVyOiBJUGFnZWhlYWRlckNvbmZpZyA9IHtcclxuICAgICAgICBwYWdlaGVhZGVyVGV4dDogJycsXHJcbiAgICAgICAgbGVmdEJ0bjogW10sXHJcbiAgICAgICAgLy8gbGVmdEJ0bjogW3tcclxuICAgICAgICAvLyAgICAgdHlwZTogJ2FkZCdcclxuICAgICAgICAvLyB9XSxcclxuICAgICAgICBtb3JlQnRuOiBmYWxzZSxcclxuICAgICAgICBtb3JlQWN0aW9uOiBbXSxcclxuICAgICAgICBzZWFyY2hCdG46IGZhbHNlLFxyXG4gICAgICAgIHNlYXJjaEV2ZW50OiBbJ2NoYW5nZScsICdrZXl1cCddXHJcbiAgICB9O1xyXG5cclxuICAgIHByaXZhdGUgX2JyZWFkY3J1bWJMaXN0OiBhbnkgPSB7XHJcbiAgICAgICAgaG9tZTogeyBpY29uOiAnZmEgZmEtaG9tZScsIHVybDogJycsIHBhdGg6ICcvQXBwL0luc3RpdHV0aW9uQ2xhc3Nlcy9saXN0JyB9LFxyXG4gICAgICAgIGxpc3Q6IFtdXHJcbiAgICB9O1xyXG4gICAgcHJpdmF0ZSBfcGFnZVBhcmFtczogYW55ID0ge307XHJcbiAgICBwcml2YXRlIF9wcmV2UGFnZVVSTDogc3RyaW5nID0gJyc7XHJcbiAgICBwdWJsaWMgY29udmVydGlvblN2YzogS2RDb252ZXJ0aW9uU3ZjO1xyXG4gICAgcHVibGljIGRhdGFTdmM6IEtkRGF0YVN2YztcclxuICAgIC8vIHByaXZhdGUgX2FsZXJ0RXZlbnQ6IEtkQWxlcnRFdmVudDtcclxuXHJcbiAgICBwcml2YXRlIF9yb3V0ZXJTdWI6IFN1YnNjcmlwdGlvbjtcclxuICAgIHByaXZhdGUgX2FjdGl2YXRlZFJvdXRlU3ViOiBTdWJzY3JpcHRpb247XHJcbiAgICBwcml2YXRlIF9jdXJyZW50VVJMOiBzdHJpbmcgPSAnJztcclxuICAgIGNvbnN0cnVjdG9yKFxyXG4gICAgICAgIHB1YmxpYyBvcHRpb25zOiBJUGFnZUJhc2VPcHRpb25zXHJcbiAgICApIHtcclxuICAgICAgICB0aGlzLmNvbnZlcnRpb25TdmMgPSBuZXcgS2RDb252ZXJ0aW9uU3ZjKCk7XHJcbiAgICAgICAgdGhpcy5kYXRhU3ZjID0gbmV3IEtkRGF0YVN2YygpO1xyXG5cclxuICAgICAgICAvLyB0aGlzLl9wcmV2UGFnZUluZm8gPSB0aGlzLmluaXRQcmV2SGlzdG9yeSgpO1xyXG4gICAgICAgIC8vIHRoaXMub3B0aW9ucy5yb3V0ZXIuZXZlbnRzXHJcbiAgICAgICAgLy8gICAgIC5maWx0ZXIoZSA9PiBlIGluc3RhbmNlb2YgUm91dGVzUmVjb2duaXplZClcclxuICAgICAgICAvLyAgICAgLy8gLmZpbHRlcihlID0+IChlLmNvbnN0cnVjdG9yLm5hbWUgPT09ICdSb3V0ZXNSZWNvZ25pemVkJykgfHwgKCBlLmNvbnN0cnVjdG9yLm5hbWUgPT09ICdOYXZpZ2F0aW9uRW5kJykpXHJcbiAgICAgICAgLy8gICAgIC5wYWlyd2lzZSgpXHJcbiAgICAgICAgLy8gICAgIC5zdWJzY3JpYmUoKGU6IGFueVtdKTogdm9pZCA9PiB7XHJcbiAgICAgICAgLy8gICAgICAgICBjb25zb2xlLmxvZygnMSBvbiBpbml0ID4gdXJsIGluZm8gJywgZSk7XHJcbiAgICAgICAgLy8gICAgICAgICBjb25zb2xlLmxvZyhuZXcgRGF0ZSgpKTtcclxuICAgICAgICAvLyAgICAgICAgIGNvbnNvbGUubG9nKGVbMF0pO1xyXG4gICAgICAgIC8vICAgICAgICAgY29uc29sZS5sb2coZVtlLmxlbmd0aCAtIDFdKTtcclxuICAgICAgICAvLyAgICAgICAgIHRoaXMuX3ByZXZQYWdlSW5mbyA9IGVbMF0udXJsQWZ0ZXJSZWRpcmVjdHM7XHJcbiAgICAgICAgLy8gICAgICAgICAvLyBjb25zb2xlLmxvZygndGhpcy5fcHJldlBhZ2VJbmZvID0gPiAnLCB0aGlzLl9wcmV2UGFnZUluZm8pO1xyXG4gICAgICAgIC8vICAgICAgICAgLy8gdGhpcy5fcm91dGVySGlzdG9yeVN1Yi51bnN1YnNjcmliZSgpO1xyXG4gICAgICAgIC8vICAgICB9KTtcclxuXHJcbiAgICAgICAgLy8gY29uc29sZS5sb2coJ2NvbnN0cnVjdG9yID4+ICcsdGhpcy5fcHJldlBhZ2VJbmZvKTtcclxuICAgICAgICB0aGlzLl9yb3V0ZXJTdWIgPSB0aGlzLm9wdGlvbnMucm91dGVyLmV2ZW50c1xyXG4gICAgICAgICAgICAuc3Vic2NyaWJlKGV2ZW50ID0+IHtcclxuICAgICAgICAgICAgICAgIC8vIGlmIChldmVudCBpbnN0YW5jZW9mIFJvdXRlc1JlY29nbml6ZWQpIHtcclxuICAgICAgICAgICAgICAgIC8vIGNvbnNvbGUubG9nKCdSb3V0ZXNSZWNvZ25pemVkID4gZXZlbnQgLSAnLCBPYmplY3QuYXNzaWduKHt9LCBldmVudCkpO1xyXG4gICAgICAgICAgICAgICAgLy8gfVxyXG4gICAgICAgICAgICAgICAgaWYgKGV2ZW50IGluc3RhbmNlb2YgTmF2aWdhdGlvbkVuZCkge1xyXG4gICAgICAgICAgICAgICAgICAgIC8vIGNvbnNvbGUubG9nKCc+PicsIGV2ZW50KTtcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLl9wcmV2UGFnZVVSTCA9IEpTT04uc3RyaW5naWZ5KHRoaXMuX2N1cnJlbnRVUkwpO1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuX2N1cnJlbnRVUkwgPSBldmVudC51cmxBZnRlclJlZGlyZWN0cztcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLl9icmVhZGNydW1iTGlzdC5saXN0ID0gdGhpcy5jb252ZXJ0aW9uU3ZjLnVybFRvQXJyYXkoZXZlbnQudXJsQWZ0ZXJSZWRpcmVjdHMsIHRoaXMuX3RleHRPbWl0dGVkKTtcclxuICAgICAgICAgICAgICAgICAgICAvLyBjb25zb2xlLmxvZygndGhpcy5fYnJlYWRjcnVtYkxpc3QubGlzdCcsdGhpcy5fYnJlYWRjcnVtYkxpc3QubGlzdCk7XHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKHR5cGVvZiB0aGlzLm9wdGlvbnMucGFnZUV2ZW50ICE9PSAndW5kZWZpbmVkJykge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLm9wdGlvbnMucGFnZUV2ZW50LmFwcFJlYWR5KCk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMub3B0aW9ucy5wYWdlRXZlbnQub25BcHBSZWFkeUNvbXBsZXRlKCk7XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgICAgICAgICBpZiAodHlwZW9mIHRoaXMub3B0aW9ucy5wYWdlQmFzZUV2ZW50ICE9PSAndW5kZWZpbmVkJykge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBjb25zb2xlLmVycm9yKCdwbGVhc2UgY2hhbmdlIHRvIFBhZ2VFdmVudCBpbnN0ZWFkIG9mIFBhZ2VCYXNlRXZlbnQnKTtcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH0pO1xyXG5cclxuICAgICAgICB0aGlzLl9hY3RpdmF0ZWRSb3V0ZVN1YiA9IHRoaXMub3B0aW9ucy5hY3RpdmF0ZWRSb3V0ZS5wYXJhbXMuc3Vic2NyaWJlKChfcGFyYW1zOiBQYXJhbXMpOiB2b2lkID0+IHtcclxuICAgICAgICAgICAgdGhpcy5fcGFnZVBhcmFtcyA9IF9wYXJhbXM7XHJcbiAgICAgICAgfSk7XHJcbiAgICB9XHJcbiAgICAvLyBwcm90ZWN0ZWQgZW5hYmxlTG9hZFYyKF9ib29sOiBib29sZWFuKSB7XHJcbiAgICAvLyAgICAgLy8gdGhpcy5vcHRpb25zLnBhZ2VFdmVudC5sb2FkVjIoX2Jvb2wpO1xyXG4gICAgLy8gfVxyXG5cclxuICAgIC8qKlxyXG4gICAgICogW2Rlc3Ryb3lQYWdlQmFzZVN1YiAtIE1hbnVhbGx5IGRpc2NhcmQgdGhlIGFsbCB0aGUgc3Vic2NyaXB0aW9uc11cclxuICAgICAqL1xyXG4gICAgcHJvdGVjdGVkIGRlc3Ryb3lQYWdlQmFzZVN1YigpOiB2b2lkIHtcclxuICAgICAgICBpZiAodHlwZW9mIHRoaXMuX3JvdXRlclN1YiAhPT0gJ3VuZGVmaW5lZCcpIHRoaXMuX3JvdXRlclN1Yi51bnN1YnNjcmliZSgpO1xyXG4gICAgICAgIGlmICh0eXBlb2YgdGhpcy5fYWN0aXZhdGVkUm91dGVTdWIgIT09ICd1bmRlZmluZWQnKSB0aGlzLl9hY3RpdmF0ZWRSb3V0ZVN1Yi51bnN1YnNjcmliZSgpO1xyXG4gICAgfVxyXG5cclxuICAgIC8qKlxyXG4gICAgICogQXBwbGljYXRpb24gSGVhZGVyIChQcm9kdWN0IEhlYWRlcilcclxuICAgICAqL1xyXG5cclxuICAgIHByb3RlY3RlZCBnZXRIZWFkZXJDb25maWcoKTogYW55IHtcclxuICAgICAgICByZXR1cm4gdGhpcy5faGVhZGVyLnVzZXJJbmZvO1xyXG4gICAgfVxyXG5cclxuICAgIHByb3RlY3RlZCBzZXRIZWFkZXJDb25maWcoX2NvbmY6IGFueSkge1xyXG4gICAgICAgIHRoaXMuX2hlYWRlci51c2VySW5mbyA9IF9jb25mO1xyXG4gICAgfVxyXG5cclxuICAgIHByb3RlY3RlZCB1cGRhdGVIZWFkZXIoKSB7XHJcbiAgICAgICAgdGhpcy5vcHRpb25zLnBhZ2VFdmVudC51cGRhdGVIZWFkZXIodGhpcy5faGVhZGVyKTtcclxuICAgIH1cclxuXHJcbiAgICAvKipcclxuICAgICAqIExlZnQgTmF2aWdhdGlvblxyXG4gICAgICovXHJcblxyXG4gICAgcHJvdGVjdGVkIHNldExlZnRNZW51TGlzdChfbGVmdE1lbnVPYmo6IGFueSkge1xyXG4gICAgICAgIHRoaXMub3B0aW9ucy5wYWdlRXZlbnQudXBkYXRlTGVmdG1lbnUoX2xlZnRNZW51T2JqKTtcclxuICAgIH1cclxuXHJcbiAgICAvKipcclxuICAgICAqIFBhZ2UgSGVhZGVyXHJcbiAgICAgKi9cclxuXHJcbiAgICBwcm90ZWN0ZWQgZ2V0UGFnZVRpdGxlKCk6IHN0cmluZyB7XHJcbiAgICAgICAgcmV0dXJuIHRoaXMuX3BhZ2VoZWFkZXIucGFnZWhlYWRlclRleHQ7XHJcbiAgICB9XHJcblxyXG4gICAgcHJvdGVjdGVkIHNldFBhZ2VUaXRsZShfdGl0bGU6IHN0cmluZywgX2h1bWFuaXplOiBib29sZWFuID0gdHJ1ZSkge1xyXG4gICAgICAgIGxldCB0ZW1wU3RyOiBzdHJpbmcgPSBfdGl0bGUucmVwbGFjZSh0aGlzLl90ZXh0T21pdHRlZCwgJycpO1xyXG4gICAgICAgIGlmIChfaHVtYW5pemUpIHtcclxuICAgICAgICAgICAgdGVtcFN0ciA9IHRoaXMuaHVtYW5pemUodGhpcy51bmRlcnNjb3JlKHRlbXBTdHIpKTtcclxuICAgICAgICB9XHJcbiAgICAgICAgLy8gY29uc29sZS5sb2coJ3NldFBhZ2VUaXRsZT0nLHRlbXBTdHIpO1xyXG4gICAgICAgIHRoaXMuX3BhZ2VoZWFkZXIucGFnZWhlYWRlclRleHQgPSB0ZW1wU3RyO1xyXG4gICAgfVxyXG5cclxuICAgIHByb3RlY3RlZCBnZXRUb29sYmFyTWFpbkJ0bnMoKTogQXJyYXk8YW55PiB7XHJcbiAgICAgICAgcmV0dXJuIEpTT04ucGFyc2UoSlNPTi5zdHJpbmdpZnkodGhpcy5fcGFnZWhlYWRlci5sZWZ0QnRuKSk7XHJcbiAgICB9XHJcblxyXG4gICAgcHJvdGVjdGVkIHNldFRvb2xiYXJNYWluQnRucyhfYnV0dG9uczogQXJyYXk8YW55Pikge1xyXG4gICAgICAgIHRoaXMuX3BhZ2VoZWFkZXIubGVmdEJ0biA9IF9idXR0b25zO1xyXG4gICAgfVxyXG5cclxuICAgIHByb3RlY3RlZCBnZXRUb29sYmFyTW9yZUFjdGlvbkJ0bnMoKTogQXJyYXk8YW55PiB7XHJcbiAgICAgICAgcmV0dXJuIHRoaXMuX3BhZ2VoZWFkZXIubW9yZUFjdGlvbjtcclxuICAgIH1cclxuXHJcbiAgICBwcm90ZWN0ZWQgZW5hYmxlTW9yZUFjdGlvbkJ0bnMoX2VuYWJsZTogYm9vbGVhbiwgX2J1dHRvbnM/OiBBcnJheTxhbnk+KSB7XHJcbiAgICAgICAgdGhpcy5fcGFnZWhlYWRlci5tb3JlQnRuID0gX2VuYWJsZTtcclxuICAgICAgICBpZiAoX2J1dHRvbnMpIHtcclxuICAgICAgICAgICAgdGhpcy5fcGFnZWhlYWRlci5tb3JlQWN0aW9uID0gX2J1dHRvbnM7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIHByb3RlY3RlZCBlbmFibGVUb29sYmFyU2VhcmNoKF9lbmFibGU6IGJvb2xlYW4sIF9jYWxsYmFjaz86IChfdGV4dDogc3RyaW5nKSA9PiB2b2lkKSB7XHJcbiAgICAgICAgdGhpcy5fcGFnZWhlYWRlci5zZWFyY2hCdG4gPSBfZW5hYmxlO1xyXG4gICAgICAgIGlmIChfZW5hYmxlICYmIF9jYWxsYmFjaykge1xyXG4gICAgICAgICAgICB0aGlzLl9wYWdlaGVhZGVyLnNlYXJjaENhbGxiYWNrID0gX2NhbGxiYWNrO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICBwcm90ZWN0ZWQgdXBkYXRlU2VhcmNoVGV4dChfc2VhcmNoVGV4dDogc3RyaW5nKSB7XHJcbiAgICAgICAgdGhpcy5fcGFnZWhlYWRlci5zZWFyY2hUZXh0ID0gX3NlYXJjaFRleHQ7XHJcbiAgICB9XHJcblxyXG4gICAgcHJvdGVjdGVkIHVwZGF0ZVBhZ2VIZWFkZXIoKSB7XHJcbiAgICAgICAgY29uc29sZS5sb2coJ2Jyb2FkY2FzdCB1cGRhdGVQYWdlSGVhZGVyJywgdGhpcy5fcGFnZWhlYWRlcik7XHJcbiAgICAgICAgdGhpcy5vcHRpb25zLnBhZ2VFdmVudC51cGRhdGVQYWdlSGVhZGVyKHRoaXMuX3BhZ2VoZWFkZXIpO1xyXG4gICAgfVxyXG5cclxuICAgIC8qKlxyXG4gICAgICogQnJlYWRjcnVtYnNcclxuICAgICAqL1xyXG5cclxuICAgIHByb3RlY3RlZCBzZXRCcmVhZGNydW1ic0xpc3QoX2xpc3Q6IEFycmF5PGFueT4pOiB2b2lkIHtcclxuICAgICAgICB0aGlzLl9icmVhZGNydW1iTGlzdC5saXN0ID0gX2xpc3Q7XHJcbiAgICAgICAgdGhpcy51cGRhdGVCcmVhZGNydW1iKCk7XHJcbiAgICB9XHJcblxyXG4gICAgcHJvdGVjdGVkIGdldEJyZWFkY3J1bWJzTGlzdCgpOiBBcnJheTxhbnk+IHtcclxuICAgICAgICByZXR1cm4gdGhpcy5fYnJlYWRjcnVtYkxpc3QubGlzdDtcclxuICAgIH1cclxuXHJcbiAgICBwcm90ZWN0ZWQgdXBkYXRlQnJlYWRjcnVtYigpOiB2b2lkIHtcclxuICAgICAgICB0aGlzLm9wdGlvbnMucGFnZUV2ZW50LnVwZGF0ZUJyZWFkY3J1bWIoSlNPTi5wYXJzZShKU09OLnN0cmluZ2lmeSh0aGlzLl9icmVhZGNydW1iTGlzdCkpKTtcclxuICAgIH1cclxuXHJcbiAgICAvKipcclxuICAgICAqIEFsZXJ0c1xyXG4gICAgICovXHJcblxyXG4gICAgcHJvdGVjdGVkIHNldEFsZXJ0KF9jb25maWc6IGFueSwgX3R5cGU6IHN0cmluZyk6IHZvaWQge1xyXG4gICAgICAgIGlmICh0aGlzLm9wdGlvbnMuYWxlcnRFdmVudCkge1xyXG4gICAgICAgICAgICB0aGlzLm9wdGlvbnMuYWxlcnRFdmVudFtfdHlwZV0oX2NvbmZpZyk7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICBjb25zb2xlLndhcm4oJ01pc3NpbmcgZXZlbnQgLSBLZEFsZXJ0RXZlbnQnKTtcclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgLyoqXHJcbiAgICAgKiBbc2V0TW9kYWwgQ3JlYXRpbmcgbW9kYWwgdmlld11cclxuICAgICAqICBfY29uZmlnQ29uZmltYXRpb24ge1xyXG4gICAgICogICAgICAgICAgICAgIGhlYWRlcjogJycsXHJcbiAgICAgKiAgICAgICAgICAgICAgbWVzc2FnZTogJycsXHJcbiAgICAgKiAgICAgICAgICAgICAgYnV0dG9uQ29uZmlybToge1xyXG4gICAgICogICAgICAgICAgICAgICAgICB0ZXh0OiAndGVzdCB0ZXh0JyxcclxuICAgICAqICAgICAgICAgICAgICAgICAgY2FsbGJhY2s6ICgpID0+e1xyXG4gICAgICpcclxuICAgICAqICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICogICAgICAgICAgICAgIH1cclxuICAgICAqICAgICAgICAgIH1cclxuICAgICAqL1xyXG4gICAgcHJvdGVjdGVkIHNldE1vZGFsKCk6IHsgY29uZmlybWF0aW9uOiBGdW5jdGlvbiwgbm90aWZ5OiBGdW5jdGlvbiwgZGlzYWJsZWQ6IEZ1bmN0aW9uLCBjbG9zZTogRnVuY3Rpb24gfSB7XHJcbiAgICAgICAgbGV0IF9wYWdlQmFzZUV2ZW50OiBLZFBhZ2VCYXNlRXZlbnQ7XHJcbiAgICAgICAgaWYgKHRoaXMub3B0aW9ucy5wYWdlRXZlbnQpIHtcclxuICAgICAgICAgICAgX3BhZ2VCYXNlRXZlbnQgPSB0aGlzLm9wdGlvbnMucGFnZUV2ZW50O1xyXG4gICAgICAgIH1cclxuICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgY29uc29sZS53YXJuKCdQbGVhc2UgaW1wb3J0IFxcJ1BhZ2VCYXNlRXZlbnRcXCcgdG8gdXNlIG1vZGFsJyk7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICAvKipcclxuICAgICAgICAgKiBbY29uZmlybWF0aW9uIGEgbW9kYWwgZGlhbG9nIHdpdGggMiBidXR0b25zOiAnQ29uZmlybScgYW5kICdDYW5jZWwnXVxyXG4gICAgICAgICAqL1xyXG4gICAgICAgIGZ1bmN0aW9uIGNvbmZpcm1hdGlvbihfY29uZmlnPzogYW55KTogdm9pZCB7XHJcbiAgICAgICAgICAgIGlmIChfcGFnZUJhc2VFdmVudCkge1xyXG4gICAgICAgICAgICAgICAgbGV0IHVwZGF0ZWRDb25maWc6IGFueSA9IHt9O1xyXG4gICAgICAgICAgICAgICAgbGV0IGRlZmF1bHRDb25maWc6IGFueSA9IHtcclxuICAgICAgICAgICAgICAgICAgICBzdXNwZW5kQ2xvc2U6IHRydWUsXHJcbiAgICAgICAgICAgICAgICAgICAgdGl0bGU6ICdBbGVydCcsXHJcbiAgICAgICAgICAgICAgICAgICAgYm9keTogJ0R1bW15IHRleHQgLSBjb25maXJtYXRpb24nLFxyXG4gICAgICAgICAgICAgICAgICAgIGJ1dHRvbjogW3tcclxuICAgICAgICAgICAgICAgICAgICAgICAgdGV4dDogJ0NvbmZpcm0nLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBjbGFzczogJ2J0bi10ZXh0JyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgY2FsbGJhY2s6ICgpOiB2b2lkID0+IHsgfVxyXG4gICAgICAgICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICAgICAgICAge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB0ZXh0OiAnQ2FuY2VsJyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3M6ICdidG4tb3V0bGluZScsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNhbGxiYWNrOiAoKTogdm9pZCA9PiB7IF9wYWdlQmFzZUV2ZW50LnVwZGF0ZU1vZGFsKHsgY2xvc2U6IHRydWUgfSk7IH1cclxuICAgICAgICAgICAgICAgICAgICB9XVxyXG4gICAgICAgICAgICAgICAgfTtcclxuXHJcbiAgICAgICAgICAgICAgICB1cGRhdGVkQ29uZmlnID0gYXBwbHlDb25maWcoX2NvbmZpZywgZGVmYXVsdENvbmZpZyk7XHJcbiAgICAgICAgICAgICAgICBfcGFnZUJhc2VFdmVudC51cGRhdGVNb2RhbCh7IGVuYWJsZWQ6IHRydWUsIGNvbmZpZzogdXBkYXRlZENvbmZpZyB9KTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgLyoqXHJcbiAgICAgICAgICogW25vdGlmeSBhIG1vZGFsIGRpYWxvZyB3aXRoIDEgYnV0dG9uOiAnRG9uZSddXHJcbiAgICAgICAgICovXHJcbiAgICAgICAgZnVuY3Rpb24gbm90aWZ5KF9jb25maWc/OiBhbnkpOiB2b2lkIHtcclxuICAgICAgICAgICAgaWYgKF9wYWdlQmFzZUV2ZW50KSB7XHJcbiAgICAgICAgICAgICAgICBsZXQgdXBkYXRlZENvbmZpZzogYW55ID0ge307XHJcbiAgICAgICAgICAgICAgICBsZXQgZGVmYXVsdENvbmZpZzogYW55ID0ge1xyXG4gICAgICAgICAgICAgICAgICAgIHN1c3BlbmRDbG9zZTogdHJ1ZSxcclxuICAgICAgICAgICAgICAgICAgICB0aXRsZTogJ0FsZXJ0JyxcclxuICAgICAgICAgICAgICAgICAgICBib2R5OiAnRHVtbXkgdGV4dCAtIG5vdGlmeScsXHJcbiAgICAgICAgICAgICAgICAgICAgYnV0dG9uOiBbe1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB0ZXh0OiAnRG9uZScsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzOiAnYnRuLXRleHQnLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBjYWxsYmFjazogKCk6IHZvaWQgPT4geyBfcGFnZUJhc2VFdmVudC51cGRhdGVNb2RhbCh7IGNsb3NlOiB0cnVlIH0pOyB9XHJcbiAgICAgICAgICAgICAgICAgICAgfV1cclxuICAgICAgICAgICAgICAgIH07XHJcblxyXG4gICAgICAgICAgICAgICAgdXBkYXRlZENvbmZpZyA9IGFwcGx5Q29uZmlnKF9jb25maWcsIGRlZmF1bHRDb25maWcpO1xyXG4gICAgICAgICAgICAgICAgX3BhZ2VCYXNlRXZlbnQudXBkYXRlTW9kYWwoeyBlbmFibGVkOiB0cnVlLCBjb25maWc6IHVwZGF0ZWRDb25maWcgfSk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIGZ1bmN0aW9uIGRpc2FibGVkKCk6IHZvaWQge1xyXG4gICAgICAgICAgICBpZiAoX3BhZ2VCYXNlRXZlbnQpIF9wYWdlQmFzZUV2ZW50LnVwZGF0ZU1vZGFsKHsgZW5hYmxlZDogZmFsc2UgfSk7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICBmdW5jdGlvbiBjbG9zZSgpOiB2b2lkIHtcclxuICAgICAgICAgICAgaWYgKF9wYWdlQmFzZUV2ZW50KSBfcGFnZUJhc2VFdmVudC51cGRhdGVNb2RhbCh7IGNsb3NlOiB0cnVlIH0pO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgZnVuY3Rpb24gYXBwbHlDb25maWcoX3NvdXJjZUNvbmZpZzogYW55LCBfdGFyZ2V0Q29uZmlnOiBhbnkpOiB7fSB7XHJcbiAgICAgICAgICAgIGxldCB1cGRhdGVkQ29uZmlnOiBhbnkgPSB7fTtcclxuICAgICAgICAgICAgKDxhbnk+T2JqZWN0KS5hc3NpZ24odXBkYXRlZENvbmZpZywgX3RhcmdldENvbmZpZyk7XHJcblxyXG4gICAgICAgICAgICBpZiAoX3NvdXJjZUNvbmZpZy5oZWFkZXIpIHVwZGF0ZWRDb25maWcudGl0bGUgPSBfc291cmNlQ29uZmlnLmhlYWRlcjtcclxuICAgICAgICAgICAgaWYgKF9zb3VyY2VDb25maWcubWVzc2FnZSkgdXBkYXRlZENvbmZpZy5ib2R5ID0gX3NvdXJjZUNvbmZpZy5tZXNzYWdlO1xyXG4gICAgICAgICAgICBpZiAoX3NvdXJjZUNvbmZpZy5idXR0b25Db25maXJtKSB7XHJcbiAgICAgICAgICAgICAgICBpZiAoX3NvdXJjZUNvbmZpZy5idXR0b25Db25maXJtLnRleHQpIHVwZGF0ZWRDb25maWcuYnV0dG9uWzBdLnRleHQgPSBfc291cmNlQ29uZmlnLmJ1dHRvbkNvbmZpcm0udGV4dDtcclxuICAgICAgICAgICAgICAgIGlmIChfc291cmNlQ29uZmlnLmJ1dHRvbkNvbmZpcm0uY2FsbGJhY2spIHVwZGF0ZWRDb25maWcuYnV0dG9uWzBdLmNhbGxiYWNrID0gX3NvdXJjZUNvbmZpZy5idXR0b25Db25maXJtLmNhbGxiYWNrO1xyXG4gICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICByZXR1cm4gdXBkYXRlZENvbmZpZztcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIHJldHVybiB7XHJcbiAgICAgICAgICAgIGNvbmZpcm1hdGlvbjogY29uZmlybWF0aW9uLFxyXG4gICAgICAgICAgICBub3RpZnk6IG5vdGlmeSxcclxuICAgICAgICAgICAgZGlzYWJsZWQ6IGRpc2FibGVkLFxyXG4gICAgICAgICAgICBjbG9zZTogY2xvc2VcclxuICAgICAgICB9O1xyXG4gICAgfVxyXG5cclxuXHJcblxyXG4gICAgLyoqXHJcbiAgICAgKiBVdGlscyBNZXRob2RzXHJcbiAgICAgKi9cclxuXHJcbiAgICAvLyBwcml2YXRlIGluaXRQcmV2SGlzdG9yeSgpe1xyXG4gICAgLy8gICAgIC8vIHRoaXMuX3JvdXRlckhpc3RvcnlTdWIgPSB0aGlzLm9wdGlvbnMucm91dGVyLmV2ZW50c1xyXG4gICAgLy8gICAgIHJldHVybiB0aGlzLm9wdGlvbnMucm91dGVyLmV2ZW50c1xyXG4gICAgLy8gICAgICAgICAuZmlsdGVyKGUgPT4gZSBpbnN0YW5jZW9mIFJvdXRlc1JlY29nbml6ZWQpXHJcbiAgICAvLyAgICAgICAgIC8vIC5maWx0ZXIoZSA9PiAoZS5jb25zdHJ1Y3Rvci5uYW1lID09PSAnUm91dGVzUmVjb2duaXplZCcpIHx8ICggZS5jb25zdHJ1Y3Rvci5uYW1lID09PSAnTmF2aWdhdGlvbkVuZCcpKVxyXG4gICAgLy8gICAgICAgICAucGFpcndpc2UoKVxyXG4gICAgLy8gICAgICAgICAuc3Vic2NyaWJlKChlOiBhbnlbXSk6IHZvaWQgPT4ge1xyXG4gICAgLy8gICAgICAgICAgICAgY29uc29sZS5sb2coJzEgb24gaW5pdCA+IHVybCBpbmZvICcsIGUpO1xyXG4gICAgLy8gICAgICAgICAgICAgY29uc29sZS5sb2cobmV3IERhdGUoKSk7XHJcbiAgICAvLyAgICAgICAgICAgICBjb25zb2xlLmxvZyhlWzBdKTtcclxuICAgIC8vICAgICAgICAgICAgIGNvbnNvbGUubG9nKGVbZS5sZW5ndGggLSAxXSk7XHJcbiAgICAvLyAgICAgICAgICAgICByZXR1cm4gZVswXTtcclxuICAgIC8vICAgICAgICAgICAgIC8vIGNvbnNvbGUubG9nKCd0aGlzLl9wcmV2UGFnZUluZm8gPSA+ICcsIHRoaXMuX3ByZXZQYWdlSW5mbyk7XHJcbiAgICAvLyAgICAgICAgICAgICAvLyB0aGlzLl9yb3V0ZXJIaXN0b3J5U3ViLnVuc3Vic2NyaWJlKCk7XHJcbiAgICAvLyAgICAgICAgIH0pO1xyXG4gICAgLy8gfVxyXG5cclxuICAgIHByb3RlY3RlZCBnZXRDdXJyZW50VVJMKCk6IHN0cmluZyB7XHJcbiAgICAgICAgcmV0dXJuIHRoaXMuX2N1cnJlbnRVUkw7XHJcbiAgICB9XHJcblxyXG4gICAgcHJvdGVjdGVkIHNldFRleHRPbWl0KF90ZXh0OiBzdHJpbmcpIHtcclxuICAgICAgICB0aGlzLl90ZXh0T21pdHRlZCA9IF90ZXh0O1xyXG4gICAgfVxyXG5cclxuICAgIHByb3RlY3RlZCBnZXRQYXJhbXMoKTogYW55IHtcclxuICAgICAgICByZXR1cm4gdGhpcy5fcGFnZVBhcmFtcztcclxuICAgIH1cclxuXHJcbiAgICBwcm90ZWN0ZWQgZ2V0UHJldlBhZ2VJbmZvKCk6IHN0cmluZyB7XHJcbiAgICAgICAgY29uc29sZS5sb2coJ2dldFByZXZQYWdlSW5mbyAuID4+ICcsIHRoaXMuX3ByZXZQYWdlVVJMKTtcclxuICAgICAgICByZXR1cm4gdGhpcy5fcHJldlBhZ2VVUkw7XHJcbiAgICB9XHJcblxyXG4gICAgcHJvdGVjdGVkIHVuZGVyc2NvcmUoX2NhbWVsQ2FzZTogc3RyaW5nKTogc3RyaW5nIHtcclxuICAgICAgICByZXR1cm4gdGhpcy5jb252ZXJ0aW9uU3ZjLnVuZGVyc2NvcmUoX2NhbWVsQ2FzZSk7XHJcbiAgICB9XHJcblxyXG4gICAgcHJvdGVjdGVkIGh1bWFuaXplKF91bmRlcnNjb3JlZDogc3RyaW5nKTogc3RyaW5nIHtcclxuICAgICAgICByZXR1cm4gdGhpcy5jb252ZXJ0aW9uU3ZjLmh1bWFuaXplKF91bmRlcnNjb3JlZCk7XHJcbiAgICB9XHJcblxyXG4gICAgcHJvdGVjdGVkIGNhbWVsQ2FzZShfdGV4dDogc3RyaW5nKTogc3RyaW5nIHtcclxuICAgICAgICByZXR1cm4gdGhpcy5jb252ZXJ0aW9uU3ZjLmNhbWVsQ2FzZShfdGV4dCwgJyAnKTtcclxuICAgIH1cclxuXHJcblxyXG4gICAgcHJvdGVjdGVkIHNsdWcoX3dvcmQ6IHN0cmluZykge1xyXG4gICAgICAgIHJldHVybiB0aGlzLmNvbnZlcnRpb25TdmMuc2x1Zyhfd29yZCk7XHJcbiAgICB9XHJcbn1cclxuIl19