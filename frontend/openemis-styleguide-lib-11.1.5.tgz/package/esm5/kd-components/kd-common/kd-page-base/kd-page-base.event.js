import { __decorate, __metadata } from "tslib";
import { Injectable } from '@angular/core';
// import { KdBroadcaster } from '../kd-broadcaster/kd-broadcaster-svc';
// import { KdBroadcaster } from '../../';
import { KdBroadcaster } from '../index';
import * as i0 from "@angular/core";
import * as i1 from "../kd-broadcaster-svc";
var KdPageBaseEvent = /** @class */ (function () {
    // public broadcaster: KdBroadcaster;
    function KdPageBaseEvent(broadcaster) {
        this.broadcaster = broadcaster;
    }
    KdPageBaseEvent.prototype.updatePageHeader = function (data) {
        this.broadcaster.broadcast('Template_UpdatePageHeader', data);
    };
    KdPageBaseEvent.prototype.onUpdatePageHeader = function () {
        return this.broadcaster.on('Template_UpdatePageHeader');
    };
    KdPageBaseEvent.prototype.updateHeader = function (data) {
        this.broadcaster.broadcast('Template_UpdateHeader', data);
    };
    KdPageBaseEvent.prototype.onUpdateHeader = function () {
        return this.broadcaster.on('Template_UpdateHeader');
    };
    KdPageBaseEvent.prototype.updateBreadcrumb = function (data) {
        this.broadcaster.broadcast('Template_UpdateBreadcrumb', data);
    };
    KdPageBaseEvent.prototype.onUpdateBreadcrumb = function () {
        return this.broadcaster.on('Template_UpdateBreadcrumb');
    };
    KdPageBaseEvent.prototype.updateLeftmenu = function (data) {
        this.broadcaster.broadcast('Template_UpdateLeftMenu', data);
    };
    KdPageBaseEvent.prototype.onUpdateLeftmenu = function () {
        return this.broadcaster.on('Template_UpdateLeftMenu');
    };
    KdPageBaseEvent.prototype.appReady = function () {
        // this.broadcaster.broadcastReplay('AppReady');
        this.broadcaster.broadcastAsync('AppReady');
    };
    KdPageBaseEvent.prototype.onAppReady = function () {
        // return this.broadcaster.onReplay<any>('AppReady');
        return this.broadcaster.onAsync('AppReady');
    };
    KdPageBaseEvent.prototype.onAppReadyComplete = function () {
        this.broadcaster.completeAsync('AppReady');
    };
    // loadV2(data: any): void {
    //     this.broadcaster.broadcast('LoadV2', data);
    // }
    // onLoadV2(): Observable<any> {
    //     return this.broadcaster.on<any>('LoadV2');
    // }
    KdPageBaseEvent.prototype.updateModal = function (data) {
        this.broadcaster.broadcast('ShowModal', data);
    };
    KdPageBaseEvent.prototype.onUpdateModal = function () {
        return this.broadcaster.on('ShowModal');
    };
    KdPageBaseEvent.ctorParameters = function () { return [
        { type: KdBroadcaster }
    ]; };
    KdPageBaseEvent.ɵprov = i0.ɵɵdefineInjectable({ factory: function KdPageBaseEvent_Factory() { return new KdPageBaseEvent(i0.ɵɵinject(i1.KdBroadcaster)); }, token: KdPageBaseEvent, providedIn: "root" });
    KdPageBaseEvent = __decorate([
        Injectable({
            providedIn: 'root'
        }),
        __metadata("design:paramtypes", [KdBroadcaster])
    ], KdPageBaseEvent);
    return KdPageBaseEvent;
}());
export { KdPageBaseEvent };
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoia2QtcGFnZS1iYXNlLmV2ZW50LmpzIiwic291cmNlUm9vdCI6Im5nOi8vb3BlbmVtaXMtc3R5bGVndWlkZS1saWIvIiwic291cmNlcyI6WyJrZC1jb21wb25lbnRzL2tkLWNvbW1vbi9rZC1wYWdlLWJhc2Uva2QtcGFnZS1iYXNlLmV2ZW50LnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7QUFBQSxPQUFPLEVBQUUsVUFBVSxFQUFFLE1BQU0sZUFBZSxDQUFDO0FBRTNDLHdFQUF3RTtBQUN4RSwwQ0FBMEM7QUFDMUMsT0FBTyxFQUFFLGFBQWEsRUFBRSxNQUFNLFVBQVUsQ0FBQzs7O0FBS3pDO0lBQ0kscUNBQXFDO0lBQ3JDLHlCQUFzQixXQUEwQjtRQUExQixnQkFBVyxHQUFYLFdBQVcsQ0FBZTtJQUFJLENBQUM7SUFFckQsMENBQWdCLEdBQWhCLFVBQWlCLElBQVM7UUFDdEIsSUFBSSxDQUFDLFdBQVcsQ0FBQyxTQUFTLENBQUMsMkJBQTJCLEVBQUUsSUFBSSxDQUFDLENBQUM7SUFDbEUsQ0FBQztJQUVELDRDQUFrQixHQUFsQjtRQUNJLE9BQU8sSUFBSSxDQUFDLFdBQVcsQ0FBQyxFQUFFLENBQU0sMkJBQTJCLENBQUMsQ0FBQztJQUNqRSxDQUFDO0lBRUQsc0NBQVksR0FBWixVQUFhLElBQVM7UUFDbEIsSUFBSSxDQUFDLFdBQVcsQ0FBQyxTQUFTLENBQUMsdUJBQXVCLEVBQUUsSUFBSSxDQUFDLENBQUM7SUFDOUQsQ0FBQztJQUVELHdDQUFjLEdBQWQ7UUFDSSxPQUFPLElBQUksQ0FBQyxXQUFXLENBQUMsRUFBRSxDQUFNLHVCQUF1QixDQUFDLENBQUM7SUFDN0QsQ0FBQztJQUVELDBDQUFnQixHQUFoQixVQUFpQixJQUFTO1FBQ3RCLElBQUksQ0FBQyxXQUFXLENBQUMsU0FBUyxDQUFDLDJCQUEyQixFQUFFLElBQUksQ0FBQyxDQUFDO0lBQ2xFLENBQUM7SUFFRCw0Q0FBa0IsR0FBbEI7UUFDSSxPQUFPLElBQUksQ0FBQyxXQUFXLENBQUMsRUFBRSxDQUFNLDJCQUEyQixDQUFDLENBQUM7SUFDakUsQ0FBQztJQUVELHdDQUFjLEdBQWQsVUFBZSxJQUFTO1FBQ3BCLElBQUksQ0FBQyxXQUFXLENBQUMsU0FBUyxDQUFDLHlCQUF5QixFQUFFLElBQUksQ0FBQyxDQUFDO0lBQ2hFLENBQUM7SUFFRCwwQ0FBZ0IsR0FBaEI7UUFDSSxPQUFPLElBQUksQ0FBQyxXQUFXLENBQUMsRUFBRSxDQUFNLHlCQUF5QixDQUFDLENBQUM7SUFDL0QsQ0FBQztJQUVELGtDQUFRLEdBQVI7UUFDSSxnREFBZ0Q7UUFDaEQsSUFBSSxDQUFDLFdBQVcsQ0FBQyxjQUFjLENBQUMsVUFBVSxDQUFDLENBQUM7SUFDaEQsQ0FBQztJQUVELG9DQUFVLEdBQVY7UUFDSSxxREFBcUQ7UUFDckQsT0FBTyxJQUFJLENBQUMsV0FBVyxDQUFDLE9BQU8sQ0FBTSxVQUFVLENBQUMsQ0FBQztJQUNyRCxDQUFDO0lBRUQsNENBQWtCLEdBQWxCO1FBQ0ksSUFBSSxDQUFDLFdBQVcsQ0FBQyxhQUFhLENBQUMsVUFBVSxDQUFDLENBQUM7SUFDL0MsQ0FBQztJQUVELDRCQUE0QjtJQUM1QixrREFBa0Q7SUFDbEQsSUFBSTtJQUVKLGdDQUFnQztJQUNoQyxpREFBaUQ7SUFDakQsSUFBSTtJQUVKLHFDQUFXLEdBQVgsVUFBWSxJQUFTO1FBQ2pCLElBQUksQ0FBQyxXQUFXLENBQUMsU0FBUyxDQUFDLFdBQVcsRUFBRSxJQUFJLENBQUMsQ0FBQztJQUNsRCxDQUFDO0lBRUQsdUNBQWEsR0FBYjtRQUNJLE9BQU8sSUFBSSxDQUFDLFdBQVcsQ0FBQyxFQUFFLENBQU0sV0FBVyxDQUFDLENBQUM7SUFDakQsQ0FBQzs7Z0JBOURrQyxhQUFhOzs7SUFGdkMsZUFBZTtRQUgzQixVQUFVLENBQUU7WUFDUixVQUFVLEVBQUUsTUFBTTtTQUN0QixDQUFFO3lDQUdvQyxhQUFhO09BRnZDLGVBQWUsQ0FpRTNCOzBCQTFFRDtDQTBFQyxBQWpFRCxJQWlFQztTQWpFWSxlQUFlIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgSW5qZWN0YWJsZSB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xyXG5pbXBvcnQgeyBPYnNlcnZhYmxlIH0gZnJvbSAncnhqcyc7XHJcbi8vIGltcG9ydCB7IEtkQnJvYWRjYXN0ZXIgfSBmcm9tICcuLi9rZC1icm9hZGNhc3Rlci9rZC1icm9hZGNhc3Rlci1zdmMnO1xyXG4vLyBpbXBvcnQgeyBLZEJyb2FkY2FzdGVyIH0gZnJvbSAnLi4vLi4vJztcclxuaW1wb3J0IHsgS2RCcm9hZGNhc3RlciB9IGZyb20gJy4uL2luZGV4JztcclxuXHJcbkBJbmplY3RhYmxlKCB7XHJcbiAgICAgcHJvdmlkZWRJbjogJ3Jvb3QnXHJcbn0gKVxyXG5leHBvcnQgY2xhc3MgS2RQYWdlQmFzZUV2ZW50IHtcclxuICAgIC8vIHB1YmxpYyBicm9hZGNhc3RlcjogS2RCcm9hZGNhc3RlcjtcclxuICAgIGNvbnN0cnVjdG9yKHByb3RlY3RlZCBicm9hZGNhc3RlcjogS2RCcm9hZGNhc3RlcikgeyB9XHJcblxyXG4gICAgdXBkYXRlUGFnZUhlYWRlcihkYXRhOiBhbnkpOiB2b2lkIHtcclxuICAgICAgICB0aGlzLmJyb2FkY2FzdGVyLmJyb2FkY2FzdCgnVGVtcGxhdGVfVXBkYXRlUGFnZUhlYWRlcicsIGRhdGEpO1xyXG4gICAgfVxyXG5cclxuICAgIG9uVXBkYXRlUGFnZUhlYWRlcigpOiBPYnNlcnZhYmxlPGFueT4ge1xyXG4gICAgICAgIHJldHVybiB0aGlzLmJyb2FkY2FzdGVyLm9uPGFueT4oJ1RlbXBsYXRlX1VwZGF0ZVBhZ2VIZWFkZXInKTtcclxuICAgIH1cclxuXHJcbiAgICB1cGRhdGVIZWFkZXIoZGF0YTogYW55KTogdm9pZCB7XHJcbiAgICAgICAgdGhpcy5icm9hZGNhc3Rlci5icm9hZGNhc3QoJ1RlbXBsYXRlX1VwZGF0ZUhlYWRlcicsIGRhdGEpO1xyXG4gICAgfVxyXG5cclxuICAgIG9uVXBkYXRlSGVhZGVyKCk6IE9ic2VydmFibGU8YW55PiB7XHJcbiAgICAgICAgcmV0dXJuIHRoaXMuYnJvYWRjYXN0ZXIub248YW55PignVGVtcGxhdGVfVXBkYXRlSGVhZGVyJyk7XHJcbiAgICB9XHJcblxyXG4gICAgdXBkYXRlQnJlYWRjcnVtYihkYXRhOiBhbnkpOiB2b2lkIHtcclxuICAgICAgICB0aGlzLmJyb2FkY2FzdGVyLmJyb2FkY2FzdCgnVGVtcGxhdGVfVXBkYXRlQnJlYWRjcnVtYicsIGRhdGEpO1xyXG4gICAgfVxyXG5cclxuICAgIG9uVXBkYXRlQnJlYWRjcnVtYigpOiBPYnNlcnZhYmxlPGFueT4ge1xyXG4gICAgICAgIHJldHVybiB0aGlzLmJyb2FkY2FzdGVyLm9uPGFueT4oJ1RlbXBsYXRlX1VwZGF0ZUJyZWFkY3J1bWInKTtcclxuICAgIH1cclxuXHJcbiAgICB1cGRhdGVMZWZ0bWVudShkYXRhOiBhbnkpOiB2b2lkIHtcclxuICAgICAgICB0aGlzLmJyb2FkY2FzdGVyLmJyb2FkY2FzdCgnVGVtcGxhdGVfVXBkYXRlTGVmdE1lbnUnLCBkYXRhKTtcclxuICAgIH1cclxuXHJcbiAgICBvblVwZGF0ZUxlZnRtZW51KCk6IE9ic2VydmFibGU8YW55PiB7XHJcbiAgICAgICAgcmV0dXJuIHRoaXMuYnJvYWRjYXN0ZXIub248YW55PignVGVtcGxhdGVfVXBkYXRlTGVmdE1lbnUnKTtcclxuICAgIH1cclxuXHJcbiAgICBhcHBSZWFkeSgpOiB2b2lkIHtcclxuICAgICAgICAvLyB0aGlzLmJyb2FkY2FzdGVyLmJyb2FkY2FzdFJlcGxheSgnQXBwUmVhZHknKTtcclxuICAgICAgICB0aGlzLmJyb2FkY2FzdGVyLmJyb2FkY2FzdEFzeW5jKCdBcHBSZWFkeScpO1xyXG4gICAgfVxyXG5cclxuICAgIG9uQXBwUmVhZHkoKTogT2JzZXJ2YWJsZTxhbnk+IHtcclxuICAgICAgICAvLyByZXR1cm4gdGhpcy5icm9hZGNhc3Rlci5vblJlcGxheTxhbnk+KCdBcHBSZWFkeScpO1xyXG4gICAgICAgIHJldHVybiB0aGlzLmJyb2FkY2FzdGVyLm9uQXN5bmM8YW55PignQXBwUmVhZHknKTtcclxuICAgIH1cclxuXHJcbiAgICBvbkFwcFJlYWR5Q29tcGxldGUoKTogdm9pZCB7XHJcbiAgICAgICAgdGhpcy5icm9hZGNhc3Rlci5jb21wbGV0ZUFzeW5jKCdBcHBSZWFkeScpO1xyXG4gICAgfVxyXG5cclxuICAgIC8vIGxvYWRWMihkYXRhOiBhbnkpOiB2b2lkIHtcclxuICAgIC8vICAgICB0aGlzLmJyb2FkY2FzdGVyLmJyb2FkY2FzdCgnTG9hZFYyJywgZGF0YSk7XHJcbiAgICAvLyB9XHJcblxyXG4gICAgLy8gb25Mb2FkVjIoKTogT2JzZXJ2YWJsZTxhbnk+IHtcclxuICAgIC8vICAgICByZXR1cm4gdGhpcy5icm9hZGNhc3Rlci5vbjxhbnk+KCdMb2FkVjInKTtcclxuICAgIC8vIH1cclxuXHJcbiAgICB1cGRhdGVNb2RhbChkYXRhOiBhbnkpOiB2b2lkIHtcclxuICAgICAgICB0aGlzLmJyb2FkY2FzdGVyLmJyb2FkY2FzdCgnU2hvd01vZGFsJywgZGF0YSk7XHJcbiAgICB9XHJcblxyXG4gICAgb25VcGRhdGVNb2RhbCgpOiBPYnNlcnZhYmxlPGFueT4ge1xyXG4gICAgICAgIHJldHVybiB0aGlzLmJyb2FkY2FzdGVyLm9uPGFueT4oJ1Nob3dNb2RhbCcpO1xyXG4gICAgfVxyXG59XHJcbiJdfQ==