import { __decorate, __metadata, __read } from "tslib";
import { Injectable, ElementRef, Renderer2 } from '@angular/core';
import * as i0 from "@angular/core";
var KdDomElemSvc = /** @class */ (function () {
    function KdDomElemSvc(_renderer) {
        this._renderer = _renderer;
    }
    KdDomElemSvc.prototype.isMobile = function () {
        return (window.innerWidth > 1024) ? false : true;
    };
    KdDomElemSvc.prototype.isMobileDevice = function () {
        var ua = navigator.userAgent.toLowerCase();
        return /android|webos|iphone|ipad|ipod|blackberry|iemobile|opera mini|mobi|j2me/i.test(ua);
    };
    KdDomElemSvc.prototype.getDocumentLang = function () {
        return document.documentElement.lang;
    };
    KdDomElemSvc.prototype.getDocumentTheme = function () {
        var theme = 'openemis-styleguide';
        var bodyElem = document.querySelector('body[class^="openemis-"]');
        if (bodyElem !== null) {
            // console.log(bodyElem.classList);
            // console.log(this.el);
            for (var i = 0; i < bodyElem.classList.length; i++) {
                if (bodyElem.classList[i].match(/^[openemis\-]/)) {
                    theme = bodyElem.classList[i];
                    break;
                }
            }
        }
        return theme;
    };
    /**
     * [To get document direction either LTR or RTL]
     * _isFullStr    : [whether to return short form like 'ltr' or string 'left']
     */
    KdDomElemSvc.prototype.getDocumentDirection = function (_isFullStr) {
        if (typeof _isFullStr === 'undefined')
            _isFullStr = false;
        var doc = document.querySelector('[dir]');
        var shortDir = 'ltr';
        if (doc !== null && doc.localName === 'html')
            shortDir = doc['dir'];
        if (_isFullStr) {
            return (shortDir === 'ltr') ? 'left' : 'right';
        }
        else {
            return shortDir;
        }
    };
    KdDomElemSvc.prototype.createElement = function (_parentElem, _classes, _name) {
        _name = (typeof _name === 'undefined') ? 'div' : _name;
        _name = (_name === null) ? 'div' : _name;
        var newElem = __ngRendererCreateElementHelper(this._renderer, _parentElem, _name);
        if (_classes !== null)
            this.addClass(newElem, _classes);
        return newElem;
    };
    KdDomElemSvc.prototype.addClass = function (_targetElem, _classes) {
        _classes = (typeof _classes === 'undefined') ? '' : _classes;
        var classes = _classes.split(' ');
        for (var i = 0; i < classes.length; i++) {
            // console.log(classes[i]);
            if (classes[i] === '')
                continue;
            this.setElementClass(_targetElem, classes[i], true);
        }
    };
    KdDomElemSvc.prototype.removeClass = function (_targetElem, _classes) {
        _classes = (typeof _classes === 'undefined') ? '' : _classes;
        var classes = _classes.split(' ');
        for (var i = 0; i < classes.length; i++) {
            // console.log(classes[i]);
            this.setElementClass(_targetElem, classes[i], false);
        }
    };
    KdDomElemSvc.prototype.setAttribute = function (_targetElem, _attribute, _attributeValue) {
        __ngRendererSetElementAttributeHelper(this._renderer, _targetElem, _attribute, _attributeValue);
    };
    KdDomElemSvc.prototype.setElementClass = function (_targetElem, _class, _add) {
        _add ? this._renderer.addClass(_targetElem, _class) : this._renderer.removeClass(_targetElem, _class);
    };
    KdDomElemSvc.prototype.setElementStyle = function (_targetElem, _slyleName, _styleValue) {
        this._renderer.setStyle(_targetElem, _slyleName, _styleValue);
        return _targetElem;
    };
    KdDomElemSvc.prototype.invokeElementMethod = function (_targetElem, _methodName, _arg) {
        _targetElem[_methodName].apply(_targetElem, _arg);
    };
    /**
     * [To remove dom element]
     * _class          : [class of the item to be deleted]
     * _containerElem  : [specify a container to search or the delete element
     *                                     e.g > this.element.nativeElement
     *                                     by default it will search the entire dom]
     */
    KdDomElemSvc.prototype.removeElementByClass = function (_class, _containerElem) {
        var containerElem = (typeof _containerElem === 'undefined') ? document : _containerElem;
        var deleteElem = containerElem.querySelector(_class);
        if (deleteElem !== null) {
            deleteElem.parentElement.removeChild(deleteElem);
        }
    };
    /**
     * To do auto append for font icon. For now only support Font Awesome type
     * _class    : [class name. e.g. "fa fa-university" or "fa-university"]
     *            [it will return whether to prepend the a class name or not]
     */
    KdDomElemSvc.prototype.setIconClass = function (_class) {
        var className = _class;
        var isSingleWord = _class.indexOf(' ') === -1;
        if (typeof _class === 'undefined' || _class === '' || !isSingleWord)
            return className;
        // Only append for font-awesome prefix class name
        var classes = _class.split('-');
        if (classes[0] === 'fa')
            className = 'fa ' + className;
        return className;
    };
    KdDomElemSvc.ctorParameters = function () { return [
        { type: Renderer2 }
    ]; };
    KdDomElemSvc.ɵprov = i0.ɵɵdefineInjectable({ factory: function KdDomElemSvc_Factory() { return new KdDomElemSvc(i0.ɵɵinject(i0.Renderer2)); }, token: KdDomElemSvc, providedIn: "root" });
    KdDomElemSvc = __decorate([
        Injectable({
            providedIn: 'root'
        }),
        __metadata("design:paramtypes", [Renderer2])
    ], KdDomElemSvc);
    return KdDomElemSvc;
}());
export { KdDomElemSvc };
function __ngRendererSplitNamespaceHelper(name) {
    if (name[0] === ":") {
        var match = name.match(/^:([^:]+):(.+)$/);
        return [match[1], match[2]];
    }
    return ["", name];
}
function __ngRendererCreateElementHelper(renderer, parent, namespaceAndName) {
    var _a = __read(__ngRendererSplitNamespaceHelper(namespaceAndName), 2), namespace = _a[0], name = _a[1];
    var node = renderer.createElement(name, namespace);
    if (parent) {
        renderer.appendChild(parent, node);
    }
    return node;
}
function __ngRendererSetElementAttributeHelper(renderer, element, namespaceAndName, value) {
    var _a = __read(__ngRendererSplitNamespaceHelper(namespaceAndName), 2), namespace = _a[0], name = _a[1];
    if (value != null) {
        renderer.setAttribute(element, name, value, namespace);
    }
    else {
        renderer.removeAttribute(element, name, namespace);
    }
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoia2QtZG9tZWxlbS1zdmMuanMiLCJzb3VyY2VSb290Ijoibmc6Ly9vcGVuZW1pcy1zdHlsZWd1aWRlLWxpYi8iLCJzb3VyY2VzIjpbImtkLWNvbXBvbmVudHMva2QtY29tbW9uL2tkLWRvbWVsZW0tc3ZjLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7QUFBQSxPQUFPLEVBQUUsVUFBVSxFQUFFLFVBQVUsRUFBRSxTQUFTLEVBQUUsTUFBTSxlQUFlLENBQUM7O0FBS2xFO0lBQ0ksc0JBQ1ksU0FBb0I7UUFBcEIsY0FBUyxHQUFULFNBQVMsQ0FBVztJQUM1QixDQUFDO0lBRUwsK0JBQVEsR0FBUjtRQUNJLE9BQU8sQ0FBQyxNQUFNLENBQUMsVUFBVSxHQUFHLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQztJQUNyRCxDQUFDO0lBRUQscUNBQWMsR0FBZDtRQUNJLElBQUksRUFBRSxHQUFXLFNBQVMsQ0FBQyxTQUFTLENBQUMsV0FBVyxFQUFFLENBQUM7UUFDbkQsT0FBTywwRUFBMEUsQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDLENBQUM7SUFDL0YsQ0FBQztJQUVELHNDQUFlLEdBQWY7UUFDSSxPQUFPLFFBQVEsQ0FBQyxlQUFlLENBQUMsSUFBSSxDQUFDO0lBQ3pDLENBQUM7SUFFRCx1Q0FBZ0IsR0FBaEI7UUFDSSxJQUFJLEtBQUssR0FBVyxxQkFBcUIsQ0FBQztRQUMxQyxJQUFJLFFBQVEsR0FBUSxRQUFRLENBQUMsYUFBYSxDQUFDLDBCQUEwQixDQUFDLENBQUM7UUFDdkUsSUFBSSxRQUFRLEtBQUssSUFBSSxFQUFFO1lBQ25CLG1DQUFtQztZQUNuQyx3QkFBd0I7WUFFeEIsS0FBSyxJQUFJLENBQUMsR0FBVyxDQUFDLEVBQUUsQ0FBQyxHQUFHLFFBQVEsQ0FBQyxTQUFTLENBQUMsTUFBTSxFQUFFLENBQUMsRUFBRSxFQUFFO2dCQUN4RCxJQUFJLFFBQVEsQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLGVBQWUsQ0FBQyxFQUFFO29CQUM5QyxLQUFLLEdBQUcsUUFBUSxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQztvQkFDOUIsTUFBTTtpQkFDVDthQUNKO1NBQ0o7UUFFRCxPQUFPLEtBQUssQ0FBQztJQUNqQixDQUFDO0lBRUQ7OztPQUdHO0lBQ0gsMkNBQW9CLEdBQXBCLFVBQXFCLFVBQW9CO1FBQ3JDLElBQUksT0FBTyxVQUFVLEtBQUssV0FBVztZQUFFLFVBQVUsR0FBRyxLQUFLLENBQUM7UUFDMUQsSUFBSSxHQUFHLEdBQVksUUFBUSxDQUFDLGFBQWEsQ0FBQyxPQUFPLENBQUMsQ0FBQztRQUNuRCxJQUFJLFFBQVEsR0FBRyxLQUFLLENBQUM7UUFDckIsSUFBSSxHQUFHLEtBQUssSUFBSSxJQUFJLEdBQUcsQ0FBQyxTQUFTLEtBQUssTUFBTTtZQUFFLFFBQVEsR0FBRyxHQUFHLENBQUMsS0FBSyxDQUFDLENBQUM7UUFFcEUsSUFBSSxVQUFVLEVBQUU7WUFDWixPQUFPLENBQUMsUUFBUSxLQUFLLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQztTQUNsRDthQUNJO1lBQ0QsT0FBTyxRQUFRLENBQUM7U0FDbkI7SUFDTCxDQUFDO0lBRUQsb0NBQWEsR0FBYixVQUFjLFdBQWdCLEVBQUUsUUFBaUIsRUFBRSxLQUFjO1FBQzdELEtBQUssR0FBRyxDQUFDLE9BQU8sS0FBSyxLQUFLLFdBQVcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQztRQUN2RCxLQUFLLEdBQUcsQ0FBQyxLQUFLLEtBQUssSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDO1FBRXpDLElBQUksT0FBTyxHQUFlLCtCQUErQixDQUFDLElBQUksQ0FBQyxTQUFTLEVBQUUsV0FBVyxFQUFFLEtBQUssQ0FBQyxDQUFDO1FBQzlGLElBQUksUUFBUSxLQUFLLElBQUk7WUFBRSxJQUFJLENBQUMsUUFBUSxDQUFDLE9BQU8sRUFBRSxRQUFRLENBQUMsQ0FBQztRQUV4RCxPQUFPLE9BQU8sQ0FBQztJQUNuQixDQUFDO0lBRUQsK0JBQVEsR0FBUixVQUFTLFdBQWdCLEVBQUUsUUFBZ0I7UUFDdkMsUUFBUSxHQUFHLENBQUMsT0FBTyxRQUFRLEtBQUssV0FBVyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDO1FBQzdELElBQUksT0FBTyxHQUFlLFFBQVEsQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLENBQUM7UUFFOUMsS0FBSyxJQUFJLENBQUMsR0FBVyxDQUFDLEVBQUUsQ0FBQyxHQUFHLE9BQU8sQ0FBQyxNQUFNLEVBQUUsQ0FBQyxFQUFFLEVBQUU7WUFDN0MsMkJBQTJCO1lBQzNCLElBQUksT0FBTyxDQUFDLENBQUMsQ0FBQyxLQUFLLEVBQUU7Z0JBQUUsU0FBUztZQUNoQyxJQUFJLENBQUMsZUFBZSxDQUFDLFdBQVcsRUFBRSxPQUFPLENBQUMsQ0FBQyxDQUFDLEVBQUUsSUFBSSxDQUFDLENBQUM7U0FDdkQ7SUFDTCxDQUFDO0lBRUQsa0NBQVcsR0FBWCxVQUFZLFdBQWdCLEVBQUUsUUFBZ0I7UUFDMUMsUUFBUSxHQUFHLENBQUMsT0FBTyxRQUFRLEtBQUssV0FBVyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDO1FBQzdELElBQUksT0FBTyxHQUFlLFFBQVEsQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLENBQUM7UUFFOUMsS0FBSyxJQUFJLENBQUMsR0FBVyxDQUFDLEVBQUUsQ0FBQyxHQUFHLE9BQU8sQ0FBQyxNQUFNLEVBQUUsQ0FBQyxFQUFFLEVBQUU7WUFDN0MsMkJBQTJCO1lBQzNCLElBQUksQ0FBQyxlQUFlLENBQUMsV0FBVyxFQUFFLE9BQU8sQ0FBQyxDQUFDLENBQUMsRUFBRSxLQUFLLENBQUMsQ0FBQztTQUN4RDtJQUNMLENBQUM7SUFFRCxtQ0FBWSxHQUFaLFVBQWEsV0FBZ0IsRUFBRSxVQUFrQixFQUFFLGVBQXVCO1FBQ3RFLHFDQUFxQyxDQUFDLElBQUksQ0FBQyxTQUFTLEVBQUUsV0FBVyxFQUFFLFVBQVUsRUFBRSxlQUFlLENBQUMsQ0FBQztJQUNwRyxDQUFDO0lBRUQsc0NBQWUsR0FBZixVQUFnQixXQUFnQixFQUFFLE1BQWMsRUFBRSxJQUFhO1FBQzNELElBQUksQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxRQUFRLENBQUMsV0FBVyxFQUFFLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLFdBQVcsQ0FBQyxXQUFXLEVBQUUsTUFBTSxDQUFDLENBQUM7SUFDMUcsQ0FBQztJQUVELHNDQUFlLEdBQWYsVUFBZ0IsV0FBZ0IsRUFBRSxVQUFrQixFQUFFLFdBQW1CO1FBQ3JFLElBQUksQ0FBQyxTQUFTLENBQUMsUUFBUSxDQUFDLFdBQVcsRUFBRSxVQUFVLEVBQUUsV0FBVyxDQUFDLENBQUM7UUFDOUQsT0FBTyxXQUFXLENBQUM7SUFDdkIsQ0FBQztJQUVELDBDQUFtQixHQUFuQixVQUFvQixXQUFnQixFQUFFLFdBQW1CLEVBQUUsSUFBWTtRQUNsRSxXQUFtQixDQUFDLFdBQVcsQ0FBQyxDQUFDLEtBQUssQ0FBQyxXQUFXLEVBQUUsSUFBSSxDQUFDLENBQUM7SUFDL0QsQ0FBQztJQUVEOzs7Ozs7T0FNRztJQUNILDJDQUFvQixHQUFwQixVQUFxQixNQUFjLEVBQUUsY0FBNEI7UUFDN0QsSUFBSSxhQUFhLEdBQUcsQ0FBQyxPQUFPLGNBQWMsS0FBSyxXQUFXLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxjQUFjLENBQUM7UUFDeEYsSUFBSSxVQUFVLEdBQUcsYUFBYSxDQUFDLGFBQWEsQ0FBQyxNQUFNLENBQUMsQ0FBQztRQUNyRCxJQUFJLFVBQVUsS0FBSyxJQUFJLEVBQUU7WUFDckIsVUFBVSxDQUFDLGFBQWEsQ0FBQyxXQUFXLENBQUMsVUFBVSxDQUFDLENBQUM7U0FDcEQ7SUFDTCxDQUFDO0lBRUQ7Ozs7T0FJRztJQUNILG1DQUFZLEdBQVosVUFBYSxNQUFjO1FBQ3ZCLElBQUksU0FBUyxHQUFXLE1BQU0sQ0FBQztRQUMvQixJQUFJLFlBQVksR0FBWSxNQUFNLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDO1FBRXZELElBQUksT0FBTyxNQUFNLEtBQUssV0FBVyxJQUFJLE1BQU0sS0FBSyxFQUFFLElBQUksQ0FBQyxZQUFZO1lBQUUsT0FBTyxTQUFTLENBQUM7UUFDdEYsaURBQWlEO1FBQ2pELElBQUksT0FBTyxHQUFlLE1BQU0sQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLENBQUM7UUFDNUMsSUFBSSxPQUFPLENBQUMsQ0FBQyxDQUFDLEtBQUssSUFBSTtZQUFFLFNBQVMsR0FBRyxLQUFLLEdBQUcsU0FBUyxDQUFDO1FBQ3ZELE9BQU8sU0FBUyxDQUFDO0lBQ3JCLENBQUM7O2dCQWpJc0IsU0FBUzs7O0lBRnZCLFlBQVk7UUFIeEIsVUFBVSxDQUFDO1lBQ1IsVUFBVSxFQUFFLE1BQU07U0FDckIsQ0FBQzt5Q0FHeUIsU0FBUztPQUZ2QixZQUFZLENBb0l4Qjt1QkF6SUQ7Q0F5SUMsQUFwSUQsSUFvSUM7U0FwSVksWUFBWTtBQXdJekIsU0FBUyxnQ0FBZ0MsQ0FBQyxJQUFnQztJQUN0RSxJQUFJLElBQUksQ0FBQyxDQUFDLENBQUMsS0FBSyxHQUFHLEVBQUU7UUFDakIsSUFBTSxLQUFLLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQyxpQkFBaUIsQ0FBQyxDQUFDO1FBQzVDLE9BQU8sQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLEVBQUUsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7S0FDL0I7SUFDRCxPQUFPLENBQUMsRUFBRSxFQUFFLElBQUksQ0FBQyxDQUFDO0FBQ3RCLENBQUM7QUFFRCxTQUFTLCtCQUErQixDQUFDLFFBQW9DLEVBQUUsTUFBa0MsRUFBRSxnQkFBNEM7SUFDckosSUFBQSxrRUFBc0UsRUFBckUsaUJBQVMsRUFBRSxZQUEwRCxDQUFDO0lBQzdFLElBQU0sSUFBSSxHQUFHLFFBQVEsQ0FBQyxhQUFhLENBQUMsSUFBSSxFQUFFLFNBQVMsQ0FBQyxDQUFDO0lBQ3JELElBQUksTUFBTSxFQUFFO1FBQ1IsUUFBUSxDQUFDLFdBQVcsQ0FBQyxNQUFNLEVBQUUsSUFBSSxDQUFDLENBQUM7S0FDdEM7SUFDRCxPQUFPLElBQUksQ0FBQztBQUNoQixDQUFDO0FBRUQsU0FBUyxxQ0FBcUMsQ0FBQyxRQUFvQyxFQUFFLE9BQW1DLEVBQUUsZ0JBQTRDLEVBQUUsS0FBa0M7SUFDaE0sSUFBQSxrRUFBc0UsRUFBckUsaUJBQVMsRUFBRSxZQUEwRCxDQUFDO0lBQzdFLElBQUksS0FBSyxJQUFJLElBQUksRUFBRTtRQUNmLFFBQVEsQ0FBQyxZQUFZLENBQUMsT0FBTyxFQUFFLElBQUksRUFBRSxLQUFLLEVBQUUsU0FBUyxDQUFDLENBQUM7S0FDMUQ7U0FDSTtRQUNELFFBQVEsQ0FBQyxlQUFlLENBQUMsT0FBTyxFQUFFLElBQUksRUFBRSxTQUFTLENBQUMsQ0FBQztLQUN0RDtBQUNMLENBQUMiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBJbmplY3RhYmxlLCBFbGVtZW50UmVmLCBSZW5kZXJlcjIgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcclxuXHJcbkBJbmplY3RhYmxlKHtcclxuICAgIHByb3ZpZGVkSW46ICdyb290J1xyXG59KVxyXG5leHBvcnQgY2xhc3MgS2REb21FbGVtU3ZjIHtcclxuICAgIGNvbnN0cnVjdG9yKFxyXG4gICAgICAgIHByaXZhdGUgX3JlbmRlcmVyOiBSZW5kZXJlcjJcclxuICAgICkgeyB9XHJcblxyXG4gICAgaXNNb2JpbGUoKTogYm9vbGVhbiB7XHJcbiAgICAgICAgcmV0dXJuICh3aW5kb3cuaW5uZXJXaWR0aCA+IDEwMjQpID8gZmFsc2UgOiB0cnVlO1xyXG4gICAgfVxyXG5cclxuICAgIGlzTW9iaWxlRGV2aWNlKCk6IGJvb2xlYW4ge1xyXG4gICAgICAgIGxldCB1YTogc3RyaW5nID0gbmF2aWdhdG9yLnVzZXJBZ2VudC50b0xvd2VyQ2FzZSgpO1xyXG4gICAgICAgIHJldHVybiAvYW5kcm9pZHx3ZWJvc3xpcGhvbmV8aXBhZHxpcG9kfGJsYWNrYmVycnl8aWVtb2JpbGV8b3BlcmEgbWluaXxtb2JpfGoybWUvaS50ZXN0KHVhKTtcclxuICAgIH1cclxuXHJcbiAgICBnZXREb2N1bWVudExhbmcoKTogc3RyaW5nIHtcclxuICAgICAgICByZXR1cm4gZG9jdW1lbnQuZG9jdW1lbnRFbGVtZW50Lmxhbmc7XHJcbiAgICB9XHJcblxyXG4gICAgZ2V0RG9jdW1lbnRUaGVtZSgpOiBzdHJpbmcge1xyXG4gICAgICAgIGxldCB0aGVtZTogc3RyaW5nID0gJ29wZW5lbWlzLXN0eWxlZ3VpZGUnO1xyXG4gICAgICAgIGxldCBib2R5RWxlbTogYW55ID0gZG9jdW1lbnQucXVlcnlTZWxlY3RvcignYm9keVtjbGFzc149XCJvcGVuZW1pcy1cIl0nKTtcclxuICAgICAgICBpZiAoYm9keUVsZW0gIT09IG51bGwpIHtcclxuICAgICAgICAgICAgLy8gY29uc29sZS5sb2coYm9keUVsZW0uY2xhc3NMaXN0KTtcclxuICAgICAgICAgICAgLy8gY29uc29sZS5sb2codGhpcy5lbCk7XHJcblxyXG4gICAgICAgICAgICBmb3IgKGxldCBpOiBudW1iZXIgPSAwOyBpIDwgYm9keUVsZW0uY2xhc3NMaXN0Lmxlbmd0aDsgaSsrKSB7XHJcbiAgICAgICAgICAgICAgICBpZiAoYm9keUVsZW0uY2xhc3NMaXN0W2ldLm1hdGNoKC9eW29wZW5lbWlzXFwtXS8pKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhlbWUgPSBib2R5RWxlbS5jbGFzc0xpc3RbaV07XHJcbiAgICAgICAgICAgICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIHJldHVybiB0aGVtZTtcclxuICAgIH1cclxuXHJcbiAgICAvKipcclxuICAgICAqIFtUbyBnZXQgZG9jdW1lbnQgZGlyZWN0aW9uIGVpdGhlciBMVFIgb3IgUlRMXVxyXG4gICAgICogX2lzRnVsbFN0ciAgICA6IFt3aGV0aGVyIHRvIHJldHVybiBzaG9ydCBmb3JtIGxpa2UgJ2x0cicgb3Igc3RyaW5nICdsZWZ0J11cclxuICAgICAqL1xyXG4gICAgZ2V0RG9jdW1lbnREaXJlY3Rpb24oX2lzRnVsbFN0cj86IGJvb2xlYW4pOiBzdHJpbmcge1xyXG4gICAgICAgIGlmICh0eXBlb2YgX2lzRnVsbFN0ciA9PT0gJ3VuZGVmaW5lZCcpIF9pc0Z1bGxTdHIgPSBmYWxzZTtcclxuICAgICAgICBsZXQgZG9jOiBFbGVtZW50ID0gZG9jdW1lbnQucXVlcnlTZWxlY3RvcignW2Rpcl0nKTtcclxuICAgICAgICBsZXQgc2hvcnREaXIgPSAnbHRyJztcclxuICAgICAgICBpZiAoZG9jICE9PSBudWxsICYmIGRvYy5sb2NhbE5hbWUgPT09ICdodG1sJykgc2hvcnREaXIgPSBkb2NbJ2RpciddO1xyXG5cclxuICAgICAgICBpZiAoX2lzRnVsbFN0cikge1xyXG4gICAgICAgICAgICByZXR1cm4gKHNob3J0RGlyID09PSAnbHRyJykgPyAnbGVmdCcgOiAncmlnaHQnO1xyXG4gICAgICAgIH1cclxuICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgcmV0dXJuIHNob3J0RGlyO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICBjcmVhdGVFbGVtZW50KF9wYXJlbnRFbGVtOiBhbnksIF9jbGFzc2VzPzogc3RyaW5nLCBfbmFtZT86IHN0cmluZyk6IGFueSB7XHJcbiAgICAgICAgX25hbWUgPSAodHlwZW9mIF9uYW1lID09PSAndW5kZWZpbmVkJykgPyAnZGl2JyA6IF9uYW1lO1xyXG4gICAgICAgIF9uYW1lID0gKF9uYW1lID09PSBudWxsKSA/ICdkaXYnIDogX25hbWU7XHJcblxyXG4gICAgICAgIGxldCBuZXdFbGVtOiBFbGVtZW50UmVmID0gX19uZ1JlbmRlcmVyQ3JlYXRlRWxlbWVudEhlbHBlcih0aGlzLl9yZW5kZXJlciwgX3BhcmVudEVsZW0sIF9uYW1lKTtcclxuICAgICAgICBpZiAoX2NsYXNzZXMgIT09IG51bGwpIHRoaXMuYWRkQ2xhc3MobmV3RWxlbSwgX2NsYXNzZXMpO1xyXG5cclxuICAgICAgICByZXR1cm4gbmV3RWxlbTtcclxuICAgIH1cclxuXHJcbiAgICBhZGRDbGFzcyhfdGFyZ2V0RWxlbTogYW55LCBfY2xhc3Nlczogc3RyaW5nKTogdm9pZCB7XHJcbiAgICAgICAgX2NsYXNzZXMgPSAodHlwZW9mIF9jbGFzc2VzID09PSAndW5kZWZpbmVkJykgPyAnJyA6IF9jbGFzc2VzO1xyXG4gICAgICAgIGxldCBjbGFzc2VzOiBBcnJheTxhbnk+ID0gX2NsYXNzZXMuc3BsaXQoJyAnKTtcclxuXHJcbiAgICAgICAgZm9yIChsZXQgaTogbnVtYmVyID0gMDsgaSA8IGNsYXNzZXMubGVuZ3RoOyBpKyspIHtcclxuICAgICAgICAgICAgLy8gY29uc29sZS5sb2coY2xhc3Nlc1tpXSk7XHJcbiAgICAgICAgICAgIGlmIChjbGFzc2VzW2ldID09PSAnJykgY29udGludWU7XHJcbiAgICAgICAgICAgIHRoaXMuc2V0RWxlbWVudENsYXNzKF90YXJnZXRFbGVtLCBjbGFzc2VzW2ldLCB0cnVlKTtcclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgcmVtb3ZlQ2xhc3MoX3RhcmdldEVsZW06IGFueSwgX2NsYXNzZXM6IHN0cmluZyk6IHZvaWQge1xyXG4gICAgICAgIF9jbGFzc2VzID0gKHR5cGVvZiBfY2xhc3NlcyA9PT0gJ3VuZGVmaW5lZCcpID8gJycgOiBfY2xhc3NlcztcclxuICAgICAgICBsZXQgY2xhc3NlczogQXJyYXk8YW55PiA9IF9jbGFzc2VzLnNwbGl0KCcgJyk7XHJcblxyXG4gICAgICAgIGZvciAobGV0IGk6IG51bWJlciA9IDA7IGkgPCBjbGFzc2VzLmxlbmd0aDsgaSsrKSB7XHJcbiAgICAgICAgICAgIC8vIGNvbnNvbGUubG9nKGNsYXNzZXNbaV0pO1xyXG4gICAgICAgICAgICB0aGlzLnNldEVsZW1lbnRDbGFzcyhfdGFyZ2V0RWxlbSwgY2xhc3Nlc1tpXSwgZmFsc2UpO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICBzZXRBdHRyaWJ1dGUoX3RhcmdldEVsZW06IGFueSwgX2F0dHJpYnV0ZTogc3RyaW5nLCBfYXR0cmlidXRlVmFsdWU6IHN0cmluZyk6IHZvaWQge1xyXG4gICAgICAgIF9fbmdSZW5kZXJlclNldEVsZW1lbnRBdHRyaWJ1dGVIZWxwZXIodGhpcy5fcmVuZGVyZXIsIF90YXJnZXRFbGVtLCBfYXR0cmlidXRlLCBfYXR0cmlidXRlVmFsdWUpO1xyXG4gICAgfVxyXG5cclxuICAgIHNldEVsZW1lbnRDbGFzcyhfdGFyZ2V0RWxlbTogYW55LCBfY2xhc3M6IHN0cmluZywgX2FkZDogYm9vbGVhbik6IHZvaWQge1xyXG4gICAgICAgIF9hZGQgPyB0aGlzLl9yZW5kZXJlci5hZGRDbGFzcyhfdGFyZ2V0RWxlbSwgX2NsYXNzKSA6IHRoaXMuX3JlbmRlcmVyLnJlbW92ZUNsYXNzKF90YXJnZXRFbGVtLCBfY2xhc3MpO1xyXG4gICAgfVxyXG5cclxuICAgIHNldEVsZW1lbnRTdHlsZShfdGFyZ2V0RWxlbTogYW55LCBfc2x5bGVOYW1lOiBzdHJpbmcsIF9zdHlsZVZhbHVlOiBzdHJpbmcpOiBhbnkge1xyXG4gICAgICAgIHRoaXMuX3JlbmRlcmVyLnNldFN0eWxlKF90YXJnZXRFbGVtLCBfc2x5bGVOYW1lLCBfc3R5bGVWYWx1ZSk7XHJcbiAgICAgICAgcmV0dXJuIF90YXJnZXRFbGVtO1xyXG4gICAgfVxyXG5cclxuICAgIGludm9rZUVsZW1lbnRNZXRob2QoX3RhcmdldEVsZW06IGFueSwgX21ldGhvZE5hbWU6IHN0cmluZywgX2FyZz86IGFueVtdKTogYW55IHtcclxuICAgICAgICAoX3RhcmdldEVsZW0gYXMgYW55KVtfbWV0aG9kTmFtZV0uYXBwbHkoX3RhcmdldEVsZW0sIF9hcmcpO1xyXG4gICAgfVxyXG5cclxuICAgIC8qKlxyXG4gICAgICogW1RvIHJlbW92ZSBkb20gZWxlbWVudF1cclxuICAgICAqIF9jbGFzcyAgICAgICAgICA6IFtjbGFzcyBvZiB0aGUgaXRlbSB0byBiZSBkZWxldGVkXVxyXG4gICAgICogX2NvbnRhaW5lckVsZW0gIDogW3NwZWNpZnkgYSBjb250YWluZXIgdG8gc2VhcmNoIG9yIHRoZSBkZWxldGUgZWxlbWVudFxyXG4gICAgICogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZS5nID4gdGhpcy5lbGVtZW50Lm5hdGl2ZUVsZW1lbnRcclxuICAgICAqICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGJ5IGRlZmF1bHQgaXQgd2lsbCBzZWFyY2ggdGhlIGVudGlyZSBkb21dXHJcbiAgICAgKi9cclxuICAgIHJlbW92ZUVsZW1lbnRCeUNsYXNzKF9jbGFzczogc3RyaW5nLCBfY29udGFpbmVyRWxlbT86IEhUTUxFbGVtZW50KTogdm9pZCB7XHJcbiAgICAgICAgbGV0IGNvbnRhaW5lckVsZW0gPSAodHlwZW9mIF9jb250YWluZXJFbGVtID09PSAndW5kZWZpbmVkJykgPyBkb2N1bWVudCA6IF9jb250YWluZXJFbGVtO1xyXG4gICAgICAgIGxldCBkZWxldGVFbGVtID0gY29udGFpbmVyRWxlbS5xdWVyeVNlbGVjdG9yKF9jbGFzcyk7XHJcbiAgICAgICAgaWYgKGRlbGV0ZUVsZW0gIT09IG51bGwpIHtcclxuICAgICAgICAgICAgZGVsZXRlRWxlbS5wYXJlbnRFbGVtZW50LnJlbW92ZUNoaWxkKGRlbGV0ZUVsZW0pO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICAvKipcclxuICAgICAqIFRvIGRvIGF1dG8gYXBwZW5kIGZvciBmb250IGljb24uIEZvciBub3cgb25seSBzdXBwb3J0IEZvbnQgQXdlc29tZSB0eXBlXHJcbiAgICAgKiBfY2xhc3MgICAgOiBbY2xhc3MgbmFtZS4gZS5nLiBcImZhIGZhLXVuaXZlcnNpdHlcIiBvciBcImZhLXVuaXZlcnNpdHlcIl1cclxuICAgICAqICAgICAgICAgICAgW2l0IHdpbGwgcmV0dXJuIHdoZXRoZXIgdG8gcHJlcGVuZCB0aGUgYSBjbGFzcyBuYW1lIG9yIG5vdF1cclxuICAgICAqL1xyXG4gICAgc2V0SWNvbkNsYXNzKF9jbGFzczogc3RyaW5nKTogc3RyaW5nIHtcclxuICAgICAgICBsZXQgY2xhc3NOYW1lOiBzdHJpbmcgPSBfY2xhc3M7XHJcbiAgICAgICAgbGV0IGlzU2luZ2xlV29yZDogYm9vbGVhbiA9IF9jbGFzcy5pbmRleE9mKCcgJykgPT09IC0xO1xyXG5cclxuICAgICAgICBpZiAodHlwZW9mIF9jbGFzcyA9PT0gJ3VuZGVmaW5lZCcgfHwgX2NsYXNzID09PSAnJyB8fCAhaXNTaW5nbGVXb3JkKSByZXR1cm4gY2xhc3NOYW1lO1xyXG4gICAgICAgIC8vIE9ubHkgYXBwZW5kIGZvciBmb250LWF3ZXNvbWUgcHJlZml4IGNsYXNzIG5hbWVcclxuICAgICAgICBsZXQgY2xhc3NlczogQXJyYXk8YW55PiA9IF9jbGFzcy5zcGxpdCgnLScpO1xyXG4gICAgICAgIGlmIChjbGFzc2VzWzBdID09PSAnZmEnKSBjbGFzc05hbWUgPSAnZmEgJyArIGNsYXNzTmFtZTtcclxuICAgICAgICByZXR1cm4gY2xhc3NOYW1lO1xyXG4gICAgfVxyXG59XHJcblxyXG50eXBlIEFueUR1cmluZ1JlbmRlcmVyTWlncmF0aW9uID0gYW55O1xyXG5cclxuZnVuY3Rpb24gX19uZ1JlbmRlcmVyU3BsaXROYW1lc3BhY2VIZWxwZXIobmFtZTogQW55RHVyaW5nUmVuZGVyZXJNaWdyYXRpb24pIHtcclxuICAgIGlmIChuYW1lWzBdID09PSBcIjpcIikge1xyXG4gICAgICAgIGNvbnN0IG1hdGNoID0gbmFtZS5tYXRjaCgvXjooW146XSspOiguKykkLyk7XHJcbiAgICAgICAgcmV0dXJuIFttYXRjaFsxXSwgbWF0Y2hbMl1dO1xyXG4gICAgfVxyXG4gICAgcmV0dXJuIFtcIlwiLCBuYW1lXTtcclxufVxyXG5cclxuZnVuY3Rpb24gX19uZ1JlbmRlcmVyQ3JlYXRlRWxlbWVudEhlbHBlcihyZW5kZXJlcjogQW55RHVyaW5nUmVuZGVyZXJNaWdyYXRpb24sIHBhcmVudDogQW55RHVyaW5nUmVuZGVyZXJNaWdyYXRpb24sIG5hbWVzcGFjZUFuZE5hbWU6IEFueUR1cmluZ1JlbmRlcmVyTWlncmF0aW9uKSB7XHJcbiAgICBjb25zdCBbbmFtZXNwYWNlLCBuYW1lXSA9IF9fbmdSZW5kZXJlclNwbGl0TmFtZXNwYWNlSGVscGVyKG5hbWVzcGFjZUFuZE5hbWUpO1xyXG4gICAgY29uc3Qgbm9kZSA9IHJlbmRlcmVyLmNyZWF0ZUVsZW1lbnQobmFtZSwgbmFtZXNwYWNlKTtcclxuICAgIGlmIChwYXJlbnQpIHtcclxuICAgICAgICByZW5kZXJlci5hcHBlbmRDaGlsZChwYXJlbnQsIG5vZGUpO1xyXG4gICAgfVxyXG4gICAgcmV0dXJuIG5vZGU7XHJcbn1cclxuXHJcbmZ1bmN0aW9uIF9fbmdSZW5kZXJlclNldEVsZW1lbnRBdHRyaWJ1dGVIZWxwZXIocmVuZGVyZXI6IEFueUR1cmluZ1JlbmRlcmVyTWlncmF0aW9uLCBlbGVtZW50OiBBbnlEdXJpbmdSZW5kZXJlck1pZ3JhdGlvbiwgbmFtZXNwYWNlQW5kTmFtZTogQW55RHVyaW5nUmVuZGVyZXJNaWdyYXRpb24sIHZhbHVlPzogQW55RHVyaW5nUmVuZGVyZXJNaWdyYXRpb24pIHtcclxuICAgIGNvbnN0IFtuYW1lc3BhY2UsIG5hbWVdID0gX19uZ1JlbmRlcmVyU3BsaXROYW1lc3BhY2VIZWxwZXIobmFtZXNwYWNlQW5kTmFtZSk7XHJcbiAgICBpZiAodmFsdWUgIT0gbnVsbCkge1xyXG4gICAgICAgIHJlbmRlcmVyLnNldEF0dHJpYnV0ZShlbGVtZW50LCBuYW1lLCB2YWx1ZSwgbmFtZXNwYWNlKTtcclxuICAgIH1cclxuICAgIGVsc2Uge1xyXG4gICAgICAgIHJlbmRlcmVyLnJlbW92ZUF0dHJpYnV0ZShlbGVtZW50LCBuYW1lLCBuYW1lc3BhY2UpO1xyXG4gICAgfVxyXG59XHJcbiJdfQ==