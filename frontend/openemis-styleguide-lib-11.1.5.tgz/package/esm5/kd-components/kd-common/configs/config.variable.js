/*******************************************************************************
    File: config.variable.ts
    Version: 1.0
    Purpose: General variables usage for kd-component libraries

    Last change:
        -

 ******************************************************************************/
// Standard delay timing for all components
export var DELAY_TIME = 300;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiY29uZmlnLnZhcmlhYmxlLmpzIiwic291cmNlUm9vdCI6Im5nOi8vb3BlbmVtaXMtc3R5bGVndWlkZS1saWIvIiwic291cmNlcyI6WyJrZC1jb21wb25lbnRzL2tkLWNvbW1vbi9jb25maWdzL2NvbmZpZy52YXJpYWJsZS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTs7Ozs7Ozs7Z0ZBUWdGO0FBRWhGLDJDQUEyQztBQUMzQyxNQUFNLENBQUMsSUFBTSxVQUFVLEdBQVcsR0FBRyxDQUFDIiwic291cmNlc0NvbnRlbnQiOlsiLyoqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKipcclxuXHRGaWxlOiBjb25maWcudmFyaWFibGUudHNcclxuXHRWZXJzaW9uOiAxLjBcclxuXHRQdXJwb3NlOiBHZW5lcmFsIHZhcmlhYmxlcyB1c2FnZSBmb3Iga2QtY29tcG9uZW50IGxpYnJhcmllc1xyXG5cclxuXHRMYXN0IGNoYW5nZTpcclxuXHRcdC1cclxuXHJcbiAqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKiovXHJcblxyXG4vLyBTdGFuZGFyZCBkZWxheSB0aW1pbmcgZm9yIGFsbCBjb21wb25lbnRzXHJcbmV4cG9ydCBjb25zdCBERUxBWV9USU1FOiBudW1iZXIgPSAzMDA7XHJcbiJdfQ==