import { __decorate } from "tslib";
import { Injectable } from '@angular/core';
import * as i0 from "@angular/core";
var KdDataSvc = /** @class */ (function () {
    function KdDataSvc() {
    }
    KdDataSvc.prototype.getDataValue = function (_fromObject, _key) {
        var splitArray = _key.split('.');
        var data = _fromObject;
        if (typeof data === 'undefined' || data === null)
            return null;
        for (var i = 0; i < splitArray.length; i++) {
            if (data.hasOwnProperty(splitArray[i]))
                data = data[splitArray[i]];
            else
                return null;
        }
        return data;
    };
    KdDataSvc.prototype.getPlaceholder = function (_fromObject, _queryString) {
        var updatedString = _queryString.slice();
        var search = _queryString.match(/\$\((.*?)\)/g);
        if (search !== null) {
            for (var i = 0; i < search.length; i++) {
                var searchString = search[i].substring(2, search[i].length - 1);
                var replacedString = this.getDataValue(_fromObject, searchString);
                if (replacedString !== null) {
                    updatedString = updatedString.replace(search[i], replacedString);
                }
            }
        }
        return updatedString;
    };
    /**
     * [deepMergeObject]
     * target        : merge to
     * source        : merge from
     * _returnNewObj : by default is true. It will return a new object. If is false, it will do a direct merge/combine
     *                 a new object. (Optional)
     */
    KdDataSvc.prototype.deepMergeObject = function (target, source, _returnNewObj) {
        var _a, _b;
        var output = {};
        _returnNewObj = (typeof _returnNewObj === 'undefined') ? true : _returnNewObj;
        output = (_returnNewObj) ? Object.assign({}, target) : target;
        for (var key in source) {
            if (key in output) {
                if (output[key] && typeof output[key] === 'object' && !Array.isArray(output[key])) {
                    output[key] = typeof source[key] !== 'object' ? source[key] : this.deepMergeObject(output[key], source[key]);
                }
                else {
                    Object.assign(output, (_a = {}, _a[key] = source[key], _a));
                }
            }
            else {
                Object.assign(output, (_b = {}, _b[key] = source[key], _b));
            }
        }
        if (_returnNewObj)
            return output;
    };
    /**
     * combines the source to the target, changing target's key values directly. source key values takes proprioty
     * target        : merge to
     * source        : merge from
     */
    KdDataSvc.prototype.deepCombineObject = function (target, source) {
        var _a;
        for (var key in source) {
            if (source[key] && typeof source[key] === 'object') {
                if (target[key] && typeof target[key] === 'object' && key in target) {
                    this.deepCombineObject(target[key], source[key]);
                }
                else {
                    Object.assign(target, (_a = {}, _a[key] = source[key], _a));
                }
            }
            else {
                target[key] = source[key];
            }
        }
    };
    KdDataSvc.ɵprov = i0.ɵɵdefineInjectable({ factory: function KdDataSvc_Factory() { return new KdDataSvc(); }, token: KdDataSvc, providedIn: "root" });
    KdDataSvc = __decorate([
        Injectable({
            providedIn: 'root'
        })
    ], KdDataSvc);
    return KdDataSvc;
}());
export { KdDataSvc };
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoia2QtZGF0YS1zdmMuanMiLCJzb3VyY2VSb290Ijoibmc6Ly9vcGVuZW1pcy1zdHlsZWd1aWRlLWxpYi8iLCJzb3VyY2VzIjpbImtkLWNvbXBvbmVudHMva2QtY29tbW9uL2tkLWRhdGEtc3ZjLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7QUFBQSxPQUFPLEVBQUUsVUFBVSxFQUFFLE1BQU0sZUFBZSxDQUFDOztBQUszQztJQUFBO0tBdUVDO0lBdEVHLGdDQUFZLEdBQVosVUFBYSxXQUFnQixFQUFFLElBQVk7UUFDdkMsSUFBSSxVQUFVLEdBQWUsSUFBSSxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FBQztRQUM3QyxJQUFJLElBQUksR0FBUSxXQUFXLENBQUM7UUFDNUIsSUFBSSxPQUFPLElBQUksS0FBSyxXQUFXLElBQUksSUFBSSxLQUFLLElBQUk7WUFBRSxPQUFPLElBQUksQ0FBQztRQUM5RCxLQUFLLElBQUksQ0FBQyxHQUFXLENBQUMsRUFBRSxDQUFDLEdBQUcsVUFBVSxDQUFDLE1BQU0sRUFBRSxDQUFDLEVBQUUsRUFBRTtZQUNoRCxJQUFJLElBQUksQ0FBQyxjQUFjLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQyxDQUFDO2dCQUFFLElBQUksR0FBRyxJQUFJLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7O2dCQUM5RCxPQUFPLElBQUksQ0FBQztTQUNwQjtRQUNELE9BQU8sSUFBSSxDQUFDO0lBQ2hCLENBQUM7SUFFRCxrQ0FBYyxHQUFkLFVBQWUsV0FBZ0IsRUFBRSxZQUFvQjtRQUNqRCxJQUFJLGFBQWEsR0FBVyxZQUFZLENBQUMsS0FBSyxFQUFFLENBQUM7UUFDakQsSUFBSSxNQUFNLEdBQWtCLFlBQVksQ0FBQyxLQUFLLENBQUMsY0FBYyxDQUFDLENBQUM7UUFDL0QsSUFBSSxNQUFNLEtBQUssSUFBSSxFQUFFO1lBQ2pCLEtBQUssSUFBSSxDQUFDLEdBQVcsQ0FBQyxFQUFFLENBQUMsR0FBRyxNQUFNLENBQUMsTUFBTSxFQUFFLENBQUMsRUFBRSxFQUFFO2dCQUM1QyxJQUFJLFlBQVksR0FBVyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDLENBQUMsRUFBRSxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxHQUFHLENBQUMsQ0FBQyxDQUFDO2dCQUN4RSxJQUFJLGNBQWMsR0FBVyxJQUFJLENBQUMsWUFBWSxDQUFDLFdBQVcsRUFBRSxZQUFZLENBQUMsQ0FBQztnQkFDMUUsSUFBSSxjQUFjLEtBQUssSUFBSSxFQUFFO29CQUN6QixhQUFhLEdBQUcsYUFBYSxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLEVBQUUsY0FBYyxDQUFDLENBQUM7aUJBQ3BFO2FBQ0o7U0FDSjtRQUNELE9BQU8sYUFBYSxDQUFDO0lBQ3pCLENBQUM7SUFFRDs7Ozs7O09BTUc7SUFDSCxtQ0FBZSxHQUFmLFVBQWdCLE1BQVcsRUFBRSxNQUFXLEVBQUUsYUFBdUI7O1FBQzdELElBQUksTUFBTSxHQUFRLEVBQUUsQ0FBQztRQUNyQixhQUFhLEdBQUcsQ0FBQyxPQUFPLGFBQWEsS0FBSyxXQUFXLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxhQUFhLENBQUM7UUFDOUUsTUFBTSxHQUFHLENBQUMsYUFBYSxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsRUFBRSxFQUFFLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUM7UUFFOUQsS0FBSyxJQUFJLEdBQUcsSUFBSSxNQUFNLEVBQUU7WUFDcEIsSUFBSSxHQUFHLElBQUksTUFBTSxFQUFFO2dCQUNmLElBQUksTUFBTSxDQUFDLEdBQUcsQ0FBQyxJQUFJLE9BQU8sTUFBTSxDQUFDLEdBQUcsQ0FBQyxLQUFLLFFBQVEsSUFBSSxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDLEVBQUU7b0JBQy9FLE1BQU0sQ0FBQyxHQUFHLENBQUMsR0FBRyxPQUFPLE1BQU0sQ0FBQyxHQUFHLENBQUMsS0FBSyxRQUFRLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLGVBQWUsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLEVBQUUsTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUM7aUJBQ2hIO3FCQUFNO29CQUNILE1BQU0sQ0FBQyxNQUFNLENBQUMsTUFBTSxZQUFJLEdBQUMsR0FBRyxJQUFHLE1BQU0sQ0FBQyxHQUFHLENBQUMsTUFBRyxDQUFDO2lCQUNqRDthQUNKO2lCQUFNO2dCQUNILE1BQU0sQ0FBQyxNQUFNLENBQUMsTUFBTSxZQUFJLEdBQUMsR0FBRyxJQUFHLE1BQU0sQ0FBQyxHQUFHLENBQUMsTUFBRyxDQUFDO2FBQ2pEO1NBQ0o7UUFDRCxJQUFJLGFBQWE7WUFBRSxPQUFPLE1BQU0sQ0FBQztJQUNyQyxDQUFDO0lBRUQ7Ozs7T0FJRztJQUNILHFDQUFpQixHQUFqQixVQUFrQixNQUFXLEVBQUUsTUFBVzs7UUFDdEMsS0FBSyxJQUFJLEdBQUcsSUFBSSxNQUFNLEVBQUU7WUFDcEIsSUFBSSxNQUFNLENBQUMsR0FBRyxDQUFDLElBQUksT0FBTyxNQUFNLENBQUMsR0FBRyxDQUFDLEtBQUssUUFBUSxFQUFFO2dCQUNoRCxJQUFJLE1BQU0sQ0FBQyxHQUFHLENBQUMsSUFBSSxPQUFPLE1BQU0sQ0FBQyxHQUFHLENBQUMsS0FBSyxRQUFRLElBQUksR0FBRyxJQUFJLE1BQU0sRUFBRTtvQkFDakUsSUFBSSxDQUFDLGlCQUFpQixDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsRUFBRSxNQUFNLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQztpQkFDcEQ7cUJBQU07b0JBQ0gsTUFBTSxDQUFDLE1BQU0sQ0FBQyxNQUFNLFlBQUksR0FBQyxHQUFHLElBQUcsTUFBTSxDQUFDLEdBQUcsQ0FBQyxNQUFHLENBQUM7aUJBQ2pEO2FBQ0o7aUJBQU07Z0JBQ0gsTUFBTSxDQUFDLEdBQUcsQ0FBQyxHQUFHLE1BQU0sQ0FBQyxHQUFHLENBQUMsQ0FBQzthQUM3QjtTQUNKO0lBQ0wsQ0FBQzs7SUF0RVEsU0FBUztRQUhyQixVQUFVLENBQUM7WUFDUixVQUFVLEVBQUUsTUFBTTtTQUNyQixDQUFDO09BQ1csU0FBUyxDQXVFckI7b0JBNUVEO0NBNEVDLEFBdkVELElBdUVDO1NBdkVZLFNBQVMiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBJbmplY3RhYmxlIH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XHJcblxyXG5ASW5qZWN0YWJsZSh7XHJcbiAgICBwcm92aWRlZEluOiAncm9vdCdcclxufSlcclxuZXhwb3J0IGNsYXNzIEtkRGF0YVN2YyB7XHJcbiAgICBnZXREYXRhVmFsdWUoX2Zyb21PYmplY3Q6IGFueSwgX2tleTogc3RyaW5nKTogYW55IHtcclxuICAgICAgICBsZXQgc3BsaXRBcnJheTogQXJyYXk8YW55PiA9IF9rZXkuc3BsaXQoJy4nKTtcclxuICAgICAgICBsZXQgZGF0YTogYW55ID0gX2Zyb21PYmplY3Q7XHJcbiAgICAgICAgaWYgKHR5cGVvZiBkYXRhID09PSAndW5kZWZpbmVkJyB8fCBkYXRhID09PSBudWxsKSByZXR1cm4gbnVsbDtcclxuICAgICAgICBmb3IgKGxldCBpOiBudW1iZXIgPSAwOyBpIDwgc3BsaXRBcnJheS5sZW5ndGg7IGkrKykge1xyXG4gICAgICAgICAgICBpZiAoZGF0YS5oYXNPd25Qcm9wZXJ0eShzcGxpdEFycmF5W2ldKSkgZGF0YSA9IGRhdGFbc3BsaXRBcnJheVtpXV07XHJcbiAgICAgICAgICAgIGVsc2UgcmV0dXJuIG51bGw7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIHJldHVybiBkYXRhO1xyXG4gICAgfVxyXG5cclxuICAgIGdldFBsYWNlaG9sZGVyKF9mcm9tT2JqZWN0OiBhbnksIF9xdWVyeVN0cmluZzogc3RyaW5nKTogYW55IHtcclxuICAgICAgICBsZXQgdXBkYXRlZFN0cmluZzogc3RyaW5nID0gX3F1ZXJ5U3RyaW5nLnNsaWNlKCk7XHJcbiAgICAgICAgbGV0IHNlYXJjaDogQXJyYXk8c3RyaW5nPiA9IF9xdWVyeVN0cmluZy5tYXRjaCgvXFwkXFwoKC4qPylcXCkvZyk7XHJcbiAgICAgICAgaWYgKHNlYXJjaCAhPT0gbnVsbCkge1xyXG4gICAgICAgICAgICBmb3IgKGxldCBpOiBudW1iZXIgPSAwOyBpIDwgc2VhcmNoLmxlbmd0aDsgaSsrKSB7XHJcbiAgICAgICAgICAgICAgICBsZXQgc2VhcmNoU3RyaW5nOiBzdHJpbmcgPSBzZWFyY2hbaV0uc3Vic3RyaW5nKDIsIHNlYXJjaFtpXS5sZW5ndGggLSAxKTtcclxuICAgICAgICAgICAgICAgIGxldCByZXBsYWNlZFN0cmluZzogc3RyaW5nID0gdGhpcy5nZXREYXRhVmFsdWUoX2Zyb21PYmplY3QsIHNlYXJjaFN0cmluZyk7XHJcbiAgICAgICAgICAgICAgICBpZiAocmVwbGFjZWRTdHJpbmcgIT09IG51bGwpIHtcclxuICAgICAgICAgICAgICAgICAgICB1cGRhdGVkU3RyaW5nID0gdXBkYXRlZFN0cmluZy5yZXBsYWNlKHNlYXJjaFtpXSwgcmVwbGFjZWRTdHJpbmcpO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgICAgIHJldHVybiB1cGRhdGVkU3RyaW5nO1xyXG4gICAgfVxyXG5cclxuICAgIC8qKlxyXG4gICAgICogW2RlZXBNZXJnZU9iamVjdF1cclxuICAgICAqIHRhcmdldCAgICAgICAgOiBtZXJnZSB0b1xyXG4gICAgICogc291cmNlICAgICAgICA6IG1lcmdlIGZyb21cclxuICAgICAqIF9yZXR1cm5OZXdPYmogOiBieSBkZWZhdWx0IGlzIHRydWUuIEl0IHdpbGwgcmV0dXJuIGEgbmV3IG9iamVjdC4gSWYgaXMgZmFsc2UsIGl0IHdpbGwgZG8gYSBkaXJlY3QgbWVyZ2UvY29tYmluZVxyXG4gICAgICogICAgICAgICAgICAgICAgIGEgbmV3IG9iamVjdC4gKE9wdGlvbmFsKVxyXG4gICAgICovXHJcbiAgICBkZWVwTWVyZ2VPYmplY3QodGFyZ2V0OiBhbnksIHNvdXJjZTogYW55LCBfcmV0dXJuTmV3T2JqPzogYm9vbGVhbik6IGFueSB7XHJcbiAgICAgICAgbGV0IG91dHB1dDogYW55ID0ge307XHJcbiAgICAgICAgX3JldHVybk5ld09iaiA9ICh0eXBlb2YgX3JldHVybk5ld09iaiA9PT0gJ3VuZGVmaW5lZCcpID8gdHJ1ZSA6IF9yZXR1cm5OZXdPYmo7XHJcbiAgICAgICAgb3V0cHV0ID0gKF9yZXR1cm5OZXdPYmopID8gT2JqZWN0LmFzc2lnbih7fSwgdGFyZ2V0KSA6IHRhcmdldDtcclxuXHJcbiAgICAgICAgZm9yIChsZXQga2V5IGluIHNvdXJjZSkge1xyXG4gICAgICAgICAgICBpZiAoa2V5IGluIG91dHB1dCkge1xyXG4gICAgICAgICAgICAgICAgaWYgKG91dHB1dFtrZXldICYmIHR5cGVvZiBvdXRwdXRba2V5XSA9PT0gJ29iamVjdCcgJiYgIUFycmF5LmlzQXJyYXkob3V0cHV0W2tleV0pKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgb3V0cHV0W2tleV0gPSB0eXBlb2Ygc291cmNlW2tleV0gIT09ICdvYmplY3QnID8gc291cmNlW2tleV0gOiB0aGlzLmRlZXBNZXJnZU9iamVjdChvdXRwdXRba2V5XSwgc291cmNlW2tleV0pO1xyXG4gICAgICAgICAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgICAgICAgICBPYmplY3QuYXNzaWduKG91dHB1dCwgeyBba2V5XTogc291cmNlW2tleV0gfSk7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgICAgICBPYmplY3QuYXNzaWduKG91dHB1dCwgeyBba2V5XTogc291cmNlW2tleV0gfSk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICAgICAgaWYgKF9yZXR1cm5OZXdPYmopIHJldHVybiBvdXRwdXQ7XHJcbiAgICB9XHJcblxyXG4gICAgLyoqXHJcbiAgICAgKiBjb21iaW5lcyB0aGUgc291cmNlIHRvIHRoZSB0YXJnZXQsIGNoYW5naW5nIHRhcmdldCdzIGtleSB2YWx1ZXMgZGlyZWN0bHkuIHNvdXJjZSBrZXkgdmFsdWVzIHRha2VzIHByb3ByaW90eVxyXG4gICAgICogdGFyZ2V0ICAgICAgICA6IG1lcmdlIHRvXHJcbiAgICAgKiBzb3VyY2UgICAgICAgIDogbWVyZ2UgZnJvbVxyXG4gICAgICovXHJcbiAgICBkZWVwQ29tYmluZU9iamVjdCh0YXJnZXQ6IGFueSwgc291cmNlOiBhbnkpOiB2b2lkIHtcclxuICAgICAgICBmb3IgKGxldCBrZXkgaW4gc291cmNlKSB7XHJcbiAgICAgICAgICAgIGlmIChzb3VyY2Vba2V5XSAmJiB0eXBlb2Ygc291cmNlW2tleV0gPT09ICdvYmplY3QnKSB7XHJcbiAgICAgICAgICAgICAgICBpZiAodGFyZ2V0W2tleV0gJiYgdHlwZW9mIHRhcmdldFtrZXldID09PSAnb2JqZWN0JyAmJiBrZXkgaW4gdGFyZ2V0KSB7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5kZWVwQ29tYmluZU9iamVjdCh0YXJnZXRba2V5XSwgc291cmNlW2tleV0pO1xyXG4gICAgICAgICAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgICAgICAgICBPYmplY3QuYXNzaWduKHRhcmdldCwgeyBba2V5XTogc291cmNlW2tleV0gfSk7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgICAgICB0YXJnZXRba2V5XSA9IHNvdXJjZVtrZXldO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG59XHJcbiJdfQ==