import { __decorate, __metadata } from "tslib";
import { Injectable } from '@angular/core';
import { ElementRef } from '@angular/core';
/**
* Wizard v.1.0.0
* created by: Grace Pek
* created on: 12 Dec 2017
* plugins: primeng tooltip
*
* functions:
*     public
*         - setItem
*            purpose: set active/disable, icons and tooltip's HTML string
*         - setContainerAndStepElement
*         - translateViewToClickedElem
*         - isStepOutOfBounds
*     private
*         - setWidthInfo
*             purpose: store container and each steps's width for translation calculation
*         - setTooltipString
*         - getWindowScrollLeft
*/
var KdWizardSvc = /** @class */ (function () {
    function KdWizardSvc(_elementRef) {
        this._elementRef = _elementRef;
    }
    Object.defineProperty(KdWizardSvc.prototype, "direction", {
        set: function (_direction) {
            this._direction = _direction;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(KdWizardSvc.prototype, "totalSteps", {
        set: function (_totalSteps) {
            this._totalSteps = _totalSteps;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(KdWizardSvc.prototype, "containerWidth", {
        get: function () {
            return this._containerWidth;
        },
        enumerable: true,
        configurable: true
    });
    KdWizardSvc.prototype.setItem = function (_items) {
        var items = [];
        for (var i = 0; i < _items.length; ++i) {
            var item = Object.assign({}, _items[i], {
                id: i,
                isActive: i === 0 ? true : false,
                isDisabled: i === 0 ? false : true,
                icon: _items[i].icon ? _items[i].icon : i + 1,
                iconType: _items[i].icon ? 'icon' : 'number',
                tooltipString: this._setTooltipString(_items[i])
            });
            items.push(item);
        }
        return items;
    };
    KdWizardSvc.prototype.setContainerAndStepElement = function (_id) {
        this._innerWrapperEle = this._elementRef.nativeElement.querySelector('#' + _id + ' .kdx-wizard-inner-wrapper');
        this._stepEle = this._elementRef.nativeElement.querySelector('#' + _id + ' .kdx-wizard-step-selected');
        this._containerEle = this._elementRef.nativeElement.querySelector('#' + _id + ' .kdx-wizard-steps-container');
    };
    KdWizardSvc.prototype.translateViewToClickedElem = function (_activeStep) {
        this._setWidthInfo();
        var moveXValue = (_activeStep.id * this._stepWidth - this._containerWidth / 2 + this._stepWidth / 2) * -1;
        if (this._direction === 'right') {
            moveXValue = -1 * moveXValue;
            if (moveXValue < 0) {
                moveXValue = 0;
            }
            if (moveXValue > (this._totalSteps * this._stepWidth - this._containerWidth)) {
                moveXValue = this._totalSteps * this._stepWidth - this._containerWidth;
            }
        }
        else {
            if (moveXValue > 0) {
                moveXValue = 0;
            }
            if (moveXValue < (this._totalSteps * this._stepWidth - this._containerWidth) * -1) {
                moveXValue = (this._totalSteps * this._stepWidth - this._containerWidth) * -1;
            }
        }
        this._translateXValue = Math.floor(moveXValue).toString();
        this._innerWrapperEle.style.transform = 'translateX(' + this._translateXValue + 'px)';
    };
    /* if description texts are within the bounds of .steps-container, then show tooltip */
    KdWizardSvc.prototype.isStepOutOfBounds = function (event) {
        var targetLeft = event.target.getBoundingClientRect().left + this._getWindowScrollLeft();
        var containerRect = this._containerEle.getBoundingClientRect();
        var containerLeft = Math.floor(containerRect.left + this._getWindowScrollLeft());
        if (targetLeft + event.target.offsetWidth > containerLeft + containerRect.width)
            return true;
        if (targetLeft < containerLeft)
            return true;
        return false;
    };
    KdWizardSvc.prototype._setWidthInfo = function () {
        this._stepWidth = this._stepEle.clientWidth;
        this._containerWidth = this._innerWrapperEle.clientWidth;
    };
    KdWizardSvc.prototype._setTooltipString = function (_step) {
        var description = _step.description ? '<div class="tooltip-description">' + _step.description + '</div>' : '';
        return "<div class=\"tooltip-wizard-text\">\n                    <div class=\"tooltip-label\">" + _step.label + "</div>"
            + description +
            '</div>';
    };
    KdWizardSvc.prototype._getWindowScrollLeft = function () {
        var doc = document.documentElement;
        return (window.pageXOffset || doc.scrollLeft) - (doc.clientLeft || 0);
    };
    KdWizardSvc.ctorParameters = function () { return [
        { type: ElementRef }
    ]; };
    KdWizardSvc = __decorate([
        Injectable(),
        __metadata("design:paramtypes", [ElementRef])
    ], KdWizardSvc);
    return KdWizardSvc;
}());
export { KdWizardSvc };
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoia2QtYW5ndWxhci13aXphcmQtc3ZjLmpzIiwic291cmNlUm9vdCI6Im5nOi8vb3BlbmVtaXMtc3R5bGVndWlkZS1saWIvIiwic291cmNlcyI6WyJrZC1jb21wb25lbnRzL2tkLWFuZ3VsYXItd2l6YXJkL2tkLWFuZ3VsYXItd2l6YXJkLXN2Yy50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiO0FBQUEsT0FBTyxFQUFFLFVBQVUsRUFBRSxNQUFNLGVBQWUsQ0FBQztBQUUzQyxPQUFPLEVBQUUsVUFBVSxFQUFFLE1BQU0sZUFBZSxDQUFDO0FBRTNDOzs7Ozs7Ozs7Ozs7Ozs7Ozs7RUFrQkU7QUFHRjtJQVdJLHFCQUNZLFdBQXVCO1FBQXZCLGdCQUFXLEdBQVgsV0FBVyxDQUFZO0lBQy9CLENBQUM7SUFFTCxzQkFBSSxrQ0FBUzthQUFiLFVBQWMsVUFBa0I7WUFDNUIsSUFBSSxDQUFDLFVBQVUsR0FBRyxVQUFVLENBQUM7UUFDakMsQ0FBQzs7O09BQUE7SUFFRCxzQkFBSSxtQ0FBVTthQUFkLFVBQWUsV0FBbUI7WUFDOUIsSUFBSSxDQUFDLFdBQVcsR0FBRyxXQUFXLENBQUM7UUFDbkMsQ0FBQzs7O09BQUE7SUFFRCxzQkFBSSx1Q0FBYzthQUFsQjtZQUNJLE9BQU8sSUFBSSxDQUFDLGVBQWUsQ0FBQztRQUNoQyxDQUFDOzs7T0FBQTtJQUVNLDZCQUFPLEdBQWQsVUFBZSxNQUFrQjtRQUM3QixJQUFJLEtBQUssR0FBaUIsRUFBRSxDQUFDO1FBQzdCLEtBQUssSUFBSSxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsR0FBRyxNQUFNLENBQUMsTUFBTSxFQUFFLEVBQUUsQ0FBQyxFQUFFO1lBQ3BDLElBQUksSUFBSSxHQUFHLE1BQU0sQ0FBQyxNQUFNLENBQUMsRUFBRSxFQUFFLE1BQU0sQ0FBQyxDQUFDLENBQUMsRUFBRTtnQkFDcEMsRUFBRSxFQUFFLENBQUM7Z0JBQ0wsUUFBUSxFQUFFLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsS0FBSztnQkFDaEMsVUFBVSxFQUFFLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsSUFBSTtnQkFDbEMsSUFBSSxFQUFFLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDO2dCQUM3QyxRQUFRLEVBQUUsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxRQUFRO2dCQUM1QyxhQUFhLEVBQUUsSUFBSSxDQUFDLGlCQUFpQixDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQzthQUNuRCxDQUFDLENBQUM7WUFDSCxLQUFLLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDO1NBQ3BCO1FBQ0QsT0FBTyxLQUFLLENBQUM7SUFDakIsQ0FBQztJQUVNLGdEQUEwQixHQUFqQyxVQUFrQyxHQUFXO1FBQ3pDLElBQUksQ0FBQyxnQkFBZ0IsR0FBRyxJQUFJLENBQUMsV0FBVyxDQUFDLGFBQWEsQ0FBQyxhQUFhLENBQUMsR0FBRyxHQUFHLEdBQUcsR0FBRyw0QkFBNEIsQ0FBQyxDQUFDO1FBQy9HLElBQUksQ0FBQyxRQUFRLEdBQUcsSUFBSSxDQUFDLFdBQVcsQ0FBQyxhQUFhLENBQUMsYUFBYSxDQUFDLEdBQUcsR0FBRyxHQUFHLEdBQUcsNEJBQTRCLENBQUMsQ0FBQztRQUN2RyxJQUFJLENBQUMsYUFBYSxHQUFHLElBQUksQ0FBQyxXQUFXLENBQUMsYUFBYSxDQUFDLGFBQWEsQ0FBQyxHQUFHLEdBQUcsR0FBRyxHQUFHLDhCQUE4QixDQUFDLENBQUM7SUFDbEgsQ0FBQztJQUVNLGdEQUEwQixHQUFqQyxVQUFrQyxXQUFrQjtRQUVoRCxJQUFJLENBQUMsYUFBYSxFQUFFLENBQUM7UUFFckIsSUFBSSxVQUFVLEdBQVcsQ0FBQyxXQUFXLENBQUMsRUFBRSxHQUFHLElBQUksQ0FBQyxVQUFVLEdBQUcsSUFBSSxDQUFDLGVBQWUsR0FBRyxDQUFDLEdBQUcsSUFBSSxDQUFDLFVBQVUsR0FBRyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQztRQUVsSCxJQUFJLElBQUksQ0FBQyxVQUFVLEtBQUssT0FBTyxFQUFFO1lBQzdCLFVBQVUsR0FBRyxDQUFDLENBQUMsR0FBRyxVQUFVLENBQUM7WUFDN0IsSUFBSSxVQUFVLEdBQUcsQ0FBQyxFQUFFO2dCQUNoQixVQUFVLEdBQUcsQ0FBQyxDQUFDO2FBQ2xCO1lBQ0QsSUFBSSxVQUFVLEdBQUcsQ0FBQyxJQUFJLENBQUMsV0FBVyxHQUFHLElBQUksQ0FBQyxVQUFVLEdBQUcsSUFBSSxDQUFDLGVBQWUsQ0FBQyxFQUFFO2dCQUMxRSxVQUFVLEdBQUcsSUFBSSxDQUFDLFdBQVcsR0FBRyxJQUFJLENBQUMsVUFBVSxHQUFHLElBQUksQ0FBQyxlQUFlLENBQUM7YUFDMUU7U0FDSjthQUFNO1lBQ0gsSUFBSSxVQUFVLEdBQUcsQ0FBQyxFQUFFO2dCQUNoQixVQUFVLEdBQUcsQ0FBQyxDQUFDO2FBQ2xCO1lBQ0QsSUFBSSxVQUFVLEdBQUcsQ0FBQyxJQUFJLENBQUMsV0FBVyxHQUFHLElBQUksQ0FBQyxVQUFVLEdBQUcsSUFBSSxDQUFDLGVBQWUsQ0FBQyxHQUFHLENBQUMsQ0FBQyxFQUFFO2dCQUMvRSxVQUFVLEdBQUcsQ0FBQyxJQUFJLENBQUMsV0FBVyxHQUFHLElBQUksQ0FBQyxVQUFVLEdBQUcsSUFBSSxDQUFDLGVBQWUsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDO2FBQ2pGO1NBQ0o7UUFFRCxJQUFJLENBQUMsZ0JBQWdCLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQyxVQUFVLENBQUMsQ0FBQyxRQUFRLEVBQUUsQ0FBQztRQUMxRCxJQUFJLENBQUMsZ0JBQWdCLENBQUMsS0FBSyxDQUFDLFNBQVMsR0FBRyxhQUFhLEdBQUcsSUFBSSxDQUFDLGdCQUFnQixHQUFHLEtBQUssQ0FBQztJQUMxRixDQUFDO0lBRUQsdUZBQXVGO0lBQ2hGLHVDQUFpQixHQUF4QixVQUF5QixLQUFVO1FBQy9CLElBQUksVUFBVSxHQUFXLEtBQUssQ0FBQyxNQUFNLENBQUMscUJBQXFCLEVBQUUsQ0FBQyxJQUFJLEdBQUcsSUFBSSxDQUFDLG9CQUFvQixFQUFFLENBQUM7UUFDakcsSUFBSSxhQUFhLEdBQVEsSUFBSSxDQUFDLGFBQWEsQ0FBQyxxQkFBcUIsRUFBRSxDQUFDO1FBQ3BFLElBQUksYUFBYSxHQUFXLElBQUksQ0FBQyxLQUFLLENBQUMsYUFBYSxDQUFDLElBQUksR0FBRyxJQUFJLENBQUMsb0JBQW9CLEVBQUUsQ0FBQyxDQUFDO1FBQ3pGLElBQUksVUFBVSxHQUFHLEtBQUssQ0FBQyxNQUFNLENBQUMsV0FBVyxHQUFHLGFBQWEsR0FBRyxhQUFhLENBQUMsS0FBSztZQUFFLE9BQU8sSUFBSSxDQUFDO1FBQzdGLElBQUksVUFBVSxHQUFHLGFBQWE7WUFBRSxPQUFPLElBQUksQ0FBQztRQUM1QyxPQUFPLEtBQUssQ0FBQztJQUNqQixDQUFDO0lBRU8sbUNBQWEsR0FBckI7UUFDSSxJQUFJLENBQUMsVUFBVSxHQUFHLElBQUksQ0FBQyxRQUFRLENBQUMsV0FBVyxDQUFDO1FBQzVDLElBQUksQ0FBQyxlQUFlLEdBQUcsSUFBSSxDQUFDLGdCQUFnQixDQUFDLFdBQVcsQ0FBQztJQUM3RCxDQUFDO0lBRU8sdUNBQWlCLEdBQXpCLFVBQTBCLEtBQVk7UUFDbEMsSUFBSSxXQUFXLEdBQVcsS0FBSyxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUMsbUNBQW1DLEdBQUcsS0FBSyxDQUFDLFdBQVcsR0FBRyxRQUFRLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQztRQUN0SCxPQUFPLHdGQUNpQyxHQUFHLEtBQUssQ0FBQyxLQUFLLEdBQUcsUUFBUTtjQUNuRCxXQUFXO1lBQ2pCLFFBQVEsQ0FBQztJQUNyQixDQUFDO0lBRU8sMENBQW9CLEdBQTVCO1FBQ0ksSUFBSSxHQUFHLEdBQWdCLFFBQVEsQ0FBQyxlQUFlLENBQUM7UUFDaEQsT0FBTyxDQUFDLE1BQU0sQ0FBQyxXQUFXLElBQUksR0FBRyxDQUFDLFVBQVUsQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDLFVBQVUsSUFBSSxDQUFDLENBQUMsQ0FBQztJQUMxRSxDQUFDOztnQkExRndCLFVBQVU7O0lBWjFCLFdBQVc7UUFEdkIsVUFBVSxFQUFFO3lDQWFnQixVQUFVO09BWjFCLFdBQVcsQ0F1R3ZCO0lBQUQsa0JBQUM7Q0FBQSxBQXZHRCxJQXVHQztTQXZHWSxXQUFXIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgSW5qZWN0YWJsZSB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xyXG5pbXBvcnQgeyBJU3RlcCB9IGZyb20gJy4va2QtYW5ndWxhci13aXphcmQnO1xyXG5pbXBvcnQgeyBFbGVtZW50UmVmIH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XHJcblxyXG4vKipcclxuKiBXaXphcmQgdi4xLjAuMFxyXG4qIGNyZWF0ZWQgYnk6IEdyYWNlIFBla1xyXG4qIGNyZWF0ZWQgb246IDEyIERlYyAyMDE3XHJcbiogcGx1Z2luczogcHJpbWVuZyB0b29sdGlwXHJcbipcclxuKiBmdW5jdGlvbnM6XHJcbiogICAgIHB1YmxpY1xyXG4qICAgICAgICAgLSBzZXRJdGVtXHJcbiogICAgICAgICAgICBwdXJwb3NlOiBzZXQgYWN0aXZlL2Rpc2FibGUsIGljb25zIGFuZCB0b29sdGlwJ3MgSFRNTCBzdHJpbmdcclxuKiAgICAgICAgIC0gc2V0Q29udGFpbmVyQW5kU3RlcEVsZW1lbnRcclxuKiAgICAgICAgIC0gdHJhbnNsYXRlVmlld1RvQ2xpY2tlZEVsZW1cclxuKiAgICAgICAgIC0gaXNTdGVwT3V0T2ZCb3VuZHNcclxuKiAgICAgcHJpdmF0ZVxyXG4qICAgICAgICAgLSBzZXRXaWR0aEluZm9cclxuKiAgICAgICAgICAgICBwdXJwb3NlOiBzdG9yZSBjb250YWluZXIgYW5kIGVhY2ggc3RlcHMncyB3aWR0aCBmb3IgdHJhbnNsYXRpb24gY2FsY3VsYXRpb25cclxuKiAgICAgICAgIC0gc2V0VG9vbHRpcFN0cmluZ1xyXG4qICAgICAgICAgLSBnZXRXaW5kb3dTY3JvbGxMZWZ0XHJcbiovXHJcblxyXG5ASW5qZWN0YWJsZSgpXHJcbmV4cG9ydCBjbGFzcyBLZFdpemFyZFN2YyB7XHJcblxyXG4gICAgcHJpdmF0ZSBfY29udGFpbmVyRWxlOiBIVE1MRWxlbWVudDtcclxuICAgIHByaXZhdGUgX2lubmVyV3JhcHBlckVsZTogSFRNTEVsZW1lbnQ7XHJcbiAgICBwcml2YXRlIF9zdGVwRWxlOiBIVE1MRWxlbWVudDtcclxuICAgIHByaXZhdGUgX2NvbnRhaW5lcldpZHRoOiBudW1iZXI7XHJcbiAgICBwcml2YXRlIF9zdGVwV2lkdGg6IG51bWJlcjtcclxuICAgIHByaXZhdGUgX3RyYW5zbGF0ZVhWYWx1ZTogc3RyaW5nO1xyXG4gICAgcHJpdmF0ZSBfdG90YWxTdGVwczogbnVtYmVyO1xyXG4gICAgcHJpdmF0ZSBfZGlyZWN0aW9uOiBzdHJpbmc7XHJcblxyXG4gICAgY29uc3RydWN0b3IoXHJcbiAgICAgICAgcHJpdmF0ZSBfZWxlbWVudFJlZjogRWxlbWVudFJlZlxyXG4gICAgKSB7IH1cclxuXHJcbiAgICBzZXQgZGlyZWN0aW9uKF9kaXJlY3Rpb246IHN0cmluZykge1xyXG4gICAgICAgIHRoaXMuX2RpcmVjdGlvbiA9IF9kaXJlY3Rpb247XHJcbiAgICB9XHJcblxyXG4gICAgc2V0IHRvdGFsU3RlcHMoX3RvdGFsU3RlcHM6IG51bWJlcikge1xyXG4gICAgICAgIHRoaXMuX3RvdGFsU3RlcHMgPSBfdG90YWxTdGVwcztcclxuICAgIH1cclxuXHJcbiAgICBnZXQgY29udGFpbmVyV2lkdGgoKTogbnVtYmVyIHtcclxuICAgICAgICByZXR1cm4gdGhpcy5fY29udGFpbmVyV2lkdGg7XHJcbiAgICB9XHJcblxyXG4gICAgcHVibGljIHNldEl0ZW0oX2l0ZW1zOiBBcnJheTxhbnk+KTogQXJyYXk8SVN0ZXA+IHtcclxuICAgICAgICBsZXQgaXRlbXM6IEFycmF5PElTdGVwPiA9IFtdO1xyXG4gICAgICAgIGZvciAobGV0IGkgPSAwOyBpIDwgX2l0ZW1zLmxlbmd0aDsgKytpKSB7XHJcbiAgICAgICAgICAgIGxldCBpdGVtID0gT2JqZWN0LmFzc2lnbih7fSwgX2l0ZW1zW2ldLCB7XHJcbiAgICAgICAgICAgICAgICBpZDogaSxcclxuICAgICAgICAgICAgICAgIGlzQWN0aXZlOiBpID09PSAwID8gdHJ1ZSA6IGZhbHNlLFxyXG4gICAgICAgICAgICAgICAgaXNEaXNhYmxlZDogaSA9PT0gMCA/IGZhbHNlIDogdHJ1ZSxcclxuICAgICAgICAgICAgICAgIGljb246IF9pdGVtc1tpXS5pY29uID8gX2l0ZW1zW2ldLmljb24gOiBpICsgMSxcclxuICAgICAgICAgICAgICAgIGljb25UeXBlOiBfaXRlbXNbaV0uaWNvbiA/ICdpY29uJyA6ICdudW1iZXInLFxyXG4gICAgICAgICAgICAgICAgdG9vbHRpcFN0cmluZzogdGhpcy5fc2V0VG9vbHRpcFN0cmluZyhfaXRlbXNbaV0pXHJcbiAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICBpdGVtcy5wdXNoKGl0ZW0pO1xyXG4gICAgICAgIH1cclxuICAgICAgICByZXR1cm4gaXRlbXM7XHJcbiAgICB9XHJcblxyXG4gICAgcHVibGljIHNldENvbnRhaW5lckFuZFN0ZXBFbGVtZW50KF9pZDogc3RyaW5nKTogdm9pZCB7XHJcbiAgICAgICAgdGhpcy5faW5uZXJXcmFwcGVyRWxlID0gdGhpcy5fZWxlbWVudFJlZi5uYXRpdmVFbGVtZW50LnF1ZXJ5U2VsZWN0b3IoJyMnICsgX2lkICsgJyAua2R4LXdpemFyZC1pbm5lci13cmFwcGVyJyk7XHJcbiAgICAgICAgdGhpcy5fc3RlcEVsZSA9IHRoaXMuX2VsZW1lbnRSZWYubmF0aXZlRWxlbWVudC5xdWVyeVNlbGVjdG9yKCcjJyArIF9pZCArICcgLmtkeC13aXphcmQtc3RlcC1zZWxlY3RlZCcpO1xyXG4gICAgICAgIHRoaXMuX2NvbnRhaW5lckVsZSA9IHRoaXMuX2VsZW1lbnRSZWYubmF0aXZlRWxlbWVudC5xdWVyeVNlbGVjdG9yKCcjJyArIF9pZCArICcgLmtkeC13aXphcmQtc3RlcHMtY29udGFpbmVyJyk7XHJcbiAgICB9XHJcblxyXG4gICAgcHVibGljIHRyYW5zbGF0ZVZpZXdUb0NsaWNrZWRFbGVtKF9hY3RpdmVTdGVwOiBJU3RlcCk6IHZvaWQge1xyXG5cclxuICAgICAgICB0aGlzLl9zZXRXaWR0aEluZm8oKTtcclxuXHJcbiAgICAgICAgbGV0IG1vdmVYVmFsdWU6IG51bWJlciA9IChfYWN0aXZlU3RlcC5pZCAqIHRoaXMuX3N0ZXBXaWR0aCAtIHRoaXMuX2NvbnRhaW5lcldpZHRoIC8gMiArIHRoaXMuX3N0ZXBXaWR0aCAvIDIpICogLTE7XHJcblxyXG4gICAgICAgIGlmICh0aGlzLl9kaXJlY3Rpb24gPT09ICdyaWdodCcpIHtcclxuICAgICAgICAgICAgbW92ZVhWYWx1ZSA9IC0xICogbW92ZVhWYWx1ZTtcclxuICAgICAgICAgICAgaWYgKG1vdmVYVmFsdWUgPCAwKSB7XHJcbiAgICAgICAgICAgICAgICBtb3ZlWFZhbHVlID0gMDtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBpZiAobW92ZVhWYWx1ZSA+ICh0aGlzLl90b3RhbFN0ZXBzICogdGhpcy5fc3RlcFdpZHRoIC0gdGhpcy5fY29udGFpbmVyV2lkdGgpKSB7XHJcbiAgICAgICAgICAgICAgICBtb3ZlWFZhbHVlID0gdGhpcy5fdG90YWxTdGVwcyAqIHRoaXMuX3N0ZXBXaWR0aCAtIHRoaXMuX2NvbnRhaW5lcldpZHRoO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgaWYgKG1vdmVYVmFsdWUgPiAwKSB7XHJcbiAgICAgICAgICAgICAgICBtb3ZlWFZhbHVlID0gMDtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBpZiAobW92ZVhWYWx1ZSA8ICh0aGlzLl90b3RhbFN0ZXBzICogdGhpcy5fc3RlcFdpZHRoIC0gdGhpcy5fY29udGFpbmVyV2lkdGgpICogLTEpIHtcclxuICAgICAgICAgICAgICAgIG1vdmVYVmFsdWUgPSAodGhpcy5fdG90YWxTdGVwcyAqIHRoaXMuX3N0ZXBXaWR0aCAtIHRoaXMuX2NvbnRhaW5lcldpZHRoKSAqIC0xO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICB0aGlzLl90cmFuc2xhdGVYVmFsdWUgPSBNYXRoLmZsb29yKG1vdmVYVmFsdWUpLnRvU3RyaW5nKCk7XHJcbiAgICAgICAgdGhpcy5faW5uZXJXcmFwcGVyRWxlLnN0eWxlLnRyYW5zZm9ybSA9ICd0cmFuc2xhdGVYKCcgKyB0aGlzLl90cmFuc2xhdGVYVmFsdWUgKyAncHgpJztcclxuICAgIH1cclxuXHJcbiAgICAvKiBpZiBkZXNjcmlwdGlvbiB0ZXh0cyBhcmUgd2l0aGluIHRoZSBib3VuZHMgb2YgLnN0ZXBzLWNvbnRhaW5lciwgdGhlbiBzaG93IHRvb2x0aXAgKi9cclxuICAgIHB1YmxpYyBpc1N0ZXBPdXRPZkJvdW5kcyhldmVudDogYW55KTogYm9vbGVhbiB7XHJcbiAgICAgICAgbGV0IHRhcmdldExlZnQ6IG51bWJlciA9IGV2ZW50LnRhcmdldC5nZXRCb3VuZGluZ0NsaWVudFJlY3QoKS5sZWZ0ICsgdGhpcy5fZ2V0V2luZG93U2Nyb2xsTGVmdCgpO1xyXG4gICAgICAgIGxldCBjb250YWluZXJSZWN0OiBhbnkgPSB0aGlzLl9jb250YWluZXJFbGUuZ2V0Qm91bmRpbmdDbGllbnRSZWN0KCk7XHJcbiAgICAgICAgbGV0IGNvbnRhaW5lckxlZnQ6IG51bWJlciA9IE1hdGguZmxvb3IoY29udGFpbmVyUmVjdC5sZWZ0ICsgdGhpcy5fZ2V0V2luZG93U2Nyb2xsTGVmdCgpKTtcclxuICAgICAgICBpZiAodGFyZ2V0TGVmdCArIGV2ZW50LnRhcmdldC5vZmZzZXRXaWR0aCA+IGNvbnRhaW5lckxlZnQgKyBjb250YWluZXJSZWN0LndpZHRoKSByZXR1cm4gdHJ1ZTtcclxuICAgICAgICBpZiAodGFyZ2V0TGVmdCA8IGNvbnRhaW5lckxlZnQpIHJldHVybiB0cnVlO1xyXG4gICAgICAgIHJldHVybiBmYWxzZTtcclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF9zZXRXaWR0aEluZm8oKTogdm9pZCB7XHJcbiAgICAgICAgdGhpcy5fc3RlcFdpZHRoID0gdGhpcy5fc3RlcEVsZS5jbGllbnRXaWR0aDtcclxuICAgICAgICB0aGlzLl9jb250YWluZXJXaWR0aCA9IHRoaXMuX2lubmVyV3JhcHBlckVsZS5jbGllbnRXaWR0aDtcclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF9zZXRUb29sdGlwU3RyaW5nKF9zdGVwOiBJU3RlcCk6IHN0cmluZyB7XHJcbiAgICAgICAgbGV0IGRlc2NyaXB0aW9uOiBzdHJpbmcgPSBfc3RlcC5kZXNjcmlwdGlvbiA/ICc8ZGl2IGNsYXNzPVwidG9vbHRpcC1kZXNjcmlwdGlvblwiPicgKyBfc3RlcC5kZXNjcmlwdGlvbiArICc8L2Rpdj4nIDogJyc7XHJcbiAgICAgICAgcmV0dXJuIGA8ZGl2IGNsYXNzPVwidG9vbHRpcC13aXphcmQtdGV4dFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJ0b29sdGlwLWxhYmVsXCI+YCArIF9zdGVwLmxhYmVsICsgYDwvZGl2PmBcclxuICAgICAgICAgICAgICAgICAgICArIGRlc2NyaXB0aW9uICtcclxuICAgICAgICAgICAgICAgICc8L2Rpdj4nO1xyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX2dldFdpbmRvd1Njcm9sbExlZnQoKTogbnVtYmVyIHtcclxuICAgICAgICBsZXQgZG9jOiBIVE1MRWxlbWVudCA9IGRvY3VtZW50LmRvY3VtZW50RWxlbWVudDtcclxuICAgICAgICByZXR1cm4gKHdpbmRvdy5wYWdlWE9mZnNldCB8fCBkb2Muc2Nyb2xsTGVmdCkgLSAoZG9jLmNsaWVudExlZnQgfHwgMCk7XHJcbiAgICB9XHJcbn1cclxuIl19