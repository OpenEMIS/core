import { __decorate, __metadata } from "tslib";
import { Injectable } from '@angular/core';
import { KdBroadcaster } from '../kd-common/index';
import * as i0 from "@angular/core";
import * as i1 from "../kd-common/kd-broadcaster-svc";
var KdWizardEvent = /** @class */ (function () {
    function KdWizardEvent(_broadcaster) {
        this._broadcaster = _broadcaster;
    }
    KdWizardEvent.prototype.actionClicked = function (_wizardId, _event) {
        this._broadcaster.broadcast(_wizardId + 'KdWizardActionClicked', _event);
    };
    KdWizardEvent.prototype.onActionClicked = function (_wizardId) {
        return this._broadcaster.on(_wizardId + 'KdWizardActionClicked');
    };
    KdWizardEvent.prototype.nextClickedWhenLastStep = function (_wizardId, _event) {
        this._broadcaster.broadcast(_wizardId + 'KdWizardLastStepReached', _event);
    };
    KdWizardEvent.prototype.onNextClickedWhenLastStep = function (_wizardId) {
        return this._broadcaster.on(_wizardId + 'KdWizardLastStepReached');
    };
    KdWizardEvent.ctorParameters = function () { return [
        { type: KdBroadcaster }
    ]; };
    KdWizardEvent.ɵprov = i0.ɵɵdefineInjectable({ factory: function KdWizardEvent_Factory() { return new KdWizardEvent(i0.ɵɵinject(i1.KdBroadcaster)); }, token: KdWizardEvent, providedIn: "root" });
    KdWizardEvent = __decorate([
        Injectable({
            providedIn: 'root'
        }),
        __metadata("design:paramtypes", [KdBroadcaster])
    ], KdWizardEvent);
    return KdWizardEvent;
}());
export { KdWizardEvent };
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoia2QtYW5ndWxhci13aXphcmQtZXZlbnQuanMiLCJzb3VyY2VSb290Ijoibmc6Ly9vcGVuZW1pcy1zdHlsZWd1aWRlLWxpYi8iLCJzb3VyY2VzIjpbImtkLWNvbXBvbmVudHMva2QtYW5ndWxhci13aXphcmQva2QtYW5ndWxhci13aXphcmQtZXZlbnQudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IjtBQUFBLE9BQU8sRUFBRSxVQUFVLEVBQUUsTUFBTSxlQUFlLENBQUM7QUFHM0MsT0FBTyxFQUFFLGFBQWEsRUFBRSxNQUFNLG9CQUFvQixDQUFDOzs7QUFLbkQ7SUFDSSx1QkFDWSxZQUEyQjtRQUEzQixpQkFBWSxHQUFaLFlBQVksQ0FBZTtJQUNuQyxDQUFDO0lBRUUscUNBQWEsR0FBcEIsVUFBcUIsU0FBaUIsRUFBRSxNQUFZO1FBQ2hELElBQUksQ0FBQyxZQUFZLENBQUMsU0FBUyxDQUFDLFNBQVMsR0FBRyx1QkFBdUIsRUFBRSxNQUFNLENBQUMsQ0FBQztJQUM3RSxDQUFDO0lBRU0sdUNBQWUsR0FBdEIsVUFBdUIsU0FBaUI7UUFDcEMsT0FBTyxJQUFJLENBQUMsWUFBWSxDQUFDLEVBQUUsQ0FBTSxTQUFTLEdBQUcsdUJBQXVCLENBQUMsQ0FBQztJQUMxRSxDQUFDO0lBRU0sK0NBQXVCLEdBQTlCLFVBQStCLFNBQWlCLEVBQUUsTUFBWTtRQUMxRCxJQUFJLENBQUMsWUFBWSxDQUFDLFNBQVMsQ0FBQyxTQUFTLEdBQUcseUJBQXlCLEVBQUUsTUFBTSxDQUFDLENBQUM7SUFDL0UsQ0FBQztJQUVNLGlEQUF5QixHQUFoQyxVQUFpQyxTQUFpQjtRQUM5QyxPQUFPLElBQUksQ0FBQyxZQUFZLENBQUMsRUFBRSxDQUFNLFNBQVMsR0FBRyx5QkFBeUIsQ0FBQyxDQUFDO0lBQzVFLENBQUM7O2dCQWpCeUIsYUFBYTs7O0lBRjlCLGFBQWE7UUFIekIsVUFBVSxDQUFDO1lBQ1IsVUFBVSxFQUFFLE1BQU07U0FDckIsQ0FBQzt5Q0FHNEIsYUFBYTtPQUY5QixhQUFhLENBb0J6Qjt3QkE1QkQ7Q0E0QkMsQUFwQkQsSUFvQkM7U0FwQlksYUFBYSIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IEluamVjdGFibGUgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcclxuaW1wb3J0IHsgT2JzZXJ2YWJsZSB9IGZyb20gJ3J4anMnO1xyXG5cclxuaW1wb3J0IHsgS2RCcm9hZGNhc3RlciB9IGZyb20gJy4uL2tkLWNvbW1vbi9pbmRleCc7XHJcblxyXG5ASW5qZWN0YWJsZSh7XHJcbiAgICBwcm92aWRlZEluOiAncm9vdCdcclxufSlcclxuZXhwb3J0IGNsYXNzIEtkV2l6YXJkRXZlbnQge1xyXG4gICAgY29uc3RydWN0b3IoXHJcbiAgICAgICAgcHJpdmF0ZSBfYnJvYWRjYXN0ZXI6IEtkQnJvYWRjYXN0ZXJcclxuICAgICkgeyB9XHJcblxyXG4gICAgcHVibGljIGFjdGlvbkNsaWNrZWQoX3dpemFyZElkOiBzdHJpbmcsIF9ldmVudD86IGFueSk6IHZvaWQge1xyXG4gICAgICAgIHRoaXMuX2Jyb2FkY2FzdGVyLmJyb2FkY2FzdChfd2l6YXJkSWQgKyAnS2RXaXphcmRBY3Rpb25DbGlja2VkJywgX2V2ZW50KTtcclxuICAgIH1cclxuXHJcbiAgICBwdWJsaWMgb25BY3Rpb25DbGlja2VkKF93aXphcmRJZDogc3RyaW5nKTogT2JzZXJ2YWJsZTxhbnk+IHtcclxuICAgICAgICByZXR1cm4gdGhpcy5fYnJvYWRjYXN0ZXIub248YW55Pihfd2l6YXJkSWQgKyAnS2RXaXphcmRBY3Rpb25DbGlja2VkJyk7XHJcbiAgICB9XHJcblxyXG4gICAgcHVibGljIG5leHRDbGlja2VkV2hlbkxhc3RTdGVwKF93aXphcmRJZDogc3RyaW5nLCBfZXZlbnQ/OiBhbnkpOiB2b2lkIHtcclxuICAgICAgICB0aGlzLl9icm9hZGNhc3Rlci5icm9hZGNhc3QoX3dpemFyZElkICsgJ0tkV2l6YXJkTGFzdFN0ZXBSZWFjaGVkJywgX2V2ZW50KTtcclxuICAgIH1cclxuXHJcbiAgICBwdWJsaWMgb25OZXh0Q2xpY2tlZFdoZW5MYXN0U3RlcChfd2l6YXJkSWQ6IHN0cmluZyk6IE9ic2VydmFibGU8YW55PiB7XHJcbiAgICAgICAgcmV0dXJuIHRoaXMuX2Jyb2FkY2FzdGVyLm9uPGFueT4oX3dpemFyZElkICsgJ0tkV2l6YXJkTGFzdFN0ZXBSZWFjaGVkJyk7XHJcbiAgICB9XHJcbn1cclxuIl19