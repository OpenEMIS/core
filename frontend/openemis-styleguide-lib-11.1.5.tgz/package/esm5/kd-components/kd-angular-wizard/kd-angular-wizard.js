import { __decorate, __metadata } from "tslib";
import { Component, ViewEncapsulation, Input, HostListener, Output, EventEmitter, } from '@angular/core';
import { timer } from 'rxjs';
import { debounceTime } from 'rxjs/operators';
import { Router } from '@angular/router';
import { KdWizardEvent } from './kd-angular-wizard-event';
import { KdWizardSvc } from './kd-angular-wizard-svc';
import { KdDomElemSvc } from '../kd-common/index';
import { KdSplitterEvent } from '../kd-angular-splitter/index';
var KdWizard = /** @class */ (function () {
    function KdWizard(_router, _kdWizardEvent, _kdWizardSvc, _kdDomSvc, _kdSplitterEvent) {
        var _this = this;
        this._router = _router;
        this._kdWizardEvent = _kdWizardEvent;
        this._kdWizardSvc = _kdWizardSvc;
        this._kdDomSvc = _kdDomSvc;
        this.steps = [];
        this.isButtonHidden = false;
        this.isPreviousDisabled = true;
        this.isNextDisabled = false;
        this.tooltipDisabled = false;
        this._tooltipNotDisplayed = false;
        this.activeStepEmitter = new EventEmitter();
        this._dragMenuSub = _kdSplitterEvent.onDrag()
            .pipe(debounceTime(100))
            .subscribe(function () {
            _this._handleTranslateAndTooltip();
        });
        this._toggleMenuSub = _kdSplitterEvent.onToggleMenu().subscribe(function () {
            timer(500).subscribe(function () {
                _this._handleTranslateAndTooltip();
            });
        });
    }
    KdWizard.prototype.onResize = function (event) {
        var _this = this;
        timer(200).subscribe(function () {
            _this._handleTranslateAndTooltip();
        });
    };
    KdWizard.prototype.ngOnInit = function () {
        this.id = typeof this.wizardId === 'undefined' ? 'wizard' : this.wizardId;
        this.steps = this._kdWizardSvc.setItem(this.config.steps);
        this._initApi();
        this.nextButtonText = this.config.next || 'Next';
        this.activeStep = this.steps[0];
        this._emitStep(this.steps[0].content);
        this.isMobileDevice = this._kdDomSvc.isMobileDevice();
        if (this.isMobileDevice || window.innerWidth < 481) {
            this.tooltipDisabled = true;
            this._tooltipNotDisplayed = true;
        }
    };
    KdWizard.prototype.ngAfterViewInit = function () {
        this._kdWizardSvc.direction = this._kdDomSvc.getDocumentDirection(true) || 'left';
        this._kdWizardSvc.totalSteps = this.steps.length;
        this._kdWizardSvc.setContainerAndStepElement(this.id);
    };
    KdWizard.prototype.ngOnDestroy = function () {
        this._dragMenuSub.unsubscribe();
        this._toggleMenuSub.unsubscribe();
    };
    /* user clicks and goes back to past steps */
    KdWizard.prototype.selectedStep = function (_step, e) {
        e.preventDefault();
        if (!_step.isDisabled) {
            // make clicked step active
            this.steps[_step.id].isActive = true;
            // disable all future steps
            for (var i = _step.id + 1; i < this.steps.length; ++i) {
                this.steps[i].isDisabled = true;
                if (this.steps[i].isActive)
                    this.steps[i].isActive = false;
            }
            this.activeStep = _step;
            this._kdWizardSvc.translateViewToClickedElem(this.activeStep);
            // update button's text. disable 'previous' button if first step, and change text of 'next' button for last step
            this._updateButton();
            // emit current step to parent component's DOM to render required content
            this._emitStep(_step.content);
        }
    };
    KdWizard.prototype.actionClicked = function (_action, e) {
        e.preventDefault();
        // emit click event to outside of component, provides action type (next or previous), current step and whether this is last step
        this._kdWizardEvent.actionClicked(this.id, {
            action: _action,
            step: this.activeStep,
            isLast: this.activeStep.id === this.steps.length - 1
        });
    };
    KdWizard.prototype.openToottip = function (e) {
        e.preventDefault();
        if (this._tooltipNotDisplayed)
            return;
        if (this._kdWizardSvc.isStepOutOfBounds(e)) {
            this.tooltipDisabled = true;
        }
        else {
            this.tooltipDisabled = false;
        }
    };
    KdWizard.prototype._initApi = function () {
        var _this = this;
        if (typeof this.api !== 'undefined') {
            this.api.updateSteps = function (_action) { return _this._updateSteps(_action); };
            this.api.enableButton = function (_type) { return _this._enableButton(_type); };
            this.api.disableButton = function (_type) { return _this._disableButton(_type); };
            this.api.getActiveStep = function () { return _this.activeStep; };
            this.api.hideButton = function () { _this.isButtonHidden = true; };
            this.api.showButton = function () { _this.isButtonHidden = false; };
        }
    };
    /* update Steps when validation (done by application via api) is done */
    KdWizard.prototype._updateSteps = function (_action) {
        // broadcast 'next' button is clicked when at last step and when validation (done by application) is done
        if (this.activeStep.id === this.steps.length - 1 && _action === 'next') {
            this._kdWizardEvent.nextClickedWhenLastStep(this.id);
            return;
        }
        var index = this.activeStep.id;
        switch (_action) {
            case 'previous':
                if (index !== 0) {
                    this.steps[index - 1].isActive = true;
                    this.steps[index].isDisabled = true;
                    this.steps[index].isActive = false;
                    this.activeStep = this.steps[this.activeStep.id - 1];
                }
                break;
            case 'next':
                if (index !== this.steps.length - 1) {
                    this.steps[index].isActive = false;
                    this.steps[index + 1].isActive = true;
                    this.steps[index + 1].isDisabled = false;
                    this.activeStep = this.steps[this.activeStep.id + 1];
                }
                break;
            default:
                break;
        }
        this._kdWizardSvc.translateViewToClickedElem(this.activeStep);
        this._updateButton();
        this._emitStep(this.activeStep.content);
    };
    KdWizard.prototype._emitStep = function (_content) {
        if (this.contentType === 'html')
            this.activeStepEmitter.emit(_content);
        if (this.contentType === 'router')
            this._router.navigateByUrl(_content);
    };
    KdWizard.prototype._handleTranslateAndTooltip = function () {
        this._kdWizardSvc.translateViewToClickedElem(this.activeStep);
        if (!this.isMobileDevice) {
            this.tooltipDisabled = window.innerWidth > 480 ? false : true;
            this._tooltipNotDisplayed = this.tooltipDisabled;
        }
    };
    /* set the text of next and previous buttons depending on which step */
    KdWizard.prototype._updateButton = function () {
        // disable first step's previous button
        this.isPreviousDisabled = this.activeStep.id === 0 ? true : false;
        // change text of last step's next button to 'complete'
        this.nextButtonText = this.activeStep.id === this.steps.length - 1 ? this.config.complete || 'Complete' : this.config.next || 'Next';
    };
    /* enable external components to enable or disable next and previous buttons */
    KdWizard.prototype._enableButton = function (_type) {
        if (_type === 'previous')
            this.isPreviousDisabled = false;
        if (_type === 'next')
            this.isNextDisabled = false;
    };
    KdWizard.prototype._disableButton = function (_type) {
        if (_type === 'previous')
            this.isPreviousDisabled = true;
        if (_type === 'next')
            this.isNextDisabled = true;
    };
    KdWizard.ctorParameters = function () { return [
        { type: Router },
        { type: KdWizardEvent },
        { type: KdWizardSvc },
        { type: KdDomElemSvc },
        { type: KdSplitterEvent }
    ]; };
    __decorate([
        Input('id'),
        __metadata("design:type", String)
    ], KdWizard.prototype, "wizardId", void 0);
    __decorate([
        Input(),
        __metadata("design:type", Object)
    ], KdWizard.prototype, "config", void 0);
    __decorate([
        Input('type'),
        __metadata("design:type", String)
    ], KdWizard.prototype, "contentType", void 0);
    __decorate([
        Input(),
        __metadata("design:type", Object)
    ], KdWizard.prototype, "api", void 0);
    __decorate([
        Output(),
        __metadata("design:type", EventEmitter)
    ], KdWizard.prototype, "activeStepEmitter", void 0);
    __decorate([
        HostListener('window:resize', ['$event']),
        __metadata("design:type", Function),
        __metadata("design:paramtypes", [Object]),
        __metadata("design:returntype", void 0)
    ], KdWizard.prototype, "onResize", null);
    KdWizard = __decorate([
        Component({
            selector: 'kd-wizard',
            template: "<div class=\"kdx kdx-wizard\" [id]=\"id\">\r\n    <div class=\"kdx-wizard-steps-container\">\r\n        <div class=\"kdx-wizard-inner-wrapper\">\r\n            <ul>\r\n                <li [ngClass]='{\"kdx-wizard-step-selected\": step.isActive, \"step-disabled\": step.isDisabled, \"step-enabled\": !step.isDisabled}' *ngFor=\"let step of steps; let isFirst = first; let isLast = last; \">\r\n                    <a (click)='selectedStep(step, $event)' class='kdx-step-container' data-step=\"i\">\r\n                        <div class=\"kdx-step-progress-and-icon\" [ngClass]='{\"kdx-bar-hide-first\": isFirst, \"kdx-bar-hide-last\": isLast }'>\r\n                            <div class=\"kdx-step-icon\">\r\n                                <i class=\"{{step.icon}}\" *ngIf=\"step.iconType === 'icon'\"></i>\r\n                                <div class=\"kdx-step-icon-string\" *ngIf=\"step.iconType === 'number'\">{{step.icon}}</div>\r\n                            </div>\r\n                        </div>\r\n                        <div class=\"kdx-step-text\" [kd-tooltip-dir]=\"step.tooltipString\" tooltipPosition=\"bottom\" tooltipStyleClass=\"tooltip-wizard\" tooltipEvent=\"hover\" [tooltipDisabled]=\"tooltipDisabled\" [escape]=\"false\" (mouseenter)='openToottip($event)'>\r\n                            <div class=\"step-label ellipsis-wizard\" >\r\n                                {{step.label}}\r\n                            </div>\r\n                            <div class=\"step-description ellipsis-wizard\" *ngIf=\"step.description && !isMobileDevice\">\r\n                                {{step.description}}\r\n                            </div>\r\n                        </div>\r\n                    </a>\r\n                </li>\r\n            </ul>\r\n        </div>\r\n    </div>\r\n    <div class=\"steps-content\">\r\n        <div class=\"step-text-mobile\">\r\n            <div class=\"step-label-mobile\" >\r\n                {{activeStep.label}}\r\n            </div>\r\n            <div class=\"step-description-mobile\" *ngIf=\"activeStep.description\">\r\n                {{activeStep.description}}\r\n            </div>\r\n        </div>\r\n        <ng-template [ngIf]='contentType === \"text\"'>\r\n            <div class='step-content'>\r\n                <div class='step-pane'>{{activeStep.content}}</div>\r\n            </div>\r\n        </ng-template>\r\n        <ng-template [ngIf]='contentType === \"html\"'>\r\n            <ng-content></ng-content>\r\n        </ng-template>\r\n        <ng-template [ngIf]='contentType === \"router\"'>\r\n            <router-outlet></router-outlet>\r\n        </ng-template>\r\n    </div>\r\n    <div class=\"steps-bottom\">\r\n        <div class=\"actions-bottom\" [ngClass]='{\"actions-hide\": isButtonHidden}'>\r\n            <button class=\"btn previous-button\" [disabled]=\"isPreviousDisabled\" (click)=\"actionClicked('previous', $event)\">\r\n                <i class=\"fa fa-caret-left previous-icon icon\"></i>\r\n                {{config.previous || 'Previous'}}\r\n            </button>\r\n            <button class=\"btn next-button\" [disabled]=\"isNextDisabled\" (click)=\"actionClicked('next', $event)\">\r\n                <i class=\"fa fa-caret-right next-icon icon\"></i>\r\n                {{nextButtonText}}\r\n            </button>\r\n        </div>\r\n    </div>\r\n</div>",
            encapsulation: ViewEncapsulation.None,
            providers: [KdWizardSvc, KdDomElemSvc]
        }),
        __metadata("design:paramtypes", [Router,
            KdWizardEvent,
            KdWizardSvc,
            KdDomElemSvc,
            KdSplitterEvent])
    ], KdWizard);
    return KdWizard;
}());
export { KdWizard };
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoia2QtYW5ndWxhci13aXphcmQuanMiLCJzb3VyY2VSb290Ijoibmc6Ly9vcGVuZW1pcy1zdHlsZWd1aWRlLWxpYi8iLCJzb3VyY2VzIjpbImtkLWNvbXBvbmVudHMva2QtYW5ndWxhci13aXphcmQva2QtYW5ndWxhci13aXphcmQudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IjtBQUFBLE9BQU8sRUFDSCxTQUFTLEVBQ1QsaUJBQWlCLEVBQ2pCLEtBQUssRUFHTCxZQUFZLEVBQ1osTUFBTSxFQUNOLFlBQVksR0FFZixNQUFNLGVBQWUsQ0FBQztBQUN2QixPQUFPLEVBQWtCLEtBQUssRUFBRSxNQUFNLE1BQU0sQ0FBQztBQUM3QyxPQUFPLEVBQUUsWUFBWSxFQUFFLE1BQU0sZ0JBQWdCLENBQUM7QUFDOUMsT0FBTyxFQUFFLE1BQU0sRUFBRSxNQUFNLGlCQUFpQixDQUFDO0FBQ3pDLE9BQU8sRUFBRSxhQUFhLEVBQUUsTUFBTSwyQkFBMkIsQ0FBQztBQUMxRCxPQUFPLEVBQUUsV0FBVyxFQUFFLE1BQU0seUJBQXlCLENBQUM7QUFDdEQsT0FBTyxFQUFFLFlBQVksRUFBRSxNQUFNLG9CQUFvQixDQUFDO0FBQ2xELE9BQU8sRUFBRSxlQUFlLEVBQUUsTUFBTSw4QkFBOEIsQ0FBQztBQThCL0Q7SUFxQkksa0JBQ1ksT0FBZSxFQUNmLGNBQTZCLEVBQzdCLFlBQXlCLEVBQ3pCLFNBQXVCLEVBQy9CLGdCQUFpQztRQUxyQyxpQkFvQkM7UUFuQlcsWUFBTyxHQUFQLE9BQU8sQ0FBUTtRQUNmLG1CQUFjLEdBQWQsY0FBYyxDQUFlO1FBQzdCLGlCQUFZLEdBQVosWUFBWSxDQUFhO1FBQ3pCLGNBQVMsR0FBVCxTQUFTLENBQWM7UUF2QjVCLFVBQUssR0FBaUIsRUFBRSxDQUFDO1FBQ3pCLG1CQUFjLEdBQVksS0FBSyxDQUFDO1FBQ2hDLHVCQUFrQixHQUFZLElBQUksQ0FBQztRQUNuQyxtQkFBYyxHQUFZLEtBQUssQ0FBQztRQUdoQyxvQkFBZSxHQUFZLEtBQUssQ0FBQztRQUtoQyx5QkFBb0IsR0FBWSxLQUFLLENBQUM7UUFNcEMsc0JBQWlCLEdBQXFCLElBQUksWUFBWSxFQUFFLENBQUM7UUFTL0QsSUFBSSxDQUFDLFlBQVksR0FBRyxnQkFBZ0IsQ0FBQyxNQUFNLEVBQUU7YUFDeEMsSUFBSSxDQUNELFlBQVksQ0FBQyxHQUFHLENBQUMsQ0FDcEI7YUFDQSxTQUFTLENBQUM7WUFDUCxLQUFJLENBQUMsMEJBQTBCLEVBQUUsQ0FBQztRQUN0QyxDQUFDLENBQUMsQ0FBQztRQUVQLElBQUksQ0FBQyxjQUFjLEdBQUcsZ0JBQWdCLENBQUMsWUFBWSxFQUFFLENBQUMsU0FBUyxDQUFDO1lBQzVELEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FBQyxTQUFTLENBQUM7Z0JBQ2pCLEtBQUksQ0FBQywwQkFBMEIsRUFBRSxDQUFDO1lBQ3RDLENBQUMsQ0FBQyxDQUFDO1FBQ1AsQ0FBQyxDQUFDLENBQUM7SUFDUCxDQUFDO0lBR0QsMkJBQVEsR0FBUixVQUFTLEtBQVU7UUFEbkIsaUJBS0M7UUFIRyxLQUFLLENBQUMsR0FBRyxDQUFDLENBQUMsU0FBUyxDQUFDO1lBQ2pCLEtBQUksQ0FBQywwQkFBMEIsRUFBRSxDQUFDO1FBQ3RDLENBQUMsQ0FBQyxDQUFDO0lBQ1AsQ0FBQztJQUVELDJCQUFRLEdBQVI7UUFDSSxJQUFJLENBQUMsRUFBRSxHQUFHLE9BQU8sSUFBSSxDQUFDLFFBQVEsS0FBSyxXQUFXLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQztRQUMxRSxJQUFJLENBQUMsS0FBSyxHQUFHLElBQUksQ0FBQyxZQUFZLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLENBQUM7UUFDMUQsSUFBSSxDQUFDLFFBQVEsRUFBRSxDQUFDO1FBQ2hCLElBQUksQ0FBQyxjQUFjLEdBQUcsSUFBSSxDQUFDLE1BQU0sQ0FBQyxJQUFJLElBQUksTUFBTSxDQUFDO1FBQ2pELElBQUksQ0FBQyxVQUFVLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQztRQUNoQyxJQUFJLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUM7UUFDdEMsSUFBSSxDQUFDLGNBQWMsR0FBRyxJQUFJLENBQUMsU0FBUyxDQUFDLGNBQWMsRUFBRSxDQUFDO1FBQ3RELElBQUksSUFBSSxDQUFDLGNBQWMsSUFBSSxNQUFNLENBQUMsVUFBVSxHQUFHLEdBQUcsRUFBRTtZQUNoRCxJQUFJLENBQUMsZUFBZSxHQUFHLElBQUksQ0FBQztZQUM1QixJQUFJLENBQUMsb0JBQW9CLEdBQUcsSUFBSSxDQUFDO1NBQ3BDO0lBQ0wsQ0FBQztJQUVELGtDQUFlLEdBQWY7UUFDSSxJQUFJLENBQUMsWUFBWSxDQUFDLFNBQVMsR0FBRyxJQUFJLENBQUMsU0FBUyxDQUFDLG9CQUFvQixDQUFDLElBQUksQ0FBQyxJQUFJLE1BQU0sQ0FBQztRQUNsRixJQUFJLENBQUMsWUFBWSxDQUFDLFVBQVUsR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQztRQUNqRCxJQUFJLENBQUMsWUFBWSxDQUFDLDBCQUEwQixDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsQ0FBQztJQUMxRCxDQUFDO0lBRUQsOEJBQVcsR0FBWDtRQUNJLElBQUksQ0FBQyxZQUFZLENBQUMsV0FBVyxFQUFFLENBQUM7UUFDaEMsSUFBSSxDQUFDLGNBQWMsQ0FBQyxXQUFXLEVBQUUsQ0FBQztJQUN0QyxDQUFDO0lBRUQsNkNBQTZDO0lBQ3RDLCtCQUFZLEdBQW5CLFVBQW9CLEtBQVksRUFBRSxDQUFRO1FBQ3RDLENBQUMsQ0FBQyxjQUFjLEVBQUUsQ0FBQztRQUNuQixJQUFJLENBQUMsS0FBSyxDQUFDLFVBQVUsRUFBRTtZQUNuQiwyQkFBMkI7WUFDM0IsSUFBSSxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsRUFBRSxDQUFDLENBQUMsUUFBUSxHQUFHLElBQUksQ0FBQztZQUNyQywyQkFBMkI7WUFDM0IsS0FBSyxJQUFJLENBQUMsR0FBRyxLQUFLLENBQUMsRUFBRSxHQUFHLENBQUMsRUFBRSxDQUFDLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQyxNQUFNLEVBQUUsRUFBRSxDQUFDLEVBQUU7Z0JBQ25ELElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsVUFBVSxHQUFHLElBQUksQ0FBQztnQkFDaEMsSUFBSSxJQUFJLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVE7b0JBQUUsSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLEdBQUcsS0FBSyxDQUFDO2FBQzlEO1lBQ0QsSUFBSSxDQUFDLFVBQVUsR0FBRyxLQUFLLENBQUM7WUFDeEIsSUFBSSxDQUFDLFlBQVksQ0FBQywwQkFBMEIsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLENBQUM7WUFDOUQsZ0hBQWdIO1lBQ2hILElBQUksQ0FBQyxhQUFhLEVBQUUsQ0FBQztZQUNyQix5RUFBeUU7WUFDekUsSUFBSSxDQUFDLFNBQVMsQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLENBQUM7U0FDakM7SUFDTCxDQUFDO0lBRU0sZ0NBQWEsR0FBcEIsVUFBcUIsT0FBZSxFQUFFLENBQVE7UUFDMUMsQ0FBQyxDQUFDLGNBQWMsRUFBRSxDQUFDO1FBQ25CLGdJQUFnSTtRQUNoSSxJQUFJLENBQUMsY0FBYyxDQUFDLGFBQWEsQ0FDN0IsSUFBSSxDQUFDLEVBQUUsRUFDUDtZQUNJLE1BQU0sRUFBRSxPQUFPO1lBQ2YsSUFBSSxFQUFFLElBQUksQ0FBQyxVQUFVO1lBQ3JCLE1BQU0sRUFBRSxJQUFJLENBQUMsVUFBVSxDQUFDLEVBQUUsS0FBSyxJQUFJLENBQUMsS0FBSyxDQUFDLE1BQU0sR0FBRyxDQUFDO1NBQ3ZELENBQ0osQ0FBQztJQUNOLENBQUM7SUFFTSw4QkFBVyxHQUFsQixVQUFtQixDQUFRO1FBQ3ZCLENBQUMsQ0FBQyxjQUFjLEVBQUUsQ0FBQztRQUNuQixJQUFJLElBQUksQ0FBQyxvQkFBb0I7WUFBRSxPQUFPO1FBQ3RDLElBQUksSUFBSSxDQUFDLFlBQVksQ0FBQyxpQkFBaUIsQ0FBQyxDQUFDLENBQUMsRUFBRTtZQUN4QyxJQUFJLENBQUMsZUFBZSxHQUFHLElBQUksQ0FBQztTQUMvQjthQUFNO1lBQ0gsSUFBSSxDQUFDLGVBQWUsR0FBRyxLQUFLLENBQUM7U0FDaEM7SUFDTCxDQUFDO0lBRU8sMkJBQVEsR0FBaEI7UUFBQSxpQkFTQztRQVJHLElBQUksT0FBTyxJQUFJLENBQUMsR0FBRyxLQUFLLFdBQVcsRUFBRTtZQUNqQyxJQUFJLENBQUMsR0FBRyxDQUFDLFdBQVcsR0FBRyxVQUFDLE9BQWUsSUFBVyxPQUFBLEtBQUksQ0FBQyxZQUFZLENBQUMsT0FBTyxDQUFDLEVBQTFCLENBQTBCLENBQUM7WUFDN0UsSUFBSSxDQUFDLEdBQUcsQ0FBQyxZQUFZLEdBQUcsVUFBQyxLQUFhLElBQVcsT0FBQSxLQUFJLENBQUMsYUFBYSxDQUFDLEtBQUssQ0FBQyxFQUF6QixDQUF5QixDQUFDO1lBQzNFLElBQUksQ0FBQyxHQUFHLENBQUMsYUFBYSxHQUFHLFVBQUMsS0FBYSxJQUFXLE9BQUEsS0FBSSxDQUFDLGNBQWMsQ0FBQyxLQUFLLENBQUMsRUFBMUIsQ0FBMEIsQ0FBQztZQUM3RSxJQUFJLENBQUMsR0FBRyxDQUFDLGFBQWEsR0FBRyxjQUFhLE9BQUEsS0FBSSxDQUFDLFVBQVUsRUFBZixDQUFlLENBQUM7WUFDdEQsSUFBSSxDQUFDLEdBQUcsQ0FBQyxVQUFVLEdBQUcsY0FBYyxLQUFJLENBQUMsY0FBYyxHQUFHLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQztZQUNsRSxJQUFJLENBQUMsR0FBRyxDQUFDLFVBQVUsR0FBRyxjQUFjLEtBQUksQ0FBQyxjQUFjLEdBQUcsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDO1NBQ3RFO0lBQ0wsQ0FBQztJQUVELHdFQUF3RTtJQUNoRSwrQkFBWSxHQUFwQixVQUFxQixPQUFlO1FBQ2hDLHlHQUF5RztRQUN6RyxJQUFJLElBQUksQ0FBQyxVQUFVLENBQUMsRUFBRSxLQUFLLElBQUksQ0FBQyxLQUFLLENBQUMsTUFBTSxHQUFHLENBQUMsSUFBSSxPQUFPLEtBQUssTUFBTSxFQUFFO1lBQ3BFLElBQUksQ0FBQyxjQUFjLENBQUMsdUJBQXVCLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxDQUFDO1lBQ3JELE9BQU87U0FDVjtRQUNELElBQUksS0FBSyxHQUFXLElBQUksQ0FBQyxVQUFVLENBQUMsRUFBRSxDQUFDO1FBQ3ZDLFFBQVEsT0FBTyxFQUFFO1lBQ2IsS0FBSyxVQUFVO2dCQUNYLElBQUksS0FBSyxLQUFLLENBQUMsRUFBRTtvQkFDYixJQUFJLENBQUMsS0FBSyxDQUFDLEtBQUssR0FBRyxDQUFDLENBQUMsQ0FBQyxRQUFRLEdBQUcsSUFBSSxDQUFDO29CQUN0QyxJQUFJLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxDQUFDLFVBQVUsR0FBRyxJQUFJLENBQUM7b0JBQ3BDLElBQUksQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLENBQUMsUUFBUSxHQUFHLEtBQUssQ0FBQztvQkFDbkMsSUFBSSxDQUFDLFVBQVUsR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsRUFBRSxHQUFHLENBQUMsQ0FBQyxDQUFDO2lCQUN4RDtnQkFDRCxNQUFNO1lBQ1YsS0FBSyxNQUFNO2dCQUNQLElBQUksS0FBSyxLQUFLLElBQUksQ0FBQyxLQUFLLENBQUMsTUFBTSxHQUFHLENBQUMsRUFBRTtvQkFDakMsSUFBSSxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsQ0FBQyxRQUFRLEdBQUcsS0FBSyxDQUFDO29CQUNuQyxJQUFJLENBQUMsS0FBSyxDQUFDLEtBQUssR0FBRyxDQUFDLENBQUMsQ0FBQyxRQUFRLEdBQUcsSUFBSSxDQUFDO29CQUN0QyxJQUFJLENBQUMsS0FBSyxDQUFDLEtBQUssR0FBRyxDQUFDLENBQUMsQ0FBQyxVQUFVLEdBQUcsS0FBSyxDQUFDO29CQUN6QyxJQUFJLENBQUMsVUFBVSxHQUFHLElBQUksQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxFQUFFLEdBQUcsQ0FBQyxDQUFDLENBQUM7aUJBQ3hEO2dCQUNELE1BQU07WUFDVjtnQkFDSSxNQUFNO1NBQ2I7UUFDRCxJQUFJLENBQUMsWUFBWSxDQUFDLDBCQUEwQixDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsQ0FBQztRQUM5RCxJQUFJLENBQUMsYUFBYSxFQUFFLENBQUM7UUFDckIsSUFBSSxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLE9BQU8sQ0FBQyxDQUFDO0lBQzVDLENBQUM7SUFFTyw0QkFBUyxHQUFqQixVQUFrQixRQUFRO1FBQ3RCLElBQUksSUFBSSxDQUFDLFdBQVcsS0FBSyxNQUFNO1lBQUUsSUFBSSxDQUFDLGlCQUFpQixDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsQ0FBQztRQUN2RSxJQUFJLElBQUksQ0FBQyxXQUFXLEtBQUssUUFBUTtZQUFFLElBQUksQ0FBQyxPQUFPLENBQUMsYUFBYSxDQUFDLFFBQVEsQ0FBQyxDQUFDO0lBQzVFLENBQUM7SUFFTyw2Q0FBMEIsR0FBbEM7UUFDSSxJQUFJLENBQUMsWUFBWSxDQUFDLDBCQUEwQixDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsQ0FBQztRQUM5RCxJQUFJLENBQUMsSUFBSSxDQUFDLGNBQWMsRUFBRTtZQUN0QixJQUFJLENBQUMsZUFBZSxHQUFHLE1BQU0sQ0FBQyxVQUFVLEdBQUcsR0FBRyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQztZQUM5RCxJQUFJLENBQUMsb0JBQW9CLEdBQUcsSUFBSSxDQUFDLGVBQWUsQ0FBQztTQUNwRDtJQUNMLENBQUM7SUFFRCx1RUFBdUU7SUFDL0QsZ0NBQWEsR0FBckI7UUFDSSx1Q0FBdUM7UUFDdkMsSUFBSSxDQUFDLGtCQUFrQixHQUFHLElBQUksQ0FBQyxVQUFVLENBQUMsRUFBRSxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUM7UUFFbEUsdURBQXVEO1FBQ3ZELElBQUksQ0FBQyxjQUFjLEdBQUcsSUFBSSxDQUFDLFVBQVUsQ0FBQyxFQUFFLEtBQUssSUFBSSxDQUFDLEtBQUssQ0FBQyxNQUFNLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLFFBQVEsSUFBSSxVQUFVLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsSUFBSSxJQUFJLE1BQU0sQ0FBQztJQUN6SSxDQUFDO0lBRUQsK0VBQStFO0lBQ3ZFLGdDQUFhLEdBQXJCLFVBQXNCLEtBQWE7UUFDL0IsSUFBSSxLQUFLLEtBQUssVUFBVTtZQUFFLElBQUksQ0FBQyxrQkFBa0IsR0FBRyxLQUFLLENBQUM7UUFDMUQsSUFBSSxLQUFLLEtBQUssTUFBTTtZQUFFLElBQUksQ0FBQyxjQUFjLEdBQUcsS0FBSyxDQUFDO0lBQ3RELENBQUM7SUFFTyxpQ0FBYyxHQUF0QixVQUF1QixLQUFhO1FBQ2hDLElBQUksS0FBSyxLQUFLLFVBQVU7WUFBRSxJQUFJLENBQUMsa0JBQWtCLEdBQUcsSUFBSSxDQUFDO1FBQ3pELElBQUksS0FBSyxLQUFLLE1BQU07WUFBRSxJQUFJLENBQUMsY0FBYyxHQUFHLElBQUksQ0FBQztJQUNyRCxDQUFDOztnQkEzS29CLE1BQU07Z0JBQ0MsYUFBYTtnQkFDZixXQUFXO2dCQUNkLFlBQVk7Z0JBQ2IsZUFBZTs7SUFYeEI7UUFBWixLQUFLLENBQUMsSUFBSSxDQUFDOzs4Q0FBa0I7SUFDckI7UUFBUixLQUFLLEVBQUU7OzRDQUFhO0lBQ047UUFBZCxLQUFLLENBQUMsTUFBTSxDQUFDOztpREFBcUI7SUFDMUI7UUFBUixLQUFLLEVBQUU7O3lDQUFpQjtJQUNmO1FBQVQsTUFBTSxFQUFFO2tDQUFvQixZQUFZO3VEQUEwQjtJQXlCbkU7UUFEQyxZQUFZLENBQUMsZUFBZSxFQUFFLENBQUMsUUFBUSxDQUFDLENBQUM7Ozs7NENBS3pDO0lBaERRLFFBQVE7UUFQcEIsU0FBUyxDQUFDO1lBQ1AsUUFBUSxFQUFFLFdBQVc7WUFDckIsMHpHQUF1QztZQUN2QyxhQUFhLEVBQUUsaUJBQWlCLENBQUMsSUFBSTtZQUNyQyxTQUFTLEVBQUUsQ0FBQyxXQUFXLEVBQUUsWUFBWSxDQUFDO1NBQ3pDLENBQUM7eUNBd0J1QixNQUFNO1lBQ0MsYUFBYTtZQUNmLFdBQVc7WUFDZCxZQUFZO1lBQ2IsZUFBZTtPQTFCNUIsUUFBUSxDQWtNcEI7SUFBRCxlQUFDO0NBQUEsQUFsTUQsSUFrTUM7U0FsTVksUUFBUSIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7XHJcbiAgICBDb21wb25lbnQsXHJcbiAgICBWaWV3RW5jYXBzdWxhdGlvbixcclxuICAgIElucHV0LFxyXG4gICAgT25Jbml0LFxyXG4gICAgT25EZXN0cm95LFxyXG4gICAgSG9zdExpc3RlbmVyLFxyXG4gICAgT3V0cHV0LFxyXG4gICAgRXZlbnRFbWl0dGVyLFxyXG4gICAgQWZ0ZXJWaWV3SW5pdCxcclxufSBmcm9tICdAYW5ndWxhci9jb3JlJztcclxuaW1wb3J0IHsgU3Vic2NyaXB0aW9uICwgIHRpbWVyIH0gZnJvbSAncnhqcyc7XHJcbmltcG9ydCB7IGRlYm91bmNlVGltZSB9IGZyb20gJ3J4anMvb3BlcmF0b3JzJztcclxuaW1wb3J0IHsgUm91dGVyIH0gZnJvbSAnQGFuZ3VsYXIvcm91dGVyJztcclxuaW1wb3J0IHsgS2RXaXphcmRFdmVudCB9IGZyb20gJy4va2QtYW5ndWxhci13aXphcmQtZXZlbnQnO1xyXG5pbXBvcnQgeyBLZFdpemFyZFN2YyB9IGZyb20gJy4va2QtYW5ndWxhci13aXphcmQtc3ZjJztcclxuaW1wb3J0IHsgS2REb21FbGVtU3ZjIH0gZnJvbSAnLi4va2QtY29tbW9uL2luZGV4JztcclxuaW1wb3J0IHsgS2RTcGxpdHRlckV2ZW50IH0gZnJvbSAnLi4va2QtYW5ndWxhci1zcGxpdHRlci9pbmRleCc7XHJcblxyXG5leHBvcnQgaW50ZXJmYWNlIElTdGVwIHtcclxuICAgIGlkOiBudW1iZXI7XHJcbiAgICBsYWJlbDogc3RyaW5nO1xyXG4gICAgY29udGVudDogc3RyaW5nO1xyXG4gICAgZGVzY3JpcHRpb24/OiBzdHJpbmc7XHJcbiAgICBpY29uOiBzdHJpbmc7XHJcbiAgICBpY29uVHlwZTogc3RyaW5nO1xyXG4gICAgaXNBY3RpdmU6IGJvb2xlYW47XHJcbiAgICBpc0Rpc2FibGVkOiBib29sZWFuO1xyXG4gICAgdG9vbHRpcFN0cmluZzogc3RyaW5nO1xyXG59XHJcblxyXG5leHBvcnQgaW50ZXJmYWNlIElXaXphcmRBcGkge1xyXG4gICAgdXBkYXRlU3RlcHM/OiAoX2FjdGlvbjogc3RyaW5nKSA9PiB2b2lkO1xyXG4gICAgZW5hYmxlQnV0dG9uPzogKF90eXBlOiBzdHJpbmcpID0+IHZvaWQ7XHJcbiAgICBkaXNhYmxlQnV0dG9uPzogKF90eXBlOiBzdHJpbmcpID0+IHZvaWQ7XHJcbiAgICBnZXRBY3RpdmVTdGVwPzogKCkgPT4gSVN0ZXA7XHJcbiAgICBoaWRlQnV0dG9uPzogKCkgPT4gdm9pZDtcclxuICAgIHNob3dCdXR0b24/OiAoKSA9PiB2b2lkO1xyXG59XHJcblxyXG5AQ29tcG9uZW50KHtcclxuICAgIHNlbGVjdG9yOiAna2Qtd2l6YXJkJyxcclxuICAgIHRlbXBsYXRlVXJsOiAnLi9rZC1hbmd1bGFyLXdpemFyZC5odG1sJyxcclxuICAgIGVuY2Fwc3VsYXRpb246IFZpZXdFbmNhcHN1bGF0aW9uLk5vbmUsXHJcbiAgICBwcm92aWRlcnM6IFtLZFdpemFyZFN2YywgS2REb21FbGVtU3ZjXVxyXG59KVxyXG5cclxuZXhwb3J0IGNsYXNzIEtkV2l6YXJkIGltcGxlbWVudHMgT25Jbml0LCBBZnRlclZpZXdJbml0LCBPbkRlc3Ryb3kge1xyXG4gICAgcHVibGljIGlkOiBzdHJpbmc7XHJcbiAgICBwdWJsaWMgc3RlcHM6IEFycmF5PElTdGVwPiA9IFtdO1xyXG4gICAgcHVibGljIGlzQnV0dG9uSGlkZGVuOiBib29sZWFuID0gZmFsc2U7XHJcbiAgICBwdWJsaWMgaXNQcmV2aW91c0Rpc2FibGVkOiBib29sZWFuID0gdHJ1ZTtcclxuICAgIHB1YmxpYyBpc05leHREaXNhYmxlZDogYm9vbGVhbiA9IGZhbHNlO1xyXG4gICAgcHVibGljIG5leHRCdXR0b25UZXh0OiBzdHJpbmc7XHJcbiAgICBwdWJsaWMgYWN0aXZlU3RlcDogSVN0ZXA7XHJcbiAgICBwdWJsaWMgdG9vbHRpcERpc2FibGVkOiBib29sZWFuID0gZmFsc2U7XHJcbiAgICBwdWJsaWMgaXNNb2JpbGVEZXZpY2U6IGJvb2xlYW47XHJcblxyXG4gICAgcHJpdmF0ZSBfZHJhZ01lbnVTdWI6IFN1YnNjcmlwdGlvbjtcclxuICAgIHByaXZhdGUgX3RvZ2dsZU1lbnVTdWI6IFN1YnNjcmlwdGlvbjtcclxuICAgIHByaXZhdGUgX3Rvb2x0aXBOb3REaXNwbGF5ZWQ6IGJvb2xlYW4gPSBmYWxzZTtcclxuXHJcbiAgICBASW5wdXQoJ2lkJykgd2l6YXJkSWQ6IHN0cmluZztcclxuICAgIEBJbnB1dCgpIGNvbmZpZzogYW55O1xyXG4gICAgQElucHV0KCd0eXBlJykgY29udGVudFR5cGU6IHN0cmluZztcclxuICAgIEBJbnB1dCgpIGFwaTogSVdpemFyZEFwaTtcclxuICAgIEBPdXRwdXQoKSBhY3RpdmVTdGVwRW1pdHRlcjogRXZlbnRFbWl0dGVyPHt9PiA9IG5ldyBFdmVudEVtaXR0ZXIoKTtcclxuXHJcbiAgICBjb25zdHJ1Y3RvcihcclxuICAgICAgICBwcml2YXRlIF9yb3V0ZXI6IFJvdXRlcixcclxuICAgICAgICBwcml2YXRlIF9rZFdpemFyZEV2ZW50OiBLZFdpemFyZEV2ZW50LFxyXG4gICAgICAgIHByaXZhdGUgX2tkV2l6YXJkU3ZjOiBLZFdpemFyZFN2YyxcclxuICAgICAgICBwcml2YXRlIF9rZERvbVN2YzogS2REb21FbGVtU3ZjLFxyXG4gICAgICAgIF9rZFNwbGl0dGVyRXZlbnQ6IEtkU3BsaXR0ZXJFdmVudCxcclxuICAgICkge1xyXG4gICAgICAgIHRoaXMuX2RyYWdNZW51U3ViID0gX2tkU3BsaXR0ZXJFdmVudC5vbkRyYWcoKVxyXG4gICAgICAgICAgICAucGlwZShcclxuICAgICAgICAgICAgICAgIGRlYm91bmNlVGltZSgxMDApXHJcbiAgICAgICAgICAgIClcclxuICAgICAgICAgICAgLnN1YnNjcmliZSgoKTogdm9pZCA9PiB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLl9oYW5kbGVUcmFuc2xhdGVBbmRUb29sdGlwKCk7XHJcbiAgICAgICAgICAgIH0pO1xyXG5cclxuICAgICAgICB0aGlzLl90b2dnbGVNZW51U3ViID0gX2tkU3BsaXR0ZXJFdmVudC5vblRvZ2dsZU1lbnUoKS5zdWJzY3JpYmUoKCk6IHZvaWQgPT4ge1xyXG4gICAgICAgICAgICB0aW1lcig1MDApLnN1YnNjcmliZSgoKTogdm9pZCA9PiB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLl9oYW5kbGVUcmFuc2xhdGVBbmRUb29sdGlwKCk7XHJcbiAgICAgICAgICAgIH0pO1xyXG4gICAgICAgIH0pO1xyXG4gICAgfVxyXG5cclxuICAgIEBIb3N0TGlzdGVuZXIoJ3dpbmRvdzpyZXNpemUnLCBbJyRldmVudCddKVxyXG4gICAgb25SZXNpemUoZXZlbnQ6IGFueSk6IHZvaWQge1xyXG4gICAgICAgIHRpbWVyKDIwMCkuc3Vic2NyaWJlKCgpOiB2b2lkID0+IHtcclxuICAgICAgICAgICAgdGhpcy5faGFuZGxlVHJhbnNsYXRlQW5kVG9vbHRpcCgpO1xyXG4gICAgICAgIH0pO1xyXG4gICAgfVxyXG5cclxuICAgIG5nT25Jbml0KCk6IHZvaWQge1xyXG4gICAgICAgIHRoaXMuaWQgPSB0eXBlb2YgdGhpcy53aXphcmRJZCA9PT0gJ3VuZGVmaW5lZCcgPyAnd2l6YXJkJyA6IHRoaXMud2l6YXJkSWQ7XHJcbiAgICAgICAgdGhpcy5zdGVwcyA9IHRoaXMuX2tkV2l6YXJkU3ZjLnNldEl0ZW0odGhpcy5jb25maWcuc3RlcHMpO1xyXG4gICAgICAgIHRoaXMuX2luaXRBcGkoKTtcclxuICAgICAgICB0aGlzLm5leHRCdXR0b25UZXh0ID0gdGhpcy5jb25maWcubmV4dCB8fCAnTmV4dCc7XHJcbiAgICAgICAgdGhpcy5hY3RpdmVTdGVwID0gdGhpcy5zdGVwc1swXTtcclxuICAgICAgICB0aGlzLl9lbWl0U3RlcCh0aGlzLnN0ZXBzWzBdLmNvbnRlbnQpO1xyXG4gICAgICAgIHRoaXMuaXNNb2JpbGVEZXZpY2UgPSB0aGlzLl9rZERvbVN2Yy5pc01vYmlsZURldmljZSgpO1xyXG4gICAgICAgIGlmICh0aGlzLmlzTW9iaWxlRGV2aWNlIHx8IHdpbmRvdy5pbm5lcldpZHRoIDwgNDgxKSB7XHJcbiAgICAgICAgICAgIHRoaXMudG9vbHRpcERpc2FibGVkID0gdHJ1ZTtcclxuICAgICAgICAgICAgdGhpcy5fdG9vbHRpcE5vdERpc3BsYXllZCA9IHRydWU7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIG5nQWZ0ZXJWaWV3SW5pdCgpOiB2b2lkIHtcclxuICAgICAgICB0aGlzLl9rZFdpemFyZFN2Yy5kaXJlY3Rpb24gPSB0aGlzLl9rZERvbVN2Yy5nZXREb2N1bWVudERpcmVjdGlvbih0cnVlKSB8fCAnbGVmdCc7XHJcbiAgICAgICAgdGhpcy5fa2RXaXphcmRTdmMudG90YWxTdGVwcyA9IHRoaXMuc3RlcHMubGVuZ3RoO1xyXG4gICAgICAgIHRoaXMuX2tkV2l6YXJkU3ZjLnNldENvbnRhaW5lckFuZFN0ZXBFbGVtZW50KHRoaXMuaWQpO1xyXG4gICAgfVxyXG5cclxuICAgIG5nT25EZXN0cm95KCk6IHZvaWQge1xyXG4gICAgICAgIHRoaXMuX2RyYWdNZW51U3ViLnVuc3Vic2NyaWJlKCk7XHJcbiAgICAgICAgdGhpcy5fdG9nZ2xlTWVudVN1Yi51bnN1YnNjcmliZSgpO1xyXG4gICAgfVxyXG5cclxuICAgIC8qIHVzZXIgY2xpY2tzIGFuZCBnb2VzIGJhY2sgdG8gcGFzdCBzdGVwcyAqL1xyXG4gICAgcHVibGljIHNlbGVjdGVkU3RlcChfc3RlcDogSVN0ZXAsIGU6IEV2ZW50KTogdm9pZCB7XHJcbiAgICAgICAgZS5wcmV2ZW50RGVmYXVsdCgpO1xyXG4gICAgICAgIGlmICghX3N0ZXAuaXNEaXNhYmxlZCkge1xyXG4gICAgICAgICAgICAvLyBtYWtlIGNsaWNrZWQgc3RlcCBhY3RpdmVcclxuICAgICAgICAgICAgdGhpcy5zdGVwc1tfc3RlcC5pZF0uaXNBY3RpdmUgPSB0cnVlO1xyXG4gICAgICAgICAgICAvLyBkaXNhYmxlIGFsbCBmdXR1cmUgc3RlcHNcclxuICAgICAgICAgICAgZm9yIChsZXQgaSA9IF9zdGVwLmlkICsgMTsgaSA8IHRoaXMuc3RlcHMubGVuZ3RoOyArK2kpIHtcclxuICAgICAgICAgICAgICAgIHRoaXMuc3RlcHNbaV0uaXNEaXNhYmxlZCA9IHRydWU7XHJcbiAgICAgICAgICAgICAgICBpZiAodGhpcy5zdGVwc1tpXS5pc0FjdGl2ZSkgdGhpcy5zdGVwc1tpXS5pc0FjdGl2ZSA9IGZhbHNlO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIHRoaXMuYWN0aXZlU3RlcCA9IF9zdGVwO1xyXG4gICAgICAgICAgICB0aGlzLl9rZFdpemFyZFN2Yy50cmFuc2xhdGVWaWV3VG9DbGlja2VkRWxlbSh0aGlzLmFjdGl2ZVN0ZXApO1xyXG4gICAgICAgICAgICAvLyB1cGRhdGUgYnV0dG9uJ3MgdGV4dC4gZGlzYWJsZSAncHJldmlvdXMnIGJ1dHRvbiBpZiBmaXJzdCBzdGVwLCBhbmQgY2hhbmdlIHRleHQgb2YgJ25leHQnIGJ1dHRvbiBmb3IgbGFzdCBzdGVwXHJcbiAgICAgICAgICAgIHRoaXMuX3VwZGF0ZUJ1dHRvbigpO1xyXG4gICAgICAgICAgICAvLyBlbWl0IGN1cnJlbnQgc3RlcCB0byBwYXJlbnQgY29tcG9uZW50J3MgRE9NIHRvIHJlbmRlciByZXF1aXJlZCBjb250ZW50XHJcbiAgICAgICAgICAgIHRoaXMuX2VtaXRTdGVwKF9zdGVwLmNvbnRlbnQpO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICBwdWJsaWMgYWN0aW9uQ2xpY2tlZChfYWN0aW9uOiBzdHJpbmcsIGU6IEV2ZW50KTogdm9pZCB7XHJcbiAgICAgICAgZS5wcmV2ZW50RGVmYXVsdCgpO1xyXG4gICAgICAgIC8vIGVtaXQgY2xpY2sgZXZlbnQgdG8gb3V0c2lkZSBvZiBjb21wb25lbnQsIHByb3ZpZGVzIGFjdGlvbiB0eXBlIChuZXh0IG9yIHByZXZpb3VzKSwgY3VycmVudCBzdGVwIGFuZCB3aGV0aGVyIHRoaXMgaXMgbGFzdCBzdGVwXHJcbiAgICAgICAgdGhpcy5fa2RXaXphcmRFdmVudC5hY3Rpb25DbGlja2VkKFxyXG4gICAgICAgICAgICB0aGlzLmlkLFxyXG4gICAgICAgICAgICB7XHJcbiAgICAgICAgICAgICAgICBhY3Rpb246IF9hY3Rpb24sXHJcbiAgICAgICAgICAgICAgICBzdGVwOiB0aGlzLmFjdGl2ZVN0ZXAsXHJcbiAgICAgICAgICAgICAgICBpc0xhc3Q6IHRoaXMuYWN0aXZlU3RlcC5pZCA9PT0gdGhpcy5zdGVwcy5sZW5ndGggLSAxXHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICApO1xyXG4gICAgfVxyXG5cclxuICAgIHB1YmxpYyBvcGVuVG9vdHRpcChlOiBFdmVudCk6IHZvaWQge1xyXG4gICAgICAgIGUucHJldmVudERlZmF1bHQoKTtcclxuICAgICAgICBpZiAodGhpcy5fdG9vbHRpcE5vdERpc3BsYXllZCkgcmV0dXJuO1xyXG4gICAgICAgIGlmICh0aGlzLl9rZFdpemFyZFN2Yy5pc1N0ZXBPdXRPZkJvdW5kcyhlKSkge1xyXG4gICAgICAgICAgICB0aGlzLnRvb2x0aXBEaXNhYmxlZCA9IHRydWU7XHJcbiAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgdGhpcy50b29sdGlwRGlzYWJsZWQgPSBmYWxzZTtcclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfaW5pdEFwaSgpOiB2b2lkIHtcclxuICAgICAgICBpZiAodHlwZW9mIHRoaXMuYXBpICE9PSAndW5kZWZpbmVkJykge1xyXG4gICAgICAgICAgICB0aGlzLmFwaS51cGRhdGVTdGVwcyA9IChfYWN0aW9uOiBzdHJpbmcpOiB2b2lkID0+IHRoaXMuX3VwZGF0ZVN0ZXBzKF9hY3Rpb24pO1xyXG4gICAgICAgICAgICB0aGlzLmFwaS5lbmFibGVCdXR0b24gPSAoX3R5cGU6IHN0cmluZyk6IHZvaWQgPT4gdGhpcy5fZW5hYmxlQnV0dG9uKF90eXBlKTtcclxuICAgICAgICAgICAgdGhpcy5hcGkuZGlzYWJsZUJ1dHRvbiA9IChfdHlwZTogc3RyaW5nKTogdm9pZCA9PiB0aGlzLl9kaXNhYmxlQnV0dG9uKF90eXBlKTtcclxuICAgICAgICAgICAgdGhpcy5hcGkuZ2V0QWN0aXZlU3RlcCA9ICgpOiBJU3RlcCA9PiB0aGlzLmFjdGl2ZVN0ZXA7XHJcbiAgICAgICAgICAgIHRoaXMuYXBpLmhpZGVCdXR0b24gPSAoKTogdm9pZCA9PiB7IHRoaXMuaXNCdXR0b25IaWRkZW4gPSB0cnVlOyB9O1xyXG4gICAgICAgICAgICB0aGlzLmFwaS5zaG93QnV0dG9uID0gKCk6IHZvaWQgPT4geyB0aGlzLmlzQnV0dG9uSGlkZGVuID0gZmFsc2U7IH07XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIC8qIHVwZGF0ZSBTdGVwcyB3aGVuIHZhbGlkYXRpb24gKGRvbmUgYnkgYXBwbGljYXRpb24gdmlhIGFwaSkgaXMgZG9uZSAqL1xyXG4gICAgcHJpdmF0ZSBfdXBkYXRlU3RlcHMoX2FjdGlvbjogc3RyaW5nKTogdm9pZCB7XHJcbiAgICAgICAgLy8gYnJvYWRjYXN0ICduZXh0JyBidXR0b24gaXMgY2xpY2tlZCB3aGVuIGF0IGxhc3Qgc3RlcCBhbmQgd2hlbiB2YWxpZGF0aW9uIChkb25lIGJ5IGFwcGxpY2F0aW9uKSBpcyBkb25lXHJcbiAgICAgICAgaWYgKHRoaXMuYWN0aXZlU3RlcC5pZCA9PT0gdGhpcy5zdGVwcy5sZW5ndGggLSAxICYmIF9hY3Rpb24gPT09ICduZXh0Jykge1xyXG4gICAgICAgICAgICB0aGlzLl9rZFdpemFyZEV2ZW50Lm5leHRDbGlja2VkV2hlbkxhc3RTdGVwKHRoaXMuaWQpO1xyXG4gICAgICAgICAgICByZXR1cm47XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGxldCBpbmRleDogbnVtYmVyID0gdGhpcy5hY3RpdmVTdGVwLmlkO1xyXG4gICAgICAgIHN3aXRjaCAoX2FjdGlvbikge1xyXG4gICAgICAgICAgICBjYXNlICdwcmV2aW91cyc6XHJcbiAgICAgICAgICAgICAgICBpZiAoaW5kZXggIT09IDApIHtcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLnN0ZXBzW2luZGV4IC0gMV0uaXNBY3RpdmUgPSB0cnVlO1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuc3RlcHNbaW5kZXhdLmlzRGlzYWJsZWQgPSB0cnVlO1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuc3RlcHNbaW5kZXhdLmlzQWN0aXZlID0gZmFsc2U7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5hY3RpdmVTdGVwID0gdGhpcy5zdGVwc1t0aGlzLmFjdGl2ZVN0ZXAuaWQgLSAxXTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgICAgICBjYXNlICduZXh0JzpcclxuICAgICAgICAgICAgICAgIGlmIChpbmRleCAhPT0gdGhpcy5zdGVwcy5sZW5ndGggLSAxKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5zdGVwc1tpbmRleF0uaXNBY3RpdmUgPSBmYWxzZTtcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLnN0ZXBzW2luZGV4ICsgMV0uaXNBY3RpdmUgPSB0cnVlO1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuc3RlcHNbaW5kZXggKyAxXS5pc0Rpc2FibGVkID0gZmFsc2U7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5hY3RpdmVTdGVwID0gdGhpcy5zdGVwc1t0aGlzLmFjdGl2ZVN0ZXAuaWQgKyAxXTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgICAgICBkZWZhdWx0OlxyXG4gICAgICAgICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIHRoaXMuX2tkV2l6YXJkU3ZjLnRyYW5zbGF0ZVZpZXdUb0NsaWNrZWRFbGVtKHRoaXMuYWN0aXZlU3RlcCk7XHJcbiAgICAgICAgdGhpcy5fdXBkYXRlQnV0dG9uKCk7XHJcbiAgICAgICAgdGhpcy5fZW1pdFN0ZXAodGhpcy5hY3RpdmVTdGVwLmNvbnRlbnQpO1xyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX2VtaXRTdGVwKF9jb250ZW50KTogdm9pZCB7XHJcbiAgICAgICAgaWYgKHRoaXMuY29udGVudFR5cGUgPT09ICdodG1sJykgdGhpcy5hY3RpdmVTdGVwRW1pdHRlci5lbWl0KF9jb250ZW50KTtcclxuICAgICAgICBpZiAodGhpcy5jb250ZW50VHlwZSA9PT0gJ3JvdXRlcicpIHRoaXMuX3JvdXRlci5uYXZpZ2F0ZUJ5VXJsKF9jb250ZW50KTtcclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF9oYW5kbGVUcmFuc2xhdGVBbmRUb29sdGlwKCk6IHZvaWQge1xyXG4gICAgICAgIHRoaXMuX2tkV2l6YXJkU3ZjLnRyYW5zbGF0ZVZpZXdUb0NsaWNrZWRFbGVtKHRoaXMuYWN0aXZlU3RlcCk7XHJcbiAgICAgICAgaWYgKCF0aGlzLmlzTW9iaWxlRGV2aWNlKSB7XHJcbiAgICAgICAgICAgIHRoaXMudG9vbHRpcERpc2FibGVkID0gd2luZG93LmlubmVyV2lkdGggPiA0ODAgPyBmYWxzZSA6IHRydWU7XHJcbiAgICAgICAgICAgIHRoaXMuX3Rvb2x0aXBOb3REaXNwbGF5ZWQgPSB0aGlzLnRvb2x0aXBEaXNhYmxlZDtcclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgLyogc2V0IHRoZSB0ZXh0IG9mIG5leHQgYW5kIHByZXZpb3VzIGJ1dHRvbnMgZGVwZW5kaW5nIG9uIHdoaWNoIHN0ZXAgKi9cclxuICAgIHByaXZhdGUgX3VwZGF0ZUJ1dHRvbigpOiB2b2lkIHtcclxuICAgICAgICAvLyBkaXNhYmxlIGZpcnN0IHN0ZXAncyBwcmV2aW91cyBidXR0b25cclxuICAgICAgICB0aGlzLmlzUHJldmlvdXNEaXNhYmxlZCA9IHRoaXMuYWN0aXZlU3RlcC5pZCA9PT0gMCA/IHRydWUgOiBmYWxzZTtcclxuXHJcbiAgICAgICAgLy8gY2hhbmdlIHRleHQgb2YgbGFzdCBzdGVwJ3MgbmV4dCBidXR0b24gdG8gJ2NvbXBsZXRlJ1xyXG4gICAgICAgIHRoaXMubmV4dEJ1dHRvblRleHQgPSB0aGlzLmFjdGl2ZVN0ZXAuaWQgPT09IHRoaXMuc3RlcHMubGVuZ3RoIC0gMSA/IHRoaXMuY29uZmlnLmNvbXBsZXRlIHx8ICdDb21wbGV0ZScgOiB0aGlzLmNvbmZpZy5uZXh0IHx8ICdOZXh0JztcclxuICAgIH1cclxuXHJcbiAgICAvKiBlbmFibGUgZXh0ZXJuYWwgY29tcG9uZW50cyB0byBlbmFibGUgb3IgZGlzYWJsZSBuZXh0IGFuZCBwcmV2aW91cyBidXR0b25zICovXHJcbiAgICBwcml2YXRlIF9lbmFibGVCdXR0b24oX3R5cGU6IHN0cmluZyk6IHZvaWQge1xyXG4gICAgICAgIGlmIChfdHlwZSA9PT0gJ3ByZXZpb3VzJykgdGhpcy5pc1ByZXZpb3VzRGlzYWJsZWQgPSBmYWxzZTtcclxuICAgICAgICBpZiAoX3R5cGUgPT09ICduZXh0JykgdGhpcy5pc05leHREaXNhYmxlZCA9IGZhbHNlO1xyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX2Rpc2FibGVCdXR0b24oX3R5cGU6IHN0cmluZyk6IHZvaWQge1xyXG4gICAgICAgIGlmIChfdHlwZSA9PT0gJ3ByZXZpb3VzJykgdGhpcy5pc1ByZXZpb3VzRGlzYWJsZWQgPSB0cnVlO1xyXG4gICAgICAgIGlmIChfdHlwZSA9PT0gJ25leHQnKSB0aGlzLmlzTmV4dERpc2FibGVkID0gdHJ1ZTtcclxuICAgIH1cclxufVxyXG4iXX0=