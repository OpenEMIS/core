import { __decorate, __metadata } from "tslib";
import { Component, Input } from '@angular/core';
// import { Response } from '@angular/http';
import { HttpClient } from '@angular/common/http';
import { DomSanitizer } from '@angular/platform-browser';
var KdCodeblock = /** @class */ (function () {
    // trustHTMLcode: SafeUrl;
    function KdCodeblock(_sanitizer, _http) {
        this._sanitizer = _sanitizer;
        this._http = _http;
        this.Prism = require('prismjs');
        this.code = null;
    }
    KdCodeblock.prototype.ngOnInit = function () {
        // let tempStr = this.code;
        // let regex = new RegExp(this._getSpaces(tempStr), 'g');
        // // tempStr = tempStr.replace(/  +/g, '').trim();
        // tempStr = tempStr.replace(regex, '').trim();
        // tempStr = this.Prism.highlight(tempStr, this._getType(this.language));
        // this._sanitizer.bypassSecurityTrustHtml(tempStr);
        // this.code = tempStr;
        var _this = this;
        var tempStr;
        if (typeof this.path !== 'undefined') {
            try {
                this._httpSub = this._http.get(this.path)
                    // .pipe(
                    //     map((respond: Response): any => respond.text())
                    // )
                    .subscribe(function (data) {
                    console.log('Codeblock', data);
                    tempStr = data.trim();
                    _this._updateCodeblock(tempStr);
                }, function (error) { }, function () { });
            }
            catch (err) { }
        }
        else {
            tempStr = this.code;
            this._updateCodeblock(tempStr);
        }
    };
    KdCodeblock.prototype._updateCodeblock = function (tempStr) {
        var regex = new RegExp(this._getSpaces(tempStr), 'g');
        tempStr = tempStr.replace(regex, '').trim();
        tempStr = this.Prism.highlight(tempStr, this._getType(this.language));
        this._sanitizer.bypassSecurityTrustHtml(tempStr);
        this._updatedCode = tempStr;
    };
    KdCodeblock.prototype._getSpaces = function (_text) {
        var spacesArr = _text.match(/[^\S\n\t]+/g);
        var removeSpace = null;
        if (spacesArr !== null) {
            for (var i = 0; i < spacesArr.length; i++) {
                if (removeSpace === null && spacesArr[i].length > 1) {
                    removeSpace = spacesArr[i];
                }
                else if (spacesArr[i].length > 1 && removeSpace.length > spacesArr[i].length) {
                    removeSpace = spacesArr[i];
                }
            }
        }
        return removeSpace;
    };
    KdCodeblock.prototype._getType = function (_type) {
        if (_type === 'javascript' || _type === 'js' || _type === 'typescript') {
            return this.Prism.languages.javascript;
        }
        else if (_type === 'html') {
            return this.Prism.languages.html;
        }
        else if (_type === 'css') {
            return this.Prism.languages.css;
        }
        else {
            return this.Prism.languages.markup;
        }
    };
    KdCodeblock.ctorParameters = function () { return [
        { type: DomSanitizer },
        { type: HttpClient }
    ]; };
    __decorate([
        Input(),
        __metadata("design:type", String)
    ], KdCodeblock.prototype, "code", void 0);
    __decorate([
        Input(),
        __metadata("design:type", String)
    ], KdCodeblock.prototype, "path", void 0);
    __decorate([
        Input(),
        __metadata("design:type", String)
    ], KdCodeblock.prototype, "language", void 0);
    KdCodeblock = __decorate([
        Component({
            selector: 'kd-codeblock',
            template: "\n            <pre class='language-javascript' style='font-size: 12px'><code class='language-javascript' [innerHtml]='_updatedCode'></code></pre>\n    "
        }),
        __metadata("design:paramtypes", [DomSanitizer, HttpClient])
    ], KdCodeblock);
    return KdCodeblock;
}());
export { KdCodeblock };
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoia2QtYW5ndWxhci1jb2RlYmxvY2suanMiLCJzb3VyY2VSb290Ijoibmc6Ly9vcGVuZW1pcy1zdHlsZWd1aWRlLWxpYi8iLCJzb3VyY2VzIjpbImtkLWNvbXBvbmVudHMva2QtYW5ndWxhci1jb2RlYmxvY2sva2QtYW5ndWxhci1jb2RlYmxvY2sudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IjtBQUFBLE9BQU8sRUFDSCxTQUFTLEVBQ1QsS0FBSyxFQUVSLE1BQU0sZUFBZSxDQUFDO0FBQ3ZCLDRDQUE0QztBQUM1QyxPQUFPLEVBQUUsVUFBVSxFQUFDLE1BQU0sc0JBQXNCLENBQUM7QUFHakQsT0FBTyxFQUFFLFlBQVksRUFBRSxNQUFNLDJCQUEyQixDQUFDO0FBV3pEO0lBU0ksMEJBQTBCO0lBQzFCLHFCQUFvQixVQUF3QixFQUFVLEtBQWlCO1FBQW5ELGVBQVUsR0FBVixVQUFVLENBQWM7UUFBVSxVQUFLLEdBQUwsS0FBSyxDQUFZO1FBUi9ELFVBQUssR0FBRyxPQUFPLENBQUMsU0FBUyxDQUFDLENBQUM7UUFHMUIsU0FBSSxHQUFXLElBQUksQ0FBQztJQUs4QyxDQUFDO0lBRTVFLDhCQUFRLEdBQVI7UUFDSSwyQkFBMkI7UUFDM0IseURBQXlEO1FBQ3pELG1EQUFtRDtRQUNuRCwrQ0FBK0M7UUFDL0MseUVBQXlFO1FBQ3pFLG9EQUFvRDtRQUNwRCx1QkFBdUI7UUFQM0IsaUJBZ0NDO1FBdkJHLElBQUksT0FBZSxDQUFDO1FBQ3BCLElBQUksT0FBTyxJQUFJLENBQUMsSUFBSSxLQUFLLFdBQVcsRUFBRTtZQUNsQyxJQUFJO2dCQUNBLElBQUksQ0FBQyxRQUFRLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQztvQkFDckMsU0FBUztvQkFDVCxzREFBc0Q7b0JBQ3RELElBQUk7cUJBQ0gsU0FBUyxDQUNOLFVBQUMsSUFBUztvQkFDTixPQUFPLENBQUMsR0FBRyxDQUFDLFdBQVcsRUFBQyxJQUFJLENBQUMsQ0FBQztvQkFDOUIsT0FBTyxHQUFHLElBQUksQ0FBQyxJQUFJLEVBQUUsQ0FBQztvQkFDdEIsS0FBSSxDQUFDLGdCQUFnQixDQUFDLE9BQU8sQ0FBQyxDQUFDO2dCQUNuQyxDQUFDLEVBQ0QsVUFBQyxLQUFVLElBQWEsQ0FBQyxFQUN6QixjQUFjLENBQUMsQ0FDbEIsQ0FBQzthQUNUO1lBQUMsT0FBTyxHQUFHLEVBQUUsR0FBRztTQUNwQjthQUNJO1lBQ0QsT0FBTyxHQUFHLElBQUksQ0FBQyxJQUFJLENBQUM7WUFDcEIsSUFBSSxDQUFDLGdCQUFnQixDQUFDLE9BQU8sQ0FBQyxDQUFDO1NBQ2xDO0lBRUwsQ0FBQztJQUVPLHNDQUFnQixHQUF4QixVQUF5QixPQUFlO1FBQ3BDLElBQUksS0FBSyxHQUFHLElBQUksTUFBTSxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsT0FBTyxDQUFDLEVBQUUsR0FBRyxDQUFDLENBQUM7UUFDdEQsT0FBTyxHQUFHLE9BQU8sQ0FBQyxPQUFPLENBQUMsS0FBSyxFQUFFLEVBQUUsQ0FBQyxDQUFDLElBQUksRUFBRSxDQUFDO1FBQzVDLE9BQU8sR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDLFNBQVMsQ0FBQyxPQUFPLEVBQUUsSUFBSSxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQztRQUN0RSxJQUFJLENBQUMsVUFBVSxDQUFDLHVCQUF1QixDQUFDLE9BQU8sQ0FBQyxDQUFDO1FBQ2pELElBQUksQ0FBQyxZQUFZLEdBQUcsT0FBTyxDQUFDO0lBQ2hDLENBQUM7SUFFTyxnQ0FBVSxHQUFsQixVQUFtQixLQUFhO1FBQzVCLElBQUksU0FBUyxHQUFHLEtBQUssQ0FBQyxLQUFLLENBQUMsYUFBYSxDQUFDLENBQUM7UUFDM0MsSUFBSSxXQUFXLEdBQUcsSUFBSSxDQUFDO1FBQ3ZCLElBQUksU0FBUyxLQUFLLElBQUksRUFBRTtZQUNwQixLQUFLLElBQUksQ0FBQyxHQUFXLENBQUMsRUFBRSxDQUFDLEdBQUcsU0FBUyxDQUFDLE1BQU0sRUFBRSxDQUFDLEVBQUUsRUFBRTtnQkFDL0MsSUFBSSxXQUFXLEtBQUssSUFBSSxJQUFJLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLEdBQUcsQ0FBQyxFQUFFO29CQUNqRCxXQUFXLEdBQUcsU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDO2lCQUM5QjtxQkFDSSxJQUFJLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLEdBQUcsQ0FBQyxJQUFJLFdBQVcsQ0FBQyxNQUFNLEdBQUcsU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sRUFBRTtvQkFDMUUsV0FBVyxHQUFHLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQztpQkFDOUI7YUFDSjtTQUNKO1FBQ0QsT0FBTyxXQUFXLENBQUM7SUFDdkIsQ0FBQztJQUVPLDhCQUFRLEdBQWhCLFVBQWlCLEtBQWE7UUFDMUIsSUFBSSxLQUFLLEtBQUssWUFBWSxJQUFJLEtBQUssS0FBSyxJQUFJLElBQUksS0FBSyxLQUFLLFlBQVksRUFBRTtZQUNwRSxPQUFPLElBQUksQ0FBQyxLQUFLLENBQUMsU0FBUyxDQUFDLFVBQVUsQ0FBQztTQUMxQzthQUNJLElBQUksS0FBSyxLQUFLLE1BQU0sRUFBRTtZQUN2QixPQUFPLElBQUksQ0FBQyxLQUFLLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQztTQUNwQzthQUNJLElBQUksS0FBSyxLQUFLLEtBQUssRUFBRTtZQUN0QixPQUFPLElBQUksQ0FBQyxLQUFLLENBQUMsU0FBUyxDQUFDLEdBQUcsQ0FBQztTQUNuQzthQUNJO1lBQ0QsT0FBTyxJQUFJLENBQUMsS0FBSyxDQUFDLFNBQVMsQ0FBQyxNQUFNLENBQUM7U0FDdEM7SUFDTCxDQUFDOztnQkF6RStCLFlBQVk7Z0JBQWlCLFVBQVU7O0lBTDlEO1FBQVIsS0FBSyxFQUFFOzs2Q0FBcUI7SUFDcEI7UUFBUixLQUFLLEVBQUU7OzZDQUFjO0lBQ2I7UUFBUixLQUFLLEVBQUU7O2lEQUFrQjtJQVBqQixXQUFXO1FBUHZCLFNBQVMsQ0FBQztZQUNQLFFBQVEsRUFBRSxjQUFjO1lBQ3hCLFFBQVEsRUFBRSx5SkFFVDtTQUNKLENBQUM7eUNBWWtDLFlBQVksRUFBaUIsVUFBVTtPQVY5RCxXQUFXLENBb0Z2QjtJQUFELGtCQUFDO0NBQUEsQUFwRkQsSUFvRkM7U0FwRlksV0FBVyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7XHJcbiAgICBDb21wb25lbnQsXHJcbiAgICBJbnB1dCxcclxuICAgIE9uSW5pdFxyXG59IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xyXG4vLyBpbXBvcnQgeyBSZXNwb25zZSB9IGZyb20gJ0Bhbmd1bGFyL2h0dHAnO1xyXG5pbXBvcnQgeyBIdHRwQ2xpZW50fSBmcm9tICdAYW5ndWxhci9jb21tb24vaHR0cCc7XHJcbmltcG9ydCB7IFN1YnNjcmlwdGlvbiB9IGZyb20gJ3J4anMnO1xyXG5pbXBvcnQgeyBtYXAgfSBmcm9tICdyeGpzL29wZXJhdG9ycyc7XHJcbmltcG9ydCB7IERvbVNhbml0aXplciB9IGZyb20gJ0Bhbmd1bGFyL3BsYXRmb3JtLWJyb3dzZXInO1xyXG5cclxuZGVjbGFyZSB2YXIgcmVxdWlyZTogYW55O1xyXG5cclxuQENvbXBvbmVudCh7XHJcbiAgICBzZWxlY3RvcjogJ2tkLWNvZGVibG9jaycsXHJcbiAgICB0ZW1wbGF0ZTogYFxyXG4gICAgICAgICAgICA8cHJlIGNsYXNzPSdsYW5ndWFnZS1qYXZhc2NyaXB0JyBzdHlsZT0nZm9udC1zaXplOiAxMnB4Jz48Y29kZSBjbGFzcz0nbGFuZ3VhZ2UtamF2YXNjcmlwdCcgW2lubmVySHRtbF09J191cGRhdGVkQ29kZSc+PC9jb2RlPjwvcHJlPlxyXG4gICAgYCxcclxufSlcclxuXHJcbmV4cG9ydCBjbGFzcyBLZENvZGVibG9jayBpbXBsZW1lbnRzIE9uSW5pdCB7XHJcbiAgICBwdWJsaWMgX3VwZGF0ZWRDb2RlOiBzdHJpbmc7XHJcbiAgICBwcml2YXRlIFByaXNtID0gcmVxdWlyZSgncHJpc21qcycpO1xyXG4gICAgcHJpdmF0ZSBfaHR0cFN1YjogU3Vic2NyaXB0aW9uO1xyXG5cclxuICAgIEBJbnB1dCgpIGNvZGU6IHN0cmluZyA9IG51bGw7XHJcbiAgICBASW5wdXQoKSBwYXRoOiBzdHJpbmc7XHJcbiAgICBASW5wdXQoKSBsYW5ndWFnZTogc3RyaW5nO1xyXG5cclxuICAgIC8vIHRydXN0SFRNTGNvZGU6IFNhZmVVcmw7XHJcbiAgICBjb25zdHJ1Y3Rvcihwcml2YXRlIF9zYW5pdGl6ZXI6IERvbVNhbml0aXplciwgcHJpdmF0ZSBfaHR0cDogSHR0cENsaWVudCkgeyB9XHJcblxyXG4gICAgbmdPbkluaXQoKTogdm9pZCB7XHJcbiAgICAgICAgLy8gbGV0IHRlbXBTdHIgPSB0aGlzLmNvZGU7XHJcbiAgICAgICAgLy8gbGV0IHJlZ2V4ID0gbmV3IFJlZ0V4cCh0aGlzLl9nZXRTcGFjZXModGVtcFN0ciksICdnJyk7XHJcbiAgICAgICAgLy8gLy8gdGVtcFN0ciA9IHRlbXBTdHIucmVwbGFjZSgvICArL2csICcnKS50cmltKCk7XHJcbiAgICAgICAgLy8gdGVtcFN0ciA9IHRlbXBTdHIucmVwbGFjZShyZWdleCwgJycpLnRyaW0oKTtcclxuICAgICAgICAvLyB0ZW1wU3RyID0gdGhpcy5QcmlzbS5oaWdobGlnaHQodGVtcFN0ciwgdGhpcy5fZ2V0VHlwZSh0aGlzLmxhbmd1YWdlKSk7XHJcbiAgICAgICAgLy8gdGhpcy5fc2FuaXRpemVyLmJ5cGFzc1NlY3VyaXR5VHJ1c3RIdG1sKHRlbXBTdHIpO1xyXG4gICAgICAgIC8vIHRoaXMuY29kZSA9IHRlbXBTdHI7XHJcblxyXG4gICAgICAgIGxldCB0ZW1wU3RyOiBzdHJpbmc7XHJcbiAgICAgICAgaWYgKHR5cGVvZiB0aGlzLnBhdGggIT09ICd1bmRlZmluZWQnKSB7XHJcbiAgICAgICAgICAgIHRyeSB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLl9odHRwU3ViID0gdGhpcy5faHR0cC5nZXQodGhpcy5wYXRoKVxyXG4gICAgICAgICAgICAgICAgICAgIC8vIC5waXBlKFxyXG4gICAgICAgICAgICAgICAgICAgIC8vICAgICBtYXAoKHJlc3BvbmQ6IFJlc3BvbnNlKTogYW55ID0+IHJlc3BvbmQudGV4dCgpKVxyXG4gICAgICAgICAgICAgICAgICAgIC8vIClcclxuICAgICAgICAgICAgICAgICAgICAuc3Vic2NyaWJlKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAoZGF0YTogYW55KTogdm9pZCA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb25zb2xlLmxvZygnQ29kZWJsb2NrJyxkYXRhKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRlbXBTdHIgPSBkYXRhLnRyaW0oKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuX3VwZGF0ZUNvZGVibG9jayh0ZW1wU3RyKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgKGVycm9yOiBhbnkpOiB2b2lkID0+IHsgfSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgKCk6IHZvaWQgPT4geyB9XHJcbiAgICAgICAgICAgICAgICAgICAgKTtcclxuICAgICAgICAgICAgfSBjYXRjaCAoZXJyKSB7IH1cclxuICAgICAgICB9XHJcbiAgICAgICAgZWxzZSB7XHJcbiAgICAgICAgICAgIHRlbXBTdHIgPSB0aGlzLmNvZGU7XHJcbiAgICAgICAgICAgIHRoaXMuX3VwZGF0ZUNvZGVibG9jayh0ZW1wU3RyKTtcclxuICAgICAgICB9XHJcblxyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX3VwZGF0ZUNvZGVibG9jayh0ZW1wU3RyOiBzdHJpbmcpOiB2b2lkIHtcclxuICAgICAgICBsZXQgcmVnZXggPSBuZXcgUmVnRXhwKHRoaXMuX2dldFNwYWNlcyh0ZW1wU3RyKSwgJ2cnKTtcclxuICAgICAgICB0ZW1wU3RyID0gdGVtcFN0ci5yZXBsYWNlKHJlZ2V4LCAnJykudHJpbSgpO1xyXG4gICAgICAgIHRlbXBTdHIgPSB0aGlzLlByaXNtLmhpZ2hsaWdodCh0ZW1wU3RyLCB0aGlzLl9nZXRUeXBlKHRoaXMubGFuZ3VhZ2UpKTtcclxuICAgICAgICB0aGlzLl9zYW5pdGl6ZXIuYnlwYXNzU2VjdXJpdHlUcnVzdEh0bWwodGVtcFN0cik7XHJcbiAgICAgICAgdGhpcy5fdXBkYXRlZENvZGUgPSB0ZW1wU3RyO1xyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX2dldFNwYWNlcyhfdGV4dDogc3RyaW5nKTogc3RyaW5nIHtcclxuICAgICAgICBsZXQgc3BhY2VzQXJyID0gX3RleHQubWF0Y2goL1teXFxTXFxuXFx0XSsvZyk7XHJcbiAgICAgICAgbGV0IHJlbW92ZVNwYWNlID0gbnVsbDtcclxuICAgICAgICBpZiAoc3BhY2VzQXJyICE9PSBudWxsKSB7XHJcbiAgICAgICAgICAgIGZvciAobGV0IGk6IG51bWJlciA9IDA7IGkgPCBzcGFjZXNBcnIubGVuZ3RoOyBpKyspIHtcclxuICAgICAgICAgICAgICAgIGlmIChyZW1vdmVTcGFjZSA9PT0gbnVsbCAmJiBzcGFjZXNBcnJbaV0ubGVuZ3RoID4gMSkge1xyXG4gICAgICAgICAgICAgICAgICAgIHJlbW92ZVNwYWNlID0gc3BhY2VzQXJyW2ldO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgZWxzZSBpZiAoc3BhY2VzQXJyW2ldLmxlbmd0aCA+IDEgJiYgcmVtb3ZlU3BhY2UubGVuZ3RoID4gc3BhY2VzQXJyW2ldLmxlbmd0aCkge1xyXG4gICAgICAgICAgICAgICAgICAgIHJlbW92ZVNwYWNlID0gc3BhY2VzQXJyW2ldO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgICAgIHJldHVybiByZW1vdmVTcGFjZTtcclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF9nZXRUeXBlKF90eXBlOiBzdHJpbmcpOiBhbnkge1xyXG4gICAgICAgIGlmIChfdHlwZSA9PT0gJ2phdmFzY3JpcHQnIHx8IF90eXBlID09PSAnanMnIHx8IF90eXBlID09PSAndHlwZXNjcmlwdCcpIHtcclxuICAgICAgICAgICAgcmV0dXJuIHRoaXMuUHJpc20ubGFuZ3VhZ2VzLmphdmFzY3JpcHQ7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGVsc2UgaWYgKF90eXBlID09PSAnaHRtbCcpIHtcclxuICAgICAgICAgICAgcmV0dXJuIHRoaXMuUHJpc20ubGFuZ3VhZ2VzLmh0bWw7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGVsc2UgaWYgKF90eXBlID09PSAnY3NzJykge1xyXG4gICAgICAgICAgICByZXR1cm4gdGhpcy5QcmlzbS5sYW5ndWFnZXMuY3NzO1xyXG4gICAgICAgIH1cclxuICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgcmV0dXJuIHRoaXMuUHJpc20ubGFuZ3VhZ2VzLm1hcmt1cDtcclxuICAgICAgICB9XHJcbiAgICB9XHJcbn1cclxuIl19