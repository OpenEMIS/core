import { __decorate, __metadata } from "tslib";
import { Component, ViewEncapsulation } from '@angular/core';
import { ToasterService, ToasterConfig } from 'angular2-toaster';
import { KdAlertEvent } from './kd-alert-event';
var KdAlert = /** @class */ (function () {
    function KdAlert(_toasterService, _kdAlertEvent) {
        this._toasterService = _toasterService;
        this._kdAlertEvent = _kdAlertEvent;
        this._toasterDefaultConfig = {
            showCloseButton: true,
            tapToDismiss: false,
            timeout: -1,
            limit: 5,
            positionClass: 'toast-top-right'
        };
    }
    KdAlert.prototype.ngOnInit = function () {
        this.registerAlertBroadcast();
    };
    KdAlert.prototype.registerAlertBroadcast = function () {
        var _this = this;
        this._kdAlertEvent.on()
            .subscribe(function (_toast) {
            _this._config = Object.assign({}, _this._toasterDefaultConfig, _toast);
            _this._toasterconfig = new ToasterConfig(_this._config);
            _this._toasterService.pop(_toast);
            // this._toasterService.pop('success', 'Args Title', 'Args Body');;
        });
    };
    KdAlert.ctorParameters = function () { return [
        { type: ToasterService },
        { type: KdAlertEvent }
    ]; };
    KdAlert = __decorate([
        Component({
            selector: 'kd-alert',
            providers: [ToasterService, KdAlertEvent],
            encapsulation: ViewEncapsulation.None,
            template: "\n        <toaster-container [toasterconfig]='_toasterconfig'>\n        </toaster-container>\n       "
        }),
        __metadata("design:paramtypes", [ToasterService,
            KdAlertEvent])
    ], KdAlert);
    return KdAlert;
}());
export { KdAlert };
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoia2QtYWxlcnQuanMiLCJzb3VyY2VSb290Ijoibmc6Ly9vcGVuZW1pcy1zdHlsZWd1aWRlLWxpYi8iLCJzb3VyY2VzIjpbImtkLWNvbXBvbmVudHMva2QtYW5ndWxhci1hbGVydC9rZC1hbGVydC50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiO0FBQUEsT0FBTyxFQUFFLFNBQVMsRUFBRSxpQkFBaUIsRUFBVSxNQUFNLGVBQWUsQ0FBQztBQUNyRSxPQUFPLEVBQUUsY0FBYyxFQUFFLGFBQWEsRUFBQyxNQUFNLGtCQUFrQixDQUFDO0FBQ2hFLE9BQU8sRUFBRSxZQUFZLEVBQUUsTUFBTSxrQkFBa0IsQ0FBQztBQVloRDtJQVdJLGlCQUNZLGVBQStCLEVBQy9CLGFBQTJCO1FBRDNCLG9CQUFlLEdBQWYsZUFBZSxDQUFnQjtRQUMvQixrQkFBYSxHQUFiLGFBQWEsQ0FBYztRQVYvQiwwQkFBcUIsR0FBUTtZQUNqQyxlQUFlLEVBQUUsSUFBSTtZQUNyQixZQUFZLEVBQUUsS0FBSztZQUNuQixPQUFPLEVBQUUsQ0FBQyxDQUFDO1lBQ1gsS0FBSyxFQUFFLENBQUM7WUFDUixhQUFhLEVBQUUsaUJBQWlCO1NBQ25DLENBQUM7SUFLRSxDQUFDO0lBRUwsMEJBQVEsR0FBUjtRQUNJLElBQUksQ0FBQyxzQkFBc0IsRUFBRSxDQUFDO0lBQ2xDLENBQUM7SUFFRCx3Q0FBc0IsR0FBdEI7UUFBQSxpQkFRQztRQVBHLElBQUksQ0FBQyxhQUFhLENBQUMsRUFBRSxFQUFFO2FBQ2xCLFNBQVMsQ0FBQyxVQUFBLE1BQU07WUFDYixLQUFJLENBQUMsT0FBTyxHQUFHLE1BQU0sQ0FBQyxNQUFNLENBQUMsRUFBRSxFQUFFLEtBQUksQ0FBQyxxQkFBcUIsRUFBRSxNQUFNLENBQUMsQ0FBQztZQUNyRSxLQUFJLENBQUMsY0FBYyxHQUFHLElBQUksYUFBYSxDQUFDLEtBQUksQ0FBQyxPQUFPLENBQUMsQ0FBQztZQUN0RCxLQUFJLENBQUMsZUFBZSxDQUFDLEdBQUcsQ0FBQyxNQUFNLENBQUMsQ0FBQztZQUNqQyxtRUFBbUU7UUFDdkUsQ0FBQyxDQUFDLENBQUM7SUFDWCxDQUFDOztnQkFoQjRCLGNBQWM7Z0JBQ2hCLFlBQVk7O0lBYjlCLE9BQU87UUFWbkIsU0FBUyxDQUFDO1lBQ1AsUUFBUSxFQUFFLFVBQVU7WUFDcEIsU0FBUyxFQUFFLENBQUMsY0FBYyxFQUFFLFlBQVksQ0FBQztZQUN6QyxhQUFhLEVBQUUsaUJBQWlCLENBQUMsSUFBSTtZQUNyQyxRQUFRLEVBQUUsdUdBR047U0FDUCxDQUFDO3lDQWMrQixjQUFjO1lBQ2hCLFlBQVk7T0FiOUIsT0FBTyxDQThCbkI7SUFBRCxjQUFDO0NBQUEsQUE5QkQsSUE4QkM7U0E5QlksT0FBTyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IENvbXBvbmVudCwgVmlld0VuY2Fwc3VsYXRpb24sIE9uSW5pdCB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xyXG5pbXBvcnQgeyBUb2FzdGVyU2VydmljZSwgVG9hc3RlckNvbmZpZ30gZnJvbSAnYW5ndWxhcjItdG9hc3Rlcic7XHJcbmltcG9ydCB7IEtkQWxlcnRFdmVudCB9IGZyb20gJy4va2QtYWxlcnQtZXZlbnQnO1xyXG5cclxuQENvbXBvbmVudCh7XHJcbiAgICBzZWxlY3RvcjogJ2tkLWFsZXJ0JyxcclxuICAgIHByb3ZpZGVyczogW1RvYXN0ZXJTZXJ2aWNlLCBLZEFsZXJ0RXZlbnRdLFxyXG4gICAgZW5jYXBzdWxhdGlvbjogVmlld0VuY2Fwc3VsYXRpb24uTm9uZSxcclxuICAgIHRlbXBsYXRlOiBgXHJcbiAgICAgICAgPHRvYXN0ZXItY29udGFpbmVyIFt0b2FzdGVyY29uZmlnXT0nX3RvYXN0ZXJjb25maWcnPlxyXG4gICAgICAgIDwvdG9hc3Rlci1jb250YWluZXI+XHJcbiAgICAgICBgLFxyXG59KVxyXG5cclxuZXhwb3J0IGNsYXNzIEtkQWxlcnQgaW1wbGVtZW50cyBPbkluaXQge1xyXG4gICAgcHVibGljIF90b2FzdGVyY29uZmlnOiBUb2FzdGVyQ29uZmlnO1xyXG4gICAgcHJpdmF0ZSBfY29uZmlnOiBhbnk7XHJcbiAgICBwcml2YXRlIF90b2FzdGVyRGVmYXVsdENvbmZpZzogYW55ID0ge1xyXG4gICAgICAgIHNob3dDbG9zZUJ1dHRvbjogdHJ1ZSxcclxuICAgICAgICB0YXBUb0Rpc21pc3M6IGZhbHNlLFxyXG4gICAgICAgIHRpbWVvdXQ6IC0xLFxyXG4gICAgICAgIGxpbWl0OiA1LFxyXG4gICAgICAgIHBvc2l0aW9uQ2xhc3M6ICd0b2FzdC10b3AtcmlnaHQnXHJcbiAgICB9O1xyXG5cclxuICAgIGNvbnN0cnVjdG9yKFxyXG4gICAgICAgIHByaXZhdGUgX3RvYXN0ZXJTZXJ2aWNlOiBUb2FzdGVyU2VydmljZSxcclxuICAgICAgICBwcml2YXRlIF9rZEFsZXJ0RXZlbnQ6IEtkQWxlcnRFdmVudFxyXG4gICAgKSB7IH1cclxuXHJcbiAgICBuZ09uSW5pdCgpOiB2b2lkIHtcclxuICAgICAgICB0aGlzLnJlZ2lzdGVyQWxlcnRCcm9hZGNhc3QoKTtcclxuICAgIH1cclxuXHJcbiAgICByZWdpc3RlckFsZXJ0QnJvYWRjYXN0KCk6IHZvaWQge1xyXG4gICAgICAgIHRoaXMuX2tkQWxlcnRFdmVudC5vbigpXHJcbiAgICAgICAgICAgIC5zdWJzY3JpYmUoX3RvYXN0ID0+IHtcclxuICAgICAgICAgICAgICAgIHRoaXMuX2NvbmZpZyA9IE9iamVjdC5hc3NpZ24oe30sIHRoaXMuX3RvYXN0ZXJEZWZhdWx0Q29uZmlnLCBfdG9hc3QpO1xyXG4gICAgICAgICAgICAgICAgdGhpcy5fdG9hc3RlcmNvbmZpZyA9IG5ldyBUb2FzdGVyQ29uZmlnKHRoaXMuX2NvbmZpZyk7XHJcbiAgICAgICAgICAgICAgICB0aGlzLl90b2FzdGVyU2VydmljZS5wb3AoX3RvYXN0KTtcclxuICAgICAgICAgICAgICAgIC8vIHRoaXMuX3RvYXN0ZXJTZXJ2aWNlLnBvcCgnc3VjY2VzcycsICdBcmdzIFRpdGxlJywgJ0FyZ3MgQm9keScpOztcclxuICAgICAgICAgICAgfSk7XHJcbiAgICB9XHJcblxyXG59XHJcbiJdfQ==