import { __decorate, __metadata } from "tslib";
import { Injectable } from '@angular/core';
import { KdBroadcaster } from '../kd-common/index';
import * as i0 from "@angular/core";
import * as i1 from "../kd-common/kd-broadcaster-svc";
var KdAlertEvent = /** @class */ (function () {
    function KdAlertEvent(broadcaster) {
        this.broadcaster = broadcaster;
    }
    KdAlertEvent_1 = KdAlertEvent;
    KdAlertEvent.prototype.show = function (data) {
        this.broadcaster.broadcast(KdAlertEvent_1, data);
    };
    KdAlertEvent.prototype.success = function (data) {
        data = Object.assign({}, data, { type: 'success' });
        this.broadcaster.broadcast(KdAlertEvent_1, data);
    };
    KdAlertEvent.prototype.error = function (data) {
        data = Object.assign({}, data, { type: 'error', /*timeout: -1,*/ showCloseButton: true });
        this.broadcaster.broadcast(KdAlertEvent_1, data);
    };
    KdAlertEvent.prototype.info = function (data) {
        data = Object.assign({}, data, { type: 'info' });
        this.broadcaster.broadcast(KdAlertEvent_1, data);
    };
    KdAlertEvent.prototype.warn = function (data) {
        data = Object.assign({}, data, { type: 'warning', /*timeout: -1,*/ showCloseButton: true });
        this.broadcaster.broadcast(KdAlertEvent_1, data);
    };
    KdAlertEvent.prototype.on = function () {
        return this.broadcaster.on(KdAlertEvent_1);
    };
    var KdAlertEvent_1;
    KdAlertEvent.ctorParameters = function () { return [
        { type: KdBroadcaster }
    ]; };
    KdAlertEvent.ɵprov = i0.ɵɵdefineInjectable({ factory: function KdAlertEvent_Factory() { return new KdAlertEvent(i0.ɵɵinject(i1.KdBroadcaster)); }, token: KdAlertEvent, providedIn: "root" });
    KdAlertEvent = KdAlertEvent_1 = __decorate([
        Injectable({
            providedIn: 'root'
        }),
        __metadata("design:paramtypes", [KdBroadcaster])
    ], KdAlertEvent);
    return KdAlertEvent;
}());
export { KdAlertEvent };
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoia2QtYWxlcnQtZXZlbnQuanMiLCJzb3VyY2VSb290Ijoibmc6Ly9vcGVuZW1pcy1zdHlsZWd1aWRlLWxpYi8iLCJzb3VyY2VzIjpbImtkLWNvbXBvbmVudHMva2QtYW5ndWxhci1hbGVydC9rZC1hbGVydC1ldmVudC50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiO0FBQUEsT0FBTyxFQUFFLFVBQVUsRUFBRSxNQUFNLGVBQWUsQ0FBQztBQUUzQyxPQUFPLEVBQUUsYUFBYSxFQUFFLE1BQU0sb0JBQW9CLENBQUM7OztBQUtuRDtJQUNJLHNCQUFvQixXQUEwQjtRQUExQixnQkFBVyxHQUFYLFdBQVcsQ0FBZTtJQUFJLENBQUM7cUJBRDFDLFlBQVk7SUFHckIsMkJBQUksR0FBSixVQUFLLElBQVM7UUFDVixJQUFJLENBQUMsV0FBVyxDQUFDLFNBQVMsQ0FBQyxjQUFZLEVBQUUsSUFBSSxDQUFDLENBQUM7SUFDbkQsQ0FBQztJQUVELDhCQUFPLEdBQVAsVUFBUSxJQUFTO1FBQ2IsSUFBSSxHQUFHLE1BQU0sQ0FBQyxNQUFNLENBQUMsRUFBRSxFQUFFLElBQUksRUFBRSxFQUFFLElBQUksRUFBRSxTQUFTLEVBQUUsQ0FBQyxDQUFDO1FBQ3BELElBQUksQ0FBQyxXQUFXLENBQUMsU0FBUyxDQUFDLGNBQVksRUFBRSxJQUFJLENBQUMsQ0FBQztJQUNuRCxDQUFDO0lBRUQsNEJBQUssR0FBTCxVQUFNLElBQVM7UUFDWCxJQUFJLEdBQUcsTUFBTSxDQUFDLE1BQU0sQ0FBQyxFQUFFLEVBQUUsSUFBSSxFQUFFLEVBQUUsSUFBSSxFQUFFLE9BQU8sRUFBRSxnQkFBZ0IsQ0FBQyxlQUFlLEVBQUUsSUFBSSxFQUFFLENBQUMsQ0FBQztRQUMxRixJQUFJLENBQUMsV0FBVyxDQUFDLFNBQVMsQ0FBQyxjQUFZLEVBQUUsSUFBSSxDQUFDLENBQUM7SUFDbkQsQ0FBQztJQUVELDJCQUFJLEdBQUosVUFBSyxJQUFTO1FBQ1YsSUFBSSxHQUFHLE1BQU0sQ0FBQyxNQUFNLENBQUMsRUFBRSxFQUFFLElBQUksRUFBRSxFQUFFLElBQUksRUFBRSxNQUFNLEVBQUUsQ0FBQyxDQUFDO1FBQ2pELElBQUksQ0FBQyxXQUFXLENBQUMsU0FBUyxDQUFDLGNBQVksRUFBRSxJQUFJLENBQUMsQ0FBQztJQUNuRCxDQUFDO0lBRUQsMkJBQUksR0FBSixVQUFLLElBQVM7UUFDVixJQUFJLEdBQUcsTUFBTSxDQUFDLE1BQU0sQ0FBQyxFQUFFLEVBQUUsSUFBSSxFQUFFLEVBQUUsSUFBSSxFQUFFLFNBQVMsRUFBRSxnQkFBZ0IsQ0FBQyxlQUFlLEVBQUUsSUFBSSxFQUFFLENBQUMsQ0FBQztRQUM1RixJQUFJLENBQUMsV0FBVyxDQUFDLFNBQVMsQ0FBQyxjQUFZLEVBQUUsSUFBSSxDQUFDLENBQUM7SUFDbkQsQ0FBQztJQUVELHlCQUFFLEdBQUY7UUFDSSxPQUFPLElBQUksQ0FBQyxXQUFXLENBQUMsRUFBRSxDQUFNLGNBQVksQ0FBQyxDQUFDO0lBQ2xELENBQUM7OztnQkE1QmdDLGFBQWE7OztJQURyQyxZQUFZO1FBSHhCLFVBQVUsQ0FBRTtZQUNSLFVBQVUsRUFBRSxNQUFNO1NBQ3RCLENBQUU7eUNBRWtDLGFBQWE7T0FEckMsWUFBWSxDQThCeEI7dUJBckNEO0NBcUNDLEFBOUJELElBOEJDO1NBOUJZLFlBQVkiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBJbmplY3RhYmxlIH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XHJcbmltcG9ydCB7IE9ic2VydmFibGUgfSBmcm9tICdyeGpzJztcclxuaW1wb3J0IHsgS2RCcm9hZGNhc3RlciB9IGZyb20gJy4uL2tkLWNvbW1vbi9pbmRleCc7XHJcblxyXG5ASW5qZWN0YWJsZSgge1xyXG4gICAgIHByb3ZpZGVkSW46ICdyb290J1xyXG59IClcclxuZXhwb3J0IGNsYXNzIEtkQWxlcnRFdmVudCB7XHJcbiAgICBjb25zdHJ1Y3Rvcihwcml2YXRlIGJyb2FkY2FzdGVyOiBLZEJyb2FkY2FzdGVyKSB7IH1cclxuXHJcbiAgICBzaG93KGRhdGE6IGFueSk6IHZvaWQge1xyXG4gICAgICAgIHRoaXMuYnJvYWRjYXN0ZXIuYnJvYWRjYXN0KEtkQWxlcnRFdmVudCwgZGF0YSk7XHJcbiAgICB9XHJcblxyXG4gICAgc3VjY2VzcyhkYXRhOiBhbnkpOiB2b2lkIHtcclxuICAgICAgICBkYXRhID0gT2JqZWN0LmFzc2lnbih7fSwgZGF0YSwgeyB0eXBlOiAnc3VjY2VzcycgfSk7XHJcbiAgICAgICAgdGhpcy5icm9hZGNhc3Rlci5icm9hZGNhc3QoS2RBbGVydEV2ZW50LCBkYXRhKTtcclxuICAgIH1cclxuXHJcbiAgICBlcnJvcihkYXRhOiBhbnkpOiB2b2lkIHtcclxuICAgICAgICBkYXRhID0gT2JqZWN0LmFzc2lnbih7fSwgZGF0YSwgeyB0eXBlOiAnZXJyb3InLCAvKnRpbWVvdXQ6IC0xLCovIHNob3dDbG9zZUJ1dHRvbjogdHJ1ZSB9KTtcclxuICAgICAgICB0aGlzLmJyb2FkY2FzdGVyLmJyb2FkY2FzdChLZEFsZXJ0RXZlbnQsIGRhdGEpO1xyXG4gICAgfVxyXG5cclxuICAgIGluZm8oZGF0YTogYW55KTogdm9pZCB7XHJcbiAgICAgICAgZGF0YSA9IE9iamVjdC5hc3NpZ24oe30sIGRhdGEsIHsgdHlwZTogJ2luZm8nIH0pO1xyXG4gICAgICAgIHRoaXMuYnJvYWRjYXN0ZXIuYnJvYWRjYXN0KEtkQWxlcnRFdmVudCwgZGF0YSk7XHJcbiAgICB9XHJcblxyXG4gICAgd2FybihkYXRhOiBhbnkpOiB2b2lkIHtcclxuICAgICAgICBkYXRhID0gT2JqZWN0LmFzc2lnbih7fSwgZGF0YSwgeyB0eXBlOiAnd2FybmluZycsIC8qdGltZW91dDogLTEsKi8gc2hvd0Nsb3NlQnV0dG9uOiB0cnVlIH0pO1xyXG4gICAgICAgIHRoaXMuYnJvYWRjYXN0ZXIuYnJvYWRjYXN0KEtkQWxlcnRFdmVudCwgZGF0YSk7XHJcbiAgICB9XHJcblxyXG4gICAgb24oKTogT2JzZXJ2YWJsZTxhbnk+IHtcclxuICAgICAgICByZXR1cm4gdGhpcy5icm9hZGNhc3Rlci5vbjxhbnk+KEtkQWxlcnRFdmVudCk7XHJcbiAgICB9XHJcbn1cclxuIl19