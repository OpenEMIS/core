import { __decorate } from "tslib";
import { Injectable } from '@angular/core';
var KdTabsSvc = /** @class */ (function () {
    function KdTabsSvc() {
    }
    KdTabsSvc.prototype.setResult = function (config, type) {
        var result = config;
        var isMultipleActive = false;
        if (typeof result !== 'undefined' && result.length !== 0) {
            for (var i = 0; i < result.length; i++) {
                if (type === 'html') {
                    result[i].tabType = 'html';
                }
                else if (type === 'router') {
                    result[i].tabType = 'router';
                    if (typeof result[i].routerPath === 'undefined') {
                        result[i].routerPath = 'home';
                    }
                }
                else {
                    result[i].tabType = 'content';
                    if (typeof result[i].tabContent === 'undefined') {
                        result[i].tabContent = 'Undefined';
                    }
                }
                // why???
                if (result[i].isActive === true && isMultipleActive === false) {
                    isMultipleActive = true;
                }
                else if (typeof result[i].isActive === 'undefined' || isMultipleActive === true) {
                    result[i].isActive = false;
                }
                // if(typeof result[i].tabType === 'undefined'){
                //     result[i].tabType = 'content';
                // }
                if (typeof result[i].tabId === 'undefined') {
                    var id = result[i].tabName;
                    id = id.split(' ').join('_').toLowerCase();
                    result[i].tabId = id;
                }
            }
        }
        return result;
    };
    // checkDirection(): string {
    //     let direction = document.querySelector('.rtl');
    //     if (direction === null) return 'left';
    //     return 'right';
    // }
    KdTabsSvc.prototype.checkHasArray = function (_result) {
        return (typeof _result === 'undefined' || _result.length === 0) ? false : true;
    };
    KdTabsSvc = __decorate([
        Injectable()
    ], KdTabsSvc);
    return KdTabsSvc;
}());
export { KdTabsSvc };
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoia2QtYW5ndWxhci10YWJzLXN2Yy5qcyIsInNvdXJjZVJvb3QiOiJuZzovL29wZW5lbWlzLXN0eWxlZ3VpZGUtbGliLyIsInNvdXJjZXMiOlsia2QtY29tcG9uZW50cy9rZC1hbmd1bGFyLXRhYnMva2QtYW5ndWxhci10YWJzLXN2Yy50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiO0FBQUEsT0FBTyxFQUFFLFVBQVUsRUFBRSxNQUFNLGVBQWUsQ0FBQztBQUczQztJQUFBO0lBc0RBLENBQUM7SUFyREcsNkJBQVMsR0FBVCxVQUFVLE1BQWtCLEVBQUUsSUFBWTtRQUN0QyxJQUFJLE1BQU0sR0FBRyxNQUFNLENBQUM7UUFDcEIsSUFBSSxnQkFBZ0IsR0FBRyxLQUFLLENBQUM7UUFFN0IsSUFBSSxPQUFPLE1BQU0sS0FBSyxXQUFXLElBQUksTUFBTSxDQUFDLE1BQU0sS0FBSyxDQUFDLEVBQUU7WUFDdEQsS0FBSyxJQUFJLENBQUMsR0FBVyxDQUFDLEVBQUUsQ0FBQyxHQUFHLE1BQU0sQ0FBQyxNQUFNLEVBQUUsQ0FBQyxFQUFFLEVBQUU7Z0JBQzVDLElBQUksSUFBSSxLQUFLLE1BQU0sRUFBRTtvQkFDakIsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sR0FBRyxNQUFNLENBQUM7aUJBQzlCO3FCQUNJLElBQUksSUFBSSxLQUFLLFFBQVEsRUFBRTtvQkFDeEIsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sR0FBRyxRQUFRLENBQUM7b0JBQzdCLElBQUksT0FBTyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsVUFBVSxLQUFLLFdBQVcsRUFBRTt3QkFDN0MsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLFVBQVUsR0FBRyxNQUFNLENBQUM7cUJBQ2pDO2lCQUNKO3FCQUNJO29CQUNELE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPLEdBQUcsU0FBUyxDQUFDO29CQUM5QixJQUFJLE9BQU8sTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLFVBQVUsS0FBSyxXQUFXLEVBQUU7d0JBQzdDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxVQUFVLEdBQUcsV0FBVyxDQUFDO3FCQUN0QztpQkFDSjtnQkFDRCxTQUFTO2dCQUNULElBQUksTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsS0FBSyxJQUFJLElBQUksZ0JBQWdCLEtBQUssS0FBSyxFQUFFO29CQUMzRCxnQkFBZ0IsR0FBRyxJQUFJLENBQUM7aUJBQzNCO3FCQUVJLElBQUksT0FBTyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxLQUFLLFdBQVcsSUFBSSxnQkFBZ0IsS0FBSyxJQUFJLEVBQUU7b0JBQzdFLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLEdBQUcsS0FBSyxDQUFDO2lCQUM5QjtnQkFFRCxnREFBZ0Q7Z0JBQ2hELHFDQUFxQztnQkFDckMsSUFBSTtnQkFFSixJQUFJLE9BQU8sTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssS0FBSyxXQUFXLEVBQUU7b0JBQ3hDLElBQUksRUFBRSxHQUFXLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUM7b0JBQ25DLEVBQUUsR0FBRyxFQUFFLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQyxXQUFXLEVBQUUsQ0FBQztvQkFDM0MsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssR0FBRyxFQUFFLENBQUM7aUJBQ3hCO2FBQ0o7U0FDSjtRQUNELE9BQU8sTUFBTSxDQUFDO0lBQ2xCLENBQUM7SUFFRCw2QkFBNkI7SUFDN0Isc0RBQXNEO0lBQ3RELDZDQUE2QztJQUM3QyxzQkFBc0I7SUFDdEIsSUFBSTtJQUVKLGlDQUFhLEdBQWIsVUFBYyxPQUFtQjtRQUM3QixPQUFPLENBQUMsT0FBTyxPQUFPLEtBQUssV0FBVyxJQUFJLE9BQU8sQ0FBQyxNQUFNLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDO0lBQ25GLENBQUM7SUFyRFEsU0FBUztRQURyQixVQUFVLEVBQUU7T0FDQSxTQUFTLENBc0RyQjtJQUFELGdCQUFDO0NBQUEsQUF0REQsSUFzREM7U0F0RFksU0FBUyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IEluamVjdGFibGUgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcclxuXHJcbkBJbmplY3RhYmxlKClcclxuZXhwb3J0IGNsYXNzIEtkVGFic1N2YyB7XHJcbiAgICBzZXRSZXN1bHQoY29uZmlnOiBBcnJheTxhbnk+LCB0eXBlOiBzdHJpbmcpOiBBcnJheTxhbnk+IHtcclxuICAgICAgICBsZXQgcmVzdWx0ID0gY29uZmlnO1xyXG4gICAgICAgIGxldCBpc011bHRpcGxlQWN0aXZlID0gZmFsc2U7XHJcblxyXG4gICAgICAgIGlmICh0eXBlb2YgcmVzdWx0ICE9PSAndW5kZWZpbmVkJyAmJiByZXN1bHQubGVuZ3RoICE9PSAwKSB7XHJcbiAgICAgICAgICAgIGZvciAobGV0IGk6IG51bWJlciA9IDA7IGkgPCByZXN1bHQubGVuZ3RoOyBpKyspIHtcclxuICAgICAgICAgICAgICAgIGlmICh0eXBlID09PSAnaHRtbCcpIHtcclxuICAgICAgICAgICAgICAgICAgICByZXN1bHRbaV0udGFiVHlwZSA9ICdodG1sJztcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIGVsc2UgaWYgKHR5cGUgPT09ICdyb3V0ZXInKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgcmVzdWx0W2ldLnRhYlR5cGUgPSAncm91dGVyJztcclxuICAgICAgICAgICAgICAgICAgICBpZiAodHlwZW9mIHJlc3VsdFtpXS5yb3V0ZXJQYXRoID09PSAndW5kZWZpbmVkJykge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICByZXN1bHRbaV0ucm91dGVyUGF0aCA9ICdob21lJztcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgICAgICAgICByZXN1bHRbaV0udGFiVHlwZSA9ICdjb250ZW50JztcclxuICAgICAgICAgICAgICAgICAgICBpZiAodHlwZW9mIHJlc3VsdFtpXS50YWJDb250ZW50ID09PSAndW5kZWZpbmVkJykge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICByZXN1bHRbaV0udGFiQ29udGVudCA9ICdVbmRlZmluZWQnO1xyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIC8vIHdoeT8/P1xyXG4gICAgICAgICAgICAgICAgaWYgKHJlc3VsdFtpXS5pc0FjdGl2ZSA9PT0gdHJ1ZSAmJiBpc011bHRpcGxlQWN0aXZlID09PSBmYWxzZSkge1xyXG4gICAgICAgICAgICAgICAgICAgIGlzTXVsdGlwbGVBY3RpdmUgPSB0cnVlO1xyXG4gICAgICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgICAgIGVsc2UgaWYgKHR5cGVvZiByZXN1bHRbaV0uaXNBY3RpdmUgPT09ICd1bmRlZmluZWQnIHx8IGlzTXVsdGlwbGVBY3RpdmUgPT09IHRydWUpIHtcclxuICAgICAgICAgICAgICAgICAgICByZXN1bHRbaV0uaXNBY3RpdmUgPSBmYWxzZTtcclxuICAgICAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgICAgICAvLyBpZih0eXBlb2YgcmVzdWx0W2ldLnRhYlR5cGUgPT09ICd1bmRlZmluZWQnKXtcclxuICAgICAgICAgICAgICAgIC8vICAgICByZXN1bHRbaV0udGFiVHlwZSA9ICdjb250ZW50JztcclxuICAgICAgICAgICAgICAgIC8vIH1cclxuXHJcbiAgICAgICAgICAgICAgICBpZiAodHlwZW9mIHJlc3VsdFtpXS50YWJJZCA9PT0gJ3VuZGVmaW5lZCcpIHtcclxuICAgICAgICAgICAgICAgICAgICBsZXQgaWQ6IHN0cmluZyA9IHJlc3VsdFtpXS50YWJOYW1lO1xyXG4gICAgICAgICAgICAgICAgICAgIGlkID0gaWQuc3BsaXQoJyAnKS5qb2luKCdfJykudG9Mb3dlckNhc2UoKTtcclxuICAgICAgICAgICAgICAgICAgICByZXN1bHRbaV0udGFiSWQgPSBpZDtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgICAgICByZXR1cm4gcmVzdWx0O1xyXG4gICAgfVxyXG5cclxuICAgIC8vIGNoZWNrRGlyZWN0aW9uKCk6IHN0cmluZyB7XHJcbiAgICAvLyAgICAgbGV0IGRpcmVjdGlvbiA9IGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3IoJy5ydGwnKTtcclxuICAgIC8vICAgICBpZiAoZGlyZWN0aW9uID09PSBudWxsKSByZXR1cm4gJ2xlZnQnO1xyXG4gICAgLy8gICAgIHJldHVybiAncmlnaHQnO1xyXG4gICAgLy8gfVxyXG5cclxuICAgIGNoZWNrSGFzQXJyYXkoX3Jlc3VsdDogQXJyYXk8YW55Pik6IGJvb2xlYW4ge1xyXG4gICAgICAgIHJldHVybiAodHlwZW9mIF9yZXN1bHQgPT09ICd1bmRlZmluZWQnIHx8IF9yZXN1bHQubGVuZ3RoID09PSAwKSA/IGZhbHNlIDogdHJ1ZTtcclxuICAgIH1cclxufVxyXG4iXX0=