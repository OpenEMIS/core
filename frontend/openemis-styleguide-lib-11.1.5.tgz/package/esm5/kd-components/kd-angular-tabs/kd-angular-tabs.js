import { __decorate, __metadata } from "tslib";
import { Component, Input, Output, EventEmitter, ViewEncapsulation, OnInit, OnChanges, AfterViewInit, ViewContainerRef, HostListener, ChangeDetectorRef, Renderer2 } from '@angular/core';
import { timer } from 'rxjs';
import { Router, ActivatedRoute } from '@angular/router';
import { KdTabsSvc } from './kd-angular-tabs-svc';
import { KdDomElemSvc } from '../kd-common/index';
import { KdSplitterEvent } from '../kd-angular-splitter/index';
var KdTabs = /** @class */ (function () {
    function KdTabs(_vcr, _renderer, _cd, _tabSvc, _router, _activeRoute, _domEle, _splitterEvent) {
        this._vcr = _vcr;
        this._renderer = _renderer;
        this._cd = _cd;
        this._tabSvc = _tabSvc;
        this._router = _router;
        this._domEle = _domEle;
        this._splitterEvent = _splitterEvent;
        this._result = [];
        this._hasArray = false;
        this._scrollBtn = false;
        this._disableLeft = false;
        this._disableRight = false;
        this._left = 0;
        this._maxLeft = 0;
        this._ulWidth = 0;
        this._ulMargin = 0;
        this._parentPadding = 30;
        this.activeState = new EventEmitter();
    }
    KdTabs.prototype.onResize = function (event) {
        this._checkWidth();
        this._checkScrollable();
    };
    KdTabs.prototype.ngOnInit = function () {
        var _this = this;
        this._id = (typeof this.inputId !== 'undefined') ? this.inputId : 'tabs';
        this._result = this._tabSvc.setResult(this.tabsConfig, this.tabType);
        this._hasArray = this._tabSvc.checkHasArray(this._result);
        if (typeof this._result !== 'undefined') {
            for (var i = 0; i < this._result.length; i++) {
                if (this._result[i].isActive === true) {
                    this._previousItem = this._result[i];
                    this.activeState.emit(this._previousItem.tabId);
                    // if (this._previousItem.tabType === 'router') {
                    //     this._router.navigate(['./' + this._previousItem.routerPath], { relativeTo: this._route });
                    // }
                    break;
                }
            }
        }
        this._splitterEvent.onDrag()
            .subscribe(function (_type) {
            _this._checkWidth();
            _this._checkScrollable();
        });
        this._splitterEvent.onToggleMenu()
            .subscribe(function (_type) {
            timer(500).subscribe(function () {
                _this._checkWidth();
                _this._checkScrollable();
            });
        });
    };
    KdTabs.prototype.ngOnChanges = function () {
        var _this = this;
        this._result = this._tabSvc.setResult(this.tabsConfig, this.tabType);
        this._hasArray = this._tabSvc.checkHasArray(this._result);
        if (typeof this._result !== 'undefined') {
            for (var i = 0; i < this._result.length; i++) {
                if (this._result[i].isActive === true) {
                    this._previousItem = this._result[i];
                    this.activeState.emit(this._previousItem.tabId);
                    if (this._previousItem.tabType === 'router') {
                        // console.log('Kd-angular-tab - Need to relook this section', this._previousItem.routerPath, this._route );
                        // this._router.navigate(['./' + this._previousItem.routerPath], { relativeTo: this._route });
                        /* Change the navigation on first load to use full router path to match all the path */
                        this._router.navigateByUrl(this._previousItem.routerPath);
                    }
                    break;
                }
            }
        }
        timer(50).subscribe(function () {
            _this._checkWidth();
            _this._checkScrollable();
        });
    };
    KdTabs.prototype.ngAfterViewInit = function () {
        // this._direction = this._tabSvc.checkDirection();
        this._direction = this._domEle.getDocumentDirection(true);
        this._checkWidth();
        this._cd.detach();
        this._checkScrollable();
        this._cd.detectChanges();
        this._cd.reattach();
    };
    KdTabs.prototype.selectTab = function (item, e) {
        e.preventDefault();
        if (typeof item.disabled !== 'undefined' && item.disabled)
            return;
        if (typeof this._previousItem !== 'undefined' && this._previousItem !== item) {
            this._previousItem.isActive = false;
        }
        if (item.tabType === 'router' && item.isActive === false) {
            this._router.navigateByUrl(item.routerPath);
        }
        item.isActive = true;
        this._previousItem = item;
        this.activeState.emit(this._previousItem.tabId);
        this._setSelected();
    };
    KdTabs.prototype.scroll = function (direction) {
        var offsetX = 200;
        this._left = (direction === 'right') ? this._left - offsetX : this._left + offsetX;
        this._setLeft();
    };
    KdTabs.prototype._checkWidth = function () {
        this._ulWidth = 0;
        var ulList = this._vcr.element.nativeElement.querySelectorAll('#' + this._id + ' .nav-item');
        // console.log(ulList);
        // console.log(this._result);
        if (typeof ulList !== 'undefined' && ulList.length > 1) {
            if (this._direction === 'left') {
                this._ulMargin = ulList[1].getBoundingClientRect().left - ulList[0].getBoundingClientRect().right;
            }
            else {
                this._ulMargin = ulList[0].getBoundingClientRect().left - ulList[1].getBoundingClientRect().right;
            }
        }
        if (typeof this._result !== 'undefined') {
            for (var i = 0; i < ulList.length; i++) {
                if (typeof this._result[i] === 'undefined')
                    continue;
                this._result[i].width = Math.round(ulList[i].getBoundingClientRect().width);
                if (i !== 0) {
                    this._result[i].width = Math.round(this._result[i].width + this._ulMargin);
                }
                this._ulWidth += this._result[i].width;
            }
        }
    };
    KdTabs.prototype._checkScrollable = function () {
        var _this = this;
        var parentWidth = this._vcr.element.nativeElement.parentElement.getBoundingClientRect().width;
        var ulElement = this._vcr.element.nativeElement.querySelector('#' + this._id + ' .nav-tabs');
        this._scrollBtn = (this._ulWidth > parentWidth) ? true : false;
        this._scrollBtn ? this._renderer.addClass(ulElement, 'scrollable') : this._renderer.removeClass(ulElement, 'scrollable');
        timer(100).subscribe(function () {
            if (ulElement.clientWidth < _this._ulWidth) {
                if (_this._direction === 'left') {
                    _this._maxLeft = ulElement.clientWidth - _this._ulWidth;
                }
                else {
                    _this._maxLeft = _this._ulWidth - ulElement.clientWidth;
                }
            }
            if (!_this._scrollBtn) {
                _this._left = 0;
                _this._setLeft();
            }
            else {
                _this._setSelected();
            }
        });
    };
    KdTabs.prototype._setSelected = function () {
        var parentWidth = this._vcr.element.nativeElement.querySelector('#' + this._id + ' .nav-tabs').clientWidth - this._parentPadding;
        var middle = parentWidth / 2;
        var width = 0;
        if (this._scrollBtn) {
            // if (this._direction === 'left') {
            for (var i = 0; i < this._result.length; i++) {
                if (this._previousItem !== this._result[i]) {
                    width += this._result[i].width;
                }
                else {
                    width += (this._result[i].width / 2);
                    if (this._direction === 'left') {
                        this._left = middle - width;
                    }
                    else {
                        this._left = width - middle;
                    }
                    break;
                }
            }
            // }
            // else {
            //     for (let i: number = this._result.length - 1; i >= 0; i--) {
            //         if (this._previousItem !== this._result[i]) {
            //             width += this._result[i].width;
            //         }
            //         else {
            //             width += (this._result[i].width / 2);
            //             this._left = width - middle;
            //             break;
            //         }
            //     }
            // }
        }
        else {
            this._left = 0;
        }
        this._setLeft();
    };
    KdTabs.prototype._setLeft = function () {
        var item = this._vcr.element.nativeElement.querySelectorAll('#' + this._id + ' .nav-item');
        if (this._direction === 'left') {
            if (this._left < this._maxLeft) {
                this._left = this._maxLeft;
            }
            else if (this._left >= 0) {
                this._left = 0;
            }
            this._disableLeft = (this._left === 0) ? true : false;
            this._disableRight = (this._left === this._maxLeft) ? true : false;
        }
        else {
            if (this._left < 0) {
                this._left = 0;
            }
            else if (this._left > this._maxLeft) {
                this._left = this._maxLeft;
            }
            this._disableLeft = (this._left === this._maxLeft) ? true : false;
            this._disableRight = (this._left === 0) ? true : false;
        }
        var move = this._left + 'px';
        for (var i = 0; i < item.length; i++) {
            this._renderer.setStyle(item[i], 'left', move);
        }
    };
    KdTabs.ctorParameters = function () { return [
        { type: ViewContainerRef },
        { type: Renderer2 },
        { type: ChangeDetectorRef },
        { type: KdTabsSvc },
        { type: Router },
        { type: ActivatedRoute },
        { type: KdDomElemSvc },
        { type: KdSplitterEvent }
    ]; };
    __decorate([
        Input(),
        __metadata("design:type", String)
    ], KdTabs.prototype, "inputId", void 0);
    __decorate([
        Input('config'),
        __metadata("design:type", Object)
    ], KdTabs.prototype, "tabsConfig", void 0);
    __decorate([
        Input('type'),
        __metadata("design:type", String)
    ], KdTabs.prototype, "tabType", void 0);
    __decorate([
        Output(),
        __metadata("design:type", EventEmitter)
    ], KdTabs.prototype, "activeState", void 0);
    __decorate([
        HostListener('window:resize', ['$event']),
        __metadata("design:type", Function),
        __metadata("design:paramtypes", [Object]),
        __metadata("design:returntype", void 0)
    ], KdTabs.prototype, "onResize", null);
    KdTabs = __decorate([
        Component({
            selector: 'kd-tabs',
            template: "\n        <div class='nav-bar' [hidden]='!_hasArray' [id]='_id'>\n            <button *ngIf='_scrollBtn' (click)='scroll(\"left\")' class='scroll-left' [disabled]='_disableLeft'><</button>\n            <ul class='nav nav-tabs'>\n                <ng-template ngFor let-item [ngForOf]='_result'>\n                    <li class='nav-item' style='left:0px' [ngClass]='{\"tab-selected\": item.isActive, \"tab-disabled\": item.disabled}'>\n                        <a (click)='selectTab(item, $event)' class='nav-link'>{{item.tabName}}</a>\n                        <!-- <a *ngIf='item.tabType !== \"router\"' (click)='selectTab(item, $event)' class='nav-link'>{{item.tabName}}</a>\n                        <a *ngIf='item.tabType === \"router\"' (click)='selectTab(item, $event)' class='nav-link' [routerLink]='item.routerPath'>{{item.tabName}}</a> -->\n                    </li>\n                </ng-template>\n            </ul>\n            <button *ngIf='_scrollBtn' (click)='scroll(\"right\")' class='scroll-right' [disabled]='_disableRight'>></button>\n            <div class='tab-divider'></div>\n         </div>\n\n        <ng-template [ngIf]='_previousItem && _previousItem.tabType === \"content\"'>\n            <div class='tab-content'>\n                <div class='tab-pane' [ngClass]='{\"active\": _previousItem.isActive}'>{{_previousItem.tabContent}}</div>\n            </div>\n        </ng-template>\n\n        <ng-template [ngIf]='tabType === \"router\" || tabType === \"html\"'>\n            <ng-content></ng-content>\n        </ng-template>\n\n        <div class='tab-bottom-divider'></div>\n    ",
            encapsulation: ViewEncapsulation.None,
            providers: [KdTabsSvc, KdDomElemSvc],
            host: {
                'class': 'kdx-tabs',
            },
            styles: ["\n        .angular-tabs .nav-tabs .nav-item.tab-disabled > a.nav-link:hover {\n            color: #333 !important;\n            border: 1px solid #DDD !important;\n            cursor: not-allowed !important;\n            background-color: transparent !important;\n        }\n    "]
        }),
        __metadata("design:paramtypes", [ViewContainerRef,
            Renderer2,
            ChangeDetectorRef,
            KdTabsSvc,
            Router,
            ActivatedRoute,
            KdDomElemSvc,
            KdSplitterEvent])
    ], KdTabs);
    return KdTabs;
}());
export { KdTabs };
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoia2QtYW5ndWxhci10YWJzLmpzIiwic291cmNlUm9vdCI6Im5nOi8vb3BlbmVtaXMtc3R5bGVndWlkZS1saWIvIiwic291cmNlcyI6WyJrZC1jb21wb25lbnRzL2tkLWFuZ3VsYXItdGFicy9rZC1hbmd1bGFyLXRhYnMudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IjtBQUFBLE9BQU8sRUFBRSxTQUFTLEVBQUUsS0FBSyxFQUFFLE1BQU0sRUFBRSxZQUFZLEVBQUUsaUJBQWlCLEVBQUUsTUFBTSxFQUFFLFNBQVMsRUFBRSxhQUFhLEVBQUUsZ0JBQWdCLEVBQUUsWUFBWSxFQUFFLGlCQUFpQixFQUFFLFNBQVMsRUFBRSxNQUFNLGVBQWUsQ0FBQztBQUMxTCxPQUFPLEVBQUUsS0FBSyxFQUFFLE1BQU0sTUFBTSxDQUFDO0FBQzdCLE9BQU8sRUFBRSxNQUFNLEVBQUUsY0FBYyxFQUFFLE1BQU0saUJBQWlCLENBQUM7QUFDekQsT0FBTyxFQUFFLFNBQVMsRUFBRSxNQUFNLHVCQUF1QixDQUFDO0FBQ2xELE9BQU8sRUFBRSxZQUFZLEVBQUUsTUFBTSxvQkFBb0IsQ0FBQztBQUNsRCxPQUFPLEVBQUUsZUFBZSxFQUFFLE1BQU0sOEJBQThCLENBQUM7QUFnRC9EO0lBcUJJLGdCQUNZLElBQXNCLEVBQ3RCLFNBQW9CLEVBQ3BCLEdBQXNCLEVBQ3RCLE9BQWtCLEVBQ2xCLE9BQWUsRUFDdkIsWUFBNEIsRUFDcEIsT0FBcUIsRUFDckIsY0FBK0I7UUFQL0IsU0FBSSxHQUFKLElBQUksQ0FBa0I7UUFDdEIsY0FBUyxHQUFULFNBQVMsQ0FBVztRQUNwQixRQUFHLEdBQUgsR0FBRyxDQUFtQjtRQUN0QixZQUFPLEdBQVAsT0FBTyxDQUFXO1FBQ2xCLFlBQU8sR0FBUCxPQUFPLENBQVE7UUFFZixZQUFPLEdBQVAsT0FBTyxDQUFjO1FBQ3JCLG1CQUFjLEdBQWQsY0FBYyxDQUFpQjtRQTNCcEMsWUFBTyxHQUFlLEVBQUUsQ0FBQztRQUN6QixjQUFTLEdBQVksS0FBSyxDQUFDO1FBQzNCLGVBQVUsR0FBWSxLQUFLLENBQUM7UUFFNUIsaUJBQVksR0FBWSxLQUFLLENBQUM7UUFDOUIsa0JBQWEsR0FBWSxLQUFLLENBQUM7UUFFOUIsVUFBSyxHQUFXLENBQUMsQ0FBQztRQUNsQixhQUFRLEdBQVcsQ0FBQyxDQUFDO1FBQ3JCLGFBQVEsR0FBVyxDQUFDLENBQUM7UUFDckIsY0FBUyxHQUFXLENBQUMsQ0FBQztRQUV0QixtQkFBYyxHQUFXLEVBQUUsQ0FBQztRQUsxQixnQkFBVyxHQUFxQixJQUFJLFlBQVksRUFBRSxDQUFDO0lBVWQsQ0FBQztJQUdoRCx5QkFBUSxHQUFSLFVBQVMsS0FBVTtRQUNmLElBQUksQ0FBQyxXQUFXLEVBQUUsQ0FBQztRQUNuQixJQUFJLENBQUMsZ0JBQWdCLEVBQUUsQ0FBQztJQUM1QixDQUFDO0lBRUQseUJBQVEsR0FBUjtRQUFBLGlCQWlDQztRQWhDRyxJQUFJLENBQUMsR0FBRyxHQUFHLENBQUMsT0FBTyxJQUFJLENBQUMsT0FBTyxLQUFLLFdBQVcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUM7UUFDekUsSUFBSSxDQUFDLE9BQU8sR0FBRyxJQUFJLENBQUMsT0FBTyxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsVUFBVSxFQUFFLElBQUksQ0FBQyxPQUFPLENBQUMsQ0FBQztRQUVyRSxJQUFJLENBQUMsU0FBUyxHQUFHLElBQUksQ0FBQyxPQUFPLENBQUMsYUFBYSxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsQ0FBQztRQUUxRCxJQUFJLE9BQU8sSUFBSSxDQUFDLE9BQU8sS0FBSyxXQUFXLEVBQUU7WUFDckMsS0FBSyxJQUFJLENBQUMsR0FBVyxDQUFDLEVBQUUsQ0FBQyxHQUFHLElBQUksQ0FBQyxPQUFPLENBQUMsTUFBTSxFQUFFLENBQUMsRUFBRSxFQUFFO2dCQUNsRCxJQUFJLElBQUksQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxLQUFLLElBQUksRUFBRTtvQkFDbkMsSUFBSSxDQUFDLGFBQWEsR0FBRyxJQUFJLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDO29CQUNyQyxJQUFJLENBQUMsV0FBVyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsYUFBYSxDQUFDLEtBQUssQ0FBQyxDQUFDO29CQUVoRCxpREFBaUQ7b0JBQ2pELGtHQUFrRztvQkFDbEcsSUFBSTtvQkFDSixNQUFNO2lCQUNUO2FBQ0o7U0FDSjtRQUVELElBQUksQ0FBQyxjQUFjLENBQUMsTUFBTSxFQUFFO2FBQ3ZCLFNBQVMsQ0FBQyxVQUFBLEtBQUs7WUFDWixLQUFJLENBQUMsV0FBVyxFQUFFLENBQUM7WUFDbkIsS0FBSSxDQUFDLGdCQUFnQixFQUFFLENBQUM7UUFDNUIsQ0FBQyxDQUFDLENBQUM7UUFFUCxJQUFJLENBQUMsY0FBYyxDQUFDLFlBQVksRUFBRTthQUM3QixTQUFTLENBQUMsVUFBQSxLQUFLO1lBQ1osS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDLFNBQVMsQ0FBQztnQkFDakIsS0FBSSxDQUFDLFdBQVcsRUFBRSxDQUFDO2dCQUNuQixLQUFJLENBQUMsZ0JBQWdCLEVBQUUsQ0FBQztZQUM1QixDQUFDLENBQUMsQ0FBQztRQUNQLENBQUMsQ0FBQyxDQUFDO0lBQ1gsQ0FBQztJQUVELDRCQUFXLEdBQVg7UUFBQSxpQkEwQkM7UUF6QkcsSUFBSSxDQUFDLE9BQU8sR0FBRyxJQUFJLENBQUMsT0FBTyxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsVUFBVSxFQUFFLElBQUksQ0FBQyxPQUFPLENBQUMsQ0FBQztRQUNyRSxJQUFJLENBQUMsU0FBUyxHQUFHLElBQUksQ0FBQyxPQUFPLENBQUMsYUFBYSxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsQ0FBQztRQUUxRCxJQUFJLE9BQU8sSUFBSSxDQUFDLE9BQU8sS0FBSyxXQUFXLEVBQUU7WUFDckMsS0FBSyxJQUFJLENBQUMsR0FBVyxDQUFDLEVBQUUsQ0FBQyxHQUFHLElBQUksQ0FBQyxPQUFPLENBQUMsTUFBTSxFQUFFLENBQUMsRUFBRSxFQUFFO2dCQUNsRCxJQUFJLElBQUksQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxLQUFLLElBQUksRUFBRTtvQkFDbkMsSUFBSSxDQUFDLGFBQWEsR0FBRyxJQUFJLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDO29CQUNyQyxJQUFJLENBQUMsV0FBVyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsYUFBYSxDQUFDLEtBQUssQ0FBQyxDQUFDO29CQUVoRCxJQUFJLElBQUksQ0FBQyxhQUFhLENBQUMsT0FBTyxLQUFLLFFBQVEsRUFBRTt3QkFDekMsNEdBQTRHO3dCQUM1Ryw4RkFBOEY7d0JBQzlGLHVGQUF1Rjt3QkFDdkYsSUFBSSxDQUFDLE9BQU8sQ0FBQyxhQUFhLENBQUMsSUFBSSxDQUFDLGFBQWEsQ0FBQyxVQUFVLENBQUMsQ0FBQztxQkFDN0Q7b0JBQ0QsTUFBTTtpQkFDVDthQUNKO1NBQ0o7UUFFRCxLQUFLLENBQUMsRUFBRSxDQUFDLENBQUMsU0FBUyxDQUFDO1lBQ2hCLEtBQUksQ0FBQyxXQUFXLEVBQUUsQ0FBQztZQUNuQixLQUFJLENBQUMsZ0JBQWdCLEVBQUUsQ0FBQztRQUM1QixDQUFDLENBQUMsQ0FBQztJQUVQLENBQUM7SUFFRCxnQ0FBZSxHQUFmO1FBQ0ksbURBQW1EO1FBQ25ELElBQUksQ0FBQyxVQUFVLEdBQUcsSUFBSSxDQUFDLE9BQU8sQ0FBQyxvQkFBb0IsQ0FBQyxJQUFJLENBQUMsQ0FBQztRQUMxRCxJQUFJLENBQUMsV0FBVyxFQUFFLENBQUM7UUFFbkIsSUFBSSxDQUFDLEdBQUcsQ0FBQyxNQUFNLEVBQUUsQ0FBQztRQUNsQixJQUFJLENBQUMsZ0JBQWdCLEVBQUUsQ0FBQztRQUN4QixJQUFJLENBQUMsR0FBRyxDQUFDLGFBQWEsRUFBRSxDQUFDO1FBQ3pCLElBQUksQ0FBQyxHQUFHLENBQUMsUUFBUSxFQUFFLENBQUM7SUFDeEIsQ0FBQztJQUVNLDBCQUFTLEdBQWhCLFVBQWlCLElBQVMsRUFBRSxDQUFRO1FBQ2hDLENBQUMsQ0FBQyxjQUFjLEVBQUUsQ0FBQztRQUNuQixJQUFJLE9BQU8sSUFBSSxDQUFDLFFBQVEsS0FBSyxXQUFXLElBQUksSUFBSSxDQUFDLFFBQVE7WUFBRSxPQUFPO1FBRWxFLElBQUksT0FBTyxJQUFJLENBQUMsYUFBYSxLQUFLLFdBQVcsSUFBSSxJQUFJLENBQUMsYUFBYSxLQUFLLElBQUksRUFBRTtZQUMxRSxJQUFJLENBQUMsYUFBYSxDQUFDLFFBQVEsR0FBRyxLQUFLLENBQUM7U0FDdkM7UUFFRCxJQUFJLElBQUksQ0FBQyxPQUFPLEtBQUssUUFBUSxJQUFJLElBQUksQ0FBQyxRQUFRLEtBQUssS0FBSyxFQUFFO1lBQ3RELElBQUksQ0FBQyxPQUFPLENBQUMsYUFBYSxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsQ0FBQztTQUMvQztRQUVELElBQUksQ0FBQyxRQUFRLEdBQUcsSUFBSSxDQUFDO1FBQ3JCLElBQUksQ0FBQyxhQUFhLEdBQUcsSUFBSSxDQUFDO1FBQzFCLElBQUksQ0FBQyxXQUFXLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxhQUFhLENBQUMsS0FBSyxDQUFDLENBQUM7UUFDaEQsSUFBSSxDQUFDLFlBQVksRUFBRSxDQUFDO0lBQ3hCLENBQUM7SUFFTSx1QkFBTSxHQUFiLFVBQWMsU0FBaUI7UUFDM0IsSUFBSSxPQUFPLEdBQVcsR0FBRyxDQUFDO1FBQzFCLElBQUksQ0FBQyxLQUFLLEdBQUcsQ0FBQyxTQUFTLEtBQUssT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxLQUFLLEdBQUcsT0FBTyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsS0FBSyxHQUFHLE9BQU8sQ0FBQztRQUNuRixJQUFJLENBQUMsUUFBUSxFQUFFLENBQUM7SUFDcEIsQ0FBQztJQUVPLDRCQUFXLEdBQW5CO1FBQ0ksSUFBSSxDQUFDLFFBQVEsR0FBRyxDQUFDLENBQUM7UUFDbEIsSUFBSSxNQUFNLEdBQXVCLElBQUksQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLGFBQWEsQ0FBQyxnQkFBZ0IsQ0FBQyxHQUFHLEdBQUcsSUFBSSxDQUFDLEdBQUcsR0FBRyxZQUFZLENBQUMsQ0FBQztRQUNqSCx1QkFBdUI7UUFDdkIsNkJBQTZCO1FBQzdCLElBQUksT0FBTyxNQUFNLEtBQUssV0FBVyxJQUFJLE1BQU0sQ0FBQyxNQUFNLEdBQUcsQ0FBQyxFQUFFO1lBQ3BELElBQUksSUFBSSxDQUFDLFVBQVUsS0FBSyxNQUFNLEVBQUU7Z0JBQzVCLElBQUksQ0FBQyxTQUFTLEdBQUcsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLHFCQUFxQixFQUFFLENBQUMsSUFBSSxHQUFHLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxxQkFBcUIsRUFBRSxDQUFDLEtBQUssQ0FBQzthQUNyRztpQkFDSTtnQkFDRCxJQUFJLENBQUMsU0FBUyxHQUFHLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxxQkFBcUIsRUFBRSxDQUFDLElBQUksR0FBRyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMscUJBQXFCLEVBQUUsQ0FBQyxLQUFLLENBQUM7YUFDckc7U0FDSjtRQUVELElBQUksT0FBTyxJQUFJLENBQUMsT0FBTyxLQUFLLFdBQVcsRUFBRTtZQUNyQyxLQUFLLElBQUksQ0FBQyxHQUFXLENBQUMsRUFBRSxDQUFDLEdBQUcsTUFBTSxDQUFDLE1BQU0sRUFBRSxDQUFDLEVBQUUsRUFBRTtnQkFDNUMsSUFBSSxPQUFPLElBQUksQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLEtBQUssV0FBVztvQkFBRSxTQUFTO2dCQUVyRCxJQUFJLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxxQkFBcUIsRUFBRSxDQUFDLEtBQUssQ0FBQyxDQUFDO2dCQUU1RSxJQUFJLENBQUMsS0FBSyxDQUFDLEVBQUU7b0JBQ1QsSUFBSSxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssR0FBRyxJQUFJLENBQUMsU0FBUyxDQUFDLENBQUM7aUJBQzlFO2dCQUNELElBQUksQ0FBQyxRQUFRLElBQUksSUFBSSxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUM7YUFDMUM7U0FDSjtJQUVMLENBQUM7SUFFTyxpQ0FBZ0IsR0FBeEI7UUFBQSxpQkF3QkM7UUF2QkcsSUFBSSxXQUFXLEdBQVcsSUFBSSxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsYUFBYSxDQUFDLGFBQWEsQ0FBQyxxQkFBcUIsRUFBRSxDQUFDLEtBQUssQ0FBQztRQUN0RyxJQUFJLFNBQVMsR0FBZ0IsSUFBSSxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsYUFBYSxDQUFDLGFBQWEsQ0FBQyxHQUFHLEdBQUcsSUFBSSxDQUFDLEdBQUcsR0FBRyxZQUFZLENBQUMsQ0FBQztRQUMxRyxJQUFJLENBQUMsVUFBVSxHQUFHLENBQUMsSUFBSSxDQUFDLFFBQVEsR0FBRyxXQUFXLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUM7UUFDL0QsSUFBSSxDQUFDLFVBQVUsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxRQUFRLENBQUMsU0FBUyxFQUFFLFlBQVksQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLFdBQVcsQ0FBQyxTQUFTLEVBQUUsWUFBWSxDQUFDLENBQUM7UUFFekgsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDLFNBQVMsQ0FBQztZQUNqQixJQUFJLFNBQVMsQ0FBQyxXQUFXLEdBQUcsS0FBSSxDQUFDLFFBQVEsRUFBRTtnQkFDdkMsSUFBSSxLQUFJLENBQUMsVUFBVSxLQUFLLE1BQU0sRUFBRTtvQkFDNUIsS0FBSSxDQUFDLFFBQVEsR0FBRyxTQUFTLENBQUMsV0FBVyxHQUFHLEtBQUksQ0FBQyxRQUFRLENBQUM7aUJBQ3pEO3FCQUNJO29CQUNELEtBQUksQ0FBQyxRQUFRLEdBQUcsS0FBSSxDQUFDLFFBQVEsR0FBRyxTQUFTLENBQUMsV0FBVyxDQUFDO2lCQUN6RDthQUNKO1lBRUQsSUFBSSxDQUFDLEtBQUksQ0FBQyxVQUFVLEVBQUU7Z0JBQ2xCLEtBQUksQ0FBQyxLQUFLLEdBQUcsQ0FBQyxDQUFDO2dCQUNmLEtBQUksQ0FBQyxRQUFRLEVBQUUsQ0FBQzthQUNuQjtpQkFDSTtnQkFDRCxLQUFJLENBQUMsWUFBWSxFQUFFLENBQUM7YUFDdkI7UUFDTCxDQUFDLENBQUMsQ0FBQztJQUNQLENBQUM7SUFFTyw2QkFBWSxHQUFwQjtRQUNJLElBQUksV0FBVyxHQUFXLElBQUksQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLGFBQWEsQ0FBQyxhQUFhLENBQUMsR0FBRyxHQUFHLElBQUksQ0FBQyxHQUFHLEdBQUcsWUFBWSxDQUFDLENBQUMsV0FBVyxHQUFHLElBQUksQ0FBQyxjQUFjLENBQUM7UUFDekksSUFBSSxNQUFNLEdBQUcsV0FBVyxHQUFHLENBQUMsQ0FBQztRQUM3QixJQUFJLEtBQUssR0FBRyxDQUFDLENBQUM7UUFFZCxJQUFJLElBQUksQ0FBQyxVQUFVLEVBQUU7WUFDakIsb0NBQW9DO1lBQ3BDLEtBQUssSUFBSSxDQUFDLEdBQVcsQ0FBQyxFQUFFLENBQUMsR0FBRyxJQUFJLENBQUMsT0FBTyxDQUFDLE1BQU0sRUFBRSxDQUFDLEVBQUUsRUFBRTtnQkFDbEQsSUFBSSxJQUFJLENBQUMsYUFBYSxLQUFLLElBQUksQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLEVBQUU7b0JBQ3hDLEtBQUssSUFBSSxJQUFJLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQztpQkFDbEM7cUJBQ0k7b0JBQ0QsS0FBSyxJQUFJLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLEdBQUcsQ0FBQyxDQUFDLENBQUM7b0JBRXJDLElBQUksSUFBSSxDQUFDLFVBQVUsS0FBSyxNQUFNLEVBQUU7d0JBQzVCLElBQUksQ0FBQyxLQUFLLEdBQUcsTUFBTSxHQUFHLEtBQUssQ0FBQztxQkFDL0I7eUJBQ0k7d0JBQ0QsSUFBSSxDQUFDLEtBQUssR0FBRyxLQUFLLEdBQUcsTUFBTSxDQUFDO3FCQUMvQjtvQkFDRCxNQUFNO2lCQUNUO2FBQ0o7WUFDRCxJQUFJO1lBRUosU0FBUztZQUNULG1FQUFtRTtZQUNuRSx3REFBd0Q7WUFDeEQsOENBQThDO1lBQzlDLFlBQVk7WUFDWixpQkFBaUI7WUFDakIsb0RBQW9EO1lBQ3BELDJDQUEyQztZQUMzQyxxQkFBcUI7WUFDckIsWUFBWTtZQUNaLFFBQVE7WUFDUixJQUFJO1NBQ1A7YUFDSTtZQUNELElBQUksQ0FBQyxLQUFLLEdBQUcsQ0FBQyxDQUFDO1NBQ2xCO1FBQ0QsSUFBSSxDQUFDLFFBQVEsRUFBRSxDQUFDO0lBQ3BCLENBQUM7SUFFTyx5QkFBUSxHQUFoQjtRQUNJLElBQUksSUFBSSxHQUF1QixJQUFJLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxhQUFhLENBQUMsZ0JBQWdCLENBQUMsR0FBRyxHQUFHLElBQUksQ0FBQyxHQUFHLEdBQUcsWUFBWSxDQUFDLENBQUM7UUFFL0csSUFBSSxJQUFJLENBQUMsVUFBVSxLQUFLLE1BQU0sRUFBRTtZQUM1QixJQUFJLElBQUksQ0FBQyxLQUFLLEdBQUcsSUFBSSxDQUFDLFFBQVEsRUFBRTtnQkFDNUIsSUFBSSxDQUFDLEtBQUssR0FBRyxJQUFJLENBQUMsUUFBUSxDQUFDO2FBRTlCO2lCQUNJLElBQUksSUFBSSxDQUFDLEtBQUssSUFBSSxDQUFDLEVBQUU7Z0JBQ3RCLElBQUksQ0FBQyxLQUFLLEdBQUcsQ0FBQyxDQUFDO2FBQ2xCO1lBRUQsSUFBSSxDQUFDLFlBQVksR0FBRyxDQUFDLElBQUksQ0FBQyxLQUFLLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDO1lBQ3RELElBQUksQ0FBQyxhQUFhLEdBQUcsQ0FBQyxJQUFJLENBQUMsS0FBSyxLQUFLLElBQUksQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUM7U0FDdEU7YUFDSTtZQUNELElBQUksSUFBSSxDQUFDLEtBQUssR0FBRyxDQUFDLEVBQUU7Z0JBQ2hCLElBQUksQ0FBQyxLQUFLLEdBQUcsQ0FBQyxDQUFDO2FBQ2xCO2lCQUNJLElBQUksSUFBSSxDQUFDLEtBQUssR0FBRyxJQUFJLENBQUMsUUFBUSxFQUFFO2dCQUNqQyxJQUFJLENBQUMsS0FBSyxHQUFHLElBQUksQ0FBQyxRQUFRLENBQUM7YUFDOUI7WUFFRCxJQUFJLENBQUMsWUFBWSxHQUFHLENBQUMsSUFBSSxDQUFDLEtBQUssS0FBSyxJQUFJLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDO1lBQ2xFLElBQUksQ0FBQyxhQUFhLEdBQUcsQ0FBQyxJQUFJLENBQUMsS0FBSyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQztTQUMxRDtRQUdELElBQUksSUFBSSxHQUFHLElBQUksQ0FBQyxLQUFLLEdBQUcsSUFBSSxDQUFDO1FBRTdCLEtBQUssSUFBSSxDQUFDLEdBQVcsQ0FBQyxFQUFFLENBQUMsR0FBRyxJQUFJLENBQUMsTUFBTSxFQUFFLENBQUMsRUFBRSxFQUFFO1lBQzFDLElBQUksQ0FBQyxTQUFTLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsRUFBRSxNQUFNLEVBQUUsSUFBSSxDQUFDLENBQUM7U0FDbEQ7SUFDTCxDQUFDOztnQkFyUGlCLGdCQUFnQjtnQkFDWCxTQUFTO2dCQUNmLGlCQUFpQjtnQkFDYixTQUFTO2dCQUNULE1BQU07Z0JBQ1QsY0FBYztnQkFDWCxZQUFZO2dCQUNMLGVBQWU7O0lBYmxDO1FBQVIsS0FBSyxFQUFFOzsyQ0FBaUI7SUFDUjtRQUFoQixLQUFLLENBQUMsUUFBUSxDQUFDOzs4Q0FBaUI7SUFDbEI7UUFBZCxLQUFLLENBQUMsTUFBTSxDQUFDOzsyQ0FBaUI7SUFDckI7UUFBVCxNQUFNLEVBQUU7a0NBQWMsWUFBWTsrQ0FBMEI7SUFhN0Q7UUFEQyxZQUFZLENBQUMsZUFBZSxFQUFFLENBQUMsUUFBUSxDQUFDLENBQUM7Ozs7MENBSXpDO0lBbkNRLE1BQU07UUE5Q2xCLFNBQVMsQ0FBQztZQUNQLFFBQVEsRUFBRSxTQUFTO1lBQ2YsUUFBUSxFQUFFLHdrREEyQmI7WUFDRCxhQUFhLEVBQUUsaUJBQWlCLENBQUMsSUFBSTtZQUNyQyxTQUFTLEVBQUUsQ0FBQyxTQUFTLEVBQUUsWUFBWSxDQUFDO1lBQ3BDLElBQUksRUFBRTtnQkFDRixPQUFPLEVBQUUsVUFBVTthQUN0QjtxQkFFUSx5UkFPUjtTQUNKLENBQUM7eUNBd0JvQixnQkFBZ0I7WUFDWCxTQUFTO1lBQ2YsaUJBQWlCO1lBQ2IsU0FBUztZQUNULE1BQU07WUFDVCxjQUFjO1lBQ1gsWUFBWTtZQUNMLGVBQWU7T0E3QmxDLE1BQU0sQ0E0UWxCO0lBQUQsYUFBQztDQUFBLEFBNVFELElBNFFDO1NBNVFZLE1BQU0iLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBDb21wb25lbnQsIElucHV0LCBPdXRwdXQsIEV2ZW50RW1pdHRlciwgVmlld0VuY2Fwc3VsYXRpb24sIE9uSW5pdCwgT25DaGFuZ2VzLCBBZnRlclZpZXdJbml0LCBWaWV3Q29udGFpbmVyUmVmLCBIb3N0TGlzdGVuZXIsIENoYW5nZURldGVjdG9yUmVmLCBSZW5kZXJlcjIgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcclxuaW1wb3J0IHsgdGltZXIgfSBmcm9tICdyeGpzJztcclxuaW1wb3J0IHsgUm91dGVyLCBBY3RpdmF0ZWRSb3V0ZSB9IGZyb20gJ0Bhbmd1bGFyL3JvdXRlcic7XHJcbmltcG9ydCB7IEtkVGFic1N2YyB9IGZyb20gJy4va2QtYW5ndWxhci10YWJzLXN2Yyc7XHJcbmltcG9ydCB7IEtkRG9tRWxlbVN2YyB9IGZyb20gJy4uL2tkLWNvbW1vbi9pbmRleCc7XHJcbmltcG9ydCB7IEtkU3BsaXR0ZXJFdmVudCB9IGZyb20gJy4uL2tkLWFuZ3VsYXItc3BsaXR0ZXIvaW5kZXgnO1xyXG5cclxuQENvbXBvbmVudCh7XHJcbiAgICBzZWxlY3RvcjogJ2tkLXRhYnMnLFxyXG4gICAgICAgIHRlbXBsYXRlOiBgXHJcbiAgICAgICAgPGRpdiBjbGFzcz0nbmF2LWJhcicgW2hpZGRlbl09JyFfaGFzQXJyYXknIFtpZF09J19pZCc+XHJcbiAgICAgICAgICAgIDxidXR0b24gKm5nSWY9J19zY3JvbGxCdG4nIChjbGljayk9J3Njcm9sbChcImxlZnRcIiknIGNsYXNzPSdzY3JvbGwtbGVmdCcgW2Rpc2FibGVkXT0nX2Rpc2FibGVMZWZ0Jz48PC9idXR0b24+XHJcbiAgICAgICAgICAgIDx1bCBjbGFzcz0nbmF2IG5hdi10YWJzJz5cclxuICAgICAgICAgICAgICAgIDxuZy10ZW1wbGF0ZSBuZ0ZvciBsZXQtaXRlbSBbbmdGb3JPZl09J19yZXN1bHQnPlxyXG4gICAgICAgICAgICAgICAgICAgIDxsaSBjbGFzcz0nbmF2LWl0ZW0nIHN0eWxlPSdsZWZ0OjBweCcgW25nQ2xhc3NdPSd7XCJ0YWItc2VsZWN0ZWRcIjogaXRlbS5pc0FjdGl2ZSwgXCJ0YWItZGlzYWJsZWRcIjogaXRlbS5kaXNhYmxlZH0nPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8YSAoY2xpY2spPSdzZWxlY3RUYWIoaXRlbSwgJGV2ZW50KScgY2xhc3M9J25hdi1saW5rJz57e2l0ZW0udGFiTmFtZX19PC9hPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8IS0tIDxhICpuZ0lmPSdpdGVtLnRhYlR5cGUgIT09IFwicm91dGVyXCInIChjbGljayk9J3NlbGVjdFRhYihpdGVtLCAkZXZlbnQpJyBjbGFzcz0nbmF2LWxpbmsnPnt7aXRlbS50YWJOYW1lfX08L2E+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxhICpuZ0lmPSdpdGVtLnRhYlR5cGUgPT09IFwicm91dGVyXCInIChjbGljayk9J3NlbGVjdFRhYihpdGVtLCAkZXZlbnQpJyBjbGFzcz0nbmF2LWxpbmsnIFtyb3V0ZXJMaW5rXT0naXRlbS5yb3V0ZXJQYXRoJz57e2l0ZW0udGFiTmFtZX19PC9hPiAtLT5cclxuICAgICAgICAgICAgICAgICAgICA8L2xpPlxyXG4gICAgICAgICAgICAgICAgPC9uZy10ZW1wbGF0ZT5cclxuICAgICAgICAgICAgPC91bD5cclxuICAgICAgICAgICAgPGJ1dHRvbiAqbmdJZj0nX3Njcm9sbEJ0bicgKGNsaWNrKT0nc2Nyb2xsKFwicmlnaHRcIiknIGNsYXNzPSdzY3JvbGwtcmlnaHQnIFtkaXNhYmxlZF09J19kaXNhYmxlUmlnaHQnPj48L2J1dHRvbj5cclxuICAgICAgICAgICAgPGRpdiBjbGFzcz0ndGFiLWRpdmlkZXInPjwvZGl2PlxyXG4gICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgPG5nLXRlbXBsYXRlIFtuZ0lmXT0nX3ByZXZpb3VzSXRlbSAmJiBfcHJldmlvdXNJdGVtLnRhYlR5cGUgPT09IFwiY29udGVudFwiJz5cclxuICAgICAgICAgICAgPGRpdiBjbGFzcz0ndGFiLWNvbnRlbnQnPlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzcz0ndGFiLXBhbmUnIFtuZ0NsYXNzXT0ne1wiYWN0aXZlXCI6IF9wcmV2aW91c0l0ZW0uaXNBY3RpdmV9Jz57e19wcmV2aW91c0l0ZW0udGFiQ29udGVudH19PC9kaXY+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDwvbmctdGVtcGxhdGU+XHJcblxyXG4gICAgICAgIDxuZy10ZW1wbGF0ZSBbbmdJZl09J3RhYlR5cGUgPT09IFwicm91dGVyXCIgfHwgdGFiVHlwZSA9PT0gXCJodG1sXCInPlxyXG4gICAgICAgICAgICA8bmctY29udGVudD48L25nLWNvbnRlbnQ+XHJcbiAgICAgICAgPC9uZy10ZW1wbGF0ZT5cclxuXHJcbiAgICAgICAgPGRpdiBjbGFzcz0ndGFiLWJvdHRvbS1kaXZpZGVyJz48L2Rpdj5cclxuICAgIGAsXHJcbiAgICBlbmNhcHN1bGF0aW9uOiBWaWV3RW5jYXBzdWxhdGlvbi5Ob25lLFxyXG4gICAgcHJvdmlkZXJzOiBbS2RUYWJzU3ZjLCBLZERvbUVsZW1TdmNdLFxyXG4gICAgaG9zdDoge1xyXG4gICAgICAgICdjbGFzcyc6ICdrZHgtdGFicycsXHJcbiAgICB9LFxyXG4gICAgLy8gVGVtcCBzY2hvb2wgb3ZlcndyaXRlcyBmb3Igc3R5bGluZyBmb3IgZGlzYWJsZWQgYXR0cmlidXRlIGZvciBPcGVuRU1JUyBTY2hvb2wgb25seSAtIFRvIHByb3BlciB1cGRhdGVzIHN0eWxlIGNsYXNzZXMgaW4gc3R5bGVndWlkZSB0byBoYXZlIHRoZSBkaXNhYmxlZCBjbGFzcyBzdHlsaW5nXHJcbiAgICBzdHlsZXM6IFtgXHJcbiAgICAgICAgLmFuZ3VsYXItdGFicyAubmF2LXRhYnMgLm5hdi1pdGVtLnRhYi1kaXNhYmxlZCA+IGEubmF2LWxpbms6aG92ZXIge1xyXG4gICAgICAgICAgICBjb2xvcjogIzMzMyAhaW1wb3J0YW50O1xyXG4gICAgICAgICAgICBib3JkZXI6IDFweCBzb2xpZCAjREREICFpbXBvcnRhbnQ7XHJcbiAgICAgICAgICAgIGN1cnNvcjogbm90LWFsbG93ZWQgIWltcG9ydGFudDtcclxuICAgICAgICAgICAgYmFja2dyb3VuZC1jb2xvcjogdHJhbnNwYXJlbnQgIWltcG9ydGFudDtcclxuICAgICAgICB9XHJcbiAgICBgXVxyXG59KVxyXG5cclxuZXhwb3J0IGNsYXNzIEtkVGFicyBpbXBsZW1lbnRzIE9uSW5pdCwgT25DaGFuZ2VzLCBBZnRlclZpZXdJbml0IHtcclxuICAgIHB1YmxpYyBfaWQ6IHN0cmluZztcclxuICAgIHB1YmxpYyBfcmVzdWx0OiBBcnJheTxhbnk+ID0gW107XHJcbiAgICBwdWJsaWMgX2hhc0FycmF5OiBib29sZWFuID0gZmFsc2U7XHJcbiAgICBwdWJsaWMgX3Njcm9sbEJ0bjogYm9vbGVhbiA9IGZhbHNlO1xyXG4gICAgcHVibGljIF9wcmV2aW91c0l0ZW06IGFueTtcclxuICAgIHB1YmxpYyBfZGlzYWJsZUxlZnQ6IGJvb2xlYW4gPSBmYWxzZTtcclxuICAgIHB1YmxpYyBfZGlzYWJsZVJpZ2h0OiBib29sZWFuID0gZmFsc2U7XHJcblxyXG4gICAgcHJpdmF0ZSBfbGVmdDogbnVtYmVyID0gMDtcclxuICAgIHByaXZhdGUgX21heExlZnQ6IG51bWJlciA9IDA7XHJcbiAgICBwcml2YXRlIF91bFdpZHRoOiBudW1iZXIgPSAwO1xyXG4gICAgcHJpdmF0ZSBfdWxNYXJnaW46IG51bWJlciA9IDA7XHJcbiAgICBwcml2YXRlIF9kaXJlY3Rpb246IGFueTtcclxuICAgIHByaXZhdGUgX3BhcmVudFBhZGRpbmc6IG51bWJlciA9IDMwO1xyXG5cclxuICAgIEBJbnB1dCgpIGlucHV0SWQ6IHN0cmluZztcclxuICAgIEBJbnB1dCgnY29uZmlnJykgdGFic0NvbmZpZzogYW55O1xyXG4gICAgQElucHV0KCd0eXBlJykgdGFiVHlwZTogc3RyaW5nO1xyXG4gICAgQE91dHB1dCgpIGFjdGl2ZVN0YXRlOiBFdmVudEVtaXR0ZXI8e30+ID0gbmV3IEV2ZW50RW1pdHRlcigpO1xyXG5cclxuICAgIGNvbnN0cnVjdG9yKFxyXG4gICAgICAgIHByaXZhdGUgX3ZjcjogVmlld0NvbnRhaW5lclJlZixcclxuICAgICAgICBwcml2YXRlIF9yZW5kZXJlcjogUmVuZGVyZXIyLFxyXG4gICAgICAgIHByaXZhdGUgX2NkOiBDaGFuZ2VEZXRlY3RvclJlZixcclxuICAgICAgICBwcml2YXRlIF90YWJTdmM6IEtkVGFic1N2YyxcclxuICAgICAgICBwcml2YXRlIF9yb3V0ZXI6IFJvdXRlcixcclxuICAgICAgICBfYWN0aXZlUm91dGU6IEFjdGl2YXRlZFJvdXRlLFxyXG4gICAgICAgIHByaXZhdGUgX2RvbUVsZTogS2REb21FbGVtU3ZjLFxyXG4gICAgICAgIHByaXZhdGUgX3NwbGl0dGVyRXZlbnQ6IEtkU3BsaXR0ZXJFdmVudCkgeyB9XHJcblxyXG4gICAgQEhvc3RMaXN0ZW5lcignd2luZG93OnJlc2l6ZScsIFsnJGV2ZW50J10pXHJcbiAgICBvblJlc2l6ZShldmVudDogYW55KTogdm9pZCB7XHJcbiAgICAgICAgdGhpcy5fY2hlY2tXaWR0aCgpO1xyXG4gICAgICAgIHRoaXMuX2NoZWNrU2Nyb2xsYWJsZSgpO1xyXG4gICAgfVxyXG5cclxuICAgIG5nT25Jbml0KCk6IHZvaWQge1xyXG4gICAgICAgIHRoaXMuX2lkID0gKHR5cGVvZiB0aGlzLmlucHV0SWQgIT09ICd1bmRlZmluZWQnKSA/IHRoaXMuaW5wdXRJZCA6ICd0YWJzJztcclxuICAgICAgICB0aGlzLl9yZXN1bHQgPSB0aGlzLl90YWJTdmMuc2V0UmVzdWx0KHRoaXMudGFic0NvbmZpZywgdGhpcy50YWJUeXBlKTtcclxuXHJcbiAgICAgICAgdGhpcy5faGFzQXJyYXkgPSB0aGlzLl90YWJTdmMuY2hlY2tIYXNBcnJheSh0aGlzLl9yZXN1bHQpO1xyXG5cclxuICAgICAgICBpZiAodHlwZW9mIHRoaXMuX3Jlc3VsdCAhPT0gJ3VuZGVmaW5lZCcpIHtcclxuICAgICAgICAgICAgZm9yIChsZXQgaTogbnVtYmVyID0gMDsgaSA8IHRoaXMuX3Jlc3VsdC5sZW5ndGg7IGkrKykge1xyXG4gICAgICAgICAgICAgICAgaWYgKHRoaXMuX3Jlc3VsdFtpXS5pc0FjdGl2ZSA9PT0gdHJ1ZSkge1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuX3ByZXZpb3VzSXRlbSA9IHRoaXMuX3Jlc3VsdFtpXTtcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLmFjdGl2ZVN0YXRlLmVtaXQodGhpcy5fcHJldmlvdXNJdGVtLnRhYklkKTtcclxuXHJcbiAgICAgICAgICAgICAgICAgICAgLy8gaWYgKHRoaXMuX3ByZXZpb3VzSXRlbS50YWJUeXBlID09PSAncm91dGVyJykge1xyXG4gICAgICAgICAgICAgICAgICAgIC8vICAgICB0aGlzLl9yb3V0ZXIubmF2aWdhdGUoWycuLycgKyB0aGlzLl9wcmV2aW91c0l0ZW0ucm91dGVyUGF0aF0sIHsgcmVsYXRpdmVUbzogdGhpcy5fcm91dGUgfSk7XHJcbiAgICAgICAgICAgICAgICAgICAgLy8gfVxyXG4gICAgICAgICAgICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICB0aGlzLl9zcGxpdHRlckV2ZW50Lm9uRHJhZygpXHJcbiAgICAgICAgICAgIC5zdWJzY3JpYmUoX3R5cGUgPT4ge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5fY2hlY2tXaWR0aCgpO1xyXG4gICAgICAgICAgICAgICAgdGhpcy5fY2hlY2tTY3JvbGxhYmxlKCk7XHJcbiAgICAgICAgICAgIH0pO1xyXG5cclxuICAgICAgICB0aGlzLl9zcGxpdHRlckV2ZW50Lm9uVG9nZ2xlTWVudSgpXHJcbiAgICAgICAgICAgIC5zdWJzY3JpYmUoX3R5cGUgPT4ge1xyXG4gICAgICAgICAgICAgICAgdGltZXIoNTAwKS5zdWJzY3JpYmUoKCk6IHZvaWQgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuX2NoZWNrV2lkdGgoKTtcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLl9jaGVja1Njcm9sbGFibGUoKTtcclxuICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICB9KTtcclxuICAgIH1cclxuXHJcbiAgICBuZ09uQ2hhbmdlcygpOiB2b2lkIHtcclxuICAgICAgICB0aGlzLl9yZXN1bHQgPSB0aGlzLl90YWJTdmMuc2V0UmVzdWx0KHRoaXMudGFic0NvbmZpZywgdGhpcy50YWJUeXBlKTtcclxuICAgICAgICB0aGlzLl9oYXNBcnJheSA9IHRoaXMuX3RhYlN2Yy5jaGVja0hhc0FycmF5KHRoaXMuX3Jlc3VsdCk7XHJcblxyXG4gICAgICAgIGlmICh0eXBlb2YgdGhpcy5fcmVzdWx0ICE9PSAndW5kZWZpbmVkJykge1xyXG4gICAgICAgICAgICBmb3IgKGxldCBpOiBudW1iZXIgPSAwOyBpIDwgdGhpcy5fcmVzdWx0Lmxlbmd0aDsgaSsrKSB7XHJcbiAgICAgICAgICAgICAgICBpZiAodGhpcy5fcmVzdWx0W2ldLmlzQWN0aXZlID09PSB0cnVlKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5fcHJldmlvdXNJdGVtID0gdGhpcy5fcmVzdWx0W2ldO1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuYWN0aXZlU3RhdGUuZW1pdCh0aGlzLl9wcmV2aW91c0l0ZW0udGFiSWQpO1xyXG5cclxuICAgICAgICAgICAgICAgICAgICBpZiAodGhpcy5fcHJldmlvdXNJdGVtLnRhYlR5cGUgPT09ICdyb3V0ZXInKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC8vIGNvbnNvbGUubG9nKCdLZC1hbmd1bGFyLXRhYiAtIE5lZWQgdG8gcmVsb29rIHRoaXMgc2VjdGlvbicsIHRoaXMuX3ByZXZpb3VzSXRlbS5yb3V0ZXJQYXRoLCB0aGlzLl9yb3V0ZSApO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAvLyB0aGlzLl9yb3V0ZXIubmF2aWdhdGUoWycuLycgKyB0aGlzLl9wcmV2aW91c0l0ZW0ucm91dGVyUGF0aF0sIHsgcmVsYXRpdmVUbzogdGhpcy5fcm91dGUgfSk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC8qIENoYW5nZSB0aGUgbmF2aWdhdGlvbiBvbiBmaXJzdCBsb2FkIHRvIHVzZSBmdWxsIHJvdXRlciBwYXRoIHRvIG1hdGNoIGFsbCB0aGUgcGF0aCAqL1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLl9yb3V0ZXIubmF2aWdhdGVCeVVybCh0aGlzLl9wcmV2aW91c0l0ZW0ucm91dGVyUGF0aCk7XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICB0aW1lcig1MCkuc3Vic2NyaWJlKCgpOiB2b2lkID0+IHtcclxuICAgICAgICAgICAgdGhpcy5fY2hlY2tXaWR0aCgpO1xyXG4gICAgICAgICAgICB0aGlzLl9jaGVja1Njcm9sbGFibGUoKTtcclxuICAgICAgICB9KTtcclxuXHJcbiAgICB9XHJcblxyXG4gICAgbmdBZnRlclZpZXdJbml0KCk6IHZvaWQge1xyXG4gICAgICAgIC8vIHRoaXMuX2RpcmVjdGlvbiA9IHRoaXMuX3RhYlN2Yy5jaGVja0RpcmVjdGlvbigpO1xyXG4gICAgICAgIHRoaXMuX2RpcmVjdGlvbiA9IHRoaXMuX2RvbUVsZS5nZXREb2N1bWVudERpcmVjdGlvbih0cnVlKTtcclxuICAgICAgICB0aGlzLl9jaGVja1dpZHRoKCk7XHJcblxyXG4gICAgICAgIHRoaXMuX2NkLmRldGFjaCgpO1xyXG4gICAgICAgIHRoaXMuX2NoZWNrU2Nyb2xsYWJsZSgpO1xyXG4gICAgICAgIHRoaXMuX2NkLmRldGVjdENoYW5nZXMoKTtcclxuICAgICAgICB0aGlzLl9jZC5yZWF0dGFjaCgpO1xyXG4gICAgfVxyXG5cclxuICAgIHB1YmxpYyBzZWxlY3RUYWIoaXRlbTogYW55LCBlOiBFdmVudCk6IHZvaWQge1xyXG4gICAgICAgIGUucHJldmVudERlZmF1bHQoKTtcclxuICAgICAgICBpZiAodHlwZW9mIGl0ZW0uZGlzYWJsZWQgIT09ICd1bmRlZmluZWQnICYmIGl0ZW0uZGlzYWJsZWQpIHJldHVybjtcclxuXHJcbiAgICAgICAgaWYgKHR5cGVvZiB0aGlzLl9wcmV2aW91c0l0ZW0gIT09ICd1bmRlZmluZWQnICYmIHRoaXMuX3ByZXZpb3VzSXRlbSAhPT0gaXRlbSkge1xyXG4gICAgICAgICAgICB0aGlzLl9wcmV2aW91c0l0ZW0uaXNBY3RpdmUgPSBmYWxzZTtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIGlmIChpdGVtLnRhYlR5cGUgPT09ICdyb3V0ZXInICYmIGl0ZW0uaXNBY3RpdmUgPT09IGZhbHNlKSB7XHJcbiAgICAgICAgICAgIHRoaXMuX3JvdXRlci5uYXZpZ2F0ZUJ5VXJsKGl0ZW0ucm91dGVyUGF0aCk7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICBpdGVtLmlzQWN0aXZlID0gdHJ1ZTtcclxuICAgICAgICB0aGlzLl9wcmV2aW91c0l0ZW0gPSBpdGVtO1xyXG4gICAgICAgIHRoaXMuYWN0aXZlU3RhdGUuZW1pdCh0aGlzLl9wcmV2aW91c0l0ZW0udGFiSWQpO1xyXG4gICAgICAgIHRoaXMuX3NldFNlbGVjdGVkKCk7XHJcbiAgICB9XHJcblxyXG4gICAgcHVibGljIHNjcm9sbChkaXJlY3Rpb246IHN0cmluZyk6IHZvaWQge1xyXG4gICAgICAgIGxldCBvZmZzZXRYOiBudW1iZXIgPSAyMDA7XHJcbiAgICAgICAgdGhpcy5fbGVmdCA9IChkaXJlY3Rpb24gPT09ICdyaWdodCcpID8gdGhpcy5fbGVmdCAtIG9mZnNldFggOiB0aGlzLl9sZWZ0ICsgb2Zmc2V0WDtcclxuICAgICAgICB0aGlzLl9zZXRMZWZ0KCk7XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfY2hlY2tXaWR0aCgpOiB2b2lkIHtcclxuICAgICAgICB0aGlzLl91bFdpZHRoID0gMDtcclxuICAgICAgICBsZXQgdWxMaXN0OiBBcnJheTxIVE1MRWxlbWVudD4gPSB0aGlzLl92Y3IuZWxlbWVudC5uYXRpdmVFbGVtZW50LnF1ZXJ5U2VsZWN0b3JBbGwoJyMnICsgdGhpcy5faWQgKyAnIC5uYXYtaXRlbScpO1xyXG4gICAgICAgIC8vIGNvbnNvbGUubG9nKHVsTGlzdCk7XHJcbiAgICAgICAgLy8gY29uc29sZS5sb2codGhpcy5fcmVzdWx0KTtcclxuICAgICAgICBpZiAodHlwZW9mIHVsTGlzdCAhPT0gJ3VuZGVmaW5lZCcgJiYgdWxMaXN0Lmxlbmd0aCA+IDEpIHtcclxuICAgICAgICAgICAgaWYgKHRoaXMuX2RpcmVjdGlvbiA9PT0gJ2xlZnQnKSB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLl91bE1hcmdpbiA9IHVsTGlzdFsxXS5nZXRCb3VuZGluZ0NsaWVudFJlY3QoKS5sZWZ0IC0gdWxMaXN0WzBdLmdldEJvdW5kaW5nQ2xpZW50UmVjdCgpLnJpZ2h0O1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5fdWxNYXJnaW4gPSB1bExpc3RbMF0uZ2V0Qm91bmRpbmdDbGllbnRSZWN0KCkubGVmdCAtIHVsTGlzdFsxXS5nZXRCb3VuZGluZ0NsaWVudFJlY3QoKS5yaWdodDtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgaWYgKHR5cGVvZiB0aGlzLl9yZXN1bHQgIT09ICd1bmRlZmluZWQnKSB7XHJcbiAgICAgICAgICAgIGZvciAobGV0IGk6IG51bWJlciA9IDA7IGkgPCB1bExpc3QubGVuZ3RoOyBpKyspIHtcclxuICAgICAgICAgICAgICAgIGlmICh0eXBlb2YgdGhpcy5fcmVzdWx0W2ldID09PSAndW5kZWZpbmVkJykgY29udGludWU7XHJcblxyXG4gICAgICAgICAgICAgICAgdGhpcy5fcmVzdWx0W2ldLndpZHRoID0gTWF0aC5yb3VuZCh1bExpc3RbaV0uZ2V0Qm91bmRpbmdDbGllbnRSZWN0KCkud2lkdGgpO1xyXG5cclxuICAgICAgICAgICAgICAgIGlmIChpICE9PSAwKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5fcmVzdWx0W2ldLndpZHRoID0gTWF0aC5yb3VuZCh0aGlzLl9yZXN1bHRbaV0ud2lkdGggKyB0aGlzLl91bE1hcmdpbik7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICB0aGlzLl91bFdpZHRoICs9IHRoaXMuX3Jlc3VsdFtpXS53aWR0aDtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuXHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfY2hlY2tTY3JvbGxhYmxlKCk6IHZvaWQge1xyXG4gICAgICAgIGxldCBwYXJlbnRXaWR0aDogbnVtYmVyID0gdGhpcy5fdmNyLmVsZW1lbnQubmF0aXZlRWxlbWVudC5wYXJlbnRFbGVtZW50LmdldEJvdW5kaW5nQ2xpZW50UmVjdCgpLndpZHRoO1xyXG4gICAgICAgIGxldCB1bEVsZW1lbnQ6IEhUTUxFbGVtZW50ID0gdGhpcy5fdmNyLmVsZW1lbnQubmF0aXZlRWxlbWVudC5xdWVyeVNlbGVjdG9yKCcjJyArIHRoaXMuX2lkICsgJyAubmF2LXRhYnMnKTtcclxuICAgICAgICB0aGlzLl9zY3JvbGxCdG4gPSAodGhpcy5fdWxXaWR0aCA+IHBhcmVudFdpZHRoKSA/IHRydWUgOiBmYWxzZTtcclxuICAgICAgICB0aGlzLl9zY3JvbGxCdG4gPyB0aGlzLl9yZW5kZXJlci5hZGRDbGFzcyh1bEVsZW1lbnQsICdzY3JvbGxhYmxlJykgOiB0aGlzLl9yZW5kZXJlci5yZW1vdmVDbGFzcyh1bEVsZW1lbnQsICdzY3JvbGxhYmxlJyk7XHJcblxyXG4gICAgICAgIHRpbWVyKDEwMCkuc3Vic2NyaWJlKCgpOiB2b2lkID0+IHtcclxuICAgICAgICAgICAgaWYgKHVsRWxlbWVudC5jbGllbnRXaWR0aCA8IHRoaXMuX3VsV2lkdGgpIHtcclxuICAgICAgICAgICAgICAgIGlmICh0aGlzLl9kaXJlY3Rpb24gPT09ICdsZWZ0Jykge1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuX21heExlZnQgPSB1bEVsZW1lbnQuY2xpZW50V2lkdGggLSB0aGlzLl91bFdpZHRoO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgZWxzZSB7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5fbWF4TGVmdCA9IHRoaXMuX3VsV2lkdGggLSB1bEVsZW1lbnQuY2xpZW50V2lkdGg7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgIGlmICghdGhpcy5fc2Nyb2xsQnRuKSB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLl9sZWZ0ID0gMDtcclxuICAgICAgICAgICAgICAgIHRoaXMuX3NldExlZnQoKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgICAgIHRoaXMuX3NldFNlbGVjdGVkKCk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9KTtcclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF9zZXRTZWxlY3RlZCgpOiB2b2lkIHtcclxuICAgICAgICBsZXQgcGFyZW50V2lkdGg6IG51bWJlciA9IHRoaXMuX3Zjci5lbGVtZW50Lm5hdGl2ZUVsZW1lbnQucXVlcnlTZWxlY3RvcignIycgKyB0aGlzLl9pZCArICcgLm5hdi10YWJzJykuY2xpZW50V2lkdGggLSB0aGlzLl9wYXJlbnRQYWRkaW5nO1xyXG4gICAgICAgIGxldCBtaWRkbGUgPSBwYXJlbnRXaWR0aCAvIDI7XHJcbiAgICAgICAgbGV0IHdpZHRoID0gMDtcclxuXHJcbiAgICAgICAgaWYgKHRoaXMuX3Njcm9sbEJ0bikge1xyXG4gICAgICAgICAgICAvLyBpZiAodGhpcy5fZGlyZWN0aW9uID09PSAnbGVmdCcpIHtcclxuICAgICAgICAgICAgZm9yIChsZXQgaTogbnVtYmVyID0gMDsgaSA8IHRoaXMuX3Jlc3VsdC5sZW5ndGg7IGkrKykge1xyXG4gICAgICAgICAgICAgICAgaWYgKHRoaXMuX3ByZXZpb3VzSXRlbSAhPT0gdGhpcy5fcmVzdWx0W2ldKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgd2lkdGggKz0gdGhpcy5fcmVzdWx0W2ldLndpZHRoO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgZWxzZSB7XHJcbiAgICAgICAgICAgICAgICAgICAgd2lkdGggKz0gKHRoaXMuX3Jlc3VsdFtpXS53aWR0aCAvIDIpO1xyXG5cclxuICAgICAgICAgICAgICAgICAgICBpZiAodGhpcy5fZGlyZWN0aW9uID09PSAnbGVmdCcpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5fbGVmdCA9IG1pZGRsZSAtIHdpZHRoO1xyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5fbGVmdCA9IHdpZHRoIC0gbWlkZGxlO1xyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICBicmVhaztcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAvLyB9XHJcblxyXG4gICAgICAgICAgICAvLyBlbHNlIHtcclxuICAgICAgICAgICAgLy8gICAgIGZvciAobGV0IGk6IG51bWJlciA9IHRoaXMuX3Jlc3VsdC5sZW5ndGggLSAxOyBpID49IDA7IGktLSkge1xyXG4gICAgICAgICAgICAvLyAgICAgICAgIGlmICh0aGlzLl9wcmV2aW91c0l0ZW0gIT09IHRoaXMuX3Jlc3VsdFtpXSkge1xyXG4gICAgICAgICAgICAvLyAgICAgICAgICAgICB3aWR0aCArPSB0aGlzLl9yZXN1bHRbaV0ud2lkdGg7XHJcbiAgICAgICAgICAgIC8vICAgICAgICAgfVxyXG4gICAgICAgICAgICAvLyAgICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICAvLyAgICAgICAgICAgICB3aWR0aCArPSAodGhpcy5fcmVzdWx0W2ldLndpZHRoIC8gMik7XHJcbiAgICAgICAgICAgIC8vICAgICAgICAgICAgIHRoaXMuX2xlZnQgPSB3aWR0aCAtIG1pZGRsZTtcclxuICAgICAgICAgICAgLy8gICAgICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgICAgIC8vICAgICAgICAgfVxyXG4gICAgICAgICAgICAvLyAgICAgfVxyXG4gICAgICAgICAgICAvLyB9XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICB0aGlzLl9sZWZ0ID0gMDtcclxuICAgICAgICB9XHJcbiAgICAgICAgdGhpcy5fc2V0TGVmdCgpO1xyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX3NldExlZnQoKTogdm9pZCB7XHJcbiAgICAgICAgbGV0IGl0ZW06IEFycmF5PEhUTUxFbGVtZW50PiA9IHRoaXMuX3Zjci5lbGVtZW50Lm5hdGl2ZUVsZW1lbnQucXVlcnlTZWxlY3RvckFsbCgnIycgKyB0aGlzLl9pZCArICcgLm5hdi1pdGVtJyk7XHJcblxyXG4gICAgICAgIGlmICh0aGlzLl9kaXJlY3Rpb24gPT09ICdsZWZ0Jykge1xyXG4gICAgICAgICAgICBpZiAodGhpcy5fbGVmdCA8IHRoaXMuX21heExlZnQpIHtcclxuICAgICAgICAgICAgICAgIHRoaXMuX2xlZnQgPSB0aGlzLl9tYXhMZWZ0O1xyXG5cclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBlbHNlIGlmICh0aGlzLl9sZWZ0ID49IDApIHtcclxuICAgICAgICAgICAgICAgIHRoaXMuX2xlZnQgPSAwO1xyXG4gICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICB0aGlzLl9kaXNhYmxlTGVmdCA9ICh0aGlzLl9sZWZ0ID09PSAwKSA/IHRydWUgOiBmYWxzZTtcclxuICAgICAgICAgICAgdGhpcy5fZGlzYWJsZVJpZ2h0ID0gKHRoaXMuX2xlZnQgPT09IHRoaXMuX21heExlZnQpID8gdHJ1ZSA6IGZhbHNlO1xyXG4gICAgICAgIH1cclxuICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgaWYgKHRoaXMuX2xlZnQgPCAwKSB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLl9sZWZ0ID0gMDtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBlbHNlIGlmICh0aGlzLl9sZWZ0ID4gdGhpcy5fbWF4TGVmdCkge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5fbGVmdCA9IHRoaXMuX21heExlZnQ7XHJcbiAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgIHRoaXMuX2Rpc2FibGVMZWZ0ID0gKHRoaXMuX2xlZnQgPT09IHRoaXMuX21heExlZnQpID8gdHJ1ZSA6IGZhbHNlO1xyXG4gICAgICAgICAgICB0aGlzLl9kaXNhYmxlUmlnaHQgPSAodGhpcy5fbGVmdCA9PT0gMCkgPyB0cnVlIDogZmFsc2U7XHJcbiAgICAgICAgfVxyXG5cclxuXHJcbiAgICAgICAgbGV0IG1vdmUgPSB0aGlzLl9sZWZ0ICsgJ3B4JztcclxuXHJcbiAgICAgICAgZm9yIChsZXQgaTogbnVtYmVyID0gMDsgaSA8IGl0ZW0ubGVuZ3RoOyBpKyspIHtcclxuICAgICAgICAgICAgdGhpcy5fcmVuZGVyZXIuc2V0U3R5bGUoaXRlbVtpXSwgJ2xlZnQnLCBtb3ZlKTtcclxuICAgICAgICB9XHJcbiAgICB9XHJcbn1cclxuIl19