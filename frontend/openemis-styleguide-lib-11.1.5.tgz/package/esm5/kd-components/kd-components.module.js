import { __decorate } from "tslib";
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
// third party plugins
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { ToasterModule } from 'angular2-toaster';
import { AgGridModule } from 'ag-grid-angular';
import { CalendarModule, DateAdapter } from 'angular-calendar';
import { GridsterModule } from 'angular-gridster2';
import { AutoCompleteModule } from 'primeng/autocomplete';
import { DropdownModule } from 'primeng/dropdown';
import { MenuModule } from 'primeng/menu';
import { ButtonModule } from 'primeng/button';
import { TooltipModule } from 'primeng/tooltip';
import { ChartModule } from 'primeng/chart';
import { TreeModule } from 'primeng/tree';
import { SharedModule } from 'primeng/api';
import { SliderModule } from 'primeng/slider';
import { PaginatorModule } from 'primeng/paginator';
// OpenEMIS component list
// import { KD_COMPONENTS_PVDERS, getProdInfo } from './kd-components.provider';
import { KdHeader } from './kd-angular-header/index';
import { KdSplitter, KdPane } from './kd-angular-splitter/index';
import { KdFooter } from './kd-angular-footer/index';
import { KdLeftMenu } from './kd-angular-leftmenu/index';
import { KdBreadcrumb } from './kd-angular-breadcrumb/index';
import { KdPageheader, KdToolbar } from './kd-angular-pageheader/index';
import { KdAlert } from './kd-angular-alert/index';
import { KdTemplateLayout } from './kd-angular-template-layout/index';
import { KdCodeblock } from './kd-angular-codeblock/kd-angular-codeblock';
import { KdTabs } from './kd-angular-tabs/index';
import { KdLogin, KdLoginForm } from './kd-angular-login/index';
import { KdError } from './kd-angular-error/index';
import { KdAdvFilter } from './kd-angular-adv-filter/index';
import { KdView } from './kd-angular-view/index';
import { KdSlider, KdSliderContent } from './kd-angular-slider/index';
import { KdTable, KdTableAction, KdTableCheckboxRadio, KdTableInput, KdTableImage } from './kd-angular-table/index';
import { KdTooltip, KdTooltipDirective } from './kd-angular-tooltip/index';
import { KdInput } from './kd-angular-input/kd-angular-input';
import { KdButtonGroup } from './kd-angular-button-group/index';
import { KdPlaceholder } from './kd-angular-placeholder/index';
import { KdModal } from './kd-angular-modal/index';
import { KdTextInput } from './kd-angular-text-input/index';
import { KdMultiSelectTable } from './kd-angular-multiselect-table/index';
import { KdCheckboxRadio } from './kd-angular-checkbox-radio/index';
import { KdDatepicker } from './kd-angular-datepicker/index';
import { KdTimepicker } from './kd-angular-timepicker/index';
import { KdTreeDropdown } from './kd-angular-treedropdown/index';
import { KdProgressloader } from './kd-angular-progressloader/index';
import { KdFileInput } from './kd-angular-fileinput/index';
import { KdMap } from './kd-angular-map/index';
import { KdFilter } from './kd-angular-filter/index';
import { KdSearch } from './kd-angular-search/index';
import { KdDelete } from './kd-angular-delete-comp/index';
import { KdFonts, FilterArrayPipe } from './kd-angular-fonts/index';
import { KdMiniDashboard, KdMiniDashboardChart } from './kd-angular-mini-dashboard/index';
import { KdWizard } from './kd-angular-wizard/index';
import { KdCalendar } from './kd-angular-calendar/index';
import { KdMindmap, KdMindmapNode, KdMindmapLink, KdMindmapZoomDirective, KdMindmapDragDirective, KdMindmapZoomButton } from './kd-angular-mindmap/index';
import { KdGridster, KdGridsterToolbar } from './kd-angular-gridster/index';
import { KdCharts, KdBarChart, KdLineChart, KdPieChart, KdMapChart } from './kd-angular-charts/index';
import { KdVisualization } from './kd-angular-visualization/index';
import { adapterFactory } from 'angular-calendar/date-adapters/date-fns';
var ɵ0 = adapterFactory;
var KdComponentsModule = /** @class */ (function () {
    function KdComponentsModule() {
    }
    KdComponentsModule = __decorate([
        NgModule({
            imports: [
                CommonModule,
                FormsModule,
                ReactiveFormsModule,
                NgbModule,
                ToasterModule,
                TreeModule,
                SharedModule,
                AutoCompleteModule,
                DropdownModule,
                MenuModule,
                ButtonModule,
                TooltipModule,
                ChartModule,
                SliderModule,
                PaginatorModule,
                AgGridModule.withComponents([
                    KdTableAction,
                    KdTableCheckboxRadio,
                    KdTableInput,
                    KdTableImage
                ]),
                CalendarModule.forRoot({
                    provide: DateAdapter,
                    useFactory: ɵ0
                }),
                GridsterModule
            ],
            declarations: [
                KdHeader,
                KdFooter,
                KdSplitter,
                KdPane,
                KdBreadcrumb,
                KdLeftMenu,
                KdPageheader,
                KdToolbar,
                KdAlert,
                KdTemplateLayout,
                KdCodeblock,
                KdTabs,
                KdLogin,
                KdLoginForm,
                KdError,
                KdAdvFilter,
                KdView,
                KdSlider,
                KdSliderContent,
                KdTable,
                KdTableAction,
                KdTableCheckboxRadio,
                KdTableImage,
                KdTableInput,
                KdTooltip,
                KdTooltipDirective,
                KdInput,
                KdTextInput,
                KdButtonGroup,
                KdPlaceholder,
                KdModal,
                KdMultiSelectTable,
                KdCheckboxRadio,
                KdDatepicker,
                KdTimepicker,
                KdTreeDropdown,
                KdProgressloader,
                KdFileInput,
                KdMap,
                KdFilter,
                KdSearch,
                KdDelete,
                KdFonts,
                FilterArrayPipe,
                KdMiniDashboard,
                KdMiniDashboardChart,
                KdWizard,
                KdCalendar,
                KdMindmap,
                KdMindmapNode,
                KdMindmapLink,
                KdMindmapZoomDirective,
                KdMindmapDragDirective,
                KdMindmapZoomButton,
                KdGridster,
                KdGridsterToolbar,
                KdCharts,
                KdBarChart,
                KdLineChart,
                KdPieChart,
                KdMapChart,
                KdVisualization,
            ],
            exports: [
                PaginatorModule,
                MenuModule,
                CommonModule,
                FormsModule,
                ReactiveFormsModule,
                KdHeader,
                KdFooter,
                KdSplitter,
                KdPane,
                KdBreadcrumb,
                KdLeftMenu,
                KdPageheader,
                KdToolbar,
                KdAlert,
                KdTemplateLayout,
                KdCodeblock,
                KdTabs,
                KdLogin,
                KdLoginForm,
                KdError,
                KdAdvFilter,
                KdView,
                KdSlider,
                KdSliderContent,
                KdTable,
                KdTableAction,
                KdTableCheckboxRadio,
                KdTableInput,
                KdTableImage,
                KdTooltip,
                KdTooltipDirective,
                KdInput,
                KdTextInput,
                KdButtonGroup,
                KdPlaceholder,
                KdModal,
                KdMultiSelectTable,
                KdCheckboxRadio,
                KdDatepicker,
                KdTimepicker,
                KdTreeDropdown,
                KdProgressloader,
                KdFileInput,
                KdMap,
                KdFilter,
                KdSearch,
                KdDelete,
                KdFonts,
                FilterArrayPipe,
                KdMiniDashboard,
                KdMiniDashboardChart,
                KdWizard,
                KdCalendar,
                KdMindmap,
                KdMindmapNode,
                KdMindmapLink,
                KdMindmapZoomDirective,
                KdMindmapDragDirective,
                KdMindmapZoomButton,
                KdGridster,
                KdGridsterToolbar,
                KdCharts,
                KdBarChart,
                KdLineChart,
                KdPieChart,
                KdMapChart,
                KdVisualization
            ]
        })
    ], KdComponentsModule);
    return KdComponentsModule;
}());
export { KdComponentsModule };
export { ɵ0 };
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoia2QtY29tcG9uZW50cy5tb2R1bGUuanMiLCJzb3VyY2VSb290Ijoibmc6Ly9vcGVuZW1pcy1zdHlsZWd1aWRlLWxpYi8iLCJzb3VyY2VzIjpbImtkLWNvbXBvbmVudHMva2QtY29tcG9uZW50cy5tb2R1bGUudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IjtBQUFBLE9BQU8sRUFBRSxRQUFRLEVBQTBDLE1BQU0sZUFBZSxDQUFDO0FBQ2pGLE9BQU8sRUFBRSxZQUFZLEVBQUUsTUFBTSxpQkFBaUIsQ0FBQztBQUMvQyxPQUFPLEVBQUUsV0FBVyxFQUFFLG1CQUFtQixFQUFFLE1BQU0sZ0JBQWdCLENBQUM7QUFFbEUsc0JBQXNCO0FBQ3RCLE9BQU8sRUFBRSxTQUFTLEVBQUUsTUFBTSw0QkFBNEIsQ0FBQztBQUN2RCxPQUFPLEVBQUUsYUFBYSxFQUFFLE1BQU0sa0JBQWtCLENBQUM7QUFDakQsT0FBTyxFQUFFLFlBQVksRUFBRSxNQUFNLGlCQUFpQixDQUFDO0FBQy9DLE9BQU8sRUFBRSxjQUFjLEVBQUUsV0FBVyxFQUFFLE1BQU0sa0JBQWtCLENBQUM7QUFDL0QsT0FBTyxFQUFFLGNBQWMsRUFBRSxNQUFNLG1CQUFtQixDQUFDO0FBQ25ELE9BQU8sRUFBRSxrQkFBa0IsRUFBRSxNQUFNLHNCQUFzQixDQUFDO0FBQzFELE9BQU8sRUFBRSxjQUFjLEVBQUUsTUFBTSxrQkFBa0IsQ0FBQztBQUNsRCxPQUFPLEVBQUUsVUFBVSxFQUFFLE1BQU0sY0FBYyxDQUFDO0FBQzFDLE9BQU8sRUFBRSxZQUFZLEVBQUUsTUFBTSxnQkFBZ0IsQ0FBQztBQUM5QyxPQUFPLEVBQUUsYUFBYSxFQUFFLE1BQU0saUJBQWlCLENBQUM7QUFDaEQsT0FBTyxFQUFFLFdBQVcsRUFBRSxNQUFNLGVBQWUsQ0FBQztBQUM1QyxPQUFPLEVBQUUsVUFBVSxFQUFFLE1BQU0sY0FBYyxDQUFDO0FBRTFDLE9BQU8sRUFBRSxZQUFZLEVBQUUsTUFBTSxhQUFhLENBQUM7QUFDM0MsT0FBTyxFQUFFLFlBQVksRUFBRSxNQUFNLGdCQUFnQixDQUFDO0FBQzlDLE9BQU8sRUFBRSxlQUFlLEVBQUUsTUFBTSxtQkFBbUIsQ0FBQztBQUlwRCwwQkFBMEI7QUFDMUIsZ0ZBQWdGO0FBRWhGLE9BQU8sRUFBRSxRQUFRLEVBQUUsTUFBTSwyQkFBMkIsQ0FBQztBQUNyRCxPQUFPLEVBQUUsVUFBVSxFQUFFLE1BQU0sRUFBRSxNQUFNLDZCQUE2QixDQUFDO0FBQ2pFLE9BQU8sRUFBRSxRQUFRLEVBQUUsTUFBTSwyQkFBMkIsQ0FBQztBQUNyRCxPQUFPLEVBQUUsVUFBVSxFQUFFLE1BQU0sNkJBQTZCLENBQUM7QUFDekQsT0FBTyxFQUFFLFlBQVksRUFBRSxNQUFNLCtCQUErQixDQUFDO0FBQzdELE9BQU8sRUFBRSxZQUFZLEVBQUUsU0FBUyxFQUFFLE1BQU0sK0JBQStCLENBQUM7QUFDeEUsT0FBTyxFQUFFLE9BQU8sRUFBRSxNQUFNLDBCQUEwQixDQUFDO0FBQ25ELE9BQU8sRUFBRSxnQkFBZ0IsRUFBRSxNQUFNLG9DQUFvQyxDQUFDO0FBQ3RFLE9BQU8sRUFBRSxXQUFXLEVBQUUsTUFBTSw2Q0FBNkMsQ0FBQztBQUMxRSxPQUFPLEVBQUUsTUFBTSxFQUFFLE1BQU0seUJBQXlCLENBQUM7QUFDakQsT0FBTyxFQUFFLE9BQU8sRUFBRSxXQUFXLEVBQUUsTUFBTSwwQkFBMEIsQ0FBQztBQUNoRSxPQUFPLEVBQUUsT0FBTyxFQUFFLE1BQU0sMEJBQTBCLENBQUM7QUFFbkQsT0FBTyxFQUFFLFdBQVcsRUFBRSxNQUFNLCtCQUErQixDQUFDO0FBQzVELE9BQU8sRUFBRSxNQUFNLEVBQUUsTUFBTSx5QkFBeUIsQ0FBQztBQUNqRCxPQUFPLEVBQUUsUUFBUSxFQUFFLGVBQWUsRUFBRSxNQUFNLDJCQUEyQixDQUFDO0FBQ3RFLE9BQU8sRUFDSCxPQUFPLEVBQ1AsYUFBYSxFQUNiLG9CQUFvQixFQUNwQixZQUFZLEVBQ1osWUFBWSxFQUNmLE1BQU0sMEJBQTBCLENBQUM7QUFDbEMsT0FBTyxFQUFFLFNBQVMsRUFBRSxrQkFBa0IsRUFBRSxNQUFNLDRCQUE0QixDQUFDO0FBQzNFLE9BQU8sRUFBRSxPQUFPLEVBQUUsTUFBTSxxQ0FBcUMsQ0FBQztBQUM5RCxPQUFPLEVBQUUsYUFBYSxFQUFFLE1BQU0saUNBQWlDLENBQUM7QUFDaEUsT0FBTyxFQUFFLGFBQWEsRUFBRSxNQUFNLGdDQUFnQyxDQUFDO0FBQy9ELE9BQU8sRUFBRSxPQUFPLEVBQUUsTUFBTSwwQkFBMEIsQ0FBQztBQUNuRCxPQUFPLEVBQUUsV0FBVyxFQUFFLE1BQU0sK0JBQStCLENBQUM7QUFDNUQsT0FBTyxFQUFFLGtCQUFrQixFQUFFLE1BQU0sc0NBQXNDLENBQUM7QUFFMUUsT0FBTyxFQUFFLGVBQWUsRUFBRSxNQUFNLG1DQUFtQyxDQUFDO0FBQ3BFLE9BQU8sRUFBRSxZQUFZLEVBQUUsTUFBTSwrQkFBK0IsQ0FBQztBQUM3RCxPQUFPLEVBQUUsWUFBWSxFQUFFLE1BQU0sK0JBQStCLENBQUM7QUFDN0QsT0FBTyxFQUFFLGNBQWMsRUFBRSxNQUFNLGlDQUFpQyxDQUFDO0FBQ2pFLE9BQU8sRUFBRSxnQkFBZ0IsRUFBRSxNQUFNLG1DQUFtQyxDQUFDO0FBQ3JFLE9BQU8sRUFBRSxXQUFXLEVBQUUsTUFBTSw4QkFBOEIsQ0FBQztBQUMzRCxPQUFPLEVBQUUsS0FBSyxFQUFFLE1BQU0sd0JBQXdCLENBQUM7QUFDL0MsT0FBTyxFQUFFLFFBQVEsRUFBRSxNQUFNLDJCQUEyQixDQUFDO0FBQ3JELE9BQU8sRUFBRSxRQUFRLEVBQUUsTUFBTSwyQkFBMkIsQ0FBQztBQUVyRCxPQUFPLEVBQUUsUUFBUSxFQUFFLE1BQU0sZ0NBQWdDLENBQUM7QUFFMUQsT0FBTyxFQUFFLE9BQU8sRUFBRSxlQUFlLEVBQUUsTUFBTSwwQkFBMEIsQ0FBQztBQUVwRSxPQUFPLEVBQUUsZUFBZSxFQUFFLG9CQUFvQixFQUFFLE1BQU0sbUNBQW1DLENBQUM7QUFDMUYsT0FBTyxFQUFFLFFBQVEsRUFBRSxNQUFNLDJCQUEyQixDQUFDO0FBQ3JELE9BQU8sRUFBRSxVQUFVLEVBQUUsTUFBTSw2QkFBNkIsQ0FBQztBQUN6RCxPQUFPLEVBQ0gsU0FBUyxFQUNULGFBQWEsRUFDYixhQUFhLEVBQ2Isc0JBQXNCLEVBQ3RCLHNCQUFzQixFQUN0QixtQkFBbUIsRUFDdEIsTUFBTSw0QkFBNEIsQ0FBQztBQUNwQyxPQUFPLEVBQUUsVUFBVSxFQUFFLGlCQUFpQixFQUFFLE1BQU0sNkJBQTZCLENBQUM7QUFDNUUsT0FBTyxFQUNILFFBQVEsRUFDUixVQUFVLEVBQ1YsV0FBVyxFQUNYLFVBQVUsRUFDVixVQUFVLEVBQ2IsTUFBTSwyQkFBMkIsQ0FBQztBQUNuQyxPQUFPLEVBQUUsZUFBZSxFQUFFLE1BQU0sa0NBQWtDLENBQUM7QUFDbkUsT0FBTyxFQUFFLGNBQWMsRUFBRSxNQUFNLHlDQUF5QyxDQUFDO1NBMkJqRCxjQUFjO0FBMkt0QztJQUFBO0lBT0EsQ0FBQztJQVBZLGtCQUFrQjtRQXBNOUIsUUFBUSxDQUFDO1lBQ04sT0FBTyxFQUFFO2dCQUNMLFlBQVk7Z0JBQ1osV0FBVztnQkFDWCxtQkFBbUI7Z0JBQ25CLFNBQVM7Z0JBQ1QsYUFBYTtnQkFDYixVQUFVO2dCQUNWLFlBQVk7Z0JBQ1osa0JBQWtCO2dCQUNsQixjQUFjO2dCQUNkLFVBQVU7Z0JBQ1YsWUFBWTtnQkFDWixhQUFhO2dCQUNiLFdBQVc7Z0JBQ1gsWUFBWTtnQkFDWixlQUFlO2dCQUNmLFlBQVksQ0FBQyxjQUFjLENBQUM7b0JBQ3hCLGFBQWE7b0JBQ2Isb0JBQW9CO29CQUNwQixZQUFZO29CQUNaLFlBQVk7aUJBQ2YsQ0FBQztnQkFDRixjQUFjLENBQUMsT0FBTyxDQUFDO29CQUNuQixPQUFPLEVBQUUsV0FBVztvQkFDcEIsVUFBVSxJQUFnQjtpQkFDM0IsQ0FBQztnQkFFSixjQUFjO2FBQ2pCO1lBQ0QsWUFBWSxFQUFFO2dCQUNWLFFBQVE7Z0JBQ1IsUUFBUTtnQkFDUixVQUFVO2dCQUNWLE1BQU07Z0JBQ04sWUFBWTtnQkFDWixVQUFVO2dCQUNWLFlBQVk7Z0JBQ1osU0FBUztnQkFDVCxPQUFPO2dCQUNQLGdCQUFnQjtnQkFDaEIsV0FBVztnQkFFWCxNQUFNO2dCQUVOLE9BQU87Z0JBQ1AsV0FBVztnQkFFWCxPQUFPO2dCQUVQLFdBQVc7Z0JBQ1gsTUFBTTtnQkFDTixRQUFRO2dCQUNSLGVBQWU7Z0JBQ2YsT0FBTztnQkFDUCxhQUFhO2dCQUNiLG9CQUFvQjtnQkFDcEIsWUFBWTtnQkFDWixZQUFZO2dCQUVaLFNBQVM7Z0JBQ1Qsa0JBQWtCO2dCQUVsQixPQUFPO2dCQUNQLFdBQVc7Z0JBQ1gsYUFBYTtnQkFDYixhQUFhO2dCQUNiLE9BQU87Z0JBQ1Asa0JBQWtCO2dCQUNsQixlQUFlO2dCQUNmLFlBQVk7Z0JBQ1osWUFBWTtnQkFDWixjQUFjO2dCQUNkLGdCQUFnQjtnQkFDaEIsV0FBVztnQkFDWCxLQUFLO2dCQUVMLFFBQVE7Z0JBQ1IsUUFBUTtnQkFFUixRQUFRO2dCQUVSLE9BQU87Z0JBQ1AsZUFBZTtnQkFFZixlQUFlO2dCQUNmLG9CQUFvQjtnQkFFcEIsUUFBUTtnQkFFUixVQUFVO2dCQUVWLFNBQVM7Z0JBQ1QsYUFBYTtnQkFDYixhQUFhO2dCQUNiLHNCQUFzQjtnQkFDdEIsc0JBQXNCO2dCQUN0QixtQkFBbUI7Z0JBRW5CLFVBQVU7Z0JBQ1YsaUJBQWlCO2dCQUVqQixRQUFRO2dCQUNSLFVBQVU7Z0JBQ1YsV0FBVztnQkFDWCxVQUFVO2dCQUNWLFVBQVU7Z0JBQ1YsZUFBZTthQUNsQjtZQUNELE9BQU8sRUFBRTtnQkFDTCxlQUFlO2dCQUNmLFVBQVU7Z0JBQ1YsWUFBWTtnQkFDWixXQUFXO2dCQUNYLG1CQUFtQjtnQkFFbkIsUUFBUTtnQkFDUixRQUFRO2dCQUNSLFVBQVU7Z0JBQ1YsTUFBTTtnQkFDTixZQUFZO2dCQUNaLFVBQVU7Z0JBQ1YsWUFBWTtnQkFDWixTQUFTO2dCQUNULE9BQU87Z0JBQ1AsZ0JBQWdCO2dCQUNoQixXQUFXO2dCQUVYLE1BQU07Z0JBRU4sT0FBTztnQkFDUCxXQUFXO2dCQUVYLE9BQU87Z0JBRVAsV0FBVztnQkFDWCxNQUFNO2dCQUNOLFFBQVE7Z0JBQ1IsZUFBZTtnQkFFZixPQUFPO2dCQUNQLGFBQWE7Z0JBQ2Isb0JBQW9CO2dCQUNwQixZQUFZO2dCQUNaLFlBQVk7Z0JBRVosU0FBUztnQkFDVCxrQkFBa0I7Z0JBQ2xCLE9BQU87Z0JBQ1AsV0FBVztnQkFDWCxhQUFhO2dCQUNiLGFBQWE7Z0JBQ2IsT0FBTztnQkFDUCxrQkFBa0I7Z0JBR2xCLGVBQWU7Z0JBQ2YsWUFBWTtnQkFDWixZQUFZO2dCQUNaLGNBQWM7Z0JBQ2QsZ0JBQWdCO2dCQUNoQixXQUFXO2dCQUNYLEtBQUs7Z0JBRUwsUUFBUTtnQkFDUixRQUFRO2dCQUVSLFFBQVE7Z0JBRVIsT0FBTztnQkFDUCxlQUFlO2dCQUVmLGVBQWU7Z0JBQ2Ysb0JBQW9CO2dCQUNwQixRQUFRO2dCQUVSLFVBQVU7Z0JBRVYsU0FBUztnQkFDVCxhQUFhO2dCQUNiLGFBQWE7Z0JBQ2Isc0JBQXNCO2dCQUN0QixzQkFBc0I7Z0JBQ3RCLG1CQUFtQjtnQkFFbkIsVUFBVTtnQkFDVixpQkFBaUI7Z0JBRWpCLFFBQVE7Z0JBQ1IsVUFBVTtnQkFDVixXQUFXO2dCQUNYLFVBQVU7Z0JBQ1YsVUFBVTtnQkFDVixlQUFlO2FBQ2xCO1NBQ0osQ0FBQztPQUNXLGtCQUFrQixDQU85QjtJQUFELHlCQUFDO0NBQUEsQUFQRCxJQU9DO1NBUFksa0JBQWtCIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgTmdNb2R1bGUsIE1vZHVsZVdpdGhQcm92aWRlcnMvKiwgVmFsdWVQcm92aWRlciovIH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XHJcbmltcG9ydCB7IENvbW1vbk1vZHVsZSB9IGZyb20gJ0Bhbmd1bGFyL2NvbW1vbic7XHJcbmltcG9ydCB7IEZvcm1zTW9kdWxlLCBSZWFjdGl2ZUZvcm1zTW9kdWxlIH0gZnJvbSAnQGFuZ3VsYXIvZm9ybXMnO1xyXG5cclxuLy8gdGhpcmQgcGFydHkgcGx1Z2luc1xyXG5pbXBvcnQgeyBOZ2JNb2R1bGUgfSBmcm9tICdAbmctYm9vdHN0cmFwL25nLWJvb3RzdHJhcCc7XHJcbmltcG9ydCB7IFRvYXN0ZXJNb2R1bGUgfSBmcm9tICdhbmd1bGFyMi10b2FzdGVyJztcclxuaW1wb3J0IHsgQWdHcmlkTW9kdWxlIH0gZnJvbSAnYWctZ3JpZC1hbmd1bGFyJztcclxuaW1wb3J0IHsgQ2FsZW5kYXJNb2R1bGUsIERhdGVBZGFwdGVyIH0gZnJvbSAnYW5ndWxhci1jYWxlbmRhcic7XHJcbmltcG9ydCB7IEdyaWRzdGVyTW9kdWxlIH0gZnJvbSAnYW5ndWxhci1ncmlkc3RlcjInO1xyXG5pbXBvcnQgeyBBdXRvQ29tcGxldGVNb2R1bGUgfSBmcm9tICdwcmltZW5nL2F1dG9jb21wbGV0ZSc7XHJcbmltcG9ydCB7IERyb3Bkb3duTW9kdWxlIH0gZnJvbSAncHJpbWVuZy9kcm9wZG93bic7XHJcbmltcG9ydCB7IE1lbnVNb2R1bGUgfSBmcm9tICdwcmltZW5nL21lbnUnO1xyXG5pbXBvcnQgeyBCdXR0b25Nb2R1bGUgfSBmcm9tICdwcmltZW5nL2J1dHRvbic7XHJcbmltcG9ydCB7IFRvb2x0aXBNb2R1bGUgfSBmcm9tICdwcmltZW5nL3Rvb2x0aXAnO1xyXG5pbXBvcnQgeyBDaGFydE1vZHVsZSB9IGZyb20gJ3ByaW1lbmcvY2hhcnQnO1xyXG5pbXBvcnQgeyBUcmVlTW9kdWxlIH0gZnJvbSAncHJpbWVuZy90cmVlJztcclxuaW1wb3J0IHsgVHJlZU5vZGUgfSBmcm9tICdwcmltZW5nL2FwaSc7XHJcbmltcG9ydCB7IFNoYXJlZE1vZHVsZSB9IGZyb20gJ3ByaW1lbmcvYXBpJztcclxuaW1wb3J0IHsgU2xpZGVyTW9kdWxlIH0gZnJvbSAncHJpbWVuZy9zbGlkZXInO1xyXG5pbXBvcnQgeyBQYWdpbmF0b3JNb2R1bGUgfSBmcm9tICdwcmltZW5nL3BhZ2luYXRvcic7XHJcblxyXG5cclxuXHJcbi8vIE9wZW5FTUlTIGNvbXBvbmVudCBsaXN0XHJcbi8vIGltcG9ydCB7IEtEX0NPTVBPTkVOVFNfUFZERVJTLCBnZXRQcm9kSW5mbyB9IGZyb20gJy4va2QtY29tcG9uZW50cy5wcm92aWRlcic7XHJcblxyXG5pbXBvcnQgeyBLZEhlYWRlciB9IGZyb20gJy4va2QtYW5ndWxhci1oZWFkZXIvaW5kZXgnO1xyXG5pbXBvcnQgeyBLZFNwbGl0dGVyLCBLZFBhbmUgfSBmcm9tICcuL2tkLWFuZ3VsYXItc3BsaXR0ZXIvaW5kZXgnO1xyXG5pbXBvcnQgeyBLZEZvb3RlciB9IGZyb20gJy4va2QtYW5ndWxhci1mb290ZXIvaW5kZXgnO1xyXG5pbXBvcnQgeyBLZExlZnRNZW51IH0gZnJvbSAnLi9rZC1hbmd1bGFyLWxlZnRtZW51L2luZGV4JztcclxuaW1wb3J0IHsgS2RCcmVhZGNydW1iIH0gZnJvbSAnLi9rZC1hbmd1bGFyLWJyZWFkY3J1bWIvaW5kZXgnO1xyXG5pbXBvcnQgeyBLZFBhZ2VoZWFkZXIsIEtkVG9vbGJhciB9IGZyb20gJy4va2QtYW5ndWxhci1wYWdlaGVhZGVyL2luZGV4JztcclxuaW1wb3J0IHsgS2RBbGVydCB9IGZyb20gJy4va2QtYW5ndWxhci1hbGVydC9pbmRleCc7XHJcbmltcG9ydCB7IEtkVGVtcGxhdGVMYXlvdXQgfSBmcm9tICcuL2tkLWFuZ3VsYXItdGVtcGxhdGUtbGF5b3V0L2luZGV4JztcclxuaW1wb3J0IHsgS2RDb2RlYmxvY2sgfSBmcm9tICcuL2tkLWFuZ3VsYXItY29kZWJsb2NrL2tkLWFuZ3VsYXItY29kZWJsb2NrJztcclxuaW1wb3J0IHsgS2RUYWJzIH0gZnJvbSAnLi9rZC1hbmd1bGFyLXRhYnMvaW5kZXgnO1xyXG5pbXBvcnQgeyBLZExvZ2luLCBLZExvZ2luRm9ybSB9IGZyb20gJy4va2QtYW5ndWxhci1sb2dpbi9pbmRleCc7XHJcbmltcG9ydCB7IEtkRXJyb3IgfSBmcm9tICcuL2tkLWFuZ3VsYXItZXJyb3IvaW5kZXgnO1xyXG5cclxuaW1wb3J0IHsgS2RBZHZGaWx0ZXIgfSBmcm9tICcuL2tkLWFuZ3VsYXItYWR2LWZpbHRlci9pbmRleCc7XHJcbmltcG9ydCB7IEtkVmlldyB9IGZyb20gJy4va2QtYW5ndWxhci12aWV3L2luZGV4JztcclxuaW1wb3J0IHsgS2RTbGlkZXIsIEtkU2xpZGVyQ29udGVudCB9IGZyb20gJy4va2QtYW5ndWxhci1zbGlkZXIvaW5kZXgnO1xyXG5pbXBvcnQge1xyXG4gICAgS2RUYWJsZSxcclxuICAgIEtkVGFibGVBY3Rpb24sXHJcbiAgICBLZFRhYmxlQ2hlY2tib3hSYWRpbyxcclxuICAgIEtkVGFibGVJbnB1dCxcclxuICAgIEtkVGFibGVJbWFnZVxyXG59IGZyb20gJy4va2QtYW5ndWxhci10YWJsZS9pbmRleCc7XHJcbmltcG9ydCB7IEtkVG9vbHRpcCwgS2RUb29sdGlwRGlyZWN0aXZlIH0gZnJvbSAnLi9rZC1hbmd1bGFyLXRvb2x0aXAvaW5kZXgnO1xyXG5pbXBvcnQgeyBLZElucHV0IH0gZnJvbSAnLi9rZC1hbmd1bGFyLWlucHV0L2tkLWFuZ3VsYXItaW5wdXQnO1xyXG5pbXBvcnQgeyBLZEJ1dHRvbkdyb3VwIH0gZnJvbSAnLi9rZC1hbmd1bGFyLWJ1dHRvbi1ncm91cC9pbmRleCc7XHJcbmltcG9ydCB7IEtkUGxhY2Vob2xkZXIgfSBmcm9tICcuL2tkLWFuZ3VsYXItcGxhY2Vob2xkZXIvaW5kZXgnO1xyXG5pbXBvcnQgeyBLZE1vZGFsIH0gZnJvbSAnLi9rZC1hbmd1bGFyLW1vZGFsL2luZGV4JztcclxuaW1wb3J0IHsgS2RUZXh0SW5wdXQgfSBmcm9tICcuL2tkLWFuZ3VsYXItdGV4dC1pbnB1dC9pbmRleCc7XHJcbmltcG9ydCB7IEtkTXVsdGlTZWxlY3RUYWJsZSB9IGZyb20gJy4va2QtYW5ndWxhci1tdWx0aXNlbGVjdC10YWJsZS9pbmRleCc7XHJcblxyXG5pbXBvcnQgeyBLZENoZWNrYm94UmFkaW8gfSBmcm9tICcuL2tkLWFuZ3VsYXItY2hlY2tib3gtcmFkaW8vaW5kZXgnO1xyXG5pbXBvcnQgeyBLZERhdGVwaWNrZXIgfSBmcm9tICcuL2tkLWFuZ3VsYXItZGF0ZXBpY2tlci9pbmRleCc7XHJcbmltcG9ydCB7IEtkVGltZXBpY2tlciB9IGZyb20gJy4va2QtYW5ndWxhci10aW1lcGlja2VyL2luZGV4JztcclxuaW1wb3J0IHsgS2RUcmVlRHJvcGRvd24gfSBmcm9tICcuL2tkLWFuZ3VsYXItdHJlZWRyb3Bkb3duL2luZGV4JztcclxuaW1wb3J0IHsgS2RQcm9ncmVzc2xvYWRlciB9IGZyb20gJy4va2QtYW5ndWxhci1wcm9ncmVzc2xvYWRlci9pbmRleCc7XHJcbmltcG9ydCB7IEtkRmlsZUlucHV0IH0gZnJvbSAnLi9rZC1hbmd1bGFyLWZpbGVpbnB1dC9pbmRleCc7XHJcbmltcG9ydCB7IEtkTWFwIH0gZnJvbSAnLi9rZC1hbmd1bGFyLW1hcC9pbmRleCc7XHJcbmltcG9ydCB7IEtkRmlsdGVyIH0gZnJvbSAnLi9rZC1hbmd1bGFyLWZpbHRlci9pbmRleCc7XHJcbmltcG9ydCB7IEtkU2VhcmNoIH0gZnJvbSAnLi9rZC1hbmd1bGFyLXNlYXJjaC9pbmRleCc7XHJcblxyXG5pbXBvcnQgeyBLZERlbGV0ZSB9IGZyb20gJy4va2QtYW5ndWxhci1kZWxldGUtY29tcC9pbmRleCc7XHJcblxyXG5pbXBvcnQgeyBLZEZvbnRzLCBGaWx0ZXJBcnJheVBpcGUgfSBmcm9tICcuL2tkLWFuZ3VsYXItZm9udHMvaW5kZXgnO1xyXG5cclxuaW1wb3J0IHsgS2RNaW5pRGFzaGJvYXJkLCBLZE1pbmlEYXNoYm9hcmRDaGFydCB9IGZyb20gJy4va2QtYW5ndWxhci1taW5pLWRhc2hib2FyZC9pbmRleCc7XHJcbmltcG9ydCB7IEtkV2l6YXJkIH0gZnJvbSAnLi9rZC1hbmd1bGFyLXdpemFyZC9pbmRleCc7XHJcbmltcG9ydCB7IEtkQ2FsZW5kYXIgfSBmcm9tICcuL2tkLWFuZ3VsYXItY2FsZW5kYXIvaW5kZXgnO1xyXG5pbXBvcnQge1xyXG4gICAgS2RNaW5kbWFwLFxyXG4gICAgS2RNaW5kbWFwTm9kZSxcclxuICAgIEtkTWluZG1hcExpbmssXHJcbiAgICBLZE1pbmRtYXBab29tRGlyZWN0aXZlLFxyXG4gICAgS2RNaW5kbWFwRHJhZ0RpcmVjdGl2ZSxcclxuICAgIEtkTWluZG1hcFpvb21CdXR0b25cclxufSBmcm9tICcuL2tkLWFuZ3VsYXItbWluZG1hcC9pbmRleCc7XHJcbmltcG9ydCB7IEtkR3JpZHN0ZXIsIEtkR3JpZHN0ZXJUb29sYmFyIH0gZnJvbSAnLi9rZC1hbmd1bGFyLWdyaWRzdGVyL2luZGV4JztcclxuaW1wb3J0IHtcclxuICAgIEtkQ2hhcnRzLFxyXG4gICAgS2RCYXJDaGFydCxcclxuICAgIEtkTGluZUNoYXJ0LFxyXG4gICAgS2RQaWVDaGFydCxcclxuICAgIEtkTWFwQ2hhcnRcclxufSBmcm9tICcuL2tkLWFuZ3VsYXItY2hhcnRzL2luZGV4JztcclxuaW1wb3J0IHsgS2RWaXN1YWxpemF0aW9uIH0gZnJvbSAnLi9rZC1hbmd1bGFyLXZpc3VhbGl6YXRpb24vaW5kZXgnO1xyXG5pbXBvcnQgeyBhZGFwdGVyRmFjdG9yeSB9IGZyb20gJ2FuZ3VsYXItY2FsZW5kYXIvZGF0ZS1hZGFwdGVycy9kYXRlLWZucyc7XHJcblxyXG5ATmdNb2R1bGUoe1xyXG4gICAgaW1wb3J0czogW1xyXG4gICAgICAgIENvbW1vbk1vZHVsZSxcclxuICAgICAgICBGb3Jtc01vZHVsZSxcclxuICAgICAgICBSZWFjdGl2ZUZvcm1zTW9kdWxlLFxyXG4gICAgICAgIE5nYk1vZHVsZSxcclxuICAgICAgICBUb2FzdGVyTW9kdWxlLFxyXG4gICAgICAgIFRyZWVNb2R1bGUsXHJcbiAgICAgICAgU2hhcmVkTW9kdWxlLFxyXG4gICAgICAgIEF1dG9Db21wbGV0ZU1vZHVsZSxcclxuICAgICAgICBEcm9wZG93bk1vZHVsZSxcclxuICAgICAgICBNZW51TW9kdWxlLFxyXG4gICAgICAgIEJ1dHRvbk1vZHVsZSxcclxuICAgICAgICBUb29sdGlwTW9kdWxlLFxyXG4gICAgICAgIENoYXJ0TW9kdWxlLFxyXG4gICAgICAgIFNsaWRlck1vZHVsZSxcclxuICAgICAgICBQYWdpbmF0b3JNb2R1bGUsIFxyXG4gICAgICAgIEFnR3JpZE1vZHVsZS53aXRoQ29tcG9uZW50cyhbXHJcbiAgICAgICAgICAgIEtkVGFibGVBY3Rpb24sXHJcbiAgICAgICAgICAgIEtkVGFibGVDaGVja2JveFJhZGlvLFxyXG4gICAgICAgICAgICBLZFRhYmxlSW5wdXQsXHJcbiAgICAgICAgICAgIEtkVGFibGVJbWFnZVxyXG4gICAgICAgIF0pLFxyXG4gICAgICAgIENhbGVuZGFyTW9kdWxlLmZvclJvb3Qoe1xyXG4gICAgICAgICAgICBwcm92aWRlOiBEYXRlQWRhcHRlcixcclxuICAgICAgICAgICAgdXNlRmFjdG9yeTogYWRhcHRlckZhY3RvcnlcclxuICAgICAgICAgIH0pLFxyXG5cclxuICAgICAgICBHcmlkc3Rlck1vZHVsZVxyXG4gICAgXSxcclxuICAgIGRlY2xhcmF0aW9uczogW1xyXG4gICAgICAgIEtkSGVhZGVyLFxyXG4gICAgICAgIEtkRm9vdGVyLFxyXG4gICAgICAgIEtkU3BsaXR0ZXIsXHJcbiAgICAgICAgS2RQYW5lLFxyXG4gICAgICAgIEtkQnJlYWRjcnVtYixcclxuICAgICAgICBLZExlZnRNZW51LFxyXG4gICAgICAgIEtkUGFnZWhlYWRlcixcclxuICAgICAgICBLZFRvb2xiYXIsXHJcbiAgICAgICAgS2RBbGVydCxcclxuICAgICAgICBLZFRlbXBsYXRlTGF5b3V0LFxyXG4gICAgICAgIEtkQ29kZWJsb2NrLFxyXG5cclxuICAgICAgICBLZFRhYnMsXHJcblxyXG4gICAgICAgIEtkTG9naW4sXHJcbiAgICAgICAgS2RMb2dpbkZvcm0sXHJcblxyXG4gICAgICAgIEtkRXJyb3IsXHJcblxyXG4gICAgICAgIEtkQWR2RmlsdGVyLFxyXG4gICAgICAgIEtkVmlldyxcclxuICAgICAgICBLZFNsaWRlcixcclxuICAgICAgICBLZFNsaWRlckNvbnRlbnQsXHJcbiAgICAgICAgS2RUYWJsZSxcclxuICAgICAgICBLZFRhYmxlQWN0aW9uLFxyXG4gICAgICAgIEtkVGFibGVDaGVja2JveFJhZGlvLFxyXG4gICAgICAgIEtkVGFibGVJbWFnZSxcclxuICAgICAgICBLZFRhYmxlSW5wdXQsXHJcblxyXG4gICAgICAgIEtkVG9vbHRpcCxcclxuICAgICAgICBLZFRvb2x0aXBEaXJlY3RpdmUsXHJcblxyXG4gICAgICAgIEtkSW5wdXQsXHJcbiAgICAgICAgS2RUZXh0SW5wdXQsXHJcbiAgICAgICAgS2RCdXR0b25Hcm91cCxcclxuICAgICAgICBLZFBsYWNlaG9sZGVyLFxyXG4gICAgICAgIEtkTW9kYWwsXHJcbiAgICAgICAgS2RNdWx0aVNlbGVjdFRhYmxlLFxyXG4gICAgICAgIEtkQ2hlY2tib3hSYWRpbyxcclxuICAgICAgICBLZERhdGVwaWNrZXIsXHJcbiAgICAgICAgS2RUaW1lcGlja2VyLFxyXG4gICAgICAgIEtkVHJlZURyb3Bkb3duLFxyXG4gICAgICAgIEtkUHJvZ3Jlc3Nsb2FkZXIsXHJcbiAgICAgICAgS2RGaWxlSW5wdXQsXHJcbiAgICAgICAgS2RNYXAsXHJcblxyXG4gICAgICAgIEtkRmlsdGVyLFxyXG4gICAgICAgIEtkU2VhcmNoLFxyXG5cclxuICAgICAgICBLZERlbGV0ZSxcclxuXHJcbiAgICAgICAgS2RGb250cyxcclxuICAgICAgICBGaWx0ZXJBcnJheVBpcGUsXHJcblxyXG4gICAgICAgIEtkTWluaURhc2hib2FyZCxcclxuICAgICAgICBLZE1pbmlEYXNoYm9hcmRDaGFydCxcclxuXHJcbiAgICAgICAgS2RXaXphcmQsXHJcblxyXG4gICAgICAgIEtkQ2FsZW5kYXIsXHJcblxyXG4gICAgICAgIEtkTWluZG1hcCxcclxuICAgICAgICBLZE1pbmRtYXBOb2RlLFxyXG4gICAgICAgIEtkTWluZG1hcExpbmssXHJcbiAgICAgICAgS2RNaW5kbWFwWm9vbURpcmVjdGl2ZSxcclxuICAgICAgICBLZE1pbmRtYXBEcmFnRGlyZWN0aXZlLFxyXG4gICAgICAgIEtkTWluZG1hcFpvb21CdXR0b24sXHJcblxyXG4gICAgICAgIEtkR3JpZHN0ZXIsXHJcbiAgICAgICAgS2RHcmlkc3RlclRvb2xiYXIsXHJcblxyXG4gICAgICAgIEtkQ2hhcnRzLFxyXG4gICAgICAgIEtkQmFyQ2hhcnQsXHJcbiAgICAgICAgS2RMaW5lQ2hhcnQsXHJcbiAgICAgICAgS2RQaWVDaGFydCxcclxuICAgICAgICBLZE1hcENoYXJ0LFxyXG4gICAgICAgIEtkVmlzdWFsaXphdGlvbixcclxuICAgIF0sXHJcbiAgICBleHBvcnRzOiBbXHJcbiAgICAgICAgUGFnaW5hdG9yTW9kdWxlLFxyXG4gICAgICAgIE1lbnVNb2R1bGUsXHJcbiAgICAgICAgQ29tbW9uTW9kdWxlLFxyXG4gICAgICAgIEZvcm1zTW9kdWxlLFxyXG4gICAgICAgIFJlYWN0aXZlRm9ybXNNb2R1bGUsXHJcblxyXG4gICAgICAgIEtkSGVhZGVyLFxyXG4gICAgICAgIEtkRm9vdGVyLFxyXG4gICAgICAgIEtkU3BsaXR0ZXIsXHJcbiAgICAgICAgS2RQYW5lLFxyXG4gICAgICAgIEtkQnJlYWRjcnVtYixcclxuICAgICAgICBLZExlZnRNZW51LFxyXG4gICAgICAgIEtkUGFnZWhlYWRlcixcclxuICAgICAgICBLZFRvb2xiYXIsXHJcbiAgICAgICAgS2RBbGVydCxcclxuICAgICAgICBLZFRlbXBsYXRlTGF5b3V0LFxyXG4gICAgICAgIEtkQ29kZWJsb2NrLFxyXG4gICAgICAgICAgICAgICAgXHJcbiAgICAgICAgS2RUYWJzLFxyXG4gICAgICAgIFxyXG4gICAgICAgIEtkTG9naW4sXHJcbiAgICAgICAgS2RMb2dpbkZvcm0sXHJcblxyXG4gICAgICAgIEtkRXJyb3IsXHJcblxyXG4gICAgICAgIEtkQWR2RmlsdGVyLFxyXG4gICAgICAgIEtkVmlldyxcclxuICAgICAgICBLZFNsaWRlcixcclxuICAgICAgICBLZFNsaWRlckNvbnRlbnQsXHJcblxyXG4gICAgICAgIEtkVGFibGUsXHJcbiAgICAgICAgS2RUYWJsZUFjdGlvbixcclxuICAgICAgICBLZFRhYmxlQ2hlY2tib3hSYWRpbyxcclxuICAgICAgICBLZFRhYmxlSW5wdXQsXHJcbiAgICAgICAgS2RUYWJsZUltYWdlLFxyXG5cclxuICAgICAgICBLZFRvb2x0aXAsXHJcbiAgICAgICAgS2RUb29sdGlwRGlyZWN0aXZlLFxyXG4gICAgICAgIEtkSW5wdXQsXHJcbiAgICAgICAgS2RUZXh0SW5wdXQsXHJcbiAgICAgICAgS2RCdXR0b25Hcm91cCxcclxuICAgICAgICBLZFBsYWNlaG9sZGVyLFxyXG4gICAgICAgIEtkTW9kYWwsXHJcbiAgICAgICAgS2RNdWx0aVNlbGVjdFRhYmxlLFxyXG5cclxuXHJcbiAgICAgICAgS2RDaGVja2JveFJhZGlvLFxyXG4gICAgICAgIEtkRGF0ZXBpY2tlcixcclxuICAgICAgICBLZFRpbWVwaWNrZXIsXHJcbiAgICAgICAgS2RUcmVlRHJvcGRvd24sXHJcbiAgICAgICAgS2RQcm9ncmVzc2xvYWRlcixcclxuICAgICAgICBLZEZpbGVJbnB1dCxcclxuICAgICAgICBLZE1hcCxcclxuXHJcbiAgICAgICAgS2RGaWx0ZXIsXHJcbiAgICAgICAgS2RTZWFyY2gsXHJcblxyXG4gICAgICAgIEtkRGVsZXRlLFxyXG4gICAgICAgIFxyXG4gICAgICAgIEtkRm9udHMsXHJcbiAgICAgICAgRmlsdGVyQXJyYXlQaXBlLFxyXG5cclxuICAgICAgICBLZE1pbmlEYXNoYm9hcmQsXHJcbiAgICAgICAgS2RNaW5pRGFzaGJvYXJkQ2hhcnQsXHJcbiAgICAgICAgS2RXaXphcmQsXHJcblxyXG4gICAgICAgIEtkQ2FsZW5kYXIsXHJcblxyXG4gICAgICAgIEtkTWluZG1hcCxcclxuICAgICAgICBLZE1pbmRtYXBOb2RlLFxyXG4gICAgICAgIEtkTWluZG1hcExpbmssXHJcbiAgICAgICAgS2RNaW5kbWFwWm9vbURpcmVjdGl2ZSxcclxuICAgICAgICBLZE1pbmRtYXBEcmFnRGlyZWN0aXZlLFxyXG4gICAgICAgIEtkTWluZG1hcFpvb21CdXR0b24sXHJcblxyXG4gICAgICAgIEtkR3JpZHN0ZXIsXHJcbiAgICAgICAgS2RHcmlkc3RlclRvb2xiYXIsXHJcblxyXG4gICAgICAgIEtkQ2hhcnRzLFxyXG4gICAgICAgIEtkQmFyQ2hhcnQsXHJcbiAgICAgICAgS2RMaW5lQ2hhcnQsXHJcbiAgICAgICAgS2RQaWVDaGFydCxcclxuICAgICAgICBLZE1hcENoYXJ0LFxyXG4gICAgICAgIEtkVmlzdWFsaXphdGlvblxyXG4gICAgXVxyXG59KVxyXG5leHBvcnQgY2xhc3MgS2RDb21wb25lbnRzTW9kdWxlIHtcclxuICAgIC8vIHN0YXRpYyBmb3JSb290KCk6IE1vZHVsZVdpdGhQcm92aWRlcnMge1xyXG4gICAgLy8gICAgIHJldHVybiB7XHJcbiAgICAvLyAgICAgICAgIG5nTW9kdWxlOiBLZENvbXBvbmVudHNNb2R1bGUsXHJcbiAgICAvLyAgICAgICAgIHByb3ZpZGVyczogS0RfQ09NUE9ORU5UU19QVkRFUlNcclxuICAgIC8vICAgICB9O1xyXG4gICAgLy8gfVxyXG59XHJcbiJdfQ==