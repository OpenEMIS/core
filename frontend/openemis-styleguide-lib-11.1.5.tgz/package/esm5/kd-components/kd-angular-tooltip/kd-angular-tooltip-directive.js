import { __decorate, __extends, __metadata } from "tslib";
import { Directive, ElementRef, OnInit, OnDestroy, Input, Renderer2, NgZone, } from '@angular/core';
import { KdDomElemSvc } from '../kd-common/index';
import { DomHandler } from 'primeng/dom';
import { Tooltip } from 'primeng/tooltip';
import { KdSplitterEvent } from '../kd-angular-splitter/index';
var KdTooltipDirective = /** @class */ (function (_super) {
    __extends(KdTooltipDirective, _super);
    // constructor is fully new
    function KdTooltipDirective(_el, _zone, _domHandler, _renderer, _kdDomSvc, _kdSplitterEvent) {
        var _this = 
        // super(_el, _domHandler, _zone);
        _super.call(this, _el, _zone) || this;
        _this._el = _el;
        _this._domHandler = _domHandler;
        _this._renderer = _renderer;
        _this._isOutOfBounds = false;
        _this._deactivateHostListener = false;
        _this._offset = { x: 0, y: 0 };
        _this._defaultOffset = 10;
        _this._isMobile = _kdDomSvc.isMobileDevice();
        _this._dragMenuSub = _kdSplitterEvent.onDrag().subscribe(function () {
            _super.prototype.hide.call(_this);
        });
        _this._toggleMenuSub = _kdSplitterEvent.onToggleMenu().subscribe(function () {
            _super.prototype.hide.call(_this);
        });
        return _this;
    }
    KdTooltipDirective.prototype.ngOnInit = function () {
        this._initApi();
    };
    KdTooltipDirective.prototype.onMouseEnter = function (e) {
        // added extra condition !this._isMobile to if statement
        if (!this._isMobile && !this._deactivateHostListener) {
            if (this.hideTimeout) {
                clearTimeout(this.hideTimeout);
                this.remove();
            }
            _super.prototype.activate.call(this);
        }
    };
    KdTooltipDirective.prototype.onMouseLeave = function (e) {
        // added extra condition !this._isMobile to if statement
        if (!this._isMobile && !this._deactivateHostListener) {
            _super.prototype.deactivate.call(this);
        }
    };
    KdTooltipDirective.prototype.onClick = function (e) {
        if (!this._deactivateHostListener) {
            // when mobile device, click will activate the tooltip. when web, click will deactivate the tooltip
            if (!this._isMobile) {
                _super.prototype.deactivate.call(this);
            }
            else {
                if (this.hideTimeout) {
                    clearTimeout(this.hideTimeout);
                    this.remove();
                }
                _super.prototype.activate.call(this);
            }
        }
    };
    Object.defineProperty(KdTooltipDirective.prototype, "text", {
        // changed Input param to 'kd-tooltip-dir' (old input was: pTooltip)
        set: function (text) {
            this._text = text;
            if (this.active) {
                if (this._text) {
                    if (this.container && this.container.offsetParent) {
                        _super.prototype.updateText.call(this);
                    }
                    else {
                        this.show();
                    }
                }
                else {
                    _super.prototype.hide.call(this);
                }
            }
        },
        enumerable: true,
        configurable: true
    });
    KdTooltipDirective.prototype.show = function () {
        if (!this._text || this.disabled) {
            return;
        }
        _super.prototype.create.call(this);
        this.align();
        DomHandler.fadeIn(this.container, 250);
        if (this.tooltipZIndex === 'auto') {
            this.container.style.zIndex = ++DomHandler.zindex;
        }
        else {
            this.container.style.zIndex = this.tooltipZIndex;
        }
        if (!this._deactivateHostListener) {
            _super.prototype.bindDocumentResizeListener.call(this);
            // added 1 line. _bindDocumentTouchStartListener()
            if (this._isMobile)
                this._bindDocumentTouchStartListener();
        }
    };
    KdTooltipDirective.prototype.align = function () {
        var position = this.tooltipPosition;
        this._widthOutsideViewport = null;
        switch (position) {
            case 'top':
                this.alignTop();
                // added 1 line. _widthOutsideViewport
                // this._isOutofBounds is used instead of super.OutofBounds
                if (this._isOutOfBounds) {
                    this.alignTopRight();
                    if (this._isOutOfBounds) {
                        this.alignTopLeft();
                        if (this._isOutOfBounds) {
                            this._widthOutsideViewport = this._calculateWidthOut();
                            this.alignBottom(this._widthOutsideViewport);
                        }
                    }
                }
                break;
            case 'top-right':
                this.alignTopRight();
                // added 1 line. _widthOutsideViewport
                if (this._isOutOfBounds) {
                    this.alignTop();
                    if (this._isOutOfBounds) {
                        this.alignTopLeft();
                        if (this._isOutOfBounds) {
                            this._widthOutsideViewport = this._calculateWidthOut();
                            this.alignBottom(this._widthOutsideViewport);
                        }
                    }
                }
                break;
            case 'top-left':
                this.alignTopLeft();
                // added 1 line. _widthOutsideViewport
                if (this._isOutOfBounds) {
                    this.alignTop();
                    if (this._isOutOfBounds) {
                        this.alignTopRight();
                        if (this._isOutOfBounds) {
                            this._widthOutsideViewport = this._calculateWidthOut();
                            this.alignBottom(this._widthOutsideViewport);
                        }
                    }
                }
                break;
            case 'bottom':
                this.alignBottom();
                // added 1 line. _widthOutsideViewport
                if (this._isOutOfBounds) {
                    this.alignBottomRight();
                    if (this._isOutOfBounds) {
                        this.alignBottomLeft();
                        if (this._isOutOfBounds) {
                            // added 1 line. edited alignTop with param
                            this._widthOutsideViewport = this._calculateWidthOut();
                            this.alignTop(this._widthOutsideViewport);
                        }
                    }
                }
                break;
            case 'bottom-right':
                this.alignBottomRight();
                // added 1 line. _widthOutsideViewport
                if (this._isOutOfBounds) {
                    this.alignBottom();
                    if (this._isOutOfBounds) {
                        this.alignBottomLeft();
                        if (this._isOutOfBounds) {
                            // added 1 line. edited alignTop with param
                            this._widthOutsideViewport = this._calculateWidthOut();
                            this.alignTop(this._widthOutsideViewport);
                        }
                    }
                }
                break;
            case 'bottom-left':
                this.alignBottomLeft();
                // added 1 line. _widthOutsideViewport
                if (this._isOutOfBounds) {
                    this.alignBottom();
                    if (this._isOutOfBounds) {
                        this.alignBottomRight();
                        if (this._isOutOfBounds) {
                            // added 1 line. edited alignTop with param
                            this._widthOutsideViewport = this._calculateWidthOut();
                            this.alignTop(this._widthOutsideViewport);
                        }
                    }
                }
                break;
            case 'left':
                this.alignLeft();
                if (this._isOutOfBounds) {
                    this.alignRight();
                    if (this._isOutOfBounds) {
                        this.alignTop();
                        if (this._isOutOfBounds) {
                            // added 1 line. edited alignBottom with param
                            this._widthOutsideViewport = this._calculateWidthOut();
                            this.alignBottom(this._calculateWidthOut());
                        }
                    }
                }
                break;
            case 'right':
                this.alignRight();
                if (this._isOutOfBounds) {
                    this.alignLeft();
                    if (this._isOutOfBounds) {
                        this.alignTop();
                        if (this._isOutOfBounds) {
                            // added 1 line. edited alignBottom with param
                            this.alignBottom(this._calculateWidthOut());
                        }
                    }
                }
                break;
        }
    };
    KdTooltipDirective.prototype.alignRight = function () {
        // added 1 line. edited preAlign with param
        this.preAlign('right');
        var hostOffset = _super.prototype.getHostOffset.call(this);
        var width = DomHandler.getOuterWidth(this.container);
        var height = DomHandler.getOuterHeight(this.container);
        var left = hostOffset.left + DomHandler.getOuterWidth(this._el.nativeElement) + this._offset.x;
        var top = hostOffset.top + (DomHandler.getOuterHeight(this._el.nativeElement) - DomHandler.getOuterHeight(this.container)) / 2 - 1 + this._offset.y;
        this._isOutOfBounds = this._checkOutOfBounds(left, top, width, height);
        this.container.style.left = left + 'px';
        this.container.style.top = top + 'px';
    };
    KdTooltipDirective.prototype.alignLeft = function () {
        // added 1 line. edited preAlign with param
        this.preAlign('left');
        var hostOffset = _super.prototype.getHostOffset.call(this);
        var width = DomHandler.getOuterWidth(this.container);
        var height = DomHandler.getOuterHeight(this.container);
        var left = hostOffset.left - DomHandler.getOuterWidth(this.container) + this._offset.x;
        var top = hostOffset.top + (DomHandler.getOuterHeight(this._el.nativeElement) - DomHandler.getOuterHeight(this.container)) / 2 + this._offset.y;
        this._isOutOfBounds = this._checkOutOfBounds(left, top, width, height);
        this.container.style.left = left + 'px';
        this.container.style.top = top + 'px';
    };
    KdTooltipDirective.prototype.alignTop = function (widthOut) {
        // added 2 line. edited preAlign with param and widthOut
        this.preAlign('top');
        if (widthOut !== 0 && typeof widthOut !== 'undefined') {
            this.container.style.maxWidth = (DomHandler.getOuterWidth(this.container) - widthOut * 2).toString() + 'px';
        }
        var hostOffset = _super.prototype.getHostOffset.call(this);
        var width = DomHandler.getOuterWidth(this.container);
        var height = DomHandler.getOuterHeight(this.container);
        var left = hostOffset.left + (DomHandler.getOuterWidth(this._el.nativeElement) - DomHandler.getOuterWidth(this.container)) / 2 + this._offset.x;
        var top = hostOffset.top - DomHandler.getOuterHeight(this.container) + this._offset.y;
        this._isOutOfBounds = this._checkOutOfBounds(left, top, width, height);
        this.container.style.left = left + 'px';
        this.container.style.top = top + 'px';
    };
    // new direction
    KdTooltipDirective.prototype.alignTopRight = function (widthOut) {
        this.preAlign('top ui-tooltip-top-right');
        if (widthOut !== 0 && typeof widthOut !== 'undefined')
            this.container.style.maxWidth = (DomHandler.getOuterWidth(this.container) - widthOut * 2).toString() + 'px';
        var hostOffset = _super.prototype.getHostOffset.call(this);
        var width = DomHandler.getOuterWidth(this.container);
        var height = DomHandler.getOuterHeight(this.container);
        var left = hostOffset.left + DomHandler.getOuterWidth(this._el.nativeElement) / 2 - this._defaultOffset + this._offset.x;
        var top = hostOffset.top - DomHandler.getOuterHeight(this.container) + this._offset.y;
        this._isOutOfBounds = this._checkOutOfBounds(left, top, width, height);
        this.container.style.left = left + 'px';
        this.container.style.top = top + 'px';
    };
    // new direction
    KdTooltipDirective.prototype.alignTopLeft = function (widthOut) {
        this.preAlign('top ui-tooltip-top-left');
        if (widthOut !== 0 && typeof widthOut !== 'undefined')
            this.container.style.maxWidth = (DomHandler.getOuterWidth(this.container) - widthOut * 2).toString() + 'px';
        var hostOffset = _super.prototype.getHostOffset.call(this);
        var width = DomHandler.getOuterWidth(this.container);
        var height = DomHandler.getOuterHeight(this.container);
        var left = hostOffset.left + DomHandler.getOuterWidth(this._el.nativeElement) / 2 - DomHandler.getOuterWidth(this.container) + this._defaultOffset + this._offset.x;
        var top = hostOffset.top - DomHandler.getOuterHeight(this.container) + this._offset.y;
        this._isOutOfBounds = this._checkOutOfBounds(left, top, width, height);
        this.container.style.left = left + 'px';
        this.container.style.top = top + 'px';
    };
    KdTooltipDirective.prototype.alignBottom = function (widthOut) {
        // added 2 line. edited preAlign with param and widthOut
        this.preAlign('bottom');
        if (widthOut !== 0 && typeof widthOut !== 'undefined')
            this.container.style.maxWidth = (DomHandler.getOuterWidth(this.container) - widthOut * 2).toString() + 'px';
        var hostOffset = _super.prototype.getHostOffset.call(this);
        var width = DomHandler.getOuterWidth(this.container);
        var height = DomHandler.getOuterHeight(this.container);
        var left = hostOffset.left + (DomHandler.getOuterWidth(this._el.nativeElement) - DomHandler.getOuterWidth(this.container)) / 2 + this._offset.x;
        var top = hostOffset.top + DomHandler.getOuterHeight(this._el.nativeElement) + this._offset.y;
        this._isOutOfBounds = this._checkOutOfBounds(left, top, width, height);
        this.container.style.left = left + 'px';
        this.container.style.top = top + 'px';
    };
    // new direction
    KdTooltipDirective.prototype.alignBottomRight = function (widthOut) {
        this.preAlign('bottom ui-tooltip-bottom-right');
        if (widthOut !== 0 && typeof widthOut !== 'undefined')
            this.container.style.maxWidth = (DomHandler.getOuterWidth(this.container) - widthOut * 2).toString() + 'px';
        var hostOffset = _super.prototype.getHostOffset.call(this);
        var width = DomHandler.getOuterWidth(this.container);
        var height = DomHandler.getOuterHeight(this.container);
        var left = hostOffset.left + DomHandler.getOuterWidth(this._el.nativeElement) / 2 - this._defaultOffset + this._offset.x;
        var top = hostOffset.top + DomHandler.getOuterHeight(this._el.nativeElement) + this._offset.y;
        this._isOutOfBounds = this._checkOutOfBounds(left, top, width, height);
        this.container.style.left = left + 'px';
        this.container.style.top = top + 'px';
    };
    // new direction
    KdTooltipDirective.prototype.alignBottomLeft = function (widthOut) {
        this.preAlign('bottom ui-tooltip-bottom-left');
        if (widthOut !== 0 && typeof widthOut !== 'undefined')
            this.container.style.maxWidth = (DomHandler.getOuterWidth(this.container) - widthOut * 2).toString() + 'px';
        var hostOffset = _super.prototype.getHostOffset.call(this);
        var width = DomHandler.getOuterWidth(this.container);
        var height = DomHandler.getOuterHeight(this.container);
        var left = hostOffset.left + DomHandler.getOuterWidth(this._el.nativeElement) / 2 - DomHandler.getOuterWidth(this.container) + this._defaultOffset + this._offset.x;
        var top = hostOffset.top + DomHandler.getOuterHeight(this._el.nativeElement) + this._offset.y;
        this._isOutOfBounds = this._checkOutOfBounds(left, top, width, height);
        this.container.style.left = left + 'px';
        this.container.style.top = top + 'px';
    };
    KdTooltipDirective.prototype.preAlign = function (_position) {
        this.container.style.left = -999 + 'px';
        this.container.style.top = -999 + 'px';
        // added 2 line. defaultClassName and container.className
        var defaultClassName = 'ui-tooltip ui-widget ui-tooltip-' + _position;
        this.container.className = this.tooltipStyleClass ? defaultClassName + ' ' + this.tooltipStyleClass : defaultClassName;
    };
    // temp fix: checking out of bounds should happen before wordwrap changes the size on tooltip
    KdTooltipDirective.prototype._checkOutOfBounds = function (_left, _top, _width, _height) {
        var viewport = DomHandler.getViewport();
        return (_left + _width > viewport.width) || (_left < 0) || (_top < 0) || (_top + _height > viewport.height);
    };
    KdTooltipDirective.prototype.remove = function () {
        if (!this._deactivateHostListener) {
            // added one line, _unbindDocumentTouchStartListner()
            if (this._isMobile)
                this._unbindDocumentTouchStartListner();
        }
        if (this.container && this.container.parentElement) {
            if (this.appendTo === 'body') {
                document.body.removeChild(this.container);
            }
            else if (this.appendTo === 'target') {
                this._el.nativeElement.removeChild(this.container);
            }
            else {
                DomHandler.removeChild(this.container, this.appendTo);
            }
        }
        this.container = null;
    };
    /********New Functions***********/
    KdTooltipDirective.prototype._initApi = function () {
        var _this = this;
        if (typeof this.api !== 'undefined') {
            this.api.showTooltip = function () { return _super.prototype.activate.call(_this); };
            this.api.hideTooltip = function () { return _super.prototype.deactivate.call(_this); };
            this.api.deactivateHostListener = function () { _this._deactivateHostListener = true; };
            this.api.activateHostListener = function () { _this._deactivateHostListener = false; };
            this.api.align = function () {
                if (!_this.container)
                    return;
                _this.align();
            };
            this.api.setOffset = function (_offset) { _this._offset = _offset; };
        }
    };
    KdTooltipDirective.prototype._calculateWidthOut = function () {
        var offset = this.container.getBoundingClientRect();
        var targetLeft = offset.left;
        var width = DomHandler.getOuterWidth(this.container);
        var viewport = DomHandler.getViewport();
        if (targetLeft + width - viewport.width > 0)
            return targetLeft + width - viewport.width;
        if (targetLeft < 0)
            return targetLeft * -1;
        return 0;
    };
    KdTooltipDirective.prototype._bindDocumentTouchStartListener = function () {
        var _this = this;
        this._documentTouchStartListener = this._renderer.listen('document', 'touchstart', function (event) {
            _super.prototype.hide.call(_this);
        });
    };
    KdTooltipDirective.prototype._unbindDocumentTouchStartListner = function () {
        if (this._documentTouchStartListener) {
            this._documentTouchStartListener();
            this._documentTouchStartListener = null;
        }
    };
    KdTooltipDirective.prototype.ngOnDestroy = function () {
        // super.unbindEvents();
        this.remove();
        // added 2 line. unsubscription
        this._dragMenuSub.unsubscribe();
        this._toggleMenuSub.unsubscribe();
    };
    KdTooltipDirective.ctorParameters = function () { return [
        { type: ElementRef },
        { type: NgZone },
        { type: DomHandler },
        { type: Renderer2 },
        { type: KdDomElemSvc },
        { type: KdSplitterEvent }
    ]; };
    __decorate([
        Input(),
        __metadata("design:type", Object)
    ], KdTooltipDirective.prototype, "api", void 0);
    __decorate([
        Input('kd-tooltip-dir'),
        __metadata("design:type", String),
        __metadata("design:paramtypes", [String])
    ], KdTooltipDirective.prototype, "text", null);
    KdTooltipDirective = __decorate([
        Directive({
            selector: '[kd-tooltip-dir]',
            providers: [DomHandler, KdDomElemSvc, KdSplitterEvent],
        }),
        __metadata("design:paramtypes", [ElementRef,
            NgZone,
            DomHandler,
            Renderer2,
            KdDomElemSvc,
            KdSplitterEvent])
    ], KdTooltipDirective);
    return KdTooltipDirective;
}(Tooltip));
export { KdTooltipDirective };
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoia2QtYW5ndWxhci10b29sdGlwLWRpcmVjdGl2ZS5qcyIsInNvdXJjZVJvb3QiOiJuZzovL29wZW5lbWlzLXN0eWxlZ3VpZGUtbGliLyIsInNvdXJjZXMiOlsia2QtY29tcG9uZW50cy9rZC1hbmd1bGFyLXRvb2x0aXAva2QtYW5ndWxhci10b29sdGlwLWRpcmVjdGl2ZS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiO0FBQUEsT0FBTyxFQUNILFNBQVMsRUFDVCxVQUFVLEVBQ1YsTUFBTSxFQUNOLFNBQVMsRUFDVCxLQUFLLEVBQ0wsU0FBUyxFQUNULE1BQU0sR0FDVCxNQUFNLGVBQWUsQ0FBQztBQUN2QixPQUFPLEVBQUUsWUFBWSxFQUFFLE1BQU0sb0JBQW9CLENBQUM7QUFDbEQsT0FBTyxFQUFDLFVBQVUsRUFBQyxNQUFNLGFBQWEsQ0FBQztBQUN2QyxPQUFPLEVBQUUsT0FBTyxFQUFFLE1BQU0saUJBQWlCLENBQUM7QUFDMUMsT0FBTyxFQUFFLGVBQWUsRUFBRSxNQUFNLDhCQUE4QixDQUFDO0FBZ0IvRDtJQUF3QyxzQ0FBTztJQWUzQywyQkFBMkI7SUFDM0IsNEJBQ1ksR0FBZSxFQUN2QixLQUFhLEVBQ0wsV0FBdUIsRUFDdkIsU0FBb0IsRUFDNUIsU0FBdUIsRUFDdkIsZ0JBQWlDO1FBTnJDO1FBUUksa0NBQWtDO1FBQ2xDLGtCQUFNLEdBQUcsRUFBRSxLQUFLLENBQUMsU0FTcEI7UUFqQlcsU0FBRyxHQUFILEdBQUcsQ0FBWTtRQUVmLGlCQUFXLEdBQVgsV0FBVyxDQUFZO1FBQ3ZCLGVBQVMsR0FBVCxTQUFTLENBQVc7UUFkeEIsb0JBQWMsR0FBWSxLQUFLLENBQUM7UUFHaEMsNkJBQXVCLEdBQVksS0FBSyxDQUFDO1FBQ3pDLGFBQU8sR0FBNkIsRUFBRSxDQUFDLEVBQUUsQ0FBQyxFQUFFLENBQUMsRUFBRSxDQUFDLEVBQUUsQ0FBQztRQUNuRCxvQkFBYyxHQUFXLEVBQUUsQ0FBQztRQWdCaEMsS0FBSSxDQUFDLFNBQVMsR0FBRyxTQUFTLENBQUMsY0FBYyxFQUFFLENBQUM7UUFDNUMsS0FBSSxDQUFDLFlBQVksR0FBRyxnQkFBZ0IsQ0FBQyxNQUFNLEVBQUUsQ0FBQyxTQUFTLENBQUM7WUFDcEQsaUJBQU0sSUFBSSxZQUFFLENBQUM7UUFDakIsQ0FBQyxDQUFDLENBQUM7UUFDSCxLQUFJLENBQUMsY0FBYyxHQUFHLGdCQUFnQixDQUFDLFlBQVksRUFBRSxDQUFDLFNBQVMsQ0FBQztZQUM1RCxpQkFBTSxJQUFJLFlBQUUsQ0FBQztRQUNqQixDQUFDLENBQUMsQ0FBQzs7SUFDUCxDQUFDO0lBRUQscUNBQVEsR0FBUjtRQUNJLElBQUksQ0FBQyxRQUFRLEVBQUUsQ0FBQztJQUNwQixDQUFDO0lBRUQseUNBQVksR0FBWixVQUFhLENBQVE7UUFDakIsd0RBQXdEO1FBQ3hELElBQUksQ0FBQyxJQUFJLENBQUMsU0FBUyxJQUFJLENBQUMsSUFBSSxDQUFDLHVCQUF1QixFQUFFO1lBQ2xELElBQUksSUFBSSxDQUFDLFdBQVcsRUFBRTtnQkFDbEIsWUFBWSxDQUFDLElBQUksQ0FBQyxXQUFXLENBQUMsQ0FBQztnQkFDL0IsSUFBSSxDQUFDLE1BQU0sRUFBRSxDQUFDO2FBQ2pCO1lBQ0QsaUJBQU0sUUFBUSxXQUFFLENBQUM7U0FDcEI7SUFDTCxDQUFDO0lBRUQseUNBQVksR0FBWixVQUFhLENBQVE7UUFDakIsd0RBQXdEO1FBQ3hELElBQUksQ0FBQyxJQUFJLENBQUMsU0FBUyxJQUFJLENBQUMsSUFBSSxDQUFDLHVCQUF1QixFQUFFO1lBQ2xELGlCQUFNLFVBQVUsV0FBRSxDQUFDO1NBQ3RCO0lBQ0wsQ0FBQztJQUVELG9DQUFPLEdBQVAsVUFBUSxDQUFRO1FBQ1osSUFBSSxDQUFDLElBQUksQ0FBQyx1QkFBdUIsRUFBRTtZQUMvQixtR0FBbUc7WUFDbkcsSUFBSSxDQUFDLElBQUksQ0FBQyxTQUFTLEVBQUU7Z0JBQ2pCLGlCQUFNLFVBQVUsV0FBRSxDQUFDO2FBQ3RCO2lCQUFNO2dCQUNILElBQUksSUFBSSxDQUFDLFdBQVcsRUFBRTtvQkFDbEIsWUFBWSxDQUFDLElBQUksQ0FBQyxXQUFXLENBQUMsQ0FBQztvQkFDL0IsSUFBSSxDQUFDLE1BQU0sRUFBRSxDQUFDO2lCQUNqQjtnQkFFRCxpQkFBTSxRQUFRLFdBQUUsQ0FBQzthQUNwQjtTQUNKO0lBQ0wsQ0FBQztJQUd3QixzQkFBSSxvQ0FBSTtRQURqQyxvRUFBb0U7YUFDM0MsVUFBUyxJQUFZO1lBQzFDLElBQUksQ0FBQyxLQUFLLEdBQUcsSUFBSSxDQUFDO1lBQ2xCLElBQUksSUFBSSxDQUFDLE1BQU0sRUFBRTtnQkFDYixJQUFJLElBQUksQ0FBQyxLQUFLLEVBQUU7b0JBQ1osSUFBSSxJQUFJLENBQUMsU0FBUyxJQUFJLElBQUksQ0FBQyxTQUFTLENBQUMsWUFBWSxFQUFFO3dCQUMvQyxpQkFBTSxVQUFVLFdBQUUsQ0FBQztxQkFDdEI7eUJBQU07d0JBQ0gsSUFBSSxDQUFDLElBQUksRUFBRSxDQUFDO3FCQUNmO2lCQUNKO3FCQUNJO29CQUNELGlCQUFNLElBQUksV0FBRSxDQUFDO2lCQUNoQjthQUNKO1FBQ0wsQ0FBQzs7O09BQUE7SUFFTSxpQ0FBSSxHQUFYO1FBQ0ksSUFBSSxDQUFDLElBQUksQ0FBQyxLQUFLLElBQUksSUFBSSxDQUFDLFFBQVEsRUFBRTtZQUM5QixPQUFPO1NBQ1Y7UUFDRCxpQkFBTSxNQUFNLFdBQUUsQ0FBQztRQUNmLElBQUksQ0FBQyxLQUFLLEVBQUUsQ0FBQztRQUViLFVBQVUsQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLFNBQVMsRUFBRSxHQUFHLENBQUMsQ0FBQztRQUN2QyxJQUFJLElBQUksQ0FBQyxhQUFhLEtBQUssTUFBTSxFQUFFO1lBQy9CLElBQUksQ0FBQyxTQUFTLENBQUMsS0FBSyxDQUFDLE1BQU0sR0FBRyxFQUFFLFVBQVUsQ0FBQyxNQUFNLENBQUM7U0FDckQ7YUFBTTtZQUNILElBQUksQ0FBQyxTQUFTLENBQUMsS0FBSyxDQUFDLE1BQU0sR0FBRyxJQUFJLENBQUMsYUFBYSxDQUFDO1NBQ3BEO1FBQ0QsSUFBSSxDQUFDLElBQUksQ0FBQyx1QkFBdUIsRUFBRTtZQUMvQixpQkFBTSwwQkFBMEIsV0FBRSxDQUFDO1lBQ25DLGtEQUFrRDtZQUNsRCxJQUFJLElBQUksQ0FBQyxTQUFTO2dCQUFFLElBQUksQ0FBQywrQkFBK0IsRUFBRSxDQUFDO1NBQzlEO0lBQ0wsQ0FBQztJQUVNLGtDQUFLLEdBQVo7UUFDSSxJQUFJLFFBQVEsR0FBVyxJQUFJLENBQUMsZUFBZSxDQUFDO1FBQzVDLElBQUksQ0FBQyxxQkFBcUIsR0FBRyxJQUFJLENBQUM7UUFFbEMsUUFBUSxRQUFRLEVBQUU7WUFDZCxLQUFLLEtBQUs7Z0JBQ04sSUFBSSxDQUFDLFFBQVEsRUFBRSxDQUFDO2dCQUNoQixzQ0FBc0M7Z0JBQ3RDLDJEQUEyRDtnQkFDM0QsSUFBSSxJQUFJLENBQUMsY0FBYyxFQUFFO29CQUNyQixJQUFJLENBQUMsYUFBYSxFQUFFLENBQUM7b0JBRXJCLElBQUksSUFBSSxDQUFDLGNBQWMsRUFBRTt3QkFDckIsSUFBSSxDQUFDLFlBQVksRUFBRSxDQUFDO3dCQUVwQixJQUFJLElBQUksQ0FBQyxjQUFjLEVBQUU7NEJBQ3JCLElBQUksQ0FBQyxxQkFBcUIsR0FBRyxJQUFJLENBQUMsa0JBQWtCLEVBQUUsQ0FBQzs0QkFDdkQsSUFBSSxDQUFDLFdBQVcsQ0FBQyxJQUFJLENBQUMscUJBQXFCLENBQUMsQ0FBQzt5QkFDaEQ7cUJBQ0o7aUJBQ0o7Z0JBQ0QsTUFBTTtZQUVWLEtBQUssV0FBVztnQkFDWixJQUFJLENBQUMsYUFBYSxFQUFFLENBQUM7Z0JBQ3JCLHNDQUFzQztnQkFDdEMsSUFBSSxJQUFJLENBQUMsY0FBYyxFQUFFO29CQUNyQixJQUFJLENBQUMsUUFBUSxFQUFFLENBQUM7b0JBRWhCLElBQUksSUFBSSxDQUFDLGNBQWMsRUFBRTt3QkFDckIsSUFBSSxDQUFDLFlBQVksRUFBRSxDQUFDO3dCQUVwQixJQUFJLElBQUksQ0FBQyxjQUFjLEVBQUU7NEJBQ3JCLElBQUksQ0FBQyxxQkFBcUIsR0FBRyxJQUFJLENBQUMsa0JBQWtCLEVBQUUsQ0FBQzs0QkFDdkQsSUFBSSxDQUFDLFdBQVcsQ0FBQyxJQUFJLENBQUMscUJBQXFCLENBQUMsQ0FBQzt5QkFDaEQ7cUJBQ0o7aUJBQ0o7Z0JBQ0QsTUFBTTtZQUVWLEtBQUssVUFBVTtnQkFDWCxJQUFJLENBQUMsWUFBWSxFQUFFLENBQUM7Z0JBQ3BCLHNDQUFzQztnQkFDdEMsSUFBSSxJQUFJLENBQUMsY0FBYyxFQUFFO29CQUNyQixJQUFJLENBQUMsUUFBUSxFQUFFLENBQUM7b0JBRWhCLElBQUksSUFBSSxDQUFDLGNBQWMsRUFBRTt3QkFDckIsSUFBSSxDQUFDLGFBQWEsRUFBRSxDQUFDO3dCQUVyQixJQUFJLElBQUksQ0FBQyxjQUFjLEVBQUU7NEJBQ3JCLElBQUksQ0FBQyxxQkFBcUIsR0FBRyxJQUFJLENBQUMsa0JBQWtCLEVBQUUsQ0FBQzs0QkFDdkQsSUFBSSxDQUFDLFdBQVcsQ0FBQyxJQUFJLENBQUMscUJBQXFCLENBQUMsQ0FBQzt5QkFDaEQ7cUJBQ0o7aUJBQ0o7Z0JBQ0QsTUFBTTtZQUVWLEtBQUssUUFBUTtnQkFDVCxJQUFJLENBQUMsV0FBVyxFQUFFLENBQUM7Z0JBQ25CLHNDQUFzQztnQkFDdEMsSUFBSSxJQUFJLENBQUMsY0FBYyxFQUFFO29CQUNyQixJQUFJLENBQUMsZ0JBQWdCLEVBQUUsQ0FBQztvQkFFeEIsSUFBSSxJQUFJLENBQUMsY0FBYyxFQUFFO3dCQUNyQixJQUFJLENBQUMsZUFBZSxFQUFFLENBQUM7d0JBRXZCLElBQUksSUFBSSxDQUFDLGNBQWMsRUFBRTs0QkFDckIsMkNBQTJDOzRCQUMzQyxJQUFJLENBQUMscUJBQXFCLEdBQUcsSUFBSSxDQUFDLGtCQUFrQixFQUFFLENBQUM7NEJBQ3ZELElBQUksQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLHFCQUFxQixDQUFDLENBQUM7eUJBQzdDO3FCQUNKO2lCQUNKO2dCQUNELE1BQU07WUFFVixLQUFLLGNBQWM7Z0JBQ2YsSUFBSSxDQUFDLGdCQUFnQixFQUFFLENBQUM7Z0JBQ3hCLHNDQUFzQztnQkFDdEMsSUFBSSxJQUFJLENBQUMsY0FBYyxFQUFFO29CQUNyQixJQUFJLENBQUMsV0FBVyxFQUFFLENBQUM7b0JBRW5CLElBQUksSUFBSSxDQUFDLGNBQWMsRUFBRTt3QkFDckIsSUFBSSxDQUFDLGVBQWUsRUFBRSxDQUFDO3dCQUV2QixJQUFJLElBQUksQ0FBQyxjQUFjLEVBQUU7NEJBQ3JCLDJDQUEyQzs0QkFDM0MsSUFBSSxDQUFDLHFCQUFxQixHQUFHLElBQUksQ0FBQyxrQkFBa0IsRUFBRSxDQUFDOzRCQUN2RCxJQUFJLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxxQkFBcUIsQ0FBQyxDQUFDO3lCQUM3QztxQkFDSjtpQkFDSjtnQkFDRCxNQUFNO1lBRVYsS0FBSyxhQUFhO2dCQUNkLElBQUksQ0FBQyxlQUFlLEVBQUUsQ0FBQztnQkFDdkIsc0NBQXNDO2dCQUN0QyxJQUFJLElBQUksQ0FBQyxjQUFjLEVBQUU7b0JBQ3JCLElBQUksQ0FBQyxXQUFXLEVBQUUsQ0FBQztvQkFFbkIsSUFBSSxJQUFJLENBQUMsY0FBYyxFQUFFO3dCQUNyQixJQUFJLENBQUMsZ0JBQWdCLEVBQUUsQ0FBQzt3QkFFeEIsSUFBSSxJQUFJLENBQUMsY0FBYyxFQUFFOzRCQUNyQiwyQ0FBMkM7NEJBQzNDLElBQUksQ0FBQyxxQkFBcUIsR0FBRyxJQUFJLENBQUMsa0JBQWtCLEVBQUUsQ0FBQzs0QkFDdkQsSUFBSSxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMscUJBQXFCLENBQUMsQ0FBQzt5QkFDN0M7cUJBQ0o7aUJBQ0o7Z0JBQ0QsTUFBTTtZQUVWLEtBQUssTUFBTTtnQkFDUCxJQUFJLENBQUMsU0FBUyxFQUFFLENBQUM7Z0JBQ2pCLElBQUksSUFBSSxDQUFDLGNBQWMsRUFBRTtvQkFDckIsSUFBSSxDQUFDLFVBQVUsRUFBRSxDQUFDO29CQUVsQixJQUFJLElBQUksQ0FBQyxjQUFjLEVBQUU7d0JBQ3JCLElBQUksQ0FBQyxRQUFRLEVBQUUsQ0FBQzt3QkFFaEIsSUFBSSxJQUFJLENBQUMsY0FBYyxFQUFFOzRCQUNyQiw4Q0FBOEM7NEJBQzlDLElBQUksQ0FBQyxxQkFBcUIsR0FBRyxJQUFJLENBQUMsa0JBQWtCLEVBQUUsQ0FBQzs0QkFDdkQsSUFBSSxDQUFDLFdBQVcsQ0FBQyxJQUFJLENBQUMsa0JBQWtCLEVBQUUsQ0FBQyxDQUFDO3lCQUMvQztxQkFDSjtpQkFDSjtnQkFDRCxNQUFNO1lBRVYsS0FBSyxPQUFPO2dCQUNSLElBQUksQ0FBQyxVQUFVLEVBQUUsQ0FBQztnQkFDbEIsSUFBSSxJQUFJLENBQUMsY0FBYyxFQUFFO29CQUNyQixJQUFJLENBQUMsU0FBUyxFQUFFLENBQUM7b0JBRWpCLElBQUksSUFBSSxDQUFDLGNBQWMsRUFBRTt3QkFDckIsSUFBSSxDQUFDLFFBQVEsRUFBRSxDQUFDO3dCQUVoQixJQUFJLElBQUksQ0FBQyxjQUFjLEVBQUU7NEJBQ3JCLDhDQUE4Qzs0QkFDOUMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxJQUFJLENBQUMsa0JBQWtCLEVBQUUsQ0FBQyxDQUFDO3lCQUMvQztxQkFDSjtpQkFDSjtnQkFDRCxNQUFNO1NBQ2I7SUFDTCxDQUFDO0lBRU0sdUNBQVUsR0FBakI7UUFDSSwyQ0FBMkM7UUFDM0MsSUFBSSxDQUFDLFFBQVEsQ0FBQyxPQUFPLENBQUMsQ0FBQztRQUN2QixJQUFJLFVBQVUsR0FBa0MsaUJBQU0sYUFBYSxXQUFFLENBQUM7UUFDdEUsSUFBSSxLQUFLLEdBQVcsVUFBVSxDQUFDLGFBQWEsQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLENBQUM7UUFDN0QsSUFBSSxNQUFNLEdBQVcsVUFBVSxDQUFDLGNBQWMsQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLENBQUM7UUFDL0QsSUFBSSxJQUFJLEdBQVcsVUFBVSxDQUFDLElBQUksR0FBRyxVQUFVLENBQUMsYUFBYSxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsYUFBYSxDQUFDLEdBQUcsSUFBSSxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUM7UUFDdkcsSUFBSSxHQUFHLEdBQVcsVUFBVSxDQUFDLEdBQUcsR0FBRyxDQUFDLFVBQVUsQ0FBQyxjQUFjLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxhQUFhLENBQUMsR0FBRyxVQUFVLENBQUMsY0FBYyxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDLEdBQUcsSUFBSSxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUM7UUFFNUosSUFBSSxDQUFDLGNBQWMsR0FBRyxJQUFJLENBQUMsaUJBQWlCLENBQUMsSUFBSSxFQUFFLEdBQUcsRUFBRSxLQUFLLEVBQUUsTUFBTSxDQUFDLENBQUM7UUFDdkUsSUFBSSxDQUFDLFNBQVMsQ0FBQyxLQUFLLENBQUMsSUFBSSxHQUFHLElBQUksR0FBRyxJQUFJLENBQUM7UUFDeEMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxLQUFLLENBQUMsR0FBRyxHQUFHLEdBQUcsR0FBRyxJQUFJLENBQUM7SUFDMUMsQ0FBQztJQUVNLHNDQUFTLEdBQWhCO1FBQ0ksMkNBQTJDO1FBQzNDLElBQUksQ0FBQyxRQUFRLENBQUMsTUFBTSxDQUFDLENBQUM7UUFDdEIsSUFBSSxVQUFVLEdBQWtDLGlCQUFNLGFBQWEsV0FBRSxDQUFDO1FBQ3RFLElBQUksS0FBSyxHQUFXLFVBQVUsQ0FBQyxhQUFhLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDO1FBQzdELElBQUksTUFBTSxHQUFXLFVBQVUsQ0FBQyxjQUFjLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDO1FBQy9ELElBQUksSUFBSSxHQUFXLFVBQVUsQ0FBQyxJQUFJLEdBQUcsVUFBVSxDQUFDLGFBQWEsQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLEdBQUcsSUFBSSxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUM7UUFDL0YsSUFBSSxHQUFHLEdBQVcsVUFBVSxDQUFDLEdBQUcsR0FBRyxDQUFDLFVBQVUsQ0FBQyxjQUFjLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxhQUFhLENBQUMsR0FBRyxVQUFVLENBQUMsY0FBYyxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsQ0FBQyxHQUFHLENBQUMsR0FBRyxJQUFJLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQztRQUV4SixJQUFJLENBQUMsY0FBYyxHQUFHLElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxJQUFJLEVBQUUsR0FBRyxFQUFFLEtBQUssRUFBRSxNQUFNLENBQUMsQ0FBQztRQUN2RSxJQUFJLENBQUMsU0FBUyxDQUFDLEtBQUssQ0FBQyxJQUFJLEdBQUcsSUFBSSxHQUFHLElBQUksQ0FBQztRQUN4QyxJQUFJLENBQUMsU0FBUyxDQUFDLEtBQUssQ0FBQyxHQUFHLEdBQUcsR0FBRyxHQUFHLElBQUksQ0FBQztJQUMxQyxDQUFDO0lBRU0scUNBQVEsR0FBZixVQUFnQixRQUFpQjtRQUM3Qix3REFBd0Q7UUFDeEQsSUFBSSxDQUFDLFFBQVEsQ0FBQyxLQUFLLENBQUMsQ0FBQztRQUNyQixJQUFJLFFBQVEsS0FBSyxDQUFDLElBQUksT0FBTyxRQUFRLEtBQUssV0FBVyxFQUFFO1lBQ25ELElBQUksQ0FBQyxTQUFTLENBQUMsS0FBSyxDQUFDLFFBQVEsR0FBRyxDQUFDLFVBQVUsQ0FBQyxhQUFhLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxHQUFHLFFBQVEsR0FBRyxDQUFDLENBQUMsQ0FBQyxRQUFRLEVBQUUsR0FBRyxJQUFJLENBQUM7U0FDL0c7UUFDRCxJQUFJLFVBQVUsR0FBa0MsaUJBQU0sYUFBYSxXQUFFLENBQUM7UUFDdEUsSUFBSSxLQUFLLEdBQVcsVUFBVSxDQUFDLGFBQWEsQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLENBQUM7UUFDN0QsSUFBSSxNQUFNLEdBQVcsVUFBVSxDQUFDLGNBQWMsQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLENBQUM7UUFDL0QsSUFBSSxJQUFJLEdBQVcsVUFBVSxDQUFDLElBQUksR0FBRyxDQUFDLFVBQVUsQ0FBQyxhQUFhLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxhQUFhLENBQUMsR0FBRyxVQUFVLENBQUMsYUFBYSxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsQ0FBQyxHQUFHLENBQUMsR0FBRyxJQUFJLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQztRQUN4SixJQUFJLEdBQUcsR0FBVyxVQUFVLENBQUMsR0FBRyxHQUFHLFVBQVUsQ0FBQyxjQUFjLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxHQUFHLElBQUksQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDO1FBRTlGLElBQUksQ0FBQyxjQUFjLEdBQUcsSUFBSSxDQUFDLGlCQUFpQixDQUFDLElBQUksRUFBRSxHQUFHLEVBQUUsS0FBSyxFQUFFLE1BQU0sQ0FBQyxDQUFDO1FBQ3ZFLElBQUksQ0FBQyxTQUFTLENBQUMsS0FBSyxDQUFDLElBQUksR0FBRyxJQUFJLEdBQUcsSUFBSSxDQUFDO1FBQ3hDLElBQUksQ0FBQyxTQUFTLENBQUMsS0FBSyxDQUFDLEdBQUcsR0FBRyxHQUFHLEdBQUcsSUFBSSxDQUFDO0lBQzFDLENBQUM7SUFFRCxnQkFBZ0I7SUFDVCwwQ0FBYSxHQUFwQixVQUFxQixRQUFpQjtRQUNsQyxJQUFJLENBQUMsUUFBUSxDQUFDLDBCQUEwQixDQUFDLENBQUM7UUFDMUMsSUFBSSxRQUFRLEtBQUssQ0FBQyxJQUFJLE9BQU8sUUFBUSxLQUFLLFdBQVc7WUFBRSxJQUFJLENBQUMsU0FBUyxDQUFDLEtBQUssQ0FBQyxRQUFRLEdBQUcsQ0FBQyxVQUFVLENBQUMsYUFBYSxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsR0FBRyxRQUFRLEdBQUcsQ0FBQyxDQUFDLENBQUMsUUFBUSxFQUFFLEdBQUcsSUFBSSxDQUFDO1FBRW5LLElBQUksVUFBVSxHQUFrQyxpQkFBTSxhQUFhLFdBQUUsQ0FBQztRQUN0RSxJQUFJLEtBQUssR0FBVyxVQUFVLENBQUMsYUFBYSxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsQ0FBQztRQUM3RCxJQUFJLE1BQU0sR0FBVyxVQUFVLENBQUMsY0FBYyxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsQ0FBQztRQUMvRCxJQUFJLElBQUksR0FBVyxVQUFVLENBQUMsSUFBSSxHQUFHLFVBQVUsQ0FBQyxhQUFhLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxhQUFhLENBQUMsR0FBRyxDQUFDLEdBQUcsSUFBSSxDQUFDLGNBQWMsR0FBRyxJQUFJLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQztRQUNqSSxJQUFJLEdBQUcsR0FBVyxVQUFVLENBQUMsR0FBRyxHQUFHLFVBQVUsQ0FBQyxjQUFjLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxHQUFHLElBQUksQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDO1FBRTlGLElBQUksQ0FBQyxjQUFjLEdBQUcsSUFBSSxDQUFDLGlCQUFpQixDQUFDLElBQUksRUFBRSxHQUFHLEVBQUUsS0FBSyxFQUFFLE1BQU0sQ0FBQyxDQUFDO1FBQ3ZFLElBQUksQ0FBQyxTQUFTLENBQUMsS0FBSyxDQUFDLElBQUksR0FBRyxJQUFJLEdBQUcsSUFBSSxDQUFDO1FBQ3hDLElBQUksQ0FBQyxTQUFTLENBQUMsS0FBSyxDQUFDLEdBQUcsR0FBRyxHQUFHLEdBQUcsSUFBSSxDQUFDO0lBQzFDLENBQUM7SUFFRCxnQkFBZ0I7SUFDVCx5Q0FBWSxHQUFuQixVQUFvQixRQUFpQjtRQUNqQyxJQUFJLENBQUMsUUFBUSxDQUFDLHlCQUF5QixDQUFDLENBQUM7UUFDekMsSUFBSSxRQUFRLEtBQUssQ0FBQyxJQUFJLE9BQU8sUUFBUSxLQUFLLFdBQVc7WUFBRSxJQUFJLENBQUMsU0FBUyxDQUFDLEtBQUssQ0FBQyxRQUFRLEdBQUcsQ0FBQyxVQUFVLENBQUMsYUFBYSxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsR0FBRyxRQUFRLEdBQUcsQ0FBQyxDQUFDLENBQUMsUUFBUSxFQUFFLEdBQUcsSUFBSSxDQUFDO1FBRW5LLElBQUksVUFBVSxHQUFrQyxpQkFBTSxhQUFhLFdBQUUsQ0FBQztRQUN0RSxJQUFJLEtBQUssR0FBVyxVQUFVLENBQUMsYUFBYSxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsQ0FBQztRQUM3RCxJQUFJLE1BQU0sR0FBVyxVQUFVLENBQUMsY0FBYyxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsQ0FBQztRQUMvRCxJQUFJLElBQUksR0FBVyxVQUFVLENBQUMsSUFBSSxHQUFHLFVBQVUsQ0FBQyxhQUFhLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxhQUFhLENBQUMsR0FBRyxDQUFDLEdBQUcsVUFBVSxDQUFDLGFBQWEsQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLEdBQUcsSUFBSSxDQUFDLGNBQWMsR0FBRyxJQUFJLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQztRQUM1SyxJQUFJLEdBQUcsR0FBVyxVQUFVLENBQUMsR0FBRyxHQUFHLFVBQVUsQ0FBQyxjQUFjLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxHQUFHLElBQUksQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDO1FBRTlGLElBQUksQ0FBQyxjQUFjLEdBQUcsSUFBSSxDQUFDLGlCQUFpQixDQUFDLElBQUksRUFBRSxHQUFHLEVBQUUsS0FBSyxFQUFFLE1BQU0sQ0FBQyxDQUFDO1FBQ3ZFLElBQUksQ0FBQyxTQUFTLENBQUMsS0FBSyxDQUFDLElBQUksR0FBRyxJQUFJLEdBQUcsSUFBSSxDQUFDO1FBQ3hDLElBQUksQ0FBQyxTQUFTLENBQUMsS0FBSyxDQUFDLEdBQUcsR0FBRyxHQUFHLEdBQUcsSUFBSSxDQUFDO0lBQzFDLENBQUM7SUFHTSx3Q0FBVyxHQUFsQixVQUFtQixRQUFpQjtRQUNoQyx3REFBd0Q7UUFDeEQsSUFBSSxDQUFDLFFBQVEsQ0FBQyxRQUFRLENBQUMsQ0FBQztRQUN4QixJQUFJLFFBQVEsS0FBSyxDQUFDLElBQUksT0FBTyxRQUFRLEtBQUssV0FBVztZQUFFLElBQUksQ0FBQyxTQUFTLENBQUMsS0FBSyxDQUFDLFFBQVEsR0FBRyxDQUFDLFVBQVUsQ0FBQyxhQUFhLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxHQUFHLFFBQVEsR0FBRyxDQUFDLENBQUMsQ0FBQyxRQUFRLEVBQUUsR0FBRyxJQUFJLENBQUM7UUFFbkssSUFBSSxVQUFVLEdBQWtDLGlCQUFNLGFBQWEsV0FBRSxDQUFDO1FBQ3RFLElBQUksS0FBSyxHQUFXLFVBQVUsQ0FBQyxhQUFhLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDO1FBQzdELElBQUksTUFBTSxHQUFXLFVBQVUsQ0FBQyxjQUFjLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDO1FBQy9ELElBQUksSUFBSSxHQUFXLFVBQVUsQ0FBQyxJQUFJLEdBQUcsQ0FBQyxVQUFVLENBQUMsYUFBYSxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsYUFBYSxDQUFDLEdBQUcsVUFBVSxDQUFDLGFBQWEsQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLENBQUMsR0FBRyxDQUFDLEdBQUcsSUFBSSxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUM7UUFDeEosSUFBSSxHQUFHLEdBQVcsVUFBVSxDQUFDLEdBQUcsR0FBRyxVQUFVLENBQUMsY0FBYyxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsYUFBYSxDQUFDLEdBQUcsSUFBSSxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUM7UUFFdEcsSUFBSSxDQUFDLGNBQWMsR0FBRyxJQUFJLENBQUMsaUJBQWlCLENBQUMsSUFBSSxFQUFFLEdBQUcsRUFBRSxLQUFLLEVBQUUsTUFBTSxDQUFDLENBQUM7UUFDdkUsSUFBSSxDQUFDLFNBQVMsQ0FBQyxLQUFLLENBQUMsSUFBSSxHQUFHLElBQUksR0FBRyxJQUFJLENBQUM7UUFDeEMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxLQUFLLENBQUMsR0FBRyxHQUFHLEdBQUcsR0FBRyxJQUFJLENBQUM7SUFDMUMsQ0FBQztJQUVELGdCQUFnQjtJQUNULDZDQUFnQixHQUF2QixVQUF3QixRQUFpQjtRQUNyQyxJQUFJLENBQUMsUUFBUSxDQUFDLGdDQUFnQyxDQUFDLENBQUM7UUFDaEQsSUFBSSxRQUFRLEtBQUssQ0FBQyxJQUFJLE9BQU8sUUFBUSxLQUFLLFdBQVc7WUFBRSxJQUFJLENBQUMsU0FBUyxDQUFDLEtBQUssQ0FBQyxRQUFRLEdBQUcsQ0FBQyxVQUFVLENBQUMsYUFBYSxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsR0FBRyxRQUFRLEdBQUcsQ0FBQyxDQUFDLENBQUMsUUFBUSxFQUFFLEdBQUcsSUFBSSxDQUFDO1FBRW5LLElBQUksVUFBVSxHQUFrQyxpQkFBTSxhQUFhLFdBQUUsQ0FBQztRQUN0RSxJQUFJLEtBQUssR0FBVyxVQUFVLENBQUMsYUFBYSxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsQ0FBQztRQUM3RCxJQUFJLE1BQU0sR0FBVyxVQUFVLENBQUMsY0FBYyxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsQ0FBQztRQUMvRCxJQUFJLElBQUksR0FBVyxVQUFVLENBQUMsSUFBSSxHQUFHLFVBQVUsQ0FBQyxhQUFhLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxhQUFhLENBQUMsR0FBRyxDQUFDLEdBQUcsSUFBSSxDQUFDLGNBQWMsR0FBRyxJQUFJLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQztRQUNqSSxJQUFJLEdBQUcsR0FBVyxVQUFVLENBQUMsR0FBRyxHQUFHLFVBQVUsQ0FBQyxjQUFjLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxhQUFhLENBQUMsR0FBRyxJQUFJLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQztRQUV0RyxJQUFJLENBQUMsY0FBYyxHQUFHLElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxJQUFJLEVBQUUsR0FBRyxFQUFFLEtBQUssRUFBRSxNQUFNLENBQUMsQ0FBQztRQUN2RSxJQUFJLENBQUMsU0FBUyxDQUFDLEtBQUssQ0FBQyxJQUFJLEdBQUcsSUFBSSxHQUFHLElBQUksQ0FBQztRQUN4QyxJQUFJLENBQUMsU0FBUyxDQUFDLEtBQUssQ0FBQyxHQUFHLEdBQUcsR0FBRyxHQUFHLElBQUksQ0FBQztJQUMxQyxDQUFDO0lBRUQsZ0JBQWdCO0lBQ1QsNENBQWUsR0FBdEIsVUFBdUIsUUFBaUI7UUFDcEMsSUFBSSxDQUFDLFFBQVEsQ0FBQywrQkFBK0IsQ0FBQyxDQUFDO1FBQy9DLElBQUksUUFBUSxLQUFLLENBQUMsSUFBSSxPQUFPLFFBQVEsS0FBSyxXQUFXO1lBQUUsSUFBSSxDQUFDLFNBQVMsQ0FBQyxLQUFLLENBQUMsUUFBUSxHQUFHLENBQUMsVUFBVSxDQUFDLGFBQWEsQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLEdBQUcsUUFBUSxHQUFHLENBQUMsQ0FBQyxDQUFDLFFBQVEsRUFBRSxHQUFHLElBQUksQ0FBQztRQUVuSyxJQUFJLFVBQVUsR0FBa0MsaUJBQU0sYUFBYSxXQUFFLENBQUM7UUFDdEUsSUFBSSxLQUFLLEdBQVcsVUFBVSxDQUFDLGFBQWEsQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLENBQUM7UUFDN0QsSUFBSSxNQUFNLEdBQVcsVUFBVSxDQUFDLGNBQWMsQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLENBQUM7UUFDL0QsSUFBSSxJQUFJLEdBQVcsVUFBVSxDQUFDLElBQUksR0FBRyxVQUFVLENBQUMsYUFBYSxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsYUFBYSxDQUFDLEdBQUcsQ0FBQyxHQUFHLFVBQVUsQ0FBQyxhQUFhLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxHQUFHLElBQUksQ0FBQyxjQUFjLEdBQUcsSUFBSSxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUM7UUFDNUssSUFBSSxHQUFHLEdBQVcsVUFBVSxDQUFDLEdBQUcsR0FBRyxVQUFVLENBQUMsY0FBYyxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsYUFBYSxDQUFDLEdBQUcsSUFBSSxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUM7UUFFdEcsSUFBSSxDQUFDLGNBQWMsR0FBRyxJQUFJLENBQUMsaUJBQWlCLENBQUMsSUFBSSxFQUFFLEdBQUcsRUFBRSxLQUFLLEVBQUUsTUFBTSxDQUFDLENBQUM7UUFDdkUsSUFBSSxDQUFDLFNBQVMsQ0FBQyxLQUFLLENBQUMsSUFBSSxHQUFHLElBQUksR0FBRyxJQUFJLENBQUM7UUFDeEMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxLQUFLLENBQUMsR0FBRyxHQUFHLEdBQUcsR0FBRyxJQUFJLENBQUM7SUFDMUMsQ0FBQztJQUVNLHFDQUFRLEdBQWYsVUFBZ0IsU0FBa0I7UUFDOUIsSUFBSSxDQUFDLFNBQVMsQ0FBQyxLQUFLLENBQUMsSUFBSSxHQUFHLENBQUMsR0FBRyxHQUFHLElBQUksQ0FBQztRQUN4QyxJQUFJLENBQUMsU0FBUyxDQUFDLEtBQUssQ0FBQyxHQUFHLEdBQUcsQ0FBQyxHQUFHLEdBQUcsSUFBSSxDQUFDO1FBRXZDLHlEQUF5RDtRQUN6RCxJQUFJLGdCQUFnQixHQUFXLGtDQUFrQyxHQUFHLFNBQVMsQ0FBQztRQUM5RSxJQUFJLENBQUMsU0FBUyxDQUFDLFNBQVMsR0FBRyxJQUFJLENBQUMsaUJBQWlCLENBQUMsQ0FBQyxDQUFDLGdCQUFnQixHQUFHLEdBQUcsR0FBRyxJQUFJLENBQUMsaUJBQWlCLENBQUMsQ0FBQyxDQUFDLGdCQUFnQixDQUFDO0lBQzNILENBQUM7SUFFRCw2RkFBNkY7SUFDckYsOENBQWlCLEdBQXpCLFVBQTBCLEtBQWEsRUFBRSxJQUFZLEVBQUUsTUFBYyxFQUFFLE9BQWU7UUFDbEYsSUFBSSxRQUFRLEdBQUcsVUFBVSxDQUFDLFdBQVcsRUFBRSxDQUFDO1FBQ3hDLE9BQU8sQ0FBQyxLQUFLLEdBQUcsTUFBTSxHQUFHLFFBQVEsQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLEtBQUssR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDLElBQUksR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDLElBQUksR0FBRyxPQUFPLEdBQUcsUUFBUSxDQUFDLE1BQU0sQ0FBQyxDQUFDO0lBQ2hILENBQUM7SUFFTSxtQ0FBTSxHQUFiO1FBQ0ksSUFBSSxDQUFDLElBQUksQ0FBQyx1QkFBdUIsRUFBRTtZQUMvQixxREFBcUQ7WUFDckQsSUFBSSxJQUFJLENBQUMsU0FBUztnQkFBRSxJQUFJLENBQUMsZ0NBQWdDLEVBQUUsQ0FBQztTQUMvRDtRQUNELElBQUksSUFBSSxDQUFDLFNBQVMsSUFBSSxJQUFJLENBQUMsU0FBUyxDQUFDLGFBQWEsRUFBRTtZQUNoRCxJQUFJLElBQUksQ0FBQyxRQUFRLEtBQUssTUFBTSxFQUFFO2dCQUMxQixRQUFRLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLENBQUM7YUFDN0M7aUJBQU0sSUFBSSxJQUFJLENBQUMsUUFBUSxLQUFLLFFBQVEsRUFBRTtnQkFDbkMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxhQUFhLENBQUMsV0FBVyxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsQ0FBQzthQUN0RDtpQkFBTTtnQkFDSCxVQUFVLENBQUMsV0FBVyxDQUFDLElBQUksQ0FBQyxTQUFTLEVBQUUsSUFBSSxDQUFDLFFBQVEsQ0FBQyxDQUFDO2FBQ3pEO1NBQ0o7UUFDRCxJQUFJLENBQUMsU0FBUyxHQUFHLElBQUksQ0FBQztJQUMxQixDQUFDO0lBRUQsa0NBQWtDO0lBQzFCLHFDQUFRLEdBQWhCO1FBQUEsaUJBWUM7UUFYRyxJQUFJLE9BQU8sSUFBSSxDQUFDLEdBQUcsS0FBSyxXQUFXLEVBQUU7WUFDakMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxXQUFXLEdBQUcsY0FBWSxPQUFBLGlCQUFNLFFBQVEsWUFBRSxFQUFoQixDQUFnQixDQUFDO1lBQ3BELElBQUksQ0FBQyxHQUFHLENBQUMsV0FBVyxHQUFHLGNBQVksT0FBQSxpQkFBTSxVQUFVLFlBQUUsRUFBbEIsQ0FBa0IsQ0FBQztZQUN0RCxJQUFJLENBQUMsR0FBRyxDQUFDLHNCQUFzQixHQUFHLGNBQWMsS0FBSSxDQUFDLHVCQUF1QixHQUFHLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQztZQUN2RixJQUFJLENBQUMsR0FBRyxDQUFDLG9CQUFvQixHQUFHLGNBQWMsS0FBSSxDQUFDLHVCQUF1QixHQUFHLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQztZQUN0RixJQUFJLENBQUMsR0FBRyxDQUFDLEtBQUssR0FBRztnQkFDYixJQUFJLENBQUMsS0FBSSxDQUFDLFNBQVM7b0JBQUUsT0FBTztnQkFDNUIsS0FBSSxDQUFDLEtBQUssRUFBRSxDQUFDO1lBQ2pCLENBQUMsQ0FBQztZQUNGLElBQUksQ0FBQyxHQUFHLENBQUMsU0FBUyxHQUFHLFVBQUMsT0FBaUMsSUFBYSxLQUFJLENBQUMsT0FBTyxHQUFHLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQztTQUNqRztJQUNMLENBQUM7SUFFTywrQ0FBa0IsR0FBMUI7UUFDSSxJQUFJLE1BQU0sR0FBZSxJQUFJLENBQUMsU0FBUyxDQUFDLHFCQUFxQixFQUFFLENBQUM7UUFDaEUsSUFBSSxVQUFVLEdBQVcsTUFBTSxDQUFDLElBQUksQ0FBQztRQUNyQyxJQUFJLEtBQUssR0FBVyxVQUFVLENBQUMsYUFBYSxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsQ0FBQztRQUM3RCxJQUFJLFFBQVEsR0FBUSxVQUFVLENBQUMsV0FBVyxFQUFFLENBQUM7UUFFN0MsSUFBSSxVQUFVLEdBQUcsS0FBSyxHQUFHLFFBQVEsQ0FBQyxLQUFLLEdBQUcsQ0FBQztZQUFFLE9BQU8sVUFBVSxHQUFHLEtBQUssR0FBRyxRQUFRLENBQUMsS0FBSyxDQUFDO1FBQ3hGLElBQUksVUFBVSxHQUFHLENBQUM7WUFBRSxPQUFPLFVBQVUsR0FBRyxDQUFDLENBQUMsQ0FBQztRQUUzQyxPQUFPLENBQUMsQ0FBQztJQUNiLENBQUM7SUFFTyw0REFBK0IsR0FBdkM7UUFBQSxpQkFRQztRQVBHLElBQUksQ0FBQywyQkFBMkIsR0FBRyxJQUFJLENBQUMsU0FBUyxDQUFDLE1BQU0sQ0FDcEQsVUFBVSxFQUNWLFlBQVksRUFDWixVQUFBLEtBQUs7WUFDRCxpQkFBTSxJQUFJLFlBQUUsQ0FBQztRQUNqQixDQUFDLENBQ0osQ0FBQztJQUNOLENBQUM7SUFFTyw2REFBZ0MsR0FBeEM7UUFDSSxJQUFJLElBQUksQ0FBQywyQkFBMkIsRUFBRTtZQUNsQyxJQUFJLENBQUMsMkJBQTJCLEVBQUUsQ0FBQztZQUNuQyxJQUFJLENBQUMsMkJBQTJCLEdBQUcsSUFBSSxDQUFDO1NBQzNDO0lBQ0wsQ0FBQztJQUVELHdDQUFXLEdBQVg7UUFDSSx3QkFBd0I7UUFDeEIsSUFBSSxDQUFDLE1BQU0sRUFBRSxDQUFDO1FBQ2QsK0JBQStCO1FBQy9CLElBQUksQ0FBQyxZQUFZLENBQUMsV0FBVyxFQUFFLENBQUM7UUFDaEMsSUFBSSxDQUFDLGNBQWMsQ0FBQyxXQUFXLEVBQUUsQ0FBQztJQUN0QyxDQUFDOztnQkFoY2dCLFVBQVU7Z0JBQ2hCLE1BQU07Z0JBQ1EsVUFBVTtnQkFDWixTQUFTO2dCQUNqQixZQUFZO2dCQUNMLGVBQWU7O0lBVDVCO1FBQVIsS0FBSyxFQUFFOzttREFBa0I7SUE4REQ7UUFBeEIsS0FBSyxDQUFDLGdCQUFnQixDQUFDOzs7a0RBY3ZCO0lBekZRLGtCQUFrQjtRQUo5QixTQUFTLENBQUM7WUFDUCxRQUFRLEVBQUUsa0JBQWtCO1lBQzVCLFNBQVMsRUFBRSxDQUFDLFVBQVUsRUFBRSxZQUFZLEVBQUUsZUFBZSxDQUFDO1NBQ3pELENBQUM7eUNBa0JtQixVQUFVO1lBQ2hCLE1BQU07WUFDUSxVQUFVO1lBQ1osU0FBUztZQUNqQixZQUFZO1lBQ0wsZUFBZTtPQXRCNUIsa0JBQWtCLENBa2Q5QjtJQUFELHlCQUFDO0NBQUEsQUFsZEQsQ0FBd0MsT0FBTyxHQWtkOUM7U0FsZFksa0JBQWtCIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHtcclxuICAgIERpcmVjdGl2ZSxcclxuICAgIEVsZW1lbnRSZWYsXHJcbiAgICBPbkluaXQsXHJcbiAgICBPbkRlc3Ryb3ksXHJcbiAgICBJbnB1dCxcclxuICAgIFJlbmRlcmVyMixcclxuICAgIE5nWm9uZSxcclxufSBmcm9tICdAYW5ndWxhci9jb3JlJztcclxuaW1wb3J0IHsgS2REb21FbGVtU3ZjIH0gZnJvbSAnLi4va2QtY29tbW9uL2luZGV4JztcclxuaW1wb3J0IHtEb21IYW5kbGVyfSBmcm9tICdwcmltZW5nL2RvbSc7XHJcbmltcG9ydCB7IFRvb2x0aXAgfSBmcm9tICdwcmltZW5nL3Rvb2x0aXAnO1xyXG5pbXBvcnQgeyBLZFNwbGl0dGVyRXZlbnQgfSBmcm9tICcuLi9rZC1hbmd1bGFyLXNwbGl0dGVyL2luZGV4JztcclxuaW1wb3J0IHsgU3Vic2NyaXB0aW9uIH0gZnJvbSAncnhqcyc7XHJcblxyXG5leHBvcnQgaW50ZXJmYWNlIElUb29sdGlwQXBpIHtcclxuICAgIHNob3dUb29sdGlwPzogKCkgPT4gdm9pZDtcclxuICAgIGhpZGVUb29sdGlwPzogKCkgPT4gdm9pZDtcclxuICAgIGRlYWN0aXZhdGVIb3N0TGlzdGVuZXI/OiAoKSA9PiB2b2lkO1xyXG4gICAgYWN0aXZhdGVIb3N0TGlzdGVuZXI/OiAoKSA9PiB2b2lkO1xyXG4gICAgYWxpZ24/OiAoKSA9PiB2b2lkO1xyXG4gICAgc2V0T2Zmc2V0PzogKF9vZmZzZXQ6IHsgeDogbnVtYmVyLCB5OiBudW1iZXIgfSkgPT4gdm9pZDtcclxufVxyXG5cclxuQERpcmVjdGl2ZSh7XHJcbiAgICBzZWxlY3RvcjogJ1trZC10b29sdGlwLWRpcl0nLFxyXG4gICAgcHJvdmlkZXJzOiBbRG9tSGFuZGxlciwgS2REb21FbGVtU3ZjLCBLZFNwbGl0dGVyRXZlbnRdLFxyXG59KVxyXG5leHBvcnQgY2xhc3MgS2RUb29sdGlwRGlyZWN0aXZlIGV4dGVuZHMgVG9vbHRpcCBpbXBsZW1lbnRzIE9uSW5pdCwgT25EZXN0cm95IHtcclxuXHJcbiAgICBwcml2YXRlIF9pc01vYmlsZTogYm9vbGVhbjtcclxuICAgIHByaXZhdGUgX3dpZHRoT3V0c2lkZVZpZXdwb3J0OiBudW1iZXI7XHJcbiAgICBwcml2YXRlIF9kcmFnTWVudVN1YjogU3Vic2NyaXB0aW9uO1xyXG4gICAgcHJpdmF0ZSBfdG9nZ2xlTWVudVN1YjogU3Vic2NyaXB0aW9uO1xyXG4gICAgcHJpdmF0ZSBfaXNPdXRPZkJvdW5kczogYm9vbGVhbiA9IGZhbHNlO1xyXG5cclxuICAgIHByaXZhdGUgX2RvY3VtZW50VG91Y2hTdGFydExpc3RlbmVyOiBhbnk7XHJcbiAgICBwcml2YXRlIF9kZWFjdGl2YXRlSG9zdExpc3RlbmVyOiBib29sZWFuID0gZmFsc2U7XHJcbiAgICBwcml2YXRlIF9vZmZzZXQ6IHsgeDogbnVtYmVyLCB5OiBudW1iZXIgfSA9IHsgeDogMCwgeTogMCB9O1xyXG4gICAgcHJpdmF0ZSBfZGVmYXVsdE9mZnNldDogbnVtYmVyID0gMTA7XHJcblxyXG4gICAgQElucHV0KCkgYXBpOiBJVG9vbHRpcEFwaTtcclxuXHJcbiAgICAvLyBjb25zdHJ1Y3RvciBpcyBmdWxseSBuZXdcclxuICAgIGNvbnN0cnVjdG9yKFxyXG4gICAgICAgIHByaXZhdGUgX2VsOiBFbGVtZW50UmVmLFxyXG4gICAgICAgIF96b25lOiBOZ1pvbmUsXHJcbiAgICAgICAgcHJpdmF0ZSBfZG9tSGFuZGxlcjogRG9tSGFuZGxlcixcclxuICAgICAgICBwcml2YXRlIF9yZW5kZXJlcjogUmVuZGVyZXIyLFxyXG4gICAgICAgIF9rZERvbVN2YzogS2REb21FbGVtU3ZjLFxyXG4gICAgICAgIF9rZFNwbGl0dGVyRXZlbnQ6IEtkU3BsaXR0ZXJFdmVudCxcclxuICAgICkge1xyXG4gICAgICAgIC8vIHN1cGVyKF9lbCwgX2RvbUhhbmRsZXIsIF96b25lKTtcclxuICAgICAgICBzdXBlcihfZWwsIF96b25lKTtcclxuXHJcbiAgICAgICAgdGhpcy5faXNNb2JpbGUgPSBfa2REb21TdmMuaXNNb2JpbGVEZXZpY2UoKTtcclxuICAgICAgICB0aGlzLl9kcmFnTWVudVN1YiA9IF9rZFNwbGl0dGVyRXZlbnQub25EcmFnKCkuc3Vic2NyaWJlKCgpOiB2b2lkID0+IHtcclxuICAgICAgICAgICAgc3VwZXIuaGlkZSgpO1xyXG4gICAgICAgIH0pO1xyXG4gICAgICAgIHRoaXMuX3RvZ2dsZU1lbnVTdWIgPSBfa2RTcGxpdHRlckV2ZW50Lm9uVG9nZ2xlTWVudSgpLnN1YnNjcmliZSgoKTogdm9pZCA9PiB7XHJcbiAgICAgICAgICAgIHN1cGVyLmhpZGUoKTtcclxuICAgICAgICB9KTtcclxuICAgIH1cclxuXHJcbiAgICBuZ09uSW5pdCgpOiB2b2lkIHtcclxuICAgICAgICB0aGlzLl9pbml0QXBpKCk7XHJcbiAgICB9XHJcblxyXG4gICAgb25Nb3VzZUVudGVyKGU6IEV2ZW50KTogdm9pZCB7XHJcbiAgICAgICAgLy8gYWRkZWQgZXh0cmEgY29uZGl0aW9uICF0aGlzLl9pc01vYmlsZSB0byBpZiBzdGF0ZW1lbnRcclxuICAgICAgICBpZiAoIXRoaXMuX2lzTW9iaWxlICYmICF0aGlzLl9kZWFjdGl2YXRlSG9zdExpc3RlbmVyKSB7XHJcbiAgICAgICAgICAgIGlmICh0aGlzLmhpZGVUaW1lb3V0KSB7XHJcbiAgICAgICAgICAgICAgICBjbGVhclRpbWVvdXQodGhpcy5oaWRlVGltZW91dCk7XHJcbiAgICAgICAgICAgICAgICB0aGlzLnJlbW92ZSgpO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIHN1cGVyLmFjdGl2YXRlKCk7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIG9uTW91c2VMZWF2ZShlOiBFdmVudCk6IHZvaWQge1xyXG4gICAgICAgIC8vIGFkZGVkIGV4dHJhIGNvbmRpdGlvbiAhdGhpcy5faXNNb2JpbGUgdG8gaWYgc3RhdGVtZW50XHJcbiAgICAgICAgaWYgKCF0aGlzLl9pc01vYmlsZSAmJiAhdGhpcy5fZGVhY3RpdmF0ZUhvc3RMaXN0ZW5lcikge1xyXG4gICAgICAgICAgICBzdXBlci5kZWFjdGl2YXRlKCk7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIG9uQ2xpY2soZTogRXZlbnQpOiB2b2lkIHtcclxuICAgICAgICBpZiAoIXRoaXMuX2RlYWN0aXZhdGVIb3N0TGlzdGVuZXIpIHtcclxuICAgICAgICAgICAgLy8gd2hlbiBtb2JpbGUgZGV2aWNlLCBjbGljayB3aWxsIGFjdGl2YXRlIHRoZSB0b29sdGlwLiB3aGVuIHdlYiwgY2xpY2sgd2lsbCBkZWFjdGl2YXRlIHRoZSB0b29sdGlwXHJcbiAgICAgICAgICAgIGlmICghdGhpcy5faXNNb2JpbGUpIHtcclxuICAgICAgICAgICAgICAgIHN1cGVyLmRlYWN0aXZhdGUoKTtcclxuICAgICAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgICAgIGlmICh0aGlzLmhpZGVUaW1lb3V0KSB7XHJcbiAgICAgICAgICAgICAgICAgICAgY2xlYXJUaW1lb3V0KHRoaXMuaGlkZVRpbWVvdXQpO1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMucmVtb3ZlKCk7XHJcbiAgICAgICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICAgICAgc3VwZXIuYWN0aXZhdGUoKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICAvLyBjaGFuZ2VkIElucHV0IHBhcmFtIHRvICdrZC10b29sdGlwLWRpcicgKG9sZCBpbnB1dCB3YXM6IHBUb29sdGlwKVxyXG4gICAgQElucHV0KCdrZC10b29sdGlwLWRpcicpIHNldCB0ZXh0KHRleHQ6IHN0cmluZykge1xyXG4gICAgICAgIHRoaXMuX3RleHQgPSB0ZXh0O1xyXG4gICAgICAgIGlmICh0aGlzLmFjdGl2ZSkge1xyXG4gICAgICAgICAgICBpZiAodGhpcy5fdGV4dCkge1xyXG4gICAgICAgICAgICAgICAgaWYgKHRoaXMuY29udGFpbmVyICYmIHRoaXMuY29udGFpbmVyLm9mZnNldFBhcmVudCkge1xyXG4gICAgICAgICAgICAgICAgICAgIHN1cGVyLnVwZGF0ZVRleHQoKTtcclxuICAgICAgICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5zaG93KCk7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgZWxzZSB7XHJcbiAgICAgICAgICAgICAgICBzdXBlci5oaWRlKCk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgcHVibGljIHNob3coKTogdm9pZCB7XHJcbiAgICAgICAgaWYgKCF0aGlzLl90ZXh0IHx8IHRoaXMuZGlzYWJsZWQpIHtcclxuICAgICAgICAgICAgcmV0dXJuO1xyXG4gICAgICAgIH1cclxuICAgICAgICBzdXBlci5jcmVhdGUoKTtcclxuICAgICAgICB0aGlzLmFsaWduKCk7XHJcblxyXG4gICAgICAgIERvbUhhbmRsZXIuZmFkZUluKHRoaXMuY29udGFpbmVyLCAyNTApO1xyXG4gICAgICAgIGlmICh0aGlzLnRvb2x0aXBaSW5kZXggPT09ICdhdXRvJykge1xyXG4gICAgICAgICAgICB0aGlzLmNvbnRhaW5lci5zdHlsZS56SW5kZXggPSArK0RvbUhhbmRsZXIuemluZGV4O1xyXG4gICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgIHRoaXMuY29udGFpbmVyLnN0eWxlLnpJbmRleCA9IHRoaXMudG9vbHRpcFpJbmRleDtcclxuICAgICAgICB9XHJcbiAgICAgICAgaWYgKCF0aGlzLl9kZWFjdGl2YXRlSG9zdExpc3RlbmVyKSB7XHJcbiAgICAgICAgICAgIHN1cGVyLmJpbmREb2N1bWVudFJlc2l6ZUxpc3RlbmVyKCk7XHJcbiAgICAgICAgICAgIC8vIGFkZGVkIDEgbGluZS4gX2JpbmREb2N1bWVudFRvdWNoU3RhcnRMaXN0ZW5lcigpXHJcbiAgICAgICAgICAgIGlmICh0aGlzLl9pc01vYmlsZSkgdGhpcy5fYmluZERvY3VtZW50VG91Y2hTdGFydExpc3RlbmVyKCk7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIHB1YmxpYyBhbGlnbigpOiB2b2lkIHtcclxuICAgICAgICBsZXQgcG9zaXRpb246IHN0cmluZyA9IHRoaXMudG9vbHRpcFBvc2l0aW9uO1xyXG4gICAgICAgIHRoaXMuX3dpZHRoT3V0c2lkZVZpZXdwb3J0ID0gbnVsbDtcclxuXHJcbiAgICAgICAgc3dpdGNoIChwb3NpdGlvbikge1xyXG4gICAgICAgICAgICBjYXNlICd0b3AnOlxyXG4gICAgICAgICAgICAgICAgdGhpcy5hbGlnblRvcCgpO1xyXG4gICAgICAgICAgICAgICAgLy8gYWRkZWQgMSBsaW5lLiBfd2lkdGhPdXRzaWRlVmlld3BvcnRcclxuICAgICAgICAgICAgICAgIC8vIHRoaXMuX2lzT3V0b2ZCb3VuZHMgaXMgdXNlZCBpbnN0ZWFkIG9mIHN1cGVyLk91dG9mQm91bmRzXHJcbiAgICAgICAgICAgICAgICBpZiAodGhpcy5faXNPdXRPZkJvdW5kcykge1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuYWxpZ25Ub3BSaWdodCgpO1xyXG5cclxuICAgICAgICAgICAgICAgICAgICBpZiAodGhpcy5faXNPdXRPZkJvdW5kcykge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLmFsaWduVG9wTGVmdCgpO1xyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgaWYgKHRoaXMuX2lzT3V0T2ZCb3VuZHMpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuX3dpZHRoT3V0c2lkZVZpZXdwb3J0ID0gdGhpcy5fY2FsY3VsYXRlV2lkdGhPdXQoKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuYWxpZ25Cb3R0b20odGhpcy5fd2lkdGhPdXRzaWRlVmlld3BvcnQpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgYnJlYWs7XHJcblxyXG4gICAgICAgICAgICBjYXNlICd0b3AtcmlnaHQnOlxyXG4gICAgICAgICAgICAgICAgdGhpcy5hbGlnblRvcFJpZ2h0KCk7XHJcbiAgICAgICAgICAgICAgICAvLyBhZGRlZCAxIGxpbmUuIF93aWR0aE91dHNpZGVWaWV3cG9ydFxyXG4gICAgICAgICAgICAgICAgaWYgKHRoaXMuX2lzT3V0T2ZCb3VuZHMpIHtcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLmFsaWduVG9wKCk7XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIGlmICh0aGlzLl9pc091dE9mQm91bmRzKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuYWxpZ25Ub3BMZWZ0KCk7XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAodGhpcy5faXNPdXRPZkJvdW5kcykge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5fd2lkdGhPdXRzaWRlVmlld3BvcnQgPSB0aGlzLl9jYWxjdWxhdGVXaWR0aE91dCgpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5hbGlnbkJvdHRvbSh0aGlzLl93aWR0aE91dHNpZGVWaWV3cG9ydCk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICBicmVhaztcclxuXHJcbiAgICAgICAgICAgIGNhc2UgJ3RvcC1sZWZ0JzpcclxuICAgICAgICAgICAgICAgIHRoaXMuYWxpZ25Ub3BMZWZ0KCk7XHJcbiAgICAgICAgICAgICAgICAvLyBhZGRlZCAxIGxpbmUuIF93aWR0aE91dHNpZGVWaWV3cG9ydFxyXG4gICAgICAgICAgICAgICAgaWYgKHRoaXMuX2lzT3V0T2ZCb3VuZHMpIHtcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLmFsaWduVG9wKCk7XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIGlmICh0aGlzLl9pc091dE9mQm91bmRzKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuYWxpZ25Ub3BSaWdodCgpO1xyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgaWYgKHRoaXMuX2lzT3V0T2ZCb3VuZHMpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuX3dpZHRoT3V0c2lkZVZpZXdwb3J0ID0gdGhpcy5fY2FsY3VsYXRlV2lkdGhPdXQoKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuYWxpZ25Cb3R0b20odGhpcy5fd2lkdGhPdXRzaWRlVmlld3BvcnQpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgYnJlYWs7XHJcblxyXG4gICAgICAgICAgICBjYXNlICdib3R0b20nOlxyXG4gICAgICAgICAgICAgICAgdGhpcy5hbGlnbkJvdHRvbSgpO1xyXG4gICAgICAgICAgICAgICAgLy8gYWRkZWQgMSBsaW5lLiBfd2lkdGhPdXRzaWRlVmlld3BvcnRcclxuICAgICAgICAgICAgICAgIGlmICh0aGlzLl9pc091dE9mQm91bmRzKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5hbGlnbkJvdHRvbVJpZ2h0KCk7XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIGlmICh0aGlzLl9pc091dE9mQm91bmRzKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuYWxpZ25Cb3R0b21MZWZ0KCk7XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAodGhpcy5faXNPdXRPZkJvdW5kcykge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gYWRkZWQgMSBsaW5lLiBlZGl0ZWQgYWxpZ25Ub3Agd2l0aCBwYXJhbVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5fd2lkdGhPdXRzaWRlVmlld3BvcnQgPSB0aGlzLl9jYWxjdWxhdGVXaWR0aE91dCgpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5hbGlnblRvcCh0aGlzLl93aWR0aE91dHNpZGVWaWV3cG9ydCk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICBicmVhaztcclxuXHJcbiAgICAgICAgICAgIGNhc2UgJ2JvdHRvbS1yaWdodCc6XHJcbiAgICAgICAgICAgICAgICB0aGlzLmFsaWduQm90dG9tUmlnaHQoKTtcclxuICAgICAgICAgICAgICAgIC8vIGFkZGVkIDEgbGluZS4gX3dpZHRoT3V0c2lkZVZpZXdwb3J0XHJcbiAgICAgICAgICAgICAgICBpZiAodGhpcy5faXNPdXRPZkJvdW5kcykge1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuYWxpZ25Cb3R0b20oKTtcclxuXHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKHRoaXMuX2lzT3V0T2ZCb3VuZHMpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5hbGlnbkJvdHRvbUxlZnQoKTtcclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGlmICh0aGlzLl9pc091dE9mQm91bmRzKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyBhZGRlZCAxIGxpbmUuIGVkaXRlZCBhbGlnblRvcCB3aXRoIHBhcmFtXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0aGlzLl93aWR0aE91dHNpZGVWaWV3cG9ydCA9IHRoaXMuX2NhbGN1bGF0ZVdpZHRoT3V0KCk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0aGlzLmFsaWduVG9wKHRoaXMuX3dpZHRoT3V0c2lkZVZpZXdwb3J0KTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIGJyZWFrO1xyXG5cclxuICAgICAgICAgICAgY2FzZSAnYm90dG9tLWxlZnQnOlxyXG4gICAgICAgICAgICAgICAgdGhpcy5hbGlnbkJvdHRvbUxlZnQoKTtcclxuICAgICAgICAgICAgICAgIC8vIGFkZGVkIDEgbGluZS4gX3dpZHRoT3V0c2lkZVZpZXdwb3J0XHJcbiAgICAgICAgICAgICAgICBpZiAodGhpcy5faXNPdXRPZkJvdW5kcykge1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuYWxpZ25Cb3R0b20oKTtcclxuXHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKHRoaXMuX2lzT3V0T2ZCb3VuZHMpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5hbGlnbkJvdHRvbVJpZ2h0KCk7XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAodGhpcy5faXNPdXRPZkJvdW5kcykge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gYWRkZWQgMSBsaW5lLiBlZGl0ZWQgYWxpZ25Ub3Agd2l0aCBwYXJhbVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5fd2lkdGhPdXRzaWRlVmlld3BvcnQgPSB0aGlzLl9jYWxjdWxhdGVXaWR0aE91dCgpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5hbGlnblRvcCh0aGlzLl93aWR0aE91dHNpZGVWaWV3cG9ydCk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICBicmVhaztcclxuXHJcbiAgICAgICAgICAgIGNhc2UgJ2xlZnQnOlxyXG4gICAgICAgICAgICAgICAgdGhpcy5hbGlnbkxlZnQoKTtcclxuICAgICAgICAgICAgICAgIGlmICh0aGlzLl9pc091dE9mQm91bmRzKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5hbGlnblJpZ2h0KCk7XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIGlmICh0aGlzLl9pc091dE9mQm91bmRzKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuYWxpZ25Ub3AoKTtcclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGlmICh0aGlzLl9pc091dE9mQm91bmRzKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyBhZGRlZCAxIGxpbmUuIGVkaXRlZCBhbGlnbkJvdHRvbSB3aXRoIHBhcmFtXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0aGlzLl93aWR0aE91dHNpZGVWaWV3cG9ydCA9IHRoaXMuX2NhbGN1bGF0ZVdpZHRoT3V0KCk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0aGlzLmFsaWduQm90dG9tKHRoaXMuX2NhbGN1bGF0ZVdpZHRoT3V0KCkpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgYnJlYWs7XHJcblxyXG4gICAgICAgICAgICBjYXNlICdyaWdodCc6XHJcbiAgICAgICAgICAgICAgICB0aGlzLmFsaWduUmlnaHQoKTtcclxuICAgICAgICAgICAgICAgIGlmICh0aGlzLl9pc091dE9mQm91bmRzKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5hbGlnbkxlZnQoKTtcclxuXHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKHRoaXMuX2lzT3V0T2ZCb3VuZHMpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5hbGlnblRvcCgpO1xyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgaWYgKHRoaXMuX2lzT3V0T2ZCb3VuZHMpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIGFkZGVkIDEgbGluZS4gZWRpdGVkIGFsaWduQm90dG9tIHdpdGggcGFyYW1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuYWxpZ25Cb3R0b20odGhpcy5fY2FsY3VsYXRlV2lkdGhPdXQoKSk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICBicmVhaztcclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgcHVibGljIGFsaWduUmlnaHQoKSB7XHJcbiAgICAgICAgLy8gYWRkZWQgMSBsaW5lLiBlZGl0ZWQgcHJlQWxpZ24gd2l0aCBwYXJhbVxyXG4gICAgICAgIHRoaXMucHJlQWxpZ24oJ3JpZ2h0Jyk7XHJcbiAgICAgICAgbGV0IGhvc3RPZmZzZXQ6IHsgbGVmdDogbnVtYmVyLCB0b3A6IG51bWJlciB9ID0gc3VwZXIuZ2V0SG9zdE9mZnNldCgpO1xyXG4gICAgICAgIGxldCB3aWR0aDogbnVtYmVyID0gRG9tSGFuZGxlci5nZXRPdXRlcldpZHRoKHRoaXMuY29udGFpbmVyKTtcclxuICAgICAgICBsZXQgaGVpZ2h0OiBudW1iZXIgPSBEb21IYW5kbGVyLmdldE91dGVySGVpZ2h0KHRoaXMuY29udGFpbmVyKTtcclxuICAgICAgICBsZXQgbGVmdDogbnVtYmVyID0gaG9zdE9mZnNldC5sZWZ0ICsgRG9tSGFuZGxlci5nZXRPdXRlcldpZHRoKHRoaXMuX2VsLm5hdGl2ZUVsZW1lbnQpICsgdGhpcy5fb2Zmc2V0Lng7XHJcbiAgICAgICAgbGV0IHRvcDogbnVtYmVyID0gaG9zdE9mZnNldC50b3AgKyAoRG9tSGFuZGxlci5nZXRPdXRlckhlaWdodCh0aGlzLl9lbC5uYXRpdmVFbGVtZW50KSAtIERvbUhhbmRsZXIuZ2V0T3V0ZXJIZWlnaHQodGhpcy5jb250YWluZXIpKSAvIDIgLSAxICsgdGhpcy5fb2Zmc2V0Lnk7XHJcblxyXG4gICAgICAgIHRoaXMuX2lzT3V0T2ZCb3VuZHMgPSB0aGlzLl9jaGVja091dE9mQm91bmRzKGxlZnQsIHRvcCwgd2lkdGgsIGhlaWdodCk7XHJcbiAgICAgICAgdGhpcy5jb250YWluZXIuc3R5bGUubGVmdCA9IGxlZnQgKyAncHgnO1xyXG4gICAgICAgIHRoaXMuY29udGFpbmVyLnN0eWxlLnRvcCA9IHRvcCArICdweCc7XHJcbiAgICB9XHJcblxyXG4gICAgcHVibGljIGFsaWduTGVmdCgpIHtcclxuICAgICAgICAvLyBhZGRlZCAxIGxpbmUuIGVkaXRlZCBwcmVBbGlnbiB3aXRoIHBhcmFtXHJcbiAgICAgICAgdGhpcy5wcmVBbGlnbignbGVmdCcpO1xyXG4gICAgICAgIGxldCBob3N0T2Zmc2V0OiB7IGxlZnQ6IG51bWJlciwgdG9wOiBudW1iZXIgfSA9IHN1cGVyLmdldEhvc3RPZmZzZXQoKTtcclxuICAgICAgICBsZXQgd2lkdGg6IG51bWJlciA9IERvbUhhbmRsZXIuZ2V0T3V0ZXJXaWR0aCh0aGlzLmNvbnRhaW5lcik7XHJcbiAgICAgICAgbGV0IGhlaWdodDogbnVtYmVyID0gRG9tSGFuZGxlci5nZXRPdXRlckhlaWdodCh0aGlzLmNvbnRhaW5lcik7XHJcbiAgICAgICAgbGV0IGxlZnQ6IG51bWJlciA9IGhvc3RPZmZzZXQubGVmdCAtIERvbUhhbmRsZXIuZ2V0T3V0ZXJXaWR0aCh0aGlzLmNvbnRhaW5lcikgKyB0aGlzLl9vZmZzZXQueDtcclxuICAgICAgICBsZXQgdG9wOiBudW1iZXIgPSBob3N0T2Zmc2V0LnRvcCArIChEb21IYW5kbGVyLmdldE91dGVySGVpZ2h0KHRoaXMuX2VsLm5hdGl2ZUVsZW1lbnQpIC0gRG9tSGFuZGxlci5nZXRPdXRlckhlaWdodCh0aGlzLmNvbnRhaW5lcikpIC8gMiArIHRoaXMuX29mZnNldC55O1xyXG5cclxuICAgICAgICB0aGlzLl9pc091dE9mQm91bmRzID0gdGhpcy5fY2hlY2tPdXRPZkJvdW5kcyhsZWZ0LCB0b3AsIHdpZHRoLCBoZWlnaHQpO1xyXG4gICAgICAgIHRoaXMuY29udGFpbmVyLnN0eWxlLmxlZnQgPSBsZWZ0ICsgJ3B4JztcclxuICAgICAgICB0aGlzLmNvbnRhaW5lci5zdHlsZS50b3AgPSB0b3AgKyAncHgnO1xyXG4gICAgfVxyXG5cclxuICAgIHB1YmxpYyBhbGlnblRvcCh3aWR0aE91dD86IG51bWJlcik6IHZvaWQge1xyXG4gICAgICAgIC8vIGFkZGVkIDIgbGluZS4gZWRpdGVkIHByZUFsaWduIHdpdGggcGFyYW0gYW5kIHdpZHRoT3V0XHJcbiAgICAgICAgdGhpcy5wcmVBbGlnbigndG9wJyk7XHJcbiAgICAgICAgaWYgKHdpZHRoT3V0ICE9PSAwICYmIHR5cGVvZiB3aWR0aE91dCAhPT0gJ3VuZGVmaW5lZCcpIHtcclxuICAgICAgICAgICAgdGhpcy5jb250YWluZXIuc3R5bGUubWF4V2lkdGggPSAoRG9tSGFuZGxlci5nZXRPdXRlcldpZHRoKHRoaXMuY29udGFpbmVyKSAtIHdpZHRoT3V0ICogMikudG9TdHJpbmcoKSArICdweCc7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGxldCBob3N0T2Zmc2V0OiB7IGxlZnQ6IG51bWJlciwgdG9wOiBudW1iZXIgfSA9IHN1cGVyLmdldEhvc3RPZmZzZXQoKTtcclxuICAgICAgICBsZXQgd2lkdGg6IG51bWJlciA9IERvbUhhbmRsZXIuZ2V0T3V0ZXJXaWR0aCh0aGlzLmNvbnRhaW5lcik7XHJcbiAgICAgICAgbGV0IGhlaWdodDogbnVtYmVyID0gRG9tSGFuZGxlci5nZXRPdXRlckhlaWdodCh0aGlzLmNvbnRhaW5lcik7XHJcbiAgICAgICAgbGV0IGxlZnQ6IG51bWJlciA9IGhvc3RPZmZzZXQubGVmdCArIChEb21IYW5kbGVyLmdldE91dGVyV2lkdGgodGhpcy5fZWwubmF0aXZlRWxlbWVudCkgLSBEb21IYW5kbGVyLmdldE91dGVyV2lkdGgodGhpcy5jb250YWluZXIpKSAvIDIgKyB0aGlzLl9vZmZzZXQueDtcclxuICAgICAgICBsZXQgdG9wOiBudW1iZXIgPSBob3N0T2Zmc2V0LnRvcCAtIERvbUhhbmRsZXIuZ2V0T3V0ZXJIZWlnaHQodGhpcy5jb250YWluZXIpICsgdGhpcy5fb2Zmc2V0Lnk7XHJcblxyXG4gICAgICAgIHRoaXMuX2lzT3V0T2ZCb3VuZHMgPSB0aGlzLl9jaGVja091dE9mQm91bmRzKGxlZnQsIHRvcCwgd2lkdGgsIGhlaWdodCk7XHJcbiAgICAgICAgdGhpcy5jb250YWluZXIuc3R5bGUubGVmdCA9IGxlZnQgKyAncHgnO1xyXG4gICAgICAgIHRoaXMuY29udGFpbmVyLnN0eWxlLnRvcCA9IHRvcCArICdweCc7XHJcbiAgICB9XHJcblxyXG4gICAgLy8gbmV3IGRpcmVjdGlvblxyXG4gICAgcHVibGljIGFsaWduVG9wUmlnaHQod2lkdGhPdXQ/OiBudW1iZXIpOiB2b2lkIHtcclxuICAgICAgICB0aGlzLnByZUFsaWduKCd0b3AgdWktdG9vbHRpcC10b3AtcmlnaHQnKTtcclxuICAgICAgICBpZiAod2lkdGhPdXQgIT09IDAgJiYgdHlwZW9mIHdpZHRoT3V0ICE9PSAndW5kZWZpbmVkJykgdGhpcy5jb250YWluZXIuc3R5bGUubWF4V2lkdGggPSAoRG9tSGFuZGxlci5nZXRPdXRlcldpZHRoKHRoaXMuY29udGFpbmVyKSAtIHdpZHRoT3V0ICogMikudG9TdHJpbmcoKSArICdweCc7XHJcblxyXG4gICAgICAgIGxldCBob3N0T2Zmc2V0OiB7IGxlZnQ6IG51bWJlciwgdG9wOiBudW1iZXIgfSA9IHN1cGVyLmdldEhvc3RPZmZzZXQoKTtcclxuICAgICAgICBsZXQgd2lkdGg6IG51bWJlciA9IERvbUhhbmRsZXIuZ2V0T3V0ZXJXaWR0aCh0aGlzLmNvbnRhaW5lcik7XHJcbiAgICAgICAgbGV0IGhlaWdodDogbnVtYmVyID0gRG9tSGFuZGxlci5nZXRPdXRlckhlaWdodCh0aGlzLmNvbnRhaW5lcik7XHJcbiAgICAgICAgbGV0IGxlZnQ6IG51bWJlciA9IGhvc3RPZmZzZXQubGVmdCArIERvbUhhbmRsZXIuZ2V0T3V0ZXJXaWR0aCh0aGlzLl9lbC5uYXRpdmVFbGVtZW50KSAvIDIgLSB0aGlzLl9kZWZhdWx0T2Zmc2V0ICsgdGhpcy5fb2Zmc2V0Lng7XHJcbiAgICAgICAgbGV0IHRvcDogbnVtYmVyID0gaG9zdE9mZnNldC50b3AgLSBEb21IYW5kbGVyLmdldE91dGVySGVpZ2h0KHRoaXMuY29udGFpbmVyKSArIHRoaXMuX29mZnNldC55O1xyXG5cclxuICAgICAgICB0aGlzLl9pc091dE9mQm91bmRzID0gdGhpcy5fY2hlY2tPdXRPZkJvdW5kcyhsZWZ0LCB0b3AsIHdpZHRoLCBoZWlnaHQpO1xyXG4gICAgICAgIHRoaXMuY29udGFpbmVyLnN0eWxlLmxlZnQgPSBsZWZ0ICsgJ3B4JztcclxuICAgICAgICB0aGlzLmNvbnRhaW5lci5zdHlsZS50b3AgPSB0b3AgKyAncHgnO1xyXG4gICAgfVxyXG5cclxuICAgIC8vIG5ldyBkaXJlY3Rpb25cclxuICAgIHB1YmxpYyBhbGlnblRvcExlZnQod2lkdGhPdXQ/OiBudW1iZXIpOiB2b2lkIHtcclxuICAgICAgICB0aGlzLnByZUFsaWduKCd0b3AgdWktdG9vbHRpcC10b3AtbGVmdCcpO1xyXG4gICAgICAgIGlmICh3aWR0aE91dCAhPT0gMCAmJiB0eXBlb2Ygd2lkdGhPdXQgIT09ICd1bmRlZmluZWQnKSB0aGlzLmNvbnRhaW5lci5zdHlsZS5tYXhXaWR0aCA9IChEb21IYW5kbGVyLmdldE91dGVyV2lkdGgodGhpcy5jb250YWluZXIpIC0gd2lkdGhPdXQgKiAyKS50b1N0cmluZygpICsgJ3B4JztcclxuXHJcbiAgICAgICAgbGV0IGhvc3RPZmZzZXQ6IHsgbGVmdDogbnVtYmVyLCB0b3A6IG51bWJlciB9ID0gc3VwZXIuZ2V0SG9zdE9mZnNldCgpO1xyXG4gICAgICAgIGxldCB3aWR0aDogbnVtYmVyID0gRG9tSGFuZGxlci5nZXRPdXRlcldpZHRoKHRoaXMuY29udGFpbmVyKTtcclxuICAgICAgICBsZXQgaGVpZ2h0OiBudW1iZXIgPSBEb21IYW5kbGVyLmdldE91dGVySGVpZ2h0KHRoaXMuY29udGFpbmVyKTtcclxuICAgICAgICBsZXQgbGVmdDogbnVtYmVyID0gaG9zdE9mZnNldC5sZWZ0ICsgRG9tSGFuZGxlci5nZXRPdXRlcldpZHRoKHRoaXMuX2VsLm5hdGl2ZUVsZW1lbnQpIC8gMiAtIERvbUhhbmRsZXIuZ2V0T3V0ZXJXaWR0aCh0aGlzLmNvbnRhaW5lcikgKyB0aGlzLl9kZWZhdWx0T2Zmc2V0ICsgdGhpcy5fb2Zmc2V0Lng7XHJcbiAgICAgICAgbGV0IHRvcDogbnVtYmVyID0gaG9zdE9mZnNldC50b3AgLSBEb21IYW5kbGVyLmdldE91dGVySGVpZ2h0KHRoaXMuY29udGFpbmVyKSArIHRoaXMuX29mZnNldC55O1xyXG5cclxuICAgICAgICB0aGlzLl9pc091dE9mQm91bmRzID0gdGhpcy5fY2hlY2tPdXRPZkJvdW5kcyhsZWZ0LCB0b3AsIHdpZHRoLCBoZWlnaHQpO1xyXG4gICAgICAgIHRoaXMuY29udGFpbmVyLnN0eWxlLmxlZnQgPSBsZWZ0ICsgJ3B4JztcclxuICAgICAgICB0aGlzLmNvbnRhaW5lci5zdHlsZS50b3AgPSB0b3AgKyAncHgnO1xyXG4gICAgfVxyXG5cclxuXHJcbiAgICBwdWJsaWMgYWxpZ25Cb3R0b20od2lkdGhPdXQ/OiBudW1iZXIpOiB2b2lkIHtcclxuICAgICAgICAvLyBhZGRlZCAyIGxpbmUuIGVkaXRlZCBwcmVBbGlnbiB3aXRoIHBhcmFtIGFuZCB3aWR0aE91dFxyXG4gICAgICAgIHRoaXMucHJlQWxpZ24oJ2JvdHRvbScpO1xyXG4gICAgICAgIGlmICh3aWR0aE91dCAhPT0gMCAmJiB0eXBlb2Ygd2lkdGhPdXQgIT09ICd1bmRlZmluZWQnKSB0aGlzLmNvbnRhaW5lci5zdHlsZS5tYXhXaWR0aCA9IChEb21IYW5kbGVyLmdldE91dGVyV2lkdGgodGhpcy5jb250YWluZXIpIC0gd2lkdGhPdXQgKiAyKS50b1N0cmluZygpICsgJ3B4JztcclxuXHJcbiAgICAgICAgbGV0IGhvc3RPZmZzZXQ6IHsgbGVmdDogbnVtYmVyLCB0b3A6IG51bWJlciB9ID0gc3VwZXIuZ2V0SG9zdE9mZnNldCgpO1xyXG4gICAgICAgIGxldCB3aWR0aDogbnVtYmVyID0gRG9tSGFuZGxlci5nZXRPdXRlcldpZHRoKHRoaXMuY29udGFpbmVyKTtcclxuICAgICAgICBsZXQgaGVpZ2h0OiBudW1iZXIgPSBEb21IYW5kbGVyLmdldE91dGVySGVpZ2h0KHRoaXMuY29udGFpbmVyKTtcclxuICAgICAgICBsZXQgbGVmdDogbnVtYmVyID0gaG9zdE9mZnNldC5sZWZ0ICsgKERvbUhhbmRsZXIuZ2V0T3V0ZXJXaWR0aCh0aGlzLl9lbC5uYXRpdmVFbGVtZW50KSAtIERvbUhhbmRsZXIuZ2V0T3V0ZXJXaWR0aCh0aGlzLmNvbnRhaW5lcikpIC8gMiArIHRoaXMuX29mZnNldC54O1xyXG4gICAgICAgIGxldCB0b3A6IG51bWJlciA9IGhvc3RPZmZzZXQudG9wICsgRG9tSGFuZGxlci5nZXRPdXRlckhlaWdodCh0aGlzLl9lbC5uYXRpdmVFbGVtZW50KSArIHRoaXMuX29mZnNldC55O1xyXG5cclxuICAgICAgICB0aGlzLl9pc091dE9mQm91bmRzID0gdGhpcy5fY2hlY2tPdXRPZkJvdW5kcyhsZWZ0LCB0b3AsIHdpZHRoLCBoZWlnaHQpO1xyXG4gICAgICAgIHRoaXMuY29udGFpbmVyLnN0eWxlLmxlZnQgPSBsZWZ0ICsgJ3B4JztcclxuICAgICAgICB0aGlzLmNvbnRhaW5lci5zdHlsZS50b3AgPSB0b3AgKyAncHgnO1xyXG4gICAgfVxyXG5cclxuICAgIC8vIG5ldyBkaXJlY3Rpb25cclxuICAgIHB1YmxpYyBhbGlnbkJvdHRvbVJpZ2h0KHdpZHRoT3V0PzogbnVtYmVyKTogdm9pZCB7XHJcbiAgICAgICAgdGhpcy5wcmVBbGlnbignYm90dG9tIHVpLXRvb2x0aXAtYm90dG9tLXJpZ2h0Jyk7XHJcbiAgICAgICAgaWYgKHdpZHRoT3V0ICE9PSAwICYmIHR5cGVvZiB3aWR0aE91dCAhPT0gJ3VuZGVmaW5lZCcpIHRoaXMuY29udGFpbmVyLnN0eWxlLm1heFdpZHRoID0gKERvbUhhbmRsZXIuZ2V0T3V0ZXJXaWR0aCh0aGlzLmNvbnRhaW5lcikgLSB3aWR0aE91dCAqIDIpLnRvU3RyaW5nKCkgKyAncHgnO1xyXG5cclxuICAgICAgICBsZXQgaG9zdE9mZnNldDogeyBsZWZ0OiBudW1iZXIsIHRvcDogbnVtYmVyIH0gPSBzdXBlci5nZXRIb3N0T2Zmc2V0KCk7XHJcbiAgICAgICAgbGV0IHdpZHRoOiBudW1iZXIgPSBEb21IYW5kbGVyLmdldE91dGVyV2lkdGgodGhpcy5jb250YWluZXIpO1xyXG4gICAgICAgIGxldCBoZWlnaHQ6IG51bWJlciA9IERvbUhhbmRsZXIuZ2V0T3V0ZXJIZWlnaHQodGhpcy5jb250YWluZXIpO1xyXG4gICAgICAgIGxldCBsZWZ0OiBudW1iZXIgPSBob3N0T2Zmc2V0LmxlZnQgKyBEb21IYW5kbGVyLmdldE91dGVyV2lkdGgodGhpcy5fZWwubmF0aXZlRWxlbWVudCkgLyAyIC0gdGhpcy5fZGVmYXVsdE9mZnNldCArIHRoaXMuX29mZnNldC54O1xyXG4gICAgICAgIGxldCB0b3A6IG51bWJlciA9IGhvc3RPZmZzZXQudG9wICsgRG9tSGFuZGxlci5nZXRPdXRlckhlaWdodCh0aGlzLl9lbC5uYXRpdmVFbGVtZW50KSArIHRoaXMuX29mZnNldC55O1xyXG5cclxuICAgICAgICB0aGlzLl9pc091dE9mQm91bmRzID0gdGhpcy5fY2hlY2tPdXRPZkJvdW5kcyhsZWZ0LCB0b3AsIHdpZHRoLCBoZWlnaHQpO1xyXG4gICAgICAgIHRoaXMuY29udGFpbmVyLnN0eWxlLmxlZnQgPSBsZWZ0ICsgJ3B4JztcclxuICAgICAgICB0aGlzLmNvbnRhaW5lci5zdHlsZS50b3AgPSB0b3AgKyAncHgnO1xyXG4gICAgfVxyXG5cclxuICAgIC8vIG5ldyBkaXJlY3Rpb25cclxuICAgIHB1YmxpYyBhbGlnbkJvdHRvbUxlZnQod2lkdGhPdXQ/OiBudW1iZXIpOiB2b2lkIHtcclxuICAgICAgICB0aGlzLnByZUFsaWduKCdib3R0b20gdWktdG9vbHRpcC1ib3R0b20tbGVmdCcpO1xyXG4gICAgICAgIGlmICh3aWR0aE91dCAhPT0gMCAmJiB0eXBlb2Ygd2lkdGhPdXQgIT09ICd1bmRlZmluZWQnKSB0aGlzLmNvbnRhaW5lci5zdHlsZS5tYXhXaWR0aCA9IChEb21IYW5kbGVyLmdldE91dGVyV2lkdGgodGhpcy5jb250YWluZXIpIC0gd2lkdGhPdXQgKiAyKS50b1N0cmluZygpICsgJ3B4JztcclxuXHJcbiAgICAgICAgbGV0IGhvc3RPZmZzZXQ6IHsgbGVmdDogbnVtYmVyLCB0b3A6IG51bWJlciB9ID0gc3VwZXIuZ2V0SG9zdE9mZnNldCgpO1xyXG4gICAgICAgIGxldCB3aWR0aDogbnVtYmVyID0gRG9tSGFuZGxlci5nZXRPdXRlcldpZHRoKHRoaXMuY29udGFpbmVyKTtcclxuICAgICAgICBsZXQgaGVpZ2h0OiBudW1iZXIgPSBEb21IYW5kbGVyLmdldE91dGVySGVpZ2h0KHRoaXMuY29udGFpbmVyKTtcclxuICAgICAgICBsZXQgbGVmdDogbnVtYmVyID0gaG9zdE9mZnNldC5sZWZ0ICsgRG9tSGFuZGxlci5nZXRPdXRlcldpZHRoKHRoaXMuX2VsLm5hdGl2ZUVsZW1lbnQpIC8gMiAtIERvbUhhbmRsZXIuZ2V0T3V0ZXJXaWR0aCh0aGlzLmNvbnRhaW5lcikgKyB0aGlzLl9kZWZhdWx0T2Zmc2V0ICsgdGhpcy5fb2Zmc2V0Lng7XHJcbiAgICAgICAgbGV0IHRvcDogbnVtYmVyID0gaG9zdE9mZnNldC50b3AgKyBEb21IYW5kbGVyLmdldE91dGVySGVpZ2h0KHRoaXMuX2VsLm5hdGl2ZUVsZW1lbnQpICsgdGhpcy5fb2Zmc2V0Lnk7XHJcblxyXG4gICAgICAgIHRoaXMuX2lzT3V0T2ZCb3VuZHMgPSB0aGlzLl9jaGVja091dE9mQm91bmRzKGxlZnQsIHRvcCwgd2lkdGgsIGhlaWdodCk7XHJcbiAgICAgICAgdGhpcy5jb250YWluZXIuc3R5bGUubGVmdCA9IGxlZnQgKyAncHgnO1xyXG4gICAgICAgIHRoaXMuY29udGFpbmVyLnN0eWxlLnRvcCA9IHRvcCArICdweCc7XHJcbiAgICB9XHJcblxyXG4gICAgcHVibGljIHByZUFsaWduKF9wb3NpdGlvbj86IHN0cmluZyk6IHZvaWQge1xyXG4gICAgICAgIHRoaXMuY29udGFpbmVyLnN0eWxlLmxlZnQgPSAtOTk5ICsgJ3B4JztcclxuICAgICAgICB0aGlzLmNvbnRhaW5lci5zdHlsZS50b3AgPSAtOTk5ICsgJ3B4JztcclxuXHJcbiAgICAgICAgLy8gYWRkZWQgMiBsaW5lLiBkZWZhdWx0Q2xhc3NOYW1lIGFuZCBjb250YWluZXIuY2xhc3NOYW1lXHJcbiAgICAgICAgbGV0IGRlZmF1bHRDbGFzc05hbWU6IHN0cmluZyA9ICd1aS10b29sdGlwIHVpLXdpZGdldCB1aS10b29sdGlwLScgKyBfcG9zaXRpb247XHJcbiAgICAgICAgdGhpcy5jb250YWluZXIuY2xhc3NOYW1lID0gdGhpcy50b29sdGlwU3R5bGVDbGFzcyA/IGRlZmF1bHRDbGFzc05hbWUgKyAnICcgKyB0aGlzLnRvb2x0aXBTdHlsZUNsYXNzIDogZGVmYXVsdENsYXNzTmFtZTtcclxuICAgIH1cclxuXHJcbiAgICAvLyB0ZW1wIGZpeDogY2hlY2tpbmcgb3V0IG9mIGJvdW5kcyBzaG91bGQgaGFwcGVuIGJlZm9yZSB3b3Jkd3JhcCBjaGFuZ2VzIHRoZSBzaXplIG9uIHRvb2x0aXBcclxuICAgIHByaXZhdGUgX2NoZWNrT3V0T2ZCb3VuZHMoX2xlZnQ6IG51bWJlciwgX3RvcDogbnVtYmVyLCBfd2lkdGg6IG51bWJlciwgX2hlaWdodDogbnVtYmVyKSB7XHJcbiAgICAgICAgbGV0IHZpZXdwb3J0ID0gRG9tSGFuZGxlci5nZXRWaWV3cG9ydCgpO1xyXG4gICAgICAgIHJldHVybiAoX2xlZnQgKyBfd2lkdGggPiB2aWV3cG9ydC53aWR0aCkgfHwgKF9sZWZ0IDwgMCkgfHwgKF90b3AgPCAwKSB8fCAoX3RvcCArIF9oZWlnaHQgPiB2aWV3cG9ydC5oZWlnaHQpO1xyXG4gICAgfVxyXG5cclxuICAgIHB1YmxpYyByZW1vdmUoKTogdm9pZCB7XHJcbiAgICAgICAgaWYgKCF0aGlzLl9kZWFjdGl2YXRlSG9zdExpc3RlbmVyKSB7XHJcbiAgICAgICAgICAgIC8vIGFkZGVkIG9uZSBsaW5lLCBfdW5iaW5kRG9jdW1lbnRUb3VjaFN0YXJ0TGlzdG5lcigpXHJcbiAgICAgICAgICAgIGlmICh0aGlzLl9pc01vYmlsZSkgdGhpcy5fdW5iaW5kRG9jdW1lbnRUb3VjaFN0YXJ0TGlzdG5lcigpO1xyXG4gICAgICAgIH1cclxuICAgICAgICBpZiAodGhpcy5jb250YWluZXIgJiYgdGhpcy5jb250YWluZXIucGFyZW50RWxlbWVudCkge1xyXG4gICAgICAgICAgICBpZiAodGhpcy5hcHBlbmRUbyA9PT0gJ2JvZHknKSB7XHJcbiAgICAgICAgICAgICAgICBkb2N1bWVudC5ib2R5LnJlbW92ZUNoaWxkKHRoaXMuY29udGFpbmVyKTtcclxuICAgICAgICAgICAgfSBlbHNlIGlmICh0aGlzLmFwcGVuZFRvID09PSAndGFyZ2V0Jykge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5fZWwubmF0aXZlRWxlbWVudC5yZW1vdmVDaGlsZCh0aGlzLmNvbnRhaW5lcik7XHJcbiAgICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgICAgICBEb21IYW5kbGVyLnJlbW92ZUNoaWxkKHRoaXMuY29udGFpbmVyLCB0aGlzLmFwcGVuZFRvKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgICAgICB0aGlzLmNvbnRhaW5lciA9IG51bGw7XHJcbiAgICB9XHJcblxyXG4gICAgLyoqKioqKioqTmV3IEZ1bmN0aW9ucyoqKioqKioqKioqL1xyXG4gICAgcHJpdmF0ZSBfaW5pdEFwaSgpOiB2b2lkIHtcclxuICAgICAgICBpZiAodHlwZW9mIHRoaXMuYXBpICE9PSAndW5kZWZpbmVkJykge1xyXG4gICAgICAgICAgICB0aGlzLmFwaS5zaG93VG9vbHRpcCA9ICgpOiB2b2lkID0+IHN1cGVyLmFjdGl2YXRlKCk7XHJcbiAgICAgICAgICAgIHRoaXMuYXBpLmhpZGVUb29sdGlwID0gKCk6IHZvaWQgPT4gc3VwZXIuZGVhY3RpdmF0ZSgpO1xyXG4gICAgICAgICAgICB0aGlzLmFwaS5kZWFjdGl2YXRlSG9zdExpc3RlbmVyID0gKCk6IHZvaWQgPT4geyB0aGlzLl9kZWFjdGl2YXRlSG9zdExpc3RlbmVyID0gdHJ1ZTsgfTtcclxuICAgICAgICAgICAgdGhpcy5hcGkuYWN0aXZhdGVIb3N0TGlzdGVuZXIgPSAoKTogdm9pZCA9PiB7IHRoaXMuX2RlYWN0aXZhdGVIb3N0TGlzdGVuZXIgPSBmYWxzZTsgfTtcclxuICAgICAgICAgICAgdGhpcy5hcGkuYWxpZ24gPSAoKTogdm9pZCA9PiB7XHJcbiAgICAgICAgICAgICAgICBpZiAoIXRoaXMuY29udGFpbmVyKSByZXR1cm47XHJcbiAgICAgICAgICAgICAgICB0aGlzLmFsaWduKCk7XHJcbiAgICAgICAgICAgIH07XHJcbiAgICAgICAgICAgIHRoaXMuYXBpLnNldE9mZnNldCA9IChfb2Zmc2V0OiB7IHg6IG51bWJlciwgeTogbnVtYmVyIH0pOiB2b2lkID0+IHsgdGhpcy5fb2Zmc2V0ID0gX29mZnNldDsgfTtcclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfY2FsY3VsYXRlV2lkdGhPdXQoKTogbnVtYmVyIHtcclxuICAgICAgICBsZXQgb2Zmc2V0OiBDbGllbnRSZWN0ID0gdGhpcy5jb250YWluZXIuZ2V0Qm91bmRpbmdDbGllbnRSZWN0KCk7XHJcbiAgICAgICAgbGV0IHRhcmdldExlZnQ6IG51bWJlciA9IG9mZnNldC5sZWZ0O1xyXG4gICAgICAgIGxldCB3aWR0aDogbnVtYmVyID0gRG9tSGFuZGxlci5nZXRPdXRlcldpZHRoKHRoaXMuY29udGFpbmVyKTtcclxuICAgICAgICBsZXQgdmlld3BvcnQ6IGFueSA9IERvbUhhbmRsZXIuZ2V0Vmlld3BvcnQoKTtcclxuXHJcbiAgICAgICAgaWYgKHRhcmdldExlZnQgKyB3aWR0aCAtIHZpZXdwb3J0LndpZHRoID4gMCkgcmV0dXJuIHRhcmdldExlZnQgKyB3aWR0aCAtIHZpZXdwb3J0LndpZHRoO1xyXG4gICAgICAgIGlmICh0YXJnZXRMZWZ0IDwgMCkgcmV0dXJuIHRhcmdldExlZnQgKiAtMTtcclxuXHJcbiAgICAgICAgcmV0dXJuIDA7XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfYmluZERvY3VtZW50VG91Y2hTdGFydExpc3RlbmVyKCk6IHZvaWQge1xyXG4gICAgICAgIHRoaXMuX2RvY3VtZW50VG91Y2hTdGFydExpc3RlbmVyID0gdGhpcy5fcmVuZGVyZXIubGlzdGVuKFxyXG4gICAgICAgICAgICAnZG9jdW1lbnQnLFxyXG4gICAgICAgICAgICAndG91Y2hzdGFydCcsXHJcbiAgICAgICAgICAgIGV2ZW50ID0+IHtcclxuICAgICAgICAgICAgICAgIHN1cGVyLmhpZGUoKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICk7XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfdW5iaW5kRG9jdW1lbnRUb3VjaFN0YXJ0TGlzdG5lcigpOiB2b2lkIHtcclxuICAgICAgICBpZiAodGhpcy5fZG9jdW1lbnRUb3VjaFN0YXJ0TGlzdGVuZXIpIHtcclxuICAgICAgICAgICAgdGhpcy5fZG9jdW1lbnRUb3VjaFN0YXJ0TGlzdGVuZXIoKTtcclxuICAgICAgICAgICAgdGhpcy5fZG9jdW1lbnRUb3VjaFN0YXJ0TGlzdGVuZXIgPSBudWxsO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICBuZ09uRGVzdHJveSgpOiB2b2lkIHtcclxuICAgICAgICAvLyBzdXBlci51bmJpbmRFdmVudHMoKTtcclxuICAgICAgICB0aGlzLnJlbW92ZSgpO1xyXG4gICAgICAgIC8vIGFkZGVkIDIgbGluZS4gdW5zdWJzY3JpcHRpb25cclxuICAgICAgICB0aGlzLl9kcmFnTWVudVN1Yi51bnN1YnNjcmliZSgpO1xyXG4gICAgICAgIHRoaXMuX3RvZ2dsZU1lbnVTdWIudW5zdWJzY3JpYmUoKTtcclxuICAgIH1cclxufVxyXG4iXX0=