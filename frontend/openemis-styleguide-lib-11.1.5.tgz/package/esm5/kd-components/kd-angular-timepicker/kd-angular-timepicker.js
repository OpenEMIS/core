import { __decorate, __metadata } from "tslib";
import { Component, ViewEncapsulation, Input, Output, EventEmitter } from '@angular/core';
import { NgbTimepickerConfig } from '@ng-bootstrap/ng-bootstrap';
var KdTimepicker = /** @class */ (function () {
    function KdTimepicker() {
        this._defaultConfig = new NgbTimepickerConfig();
        this.timeConfig = new EventEmitter();
    }
    KdTimepicker.prototype.ngOnInit = function () {
        if (typeof this.inputVal !== 'undefined')
            this.newVal = this.inputVal;
        this.timepickerConfig();
    };
    KdTimepicker.prototype.timepickerConfig = function () {
        for (var i in this.config) {
            if (this.config.hasOwnProperty(i)) {
                this._defaultConfig[i] = this.config[i];
            }
        }
    };
    KdTimepicker.prototype.emitValue = function () {
        this.timeConfig.emit(this.newVal);
    };
    __decorate([
        Input(),
        __metadata("design:type", Object)
    ], KdTimepicker.prototype, "config", void 0);
    __decorate([
        Input(),
        __metadata("design:type", Object)
    ], KdTimepicker.prototype, "inputVal", void 0);
    __decorate([
        Output(),
        __metadata("design:type", EventEmitter)
    ], KdTimepicker.prototype, "timeConfig", void 0);
    KdTimepicker = __decorate([
        Component({
            selector: 'kd-timepicker',
            template: "<div class=\"kdx-timepicker-wrapper\">\r\n\t<ngb-timepicker\r\n\t\t[(ngModel)]=\"newVal\"\r\n\t\t(ngModelChange)=\"emitValue()\"\r\n\t\t[disabled]=\"_defaultConfig.disabled\"\r\n\t\t[hourStep]=\"_defaultConfig.hourStep\"\r\n\t\t[meridian]=\"_defaultConfig.meridian\"\r\n\t\t[minuteStep]=\"_defaultConfig.minuteStep\"\r\n\t\t[readonlyInputs]=\"_defaultConfig.readonlyInputs\"\r\n\t\t[secondStep]=\"_defaultConfig.secondStep\"\r\n\t\t[seconds]=\"_defaultConfig.seconds\"\r\n\t\t[spinners]=\"_defaultConfig.spinners\"\r\n\t></ngb-timepicker>\r\n\t<ng-content></ng-content>\r\n</div>\r\n\r\n",
            encapsulation: ViewEncapsulation.None,
            host: { 'class': 'kdx kdx-timepicker' }
        })
    ], KdTimepicker);
    return KdTimepicker;
}());
export { KdTimepicker };
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoia2QtYW5ndWxhci10aW1lcGlja2VyLmpzIiwic291cmNlUm9vdCI6Im5nOi8vb3BlbmVtaXMtc3R5bGVndWlkZS1saWIvIiwic291cmNlcyI6WyJrZC1jb21wb25lbnRzL2tkLWFuZ3VsYXItdGltZXBpY2tlci9rZC1hbmd1bGFyLXRpbWVwaWNrZXIudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IjtBQUFBLE9BQU8sRUFDSCxTQUFTLEVBQ1QsaUJBQWlCLEVBQ2pCLEtBQUssRUFDTCxNQUFNLEVBQ04sWUFBWSxFQUVmLE1BQU0sZUFBZSxDQUFDO0FBQ3ZCLE9BQU8sRUFBRSxtQkFBbUIsRUFBRSxNQUFNLDRCQUE0QixDQUFDO0FBU2pFO0lBQUE7UUFFVyxtQkFBYyxHQUF3QixJQUFJLG1CQUFtQixFQUFFLENBQUM7UUFJN0QsZUFBVSxHQUFxQixJQUFJLFlBQVksRUFBRSxDQUFDO0lBa0JoRSxDQUFDO0lBaEJHLCtCQUFRLEdBQVI7UUFDSSxJQUFJLE9BQU8sSUFBSSxDQUFDLFFBQVEsS0FBSyxXQUFXO1lBQUUsSUFBSSxDQUFDLE1BQU0sR0FBRyxJQUFJLENBQUMsUUFBUSxDQUFDO1FBQ3RFLElBQUksQ0FBQyxnQkFBZ0IsRUFBRSxDQUFDO0lBQzVCLENBQUM7SUFFRCx1Q0FBZ0IsR0FBaEI7UUFDSSxLQUFLLElBQUksQ0FBQyxJQUFJLElBQUksQ0FBQyxNQUFNLEVBQUU7WUFDdkIsSUFBSSxJQUFJLENBQUMsTUFBTSxDQUFDLGNBQWMsQ0FBQyxDQUFDLENBQUMsRUFBRTtnQkFDL0IsSUFBSSxDQUFDLGNBQWMsQ0FBQyxDQUFDLENBQUMsR0FBRyxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDO2FBQzNDO1NBQ0o7SUFDTCxDQUFDO0lBRUQsZ0NBQVMsR0FBVDtRQUNJLElBQUksQ0FBQyxVQUFVLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQztJQUN0QyxDQUFDO0lBbkJRO1FBQVIsS0FBSyxFQUFFOztnREFBYTtJQUNaO1FBQVIsS0FBSyxFQUFFOztrREFBZTtJQUNiO1FBQVQsTUFBTSxFQUFFO2tDQUFhLFlBQVk7b0RBQTBCO0lBTm5ELFlBQVk7UUFQeEIsU0FBUyxDQUFDO1lBQ1AsUUFBUSxFQUFFLGVBQWU7WUFDekIsdWxCQUEyQztZQUMzQyxhQUFhLEVBQUUsaUJBQWlCLENBQUMsSUFBSTtZQUNyQyxJQUFJLEVBQUcsRUFBRSxPQUFPLEVBQUcsb0JBQW9CLEVBQUU7U0FDNUMsQ0FBQztPQUVXLFlBQVksQ0F3QnhCO0lBQUQsbUJBQUM7Q0FBQSxBQXhCRCxJQXdCQztTQXhCWSxZQUFZIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHtcclxuICAgIENvbXBvbmVudCxcclxuICAgIFZpZXdFbmNhcHN1bGF0aW9uLFxyXG4gICAgSW5wdXQsXHJcbiAgICBPdXRwdXQsXHJcbiAgICBFdmVudEVtaXR0ZXIsXHJcbiAgICBPbkluaXRcclxufSBmcm9tICdAYW5ndWxhci9jb3JlJztcclxuaW1wb3J0IHsgTmdiVGltZXBpY2tlckNvbmZpZyB9IGZyb20gJ0BuZy1ib290c3RyYXAvbmctYm9vdHN0cmFwJztcclxuXHJcbkBDb21wb25lbnQoe1xyXG4gICAgc2VsZWN0b3I6ICdrZC10aW1lcGlja2VyJyxcclxuICAgIHRlbXBsYXRlVXJsOiAnLi9rZC1hbmd1bGFyLXRpbWVwaWNrZXIuaHRtbCcsXHJcbiAgICBlbmNhcHN1bGF0aW9uOiBWaWV3RW5jYXBzdWxhdGlvbi5Ob25lLFxyXG4gICAgaG9zdCA6IHsgJ2NsYXNzJyA6ICdrZHgga2R4LXRpbWVwaWNrZXInIH1cclxufSlcclxuXHJcbmV4cG9ydCBjbGFzcyBLZFRpbWVwaWNrZXIgaW1wbGVtZW50cyBPbkluaXQge1xyXG4gICAgcHVibGljIG5ld1ZhbDogYW55O1xyXG4gICAgcHVibGljIF9kZWZhdWx0Q29uZmlnOiBOZ2JUaW1lcGlja2VyQ29uZmlnID0gbmV3IE5nYlRpbWVwaWNrZXJDb25maWcoKTtcclxuXHJcbiAgICBASW5wdXQoKSBjb25maWc6IGFueTtcclxuICAgIEBJbnB1dCgpIGlucHV0VmFsOiBhbnk7XHJcbiAgICBAT3V0cHV0KCkgdGltZUNvbmZpZzogRXZlbnRFbWl0dGVyPHt9PiA9IG5ldyBFdmVudEVtaXR0ZXIoKTtcclxuXHJcbiAgICBuZ09uSW5pdCgpOiB2b2lkIHtcclxuICAgICAgICBpZiAodHlwZW9mIHRoaXMuaW5wdXRWYWwgIT09ICd1bmRlZmluZWQnKSB0aGlzLm5ld1ZhbCA9IHRoaXMuaW5wdXRWYWw7XHJcbiAgICAgICAgdGhpcy50aW1lcGlja2VyQ29uZmlnKCk7XHJcbiAgICB9XHJcblxyXG4gICAgdGltZXBpY2tlckNvbmZpZygpIHtcclxuICAgICAgICBmb3IgKGxldCBpIGluIHRoaXMuY29uZmlnKSB7XHJcbiAgICAgICAgICAgIGlmICh0aGlzLmNvbmZpZy5oYXNPd25Qcm9wZXJ0eShpKSkge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5fZGVmYXVsdENvbmZpZ1tpXSA9IHRoaXMuY29uZmlnW2ldO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIGVtaXRWYWx1ZSgpIHtcclxuICAgICAgICB0aGlzLnRpbWVDb25maWcuZW1pdCh0aGlzLm5ld1ZhbCk7XHJcbiAgICB9XHJcbn1cclxuIl19