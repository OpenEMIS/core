import { __decorate, __metadata } from "tslib";
import { Component, ViewContainerRef, Input, OnChanges, Output, EventEmitter, ViewChild, ViewEncapsulation, OnInit, AfterViewInit, OnDestroy, SimpleChanges, Renderer2 } from '@angular/core';
import { timer } from 'rxjs';
import { KdTextInputSvc } from './kd-angular-textinput-svc';
import { KdDomElemSvc } from '../kd-common/index';
import { AutoComplete } from 'primeng/autocomplete';
var KdTextInput = /** @class */ (function () {
    function KdTextInput(_renderer, _vcr, _textInputSvc) {
        this._renderer = _renderer;
        this._vcr = _vcr;
        this._textInputSvc = _textInputSvc;
        this._textSetting = {};
        this._isLoading = false;
        this.updatedValue = new EventEmitter();
    }
    KdTextInput.prototype.ngOnInit = function () {
        this._textSetting = this._textInputSvc.setInitSetting(this.config);
        this._textValue = (typeof this.value !== 'undefined') ? this.value : '';
        if (typeof this.options !== 'undefined' && this.options !== null) {
            var currentSelected = typeof this._textValue !== 'undefined' ? this._textValue : [];
            this._resultList = this._textInputSvc.checkMultiSelect(this.options, currentSelected);
        }
        else if (typeof this.config.dropdownCallback === 'undefined') {
            this._textSetting.multiselect = false;
            this._textSetting.autocomplete = false;
        }
    };
    KdTextInput.prototype.ngOnChanges = function (changes) {
        if (changes.hasOwnProperty('options') && typeof changes['options'].currentValue !== 'undefined') {
            var currentSelected = typeof this._textValue !== 'undefined' ? this._textValue : [];
            this._resultList = this._textInputSvc.checkMultiSelect(changes['options'].currentValue, currentSelected);
        }
        if (changes.hasOwnProperty('value')) {
            if (typeof changes['value'] !== 'undefined' && typeof changes['value'].currentValue !== 'undefined') {
                if (changes['value'].currentValue !== '') {
                    this._textValue = changes['value'].currentValue;
                }
                else {
                    if (this._textSetting.multiselect) {
                        this._textValue = [];
                    }
                    else {
                        this._textValue = '';
                    }
                }
            }
            else {
                this._textValue = '';
            }
            // this._textValue = (typeof changes["value"].currentValue != "undefined") ? changes["value"].currentValue : "";
        }
    };
    KdTextInput.prototype.ngAfterViewInit = function () {
        var _this = this;
        timer().subscribe(function () {
            if (_this._textSetting.multiselect && _this._textSetting.dropdownToggle) {
                var queryString = '.ui-autocomplete-multiple .ui-autocomplete-input-token input';
                _this._addClickListener(queryString);
            }
            else if (_this._textSetting.autocomplete && _this._textSetting.dropdownToggle) {
                var queryString = '.ui-autocomplete input.ui-inputtext';
                _this._addClickListener(queryString);
            }
        });
    };
    KdTextInput.prototype.ngOnDestroy = function () {
        if (typeof this._subscription !== 'undefined')
            this._subscription.unsubscribe();
        if (typeof this._rendererListenFunc !== 'undefined')
            this._rendererListenFunc();
    };
    KdTextInput.prototype.emitValue = function () {
        this.updatedValue.emit(this._textValue);
    };
    KdTextInput.prototype.searchMulti = function (_event, _state) {
        var query = this._textInputSvc.checkQuery(_event);
        if (typeof this._resultList !== 'undefined') {
            var searchResult = this._textInputSvc.searchList(query, this._resultList);
            this._checkSearchResult(searchResult, query);
        }
        else {
            this._checkLoadingFunc(query);
        }
    };
    KdTextInput.prototype.multiSelection = function (val, state) {
        if (this._textSetting.multiselect && typeof this._resultList !== 'undefined') {
            this._updateResultList(val, state);
        }
    };
    KdTextInput.prototype.checkEnterAndError = function (event) {
        var inputVal = event.target.value;
        if (inputVal.length < this._textSetting.minLength) {
            this.config.errors = undefined;
        }
        if (event.key === 'Backspace' && typeof this.config.dropdownCallback !== 'undefined' && !this._textSetting.enter) {
            if (typeof this._subscription !== 'undefined') {
                this._subscription.unsubscribe();
            }
            this._isLoading = false;
        }
        if (event.key === 'Enter' && typeof inputVal !== 'undefined' && inputVal !== '') {
            if (this._textSetting.multiselect) {
                this.searchMulti(inputVal, 'selected');
            }
            else if (!this._textSetting.multiselect && typeof this.config.value !== 'undefined' && typeof this.config.value !== 'object') {
                this.searchMulti(inputVal, 'selected');
            }
        }
    };
    KdTextInput.prototype._addClickListener = function (_queryString) {
        var _this = this;
        var clickEventEle = this._vcr.element.nativeElement.querySelector(_queryString);
        this._rendererListenFunc = this._renderer.listen(clickEventEle, 'click', function (_event) {
            _this.autocompleteComponent.handleDropdownClick(_event);
        });
    };
    KdTextInput.prototype._updateResultList = function (_val, _state) {
        if (_state === 'selected') {
            for (var i = 0; i < this._resultList.length; i++) {
                if (_val.value === this._resultList[i].value) {
                    this._resultList.splice(i, 1);
                    break;
                }
            }
        }
        else {
            var sortFunc = function (a, b) {
                if (a.value < b.value)
                    return -1;
                else if (a.value > b.value)
                    return 1;
                return 0;
            };
            this._resultList.push(_val);
            this._resultList.sort(sortFunc);
        }
    };
    KdTextInput.prototype._checkSearchResult = function (_value, _query) {
        var _this = this;
        var filteredOptions = this._textInputSvc.filterOptionList(_value, this._textValue);
        timer().subscribe(function () {
            _this._suggestionList = filteredOptions.slice();
            var checkedResult = _this._textInputSvc.checkError(_this._suggestionList, _query);
            if (typeof checkedResult !== 'undefined') {
                var result = [];
                result.push(checkedResult.dialogueMessage);
                _this.config.errors = result;
            }
        });
    };
    KdTextInput.prototype._checkLoadingFunc = function (_query) {
        var _this = this;
        this._isLoading = true;
        var selectedVal = (typeof this.config.value !== 'undefined') ? this.config.value : [];
        var params = { query: _query, currentSelected: selectedVal };
        if (typeof this._subscription !== 'undefined') {
            this._subscription.unsubscribe();
        }
        this._subscription = this.config.dropdownCallback(params).subscribe(function (_value) {
            // console.log(">>> value", _value);
            _this._checkSearchResult(_value, _query);
            _this._isLoading = false;
        });
    };
    KdTextInput.ctorParameters = function () { return [
        { type: Renderer2 },
        { type: ViewContainerRef },
        { type: KdTextInputSvc }
    ]; };
    __decorate([
        Input(),
        __metadata("design:type", Object)
    ], KdTextInput.prototype, "config", void 0);
    __decorate([
        Input(),
        __metadata("design:type", Object)
    ], KdTextInput.prototype, "options", void 0);
    __decorate([
        Input(),
        __metadata("design:type", Boolean)
    ], KdTextInput.prototype, "disabled", void 0);
    __decorate([
        Input(),
        __metadata("design:type", Boolean)
    ], KdTextInput.prototype, "readonly", void 0);
    __decorate([
        Input(),
        __metadata("design:type", Object)
    ], KdTextInput.prototype, "value", void 0);
    __decorate([
        Input(),
        __metadata("design:type", Number)
    ], KdTextInput.prototype, "maxLength", void 0);
    __decorate([
        Output(),
        __metadata("design:type", EventEmitter)
    ], KdTextInput.prototype, "updatedValue", void 0);
    __decorate([
        ViewChild(AutoComplete),
        __metadata("design:type", AutoComplete)
    ], KdTextInput.prototype, "autocompleteComponent", void 0);
    KdTextInput = __decorate([
        Component({
            selector: 'kd-text-input',
            template: "<p-autoComplete \r\n\t*ngIf=\"_textSetting.multiselect && !_textSetting.enter\" \r\n\t[multiple]=\"_textSetting.multiselect\" \r\n\t[suggestions]=\"_suggestionList\" \r\n\t(keyup)=\"checkEnterAndError($event)\" \r\n\t(completeMethod)=\"searchMulti($event, 'complete')\" \r\n\t(onSelect)=\"multiSelection($event, 'selected')\" \r\n\t(onUnselect)=\"multiSelection($event, 'unselected')\" \r\n\t[minLength]=\"_textSetting.minLength\" \r\n\t(onDropdownClick)=\"searchMulti($event, 'dropdown')\" \r\n\t[(ngModel)]=\"_textValue\" \r\n\t(ngModelChange)=\"emitValue()\" \r\n\t[disabled]=\"disabled || readonly\" \r\n\t[placeholder]=\"_textSetting.placeholder\"\r\n\tfield=\"value\"\r\n\tclass=\"kdx-p-autocomplete\"\r\n>\r\n</p-autoComplete>\r\n\r\n<p-autoComplete  \r\n\t*ngIf=\"_textSetting.autocomplete && !_textSetting.enter\"\r\n\t[suggestions]=\"_suggestionList\"\r\n\t(keyup)=\"checkEnterAndError($event)\"\r\n\t(completeMethod)=\"searchMulti($event, 'complete')\"\r\n\t(onSelect)=\"multiSelection($event, 'selected')\"\r\n\t[minLength]=\"_textSetting.minLength\"\r\n\t[placeholder]=\"_textSetting.placeholder\"\r\n\t(onDropdownClick)=\"searchMulti($event, 'dropdown')\"\r\n\t[(ngModel)]=\"_textValue\" \r\n\t(ngModelChange)=\"emitValue()\"\r\n\t[disabled]=\"disabled\"\r\n\t[readonly]=\"readonly\" \r\n\tfield=\"value\"\r\n\tclass=\"kdx-p-autocomplete\"\r\n>\r\n</p-autoComplete>\r\n\r\n<div *ngIf=\"_textSetting.multiselect && _textSetting.enter\" class=\"kdx-input-with-btn\">\r\n\t<p-autoComplete \r\n\t\t[multiple]=\"_textSetting.multiselect\"\r\n\t\t(keyup)=\"checkEnterAndError($event)\"\r\n\t\t[dropdown]=\"true\"\r\n\t\t(completeMethod)=\"searchMulti($event, 'complete')\"\r\n\t\t[suggestions]=\"_suggestionList\"\r\n\t\t(onSelect)=\"multiSelection($event, 'selected')\"\r\n\t\t(onUnselect)=\"multiSelection($event, 'unselected')\"\r\n\t\t(onDropdownClick)=\"searchMulti($event, 'dropdown')\"\r\n\t\t[placeholder]=\"_textSetting.placeholder\"\r\n\t\t[(ngModel)]=\"_textValue\" \r\n\t\t(ngModelChange)=\"emitValue()\"\r\n\t\t[disabled]=\"disabled || readonly\"\r\n\t\t[readonly]=\"readonly\"\r\n\t\tfield=\"value\"\r\n\t\tclass=\"kdx-p-autocomplete\"\r\n\t>\r\n\t</p-autoComplete>\r\n</div>\r\n\r\n<div *ngIf=\"_textSetting.autocomplete && _textSetting.enter\" class=\"kdx-input-with-btn\">\r\n\t<p-autoComplete \r\n\t\t(keyup)=\"checkEnterAndError($event)\"\r\n\t\t[dropdown]=\"true\"\r\n\t\t[suggestions]=\"_suggestionList\"\r\n\t\t(completeMethod)=\"searchMulti($event, 'complete')\"\r\n\t\t(onDropdownClick)=\"searchMulti($event, 'dropdown')\"\r\n\t\t(onSelect)=\"multiSelection($event, 'selected')\"\r\n\t\t[placeholder]=\"_textSetting.placeholder\"\r\n\t\t[(ngModel)]=\"_textValue\" \r\n\t\t(ngModelChange)=\"emitValue()\"\r\n\t\t[disabled]=\"disabled\"\r\n\t\t[readonly]=\"readonly\" \r\n\t\tfield=\"value\"\r\n\t\tclass=\"kdx-p-autocomplete\"\r\n\t>\r\n\t</p-autoComplete>\r\n</div>\r\n\r\n<div [hidden]=\"!_isLoading\" class=\"kdx-input-loader-wrapper\">\r\n\t<i class=\"fa fa-spinner fa-pulse fa-lg fa-fw input-loader\"></i>\r\n</div>\r\n\r\n<input \r\n\t*ngIf=\"!_textSetting.autocomplete && !_textSetting.multiselect\" \r\n\ttype=\"text\" \r\n\t[placeholder]=\"_textSetting.placeholder\" \r\n\t[(ngModel)]=\"_textValue\" \r\n\t[attr.maxlength]=\"maxLength\" \r\n\t[attr.disabled]=\"disabled ? disabled : null\" \r\n\t[attr.readonly]=\"readonly ? readonly : null\" \r\n\t(ngModelChange)=\"emitValue()\"\r\n/>\r\n\r\n<ng-content></ng-content>",
            encapsulation: ViewEncapsulation.None,
            providers: [KdTextInputSvc, KdDomElemSvc],
            host: { 'class': 'kdx kdx-text-input' }
        }),
        __metadata("design:paramtypes", [Renderer2,
            ViewContainerRef,
            KdTextInputSvc])
    ], KdTextInput);
    return KdTextInput;
}());
export { KdTextInput };
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoia2QtYW5ndWxhci10ZXh0LWlucHV0LmpzIiwic291cmNlUm9vdCI6Im5nOi8vb3BlbmVtaXMtc3R5bGVndWlkZS1saWIvIiwic291cmNlcyI6WyJrZC1jb21wb25lbnRzL2tkLWFuZ3VsYXItdGV4dC1pbnB1dC9rZC1hbmd1bGFyLXRleHQtaW5wdXQudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IjtBQUFBLE9BQU8sRUFBRSxTQUFTLEVBQUUsZ0JBQWdCLEVBQUUsS0FBSyxFQUFFLFNBQVMsRUFBRSxNQUFNLEVBQUUsWUFBWSxFQUFFLFNBQVMsRUFBRSxpQkFBaUIsRUFBRSxNQUFNLEVBQUUsYUFBYSxFQUFFLFNBQVMsRUFBRSxhQUFhLEVBQUUsU0FBUyxFQUFFLE1BQU0sZUFBZSxDQUFDO0FBQzlMLE9BQU8sRUFBRSxLQUFLLEVBQWtCLE1BQU0sTUFBTSxDQUFDO0FBQzdDLE9BQU8sRUFBRSxjQUFjLEVBQUUsTUFBTSw0QkFBNEIsQ0FBQztBQUM1RCxPQUFPLEVBQUUsWUFBWSxFQUFFLE1BQU0sb0JBQW9CLENBQUM7QUFDbEQsT0FBTyxFQUFFLFlBQVksRUFBRSxNQUFNLHNCQUFzQixDQUFDO0FBV3BEO0lBa0JJLHFCQUNZLFNBQW9CLEVBQ3BCLElBQXNCLEVBQ3RCLGFBQTZCO1FBRjdCLGNBQVMsR0FBVCxTQUFTLENBQVc7UUFDcEIsU0FBSSxHQUFKLElBQUksQ0FBa0I7UUFDdEIsa0JBQWEsR0FBYixhQUFhLENBQWdCO1FBcEJsQyxpQkFBWSxHQUFRLEVBQUUsQ0FBQztRQUN2QixlQUFVLEdBQVksS0FBSyxDQUFDO1FBYXpCLGlCQUFZLEdBQXNCLElBQUksWUFBWSxFQUFFLENBQUM7SUFPM0QsQ0FBQztJQUVMLDhCQUFRLEdBQVI7UUFDSSxJQUFJLENBQUMsWUFBWSxHQUFHLElBQUksQ0FBQyxhQUFhLENBQUMsY0FBYyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQztRQUNuRSxJQUFJLENBQUMsVUFBVSxHQUFHLENBQUMsT0FBTyxJQUFJLENBQUMsS0FBSyxLQUFLLFdBQVcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUM7UUFFeEUsSUFBSSxPQUFPLElBQUksQ0FBQyxPQUFPLEtBQUssV0FBVyxJQUFJLElBQUksQ0FBQyxPQUFPLEtBQUssSUFBSSxFQUFFO1lBQzlELElBQUksZUFBZSxHQUFlLE9BQU8sSUFBSSxDQUFDLFVBQVUsS0FBSyxXQUFXLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQztZQUNoRyxJQUFJLENBQUMsV0FBVyxHQUFHLElBQUksQ0FBQyxhQUFhLENBQUMsZ0JBQWdCLENBQUMsSUFBSSxDQUFDLE9BQU8sRUFBRSxlQUFlLENBQUMsQ0FBQztTQUN6RjthQUNJLElBQUksT0FBTyxJQUFJLENBQUMsTUFBTSxDQUFDLGdCQUFnQixLQUFLLFdBQVcsRUFBRTtZQUMxRCxJQUFJLENBQUMsWUFBWSxDQUFDLFdBQVcsR0FBRyxLQUFLLENBQUM7WUFDdEMsSUFBSSxDQUFDLFlBQVksQ0FBQyxZQUFZLEdBQUcsS0FBSyxDQUFDO1NBQzFDO0lBQ0wsQ0FBQztJQUVELGlDQUFXLEdBQVgsVUFBWSxPQUFzQjtRQUM5QixJQUFJLE9BQU8sQ0FBQyxjQUFjLENBQUMsU0FBUyxDQUFDLElBQUksT0FBTyxPQUFPLENBQUMsU0FBUyxDQUFDLENBQUMsWUFBWSxLQUFLLFdBQVcsRUFBRTtZQUM3RixJQUFJLGVBQWUsR0FBZSxPQUFPLElBQUksQ0FBQyxVQUFVLEtBQUssV0FBVyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUM7WUFDaEcsSUFBSSxDQUFDLFdBQVcsR0FBRyxJQUFJLENBQUMsYUFBYSxDQUFDLGdCQUFnQixDQUFDLE9BQU8sQ0FBQyxTQUFTLENBQUMsQ0FBQyxZQUFZLEVBQUUsZUFBZSxDQUFDLENBQUM7U0FDNUc7UUFFRCxJQUFJLE9BQU8sQ0FBQyxjQUFjLENBQUMsT0FBTyxDQUFDLEVBQUU7WUFDakMsSUFBSSxPQUFPLE9BQU8sQ0FBQyxPQUFPLENBQUMsS0FBSyxXQUFXLElBQUksT0FBTyxPQUFPLENBQUMsT0FBTyxDQUFDLENBQUMsWUFBWSxLQUFLLFdBQVcsRUFBRTtnQkFDakcsSUFBSSxPQUFPLENBQUMsT0FBTyxDQUFDLENBQUMsWUFBWSxLQUFLLEVBQUUsRUFBRTtvQkFDdEMsSUFBSSxDQUFDLFVBQVUsR0FBRyxPQUFPLENBQUMsT0FBTyxDQUFDLENBQUMsWUFBWSxDQUFDO2lCQUNuRDtxQkFDSTtvQkFDRCxJQUFJLElBQUksQ0FBQyxZQUFZLENBQUMsV0FBVyxFQUFFO3dCQUMvQixJQUFJLENBQUMsVUFBVSxHQUFHLEVBQUUsQ0FBQztxQkFDeEI7eUJBQ0k7d0JBQ0QsSUFBSSxDQUFDLFVBQVUsR0FBRyxFQUFFLENBQUM7cUJBQ3hCO2lCQUNKO2FBQ0o7aUJBQU07Z0JBQ0gsSUFBSSxDQUFDLFVBQVUsR0FBRyxFQUFFLENBQUM7YUFDeEI7WUFFRCxnSEFBZ0g7U0FDbkg7SUFDTCxDQUFDO0lBRUQscUNBQWUsR0FBZjtRQUFBLGlCQVlDO1FBWEcsS0FBSyxFQUFFLENBQUMsU0FBUyxDQUFDO1lBQ2QsSUFBSSxLQUFJLENBQUMsWUFBWSxDQUFDLFdBQVcsSUFBSSxLQUFJLENBQUMsWUFBWSxDQUFDLGNBQWMsRUFBRTtnQkFDbkUsSUFBSSxXQUFXLEdBQVcsOERBQThELENBQUM7Z0JBQ3pGLEtBQUksQ0FBQyxpQkFBaUIsQ0FBQyxXQUFXLENBQUMsQ0FBQzthQUN2QztpQkFDSSxJQUFJLEtBQUksQ0FBQyxZQUFZLENBQUMsWUFBWSxJQUFJLEtBQUksQ0FBQyxZQUFZLENBQUMsY0FBYyxFQUFFO2dCQUN6RSxJQUFJLFdBQVcsR0FBVyxxQ0FBcUMsQ0FBQztnQkFDaEUsS0FBSSxDQUFDLGlCQUFpQixDQUFDLFdBQVcsQ0FBQyxDQUFDO2FBQ3ZDO1FBQ0wsQ0FBQyxDQUFDLENBQUM7SUFFUCxDQUFDO0lBRUQsaUNBQVcsR0FBWDtRQUNJLElBQUksT0FBTyxJQUFJLENBQUMsYUFBYSxLQUFLLFdBQVc7WUFBRSxJQUFJLENBQUMsYUFBYSxDQUFDLFdBQVcsRUFBRSxDQUFDO1FBQ2hGLElBQUksT0FBTyxJQUFJLENBQUMsbUJBQW1CLEtBQUssV0FBVztZQUFFLElBQUksQ0FBQyxtQkFBbUIsRUFBRSxDQUFDO0lBQ3BGLENBQUM7SUFFRCwrQkFBUyxHQUFUO1FBQ0ksSUFBSSxDQUFDLFlBQVksQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxDQUFDO0lBQzVDLENBQUM7SUFFRCxpQ0FBVyxHQUFYLFVBQVksTUFBVyxFQUFFLE1BQWM7UUFDbkMsSUFBSSxLQUFLLEdBQVcsSUFBSSxDQUFDLGFBQWEsQ0FBQyxVQUFVLENBQUMsTUFBTSxDQUFDLENBQUM7UUFFMUQsSUFBSSxPQUFPLElBQUksQ0FBQyxXQUFXLEtBQUssV0FBVyxFQUFFO1lBQ3pDLElBQUksWUFBWSxHQUFlLElBQUksQ0FBQyxhQUFhLENBQUMsVUFBVSxDQUFDLEtBQUssRUFBRSxJQUFJLENBQUMsV0FBVyxDQUFDLENBQUM7WUFDdEYsSUFBSSxDQUFDLGtCQUFrQixDQUFDLFlBQVksRUFBRSxLQUFLLENBQUMsQ0FBQztTQUNoRDthQUNJO1lBQ0QsSUFBSSxDQUFDLGlCQUFpQixDQUFDLEtBQUssQ0FBQyxDQUFDO1NBQ2pDO0lBQ0wsQ0FBQztJQUVELG9DQUFjLEdBQWQsVUFBZSxHQUFRLEVBQUUsS0FBYTtRQUNsQyxJQUFJLElBQUksQ0FBQyxZQUFZLENBQUMsV0FBVyxJQUFJLE9BQU8sSUFBSSxDQUFDLFdBQVcsS0FBSyxXQUFXLEVBQUU7WUFDMUUsSUFBSSxDQUFDLGlCQUFpQixDQUFDLEdBQUcsRUFBRSxLQUFLLENBQUMsQ0FBQztTQUN0QztJQUNMLENBQUM7SUFFRCx3Q0FBa0IsR0FBbEIsVUFBbUIsS0FBVTtRQUN6QixJQUFJLFFBQVEsR0FBVyxLQUFLLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQztRQUUxQyxJQUFJLFFBQVEsQ0FBQyxNQUFNLEdBQUcsSUFBSSxDQUFDLFlBQVksQ0FBQyxTQUFTLEVBQUU7WUFDL0MsSUFBSSxDQUFDLE1BQU0sQ0FBQyxNQUFNLEdBQUcsU0FBUyxDQUFDO1NBQ2xDO1FBRUQsSUFBSSxLQUFLLENBQUMsR0FBRyxLQUFLLFdBQVcsSUFBSSxPQUFPLElBQUksQ0FBQyxNQUFNLENBQUMsZ0JBQWdCLEtBQUssV0FBVyxJQUFJLENBQUMsSUFBSSxDQUFDLFlBQVksQ0FBQyxLQUFLLEVBQUU7WUFDOUcsSUFBSSxPQUFPLElBQUksQ0FBQyxhQUFhLEtBQUssV0FBVyxFQUFFO2dCQUMzQyxJQUFJLENBQUMsYUFBYSxDQUFDLFdBQVcsRUFBRSxDQUFDO2FBQ3BDO1lBRUQsSUFBSSxDQUFDLFVBQVUsR0FBRyxLQUFLLENBQUM7U0FDM0I7UUFFRCxJQUFJLEtBQUssQ0FBQyxHQUFHLEtBQUssT0FBTyxJQUFJLE9BQU8sUUFBUSxLQUFLLFdBQVcsSUFBSSxRQUFRLEtBQUssRUFBRSxFQUFFO1lBQzdFLElBQUksSUFBSSxDQUFDLFlBQVksQ0FBQyxXQUFXLEVBQUU7Z0JBQy9CLElBQUksQ0FBQyxXQUFXLENBQUMsUUFBUSxFQUFFLFVBQVUsQ0FBQyxDQUFDO2FBQzFDO2lCQUVJLElBQUksQ0FBQyxJQUFJLENBQUMsWUFBWSxDQUFDLFdBQVcsSUFBSSxPQUFPLElBQUksQ0FBQyxNQUFNLENBQUMsS0FBSyxLQUFLLFdBQVcsSUFBSSxPQUFPLElBQUksQ0FBQyxNQUFNLENBQUMsS0FBSyxLQUFLLFFBQVEsRUFBRTtnQkFDMUgsSUFBSSxDQUFDLFdBQVcsQ0FBQyxRQUFRLEVBQUUsVUFBVSxDQUFDLENBQUM7YUFDMUM7U0FDSjtJQUNMLENBQUM7SUFFTyx1Q0FBaUIsR0FBekIsVUFBMEIsWUFBb0I7UUFBOUMsaUJBTUM7UUFMRyxJQUFJLGFBQWEsR0FBZ0IsSUFBSSxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsYUFBYSxDQUFDLGFBQWEsQ0FBQyxZQUFZLENBQUMsQ0FBQztRQUU3RixJQUFJLENBQUMsbUJBQW1CLEdBQUcsSUFBSSxDQUFDLFNBQVMsQ0FBQyxNQUFNLENBQUMsYUFBYSxFQUFFLE9BQU8sRUFBRSxVQUFDLE1BQVc7WUFDekYsS0FBSSxDQUFDLHFCQUFxQixDQUFDLG1CQUFtQixDQUFDLE1BQU0sQ0FBQyxDQUFDO1FBQzNELENBQUMsQ0FBQyxDQUFDO0lBQ0MsQ0FBQztJQUVPLHVDQUFpQixHQUF6QixVQUEwQixJQUFTLEVBQUUsTUFBYztRQUMvQyxJQUFJLE1BQU0sS0FBSyxVQUFVLEVBQUU7WUFDdkIsS0FBSyxJQUFJLENBQUMsR0FBVyxDQUFDLEVBQUUsQ0FBQyxHQUFHLElBQUksQ0FBQyxXQUFXLENBQUMsTUFBTSxFQUFFLENBQUMsRUFBRSxFQUFFO2dCQUN0RCxJQUFJLElBQUksQ0FBQyxLQUFLLEtBQUssSUFBSSxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLEVBQUU7b0JBQzFDLElBQUksQ0FBQyxXQUFXLENBQUMsTUFBTSxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQztvQkFDOUIsTUFBTTtpQkFDVDthQUNKO1NBQ0o7YUFDSTtZQUNELElBQUksUUFBUSxHQUErQixVQUFDLENBQU0sRUFBRSxDQUFNO2dCQUN0RCxJQUFJLENBQUMsQ0FBQyxLQUFLLEdBQUcsQ0FBQyxDQUFDLEtBQUs7b0JBQUUsT0FBTyxDQUFDLENBQUMsQ0FBQztxQkFDNUIsSUFBSSxDQUFDLENBQUMsS0FBSyxHQUFHLENBQUMsQ0FBQyxLQUFLO29CQUFFLE9BQU8sQ0FBQyxDQUFDO2dCQUNyQyxPQUFPLENBQUMsQ0FBQztZQUNiLENBQUMsQ0FBQztZQUVGLElBQUksQ0FBQyxXQUFXLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDO1lBQzVCLElBQUksQ0FBQyxXQUFXLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxDQUFDO1NBQ25DO0lBQ0wsQ0FBQztJQUVPLHdDQUFrQixHQUExQixVQUEyQixNQUFrQixFQUFFLE1BQWM7UUFBN0QsaUJBY0M7UUFiRyxJQUFJLGVBQWUsR0FBZSxJQUFJLENBQUMsYUFBYSxDQUFDLGdCQUFnQixDQUFDLE1BQU0sRUFBRSxJQUFJLENBQUMsVUFBVSxDQUFDLENBQUM7UUFFL0YsS0FBSyxFQUFFLENBQUMsU0FBUyxDQUFDO1lBQ2QsS0FBSSxDQUFDLGVBQWUsR0FBRyxlQUFlLENBQUMsS0FBSyxFQUFFLENBQUM7WUFFL0MsSUFBSSxhQUFhLEdBQUcsS0FBSSxDQUFDLGFBQWEsQ0FBQyxVQUFVLENBQUMsS0FBSSxDQUFDLGVBQWUsRUFBRSxNQUFNLENBQUMsQ0FBQztZQUVoRixJQUFJLE9BQU8sYUFBYSxLQUFLLFdBQVcsRUFBRTtnQkFDdEMsSUFBSSxNQUFNLEdBQWtCLEVBQUUsQ0FBQztnQkFDL0IsTUFBTSxDQUFDLElBQUksQ0FBQyxhQUFhLENBQUMsZUFBZSxDQUFDLENBQUM7Z0JBQzNDLEtBQUksQ0FBQyxNQUFNLENBQUMsTUFBTSxHQUFHLE1BQU0sQ0FBQzthQUMvQjtRQUNMLENBQUMsQ0FBQyxDQUFDO0lBQ1AsQ0FBQztJQUVPLHVDQUFpQixHQUF6QixVQUEwQixNQUFjO1FBQXhDLGlCQWVDO1FBZEcsSUFBSSxDQUFDLFVBQVUsR0FBRyxJQUFJLENBQUM7UUFFdkIsSUFBSSxXQUFXLEdBQUcsQ0FBQyxPQUFPLElBQUksQ0FBQyxNQUFNLENBQUMsS0FBSyxLQUFLLFdBQVcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDO1FBQ3RGLElBQUksTUFBTSxHQUFHLEVBQUMsS0FBSyxFQUFFLE1BQU0sRUFBRSxlQUFlLEVBQUUsV0FBVyxFQUFDLENBQUM7UUFFM0QsSUFBSSxPQUFPLElBQUksQ0FBQyxhQUFhLEtBQUssV0FBVyxFQUFFO1lBQzNDLElBQUksQ0FBQyxhQUFhLENBQUMsV0FBVyxFQUFFLENBQUM7U0FDcEM7UUFFRCxJQUFJLENBQUMsYUFBYSxHQUFHLElBQUksQ0FBQyxNQUFNLENBQUMsZ0JBQWdCLENBQUMsTUFBTSxDQUFDLENBQUMsU0FBUyxDQUFDLFVBQUMsTUFBVztZQUM1RSxvQ0FBb0M7WUFDcEMsS0FBSSxDQUFDLGtCQUFrQixDQUFDLE1BQU0sRUFBRSxNQUFNLENBQUMsQ0FBQztZQUN4QyxLQUFJLENBQUMsVUFBVSxHQUFHLEtBQUssQ0FBQztRQUM1QixDQUFDLENBQUMsQ0FBQztJQUNQLENBQUM7O2dCQTdLc0IsU0FBUztnQkFDZCxnQkFBZ0I7Z0JBQ1AsY0FBYzs7SUFaaEM7UUFBUixLQUFLLEVBQUU7OytDQUFhO0lBQ1o7UUFBUixLQUFLLEVBQUU7O2dEQUFjO0lBQ2I7UUFBUixLQUFLLEVBQUU7O2lEQUFtQjtJQUNsQjtRQUFSLEtBQUssRUFBRTs7aURBQW1CO0lBQ2xCO1FBQVIsS0FBSyxFQUFFOzs4Q0FBWTtJQUNYO1FBQVIsS0FBSyxFQUFFOztrREFBbUI7SUFDakI7UUFBVCxNQUFNLEVBQUU7a0NBQWUsWUFBWTtxREFBMkI7SUFDdEM7UUFBeEIsU0FBUyxDQUFDLFlBQVksQ0FBQztrQ0FBd0IsWUFBWTs4REFBQztJQWhCcEQsV0FBVztRQVJ2QixTQUFTLENBQUM7WUFDUCxRQUFRLEVBQUUsZUFBZTtZQUN6QiwrNEdBQTJDO1lBQzNDLGFBQWEsRUFBRSxpQkFBaUIsQ0FBQyxJQUFJO1lBQ3JDLFNBQVMsRUFBRSxDQUFDLGNBQWMsRUFBRSxZQUFZLENBQUM7WUFDekMsSUFBSSxFQUFHLEVBQUUsT0FBTyxFQUFHLG9CQUFvQixFQUFFO1NBQzVDLENBQUM7eUNBcUJ5QixTQUFTO1lBQ2QsZ0JBQWdCO1lBQ1AsY0FBYztPQXJCaEMsV0FBVyxDQWlNdkI7SUFBRCxrQkFBQztDQUFBLEFBak1ELElBaU1DO1NBak1ZLFdBQVciLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBDb21wb25lbnQsIFZpZXdDb250YWluZXJSZWYsIElucHV0LCBPbkNoYW5nZXMsIE91dHB1dCwgRXZlbnRFbWl0dGVyLCBWaWV3Q2hpbGQsIFZpZXdFbmNhcHN1bGF0aW9uLCBPbkluaXQsIEFmdGVyVmlld0luaXQsIE9uRGVzdHJveSwgU2ltcGxlQ2hhbmdlcywgUmVuZGVyZXIyIH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XHJcbmltcG9ydCB7IHRpbWVyICwgIFN1YnNjcmlwdGlvbiB9IGZyb20gJ3J4anMnO1xyXG5pbXBvcnQgeyBLZFRleHRJbnB1dFN2YyB9IGZyb20gJy4va2QtYW5ndWxhci10ZXh0aW5wdXQtc3ZjJztcclxuaW1wb3J0IHsgS2REb21FbGVtU3ZjIH0gZnJvbSAnLi4va2QtY29tbW9uL2luZGV4JztcclxuaW1wb3J0IHsgQXV0b0NvbXBsZXRlIH0gZnJvbSAncHJpbWVuZy9hdXRvY29tcGxldGUnO1xyXG5cclxuXHJcbkBDb21wb25lbnQoe1xyXG4gICAgc2VsZWN0b3I6ICdrZC10ZXh0LWlucHV0JyxcclxuICAgIHRlbXBsYXRlVXJsOiAnLi9rZC1hbmd1bGFyLXRleHQtaW5wdXQuaHRtbCcsXHJcbiAgICBlbmNhcHN1bGF0aW9uOiBWaWV3RW5jYXBzdWxhdGlvbi5Ob25lLFxyXG4gICAgcHJvdmlkZXJzOiBbS2RUZXh0SW5wdXRTdmMsIEtkRG9tRWxlbVN2Y10sXHJcbiAgICBob3N0IDogeyAnY2xhc3MnIDogJ2tkeCBrZHgtdGV4dC1pbnB1dCcgfVxyXG59KVxyXG5cclxuZXhwb3J0IGNsYXNzIEtkVGV4dElucHV0IGltcGxlbWVudHMgT25Jbml0LCBPbkNoYW5nZXMsIEFmdGVyVmlld0luaXQsIE9uRGVzdHJveSB7XHJcbiAgICBwdWJsaWMgX3RleHRTZXR0aW5nOiBhbnkgPSB7fTtcclxuICAgIHB1YmxpYyBfaXNMb2FkaW5nOiBib29sZWFuID0gZmFsc2U7XHJcbiAgICBwcml2YXRlIF9yZXN1bHRMaXN0OiBBcnJheTxhbnk+O1xyXG4gICAgcHVibGljIF9zdWdnZXN0aW9uTGlzdDogQXJyYXk8c3RyaW5nPjtcclxuICAgIHByaXZhdGUgX3N1YnNjcmlwdGlvbjogU3Vic2NyaXB0aW9uO1xyXG4gICAgcHJpdmF0ZSBfcmVuZGVyZXJMaXN0ZW5GdW5jOiBGdW5jdGlvbjtcclxuICAgIHB1YmxpYyBfdGV4dFZhbHVlOiBhbnk7XHJcblxyXG4gICAgQElucHV0KCkgY29uZmlnOiBhbnk7XHJcbiAgICBASW5wdXQoKSBvcHRpb25zOiBhbnk7XHJcbiAgICBASW5wdXQoKSBkaXNhYmxlZDogYm9vbGVhbjtcclxuICAgIEBJbnB1dCgpIHJlYWRvbmx5OiBib29sZWFuO1xyXG4gICAgQElucHV0KCkgdmFsdWU6IGFueTtcclxuICAgIEBJbnB1dCgpIG1heExlbmd0aDogbnVtYmVyO1xyXG4gICAgQE91dHB1dCgpIHVwZGF0ZWRWYWx1ZTogRXZlbnRFbWl0dGVyPGFueT4gPSBuZXcgRXZlbnRFbWl0dGVyKCk7XHJcbiAgICBAVmlld0NoaWxkKEF1dG9Db21wbGV0ZSkgYXV0b2NvbXBsZXRlQ29tcG9uZW50OiBBdXRvQ29tcGxldGU7XHJcblxyXG4gICAgY29uc3RydWN0b3IoXHJcbiAgICAgICAgcHJpdmF0ZSBfcmVuZGVyZXI6IFJlbmRlcmVyMixcclxuICAgICAgICBwcml2YXRlIF92Y3I6IFZpZXdDb250YWluZXJSZWYsXHJcbiAgICAgICAgcHJpdmF0ZSBfdGV4dElucHV0U3ZjOiBLZFRleHRJbnB1dFN2Y1xyXG4gICAgKSB7IH1cclxuXHJcbiAgICBuZ09uSW5pdCgpOiB2b2lkIHtcclxuICAgICAgICB0aGlzLl90ZXh0U2V0dGluZyA9IHRoaXMuX3RleHRJbnB1dFN2Yy5zZXRJbml0U2V0dGluZyh0aGlzLmNvbmZpZyk7XHJcbiAgICAgICAgdGhpcy5fdGV4dFZhbHVlID0gKHR5cGVvZiB0aGlzLnZhbHVlICE9PSAndW5kZWZpbmVkJykgPyB0aGlzLnZhbHVlIDogJyc7XHJcblxyXG4gICAgICAgIGlmICh0eXBlb2YgdGhpcy5vcHRpb25zICE9PSAndW5kZWZpbmVkJyAmJiB0aGlzLm9wdGlvbnMgIT09IG51bGwpIHtcclxuICAgICAgICAgICAgbGV0IGN1cnJlbnRTZWxlY3RlZDogQXJyYXk8YW55PiA9IHR5cGVvZiB0aGlzLl90ZXh0VmFsdWUgIT09ICd1bmRlZmluZWQnID8gdGhpcy5fdGV4dFZhbHVlIDogW107XHJcbiAgICAgICAgICAgIHRoaXMuX3Jlc3VsdExpc3QgPSB0aGlzLl90ZXh0SW5wdXRTdmMuY2hlY2tNdWx0aVNlbGVjdCh0aGlzLm9wdGlvbnMsIGN1cnJlbnRTZWxlY3RlZCk7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGVsc2UgaWYgKHR5cGVvZiB0aGlzLmNvbmZpZy5kcm9wZG93bkNhbGxiYWNrID09PSAndW5kZWZpbmVkJykge1xyXG4gICAgICAgICAgICB0aGlzLl90ZXh0U2V0dGluZy5tdWx0aXNlbGVjdCA9IGZhbHNlO1xyXG4gICAgICAgICAgICB0aGlzLl90ZXh0U2V0dGluZy5hdXRvY29tcGxldGUgPSBmYWxzZTtcclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgbmdPbkNoYW5nZXMoY2hhbmdlczogU2ltcGxlQ2hhbmdlcyk6IHZvaWQge1xyXG4gICAgICAgIGlmIChjaGFuZ2VzLmhhc093blByb3BlcnR5KCdvcHRpb25zJykgJiYgdHlwZW9mIGNoYW5nZXNbJ29wdGlvbnMnXS5jdXJyZW50VmFsdWUgIT09ICd1bmRlZmluZWQnKSB7XHJcbiAgICAgICAgICAgIGxldCBjdXJyZW50U2VsZWN0ZWQ6IEFycmF5PGFueT4gPSB0eXBlb2YgdGhpcy5fdGV4dFZhbHVlICE9PSAndW5kZWZpbmVkJyA/IHRoaXMuX3RleHRWYWx1ZSA6IFtdO1xyXG4gICAgICAgICAgICB0aGlzLl9yZXN1bHRMaXN0ID0gdGhpcy5fdGV4dElucHV0U3ZjLmNoZWNrTXVsdGlTZWxlY3QoY2hhbmdlc1snb3B0aW9ucyddLmN1cnJlbnRWYWx1ZSwgY3VycmVudFNlbGVjdGVkKTtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIGlmIChjaGFuZ2VzLmhhc093blByb3BlcnR5KCd2YWx1ZScpKSB7XHJcbiAgICAgICAgICAgIGlmICh0eXBlb2YgY2hhbmdlc1sndmFsdWUnXSAhPT0gJ3VuZGVmaW5lZCcgJiYgdHlwZW9mIGNoYW5nZXNbJ3ZhbHVlJ10uY3VycmVudFZhbHVlICE9PSAndW5kZWZpbmVkJykge1xyXG4gICAgICAgICAgICAgICAgaWYgKGNoYW5nZXNbJ3ZhbHVlJ10uY3VycmVudFZhbHVlICE9PSAnJykge1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuX3RleHRWYWx1ZSA9IGNoYW5nZXNbJ3ZhbHVlJ10uY3VycmVudFZhbHVlO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgZWxzZSB7XHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKHRoaXMuX3RleHRTZXR0aW5nLm11bHRpc2VsZWN0KSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuX3RleHRWYWx1ZSA9IFtdO1xyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5fdGV4dFZhbHVlID0gJyc7XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5fdGV4dFZhbHVlID0gJyc7XHJcbiAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgIC8vIHRoaXMuX3RleHRWYWx1ZSA9ICh0eXBlb2YgY2hhbmdlc1tcInZhbHVlXCJdLmN1cnJlbnRWYWx1ZSAhPSBcInVuZGVmaW5lZFwiKSA/IGNoYW5nZXNbXCJ2YWx1ZVwiXS5jdXJyZW50VmFsdWUgOiBcIlwiO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICBuZ0FmdGVyVmlld0luaXQoKTogdm9pZCB7XHJcbiAgICAgICAgdGltZXIoKS5zdWJzY3JpYmUoKCk6IHZvaWQgPT4ge1xyXG4gICAgICAgICAgICBpZiAodGhpcy5fdGV4dFNldHRpbmcubXVsdGlzZWxlY3QgJiYgdGhpcy5fdGV4dFNldHRpbmcuZHJvcGRvd25Ub2dnbGUpIHtcclxuICAgICAgICAgICAgICAgIGxldCBxdWVyeVN0cmluZzogc3RyaW5nID0gJy51aS1hdXRvY29tcGxldGUtbXVsdGlwbGUgLnVpLWF1dG9jb21wbGV0ZS1pbnB1dC10b2tlbiBpbnB1dCc7XHJcbiAgICAgICAgICAgICAgICB0aGlzLl9hZGRDbGlja0xpc3RlbmVyKHF1ZXJ5U3RyaW5nKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBlbHNlIGlmICh0aGlzLl90ZXh0U2V0dGluZy5hdXRvY29tcGxldGUgJiYgdGhpcy5fdGV4dFNldHRpbmcuZHJvcGRvd25Ub2dnbGUpIHtcclxuICAgICAgICAgICAgICAgIGxldCBxdWVyeVN0cmluZzogc3RyaW5nID0gJy51aS1hdXRvY29tcGxldGUgaW5wdXQudWktaW5wdXR0ZXh0JztcclxuICAgICAgICAgICAgICAgIHRoaXMuX2FkZENsaWNrTGlzdGVuZXIocXVlcnlTdHJpbmcpO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfSk7XHJcblxyXG4gICAgfVxyXG5cclxuICAgIG5nT25EZXN0cm95KCk6IHZvaWQge1xyXG4gICAgICAgIGlmICh0eXBlb2YgdGhpcy5fc3Vic2NyaXB0aW9uICE9PSAndW5kZWZpbmVkJykgdGhpcy5fc3Vic2NyaXB0aW9uLnVuc3Vic2NyaWJlKCk7XHJcbiAgICAgICAgaWYgKHR5cGVvZiB0aGlzLl9yZW5kZXJlckxpc3RlbkZ1bmMgIT09ICd1bmRlZmluZWQnKSB0aGlzLl9yZW5kZXJlckxpc3RlbkZ1bmMoKTtcclxuICAgIH1cclxuXHJcbiAgICBlbWl0VmFsdWUoKTogdm9pZCB7XHJcbiAgICAgICAgdGhpcy51cGRhdGVkVmFsdWUuZW1pdCh0aGlzLl90ZXh0VmFsdWUpO1xyXG4gICAgfVxyXG5cclxuICAgIHNlYXJjaE11bHRpKF9ldmVudDogYW55LCBfc3RhdGU6IHN0cmluZyk6IHZvaWQge1xyXG4gICAgICAgIGxldCBxdWVyeTogc3RyaW5nID0gdGhpcy5fdGV4dElucHV0U3ZjLmNoZWNrUXVlcnkoX2V2ZW50KTtcclxuXHJcbiAgICAgICAgaWYgKHR5cGVvZiB0aGlzLl9yZXN1bHRMaXN0ICE9PSAndW5kZWZpbmVkJykge1xyXG4gICAgICAgICAgICBsZXQgc2VhcmNoUmVzdWx0OiBBcnJheTxhbnk+ID0gdGhpcy5fdGV4dElucHV0U3ZjLnNlYXJjaExpc3QocXVlcnksIHRoaXMuX3Jlc3VsdExpc3QpO1xyXG4gICAgICAgICAgICB0aGlzLl9jaGVja1NlYXJjaFJlc3VsdChzZWFyY2hSZXN1bHQsIHF1ZXJ5KTtcclxuICAgICAgICB9XHJcbiAgICAgICAgZWxzZSB7XHJcbiAgICAgICAgICAgIHRoaXMuX2NoZWNrTG9hZGluZ0Z1bmMocXVlcnkpO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICBtdWx0aVNlbGVjdGlvbih2YWw6IGFueSwgc3RhdGU6IHN0cmluZyk6IHZvaWQge1xyXG4gICAgICAgIGlmICh0aGlzLl90ZXh0U2V0dGluZy5tdWx0aXNlbGVjdCAmJiB0eXBlb2YgdGhpcy5fcmVzdWx0TGlzdCAhPT0gJ3VuZGVmaW5lZCcpIHtcclxuICAgICAgICAgICAgdGhpcy5fdXBkYXRlUmVzdWx0TGlzdCh2YWwsIHN0YXRlKTtcclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgY2hlY2tFbnRlckFuZEVycm9yKGV2ZW50OiBhbnkpOiB2b2lkIHtcclxuICAgICAgICBsZXQgaW5wdXRWYWw6IHN0cmluZyA9IGV2ZW50LnRhcmdldC52YWx1ZTtcclxuXHJcbiAgICAgICAgaWYgKGlucHV0VmFsLmxlbmd0aCA8IHRoaXMuX3RleHRTZXR0aW5nLm1pbkxlbmd0aCkge1xyXG4gICAgICAgICAgICB0aGlzLmNvbmZpZy5lcnJvcnMgPSB1bmRlZmluZWQ7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICBpZiAoZXZlbnQua2V5ID09PSAnQmFja3NwYWNlJyAmJiB0eXBlb2YgdGhpcy5jb25maWcuZHJvcGRvd25DYWxsYmFjayAhPT0gJ3VuZGVmaW5lZCcgJiYgIXRoaXMuX3RleHRTZXR0aW5nLmVudGVyKSB7XHJcbiAgICAgICAgICAgIGlmICh0eXBlb2YgdGhpcy5fc3Vic2NyaXB0aW9uICE9PSAndW5kZWZpbmVkJykge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5fc3Vic2NyaXB0aW9uLnVuc3Vic2NyaWJlKCk7XHJcbiAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgIHRoaXMuX2lzTG9hZGluZyA9IGZhbHNlO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgaWYgKGV2ZW50LmtleSA9PT0gJ0VudGVyJyAmJiB0eXBlb2YgaW5wdXRWYWwgIT09ICd1bmRlZmluZWQnICYmIGlucHV0VmFsICE9PSAnJykge1xyXG4gICAgICAgICAgICBpZiAodGhpcy5fdGV4dFNldHRpbmcubXVsdGlzZWxlY3QpIHtcclxuICAgICAgICAgICAgICAgIHRoaXMuc2VhcmNoTXVsdGkoaW5wdXRWYWwsICdzZWxlY3RlZCcpO1xyXG4gICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICBlbHNlIGlmICghdGhpcy5fdGV4dFNldHRpbmcubXVsdGlzZWxlY3QgJiYgdHlwZW9mIHRoaXMuY29uZmlnLnZhbHVlICE9PSAndW5kZWZpbmVkJyAmJiB0eXBlb2YgdGhpcy5jb25maWcudmFsdWUgIT09ICdvYmplY3QnKSB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLnNlYXJjaE11bHRpKGlucHV0VmFsLCAnc2VsZWN0ZWQnKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF9hZGRDbGlja0xpc3RlbmVyKF9xdWVyeVN0cmluZzogc3RyaW5nKTogdm9pZCB7XHJcbiAgICAgICAgbGV0IGNsaWNrRXZlbnRFbGU6IEhUTUxFbGVtZW50ID0gdGhpcy5fdmNyLmVsZW1lbnQubmF0aXZlRWxlbWVudC5xdWVyeVNlbGVjdG9yKF9xdWVyeVN0cmluZyk7XHJcblxyXG4gICAgICAgIHRoaXMuX3JlbmRlcmVyTGlzdGVuRnVuYyA9IHRoaXMuX3JlbmRlcmVyLmxpc3RlbihjbGlja0V2ZW50RWxlLCAnY2xpY2snLCAoX2V2ZW50OiBhbnkpOiB2b2lkID0+IHtcclxuICAgIHRoaXMuYXV0b2NvbXBsZXRlQ29tcG9uZW50LmhhbmRsZURyb3Bkb3duQ2xpY2soX2V2ZW50KTtcclxufSk7XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfdXBkYXRlUmVzdWx0TGlzdChfdmFsOiBhbnksIF9zdGF0ZTogc3RyaW5nKTogdm9pZCB7XHJcbiAgICAgICAgaWYgKF9zdGF0ZSA9PT0gJ3NlbGVjdGVkJykge1xyXG4gICAgICAgICAgICBmb3IgKGxldCBpOiBudW1iZXIgPSAwOyBpIDwgdGhpcy5fcmVzdWx0TGlzdC5sZW5ndGg7IGkrKykge1xyXG4gICAgICAgICAgICAgICAgaWYgKF92YWwudmFsdWUgPT09IHRoaXMuX3Jlc3VsdExpc3RbaV0udmFsdWUpIHtcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLl9yZXN1bHRMaXN0LnNwbGljZShpLCAxKTtcclxuICAgICAgICAgICAgICAgICAgICBicmVhaztcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgbGV0IHNvcnRGdW5jOiAoYTogYW55LCBiOiBhbnkpID0+IG51bWJlciA9IChhOiBhbnksIGI6IGFueSk6IG51bWJlciA9PiB7XHJcbiAgICAgICAgICAgICAgICBpZiAoYS52YWx1ZSA8IGIudmFsdWUpIHJldHVybiAtMTtcclxuICAgICAgICAgICAgICAgIGVsc2UgaWYgKGEudmFsdWUgPiBiLnZhbHVlKSByZXR1cm4gMTtcclxuICAgICAgICAgICAgICAgIHJldHVybiAwO1xyXG4gICAgICAgICAgICB9O1xyXG5cclxuICAgICAgICAgICAgdGhpcy5fcmVzdWx0TGlzdC5wdXNoKF92YWwpO1xyXG4gICAgICAgICAgICB0aGlzLl9yZXN1bHRMaXN0LnNvcnQoc29ydEZ1bmMpO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF9jaGVja1NlYXJjaFJlc3VsdChfdmFsdWU6IEFycmF5PGFueT4sIF9xdWVyeTogc3RyaW5nKTogdm9pZCB7XHJcbiAgICAgICAgbGV0IGZpbHRlcmVkT3B0aW9uczogQXJyYXk8YW55PiA9IHRoaXMuX3RleHRJbnB1dFN2Yy5maWx0ZXJPcHRpb25MaXN0KF92YWx1ZSwgdGhpcy5fdGV4dFZhbHVlKTtcclxuXHJcbiAgICAgICAgdGltZXIoKS5zdWJzY3JpYmUoKCk6IHZvaWQgPT4ge1xyXG4gICAgICAgICAgICB0aGlzLl9zdWdnZXN0aW9uTGlzdCA9IGZpbHRlcmVkT3B0aW9ucy5zbGljZSgpO1xyXG5cclxuICAgICAgICAgICAgbGV0IGNoZWNrZWRSZXN1bHQgPSB0aGlzLl90ZXh0SW5wdXRTdmMuY2hlY2tFcnJvcih0aGlzLl9zdWdnZXN0aW9uTGlzdCwgX3F1ZXJ5KTtcclxuXHJcbiAgICAgICAgICAgIGlmICh0eXBlb2YgY2hlY2tlZFJlc3VsdCAhPT0gJ3VuZGVmaW5lZCcpIHtcclxuICAgICAgICAgICAgICAgIGxldCByZXN1bHQ6IEFycmF5PHN0cmluZz4gPSBbXTtcclxuICAgICAgICAgICAgICAgIHJlc3VsdC5wdXNoKGNoZWNrZWRSZXN1bHQuZGlhbG9ndWVNZXNzYWdlKTtcclxuICAgICAgICAgICAgICAgIHRoaXMuY29uZmlnLmVycm9ycyA9IHJlc3VsdDtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH0pO1xyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX2NoZWNrTG9hZGluZ0Z1bmMoX3F1ZXJ5OiBzdHJpbmcpOiB2b2lkIHtcclxuICAgICAgICB0aGlzLl9pc0xvYWRpbmcgPSB0cnVlO1xyXG5cclxuICAgICAgICBsZXQgc2VsZWN0ZWRWYWwgPSAodHlwZW9mIHRoaXMuY29uZmlnLnZhbHVlICE9PSAndW5kZWZpbmVkJykgPyB0aGlzLmNvbmZpZy52YWx1ZSA6IFtdO1xyXG4gICAgICAgIGxldCBwYXJhbXMgPSB7cXVlcnk6IF9xdWVyeSwgY3VycmVudFNlbGVjdGVkOiBzZWxlY3RlZFZhbH07XHJcblxyXG4gICAgICAgIGlmICh0eXBlb2YgdGhpcy5fc3Vic2NyaXB0aW9uICE9PSAndW5kZWZpbmVkJykge1xyXG4gICAgICAgICAgICB0aGlzLl9zdWJzY3JpcHRpb24udW5zdWJzY3JpYmUoKTtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIHRoaXMuX3N1YnNjcmlwdGlvbiA9IHRoaXMuY29uZmlnLmRyb3Bkb3duQ2FsbGJhY2socGFyYW1zKS5zdWJzY3JpYmUoKF92YWx1ZTogYW55KTogdm9pZCA9PiB7XHJcbiAgICAgICAgICAgIC8vIGNvbnNvbGUubG9nKFwiPj4+IHZhbHVlXCIsIF92YWx1ZSk7XHJcbiAgICAgICAgICAgIHRoaXMuX2NoZWNrU2VhcmNoUmVzdWx0KF92YWx1ZSwgX3F1ZXJ5KTtcclxuICAgICAgICAgICAgdGhpcy5faXNMb2FkaW5nID0gZmFsc2U7XHJcbiAgICAgICAgfSk7XHJcbiAgICB9XHJcbn1cclxuIl19