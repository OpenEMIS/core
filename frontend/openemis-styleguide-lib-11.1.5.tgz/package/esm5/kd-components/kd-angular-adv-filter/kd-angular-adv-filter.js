import { __decorate, __metadata } from "tslib";
import { Component, Input, Output, EventEmitter, ViewEncapsulation, ViewContainerRef, HostBinding, OnInit, OnDestroy } from '@angular/core';
import { Router, NavigationEnd } from '@angular/router';
import { timer } from 'rxjs';
import { KdDomElemSvc } from '../kd-common/index';
import { KdAdvFilterEvent, KdIntAdvFilterEvent } from './kd-adv-filter-event';
var KdAdvFilter = /** @class */ (function () {
    function KdAdvFilter(_intAdvSearchEvent, _advSearchEvent, _domSvc, _vcr, _router) {
        this._intAdvSearchEvent = _intAdvSearchEvent;
        this._advSearchEvent = _advSearchEvent;
        this._domSvc = _domSvc;
        this._vcr = _vcr;
        this._router = _router;
        this.showSearch = false;
        this.api = {};
        this._formButtons = [
            {
                type: 'submit',
                name: 'Search',
                icon: 'kd-check',
                class: 'btn-text'
            },
            {
                type: 'reset',
                name: 'Reset',
                icon: 'kd-close',
                class: 'btn-outline'
            }
        ];
        this._toShow = false;
        this.fieldValue = new EventEmitter();
        this.formValue = new EventEmitter();
        this._classShow = false;
        this._classKdxAdvSearch = true;
    }
    KdAdvFilter.prototype.ngOnInit = function () {
        var _this = this;
        this._toggleSub = this._intAdvSearchEvent.onToggleAdvSearch().subscribe(function (val) {
            _this._toShow = (typeof val !== 'undefined') ? val : !_this._toShow;
            _this._startAnimation(_this._toShow);
            _this._intAdvSearchEvent.sendAdvSearchStatus(_this._toShow);
        });
        this._routerSub = this._router.events.subscribe(function (event) {
            if (event instanceof NavigationEnd) {
                _this._advSearchEvent.toggleAdvSearch(false);
            }
        });
    };
    KdAdvFilter.prototype.ngOnDestroy = function () {
        this._toggleSub.unsubscribe();
        this._routerSub.unsubscribe();
    };
    KdAdvFilter.prototype.closeSearch = function () {
        this._advSearchEvent.toggleAdvSearch(false);
    };
    KdAdvFilter.prototype.getTriggerInput = function (data) {
        this.fieldValue.emit(data);
    };
    KdAdvFilter.prototype.getValue = function (fieldVal) {
        this._searchQuery = fieldVal;
    };
    KdAdvFilter.prototype.formSubmitVal = function (formVal) {
        this.formValue.emit(formVal);
    };
    KdAdvFilter.prototype._startAnimation = function (isShow) {
        var _this = this;
        /*
            hide -> show
                - bring z-index up (_classShow)
                - animation right/left position via keyframe (_showSearch)

            show -> hide
                - animation right/left position via keyframe (_showSearch)
                - bring z-index down (_classShow)
         */
        if (isShow) {
            this._classShow = isShow;
            timer(200).subscribe(function () {
                _this.showSearch = isShow;
            });
        }
        else {
            this.showSearch = isShow;
            timer(300).subscribe(function () {
                _this._classShow = isShow;
                var scrollBackTop = _this._vcr.element.nativeElement.querySelector('.kdx-adv-search-body');
                scrollBackTop.scrollTop = 0;
            });
        }
        if (this._domSvc.isMobile())
            this._checkMainWrapperOverflow(isShow);
    };
    KdAdvFilter.prototype._checkMainWrapperOverflow = function (_isShow) {
        var toOverflow = (_isShow) ? 'hidden' : 'auto';
        var mainWrapperEle = document.body.querySelector('.main-wrapper');
        this._domSvc.setElementStyle(mainWrapperEle, 'overflow', toOverflow);
    };
    KdAdvFilter.ctorParameters = function () { return [
        { type: KdIntAdvFilterEvent },
        { type: KdAdvFilterEvent },
        { type: KdDomElemSvc },
        { type: ViewContainerRef },
        { type: Router }
    ]; };
    __decorate([
        Input(),
        __metadata("design:type", Array)
    ], KdAdvFilter.prototype, "formData", void 0);
    __decorate([
        Output(),
        __metadata("design:type", EventEmitter)
    ], KdAdvFilter.prototype, "fieldValue", void 0);
    __decorate([
        Output(),
        __metadata("design:type", EventEmitter)
    ], KdAdvFilter.prototype, "formValue", void 0);
    __decorate([
        HostBinding('class.show'),
        __metadata("design:type", Boolean)
    ], KdAdvFilter.prototype, "_classShow", void 0);
    __decorate([
        HostBinding('class.kdx-adv-search'),
        __metadata("design:type", Boolean)
    ], KdAdvFilter.prototype, "_classKdxAdvSearch", void 0);
    KdAdvFilter = __decorate([
        Component({
            selector: 'kd-adv-search',
            template: "<div [ngClass]=\"{'kdx-hide-adv': !showSearch, 'kdx-show-adv': showSearch}\" class=\"kdx-adv-search-wrapper\">\r\n    <div class=\"kdx-white-bg\">\r\n    </div>\r\n    <div class=\"kdx-adv-search-content\">\r\n        <div class=\"kdx-adv-search-header\">\r\n            <i class=\"fa fa-search-plus\"></i>\r\n            <h3>Advance Search</h3>\r\n            <button class=\"btn btn-icon btn-outline\" type=\"button\" (click)=\"closeSearch()\">\r\n                <i class=\"kd-close-round\"></i>\r\n            </button> s\r\n        </div>\r\n        <div class=\"kdx-adv-search-body\">\r\n            <kd-view \r\n            displayType=\"form\" \r\n            id=\"advance-search\" \r\n            [inputData]=\"formData\" \r\n            [button]=\"_formButtons\" \r\n            [api]=\"api\" \r\n            (detectFrom)=\"getTriggerInput($event)\" \r\n            (submitEvent)=\"formSubmitVal($event)\"></kd-view>\r\n        </div>\r\n    </div>\r\n</div>\r\n",
            encapsulation: ViewEncapsulation.None,
            providers: [KdIntAdvFilterEvent, KdAdvFilterEvent]
        }),
        __metadata("design:paramtypes", [KdIntAdvFilterEvent,
            KdAdvFilterEvent,
            KdDomElemSvc,
            ViewContainerRef,
            Router])
    ], KdAdvFilter);
    return KdAdvFilter;
}());
export { KdAdvFilter };
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoia2QtYW5ndWxhci1hZHYtZmlsdGVyLmpzIiwic291cmNlUm9vdCI6Im5nOi8vb3BlbmVtaXMtc3R5bGVndWlkZS1saWIvIiwic291cmNlcyI6WyJrZC1jb21wb25lbnRzL2tkLWFuZ3VsYXItYWR2LWZpbHRlci9rZC1hbmd1bGFyLWFkdi1maWx0ZXIudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IjtBQUFBLE9BQU8sRUFDSCxTQUFTLEVBQ1QsS0FBSyxFQUNMLE1BQU0sRUFDTixZQUFZLEVBQ1osaUJBQWlCLEVBQ2pCLGdCQUFnQixFQUNoQixXQUFXLEVBQ1gsTUFBTSxFQUNOLFNBQVMsRUFDWixNQUFNLGVBQWUsQ0FBQztBQUN2QixPQUFPLEVBQUUsTUFBTSxFQUFFLGFBQWEsRUFBRSxNQUFNLGlCQUFpQixDQUFDO0FBQ3hELE9BQU8sRUFBRSxLQUFLLEVBQWtCLE1BQU0sTUFBTSxDQUFDO0FBRTdDLE9BQU8sRUFBRSxZQUFZLEVBQUUsTUFBTSxvQkFBb0IsQ0FBQztBQUNsRCxPQUFPLEVBQUUsZ0JBQWdCLEVBQUUsbUJBQW1CLEVBQUUsTUFBTSx1QkFBdUIsQ0FBQztBQVE5RTtJQTZCSSxxQkFDWSxrQkFBdUMsRUFDdkMsZUFBaUMsRUFDakMsT0FBcUIsRUFDckIsSUFBc0IsRUFDdEIsT0FBZTtRQUpmLHVCQUFrQixHQUFsQixrQkFBa0IsQ0FBcUI7UUFDdkMsb0JBQWUsR0FBZixlQUFlLENBQWtCO1FBQ2pDLFlBQU8sR0FBUCxPQUFPLENBQWM7UUFDckIsU0FBSSxHQUFKLElBQUksQ0FBa0I7UUFDdEIsWUFBTyxHQUFQLE9BQU8sQ0FBUTtRQWpDcEIsZUFBVSxHQUFZLEtBQUssQ0FBQztRQUM1QixRQUFHLEdBQW9CLEVBQUUsQ0FBQztRQUMxQixpQkFBWSxHQUFlO1lBQzlCO2dCQUNJLElBQUksRUFBRSxRQUFRO2dCQUNkLElBQUksRUFBRSxRQUFRO2dCQUNkLElBQUksRUFBRSxVQUFVO2dCQUNoQixLQUFLLEVBQUUsVUFBVTthQUNwQjtZQUNEO2dCQUNJLElBQUksRUFBRSxPQUFPO2dCQUNiLElBQUksRUFBRSxPQUFPO2dCQUNiLElBQUksRUFBRSxVQUFVO2dCQUNoQixLQUFLLEVBQUUsYUFBYTthQUN2QjtTQUNKLENBQUM7UUFFTSxZQUFPLEdBQVksS0FBSyxDQUFDO1FBTXZCLGVBQVUsR0FBc0IsSUFBSSxZQUFZLEVBQUUsQ0FBQztRQUNuRCxjQUFTLEdBQXNCLElBQUksWUFBWSxFQUFFLENBQUM7UUFDakMsZUFBVSxHQUFZLEtBQUssQ0FBQztRQUNsQix1QkFBa0IsR0FBWSxJQUFJLENBQUM7SUFRcEUsQ0FBQztJQUVMLDhCQUFRLEdBQVI7UUFBQSxpQkFhQztRQVpHLElBQUksQ0FBQyxVQUFVLEdBQUcsSUFBSSxDQUFDLGtCQUFrQixDQUFDLGlCQUFpQixFQUFFLENBQUMsU0FBUyxDQUFDLFVBQUEsR0FBRztZQUN2RSxLQUFJLENBQUMsT0FBTyxHQUFHLENBQUMsT0FBTyxHQUFHLEtBQUssV0FBVyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFJLENBQUMsT0FBTyxDQUFDO1lBQ2xFLEtBQUksQ0FBQyxlQUFlLENBQUMsS0FBSSxDQUFDLE9BQU8sQ0FBQyxDQUFDO1lBRW5DLEtBQUksQ0FBQyxrQkFBa0IsQ0FBQyxtQkFBbUIsQ0FBQyxLQUFJLENBQUMsT0FBTyxDQUFDLENBQUM7UUFDOUQsQ0FBQyxDQUFDLENBQUM7UUFFSCxJQUFJLENBQUMsVUFBVSxHQUFHLElBQUksQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLFNBQVMsQ0FBQyxVQUFBLEtBQUs7WUFDakQsSUFBSSxLQUFLLFlBQVksYUFBYSxFQUFFO2dCQUNoQyxLQUFJLENBQUMsZUFBZSxDQUFDLGVBQWUsQ0FBQyxLQUFLLENBQUMsQ0FBQzthQUMvQztRQUNMLENBQUMsQ0FBQyxDQUFDO0lBQ1AsQ0FBQztJQUVELGlDQUFXLEdBQVg7UUFDSSxJQUFJLENBQUMsVUFBVSxDQUFDLFdBQVcsRUFBRSxDQUFDO1FBQzlCLElBQUksQ0FBQyxVQUFVLENBQUMsV0FBVyxFQUFFLENBQUM7SUFDbEMsQ0FBQztJQUVELGlDQUFXLEdBQVg7UUFDSSxJQUFJLENBQUMsZUFBZSxDQUFDLGVBQWUsQ0FBQyxLQUFLLENBQUMsQ0FBQztJQUNoRCxDQUFDO0lBRUQscUNBQWUsR0FBZixVQUFnQixJQUFTO1FBQ3JCLElBQUksQ0FBQyxVQUFVLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDO0lBQy9CLENBQUM7SUFFRCw4QkFBUSxHQUFSLFVBQVMsUUFBYTtRQUNsQixJQUFJLENBQUMsWUFBWSxHQUFHLFFBQVEsQ0FBQztJQUNqQyxDQUFDO0lBRUQsbUNBQWEsR0FBYixVQUFjLE9BQVk7UUFDdEIsSUFBSSxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLENBQUM7SUFDakMsQ0FBQztJQUVPLHFDQUFlLEdBQXZCLFVBQXdCLE1BQWU7UUFBdkMsaUJBMkJDO1FBMUJHOzs7Ozs7OztXQVFHO1FBQ0gsSUFBSSxNQUFNLEVBQUU7WUFDUixJQUFJLENBQUMsVUFBVSxHQUFHLE1BQU0sQ0FBQztZQUN6QixLQUFLLENBQUMsR0FBRyxDQUFDLENBQUMsU0FBUyxDQUFDO2dCQUNqQixLQUFJLENBQUMsVUFBVSxHQUFHLE1BQU0sQ0FBQztZQUM3QixDQUFDLENBQUMsQ0FBQztTQUNOO2FBQ0k7WUFDRCxJQUFJLENBQUMsVUFBVSxHQUFHLE1BQU0sQ0FBQztZQUN6QixLQUFLLENBQUMsR0FBRyxDQUFDLENBQUMsU0FBUyxDQUFDO2dCQUNqQixLQUFJLENBQUMsVUFBVSxHQUFHLE1BQU0sQ0FBQztnQkFFekIsSUFBSSxhQUFhLEdBQVksS0FBSSxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsYUFBYSxDQUFDLGFBQWEsQ0FBQyxzQkFBc0IsQ0FBQyxDQUFDO2dCQUNuRyxhQUFhLENBQUMsU0FBUyxHQUFHLENBQUMsQ0FBQztZQUNoQyxDQUFDLENBQUMsQ0FBQztTQUNOO1FBRUQsSUFBSSxJQUFJLENBQUMsT0FBTyxDQUFDLFFBQVEsRUFBRTtZQUFFLElBQUksQ0FBQyx5QkFBeUIsQ0FBQyxNQUFNLENBQUMsQ0FBQztJQUN4RSxDQUFDO0lBRU8sK0NBQXlCLEdBQWpDLFVBQWtDLE9BQWdCO1FBQzlDLElBQUksVUFBVSxHQUFXLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDO1FBQ3ZELElBQUksY0FBYyxHQUFZLFFBQVEsQ0FBQyxJQUFJLENBQUMsYUFBYSxDQUFDLGVBQWUsQ0FBQyxDQUFDO1FBQzNFLElBQUksQ0FBQyxPQUFPLENBQUMsZUFBZSxDQUFDLGNBQWMsRUFBRSxVQUFVLEVBQUUsVUFBVSxDQUFDLENBQUM7SUFDekUsQ0FBQzs7Z0JBNUUrQixtQkFBbUI7Z0JBQ3RCLGdCQUFnQjtnQkFDeEIsWUFBWTtnQkFDZixnQkFBZ0I7Z0JBQ2IsTUFBTTs7SUFYbEI7UUFBUixLQUFLLEVBQUU7a0NBQVcsS0FBSztpREFBTTtJQUNwQjtRQUFULE1BQU0sRUFBRTtrQ0FBYSxZQUFZO21EQUEyQjtJQUNuRDtRQUFULE1BQU0sRUFBRTtrQ0FBWSxZQUFZO2tEQUEyQjtJQUNqQztRQUExQixXQUFXLENBQUMsWUFBWSxDQUFDOzttREFBNkI7SUFDbEI7UUFBcEMsV0FBVyxDQUFDLHNCQUFzQixDQUFDOzsyREFBb0M7SUEzQi9ELFdBQVc7UUFOdkIsU0FBUyxDQUFDO1lBQ1AsUUFBUSxFQUFFLGVBQWU7WUFDekIsdzlCQUEyQztZQUMzQyxhQUFhLEVBQUUsaUJBQWlCLENBQUMsSUFBSTtZQUNyQyxTQUFTLEVBQUUsQ0FBQyxtQkFBbUIsRUFBRSxnQkFBZ0IsQ0FBQztTQUNyRCxDQUFDO3lDQStCa0MsbUJBQW1CO1lBQ3RCLGdCQUFnQjtZQUN4QixZQUFZO1lBQ2YsZ0JBQWdCO1lBQ2IsTUFBTTtPQWxDbEIsV0FBVyxDQTJHdkI7SUFBRCxrQkFBQztDQUFBLEFBM0dELElBMkdDO1NBM0dZLFdBQVciLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQge1xyXG4gICAgQ29tcG9uZW50LFxyXG4gICAgSW5wdXQsXHJcbiAgICBPdXRwdXQsXHJcbiAgICBFdmVudEVtaXR0ZXIsXHJcbiAgICBWaWV3RW5jYXBzdWxhdGlvbixcclxuICAgIFZpZXdDb250YWluZXJSZWYsXHJcbiAgICBIb3N0QmluZGluZyxcclxuICAgIE9uSW5pdCxcclxuICAgIE9uRGVzdHJveVxyXG59IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xyXG5pbXBvcnQgeyBSb3V0ZXIsIE5hdmlnYXRpb25FbmQgfSBmcm9tICdAYW5ndWxhci9yb3V0ZXInO1xyXG5pbXBvcnQgeyB0aW1lciAsICBTdWJzY3JpcHRpb24gfSBmcm9tICdyeGpzJztcclxuaW1wb3J0IHsgSUR5bmFtaWNGb3JtQXBpIH0gZnJvbSAnLi4va2QtYW5ndWxhci12aWV3L2luZGV4JztcclxuaW1wb3J0IHsgS2REb21FbGVtU3ZjIH0gZnJvbSAnLi4va2QtY29tbW9uL2luZGV4JztcclxuaW1wb3J0IHsgS2RBZHZGaWx0ZXJFdmVudCwgS2RJbnRBZHZGaWx0ZXJFdmVudCB9IGZyb20gJy4va2QtYWR2LWZpbHRlci1ldmVudCc7XHJcblxyXG5AQ29tcG9uZW50KHtcclxuICAgIHNlbGVjdG9yOiAna2QtYWR2LXNlYXJjaCcsXHJcbiAgICB0ZW1wbGF0ZVVybDogJy4va2QtYW5ndWxhci1hZHYtZmlsdGVyLmh0bWwnLFxyXG4gICAgZW5jYXBzdWxhdGlvbjogVmlld0VuY2Fwc3VsYXRpb24uTm9uZSxcclxuICAgIHByb3ZpZGVyczogW0tkSW50QWR2RmlsdGVyRXZlbnQsIEtkQWR2RmlsdGVyRXZlbnRdXHJcbn0pXHJcbmV4cG9ydCBjbGFzcyBLZEFkdkZpbHRlciBpbXBsZW1lbnRzIE9uSW5pdCwgT25EZXN0cm95IHtcclxuICAgIHB1YmxpYyBzaG93U2VhcmNoOiBib29sZWFuID0gZmFsc2U7XHJcbiAgICBwdWJsaWMgYXBpOiBJRHluYW1pY0Zvcm1BcGkgPSB7fTtcclxuICAgIHB1YmxpYyBfZm9ybUJ1dHRvbnM6IEFycmF5PGFueT4gPSBbXHJcbiAgICAgICAge1xyXG4gICAgICAgICAgICB0eXBlOiAnc3VibWl0JyxcclxuICAgICAgICAgICAgbmFtZTogJ1NlYXJjaCcsXHJcbiAgICAgICAgICAgIGljb246ICdrZC1jaGVjaycsXHJcbiAgICAgICAgICAgIGNsYXNzOiAnYnRuLXRleHQnXHJcbiAgICAgICAgfSxcclxuICAgICAgICB7XHJcbiAgICAgICAgICAgIHR5cGU6ICdyZXNldCcsXHJcbiAgICAgICAgICAgIG5hbWU6ICdSZXNldCcsXHJcbiAgICAgICAgICAgIGljb246ICdrZC1jbG9zZScsXHJcbiAgICAgICAgICAgIGNsYXNzOiAnYnRuLW91dGxpbmUnXHJcbiAgICAgICAgfVxyXG4gICAgXTtcclxuXHJcbiAgICBwcml2YXRlIF90b1Nob3c6IGJvb2xlYW4gPSBmYWxzZTtcclxuICAgIHByaXZhdGUgX3NlYXJjaFF1ZXJ5OiBhbnk7XHJcbiAgICBwcml2YXRlIF90b2dnbGVTdWI6IFN1YnNjcmlwdGlvbjtcclxuICAgIHByaXZhdGUgX3JvdXRlclN1YjogU3Vic2NyaXB0aW9uO1xyXG5cclxuICAgIEBJbnB1dCgpIGZvcm1EYXRhOiBBcnJheTxhbnk+O1xyXG4gICAgQE91dHB1dCgpIGZpZWxkVmFsdWU6IEV2ZW50RW1pdHRlcjxhbnk+ID0gbmV3IEV2ZW50RW1pdHRlcigpO1xyXG4gICAgQE91dHB1dCgpIGZvcm1WYWx1ZTogRXZlbnRFbWl0dGVyPGFueT4gPSBuZXcgRXZlbnRFbWl0dGVyKCk7XHJcbiAgICBASG9zdEJpbmRpbmcoJ2NsYXNzLnNob3cnKSBfY2xhc3NTaG93OiBib29sZWFuID0gZmFsc2U7XHJcbiAgICBASG9zdEJpbmRpbmcoJ2NsYXNzLmtkeC1hZHYtc2VhcmNoJykgX2NsYXNzS2R4QWR2U2VhcmNoOiBib29sZWFuID0gdHJ1ZTtcclxuXHJcbiAgICBjb25zdHJ1Y3RvcihcclxuICAgICAgICBwcml2YXRlIF9pbnRBZHZTZWFyY2hFdmVudDogS2RJbnRBZHZGaWx0ZXJFdmVudCxcclxuICAgICAgICBwcml2YXRlIF9hZHZTZWFyY2hFdmVudDogS2RBZHZGaWx0ZXJFdmVudCxcclxuICAgICAgICBwcml2YXRlIF9kb21TdmM6IEtkRG9tRWxlbVN2YyxcclxuICAgICAgICBwcml2YXRlIF92Y3I6IFZpZXdDb250YWluZXJSZWYsXHJcbiAgICAgICAgcHJpdmF0ZSBfcm91dGVyOiBSb3V0ZXJcclxuICAgICkgeyB9XHJcblxyXG4gICAgbmdPbkluaXQoKTogdm9pZCB7XHJcbiAgICAgICAgdGhpcy5fdG9nZ2xlU3ViID0gdGhpcy5faW50QWR2U2VhcmNoRXZlbnQub25Ub2dnbGVBZHZTZWFyY2goKS5zdWJzY3JpYmUodmFsID0+IHtcclxuICAgICAgICAgICAgdGhpcy5fdG9TaG93ID0gKHR5cGVvZiB2YWwgIT09ICd1bmRlZmluZWQnKSA/IHZhbCA6ICF0aGlzLl90b1Nob3c7XHJcbiAgICAgICAgICAgIHRoaXMuX3N0YXJ0QW5pbWF0aW9uKHRoaXMuX3RvU2hvdyk7XHJcblxyXG4gICAgICAgICAgICB0aGlzLl9pbnRBZHZTZWFyY2hFdmVudC5zZW5kQWR2U2VhcmNoU3RhdHVzKHRoaXMuX3RvU2hvdyk7XHJcbiAgICAgICAgfSk7XHJcblxyXG4gICAgICAgIHRoaXMuX3JvdXRlclN1YiA9IHRoaXMuX3JvdXRlci5ldmVudHMuc3Vic2NyaWJlKGV2ZW50ID0+IHtcclxuICAgICAgICAgICAgaWYgKGV2ZW50IGluc3RhbmNlb2YgTmF2aWdhdGlvbkVuZCkge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5fYWR2U2VhcmNoRXZlbnQudG9nZ2xlQWR2U2VhcmNoKGZhbHNlKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH0pO1xyXG4gICAgfVxyXG5cclxuICAgIG5nT25EZXN0cm95KCk6IHZvaWQge1xyXG4gICAgICAgIHRoaXMuX3RvZ2dsZVN1Yi51bnN1YnNjcmliZSgpO1xyXG4gICAgICAgIHRoaXMuX3JvdXRlclN1Yi51bnN1YnNjcmliZSgpO1xyXG4gICAgfVxyXG5cclxuICAgIGNsb3NlU2VhcmNoKCk6IHZvaWQge1xyXG4gICAgICAgIHRoaXMuX2FkdlNlYXJjaEV2ZW50LnRvZ2dsZUFkdlNlYXJjaChmYWxzZSk7XHJcbiAgICB9XHJcblxyXG4gICAgZ2V0VHJpZ2dlcklucHV0KGRhdGE6IGFueSk6IHZvaWQge1xyXG4gICAgICAgIHRoaXMuZmllbGRWYWx1ZS5lbWl0KGRhdGEpO1xyXG4gICAgfVxyXG5cclxuICAgIGdldFZhbHVlKGZpZWxkVmFsOiBhbnkpOiB2b2lkIHtcclxuICAgICAgICB0aGlzLl9zZWFyY2hRdWVyeSA9IGZpZWxkVmFsO1xyXG4gICAgfVxyXG5cclxuICAgIGZvcm1TdWJtaXRWYWwoZm9ybVZhbDogYW55KTogdm9pZCB7XHJcbiAgICAgICAgdGhpcy5mb3JtVmFsdWUuZW1pdChmb3JtVmFsKTtcclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF9zdGFydEFuaW1hdGlvbihpc1Nob3c6IGJvb2xlYW4pOiB2b2lkIHtcclxuICAgICAgICAvKlxyXG4gICAgICAgICAgICBoaWRlIC0+IHNob3dcclxuICAgICAgICAgICAgICAgIC0gYnJpbmcgei1pbmRleCB1cCAoX2NsYXNzU2hvdylcclxuICAgICAgICAgICAgICAgIC0gYW5pbWF0aW9uIHJpZ2h0L2xlZnQgcG9zaXRpb24gdmlhIGtleWZyYW1lIChfc2hvd1NlYXJjaClcclxuXHJcbiAgICAgICAgICAgIHNob3cgLT4gaGlkZVxyXG4gICAgICAgICAgICAgICAgLSBhbmltYXRpb24gcmlnaHQvbGVmdCBwb3NpdGlvbiB2aWEga2V5ZnJhbWUgKF9zaG93U2VhcmNoKVxyXG4gICAgICAgICAgICAgICAgLSBicmluZyB6LWluZGV4IGRvd24gKF9jbGFzc1Nob3cpXHJcbiAgICAgICAgICovXHJcbiAgICAgICAgaWYgKGlzU2hvdykge1xyXG4gICAgICAgICAgICB0aGlzLl9jbGFzc1Nob3cgPSBpc1Nob3c7XHJcbiAgICAgICAgICAgIHRpbWVyKDIwMCkuc3Vic2NyaWJlKCgpOiB2b2lkID0+IHtcclxuICAgICAgICAgICAgICAgIHRoaXMuc2hvd1NlYXJjaCA9IGlzU2hvdztcclxuICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICB0aGlzLnNob3dTZWFyY2ggPSBpc1Nob3c7XHJcbiAgICAgICAgICAgIHRpbWVyKDMwMCkuc3Vic2NyaWJlKCgpOiB2b2lkID0+IHtcclxuICAgICAgICAgICAgICAgIHRoaXMuX2NsYXNzU2hvdyA9IGlzU2hvdztcclxuXHJcbiAgICAgICAgICAgICAgICBsZXQgc2Nyb2xsQmFja1RvcDogRWxlbWVudCA9IHRoaXMuX3Zjci5lbGVtZW50Lm5hdGl2ZUVsZW1lbnQucXVlcnlTZWxlY3RvcignLmtkeC1hZHYtc2VhcmNoLWJvZHknKTtcclxuICAgICAgICAgICAgICAgIHNjcm9sbEJhY2tUb3Auc2Nyb2xsVG9wID0gMDtcclxuICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICBpZiAodGhpcy5fZG9tU3ZjLmlzTW9iaWxlKCkpIHRoaXMuX2NoZWNrTWFpbldyYXBwZXJPdmVyZmxvdyhpc1Nob3cpO1xyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX2NoZWNrTWFpbldyYXBwZXJPdmVyZmxvdyhfaXNTaG93OiBib29sZWFuKTogdm9pZCB7XHJcbiAgICAgICAgbGV0IHRvT3ZlcmZsb3c6IHN0cmluZyA9IChfaXNTaG93KSA/ICdoaWRkZW4nIDogJ2F1dG8nO1xyXG4gICAgICAgIGxldCBtYWluV3JhcHBlckVsZTogRWxlbWVudCA9IGRvY3VtZW50LmJvZHkucXVlcnlTZWxlY3RvcignLm1haW4td3JhcHBlcicpO1xyXG4gICAgICAgIHRoaXMuX2RvbVN2Yy5zZXRFbGVtZW50U3R5bGUobWFpbldyYXBwZXJFbGUsICdvdmVyZmxvdycsIHRvT3ZlcmZsb3cpO1xyXG4gICAgfVxyXG59XHJcbiJdfQ==