import { __decorate, __metadata } from "tslib";
import { Injectable } from '@angular/core';
import { KdBroadcaster } from '../kd-common/index';
import * as i0 from "@angular/core";
import * as i1 from "../kd-common/kd-broadcaster-svc";
var KdIntAdvFilterEvent = /** @class */ (function () {
    function KdIntAdvFilterEvent(_broadcaster) {
        this._broadcaster = _broadcaster;
    }
    KdIntAdvFilterEvent.prototype.onToggleAdvSearch = function () {
        return this._broadcaster.on('KDToggleAdvSearch');
    };
    KdIntAdvFilterEvent.prototype.onSendData = function () {
        return this._broadcaster.on('KdFormValue');
    };
    KdIntAdvFilterEvent.prototype.sendAdvSearchStatus = function (data) {
        this._broadcaster.broadcast('KdSendShowStatus', data);
    };
    KdIntAdvFilterEvent.ctorParameters = function () { return [
        { type: KdBroadcaster }
    ]; };
    KdIntAdvFilterEvent = __decorate([
        Injectable(),
        __metadata("design:paramtypes", [KdBroadcaster])
    ], KdIntAdvFilterEvent);
    return KdIntAdvFilterEvent;
}());
export { KdIntAdvFilterEvent };
var KdAdvFilterEvent = /** @class */ (function () {
    function KdAdvFilterEvent(_broadcaster) {
        this._broadcaster = _broadcaster;
    }
    KdAdvFilterEvent.prototype.toggleAdvSearch = function (data) {
        this._broadcaster.broadcast('KDToggleAdvSearch', data);
    };
    KdAdvFilterEvent.prototype.sendData = function (data) {
        this._broadcaster.broadcast('KdFormValue', data);
    };
    KdAdvFilterEvent.prototype.onSendAdvSearchStatus = function (data) {
        return this._broadcaster.on('KdSendShowStatus');
    };
    KdAdvFilterEvent.ctorParameters = function () { return [
        { type: KdBroadcaster }
    ]; };
    KdAdvFilterEvent.ɵprov = i0.ɵɵdefineInjectable({ factory: function KdAdvFilterEvent_Factory() { return new KdAdvFilterEvent(i0.ɵɵinject(i1.KdBroadcaster)); }, token: KdAdvFilterEvent, providedIn: "root" });
    KdAdvFilterEvent = __decorate([
        Injectable({
            providedIn: 'root'
        }),
        __metadata("design:paramtypes", [KdBroadcaster])
    ], KdAdvFilterEvent);
    return KdAdvFilterEvent;
}());
export { KdAdvFilterEvent };
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoia2QtYWR2LWZpbHRlci1ldmVudC5qcyIsInNvdXJjZVJvb3QiOiJuZzovL29wZW5lbWlzLXN0eWxlZ3VpZGUtbGliLyIsInNvdXJjZXMiOlsia2QtY29tcG9uZW50cy9rZC1hbmd1bGFyLWFkdi1maWx0ZXIva2QtYWR2LWZpbHRlci1ldmVudC50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiO0FBQUEsT0FBTyxFQUFFLFVBQVUsRUFBRSxNQUFNLGVBQWUsQ0FBQztBQUUzQyxPQUFPLEVBQUUsYUFBYSxFQUFFLE1BQU0sb0JBQW9CLENBQUM7OztBQUduRDtJQUNJLDZCQUFvQixZQUEyQjtRQUEzQixpQkFBWSxHQUFaLFlBQVksQ0FBZTtJQUFJLENBQUM7SUFFcEQsK0NBQWlCLEdBQWpCO1FBQ0ksT0FBTyxJQUFJLENBQUMsWUFBWSxDQUFDLEVBQUUsQ0FBTSxtQkFBbUIsQ0FBQyxDQUFDO0lBQzFELENBQUM7SUFFRCx3Q0FBVSxHQUFWO1FBQ0ksT0FBTyxJQUFJLENBQUMsWUFBWSxDQUFDLEVBQUUsQ0FBTSxhQUFhLENBQUMsQ0FBQztJQUNwRCxDQUFDO0lBRUQsaURBQW1CLEdBQW5CLFVBQW9CLElBQVU7UUFDMUIsSUFBSSxDQUFDLFlBQVksQ0FBQyxTQUFTLENBQUMsa0JBQWtCLEVBQUUsSUFBSSxDQUFDLENBQUM7SUFDMUQsQ0FBQzs7Z0JBWmlDLGFBQWE7O0lBRHRDLG1CQUFtQjtRQUQvQixVQUFVLEVBQUU7eUNBRXlCLGFBQWE7T0FEdEMsbUJBQW1CLENBYy9CO0lBQUQsMEJBQUM7Q0FBQSxBQWRELElBY0M7U0FkWSxtQkFBbUI7QUFtQmhDO0lBQ0ksMEJBQW9CLFlBQTJCO1FBQTNCLGlCQUFZLEdBQVosWUFBWSxDQUFlO0lBQUksQ0FBQztJQUVwRCwwQ0FBZSxHQUFmLFVBQWdCLElBQVU7UUFDdEIsSUFBSSxDQUFDLFlBQVksQ0FBQyxTQUFTLENBQUMsbUJBQW1CLEVBQUUsSUFBSSxDQUFDLENBQUM7SUFDM0QsQ0FBQztJQUVELG1DQUFRLEdBQVIsVUFBUyxJQUFVO1FBQ2YsSUFBSSxDQUFDLFlBQVksQ0FBQyxTQUFTLENBQUMsYUFBYSxFQUFFLElBQUksQ0FBQyxDQUFDO0lBQ3JELENBQUM7SUFFRCxnREFBcUIsR0FBckIsVUFBc0IsSUFBVTtRQUM1QixPQUFPLElBQUksQ0FBQyxZQUFZLENBQUMsRUFBRSxDQUFNLGtCQUFrQixDQUFDLENBQUM7SUFDekQsQ0FBQzs7Z0JBWmlDLGFBQWE7OztJQUR0QyxnQkFBZ0I7UUFINUIsVUFBVSxDQUFDO1lBQ1IsVUFBVSxFQUFFLE1BQU07U0FDckIsQ0FBQzt5Q0FFb0MsYUFBYTtPQUR0QyxnQkFBZ0IsQ0FjNUI7MkJBdENEO0NBc0NDLEFBZEQsSUFjQztTQWRZLGdCQUFnQiIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IEluamVjdGFibGUgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcclxuaW1wb3J0IHsgT2JzZXJ2YWJsZSB9IGZyb20gJ3J4anMnO1xyXG5pbXBvcnQgeyBLZEJyb2FkY2FzdGVyIH0gZnJvbSAnLi4va2QtY29tbW9uL2luZGV4JztcclxuXHJcbkBJbmplY3RhYmxlKClcclxuZXhwb3J0IGNsYXNzIEtkSW50QWR2RmlsdGVyRXZlbnQge1xyXG4gICAgY29uc3RydWN0b3IocHJpdmF0ZSBfYnJvYWRjYXN0ZXI6IEtkQnJvYWRjYXN0ZXIpIHsgfVxyXG5cclxuICAgIG9uVG9nZ2xlQWR2U2VhcmNoKCk6IE9ic2VydmFibGU8YW55PiB7XHJcbiAgICAgICAgcmV0dXJuIHRoaXMuX2Jyb2FkY2FzdGVyLm9uPGFueT4oJ0tEVG9nZ2xlQWR2U2VhcmNoJyk7XHJcbiAgICB9XHJcblxyXG4gICAgb25TZW5kRGF0YSgpOiBPYnNlcnZhYmxlPGFueT4ge1xyXG4gICAgICAgIHJldHVybiB0aGlzLl9icm9hZGNhc3Rlci5vbjxhbnk+KCdLZEZvcm1WYWx1ZScpO1xyXG4gICAgfVxyXG5cclxuICAgIHNlbmRBZHZTZWFyY2hTdGF0dXMoZGF0YT86IGFueSk6IHZvaWQge1xyXG4gICAgICAgIHRoaXMuX2Jyb2FkY2FzdGVyLmJyb2FkY2FzdCgnS2RTZW5kU2hvd1N0YXR1cycsIGRhdGEpO1xyXG4gICAgfVxyXG59XHJcblxyXG5ASW5qZWN0YWJsZSh7XHJcbiAgICBwcm92aWRlZEluOiAncm9vdCdcclxufSlcclxuZXhwb3J0IGNsYXNzIEtkQWR2RmlsdGVyRXZlbnQge1xyXG4gICAgY29uc3RydWN0b3IocHJpdmF0ZSBfYnJvYWRjYXN0ZXI6IEtkQnJvYWRjYXN0ZXIpIHsgfVxyXG5cclxuICAgIHRvZ2dsZUFkdlNlYXJjaChkYXRhPzogYW55KTogdm9pZCB7XHJcbiAgICAgICAgdGhpcy5fYnJvYWRjYXN0ZXIuYnJvYWRjYXN0KCdLRFRvZ2dsZUFkdlNlYXJjaCcsIGRhdGEpO1xyXG4gICAgfVxyXG5cclxuICAgIHNlbmREYXRhKGRhdGE/OiBhbnkpOiB2b2lkIHtcclxuICAgICAgICB0aGlzLl9icm9hZGNhc3Rlci5icm9hZGNhc3QoJ0tkRm9ybVZhbHVlJywgZGF0YSk7XHJcbiAgICB9XHJcblxyXG4gICAgb25TZW5kQWR2U2VhcmNoU3RhdHVzKGRhdGE/OiBhbnkpOiBPYnNlcnZhYmxlPGFueT4ge1xyXG4gICAgICAgIHJldHVybiB0aGlzLl9icm9hZGNhc3Rlci5vbjxhbnk+KCdLZFNlbmRTaG93U3RhdHVzJyk7XHJcbiAgICB9XHJcbn1cclxuIl19