import { __decorate, __metadata } from "tslib";
import { Component, Input, ViewChild } from '@angular/core';
import { NgbModal, ModalDismissReasons, NgbActiveModal, NgbModalRef } from '@ng-bootstrap/ng-bootstrap';
import { KdModalEvent } from './kd-modal-event';
export { KdModalEvent } from './kd-modal-event';
var KdModal = /** @class */ (function () {
    function KdModal(_ngbModal, _modalEvent) {
        this._ngbModal = _ngbModal;
        this._modalEvent = _modalEvent;
        this._isBodyExist = false;
        this._modalDefault = {
            suspendClose: false,
            title: 'Modal Title',
            body: 'Modal Body Text.',
            button: [
                {
                    text: 'Cancel',
                    class: 'btn-outline',
                    callback: function () { }
                }
            ]
        };
    }
    KdModal.prototype.ngOnInit = function () {
        var _this = this;
        this.defaultConfig();
        this._modalOpenSub = this._modalEvent.onToggleOpen().subscribe(function (val) {
            if (typeof val === 'undefined' || _this.config.id === val) {
                _this._curModal = _this._ngbModal.open(_this.contentRef);
                // console.log(this._curModal.close);
                // console.log('am i modal loaded', val);
                // if (typeof this.config.id === 'undefined') this.open(this.contentRef);
                // else if (val === this.config.id) this.open(this.contentRef);
                _this._curModal.result.then(function (_result) {
                    _this.closeResult = "Closed with: " + _result;
                    // console.log('_result : ', this.closeResult);
                }, function (_reason) {
                    _this.closeResult = "Dismissed " + _this._getDismissReason(_reason);
                    // console.log('_reason : ', this.closeResult);
                });
            }
        });
        this._modalCloseSub = this._modalEvent.onToggleClose().subscribe(function (val) {
            if (typeof val === 'undefined' || _this.config.id === val) {
                _this._curModal.close();
            }
        });
    };
    KdModal.prototype.ngOnChanges = function () {
        this.defaultConfig();
    };
    KdModal.prototype.ngOnDestroy = function () {
        this._modalOpenSub.unsubscribe();
    };
    KdModal.prototype.defaultConfig = function () {
        if (typeof this.config !== 'undefined') {
            this._modalDefault = this.config;
            if (typeof this._modalDefault.button !== 'undefined') {
                for (var i = 0; i < this._modalDefault.button.length; i++) {
                    if (typeof this.config !== 'undefined')
                        this._modalDefault.button[i] = this.config.button[i];
                }
            }
            if (typeof this.config.body !== 'undefined' && this.config.body !== '')
                this._isBodyExist = true;
        }
    };
    KdModal.prototype.callback = function (event, btn) {
        if (typeof btn.callback === 'function')
            btn.callback(event, btn);
    };
    KdModal.prototype._getDismissReason = function (reason) {
        if (reason === ModalDismissReasons.ESC)
            return 'by pressing ESC';
        else if (reason === ModalDismissReasons.BACKDROP_CLICK)
            return 'by clicking on a backdrop';
        else
            return "with: " + reason;
    };
    KdModal.ctorParameters = function () { return [
        { type: NgbModal },
        { type: KdModalEvent }
    ]; };
    __decorate([
        Input(),
        __metadata("design:type", Object)
    ], KdModal.prototype, "config", void 0);
    __decorate([
        ViewChild('content', { static: true }),
        __metadata("design:type", Object)
    ], KdModal.prototype, "contentRef", void 0);
    KdModal = __decorate([
        Component({
            selector: 'kd-modal',
            template: "<ng-template ngbModalContainer #content let-c=\"close\" let-d=\"dismiss\">\r\n    <div class=\"kdx-modal-dialog-wrapper\">\r\n        <div class=\"modal-header\">\r\n            <h4 class=\"modal-title\">{{_modalDefault.title}}</h4>\r\n            <button  *ngIf=\"!_modalDefault.suspendClose\" type=\"button\" class=\"close\" aria-label=\"Close\" (click)=\"d('Cross click')\">\r\n              <i class=\"kd-close-round\" aria-hidden=\"true\"></i>\r\n            </button>\r\n        </div>\r\n        <div class=\"modal-body\">\r\n            <p *ngIf=\"_isBodyExist\">{{_modalDefault.body}}</p>\r\n            <ng-content *ngIf=\"!_isBodyExist\"></ng-content>\r\n        </div>\r\n        <div class=\"modal-footer\">\r\n            <button type=\"button\" class=\"btn\" ngClass=\"{{btn.class}}\" *ngFor=\"let btn of _modalDefault.button\" (click)=\"callback($event, btn)\">\r\n                {{btn.text}}\r\n            </button>\r\n            <!-- <button type=\"button\" class=\"btn {{btn.class}}\" (click)=\"c('Close click')\">{{btn.text}}</button> -->\r\n        </div>\r\n    </div>\r\n</ng-template>\r\n<!-- <pre>{{closeResult}}</pre> -->\r\n",
            providers: [KdModalEvent, NgbActiveModal]
        }),
        __metadata("design:paramtypes", [NgbModal,
            KdModalEvent])
    ], KdModal);
    return KdModal;
}());
export { KdModal };
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoia2QtYW5ndWxhci1tb2RhbC5qcyIsInNvdXJjZVJvb3QiOiJuZzovL29wZW5lbWlzLXN0eWxlZ3VpZGUtbGliLyIsInNvdXJjZXMiOlsia2QtY29tcG9uZW50cy9rZC1hbmd1bGFyLW1vZGFsL2tkLWFuZ3VsYXItbW9kYWwudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IjtBQUFBLE9BQU8sRUFDSCxTQUFTLEVBQ1QsS0FBSyxFQUVMLFNBQVMsRUFFWixNQUFNLGVBQWUsQ0FBQztBQUV2QixPQUFPLEVBQUUsUUFBUSxFQUFFLG1CQUFtQixFQUFFLGNBQWMsRUFBRSxXQUFXLEVBQUUsTUFBTSw0QkFBNEIsQ0FBQztBQUN4RyxPQUFPLEVBQUUsWUFBWSxFQUFFLE1BQU0sa0JBQWtCLENBQUM7QUFHaEQsT0FBTyxFQUFFLFlBQVksRUFBRSxNQUFNLGtCQUFrQixDQUFDO0FBUWhEO0lBc0JJLGlCQUNZLFNBQW1CLEVBQ25CLFdBQXlCO1FBRHpCLGNBQVMsR0FBVCxTQUFTLENBQVU7UUFDbkIsZ0JBQVcsR0FBWCxXQUFXLENBQWM7UUF0QjlCLGlCQUFZLEdBQVksS0FBSyxDQUFDO1FBS3JDLGtCQUFhLEdBQVE7WUFDakIsWUFBWSxFQUFFLEtBQUs7WUFDbkIsS0FBSyxFQUFFLGFBQWE7WUFDcEIsSUFBSSxFQUFFLGtCQUFrQjtZQUN4QixNQUFNLEVBQUU7Z0JBQ0o7b0JBQ0ksSUFBSSxFQUFFLFFBQVE7b0JBQ2QsS0FBSyxFQUFFLGFBQWE7b0JBQ3BCLFFBQVEsRUFBRSxjQUFjLENBQUM7aUJBQzVCO2FBQUM7U0FDVCxDQUFDO0lBUUUsQ0FBQztJQUVMLDBCQUFRLEdBQVI7UUFBQSxpQkF3QkM7UUF2QkcsSUFBSSxDQUFDLGFBQWEsRUFBRSxDQUFDO1FBQ3JCLElBQUksQ0FBQyxhQUFhLEdBQUcsSUFBSSxDQUFDLFdBQVcsQ0FBQyxZQUFZLEVBQUUsQ0FBQyxTQUFTLENBQUMsVUFBQSxHQUFHO1lBQzlELElBQUksT0FBTyxHQUFHLEtBQUssV0FBVyxJQUFJLEtBQUksQ0FBQyxNQUFNLENBQUMsRUFBRSxLQUFLLEdBQUcsRUFBRTtnQkFDdEQsS0FBSSxDQUFDLFNBQVMsR0FBRyxLQUFJLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQyxLQUFJLENBQUMsVUFBVSxDQUFDLENBQUM7Z0JBQ3RELHFDQUFxQztnQkFDckMseUNBQXlDO2dCQUN6Qyx5RUFBeUU7Z0JBQ3pFLCtEQUErRDtnQkFDL0QsS0FBSSxDQUFDLFNBQVMsQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLFVBQUMsT0FBTztvQkFDL0IsS0FBSSxDQUFDLFdBQVcsR0FBRyxrQkFBZ0IsT0FBUyxDQUFDO29CQUM3QywrQ0FBK0M7Z0JBQ25ELENBQUMsRUFBRSxVQUFDLE9BQU87b0JBQ1AsS0FBSSxDQUFDLFdBQVcsR0FBRyxlQUFhLEtBQUksQ0FBQyxpQkFBaUIsQ0FBQyxPQUFPLENBQUcsQ0FBQztvQkFDbEUsK0NBQStDO2dCQUNuRCxDQUFDLENBQUMsQ0FBQzthQUNOO1FBQ0wsQ0FBQyxDQUFDLENBQUM7UUFFSCxJQUFJLENBQUMsY0FBYyxHQUFHLElBQUksQ0FBQyxXQUFXLENBQUMsYUFBYSxFQUFFLENBQUMsU0FBUyxDQUFDLFVBQUEsR0FBRztZQUNoRSxJQUFJLE9BQU8sR0FBRyxLQUFLLFdBQVcsSUFBSSxLQUFJLENBQUMsTUFBTSxDQUFDLEVBQUUsS0FBSyxHQUFHLEVBQUU7Z0JBQ3RELEtBQUksQ0FBQyxTQUFTLENBQUMsS0FBSyxFQUFFLENBQUM7YUFDMUI7UUFDTCxDQUFDLENBQUMsQ0FBQztJQUNQLENBQUM7SUFFRCw2QkFBVyxHQUFYO1FBQ0ksSUFBSSxDQUFDLGFBQWEsRUFBRSxDQUFDO0lBQ3pCLENBQUM7SUFFRCw2QkFBVyxHQUFYO1FBQ0ksSUFBSSxDQUFDLGFBQWEsQ0FBQyxXQUFXLEVBQUUsQ0FBQztJQUNyQyxDQUFDO0lBRUQsK0JBQWEsR0FBYjtRQUNJLElBQUksT0FBTyxJQUFJLENBQUMsTUFBTSxLQUFLLFdBQVcsRUFBRTtZQUNwQyxJQUFJLENBQUMsYUFBYSxHQUFHLElBQUksQ0FBQyxNQUFNLENBQUM7WUFDakMsSUFBSSxPQUFPLElBQUksQ0FBQyxhQUFhLENBQUMsTUFBTSxLQUFLLFdBQVcsRUFBRTtnQkFDbEQsS0FBSyxJQUFJLENBQUMsR0FBVyxDQUFDLEVBQUUsQ0FBQyxHQUFHLElBQUksQ0FBQyxhQUFhLENBQUMsTUFBTSxDQUFDLE1BQU0sRUFBRSxDQUFDLEVBQUUsRUFBRTtvQkFDL0QsSUFBSSxPQUFPLElBQUksQ0FBQyxNQUFNLEtBQUssV0FBVzt3QkFBRSxJQUFJLENBQUMsYUFBYSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsR0FBRyxJQUFJLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQztpQkFDaEc7YUFDSjtZQUNELElBQUksT0FBTyxJQUFJLENBQUMsTUFBTSxDQUFDLElBQUksS0FBSyxXQUFXLElBQUksSUFBSSxDQUFDLE1BQU0sQ0FBQyxJQUFJLEtBQUssRUFBRTtnQkFBRSxJQUFJLENBQUMsWUFBWSxHQUFHLElBQUksQ0FBQztTQUNwRztJQUNMLENBQUM7SUFFTSwwQkFBUSxHQUFmLFVBQWdCLEtBQVUsRUFBRSxHQUFRO1FBQ2hDLElBQUksT0FBTyxHQUFHLENBQUMsUUFBUSxLQUFLLFVBQVU7WUFBRSxHQUFHLENBQUMsUUFBUSxDQUFDLEtBQUssRUFBRSxHQUFHLENBQUMsQ0FBQztJQUNyRSxDQUFDO0lBRU8sbUNBQWlCLEdBQXpCLFVBQTBCLE1BQVc7UUFDakMsSUFBSSxNQUFNLEtBQUssbUJBQW1CLENBQUMsR0FBRztZQUFFLE9BQU8saUJBQWlCLENBQUM7YUFDNUQsSUFBSSxNQUFNLEtBQUssbUJBQW1CLENBQUMsY0FBYztZQUFFLE9BQU8sMkJBQTJCLENBQUM7O1lBQ3RGLE9BQU8sV0FBUyxNQUFRLENBQUM7SUFDbEMsQ0FBQzs7Z0JBMURzQixRQUFRO2dCQUNOLFlBQVk7O0lBTDVCO1FBQVIsS0FBSyxFQUFFOzsyQ0FBYTtJQUNtQjtRQUF2QyxTQUFTLENBQUMsU0FBUyxFQUFFLEVBQUUsTUFBTSxFQUFFLElBQUksRUFBRSxDQUFDOzsrQ0FBaUI7SUFwQi9DLE9BQU87UUFObkIsU0FBUyxDQUFDO1lBQ1AsUUFBUSxFQUFFLFVBQVU7WUFDcEIsOG9DQUFzQztZQUN0QyxTQUFTLEVBQUUsQ0FBQyxZQUFZLEVBQUUsY0FBYyxDQUFDO1NBQzVDLENBQUM7eUNBeUJ5QixRQUFRO1lBQ04sWUFBWTtPQXhCNUIsT0FBTyxDQWtGbkI7SUFBRCxjQUFDO0NBQUEsQUFsRkQsSUFrRkM7U0FsRlksT0FBTyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7XHJcbiAgICBDb21wb25lbnQsXHJcbiAgICBJbnB1dCxcclxuICAgIE9uSW5pdCxcclxuICAgIFZpZXdDaGlsZCxcclxuICAgIE9uRGVzdHJveVxyXG59IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xyXG5cclxuaW1wb3J0IHsgTmdiTW9kYWwsIE1vZGFsRGlzbWlzc1JlYXNvbnMsIE5nYkFjdGl2ZU1vZGFsLCBOZ2JNb2RhbFJlZiB9IGZyb20gJ0BuZy1ib290c3RyYXAvbmctYm9vdHN0cmFwJztcclxuaW1wb3J0IHsgS2RNb2RhbEV2ZW50IH0gZnJvbSAnLi9rZC1tb2RhbC1ldmVudCc7XHJcbmltcG9ydCB7IFN1YnNjcmlwdGlvbiB9IGZyb20gJ3J4anMnO1xyXG5cclxuZXhwb3J0IHsgS2RNb2RhbEV2ZW50IH0gZnJvbSAnLi9rZC1tb2RhbC1ldmVudCc7XHJcblxyXG5AQ29tcG9uZW50KHtcclxuICAgIHNlbGVjdG9yOiAna2QtbW9kYWwnLFxyXG4gICAgdGVtcGxhdGVVcmw6ICcuL2tkLWFuZ3VsYXItbW9kYWwuaHRtbCcsXHJcbiAgICBwcm92aWRlcnM6IFtLZE1vZGFsRXZlbnQsIE5nYkFjdGl2ZU1vZGFsXVxyXG59KVxyXG5cclxuZXhwb3J0IGNsYXNzIEtkTW9kYWwgaW1wbGVtZW50cyBPbkluaXQsIE9uRGVzdHJveSB7XHJcbiAgICBwcml2YXRlIF9jdXJNb2RhbDogTmdiTW9kYWxSZWY7XHJcbiAgICBwdWJsaWMgX2lzQm9keUV4aXN0OiBib29sZWFuID0gZmFsc2U7XHJcbiAgICBwcml2YXRlIF9tb2RhbE9wZW5TdWI6IFN1YnNjcmlwdGlvbjtcclxuICAgIHByaXZhdGUgX21vZGFsQ2xvc2VTdWI6IFN1YnNjcmlwdGlvbjtcclxuICAgIGNsb3NlUmVzdWx0OiBzdHJpbmc7XHJcblxyXG4gICAgX21vZGFsRGVmYXVsdDogYW55ID0ge1xyXG4gICAgICAgIHN1c3BlbmRDbG9zZTogZmFsc2UsXHJcbiAgICAgICAgdGl0bGU6ICdNb2RhbCBUaXRsZScsXHJcbiAgICAgICAgYm9keTogJ01vZGFsIEJvZHkgVGV4dC4nLFxyXG4gICAgICAgIGJ1dHRvbjogW1xyXG4gICAgICAgICAgICB7XHJcbiAgICAgICAgICAgICAgICB0ZXh0OiAnQ2FuY2VsJyxcclxuICAgICAgICAgICAgICAgIGNsYXNzOiAnYnRuLW91dGxpbmUnLFxyXG4gICAgICAgICAgICAgICAgY2FsbGJhY2s6ICgpOiB2b2lkID0+IHsgfVxyXG4gICAgICAgICAgICB9XVxyXG4gICAgfTtcclxuXHJcbiAgICBASW5wdXQoKSBjb25maWc6IGFueTtcclxuICAgIEBWaWV3Q2hpbGQoJ2NvbnRlbnQnLCB7IHN0YXRpYzogdHJ1ZSB9KSBjb250ZW50UmVmOiBhbnk7XHJcblxyXG4gICAgY29uc3RydWN0b3IoXHJcbiAgICAgICAgcHJpdmF0ZSBfbmdiTW9kYWw6IE5nYk1vZGFsLFxyXG4gICAgICAgIHByaXZhdGUgX21vZGFsRXZlbnQ6IEtkTW9kYWxFdmVudFxyXG4gICAgKSB7IH1cclxuXHJcbiAgICBuZ09uSW5pdCgpOiB2b2lkIHtcclxuICAgICAgICB0aGlzLmRlZmF1bHRDb25maWcoKTtcclxuICAgICAgICB0aGlzLl9tb2RhbE9wZW5TdWIgPSB0aGlzLl9tb2RhbEV2ZW50Lm9uVG9nZ2xlT3BlbigpLnN1YnNjcmliZSh2YWwgPT4ge1xyXG4gICAgICAgICAgICBpZiAodHlwZW9mIHZhbCA9PT0gJ3VuZGVmaW5lZCcgfHwgdGhpcy5jb25maWcuaWQgPT09IHZhbCkge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5fY3VyTW9kYWwgPSB0aGlzLl9uZ2JNb2RhbC5vcGVuKHRoaXMuY29udGVudFJlZik7XHJcbiAgICAgICAgICAgICAgICAvLyBjb25zb2xlLmxvZyh0aGlzLl9jdXJNb2RhbC5jbG9zZSk7XHJcbiAgICAgICAgICAgICAgICAvLyBjb25zb2xlLmxvZygnYW0gaSBtb2RhbCBsb2FkZWQnLCB2YWwpO1xyXG4gICAgICAgICAgICAgICAgLy8gaWYgKHR5cGVvZiB0aGlzLmNvbmZpZy5pZCA9PT0gJ3VuZGVmaW5lZCcpIHRoaXMub3Blbih0aGlzLmNvbnRlbnRSZWYpO1xyXG4gICAgICAgICAgICAgICAgLy8gZWxzZSBpZiAodmFsID09PSB0aGlzLmNvbmZpZy5pZCkgdGhpcy5vcGVuKHRoaXMuY29udGVudFJlZik7XHJcbiAgICAgICAgICAgICAgICB0aGlzLl9jdXJNb2RhbC5yZXN1bHQudGhlbigoX3Jlc3VsdCk6IHZvaWQgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuY2xvc2VSZXN1bHQgPSBgQ2xvc2VkIHdpdGg6ICR7X3Jlc3VsdH1gO1xyXG4gICAgICAgICAgICAgICAgICAgIC8vIGNvbnNvbGUubG9nKCdfcmVzdWx0IDogJywgdGhpcy5jbG9zZVJlc3VsdCk7XHJcbiAgICAgICAgICAgICAgICB9LCAoX3JlYXNvbik6IHZvaWQgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuY2xvc2VSZXN1bHQgPSBgRGlzbWlzc2VkICR7dGhpcy5fZ2V0RGlzbWlzc1JlYXNvbihfcmVhc29uKX1gO1xyXG4gICAgICAgICAgICAgICAgICAgIC8vIGNvbnNvbGUubG9nKCdfcmVhc29uIDogJywgdGhpcy5jbG9zZVJlc3VsdCk7XHJcbiAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH0pO1xyXG5cclxuICAgICAgICB0aGlzLl9tb2RhbENsb3NlU3ViID0gdGhpcy5fbW9kYWxFdmVudC5vblRvZ2dsZUNsb3NlKCkuc3Vic2NyaWJlKHZhbCA9PiB7XHJcbiAgICAgICAgICAgIGlmICh0eXBlb2YgdmFsID09PSAndW5kZWZpbmVkJyB8fCB0aGlzLmNvbmZpZy5pZCA9PT0gdmFsKSB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLl9jdXJNb2RhbC5jbG9zZSgpO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfSk7XHJcbiAgICB9XHJcblxyXG4gICAgbmdPbkNoYW5nZXMoKTogdm9pZCB7XHJcbiAgICAgICAgdGhpcy5kZWZhdWx0Q29uZmlnKCk7XHJcbiAgICB9XHJcblxyXG4gICAgbmdPbkRlc3Ryb3koKTogdm9pZCB7XHJcbiAgICAgICAgdGhpcy5fbW9kYWxPcGVuU3ViLnVuc3Vic2NyaWJlKCk7XHJcbiAgICB9XHJcblxyXG4gICAgZGVmYXVsdENvbmZpZygpIHtcclxuICAgICAgICBpZiAodHlwZW9mIHRoaXMuY29uZmlnICE9PSAndW5kZWZpbmVkJykge1xyXG4gICAgICAgICAgICB0aGlzLl9tb2RhbERlZmF1bHQgPSB0aGlzLmNvbmZpZztcclxuICAgICAgICAgICAgaWYgKHR5cGVvZiB0aGlzLl9tb2RhbERlZmF1bHQuYnV0dG9uICE9PSAndW5kZWZpbmVkJykge1xyXG4gICAgICAgICAgICAgICAgZm9yIChsZXQgaTogbnVtYmVyID0gMDsgaSA8IHRoaXMuX21vZGFsRGVmYXVsdC5idXR0b24ubGVuZ3RoOyBpKyspIHtcclxuICAgICAgICAgICAgICAgICAgICBpZiAodHlwZW9mIHRoaXMuY29uZmlnICE9PSAndW5kZWZpbmVkJykgdGhpcy5fbW9kYWxEZWZhdWx0LmJ1dHRvbltpXSA9IHRoaXMuY29uZmlnLmJ1dHRvbltpXTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBpZiAodHlwZW9mIHRoaXMuY29uZmlnLmJvZHkgIT09ICd1bmRlZmluZWQnICYmIHRoaXMuY29uZmlnLmJvZHkgIT09ICcnKSB0aGlzLl9pc0JvZHlFeGlzdCA9IHRydWU7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIHB1YmxpYyBjYWxsYmFjayhldmVudDogYW55LCBidG46IGFueSk6IHZvaWQge1xyXG4gICAgICAgIGlmICh0eXBlb2YgYnRuLmNhbGxiYWNrID09PSAnZnVuY3Rpb24nKSBidG4uY2FsbGJhY2soZXZlbnQsIGJ0bik7XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfZ2V0RGlzbWlzc1JlYXNvbihyZWFzb246IGFueSk6IHN0cmluZyB7XHJcbiAgICAgICAgaWYgKHJlYXNvbiA9PT0gTW9kYWxEaXNtaXNzUmVhc29ucy5FU0MpIHJldHVybiAnYnkgcHJlc3NpbmcgRVNDJztcclxuICAgICAgICBlbHNlIGlmIChyZWFzb24gPT09IE1vZGFsRGlzbWlzc1JlYXNvbnMuQkFDS0RST1BfQ0xJQ0spIHJldHVybiAnYnkgY2xpY2tpbmcgb24gYSBiYWNrZHJvcCc7XHJcbiAgICAgICAgZWxzZSByZXR1cm4gYHdpdGg6ICR7cmVhc29ufWA7XHJcbiAgICB9XHJcbn1cclxuIl19