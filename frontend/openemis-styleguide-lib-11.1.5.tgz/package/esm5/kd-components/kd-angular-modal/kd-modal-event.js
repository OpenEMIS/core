import { __decorate, __metadata } from "tslib";
import { Injectable } from '@angular/core';
import { KdBroadcaster } from '../kd-common/index';
import * as i0 from "@angular/core";
import * as i1 from "../kd-common/kd-broadcaster-svc";
var KdModalEvent = /** @class */ (function () {
    function KdModalEvent(_broadcaster) {
        this._broadcaster = _broadcaster;
    }
    KdModalEvent.prototype.toggleOpen = function (data) {
        this._broadcaster.broadcast('ModalOpen', data);
    };
    KdModalEvent.prototype.onToggleOpen = function () {
        return this._broadcaster.on('ModalOpen');
    };
    KdModalEvent.prototype.toggleClose = function (data) {
        this._broadcaster.broadcast('ModalClose', data);
    };
    KdModalEvent.prototype.onToggleClose = function () {
        return this._broadcaster.on('ModalClose');
    };
    KdModalEvent.ctorParameters = function () { return [
        { type: KdBroadcaster }
    ]; };
    KdModalEvent.ɵprov = i0.ɵɵdefineInjectable({ factory: function KdModalEvent_Factory() { return new KdModalEvent(i0.ɵɵinject(i1.KdBroadcaster)); }, token: KdModalEvent, providedIn: "root" });
    KdModalEvent = __decorate([
        Injectable({
            providedIn: 'root'
        }),
        __metadata("design:paramtypes", [KdBroadcaster])
    ], KdModalEvent);
    return KdModalEvent;
}());
export { KdModalEvent };
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoia2QtbW9kYWwtZXZlbnQuanMiLCJzb3VyY2VSb290Ijoibmc6Ly9vcGVuZW1pcy1zdHlsZWd1aWRlLWxpYi8iLCJzb3VyY2VzIjpbImtkLWNvbXBvbmVudHMva2QtYW5ndWxhci1tb2RhbC9rZC1tb2RhbC1ldmVudC50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiO0FBQUEsT0FBTyxFQUFFLFVBQVUsRUFBRSxNQUFNLGVBQWUsQ0FBQztBQUUzQyxPQUFPLEVBQUUsYUFBYSxFQUFFLE1BQU0sb0JBQW9CLENBQUM7OztBQUtuRDtJQUNJLHNCQUFvQixZQUEyQjtRQUEzQixpQkFBWSxHQUFaLFlBQVksQ0FBZTtJQUFJLENBQUM7SUFFcEQsaUNBQVUsR0FBVixVQUFXLElBQVU7UUFDakIsSUFBSSxDQUFDLFlBQVksQ0FBQyxTQUFTLENBQUMsV0FBVyxFQUFFLElBQUksQ0FBQyxDQUFDO0lBQ25ELENBQUM7SUFFRCxtQ0FBWSxHQUFaO1FBQ0ksT0FBTyxJQUFJLENBQUMsWUFBWSxDQUFDLEVBQUUsQ0FBTSxXQUFXLENBQUMsQ0FBQztJQUNsRCxDQUFDO0lBRUQsa0NBQVcsR0FBWCxVQUFZLElBQVU7UUFDbEIsSUFBSSxDQUFDLFlBQVksQ0FBQyxTQUFTLENBQUMsWUFBWSxFQUFFLElBQUksQ0FBQyxDQUFDO0lBQ3BELENBQUM7SUFFRCxvQ0FBYSxHQUFiO1FBQ0ksT0FBTyxJQUFJLENBQUMsWUFBWSxDQUFDLEVBQUUsQ0FBTSxZQUFZLENBQUMsQ0FBQztJQUNuRCxDQUFDOztnQkFoQmlDLGFBQWE7OztJQUR0QyxZQUFZO1FBSHhCLFVBQVUsQ0FBQztZQUNSLFVBQVUsRUFBRSxNQUFNO1NBQ3JCLENBQUM7eUNBRW9DLGFBQWE7T0FEdEMsWUFBWSxDQWtCeEI7dUJBekJEO0NBeUJDLEFBbEJELElBa0JDO1NBbEJZLFlBQVkiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBJbmplY3RhYmxlIH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XHJcbmltcG9ydCB7IE9ic2VydmFibGUgfSBmcm9tICdyeGpzJztcclxuaW1wb3J0IHsgS2RCcm9hZGNhc3RlciB9IGZyb20gJy4uL2tkLWNvbW1vbi9pbmRleCc7XHJcblxyXG5ASW5qZWN0YWJsZSh7XHJcbiAgICBwcm92aWRlZEluOiAncm9vdCdcclxufSlcclxuZXhwb3J0IGNsYXNzIEtkTW9kYWxFdmVudCB7XHJcbiAgICBjb25zdHJ1Y3Rvcihwcml2YXRlIF9icm9hZGNhc3RlcjogS2RCcm9hZGNhc3RlcikgeyB9XHJcblxyXG4gICAgdG9nZ2xlT3BlbihkYXRhPzogYW55KTogdm9pZCB7XHJcbiAgICAgICAgdGhpcy5fYnJvYWRjYXN0ZXIuYnJvYWRjYXN0KCdNb2RhbE9wZW4nLCBkYXRhKTtcclxuICAgIH1cclxuXHJcbiAgICBvblRvZ2dsZU9wZW4oKTogT2JzZXJ2YWJsZTxhbnk+IHtcclxuICAgICAgICByZXR1cm4gdGhpcy5fYnJvYWRjYXN0ZXIub248YW55PignTW9kYWxPcGVuJyk7XHJcbiAgICB9XHJcblxyXG4gICAgdG9nZ2xlQ2xvc2UoZGF0YT86IGFueSk6IHZvaWQge1xyXG4gICAgICAgIHRoaXMuX2Jyb2FkY2FzdGVyLmJyb2FkY2FzdCgnTW9kYWxDbG9zZScsIGRhdGEpO1xyXG4gICAgfVxyXG5cclxuICAgIG9uVG9nZ2xlQ2xvc2UoKTogT2JzZXJ2YWJsZTxhbnk+IHtcclxuICAgICAgICByZXR1cm4gdGhpcy5fYnJvYWRjYXN0ZXIub248YW55PignTW9kYWxDbG9zZScpO1xyXG4gICAgfVxyXG59XHJcbiJdfQ==