import { __decorate, __metadata } from "tslib";
import { Injectable } from '@angular/core';
import * as i0 from "@angular/core";
var KdTemplateLayoutSvc = /** @class */ (function () {
    function KdTemplateLayoutSvc() {
        this._api = {};
    }
    KdTemplateLayoutSvc.prototype.setApi = function (_name, _api) {
        if (typeof _name !== undefined && _name !== '' && typeof _api !== undefined) {
            this._api[_name] = _api;
        }
    };
    KdTemplateLayoutSvc.prototype.getApi = function (_name) {
        if (typeof _name === undefined || _name === '' || !this._api.hasOwnProperty(_name))
            return undefined;
        return this._api[_name];
    };
    KdTemplateLayoutSvc.ɵprov = i0.ɵɵdefineInjectable({ factory: function KdTemplateLayoutSvc_Factory() { return new KdTemplateLayoutSvc(); }, token: KdTemplateLayoutSvc, providedIn: "root" });
    KdTemplateLayoutSvc = __decorate([
        Injectable({
            providedIn: 'root'
        }),
        __metadata("design:paramtypes", [])
    ], KdTemplateLayoutSvc);
    return KdTemplateLayoutSvc;
}());
export { KdTemplateLayoutSvc };
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoia2QtYW5ndWxhci10ZW1wbGF0ZS1sYXlvdXQtc3ZjLmpzIiwic291cmNlUm9vdCI6Im5nOi8vb3BlbmVtaXMtc3R5bGVndWlkZS1saWIvIiwic291cmNlcyI6WyJrZC1jb21wb25lbnRzL2tkLWFuZ3VsYXItdGVtcGxhdGUtbGF5b3V0L2tkLWFuZ3VsYXItdGVtcGxhdGUtbGF5b3V0LXN2Yy50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiO0FBQUEsT0FBTyxFQUFFLFVBQVUsRUFBRSxNQUFNLGVBQWUsQ0FBQzs7QUFLM0M7SUFHSTtRQUZRLFNBQUksR0FBUSxFQUFFLENBQUM7SUFFUCxDQUFDO0lBRVYsb0NBQU0sR0FBYixVQUFjLEtBQWEsRUFBRSxJQUFTO1FBQ2xDLElBQUksT0FBTyxLQUFLLEtBQUssU0FBUyxJQUFJLEtBQUssS0FBSyxFQUFFLElBQUksT0FBTyxJQUFJLEtBQUssU0FBUyxFQUFFO1lBQ3pFLElBQUksQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLEdBQUcsSUFBSSxDQUFDO1NBQzNCO0lBQ0wsQ0FBQztJQUVNLG9DQUFNLEdBQWIsVUFBYyxLQUFhO1FBQ3ZCLElBQUksT0FBTyxLQUFLLEtBQUssU0FBUyxJQUFJLEtBQUssS0FBSyxFQUFFLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLGNBQWMsQ0FBQyxLQUFLLENBQUM7WUFBRSxPQUFPLFNBQVMsQ0FBQztRQUNyRyxPQUFPLElBQUksQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLENBQUM7SUFDNUIsQ0FBQzs7SUFkUSxtQkFBbUI7UUFIL0IsVUFBVSxDQUFDO1lBQ1IsVUFBVSxFQUFFLE1BQU07U0FDckIsQ0FBQzs7T0FDVyxtQkFBbUIsQ0FlL0I7OEJBcEJEO0NBb0JDLEFBZkQsSUFlQztTQWZZLG1CQUFtQiIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IEluamVjdGFibGUgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcclxuXHJcbkBJbmplY3RhYmxlKHtcclxuICAgIHByb3ZpZGVkSW46ICdyb290J1xyXG59KVxyXG5leHBvcnQgY2xhc3MgS2RUZW1wbGF0ZUxheW91dFN2YyB7XHJcbiAgICBwcml2YXRlIF9hcGk6IGFueSA9IHt9O1xyXG5cclxuICAgIGNvbnN0cnVjdG9yKCkgeyB9XHJcblxyXG4gICAgcHVibGljIHNldEFwaShfbmFtZTogc3RyaW5nLCBfYXBpOiBhbnkpOiB2b2lkIHtcclxuICAgICAgICBpZiAodHlwZW9mIF9uYW1lICE9PSB1bmRlZmluZWQgJiYgX25hbWUgIT09ICcnICYmIHR5cGVvZiBfYXBpICE9PSB1bmRlZmluZWQpIHtcclxuICAgICAgICAgICAgdGhpcy5fYXBpW19uYW1lXSA9IF9hcGk7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIHB1YmxpYyBnZXRBcGkoX25hbWU6IHN0cmluZyk6IGFueSB7XHJcbiAgICAgICAgaWYgKHR5cGVvZiBfbmFtZSA9PT0gdW5kZWZpbmVkIHx8IF9uYW1lID09PSAnJyB8fCAhdGhpcy5fYXBpLmhhc093blByb3BlcnR5KF9uYW1lKSkgcmV0dXJuIHVuZGVmaW5lZDtcclxuICAgICAgICByZXR1cm4gdGhpcy5fYXBpW19uYW1lXTtcclxuICAgIH1cclxufVxyXG4iXX0=