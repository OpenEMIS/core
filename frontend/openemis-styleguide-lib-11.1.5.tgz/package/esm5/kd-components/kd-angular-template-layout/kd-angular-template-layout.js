import { __decorate, __metadata } from "tslib";
import { Component, Input } from '@angular/core';
import { KdDataSvc } from '../kd-common/index';
var KdTemplateLayout = /** @class */ (function () {
    function KdTemplateLayout(
    // private _pageEvent: KdPageBaseEvent,
    // private _router: Router,
    _dataSvc) {
        this._dataSvc = _dataSvc;
        this.localApi = {
            header: {},
            pageHeader: {},
            breadcrumbs: {},
            navigation: {}
        };
    }
    KdTemplateLayout.prototype.ngOnInit = function () {
        this._initApi();
    };
    KdTemplateLayout.prototype.ngOnDestroy = function () {
    };
    KdTemplateLayout.prototype.changeDetectFrom = function (question) {
        // console.log('Adv search component change detect from: ', question);
    };
    KdTemplateLayout.prototype.submittedFormValue = function (formVal) {
        // console.log('Adv search form submit data: ', formVal);
    };
    KdTemplateLayout.prototype._initApi = function () {
        if (!this.api)
            return;
        // this.api = this.localApi;
        this._dataSvc.deepCombineObject(this.api, this.localApi);
        // this._cdr.detectChanges();
        // console.log('set to api', this.api);
    };
    KdTemplateLayout.ctorParameters = function () { return [
        { type: KdDataSvc }
    ]; };
    __decorate([
        Input('navigation'),
        __metadata("design:type", Object)
    ], KdTemplateLayout.prototype, "leftNavConfig", void 0);
    __decorate([
        Input('header'),
        __metadata("design:type", Object)
    ], KdTemplateLayout.prototype, "headerConfig", void 0);
    __decorate([
        Input('pageheader'),
        __metadata("design:type", Object)
    ], KdTemplateLayout.prototype, "pageHeaderConfig", void 0);
    __decorate([
        Input('breadcrumbs'),
        __metadata("design:type", Object)
    ], KdTemplateLayout.prototype, "breadcrumbConfig", void 0);
    __decorate([
        Input('search'),
        __metadata("design:type", Object)
    ], KdTemplateLayout.prototype, "searchFormData", void 0);
    __decorate([
        Input(),
        __metadata("design:type", Object)
    ], KdTemplateLayout.prototype, "api", void 0);
    KdTemplateLayout = __decorate([
        Component({
            selector: 'kd-template-layout',
            template: "\n        <kd-splitter class='has-header has-footer main'>\n            <kd-pane size='10%' max='30%' min='2%'>\n                <kd-leftmenu [config]='leftNavConfig' [api]='localApi.navigation'></kd-leftmenu>\n            </kd-pane>\n            <kd-pane>\n                <ng-template ngbModalContainer></ng-template>\n                <kd-alert></kd-alert>\n                <kd-header [config]='headerConfig' [api]='localApi.header'></kd-header>\n                <div class='main-wrapper'>\n                    <div class='content-wrapper'>\n                        <kd-breadcrumb [config]='breadcrumbConfig' [api]='localApi.breadcrumbs'></kd-breadcrumb>\n                        <kd-pageheader [config]='pageHeaderConfig' [api]='localApi.pageHeader'></kd-pageheader>\n                        <div class='content-area'>\n                            <div class='content'>\n                                <router-outlet></router-outlet>\n                            </div>\n                            <kd-footer enableFloat='true'></kd-footer>\n                        </div>\n                        <!-- <kd-adv-search [formData]='searchFormData' (fieldValue)='changeDetectFrom($event)' (formValue)='submittedFormValue($event)'></kd-adv-search> -->\n                    </div>\n                </div>\n            </kd-pane>\n        </kd-splitter>\n    ",
            providers: [
                KdDataSvc
                // KdPageBaseEvent
            ]
        }),
        __metadata("design:paramtypes", [KdDataSvc])
    ], KdTemplateLayout);
    return KdTemplateLayout;
}());
export { KdTemplateLayout };
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoia2QtYW5ndWxhci10ZW1wbGF0ZS1sYXlvdXQuanMiLCJzb3VyY2VSb290Ijoibmc6Ly9vcGVuZW1pcy1zdHlsZWd1aWRlLWxpYi8iLCJzb3VyY2VzIjpbImtkLWNvbXBvbmVudHMva2QtYW5ndWxhci10ZW1wbGF0ZS1sYXlvdXQva2QtYW5ndWxhci10ZW1wbGF0ZS1sYXlvdXQudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IjtBQUFBLE9BQU8sRUFDSCxTQUFTLEVBR1QsS0FBSyxFQUNSLE1BQU0sZUFBZSxDQUFDO0FBT3ZCLE9BQU8sRUFBRSxTQUFTLEVBQUUsTUFBTSxvQkFBb0IsQ0FBQztBQXVDL0M7SUFrQkk7SUFDSSx1Q0FBdUM7SUFDdkMsMkJBQTJCO0lBQ25CLFFBQW1CO1FBQW5CLGFBQVEsR0FBUixRQUFRLENBQVc7UUFwQnhCLGFBQVEsR0FBdUI7WUFDbEMsTUFBTSxFQUFFLEVBQUU7WUFDVixVQUFVLEVBQUUsRUFBRTtZQUNkLFdBQVcsRUFBRSxFQUFFO1lBQ2YsVUFBVSxFQUFFLEVBQUU7U0FDakIsQ0FBQztJQWtCRixDQUFDO0lBRUQsbUNBQVEsR0FBUjtRQUNJLElBQUksQ0FBQyxRQUFRLEVBQUUsQ0FBQztJQUNwQixDQUFDO0lBRUQsc0NBQVcsR0FBWDtJQUVBLENBQUM7SUFFTSwyQ0FBZ0IsR0FBdkIsVUFBd0IsUUFBYTtRQUNqQyxzRUFBc0U7SUFDMUUsQ0FBQztJQUVNLDZDQUFrQixHQUF6QixVQUEwQixPQUFZO1FBQ2xDLHlEQUF5RDtJQUM3RCxDQUFDO0lBRU8sbUNBQVEsR0FBaEI7UUFDSSxJQUFJLENBQUMsSUFBSSxDQUFDLEdBQUc7WUFBRSxPQUFPO1FBRXRCLDRCQUE0QjtRQUM1QixJQUFJLENBQUMsUUFBUSxDQUFDLGlCQUFpQixDQUFDLElBQUksQ0FBQyxHQUFHLEVBQUUsSUFBSSxDQUFDLFFBQVEsQ0FBQyxDQUFDO1FBRXpELDZCQUE2QjtRQUM3Qix1Q0FBdUM7SUFDM0MsQ0FBQzs7Z0JBN0JxQixTQUFTOztJQVZWO1FBQXBCLEtBQUssQ0FBQyxZQUFZLENBQUM7OzJEQUFvQjtJQUN2QjtRQUFoQixLQUFLLENBQUMsUUFBUSxDQUFDOzswREFBNkI7SUFDeEI7UUFBcEIsS0FBSyxDQUFDLFlBQVksQ0FBQzs7OERBQXFDO0lBQ25DO1FBQXJCLEtBQUssQ0FBQyxhQUFhLENBQUM7OzhEQUFxQztJQUN6QztRQUFoQixLQUFLLENBQUMsUUFBUSxDQUFDOzs0REFBcUI7SUFDNUI7UUFBUixLQUFLLEVBQUU7O2lEQUFVO0lBaEJULGdCQUFnQjtRQWxDNUIsU0FBUyxDQUFDO1lBQ1AsUUFBUSxFQUFFLG9CQUFvQjtZQUM5QixRQUFRLEVBQUUsZzFDQXdCVDtZQUNELFNBQVMsRUFBRTtnQkFDUCxTQUFTO2dCQUNULGtCQUFrQjthQUNyQjtTQUNKLENBQUM7eUNBd0J3QixTQUFTO09BckJ0QixnQkFBZ0IsQ0FtRDVCO0lBQUQsdUJBQUM7Q0FBQSxBQW5ERCxJQW1EQztTQW5EWSxnQkFBZ0IiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQge1xyXG4gICAgQ29tcG9uZW50LFxyXG4gICAgT25Jbml0LFxyXG4gICAgT25EZXN0cm95LFxyXG4gICAgSW5wdXRcclxufSBmcm9tICdAYW5ndWxhci9jb3JlJztcclxuLy8gaW1wb3J0IHsgU3Vic2NyaXB0aW9uIH0gZnJvbSAncnhqcy9TdWJzY3JpcHRpb24nO1xyXG4vLyBpbXBvcnQgeyBSb3V0ZXIgfSBmcm9tICdAYW5ndWxhci9yb3V0ZXInO1xyXG4vLyBpbXBvcnQgeyBLZFRlbXBsYXRlTGF5b3V0U3ZjIH0gZnJvbSAnLi9rZC1hbmd1bGFyLXRlbXBsYXRlLWxheW91dC1zdmMnO1xyXG5pbXBvcnQgeyBJVGVtcGxhdGVMYXlvdXRBUEkgfSBmcm9tICcuL2tkLWFuZ3VsYXItdGVtcGxhdGUtbGF5b3V0LWludGVyZmFjZSc7XHJcbmltcG9ydCB7IC8qSUhlYWRlckFQSSwqLyBJSGVhZGVyQ29uZmlnIH0gZnJvbSAnLi4va2QtYW5ndWxhci1oZWFkZXIvaW5kZXgnO1xyXG5pbXBvcnQgeyBJQnJlYWRjcnVtYkNvbmZpZyB9IGZyb20gJy4uL2tkLWFuZ3VsYXItYnJlYWRjcnVtYi9pbmRleCc7XHJcbmltcG9ydCB7IEtkRGF0YVN2YyB9IGZyb20gJy4uL2tkLWNvbW1vbi9pbmRleCc7XHJcblxyXG5pbXBvcnQgeyAvKklQYWdlaGVhZGVyQXBpLCovIElQYWdlaGVhZGVyQ29uZmlnIH0gZnJvbSAnLi4va2QtYW5ndWxhci1wYWdlaGVhZGVyL2luZGV4JztcclxuXHJcblxyXG5AQ29tcG9uZW50KHtcclxuICAgIHNlbGVjdG9yOiAna2QtdGVtcGxhdGUtbGF5b3V0JyxcclxuICAgIHRlbXBsYXRlOiBgXHJcbiAgICAgICAgPGtkLXNwbGl0dGVyIGNsYXNzPSdoYXMtaGVhZGVyIGhhcy1mb290ZXIgbWFpbic+XHJcbiAgICAgICAgICAgIDxrZC1wYW5lIHNpemU9JzEwJScgbWF4PSczMCUnIG1pbj0nMiUnPlxyXG4gICAgICAgICAgICAgICAgPGtkLWxlZnRtZW51IFtjb25maWddPSdsZWZ0TmF2Q29uZmlnJyBbYXBpXT0nbG9jYWxBcGkubmF2aWdhdGlvbic+PC9rZC1sZWZ0bWVudT5cclxuICAgICAgICAgICAgPC9rZC1wYW5lPlxyXG4gICAgICAgICAgICA8a2QtcGFuZT5cclxuICAgICAgICAgICAgICAgIDxuZy10ZW1wbGF0ZSBuZ2JNb2RhbENvbnRhaW5lcj48L25nLXRlbXBsYXRlPlxyXG4gICAgICAgICAgICAgICAgPGtkLWFsZXJ0Pjwva2QtYWxlcnQ+XHJcbiAgICAgICAgICAgICAgICA8a2QtaGVhZGVyIFtjb25maWddPSdoZWFkZXJDb25maWcnIFthcGldPSdsb2NhbEFwaS5oZWFkZXInPjwva2QtaGVhZGVyPlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzcz0nbWFpbi13cmFwcGVyJz5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzPSdjb250ZW50LXdyYXBwZXInPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8a2QtYnJlYWRjcnVtYiBbY29uZmlnXT0nYnJlYWRjcnVtYkNvbmZpZycgW2FwaV09J2xvY2FsQXBpLmJyZWFkY3J1bWJzJz48L2tkLWJyZWFkY3J1bWI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxrZC1wYWdlaGVhZGVyIFtjb25maWddPSdwYWdlSGVhZGVyQ29uZmlnJyBbYXBpXT0nbG9jYWxBcGkucGFnZUhlYWRlcic+PC9rZC1wYWdlaGVhZGVyPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzPSdjb250ZW50LWFyZWEnPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzcz0nY29udGVudCc+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHJvdXRlci1vdXRsZXQ+PC9yb3V0ZXItb3V0bGV0PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8a2QtZm9vdGVyIGVuYWJsZUZsb2F0PSd0cnVlJz48L2tkLWZvb3Rlcj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwhLS0gPGtkLWFkdi1zZWFyY2ggW2Zvcm1EYXRhXT0nc2VhcmNoRm9ybURhdGEnIChmaWVsZFZhbHVlKT0nY2hhbmdlRGV0ZWN0RnJvbSgkZXZlbnQpJyAoZm9ybVZhbHVlKT0nc3VibWl0dGVkRm9ybVZhbHVlKCRldmVudCknPjwva2QtYWR2LXNlYXJjaD4gLS0+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPC9rZC1wYW5lPlxyXG4gICAgICAgIDwva2Qtc3BsaXR0ZXI+XHJcbiAgICBgLFxyXG4gICAgcHJvdmlkZXJzOiBbXHJcbiAgICAgICAgS2REYXRhU3ZjXHJcbiAgICAgICAgLy8gS2RQYWdlQmFzZUV2ZW50XHJcbiAgICBdXHJcbn0pXHJcblxyXG5cclxuZXhwb3J0IGNsYXNzIEtkVGVtcGxhdGVMYXlvdXQgaW1wbGVtZW50cyBPbkluaXQsIE9uRGVzdHJveSB7XHJcbiAgICBwdWJsaWMgbG9jYWxBcGk6IElUZW1wbGF0ZUxheW91dEFQSSA9IHtcclxuICAgICAgICBoZWFkZXI6IHt9LFxyXG4gICAgICAgIHBhZ2VIZWFkZXI6IHt9LFxyXG4gICAgICAgIGJyZWFkY3J1bWJzOiB7fSxcclxuICAgICAgICBuYXZpZ2F0aW9uOiB7fVxyXG4gICAgfTtcclxuXHJcbiAgICAvLyBwcml2YXRlIF9wYWdlaGVhZGVyU3ViOiBTdWJzY3JpcHRpb247XHJcbiAgICAvLyBwcml2YXRlIF9icmVhZGNydW1iU3ViOiBTdWJzY3JpcHRpb247XHJcblxyXG4gICAgQElucHV0KCduYXZpZ2F0aW9uJykgbGVmdE5hdkNvbmZpZzogYW55O1xyXG4gICAgQElucHV0KCdoZWFkZXInKSBoZWFkZXJDb25maWc6IElIZWFkZXJDb25maWc7XHJcbiAgICBASW5wdXQoJ3BhZ2VoZWFkZXInKSBwYWdlSGVhZGVyQ29uZmlnOiBJUGFnZWhlYWRlckNvbmZpZztcclxuICAgIEBJbnB1dCgnYnJlYWRjcnVtYnMnKSBicmVhZGNydW1iQ29uZmlnOiBJQnJlYWRjcnVtYkNvbmZpZztcclxuICAgIEBJbnB1dCgnc2VhcmNoJykgc2VhcmNoRm9ybURhdGE6IGFueTtcclxuICAgIEBJbnB1dCgpIGFwaTogYW55O1xyXG5cclxuICAgIGNvbnN0cnVjdG9yKFxyXG4gICAgICAgIC8vIHByaXZhdGUgX3BhZ2VFdmVudDogS2RQYWdlQmFzZUV2ZW50LFxyXG4gICAgICAgIC8vIHByaXZhdGUgX3JvdXRlcjogUm91dGVyLFxyXG4gICAgICAgIHByaXZhdGUgX2RhdGFTdmM6IEtkRGF0YVN2YyxcclxuICAgICkge1xyXG5cclxuICAgIH1cclxuXHJcbiAgICBuZ09uSW5pdCgpOiB2b2lkIHtcclxuICAgICAgICB0aGlzLl9pbml0QXBpKCk7XHJcbiAgICB9XHJcblxyXG4gICAgbmdPbkRlc3Ryb3koKTogdm9pZCB7XHJcblxyXG4gICAgfVxyXG5cclxuICAgIHB1YmxpYyBjaGFuZ2VEZXRlY3RGcm9tKHF1ZXN0aW9uOiBhbnkpOiB2b2lkIHtcclxuICAgICAgICAvLyBjb25zb2xlLmxvZygnQWR2IHNlYXJjaCBjb21wb25lbnQgY2hhbmdlIGRldGVjdCBmcm9tOiAnLCBxdWVzdGlvbik7XHJcbiAgICB9XHJcblxyXG4gICAgcHVibGljIHN1Ym1pdHRlZEZvcm1WYWx1ZShmb3JtVmFsOiBhbnkpOiB2b2lkIHtcclxuICAgICAgICAvLyBjb25zb2xlLmxvZygnQWR2IHNlYXJjaCBmb3JtIHN1Ym1pdCBkYXRhOiAnLCBmb3JtVmFsKTtcclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF9pbml0QXBpKCkge1xyXG4gICAgICAgIGlmICghdGhpcy5hcGkpIHJldHVybjtcclxuXHJcbiAgICAgICAgLy8gdGhpcy5hcGkgPSB0aGlzLmxvY2FsQXBpO1xyXG4gICAgICAgIHRoaXMuX2RhdGFTdmMuZGVlcENvbWJpbmVPYmplY3QodGhpcy5hcGksIHRoaXMubG9jYWxBcGkpO1xyXG5cclxuICAgICAgICAvLyB0aGlzLl9jZHIuZGV0ZWN0Q2hhbmdlcygpO1xyXG4gICAgICAgIC8vIGNvbnNvbGUubG9nKCdzZXQgdG8gYXBpJywgdGhpcy5hcGkpO1xyXG4gICAgfVxyXG59XHJcbiJdfQ==