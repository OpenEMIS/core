import { __decorate, __metadata } from "tslib";
import { Component, Input } from '@angular/core';
import { FONTAWESOME_FONTS } from './config/config.fa-fonts';
import { KD_FONTS } from './config/config.kd-fonts';
var KdFonts = /** @class */ (function () {
    function KdFonts() {
        this._fontList = [];
    }
    KdFonts.prototype.ngOnInit = function () {
        switch (this.fontType) {
            case 'fa':
                this._fontList = FONTAWESOME_FONTS;
                break;
            default:
                this._fontList = KD_FONTS;
                break;
        }
    };
    __decorate([
        Input(),
        __metadata("design:type", String)
    ], KdFonts.prototype, "fontType", void 0);
    __decorate([
        Input(),
        __metadata("design:type", String)
    ], KdFonts.prototype, "textFilter", void 0);
    KdFonts = __decorate([
        Component({
            selector: 'kd-fonts',
            template: "\n        <div class=\"font-containter default-font-size\">\n            <div *ngFor=\"let item of _fontList | filter: textFilter\" class=\"col-md-3 col-sm-4\" style=\"height:38px;\" [hidden]=\"item.hidden\">\n                <i class=\"fa {{item.text}}\"></i> {{item.text}}\n            </div>\n        </div>\n    "
        })
    ], KdFonts);
    return KdFonts;
}());
export { KdFonts };
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoia2QtYW5ndWxhci1mb250cy5qcyIsInNvdXJjZVJvb3QiOiJuZzovL29wZW5lbWlzLXN0eWxlZ3VpZGUtbGliLyIsInNvdXJjZXMiOlsia2QtY29tcG9uZW50cy9rZC1hbmd1bGFyLWZvbnRzL2tkLWFuZ3VsYXItZm9udHMudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IjtBQUFBLE9BQU8sRUFBRSxTQUFTLEVBQVUsS0FBSyxFQUFFLE1BQU0sZUFBZSxDQUFDO0FBQ3pELE9BQU8sRUFBRSxpQkFBaUIsRUFBRSxNQUFNLDBCQUEwQixDQUFDO0FBQzdELE9BQU8sRUFBRSxRQUFRLEVBQUUsTUFBTSwwQkFBMEIsQ0FBQztBQWFwRDtJQUFBO1FBQ1csY0FBUyxHQUFlLEVBQUUsQ0FBQztJQWV0QyxDQUFDO0lBVkcsMEJBQVEsR0FBUjtRQUNJLFFBQVEsSUFBSSxDQUFDLFFBQVEsRUFBRTtZQUNuQixLQUFLLElBQUk7Z0JBQ0wsSUFBSSxDQUFDLFNBQVMsR0FBRyxpQkFBaUIsQ0FBQztnQkFDbkMsTUFBTTtZQUNWO2dCQUNJLElBQUksQ0FBQyxTQUFTLEdBQUcsUUFBUSxDQUFDO2dCQUMxQixNQUFNO1NBQ2I7SUFDTCxDQUFDO0lBWlE7UUFBUixLQUFLLEVBQUU7OzZDQUFrQjtJQUNqQjtRQUFSLEtBQUssRUFBRTs7K0NBQW9CO0lBSm5CLE9BQU87UUFYbkIsU0FBUyxDQUFFO1lBQ1IsUUFBUSxFQUFFLFVBQVU7WUFDcEIsUUFBUSxFQUFFLDhUQU1UO1NBQ0osQ0FBQztPQUVXLE9BQU8sQ0FnQm5CO0lBQUQsY0FBQztDQUFBLEFBaEJELElBZ0JDO1NBaEJZLE9BQU8iLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBDb21wb25lbnQsIE9uSW5pdCwgSW5wdXQgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcclxuaW1wb3J0IHsgRk9OVEFXRVNPTUVfRk9OVFMgfSBmcm9tICcuL2NvbmZpZy9jb25maWcuZmEtZm9udHMnO1xyXG5pbXBvcnQgeyBLRF9GT05UUyB9IGZyb20gJy4vY29uZmlnL2NvbmZpZy5rZC1mb250cyc7XHJcblxyXG5AQ29tcG9uZW50ICh7XHJcbiAgICBzZWxlY3RvcjogJ2tkLWZvbnRzJyxcclxuICAgIHRlbXBsYXRlOiBgXHJcbiAgICAgICAgPGRpdiBjbGFzcz1cImZvbnQtY29udGFpbnRlciBkZWZhdWx0LWZvbnQtc2l6ZVwiPlxyXG4gICAgICAgICAgICA8ZGl2ICpuZ0Zvcj1cImxldCBpdGVtIG9mIF9mb250TGlzdCB8IGZpbHRlcjogdGV4dEZpbHRlclwiIGNsYXNzPVwiY29sLW1kLTMgY29sLXNtLTRcIiBzdHlsZT1cImhlaWdodDozOHB4O1wiIFtoaWRkZW5dPVwiaXRlbS5oaWRkZW5cIj5cclxuICAgICAgICAgICAgICAgIDxpIGNsYXNzPVwiZmEge3tpdGVtLnRleHR9fVwiPjwvaT4ge3tpdGVtLnRleHR9fVxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8L2Rpdj5cclxuICAgIGBcclxufSlcclxuXHJcbmV4cG9ydCBjbGFzcyBLZEZvbnRzIGltcGxlbWVudHMgT25Jbml0IHtcclxuICAgIHB1YmxpYyBfZm9udExpc3Q6IEFycmF5PGFueT4gPSBbXTtcclxuXHJcbiAgICBASW5wdXQoKSBmb250VHlwZTogc3RyaW5nO1xyXG4gICAgQElucHV0KCkgdGV4dEZpbHRlcjogc3RyaW5nO1xyXG5cclxuICAgIG5nT25Jbml0KCk6IHZvaWQge1xyXG4gICAgICAgIHN3aXRjaCAodGhpcy5mb250VHlwZSkge1xyXG4gICAgICAgICAgICBjYXNlICdmYSc6XHJcbiAgICAgICAgICAgICAgICB0aGlzLl9mb250TGlzdCA9IEZPTlRBV0VTT01FX0ZPTlRTO1xyXG4gICAgICAgICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgICAgIGRlZmF1bHQ6XHJcbiAgICAgICAgICAgICAgICB0aGlzLl9mb250TGlzdCA9IEtEX0ZPTlRTO1xyXG4gICAgICAgICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG59XHJcbiJdfQ==