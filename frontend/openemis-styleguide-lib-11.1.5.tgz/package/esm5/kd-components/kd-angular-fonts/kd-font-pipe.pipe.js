import { __decorate } from "tslib";
import { Pipe } from '@angular/core';
var FilterArrayPipe = /** @class */ (function () {
    function FilterArrayPipe() {
    }
    FilterArrayPipe.prototype.transform = function (value, args) {
        if (typeof args === 'undefined' || args.length === 0) {
            return value;
        }
        else if (value) {
            // .text is comparing a string  that is inside an object
            return value.filter(function (item) {
                return (item.text.indexOf(args) !== -1) ? true : false;
            });
        }
    };
    FilterArrayPipe = __decorate([
        Pipe({ name: 'filter' })
    ], FilterArrayPipe);
    return FilterArrayPipe;
}());
export { FilterArrayPipe };
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoia2QtZm9udC1waXBlLnBpcGUuanMiLCJzb3VyY2VSb290Ijoibmc6Ly9vcGVuZW1pcy1zdHlsZWd1aWRlLWxpYi8iLCJzb3VyY2VzIjpbImtkLWNvbXBvbmVudHMva2QtYW5ndWxhci1mb250cy9rZC1mb250LXBpcGUucGlwZS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiO0FBQUEsT0FBTyxFQUFFLElBQUksRUFBRSxNQUFNLGVBQWUsQ0FBQztBQUdyQztJQUFBO0lBWUEsQ0FBQztJQVZHLG1DQUFTLEdBQVQsVUFBVSxLQUFVLEVBQUUsSUFBUztRQUMzQixJQUFJLE9BQU8sSUFBSSxLQUFLLFdBQVcsSUFBSSxJQUFJLENBQUMsTUFBTSxLQUFLLENBQUMsRUFBRTtZQUNsRCxPQUFPLEtBQUssQ0FBQztTQUNoQjthQUFNLElBQUksS0FBSyxFQUFFO1lBQ2Qsd0RBQXdEO1lBQ3hELE9BQU8sS0FBSyxDQUFDLE1BQU0sQ0FBQyxVQUFDLElBQVM7Z0JBQzFCLE9BQU8sQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQztZQUMzRCxDQUFDLENBQUMsQ0FBQztTQUNOO0lBQ0wsQ0FBQztJQVhRLGVBQWU7UUFEM0IsSUFBSSxDQUFDLEVBQUUsSUFBSSxFQUFFLFFBQVEsRUFBRSxDQUFDO09BQ1osZUFBZSxDQVkzQjtJQUFELHNCQUFDO0NBQUEsQUFaRCxJQVlDO1NBWlksZUFBZSIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IFBpcGUgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcclxuXHJcbkBQaXBlKHsgbmFtZTogJ2ZpbHRlcicgfSlcclxuZXhwb3J0IGNsYXNzIEZpbHRlckFycmF5UGlwZSB7XHJcblxyXG4gICAgdHJhbnNmb3JtKHZhbHVlOiBhbnksIGFyZ3M6IGFueSkge1xyXG4gICAgICAgIGlmICh0eXBlb2YgYXJncyA9PT0gJ3VuZGVmaW5lZCcgfHwgYXJncy5sZW5ndGggPT09IDApIHtcclxuICAgICAgICAgICAgcmV0dXJuIHZhbHVlO1xyXG4gICAgICAgIH0gZWxzZSBpZiAodmFsdWUpIHtcclxuICAgICAgICAgICAgLy8gLnRleHQgaXMgY29tcGFyaW5nIGEgc3RyaW5nICB0aGF0IGlzIGluc2lkZSBhbiBvYmplY3RcclxuICAgICAgICAgICAgcmV0dXJuIHZhbHVlLmZpbHRlcigoaXRlbTogYW55KTogYm9vbGVhbiA9PiB7XHJcbiAgICAgICAgICAgICAgICByZXR1cm4gKGl0ZW0udGV4dC5pbmRleE9mKGFyZ3MpICE9PSAtMSkgPyB0cnVlIDogZmFsc2U7XHJcbiAgICAgICAgICAgIH0pO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxufVxyXG4iXX0=