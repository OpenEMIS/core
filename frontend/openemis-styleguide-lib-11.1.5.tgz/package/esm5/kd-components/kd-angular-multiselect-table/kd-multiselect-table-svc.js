import { __decorate } from "tslib";
import { Injectable } from '@angular/core';
var KdMultiSelectTableSvc = /** @class */ (function () {
    function KdMultiSelectTableSvc() {
    }
    KdMultiSelectTableSvc.prototype.getBothOptions = function (_config, _masterData, _slaveData) {
        // let masterData = (typeof config.masterData != "undefined") ? config.masterData.slice() : [];
        // let slaveData = (typeof config.slaveData != "undefined") ? config.slaveData.slice() : [];
        // console.log(_config);
        // console.log(_masterData);
        // console.log(_slaveData);
        var updatedOptions = {
            masterGridOption: this._getGridOptions('master', _masterData),
            slaveGridOption: this._getGridOptions('slave', _slaveData)
        };
        return updatedOptions;
    };
    KdMultiSelectTableSvc.prototype.getPrimarykey = function (config) {
        // if user set more than one primary key, only the first one will be used.
        if (typeof config.colDef !== 'undefined') {
            for (var i in config.colDef) {
                if (config.colDef[i].primaryKey) {
                    return i;
                }
            }
            return 'id';
        }
    };
    KdMultiSelectTableSvc.prototype.getColDefs = function (_colDef) {
        var updatedColDef = [];
        for (var i in _colDef) {
            if (typeof _colDef[i] !== 'undefined') {
                var tableColumn = {
                    headerName: _colDef[i].headerName,
                    field: i,
                    colId: i,
                    cellClass: 'ag-default',
                    menuTabs: []
                };
                updatedColDef.push(tableColumn);
            }
        }
        return updatedColDef;
    };
    KdMultiSelectTableSvc.prototype.getPlaceholder = function (config, grid) {
        // grid is either top or bottom
        var query = grid + 'Placeholder';
        if (typeof config.gridSetting !== 'undefined' && typeof config.gridSetting[query] !== 'undefined')
            return config.gridSetting[query];
        return 'Undefined';
    };
    KdMultiSelectTableSvc.prototype.getButton = function (config, grid) {
        // grid is either toTopBtn or toBottomBtn
        var updatedBtn = {};
        if (typeof config.gridSetting !== 'undefined' && typeof config.gridSetting[grid].icon !== 'undefined')
            updatedBtn.icon = config.gridSetting[grid].icon;
        else
            updatedBtn.icon = '';
        if (typeof config.gridSetting[grid] !== 'undefined' && typeof config.gridSetting[grid].text !== 'undefined')
            updatedBtn.text = config.gridSetting[grid].text;
        else
            updatedBtn.text = 'Undefined';
        return updatedBtn;
    };
    KdMultiSelectTableSvc.prototype.getCheckboxDefault = function () {
        return {
            width: 50,
            minWidth: 50,
            maxWidth: 50,
            colId: 'checkbox',
            headerName: '',
            suppressMenu: true,
            suppressSorting: true,
            suppressSizeToFit: true,
            cellClass: 'ag-checkbox-radio'
        };
    };
    KdMultiSelectTableSvc.prototype.calcMobileHeight = function (masterGrid, slaveGrid, vcr) {
        var topData = masterGrid.api.getModel().getRowCount();
        var bottomData = slaveGrid.api.getModel().getRowCount();
        var topHeight = (typeof topData !== 'undefined' && topData > 0) ? this._getGridHeight(topData, 'top') : 150;
        var bottomHeight = (typeof bottomData !== 'undefined' && bottomData > 0) ? this._getGridHeight(bottomData, 'bottom') : 150;
        var result = {
            top: topHeight,
            bottom: bottomHeight
        };
        return result;
    };
    KdMultiSelectTableSvc.prototype.calcWebHeight = function (height) {
        var separator = 65;
        var checkedHeight = ((typeof height !== 'number') ? 600 : height) - separator;
        var bottomHeight = (checkedHeight - 38) / 2;
        var webHeight = {
            top: bottomHeight + 38,
            bottom: bottomHeight
        };
        return webHeight;
    };
    // getColDefWidth(_gridOptions: GridOptions): Array<any> {
    //     let column: Array<Column> = _gridOptions.columnApi.getAllColumns();
    //     let colWidth: Array<number> = [];
    //     for(let i: number = 0; i < column.length; i++){
    //         if(column[i].getColId() !== 'checkbox') {
    //             colWidth.push(column[i].getActualWidth() + 30);
    //         }
    //         else{
    //             colWidth.push(50);
    //         }
    //     }
    //     // console.log(colWidth);
    //     return colWidth;
    // }
    // getColTotalWidth(_colArray: Array<number>): number {
    //     let total: number = 0;
    //     for (let i: number = 0; i < _colArray.length; i++) {
    //         total += _colArray[i];
    //     }
    //     return total;
    // }
    // getUsableWidth(_vcr: ViewContainerRef): number {
    //     let agGridEle: HTMLElement = _vcr.element.nativeElement.querySelector('.stg-theme');
    //     let parentWidth: number = Math.round(agGridEle.getBoundingClientRect().width);
    //     let computedStyle: CSSStyleDeclaration = window.getComputedStyle(agGridEle);
    //     let borderLeft: number = (computedStyle.borderLeft !== '') ? parseInt(computedStyle.borderLeft) : 0;
    //     let borderRight: number = (computedStyle.borderRight !== '') ? parseInt(computedStyle.borderRight) : 0;
    //     let borderLeftRight = borderLeft + borderRight
    //     return parentWidth - borderLeftRight;
    // }
    KdMultiSelectTableSvc.prototype.checkSelection = function (topOptions, bottomOptions) {
        var updateDisabled = { top: true, bottom: true };
        updateDisabled.top = (topOptions.api.getSelectedNodes().length > 0) ? false : true;
        updateDisabled.bottom = (bottomOptions.api.getSelectedNodes().length > 0) ? false : true;
        return updateDisabled;
    };
    KdMultiSelectTableSvc.prototype.checkOverlay = function (topOptions, bottomOptions) {
        var topOverlay = (topOptions.api.getModel().getRowCount() > 0) ? false : true;
        var bottomOverlay = (bottomOptions.api.getModel().getRowCount() > 0) ? false : true;
        if (topOverlay)
            topOptions.api.showNoRowsOverlay();
        else
            topOptions.api.hideOverlay();
        if (bottomOverlay)
            bottomOptions.api.showNoRowsOverlay();
        else
            bottomOptions.api.hideOverlay();
    };
    // setRtlView(_gridOptions: GridOptions): void {
    //     let colDefLength: number = _gridOptions.columnDefs.length;
    //     for (let i: number = 0; i < colDefLength; i++) {
    //         _gridOptions.columnApi.moveColumn(0, colDefLength - (i + 1));
    //     }
    //     // _gridOptions.api.setColumnDefs(_gridOptions.columnDefs);
    //     _gridOptions.api.refreshView();
    // }
    KdMultiSelectTableSvc.prototype.setCheckboxFalseAfterUpdate = function (vcr) {
        var selectAllCheckbox = vcr.element.nativeElement.querySelectorAll('.selection-wrapper input.select-all');
        for (var i = 0; i < selectAllCheckbox.length; i++) {
            selectAllCheckbox[i].checked = false;
        }
    };
    KdMultiSelectTableSvc.prototype.setCheckboxFalse = function (removedElement) {
        for (var i = 0; i < removedElement.length; i++) {
            removedElement[i].checked = false;
        }
    };
    KdMultiSelectTableSvc.prototype._getGridHeight = function (dataCount, grid) {
        var floatingHeight = 38;
        var headerHeight = (grid === 'top') ? 38 : 0;
        var dataHeight = 38 * dataCount;
        return (floatingHeight + headerHeight + dataHeight + 8);
        /*   height calculation based on vcr
            let totalHeight: number = 0;
            let queryEleString: string = '#' + grid;
            let nativeEle: Element = vcr.element.nativeElement.querySelector(queryEleString);
            console.log(nativeEle);
            totalHeight += Math.ceil(nativeEle.querySelector('.ag-header-container').getBoundingClientRect().height);
            totalHeight += Math.ceil(nativeEle.querySelector('.ag-body-container').getBoundingClientRect().height);
            totalHeight += Math.ceil(nativeEle.querySelector('.ag-floating-top-full-width-container').getBoundingClientRect().height);
            let paginationBottom: Element = nativeEle.querySelector('#south')
            if(paginationBottom !== null) {
                totalHeight += Math.ceil(paginationBottom.getBoundingClientRect().height);
            }

            totalHeight += 8;
            return totalHeight;
            */
    };
    KdMultiSelectTableSvc.prototype._getGridOptions = function (grid, rowData) {
        var options = {
            // rowData: [],
            rowData: rowData,
            columnDefs: [],
            // debug: true,
            headerHeight: (grid === 'slave') ? 0 : 38,
            rowHeight: 38,
            suppressContextMenu: true,
            // suppressMenuMainPanel: true,
            // suppressMenuColumnPanel: true,
            // suppressMenuFilterPanel: true,
            suppressMovableColumns: true,
            suppressMenuHide: true,
            suppressColumnVirtualisation: true,
            enableFilter: true,
            enableSorting: true,
            enableColResize: false,
            unSortIcon: true,
            icons: {
                // use font awesome for menu icons
                // menu: '<i class='fa fa-bars'/>',
                filter: '<i class="fa fa-filter"/>',
                sortAscending: '<i class="fa fa-caret-down"/>',
                sortDescending: '<i class="fa fa-caret-up"/>',
                sortUnSort: '<i class="fa fa-sort"/>',
                groupExpanded: '<i class="fa fa-minus-circle"/>',
                groupContracted: '<i class="fa fa-plus-circle"/>'
            },
            // onGridSizeChanged: function(e) {
            //     this.api.sizeColumnsToFit();
            // },
            getRowClass: function (params) {
                if (params.data.hasOwnProperty('newRow')) {
                    delete params.data.newRow;
                    return 'new-row-highlight';
                }
                return;
            },
            alignedGrids: [],
            overlayNoRowsTemplate: '<span class="ag-custom-overlay"><i class="fa fa-info-circle fa-lg margin-right10"></i>No student record found</span>'
        };
        return options;
    };
    KdMultiSelectTableSvc = __decorate([
        Injectable()
    ], KdMultiSelectTableSvc);
    return KdMultiSelectTableSvc;
}());
export { KdMultiSelectTableSvc };
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoia2QtbXVsdGlzZWxlY3QtdGFibGUtc3ZjLmpzIiwic291cmNlUm9vdCI6Im5nOi8vb3BlbmVtaXMtc3R5bGVndWlkZS1saWIvIiwic291cmNlcyI6WyJrZC1jb21wb25lbnRzL2tkLWFuZ3VsYXItbXVsdGlzZWxlY3QtdGFibGUva2QtbXVsdGlzZWxlY3QtdGFibGUtc3ZjLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7QUFBQSxPQUFPLEVBQUUsVUFBVSxFQUFvQixNQUFNLGVBQWUsQ0FBQztBQUk3RDtJQUFBO0lBK1BBLENBQUM7SUE5UEcsOENBQWMsR0FBZCxVQUFlLE9BQVksRUFBRSxXQUF1QixFQUFFLFVBQXNCO1FBQ3hFLCtGQUErRjtRQUMvRiw0RkFBNEY7UUFDNUYsd0JBQXdCO1FBQ3hCLDRCQUE0QjtRQUM1QiwyQkFBMkI7UUFFM0IsSUFBSSxjQUFjLEdBQVE7WUFDdEIsZ0JBQWdCLEVBQUUsSUFBSSxDQUFDLGVBQWUsQ0FBQyxRQUFRLEVBQUUsV0FBVyxDQUFDO1lBQzdELGVBQWUsRUFBRSxJQUFJLENBQUMsZUFBZSxDQUFDLE9BQU8sRUFBRSxVQUFVLENBQUM7U0FDN0QsQ0FBQztRQUVGLE9BQU8sY0FBYyxDQUFDO0lBQzFCLENBQUM7SUFFRCw2Q0FBYSxHQUFiLFVBQWMsTUFBVztRQUNyQiwwRUFBMEU7UUFDMUUsSUFBSSxPQUFPLE1BQU0sQ0FBQyxNQUFNLEtBQUssV0FBVyxFQUFFO1lBQ3RDLEtBQUssSUFBSSxDQUFDLElBQUksTUFBTSxDQUFDLE1BQU0sRUFBRTtnQkFDekIsSUFBSSxNQUFNLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLFVBQVUsRUFBRTtvQkFDN0IsT0FBTyxDQUFDLENBQUM7aUJBQ1o7YUFDSjtZQUNELE9BQU8sSUFBSSxDQUFDO1NBQ2Y7SUFDTCxDQUFDO0lBRUQsMENBQVUsR0FBVixVQUFXLE9BQVk7UUFDbkIsSUFBSSxhQUFhLEdBQWUsRUFBRSxDQUFDO1FBQ25DLEtBQUssSUFBSSxDQUFDLElBQUksT0FBTyxFQUFFO1lBQ25CLElBQUksT0FBTyxPQUFPLENBQUMsQ0FBQyxDQUFDLEtBQUssV0FBVyxFQUFFO2dCQUNuQyxJQUFJLFdBQVcsR0FBUTtvQkFDbkIsVUFBVSxFQUFFLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxVQUFVO29CQUNqQyxLQUFLLEVBQUUsQ0FBQztvQkFDUixLQUFLLEVBQUUsQ0FBQztvQkFDUixTQUFTLEVBQUUsWUFBWTtvQkFDdkIsUUFBUSxFQUFFLEVBQUU7aUJBQ2YsQ0FBQztnQkFFRixhQUFhLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxDQUFDO2FBQ25DO1NBQ0o7UUFDRCxPQUFPLGFBQWEsQ0FBQztJQUN6QixDQUFDO0lBRUQsOENBQWMsR0FBZCxVQUFlLE1BQVcsRUFBRSxJQUFZO1FBQ3BDLCtCQUErQjtRQUMvQixJQUFJLEtBQUssR0FBRyxJQUFJLEdBQUcsYUFBYSxDQUFDO1FBQ2pDLElBQUksT0FBTyxNQUFNLENBQUMsV0FBVyxLQUFLLFdBQVcsSUFBSSxPQUFPLE1BQU0sQ0FBQyxXQUFXLENBQUMsS0FBSyxDQUFDLEtBQUssV0FBVztZQUFFLE9BQU8sTUFBTSxDQUFDLFdBQVcsQ0FBQyxLQUFLLENBQUMsQ0FBQztRQUNwSSxPQUFPLFdBQVcsQ0FBQztJQUN2QixDQUFDO0lBRUQseUNBQVMsR0FBVCxVQUFVLE1BQVcsRUFBRSxJQUFTO1FBQzVCLHlDQUF5QztRQUN6QyxJQUFJLFVBQVUsR0FBUSxFQUFFLENBQUM7UUFFekIsSUFBSSxPQUFPLE1BQU0sQ0FBQyxXQUFXLEtBQUssV0FBVyxJQUFJLE9BQU8sTUFBTSxDQUFDLFdBQVcsQ0FBQyxJQUFJLENBQUMsQ0FBQyxJQUFJLEtBQUssV0FBVztZQUFFLFVBQVUsQ0FBQyxJQUFJLEdBQUcsTUFBTSxDQUFDLFdBQVcsQ0FBQyxJQUFJLENBQUMsQ0FBQyxJQUFJLENBQUM7O1lBQ2xKLFVBQVUsQ0FBQyxJQUFJLEdBQUcsRUFBRSxDQUFDO1FBRTFCLElBQUksT0FBTyxNQUFNLENBQUMsV0FBVyxDQUFDLElBQUksQ0FBQyxLQUFLLFdBQVcsSUFBSSxPQUFPLE1BQU0sQ0FBQyxXQUFXLENBQUMsSUFBSSxDQUFDLENBQUMsSUFBSSxLQUFLLFdBQVc7WUFBRSxVQUFVLENBQUMsSUFBSSxHQUFHLE1BQU0sQ0FBQyxXQUFXLENBQUMsSUFBSSxDQUFDLENBQUMsSUFBSSxDQUFDOztZQUN4SixVQUFVLENBQUMsSUFBSSxHQUFHLFdBQVcsQ0FBQztRQUVuQyxPQUFPLFVBQVUsQ0FBQztJQUN0QixDQUFDO0lBRUQsa0RBQWtCLEdBQWxCO1FBQ0ksT0FBTztZQUNILEtBQUssRUFBRSxFQUFFO1lBQ1QsUUFBUSxFQUFFLEVBQUU7WUFDWixRQUFRLEVBQUUsRUFBRTtZQUNaLEtBQUssRUFBRSxVQUFVO1lBQ2pCLFVBQVUsRUFBRSxFQUFFO1lBQ2QsWUFBWSxFQUFFLElBQUk7WUFDbEIsZUFBZSxFQUFFLElBQUk7WUFDckIsaUJBQWlCLEVBQUUsSUFBSTtZQUN2QixTQUFTLEVBQUUsbUJBQW1CO1NBQ2pDLENBQUM7SUFDTixDQUFDO0lBRUQsZ0RBQWdCLEdBQWhCLFVBQWlCLFVBQXVCLEVBQUUsU0FBc0IsRUFBRSxHQUFxQjtRQUNuRixJQUFJLE9BQU8sR0FBVyxVQUFVLENBQUMsR0FBRyxDQUFDLFFBQVEsRUFBRSxDQUFDLFdBQVcsRUFBRSxDQUFDO1FBQzlELElBQUksVUFBVSxHQUFXLFNBQVMsQ0FBQyxHQUFHLENBQUMsUUFBUSxFQUFFLENBQUMsV0FBVyxFQUFFLENBQUM7UUFDaEUsSUFBSSxTQUFTLEdBQUcsQ0FBQyxPQUFPLE9BQU8sS0FBSyxXQUFXLElBQUksT0FBTyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsY0FBYyxDQUFDLE9BQU8sRUFBRSxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDO1FBQzVHLElBQUksWUFBWSxHQUFHLENBQUMsT0FBTyxVQUFVLEtBQUssV0FBVyxJQUFJLFVBQVUsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLGNBQWMsQ0FBQyxVQUFVLEVBQUUsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQztRQUMzSCxJQUFJLE1BQU0sR0FBUTtZQUNkLEdBQUcsRUFBRSxTQUFTO1lBQ2QsTUFBTSxFQUFFLFlBQVk7U0FDdkIsQ0FBQztRQUNGLE9BQU8sTUFBTSxDQUFDO0lBQ2xCLENBQUM7SUFFRCw2Q0FBYSxHQUFiLFVBQWMsTUFBYztRQUN4QixJQUFJLFNBQVMsR0FBVyxFQUFFLENBQUM7UUFDM0IsSUFBSSxhQUFhLEdBQVcsQ0FBQyxDQUFDLE9BQU8sTUFBTSxLQUFLLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxHQUFHLFNBQVMsQ0FBQztRQUN0RixJQUFJLFlBQVksR0FBVyxDQUFDLGFBQWEsR0FBRyxFQUFFLENBQUMsR0FBRyxDQUFDLENBQUM7UUFDcEQsSUFBSSxTQUFTLEdBQVE7WUFDakIsR0FBRyxFQUFFLFlBQVksR0FBRyxFQUFFO1lBQ3RCLE1BQU0sRUFBRSxZQUFZO1NBQ3ZCLENBQUM7UUFFRixPQUFPLFNBQVMsQ0FBQztJQUNyQixDQUFDO0lBRUQsMERBQTBEO0lBQzFELDBFQUEwRTtJQUMxRSx3Q0FBd0M7SUFDeEMsc0RBQXNEO0lBQ3RELG9EQUFvRDtJQUNwRCw4REFBOEQ7SUFDOUQsWUFBWTtJQUNaLGdCQUFnQjtJQUNoQixpQ0FBaUM7SUFDakMsWUFBWTtJQUNaLFFBQVE7SUFFUixnQ0FBZ0M7SUFDaEMsdUJBQXVCO0lBQ3ZCLElBQUk7SUFFSix1REFBdUQ7SUFDdkQsNkJBQTZCO0lBRTdCLDJEQUEyRDtJQUMzRCxpQ0FBaUM7SUFDakMsUUFBUTtJQUVSLG9CQUFvQjtJQUNwQixJQUFJO0lBRUosbURBQW1EO0lBQ25ELDJGQUEyRjtJQUMzRixxRkFBcUY7SUFDckYsbUZBQW1GO0lBQ25GLDJHQUEyRztJQUMzRyw4R0FBOEc7SUFDOUcscURBQXFEO0lBQ3JELDRDQUE0QztJQUM1QyxJQUFJO0lBRUosOENBQWMsR0FBZCxVQUFlLFVBQXVCLEVBQUUsYUFBMEI7UUFDOUQsSUFBSSxjQUFjLEdBQVEsRUFBRSxHQUFHLEVBQUUsSUFBSSxFQUFFLE1BQU0sRUFBRSxJQUFJLEVBQUUsQ0FBQztRQUV0RCxjQUFjLENBQUMsR0FBRyxHQUFHLENBQUMsVUFBVSxDQUFDLEdBQUcsQ0FBQyxnQkFBZ0IsRUFBRSxDQUFDLE1BQU0sR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUM7UUFDbkYsY0FBYyxDQUFDLE1BQU0sR0FBRyxDQUFDLGFBQWEsQ0FBQyxHQUFHLENBQUMsZ0JBQWdCLEVBQUUsQ0FBQyxNQUFNLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDO1FBRXpGLE9BQU8sY0FBYyxDQUFDO0lBQzFCLENBQUM7SUFFRCw0Q0FBWSxHQUFaLFVBQWEsVUFBdUIsRUFBRSxhQUEwQjtRQUM1RCxJQUFJLFVBQVUsR0FBWSxDQUFDLFVBQVUsQ0FBQyxHQUFHLENBQUMsUUFBUSxFQUFFLENBQUMsV0FBVyxFQUFFLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDO1FBQ3ZGLElBQUksYUFBYSxHQUFZLENBQUMsYUFBYSxDQUFDLEdBQUcsQ0FBQyxRQUFRLEVBQUUsQ0FBQyxXQUFXLEVBQUUsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUM7UUFFN0YsSUFBSSxVQUFVO1lBQUUsVUFBVSxDQUFDLEdBQUcsQ0FBQyxpQkFBaUIsRUFBRSxDQUFDOztZQUM5QyxVQUFVLENBQUMsR0FBRyxDQUFDLFdBQVcsRUFBRSxDQUFDO1FBQ2xDLElBQUksYUFBYTtZQUFFLGFBQWEsQ0FBQyxHQUFHLENBQUMsaUJBQWlCLEVBQUUsQ0FBQzs7WUFDcEQsYUFBYSxDQUFDLEdBQUcsQ0FBQyxXQUFXLEVBQUUsQ0FBQztJQUN6QyxDQUFDO0lBRUQsZ0RBQWdEO0lBQ2hELGlFQUFpRTtJQUNqRSx1REFBdUQ7SUFDdkQsd0VBQXdFO0lBQ3hFLFFBQVE7SUFDUixrRUFBa0U7SUFDbEUsc0NBQXNDO0lBQ3RDLElBQUk7SUFFSiwyREFBMkIsR0FBM0IsVUFBNEIsR0FBcUI7UUFDN0MsSUFBSSxpQkFBaUIsR0FBZSxHQUFHLENBQUMsT0FBTyxDQUFDLGFBQWEsQ0FBQyxnQkFBZ0IsQ0FBQyxxQ0FBcUMsQ0FBQyxDQUFDO1FBQ3RILEtBQUssSUFBSSxDQUFDLEdBQVcsQ0FBQyxFQUFFLENBQUMsR0FBRyxpQkFBaUIsQ0FBQyxNQUFNLEVBQUUsQ0FBQyxFQUFFLEVBQUU7WUFDdkQsaUJBQWlCLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxHQUFHLEtBQUssQ0FBQztTQUN4QztJQUNMLENBQUM7SUFFRCxnREFBZ0IsR0FBaEIsVUFBaUIsY0FBdUM7UUFDcEQsS0FBSyxJQUFJLENBQUMsR0FBVyxDQUFDLEVBQUUsQ0FBQyxHQUFHLGNBQWMsQ0FBQyxNQUFNLEVBQUUsQ0FBQyxFQUFFLEVBQUU7WUFDcEQsY0FBYyxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sR0FBRyxLQUFLLENBQUM7U0FDckM7SUFDTCxDQUFDO0lBRU8sOENBQWMsR0FBdEIsVUFBdUIsU0FBaUIsRUFBRSxJQUFZO1FBQ2xELElBQUksY0FBYyxHQUFHLEVBQUUsQ0FBQztRQUN4QixJQUFJLFlBQVksR0FBRyxDQUFDLElBQUksS0FBSyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7UUFDN0MsSUFBSSxVQUFVLEdBQUcsRUFBRSxHQUFHLFNBQVMsQ0FBQztRQUVoQyxPQUFPLENBQUMsY0FBYyxHQUFHLFlBQVksR0FBRyxVQUFVLEdBQUcsQ0FBQyxDQUFDLENBQUM7UUFFeEQ7Ozs7Ozs7Ozs7Ozs7OztjQWVNO0lBQ1YsQ0FBQztJQUVPLCtDQUFlLEdBQXZCLFVBQXdCLElBQVksRUFBRSxPQUFtQjtRQUNyRCxJQUFJLE9BQU8sR0FBUTtZQUNmLGVBQWU7WUFDZixPQUFPLEVBQUUsT0FBTztZQUNoQixVQUFVLEVBQUUsRUFBRTtZQUNkLGVBQWU7WUFFZixZQUFZLEVBQUUsQ0FBQyxJQUFJLEtBQUssT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRTtZQUN6QyxTQUFTLEVBQUUsRUFBRTtZQUViLG1CQUFtQixFQUFFLElBQUk7WUFDekIsK0JBQStCO1lBQy9CLGlDQUFpQztZQUNqQyxpQ0FBaUM7WUFDakMsc0JBQXNCLEVBQUUsSUFBSTtZQUM1QixnQkFBZ0IsRUFBRSxJQUFJO1lBQ3RCLDRCQUE0QixFQUFFLElBQUk7WUFDbEMsWUFBWSxFQUFFLElBQUk7WUFDbEIsYUFBYSxFQUFFLElBQUk7WUFDbkIsZUFBZSxFQUFFLEtBQUs7WUFFdEIsVUFBVSxFQUFFLElBQUk7WUFDaEIsS0FBSyxFQUFFO2dCQUNILGtDQUFrQztnQkFDbEMsbUNBQW1DO2dCQUNuQyxNQUFNLEVBQUUsMkJBQTJCO2dCQUNuQyxhQUFhLEVBQUUsK0JBQStCO2dCQUM5QyxjQUFjLEVBQUUsNkJBQTZCO2dCQUM3QyxVQUFVLEVBQUUseUJBQXlCO2dCQUNyQyxhQUFhLEVBQUUsaUNBQWlDO2dCQUNoRCxlQUFlLEVBQUUsZ0NBQWdDO2FBQ3BEO1lBQ0QsbUNBQW1DO1lBQ25DLG1DQUFtQztZQUNuQyxLQUFLO1lBQ0wsV0FBVyxFQUFFLFVBQVMsTUFBZTtnQkFDakMsSUFBSSxNQUFNLENBQUMsSUFBSSxDQUFDLGNBQWMsQ0FBQyxRQUFRLENBQUMsRUFBRTtvQkFDdEMsT0FBTyxNQUFNLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQztvQkFDMUIsT0FBTyxtQkFBbUIsQ0FBQztpQkFDOUI7Z0JBQ0QsT0FBTztZQUNYLENBQUM7WUFDRCxZQUFZLEVBQUUsRUFBRTtZQUNoQixxQkFBcUIsRUFBRSxzSEFBc0g7U0FDaEosQ0FBQztRQUdGLE9BQU8sT0FBTyxDQUFDO0lBQ25CLENBQUM7SUE5UFEscUJBQXFCO1FBRGpDLFVBQVUsRUFBRTtPQUNBLHFCQUFxQixDQStQakM7SUFBRCw0QkFBQztDQUFBLEFBL1BELElBK1BDO1NBL1BZLHFCQUFxQiIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IEluamVjdGFibGUsIFZpZXdDb250YWluZXJSZWYgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcclxuaW1wb3J0IHsgUm93Tm9kZSwgR3JpZE9wdGlvbnMgfSBmcm9tICdhZy1ncmlkLWNvbW11bml0eSc7XHJcblxyXG5ASW5qZWN0YWJsZSgpXHJcbmV4cG9ydCBjbGFzcyBLZE11bHRpU2VsZWN0VGFibGVTdmMge1xyXG4gICAgZ2V0Qm90aE9wdGlvbnMoX2NvbmZpZzogYW55LCBfbWFzdGVyRGF0YTogQXJyYXk8YW55PiwgX3NsYXZlRGF0YTogQXJyYXk8YW55Pik6IGFueSB7XHJcbiAgICAgICAgLy8gbGV0IG1hc3RlckRhdGEgPSAodHlwZW9mIGNvbmZpZy5tYXN0ZXJEYXRhICE9IFwidW5kZWZpbmVkXCIpID8gY29uZmlnLm1hc3RlckRhdGEuc2xpY2UoKSA6IFtdO1xyXG4gICAgICAgIC8vIGxldCBzbGF2ZURhdGEgPSAodHlwZW9mIGNvbmZpZy5zbGF2ZURhdGEgIT0gXCJ1bmRlZmluZWRcIikgPyBjb25maWcuc2xhdmVEYXRhLnNsaWNlKCkgOiBbXTtcclxuICAgICAgICAvLyBjb25zb2xlLmxvZyhfY29uZmlnKTtcclxuICAgICAgICAvLyBjb25zb2xlLmxvZyhfbWFzdGVyRGF0YSk7XHJcbiAgICAgICAgLy8gY29uc29sZS5sb2coX3NsYXZlRGF0YSk7XHJcblxyXG4gICAgICAgIGxldCB1cGRhdGVkT3B0aW9uczogYW55ID0ge1xyXG4gICAgICAgICAgICBtYXN0ZXJHcmlkT3B0aW9uOiB0aGlzLl9nZXRHcmlkT3B0aW9ucygnbWFzdGVyJywgX21hc3RlckRhdGEpLFxyXG4gICAgICAgICAgICBzbGF2ZUdyaWRPcHRpb246IHRoaXMuX2dldEdyaWRPcHRpb25zKCdzbGF2ZScsIF9zbGF2ZURhdGEpXHJcbiAgICAgICAgfTtcclxuXHJcbiAgICAgICAgcmV0dXJuIHVwZGF0ZWRPcHRpb25zO1xyXG4gICAgfVxyXG5cclxuICAgIGdldFByaW1hcnlrZXkoY29uZmlnOiBhbnkpOiBhbnkge1xyXG4gICAgICAgIC8vIGlmIHVzZXIgc2V0IG1vcmUgdGhhbiBvbmUgcHJpbWFyeSBrZXksIG9ubHkgdGhlIGZpcnN0IG9uZSB3aWxsIGJlIHVzZWQuXHJcbiAgICAgICAgaWYgKHR5cGVvZiBjb25maWcuY29sRGVmICE9PSAndW5kZWZpbmVkJykge1xyXG4gICAgICAgICAgICBmb3IgKGxldCBpIGluIGNvbmZpZy5jb2xEZWYpIHtcclxuICAgICAgICAgICAgICAgIGlmIChjb25maWcuY29sRGVmW2ldLnByaW1hcnlLZXkpIHtcclxuICAgICAgICAgICAgICAgICAgICByZXR1cm4gaTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICByZXR1cm4gJ2lkJztcclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgZ2V0Q29sRGVmcyhfY29sRGVmOiBhbnkpOiBBcnJheTxhbnk+IHtcclxuICAgICAgICBsZXQgdXBkYXRlZENvbERlZjogQXJyYXk8YW55PiA9IFtdO1xyXG4gICAgICAgIGZvciAobGV0IGkgaW4gX2NvbERlZikge1xyXG4gICAgICAgICAgICBpZiAodHlwZW9mIF9jb2xEZWZbaV0gIT09ICd1bmRlZmluZWQnKSB7XHJcbiAgICAgICAgICAgICAgICBsZXQgdGFibGVDb2x1bW46IGFueSA9IHtcclxuICAgICAgICAgICAgICAgICAgICBoZWFkZXJOYW1lOiBfY29sRGVmW2ldLmhlYWRlck5hbWUsXHJcbiAgICAgICAgICAgICAgICAgICAgZmllbGQ6IGksXHJcbiAgICAgICAgICAgICAgICAgICAgY29sSWQ6IGksXHJcbiAgICAgICAgICAgICAgICAgICAgY2VsbENsYXNzOiAnYWctZGVmYXVsdCcsXHJcbiAgICAgICAgICAgICAgICAgICAgbWVudVRhYnM6IFtdXHJcbiAgICAgICAgICAgICAgICB9O1xyXG5cclxuICAgICAgICAgICAgICAgIHVwZGF0ZWRDb2xEZWYucHVzaCh0YWJsZUNvbHVtbik7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICAgICAgcmV0dXJuIHVwZGF0ZWRDb2xEZWY7XHJcbiAgICB9XHJcblxyXG4gICAgZ2V0UGxhY2Vob2xkZXIoY29uZmlnOiBhbnksIGdyaWQ6IHN0cmluZyk6IHN0cmluZyB7XHJcbiAgICAgICAgLy8gZ3JpZCBpcyBlaXRoZXIgdG9wIG9yIGJvdHRvbVxyXG4gICAgICAgIGxldCBxdWVyeSA9IGdyaWQgKyAnUGxhY2Vob2xkZXInO1xyXG4gICAgICAgIGlmICh0eXBlb2YgY29uZmlnLmdyaWRTZXR0aW5nICE9PSAndW5kZWZpbmVkJyAmJiB0eXBlb2YgY29uZmlnLmdyaWRTZXR0aW5nW3F1ZXJ5XSAhPT0gJ3VuZGVmaW5lZCcpIHJldHVybiBjb25maWcuZ3JpZFNldHRpbmdbcXVlcnldO1xyXG4gICAgICAgIHJldHVybiAnVW5kZWZpbmVkJztcclxuICAgIH1cclxuXHJcbiAgICBnZXRCdXR0b24oY29uZmlnOiBhbnksIGdyaWQ6IGFueSk6IGFueSB7XHJcbiAgICAgICAgLy8gZ3JpZCBpcyBlaXRoZXIgdG9Ub3BCdG4gb3IgdG9Cb3R0b21CdG5cclxuICAgICAgICBsZXQgdXBkYXRlZEJ0bjogYW55ID0ge307XHJcblxyXG4gICAgICAgIGlmICh0eXBlb2YgY29uZmlnLmdyaWRTZXR0aW5nICE9PSAndW5kZWZpbmVkJyAmJiB0eXBlb2YgY29uZmlnLmdyaWRTZXR0aW5nW2dyaWRdLmljb24gIT09ICd1bmRlZmluZWQnKSB1cGRhdGVkQnRuLmljb24gPSBjb25maWcuZ3JpZFNldHRpbmdbZ3JpZF0uaWNvbjtcclxuICAgICAgICBlbHNlIHVwZGF0ZWRCdG4uaWNvbiA9ICcnO1xyXG5cclxuICAgICAgICBpZiAodHlwZW9mIGNvbmZpZy5ncmlkU2V0dGluZ1tncmlkXSAhPT0gJ3VuZGVmaW5lZCcgJiYgdHlwZW9mIGNvbmZpZy5ncmlkU2V0dGluZ1tncmlkXS50ZXh0ICE9PSAndW5kZWZpbmVkJykgdXBkYXRlZEJ0bi50ZXh0ID0gY29uZmlnLmdyaWRTZXR0aW5nW2dyaWRdLnRleHQ7XHJcbiAgICAgICAgZWxzZSB1cGRhdGVkQnRuLnRleHQgPSAnVW5kZWZpbmVkJztcclxuXHJcbiAgICAgICAgcmV0dXJuIHVwZGF0ZWRCdG47XHJcbiAgICB9XHJcblxyXG4gICAgZ2V0Q2hlY2tib3hEZWZhdWx0KCk6IGFueSB7XHJcbiAgICAgICAgcmV0dXJuIHtcclxuICAgICAgICAgICAgd2lkdGg6IDUwLFxyXG4gICAgICAgICAgICBtaW5XaWR0aDogNTAsXHJcbiAgICAgICAgICAgIG1heFdpZHRoOiA1MCxcclxuICAgICAgICAgICAgY29sSWQ6ICdjaGVja2JveCcsXHJcbiAgICAgICAgICAgIGhlYWRlck5hbWU6ICcnLFxyXG4gICAgICAgICAgICBzdXBwcmVzc01lbnU6IHRydWUsXHJcbiAgICAgICAgICAgIHN1cHByZXNzU29ydGluZzogdHJ1ZSxcclxuICAgICAgICAgICAgc3VwcHJlc3NTaXplVG9GaXQ6IHRydWUsXHJcbiAgICAgICAgICAgIGNlbGxDbGFzczogJ2FnLWNoZWNrYm94LXJhZGlvJ1xyXG4gICAgICAgIH07XHJcbiAgICB9XHJcblxyXG4gICAgY2FsY01vYmlsZUhlaWdodChtYXN0ZXJHcmlkOiBHcmlkT3B0aW9ucywgc2xhdmVHcmlkOiBHcmlkT3B0aW9ucywgdmNyOiBWaWV3Q29udGFpbmVyUmVmKTogYW55IHtcclxuICAgICAgICBsZXQgdG9wRGF0YTogbnVtYmVyID0gbWFzdGVyR3JpZC5hcGkuZ2V0TW9kZWwoKS5nZXRSb3dDb3VudCgpO1xyXG4gICAgICAgIGxldCBib3R0b21EYXRhOiBudW1iZXIgPSBzbGF2ZUdyaWQuYXBpLmdldE1vZGVsKCkuZ2V0Um93Q291bnQoKTtcclxuICAgICAgICBsZXQgdG9wSGVpZ2h0ID0gKHR5cGVvZiB0b3BEYXRhICE9PSAndW5kZWZpbmVkJyAmJiB0b3BEYXRhID4gMCkgPyB0aGlzLl9nZXRHcmlkSGVpZ2h0KHRvcERhdGEsICd0b3AnKSA6IDE1MDtcclxuICAgICAgICBsZXQgYm90dG9tSGVpZ2h0ID0gKHR5cGVvZiBib3R0b21EYXRhICE9PSAndW5kZWZpbmVkJyAmJiBib3R0b21EYXRhID4gMCkgPyB0aGlzLl9nZXRHcmlkSGVpZ2h0KGJvdHRvbURhdGEsICdib3R0b20nKSA6IDE1MDtcclxuICAgICAgICBsZXQgcmVzdWx0OiBhbnkgPSB7XHJcbiAgICAgICAgICAgIHRvcDogdG9wSGVpZ2h0LFxyXG4gICAgICAgICAgICBib3R0b206IGJvdHRvbUhlaWdodFxyXG4gICAgICAgIH07XHJcbiAgICAgICAgcmV0dXJuIHJlc3VsdDtcclxuICAgIH1cclxuXHJcbiAgICBjYWxjV2ViSGVpZ2h0KGhlaWdodDogbnVtYmVyKTogYW55IHtcclxuICAgICAgICBsZXQgc2VwYXJhdG9yOiBudW1iZXIgPSA2NTtcclxuICAgICAgICBsZXQgY2hlY2tlZEhlaWdodDogbnVtYmVyID0gKCh0eXBlb2YgaGVpZ2h0ICE9PSAnbnVtYmVyJykgPyA2MDAgOiBoZWlnaHQpIC0gc2VwYXJhdG9yO1xyXG4gICAgICAgIGxldCBib3R0b21IZWlnaHQ6IG51bWJlciA9IChjaGVja2VkSGVpZ2h0IC0gMzgpIC8gMjtcclxuICAgICAgICBsZXQgd2ViSGVpZ2h0OiBhbnkgPSB7XHJcbiAgICAgICAgICAgIHRvcDogYm90dG9tSGVpZ2h0ICsgMzgsXHJcbiAgICAgICAgICAgIGJvdHRvbTogYm90dG9tSGVpZ2h0XHJcbiAgICAgICAgfTtcclxuXHJcbiAgICAgICAgcmV0dXJuIHdlYkhlaWdodDtcclxuICAgIH1cclxuXHJcbiAgICAvLyBnZXRDb2xEZWZXaWR0aChfZ3JpZE9wdGlvbnM6IEdyaWRPcHRpb25zKTogQXJyYXk8YW55PiB7XHJcbiAgICAvLyAgICAgbGV0IGNvbHVtbjogQXJyYXk8Q29sdW1uPiA9IF9ncmlkT3B0aW9ucy5jb2x1bW5BcGkuZ2V0QWxsQ29sdW1ucygpO1xyXG4gICAgLy8gICAgIGxldCBjb2xXaWR0aDogQXJyYXk8bnVtYmVyPiA9IFtdO1xyXG4gICAgLy8gICAgIGZvcihsZXQgaTogbnVtYmVyID0gMDsgaSA8IGNvbHVtbi5sZW5ndGg7IGkrKyl7XHJcbiAgICAvLyAgICAgICAgIGlmKGNvbHVtbltpXS5nZXRDb2xJZCgpICE9PSAnY2hlY2tib3gnKSB7XHJcbiAgICAvLyAgICAgICAgICAgICBjb2xXaWR0aC5wdXNoKGNvbHVtbltpXS5nZXRBY3R1YWxXaWR0aCgpICsgMzApO1xyXG4gICAgLy8gICAgICAgICB9XHJcbiAgICAvLyAgICAgICAgIGVsc2V7XHJcbiAgICAvLyAgICAgICAgICAgICBjb2xXaWR0aC5wdXNoKDUwKTtcclxuICAgIC8vICAgICAgICAgfVxyXG4gICAgLy8gICAgIH1cclxuXHJcbiAgICAvLyAgICAgLy8gY29uc29sZS5sb2coY29sV2lkdGgpO1xyXG4gICAgLy8gICAgIHJldHVybiBjb2xXaWR0aDtcclxuICAgIC8vIH1cclxuXHJcbiAgICAvLyBnZXRDb2xUb3RhbFdpZHRoKF9jb2xBcnJheTogQXJyYXk8bnVtYmVyPik6IG51bWJlciB7XHJcbiAgICAvLyAgICAgbGV0IHRvdGFsOiBudW1iZXIgPSAwO1xyXG5cclxuICAgIC8vICAgICBmb3IgKGxldCBpOiBudW1iZXIgPSAwOyBpIDwgX2NvbEFycmF5Lmxlbmd0aDsgaSsrKSB7XHJcbiAgICAvLyAgICAgICAgIHRvdGFsICs9IF9jb2xBcnJheVtpXTtcclxuICAgIC8vICAgICB9XHJcblxyXG4gICAgLy8gICAgIHJldHVybiB0b3RhbDtcclxuICAgIC8vIH1cclxuXHJcbiAgICAvLyBnZXRVc2FibGVXaWR0aChfdmNyOiBWaWV3Q29udGFpbmVyUmVmKTogbnVtYmVyIHtcclxuICAgIC8vICAgICBsZXQgYWdHcmlkRWxlOiBIVE1MRWxlbWVudCA9IF92Y3IuZWxlbWVudC5uYXRpdmVFbGVtZW50LnF1ZXJ5U2VsZWN0b3IoJy5zdGctdGhlbWUnKTtcclxuICAgIC8vICAgICBsZXQgcGFyZW50V2lkdGg6IG51bWJlciA9IE1hdGgucm91bmQoYWdHcmlkRWxlLmdldEJvdW5kaW5nQ2xpZW50UmVjdCgpLndpZHRoKTtcclxuICAgIC8vICAgICBsZXQgY29tcHV0ZWRTdHlsZTogQ1NTU3R5bGVEZWNsYXJhdGlvbiA9IHdpbmRvdy5nZXRDb21wdXRlZFN0eWxlKGFnR3JpZEVsZSk7XHJcbiAgICAvLyAgICAgbGV0IGJvcmRlckxlZnQ6IG51bWJlciA9IChjb21wdXRlZFN0eWxlLmJvcmRlckxlZnQgIT09ICcnKSA/IHBhcnNlSW50KGNvbXB1dGVkU3R5bGUuYm9yZGVyTGVmdCkgOiAwO1xyXG4gICAgLy8gICAgIGxldCBib3JkZXJSaWdodDogbnVtYmVyID0gKGNvbXB1dGVkU3R5bGUuYm9yZGVyUmlnaHQgIT09ICcnKSA/IHBhcnNlSW50KGNvbXB1dGVkU3R5bGUuYm9yZGVyUmlnaHQpIDogMDtcclxuICAgIC8vICAgICBsZXQgYm9yZGVyTGVmdFJpZ2h0ID0gYm9yZGVyTGVmdCArIGJvcmRlclJpZ2h0XHJcbiAgICAvLyAgICAgcmV0dXJuIHBhcmVudFdpZHRoIC0gYm9yZGVyTGVmdFJpZ2h0O1xyXG4gICAgLy8gfVxyXG5cclxuICAgIGNoZWNrU2VsZWN0aW9uKHRvcE9wdGlvbnM6IEdyaWRPcHRpb25zLCBib3R0b21PcHRpb25zOiBHcmlkT3B0aW9ucyk6IGFueSB7XHJcbiAgICAgICAgbGV0IHVwZGF0ZURpc2FibGVkOiBhbnkgPSB7IHRvcDogdHJ1ZSwgYm90dG9tOiB0cnVlIH07XHJcblxyXG4gICAgICAgIHVwZGF0ZURpc2FibGVkLnRvcCA9ICh0b3BPcHRpb25zLmFwaS5nZXRTZWxlY3RlZE5vZGVzKCkubGVuZ3RoID4gMCkgPyBmYWxzZSA6IHRydWU7XHJcbiAgICAgICAgdXBkYXRlRGlzYWJsZWQuYm90dG9tID0gKGJvdHRvbU9wdGlvbnMuYXBpLmdldFNlbGVjdGVkTm9kZXMoKS5sZW5ndGggPiAwKSA/IGZhbHNlIDogdHJ1ZTtcclxuXHJcbiAgICAgICAgcmV0dXJuIHVwZGF0ZURpc2FibGVkO1xyXG4gICAgfVxyXG5cclxuICAgIGNoZWNrT3ZlcmxheSh0b3BPcHRpb25zOiBHcmlkT3B0aW9ucywgYm90dG9tT3B0aW9uczogR3JpZE9wdGlvbnMpOiB2b2lkIHtcclxuICAgICAgICBsZXQgdG9wT3ZlcmxheTogYm9vbGVhbiA9ICh0b3BPcHRpb25zLmFwaS5nZXRNb2RlbCgpLmdldFJvd0NvdW50KCkgPiAwKSA/IGZhbHNlIDogdHJ1ZTtcclxuICAgICAgICBsZXQgYm90dG9tT3ZlcmxheTogYm9vbGVhbiA9IChib3R0b21PcHRpb25zLmFwaS5nZXRNb2RlbCgpLmdldFJvd0NvdW50KCkgPiAwKSA/IGZhbHNlIDogdHJ1ZTtcclxuXHJcbiAgICAgICAgaWYgKHRvcE92ZXJsYXkpIHRvcE9wdGlvbnMuYXBpLnNob3dOb1Jvd3NPdmVybGF5KCk7XHJcbiAgICAgICAgZWxzZSB0b3BPcHRpb25zLmFwaS5oaWRlT3ZlcmxheSgpO1xyXG4gICAgICAgIGlmIChib3R0b21PdmVybGF5KSBib3R0b21PcHRpb25zLmFwaS5zaG93Tm9Sb3dzT3ZlcmxheSgpO1xyXG4gICAgICAgIGVsc2UgYm90dG9tT3B0aW9ucy5hcGkuaGlkZU92ZXJsYXkoKTtcclxuICAgIH1cclxuXHJcbiAgICAvLyBzZXRSdGxWaWV3KF9ncmlkT3B0aW9uczogR3JpZE9wdGlvbnMpOiB2b2lkIHtcclxuICAgIC8vICAgICBsZXQgY29sRGVmTGVuZ3RoOiBudW1iZXIgPSBfZ3JpZE9wdGlvbnMuY29sdW1uRGVmcy5sZW5ndGg7XHJcbiAgICAvLyAgICAgZm9yIChsZXQgaTogbnVtYmVyID0gMDsgaSA8IGNvbERlZkxlbmd0aDsgaSsrKSB7XHJcbiAgICAvLyAgICAgICAgIF9ncmlkT3B0aW9ucy5jb2x1bW5BcGkubW92ZUNvbHVtbigwLCBjb2xEZWZMZW5ndGggLSAoaSArIDEpKTtcclxuICAgIC8vICAgICB9XHJcbiAgICAvLyAgICAgLy8gX2dyaWRPcHRpb25zLmFwaS5zZXRDb2x1bW5EZWZzKF9ncmlkT3B0aW9ucy5jb2x1bW5EZWZzKTtcclxuICAgIC8vICAgICBfZ3JpZE9wdGlvbnMuYXBpLnJlZnJlc2hWaWV3KCk7XHJcbiAgICAvLyB9XHJcblxyXG4gICAgc2V0Q2hlY2tib3hGYWxzZUFmdGVyVXBkYXRlKHZjcjogVmlld0NvbnRhaW5lclJlZik6IHZvaWQge1xyXG4gICAgICAgIGxldCBzZWxlY3RBbGxDaGVja2JveDogQXJyYXk8YW55PiA9IHZjci5lbGVtZW50Lm5hdGl2ZUVsZW1lbnQucXVlcnlTZWxlY3RvckFsbCgnLnNlbGVjdGlvbi13cmFwcGVyIGlucHV0LnNlbGVjdC1hbGwnKTtcclxuICAgICAgICBmb3IgKGxldCBpOiBudW1iZXIgPSAwOyBpIDwgc2VsZWN0QWxsQ2hlY2tib3gubGVuZ3RoOyBpKyspIHtcclxuICAgICAgICAgICAgc2VsZWN0QWxsQ2hlY2tib3hbaV0uY2hlY2tlZCA9IGZhbHNlO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICBzZXRDaGVja2JveEZhbHNlKHJlbW92ZWRFbGVtZW50OiBBcnJheTxIVE1MSW5wdXRFbGVtZW50Pik6IHZvaWQge1xyXG4gICAgICAgIGZvciAobGV0IGk6IG51bWJlciA9IDA7IGkgPCByZW1vdmVkRWxlbWVudC5sZW5ndGg7IGkrKykge1xyXG4gICAgICAgICAgICByZW1vdmVkRWxlbWVudFtpXS5jaGVja2VkID0gZmFsc2U7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX2dldEdyaWRIZWlnaHQoZGF0YUNvdW50OiBudW1iZXIsIGdyaWQ6IHN0cmluZyk6IG51bWJlciB7XHJcbiAgICAgICAgbGV0IGZsb2F0aW5nSGVpZ2h0ID0gMzg7XHJcbiAgICAgICAgbGV0IGhlYWRlckhlaWdodCA9IChncmlkID09PSAndG9wJykgPyAzOCA6IDA7XHJcbiAgICAgICAgbGV0IGRhdGFIZWlnaHQgPSAzOCAqIGRhdGFDb3VudDtcclxuXHJcbiAgICAgICAgcmV0dXJuIChmbG9hdGluZ0hlaWdodCArIGhlYWRlckhlaWdodCArIGRhdGFIZWlnaHQgKyA4KTtcclxuXHJcbiAgICAgICAgLyogICBoZWlnaHQgY2FsY3VsYXRpb24gYmFzZWQgb24gdmNyXHJcbiAgICAgICAgICAgIGxldCB0b3RhbEhlaWdodDogbnVtYmVyID0gMDtcclxuICAgICAgICAgICAgbGV0IHF1ZXJ5RWxlU3RyaW5nOiBzdHJpbmcgPSAnIycgKyBncmlkO1xyXG4gICAgICAgICAgICBsZXQgbmF0aXZlRWxlOiBFbGVtZW50ID0gdmNyLmVsZW1lbnQubmF0aXZlRWxlbWVudC5xdWVyeVNlbGVjdG9yKHF1ZXJ5RWxlU3RyaW5nKTtcclxuICAgICAgICAgICAgY29uc29sZS5sb2cobmF0aXZlRWxlKTtcclxuICAgICAgICAgICAgdG90YWxIZWlnaHQgKz0gTWF0aC5jZWlsKG5hdGl2ZUVsZS5xdWVyeVNlbGVjdG9yKCcuYWctaGVhZGVyLWNvbnRhaW5lcicpLmdldEJvdW5kaW5nQ2xpZW50UmVjdCgpLmhlaWdodCk7XHJcbiAgICAgICAgICAgIHRvdGFsSGVpZ2h0ICs9IE1hdGguY2VpbChuYXRpdmVFbGUucXVlcnlTZWxlY3RvcignLmFnLWJvZHktY29udGFpbmVyJykuZ2V0Qm91bmRpbmdDbGllbnRSZWN0KCkuaGVpZ2h0KTtcclxuICAgICAgICAgICAgdG90YWxIZWlnaHQgKz0gTWF0aC5jZWlsKG5hdGl2ZUVsZS5xdWVyeVNlbGVjdG9yKCcuYWctZmxvYXRpbmctdG9wLWZ1bGwtd2lkdGgtY29udGFpbmVyJykuZ2V0Qm91bmRpbmdDbGllbnRSZWN0KCkuaGVpZ2h0KTtcclxuICAgICAgICAgICAgbGV0IHBhZ2luYXRpb25Cb3R0b206IEVsZW1lbnQgPSBuYXRpdmVFbGUucXVlcnlTZWxlY3RvcignI3NvdXRoJylcclxuICAgICAgICAgICAgaWYocGFnaW5hdGlvbkJvdHRvbSAhPT0gbnVsbCkge1xyXG4gICAgICAgICAgICAgICAgdG90YWxIZWlnaHQgKz0gTWF0aC5jZWlsKHBhZ2luYXRpb25Cb3R0b20uZ2V0Qm91bmRpbmdDbGllbnRSZWN0KCkuaGVpZ2h0KTtcclxuICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgdG90YWxIZWlnaHQgKz0gODtcclxuICAgICAgICAgICAgcmV0dXJuIHRvdGFsSGVpZ2h0O1xyXG4gICAgICAgICAgICAqL1xyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX2dldEdyaWRPcHRpb25zKGdyaWQ6IHN0cmluZywgcm93RGF0YTogQXJyYXk8YW55Pik6IGFueSB7XHJcbiAgICAgICAgbGV0IG9wdGlvbnM6IGFueSA9IHtcclxuICAgICAgICAgICAgLy8gcm93RGF0YTogW10sXHJcbiAgICAgICAgICAgIHJvd0RhdGE6IHJvd0RhdGEsXHJcbiAgICAgICAgICAgIGNvbHVtbkRlZnM6IFtdLFxyXG4gICAgICAgICAgICAvLyBkZWJ1ZzogdHJ1ZSxcclxuXHJcbiAgICAgICAgICAgIGhlYWRlckhlaWdodDogKGdyaWQgPT09ICdzbGF2ZScpID8gMCA6IDM4LFxyXG4gICAgICAgICAgICByb3dIZWlnaHQ6IDM4LFxyXG5cclxuICAgICAgICAgICAgc3VwcHJlc3NDb250ZXh0TWVudTogdHJ1ZSxcclxuICAgICAgICAgICAgLy8gc3VwcHJlc3NNZW51TWFpblBhbmVsOiB0cnVlLFxyXG4gICAgICAgICAgICAvLyBzdXBwcmVzc01lbnVDb2x1bW5QYW5lbDogdHJ1ZSxcclxuICAgICAgICAgICAgLy8gc3VwcHJlc3NNZW51RmlsdGVyUGFuZWw6IHRydWUsXHJcbiAgICAgICAgICAgIHN1cHByZXNzTW92YWJsZUNvbHVtbnM6IHRydWUsXHJcbiAgICAgICAgICAgIHN1cHByZXNzTWVudUhpZGU6IHRydWUsXHJcbiAgICAgICAgICAgIHN1cHByZXNzQ29sdW1uVmlydHVhbGlzYXRpb246IHRydWUsXHJcbiAgICAgICAgICAgIGVuYWJsZUZpbHRlcjogdHJ1ZSxcclxuICAgICAgICAgICAgZW5hYmxlU29ydGluZzogdHJ1ZSxcclxuICAgICAgICAgICAgZW5hYmxlQ29sUmVzaXplOiBmYWxzZSxcclxuXHJcbiAgICAgICAgICAgIHVuU29ydEljb246IHRydWUsXHJcbiAgICAgICAgICAgIGljb25zOiB7XHJcbiAgICAgICAgICAgICAgICAvLyB1c2UgZm9udCBhd2Vzb21lIGZvciBtZW51IGljb25zXHJcbiAgICAgICAgICAgICAgICAvLyBtZW51OiAnPGkgY2xhc3M9J2ZhIGZhLWJhcnMnLz4nLFxyXG4gICAgICAgICAgICAgICAgZmlsdGVyOiAnPGkgY2xhc3M9XCJmYSBmYS1maWx0ZXJcIi8+JyxcclxuICAgICAgICAgICAgICAgIHNvcnRBc2NlbmRpbmc6ICc8aSBjbGFzcz1cImZhIGZhLWNhcmV0LWRvd25cIi8+JyxcclxuICAgICAgICAgICAgICAgIHNvcnREZXNjZW5kaW5nOiAnPGkgY2xhc3M9XCJmYSBmYS1jYXJldC11cFwiLz4nLFxyXG4gICAgICAgICAgICAgICAgc29ydFVuU29ydDogJzxpIGNsYXNzPVwiZmEgZmEtc29ydFwiLz4nLFxyXG4gICAgICAgICAgICAgICAgZ3JvdXBFeHBhbmRlZDogJzxpIGNsYXNzPVwiZmEgZmEtbWludXMtY2lyY2xlXCIvPicsXHJcbiAgICAgICAgICAgICAgICBncm91cENvbnRyYWN0ZWQ6ICc8aSBjbGFzcz1cImZhIGZhLXBsdXMtY2lyY2xlXCIvPidcclxuICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgLy8gb25HcmlkU2l6ZUNoYW5nZWQ6IGZ1bmN0aW9uKGUpIHtcclxuICAgICAgICAgICAgLy8gICAgIHRoaXMuYXBpLnNpemVDb2x1bW5zVG9GaXQoKTtcclxuICAgICAgICAgICAgLy8gfSxcclxuICAgICAgICAgICAgZ2V0Um93Q2xhc3M6IGZ1bmN0aW9uKHBhcmFtczogUm93Tm9kZSk6IGFueSB7XHJcbiAgICAgICAgICAgICAgICBpZiAocGFyYW1zLmRhdGEuaGFzT3duUHJvcGVydHkoJ25ld1JvdycpKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgZGVsZXRlIHBhcmFtcy5kYXRhLm5ld1JvdztcclxuICAgICAgICAgICAgICAgICAgICByZXR1cm4gJ25ldy1yb3ctaGlnaGxpZ2h0JztcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIHJldHVybjtcclxuICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgYWxpZ25lZEdyaWRzOiBbXSxcclxuICAgICAgICAgICAgb3ZlcmxheU5vUm93c1RlbXBsYXRlOiAnPHNwYW4gY2xhc3M9XCJhZy1jdXN0b20tb3ZlcmxheVwiPjxpIGNsYXNzPVwiZmEgZmEtaW5mby1jaXJjbGUgZmEtbGcgbWFyZ2luLXJpZ2h0MTBcIj48L2k+Tm8gc3R1ZGVudCByZWNvcmQgZm91bmQ8L3NwYW4+J1xyXG4gICAgICAgIH07XHJcblxyXG5cclxuICAgICAgICByZXR1cm4gb3B0aW9ucztcclxuICAgIH1cclxufVxyXG4iXX0=