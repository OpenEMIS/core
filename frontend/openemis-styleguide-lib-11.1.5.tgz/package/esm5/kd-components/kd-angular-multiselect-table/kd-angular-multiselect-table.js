import { __decorate, __metadata } from "tslib";
import { Component, OnInit, AfterViewInit, OnDestroy, Input, Output, EventEmitter, ViewEncapsulation, ViewContainerRef, HostListener, SimpleChanges, Renderer2 } from '@angular/core';
import { timer } from 'rxjs';
import 'ag-grid-enterprise';
import { KdDomElemSvc, AG_GRID_KEY } from '../kd-common/index';
import { KdSplitterEvent } from '../kd-angular-splitter/index';
import { KdMultiSelectTableSvc } from './kd-multiselect-table-svc';
import { KdAggridSvc } from '../kd-angular-aggrid/src/kd-angular-aggrid-svc';
import { LicenseManager } from "ag-grid-enterprise";
var KdMultiSelectTable = /** @class */ (function () {
    function KdMultiSelectTable(_multiTableSvc, _domSvc, _vcr, _renderer, _splitterEvent, _aggridSvc) {
        this._multiTableSvc = _multiTableSvc;
        this._domSvc = _domSvc;
        this._vcr = _vcr;
        this._renderer = _renderer;
        this._splitterEvent = _splitterEvent;
        this._aggridSvc = _aggridSvc;
        this._masterSearch = '';
        this._slaveSearch = '';
        this._disableButton = {};
        this._placeholder = {};
        this._buttons = {};
        this.enterprise = require('ag-grid-enterprise');
        this._masterSelectAll = false;
        this._slaveSelectAll = false;
        this._colDefArrayWidth = [];
        this._firstRun = true;
        this._masterData = [];
        this._slaveData = [];
        this.topBottomData = new EventEmitter();
        LicenseManager.setLicenseKey(AG_GRID_KEY.value);
    }
    KdMultiSelectTable.prototype.onResize = function (e) {
        this._setView();
    };
    KdMultiSelectTable.prototype.ngOnInit = function () {
        var _this = this;
        this._direction = (this._domSvc.getDocumentDirection(true));
        this._masterData = (typeof this.masterData !== 'undefined') ? this.masterData.slice() : [];
        this._slaveData = (typeof this.slaveData !== 'undefined') ? this.slaveData.slice() : [];
        this._setGridOptions();
        this._splitterClickSub = this._splitterEvent.onToggleMenu().subscribe(function () {
            timer(700).subscribe(function () {
                _this._setView();
            });
        });
        this._splitterDragSub = this._splitterEvent.onDrag().subscribe(function () {
            timer(200).subscribe(function () {
                _this._setView();
            });
        });
        var currentSelection = {};
        this._masterGridOptions.enableRtl = this._direction === 'right';
        this._slaveGridOptions.enableRtl = this._direction === 'right';
        currentSelection.topGrid = this._masterGridOptions.rowData;
        currentSelection.bottomGrid = this._slaveGridOptions.rowData;
        timer().subscribe(function () {
            _this.topBottomData.emit(currentSelection);
        });
    };
    KdMultiSelectTable.prototype.ngOnChanges = function (_simpleChange) {
        if (!this._firstRun) {
            if (_simpleChange.hasOwnProperty('masterData')) {
                this._masterGridOptions.rowData = _simpleChange['masterData'].currentValue;
                this._masterGridOptions.api.setRowData(_simpleChange['masterData'].currentValue);
                this._emitData();
            }
            if (_simpleChange.hasOwnProperty('slaveData')) {
                this._slaveGridOptions.rowData = _simpleChange['slaveData'].currentValue;
                this._slaveGridOptions.api.setRowData(_simpleChange['slaveData'].currentValue);
                this._emitData();
            }
        }
    };
    KdMultiSelectTable.prototype.ngAfterViewInit = function () {
        var _this = this;
        if (this._masterGridOptions.rowData.length === 0) {
            this._masterGridOptions.api.showNoRowsOverlay();
        }
        if (this._slaveGridOptions.rowData.length === 0) {
            this._slaveGridOptions.api.showNoRowsOverlay();
        }
        this._updateNoDataClass();
        this._masterGridOptions.columnApi.autoSizeAllColumns();
        this._colDefArrayWidth = this._aggridSvc.calcColWidth(this._masterGridOptions);
        timer(300).subscribe(function () {
            _this._setView();
        });
        this._firstRun = false;
    };
    KdMultiSelectTable.prototype.ngOnDestroy = function () {
        this._splitterDragSub.unsubscribe();
        this._splitterClickSub.unsubscribe();
    };
    KdMultiSelectTable.prototype.assign = function (_target) {
        if (_target === 'toTop') {
            this._updateRowData(this._slaveGridOptions, this._masterGridOptions);
        }
        else {
            this._updateRowData(this._masterGridOptions, this._slaveGridOptions);
        }
        if (this._domSvc.isMobile()) {
            this._setHeight(true);
        }
    };
    KdMultiSelectTable.prototype.resetSearch = function (_e, _grid) {
        _e.stopPropagation();
        var isMobile = this._domSvc.isMobile();
        var search = (_grid === 'top') ? this._masterSearch : this._slaveSearch;
        if (isMobile && search.length === 0) {
            this._searchState(_grid, 'collapse');
        }
        else {
            if (_grid === 'top') {
                this._masterSearch = '';
            }
            else {
                this._slaveSearch = '';
            }
        }
        this.filterChanged(_grid);
    };
    KdMultiSelectTable.prototype.filterChanged = function (_grid) {
        var isMobile = this._domSvc.isMobile();
        var gridFilterOptions;
        var search = '';
        if (_grid === 'top') {
            gridFilterOptions = this._masterGridOptions;
            search = this._masterSearch;
        }
        else {
            gridFilterOptions = this._slaveGridOptions;
            search = this._slaveSearch;
        }
        gridFilterOptions.api.setQuickFilter(search);
        if (isMobile) {
            this._setHeight(isMobile);
        }
        this._multiTableSvc.checkOverlay(this._masterGridOptions, this._slaveGridOptions);
    };
    KdMultiSelectTable.prototype.sortGrid = function () {
        var sortModel = this._masterGridOptions.api.getSortModel();
        this._slaveGridOptions.api.setSortModel(sortModel);
    };
    KdMultiSelectTable.prototype._setView = function () {
        var isMobile = this._domSvc.isMobile();
        this._setSearchState(isMobile);
        this._setColWidth();
        this._setHeight(isMobile);
        this._setClickSearch(isMobile);
    };
    KdMultiSelectTable.prototype._setSearchState = function (_isMobile) {
        if (_isMobile) {
            var search = [];
            search.push(this._vcr.element.nativeElement.querySelector('.search-table-top'));
            search.push(this._vcr.element.nativeElement.querySelector('.search-table-bottom'));
            for (var i = 0; i < search.length; i++) {
                var isCurrentStateExist = search[i].classList.contains('collapse-search') || search[i].classList.contains('expand-search');
                if (!isCurrentStateExist) {
                    var grid = void 0;
                    var searchString = void 0;
                    if (i === 0) {
                        grid = 'top';
                        searchString = this._masterSearch;
                    }
                    else {
                        grid = 'bottom';
                        searchString = this._slaveSearch;
                    }
                    if (searchString === '') {
                        this._searchState(grid, 'collapse');
                    }
                    else {
                        this._searchState(grid, 'expand');
                    }
                }
            }
        }
        else {
            this._searchState('top', 'reset');
            this._searchState('bottom', 'reset');
        }
    };
    KdMultiSelectTable.prototype._updateNoDataClass = function () {
        this._setNoData('top');
        this._setNoData('bottom');
    };
    KdMultiSelectTable.prototype._setNoData = function (_grid) {
        var queryString = '.search-table-' + _grid + ' input.search-' + _grid;
        var checkGrid = (_grid === 'top') ? this._masterGridOptions : this._slaveGridOptions;
        var inputEle = this._vcr.element.nativeElement.querySelector(queryString);
        if (checkGrid.rowData.length === 0) {
            this._domSvc.addClass(inputEle, 'no-data');
        }
        else {
            this._domSvc.removeClass(inputEle, 'no-data');
        }
    };
    KdMultiSelectTable.prototype._setColWidth = function () {
        var usableWidth = this._aggridSvc.calcUsableWidth(this._vcr);
        if (this._masterGridOptions.columnApi !== null) {
            var totalWidth = this._aggridSvc.colTotalWidth(this._colDefArrayWidth, this._masterGridOptions.columnApi.getAllColumns());
            if (this._masterGridOptions.columnApi !== null) {
                var colDef = this._masterGridOptions.columnApi.getAllColumns();
                var extraPerCol = 0;
                if (totalWidth < usableWidth) {
                    var leftoverWidth = usableWidth - totalWidth;
                    extraPerCol = leftoverWidth / (this._colDefArrayWidth.length - 1);
                }
                for (var i = 0; i < this._colDefArrayWidth.length; i++) {
                    var width = (colDef[i].getColId() === 'checkbox') ? this._colDefArrayWidth[i].width : this._colDefArrayWidth[i].width + extraPerCol;
                    this._masterGridOptions.columnApi.setColumnWidth(colDef[i], width);
                }
            }
        }
    };
    KdMultiSelectTable.prototype._setClickSearch = function (_isMobile) {
        var _this = this;
        var tableTop = this._vcr.element.nativeElement.querySelector('.search-table-top');
        var tableBottom = this._vcr.element.nativeElement.querySelector('.search-table-bottom');
        if (_isMobile) {
            this._renderer.listen(tableTop, 'click', function (_e) {
                if (tableTop.classList.contains('collapse-search')) {
                    _this._searchState('top', 'expand');
                }
            });
            this._renderer.listen(tableBottom, 'click', function (_e) {
                if (tableBottom.classList.contains('collapse-search')) {
                    _this._searchState('bottom', 'expand');
                }
            });
        }
    };
    KdMultiSelectTable.prototype._setGridOptions = function () {
        var settings = this._multiTableSvc.getBothOptions(this.config, this._masterData, this._slaveData);
        this._primaryKey = this._multiTableSvc.getPrimarykey(this.config);
        this._masterGridOptions = settings.masterGridOption;
        this._slaveGridOptions = settings.slaveGridOption;
        this._masterGridOptions.alignedGrids = [this._slaveGridOptions];
        this._slaveGridOptions.alignedGrids = [this._masterGridOptions];
        this._disableButton.top = true;
        this._disableButton.bottom = true;
        this._placeholder.top = this._multiTableSvc.getPlaceholder(this.config, 'top');
        this._placeholder.bottom = this._multiTableSvc.getPlaceholder(this.config, 'bottom');
        this._buttons.toTop = this._multiTableSvc.getButton(this.config, 'toTopBtn');
        this._buttons.toBottom = this._multiTableSvc.getButton(this.config, 'toBottomBtn');
        this._setColDefFloating('master');
        this._setColDefFloating('slave');
    };
    KdMultiSelectTable.prototype._setColDefFloating = function (_grid) {
        var newKdAgGridSvc = new KdAggridSvc();
        this._setFloatingTop(_grid);
        var genericGrid = (_grid === 'master') ? this._masterGridOptions : this._slaveGridOptions;
        var colDef = newKdAgGridSvc.setColDefs(this.config.colDef, genericGrid);
        colDef.updatedColDef.unshift(this._setCheckbox(_grid));
        genericGrid.columnDefs = colDef.updatedColDef;
    };
    KdMultiSelectTable.prototype._updateRowData = function (_fromGrid, _toGrid) {
        var _this = this;
        var selectedNodes = _fromGrid.api.getSelectedNodes();
        var offset = 0;
        for (var i = 0; i < selectedNodes.length; i++) {
            selectedNodes[i].data.newRow = true;
            _toGrid.rowData.push(selectedNodes[i].data);
            _fromGrid.rowData.splice(parseInt(selectedNodes[i].id) - offset, 1);
            offset++;
        }
        _toGrid.api.setRowData(_toGrid.rowData);
        _fromGrid.api.setRowData(_fromGrid.rowData);
        var newRow = -1;
        _toGrid.api.forEachNodeAfterFilter(function (_node) {
            if (selectedNodes[0].data[_this._primaryKey] === _node.data[_this._primaryKey]) {
                newRow = _node.childIndex;
            }
        });
        _toGrid.api.ensureIndexVisible(newRow);
        this._disableButton = this._multiTableSvc.checkSelection(this._masterGridOptions, this._slaveGridOptions);
        this._updateNoDataClass();
        this._setCheckboxAfterUpdate();
        this._emitData();
    };
    KdMultiSelectTable.prototype._setCheckboxAfterUpdate = function () {
        this._masterSelectAll = false;
        this._slaveSelectAll = false;
        this._multiTableSvc.setCheckboxFalseAfterUpdate(this._vcr);
    };
    KdMultiSelectTable.prototype._emitData = function () {
        var currentSelection = {};
        currentSelection.topGrid = this._masterGridOptions.rowData;
        currentSelection.bottomGrid = this._slaveGridOptions.rowData;
        this.topBottomData.emit(currentSelection);
    };
    // private _getRowData(): void {
    // }
    KdMultiSelectTable.prototype._setFloatingTop = function (_grid) {
        var _this = this;
        var gridOptions;
        var selectAllCheck;
        if (_grid === 'master') {
            gridOptions = this._masterGridOptions;
            selectAllCheck = this._masterSelectAll;
        }
        else {
            gridOptions = this._slaveGridOptions;
            selectAllCheck = this._slaveSelectAll;
        }
        gridOptions.pinnedTopRowData = [{ fullWidth: true }];
        gridOptions.isFullWidthCell = function (_rowNode) {
            if (typeof _rowNode.data.fullWidth !== 'undefined') {
                return _rowNode.data.fullWidth;
            }
            return false;
        };
        gridOptions.fullWidthCellRenderer = function (params) {
            var parentWrapper = document.createElement('div');
            var checkboxWrapper = _this._domSvc.createElement(parentWrapper, 'selection-wrapper select-all', 'div');
            var checkbox = _this._domSvc.createElement(checkboxWrapper, 'select-all', 'input');
            checkbox.type = 'checkbox';
            _this._domSvc.createElement(checkboxWrapper, 'label', 'label');
            checkboxWrapper.addEventListener('change', function () {
                var isChecked = checkbox.checked;
                _this._checkSelectAllBox(params, _grid, isChecked);
            });
            if (selectAllCheck) {
                checkbox.checked = true;
            }
            var displayData = _this._domSvc.createElement(parentWrapper, 'checkbox-text', 'div');
            var pTag = _this._domSvc.createElement(displayData, 'check-data', 'div');
            var data = gridOptions.api.getModel().getRowCount();
            pTag.innerHTML = 'Select all ' + data + ' results';
            return parentWrapper;
        };
    };
    KdMultiSelectTable.prototype._setHeight = function (_isMobile) {
        var height;
        if (_isMobile) {
            height = this._multiTableSvc.calcMobileHeight(this._masterGridOptions, this._slaveGridOptions, this._vcr);
        }
        else {
            height = this._multiTableSvc.calcWebHeight(this.config.height);
        }
        this._setGridHeight('master', height);
        this._setGridHeight('slave', height);
    };
    KdMultiSelectTable.prototype._setGridHeight = function (_grid, _height) {
        var queryString = '.stg-theme.' + _grid;
        var gridHeight;
        var htmlEle = this._vcr.element.nativeElement.querySelector(queryString);
        if (_grid === 'master') {
            gridHeight = _height.top + 'px';
        }
        else {
            gridHeight = _height.bottom + 'px';
        }
        this._domSvc.setElementStyle(htmlEle, 'height', gridHeight);
    };
    KdMultiSelectTable.prototype._setCheckbox = function (_grid) {
        var _this = this;
        var checkboxSetting = this._multiTableSvc.getCheckboxDefault();
        checkboxSetting.pinned = this._direction;
        checkboxSetting.cellClass = 'ag-checkbox-radio';
        checkboxSetting.cellRenderer = function (_params) { return _this._setCellRendering(_params, _grid); };
        return checkboxSetting;
    };
    KdMultiSelectTable.prototype._setCellRendering = function (params, grid) {
        var _this = this;
        var header = document.createElement('div');
        var input = this._domSvc.createElement(header, 'checkbox', 'input');
        this._domSvc.createElement(header, 'label', 'label');
        var gridOptions = (grid === 'master') ? this._masterGridOptions : this._slaveGridOptions;
        var currentNode = gridOptions.api.getModel().getRow(params.rowIndex);
        input.type = 'checkbox';
        header.className = 'selection-wrapper';
        header.addEventListener('change', function ($event) {
            currentNode.selectThisNode(input.checked);
            _this._checkSelectBox(params, grid);
        });
        if (currentNode.isSelected())
            input.checked = true;
        return header;
    };
    KdMultiSelectTable.prototype._checkSelectBox = function (params, grid) {
        var gridOptions = (grid === 'master') ? this._masterGridOptions : this._slaveGridOptions;
        var selectAll = (grid === 'master') ? this._masterSelectAll : this._slaveSelectAll;
        var queryString = '#' + grid + ' .select-all input';
        var rowModelCount = gridOptions.api.getModel().getRowCount();
        var selectedNodesCount = gridOptions.api.getSelectedNodes().length;
        selectAll = (rowModelCount === selectedNodesCount);
        if (grid === 'master')
            this._masterSelectAll = selectAll;
        else
            this._slaveSelectAll = selectAll;
        this._vcr.element.nativeElement.querySelector(queryString).checked = selectAll;
        this._updateSelection(grid);
        this._disableButton = this._multiTableSvc.checkSelection(this._masterGridOptions, this._slaveGridOptions);
    };
    KdMultiSelectTable.prototype._checkSelectAllBox = function (params, grid, isChecked) {
        var eleClass = '#' + grid + ((this._direction === 'left') ? ' .ag-pinned-left-cols-container' : ' .ag-pinned-right-cols-container');
        var bodyContainer = this._vcr.element.nativeElement.querySelector(eleClass);
        var inputEle = bodyContainer.querySelectorAll('.selection-wrapper input');
        var gridOptions = (grid === 'master') ? this._masterGridOptions : this._slaveGridOptions;
        var modelApi = gridOptions.api.getModel();
        if (grid === 'master')
            this._masterSelectAll = isChecked;
        else
            this._slaveSelectAll = isChecked;
        var selectAll = (grid === 'master') ? this._masterSelectAll : this._slaveSelectAll;
        for (var i = 0; i < modelApi.getRowCount(); i++) {
            modelApi.getRow(i).selectThisNode(selectAll);
            if (typeof inputEle[i] !== 'undefined')
                inputEle[i].checked = selectAll;
        }
        this._updateSelection(grid);
        this._disableButton = this._multiTableSvc.checkSelection(this._masterGridOptions, this._slaveGridOptions);
    };
    KdMultiSelectTable.prototype._updateSelection = function (checkedGrid) {
        var queryString = (checkedGrid === 'master') ? '#slave .selection-wrapper input' : '#master .selection-wrapper input';
        var allElement = this._vcr.element.nativeElement.querySelectorAll(queryString);
        this._multiTableSvc.setCheckboxFalse(allElement);
        if (checkedGrid === 'master') {
            this._slaveGridOptions.api.deselectAll();
            this._slaveSelectAll = false;
        }
        else {
            this._masterGridOptions.api.deselectAll();
            this._masterSelectAll = false;
        }
    };
    KdMultiSelectTable.prototype._searchState = function (grid, state) {
        var queryString = '.search-table-' + grid;
        var renderGrid = this._vcr.element.nativeElement.querySelector(queryString);
        if (state === 'collapse') {
            this._domSvc.addClass(renderGrid, 'collapse-search');
            this._domSvc.removeClass(renderGrid, 'expand-search');
        }
        else if (state === 'expand') {
            this._domSvc.addClass(renderGrid, 'expand-search');
            this._domSvc.removeClass(renderGrid, 'collapse-search');
        }
        // 'reset'
        else {
            this._domSvc.removeClass(renderGrid, 'expand-search');
            this._domSvc.removeClass(renderGrid, 'collapse-search');
        }
    };
    KdMultiSelectTable.ctorParameters = function () { return [
        { type: KdMultiSelectTableSvc },
        { type: KdDomElemSvc },
        { type: ViewContainerRef },
        { type: Renderer2 },
        { type: KdSplitterEvent },
        { type: KdAggridSvc }
    ]; };
    __decorate([
        Input(),
        __metadata("design:type", Object)
    ], KdMultiSelectTable.prototype, "config", void 0);
    __decorate([
        Input(),
        __metadata("design:type", Array)
    ], KdMultiSelectTable.prototype, "masterData", void 0);
    __decorate([
        Input(),
        __metadata("design:type", Array)
    ], KdMultiSelectTable.prototype, "slaveData", void 0);
    __decorate([
        Output(),
        __metadata("design:type", EventEmitter)
    ], KdMultiSelectTable.prototype, "topBottomData", void 0);
    __decorate([
        HostListener('window:resize', ['$event']),
        __metadata("design:type", Function),
        __metadata("design:paramtypes", [Event]),
        __metadata("design:returntype", void 0)
    ], KdMultiSelectTable.prototype, "onResize", null);
    KdMultiSelectTable = __decorate([
        Component({
            selector: 'kd-multiselect-table',
            template: "<div class='kdx-table-wrapper'>\r\n    <div class='kdx-table-top'>\r\n        <div class='kdx search-table-top'>\r\n            <i class='fa fa-search'></i>\r\n            <input [placeholder]='_placeholder.top' name='focus' class='search-top' type='text' [(ngModel)]=\"_masterSearch\" (ngModelChange)=\"filterChanged('top')\">\r\n            <button type='button' class='close-icon' (click)=\"resetSearch($event, 'top')\" [hidden]='!_masterSearch.length'></button>\r\n        </div>\r\n   \t\t<ag-grid-angular #agGridMaster id=\"master\" class=\"stg-theme master\"\r\n                [gridOptions]=\"_masterGridOptions\" \r\n                (sortChanged) = \"sortGrid()\"\r\n        >\r\n        </ag-grid-angular>\r\n    </div>\r\n    <div class='table-action-btn'>\r\n        <button class='btn btn-default' id='assignBtn' type=\"button\" [disabled]=\"_disableButton.top\" (click)=\"assign('toBottom')\">\r\n            <i [class]='_buttons.toBottom.icon'></i> {{_buttons.toBottom.text}}\r\n        </button>\r\n        <button class='btn btn-default' id='unassignBtn' type=\"button\" [disabled]=\"_disableButton.bottom\" (click)=\"assign('toTop')\">\r\n            <i [class]='_buttons.toTop.icon'></i> {{_buttons.toTop.text}}\r\n        </button>\r\n    </div>\r\n    <div class='kdx-table-bottom'>\r\n        <div class='kdx search-table-bottom'>\r\n            <i class='fa fa-search'></i>\r\n            <input [placeholder]='_placeholder.bottom' name='focus' class='search-bottom' type='text' [(ngModel)]=\"_slaveSearch\" (ngModelChange)=\"filterChanged('bottom')\">\r\n            <button type='button' class='close-icon' (click)=\"resetSearch($event, 'bottom')\" [hidden]=\"!_slaveSearch.length\"></button>\r\n        </div>\r\n       \t<ag-grid-angular #agGridSlave id=\"slave\" class=\"stg-theme slave\" \r\n       \t\t[gridOptions]=\"_slaveGridOptions\"\r\n       \t>\r\n        </ag-grid-angular>\r\n    </div>\r\n</div>",
            providers: [KdMultiSelectTableSvc, KdDomElemSvc, KdAggridSvc],
            encapsulation: ViewEncapsulation.None,
            host: { 'class': 'kdx-multiselect-table' }
        }),
        __metadata("design:paramtypes", [KdMultiSelectTableSvc,
            KdDomElemSvc,
            ViewContainerRef,
            Renderer2,
            KdSplitterEvent,
            KdAggridSvc])
    ], KdMultiSelectTable);
    return KdMultiSelectTable;
}());
export { KdMultiSelectTable };
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoia2QtYW5ndWxhci1tdWx0aXNlbGVjdC10YWJsZS5qcyIsInNvdXJjZVJvb3QiOiJuZzovL29wZW5lbWlzLXN0eWxlZ3VpZGUtbGliLyIsInNvdXJjZXMiOlsia2QtY29tcG9uZW50cy9rZC1hbmd1bGFyLW11bHRpc2VsZWN0LXRhYmxlL2tkLWFuZ3VsYXItbXVsdGlzZWxlY3QtdGFibGUudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IjtBQUFBLE9BQU8sRUFBRSxTQUFTLEVBQUUsTUFBTSxFQUFFLGFBQWEsRUFBRSxTQUFTLEVBQUUsS0FBSyxFQUFFLE1BQU0sRUFBRSxZQUFZLEVBQUUsaUJBQWlCLEVBQUUsZ0JBQWdCLEVBQUUsWUFBWSxFQUFFLGFBQWEsRUFBRSxTQUFTLEVBQUUsTUFBTSxlQUFlLENBQUM7QUFDdEwsT0FBTyxFQUFFLEtBQUssRUFBa0IsTUFBTSxNQUFNLENBQUM7QUFFN0MsT0FBTyxvQkFBb0IsQ0FBQztBQUM1QixPQUFPLEVBQUUsWUFBWSxFQUFFLFdBQVcsRUFBRSxNQUFNLG9CQUFvQixDQUFDO0FBQy9ELE9BQU8sRUFBRSxlQUFlLEVBQUUsTUFBTSw4QkFBOEIsQ0FBQztBQUMvRCxPQUFPLEVBQUUscUJBQXFCLEVBQUUsTUFBTSw0QkFBNEIsQ0FBQztBQUNuRSxPQUFPLEVBQUUsV0FBVyxFQUFFLE1BQU0sZ0RBQWdELENBQUM7QUFDN0UsT0FBTyxFQUFDLGNBQWMsRUFBQyxNQUFNLG9CQUFvQixDQUFDO0FBWWxEO0lBMEJJLDRCQUNZLGNBQXFDLEVBQ3JDLE9BQXFCLEVBQ3JCLElBQXNCLEVBQ3RCLFNBQW9CLEVBQ3BCLGNBQStCLEVBQy9CLFVBQXVCO1FBTHZCLG1CQUFjLEdBQWQsY0FBYyxDQUF1QjtRQUNyQyxZQUFPLEdBQVAsT0FBTyxDQUFjO1FBQ3JCLFNBQUksR0FBSixJQUFJLENBQWtCO1FBQ3RCLGNBQVMsR0FBVCxTQUFTLENBQVc7UUFDcEIsbUJBQWMsR0FBZCxjQUFjLENBQWlCO1FBQy9CLGVBQVUsR0FBVixVQUFVLENBQWE7UUEvQjVCLGtCQUFhLEdBQVcsRUFBRSxDQUFDO1FBQzNCLGlCQUFZLEdBQVcsRUFBRSxDQUFDO1FBRzFCLG1CQUFjLEdBQVEsRUFBRSxDQUFDO1FBQ3pCLGlCQUFZLEdBQVEsRUFBRSxDQUFDO1FBQ3ZCLGFBQVEsR0FBUSxFQUFFLENBQUM7UUFFbEIsZUFBVSxHQUFHLE9BQU8sQ0FBQyxvQkFBb0IsQ0FBQyxDQUFDO1FBQzNDLHFCQUFnQixHQUFZLEtBQUssQ0FBQztRQUNsQyxvQkFBZSxHQUFZLEtBQUssQ0FBQztRQUNqQyxzQkFBaUIsR0FBdUMsRUFBRSxDQUFDO1FBRzNELGNBQVMsR0FBWSxJQUFJLENBQUM7UUFDMUIsZ0JBQVcsR0FBZSxFQUFFLENBQUM7UUFDN0IsZUFBVSxHQUFlLEVBQUUsQ0FBQztRQU8xQixrQkFBYSxHQUFzQixJQUFJLFlBQVksRUFBRSxDQUFDO1FBVTVELGNBQWMsQ0FBQyxhQUFhLENBQUMsV0FBVyxDQUFDLEtBQUssQ0FBQyxDQUFDO0lBQ3BELENBQUM7SUFHRCxxQ0FBUSxHQUFSLFVBQVMsQ0FBUTtRQUNiLElBQUksQ0FBQyxRQUFRLEVBQUUsQ0FBQztJQUNwQixDQUFDO0lBRUQscUNBQVEsR0FBUjtRQUFBLGlCQTRCQztRQTNCRyxJQUFJLENBQUMsVUFBVSxHQUFHLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxvQkFBb0IsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDO1FBQzVELElBQUksQ0FBQyxXQUFXLEdBQUcsQ0FBQyxPQUFPLElBQUksQ0FBQyxVQUFVLEtBQUssV0FBVyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsS0FBSyxFQUFFLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQztRQUMzRixJQUFJLENBQUMsVUFBVSxHQUFHLENBQUMsT0FBTyxJQUFJLENBQUMsU0FBUyxLQUFLLFdBQVcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLEtBQUssRUFBRSxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUM7UUFDeEYsSUFBSSxDQUFDLGVBQWUsRUFBRSxDQUFDO1FBRXZCLElBQUksQ0FBQyxpQkFBaUIsR0FBRyxJQUFJLENBQUMsY0FBYyxDQUFDLFlBQVksRUFBRSxDQUFDLFNBQVMsQ0FBQztZQUNsRSxLQUFLLENBQUMsR0FBRyxDQUFDLENBQUMsU0FBUyxDQUFDO2dCQUNqQixLQUFJLENBQUMsUUFBUSxFQUFFLENBQUM7WUFDcEIsQ0FBQyxDQUFDLENBQUM7UUFDUCxDQUFDLENBQUMsQ0FBQztRQUVILElBQUksQ0FBQyxnQkFBZ0IsR0FBRyxJQUFJLENBQUMsY0FBYyxDQUFDLE1BQU0sRUFBRSxDQUFDLFNBQVMsQ0FBQztZQUMzRCxLQUFLLENBQUMsR0FBRyxDQUFDLENBQUMsU0FBUyxDQUFDO2dCQUNqQixLQUFJLENBQUMsUUFBUSxFQUFFLENBQUM7WUFDcEIsQ0FBQyxDQUFDLENBQUM7UUFDUCxDQUFDLENBQUMsQ0FBQztRQUVILElBQUksZ0JBQWdCLEdBQVEsRUFBRSxDQUFDO1FBRS9CLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxTQUFTLEdBQUcsSUFBSSxDQUFDLFVBQVUsS0FBSyxPQUFPLENBQUM7UUFDaEUsSUFBSSxDQUFDLGlCQUFpQixDQUFDLFNBQVMsR0FBRyxJQUFJLENBQUMsVUFBVSxLQUFLLE9BQU8sQ0FBQztRQUUvRCxnQkFBZ0IsQ0FBQyxPQUFPLEdBQUcsSUFBSSxDQUFDLGtCQUFrQixDQUFDLE9BQU8sQ0FBQztRQUMzRCxnQkFBZ0IsQ0FBQyxVQUFVLEdBQUcsSUFBSSxDQUFDLGlCQUFpQixDQUFDLE9BQU8sQ0FBQztRQUM3RCxLQUFLLEVBQUUsQ0FBQyxTQUFTLENBQUM7WUFDZCxLQUFJLENBQUMsYUFBYSxDQUFDLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDO1FBQzlDLENBQUMsQ0FBQyxDQUFDO0lBQ1AsQ0FBQztJQUVELHdDQUFXLEdBQVgsVUFBWSxhQUE0QjtRQUNwQyxJQUFJLENBQUMsSUFBSSxDQUFDLFNBQVMsRUFBRTtZQUNqQixJQUFJLGFBQWEsQ0FBQyxjQUFjLENBQUMsWUFBWSxDQUFDLEVBQUU7Z0JBQzVDLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxPQUFPLEdBQUcsYUFBYSxDQUFDLFlBQVksQ0FBQyxDQUFDLFlBQVksQ0FBQztnQkFDM0UsSUFBSSxDQUFDLGtCQUFrQixDQUFDLEdBQUcsQ0FBQyxVQUFVLENBQUMsYUFBYSxDQUFDLFlBQVksQ0FBQyxDQUFDLFlBQVksQ0FBQyxDQUFDO2dCQUNqRixJQUFJLENBQUMsU0FBUyxFQUFFLENBQUM7YUFDcEI7WUFDRCxJQUFJLGFBQWEsQ0FBQyxjQUFjLENBQUMsV0FBVyxDQUFDLEVBQUU7Z0JBQzNDLElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxPQUFPLEdBQUcsYUFBYSxDQUFDLFdBQVcsQ0FBQyxDQUFDLFlBQVksQ0FBQztnQkFDekUsSUFBSSxDQUFDLGlCQUFpQixDQUFDLEdBQUcsQ0FBQyxVQUFVLENBQUMsYUFBYSxDQUFDLFdBQVcsQ0FBQyxDQUFDLFlBQVksQ0FBQyxDQUFDO2dCQUMvRSxJQUFJLENBQUMsU0FBUyxFQUFFLENBQUM7YUFDcEI7U0FDSjtJQUNMLENBQUM7SUFFRCw0Q0FBZSxHQUFmO1FBQUEsaUJBa0JDO1FBakJHLElBQUksSUFBSSxDQUFDLGtCQUFrQixDQUFDLE9BQU8sQ0FBQyxNQUFNLEtBQUssQ0FBQyxFQUFFO1lBQzlDLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxHQUFHLENBQUMsaUJBQWlCLEVBQUUsQ0FBQztTQUNuRDtRQUVELElBQUksSUFBSSxDQUFDLGlCQUFpQixDQUFDLE9BQU8sQ0FBQyxNQUFNLEtBQUssQ0FBQyxFQUFFO1lBQzdDLElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxHQUFHLENBQUMsaUJBQWlCLEVBQUUsQ0FBQztTQUNsRDtRQUVELElBQUksQ0FBQyxrQkFBa0IsRUFBRSxDQUFDO1FBQzFCLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxTQUFTLENBQUMsa0JBQWtCLEVBQUUsQ0FBQztRQUN2RCxJQUFJLENBQUMsaUJBQWlCLEdBQUcsSUFBSSxDQUFDLFVBQVUsQ0FBQyxZQUFZLENBQUMsSUFBSSxDQUFDLGtCQUFrQixDQUFDLENBQUM7UUFFL0UsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDLFNBQVMsQ0FBQztZQUNqQixLQUFJLENBQUMsUUFBUSxFQUFFLENBQUM7UUFDcEIsQ0FBQyxDQUFDLENBQUM7UUFFSCxJQUFJLENBQUMsU0FBUyxHQUFHLEtBQUssQ0FBQztJQUMzQixDQUFDO0lBRUQsd0NBQVcsR0FBWDtRQUNJLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxXQUFXLEVBQUUsQ0FBQztRQUNwQyxJQUFJLENBQUMsaUJBQWlCLENBQUMsV0FBVyxFQUFFLENBQUM7SUFDekMsQ0FBQztJQUVELG1DQUFNLEdBQU4sVUFBTyxPQUFlO1FBQ2xCLElBQUksT0FBTyxLQUFLLE9BQU8sRUFBRTtZQUNyQixJQUFJLENBQUMsY0FBYyxDQUFDLElBQUksQ0FBQyxpQkFBaUIsRUFBRSxJQUFJLENBQUMsa0JBQWtCLENBQUMsQ0FBQztTQUN4RTthQUNJO1lBQ0QsSUFBSSxDQUFDLGNBQWMsQ0FBQyxJQUFJLENBQUMsa0JBQWtCLEVBQUUsSUFBSSxDQUFDLGlCQUFpQixDQUFDLENBQUM7U0FDeEU7UUFFRCxJQUFJLElBQUksQ0FBQyxPQUFPLENBQUMsUUFBUSxFQUFFLEVBQUU7WUFDekIsSUFBSSxDQUFDLFVBQVUsQ0FBQyxJQUFJLENBQUMsQ0FBQztTQUN6QjtJQUNMLENBQUM7SUFFRCx3Q0FBVyxHQUFYLFVBQVksRUFBUyxFQUFFLEtBQWE7UUFDaEMsRUFBRSxDQUFDLGVBQWUsRUFBRSxDQUFDO1FBRXJCLElBQUksUUFBUSxHQUFZLElBQUksQ0FBQyxPQUFPLENBQUMsUUFBUSxFQUFFLENBQUM7UUFDaEQsSUFBSSxNQUFNLEdBQVcsQ0FBQyxLQUFLLEtBQUssS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxhQUFhLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxZQUFZLENBQUM7UUFFaEYsSUFBSSxRQUFRLElBQUksTUFBTSxDQUFDLE1BQU0sS0FBSyxDQUFDLEVBQUU7WUFDakMsSUFBSSxDQUFDLFlBQVksQ0FBQyxLQUFLLEVBQUUsVUFBVSxDQUFDLENBQUM7U0FDeEM7YUFDSTtZQUNELElBQUksS0FBSyxLQUFLLEtBQUssRUFBRTtnQkFDakIsSUFBSSxDQUFDLGFBQWEsR0FBRyxFQUFFLENBQUM7YUFDM0I7aUJBQ0k7Z0JBQ0QsSUFBSSxDQUFDLFlBQVksR0FBRyxFQUFFLENBQUM7YUFDMUI7U0FDSjtRQUVELElBQUksQ0FBQyxhQUFhLENBQUMsS0FBSyxDQUFDLENBQUM7SUFDOUIsQ0FBQztJQUVELDBDQUFhLEdBQWIsVUFBYyxLQUFhO1FBQ3ZCLElBQUksUUFBUSxHQUFZLElBQUksQ0FBQyxPQUFPLENBQUMsUUFBUSxFQUFFLENBQUM7UUFDaEQsSUFBSSxpQkFBOEIsQ0FBQztRQUNuQyxJQUFJLE1BQU0sR0FBVyxFQUFFLENBQUM7UUFFeEIsSUFBSSxLQUFLLEtBQUssS0FBSyxFQUFFO1lBQ2pCLGlCQUFpQixHQUFHLElBQUksQ0FBQyxrQkFBa0IsQ0FBQztZQUM1QyxNQUFNLEdBQUcsSUFBSSxDQUFDLGFBQWEsQ0FBQztTQUMvQjthQUNJO1lBQ0QsaUJBQWlCLEdBQUcsSUFBSSxDQUFDLGlCQUFpQixDQUFDO1lBQzNDLE1BQU0sR0FBRyxJQUFJLENBQUMsWUFBWSxDQUFDO1NBQzlCO1FBRUQsaUJBQWlCLENBQUMsR0FBRyxDQUFDLGNBQWMsQ0FBQyxNQUFNLENBQUMsQ0FBQztRQUU3QyxJQUFJLFFBQVEsRUFBRTtZQUNWLElBQUksQ0FBQyxVQUFVLENBQUMsUUFBUSxDQUFDLENBQUM7U0FDN0I7UUFFRCxJQUFJLENBQUMsY0FBYyxDQUFDLFlBQVksQ0FBQyxJQUFJLENBQUMsa0JBQWtCLEVBQUUsSUFBSSxDQUFDLGlCQUFpQixDQUFDLENBQUM7SUFDdEYsQ0FBQztJQUVELHFDQUFRLEdBQVI7UUFDSSxJQUFJLFNBQVMsR0FBUSxJQUFJLENBQUMsa0JBQWtCLENBQUMsR0FBRyxDQUFDLFlBQVksRUFBRSxDQUFDO1FBQ2hFLElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxHQUFHLENBQUMsWUFBWSxDQUFDLFNBQVMsQ0FBQyxDQUFDO0lBQ3ZELENBQUM7SUFFTyxxQ0FBUSxHQUFoQjtRQUNJLElBQUksUUFBUSxHQUFHLElBQUksQ0FBQyxPQUFPLENBQUMsUUFBUSxFQUFFLENBQUM7UUFDdkMsSUFBSSxDQUFDLGVBQWUsQ0FBQyxRQUFRLENBQUMsQ0FBQztRQUMvQixJQUFJLENBQUMsWUFBWSxFQUFFLENBQUM7UUFDcEIsSUFBSSxDQUFDLFVBQVUsQ0FBQyxRQUFRLENBQUMsQ0FBQztRQUMxQixJQUFJLENBQUMsZUFBZSxDQUFDLFFBQVEsQ0FBQyxDQUFDO0lBQ25DLENBQUM7SUFFTyw0Q0FBZSxHQUF2QixVQUF3QixTQUFrQjtRQUN0QyxJQUFJLFNBQVMsRUFBRTtZQUNYLElBQUksTUFBTSxHQUF1QixFQUFFLENBQUM7WUFFcEMsTUFBTSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxhQUFhLENBQUMsYUFBYSxDQUFDLG1CQUFtQixDQUFDLENBQUMsQ0FBQztZQUNoRixNQUFNLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLGFBQWEsQ0FBQyxhQUFhLENBQUMsc0JBQXNCLENBQUMsQ0FBQyxDQUFDO1lBRW5GLEtBQUssSUFBSSxDQUFDLEdBQVcsQ0FBQyxFQUFFLENBQUMsR0FBRyxNQUFNLENBQUMsTUFBTSxFQUFFLENBQUMsRUFBRSxFQUFFO2dCQUM1QyxJQUFJLG1CQUFtQixHQUFZLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUMsUUFBUSxDQUFDLGlCQUFpQixDQUFDLElBQUksTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxRQUFRLENBQUMsZUFBZSxDQUFDLENBQUM7Z0JBRXBJLElBQUksQ0FBQyxtQkFBbUIsRUFBRTtvQkFDdEIsSUFBSSxJQUFJLFNBQVEsQ0FBQztvQkFDakIsSUFBSSxZQUFZLFNBQVEsQ0FBQztvQkFFekIsSUFBSSxDQUFDLEtBQUssQ0FBQyxFQUFFO3dCQUNULElBQUksR0FBRyxLQUFLLENBQUM7d0JBQ2IsWUFBWSxHQUFHLElBQUksQ0FBQyxhQUFhLENBQUM7cUJBQ3JDO3lCQUNJO3dCQUNELElBQUksR0FBRyxRQUFRLENBQUM7d0JBQ2hCLFlBQVksR0FBRyxJQUFJLENBQUMsWUFBWSxDQUFDO3FCQUNwQztvQkFFRCxJQUFJLFlBQVksS0FBSyxFQUFFLEVBQUU7d0JBQ3JCLElBQUksQ0FBQyxZQUFZLENBQUMsSUFBSSxFQUFFLFVBQVUsQ0FBQyxDQUFDO3FCQUN2Qzt5QkFDSTt3QkFDRCxJQUFJLENBQUMsWUFBWSxDQUFDLElBQUksRUFBRSxRQUFRLENBQUMsQ0FBQztxQkFDckM7aUJBQ0o7YUFDSjtTQUNKO2FBQ0k7WUFDRCxJQUFJLENBQUMsWUFBWSxDQUFDLEtBQUssRUFBRSxPQUFPLENBQUMsQ0FBQztZQUNsQyxJQUFJLENBQUMsWUFBWSxDQUFDLFFBQVEsRUFBRSxPQUFPLENBQUMsQ0FBQztTQUN4QztJQUNMLENBQUM7SUFFTywrQ0FBa0IsR0FBMUI7UUFDSSxJQUFJLENBQUMsVUFBVSxDQUFDLEtBQUssQ0FBQyxDQUFDO1FBQ3ZCLElBQUksQ0FBQyxVQUFVLENBQUMsUUFBUSxDQUFDLENBQUM7SUFDOUIsQ0FBQztJQUVPLHVDQUFVLEdBQWxCLFVBQW1CLEtBQWE7UUFDNUIsSUFBSSxXQUFXLEdBQVcsZ0JBQWdCLEdBQUcsS0FBSyxHQUFHLGdCQUFnQixHQUFHLEtBQUssQ0FBQztRQUM5RSxJQUFJLFNBQVMsR0FBZ0IsQ0FBQyxLQUFLLEtBQUssS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLGlCQUFpQixDQUFDO1FBQ2xHLElBQUksUUFBUSxHQUFnQixJQUFJLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxhQUFhLENBQUMsYUFBYSxDQUFDLFdBQVcsQ0FBQyxDQUFDO1FBRXZGLElBQUksU0FBUyxDQUFDLE9BQU8sQ0FBQyxNQUFNLEtBQUssQ0FBQyxFQUFFO1lBQ2hDLElBQUksQ0FBQyxPQUFPLENBQUMsUUFBUSxDQUFDLFFBQVEsRUFBRSxTQUFTLENBQUMsQ0FBQztTQUM5QzthQUNJO1lBQ0QsSUFBSSxDQUFDLE9BQU8sQ0FBQyxXQUFXLENBQUMsUUFBUSxFQUFFLFNBQVMsQ0FBQyxDQUFDO1NBQ2pEO0lBQ0wsQ0FBQztJQUVPLHlDQUFZLEdBQXBCO1FBQ0ksSUFBSSxXQUFXLEdBQVcsSUFBSSxDQUFDLFVBQVUsQ0FBQyxlQUFlLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDO1FBRXJFLElBQUksSUFBSSxDQUFDLGtCQUFrQixDQUFDLFNBQVMsS0FBSyxJQUFJLEVBQUU7WUFDNUMsSUFBSSxVQUFVLEdBQVcsSUFBSSxDQUFDLFVBQVUsQ0FBQyxhQUFhLENBQUMsSUFBSSxDQUFDLGlCQUFpQixFQUFFLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxTQUFTLENBQUMsYUFBYSxFQUFFLENBQUMsQ0FBQztZQUVsSSxJQUFJLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxTQUFTLEtBQUssSUFBSSxFQUFFO2dCQUM1QyxJQUFJLE1BQU0sR0FBa0IsSUFBSSxDQUFDLGtCQUFrQixDQUFDLFNBQVMsQ0FBQyxhQUFhLEVBQUUsQ0FBQztnQkFDOUUsSUFBSSxXQUFXLEdBQVcsQ0FBQyxDQUFDO2dCQUU1QixJQUFJLFVBQVUsR0FBRyxXQUFXLEVBQUU7b0JBQzFCLElBQUksYUFBYSxHQUFXLFdBQVcsR0FBRyxVQUFVLENBQUM7b0JBQ3JELFdBQVcsR0FBRyxhQUFhLEdBQUcsQ0FBQyxJQUFJLENBQUMsaUJBQWlCLENBQUMsTUFBTSxHQUFHLENBQUMsQ0FBQyxDQUFDO2lCQUNyRTtnQkFFRCxLQUFLLElBQUksQ0FBQyxHQUFXLENBQUMsRUFBRSxDQUFDLEdBQUcsSUFBSSxDQUFDLGlCQUFpQixDQUFDLE1BQU0sRUFBRSxDQUFDLEVBQUUsRUFBRTtvQkFDNUQsSUFBSSxLQUFLLEdBQVcsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxFQUFFLEtBQUssVUFBVSxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLEdBQUcsV0FBVyxDQUFDO29CQUM1SSxJQUFJLENBQUMsa0JBQWtCLENBQUMsU0FBUyxDQUFDLGNBQWMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLEVBQUUsS0FBSyxDQUFDLENBQUM7aUJBQ3RFO2FBQ0o7U0FDSjtJQUNMLENBQUM7SUFFTyw0Q0FBZSxHQUF2QixVQUF3QixTQUFrQjtRQUExQyxpQkFpQkM7UUFoQkcsSUFBSSxRQUFRLEdBQWdCLElBQUksQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLGFBQWEsQ0FBQyxhQUFhLENBQUMsbUJBQW1CLENBQUMsQ0FBQztRQUMvRixJQUFJLFdBQVcsR0FBZ0IsSUFBSSxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsYUFBYSxDQUFDLGFBQWEsQ0FBQyxzQkFBc0IsQ0FBQyxDQUFDO1FBRXJHLElBQUksU0FBUyxFQUFFO1lBQ1gsSUFBSSxDQUFDLFNBQVMsQ0FBQyxNQUFNLENBQUMsUUFBUSxFQUFFLE9BQU8sRUFBRSxVQUFDLEVBQVM7Z0JBQzNELElBQUksUUFBUSxDQUFDLFNBQVMsQ0FBQyxRQUFRLENBQUMsaUJBQWlCLENBQUMsRUFBRTtvQkFDaEQsS0FBSSxDQUFDLFlBQVksQ0FBQyxLQUFLLEVBQUUsUUFBUSxDQUFDLENBQUM7aUJBQ3RDO1lBQ0wsQ0FBQyxDQUFDLENBQUM7WUFFUyxJQUFJLENBQUMsU0FBUyxDQUFDLE1BQU0sQ0FBQyxXQUFXLEVBQUUsT0FBTyxFQUFFLFVBQUMsRUFBUztnQkFDOUQsSUFBSSxXQUFXLENBQUMsU0FBUyxDQUFDLFFBQVEsQ0FBQyxpQkFBaUIsQ0FBQyxFQUFFO29CQUNuRCxLQUFJLENBQUMsWUFBWSxDQUFDLFFBQVEsRUFBRSxRQUFRLENBQUMsQ0FBQztpQkFDekM7WUFDTCxDQUFDLENBQUMsQ0FBQztTQUNNO0lBQ0wsQ0FBQztJQUVPLDRDQUFlLEdBQXZCO1FBQ0ksSUFBSSxRQUFRLEdBQVEsSUFBSSxDQUFDLGNBQWMsQ0FBQyxjQUFjLENBQUMsSUFBSSxDQUFDLE1BQU0sRUFBRSxJQUFJLENBQUMsV0FBVyxFQUFFLElBQUksQ0FBQyxVQUFVLENBQUMsQ0FBQztRQUN2RyxJQUFJLENBQUMsV0FBVyxHQUFHLElBQUksQ0FBQyxjQUFjLENBQUMsYUFBYSxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQztRQUVsRSxJQUFJLENBQUMsa0JBQWtCLEdBQUcsUUFBUSxDQUFDLGdCQUFnQixDQUFDO1FBQ3BELElBQUksQ0FBQyxpQkFBaUIsR0FBRyxRQUFRLENBQUMsZUFBZSxDQUFDO1FBQ2xELElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxZQUFZLEdBQUcsQ0FBQyxJQUFJLENBQUMsaUJBQWlCLENBQUMsQ0FBQztRQUNoRSxJQUFJLENBQUMsaUJBQWlCLENBQUMsWUFBWSxHQUFHLENBQUMsSUFBSSxDQUFDLGtCQUFrQixDQUFDLENBQUM7UUFFaEUsSUFBSSxDQUFDLGNBQWMsQ0FBQyxHQUFHLEdBQUcsSUFBSSxDQUFDO1FBQy9CLElBQUksQ0FBQyxjQUFjLENBQUMsTUFBTSxHQUFHLElBQUksQ0FBQztRQUVsQyxJQUFJLENBQUMsWUFBWSxDQUFDLEdBQUcsR0FBRyxJQUFJLENBQUMsY0FBYyxDQUFDLGNBQWMsQ0FBQyxJQUFJLENBQUMsTUFBTSxFQUFFLEtBQUssQ0FBQyxDQUFDO1FBQy9FLElBQUksQ0FBQyxZQUFZLENBQUMsTUFBTSxHQUFHLElBQUksQ0FBQyxjQUFjLENBQUMsY0FBYyxDQUFDLElBQUksQ0FBQyxNQUFNLEVBQUUsUUFBUSxDQUFDLENBQUM7UUFFckYsSUFBSSxDQUFDLFFBQVEsQ0FBQyxLQUFLLEdBQUcsSUFBSSxDQUFDLGNBQWMsQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDLE1BQU0sRUFBRSxVQUFVLENBQUMsQ0FBQztRQUM3RSxJQUFJLENBQUMsUUFBUSxDQUFDLFFBQVEsR0FBRyxJQUFJLENBQUMsY0FBYyxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsTUFBTSxFQUFFLGFBQWEsQ0FBQyxDQUFDO1FBRW5GLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxRQUFRLENBQUMsQ0FBQztRQUNsQyxJQUFJLENBQUMsa0JBQWtCLENBQUMsT0FBTyxDQUFDLENBQUM7SUFDckMsQ0FBQztJQUVPLCtDQUFrQixHQUExQixVQUEyQixLQUFhO1FBQ3BDLElBQUksY0FBYyxHQUFnQixJQUFJLFdBQVcsRUFBRSxDQUFDO1FBQ3BELElBQUksQ0FBQyxlQUFlLENBQUMsS0FBSyxDQUFDLENBQUM7UUFFNUIsSUFBSSxXQUFXLEdBQWdCLENBQUMsS0FBSyxLQUFLLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsa0JBQWtCLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxpQkFBaUIsQ0FBQztRQUN2RyxJQUFJLE1BQU0sR0FBUSxjQUFjLENBQUMsVUFBVSxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsTUFBTSxFQUFFLFdBQVcsQ0FBQyxDQUFDO1FBQzdFLE1BQU0sQ0FBQyxhQUFhLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxZQUFZLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQztRQUN2RCxXQUFXLENBQUMsVUFBVSxHQUFHLE1BQU0sQ0FBQyxhQUFhLENBQUM7SUFDbEQsQ0FBQztJQUVPLDJDQUFjLEdBQXRCLFVBQXVCLFNBQXNCLEVBQUUsT0FBb0I7UUFBbkUsaUJBNkJDO1FBNUJHLElBQUksYUFBYSxHQUFtQixTQUFTLENBQUMsR0FBRyxDQUFDLGdCQUFnQixFQUFFLENBQUM7UUFDckUsSUFBSSxNQUFNLEdBQVcsQ0FBQyxDQUFDO1FBRXZCLEtBQUssSUFBSSxDQUFDLEdBQVcsQ0FBQyxFQUFFLENBQUMsR0FBRyxhQUFhLENBQUMsTUFBTSxFQUFFLENBQUMsRUFBRSxFQUFFO1lBQ25ELGFBQWEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsTUFBTSxHQUFHLElBQUksQ0FBQztZQUVwQyxPQUFPLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxhQUFhLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUM7WUFDNUMsU0FBUyxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsUUFBUSxDQUFDLGFBQWEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsR0FBRyxNQUFNLEVBQUUsQ0FBQyxDQUFDLENBQUM7WUFFcEUsTUFBTSxFQUFFLENBQUM7U0FDWjtRQUVELE9BQU8sQ0FBQyxHQUFHLENBQUMsVUFBVSxDQUFDLE9BQU8sQ0FBQyxPQUFPLENBQUMsQ0FBQztRQUN4QyxTQUFTLENBQUMsR0FBRyxDQUFDLFVBQVUsQ0FBQyxTQUFTLENBQUMsT0FBTyxDQUFDLENBQUM7UUFFNUMsSUFBSSxNQUFNLEdBQVcsQ0FBQyxDQUFDLENBQUM7UUFDeEIsT0FBTyxDQUFDLEdBQUcsQ0FBQyxzQkFBc0IsQ0FBQyxVQUFDLEtBQWM7WUFDOUMsSUFBSSxhQUFhLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLEtBQUksQ0FBQyxXQUFXLENBQUMsS0FBSyxLQUFLLENBQUMsSUFBSSxDQUFDLEtBQUksQ0FBQyxXQUFXLENBQUMsRUFBRTtnQkFDMUUsTUFBTSxHQUFHLEtBQUssQ0FBQyxVQUFVLENBQUM7YUFDN0I7UUFDTCxDQUFDLENBQUMsQ0FBQztRQUVILE9BQU8sQ0FBQyxHQUFHLENBQUMsa0JBQWtCLENBQUMsTUFBTSxDQUFDLENBQUM7UUFFdkMsSUFBSSxDQUFDLGNBQWMsR0FBRyxJQUFJLENBQUMsY0FBYyxDQUFDLGNBQWMsQ0FBQyxJQUFJLENBQUMsa0JBQWtCLEVBQUUsSUFBSSxDQUFDLGlCQUFpQixDQUFDLENBQUM7UUFDMUcsSUFBSSxDQUFDLGtCQUFrQixFQUFFLENBQUM7UUFDMUIsSUFBSSxDQUFDLHVCQUF1QixFQUFFLENBQUM7UUFDL0IsSUFBSSxDQUFDLFNBQVMsRUFBRSxDQUFDO0lBQ3JCLENBQUM7SUFFTyxvREFBdUIsR0FBL0I7UUFDSSxJQUFJLENBQUMsZ0JBQWdCLEdBQUcsS0FBSyxDQUFDO1FBQzlCLElBQUksQ0FBQyxlQUFlLEdBQUcsS0FBSyxDQUFDO1FBQzdCLElBQUksQ0FBQyxjQUFjLENBQUMsMkJBQTJCLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDO0lBQy9ELENBQUM7SUFFTyxzQ0FBUyxHQUFqQjtRQUNJLElBQUksZ0JBQWdCLEdBQVEsRUFBRSxDQUFDO1FBQy9CLGdCQUFnQixDQUFDLE9BQU8sR0FBRyxJQUFJLENBQUMsa0JBQWtCLENBQUMsT0FBTyxDQUFDO1FBQzNELGdCQUFnQixDQUFDLFVBQVUsR0FBRyxJQUFJLENBQUMsaUJBQWlCLENBQUMsT0FBTyxDQUFDO1FBQzdELElBQUksQ0FBQyxhQUFhLENBQUMsSUFBSSxDQUFDLGdCQUFnQixDQUFDLENBQUM7SUFDOUMsQ0FBQztJQUVELGdDQUFnQztJQUVoQyxJQUFJO0lBRUksNENBQWUsR0FBdkIsVUFBd0IsS0FBYTtRQUFyQyxpQkE2Q0M7UUE1Q0csSUFBSSxXQUF3QixDQUFDO1FBQzdCLElBQUksY0FBdUIsQ0FBQztRQUU1QixJQUFJLEtBQUssS0FBSyxRQUFRLEVBQUU7WUFDcEIsV0FBVyxHQUFHLElBQUksQ0FBQyxrQkFBa0IsQ0FBQztZQUN0QyxjQUFjLEdBQUcsSUFBSSxDQUFDLGdCQUFnQixDQUFDO1NBQzFDO2FBQ0k7WUFDRCxXQUFXLEdBQUcsSUFBSSxDQUFDLGlCQUFpQixDQUFDO1lBQ3JDLGNBQWMsR0FBRyxJQUFJLENBQUMsZUFBZSxDQUFDO1NBQ3pDO1FBRUQsV0FBVyxDQUFDLGdCQUFnQixHQUFHLENBQUMsRUFBQyxTQUFTLEVBQUUsSUFBSSxFQUFDLENBQUMsQ0FBQztRQUNuRCxXQUFXLENBQUMsZUFBZSxHQUFHLFVBQUMsUUFBaUI7WUFDNUMsSUFBSSxPQUFPLFFBQVEsQ0FBQyxJQUFJLENBQUMsU0FBUyxLQUFLLFdBQVcsRUFBRTtnQkFDaEQsT0FBTyxRQUFRLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQzthQUNsQztZQUNELE9BQU8sS0FBSyxDQUFDO1FBQ2pCLENBQUMsQ0FBQztRQUVGLFdBQVcsQ0FBQyxxQkFBcUIsR0FBRyxVQUFDLE1BQVc7WUFDNUMsSUFBSSxhQUFhLEdBQWdCLFFBQVEsQ0FBQyxhQUFhLENBQUMsS0FBSyxDQUFDLENBQUM7WUFDL0QsSUFBSSxlQUFlLEdBQW1CLEtBQUksQ0FBQyxPQUFPLENBQUMsYUFBYSxDQUFDLGFBQWEsRUFBRSw4QkFBOEIsRUFBRSxLQUFLLENBQUMsQ0FBQztZQUN2SCxJQUFJLFFBQVEsR0FBcUIsS0FBSSxDQUFDLE9BQU8sQ0FBQyxhQUFhLENBQUMsZUFBZSxFQUFFLFlBQVksRUFBRSxPQUFPLENBQUMsQ0FBQztZQUVwRyxRQUFRLENBQUMsSUFBSSxHQUFHLFVBQVUsQ0FBQztZQUUzQixLQUFJLENBQUMsT0FBTyxDQUFDLGFBQWEsQ0FBQyxlQUFlLEVBQUUsT0FBTyxFQUFFLE9BQU8sQ0FBQyxDQUFDO1lBQzlELGVBQWUsQ0FBQyxnQkFBZ0IsQ0FBQyxRQUFRLEVBQUU7Z0JBQ3ZDLElBQUksU0FBUyxHQUFZLFFBQVEsQ0FBQyxPQUFPLENBQUM7Z0JBQzFDLEtBQUksQ0FBQyxrQkFBa0IsQ0FBQyxNQUFNLEVBQUUsS0FBSyxFQUFFLFNBQVMsQ0FBQyxDQUFDO1lBQ3RELENBQUMsQ0FBQyxDQUFDO1lBRUgsSUFBSSxjQUFjLEVBQUU7Z0JBQ2hCLFFBQVEsQ0FBQyxPQUFPLEdBQUcsSUFBSSxDQUFDO2FBQzNCO1lBRUQsSUFBSSxXQUFXLEdBQW1CLEtBQUksQ0FBQyxPQUFPLENBQUMsYUFBYSxDQUFDLGFBQWEsRUFBRSxlQUFlLEVBQUUsS0FBSyxDQUFDLENBQUM7WUFDcEcsSUFBSSxJQUFJLEdBQW1CLEtBQUksQ0FBQyxPQUFPLENBQUMsYUFBYSxDQUFDLFdBQVcsRUFBRSxZQUFZLEVBQUUsS0FBSyxDQUFDLENBQUM7WUFDeEYsSUFBSSxJQUFJLEdBQUcsV0FBVyxDQUFDLEdBQUcsQ0FBQyxRQUFRLEVBQUUsQ0FBQyxXQUFXLEVBQUUsQ0FBQztZQUNwRCxJQUFJLENBQUMsU0FBUyxHQUFHLGFBQWEsR0FBRyxJQUFJLEdBQUcsVUFBVSxDQUFDO1lBRW5ELE9BQU8sYUFBYSxDQUFDO1FBQ3pCLENBQUMsQ0FBQztJQUNOLENBQUM7SUFFTyx1Q0FBVSxHQUFsQixVQUFtQixTQUFrQjtRQUNqQyxJQUFJLE1BQVcsQ0FBQztRQUVoQixJQUFJLFNBQVMsRUFBRTtZQUNYLE1BQU0sR0FBRyxJQUFJLENBQUMsY0FBYyxDQUFDLGdCQUFnQixDQUFDLElBQUksQ0FBQyxrQkFBa0IsRUFBRSxJQUFJLENBQUMsaUJBQWlCLEVBQUUsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDO1NBQzdHO2FBQ0k7WUFDRCxNQUFNLEdBQUcsSUFBSSxDQUFDLGNBQWMsQ0FBQyxhQUFhLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsQ0FBQztTQUNsRTtRQUVELElBQUksQ0FBQyxjQUFjLENBQUMsUUFBUSxFQUFFLE1BQU0sQ0FBQyxDQUFDO1FBQ3RDLElBQUksQ0FBQyxjQUFjLENBQUMsT0FBTyxFQUFFLE1BQU0sQ0FBQyxDQUFDO0lBQ3pDLENBQUM7SUFFTywyQ0FBYyxHQUF0QixVQUF1QixLQUFhLEVBQUUsT0FBWTtRQUM5QyxJQUFJLFdBQVcsR0FBVyxhQUFhLEdBQUcsS0FBSyxDQUFDO1FBQ2hELElBQUksVUFBa0IsQ0FBQztRQUN2QixJQUFJLE9BQU8sR0FBZ0IsSUFBSSxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsYUFBYSxDQUFDLGFBQWEsQ0FBQyxXQUFXLENBQUMsQ0FBQztRQUV0RixJQUFJLEtBQUssS0FBSyxRQUFRLEVBQUU7WUFDcEIsVUFBVSxHQUFHLE9BQU8sQ0FBQyxHQUFHLEdBQUcsSUFBSSxDQUFDO1NBQ25DO2FBQ0k7WUFDRCxVQUFVLEdBQUcsT0FBTyxDQUFDLE1BQU0sR0FBRyxJQUFJLENBQUM7U0FDdEM7UUFFRCxJQUFJLENBQUMsT0FBTyxDQUFDLGVBQWUsQ0FBQyxPQUFPLEVBQUUsUUFBUSxFQUFFLFVBQVUsQ0FBQyxDQUFDO0lBQ2hFLENBQUM7SUFFTyx5Q0FBWSxHQUFwQixVQUFxQixLQUFhO1FBQWxDLGlCQU9DO1FBTkcsSUFBSSxlQUFlLEdBQVEsSUFBSSxDQUFDLGNBQWMsQ0FBQyxrQkFBa0IsRUFBRSxDQUFDO1FBQ3BFLGVBQWUsQ0FBQyxNQUFNLEdBQUksSUFBSSxDQUFDLFVBQVUsQ0FBQztRQUMxQyxlQUFlLENBQUMsU0FBUyxHQUFHLG1CQUFtQixDQUFDO1FBQ2hELGVBQWUsQ0FBQyxZQUFZLEdBQUcsVUFBQyxPQUFZLElBQWtCLE9BQUEsS0FBSSxDQUFDLGlCQUFpQixDQUFDLE9BQU8sRUFBRSxLQUFLLENBQUMsRUFBdEMsQ0FBc0MsQ0FBQztRQUVyRyxPQUFPLGVBQWUsQ0FBQztJQUMzQixDQUFDO0lBRU8sOENBQWlCLEdBQXpCLFVBQTBCLE1BQVcsRUFBRSxJQUFZO1FBQW5ELGlCQWVDO1FBZEcsSUFBSSxNQUFNLEdBQW1CLFFBQVEsQ0FBQyxhQUFhLENBQUMsS0FBSyxDQUFDLENBQUM7UUFDM0QsSUFBSSxLQUFLLEdBQXFCLElBQUksQ0FBQyxPQUFPLENBQUMsYUFBYSxDQUFDLE1BQU0sRUFBRSxVQUFVLEVBQUUsT0FBTyxDQUFDLENBQUM7UUFDdEYsSUFBSSxDQUFDLE9BQU8sQ0FBQyxhQUFhLENBQUMsTUFBTSxFQUFFLE9BQU8sRUFBRSxPQUFPLENBQUMsQ0FBQztRQUNyRCxJQUFJLFdBQVcsR0FBZ0IsQ0FBQyxJQUFJLEtBQUssUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLGlCQUFpQixDQUFDO1FBQ3RHLElBQUksV0FBVyxHQUFZLFdBQVcsQ0FBQyxHQUFHLENBQUMsUUFBUSxFQUFFLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxRQUFRLENBQUMsQ0FBQztRQUM5RSxLQUFLLENBQUMsSUFBSSxHQUFHLFVBQVUsQ0FBQztRQUN4QixNQUFNLENBQUMsU0FBUyxHQUFHLG1CQUFtQixDQUFDO1FBQ3ZDLE1BQU0sQ0FBQyxnQkFBZ0IsQ0FBQyxRQUFRLEVBQUUsVUFBQyxNQUFNO1lBQ3JDLFdBQVcsQ0FBQyxjQUFjLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxDQUFDO1lBQzFDLEtBQUksQ0FBQyxlQUFlLENBQUMsTUFBTSxFQUFFLElBQUksQ0FBQyxDQUFDO1FBQ3ZDLENBQUMsQ0FBQyxDQUFDO1FBQ0gsSUFBSSxXQUFXLENBQUMsVUFBVSxFQUFFO1lBQUUsS0FBSyxDQUFDLE9BQU8sR0FBRyxJQUFJLENBQUM7UUFFbkQsT0FBTyxNQUFNLENBQUM7SUFDbEIsQ0FBQztJQUVPLDRDQUFlLEdBQXZCLFVBQXdCLE1BQVcsRUFBRSxJQUFZO1FBQzdDLElBQUksV0FBVyxHQUFnQixDQUFDLElBQUksS0FBSyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLGtCQUFrQixDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsaUJBQWlCLENBQUM7UUFDdEcsSUFBSSxTQUFTLEdBQVksQ0FBQyxJQUFJLEtBQUssUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLGVBQWUsQ0FBQztRQUM1RixJQUFJLFdBQVcsR0FBVyxHQUFHLEdBQUcsSUFBSSxHQUFHLG9CQUFvQixDQUFDO1FBQzVELElBQUksYUFBYSxHQUFHLFdBQVcsQ0FBQyxHQUFHLENBQUMsUUFBUSxFQUFFLENBQUMsV0FBVyxFQUFFLENBQUM7UUFDN0QsSUFBSSxrQkFBa0IsR0FBRyxXQUFXLENBQUMsR0FBRyxDQUFDLGdCQUFnQixFQUFFLENBQUMsTUFBTSxDQUFDO1FBQ25FLFNBQVMsR0FBRyxDQUFDLGFBQWEsS0FBSyxrQkFBa0IsQ0FBQyxDQUFDO1FBRW5ELElBQUksSUFBSSxLQUFLLFFBQVE7WUFBRSxJQUFJLENBQUMsZ0JBQWdCLEdBQUcsU0FBUyxDQUFDOztZQUNwRCxJQUFJLENBQUMsZUFBZSxHQUFHLFNBQVMsQ0FBQztRQUV0QyxJQUFJLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxhQUFhLENBQUMsYUFBYSxDQUFDLFdBQVcsQ0FBQyxDQUFDLE9BQU8sR0FBRyxTQUFTLENBQUM7UUFDL0UsSUFBSSxDQUFDLGdCQUFnQixDQUFDLElBQUksQ0FBQyxDQUFDO1FBQzVCLElBQUksQ0FBQyxjQUFjLEdBQUcsSUFBSSxDQUFDLGNBQWMsQ0FBQyxjQUFjLENBQUMsSUFBSSxDQUFDLGtCQUFrQixFQUFFLElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxDQUFDO0lBQzlHLENBQUM7SUFFTywrQ0FBa0IsR0FBMUIsVUFBMkIsTUFBVyxFQUFFLElBQVksRUFBRSxTQUFrQjtRQUNwRSxJQUFJLFFBQVEsR0FBVyxHQUFHLEdBQUcsSUFBSSxHQUFHLENBQUMsQ0FBQyxJQUFJLENBQUMsVUFBVSxLQUFLLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxpQ0FBaUMsQ0FBQyxDQUFDLENBQUMsa0NBQWtDLENBQUMsQ0FBQztRQUM1SSxJQUFJLGFBQWEsR0FBZ0IsSUFBSSxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsYUFBYSxDQUFDLGFBQWEsQ0FBQyxRQUFRLENBQUMsQ0FBQztRQUN6RixJQUFJLFFBQVEsR0FBb0IsYUFBYSxDQUFDLGdCQUFnQixDQUFDLDBCQUEwQixDQUFDLENBQUM7UUFDM0YsSUFBSSxXQUFXLEdBQWdCLENBQUMsSUFBSSxLQUFLLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsa0JBQWtCLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxpQkFBaUIsQ0FBQztRQUN0RyxJQUFJLFFBQVEsR0FBYyxXQUFXLENBQUMsR0FBRyxDQUFDLFFBQVEsRUFBRSxDQUFDO1FBRXJELElBQUksSUFBSSxLQUFLLFFBQVE7WUFBRSxJQUFJLENBQUMsZ0JBQWdCLEdBQUcsU0FBUyxDQUFDOztZQUNwRCxJQUFJLENBQUMsZUFBZSxHQUFHLFNBQVMsQ0FBQztRQUV0QyxJQUFJLFNBQVMsR0FBWSxDQUFDLElBQUksS0FBSyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLGdCQUFnQixDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsZUFBZSxDQUFDO1FBQzVGLEtBQUssSUFBSSxDQUFDLEdBQVcsQ0FBQyxFQUFFLENBQUMsR0FBRyxRQUFRLENBQUMsV0FBVyxFQUFFLEVBQUUsQ0FBQyxFQUFFLEVBQUU7WUFDckQsUUFBUSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxjQUFjLENBQUMsU0FBUyxDQUFDLENBQUM7WUFDN0MsSUFBSSxPQUFPLFFBQVEsQ0FBQyxDQUFDLENBQUMsS0FBSyxXQUFXO2dCQUFFLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPLEdBQUcsU0FBUyxDQUFDO1NBQzNFO1FBQ0QsSUFBSSxDQUFDLGdCQUFnQixDQUFDLElBQUksQ0FBQyxDQUFDO1FBQzVCLElBQUksQ0FBQyxjQUFjLEdBQUcsSUFBSSxDQUFDLGNBQWMsQ0FBQyxjQUFjLENBQUMsSUFBSSxDQUFDLGtCQUFrQixFQUFFLElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxDQUFDO0lBQzlHLENBQUM7SUFFTyw2Q0FBZ0IsR0FBeEIsVUFBeUIsV0FBbUI7UUFDeEMsSUFBSSxXQUFXLEdBQVcsQ0FBQyxXQUFXLEtBQUssUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLGlDQUFpQyxDQUFDLENBQUMsQ0FBQyxrQ0FBa0MsQ0FBQztRQUM5SCxJQUFJLFVBQVUsR0FBZSxJQUFJLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxhQUFhLENBQUMsZ0JBQWdCLENBQUMsV0FBVyxDQUFDLENBQUM7UUFDM0YsSUFBSSxDQUFDLGNBQWMsQ0FBQyxnQkFBZ0IsQ0FBQyxVQUFVLENBQUMsQ0FBQztRQUNqRCxJQUFJLFdBQVcsS0FBSyxRQUFRLEVBQUU7WUFDMUIsSUFBSSxDQUFDLGlCQUFpQixDQUFDLEdBQUcsQ0FBQyxXQUFXLEVBQUUsQ0FBQztZQUN6QyxJQUFJLENBQUMsZUFBZSxHQUFHLEtBQUssQ0FBQztTQUNoQzthQUNJO1lBQ0QsSUFBSSxDQUFDLGtCQUFrQixDQUFDLEdBQUcsQ0FBQyxXQUFXLEVBQUUsQ0FBQztZQUMxQyxJQUFJLENBQUMsZ0JBQWdCLEdBQUcsS0FBSyxDQUFDO1NBQ2pDO0lBQ0wsQ0FBQztJQUVPLHlDQUFZLEdBQXBCLFVBQXFCLElBQVksRUFBRSxLQUFhO1FBQzVDLElBQUksV0FBVyxHQUFXLGdCQUFnQixHQUFHLElBQUksQ0FBQztRQUNsRCxJQUFJLFVBQVUsR0FBZ0IsSUFBSSxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsYUFBYSxDQUFDLGFBQWEsQ0FBQyxXQUFXLENBQUMsQ0FBQztRQUN6RixJQUFJLEtBQUssS0FBSyxVQUFVLEVBQUU7WUFDdEIsSUFBSSxDQUFDLE9BQU8sQ0FBQyxRQUFRLENBQUMsVUFBVSxFQUFFLGlCQUFpQixDQUFDLENBQUM7WUFDckQsSUFBSSxDQUFDLE9BQU8sQ0FBQyxXQUFXLENBQUMsVUFBVSxFQUFFLGVBQWUsQ0FBQyxDQUFDO1NBQ3pEO2FBQ0ksSUFBSSxLQUFLLEtBQUssUUFBUSxFQUFFO1lBQ3pCLElBQUksQ0FBQyxPQUFPLENBQUMsUUFBUSxDQUFDLFVBQVUsRUFBRSxlQUFlLENBQUMsQ0FBQztZQUNuRCxJQUFJLENBQUMsT0FBTyxDQUFDLFdBQVcsQ0FBQyxVQUFVLEVBQUUsaUJBQWlCLENBQUMsQ0FBQztTQUMzRDtRQUNELFVBQVU7YUFDTDtZQUNELElBQUksQ0FBQyxPQUFPLENBQUMsV0FBVyxDQUFDLFVBQVUsRUFBRSxlQUFlLENBQUMsQ0FBQztZQUN0RCxJQUFJLENBQUMsT0FBTyxDQUFDLFdBQVcsQ0FBQyxVQUFVLEVBQUUsaUJBQWlCLENBQUMsQ0FBQztTQUMzRDtJQUNMLENBQUM7O2dCQXBmMkIscUJBQXFCO2dCQUM1QixZQUFZO2dCQUNmLGdCQUFnQjtnQkFDWCxTQUFTO2dCQUNKLGVBQWU7Z0JBQ25CLFdBQVc7O0lBWDFCO1FBQVIsS0FBSyxFQUFFOztzREFBYTtJQUNaO1FBQVIsS0FBSyxFQUFFO2tDQUFhLEtBQUs7MERBQU07SUFDdkI7UUFBUixLQUFLLEVBQUU7a0NBQVksS0FBSzt5REFBTTtJQUNyQjtRQUFULE1BQU0sRUFBRTtrQ0FBZ0IsWUFBWTs2REFBMkI7SUFjaEU7UUFEQyxZQUFZLENBQUMsZUFBZSxFQUFFLENBQUMsUUFBUSxDQUFDLENBQUM7O3lDQUM5QixLQUFLOztzREFFaEI7SUF4Q1Esa0JBQWtCO1FBUjlCLFNBQVMsQ0FBQztZQUNQLFFBQVEsRUFBRSxzQkFBc0I7WUFDaEMsMjVEQUFrRDtZQUNsRCxTQUFTLEVBQUUsQ0FBQyxxQkFBcUIsRUFBRSxZQUFZLEVBQUUsV0FBVyxDQUFDO1lBQzdELGFBQWEsRUFBRSxpQkFBaUIsQ0FBQyxJQUFJO1lBQ3JDLElBQUksRUFBRyxFQUFFLE9BQU8sRUFBRyx1QkFBdUIsRUFBRTtTQUMvQyxDQUFDO3lDQTZCOEIscUJBQXFCO1lBQzVCLFlBQVk7WUFDZixnQkFBZ0I7WUFDWCxTQUFTO1lBQ0osZUFBZTtZQUNuQixXQUFXO09BaEMxQixrQkFBa0IsQ0FnaEI5QjtJQUFELHlCQUFDO0NBQUEsQUFoaEJELElBZ2hCQztTQWhoQlksa0JBQWtCIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgQ29tcG9uZW50LCBPbkluaXQsIEFmdGVyVmlld0luaXQsIE9uRGVzdHJveSwgSW5wdXQsIE91dHB1dCwgRXZlbnRFbWl0dGVyLCBWaWV3RW5jYXBzdWxhdGlvbiwgVmlld0NvbnRhaW5lclJlZiwgSG9zdExpc3RlbmVyLCBTaW1wbGVDaGFuZ2VzLCBSZW5kZXJlcjIgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcclxuaW1wb3J0IHsgdGltZXIgLCAgU3Vic2NyaXB0aW9uIH0gZnJvbSAncnhqcyc7XHJcbmltcG9ydCB7IEdyaWRPcHRpb25zLCBSb3dOb2RlLCBJUm93TW9kZWwsIENvbHVtbiB9IGZyb20gJ2FnLWdyaWQtY29tbXVuaXR5JztcclxuaW1wb3J0ICdhZy1ncmlkLWVudGVycHJpc2UnO1xyXG5pbXBvcnQgeyBLZERvbUVsZW1TdmMsIEFHX0dSSURfS0VZIH0gZnJvbSAnLi4va2QtY29tbW9uL2luZGV4JztcclxuaW1wb3J0IHsgS2RTcGxpdHRlckV2ZW50IH0gZnJvbSAnLi4va2QtYW5ndWxhci1zcGxpdHRlci9pbmRleCc7XHJcbmltcG9ydCB7IEtkTXVsdGlTZWxlY3RUYWJsZVN2YyB9IGZyb20gJy4va2QtbXVsdGlzZWxlY3QtdGFibGUtc3ZjJztcclxuaW1wb3J0IHsgS2RBZ2dyaWRTdmMgfSBmcm9tICcuLi9rZC1hbmd1bGFyLWFnZ3JpZC9zcmMva2QtYW5ndWxhci1hZ2dyaWQtc3ZjJztcclxuaW1wb3J0IHtMaWNlbnNlTWFuYWdlcn0gZnJvbSBcImFnLWdyaWQtZW50ZXJwcmlzZVwiO1xyXG5cclxuZGVjbGFyZSB2YXIgcmVxdWlyZTogYW55O1xyXG5cclxuQENvbXBvbmVudCh7XHJcbiAgICBzZWxlY3RvcjogJ2tkLW11bHRpc2VsZWN0LXRhYmxlJyxcclxuICAgIHRlbXBsYXRlVXJsOiAnLi9rZC1hbmd1bGFyLW11bHRpc2VsZWN0LXRhYmxlLmh0bWwnLFxyXG4gICAgcHJvdmlkZXJzOiBbS2RNdWx0aVNlbGVjdFRhYmxlU3ZjLCBLZERvbUVsZW1TdmMsIEtkQWdncmlkU3ZjXSxcclxuICAgIGVuY2Fwc3VsYXRpb246IFZpZXdFbmNhcHN1bGF0aW9uLk5vbmUsXHJcbiAgICBob3N0IDogeyAnY2xhc3MnIDogJ2tkeC1tdWx0aXNlbGVjdC10YWJsZScgfVxyXG59KVxyXG5cclxuZXhwb3J0IGNsYXNzIEtkTXVsdGlTZWxlY3RUYWJsZSBpbXBsZW1lbnRzIE9uSW5pdCwgQWZ0ZXJWaWV3SW5pdCwgT25EZXN0cm95IHtcclxuICAgIHB1YmxpYyBfbWFzdGVyU2VhcmNoOiBzdHJpbmcgPSAnJztcclxuICAgIHB1YmxpYyBfc2xhdmVTZWFyY2g6IHN0cmluZyA9ICcnO1xyXG4gICAgcHVibGljIF9tYXN0ZXJHcmlkT3B0aW9uczogR3JpZE9wdGlvbnM7XHJcbiAgICBwdWJsaWMgX3NsYXZlR3JpZE9wdGlvbnM6IEdyaWRPcHRpb25zO1xyXG4gICAgcHVibGljIF9kaXNhYmxlQnV0dG9uOiBhbnkgPSB7fTtcclxuICAgIHB1YmxpYyBfcGxhY2Vob2xkZXI6IGFueSA9IHt9O1xyXG4gICAgcHVibGljIF9idXR0b25zOiBhbnkgPSB7fTtcclxuXHJcbiAgICBwcml2YXRlIGVudGVycHJpc2UgPSByZXF1aXJlKCdhZy1ncmlkLWVudGVycHJpc2UnKTtcclxuICAgIHByaXZhdGUgX21hc3RlclNlbGVjdEFsbDogYm9vbGVhbiA9IGZhbHNlO1xyXG4gICAgcHJpdmF0ZSBfc2xhdmVTZWxlY3RBbGw6IGJvb2xlYW4gPSBmYWxzZTtcclxuICAgIHByaXZhdGUgX2NvbERlZkFycmF5V2lkdGg6IEFycmF5PHt3aWR0aDogbnVtYmVyLCBpZDogc3RyaW5nfT4gPSBbXTtcclxuICAgIHByaXZhdGUgX2RpcmVjdGlvbjogc3RyaW5nO1xyXG4gICAgcHJpdmF0ZSBfcHJpbWFyeUtleTogYW55O1xyXG4gICAgcHJpdmF0ZSBfZmlyc3RSdW46IGJvb2xlYW4gPSB0cnVlO1xyXG4gICAgcHJpdmF0ZSBfbWFzdGVyRGF0YTogQXJyYXk8YW55PiA9IFtdO1xyXG4gICAgcHJpdmF0ZSBfc2xhdmVEYXRhOiBBcnJheTxhbnk+ID0gW107XHJcbiAgICBwcml2YXRlIF9zcGxpdHRlckNsaWNrU3ViOiBTdWJzY3JpcHRpb247XHJcbiAgICBwcml2YXRlIF9zcGxpdHRlckRyYWdTdWI6IFN1YnNjcmlwdGlvbjtcclxuXHJcbiAgICBASW5wdXQoKSBjb25maWc6IGFueTtcclxuICAgIEBJbnB1dCgpIG1hc3RlckRhdGE6IEFycmF5PGFueT47XHJcbiAgICBASW5wdXQoKSBzbGF2ZURhdGE6IEFycmF5PGFueT47XHJcbiAgICBAT3V0cHV0KCkgdG9wQm90dG9tRGF0YTogRXZlbnRFbWl0dGVyPGFueT4gPSBuZXcgRXZlbnRFbWl0dGVyKCk7XHJcblxyXG4gICAgY29uc3RydWN0b3IoXHJcbiAgICAgICAgcHJpdmF0ZSBfbXVsdGlUYWJsZVN2YzogS2RNdWx0aVNlbGVjdFRhYmxlU3ZjLFxyXG4gICAgICAgIHByaXZhdGUgX2RvbVN2YzogS2REb21FbGVtU3ZjLFxyXG4gICAgICAgIHByaXZhdGUgX3ZjcjogVmlld0NvbnRhaW5lclJlZixcclxuICAgICAgICBwcml2YXRlIF9yZW5kZXJlcjogUmVuZGVyZXIyLFxyXG4gICAgICAgIHByaXZhdGUgX3NwbGl0dGVyRXZlbnQ6IEtkU3BsaXR0ZXJFdmVudCxcclxuICAgICAgICBwcml2YXRlIF9hZ2dyaWRTdmM6IEtkQWdncmlkU3ZjXHJcbiAgICApIHtcclxuICAgICAgICBMaWNlbnNlTWFuYWdlci5zZXRMaWNlbnNlS2V5KEFHX0dSSURfS0VZLnZhbHVlKTtcclxuICAgIH1cclxuXHJcbiAgICBASG9zdExpc3RlbmVyKCd3aW5kb3c6cmVzaXplJywgWyckZXZlbnQnXSlcclxuICAgIG9uUmVzaXplKGU6IEV2ZW50KSB7XHJcbiAgICAgICAgdGhpcy5fc2V0VmlldygpO1xyXG4gICAgfVxyXG5cclxuICAgIG5nT25Jbml0KCk6IHZvaWQge1xyXG4gICAgICAgIHRoaXMuX2RpcmVjdGlvbiA9ICh0aGlzLl9kb21TdmMuZ2V0RG9jdW1lbnREaXJlY3Rpb24odHJ1ZSkpO1xyXG4gICAgICAgIHRoaXMuX21hc3RlckRhdGEgPSAodHlwZW9mIHRoaXMubWFzdGVyRGF0YSAhPT0gJ3VuZGVmaW5lZCcpID8gdGhpcy5tYXN0ZXJEYXRhLnNsaWNlKCkgOiBbXTtcclxuICAgICAgICB0aGlzLl9zbGF2ZURhdGEgPSAodHlwZW9mIHRoaXMuc2xhdmVEYXRhICE9PSAndW5kZWZpbmVkJykgPyB0aGlzLnNsYXZlRGF0YS5zbGljZSgpIDogW107XHJcbiAgICAgICAgdGhpcy5fc2V0R3JpZE9wdGlvbnMoKTtcclxuXHJcbiAgICAgICAgdGhpcy5fc3BsaXR0ZXJDbGlja1N1YiA9IHRoaXMuX3NwbGl0dGVyRXZlbnQub25Ub2dnbGVNZW51KCkuc3Vic2NyaWJlKCgpOiB2b2lkID0+IHtcclxuICAgICAgICAgICAgdGltZXIoNzAwKS5zdWJzY3JpYmUoKCk6IHZvaWQgPT4ge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5fc2V0VmlldygpO1xyXG4gICAgICAgICAgICB9KTtcclxuICAgICAgICB9KTtcclxuXHJcbiAgICAgICAgdGhpcy5fc3BsaXR0ZXJEcmFnU3ViID0gdGhpcy5fc3BsaXR0ZXJFdmVudC5vbkRyYWcoKS5zdWJzY3JpYmUoKCk6IHZvaWQgPT4ge1xyXG4gICAgICAgICAgICB0aW1lcigyMDApLnN1YnNjcmliZSgoKTogdm9pZCA9PiB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLl9zZXRWaWV3KCk7XHJcbiAgICAgICAgICAgIH0pO1xyXG4gICAgICAgIH0pO1xyXG5cclxuICAgICAgICBsZXQgY3VycmVudFNlbGVjdGlvbjogYW55ID0ge307XHJcblxyXG4gICAgICAgIHRoaXMuX21hc3RlckdyaWRPcHRpb25zLmVuYWJsZVJ0bCA9IHRoaXMuX2RpcmVjdGlvbiA9PT0gJ3JpZ2h0JztcclxuICAgICAgICB0aGlzLl9zbGF2ZUdyaWRPcHRpb25zLmVuYWJsZVJ0bCA9IHRoaXMuX2RpcmVjdGlvbiA9PT0gJ3JpZ2h0JztcclxuXHJcbiAgICAgICAgY3VycmVudFNlbGVjdGlvbi50b3BHcmlkID0gdGhpcy5fbWFzdGVyR3JpZE9wdGlvbnMucm93RGF0YTtcclxuICAgICAgICBjdXJyZW50U2VsZWN0aW9uLmJvdHRvbUdyaWQgPSB0aGlzLl9zbGF2ZUdyaWRPcHRpb25zLnJvd0RhdGE7XHJcbiAgICAgICAgdGltZXIoKS5zdWJzY3JpYmUoKCk6IHZvaWQgPT4ge1xyXG4gICAgICAgICAgICB0aGlzLnRvcEJvdHRvbURhdGEuZW1pdChjdXJyZW50U2VsZWN0aW9uKTtcclxuICAgICAgICB9KTtcclxuICAgIH1cclxuXHJcbiAgICBuZ09uQ2hhbmdlcyhfc2ltcGxlQ2hhbmdlOiBTaW1wbGVDaGFuZ2VzKTogdm9pZCB7XHJcbiAgICAgICAgaWYgKCF0aGlzLl9maXJzdFJ1bikge1xyXG4gICAgICAgICAgICBpZiAoX3NpbXBsZUNoYW5nZS5oYXNPd25Qcm9wZXJ0eSgnbWFzdGVyRGF0YScpKSB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLl9tYXN0ZXJHcmlkT3B0aW9ucy5yb3dEYXRhID0gX3NpbXBsZUNoYW5nZVsnbWFzdGVyRGF0YSddLmN1cnJlbnRWYWx1ZTtcclxuICAgICAgICAgICAgICAgIHRoaXMuX21hc3RlckdyaWRPcHRpb25zLmFwaS5zZXRSb3dEYXRhKF9zaW1wbGVDaGFuZ2VbJ21hc3RlckRhdGEnXS5jdXJyZW50VmFsdWUpO1xyXG4gICAgICAgICAgICAgICAgdGhpcy5fZW1pdERhdGEoKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBpZiAoX3NpbXBsZUNoYW5nZS5oYXNPd25Qcm9wZXJ0eSgnc2xhdmVEYXRhJykpIHtcclxuICAgICAgICAgICAgICAgIHRoaXMuX3NsYXZlR3JpZE9wdGlvbnMucm93RGF0YSA9IF9zaW1wbGVDaGFuZ2VbJ3NsYXZlRGF0YSddLmN1cnJlbnRWYWx1ZTtcclxuICAgICAgICAgICAgICAgIHRoaXMuX3NsYXZlR3JpZE9wdGlvbnMuYXBpLnNldFJvd0RhdGEoX3NpbXBsZUNoYW5nZVsnc2xhdmVEYXRhJ10uY3VycmVudFZhbHVlKTtcclxuICAgICAgICAgICAgICAgIHRoaXMuX2VtaXREYXRhKCk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgbmdBZnRlclZpZXdJbml0KCk6IHZvaWQge1xyXG4gICAgICAgIGlmICh0aGlzLl9tYXN0ZXJHcmlkT3B0aW9ucy5yb3dEYXRhLmxlbmd0aCA9PT0gMCkge1xyXG4gICAgICAgICAgICB0aGlzLl9tYXN0ZXJHcmlkT3B0aW9ucy5hcGkuc2hvd05vUm93c092ZXJsYXkoKTtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIGlmICh0aGlzLl9zbGF2ZUdyaWRPcHRpb25zLnJvd0RhdGEubGVuZ3RoID09PSAwKSB7XHJcbiAgICAgICAgICAgIHRoaXMuX3NsYXZlR3JpZE9wdGlvbnMuYXBpLnNob3dOb1Jvd3NPdmVybGF5KCk7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICB0aGlzLl91cGRhdGVOb0RhdGFDbGFzcygpO1xyXG4gICAgICAgIHRoaXMuX21hc3RlckdyaWRPcHRpb25zLmNvbHVtbkFwaS5hdXRvU2l6ZUFsbENvbHVtbnMoKTtcclxuICAgICAgICB0aGlzLl9jb2xEZWZBcnJheVdpZHRoID0gdGhpcy5fYWdncmlkU3ZjLmNhbGNDb2xXaWR0aCh0aGlzLl9tYXN0ZXJHcmlkT3B0aW9ucyk7XHJcblxyXG4gICAgICAgIHRpbWVyKDMwMCkuc3Vic2NyaWJlKCgpOiB2b2lkID0+IHtcclxuICAgICAgICAgICAgdGhpcy5fc2V0VmlldygpO1xyXG4gICAgICAgIH0pO1xyXG5cclxuICAgICAgICB0aGlzLl9maXJzdFJ1biA9IGZhbHNlO1xyXG4gICAgfVxyXG5cclxuICAgIG5nT25EZXN0cm95KCk6IHZvaWQge1xyXG4gICAgICAgIHRoaXMuX3NwbGl0dGVyRHJhZ1N1Yi51bnN1YnNjcmliZSgpO1xyXG4gICAgICAgIHRoaXMuX3NwbGl0dGVyQ2xpY2tTdWIudW5zdWJzY3JpYmUoKTtcclxuICAgIH1cclxuXHJcbiAgICBhc3NpZ24oX3RhcmdldDogc3RyaW5nKTogdm9pZCB7XHJcbiAgICAgICAgaWYgKF90YXJnZXQgPT09ICd0b1RvcCcpIHtcclxuICAgICAgICAgICAgdGhpcy5fdXBkYXRlUm93RGF0YSh0aGlzLl9zbGF2ZUdyaWRPcHRpb25zLCB0aGlzLl9tYXN0ZXJHcmlkT3B0aW9ucyk7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICB0aGlzLl91cGRhdGVSb3dEYXRhKHRoaXMuX21hc3RlckdyaWRPcHRpb25zLCB0aGlzLl9zbGF2ZUdyaWRPcHRpb25zKTtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIGlmICh0aGlzLl9kb21TdmMuaXNNb2JpbGUoKSkge1xyXG4gICAgICAgICAgICB0aGlzLl9zZXRIZWlnaHQodHJ1ZSk7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIHJlc2V0U2VhcmNoKF9lOiBFdmVudCwgX2dyaWQ6IHN0cmluZyk6IHZvaWQge1xyXG4gICAgICAgIF9lLnN0b3BQcm9wYWdhdGlvbigpO1xyXG5cclxuICAgICAgICBsZXQgaXNNb2JpbGU6IGJvb2xlYW4gPSB0aGlzLl9kb21TdmMuaXNNb2JpbGUoKTtcclxuICAgICAgICBsZXQgc2VhcmNoOiBzdHJpbmcgPSAoX2dyaWQgPT09ICd0b3AnKSA/IHRoaXMuX21hc3RlclNlYXJjaCA6IHRoaXMuX3NsYXZlU2VhcmNoO1xyXG5cclxuICAgICAgICBpZiAoaXNNb2JpbGUgJiYgc2VhcmNoLmxlbmd0aCA9PT0gMCkge1xyXG4gICAgICAgICAgICB0aGlzLl9zZWFyY2hTdGF0ZShfZ3JpZCwgJ2NvbGxhcHNlJyk7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICBpZiAoX2dyaWQgPT09ICd0b3AnKSB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLl9tYXN0ZXJTZWFyY2ggPSAnJztcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgICAgIHRoaXMuX3NsYXZlU2VhcmNoID0gJyc7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIHRoaXMuZmlsdGVyQ2hhbmdlZChfZ3JpZCk7XHJcbiAgICB9XHJcblxyXG4gICAgZmlsdGVyQ2hhbmdlZChfZ3JpZDogc3RyaW5nKTogdm9pZCB7XHJcbiAgICAgICAgbGV0IGlzTW9iaWxlOiBib29sZWFuID0gdGhpcy5fZG9tU3ZjLmlzTW9iaWxlKCk7XHJcbiAgICAgICAgbGV0IGdyaWRGaWx0ZXJPcHRpb25zOiBHcmlkT3B0aW9ucztcclxuICAgICAgICBsZXQgc2VhcmNoOiBzdHJpbmcgPSAnJztcclxuXHJcbiAgICAgICAgaWYgKF9ncmlkID09PSAndG9wJykge1xyXG4gICAgICAgICAgICBncmlkRmlsdGVyT3B0aW9ucyA9IHRoaXMuX21hc3RlckdyaWRPcHRpb25zO1xyXG4gICAgICAgICAgICBzZWFyY2ggPSB0aGlzLl9tYXN0ZXJTZWFyY2g7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICBncmlkRmlsdGVyT3B0aW9ucyA9IHRoaXMuX3NsYXZlR3JpZE9wdGlvbnM7XHJcbiAgICAgICAgICAgIHNlYXJjaCA9IHRoaXMuX3NsYXZlU2VhcmNoO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgZ3JpZEZpbHRlck9wdGlvbnMuYXBpLnNldFF1aWNrRmlsdGVyKHNlYXJjaCk7XHJcblxyXG4gICAgICAgIGlmIChpc01vYmlsZSkge1xyXG4gICAgICAgICAgICB0aGlzLl9zZXRIZWlnaHQoaXNNb2JpbGUpO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgdGhpcy5fbXVsdGlUYWJsZVN2Yy5jaGVja092ZXJsYXkodGhpcy5fbWFzdGVyR3JpZE9wdGlvbnMsIHRoaXMuX3NsYXZlR3JpZE9wdGlvbnMpO1xyXG4gICAgfVxyXG5cclxuICAgIHNvcnRHcmlkKCk6IHZvaWQge1xyXG4gICAgICAgIGxldCBzb3J0TW9kZWw6IGFueSA9IHRoaXMuX21hc3RlckdyaWRPcHRpb25zLmFwaS5nZXRTb3J0TW9kZWwoKTtcclxuICAgICAgICB0aGlzLl9zbGF2ZUdyaWRPcHRpb25zLmFwaS5zZXRTb3J0TW9kZWwoc29ydE1vZGVsKTtcclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF9zZXRWaWV3KCk6IHZvaWQge1xyXG4gICAgICAgIGxldCBpc01vYmlsZSA9IHRoaXMuX2RvbVN2Yy5pc01vYmlsZSgpO1xyXG4gICAgICAgIHRoaXMuX3NldFNlYXJjaFN0YXRlKGlzTW9iaWxlKTtcclxuICAgICAgICB0aGlzLl9zZXRDb2xXaWR0aCgpO1xyXG4gICAgICAgIHRoaXMuX3NldEhlaWdodChpc01vYmlsZSk7XHJcbiAgICAgICAgdGhpcy5fc2V0Q2xpY2tTZWFyY2goaXNNb2JpbGUpO1xyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX3NldFNlYXJjaFN0YXRlKF9pc01vYmlsZTogYm9vbGVhbik6IHZvaWQge1xyXG4gICAgICAgIGlmIChfaXNNb2JpbGUpIHtcclxuICAgICAgICAgICAgbGV0IHNlYXJjaDogQXJyYXk8SFRNTEVsZW1lbnQ+ID0gW107XHJcblxyXG4gICAgICAgICAgICBzZWFyY2gucHVzaCh0aGlzLl92Y3IuZWxlbWVudC5uYXRpdmVFbGVtZW50LnF1ZXJ5U2VsZWN0b3IoJy5zZWFyY2gtdGFibGUtdG9wJykpO1xyXG4gICAgICAgICAgICBzZWFyY2gucHVzaCh0aGlzLl92Y3IuZWxlbWVudC5uYXRpdmVFbGVtZW50LnF1ZXJ5U2VsZWN0b3IoJy5zZWFyY2gtdGFibGUtYm90dG9tJykpO1xyXG5cclxuICAgICAgICAgICAgZm9yIChsZXQgaTogbnVtYmVyID0gMDsgaSA8IHNlYXJjaC5sZW5ndGg7IGkrKykge1xyXG4gICAgICAgICAgICAgICAgbGV0IGlzQ3VycmVudFN0YXRlRXhpc3Q6IGJvb2xlYW4gPSBzZWFyY2hbaV0uY2xhc3NMaXN0LmNvbnRhaW5zKCdjb2xsYXBzZS1zZWFyY2gnKSB8fCBzZWFyY2hbaV0uY2xhc3NMaXN0LmNvbnRhaW5zKCdleHBhbmQtc2VhcmNoJyk7XHJcblxyXG4gICAgICAgICAgICAgICAgaWYgKCFpc0N1cnJlbnRTdGF0ZUV4aXN0KSB7XHJcbiAgICAgICAgICAgICAgICAgICAgbGV0IGdyaWQ6IHN0cmluZztcclxuICAgICAgICAgICAgICAgICAgICBsZXQgc2VhcmNoU3RyaW5nOiBzdHJpbmc7XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIGlmIChpID09PSAwKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGdyaWQgPSAndG9wJztcclxuICAgICAgICAgICAgICAgICAgICAgICAgc2VhcmNoU3RyaW5nID0gdGhpcy5fbWFzdGVyU2VhcmNoO1xyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgZ3JpZCA9ICdib3R0b20nO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBzZWFyY2hTdHJpbmcgPSB0aGlzLl9zbGF2ZVNlYXJjaDtcclxuICAgICAgICAgICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIGlmIChzZWFyY2hTdHJpbmcgPT09ICcnKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuX3NlYXJjaFN0YXRlKGdyaWQsICdjb2xsYXBzZScpO1xyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5fc2VhcmNoU3RhdGUoZ3JpZCwgJ2V4cGFuZCcpO1xyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgdGhpcy5fc2VhcmNoU3RhdGUoJ3RvcCcsICdyZXNldCcpO1xyXG4gICAgICAgICAgICB0aGlzLl9zZWFyY2hTdGF0ZSgnYm90dG9tJywgJ3Jlc2V0Jyk7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX3VwZGF0ZU5vRGF0YUNsYXNzKCk6IHZvaWQge1xyXG4gICAgICAgIHRoaXMuX3NldE5vRGF0YSgndG9wJyk7XHJcbiAgICAgICAgdGhpcy5fc2V0Tm9EYXRhKCdib3R0b20nKTtcclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF9zZXROb0RhdGEoX2dyaWQ6IHN0cmluZyk6IHZvaWQge1xyXG4gICAgICAgIGxldCBxdWVyeVN0cmluZzogc3RyaW5nID0gJy5zZWFyY2gtdGFibGUtJyArIF9ncmlkICsgJyBpbnB1dC5zZWFyY2gtJyArIF9ncmlkO1xyXG4gICAgICAgIGxldCBjaGVja0dyaWQ6IEdyaWRPcHRpb25zID0gKF9ncmlkID09PSAndG9wJykgPyB0aGlzLl9tYXN0ZXJHcmlkT3B0aW9ucyA6IHRoaXMuX3NsYXZlR3JpZE9wdGlvbnM7XHJcbiAgICAgICAgbGV0IGlucHV0RWxlOiBIVE1MRWxlbWVudCA9IHRoaXMuX3Zjci5lbGVtZW50Lm5hdGl2ZUVsZW1lbnQucXVlcnlTZWxlY3RvcihxdWVyeVN0cmluZyk7XHJcblxyXG4gICAgICAgIGlmIChjaGVja0dyaWQucm93RGF0YS5sZW5ndGggPT09IDApIHtcclxuICAgICAgICAgICAgdGhpcy5fZG9tU3ZjLmFkZENsYXNzKGlucHV0RWxlLCAnbm8tZGF0YScpO1xyXG4gICAgICAgIH1cclxuICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgdGhpcy5fZG9tU3ZjLnJlbW92ZUNsYXNzKGlucHV0RWxlLCAnbm8tZGF0YScpO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF9zZXRDb2xXaWR0aCgpOiB2b2lkIHtcclxuICAgICAgICBsZXQgdXNhYmxlV2lkdGg6IG51bWJlciA9IHRoaXMuX2FnZ3JpZFN2Yy5jYWxjVXNhYmxlV2lkdGgodGhpcy5fdmNyKTtcclxuXHJcbiAgICAgICAgaWYgKHRoaXMuX21hc3RlckdyaWRPcHRpb25zLmNvbHVtbkFwaSAhPT0gbnVsbCkge1xyXG4gICAgICAgICAgICBsZXQgdG90YWxXaWR0aDogbnVtYmVyID0gdGhpcy5fYWdncmlkU3ZjLmNvbFRvdGFsV2lkdGgodGhpcy5fY29sRGVmQXJyYXlXaWR0aCwgdGhpcy5fbWFzdGVyR3JpZE9wdGlvbnMuY29sdW1uQXBpLmdldEFsbENvbHVtbnMoKSk7XHJcblxyXG4gICAgICAgICAgICBpZiAodGhpcy5fbWFzdGVyR3JpZE9wdGlvbnMuY29sdW1uQXBpICE9PSBudWxsKSB7XHJcbiAgICAgICAgICAgICAgICBsZXQgY29sRGVmOiBBcnJheTxDb2x1bW4+ID0gdGhpcy5fbWFzdGVyR3JpZE9wdGlvbnMuY29sdW1uQXBpLmdldEFsbENvbHVtbnMoKTtcclxuICAgICAgICAgICAgICAgIGxldCBleHRyYVBlckNvbDogbnVtYmVyID0gMDtcclxuXHJcbiAgICAgICAgICAgICAgICBpZiAodG90YWxXaWR0aCA8IHVzYWJsZVdpZHRoKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgbGV0IGxlZnRvdmVyV2lkdGg6IG51bWJlciA9IHVzYWJsZVdpZHRoIC0gdG90YWxXaWR0aDtcclxuICAgICAgICAgICAgICAgICAgICBleHRyYVBlckNvbCA9IGxlZnRvdmVyV2lkdGggLyAodGhpcy5fY29sRGVmQXJyYXlXaWR0aC5sZW5ndGggLSAxKTtcclxuICAgICAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgICAgICBmb3IgKGxldCBpOiBudW1iZXIgPSAwOyBpIDwgdGhpcy5fY29sRGVmQXJyYXlXaWR0aC5sZW5ndGg7IGkrKykge1xyXG4gICAgICAgICAgICAgICAgICAgIGxldCB3aWR0aDogbnVtYmVyID0gKGNvbERlZltpXS5nZXRDb2xJZCgpID09PSAnY2hlY2tib3gnKSA/IHRoaXMuX2NvbERlZkFycmF5V2lkdGhbaV0ud2lkdGggOiB0aGlzLl9jb2xEZWZBcnJheVdpZHRoW2ldLndpZHRoICsgZXh0cmFQZXJDb2w7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5fbWFzdGVyR3JpZE9wdGlvbnMuY29sdW1uQXBpLnNldENvbHVtbldpZHRoKGNvbERlZltpXSwgd2lkdGgpO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX3NldENsaWNrU2VhcmNoKF9pc01vYmlsZTogYm9vbGVhbik6IHZvaWQge1xyXG4gICAgICAgIGxldCB0YWJsZVRvcDogSFRNTEVsZW1lbnQgPSB0aGlzLl92Y3IuZWxlbWVudC5uYXRpdmVFbGVtZW50LnF1ZXJ5U2VsZWN0b3IoJy5zZWFyY2gtdGFibGUtdG9wJyk7XHJcbiAgICAgICAgbGV0IHRhYmxlQm90dG9tOiBIVE1MRWxlbWVudCA9IHRoaXMuX3Zjci5lbGVtZW50Lm5hdGl2ZUVsZW1lbnQucXVlcnlTZWxlY3RvcignLnNlYXJjaC10YWJsZS1ib3R0b20nKTtcclxuXHJcbiAgICAgICAgaWYgKF9pc01vYmlsZSkge1xyXG4gICAgICAgICAgICB0aGlzLl9yZW5kZXJlci5saXN0ZW4odGFibGVUb3AsICdjbGljaycsIChfZTogRXZlbnQpOiB2b2lkID0+IHtcclxuICAgIGlmICh0YWJsZVRvcC5jbGFzc0xpc3QuY29udGFpbnMoJ2NvbGxhcHNlLXNlYXJjaCcpKSB7XHJcbiAgICAgICAgdGhpcy5fc2VhcmNoU3RhdGUoJ3RvcCcsICdleHBhbmQnKTtcclxuICAgIH1cclxufSk7XHJcblxyXG4gICAgICAgICAgICB0aGlzLl9yZW5kZXJlci5saXN0ZW4odGFibGVCb3R0b20sICdjbGljaycsIChfZTogRXZlbnQpOiB2b2lkID0+IHtcclxuICAgIGlmICh0YWJsZUJvdHRvbS5jbGFzc0xpc3QuY29udGFpbnMoJ2NvbGxhcHNlLXNlYXJjaCcpKSB7XHJcbiAgICAgICAgdGhpcy5fc2VhcmNoU3RhdGUoJ2JvdHRvbScsICdleHBhbmQnKTtcclxuICAgIH1cclxufSk7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX3NldEdyaWRPcHRpb25zKCk6IHZvaWQge1xyXG4gICAgICAgIGxldCBzZXR0aW5nczogYW55ID0gdGhpcy5fbXVsdGlUYWJsZVN2Yy5nZXRCb3RoT3B0aW9ucyh0aGlzLmNvbmZpZywgdGhpcy5fbWFzdGVyRGF0YSwgdGhpcy5fc2xhdmVEYXRhKTtcclxuICAgICAgICB0aGlzLl9wcmltYXJ5S2V5ID0gdGhpcy5fbXVsdGlUYWJsZVN2Yy5nZXRQcmltYXJ5a2V5KHRoaXMuY29uZmlnKTtcclxuXHJcbiAgICAgICAgdGhpcy5fbWFzdGVyR3JpZE9wdGlvbnMgPSBzZXR0aW5ncy5tYXN0ZXJHcmlkT3B0aW9uO1xyXG4gICAgICAgIHRoaXMuX3NsYXZlR3JpZE9wdGlvbnMgPSBzZXR0aW5ncy5zbGF2ZUdyaWRPcHRpb247XHJcbiAgICAgICAgdGhpcy5fbWFzdGVyR3JpZE9wdGlvbnMuYWxpZ25lZEdyaWRzID0gW3RoaXMuX3NsYXZlR3JpZE9wdGlvbnNdO1xyXG4gICAgICAgIHRoaXMuX3NsYXZlR3JpZE9wdGlvbnMuYWxpZ25lZEdyaWRzID0gW3RoaXMuX21hc3RlckdyaWRPcHRpb25zXTtcclxuXHJcbiAgICAgICAgdGhpcy5fZGlzYWJsZUJ1dHRvbi50b3AgPSB0cnVlO1xyXG4gICAgICAgIHRoaXMuX2Rpc2FibGVCdXR0b24uYm90dG9tID0gdHJ1ZTtcclxuXHJcbiAgICAgICAgdGhpcy5fcGxhY2Vob2xkZXIudG9wID0gdGhpcy5fbXVsdGlUYWJsZVN2Yy5nZXRQbGFjZWhvbGRlcih0aGlzLmNvbmZpZywgJ3RvcCcpO1xyXG4gICAgICAgIHRoaXMuX3BsYWNlaG9sZGVyLmJvdHRvbSA9IHRoaXMuX211bHRpVGFibGVTdmMuZ2V0UGxhY2Vob2xkZXIodGhpcy5jb25maWcsICdib3R0b20nKTtcclxuXHJcbiAgICAgICAgdGhpcy5fYnV0dG9ucy50b1RvcCA9IHRoaXMuX211bHRpVGFibGVTdmMuZ2V0QnV0dG9uKHRoaXMuY29uZmlnLCAndG9Ub3BCdG4nKTtcclxuICAgICAgICB0aGlzLl9idXR0b25zLnRvQm90dG9tID0gdGhpcy5fbXVsdGlUYWJsZVN2Yy5nZXRCdXR0b24odGhpcy5jb25maWcsICd0b0JvdHRvbUJ0bicpO1xyXG5cclxuICAgICAgICB0aGlzLl9zZXRDb2xEZWZGbG9hdGluZygnbWFzdGVyJyk7XHJcbiAgICAgICAgdGhpcy5fc2V0Q29sRGVmRmxvYXRpbmcoJ3NsYXZlJyk7XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfc2V0Q29sRGVmRmxvYXRpbmcoX2dyaWQ6IHN0cmluZyk6IHZvaWQge1xyXG4gICAgICAgIGxldCBuZXdLZEFnR3JpZFN2YzogS2RBZ2dyaWRTdmMgPSBuZXcgS2RBZ2dyaWRTdmMoKTtcclxuICAgICAgICB0aGlzLl9zZXRGbG9hdGluZ1RvcChfZ3JpZCk7XHJcblxyXG4gICAgICAgIGxldCBnZW5lcmljR3JpZDogR3JpZE9wdGlvbnMgPSAoX2dyaWQgPT09ICdtYXN0ZXInKSA/IHRoaXMuX21hc3RlckdyaWRPcHRpb25zIDogdGhpcy5fc2xhdmVHcmlkT3B0aW9ucztcclxuICAgICAgICBsZXQgY29sRGVmOiBhbnkgPSBuZXdLZEFnR3JpZFN2Yy5zZXRDb2xEZWZzKHRoaXMuY29uZmlnLmNvbERlZiwgZ2VuZXJpY0dyaWQpO1xyXG4gICAgICAgIGNvbERlZi51cGRhdGVkQ29sRGVmLnVuc2hpZnQodGhpcy5fc2V0Q2hlY2tib3goX2dyaWQpKTtcclxuICAgICAgICBnZW5lcmljR3JpZC5jb2x1bW5EZWZzID0gY29sRGVmLnVwZGF0ZWRDb2xEZWY7XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfdXBkYXRlUm93RGF0YShfZnJvbUdyaWQ6IEdyaWRPcHRpb25zLCBfdG9HcmlkOiBHcmlkT3B0aW9ucyk6IHZvaWQge1xyXG4gICAgICAgIGxldCBzZWxlY3RlZE5vZGVzOiBBcnJheTxSb3dOb2RlPiA9IF9mcm9tR3JpZC5hcGkuZ2V0U2VsZWN0ZWROb2RlcygpO1xyXG4gICAgICAgIGxldCBvZmZzZXQ6IG51bWJlciA9IDA7XHJcblxyXG4gICAgICAgIGZvciAobGV0IGk6IG51bWJlciA9IDA7IGkgPCBzZWxlY3RlZE5vZGVzLmxlbmd0aDsgaSsrKSB7XHJcbiAgICAgICAgICAgIHNlbGVjdGVkTm9kZXNbaV0uZGF0YS5uZXdSb3cgPSB0cnVlO1xyXG5cclxuICAgICAgICAgICAgX3RvR3JpZC5yb3dEYXRhLnB1c2goc2VsZWN0ZWROb2Rlc1tpXS5kYXRhKTtcclxuICAgICAgICAgICAgX2Zyb21HcmlkLnJvd0RhdGEuc3BsaWNlKHBhcnNlSW50KHNlbGVjdGVkTm9kZXNbaV0uaWQpIC0gb2Zmc2V0LCAxKTtcclxuXHJcbiAgICAgICAgICAgIG9mZnNldCsrO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgX3RvR3JpZC5hcGkuc2V0Um93RGF0YShfdG9HcmlkLnJvd0RhdGEpO1xyXG4gICAgICAgIF9mcm9tR3JpZC5hcGkuc2V0Um93RGF0YShfZnJvbUdyaWQucm93RGF0YSk7XHJcblxyXG4gICAgICAgIGxldCBuZXdSb3c6IG51bWJlciA9IC0xO1xyXG4gICAgICAgIF90b0dyaWQuYXBpLmZvckVhY2hOb2RlQWZ0ZXJGaWx0ZXIoKF9ub2RlOiBSb3dOb2RlKTogdm9pZCA9PiB7XHJcbiAgICAgICAgICAgIGlmIChzZWxlY3RlZE5vZGVzWzBdLmRhdGFbdGhpcy5fcHJpbWFyeUtleV0gPT09IF9ub2RlLmRhdGFbdGhpcy5fcHJpbWFyeUtleV0pIHtcclxuICAgICAgICAgICAgICAgIG5ld1JvdyA9IF9ub2RlLmNoaWxkSW5kZXg7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9KTtcclxuXHJcbiAgICAgICAgX3RvR3JpZC5hcGkuZW5zdXJlSW5kZXhWaXNpYmxlKG5ld1Jvdyk7XHJcblxyXG4gICAgICAgIHRoaXMuX2Rpc2FibGVCdXR0b24gPSB0aGlzLl9tdWx0aVRhYmxlU3ZjLmNoZWNrU2VsZWN0aW9uKHRoaXMuX21hc3RlckdyaWRPcHRpb25zLCB0aGlzLl9zbGF2ZUdyaWRPcHRpb25zKTtcclxuICAgICAgICB0aGlzLl91cGRhdGVOb0RhdGFDbGFzcygpO1xyXG4gICAgICAgIHRoaXMuX3NldENoZWNrYm94QWZ0ZXJVcGRhdGUoKTtcclxuICAgICAgICB0aGlzLl9lbWl0RGF0YSgpO1xyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX3NldENoZWNrYm94QWZ0ZXJVcGRhdGUoKTogdm9pZCB7XHJcbiAgICAgICAgdGhpcy5fbWFzdGVyU2VsZWN0QWxsID0gZmFsc2U7XHJcbiAgICAgICAgdGhpcy5fc2xhdmVTZWxlY3RBbGwgPSBmYWxzZTtcclxuICAgICAgICB0aGlzLl9tdWx0aVRhYmxlU3ZjLnNldENoZWNrYm94RmFsc2VBZnRlclVwZGF0ZSh0aGlzLl92Y3IpO1xyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX2VtaXREYXRhKCk6IHZvaWQge1xyXG4gICAgICAgIGxldCBjdXJyZW50U2VsZWN0aW9uOiBhbnkgPSB7fTtcclxuICAgICAgICBjdXJyZW50U2VsZWN0aW9uLnRvcEdyaWQgPSB0aGlzLl9tYXN0ZXJHcmlkT3B0aW9ucy5yb3dEYXRhO1xyXG4gICAgICAgIGN1cnJlbnRTZWxlY3Rpb24uYm90dG9tR3JpZCA9IHRoaXMuX3NsYXZlR3JpZE9wdGlvbnMucm93RGF0YTtcclxuICAgICAgICB0aGlzLnRvcEJvdHRvbURhdGEuZW1pdChjdXJyZW50U2VsZWN0aW9uKTtcclxuICAgIH1cclxuXHJcbiAgICAvLyBwcml2YXRlIF9nZXRSb3dEYXRhKCk6IHZvaWQge1xyXG5cclxuICAgIC8vIH1cclxuXHJcbiAgICBwcml2YXRlIF9zZXRGbG9hdGluZ1RvcChfZ3JpZDogc3RyaW5nKTogdm9pZCB7XHJcbiAgICAgICAgbGV0IGdyaWRPcHRpb25zOiBHcmlkT3B0aW9ucztcclxuICAgICAgICBsZXQgc2VsZWN0QWxsQ2hlY2s6IGJvb2xlYW47XHJcblxyXG4gICAgICAgIGlmIChfZ3JpZCA9PT0gJ21hc3RlcicpIHtcclxuICAgICAgICAgICAgZ3JpZE9wdGlvbnMgPSB0aGlzLl9tYXN0ZXJHcmlkT3B0aW9ucztcclxuICAgICAgICAgICAgc2VsZWN0QWxsQ2hlY2sgPSB0aGlzLl9tYXN0ZXJTZWxlY3RBbGw7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICBncmlkT3B0aW9ucyA9IHRoaXMuX3NsYXZlR3JpZE9wdGlvbnM7XHJcbiAgICAgICAgICAgIHNlbGVjdEFsbENoZWNrID0gdGhpcy5fc2xhdmVTZWxlY3RBbGw7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICBncmlkT3B0aW9ucy5waW5uZWRUb3BSb3dEYXRhID0gW3tmdWxsV2lkdGg6IHRydWV9XTtcclxuICAgICAgICBncmlkT3B0aW9ucy5pc0Z1bGxXaWR0aENlbGwgPSAoX3Jvd05vZGU6IFJvd05vZGUpOiBib29sZWFuID0+IHtcclxuICAgICAgICAgICAgaWYgKHR5cGVvZiBfcm93Tm9kZS5kYXRhLmZ1bGxXaWR0aCAhPT0gJ3VuZGVmaW5lZCcpIHtcclxuICAgICAgICAgICAgICAgIHJldHVybiBfcm93Tm9kZS5kYXRhLmZ1bGxXaWR0aDtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICByZXR1cm4gZmFsc2U7XHJcbiAgICAgICAgfTtcclxuXHJcbiAgICAgICAgZ3JpZE9wdGlvbnMuZnVsbFdpZHRoQ2VsbFJlbmRlcmVyID0gKHBhcmFtczogYW55KTogSFRNTEVsZW1lbnQgPT4ge1xyXG4gICAgICAgICAgICBsZXQgcGFyZW50V3JhcHBlcjogSFRNTEVsZW1lbnQgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdkaXYnKTtcclxuICAgICAgICAgICAgbGV0IGNoZWNrYm94V3JhcHBlcjogSFRNTERpdkVsZW1lbnQgPSB0aGlzLl9kb21TdmMuY3JlYXRlRWxlbWVudChwYXJlbnRXcmFwcGVyLCAnc2VsZWN0aW9uLXdyYXBwZXIgc2VsZWN0LWFsbCcsICdkaXYnKTtcclxuICAgICAgICAgICAgbGV0IGNoZWNrYm94OiBIVE1MSW5wdXRFbGVtZW50ID0gdGhpcy5fZG9tU3ZjLmNyZWF0ZUVsZW1lbnQoY2hlY2tib3hXcmFwcGVyLCAnc2VsZWN0LWFsbCcsICdpbnB1dCcpO1xyXG5cclxuICAgICAgICAgICAgY2hlY2tib3gudHlwZSA9ICdjaGVja2JveCc7XHJcblxyXG4gICAgICAgICAgICB0aGlzLl9kb21TdmMuY3JlYXRlRWxlbWVudChjaGVja2JveFdyYXBwZXIsICdsYWJlbCcsICdsYWJlbCcpO1xyXG4gICAgICAgICAgICBjaGVja2JveFdyYXBwZXIuYWRkRXZlbnRMaXN0ZW5lcignY2hhbmdlJywgKCk6IHZvaWQgPT4ge1xyXG4gICAgICAgICAgICAgICAgbGV0IGlzQ2hlY2tlZDogYm9vbGVhbiA9IGNoZWNrYm94LmNoZWNrZWQ7XHJcbiAgICAgICAgICAgICAgICB0aGlzLl9jaGVja1NlbGVjdEFsbEJveChwYXJhbXMsIF9ncmlkLCBpc0NoZWNrZWQpO1xyXG4gICAgICAgICAgICB9KTtcclxuXHJcbiAgICAgICAgICAgIGlmIChzZWxlY3RBbGxDaGVjaykge1xyXG4gICAgICAgICAgICAgICAgY2hlY2tib3guY2hlY2tlZCA9IHRydWU7XHJcbiAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgIGxldCBkaXNwbGF5RGF0YTogSFRNTERpdkVsZW1lbnQgPSB0aGlzLl9kb21TdmMuY3JlYXRlRWxlbWVudChwYXJlbnRXcmFwcGVyLCAnY2hlY2tib3gtdGV4dCcsICdkaXYnKTtcclxuICAgICAgICAgICAgbGV0IHBUYWc6IEhUTUxEaXZFbGVtZW50ID0gdGhpcy5fZG9tU3ZjLmNyZWF0ZUVsZW1lbnQoZGlzcGxheURhdGEsICdjaGVjay1kYXRhJywgJ2RpdicpO1xyXG4gICAgICAgICAgICBsZXQgZGF0YSA9IGdyaWRPcHRpb25zLmFwaS5nZXRNb2RlbCgpLmdldFJvd0NvdW50KCk7XHJcbiAgICAgICAgICAgIHBUYWcuaW5uZXJIVE1MID0gJ1NlbGVjdCBhbGwgJyArIGRhdGEgKyAnIHJlc3VsdHMnO1xyXG5cclxuICAgICAgICAgICAgcmV0dXJuIHBhcmVudFdyYXBwZXI7XHJcbiAgICAgICAgfTtcclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF9zZXRIZWlnaHQoX2lzTW9iaWxlOiBib29sZWFuKTogdm9pZCB7XHJcbiAgICAgICAgbGV0IGhlaWdodDogYW55O1xyXG5cclxuICAgICAgICBpZiAoX2lzTW9iaWxlKSB7XHJcbiAgICAgICAgICAgIGhlaWdodCA9IHRoaXMuX211bHRpVGFibGVTdmMuY2FsY01vYmlsZUhlaWdodCh0aGlzLl9tYXN0ZXJHcmlkT3B0aW9ucywgdGhpcy5fc2xhdmVHcmlkT3B0aW9ucywgdGhpcy5fdmNyKTtcclxuICAgICAgICB9XHJcbiAgICAgICAgZWxzZSB7XHJcbiAgICAgICAgICAgIGhlaWdodCA9IHRoaXMuX211bHRpVGFibGVTdmMuY2FsY1dlYkhlaWdodCh0aGlzLmNvbmZpZy5oZWlnaHQpO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgdGhpcy5fc2V0R3JpZEhlaWdodCgnbWFzdGVyJywgaGVpZ2h0KTtcclxuICAgICAgICB0aGlzLl9zZXRHcmlkSGVpZ2h0KCdzbGF2ZScsIGhlaWdodCk7XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfc2V0R3JpZEhlaWdodChfZ3JpZDogc3RyaW5nLCBfaGVpZ2h0OiBhbnkpOiB2b2lkIHtcclxuICAgICAgICBsZXQgcXVlcnlTdHJpbmc6IHN0cmluZyA9ICcuc3RnLXRoZW1lLicgKyBfZ3JpZDtcclxuICAgICAgICBsZXQgZ3JpZEhlaWdodDogc3RyaW5nO1xyXG4gICAgICAgIGxldCBodG1sRWxlOiBIVE1MRWxlbWVudCA9IHRoaXMuX3Zjci5lbGVtZW50Lm5hdGl2ZUVsZW1lbnQucXVlcnlTZWxlY3RvcihxdWVyeVN0cmluZyk7XHJcblxyXG4gICAgICAgIGlmIChfZ3JpZCA9PT0gJ21hc3RlcicpIHtcclxuICAgICAgICAgICAgZ3JpZEhlaWdodCA9IF9oZWlnaHQudG9wICsgJ3B4JztcclxuICAgICAgICB9XHJcbiAgICAgICAgZWxzZSB7XHJcbiAgICAgICAgICAgIGdyaWRIZWlnaHQgPSBfaGVpZ2h0LmJvdHRvbSArICdweCc7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICB0aGlzLl9kb21TdmMuc2V0RWxlbWVudFN0eWxlKGh0bWxFbGUsICdoZWlnaHQnLCBncmlkSGVpZ2h0KTtcclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF9zZXRDaGVja2JveChfZ3JpZDogc3RyaW5nKTogYW55IHtcclxuICAgICAgICBsZXQgY2hlY2tib3hTZXR0aW5nOiBhbnkgPSB0aGlzLl9tdWx0aVRhYmxlU3ZjLmdldENoZWNrYm94RGVmYXVsdCgpO1xyXG4gICAgICAgIGNoZWNrYm94U2V0dGluZy5waW5uZWQgPSAgdGhpcy5fZGlyZWN0aW9uO1xyXG4gICAgICAgIGNoZWNrYm94U2V0dGluZy5jZWxsQ2xhc3MgPSAnYWctY2hlY2tib3gtcmFkaW8nO1xyXG4gICAgICAgIGNoZWNrYm94U2V0dGluZy5jZWxsUmVuZGVyZXIgPSAoX3BhcmFtczogYW55KTogSFRNTEVsZW1lbnQgPT4gdGhpcy5fc2V0Q2VsbFJlbmRlcmluZyhfcGFyYW1zLCBfZ3JpZCk7XHJcblxyXG4gICAgICAgIHJldHVybiBjaGVja2JveFNldHRpbmc7XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfc2V0Q2VsbFJlbmRlcmluZyhwYXJhbXM6IGFueSwgZ3JpZDogc3RyaW5nKTogSFRNTEVsZW1lbnQge1xyXG4gICAgICAgIGxldCBoZWFkZXI6IEhUTUxEaXZFbGVtZW50ID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnZGl2Jyk7XHJcbiAgICAgICAgbGV0IGlucHV0OiBIVE1MSW5wdXRFbGVtZW50ID0gdGhpcy5fZG9tU3ZjLmNyZWF0ZUVsZW1lbnQoaGVhZGVyLCAnY2hlY2tib3gnLCAnaW5wdXQnKTtcclxuICAgICAgICB0aGlzLl9kb21TdmMuY3JlYXRlRWxlbWVudChoZWFkZXIsICdsYWJlbCcsICdsYWJlbCcpO1xyXG4gICAgICAgIGxldCBncmlkT3B0aW9uczogR3JpZE9wdGlvbnMgPSAoZ3JpZCA9PT0gJ21hc3RlcicpID8gdGhpcy5fbWFzdGVyR3JpZE9wdGlvbnMgOiB0aGlzLl9zbGF2ZUdyaWRPcHRpb25zO1xyXG4gICAgICAgIGxldCBjdXJyZW50Tm9kZTogUm93Tm9kZSA9IGdyaWRPcHRpb25zLmFwaS5nZXRNb2RlbCgpLmdldFJvdyhwYXJhbXMucm93SW5kZXgpO1xyXG4gICAgICAgIGlucHV0LnR5cGUgPSAnY2hlY2tib3gnO1xyXG4gICAgICAgIGhlYWRlci5jbGFzc05hbWUgPSAnc2VsZWN0aW9uLXdyYXBwZXInO1xyXG4gICAgICAgIGhlYWRlci5hZGRFdmVudExpc3RlbmVyKCdjaGFuZ2UnLCAoJGV2ZW50KTogdm9pZCA9PiB7XHJcbiAgICAgICAgICAgIGN1cnJlbnROb2RlLnNlbGVjdFRoaXNOb2RlKGlucHV0LmNoZWNrZWQpO1xyXG4gICAgICAgICAgICB0aGlzLl9jaGVja1NlbGVjdEJveChwYXJhbXMsIGdyaWQpO1xyXG4gICAgICAgIH0pO1xyXG4gICAgICAgIGlmIChjdXJyZW50Tm9kZS5pc1NlbGVjdGVkKCkpIGlucHV0LmNoZWNrZWQgPSB0cnVlO1xyXG5cclxuICAgICAgICByZXR1cm4gaGVhZGVyO1xyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX2NoZWNrU2VsZWN0Qm94KHBhcmFtczogYW55LCBncmlkOiBzdHJpbmcpOiB2b2lkIHtcclxuICAgICAgICBsZXQgZ3JpZE9wdGlvbnM6IEdyaWRPcHRpb25zID0gKGdyaWQgPT09ICdtYXN0ZXInKSA/IHRoaXMuX21hc3RlckdyaWRPcHRpb25zIDogdGhpcy5fc2xhdmVHcmlkT3B0aW9ucztcclxuICAgICAgICBsZXQgc2VsZWN0QWxsOiBib29sZWFuID0gKGdyaWQgPT09ICdtYXN0ZXInKSA/IHRoaXMuX21hc3RlclNlbGVjdEFsbCA6IHRoaXMuX3NsYXZlU2VsZWN0QWxsO1xyXG4gICAgICAgIGxldCBxdWVyeVN0cmluZzogc3RyaW5nID0gJyMnICsgZ3JpZCArICcgLnNlbGVjdC1hbGwgaW5wdXQnO1xyXG4gICAgICAgIGxldCByb3dNb2RlbENvdW50ID0gZ3JpZE9wdGlvbnMuYXBpLmdldE1vZGVsKCkuZ2V0Um93Q291bnQoKTtcclxuICAgICAgICBsZXQgc2VsZWN0ZWROb2Rlc0NvdW50ID0gZ3JpZE9wdGlvbnMuYXBpLmdldFNlbGVjdGVkTm9kZXMoKS5sZW5ndGg7XHJcbiAgICAgICAgc2VsZWN0QWxsID0gKHJvd01vZGVsQ291bnQgPT09IHNlbGVjdGVkTm9kZXNDb3VudCk7XHJcblxyXG4gICAgICAgIGlmIChncmlkID09PSAnbWFzdGVyJykgdGhpcy5fbWFzdGVyU2VsZWN0QWxsID0gc2VsZWN0QWxsO1xyXG4gICAgICAgIGVsc2UgdGhpcy5fc2xhdmVTZWxlY3RBbGwgPSBzZWxlY3RBbGw7XHJcblxyXG4gICAgICAgIHRoaXMuX3Zjci5lbGVtZW50Lm5hdGl2ZUVsZW1lbnQucXVlcnlTZWxlY3RvcihxdWVyeVN0cmluZykuY2hlY2tlZCA9IHNlbGVjdEFsbDtcclxuICAgICAgICB0aGlzLl91cGRhdGVTZWxlY3Rpb24oZ3JpZCk7XHJcbiAgICAgICAgdGhpcy5fZGlzYWJsZUJ1dHRvbiA9IHRoaXMuX211bHRpVGFibGVTdmMuY2hlY2tTZWxlY3Rpb24odGhpcy5fbWFzdGVyR3JpZE9wdGlvbnMsIHRoaXMuX3NsYXZlR3JpZE9wdGlvbnMpO1xyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX2NoZWNrU2VsZWN0QWxsQm94KHBhcmFtczogYW55LCBncmlkOiBzdHJpbmcsIGlzQ2hlY2tlZDogYm9vbGVhbik6IHZvaWQge1xyXG4gICAgICAgIGxldCBlbGVDbGFzczogc3RyaW5nID0gJyMnICsgZ3JpZCArICgodGhpcy5fZGlyZWN0aW9uID09PSAnbGVmdCcpID8gJyAuYWctcGlubmVkLWxlZnQtY29scy1jb250YWluZXInIDogJyAuYWctcGlubmVkLXJpZ2h0LWNvbHMtY29udGFpbmVyJyk7XHJcbiAgICAgICAgbGV0IGJvZHlDb250YWluZXI6IEhUTUxFbGVtZW50ID0gdGhpcy5fdmNyLmVsZW1lbnQubmF0aXZlRWxlbWVudC5xdWVyeVNlbGVjdG9yKGVsZUNsYXNzKTtcclxuICAgICAgICBsZXQgaW5wdXRFbGU6IE5vZGVMaXN0T2Y8YW55PiA9IGJvZHlDb250YWluZXIucXVlcnlTZWxlY3RvckFsbCgnLnNlbGVjdGlvbi13cmFwcGVyIGlucHV0Jyk7XHJcbiAgICAgICAgbGV0IGdyaWRPcHRpb25zOiBHcmlkT3B0aW9ucyA9IChncmlkID09PSAnbWFzdGVyJykgPyB0aGlzLl9tYXN0ZXJHcmlkT3B0aW9ucyA6IHRoaXMuX3NsYXZlR3JpZE9wdGlvbnM7XHJcbiAgICAgICAgbGV0IG1vZGVsQXBpOiBJUm93TW9kZWwgPSBncmlkT3B0aW9ucy5hcGkuZ2V0TW9kZWwoKTtcclxuXHJcbiAgICAgICAgaWYgKGdyaWQgPT09ICdtYXN0ZXInKSB0aGlzLl9tYXN0ZXJTZWxlY3RBbGwgPSBpc0NoZWNrZWQ7XHJcbiAgICAgICAgZWxzZSB0aGlzLl9zbGF2ZVNlbGVjdEFsbCA9IGlzQ2hlY2tlZDtcclxuXHJcbiAgICAgICAgbGV0IHNlbGVjdEFsbDogYm9vbGVhbiA9IChncmlkID09PSAnbWFzdGVyJykgPyB0aGlzLl9tYXN0ZXJTZWxlY3RBbGwgOiB0aGlzLl9zbGF2ZVNlbGVjdEFsbDtcclxuICAgICAgICBmb3IgKGxldCBpOiBudW1iZXIgPSAwOyBpIDwgbW9kZWxBcGkuZ2V0Um93Q291bnQoKTsgaSsrKSB7XHJcbiAgICAgICAgICAgIG1vZGVsQXBpLmdldFJvdyhpKS5zZWxlY3RUaGlzTm9kZShzZWxlY3RBbGwpO1xyXG4gICAgICAgICAgICBpZiAodHlwZW9mIGlucHV0RWxlW2ldICE9PSAndW5kZWZpbmVkJykgaW5wdXRFbGVbaV0uY2hlY2tlZCA9IHNlbGVjdEFsbDtcclxuICAgICAgICB9XHJcbiAgICAgICAgdGhpcy5fdXBkYXRlU2VsZWN0aW9uKGdyaWQpO1xyXG4gICAgICAgIHRoaXMuX2Rpc2FibGVCdXR0b24gPSB0aGlzLl9tdWx0aVRhYmxlU3ZjLmNoZWNrU2VsZWN0aW9uKHRoaXMuX21hc3RlckdyaWRPcHRpb25zLCB0aGlzLl9zbGF2ZUdyaWRPcHRpb25zKTtcclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF91cGRhdGVTZWxlY3Rpb24oY2hlY2tlZEdyaWQ6IHN0cmluZyk6IHZvaWQge1xyXG4gICAgICAgIGxldCBxdWVyeVN0cmluZzogc3RyaW5nID0gKGNoZWNrZWRHcmlkID09PSAnbWFzdGVyJykgPyAnI3NsYXZlIC5zZWxlY3Rpb24td3JhcHBlciBpbnB1dCcgOiAnI21hc3RlciAuc2VsZWN0aW9uLXdyYXBwZXIgaW5wdXQnO1xyXG4gICAgICAgIGxldCBhbGxFbGVtZW50OiBBcnJheTxhbnk+ID0gdGhpcy5fdmNyLmVsZW1lbnQubmF0aXZlRWxlbWVudC5xdWVyeVNlbGVjdG9yQWxsKHF1ZXJ5U3RyaW5nKTtcclxuICAgICAgICB0aGlzLl9tdWx0aVRhYmxlU3ZjLnNldENoZWNrYm94RmFsc2UoYWxsRWxlbWVudCk7XHJcbiAgICAgICAgaWYgKGNoZWNrZWRHcmlkID09PSAnbWFzdGVyJykge1xyXG4gICAgICAgICAgICB0aGlzLl9zbGF2ZUdyaWRPcHRpb25zLmFwaS5kZXNlbGVjdEFsbCgpO1xyXG4gICAgICAgICAgICB0aGlzLl9zbGF2ZVNlbGVjdEFsbCA9IGZhbHNlO1xyXG4gICAgICAgIH1cclxuICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgdGhpcy5fbWFzdGVyR3JpZE9wdGlvbnMuYXBpLmRlc2VsZWN0QWxsKCk7XHJcbiAgICAgICAgICAgIHRoaXMuX21hc3RlclNlbGVjdEFsbCA9IGZhbHNlO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF9zZWFyY2hTdGF0ZShncmlkOiBzdHJpbmcsIHN0YXRlOiBzdHJpbmcpOiB2b2lkIHtcclxuICAgICAgICBsZXQgcXVlcnlTdHJpbmc6IHN0cmluZyA9ICcuc2VhcmNoLXRhYmxlLScgKyBncmlkO1xyXG4gICAgICAgIGxldCByZW5kZXJHcmlkOiBIVE1MRWxlbWVudCA9IHRoaXMuX3Zjci5lbGVtZW50Lm5hdGl2ZUVsZW1lbnQucXVlcnlTZWxlY3RvcihxdWVyeVN0cmluZyk7XHJcbiAgICAgICAgaWYgKHN0YXRlID09PSAnY29sbGFwc2UnKSB7XHJcbiAgICAgICAgICAgIHRoaXMuX2RvbVN2Yy5hZGRDbGFzcyhyZW5kZXJHcmlkLCAnY29sbGFwc2Utc2VhcmNoJyk7XHJcbiAgICAgICAgICAgIHRoaXMuX2RvbVN2Yy5yZW1vdmVDbGFzcyhyZW5kZXJHcmlkLCAnZXhwYW5kLXNlYXJjaCcpO1xyXG4gICAgICAgIH1cclxuICAgICAgICBlbHNlIGlmIChzdGF0ZSA9PT0gJ2V4cGFuZCcpIHtcclxuICAgICAgICAgICAgdGhpcy5fZG9tU3ZjLmFkZENsYXNzKHJlbmRlckdyaWQsICdleHBhbmQtc2VhcmNoJyk7XHJcbiAgICAgICAgICAgIHRoaXMuX2RvbVN2Yy5yZW1vdmVDbGFzcyhyZW5kZXJHcmlkLCAnY29sbGFwc2Utc2VhcmNoJyk7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIC8vICdyZXNldCdcclxuICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgdGhpcy5fZG9tU3ZjLnJlbW92ZUNsYXNzKHJlbmRlckdyaWQsICdleHBhbmQtc2VhcmNoJyk7XHJcbiAgICAgICAgICAgIHRoaXMuX2RvbVN2Yy5yZW1vdmVDbGFzcyhyZW5kZXJHcmlkLCAnY29sbGFwc2Utc2VhcmNoJyk7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG59XHJcbiJdfQ==