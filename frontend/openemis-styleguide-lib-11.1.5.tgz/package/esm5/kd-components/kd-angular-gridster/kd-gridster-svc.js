import { __decorate, __metadata } from "tslib";
import { Injectable } from '@angular/core';
import { KdBroadcaster } from '../kd-common/index';
var KdGridsterSvc = /** @class */ (function () {
    function KdGridsterSvc(broadcaster) {
        this.broadcaster = broadcaster;
    }
    KdGridsterSvc.prototype.setEmitter = function (gridsterItemResizeEmitter, getGridsterItemEmitter) {
        this.gridsterItemResizeEmitter = gridsterItemResizeEmitter;
        this.getGridsterItem = getGridsterItemEmitter;
    };
    /**
     * generate default gridster config
     *  default gridster config
     */
    KdGridsterSvc.prototype.getDefaultGridsterConfig = function () {
        return {
            // gridster plugin property
            gridType: 'scrollVertical',
            mobileBreakpoint: 0,
            defaultItemCols: 20,
            defaultItemRows: 10,
            draggable: {
                enabled: true,
                ignoreContentClass: 'no-drag',
            },
            resizable: {
                enabled: true,
            },
            pushItems: false,
            disablePushOnDrag: true,
            disablePushOnResize: true,
            pushResizeItems: false,
            pushDirections: { north: false, east: false, south: false, west: false },
            displayGrid: 'onDrag&Resize',
            scrollToNewItems: true,
            disableAutoPositionOnConflict: true,
            setGridSize: false,
            minCols: 100,
            maxCols: 100,
            maxRows: 100,
            // add-on property
            border: false,
            enableEditMode: false,
            hideDragButtons: false,
            hideCustomButtons: false,
            setFixCenter: false,
            enableDowngrade: false,
            buttons: []
        };
    };
    /**
     * return combination of default gridster config and user define config
     *    _config  config from user/application
     *             [description]
     */
    KdGridsterSvc.prototype.getConfig = function (_config) {
        var _this = this;
        if (typeof _config === 'undefined')
            _config = {};
        var gridsterDefaultConfig = this.getDefaultGridsterConfig();
        gridsterDefaultConfig.itemInitCallback = function (item, itemComponent) { return _this._onItemInit(item, itemComponent); };
        gridsterDefaultConfig.itemResizeCallback = function (item, itemComponent) { return _this._onItemResize(item, itemComponent); };
        return Object.assign({}, gridsterDefaultConfig, _config);
    };
    KdGridsterSvc.prototype._onItemInit = function (_item, _itemComponent) {
        // console.log('_onItemInit', JSON.stringify(_item));
        _itemComponent.el.className += ' kdx-display-box';
        _item.isDoneInit = true;
        this.getGridsterItem.emit(_item);
        this._gridsterItemInit(_item);
    };
    KdGridsterSvc.prototype._onItemResize = function (_item, _itemComponent) {
        if (!_item.isDoneInit) {
            this._gridsterItemResize(_item);
            this.gridsterItemResizeEmitter.emit(_item);
        }
        else {
            _item.isDoneInit = false;
        }
    };
    KdGridsterSvc.prototype.onGridsterItemInit = function () {
        return this.broadcaster.on('KdGridsterEvent_onItemInit');
    };
    KdGridsterSvc.prototype._gridsterItemInit = function (_item) {
        this.broadcaster.broadcast('KdGridsterEvent_onItemInit', _item);
    };
    KdGridsterSvc.prototype.onGridsterItemResize = function () {
        return this.broadcaster.on('KdGridsterEvent_onItemResize');
    };
    KdGridsterSvc.prototype._gridsterItemResize = function (_item) {
        this.broadcaster.broadcast('KdGridsterEvent_onItemResize', _item);
    };
    KdGridsterSvc.prototype.onGridsterRemoved = function () {
        return this.broadcaster.on('KdGridsterEvent_onRemoved');
    };
    KdGridsterSvc.prototype.gridsterRemoved = function () {
        this.broadcaster.broadcast('KdGridsterEvent_onRemoved');
    };
    KdGridsterSvc.ctorParameters = function () { return [
        { type: KdBroadcaster }
    ]; };
    KdGridsterSvc = __decorate([
        Injectable(),
        __metadata("design:paramtypes", [KdBroadcaster])
    ], KdGridsterSvc);
    return KdGridsterSvc;
}());
export { KdGridsterSvc };
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoia2QtZ3JpZHN0ZXItc3ZjLmpzIiwic291cmNlUm9vdCI6Im5nOi8vb3BlbmVtaXMtc3R5bGVndWlkZS1saWIvIiwic291cmNlcyI6WyJrZC1jb21wb25lbnRzL2tkLWFuZ3VsYXItZ3JpZHN0ZXIva2QtZ3JpZHN0ZXItc3ZjLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7QUFBQSxPQUFPLEVBQUUsVUFBVSxFQUFnQixNQUFNLGVBQWUsQ0FBQztBQU96RCxPQUFPLEVBQUUsYUFBYSxFQUFFLE1BQU0sb0JBQW9CLENBQUM7QUFJbkQ7SUFLSSx1QkFBb0IsV0FBMEI7UUFBMUIsZ0JBQVcsR0FBWCxXQUFXLENBQWU7SUFBSSxDQUFDO0lBRTVDLGtDQUFVLEdBQWpCLFVBQWtCLHlCQUFxRCxFQUFFLHNCQUFrRDtRQUN2SCxJQUFJLENBQUMseUJBQXlCLEdBQUcseUJBQXlCLENBQUM7UUFDM0QsSUFBSSxDQUFDLGVBQWUsR0FBRyxzQkFBc0IsQ0FBQztJQUNsRCxDQUFDO0lBRUQ7OztPQUdHO0lBQ0ssZ0RBQXdCLEdBQWhDO1FBQ0ksT0FBTztZQUNILDJCQUEyQjtZQUMzQixRQUFRLEVBQUUsZ0JBQWdCO1lBQzFCLGdCQUFnQixFQUFFLENBQUM7WUFDbkIsZUFBZSxFQUFFLEVBQUU7WUFDbkIsZUFBZSxFQUFFLEVBQUU7WUFDbkIsU0FBUyxFQUFFO2dCQUNQLE9BQU8sRUFBRSxJQUFJO2dCQUNiLGtCQUFrQixFQUFFLFNBQVM7YUFDaEM7WUFDRCxTQUFTLEVBQUU7Z0JBQ1AsT0FBTyxFQUFFLElBQUk7YUFDaEI7WUFDRCxTQUFTLEVBQUUsS0FBSztZQUNoQixpQkFBaUIsRUFBRSxJQUFJO1lBQ3ZCLG1CQUFtQixFQUFFLElBQUk7WUFDekIsZUFBZSxFQUFFLEtBQUs7WUFDdEIsY0FBYyxFQUFFLEVBQUUsS0FBSyxFQUFFLEtBQUssRUFBRSxJQUFJLEVBQUUsS0FBSyxFQUFFLEtBQUssRUFBRSxLQUFLLEVBQUUsSUFBSSxFQUFFLEtBQUssRUFBRTtZQUN4RSxXQUFXLEVBQUUsZUFBZTtZQUM1QixnQkFBZ0IsRUFBRSxJQUFJO1lBQ3RCLDZCQUE2QixFQUFFLElBQUk7WUFDbkMsV0FBVyxFQUFFLEtBQUs7WUFDbEIsT0FBTyxFQUFFLEdBQUc7WUFDWixPQUFPLEVBQUUsR0FBRztZQUNaLE9BQU8sRUFBRSxHQUFHO1lBRVosa0JBQWtCO1lBQ2xCLE1BQU0sRUFBRSxLQUFLO1lBQ2IsY0FBYyxFQUFFLEtBQUs7WUFDckIsZUFBZSxFQUFFLEtBQUs7WUFDdEIsaUJBQWlCLEVBQUUsS0FBSztZQUN4QixZQUFZLEVBQUUsS0FBSztZQUNuQixlQUFlLEVBQUUsS0FBSztZQUN0QixPQUFPLEVBQUUsRUFBRTtTQUNkLENBQUM7SUFDTixDQUFDO0lBRUQ7Ozs7T0FJRztJQUNJLGlDQUFTLEdBQWhCLFVBQWlCLE9BQXdCO1FBQXpDLGlCQVVDO1FBVEcsSUFBSSxPQUFPLE9BQU8sS0FBSyxXQUFXO1lBQUUsT0FBTyxHQUFHLEVBQUUsQ0FBQztRQUVqRCxJQUFJLHFCQUFxQixHQUFtQixJQUFJLENBQUMsd0JBQXdCLEVBQUUsQ0FBQztRQUU1RSxxQkFBcUIsQ0FBQyxnQkFBZ0IsR0FBRyxVQUFDLElBQWtCLEVBQUUsYUFBNkMsSUFBSyxPQUFBLEtBQUksQ0FBQyxXQUFXLENBQUMsSUFBSSxFQUFFLGFBQWEsQ0FBQyxFQUFyQyxDQUFxQyxDQUFDO1FBRXRKLHFCQUFxQixDQUFDLGtCQUFrQixHQUFHLFVBQUMsSUFBa0IsRUFBRSxhQUE2QyxJQUFLLE9BQUEsS0FBSSxDQUFDLGFBQWEsQ0FBQyxJQUFJLEVBQUUsYUFBYSxDQUFDLEVBQXZDLENBQXVDLENBQUM7UUFFMUosT0FBeUIsTUFBTyxDQUFDLE1BQU0sQ0FBQyxFQUFFLEVBQUUscUJBQXFCLEVBQUUsT0FBTyxDQUFDLENBQUM7SUFDaEYsQ0FBQztJQUVPLG1DQUFXLEdBQW5CLFVBQW9CLEtBQW1CLEVBQUUsY0FBOEM7UUFDbkYscURBQXFEO1FBQ3JELGNBQWMsQ0FBQyxFQUFFLENBQUMsU0FBUyxJQUFJLGtCQUFrQixDQUFDO1FBQ2xELEtBQUssQ0FBQyxVQUFVLEdBQUcsSUFBSSxDQUFDO1FBQ3hCLElBQUksQ0FBQyxlQUFlLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFDO1FBQ2pDLElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxLQUFLLENBQUMsQ0FBQztJQUNsQyxDQUFDO0lBRU8scUNBQWEsR0FBckIsVUFBc0IsS0FBbUIsRUFBRSxjQUE4QztRQUNyRixJQUFJLENBQUMsS0FBSyxDQUFDLFVBQVUsRUFBRTtZQUNuQixJQUFJLENBQUMsbUJBQW1CLENBQUMsS0FBSyxDQUFDLENBQUM7WUFDaEMsSUFBSSxDQUFDLHlCQUF5QixDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQztTQUM5QzthQUNJO1lBQ0QsS0FBSyxDQUFDLFVBQVUsR0FBRyxLQUFLLENBQUM7U0FDNUI7SUFDTCxDQUFDO0lBRU0sMENBQWtCLEdBQXpCO1FBQ0ksT0FBTyxJQUFJLENBQUMsV0FBVyxDQUFDLEVBQUUsQ0FBTSw0QkFBNEIsQ0FBQyxDQUFDO0lBQ2xFLENBQUM7SUFFTyx5Q0FBaUIsR0FBekIsVUFBMEIsS0FBVTtRQUNoQyxJQUFJLENBQUMsV0FBVyxDQUFDLFNBQVMsQ0FBQyw0QkFBNEIsRUFBRSxLQUFLLENBQUMsQ0FBQztJQUNwRSxDQUFDO0lBRU0sNENBQW9CLEdBQTNCO1FBQ0ksT0FBTyxJQUFJLENBQUMsV0FBVyxDQUFDLEVBQUUsQ0FBTSw4QkFBOEIsQ0FBQyxDQUFDO0lBQ3BFLENBQUM7SUFFTywyQ0FBbUIsR0FBM0IsVUFBNEIsS0FBVTtRQUNsQyxJQUFJLENBQUMsV0FBVyxDQUFDLFNBQVMsQ0FBQyw4QkFBOEIsRUFBRSxLQUFLLENBQUMsQ0FBQztJQUN0RSxDQUFDO0lBRU0seUNBQWlCLEdBQXhCO1FBQ0ksT0FBTyxJQUFJLENBQUMsV0FBVyxDQUFDLEVBQUUsQ0FBTSwyQkFBMkIsQ0FBQyxDQUFDO0lBQ2pFLENBQUM7SUFFTSx1Q0FBZSxHQUF0QjtRQUNJLElBQUksQ0FBQyxXQUFXLENBQUMsU0FBUyxDQUFDLDJCQUEyQixDQUFDLENBQUM7SUFDNUQsQ0FBQzs7Z0JBMUdnQyxhQUFhOztJQUxyQyxhQUFhO1FBRHpCLFVBQVUsRUFBRTt5Q0FNd0IsYUFBYTtPQUxyQyxhQUFhLENBZ0h6QjtJQUFELG9CQUFDO0NBQUEsQUFoSEQsSUFnSEM7U0FoSFksYUFBYSIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IEluamVjdGFibGUsIEV2ZW50RW1pdHRlciB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xyXG5pbXBvcnQgeyBJR3JpZHN0ZXJDb25maWcgfSBmcm9tICcuL2tkLWdyaWRzdGVyLWludGVyZmFjZSc7XHJcbmltcG9ydCB7XHJcbiAgICBHcmlkc3RlckNvbmZpZyxcclxuICAgIEdyaWRzdGVySXRlbSxcclxuICAgIEdyaWRzdGVySXRlbUNvbXBvbmVudEludGVyZmFjZVxyXG59IGZyb20gJ2FuZ3VsYXItZ3JpZHN0ZXIyJztcclxuaW1wb3J0IHsgS2RCcm9hZGNhc3RlciB9IGZyb20gJy4uL2tkLWNvbW1vbi9pbmRleCc7XHJcbmltcG9ydCB7IE9ic2VydmFibGUgfSBmcm9tICdyeGpzJztcclxuXHJcbkBJbmplY3RhYmxlKClcclxuZXhwb3J0IGNsYXNzIEtkR3JpZHN0ZXJTdmMge1xyXG5cclxuICAgIHByaXZhdGUgZ2V0R3JpZHN0ZXJJdGVtOiBFdmVudEVtaXR0ZXI8R3JpZHN0ZXJJdGVtPjtcclxuICAgIHByaXZhdGUgZ3JpZHN0ZXJJdGVtUmVzaXplRW1pdHRlcjogRXZlbnRFbWl0dGVyPEdyaWRzdGVySXRlbT47XHJcblxyXG4gICAgY29uc3RydWN0b3IocHJpdmF0ZSBicm9hZGNhc3RlcjogS2RCcm9hZGNhc3RlcikgeyB9XHJcblxyXG4gICAgcHVibGljIHNldEVtaXR0ZXIoZ3JpZHN0ZXJJdGVtUmVzaXplRW1pdHRlcjogRXZlbnRFbWl0dGVyPEdyaWRzdGVySXRlbT4sIGdldEdyaWRzdGVySXRlbUVtaXR0ZXI6IEV2ZW50RW1pdHRlcjxHcmlkc3Rlckl0ZW0+KSB7XHJcbiAgICAgICAgdGhpcy5ncmlkc3Rlckl0ZW1SZXNpemVFbWl0dGVyID0gZ3JpZHN0ZXJJdGVtUmVzaXplRW1pdHRlcjtcclxuICAgICAgICB0aGlzLmdldEdyaWRzdGVySXRlbSA9IGdldEdyaWRzdGVySXRlbUVtaXR0ZXI7XHJcbiAgICB9XHJcblxyXG4gICAgLyoqXHJcbiAgICAgKiBnZW5lcmF0ZSBkZWZhdWx0IGdyaWRzdGVyIGNvbmZpZ1xyXG4gICAgICogIGRlZmF1bHQgZ3JpZHN0ZXIgY29uZmlnXHJcbiAgICAgKi9cclxuICAgIHByaXZhdGUgZ2V0RGVmYXVsdEdyaWRzdGVyQ29uZmlnKCk6IEdyaWRzdGVyQ29uZmlnIHtcclxuICAgICAgICByZXR1cm4ge1xyXG4gICAgICAgICAgICAvLyBncmlkc3RlciBwbHVnaW4gcHJvcGVydHlcclxuICAgICAgICAgICAgZ3JpZFR5cGU6ICdzY3JvbGxWZXJ0aWNhbCcsXHJcbiAgICAgICAgICAgIG1vYmlsZUJyZWFrcG9pbnQ6IDAsXHJcbiAgICAgICAgICAgIGRlZmF1bHRJdGVtQ29sczogMjAsXHJcbiAgICAgICAgICAgIGRlZmF1bHRJdGVtUm93czogMTAsXHJcbiAgICAgICAgICAgIGRyYWdnYWJsZToge1xyXG4gICAgICAgICAgICAgICAgZW5hYmxlZDogdHJ1ZSxcclxuICAgICAgICAgICAgICAgIGlnbm9yZUNvbnRlbnRDbGFzczogJ25vLWRyYWcnLFxyXG4gICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICByZXNpemFibGU6IHtcclxuICAgICAgICAgICAgICAgIGVuYWJsZWQ6IHRydWUsXHJcbiAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgIHB1c2hJdGVtczogZmFsc2UsXHJcbiAgICAgICAgICAgIGRpc2FibGVQdXNoT25EcmFnOiB0cnVlLFxyXG4gICAgICAgICAgICBkaXNhYmxlUHVzaE9uUmVzaXplOiB0cnVlLFxyXG4gICAgICAgICAgICBwdXNoUmVzaXplSXRlbXM6IGZhbHNlLFxyXG4gICAgICAgICAgICBwdXNoRGlyZWN0aW9uczogeyBub3J0aDogZmFsc2UsIGVhc3Q6IGZhbHNlLCBzb3V0aDogZmFsc2UsIHdlc3Q6IGZhbHNlIH0sXHJcbiAgICAgICAgICAgIGRpc3BsYXlHcmlkOiAnb25EcmFnJlJlc2l6ZScsXHJcbiAgICAgICAgICAgIHNjcm9sbFRvTmV3SXRlbXM6IHRydWUsXHJcbiAgICAgICAgICAgIGRpc2FibGVBdXRvUG9zaXRpb25PbkNvbmZsaWN0OiB0cnVlLFxyXG4gICAgICAgICAgICBzZXRHcmlkU2l6ZTogZmFsc2UsXHJcbiAgICAgICAgICAgIG1pbkNvbHM6IDEwMCxcclxuICAgICAgICAgICAgbWF4Q29sczogMTAwLFxyXG4gICAgICAgICAgICBtYXhSb3dzOiAxMDAsXHJcblxyXG4gICAgICAgICAgICAvLyBhZGQtb24gcHJvcGVydHlcclxuICAgICAgICAgICAgYm9yZGVyOiBmYWxzZSxcclxuICAgICAgICAgICAgZW5hYmxlRWRpdE1vZGU6IGZhbHNlLFxyXG4gICAgICAgICAgICBoaWRlRHJhZ0J1dHRvbnM6IGZhbHNlLFxyXG4gICAgICAgICAgICBoaWRlQ3VzdG9tQnV0dG9uczogZmFsc2UsXHJcbiAgICAgICAgICAgIHNldEZpeENlbnRlcjogZmFsc2UsXHJcbiAgICAgICAgICAgIGVuYWJsZURvd25ncmFkZTogZmFsc2UsXHJcbiAgICAgICAgICAgIGJ1dHRvbnM6IFtdXHJcbiAgICAgICAgfTtcclxuICAgIH1cclxuXHJcbiAgICAvKipcclxuICAgICAqIHJldHVybiBjb21iaW5hdGlvbiBvZiBkZWZhdWx0IGdyaWRzdGVyIGNvbmZpZyBhbmQgdXNlciBkZWZpbmUgY29uZmlnXHJcbiAgICAgKiAgICBfY29uZmlnICBjb25maWcgZnJvbSB1c2VyL2FwcGxpY2F0aW9uXHJcbiAgICAgKiAgICAgICAgICAgICBbZGVzY3JpcHRpb25dXHJcbiAgICAgKi9cclxuICAgIHB1YmxpYyBnZXRDb25maWcoX2NvbmZpZzogSUdyaWRzdGVyQ29uZmlnKTogSUdyaWRzdGVyQ29uZmlnIHtcclxuICAgICAgICBpZiAodHlwZW9mIF9jb25maWcgPT09ICd1bmRlZmluZWQnKSBfY29uZmlnID0ge307XHJcblxyXG4gICAgICAgIGxldCBncmlkc3RlckRlZmF1bHRDb25maWc6IEdyaWRzdGVyQ29uZmlnID0gdGhpcy5nZXREZWZhdWx0R3JpZHN0ZXJDb25maWcoKTtcclxuXHJcbiAgICAgICAgZ3JpZHN0ZXJEZWZhdWx0Q29uZmlnLml0ZW1Jbml0Q2FsbGJhY2sgPSAoaXRlbTogR3JpZHN0ZXJJdGVtLCBpdGVtQ29tcG9uZW50OiBHcmlkc3Rlckl0ZW1Db21wb25lbnRJbnRlcmZhY2UpID0+IHRoaXMuX29uSXRlbUluaXQoaXRlbSwgaXRlbUNvbXBvbmVudCk7XHJcblxyXG4gICAgICAgIGdyaWRzdGVyRGVmYXVsdENvbmZpZy5pdGVtUmVzaXplQ2FsbGJhY2sgPSAoaXRlbTogR3JpZHN0ZXJJdGVtLCBpdGVtQ29tcG9uZW50OiBHcmlkc3Rlckl0ZW1Db21wb25lbnRJbnRlcmZhY2UpID0+IHRoaXMuX29uSXRlbVJlc2l6ZShpdGVtLCBpdGVtQ29tcG9uZW50KTtcclxuXHJcbiAgICAgICAgcmV0dXJuICg8SUdyaWRzdGVyQ29uZmlnPk9iamVjdCkuYXNzaWduKHt9LCBncmlkc3RlckRlZmF1bHRDb25maWcsIF9jb25maWcpO1xyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX29uSXRlbUluaXQoX2l0ZW06IEdyaWRzdGVySXRlbSwgX2l0ZW1Db21wb25lbnQ6IEdyaWRzdGVySXRlbUNvbXBvbmVudEludGVyZmFjZSk6IHZvaWQge1xyXG4gICAgICAgIC8vIGNvbnNvbGUubG9nKCdfb25JdGVtSW5pdCcsIEpTT04uc3RyaW5naWZ5KF9pdGVtKSk7XHJcbiAgICAgICAgX2l0ZW1Db21wb25lbnQuZWwuY2xhc3NOYW1lICs9ICcga2R4LWRpc3BsYXktYm94JztcclxuICAgICAgICBfaXRlbS5pc0RvbmVJbml0ID0gdHJ1ZTtcclxuICAgICAgICB0aGlzLmdldEdyaWRzdGVySXRlbS5lbWl0KF9pdGVtKTtcclxuICAgICAgICB0aGlzLl9ncmlkc3Rlckl0ZW1Jbml0KF9pdGVtKTtcclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF9vbkl0ZW1SZXNpemUoX2l0ZW06IEdyaWRzdGVySXRlbSwgX2l0ZW1Db21wb25lbnQ6IEdyaWRzdGVySXRlbUNvbXBvbmVudEludGVyZmFjZSk6IHZvaWQge1xyXG4gICAgICAgIGlmICghX2l0ZW0uaXNEb25lSW5pdCkge1xyXG4gICAgICAgICAgICB0aGlzLl9ncmlkc3Rlckl0ZW1SZXNpemUoX2l0ZW0pO1xyXG4gICAgICAgICAgICB0aGlzLmdyaWRzdGVySXRlbVJlc2l6ZUVtaXR0ZXIuZW1pdChfaXRlbSk7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICBfaXRlbS5pc0RvbmVJbml0ID0gZmFsc2U7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIHB1YmxpYyBvbkdyaWRzdGVySXRlbUluaXQoKTogT2JzZXJ2YWJsZTxhbnk+IHtcclxuICAgICAgICByZXR1cm4gdGhpcy5icm9hZGNhc3Rlci5vbjxhbnk+KCdLZEdyaWRzdGVyRXZlbnRfb25JdGVtSW5pdCcpO1xyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX2dyaWRzdGVySXRlbUluaXQoX2l0ZW06IGFueSk6IHZvaWQge1xyXG4gICAgICAgIHRoaXMuYnJvYWRjYXN0ZXIuYnJvYWRjYXN0KCdLZEdyaWRzdGVyRXZlbnRfb25JdGVtSW5pdCcsIF9pdGVtKTtcclxuICAgIH1cclxuXHJcbiAgICBwdWJsaWMgb25Hcmlkc3Rlckl0ZW1SZXNpemUoKTogT2JzZXJ2YWJsZTxhbnk+IHtcclxuICAgICAgICByZXR1cm4gdGhpcy5icm9hZGNhc3Rlci5vbjxhbnk+KCdLZEdyaWRzdGVyRXZlbnRfb25JdGVtUmVzaXplJyk7XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfZ3JpZHN0ZXJJdGVtUmVzaXplKF9pdGVtOiBhbnkpOiB2b2lkIHtcclxuICAgICAgICB0aGlzLmJyb2FkY2FzdGVyLmJyb2FkY2FzdCgnS2RHcmlkc3RlckV2ZW50X29uSXRlbVJlc2l6ZScsIF9pdGVtKTtcclxuICAgIH1cclxuXHJcbiAgICBwdWJsaWMgb25Hcmlkc3RlclJlbW92ZWQoKTogT2JzZXJ2YWJsZTxhbnk+IHtcclxuICAgICAgICByZXR1cm4gdGhpcy5icm9hZGNhc3Rlci5vbjxhbnk+KCdLZEdyaWRzdGVyRXZlbnRfb25SZW1vdmVkJyk7XHJcbiAgICB9XHJcblxyXG4gICAgcHVibGljIGdyaWRzdGVyUmVtb3ZlZCgpOiB2b2lkIHtcclxuICAgICAgICB0aGlzLmJyb2FkY2FzdGVyLmJyb2FkY2FzdCgnS2RHcmlkc3RlckV2ZW50X29uUmVtb3ZlZCcpO1xyXG4gICAgfVxyXG59XHJcbiJdfQ==