import { __decorate, __metadata, __values } from "tslib";
import { Component, ViewEncapsulation, Input, Output, ContentChild, TemplateRef, ViewChild, ViewContainerRef, EventEmitter } from '@angular/core';
import { KdGridsterSvc } from './kd-gridster-svc';
var KdGridster = /** @class */ (function () {
    function KdGridster(_gridsterSvc) {
        this._gridsterSvc = _gridsterSvc;
        this._gridsterItems = [];
        this.items = [];
        this.getConfig = new EventEmitter();
        this.getGridsterItem = new EventEmitter();
        this.gridsterItemResize = new EventEmitter();
        this.gridsterRemoved = new EventEmitter();
    }
    KdGridster.prototype.ngOnInit = function () {
        var _this = this;
        // console.log('init');
        this.api.addGridsterItem = function (_item, _handleError) {
            var newItem = _this.getValidItem(_item);
            if (newItem) {
                _this._gridsterItems.push(newItem);
                _this.addGridsterItem(newItem);
            }
            else {
                if (_handleError) {
                    _handleError('KdGridster ERROR: maxCols and maxRows has been reached, item can\'t be placed in the bounds of the dashboard');
                }
                else {
                    console.warn('KdGridster ERROR: maxCols and maxRows has been reached, item can\'t be placed in the bounds of the dashboard');
                }
            }
        };
        this.api.removeGridsterItem = function (_id) { return _this._removeGridsterItem(_id); };
        this.api.gridsterResize = function () { return _this.gridsterOptions.api.resize(); };
        this.api.onGridsterItemReady = this._gridsterSvc.onGridsterItemInit();
        this.api.onGridsterItemResize = this._gridsterSvc.onGridsterItemResize();
        this.api.onGridsterRemoved = this._gridsterSvc.onGridsterRemoved();
        this._gridsterSvc.setEmitter(this.gridsterItemResize, this.getGridsterItem);
    };
    KdGridster.prototype.ngOnDestroy = function () {
        this.gridsterRemoved.emit();
        this._gridsterSvc.gridsterRemoved();
        this.gridsterContainer.clear();
    };
    KdGridster.prototype.ngOnChanges = function (changes) {
        // console.log('kd gridster, changes', changes);
        var e_1, _a;
        if (changes.hasOwnProperty('config')) {
            if (!changes.config.isFirstChange()) {
                this._gridsterItems = [];
                this.gridsterContainer.clear();
            }
            // get grister config only
            this.gridsterOptions = this._gridsterSvc.getConfig(changes.config.currentValue);
            this.getConfig.emit(this.gridsterOptions);
            var gridsterItems = this.items.slice();
            try {
                // load in the default gridsterItems
                for (var gridsterItems_1 = __values(gridsterItems), gridsterItems_1_1 = gridsterItems_1.next(); !gridsterItems_1_1.done; gridsterItems_1_1 = gridsterItems_1.next()) {
                    var item = gridsterItems_1_1.value;
                    var newItem = this.getValidItem(item);
                    if (typeof newItem.enableContentDrag === 'undefined')
                        newItem.enableContentDrag = true;
                    this.addGridsterItem(newItem);
                    this._gridsterItems.push(newItem);
                }
            }
            catch (e_1_1) { e_1 = { error: e_1_1 }; }
            finally {
                try {
                    if (gridsterItems_1_1 && !gridsterItems_1_1.done && (_a = gridsterItems_1.return)) _a.call(gridsterItems_1);
                }
                finally { if (e_1) throw e_1.error; }
            }
        }
    };
    /**
     * remove item from ready list, item list and container
     *  _id item.id
     */
    KdGridster.prototype._removeGridsterItem = function (_id) {
        for (var i = this._gridsterItems.length - 1; i >= 0; i--) {
            if (this._gridsterItems[i].id === _id) {
                this._gridsterItems.splice(i, 1);
                if (!this.config.enableDowngrade)
                    this.gridsterContainer.remove(i);
                break;
            }
        }
    };
    /**
     * check if gridsterItem can be added in the position specified
     * _item IGridsterItem
     */
    KdGridster.prototype.getValidItem = function (_item) {
        var newItem = Object.assign({ x: -1, y: -1, cols: -1, rows: -1 }, _item);
        if (typeof _item.x === 'undefined' || typeof _item.y === 'undefined') {
            Object.assign(newItem, this.gridsterOptions.api.getFirstPossiblePosition(newItem));
        }
        if ((newItem.x + newItem.cols) > this.gridsterOptions.maxCols || (newItem.y + newItem.rows) > this.gridsterOptions.maxRows) {
            return;
        }
        return newItem;
    };
    /**
     * add template of <gridster-item> into <gridster>
     *  _item [description]
     */
    KdGridster.prototype.addGridsterItem = function (_item) {
        var _this = this;
        if (this.config.enableDowngrade)
            return;
        setTimeout(function () { return _this.gridsterContainer.createEmbeddedView(_this.gridsterItemTemplate, { item: _item, gridsterOptions: _this.gridsterOptions }); });
    };
    KdGridster.ctorParameters = function () { return [
        { type: KdGridsterSvc }
    ]; };
    __decorate([
        Input(),
        __metadata("design:type", Object)
    ], KdGridster.prototype, "config", void 0);
    __decorate([
        Input(),
        __metadata("design:type", Array)
    ], KdGridster.prototype, "items", void 0);
    __decorate([
        Input(),
        __metadata("design:type", Object)
    ], KdGridster.prototype, "api", void 0);
    __decorate([
        Output(),
        __metadata("design:type", EventEmitter)
    ], KdGridster.prototype, "getConfig", void 0);
    __decorate([
        Output(),
        __metadata("design:type", EventEmitter)
    ], KdGridster.prototype, "getGridsterItem", void 0);
    __decorate([
        Output(),
        __metadata("design:type", EventEmitter)
    ], KdGridster.prototype, "gridsterItemResize", void 0);
    __decorate([
        Output(),
        __metadata("design:type", EventEmitter)
    ], KdGridster.prototype, "gridsterRemoved", void 0);
    __decorate([
        ContentChild(TemplateRef),
        __metadata("design:type", TemplateRef)
    ], KdGridster.prototype, "gridsterContentTemplate", void 0);
    __decorate([
        ViewChild('gridsterContainer', { read: ViewContainerRef }),
        __metadata("design:type", ViewContainerRef)
    ], KdGridster.prototype, "gridsterContainer", void 0);
    __decorate([
        ViewChild('gridsterItemTemplate'),
        __metadata("design:type", TemplateRef)
    ], KdGridster.prototype, "gridsterItemTemplate", void 0);
    KdGridster = __decorate([
        Component({
            selector: 'kd-gridster',
            providers: [KdGridsterSvc],
            encapsulation: ViewEncapsulation.None,
            template: "<ng-content *ngIf=\"gridsterOptions.enableDowngrade\">\r\n</ng-content>\r\n<gridster *ngIf=\"!gridsterOptions.enableDowngrade\" class=\"kdx-gridster\" [ngClass]=\"{'bg-dot': gridsterOptions.enableEditMode, 'kdx-center': gridsterOptions.setFixCenter}\" [options]=\"gridsterOptions\">\r\n    <ng-container #gridsterContainer></ng-container>\r\n    <ng-template #gridsterItemTemplate let-gridsterOptions=\"gridsterOptions\" let-item=\"item\">\r\n        <gridster-item [item]=\"item\" class=\"kdx-gridster-item\" [ngClass]=\"{'no-border': !gridsterOptions.border}\">\r\n            <kd-gridster-toolbar [item]=\"item\" [config]=\"gridsterOptions\"></kd-gridster-toolbar>\r\n            <div class=\"kdx-gridster-item-content\" [ngClass]=\"{'no-drag': !item.enableContentDrag}\">\r\n                <ng-container *ngIf=\"!gridsterOptions.enableDowngrade\">\r\n                    <ng-container *ngTemplateOutlet=\"gridsterContentTemplate; context: { $implicit: item }\">\r\n                        <ng-content select=\".gridster-content\"></ng-content>\r\n                    </ng-container>\r\n                </ng-container>\r\n            </div>\r\n        </gridster-item>\r\n    </ng-template>\r\n</gridster>\r\n"
        }),
        __metadata("design:paramtypes", [KdGridsterSvc])
    ], KdGridster);
    return KdGridster;
}());
export { KdGridster };
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoia2QtZ3JpZHN0ZXIuanMiLCJzb3VyY2VSb290Ijoibmc6Ly9vcGVuZW1pcy1zdHlsZWd1aWRlLWxpYi8iLCJzb3VyY2VzIjpbImtkLWNvbXBvbmVudHMva2QtYW5ndWxhci1ncmlkc3Rlci9rZC1ncmlkc3Rlci50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiO0FBQUEsT0FBTyxFQUNILFNBQVMsRUFDVCxpQkFBaUIsRUFLakIsS0FBSyxFQUNMLE1BQU0sRUFDTixZQUFZLEVBQ1osV0FBVyxFQUNYLFNBQVMsRUFDVCxnQkFBZ0IsRUFDaEIsWUFBWSxFQUNmLE1BQU0sZUFBZSxDQUFDO0FBRXZCLE9BQU8sRUFBRSxhQUFhLEVBQUUsTUFBTSxtQkFBbUIsQ0FBQztBQWNsRDtJQW1CSSxvQkFDWSxZQUEyQjtRQUEzQixpQkFBWSxHQUFaLFlBQVksQ0FBZTtRQWpCL0IsbUJBQWMsR0FBd0IsRUFBRSxDQUFDO1FBR3hDLFVBQUssR0FBeUIsRUFBRSxDQUFDO1FBR2hDLGNBQVMsR0FBa0MsSUFBSSxZQUFZLEVBQUUsQ0FBQztRQUM5RCxvQkFBZSxHQUErQixJQUFJLFlBQVksRUFBRSxDQUFDO1FBQ2pFLHVCQUFrQixHQUErQixJQUFJLFlBQVksRUFBZ0IsQ0FBQztRQUNsRixvQkFBZSxHQUFzQixJQUFJLFlBQVksRUFBTyxDQUFDO0lBU25FLENBQUM7SUFFTCw2QkFBUSxHQUFSO1FBQUEsaUJBdUJDO1FBdEJHLHVCQUF1QjtRQUN2QixJQUFJLENBQUMsR0FBRyxDQUFDLGVBQWUsR0FBRyxVQUFDLEtBQW9CLEVBQUUsWUFBc0M7WUFDcEYsSUFBSSxPQUFPLEdBQWlCLEtBQUksQ0FBQyxZQUFZLENBQUMsS0FBSyxDQUFDLENBQUM7WUFDckQsSUFBSSxPQUFPLEVBQUU7Z0JBQ1QsS0FBSSxDQUFDLGNBQWMsQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLENBQUM7Z0JBQ2xDLEtBQUksQ0FBQyxlQUFlLENBQUMsT0FBTyxDQUFDLENBQUM7YUFDakM7aUJBQU07Z0JBQ0gsSUFBSSxZQUFZLEVBQUU7b0JBQ2QsWUFBWSxDQUFDLDhHQUE4RyxDQUFDLENBQUM7aUJBQ2hJO3FCQUFNO29CQUNILE9BQU8sQ0FBQyxJQUFJLENBQUMsOEdBQThHLENBQUMsQ0FBQztpQkFDaEk7YUFDSjtRQUNMLENBQUMsQ0FBQztRQUVGLElBQUksQ0FBQyxHQUFHLENBQUMsa0JBQWtCLEdBQUcsVUFBQyxHQUFXLElBQUssT0FBQSxLQUFJLENBQUMsbUJBQW1CLENBQUMsR0FBRyxDQUFDLEVBQTdCLENBQTZCLENBQUM7UUFDN0UsSUFBSSxDQUFDLEdBQUcsQ0FBQyxjQUFjLEdBQUcsY0FBTSxPQUFBLEtBQUksQ0FBQyxlQUFlLENBQUMsR0FBRyxDQUFDLE1BQU0sRUFBRSxFQUFqQyxDQUFpQyxDQUFDO1FBQ2xFLElBQUksQ0FBQyxHQUFHLENBQUMsbUJBQW1CLEdBQUcsSUFBSSxDQUFDLFlBQVksQ0FBQyxrQkFBa0IsRUFBRSxDQUFDO1FBQ3RFLElBQUksQ0FBQyxHQUFHLENBQUMsb0JBQW9CLEdBQUcsSUFBSSxDQUFDLFlBQVksQ0FBQyxvQkFBb0IsRUFBRSxDQUFDO1FBQ3pFLElBQUksQ0FBQyxHQUFHLENBQUMsaUJBQWlCLEdBQUcsSUFBSSxDQUFDLFlBQVksQ0FBQyxpQkFBaUIsRUFBRSxDQUFDO1FBRW5FLElBQUksQ0FBQyxZQUFZLENBQUMsVUFBVSxDQUFDLElBQUksQ0FBQyxrQkFBa0IsRUFBRSxJQUFJLENBQUMsZUFBZSxDQUFDLENBQUM7SUFDaEYsQ0FBQztJQUVELGdDQUFXLEdBQVg7UUFDSSxJQUFJLENBQUMsZUFBZSxDQUFDLElBQUksRUFBRSxDQUFDO1FBQzVCLElBQUksQ0FBQyxZQUFZLENBQUMsZUFBZSxFQUFFLENBQUM7UUFDcEMsSUFBSSxDQUFDLGlCQUFpQixDQUFDLEtBQUssRUFBRSxDQUFDO0lBQ25DLENBQUM7SUFFRCxnQ0FBVyxHQUFYLFVBQVksT0FBc0I7UUFDOUIsZ0RBQWdEOztRQUVoRCxJQUFJLE9BQU8sQ0FBQyxjQUFjLENBQUMsUUFBUSxDQUFDLEVBQUU7WUFFbEMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsYUFBYSxFQUFFLEVBQUU7Z0JBQ2pDLElBQUksQ0FBQyxjQUFjLEdBQUcsRUFBRSxDQUFDO2dCQUN6QixJQUFJLENBQUMsaUJBQWlCLENBQUMsS0FBSyxFQUFFLENBQUM7YUFDbEM7WUFFRCwwQkFBMEI7WUFDMUIsSUFBSSxDQUFDLGVBQWUsR0FBRyxJQUFJLENBQUMsWUFBWSxDQUFDLFNBQVMsQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLFlBQVksQ0FBQyxDQUFDO1lBQ2hGLElBQUksQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxlQUFlLENBQUMsQ0FBQztZQUUxQyxJQUFJLGFBQWEsR0FBSSxJQUFJLENBQUMsS0FBSyxDQUFDLEtBQUssRUFBRSxDQUFDOztnQkFFeEMsb0NBQW9DO2dCQUNwQyxLQUFpQixJQUFBLGtCQUFBLFNBQUEsYUFBYSxDQUFBLDRDQUFBLHVFQUFFO29CQUEzQixJQUFJLElBQUksMEJBQUE7b0JBQ1QsSUFBSSxPQUFPLEdBQWlCLElBQUksQ0FBQyxZQUFZLENBQUMsSUFBSSxDQUFDLENBQUM7b0JBQ3BELElBQUksT0FBTyxPQUFPLENBQUMsaUJBQWlCLEtBQUssV0FBVzt3QkFBRSxPQUFPLENBQUMsaUJBQWlCLEdBQUcsSUFBSSxDQUFDO29CQUN2RixJQUFJLENBQUMsZUFBZSxDQUFDLE9BQU8sQ0FBQyxDQUFDO29CQUM5QixJQUFJLENBQUMsY0FBYyxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsQ0FBQztpQkFDckM7Ozs7Ozs7OztTQUNKO0lBQ0wsQ0FBQztJQUVEOzs7T0FHRztJQUNLLHdDQUFtQixHQUEzQixVQUE0QixHQUFXO1FBQ25DLEtBQUssSUFBSSxDQUFDLEdBQUcsSUFBSSxDQUFDLGNBQWMsQ0FBQyxNQUFNLEdBQUcsQ0FBQyxFQUFFLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxFQUFFLEVBQUU7WUFDdEQsSUFBSSxJQUFJLENBQUMsY0FBYyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsS0FBSyxHQUFHLEVBQUU7Z0JBQ25DLElBQUksQ0FBQyxjQUFjLENBQUMsTUFBTSxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQztnQkFDakMsSUFBSSxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsZUFBZTtvQkFBRSxJQUFJLENBQUMsaUJBQWlCLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDO2dCQUNuRSxNQUFNO2FBQ1Q7U0FDSjtJQUNMLENBQUM7SUFFRDs7O09BR0c7SUFDSyxpQ0FBWSxHQUFwQixVQUFxQixLQUFvQjtRQUNyQyxJQUFJLE9BQU8sR0FBaUIsTUFBTSxDQUFDLE1BQU0sQ0FBQyxFQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsQ0FBQyxDQUFDLEVBQUUsSUFBSSxFQUFFLENBQUMsQ0FBQyxFQUFFLElBQUksRUFBRSxDQUFDLENBQUMsRUFBQyxFQUFFLEtBQUssQ0FBQyxDQUFDO1FBQ3JGLElBQUksT0FBTyxLQUFLLENBQUMsQ0FBQyxLQUFLLFdBQVcsSUFBSSxPQUFPLEtBQUssQ0FBQyxDQUFDLEtBQUssV0FBVyxFQUFFO1lBQzVELE1BQU8sQ0FBQyxNQUFNLENBQUMsT0FBTyxFQUFFLElBQUksQ0FBQyxlQUFlLENBQUMsR0FBRyxDQUFDLHdCQUF3QixDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUM7U0FDN0Y7UUFFRCxJQUFJLENBQUMsT0FBTyxDQUFDLENBQUMsR0FBRyxPQUFPLENBQUMsSUFBSSxDQUFDLEdBQUcsSUFBSSxDQUFDLGVBQWUsQ0FBQyxPQUFPLElBQUksQ0FBQyxPQUFPLENBQUMsQ0FBQyxHQUFHLE9BQU8sQ0FBQyxJQUFJLENBQUMsR0FBRyxJQUFJLENBQUMsZUFBZSxDQUFDLE9BQU8sRUFBRTtZQUN4SCxPQUFPO1NBQ1Y7UUFDRCxPQUFPLE9BQU8sQ0FBQztJQUNuQixDQUFDO0lBRUQ7OztPQUdHO0lBQ0ssb0NBQWUsR0FBdkIsVUFBd0IsS0FBbUI7UUFBM0MsaUJBR0M7UUFGRyxJQUFJLElBQUksQ0FBQyxNQUFNLENBQUMsZUFBZTtZQUFFLE9BQU87UUFDeEMsVUFBVSxDQUFDLGNBQU0sT0FBQSxLQUFJLENBQUMsaUJBQWlCLENBQUMsa0JBQWtCLENBQUMsS0FBSSxDQUFDLG9CQUFvQixFQUFFLEVBQUUsSUFBSSxFQUFFLEtBQUssRUFBRSxlQUFlLEVBQUUsS0FBSSxDQUFDLGVBQWUsRUFBRSxDQUFDLEVBQTVILENBQTRILENBQUMsQ0FBQztJQUNuSixDQUFDOztnQkFqR3lCLGFBQWE7O0lBZjlCO1FBQVIsS0FBSyxFQUFFOzs4Q0FBeUI7SUFDeEI7UUFBUixLQUFLLEVBQUU7a0NBQVEsS0FBSzs2Q0FBcUI7SUFDakM7UUFBUixLQUFLLEVBQUU7OzJDQUFtQjtJQUVqQjtRQUFULE1BQU0sRUFBRTtrQ0FBWSxZQUFZO2lEQUF1QztJQUM5RDtRQUFULE1BQU0sRUFBRTtrQ0FBa0IsWUFBWTt1REFBb0M7SUFDakU7UUFBVCxNQUFNLEVBQUU7a0NBQXFCLFlBQVk7MERBQWtEO0lBQ2xGO1FBQVQsTUFBTSxFQUFFO2tDQUFrQixZQUFZO3VEQUFnQztJQUU1QztRQUExQixZQUFZLENBQUMsV0FBVyxDQUFDO2tDQUEwQixXQUFXOytEQUFNO0lBRVQ7UUFBM0QsU0FBUyxDQUFDLG1CQUFtQixFQUFFLEVBQUUsSUFBSSxFQUFFLGdCQUFnQixFQUFFLENBQUM7a0NBQW9CLGdCQUFnQjt5REFBQztJQUM3RDtRQUFsQyxTQUFTLENBQUMsc0JBQXNCLENBQUM7a0NBQXVCLFdBQVc7NERBQU07SUFqQmpFLFVBQVU7UUFQdEIsU0FBUyxDQUFDO1lBQ1AsUUFBUSxFQUFFLGFBQWE7WUFDdkIsU0FBUyxFQUFFLENBQUMsYUFBYSxDQUFDO1lBQzFCLGFBQWEsRUFBRSxpQkFBaUIsQ0FBQyxJQUFJO1lBQ3JDLHlzQ0FBaUM7U0FDcEMsQ0FBQzt5Q0FzQjRCLGFBQWE7T0FwQjlCLFVBQVUsQ0FzSHRCO0lBQUQsaUJBQUM7Q0FBQSxBQXRIRCxJQXNIQztTQXRIWSxVQUFVIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHtcclxuICAgIENvbXBvbmVudCxcclxuICAgIFZpZXdFbmNhcHN1bGF0aW9uLFxyXG4gICAgT25Jbml0LFxyXG4gICAgT25EZXN0cm95LFxyXG4gICAgT25DaGFuZ2VzLFxyXG4gICAgU2ltcGxlQ2hhbmdlcyxcclxuICAgIElucHV0LFxyXG4gICAgT3V0cHV0LFxyXG4gICAgQ29udGVudENoaWxkLFxyXG4gICAgVGVtcGxhdGVSZWYsXHJcbiAgICBWaWV3Q2hpbGQsXHJcbiAgICBWaWV3Q29udGFpbmVyUmVmLFxyXG4gICAgRXZlbnRFbWl0dGVyXHJcbn0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XHJcbmltcG9ydCB7IEdyaWRzdGVyQ29uZmlnLCBHcmlkc3Rlckl0ZW0gfSBmcm9tICdhbmd1bGFyLWdyaWRzdGVyMic7XHJcbmltcG9ydCB7IEtkR3JpZHN0ZXJTdmMgfSBmcm9tICcuL2tkLWdyaWRzdGVyLXN2Yyc7XHJcbmltcG9ydCB7XHJcbiAgICBJR3JpZHN0ZXJDb25maWcsXHJcbiAgICBJR3JpZHN0ZXJJdGVtLFxyXG4gICAgSUdyaWRzdGVyQXBpXHJcbn0gZnJvbSAnLi9rZC1ncmlkc3Rlci1pbnRlcmZhY2UnO1xyXG5cclxuQENvbXBvbmVudCh7XHJcbiAgICBzZWxlY3RvcjogJ2tkLWdyaWRzdGVyJyxcclxuICAgIHByb3ZpZGVyczogW0tkR3JpZHN0ZXJTdmNdLFxyXG4gICAgZW5jYXBzdWxhdGlvbjogVmlld0VuY2Fwc3VsYXRpb24uTm9uZSxcclxuICAgIHRlbXBsYXRlVXJsOiAnLi9rZC1ncmlkc3Rlci5odG1sJ1xyXG59KVxyXG5cclxuZXhwb3J0IGNsYXNzIEtkR3JpZHN0ZXIgaW1wbGVtZW50cyBPbkluaXQsIE9uRGVzdHJveSwgT25DaGFuZ2VzIHtcclxuXHJcbiAgICBwdWJsaWMgZ3JpZHN0ZXJPcHRpb25zOiBHcmlkc3RlckNvbmZpZztcclxuICAgIHByaXZhdGUgX2dyaWRzdGVySXRlbXM6IEFycmF5PEdyaWRzdGVySXRlbT4gPSBbXTtcclxuXHJcbiAgICBASW5wdXQoKSBjb25maWc6IElHcmlkc3RlckNvbmZpZztcclxuICAgIEBJbnB1dCgpIGl0ZW1zOiBBcnJheTxJR3JpZHN0ZXJJdGVtPiA9IFtdO1xyXG4gICAgQElucHV0KCkgYXBpOiBJR3JpZHN0ZXJBcGk7XHJcblxyXG4gICAgQE91dHB1dCgpIGdldENvbmZpZzogRXZlbnRFbWl0dGVyPElHcmlkc3RlckNvbmZpZz4gPSBuZXcgRXZlbnRFbWl0dGVyKCk7XHJcbiAgICBAT3V0cHV0KCkgZ2V0R3JpZHN0ZXJJdGVtOiBFdmVudEVtaXR0ZXI8R3JpZHN0ZXJJdGVtPiA9IG5ldyBFdmVudEVtaXR0ZXIoKTtcclxuICAgIEBPdXRwdXQoKSBncmlkc3Rlckl0ZW1SZXNpemU6IEV2ZW50RW1pdHRlcjxHcmlkc3Rlckl0ZW0+ID0gbmV3IEV2ZW50RW1pdHRlcjxHcmlkc3Rlckl0ZW0+KCk7XHJcbiAgICBAT3V0cHV0KCkgZ3JpZHN0ZXJSZW1vdmVkOiBFdmVudEVtaXR0ZXI8YW55PiA9IG5ldyBFdmVudEVtaXR0ZXI8YW55PigpO1xyXG5cclxuICAgIEBDb250ZW50Q2hpbGQoVGVtcGxhdGVSZWYpIGdyaWRzdGVyQ29udGVudFRlbXBsYXRlOiBUZW1wbGF0ZVJlZjxhbnk+O1xyXG5cclxuICAgIEBWaWV3Q2hpbGQoJ2dyaWRzdGVyQ29udGFpbmVyJywgeyByZWFkOiBWaWV3Q29udGFpbmVyUmVmIH0pIGdyaWRzdGVyQ29udGFpbmVyOiBWaWV3Q29udGFpbmVyUmVmO1xyXG4gICAgQFZpZXdDaGlsZCgnZ3JpZHN0ZXJJdGVtVGVtcGxhdGUnKSBncmlkc3Rlckl0ZW1UZW1wbGF0ZTogVGVtcGxhdGVSZWY8YW55PjtcclxuXHJcbiAgICBjb25zdHJ1Y3RvcihcclxuICAgICAgICBwcml2YXRlIF9ncmlkc3RlclN2YzogS2RHcmlkc3RlclN2Y1xyXG4gICAgKSB7IH1cclxuXHJcbiAgICBuZ09uSW5pdCgpOiB2b2lkIHtcclxuICAgICAgICAvLyBjb25zb2xlLmxvZygnaW5pdCcpO1xyXG4gICAgICAgIHRoaXMuYXBpLmFkZEdyaWRzdGVySXRlbSA9IChfaXRlbTogSUdyaWRzdGVySXRlbSwgX2hhbmRsZUVycm9yPzogKGVycm9yOiBzdHJpbmcpID0+IHZvaWQpID0+IHtcclxuICAgICAgICAgICAgbGV0IG5ld0l0ZW06IEdyaWRzdGVySXRlbSA9IHRoaXMuZ2V0VmFsaWRJdGVtKF9pdGVtKTtcclxuICAgICAgICAgICAgaWYgKG5ld0l0ZW0pIHtcclxuICAgICAgICAgICAgICAgIHRoaXMuX2dyaWRzdGVySXRlbXMucHVzaChuZXdJdGVtKTtcclxuICAgICAgICAgICAgICAgIHRoaXMuYWRkR3JpZHN0ZXJJdGVtKG5ld0l0ZW0pO1xyXG4gICAgICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgaWYgKF9oYW5kbGVFcnJvcikge1xyXG4gICAgICAgICAgICAgICAgICAgIF9oYW5kbGVFcnJvcignS2RHcmlkc3RlciBFUlJPUjogbWF4Q29scyBhbmQgbWF4Um93cyBoYXMgYmVlbiByZWFjaGVkLCBpdGVtIGNhblxcJ3QgYmUgcGxhY2VkIGluIHRoZSBib3VuZHMgb2YgdGhlIGRhc2hib2FyZCcpO1xyXG4gICAgICAgICAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgICAgICAgICBjb25zb2xlLndhcm4oJ0tkR3JpZHN0ZXIgRVJST1I6IG1heENvbHMgYW5kIG1heFJvd3MgaGFzIGJlZW4gcmVhY2hlZCwgaXRlbSBjYW5cXCd0IGJlIHBsYWNlZCBpbiB0aGUgYm91bmRzIG9mIHRoZSBkYXNoYm9hcmQnKTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH07XHJcblxyXG4gICAgICAgIHRoaXMuYXBpLnJlbW92ZUdyaWRzdGVySXRlbSA9IChfaWQ6IHN0cmluZykgPT4gdGhpcy5fcmVtb3ZlR3JpZHN0ZXJJdGVtKF9pZCk7XHJcbiAgICAgICAgdGhpcy5hcGkuZ3JpZHN0ZXJSZXNpemUgPSAoKSA9PiB0aGlzLmdyaWRzdGVyT3B0aW9ucy5hcGkucmVzaXplKCk7XHJcbiAgICAgICAgdGhpcy5hcGkub25Hcmlkc3Rlckl0ZW1SZWFkeSA9IHRoaXMuX2dyaWRzdGVyU3ZjLm9uR3JpZHN0ZXJJdGVtSW5pdCgpO1xyXG4gICAgICAgIHRoaXMuYXBpLm9uR3JpZHN0ZXJJdGVtUmVzaXplID0gdGhpcy5fZ3JpZHN0ZXJTdmMub25Hcmlkc3Rlckl0ZW1SZXNpemUoKTtcclxuICAgICAgICB0aGlzLmFwaS5vbkdyaWRzdGVyUmVtb3ZlZCA9IHRoaXMuX2dyaWRzdGVyU3ZjLm9uR3JpZHN0ZXJSZW1vdmVkKCk7XHJcblxyXG4gICAgICAgIHRoaXMuX2dyaWRzdGVyU3ZjLnNldEVtaXR0ZXIodGhpcy5ncmlkc3Rlckl0ZW1SZXNpemUsIHRoaXMuZ2V0R3JpZHN0ZXJJdGVtKTtcclxuICAgIH1cclxuXHJcbiAgICBuZ09uRGVzdHJveSgpOiB2b2lkIHtcclxuICAgICAgICB0aGlzLmdyaWRzdGVyUmVtb3ZlZC5lbWl0KCk7XHJcbiAgICAgICAgdGhpcy5fZ3JpZHN0ZXJTdmMuZ3JpZHN0ZXJSZW1vdmVkKCk7XHJcbiAgICAgICAgdGhpcy5ncmlkc3RlckNvbnRhaW5lci5jbGVhcigpO1xyXG4gICAgfVxyXG5cclxuICAgIG5nT25DaGFuZ2VzKGNoYW5nZXM6IFNpbXBsZUNoYW5nZXMpOiB2b2lkIHtcclxuICAgICAgICAvLyBjb25zb2xlLmxvZygna2QgZ3JpZHN0ZXIsIGNoYW5nZXMnLCBjaGFuZ2VzKTtcclxuXHJcbiAgICAgICAgaWYgKGNoYW5nZXMuaGFzT3duUHJvcGVydHkoJ2NvbmZpZycpKSB7XHJcblxyXG4gICAgICAgICAgICBpZiAoIWNoYW5nZXMuY29uZmlnLmlzRmlyc3RDaGFuZ2UoKSkge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5fZ3JpZHN0ZXJJdGVtcyA9IFtdO1xyXG4gICAgICAgICAgICAgICAgdGhpcy5ncmlkc3RlckNvbnRhaW5lci5jbGVhcigpO1xyXG4gICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICAvLyBnZXQgZ3Jpc3RlciBjb25maWcgb25seVxyXG4gICAgICAgICAgICB0aGlzLmdyaWRzdGVyT3B0aW9ucyA9IHRoaXMuX2dyaWRzdGVyU3ZjLmdldENvbmZpZyhjaGFuZ2VzLmNvbmZpZy5jdXJyZW50VmFsdWUpO1xyXG4gICAgICAgICAgICB0aGlzLmdldENvbmZpZy5lbWl0KHRoaXMuZ3JpZHN0ZXJPcHRpb25zKTtcclxuXHJcbiAgICAgICAgICAgIGxldCBncmlkc3Rlckl0ZW1zID0gIHRoaXMuaXRlbXMuc2xpY2UoKTtcclxuXHJcbiAgICAgICAgICAgIC8vIGxvYWQgaW4gdGhlIGRlZmF1bHQgZ3JpZHN0ZXJJdGVtc1xyXG4gICAgICAgICAgICBmb3IgKGxldCBpdGVtIG9mIGdyaWRzdGVySXRlbXMpIHtcclxuICAgICAgICAgICAgICAgIGxldCBuZXdJdGVtOiBHcmlkc3Rlckl0ZW0gPSB0aGlzLmdldFZhbGlkSXRlbShpdGVtKTtcclxuICAgICAgICAgICAgICAgIGlmICh0eXBlb2YgbmV3SXRlbS5lbmFibGVDb250ZW50RHJhZyA9PT0gJ3VuZGVmaW5lZCcpIG5ld0l0ZW0uZW5hYmxlQ29udGVudERyYWcgPSB0cnVlO1xyXG4gICAgICAgICAgICAgICAgdGhpcy5hZGRHcmlkc3Rlckl0ZW0obmV3SXRlbSk7XHJcbiAgICAgICAgICAgICAgICB0aGlzLl9ncmlkc3Rlckl0ZW1zLnB1c2gobmV3SXRlbSk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgLyoqXHJcbiAgICAgKiByZW1vdmUgaXRlbSBmcm9tIHJlYWR5IGxpc3QsIGl0ZW0gbGlzdCBhbmQgY29udGFpbmVyXHJcbiAgICAgKiAgX2lkIGl0ZW0uaWRcclxuICAgICAqL1xyXG4gICAgcHJpdmF0ZSBfcmVtb3ZlR3JpZHN0ZXJJdGVtKF9pZDogc3RyaW5nKTogdm9pZCB7XHJcbiAgICAgICAgZm9yIChsZXQgaSA9IHRoaXMuX2dyaWRzdGVySXRlbXMubGVuZ3RoIC0gMTsgaSA+PSAwOyBpLS0pIHtcclxuICAgICAgICAgICAgaWYgKHRoaXMuX2dyaWRzdGVySXRlbXNbaV0uaWQgPT09IF9pZCkge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5fZ3JpZHN0ZXJJdGVtcy5zcGxpY2UoaSwgMSk7XHJcbiAgICAgICAgICAgICAgICBpZiAoIXRoaXMuY29uZmlnLmVuYWJsZURvd25ncmFkZSkgdGhpcy5ncmlkc3RlckNvbnRhaW5lci5yZW1vdmUoaSk7XHJcbiAgICAgICAgICAgICAgICBicmVhaztcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICAvKipcclxuICAgICAqIGNoZWNrIGlmIGdyaWRzdGVySXRlbSBjYW4gYmUgYWRkZWQgaW4gdGhlIHBvc2l0aW9uIHNwZWNpZmllZFxyXG4gICAgICogX2l0ZW0gSUdyaWRzdGVySXRlbVxyXG4gICAgICovXHJcbiAgICBwcml2YXRlIGdldFZhbGlkSXRlbShfaXRlbTogSUdyaWRzdGVySXRlbSk6IEdyaWRzdGVySXRlbSB7XHJcbiAgICAgICAgbGV0IG5ld0l0ZW06IEdyaWRzdGVySXRlbSA9IE9iamVjdC5hc3NpZ24oe3g6IC0xLCB5OiAtMSwgY29sczogLTEsIHJvd3M6IC0xfSwgX2l0ZW0pO1xyXG4gICAgICAgIGlmICh0eXBlb2YgX2l0ZW0ueCA9PT0gJ3VuZGVmaW5lZCcgfHwgdHlwZW9mIF9pdGVtLnkgPT09ICd1bmRlZmluZWQnKSB7XHJcbiAgICAgICAgICAgICg8YW55Pk9iamVjdCkuYXNzaWduKG5ld0l0ZW0sIHRoaXMuZ3JpZHN0ZXJPcHRpb25zLmFwaS5nZXRGaXJzdFBvc3NpYmxlUG9zaXRpb24obmV3SXRlbSkpO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgaWYgKChuZXdJdGVtLnggKyBuZXdJdGVtLmNvbHMpID4gdGhpcy5ncmlkc3Rlck9wdGlvbnMubWF4Q29scyB8fCAobmV3SXRlbS55ICsgbmV3SXRlbS5yb3dzKSA+IHRoaXMuZ3JpZHN0ZXJPcHRpb25zLm1heFJvd3MpIHtcclxuICAgICAgICAgICAgcmV0dXJuO1xyXG4gICAgICAgIH1cclxuICAgICAgICByZXR1cm4gbmV3SXRlbTtcclxuICAgIH1cclxuXHJcbiAgICAvKipcclxuICAgICAqIGFkZCB0ZW1wbGF0ZSBvZiA8Z3JpZHN0ZXItaXRlbT4gaW50byA8Z3JpZHN0ZXI+XHJcbiAgICAgKiAgX2l0ZW0gW2Rlc2NyaXB0aW9uXVxyXG4gICAgICovXHJcbiAgICBwcml2YXRlIGFkZEdyaWRzdGVySXRlbShfaXRlbTogR3JpZHN0ZXJJdGVtKTogdm9pZCB7XHJcbiAgICAgICAgaWYgKHRoaXMuY29uZmlnLmVuYWJsZURvd25ncmFkZSkgcmV0dXJuO1xyXG4gICAgICAgIHNldFRpbWVvdXQoKCkgPT4gdGhpcy5ncmlkc3RlckNvbnRhaW5lci5jcmVhdGVFbWJlZGRlZFZpZXcodGhpcy5ncmlkc3Rlckl0ZW1UZW1wbGF0ZSwgeyBpdGVtOiBfaXRlbSwgZ3JpZHN0ZXJPcHRpb25zOiB0aGlzLmdyaWRzdGVyT3B0aW9ucyB9KSk7XHJcbiAgICB9XHJcbn1cclxuIl19