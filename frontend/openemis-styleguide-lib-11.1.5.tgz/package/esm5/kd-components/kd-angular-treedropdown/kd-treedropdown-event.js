import { __decorate, __metadata } from "tslib";
import { Injectable } from '@angular/core';
import { KdBroadcaster } from '../kd-common/index';
import * as i0 from "@angular/core";
import * as i1 from "../kd-common/kd-broadcaster-svc";
var KdTreeDropdownEvent = /** @class */ (function () {
    function KdTreeDropdownEvent(_broadcaster) {
        this._broadcaster = _broadcaster;
    }
    KdTreeDropdownEvent.prototype.childExpand = function (data) {
        this._broadcaster.broadcast('KDTreeDropdown_ChildData', data);
    };
    KdTreeDropdownEvent.prototype.onChildNodeExpand = function () {
        return this._broadcaster.on('KDTreeDropdown_ChildData');
    };
    KdTreeDropdownEvent.prototype.loadList = function (data) {
        this._broadcaster.broadcast('KDTreeDropdown_ParentData', data);
    };
    KdTreeDropdownEvent.prototype.onLoadList = function () {
        return this._broadcaster.on('KDTreeDropdown_ParentData');
    };
    KdTreeDropdownEvent.ctorParameters = function () { return [
        { type: KdBroadcaster }
    ]; };
    KdTreeDropdownEvent.ɵprov = i0.ɵɵdefineInjectable({ factory: function KdTreeDropdownEvent_Factory() { return new KdTreeDropdownEvent(i0.ɵɵinject(i1.KdBroadcaster)); }, token: KdTreeDropdownEvent, providedIn: "root" });
    KdTreeDropdownEvent = __decorate([
        Injectable({
            providedIn: 'root'
        }),
        __metadata("design:paramtypes", [KdBroadcaster])
    ], KdTreeDropdownEvent);
    return KdTreeDropdownEvent;
}());
export { KdTreeDropdownEvent };
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoia2QtdHJlZWRyb3Bkb3duLWV2ZW50LmpzIiwic291cmNlUm9vdCI6Im5nOi8vb3BlbmVtaXMtc3R5bGVndWlkZS1saWIvIiwic291cmNlcyI6WyJrZC1jb21wb25lbnRzL2tkLWFuZ3VsYXItdHJlZWRyb3Bkb3duL2tkLXRyZWVkcm9wZG93bi1ldmVudC50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiO0FBQUEsT0FBTyxFQUFFLFVBQVUsRUFBRSxNQUFNLGVBQWUsQ0FBQztBQUUzQyxPQUFPLEVBQUUsYUFBYSxFQUFFLE1BQU0sb0JBQW9CLENBQUM7OztBQUtuRDtJQUNJLDZCQUFvQixZQUEyQjtRQUEzQixpQkFBWSxHQUFaLFlBQVksQ0FBZTtJQUFJLENBQUM7SUFFcEQseUNBQVcsR0FBWCxVQUFZLElBQVM7UUFDakIsSUFBSSxDQUFDLFlBQVksQ0FBQyxTQUFTLENBQUMsMEJBQTBCLEVBQUUsSUFBSSxDQUFDLENBQUM7SUFDbEUsQ0FBQztJQUVELCtDQUFpQixHQUFqQjtRQUNJLE9BQU8sSUFBSSxDQUFDLFlBQVksQ0FBQyxFQUFFLENBQU0sMEJBQTBCLENBQUMsQ0FBQztJQUNqRSxDQUFDO0lBRUQsc0NBQVEsR0FBUixVQUFTLElBQVM7UUFDZCxJQUFJLENBQUMsWUFBWSxDQUFDLFNBQVMsQ0FBQywyQkFBMkIsRUFBRSxJQUFJLENBQUMsQ0FBQztJQUNuRSxDQUFDO0lBRUQsd0NBQVUsR0FBVjtRQUNJLE9BQU8sSUFBSSxDQUFDLFlBQVksQ0FBQyxFQUFFLENBQU0sMkJBQTJCLENBQUMsQ0FBQztJQUNsRSxDQUFDOztnQkFoQmlDLGFBQWE7OztJQUR0QyxtQkFBbUI7UUFIL0IsVUFBVSxDQUFDO1lBQ1IsVUFBVSxFQUFFLE1BQU07U0FDckIsQ0FBQzt5Q0FFb0MsYUFBYTtPQUR0QyxtQkFBbUIsQ0FrQi9COzhCQXpCRDtDQXlCQyxBQWxCRCxJQWtCQztTQWxCWSxtQkFBbUIiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBJbmplY3RhYmxlIH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XHJcbmltcG9ydCB7IE9ic2VydmFibGUgfSBmcm9tICdyeGpzJztcclxuaW1wb3J0IHsgS2RCcm9hZGNhc3RlciB9IGZyb20gJy4uL2tkLWNvbW1vbi9pbmRleCc7XHJcblxyXG5ASW5qZWN0YWJsZSh7XHJcbiAgICBwcm92aWRlZEluOiAncm9vdCdcclxufSlcclxuZXhwb3J0IGNsYXNzIEtkVHJlZURyb3Bkb3duRXZlbnQge1xyXG4gICAgY29uc3RydWN0b3IocHJpdmF0ZSBfYnJvYWRjYXN0ZXI6IEtkQnJvYWRjYXN0ZXIpIHsgfVxyXG5cclxuICAgIGNoaWxkRXhwYW5kKGRhdGE6IGFueSk6IHZvaWQge1xyXG4gICAgICAgIHRoaXMuX2Jyb2FkY2FzdGVyLmJyb2FkY2FzdCgnS0RUcmVlRHJvcGRvd25fQ2hpbGREYXRhJywgZGF0YSk7XHJcbiAgICB9XHJcblxyXG4gICAgb25DaGlsZE5vZGVFeHBhbmQoKTogT2JzZXJ2YWJsZTxhbnk+IHtcclxuICAgICAgICByZXR1cm4gdGhpcy5fYnJvYWRjYXN0ZXIub248YW55PignS0RUcmVlRHJvcGRvd25fQ2hpbGREYXRhJyk7XHJcbiAgICB9XHJcblxyXG4gICAgbG9hZExpc3QoZGF0YTogYW55KTogdm9pZCB7XHJcbiAgICAgICAgdGhpcy5fYnJvYWRjYXN0ZXIuYnJvYWRjYXN0KCdLRFRyZWVEcm9wZG93bl9QYXJlbnREYXRhJywgZGF0YSk7XHJcbiAgICB9XHJcblxyXG4gICAgb25Mb2FkTGlzdCgpOiBPYnNlcnZhYmxlPGFueT4ge1xyXG4gICAgICAgIHJldHVybiB0aGlzLl9icm9hZGNhc3Rlci5vbjxhbnk+KCdLRFRyZWVEcm9wZG93bl9QYXJlbnREYXRhJyk7XHJcbiAgICB9XHJcbn1cclxuIl19