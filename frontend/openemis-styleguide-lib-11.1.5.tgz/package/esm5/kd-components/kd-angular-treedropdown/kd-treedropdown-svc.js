import { __decorate } from "tslib";
import { Injectable } from '@angular/core';
var KdTreeDropdownSvc = /** @class */ (function () {
    function KdTreeDropdownSvc() {
    }
    /**
     * change config to primeng readable tree data
     *
     * config      : [data pass from example]
     * mode        : [mode of the dropdown checkbox/multiple or radio/single]
     * isChildData : [for lazy load. as we need to convert child data from example to be TreeNode readable by primeng tree
     *                     plugin, we will need a flag to decide which data to be convert. whether it is the config.list (for
     *                     config) or just config (for child data)]
     *
     */
    KdTreeDropdownSvc.prototype.getUpdateNode = function (config, mode, isChildData) {
        var tempData = [];
        if (typeof config !== 'undefined' && typeof config.list !== 'undefined')
            tempData = this._cloneNewArray(config.list);
        else if (typeof isChildData !== 'undefined' && isChildData)
            tempData = this._cloneNewArray(config);
        else
            return tempData;
        var updatedData = [];
        if (mode === 'multiple')
            updatedData = this._getExpandedBool(tempData, mode);
        else
            updatedData = this._getExpandedBool(tempData, mode, false);
        return updatedData;
    };
    /**
     * get the treedropdown input type whether it is checkbox or radio
     *
     * config    : [data pass from example]
     *
     */
    KdTreeDropdownSvc.prototype.getMode = function (config) {
        if (typeof config === 'undefined' ||
            typeof config.selectionMode === 'undefined' ||
            (config.selectionMode === 'multiple' || config.selectionMode === 'single'))
            return config.selectionMode;
        return 'single';
    };
    /**
     * get the selected value. if it is checkbox, add in the selected data, if it is radio, replace the selected data
     *
     * currentSelected    : [previously selected data]
     * selectNode         : [selected node primeng data]
     * mode               : [checkbox/radio | multiple/single]
     * return format      : [{ id, name, selected: true }]
     */
    KdTreeDropdownSvc.prototype.updateSelectedNodes = function (currentSelected, selectNode, mode) {
        var updateArray = [];
        if (mode === 'multiple')
            updateArray = this._checkCheckbox(currentSelected, selectNode);
        else if (selectNode.data.selected)
            updateArray.push(selectNode.data);
        return updateArray;
    };
    /**
     * if selected, add data into selected array, else remove from array
     *
     * currentSelected    : [selected data: { id, name, selected: true }]
     * selectNode         : [selected node (primeng node)]
     *
     */
    KdTreeDropdownSvc.prototype._checkCheckbox = function (currentSelected, selectNode) {
        var updatedArray = currentSelected.slice(0) || [];
        if (selectNode.data.selected)
            updatedArray.push(selectNode.data);
        else {
            for (var i = 0; i < currentSelected.length; i++) {
                if (selectNode.data.id === currentSelected[i].id) {
                    updatedArray.splice(i, 1);
                    break;
                }
            }
        }
        return updatedArray;
    };
    /**
     * Update the selected data
     *
     * currentData    : [all data]
     * mode           : [checkbox/radio | multiple/single]
     *
     */
    KdTreeDropdownSvc.prototype.updateInitSelected = function (currentData, mode) {
        var updatedData = [];
        if (mode === 'multiple')
            updatedData = this.getInitSelected(updatedData, currentData);
        else
            updatedData = this.getInitSelected(updatedData, currentData, false);
        return updatedData;
    };
    /**
     * Change dropdown label. Either "Please select" or number of item selected
     *
     * selectedNodes    : [selected data]
     *
     */
    KdTreeDropdownSvc.prototype.updateSelectedString = function (selectedNodes) {
        if (typeof selectedNodes === 'undefined' || selectedNodes.length === 0)
            return 'Please select';
        else if (selectedNodes.length === 1)
            return selectedNodes[0].name;
        else
            return selectedNodes.length + ' items selected';
    };
    /**
     * check if the mouse/touch is within the dropdown list (option list) box
     *
     * state         : [blur: click or scroll]
     * position      : [position of the mouse/touch]
     * id            : [tree id]
     * currentEle    : [dropdown list]
     *
     */
    KdTreeDropdownSvc.prototype.checkWithinBoundingBox = function (state, position, id, currentEle) {
        var queryString = '.' + id + '.kdx-popover-window';
        var popoverWindow = document.querySelector(queryString);
        var popoverWindowRect = popoverWindow.getBoundingClientRect();
        if (popoverWindow === null)
            return false;
        var boundingRect = {
            top: (state === 'blur') ? currentEle.getBoundingClientRect().top : popoverWindowRect.top,
            bottom: popoverWindowRect.bottom,
            right: popoverWindowRect.right,
            left: popoverWindowRect.left
        };
        if (position.x > boundingRect.left && position.x < boundingRect.right &&
            position.y > boundingRect.top && position.y < boundingRect.bottom)
            return true;
        return false;
    };
    /**
     * get position for the mouse/touch  in x and y
     *
     * e    : [mouse/touch event]
     *
     */
    KdTreeDropdownSvc.prototype.getTouchPosition = function (e) {
        var position = { x: 0, y: 0 };
        try {
            position.x = e.touches[0].clientX;
            position.y = e.touches[0].clientY;
        }
        catch (err) {
            position.x = e.targetTouches[0].clientX;
            position.y = e.targetTouches[0].clientY;
        }
        return position;
    };
    /**
     * When first load, get the selected data. if mode is radio, only return the first data that is selected in the current Array.
     * Previous selected data or the following selected data will be removed.
     *
     * selectedArray    : [selected array either empty or array of data for multiple selection mode]
     * currentArray     : [all data]
     * isSingleFound    : [if radio/single mode, true else undefined]
     */
    KdTreeDropdownSvc.prototype.getInitSelected = function (selectedArray, currentArray, isSingleFound) {
        var updatedArray = selectedArray.slice(0);
        var loopSingleFound = undefined;
        if (typeof isSingleFound !== 'undefined')
            loopSingleFound = isSingleFound;
        for (var i = 0; i < currentArray.length; i++) {
            if (loopSingleFound)
                break;
            if (currentArray[i].data.selected) {
                updatedArray.push(currentArray[i].data);
                if (typeof isSingleFound !== 'undefined')
                    loopSingleFound = true;
            }
            if (typeof currentArray[i].children !== 'undefined')
                updatedArray = this.getInitSelected(updatedArray, currentArray[i].children, loopSingleFound);
        }
        return updatedArray;
    };
    /**
     * do a copy of array
     *
     * oldArray    : [array that you would like to copy]
     *
     */
    KdTreeDropdownSvc.prototype._cloneNewArray = function (oldArray) {
        var newArray = [];
        for (var i = 0; i < oldArray.length; i++) {
            var item = Object.assign({}, oldArray[i]);
            item.data = Object.assign({}, oldArray[i].data);
            if (typeof oldArray[i].children !== 'undefined')
                item.children = this._cloneNewArray(oldArray[i].children);
            newArray.push(item);
        }
        return newArray;
    };
    /**
     * set all data as not expanded and convert all data into primeng tree plugin readable data
     *
     * _currentData      : [all data]
     * _mode             : [checkbox/radio | single/multiple ]
     * _isSingleSelected :
     *
     */
    KdTreeDropdownSvc.prototype._getExpandedBool = function (_currentData, _mode, _isSingleSelected) {
        var isSingleFound = _isSingleSelected;
        var updatedData = _currentData.slice(0);
        for (var i = 0; i < updatedData.length; i++) {
            updatedData[i].label = _currentData[i].data.name;
            if (typeof updatedData[i].children !== 'undefined') {
                updatedData[i].expanded = false;
                updatedData[i].children = this._getExpandedBool(updatedData[i].children, _mode, isSingleFound);
            }
            updatedData[i].type = (_mode === 'multiple') ? 'checkbox' : 'radio';
            if (typeof updatedData[i].data.selected === 'undefined')
                updatedData[i].data.selected = false;
            else if (updatedData[i].data.selected && typeof isSingleFound !== 'undefined') {
                if (!isSingleFound)
                    isSingleFound = true;
                else
                    updatedData[i].data.selected = false;
            }
        }
        return updatedData;
    };
    /**
     * error prevention set false if data passed in is undefined. leave the data as it is if it is not undefined
     *
     * config     : [config]
     * setting    : [any setting. can be mode, can be expandSelected or expandAll]
     *
     */
    KdTreeDropdownSvc.prototype.getSetting = function (config, setting) {
        if (typeof config === 'undefined' ||
            typeof config[setting] === 'undefined')
            return false;
        return config[setting];
    };
    /**
     * for expandAll. expand the data as long as there is a child data
     *
     * _list    : [config list]
     */
    KdTreeDropdownSvc.prototype._expandList = function (_list) {
        var vm = this;
        _list.forEach(function (item) {
            item.expanded = true;
            if (item.children) {
                vm._expandList(item.children);
            }
        });
    };
    /**
     * only expand the parent data if the child value is selected
     *
     * _list : [config list]
     */
    KdTreeDropdownSvc.prototype._expandSelected = function (_list) {
        var isChildSelected;
        for (var i = 0; i < _list.length; i++) {
            var item = _list[i];
            isChildSelected = false;
            if (item.children) {
                isChildSelected = this._expandChildList(item.children);
                item.expanded = isChildSelected;
            }
            else {
                continue;
            }
        }
    };
    /**
     * main purpose is to return true if there is a selected data. this loop should loop
     * through all the way until the last child item at the same time, every single loop,
     * it should set the layer above the current child list to expand true if the current
     * child list is selected
     *
     * _list :
     *
     */
    KdTreeDropdownSvc.prototype._expandChildList = function (_list) {
        for (var x = 0; x < _list.length; x++) {
            var childItem = _list[x];
            if (childItem.children) {
                var isChildSelected = this._expandChildList(childItem.children);
                childItem.expanded = isChildSelected;
                return isChildSelected;
            }
            else if (childItem.data.selected) {
                return childItem.data.selected;
            }
        }
        return false;
    };
    /**
     * main function to check and trigger whether to expand all or expand selected
     *
     * _config      : [config]
     * _updatedData : [primeng tree data]
     */
    KdTreeDropdownSvc.prototype.autoExpandList = function (_config, _updatedData) {
        var _expandAll = this.getSetting(_config, 'expandAll');
        var _expandSelected = this.getSetting(_config, 'expandSelected');
        if (typeof _expandAll !== 'undefined' || typeof _expandSelected !== 'undefined') {
            if (_expandAll === 'true' || _expandAll) {
                this._expandList(_updatedData);
            }
            else if (_expandSelected === 'true' || _expandSelected) {
                this._expandSelected(_updatedData);
            }
        }
    };
    /**
     * used when adding child data manually during child data lazy load. when user click to expand child list
     * the example will pass in child data which is not to the primeng tree plugin readable data
     *
     * _id             :
     * _childData      :
     * _updatedData    :
     * mode            :
     *
     */
    KdTreeDropdownSvc.prototype.updateConfig = function (_id, _childData, _updatedData, mode) {
        for (var i = 0; i < _updatedData.length; i++) {
            var configList = _updatedData[i];
            if (configList.data.id === _id) {
                if (typeof configList.children === 'undefined') {
                    configList.children = [];
                }
                configList.children = this.getUpdateNode(_childData, mode, true);
                break;
            }
            else {
                if (configList.hasOwnProperty('children')) {
                    this.updateConfig(_id, _childData, configList.children, mode);
                }
            }
        }
        return this.updateInitSelected(_updatedData, mode);
    };
    KdTreeDropdownSvc = __decorate([
        Injectable()
    ], KdTreeDropdownSvc);
    return KdTreeDropdownSvc;
}());
export { KdTreeDropdownSvc };
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoia2QtdHJlZWRyb3Bkb3duLXN2Yy5qcyIsInNvdXJjZVJvb3QiOiJuZzovL29wZW5lbWlzLXN0eWxlZ3VpZGUtbGliLyIsInNvdXJjZXMiOlsia2QtY29tcG9uZW50cy9rZC1hbmd1bGFyLXRyZWVkcm9wZG93bi9rZC10cmVlZHJvcGRvd24tc3ZjLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7QUFBQSxPQUFPLEVBQUUsVUFBVSxFQUFFLE1BQU0sZUFBZSxDQUFDO0FBSTNDO0lBQUE7SUEyVUEsQ0FBQztJQTFVRzs7Ozs7Ozs7O09BU0c7SUFDSCx5Q0FBYSxHQUFiLFVBQWMsTUFBVyxFQUFFLElBQVksRUFBRSxXQUFxQjtRQUMxRCxJQUFJLFFBQVEsR0FBb0IsRUFBRSxDQUFDO1FBQ25DLElBQUksT0FBTyxNQUFNLEtBQUssV0FBVyxJQUFJLE9BQU8sTUFBTSxDQUFDLElBQUksS0FBSyxXQUFXO1lBQUUsUUFBUSxHQUFHLElBQUksQ0FBQyxjQUFjLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxDQUFDO2FBQ2hILElBQUksT0FBTyxXQUFXLEtBQUssV0FBVyxJQUFJLFdBQVc7WUFBRSxRQUFRLEdBQUcsSUFBSSxDQUFDLGNBQWMsQ0FBQyxNQUFNLENBQUMsQ0FBQzs7WUFDOUYsT0FBTyxRQUFRLENBQUM7UUFFckIsSUFBSSxXQUFXLEdBQWUsRUFBRSxDQUFDO1FBQ2pDLElBQUksSUFBSSxLQUFLLFVBQVU7WUFBRSxXQUFXLEdBQUcsSUFBSSxDQUFDLGdCQUFnQixDQUFDLFFBQVEsRUFBRSxJQUFJLENBQUMsQ0FBQzs7WUFDeEUsV0FBVyxHQUFHLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxRQUFRLEVBQUUsSUFBSSxFQUFFLEtBQUssQ0FBQyxDQUFDO1FBQ2hFLE9BQU8sV0FBVyxDQUFDO0lBQ3ZCLENBQUM7SUFFRDs7Ozs7T0FLRztJQUNILG1DQUFPLEdBQVAsVUFBUSxNQUFXO1FBQ2YsSUFDSSxPQUFPLE1BQU0sS0FBSyxXQUFXO1lBQzdCLE9BQU8sTUFBTSxDQUFDLGFBQWEsS0FBSyxXQUFXO1lBQzNDLENBQUMsTUFBTSxDQUFDLGFBQWEsS0FBSyxVQUFVLElBQUksTUFBTSxDQUFDLGFBQWEsS0FBSyxRQUFRLENBQUM7WUFDNUUsT0FBTyxNQUFNLENBQUMsYUFBYSxDQUFDO1FBQzlCLE9BQU8sUUFBUSxDQUFDO0lBQ3BCLENBQUM7SUFFRDs7Ozs7OztPQU9HO0lBQ0gsK0NBQW1CLEdBQW5CLFVBQW9CLGVBQTJCLEVBQUUsVUFBZSxFQUFFLElBQVk7UUFDMUUsSUFBSSxXQUFXLEdBQWUsRUFBRSxDQUFDO1FBQ2pDLElBQUksSUFBSSxLQUFLLFVBQVU7WUFBRSxXQUFXLEdBQUcsSUFBSSxDQUFDLGNBQWMsQ0FBQyxlQUFlLEVBQUUsVUFBVSxDQUFDLENBQUM7YUFDbkYsSUFBSSxVQUFVLENBQUMsSUFBSSxDQUFDLFFBQVE7WUFBRSxXQUFXLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxJQUFJLENBQUMsQ0FBQztRQUNyRSxPQUFPLFdBQVcsQ0FBQztJQUN2QixDQUFDO0lBRUQ7Ozs7OztPQU1HO0lBQ0ssMENBQWMsR0FBdEIsVUFBdUIsZUFBMkIsRUFBRSxVQUFlO1FBQy9ELElBQUksWUFBWSxHQUFlLGVBQWUsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLElBQUksRUFBRSxDQUFDO1FBQzlELElBQUksVUFBVSxDQUFDLElBQUksQ0FBQyxRQUFRO1lBQUUsWUFBWSxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsSUFBSSxDQUFDLENBQUM7YUFDNUQ7WUFDRCxLQUFLLElBQUksQ0FBQyxHQUFXLENBQUMsRUFBRSxDQUFDLEdBQUcsZUFBZSxDQUFDLE1BQU0sRUFBRSxDQUFDLEVBQUUsRUFBRTtnQkFDckQsSUFBSSxVQUFVLENBQUMsSUFBSSxDQUFDLEVBQUUsS0FBSyxlQUFlLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxFQUFFO29CQUM5QyxZQUFZLENBQUMsTUFBTSxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQztvQkFDMUIsTUFBTTtpQkFDVDthQUNKO1NBQ0o7UUFDRCxPQUFPLFlBQVksQ0FBQztJQUN4QixDQUFDO0lBRUQ7Ozs7OztPQU1HO0lBQ0gsOENBQWtCLEdBQWxCLFVBQW1CLFdBQXVCLEVBQUUsSUFBWTtRQUNwRCxJQUFJLFdBQVcsR0FBZSxFQUFFLENBQUM7UUFDakMsSUFBSSxJQUFJLEtBQUssVUFBVTtZQUFFLFdBQVcsR0FBRyxJQUFJLENBQUMsZUFBZSxDQUFDLFdBQVcsRUFBRSxXQUFXLENBQUMsQ0FBQzs7WUFDakYsV0FBVyxHQUFHLElBQUksQ0FBQyxlQUFlLENBQUMsV0FBVyxFQUFFLFdBQVcsRUFBRSxLQUFLLENBQUMsQ0FBQztRQUN6RSxPQUFPLFdBQVcsQ0FBQztJQUN2QixDQUFDO0lBRUQ7Ozs7O09BS0c7SUFDSCxnREFBb0IsR0FBcEIsVUFBcUIsYUFBeUI7UUFDMUMsSUFBSSxPQUFPLGFBQWEsS0FBSyxXQUFXLElBQUksYUFBYSxDQUFDLE1BQU0sS0FBSyxDQUFDO1lBQUUsT0FBTyxlQUFlLENBQUM7YUFDMUYsSUFBSSxhQUFhLENBQUMsTUFBTSxLQUFLLENBQUM7WUFBRSxPQUFPLGFBQWEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUM7O1lBQzdELE9BQU8sYUFBYSxDQUFDLE1BQU0sR0FBRyxpQkFBaUIsQ0FBQztJQUN6RCxDQUFDO0lBRUQ7Ozs7Ozs7O09BUUc7SUFDSCxrREFBc0IsR0FBdEIsVUFBdUIsS0FBYSxFQUFFLFFBQWEsRUFBRSxFQUFVLEVBQUUsVUFBd0I7UUFDckYsSUFBSSxXQUFXLEdBQVcsR0FBRyxHQUFHLEVBQUUsR0FBRyxxQkFBcUIsQ0FBQztRQUMzRCxJQUFJLGFBQWEsR0FBWSxRQUFRLENBQUMsYUFBYSxDQUFDLFdBQVcsQ0FBQyxDQUFDO1FBQ2pFLElBQUksaUJBQWlCLEdBQWUsYUFBYSxDQUFDLHFCQUFxQixFQUFFLENBQUM7UUFDMUUsSUFBSSxhQUFhLEtBQUssSUFBSTtZQUFFLE9BQU8sS0FBSyxDQUFDO1FBQ3pDLElBQUksWUFBWSxHQUFRO1lBQ3BCLEdBQUcsRUFBRSxDQUFDLEtBQUssS0FBSyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsVUFBVSxDQUFDLHFCQUFxQixFQUFFLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxpQkFBaUIsQ0FBQyxHQUFHO1lBQ3hGLE1BQU0sRUFBRSxpQkFBaUIsQ0FBQyxNQUFNO1lBQ2hDLEtBQUssRUFBRSxpQkFBaUIsQ0FBQyxLQUFLO1lBQzlCLElBQUksRUFBRSxpQkFBaUIsQ0FBQyxJQUFJO1NBQy9CLENBQUM7UUFDRixJQUFJLFFBQVEsQ0FBQyxDQUFDLEdBQUcsWUFBWSxDQUFDLElBQUksSUFBSSxRQUFRLENBQUMsQ0FBQyxHQUFHLFlBQVksQ0FBQyxLQUFLO1lBQ2pFLFFBQVEsQ0FBQyxDQUFDLEdBQUcsWUFBWSxDQUFDLEdBQUcsSUFBSSxRQUFRLENBQUMsQ0FBQyxHQUFHLFlBQVksQ0FBQyxNQUFNO1lBQUUsT0FBTyxJQUFJLENBQUM7UUFDbkYsT0FBTyxLQUFLLENBQUM7SUFDakIsQ0FBQztJQUVEOzs7OztPQUtHO0lBQ0gsNENBQWdCLEdBQWhCLFVBQWlCLENBQWE7UUFDMUIsSUFBSSxRQUFRLEdBQVEsRUFBRSxDQUFDLEVBQUUsQ0FBQyxFQUFFLENBQUMsRUFBRSxDQUFDLEVBQUUsQ0FBQztRQUNuQyxJQUFJO1lBQ0EsUUFBUSxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQztZQUNsQyxRQUFRLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDO1NBQ3JDO1FBQUMsT0FBTyxHQUFHLEVBQUU7WUFDVixRQUFRLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxhQUFhLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDO1lBQ3hDLFFBQVEsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLGFBQWEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUM7U0FDM0M7UUFDRCxPQUFPLFFBQVEsQ0FBQztJQUNwQixDQUFDO0lBRUQ7Ozs7Ozs7T0FPRztJQUNLLDJDQUFlLEdBQXZCLFVBQXdCLGFBQXlCLEVBQUUsWUFBd0IsRUFBRSxhQUF1QjtRQUNoRyxJQUFJLFlBQVksR0FBZSxhQUFhLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDO1FBQ3RELElBQUksZUFBZSxHQUFZLFNBQVMsQ0FBQztRQUN6QyxJQUFJLE9BQU8sYUFBYSxLQUFLLFdBQVc7WUFBRSxlQUFlLEdBQUcsYUFBYSxDQUFDO1FBQzFFLEtBQUssSUFBSSxDQUFDLEdBQVcsQ0FBQyxFQUFFLENBQUMsR0FBRyxZQUFZLENBQUMsTUFBTSxFQUFFLENBQUMsRUFBRSxFQUFFO1lBQ2xELElBQUksZUFBZTtnQkFBRSxNQUFNO1lBQzNCLElBQUksWUFBWSxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxRQUFRLEVBQUU7Z0JBQy9CLFlBQVksQ0FBQyxJQUFJLENBQUMsWUFBWSxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDO2dCQUN4QyxJQUFJLE9BQU8sYUFBYSxLQUFLLFdBQVc7b0JBQUUsZUFBZSxHQUFHLElBQUksQ0FBQzthQUNwRTtZQUNELElBQUksT0FBTyxZQUFZLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxLQUFLLFdBQVc7Z0JBQUUsWUFBWSxHQUFHLElBQUksQ0FBQyxlQUFlLENBQUMsWUFBWSxFQUFFLFlBQVksQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLEVBQUUsZUFBZSxDQUFDLENBQUM7U0FDcko7UUFDRCxPQUFPLFlBQVksQ0FBQztJQUN4QixDQUFDO0lBRUQ7Ozs7O09BS0c7SUFDSywwQ0FBYyxHQUF0QixVQUF1QixRQUF5QjtRQUM1QyxJQUFJLFFBQVEsR0FBb0IsRUFBRSxDQUFDO1FBQ25DLEtBQUssSUFBSSxDQUFDLEdBQVcsQ0FBQyxFQUFFLENBQUMsR0FBRyxRQUFRLENBQUMsTUFBTSxFQUFFLENBQUMsRUFBRSxFQUFFO1lBQzlDLElBQUksSUFBSSxHQUFhLE1BQU0sQ0FBQyxNQUFNLENBQUMsRUFBRSxFQUFFLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO1lBQ3BELElBQUksQ0FBQyxJQUFJLEdBQUcsTUFBTSxDQUFDLE1BQU0sQ0FBQyxFQUFFLEVBQUUsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDO1lBQ2hELElBQUksT0FBTyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxLQUFLLFdBQVc7Z0JBQUUsSUFBSSxDQUFDLFFBQVEsR0FBRyxJQUFJLENBQUMsY0FBYyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQztZQUMzRyxRQUFRLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDO1NBQ3ZCO1FBQ0QsT0FBTyxRQUFRLENBQUM7SUFDcEIsQ0FBQztJQUVEOzs7Ozs7O09BT0c7SUFDSyw0Q0FBZ0IsR0FBeEIsVUFBeUIsWUFBNkIsRUFBRSxLQUFhLEVBQUUsaUJBQTJCO1FBQzlGLElBQUksYUFBYSxHQUFZLGlCQUFpQixDQUFDO1FBQy9DLElBQUksV0FBVyxHQUFvQixZQUFZLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDO1FBQ3pELEtBQUssSUFBSSxDQUFDLEdBQVcsQ0FBQyxFQUFFLENBQUMsR0FBRyxXQUFXLENBQUMsTUFBTSxFQUFFLENBQUMsRUFBRSxFQUFFO1lBQ2pELFdBQVcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLEdBQUcsWUFBWSxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUM7WUFDakQsSUFBSSxPQUFPLFdBQVcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLEtBQUssV0FBVyxFQUFFO2dCQUNoRCxXQUFXLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxHQUFHLEtBQUssQ0FBQztnQkFDaEMsV0FBVyxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsR0FBRyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsRUFBRSxLQUFLLEVBQUUsYUFBYSxDQUFDLENBQUM7YUFDbEc7WUFDRCxXQUFXLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxHQUFHLENBQUMsS0FBSyxLQUFLLFVBQVUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxVQUFVLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQztZQUNwRSxJQUFJLE9BQU8sV0FBVyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxRQUFRLEtBQUssV0FBVztnQkFBRSxXQUFXLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLFFBQVEsR0FBRyxLQUFLLENBQUM7aUJBQ3pGLElBQUksV0FBVyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxRQUFRLElBQUksT0FBTyxhQUFhLEtBQUssV0FBVyxFQUFFO2dCQUMzRSxJQUFJLENBQUMsYUFBYTtvQkFBRSxhQUFhLEdBQUcsSUFBSSxDQUFDOztvQkFDcEMsV0FBVyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxRQUFRLEdBQUcsS0FBSyxDQUFDO2FBQzdDO1NBQ0o7UUFDRCxPQUFPLFdBQVcsQ0FBQztJQUN2QixDQUFDO0lBR0Q7Ozs7OztPQU1HO0lBQ0gsc0NBQVUsR0FBVixVQUFXLE1BQVcsRUFBRSxPQUFlO1FBQ25DLElBQ0ksT0FBTyxNQUFNLEtBQUssV0FBVztZQUM3QixPQUFPLE1BQU0sQ0FBQyxPQUFPLENBQUMsS0FBSyxXQUFXO1lBQ3hDLE9BQU8sS0FBSyxDQUFDO1FBQ2YsT0FBTyxNQUFNLENBQUMsT0FBTyxDQUFDLENBQUM7SUFDM0IsQ0FBQztJQUVEOzs7O09BSUc7SUFDSyx1Q0FBVyxHQUFuQixVQUFvQixLQUFpQjtRQUNqQyxJQUFJLEVBQUUsR0FBc0IsSUFBSSxDQUFDO1FBQ2pDLEtBQUssQ0FBQyxPQUFPLENBQUMsVUFBUyxJQUFJO1lBQ3ZCLElBQUksQ0FBQyxRQUFRLEdBQUcsSUFBSSxDQUFDO1lBQ3JCLElBQUksSUFBSSxDQUFDLFFBQVEsRUFBRTtnQkFDZixFQUFFLENBQUMsV0FBVyxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsQ0FBQzthQUNqQztRQUNMLENBQUMsQ0FBQyxDQUFDO0lBQ1AsQ0FBQztJQUVEOzs7O09BSUc7SUFDSywyQ0FBZSxHQUF2QixVQUF3QixLQUFpQjtRQUNyQyxJQUFJLGVBQXdCLENBQUM7UUFDN0IsS0FBSyxJQUFJLENBQUMsR0FBVyxDQUFDLEVBQUUsQ0FBQyxHQUFHLEtBQUssQ0FBQyxNQUFNLEVBQUUsQ0FBQyxFQUFFLEVBQUU7WUFDM0MsSUFBSSxJQUFJLEdBQWEsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDO1lBQzlCLGVBQWUsR0FBRyxLQUFLLENBQUM7WUFDeEIsSUFBSSxJQUFJLENBQUMsUUFBUSxFQUFFO2dCQUNmLGVBQWUsR0FBRyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxDQUFDO2dCQUN2RCxJQUFJLENBQUMsUUFBUSxHQUFHLGVBQWUsQ0FBQzthQUNuQztpQkFBTTtnQkFDSCxTQUFTO2FBQ1o7U0FDSjtJQUNMLENBQUM7SUFFRDs7Ozs7Ozs7T0FRRztJQUNLLDRDQUFnQixHQUF4QixVQUF5QixLQUFpQjtRQUN0QyxLQUFLLElBQUksQ0FBQyxHQUFXLENBQUMsRUFBRSxDQUFDLEdBQUcsS0FBSyxDQUFDLE1BQU0sRUFBRSxDQUFDLEVBQUUsRUFBRTtZQUMzQyxJQUFJLFNBQVMsR0FBYSxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUM7WUFDbkMsSUFBSSxTQUFTLENBQUMsUUFBUSxFQUFFO2dCQUNwQixJQUFJLGVBQWUsR0FBWSxJQUFJLENBQUMsZ0JBQWdCLENBQUMsU0FBUyxDQUFDLFFBQVEsQ0FBQyxDQUFDO2dCQUN6RSxTQUFTLENBQUMsUUFBUSxHQUFHLGVBQWUsQ0FBQztnQkFDckMsT0FBTyxlQUFlLENBQUM7YUFDMUI7aUJBQU0sSUFBSSxTQUFTLENBQUMsSUFBSSxDQUFDLFFBQVEsRUFBRTtnQkFDaEMsT0FBTyxTQUFTLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQzthQUNsQztTQUNKO1FBQ0QsT0FBTyxLQUFLLENBQUM7SUFDakIsQ0FBQztJQUVEOzs7OztPQUtHO0lBQ0gsMENBQWMsR0FBZCxVQUFlLE9BQVksRUFBRSxZQUF3QjtRQUNqRCxJQUFJLFVBQVUsR0FBbUIsSUFBSSxDQUFDLFVBQVUsQ0FBQyxPQUFPLEVBQUUsV0FBVyxDQUFDLENBQUM7UUFDdkUsSUFBSSxlQUFlLEdBQW1CLElBQUksQ0FBQyxVQUFVLENBQUMsT0FBTyxFQUFFLGdCQUFnQixDQUFDLENBQUM7UUFDakYsSUFBSSxPQUFPLFVBQVUsS0FBSyxXQUFXLElBQUksT0FBTyxlQUFlLEtBQUssV0FBVyxFQUFFO1lBQzdFLElBQUksVUFBVSxLQUFLLE1BQU0sSUFBSSxVQUFVLEVBQUU7Z0JBQ3JDLElBQUksQ0FBQyxXQUFXLENBQUMsWUFBWSxDQUFDLENBQUM7YUFDbEM7aUJBQU0sSUFBSSxlQUFlLEtBQUssTUFBTSxJQUFJLGVBQWUsRUFBRTtnQkFDdEQsSUFBSSxDQUFDLGVBQWUsQ0FBQyxZQUFZLENBQUMsQ0FBQzthQUN0QztTQUNKO0lBQ0wsQ0FBQztJQUVEOzs7Ozs7Ozs7T0FTRztJQUNILHdDQUFZLEdBQVosVUFBYSxHQUFXLEVBQUUsVUFBeUIsRUFBRSxZQUF3QixFQUFFLElBQVk7UUFFdkYsS0FBSyxJQUFJLENBQUMsR0FBVyxDQUFDLEVBQUUsQ0FBQyxHQUFHLFlBQVksQ0FBQyxNQUFNLEVBQUUsQ0FBQyxFQUFFLEVBQUU7WUFFbEQsSUFBSSxVQUFVLEdBQWEsWUFBWSxDQUFDLENBQUMsQ0FBQyxDQUFDO1lBQzNDLElBQUksVUFBVSxDQUFDLElBQUksQ0FBQyxFQUFFLEtBQUssR0FBRyxFQUFFO2dCQUM1QixJQUFJLE9BQU8sVUFBVSxDQUFDLFFBQVEsS0FBSyxXQUFXLEVBQUU7b0JBQzVDLFVBQVUsQ0FBQyxRQUFRLEdBQUcsRUFBRSxDQUFDO2lCQUM1QjtnQkFDRCxVQUFVLENBQUMsUUFBUSxHQUFHLElBQUksQ0FBQyxhQUFhLENBQUMsVUFBVSxFQUFFLElBQUksRUFBRSxJQUFJLENBQUMsQ0FBQztnQkFDakUsTUFBTTthQUNUO2lCQUFNO2dCQUNILElBQUksVUFBVSxDQUFDLGNBQWMsQ0FBQyxVQUFVLENBQUMsRUFBRTtvQkFDdkMsSUFBSSxDQUFDLFlBQVksQ0FBQyxHQUFHLEVBQUUsVUFBVSxFQUFFLFVBQVUsQ0FBQyxRQUFRLEVBQUUsSUFBSSxDQUFDLENBQUM7aUJBQ2pFO2FBQ0o7U0FFSjtRQUNELE9BQU8sSUFBSSxDQUFDLGtCQUFrQixDQUFDLFlBQVksRUFBRSxJQUFJLENBQUMsQ0FBQztJQUN2RCxDQUFDO0lBMVVRLGlCQUFpQjtRQUQ3QixVQUFVLEVBQUU7T0FDQSxpQkFBaUIsQ0EyVTdCO0lBQUQsd0JBQUM7Q0FBQSxBQTNVRCxJQTJVQztTQTNVWSxpQkFBaUIiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBJbmplY3RhYmxlIH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XHJcbmltcG9ydCB7IFRyZWVOb2RlIH0gZnJvbSAncHJpbWVuZy9wcmltZW5nJztcclxuXHJcbkBJbmplY3RhYmxlKClcclxuZXhwb3J0IGNsYXNzIEtkVHJlZURyb3Bkb3duU3ZjIHtcclxuICAgIC8qKlxyXG4gICAgICogY2hhbmdlIGNvbmZpZyB0byBwcmltZW5nIHJlYWRhYmxlIHRyZWUgZGF0YVxyXG4gICAgICpcclxuICAgICAqIGNvbmZpZyAgICAgIDogW2RhdGEgcGFzcyBmcm9tIGV4YW1wbGVdXHJcbiAgICAgKiBtb2RlICAgICAgICA6IFttb2RlIG9mIHRoZSBkcm9wZG93biBjaGVja2JveC9tdWx0aXBsZSBvciByYWRpby9zaW5nbGVdXHJcbiAgICAgKiBpc0NoaWxkRGF0YSA6IFtmb3IgbGF6eSBsb2FkLiBhcyB3ZSBuZWVkIHRvIGNvbnZlcnQgY2hpbGQgZGF0YSBmcm9tIGV4YW1wbGUgdG8gYmUgVHJlZU5vZGUgcmVhZGFibGUgYnkgcHJpbWVuZyB0cmVlXHJcbiAgICAgKiAgICAgICAgICAgICAgICAgICAgIHBsdWdpbiwgd2Ugd2lsbCBuZWVkIGEgZmxhZyB0byBkZWNpZGUgd2hpY2ggZGF0YSB0byBiZSBjb252ZXJ0LiB3aGV0aGVyIGl0IGlzIHRoZSBjb25maWcubGlzdCAoZm9yXHJcbiAgICAgKiAgICAgICAgICAgICAgICAgICAgIGNvbmZpZykgb3IganVzdCBjb25maWcgKGZvciBjaGlsZCBkYXRhKV1cclxuICAgICAqIFxyXG4gICAgICovXHJcbiAgICBnZXRVcGRhdGVOb2RlKGNvbmZpZzogYW55LCBtb2RlOiBzdHJpbmcsIGlzQ2hpbGREYXRhPzogYm9vbGVhbik6IEFycmF5PFRyZWVOb2RlPiB7XHJcbiAgICAgICAgbGV0IHRlbXBEYXRhOiBBcnJheTxUcmVlTm9kZT4gPSBbXTtcclxuICAgICAgICBpZiAodHlwZW9mIGNvbmZpZyAhPT0gJ3VuZGVmaW5lZCcgJiYgdHlwZW9mIGNvbmZpZy5saXN0ICE9PSAndW5kZWZpbmVkJykgdGVtcERhdGEgPSB0aGlzLl9jbG9uZU5ld0FycmF5KGNvbmZpZy5saXN0KTtcclxuICAgICAgICBlbHNlIGlmICh0eXBlb2YgaXNDaGlsZERhdGEgIT09ICd1bmRlZmluZWQnICYmIGlzQ2hpbGREYXRhKSB0ZW1wRGF0YSA9IHRoaXMuX2Nsb25lTmV3QXJyYXkoY29uZmlnKTtcclxuICAgICAgICBlbHNlIHJldHVybiB0ZW1wRGF0YTtcclxuXHJcbiAgICAgICAgbGV0IHVwZGF0ZWREYXRhOiBBcnJheTxhbnk+ID0gW107XHJcbiAgICAgICAgaWYgKG1vZGUgPT09ICdtdWx0aXBsZScpIHVwZGF0ZWREYXRhID0gdGhpcy5fZ2V0RXhwYW5kZWRCb29sKHRlbXBEYXRhLCBtb2RlKTtcclxuICAgICAgICBlbHNlIHVwZGF0ZWREYXRhID0gdGhpcy5fZ2V0RXhwYW5kZWRCb29sKHRlbXBEYXRhLCBtb2RlLCBmYWxzZSk7XHJcbiAgICAgICAgcmV0dXJuIHVwZGF0ZWREYXRhO1xyXG4gICAgfVxyXG5cclxuICAgIC8qKlxyXG4gICAgICogZ2V0IHRoZSB0cmVlZHJvcGRvd24gaW5wdXQgdHlwZSB3aGV0aGVyIGl0IGlzIGNoZWNrYm94IG9yIHJhZGlvXHJcbiAgICAgKlxyXG4gICAgICogY29uZmlnICAgIDogW2RhdGEgcGFzcyBmcm9tIGV4YW1wbGVdXHJcbiAgICAgKiBcclxuICAgICAqL1xyXG4gICAgZ2V0TW9kZShjb25maWc6IGFueSk6IHN0cmluZyB7XHJcbiAgICAgICAgaWYgKFxyXG4gICAgICAgICAgICB0eXBlb2YgY29uZmlnID09PSAndW5kZWZpbmVkJyB8fFxyXG4gICAgICAgICAgICB0eXBlb2YgY29uZmlnLnNlbGVjdGlvbk1vZGUgPT09ICd1bmRlZmluZWQnIHx8XHJcbiAgICAgICAgICAgIChjb25maWcuc2VsZWN0aW9uTW9kZSA9PT0gJ211bHRpcGxlJyB8fCBjb25maWcuc2VsZWN0aW9uTW9kZSA9PT0gJ3NpbmdsZScpXHJcbiAgICAgICAgKSByZXR1cm4gY29uZmlnLnNlbGVjdGlvbk1vZGU7XHJcbiAgICAgICAgcmV0dXJuICdzaW5nbGUnO1xyXG4gICAgfVxyXG5cclxuICAgIC8qKlxyXG4gICAgICogZ2V0IHRoZSBzZWxlY3RlZCB2YWx1ZS4gaWYgaXQgaXMgY2hlY2tib3gsIGFkZCBpbiB0aGUgc2VsZWN0ZWQgZGF0YSwgaWYgaXQgaXMgcmFkaW8sIHJlcGxhY2UgdGhlIHNlbGVjdGVkIGRhdGFcclxuICAgICAqXHJcbiAgICAgKiBjdXJyZW50U2VsZWN0ZWQgICAgOiBbcHJldmlvdXNseSBzZWxlY3RlZCBkYXRhXVxyXG4gICAgICogc2VsZWN0Tm9kZSAgICAgICAgIDogW3NlbGVjdGVkIG5vZGUgcHJpbWVuZyBkYXRhXVxyXG4gICAgICogbW9kZSAgICAgICAgICAgICAgIDogW2NoZWNrYm94L3JhZGlvIHwgbXVsdGlwbGUvc2luZ2xlXVxyXG4gICAgICogcmV0dXJuIGZvcm1hdCAgICAgIDogW3sgaWQsIG5hbWUsIHNlbGVjdGVkOiB0cnVlIH1dXHJcbiAgICAgKi9cclxuICAgIHVwZGF0ZVNlbGVjdGVkTm9kZXMoY3VycmVudFNlbGVjdGVkOiBBcnJheTxhbnk+LCBzZWxlY3ROb2RlOiBhbnksIG1vZGU6IHN0cmluZyk6IEFycmF5PGFueT4ge1xyXG4gICAgICAgIGxldCB1cGRhdGVBcnJheTogQXJyYXk8YW55PiA9IFtdO1xyXG4gICAgICAgIGlmIChtb2RlID09PSAnbXVsdGlwbGUnKSB1cGRhdGVBcnJheSA9IHRoaXMuX2NoZWNrQ2hlY2tib3goY3VycmVudFNlbGVjdGVkLCBzZWxlY3ROb2RlKTtcclxuICAgICAgICBlbHNlIGlmIChzZWxlY3ROb2RlLmRhdGEuc2VsZWN0ZWQpIHVwZGF0ZUFycmF5LnB1c2goc2VsZWN0Tm9kZS5kYXRhKTtcclxuICAgICAgICByZXR1cm4gdXBkYXRlQXJyYXk7XHJcbiAgICB9XHJcblxyXG4gICAgLyoqXHJcbiAgICAgKiBpZiBzZWxlY3RlZCwgYWRkIGRhdGEgaW50byBzZWxlY3RlZCBhcnJheSwgZWxzZSByZW1vdmUgZnJvbSBhcnJheVxyXG4gICAgICpcclxuICAgICAqIGN1cnJlbnRTZWxlY3RlZCAgICA6IFtzZWxlY3RlZCBkYXRhOiB7IGlkLCBuYW1lLCBzZWxlY3RlZDogdHJ1ZSB9XVxyXG4gICAgICogc2VsZWN0Tm9kZSAgICAgICAgIDogW3NlbGVjdGVkIG5vZGUgKHByaW1lbmcgbm9kZSldXHJcbiAgICAgKiBcclxuICAgICAqL1xyXG4gICAgcHJpdmF0ZSBfY2hlY2tDaGVja2JveChjdXJyZW50U2VsZWN0ZWQ6IEFycmF5PGFueT4sIHNlbGVjdE5vZGU6IGFueSk6IEFycmF5PGFueT4ge1xyXG4gICAgICAgIGxldCB1cGRhdGVkQXJyYXk6IEFycmF5PGFueT4gPSBjdXJyZW50U2VsZWN0ZWQuc2xpY2UoMCkgfHwgW107XHJcbiAgICAgICAgaWYgKHNlbGVjdE5vZGUuZGF0YS5zZWxlY3RlZCkgdXBkYXRlZEFycmF5LnB1c2goc2VsZWN0Tm9kZS5kYXRhKTtcclxuICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgZm9yIChsZXQgaTogbnVtYmVyID0gMDsgaSA8IGN1cnJlbnRTZWxlY3RlZC5sZW5ndGg7IGkrKykge1xyXG4gICAgICAgICAgICAgICAgaWYgKHNlbGVjdE5vZGUuZGF0YS5pZCA9PT0gY3VycmVudFNlbGVjdGVkW2ldLmlkKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgdXBkYXRlZEFycmF5LnNwbGljZShpLCAxKTtcclxuICAgICAgICAgICAgICAgICAgICBicmVhaztcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgICAgICByZXR1cm4gdXBkYXRlZEFycmF5O1xyXG4gICAgfVxyXG5cclxuICAgIC8qKlxyXG4gICAgICogVXBkYXRlIHRoZSBzZWxlY3RlZCBkYXRhXHJcbiAgICAgKlxyXG4gICAgICogY3VycmVudERhdGEgICAgOiBbYWxsIGRhdGFdXHJcbiAgICAgKiBtb2RlICAgICAgICAgICA6IFtjaGVja2JveC9yYWRpbyB8IG11bHRpcGxlL3NpbmdsZV1cclxuICAgICAqIFxyXG4gICAgICovXHJcbiAgICB1cGRhdGVJbml0U2VsZWN0ZWQoY3VycmVudERhdGE6IEFycmF5PGFueT4sIG1vZGU6IHN0cmluZyk6IEFycmF5PGFueT4ge1xyXG4gICAgICAgIGxldCB1cGRhdGVkRGF0YTogQXJyYXk8YW55PiA9IFtdO1xyXG4gICAgICAgIGlmIChtb2RlID09PSAnbXVsdGlwbGUnKSB1cGRhdGVkRGF0YSA9IHRoaXMuZ2V0SW5pdFNlbGVjdGVkKHVwZGF0ZWREYXRhLCBjdXJyZW50RGF0YSk7XHJcbiAgICAgICAgZWxzZSB1cGRhdGVkRGF0YSA9IHRoaXMuZ2V0SW5pdFNlbGVjdGVkKHVwZGF0ZWREYXRhLCBjdXJyZW50RGF0YSwgZmFsc2UpO1xyXG4gICAgICAgIHJldHVybiB1cGRhdGVkRGF0YTtcclxuICAgIH1cclxuXHJcbiAgICAvKipcclxuICAgICAqIENoYW5nZSBkcm9wZG93biBsYWJlbC4gRWl0aGVyIFwiUGxlYXNlIHNlbGVjdFwiIG9yIG51bWJlciBvZiBpdGVtIHNlbGVjdGVkXHJcbiAgICAgKlxyXG4gICAgICogc2VsZWN0ZWROb2RlcyAgICA6IFtzZWxlY3RlZCBkYXRhXVxyXG4gICAgICogXHJcbiAgICAgKi9cclxuICAgIHVwZGF0ZVNlbGVjdGVkU3RyaW5nKHNlbGVjdGVkTm9kZXM6IEFycmF5PGFueT4pOiBzdHJpbmcge1xyXG4gICAgICAgIGlmICh0eXBlb2Ygc2VsZWN0ZWROb2RlcyA9PT0gJ3VuZGVmaW5lZCcgfHwgc2VsZWN0ZWROb2Rlcy5sZW5ndGggPT09IDApIHJldHVybiAnUGxlYXNlIHNlbGVjdCc7XHJcbiAgICAgICAgZWxzZSBpZiAoc2VsZWN0ZWROb2Rlcy5sZW5ndGggPT09IDEpIHJldHVybiBzZWxlY3RlZE5vZGVzWzBdLm5hbWU7XHJcbiAgICAgICAgZWxzZSByZXR1cm4gc2VsZWN0ZWROb2Rlcy5sZW5ndGggKyAnIGl0ZW1zIHNlbGVjdGVkJztcclxuICAgIH1cclxuXHJcbiAgICAvKipcclxuICAgICAqIGNoZWNrIGlmIHRoZSBtb3VzZS90b3VjaCBpcyB3aXRoaW4gdGhlIGRyb3Bkb3duIGxpc3QgKG9wdGlvbiBsaXN0KSBib3hcclxuICAgICAqXHJcbiAgICAgKiBzdGF0ZSAgICAgICAgIDogW2JsdXI6IGNsaWNrIG9yIHNjcm9sbF1cclxuICAgICAqIHBvc2l0aW9uICAgICAgOiBbcG9zaXRpb24gb2YgdGhlIG1vdXNlL3RvdWNoXVxyXG4gICAgICogaWQgICAgICAgICAgICA6IFt0cmVlIGlkXVxyXG4gICAgICogY3VycmVudEVsZSAgICA6IFtkcm9wZG93biBsaXN0XVxyXG4gICAgICogXHJcbiAgICAgKi9cclxuICAgIGNoZWNrV2l0aGluQm91bmRpbmdCb3goc3RhdGU6IHN0cmluZywgcG9zaXRpb246IGFueSwgaWQ6IHN0cmluZywgY3VycmVudEVsZT86IEhUTUxFbGVtZW50KTogYm9vbGVhbiB7XHJcbiAgICAgICAgbGV0IHF1ZXJ5U3RyaW5nOiBzdHJpbmcgPSAnLicgKyBpZCArICcua2R4LXBvcG92ZXItd2luZG93JztcclxuICAgICAgICBsZXQgcG9wb3ZlcldpbmRvdzogRWxlbWVudCA9IGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3IocXVlcnlTdHJpbmcpO1xyXG4gICAgICAgIGxldCBwb3BvdmVyV2luZG93UmVjdDogQ2xpZW50UmVjdCA9IHBvcG92ZXJXaW5kb3cuZ2V0Qm91bmRpbmdDbGllbnRSZWN0KCk7XHJcbiAgICAgICAgaWYgKHBvcG92ZXJXaW5kb3cgPT09IG51bGwpIHJldHVybiBmYWxzZTtcclxuICAgICAgICBsZXQgYm91bmRpbmdSZWN0OiBhbnkgPSB7XHJcbiAgICAgICAgICAgIHRvcDogKHN0YXRlID09PSAnYmx1cicpID8gY3VycmVudEVsZS5nZXRCb3VuZGluZ0NsaWVudFJlY3QoKS50b3AgOiBwb3BvdmVyV2luZG93UmVjdC50b3AsXHJcbiAgICAgICAgICAgIGJvdHRvbTogcG9wb3ZlcldpbmRvd1JlY3QuYm90dG9tLFxyXG4gICAgICAgICAgICByaWdodDogcG9wb3ZlcldpbmRvd1JlY3QucmlnaHQsXHJcbiAgICAgICAgICAgIGxlZnQ6IHBvcG92ZXJXaW5kb3dSZWN0LmxlZnRcclxuICAgICAgICB9O1xyXG4gICAgICAgIGlmIChwb3NpdGlvbi54ID4gYm91bmRpbmdSZWN0LmxlZnQgJiYgcG9zaXRpb24ueCA8IGJvdW5kaW5nUmVjdC5yaWdodCAmJlxyXG4gICAgICAgICAgICBwb3NpdGlvbi55ID4gYm91bmRpbmdSZWN0LnRvcCAmJiBwb3NpdGlvbi55IDwgYm91bmRpbmdSZWN0LmJvdHRvbSkgcmV0dXJuIHRydWU7XHJcbiAgICAgICAgcmV0dXJuIGZhbHNlO1xyXG4gICAgfVxyXG5cclxuICAgIC8qKlxyXG4gICAgICogZ2V0IHBvc2l0aW9uIGZvciB0aGUgbW91c2UvdG91Y2ggIGluIHggYW5kIHlcclxuICAgICAqXHJcbiAgICAgKiBlICAgIDogW21vdXNlL3RvdWNoIGV2ZW50XVxyXG4gICAgICogXHJcbiAgICAgKi9cclxuICAgIGdldFRvdWNoUG9zaXRpb24oZTogVG91Y2hFdmVudCk6IGFueSB7XHJcbiAgICAgICAgbGV0IHBvc2l0aW9uOiBhbnkgPSB7IHg6IDAsIHk6IDAgfTtcclxuICAgICAgICB0cnkge1xyXG4gICAgICAgICAgICBwb3NpdGlvbi54ID0gZS50b3VjaGVzWzBdLmNsaWVudFg7XHJcbiAgICAgICAgICAgIHBvc2l0aW9uLnkgPSBlLnRvdWNoZXNbMF0uY2xpZW50WTtcclxuICAgICAgICB9IGNhdGNoIChlcnIpIHtcclxuICAgICAgICAgICAgcG9zaXRpb24ueCA9IGUudGFyZ2V0VG91Y2hlc1swXS5jbGllbnRYO1xyXG4gICAgICAgICAgICBwb3NpdGlvbi55ID0gZS50YXJnZXRUb3VjaGVzWzBdLmNsaWVudFk7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIHJldHVybiBwb3NpdGlvbjtcclxuICAgIH1cclxuXHJcbiAgICAvKipcclxuICAgICAqIFdoZW4gZmlyc3QgbG9hZCwgZ2V0IHRoZSBzZWxlY3RlZCBkYXRhLiBpZiBtb2RlIGlzIHJhZGlvLCBvbmx5IHJldHVybiB0aGUgZmlyc3QgZGF0YSB0aGF0IGlzIHNlbGVjdGVkIGluIHRoZSBjdXJyZW50IEFycmF5LlxyXG4gICAgICogUHJldmlvdXMgc2VsZWN0ZWQgZGF0YSBvciB0aGUgZm9sbG93aW5nIHNlbGVjdGVkIGRhdGEgd2lsbCBiZSByZW1vdmVkLlxyXG4gICAgICpcclxuICAgICAqIHNlbGVjdGVkQXJyYXkgICAgOiBbc2VsZWN0ZWQgYXJyYXkgZWl0aGVyIGVtcHR5IG9yIGFycmF5IG9mIGRhdGEgZm9yIG11bHRpcGxlIHNlbGVjdGlvbiBtb2RlXVxyXG4gICAgICogY3VycmVudEFycmF5ICAgICA6IFthbGwgZGF0YV1cclxuICAgICAqIGlzU2luZ2xlRm91bmQgICAgOiBbaWYgcmFkaW8vc2luZ2xlIG1vZGUsIHRydWUgZWxzZSB1bmRlZmluZWRdXHJcbiAgICAgKi9cclxuICAgIHByaXZhdGUgZ2V0SW5pdFNlbGVjdGVkKHNlbGVjdGVkQXJyYXk6IEFycmF5PGFueT4sIGN1cnJlbnRBcnJheTogQXJyYXk8YW55PiwgaXNTaW5nbGVGb3VuZD86IGJvb2xlYW4pOiBBcnJheTxhbnk+IHtcclxuICAgICAgICBsZXQgdXBkYXRlZEFycmF5OiBBcnJheTxhbnk+ID0gc2VsZWN0ZWRBcnJheS5zbGljZSgwKTtcclxuICAgICAgICBsZXQgbG9vcFNpbmdsZUZvdW5kOiBib29sZWFuID0gdW5kZWZpbmVkO1xyXG4gICAgICAgIGlmICh0eXBlb2YgaXNTaW5nbGVGb3VuZCAhPT0gJ3VuZGVmaW5lZCcpIGxvb3BTaW5nbGVGb3VuZCA9IGlzU2luZ2xlRm91bmQ7XHJcbiAgICAgICAgZm9yIChsZXQgaTogbnVtYmVyID0gMDsgaSA8IGN1cnJlbnRBcnJheS5sZW5ndGg7IGkrKykge1xyXG4gICAgICAgICAgICBpZiAobG9vcFNpbmdsZUZvdW5kKSBicmVhaztcclxuICAgICAgICAgICAgaWYgKGN1cnJlbnRBcnJheVtpXS5kYXRhLnNlbGVjdGVkKSB7XHJcbiAgICAgICAgICAgICAgICB1cGRhdGVkQXJyYXkucHVzaChjdXJyZW50QXJyYXlbaV0uZGF0YSk7XHJcbiAgICAgICAgICAgICAgICBpZiAodHlwZW9mIGlzU2luZ2xlRm91bmQgIT09ICd1bmRlZmluZWQnKSBsb29wU2luZ2xlRm91bmQgPSB0cnVlO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIGlmICh0eXBlb2YgY3VycmVudEFycmF5W2ldLmNoaWxkcmVuICE9PSAndW5kZWZpbmVkJykgdXBkYXRlZEFycmF5ID0gdGhpcy5nZXRJbml0U2VsZWN0ZWQodXBkYXRlZEFycmF5LCBjdXJyZW50QXJyYXlbaV0uY2hpbGRyZW4sIGxvb3BTaW5nbGVGb3VuZCk7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIHJldHVybiB1cGRhdGVkQXJyYXk7XHJcbiAgICB9XHJcblxyXG4gICAgLyoqXHJcbiAgICAgKiBkbyBhIGNvcHkgb2YgYXJyYXlcclxuICAgICAqXHJcbiAgICAgKiBvbGRBcnJheSAgICA6IFthcnJheSB0aGF0IHlvdSB3b3VsZCBsaWtlIHRvIGNvcHldXHJcbiAgICAgKiBcclxuICAgICAqL1xyXG4gICAgcHJpdmF0ZSBfY2xvbmVOZXdBcnJheShvbGRBcnJheTogQXJyYXk8VHJlZU5vZGU+KTogQXJyYXk8VHJlZU5vZGU+IHtcclxuICAgICAgICBsZXQgbmV3QXJyYXk6IEFycmF5PFRyZWVOb2RlPiA9IFtdO1xyXG4gICAgICAgIGZvciAobGV0IGk6IG51bWJlciA9IDA7IGkgPCBvbGRBcnJheS5sZW5ndGg7IGkrKykge1xyXG4gICAgICAgICAgICBsZXQgaXRlbTogVHJlZU5vZGUgPSBPYmplY3QuYXNzaWduKHt9LCBvbGRBcnJheVtpXSk7XHJcbiAgICAgICAgICAgIGl0ZW0uZGF0YSA9IE9iamVjdC5hc3NpZ24oe30sIG9sZEFycmF5W2ldLmRhdGEpO1xyXG4gICAgICAgICAgICBpZiAodHlwZW9mIG9sZEFycmF5W2ldLmNoaWxkcmVuICE9PSAndW5kZWZpbmVkJykgaXRlbS5jaGlsZHJlbiA9IHRoaXMuX2Nsb25lTmV3QXJyYXkob2xkQXJyYXlbaV0uY2hpbGRyZW4pO1xyXG4gICAgICAgICAgICBuZXdBcnJheS5wdXNoKGl0ZW0pO1xyXG4gICAgICAgIH1cclxuICAgICAgICByZXR1cm4gbmV3QXJyYXk7XHJcbiAgICB9XHJcblxyXG4gICAgLyoqXHJcbiAgICAgKiBzZXQgYWxsIGRhdGEgYXMgbm90IGV4cGFuZGVkIGFuZCBjb252ZXJ0IGFsbCBkYXRhIGludG8gcHJpbWVuZyB0cmVlIHBsdWdpbiByZWFkYWJsZSBkYXRhXHJcbiAgICAgKlxyXG4gICAgICogX2N1cnJlbnREYXRhICAgICAgOiBbYWxsIGRhdGFdXHJcbiAgICAgKiBfbW9kZSAgICAgICAgICAgICA6IFtjaGVja2JveC9yYWRpbyB8IHNpbmdsZS9tdWx0aXBsZSBdXHJcbiAgICAgKiBfaXNTaW5nbGVTZWxlY3RlZCA6XHJcbiAgICAgKiBcclxuICAgICAqL1xyXG4gICAgcHJpdmF0ZSBfZ2V0RXhwYW5kZWRCb29sKF9jdXJyZW50RGF0YTogQXJyYXk8VHJlZU5vZGU+LCBfbW9kZTogc3RyaW5nLCBfaXNTaW5nbGVTZWxlY3RlZD86IGJvb2xlYW4pOiBBcnJheTxUcmVlTm9kZT4ge1xyXG4gICAgICAgIGxldCBpc1NpbmdsZUZvdW5kOiBib29sZWFuID0gX2lzU2luZ2xlU2VsZWN0ZWQ7XHJcbiAgICAgICAgbGV0IHVwZGF0ZWREYXRhOiBBcnJheTxUcmVlTm9kZT4gPSBfY3VycmVudERhdGEuc2xpY2UoMCk7XHJcbiAgICAgICAgZm9yIChsZXQgaTogbnVtYmVyID0gMDsgaSA8IHVwZGF0ZWREYXRhLmxlbmd0aDsgaSsrKSB7XHJcbiAgICAgICAgICAgIHVwZGF0ZWREYXRhW2ldLmxhYmVsID0gX2N1cnJlbnREYXRhW2ldLmRhdGEubmFtZTtcclxuICAgICAgICAgICAgaWYgKHR5cGVvZiB1cGRhdGVkRGF0YVtpXS5jaGlsZHJlbiAhPT0gJ3VuZGVmaW5lZCcpIHtcclxuICAgICAgICAgICAgICAgIHVwZGF0ZWREYXRhW2ldLmV4cGFuZGVkID0gZmFsc2U7XHJcbiAgICAgICAgICAgICAgICB1cGRhdGVkRGF0YVtpXS5jaGlsZHJlbiA9IHRoaXMuX2dldEV4cGFuZGVkQm9vbCh1cGRhdGVkRGF0YVtpXS5jaGlsZHJlbiwgX21vZGUsIGlzU2luZ2xlRm91bmQpO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIHVwZGF0ZWREYXRhW2ldLnR5cGUgPSAoX21vZGUgPT09ICdtdWx0aXBsZScpID8gJ2NoZWNrYm94JyA6ICdyYWRpbyc7XHJcbiAgICAgICAgICAgIGlmICh0eXBlb2YgdXBkYXRlZERhdGFbaV0uZGF0YS5zZWxlY3RlZCA9PT0gJ3VuZGVmaW5lZCcpIHVwZGF0ZWREYXRhW2ldLmRhdGEuc2VsZWN0ZWQgPSBmYWxzZTtcclxuICAgICAgICAgICAgZWxzZSBpZiAodXBkYXRlZERhdGFbaV0uZGF0YS5zZWxlY3RlZCAmJiB0eXBlb2YgaXNTaW5nbGVGb3VuZCAhPT0gJ3VuZGVmaW5lZCcpIHtcclxuICAgICAgICAgICAgICAgIGlmICghaXNTaW5nbGVGb3VuZCkgaXNTaW5nbGVGb3VuZCA9IHRydWU7XHJcbiAgICAgICAgICAgICAgICBlbHNlIHVwZGF0ZWREYXRhW2ldLmRhdGEuc2VsZWN0ZWQgPSBmYWxzZTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgICAgICByZXR1cm4gdXBkYXRlZERhdGE7XHJcbiAgICB9XHJcblxyXG5cclxuICAgIC8qKlxyXG4gICAgICogZXJyb3IgcHJldmVudGlvbiBzZXQgZmFsc2UgaWYgZGF0YSBwYXNzZWQgaW4gaXMgdW5kZWZpbmVkLiBsZWF2ZSB0aGUgZGF0YSBhcyBpdCBpcyBpZiBpdCBpcyBub3QgdW5kZWZpbmVkXHJcbiAgICAgKlxyXG4gICAgICogY29uZmlnICAgICA6IFtjb25maWddXHJcbiAgICAgKiBzZXR0aW5nICAgIDogW2FueSBzZXR0aW5nLiBjYW4gYmUgbW9kZSwgY2FuIGJlIGV4cGFuZFNlbGVjdGVkIG9yIGV4cGFuZEFsbF1cclxuICAgICAqIFxyXG4gICAgICovXHJcbiAgICBnZXRTZXR0aW5nKGNvbmZpZzogYW55LCBzZXR0aW5nOiBzdHJpbmcpOiAoYm9vbGVhbnxzdHJpbmcpIHtcclxuICAgICAgICBpZiAoXHJcbiAgICAgICAgICAgIHR5cGVvZiBjb25maWcgPT09ICd1bmRlZmluZWQnIHx8XHJcbiAgICAgICAgICAgIHR5cGVvZiBjb25maWdbc2V0dGluZ10gPT09ICd1bmRlZmluZWQnXHJcbiAgICAgICAgKSByZXR1cm4gZmFsc2U7XHJcbiAgICAgICAgcmV0dXJuIGNvbmZpZ1tzZXR0aW5nXTtcclxuICAgIH1cclxuXHJcbiAgICAvKipcclxuICAgICAqIGZvciBleHBhbmRBbGwuIGV4cGFuZCB0aGUgZGF0YSBhcyBsb25nIGFzIHRoZXJlIGlzIGEgY2hpbGQgZGF0YVxyXG4gICAgICpcclxuICAgICAqIF9saXN0ICAgIDogW2NvbmZpZyBsaXN0XVxyXG4gICAgICovXHJcbiAgICBwcml2YXRlIF9leHBhbmRMaXN0KF9saXN0OiBUcmVlTm9kZVtdKTogdm9pZCB7XHJcbiAgICAgICAgbGV0IHZtOiBLZFRyZWVEcm9wZG93blN2YyA9IHRoaXM7XHJcbiAgICAgICAgX2xpc3QuZm9yRWFjaChmdW5jdGlvbihpdGVtKSB7XHJcbiAgICAgICAgICAgIGl0ZW0uZXhwYW5kZWQgPSB0cnVlO1xyXG4gICAgICAgICAgICBpZiAoaXRlbS5jaGlsZHJlbikge1xyXG4gICAgICAgICAgICAgICAgdm0uX2V4cGFuZExpc3QoaXRlbS5jaGlsZHJlbik7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9KTtcclxuICAgIH1cclxuXHJcbiAgICAvKipcclxuICAgICAqIG9ubHkgZXhwYW5kIHRoZSBwYXJlbnQgZGF0YSBpZiB0aGUgY2hpbGQgdmFsdWUgaXMgc2VsZWN0ZWRcclxuICAgICAqXHJcbiAgICAgKiBfbGlzdCA6IFtjb25maWcgbGlzdF1cclxuICAgICAqL1xyXG4gICAgcHJpdmF0ZSBfZXhwYW5kU2VsZWN0ZWQoX2xpc3Q6IFRyZWVOb2RlW10pOiB2b2lkIHtcclxuICAgICAgICBsZXQgaXNDaGlsZFNlbGVjdGVkOiBib29sZWFuO1xyXG4gICAgICAgIGZvciAobGV0IGk6IG51bWJlciA9IDA7IGkgPCBfbGlzdC5sZW5ndGg7IGkrKykge1xyXG4gICAgICAgICAgICBsZXQgaXRlbTogVHJlZU5vZGUgPSBfbGlzdFtpXTtcclxuICAgICAgICAgICAgaXNDaGlsZFNlbGVjdGVkID0gZmFsc2U7XHJcbiAgICAgICAgICAgIGlmIChpdGVtLmNoaWxkcmVuKSB7XHJcbiAgICAgICAgICAgICAgICBpc0NoaWxkU2VsZWN0ZWQgPSB0aGlzLl9leHBhbmRDaGlsZExpc3QoaXRlbS5jaGlsZHJlbik7XHJcbiAgICAgICAgICAgICAgICBpdGVtLmV4cGFuZGVkID0gaXNDaGlsZFNlbGVjdGVkO1xyXG4gICAgICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgY29udGludWU7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgLyoqXHJcbiAgICAgKiBtYWluIHB1cnBvc2UgaXMgdG8gcmV0dXJuIHRydWUgaWYgdGhlcmUgaXMgYSBzZWxlY3RlZCBkYXRhLiB0aGlzIGxvb3Agc2hvdWxkIGxvb3BcclxuICAgICAqIHRocm91Z2ggYWxsIHRoZSB3YXkgdW50aWwgdGhlIGxhc3QgY2hpbGQgaXRlbSBhdCB0aGUgc2FtZSB0aW1lLCBldmVyeSBzaW5nbGUgbG9vcCxcclxuICAgICAqIGl0IHNob3VsZCBzZXQgdGhlIGxheWVyIGFib3ZlIHRoZSBjdXJyZW50IGNoaWxkIGxpc3QgdG8gZXhwYW5kIHRydWUgaWYgdGhlIGN1cnJlbnRcclxuICAgICAqIGNoaWxkIGxpc3QgaXMgc2VsZWN0ZWRcclxuICAgICAqXHJcbiAgICAgKiBfbGlzdCA6XHJcbiAgICAgKiBcclxuICAgICAqL1xyXG4gICAgcHJpdmF0ZSBfZXhwYW5kQ2hpbGRMaXN0KF9saXN0OiBUcmVlTm9kZVtdKTogYm9vbGVhbiB7XHJcbiAgICAgICAgZm9yIChsZXQgeDogbnVtYmVyID0gMDsgeCA8IF9saXN0Lmxlbmd0aDsgeCsrKSB7XHJcbiAgICAgICAgICAgIGxldCBjaGlsZEl0ZW06IFRyZWVOb2RlID0gX2xpc3RbeF07XHJcbiAgICAgICAgICAgIGlmIChjaGlsZEl0ZW0uY2hpbGRyZW4pIHtcclxuICAgICAgICAgICAgICAgIGxldCBpc0NoaWxkU2VsZWN0ZWQ6IGJvb2xlYW4gPSB0aGlzLl9leHBhbmRDaGlsZExpc3QoY2hpbGRJdGVtLmNoaWxkcmVuKTtcclxuICAgICAgICAgICAgICAgIGNoaWxkSXRlbS5leHBhbmRlZCA9IGlzQ2hpbGRTZWxlY3RlZDtcclxuICAgICAgICAgICAgICAgIHJldHVybiBpc0NoaWxkU2VsZWN0ZWQ7XHJcbiAgICAgICAgICAgIH0gZWxzZSBpZiAoY2hpbGRJdGVtLmRhdGEuc2VsZWN0ZWQpIHtcclxuICAgICAgICAgICAgICAgIHJldHVybiBjaGlsZEl0ZW0uZGF0YS5zZWxlY3RlZDtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgICAgICByZXR1cm4gZmFsc2U7XHJcbiAgICB9XHJcblxyXG4gICAgLyoqXHJcbiAgICAgKiBtYWluIGZ1bmN0aW9uIHRvIGNoZWNrIGFuZCB0cmlnZ2VyIHdoZXRoZXIgdG8gZXhwYW5kIGFsbCBvciBleHBhbmQgc2VsZWN0ZWRcclxuICAgICAqXHJcbiAgICAgKiBfY29uZmlnICAgICAgOiBbY29uZmlnXVxyXG4gICAgICogX3VwZGF0ZWREYXRhIDogW3ByaW1lbmcgdHJlZSBkYXRhXVxyXG4gICAgICovXHJcbiAgICBhdXRvRXhwYW5kTGlzdChfY29uZmlnOiBhbnksIF91cGRhdGVkRGF0YTogVHJlZU5vZGVbXSk6IHZvaWQge1xyXG4gICAgICAgIGxldCBfZXhwYW5kQWxsOiBib29sZWFufHN0cmluZyA9IHRoaXMuZ2V0U2V0dGluZyhfY29uZmlnLCAnZXhwYW5kQWxsJyk7XHJcbiAgICAgICAgbGV0IF9leHBhbmRTZWxlY3RlZDogYm9vbGVhbnxzdHJpbmcgPSB0aGlzLmdldFNldHRpbmcoX2NvbmZpZywgJ2V4cGFuZFNlbGVjdGVkJyk7XHJcbiAgICAgICAgaWYgKHR5cGVvZiBfZXhwYW5kQWxsICE9PSAndW5kZWZpbmVkJyB8fCB0eXBlb2YgX2V4cGFuZFNlbGVjdGVkICE9PSAndW5kZWZpbmVkJykge1xyXG4gICAgICAgICAgICBpZiAoX2V4cGFuZEFsbCA9PT0gJ3RydWUnIHx8IF9leHBhbmRBbGwpIHtcclxuICAgICAgICAgICAgICAgIHRoaXMuX2V4cGFuZExpc3QoX3VwZGF0ZWREYXRhKTtcclxuICAgICAgICAgICAgfSBlbHNlIGlmIChfZXhwYW5kU2VsZWN0ZWQgPT09ICd0cnVlJyB8fCBfZXhwYW5kU2VsZWN0ZWQpIHtcclxuICAgICAgICAgICAgICAgIHRoaXMuX2V4cGFuZFNlbGVjdGVkKF91cGRhdGVkRGF0YSk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgLyoqXHJcbiAgICAgKiB1c2VkIHdoZW4gYWRkaW5nIGNoaWxkIGRhdGEgbWFudWFsbHkgZHVyaW5nIGNoaWxkIGRhdGEgbGF6eSBsb2FkLiB3aGVuIHVzZXIgY2xpY2sgdG8gZXhwYW5kIGNoaWxkIGxpc3RcclxuICAgICAqIHRoZSBleGFtcGxlIHdpbGwgcGFzcyBpbiBjaGlsZCBkYXRhIHdoaWNoIGlzIG5vdCB0byB0aGUgcHJpbWVuZyB0cmVlIHBsdWdpbiByZWFkYWJsZSBkYXRhXHJcbiAgICAgKlxyXG4gICAgICogX2lkICAgICAgICAgICAgIDpcclxuICAgICAqIF9jaGlsZERhdGEgICAgICA6XHJcbiAgICAgKiBfdXBkYXRlZERhdGEgICAgOlxyXG4gICAgICogbW9kZSAgICAgICAgICAgIDpcclxuICAgICAqIFxyXG4gICAgICovXHJcbiAgICB1cGRhdGVDb25maWcoX2lkOiBzdHJpbmcsIF9jaGlsZERhdGE6IEFycmF5PG9iamVjdD4sIF91cGRhdGVkRGF0YTogVHJlZU5vZGVbXSwgbW9kZTogc3RyaW5nKTogQXJyYXk8VHJlZU5vZGU+IHtcclxuXHJcbiAgICAgICAgZm9yIChsZXQgaTogbnVtYmVyID0gMDsgaSA8IF91cGRhdGVkRGF0YS5sZW5ndGg7IGkrKykge1xyXG5cclxuICAgICAgICAgICAgbGV0IGNvbmZpZ0xpc3Q6IFRyZWVOb2RlID0gX3VwZGF0ZWREYXRhW2ldO1xyXG4gICAgICAgICAgICBpZiAoY29uZmlnTGlzdC5kYXRhLmlkID09PSBfaWQpIHtcclxuICAgICAgICAgICAgICAgIGlmICh0eXBlb2YgY29uZmlnTGlzdC5jaGlsZHJlbiA9PT0gJ3VuZGVmaW5lZCcpIHtcclxuICAgICAgICAgICAgICAgICAgICBjb25maWdMaXN0LmNoaWxkcmVuID0gW107XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICBjb25maWdMaXN0LmNoaWxkcmVuID0gdGhpcy5nZXRVcGRhdGVOb2RlKF9jaGlsZERhdGEsIG1vZGUsIHRydWUpO1xyXG4gICAgICAgICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgICAgICBpZiAoY29uZmlnTGlzdC5oYXNPd25Qcm9wZXJ0eSgnY2hpbGRyZW4nKSkge1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMudXBkYXRlQ29uZmlnKF9pZCwgX2NoaWxkRGF0YSwgY29uZmlnTGlzdC5jaGlsZHJlbiwgbW9kZSk7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgfVxyXG4gICAgICAgIHJldHVybiB0aGlzLnVwZGF0ZUluaXRTZWxlY3RlZChfdXBkYXRlZERhdGEsIG1vZGUpO1xyXG4gICAgfVxyXG59XHJcbiJdfQ==