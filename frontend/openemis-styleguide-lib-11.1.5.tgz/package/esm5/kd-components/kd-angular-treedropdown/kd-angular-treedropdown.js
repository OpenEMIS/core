import { __decorate, __metadata } from "tslib";
import { Component, OnInit, AfterViewInit, OnDestroy, ViewContainerRef, Input, Output, EventEmitter, ViewEncapsulation, HostListener, Renderer2 } from '@angular/core';
import { timer } from 'rxjs';
import { KdTreeDropdownSvc } from './kd-treedropdown-svc';
import { KdDomElemSvc } from '../kd-common/index';
import { KdTreeDropdownEvent } from './kd-treedropdown-event';
var KdTreeDropdown = /** @class */ (function () {
    function KdTreeDropdown(_tddSvc, _vcr, _domSvc, _renderer, _treeDropdownEvent) {
        this._tddSvc = _tddSvc;
        this._vcr = _vcr;
        this._domSvc = _domSvc;
        this._renderer = _renderer;
        this._treeDropdownEvent = _treeDropdownEvent;
        this._updatedData = [];
        this._treeId = '';
        this._hide = true;
        this.selectedString = '';
        this.selectionMode = '';
        this._selectedNodes = [];
        this._wheelEvt = null;
        this._loadingIconList = {};
        this.eventSelectedNodes = new EventEmitter();
    }
    KdTreeDropdown.prototype.onResize = function () {
        this._hide = true;
        this._setPopWidthHeight();
    };
    KdTreeDropdown.prototype.onDocClick = function (docClickEvent) {
        this._setToggle(false, 'blur', docClickEvent);
    };
    KdTreeDropdown.prototype.onWheel = function (winMouseEvent) {
        var _this = this;
        if (this._wheelEvt === null) {
            this._wheelEvt = winMouseEvent;
        }
        var position = { x: this._wheelEvt.clientX, y: this._wheelEvt.clientY };
        if (this._tddSvc.checkWithinBoundingBox('notblur', position, this._treeId)) {
            clearTimeout(this._timer);
            this._timer = setTimeout(function () {
                _this._setToggle(false, 'scroll', _this._wheelEvt);
                _this._wheelEvt = null;
            }, 50);
        }
        else {
            this._hide = true;
            this._wheelEvt = null;
        }
    };
    KdTreeDropdown.prototype.ngOnInit = function () {
        var _this = this;
        this._treeId = (typeof this.config.id !== 'undefined') ? this.config.id : 'tree-class';
        this.selectionMode = this._tddSvc.getMode(this.config);
        if (typeof this.config.list === 'undefined') {
            this.config.list = [];
        }
        // let tempData: Array<any> = this._tddSvc.getUpdateNode(this.config, this.selectionMode);
        this._updatedData = this._tddSvc.getUpdateNode(this.config, this.selectionMode);
        // this._updatedData = JSON.parse(JSON.stringify(tempData));
        this._setTouchListenerAndFF();
        this._selectedNodes = this._tddSvc.updateInitSelected(this._updatedData, this.selectionMode);
        timer().subscribe(function () {
            _this._updateAndEmit();
        });
    };
    KdTreeDropdown.prototype.ngAfterViewInit = function () {
        this._setBodyPosition(true);
    };
    KdTreeDropdown.prototype.ngOnDestroy = function () {
        clearTimeout(this._timer);
        var queryString = '.' + this._treeId + '.kdx-popover-window';
        this._domSvc.removeElementByClass(queryString);
        this._touchendEvent();
        this._touchmoveEvent();
        this._firefoxMouseEvent();
    };
    KdTreeDropdown.prototype.nodeSelect = function (_data) {
        if (this.selectionMode === 'multiple')
            _data.node.data.selected = !_data.node.data.selected;
        else {
            if (typeof this._singleSelectionPrevious !== 'undefined')
                this._singleSelectionPrevious.node.data.selected = false;
            _data.node.data.selected = true;
            this._singleSelectionPrevious = _data;
        }
        this._selectedNodes = this._tddSvc.updateSelectedNodes(this._selectedNodes, _data.node, this.selectionMode);
        this._updateAndEmit();
    };
    KdTreeDropdown.prototype.loadNode = function (_event) {
        if (!_event.node.children || _event.node.children.length <= 0) {
            this._showLoadingIcon(_event.originalEvent.target, true);
            if (_event.node) {
                this._initChildApi(_event.node.data.id, _event.originalEvent.target);
            }
        }
    };
    KdTreeDropdown.prototype.showPop = function () {
        this._hide = !this._hide;
        this._setBodyPosition(false);
        this._setPopWidthHeight();
        this._tddSvc.autoExpandList(this.config, this._updatedData);
        if (this.config.list.length === 0) {
            var loadingIcon = this._vcr.element.nativeElement.parentNode;
            this._showLoadingIcon(loadingIcon, true, true);
            this._initParentApi(loadingIcon);
        }
    };
    KdTreeDropdown.prototype._initParentApi = function (_loadingIcon) {
        this._loadingIconList[this._treeId] = _loadingIcon;
        var vm = this;
        this.api.updateList = function (_treeId, _listData) {
            vm._showLoadingIcon(vm._loadingIconList[_treeId], false);
            vm.config.list = _listData;
            vm._updatedData = vm._tddSvc.getUpdateNode(vm.config, vm.selectionMode);
            vm._selectedNodes = vm._tddSvc.updateInitSelected(vm._updatedData, vm.selectionMode);
            vm._updateAndEmit();
        };
        this._treeDropdownEvent.loadList(this._treeId);
    };
    KdTreeDropdown.prototype._initChildApi = function (_id, _loadingIcon) {
        this._loadingIconList[_id] = _loadingIcon;
        var vm = this;
        this.api.updateChildNode = function (_parentId, _returnData) {
            vm._showLoadingIcon(vm._loadingIconList[_parentId], false);
            vm._selectedNodes = vm._tddSvc.updateConfig(_parentId, _returnData, vm._updatedData, vm.selectionMode);
            vm._updateAndEmit();
        };
        this._treeDropdownEvent.childExpand(_id);
    };
    KdTreeDropdown.prototype._showLoadingIcon = function (_element, _showLoading, _isListNode) {
        if (_showLoading) {
            this._renderer.addClass(_element, 'kdx-loading-class');
            if (typeof _isListNode === 'undefined' || (typeof _isListNode === 'boolean' && !_isListNode)) {
                this._renderer.addClass(_element, 'fa-spinner');
                this._renderer.addClass(_element, 'fa-pulse');
                this._renderer.addClass(_element, 'fa-lg');
            }
        }
        else {
            _element.className = _element.className.replace(/(?:^|\s)kdx-loading-class(?!\S)/g, '');
            if (typeof _isListNode === 'undefined' || (typeof _isListNode === 'boolean' && !_isListNode)) {
                _element.className = _element.className.replace(/(?:^|\s)fa-spinner(?!\S)/g, '');
                _element.className = _element.className.replace(/(?:^|\s)fa-pulse(?!\S)/g, '');
                _element.className = _element.className.replace(/(?:^|\s)fa-lg(?!\S)/g, '');
            }
        }
    };
    KdTreeDropdown.prototype._updateAndEmit = function () {
        this.selectedString = this._tddSvc.updateSelectedString(this._selectedNodes);
        this.eventSelectedNodes.emit(this._selectedNodes);
    };
    KdTreeDropdown.prototype._setPopWidthHeight = function () {
        var queryString = '.' + this._treeId + '.kdx-popover-window';
        var popoverWindow = document.querySelector(queryString);
        this._setPopoverWidth(popoverWindow);
        this._setPopoverMaxHeight(popoverWindow);
    };
    KdTreeDropdown.prototype._setPopoverWidth = function (_popoverWindow) {
        var selectionEle = this._vcr.element.nativeElement;
        var width = selectionEle.getBoundingClientRect().width + 'px';
        this._domSvc.setElementStyle(_popoverWindow, 'max-width', width);
        this._domSvc.setElementStyle(_popoverWindow, 'min-width', width);
    };
    KdTreeDropdown.prototype._setPopoverMaxHeight = function (_popoverWindow) {
        var dropdown = this._vcr.element.nativeElement.parentNode;
        var usableHeight = window.innerHeight - dropdown.getBoundingClientRect().bottom - 5;
        var maxHeight = (usableHeight > 300) ? 300 : usableHeight;
        var maxHeightPx = maxHeight + 'px';
        var tree = _popoverWindow.querySelector('.ui-tree .ui-tree-container');
        if (tree !== null)
            this._domSvc.setElementStyle(tree, 'max-height', maxHeightPx);
    };
    KdTreeDropdown.prototype._setToggle = function (_isTouch, _checkType, _eventObj) {
        var position = (_isTouch) ? this._tddSvc.getTouchPosition(_eventObj) : { x: _eventObj.clientX, y: _eventObj.clientY };
        var toggle = (_checkType === 'blur') ? this._tddSvc.checkWithinBoundingBox(_checkType, position, this._treeId, this._vcr.element.nativeElement.parentNode) : this._tddSvc.checkWithinBoundingBox(_checkType, position, this._treeId);
        if (!toggle)
            this._hide = true;
    };
    KdTreeDropdown.prototype._setTouchListenerAndFF = function () {
        var _this = this;
        this._firefoxMouseEvent = this._renderer.listen('document', 'DOMMouseScroll', function (ffMouseEvent) {
            _this._setToggle(false, 'scroll', ffMouseEvent);
        });
        this._touchmoveEvent = this._renderer.listen('document', 'touchmove', function (touchEvent) {
            _this._setToggle(true, 'scroll', touchEvent);
        });
        this._touchendEvent = this._renderer.listen('document', 'touchstart', function (touchEvent) {
            _this._setToggle(true, 'blur', touchEvent);
        });
    };
    KdTreeDropdown.prototype._setBodyPosition = function (_isFirstCheck) {
        var mainEle = this._vcr.element.nativeElement.getBoundingClientRect();
        var queryString = '.' + this._treeId + '.kdx-popover-window';
        var toBody = (_isFirstCheck) ? this._vcr.element.nativeElement.querySelector(queryString) : document.querySelector(queryString);
        var topPos = (mainEle.bottom + 8) + 'px';
        var leftPos = mainEle.left + 'px';
        this._domSvc.setElementStyle(toBody, 'top', topPos);
        this._domSvc.setElementStyle(toBody, 'left', leftPos);
        if (_isFirstCheck)
            document.body.appendChild(toBody);
    };
    KdTreeDropdown.ctorParameters = function () { return [
        { type: KdTreeDropdownSvc },
        { type: ViewContainerRef },
        { type: KdDomElemSvc },
        { type: Renderer2 },
        { type: KdTreeDropdownEvent }
    ]; };
    __decorate([
        Input(),
        __metadata("design:type", Object)
    ], KdTreeDropdown.prototype, "config", void 0);
    __decorate([
        Input(),
        __metadata("design:type", Object)
    ], KdTreeDropdown.prototype, "api", void 0);
    __decorate([
        Output(),
        __metadata("design:type", EventEmitter)
    ], KdTreeDropdown.prototype, "eventSelectedNodes", void 0);
    __decorate([
        HostListener('window:resize', []),
        __metadata("design:type", Function),
        __metadata("design:paramtypes", []),
        __metadata("design:returntype", void 0)
    ], KdTreeDropdown.prototype, "onResize", null);
    __decorate([
        HostListener('document:mouseup', ['$event']),
        __metadata("design:type", Function),
        __metadata("design:paramtypes", [MouseEvent]),
        __metadata("design:returntype", void 0)
    ], KdTreeDropdown.prototype, "onDocClick", null);
    __decorate([
        HostListener('window:mousewheel', ['$event']),
        __metadata("design:type", Function),
        __metadata("design:paramtypes", [MouseEvent]),
        __metadata("design:returntype", void 0)
    ], KdTreeDropdown.prototype, "onWheel", null);
    KdTreeDropdown = __decorate([
        Component({
            selector: 'kd-tree-dropdown',
            template: "<div class=\"popover popover-bottom kdx-popover-window\" [ngClass]=\"_treeId\" [hidden]=\"_hide\">\r\n    <h3 class=\"popover-title\"></h3>\r\n    <div class=\"popover-content\">\r\n\t\t<p-tree class=\"kdx-p-tree\"\r\n\t\t[value]=\"_updatedData\" \r\n\t\tselectionMode=\"selectionMode\" \r\n\t\t(onNodeSelect)=\"nodeSelect($event)\"\r\n\t\t(onNodeExpand)=\"loadNode($event)\"\r\n\t\t>\r\n\t\t\t<ng-template let-node pTemplate=\"checkbox\">\r\n\t\t\t<div class=\"input-selection\">\r\n\t\t\t\t<div class=\"input\">\r\n\t\t\t\t\t<input [ngClass]=\"['dropdown', node.data.id]\" [kd-checkbox-radio]=\"node.label\" type='checkbox' [checked]=\"node.data.selected\"/>\r\n\t\t\t\t</div>\r\n\t\t\t</div>\r\n\t\t\t</ng-template>\r\n\t\t\t<ng-template let-node pTemplate=\"radio\">\r\n\t\t\t<div class=\"input-selection\">\r\n\t\t\t\t<div class=\"input\">\r\n\t\t\t\t\t<input [ngClass]=\"['dropdown', node.data.id]\" [kd-checkbox-radio]=\"node.label\" type='radio' name=\"radio\" [checked]=\"node.data.selected\"/>\r\n\t\t\t\t</div>\r\n\t\t\t</div>\r\n\t\t\t</ng-template>\r\n\t\t</p-tree>\r\n    </div>\r\n</div>\r\n\r\n<a class=\"kdx-treedropdown-input\" (click)=\"showPop()\">{{selectedString}}</a>",
            encapsulation: ViewEncapsulation.None,
            providers: [KdTreeDropdownSvc, KdDomElemSvc],
            host: { 'class': 'kdx-tree-dropdown' }
        }),
        __metadata("design:paramtypes", [KdTreeDropdownSvc,
            ViewContainerRef,
            KdDomElemSvc,
            Renderer2,
            KdTreeDropdownEvent])
    ], KdTreeDropdown);
    return KdTreeDropdown;
}());
export { KdTreeDropdown };
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoia2QtYW5ndWxhci10cmVlZHJvcGRvd24uanMiLCJzb3VyY2VSb290Ijoibmc6Ly9vcGVuZW1pcy1zdHlsZWd1aWRlLWxpYi8iLCJzb3VyY2VzIjpbImtkLWNvbXBvbmVudHMva2QtYW5ndWxhci10cmVlZHJvcGRvd24va2QtYW5ndWxhci10cmVlZHJvcGRvd24udHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IjtBQUFBLE9BQU8sRUFBRSxTQUFTLEVBQUUsTUFBTSxFQUFFLGFBQWEsRUFBRSxTQUFTLEVBQUUsZ0JBQWdCLEVBQUUsS0FBSyxFQUFFLE1BQU0sRUFBRSxZQUFZLEVBQUUsaUJBQWlCLEVBQUUsWUFBWSxFQUFFLFNBQVMsRUFBRSxNQUFNLGVBQWUsQ0FBQztBQUN2SyxPQUFPLEVBQUUsS0FBSyxFQUFFLE1BQU0sTUFBTSxDQUFDO0FBRTdCLE9BQU8sRUFBRSxpQkFBaUIsRUFBRSxNQUFNLHVCQUF1QixDQUFDO0FBQzFELE9BQU8sRUFBRSxZQUFZLEVBQUUsTUFBTSxvQkFBb0IsQ0FBQztBQUNsRCxPQUFPLEVBQUUsbUJBQW1CLEVBQUUsTUFBTSx5QkFBeUIsQ0FBQztBQVc5RDtJQXFCSSx3QkFDWSxPQUEwQixFQUMxQixJQUFzQixFQUN0QixPQUFxQixFQUNyQixTQUFvQixFQUNwQixrQkFBdUM7UUFKdkMsWUFBTyxHQUFQLE9BQU8sQ0FBbUI7UUFDMUIsU0FBSSxHQUFKLElBQUksQ0FBa0I7UUFDdEIsWUFBTyxHQUFQLE9BQU8sQ0FBYztRQUNyQixjQUFTLEdBQVQsU0FBUyxDQUFXO1FBQ3BCLHVCQUFrQixHQUFsQixrQkFBa0IsQ0FBcUI7UUF6QjVDLGlCQUFZLEdBQW9CLEVBQUUsQ0FBQztRQUNuQyxZQUFPLEdBQVcsRUFBRSxDQUFDO1FBQ3JCLFVBQUssR0FBWSxJQUFJLENBQUM7UUFDdEIsbUJBQWMsR0FBVyxFQUFFLENBQUM7UUFDNUIsa0JBQWEsR0FBVyxFQUFFLENBQUM7UUFFMUIsbUJBQWMsR0FBZSxFQUFFLENBQUM7UUFLaEMsY0FBUyxHQUFRLElBQUksQ0FBQztRQUV0QixxQkFBZ0IsR0FBVyxFQUFFLENBQUM7UUFLNUIsdUJBQWtCLEdBQXNCLElBQUksWUFBWSxFQUFFLENBQUM7SUFRbEUsQ0FBQztJQUdKLGlDQUFRLEdBQVI7UUFDSSxJQUFJLENBQUMsS0FBSyxHQUFHLElBQUksQ0FBQztRQUNsQixJQUFJLENBQUMsa0JBQWtCLEVBQUUsQ0FBQztJQUM5QixDQUFDO0lBR0QsbUNBQVUsR0FBVixVQUFXLGFBQXlCO1FBQ2hDLElBQUksQ0FBQyxVQUFVLENBQUMsS0FBSyxFQUFFLE1BQU0sRUFBRSxhQUFhLENBQUMsQ0FBQztJQUNsRCxDQUFDO0lBR0QsZ0NBQU8sR0FBUCxVQUFRLGFBQXlCO1FBRGpDLGlCQW1CQztRQWpCRyxJQUFJLElBQUksQ0FBQyxTQUFTLEtBQUssSUFBSSxFQUFFO1lBQ3pCLElBQUksQ0FBQyxTQUFTLEdBQUcsYUFBYSxDQUFDO1NBQ2xDO1FBRUQsSUFBSSxRQUFRLEdBQVEsRUFBQyxDQUFDLEVBQUUsSUFBSSxDQUFDLFNBQVMsQ0FBQyxPQUFPLEVBQUUsQ0FBQyxFQUFFLElBQUksQ0FBQyxTQUFTLENBQUMsT0FBTyxFQUFDLENBQUM7UUFDM0UsSUFBSSxJQUFJLENBQUMsT0FBTyxDQUFDLHNCQUFzQixDQUFDLFNBQVMsRUFBRSxRQUFRLEVBQUUsSUFBSSxDQUFDLE9BQU8sQ0FBQyxFQUFFO1lBQ3hFLFlBQVksQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUM7WUFFMUIsSUFBSSxDQUFDLE1BQU0sR0FBRyxVQUFVLENBQUM7Z0JBQ3JCLEtBQUksQ0FBQyxVQUFVLENBQUMsS0FBSyxFQUFFLFFBQVEsRUFBRSxLQUFJLENBQUMsU0FBUyxDQUFDLENBQUM7Z0JBQ2pELEtBQUksQ0FBQyxTQUFTLEdBQUcsSUFBSSxDQUFDO1lBQzFCLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQztTQUNWO2FBQ0k7WUFDRCxJQUFJLENBQUMsS0FBSyxHQUFHLElBQUksQ0FBQztZQUNsQixJQUFJLENBQUMsU0FBUyxHQUFHLElBQUksQ0FBQztTQUN6QjtJQUNMLENBQUM7SUFFRCxpQ0FBUSxHQUFSO1FBQUEsaUJBa0JDO1FBaEJHLElBQUksQ0FBQyxPQUFPLEdBQUcsQ0FBQyxPQUFPLElBQUksQ0FBQyxNQUFNLENBQUMsRUFBRSxLQUFLLFdBQVcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsWUFBWSxDQUFDO1FBQ3ZGLElBQUksQ0FBQyxhQUFhLEdBQUcsSUFBSSxDQUFDLE9BQU8sQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDO1FBRXZELElBQUksT0FBTyxJQUFJLENBQUMsTUFBTSxDQUFDLElBQUksS0FBSyxXQUFXLEVBQUU7WUFDekMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxJQUFJLEdBQUcsRUFBRSxDQUFDO1NBQ3pCO1FBRUQsMEZBQTBGO1FBQzFGLElBQUksQ0FBQyxZQUFZLEdBQUcsSUFBSSxDQUFDLE9BQU8sQ0FBQyxhQUFhLENBQUMsSUFBSSxDQUFDLE1BQU0sRUFBRSxJQUFJLENBQUMsYUFBYSxDQUFDLENBQUM7UUFDaEYsNERBQTREO1FBQzVELElBQUksQ0FBQyxzQkFBc0IsRUFBRSxDQUFDO1FBQzlCLElBQUksQ0FBQyxjQUFjLEdBQUcsSUFBSSxDQUFDLE9BQU8sQ0FBQyxrQkFBa0IsQ0FBQyxJQUFJLENBQUMsWUFBWSxFQUFFLElBQUksQ0FBQyxhQUFhLENBQUMsQ0FBQztRQUU3RixLQUFLLEVBQUUsQ0FBQyxTQUFTLENBQUM7WUFDZCxLQUFJLENBQUMsY0FBYyxFQUFFLENBQUM7UUFDMUIsQ0FBQyxDQUFDLENBQUM7SUFDUCxDQUFDO0lBRUQsd0NBQWUsR0FBZjtRQUNJLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxJQUFJLENBQUMsQ0FBQztJQUNoQyxDQUFDO0lBRUQsb0NBQVcsR0FBWDtRQUNJLFlBQVksQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUM7UUFDMUIsSUFBSSxXQUFXLEdBQVcsR0FBRyxHQUFHLElBQUksQ0FBQyxPQUFPLEdBQUcscUJBQXFCLENBQUM7UUFDckUsSUFBSSxDQUFDLE9BQU8sQ0FBQyxvQkFBb0IsQ0FBQyxXQUFXLENBQUMsQ0FBQztRQUMvQyxJQUFJLENBQUMsY0FBYyxFQUFFLENBQUM7UUFDdEIsSUFBSSxDQUFDLGVBQWUsRUFBRSxDQUFDO1FBQ3ZCLElBQUksQ0FBQyxrQkFBa0IsRUFBRSxDQUFDO0lBQzlCLENBQUM7SUFFRCxtQ0FBVSxHQUFWLFVBQVcsS0FBVTtRQUNqQixJQUFJLElBQUksQ0FBQyxhQUFhLEtBQUssVUFBVTtZQUFFLEtBQUssQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLFFBQVEsR0FBRyxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQzthQUN2RjtZQUNELElBQUksT0FBTyxJQUFJLENBQUMsd0JBQXdCLEtBQUssV0FBVztnQkFBRSxJQUFJLENBQUMsd0JBQXdCLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxRQUFRLEdBQUcsS0FBSyxDQUFDO1lBQ25ILEtBQUssQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLFFBQVEsR0FBRyxJQUFJLENBQUM7WUFDaEMsSUFBSSxDQUFDLHdCQUF3QixHQUFHLEtBQUssQ0FBQztTQUN6QztRQUNELElBQUksQ0FBQyxjQUFjLEdBQUcsSUFBSSxDQUFDLE9BQU8sQ0FBQyxtQkFBbUIsQ0FBQyxJQUFJLENBQUMsY0FBYyxFQUFFLEtBQUssQ0FBQyxJQUFJLEVBQUUsSUFBSSxDQUFDLGFBQWEsQ0FBQyxDQUFDO1FBQzVHLElBQUksQ0FBQyxjQUFjLEVBQUUsQ0FBQztJQUMxQixDQUFDO0lBRUQsaUNBQVEsR0FBUixVQUFTLE1BQVc7UUFFaEIsSUFBSSxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsUUFBUSxJQUFJLE1BQU0sQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLE1BQU0sSUFBSSxDQUFDLEVBQUU7WUFDM0QsSUFBSSxDQUFDLGdCQUFnQixDQUFDLE1BQU0sQ0FBQyxhQUFhLENBQUMsTUFBTSxFQUFFLElBQUksQ0FBQyxDQUFDO1lBRXpELElBQUksTUFBTSxDQUFDLElBQUksRUFBRTtnQkFDYixJQUFJLENBQUMsYUFBYSxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLEVBQUUsRUFBRSxNQUFNLENBQUMsYUFBYSxDQUFDLE1BQU0sQ0FBQyxDQUFDO2FBQ3hFO1NBQ0o7SUFDTCxDQUFDO0lBRUQsZ0NBQU8sR0FBUDtRQUNJLElBQUksQ0FBQyxLQUFLLEdBQUcsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDO1FBQ3pCLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxLQUFLLENBQUMsQ0FBQztRQUM3QixJQUFJLENBQUMsa0JBQWtCLEVBQUUsQ0FBQztRQUUxQixJQUFJLENBQUMsT0FBTyxDQUFDLGNBQWMsQ0FBQyxJQUFJLENBQUMsTUFBTSxFQUFFLElBQUksQ0FBQyxZQUFZLENBQUMsQ0FBQztRQUM1RCxJQUFJLElBQUksQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLE1BQU0sS0FBSyxDQUFDLEVBQUU7WUFFL0IsSUFBSSxXQUFXLEdBQVksSUFBSSxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsYUFBYSxDQUFDLFVBQVUsQ0FBQztZQUN0RSxJQUFJLENBQUMsZ0JBQWdCLENBQUMsV0FBVyxFQUFFLElBQUksRUFBRSxJQUFJLENBQUMsQ0FBQztZQUUvQyxJQUFJLENBQUMsY0FBYyxDQUFDLFdBQVcsQ0FBQyxDQUFDO1NBQ3BDO0lBQ0wsQ0FBQztJQUVPLHVDQUFjLEdBQXRCLFVBQXVCLFlBQXFCO1FBQ3hDLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLEdBQUcsWUFBWSxDQUFDO1FBRW5ELElBQUksRUFBRSxHQUFtQixJQUFJLENBQUM7UUFDOUIsSUFBSSxDQUFDLEdBQUcsQ0FBQyxVQUFVLEdBQUcsVUFBQyxPQUFlLEVBQUUsU0FBcUI7WUFDekQsRUFBRSxDQUFDLGdCQUFnQixDQUFDLEVBQUUsQ0FBQyxnQkFBZ0IsQ0FBQyxPQUFPLENBQUMsRUFBRSxLQUFLLENBQUMsQ0FBQztZQUN6RCxFQUFFLENBQUMsTUFBTSxDQUFDLElBQUksR0FBRyxTQUFTLENBQUM7WUFDM0IsRUFBRSxDQUFDLFlBQVksR0FBRyxFQUFFLENBQUMsT0FBTyxDQUFDLGFBQWEsQ0FBQyxFQUFFLENBQUMsTUFBTSxFQUFFLEVBQUUsQ0FBQyxhQUFhLENBQUMsQ0FBQztZQUN4RSxFQUFFLENBQUMsY0FBYyxHQUFHLEVBQUUsQ0FBQyxPQUFPLENBQUMsa0JBQWtCLENBQUMsRUFBRSxDQUFDLFlBQVksRUFBRSxFQUFFLENBQUMsYUFBYSxDQUFDLENBQUM7WUFDckYsRUFBRSxDQUFDLGNBQWMsRUFBRSxDQUFDO1FBQ3hCLENBQUMsQ0FBQztRQUVGLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxDQUFDO0lBQ25ELENBQUM7SUFFTyxzQ0FBYSxHQUFyQixVQUFzQixHQUFXLEVBQUUsWUFBcUI7UUFDcEQsSUFBSSxDQUFDLGdCQUFnQixDQUFDLEdBQUcsQ0FBQyxHQUFHLFlBQVksQ0FBQztRQUUxQyxJQUFJLEVBQUUsR0FBbUIsSUFBSSxDQUFDO1FBQzlCLElBQUksQ0FBQyxHQUFHLENBQUMsZUFBZSxHQUFHLFVBQUMsU0FBaUIsRUFBRSxXQUEwQjtZQUNyRSxFQUFFLENBQUMsZ0JBQWdCLENBQUMsRUFBRSxDQUFDLGdCQUFnQixDQUFDLFNBQVMsQ0FBQyxFQUFFLEtBQUssQ0FBQyxDQUFDO1lBQzNELEVBQUUsQ0FBQyxjQUFjLEdBQUcsRUFBRSxDQUFDLE9BQU8sQ0FBQyxZQUFZLENBQUMsU0FBUyxFQUFFLFdBQVcsRUFBRSxFQUFFLENBQUMsWUFBWSxFQUFFLEVBQUUsQ0FBQyxhQUFhLENBQUMsQ0FBQztZQUN2RyxFQUFFLENBQUMsY0FBYyxFQUFFLENBQUM7UUFDeEIsQ0FBQyxDQUFDO1FBRUYsSUFBSSxDQUFDLGtCQUFrQixDQUFDLFdBQVcsQ0FBQyxHQUFHLENBQUMsQ0FBQztJQUM3QyxDQUFDO0lBRU8seUNBQWdCLEdBQXhCLFVBQXlCLFFBQWlCLEVBQUUsWUFBcUIsRUFBRSxXQUFxQjtRQUVwRixJQUFJLFlBQVksRUFBRTtZQUNkLElBQUksQ0FBQyxTQUFTLENBQUMsUUFBUSxDQUFDLFFBQVEsRUFBRSxtQkFBbUIsQ0FBQyxDQUFDO1lBQ3ZELElBQUksT0FBTyxXQUFXLEtBQUssV0FBVyxJQUFJLENBQUMsT0FBTyxXQUFXLEtBQUssU0FBUyxJQUFJLENBQUMsV0FBVyxDQUFDLEVBQUU7Z0JBQzFGLElBQUksQ0FBQyxTQUFTLENBQUMsUUFBUSxDQUFDLFFBQVEsRUFBRSxZQUFZLENBQUMsQ0FBQztnQkFDaEQsSUFBSSxDQUFDLFNBQVMsQ0FBQyxRQUFRLENBQUMsUUFBUSxFQUFFLFVBQVUsQ0FBQyxDQUFDO2dCQUM5QyxJQUFJLENBQUMsU0FBUyxDQUFDLFFBQVEsQ0FBQyxRQUFRLEVBQUUsT0FBTyxDQUFDLENBQUM7YUFDOUM7U0FDSjthQUFNO1lBQ0gsUUFBUSxDQUFDLFNBQVMsR0FBRyxRQUFRLENBQUMsU0FBUyxDQUFDLE9BQU8sQ0FBQyxrQ0FBa0MsRUFBRSxFQUFFLENBQUMsQ0FBQztZQUN4RixJQUFJLE9BQU8sV0FBVyxLQUFLLFdBQVcsSUFBSSxDQUFDLE9BQU8sV0FBVyxLQUFLLFNBQVMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxFQUFFO2dCQUMxRixRQUFRLENBQUMsU0FBUyxHQUFHLFFBQVEsQ0FBQyxTQUFTLENBQUMsT0FBTyxDQUFDLDJCQUEyQixFQUFFLEVBQUUsQ0FBQyxDQUFDO2dCQUNqRixRQUFRLENBQUMsU0FBUyxHQUFHLFFBQVEsQ0FBQyxTQUFTLENBQUMsT0FBTyxDQUFDLHlCQUF5QixFQUFFLEVBQUUsQ0FBQyxDQUFDO2dCQUMvRSxRQUFRLENBQUMsU0FBUyxHQUFHLFFBQVEsQ0FBQyxTQUFTLENBQUMsT0FBTyxDQUFDLHNCQUFzQixFQUFFLEVBQUUsQ0FBQyxDQUFDO2FBQy9FO1NBQ0o7SUFFTCxDQUFDO0lBRU8sdUNBQWMsR0FBdEI7UUFDSSxJQUFJLENBQUMsY0FBYyxHQUFHLElBQUksQ0FBQyxPQUFPLENBQUMsb0JBQW9CLENBQUMsSUFBSSxDQUFDLGNBQWMsQ0FBQyxDQUFDO1FBQzdFLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLGNBQWMsQ0FBQyxDQUFDO0lBQ3RELENBQUM7SUFFTywyQ0FBa0IsR0FBMUI7UUFDSSxJQUFJLFdBQVcsR0FBVyxHQUFHLEdBQUcsSUFBSSxDQUFDLE9BQU8sR0FBRyxxQkFBcUIsQ0FBQztRQUNyRSxJQUFJLGFBQWEsR0FBWSxRQUFRLENBQUMsYUFBYSxDQUFDLFdBQVcsQ0FBQyxDQUFDO1FBQ2pFLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxhQUFhLENBQUMsQ0FBQztRQUNyQyxJQUFJLENBQUMsb0JBQW9CLENBQUMsYUFBYSxDQUFDLENBQUM7SUFDN0MsQ0FBQztJQUVPLHlDQUFnQixHQUF4QixVQUF5QixjQUF1QjtRQUM1QyxJQUFJLFlBQVksR0FBZ0IsSUFBSSxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsYUFBYSxDQUFDO1FBQ2hFLElBQUksS0FBSyxHQUFXLFlBQVksQ0FBQyxxQkFBcUIsRUFBRSxDQUFDLEtBQUssR0FBRyxJQUFJLENBQUM7UUFDdEUsSUFBSSxDQUFDLE9BQU8sQ0FBQyxlQUFlLENBQUMsY0FBYyxFQUFFLFdBQVcsRUFBRSxLQUFLLENBQUMsQ0FBQztRQUNqRSxJQUFJLENBQUMsT0FBTyxDQUFDLGVBQWUsQ0FBQyxjQUFjLEVBQUUsV0FBVyxFQUFFLEtBQUssQ0FBQyxDQUFDO0lBQ3JFLENBQUM7SUFFTyw2Q0FBb0IsR0FBNUIsVUFBNkIsY0FBdUI7UUFDaEQsSUFBSSxRQUFRLEdBQVksSUFBSSxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsYUFBYSxDQUFDLFVBQVUsQ0FBQztRQUNuRSxJQUFJLFlBQVksR0FBVyxNQUFNLENBQUMsV0FBVyxHQUFHLFFBQVEsQ0FBQyxxQkFBcUIsRUFBRSxDQUFDLE1BQU0sR0FBRyxDQUFDLENBQUM7UUFDNUYsSUFBSSxTQUFTLEdBQVcsQ0FBQyxZQUFZLEdBQUcsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsWUFBWSxDQUFDO1FBQ2xFLElBQUksV0FBVyxHQUFXLFNBQVMsR0FBRyxJQUFJLENBQUM7UUFDM0MsSUFBSSxJQUFJLEdBQVksY0FBYyxDQUFDLGFBQWEsQ0FBQyw2QkFBNkIsQ0FBQyxDQUFDO1FBQ2hGLElBQUksSUFBSSxLQUFLLElBQUk7WUFBRSxJQUFJLENBQUMsT0FBTyxDQUFDLGVBQWUsQ0FBQyxJQUFJLEVBQUUsWUFBWSxFQUFFLFdBQVcsQ0FBQyxDQUFDO0lBQ3JGLENBQUM7SUFFTyxtQ0FBVSxHQUFsQixVQUFtQixRQUFpQixFQUFFLFVBQWtCLEVBQUUsU0FBYztRQUVwRSxJQUFJLFFBQVEsR0FBUSxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLGdCQUFnQixDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxTQUFTLENBQUMsT0FBTyxFQUFFLENBQUMsRUFBRSxTQUFTLENBQUMsT0FBTyxFQUFFLENBQUM7UUFDM0gsSUFBSSxNQUFNLEdBQVksQ0FBQyxVQUFVLEtBQUssTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsc0JBQXNCLENBQUMsVUFBVSxFQUFFLFFBQVEsRUFBRSxJQUFJLENBQUMsT0FBTyxFQUFFLElBQUksQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLGFBQWEsQ0FBQyxVQUFVLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxzQkFBc0IsQ0FBQyxVQUFVLEVBQUUsUUFBUSxFQUFFLElBQUksQ0FBQyxPQUFPLENBQUMsQ0FBQztRQUM5TyxJQUFJLENBQUMsTUFBTTtZQUFFLElBQUksQ0FBQyxLQUFLLEdBQUcsSUFBSSxDQUFDO0lBQ25DLENBQUM7SUFFTywrQ0FBc0IsR0FBOUI7UUFBQSxpQkFVQztRQVRHLElBQUksQ0FBQyxrQkFBa0IsR0FBRyxJQUFJLENBQUMsU0FBUyxDQUFDLE1BQU0sQ0FBQyxVQUFVLEVBQUUsZ0JBQWdCLEVBQUUsVUFBQyxZQUF3QjtZQUMzRyxLQUFJLENBQUMsVUFBVSxDQUFDLEtBQUssRUFBRSxRQUFRLEVBQUUsWUFBWSxDQUFDLENBQUM7UUFDbkQsQ0FBQyxDQUFDLENBQUM7UUFDSyxJQUFJLENBQUMsZUFBZSxHQUFHLElBQUksQ0FBQyxTQUFTLENBQUMsTUFBTSxDQUFDLFVBQVUsRUFBRSxXQUFXLEVBQUUsVUFBQyxVQUFzQjtZQUNqRyxLQUFJLENBQUMsVUFBVSxDQUFDLElBQUksRUFBRSxRQUFRLEVBQUUsVUFBVSxDQUFDLENBQUM7UUFDaEQsQ0FBQyxDQUFDLENBQUM7UUFDSyxJQUFJLENBQUMsY0FBYyxHQUFHLElBQUksQ0FBQyxTQUFTLENBQUMsTUFBTSxDQUFDLFVBQVUsRUFBRSxZQUFZLEVBQUUsVUFBQyxVQUFzQjtZQUNqRyxLQUFJLENBQUMsVUFBVSxDQUFDLElBQUksRUFBRSxNQUFNLEVBQUUsVUFBVSxDQUFDLENBQUM7UUFDOUMsQ0FBQyxDQUFDLENBQUM7SUFDQyxDQUFDO0lBRU8seUNBQWdCLEdBQXhCLFVBQXlCLGFBQXNCO1FBQzNDLElBQUksT0FBTyxHQUFlLElBQUksQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLGFBQWEsQ0FBQyxxQkFBcUIsRUFBRSxDQUFDO1FBQ2xGLElBQUksV0FBVyxHQUFXLEdBQUcsR0FBRyxJQUFJLENBQUMsT0FBTyxHQUFHLHFCQUFxQixDQUFDO1FBQ3JFLElBQUksTUFBTSxHQUFZLENBQUMsYUFBYSxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLGFBQWEsQ0FBQyxhQUFhLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxhQUFhLENBQUMsV0FBVyxDQUFDLENBQUM7UUFDekksSUFBSSxNQUFNLEdBQVcsQ0FBQyxPQUFPLENBQUMsTUFBTSxHQUFHLENBQUMsQ0FBQyxHQUFHLElBQUksQ0FBQztRQUNqRCxJQUFJLE9BQU8sR0FBVyxPQUFPLENBQUMsSUFBSSxHQUFHLElBQUksQ0FBQztRQUMxQyxJQUFJLENBQUMsT0FBTyxDQUFDLGVBQWUsQ0FBQyxNQUFNLEVBQUUsS0FBSyxFQUFFLE1BQU0sQ0FBQyxDQUFDO1FBQ3BELElBQUksQ0FBQyxPQUFPLENBQUMsZUFBZSxDQUFDLE1BQU0sRUFBRSxNQUFNLEVBQUUsT0FBTyxDQUFDLENBQUM7UUFDdEQsSUFBSSxhQUFhO1lBQUUsUUFBUSxDQUFDLElBQUksQ0FBQyxXQUFXLENBQUMsTUFBTSxDQUFDLENBQUM7SUFDekQsQ0FBQzs7Z0JBck5vQixpQkFBaUI7Z0JBQ3BCLGdCQUFnQjtnQkFDYixZQUFZO2dCQUNWLFNBQVM7Z0JBQ0EsbUJBQW1COztJQVYxQztRQUFSLEtBQUssRUFBRTs7a0RBQWE7SUFDWjtRQUFSLEtBQUssRUFBRTs7K0NBQWU7SUFFYjtRQUFULE1BQU0sRUFBRTtrQ0FBcUIsWUFBWTs4REFBMkI7SUFXckU7UUFEQyxZQUFZLENBQUMsZUFBZSxFQUFFLEVBQUUsQ0FBQzs7OztrREFJakM7SUFHRDtRQURDLFlBQVksQ0FBQyxrQkFBa0IsRUFBRSxDQUFDLFFBQVEsQ0FBQyxDQUFDOzt5Q0FDbkIsVUFBVTs7b0RBRW5DO0lBR0Q7UUFEQyxZQUFZLENBQUMsbUJBQW1CLEVBQUUsQ0FBQyxRQUFRLENBQUMsQ0FBQzs7eUNBQ3ZCLFVBQVU7O2lEQWtCaEM7SUEzRFEsY0FBYztRQVIxQixTQUFTLENBQUM7WUFDUCxRQUFRLEVBQUUsa0JBQWtCO1lBQzVCLGtyQ0FBNkM7WUFDN0MsYUFBYSxFQUFFLGlCQUFpQixDQUFDLElBQUk7WUFDckMsU0FBUyxFQUFFLENBQUMsaUJBQWlCLEVBQUUsWUFBWSxDQUFDO1lBQzVDLElBQUksRUFBRyxFQUFFLE9BQU8sRUFBRyxtQkFBbUIsRUFBRTtTQUMzQyxDQUFDO3lDQXdCdUIsaUJBQWlCO1lBQ3BCLGdCQUFnQjtZQUNiLFlBQVk7WUFDVixTQUFTO1lBQ0EsbUJBQW1CO09BMUIxQyxjQUFjLENBNE8xQjtJQUFELHFCQUFDO0NBQUEsQUE1T0QsSUE0T0M7U0E1T1ksY0FBYyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IENvbXBvbmVudCwgT25Jbml0LCBBZnRlclZpZXdJbml0LCBPbkRlc3Ryb3ksIFZpZXdDb250YWluZXJSZWYsIElucHV0LCBPdXRwdXQsIEV2ZW50RW1pdHRlciwgVmlld0VuY2Fwc3VsYXRpb24sIEhvc3RMaXN0ZW5lciwgUmVuZGVyZXIyIH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XHJcbmltcG9ydCB7IHRpbWVyIH0gZnJvbSAncnhqcyc7XHJcbmltcG9ydCB7IFRyZWVOb2RlIH0gZnJvbSAncHJpbWVuZy9wcmltZW5nJztcclxuaW1wb3J0IHsgS2RUcmVlRHJvcGRvd25TdmMgfSBmcm9tICcuL2tkLXRyZWVkcm9wZG93bi1zdmMnO1xyXG5pbXBvcnQgeyBLZERvbUVsZW1TdmMgfSBmcm9tICcuLi9rZC1jb21tb24vaW5kZXgnO1xyXG5pbXBvcnQgeyBLZFRyZWVEcm9wZG93bkV2ZW50IH0gZnJvbSAnLi9rZC10cmVlZHJvcGRvd24tZXZlbnQnO1xyXG5pbXBvcnQgeyBJVHJlZUFwaSB9IGZyb20gJy4va2QtdHJlZWRyb3Bkb3duLWludGVyZmFjZSc7XHJcblxyXG5AQ29tcG9uZW50KHtcclxuICAgIHNlbGVjdG9yOiAna2QtdHJlZS1kcm9wZG93bicsXHJcbiAgICB0ZW1wbGF0ZVVybDogJy4va2QtYW5ndWxhci10cmVlZHJvcGRvd24uaHRtbCcsXHJcbiAgICBlbmNhcHN1bGF0aW9uOiBWaWV3RW5jYXBzdWxhdGlvbi5Ob25lLFxyXG4gICAgcHJvdmlkZXJzOiBbS2RUcmVlRHJvcGRvd25TdmMsIEtkRG9tRWxlbVN2Y10sXHJcbiAgICBob3N0IDogeyAnY2xhc3MnIDogJ2tkeC10cmVlLWRyb3Bkb3duJyB9XHJcbn0pXHJcblxyXG5leHBvcnQgY2xhc3MgS2RUcmVlRHJvcGRvd24gaW1wbGVtZW50cyBPbkluaXQsIEFmdGVyVmlld0luaXQsIE9uRGVzdHJveSB7XHJcbiAgICBwdWJsaWMgX3VwZGF0ZWREYXRhOiBBcnJheTxUcmVlTm9kZT4gPSBbXTtcclxuICAgIHB1YmxpYyBfdHJlZUlkOiBzdHJpbmcgPSAnJztcclxuICAgIHB1YmxpYyBfaGlkZTogYm9vbGVhbiA9IHRydWU7XHJcbiAgICBwdWJsaWMgc2VsZWN0ZWRTdHJpbmc6IHN0cmluZyA9ICcnO1xyXG4gICAgcHVibGljIHNlbGVjdGlvbk1vZGU6IHN0cmluZyA9ICcnO1xyXG5cclxuICAgIHByaXZhdGUgX3NlbGVjdGVkTm9kZXM6IEFycmF5PGFueT4gPSBbXTtcclxuICAgIHByaXZhdGUgX3NpbmdsZVNlbGVjdGlvblByZXZpb3VzOiBhbnk7XHJcbiAgICBwcml2YXRlIF90b3VjaG1vdmVFdmVudDogRnVuY3Rpb247XHJcbiAgICBwcml2YXRlIF90b3VjaGVuZEV2ZW50OiBGdW5jdGlvbjtcclxuICAgIHByaXZhdGUgX2ZpcmVmb3hNb3VzZUV2ZW50OiBGdW5jdGlvbjtcclxuICAgIHByaXZhdGUgX3doZWVsRXZ0OiBhbnkgPSBudWxsO1xyXG4gICAgcHJpdmF0ZSBfdGltZXI6IGFueTtcclxuICAgIHByaXZhdGUgX2xvYWRpbmdJY29uTGlzdDogb2JqZWN0ID0ge307XHJcblxyXG4gICAgQElucHV0KCkgY29uZmlnOiBhbnk7XHJcbiAgICBASW5wdXQoKSBhcGk6IElUcmVlQXBpO1xyXG5cclxuICAgIEBPdXRwdXQoKSBldmVudFNlbGVjdGVkTm9kZXM6IEV2ZW50RW1pdHRlcjxhbnk+ID0gbmV3IEV2ZW50RW1pdHRlcigpO1xyXG5cclxuICAgIGNvbnN0cnVjdG9yKFxyXG4gICAgICAgIHByaXZhdGUgX3RkZFN2YzogS2RUcmVlRHJvcGRvd25TdmMsXHJcbiAgICAgICAgcHJpdmF0ZSBfdmNyOiBWaWV3Q29udGFpbmVyUmVmLFxyXG4gICAgICAgIHByaXZhdGUgX2RvbVN2YzogS2REb21FbGVtU3ZjLFxyXG4gICAgICAgIHByaXZhdGUgX3JlbmRlcmVyOiBSZW5kZXJlcjIsXHJcbiAgICAgICAgcHJpdmF0ZSBfdHJlZURyb3Bkb3duRXZlbnQ6IEtkVHJlZURyb3Bkb3duRXZlbnRcclxuICAgICkge31cclxuXHJcbiAgICBASG9zdExpc3RlbmVyKCd3aW5kb3c6cmVzaXplJywgW10pXHJcbiAgICBvblJlc2l6ZSgpIHtcclxuICAgICAgICB0aGlzLl9oaWRlID0gdHJ1ZTtcclxuICAgICAgICB0aGlzLl9zZXRQb3BXaWR0aEhlaWdodCgpO1xyXG4gICAgfVxyXG5cclxuICAgIEBIb3N0TGlzdGVuZXIoJ2RvY3VtZW50Om1vdXNldXAnLCBbJyRldmVudCddKVxyXG4gICAgb25Eb2NDbGljayhkb2NDbGlja0V2ZW50OiBNb3VzZUV2ZW50KSB7XHJcbiAgICAgICAgdGhpcy5fc2V0VG9nZ2xlKGZhbHNlLCAnYmx1cicsIGRvY0NsaWNrRXZlbnQpO1xyXG4gICAgfVxyXG5cclxuICAgIEBIb3N0TGlzdGVuZXIoJ3dpbmRvdzptb3VzZXdoZWVsJywgWyckZXZlbnQnXSlcclxuICAgIG9uV2hlZWwod2luTW91c2VFdmVudDogTW91c2VFdmVudCkge1xyXG4gICAgICAgIGlmICh0aGlzLl93aGVlbEV2dCA9PT0gbnVsbCkge1xyXG4gICAgICAgICAgICB0aGlzLl93aGVlbEV2dCA9IHdpbk1vdXNlRXZlbnQ7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICBsZXQgcG9zaXRpb246IGFueSA9IHt4OiB0aGlzLl93aGVlbEV2dC5jbGllbnRYLCB5OiB0aGlzLl93aGVlbEV2dC5jbGllbnRZfTtcclxuICAgICAgICBpZiAodGhpcy5fdGRkU3ZjLmNoZWNrV2l0aGluQm91bmRpbmdCb3goJ25vdGJsdXInLCBwb3NpdGlvbiwgdGhpcy5fdHJlZUlkKSkge1xyXG4gICAgICAgICAgICBjbGVhclRpbWVvdXQodGhpcy5fdGltZXIpO1xyXG5cclxuICAgICAgICAgICAgdGhpcy5fdGltZXIgPSBzZXRUaW1lb3V0KCgpOiB2b2lkID0+IHtcclxuICAgICAgICAgICAgICAgIHRoaXMuX3NldFRvZ2dsZShmYWxzZSwgJ3Njcm9sbCcsIHRoaXMuX3doZWVsRXZ0KTtcclxuICAgICAgICAgICAgICAgIHRoaXMuX3doZWVsRXZ0ID0gbnVsbDtcclxuICAgICAgICAgICAgfSwgNTApO1xyXG4gICAgICAgIH1cclxuICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgdGhpcy5faGlkZSA9IHRydWU7XHJcbiAgICAgICAgICAgIHRoaXMuX3doZWVsRXZ0ID0gbnVsbDtcclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgbmdPbkluaXQoKTogdm9pZCB7XHJcblxyXG4gICAgICAgIHRoaXMuX3RyZWVJZCA9ICh0eXBlb2YgdGhpcy5jb25maWcuaWQgIT09ICd1bmRlZmluZWQnKSA/IHRoaXMuY29uZmlnLmlkIDogJ3RyZWUtY2xhc3MnO1xyXG4gICAgICAgIHRoaXMuc2VsZWN0aW9uTW9kZSA9IHRoaXMuX3RkZFN2Yy5nZXRNb2RlKHRoaXMuY29uZmlnKTtcclxuXHJcbiAgICAgICAgaWYgKHR5cGVvZiB0aGlzLmNvbmZpZy5saXN0ID09PSAndW5kZWZpbmVkJykge1xyXG4gICAgICAgICAgICB0aGlzLmNvbmZpZy5saXN0ID0gW107XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICAvLyBsZXQgdGVtcERhdGE6IEFycmF5PGFueT4gPSB0aGlzLl90ZGRTdmMuZ2V0VXBkYXRlTm9kZSh0aGlzLmNvbmZpZywgdGhpcy5zZWxlY3Rpb25Nb2RlKTtcclxuICAgICAgICB0aGlzLl91cGRhdGVkRGF0YSA9IHRoaXMuX3RkZFN2Yy5nZXRVcGRhdGVOb2RlKHRoaXMuY29uZmlnLCB0aGlzLnNlbGVjdGlvbk1vZGUpO1xyXG4gICAgICAgIC8vIHRoaXMuX3VwZGF0ZWREYXRhID0gSlNPTi5wYXJzZShKU09OLnN0cmluZ2lmeSh0ZW1wRGF0YSkpO1xyXG4gICAgICAgIHRoaXMuX3NldFRvdWNoTGlzdGVuZXJBbmRGRigpO1xyXG4gICAgICAgIHRoaXMuX3NlbGVjdGVkTm9kZXMgPSB0aGlzLl90ZGRTdmMudXBkYXRlSW5pdFNlbGVjdGVkKHRoaXMuX3VwZGF0ZWREYXRhLCB0aGlzLnNlbGVjdGlvbk1vZGUpO1xyXG5cclxuICAgICAgICB0aW1lcigpLnN1YnNjcmliZSgoKTogdm9pZCA9PiB7XHJcbiAgICAgICAgICAgIHRoaXMuX3VwZGF0ZUFuZEVtaXQoKTtcclxuICAgICAgICB9KTtcclxuICAgIH1cclxuXHJcbiAgICBuZ0FmdGVyVmlld0luaXQoKTogdm9pZCB7XHJcbiAgICAgICAgdGhpcy5fc2V0Qm9keVBvc2l0aW9uKHRydWUpO1xyXG4gICAgfVxyXG5cclxuICAgIG5nT25EZXN0cm95KCk6IHZvaWQge1xyXG4gICAgICAgIGNsZWFyVGltZW91dCh0aGlzLl90aW1lcik7XHJcbiAgICAgICAgbGV0IHF1ZXJ5U3RyaW5nOiBzdHJpbmcgPSAnLicgKyB0aGlzLl90cmVlSWQgKyAnLmtkeC1wb3BvdmVyLXdpbmRvdyc7XHJcbiAgICAgICAgdGhpcy5fZG9tU3ZjLnJlbW92ZUVsZW1lbnRCeUNsYXNzKHF1ZXJ5U3RyaW5nKTtcclxuICAgICAgICB0aGlzLl90b3VjaGVuZEV2ZW50KCk7XHJcbiAgICAgICAgdGhpcy5fdG91Y2htb3ZlRXZlbnQoKTtcclxuICAgICAgICB0aGlzLl9maXJlZm94TW91c2VFdmVudCgpO1xyXG4gICAgfVxyXG5cclxuICAgIG5vZGVTZWxlY3QoX2RhdGE6IGFueSk6IHZvaWQge1xyXG4gICAgICAgIGlmICh0aGlzLnNlbGVjdGlvbk1vZGUgPT09ICdtdWx0aXBsZScpIF9kYXRhLm5vZGUuZGF0YS5zZWxlY3RlZCA9ICFfZGF0YS5ub2RlLmRhdGEuc2VsZWN0ZWQ7XHJcbiAgICAgICAgZWxzZSB7XHJcbiAgICAgICAgICAgIGlmICh0eXBlb2YgdGhpcy5fc2luZ2xlU2VsZWN0aW9uUHJldmlvdXMgIT09ICd1bmRlZmluZWQnKSB0aGlzLl9zaW5nbGVTZWxlY3Rpb25QcmV2aW91cy5ub2RlLmRhdGEuc2VsZWN0ZWQgPSBmYWxzZTtcclxuICAgICAgICAgICAgX2RhdGEubm9kZS5kYXRhLnNlbGVjdGVkID0gdHJ1ZTtcclxuICAgICAgICAgICAgdGhpcy5fc2luZ2xlU2VsZWN0aW9uUHJldmlvdXMgPSBfZGF0YTtcclxuICAgICAgICB9XHJcbiAgICAgICAgdGhpcy5fc2VsZWN0ZWROb2RlcyA9IHRoaXMuX3RkZFN2Yy51cGRhdGVTZWxlY3RlZE5vZGVzKHRoaXMuX3NlbGVjdGVkTm9kZXMsIF9kYXRhLm5vZGUsIHRoaXMuc2VsZWN0aW9uTW9kZSk7XHJcbiAgICAgICAgdGhpcy5fdXBkYXRlQW5kRW1pdCgpO1xyXG4gICAgfVxyXG5cclxuICAgIGxvYWROb2RlKF9ldmVudDogYW55KTogdm9pZCB7XHJcblxyXG4gICAgICAgIGlmICghX2V2ZW50Lm5vZGUuY2hpbGRyZW4gfHwgX2V2ZW50Lm5vZGUuY2hpbGRyZW4ubGVuZ3RoIDw9IDApIHtcclxuICAgICAgICAgICAgdGhpcy5fc2hvd0xvYWRpbmdJY29uKF9ldmVudC5vcmlnaW5hbEV2ZW50LnRhcmdldCwgdHJ1ZSk7XHJcblxyXG4gICAgICAgICAgICBpZiAoX2V2ZW50Lm5vZGUpIHtcclxuICAgICAgICAgICAgICAgIHRoaXMuX2luaXRDaGlsZEFwaShfZXZlbnQubm9kZS5kYXRhLmlkLCBfZXZlbnQub3JpZ2luYWxFdmVudC50YXJnZXQpO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIHNob3dQb3AoKTogdm9pZCB7XHJcbiAgICAgICAgdGhpcy5faGlkZSA9ICF0aGlzLl9oaWRlO1xyXG4gICAgICAgIHRoaXMuX3NldEJvZHlQb3NpdGlvbihmYWxzZSk7XHJcbiAgICAgICAgdGhpcy5fc2V0UG9wV2lkdGhIZWlnaHQoKTtcclxuXHJcbiAgICAgICAgdGhpcy5fdGRkU3ZjLmF1dG9FeHBhbmRMaXN0KHRoaXMuY29uZmlnLCB0aGlzLl91cGRhdGVkRGF0YSk7XHJcbiAgICAgICAgaWYgKHRoaXMuY29uZmlnLmxpc3QubGVuZ3RoID09PSAwKSB7XHJcblxyXG4gICAgICAgICAgICBsZXQgbG9hZGluZ0ljb246IEVsZW1lbnQgPSB0aGlzLl92Y3IuZWxlbWVudC5uYXRpdmVFbGVtZW50LnBhcmVudE5vZGU7XHJcbiAgICAgICAgICAgIHRoaXMuX3Nob3dMb2FkaW5nSWNvbihsb2FkaW5nSWNvbiwgdHJ1ZSwgdHJ1ZSk7XHJcblxyXG4gICAgICAgICAgICB0aGlzLl9pbml0UGFyZW50QXBpKGxvYWRpbmdJY29uKTtcclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfaW5pdFBhcmVudEFwaShfbG9hZGluZ0ljb246IEVsZW1lbnQpOiB2b2lkIHtcclxuICAgICAgICB0aGlzLl9sb2FkaW5nSWNvbkxpc3RbdGhpcy5fdHJlZUlkXSA9IF9sb2FkaW5nSWNvbjtcclxuXHJcbiAgICAgICAgbGV0IHZtOiBLZFRyZWVEcm9wZG93biA9IHRoaXM7XHJcbiAgICAgICAgdGhpcy5hcGkudXBkYXRlTGlzdCA9IChfdHJlZUlkOiBzdHJpbmcsIF9saXN0RGF0YTogQXJyYXk8YW55PikgPT4ge1xyXG4gICAgICAgICAgICB2bS5fc2hvd0xvYWRpbmdJY29uKHZtLl9sb2FkaW5nSWNvbkxpc3RbX3RyZWVJZF0sIGZhbHNlKTtcclxuICAgICAgICAgICAgdm0uY29uZmlnLmxpc3QgPSBfbGlzdERhdGE7XHJcbiAgICAgICAgICAgIHZtLl91cGRhdGVkRGF0YSA9IHZtLl90ZGRTdmMuZ2V0VXBkYXRlTm9kZSh2bS5jb25maWcsIHZtLnNlbGVjdGlvbk1vZGUpO1xyXG4gICAgICAgICAgICB2bS5fc2VsZWN0ZWROb2RlcyA9IHZtLl90ZGRTdmMudXBkYXRlSW5pdFNlbGVjdGVkKHZtLl91cGRhdGVkRGF0YSwgdm0uc2VsZWN0aW9uTW9kZSk7XHJcbiAgICAgICAgICAgIHZtLl91cGRhdGVBbmRFbWl0KCk7XHJcbiAgICAgICAgfTtcclxuXHJcbiAgICAgICAgdGhpcy5fdHJlZURyb3Bkb3duRXZlbnQubG9hZExpc3QodGhpcy5fdHJlZUlkKTtcclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF9pbml0Q2hpbGRBcGkoX2lkOiBzdHJpbmcsIF9sb2FkaW5nSWNvbjogRWxlbWVudCk6IHZvaWQge1xyXG4gICAgICAgIHRoaXMuX2xvYWRpbmdJY29uTGlzdFtfaWRdID0gX2xvYWRpbmdJY29uO1xyXG5cclxuICAgICAgICBsZXQgdm06IEtkVHJlZURyb3Bkb3duID0gdGhpcztcclxuICAgICAgICB0aGlzLmFwaS51cGRhdGVDaGlsZE5vZGUgPSAoX3BhcmVudElkOiBzdHJpbmcsIF9yZXR1cm5EYXRhOiBBcnJheTxvYmplY3Q+KSA9PiB7XHJcbiAgICAgICAgICAgIHZtLl9zaG93TG9hZGluZ0ljb24odm0uX2xvYWRpbmdJY29uTGlzdFtfcGFyZW50SWRdLCBmYWxzZSk7XHJcbiAgICAgICAgICAgIHZtLl9zZWxlY3RlZE5vZGVzID0gdm0uX3RkZFN2Yy51cGRhdGVDb25maWcoX3BhcmVudElkLCBfcmV0dXJuRGF0YSwgdm0uX3VwZGF0ZWREYXRhLCB2bS5zZWxlY3Rpb25Nb2RlKTtcclxuICAgICAgICAgICAgdm0uX3VwZGF0ZUFuZEVtaXQoKTtcclxuICAgICAgICB9O1xyXG5cclxuICAgICAgICB0aGlzLl90cmVlRHJvcGRvd25FdmVudC5jaGlsZEV4cGFuZChfaWQpO1xyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX3Nob3dMb2FkaW5nSWNvbihfZWxlbWVudDogRWxlbWVudCwgX3Nob3dMb2FkaW5nOiBib29sZWFuLCBfaXNMaXN0Tm9kZT86IGJvb2xlYW4pOiB2b2lkIHtcclxuXHJcbiAgICAgICAgaWYgKF9zaG93TG9hZGluZykge1xyXG4gICAgICAgICAgICB0aGlzLl9yZW5kZXJlci5hZGRDbGFzcyhfZWxlbWVudCwgJ2tkeC1sb2FkaW5nLWNsYXNzJyk7XHJcbiAgICAgICAgICAgIGlmICh0eXBlb2YgX2lzTGlzdE5vZGUgPT09ICd1bmRlZmluZWQnIHx8ICh0eXBlb2YgX2lzTGlzdE5vZGUgPT09ICdib29sZWFuJyAmJiAhX2lzTGlzdE5vZGUpKSB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLl9yZW5kZXJlci5hZGRDbGFzcyhfZWxlbWVudCwgJ2ZhLXNwaW5uZXInKTtcclxuICAgICAgICAgICAgICAgIHRoaXMuX3JlbmRlcmVyLmFkZENsYXNzKF9lbGVtZW50LCAnZmEtcHVsc2UnKTtcclxuICAgICAgICAgICAgICAgIHRoaXMuX3JlbmRlcmVyLmFkZENsYXNzKF9lbGVtZW50LCAnZmEtbGcnKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgIF9lbGVtZW50LmNsYXNzTmFtZSA9IF9lbGVtZW50LmNsYXNzTmFtZS5yZXBsYWNlKC8oPzpefFxccylrZHgtbG9hZGluZy1jbGFzcyg/IVxcUykvZywgJycpO1xyXG4gICAgICAgICAgICBpZiAodHlwZW9mIF9pc0xpc3ROb2RlID09PSAndW5kZWZpbmVkJyB8fCAodHlwZW9mIF9pc0xpc3ROb2RlID09PSAnYm9vbGVhbicgJiYgIV9pc0xpc3ROb2RlKSkge1xyXG4gICAgICAgICAgICAgICAgX2VsZW1lbnQuY2xhc3NOYW1lID0gX2VsZW1lbnQuY2xhc3NOYW1lLnJlcGxhY2UoLyg/Ol58XFxzKWZhLXNwaW5uZXIoPyFcXFMpL2csICcnKTtcclxuICAgICAgICAgICAgICAgIF9lbGVtZW50LmNsYXNzTmFtZSA9IF9lbGVtZW50LmNsYXNzTmFtZS5yZXBsYWNlKC8oPzpefFxccylmYS1wdWxzZSg/IVxcUykvZywgJycpO1xyXG4gICAgICAgICAgICAgICAgX2VsZW1lbnQuY2xhc3NOYW1lID0gX2VsZW1lbnQuY2xhc3NOYW1lLnJlcGxhY2UoLyg/Ol58XFxzKWZhLWxnKD8hXFxTKS9nLCAnJyk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcblxyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX3VwZGF0ZUFuZEVtaXQoKTogdm9pZCB7XHJcbiAgICAgICAgdGhpcy5zZWxlY3RlZFN0cmluZyA9IHRoaXMuX3RkZFN2Yy51cGRhdGVTZWxlY3RlZFN0cmluZyh0aGlzLl9zZWxlY3RlZE5vZGVzKTtcclxuICAgICAgICB0aGlzLmV2ZW50U2VsZWN0ZWROb2Rlcy5lbWl0KHRoaXMuX3NlbGVjdGVkTm9kZXMpO1xyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX3NldFBvcFdpZHRoSGVpZ2h0KCk6IHZvaWQge1xyXG4gICAgICAgIGxldCBxdWVyeVN0cmluZzogc3RyaW5nID0gJy4nICsgdGhpcy5fdHJlZUlkICsgJy5rZHgtcG9wb3Zlci13aW5kb3cnO1xyXG4gICAgICAgIGxldCBwb3BvdmVyV2luZG93OiBFbGVtZW50ID0gZG9jdW1lbnQucXVlcnlTZWxlY3RvcihxdWVyeVN0cmluZyk7XHJcbiAgICAgICAgdGhpcy5fc2V0UG9wb3ZlcldpZHRoKHBvcG92ZXJXaW5kb3cpO1xyXG4gICAgICAgIHRoaXMuX3NldFBvcG92ZXJNYXhIZWlnaHQocG9wb3ZlcldpbmRvdyk7XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfc2V0UG9wb3ZlcldpZHRoKF9wb3BvdmVyV2luZG93OiBFbGVtZW50KTogdm9pZCB7XHJcbiAgICAgICAgbGV0IHNlbGVjdGlvbkVsZTogSFRNTEVsZW1lbnQgPSB0aGlzLl92Y3IuZWxlbWVudC5uYXRpdmVFbGVtZW50O1xyXG4gICAgICAgIGxldCB3aWR0aDogc3RyaW5nID0gc2VsZWN0aW9uRWxlLmdldEJvdW5kaW5nQ2xpZW50UmVjdCgpLndpZHRoICsgJ3B4JztcclxuICAgICAgICB0aGlzLl9kb21TdmMuc2V0RWxlbWVudFN0eWxlKF9wb3BvdmVyV2luZG93LCAnbWF4LXdpZHRoJywgd2lkdGgpO1xyXG4gICAgICAgIHRoaXMuX2RvbVN2Yy5zZXRFbGVtZW50U3R5bGUoX3BvcG92ZXJXaW5kb3csICdtaW4td2lkdGgnLCB3aWR0aCk7XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfc2V0UG9wb3Zlck1heEhlaWdodChfcG9wb3ZlcldpbmRvdzogRWxlbWVudCk6IHZvaWQge1xyXG4gICAgICAgIGxldCBkcm9wZG93bjogRWxlbWVudCA9IHRoaXMuX3Zjci5lbGVtZW50Lm5hdGl2ZUVsZW1lbnQucGFyZW50Tm9kZTtcclxuICAgICAgICBsZXQgdXNhYmxlSGVpZ2h0OiBudW1iZXIgPSB3aW5kb3cuaW5uZXJIZWlnaHQgLSBkcm9wZG93bi5nZXRCb3VuZGluZ0NsaWVudFJlY3QoKS5ib3R0b20gLSA1O1xyXG4gICAgICAgIGxldCBtYXhIZWlnaHQ6IG51bWJlciA9ICh1c2FibGVIZWlnaHQgPiAzMDApID8gMzAwIDogdXNhYmxlSGVpZ2h0O1xyXG4gICAgICAgIGxldCBtYXhIZWlnaHRQeDogc3RyaW5nID0gbWF4SGVpZ2h0ICsgJ3B4JztcclxuICAgICAgICBsZXQgdHJlZTogRWxlbWVudCA9IF9wb3BvdmVyV2luZG93LnF1ZXJ5U2VsZWN0b3IoJy51aS10cmVlIC51aS10cmVlLWNvbnRhaW5lcicpO1xyXG4gICAgICAgIGlmICh0cmVlICE9PSBudWxsKSB0aGlzLl9kb21TdmMuc2V0RWxlbWVudFN0eWxlKHRyZWUsICdtYXgtaGVpZ2h0JywgbWF4SGVpZ2h0UHgpO1xyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX3NldFRvZ2dsZShfaXNUb3VjaDogYm9vbGVhbiwgX2NoZWNrVHlwZTogc3RyaW5nLCBfZXZlbnRPYmo6IGFueSk6IHZvaWQge1xyXG5cclxuICAgICAgICBsZXQgcG9zaXRpb246IGFueSA9IChfaXNUb3VjaCkgPyB0aGlzLl90ZGRTdmMuZ2V0VG91Y2hQb3NpdGlvbihfZXZlbnRPYmopIDogeyB4OiBfZXZlbnRPYmouY2xpZW50WCwgeTogX2V2ZW50T2JqLmNsaWVudFkgfTtcclxuICAgICAgICBsZXQgdG9nZ2xlOiBib29sZWFuID0gKF9jaGVja1R5cGUgPT09ICdibHVyJykgPyB0aGlzLl90ZGRTdmMuY2hlY2tXaXRoaW5Cb3VuZGluZ0JveChfY2hlY2tUeXBlLCBwb3NpdGlvbiwgdGhpcy5fdHJlZUlkLCB0aGlzLl92Y3IuZWxlbWVudC5uYXRpdmVFbGVtZW50LnBhcmVudE5vZGUpIDogdGhpcy5fdGRkU3ZjLmNoZWNrV2l0aGluQm91bmRpbmdCb3goX2NoZWNrVHlwZSwgcG9zaXRpb24sIHRoaXMuX3RyZWVJZCk7XHJcbiAgICAgICAgaWYgKCF0b2dnbGUpIHRoaXMuX2hpZGUgPSB0cnVlO1xyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX3NldFRvdWNoTGlzdGVuZXJBbmRGRigpOiB2b2lkIHtcclxuICAgICAgICB0aGlzLl9maXJlZm94TW91c2VFdmVudCA9IHRoaXMuX3JlbmRlcmVyLmxpc3RlbignZG9jdW1lbnQnLCAnRE9NTW91c2VTY3JvbGwnLCAoZmZNb3VzZUV2ZW50OiBNb3VzZUV2ZW50KTogdm9pZCA9PiB7XHJcbiAgICB0aGlzLl9zZXRUb2dnbGUoZmFsc2UsICdzY3JvbGwnLCBmZk1vdXNlRXZlbnQpO1xyXG59KTtcclxuICAgICAgICB0aGlzLl90b3VjaG1vdmVFdmVudCA9IHRoaXMuX3JlbmRlcmVyLmxpc3RlbignZG9jdW1lbnQnLCAndG91Y2htb3ZlJywgKHRvdWNoRXZlbnQ6IFRvdWNoRXZlbnQpOiB2b2lkID0+IHtcclxuICAgIHRoaXMuX3NldFRvZ2dsZSh0cnVlLCAnc2Nyb2xsJywgdG91Y2hFdmVudCk7XHJcbn0pO1xyXG4gICAgICAgIHRoaXMuX3RvdWNoZW5kRXZlbnQgPSB0aGlzLl9yZW5kZXJlci5saXN0ZW4oJ2RvY3VtZW50JywgJ3RvdWNoc3RhcnQnLCAodG91Y2hFdmVudDogVG91Y2hFdmVudCk6IHZvaWQgPT4ge1xyXG4gICAgdGhpcy5fc2V0VG9nZ2xlKHRydWUsICdibHVyJywgdG91Y2hFdmVudCk7XHJcbn0pO1xyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX3NldEJvZHlQb3NpdGlvbihfaXNGaXJzdENoZWNrOiBib29sZWFuKTogdm9pZCB7XHJcbiAgICAgICAgbGV0IG1haW5FbGU6IENsaWVudFJlY3QgPSB0aGlzLl92Y3IuZWxlbWVudC5uYXRpdmVFbGVtZW50LmdldEJvdW5kaW5nQ2xpZW50UmVjdCgpO1xyXG4gICAgICAgIGxldCBxdWVyeVN0cmluZzogc3RyaW5nID0gJy4nICsgdGhpcy5fdHJlZUlkICsgJy5rZHgtcG9wb3Zlci13aW5kb3cnO1xyXG4gICAgICAgIGxldCB0b0JvZHk6IEVsZW1lbnQgPSAoX2lzRmlyc3RDaGVjaykgPyB0aGlzLl92Y3IuZWxlbWVudC5uYXRpdmVFbGVtZW50LnF1ZXJ5U2VsZWN0b3IocXVlcnlTdHJpbmcpIDogZG9jdW1lbnQucXVlcnlTZWxlY3RvcihxdWVyeVN0cmluZyk7XHJcbiAgICAgICAgbGV0IHRvcFBvczogc3RyaW5nID0gKG1haW5FbGUuYm90dG9tICsgOCkgKyAncHgnO1xyXG4gICAgICAgIGxldCBsZWZ0UG9zOiBzdHJpbmcgPSBtYWluRWxlLmxlZnQgKyAncHgnO1xyXG4gICAgICAgIHRoaXMuX2RvbVN2Yy5zZXRFbGVtZW50U3R5bGUodG9Cb2R5LCAndG9wJywgdG9wUG9zKTtcclxuICAgICAgICB0aGlzLl9kb21TdmMuc2V0RWxlbWVudFN0eWxlKHRvQm9keSwgJ2xlZnQnLCBsZWZ0UG9zKTtcclxuICAgICAgICBpZiAoX2lzRmlyc3RDaGVjaykgZG9jdW1lbnQuYm9keS5hcHBlbmRDaGlsZCh0b0JvZHkpO1xyXG4gICAgfVxyXG59XHJcbiJdfQ==