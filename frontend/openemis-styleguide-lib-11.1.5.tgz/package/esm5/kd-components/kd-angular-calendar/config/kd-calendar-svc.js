import { __decorate, __extends, __metadata, __param } from "tslib";
import { LOCALE_ID, Inject, Injectable } from '@angular/core';
import { CalendarEventTitleFormatter, CalendarDateFormatter } from 'angular-calendar';
import { format, addYears, addMonths, addWeeks, addDays, subYears, subMonths, subWeeks, subDays, differenceInCalendarDays } from 'date-fns';
var CustomEventTitleFormatter = /** @class */ (function (_super) {
    __extends(CustomEventTitleFormatter, _super);
    function CustomEventTitleFormatter(locale) {
        return _super.call(this) || this;
    }
    CustomEventTitleFormatter.prototype.month = function (event) {
        var badgeColor = event['badge']['color'];
        var colorClass = (badgeColor === 'green') ? 'btn-success' : (badgeColor === 'red') ? 'btn-error' : (badgeColor === 'yellow') ? 'btn-warning' : 'btn-info';
        var note = (event['note']) ? '<br/>' + event['note'] : '';
        // let eventDate = '('+new Intl.DateTimeFormat(this.locale, {month: 'short', day: '2-digit'}).format(event.start)+') ';
        // let eventDate = '('+new Intl.DateTimeFormat('en-GB', {day: '2-digit', month: 'short'}).format(event.start)+') ';
        return '<small class="kdx-cal-day-event ' + colorClass + '">' + event['badge']['label'] + '</small>\
                <div class="kdx-cal-event-details"><b>' + ("" + event.title) + '</b>' + note + '</div>';
    };
    CustomEventTitleFormatter.prototype.week = function (event) {
        return '<small class="kdx-cal-day-event">' + event['badge']['label'] + '</small>';
    };
    CustomEventTitleFormatter.prototype.day = function (event) {
        return '<small class="kdx-cal-day-event">' + event['badge']['label'] + '</small>';
    };
    CustomEventTitleFormatter.ctorParameters = function () { return [
        { type: String, decorators: [{ type: Inject, args: [LOCALE_ID,] }] }
    ]; };
    CustomEventTitleFormatter = __decorate([
        Injectable(),
        __param(0, Inject(LOCALE_ID)),
        __metadata("design:paramtypes", [String])
    ], CustomEventTitleFormatter);
    return CustomEventTitleFormatter;
}(CalendarEventTitleFormatter));
export { CustomEventTitleFormatter };
var CustomDateFormatter = /** @class */ (function (_super) {
    __extends(CustomDateFormatter, _super);
    function CustomDateFormatter() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    CustomDateFormatter.prototype.monthViewColumnHeader = function (_a) {
        var date = _a.date, locale = _a.locale;
        return new Intl.DateTimeFormat(locale, { weekday: 'short' }).format(date);
    };
    CustomDateFormatter.prototype.monthViewTitle = function (_a) {
        var date = _a.date, locale = _a.locale;
        return new Intl.DateTimeFormat(locale, {
            year: 'numeric',
            month: 'long'
        }).format(date);
    };
    CustomDateFormatter.prototype.weekViewColumnHeader = function (_a) {
        var date = _a.date, locale = _a.locale;
        return new Intl.DateTimeFormat(locale, { weekday: 'short' }).format(date);
    };
    CustomDateFormatter.prototype.dayViewHour = function (_a) {
        var date = _a.date, locale = _a.locale;
        return new Intl.DateTimeFormat(locale, {
            hour: 'numeric',
            minute: 'numeric'
        }).format(date);
    };
    CustomDateFormatter = __decorate([
        Injectable()
    ], CustomDateFormatter);
    return CustomDateFormatter;
}(CalendarDateFormatter));
export { CustomDateFormatter };
var CalendarHelper = /** @class */ (function () {
    function CalendarHelper() {
        this._positionList = ['top', 'left', 'bottom', 'right'];
        this._colorList = ['yellow', 'blue', 'red', 'green'];
        this._highlightList = ['grey', 'gray', 'white'];
    }
    CalendarHelper.prototype.addMissingRequiredPropertyForEvent = function (event, colorTray) {
        var startDate = event.start;
        if (this._checkStringDateFormat(event.start)) {
            if (typeof startDate === 'string') {
                startDate = this.stringToDate(event.start.toString().trim() + ' 00:00:01');
            }
            // is the event start date valid? if start date is invalid, event is invalid and will not be added into calendar
            if (typeof startDate !== 'undefined' && startDate !== undefined && startDate !== null) {
                var endDate = void 0;
                if (event.end) {
                    if (this._checkStringDateFormat(event.end)) {
                        endDate = this.stringToDate(event.end + ' 23:59:59');
                    }
                    else {
                        console.warn('Kd-Calendar ERROR: Date format for start/end date is wrong. Date format: YYYY-MM-DD', event);
                        return false;
                    }
                }
                else {
                    endDate = this.stringToDate(event.start + ' 23:59:59');
                }
                // endDate = (differenceInCalendarDays(startDate, endDate) <= 0) ? endDate : this.stringToDate(event.start + ' 23:59:59');
                var color = this._setBadgeColor(event, colorTray);
                this._setHighlightColor(event);
                event.title = event.name;
                event.start = startDate;
                event.end = endDate;
                event.color = color;
                event.resizable = { beforeStart: false, afterEnd: false };
                event.draggable = false;
                event.meta = {
                    incrementsBadgeTotal: false
                };
                if (event.badge.position === undefined || !this._positionList.includes(event.badge.position)) {
                    console.warn('Kd-Calendar ERROR: Badge position of ' + event.badge.position + ' is invalid and has been automatically set to bottom. Only "top", "bottom", "left" and "right" is allowed', event);
                    event.badge.position = 'bottom';
                }
            }
            else {
                console.warn('Kd-Calendar ERROR: Unable to display invalid Event. Event requires: id, name, badge {label}, start', event);
            }
            return true;
        }
        else {
            console.warn('Kd-Calendar ERROR: Date format for start/end date is wrong. Date format: YYYY-MM-DD', event);
            return false;
        }
    };
    CalendarHelper.prototype._checkStringDateFormat = function (dateToCheck) {
        dateToCheck = dateToCheck.toString().trim();
        if (dateToCheck.indexOf('-') !== -1) {
            var dateArr = dateToCheck.split('-');
            if (dateArr.length === 3 && dateArr[0].length === 4 && dateArr[1].length === 2 && dateArr[2].length === 2) {
                return true;
            }
        }
        return false;
    };
    CalendarHelper.prototype.cleanEventProperty = function (event) {
        return {
            id: event.id,
            name: event.title,
            note: event.note,
            badge: { label: event.badge.label, position: event.badge.position, color: event.badge.color, highlight: event.badge.highlight },
            start: format(new Date(event.start), 'YYYY-MM-DD'),
            end: format(new Date(event.end), 'YYYY-MM-DD'),
        };
    };
    CalendarHelper.prototype.stringToDate = function (datestring) {
        if (typeof datestring === 'string') {
            var dateArr = datestring.toString().split(/[^0-9]/);
            var month = parseInt(dateArr[1]) - 1;
            return new Date(parseInt(dateArr[0]), month, parseInt(dateArr[2]), parseInt(dateArr[3]), parseInt(dateArr[4]), parseInt(dateArr[5]));
        }
        return datestring;
    };
    CalendarHelper.prototype.getUniqueDateToHighlight = function (dayDate, events) {
        var toHighlight = false;
        for (var i = 0; i < events.length; i++) {
            var event_1 = events[i];
            if ((differenceInCalendarDays(dayDate, new Date(event_1.start)) >= 0) && (differenceInCalendarDays(dayDate, new Date(event_1.end)) <= 0)) {
                if (event_1.badge.highlight === 'grey') {
                    toHighlight = true;
                }
                else {
                    return false;
                }
            }
        }
        return toHighlight;
    };
    CalendarHelper.prototype.getViewDate = function (calendarType, action, viewDate) {
        var newDate = false;
        if (calendarType === 'today') {
            newDate = new Date();
        }
        else {
            newDate = this.stringToDate(viewDate);
            if (calendarType === 'year') {
                if (action === 'next') {
                    newDate = addYears(newDate, 1);
                }
                else if (action === 'previous') {
                    newDate = subYears(newDate, 1);
                }
            }
            else if (calendarType === 'month') {
                if (action === 'next') {
                    newDate = addMonths(newDate, 1);
                }
                else if (action === 'previous') {
                    newDate = subMonths(newDate, 1);
                }
            }
            else if (calendarType === 'week') {
                if (action === 'next') {
                    newDate = addWeeks(newDate, 1);
                }
                else if (action === 'previous') {
                    newDate = subWeeks(newDate, 1);
                }
            }
            else if (calendarType === 'day') {
                if (action === 'next') {
                    newDate = addDays(newDate, 1);
                }
                else if (action === 'previous') {
                    newDate = subDays(newDate, 1);
                }
            }
            else {
                var isDate = this.stringToDate(calendarType + ' 00:00:01');
                if (isNaN(isDate.getTime()) === false) {
                    newDate = isDate; // valid date
                }
            }
        }
        return newDate;
    };
    CalendarHelper.prototype.generateViewMoreValue = function (eventsLength) {
        var output = eventsLength - 4;
        if (output < 1000) {
            return '+' + output.toString();
        }
        return '+999';
    };
    CalendarHelper.prototype.createCloseIconElement = function () {
        var spanEl = document.createElement('span');
        spanEl.setAttribute('class', 'kdx-cal-close-open-event');
        var iconEl = document.createElement('i');
        iconEl.setAttribute('class', 'fa kd-close');
        spanEl.appendChild(iconEl);
        return spanEl;
    };
    CalendarHelper.prototype.getOpenedDrawer = function (eventOpenedDrawers, _currentDrawer) {
        var isIconAdded = true;
        if (_currentDrawer === null) {
            _currentDrawer = eventOpenedDrawers[0];
            isIconAdded = false;
        }
        else {
            for (var i = 0; i < eventOpenedDrawers.length; i++) {
                var openedDrawer = eventOpenedDrawers[i];
                if (openedDrawer !== _currentDrawer) {
                    _currentDrawer = openedDrawer;
                    isIconAdded = false;
                    break;
                }
            }
        }
        return { element: _currentDrawer, isIconAdded: isIconAdded };
    };
    CalendarHelper.prototype._setBadgeColor = function (event, colorTray) {
        var color = { primary: '#2a6db0', secondary: '#2F79C3' };
        if (event.badge.color !== undefined && !this._colorList.includes(event.badge.color)) {
            console.warn('Kd-Calendar ERROR: event badge color ' + event.badge.color + ' is not recognised and has been automatically set to blue. Only "yellow" or "blue" or "red" or "green" are allowed', event);
        }
        else if (event.badge.color !== undefined) {
            color = { primary: colorTray[event.badge.color].primary, secondary: colorTray[event.badge.color].secondary };
        }
        return color;
    };
    CalendarHelper.prototype._setHighlightColor = function (event) {
        if (event.badge.highlight !== undefined && !this._highlightList.includes(event.badge.highlight)) {
            console.warn('Kd-Calendar ERROR: event badge highlight ' + event.badge.highlight + ' is not recognised and has been automatically set to white. Only "grey" and "white" are allowed', event);
        }
        else if (event.badge.highlight !== undefined && event.badge.highlight !== 'white') {
            event.badge.highlight = 'grey'; // standardize gray/grey to grey
        }
    };
    CalendarHelper = __decorate([
        Injectable()
    ], CalendarHelper);
    return CalendarHelper;
}());
export { CalendarHelper };
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoia2QtY2FsZW5kYXItc3ZjLmpzIiwic291cmNlUm9vdCI6Im5nOi8vb3BlbmVtaXMtc3R5bGVndWlkZS1saWIvIiwic291cmNlcyI6WyJrZC1jb21wb25lbnRzL2tkLWFuZ3VsYXItY2FsZW5kYXIvY29uZmlnL2tkLWNhbGVuZGFyLXN2Yy50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiO0FBQUEsT0FBTyxFQUFFLFNBQVMsRUFBRSxNQUFNLEVBQUUsVUFBVSxFQUFFLE1BQU0sZUFBZSxDQUFDO0FBQzlELE9BQU8sRUFBRSwyQkFBMkIsRUFBaUIscUJBQXFCLEVBQXVCLE1BQU0sa0JBQWtCLENBQUM7QUFFMUgsT0FBTyxFQUNILE1BQU0sRUFDTixRQUFRLEVBQ1IsU0FBUyxFQUNULFFBQVEsRUFDUixPQUFPLEVBQ1AsUUFBUSxFQUNSLFNBQVMsRUFDVCxRQUFRLEVBQ1IsT0FBTyxFQUNQLHdCQUF3QixFQUMzQixNQUFNLFVBQVUsQ0FBQztBQUdsQjtJQUErQyw2Q0FBMkI7SUFDdEUsbUNBQStCLE1BQWM7ZUFDekMsaUJBQU87SUFDWCxDQUFDO0lBRUQseUNBQUssR0FBTCxVQUFNLEtBQW9CO1FBRXRCLElBQUksVUFBVSxHQUFXLEtBQUssQ0FBQyxPQUFPLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQztRQUVqRCxJQUFJLFVBQVUsR0FBVyxDQUFDLFVBQVUsS0FBSyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsYUFBYSxDQUFDLENBQUMsQ0FBQyxDQUFDLFVBQVUsS0FBSyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQyxDQUFDLFVBQVUsS0FBSyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsYUFBYSxDQUFDLENBQUMsQ0FBQyxVQUFVLENBQUM7UUFFbEssSUFBSSxJQUFJLEdBQVcsQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxHQUFHLEtBQUssQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDO1FBRWxFLHVIQUF1SDtRQUN2SCxtSEFBbUg7UUFFbkgsT0FBTyxrQ0FBa0MsR0FBRyxVQUFVLEdBQUcsSUFBSSxHQUFHLEtBQUssQ0FBQyxPQUFPLENBQUMsQ0FBQyxPQUFPLENBQUMsR0FBRzt1REFDM0MsSUFBRyxLQUFHLEtBQUssQ0FBQyxLQUFPLENBQUEsR0FBRyxNQUFNLEdBQUcsSUFBSSxHQUFHLFFBQVEsQ0FBQztJQUNsRyxDQUFDO0lBRUQsd0NBQUksR0FBSixVQUFLLEtBQW9CO1FBRXJCLE9BQU8sbUNBQW1DLEdBQUcsS0FBSyxDQUFDLE9BQU8sQ0FBQyxDQUFDLE9BQU8sQ0FBQyxHQUFHLFVBQVUsQ0FBQztJQUN0RixDQUFDO0lBRUQsdUNBQUcsR0FBSCxVQUFJLEtBQW9CO1FBRXBCLE9BQU8sbUNBQW1DLEdBQUcsS0FBSyxDQUFDLE9BQU8sQ0FBQyxDQUFDLE9BQU8sQ0FBQyxHQUFHLFVBQVUsQ0FBQztJQUN0RixDQUFDOzs2Q0EzQlksTUFBTSxTQUFDLFNBQVM7O0lBRHBCLHlCQUF5QjtRQURyQyxVQUFVLEVBQUU7UUFFSSxXQUFBLE1BQU0sQ0FBQyxTQUFTLENBQUMsQ0FBQTs7T0FEckIseUJBQXlCLENBOEJyQztJQUFELGdDQUFDO0NBQUEsQUE5QkQsQ0FBK0MsMkJBQTJCLEdBOEJ6RTtTQTlCWSx5QkFBeUI7QUFpQ3RDO0lBQXlDLHVDQUFxQjtJQUE5RDs7SUF1QkEsQ0FBQztJQXRCVSxtREFBcUIsR0FBNUIsVUFBNkIsRUFBcUM7WUFBbkMsY0FBSSxFQUFFLGtCQUFNO1FBQ3ZDLE9BQU8sSUFBSSxJQUFJLENBQUMsY0FBYyxDQUFDLE1BQU0sRUFBRSxFQUFFLE9BQU8sRUFBRSxPQUFPLEVBQUUsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsQ0FBQztJQUM5RSxDQUFDO0lBRU0sNENBQWMsR0FBckIsVUFBc0IsRUFBcUM7WUFBbkMsY0FBSSxFQUFFLGtCQUFNO1FBQ2hDLE9BQU8sSUFBSSxJQUFJLENBQUMsY0FBYyxDQUFDLE1BQU0sRUFBRTtZQUNuQyxJQUFJLEVBQUUsU0FBUztZQUNmLEtBQUssRUFBRSxNQUFNO1NBQ2hCLENBQUMsQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLENBQUM7SUFDcEIsQ0FBQztJQUVNLGtEQUFvQixHQUEzQixVQUE0QixFQUFxQztZQUFuQyxjQUFJLEVBQUUsa0JBQU07UUFDdEMsT0FBTyxJQUFJLElBQUksQ0FBQyxjQUFjLENBQUMsTUFBTSxFQUFFLEVBQUUsT0FBTyxFQUFFLE9BQU8sRUFBRSxDQUFDLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxDQUFDO0lBQzlFLENBQUM7SUFFTSx5Q0FBVyxHQUFsQixVQUFtQixFQUFxQztZQUFuQyxjQUFJLEVBQUUsa0JBQU07UUFDN0IsT0FBTyxJQUFJLElBQUksQ0FBQyxjQUFjLENBQUMsTUFBTSxFQUFFO1lBQ25DLElBQUksRUFBRSxTQUFTO1lBQ2YsTUFBTSxFQUFFLFNBQVM7U0FDcEIsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsQ0FBQztJQUNwQixDQUFDO0lBckJRLG1CQUFtQjtRQUQvQixVQUFVLEVBQUU7T0FDQSxtQkFBbUIsQ0F1Qi9CO0lBQUQsMEJBQUM7Q0FBQSxBQXZCRCxDQUF5QyxxQkFBcUIsR0F1QjdEO1NBdkJZLG1CQUFtQjtBQTBCaEM7SUFBQTtRQUVZLGtCQUFhLEdBQWtCLENBQUMsS0FBSyxFQUFFLE1BQU0sRUFBRSxRQUFRLEVBQUUsT0FBTyxDQUFDLENBQUM7UUFFbEUsZUFBVSxHQUFrQixDQUFDLFFBQVEsRUFBRSxNQUFNLEVBQUUsS0FBSyxFQUFFLE9BQU8sQ0FBQyxDQUFDO1FBRS9ELG1CQUFjLEdBQWtCLENBQUMsTUFBTSxFQUFFLE1BQU0sRUFBRSxPQUFPLENBQUMsQ0FBQztJQThNdEUsQ0FBQztJQTNNRywyREFBa0MsR0FBbEMsVUFBbUMsS0FBZ0IsRUFBRSxTQUFpQjtRQUVsRSxJQUFJLFNBQVMsR0FBZ0IsS0FBSyxDQUFDLEtBQUssQ0FBQztRQUV6QyxJQUFLLElBQUksQ0FBQyxzQkFBc0IsQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLEVBQUc7WUFFNUMsSUFBSyxPQUFPLFNBQVMsS0FBSyxRQUFRLEVBQUc7Z0JBQ2pDLFNBQVMsR0FBRyxJQUFJLENBQUMsWUFBWSxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsUUFBUSxFQUFFLENBQUMsSUFBSSxFQUFFLEdBQUcsV0FBVyxDQUFDLENBQUM7YUFDOUU7WUFFRCxnSEFBZ0g7WUFDaEgsSUFBSyxPQUFPLFNBQVMsS0FBSyxXQUFXLElBQUksU0FBUyxLQUFLLFNBQVMsSUFBSSxTQUFTLEtBQUssSUFBSSxFQUFHO2dCQUVyRixJQUFJLE9BQU8sU0FBTSxDQUFDO2dCQUNsQixJQUFLLEtBQUssQ0FBQyxHQUFHLEVBQUc7b0JBQ2IsSUFBSyxJQUFJLENBQUMsc0JBQXNCLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxFQUFHO3dCQUMxQyxPQUFPLEdBQUcsSUFBSSxDQUFDLFlBQVksQ0FBQyxLQUFLLENBQUMsR0FBRyxHQUFHLFdBQVcsQ0FBQyxDQUFDO3FCQUN4RDt5QkFBTTt3QkFDSCxPQUFPLENBQUMsSUFBSSxDQUFDLHFGQUFxRixFQUFFLEtBQUssQ0FBQyxDQUFDO3dCQUMzRyxPQUFPLEtBQUssQ0FBQztxQkFDaEI7aUJBQ0o7cUJBQU07b0JBQ0gsT0FBTyxHQUFHLElBQUksQ0FBQyxZQUFZLENBQUMsS0FBSyxDQUFDLEtBQUssR0FBRyxXQUFXLENBQUMsQ0FBQztpQkFDMUQ7Z0JBRUQsMEhBQTBIO2dCQUMxSCxJQUFJLEtBQUssR0FBVyxJQUFJLENBQUMsY0FBYyxDQUFDLEtBQUssRUFBRSxTQUFTLENBQUMsQ0FBQztnQkFDMUQsSUFBSSxDQUFDLGtCQUFrQixDQUFDLEtBQUssQ0FBQyxDQUFDO2dCQUUvQixLQUFLLENBQUMsS0FBSyxHQUFHLEtBQUssQ0FBQyxJQUFJLENBQUM7Z0JBQ3pCLEtBQUssQ0FBQyxLQUFLLEdBQUcsU0FBUyxDQUFDO2dCQUN4QixLQUFLLENBQUMsR0FBRyxHQUFHLE9BQU8sQ0FBQztnQkFDcEIsS0FBSyxDQUFDLEtBQUssR0FBRyxLQUFLLENBQUM7Z0JBQ3BCLEtBQUssQ0FBQyxTQUFTLEdBQUcsRUFBRSxXQUFXLEVBQUUsS0FBSyxFQUFFLFFBQVEsRUFBRSxLQUFLLEVBQUMsQ0FBQztnQkFDekQsS0FBSyxDQUFDLFNBQVMsR0FBRyxLQUFLLENBQUM7Z0JBQ3hCLEtBQUssQ0FBQyxJQUFJLEdBQUc7b0JBQ1Qsb0JBQW9CLEVBQUUsS0FBSztpQkFDOUIsQ0FBQztnQkFFRixJQUFLLEtBQUssQ0FBQyxLQUFLLENBQUMsUUFBUSxLQUFLLFNBQVMsSUFBSSxDQUFDLElBQUksQ0FBQyxhQUFhLENBQUMsUUFBUSxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsUUFBUSxDQUFDLEVBQUc7b0JBQzVGLE9BQU8sQ0FBQyxJQUFJLENBQUMsdUNBQXVDLEdBQUcsS0FBSyxDQUFDLEtBQUssQ0FBQyxRQUFRLEdBQUcsMkdBQTJHLEVBQUUsS0FBSyxDQUFDLENBQUM7b0JBQ2xNLEtBQUssQ0FBQyxLQUFLLENBQUMsUUFBUSxHQUFHLFFBQVEsQ0FBQztpQkFDbkM7YUFFSjtpQkFBTTtnQkFDSCxPQUFPLENBQUMsSUFBSSxDQUFDLG9HQUFvRyxFQUFFLEtBQUssQ0FBQyxDQUFDO2FBQzdIO1lBRUQsT0FBTyxJQUFJLENBQUM7U0FDZjthQUFNO1lBQ0gsT0FBTyxDQUFDLElBQUksQ0FBQyxxRkFBcUYsRUFBRSxLQUFLLENBQUMsQ0FBQztZQUMzRyxPQUFPLEtBQUssQ0FBQztTQUNoQjtJQUNMLENBQUM7SUFFTywrQ0FBc0IsR0FBOUIsVUFBK0IsV0FBd0I7UUFDbkQsV0FBVyxHQUFHLFdBQVcsQ0FBQyxRQUFRLEVBQUUsQ0FBQyxJQUFJLEVBQUUsQ0FBQztRQUM1QyxJQUFLLFdBQVcsQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxDQUFDLEVBQUc7WUFDbkMsSUFBSSxPQUFPLEdBQWtCLFdBQVcsQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLENBQUM7WUFDcEQsSUFBSyxPQUFPLENBQUMsTUFBTSxLQUFLLENBQUMsSUFBSSxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxLQUFLLENBQUMsSUFBSSxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxLQUFLLENBQUMsSUFBSSxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxLQUFLLENBQUMsRUFBRztnQkFDekcsT0FBTyxJQUFJLENBQUM7YUFDZjtTQUNKO1FBQ0QsT0FBTyxLQUFLLENBQUM7SUFDakIsQ0FBQztJQUVELDJDQUFrQixHQUFsQixVQUFtQixLQUFnQjtRQUUvQixPQUFPO1lBQ0gsRUFBRSxFQUFFLEtBQUssQ0FBQyxFQUFFO1lBQ1osSUFBSSxFQUFFLEtBQUssQ0FBQyxLQUFLO1lBQ2pCLElBQUksRUFBRSxLQUFLLENBQUMsSUFBSTtZQUNoQixLQUFLLEVBQUUsRUFBRSxLQUFLLEVBQUUsS0FBSyxDQUFDLEtBQUssQ0FBQyxLQUFLLEVBQUUsUUFBUSxFQUFFLEtBQUssQ0FBQyxLQUFLLENBQUMsUUFBUSxFQUFFLEtBQUssRUFBRSxLQUFLLENBQUMsS0FBSyxDQUFDLEtBQUssRUFBRSxTQUFTLEVBQUUsS0FBSyxDQUFDLEtBQUssQ0FBQyxTQUFTLEVBQUU7WUFDL0gsS0FBSyxFQUFFLE1BQU0sQ0FBQyxJQUFJLElBQUksQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLEVBQUUsWUFBWSxDQUFDO1lBQ2xELEdBQUcsRUFBRSxNQUFNLENBQUMsSUFBSSxJQUFJLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxFQUFFLFlBQVksQ0FBQztTQUNqRCxDQUFDO0lBQ04sQ0FBQztJQUVELHFDQUFZLEdBQVosVUFBYSxVQUF1QjtRQUNoQyxJQUFLLE9BQU8sVUFBVSxLQUFLLFFBQVEsRUFBRztZQUNsQyxJQUFJLE9BQU8sR0FBa0IsVUFBVSxDQUFDLFFBQVEsRUFBRSxDQUFDLEtBQUssQ0FBQyxRQUFRLENBQUMsQ0FBQztZQUNuRSxJQUFJLEtBQUssR0FBVyxRQUFRLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDO1lBQzdDLE9BQU8sSUFBSSxJQUFJLENBQUMsUUFBUSxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLEtBQUssRUFBRSxRQUFRLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsUUFBUSxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLFFBQVEsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxRQUFRLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztTQUN4STtRQUNELE9BQU8sVUFBVSxDQUFDO0lBQ3RCLENBQUM7SUFFRCxpREFBd0IsR0FBeEIsVUFBeUIsT0FBYSxFQUFFLE1BQXdCO1FBQzVELElBQUksV0FBVyxHQUFZLEtBQUssQ0FBQztRQUNqQyxLQUFNLElBQUksQ0FBQyxHQUFXLENBQUMsRUFBRSxDQUFDLEdBQUcsTUFBTSxDQUFDLE1BQU0sRUFBRSxDQUFDLEVBQUUsRUFBRztZQUM5QyxJQUFJLE9BQUssR0FBYyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUM7WUFDakMsSUFBSyxDQUFDLHdCQUF3QixDQUFDLE9BQU8sRUFBRSxJQUFJLElBQUksQ0FBQyxPQUFLLENBQUMsS0FBSyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsSUFBSSxDQUFDLHdCQUF3QixDQUFDLE9BQU8sRUFBRSxJQUFJLElBQUksQ0FBQyxPQUFLLENBQUMsR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsRUFBRztnQkFDcEksSUFBSyxPQUFLLENBQUMsS0FBSyxDQUFDLFNBQVMsS0FBSyxNQUFNLEVBQUc7b0JBQ3BDLFdBQVcsR0FBRyxJQUFJLENBQUM7aUJBQ3RCO3FCQUFNO29CQUNILE9BQU8sS0FBSyxDQUFDO2lCQUNoQjthQUNKO1NBQ0o7UUFDRCxPQUFPLFdBQVcsQ0FBQztJQUN2QixDQUFDO0lBR0Qsb0NBQVcsR0FBWCxVQUFZLFlBQW9CLEVBQUUsTUFBYyxFQUFFLFFBQWM7UUFFNUQsSUFBSSxPQUFPLEdBQWlCLEtBQUssQ0FBQztRQUNsQyxJQUFLLFlBQVksS0FBSyxPQUFPLEVBQUc7WUFDNUIsT0FBTyxHQUFHLElBQUksSUFBSSxFQUFFLENBQUM7U0FDeEI7YUFBTTtZQUNILE9BQU8sR0FBRyxJQUFJLENBQUMsWUFBWSxDQUFDLFFBQVEsQ0FBQyxDQUFDO1lBQ3RDLElBQUssWUFBWSxLQUFLLE1BQU0sRUFBRztnQkFDM0IsSUFBSSxNQUFNLEtBQUssTUFBTSxFQUFFO29CQUNuQixPQUFPLEdBQUcsUUFBUSxDQUFDLE9BQU8sRUFBRSxDQUFDLENBQUMsQ0FBQztpQkFDbEM7cUJBQU0sSUFBSyxNQUFNLEtBQUssVUFBVSxFQUFHO29CQUNoQyxPQUFPLEdBQUcsUUFBUSxDQUFDLE9BQU8sRUFBRSxDQUFDLENBQUMsQ0FBQztpQkFDbEM7YUFDSjtpQkFBTSxJQUFLLFlBQVksS0FBSyxPQUFPLEVBQUc7Z0JBQ25DLElBQUssTUFBTSxLQUFLLE1BQU0sRUFBRztvQkFDckIsT0FBTyxHQUFHLFNBQVMsQ0FBQyxPQUFPLEVBQUUsQ0FBQyxDQUFDLENBQUM7aUJBQ25DO3FCQUFNLElBQUssTUFBTSxLQUFLLFVBQVUsRUFBRztvQkFDaEMsT0FBTyxHQUFHLFNBQVMsQ0FBQyxPQUFPLEVBQUUsQ0FBQyxDQUFDLENBQUM7aUJBQ25DO2FBQ0o7aUJBQU0sSUFBSyxZQUFZLEtBQUssTUFBTSxFQUFHO2dCQUNsQyxJQUFLLE1BQU0sS0FBSyxNQUFNLEVBQUc7b0JBQ3JCLE9BQU8sR0FBRyxRQUFRLENBQUMsT0FBTyxFQUFFLENBQUMsQ0FBQyxDQUFDO2lCQUNsQztxQkFBTSxJQUFLLE1BQU0sS0FBSyxVQUFVLEVBQUc7b0JBQ2hDLE9BQU8sR0FBRyxRQUFRLENBQUMsT0FBTyxFQUFFLENBQUMsQ0FBQyxDQUFDO2lCQUNsQzthQUNKO2lCQUFNLElBQUssWUFBWSxLQUFLLEtBQUssRUFBRztnQkFDakMsSUFBSyxNQUFNLEtBQUssTUFBTSxFQUFHO29CQUNyQixPQUFPLEdBQUcsT0FBTyxDQUFDLE9BQU8sRUFBRSxDQUFDLENBQUMsQ0FBQztpQkFDakM7cUJBQU0sSUFBSyxNQUFNLEtBQUssVUFBVSxFQUFHO29CQUNoQyxPQUFPLEdBQUcsT0FBTyxDQUFDLE9BQU8sRUFBRSxDQUFDLENBQUMsQ0FBQztpQkFDakM7YUFDSjtpQkFBTTtnQkFDSCxJQUFJLE1BQU0sR0FBUyxJQUFJLENBQUMsWUFBWSxDQUFDLFlBQVksR0FBRyxXQUFXLENBQUMsQ0FBQztnQkFDakUsSUFBSyxLQUFLLENBQUUsTUFBTSxDQUFDLE9BQU8sRUFBRSxDQUFFLEtBQUssS0FBSyxFQUFHO29CQUN2QyxPQUFPLEdBQUcsTUFBTSxDQUFDLENBQUMsYUFBYTtpQkFDbEM7YUFDSjtTQUNKO1FBQ0QsT0FBTyxPQUFPLENBQUM7SUFDbkIsQ0FBQztJQUVELDhDQUFxQixHQUFyQixVQUFzQixZQUFvQjtRQUN0QyxJQUFJLE1BQU0sR0FBVyxZQUFZLEdBQUcsQ0FBQyxDQUFDO1FBQ3RDLElBQUssTUFBTSxHQUFHLElBQUksRUFBRztZQUNqQixPQUFPLEdBQUcsR0FBRyxNQUFNLENBQUMsUUFBUSxFQUFFLENBQUM7U0FDbEM7UUFDRCxPQUFPLE1BQU0sQ0FBQztJQUNsQixDQUFDO0lBRUQsK0NBQXNCLEdBQXRCO1FBRUksSUFBSSxNQUFNLEdBQW9CLFFBQVEsQ0FBQyxhQUFhLENBQUMsTUFBTSxDQUFDLENBQUM7UUFDN0QsTUFBTSxDQUFDLFlBQVksQ0FBQyxPQUFPLEVBQUUsMEJBQTBCLENBQUMsQ0FBQztRQUN6RCxJQUFJLE1BQU0sR0FBZ0IsUUFBUSxDQUFDLGFBQWEsQ0FBQyxHQUFHLENBQUMsQ0FBQztRQUN0RCxNQUFNLENBQUMsWUFBWSxDQUFDLE9BQU8sRUFBRSxhQUFhLENBQUMsQ0FBQztRQUM1QyxNQUFNLENBQUMsV0FBVyxDQUFDLE1BQU0sQ0FBQyxDQUFDO1FBRTNCLE9BQU8sTUFBTSxDQUFDO0lBQ2xCLENBQUM7SUFFRCx3Q0FBZSxHQUFmLFVBQWdCLGtCQUFrQyxFQUFFLGNBQXVCO1FBRXZFLElBQUksV0FBVyxHQUFZLElBQUksQ0FBQztRQUVoQyxJQUFLLGNBQWMsS0FBSyxJQUFJLEVBQUc7WUFDM0IsY0FBYyxHQUFHLGtCQUFrQixDQUFDLENBQUMsQ0FBQyxDQUFDO1lBQ3ZDLFdBQVcsR0FBRyxLQUFLLENBQUM7U0FDdkI7YUFBTTtZQUNILEtBQU0sSUFBSSxDQUFDLEdBQVcsQ0FBQyxFQUFFLENBQUMsR0FBRyxrQkFBa0IsQ0FBQyxNQUFNLEVBQUUsQ0FBQyxFQUFFLEVBQUc7Z0JBQzFELElBQUksWUFBWSxHQUFZLGtCQUFrQixDQUFDLENBQUMsQ0FBQyxDQUFDO2dCQUNsRCxJQUFLLFlBQVksS0FBSyxjQUFjLEVBQUc7b0JBQ25DLGNBQWMsR0FBRyxZQUFZLENBQUM7b0JBQzlCLFdBQVcsR0FBRyxLQUFLLENBQUM7b0JBQ3BCLE1BQU07aUJBQ1Q7YUFDSjtTQUNKO1FBQ0QsT0FBTyxFQUFDLE9BQU8sRUFBRSxjQUFjLEVBQUUsV0FBVyxFQUFFLFdBQVcsRUFBQyxDQUFDO0lBQy9ELENBQUM7SUFFTyx1Q0FBYyxHQUF0QixVQUF1QixLQUFnQixFQUFFLFNBQWlCO1FBRXRELElBQUksS0FBSyxHQUFXLEVBQUMsT0FBTyxFQUFFLFNBQVMsRUFBRSxTQUFTLEVBQUUsU0FBUyxFQUFDLENBQUM7UUFFL0QsSUFBSyxLQUFLLENBQUMsS0FBSyxDQUFDLEtBQUssS0FBSyxTQUFTLElBQUksQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLFFBQVEsQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxFQUFHO1lBQ25GLE9BQU8sQ0FBQyxJQUFJLENBQUMsdUNBQXVDLEdBQUcsS0FBSyxDQUFDLEtBQUssQ0FBQyxLQUFLLEdBQUcsb0hBQW9ILEVBQUUsS0FBSyxDQUFDLENBQUM7U0FDM007YUFBTSxJQUFLLEtBQUssQ0FBQyxLQUFLLENBQUMsS0FBSyxLQUFLLFNBQVMsRUFBRztZQUMxQyxLQUFLLEdBQUcsRUFBQyxPQUFPLEVBQUUsU0FBUyxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLENBQUMsT0FBTyxFQUFFLFNBQVMsRUFBRyxTQUFTLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsQ0FBQyxTQUFTLEVBQUMsQ0FBQztTQUMvRztRQUNELE9BQU8sS0FBSyxDQUFDO0lBQ2pCLENBQUM7SUFFTywyQ0FBa0IsR0FBMUIsVUFBMkIsS0FBZ0I7UUFFdkMsSUFBSyxLQUFLLENBQUMsS0FBSyxDQUFDLFNBQVMsS0FBSyxTQUFTLElBQUksQ0FBQyxJQUFJLENBQUMsY0FBYyxDQUFDLFFBQVEsQ0FBRSxLQUFLLENBQUMsS0FBSyxDQUFDLFNBQVMsQ0FBQyxFQUFHO1lBQ2hHLE9BQU8sQ0FBQyxJQUFJLENBQUMsMkNBQTJDLEdBQUcsS0FBSyxDQUFDLEtBQUssQ0FBQyxTQUFTLEdBQUcsaUdBQWlHLEVBQUUsS0FBSyxDQUFDLENBQUM7U0FDaE07YUFBTSxJQUFLLEtBQUssQ0FBQyxLQUFLLENBQUMsU0FBUyxLQUFLLFNBQVMsSUFBSSxLQUFLLENBQUMsS0FBSyxDQUFDLFNBQVMsS0FBSyxPQUFPLEVBQUc7WUFDbkYsS0FBSyxDQUFDLEtBQUssQ0FBQyxTQUFTLEdBQUcsTUFBTSxDQUFDLENBQUMsZ0NBQWdDO1NBQ25FO0lBQ0wsQ0FBQztJQW5OUSxjQUFjO1FBRDFCLFVBQVUsRUFBRTtPQUNBLGNBQWMsQ0FvTjFCO0lBQUQscUJBQUM7Q0FBQSxBQXBORCxJQW9OQztTQXBOWSxjQUFjIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgTE9DQUxFX0lELCBJbmplY3QsIEluamVjdGFibGUgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcclxuaW1wb3J0IHsgQ2FsZW5kYXJFdmVudFRpdGxlRm9ybWF0dGVyLCBDYWxlbmRhckV2ZW50LCBDYWxlbmRhckRhdGVGb3JtYXR0ZXIsIERhdGVGb3JtYXR0ZXJQYXJhbXMgfSBmcm9tICdhbmd1bGFyLWNhbGVuZGFyJztcclxuaW1wb3J0IHsgSUNhbGVuZGFyLCBJQ2FsZW5kYXJPcGVuRHJhd2VyIH0gZnJvbSAnLi4va2QtYW5ndWxhci1jYWxlbmRhci1pbnRlcmZhY2UnO1xyXG5pbXBvcnQge1xyXG4gICAgZm9ybWF0LFxyXG4gICAgYWRkWWVhcnMsXHJcbiAgICBhZGRNb250aHMsXHJcbiAgICBhZGRXZWVrcyxcclxuICAgIGFkZERheXMsXHJcbiAgICBzdWJZZWFycyxcclxuICAgIHN1Yk1vbnRocyxcclxuICAgIHN1YldlZWtzLFxyXG4gICAgc3ViRGF5cyxcclxuICAgIGRpZmZlcmVuY2VJbkNhbGVuZGFyRGF5c1xyXG59IGZyb20gJ2RhdGUtZm5zJztcclxuXHJcbkBJbmplY3RhYmxlKClcclxuZXhwb3J0IGNsYXNzIEN1c3RvbUV2ZW50VGl0bGVGb3JtYXR0ZXIgZXh0ZW5kcyBDYWxlbmRhckV2ZW50VGl0bGVGb3JtYXR0ZXIge1xyXG4gICAgY29uc3RydWN0b3IoQEluamVjdChMT0NBTEVfSUQpIGxvY2FsZTogc3RyaW5nKSB7XHJcbiAgICAgICAgc3VwZXIoKTtcclxuICAgIH1cclxuXHJcbiAgICBtb250aChldmVudDogQ2FsZW5kYXJFdmVudCk6IHN0cmluZyB7XHJcblxyXG4gICAgICAgIGxldCBiYWRnZUNvbG9yOiBzdHJpbmcgPSBldmVudFsnYmFkZ2UnXVsnY29sb3InXTtcclxuXHJcbiAgICAgICAgbGV0IGNvbG9yQ2xhc3M6IHN0cmluZyA9IChiYWRnZUNvbG9yID09PSAnZ3JlZW4nKSA/ICdidG4tc3VjY2VzcycgOiAoYmFkZ2VDb2xvciA9PT0gJ3JlZCcpID8gJ2J0bi1lcnJvcicgOiAoYmFkZ2VDb2xvciA9PT0gJ3llbGxvdycpID8gJ2J0bi13YXJuaW5nJyA6ICdidG4taW5mbyc7XHJcblxyXG4gICAgICAgIGxldCBub3RlOiBzdHJpbmcgPSAoZXZlbnRbJ25vdGUnXSkgPyAnPGJyLz4nICsgZXZlbnRbJ25vdGUnXSA6ICcnO1xyXG5cclxuICAgICAgICAvLyBsZXQgZXZlbnREYXRlID0gJygnK25ldyBJbnRsLkRhdGVUaW1lRm9ybWF0KHRoaXMubG9jYWxlLCB7bW9udGg6ICdzaG9ydCcsIGRheTogJzItZGlnaXQnfSkuZm9ybWF0KGV2ZW50LnN0YXJ0KSsnKSAnO1xyXG4gICAgICAgIC8vIGxldCBldmVudERhdGUgPSAnKCcrbmV3IEludGwuRGF0ZVRpbWVGb3JtYXQoJ2VuLUdCJywge2RheTogJzItZGlnaXQnLCBtb250aDogJ3Nob3J0J30pLmZvcm1hdChldmVudC5zdGFydCkrJykgJztcclxuXHJcbiAgICAgICAgcmV0dXJuICc8c21hbGwgY2xhc3M9XCJrZHgtY2FsLWRheS1ldmVudCAnICsgY29sb3JDbGFzcyArICdcIj4nICsgZXZlbnRbJ2JhZGdlJ11bJ2xhYmVsJ10gKyAnPC9zbWFsbD5cXFxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cImtkeC1jYWwtZXZlbnQtZGV0YWlsc1wiPjxiPicgKyBgJHtldmVudC50aXRsZX1gICsgJzwvYj4nICsgbm90ZSArICc8L2Rpdj4nO1xyXG4gICAgfVxyXG5cclxuICAgIHdlZWsoZXZlbnQ6IENhbGVuZGFyRXZlbnQpOiBzdHJpbmcge1xyXG5cclxuICAgICAgICByZXR1cm4gJzxzbWFsbCBjbGFzcz1cImtkeC1jYWwtZGF5LWV2ZW50XCI+JyArIGV2ZW50WydiYWRnZSddWydsYWJlbCddICsgJzwvc21hbGw+JztcclxuICAgIH1cclxuXHJcbiAgICBkYXkoZXZlbnQ6IENhbGVuZGFyRXZlbnQpOiBzdHJpbmcge1xyXG5cclxuICAgICAgICByZXR1cm4gJzxzbWFsbCBjbGFzcz1cImtkeC1jYWwtZGF5LWV2ZW50XCI+JyArIGV2ZW50WydiYWRnZSddWydsYWJlbCddICsgJzwvc21hbGw+JztcclxuICAgIH1cclxuXHJcbn1cclxuXHJcbkBJbmplY3RhYmxlKClcclxuZXhwb3J0IGNsYXNzIEN1c3RvbURhdGVGb3JtYXR0ZXIgZXh0ZW5kcyBDYWxlbmRhckRhdGVGb3JtYXR0ZXIge1xyXG4gICAgcHVibGljIG1vbnRoVmlld0NvbHVtbkhlYWRlcih7IGRhdGUsIGxvY2FsZSB9OiBEYXRlRm9ybWF0dGVyUGFyYW1zKTogc3RyaW5nIHtcclxuICAgICAgICByZXR1cm4gbmV3IEludGwuRGF0ZVRpbWVGb3JtYXQobG9jYWxlLCB7IHdlZWtkYXk6ICdzaG9ydCcgfSkuZm9ybWF0KGRhdGUpO1xyXG4gICAgfVxyXG5cclxuICAgIHB1YmxpYyBtb250aFZpZXdUaXRsZSh7IGRhdGUsIGxvY2FsZSB9OiBEYXRlRm9ybWF0dGVyUGFyYW1zKTogc3RyaW5nIHtcclxuICAgICAgICByZXR1cm4gbmV3IEludGwuRGF0ZVRpbWVGb3JtYXQobG9jYWxlLCB7XHJcbiAgICAgICAgICAgIHllYXI6ICdudW1lcmljJyxcclxuICAgICAgICAgICAgbW9udGg6ICdsb25nJ1xyXG4gICAgICAgIH0pLmZvcm1hdChkYXRlKTtcclxuICAgIH1cclxuXHJcbiAgICBwdWJsaWMgd2Vla1ZpZXdDb2x1bW5IZWFkZXIoeyBkYXRlLCBsb2NhbGUgfTogRGF0ZUZvcm1hdHRlclBhcmFtcyk6IHN0cmluZyB7XHJcbiAgICAgICAgcmV0dXJuIG5ldyBJbnRsLkRhdGVUaW1lRm9ybWF0KGxvY2FsZSwgeyB3ZWVrZGF5OiAnc2hvcnQnIH0pLmZvcm1hdChkYXRlKTtcclxuICAgIH1cclxuXHJcbiAgICBwdWJsaWMgZGF5Vmlld0hvdXIoeyBkYXRlLCBsb2NhbGUgfTogRGF0ZUZvcm1hdHRlclBhcmFtcyk6IHN0cmluZyB7XHJcbiAgICAgICAgcmV0dXJuIG5ldyBJbnRsLkRhdGVUaW1lRm9ybWF0KGxvY2FsZSwge1xyXG4gICAgICAgICAgICBob3VyOiAnbnVtZXJpYycsXHJcbiAgICAgICAgICAgIG1pbnV0ZTogJ251bWVyaWMnXHJcbiAgICAgICAgfSkuZm9ybWF0KGRhdGUpO1xyXG4gICAgfVxyXG5cclxufVxyXG5cclxuQEluamVjdGFibGUoKVxyXG5leHBvcnQgY2xhc3MgQ2FsZW5kYXJIZWxwZXIge1xyXG5cclxuICAgIHByaXZhdGUgX3Bvc2l0aW9uTGlzdDogQXJyYXk8c3RyaW5nPiA9IFsndG9wJywgJ2xlZnQnLCAnYm90dG9tJywgJ3JpZ2h0J107XHJcblxyXG4gICAgcHJpdmF0ZSBfY29sb3JMaXN0OiBBcnJheTxzdHJpbmc+ID0gWyd5ZWxsb3cnLCAnYmx1ZScsICdyZWQnLCAnZ3JlZW4nXTtcclxuXHJcbiAgICBwcml2YXRlIF9oaWdobGlnaHRMaXN0OiBBcnJheTxzdHJpbmc+ID0gWydncmV5JywgJ2dyYXknLCAnd2hpdGUnXTtcclxuXHJcblxyXG4gICAgYWRkTWlzc2luZ1JlcXVpcmVkUHJvcGVydHlGb3JFdmVudChldmVudDogSUNhbGVuZGFyLCBjb2xvclRyYXk6IG9iamVjdCk6IGJvb2xlYW4ge1xyXG5cclxuICAgICAgICBsZXQgc3RhcnREYXRlOiBEYXRlfHN0cmluZyA9IGV2ZW50LnN0YXJ0O1xyXG5cclxuICAgICAgICBpZiAoIHRoaXMuX2NoZWNrU3RyaW5nRGF0ZUZvcm1hdChldmVudC5zdGFydCkgKSB7XHJcblxyXG4gICAgICAgICAgICBpZiAoIHR5cGVvZiBzdGFydERhdGUgPT09ICdzdHJpbmcnICkge1xyXG4gICAgICAgICAgICAgICAgc3RhcnREYXRlID0gdGhpcy5zdHJpbmdUb0RhdGUoZXZlbnQuc3RhcnQudG9TdHJpbmcoKS50cmltKCkgKyAnIDAwOjAwOjAxJyk7XHJcbiAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgIC8vIGlzIHRoZSBldmVudCBzdGFydCBkYXRlIHZhbGlkPyBpZiBzdGFydCBkYXRlIGlzIGludmFsaWQsIGV2ZW50IGlzIGludmFsaWQgYW5kIHdpbGwgbm90IGJlIGFkZGVkIGludG8gY2FsZW5kYXJcclxuICAgICAgICAgICAgaWYgKCB0eXBlb2Ygc3RhcnREYXRlICE9PSAndW5kZWZpbmVkJyAmJiBzdGFydERhdGUgIT09IHVuZGVmaW5lZCAmJiBzdGFydERhdGUgIT09IG51bGwgKSB7XHJcblxyXG4gICAgICAgICAgICAgICAgbGV0IGVuZERhdGU6IERhdGU7XHJcbiAgICAgICAgICAgICAgICBpZiAoIGV2ZW50LmVuZCApIHtcclxuICAgICAgICAgICAgICAgICAgICBpZiAoIHRoaXMuX2NoZWNrU3RyaW5nRGF0ZUZvcm1hdChldmVudC5lbmQpICkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBlbmREYXRlID0gdGhpcy5zdHJpbmdUb0RhdGUoZXZlbnQuZW5kICsgJyAyMzo1OTo1OScpO1xyXG4gICAgICAgICAgICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbnNvbGUud2FybignS2QtQ2FsZW5kYXIgRVJST1I6IERhdGUgZm9ybWF0IGZvciBzdGFydC9lbmQgZGF0ZSBpcyB3cm9uZy4gRGF0ZSBmb3JtYXQ6IFlZWVktTU0tREQnLCBldmVudCk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiBmYWxzZTtcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgICAgIGVuZERhdGUgPSB0aGlzLnN0cmluZ1RvRGF0ZShldmVudC5zdGFydCArICcgMjM6NTk6NTknKTtcclxuICAgICAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgICAgICAvLyBlbmREYXRlID0gKGRpZmZlcmVuY2VJbkNhbGVuZGFyRGF5cyhzdGFydERhdGUsIGVuZERhdGUpIDw9IDApID8gZW5kRGF0ZSA6IHRoaXMuc3RyaW5nVG9EYXRlKGV2ZW50LnN0YXJ0ICsgJyAyMzo1OTo1OScpO1xyXG4gICAgICAgICAgICAgICAgbGV0IGNvbG9yOiBvYmplY3QgPSB0aGlzLl9zZXRCYWRnZUNvbG9yKGV2ZW50LCBjb2xvclRyYXkpO1xyXG4gICAgICAgICAgICAgICAgdGhpcy5fc2V0SGlnaGxpZ2h0Q29sb3IoZXZlbnQpO1xyXG5cclxuICAgICAgICAgICAgICAgIGV2ZW50LnRpdGxlID0gZXZlbnQubmFtZTtcclxuICAgICAgICAgICAgICAgIGV2ZW50LnN0YXJ0ID0gc3RhcnREYXRlO1xyXG4gICAgICAgICAgICAgICAgZXZlbnQuZW5kID0gZW5kRGF0ZTtcclxuICAgICAgICAgICAgICAgIGV2ZW50LmNvbG9yID0gY29sb3I7XHJcbiAgICAgICAgICAgICAgICBldmVudC5yZXNpemFibGUgPSB7IGJlZm9yZVN0YXJ0OiBmYWxzZSwgYWZ0ZXJFbmQ6IGZhbHNlfTtcclxuICAgICAgICAgICAgICAgIGV2ZW50LmRyYWdnYWJsZSA9IGZhbHNlO1xyXG4gICAgICAgICAgICAgICAgZXZlbnQubWV0YSA9IHtcclxuICAgICAgICAgICAgICAgICAgICBpbmNyZW1lbnRzQmFkZ2VUb3RhbDogZmFsc2VcclxuICAgICAgICAgICAgICAgIH07XHJcblxyXG4gICAgICAgICAgICAgICAgaWYgKCBldmVudC5iYWRnZS5wb3NpdGlvbiA9PT0gdW5kZWZpbmVkIHx8ICF0aGlzLl9wb3NpdGlvbkxpc3QuaW5jbHVkZXMoZXZlbnQuYmFkZ2UucG9zaXRpb24pICkge1xyXG4gICAgICAgICAgICAgICAgICAgIGNvbnNvbGUud2FybignS2QtQ2FsZW5kYXIgRVJST1I6IEJhZGdlIHBvc2l0aW9uIG9mICcgKyBldmVudC5iYWRnZS5wb3NpdGlvbiArICcgaXMgaW52YWxpZCBhbmQgaGFzIGJlZW4gYXV0b21hdGljYWxseSBzZXQgdG8gYm90dG9tLiBPbmx5IFwidG9wXCIsIFwiYm90dG9tXCIsIFwibGVmdFwiIGFuZCBcInJpZ2h0XCIgaXMgYWxsb3dlZCcsIGV2ZW50KTtcclxuICAgICAgICAgICAgICAgICAgICBldmVudC5iYWRnZS5wb3NpdGlvbiA9ICdib3R0b20nO1xyXG4gICAgICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgICAgIGNvbnNvbGUud2FybignS2QtQ2FsZW5kYXIgRVJST1I6IFVuYWJsZSB0byBkaXNwbGF5IGludmFsaWQgRXZlbnQuIEV2ZW50IHJlcXVpcmVzOiBpZCwgbmFtZSwgYmFkZ2Uge2xhYmVsfSwgc3RhcnQnLCBldmVudCk7XHJcbiAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgIHJldHVybiB0cnVlO1xyXG4gICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgIGNvbnNvbGUud2FybignS2QtQ2FsZW5kYXIgRVJST1I6IERhdGUgZm9ybWF0IGZvciBzdGFydC9lbmQgZGF0ZSBpcyB3cm9uZy4gRGF0ZSBmb3JtYXQ6IFlZWVktTU0tREQnLCBldmVudCk7XHJcbiAgICAgICAgICAgIHJldHVybiBmYWxzZTtcclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfY2hlY2tTdHJpbmdEYXRlRm9ybWF0KGRhdGVUb0NoZWNrOiBzdHJpbmd8RGF0ZSkge1xyXG4gICAgICAgIGRhdGVUb0NoZWNrID0gZGF0ZVRvQ2hlY2sudG9TdHJpbmcoKS50cmltKCk7XHJcbiAgICAgICAgaWYgKCBkYXRlVG9DaGVjay5pbmRleE9mKCctJykgIT09IC0xICkge1xyXG4gICAgICAgICAgICBsZXQgZGF0ZUFycjogQXJyYXk8c3RyaW5nPiA9IGRhdGVUb0NoZWNrLnNwbGl0KCctJyk7XHJcbiAgICAgICAgICAgIGlmICggZGF0ZUFyci5sZW5ndGggPT09IDMgJiYgZGF0ZUFyclswXS5sZW5ndGggPT09IDQgJiYgZGF0ZUFyclsxXS5sZW5ndGggPT09IDIgJiYgZGF0ZUFyclsyXS5sZW5ndGggPT09IDIgKSB7XHJcbiAgICAgICAgICAgICAgICByZXR1cm4gdHJ1ZTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgICAgICByZXR1cm4gZmFsc2U7XHJcbiAgICB9XHJcblxyXG4gICAgY2xlYW5FdmVudFByb3BlcnR5KGV2ZW50OiBJQ2FsZW5kYXIpOiBJQ2FsZW5kYXIge1xyXG5cclxuICAgICAgICByZXR1cm4ge1xyXG4gICAgICAgICAgICBpZDogZXZlbnQuaWQsXHJcbiAgICAgICAgICAgIG5hbWU6IGV2ZW50LnRpdGxlLFxyXG4gICAgICAgICAgICBub3RlOiBldmVudC5ub3RlLFxyXG4gICAgICAgICAgICBiYWRnZTogeyBsYWJlbDogZXZlbnQuYmFkZ2UubGFiZWwsIHBvc2l0aW9uOiBldmVudC5iYWRnZS5wb3NpdGlvbiwgY29sb3I6IGV2ZW50LmJhZGdlLmNvbG9yLCBoaWdobGlnaHQ6IGV2ZW50LmJhZGdlLmhpZ2hsaWdodCB9LFxyXG4gICAgICAgICAgICBzdGFydDogZm9ybWF0KG5ldyBEYXRlKGV2ZW50LnN0YXJ0KSwgJ1lZWVktTU0tREQnKSxcclxuICAgICAgICAgICAgZW5kOiBmb3JtYXQobmV3IERhdGUoZXZlbnQuZW5kKSwgJ1lZWVktTU0tREQnKSxcclxuICAgICAgICB9O1xyXG4gICAgfVxyXG5cclxuICAgIHN0cmluZ1RvRGF0ZShkYXRlc3RyaW5nOiBzdHJpbmd8RGF0ZSk6IERhdGUge1xyXG4gICAgICAgIGlmICggdHlwZW9mIGRhdGVzdHJpbmcgPT09ICdzdHJpbmcnICkge1xyXG4gICAgICAgICAgICBsZXQgZGF0ZUFycjogQXJyYXk8c3RyaW5nPiA9IGRhdGVzdHJpbmcudG9TdHJpbmcoKS5zcGxpdCgvW14wLTldLyk7XHJcbiAgICAgICAgICAgIGxldCBtb250aDogbnVtYmVyID0gcGFyc2VJbnQoZGF0ZUFyclsxXSkgLSAxO1xyXG4gICAgICAgICAgICByZXR1cm4gbmV3IERhdGUocGFyc2VJbnQoZGF0ZUFyclswXSksIG1vbnRoLCBwYXJzZUludChkYXRlQXJyWzJdKSwgcGFyc2VJbnQoZGF0ZUFyclszXSksIHBhcnNlSW50KGRhdGVBcnJbNF0pLCBwYXJzZUludChkYXRlQXJyWzVdKSk7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIHJldHVybiBkYXRlc3RyaW5nO1xyXG4gICAgfVxyXG5cclxuICAgIGdldFVuaXF1ZURhdGVUb0hpZ2hsaWdodChkYXlEYXRlOiBEYXRlLCBldmVudHM6IEFycmF5PElDYWxlbmRhcj4pOiBib29sZWFuIHtcclxuICAgICAgICBsZXQgdG9IaWdobGlnaHQ6IGJvb2xlYW4gPSBmYWxzZTtcclxuICAgICAgICBmb3IgKCBsZXQgaTogbnVtYmVyID0gMDsgaSA8IGV2ZW50cy5sZW5ndGg7IGkrKyApIHtcclxuICAgICAgICAgICAgbGV0IGV2ZW50OiBJQ2FsZW5kYXIgPSBldmVudHNbaV07XHJcbiAgICAgICAgICAgIGlmICggKGRpZmZlcmVuY2VJbkNhbGVuZGFyRGF5cyhkYXlEYXRlLCBuZXcgRGF0ZShldmVudC5zdGFydCkpID49IDApICYmIChkaWZmZXJlbmNlSW5DYWxlbmRhckRheXMoZGF5RGF0ZSwgbmV3IERhdGUoZXZlbnQuZW5kKSkgPD0gMCkgKSB7XHJcbiAgICAgICAgICAgICAgICBpZiAoIGV2ZW50LmJhZGdlLmhpZ2hsaWdodCA9PT0gJ2dyZXknICkge1xyXG4gICAgICAgICAgICAgICAgICAgIHRvSGlnaGxpZ2h0ID0gdHJ1ZTtcclxuICAgICAgICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIGZhbHNlO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgICAgIHJldHVybiB0b0hpZ2hsaWdodDtcclxuICAgIH1cclxuXHJcblxyXG4gICAgZ2V0Vmlld0RhdGUoY2FsZW5kYXJUeXBlOiBzdHJpbmcsIGFjdGlvbjogc3RyaW5nLCB2aWV3RGF0ZTogRGF0ZSk6IGJvb2xlYW58RGF0ZSB7XHJcblxyXG4gICAgICAgIGxldCBuZXdEYXRlOiBib29sZWFufERhdGUgPSBmYWxzZTtcclxuICAgICAgICBpZiAoIGNhbGVuZGFyVHlwZSA9PT0gJ3RvZGF5JyApIHtcclxuICAgICAgICAgICAgbmV3RGF0ZSA9IG5ldyBEYXRlKCk7XHJcbiAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgbmV3RGF0ZSA9IHRoaXMuc3RyaW5nVG9EYXRlKHZpZXdEYXRlKTtcclxuICAgICAgICAgICAgaWYgKCBjYWxlbmRhclR5cGUgPT09ICd5ZWFyJyApIHtcclxuICAgICAgICAgICAgICAgIGlmIChhY3Rpb24gPT09ICduZXh0Jykge1xyXG4gICAgICAgICAgICAgICAgICAgIG5ld0RhdGUgPSBhZGRZZWFycyhuZXdEYXRlLCAxKTtcclxuICAgICAgICAgICAgICAgIH0gZWxzZSBpZiAoIGFjdGlvbiA9PT0gJ3ByZXZpb3VzJyApIHtcclxuICAgICAgICAgICAgICAgICAgICBuZXdEYXRlID0gc3ViWWVhcnMobmV3RGF0ZSwgMSk7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH0gZWxzZSBpZiAoIGNhbGVuZGFyVHlwZSA9PT0gJ21vbnRoJyApIHtcclxuICAgICAgICAgICAgICAgIGlmICggYWN0aW9uID09PSAnbmV4dCcgKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgbmV3RGF0ZSA9IGFkZE1vbnRocyhuZXdEYXRlLCAxKTtcclxuICAgICAgICAgICAgICAgIH0gZWxzZSBpZiAoIGFjdGlvbiA9PT0gJ3ByZXZpb3VzJyApIHtcclxuICAgICAgICAgICAgICAgICAgICBuZXdEYXRlID0gc3ViTW9udGhzKG5ld0RhdGUsIDEpO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9IGVsc2UgaWYgKCBjYWxlbmRhclR5cGUgPT09ICd3ZWVrJyApIHtcclxuICAgICAgICAgICAgICAgIGlmICggYWN0aW9uID09PSAnbmV4dCcgKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgbmV3RGF0ZSA9IGFkZFdlZWtzKG5ld0RhdGUsIDEpO1xyXG4gICAgICAgICAgICAgICAgfSBlbHNlIGlmICggYWN0aW9uID09PSAncHJldmlvdXMnICkge1xyXG4gICAgICAgICAgICAgICAgICAgIG5ld0RhdGUgPSBzdWJXZWVrcyhuZXdEYXRlLCAxKTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfSBlbHNlIGlmICggY2FsZW5kYXJUeXBlID09PSAnZGF5JyApIHtcclxuICAgICAgICAgICAgICAgIGlmICggYWN0aW9uID09PSAnbmV4dCcgKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgbmV3RGF0ZSA9IGFkZERheXMobmV3RGF0ZSwgMSk7XHJcbiAgICAgICAgICAgICAgICB9IGVsc2UgaWYgKCBhY3Rpb24gPT09ICdwcmV2aW91cycgKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgbmV3RGF0ZSA9IHN1YkRheXMobmV3RGF0ZSwgMSk7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgICAgICBsZXQgaXNEYXRlOiBEYXRlID0gdGhpcy5zdHJpbmdUb0RhdGUoY2FsZW5kYXJUeXBlICsgJyAwMDowMDowMScpO1xyXG4gICAgICAgICAgICAgICAgaWYgKCBpc05hTiggaXNEYXRlLmdldFRpbWUoKSApID09PSBmYWxzZSApIHtcclxuICAgICAgICAgICAgICAgICAgICBuZXdEYXRlID0gaXNEYXRlOyAvLyB2YWxpZCBkYXRlXHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICAgICAgcmV0dXJuIG5ld0RhdGU7XHJcbiAgICB9XHJcblxyXG4gICAgZ2VuZXJhdGVWaWV3TW9yZVZhbHVlKGV2ZW50c0xlbmd0aDogbnVtYmVyKTogc3RyaW5nIHtcclxuICAgICAgICBsZXQgb3V0cHV0OiBudW1iZXIgPSBldmVudHNMZW5ndGggLSA0O1xyXG4gICAgICAgIGlmICggb3V0cHV0IDwgMTAwMCApIHtcclxuICAgICAgICAgICAgcmV0dXJuICcrJyArIG91dHB1dC50b1N0cmluZygpO1xyXG4gICAgICAgIH1cclxuICAgICAgICByZXR1cm4gJys5OTknO1xyXG4gICAgfVxyXG5cclxuICAgIGNyZWF0ZUNsb3NlSWNvbkVsZW1lbnQoKTogSFRNTFNwYW5FbGVtZW50IHtcclxuXHJcbiAgICAgICAgbGV0IHNwYW5FbDogSFRNTFNwYW5FbGVtZW50ID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnc3BhbicpO1xyXG4gICAgICAgIHNwYW5FbC5zZXRBdHRyaWJ1dGUoJ2NsYXNzJywgJ2tkeC1jYWwtY2xvc2Utb3Blbi1ldmVudCcpO1xyXG4gICAgICAgIGxldCBpY29uRWw6IEhUTUxFbGVtZW50ID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnaScpO1xyXG4gICAgICAgIGljb25FbC5zZXRBdHRyaWJ1dGUoJ2NsYXNzJywgJ2ZhIGtkLWNsb3NlJyk7XHJcbiAgICAgICAgc3BhbkVsLmFwcGVuZENoaWxkKGljb25FbCk7XHJcblxyXG4gICAgICAgIHJldHVybiBzcGFuRWw7XHJcbiAgICB9XHJcblxyXG4gICAgZ2V0T3BlbmVkRHJhd2VyKGV2ZW50T3BlbmVkRHJhd2VyczogQXJyYXk8RWxlbWVudD4sIF9jdXJyZW50RHJhd2VyOiBFbGVtZW50KTogSUNhbGVuZGFyT3BlbkRyYXdlciB7XHJcblxyXG4gICAgICAgIGxldCBpc0ljb25BZGRlZDogYm9vbGVhbiA9IHRydWU7XHJcblxyXG4gICAgICAgIGlmICggX2N1cnJlbnREcmF3ZXIgPT09IG51bGwgKSB7XHJcbiAgICAgICAgICAgIF9jdXJyZW50RHJhd2VyID0gZXZlbnRPcGVuZWREcmF3ZXJzWzBdO1xyXG4gICAgICAgICAgICBpc0ljb25BZGRlZCA9IGZhbHNlO1xyXG4gICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgIGZvciAoIGxldCBpOiBudW1iZXIgPSAwOyBpIDwgZXZlbnRPcGVuZWREcmF3ZXJzLmxlbmd0aDsgaSsrICkge1xyXG4gICAgICAgICAgICAgICAgbGV0IG9wZW5lZERyYXdlcjogRWxlbWVudCA9IGV2ZW50T3BlbmVkRHJhd2Vyc1tpXTtcclxuICAgICAgICAgICAgICAgIGlmICggb3BlbmVkRHJhd2VyICE9PSBfY3VycmVudERyYXdlciApIHtcclxuICAgICAgICAgICAgICAgICAgICBfY3VycmVudERyYXdlciA9IG9wZW5lZERyYXdlcjtcclxuICAgICAgICAgICAgICAgICAgICBpc0ljb25BZGRlZCA9IGZhbHNlO1xyXG4gICAgICAgICAgICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgICAgIHJldHVybiB7ZWxlbWVudDogX2N1cnJlbnREcmF3ZXIsIGlzSWNvbkFkZGVkOiBpc0ljb25BZGRlZH07XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfc2V0QmFkZ2VDb2xvcihldmVudDogSUNhbGVuZGFyLCBjb2xvclRyYXk6IG9iamVjdCk6IG9iamVjdCB7XHJcblxyXG4gICAgICAgIGxldCBjb2xvcjogb2JqZWN0ID0ge3ByaW1hcnk6ICcjMmE2ZGIwJywgc2Vjb25kYXJ5OiAnIzJGNzlDMyd9O1xyXG5cclxuICAgICAgICBpZiAoIGV2ZW50LmJhZGdlLmNvbG9yICE9PSB1bmRlZmluZWQgJiYgIXRoaXMuX2NvbG9yTGlzdC5pbmNsdWRlcyhldmVudC5iYWRnZS5jb2xvcikgKSB7XHJcbiAgICAgICAgICAgIGNvbnNvbGUud2FybignS2QtQ2FsZW5kYXIgRVJST1I6IGV2ZW50IGJhZGdlIGNvbG9yICcgKyBldmVudC5iYWRnZS5jb2xvciArICcgaXMgbm90IHJlY29nbmlzZWQgYW5kIGhhcyBiZWVuIGF1dG9tYXRpY2FsbHkgc2V0IHRvIGJsdWUuIE9ubHkgXCJ5ZWxsb3dcIiBvciBcImJsdWVcIiBvciBcInJlZFwiIG9yIFwiZ3JlZW5cIiBhcmUgYWxsb3dlZCcsIGV2ZW50KTtcclxuICAgICAgICB9IGVsc2UgaWYgKCBldmVudC5iYWRnZS5jb2xvciAhPT0gdW5kZWZpbmVkICkge1xyXG4gICAgICAgICAgICBjb2xvciA9IHtwcmltYXJ5OiBjb2xvclRyYXlbZXZlbnQuYmFkZ2UuY29sb3JdLnByaW1hcnksIHNlY29uZGFyeSA6IGNvbG9yVHJheVtldmVudC5iYWRnZS5jb2xvcl0uc2Vjb25kYXJ5fTtcclxuICAgICAgICB9XHJcbiAgICAgICAgcmV0dXJuIGNvbG9yO1xyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX3NldEhpZ2hsaWdodENvbG9yKGV2ZW50OiBJQ2FsZW5kYXIpOiB2b2lkIHtcclxuXHJcbiAgICAgICAgaWYgKCBldmVudC5iYWRnZS5oaWdobGlnaHQgIT09IHVuZGVmaW5lZCAmJiAhdGhpcy5faGlnaGxpZ2h0TGlzdC5pbmNsdWRlcyggZXZlbnQuYmFkZ2UuaGlnaGxpZ2h0KSApIHtcclxuICAgICAgICAgICAgY29uc29sZS53YXJuKCdLZC1DYWxlbmRhciBFUlJPUjogZXZlbnQgYmFkZ2UgaGlnaGxpZ2h0ICcgKyBldmVudC5iYWRnZS5oaWdobGlnaHQgKyAnIGlzIG5vdCByZWNvZ25pc2VkIGFuZCBoYXMgYmVlbiBhdXRvbWF0aWNhbGx5IHNldCB0byB3aGl0ZS4gT25seSBcImdyZXlcIiBhbmQgXCJ3aGl0ZVwiIGFyZSBhbGxvd2VkJywgZXZlbnQpO1xyXG4gICAgICAgIH0gZWxzZSBpZiAoIGV2ZW50LmJhZGdlLmhpZ2hsaWdodCAhPT0gdW5kZWZpbmVkICYmIGV2ZW50LmJhZGdlLmhpZ2hsaWdodCAhPT0gJ3doaXRlJyApIHtcclxuICAgICAgICAgICAgZXZlbnQuYmFkZ2UuaGlnaGxpZ2h0ID0gJ2dyZXknOyAvLyBzdGFuZGFyZGl6ZSBncmF5L2dyZXkgdG8gZ3JleVxyXG4gICAgICAgIH1cclxuICAgIH1cclxufVxyXG4iXX0=