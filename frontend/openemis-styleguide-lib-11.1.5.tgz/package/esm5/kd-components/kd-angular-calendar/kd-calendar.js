import { __decorate, __metadata } from "tslib";
import { Component, ViewEncapsulation, OnInit, OnChanges, SimpleChanges, Input, Output, EventEmitter, ElementRef } from '@angular/core';
import { format, differenceInCalendarDays } from 'date-fns';
import { CalendarEventTitleFormatter, CalendarDateFormatter } from 'angular-calendar';
import { CustomEventTitleFormatter, CustomDateFormatter, CalendarHelper } from './config/kd-calendar-svc';
import { Subject } from 'rxjs';
var KdCalendar = /** @class */ (function () {
    function KdCalendar(_calendarHelper, _elRef) {
        this._calendarHelper = _calendarHelper;
        this._elRef = _elRef;
        this.refresh = new Subject();
        this.viewDate = new Date();
        this.activeDayIsOpen = false;
        this._colorTray = {
            'blue': { primary: '#2a6db0', secondary: '#2F79C3' },
            'red': { primary: '#b84242', secondary: '#CB4945' },
            'yellow': { primary: '#d78f32', secondary: '#EF9F38' },
            'green': { primary: '#159e82', secondary: '#17b090' }
        };
        // public eventCalendar: Array<ICalendar>;
        this.calendarType = 'month';
        this.events = [];
        this.onEventClicked = new EventEmitter();
    }
    // init
    KdCalendar.prototype.ngOnInit = function () {
        // this.eventCalendar = [];
        for (var i = 0; i < this.events.length; i++) {
            var event_1 = this.events[i];
            var returnData = this._calendarHelper.addMissingRequiredPropertyForEvent(event_1, this._colorTray);
            if (returnData === false) {
                continue;
            }
        }
        this.initApi();
    };
    KdCalendar.prototype.ngOnChanges = function (changes) {
        if (changes.hasOwnProperty('events')) {
            for (var i = 0; i < changes.events.currentValue.length; i++) {
                var event_2 = changes.events.currentValue[i];
                var returnData = this._calendarHelper.addMissingRequiredPropertyForEvent(event_2, this._colorTray);
                if (returnData === false) {
                    continue;
                }
            }
            this.refresh.next();
        }
    };
    KdCalendar.prototype.initApi = function () {
        var _this = this;
        this.api.getCalendarDate = function () { return format(_this._calendarHelper.stringToDate(_this.viewDate), 'YYYY-MM-DD'); };
        this.api.setCalendarType = function (_type) { return _this.calendarType = _type; };
        this.api.nextMonth = function () { return _this._onViewChange('month', 'next'); };
        this.api.nextWeek = function () { return _this._onViewChange('week', 'next'); };
        this.api.nextDay = function () { return _this._onViewChange('day', 'next'); };
        this.api.previousMonth = function () { return _this._onViewChange('month', 'previous'); };
        this.api.previousWeek = function () { return _this._onViewChange('week', 'previous'); };
        this.api.previousDay = function () { return _this._onViewChange('day', 'previous'); };
        this.api.goDate = function (dateString) { var goWhere = (dateString) ? dateString : 'today'; _this._onViewChange(goWhere, 'go'); };
    };
    KdCalendar.prototype.beforeMonthViewRender = function (_a) {
        var _this = this;
        var body = _a.body;
        body.forEach(function (day) {
            if (_this._calendarHelper.getUniqueDateToHighlight(day.date, _this.events)) {
                day.cssClass = 'highlight-cell-grey';
            }
        });
    };
    KdCalendar.prototype.generateViewMoreValue = function (events) {
        var eventsLength = events.length;
        if (events[0].id === 1) {
            eventsLength = 2000;
        }
        var value = this._calendarHelper.generateViewMoreValue(eventsLength);
        return value;
    };
    KdCalendar.prototype.dayClicked = function (_a) {
        var date = _a.date, events = _a.events;
        var isSameDate = (this.viewDate === date || differenceInCalendarDays(this.viewDate, date) === 0);
        if ((isSameDate === true && this.activeDayIsOpen === true) || events.length === 0) {
            this.activeDayIsOpen = false;
        }
        else {
            this.activeDayIsOpen = true;
            this.viewDate = date;
            this._showCloseIcon();
        }
    };
    KdCalendar.prototype._showCloseIcon = function () {
        var thisController = this;
        var time = 1;
        setTimeout(function () {
            var eventOpenedDrawers = thisController._elRef.nativeElement.querySelectorAll('.cal-open-day-events');
            if (eventOpenedDrawers) {
                var addIcon = thisController._calendarHelper.getOpenedDrawer(eventOpenedDrawers, thisController._currentDrawer);
                thisController._currentDrawer = addIcon.element;
                var isIconAdded = addIcon.isIconAdded;
                if (!isIconAdded) {
                    var spanEl = thisController._calendarHelper.createCloseIconElement();
                    spanEl.onclick = function (event) {
                        thisController.closeEventDetailPanel(event);
                    };
                    thisController._currentDrawer.insertBefore(spanEl, thisController._currentDrawer.firstChild);
                }
            }
            else {
                time++;
                thisController._showCloseIcon();
            }
        }, time);
    };
    KdCalendar.prototype.closeEventDetailPanel = function (event) {
        event.stopPropagation();
        this.activeDayIsOpen = false;
    };
    // api
    KdCalendar.prototype.handleEvent = function (_event) {
        var eventClean = this._calendarHelper.cleanEventProperty(_event);
        this.onEventClicked.emit(eventClean);
        this._calendarHelper.addMissingRequiredPropertyForEvent(eventClean, this._colorTray);
        this.refresh.next();
    };
    KdCalendar.prototype._onViewChange = function (_calendarType, _action) {
        var newDate = this._calendarHelper.getViewDate(_calendarType, _action, this.viewDate);
        if (typeof newDate !== 'boolean') {
            this.activeDayIsOpen = false;
            this.viewDate = this._calendarHelper.stringToDate(newDate);
            this.api.getCalendarDate(format(this._calendarHelper.stringToDate(this.viewDate), 'YYYY-MM-DD'));
            this.refresh.next();
        }
        else {
            console.warn('Kd-Calendar ERROR: calendarType: ' + _calendarType + ' and action:' + _action + ' for onViewChange function only takes in calendar type: "year" or "month" or "week" or "day", action: "next" or "previous" or "today" as the argument');
        }
    };
    KdCalendar.ctorParameters = function () { return [
        { type: CalendarHelper },
        { type: ElementRef }
    ]; };
    __decorate([
        Input(),
        __metadata("design:type", String)
    ], KdCalendar.prototype, "calendarType", void 0);
    __decorate([
        Input(),
        __metadata("design:type", Array)
    ], KdCalendar.prototype, "events", void 0);
    __decorate([
        Input(),
        __metadata("design:type", Object)
    ], KdCalendar.prototype, "api", void 0);
    __decorate([
        Output(),
        __metadata("design:type", EventEmitter)
    ], KdCalendar.prototype, "onEventClicked", void 0);
    KdCalendar = __decorate([
        Component({
            selector: 'kd-calendar',
            template: "<ng-template #customCellTemplate let-day=\"day\" let-locale=\"locale\">\r\n    <div class=\"cal-cell-top\">\r\n        <span class=\"cal-day-number\">{{ day.date | calendarDate:'monthViewDayNumber':locale }}</span>\r\n        <span class=\"kdx-cal-view-more\" *ngIf=\"day.events.length > 4\">{{ generateViewMoreValue(day.events) }}</span>\r\n        <div class=\"kdx-cal-cell-event-top\">\r\n            <ng-container *ngFor=\"let event; of:day.events|slice:0:4; let i=index\">\r\n                <div *ngIf=\"i<4 && event.badge.position === 'top'\" class=\"cal-cell-event-type\">\r\n                    <small class=\"kdx-cal-day-event\" *ngIf=\"event.badge.position === 'top'\" [ngClass]=\"(event.badge.color === 'green') ? 'kdx btn-success' : (event.badge.color === 'red') ? 'kdx btn-error' : (event.badge.color === 'yellow') ? 'kdx btn-warning' : 'kdx btn-info'\">{{ event.badge.label }}</small>\r\n                </div>\r\n            </ng-container>\r\n        </div>\r\n    </div>\r\n    <div class=\"kdx-cal-cell-event-bottom\">\r\n        <ng-container *ngFor=\"let event; of:day.events|slice:0:4; let i=index\">\r\n            <div *ngIf=\"i<4 && event.badge.position === 'bottom'\" class=\"cal-cell-event-type\">\r\n                <small class=\"kdx-cal-day-event\" *ngIf=\"event.badge.position === 'bottom'\" [ngClass]=\"(event.badge.color === 'green') ? 'kdx btn-success' : (event.badge.color === 'red') ? 'kdx btn-error' : (event.badge.color === 'yellow') ? 'kdx btn-warning' : 'kdx btn-info'\">{{ event.badge.label }}</small>\r\n            </div>\r\n        </ng-container>\r\n    </div>\r\n</ng-template>\r\n<div class=\"kdx-calendar\">\r\n    <div [ngSwitch]=\"calendarType\">\r\n        <mwl-calendar-month-view *ngSwitchCase=\"'month'\" class=\"cal-month-view\" [viewDate]=\"viewDate\" [(events)]=\"events\" [refresh]=\"refresh\" [activeDayIsOpen]=\"activeDayIsOpen\" (dayClicked)=\"dayClicked($event.day)\" (eventClicked)=\"handleEvent($event.event)\" (beforeViewRender)=\"beforeMonthViewRender($event)\" [cellTemplate]=\"customCellTemplate\">\r\n        </mwl-calendar-month-view>\r\n        <mwl-calendar-week-view *ngSwitchCase=\"'week'\" class=\"cal-week-view\" [viewDate]=\"viewDate\" [(events)]=\"events\" [refresh]=\"refresh\" (eventClicked)=\"handleEvent($event.event)\">\r\n        </mwl-calendar-week-view>\r\n        <!-- <mwl-calendar-day-view *ngSwitchCase=\"'day'\" class=\"cal-day-view\" [viewDate]=\"viewDate\" [(events)]=\"events\" [refresh]=\"refresh\" (eventClicked)=\"handleEvent($event.event)\">\r\n        </mwl-calendar-day-view> -->\r\n    </div>\r\n</div>\r\n",
            encapsulation: ViewEncapsulation.None,
            providers: [
                {
                    provide: CalendarEventTitleFormatter,
                    useClass: CustomEventTitleFormatter
                },
                {
                    provide: CalendarDateFormatter,
                    useClass: CustomDateFormatter
                },
                CalendarHelper
            ]
        }),
        __metadata("design:paramtypes", [CalendarHelper,
            ElementRef])
    ], KdCalendar);
    return KdCalendar;
}());
export { KdCalendar };
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoia2QtY2FsZW5kYXIuanMiLCJzb3VyY2VSb290Ijoibmc6Ly9vcGVuZW1pcy1zdHlsZWd1aWRlLWxpYi8iLCJzb3VyY2VzIjpbImtkLWNvbXBvbmVudHMva2QtYW5ndWxhci1jYWxlbmRhci9rZC1jYWxlbmRhci50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiO0FBQUEsT0FBTyxFQUNILFNBQVMsRUFDVCxpQkFBaUIsRUFDakIsTUFBTSxFQUNOLFNBQVMsRUFDVCxhQUFhLEVBQ2IsS0FBSyxFQUNMLE1BQU0sRUFDTixZQUFZLEVBQ1osVUFBVSxFQUNiLE1BQU0sZUFBZSxDQUFDO0FBQ3ZCLE9BQU8sRUFDSCxNQUFNLEVBQ04sd0JBQXdCLEVBQzNCLE1BQU0sVUFBVSxDQUFDO0FBQ2xCLE9BQU8sRUFFSCwyQkFBMkIsRUFFM0IscUJBQXFCLEVBQ3hCLE1BQU0sa0JBQWtCLENBQUM7QUFDMUIsT0FBTyxFQUFFLHlCQUF5QixFQUFFLG1CQUFtQixFQUFFLGNBQWMsRUFBRSxNQUFNLDBCQUEwQixDQUFDO0FBQzFHLE9BQU8sRUFBRSxPQUFPLEVBQUUsTUFBTSxNQUFNLENBQUM7QUFxQi9CO0lBMEJJLG9CQUNZLGVBQStCLEVBQy9CLE1BQWtCO1FBRGxCLG9CQUFlLEdBQWYsZUFBZSxDQUFnQjtRQUMvQixXQUFNLEdBQU4sTUFBTSxDQUFZO1FBMUJ2QixZQUFPLEdBQWlCLElBQUksT0FBTyxFQUFFLENBQUM7UUFFdEMsYUFBUSxHQUFTLElBQUksSUFBSSxFQUFFLENBQUM7UUFFNUIsb0JBQWUsR0FBWSxLQUFLLENBQUM7UUFFaEMsZUFBVSxHQUFXO1lBQ3pCLE1BQU0sRUFBRyxFQUFDLE9BQU8sRUFBRSxTQUFTLEVBQUUsU0FBUyxFQUFFLFNBQVMsRUFBQztZQUNuRCxLQUFLLEVBQUcsRUFBQyxPQUFPLEVBQUUsU0FBUyxFQUFFLFNBQVMsRUFBRSxTQUFTLEVBQUM7WUFDbEQsUUFBUSxFQUFHLEVBQUMsT0FBTyxFQUFFLFNBQVMsRUFBRSxTQUFTLEVBQUUsU0FBUyxFQUFDO1lBQ3JELE9BQU8sRUFBRyxFQUFDLE9BQU8sRUFBRSxTQUFTLEVBQUUsU0FBUyxFQUFFLFNBQVMsRUFBQztTQUN2RCxDQUFDO1FBR0YsMENBQTBDO1FBRWpDLGlCQUFZLEdBQVcsT0FBTyxDQUFDO1FBRS9CLFdBQU0sR0FBcUIsRUFBRSxDQUFDO1FBSTdCLG1CQUFjLEdBQTRCLElBQUksWUFBWSxFQUFhLENBQUM7SUFLOUUsQ0FBQztJQUVMLE9BQU87SUFFUCw2QkFBUSxHQUFSO1FBRUksMkJBQTJCO1FBRTNCLEtBQU0sSUFBSSxDQUFDLEdBQVcsQ0FBQyxFQUFFLENBQUMsR0FBRyxJQUFJLENBQUMsTUFBTSxDQUFDLE1BQU0sRUFBRSxDQUFDLEVBQUUsRUFBRztZQUNuRCxJQUFJLE9BQUssR0FBYyxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDO1lBQ3RDLElBQUksVUFBVSxHQUFZLElBQUksQ0FBQyxlQUFlLENBQUMsa0NBQWtDLENBQUMsT0FBSyxFQUFFLElBQUksQ0FBQyxVQUFVLENBQUMsQ0FBQztZQUMxRyxJQUFLLFVBQVUsS0FBSyxLQUFLLEVBQUc7Z0JBQ3hCLFNBQVM7YUFDWjtTQUNKO1FBRUQsSUFBSSxDQUFDLE9BQU8sRUFBRSxDQUFDO0lBQ25CLENBQUM7SUFFRCxnQ0FBVyxHQUFYLFVBQVksT0FBc0I7UUFDOUIsSUFBSyxPQUFPLENBQUMsY0FBYyxDQUFDLFFBQVEsQ0FBQyxFQUFHO1lBRXBDLEtBQU0sSUFBSSxDQUFDLEdBQVcsQ0FBQyxFQUFFLENBQUMsR0FBRyxPQUFPLENBQUMsTUFBTSxDQUFDLFlBQVksQ0FBQyxNQUFNLEVBQUUsQ0FBQyxFQUFFLEVBQUc7Z0JBQ25FLElBQUksT0FBSyxHQUFjLE9BQU8sQ0FBQyxNQUFNLENBQUMsWUFBWSxDQUFDLENBQUMsQ0FBQyxDQUFDO2dCQUN0RCxJQUFJLFVBQVUsR0FBWSxJQUFJLENBQUMsZUFBZSxDQUFDLGtDQUFrQyxDQUFDLE9BQUssRUFBRSxJQUFJLENBQUMsVUFBVSxDQUFDLENBQUM7Z0JBQzFHLElBQUssVUFBVSxLQUFLLEtBQUssRUFBRztvQkFDeEIsU0FBUztpQkFDWjthQUNKO1lBRUQsSUFBSSxDQUFDLE9BQU8sQ0FBQyxJQUFJLEVBQUUsQ0FBQztTQUN2QjtJQUNMLENBQUM7SUFFRCw0QkFBTyxHQUFQO1FBQUEsaUJBVUM7UUFURyxJQUFJLENBQUMsR0FBRyxDQUFDLGVBQWUsR0FBRyxjQUFnQixPQUFPLE1BQU0sQ0FBQyxLQUFJLENBQUMsZUFBZSxDQUFDLFlBQVksQ0FBQyxLQUFJLENBQUMsUUFBUSxDQUFDLEVBQUUsWUFBWSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7UUFDNUgsSUFBSSxDQUFDLEdBQUcsQ0FBQyxlQUFlLEdBQUcsVUFBQyxLQUFhLElBQUssT0FBQSxLQUFJLENBQUMsWUFBWSxHQUFHLEtBQUssRUFBekIsQ0FBeUIsQ0FBQztRQUN4RSxJQUFJLENBQUMsR0FBRyxDQUFDLFNBQVMsR0FBRyxjQUFNLE9BQUEsS0FBSSxDQUFDLGFBQWEsQ0FBQyxPQUFPLEVBQUUsTUFBTSxDQUFDLEVBQW5DLENBQW1DLENBQUM7UUFDL0QsSUFBSSxDQUFDLEdBQUcsQ0FBQyxRQUFRLEdBQUcsY0FBTSxPQUFBLEtBQUksQ0FBQyxhQUFhLENBQUMsTUFBTSxFQUFFLE1BQU0sQ0FBQyxFQUFsQyxDQUFrQyxDQUFDO1FBQzdELElBQUksQ0FBQyxHQUFHLENBQUMsT0FBTyxHQUFHLGNBQU0sT0FBQSxLQUFJLENBQUMsYUFBYSxDQUFDLEtBQUssRUFBRSxNQUFNLENBQUMsRUFBakMsQ0FBaUMsQ0FBQztRQUMzRCxJQUFJLENBQUMsR0FBRyxDQUFDLGFBQWEsR0FBRyxjQUFNLE9BQUEsS0FBSSxDQUFDLGFBQWEsQ0FBQyxPQUFPLEVBQUUsVUFBVSxDQUFDLEVBQXZDLENBQXVDLENBQUM7UUFDdkUsSUFBSSxDQUFDLEdBQUcsQ0FBQyxZQUFZLEdBQUcsY0FBTSxPQUFBLEtBQUksQ0FBQyxhQUFhLENBQUMsTUFBTSxFQUFFLFVBQVUsQ0FBQyxFQUF0QyxDQUFzQyxDQUFDO1FBQ3JFLElBQUksQ0FBQyxHQUFHLENBQUMsV0FBVyxHQUFHLGNBQU0sT0FBQSxLQUFJLENBQUMsYUFBYSxDQUFDLEtBQUssRUFBRSxVQUFVLENBQUMsRUFBckMsQ0FBcUMsQ0FBQztRQUNuRSxJQUFJLENBQUMsR0FBRyxDQUFDLE1BQU0sR0FBRyxVQUFDLFVBQW1CLElBQU8sSUFBSSxPQUFPLEdBQVcsQ0FBQyxVQUFVLENBQUMsQ0FBQyxDQUFDLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxLQUFJLENBQUMsYUFBYSxDQUFDLE9BQU8sRUFBRSxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztJQUNqSixDQUFDO0lBRUQsMENBQXFCLEdBQXJCLFVBQXNCLEVBQTBDO1FBQWhFLGlCQU1DO1lBTnVCLGNBQUk7UUFDeEIsSUFBSSxDQUFDLE9BQU8sQ0FBQyxVQUFBLEdBQUc7WUFDWixJQUFLLEtBQUksQ0FBQyxlQUFlLENBQUMsd0JBQXdCLENBQUMsR0FBRyxDQUFDLElBQUksRUFBRSxLQUFJLENBQUMsTUFBTSxDQUFDLEVBQUc7Z0JBQ3hFLEdBQUcsQ0FBQyxRQUFRLEdBQUcscUJBQXFCLENBQUM7YUFDeEM7UUFDTCxDQUFDLENBQUMsQ0FBQztJQUNQLENBQUM7SUFFRCwwQ0FBcUIsR0FBckIsVUFBc0IsTUFBbUI7UUFDckMsSUFBSSxZQUFZLEdBQVcsTUFBTSxDQUFDLE1BQU0sQ0FBQztRQUN6QyxJQUFLLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLEtBQUssQ0FBQyxFQUFHO1lBQ3RCLFlBQVksR0FBRyxJQUFJLENBQUM7U0FDdkI7UUFDRCxJQUFJLEtBQUssR0FBVyxJQUFJLENBQUMsZUFBZSxDQUFDLHFCQUFxQixDQUFDLFlBQVksQ0FBQyxDQUFDO1FBQzdFLE9BQU8sS0FBSyxDQUFDO0lBQ2pCLENBQUM7SUFFRCwrQkFBVSxHQUFWLFVBQVcsRUFBd0Q7WUFBdEQsY0FBSSxFQUFFLGtCQUFNO1FBRXJCLElBQUksVUFBVSxHQUFZLENBQUMsSUFBSSxDQUFDLFFBQVEsS0FBSyxJQUFJLElBQUksd0JBQXdCLENBQUMsSUFBSSxDQUFDLFFBQVEsRUFBRSxJQUFJLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQztRQUMxRyxJQUFJLENBQUUsVUFBVSxLQUFLLElBQUksSUFBSSxJQUFJLENBQUMsZUFBZSxLQUFLLElBQUksQ0FBQyxJQUFJLE1BQU0sQ0FBQyxNQUFNLEtBQUssQ0FBQyxFQUFHO1lBQ2pGLElBQUksQ0FBQyxlQUFlLEdBQUcsS0FBSyxDQUFDO1NBQ2hDO2FBQU07WUFDSCxJQUFJLENBQUMsZUFBZSxHQUFHLElBQUksQ0FBQztZQUM1QixJQUFJLENBQUMsUUFBUSxHQUFHLElBQUksQ0FBQztZQUNyQixJQUFJLENBQUMsY0FBYyxFQUFFLENBQUM7U0FDekI7SUFDTCxDQUFDO0lBRU8sbUNBQWMsR0FBdEI7UUFFSSxJQUFJLGNBQWMsR0FBUyxJQUFJLENBQUM7UUFDaEMsSUFBSSxJQUFJLEdBQVcsQ0FBQyxDQUFDO1FBRXJCLFVBQVUsQ0FBQztZQUVQLElBQUksa0JBQWtCLEdBQW1CLGNBQWMsQ0FBQyxNQUFNLENBQUMsYUFBYSxDQUFDLGdCQUFnQixDQUFDLHNCQUFzQixDQUFDLENBQUM7WUFFdEgsSUFBSyxrQkFBa0IsRUFBRztnQkFFdEIsSUFBSSxPQUFPLEdBQXdCLGNBQWMsQ0FBQyxlQUFlLENBQUMsZUFBZSxDQUFDLGtCQUFrQixFQUFFLGNBQWMsQ0FBQyxjQUFjLENBQUMsQ0FBQztnQkFFckksY0FBYyxDQUFDLGNBQWMsR0FBRyxPQUFPLENBQUMsT0FBTyxDQUFDO2dCQUNoRCxJQUFJLFdBQVcsR0FBRyxPQUFPLENBQUMsV0FBVyxDQUFDO2dCQUV0QyxJQUFLLENBQUMsV0FBVyxFQUFHO29CQUNoQixJQUFJLE1BQU0sR0FBb0IsY0FBYyxDQUFDLGVBQWUsQ0FBQyxzQkFBc0IsRUFBRSxDQUFDO29CQUN0RixNQUFNLENBQUMsT0FBTyxHQUFHLFVBQVMsS0FBSzt3QkFDM0IsY0FBYyxDQUFDLHFCQUFxQixDQUFDLEtBQUssQ0FBQyxDQUFDO29CQUNoRCxDQUFDLENBQUM7b0JBRUYsY0FBYyxDQUFDLGNBQWMsQ0FBQyxZQUFZLENBQUMsTUFBTSxFQUFFLGNBQWMsQ0FBQyxjQUFjLENBQUMsVUFBVSxDQUFDLENBQUM7aUJBQ2hHO2FBQ0o7aUJBQU07Z0JBQ0gsSUFBSSxFQUFFLENBQUM7Z0JBQ1AsY0FBYyxDQUFDLGNBQWMsRUFBRSxDQUFDO2FBQ25DO1FBQ0wsQ0FBQyxFQUFFLElBQUksQ0FBQyxDQUFDO0lBQ2IsQ0FBQztJQUVELDBDQUFxQixHQUFyQixVQUFzQixLQUFLO1FBQ3ZCLEtBQUssQ0FBQyxlQUFlLEVBQUUsQ0FBQztRQUN4QixJQUFJLENBQUMsZUFBZSxHQUFHLEtBQUssQ0FBQztJQUNqQyxDQUFDO0lBRUQsTUFBTTtJQUVOLGdDQUFXLEdBQVgsVUFBWSxNQUFpQjtRQUV6QixJQUFJLFVBQVUsR0FBYyxJQUFJLENBQUMsZUFBZSxDQUFDLGtCQUFrQixDQUFDLE1BQU0sQ0FBQyxDQUFDO1FBRTVFLElBQUksQ0FBQyxjQUFjLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxDQUFDO1FBQ3JDLElBQUksQ0FBQyxlQUFlLENBQUMsa0NBQWtDLENBQUMsVUFBVSxFQUFFLElBQUksQ0FBQyxVQUFVLENBQUMsQ0FBQztRQUVyRixJQUFJLENBQUMsT0FBTyxDQUFDLElBQUksRUFBRSxDQUFDO0lBQ3hCLENBQUM7SUFFTyxrQ0FBYSxHQUFyQixVQUFzQixhQUFxQixFQUFFLE9BQWU7UUFFeEQsSUFBSSxPQUFPLEdBQWlCLElBQUksQ0FBQyxlQUFlLENBQUMsV0FBVyxDQUFDLGFBQWEsRUFBRSxPQUFPLEVBQUUsSUFBSSxDQUFDLFFBQVEsQ0FBQyxDQUFDO1FBRXBHLElBQUssT0FBTyxPQUFPLEtBQUssU0FBUyxFQUFHO1lBQ2hDLElBQUksQ0FBQyxlQUFlLEdBQUcsS0FBSyxDQUFDO1lBQzdCLElBQUksQ0FBQyxRQUFRLEdBQUcsSUFBSSxDQUFDLGVBQWUsQ0FBQyxZQUFZLENBQUMsT0FBTyxDQUFDLENBQUM7WUFDM0QsSUFBSSxDQUFDLEdBQUcsQ0FBQyxlQUFlLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxlQUFlLENBQUMsWUFBWSxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsRUFBRSxZQUFZLENBQUMsQ0FBQyxDQUFDO1lBQ2pHLElBQUksQ0FBQyxPQUFPLENBQUMsSUFBSSxFQUFFLENBQUM7U0FDdkI7YUFBTTtZQUNILE9BQU8sQ0FBQyxJQUFJLENBQUMsbUNBQW1DLEdBQUcsYUFBYSxHQUFHLGNBQWMsR0FBRyxPQUFPLEdBQUcsdUpBQXVKLENBQUMsQ0FBQztTQUMxUDtJQUNMLENBQUM7O2dCQXpJNEIsY0FBYztnQkFDdkIsVUFBVTs7SUFWckI7UUFBUixLQUFLLEVBQUU7O29EQUFnQztJQUUvQjtRQUFSLEtBQUssRUFBRTtrQ0FBUyxLQUFLOzhDQUFpQjtJQUU5QjtRQUFSLEtBQUssRUFBRTs7MkNBQW1CO0lBRWpCO1FBQVQsTUFBTSxFQUFFO2tDQUFpQixZQUFZO3NEQUE0QztJQXhCekUsVUFBVTtRQWxCdEIsU0FBUyxDQUFDO1lBQ1AsUUFBUSxFQUFFLGFBQWE7WUFDdkIsMmpGQUFpQztZQUNqQyxhQUFhLEVBQUUsaUJBQWlCLENBQUMsSUFBSTtZQUNyQyxTQUFTLEVBQUU7Z0JBQ1A7b0JBQ0UsT0FBTyxFQUFFLDJCQUEyQjtvQkFDcEMsUUFBUSxFQUFFLHlCQUF5QjtpQkFDcEM7Z0JBRUQ7b0JBQ0UsT0FBTyxFQUFFLHFCQUFxQjtvQkFDOUIsUUFBUSxFQUFFLG1CQUFtQjtpQkFDOUI7Z0JBQ0QsY0FBYzthQUNqQjtTQUNKLENBQUM7eUNBNkIrQixjQUFjO1lBQ3ZCLFVBQVU7T0E1QnJCLFVBQVUsQ0FzS3RCO0lBQUQsaUJBQUM7Q0FBQSxBQXRLRCxJQXNLQztTQXRLWSxVQUFVIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHtcclxuICAgIENvbXBvbmVudCxcclxuICAgIFZpZXdFbmNhcHN1bGF0aW9uLFxyXG4gICAgT25Jbml0LFxyXG4gICAgT25DaGFuZ2VzLFxyXG4gICAgU2ltcGxlQ2hhbmdlcyxcclxuICAgIElucHV0LFxyXG4gICAgT3V0cHV0LFxyXG4gICAgRXZlbnRFbWl0dGVyLFxyXG4gICAgRWxlbWVudFJlZlxyXG59IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xyXG5pbXBvcnQge1xyXG4gICAgZm9ybWF0LFxyXG4gICAgZGlmZmVyZW5jZUluQ2FsZW5kYXJEYXlzXHJcbn0gZnJvbSAnZGF0ZS1mbnMnO1xyXG5pbXBvcnQge1xyXG4gICAgQ2FsZW5kYXJFdmVudCxcclxuICAgIENhbGVuZGFyRXZlbnRUaXRsZUZvcm1hdHRlcixcclxuICAgIENhbGVuZGFyTW9udGhWaWV3RGF5LFxyXG4gICAgQ2FsZW5kYXJEYXRlRm9ybWF0dGVyXHJcbn0gZnJvbSAnYW5ndWxhci1jYWxlbmRhcic7XHJcbmltcG9ydCB7IEN1c3RvbUV2ZW50VGl0bGVGb3JtYXR0ZXIsIEN1c3RvbURhdGVGb3JtYXR0ZXIsIENhbGVuZGFySGVscGVyIH0gZnJvbSAnLi9jb25maWcva2QtY2FsZW5kYXItc3ZjJztcclxuaW1wb3J0IHsgU3ViamVjdCB9IGZyb20gJ3J4anMnO1xyXG5pbXBvcnQgeyBJQ2FsZW5kYXIsIElDYWxlbmRhckFwaSwgSUNhbGVuZGFyT3BlbkRyYXdlciB9IGZyb20gJy4va2QtYW5ndWxhci1jYWxlbmRhci1pbnRlcmZhY2UnO1xyXG5cclxuQENvbXBvbmVudCh7XHJcbiAgICBzZWxlY3RvcjogJ2tkLWNhbGVuZGFyJyxcclxuICAgIHRlbXBsYXRlVXJsOiAnLi9rZC1jYWxlbmRhci5odG1sJyxcclxuICAgIGVuY2Fwc3VsYXRpb246IFZpZXdFbmNhcHN1bGF0aW9uLk5vbmUsXHJcbiAgICBwcm92aWRlcnM6IFtcclxuICAgICAgICB7XHJcbiAgICAgICAgICBwcm92aWRlOiBDYWxlbmRhckV2ZW50VGl0bGVGb3JtYXR0ZXIsXHJcbiAgICAgICAgICB1c2VDbGFzczogQ3VzdG9tRXZlbnRUaXRsZUZvcm1hdHRlclxyXG4gICAgICAgIH0sXHJcblxyXG4gICAgICAgIHtcclxuICAgICAgICAgIHByb3ZpZGU6IENhbGVuZGFyRGF0ZUZvcm1hdHRlcixcclxuICAgICAgICAgIHVzZUNsYXNzOiBDdXN0b21EYXRlRm9ybWF0dGVyXHJcbiAgICAgICAgfSxcclxuICAgICAgICBDYWxlbmRhckhlbHBlclxyXG4gICAgXVxyXG59KVxyXG5cclxuZXhwb3J0IGNsYXNzIEtkQ2FsZW5kYXIgaW1wbGVtZW50cyBPbkluaXQsIE9uQ2hhbmdlcyB7XHJcblxyXG4gICAgcHVibGljIHJlZnJlc2g6IFN1YmplY3Q8YW55PiA9IG5ldyBTdWJqZWN0KCk7XHJcblxyXG4gICAgcHVibGljIHZpZXdEYXRlOiBEYXRlID0gbmV3IERhdGUoKTtcclxuXHJcbiAgICBwdWJsaWMgYWN0aXZlRGF5SXNPcGVuOiBib29sZWFuID0gZmFsc2U7XHJcblxyXG4gICAgcHJpdmF0ZSBfY29sb3JUcmF5OiBvYmplY3QgPSB7XHJcbiAgICAgICAgJ2JsdWUnIDoge3ByaW1hcnk6ICcjMmE2ZGIwJywgc2Vjb25kYXJ5OiAnIzJGNzlDMyd9LFxyXG4gICAgICAgICdyZWQnIDoge3ByaW1hcnk6ICcjYjg0MjQyJywgc2Vjb25kYXJ5OiAnI0NCNDk0NSd9LFxyXG4gICAgICAgICd5ZWxsb3cnIDoge3ByaW1hcnk6ICcjZDc4ZjMyJywgc2Vjb25kYXJ5OiAnI0VGOUYzOCd9LFxyXG4gICAgICAgICdncmVlbicgOiB7cHJpbWFyeTogJyMxNTllODInLCBzZWNvbmRhcnk6ICcjMTdiMDkwJ31cclxuICAgIH07XHJcbiAgICBwcml2YXRlIF9jdXJyZW50RHJhd2VyOiBFbGVtZW50O1xyXG5cclxuICAgIC8vIHB1YmxpYyBldmVudENhbGVuZGFyOiBBcnJheTxJQ2FsZW5kYXI+O1xyXG5cclxuICAgIEBJbnB1dCgpIGNhbGVuZGFyVHlwZTogc3RyaW5nID0gJ21vbnRoJztcclxuXHJcbiAgICBASW5wdXQoKSBldmVudHM6IEFycmF5PElDYWxlbmRhcj4gPSBbXTtcclxuXHJcbiAgICBASW5wdXQoKSBhcGk6IElDYWxlbmRhckFwaTtcclxuXHJcbiAgICBAT3V0cHV0KCkgb25FdmVudENsaWNrZWQ6IEV2ZW50RW1pdHRlcjxJQ2FsZW5kYXI+ID0gbmV3IEV2ZW50RW1pdHRlcjxJQ2FsZW5kYXI+KCk7XHJcblxyXG4gICAgY29uc3RydWN0b3IoXHJcbiAgICAgICAgcHJpdmF0ZSBfY2FsZW5kYXJIZWxwZXI6IENhbGVuZGFySGVscGVyLFxyXG4gICAgICAgIHByaXZhdGUgX2VsUmVmOiBFbGVtZW50UmVmXHJcbiAgICApIHsgfVxyXG5cclxuICAgIC8vIGluaXRcclxuXHJcbiAgICBuZ09uSW5pdCgpOiB2b2lkIHtcclxuXHJcbiAgICAgICAgLy8gdGhpcy5ldmVudENhbGVuZGFyID0gW107XHJcblxyXG4gICAgICAgIGZvciAoIGxldCBpOiBudW1iZXIgPSAwOyBpIDwgdGhpcy5ldmVudHMubGVuZ3RoOyBpKysgKSB7XHJcbiAgICAgICAgICAgIGxldCBldmVudDogSUNhbGVuZGFyID0gdGhpcy5ldmVudHNbaV07XHJcbiAgICAgICAgICAgIGxldCByZXR1cm5EYXRhOiBib29sZWFuID0gdGhpcy5fY2FsZW5kYXJIZWxwZXIuYWRkTWlzc2luZ1JlcXVpcmVkUHJvcGVydHlGb3JFdmVudChldmVudCwgdGhpcy5fY29sb3JUcmF5KTtcclxuICAgICAgICAgICAgaWYgKCByZXR1cm5EYXRhID09PSBmYWxzZSApIHtcclxuICAgICAgICAgICAgICAgIGNvbnRpbnVlO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICB0aGlzLmluaXRBcGkoKTtcclxuICAgIH1cclxuXHJcbiAgICBuZ09uQ2hhbmdlcyhjaGFuZ2VzOiBTaW1wbGVDaGFuZ2VzKTogdm9pZCB7XHJcbiAgICAgICAgaWYgKCBjaGFuZ2VzLmhhc093blByb3BlcnR5KCdldmVudHMnKSApIHtcclxuXHJcbiAgICAgICAgICAgIGZvciAoIGxldCBpOiBudW1iZXIgPSAwOyBpIDwgY2hhbmdlcy5ldmVudHMuY3VycmVudFZhbHVlLmxlbmd0aDsgaSsrICkge1xyXG4gICAgICAgICAgICAgICAgbGV0IGV2ZW50OiBJQ2FsZW5kYXIgPSBjaGFuZ2VzLmV2ZW50cy5jdXJyZW50VmFsdWVbaV07XHJcbiAgICAgICAgICAgICAgICBsZXQgcmV0dXJuRGF0YTogYm9vbGVhbiA9IHRoaXMuX2NhbGVuZGFySGVscGVyLmFkZE1pc3NpbmdSZXF1aXJlZFByb3BlcnR5Rm9yRXZlbnQoZXZlbnQsIHRoaXMuX2NvbG9yVHJheSk7XHJcbiAgICAgICAgICAgICAgICBpZiAoIHJldHVybkRhdGEgPT09IGZhbHNlICkge1xyXG4gICAgICAgICAgICAgICAgICAgIGNvbnRpbnVlO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICB0aGlzLnJlZnJlc2gubmV4dCgpO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICBpbml0QXBpKCk6IHZvaWQge1xyXG4gICAgICAgIHRoaXMuYXBpLmdldENhbGVuZGFyRGF0ZSA9ICgpOiBzdHJpbmcgPT4geyByZXR1cm4gZm9ybWF0KHRoaXMuX2NhbGVuZGFySGVscGVyLnN0cmluZ1RvRGF0ZSh0aGlzLnZpZXdEYXRlKSwgJ1lZWVktTU0tREQnKTsgfTtcclxuICAgICAgICB0aGlzLmFwaS5zZXRDYWxlbmRhclR5cGUgPSAoX3R5cGU6IHN0cmluZykgPT4gdGhpcy5jYWxlbmRhclR5cGUgPSBfdHlwZTtcclxuICAgICAgICB0aGlzLmFwaS5uZXh0TW9udGggPSAoKSA9PiB0aGlzLl9vblZpZXdDaGFuZ2UoJ21vbnRoJywgJ25leHQnKTtcclxuICAgICAgICB0aGlzLmFwaS5uZXh0V2VlayA9ICgpID0+IHRoaXMuX29uVmlld0NoYW5nZSgnd2VlaycsICduZXh0Jyk7XHJcbiAgICAgICAgdGhpcy5hcGkubmV4dERheSA9ICgpID0+IHRoaXMuX29uVmlld0NoYW5nZSgnZGF5JywgJ25leHQnKTtcclxuICAgICAgICB0aGlzLmFwaS5wcmV2aW91c01vbnRoID0gKCkgPT4gdGhpcy5fb25WaWV3Q2hhbmdlKCdtb250aCcsICdwcmV2aW91cycpO1xyXG4gICAgICAgIHRoaXMuYXBpLnByZXZpb3VzV2VlayA9ICgpID0+IHRoaXMuX29uVmlld0NoYW5nZSgnd2VlaycsICdwcmV2aW91cycpO1xyXG4gICAgICAgIHRoaXMuYXBpLnByZXZpb3VzRGF5ID0gKCkgPT4gdGhpcy5fb25WaWV3Q2hhbmdlKCdkYXknLCAncHJldmlvdXMnKTtcclxuICAgICAgICB0aGlzLmFwaS5nb0RhdGUgPSAoZGF0ZVN0cmluZz86IHN0cmluZykgPT4geyBsZXQgZ29XaGVyZTogc3RyaW5nID0gKGRhdGVTdHJpbmcpID8gZGF0ZVN0cmluZyA6ICd0b2RheSc7IHRoaXMuX29uVmlld0NoYW5nZShnb1doZXJlLCAnZ28nKTsgfTtcclxuICAgIH1cclxuXHJcbiAgICBiZWZvcmVNb250aFZpZXdSZW5kZXIoeyBib2R5IH06IHsgYm9keTogQ2FsZW5kYXJNb250aFZpZXdEYXlbXSB9KTogdm9pZCB7XHJcbiAgICAgICAgYm9keS5mb3JFYWNoKGRheSA9PiB7XHJcbiAgICAgICAgICAgIGlmICggdGhpcy5fY2FsZW5kYXJIZWxwZXIuZ2V0VW5pcXVlRGF0ZVRvSGlnaGxpZ2h0KGRheS5kYXRlLCB0aGlzLmV2ZW50cykgKSB7XHJcbiAgICAgICAgICAgICAgICBkYXkuY3NzQ2xhc3MgPSAnaGlnaGxpZ2h0LWNlbGwtZ3JleSc7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9KTtcclxuICAgIH1cclxuXHJcbiAgICBnZW5lcmF0ZVZpZXdNb3JlVmFsdWUoZXZlbnRzOiBJQ2FsZW5kYXJbXSk6IHN0cmluZyB7XHJcbiAgICAgICAgbGV0IGV2ZW50c0xlbmd0aDogbnVtYmVyID0gZXZlbnRzLmxlbmd0aDtcclxuICAgICAgICBpZiAoIGV2ZW50c1swXS5pZCA9PT0gMSApIHtcclxuICAgICAgICAgICAgZXZlbnRzTGVuZ3RoID0gMjAwMDtcclxuICAgICAgICB9XHJcbiAgICAgICAgbGV0IHZhbHVlOiBzdHJpbmcgPSB0aGlzLl9jYWxlbmRhckhlbHBlci5nZW5lcmF0ZVZpZXdNb3JlVmFsdWUoZXZlbnRzTGVuZ3RoKTtcclxuICAgICAgICByZXR1cm4gdmFsdWU7XHJcbiAgICB9XHJcblxyXG4gICAgZGF5Q2xpY2tlZCh7IGRhdGUsIGV2ZW50c306IHsgZGF0ZTogRGF0ZTsgZXZlbnRzOiBDYWxlbmRhckV2ZW50W10gfSk6IHZvaWQge1xyXG5cclxuICAgICAgICBsZXQgaXNTYW1lRGF0ZTogYm9vbGVhbiA9ICh0aGlzLnZpZXdEYXRlID09PSBkYXRlIHx8IGRpZmZlcmVuY2VJbkNhbGVuZGFyRGF5cyh0aGlzLnZpZXdEYXRlLCBkYXRlKSA9PT0gMCk7XHJcbiAgICAgICAgaWYgKCggaXNTYW1lRGF0ZSA9PT0gdHJ1ZSAmJiB0aGlzLmFjdGl2ZURheUlzT3BlbiA9PT0gdHJ1ZSkgfHwgZXZlbnRzLmxlbmd0aCA9PT0gMCApIHtcclxuICAgICAgICAgICAgdGhpcy5hY3RpdmVEYXlJc09wZW4gPSBmYWxzZTtcclxuICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICB0aGlzLmFjdGl2ZURheUlzT3BlbiA9IHRydWU7XHJcbiAgICAgICAgICAgIHRoaXMudmlld0RhdGUgPSBkYXRlO1xyXG4gICAgICAgICAgICB0aGlzLl9zaG93Q2xvc2VJY29uKCk7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX3Nob3dDbG9zZUljb24oKTogdm9pZCB7XHJcblxyXG4gICAgICAgIGxldCB0aGlzQ29udHJvbGxlcjogdGhpcyA9IHRoaXM7XHJcbiAgICAgICAgbGV0IHRpbWU6IG51bWJlciA9IDE7XHJcblxyXG4gICAgICAgIHNldFRpbWVvdXQoZnVuY3Rpb24oKSB7XHJcblxyXG4gICAgICAgICAgICBsZXQgZXZlbnRPcGVuZWREcmF3ZXJzOiBBcnJheTxFbGVtZW50PiA9IHRoaXNDb250cm9sbGVyLl9lbFJlZi5uYXRpdmVFbGVtZW50LnF1ZXJ5U2VsZWN0b3JBbGwoJy5jYWwtb3Blbi1kYXktZXZlbnRzJyk7XHJcblxyXG4gICAgICAgICAgICBpZiAoIGV2ZW50T3BlbmVkRHJhd2VycyApIHtcclxuXHJcbiAgICAgICAgICAgICAgICBsZXQgYWRkSWNvbjogSUNhbGVuZGFyT3BlbkRyYXdlciA9IHRoaXNDb250cm9sbGVyLl9jYWxlbmRhckhlbHBlci5nZXRPcGVuZWREcmF3ZXIoZXZlbnRPcGVuZWREcmF3ZXJzLCB0aGlzQ29udHJvbGxlci5fY3VycmVudERyYXdlcik7XHJcblxyXG4gICAgICAgICAgICAgICAgdGhpc0NvbnRyb2xsZXIuX2N1cnJlbnREcmF3ZXIgPSBhZGRJY29uLmVsZW1lbnQ7XHJcbiAgICAgICAgICAgICAgICBsZXQgaXNJY29uQWRkZWQgPSBhZGRJY29uLmlzSWNvbkFkZGVkO1xyXG5cclxuICAgICAgICAgICAgICAgIGlmICggIWlzSWNvbkFkZGVkICkge1xyXG4gICAgICAgICAgICAgICAgICAgIGxldCBzcGFuRWw6IEhUTUxTcGFuRWxlbWVudCA9IHRoaXNDb250cm9sbGVyLl9jYWxlbmRhckhlbHBlci5jcmVhdGVDbG9zZUljb25FbGVtZW50KCk7XHJcbiAgICAgICAgICAgICAgICAgICAgc3BhbkVsLm9uY2xpY2sgPSBmdW5jdGlvbihldmVudCkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzQ29udHJvbGxlci5jbG9zZUV2ZW50RGV0YWlsUGFuZWwoZXZlbnQpO1xyXG4gICAgICAgICAgICAgICAgICAgIH07XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIHRoaXNDb250cm9sbGVyLl9jdXJyZW50RHJhd2VyLmluc2VydEJlZm9yZShzcGFuRWwsIHRoaXNDb250cm9sbGVyLl9jdXJyZW50RHJhd2VyLmZpcnN0Q2hpbGQpO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgdGltZSsrO1xyXG4gICAgICAgICAgICAgICAgdGhpc0NvbnRyb2xsZXIuX3Nob3dDbG9zZUljb24oKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH0sIHRpbWUpO1xyXG4gICAgfVxyXG5cclxuICAgIGNsb3NlRXZlbnREZXRhaWxQYW5lbChldmVudCk6IHZvaWQge1xyXG4gICAgICAgIGV2ZW50LnN0b3BQcm9wYWdhdGlvbigpO1xyXG4gICAgICAgIHRoaXMuYWN0aXZlRGF5SXNPcGVuID0gZmFsc2U7XHJcbiAgICB9XHJcblxyXG4gICAgLy8gYXBpXHJcblxyXG4gICAgaGFuZGxlRXZlbnQoX2V2ZW50OiBJQ2FsZW5kYXIpOiB2b2lkIHtcclxuXHJcbiAgICAgICAgbGV0IGV2ZW50Q2xlYW46IElDYWxlbmRhciA9IHRoaXMuX2NhbGVuZGFySGVscGVyLmNsZWFuRXZlbnRQcm9wZXJ0eShfZXZlbnQpO1xyXG5cclxuICAgICAgICB0aGlzLm9uRXZlbnRDbGlja2VkLmVtaXQoZXZlbnRDbGVhbik7XHJcbiAgICAgICAgdGhpcy5fY2FsZW5kYXJIZWxwZXIuYWRkTWlzc2luZ1JlcXVpcmVkUHJvcGVydHlGb3JFdmVudChldmVudENsZWFuLCB0aGlzLl9jb2xvclRyYXkpO1xyXG5cclxuICAgICAgICB0aGlzLnJlZnJlc2gubmV4dCgpO1xyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX29uVmlld0NoYW5nZShfY2FsZW5kYXJUeXBlOiBzdHJpbmcsIF9hY3Rpb246IHN0cmluZyk6IHZvaWQge1xyXG5cclxuICAgICAgICBsZXQgbmV3RGF0ZTogYm9vbGVhbnxEYXRlID0gdGhpcy5fY2FsZW5kYXJIZWxwZXIuZ2V0Vmlld0RhdGUoX2NhbGVuZGFyVHlwZSwgX2FjdGlvbiwgdGhpcy52aWV3RGF0ZSk7XHJcblxyXG4gICAgICAgIGlmICggdHlwZW9mIG5ld0RhdGUgIT09ICdib29sZWFuJyApIHtcclxuICAgICAgICAgICAgdGhpcy5hY3RpdmVEYXlJc09wZW4gPSBmYWxzZTtcclxuICAgICAgICAgICAgdGhpcy52aWV3RGF0ZSA9IHRoaXMuX2NhbGVuZGFySGVscGVyLnN0cmluZ1RvRGF0ZShuZXdEYXRlKTtcclxuICAgICAgICAgICAgdGhpcy5hcGkuZ2V0Q2FsZW5kYXJEYXRlKGZvcm1hdCh0aGlzLl9jYWxlbmRhckhlbHBlci5zdHJpbmdUb0RhdGUodGhpcy52aWV3RGF0ZSksICdZWVlZLU1NLUREJykpO1xyXG4gICAgICAgICAgICB0aGlzLnJlZnJlc2gubmV4dCgpO1xyXG4gICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgIGNvbnNvbGUud2FybignS2QtQ2FsZW5kYXIgRVJST1I6IGNhbGVuZGFyVHlwZTogJyArIF9jYWxlbmRhclR5cGUgKyAnIGFuZCBhY3Rpb246JyArIF9hY3Rpb24gKyAnIGZvciBvblZpZXdDaGFuZ2UgZnVuY3Rpb24gb25seSB0YWtlcyBpbiBjYWxlbmRhciB0eXBlOiBcInllYXJcIiBvciBcIm1vbnRoXCIgb3IgXCJ3ZWVrXCIgb3IgXCJkYXlcIiwgYWN0aW9uOiBcIm5leHRcIiBvciBcInByZXZpb3VzXCIgb3IgXCJ0b2RheVwiIGFzIHRoZSBhcmd1bWVudCcpO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbn1cclxuIl19