import { __decorate } from "tslib";
import { Injectable } from '@angular/core';
// import {
//     KdAGDropdown,
//     KdAGPhoto,
//     KdAGForm,
//     KdAGCheckboxRadio
// } from './ag-grid-components/kd-aggrid-components';
var KdAggridSvc = /** @class */ (function () {
    function KdAggridSvc() {
        this._resizeableCol = 0;
    }
    // private _dataSvc: KdDataSvc = new KdDataSvc();
    KdAggridSvc.prototype.getGridOptions = function () {
        var options = {
            rowData: [],
            columnDefs: [],
            // debug: true,
            headerHeight: 38,
            getRowHeight: this._getRowHeight,
            // animateRows: true,
            // rowBuffer: 5,
            suppressContextMenu: true,
            // suppressMenuMainPanel: true,
            // suppressMenuColumnPanel: true,
            suppressMovableColumns: true,
            suppressMenuHide: true,
            suppressColumnVirtualisation: true,
            unSortIcon: true,
            icons: {
                filter: '<i class="fa fa-filter"/>',
                sortAscending: '<i class="fa fa-caret-down"/>',
                sortDescending: '<i class="fa fa-caret-up"/>',
                sortUnSort: '<i class="fa fa-sort"/>',
                groupExpanded: '<i class="fa fa-minus-circle"/>',
                groupContracted: '<i class="fa fa-plus-circle"/>',
            },
            overlayNoRowsTemplate: '<span class="ag-custom-overlay"><i class="fa fa-info-circle fa-lg margin-right10"></i>No student record found</span>'
        };
        return options;
    };
    KdAggridSvc.prototype.setResult = function (_config) {
        var updateResult = {};
        updateResult.id = (typeof _config !== 'undefined' && typeof _config.id !== 'undefined') ? _config.id : 'kd-grid';
        updateResult.gridHeight = this._checkGridHeight(_config);
        updateResult.checkbox = (typeof _config !== 'undefined' && typeof _config.checkbox !== 'undefined') ? _config.checkbox : false;
        updateResult.radio = (typeof _config !== 'undefined' && typeof _config.radio !== 'undefined') ? _config.radio : false;
        updateResult.externalFilter = (typeof _config !== 'undefined' && typeof _config.externalFilter !== 'undefined') ? _config.externalFilter : false;
        updateResult.loadType = this._checkLoadType(_config);
        updateResult.paginationType = this._checkPaginationType(updateResult.loadType);
        updateResult.pagesize = this._checkPagesize(_config, updateResult.loadType);
        updateResult.totalData = (typeof _config !== 'undefined' && typeof _config.totalData !== 'undefined') ? _config.totalData : -1;
        updateResult.button = (typeof _config !== 'undefined' && typeof _config.button !== 'undefined') ? _config.button : false;
        updateResult.buttonConfig = (typeof _config !== 'undefined' && typeof _config.buttonConfig !== 'undefined') ? this._checkBtnConfig(_config.buttonConfig) : null;
        updateResult.alignment = (typeof _config !== 'undefined' && typeof _config.alignment !== 'undefined') ? _config.alignment : 'middle';
        updateResult.suppressHeightResize = (typeof _config !== 'undefined' && typeof _config.suppressHeightResize !== 'undefined') ? _config.suppressHeightResize : true;
        updateResult.rowClickable = (typeof _config !== 'undefined' && typeof _config.rowClickable !== 'undefined') ? _config.rowClickable : false;
        updateResult.rowMapActionType = (typeof _config !== 'undefined' && typeof _config.rowMapActionType !== 'undefined') ? _config.rowMapActionType : null;
        if (updateResult.radio && updateResult.checkbox)
            updateResult.radio = false;
        return updateResult;
    };
    KdAggridSvc.prototype.setRowResult = function (_rowData) {
        var tableData = (typeof _rowData !== 'undefined') ? _rowData : [];
        return tableData;
    };
    KdAggridSvc.prototype.setColDefs = function (_colDef, _gridOptions, /*_dataSvc: KdDataSvc, */ _router, _isRecursive) {
        if (_isRecursive === void 0) { _isRecursive = false; }
        var colDefConfig = { editMode: false, updatedColDef: [] };
        var tableColumn = {};
        for (var key in _colDef) {
            if (_colDef.hasOwnProperty(key)) {
                this._resizeableCol++;
                tableColumn = {
                    headerName: _colDef[key].headerName,
                    field: (typeof _colDef[key].config !== 'undefined' && typeof _colDef[key].config.map !== 'undefined') ? _colDef[key].config.map : key,
                    editable: false,
                    suppressMenu: (typeof _colDef[key].filterable !== 'undefined') ? !_colDef[key].filterable : true,
                    suppressSorting: (typeof _colDef[key].sortable !== 'undefined') ? !_colDef[key].sortable : true,
                    colId: key,
                    config: (typeof _colDef[key].config !== 'undefined') ? _colDef[key].config : undefined,
                    // cellRenderer: (_params: any): any => {
                    //     if (typeof _params.value === 'number') {
                    //         return _params.value.toString();
                    //     }
                    //     else if (_params.value instanceof Array) {
                    //         JSON.stringify(_params.value);
                    //     }
                    //     return _params.value;
                    // },
                    hide: (typeof _colDef[key].visible !== 'undefined') ? !(_colDef[key].visible) : false,
                    cellClass: 'ag-default'
                };
                if (!tableColumn.suppressMenu) {
                    tableColumn['menuTabs'] = ['filterMenuTab'];
                    tableColumn.filterParams = {
                        newRowsAction: 'keep',
                        cellHeight: 30,
                        selectAllOnMiniFilter: true,
                        values: (typeof _colDef[key].filterVal !== 'undefined' && _colDef[key].filterVal.length > 0) ? _colDef[key].filterVal : undefined
                    };
                }
                if (typeof _colDef[key].config !== 'undefined') {
                    if (typeof _colDef[key].config.input !== 'undefined' && _colDef[key].config.input) {
                        colDefConfig.editMode = true;
                    }
                    tableColumn = this._setColumnConfig(tableColumn, _colDef[key].config, /*_dataSvc,*/ _router);
                    if (tableColumn.hasOwnProperty('cellRendererFramework')) {
                        delete tableColumn.cellRenderer;
                    }
                }
                if (typeof tableColumn.config !== 'undefined' && ((typeof tableColumn.config.checkbox !== 'undefined' && tableColumn.config.checkbox) ||
                    (typeof tableColumn.config.radio !== 'undefined' && tableColumn.config.radio))) {
                    colDefConfig.updatedColDef.unshift(tableColumn);
                }
                else {
                    colDefConfig.updatedColDef.push(tableColumn);
                }
            }
        }
        return colDefConfig;
    };
    KdAggridSvc.prototype.setFilterAndSortOptions = function (params) {
        var updatedOptions = params.gridOptions;
        if (params.loadType === 'server-pagination' || params.loadType === 'oneshot-pagination') {
            updatedOptions.enableServerSideFilter = true;
            updatedOptions.enableServerSideSorting = true;
            updatedOptions.paginationPageSize = params.pagesize;
        }
        else if (params.loadType === 'virtual') {
            updatedOptions.enableServerSideFilter = true;
            updatedOptions.enableServerSideSorting = true;
            updatedOptions.paginationPageSize = params.pagesize;
            updatedOptions.maxPagesInCache = 3;
            updatedOptions.maxConcurrentDatasourceRequests = 2;
            updatedOptions.overflowSize = 30;
        }
        else {
            updatedOptions.enableFilter = true;
            updatedOptions.enableSorting = true;
        }
        if (params.loadType === 'server-pagination' || params.loadType === 'oneshot-pagination') {
            updatedOptions.pagination = true;
        }
        else {
            updatedOptions.rowModelType = params.paginationType;
        }
        return updatedOptions;
    };
    KdAggridSvc.prototype.calcColWidth = function (_gridOptions) {
        var columns = _gridOptions.columnApi.getAllColumns();
        var updatedWidth = [];
        for (var i = 0; i < columns.length; i++) {
            var columnDef = columns[i].getColDef();
            var colWidth = -1;
            if (columnDef.cellClass.indexOf('ag-checkbox-radio') !== -1) {
                colWidth = 50;
                _gridOptions.columnApi.setColumnWidth(columns[i], colWidth);
            }
            else if (typeof columnDef.config !== 'undefined' && typeof columnDef.config.action !== 'undefined' && columnDef.config.action) {
                colWidth = 120;
                _gridOptions.columnApi.setColumnWidth(columns[i], colWidth);
            }
            else if (typeof columnDef.config !== 'undefined' && typeof columnDef.config.photo !== 'undefined' && columnDef.config.photo) {
                colWidth = 100;
                _gridOptions.columnApi.setColumnWidth(columns[i], colWidth);
            }
            else if (typeof columnDef.config !== 'undefined' && typeof columnDef.config.input !== 'undefined' && columnDef.config.input) {
                colWidth = 280;
            }
            else {
                colWidth = columns[i].getActualWidth() + 30;
            }
            updatedWidth.push({ width: colWidth, id: columnDef.colId });
        }
        return updatedWidth;
    };
    KdAggridSvc.prototype.colTotalWidth = function (_colArray, column) {
        var total = 0;
        for (var i = 0; i < _colArray.length; i++) {
            if (column[i].isVisible()) {
                total += _colArray[i].width;
            }
        }
        return total;
    };
    KdAggridSvc.prototype.calcUsableWidth = function (_vcr) {
        var agGridEle = _vcr.element.nativeElement.querySelector('.stg-theme');
        var parentWidth = Math.round(agGridEle.getBoundingClientRect().width);
        var computedStyle = window.getComputedStyle(agGridEle);
        var borderLeft = (computedStyle.borderLeft !== '') ? parseInt(computedStyle.borderLeft) : 0;
        var borderRight = (computedStyle.borderRight !== '') ? parseInt(computedStyle.borderRight) : 0;
        var borderLeftRight = borderLeft + borderRight;
        return parentWidth - borderLeftRight;
    };
    KdAggridSvc.prototype.calcResizeableCol = function (_columns) {
        var resizeableCol = this._resizeableCol;
        for (var i = 0; i < _columns.length; i++) {
            var colDef = _columns[i].getColDef();
            if (typeof colDef.config === 'undefined' && !_columns[i].isVisible()) {
                --resizeableCol;
            }
            // more checks to implement
        }
        return resizeableCol;
    };
    KdAggridSvc.prototype.calcGridHeightWeb = function (_gridHeight, _model, _vcr) {
        var actualHeight = 38 + 8;
        var idSouth = _vcr.element.nativeElement.querySelector('#south');
        if (idSouth !== null) {
            actualHeight += idSouth.getBoundingClientRect().height;
        }
        for (var i = 0; i < _model.getRowCount(); i++) {
            actualHeight += _model.getRow(i).rowHeight;
            if (actualHeight > _gridHeight) {
                break;
            }
        }
        if (actualHeight < _gridHeight) {
            return actualHeight;
        }
        return _gridHeight;
    };
    KdAggridSvc.prototype.calcGridHeightMobile = function (_vcr) {
        var totalHeight = 0;
        var nativeEle = _vcr.element.nativeElement;
        var headerContainer = nativeEle.querySelector('.ag-header-container');
        if (nativeEle === null || headerContainer === null)
            return totalHeight;
        totalHeight += Math.ceil(headerContainer.getBoundingClientRect().height);
        totalHeight += Math.ceil(nativeEle.querySelector('.ag-body-container').getBoundingClientRect().height);
        var paginationBottom = nativeEle.querySelector('#south');
        if (paginationBottom !== null) {
            totalHeight += Math.ceil(paginationBottom.getBoundingClientRect().height);
        }
        totalHeight += 8;
        return totalHeight;
    };
    KdAggridSvc.prototype.serverSortAndFilter = function (_data, _sortModel, _filterModel) {
        return this._serverSortData(_sortModel, this._serverFilterData(_filterModel, _data));
    };
    KdAggridSvc.prototype.checkColumnDef = function (_colDef, _hasCheckbox, _hasRadio) {
        if (_hasCheckbox) {
            _colDef['ag-checkbox'] = {
                config: {
                    checkbox: true
                }
            };
        }
        else if (_hasRadio) {
            _colDef['ag-radio'] = {
                config: {
                    radio: true
                }
            };
        }
        return _colDef;
    };
    KdAggridSvc.prototype.getActionList = function (_rowData, _column) {
        if (typeof _rowData.action !== 'undefined') {
            return _rowData.action;
        }
        for (var i = 0; i < _column.length; i++) {
            var colDef = _column[i].getColDef();
            if (typeof colDef.config !== 'undefined' &&
                typeof colDef.config.action !== 'undefined' &&
                colDef.config.action) {
                return colDef.config.items;
            }
        }
        return [];
    };
    KdAggridSvc.prototype.checkIsTargetClickable = function (_rowEvent) {
        var element = _rowEvent.target;
        var checkList = ['action-btn', 'checkbox-radio-input', 'fa-chevron-down'];
        for (var i = 0; i < checkList.length; i++) {
            if (element.classList.contains(checkList[i])) {
                return false;
            }
        }
        return true;
    };
    KdAggridSvc.prototype.checkIsConfigColumn = function (_colDef) {
        if (_colDef.cellClass.indexOf('ag-checkbox-radio') !== -1) {
            return true;
        }
        if (typeof _colDef.config !== 'undefined' &&
            ((typeof _colDef.config.photo !== 'undefined' && _colDef.config.photo) ||
                (typeof _colDef.config.action !== 'undefined' && _colDef.config.action))) {
            return true;
        }
        return false;
    };
    KdAggridSvc.prototype._setColumnConfig = function (_column, _config, /*_dataSvc: KdDataSvc,*/ _router) {
        var updatedColumn = Object.assign({}, _column);
        // if (typeof _config.input !== 'undefined' && _config.input) {
        //     updatedColumn.suppressMenu = true;
        //     updatedColumn.suppressSorting = true;
        //     updatedColumn.cellClass = 'ag-form';
        //     updatedColumn.cellRendererFramework = KdAGForm;
        // }
        // else if (typeof _config.action !== 'undefined' && _config.action) {
        //     updatedColumn.suppressMenu = true;
        //     updatedColumn.suppressSorting = true;
        //     updatedColumn.suppressSizeToFit = true;
        //     updatedColumn.width = 120;
        //     updatedColumn.cellClass = 'dropdown-action';
        //     updatedColumn.cellRendererFramework = KdAGDropdown;
        //     this._resizeableCol--;
        // }
        // else if (typeof _config.photo !== 'undefined' && _config.photo) {
        //     updatedColumn.suppressMenu = true;
        //     updatedColumn.suppressSorting = true;
        //     updatedColumn.suppressSizeToFit = true;
        //     updatedColumn.width = 100;
        //     updatedColumn.cellClass = 'ag-photo';
        //     updatedColumn.cellRendererFramework = KdAGPhoto;
        //     this._resizeableCol--;
        // }
        // else if (typeof _config.checkbox !== 'undefined' && _config.checkbox) {
        //     updatedColumn.suppressMenu = true;
        //     updatedColumn.suppressSorting = true;
        //     updatedColumn.suppressSizeToFit = true;
        //     updatedColumn.width = 50;
        //     updatedColumn.cellClass = 'ag-default ag-checkbox-radio';
        //     updatedColumn.colId = 'checkbox';
        //     updatedColumn.cellRendererFramework = KdAGCheckboxRadio;
        //     updatedColumn.headerComponentFramework = KdAGCheckboxRadio;
        //     this._resizeableCol--;
        // }
        // else if (typeof _config.radio !== 'undefined' && _config.radio) {
        //     updatedColumn.suppressMenu = true;
        //     updatedColumn.suppressSorting = true;
        //     updatedColumn.suppressSizeToFit = true;
        //     updatedColumn.width = 50;
        //     updatedColumn.cellClass = 'ag-default ag-checkbox-radio';
        //     updatedColumn.colId = 'radio';
        //     updatedColumn.cellRendererFramework = KdAGCheckboxRadio;
        //     updatedColumn.headerName = '';
        //     this._resizeableCol--;
        // }
        // else if (typeof _config.displayFrom !== 'undefined' && _config.displayFrom) {
        // updatedColumn.cellRenderer = (params: any): any => {
        //     if (typeof params.value !== 'undefined') {
        //         if (params.value instanceof Array) {
        //             let displayArray: Array<any> = [];
        //             for (let i: number = 0; i < params.value.length; i++) {
        //                 let display: any = this._dataSvc.getDataValue(params.value[i], _config.displayFrom);
        //                 if (display !== null) displayArray.push(display);
        //             }
        //             return displayArray;
        //         }
        //         else {
        //             let display: any = this._dataSvc.getDataValue(params.value, _config.displayFrom);
        //             if (display !== null) return display;
        //         }
        //     }
        //     return params.value;
        // }
        // }
        return updatedColumn;
    };
    KdAggridSvc.prototype._serverFilterData = function (_filterModel, _data) {
        var filteredData = _data.slice();
        if (typeof _filterModel === 'undefined' || Object.keys(_filterModel).length === 0) {
            return filteredData;
        }
        var updatedData = [];
        for (var key in _filterModel) {
            if (_filterModel.hasOwnProperty(key)) {
                for (var k = 0; k < _filterModel[key].length; k++) {
                    for (var j = 0; j < _data.length; j++) {
                        if (_data[j][key] === _filterModel[key][k]) {
                            updatedData.push(_data[j]);
                        }
                    }
                }
            }
        }
        return updatedData;
    };
    KdAggridSvc.prototype._serverSortData = function (_sortModel, _data) {
        var sortedData = _data.slice();
        if (typeof _sortModel === 'undefined' || _sortModel.length === 0) {
            return sortedData;
        }
        sortedData.sort(function (a, b) {
            for (var i = 0; i < _sortModel.length; i++) {
                var sortColModel = _sortModel[i];
                var valA = a[sortColModel.colId];
                var valB = b[sortColModel.colId];
                if (valA === valB) {
                    continue;
                }
                var direction = (sortColModel.sort === 'asc') ? 1 : -1;
                if (valA > valB) {
                    return direction;
                }
                else {
                    return direction * -1;
                }
            }
            return 0;
        });
        return sortedData;
    };
    KdAggridSvc.prototype._checkGridHeight = function (_config) {
        var defaultHeight = 600;
        if (typeof _config === 'undefined') {
            return defaultHeight;
        }
        else if (typeof _config.gridHeight !== 'undefined' &&
            typeof _config.gridHeight === 'string' &&
            _config.gridHeight === 'auto') {
            return _config.gridHeight;
        }
        else if (typeof _config.gridHeight !== 'undefined' &&
            typeof _config.gridHeight === 'number') {
            return _config.gridHeight;
        }
        return defaultHeight;
    };
    // private _checkPaginationData(_config: any, _loadType: string): any {
    //     if (typeof _config !== 'undefined' &&
    //         typeof _config.paginationSetData !== 'undefined' &&
    //         _loadType === 'server-pagination') {
    //             return _config.paginationSetData;
    //     }
    //     else if (typeof _config !== 'undefined' &&
    //         typeof _config.paginationSetData === 'undefined' &&
    //         _loadType === 'server-pagination') {
    //             console.error('Server pagination requires callback to retrieve data. Please provide the callback function.');
    //     }
    //     return undefined;
    // }
    KdAggridSvc.prototype._checkPaginationType = function (_loadType) {
        if (_loadType === 'infinite')
            return 'infinite';
        if (_loadType === 'server-pagination' || _loadType === 'oneshot-pagination')
            return 'pagination';
        return '';
    };
    KdAggridSvc.prototype._checkLoadType = function (_config) {
        var defaultLoadType = 'normal';
        if (typeof _config === 'undefined' || typeof _config.loadType === 'undefined') {
            return defaultLoadType;
        }
        if (_config.loadType === 'normal' ||
            _config.loadType === 'server-pagination' ||
            _config.loadType === 'virtual' ||
            _config.loadType === 'oneshot-pagination') {
            return _config.loadType;
        }
        return defaultLoadType;
    };
    KdAggridSvc.prototype._checkPagesize = function (_config, _loadType) {
        if (_loadType === 'normal')
            return -1;
        if (typeof _config !== 'undefined' && typeof _config.pagesize !== 'undefined')
            return _config.pagesize;
        return 25;
    };
    KdAggridSvc.prototype._getRowHeight = function (_params) {
        var gridOptions = this;
        var colDef = gridOptions.columnDefs;
        var rowHeight = 50;
        for (var i = 0; i < colDef.length; i++) {
            if (typeof colDef[i].config !== 'undefined') {
                if (typeof colDef[i].config.photo !== 'undefined' && colDef[i].config.photo)
                    return 120;
                else if (typeof colDef[i].config.textarea !== 'undefined' && colDef[i].config.textarea)
                    return 120;
                else if (typeof colDef[i].config.input !== 'undefined' && colDef[i].config.input) {
                    if (_params.data[colDef[i].colId] instanceof Array)
                        return rowHeight * _params.data[colDef[i].colId].length;
                }
            }
        }
        return 50;
    };
    KdAggridSvc.prototype._checkBtnConfig = function (_buttonList) {
        var updatedBtnConfig = [];
        for (var i = 0; i < _buttonList.length; i++) {
            updatedBtnConfig.push(this._checkButton(_buttonList[i]));
        }
        return updatedBtnConfig;
    };
    KdAggridSvc.prototype._checkButton = function (_buttonItem) {
        var defaultButton = {
            type: null,
            label: '',
            icon: '',
            config: null,
            callback: null,
            path: null
        };
        return Object.assign(defaultButton, _buttonItem);
    };
    KdAggridSvc = __decorate([
        Injectable()
    ], KdAggridSvc);
    return KdAggridSvc;
}());
export { KdAggridSvc };
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoia2QtYW5ndWxhci1hZ2dyaWQtc3ZjLmpzIiwic291cmNlUm9vdCI6Im5nOi8vb3BlbmVtaXMtc3R5bGVndWlkZS1saWIvIiwic291cmNlcyI6WyJrZC1jb21wb25lbnRzL2tkLWFuZ3VsYXItYWdncmlkL3NyYy9rZC1hbmd1bGFyLWFnZ3JpZC1zdmMudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IjtBQUFBLE9BQU8sRUFBRSxVQUFVLEVBQW9CLE1BQU0sZUFBZSxDQUFDO0FBRzdELFdBQVc7QUFDWCxvQkFBb0I7QUFDcEIsaUJBQWlCO0FBQ2pCLGdCQUFnQjtBQUNoQix3QkFBd0I7QUFDeEIsc0RBQXNEO0FBR3REO0lBQUE7UUFDWSxtQkFBYyxHQUFXLENBQUMsQ0FBQztJQXFqQnZDLENBQUM7SUFwakJHLGlEQUFpRDtJQUVqRCxvQ0FBYyxHQUFkO1FBQ0ksSUFBSSxPQUFPLEdBQVE7WUFDZixPQUFPLEVBQUUsRUFBRTtZQUNYLFVBQVUsRUFBRSxFQUFFO1lBQ2QsZUFBZTtZQUNmLFlBQVksRUFBRSxFQUFFO1lBQ2hCLFlBQVksRUFBRSxJQUFJLENBQUMsYUFBYTtZQUNoQyxxQkFBcUI7WUFDckIsZ0JBQWdCO1lBQ2hCLG1CQUFtQixFQUFFLElBQUk7WUFDekIsK0JBQStCO1lBQy9CLGlDQUFpQztZQUNqQyxzQkFBc0IsRUFBRSxJQUFJO1lBQzVCLGdCQUFnQixFQUFFLElBQUk7WUFDdEIsNEJBQTRCLEVBQUUsSUFBSTtZQUNsQyxVQUFVLEVBQUUsSUFBSTtZQUNoQixLQUFLLEVBQUU7Z0JBQ0gsTUFBTSxFQUFFLDJCQUEyQjtnQkFDbkMsYUFBYSxFQUFFLCtCQUErQjtnQkFDOUMsY0FBYyxFQUFFLDZCQUE2QjtnQkFDN0MsVUFBVSxFQUFFLHlCQUF5QjtnQkFDckMsYUFBYSxFQUFFLGlDQUFpQztnQkFDaEQsZUFBZSxFQUFFLGdDQUFnQzthQUNwRDtZQUNELHFCQUFxQixFQUFFLHNIQUFzSDtTQUNoSixDQUFDO1FBQ0YsT0FBTyxPQUFPLENBQUM7SUFDbkIsQ0FBQztJQUVELCtCQUFTLEdBQVQsVUFBVSxPQUFZO1FBQ2xCLElBQUksWUFBWSxHQUFRLEVBQUUsQ0FBQztRQUMzQixZQUFZLENBQUMsRUFBRSxHQUFHLENBQUMsT0FBTyxPQUFPLEtBQUssV0FBVyxJQUFJLE9BQU8sT0FBTyxDQUFDLEVBQUUsS0FBSyxXQUFXLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDO1FBQ2pILFlBQVksQ0FBQyxVQUFVLEdBQUcsSUFBSSxDQUFDLGdCQUFnQixDQUFDLE9BQU8sQ0FBQyxDQUFDO1FBQ3pELFlBQVksQ0FBQyxRQUFRLEdBQUcsQ0FBQyxPQUFPLE9BQU8sS0FBSyxXQUFXLElBQUksT0FBTyxPQUFPLENBQUMsUUFBUSxLQUFLLFdBQVcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUM7UUFDL0gsWUFBWSxDQUFDLEtBQUssR0FBRyxDQUFDLE9BQU8sT0FBTyxLQUFLLFdBQVcsSUFBSSxPQUFPLE9BQU8sQ0FBQyxLQUFLLEtBQUssV0FBVyxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQztRQUN0SCxZQUFZLENBQUMsY0FBYyxHQUFHLENBQUMsT0FBTyxPQUFPLEtBQUssV0FBVyxJQUFJLE9BQU8sT0FBTyxDQUFDLGNBQWMsS0FBSyxXQUFXLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLGNBQWMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDO1FBQ2pKLFlBQVksQ0FBQyxRQUFRLEdBQUcsSUFBSSxDQUFDLGNBQWMsQ0FBQyxPQUFPLENBQUMsQ0FBQztRQUNyRCxZQUFZLENBQUMsY0FBYyxHQUFHLElBQUksQ0FBQyxvQkFBb0IsQ0FBQyxZQUFZLENBQUMsUUFBUSxDQUFDLENBQUM7UUFDL0UsWUFBWSxDQUFDLFFBQVEsR0FBRyxJQUFJLENBQUMsY0FBYyxDQUFDLE9BQU8sRUFBRSxZQUFZLENBQUMsUUFBUSxDQUFDLENBQUM7UUFDNUUsWUFBWSxDQUFDLFNBQVMsR0FBRyxDQUFDLE9BQU8sT0FBTyxLQUFLLFdBQVcsSUFBSSxPQUFPLE9BQU8sQ0FBQyxTQUFTLEtBQUssV0FBVyxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO1FBQy9ILFlBQVksQ0FBQyxNQUFNLEdBQUcsQ0FBQyxPQUFPLE9BQU8sS0FBSyxXQUFXLElBQUksT0FBTyxPQUFPLENBQUMsTUFBTSxLQUFLLFdBQVcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUM7UUFDekgsWUFBWSxDQUFDLFlBQVksR0FBRyxDQUFDLE9BQU8sT0FBTyxLQUFLLFdBQVcsSUFBSSxPQUFPLE9BQU8sQ0FBQyxZQUFZLEtBQUssV0FBVyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxlQUFlLENBQUMsT0FBTyxDQUFDLFlBQVksQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUM7UUFDaEssWUFBWSxDQUFDLFNBQVMsR0FBRyxDQUFDLE9BQU8sT0FBTyxLQUFLLFdBQVcsSUFBSSxPQUFPLE9BQU8sQ0FBQyxTQUFTLEtBQUssV0FBVyxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQztRQUNySSxZQUFZLENBQUMsb0JBQW9CLEdBQUcsQ0FBQyxPQUFPLE9BQU8sS0FBSyxXQUFXLElBQUksT0FBTyxPQUFPLENBQUMsb0JBQW9CLEtBQUssV0FBVyxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxvQkFBb0IsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDO1FBQ2xLLFlBQVksQ0FBQyxZQUFZLEdBQUcsQ0FBQyxPQUFPLE9BQU8sS0FBSyxXQUFXLElBQUksT0FBTyxPQUFPLENBQUMsWUFBWSxLQUFLLFdBQVcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsWUFBWSxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUM7UUFDM0ksWUFBWSxDQUFDLGdCQUFnQixHQUFHLENBQUMsT0FBTyxPQUFPLEtBQUssV0FBVyxJQUFJLE9BQU8sT0FBTyxDQUFDLGdCQUFnQixLQUFLLFdBQVcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsZ0JBQWdCLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQztRQUV0SixJQUFJLFlBQVksQ0FBQyxLQUFLLElBQUksWUFBWSxDQUFDLFFBQVE7WUFBRSxZQUFZLENBQUMsS0FBSyxHQUFHLEtBQUssQ0FBQztRQUM1RSxPQUFPLFlBQVksQ0FBQztJQUN4QixDQUFDO0lBRUQsa0NBQVksR0FBWixVQUFhLFFBQW9CO1FBQzdCLElBQUksU0FBUyxHQUFlLENBQUMsT0FBTyxRQUFRLEtBQUssV0FBVyxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDO1FBQzlFLE9BQU8sU0FBUyxDQUFDO0lBQ3JCLENBQUM7SUFFRCxnQ0FBVSxHQUFWLFVBQVcsT0FBWSxFQUFFLFlBQXlCLEVBQUUseUJBQXlCLENBQUEsT0FBZ0IsRUFBRSxZQUE2QjtRQUE3Qiw2QkFBQSxFQUFBLG9CQUE2QjtRQUN4SCxJQUFJLFlBQVksR0FBUSxFQUFFLFFBQVEsRUFBRSxLQUFLLEVBQUUsYUFBYSxFQUFFLEVBQUUsRUFBRSxDQUFDO1FBQy9ELElBQUksV0FBVyxHQUFRLEVBQUUsQ0FBQztRQUUxQixLQUFLLElBQUksR0FBRyxJQUFJLE9BQU8sRUFBRTtZQUNyQixJQUFJLE9BQU8sQ0FBQyxjQUFjLENBQUMsR0FBRyxDQUFDLEVBQUU7Z0JBQzdCLElBQUksQ0FBQyxjQUFjLEVBQUUsQ0FBQztnQkFFdEIsV0FBVyxHQUFHO29CQUNWLFVBQVUsRUFBRSxPQUFPLENBQUMsR0FBRyxDQUFDLENBQUMsVUFBVTtvQkFDbkMsS0FBSyxFQUFFLENBQUMsT0FBTyxPQUFPLENBQUMsR0FBRyxDQUFDLENBQUMsTUFBTSxLQUFLLFdBQVcsSUFBSSxPQUFPLE9BQU8sQ0FBQyxHQUFHLENBQUMsQ0FBQyxNQUFNLENBQUMsR0FBRyxLQUFLLFdBQVcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsR0FBRztvQkFDckksUUFBUSxFQUFFLEtBQUs7b0JBQ2YsWUFBWSxFQUFFLENBQUMsT0FBTyxPQUFPLENBQUMsR0FBRyxDQUFDLENBQUMsVUFBVSxLQUFLLFdBQVcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsQ0FBQyxVQUFVLENBQUMsQ0FBQyxDQUFDLElBQUk7b0JBQ2hHLGVBQWUsRUFBRSxDQUFDLE9BQU8sT0FBTyxDQUFDLEdBQUcsQ0FBQyxDQUFDLFFBQVEsS0FBSyxXQUFXLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxJQUFJO29CQUMvRixLQUFLLEVBQUUsR0FBRztvQkFDVixNQUFNLEVBQUUsQ0FBQyxPQUFPLE9BQU8sQ0FBQyxHQUFHLENBQUMsQ0FBQyxNQUFNLEtBQUssV0FBVyxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLFNBQVM7b0JBQ3RGLHlDQUF5QztvQkFDekMsK0NBQStDO29CQUMvQywyQ0FBMkM7b0JBQzNDLFFBQVE7b0JBQ1IsaURBQWlEO29CQUNqRCx5Q0FBeUM7b0JBQ3pDLFFBQVE7b0JBQ1IsNEJBQTRCO29CQUM1QixLQUFLO29CQUNMLElBQUksRUFBRSxDQUFDLE9BQU8sT0FBTyxDQUFDLEdBQUcsQ0FBQyxDQUFDLE9BQU8sS0FBSyxXQUFXLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSztvQkFDckYsU0FBUyxFQUFFLFlBQVk7aUJBQzFCLENBQUM7Z0JBRUYsSUFBSSxDQUFDLFdBQVcsQ0FBQyxZQUFZLEVBQUU7b0JBQzNCLFdBQVcsQ0FBQyxVQUFVLENBQUMsR0FBRyxDQUFDLGVBQWUsQ0FBQyxDQUFDO29CQUM1QyxXQUFXLENBQUMsWUFBWSxHQUFHO3dCQUN2QixhQUFhLEVBQUUsTUFBTTt3QkFDckIsVUFBVSxFQUFFLEVBQUU7d0JBQ2QscUJBQXFCLEVBQUUsSUFBSTt3QkFDM0IsTUFBTSxFQUFFLENBQUMsT0FBTyxPQUFPLENBQUMsR0FBRyxDQUFDLENBQUMsU0FBUyxLQUFLLFdBQVcsSUFBSSxPQUFPLENBQUMsR0FBRyxDQUFDLENBQUMsU0FBUyxDQUFDLE1BQU0sR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsU0FBUztxQkFDcEksQ0FBQztpQkFDTDtnQkFFRCxJQUFJLE9BQU8sT0FBTyxDQUFDLEdBQUcsQ0FBQyxDQUFDLE1BQU0sS0FBSyxXQUFXLEVBQUU7b0JBQzVDLElBQUksT0FBTyxPQUFPLENBQUMsR0FBRyxDQUFDLENBQUMsTUFBTSxDQUFDLEtBQUssS0FBSyxXQUFXLElBQUksT0FBTyxDQUFDLEdBQUcsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxLQUFLLEVBQUU7d0JBQy9FLFlBQVksQ0FBQyxRQUFRLEdBQUcsSUFBSSxDQUFDO3FCQUNoQztvQkFFRCxXQUFXLEdBQUcsSUFBSSxDQUFDLGdCQUFnQixDQUFDLFdBQVcsRUFBRSxPQUFPLENBQUMsR0FBRyxDQUFDLENBQUMsTUFBTSxFQUFFLGFBQWEsQ0FBQyxPQUFPLENBQUMsQ0FBQztvQkFFN0YsSUFBSSxXQUFXLENBQUMsY0FBYyxDQUFDLHVCQUF1QixDQUFDLEVBQUU7d0JBQ3JELE9BQU8sV0FBVyxDQUFDLFlBQVksQ0FBQztxQkFDbkM7aUJBQ0o7Z0JBRUQsSUFBSSxPQUFPLFdBQVcsQ0FBQyxNQUFNLEtBQUssV0FBVyxJQUFJLENBQzdDLENBQUMsT0FBTyxXQUFXLENBQUMsTUFBTSxDQUFDLFFBQVEsS0FBSyxXQUFXLElBQUksV0FBVyxDQUFDLE1BQU0sQ0FBQyxRQUFRLENBQUM7b0JBQ25GLENBQUMsT0FBTyxXQUFXLENBQUMsTUFBTSxDQUFDLEtBQUssS0FBSyxXQUFXLElBQUksV0FBVyxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsQ0FBQyxFQUFFO29CQUM1RSxZQUFZLENBQUMsYUFBYSxDQUFDLE9BQU8sQ0FBQyxXQUFXLENBQUMsQ0FBQztpQkFDdkQ7cUJBQ0k7b0JBQ0QsWUFBWSxDQUFDLGFBQWEsQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFDLENBQUM7aUJBQ2hEO2FBQ0o7U0FDSjtRQUVELE9BQU8sWUFBWSxDQUFDO0lBQ3hCLENBQUM7SUFFRCw2Q0FBdUIsR0FBdkIsVUFBd0IsTUFBVztRQUMvQixJQUFJLGNBQWMsR0FBRyxNQUFNLENBQUMsV0FBVyxDQUFDO1FBRXhDLElBQUksTUFBTSxDQUFDLFFBQVEsS0FBSyxtQkFBbUIsSUFBSSxNQUFNLENBQUMsUUFBUSxLQUFLLG9CQUFvQixFQUFFO1lBQ3JGLGNBQWMsQ0FBQyxzQkFBc0IsR0FBRyxJQUFJLENBQUM7WUFDN0MsY0FBYyxDQUFDLHVCQUF1QixHQUFHLElBQUksQ0FBQztZQUM5QyxjQUFjLENBQUMsa0JBQWtCLEdBQUcsTUFBTSxDQUFDLFFBQVEsQ0FBQztTQUN2RDthQUNJLElBQUksTUFBTSxDQUFDLFFBQVEsS0FBSyxTQUFTLEVBQUU7WUFDcEMsY0FBYyxDQUFDLHNCQUFzQixHQUFHLElBQUksQ0FBQztZQUM3QyxjQUFjLENBQUMsdUJBQXVCLEdBQUcsSUFBSSxDQUFDO1lBQzlDLGNBQWMsQ0FBQyxrQkFBa0IsR0FBRyxNQUFNLENBQUMsUUFBUSxDQUFDO1lBQ3BELGNBQWMsQ0FBQyxlQUFlLEdBQUcsQ0FBQyxDQUFDO1lBQ25DLGNBQWMsQ0FBQywrQkFBK0IsR0FBRyxDQUFDLENBQUM7WUFDbkQsY0FBYyxDQUFDLFlBQVksR0FBRyxFQUFFLENBQUM7U0FDcEM7YUFDSTtZQUNELGNBQWMsQ0FBQyxZQUFZLEdBQUcsSUFBSSxDQUFDO1lBQ25DLGNBQWMsQ0FBQyxhQUFhLEdBQUcsSUFBSSxDQUFDO1NBQ3ZDO1FBRUQsSUFBSSxNQUFNLENBQUMsUUFBUSxLQUFLLG1CQUFtQixJQUFJLE1BQU0sQ0FBQyxRQUFRLEtBQUssb0JBQW9CLEVBQUU7WUFDckYsY0FBYyxDQUFDLFVBQVUsR0FBRyxJQUFJLENBQUM7U0FDcEM7YUFDSTtZQUNELGNBQWMsQ0FBQyxZQUFZLEdBQUcsTUFBTSxDQUFDLGNBQWMsQ0FBQztTQUN2RDtRQUVELE9BQU8sY0FBYyxDQUFDO0lBQzFCLENBQUM7SUFFRCxrQ0FBWSxHQUFaLFVBQWEsWUFBeUI7UUFDbEMsSUFBSSxPQUFPLEdBQWtCLFlBQVksQ0FBQyxTQUFTLENBQUMsYUFBYSxFQUFFLENBQUM7UUFDcEUsSUFBSSxZQUFZLEdBQXVDLEVBQUUsQ0FBQztRQUUxRCxLQUFLLElBQUksQ0FBQyxHQUFXLENBQUMsRUFBRSxDQUFDLEdBQUcsT0FBTyxDQUFDLE1BQU0sRUFBRSxDQUFDLEVBQUUsRUFBRTtZQUM3QyxJQUFJLFNBQVMsR0FBUSxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsU0FBUyxFQUFFLENBQUM7WUFDNUMsSUFBSSxRQUFRLEdBQVcsQ0FBQyxDQUFDLENBQUM7WUFFMUIsSUFBSSxTQUFTLENBQUMsU0FBUyxDQUFDLE9BQU8sQ0FBQyxtQkFBbUIsQ0FBQyxLQUFLLENBQUMsQ0FBQyxFQUFFO2dCQUN6RCxRQUFRLEdBQUcsRUFBRSxDQUFDO2dCQUNkLFlBQVksQ0FBQyxTQUFTLENBQUMsY0FBYyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsRUFBRSxRQUFRLENBQUMsQ0FBQzthQUMvRDtpQkFDSSxJQUFJLE9BQU8sU0FBUyxDQUFDLE1BQU0sS0FBSyxXQUFXLElBQUksT0FBTyxTQUFTLENBQUMsTUFBTSxDQUFDLE1BQU0sS0FBSyxXQUFXLElBQUksU0FBUyxDQUFDLE1BQU0sQ0FBQyxNQUFNLEVBQUU7Z0JBQzNILFFBQVEsR0FBRyxHQUFHLENBQUM7Z0JBQ2YsWUFBWSxDQUFDLFNBQVMsQ0FBQyxjQUFjLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxFQUFFLFFBQVEsQ0FBQyxDQUFDO2FBQy9EO2lCQUNJLElBQUksT0FBTyxTQUFTLENBQUMsTUFBTSxLQUFLLFdBQVcsSUFBSSxPQUFPLFNBQVMsQ0FBQyxNQUFNLENBQUMsS0FBSyxLQUFLLFdBQVcsSUFBSSxTQUFTLENBQUMsTUFBTSxDQUFDLEtBQUssRUFBRTtnQkFDekgsUUFBUSxHQUFHLEdBQUcsQ0FBQztnQkFDZixZQUFZLENBQUMsU0FBUyxDQUFDLGNBQWMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLEVBQUUsUUFBUSxDQUFDLENBQUM7YUFDL0Q7aUJBQ0ksSUFBSSxPQUFPLFNBQVMsQ0FBQyxNQUFNLEtBQUssV0FBVyxJQUFJLE9BQU8sU0FBUyxDQUFDLE1BQU0sQ0FBQyxLQUFLLEtBQUssV0FBVyxJQUFJLFNBQVMsQ0FBQyxNQUFNLENBQUMsS0FBSyxFQUFFO2dCQUN6SCxRQUFRLEdBQUcsR0FBRyxDQUFDO2FBQ2xCO2lCQUNJO2dCQUNELFFBQVEsR0FBRyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsY0FBYyxFQUFFLEdBQUcsRUFBRSxDQUFDO2FBQy9DO1lBRUQsWUFBWSxDQUFDLElBQUksQ0FBQyxFQUFDLEtBQUssRUFBRSxRQUFRLEVBQUUsRUFBRSxFQUFFLFNBQVMsQ0FBQyxLQUFLLEVBQUMsQ0FBQyxDQUFDO1NBQzdEO1FBRUQsT0FBTyxZQUFZLENBQUM7SUFDeEIsQ0FBQztJQUVELG1DQUFhLEdBQWIsVUFBYyxTQUE2QyxFQUFFLE1BQXFCO1FBQzlFLElBQUksS0FBSyxHQUFXLENBQUMsQ0FBQztRQUN0QixLQUFLLElBQUksQ0FBQyxHQUFXLENBQUMsRUFBRSxDQUFDLEdBQUcsU0FBUyxDQUFDLE1BQU0sRUFBRSxDQUFDLEVBQUUsRUFBRTtZQUMvQyxJQUFJLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxTQUFTLEVBQUUsRUFBRTtnQkFDdkIsS0FBSyxJQUFJLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUM7YUFDL0I7U0FDSjtRQUVELE9BQU8sS0FBSyxDQUFDO0lBQ2pCLENBQUM7SUFFRCxxQ0FBZSxHQUFmLFVBQWdCLElBQXNCO1FBQ2xDLElBQUksU0FBUyxHQUFnQixJQUFJLENBQUMsT0FBTyxDQUFDLGFBQWEsQ0FBQyxhQUFhLENBQUMsWUFBWSxDQUFDLENBQUM7UUFDcEYsSUFBSSxXQUFXLEdBQVcsSUFBSSxDQUFDLEtBQUssQ0FBQyxTQUFTLENBQUMscUJBQXFCLEVBQUUsQ0FBQyxLQUFLLENBQUMsQ0FBQztRQUM5RSxJQUFJLGFBQWEsR0FBd0IsTUFBTSxDQUFDLGdCQUFnQixDQUFDLFNBQVMsQ0FBQyxDQUFDO1FBQzVFLElBQUksVUFBVSxHQUFXLENBQUMsYUFBYSxDQUFDLFVBQVUsS0FBSyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLGFBQWEsQ0FBQyxVQUFVLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO1FBQ3BHLElBQUksV0FBVyxHQUFXLENBQUMsYUFBYSxDQUFDLFdBQVcsS0FBSyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLGFBQWEsQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO1FBQ3ZHLElBQUksZUFBZSxHQUFHLFVBQVUsR0FBRyxXQUFXLENBQUM7UUFDL0MsT0FBTyxXQUFXLEdBQUcsZUFBZSxDQUFDO0lBQ3pDLENBQUM7SUFFRCx1Q0FBaUIsR0FBakIsVUFBa0IsUUFBdUI7UUFDckMsSUFBSSxhQUFhLEdBQVcsSUFBSSxDQUFDLGNBQWMsQ0FBQztRQUVoRCxLQUFLLElBQUksQ0FBQyxHQUFXLENBQUMsRUFBRSxDQUFDLEdBQUcsUUFBUSxDQUFDLE1BQU0sRUFBRSxDQUFDLEVBQUUsRUFBRTtZQUM5QyxJQUFJLE1BQU0sR0FBUSxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsU0FBUyxFQUFFLENBQUM7WUFFMUMsSUFBSSxPQUFPLE1BQU0sQ0FBQyxNQUFNLEtBQUssV0FBVyxJQUFJLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLFNBQVMsRUFBRSxFQUFFO2dCQUNsRSxFQUFFLGFBQWEsQ0FBQzthQUNuQjtZQUVELDJCQUEyQjtTQUM5QjtRQUVELE9BQU8sYUFBYSxDQUFDO0lBQ3pCLENBQUM7SUFFRCx1Q0FBaUIsR0FBakIsVUFBa0IsV0FBZ0IsRUFBRSxNQUFpQixFQUFFLElBQXNCO1FBQ3pFLElBQUksWUFBWSxHQUFXLEVBQUUsR0FBRyxDQUFDLENBQUM7UUFDbEMsSUFBSSxPQUFPLEdBQVksSUFBSSxDQUFDLE9BQU8sQ0FBQyxhQUFhLENBQUMsYUFBYSxDQUFDLFFBQVEsQ0FBQyxDQUFDO1FBRTFFLElBQUksT0FBTyxLQUFLLElBQUksRUFBRTtZQUNsQixZQUFZLElBQUksT0FBTyxDQUFDLHFCQUFxQixFQUFFLENBQUMsTUFBTSxDQUFDO1NBQzFEO1FBRUQsS0FBSyxJQUFJLENBQUMsR0FBVyxDQUFDLEVBQUUsQ0FBQyxHQUFHLE1BQU0sQ0FBQyxXQUFXLEVBQUUsRUFBRSxDQUFDLEVBQUUsRUFBRTtZQUNuRCxZQUFZLElBQUksTUFBTSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUM7WUFDM0MsSUFBSSxZQUFZLEdBQUcsV0FBVyxFQUFFO2dCQUM1QixNQUFNO2FBQ1Q7U0FDSjtRQUVELElBQUksWUFBWSxHQUFHLFdBQVcsRUFBRTtZQUM1QixPQUFPLFlBQVksQ0FBQztTQUN2QjtRQUVELE9BQU8sV0FBVyxDQUFDO0lBQ3ZCLENBQUM7SUFFRCwwQ0FBb0IsR0FBcEIsVUFBcUIsSUFBc0I7UUFDdkMsSUFBSSxXQUFXLEdBQVcsQ0FBQyxDQUFDO1FBQzVCLElBQUksU0FBUyxHQUFZLElBQUksQ0FBQyxPQUFPLENBQUMsYUFBYSxDQUFDO1FBQ3BELElBQUksZUFBZSxHQUFZLFNBQVMsQ0FBQyxhQUFhLENBQUMsc0JBQXNCLENBQUMsQ0FBQztRQUMvRSxJQUFJLFNBQVMsS0FBSyxJQUFJLElBQUksZUFBZSxLQUFLLElBQUk7WUFBRSxPQUFPLFdBQVcsQ0FBQztRQUN2RSxXQUFXLElBQUksSUFBSSxDQUFDLElBQUksQ0FBQyxlQUFlLENBQUMscUJBQXFCLEVBQUUsQ0FBQyxNQUFNLENBQUMsQ0FBQztRQUN6RSxXQUFXLElBQUksSUFBSSxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsYUFBYSxDQUFDLG9CQUFvQixDQUFDLENBQUMscUJBQXFCLEVBQUUsQ0FBQyxNQUFNLENBQUMsQ0FBQztRQUV2RyxJQUFJLGdCQUFnQixHQUFZLFNBQVMsQ0FBQyxhQUFhLENBQUMsUUFBUSxDQUFDLENBQUM7UUFDbEUsSUFBSSxnQkFBZ0IsS0FBSyxJQUFJLEVBQUU7WUFDM0IsV0FBVyxJQUFJLElBQUksQ0FBQyxJQUFJLENBQUMsZ0JBQWdCLENBQUMscUJBQXFCLEVBQUUsQ0FBQyxNQUFNLENBQUMsQ0FBQztTQUM3RTtRQUNELFdBQVcsSUFBSSxDQUFDLENBQUM7UUFDakIsT0FBTyxXQUFXLENBQUM7SUFDdkIsQ0FBQztJQUVELHlDQUFtQixHQUFuQixVQUFvQixLQUFpQixFQUFFLFVBQXNCLEVBQUUsWUFBaUI7UUFDNUUsT0FBTyxJQUFJLENBQUMsZUFBZSxDQUFDLFVBQVUsRUFBRSxJQUFJLENBQUMsaUJBQWlCLENBQUMsWUFBWSxFQUFFLEtBQUssQ0FBQyxDQUFDLENBQUM7SUFDekYsQ0FBQztJQUVELG9DQUFjLEdBQWQsVUFBZSxPQUFZLEVBQUUsWUFBcUIsRUFBRSxTQUFrQjtRQUNsRSxJQUFJLFlBQVksRUFBRTtZQUNkLE9BQU8sQ0FBQyxhQUFhLENBQUMsR0FBRztnQkFDckIsTUFBTSxFQUFFO29CQUNKLFFBQVEsRUFBRSxJQUFJO2lCQUNqQjthQUNKLENBQUM7U0FDTDthQUNJLElBQUksU0FBUyxFQUFFO1lBQ2hCLE9BQU8sQ0FBQyxVQUFVLENBQUMsR0FBRztnQkFDbEIsTUFBTSxFQUFFO29CQUNKLEtBQUssRUFBRSxJQUFJO2lCQUNkO2FBQ0osQ0FBQztTQUNMO1FBRUQsT0FBTyxPQUFPLENBQUM7SUFDbkIsQ0FBQztJQUVELG1DQUFhLEdBQWIsVUFBYyxRQUFhLEVBQUUsT0FBc0I7UUFDL0MsSUFBSSxPQUFPLFFBQVEsQ0FBQyxNQUFNLEtBQUssV0FBVyxFQUFFO1lBQ3hDLE9BQU8sUUFBUSxDQUFDLE1BQU0sQ0FBQztTQUMxQjtRQUVELEtBQUssSUFBSSxDQUFDLEdBQVcsQ0FBQyxFQUFFLENBQUMsR0FBRyxPQUFPLENBQUMsTUFBTSxFQUFFLENBQUMsRUFBRSxFQUFFO1lBQzdDLElBQUksTUFBTSxHQUFRLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxTQUFTLEVBQUUsQ0FBQztZQUN6QyxJQUFJLE9BQU8sTUFBTSxDQUFDLE1BQU0sS0FBSyxXQUFXO2dCQUNwQyxPQUFPLE1BQU0sQ0FBQyxNQUFNLENBQUMsTUFBTSxLQUFLLFdBQVc7Z0JBQzNDLE1BQU0sQ0FBQyxNQUFNLENBQUMsTUFBTSxFQUFFO2dCQUNsQixPQUFPLE1BQU0sQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDO2FBQ2xDO1NBQ0o7UUFDRCxPQUFPLEVBQUUsQ0FBQztJQUNkLENBQUM7SUFFRCw0Q0FBc0IsR0FBdEIsVUFBdUIsU0FBZ0I7UUFDbkMsSUFBSSxPQUFPLEdBQTZCLFNBQVMsQ0FBQyxNQUFNLENBQUM7UUFDekQsSUFBSSxTQUFTLEdBQWtCLENBQUMsWUFBWSxFQUFFLHNCQUFzQixFQUFFLGlCQUFpQixDQUFDLENBQUM7UUFFekYsS0FBSyxJQUFJLENBQUMsR0FBVyxDQUFDLEVBQUUsQ0FBQyxHQUFHLFNBQVMsQ0FBQyxNQUFNLEVBQUUsQ0FBQyxFQUFFLEVBQUU7WUFDL0MsSUFBSSxPQUFPLENBQUMsU0FBUyxDQUFDLFFBQVEsQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRTtnQkFDMUMsT0FBTyxLQUFLLENBQUM7YUFDaEI7U0FDSjtRQUVELE9BQU8sSUFBSSxDQUFDO0lBQ2hCLENBQUM7SUFFRCx5Q0FBbUIsR0FBbkIsVUFBb0IsT0FBWTtRQUM1QixJQUFJLE9BQU8sQ0FBQyxTQUFTLENBQUMsT0FBTyxDQUFDLG1CQUFtQixDQUFDLEtBQUssQ0FBQyxDQUFDLEVBQUU7WUFDdkQsT0FBTyxJQUFJLENBQUM7U0FDZjtRQUVELElBQUksT0FBTyxPQUFPLENBQUMsTUFBTSxLQUFLLFdBQVc7WUFDckMsQ0FBQyxDQUFDLE9BQU8sT0FBTyxDQUFDLE1BQU0sQ0FBQyxLQUFLLEtBQUssV0FBVyxJQUFJLE9BQU8sQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDO2dCQUNyRSxDQUFDLE9BQU8sT0FBTyxDQUFDLE1BQU0sQ0FBQyxNQUFNLEtBQUssV0FBVyxJQUFJLE9BQU8sQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLENBQUMsRUFDM0U7WUFDRSxPQUFPLElBQUksQ0FBQztTQUNmO1FBRUQsT0FBTyxLQUFLLENBQUM7SUFDakIsQ0FBQztJQUVPLHNDQUFnQixHQUF4QixVQUF5QixPQUFZLEVBQUUsT0FBWSxFQUFFLHdCQUF3QixDQUFDLE9BQWdCO1FBQzFGLElBQUksYUFBYSxHQUFjLE1BQU8sQ0FBQyxNQUFNLENBQUMsRUFBRSxFQUFFLE9BQU8sQ0FBQyxDQUFDO1FBRTNELCtEQUErRDtRQUMvRCx5Q0FBeUM7UUFDekMsNENBQTRDO1FBQzVDLDJDQUEyQztRQUMzQyxzREFBc0Q7UUFDdEQsSUFBSTtRQUVKLHNFQUFzRTtRQUN0RSx5Q0FBeUM7UUFDekMsNENBQTRDO1FBQzVDLDhDQUE4QztRQUM5QyxpQ0FBaUM7UUFDakMsbURBQW1EO1FBQ25ELDBEQUEwRDtRQUUxRCw2QkFBNkI7UUFDN0IsSUFBSTtRQUVKLG9FQUFvRTtRQUNwRSx5Q0FBeUM7UUFDekMsNENBQTRDO1FBQzVDLDhDQUE4QztRQUM5QyxpQ0FBaUM7UUFDakMsNENBQTRDO1FBQzVDLHVEQUF1RDtRQUV2RCw2QkFBNkI7UUFDN0IsSUFBSTtRQUVKLDBFQUEwRTtRQUMxRSx5Q0FBeUM7UUFDekMsNENBQTRDO1FBQzVDLDhDQUE4QztRQUM5QyxnQ0FBZ0M7UUFDaEMsZ0VBQWdFO1FBQ2hFLHdDQUF3QztRQUN4QywrREFBK0Q7UUFDL0Qsa0VBQWtFO1FBRWxFLDZCQUE2QjtRQUM3QixJQUFJO1FBRUosb0VBQW9FO1FBQ3BFLHlDQUF5QztRQUN6Qyw0Q0FBNEM7UUFDNUMsOENBQThDO1FBQzlDLGdDQUFnQztRQUNoQyxnRUFBZ0U7UUFDaEUscUNBQXFDO1FBQ3JDLCtEQUErRDtRQUMvRCxxQ0FBcUM7UUFFckMsNkJBQTZCO1FBQzdCLElBQUk7UUFFSixnRkFBZ0Y7UUFDNUUsdURBQXVEO1FBQ3ZELGlEQUFpRDtRQUNqRCwrQ0FBK0M7UUFDL0MsaURBQWlEO1FBQ2pELHNFQUFzRTtRQUN0RSx1R0FBdUc7UUFDdkcsb0VBQW9FO1FBQ3BFLGdCQUFnQjtRQUNoQixtQ0FBbUM7UUFDbkMsWUFBWTtRQUNaLGlCQUFpQjtRQUNqQixnR0FBZ0c7UUFDaEcsb0RBQW9EO1FBQ3BELFlBQVk7UUFDWixRQUFRO1FBQ1IsMkJBQTJCO1FBQzNCLElBQUk7UUFDUixJQUFJO1FBRUosT0FBTyxhQUFhLENBQUM7SUFDekIsQ0FBQztJQUVPLHVDQUFpQixHQUF6QixVQUEwQixZQUFpQixFQUFFLEtBQWlCO1FBQzFELElBQUksWUFBWSxHQUFlLEtBQUssQ0FBQyxLQUFLLEVBQUUsQ0FBQztRQUU3QyxJQUFJLE9BQU8sWUFBWSxLQUFLLFdBQVcsSUFBSSxNQUFNLENBQUMsSUFBSSxDQUFDLFlBQVksQ0FBQyxDQUFDLE1BQU0sS0FBSyxDQUFDLEVBQUU7WUFDL0UsT0FBTyxZQUFZLENBQUM7U0FDdkI7UUFFRCxJQUFJLFdBQVcsR0FBZSxFQUFFLENBQUM7UUFDakMsS0FBSyxJQUFJLEdBQUcsSUFBSSxZQUFZLEVBQUU7WUFDMUIsSUFBSSxZQUFZLENBQUMsY0FBYyxDQUFDLEdBQUcsQ0FBQyxFQUFFO2dCQUNsQyxLQUFLLElBQUksQ0FBQyxHQUFXLENBQUMsRUFBRSxDQUFDLEdBQUcsWUFBWSxDQUFDLEdBQUcsQ0FBQyxDQUFDLE1BQU0sRUFBRSxDQUFDLEVBQUUsRUFBRTtvQkFDdkQsS0FBSyxJQUFJLENBQUMsR0FBVyxDQUFDLEVBQUUsQ0FBQyxHQUFHLEtBQUssQ0FBQyxNQUFNLEVBQUUsQ0FBQyxFQUFFLEVBQUU7d0JBQzNDLElBQUksS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxLQUFLLFlBQVksQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRTs0QkFDeEMsV0FBVyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQzt5QkFDOUI7cUJBQ0o7aUJBQ0o7YUFDSjtTQUNKO1FBRUQsT0FBTyxXQUFXLENBQUM7SUFDdkIsQ0FBQztJQUVPLHFDQUFlLEdBQXZCLFVBQXdCLFVBQXNCLEVBQUUsS0FBaUI7UUFDN0QsSUFBSSxVQUFVLEdBQWUsS0FBSyxDQUFDLEtBQUssRUFBRSxDQUFDO1FBRTNDLElBQUksT0FBTyxVQUFVLEtBQUssV0FBVyxJQUFJLFVBQVUsQ0FBQyxNQUFNLEtBQUssQ0FBQyxFQUFFO1lBQzlELE9BQU8sVUFBVSxDQUFDO1NBQ3JCO1FBRUQsVUFBVSxDQUFDLElBQUksQ0FBQyxVQUFDLENBQU0sRUFBRSxDQUFNO1lBQzNCLEtBQUssSUFBSSxDQUFDLEdBQVcsQ0FBQyxFQUFFLENBQUMsR0FBRyxVQUFVLENBQUMsTUFBTSxFQUFFLENBQUMsRUFBRSxFQUFFO2dCQUNoRCxJQUFJLFlBQVksR0FBUSxVQUFVLENBQUMsQ0FBQyxDQUFDLENBQUM7Z0JBQ3RDLElBQUksSUFBSSxHQUFRLENBQUMsQ0FBQyxZQUFZLENBQUMsS0FBSyxDQUFDLENBQUM7Z0JBQ3RDLElBQUksSUFBSSxHQUFRLENBQUMsQ0FBQyxZQUFZLENBQUMsS0FBSyxDQUFDLENBQUM7Z0JBRXRDLElBQUksSUFBSSxLQUFLLElBQUksRUFBRTtvQkFDZixTQUFTO2lCQUNaO2dCQUVELElBQUksU0FBUyxHQUFHLENBQUMsWUFBWSxDQUFDLElBQUksS0FBSyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztnQkFFdkQsSUFBSSxJQUFJLEdBQUcsSUFBSSxFQUFFO29CQUNiLE9BQU8sU0FBUyxDQUFDO2lCQUNwQjtxQkFDSTtvQkFDRCxPQUFPLFNBQVMsR0FBRyxDQUFDLENBQUMsQ0FBQztpQkFDekI7YUFDSDtZQUVGLE9BQU8sQ0FBQyxDQUFDO1FBQ2IsQ0FBQyxDQUFDLENBQUM7UUFDSCxPQUFPLFVBQVUsQ0FBQztJQUN0QixDQUFDO0lBRU8sc0NBQWdCLEdBQXhCLFVBQXlCLE9BQVk7UUFDakMsSUFBSSxhQUFhLEdBQVcsR0FBRyxDQUFDO1FBRWhDLElBQUksT0FBTyxPQUFPLEtBQUssV0FBVyxFQUFFO1lBQ2hDLE9BQU8sYUFBYSxDQUFDO1NBQ3hCO2FBRUksSUFBSSxPQUFPLE9BQU8sQ0FBQyxVQUFVLEtBQUssV0FBVztZQUM5QyxPQUFPLE9BQU8sQ0FBQyxVQUFVLEtBQUssUUFBUTtZQUN0QyxPQUFPLENBQUMsVUFBVSxLQUFLLE1BQU0sRUFBRTtZQUMzQixPQUFPLE9BQU8sQ0FBQyxVQUFVLENBQUM7U0FDakM7YUFDSSxJQUFJLE9BQU8sT0FBTyxDQUFDLFVBQVUsS0FBSyxXQUFXO1lBQzlDLE9BQU8sT0FBTyxDQUFDLFVBQVUsS0FBSyxRQUFRLEVBQUU7WUFDcEMsT0FBTyxPQUFPLENBQUMsVUFBVSxDQUFDO1NBQ2pDO1FBRUQsT0FBTyxhQUFhLENBQUM7SUFDekIsQ0FBQztJQUVELHVFQUF1RTtJQUN2RSw0Q0FBNEM7SUFDNUMsOERBQThEO0lBQzlELCtDQUErQztJQUMvQyxnREFBZ0Q7SUFDaEQsUUFBUTtJQUNSLGlEQUFpRDtJQUNqRCw4REFBOEQ7SUFDOUQsK0NBQStDO0lBQy9DLDRIQUE0SDtJQUM1SCxRQUFRO0lBRVIsd0JBQXdCO0lBQ3hCLElBQUk7SUFFSSwwQ0FBb0IsR0FBNUIsVUFBNkIsU0FBaUI7UUFDMUMsSUFBSSxTQUFTLEtBQUssVUFBVTtZQUFFLE9BQU8sVUFBVSxDQUFDO1FBQ2hELElBQUksU0FBUyxLQUFLLG1CQUFtQixJQUFJLFNBQVMsS0FBSyxvQkFBb0I7WUFBRSxPQUFPLFlBQVksQ0FBQztRQUNqRyxPQUFPLEVBQUUsQ0FBQztJQUNkLENBQUM7SUFFTyxvQ0FBYyxHQUF0QixVQUF1QixPQUFZO1FBQy9CLElBQUksZUFBZSxHQUFXLFFBQVEsQ0FBQztRQUV2QyxJQUFJLE9BQU8sT0FBTyxLQUFLLFdBQVcsSUFBSSxPQUFPLE9BQU8sQ0FBQyxRQUFRLEtBQUssV0FBVyxFQUFFO1lBQzNFLE9BQU8sZUFBZSxDQUFDO1NBQzFCO1FBRUQsSUFBSSxPQUFPLENBQUMsUUFBUSxLQUFLLFFBQVE7WUFDN0IsT0FBTyxDQUFDLFFBQVEsS0FBSyxtQkFBbUI7WUFDeEMsT0FBTyxDQUFDLFFBQVEsS0FBSyxTQUFTO1lBQzlCLE9BQU8sQ0FBQyxRQUFRLEtBQUssb0JBQW9CLEVBQUU7WUFDdkMsT0FBTyxPQUFPLENBQUMsUUFBUSxDQUFDO1NBQy9CO1FBRUQsT0FBTyxlQUFlLENBQUM7SUFDM0IsQ0FBQztJQUVPLG9DQUFjLEdBQXRCLFVBQXVCLE9BQVksRUFBRSxTQUFpQjtRQUNsRCxJQUFJLFNBQVMsS0FBSyxRQUFRO1lBQUUsT0FBTyxDQUFDLENBQUMsQ0FBQztRQUN0QyxJQUFJLE9BQU8sT0FBTyxLQUFLLFdBQVcsSUFBSSxPQUFPLE9BQU8sQ0FBQyxRQUFRLEtBQUssV0FBVztZQUFFLE9BQU8sT0FBTyxDQUFDLFFBQVEsQ0FBQztRQUN2RyxPQUFPLEVBQUUsQ0FBQztJQUNkLENBQUM7SUFFTyxtQ0FBYSxHQUFyQixVQUFzQixPQUFZO1FBQzlCLElBQUksV0FBVyxHQUFRLElBQUksQ0FBQztRQUM1QixJQUFJLE1BQU0sR0FBZSxXQUFXLENBQUMsVUFBVSxDQUFDO1FBQ2hELElBQUksU0FBUyxHQUFXLEVBQUUsQ0FBQztRQUMzQixLQUFLLElBQUksQ0FBQyxHQUFXLENBQUMsRUFBRSxDQUFDLEdBQUcsTUFBTSxDQUFDLE1BQU0sRUFBRSxDQUFDLEVBQUUsRUFBRTtZQUM1QyxJQUFJLE9BQU8sTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sS0FBSyxXQUFXLEVBQUU7Z0JBQ3pDLElBQUksT0FBTyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLEtBQUssS0FBSyxXQUFXLElBQUksTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxLQUFLO29CQUFFLE9BQU8sR0FBRyxDQUFDO3FCQUNuRixJQUFJLE9BQU8sTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxRQUFRLEtBQUssV0FBVyxJQUFJLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsUUFBUTtvQkFBRSxPQUFPLEdBQUcsQ0FBQztxQkFDOUYsSUFBSSxPQUFPLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsS0FBSyxLQUFLLFdBQVcsSUFBSSxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLEtBQUssRUFBRTtvQkFDOUUsSUFBSSxPQUFPLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsWUFBWSxLQUFLO3dCQUFFLE9BQU8sU0FBUyxHQUFHLE9BQU8sQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLE1BQU0sQ0FBQztpQkFDL0c7YUFDSjtTQUNKO1FBQ0QsT0FBTyxFQUFFLENBQUM7SUFDZCxDQUFDO0lBRU8scUNBQWUsR0FBdkIsVUFBd0IsV0FBdUI7UUFDM0MsSUFBSSxnQkFBZ0IsR0FBZSxFQUFFLENBQUM7UUFDdEMsS0FBSyxJQUFJLENBQUMsR0FBVyxDQUFDLEVBQUUsQ0FBQyxHQUFHLFdBQVcsQ0FBQyxNQUFNLEVBQUUsQ0FBQyxFQUFFLEVBQUU7WUFDakQsZ0JBQWdCLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxZQUFZLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztTQUM1RDtRQUNELE9BQU8sZ0JBQWdCLENBQUM7SUFDNUIsQ0FBQztJQUVPLGtDQUFZLEdBQXBCLFVBQXFCLFdBQWdCO1FBQ2pDLElBQUksYUFBYSxHQUFRO1lBQ3JCLElBQUksRUFBRSxJQUFJO1lBQ1YsS0FBSyxFQUFFLEVBQUU7WUFDVCxJQUFJLEVBQUUsRUFBRTtZQUNSLE1BQU0sRUFBRSxJQUFJO1lBQ1osUUFBUSxFQUFFLElBQUk7WUFDZCxJQUFJLEVBQUUsSUFBSTtTQUNiLENBQUM7UUFDRixPQUFPLE1BQU0sQ0FBQyxNQUFNLENBQUMsYUFBYSxFQUFFLFdBQVcsQ0FBQyxDQUFDO0lBQ3JELENBQUM7SUFyakJRLFdBQVc7UUFEdkIsVUFBVSxFQUFFO09BQ0EsV0FBVyxDQXNqQnZCO0lBQUQsa0JBQUM7Q0FBQSxBQXRqQkQsSUFzakJDO1NBdGpCWSxXQUFXIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgSW5qZWN0YWJsZSwgVmlld0NvbnRhaW5lclJlZiB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xyXG5pbXBvcnQgeyBSb3V0ZXIgfSBmcm9tICdAYW5ndWxhci9yb3V0ZXInO1xyXG5pbXBvcnQgeyBHcmlkT3B0aW9ucywgQ29sdW1uLCBJUm93TW9kZWwgfSBmcm9tICdhZy1ncmlkLWNvbW11bml0eSc7XHJcbi8vIGltcG9ydCB7XHJcbi8vICAgICBLZEFHRHJvcGRvd24sXHJcbi8vICAgICBLZEFHUGhvdG8sXHJcbi8vICAgICBLZEFHRm9ybSxcclxuLy8gICAgIEtkQUdDaGVja2JveFJhZGlvXHJcbi8vIH0gZnJvbSAnLi9hZy1ncmlkLWNvbXBvbmVudHMva2QtYWdncmlkLWNvbXBvbmVudHMnO1xyXG5cclxuQEluamVjdGFibGUoKVxyXG5leHBvcnQgY2xhc3MgS2RBZ2dyaWRTdmMge1xyXG4gICAgcHJpdmF0ZSBfcmVzaXplYWJsZUNvbDogbnVtYmVyID0gMDtcclxuICAgIC8vIHByaXZhdGUgX2RhdGFTdmM6IEtkRGF0YVN2YyA9IG5ldyBLZERhdGFTdmMoKTtcclxuXHJcbiAgICBnZXRHcmlkT3B0aW9ucygpOiBhbnkge1xyXG4gICAgICAgIGxldCBvcHRpb25zOiBhbnkgPSB7XHJcbiAgICAgICAgICAgIHJvd0RhdGE6IFtdLFxyXG4gICAgICAgICAgICBjb2x1bW5EZWZzOiBbXSxcclxuICAgICAgICAgICAgLy8gZGVidWc6IHRydWUsXHJcbiAgICAgICAgICAgIGhlYWRlckhlaWdodDogMzgsXHJcbiAgICAgICAgICAgIGdldFJvd0hlaWdodDogdGhpcy5fZ2V0Um93SGVpZ2h0LFxyXG4gICAgICAgICAgICAvLyBhbmltYXRlUm93czogdHJ1ZSxcclxuICAgICAgICAgICAgLy8gcm93QnVmZmVyOiA1LFxyXG4gICAgICAgICAgICBzdXBwcmVzc0NvbnRleHRNZW51OiB0cnVlLFxyXG4gICAgICAgICAgICAvLyBzdXBwcmVzc01lbnVNYWluUGFuZWw6IHRydWUsXHJcbiAgICAgICAgICAgIC8vIHN1cHByZXNzTWVudUNvbHVtblBhbmVsOiB0cnVlLFxyXG4gICAgICAgICAgICBzdXBwcmVzc01vdmFibGVDb2x1bW5zOiB0cnVlLFxyXG4gICAgICAgICAgICBzdXBwcmVzc01lbnVIaWRlOiB0cnVlLFxyXG4gICAgICAgICAgICBzdXBwcmVzc0NvbHVtblZpcnR1YWxpc2F0aW9uOiB0cnVlLFxyXG4gICAgICAgICAgICB1blNvcnRJY29uOiB0cnVlLFxyXG4gICAgICAgICAgICBpY29uczoge1xyXG4gICAgICAgICAgICAgICAgZmlsdGVyOiAnPGkgY2xhc3M9XCJmYSBmYS1maWx0ZXJcIi8+JyxcclxuICAgICAgICAgICAgICAgIHNvcnRBc2NlbmRpbmc6ICc8aSBjbGFzcz1cImZhIGZhLWNhcmV0LWRvd25cIi8+JyxcclxuICAgICAgICAgICAgICAgIHNvcnREZXNjZW5kaW5nOiAnPGkgY2xhc3M9XCJmYSBmYS1jYXJldC11cFwiLz4nLFxyXG4gICAgICAgICAgICAgICAgc29ydFVuU29ydDogJzxpIGNsYXNzPVwiZmEgZmEtc29ydFwiLz4nLFxyXG4gICAgICAgICAgICAgICAgZ3JvdXBFeHBhbmRlZDogJzxpIGNsYXNzPVwiZmEgZmEtbWludXMtY2lyY2xlXCIvPicsXHJcbiAgICAgICAgICAgICAgICBncm91cENvbnRyYWN0ZWQ6ICc8aSBjbGFzcz1cImZhIGZhLXBsdXMtY2lyY2xlXCIvPicsXHJcbiAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgIG92ZXJsYXlOb1Jvd3NUZW1wbGF0ZTogJzxzcGFuIGNsYXNzPVwiYWctY3VzdG9tLW92ZXJsYXlcIj48aSBjbGFzcz1cImZhIGZhLWluZm8tY2lyY2xlIGZhLWxnIG1hcmdpbi1yaWdodDEwXCI+PC9pPk5vIHN0dWRlbnQgcmVjb3JkIGZvdW5kPC9zcGFuPidcclxuICAgICAgICB9O1xyXG4gICAgICAgIHJldHVybiBvcHRpb25zO1xyXG4gICAgfVxyXG5cclxuICAgIHNldFJlc3VsdChfY29uZmlnOiBhbnkpOiBhbnkge1xyXG4gICAgICAgIGxldCB1cGRhdGVSZXN1bHQ6IGFueSA9IHt9O1xyXG4gICAgICAgIHVwZGF0ZVJlc3VsdC5pZCA9ICh0eXBlb2YgX2NvbmZpZyAhPT0gJ3VuZGVmaW5lZCcgJiYgdHlwZW9mIF9jb25maWcuaWQgIT09ICd1bmRlZmluZWQnKSA/IF9jb25maWcuaWQgOiAna2QtZ3JpZCc7XHJcbiAgICAgICAgdXBkYXRlUmVzdWx0LmdyaWRIZWlnaHQgPSB0aGlzLl9jaGVja0dyaWRIZWlnaHQoX2NvbmZpZyk7XHJcbiAgICAgICAgdXBkYXRlUmVzdWx0LmNoZWNrYm94ID0gKHR5cGVvZiBfY29uZmlnICE9PSAndW5kZWZpbmVkJyAmJiB0eXBlb2YgX2NvbmZpZy5jaGVja2JveCAhPT0gJ3VuZGVmaW5lZCcpID8gX2NvbmZpZy5jaGVja2JveCA6IGZhbHNlO1xyXG4gICAgICAgIHVwZGF0ZVJlc3VsdC5yYWRpbyA9ICh0eXBlb2YgX2NvbmZpZyAhPT0gJ3VuZGVmaW5lZCcgJiYgdHlwZW9mIF9jb25maWcucmFkaW8gIT09ICd1bmRlZmluZWQnKSA/IF9jb25maWcucmFkaW8gOiBmYWxzZTtcclxuICAgICAgICB1cGRhdGVSZXN1bHQuZXh0ZXJuYWxGaWx0ZXIgPSAodHlwZW9mIF9jb25maWcgIT09ICd1bmRlZmluZWQnICYmIHR5cGVvZiBfY29uZmlnLmV4dGVybmFsRmlsdGVyICE9PSAndW5kZWZpbmVkJykgPyBfY29uZmlnLmV4dGVybmFsRmlsdGVyIDogZmFsc2U7XHJcbiAgICAgICAgdXBkYXRlUmVzdWx0LmxvYWRUeXBlID0gdGhpcy5fY2hlY2tMb2FkVHlwZShfY29uZmlnKTtcclxuICAgICAgICB1cGRhdGVSZXN1bHQucGFnaW5hdGlvblR5cGUgPSB0aGlzLl9jaGVja1BhZ2luYXRpb25UeXBlKHVwZGF0ZVJlc3VsdC5sb2FkVHlwZSk7XHJcbiAgICAgICAgdXBkYXRlUmVzdWx0LnBhZ2VzaXplID0gdGhpcy5fY2hlY2tQYWdlc2l6ZShfY29uZmlnLCB1cGRhdGVSZXN1bHQubG9hZFR5cGUpO1xyXG4gICAgICAgIHVwZGF0ZVJlc3VsdC50b3RhbERhdGEgPSAodHlwZW9mIF9jb25maWcgIT09ICd1bmRlZmluZWQnICYmIHR5cGVvZiBfY29uZmlnLnRvdGFsRGF0YSAhPT0gJ3VuZGVmaW5lZCcpID8gX2NvbmZpZy50b3RhbERhdGEgOiAtMTtcclxuICAgICAgICB1cGRhdGVSZXN1bHQuYnV0dG9uID0gKHR5cGVvZiBfY29uZmlnICE9PSAndW5kZWZpbmVkJyAmJiB0eXBlb2YgX2NvbmZpZy5idXR0b24gIT09ICd1bmRlZmluZWQnKSA/IF9jb25maWcuYnV0dG9uIDogZmFsc2U7XHJcbiAgICAgICAgdXBkYXRlUmVzdWx0LmJ1dHRvbkNvbmZpZyA9ICh0eXBlb2YgX2NvbmZpZyAhPT0gJ3VuZGVmaW5lZCcgJiYgdHlwZW9mIF9jb25maWcuYnV0dG9uQ29uZmlnICE9PSAndW5kZWZpbmVkJykgPyB0aGlzLl9jaGVja0J0bkNvbmZpZyhfY29uZmlnLmJ1dHRvbkNvbmZpZykgOiBudWxsO1xyXG4gICAgICAgIHVwZGF0ZVJlc3VsdC5hbGlnbm1lbnQgPSAodHlwZW9mIF9jb25maWcgIT09ICd1bmRlZmluZWQnICYmIHR5cGVvZiBfY29uZmlnLmFsaWdubWVudCAhPT0gJ3VuZGVmaW5lZCcpID8gX2NvbmZpZy5hbGlnbm1lbnQgOiAnbWlkZGxlJztcclxuICAgICAgICB1cGRhdGVSZXN1bHQuc3VwcHJlc3NIZWlnaHRSZXNpemUgPSAodHlwZW9mIF9jb25maWcgIT09ICd1bmRlZmluZWQnICYmIHR5cGVvZiBfY29uZmlnLnN1cHByZXNzSGVpZ2h0UmVzaXplICE9PSAndW5kZWZpbmVkJykgPyBfY29uZmlnLnN1cHByZXNzSGVpZ2h0UmVzaXplIDogdHJ1ZTtcclxuICAgICAgICB1cGRhdGVSZXN1bHQucm93Q2xpY2thYmxlID0gKHR5cGVvZiBfY29uZmlnICE9PSAndW5kZWZpbmVkJyAmJiB0eXBlb2YgX2NvbmZpZy5yb3dDbGlja2FibGUgIT09ICd1bmRlZmluZWQnKSA/IF9jb25maWcucm93Q2xpY2thYmxlIDogZmFsc2U7XHJcbiAgICAgICAgdXBkYXRlUmVzdWx0LnJvd01hcEFjdGlvblR5cGUgPSAodHlwZW9mIF9jb25maWcgIT09ICd1bmRlZmluZWQnICYmIHR5cGVvZiBfY29uZmlnLnJvd01hcEFjdGlvblR5cGUgIT09ICd1bmRlZmluZWQnKSA/IF9jb25maWcucm93TWFwQWN0aW9uVHlwZSA6IG51bGw7XHJcblxyXG4gICAgICAgIGlmICh1cGRhdGVSZXN1bHQucmFkaW8gJiYgdXBkYXRlUmVzdWx0LmNoZWNrYm94KSB1cGRhdGVSZXN1bHQucmFkaW8gPSBmYWxzZTtcclxuICAgICAgICByZXR1cm4gdXBkYXRlUmVzdWx0O1xyXG4gICAgfVxyXG5cclxuICAgIHNldFJvd1Jlc3VsdChfcm93RGF0YTogQXJyYXk8YW55Pik6IEFycmF5PGFueT4ge1xyXG4gICAgICAgIGxldCB0YWJsZURhdGE6IEFycmF5PGFueT4gPSAodHlwZW9mIF9yb3dEYXRhICE9PSAndW5kZWZpbmVkJykgPyBfcm93RGF0YSA6IFtdO1xyXG4gICAgICAgIHJldHVybiB0YWJsZURhdGE7XHJcbiAgICB9XHJcblxyXG4gICAgc2V0Q29sRGVmcyhfY29sRGVmOiBhbnksIF9ncmlkT3B0aW9uczogR3JpZE9wdGlvbnMsIC8qX2RhdGFTdmM6IEtkRGF0YVN2YywgKi9fcm91dGVyPzogUm91dGVyLCBfaXNSZWN1cnNpdmU6IGJvb2xlYW4gPSBmYWxzZSk6IGFueSB7XHJcbiAgICAgICAgbGV0IGNvbERlZkNvbmZpZzogYW55ID0geyBlZGl0TW9kZTogZmFsc2UsIHVwZGF0ZWRDb2xEZWY6IFtdIH07XHJcbiAgICAgICAgbGV0IHRhYmxlQ29sdW1uOiBhbnkgPSB7fTtcclxuXHJcbiAgICAgICAgZm9yIChsZXQga2V5IGluIF9jb2xEZWYpIHtcclxuICAgICAgICAgICAgaWYgKF9jb2xEZWYuaGFzT3duUHJvcGVydHkoa2V5KSkge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5fcmVzaXplYWJsZUNvbCsrO1xyXG5cclxuICAgICAgICAgICAgICAgIHRhYmxlQ29sdW1uID0ge1xyXG4gICAgICAgICAgICAgICAgICAgIGhlYWRlck5hbWU6IF9jb2xEZWZba2V5XS5oZWFkZXJOYW1lLFxyXG4gICAgICAgICAgICAgICAgICAgIGZpZWxkOiAodHlwZW9mIF9jb2xEZWZba2V5XS5jb25maWcgIT09ICd1bmRlZmluZWQnICYmIHR5cGVvZiBfY29sRGVmW2tleV0uY29uZmlnLm1hcCAhPT0gJ3VuZGVmaW5lZCcpID8gX2NvbERlZltrZXldLmNvbmZpZy5tYXAgOiBrZXksXHJcbiAgICAgICAgICAgICAgICAgICAgZWRpdGFibGU6IGZhbHNlLCAvLyAodHlwZW9mIF9jb2xEZWZba2V5XS5lZGl0YWJsZSAhPT0gJ3VuZGVmaW5lZCcpID8gX2NvbERlZltrZXldLmVkaXRhYmxlIDogZmFsc2UsXHJcbiAgICAgICAgICAgICAgICAgICAgc3VwcHJlc3NNZW51OiAodHlwZW9mIF9jb2xEZWZba2V5XS5maWx0ZXJhYmxlICE9PSAndW5kZWZpbmVkJykgPyAhX2NvbERlZltrZXldLmZpbHRlcmFibGUgOiB0cnVlLFxyXG4gICAgICAgICAgICAgICAgICAgIHN1cHByZXNzU29ydGluZzogKHR5cGVvZiBfY29sRGVmW2tleV0uc29ydGFibGUgIT09ICd1bmRlZmluZWQnKSA/ICFfY29sRGVmW2tleV0uc29ydGFibGUgOiB0cnVlLFxyXG4gICAgICAgICAgICAgICAgICAgIGNvbElkOiBrZXksXHJcbiAgICAgICAgICAgICAgICAgICAgY29uZmlnOiAodHlwZW9mIF9jb2xEZWZba2V5XS5jb25maWcgIT09ICd1bmRlZmluZWQnKSA/IF9jb2xEZWZba2V5XS5jb25maWcgOiB1bmRlZmluZWQsXHJcbiAgICAgICAgICAgICAgICAgICAgLy8gY2VsbFJlbmRlcmVyOiAoX3BhcmFtczogYW55KTogYW55ID0+IHtcclxuICAgICAgICAgICAgICAgICAgICAvLyAgICAgaWYgKHR5cGVvZiBfcGFyYW1zLnZhbHVlID09PSAnbnVtYmVyJykge1xyXG4gICAgICAgICAgICAgICAgICAgIC8vICAgICAgICAgcmV0dXJuIF9wYXJhbXMudmFsdWUudG9TdHJpbmcoKTtcclxuICAgICAgICAgICAgICAgICAgICAvLyAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIC8vICAgICBlbHNlIGlmIChfcGFyYW1zLnZhbHVlIGluc3RhbmNlb2YgQXJyYXkpIHtcclxuICAgICAgICAgICAgICAgICAgICAvLyAgICAgICAgIEpTT04uc3RyaW5naWZ5KF9wYXJhbXMudmFsdWUpO1xyXG4gICAgICAgICAgICAgICAgICAgIC8vICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgLy8gICAgIHJldHVybiBfcGFyYW1zLnZhbHVlO1xyXG4gICAgICAgICAgICAgICAgICAgIC8vIH0sXHJcbiAgICAgICAgICAgICAgICAgICAgaGlkZTogKHR5cGVvZiBfY29sRGVmW2tleV0udmlzaWJsZSAhPT0gJ3VuZGVmaW5lZCcpID8gIShfY29sRGVmW2tleV0udmlzaWJsZSkgOiBmYWxzZSxcclxuICAgICAgICAgICAgICAgICAgICBjZWxsQ2xhc3M6ICdhZy1kZWZhdWx0J1xyXG4gICAgICAgICAgICAgICAgfTtcclxuXHJcbiAgICAgICAgICAgICAgICBpZiAoIXRhYmxlQ29sdW1uLnN1cHByZXNzTWVudSkge1xyXG4gICAgICAgICAgICAgICAgICAgIHRhYmxlQ29sdW1uWydtZW51VGFicyddID0gWydmaWx0ZXJNZW51VGFiJ107XHJcbiAgICAgICAgICAgICAgICAgICAgdGFibGVDb2x1bW4uZmlsdGVyUGFyYW1zID0ge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBuZXdSb3dzQWN0aW9uOiAna2VlcCcsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNlbGxIZWlnaHQ6IDMwLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBzZWxlY3RBbGxPbk1pbmlGaWx0ZXI6IHRydWUsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlczogKHR5cGVvZiBfY29sRGVmW2tleV0uZmlsdGVyVmFsICE9PSAndW5kZWZpbmVkJyAmJiBfY29sRGVmW2tleV0uZmlsdGVyVmFsLmxlbmd0aCA+IDApID8gX2NvbERlZltrZXldLmZpbHRlclZhbCA6IHVuZGVmaW5lZFxyXG4gICAgICAgICAgICAgICAgICAgIH07XHJcbiAgICAgICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICAgICAgaWYgKHR5cGVvZiBfY29sRGVmW2tleV0uY29uZmlnICE9PSAndW5kZWZpbmVkJykge1xyXG4gICAgICAgICAgICAgICAgICAgIGlmICh0eXBlb2YgX2NvbERlZltrZXldLmNvbmZpZy5pbnB1dCAhPT0gJ3VuZGVmaW5lZCcgJiYgX2NvbERlZltrZXldLmNvbmZpZy5pbnB1dCkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBjb2xEZWZDb25maWcuZWRpdE1vZGUgPSB0cnVlO1xyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgdGFibGVDb2x1bW4gPSB0aGlzLl9zZXRDb2x1bW5Db25maWcodGFibGVDb2x1bW4sIF9jb2xEZWZba2V5XS5jb25maWcsIC8qX2RhdGFTdmMsKi8gX3JvdXRlcik7XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIGlmICh0YWJsZUNvbHVtbi5oYXNPd25Qcm9wZXJ0eSgnY2VsbFJlbmRlcmVyRnJhbWV3b3JrJykpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgZGVsZXRlIHRhYmxlQ29sdW1uLmNlbGxSZW5kZXJlcjtcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICAgICAgaWYgKHR5cGVvZiB0YWJsZUNvbHVtbi5jb25maWcgIT09ICd1bmRlZmluZWQnICYmIChcclxuICAgICAgICAgICAgICAgICAgICAodHlwZW9mIHRhYmxlQ29sdW1uLmNvbmZpZy5jaGVja2JveCAhPT0gJ3VuZGVmaW5lZCcgJiYgdGFibGVDb2x1bW4uY29uZmlnLmNoZWNrYm94KSB8fFxyXG4gICAgICAgICAgICAgICAgICAgICh0eXBlb2YgdGFibGVDb2x1bW4uY29uZmlnLnJhZGlvICE9PSAndW5kZWZpbmVkJyAmJiB0YWJsZUNvbHVtbi5jb25maWcucmFkaW8pKSkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBjb2xEZWZDb25maWcudXBkYXRlZENvbERlZi51bnNoaWZ0KHRhYmxlQ29sdW1uKTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgICAgIGNvbERlZkNvbmZpZy51cGRhdGVkQ29sRGVmLnB1c2godGFibGVDb2x1bW4pO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICByZXR1cm4gY29sRGVmQ29uZmlnO1xyXG4gICAgfVxyXG5cclxuICAgIHNldEZpbHRlckFuZFNvcnRPcHRpb25zKHBhcmFtczogYW55KTogR3JpZE9wdGlvbnMge1xyXG4gICAgICAgIGxldCB1cGRhdGVkT3B0aW9ucyA9IHBhcmFtcy5ncmlkT3B0aW9ucztcclxuXHJcbiAgICAgICAgaWYgKHBhcmFtcy5sb2FkVHlwZSA9PT0gJ3NlcnZlci1wYWdpbmF0aW9uJyB8fCBwYXJhbXMubG9hZFR5cGUgPT09ICdvbmVzaG90LXBhZ2luYXRpb24nKSB7XHJcbiAgICAgICAgICAgIHVwZGF0ZWRPcHRpb25zLmVuYWJsZVNlcnZlclNpZGVGaWx0ZXIgPSB0cnVlO1xyXG4gICAgICAgICAgICB1cGRhdGVkT3B0aW9ucy5lbmFibGVTZXJ2ZXJTaWRlU29ydGluZyA9IHRydWU7XHJcbiAgICAgICAgICAgIHVwZGF0ZWRPcHRpb25zLnBhZ2luYXRpb25QYWdlU2l6ZSA9IHBhcmFtcy5wYWdlc2l6ZTtcclxuICAgICAgICB9XHJcbiAgICAgICAgZWxzZSBpZiAocGFyYW1zLmxvYWRUeXBlID09PSAndmlydHVhbCcpIHtcclxuICAgICAgICAgICAgdXBkYXRlZE9wdGlvbnMuZW5hYmxlU2VydmVyU2lkZUZpbHRlciA9IHRydWU7XHJcbiAgICAgICAgICAgIHVwZGF0ZWRPcHRpb25zLmVuYWJsZVNlcnZlclNpZGVTb3J0aW5nID0gdHJ1ZTtcclxuICAgICAgICAgICAgdXBkYXRlZE9wdGlvbnMucGFnaW5hdGlvblBhZ2VTaXplID0gcGFyYW1zLnBhZ2VzaXplO1xyXG4gICAgICAgICAgICB1cGRhdGVkT3B0aW9ucy5tYXhQYWdlc0luQ2FjaGUgPSAzO1xyXG4gICAgICAgICAgICB1cGRhdGVkT3B0aW9ucy5tYXhDb25jdXJyZW50RGF0YXNvdXJjZVJlcXVlc3RzID0gMjtcclxuICAgICAgICAgICAgdXBkYXRlZE9wdGlvbnMub3ZlcmZsb3dTaXplID0gMzA7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICB1cGRhdGVkT3B0aW9ucy5lbmFibGVGaWx0ZXIgPSB0cnVlO1xyXG4gICAgICAgICAgICB1cGRhdGVkT3B0aW9ucy5lbmFibGVTb3J0aW5nID0gdHJ1ZTtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIGlmIChwYXJhbXMubG9hZFR5cGUgPT09ICdzZXJ2ZXItcGFnaW5hdGlvbicgfHwgcGFyYW1zLmxvYWRUeXBlID09PSAnb25lc2hvdC1wYWdpbmF0aW9uJykge1xyXG4gICAgICAgICAgICB1cGRhdGVkT3B0aW9ucy5wYWdpbmF0aW9uID0gdHJ1ZTtcclxuICAgICAgICB9XHJcbiAgICAgICAgZWxzZSB7XHJcbiAgICAgICAgICAgIHVwZGF0ZWRPcHRpb25zLnJvd01vZGVsVHlwZSA9IHBhcmFtcy5wYWdpbmF0aW9uVHlwZTtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIHJldHVybiB1cGRhdGVkT3B0aW9ucztcclxuICAgIH1cclxuXHJcbiAgICBjYWxjQ29sV2lkdGgoX2dyaWRPcHRpb25zOiBHcmlkT3B0aW9ucyk6IEFycmF5PHt3aWR0aDogbnVtYmVyLCBpZDogc3RyaW5nfT4ge1xyXG4gICAgICAgIGxldCBjb2x1bW5zOiBBcnJheTxDb2x1bW4+ID0gX2dyaWRPcHRpb25zLmNvbHVtbkFwaS5nZXRBbGxDb2x1bW5zKCk7XHJcbiAgICAgICAgbGV0IHVwZGF0ZWRXaWR0aDogQXJyYXk8e3dpZHRoOiBudW1iZXIsIGlkOiBzdHJpbmd9PiA9IFtdO1xyXG5cclxuICAgICAgICBmb3IgKGxldCBpOiBudW1iZXIgPSAwOyBpIDwgY29sdW1ucy5sZW5ndGg7IGkrKykge1xyXG4gICAgICAgICAgICBsZXQgY29sdW1uRGVmOiBhbnkgPSBjb2x1bW5zW2ldLmdldENvbERlZigpO1xyXG4gICAgICAgICAgICBsZXQgY29sV2lkdGg6IG51bWJlciA9IC0xO1xyXG5cclxuICAgICAgICAgICAgaWYgKGNvbHVtbkRlZi5jZWxsQ2xhc3MuaW5kZXhPZignYWctY2hlY2tib3gtcmFkaW8nKSAhPT0gLTEpIHtcclxuICAgICAgICAgICAgICAgIGNvbFdpZHRoID0gNTA7XHJcbiAgICAgICAgICAgICAgICBfZ3JpZE9wdGlvbnMuY29sdW1uQXBpLnNldENvbHVtbldpZHRoKGNvbHVtbnNbaV0sIGNvbFdpZHRoKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBlbHNlIGlmICh0eXBlb2YgY29sdW1uRGVmLmNvbmZpZyAhPT0gJ3VuZGVmaW5lZCcgJiYgdHlwZW9mIGNvbHVtbkRlZi5jb25maWcuYWN0aW9uICE9PSAndW5kZWZpbmVkJyAmJiBjb2x1bW5EZWYuY29uZmlnLmFjdGlvbikge1xyXG4gICAgICAgICAgICAgICAgY29sV2lkdGggPSAxMjA7XHJcbiAgICAgICAgICAgICAgICBfZ3JpZE9wdGlvbnMuY29sdW1uQXBpLnNldENvbHVtbldpZHRoKGNvbHVtbnNbaV0sIGNvbFdpZHRoKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBlbHNlIGlmICh0eXBlb2YgY29sdW1uRGVmLmNvbmZpZyAhPT0gJ3VuZGVmaW5lZCcgJiYgdHlwZW9mIGNvbHVtbkRlZi5jb25maWcucGhvdG8gIT09ICd1bmRlZmluZWQnICYmIGNvbHVtbkRlZi5jb25maWcucGhvdG8pIHtcclxuICAgICAgICAgICAgICAgIGNvbFdpZHRoID0gMTAwO1xyXG4gICAgICAgICAgICAgICAgX2dyaWRPcHRpb25zLmNvbHVtbkFwaS5zZXRDb2x1bW5XaWR0aChjb2x1bW5zW2ldLCBjb2xXaWR0aCk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgZWxzZSBpZiAodHlwZW9mIGNvbHVtbkRlZi5jb25maWcgIT09ICd1bmRlZmluZWQnICYmIHR5cGVvZiBjb2x1bW5EZWYuY29uZmlnLmlucHV0ICE9PSAndW5kZWZpbmVkJyAmJiBjb2x1bW5EZWYuY29uZmlnLmlucHV0KSB7XHJcbiAgICAgICAgICAgICAgICBjb2xXaWR0aCA9IDI4MDtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgICAgIGNvbFdpZHRoID0gY29sdW1uc1tpXS5nZXRBY3R1YWxXaWR0aCgpICsgMzA7XHJcbiAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgIHVwZGF0ZWRXaWR0aC5wdXNoKHt3aWR0aDogY29sV2lkdGgsIGlkOiBjb2x1bW5EZWYuY29sSWR9KTtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIHJldHVybiB1cGRhdGVkV2lkdGg7XHJcbiAgICB9XHJcblxyXG4gICAgY29sVG90YWxXaWR0aChfY29sQXJyYXk6IEFycmF5PHt3aWR0aDogbnVtYmVyLCBpZDogc3RyaW5nfT4sIGNvbHVtbjogQXJyYXk8Q29sdW1uPik6IG51bWJlciB7XHJcbiAgICAgICAgbGV0IHRvdGFsOiBudW1iZXIgPSAwO1xyXG4gICAgICAgIGZvciAobGV0IGk6IG51bWJlciA9IDA7IGkgPCBfY29sQXJyYXkubGVuZ3RoOyBpKyspIHtcclxuICAgICAgICAgICAgaWYgKGNvbHVtbltpXS5pc1Zpc2libGUoKSkge1xyXG4gICAgICAgICAgICAgICAgdG90YWwgKz0gX2NvbEFycmF5W2ldLndpZHRoO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICByZXR1cm4gdG90YWw7XHJcbiAgICB9XHJcblxyXG4gICAgY2FsY1VzYWJsZVdpZHRoKF92Y3I6IFZpZXdDb250YWluZXJSZWYpOiBudW1iZXIge1xyXG4gICAgICAgIGxldCBhZ0dyaWRFbGU6IEhUTUxFbGVtZW50ID0gX3Zjci5lbGVtZW50Lm5hdGl2ZUVsZW1lbnQucXVlcnlTZWxlY3RvcignLnN0Zy10aGVtZScpO1xyXG4gICAgICAgIGxldCBwYXJlbnRXaWR0aDogbnVtYmVyID0gTWF0aC5yb3VuZChhZ0dyaWRFbGUuZ2V0Qm91bmRpbmdDbGllbnRSZWN0KCkud2lkdGgpO1xyXG4gICAgICAgIGxldCBjb21wdXRlZFN0eWxlOiBDU1NTdHlsZURlY2xhcmF0aW9uID0gd2luZG93LmdldENvbXB1dGVkU3R5bGUoYWdHcmlkRWxlKTtcclxuICAgICAgICBsZXQgYm9yZGVyTGVmdDogbnVtYmVyID0gKGNvbXB1dGVkU3R5bGUuYm9yZGVyTGVmdCAhPT0gJycpID8gcGFyc2VJbnQoY29tcHV0ZWRTdHlsZS5ib3JkZXJMZWZ0KSA6IDA7XHJcbiAgICAgICAgbGV0IGJvcmRlclJpZ2h0OiBudW1iZXIgPSAoY29tcHV0ZWRTdHlsZS5ib3JkZXJSaWdodCAhPT0gJycpID8gcGFyc2VJbnQoY29tcHV0ZWRTdHlsZS5ib3JkZXJSaWdodCkgOiAwO1xyXG4gICAgICAgIGxldCBib3JkZXJMZWZ0UmlnaHQgPSBib3JkZXJMZWZ0ICsgYm9yZGVyUmlnaHQ7XHJcbiAgICAgICAgcmV0dXJuIHBhcmVudFdpZHRoIC0gYm9yZGVyTGVmdFJpZ2h0O1xyXG4gICAgfVxyXG5cclxuICAgIGNhbGNSZXNpemVhYmxlQ29sKF9jb2x1bW5zOiBBcnJheTxDb2x1bW4+KTogbnVtYmVyIHtcclxuICAgICAgICBsZXQgcmVzaXplYWJsZUNvbDogbnVtYmVyID0gdGhpcy5fcmVzaXplYWJsZUNvbDtcclxuXHJcbiAgICAgICAgZm9yIChsZXQgaTogbnVtYmVyID0gMDsgaSA8IF9jb2x1bW5zLmxlbmd0aDsgaSsrKSB7XHJcbiAgICAgICAgICAgIGxldCBjb2xEZWY6IGFueSA9IF9jb2x1bW5zW2ldLmdldENvbERlZigpO1xyXG5cclxuICAgICAgICAgICAgaWYgKHR5cGVvZiBjb2xEZWYuY29uZmlnID09PSAndW5kZWZpbmVkJyAmJiAhX2NvbHVtbnNbaV0uaXNWaXNpYmxlKCkpIHtcclxuICAgICAgICAgICAgICAgIC0tcmVzaXplYWJsZUNvbDtcclxuICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgLy8gbW9yZSBjaGVja3MgdG8gaW1wbGVtZW50XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICByZXR1cm4gcmVzaXplYWJsZUNvbDtcclxuICAgIH1cclxuXHJcbiAgICBjYWxjR3JpZEhlaWdodFdlYihfZ3JpZEhlaWdodDogYW55LCBfbW9kZWw6IElSb3dNb2RlbCwgX3ZjcjogVmlld0NvbnRhaW5lclJlZik6IG51bWJlciB7XHJcbiAgICAgICAgbGV0IGFjdHVhbEhlaWdodDogbnVtYmVyID0gMzggKyA4O1xyXG4gICAgICAgIGxldCBpZFNvdXRoOiBFbGVtZW50ID0gX3Zjci5lbGVtZW50Lm5hdGl2ZUVsZW1lbnQucXVlcnlTZWxlY3RvcignI3NvdXRoJyk7XHJcblxyXG4gICAgICAgIGlmIChpZFNvdXRoICE9PSBudWxsKSB7XHJcbiAgICAgICAgICAgIGFjdHVhbEhlaWdodCArPSBpZFNvdXRoLmdldEJvdW5kaW5nQ2xpZW50UmVjdCgpLmhlaWdodDtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIGZvciAobGV0IGk6IG51bWJlciA9IDA7IGkgPCBfbW9kZWwuZ2V0Um93Q291bnQoKTsgaSsrKSB7XHJcbiAgICAgICAgICAgIGFjdHVhbEhlaWdodCArPSBfbW9kZWwuZ2V0Um93KGkpLnJvd0hlaWdodDtcclxuICAgICAgICAgICAgaWYgKGFjdHVhbEhlaWdodCA+IF9ncmlkSGVpZ2h0KSB7XHJcbiAgICAgICAgICAgICAgICBicmVhaztcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgaWYgKGFjdHVhbEhlaWdodCA8IF9ncmlkSGVpZ2h0KSB7XHJcbiAgICAgICAgICAgIHJldHVybiBhY3R1YWxIZWlnaHQ7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICByZXR1cm4gX2dyaWRIZWlnaHQ7XHJcbiAgICB9XHJcblxyXG4gICAgY2FsY0dyaWRIZWlnaHRNb2JpbGUoX3ZjcjogVmlld0NvbnRhaW5lclJlZik6IG51bWJlciB7XHJcbiAgICAgICAgbGV0IHRvdGFsSGVpZ2h0OiBudW1iZXIgPSAwO1xyXG4gICAgICAgIGxldCBuYXRpdmVFbGU6IEVsZW1lbnQgPSBfdmNyLmVsZW1lbnQubmF0aXZlRWxlbWVudDtcclxuICAgICAgICBsZXQgaGVhZGVyQ29udGFpbmVyOiBFbGVtZW50ID0gbmF0aXZlRWxlLnF1ZXJ5U2VsZWN0b3IoJy5hZy1oZWFkZXItY29udGFpbmVyJyk7XHJcbiAgICAgICAgaWYgKG5hdGl2ZUVsZSA9PT0gbnVsbCB8fCBoZWFkZXJDb250YWluZXIgPT09IG51bGwpIHJldHVybiB0b3RhbEhlaWdodDtcclxuICAgICAgICB0b3RhbEhlaWdodCArPSBNYXRoLmNlaWwoaGVhZGVyQ29udGFpbmVyLmdldEJvdW5kaW5nQ2xpZW50UmVjdCgpLmhlaWdodCk7XHJcbiAgICAgICAgdG90YWxIZWlnaHQgKz0gTWF0aC5jZWlsKG5hdGl2ZUVsZS5xdWVyeVNlbGVjdG9yKCcuYWctYm9keS1jb250YWluZXInKS5nZXRCb3VuZGluZ0NsaWVudFJlY3QoKS5oZWlnaHQpO1xyXG5cclxuICAgICAgICBsZXQgcGFnaW5hdGlvbkJvdHRvbTogRWxlbWVudCA9IG5hdGl2ZUVsZS5xdWVyeVNlbGVjdG9yKCcjc291dGgnKTtcclxuICAgICAgICBpZiAocGFnaW5hdGlvbkJvdHRvbSAhPT0gbnVsbCkge1xyXG4gICAgICAgICAgICB0b3RhbEhlaWdodCArPSBNYXRoLmNlaWwocGFnaW5hdGlvbkJvdHRvbS5nZXRCb3VuZGluZ0NsaWVudFJlY3QoKS5oZWlnaHQpO1xyXG4gICAgICAgIH1cclxuICAgICAgICB0b3RhbEhlaWdodCArPSA4O1xyXG4gICAgICAgIHJldHVybiB0b3RhbEhlaWdodDtcclxuICAgIH1cclxuXHJcbiAgICBzZXJ2ZXJTb3J0QW5kRmlsdGVyKF9kYXRhOiBBcnJheTxhbnk+LCBfc29ydE1vZGVsOiBBcnJheTxhbnk+LCBfZmlsdGVyTW9kZWw6IGFueSkge1xyXG4gICAgICAgIHJldHVybiB0aGlzLl9zZXJ2ZXJTb3J0RGF0YShfc29ydE1vZGVsLCB0aGlzLl9zZXJ2ZXJGaWx0ZXJEYXRhKF9maWx0ZXJNb2RlbCwgX2RhdGEpKTtcclxuICAgIH1cclxuXHJcbiAgICBjaGVja0NvbHVtbkRlZihfY29sRGVmOiBhbnksIF9oYXNDaGVja2JveDogYm9vbGVhbiwgX2hhc1JhZGlvOiBib29sZWFuKTogYW55IHtcclxuICAgICAgICBpZiAoX2hhc0NoZWNrYm94KSB7XHJcbiAgICAgICAgICAgIF9jb2xEZWZbJ2FnLWNoZWNrYm94J10gPSB7XHJcbiAgICAgICAgICAgICAgICBjb25maWc6IHtcclxuICAgICAgICAgICAgICAgICAgICBjaGVja2JveDogdHJ1ZVxyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9O1xyXG4gICAgICAgIH1cclxuICAgICAgICBlbHNlIGlmIChfaGFzUmFkaW8pIHtcclxuICAgICAgICAgICAgX2NvbERlZlsnYWctcmFkaW8nXSA9IHtcclxuICAgICAgICAgICAgICAgIGNvbmZpZzoge1xyXG4gICAgICAgICAgICAgICAgICAgIHJhZGlvOiB0cnVlXHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH07XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICByZXR1cm4gX2NvbERlZjtcclxuICAgIH1cclxuXHJcbiAgICBnZXRBY3Rpb25MaXN0KF9yb3dEYXRhOiBhbnksIF9jb2x1bW46IEFycmF5PENvbHVtbj4pOiBBcnJheTxhbnk+IHtcclxuICAgICAgICBpZiAodHlwZW9mIF9yb3dEYXRhLmFjdGlvbiAhPT0gJ3VuZGVmaW5lZCcpIHtcclxuICAgICAgICAgICAgcmV0dXJuIF9yb3dEYXRhLmFjdGlvbjtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIGZvciAobGV0IGk6IG51bWJlciA9IDA7IGkgPCBfY29sdW1uLmxlbmd0aDsgaSsrKSB7XHJcbiAgICAgICAgICAgIGxldCBjb2xEZWY6IGFueSA9IF9jb2x1bW5baV0uZ2V0Q29sRGVmKCk7XHJcbiAgICAgICAgICAgIGlmICh0eXBlb2YgY29sRGVmLmNvbmZpZyAhPT0gJ3VuZGVmaW5lZCcgJiZcclxuICAgICAgICAgICAgICAgIHR5cGVvZiBjb2xEZWYuY29uZmlnLmFjdGlvbiAhPT0gJ3VuZGVmaW5lZCcgJiZcclxuICAgICAgICAgICAgICAgIGNvbERlZi5jb25maWcuYWN0aW9uKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIGNvbERlZi5jb25maWcuaXRlbXM7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICAgICAgcmV0dXJuIFtdO1xyXG4gICAgfVxyXG5cclxuICAgIGNoZWNrSXNUYXJnZXRDbGlja2FibGUoX3Jvd0V2ZW50OiBFdmVudCk6IGJvb2xlYW4ge1xyXG4gICAgICAgIGxldCBlbGVtZW50OiBIVE1MRWxlbWVudCA9IDxIVE1MRWxlbWVudD5fcm93RXZlbnQudGFyZ2V0O1xyXG4gICAgICAgIGxldCBjaGVja0xpc3Q6IEFycmF5PHN0cmluZz4gPSBbJ2FjdGlvbi1idG4nLCAnY2hlY2tib3gtcmFkaW8taW5wdXQnLCAnZmEtY2hldnJvbi1kb3duJ107XHJcblxyXG4gICAgICAgIGZvciAobGV0IGk6IG51bWJlciA9IDA7IGkgPCBjaGVja0xpc3QubGVuZ3RoOyBpKyspIHtcclxuICAgICAgICAgICAgaWYgKGVsZW1lbnQuY2xhc3NMaXN0LmNvbnRhaW5zKGNoZWNrTGlzdFtpXSkpIHtcclxuICAgICAgICAgICAgICAgIHJldHVybiBmYWxzZTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgcmV0dXJuIHRydWU7XHJcbiAgICB9XHJcblxyXG4gICAgY2hlY2tJc0NvbmZpZ0NvbHVtbihfY29sRGVmOiBhbnkpOiBib29sZWFuIHtcclxuICAgICAgICBpZiAoX2NvbERlZi5jZWxsQ2xhc3MuaW5kZXhPZignYWctY2hlY2tib3gtcmFkaW8nKSAhPT0gLTEpIHtcclxuICAgICAgICAgICAgcmV0dXJuIHRydWU7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICBpZiAodHlwZW9mIF9jb2xEZWYuY29uZmlnICE9PSAndW5kZWZpbmVkJyAmJlxyXG4gICAgICAgICAgICAoKHR5cGVvZiBfY29sRGVmLmNvbmZpZy5waG90byAhPT0gJ3VuZGVmaW5lZCcgJiYgX2NvbERlZi5jb25maWcucGhvdG8pIHx8XHJcbiAgICAgICAgICAgICAodHlwZW9mIF9jb2xEZWYuY29uZmlnLmFjdGlvbiAhPT0gJ3VuZGVmaW5lZCcgJiYgX2NvbERlZi5jb25maWcuYWN0aW9uKSlcclxuICAgICAgICApIHtcclxuICAgICAgICAgICAgcmV0dXJuIHRydWU7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICByZXR1cm4gZmFsc2U7XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfc2V0Q29sdW1uQ29uZmlnKF9jb2x1bW46IGFueSwgX2NvbmZpZzogYW55LCAvKl9kYXRhU3ZjOiBLZERhdGFTdmMsKi8gX3JvdXRlcj86IFJvdXRlcik6IGFueSB7XHJcbiAgICAgICAgbGV0IHVwZGF0ZWRDb2x1bW46IGFueSA9ICg8YW55Pk9iamVjdCkuYXNzaWduKHt9LCBfY29sdW1uKTtcclxuXHJcbiAgICAgICAgLy8gaWYgKHR5cGVvZiBfY29uZmlnLmlucHV0ICE9PSAndW5kZWZpbmVkJyAmJiBfY29uZmlnLmlucHV0KSB7XHJcbiAgICAgICAgLy8gICAgIHVwZGF0ZWRDb2x1bW4uc3VwcHJlc3NNZW51ID0gdHJ1ZTtcclxuICAgICAgICAvLyAgICAgdXBkYXRlZENvbHVtbi5zdXBwcmVzc1NvcnRpbmcgPSB0cnVlO1xyXG4gICAgICAgIC8vICAgICB1cGRhdGVkQ29sdW1uLmNlbGxDbGFzcyA9ICdhZy1mb3JtJztcclxuICAgICAgICAvLyAgICAgdXBkYXRlZENvbHVtbi5jZWxsUmVuZGVyZXJGcmFtZXdvcmsgPSBLZEFHRm9ybTtcclxuICAgICAgICAvLyB9XHJcblxyXG4gICAgICAgIC8vIGVsc2UgaWYgKHR5cGVvZiBfY29uZmlnLmFjdGlvbiAhPT0gJ3VuZGVmaW5lZCcgJiYgX2NvbmZpZy5hY3Rpb24pIHtcclxuICAgICAgICAvLyAgICAgdXBkYXRlZENvbHVtbi5zdXBwcmVzc01lbnUgPSB0cnVlO1xyXG4gICAgICAgIC8vICAgICB1cGRhdGVkQ29sdW1uLnN1cHByZXNzU29ydGluZyA9IHRydWU7XHJcbiAgICAgICAgLy8gICAgIHVwZGF0ZWRDb2x1bW4uc3VwcHJlc3NTaXplVG9GaXQgPSB0cnVlO1xyXG4gICAgICAgIC8vICAgICB1cGRhdGVkQ29sdW1uLndpZHRoID0gMTIwO1xyXG4gICAgICAgIC8vICAgICB1cGRhdGVkQ29sdW1uLmNlbGxDbGFzcyA9ICdkcm9wZG93bi1hY3Rpb24nO1xyXG4gICAgICAgIC8vICAgICB1cGRhdGVkQ29sdW1uLmNlbGxSZW5kZXJlckZyYW1ld29yayA9IEtkQUdEcm9wZG93bjtcclxuXHJcbiAgICAgICAgLy8gICAgIHRoaXMuX3Jlc2l6ZWFibGVDb2wtLTtcclxuICAgICAgICAvLyB9XHJcblxyXG4gICAgICAgIC8vIGVsc2UgaWYgKHR5cGVvZiBfY29uZmlnLnBob3RvICE9PSAndW5kZWZpbmVkJyAmJiBfY29uZmlnLnBob3RvKSB7XHJcbiAgICAgICAgLy8gICAgIHVwZGF0ZWRDb2x1bW4uc3VwcHJlc3NNZW51ID0gdHJ1ZTtcclxuICAgICAgICAvLyAgICAgdXBkYXRlZENvbHVtbi5zdXBwcmVzc1NvcnRpbmcgPSB0cnVlO1xyXG4gICAgICAgIC8vICAgICB1cGRhdGVkQ29sdW1uLnN1cHByZXNzU2l6ZVRvRml0ID0gdHJ1ZTtcclxuICAgICAgICAvLyAgICAgdXBkYXRlZENvbHVtbi53aWR0aCA9IDEwMDtcclxuICAgICAgICAvLyAgICAgdXBkYXRlZENvbHVtbi5jZWxsQ2xhc3MgPSAnYWctcGhvdG8nO1xyXG4gICAgICAgIC8vICAgICB1cGRhdGVkQ29sdW1uLmNlbGxSZW5kZXJlckZyYW1ld29yayA9IEtkQUdQaG90bztcclxuXHJcbiAgICAgICAgLy8gICAgIHRoaXMuX3Jlc2l6ZWFibGVDb2wtLTtcclxuICAgICAgICAvLyB9XHJcblxyXG4gICAgICAgIC8vIGVsc2UgaWYgKHR5cGVvZiBfY29uZmlnLmNoZWNrYm94ICE9PSAndW5kZWZpbmVkJyAmJiBfY29uZmlnLmNoZWNrYm94KSB7XHJcbiAgICAgICAgLy8gICAgIHVwZGF0ZWRDb2x1bW4uc3VwcHJlc3NNZW51ID0gdHJ1ZTtcclxuICAgICAgICAvLyAgICAgdXBkYXRlZENvbHVtbi5zdXBwcmVzc1NvcnRpbmcgPSB0cnVlO1xyXG4gICAgICAgIC8vICAgICB1cGRhdGVkQ29sdW1uLnN1cHByZXNzU2l6ZVRvRml0ID0gdHJ1ZTtcclxuICAgICAgICAvLyAgICAgdXBkYXRlZENvbHVtbi53aWR0aCA9IDUwO1xyXG4gICAgICAgIC8vICAgICB1cGRhdGVkQ29sdW1uLmNlbGxDbGFzcyA9ICdhZy1kZWZhdWx0IGFnLWNoZWNrYm94LXJhZGlvJztcclxuICAgICAgICAvLyAgICAgdXBkYXRlZENvbHVtbi5jb2xJZCA9ICdjaGVja2JveCc7XHJcbiAgICAgICAgLy8gICAgIHVwZGF0ZWRDb2x1bW4uY2VsbFJlbmRlcmVyRnJhbWV3b3JrID0gS2RBR0NoZWNrYm94UmFkaW87XHJcbiAgICAgICAgLy8gICAgIHVwZGF0ZWRDb2x1bW4uaGVhZGVyQ29tcG9uZW50RnJhbWV3b3JrID0gS2RBR0NoZWNrYm94UmFkaW87XHJcblxyXG4gICAgICAgIC8vICAgICB0aGlzLl9yZXNpemVhYmxlQ29sLS07XHJcbiAgICAgICAgLy8gfVxyXG5cclxuICAgICAgICAvLyBlbHNlIGlmICh0eXBlb2YgX2NvbmZpZy5yYWRpbyAhPT0gJ3VuZGVmaW5lZCcgJiYgX2NvbmZpZy5yYWRpbykge1xyXG4gICAgICAgIC8vICAgICB1cGRhdGVkQ29sdW1uLnN1cHByZXNzTWVudSA9IHRydWU7XHJcbiAgICAgICAgLy8gICAgIHVwZGF0ZWRDb2x1bW4uc3VwcHJlc3NTb3J0aW5nID0gdHJ1ZTtcclxuICAgICAgICAvLyAgICAgdXBkYXRlZENvbHVtbi5zdXBwcmVzc1NpemVUb0ZpdCA9IHRydWU7XHJcbiAgICAgICAgLy8gICAgIHVwZGF0ZWRDb2x1bW4ud2lkdGggPSA1MDtcclxuICAgICAgICAvLyAgICAgdXBkYXRlZENvbHVtbi5jZWxsQ2xhc3MgPSAnYWctZGVmYXVsdCBhZy1jaGVja2JveC1yYWRpbyc7XHJcbiAgICAgICAgLy8gICAgIHVwZGF0ZWRDb2x1bW4uY29sSWQgPSAncmFkaW8nO1xyXG4gICAgICAgIC8vICAgICB1cGRhdGVkQ29sdW1uLmNlbGxSZW5kZXJlckZyYW1ld29yayA9IEtkQUdDaGVja2JveFJhZGlvO1xyXG4gICAgICAgIC8vICAgICB1cGRhdGVkQ29sdW1uLmhlYWRlck5hbWUgPSAnJztcclxuXHJcbiAgICAgICAgLy8gICAgIHRoaXMuX3Jlc2l6ZWFibGVDb2wtLTtcclxuICAgICAgICAvLyB9XHJcblxyXG4gICAgICAgIC8vIGVsc2UgaWYgKHR5cGVvZiBfY29uZmlnLmRpc3BsYXlGcm9tICE9PSAndW5kZWZpbmVkJyAmJiBfY29uZmlnLmRpc3BsYXlGcm9tKSB7XHJcbiAgICAgICAgICAgIC8vIHVwZGF0ZWRDb2x1bW4uY2VsbFJlbmRlcmVyID0gKHBhcmFtczogYW55KTogYW55ID0+IHtcclxuICAgICAgICAgICAgLy8gICAgIGlmICh0eXBlb2YgcGFyYW1zLnZhbHVlICE9PSAndW5kZWZpbmVkJykge1xyXG4gICAgICAgICAgICAvLyAgICAgICAgIGlmIChwYXJhbXMudmFsdWUgaW5zdGFuY2VvZiBBcnJheSkge1xyXG4gICAgICAgICAgICAvLyAgICAgICAgICAgICBsZXQgZGlzcGxheUFycmF5OiBBcnJheTxhbnk+ID0gW107XHJcbiAgICAgICAgICAgIC8vICAgICAgICAgICAgIGZvciAobGV0IGk6IG51bWJlciA9IDA7IGkgPCBwYXJhbXMudmFsdWUubGVuZ3RoOyBpKyspIHtcclxuICAgICAgICAgICAgLy8gICAgICAgICAgICAgICAgIGxldCBkaXNwbGF5OiBhbnkgPSB0aGlzLl9kYXRhU3ZjLmdldERhdGFWYWx1ZShwYXJhbXMudmFsdWVbaV0sIF9jb25maWcuZGlzcGxheUZyb20pO1xyXG4gICAgICAgICAgICAvLyAgICAgICAgICAgICAgICAgaWYgKGRpc3BsYXkgIT09IG51bGwpIGRpc3BsYXlBcnJheS5wdXNoKGRpc3BsYXkpO1xyXG4gICAgICAgICAgICAvLyAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIC8vICAgICAgICAgICAgIHJldHVybiBkaXNwbGF5QXJyYXk7XHJcbiAgICAgICAgICAgIC8vICAgICAgICAgfVxyXG4gICAgICAgICAgICAvLyAgICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICAvLyAgICAgICAgICAgICBsZXQgZGlzcGxheTogYW55ID0gdGhpcy5fZGF0YVN2Yy5nZXREYXRhVmFsdWUocGFyYW1zLnZhbHVlLCBfY29uZmlnLmRpc3BsYXlGcm9tKTtcclxuICAgICAgICAgICAgLy8gICAgICAgICAgICAgaWYgKGRpc3BsYXkgIT09IG51bGwpIHJldHVybiBkaXNwbGF5O1xyXG4gICAgICAgICAgICAvLyAgICAgICAgIH1cclxuICAgICAgICAgICAgLy8gICAgIH1cclxuICAgICAgICAgICAgLy8gICAgIHJldHVybiBwYXJhbXMudmFsdWU7XHJcbiAgICAgICAgICAgIC8vIH1cclxuICAgICAgICAvLyB9XHJcblxyXG4gICAgICAgIHJldHVybiB1cGRhdGVkQ29sdW1uO1xyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX3NlcnZlckZpbHRlckRhdGEoX2ZpbHRlck1vZGVsOiBhbnksIF9kYXRhOiBBcnJheTxhbnk+KTogQXJyYXk8YW55PiB7XHJcbiAgICAgICAgbGV0IGZpbHRlcmVkRGF0YTogQXJyYXk8YW55PiA9IF9kYXRhLnNsaWNlKCk7XHJcblxyXG4gICAgICAgIGlmICh0eXBlb2YgX2ZpbHRlck1vZGVsID09PSAndW5kZWZpbmVkJyB8fCBPYmplY3Qua2V5cyhfZmlsdGVyTW9kZWwpLmxlbmd0aCA9PT0gMCkge1xyXG4gICAgICAgICAgICByZXR1cm4gZmlsdGVyZWREYXRhO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgbGV0IHVwZGF0ZWREYXRhOiBBcnJheTxhbnk+ID0gW107XHJcbiAgICAgICAgZm9yIChsZXQga2V5IGluIF9maWx0ZXJNb2RlbCkge1xyXG4gICAgICAgICAgICBpZiAoX2ZpbHRlck1vZGVsLmhhc093blByb3BlcnR5KGtleSkpIHtcclxuICAgICAgICAgICAgICAgIGZvciAobGV0IGs6IG51bWJlciA9IDA7IGsgPCBfZmlsdGVyTW9kZWxba2V5XS5sZW5ndGg7IGsrKykge1xyXG4gICAgICAgICAgICAgICAgICAgIGZvciAobGV0IGo6IG51bWJlciA9IDA7IGogPCBfZGF0YS5sZW5ndGg7IGorKykge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAoX2RhdGFbal1ba2V5XSA9PT0gX2ZpbHRlck1vZGVsW2tleV1ba10pIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHVwZGF0ZWREYXRhLnB1c2goX2RhdGFbal0pO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICByZXR1cm4gdXBkYXRlZERhdGE7XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfc2VydmVyU29ydERhdGEoX3NvcnRNb2RlbDogQXJyYXk8YW55PiwgX2RhdGE6IEFycmF5PGFueT4pOiBBcnJheTxhbnk+IHtcclxuICAgICAgICBsZXQgc29ydGVkRGF0YTogQXJyYXk8YW55PiA9IF9kYXRhLnNsaWNlKCk7XHJcblxyXG4gICAgICAgIGlmICh0eXBlb2YgX3NvcnRNb2RlbCA9PT0gJ3VuZGVmaW5lZCcgfHwgX3NvcnRNb2RlbC5sZW5ndGggPT09IDApIHtcclxuICAgICAgICAgICAgcmV0dXJuIHNvcnRlZERhdGE7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICBzb3J0ZWREYXRhLnNvcnQoKGE6IGFueSwgYjogYW55KTogbnVtYmVyID0+IHtcclxuICAgICAgICAgICAgZm9yIChsZXQgaTogbnVtYmVyID0gMDsgaSA8IF9zb3J0TW9kZWwubGVuZ3RoOyBpKyspIHtcclxuICAgICAgICAgICAgICAgIGxldCBzb3J0Q29sTW9kZWw6IGFueSA9IF9zb3J0TW9kZWxbaV07XHJcbiAgICAgICAgICAgICAgICBsZXQgdmFsQTogYW55ID0gYVtzb3J0Q29sTW9kZWwuY29sSWRdO1xyXG4gICAgICAgICAgICAgICAgbGV0IHZhbEI6IGFueSA9IGJbc29ydENvbE1vZGVsLmNvbElkXTtcclxuXHJcbiAgICAgICAgICAgICAgICBpZiAodmFsQSA9PT0gdmFsQikge1xyXG4gICAgICAgICAgICAgICAgICAgIGNvbnRpbnVlO1xyXG4gICAgICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgICAgIGxldCBkaXJlY3Rpb24gPSAoc29ydENvbE1vZGVsLnNvcnQgPT09ICdhc2MnKSA/IDEgOiAtMTtcclxuXHJcbiAgICAgICAgICAgICAgICBpZiAodmFsQSA+IHZhbEIpIHtcclxuICAgICAgICAgICAgICAgICAgICByZXR1cm4gZGlyZWN0aW9uO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgZWxzZSB7XHJcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIGRpcmVjdGlvbiAqIC0xO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgcmV0dXJuIDA7XHJcbiAgICAgICAgfSk7XHJcbiAgICAgICAgcmV0dXJuIHNvcnRlZERhdGE7XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfY2hlY2tHcmlkSGVpZ2h0KF9jb25maWc6IGFueSk6IG51bWJlciB8IHN0cmluZyB7XHJcbiAgICAgICAgbGV0IGRlZmF1bHRIZWlnaHQ6IG51bWJlciA9IDYwMDtcclxuXHJcbiAgICAgICAgaWYgKHR5cGVvZiBfY29uZmlnID09PSAndW5kZWZpbmVkJykge1xyXG4gICAgICAgICAgICByZXR1cm4gZGVmYXVsdEhlaWdodDtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIGVsc2UgaWYgKHR5cGVvZiBfY29uZmlnLmdyaWRIZWlnaHQgIT09ICd1bmRlZmluZWQnICYmXHJcbiAgICAgICAgICAgIHR5cGVvZiBfY29uZmlnLmdyaWRIZWlnaHQgPT09ICdzdHJpbmcnICYmXHJcbiAgICAgICAgICAgIF9jb25maWcuZ3JpZEhlaWdodCA9PT0gJ2F1dG8nKSB7XHJcbiAgICAgICAgICAgICAgICByZXR1cm4gX2NvbmZpZy5ncmlkSGVpZ2h0O1xyXG4gICAgICAgIH1cclxuICAgICAgICBlbHNlIGlmICh0eXBlb2YgX2NvbmZpZy5ncmlkSGVpZ2h0ICE9PSAndW5kZWZpbmVkJyAmJlxyXG4gICAgICAgICAgICB0eXBlb2YgX2NvbmZpZy5ncmlkSGVpZ2h0ID09PSAnbnVtYmVyJykge1xyXG4gICAgICAgICAgICAgICAgcmV0dXJuIF9jb25maWcuZ3JpZEhlaWdodDtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIHJldHVybiBkZWZhdWx0SGVpZ2h0O1xyXG4gICAgfVxyXG5cclxuICAgIC8vIHByaXZhdGUgX2NoZWNrUGFnaW5hdGlvbkRhdGEoX2NvbmZpZzogYW55LCBfbG9hZFR5cGU6IHN0cmluZyk6IGFueSB7XHJcbiAgICAvLyAgICAgaWYgKHR5cGVvZiBfY29uZmlnICE9PSAndW5kZWZpbmVkJyAmJlxyXG4gICAgLy8gICAgICAgICB0eXBlb2YgX2NvbmZpZy5wYWdpbmF0aW9uU2V0RGF0YSAhPT0gJ3VuZGVmaW5lZCcgJiZcclxuICAgIC8vICAgICAgICAgX2xvYWRUeXBlID09PSAnc2VydmVyLXBhZ2luYXRpb24nKSB7XHJcbiAgICAvLyAgICAgICAgICAgICByZXR1cm4gX2NvbmZpZy5wYWdpbmF0aW9uU2V0RGF0YTtcclxuICAgIC8vICAgICB9XHJcbiAgICAvLyAgICAgZWxzZSBpZiAodHlwZW9mIF9jb25maWcgIT09ICd1bmRlZmluZWQnICYmXHJcbiAgICAvLyAgICAgICAgIHR5cGVvZiBfY29uZmlnLnBhZ2luYXRpb25TZXREYXRhID09PSAndW5kZWZpbmVkJyAmJlxyXG4gICAgLy8gICAgICAgICBfbG9hZFR5cGUgPT09ICdzZXJ2ZXItcGFnaW5hdGlvbicpIHtcclxuICAgIC8vICAgICAgICAgICAgIGNvbnNvbGUuZXJyb3IoJ1NlcnZlciBwYWdpbmF0aW9uIHJlcXVpcmVzIGNhbGxiYWNrIHRvIHJldHJpZXZlIGRhdGEuIFBsZWFzZSBwcm92aWRlIHRoZSBjYWxsYmFjayBmdW5jdGlvbi4nKTtcclxuICAgIC8vICAgICB9XHJcblxyXG4gICAgLy8gICAgIHJldHVybiB1bmRlZmluZWQ7XHJcbiAgICAvLyB9XHJcblxyXG4gICAgcHJpdmF0ZSBfY2hlY2tQYWdpbmF0aW9uVHlwZShfbG9hZFR5cGU6IHN0cmluZyk6IHN0cmluZyB7XHJcbiAgICAgICAgaWYgKF9sb2FkVHlwZSA9PT0gJ2luZmluaXRlJykgcmV0dXJuICdpbmZpbml0ZSc7XHJcbiAgICAgICAgaWYgKF9sb2FkVHlwZSA9PT0gJ3NlcnZlci1wYWdpbmF0aW9uJyB8fCBfbG9hZFR5cGUgPT09ICdvbmVzaG90LXBhZ2luYXRpb24nKSByZXR1cm4gJ3BhZ2luYXRpb24nO1xyXG4gICAgICAgIHJldHVybiAnJztcclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF9jaGVja0xvYWRUeXBlKF9jb25maWc6IGFueSk6IHN0cmluZyB7XHJcbiAgICAgICAgbGV0IGRlZmF1bHRMb2FkVHlwZTogc3RyaW5nID0gJ25vcm1hbCc7XHJcblxyXG4gICAgICAgIGlmICh0eXBlb2YgX2NvbmZpZyA9PT0gJ3VuZGVmaW5lZCcgfHwgdHlwZW9mIF9jb25maWcubG9hZFR5cGUgPT09ICd1bmRlZmluZWQnKSB7XHJcbiAgICAgICAgICAgIHJldHVybiBkZWZhdWx0TG9hZFR5cGU7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICBpZiAoX2NvbmZpZy5sb2FkVHlwZSA9PT0gJ25vcm1hbCcgfHxcclxuICAgICAgICAgICAgX2NvbmZpZy5sb2FkVHlwZSA9PT0gJ3NlcnZlci1wYWdpbmF0aW9uJyB8fFxyXG4gICAgICAgICAgICBfY29uZmlnLmxvYWRUeXBlID09PSAndmlydHVhbCcgfHxcclxuICAgICAgICAgICAgX2NvbmZpZy5sb2FkVHlwZSA9PT0gJ29uZXNob3QtcGFnaW5hdGlvbicpIHtcclxuICAgICAgICAgICAgICAgIHJldHVybiBfY29uZmlnLmxvYWRUeXBlO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgcmV0dXJuIGRlZmF1bHRMb2FkVHlwZTtcclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF9jaGVja1BhZ2VzaXplKF9jb25maWc6IGFueSwgX2xvYWRUeXBlOiBzdHJpbmcpOiBudW1iZXIge1xyXG4gICAgICAgIGlmIChfbG9hZFR5cGUgPT09ICdub3JtYWwnKSByZXR1cm4gLTE7XHJcbiAgICAgICAgaWYgKHR5cGVvZiBfY29uZmlnICE9PSAndW5kZWZpbmVkJyAmJiB0eXBlb2YgX2NvbmZpZy5wYWdlc2l6ZSAhPT0gJ3VuZGVmaW5lZCcpIHJldHVybiBfY29uZmlnLnBhZ2VzaXplO1xyXG4gICAgICAgIHJldHVybiAyNTtcclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF9nZXRSb3dIZWlnaHQoX3BhcmFtczogYW55KTogbnVtYmVyIHtcclxuICAgICAgICBsZXQgZ3JpZE9wdGlvbnM6IGFueSA9IHRoaXM7XHJcbiAgICAgICAgbGV0IGNvbERlZjogQXJyYXk8YW55PiA9IGdyaWRPcHRpb25zLmNvbHVtbkRlZnM7XHJcbiAgICAgICAgbGV0IHJvd0hlaWdodDogbnVtYmVyID0gNTA7XHJcbiAgICAgICAgZm9yIChsZXQgaTogbnVtYmVyID0gMDsgaSA8IGNvbERlZi5sZW5ndGg7IGkrKykge1xyXG4gICAgICAgICAgICBpZiAodHlwZW9mIGNvbERlZltpXS5jb25maWcgIT09ICd1bmRlZmluZWQnKSB7XHJcbiAgICAgICAgICAgICAgICBpZiAodHlwZW9mIGNvbERlZltpXS5jb25maWcucGhvdG8gIT09ICd1bmRlZmluZWQnICYmIGNvbERlZltpXS5jb25maWcucGhvdG8pIHJldHVybiAxMjA7XHJcbiAgICAgICAgICAgICAgICBlbHNlIGlmICh0eXBlb2YgY29sRGVmW2ldLmNvbmZpZy50ZXh0YXJlYSAhPT0gJ3VuZGVmaW5lZCcgJiYgY29sRGVmW2ldLmNvbmZpZy50ZXh0YXJlYSkgcmV0dXJuIDEyMDtcclxuICAgICAgICAgICAgICAgIGVsc2UgaWYgKHR5cGVvZiBjb2xEZWZbaV0uY29uZmlnLmlucHV0ICE9PSAndW5kZWZpbmVkJyAmJiBjb2xEZWZbaV0uY29uZmlnLmlucHV0KSB7XHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKF9wYXJhbXMuZGF0YVtjb2xEZWZbaV0uY29sSWRdIGluc3RhbmNlb2YgQXJyYXkpIHJldHVybiByb3dIZWlnaHQgKiBfcGFyYW1zLmRhdGFbY29sRGVmW2ldLmNvbElkXS5sZW5ndGg7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICAgICAgcmV0dXJuIDUwO1xyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX2NoZWNrQnRuQ29uZmlnKF9idXR0b25MaXN0OiBBcnJheTxhbnk+KTogQXJyYXk8YW55PiB7XHJcbiAgICAgICAgbGV0IHVwZGF0ZWRCdG5Db25maWc6IEFycmF5PGFueT4gPSBbXTtcclxuICAgICAgICBmb3IgKGxldCBpOiBudW1iZXIgPSAwOyBpIDwgX2J1dHRvbkxpc3QubGVuZ3RoOyBpKyspIHtcclxuICAgICAgICAgICAgdXBkYXRlZEJ0bkNvbmZpZy5wdXNoKHRoaXMuX2NoZWNrQnV0dG9uKF9idXR0b25MaXN0W2ldKSk7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIHJldHVybiB1cGRhdGVkQnRuQ29uZmlnO1xyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX2NoZWNrQnV0dG9uKF9idXR0b25JdGVtOiBhbnkpOiBhbnkge1xyXG4gICAgICAgIGxldCBkZWZhdWx0QnV0dG9uOiBhbnkgPSB7XHJcbiAgICAgICAgICAgIHR5cGU6IG51bGwsXHJcbiAgICAgICAgICAgIGxhYmVsOiAnJyxcclxuICAgICAgICAgICAgaWNvbjogJycsXHJcbiAgICAgICAgICAgIGNvbmZpZzogbnVsbCxcclxuICAgICAgICAgICAgY2FsbGJhY2s6IG51bGwsXHJcbiAgICAgICAgICAgIHBhdGg6IG51bGxcclxuICAgICAgICB9O1xyXG4gICAgICAgIHJldHVybiBPYmplY3QuYXNzaWduKGRlZmF1bHRCdXR0b24sIF9idXR0b25JdGVtKTtcclxuICAgIH1cclxufVxyXG4iXX0=