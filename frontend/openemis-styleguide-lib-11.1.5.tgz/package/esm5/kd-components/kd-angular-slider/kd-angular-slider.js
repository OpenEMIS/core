import { __decorate, __metadata } from "tslib";
import { Component, Input, EventEmitter, Output, } from '@angular/core';
import { KdSliderSvc } from './kd-angular-slider-svc';
var KdSlider = /** @class */ (function () {
    function KdSlider(_sliderSvc) {
        this._sliderSvc = _sliderSvc;
        this.config = {};
        this.value = 0;
        this.isPlay = false;
        this.wrapperStyle = {};
        this.apiInternal = {};
        this._defaultConfig = {
            orientation: 'horizontal',
            range: false,
            max: 100,
            min: 0,
            step: 1,
            disabled: false,
            autoplay: false,
            autoplayStep: 1,
        };
        this.sliderValue = 0;
        this.result = new EventEmitter();
    }
    KdSlider.prototype.ngOnInit = function () {
        this._setConfig(this.sliderConfig);
        this.value = this._setData(this.sliderValue, this.config);
        this._outputValue = this.value;
        this.sliderId = typeof this.id !== 'undefined' ? this.id : 'slider';
        this._initApi();
    };
    KdSlider.prototype.ngOnChanges = function (_simpleChanges) {
        if (_simpleChanges.hasOwnProperty('sliderConfig') && !_simpleChanges['sliderConfig'].firstChange) {
            if (_simpleChanges['sliderConfig'].currentValue === this.config)
                return;
            this._setConfig(_simpleChanges['sliderConfig'].currentValue);
        }
        if (_simpleChanges.hasOwnProperty('sliderValue') && !_simpleChanges['sliderValue'].firstChange) {
            if (_simpleChanges['sliderValue'].currentValue === this.value)
                return;
            this.value = this._setData(_simpleChanges['sliderValue'].currentValue, this.config);
            this._outputValue = this.value;
        }
        if (_simpleChanges.hasOwnProperty('id') && !_simpleChanges['id'].firstChange) {
            if (_simpleChanges['id'].currentValue === this.sliderId)
                return;
            this.sliderId = typeof _simpleChanges['id'].currentValue !== 'undefined' ? _simpleChanges['id'].currentValue : 'slider';
        }
    };
    /** Emits a change event if the current value is different from the last emitted value. */
    KdSlider.prototype.emitChangeEvent = function (_result) {
        /**type === number | Array<number> | Object with at least the following properties:
        * {
        *   description?: string;
        *   value: string | number;
        * }
        * */
        this._outputValue = this.config.type && this.config.type === 'others' ? this.config.options[Math.round(_result.value)] : _result.value;
        if (_result.currentAction !== 'sliding')
            this.result.emit(this._outputValue);
        this.sideValueLabel = this._sliderSvc.setSideValueLabel(this._outputValue, this.config.sideValueLabelFormat);
    };
    /** Toggle autoplay */
    KdSlider.prototype.clickPlayBtn = function () {
        if (this.config.disabled)
            return;
        this.isPlay = this.isPlay ? false : true;
    };
    /** Update this.isPlay when end of slider is reached */
    KdSlider.prototype.endPlay = function (_end) {
        this.isPlay = _end ? false : true;
    };
    KdSlider.prototype._initApi = function () {
        var _this = this;
        if (typeof this.api !== 'undefined') {
            this.api.disable = function (_flag) {
                _this.config = Object.assign({}, _this.config, { disabled: _flag });
            };
            this.api.getSliderThumbValue = function () {
                return _this._outputValue;
            };
            this.api.setSliderThumbValue = function (_value, _thumbIndex) {
                var valueToUpdate = _value;
                if (Array.isArray(_value)) {
                    if (typeof _thumbIndex === 'undefined') {
                        console.log('please pass the _thumbIndex of which to update value to');
                        return;
                    }
                    valueToUpdate = _value[_thumbIndex];
                }
                if (_this.config.type === 'others') {
                    for (var i = 0; i < _this.sliderValue.length; ++i) {
                        if (_this.sliderValue[i].value === _value.value) {
                            valueToUpdate = i;
                            break;
                        }
                    }
                }
                _this.apiInternal.handleValue(valueToUpdate, _thumbIndex);
            };
        }
    };
    KdSlider.prototype._setConfig = function (_config) {
        this.config = Object.assign({}, this._defaultConfig, _config);
        if (this.config.width)
            this.wrapperStyle = { 'width': this.config.width };
        this._sliderSvc.config = this.config;
        this.sideValueLabel = this._sliderSvc.setSideValueLabel(this.sliderValue, this.config.sideValueLabelFormat);
    };
    KdSlider.prototype._setData = function (_value, _config) {
        var _this = this;
        if (_config.type === 'others') {
            var newValue = void 0;
            this.config.max = _config.options.length - 1;
            this.config.step = 1;
            this.config.min = 0;
            this._sliderSvc.config = this.config;
            for (var i = 0; i < _config.options.length; ++i) {
                if (_config.options[i].value === _value.value) {
                    newValue = i;
                    break;
                }
            }
            return newValue || 0;
        }
        if (!Array.isArray(_value)) {
            this.config.range = false;
            this._sliderSvc.config = this.config;
            return _value;
        }
        if (_config.range) {
            this.config.autoplay = false;
            var newValue = _value.map(function (el) {
                if (typeof el !== 'number')
                    el = parseFloat(el);
                return _this._sliderSvc.clamp(el, _this.config.min, _this.config.max);
            });
            return newValue;
        }
        return 0;
    };
    KdSlider.ctorParameters = function () { return [
        { type: KdSliderSvc }
    ]; };
    __decorate([
        Input(),
        __metadata("design:type", String)
    ], KdSlider.prototype, "id", void 0);
    __decorate([
        Input('value'),
        __metadata("design:type", Object)
    ], KdSlider.prototype, "sliderValue", void 0);
    __decorate([
        Input('config'),
        __metadata("design:type", Object)
    ], KdSlider.prototype, "sliderConfig", void 0);
    __decorate([
        Input(),
        __metadata("design:type", Object)
    ], KdSlider.prototype, "api", void 0);
    __decorate([
        Output(),
        __metadata("design:type", EventEmitter)
    ], KdSlider.prototype, "result", void 0);
    KdSlider = __decorate([
        Component({
            selector: 'kd-slider',
            template: "\n        <div class=\"kdx-slider-wrapper\" [id]=\"sliderId\" [ngStyle]=\"wrapperStyle\">\n            <div class=\"kdx-slider-container\" [ngClass]=\"{'kdx-slider-container-vertical': config.orientation === 'vertical'}\">\n                <button *ngIf=\"config.autoplay\" class=\"btn\" (click)=\"clickPlayBtn()\" [attr.disabled]=\"config.disabled? '': null\">\n                    <i class=\"play-icon fa\" aria-hidden=\"true\" [ngClass]=\"{'fa-play': !isPlay, 'fa-pause': isPlay}\"></i>\n                </button>\n                <kd-slider-content [value]=\"value\"\n                                   [config]=\"config\"\n                                   [isPlay]=\"isPlay\"\n                                   [api]=\"apiInternal\"\n                                   (endPlay)=\"endPlay($event)\"\n                                   (result)=\"emitChangeEvent($event)\">\n                </kd-slider-content>\n                <div *ngIf=\"config.sideValueLabel\" class=\"side-value-label kdx-label\">{{sideValueLabel}}</div>\n            </div>\n            <div *ngIf=\"config.startLabel\" class=\"kdx-label-container\">\n                <div *ngIf=\"config.startLabel\" class=\"kdx-label\" >\n                    {{config.startLabel}}\n                </div>\n                <div *ngIf=\"config.endLabel\" class=\"kdx-label\" >\n                    {{config.endLabel}}\n                </div>\n            </div>\n           <ng-content></ng-content>\n        </div>\n    ",
            providers: [KdSliderSvc],
            host: {
                'class': 'kdx-slider',
                '[class.kdx-slider-has-start-label]': 'config.startLabel',
            }
        }),
        __metadata("design:paramtypes", [KdSliderSvc])
    ], KdSlider);
    return KdSlider;
}());
export { KdSlider };
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoia2QtYW5ndWxhci1zbGlkZXIuanMiLCJzb3VyY2VSb290Ijoibmc6Ly9vcGVuZW1pcy1zdHlsZWd1aWRlLWxpYi8iLCJzb3VyY2VzIjpbImtkLWNvbXBvbmVudHMva2QtYW5ndWxhci1zbGlkZXIva2QtYW5ndWxhci1zbGlkZXIudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IjtBQUFBLE9BQU8sRUFDSCxTQUFTLEVBQ1QsS0FBSyxFQUlMLFlBQVksRUFDWixNQUFNLEdBQ1QsTUFBTSxlQUFlLENBQUM7QUFDdkIsT0FBTyxFQUFFLFdBQVcsRUFBRSxNQUFNLHlCQUF5QixDQUFDO0FBMEN0RDtJQTRCSSxrQkFBb0IsVUFBdUI7UUFBdkIsZUFBVSxHQUFWLFVBQVUsQ0FBYTtRQTFCcEMsV0FBTSxHQUFrQixFQUFFLENBQUM7UUFDM0IsVUFBSyxHQUFRLENBQUMsQ0FBQztRQUNmLFdBQU0sR0FBWSxLQUFLLENBQUM7UUFFeEIsaUJBQVksR0FBOEIsRUFBRSxDQUFDO1FBRTdDLGdCQUFXLEdBQXVCLEVBQUUsQ0FBQztRQUVwQyxtQkFBYyxHQUFrQjtZQUNwQyxXQUFXLEVBQUUsWUFBWTtZQUN6QixLQUFLLEVBQUUsS0FBSztZQUNaLEdBQUcsRUFBRSxHQUFHO1lBQ1IsR0FBRyxFQUFFLENBQUM7WUFDTixJQUFJLEVBQUUsQ0FBQztZQUNQLFFBQVEsRUFBRSxLQUFLO1lBQ2YsUUFBUSxFQUFFLEtBQUs7WUFDZixZQUFZLEVBQUUsQ0FBQztTQUNsQixDQUFDO1FBSWMsZ0JBQVcsR0FBUSxDQUFDLENBQUM7UUFHM0IsV0FBTSxHQUFxQixJQUFJLFlBQVksRUFBRSxDQUFDO0lBRVQsQ0FBQztJQUVoRCwyQkFBUSxHQUFSO1FBQ0ksSUFBSSxDQUFDLFVBQVUsQ0FBQyxJQUFJLENBQUMsWUFBWSxDQUFDLENBQUM7UUFDbkMsSUFBSSxDQUFDLEtBQUssR0FBRyxJQUFJLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxXQUFXLEVBQUUsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDO1FBQzFELElBQUksQ0FBQyxZQUFZLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQztRQUMvQixJQUFJLENBQUMsUUFBUSxHQUFHLE9BQU8sSUFBSSxDQUFDLEVBQUUsS0FBSyxXQUFXLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQztRQUNwRSxJQUFJLENBQUMsUUFBUSxFQUFFLENBQUM7SUFDcEIsQ0FBQztJQUVELDhCQUFXLEdBQVgsVUFBWSxjQUE2QjtRQUNyQyxJQUFJLGNBQWMsQ0FBQyxjQUFjLENBQUMsY0FBYyxDQUFDLElBQUksQ0FBQyxjQUFjLENBQUMsY0FBYyxDQUFDLENBQUMsV0FBVyxFQUFFO1lBQzlGLElBQUksY0FBYyxDQUFDLGNBQWMsQ0FBQyxDQUFDLFlBQVksS0FBSyxJQUFJLENBQUMsTUFBTTtnQkFBRSxPQUFPO1lBQ3hFLElBQUksQ0FBQyxVQUFVLENBQUMsY0FBYyxDQUFDLGNBQWMsQ0FBQyxDQUFDLFlBQVksQ0FBQyxDQUFDO1NBQ2hFO1FBQ0QsSUFBSSxjQUFjLENBQUMsY0FBYyxDQUFDLGFBQWEsQ0FBQyxJQUFJLENBQUMsY0FBYyxDQUFDLGFBQWEsQ0FBQyxDQUFDLFdBQVcsRUFBRTtZQUM1RixJQUFJLGNBQWMsQ0FBQyxhQUFhLENBQUMsQ0FBQyxZQUFZLEtBQUssSUFBSSxDQUFDLEtBQUs7Z0JBQUUsT0FBTztZQUN0RSxJQUFJLENBQUMsS0FBSyxHQUFHLElBQUksQ0FBQyxRQUFRLENBQUMsY0FBYyxDQUFDLGFBQWEsQ0FBQyxDQUFDLFlBQVksRUFBRSxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUM7WUFDcEYsSUFBSSxDQUFDLFlBQVksR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDO1NBQ2xDO1FBQ0QsSUFBSSxjQUFjLENBQUMsY0FBYyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsY0FBYyxDQUFDLElBQUksQ0FBQyxDQUFDLFdBQVcsRUFBRTtZQUMxRSxJQUFJLGNBQWMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxZQUFZLEtBQUssSUFBSSxDQUFDLFFBQVE7Z0JBQUUsT0FBTztZQUNoRSxJQUFJLENBQUMsUUFBUSxHQUFHLE9BQU8sY0FBYyxDQUFDLElBQUksQ0FBQyxDQUFDLFlBQVksS0FBSyxXQUFXLENBQUMsQ0FBQyxDQUFDLGNBQWMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxZQUFZLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQztTQUMzSDtJQUNMLENBQUM7SUFFRCwwRkFBMEY7SUFDbkYsa0NBQWUsR0FBdEIsVUFBdUIsT0FBa0Q7UUFDckU7Ozs7O1lBS0k7UUFDSixJQUFJLENBQUMsWUFBWSxHQUFHLElBQUksQ0FBQyxNQUFNLENBQUMsSUFBSSxJQUFJLElBQUksQ0FBQyxNQUFNLENBQUMsSUFBSSxLQUFLLFFBQVEsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLEtBQUssQ0FBQztRQUN2SSxJQUFJLE9BQU8sQ0FBQyxhQUFhLEtBQUssU0FBUztZQUFFLElBQUksQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxZQUFZLENBQUMsQ0FBQztRQUM3RSxJQUFJLENBQUMsY0FBYyxHQUFHLElBQUksQ0FBQyxVQUFVLENBQUMsaUJBQWlCLENBQUMsSUFBSSxDQUFDLFlBQVksRUFBRSxJQUFJLENBQUMsTUFBTSxDQUFDLG9CQUFvQixDQUFDLENBQUM7SUFDakgsQ0FBQztJQUVELHNCQUFzQjtJQUNmLCtCQUFZLEdBQW5CO1FBQ0ksSUFBSSxJQUFJLENBQUMsTUFBTSxDQUFDLFFBQVE7WUFBRSxPQUFPO1FBQ2pDLElBQUksQ0FBQyxNQUFNLEdBQUcsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUM7SUFDN0MsQ0FBQztJQUVELHVEQUF1RDtJQUNoRCwwQkFBTyxHQUFkLFVBQWUsSUFBYTtRQUN4QixJQUFJLENBQUMsTUFBTSxHQUFHLElBQUksQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUM7SUFDdEMsQ0FBQztJQUdPLDJCQUFRLEdBQWhCO1FBQUEsaUJBOEJDO1FBN0JHLElBQUksT0FBTyxJQUFJLENBQUMsR0FBRyxLQUFLLFdBQVcsRUFBRTtZQUNqQyxJQUFJLENBQUMsR0FBRyxDQUFDLE9BQU8sR0FBRyxVQUFDLEtBQWM7Z0JBQzlCLEtBQUksQ0FBQyxNQUFNLEdBQUcsTUFBTSxDQUFDLE1BQU0sQ0FBQyxFQUFFLEVBQUUsS0FBSSxDQUFDLE1BQU0sRUFBRSxFQUFFLFFBQVEsRUFBRSxLQUFLLEVBQUUsQ0FBQyxDQUFDO1lBQ3RFLENBQUMsQ0FBQztZQUNGLElBQUksQ0FBQyxHQUFHLENBQUMsbUJBQW1CLEdBQUc7Z0JBQzNCLE9BQU8sS0FBSSxDQUFDLFlBQVksQ0FBQztZQUM3QixDQUFDLENBQUM7WUFDRixJQUFJLENBQUMsR0FBRyxDQUFDLG1CQUFtQixHQUFHLFVBQUMsTUFBVyxFQUFFLFdBQW9CO2dCQUM3RCxJQUFJLGFBQWEsR0FBUSxNQUFNLENBQUM7Z0JBQ2hDLElBQUksS0FBSyxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsRUFBRTtvQkFDdkIsSUFBSSxPQUFPLFdBQVcsS0FBSyxXQUFXLEVBQUU7d0JBQ3BDLE9BQU8sQ0FBQyxHQUFHLENBQUMseURBQXlELENBQUMsQ0FBQzt3QkFDdkUsT0FBTztxQkFDVjtvQkFDRCxhQUFhLEdBQUcsTUFBTSxDQUFDLFdBQVcsQ0FBQyxDQUFDO2lCQUN2QztnQkFFRCxJQUFJLEtBQUksQ0FBQyxNQUFNLENBQUMsSUFBSSxLQUFLLFFBQVEsRUFBRTtvQkFDL0IsS0FBSyxJQUFJLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxHQUFHLEtBQUksQ0FBQyxXQUFXLENBQUMsTUFBTSxFQUFFLEVBQUUsQ0FBQyxFQUFFO3dCQUM5QyxJQUFJLEtBQUksQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxLQUFLLE1BQU0sQ0FBQyxLQUFLLEVBQUU7NEJBQzVDLGFBQWEsR0FBRyxDQUFDLENBQUM7NEJBQ2xCLE1BQU07eUJBQ1Q7cUJBQ0o7aUJBQ0o7Z0JBRUQsS0FBSSxDQUFDLFdBQVcsQ0FBQyxXQUFXLENBQUMsYUFBYSxFQUFFLFdBQVcsQ0FBQyxDQUFDO1lBQzdELENBQUMsQ0FBQztTQUNMO0lBQ0wsQ0FBQztJQUVPLDZCQUFVLEdBQWxCLFVBQW1CLE9BQU87UUFDdEIsSUFBSSxDQUFDLE1BQU0sR0FBRyxNQUFNLENBQUMsTUFBTSxDQUFDLEVBQUUsRUFBRSxJQUFJLENBQUMsY0FBYyxFQUFFLE9BQU8sQ0FBQyxDQUFDO1FBQzlELElBQUksSUFBSSxDQUFDLE1BQU0sQ0FBQyxLQUFLO1lBQUUsSUFBSSxDQUFDLFlBQVksR0FBRyxFQUFFLE9BQU8sRUFBRSxJQUFJLENBQUMsTUFBTSxDQUFDLEtBQUssRUFBRSxDQUFDO1FBQzFFLElBQUksQ0FBQyxVQUFVLENBQUMsTUFBTSxHQUFHLElBQUksQ0FBQyxNQUFNLENBQUM7UUFDckMsSUFBSSxDQUFDLGNBQWMsR0FBRyxJQUFJLENBQUMsVUFBVSxDQUFDLGlCQUFpQixDQUFDLElBQUksQ0FBQyxXQUFXLEVBQUUsSUFBSSxDQUFDLE1BQU0sQ0FBQyxvQkFBb0IsQ0FBQyxDQUFDO0lBQ2hILENBQUM7SUFFTywyQkFBUSxHQUFoQixVQUFpQixNQUFNLEVBQUUsT0FBTztRQUFoQyxpQkFrQ0M7UUFoQ0csSUFBSSxPQUFPLENBQUMsSUFBSSxLQUFLLFFBQVEsRUFBRTtZQUMzQixJQUFJLFFBQVEsU0FBUSxDQUFDO1lBQ3JCLElBQUksQ0FBQyxNQUFNLENBQUMsR0FBRyxHQUFHLE9BQU8sQ0FBQyxPQUFPLENBQUMsTUFBTSxHQUFHLENBQUMsQ0FBQztZQUM3QyxJQUFJLENBQUMsTUFBTSxDQUFDLElBQUksR0FBRyxDQUFDLENBQUM7WUFDckIsSUFBSSxDQUFDLE1BQU0sQ0FBQyxHQUFHLEdBQUcsQ0FBQyxDQUFDO1lBQ3BCLElBQUksQ0FBQyxVQUFVLENBQUMsTUFBTSxHQUFHLElBQUksQ0FBQyxNQUFNLENBQUM7WUFFckMsS0FBSyxJQUFJLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxHQUFHLE9BQU8sQ0FBQyxPQUFPLENBQUMsTUFBTSxFQUFFLEVBQUUsQ0FBQyxFQUFFO2dCQUM3QyxJQUFJLE9BQU8sQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxLQUFLLE1BQU0sQ0FBQyxLQUFLLEVBQUU7b0JBQzNDLFFBQVEsR0FBRyxDQUFDLENBQUM7b0JBQ2IsTUFBTTtpQkFDVDthQUNKO1lBQ0QsT0FBTyxRQUFRLElBQUksQ0FBQyxDQUFDO1NBQ3hCO1FBRUQsSUFBSSxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLEVBQUU7WUFDeEIsSUFBSSxDQUFDLE1BQU0sQ0FBQyxLQUFLLEdBQUcsS0FBSyxDQUFDO1lBQzFCLElBQUksQ0FBQyxVQUFVLENBQUMsTUFBTSxHQUFHLElBQUksQ0FBQyxNQUFNLENBQUM7WUFDckMsT0FBTyxNQUFNLENBQUM7U0FDakI7UUFFRCxJQUFJLE9BQU8sQ0FBQyxLQUFLLEVBQUU7WUFDZixJQUFJLENBQUMsTUFBTSxDQUFDLFFBQVEsR0FBRyxLQUFLLENBQUM7WUFDN0IsSUFBSSxRQUFRLEdBQUcsTUFBTSxDQUFDLEdBQUcsQ0FBQyxVQUFDLEVBQUU7Z0JBQ3pCLElBQUksT0FBTyxFQUFFLEtBQUssUUFBUTtvQkFBRSxFQUFFLEdBQUcsVUFBVSxDQUFDLEVBQUUsQ0FBQyxDQUFDO2dCQUNoRCxPQUFPLEtBQUksQ0FBQyxVQUFVLENBQUMsS0FBSyxDQUFDLEVBQUUsRUFBRSxLQUFJLENBQUMsTUFBTSxDQUFDLEdBQUcsRUFBRSxLQUFJLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDO1lBQ3ZFLENBQUMsQ0FBQyxDQUFDO1lBQ0gsT0FBTyxRQUFRLENBQUM7U0FDbkI7UUFFRCxPQUFPLENBQUMsQ0FBQztJQUNiLENBQUM7O2dCQTVIK0IsV0FBVzs7SUFObEM7UUFBUixLQUFLLEVBQUU7O3dDQUFZO0lBQ0o7UUFBZixLQUFLLENBQUMsT0FBTyxDQUFDOztpREFBc0I7SUFDcEI7UUFBaEIsS0FBSyxDQUFDLFFBQVEsQ0FBQzs7a0RBQTZCO0lBQ3BDO1FBQVIsS0FBSyxFQUFFOzt5Q0FBaUI7SUFDZjtRQUFULE1BQU0sRUFBRTtrQ0FBUyxZQUFZOzRDQUEwQjtJQTFCL0MsUUFBUTtRQW5DcEIsU0FBUyxDQUFDO1lBQ1AsUUFBUSxFQUFFLFdBQVc7WUFDckIsUUFBUSxFQUFFLCs4Q0F5QlQ7WUFDRCxTQUFTLEVBQUUsQ0FBQyxXQUFXLENBQUM7WUFDeEIsSUFBSSxFQUFFO2dCQUNGLE9BQU8sRUFBRSxZQUFZO2dCQUNyQixvQ0FBb0MsRUFBRSxtQkFBbUI7YUFDNUQ7U0FDSixDQUFDO3lDQThCa0MsV0FBVztPQTVCbEMsUUFBUSxDQXlKcEI7SUFBRCxlQUFDO0NBQUEsQUF6SkQsSUF5SkM7U0F6SlksUUFBUSIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7XHJcbiAgICBDb21wb25lbnQsXHJcbiAgICBJbnB1dCxcclxuICAgIE9uSW5pdCxcclxuICAgIE9uQ2hhbmdlcyxcclxuICAgIFNpbXBsZUNoYW5nZXMsXHJcbiAgICBFdmVudEVtaXR0ZXIsXHJcbiAgICBPdXRwdXQsXHJcbn0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XHJcbmltcG9ydCB7IEtkU2xpZGVyU3ZjIH0gZnJvbSAnLi9rZC1hbmd1bGFyLXNsaWRlci1zdmMnO1xyXG5pbXBvcnQge1xyXG4gICAgSVNsaWRlckFwaSxcclxuICAgIElTbGlkZXJDb25maWcsXHJcbiAgICBJU2xpZGVyQXBpSW50ZXJuYWxcclxufSBmcm9tICcuL2tkLWFuZ3VsYXItc2xpZGVyLWludGVyZmFjZSc7XHJcblxyXG5AQ29tcG9uZW50KHtcclxuICAgIHNlbGVjdG9yOiAna2Qtc2xpZGVyJyxcclxuICAgIHRlbXBsYXRlOiBgXHJcbiAgICAgICAgPGRpdiBjbGFzcz1cImtkeC1zbGlkZXItd3JhcHBlclwiIFtpZF09XCJzbGlkZXJJZFwiIFtuZ1N0eWxlXT1cIndyYXBwZXJTdHlsZVwiPlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzPVwia2R4LXNsaWRlci1jb250YWluZXJcIiBbbmdDbGFzc109XCJ7J2tkeC1zbGlkZXItY29udGFpbmVyLXZlcnRpY2FsJzogY29uZmlnLm9yaWVudGF0aW9uID09PSAndmVydGljYWwnfVwiPlxyXG4gICAgICAgICAgICAgICAgPGJ1dHRvbiAqbmdJZj1cImNvbmZpZy5hdXRvcGxheVwiIGNsYXNzPVwiYnRuXCIgKGNsaWNrKT1cImNsaWNrUGxheUJ0bigpXCIgW2F0dHIuZGlzYWJsZWRdPVwiY29uZmlnLmRpc2FibGVkPyAnJzogbnVsbFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxpIGNsYXNzPVwicGxheS1pY29uIGZhXCIgYXJpYS1oaWRkZW49XCJ0cnVlXCIgW25nQ2xhc3NdPVwieydmYS1wbGF5JzogIWlzUGxheSwgJ2ZhLXBhdXNlJzogaXNQbGF5fVwiPjwvaT5cclxuICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgPGtkLXNsaWRlci1jb250ZW50IFt2YWx1ZV09XCJ2YWx1ZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgW2NvbmZpZ109XCJjb25maWdcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFtpc1BsYXldPVwiaXNQbGF5XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBbYXBpXT1cImFwaUludGVybmFsXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAoZW5kUGxheSk9XCJlbmRQbGF5KCRldmVudClcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIChyZXN1bHQpPVwiZW1pdENoYW5nZUV2ZW50KCRldmVudClcIj5cclxuICAgICAgICAgICAgICAgIDwva2Qtc2xpZGVyLWNvbnRlbnQ+XHJcbiAgICAgICAgICAgICAgICA8ZGl2ICpuZ0lmPVwiY29uZmlnLnNpZGVWYWx1ZUxhYmVsXCIgY2xhc3M9XCJzaWRlLXZhbHVlLWxhYmVsIGtkeC1sYWJlbFwiPnt7c2lkZVZhbHVlTGFiZWx9fTwvZGl2PlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPGRpdiAqbmdJZj1cImNvbmZpZy5zdGFydExhYmVsXCIgY2xhc3M9XCJrZHgtbGFiZWwtY29udGFpbmVyXCI+XHJcbiAgICAgICAgICAgICAgICA8ZGl2ICpuZ0lmPVwiY29uZmlnLnN0YXJ0TGFiZWxcIiBjbGFzcz1cImtkeC1sYWJlbFwiID5cclxuICAgICAgICAgICAgICAgICAgICB7e2NvbmZpZy5zdGFydExhYmVsfX1cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPGRpdiAqbmdJZj1cImNvbmZpZy5lbmRMYWJlbFwiIGNsYXNzPVwia2R4LWxhYmVsXCIgPlxyXG4gICAgICAgICAgICAgICAgICAgIHt7Y29uZmlnLmVuZExhYmVsfX1cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICA8bmctY29udGVudD48L25nLWNvbnRlbnQ+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICBgLFxyXG4gICAgcHJvdmlkZXJzOiBbS2RTbGlkZXJTdmNdLFxyXG4gICAgaG9zdDoge1xyXG4gICAgICAgICdjbGFzcyc6ICdrZHgtc2xpZGVyJyxcclxuICAgICAgICAnW2NsYXNzLmtkeC1zbGlkZXItaGFzLXN0YXJ0LWxhYmVsXSc6ICdjb25maWcuc3RhcnRMYWJlbCcsXHJcbiAgICB9XHJcbn0pXHJcblxyXG5leHBvcnQgY2xhc3MgS2RTbGlkZXIgaW1wbGVtZW50cyBPbkluaXQsIE9uQ2hhbmdlcyB7XHJcblxyXG4gICAgcHVibGljIGNvbmZpZzogSVNsaWRlckNvbmZpZyA9IHt9O1xyXG4gICAgcHVibGljIHZhbHVlOiBhbnkgPSAwO1xyXG4gICAgcHVibGljIGlzUGxheTogYm9vbGVhbiA9IGZhbHNlO1xyXG4gICAgcHVibGljIHNsaWRlcklkOiBzdHJpbmc7XHJcbiAgICBwdWJsaWMgd3JhcHBlclN0eWxlOiB7IFtrZXk6IHN0cmluZ106IHN0cmluZyB9ID0ge307XHJcbiAgICBwdWJsaWMgc2lkZVZhbHVlTGFiZWw6IHN0cmluZyB8IG51bWJlcjtcclxuICAgIHB1YmxpYyBhcGlJbnRlcm5hbDogSVNsaWRlckFwaUludGVybmFsID0ge307XHJcblxyXG4gICAgcHJpdmF0ZSBfZGVmYXVsdENvbmZpZzogSVNsaWRlckNvbmZpZyA9IHtcclxuICAgICAgICBvcmllbnRhdGlvbjogJ2hvcml6b250YWwnLFxyXG4gICAgICAgIHJhbmdlOiBmYWxzZSxcclxuICAgICAgICBtYXg6IDEwMCxcclxuICAgICAgICBtaW46IDAsXHJcbiAgICAgICAgc3RlcDogMSxcclxuICAgICAgICBkaXNhYmxlZDogZmFsc2UsXHJcbiAgICAgICAgYXV0b3BsYXk6IGZhbHNlLFxyXG4gICAgICAgIGF1dG9wbGF5U3RlcDogMSxcclxuICAgIH07XHJcbiAgICBwcml2YXRlIF9vdXRwdXRWYWx1ZTogYW55O1xyXG5cclxuICAgIEBJbnB1dCgpIGlkOiBzdHJpbmc7XHJcbiAgICBASW5wdXQoJ3ZhbHVlJykgc2xpZGVyVmFsdWU6IGFueSA9IDA7XHJcbiAgICBASW5wdXQoJ2NvbmZpZycpIHNsaWRlckNvbmZpZzogSVNsaWRlckNvbmZpZztcclxuICAgIEBJbnB1dCgpIGFwaTogSVNsaWRlckFwaTtcclxuICAgIEBPdXRwdXQoKSByZXN1bHQ6IEV2ZW50RW1pdHRlcjx7fT4gPSBuZXcgRXZlbnRFbWl0dGVyKCk7XHJcblxyXG4gICAgY29uc3RydWN0b3IocHJpdmF0ZSBfc2xpZGVyU3ZjOiBLZFNsaWRlclN2YykgeyB9XHJcblxyXG4gICAgbmdPbkluaXQoKTogdm9pZCB7XHJcbiAgICAgICAgdGhpcy5fc2V0Q29uZmlnKHRoaXMuc2xpZGVyQ29uZmlnKTtcclxuICAgICAgICB0aGlzLnZhbHVlID0gdGhpcy5fc2V0RGF0YSh0aGlzLnNsaWRlclZhbHVlLCB0aGlzLmNvbmZpZyk7XHJcbiAgICAgICAgdGhpcy5fb3V0cHV0VmFsdWUgPSB0aGlzLnZhbHVlO1xyXG4gICAgICAgIHRoaXMuc2xpZGVySWQgPSB0eXBlb2YgdGhpcy5pZCAhPT0gJ3VuZGVmaW5lZCcgPyB0aGlzLmlkIDogJ3NsaWRlcic7XHJcbiAgICAgICAgdGhpcy5faW5pdEFwaSgpO1xyXG4gICAgfVxyXG5cclxuICAgIG5nT25DaGFuZ2VzKF9zaW1wbGVDaGFuZ2VzOiBTaW1wbGVDaGFuZ2VzKTogdm9pZCB7XHJcbiAgICAgICAgaWYgKF9zaW1wbGVDaGFuZ2VzLmhhc093blByb3BlcnR5KCdzbGlkZXJDb25maWcnKSAmJiAhX3NpbXBsZUNoYW5nZXNbJ3NsaWRlckNvbmZpZyddLmZpcnN0Q2hhbmdlKSB7XHJcbiAgICAgICAgICAgIGlmIChfc2ltcGxlQ2hhbmdlc1snc2xpZGVyQ29uZmlnJ10uY3VycmVudFZhbHVlID09PSB0aGlzLmNvbmZpZykgcmV0dXJuO1xyXG4gICAgICAgICAgICB0aGlzLl9zZXRDb25maWcoX3NpbXBsZUNoYW5nZXNbJ3NsaWRlckNvbmZpZyddLmN1cnJlbnRWYWx1ZSk7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGlmIChfc2ltcGxlQ2hhbmdlcy5oYXNPd25Qcm9wZXJ0eSgnc2xpZGVyVmFsdWUnKSAmJiAhX3NpbXBsZUNoYW5nZXNbJ3NsaWRlclZhbHVlJ10uZmlyc3RDaGFuZ2UpIHtcclxuICAgICAgICAgICAgaWYgKF9zaW1wbGVDaGFuZ2VzWydzbGlkZXJWYWx1ZSddLmN1cnJlbnRWYWx1ZSA9PT0gdGhpcy52YWx1ZSkgcmV0dXJuO1xyXG4gICAgICAgICAgICB0aGlzLnZhbHVlID0gdGhpcy5fc2V0RGF0YShfc2ltcGxlQ2hhbmdlc1snc2xpZGVyVmFsdWUnXS5jdXJyZW50VmFsdWUsIHRoaXMuY29uZmlnKTtcclxuICAgICAgICAgICAgdGhpcy5fb3V0cHV0VmFsdWUgPSB0aGlzLnZhbHVlO1xyXG4gICAgICAgIH1cclxuICAgICAgICBpZiAoX3NpbXBsZUNoYW5nZXMuaGFzT3duUHJvcGVydHkoJ2lkJykgJiYgIV9zaW1wbGVDaGFuZ2VzWydpZCddLmZpcnN0Q2hhbmdlKSB7XHJcbiAgICAgICAgICAgIGlmIChfc2ltcGxlQ2hhbmdlc1snaWQnXS5jdXJyZW50VmFsdWUgPT09IHRoaXMuc2xpZGVySWQpIHJldHVybjtcclxuICAgICAgICAgICAgdGhpcy5zbGlkZXJJZCA9IHR5cGVvZiBfc2ltcGxlQ2hhbmdlc1snaWQnXS5jdXJyZW50VmFsdWUgIT09ICd1bmRlZmluZWQnID8gX3NpbXBsZUNoYW5nZXNbJ2lkJ10uY3VycmVudFZhbHVlIDogJ3NsaWRlcic7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIC8qKiBFbWl0cyBhIGNoYW5nZSBldmVudCBpZiB0aGUgY3VycmVudCB2YWx1ZSBpcyBkaWZmZXJlbnQgZnJvbSB0aGUgbGFzdCBlbWl0dGVkIHZhbHVlLiAqL1xyXG4gICAgcHVibGljIGVtaXRDaGFuZ2VFdmVudChfcmVzdWx0OiB7IHZhbHVlOiBhbnksIGN1cnJlbnRBY3Rpb24/OiAnc2xpZGluZycgfSk6IHZvaWQge1xyXG4gICAgICAgIC8qKnR5cGUgPT09IG51bWJlciB8IEFycmF5PG51bWJlcj4gfCBPYmplY3Qgd2l0aCBhdCBsZWFzdCB0aGUgZm9sbG93aW5nIHByb3BlcnRpZXM6XHJcbiAgICAgICAgKiB7XHJcbiAgICAgICAgKiAgIGRlc2NyaXB0aW9uPzogc3RyaW5nO1xyXG4gICAgICAgICogICB2YWx1ZTogc3RyaW5nIHwgbnVtYmVyO1xyXG4gICAgICAgICogfVxyXG4gICAgICAgICogKi9cclxuICAgICAgICB0aGlzLl9vdXRwdXRWYWx1ZSA9IHRoaXMuY29uZmlnLnR5cGUgJiYgdGhpcy5jb25maWcudHlwZSA9PT0gJ290aGVycycgPyB0aGlzLmNvbmZpZy5vcHRpb25zW01hdGgucm91bmQoX3Jlc3VsdC52YWx1ZSldIDogX3Jlc3VsdC52YWx1ZTtcclxuICAgICAgICBpZiAoX3Jlc3VsdC5jdXJyZW50QWN0aW9uICE9PSAnc2xpZGluZycpIHRoaXMucmVzdWx0LmVtaXQodGhpcy5fb3V0cHV0VmFsdWUpO1xyXG4gICAgICAgIHRoaXMuc2lkZVZhbHVlTGFiZWwgPSB0aGlzLl9zbGlkZXJTdmMuc2V0U2lkZVZhbHVlTGFiZWwodGhpcy5fb3V0cHV0VmFsdWUsIHRoaXMuY29uZmlnLnNpZGVWYWx1ZUxhYmVsRm9ybWF0KTtcclxuICAgIH1cclxuXHJcbiAgICAvKiogVG9nZ2xlIGF1dG9wbGF5ICovXHJcbiAgICBwdWJsaWMgY2xpY2tQbGF5QnRuKCk6IHZvaWQge1xyXG4gICAgICAgIGlmICh0aGlzLmNvbmZpZy5kaXNhYmxlZCkgcmV0dXJuO1xyXG4gICAgICAgIHRoaXMuaXNQbGF5ID0gdGhpcy5pc1BsYXkgPyBmYWxzZSA6IHRydWU7XHJcbiAgICB9XHJcblxyXG4gICAgLyoqIFVwZGF0ZSB0aGlzLmlzUGxheSB3aGVuIGVuZCBvZiBzbGlkZXIgaXMgcmVhY2hlZCAqL1xyXG4gICAgcHVibGljIGVuZFBsYXkoX2VuZDogYm9vbGVhbik6IHZvaWQge1xyXG4gICAgICAgIHRoaXMuaXNQbGF5ID0gX2VuZCA/IGZhbHNlIDogdHJ1ZTtcclxuICAgIH1cclxuXHJcblxyXG4gICAgcHJpdmF0ZSBfaW5pdEFwaSgpOiB2b2lkIHtcclxuICAgICAgICBpZiAodHlwZW9mIHRoaXMuYXBpICE9PSAndW5kZWZpbmVkJykge1xyXG4gICAgICAgICAgICB0aGlzLmFwaS5kaXNhYmxlID0gKF9mbGFnOiBib29sZWFuKSA9PiB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLmNvbmZpZyA9IE9iamVjdC5hc3NpZ24oe30sIHRoaXMuY29uZmlnLCB7IGRpc2FibGVkOiBfZmxhZyB9KTtcclxuICAgICAgICAgICAgfTtcclxuICAgICAgICAgICAgdGhpcy5hcGkuZ2V0U2xpZGVyVGh1bWJWYWx1ZSA9ICgpID0+IHtcclxuICAgICAgICAgICAgICAgIHJldHVybiB0aGlzLl9vdXRwdXRWYWx1ZTtcclxuICAgICAgICAgICAgfTtcclxuICAgICAgICAgICAgdGhpcy5hcGkuc2V0U2xpZGVyVGh1bWJWYWx1ZSA9IChfdmFsdWU6IGFueSwgX3RodW1iSW5kZXg/OiBudW1iZXIpID0+IHtcclxuICAgICAgICAgICAgICAgIGxldCB2YWx1ZVRvVXBkYXRlOiBhbnkgPSBfdmFsdWU7XHJcbiAgICAgICAgICAgICAgICBpZiAoQXJyYXkuaXNBcnJheShfdmFsdWUpKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKHR5cGVvZiBfdGh1bWJJbmRleCA9PT0gJ3VuZGVmaW5lZCcpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgY29uc29sZS5sb2coJ3BsZWFzZSBwYXNzIHRoZSBfdGh1bWJJbmRleCBvZiB3aGljaCB0byB1cGRhdGUgdmFsdWUgdG8nKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuO1xyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICB2YWx1ZVRvVXBkYXRlID0gX3ZhbHVlW190aHVtYkluZGV4XTtcclxuICAgICAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgICAgICBpZiAodGhpcy5jb25maWcudHlwZSA9PT0gJ290aGVycycpIHtcclxuICAgICAgICAgICAgICAgICAgICBmb3IgKGxldCBpID0gMDsgaSA8IHRoaXMuc2xpZGVyVmFsdWUubGVuZ3RoOyArK2kpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgaWYgKHRoaXMuc2xpZGVyVmFsdWVbaV0udmFsdWUgPT09IF92YWx1ZS52YWx1ZSkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWVUb1VwZGF0ZSA9IGk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBicmVhaztcclxuICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgICAgICB0aGlzLmFwaUludGVybmFsLmhhbmRsZVZhbHVlKHZhbHVlVG9VcGRhdGUsIF90aHVtYkluZGV4KTtcclxuICAgICAgICAgICAgfTtcclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfc2V0Q29uZmlnKF9jb25maWcpOiB2b2lkIHtcclxuICAgICAgICB0aGlzLmNvbmZpZyA9IE9iamVjdC5hc3NpZ24oe30sIHRoaXMuX2RlZmF1bHRDb25maWcsIF9jb25maWcpO1xyXG4gICAgICAgIGlmICh0aGlzLmNvbmZpZy53aWR0aCkgdGhpcy53cmFwcGVyU3R5bGUgPSB7ICd3aWR0aCc6IHRoaXMuY29uZmlnLndpZHRoIH07XHJcbiAgICAgICAgdGhpcy5fc2xpZGVyU3ZjLmNvbmZpZyA9IHRoaXMuY29uZmlnO1xyXG4gICAgICAgIHRoaXMuc2lkZVZhbHVlTGFiZWwgPSB0aGlzLl9zbGlkZXJTdmMuc2V0U2lkZVZhbHVlTGFiZWwodGhpcy5zbGlkZXJWYWx1ZSwgdGhpcy5jb25maWcuc2lkZVZhbHVlTGFiZWxGb3JtYXQpO1xyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX3NldERhdGEoX3ZhbHVlLCBfY29uZmlnKTogQXJyYXk8bnVtYmVyPiB8IG51bWJlciB7XHJcblxyXG4gICAgICAgIGlmIChfY29uZmlnLnR5cGUgPT09ICdvdGhlcnMnKSB7XHJcbiAgICAgICAgICAgIGxldCBuZXdWYWx1ZTogbnVtYmVyO1xyXG4gICAgICAgICAgICB0aGlzLmNvbmZpZy5tYXggPSBfY29uZmlnLm9wdGlvbnMubGVuZ3RoIC0gMTtcclxuICAgICAgICAgICAgdGhpcy5jb25maWcuc3RlcCA9IDE7XHJcbiAgICAgICAgICAgIHRoaXMuY29uZmlnLm1pbiA9IDA7XHJcbiAgICAgICAgICAgIHRoaXMuX3NsaWRlclN2Yy5jb25maWcgPSB0aGlzLmNvbmZpZztcclxuXHJcbiAgICAgICAgICAgIGZvciAobGV0IGkgPSAwOyBpIDwgX2NvbmZpZy5vcHRpb25zLmxlbmd0aDsgKytpKSB7XHJcbiAgICAgICAgICAgICAgICBpZiAoX2NvbmZpZy5vcHRpb25zW2ldLnZhbHVlID09PSBfdmFsdWUudmFsdWUpIHtcclxuICAgICAgICAgICAgICAgICAgICBuZXdWYWx1ZSA9IGk7XHJcbiAgICAgICAgICAgICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgcmV0dXJuIG5ld1ZhbHVlIHx8IDA7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICBpZiAoIUFycmF5LmlzQXJyYXkoX3ZhbHVlKSkge1xyXG4gICAgICAgICAgICB0aGlzLmNvbmZpZy5yYW5nZSA9IGZhbHNlO1xyXG4gICAgICAgICAgICB0aGlzLl9zbGlkZXJTdmMuY29uZmlnID0gdGhpcy5jb25maWc7XHJcbiAgICAgICAgICAgIHJldHVybiBfdmFsdWU7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICBpZiAoX2NvbmZpZy5yYW5nZSkge1xyXG4gICAgICAgICAgICB0aGlzLmNvbmZpZy5hdXRvcGxheSA9IGZhbHNlO1xyXG4gICAgICAgICAgICBsZXQgbmV3VmFsdWUgPSBfdmFsdWUubWFwKChlbCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgaWYgKHR5cGVvZiBlbCAhPT0gJ251bWJlcicpIGVsID0gcGFyc2VGbG9hdChlbCk7XHJcbiAgICAgICAgICAgICAgICByZXR1cm4gdGhpcy5fc2xpZGVyU3ZjLmNsYW1wKGVsLCB0aGlzLmNvbmZpZy5taW4sIHRoaXMuY29uZmlnLm1heCk7XHJcbiAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICByZXR1cm4gbmV3VmFsdWU7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICByZXR1cm4gMDtcclxuICAgIH1cclxufVxyXG4iXX0=