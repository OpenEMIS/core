import { __decorate, __metadata } from "tslib";
import { Component, Input, ViewEncapsulation, ViewChild, Output, EventEmitter } from '@angular/core';
import { KdView } from '../kd-angular-view/index';
var KdFilter = /** @class */ (function () {
    function KdFilter() {
        this._filteredData = [];
        this.valueUpdate = new EventEmitter();
    }
    KdFilter.prototype.ngOnInit = function () {
        this._filteredData = this._getUpdatedData(this.inputData);
    };
    KdFilter.prototype.getInputProperty = function (key, propertyName) {
        return this._updateView.getInputProperty(key, propertyName);
    };
    KdFilter.prototype.setInputProperty = function (_key, _propertyName, _data) {
        this._updateView.setInputProperty(_key, _propertyName, _data);
    };
    KdFilter.prototype.detectValue = function (_question) {
        this.valueUpdate.emit(_question);
    };
    KdFilter.prototype._getUpdatedData = function (_inputData) {
        var updatedData = [];
        for (var i = 0; i < _inputData.length; i++) {
            if (_inputData[i].controlType !== 'multiselect' &&
                _inputData[i].controlType !== 'password' &&
                _inputData[i].controlType !== 'textarea' &&
                _inputData[i].controlType !== 'hidden' &&
                _inputData[i].controlType !== 'disabled' &&
                _inputData[i].controlType !== 'readonly' &&
                _inputData[i].controlType !== 'file-input' &&
                _inputData[i].controlType !== 'radio' &&
                // _inputData[i].controlType !== 'tree' &&
                _inputData[i].controlType !== 'multi-table' &&
                _inputData[i].controlType !== 'aggrid' &&
                _inputData[i].controlType !== 'text') {
                updatedData.push(_inputData[i]);
            }
            if (_inputData[i].controlType === 'text' && _inputData[i].type !== 'multiselect')
                updatedData.push(_inputData[i]);
        }
        return updatedData;
    };
    __decorate([
        Input(),
        __metadata("design:type", Object)
    ], KdFilter.prototype, "inputData", void 0);
    __decorate([
        Output(),
        __metadata("design:type", EventEmitter)
    ], KdFilter.prototype, "valueUpdate", void 0);
    __decorate([
        ViewChild(KdView, { static: true }),
        __metadata("design:type", KdView)
    ], KdFilter.prototype, "_updateView", void 0);
    KdFilter = __decorate([
        Component({
            selector: 'kd-filter',
            template: "<kd-view displayType='horizontal-form' [inputData]='_filteredData' (detectFrom)='detectValue($event)'></kd-view>",
            encapsulation: ViewEncapsulation.None,
            host: { 'class': 'kdx-filter' }
        })
    ], KdFilter);
    return KdFilter;
}());
export { KdFilter };
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoia2QtYW5ndWxhci1maWx0ZXIuanMiLCJzb3VyY2VSb290Ijoibmc6Ly9vcGVuZW1pcy1zdHlsZWd1aWRlLWxpYi8iLCJzb3VyY2VzIjpbImtkLWNvbXBvbmVudHMva2QtYW5ndWxhci1maWx0ZXIva2QtYW5ndWxhci1maWx0ZXIudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IjtBQUFBLE9BQU8sRUFDSCxTQUFTLEVBQ1QsS0FBSyxFQUNMLGlCQUFpQixFQUNqQixTQUFTLEVBQ1QsTUFBTSxFQUNOLFlBQVksRUFFZixNQUFNLGVBQWUsQ0FBQztBQUN2QixPQUFPLEVBQUUsTUFBTSxFQUFFLE1BQU0sMEJBQTBCLENBQUM7QUFRbEQ7SUFBQTtRQUNXLGtCQUFhLEdBQWUsRUFBRSxDQUFDO1FBRzVCLGdCQUFXLEdBQXNCLElBQUksWUFBWSxFQUFFLENBQUM7SUEyQ2xFLENBQUM7SUF4Q0csMkJBQVEsR0FBUjtRQUNJLElBQUksQ0FBQyxhQUFhLEdBQUcsSUFBSSxDQUFDLGVBQWUsQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLENBQUM7SUFDOUQsQ0FBQztJQUVNLG1DQUFnQixHQUF2QixVQUF3QixHQUFXLEVBQUUsWUFBb0I7UUFDckQsT0FBTyxJQUFJLENBQUMsV0FBVyxDQUFDLGdCQUFnQixDQUFDLEdBQUcsRUFBRSxZQUFZLENBQUMsQ0FBQztJQUNoRSxDQUFDO0lBRU0sbUNBQWdCLEdBQXZCLFVBQXdCLElBQVksRUFBRSxhQUFxQixFQUFFLEtBQVU7UUFDbkUsSUFBSSxDQUFDLFdBQVcsQ0FBQyxnQkFBZ0IsQ0FBQyxJQUFJLEVBQUUsYUFBYSxFQUFFLEtBQUssQ0FBQyxDQUFDO0lBQ2xFLENBQUM7SUFFTSw4QkFBVyxHQUFsQixVQUFtQixTQUFjO1FBQzdCLElBQUksQ0FBQyxXQUFXLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDO0lBQ3JDLENBQUM7SUFFTyxrQ0FBZSxHQUF2QixVQUF3QixVQUFzQjtRQUMxQyxJQUFJLFdBQVcsR0FBZSxFQUFFLENBQUM7UUFDakMsS0FBSyxJQUFJLENBQUMsR0FBVyxDQUFDLEVBQUUsQ0FBQyxHQUFHLFVBQVUsQ0FBQyxNQUFNLEVBQUUsQ0FBQyxFQUFFLEVBQUU7WUFDaEQsSUFDSSxVQUFVLENBQUMsQ0FBQyxDQUFDLENBQUMsV0FBVyxLQUFLLGFBQWE7Z0JBQzNDLFVBQVUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxXQUFXLEtBQUssVUFBVTtnQkFDeEMsVUFBVSxDQUFDLENBQUMsQ0FBQyxDQUFDLFdBQVcsS0FBSyxVQUFVO2dCQUN4QyxVQUFVLENBQUMsQ0FBQyxDQUFDLENBQUMsV0FBVyxLQUFLLFFBQVE7Z0JBQ3RDLFVBQVUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxXQUFXLEtBQUssVUFBVTtnQkFDeEMsVUFBVSxDQUFDLENBQUMsQ0FBQyxDQUFDLFdBQVcsS0FBSyxVQUFVO2dCQUN4QyxVQUFVLENBQUMsQ0FBQyxDQUFDLENBQUMsV0FBVyxLQUFLLFlBQVk7Z0JBQzFDLFVBQVUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxXQUFXLEtBQUssT0FBTztnQkFDckMsMENBQTBDO2dCQUMxQyxVQUFVLENBQUMsQ0FBQyxDQUFDLENBQUMsV0FBVyxLQUFLLGFBQWE7Z0JBQzNDLFVBQVUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxXQUFXLEtBQUssUUFBUTtnQkFDdEMsVUFBVSxDQUFDLENBQUMsQ0FBQyxDQUFDLFdBQVcsS0FBSyxNQUFNLEVBQ3RDO2dCQUNFLFdBQVcsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7YUFDbkM7WUFFRCxJQUFJLFVBQVUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxXQUFXLEtBQUssTUFBTSxJQUFJLFVBQVUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLEtBQUssYUFBYTtnQkFBRSxXQUFXLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO1NBQ3JIO1FBQ0QsT0FBTyxXQUFXLENBQUM7SUFDdkIsQ0FBQztJQTNDUTtRQUFSLEtBQUssRUFBRTs7K0NBQWdCO0lBQ2Q7UUFBVCxNQUFNLEVBQUU7a0NBQWMsWUFBWTtpREFBMkI7SUFDekI7UUFBcEMsU0FBUyxDQUFDLE1BQU0sRUFBRSxFQUFFLE1BQU0sRUFBRSxJQUFJLEVBQUUsQ0FBQztrQ0FBYyxNQUFNO2lEQUFDO0lBTGhELFFBQVE7UUFOcEIsU0FBUyxDQUFDO1lBQ1AsUUFBUSxFQUFFLFdBQVc7WUFDckIsUUFBUSxFQUFFLGtIQUFrSDtZQUM1SCxhQUFhLEVBQUUsaUJBQWlCLENBQUMsSUFBSTtZQUNyQyxJQUFJLEVBQUUsRUFBRSxPQUFPLEVBQUcsWUFBWSxFQUFFO1NBQ25DLENBQUM7T0FDVyxRQUFRLENBK0NwQjtJQUFELGVBQUM7Q0FBQSxBQS9DRCxJQStDQztTQS9DWSxRQUFRIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHtcclxuICAgIENvbXBvbmVudCxcclxuICAgIElucHV0LFxyXG4gICAgVmlld0VuY2Fwc3VsYXRpb24sXHJcbiAgICBWaWV3Q2hpbGQsXHJcbiAgICBPdXRwdXQsXHJcbiAgICBFdmVudEVtaXR0ZXIsXHJcbiAgICBPbkluaXRcclxufSBmcm9tICdAYW5ndWxhci9jb3JlJztcclxuaW1wb3J0IHsgS2RWaWV3IH0gZnJvbSAnLi4va2QtYW5ndWxhci12aWV3L2luZGV4JztcclxuXHJcbkBDb21wb25lbnQoe1xyXG4gICAgc2VsZWN0b3I6ICdrZC1maWx0ZXInLFxyXG4gICAgdGVtcGxhdGU6IGA8a2QtdmlldyBkaXNwbGF5VHlwZT0naG9yaXpvbnRhbC1mb3JtJyBbaW5wdXREYXRhXT0nX2ZpbHRlcmVkRGF0YScgKGRldGVjdEZyb20pPSdkZXRlY3RWYWx1ZSgkZXZlbnQpJz48L2tkLXZpZXc+YCxcclxuICAgIGVuY2Fwc3VsYXRpb246IFZpZXdFbmNhcHN1bGF0aW9uLk5vbmUsXHJcbiAgICBob3N0OiB7ICdjbGFzcycgOiAna2R4LWZpbHRlcicgfVxyXG59KVxyXG5leHBvcnQgY2xhc3MgS2RGaWx0ZXIgaW1wbGVtZW50cyBPbkluaXQge1xyXG4gICAgcHVibGljIF9maWx0ZXJlZERhdGE6IEFycmF5PGFueT4gPSBbXTtcclxuXHJcbiAgICBASW5wdXQoKSBpbnB1dERhdGE6IGFueTtcclxuICAgIEBPdXRwdXQoKSB2YWx1ZVVwZGF0ZTogRXZlbnRFbWl0dGVyPGFueT4gPSBuZXcgRXZlbnRFbWl0dGVyKCk7XHJcbiAgICBAVmlld0NoaWxkKEtkVmlldywgeyBzdGF0aWM6IHRydWUgfSkgX3VwZGF0ZVZpZXc6IEtkVmlldztcclxuXHJcbiAgICBuZ09uSW5pdCgpOiB2b2lkIHtcclxuICAgICAgICB0aGlzLl9maWx0ZXJlZERhdGEgPSB0aGlzLl9nZXRVcGRhdGVkRGF0YSh0aGlzLmlucHV0RGF0YSk7XHJcbiAgICB9XHJcblxyXG4gICAgcHVibGljIGdldElucHV0UHJvcGVydHkoa2V5OiBzdHJpbmcsIHByb3BlcnR5TmFtZTogc3RyaW5nKTogYW55IHtcclxuICAgICAgICByZXR1cm4gdGhpcy5fdXBkYXRlVmlldy5nZXRJbnB1dFByb3BlcnR5KGtleSwgcHJvcGVydHlOYW1lKTtcclxuICAgIH1cclxuXHJcbiAgICBwdWJsaWMgc2V0SW5wdXRQcm9wZXJ0eShfa2V5OiBzdHJpbmcsIF9wcm9wZXJ0eU5hbWU6IHN0cmluZywgX2RhdGE6IGFueSk6IHZvaWQge1xyXG4gICAgICAgIHRoaXMuX3VwZGF0ZVZpZXcuc2V0SW5wdXRQcm9wZXJ0eShfa2V5LCBfcHJvcGVydHlOYW1lLCBfZGF0YSk7XHJcbiAgICB9XHJcblxyXG4gICAgcHVibGljIGRldGVjdFZhbHVlKF9xdWVzdGlvbjogYW55KTogdm9pZCB7XHJcbiAgICAgICAgdGhpcy52YWx1ZVVwZGF0ZS5lbWl0KF9xdWVzdGlvbik7XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfZ2V0VXBkYXRlZERhdGEoX2lucHV0RGF0YTogQXJyYXk8YW55Pik6IEFycmF5PGFueT4ge1xyXG4gICAgICAgIGxldCB1cGRhdGVkRGF0YTogQXJyYXk8YW55PiA9IFtdO1xyXG4gICAgICAgIGZvciAobGV0IGk6IG51bWJlciA9IDA7IGkgPCBfaW5wdXREYXRhLmxlbmd0aDsgaSsrKSB7XHJcbiAgICAgICAgICAgIGlmIChcclxuICAgICAgICAgICAgICAgIF9pbnB1dERhdGFbaV0uY29udHJvbFR5cGUgIT09ICdtdWx0aXNlbGVjdCcgJiZcclxuICAgICAgICAgICAgICAgIF9pbnB1dERhdGFbaV0uY29udHJvbFR5cGUgIT09ICdwYXNzd29yZCcgJiZcclxuICAgICAgICAgICAgICAgIF9pbnB1dERhdGFbaV0uY29udHJvbFR5cGUgIT09ICd0ZXh0YXJlYScgJiZcclxuICAgICAgICAgICAgICAgIF9pbnB1dERhdGFbaV0uY29udHJvbFR5cGUgIT09ICdoaWRkZW4nICYmXHJcbiAgICAgICAgICAgICAgICBfaW5wdXREYXRhW2ldLmNvbnRyb2xUeXBlICE9PSAnZGlzYWJsZWQnICYmXHJcbiAgICAgICAgICAgICAgICBfaW5wdXREYXRhW2ldLmNvbnRyb2xUeXBlICE9PSAncmVhZG9ubHknICYmXHJcbiAgICAgICAgICAgICAgICBfaW5wdXREYXRhW2ldLmNvbnRyb2xUeXBlICE9PSAnZmlsZS1pbnB1dCcgJiZcclxuICAgICAgICAgICAgICAgIF9pbnB1dERhdGFbaV0uY29udHJvbFR5cGUgIT09ICdyYWRpbycgJiZcclxuICAgICAgICAgICAgICAgIC8vIF9pbnB1dERhdGFbaV0uY29udHJvbFR5cGUgIT09ICd0cmVlJyAmJlxyXG4gICAgICAgICAgICAgICAgX2lucHV0RGF0YVtpXS5jb250cm9sVHlwZSAhPT0gJ211bHRpLXRhYmxlJyAmJlxyXG4gICAgICAgICAgICAgICAgX2lucHV0RGF0YVtpXS5jb250cm9sVHlwZSAhPT0gJ2FnZ3JpZCcgJiZcclxuICAgICAgICAgICAgICAgIF9pbnB1dERhdGFbaV0uY29udHJvbFR5cGUgIT09ICd0ZXh0J1xyXG4gICAgICAgICAgICApIHtcclxuICAgICAgICAgICAgICAgIHVwZGF0ZWREYXRhLnB1c2goX2lucHV0RGF0YVtpXSk7XHJcbiAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgIGlmIChfaW5wdXREYXRhW2ldLmNvbnRyb2xUeXBlID09PSAndGV4dCcgJiYgX2lucHV0RGF0YVtpXS50eXBlICE9PSAnbXVsdGlzZWxlY3QnKSB1cGRhdGVkRGF0YS5wdXNoKF9pbnB1dERhdGFbaV0pO1xyXG4gICAgICAgIH1cclxuICAgICAgICByZXR1cm4gdXBkYXRlZERhdGE7XHJcbiAgICB9XHJcbn1cclxuIl19