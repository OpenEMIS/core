import { __decorate, __metadata } from "tslib";
import { Component, ViewEncapsulation, Input, Output, EventEmitter } from '@angular/core';
import { KdIntSearchEvent } from './kd-search-event';
export { KdSearchEvent } from './kd-search-event';
var KdSearch = /** @class */ (function () {
    function KdSearch(_searchEvent) {
        this._searchEvent = _searchEvent;
        this._result = {};
        this._searchSettings = {};
        this._disable = false;
        this._defaultSettings = {
            title: 'Directory',
            searchPlaceholder: 'Search',
            description: 'Search Directory',
            filter: false,
            options: []
        };
        this.searchBtnClicked = new EventEmitter();
        this.advSearchBtnClicked = new EventEmitter();
    }
    KdSearch.prototype.ngOnInit = function () {
        var _this = this;
        this._searchSettings = Object.assign({}, this._defaultSettings, this.config);
        if (this._searchSettings.filter)
            this._result.optionVal = '';
        this._searchSub = this._searchEvent.onDisableButton().subscribe(function (data) {
            if (typeof data !== 'undefined')
                _this._disable = data;
            else
                _this._disable = !_this._disable;
        });
    };
    KdSearch.prototype.ngOnDestroy = function () {
        this._searchSub.unsubscribe();
    };
    KdSearch.prototype.searchClicked = function (isSearch) {
        if (isSearch)
            this.searchBtnClicked.emit(this._result);
        else
            this.advSearchBtnClicked.emit(this._result);
    };
    KdSearch.ctorParameters = function () { return [
        { type: KdIntSearchEvent }
    ]; };
    __decorate([
        Input(),
        __metadata("design:type", Object)
    ], KdSearch.prototype, "config", void 0);
    __decorate([
        Output(),
        __metadata("design:type", EventEmitter)
    ], KdSearch.prototype, "searchBtnClicked", void 0);
    __decorate([
        Output(),
        __metadata("design:type", EventEmitter)
    ], KdSearch.prototype, "advSearchBtnClicked", void 0);
    KdSearch = __decorate([
        Component({
            selector: 'kd-search',
            template: "\n        <div class=\"search-page-wrapper\">\n            <div class=\"search-page-box\">\n                <div class=\"search-title\">\n                    <h1>{{_searchSettings.title}}</h1>\n                    <p *ngIf=\"_searchSettings.description\">{{_searchSettings.description}}</p>\n                </div>\n                <div class=\"search-body\">\n                    <input type=\"text\" [(ngModel)]=\"_result.searchText\" placeholder=\"{{_searchSettings.searchPlaceholder}}\"/>\n                    <div *ngIf=\"_searchSettings.filter\" class=\"kdx-input-select-wrapper\">\n                        <select [(ngModel)]=\"_result.optionVal\">\n                            <option *ngFor=\"let item of _searchSettings.options\" [value]=\"item.key\">{{item.value}}</option>\n                        </select>\n                    </div>\n                </div>\n                <div class=\"search-buttons\">\n                    <button class=\"btn btn-text\" [disabled]=\"_disable\" (click)=\"searchClicked(true)\">Search </button>\n                    <button class=\"btn btn-text\" [disabled]=\"_disable\" (click)=\"searchClicked(false)\">Advance Search</button>\n                </div>\n            </div>\n        </div>\n    ",
            encapsulation: ViewEncapsulation.None,
            providers: [KdIntSearchEvent],
            host: { 'class': 'kdx kdx-search' }
        }),
        __metadata("design:paramtypes", [KdIntSearchEvent])
    ], KdSearch);
    return KdSearch;
}());
export { KdSearch };
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoia2QtYW5ndWxhci1zZWFyY2guanMiLCJzb3VyY2VSb290Ijoibmc6Ly9vcGVuZW1pcy1zdHlsZWd1aWRlLWxpYi8iLCJzb3VyY2VzIjpbImtkLWNvbXBvbmVudHMva2QtYW5ndWxhci1zZWFyY2gva2QtYW5ndWxhci1zZWFyY2gudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IjtBQUFBLE9BQU8sRUFDSCxTQUFTLEVBR1QsaUJBQWlCLEVBQ2pCLEtBQUssRUFDTCxNQUFNLEVBQ04sWUFBWSxFQUNmLE1BQU0sZUFBZSxDQUFDO0FBRXZCLE9BQU8sRUFBRSxnQkFBZ0IsRUFBRSxNQUFNLG1CQUFtQixDQUFDO0FBQ3JELE9BQU8sRUFBRSxhQUFhLEVBQUUsTUFBTSxtQkFBbUIsQ0FBQztBQStCbEQ7SUFrQkksa0JBQ1ksWUFBOEI7UUFBOUIsaUJBQVksR0FBWixZQUFZLENBQWtCO1FBbEJuQyxZQUFPLEdBQVEsRUFBRSxDQUFDO1FBQ2xCLG9CQUFlLEdBQVEsRUFBRSxDQUFDO1FBQzFCLGFBQVEsR0FBWSxLQUFLLENBQUM7UUFFekIscUJBQWdCLEdBQVE7WUFDNUIsS0FBSyxFQUFFLFdBQVc7WUFDbEIsaUJBQWlCLEVBQUUsUUFBUTtZQUMzQixXQUFXLEVBQUUsa0JBQWtCO1lBQy9CLE1BQU0sRUFBRSxLQUFLO1lBQ2IsT0FBTyxFQUFFLEVBQUU7U0FDZCxDQUFDO1FBSVEscUJBQWdCLEdBQXNCLElBQUksWUFBWSxFQUFFLENBQUM7UUFDekQsd0JBQW1CLEdBQXNCLElBQUksWUFBWSxFQUFFLENBQUM7SUFJbEUsQ0FBQztJQUVMLDJCQUFRLEdBQVI7UUFBQSxpQkFRQztRQVBHLElBQUksQ0FBQyxlQUFlLEdBQUcsTUFBTSxDQUFDLE1BQU0sQ0FBQyxFQUFFLEVBQUUsSUFBSSxDQUFDLGdCQUFnQixFQUFFLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQztRQUM3RSxJQUFJLElBQUksQ0FBQyxlQUFlLENBQUMsTUFBTTtZQUFFLElBQUksQ0FBQyxPQUFPLENBQUMsU0FBUyxHQUFHLEVBQUUsQ0FBQztRQUU3RCxJQUFJLENBQUMsVUFBVSxHQUFHLElBQUksQ0FBQyxZQUFZLENBQUMsZUFBZSxFQUFFLENBQUMsU0FBUyxDQUFDLFVBQUEsSUFBSTtZQUNoRSxJQUFJLE9BQU8sSUFBSSxLQUFLLFdBQVc7Z0JBQUUsS0FBSSxDQUFDLFFBQVEsR0FBRyxJQUFJLENBQUM7O2dCQUNqRCxLQUFJLENBQUMsUUFBUSxHQUFHLENBQUMsS0FBSSxDQUFDLFFBQVEsQ0FBQztRQUN4QyxDQUFDLENBQUMsQ0FBQztJQUNQLENBQUM7SUFFRCw4QkFBVyxHQUFYO1FBQ0ksSUFBSSxDQUFDLFVBQVUsQ0FBQyxXQUFXLEVBQUUsQ0FBQztJQUNsQyxDQUFDO0lBRU0sZ0NBQWEsR0FBcEIsVUFBcUIsUUFBaUI7UUFDbEMsSUFBSSxRQUFRO1lBQUUsSUFBSSxDQUFDLGdCQUFnQixDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLENBQUM7O1lBQ2xELElBQUksQ0FBQyxtQkFBbUIsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxDQUFDO0lBQ3JELENBQUM7O2dCQXBCeUIsZ0JBQWdCOztJQUxqQztRQUFSLEtBQUssRUFBRTs7NENBQWE7SUFDWDtRQUFULE1BQU0sRUFBRTtrQ0FBbUIsWUFBWTtzREFBMkI7SUFDekQ7UUFBVCxNQUFNLEVBQUU7a0NBQXNCLFlBQVk7eURBQTJCO0lBaEI3RCxRQUFRO1FBN0JwQixTQUFTLENBQUM7WUFDUCxRQUFRLEVBQUUsV0FBVztZQUNyQixRQUFRLEVBQUUsNnRDQXFCVDtZQUNELGFBQWEsRUFBRSxpQkFBaUIsQ0FBQyxJQUFJO1lBQ3JDLFNBQVMsRUFBRSxDQUFDLGdCQUFnQixDQUFDO1lBQzdCLElBQUksRUFBRSxFQUFFLE9BQU8sRUFBRyxnQkFBZ0IsRUFBRTtTQUN2QyxDQUFDO3lDQXFCNEIsZ0JBQWdCO09BbkJqQyxRQUFRLENBd0NwQjtJQUFELGVBQUM7Q0FBQSxBQXhDRCxJQXdDQztTQXhDWSxRQUFRIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHtcclxuICAgIENvbXBvbmVudCxcclxuICAgIE9uSW5pdCxcclxuICAgIE9uRGVzdHJveSxcclxuICAgIFZpZXdFbmNhcHN1bGF0aW9uLFxyXG4gICAgSW5wdXQsXHJcbiAgICBPdXRwdXQsXHJcbiAgICBFdmVudEVtaXR0ZXJcclxufSBmcm9tICdAYW5ndWxhci9jb3JlJztcclxuaW1wb3J0IHsgU3Vic2NyaXB0aW9uIH0gZnJvbSAncnhqcyc7XHJcbmltcG9ydCB7IEtkSW50U2VhcmNoRXZlbnQgfSBmcm9tICcuL2tkLXNlYXJjaC1ldmVudCc7XHJcbmV4cG9ydCB7IEtkU2VhcmNoRXZlbnQgfSBmcm9tICcuL2tkLXNlYXJjaC1ldmVudCc7XHJcblxyXG5AQ29tcG9uZW50KHtcclxuICAgIHNlbGVjdG9yOiAna2Qtc2VhcmNoJyxcclxuICAgIHRlbXBsYXRlOiBgXHJcbiAgICAgICAgPGRpdiBjbGFzcz1cInNlYXJjaC1wYWdlLXdyYXBwZXJcIj5cclxuICAgICAgICAgICAgPGRpdiBjbGFzcz1cInNlYXJjaC1wYWdlLWJveFwiPlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cInNlYXJjaC10aXRsZVwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxoMT57e19zZWFyY2hTZXR0aW5ncy50aXRsZX19PC9oMT5cclxuICAgICAgICAgICAgICAgICAgICA8cCAqbmdJZj1cIl9zZWFyY2hTZXR0aW5ncy5kZXNjcmlwdGlvblwiPnt7X3NlYXJjaFNldHRpbmdzLmRlc2NyaXB0aW9ufX08L3A+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJzZWFyY2gtYm9keVwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxpbnB1dCB0eXBlPVwidGV4dFwiIFsobmdNb2RlbCldPVwiX3Jlc3VsdC5zZWFyY2hUZXh0XCIgcGxhY2Vob2xkZXI9XCJ7e19zZWFyY2hTZXR0aW5ncy5zZWFyY2hQbGFjZWhvbGRlcn19XCIvPlxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgKm5nSWY9XCJfc2VhcmNoU2V0dGluZ3MuZmlsdGVyXCIgY2xhc3M9XCJrZHgtaW5wdXQtc2VsZWN0LXdyYXBwZXJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPHNlbGVjdCBbKG5nTW9kZWwpXT1cIl9yZXN1bHQub3B0aW9uVmFsXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8b3B0aW9uICpuZ0Zvcj1cImxldCBpdGVtIG9mIF9zZWFyY2hTZXR0aW5ncy5vcHRpb25zXCIgW3ZhbHVlXT1cIml0ZW0ua2V5XCI+e3tpdGVtLnZhbHVlfX08L29wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9zZWxlY3Q+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJzZWFyY2gtYnV0dG9uc1wiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxidXR0b24gY2xhc3M9XCJidG4gYnRuLXRleHRcIiBbZGlzYWJsZWRdPVwiX2Rpc2FibGVcIiAoY2xpY2spPVwic2VhcmNoQ2xpY2tlZCh0cnVlKVwiPlNlYXJjaCA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICAgICAgICA8YnV0dG9uIGNsYXNzPVwiYnRuIGJ0bi10ZXh0XCIgW2Rpc2FibGVkXT1cIl9kaXNhYmxlXCIgKGNsaWNrKT1cInNlYXJjaENsaWNrZWQoZmFsc2UpXCI+QWR2YW5jZSBTZWFyY2g8L2J1dHRvbj5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8L2Rpdj5cclxuICAgIGAsXHJcbiAgICBlbmNhcHN1bGF0aW9uOiBWaWV3RW5jYXBzdWxhdGlvbi5Ob25lLFxyXG4gICAgcHJvdmlkZXJzOiBbS2RJbnRTZWFyY2hFdmVudF0sXHJcbiAgICBob3N0OiB7ICdjbGFzcycgOiAna2R4IGtkeC1zZWFyY2gnIH1cclxufSlcclxuXHJcbmV4cG9ydCBjbGFzcyBLZFNlYXJjaCBpbXBsZW1lbnRzIE9uSW5pdCwgT25EZXN0cm95IHtcclxuICAgIHB1YmxpYyBfcmVzdWx0OiBhbnkgPSB7fTtcclxuICAgIHB1YmxpYyBfc2VhcmNoU2V0dGluZ3M6IGFueSA9IHt9O1xyXG4gICAgcHVibGljIF9kaXNhYmxlOiBib29sZWFuID0gZmFsc2U7XHJcblxyXG4gICAgcHJpdmF0ZSBfZGVmYXVsdFNldHRpbmdzOiBhbnkgPSB7XHJcbiAgICAgICAgdGl0bGU6ICdEaXJlY3RvcnknLFxyXG4gICAgICAgIHNlYXJjaFBsYWNlaG9sZGVyOiAnU2VhcmNoJyxcclxuICAgICAgICBkZXNjcmlwdGlvbjogJ1NlYXJjaCBEaXJlY3RvcnknLFxyXG4gICAgICAgIGZpbHRlcjogZmFsc2UsXHJcbiAgICAgICAgb3B0aW9uczogW11cclxuICAgIH07XHJcbiAgICBwcml2YXRlIF9zZWFyY2hTdWI6IFN1YnNjcmlwdGlvbjtcclxuXHJcbiAgICBASW5wdXQoKSBjb25maWc6IGFueTtcclxuICAgIEBPdXRwdXQoKSBzZWFyY2hCdG5DbGlja2VkOiBFdmVudEVtaXR0ZXI8YW55PiA9IG5ldyBFdmVudEVtaXR0ZXIoKTtcclxuICAgIEBPdXRwdXQoKSBhZHZTZWFyY2hCdG5DbGlja2VkOiBFdmVudEVtaXR0ZXI8YW55PiA9IG5ldyBFdmVudEVtaXR0ZXIoKTtcclxuXHJcbiAgICBjb25zdHJ1Y3RvcihcclxuICAgICAgICBwcml2YXRlIF9zZWFyY2hFdmVudDogS2RJbnRTZWFyY2hFdmVudFxyXG4gICAgKSB7IH1cclxuXHJcbiAgICBuZ09uSW5pdCgpOiB2b2lkIHtcclxuICAgICAgICB0aGlzLl9zZWFyY2hTZXR0aW5ncyA9IE9iamVjdC5hc3NpZ24oe30sIHRoaXMuX2RlZmF1bHRTZXR0aW5ncywgdGhpcy5jb25maWcpO1xyXG4gICAgICAgIGlmICh0aGlzLl9zZWFyY2hTZXR0aW5ncy5maWx0ZXIpIHRoaXMuX3Jlc3VsdC5vcHRpb25WYWwgPSAnJztcclxuXHJcbiAgICAgICAgdGhpcy5fc2VhcmNoU3ViID0gdGhpcy5fc2VhcmNoRXZlbnQub25EaXNhYmxlQnV0dG9uKCkuc3Vic2NyaWJlKGRhdGEgPT4ge1xyXG4gICAgICAgICAgICBpZiAodHlwZW9mIGRhdGEgIT09ICd1bmRlZmluZWQnKSB0aGlzLl9kaXNhYmxlID0gZGF0YTtcclxuICAgICAgICAgICAgZWxzZSB0aGlzLl9kaXNhYmxlID0gIXRoaXMuX2Rpc2FibGU7XHJcbiAgICAgICAgfSk7XHJcbiAgICB9XHJcblxyXG4gICAgbmdPbkRlc3Ryb3koKTogdm9pZCB7XHJcbiAgICAgICAgdGhpcy5fc2VhcmNoU3ViLnVuc3Vic2NyaWJlKCk7XHJcbiAgICB9XHJcblxyXG4gICAgcHVibGljIHNlYXJjaENsaWNrZWQoaXNTZWFyY2g6IGJvb2xlYW4pOiB2b2lkIHtcclxuICAgICAgICBpZiAoaXNTZWFyY2gpIHRoaXMuc2VhcmNoQnRuQ2xpY2tlZC5lbWl0KHRoaXMuX3Jlc3VsdCk7XHJcbiAgICAgICAgZWxzZSB0aGlzLmFkdlNlYXJjaEJ0bkNsaWNrZWQuZW1pdCh0aGlzLl9yZXN1bHQpO1xyXG4gICAgfVxyXG59XHJcbiJdfQ==