import { __decorate, __metadata } from "tslib";
import { Injectable } from '@angular/core';
import { KdBroadcaster } from '../kd-common/index';
import * as i0 from "@angular/core";
import * as i1 from "../kd-common/kd-broadcaster-svc";
var KdIntSearchEvent = /** @class */ (function () {
    function KdIntSearchEvent(_broadcaster) {
        this._broadcaster = _broadcaster;
    }
    KdIntSearchEvent.prototype.onDisableButton = function () {
        return this._broadcaster.on('KdDisableButton');
    };
    KdIntSearchEvent.ctorParameters = function () { return [
        { type: KdBroadcaster }
    ]; };
    KdIntSearchEvent = __decorate([
        Injectable(),
        __metadata("design:paramtypes", [KdBroadcaster])
    ], KdIntSearchEvent);
    return KdIntSearchEvent;
}());
export { KdIntSearchEvent };
var KdSearchEvent = /** @class */ (function () {
    function KdSearchEvent(_broadcaster) {
        this._broadcaster = _broadcaster;
    }
    KdSearchEvent.prototype.disableButton = function (data) {
        this._broadcaster.broadcast('KdDisableButton', data);
    };
    KdSearchEvent.ctorParameters = function () { return [
        { type: KdBroadcaster }
    ]; };
    KdSearchEvent.ɵprov = i0.ɵɵdefineInjectable({ factory: function KdSearchEvent_Factory() { return new KdSearchEvent(i0.ɵɵinject(i1.KdBroadcaster)); }, token: KdSearchEvent, providedIn: "root" });
    KdSearchEvent = __decorate([
        Injectable({
            providedIn: 'root'
        }),
        __metadata("design:paramtypes", [KdBroadcaster])
    ], KdSearchEvent);
    return KdSearchEvent;
}());
export { KdSearchEvent };
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoia2Qtc2VhcmNoLWV2ZW50LmpzIiwic291cmNlUm9vdCI6Im5nOi8vb3BlbmVtaXMtc3R5bGVndWlkZS1saWIvIiwic291cmNlcyI6WyJrZC1jb21wb25lbnRzL2tkLWFuZ3VsYXItc2VhcmNoL2tkLXNlYXJjaC1ldmVudC50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiO0FBQUEsT0FBTyxFQUFFLFVBQVUsRUFBRSxNQUFNLGVBQWUsQ0FBQztBQUUzQyxPQUFPLEVBQUUsYUFBYSxFQUFFLE1BQU0sb0JBQW9CLENBQUM7OztBQUduRDtJQUNJLDBCQUFvQixZQUEyQjtRQUEzQixpQkFBWSxHQUFaLFlBQVksQ0FBZTtJQUFJLENBQUM7SUFFcEQsMENBQWUsR0FBZjtRQUNJLE9BQU8sSUFBSSxDQUFDLFlBQVksQ0FBQyxFQUFFLENBQU0saUJBQWlCLENBQUMsQ0FBQztJQUN4RCxDQUFDOztnQkFKaUMsYUFBYTs7SUFEdEMsZ0JBQWdCO1FBRDVCLFVBQVUsRUFBRTt5Q0FFeUIsYUFBYTtPQUR0QyxnQkFBZ0IsQ0FNNUI7SUFBRCx1QkFBQztDQUFBLEFBTkQsSUFNQztTQU5ZLGdCQUFnQjtBQVc3QjtJQUNJLHVCQUFvQixZQUEyQjtRQUEzQixpQkFBWSxHQUFaLFlBQVksQ0FBZTtJQUFJLENBQUM7SUFFcEQscUNBQWEsR0FBYixVQUFjLElBQVU7UUFDcEIsSUFBSSxDQUFDLFlBQVksQ0FBQyxTQUFTLENBQUMsaUJBQWlCLEVBQUUsSUFBSSxDQUFDLENBQUM7SUFDekQsQ0FBQzs7Z0JBSmlDLGFBQWE7OztJQUR0QyxhQUFhO1FBSHpCLFVBQVUsQ0FBQztZQUNSLFVBQVUsRUFBRSxNQUFNO1NBQ3JCLENBQUM7eUNBRW9DLGFBQWE7T0FEdEMsYUFBYSxDQU16Qjt3QkF0QkQ7Q0FzQkMsQUFORCxJQU1DO1NBTlksYUFBYSIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IEluamVjdGFibGUgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcclxuaW1wb3J0IHsgT2JzZXJ2YWJsZSB9IGZyb20gJ3J4anMnO1xyXG5pbXBvcnQgeyBLZEJyb2FkY2FzdGVyIH0gZnJvbSAnLi4va2QtY29tbW9uL2luZGV4JztcclxuXHJcbkBJbmplY3RhYmxlKClcclxuZXhwb3J0IGNsYXNzIEtkSW50U2VhcmNoRXZlbnQge1xyXG4gICAgY29uc3RydWN0b3IocHJpdmF0ZSBfYnJvYWRjYXN0ZXI6IEtkQnJvYWRjYXN0ZXIpIHsgfVxyXG5cclxuICAgIG9uRGlzYWJsZUJ1dHRvbigpOiBPYnNlcnZhYmxlPGFueT4ge1xyXG4gICAgICAgIHJldHVybiB0aGlzLl9icm9hZGNhc3Rlci5vbjxhbnk+KCdLZERpc2FibGVCdXR0b24nKTtcclxuICAgIH1cclxufVxyXG5cclxuQEluamVjdGFibGUoe1xyXG4gICAgcHJvdmlkZWRJbjogJ3Jvb3QnXHJcbn0pXHJcbmV4cG9ydCBjbGFzcyBLZFNlYXJjaEV2ZW50IHtcclxuICAgIGNvbnN0cnVjdG9yKHByaXZhdGUgX2Jyb2FkY2FzdGVyOiBLZEJyb2FkY2FzdGVyKSB7IH1cclxuXHJcbiAgICBkaXNhYmxlQnV0dG9uKGRhdGE/OiBhbnkpOiB2b2lkIHtcclxuICAgICAgICB0aGlzLl9icm9hZGNhc3Rlci5icm9hZGNhc3QoJ0tkRGlzYWJsZUJ1dHRvbicsIGRhdGEpO1xyXG4gICAgfVxyXG59XHJcbiJdfQ==