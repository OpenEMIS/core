import { __decorate, __metadata } from "tslib";
import { Component, Input, Output, EventEmitter, ViewEncapsulation } from '@angular/core';
import { KdDomElemSvc } from '../kd-common/index';
var KdButtonGroup = /** @class */ (function () {
    function KdButtonGroup(_domElmSvc) {
        this._domElmSvc = _domElmSvc;
        this.buttons = [];
        this.disableToolTip = true;
        this.isIconOnly = false;
        this.name = 'kdbuttongroup';
        this.updatedValue = new EventEmitter();
    }
    KdButtonGroup.prototype.ngOnChanges = function (_simpleChanges) {
        if (_simpleChanges.hasOwnProperty('data')) {
            this.buttons = this._buttonSizeValidation(this.data);
        }
        if (_simpleChanges.hasOwnProperty('type') && typeof _simpleChanges.type.currentValue !== 'undefined') {
            this.config['type'] = this.type;
        }
        if (_simpleChanges.hasOwnProperty('value') && typeof _simpleChanges.value.currentValue !== 'undefined') {
            this._validateValueType();
        }
        if (_simpleChanges.hasOwnProperty('config')) {
            if (this.config.hasOwnProperty('iconOnly') && typeof this.config.iconOnly === 'boolean') {
                this.isIconOnly = this.config.iconOnly;
                this.disableToolTip = !this.isIconOnly;
            }
        }
    };
    KdButtonGroup.prototype.emitValue = function () {
        this.updatedValue.emit(this.modalValue);
    };
    KdButtonGroup.prototype.isButtonDisabled = function (_btnCond) {
        var btnDisabled;
        if (typeof this.disabled !== 'undefined' && this.disabled)
            btnDisabled = true;
        else
            btnDisabled = _btnCond ? _btnCond : false;
        return btnDisabled;
    };
    KdButtonGroup.prototype._validateValueType = function () {
        if (this.config.type === 'radio' &&
            this.buttons.length > 0 &&
            typeof this.buttons[0]['value'] !== typeof this.value) {
            console.warn('Value data type mismatch! ' + typeof this.buttons[0]['value'] + ' !== ' + typeof this.value);
        }
        this.modalValue = this.value;
    };
    KdButtonGroup.prototype._buttonSizeValidation = function (_buttons) {
        var btnList = [];
        var maxSize = 6;
        if (typeof _buttons === 'undefined')
            return [];
        this._validateValueType();
        for (var i = 0; i < _buttons.length; i++) {
            if (i < maxSize) {
                var button = _buttons[i];
                if (button.icon)
                    button.icon = this._domElmSvc.setIconClass(button.icon);
                btnList.push(button);
            }
            else {
                break;
            }
        }
        return btnList;
    };
    KdButtonGroup.ctorParameters = function () { return [
        { type: KdDomElemSvc }
    ]; };
    __decorate([
        Input(),
        __metadata("design:type", Array)
    ], KdButtonGroup.prototype, "data", void 0);
    __decorate([
        Input(),
        __metadata("design:type", String)
    ], KdButtonGroup.prototype, "name", void 0);
    __decorate([
        Input(),
        __metadata("design:type", Object)
    ], KdButtonGroup.prototype, "value", void 0);
    __decorate([
        Input(),
        __metadata("design:type", Boolean)
    ], KdButtonGroup.prototype, "disabled", void 0);
    __decorate([
        Input(),
        __metadata("design:type", Object)
    ], KdButtonGroup.prototype, "config", void 0);
    __decorate([
        Input(),
        __metadata("design:type", String)
    ], KdButtonGroup.prototype, "type", void 0);
    __decorate([
        Output(),
        __metadata("design:type", EventEmitter)
    ], KdButtonGroup.prototype, "updatedValue", void 0);
    KdButtonGroup = __decorate([
        Component({
            selector: 'kd-button-group',
            template: "\n        <ng-container [ngSwitch]=\"config.type\">\n            <ng-container  *ngSwitchCase=\"'radio'\" >\n                <div ngbRadioGroup class=\"btn-group btn-group-toggle\" name=\"{{name}}\" [(ngModel)]=\"modalValue\" (ngModelChange)=\"emitValue()\">\n                    <label ngbButtonLabel class=\"btn-outline\" [class.btn-icon]=\"isIconOnly\" *ngFor=\"let button of buttons\" [kd-tooltip-dir]=\"button.key\" tooltipPosition=\"bottom\" tooltipStyleClass=\"kdx-tooltip-default\" [tooltipDisabled]=\"disableToolTip\">\n                        <i *ngIf=\"button.icon\" class=\"{{button.icon}}\"></i>\n                        <span *ngIf=\"button.key && !isIconOnly\" >{{button.key}}</span>\n                        <input ngbButton type=\"radio\" [value]=\"button.value\" [disabled]=\"isButtonDisabled(button.disabled)\" >\n                    </label>\n                </div>\n            </ng-container>\n\n            <div *ngSwitchDefault class=\"btn-group btn-group-toggle btn-group-checkbox\">\n                <label ngbButtonLabel class=\"btn-outline\" [class.btn-icon]=\"isIconOnly\" *ngFor=\"let button of buttons\" [kd-tooltip-dir]=\"button.key\" tooltipPosition=\"bottom\" tooltipStyleClass=\"kdx-tooltip-default\" [tooltipDisabled]=\"disableToolTip\">\n                    <i *ngIf=\"button.icon\" class=\"{{button.icon}}\"></i>\n                    <span *ngIf=\"button.key && !isIconOnly\" >{{button.key}}</span>\n                    <input ngbButton type=\"checkbox\" [(ngModel)]=\"modalValue[button.value]\" (ngModelChange)=\"emitValue()\" [disabled]=\"isButtonDisabled(button.disabled)\">\n                </label>\n            </div>\n        </ng-container>\n    ",
            encapsulation: ViewEncapsulation.None,
            host: { 'class': 'kdx-button-group' }
        }),
        __metadata("design:paramtypes", [KdDomElemSvc])
    ], KdButtonGroup);
    return KdButtonGroup;
}());
export { KdButtonGroup };
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoia2QtYW5ndWxhci1idXR0b24tZ3JvdXAuanMiLCJzb3VyY2VSb290Ijoibmc6Ly9vcGVuZW1pcy1zdHlsZWd1aWRlLWxpYi8iLCJzb3VyY2VzIjpbImtkLWNvbXBvbmVudHMva2QtYW5ndWxhci1idXR0b24tZ3JvdXAva2QtYW5ndWxhci1idXR0b24tZ3JvdXAudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IjtBQUFBLE9BQU8sRUFDSCxTQUFTLEVBQ1QsS0FBSyxFQUNMLE1BQU0sRUFDTixZQUFZLEVBQ1osaUJBQWlCLEVBR3BCLE1BQU0sZUFBZSxDQUFDO0FBQ3ZCLE9BQU8sRUFBRSxZQUFZLEVBQUUsTUFBTSxvQkFBb0IsQ0FBQztBQThCbEQ7SUFnQkksdUJBQW9CLFVBQXdCO1FBQXhCLGVBQVUsR0FBVixVQUFVLENBQWM7UUFmckMsWUFBTyxHQUFjLEVBQUUsQ0FBQztRQUN4QixtQkFBYyxHQUFZLElBQUksQ0FBQztRQUUvQixlQUFVLEdBQVksS0FBSyxDQUFDO1FBSzFCLFNBQUksR0FBWSxlQUFlLENBQUM7UUFLL0IsaUJBQVksR0FBc0IsSUFBSSxZQUFZLEVBQUUsQ0FBQztJQUVmLENBQUM7SUFFakQsbUNBQVcsR0FBWCxVQUFZLGNBQTZCO1FBRXJDLElBQUksY0FBYyxDQUFDLGNBQWMsQ0FBQyxNQUFNLENBQUMsRUFBRTtZQUN2QyxJQUFJLENBQUMsT0FBTyxHQUFHLElBQUksQ0FBQyxxQkFBcUIsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUM7U0FDeEQ7UUFFRCxJQUFJLGNBQWMsQ0FBQyxjQUFjLENBQUMsTUFBTSxDQUFDLElBQUksT0FBTyxjQUFjLENBQUMsSUFBSSxDQUFDLFlBQVksS0FBSyxXQUFXLEVBQUU7WUFDbEcsSUFBSSxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsR0FBRyxJQUFJLENBQUMsSUFBSSxDQUFDO1NBQ25DO1FBRUQsSUFBSSxjQUFjLENBQUMsY0FBYyxDQUFDLE9BQU8sQ0FBQyxJQUFJLE9BQU8sY0FBYyxDQUFDLEtBQUssQ0FBQyxZQUFZLEtBQUssV0FBVyxFQUFFO1lBQ3BHLElBQUksQ0FBQyxrQkFBa0IsRUFBRSxDQUFDO1NBQzdCO1FBRUQsSUFBSSxjQUFjLENBQUMsY0FBYyxDQUFDLFFBQVEsQ0FBQyxFQUFFO1lBQ3pDLElBQUksSUFBSSxDQUFDLE1BQU0sQ0FBQyxjQUFjLENBQUMsVUFBVSxDQUFDLElBQUksT0FBTyxJQUFJLENBQUMsTUFBTSxDQUFDLFFBQVEsS0FBSyxTQUFTLEVBQUU7Z0JBQ3JGLElBQUksQ0FBQyxVQUFVLEdBQUcsSUFBSSxDQUFDLE1BQU0sQ0FBQyxRQUFRLENBQUM7Z0JBQ3ZDLElBQUksQ0FBQyxjQUFjLEdBQUcsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDO2FBQzFDO1NBQ0o7SUFDTCxDQUFDO0lBRU0saUNBQVMsR0FBaEI7UUFDSSxJQUFJLENBQUMsWUFBWSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLENBQUM7SUFDNUMsQ0FBQztJQUVNLHdDQUFnQixHQUF2QixVQUF3QixRQUF3QjtRQUM1QyxJQUFJLFdBQW9CLENBQUM7UUFFekIsSUFBSSxPQUFPLElBQUksQ0FBQyxRQUFRLEtBQUssV0FBVyxJQUFJLElBQUksQ0FBQyxRQUFRO1lBQUUsV0FBVyxHQUFHLElBQUksQ0FBQzs7WUFDekUsV0FBVyxHQUFHLFFBQVEsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUM7UUFFL0MsT0FBTyxXQUFXLENBQUM7SUFDdkIsQ0FBQztJQUVPLDBDQUFrQixHQUExQjtRQUNJLElBQUksSUFBSSxDQUFDLE1BQU0sQ0FBQyxJQUFJLEtBQUssT0FBTztZQUM1QixJQUFJLENBQUMsT0FBTyxDQUFDLE1BQU0sR0FBRyxDQUFDO1lBQ3ZCLE9BQU8sSUFBSSxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsS0FBSyxPQUFPLElBQUksQ0FBQyxLQUFLLEVBQ3ZEO1lBQ0UsT0FBTyxDQUFDLElBQUksQ0FBQyw0QkFBNEIsR0FBRyxPQUFPLElBQUksQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLEdBQUcsT0FBTyxHQUFHLE9BQU8sSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFDO1NBQzlHO1FBRUQsSUFBSSxDQUFDLFVBQVUsR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDO0lBQ2pDLENBQUM7SUFFTyw2Q0FBcUIsR0FBN0IsVUFBOEIsUUFBbUI7UUFDN0MsSUFBSSxPQUFPLEdBQWMsRUFBRSxDQUFDO1FBQzVCLElBQUksT0FBTyxHQUFXLENBQUMsQ0FBQztRQUV4QixJQUFJLE9BQU8sUUFBUSxLQUFLLFdBQVc7WUFBRSxPQUFPLEVBQUUsQ0FBQztRQUMvQyxJQUFJLENBQUMsa0JBQWtCLEVBQUUsQ0FBQztRQUUxQixLQUFLLElBQUksQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLEdBQUcsUUFBUSxDQUFDLE1BQU0sRUFBRSxDQUFDLEVBQUUsRUFBRTtZQUN0QyxJQUFJLENBQUMsR0FBRyxPQUFPLEVBQUU7Z0JBQ2IsSUFBSSxNQUFNLEdBQVEsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDO2dCQUM5QixJQUFJLE1BQU0sQ0FBQyxJQUFJO29CQUFFLE1BQU0sQ0FBQyxJQUFJLEdBQUcsSUFBSSxDQUFDLFVBQVUsQ0FBQyxZQUFZLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxDQUFDO2dCQUN6RSxPQUFPLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDO2FBQ3hCO2lCQUNJO2dCQUNELE1BQU07YUFDVDtTQUNKO1FBRUQsT0FBTyxPQUFPLENBQUM7SUFDbkIsQ0FBQzs7Z0JBbkUrQixZQUFZOztJQVJuQztRQUFSLEtBQUssRUFBRTtrQ0FBTyxLQUFLOytDQUFnQjtJQUMzQjtRQUFSLEtBQUssRUFBRTs7K0NBQWlDO0lBQ2hDO1FBQVIsS0FBSyxFQUFFOztnREFBWTtJQUNYO1FBQVIsS0FBSyxFQUFFOzttREFBb0I7SUFDbkI7UUFBUixLQUFLLEVBQUU7O2lEQUEwQjtJQUN6QjtRQUFSLEtBQUssRUFBRTs7K0NBQTJCO0lBQ3pCO1FBQVQsTUFBTSxFQUFFO2tDQUFlLFlBQVk7dURBQTJCO0lBZHRELGFBQWE7UUEzQnpCLFNBQVMsQ0FBQztZQUNQLFFBQVEsRUFBRSxpQkFBaUI7WUFDM0IsUUFBUSxFQUFFLDhwREFvQlQ7WUFDRCxhQUFhLEVBQUUsaUJBQWlCLENBQUMsSUFBSTtZQUNyQyxJQUFJLEVBQUUsRUFBRSxPQUFPLEVBQUUsa0JBQWtCLEVBQUU7U0FDeEMsQ0FBQzt5Q0FrQmtDLFlBQVk7T0FoQm5DLGFBQWEsQ0FvRnpCO0lBQUQsb0JBQUM7Q0FBQSxBQXBGRCxJQW9GQztTQXBGWSxhQUFhIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHtcclxuICAgIENvbXBvbmVudCxcclxuICAgIElucHV0LFxyXG4gICAgT3V0cHV0LFxyXG4gICAgRXZlbnRFbWl0dGVyLFxyXG4gICAgVmlld0VuY2Fwc3VsYXRpb24sXHJcbiAgICBPbkNoYW5nZXMsXHJcbiAgICBTaW1wbGVDaGFuZ2VzXHJcbn0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XHJcbmltcG9ydCB7IEtkRG9tRWxlbVN2YyB9IGZyb20gJy4uL2tkLWNvbW1vbi9pbmRleCc7XHJcbmltcG9ydCB7IElCdG5Hcm91cENvbmZpZywgSUJ0bkdyb3VwRGF0YSB9IGZyb20gJy4va2QtYW5ndWxhci1idXR0b24tZ3JvdXAtaW50ZXJmYWNlJztcclxuXHJcbkBDb21wb25lbnQoe1xyXG4gICAgc2VsZWN0b3I6ICdrZC1idXR0b24tZ3JvdXAnLFxyXG4gICAgdGVtcGxhdGU6IGBcclxuICAgICAgICA8bmctY29udGFpbmVyIFtuZ1N3aXRjaF09XCJjb25maWcudHlwZVwiPlxyXG4gICAgICAgICAgICA8bmctY29udGFpbmVyICAqbmdTd2l0Y2hDYXNlPVwiJ3JhZGlvJ1wiID5cclxuICAgICAgICAgICAgICAgIDxkaXYgbmdiUmFkaW9Hcm91cCBjbGFzcz1cImJ0bi1ncm91cCBidG4tZ3JvdXAtdG9nZ2xlXCIgbmFtZT1cInt7bmFtZX19XCIgWyhuZ01vZGVsKV09XCJtb2RhbFZhbHVlXCIgKG5nTW9kZWxDaGFuZ2UpPVwiZW1pdFZhbHVlKClcIj5cclxuICAgICAgICAgICAgICAgICAgICA8bGFiZWwgbmdiQnV0dG9uTGFiZWwgY2xhc3M9XCJidG4tb3V0bGluZVwiIFtjbGFzcy5idG4taWNvbl09XCJpc0ljb25Pbmx5XCIgKm5nRm9yPVwibGV0IGJ1dHRvbiBvZiBidXR0b25zXCIgW2tkLXRvb2x0aXAtZGlyXT1cImJ1dHRvbi5rZXlcIiB0b29sdGlwUG9zaXRpb249XCJib3R0b21cIiB0b29sdGlwU3R5bGVDbGFzcz1cImtkeC10b29sdGlwLWRlZmF1bHRcIiBbdG9vbHRpcERpc2FibGVkXT1cImRpc2FibGVUb29sVGlwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxpICpuZ0lmPVwiYnV0dG9uLmljb25cIiBjbGFzcz1cInt7YnV0dG9uLmljb259fVwiPjwvaT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gKm5nSWY9XCJidXR0b24ua2V5ICYmICFpc0ljb25Pbmx5XCIgPnt7YnV0dG9uLmtleX19PC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8aW5wdXQgbmdiQnV0dG9uIHR5cGU9XCJyYWRpb1wiIFt2YWx1ZV09XCJidXR0b24udmFsdWVcIiBbZGlzYWJsZWRdPVwiaXNCdXR0b25EaXNhYmxlZChidXR0b24uZGlzYWJsZWQpXCIgPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPC9uZy1jb250YWluZXI+XHJcblxyXG4gICAgICAgICAgICA8ZGl2ICpuZ1N3aXRjaERlZmF1bHQgY2xhc3M9XCJidG4tZ3JvdXAgYnRuLWdyb3VwLXRvZ2dsZSBidG4tZ3JvdXAtY2hlY2tib3hcIj5cclxuICAgICAgICAgICAgICAgIDxsYWJlbCBuZ2JCdXR0b25MYWJlbCBjbGFzcz1cImJ0bi1vdXRsaW5lXCIgW2NsYXNzLmJ0bi1pY29uXT1cImlzSWNvbk9ubHlcIiAqbmdGb3I9XCJsZXQgYnV0dG9uIG9mIGJ1dHRvbnNcIiBba2QtdG9vbHRpcC1kaXJdPVwiYnV0dG9uLmtleVwiIHRvb2x0aXBQb3NpdGlvbj1cImJvdHRvbVwiIHRvb2x0aXBTdHlsZUNsYXNzPVwia2R4LXRvb2x0aXAtZGVmYXVsdFwiIFt0b29sdGlwRGlzYWJsZWRdPVwiZGlzYWJsZVRvb2xUaXBcIj5cclxuICAgICAgICAgICAgICAgICAgICA8aSAqbmdJZj1cImJ1dHRvbi5pY29uXCIgY2xhc3M9XCJ7e2J1dHRvbi5pY29ufX1cIj48L2k+XHJcbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gKm5nSWY9XCJidXR0b24ua2V5ICYmICFpc0ljb25Pbmx5XCIgPnt7YnV0dG9uLmtleX19PC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgIDxpbnB1dCBuZ2JCdXR0b24gdHlwZT1cImNoZWNrYm94XCIgWyhuZ01vZGVsKV09XCJtb2RhbFZhbHVlW2J1dHRvbi52YWx1ZV1cIiAobmdNb2RlbENoYW5nZSk9XCJlbWl0VmFsdWUoKVwiIFtkaXNhYmxlZF09XCJpc0J1dHRvbkRpc2FibGVkKGJ1dHRvbi5kaXNhYmxlZClcIj5cclxuICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDwvbmctY29udGFpbmVyPlxyXG4gICAgYCxcclxuICAgIGVuY2Fwc3VsYXRpb246IFZpZXdFbmNhcHN1bGF0aW9uLk5vbmUsXHJcbiAgICBob3N0OiB7ICdjbGFzcyc6ICdrZHgtYnV0dG9uLWdyb3VwJyB9XHJcbn0pXHJcblxyXG5leHBvcnQgY2xhc3MgS2RCdXR0b25Hcm91cCBpbXBsZW1lbnRzIE9uQ2hhbmdlcyB7XHJcbiAgICBwdWJsaWMgYnV0dG9uczogQXJyYXk8e30+ID0gW107XHJcbiAgICBwdWJsaWMgZGlzYWJsZVRvb2xUaXA6IGJvb2xlYW4gPSB0cnVlO1xyXG4gICAgcHVibGljIGlzU3RyaW5nTW9kZTogYm9vbGVhbjtcclxuICAgIHB1YmxpYyBpc0ljb25Pbmx5OiBib29sZWFuID0gZmFsc2U7XHJcblxyXG4gICAgcHVibGljIG1vZGFsVmFsdWU6IGFueTtcclxuXHJcbiAgICBASW5wdXQoKSBkYXRhOiBBcnJheTxJQnRuR3JvdXBEYXRhPjtcclxuICAgIEBJbnB1dCgpIG5hbWU/OiBzdHJpbmcgPSAna2RidXR0b25ncm91cCc7XHJcbiAgICBASW5wdXQoKSB2YWx1ZTogYW55O1xyXG4gICAgQElucHV0KCkgZGlzYWJsZWQ/OiBib29sZWFuO1xyXG4gICAgQElucHV0KCkgY29uZmlnPzogSUJ0bkdyb3VwQ29uZmlnO1xyXG4gICAgQElucHV0KCkgdHlwZT86ICdjaGVja2JveCd8J3JhZGlvJztcclxuICAgIEBPdXRwdXQoKSB1cGRhdGVkVmFsdWU6IEV2ZW50RW1pdHRlcjxhbnk+ID0gbmV3IEV2ZW50RW1pdHRlcigpO1xyXG5cclxuICAgIGNvbnN0cnVjdG9yKHByaXZhdGUgX2RvbUVsbVN2YzogS2REb21FbGVtU3ZjKSB7IH1cclxuXHJcbiAgICBuZ09uQ2hhbmdlcyhfc2ltcGxlQ2hhbmdlczogU2ltcGxlQ2hhbmdlcyk6IHZvaWQge1xyXG5cclxuICAgICAgICBpZiAoX3NpbXBsZUNoYW5nZXMuaGFzT3duUHJvcGVydHkoJ2RhdGEnKSkge1xyXG4gICAgICAgICAgICB0aGlzLmJ1dHRvbnMgPSB0aGlzLl9idXR0b25TaXplVmFsaWRhdGlvbih0aGlzLmRhdGEpO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgaWYgKF9zaW1wbGVDaGFuZ2VzLmhhc093blByb3BlcnR5KCd0eXBlJykgJiYgdHlwZW9mIF9zaW1wbGVDaGFuZ2VzLnR5cGUuY3VycmVudFZhbHVlICE9PSAndW5kZWZpbmVkJykge1xyXG4gICAgICAgICAgICB0aGlzLmNvbmZpZ1sndHlwZSddID0gdGhpcy50eXBlO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgaWYgKF9zaW1wbGVDaGFuZ2VzLmhhc093blByb3BlcnR5KCd2YWx1ZScpICYmIHR5cGVvZiBfc2ltcGxlQ2hhbmdlcy52YWx1ZS5jdXJyZW50VmFsdWUgIT09ICd1bmRlZmluZWQnKSB7XHJcbiAgICAgICAgICAgIHRoaXMuX3ZhbGlkYXRlVmFsdWVUeXBlKCk7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICBpZiAoX3NpbXBsZUNoYW5nZXMuaGFzT3duUHJvcGVydHkoJ2NvbmZpZycpKSB7XHJcbiAgICAgICAgICAgIGlmICh0aGlzLmNvbmZpZy5oYXNPd25Qcm9wZXJ0eSgnaWNvbk9ubHknKSAmJiB0eXBlb2YgdGhpcy5jb25maWcuaWNvbk9ubHkgPT09ICdib29sZWFuJykge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5pc0ljb25Pbmx5ID0gdGhpcy5jb25maWcuaWNvbk9ubHk7XHJcbiAgICAgICAgICAgICAgICB0aGlzLmRpc2FibGVUb29sVGlwID0gIXRoaXMuaXNJY29uT25seTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICBwdWJsaWMgZW1pdFZhbHVlKCk6IHZvaWQge1xyXG4gICAgICAgIHRoaXMudXBkYXRlZFZhbHVlLmVtaXQodGhpcy5tb2RhbFZhbHVlKTtcclxuICAgIH1cclxuXHJcbiAgICBwdWJsaWMgaXNCdXR0b25EaXNhYmxlZChfYnRuQ29uZDogYm9vbGVhbiB8IG51bGwpOiBib29sZWFuIHtcclxuICAgICAgICBsZXQgYnRuRGlzYWJsZWQ6IGJvb2xlYW47XHJcblxyXG4gICAgICAgIGlmICh0eXBlb2YgdGhpcy5kaXNhYmxlZCAhPT0gJ3VuZGVmaW5lZCcgJiYgdGhpcy5kaXNhYmxlZCkgYnRuRGlzYWJsZWQgPSB0cnVlO1xyXG4gICAgICAgIGVsc2UgYnRuRGlzYWJsZWQgPSBfYnRuQ29uZCA/IF9idG5Db25kIDogZmFsc2U7XHJcblxyXG4gICAgICAgIHJldHVybiBidG5EaXNhYmxlZDtcclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF92YWxpZGF0ZVZhbHVlVHlwZSgpOiB2b2lkIHtcclxuICAgICAgICBpZiAodGhpcy5jb25maWcudHlwZSA9PT0gJ3JhZGlvJyAmJlxyXG4gICAgICAgICAgICB0aGlzLmJ1dHRvbnMubGVuZ3RoID4gMCAmJlxyXG4gICAgICAgICAgICB0eXBlb2YgdGhpcy5idXR0b25zWzBdWyd2YWx1ZSddICE9PSB0eXBlb2YgdGhpcy52YWx1ZVxyXG4gICAgICAgICkge1xyXG4gICAgICAgICAgICBjb25zb2xlLndhcm4oJ1ZhbHVlIGRhdGEgdHlwZSBtaXNtYXRjaCEgJyArIHR5cGVvZiB0aGlzLmJ1dHRvbnNbMF1bJ3ZhbHVlJ10gKyAnICE9PSAnICsgdHlwZW9mIHRoaXMudmFsdWUpO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgdGhpcy5tb2RhbFZhbHVlID0gdGhpcy52YWx1ZTtcclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF9idXR0b25TaXplVmFsaWRhdGlvbihfYnV0dG9uczogQXJyYXk8e30+KTogQXJyYXk8e30+IHtcclxuICAgICAgICBsZXQgYnRuTGlzdDogQXJyYXk8e30+ID0gW107XHJcbiAgICAgICAgbGV0IG1heFNpemU6IG51bWJlciA9IDY7XHJcblxyXG4gICAgICAgIGlmICh0eXBlb2YgX2J1dHRvbnMgPT09ICd1bmRlZmluZWQnKSByZXR1cm4gW107XHJcbiAgICAgICAgdGhpcy5fdmFsaWRhdGVWYWx1ZVR5cGUoKTtcclxuXHJcbiAgICAgICAgZm9yIChsZXQgaSA9IDA7IGkgPCBfYnV0dG9ucy5sZW5ndGg7IGkrKykge1xyXG4gICAgICAgICAgICBpZiAoaSA8IG1heFNpemUpIHtcclxuICAgICAgICAgICAgICAgIGxldCBidXR0b246IGFueSA9IF9idXR0b25zW2ldO1xyXG4gICAgICAgICAgICAgICAgaWYgKGJ1dHRvbi5pY29uKSBidXR0b24uaWNvbiA9IHRoaXMuX2RvbUVsbVN2Yy5zZXRJY29uQ2xhc3MoYnV0dG9uLmljb24pO1xyXG4gICAgICAgICAgICAgICAgYnRuTGlzdC5wdXNoKGJ1dHRvbik7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgZWxzZSB7XHJcbiAgICAgICAgICAgICAgICBicmVhaztcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgcmV0dXJuIGJ0bkxpc3Q7XHJcbiAgICB9XHJcbn1cclxuIl19