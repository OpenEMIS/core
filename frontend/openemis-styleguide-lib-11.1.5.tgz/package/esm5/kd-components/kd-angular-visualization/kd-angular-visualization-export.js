import { __decorate } from "tslib";
import { Injectable } from '@angular/core';
import * as jsPDF from 'jspdf';
import * as domtoimage from 'dom-to-image';
import { saveAs } from 'file-saver';
import print from 'print-js';
import { Observable } from 'rxjs';
import { pxtoMM, defaultPdfOptions, } from './kd-angular-visualization-interface';
import * as i0 from "@angular/core";
var KdVisualizationExport = /** @class */ (function () {
    function KdVisualizationExport() {
        this._options = {};
        this._defaultOptions = { fileName: 'file' };
        this._incompatibleBrowserMsg = ' is not supported in this browser. For the best experience, please use other browsers like Firefox or Chrome.';
    }
    /**
     * main entry to export class
     * param {Element} _rawData Element to export
     * param {string} _format  can be 'print', 'png', 'jpg', 'pdf', 'svg', 'imageUrl'
     * param {object} _options contains fileName, size, pdf options etc
     */
    KdVisualizationExport.prototype.exportElement = function (_rawData, _format, _options) {
        this._options = Object.assign({}, this._defaultOptions, _options);
        this._options.fileName = this._options.fileName + '.' + _format;
        switch (_format) {
            case 'png':
            case 'jpg':
                this._exportToBlob(_rawData, this._options);
                break;
            case 'pdf':
            case 'print':
                this._exportPdfOrPrint(_rawData, _format, this._options);
                break;
            case 'svg':
                this._exportToSvg(_rawData, this._options);
                break;
            case 'imageUrl':
                return this.getImageUrl(_rawData, this._options).then(function (imageUrl) { return imageUrl; });
            default:
                console.error('please provide a format to export');
                break;
        }
    };
    // ================================= PNG and JPG ==================================
    KdVisualizationExport.prototype._exportToBlob = function (_rawData, _options) {
        domtoimage.toBlob(_rawData, _options)
            .then(function (blob) {
            saveAs(blob, _options.fileName);
        })
            .catch(function (error) {
            console.error('domtoimage returns error', error);
        });
    };
    // ================================= SVG ==================================
    KdVisualizationExport.prototype._exportToSvg = function (_rawData, _options) {
        domtoimage.toSvg(_rawData, _options)
            .then(function (dataUrl) {
            // temp fix
            var xmlHTTP = new XMLHttpRequest();
            xmlHTTP.open('GET', dataUrl, true);
            // Must include this line - specifies the response type we want
            xmlHTTP.responseType = 'blob';
            xmlHTTP.onload = function (e) {
                saveAs(xmlHTTP.response, _options.fileName);
            };
            xmlHTTP.send();
            // fetch(dataUrl)
            // .then(res => res.blob())
            // .then(blob => saveAs(blob, _options.fileName));
        })
            .catch(function (error) {
            console.error('domtoimage returns error', error);
        });
    };
    // ================================= get ImageURL ==================================
    KdVisualizationExport.prototype._exportPdfOrPrint = function (_rawData, _format, _options) {
        var _this = this;
        this.getImageUrl(_rawData, _options).then(function (dataUrl) {
            if (_format === 'pdf')
                _this._exportToPdf(dataUrl, _options);
            if (_format === 'print')
                _this._print(dataUrl);
        });
    };
    KdVisualizationExport.prototype.getImageUrl = function (_rawData, _options) {
        return domtoimage.toPng(_rawData, _options)
            .then(function (dataUrl) {
            return dataUrl;
        })
            .catch(function (error) {
            console.error('domtoimage returns error', error);
        });
    };
    KdVisualizationExport.prototype.scaleImage = function (_base64Image, _scaleFactor) {
        if (_scaleFactor === void 0) { _scaleFactor = 1; }
        return new Observable(function (_observer) {
            if (_base64Image) {
                var img_1 = new Image();
                img_1.onload = function () {
                    var width = img_1.width * _scaleFactor, height = img_1.height * _scaleFactor, canvas = document.createElement('canvas'), ctx = canvas.getContext("2d");
                    canvas.width = width;
                    canvas.height = height;
                    ctx.drawImage(img_1, 0, 0, width, height);
                    _observer.next(canvas.toDataURL());
                    _observer.complete;
                };
                img_1.src = _base64Image;
            }
        });
    };
    // ================================= PRINT ==================================
    KdVisualizationExport.prototype._print = function (_dataUrl) {
        print({ type: 'image', printable: _dataUrl, documentTitle: '' });
    };
    // ================================= PDF ==================================
    KdVisualizationExport.prototype._exportToPdf = function (_dataUrl, _options) {
        var options = Object.assign({}, defaultPdfOptions, _options);
        var pdf = this._setPdf(options);
        this._addImageToPDF(pdf, _dataUrl, options);
        if (options.save) {
            pdf.save(_options.fileName);
        }
        else {
            pdf.output('dataurlnewwindow');
        }
    };
    KdVisualizationExport.prototype._setPdf = function (_options) {
        var format = _options.format;
        if (_options.unit === 'mm') {
            var mmWidth = _options.width * pxtoMM;
            var mmHeight = _options.height * pxtoMM;
            // jsPDF orientation 'l' means take larger value as width, whereas 'p' means take lower value as width
            _options.orientation = mmWidth > mmHeight ? 'l' : 'p';
            format = [mmWidth, mmHeight];
        }
        return new jsPDF(_options.orientation, _options.unit, format, _options.compressPdf);
    };
    KdVisualizationExport.prototype._addImageToPDF = function (_pdf, _src, _options) {
        if (!this._isExist(_pdf))
            _pdf = this._setPdf(_options);
        // note: width and height from _pdf have been converted to _options.pdf.unit
        // eg: _options.pdf.unit = 'mm' then this numbers are in mm
        var width = _pdf.internal.pageSize.getWidth();
        var height = _pdf.internal.pageSize.getHeight();
        if (_options.format === 'a4') {
            var converter = _options.unit === 'mm' ? pxtoMM : 1;
            var ratioDiffence = (width / converter) / _options.width;
            var newHeight = _options.height * ratioDiffence;
            if (newHeight < height) {
                _pdf.addImage(_src, 'PNG', 0, 0, (_options.width * ratioDiffence), newHeight, undefined, 'FAST');
                return;
            }
        }
        _pdf.addImage(_src, 'PNG', 0, 0, width, height, undefined, 'FAST');
    };
    // ================================= CHECK BROWSER COMPATIBLE ==================================
    KdVisualizationExport.prototype.isExportCompatible = function () {
        return this._isInternetExplorer() === false && this._isSafari() === false;
    };
    KdVisualizationExport.prototype.getErrorMessage = function (_format) {
        var error = '';
        switch (_format) {
            case 'print':
                error = 'printing' + this._incompatibleBrowserMsg;
                break;
            default:
                error = 'The generation of ' + _format + this._incompatibleBrowserMsg;
                break;
        }
        return error;
    };
    KdVisualizationExport.prototype._isExist = function (_val) {
        return (typeof _val !== 'undefined' && _val !== null && _val !== '');
    };
    KdVisualizationExport.prototype._isInternetExplorer = function () {
        if (navigator.appName === 'Microsoft Internet Explorer' ||
            !!(navigator.userAgent.match(/Trident/) ||
                navigator.userAgent.match(/rv 11/))) {
            return true;
        }
        return false;
    };
    KdVisualizationExport.prototype._isSafari = function () {
        var ua = navigator.userAgent.toLowerCase();
        if (ua.indexOf('safari') !== -1) {
            if (ua.indexOf('chrome') > -1) {
                return false;
            }
            else {
                return true;
            }
        }
        else {
            return false;
        }
    };
    KdVisualizationExport.ɵprov = i0.ɵɵdefineInjectable({ factory: function KdVisualizationExport_Factory() { return new KdVisualizationExport(); }, token: KdVisualizationExport, providedIn: "root" });
    KdVisualizationExport = __decorate([
        Injectable({
            providedIn: 'root'
        })
    ], KdVisualizationExport);
    return KdVisualizationExport;
}());
export { KdVisualizationExport };
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoia2QtYW5ndWxhci12aXN1YWxpemF0aW9uLWV4cG9ydC5qcyIsInNvdXJjZVJvb3QiOiJuZzovL29wZW5lbWlzLXN0eWxlZ3VpZGUtbGliLyIsInNvdXJjZXMiOlsia2QtY29tcG9uZW50cy9rZC1hbmd1bGFyLXZpc3VhbGl6YXRpb24va2QtYW5ndWxhci12aXN1YWxpemF0aW9uLWV4cG9ydC50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiO0FBQUEsT0FBTyxFQUFFLFVBQVUsRUFBRSxNQUFNLGVBQWUsQ0FBQztBQUMzQyxPQUFPLEtBQUssS0FBSyxNQUFNLE9BQU8sQ0FBQztBQUMvQixPQUFPLEtBQUssVUFBVSxNQUFNLGNBQWMsQ0FBQztBQUMzQyxPQUFPLEVBQUUsTUFBTSxFQUFFLE1BQU0sWUFBWSxDQUFDO0FBQ3BDLE9BQU8sS0FBSyxNQUFNLFVBQVUsQ0FBQztBQUM3QixPQUFPLEVBQUUsVUFBVSxFQUFZLE1BQU0sTUFBTSxDQUFDO0FBQzVDLE9BQU8sRUFDSCxNQUFNLEVBR04saUJBQWlCLEdBRXBCLE1BQU0sc0NBQXNDLENBQUM7O0FBSzlDO0lBQUE7UUFFWSxhQUFRLEdBQWEsRUFBRSxDQUFDO1FBQ3hCLG9CQUFlLEdBQWEsRUFBRSxRQUFRLEVBQUUsTUFBTSxFQUFFLENBQUM7UUFFakQsNEJBQXVCLEdBQVcsK0dBQStHLENBQUM7S0EyTjdKO0lBek5HOzs7OztPQUtHO0lBQ0ksNkNBQWEsR0FBcEIsVUFBcUIsUUFBaUIsRUFBRSxPQUFlLEVBQUUsUUFBaUI7UUFDdEUsSUFBSSxDQUFDLFFBQVEsR0FBRyxNQUFNLENBQUMsTUFBTSxDQUFDLEVBQUUsRUFBRSxJQUFJLENBQUMsZUFBZSxFQUFFLFFBQVEsQ0FBQyxDQUFDO1FBQ2xFLElBQUksQ0FBQyxRQUFRLENBQUMsUUFBUSxHQUFHLElBQUksQ0FBQyxRQUFRLENBQUMsUUFBUSxHQUFHLEdBQUcsR0FBRyxPQUFPLENBQUM7UUFFaEUsUUFBUSxPQUFPLEVBQUU7WUFDYixLQUFLLEtBQUssQ0FBQztZQUNYLEtBQUssS0FBSztnQkFDTixJQUFJLENBQUMsYUFBYSxDQUFDLFFBQVEsRUFBRSxJQUFJLENBQUMsUUFBUSxDQUFDLENBQUM7Z0JBQzVDLE1BQU07WUFDVixLQUFLLEtBQUssQ0FBQztZQUNYLEtBQUssT0FBTztnQkFDUixJQUFJLENBQUMsaUJBQWlCLENBQUMsUUFBUSxFQUFFLE9BQU8sRUFBRSxJQUFJLENBQUMsUUFBUSxDQUFDLENBQUM7Z0JBQ3pELE1BQU07WUFDVixLQUFLLEtBQUs7Z0JBQ04sSUFBSSxDQUFDLFlBQVksQ0FBQyxRQUFRLEVBQUUsSUFBSSxDQUFDLFFBQVEsQ0FBQyxDQUFDO2dCQUMzQyxNQUFNO1lBQ1YsS0FBSyxVQUFVO2dCQUNYLE9BQU8sSUFBSSxDQUFDLFdBQVcsQ0FBQyxRQUFRLEVBQUUsSUFBSSxDQUFDLFFBQVEsQ0FBQyxDQUFDLElBQUksQ0FBQyxVQUFBLFFBQVEsSUFBSSxPQUFBLFFBQVEsRUFBUixDQUFRLENBQUMsQ0FBQztZQUNoRjtnQkFDSSxPQUFPLENBQUMsS0FBSyxDQUFDLG1DQUFtQyxDQUFDLENBQUM7Z0JBQ25ELE1BQU07U0FDYjtJQUVMLENBQUM7SUFFRCxtRkFBbUY7SUFFM0UsNkNBQWEsR0FBckIsVUFBc0IsUUFBaUIsRUFBRSxRQUFrQjtRQUN2RCxVQUFVLENBQUMsTUFBTSxDQUFDLFFBQVEsRUFBRSxRQUFRLENBQUM7YUFDaEMsSUFBSSxDQUFDLFVBQUMsSUFBSTtZQUNQLE1BQU0sQ0FBQyxJQUFJLEVBQUUsUUFBUSxDQUFDLFFBQVEsQ0FBQyxDQUFDO1FBQ3BDLENBQUMsQ0FBQzthQUNELEtBQUssQ0FBQyxVQUFDLEtBQUs7WUFDVCxPQUFPLENBQUMsS0FBSyxDQUFDLDBCQUEwQixFQUFFLEtBQUssQ0FBQyxDQUFDO1FBQ3JELENBQUMsQ0FBQyxDQUFDO0lBQ1gsQ0FBQztJQUVELDJFQUEyRTtJQUVuRSw0Q0FBWSxHQUFwQixVQUFxQixRQUFpQixFQUFFLFFBQWtCO1FBQ3RELFVBQVUsQ0FBQyxLQUFLLENBQUMsUUFBUSxFQUFFLFFBQVEsQ0FBQzthQUMvQixJQUFJLENBQUMsVUFBQyxPQUFPO1lBQ1YsV0FBVztZQUNYLElBQUksT0FBTyxHQUFHLElBQUksY0FBYyxFQUFFLENBQUM7WUFDbkMsT0FBTyxDQUFDLElBQUksQ0FBQyxLQUFLLEVBQUUsT0FBTyxFQUFFLElBQUksQ0FBQyxDQUFDO1lBRW5DLCtEQUErRDtZQUMvRCxPQUFPLENBQUMsWUFBWSxHQUFHLE1BQU0sQ0FBQztZQUU5QixPQUFPLENBQUMsTUFBTSxHQUFHLFVBQVMsQ0FBQztnQkFDdkIsTUFBTSxDQUFDLE9BQU8sQ0FBQyxRQUFRLEVBQUUsUUFBUSxDQUFDLFFBQVEsQ0FBQyxDQUFDO1lBQ2hELENBQUMsQ0FBQztZQUVGLE9BQU8sQ0FBQyxJQUFJLEVBQUUsQ0FBQztZQUdmLGlCQUFpQjtZQUNqQiwyQkFBMkI7WUFDM0Isa0RBQWtEO1FBRXRELENBQUMsQ0FBQzthQUNELEtBQUssQ0FBQyxVQUFDLEtBQUs7WUFDVCxPQUFPLENBQUMsS0FBSyxDQUFDLDBCQUEwQixFQUFFLEtBQUssQ0FBQyxDQUFDO1FBQ3JELENBQUMsQ0FBQyxDQUFDO0lBQ1gsQ0FBQztJQUVELG9GQUFvRjtJQUU1RSxpREFBaUIsR0FBekIsVUFBMEIsUUFBaUIsRUFBRSxPQUFlLEVBQUUsUUFBa0I7UUFBaEYsaUJBS0M7UUFKRyxJQUFJLENBQUMsV0FBVyxDQUFDLFFBQVEsRUFBRSxRQUFRLENBQUMsQ0FBQyxJQUFJLENBQUMsVUFBQyxPQUFPO1lBQzlDLElBQUksT0FBTyxLQUFLLEtBQUs7Z0JBQUUsS0FBSSxDQUFDLFlBQVksQ0FBQyxPQUFPLEVBQUUsUUFBUSxDQUFDLENBQUM7WUFDNUQsSUFBSSxPQUFPLEtBQUssT0FBTztnQkFBRSxLQUFJLENBQUMsTUFBTSxDQUFDLE9BQU8sQ0FBQyxDQUFDO1FBQ2xELENBQUMsQ0FBQyxDQUFDO0lBQ1AsQ0FBQztJQUVNLDJDQUFXLEdBQWxCLFVBQW1CLFFBQWlCLEVBQUUsUUFBa0I7UUFDcEQsT0FBTyxVQUFVLENBQUMsS0FBSyxDQUFDLFFBQVEsRUFBRSxRQUFRLENBQUM7YUFDdEMsSUFBSSxDQUFDLFVBQUMsT0FBTztZQUNWLE9BQU8sT0FBTyxDQUFDO1FBQ25CLENBQUMsQ0FBQzthQUNELEtBQUssQ0FBQyxVQUFDLEtBQUs7WUFDVCxPQUFPLENBQUMsS0FBSyxDQUFDLDBCQUEwQixFQUFFLEtBQUssQ0FBQyxDQUFDO1FBQ3JELENBQUMsQ0FBQyxDQUFDO0lBQ1gsQ0FBQztJQUVNLDBDQUFVLEdBQWpCLFVBQWtCLFlBQW9CLEVBQUUsWUFBd0I7UUFBeEIsNkJBQUEsRUFBQSxnQkFBd0I7UUFDNUQsT0FBTyxJQUFJLFVBQVUsQ0FBUyxVQUFDLFNBQTJCO1lBQ3RELElBQUksWUFBWSxFQUFFO2dCQUNkLElBQUksS0FBRyxHQUFxQixJQUFJLEtBQUssRUFBRSxDQUFDO2dCQUV4QyxLQUFHLENBQUMsTUFBTSxHQUFHO29CQUNULElBQUksS0FBSyxHQUFXLEtBQUcsQ0FBQyxLQUFLLEdBQUcsWUFBWSxFQUN4QyxNQUFNLEdBQVcsS0FBRyxDQUFDLE1BQU0sR0FBRyxZQUFZLEVBQzFDLE1BQU0sR0FBc0IsUUFBUSxDQUFDLGFBQWEsQ0FBQyxRQUFRLENBQUMsRUFDNUQsR0FBRyxHQUFRLE1BQU0sQ0FBQyxVQUFVLENBQUMsSUFBSSxDQUFDLENBQUM7b0JBRXZDLE1BQU0sQ0FBQyxLQUFLLEdBQUcsS0FBSyxDQUFDO29CQUNyQixNQUFNLENBQUMsTUFBTSxHQUFHLE1BQU0sQ0FBQztvQkFFdkIsR0FBRyxDQUFDLFNBQVMsQ0FBQyxLQUFHLEVBQUUsQ0FBQyxFQUFFLENBQUMsRUFBRSxLQUFLLEVBQUUsTUFBTSxDQUFDLENBQUM7b0JBRXhDLFNBQVMsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLFNBQVMsRUFBRSxDQUFDLENBQUM7b0JBQ25DLFNBQVMsQ0FBQyxRQUFRLENBQUM7Z0JBQ3ZCLENBQUMsQ0FBQztnQkFFRixLQUFHLENBQUMsR0FBRyxHQUFHLFlBQVksQ0FBQzthQUMxQjtRQUNMLENBQUMsQ0FBQyxDQUFDO0lBQ1AsQ0FBQztJQUVELDZFQUE2RTtJQUVyRSxzQ0FBTSxHQUFkLFVBQWUsUUFBZ0I7UUFDM0IsS0FBSyxDQUFDLEVBQUUsSUFBSSxFQUFFLE9BQU8sRUFBRSxTQUFTLEVBQUUsUUFBUSxFQUFFLGFBQWEsRUFBRSxFQUFFLEVBQUUsQ0FBQyxDQUFDO0lBQ3JFLENBQUM7SUFFRCwyRUFBMkU7SUFFbkUsNENBQVksR0FBcEIsVUFBcUIsUUFBZ0IsRUFBRSxRQUFrQjtRQUNyRCxJQUFJLE9BQU8sR0FBYSxNQUFNLENBQUMsTUFBTSxDQUFDLEVBQUUsRUFBRSxpQkFBaUIsRUFBRSxRQUFRLENBQUMsQ0FBQztRQUN2RSxJQUFJLEdBQUcsR0FBRyxJQUFJLENBQUMsT0FBTyxDQUFDLE9BQU8sQ0FBQyxDQUFDO1FBRWhDLElBQUksQ0FBQyxjQUFjLENBQUMsR0FBRyxFQUFFLFFBQVEsRUFBRSxPQUFPLENBQUMsQ0FBQztRQUU1QyxJQUFJLE9BQU8sQ0FBQyxJQUFJLEVBQUU7WUFDZCxHQUFHLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxRQUFRLENBQUMsQ0FBQztTQUMvQjthQUFNO1lBQ0gsR0FBRyxDQUFDLE1BQU0sQ0FBQyxrQkFBa0IsQ0FBQyxDQUFDO1NBQ2xDO0lBQ0wsQ0FBQztJQUVPLHVDQUFPLEdBQWYsVUFBZ0IsUUFBa0I7UUFDOUIsSUFBSSxNQUFNLEdBQUcsUUFBUSxDQUFDLE1BQU0sQ0FBQztRQUU3QixJQUFJLFFBQVEsQ0FBQyxJQUFJLEtBQUssSUFBSSxFQUFFO1lBQ3hCLElBQUksT0FBTyxHQUFXLFFBQVEsQ0FBQyxLQUFLLEdBQUcsTUFBTSxDQUFDO1lBQzlDLElBQUksUUFBUSxHQUFXLFFBQVEsQ0FBQyxNQUFNLEdBQUcsTUFBTSxDQUFDO1lBQ2hELHNHQUFzRztZQUN0RyxRQUFRLENBQUMsV0FBVyxHQUFHLE9BQU8sR0FBRyxRQUFRLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDO1lBQ3RELE1BQU0sR0FBRyxDQUFDLE9BQU8sRUFBRSxRQUFRLENBQUMsQ0FBQztTQUNoQztRQUVELE9BQU8sSUFBSSxLQUFLLENBQUMsUUFBUSxDQUFDLFdBQVcsRUFBRSxRQUFRLENBQUMsSUFBSSxFQUFFLE1BQU0sRUFBRSxRQUFRLENBQUMsV0FBVyxDQUFDLENBQUM7SUFDeEYsQ0FBQztJQUVPLDhDQUFjLEdBQXRCLFVBQXVCLElBQVMsRUFBRSxJQUFZLEVBQUUsUUFBbUI7UUFDL0QsSUFBSSxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDO1lBQUUsSUFBSSxHQUFHLElBQUksQ0FBQyxPQUFPLENBQUMsUUFBUSxDQUFDLENBQUM7UUFFeEQsNEVBQTRFO1FBQzVFLDJEQUEyRDtRQUMzRCxJQUFJLEtBQUssR0FBVyxJQUFJLENBQUMsUUFBUSxDQUFDLFFBQVEsQ0FBQyxRQUFRLEVBQUUsQ0FBQztRQUN0RCxJQUFJLE1BQU0sR0FBVyxJQUFJLENBQUMsUUFBUSxDQUFDLFFBQVEsQ0FBQyxTQUFTLEVBQUUsQ0FBQztRQUV4RCxJQUFJLFFBQVEsQ0FBQyxNQUFNLEtBQUssSUFBSSxFQUFFO1lBQzFCLElBQUksU0FBUyxHQUFXLFFBQVEsQ0FBQyxJQUFJLEtBQUssSUFBSSxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztZQUM1RCxJQUFJLGFBQWEsR0FBVyxDQUFDLEtBQUssR0FBRyxTQUFTLENBQUMsR0FBRyxRQUFRLENBQUMsS0FBSyxDQUFDO1lBQ2pFLElBQUksU0FBUyxHQUFXLFFBQVEsQ0FBQyxNQUFNLEdBQUcsYUFBYSxDQUFDO1lBRXhELElBQUksU0FBUyxHQUFHLE1BQU0sRUFBRTtnQkFDcEIsSUFBSSxDQUFDLFFBQVEsQ0FBQyxJQUFJLEVBQUUsS0FBSyxFQUFFLENBQUMsRUFBRSxDQUFDLEVBQUUsQ0FBQyxRQUFRLENBQUMsS0FBSyxHQUFHLGFBQWEsQ0FBQyxFQUFFLFNBQVMsRUFBRSxTQUFTLEVBQUUsTUFBTSxDQUFDLENBQUM7Z0JBQ2pHLE9BQU87YUFDVjtTQUNKO1FBRUQsSUFBSSxDQUFDLFFBQVEsQ0FBQyxJQUFJLEVBQUUsS0FBSyxFQUFFLENBQUMsRUFBRSxDQUFDLEVBQUUsS0FBSyxFQUFFLE1BQU0sRUFBRSxTQUFTLEVBQUUsTUFBTSxDQUFDLENBQUM7SUFDdkUsQ0FBQztJQUVELGdHQUFnRztJQUV6RixrREFBa0IsR0FBekI7UUFDSSxPQUFPLElBQUksQ0FBQyxtQkFBbUIsRUFBRSxLQUFLLEtBQUssSUFBSSxJQUFJLENBQUMsU0FBUyxFQUFFLEtBQUssS0FBSyxDQUFDO0lBQzlFLENBQUM7SUFFTSwrQ0FBZSxHQUF0QixVQUF1QixPQUFlO1FBQ2xDLElBQUksS0FBSyxHQUFHLEVBQUUsQ0FBQztRQUNmLFFBQVEsT0FBTyxFQUFFO1lBQ2IsS0FBSyxPQUFPO2dCQUNSLEtBQUssR0FBRyxVQUFVLEdBQUcsSUFBSSxDQUFDLHVCQUF1QixDQUFDO2dCQUNsRCxNQUFNO1lBQ1Y7Z0JBQ0ksS0FBSyxHQUFHLG9CQUFvQixHQUFHLE9BQU8sR0FBRyxJQUFJLENBQUMsdUJBQXVCLENBQUM7Z0JBQ3RFLE1BQU07U0FDYjtRQUNELE9BQU8sS0FBSyxDQUFDO0lBQ2pCLENBQUM7SUFFTyx3Q0FBUSxHQUFoQixVQUFpQixJQUFTO1FBQ3RCLE9BQU8sQ0FBQyxPQUFPLElBQUksS0FBSyxXQUFXLElBQUksSUFBSSxLQUFLLElBQUksSUFBSSxJQUFJLEtBQUssRUFBRSxDQUFDLENBQUM7SUFDekUsQ0FBQztJQUVPLG1EQUFtQixHQUEzQjtRQUNJLElBQUksU0FBUyxDQUFDLE9BQU8sS0FBSyw2QkFBNkI7WUFDbkQsQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDLFNBQVMsQ0FBQyxLQUFLLENBQUMsU0FBUyxDQUFDO2dCQUNuQyxTQUFTLENBQUMsU0FBUyxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsQ0FBQyxFQUFFO1lBQ3pDLE9BQU8sSUFBSSxDQUFDO1NBQ2Y7UUFFRCxPQUFPLEtBQUssQ0FBQztJQUNqQixDQUFDO0lBQ08seUNBQVMsR0FBakI7UUFDSSxJQUFJLEVBQUUsR0FBRyxTQUFTLENBQUMsU0FBUyxDQUFDLFdBQVcsRUFBRSxDQUFDO1FBQzNDLElBQUksRUFBRSxDQUFDLE9BQU8sQ0FBQyxRQUFRLENBQUMsS0FBSyxDQUFDLENBQUMsRUFBRTtZQUM3QixJQUFJLEVBQUUsQ0FBQyxPQUFPLENBQUMsUUFBUSxDQUFDLEdBQUcsQ0FBQyxDQUFDLEVBQUU7Z0JBQzNCLE9BQU8sS0FBSyxDQUFDO2FBQ2hCO2lCQUFNO2dCQUNILE9BQU8sSUFBSSxDQUFDO2FBQ2Y7U0FDSjthQUFNO1lBQ0gsT0FBTyxLQUFLLENBQUM7U0FDaEI7SUFDTCxDQUFDOztJQS9OUSxxQkFBcUI7UUFIakMsVUFBVSxDQUFDO1lBQ1IsVUFBVSxFQUFFLE1BQU07U0FDckIsQ0FBQztPQUNXLHFCQUFxQixDQWdPakM7Z0NBalBEO0NBaVBDLEFBaE9ELElBZ09DO1NBaE9ZLHFCQUFxQiIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IEluamVjdGFibGUgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcclxuaW1wb3J0ICogYXMganNQREYgZnJvbSAnanNwZGYnO1xyXG5pbXBvcnQgKiBhcyBkb210b2ltYWdlIGZyb20gJ2RvbS10by1pbWFnZSc7XHJcbmltcG9ydCB7IHNhdmVBcyB9IGZyb20gJ2ZpbGUtc2F2ZXInO1xyXG5pbXBvcnQgcHJpbnQgZnJvbSAncHJpbnQtanMnO1xyXG5pbXBvcnQgeyBPYnNlcnZhYmxlLCBPYnNlcnZlciB9IGZyb20gJ3J4anMnO1xyXG5pbXBvcnQge1xyXG4gICAgcHh0b01NLFxyXG4gICAgSU9wdGlvbnMsXHJcbiAgICBJVGFibGVEYXRhLFxyXG4gICAgZGVmYXVsdFBkZk9wdGlvbnMsXHJcbiAgICBJRG9tVG9JbWFnZU9wdGlvbnMsXHJcbn0gZnJvbSAnLi9rZC1hbmd1bGFyLXZpc3VhbGl6YXRpb24taW50ZXJmYWNlJztcclxuXHJcbkBJbmplY3RhYmxlKHtcclxuICAgIHByb3ZpZGVkSW46ICdyb290J1xyXG59KVxyXG5leHBvcnQgY2xhc3MgS2RWaXN1YWxpemF0aW9uRXhwb3J0IHtcclxuXHJcbiAgICBwcml2YXRlIF9vcHRpb25zOiBJT3B0aW9ucyA9IHt9O1xyXG4gICAgcHJpdmF0ZSBfZGVmYXVsdE9wdGlvbnM6IElPcHRpb25zID0geyBmaWxlTmFtZTogJ2ZpbGUnIH07XHJcblxyXG4gICAgcHJpdmF0ZSBfaW5jb21wYXRpYmxlQnJvd3Nlck1zZzogc3RyaW5nID0gJyBpcyBub3Qgc3VwcG9ydGVkIGluIHRoaXMgYnJvd3Nlci4gRm9yIHRoZSBiZXN0IGV4cGVyaWVuY2UsIHBsZWFzZSB1c2Ugb3RoZXIgYnJvd3NlcnMgbGlrZSBGaXJlZm94IG9yIENocm9tZS4nO1xyXG5cclxuICAgIC8qKlxyXG4gICAgICogbWFpbiBlbnRyeSB0byBleHBvcnQgY2xhc3NcclxuICAgICAqIHBhcmFtIHtFbGVtZW50fSBfcmF3RGF0YSBFbGVtZW50IHRvIGV4cG9ydFxyXG4gICAgICogcGFyYW0ge3N0cmluZ30gX2Zvcm1hdCAgY2FuIGJlICdwcmludCcsICdwbmcnLCAnanBnJywgJ3BkZicsICdzdmcnLCAnaW1hZ2VVcmwnXHJcbiAgICAgKiBwYXJhbSB7b2JqZWN0fSBfb3B0aW9ucyBjb250YWlucyBmaWxlTmFtZSwgc2l6ZSwgcGRmIG9wdGlvbnMgZXRjXHJcbiAgICAgKi9cclxuICAgIHB1YmxpYyBleHBvcnRFbGVtZW50KF9yYXdEYXRhOiBFbGVtZW50LCBfZm9ybWF0OiBzdHJpbmcsIF9vcHRpb25zPzogb2JqZWN0KTogYW55IHtcclxuICAgICAgICB0aGlzLl9vcHRpb25zID0gT2JqZWN0LmFzc2lnbih7fSwgdGhpcy5fZGVmYXVsdE9wdGlvbnMsIF9vcHRpb25zKTtcclxuICAgICAgICB0aGlzLl9vcHRpb25zLmZpbGVOYW1lID0gdGhpcy5fb3B0aW9ucy5maWxlTmFtZSArICcuJyArIF9mb3JtYXQ7XHJcblxyXG4gICAgICAgIHN3aXRjaCAoX2Zvcm1hdCkge1xyXG4gICAgICAgICAgICBjYXNlICdwbmcnOlxyXG4gICAgICAgICAgICBjYXNlICdqcGcnOlxyXG4gICAgICAgICAgICAgICAgdGhpcy5fZXhwb3J0VG9CbG9iKF9yYXdEYXRhLCB0aGlzLl9vcHRpb25zKTtcclxuICAgICAgICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgICAgICBjYXNlICdwZGYnOlxyXG4gICAgICAgICAgICBjYXNlICdwcmludCc6XHJcbiAgICAgICAgICAgICAgICB0aGlzLl9leHBvcnRQZGZPclByaW50KF9yYXdEYXRhLCBfZm9ybWF0LCB0aGlzLl9vcHRpb25zKTtcclxuICAgICAgICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgICAgICBjYXNlICdzdmcnOlxyXG4gICAgICAgICAgICAgICAgdGhpcy5fZXhwb3J0VG9TdmcoX3Jhd0RhdGEsIHRoaXMuX29wdGlvbnMpO1xyXG4gICAgICAgICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgICAgIGNhc2UgJ2ltYWdlVXJsJzpcclxuICAgICAgICAgICAgICAgIHJldHVybiB0aGlzLmdldEltYWdlVXJsKF9yYXdEYXRhLCB0aGlzLl9vcHRpb25zKS50aGVuKGltYWdlVXJsID0+IGltYWdlVXJsKTtcclxuICAgICAgICAgICAgZGVmYXVsdDpcclxuICAgICAgICAgICAgICAgIGNvbnNvbGUuZXJyb3IoJ3BsZWFzZSBwcm92aWRlIGEgZm9ybWF0IHRvIGV4cG9ydCcpO1xyXG4gICAgICAgICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgfVxyXG5cclxuICAgIH1cclxuXHJcbiAgICAvLyA9PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT0gUE5HIGFuZCBKUEcgPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PVxyXG5cclxuICAgIHByaXZhdGUgX2V4cG9ydFRvQmxvYihfcmF3RGF0YTogRWxlbWVudCwgX29wdGlvbnM6IElPcHRpb25zKTogdm9pZCB7XHJcbiAgICAgICAgZG9tdG9pbWFnZS50b0Jsb2IoX3Jhd0RhdGEsIF9vcHRpb25zKVxyXG4gICAgICAgICAgICAudGhlbigoYmxvYikgPT4ge1xyXG4gICAgICAgICAgICAgICAgc2F2ZUFzKGJsb2IsIF9vcHRpb25zLmZpbGVOYW1lKTtcclxuICAgICAgICAgICAgfSlcclxuICAgICAgICAgICAgLmNhdGNoKChlcnJvcikgPT4ge1xyXG4gICAgICAgICAgICAgICAgY29uc29sZS5lcnJvcignZG9tdG9pbWFnZSByZXR1cm5zIGVycm9yJywgZXJyb3IpO1xyXG4gICAgICAgICAgICB9KTtcclxuICAgIH1cclxuXHJcbiAgICAvLyA9PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT0gU1ZHID09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT1cclxuXHJcbiAgICBwcml2YXRlIF9leHBvcnRUb1N2ZyhfcmF3RGF0YTogRWxlbWVudCwgX29wdGlvbnM6IElPcHRpb25zKTogdm9pZCB7XHJcbiAgICAgICAgZG9tdG9pbWFnZS50b1N2ZyhfcmF3RGF0YSwgX29wdGlvbnMpXHJcbiAgICAgICAgICAgIC50aGVuKChkYXRhVXJsKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAvLyB0ZW1wIGZpeFxyXG4gICAgICAgICAgICAgICAgdmFyIHhtbEhUVFAgPSBuZXcgWE1MSHR0cFJlcXVlc3QoKTtcclxuICAgICAgICAgICAgICAgIHhtbEhUVFAub3BlbignR0VUJywgZGF0YVVybCwgdHJ1ZSk7XHJcblxyXG4gICAgICAgICAgICAgICAgLy8gTXVzdCBpbmNsdWRlIHRoaXMgbGluZSAtIHNwZWNpZmllcyB0aGUgcmVzcG9uc2UgdHlwZSB3ZSB3YW50XHJcbiAgICAgICAgICAgICAgICB4bWxIVFRQLnJlc3BvbnNlVHlwZSA9ICdibG9iJztcclxuXHJcbiAgICAgICAgICAgICAgICB4bWxIVFRQLm9ubG9hZCA9IGZ1bmN0aW9uKGUpIHtcclxuICAgICAgICAgICAgICAgICAgICBzYXZlQXMoeG1sSFRUUC5yZXNwb25zZSwgX29wdGlvbnMuZmlsZU5hbWUpO1xyXG4gICAgICAgICAgICAgICAgfTtcclxuXHJcbiAgICAgICAgICAgICAgICB4bWxIVFRQLnNlbmQoKTtcclxuXHJcblxyXG4gICAgICAgICAgICAgICAgLy8gZmV0Y2goZGF0YVVybClcclxuICAgICAgICAgICAgICAgIC8vIC50aGVuKHJlcyA9PiByZXMuYmxvYigpKVxyXG4gICAgICAgICAgICAgICAgLy8gLnRoZW4oYmxvYiA9PiBzYXZlQXMoYmxvYiwgX29wdGlvbnMuZmlsZU5hbWUpKTtcclxuXHJcbiAgICAgICAgICAgIH0pXHJcbiAgICAgICAgICAgIC5jYXRjaCgoZXJyb3IpID0+IHtcclxuICAgICAgICAgICAgICAgIGNvbnNvbGUuZXJyb3IoJ2RvbXRvaW1hZ2UgcmV0dXJucyBlcnJvcicsIGVycm9yKTtcclxuICAgICAgICAgICAgfSk7XHJcbiAgICB9XHJcblxyXG4gICAgLy8gPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09IGdldCBJbWFnZVVSTCA9PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09XHJcblxyXG4gICAgcHJpdmF0ZSBfZXhwb3J0UGRmT3JQcmludChfcmF3RGF0YTogRWxlbWVudCwgX2Zvcm1hdDogc3RyaW5nLCBfb3B0aW9uczogSU9wdGlvbnMpOiB2b2lkIHtcclxuICAgICAgICB0aGlzLmdldEltYWdlVXJsKF9yYXdEYXRhLCBfb3B0aW9ucykudGhlbigoZGF0YVVybCkgPT4ge1xyXG4gICAgICAgICAgICBpZiAoX2Zvcm1hdCA9PT0gJ3BkZicpIHRoaXMuX2V4cG9ydFRvUGRmKGRhdGFVcmwsIF9vcHRpb25zKTtcclxuICAgICAgICAgICAgaWYgKF9mb3JtYXQgPT09ICdwcmludCcpIHRoaXMuX3ByaW50KGRhdGFVcmwpO1xyXG4gICAgICAgIH0pO1xyXG4gICAgfVxyXG5cclxuICAgIHB1YmxpYyBnZXRJbWFnZVVybChfcmF3RGF0YTogRWxlbWVudCwgX29wdGlvbnM6IElPcHRpb25zKTogUHJvbWlzZTxzdHJpbmc+IHtcclxuICAgICAgICByZXR1cm4gZG9tdG9pbWFnZS50b1BuZyhfcmF3RGF0YSwgX29wdGlvbnMpXHJcbiAgICAgICAgICAgIC50aGVuKChkYXRhVXJsKSA9PiB7XHJcbiAgICAgICAgICAgICAgICByZXR1cm4gZGF0YVVybDtcclxuICAgICAgICAgICAgfSlcclxuICAgICAgICAgICAgLmNhdGNoKChlcnJvcikgPT4ge1xyXG4gICAgICAgICAgICAgICAgY29uc29sZS5lcnJvcignZG9tdG9pbWFnZSByZXR1cm5zIGVycm9yJywgZXJyb3IpO1xyXG4gICAgICAgICAgICB9KTtcclxuICAgIH1cclxuXHJcbiAgICBwdWJsaWMgc2NhbGVJbWFnZShfYmFzZTY0SW1hZ2U6IHN0cmluZywgX3NjYWxlRmFjdG9yOiBudW1iZXIgPSAxKTogT2JzZXJ2YWJsZTxzdHJpbmc+IHtcclxuICAgICAgICByZXR1cm4gbmV3IE9ic2VydmFibGU8c3RyaW5nPigoX29ic2VydmVyOiBPYnNlcnZlcjxzdHJpbmc+KSA9PiB7XHJcbiAgICAgICAgICAgIGlmIChfYmFzZTY0SW1hZ2UpIHtcclxuICAgICAgICAgICAgICAgIGxldCBpbWc6IEhUTUxJbWFnZUVsZW1lbnQgPSBuZXcgSW1hZ2UoKTtcclxuXHJcbiAgICAgICAgICAgICAgICBpbWcub25sb2FkID0gZnVuY3Rpb24oKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgbGV0IHdpZHRoOiBudW1iZXIgPSBpbWcud2lkdGggKiBfc2NhbGVGYWN0b3IsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGhlaWdodDogbnVtYmVyID0gaW1nLmhlaWdodCAqIF9zY2FsZUZhY3RvcixcclxuICAgICAgICAgICAgICAgICAgICAgICAgY2FudmFzOiBIVE1MQ2FudmFzRWxlbWVudCA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2NhbnZhcycpLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBjdHg6IGFueSA9IGNhbnZhcy5nZXRDb250ZXh0KFwiMmRcIik7XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIGNhbnZhcy53aWR0aCA9IHdpZHRoO1xyXG4gICAgICAgICAgICAgICAgICAgIGNhbnZhcy5oZWlnaHQgPSBoZWlnaHQ7XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIGN0eC5kcmF3SW1hZ2UoaW1nLCAwLCAwLCB3aWR0aCwgaGVpZ2h0KTtcclxuXHJcbiAgICAgICAgICAgICAgICAgICAgX29ic2VydmVyLm5leHQoY2FudmFzLnRvRGF0YVVSTCgpKTtcclxuICAgICAgICAgICAgICAgICAgICBfb2JzZXJ2ZXIuY29tcGxldGU7XHJcbiAgICAgICAgICAgICAgICB9O1xyXG5cclxuICAgICAgICAgICAgICAgIGltZy5zcmMgPSBfYmFzZTY0SW1hZ2U7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9KTtcclxuICAgIH1cclxuXHJcbiAgICAvLyA9PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT0gUFJJTlQgPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PVxyXG5cclxuICAgIHByaXZhdGUgX3ByaW50KF9kYXRhVXJsOiBzdHJpbmcpOiB2b2lkIHtcclxuICAgICAgICBwcmludCh7IHR5cGU6ICdpbWFnZScsIHByaW50YWJsZTogX2RhdGFVcmwsIGRvY3VtZW50VGl0bGU6ICcnIH0pO1xyXG4gICAgfVxyXG5cclxuICAgIC8vID09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PSBQREYgPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PVxyXG5cclxuICAgIHByaXZhdGUgX2V4cG9ydFRvUGRmKF9kYXRhVXJsOiBzdHJpbmcsIF9vcHRpb25zOiBJT3B0aW9ucyk6IHZvaWQge1xyXG4gICAgICAgIGxldCBvcHRpb25zOiBJT3B0aW9ucyA9IE9iamVjdC5hc3NpZ24oe30sIGRlZmF1bHRQZGZPcHRpb25zLCBfb3B0aW9ucyk7XHJcbiAgICAgICAgbGV0IHBkZiA9IHRoaXMuX3NldFBkZihvcHRpb25zKTtcclxuXHJcbiAgICAgICAgdGhpcy5fYWRkSW1hZ2VUb1BERihwZGYsIF9kYXRhVXJsLCBvcHRpb25zKTtcclxuXHJcbiAgICAgICAgaWYgKG9wdGlvbnMuc2F2ZSkge1xyXG4gICAgICAgICAgICBwZGYuc2F2ZShfb3B0aW9ucy5maWxlTmFtZSk7XHJcbiAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgcGRmLm91dHB1dCgnZGF0YXVybG5ld3dpbmRvdycpO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF9zZXRQZGYoX29wdGlvbnM6IElPcHRpb25zKTogYW55IHtcclxuICAgICAgICBsZXQgZm9ybWF0ID0gX29wdGlvbnMuZm9ybWF0O1xyXG5cclxuICAgICAgICBpZiAoX29wdGlvbnMudW5pdCA9PT0gJ21tJykge1xyXG4gICAgICAgICAgICBsZXQgbW1XaWR0aDogbnVtYmVyID0gX29wdGlvbnMud2lkdGggKiBweHRvTU07XHJcbiAgICAgICAgICAgIGxldCBtbUhlaWdodDogbnVtYmVyID0gX29wdGlvbnMuaGVpZ2h0ICogcHh0b01NO1xyXG4gICAgICAgICAgICAvLyBqc1BERiBvcmllbnRhdGlvbiAnbCcgbWVhbnMgdGFrZSBsYXJnZXIgdmFsdWUgYXMgd2lkdGgsIHdoZXJlYXMgJ3AnIG1lYW5zIHRha2UgbG93ZXIgdmFsdWUgYXMgd2lkdGhcclxuICAgICAgICAgICAgX29wdGlvbnMub3JpZW50YXRpb24gPSBtbVdpZHRoID4gbW1IZWlnaHQgPyAnbCcgOiAncCc7XHJcbiAgICAgICAgICAgIGZvcm1hdCA9IFttbVdpZHRoLCBtbUhlaWdodF07XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICByZXR1cm4gbmV3IGpzUERGKF9vcHRpb25zLm9yaWVudGF0aW9uLCBfb3B0aW9ucy51bml0LCBmb3JtYXQsIF9vcHRpb25zLmNvbXByZXNzUGRmKTtcclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF9hZGRJbWFnZVRvUERGKF9wZGY6IGFueSwgX3NyYzogc3RyaW5nLCBfb3B0aW9ucz86IElPcHRpb25zKTogdm9pZCB7XHJcbiAgICAgICAgaWYgKCF0aGlzLl9pc0V4aXN0KF9wZGYpKSBfcGRmID0gdGhpcy5fc2V0UGRmKF9vcHRpb25zKTtcclxuXHJcbiAgICAgICAgLy8gbm90ZTogd2lkdGggYW5kIGhlaWdodCBmcm9tIF9wZGYgaGF2ZSBiZWVuIGNvbnZlcnRlZCB0byBfb3B0aW9ucy5wZGYudW5pdFxyXG4gICAgICAgIC8vIGVnOiBfb3B0aW9ucy5wZGYudW5pdCA9ICdtbScgdGhlbiB0aGlzIG51bWJlcnMgYXJlIGluIG1tXHJcbiAgICAgICAgbGV0IHdpZHRoOiBudW1iZXIgPSBfcGRmLmludGVybmFsLnBhZ2VTaXplLmdldFdpZHRoKCk7XHJcbiAgICAgICAgbGV0IGhlaWdodDogbnVtYmVyID0gX3BkZi5pbnRlcm5hbC5wYWdlU2l6ZS5nZXRIZWlnaHQoKTtcclxuXHJcbiAgICAgICAgaWYgKF9vcHRpb25zLmZvcm1hdCA9PT0gJ2E0Jykge1xyXG4gICAgICAgICAgICBsZXQgY29udmVydGVyOiBudW1iZXIgPSBfb3B0aW9ucy51bml0ID09PSAnbW0nID8gcHh0b01NIDogMTtcclxuICAgICAgICAgICAgbGV0IHJhdGlvRGlmZmVuY2U6IG51bWJlciA9ICh3aWR0aCAvIGNvbnZlcnRlcikgLyBfb3B0aW9ucy53aWR0aDtcclxuICAgICAgICAgICAgbGV0IG5ld0hlaWdodDogbnVtYmVyID0gX29wdGlvbnMuaGVpZ2h0ICogcmF0aW9EaWZmZW5jZTtcclxuXHJcbiAgICAgICAgICAgIGlmIChuZXdIZWlnaHQgPCBoZWlnaHQpIHtcclxuICAgICAgICAgICAgICAgIF9wZGYuYWRkSW1hZ2UoX3NyYywgJ1BORycsIDAsIDAsIChfb3B0aW9ucy53aWR0aCAqIHJhdGlvRGlmZmVuY2UpLCBuZXdIZWlnaHQsIHVuZGVmaW5lZCwgJ0ZBU1QnKTtcclxuICAgICAgICAgICAgICAgIHJldHVybjtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgX3BkZi5hZGRJbWFnZShfc3JjLCAnUE5HJywgMCwgMCwgd2lkdGgsIGhlaWdodCwgdW5kZWZpbmVkLCAnRkFTVCcpO1xyXG4gICAgfVxyXG5cclxuICAgIC8vID09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PSBDSEVDSyBCUk9XU0VSIENPTVBBVElCTEUgPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PVxyXG5cclxuICAgIHB1YmxpYyBpc0V4cG9ydENvbXBhdGlibGUoKTogYm9vbGVhbiB7XHJcbiAgICAgICAgcmV0dXJuIHRoaXMuX2lzSW50ZXJuZXRFeHBsb3JlcigpID09PSBmYWxzZSAmJiB0aGlzLl9pc1NhZmFyaSgpID09PSBmYWxzZTtcclxuICAgIH1cclxuXHJcbiAgICBwdWJsaWMgZ2V0RXJyb3JNZXNzYWdlKF9mb3JtYXQ6IHN0cmluZyk6IHN0cmluZyB7XHJcbiAgICAgICAgbGV0IGVycm9yID0gJyc7XHJcbiAgICAgICAgc3dpdGNoIChfZm9ybWF0KSB7XHJcbiAgICAgICAgICAgIGNhc2UgJ3ByaW50JzpcclxuICAgICAgICAgICAgICAgIGVycm9yID0gJ3ByaW50aW5nJyArIHRoaXMuX2luY29tcGF0aWJsZUJyb3dzZXJNc2c7XHJcbiAgICAgICAgICAgICAgICBicmVhaztcclxuICAgICAgICAgICAgZGVmYXVsdDpcclxuICAgICAgICAgICAgICAgIGVycm9yID0gJ1RoZSBnZW5lcmF0aW9uIG9mICcgKyBfZm9ybWF0ICsgdGhpcy5faW5jb21wYXRpYmxlQnJvd3Nlck1zZztcclxuICAgICAgICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgIH1cclxuICAgICAgICByZXR1cm4gZXJyb3I7XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfaXNFeGlzdChfdmFsOiBhbnkpOiBib29sZWFuIHtcclxuICAgICAgICByZXR1cm4gKHR5cGVvZiBfdmFsICE9PSAndW5kZWZpbmVkJyAmJiBfdmFsICE9PSBudWxsICYmIF92YWwgIT09ICcnKTtcclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF9pc0ludGVybmV0RXhwbG9yZXIoKTogYm9vbGVhbiB7XHJcbiAgICAgICAgaWYgKG5hdmlnYXRvci5hcHBOYW1lID09PSAnTWljcm9zb2Z0IEludGVybmV0IEV4cGxvcmVyJyB8fFxyXG4gICAgICAgICAgICAhIShuYXZpZ2F0b3IudXNlckFnZW50Lm1hdGNoKC9UcmlkZW50LykgfHxcclxuICAgICAgICAgICAgICAgIG5hdmlnYXRvci51c2VyQWdlbnQubWF0Y2goL3J2IDExLykpKSB7XHJcbiAgICAgICAgICAgIHJldHVybiB0cnVlO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgcmV0dXJuIGZhbHNlO1xyXG4gICAgfVxyXG4gICAgcHJpdmF0ZSBfaXNTYWZhcmkoKTogYm9vbGVhbiB7XHJcbiAgICAgICAgbGV0IHVhID0gbmF2aWdhdG9yLnVzZXJBZ2VudC50b0xvd2VyQ2FzZSgpO1xyXG4gICAgICAgIGlmICh1YS5pbmRleE9mKCdzYWZhcmknKSAhPT0gLTEpIHtcclxuICAgICAgICAgICAgaWYgKHVhLmluZGV4T2YoJ2Nocm9tZScpID4gLTEpIHtcclxuICAgICAgICAgICAgICAgIHJldHVybiBmYWxzZTtcclxuICAgICAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgICAgIHJldHVybiB0cnVlO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgcmV0dXJuIGZhbHNlO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxufVxyXG4iXX0=