import { __decorate, __metadata } from "tslib";
import { Injectable } from '@angular/core';
import { KdDomElemSvc } from '../kd-common/index';
var KdVisualizationSvc = /** @class */ (function () {
    function KdVisualizationSvc(_domElemSvc) {
        this._domElemSvc = _domElemSvc;
    }
    Object.defineProperty(KdVisualizationSvc.prototype, "visualizationElem", {
        set: function (_element) { this._visualizationElem = _element; },
        enumerable: true,
        configurable: true
    });
    // table within chart does not allow image or input type columns
    KdVisualizationSvc.prototype.filterColumns = function (_colDefArr) {
        // kd-table config is defined in the following way (9 May 2018)
        // text: does not require the key 'type'
        // input or image: puts type === image || input
        return _colDefArr.filter(function (column) { return !column.type; }).map(function (column) { return Object.assign({}, column); });
    };
    KdVisualizationSvc.prototype.getImmutableMenuArr = function (_defaultMenuArr) {
        var _this = this;
        return _defaultMenuArr.map(function (item) {
            if (item.expanded)
                _this.getImmutableMenuArr(item.expanded);
            return Object.assign({}, item);
        });
    };
    KdVisualizationSvc.prototype.setMenuItemVisibility = function (_type, _string, _isHide, _menuArr) {
        for (var i = 0; i < _menuArr.length; ++i) {
            if (_menuArr[i][_type] === _string) {
                _menuArr[i].hidden = _isHide;
                if (_type === 'id')
                    break;
            }
            else if (_menuArr[i].hasOwnProperty('expanded')) {
                this.setMenuItemVisibility(_type, _string, _isHide, _menuArr[i].expanded);
            }
        }
    };
    KdVisualizationSvc.prototype.setMenuTranslation = function (_menuArr, _translationCallback) {
        if (!_menuArr && !_translationCallback)
            return;
        var menuArr = [];
        for (var i = 0; i < _menuArr.length; ++i) {
            var item = Object.assign({}, _menuArr[i]);
            if (item.hasOwnProperty('text') && typeof item.text === 'string') {
                item.text = _translationCallback(item.text) || item.text;
            }
            if (item.hasOwnProperty('expanded'))
                item.expanded = this.setMenuTranslation(item.expanded, _translationCallback);
            menuArr.push(item);
        }
        return menuArr;
    };
    KdVisualizationSvc.prototype.getBtnAlignment = function (_btnConfig) {
        return (_btnConfig || 'bottom-left').split('-').map(function (el) { return 'kdx-visualization-' + el; }).join(' ');
    };
    // ================================= Export ==================================
    /**
     * before exporting, the html need to be changed
     * 1) remove all dummy labels
     * 2) remove class name '.legend-scroll' in order to display all legend
     *  _parentElem [description]
     */
    // public prepareHTML(_parentElem: HTMLElement): void {
    //     this._removeDummy(_parentElem);
    //     this._removeLegendScroll(_parentElem);
    //     _parentElem.style.height = 'auto';
    // }
    KdVisualizationSvc.prototype.removeDummy = function (_parentElem) {
        var dummyElementArr = _parentElem.querySelectorAll('.kdx-charts-dummy');
        for (var i = 0; i < dummyElementArr.length; ++i) {
            dummyElementArr[i].remove();
        }
    };
    KdVisualizationSvc.prototype.removeLegendScroll = function (_parentElem) {
        var legendElem = _parentElem.querySelector('.kdx-legend.legend-scroll');
        this._domElemSvc.removeClass(legendElem, 'legend-scroll');
    };
    // ================================= Table ==================================
    KdVisualizationSvc.prototype.processViewTable = function (_tableConfig) {
        // when ag-grid is in small screen, render all rows and there will be no inner-scroll
        // this logic is for mobile device, because when using mobile device, a large table should be fully displayed to prevent scrolling confusion (swiping page up might end up scrolling the table)
        // hence we will set parent's height to be 100% of content
        if (this._domElemSvc.isMobile()) {
            // when change to table, store parent's height for chart
            this._parentHeight = window.getComputedStyle(this._visualizationElem.parentNode).height;
            // if mobile, set parent height to 100% so that bottom content will be pushed down
            this.setParentHeight('table');
        }
        // temp fix. table does not follow parent height
        this._setTableHeight(_tableConfig, this._visualizationElem);
    };
    KdVisualizationSvc.prototype.setParentHeight = function (_type) {
        if (!this._domElemSvc.isMobile())
            return;
        switch (_type) {
            case 'chart':
                // when change to chart, use back the stored parent's height
                // note: chart requires parent to provide a definite height value (cannot use 100% of children)
                this._visualizationElem.parentNode.style.height = this._parentHeight;
                break;
            case 'table':
            default:
                this._visualizationElem.parentNode.style.height = '100%';
                break;
        }
    };
    KdVisualizationSvc.prototype._setTableHeight = function (_tableConfig, _element) {
        _tableConfig['gridHeight'] = _element.getBoundingClientRect().height;
    };
    KdVisualizationSvc.ctorParameters = function () { return [
        { type: KdDomElemSvc }
    ]; };
    KdVisualizationSvc = __decorate([
        Injectable(),
        __metadata("design:paramtypes", [KdDomElemSvc])
    ], KdVisualizationSvc);
    return KdVisualizationSvc;
}());
export { KdVisualizationSvc };
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoia2QtYW5ndWxhci12aXN1YWxpemF0aW9uLXN2Yy5qcyIsInNvdXJjZVJvb3QiOiJuZzovL29wZW5lbWlzLXN0eWxlZ3VpZGUtbGliLyIsInNvdXJjZXMiOlsia2QtY29tcG9uZW50cy9rZC1hbmd1bGFyLXZpc3VhbGl6YXRpb24va2QtYW5ndWxhci12aXN1YWxpemF0aW9uLXN2Yy50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiO0FBQUEsT0FBTyxFQUFFLFVBQVUsRUFBRSxNQUFNLGVBQWUsQ0FBQztBQUUzQyxPQUFPLEVBQUUsWUFBWSxFQUFFLE1BQU0sb0JBQW9CLENBQUM7QUFJbEQ7SUFRSSw0QkFBb0IsV0FBeUI7UUFBekIsZ0JBQVcsR0FBWCxXQUFXLENBQWM7SUFBSSxDQUFDO0lBRmxELHNCQUFJLGlEQUFpQjthQUFyQixVQUFzQixRQUFRLElBQUksSUFBSSxDQUFDLGtCQUFrQixHQUFHLFFBQVEsQ0FBQyxDQUFDLENBQUM7OztPQUFBO0lBSXZFLGdFQUFnRTtJQUN6RCwwQ0FBYSxHQUFwQixVQUFxQixVQUEwQjtRQUMzQywrREFBK0Q7UUFDL0Qsd0NBQXdDO1FBQ3hDLCtDQUErQztRQUMvQyxPQUFPLFVBQVUsQ0FBQyxNQUFNLENBQUMsVUFBQSxNQUFNLElBQUksT0FBQSxDQUFDLE1BQU0sQ0FBQyxJQUFJLEVBQVosQ0FBWSxDQUFDLENBQUMsR0FBRyxDQUFDLFVBQUEsTUFBTSxJQUFJLE9BQUEsTUFBTSxDQUFDLE1BQU0sQ0FBQyxFQUFFLEVBQUUsTUFBTSxDQUFDLEVBQXpCLENBQXlCLENBQUMsQ0FBQztJQUM5RixDQUFDO0lBRU0sZ0RBQW1CLEdBQTFCLFVBQTJCLGVBQWU7UUFBMUMsaUJBS0M7UUFKRyxPQUFPLGVBQWUsQ0FBQyxHQUFHLENBQUMsVUFBQSxJQUFJO1lBQzNCLElBQUksSUFBSSxDQUFDLFFBQVE7Z0JBQUUsS0FBSSxDQUFDLG1CQUFtQixDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsQ0FBQztZQUMzRCxPQUFPLE1BQU0sQ0FBQyxNQUFNLENBQUMsRUFBRSxFQUFFLElBQUksQ0FBQyxDQUFDO1FBQ25DLENBQUMsQ0FBQyxDQUFDO0lBQ1AsQ0FBQztJQUVNLGtEQUFxQixHQUE1QixVQUE2QixLQUFzQixFQUFFLE9BQWUsRUFBRSxPQUFnQixFQUFFLFFBQXFCO1FBQ3pHLEtBQUssSUFBSSxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsR0FBRyxRQUFRLENBQUMsTUFBTSxFQUFFLEVBQUUsQ0FBQyxFQUFFO1lBQ3RDLElBQUksUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxLQUFLLE9BQU8sRUFBRTtnQkFDaEMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sR0FBRyxPQUFPLENBQUM7Z0JBQzdCLElBQUksS0FBSyxLQUFLLElBQUk7b0JBQUUsTUFBTTthQUM3QjtpQkFBTSxJQUFJLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxjQUFjLENBQUMsVUFBVSxDQUFDLEVBQUU7Z0JBQy9DLElBQUksQ0FBQyxxQkFBcUIsQ0FBQyxLQUFLLEVBQUUsT0FBTyxFQUFFLE9BQU8sRUFBRSxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUM7YUFDN0U7U0FDSjtJQUNMLENBQUM7SUFFTSwrQ0FBa0IsR0FBekIsVUFBMEIsUUFBcUIsRUFBRSxvQkFBb0I7UUFDakUsSUFBSSxDQUFDLFFBQVEsSUFBSSxDQUFDLG9CQUFvQjtZQUFFLE9BQU87UUFFL0MsSUFBSSxPQUFPLEdBQUcsRUFBRSxDQUFDO1FBQ2pCLEtBQUssSUFBSSxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsR0FBRyxRQUFRLENBQUMsTUFBTSxFQUFFLEVBQUUsQ0FBQyxFQUFFO1lBQ3RDLElBQUksSUFBSSxHQUFHLE1BQU0sQ0FBQyxNQUFNLENBQUMsRUFBRSxFQUFFLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO1lBQzFDLElBQUksSUFBSSxDQUFDLGNBQWMsQ0FBQyxNQUFNLENBQUMsSUFBSSxPQUFPLElBQUksQ0FBQyxJQUFJLEtBQUssUUFBUSxFQUFFO2dCQUM5RCxJQUFJLENBQUMsSUFBSSxHQUFHLG9CQUFvQixDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxJQUFJLENBQUMsSUFBSSxDQUFDO2FBQzVEO1lBQ0QsSUFBSSxJQUFJLENBQUMsY0FBYyxDQUFDLFVBQVUsQ0FBQztnQkFBRSxJQUFJLENBQUMsUUFBUSxHQUFHLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxJQUFJLENBQUMsUUFBUSxFQUFFLG9CQUFvQixDQUFDLENBQUM7WUFDbEgsT0FBTyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQztTQUN0QjtRQUNELE9BQU8sT0FBTyxDQUFDO0lBQ25CLENBQUM7SUFFTSw0Q0FBZSxHQUF0QixVQUF1QixVQUFxRTtRQUN4RixPQUFPLENBQUMsVUFBVSxJQUFJLGFBQWEsQ0FBQyxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FBQyxHQUFHLENBQUMsVUFBQSxFQUFFLElBQUksT0FBQSxvQkFBb0IsR0FBRyxFQUFFLEVBQXpCLENBQXlCLENBQUMsQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUM7SUFDbkcsQ0FBQztJQUVELDhFQUE4RTtJQUU5RTs7Ozs7T0FLRztJQUNILHVEQUF1RDtJQUN2RCxzQ0FBc0M7SUFDdEMsNkNBQTZDO0lBQzdDLHlDQUF5QztJQUN6QyxJQUFJO0lBRUcsd0NBQVcsR0FBbEIsVUFBbUIsV0FBb0I7UUFDbkMsSUFBSSxlQUFlLEdBQVEsV0FBVyxDQUFDLGdCQUFnQixDQUFDLG1CQUFtQixDQUFDLENBQUM7UUFDN0UsS0FBSyxJQUFJLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxHQUFHLGVBQWUsQ0FBQyxNQUFNLEVBQUUsRUFBRSxDQUFDLEVBQUU7WUFDN0MsZUFBZSxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sRUFBRSxDQUFDO1NBQy9CO0lBQ0wsQ0FBQztJQUVNLCtDQUFrQixHQUF6QixVQUEwQixXQUFvQjtRQUMxQyxJQUFJLFVBQVUsR0FBRyxXQUFXLENBQUMsYUFBYSxDQUFDLDJCQUEyQixDQUFDLENBQUM7UUFDeEUsSUFBSSxDQUFDLFdBQVcsQ0FBQyxXQUFXLENBQUMsVUFBVSxFQUFFLGVBQWUsQ0FBQyxDQUFDO0lBQzlELENBQUM7SUFFRCw2RUFBNkU7SUFFdEUsNkNBQWdCLEdBQXZCLFVBQXdCLFlBQVk7UUFFaEMscUZBQXFGO1FBQ3JGLCtMQUErTDtRQUMvTCwwREFBMEQ7UUFDMUQsSUFBSSxJQUFJLENBQUMsV0FBVyxDQUFDLFFBQVEsRUFBRSxFQUFFO1lBQzdCLHdEQUF3RDtZQUN4RCxJQUFJLENBQUMsYUFBYSxHQUFHLE1BQU0sQ0FBQyxnQkFBZ0IsQ0FBQyxJQUFJLENBQUMsa0JBQWtCLENBQUMsVUFBVSxDQUFDLENBQUMsTUFBTSxDQUFDO1lBRXhGLGtGQUFrRjtZQUNsRixJQUFJLENBQUMsZUFBZSxDQUFDLE9BQU8sQ0FBQyxDQUFDO1NBQ2pDO1FBRUQsZ0RBQWdEO1FBQ2hELElBQUksQ0FBQyxlQUFlLENBQUMsWUFBWSxFQUFFLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxDQUFDO0lBQ2hFLENBQUM7SUFFTSw0Q0FBZSxHQUF0QixVQUF1QixLQUFLO1FBQ3hCLElBQUksQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFDLFFBQVEsRUFBRTtZQUFFLE9BQU87UUFFekMsUUFBUSxLQUFLLEVBQUU7WUFDWCxLQUFLLE9BQU87Z0JBQ1IsNERBQTREO2dCQUM1RCwrRkFBK0Y7Z0JBQy9GLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxVQUFVLENBQUMsS0FBSyxDQUFDLE1BQU0sR0FBRyxJQUFJLENBQUMsYUFBYSxDQUFDO2dCQUNyRSxNQUFNO1lBQ1YsS0FBSyxPQUFPLENBQUM7WUFDYjtnQkFDSSxJQUFJLENBQUMsa0JBQWtCLENBQUMsVUFBVSxDQUFDLEtBQUssQ0FBQyxNQUFNLEdBQUcsTUFBTSxDQUFDO2dCQUN6RCxNQUFNO1NBQ2I7SUFDTCxDQUFDO0lBRU8sNENBQWUsR0FBdkIsVUFBd0IsWUFBMEIsRUFBRSxRQUFRO1FBQ3hELFlBQVksQ0FBQyxZQUFZLENBQUMsR0FBRyxRQUFRLENBQUMscUJBQXFCLEVBQUUsQ0FBQyxNQUFNLENBQUM7SUFDekUsQ0FBQzs7Z0JBOUdnQyxZQUFZOztJQVJwQyxrQkFBa0I7UUFEOUIsVUFBVSxFQUFFO3lDQVN3QixZQUFZO09BUnBDLGtCQUFrQixDQXdIOUI7SUFBRCx5QkFBQztDQUFBLEFBeEhELElBd0hDO1NBeEhZLGtCQUFrQiIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IEluamVjdGFibGUgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcclxuaW1wb3J0IHsgSU1lbnVJdGVtIH0gZnJvbSAnLi4va2QtYW5ndWxhci1jaGFydHMva2QtYW5ndWxhci1jaGFydHMtaW50ZXJmYWNlJztcclxuaW1wb3J0IHsgS2REb21FbGVtU3ZjIH0gZnJvbSAnLi4va2QtY29tbW9uL2luZGV4JztcclxuaW1wb3J0IHsgSVRhYmxlQ29uZmlnLCBJVGFibGVDb2x1bW4gfSBmcm9tICcuL2tkLWFuZ3VsYXItdmlzdWFsaXphdGlvbi1pbnRlcmZhY2UnO1xyXG5cclxuQEluamVjdGFibGUoKVxyXG5leHBvcnQgY2xhc3MgS2RWaXN1YWxpemF0aW9uU3ZjIHtcclxuXHJcbiAgICBwcml2YXRlIF9wYXJlbnRIZWlnaHQ6IHN0cmluZztcclxuXHJcbiAgICBwcml2YXRlIF92aXN1YWxpemF0aW9uRWxlbTogYW55O1xyXG5cclxuICAgIHNldCB2aXN1YWxpemF0aW9uRWxlbShfZWxlbWVudCkgeyB0aGlzLl92aXN1YWxpemF0aW9uRWxlbSA9IF9lbGVtZW50OyB9XHJcblxyXG4gICAgY29uc3RydWN0b3IocHJpdmF0ZSBfZG9tRWxlbVN2YzogS2REb21FbGVtU3ZjKSB7IH1cclxuXHJcbiAgICAvLyB0YWJsZSB3aXRoaW4gY2hhcnQgZG9lcyBub3QgYWxsb3cgaW1hZ2Ugb3IgaW5wdXQgdHlwZSBjb2x1bW5zXHJcbiAgICBwdWJsaWMgZmlsdGVyQ29sdW1ucyhfY29sRGVmQXJyOiBJVGFibGVDb2x1bW5bXSk6IElUYWJsZUNvbHVtbltdIHtcclxuICAgICAgICAvLyBrZC10YWJsZSBjb25maWcgaXMgZGVmaW5lZCBpbiB0aGUgZm9sbG93aW5nIHdheSAoOSBNYXkgMjAxOClcclxuICAgICAgICAvLyB0ZXh0OiBkb2VzIG5vdCByZXF1aXJlIHRoZSBrZXkgJ3R5cGUnXHJcbiAgICAgICAgLy8gaW5wdXQgb3IgaW1hZ2U6IHB1dHMgdHlwZSA9PT0gaW1hZ2UgfHwgaW5wdXRcclxuICAgICAgICByZXR1cm4gX2NvbERlZkFyci5maWx0ZXIoY29sdW1uID0+ICFjb2x1bW4udHlwZSkubWFwKGNvbHVtbiA9PiBPYmplY3QuYXNzaWduKHt9LCBjb2x1bW4pKTtcclxuICAgIH1cclxuXHJcbiAgICBwdWJsaWMgZ2V0SW1tdXRhYmxlTWVudUFycihfZGVmYXVsdE1lbnVBcnIpIHtcclxuICAgICAgICByZXR1cm4gX2RlZmF1bHRNZW51QXJyLm1hcChpdGVtID0+IHtcclxuICAgICAgICAgICAgaWYgKGl0ZW0uZXhwYW5kZWQpIHRoaXMuZ2V0SW1tdXRhYmxlTWVudUFycihpdGVtLmV4cGFuZGVkKTtcclxuICAgICAgICAgICAgcmV0dXJuIE9iamVjdC5hc3NpZ24oe30sIGl0ZW0pO1xyXG4gICAgICAgIH0pO1xyXG4gICAgfVxyXG5cclxuICAgIHB1YmxpYyBzZXRNZW51SXRlbVZpc2liaWxpdHkoX3R5cGU6ICdpZCcgfCAnYWN0aW9uJywgX3N0cmluZzogc3RyaW5nLCBfaXNIaWRlOiBib29sZWFuLCBfbWVudUFycjogSU1lbnVJdGVtW10pOiB2b2lkIHtcclxuICAgICAgICBmb3IgKGxldCBpID0gMDsgaSA8IF9tZW51QXJyLmxlbmd0aDsgKytpKSB7XHJcbiAgICAgICAgICAgIGlmIChfbWVudUFycltpXVtfdHlwZV0gPT09IF9zdHJpbmcpIHtcclxuICAgICAgICAgICAgICAgIF9tZW51QXJyW2ldLmhpZGRlbiA9IF9pc0hpZGU7XHJcbiAgICAgICAgICAgICAgICBpZiAoX3R5cGUgPT09ICdpZCcpIGJyZWFrO1xyXG4gICAgICAgICAgICB9IGVsc2UgaWYgKF9tZW51QXJyW2ldLmhhc093blByb3BlcnR5KCdleHBhbmRlZCcpKSB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLnNldE1lbnVJdGVtVmlzaWJpbGl0eShfdHlwZSwgX3N0cmluZywgX2lzSGlkZSwgX21lbnVBcnJbaV0uZXhwYW5kZWQpO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIHB1YmxpYyBzZXRNZW51VHJhbnNsYXRpb24oX21lbnVBcnI6IElNZW51SXRlbVtdLCBfdHJhbnNsYXRpb25DYWxsYmFjayk6IElNZW51SXRlbVtdIHtcclxuICAgICAgICBpZiAoIV9tZW51QXJyICYmICFfdHJhbnNsYXRpb25DYWxsYmFjaykgcmV0dXJuO1xyXG5cclxuICAgICAgICBsZXQgbWVudUFyciA9IFtdO1xyXG4gICAgICAgIGZvciAobGV0IGkgPSAwOyBpIDwgX21lbnVBcnIubGVuZ3RoOyArK2kpIHtcclxuICAgICAgICAgICAgbGV0IGl0ZW0gPSBPYmplY3QuYXNzaWduKHt9LCBfbWVudUFycltpXSk7XHJcbiAgICAgICAgICAgIGlmIChpdGVtLmhhc093blByb3BlcnR5KCd0ZXh0JykgJiYgdHlwZW9mIGl0ZW0udGV4dCA9PT0gJ3N0cmluZycpIHtcclxuICAgICAgICAgICAgICAgIGl0ZW0udGV4dCA9IF90cmFuc2xhdGlvbkNhbGxiYWNrKGl0ZW0udGV4dCkgfHwgaXRlbS50ZXh0O1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIGlmIChpdGVtLmhhc093blByb3BlcnR5KCdleHBhbmRlZCcpKSBpdGVtLmV4cGFuZGVkID0gdGhpcy5zZXRNZW51VHJhbnNsYXRpb24oaXRlbS5leHBhbmRlZCwgX3RyYW5zbGF0aW9uQ2FsbGJhY2spO1xyXG4gICAgICAgICAgICBtZW51QXJyLnB1c2goaXRlbSk7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIHJldHVybiBtZW51QXJyO1xyXG4gICAgfVxyXG5cclxuICAgIHB1YmxpYyBnZXRCdG5BbGlnbm1lbnQoX2J0bkNvbmZpZzogJ3RvcC1sZWZ0JyB8ICd0b3AtcmlnaHQnIHwgJ2JvdHRvbS1sZWZ0JyB8ICdib3R0b20tcmlnaHQnKTogc3RyaW5nIHtcclxuICAgICAgICByZXR1cm4gKF9idG5Db25maWcgfHwgJ2JvdHRvbS1sZWZ0Jykuc3BsaXQoJy0nKS5tYXAoZWwgPT4gJ2tkeC12aXN1YWxpemF0aW9uLScgKyBlbCkuam9pbignICcpO1xyXG4gICAgfVxyXG5cclxuICAgIC8vID09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PSBFeHBvcnQgPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PVxyXG5cclxuICAgIC8qKlxyXG4gICAgICogYmVmb3JlIGV4cG9ydGluZywgdGhlIGh0bWwgbmVlZCB0byBiZSBjaGFuZ2VkXHJcbiAgICAgKiAxKSByZW1vdmUgYWxsIGR1bW15IGxhYmVsc1xyXG4gICAgICogMikgcmVtb3ZlIGNsYXNzIG5hbWUgJy5sZWdlbmQtc2Nyb2xsJyBpbiBvcmRlciB0byBkaXNwbGF5IGFsbCBsZWdlbmRcclxuICAgICAqICBfcGFyZW50RWxlbSBbZGVzY3JpcHRpb25dXHJcbiAgICAgKi9cclxuICAgIC8vIHB1YmxpYyBwcmVwYXJlSFRNTChfcGFyZW50RWxlbTogSFRNTEVsZW1lbnQpOiB2b2lkIHtcclxuICAgIC8vICAgICB0aGlzLl9yZW1vdmVEdW1teShfcGFyZW50RWxlbSk7XHJcbiAgICAvLyAgICAgdGhpcy5fcmVtb3ZlTGVnZW5kU2Nyb2xsKF9wYXJlbnRFbGVtKTtcclxuICAgIC8vICAgICBfcGFyZW50RWxlbS5zdHlsZS5oZWlnaHQgPSAnYXV0byc7XHJcbiAgICAvLyB9XHJcblxyXG4gICAgcHVibGljIHJlbW92ZUR1bW15KF9wYXJlbnRFbGVtOiBFbGVtZW50KTogdm9pZCB7XHJcbiAgICAgICAgbGV0IGR1bW15RWxlbWVudEFycjogYW55ID0gX3BhcmVudEVsZW0ucXVlcnlTZWxlY3RvckFsbCgnLmtkeC1jaGFydHMtZHVtbXknKTtcclxuICAgICAgICBmb3IgKGxldCBpID0gMDsgaSA8IGR1bW15RWxlbWVudEFyci5sZW5ndGg7ICsraSkge1xyXG4gICAgICAgICAgICBkdW1teUVsZW1lbnRBcnJbaV0ucmVtb3ZlKCk7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIHB1YmxpYyByZW1vdmVMZWdlbmRTY3JvbGwoX3BhcmVudEVsZW06IEVsZW1lbnQpIHtcclxuICAgICAgICBsZXQgbGVnZW5kRWxlbSA9IF9wYXJlbnRFbGVtLnF1ZXJ5U2VsZWN0b3IoJy5rZHgtbGVnZW5kLmxlZ2VuZC1zY3JvbGwnKTtcclxuICAgICAgICB0aGlzLl9kb21FbGVtU3ZjLnJlbW92ZUNsYXNzKGxlZ2VuZEVsZW0sICdsZWdlbmQtc2Nyb2xsJyk7XHJcbiAgICB9XHJcblxyXG4gICAgLy8gPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09IFRhYmxlID09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT1cclxuXHJcbiAgICBwdWJsaWMgcHJvY2Vzc1ZpZXdUYWJsZShfdGFibGVDb25maWcpIHtcclxuXHJcbiAgICAgICAgLy8gd2hlbiBhZy1ncmlkIGlzIGluIHNtYWxsIHNjcmVlbiwgcmVuZGVyIGFsbCByb3dzIGFuZCB0aGVyZSB3aWxsIGJlIG5vIGlubmVyLXNjcm9sbFxyXG4gICAgICAgIC8vIHRoaXMgbG9naWMgaXMgZm9yIG1vYmlsZSBkZXZpY2UsIGJlY2F1c2Ugd2hlbiB1c2luZyBtb2JpbGUgZGV2aWNlLCBhIGxhcmdlIHRhYmxlIHNob3VsZCBiZSBmdWxseSBkaXNwbGF5ZWQgdG8gcHJldmVudCBzY3JvbGxpbmcgY29uZnVzaW9uIChzd2lwaW5nIHBhZ2UgdXAgbWlnaHQgZW5kIHVwIHNjcm9sbGluZyB0aGUgdGFibGUpXHJcbiAgICAgICAgLy8gaGVuY2Ugd2Ugd2lsbCBzZXQgcGFyZW50J3MgaGVpZ2h0IHRvIGJlIDEwMCUgb2YgY29udGVudFxyXG4gICAgICAgIGlmICh0aGlzLl9kb21FbGVtU3ZjLmlzTW9iaWxlKCkpIHtcclxuICAgICAgICAgICAgLy8gd2hlbiBjaGFuZ2UgdG8gdGFibGUsIHN0b3JlIHBhcmVudCdzIGhlaWdodCBmb3IgY2hhcnRcclxuICAgICAgICAgICAgdGhpcy5fcGFyZW50SGVpZ2h0ID0gd2luZG93LmdldENvbXB1dGVkU3R5bGUodGhpcy5fdmlzdWFsaXphdGlvbkVsZW0ucGFyZW50Tm9kZSkuaGVpZ2h0O1xyXG5cclxuICAgICAgICAgICAgLy8gaWYgbW9iaWxlLCBzZXQgcGFyZW50IGhlaWdodCB0byAxMDAlIHNvIHRoYXQgYm90dG9tIGNvbnRlbnQgd2lsbCBiZSBwdXNoZWQgZG93blxyXG4gICAgICAgICAgICB0aGlzLnNldFBhcmVudEhlaWdodCgndGFibGUnKTtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIC8vIHRlbXAgZml4LiB0YWJsZSBkb2VzIG5vdCBmb2xsb3cgcGFyZW50IGhlaWdodFxyXG4gICAgICAgIHRoaXMuX3NldFRhYmxlSGVpZ2h0KF90YWJsZUNvbmZpZywgdGhpcy5fdmlzdWFsaXphdGlvbkVsZW0pO1xyXG4gICAgfVxyXG5cclxuICAgIHB1YmxpYyBzZXRQYXJlbnRIZWlnaHQoX3R5cGUpIHtcclxuICAgICAgICBpZiAoIXRoaXMuX2RvbUVsZW1TdmMuaXNNb2JpbGUoKSkgcmV0dXJuO1xyXG5cclxuICAgICAgICBzd2l0Y2ggKF90eXBlKSB7XHJcbiAgICAgICAgICAgIGNhc2UgJ2NoYXJ0JzpcclxuICAgICAgICAgICAgICAgIC8vIHdoZW4gY2hhbmdlIHRvIGNoYXJ0LCB1c2UgYmFjayB0aGUgc3RvcmVkIHBhcmVudCdzIGhlaWdodFxyXG4gICAgICAgICAgICAgICAgLy8gbm90ZTogY2hhcnQgcmVxdWlyZXMgcGFyZW50IHRvIHByb3ZpZGUgYSBkZWZpbml0ZSBoZWlnaHQgdmFsdWUgKGNhbm5vdCB1c2UgMTAwJSBvZiBjaGlsZHJlbilcclxuICAgICAgICAgICAgICAgIHRoaXMuX3Zpc3VhbGl6YXRpb25FbGVtLnBhcmVudE5vZGUuc3R5bGUuaGVpZ2h0ID0gdGhpcy5fcGFyZW50SGVpZ2h0O1xyXG4gICAgICAgICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgICAgIGNhc2UgJ3RhYmxlJzpcclxuICAgICAgICAgICAgZGVmYXVsdDpcclxuICAgICAgICAgICAgICAgIHRoaXMuX3Zpc3VhbGl6YXRpb25FbGVtLnBhcmVudE5vZGUuc3R5bGUuaGVpZ2h0ID0gJzEwMCUnO1xyXG4gICAgICAgICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX3NldFRhYmxlSGVpZ2h0KF90YWJsZUNvbmZpZzogSVRhYmxlQ29uZmlnLCBfZWxlbWVudCk6IHZvaWQge1xyXG4gICAgICAgIF90YWJsZUNvbmZpZ1snZ3JpZEhlaWdodCddID0gX2VsZW1lbnQuZ2V0Qm91bmRpbmdDbGllbnRSZWN0KCkuaGVpZ2h0O1xyXG4gICAgfVxyXG5cclxufVxyXG4iXX0=