import { __decorate, __metadata } from "tslib";
import { Component, ViewEncapsulation, Input, OnInit, Output, OnChanges, SimpleChanges, EventEmitter, ElementRef, ChangeDetectorRef, ViewChild } from '@angular/core';
import { Observable } from 'rxjs';
import { trigger, style, transition, animate } from '@angular/animations';
import { defaultMenuArr } from './kd-angular-visualization-interface';
import { KdVisualizationSvc } from './kd-angular-visualization-svc';
import { KdVisualizationExport } from './kd-angular-visualization-export';
import { KdDomElemSvc } from '../kd-common/index';
import { KdCharts } from '../kd-angular-charts/index';
var KdVisualization = /** @class */ (function () {
    function KdVisualization(_elemRef, _visualizationSvc, cdr) {
        this._elemRef = _elemRef;
        this._visualizationSvc = _visualizationSvc;
        this.cdr = cdr;
        /* menu */
        this.isExportEnabled = false;
        this.isMenuOpen = false;
        this.menuFlag = 'closed'; // can be 'opened' | 'closed' | 'expanded' | 'viewed'
        this.menuDisplayArr = [];
        this._menuArr = [];
        this.menuBtnIconClass = 'fa-chevron-up';
        this._menuBtnList = {
            closed: 'fa-chevron-up',
            opened: 'fa-close',
            viewed: 'fa-close',
            expanded: 'fa-chevron-left'
        };
        /* invisible chart */
        this.exportNow = false;
        /* initial load of invisible chart should not start drawing. need to wait for setLegendData, then draw in one go */
        this.dataForInvisibleChart = null;
        this.configForInvisiblechart = null;
        this.invisibleChartClass = 'kdx-visualization-chart-invisible';
        this._defaultChartWidth = '1024px';
        /* view */
        this.contentState = 'chart'; // currently only have chart | table
        this.exportTable = false;
        this._timeoutTiming = 1000;
        this.outputLegendData = new EventEmitter();
        this.errorMsg = new EventEmitter();
        this.outputArea = new EventEmitter();
        this._export = new KdVisualizationExport();
        this._visualizationSvc.visualizationElem = this._elemRef.nativeElement;
    }
    KdVisualization.prototype.ngOnInit = function () {
        this._initApi();
    };
    KdVisualization.prototype.ngOnChanges = function (_simpleChanges) {
        if (_simpleChanges.hasOwnProperty('config') && _simpleChanges.config.currentValue) {
            this._setConfig(_simpleChanges.config.currentValue.export);
        }
        if (_simpleChanges.hasOwnProperty('rawData') && _simpleChanges.rawData.currentValue) {
            this.columnAfterFilter = this._visualizationSvc.filterColumns(_simpleChanges.rawData.currentValue.column);
        }
    };
    KdVisualization.prototype.getOutputData = function (_data) {
        this.dataAfterMassage = _data;
    };
    KdVisualization.prototype.getOutputLegendData = function (_legendData) {
        this.outputLegendData.emit(_legendData);
        this.legendDataAfterMassage = _legendData;
    };
    KdVisualization.prototype.setArea = function (_data) {
        this.outputArea.emit(_data);
    };
    KdVisualization.prototype.onExportExcelPossible = function () {
        if (this.exportTable) {
            this.rawData.api.general.exportToExcel({ fileName: this._fileName });
            this.exportTable = false;
        }
    };
    // ================================= Config ==================================
    KdVisualization.prototype._setConfig = function (_config) {
        // whenever config changes, set back to default values
        this.contentState = 'chart';
        this.menuFlag = 'closed';
        this.isMenuOpen = false;
        this.isExportEnabled = _config && _config.enabled;
        if (!this.isExportEnabled)
            return;
        this._setInitMenu(_config.menu);
        this.invisibleChartStyle = { 'width': _config.width || this._defaultChartWidth };
        this.btnAlignment = this._visualizationSvc.getBtnAlignment(_config.btn);
        this._setInitBtnClass(_config.btn);
    };
    KdVisualization.prototype._setInitBtnClass = function (_btnConfig) {
        if (_btnConfig && _btnConfig.split('-')[0] === 'top') {
            this.menuBtnIconClass = 'fa-chevron-down';
            this._menuBtnList.closed = 'fa-chevron-down';
        }
        else {
            this.menuBtnIconClass = 'fa-chevron-up';
            this._menuBtnList.closed = 'fa-chevron-up';
        }
    };
    KdVisualization.prototype._setInitMenu = function (_menu) {
        var menuArr = this._visualizationSvc.getImmutableMenuArr(defaultMenuArr);
        // translationCallback should take english string and return translated string
        if (this.api && this.api.hasOwnProperty('translationCallback')) {
            menuArr = this._visualizationSvc.setMenuTranslation(menuArr, this.api.translationCallback);
        }
        this._menuArr = menuArr.concat(_menu || []);
        if (!this.rawData)
            this._menuArr = this._menuArr.filter(function (item) { return item.id !== 'viewData' && item.id !== 'excel'; });
        this.menuDisplayArr = this._menuArr;
    };
    // ================================= INIT API and Sub ==================================
    KdVisualization.prototype._initApi = function () {
        var _this = this;
        if (!this.api)
            return;
        this.api.addMenuItem = function (_menuItemArr) {
            _this._menuArr = _this._menuArr.concat(_menuItemArr);
            _this.cdr.detectChanges();
        };
        this.api.hideMenuItemById = function (_id, _isHide) {
            if (_isHide === void 0) { _isHide = true; }
            _this._visualizationSvc.setMenuItemVisibility('id', _id, _isHide, _this._menuArr);
            _this.cdr.detectChanges();
        };
        this.api.hideMenuItemByAction = function (_action, _isHide) {
            if (_isHide === void 0) { _isHide = true; }
            _this._visualizationSvc.setMenuItemVisibility('action', _action, _isHide, _this._menuArr);
            _this.cdr.detectChanges();
        };
        this.api.getDataUrl = function (_style, _options, _isRemoveLegendScroll) {
            return new Observable(function (_observer) {
                var originalStyle = {};
                if (_style) {
                    originalStyle = Object.assign({}, _this.invisibleChartStyle);
                    _this.invisibleChartStyle = _style;
                }
                _this._prepExportChart('imageUrl', _options, _isRemoveLegendScroll).subscribe(function (_response) {
                    if (_style)
                        _this.invisibleChartStyle = originalStyle;
                    _observer.next(_response);
                    _observer.complete();
                });
            });
        };
        this.api.toggleTable = function (_showTable, rawData) {
            rawData.config = Object.assign({}, _this.rawData.config, rawData.config);
            _this.rawData = Object.assign({}, rawData);
            _this.columnAfterFilter = _this._visualizationSvc.filterColumns(rawData.column);
            if (_showTable) {
                _this._tempState = _this.contentState;
                if (_this.contentState !== 'table') {
                    _this.contentState = 'table';
                    _this._callPlugins('view.table');
                }
                _this.isExportEnabled = false;
            }
            else {
                _this.isExportEnabled = typeof _this.config !== 'undefined' && _this.config.export.enabled;
                _this._visualizationSvc.setParentHeight('chart');
                _this.contentState = _this._tempState ? _this._tempState : 'chart';
            }
        };
    };
    // ================================= Menu Clicked ==================================
    KdVisualization.prototype.toggleMenu = function (_item) {
        var haveOperation = _item && _item.operation;
        var haveCallback = _item && _item.callback;
        if (haveOperation)
            this._callPlugins(_item.operation);
        if (haveCallback)
            _item.callback();
        this._toggleMenuFlag(this.menuFlag, _item, haveOperation || haveCallback);
        this.menuBtnIconClass = this._menuBtnList[this.menuFlag];
        this.isMenuOpen = this.menuFlag === 'opened' || this.menuFlag === 'expanded';
    };
    KdVisualization.prototype._toggleMenuFlag = function (_flag, _item, _closeExpand) {
        switch (_flag) {
            case 'closed':
            default:
                this.menuFlag = 'opened';
                break;
            case 'opened':
                var isExpand = _item && _item.expanded;
                if (isExpand) {
                    this.menuDisplayArr = _item.expanded;
                    this.menuFlag = 'expanded';
                    return;
                }
                var isView = false;
                if (_item && _item.hasOwnProperty('operation')) {
                    isView = _item && _item.operation.indexOf('view') > -1;
                    if (isView)
                        this.contentState = _item.operation.split('.')[1];
                }
                this.menuFlag = isView ? 'viewed' : 'closed';
                break;
            case 'expanded':
                this.menuFlag = _closeExpand ? 'closed' : 'opened';
                this.menuDisplayArr = this._menuArr;
                break;
            case 'viewed':
                this._visualizationSvc.setParentHeight('chart');
                this.menuFlag = 'closed';
                this.contentState = 'chart';
                break;
        }
    };
    KdVisualization.prototype._callPlugins = function (_operation) {
        // operations are separated by .
        var operationArr = _operation.split('.');
        if (operationArr[0] === 'view' && operationArr[1] === 'table') {
            this._visualizationSvc.processViewTable(this.rawData.config);
            return;
        }
        if (operationArr[0] !== 'export')
            return;
        if (this.config.title.text)
            this._fileName = this.config.title.text.replace(/\s/g, '_');
        if (operationArr[1] === 'excel') {
            this.exportTable = true;
        }
        else {
            this._prepExportChart(operationArr[1]).subscribe(function () { });
        }
    };
    KdVisualization.prototype._prepExportChart = function (_operation, _options, _isRemoveLegendScroll) {
        var _this = this;
        if (_options === void 0) { _options = {}; }
        if (_isRemoveLegendScroll === void 0) { _isRemoveLegendScroll = true; }
        return new Observable(function (_observer) {
            if (!_this._export.isExportCompatible()) {
                _this.errorMsg.emit(_this._export.getErrorMessage(_operation));
                _observer.error(_this._export.getErrorMessage(_operation));
                _observer.complete();
            }
            else {
                // chart for exporting should skip massage and not have animation
                _this.configForInvisiblechart = Object.assign({}, _this.config, { id: 'export-chart', animation: false, skipMassage: true });
                _this.exportNow = true;
                // ViewChild requires setTimeout (Angular 5)
                setTimeout(function () {
                    // set Legend Data so that this info does not have to be regenerated by invisible chart
                    _this.invisibleChart.setLegendData(_this.legendDataAfterMassage);
                    // trigger chart to draw once legend data is set
                    _this.dataForInvisibleChart = _this.dataAfterMassage;
                });
                var options_1 = Object.assign({}, _options);
                if (_this._fileName)
                    options_1['fileName'] = _this._fileName;
                setTimeout(function () {
                    var chartElement = _this._elemRef.nativeElement.querySelector('.' + _this.invisibleChartClass + '.kdx-charts');
                    // before exporting, the html needs to be changed
                    _this._visualizationSvc.removeDummy(chartElement);
                    if (_isRemoveLegendScroll)
                        _this._visualizationSvc.removeLegendScroll(chartElement);
                    chartElement.style.height = 'auto';
                    options_1['width'] = chartElement.getBoundingClientRect().width + 1;
                    options_1['height'] = chartElement.getBoundingClientRect().height + 1;
                    var result = _this._export.exportElement(chartElement, _operation, options_1);
                    // once export is done, remove the invisible chart from DOM
                    _this.exportNow = false;
                    _this.dataForInvisibleChart = null;
                    if (result) {
                        result.then(function (dataUrl) {
                            _observer.next(dataUrl);
                            _observer.complete();
                        });
                    }
                    else {
                        _observer.complete();
                    }
                }, _this._timeoutTiming);
            }
        });
    };
    KdVisualization.ctorParameters = function () { return [
        { type: ElementRef },
        { type: KdVisualizationSvc },
        { type: ChangeDetectorRef }
    ]; };
    __decorate([
        Input('data'),
        __metadata("design:type", Object)
    ], KdVisualization.prototype, "data", void 0);
    __decorate([
        Input('rawData'),
        __metadata("design:type", Object)
    ], KdVisualization.prototype, "rawData", void 0);
    __decorate([
        Input('config'),
        __metadata("design:type", Object)
    ], KdVisualization.prototype, "config", void 0);
    __decorate([
        Input(),
        __metadata("design:type", Number)
    ], KdVisualization.prototype, "xThreshold", void 0);
    __decorate([
        Input(),
        __metadata("design:type", Number)
    ], KdVisualization.prototype, "seriesThreshold", void 0);
    __decorate([
        Input(),
        __metadata("design:type", Object)
    ], KdVisualization.prototype, "api", void 0);
    __decorate([
        Output(),
        __metadata("design:type", EventEmitter)
    ], KdVisualization.prototype, "outputLegendData", void 0);
    __decorate([
        Output(),
        __metadata("design:type", EventEmitter)
    ], KdVisualization.prototype, "errorMsg", void 0);
    __decorate([
        Output(),
        __metadata("design:type", EventEmitter)
    ], KdVisualization.prototype, "outputArea", void 0);
    __decorate([
        ViewChild('invisibleChart'),
        __metadata("design:type", KdCharts)
    ], KdVisualization.prototype, "invisibleChart", void 0);
    KdVisualization = __decorate([
        Component({
            selector: 'kd-visualization',
            template: "<div class=\"kdx-visualization-chart-wrapper\" [ngClass]=\"{'kdx-visualization-invisible-wrapper': contentState !== 'chart'}\">\r\n    <kd-charts [data]=\"data\"\r\n               [config]=\"config\" \r\n               [api]=\"api\"\r\n               [xThreshold]=\"xThreshold\"\r\n               [seriesThreshold]=\"seriesThreshold\"\r\n               (outputData)=\"getOutputData($event)\" \r\n               (outputLegendData)=\"getOutputLegendData($event)\" (outputArea)=\"setArea($event)\"></kd-charts>\r\n    <div class=\"kdx-visualization-invisible-wrapper\">\r\n      <kd-charts *ngIf=\"exportNow\"\r\n                  id=\"export-chart\"\r\n                  #invisibleChart\r\n                  [data]=\"dataForInvisibleChart\" \r\n                  [config]=\"configForInvisiblechart\" \r\n                  [xThreshold]=\"xThreshold\"\r\n                  [seriesThreshold]=\"seriesThreshold\"\r\n                  [ngClass]=\"invisibleChartClass\"\r\n                  [ngStyle]=\"invisibleChartStyle\"></kd-charts>\r\n    </div>\r\n</div>\r\n\r\n<kd-table  *ngIf=\"rawData && (exportTable || contentState == 'table')\"\r\n        [ngClass]=\"{'kdx-visualization-invisible-wrapper': exportTable}\"\r\n        [row]=\"rawData.row\"\r\n        [column]=\"columnAfterFilter\"\r\n        [config]=\"rawData.config\"\r\n        [api]=\"rawData.api\"\r\n        (onExportPossible)=\"onExportExcelPossible()\"></kd-table>\r\n\r\n<div *ngIf=\"isExportEnabled && isMenuOpen\" class=\"kdx-visualization-menu-container\">\r\n    <div *ngFor=\"let item of menuDisplayArr; let i = index \" class=\"kdx-visualization-menu-item-wrapper kdx-visualization-menu-item-{{i}}\" [ngClass]=\"{'menu-item-hide': item.hidden}\" (click)=\"toggleMenu(item)\" [@itemAnim]>\r\n        <i *ngIf=\"item.iconStart\" class=\"kdx-visualization-icon-start fa {{item.iconStart}}\"></i>\r\n        <span *ngIf=\"item.text\">{{item.text}}</span>\r\n        <i *ngIf=\"item.iconEnd\" class=\"kdx-visualization-icon-end fa {{item.iconEnd}}\" [ngClass]=\"{'have-expand-arrow': item.expanded !== undefined }\"></i>\r\n    </div>\r\n</div>\r\n<div *ngIf=\"isExportEnabled\" class=\"kdx-visualization-menu-btn-wrapper\">\r\n    <div class=\"kdx-visualization-menu-btn-container {{btnAlignment}}\">\r\n        <button class=\"kdx-visualization-menu-btn btn-outline\" (click)=\"toggleMenu()\">\r\n            <i class=\"fa {{menuBtnIconClass}} {{menuFlag}}\"></i>\r\n        </button>\r\n    </div>\r\n</div>\r\n",
            encapsulation: ViewEncapsulation.None,
            providers: [KdVisualizationSvc, KdDomElemSvc],
            host: {
                'class': 'kdx-visualization',
            },
            animations: [
                trigger('itemAnim', [
                    transition(':enter', [
                        style({ transform: 'translateY(100%)' }),
                        animate('0.2s 0.2s ease-in')
                    ]),
                ])
            ]
        }),
        __metadata("design:paramtypes", [ElementRef,
            KdVisualizationSvc,
            ChangeDetectorRef])
    ], KdVisualization);
    return KdVisualization;
}());
export { KdVisualization };
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoia2QtYW5ndWxhci12aXN1YWxpemF0aW9uLmpzIiwic291cmNlUm9vdCI6Im5nOi8vb3BlbmVtaXMtc3R5bGVndWlkZS1saWIvIiwic291cmNlcyI6WyJrZC1jb21wb25lbnRzL2tkLWFuZ3VsYXItdmlzdWFsaXphdGlvbi9rZC1hbmd1bGFyLXZpc3VhbGl6YXRpb24udHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IjtBQUFBLE9BQU8sRUFDSCxTQUFTLEVBQ1QsaUJBQWlCLEVBQ2pCLEtBQUssRUFDTCxNQUFNLEVBQ04sTUFBTSxFQUNOLFNBQVMsRUFDVCxhQUFhLEVBQ2IsWUFBWSxFQUNaLFVBQVUsRUFDVixpQkFBaUIsRUFDakIsU0FBUyxFQUNaLE1BQU0sZUFBZSxDQUFDO0FBQ3ZCLE9BQU8sRUFBRSxVQUFVLEVBQVksTUFBTSxNQUFNLENBQUM7QUFDNUMsT0FBTyxFQUFFLE9BQU8sRUFBRSxLQUFLLEVBQUUsVUFBVSxFQUFFLE9BQU8sRUFBRSxNQUFNLHFCQUFxQixDQUFDO0FBQzFFLE9BQU8sRUFBRSxjQUFjLEVBQXNDLE1BQU0sc0NBQXNDLENBQUM7QUFFMUcsT0FBTyxFQUFFLGtCQUFrQixFQUFFLE1BQU0sZ0NBQWdDLENBQUM7QUFDcEUsT0FBTyxFQUFFLHFCQUFxQixFQUFFLE1BQU0sbUNBQW1DLENBQUM7QUFDMUUsT0FBTyxFQUFFLFlBQVksRUFBRSxNQUFNLG9CQUFvQixDQUFDO0FBQ2xELE9BQU8sRUFBRSxRQUFRLEVBQUUsTUFBTSw0QkFBNEIsQ0FBQztBQW9CdEQ7SUF3REkseUJBQ1ksUUFBb0IsRUFDcEIsaUJBQXFDLEVBQ3JDLEdBQXNCO1FBRnRCLGFBQVEsR0FBUixRQUFRLENBQVk7UUFDcEIsc0JBQWlCLEdBQWpCLGlCQUFpQixDQUFvQjtRQUNyQyxRQUFHLEdBQUgsR0FBRyxDQUFtQjtRQTFEbEMsVUFBVTtRQUNILG9CQUFlLEdBQVksS0FBSyxDQUFDO1FBQ2pDLGVBQVUsR0FBWSxLQUFLLENBQUM7UUFDNUIsYUFBUSxHQUFnRCxRQUFRLENBQUMsQ0FBQyxxREFBcUQ7UUFDdkgsbUJBQWMsR0FBRyxFQUFFLENBQUM7UUFDbkIsYUFBUSxHQUFnQixFQUFFLENBQUM7UUFJNUIscUJBQWdCLEdBQVcsZUFBZSxDQUFDO1FBQzFDLGlCQUFZLEdBQXlFO1lBQ3pGLE1BQU0sRUFBRSxlQUFlO1lBQ3ZCLE1BQU0sRUFBRSxVQUFVO1lBQ2xCLE1BQU0sRUFBRSxVQUFVO1lBQ2xCLFFBQVEsRUFBRSxpQkFBaUI7U0FDOUIsQ0FBQztRQUVGLHFCQUFxQjtRQUNkLGNBQVMsR0FBWSxLQUFLLENBQUM7UUFDbEMsbUhBQW1IO1FBQzVHLDBCQUFxQixHQUFZLElBQUksQ0FBQztRQUN0Qyw0QkFBdUIsR0FBaUIsSUFBSSxDQUFDO1FBSTdDLHdCQUFtQixHQUFXLG1DQUFtQyxDQUFDO1FBQ2pFLHVCQUFrQixHQUFXLFFBQVEsQ0FBQztRQUU5QyxVQUFVO1FBQ0gsaUJBQVksR0FBVyxPQUFPLENBQUMsQ0FBQyxvQ0FBb0M7UUFFcEUsZ0JBQVcsR0FBWSxLQUFLLENBQUM7UUFVNUIsbUJBQWMsR0FBVyxJQUFJLENBQUM7UUFRNUIscUJBQWdCLEdBQWlELElBQUksWUFBWSxFQUFFLENBQUM7UUFDcEYsYUFBUSxHQUF5QixJQUFJLFlBQVksRUFBRSxDQUFDO1FBQ3BELGVBQVUsR0FBMEIsSUFBSSxZQUFZLEVBQUUsQ0FBQztRQVM3RCxJQUFJLENBQUMsT0FBTyxHQUFHLElBQUkscUJBQXFCLEVBQUUsQ0FBQztRQUMzQyxJQUFJLENBQUMsaUJBQWlCLENBQUMsaUJBQWlCLEdBQUcsSUFBSSxDQUFDLFFBQVEsQ0FBQyxhQUFhLENBQUM7SUFDM0UsQ0FBQztJQUVELGtDQUFRLEdBQVI7UUFDSSxJQUFJLENBQUMsUUFBUSxFQUFFLENBQUM7SUFDcEIsQ0FBQztJQUVELHFDQUFXLEdBQVgsVUFBWSxjQUE2QjtRQUNyQyxJQUFJLGNBQWMsQ0FBQyxjQUFjLENBQUMsUUFBUSxDQUFDLElBQUksY0FBYyxDQUFDLE1BQU0sQ0FBQyxZQUFZLEVBQUU7WUFDL0UsSUFBSSxDQUFDLFVBQVUsQ0FBQyxjQUFjLENBQUMsTUFBTSxDQUFDLFlBQVksQ0FBQyxNQUFNLENBQUMsQ0FBQztTQUM5RDtRQUVELElBQUksY0FBYyxDQUFDLGNBQWMsQ0FBQyxTQUFTLENBQUMsSUFBSSxjQUFjLENBQUMsT0FBTyxDQUFDLFlBQVksRUFBRTtZQUNqRixJQUFJLENBQUMsaUJBQWlCLEdBQUcsSUFBSSxDQUFDLGlCQUFpQixDQUFDLGFBQWEsQ0FBQyxjQUFjLENBQUMsT0FBTyxDQUFDLFlBQVksQ0FBQyxNQUFNLENBQUMsQ0FBQztTQUM3RztJQUNMLENBQUM7SUFFTSx1Q0FBYSxHQUFwQixVQUFxQixLQUFjO1FBQy9CLElBQUksQ0FBQyxnQkFBZ0IsR0FBRyxLQUFLLENBQUM7SUFDbEMsQ0FBQztJQUVNLDZDQUFtQixHQUExQixVQUEyQixXQUEyQztRQUNsRSxJQUFJLENBQUMsZ0JBQWdCLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxDQUFDO1FBQ3hDLElBQUksQ0FBQyxzQkFBc0IsR0FBRyxXQUFXLENBQUM7SUFDOUMsQ0FBQztJQUVNLGlDQUFPLEdBQWQsVUFBZSxLQUFLO1FBQ2hCLElBQUksQ0FBQyxVQUFVLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFDO0lBQ2hDLENBQUM7SUFFTSwrQ0FBcUIsR0FBNUI7UUFDSSxJQUFJLElBQUksQ0FBQyxXQUFXLEVBQUU7WUFDbEIsSUFBSSxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsT0FBTyxDQUFDLGFBQWEsQ0FBQyxFQUFFLFFBQVEsRUFBRSxJQUFJLENBQUMsU0FBUyxFQUFFLENBQUMsQ0FBQztZQUNyRSxJQUFJLENBQUMsV0FBVyxHQUFHLEtBQUssQ0FBQztTQUM1QjtJQUNMLENBQUM7SUFFRCw4RUFBOEU7SUFFdEUsb0NBQVUsR0FBbEIsVUFBbUIsT0FBcUI7UUFDcEMsc0RBQXNEO1FBQ3RELElBQUksQ0FBQyxZQUFZLEdBQUcsT0FBTyxDQUFDO1FBQzVCLElBQUksQ0FBQyxRQUFRLEdBQUcsUUFBUSxDQUFDO1FBQ3pCLElBQUksQ0FBQyxVQUFVLEdBQUcsS0FBSyxDQUFDO1FBRXhCLElBQUksQ0FBQyxlQUFlLEdBQUcsT0FBTyxJQUFJLE9BQU8sQ0FBQyxPQUFPLENBQUM7UUFFbEQsSUFBSSxDQUFDLElBQUksQ0FBQyxlQUFlO1lBQUUsT0FBTztRQUVsQyxJQUFJLENBQUMsWUFBWSxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsQ0FBQztRQUVoQyxJQUFJLENBQUMsbUJBQW1CLEdBQUcsRUFBRSxPQUFPLEVBQUUsT0FBTyxDQUFDLEtBQUssSUFBSSxJQUFJLENBQUMsa0JBQWtCLEVBQUUsQ0FBQztRQUNqRixJQUFJLENBQUMsWUFBWSxHQUFHLElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxlQUFlLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxDQUFDO1FBRXhFLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLENBQUM7SUFDdkMsQ0FBQztJQUVPLDBDQUFnQixHQUF4QixVQUF5QixVQUFxRTtRQUMxRixJQUFJLFVBQVUsSUFBSSxVQUFVLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLEtBQUssRUFBRTtZQUNsRCxJQUFJLENBQUMsZ0JBQWdCLEdBQUcsaUJBQWlCLENBQUM7WUFDMUMsSUFBSSxDQUFDLFlBQVksQ0FBQyxNQUFNLEdBQUcsaUJBQWlCLENBQUM7U0FDaEQ7YUFBTTtZQUNILElBQUksQ0FBQyxnQkFBZ0IsR0FBRyxlQUFlLENBQUM7WUFDeEMsSUFBSSxDQUFDLFlBQVksQ0FBQyxNQUFNLEdBQUcsZUFBZSxDQUFDO1NBQzlDO0lBQ0wsQ0FBQztJQUVPLHNDQUFZLEdBQXBCLFVBQXFCLEtBQWtCO1FBQ25DLElBQUksT0FBTyxHQUFHLElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxtQkFBbUIsQ0FBQyxjQUFjLENBQUMsQ0FBQztRQUV6RSw4RUFBOEU7UUFDOUUsSUFBSSxJQUFJLENBQUMsR0FBRyxJQUFJLElBQUksQ0FBQyxHQUFHLENBQUMsY0FBYyxDQUFDLHFCQUFxQixDQUFDLEVBQUU7WUFDNUQsT0FBTyxHQUFHLElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxrQkFBa0IsQ0FBQyxPQUFPLEVBQUUsSUFBSSxDQUFDLEdBQUcsQ0FBQyxtQkFBbUIsQ0FBQyxDQUFDO1NBQzlGO1FBRUQsSUFBSSxDQUFDLFFBQVEsR0FBRyxPQUFPLENBQUMsTUFBTSxDQUFDLEtBQUssSUFBSSxFQUFFLENBQUMsQ0FBQztRQUM1QyxJQUFJLENBQUMsSUFBSSxDQUFDLE9BQU87WUFBRSxJQUFJLENBQUMsUUFBUSxHQUFHLElBQUksQ0FBQyxRQUFRLENBQUMsTUFBTSxDQUFDLFVBQUEsSUFBSSxJQUFJLE9BQUEsSUFBSSxDQUFDLEVBQUUsS0FBSyxVQUFVLElBQUksSUFBSSxDQUFDLEVBQUUsS0FBSyxPQUFPLEVBQTdDLENBQTZDLENBQUMsQ0FBQztRQUMvRyxJQUFJLENBQUMsY0FBYyxHQUFHLElBQUksQ0FBQyxRQUFRLENBQUM7SUFDeEMsQ0FBQztJQUVELHdGQUF3RjtJQUVoRixrQ0FBUSxHQUFoQjtRQUFBLGlCQWdEQztRQS9DRyxJQUFJLENBQUMsSUFBSSxDQUFDLEdBQUc7WUFBRSxPQUFPO1FBRXRCLElBQUksQ0FBQyxHQUFHLENBQUMsV0FBVyxHQUFHLFVBQUMsWUFBeUI7WUFDN0MsS0FBSSxDQUFDLFFBQVEsR0FBRyxLQUFJLENBQUMsUUFBUSxDQUFDLE1BQU0sQ0FBQyxZQUFZLENBQUMsQ0FBQztZQUNuRCxLQUFJLENBQUMsR0FBRyxDQUFDLGFBQWEsRUFBRSxDQUFDO1FBQzdCLENBQUMsQ0FBQztRQUNGLElBQUksQ0FBQyxHQUFHLENBQUMsZ0JBQWdCLEdBQUcsVUFBQyxHQUFXLEVBQUUsT0FBdUI7WUFBdkIsd0JBQUEsRUFBQSxjQUF1QjtZQUM3RCxLQUFJLENBQUMsaUJBQWlCLENBQUMscUJBQXFCLENBQUMsSUFBSSxFQUFFLEdBQUcsRUFBRSxPQUFPLEVBQUUsS0FBSSxDQUFDLFFBQVEsQ0FBQyxDQUFDO1lBQ2hGLEtBQUksQ0FBQyxHQUFHLENBQUMsYUFBYSxFQUFFLENBQUM7UUFDN0IsQ0FBQyxDQUFDO1FBQ0YsSUFBSSxDQUFDLEdBQUcsQ0FBQyxvQkFBb0IsR0FBRyxVQUFDLE9BQWUsRUFBRSxPQUF1QjtZQUF2Qix3QkFBQSxFQUFBLGNBQXVCO1lBQ3JFLEtBQUksQ0FBQyxpQkFBaUIsQ0FBQyxxQkFBcUIsQ0FBQyxRQUFRLEVBQUUsT0FBTyxFQUFFLE9BQU8sRUFBRSxLQUFJLENBQUMsUUFBUSxDQUFDLENBQUM7WUFDeEYsS0FBSSxDQUFDLEdBQUcsQ0FBQyxhQUFhLEVBQUUsQ0FBQztRQUM3QixDQUFDLENBQUM7UUFDRixJQUFJLENBQUMsR0FBRyxDQUFDLFVBQVUsR0FBRyxVQUFDLE1BQWUsRUFBRSxRQUFtQixFQUFFLHFCQUErQjtZQUN4RixPQUFPLElBQUksVUFBVSxDQUFTLFVBQUMsU0FBMkI7Z0JBQ3RELElBQUksYUFBYSxHQUFXLEVBQUUsQ0FBQztnQkFDL0IsSUFBSSxNQUFNLEVBQUU7b0JBQ1IsYUFBYSxHQUFHLE1BQU0sQ0FBQyxNQUFNLENBQUMsRUFBRSxFQUFFLEtBQUksQ0FBQyxtQkFBbUIsQ0FBQyxDQUFDO29CQUM1RCxLQUFJLENBQUMsbUJBQW1CLEdBQUcsTUFBTSxDQUFDO2lCQUNyQztnQkFDRCxLQUFJLENBQUMsZ0JBQWdCLENBQUMsVUFBVSxFQUFFLFFBQVEsRUFBRSxxQkFBcUIsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxVQUFDLFNBQVM7b0JBQ25GLElBQUcsTUFBTTt3QkFBRSxLQUFJLENBQUMsbUJBQW1CLEdBQUcsYUFBYSxDQUFDO29CQUNwRCxTQUFTLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDO29CQUMxQixTQUFTLENBQUMsUUFBUSxFQUFFLENBQUM7Z0JBQ3pCLENBQUMsQ0FBQyxDQUFDO1lBQ1AsQ0FBQyxDQUFDLENBQUM7UUFDUCxDQUFDLENBQUM7UUFFRixJQUFJLENBQUMsR0FBRyxDQUFDLFdBQVcsR0FBRyxVQUFDLFVBQW1CLEVBQUUsT0FBbUI7WUFDNUQsT0FBTyxDQUFDLE1BQU0sR0FBRyxNQUFNLENBQUMsTUFBTSxDQUFDLEVBQUUsRUFBRSxLQUFJLENBQUMsT0FBTyxDQUFDLE1BQU0sRUFBRSxPQUFPLENBQUMsTUFBTSxDQUFDLENBQUM7WUFDeEUsS0FBSSxDQUFDLE9BQU8sR0FBRyxNQUFNLENBQUMsTUFBTSxDQUFDLEVBQUUsRUFBRSxPQUFPLENBQUMsQ0FBQztZQUMxQyxLQUFJLENBQUMsaUJBQWlCLEdBQUcsS0FBSSxDQUFDLGlCQUFpQixDQUFDLGFBQWEsQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLENBQUM7WUFDOUUsSUFBSSxVQUFVLEVBQUU7Z0JBQ1osS0FBSSxDQUFDLFVBQVUsR0FBRyxLQUFJLENBQUMsWUFBWSxDQUFDO2dCQUNwQyxJQUFJLEtBQUksQ0FBQyxZQUFZLEtBQUssT0FBTyxFQUFFO29CQUMvQixLQUFJLENBQUMsWUFBWSxHQUFHLE9BQU8sQ0FBQztvQkFDNUIsS0FBSSxDQUFDLFlBQVksQ0FBQyxZQUFZLENBQUMsQ0FBQztpQkFDbkM7Z0JBRUQsS0FBSSxDQUFDLGVBQWUsR0FBRyxLQUFLLENBQUM7YUFDaEM7aUJBQU07Z0JBQ0gsS0FBSSxDQUFDLGVBQWUsR0FBRyxPQUFPLEtBQUksQ0FBQyxNQUFNLEtBQUssV0FBVyxJQUFJLEtBQUksQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLE9BQU8sQ0FBQztnQkFDeEYsS0FBSSxDQUFDLGlCQUFpQixDQUFDLGVBQWUsQ0FBQyxPQUFPLENBQUMsQ0FBQztnQkFDaEQsS0FBSSxDQUFDLFlBQVksR0FBRyxLQUFJLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQyxLQUFJLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUM7YUFDbkU7UUFDTCxDQUFDLENBQUE7SUFDTCxDQUFDO0lBRUQsb0ZBQW9GO0lBRTdFLG9DQUFVLEdBQWpCLFVBQWtCLEtBQVc7UUFDekIsSUFBSSxhQUFhLEdBQVksS0FBSyxJQUFJLEtBQUssQ0FBQyxTQUFTLENBQUM7UUFDdEQsSUFBSSxZQUFZLEdBQVksS0FBSyxJQUFJLEtBQUssQ0FBQyxRQUFRLENBQUM7UUFFcEQsSUFBSSxhQUFhO1lBQUUsSUFBSSxDQUFDLFlBQVksQ0FBQyxLQUFLLENBQUMsU0FBUyxDQUFDLENBQUM7UUFDdEQsSUFBSSxZQUFZO1lBQUUsS0FBSyxDQUFDLFFBQVEsRUFBRSxDQUFDO1FBRW5DLElBQUksQ0FBQyxlQUFlLENBQUMsSUFBSSxDQUFDLFFBQVEsRUFBRSxLQUFLLEVBQUUsYUFBYSxJQUFJLFlBQVksQ0FBQyxDQUFDO1FBRTFFLElBQUksQ0FBQyxnQkFBZ0IsR0FBRyxJQUFJLENBQUMsWUFBWSxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsQ0FBQztRQUV6RCxJQUFJLENBQUMsVUFBVSxHQUFHLElBQUksQ0FBQyxRQUFRLEtBQUssUUFBUSxJQUFJLElBQUksQ0FBQyxRQUFRLEtBQUssVUFBVSxDQUFDO0lBQ2pGLENBQUM7SUFFTyx5Q0FBZSxHQUF2QixVQUF3QixLQUFhLEVBQUUsS0FBVyxFQUFFLFlBQXNCO1FBQ3RFLFFBQVEsS0FBSyxFQUFFO1lBQ1gsS0FBSyxRQUFRLENBQUM7WUFDZDtnQkFDSSxJQUFJLENBQUMsUUFBUSxHQUFHLFFBQVEsQ0FBQztnQkFDekIsTUFBTTtZQUNWLEtBQUssUUFBUTtnQkFDVCxJQUFJLFFBQVEsR0FBWSxLQUFLLElBQUksS0FBSyxDQUFDLFFBQVEsQ0FBQztnQkFDaEQsSUFBSSxRQUFRLEVBQUU7b0JBQ1YsSUFBSSxDQUFDLGNBQWMsR0FBRyxLQUFLLENBQUMsUUFBUSxDQUFDO29CQUNyQyxJQUFJLENBQUMsUUFBUSxHQUFHLFVBQVUsQ0FBQztvQkFDM0IsT0FBTztpQkFDVjtnQkFDRCxJQUFJLE1BQU0sR0FBWSxLQUFLLENBQUM7Z0JBQzVCLElBQUksS0FBSyxJQUFJLEtBQUssQ0FBQyxjQUFjLENBQUMsV0FBVyxDQUFDLEVBQUU7b0JBQzVDLE1BQU0sR0FBRyxLQUFLLElBQUksS0FBSyxDQUFDLFNBQVMsQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUM7b0JBQ3ZELElBQUksTUFBTTt3QkFBRSxJQUFJLENBQUMsWUFBWSxHQUFHLEtBQUssQ0FBQyxTQUFTLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO2lCQUNqRTtnQkFDRCxJQUFJLENBQUMsUUFBUSxHQUFHLE1BQU0sQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUM7Z0JBQzdDLE1BQU07WUFDVixLQUFLLFVBQVU7Z0JBQ1gsSUFBSSxDQUFDLFFBQVEsR0FBRyxZQUFZLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDO2dCQUNuRCxJQUFJLENBQUMsY0FBYyxHQUFHLElBQUksQ0FBQyxRQUFRLENBQUM7Z0JBQ3BDLE1BQU07WUFDVixLQUFLLFFBQVE7Z0JBQ1QsSUFBSSxDQUFDLGlCQUFpQixDQUFDLGVBQWUsQ0FBQyxPQUFPLENBQUMsQ0FBQztnQkFDaEQsSUFBSSxDQUFDLFFBQVEsR0FBRyxRQUFRLENBQUM7Z0JBQ3pCLElBQUksQ0FBQyxZQUFZLEdBQUcsT0FBTyxDQUFDO2dCQUM1QixNQUFNO1NBQ2I7SUFDTCxDQUFDO0lBRU8sc0NBQVksR0FBcEIsVUFBcUIsVUFBa0I7UUFFbkMsZ0NBQWdDO1FBQ2hDLElBQUksWUFBWSxHQUFHLFVBQVUsQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLENBQUM7UUFFekMsSUFBSSxZQUFZLENBQUMsQ0FBQyxDQUFDLEtBQUssTUFBTSxJQUFJLFlBQVksQ0FBQyxDQUFDLENBQUMsS0FBSyxPQUFPLEVBQUU7WUFDM0QsSUFBSSxDQUFDLGlCQUFpQixDQUFDLGdCQUFnQixDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLENBQUM7WUFDN0QsT0FBTztTQUNWO1FBRUQsSUFBSSxZQUFZLENBQUMsQ0FBQyxDQUFDLEtBQUssUUFBUTtZQUFFLE9BQU87UUFFekMsSUFBSSxJQUFJLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxJQUFJO1lBQUUsSUFBSSxDQUFDLFNBQVMsR0FBRyxJQUFJLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLEtBQUssRUFBRSxHQUFHLENBQUMsQ0FBQztRQUV4RixJQUFJLFlBQVksQ0FBQyxDQUFDLENBQUMsS0FBSyxPQUFPLEVBQUU7WUFDN0IsSUFBSSxDQUFDLFdBQVcsR0FBRyxJQUFJLENBQUM7U0FDM0I7YUFBTTtZQUNILElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxZQUFZLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUMsY0FBSyxDQUFDLENBQUMsQ0FBQztTQUM1RDtJQUNMLENBQUM7SUFFTywwQ0FBZ0IsR0FBeEIsVUFBeUIsVUFBa0IsRUFBRSxRQUF1QixFQUFFLHFCQUFxQztRQUEzRyxpQkFtREM7UUFuRDRDLHlCQUFBLEVBQUEsYUFBdUI7UUFBRSxzQ0FBQSxFQUFBLDRCQUFxQztRQUN2RyxPQUFPLElBQUksVUFBVSxDQUFTLFVBQUMsU0FBMkI7WUFDdEQsSUFBSSxDQUFDLEtBQUksQ0FBQyxPQUFPLENBQUMsa0JBQWtCLEVBQUUsRUFBRTtnQkFDcEMsS0FBSSxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsS0FBSSxDQUFDLE9BQU8sQ0FBQyxlQUFlLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQztnQkFDN0QsU0FBUyxDQUFDLEtBQUssQ0FBQyxLQUFJLENBQUMsT0FBTyxDQUFDLGVBQWUsQ0FBQyxVQUFVLENBQUMsQ0FBQyxDQUFDO2dCQUMxRCxTQUFTLENBQUMsUUFBUSxFQUFFLENBQUM7YUFDeEI7aUJBQU07Z0JBQ0gsaUVBQWlFO2dCQUNqRSxLQUFJLENBQUMsdUJBQXVCLEdBQUcsTUFBTSxDQUFDLE1BQU0sQ0FBQyxFQUFFLEVBQUUsS0FBSSxDQUFDLE1BQU0sRUFBRSxFQUFFLEVBQUUsRUFBRSxjQUFjLEVBQUUsU0FBUyxFQUFFLEtBQUssRUFBRSxXQUFXLEVBQUUsSUFBSSxFQUFFLENBQUMsQ0FBQztnQkFDM0gsS0FBSSxDQUFDLFNBQVMsR0FBRyxJQUFJLENBQUM7Z0JBRXRCLDRDQUE0QztnQkFDNUMsVUFBVSxDQUFDO29CQUNQLHVGQUF1RjtvQkFDdkYsS0FBSSxDQUFDLGNBQWMsQ0FBQyxhQUFhLENBQUMsS0FBSSxDQUFDLHNCQUFzQixDQUFDLENBQUM7b0JBQy9ELGdEQUFnRDtvQkFDaEQsS0FBSSxDQUFDLHFCQUFxQixHQUFHLEtBQUksQ0FBQyxnQkFBZ0IsQ0FBQztnQkFDdkQsQ0FBQyxDQUFDLENBQUM7Z0JBRUgsSUFBSSxTQUFPLEdBQWEsTUFBTSxDQUFDLE1BQU0sQ0FBQyxFQUFFLEVBQUUsUUFBUSxDQUFDLENBQUM7Z0JBQ3BELElBQUksS0FBSSxDQUFDLFNBQVM7b0JBQUUsU0FBTyxDQUFDLFVBQVUsQ0FBQyxHQUFHLEtBQUksQ0FBQyxTQUFTLENBQUM7Z0JBRXpELFVBQVUsQ0FBQztvQkFDUCxJQUFJLFlBQVksR0FBRyxLQUFJLENBQUMsUUFBUSxDQUFDLGFBQWEsQ0FBQyxhQUFhLENBQUMsR0FBRyxHQUFHLEtBQUksQ0FBQyxtQkFBbUIsR0FBRyxhQUFhLENBQUMsQ0FBQztvQkFFN0csaURBQWlEO29CQUNqRCxLQUFJLENBQUMsaUJBQWlCLENBQUMsV0FBVyxDQUFDLFlBQVksQ0FBQyxDQUFDO29CQUNqRCxJQUFJLHFCQUFxQjt3QkFBRSxLQUFJLENBQUMsaUJBQWlCLENBQUMsa0JBQWtCLENBQUMsWUFBWSxDQUFDLENBQUM7b0JBQ25GLFlBQVksQ0FBQyxLQUFLLENBQUMsTUFBTSxHQUFHLE1BQU0sQ0FBQztvQkFFbkMsU0FBTyxDQUFDLE9BQU8sQ0FBQyxHQUFHLFlBQVksQ0FBQyxxQkFBcUIsRUFBRSxDQUFDLEtBQUssR0FBRyxDQUFDLENBQUM7b0JBQ2xFLFNBQU8sQ0FBQyxRQUFRLENBQUMsR0FBRyxZQUFZLENBQUMscUJBQXFCLEVBQUUsQ0FBQyxNQUFNLEdBQUcsQ0FBQyxDQUFDO29CQUVwRSxJQUFJLE1BQU0sR0FBRyxLQUFJLENBQUMsT0FBTyxDQUFDLGFBQWEsQ0FBQyxZQUFZLEVBQUUsVUFBVSxFQUFFLFNBQU8sQ0FBQyxDQUFDO29CQUUzRSwyREFBMkQ7b0JBQzNELEtBQUksQ0FBQyxTQUFTLEdBQUcsS0FBSyxDQUFDO29CQUN2QixLQUFJLENBQUMscUJBQXFCLEdBQUcsSUFBSSxDQUFDO29CQUVsQyxJQUFJLE1BQU0sRUFBRTt3QkFDUixNQUFNLENBQUMsSUFBSSxDQUFDLFVBQUEsT0FBTzs0QkFDZixTQUFTLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxDQUFDOzRCQUN4QixTQUFTLENBQUMsUUFBUSxFQUFFLENBQUM7d0JBQ3pCLENBQUMsQ0FBQyxDQUFBO3FCQUNMO3lCQUFNO3dCQUNILFNBQVMsQ0FBQyxRQUFRLEVBQUUsQ0FBQztxQkFDeEI7Z0JBQ0wsQ0FBQyxFQUFFLEtBQUksQ0FBQyxjQUFjLENBQUMsQ0FBQzthQUMzQjtRQUNMLENBQUMsQ0FBQyxDQUFDO0lBRVAsQ0FBQzs7Z0JBalFxQixVQUFVO2dCQUNELGtCQUFrQjtnQkFDaEMsaUJBQWlCOztJQWZuQjtRQUFkLEtBQUssQ0FBQyxNQUFNLENBQUM7O2lEQUFrQjtJQUNkO1FBQWpCLEtBQUssQ0FBQyxTQUFTLENBQUM7O29EQUFxQjtJQUNyQjtRQUFoQixLQUFLLENBQUMsUUFBUSxDQUFDOzttREFBc0I7SUFDN0I7UUFBUixLQUFLLEVBQUU7O3VEQUFvQjtJQUNuQjtRQUFSLEtBQUssRUFBRTs7NERBQXlCO0lBQ3hCO1FBQVIsS0FBSyxFQUFFOztnREFBVTtJQUNSO1FBQVQsTUFBTSxFQUFFO2tDQUFtQixZQUFZOzZEQUFzRDtJQUNwRjtRQUFULE1BQU0sRUFBRTtrQ0FBVyxZQUFZO3FEQUE4QjtJQUNwRDtRQUFULE1BQU0sRUFBRTtrQ0FBYSxZQUFZO3VEQUErQjtJQUVwQztRQUE1QixTQUFTLENBQUMsZ0JBQWdCLENBQUM7a0NBQWlCLFFBQVE7MkRBQUM7SUF0RDdDLGVBQWU7UUFsQjNCLFNBQVMsQ0FBQztZQUNQLFFBQVEsRUFBRSxrQkFBa0I7WUFDNUIsNDdFQUE0QztZQUM1QyxhQUFhLEVBQUUsaUJBQWlCLENBQUMsSUFBSTtZQUNyQyxTQUFTLEVBQUUsQ0FBQyxrQkFBa0IsRUFBRSxZQUFZLENBQUM7WUFDN0MsSUFBSSxFQUFFO2dCQUNGLE9BQU8sRUFBRSxtQkFBbUI7YUFDL0I7WUFDRCxVQUFVLEVBQUU7Z0JBQ1IsT0FBTyxDQUFDLFVBQVUsRUFBRTtvQkFDaEIsVUFBVSxDQUFDLFFBQVEsRUFBRTt3QkFDakIsS0FBSyxDQUFDLEVBQUUsU0FBUyxFQUFFLGtCQUFrQixFQUFFLENBQUM7d0JBQ3hDLE9BQU8sQ0FBQyxtQkFBbUIsQ0FBQztxQkFDL0IsQ0FBQztpQkFDTCxDQUFDO2FBQ0w7U0FDSixDQUFDO3lDQTJEd0IsVUFBVTtZQUNELGtCQUFrQjtZQUNoQyxpQkFBaUI7T0EzRHpCLGVBQWUsQ0E0VDNCO0lBQUQsc0JBQUM7Q0FBQSxBQTVURCxJQTRUQztTQTVUWSxlQUFlIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHtcclxuICAgIENvbXBvbmVudCxcclxuICAgIFZpZXdFbmNhcHN1bGF0aW9uLFxyXG4gICAgSW5wdXQsXHJcbiAgICBPbkluaXQsXHJcbiAgICBPdXRwdXQsXHJcbiAgICBPbkNoYW5nZXMsXHJcbiAgICBTaW1wbGVDaGFuZ2VzLFxyXG4gICAgRXZlbnRFbWl0dGVyLFxyXG4gICAgRWxlbWVudFJlZixcclxuICAgIENoYW5nZURldGVjdG9yUmVmLFxyXG4gICAgVmlld0NoaWxkXHJcbn0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XHJcbmltcG9ydCB7IE9ic2VydmFibGUsIE9ic2VydmVyIH0gZnJvbSAncnhqcyc7XHJcbmltcG9ydCB7IHRyaWdnZXIsIHN0eWxlLCB0cmFuc2l0aW9uLCBhbmltYXRlIH0gZnJvbSAnQGFuZ3VsYXIvYW5pbWF0aW9ucyc7XHJcbmltcG9ydCB7IGRlZmF1bHRNZW51QXJyLCBJT3B0aW9ucywgSVRhYmxlRGF0YSwgSVRhYmxlQ29sdW1uIH0gZnJvbSAnLi9rZC1hbmd1bGFyLXZpc3VhbGl6YXRpb24taW50ZXJmYWNlJztcclxuaW1wb3J0IHsgSUNoYXJ0RXhwb3J0LCBJRDNEYXRhLCBJQ2hhcnRDb25maWcsIElNZW51SXRlbSwgSUxlZ2VuZERhdGEsIElDaGFydERhdGEgfSBmcm9tICcuLi9rZC1hbmd1bGFyLWNoYXJ0cy9rZC1hbmd1bGFyLWNoYXJ0cy1pbnRlcmZhY2UnO1xyXG5pbXBvcnQgeyBLZFZpc3VhbGl6YXRpb25TdmMgfSBmcm9tICcuL2tkLWFuZ3VsYXItdmlzdWFsaXphdGlvbi1zdmMnO1xyXG5pbXBvcnQgeyBLZFZpc3VhbGl6YXRpb25FeHBvcnQgfSBmcm9tICcuL2tkLWFuZ3VsYXItdmlzdWFsaXphdGlvbi1leHBvcnQnO1xyXG5pbXBvcnQgeyBLZERvbUVsZW1TdmMgfSBmcm9tICcuLi9rZC1jb21tb24vaW5kZXgnO1xyXG5pbXBvcnQgeyBLZENoYXJ0cyB9IGZyb20gJy4uL2tkLWFuZ3VsYXItY2hhcnRzL2luZGV4JztcclxuXHJcbkBDb21wb25lbnQoe1xyXG4gICAgc2VsZWN0b3I6ICdrZC12aXN1YWxpemF0aW9uJyxcclxuICAgIHRlbXBsYXRlVXJsOiAna2QtYW5ndWxhci12aXN1YWxpemF0aW9uLmh0bWwnLFxyXG4gICAgZW5jYXBzdWxhdGlvbjogVmlld0VuY2Fwc3VsYXRpb24uTm9uZSxcclxuICAgIHByb3ZpZGVyczogW0tkVmlzdWFsaXphdGlvblN2YywgS2REb21FbGVtU3ZjXSxcclxuICAgIGhvc3Q6IHtcclxuICAgICAgICAnY2xhc3MnOiAna2R4LXZpc3VhbGl6YXRpb24nLFxyXG4gICAgfSxcclxuICAgIGFuaW1hdGlvbnM6IFtcclxuICAgICAgICB0cmlnZ2VyKCdpdGVtQW5pbScsIFtcclxuICAgICAgICAgICAgdHJhbnNpdGlvbignOmVudGVyJywgW1xyXG4gICAgICAgICAgICAgICAgc3R5bGUoeyB0cmFuc2Zvcm06ICd0cmFuc2xhdGVZKDEwMCUpJyB9KSxcclxuICAgICAgICAgICAgICAgIGFuaW1hdGUoJzAuMnMgMC4ycyBlYXNlLWluJylcclxuICAgICAgICAgICAgXSksXHJcbiAgICAgICAgXSlcclxuICAgIF1cclxufSlcclxuXHJcbmV4cG9ydCBjbGFzcyBLZFZpc3VhbGl6YXRpb24gaW1wbGVtZW50cyBPbkluaXQsIE9uQ2hhbmdlcyB7XHJcbiAgICAvKiBtZW51ICovXHJcbiAgICBwdWJsaWMgaXNFeHBvcnRFbmFibGVkOiBib29sZWFuID0gZmFsc2U7XHJcbiAgICBwdWJsaWMgaXNNZW51T3BlbjogYm9vbGVhbiA9IGZhbHNlO1xyXG4gICAgcHVibGljIG1lbnVGbGFnOiAnb3BlbmVkJyB8ICdjbG9zZWQnIHwgJ2V4cGFuZGVkJyB8ICd2aWV3ZWQnID0gJ2Nsb3NlZCc7IC8vIGNhbiBiZSAnb3BlbmVkJyB8ICdjbG9zZWQnIHwgJ2V4cGFuZGVkJyB8ICd2aWV3ZWQnXHJcbiAgICBwdWJsaWMgbWVudURpc3BsYXlBcnIgPSBbXTtcclxuICAgIHByaXZhdGUgX21lbnVBcnI6IElNZW51SXRlbVtdID0gW107XHJcblxyXG4gICAgLyogbWVudSBidG4gdmFyaWFibGVzICovXHJcbiAgICBwdWJsaWMgYnRuQWxpZ25tZW50OiBzdHJpbmc7XHJcbiAgICBwdWJsaWMgbWVudUJ0bkljb25DbGFzczogc3RyaW5nID0gJ2ZhLWNoZXZyb24tdXAnO1xyXG4gICAgcHJpdmF0ZSBfbWVudUJ0bkxpc3Q6IHsgY2xvc2VkOiBzdHJpbmcsIG9wZW5lZDogc3RyaW5nLCBleHBhbmRlZDogc3RyaW5nLCB2aWV3ZWQ6IHN0cmluZyB9ID0ge1xyXG4gICAgICAgIGNsb3NlZDogJ2ZhLWNoZXZyb24tdXAnLFxyXG4gICAgICAgIG9wZW5lZDogJ2ZhLWNsb3NlJyxcclxuICAgICAgICB2aWV3ZWQ6ICdmYS1jbG9zZScsXHJcbiAgICAgICAgZXhwYW5kZWQ6ICdmYS1jaGV2cm9uLWxlZnQnXHJcbiAgICB9O1xyXG5cclxuICAgIC8qIGludmlzaWJsZSBjaGFydCAqL1xyXG4gICAgcHVibGljIGV4cG9ydE5vdzogYm9vbGVhbiA9IGZhbHNlO1xyXG4gICAgLyogaW5pdGlhbCBsb2FkIG9mIGludmlzaWJsZSBjaGFydCBzaG91bGQgbm90IHN0YXJ0IGRyYXdpbmcuIG5lZWQgdG8gd2FpdCBmb3Igc2V0TGVnZW5kRGF0YSwgdGhlbiBkcmF3IGluIG9uZSBnbyAqL1xyXG4gICAgcHVibGljIGRhdGFGb3JJbnZpc2libGVDaGFydDogSUQzRGF0YSA9IG51bGw7XHJcbiAgICBwdWJsaWMgY29uZmlnRm9ySW52aXNpYmxlY2hhcnQ6IElDaGFydENvbmZpZyA9IG51bGw7XHJcbiAgICBwdWJsaWMgZGF0YUFmdGVyTWFzc2FnZTogSUQzRGF0YTtcclxuICAgIHB1YmxpYyBsZWdlbmREYXRhQWZ0ZXJNYXNzYWdlOiBhbnk7XHJcbiAgICBwdWJsaWMgaW52aXNpYmxlQ2hhcnRTdHlsZTogb2JqZWN0O1xyXG4gICAgcHVibGljIGludmlzaWJsZUNoYXJ0Q2xhc3M6IHN0cmluZyA9ICdrZHgtdmlzdWFsaXphdGlvbi1jaGFydC1pbnZpc2libGUnO1xyXG4gICAgcHJpdmF0ZSBfZGVmYXVsdENoYXJ0V2lkdGg6IHN0cmluZyA9ICcxMDI0cHgnO1xyXG5cclxuICAgIC8qIHZpZXcgKi9cclxuICAgIHB1YmxpYyBjb250ZW50U3RhdGU6IHN0cmluZyA9ICdjaGFydCc7IC8vIGN1cnJlbnRseSBvbmx5IGhhdmUgY2hhcnQgfCB0YWJsZVxyXG4gICAgcHVibGljIGNvbHVtbkFmdGVyRmlsdGVyOiBJVGFibGVDb2x1bW5bXTtcclxuICAgIHB1YmxpYyBleHBvcnRUYWJsZTogYm9vbGVhbiA9IGZhbHNlO1xyXG4gICAgcHJpdmF0ZSBfZmlsZU5hbWU6IHN0cmluZztcclxuXHJcbiAgICBwcml2YXRlIF90ZW1wU3RhdGU6IHN0cmluZztcclxuXHJcbiAgICAvKipcclxuICAgICAqIEV4cG9ydCBDbGFzc1xyXG4gICAgICogXHJcbiAgICAgKi9cclxuICAgIHByaXZhdGUgX2V4cG9ydDogS2RWaXN1YWxpemF0aW9uRXhwb3J0O1xyXG4gICAgcHJpdmF0ZSBfdGltZW91dFRpbWluZzogbnVtYmVyID0gMTAwMDtcclxuXHJcbiAgICBASW5wdXQoJ2RhdGEnKSBkYXRhOiBJQ2hhcnREYXRhO1xyXG4gICAgQElucHV0KCdyYXdEYXRhJykgcmF3RGF0YTogSVRhYmxlRGF0YTtcclxuICAgIEBJbnB1dCgnY29uZmlnJykgY29uZmlnOiBJQ2hhcnRDb25maWc7XHJcbiAgICBASW5wdXQoKSB4VGhyZXNob2xkOiBudW1iZXI7XHJcbiAgICBASW5wdXQoKSBzZXJpZXNUaHJlc2hvbGQ6IG51bWJlcjtcclxuICAgIEBJbnB1dCgpIGFwaTogYW55O1xyXG4gICAgQE91dHB1dCgpIG91dHB1dExlZ2VuZERhdGE6IEV2ZW50RW1pdHRlcjx7IFtrZXk6IHN0cmluZ106IElMZWdlbmREYXRhIH0+ID0gbmV3IEV2ZW50RW1pdHRlcigpO1xyXG4gICAgQE91dHB1dCgpIGVycm9yTXNnOiBFdmVudEVtaXR0ZXI8c3RyaW5nPiA9IG5ldyBFdmVudEVtaXR0ZXIoKTtcclxuICAgIEBPdXRwdXQoKSBvdXRwdXRBcmVhOiBFdmVudEVtaXR0ZXI8SUQzRGF0YT4gPSBuZXcgRXZlbnRFbWl0dGVyKCk7XHJcblxyXG4gICAgQFZpZXdDaGlsZCgnaW52aXNpYmxlQ2hhcnQnKSBpbnZpc2libGVDaGFydDogS2RDaGFydHM7XHJcblxyXG4gICAgY29uc3RydWN0b3IoXHJcbiAgICAgICAgcHJpdmF0ZSBfZWxlbVJlZjogRWxlbWVudFJlZixcclxuICAgICAgICBwcml2YXRlIF92aXN1YWxpemF0aW9uU3ZjOiBLZFZpc3VhbGl6YXRpb25TdmMsXHJcbiAgICAgICAgcHJpdmF0ZSBjZHI6IENoYW5nZURldGVjdG9yUmVmXHJcbiAgICApIHtcclxuICAgICAgICB0aGlzLl9leHBvcnQgPSBuZXcgS2RWaXN1YWxpemF0aW9uRXhwb3J0KCk7XHJcbiAgICAgICAgdGhpcy5fdmlzdWFsaXphdGlvblN2Yy52aXN1YWxpemF0aW9uRWxlbSA9IHRoaXMuX2VsZW1SZWYubmF0aXZlRWxlbWVudDtcclxuICAgIH1cclxuXHJcbiAgICBuZ09uSW5pdCgpOiB2b2lkIHtcclxuICAgICAgICB0aGlzLl9pbml0QXBpKCk7XHJcbiAgICB9XHJcblxyXG4gICAgbmdPbkNoYW5nZXMoX3NpbXBsZUNoYW5nZXM6IFNpbXBsZUNoYW5nZXMpOiB2b2lkIHtcclxuICAgICAgICBpZiAoX3NpbXBsZUNoYW5nZXMuaGFzT3duUHJvcGVydHkoJ2NvbmZpZycpICYmIF9zaW1wbGVDaGFuZ2VzLmNvbmZpZy5jdXJyZW50VmFsdWUpIHtcclxuICAgICAgICAgICAgdGhpcy5fc2V0Q29uZmlnKF9zaW1wbGVDaGFuZ2VzLmNvbmZpZy5jdXJyZW50VmFsdWUuZXhwb3J0KTtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIGlmIChfc2ltcGxlQ2hhbmdlcy5oYXNPd25Qcm9wZXJ0eSgncmF3RGF0YScpICYmIF9zaW1wbGVDaGFuZ2VzLnJhd0RhdGEuY3VycmVudFZhbHVlKSB7XHJcbiAgICAgICAgICAgIHRoaXMuY29sdW1uQWZ0ZXJGaWx0ZXIgPSB0aGlzLl92aXN1YWxpemF0aW9uU3ZjLmZpbHRlckNvbHVtbnMoX3NpbXBsZUNoYW5nZXMucmF3RGF0YS5jdXJyZW50VmFsdWUuY29sdW1uKTtcclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgcHVibGljIGdldE91dHB1dERhdGEoX2RhdGE6IElEM0RhdGEpOiB2b2lkIHtcclxuICAgICAgICB0aGlzLmRhdGFBZnRlck1hc3NhZ2UgPSBfZGF0YTtcclxuICAgIH1cclxuXHJcbiAgICBwdWJsaWMgZ2V0T3V0cHV0TGVnZW5kRGF0YShfbGVnZW5kRGF0YTogeyBba2V5OiBzdHJpbmddOiBJTGVnZW5kRGF0YSB9KTogdm9pZCB7XHJcbiAgICAgICAgdGhpcy5vdXRwdXRMZWdlbmREYXRhLmVtaXQoX2xlZ2VuZERhdGEpO1xyXG4gICAgICAgIHRoaXMubGVnZW5kRGF0YUFmdGVyTWFzc2FnZSA9IF9sZWdlbmREYXRhO1xyXG4gICAgfVxyXG5cclxuICAgIHB1YmxpYyBzZXRBcmVhKF9kYXRhKTogdm9pZCB7XHJcbiAgICAgICAgdGhpcy5vdXRwdXRBcmVhLmVtaXQoX2RhdGEpO1xyXG4gICAgfVxyXG5cclxuICAgIHB1YmxpYyBvbkV4cG9ydEV4Y2VsUG9zc2libGUoKTogdm9pZCB7XHJcbiAgICAgICAgaWYgKHRoaXMuZXhwb3J0VGFibGUpIHtcclxuICAgICAgICAgICAgdGhpcy5yYXdEYXRhLmFwaS5nZW5lcmFsLmV4cG9ydFRvRXhjZWwoeyBmaWxlTmFtZTogdGhpcy5fZmlsZU5hbWUgfSk7XHJcbiAgICAgICAgICAgIHRoaXMuZXhwb3J0VGFibGUgPSBmYWxzZTtcclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgLy8gPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09IENvbmZpZyA9PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09XHJcblxyXG4gICAgcHJpdmF0ZSBfc2V0Q29uZmlnKF9jb25maWc6IElDaGFydEV4cG9ydCk6IHZvaWQge1xyXG4gICAgICAgIC8vIHdoZW5ldmVyIGNvbmZpZyBjaGFuZ2VzLCBzZXQgYmFjayB0byBkZWZhdWx0IHZhbHVlc1xyXG4gICAgICAgIHRoaXMuY29udGVudFN0YXRlID0gJ2NoYXJ0JztcclxuICAgICAgICB0aGlzLm1lbnVGbGFnID0gJ2Nsb3NlZCc7XHJcbiAgICAgICAgdGhpcy5pc01lbnVPcGVuID0gZmFsc2U7XHJcblxyXG4gICAgICAgIHRoaXMuaXNFeHBvcnRFbmFibGVkID0gX2NvbmZpZyAmJiBfY29uZmlnLmVuYWJsZWQ7XHJcblxyXG4gICAgICAgIGlmICghdGhpcy5pc0V4cG9ydEVuYWJsZWQpIHJldHVybjtcclxuXHJcbiAgICAgICAgdGhpcy5fc2V0SW5pdE1lbnUoX2NvbmZpZy5tZW51KTtcclxuXHJcbiAgICAgICAgdGhpcy5pbnZpc2libGVDaGFydFN0eWxlID0geyAnd2lkdGgnOiBfY29uZmlnLndpZHRoIHx8IHRoaXMuX2RlZmF1bHRDaGFydFdpZHRoIH07XHJcbiAgICAgICAgdGhpcy5idG5BbGlnbm1lbnQgPSB0aGlzLl92aXN1YWxpemF0aW9uU3ZjLmdldEJ0bkFsaWdubWVudChfY29uZmlnLmJ0bik7XHJcblxyXG4gICAgICAgIHRoaXMuX3NldEluaXRCdG5DbGFzcyhfY29uZmlnLmJ0bik7XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfc2V0SW5pdEJ0bkNsYXNzKF9idG5Db25maWc6ICd0b3AtbGVmdCcgfCAndG9wLXJpZ2h0JyB8ICdib3R0b20tbGVmdCcgfCAnYm90dG9tLXJpZ2h0Jyk6IHZvaWQge1xyXG4gICAgICAgIGlmIChfYnRuQ29uZmlnICYmIF9idG5Db25maWcuc3BsaXQoJy0nKVswXSA9PT0gJ3RvcCcpIHtcclxuICAgICAgICAgICAgdGhpcy5tZW51QnRuSWNvbkNsYXNzID0gJ2ZhLWNoZXZyb24tZG93bic7XHJcbiAgICAgICAgICAgIHRoaXMuX21lbnVCdG5MaXN0LmNsb3NlZCA9ICdmYS1jaGV2cm9uLWRvd24nO1xyXG4gICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgIHRoaXMubWVudUJ0bkljb25DbGFzcyA9ICdmYS1jaGV2cm9uLXVwJztcclxuICAgICAgICAgICAgdGhpcy5fbWVudUJ0bkxpc3QuY2xvc2VkID0gJ2ZhLWNoZXZyb24tdXAnO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF9zZXRJbml0TWVudShfbWVudTogSU1lbnVJdGVtW10pOiB2b2lkIHtcclxuICAgICAgICBsZXQgbWVudUFyciA9IHRoaXMuX3Zpc3VhbGl6YXRpb25TdmMuZ2V0SW1tdXRhYmxlTWVudUFycihkZWZhdWx0TWVudUFycik7XHJcblxyXG4gICAgICAgIC8vIHRyYW5zbGF0aW9uQ2FsbGJhY2sgc2hvdWxkIHRha2UgZW5nbGlzaCBzdHJpbmcgYW5kIHJldHVybiB0cmFuc2xhdGVkIHN0cmluZ1xyXG4gICAgICAgIGlmICh0aGlzLmFwaSAmJiB0aGlzLmFwaS5oYXNPd25Qcm9wZXJ0eSgndHJhbnNsYXRpb25DYWxsYmFjaycpKSB7XHJcbiAgICAgICAgICAgIG1lbnVBcnIgPSB0aGlzLl92aXN1YWxpemF0aW9uU3ZjLnNldE1lbnVUcmFuc2xhdGlvbihtZW51QXJyLCB0aGlzLmFwaS50cmFuc2xhdGlvbkNhbGxiYWNrKTtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIHRoaXMuX21lbnVBcnIgPSBtZW51QXJyLmNvbmNhdChfbWVudSB8fCBbXSk7XHJcbiAgICAgICAgaWYgKCF0aGlzLnJhd0RhdGEpIHRoaXMuX21lbnVBcnIgPSB0aGlzLl9tZW51QXJyLmZpbHRlcihpdGVtID0+IGl0ZW0uaWQgIT09ICd2aWV3RGF0YScgJiYgaXRlbS5pZCAhPT0gJ2V4Y2VsJyk7XHJcbiAgICAgICAgdGhpcy5tZW51RGlzcGxheUFyciA9IHRoaXMuX21lbnVBcnI7XHJcbiAgICB9XHJcblxyXG4gICAgLy8gPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09IElOSVQgQVBJIGFuZCBTdWIgPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PVxyXG5cclxuICAgIHByaXZhdGUgX2luaXRBcGkoKSB7XHJcbiAgICAgICAgaWYgKCF0aGlzLmFwaSkgcmV0dXJuO1xyXG5cclxuICAgICAgICB0aGlzLmFwaS5hZGRNZW51SXRlbSA9IChfbWVudUl0ZW1BcnI6IElNZW51SXRlbVtdKTogdm9pZCA9PiB7XHJcbiAgICAgICAgICAgIHRoaXMuX21lbnVBcnIgPSB0aGlzLl9tZW51QXJyLmNvbmNhdChfbWVudUl0ZW1BcnIpO1xyXG4gICAgICAgICAgICB0aGlzLmNkci5kZXRlY3RDaGFuZ2VzKCk7XHJcbiAgICAgICAgfTtcclxuICAgICAgICB0aGlzLmFwaS5oaWRlTWVudUl0ZW1CeUlkID0gKF9pZDogc3RyaW5nLCBfaXNIaWRlOiBib29sZWFuID0gdHJ1ZSk6IHZvaWQgPT4ge1xyXG4gICAgICAgICAgICB0aGlzLl92aXN1YWxpemF0aW9uU3ZjLnNldE1lbnVJdGVtVmlzaWJpbGl0eSgnaWQnLCBfaWQsIF9pc0hpZGUsIHRoaXMuX21lbnVBcnIpO1xyXG4gICAgICAgICAgICB0aGlzLmNkci5kZXRlY3RDaGFuZ2VzKCk7XHJcbiAgICAgICAgfTtcclxuICAgICAgICB0aGlzLmFwaS5oaWRlTWVudUl0ZW1CeUFjdGlvbiA9IChfYWN0aW9uOiBzdHJpbmcsIF9pc0hpZGU6IGJvb2xlYW4gPSB0cnVlKTogdm9pZCA9PiB7XHJcbiAgICAgICAgICAgIHRoaXMuX3Zpc3VhbGl6YXRpb25TdmMuc2V0TWVudUl0ZW1WaXNpYmlsaXR5KCdhY3Rpb24nLCBfYWN0aW9uLCBfaXNIaWRlLCB0aGlzLl9tZW51QXJyKTtcclxuICAgICAgICAgICAgdGhpcy5jZHIuZGV0ZWN0Q2hhbmdlcygpO1xyXG4gICAgICAgIH07XHJcbiAgICAgICAgdGhpcy5hcGkuZ2V0RGF0YVVybCA9IChfc3R5bGU/OiBvYmplY3QsIF9vcHRpb25zPzogSU9wdGlvbnMsIF9pc1JlbW92ZUxlZ2VuZFNjcm9sbD86IGJvb2xlYW4pOiBPYnNlcnZhYmxlPHN0cmluZz4gPT4ge1xyXG4gICAgICAgICAgICByZXR1cm4gbmV3IE9ic2VydmFibGU8c3RyaW5nPigoX29ic2VydmVyOiBPYnNlcnZlcjxzdHJpbmc+KSA9PiB7XHJcbiAgICAgICAgICAgICAgICBsZXQgb3JpZ2luYWxTdHlsZTogb2JqZWN0ID0ge307XHJcbiAgICAgICAgICAgICAgICBpZiAoX3N0eWxlKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgb3JpZ2luYWxTdHlsZSA9IE9iamVjdC5hc3NpZ24oe30sIHRoaXMuaW52aXNpYmxlQ2hhcnRTdHlsZSk7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5pbnZpc2libGVDaGFydFN0eWxlID0gX3N0eWxlO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgdGhpcy5fcHJlcEV4cG9ydENoYXJ0KCdpbWFnZVVybCcsIF9vcHRpb25zLCBfaXNSZW1vdmVMZWdlbmRTY3JvbGwpLnN1YnNjcmliZSgoX3Jlc3BvbnNlKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgaWYoX3N0eWxlKSB0aGlzLmludmlzaWJsZUNoYXJ0U3R5bGUgPSBvcmlnaW5hbFN0eWxlO1xyXG4gICAgICAgICAgICAgICAgICAgIF9vYnNlcnZlci5uZXh0KF9yZXNwb25zZSk7XHJcbiAgICAgICAgICAgICAgICAgICAgX29ic2VydmVyLmNvbXBsZXRlKCk7XHJcbiAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgfTtcclxuXHJcbiAgICAgICAgdGhpcy5hcGkudG9nZ2xlVGFibGUgPSAoX3Nob3dUYWJsZTogYm9vbGVhbiwgcmF3RGF0YTogSVRhYmxlRGF0YSk6IHZvaWQgPT4ge1xyXG4gICAgICAgICAgICByYXdEYXRhLmNvbmZpZyA9IE9iamVjdC5hc3NpZ24oe30sIHRoaXMucmF3RGF0YS5jb25maWcsIHJhd0RhdGEuY29uZmlnKTtcclxuICAgICAgICAgICAgdGhpcy5yYXdEYXRhID0gT2JqZWN0LmFzc2lnbih7fSwgcmF3RGF0YSk7XHJcbiAgICAgICAgICAgIHRoaXMuY29sdW1uQWZ0ZXJGaWx0ZXIgPSB0aGlzLl92aXN1YWxpemF0aW9uU3ZjLmZpbHRlckNvbHVtbnMocmF3RGF0YS5jb2x1bW4pO1xyXG4gICAgICAgICAgICBpZiAoX3Nob3dUYWJsZSkge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5fdGVtcFN0YXRlID0gdGhpcy5jb250ZW50U3RhdGU7XHJcbiAgICAgICAgICAgICAgICBpZiAodGhpcy5jb250ZW50U3RhdGUgIT09ICd0YWJsZScpIHtcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLmNvbnRlbnRTdGF0ZSA9ICd0YWJsZSc7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5fY2FsbFBsdWdpbnMoJ3ZpZXcudGFibGUnKTtcclxuICAgICAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgICAgICB0aGlzLmlzRXhwb3J0RW5hYmxlZCA9IGZhbHNlO1xyXG4gICAgICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5pc0V4cG9ydEVuYWJsZWQgPSB0eXBlb2YgdGhpcy5jb25maWcgIT09ICd1bmRlZmluZWQnICYmIHRoaXMuY29uZmlnLmV4cG9ydC5lbmFibGVkO1xyXG4gICAgICAgICAgICAgICAgdGhpcy5fdmlzdWFsaXphdGlvblN2Yy5zZXRQYXJlbnRIZWlnaHQoJ2NoYXJ0Jyk7XHJcbiAgICAgICAgICAgICAgICB0aGlzLmNvbnRlbnRTdGF0ZSA9IHRoaXMuX3RlbXBTdGF0ZSA/IHRoaXMuX3RlbXBTdGF0ZSA6ICdjaGFydCc7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgLy8gPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09IE1lbnUgQ2xpY2tlZCA9PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09XHJcblxyXG4gICAgcHVibGljIHRvZ2dsZU1lbnUoX2l0ZW0/OiBhbnkpOiB2b2lkIHtcclxuICAgICAgICBsZXQgaGF2ZU9wZXJhdGlvbjogYm9vbGVhbiA9IF9pdGVtICYmIF9pdGVtLm9wZXJhdGlvbjtcclxuICAgICAgICBsZXQgaGF2ZUNhbGxiYWNrOiBib29sZWFuID0gX2l0ZW0gJiYgX2l0ZW0uY2FsbGJhY2s7XHJcblxyXG4gICAgICAgIGlmIChoYXZlT3BlcmF0aW9uKSB0aGlzLl9jYWxsUGx1Z2lucyhfaXRlbS5vcGVyYXRpb24pO1xyXG4gICAgICAgIGlmIChoYXZlQ2FsbGJhY2spIF9pdGVtLmNhbGxiYWNrKCk7XHJcblxyXG4gICAgICAgIHRoaXMuX3RvZ2dsZU1lbnVGbGFnKHRoaXMubWVudUZsYWcsIF9pdGVtLCBoYXZlT3BlcmF0aW9uIHx8IGhhdmVDYWxsYmFjayk7XHJcblxyXG4gICAgICAgIHRoaXMubWVudUJ0bkljb25DbGFzcyA9IHRoaXMuX21lbnVCdG5MaXN0W3RoaXMubWVudUZsYWddO1xyXG5cclxuICAgICAgICB0aGlzLmlzTWVudU9wZW4gPSB0aGlzLm1lbnVGbGFnID09PSAnb3BlbmVkJyB8fCB0aGlzLm1lbnVGbGFnID09PSAnZXhwYW5kZWQnO1xyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX3RvZ2dsZU1lbnVGbGFnKF9mbGFnOiBzdHJpbmcsIF9pdGVtPzogYW55LCBfY2xvc2VFeHBhbmQ/OiBib29sZWFuKTogdm9pZCB7XHJcbiAgICAgICAgc3dpdGNoIChfZmxhZykge1xyXG4gICAgICAgICAgICBjYXNlICdjbG9zZWQnOlxyXG4gICAgICAgICAgICBkZWZhdWx0OlxyXG4gICAgICAgICAgICAgICAgdGhpcy5tZW51RmxhZyA9ICdvcGVuZWQnO1xyXG4gICAgICAgICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgICAgIGNhc2UgJ29wZW5lZCc6XHJcbiAgICAgICAgICAgICAgICBsZXQgaXNFeHBhbmQ6IGJvb2xlYW4gPSBfaXRlbSAmJiBfaXRlbS5leHBhbmRlZDtcclxuICAgICAgICAgICAgICAgIGlmIChpc0V4cGFuZCkge1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMubWVudURpc3BsYXlBcnIgPSBfaXRlbS5leHBhbmRlZDtcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLm1lbnVGbGFnID0gJ2V4cGFuZGVkJztcclxuICAgICAgICAgICAgICAgICAgICByZXR1cm47XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICBsZXQgaXNWaWV3OiBib29sZWFuID0gZmFsc2U7XHJcbiAgICAgICAgICAgICAgICBpZiAoX2l0ZW0gJiYgX2l0ZW0uaGFzT3duUHJvcGVydHkoJ29wZXJhdGlvbicpKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgaXNWaWV3ID0gX2l0ZW0gJiYgX2l0ZW0ub3BlcmF0aW9uLmluZGV4T2YoJ3ZpZXcnKSA+IC0xO1xyXG4gICAgICAgICAgICAgICAgICAgIGlmIChpc1ZpZXcpIHRoaXMuY29udGVudFN0YXRlID0gX2l0ZW0ub3BlcmF0aW9uLnNwbGl0KCcuJylbMV07XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICB0aGlzLm1lbnVGbGFnID0gaXNWaWV3ID8gJ3ZpZXdlZCcgOiAnY2xvc2VkJztcclxuICAgICAgICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgICAgICBjYXNlICdleHBhbmRlZCc6XHJcbiAgICAgICAgICAgICAgICB0aGlzLm1lbnVGbGFnID0gX2Nsb3NlRXhwYW5kID8gJ2Nsb3NlZCcgOiAnb3BlbmVkJztcclxuICAgICAgICAgICAgICAgIHRoaXMubWVudURpc3BsYXlBcnIgPSB0aGlzLl9tZW51QXJyO1xyXG4gICAgICAgICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgICAgIGNhc2UgJ3ZpZXdlZCc6XHJcbiAgICAgICAgICAgICAgICB0aGlzLl92aXN1YWxpemF0aW9uU3ZjLnNldFBhcmVudEhlaWdodCgnY2hhcnQnKTtcclxuICAgICAgICAgICAgICAgIHRoaXMubWVudUZsYWcgPSAnY2xvc2VkJztcclxuICAgICAgICAgICAgICAgIHRoaXMuY29udGVudFN0YXRlID0gJ2NoYXJ0JztcclxuICAgICAgICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF9jYWxsUGx1Z2lucyhfb3BlcmF0aW9uOiBzdHJpbmcpOiB2b2lkIHtcclxuXHJcbiAgICAgICAgLy8gb3BlcmF0aW9ucyBhcmUgc2VwYXJhdGVkIGJ5IC5cclxuICAgICAgICBsZXQgb3BlcmF0aW9uQXJyID0gX29wZXJhdGlvbi5zcGxpdCgnLicpO1xyXG5cclxuICAgICAgICBpZiAob3BlcmF0aW9uQXJyWzBdID09PSAndmlldycgJiYgb3BlcmF0aW9uQXJyWzFdID09PSAndGFibGUnKSB7XHJcbiAgICAgICAgICAgIHRoaXMuX3Zpc3VhbGl6YXRpb25TdmMucHJvY2Vzc1ZpZXdUYWJsZSh0aGlzLnJhd0RhdGEuY29uZmlnKTtcclxuICAgICAgICAgICAgcmV0dXJuO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgaWYgKG9wZXJhdGlvbkFyclswXSAhPT0gJ2V4cG9ydCcpIHJldHVybjtcclxuXHJcbiAgICAgICAgaWYgKHRoaXMuY29uZmlnLnRpdGxlLnRleHQpIHRoaXMuX2ZpbGVOYW1lID0gdGhpcy5jb25maWcudGl0bGUudGV4dC5yZXBsYWNlKC9cXHMvZywgJ18nKTtcclxuXHJcbiAgICAgICAgaWYgKG9wZXJhdGlvbkFyclsxXSA9PT0gJ2V4Y2VsJykge1xyXG4gICAgICAgICAgICB0aGlzLmV4cG9ydFRhYmxlID0gdHJ1ZTtcclxuICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICB0aGlzLl9wcmVwRXhwb3J0Q2hhcnQob3BlcmF0aW9uQXJyWzFdKS5zdWJzY3JpYmUoKCk9Pnt9KTtcclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfcHJlcEV4cG9ydENoYXJ0KF9vcGVyYXRpb246IHN0cmluZywgX29wdGlvbnM6IElPcHRpb25zID0ge30sIF9pc1JlbW92ZUxlZ2VuZFNjcm9sbDogYm9vbGVhbiA9IHRydWUpOiBPYnNlcnZhYmxlPHN0cmluZz4ge1xyXG4gICAgICAgIHJldHVybiBuZXcgT2JzZXJ2YWJsZTxzdHJpbmc+KChfb2JzZXJ2ZXI6IE9ic2VydmVyPHN0cmluZz4pID0+IHtcclxuICAgICAgICAgICAgaWYgKCF0aGlzLl9leHBvcnQuaXNFeHBvcnRDb21wYXRpYmxlKCkpIHtcclxuICAgICAgICAgICAgICAgIHRoaXMuZXJyb3JNc2cuZW1pdCh0aGlzLl9leHBvcnQuZ2V0RXJyb3JNZXNzYWdlKF9vcGVyYXRpb24pKTtcclxuICAgICAgICAgICAgICAgIF9vYnNlcnZlci5lcnJvcih0aGlzLl9leHBvcnQuZ2V0RXJyb3JNZXNzYWdlKF9vcGVyYXRpb24pKTtcclxuICAgICAgICAgICAgICAgIF9vYnNlcnZlci5jb21wbGV0ZSgpO1xyXG4gICAgICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgLy8gY2hhcnQgZm9yIGV4cG9ydGluZyBzaG91bGQgc2tpcCBtYXNzYWdlIGFuZCBub3QgaGF2ZSBhbmltYXRpb25cclxuICAgICAgICAgICAgICAgIHRoaXMuY29uZmlnRm9ySW52aXNpYmxlY2hhcnQgPSBPYmplY3QuYXNzaWduKHt9LCB0aGlzLmNvbmZpZywgeyBpZDogJ2V4cG9ydC1jaGFydCcsIGFuaW1hdGlvbjogZmFsc2UsIHNraXBNYXNzYWdlOiB0cnVlIH0pO1xyXG4gICAgICAgICAgICAgICAgdGhpcy5leHBvcnROb3cgPSB0cnVlO1xyXG5cclxuICAgICAgICAgICAgICAgIC8vIFZpZXdDaGlsZCByZXF1aXJlcyBzZXRUaW1lb3V0IChBbmd1bGFyIDUpXHJcbiAgICAgICAgICAgICAgICBzZXRUaW1lb3V0KCgpID0+IHtcclxuICAgICAgICAgICAgICAgICAgICAvLyBzZXQgTGVnZW5kIERhdGEgc28gdGhhdCB0aGlzIGluZm8gZG9lcyBub3QgaGF2ZSB0byBiZSByZWdlbmVyYXRlZCBieSBpbnZpc2libGUgY2hhcnRcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLmludmlzaWJsZUNoYXJ0LnNldExlZ2VuZERhdGEodGhpcy5sZWdlbmREYXRhQWZ0ZXJNYXNzYWdlKTtcclxuICAgICAgICAgICAgICAgICAgICAvLyB0cmlnZ2VyIGNoYXJ0IHRvIGRyYXcgb25jZSBsZWdlbmQgZGF0YSBpcyBzZXRcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLmRhdGFGb3JJbnZpc2libGVDaGFydCA9IHRoaXMuZGF0YUFmdGVyTWFzc2FnZTtcclxuICAgICAgICAgICAgICAgIH0pO1xyXG5cclxuICAgICAgICAgICAgICAgIGxldCBvcHRpb25zOiBJT3B0aW9ucyA9IE9iamVjdC5hc3NpZ24oe30sIF9vcHRpb25zKTtcclxuICAgICAgICAgICAgICAgIGlmICh0aGlzLl9maWxlTmFtZSkgb3B0aW9uc1snZmlsZU5hbWUnXSA9IHRoaXMuX2ZpbGVOYW1lO1xyXG5cclxuICAgICAgICAgICAgICAgIHNldFRpbWVvdXQoKCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgIGxldCBjaGFydEVsZW1lbnQgPSB0aGlzLl9lbGVtUmVmLm5hdGl2ZUVsZW1lbnQucXVlcnlTZWxlY3RvcignLicgKyB0aGlzLmludmlzaWJsZUNoYXJ0Q2xhc3MgKyAnLmtkeC1jaGFydHMnKTtcclxuXHJcbiAgICAgICAgICAgICAgICAgICAgLy8gYmVmb3JlIGV4cG9ydGluZywgdGhlIGh0bWwgbmVlZHMgdG8gYmUgY2hhbmdlZFxyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuX3Zpc3VhbGl6YXRpb25TdmMucmVtb3ZlRHVtbXkoY2hhcnRFbGVtZW50KTtcclxuICAgICAgICAgICAgICAgICAgICBpZiAoX2lzUmVtb3ZlTGVnZW5kU2Nyb2xsKSB0aGlzLl92aXN1YWxpemF0aW9uU3ZjLnJlbW92ZUxlZ2VuZFNjcm9sbChjaGFydEVsZW1lbnQpO1xyXG4gICAgICAgICAgICAgICAgICAgIGNoYXJ0RWxlbWVudC5zdHlsZS5oZWlnaHQgPSAnYXV0byc7XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIG9wdGlvbnNbJ3dpZHRoJ10gPSBjaGFydEVsZW1lbnQuZ2V0Qm91bmRpbmdDbGllbnRSZWN0KCkud2lkdGggKyAxO1xyXG4gICAgICAgICAgICAgICAgICAgIG9wdGlvbnNbJ2hlaWdodCddID0gY2hhcnRFbGVtZW50LmdldEJvdW5kaW5nQ2xpZW50UmVjdCgpLmhlaWdodCArIDE7XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIGxldCByZXN1bHQgPSB0aGlzLl9leHBvcnQuZXhwb3J0RWxlbWVudChjaGFydEVsZW1lbnQsIF9vcGVyYXRpb24sIG9wdGlvbnMpO1xyXG5cclxuICAgICAgICAgICAgICAgICAgICAvLyBvbmNlIGV4cG9ydCBpcyBkb25lLCByZW1vdmUgdGhlIGludmlzaWJsZSBjaGFydCBmcm9tIERPTVxyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuZXhwb3J0Tm93ID0gZmFsc2U7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5kYXRhRm9ySW52aXNpYmxlQ2hhcnQgPSBudWxsO1xyXG5cclxuICAgICAgICAgICAgICAgICAgICBpZiAocmVzdWx0KSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHJlc3VsdC50aGVuKGRhdGFVcmwgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgX29ic2VydmVyLm5leHQoZGF0YVVybCk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBfb2JzZXJ2ZXIuY29tcGxldGUoKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgfSlcclxuICAgICAgICAgICAgICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBfb2JzZXJ2ZXIuY29tcGxldGUoKTtcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICB9LCB0aGlzLl90aW1lb3V0VGltaW5nKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH0pO1xyXG5cclxuICAgIH1cclxuXHJcbn1cclxuIl19