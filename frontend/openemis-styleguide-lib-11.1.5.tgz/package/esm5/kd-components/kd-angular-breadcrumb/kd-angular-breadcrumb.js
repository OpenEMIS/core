import { __decorate, __metadata } from "tslib";
import { Component, Input, ViewEncapsulation, OnInit, OnChanges, AfterViewInit, ViewContainerRef, SimpleChanges, } from '@angular/core';
import { timer, fromEvent } from 'rxjs';
import { debounceTime } from 'rxjs/operators';
import { KdBreadcrumbSvc } from './kd-angular-breadcrumb-svc';
import { KdDomElemSvc } from '../kd-common/index';
var KdBreadcrumb = /** @class */ (function () {
    function KdBreadcrumb(_vcr, _breadcrumbSvc) {
        this._vcr = _vcr;
        this._breadcrumbSvc = _breadcrumbSvc;
        this.breadcrumbResult = [];
    }
    KdBreadcrumb.prototype.ngOnInit = function () {
        var _this = this;
        this.resizeSub = fromEvent(window, 'resize')
            .pipe(debounceTime(500))
            .subscribe(function (e) {
            _this.breadcrumbResult = _this._breadcrumbSvc.renderBreadcrumbView(_this._vcr, _this.breadcrumbConfig);
        });
        this._initApi();
    };
    KdBreadcrumb.prototype.ngOnChanges = function (_simpleChanges) {
        var _this = this;
        if (_simpleChanges.hasOwnProperty('breadcrumbConfig')) {
            timer().subscribe(function () {
                _this.breadcrumbResult = _this._breadcrumbSvc.renderBreadcrumbView(_this._vcr, _this.breadcrumbConfig);
            });
        }
    };
    KdBreadcrumb.prototype.ngAfterViewInit = function () { };
    KdBreadcrumb.prototype._initApi = function () {
        var _this = this;
        if (!this.api)
            return;
        this.api.addBreadcrumb = function (_item) {
            _this.breadcrumbConfig.list.push(_item);
            _this.breadcrumbResult = _this._breadcrumbSvc.renderBreadcrumbView(_this._vcr, _this.breadcrumbConfig);
        };
        this.api.updateBreadcrumb = function (_pos, _item) {
            _this.breadcrumbConfig.list[_pos - 1] = _item;
            _this.breadcrumbResult = _this._breadcrumbSvc.renderBreadcrumbView(_this._vcr, _this.breadcrumbConfig);
        };
        this.api.getBreadcrumbs = function () {
            return _this.breadcrumbConfig;
        };
    };
    KdBreadcrumb.ctorParameters = function () { return [
        { type: ViewContainerRef },
        { type: KdBreadcrumbSvc }
    ]; };
    __decorate([
        Input('config'),
        __metadata("design:type", Object)
    ], KdBreadcrumb.prototype, "breadcrumbConfig", void 0);
    __decorate([
        Input(),
        __metadata("design:type", Object)
    ], KdBreadcrumb.prototype, "api", void 0);
    KdBreadcrumb = __decorate([
        Component({
            selector: 'kd-breadcrumb',
            template: "\n        <ul class=\"breadcrumb panel-breadcrumb\">\n            <ng-template ngFor let-crumb [ngForOf]=\"breadcrumbResult\">\n                <li *ngIf=\"crumb.toEllipsis\">\n                    <i class=\"fa kd-ellipsis ellipsis fa-rotate-90\"></i>\n                </li>\n                <li *ngIf=\"!crumb.toEllipsis\" [class.list-hide]=\"!crumb.toRender\" >\n                    <a  *ngIf=\"crumb.path && crumb.path !== ''\" [routerLink]=\"crumb.path\">\n                        <i *ngIf=\"crumb.icon && crumb.icon !=''\" class=\"{{crumb.icon}}\"></i>\n                        <span *ngIf=\"crumb.name && crumb.name !== ''\">{{crumb.name}}</span>\n                    </a>\n                    <a *ngIf=\"crumb.url && crumb.url !== ''\" [href]=\"crumb.url\">\n                        <i *ngIf=\"crumb.icon && crumb.icon !=''\" class=\"{{crumb.icon}}\"></i>\n                        <span *ngIf=\"crumb.name && crumb.name !== ''\">{{crumb.name}}</span>\n                    </a>\n                    <div *ngIf=\"(!crumb.path || crumb.path=='') && (crumb.url=='' || !crumb.url)\">\n                        <i *ngIf=\"crumb.icon && crumb.icon !=''\" class=\"{{crumb.icon}}\"></i>\n                        <span *ngIf=\"crumb.name && crumb.name !== ''\">{{crumb.name}}</span>\n                    </div>\n                </li>\n            </ng-template>\n        </ul>\n    ",
            encapsulation: ViewEncapsulation.None,
            providers: [KdBreadcrumbSvc, KdDomElemSvc],
            host: { 'class': 'kdx-breadcrumb' }
        }),
        __metadata("design:paramtypes", [ViewContainerRef,
            KdBreadcrumbSvc])
    ], KdBreadcrumb);
    return KdBreadcrumb;
}());
export { KdBreadcrumb };
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoia2QtYW5ndWxhci1icmVhZGNydW1iLmpzIiwic291cmNlUm9vdCI6Im5nOi8vb3BlbmVtaXMtc3R5bGVndWlkZS1saWIvIiwic291cmNlcyI6WyJrZC1jb21wb25lbnRzL2tkLWFuZ3VsYXItYnJlYWRjcnVtYi9rZC1hbmd1bGFyLWJyZWFkY3J1bWIudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IjtBQUFBLE9BQU8sRUFDSCxTQUFTLEVBQ1QsS0FBSyxFQUNMLGlCQUFpQixFQUNqQixNQUFNLEVBQ04sU0FBUyxFQUNULGFBQWEsRUFDYixnQkFBZ0IsRUFDaEIsYUFBYSxHQUNoQixNQUFNLGVBQWUsQ0FBQztBQUN2QixPQUFPLEVBQUUsS0FBSyxFQUFnQixTQUFTLEVBQUUsTUFBTSxNQUFNLENBQUM7QUFDdEQsT0FBTyxFQUFFLFlBQVksRUFBRSxNQUFNLGdCQUFnQixDQUFDO0FBQzlDLE9BQU8sRUFBRSxlQUFlLEVBQUUsTUFBTSw2QkFBNkIsQ0FBQztBQUM5RCxPQUFPLEVBQUUsWUFBWSxFQUFFLE1BQU0sb0JBQW9CLENBQUM7QUFpQ2xEO0lBTUksc0JBQ1ksSUFBc0IsRUFDdEIsY0FBK0I7UUFEL0IsU0FBSSxHQUFKLElBQUksQ0FBa0I7UUFDdEIsbUJBQWMsR0FBZCxjQUFjLENBQWlCO1FBUHBDLHFCQUFnQixHQUErQixFQUFFLENBQUM7SUFRckQsQ0FBQztJQUVMLCtCQUFRLEdBQVI7UUFBQSxpQkFVQztRQVRHLElBQUksQ0FBQyxTQUFTLEdBQUcsU0FBUyxDQUFDLE1BQU0sRUFBRSxRQUFRLENBQUM7YUFDdkMsSUFBSSxDQUNELFlBQVksQ0FBQyxHQUFHLENBQUMsQ0FDcEI7YUFDQSxTQUFTLENBQUMsVUFBQSxDQUFDO1lBQ1IsS0FBSSxDQUFDLGdCQUFnQixHQUFHLEtBQUksQ0FBQyxjQUFjLENBQUMsb0JBQW9CLENBQUMsS0FBSSxDQUFDLElBQUksRUFBRSxLQUFJLENBQUMsZ0JBQWdCLENBQUMsQ0FBQztRQUN2RyxDQUFDLENBQUMsQ0FBQztRQUVQLElBQUksQ0FBQyxRQUFRLEVBQUUsQ0FBQztJQUNwQixDQUFDO0lBRUQsa0NBQVcsR0FBWCxVQUFZLGNBQTZCO1FBQXpDLGlCQU1DO1FBTEcsSUFBSSxjQUFjLENBQUMsY0FBYyxDQUFDLGtCQUFrQixDQUFDLEVBQUU7WUFDbkQsS0FBSyxFQUFFLENBQUMsU0FBUyxDQUFDO2dCQUNkLEtBQUksQ0FBQyxnQkFBZ0IsR0FBRyxLQUFJLENBQUMsY0FBYyxDQUFDLG9CQUFvQixDQUFDLEtBQUksQ0FBQyxJQUFJLEVBQUUsS0FBSSxDQUFDLGdCQUFnQixDQUFDLENBQUM7WUFDdkcsQ0FBQyxDQUFDLENBQUM7U0FDTjtJQUNMLENBQUM7SUFFRCxzQ0FBZSxHQUFmLGNBQTBCLENBQUM7SUFFbkIsK0JBQVEsR0FBaEI7UUFBQSxpQkFnQkM7UUFmRyxJQUFJLENBQUMsSUFBSSxDQUFDLEdBQUc7WUFBRSxPQUFPO1FBRXRCLElBQUksQ0FBQyxHQUFHLENBQUMsYUFBYSxHQUFHLFVBQUMsS0FBa0I7WUFDeEMsS0FBSSxDQUFDLGdCQUFnQixDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLENBQUM7WUFDdkMsS0FBSSxDQUFDLGdCQUFnQixHQUFHLEtBQUksQ0FBQyxjQUFjLENBQUMsb0JBQW9CLENBQUMsS0FBSSxDQUFDLElBQUksRUFBRSxLQUFJLENBQUMsZ0JBQWdCLENBQUMsQ0FBQztRQUN2RyxDQUFDLENBQUM7UUFFRixJQUFJLENBQUMsR0FBRyxDQUFDLGdCQUFnQixHQUFHLFVBQUMsSUFBWSxFQUFFLEtBQWtCO1lBQ3pELEtBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxJQUFJLENBQUMsSUFBSSxHQUFHLENBQUMsQ0FBQyxHQUFHLEtBQUssQ0FBQztZQUM3QyxLQUFJLENBQUMsZ0JBQWdCLEdBQUcsS0FBSSxDQUFDLGNBQWMsQ0FBQyxvQkFBb0IsQ0FBQyxLQUFJLENBQUMsSUFBSSxFQUFFLEtBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDO1FBQ3ZHLENBQUMsQ0FBQztRQUVGLElBQUksQ0FBQyxHQUFHLENBQUMsY0FBYyxHQUFHO1lBQ3RCLE9BQU8sS0FBSSxDQUFDLGdCQUFnQixDQUFDO1FBQ2pDLENBQUMsQ0FBQztJQUNOLENBQUM7O2dCQTFDaUIsZ0JBQWdCO2dCQUNOLGVBQWU7O0lBTDFCO1FBQWhCLEtBQUssQ0FBQyxRQUFRLENBQUM7OzBEQUFxQztJQUM1QztRQUFSLEtBQUssRUFBRTs7NkNBQVU7SUFKVCxZQUFZO1FBOUJ4QixTQUFTLENBQUM7WUFDUCxRQUFRLEVBQUUsZUFBZTtZQUN6QixRQUFRLEVBQUUsbzJDQXNCVDtZQUNELGFBQWEsRUFBRSxpQkFBaUIsQ0FBQyxJQUFJO1lBQ3JDLFNBQVMsRUFBRSxDQUFDLGVBQWUsRUFBRSxZQUFZLENBQUM7WUFDMUMsSUFBSSxFQUFFLEVBQUUsT0FBTyxFQUFFLGdCQUFnQixFQUFFO1NBQ3RDLENBQUM7eUNBU29CLGdCQUFnQjtZQUNOLGVBQWU7T0FSbEMsWUFBWSxDQWtEeEI7SUFBRCxtQkFBQztDQUFBLEFBbERELElBa0RDO1NBbERZLFlBQVkiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQge1xyXG4gICAgQ29tcG9uZW50LFxyXG4gICAgSW5wdXQsXHJcbiAgICBWaWV3RW5jYXBzdWxhdGlvbixcclxuICAgIE9uSW5pdCxcclxuICAgIE9uQ2hhbmdlcyxcclxuICAgIEFmdGVyVmlld0luaXQsXHJcbiAgICBWaWV3Q29udGFpbmVyUmVmLFxyXG4gICAgU2ltcGxlQ2hhbmdlcyxcclxufSBmcm9tICdAYW5ndWxhci9jb3JlJztcclxuaW1wb3J0IHsgdGltZXIsIFN1YnNjcmlwdGlvbiwgZnJvbUV2ZW50IH0gZnJvbSAncnhqcyc7XHJcbmltcG9ydCB7IGRlYm91bmNlVGltZSB9IGZyb20gJ3J4anMvb3BlcmF0b3JzJztcclxuaW1wb3J0IHsgS2RCcmVhZGNydW1iU3ZjIH0gZnJvbSAnLi9rZC1hbmd1bGFyLWJyZWFkY3J1bWItc3ZjJztcclxuaW1wb3J0IHsgS2REb21FbGVtU3ZjIH0gZnJvbSAnLi4va2QtY29tbW9uL2luZGV4JztcclxuaW1wb3J0IHsgSUJyZWFkY3J1bWIsIElCcmVhZGNydW1iSW50ZXJuYWwsIElCcmVhZGNydW1iQ29uZmlnIH0gZnJvbSAnLi9rZC1hbmd1bGFyLWJyZWFkY3J1bWItaW50ZXJmYWNlJztcclxuXHJcbkBDb21wb25lbnQoe1xyXG4gICAgc2VsZWN0b3I6ICdrZC1icmVhZGNydW1iJyxcclxuICAgIHRlbXBsYXRlOiBgXHJcbiAgICAgICAgPHVsIGNsYXNzPVwiYnJlYWRjcnVtYiBwYW5lbC1icmVhZGNydW1iXCI+XHJcbiAgICAgICAgICAgIDxuZy10ZW1wbGF0ZSBuZ0ZvciBsZXQtY3J1bWIgW25nRm9yT2ZdPVwiYnJlYWRjcnVtYlJlc3VsdFwiPlxyXG4gICAgICAgICAgICAgICAgPGxpICpuZ0lmPVwiY3J1bWIudG9FbGxpcHNpc1wiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxpIGNsYXNzPVwiZmEga2QtZWxsaXBzaXMgZWxsaXBzaXMgZmEtcm90YXRlLTkwXCI+PC9pPlxyXG4gICAgICAgICAgICAgICAgPC9saT5cclxuICAgICAgICAgICAgICAgIDxsaSAqbmdJZj1cIiFjcnVtYi50b0VsbGlwc2lzXCIgW2NsYXNzLmxpc3QtaGlkZV09XCIhY3J1bWIudG9SZW5kZXJcIiA+XHJcbiAgICAgICAgICAgICAgICAgICAgPGEgICpuZ0lmPVwiY3J1bWIucGF0aCAmJiBjcnVtYi5wYXRoICE9PSAnJ1wiIFtyb3V0ZXJMaW5rXT1cImNydW1iLnBhdGhcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGkgKm5nSWY9XCJjcnVtYi5pY29uICYmIGNydW1iLmljb24gIT0nJ1wiIGNsYXNzPVwie3tjcnVtYi5pY29ufX1cIj48L2k+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuICpuZ0lmPVwiY3J1bWIubmFtZSAmJiBjcnVtYi5uYW1lICE9PSAnJ1wiPnt7Y3J1bWIubmFtZX19PC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvYT5cclxuICAgICAgICAgICAgICAgICAgICA8YSAqbmdJZj1cImNydW1iLnVybCAmJiBjcnVtYi51cmwgIT09ICcnXCIgW2hyZWZdPVwiY3J1bWIudXJsXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxpICpuZ0lmPVwiY3J1bWIuaWNvbiAmJiBjcnVtYi5pY29uICE9JydcIiBjbGFzcz1cInt7Y3J1bWIuaWNvbn19XCI+PC9pPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiAqbmdJZj1cImNydW1iLm5hbWUgJiYgY3J1bWIubmFtZSAhPT0gJydcIj57e2NydW1iLm5hbWV9fTwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICA8L2E+XHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiAqbmdJZj1cIighY3J1bWIucGF0aCB8fCBjcnVtYi5wYXRoPT0nJykgJiYgKGNydW1iLnVybD09JycgfHwgIWNydW1iLnVybClcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGkgKm5nSWY9XCJjcnVtYi5pY29uICYmIGNydW1iLmljb24gIT0nJ1wiIGNsYXNzPVwie3tjcnVtYi5pY29ufX1cIj48L2k+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuICpuZ0lmPVwiY3J1bWIubmFtZSAmJiBjcnVtYi5uYW1lICE9PSAnJ1wiPnt7Y3J1bWIubmFtZX19PC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPC9saT5cclxuICAgICAgICAgICAgPC9uZy10ZW1wbGF0ZT5cclxuICAgICAgICA8L3VsPlxyXG4gICAgYCxcclxuICAgIGVuY2Fwc3VsYXRpb246IFZpZXdFbmNhcHN1bGF0aW9uLk5vbmUsXHJcbiAgICBwcm92aWRlcnM6IFtLZEJyZWFkY3J1bWJTdmMsIEtkRG9tRWxlbVN2Y10sXHJcbiAgICBob3N0OiB7ICdjbGFzcyc6ICdrZHgtYnJlYWRjcnVtYicgfVxyXG59KVxyXG5cclxuZXhwb3J0IGNsYXNzIEtkQnJlYWRjcnVtYiBpbXBsZW1lbnRzIE9uSW5pdCwgT25DaGFuZ2VzLCBBZnRlclZpZXdJbml0IHtcclxuICAgIHB1YmxpYyBicmVhZGNydW1iUmVzdWx0OiBBcnJheTxJQnJlYWRjcnVtYkludGVybmFsPiA9IFtdO1xyXG4gICAgcHJpdmF0ZSByZXNpemVTdWI6IFN1YnNjcmlwdGlvbjtcclxuICAgIEBJbnB1dCgnY29uZmlnJykgYnJlYWRjcnVtYkNvbmZpZzogSUJyZWFkY3J1bWJDb25maWc7XHJcbiAgICBASW5wdXQoKSBhcGk6IGFueTtcclxuXHJcbiAgICBjb25zdHJ1Y3RvcihcclxuICAgICAgICBwcml2YXRlIF92Y3I6IFZpZXdDb250YWluZXJSZWYsXHJcbiAgICAgICAgcHJpdmF0ZSBfYnJlYWRjcnVtYlN2YzogS2RCcmVhZGNydW1iU3ZjXHJcbiAgICApIHsgfVxyXG5cclxuICAgIG5nT25Jbml0KCk6IHZvaWQge1xyXG4gICAgICAgIHRoaXMucmVzaXplU3ViID0gZnJvbUV2ZW50KHdpbmRvdywgJ3Jlc2l6ZScpXHJcbiAgICAgICAgICAgIC5waXBlKFxyXG4gICAgICAgICAgICAgICAgZGVib3VuY2VUaW1lKDUwMClcclxuICAgICAgICAgICAgKVxyXG4gICAgICAgICAgICAuc3Vic2NyaWJlKGUgPT4ge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5icmVhZGNydW1iUmVzdWx0ID0gdGhpcy5fYnJlYWRjcnVtYlN2Yy5yZW5kZXJCcmVhZGNydW1iVmlldyh0aGlzLl92Y3IsIHRoaXMuYnJlYWRjcnVtYkNvbmZpZyk7XHJcbiAgICAgICAgICAgIH0pO1xyXG5cclxuICAgICAgICB0aGlzLl9pbml0QXBpKCk7XHJcbiAgICB9XHJcblxyXG4gICAgbmdPbkNoYW5nZXMoX3NpbXBsZUNoYW5nZXM6IFNpbXBsZUNoYW5nZXMpOiB2b2lkIHtcclxuICAgICAgICBpZiAoX3NpbXBsZUNoYW5nZXMuaGFzT3duUHJvcGVydHkoJ2JyZWFkY3J1bWJDb25maWcnKSkge1xyXG4gICAgICAgICAgICB0aW1lcigpLnN1YnNjcmliZSgoKTogdm9pZCA9PiB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLmJyZWFkY3J1bWJSZXN1bHQgPSB0aGlzLl9icmVhZGNydW1iU3ZjLnJlbmRlckJyZWFkY3J1bWJWaWV3KHRoaXMuX3ZjciwgdGhpcy5icmVhZGNydW1iQ29uZmlnKTtcclxuICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIG5nQWZ0ZXJWaWV3SW5pdCgpOiB2b2lkIHsgfVxyXG5cclxuICAgIHByaXZhdGUgX2luaXRBcGkoKTogdm9pZCB7XHJcbiAgICAgICAgaWYgKCF0aGlzLmFwaSkgcmV0dXJuO1xyXG5cclxuICAgICAgICB0aGlzLmFwaS5hZGRCcmVhZGNydW1iID0gKF9pdGVtOiBJQnJlYWRjcnVtYikgPT4ge1xyXG4gICAgICAgICAgICB0aGlzLmJyZWFkY3J1bWJDb25maWcubGlzdC5wdXNoKF9pdGVtKTtcclxuICAgICAgICAgICAgdGhpcy5icmVhZGNydW1iUmVzdWx0ID0gdGhpcy5fYnJlYWRjcnVtYlN2Yy5yZW5kZXJCcmVhZGNydW1iVmlldyh0aGlzLl92Y3IsIHRoaXMuYnJlYWRjcnVtYkNvbmZpZyk7XHJcbiAgICAgICAgfTtcclxuXHJcbiAgICAgICAgdGhpcy5hcGkudXBkYXRlQnJlYWRjcnVtYiA9IChfcG9zOiBudW1iZXIsIF9pdGVtOiBJQnJlYWRjcnVtYikgPT4ge1xyXG4gICAgICAgICAgICB0aGlzLmJyZWFkY3J1bWJDb25maWcubGlzdFtfcG9zIC0gMV0gPSBfaXRlbTtcclxuICAgICAgICAgICAgdGhpcy5icmVhZGNydW1iUmVzdWx0ID0gdGhpcy5fYnJlYWRjcnVtYlN2Yy5yZW5kZXJCcmVhZGNydW1iVmlldyh0aGlzLl92Y3IsIHRoaXMuYnJlYWRjcnVtYkNvbmZpZyk7XHJcbiAgICAgICAgfTtcclxuXHJcbiAgICAgICAgdGhpcy5hcGkuZ2V0QnJlYWRjcnVtYnMgPSAoKTogSUJyZWFkY3J1bWJDb25maWcgPT4ge1xyXG4gICAgICAgICAgICByZXR1cm4gdGhpcy5icmVhZGNydW1iQ29uZmlnO1xyXG4gICAgICAgIH07XHJcbiAgICB9XHJcbn1cclxuIl19