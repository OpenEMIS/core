import { __decorate, __metadata } from "tslib";
import { Injectable } from '@angular/core';
import { KdDomElemSvc } from '../kd-common/index';
// import { timer } from 'rxjs/observable/timer';
var KdBreadcrumbSvc = /** @class */ (function () {
    function KdBreadcrumbSvc(_domeSvc) {
        this._domeSvc = _domeSvc;
    }
    /**
     * Returning the list of final breadcrumb which needed to be display.
     */
    KdBreadcrumbSvc.prototype.renderBreadcrumbView = function (_vcr, _breadcrumbConfig) {
        var tempResult = [];
        var elemBreadcrumb = _vcr.element;
        var sortedBreadcrumb = this._sortInitialBreadcrumb(_breadcrumbConfig);
        var elemStyle = window.getComputedStyle(_vcr.element.nativeElement.children[0]);
        var usableWidth = elemBreadcrumb.nativeElement.children[0].clientWidth - parseInt(elemStyle.marginLeft) - parseInt(elemStyle.marginRight);
        var remainWidth = usableWidth;
        if (sortedBreadcrumb.length > 1) {
            for (var i = sortedBreadcrumb.length - 1; i >= 0; i--) {
                var item = sortedBreadcrumb[i];
                var tempHiddenElem = this._domeSvc.createElement(elemBreadcrumb.nativeElement, 'temp-elem', 'div');
                var tempHE_icon = void 0;
                var tempHE_span = void 0;
                if (i === 0) { // when is the fist item of the breadcrumb
                    this._domeSvc.addClass(tempHiddenElem, 'first-item');
                }
                if (typeof item.name !== 'undefined') {
                    tempHE_span = this._domeSvc.createElement(tempHiddenElem, null, 'span');
                    tempHE_span.innerHTML = item.name;
                }
                if (typeof item.icon !== 'undefined') {
                    tempHE_icon = this._domeSvc.createElement(tempHiddenElem, item.icon, 'i');
                }
                var tempBoundingRect = tempHiddenElem.getBoundingClientRect();
                if (remainWidth - tempBoundingRect.width >= 0) {
                    sortedBreadcrumb[i].toRender = true;
                    tempResult.push(sortedBreadcrumb[i]);
                    remainWidth -= tempBoundingRect.width;
                    tempHiddenElem.remove();
                }
                else {
                    tempResult.push({ toEllipsis: true });
                    tempHiddenElem.remove();
                    break;
                }
            }
        }
        return tempResult.reverse();
    };
    // assign config to _result function
    KdBreadcrumbSvc.prototype._sortInitialBreadcrumb = function (_breadcrumb) {
        var updatedResult = [];
        updatedResult.push(this._getFormattedBreadcrumb(this._sortHome(_breadcrumb.home)));
        if (typeof _breadcrumb !== 'undefined') {
            // sort list function if list is defined
            if (typeof _breadcrumb.list !== 'undefined') {
                for (var i = 0; i < _breadcrumb.list.length; i++) {
                    updatedResult.push(this._getFormattedBreadcrumb(this._sortList(_breadcrumb.list[i])));
                }
            }
            // sort last item list url and path to ''
            var _lastResultIndex = updatedResult.length - 1;
            this._applyLastBreadcrumbFormat(updatedResult[_lastResultIndex]);
        }
        return updatedResult;
    };
    KdBreadcrumbSvc.prototype._sortHome = function (_item) {
        var tempHomeItem = _item;
        var defaultBreadcrumb = { name: '', icon: 'fa fa-home', url: '', path: 'home', toRender: true, toEllipsis: false };
        if (typeof tempHomeItem === 'undefined') {
            return defaultBreadcrumb;
        }
        else {
            tempHomeItem.toEllipsis = false;
            // no icon/name or no path
            if ((typeof tempHomeItem.name === 'undefined' && typeof tempHomeItem.icon === 'undefined') || typeof tempHomeItem.path === 'undefined') {
                var _assign = Object.assign({}, defaultBreadcrumb, tempHomeItem);
                return _assign;
            }
            else {
                return tempHomeItem;
            }
        }
    };
    KdBreadcrumbSvc.prototype._sortList = function (_itemList) {
        var tempItemList = Object.assign({}, _itemList);
        // if name and icon is not defined for the specified list
        if (typeof tempItemList.name === 'undefined' && typeof tempItemList.icon === 'undefined') {
            var defaultBreadcrumb = { name: 'undefined', icon: '', url: '', path: '', toRender: true };
            var assign = Object.assign({}, defaultBreadcrumb, tempItemList);
            return assign;
        }
        // use user config list
        else {
            return tempItemList;
        }
    };
    KdBreadcrumbSvc.prototype._getFormattedBreadcrumb = function (_item) {
        var tempItemList = Object.assign({}, _item);
        // if both url and path is defined in the item list, set url to none
        if (typeof tempItemList.url !== 'undefined' && typeof tempItemList.path !== 'undefined') {
            tempItemList.url = '';
        }
        // add toRender property to itemlist and set to true
        tempItemList.toRender = true;
        return tempItemList;
    };
    KdBreadcrumbSvc.prototype._applyLastBreadcrumbFormat = function (_lastBreadcrumb) {
        // set url and path to none if either of both is defined in the last item
        if (typeof _lastBreadcrumb.url !== 'undefined' || typeof _lastBreadcrumb.path !== 'undefined') {
            _lastBreadcrumb.url = '';
            _lastBreadcrumb.path = '';
        }
    };
    KdBreadcrumbSvc.ctorParameters = function () { return [
        { type: KdDomElemSvc }
    ]; };
    KdBreadcrumbSvc = __decorate([
        Injectable(),
        __metadata("design:paramtypes", [KdDomElemSvc])
    ], KdBreadcrumbSvc);
    return KdBreadcrumbSvc;
}());
export { KdBreadcrumbSvc };
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoia2QtYW5ndWxhci1icmVhZGNydW1iLXN2Yy5qcyIsInNvdXJjZVJvb3QiOiJuZzovL29wZW5lbWlzLXN0eWxlZ3VpZGUtbGliLyIsInNvdXJjZXMiOlsia2QtY29tcG9uZW50cy9rZC1hbmd1bGFyLWJyZWFkY3J1bWIva2QtYW5ndWxhci1icmVhZGNydW1iLXN2Yy50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiO0FBQUEsT0FBTyxFQUFFLFVBQVUsRUFBZ0MsTUFBTSxlQUFlLENBQUM7QUFFekUsT0FBTyxFQUFFLFlBQVksRUFBRSxNQUFNLG9CQUFvQixDQUFDO0FBQ2xELGlEQUFpRDtBQUdqRDtJQUVJLHlCQUFvQixRQUFzQjtRQUF0QixhQUFRLEdBQVIsUUFBUSxDQUFjO0lBQUksQ0FBQztJQUUvQzs7T0FFRztJQUNJLDhDQUFvQixHQUEzQixVQUE0QixJQUFzQixFQUFFLGlCQUFvQztRQUNwRixJQUFJLFVBQVUsR0FBZSxFQUFFLENBQUM7UUFDaEMsSUFBSSxjQUFjLEdBQWUsSUFBSSxDQUFDLE9BQU8sQ0FBQztRQUM5QyxJQUFJLGdCQUFnQixHQUErQixJQUFJLENBQUMsc0JBQXNCLENBQUMsaUJBQWlCLENBQUMsQ0FBQztRQUNsRyxJQUFJLFNBQVMsR0FBd0IsTUFBTSxDQUFDLGdCQUFnQixDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsYUFBYSxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO1FBQ3JHLElBQUksV0FBVyxHQUFXLGNBQWMsQ0FBQyxhQUFhLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLFdBQVcsR0FBRyxRQUFRLENBQUMsU0FBUyxDQUFDLFVBQVUsQ0FBQyxHQUFHLFFBQVEsQ0FBQyxTQUFTLENBQUMsV0FBVyxDQUFDLENBQUM7UUFFbEosSUFBSSxXQUFXLEdBQVcsV0FBVyxDQUFDO1FBRXRDLElBQUksZ0JBQWdCLENBQUMsTUFBTSxHQUFHLENBQUMsRUFBRTtZQUM3QixLQUFLLElBQUksQ0FBQyxHQUFXLGdCQUFnQixDQUFDLE1BQU0sR0FBRyxDQUFDLEVBQUUsQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRTtnQkFDM0QsSUFBSSxJQUFJLEdBQXdCLGdCQUFnQixDQUFDLENBQUMsQ0FBQyxDQUFDO2dCQUVwRCxJQUFJLGNBQWMsR0FBZ0IsSUFBSSxDQUFDLFFBQVEsQ0FBQyxhQUFhLENBQUMsY0FBYyxDQUFDLGFBQWEsRUFBRSxXQUFXLEVBQUUsS0FBSyxDQUFDLENBQUM7Z0JBQ2hILElBQUksV0FBVyxTQUFhLENBQUM7Z0JBQzdCLElBQUksV0FBVyxTQUFhLENBQUM7Z0JBRTdCLElBQUksQ0FBQyxLQUFLLENBQUMsRUFBRSxFQUFDLDBDQUEwQztvQkFDcEQsSUFBSSxDQUFDLFFBQVEsQ0FBQyxRQUFRLENBQUMsY0FBYyxFQUFFLFlBQVksQ0FBQyxDQUFDO2lCQUN4RDtnQkFFRCxJQUFJLE9BQU8sSUFBSSxDQUFDLElBQUksS0FBSyxXQUFXLEVBQUU7b0JBQ2xDLFdBQVcsR0FBRyxJQUFJLENBQUMsUUFBUSxDQUFDLGFBQWEsQ0FBQyxjQUFjLEVBQUUsSUFBSSxFQUFFLE1BQU0sQ0FBQyxDQUFDO29CQUN4RSxXQUFXLENBQUMsU0FBUyxHQUFHLElBQUksQ0FBQyxJQUFJLENBQUM7aUJBQ3JDO2dCQUVELElBQUksT0FBTyxJQUFJLENBQUMsSUFBSSxLQUFLLFdBQVcsRUFBRTtvQkFDbEMsV0FBVyxHQUFHLElBQUksQ0FBQyxRQUFRLENBQUMsYUFBYSxDQUFDLGNBQWMsRUFBRSxJQUFJLENBQUMsSUFBSSxFQUFFLEdBQUcsQ0FBQyxDQUFDO2lCQUM3RTtnQkFFRCxJQUFJLGdCQUFnQixHQUFlLGNBQWMsQ0FBQyxxQkFBcUIsRUFBRSxDQUFDO2dCQUUxRSxJQUFJLFdBQVcsR0FBRyxnQkFBZ0IsQ0FBQyxLQUFLLElBQUksQ0FBQyxFQUFFO29CQUMzQyxnQkFBZ0IsQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLEdBQUcsSUFBSSxDQUFDO29CQUNwQyxVQUFVLENBQUMsSUFBSSxDQUFDLGdCQUFnQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7b0JBQ3JDLFdBQVcsSUFBSSxnQkFBZ0IsQ0FBQyxLQUFLLENBQUM7b0JBQ3RDLGNBQWMsQ0FBQyxNQUFNLEVBQUUsQ0FBQztpQkFDM0I7cUJBQ0k7b0JBQ0QsVUFBVSxDQUFDLElBQUksQ0FBQyxFQUFFLFVBQVUsRUFBRSxJQUFJLEVBQUUsQ0FBQyxDQUFDO29CQUN0QyxjQUFjLENBQUMsTUFBTSxFQUFFLENBQUM7b0JBQ3hCLE1BQU07aUJBQ1Q7YUFDSjtTQUNKO1FBRUQsT0FBTyxVQUFVLENBQUMsT0FBTyxFQUFFLENBQUM7SUFDaEMsQ0FBQztJQUVELG9DQUFvQztJQUM1QixnREFBc0IsR0FBOUIsVUFBK0IsV0FBOEI7UUFDekQsSUFBSSxhQUFhLEdBQStCLEVBQUUsQ0FBQztRQUVuRCxhQUFhLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyx1QkFBdUIsQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLFdBQVcsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUM7UUFFbkYsSUFBSSxPQUFPLFdBQVcsS0FBSyxXQUFXLEVBQUU7WUFFcEMsd0NBQXdDO1lBQ3hDLElBQUksT0FBTyxXQUFXLENBQUMsSUFBSSxLQUFLLFdBQVcsRUFBRTtnQkFDekMsS0FBSyxJQUFJLENBQUMsR0FBVyxDQUFDLEVBQUUsQ0FBQyxHQUFHLFdBQVcsQ0FBQyxJQUFJLENBQUMsTUFBTSxFQUFFLENBQUMsRUFBRSxFQUFFO29CQUN0RCxhQUFhLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyx1QkFBdUIsQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLFdBQVcsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7aUJBQ3pGO2FBQ0o7WUFFRCx5Q0FBeUM7WUFDekMsSUFBSSxnQkFBZ0IsR0FBRyxhQUFhLENBQUMsTUFBTSxHQUFHLENBQUMsQ0FBQztZQUNoRCxJQUFJLENBQUMsMEJBQTBCLENBQUMsYUFBYSxDQUFDLGdCQUFnQixDQUFDLENBQUMsQ0FBQztTQUNwRTtRQUNELE9BQU8sYUFBYSxDQUFDO0lBQ3pCLENBQUM7SUFFTyxtQ0FBUyxHQUFqQixVQUFrQixLQUEwQjtRQUN4QyxJQUFJLFlBQVksR0FBd0IsS0FBSyxDQUFDO1FBQzlDLElBQUksaUJBQWlCLEdBQVEsRUFBRSxJQUFJLEVBQUUsRUFBRSxFQUFFLElBQUksRUFBRSxZQUFZLEVBQUUsR0FBRyxFQUFFLEVBQUUsRUFBRSxJQUFJLEVBQUUsTUFBTSxFQUFFLFFBQVEsRUFBRSxJQUFJLEVBQUUsVUFBVSxFQUFFLEtBQUssRUFBRSxDQUFDO1FBRXhILElBQUksT0FBTyxZQUFZLEtBQUssV0FBVyxFQUFFO1lBQ3JDLE9BQU8saUJBQWlCLENBQUM7U0FDNUI7YUFDSTtZQUNELFlBQVksQ0FBQyxVQUFVLEdBQUcsS0FBSyxDQUFDO1lBQ2hDLDBCQUEwQjtZQUMxQixJQUFJLENBQUMsT0FBTyxZQUFZLENBQUMsSUFBSSxLQUFLLFdBQVcsSUFBSSxPQUFPLFlBQVksQ0FBQyxJQUFJLEtBQUssV0FBVyxDQUFDLElBQUksT0FBTyxZQUFZLENBQUMsSUFBSSxLQUFLLFdBQVcsRUFBRTtnQkFDcEksSUFBSSxPQUFPLEdBQUcsTUFBTSxDQUFDLE1BQU0sQ0FBQyxFQUFFLEVBQUUsaUJBQWlCLEVBQUUsWUFBWSxDQUFDLENBQUM7Z0JBQ2pFLE9BQU8sT0FBTyxDQUFDO2FBQ2xCO2lCQUNJO2dCQUNELE9BQU8sWUFBWSxDQUFDO2FBQ3ZCO1NBQ0o7SUFDTCxDQUFDO0lBRU8sbUNBQVMsR0FBakIsVUFBa0IsU0FBYztRQUM1QixJQUFJLFlBQVksR0FBUSxNQUFNLENBQUMsTUFBTSxDQUFDLEVBQUUsRUFBRSxTQUFTLENBQUMsQ0FBQztRQUVyRCx5REFBeUQ7UUFDekQsSUFBSSxPQUFPLFlBQVksQ0FBQyxJQUFJLEtBQUssV0FBVyxJQUFJLE9BQU8sWUFBWSxDQUFDLElBQUksS0FBSyxXQUFXLEVBQUU7WUFDdEYsSUFBSSxpQkFBaUIsR0FBUSxFQUFFLElBQUksRUFBRSxXQUFXLEVBQUUsSUFBSSxFQUFFLEVBQUUsRUFBRSxHQUFHLEVBQUUsRUFBRSxFQUFFLElBQUksRUFBRSxFQUFFLEVBQUUsUUFBUSxFQUFFLElBQUksRUFBRSxDQUFDO1lBQ2hHLElBQUksTUFBTSxHQUFRLE1BQU0sQ0FBQyxNQUFNLENBQUMsRUFBRSxFQUFFLGlCQUFpQixFQUFFLFlBQVksQ0FBQyxDQUFDO1lBQ3JFLE9BQU8sTUFBTSxDQUFDO1NBQ2pCO1FBQ0QsdUJBQXVCO2FBQ2xCO1lBQ0QsT0FBTyxZQUFZLENBQUM7U0FDdkI7SUFDTCxDQUFDO0lBRU8saURBQXVCLEdBQS9CLFVBQWdDLEtBQTBCO1FBQ3RELElBQUksWUFBWSxHQUF3QixNQUFNLENBQUMsTUFBTSxDQUFDLEVBQUUsRUFBRSxLQUFLLENBQUMsQ0FBQztRQUVqRSxvRUFBb0U7UUFDcEUsSUFBSSxPQUFPLFlBQVksQ0FBQyxHQUFHLEtBQUssV0FBVyxJQUFJLE9BQU8sWUFBWSxDQUFDLElBQUksS0FBSyxXQUFXLEVBQUU7WUFDckYsWUFBWSxDQUFDLEdBQUcsR0FBRyxFQUFFLENBQUM7U0FDekI7UUFFRCxvREFBb0Q7UUFDcEQsWUFBWSxDQUFDLFFBQVEsR0FBRyxJQUFJLENBQUM7UUFFN0IsT0FBTyxZQUFZLENBQUM7SUFDeEIsQ0FBQztJQUVPLG9EQUEwQixHQUFsQyxVQUFtQyxlQUFvQztRQUNuRSx5RUFBeUU7UUFDekUsSUFBSSxPQUFPLGVBQWUsQ0FBQyxHQUFHLEtBQUssV0FBVyxJQUFJLE9BQU8sZUFBZSxDQUFDLElBQUksS0FBSyxXQUFXLEVBQUU7WUFDM0YsZUFBZSxDQUFDLEdBQUcsR0FBRyxFQUFFLENBQUM7WUFDekIsZUFBZSxDQUFDLElBQUksR0FBRyxFQUFFLENBQUM7U0FDN0I7SUFDTCxDQUFDOztnQkFuSTZCLFlBQVk7O0lBRmpDLGVBQWU7UUFEM0IsVUFBVSxFQUFFO3lDQUdxQixZQUFZO09BRmpDLGVBQWUsQ0FzSTNCO0lBQUQsc0JBQUM7Q0FBQSxBQXRJRCxJQXNJQztTQXRJWSxlQUFlIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgSW5qZWN0YWJsZSwgVmlld0NvbnRhaW5lclJlZiwgRWxlbWVudFJlZiB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xyXG5pbXBvcnQgeyBJQnJlYWRjcnVtYkludGVybmFsLCBJQnJlYWRjcnVtYkNvbmZpZyB9IGZyb20gJy4va2QtYW5ndWxhci1icmVhZGNydW1iLWludGVyZmFjZSc7XHJcbmltcG9ydCB7IEtkRG9tRWxlbVN2YyB9IGZyb20gJy4uL2tkLWNvbW1vbi9pbmRleCc7XHJcbi8vIGltcG9ydCB7IHRpbWVyIH0gZnJvbSAncnhqcy9vYnNlcnZhYmxlL3RpbWVyJztcclxuXHJcbkBJbmplY3RhYmxlKClcclxuZXhwb3J0IGNsYXNzIEtkQnJlYWRjcnVtYlN2YyB7XHJcblxyXG4gICAgY29uc3RydWN0b3IocHJpdmF0ZSBfZG9tZVN2YzogS2REb21FbGVtU3ZjKSB7IH1cclxuXHJcbiAgICAvKipcclxuICAgICAqIFJldHVybmluZyB0aGUgbGlzdCBvZiBmaW5hbCBicmVhZGNydW1iIHdoaWNoIG5lZWRlZCB0byBiZSBkaXNwbGF5LlxyXG4gICAgICovXHJcbiAgICBwdWJsaWMgcmVuZGVyQnJlYWRjcnVtYlZpZXcoX3ZjcjogVmlld0NvbnRhaW5lclJlZiwgX2JyZWFkY3J1bWJDb25maWc6IElCcmVhZGNydW1iQ29uZmlnKTogQXJyYXk8YW55PiB7XHJcbiAgICAgICAgbGV0IHRlbXBSZXN1bHQ6IEFycmF5PGFueT4gPSBbXTtcclxuICAgICAgICBsZXQgZWxlbUJyZWFkY3J1bWI6IEVsZW1lbnRSZWYgPSBfdmNyLmVsZW1lbnQ7XHJcbiAgICAgICAgbGV0IHNvcnRlZEJyZWFkY3J1bWI6IEFycmF5PElCcmVhZGNydW1iSW50ZXJuYWw+ID0gdGhpcy5fc29ydEluaXRpYWxCcmVhZGNydW1iKF9icmVhZGNydW1iQ29uZmlnKTtcclxuICAgICAgICBsZXQgZWxlbVN0eWxlOiBDU1NTdHlsZURlY2xhcmF0aW9uID0gd2luZG93LmdldENvbXB1dGVkU3R5bGUoX3Zjci5lbGVtZW50Lm5hdGl2ZUVsZW1lbnQuY2hpbGRyZW5bMF0pO1xyXG4gICAgICAgIGxldCB1c2FibGVXaWR0aDogbnVtYmVyID0gZWxlbUJyZWFkY3J1bWIubmF0aXZlRWxlbWVudC5jaGlsZHJlblswXS5jbGllbnRXaWR0aCAtIHBhcnNlSW50KGVsZW1TdHlsZS5tYXJnaW5MZWZ0KSAtIHBhcnNlSW50KGVsZW1TdHlsZS5tYXJnaW5SaWdodCk7XHJcblxyXG4gICAgICAgIGxldCByZW1haW5XaWR0aDogbnVtYmVyID0gdXNhYmxlV2lkdGg7XHJcblxyXG4gICAgICAgIGlmIChzb3J0ZWRCcmVhZGNydW1iLmxlbmd0aCA+IDEpIHtcclxuICAgICAgICAgICAgZm9yIChsZXQgaTogbnVtYmVyID0gc29ydGVkQnJlYWRjcnVtYi5sZW5ndGggLSAxOyBpID49IDA7IGktLSkge1xyXG4gICAgICAgICAgICAgICAgbGV0IGl0ZW06IElCcmVhZGNydW1iSW50ZXJuYWwgPSBzb3J0ZWRCcmVhZGNydW1iW2ldO1xyXG5cclxuICAgICAgICAgICAgICAgIGxldCB0ZW1wSGlkZGVuRWxlbTogSFRNTEVsZW1lbnQgPSB0aGlzLl9kb21lU3ZjLmNyZWF0ZUVsZW1lbnQoZWxlbUJyZWFkY3J1bWIubmF0aXZlRWxlbWVudCwgJ3RlbXAtZWxlbScsICdkaXYnKTtcclxuICAgICAgICAgICAgICAgIGxldCB0ZW1wSEVfaWNvbjogSFRNTEVsZW1lbnQ7XHJcbiAgICAgICAgICAgICAgICBsZXQgdGVtcEhFX3NwYW46IEhUTUxFbGVtZW50O1xyXG5cclxuICAgICAgICAgICAgICAgIGlmIChpID09PSAwKSB7Ly8gd2hlbiBpcyB0aGUgZmlzdCBpdGVtIG9mIHRoZSBicmVhZGNydW1iXHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5fZG9tZVN2Yy5hZGRDbGFzcyh0ZW1wSGlkZGVuRWxlbSwgJ2ZpcnN0LWl0ZW0nKTtcclxuICAgICAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgICAgICBpZiAodHlwZW9mIGl0ZW0ubmFtZSAhPT0gJ3VuZGVmaW5lZCcpIHtcclxuICAgICAgICAgICAgICAgICAgICB0ZW1wSEVfc3BhbiA9IHRoaXMuX2RvbWVTdmMuY3JlYXRlRWxlbWVudCh0ZW1wSGlkZGVuRWxlbSwgbnVsbCwgJ3NwYW4nKTtcclxuICAgICAgICAgICAgICAgICAgICB0ZW1wSEVfc3Bhbi5pbm5lckhUTUwgPSBpdGVtLm5hbWU7XHJcbiAgICAgICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICAgICAgaWYgKHR5cGVvZiBpdGVtLmljb24gIT09ICd1bmRlZmluZWQnKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgdGVtcEhFX2ljb24gPSB0aGlzLl9kb21lU3ZjLmNyZWF0ZUVsZW1lbnQodGVtcEhpZGRlbkVsZW0sIGl0ZW0uaWNvbiwgJ2knKTtcclxuICAgICAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgICAgICBsZXQgdGVtcEJvdW5kaW5nUmVjdDogQ2xpZW50UmVjdCA9IHRlbXBIaWRkZW5FbGVtLmdldEJvdW5kaW5nQ2xpZW50UmVjdCgpO1xyXG5cclxuICAgICAgICAgICAgICAgIGlmIChyZW1haW5XaWR0aCAtIHRlbXBCb3VuZGluZ1JlY3Qud2lkdGggPj0gMCkge1xyXG4gICAgICAgICAgICAgICAgICAgIHNvcnRlZEJyZWFkY3J1bWJbaV0udG9SZW5kZXIgPSB0cnVlO1xyXG4gICAgICAgICAgICAgICAgICAgIHRlbXBSZXN1bHQucHVzaChzb3J0ZWRCcmVhZGNydW1iW2ldKTtcclxuICAgICAgICAgICAgICAgICAgICByZW1haW5XaWR0aCAtPSB0ZW1wQm91bmRpbmdSZWN0LndpZHRoO1xyXG4gICAgICAgICAgICAgICAgICAgIHRlbXBIaWRkZW5FbGVtLnJlbW92ZSgpO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgZWxzZSB7XHJcbiAgICAgICAgICAgICAgICAgICAgdGVtcFJlc3VsdC5wdXNoKHsgdG9FbGxpcHNpczogdHJ1ZSB9KTtcclxuICAgICAgICAgICAgICAgICAgICB0ZW1wSGlkZGVuRWxlbS5yZW1vdmUoKTtcclxuICAgICAgICAgICAgICAgICAgICBicmVhaztcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgcmV0dXJuIHRlbXBSZXN1bHQucmV2ZXJzZSgpO1xyXG4gICAgfVxyXG5cclxuICAgIC8vIGFzc2lnbiBjb25maWcgdG8gX3Jlc3VsdCBmdW5jdGlvblxyXG4gICAgcHJpdmF0ZSBfc29ydEluaXRpYWxCcmVhZGNydW1iKF9icmVhZGNydW1iOiBJQnJlYWRjcnVtYkNvbmZpZyk6IEFycmF5PGFueT4ge1xyXG4gICAgICAgIGxldCB1cGRhdGVkUmVzdWx0OiBBcnJheTxJQnJlYWRjcnVtYkludGVybmFsPiA9IFtdO1xyXG5cclxuICAgICAgICB1cGRhdGVkUmVzdWx0LnB1c2godGhpcy5fZ2V0Rm9ybWF0dGVkQnJlYWRjcnVtYih0aGlzLl9zb3J0SG9tZShfYnJlYWRjcnVtYi5ob21lKSkpO1xyXG5cclxuICAgICAgICBpZiAodHlwZW9mIF9icmVhZGNydW1iICE9PSAndW5kZWZpbmVkJykge1xyXG5cclxuICAgICAgICAgICAgLy8gc29ydCBsaXN0IGZ1bmN0aW9uIGlmIGxpc3QgaXMgZGVmaW5lZFxyXG4gICAgICAgICAgICBpZiAodHlwZW9mIF9icmVhZGNydW1iLmxpc3QgIT09ICd1bmRlZmluZWQnKSB7XHJcbiAgICAgICAgICAgICAgICBmb3IgKGxldCBpOiBudW1iZXIgPSAwOyBpIDwgX2JyZWFkY3J1bWIubGlzdC5sZW5ndGg7IGkrKykge1xyXG4gICAgICAgICAgICAgICAgICAgIHVwZGF0ZWRSZXN1bHQucHVzaCh0aGlzLl9nZXRGb3JtYXR0ZWRCcmVhZGNydW1iKHRoaXMuX3NvcnRMaXN0KF9icmVhZGNydW1iLmxpc3RbaV0pKSk7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgIC8vIHNvcnQgbGFzdCBpdGVtIGxpc3QgdXJsIGFuZCBwYXRoIHRvICcnXHJcbiAgICAgICAgICAgIGxldCBfbGFzdFJlc3VsdEluZGV4ID0gdXBkYXRlZFJlc3VsdC5sZW5ndGggLSAxO1xyXG4gICAgICAgICAgICB0aGlzLl9hcHBseUxhc3RCcmVhZGNydW1iRm9ybWF0KHVwZGF0ZWRSZXN1bHRbX2xhc3RSZXN1bHRJbmRleF0pO1xyXG4gICAgICAgIH1cclxuICAgICAgICByZXR1cm4gdXBkYXRlZFJlc3VsdDtcclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF9zb3J0SG9tZShfaXRlbTogSUJyZWFkY3J1bWJJbnRlcm5hbCk6IGFueSB7XHJcbiAgICAgICAgbGV0IHRlbXBIb21lSXRlbTogSUJyZWFkY3J1bWJJbnRlcm5hbCA9IF9pdGVtO1xyXG4gICAgICAgIGxldCBkZWZhdWx0QnJlYWRjcnVtYjogYW55ID0geyBuYW1lOiAnJywgaWNvbjogJ2ZhIGZhLWhvbWUnLCB1cmw6ICcnLCBwYXRoOiAnaG9tZScsIHRvUmVuZGVyOiB0cnVlLCB0b0VsbGlwc2lzOiBmYWxzZSB9O1xyXG5cclxuICAgICAgICBpZiAodHlwZW9mIHRlbXBIb21lSXRlbSA9PT0gJ3VuZGVmaW5lZCcpIHtcclxuICAgICAgICAgICAgcmV0dXJuIGRlZmF1bHRCcmVhZGNydW1iO1xyXG4gICAgICAgIH1cclxuICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgdGVtcEhvbWVJdGVtLnRvRWxsaXBzaXMgPSBmYWxzZTtcclxuICAgICAgICAgICAgLy8gbm8gaWNvbi9uYW1lIG9yIG5vIHBhdGhcclxuICAgICAgICAgICAgaWYgKCh0eXBlb2YgdGVtcEhvbWVJdGVtLm5hbWUgPT09ICd1bmRlZmluZWQnICYmIHR5cGVvZiB0ZW1wSG9tZUl0ZW0uaWNvbiA9PT0gJ3VuZGVmaW5lZCcpIHx8IHR5cGVvZiB0ZW1wSG9tZUl0ZW0ucGF0aCA9PT0gJ3VuZGVmaW5lZCcpIHtcclxuICAgICAgICAgICAgICAgIGxldCBfYXNzaWduID0gT2JqZWN0LmFzc2lnbih7fSwgZGVmYXVsdEJyZWFkY3J1bWIsIHRlbXBIb21lSXRlbSk7XHJcbiAgICAgICAgICAgICAgICByZXR1cm4gX2Fzc2lnbjtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgICAgIHJldHVybiB0ZW1wSG9tZUl0ZW07XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfc29ydExpc3QoX2l0ZW1MaXN0OiBhbnkpOiBhbnkge1xyXG4gICAgICAgIGxldCB0ZW1wSXRlbUxpc3Q6IGFueSA9IE9iamVjdC5hc3NpZ24oe30sIF9pdGVtTGlzdCk7XHJcblxyXG4gICAgICAgIC8vIGlmIG5hbWUgYW5kIGljb24gaXMgbm90IGRlZmluZWQgZm9yIHRoZSBzcGVjaWZpZWQgbGlzdFxyXG4gICAgICAgIGlmICh0eXBlb2YgdGVtcEl0ZW1MaXN0Lm5hbWUgPT09ICd1bmRlZmluZWQnICYmIHR5cGVvZiB0ZW1wSXRlbUxpc3QuaWNvbiA9PT0gJ3VuZGVmaW5lZCcpIHtcclxuICAgICAgICAgICAgbGV0IGRlZmF1bHRCcmVhZGNydW1iOiBhbnkgPSB7IG5hbWU6ICd1bmRlZmluZWQnLCBpY29uOiAnJywgdXJsOiAnJywgcGF0aDogJycsIHRvUmVuZGVyOiB0cnVlIH07XHJcbiAgICAgICAgICAgIGxldCBhc3NpZ246IGFueSA9IE9iamVjdC5hc3NpZ24oe30sIGRlZmF1bHRCcmVhZGNydW1iLCB0ZW1wSXRlbUxpc3QpO1xyXG4gICAgICAgICAgICByZXR1cm4gYXNzaWduO1xyXG4gICAgICAgIH1cclxuICAgICAgICAvLyB1c2UgdXNlciBjb25maWcgbGlzdFxyXG4gICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICByZXR1cm4gdGVtcEl0ZW1MaXN0O1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF9nZXRGb3JtYXR0ZWRCcmVhZGNydW1iKF9pdGVtOiBJQnJlYWRjcnVtYkludGVybmFsKTogSUJyZWFkY3J1bWJJbnRlcm5hbCB7XHJcbiAgICAgICAgbGV0IHRlbXBJdGVtTGlzdDogSUJyZWFkY3J1bWJJbnRlcm5hbCA9IE9iamVjdC5hc3NpZ24oe30sIF9pdGVtKTtcclxuXHJcbiAgICAgICAgLy8gaWYgYm90aCB1cmwgYW5kIHBhdGggaXMgZGVmaW5lZCBpbiB0aGUgaXRlbSBsaXN0LCBzZXQgdXJsIHRvIG5vbmVcclxuICAgICAgICBpZiAodHlwZW9mIHRlbXBJdGVtTGlzdC51cmwgIT09ICd1bmRlZmluZWQnICYmIHR5cGVvZiB0ZW1wSXRlbUxpc3QucGF0aCAhPT0gJ3VuZGVmaW5lZCcpIHtcclxuICAgICAgICAgICAgdGVtcEl0ZW1MaXN0LnVybCA9ICcnO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgLy8gYWRkIHRvUmVuZGVyIHByb3BlcnR5IHRvIGl0ZW1saXN0IGFuZCBzZXQgdG8gdHJ1ZVxyXG4gICAgICAgIHRlbXBJdGVtTGlzdC50b1JlbmRlciA9IHRydWU7XHJcblxyXG4gICAgICAgIHJldHVybiB0ZW1wSXRlbUxpc3Q7XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfYXBwbHlMYXN0QnJlYWRjcnVtYkZvcm1hdChfbGFzdEJyZWFkY3J1bWI6IElCcmVhZGNydW1iSW50ZXJuYWwpOiB2b2lkIHtcclxuICAgICAgICAvLyBzZXQgdXJsIGFuZCBwYXRoIHRvIG5vbmUgaWYgZWl0aGVyIG9mIGJvdGggaXMgZGVmaW5lZCBpbiB0aGUgbGFzdCBpdGVtXHJcbiAgICAgICAgaWYgKHR5cGVvZiBfbGFzdEJyZWFkY3J1bWIudXJsICE9PSAndW5kZWZpbmVkJyB8fCB0eXBlb2YgX2xhc3RCcmVhZGNydW1iLnBhdGggIT09ICd1bmRlZmluZWQnKSB7XHJcbiAgICAgICAgICAgIF9sYXN0QnJlYWRjcnVtYi51cmwgPSAnJztcclxuICAgICAgICAgICAgX2xhc3RCcmVhZGNydW1iLnBhdGggPSAnJztcclxuICAgICAgICB9XHJcbiAgICB9XHJcbn1cclxuIl19