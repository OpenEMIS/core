import { __decorate, __values } from "tslib";
import { Injectable } from '@angular/core';
import * as L from 'leaflet';
import 'leaflet.markercluster';
import 'leaflet.awesome-markers/dist/leaflet.awesome-markers';
var KdMapSvc = /** @class */ (function () {
    function KdMapSvc() {
    }
    KdMapSvc_1 = KdMapSvc;
    KdMapSvc.prototype.setIcon = function (_options) {
        var defaultIcon = {
            icon: 'circle',
            // markerColor: 'purple',
            prefix: 'fa',
            iconColor: 'white',
            // title: 'My Location',
            id: 'kd-map-marker'
        };
        var newIcon = (typeof _options !== 'undefined') ? Object.assign({}, defaultIcon, _options) : defaultIcon;
        return new L.AwesomeMarkers.icon(newIcon);
    };
    KdMapSvc.prototype.populateMarkers = function (_data, _map, _displayType) {
        var e_1, _a;
        var tempmarkers = [];
        var groupCount = 0;
        var tempMarkersLegend = [];
        var tempClusterMarkers = {};
        try {
            for (var _b = __values(Object.keys(_data)), _c = _b.next(); !_c.done; _c = _b.next()) {
                var group = _c.value;
                var grpData = _data[group];
                if (grpData.hasOwnProperty('marker') && grpData.hasOwnProperty('data')) {
                    var selectedMarkerGroupId = (grpData.marker.hasOwnProperty('id')) ? grpData.marker.id : group;
                    for (var i = 0; i < grpData.data.length; i++) {
                        // Preparing all markes informations
                        if (typeof tempmarkers[groupCount] === 'undefined')
                            tempmarkers[groupCount] = [];
                        var latlog = L.latLng(grpData.data[i].lat, grpData.data[i].lng);
                        var iconMarker = this.setIcon(grpData.marker);
                        var newMarker = new L.marker(latlog, { icon: iconMarker });
                        if (grpData.data[i].content) {
                            newMarker.bindPopup(grpData.data[i].content);
                        }
                        newMarker.l = groupCount;
                        tempmarkers[groupCount].push(newMarker);
                        if (typeof tempMarkersLegend[groupCount] === 'undefined') {
                            tempMarkersLegend[groupCount] = {
                                icon: iconMarker.createIcon(),
                                label: grpData.marker.title,
                                id: selectedMarkerGroupId
                            };
                        }
                    }
                    // setting up clustering
                    if (typeof tempmarkers[groupCount] !== 'undefined') {
                        var markerClusterGroupConfig = {
                            maxClusterRadius: 100
                        };
                        if (_displayType === 'group-cluster') {
                            markerClusterGroupConfig.iconCreateFunction = this._iconCreateFunction;
                        }
                        tempClusterMarkers[selectedMarkerGroupId] = new L.MarkerClusterGroup(markerClusterGroupConfig);
                        for (var j = 0; j < tempmarkers[groupCount].length; j++) {
                            tempClusterMarkers[selectedMarkerGroupId].addLayer(tempmarkers[groupCount][j]);
                        }
                        _map.addLayer(tempClusterMarkers[selectedMarkerGroupId]);
                    }
                    groupCount++;
                }
            }
        }
        catch (e_1_1) { e_1 = { error: e_1_1 }; }
        finally {
            try {
                if (_c && !_c.done && (_a = _b.return)) _a.call(_b);
            }
            finally { if (e_1) throw e_1.error; }
        }
        return {
            markersLegend: tempMarkersLegend,
            clusterMarkers: tempClusterMarkers
        };
    };
    KdMapSvc.prototype._iconCreateFunction = function (cluster) {
        var layer = cluster.getAllChildMarkers()[0].l % KdMapSvc_1.colors.length;
        var clusterColor = (cluster.getAllChildMarkers()[0].options.icon.options.hasOwnProperty('markerColor')) ? cluster.getAllChildMarkers()[0].options.icon.options.markerColor : KdMapSvc_1.colors[layer];
        return new L.DivIcon({ html: '<div><span>' + cluster.getChildCount() + '</span></div>', className: 'marker-cluster ' + clusterColor, iconSize: new L.Point(40, 40) });
    };
    KdMapSvc.prototype.getDefaultConfig = function () {
        return {
            mapArea: {
                style: {
                    backgroundColor: '#FFFFFF',
                    fontFamily: 'Arial, Helvetica, sans-serif'
                }
            },
            title: {
                text: '',
                align: 'center'
            },
            subtitle: {
                text: '',
                align: 'center'
            },
            legend: {
                float: false,
                align: 'left',
                verticalAlign: 'bottom',
                layout: 'horizontal',
                title: {
                    text: '',
                    align: 'left'
                },
                item: {
                    style: { color: '#000000' }
                }
            },
            footer: {
                bottomLabel: {
                    text: '',
                    align: 'right'
                },
                footNote: {
                    text: '',
                    align: 'right'
                }
            }
        };
    };
    var KdMapSvc_1;
    KdMapSvc.colors = ['darkred', 'purple', 'orange', 'green', 'blue', 'darkgreen', 'darkblue'];
    KdMapSvc = KdMapSvc_1 = __decorate([
        Injectable()
    ], KdMapSvc);
    return KdMapSvc;
}());
export { KdMapSvc };
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoia2QtYW5ndWxhci1tYXAtc3ZjLmpzIiwic291cmNlUm9vdCI6Im5nOi8vb3BlbmVtaXMtc3R5bGVndWlkZS1saWIvIiwic291cmNlcyI6WyJrZC1jb21wb25lbnRzL2tkLWFuZ3VsYXItbWFwL2tkLWFuZ3VsYXItbWFwLXN2Yy50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiO0FBQUEsT0FBTyxFQUFFLFVBQVUsRUFBRSxNQUFNLGVBQWUsQ0FBQztBQUMzQyxPQUFPLEtBQUssQ0FBQyxNQUFNLFNBQVMsQ0FBQztBQUM3QixPQUFPLHVCQUF1QixDQUFDO0FBQy9CLE9BQU8sc0RBQXNELENBQUM7QUFhOUQ7SUFBQTtJQStIQSxDQUFDO2lCQS9IWSxRQUFRO0lBR1YsMEJBQU8sR0FBZCxVQUFlLFFBQXFCO1FBQ2hDLElBQUksV0FBVyxHQUFRO1lBQ25CLElBQUksRUFBRSxRQUFRO1lBQ2QseUJBQXlCO1lBQ3pCLE1BQU0sRUFBRSxJQUFJO1lBQ1osU0FBUyxFQUFFLE9BQU87WUFDbEIsd0JBQXdCO1lBQ3hCLEVBQUUsRUFBRSxlQUFlO1NBQ3RCLENBQUM7UUFFRixJQUFJLE9BQU8sR0FBZSxDQUFDLE9BQU8sUUFBUSxLQUFLLFdBQVcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLEVBQUUsRUFBRSxXQUFXLEVBQUUsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLFdBQVcsQ0FBQztRQUVySCxPQUFPLElBQUksQ0FBQyxDQUFDLGNBQWMsQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLENBQUM7SUFDOUMsQ0FBQztJQUVNLGtDQUFlLEdBQXRCLFVBQXVCLEtBQVUsRUFBRSxJQUFXLEVBQUUsWUFBb0I7O1FBQ2hFLElBQUksV0FBVyxHQUFlLEVBQUUsQ0FBQztRQUNqQyxJQUFJLFVBQVUsR0FBVyxDQUFDLENBQUM7UUFFM0IsSUFBSSxpQkFBaUIsR0FBZSxFQUFFLENBQUM7UUFDdkMsSUFBSSxrQkFBa0IsR0FBNEMsRUFBRSxDQUFDOztZQUVyRSxLQUFrQixJQUFBLEtBQUEsU0FBQSxNQUFNLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFBLGdCQUFBLDRCQUFFO2dCQUFqQyxJQUFJLEtBQUssV0FBQTtnQkFDVixJQUFJLE9BQU8sR0FBUSxLQUFLLENBQUMsS0FBSyxDQUFDLENBQUM7Z0JBRWhDLElBQUksT0FBTyxDQUFDLGNBQWMsQ0FBQyxRQUFRLENBQUMsSUFBSSxPQUFPLENBQUMsY0FBYyxDQUFDLE1BQU0sQ0FBQyxFQUFFO29CQUNwRSxJQUFJLHFCQUFxQixHQUFXLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxjQUFjLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQztvQkFFdEcsS0FBSyxJQUFJLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxHQUFHLE9BQU8sQ0FBQyxJQUFJLENBQUMsTUFBTSxFQUFFLENBQUMsRUFBRSxFQUFFO3dCQUMxQyxvQ0FBb0M7d0JBQ3BDLElBQUksT0FBTyxXQUFXLENBQUMsVUFBVSxDQUFDLEtBQUssV0FBVzs0QkFBRSxXQUFXLENBQUMsVUFBVSxDQUFDLEdBQUcsRUFBRSxDQUFDO3dCQUVqRixJQUFJLE1BQU0sR0FBaUIsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsRUFBRSxPQUFPLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDO3dCQUM5RSxJQUFJLFVBQVUsR0FBVyxJQUFJLENBQUMsT0FBTyxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsQ0FBQzt3QkFDdEQsSUFBSSxTQUFTLEdBQUcsSUFBSSxDQUFDLENBQUMsTUFBTSxDQUFDLE1BQU0sRUFBRSxFQUFFLElBQUksRUFBRSxVQUFVLEVBQUUsQ0FBQyxDQUFDO3dCQUUzRCxJQUFJLE9BQU8sQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxFQUFFOzRCQUN6QixTQUFTLENBQUMsU0FBUyxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUM7eUJBQ2hEO3dCQUNELFNBQVMsQ0FBQyxDQUFDLEdBQUcsVUFBVSxDQUFDO3dCQUN6QixXQUFXLENBQUMsVUFBVSxDQUFDLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDO3dCQUV4QyxJQUFJLE9BQU8saUJBQWlCLENBQUMsVUFBVSxDQUFDLEtBQUssV0FBVyxFQUFFOzRCQUN0RCxpQkFBaUIsQ0FBQyxVQUFVLENBQUMsR0FBRztnQ0FDNUIsSUFBSSxFQUFFLFVBQVUsQ0FBQyxVQUFVLEVBQUU7Z0NBQzdCLEtBQUssRUFBRSxPQUFPLENBQUMsTUFBTSxDQUFDLEtBQUs7Z0NBQzNCLEVBQUUsRUFBRSxxQkFBcUI7NkJBQzVCLENBQUM7eUJBQ0w7cUJBQ0o7b0JBRUQsd0JBQXdCO29CQUN4QixJQUFJLE9BQU8sV0FBVyxDQUFDLFVBQVUsQ0FBQyxLQUFLLFdBQVcsRUFBRTt3QkFDaEQsSUFBSSx3QkFBd0IsR0FBUTs0QkFDaEMsZ0JBQWdCLEVBQUUsR0FBRzt5QkFDeEIsQ0FBQzt3QkFDRixJQUFJLFlBQVksS0FBSyxlQUFlLEVBQUU7NEJBQ2xDLHdCQUF3QixDQUFDLGtCQUFrQixHQUFHLElBQUksQ0FBQyxtQkFBbUIsQ0FBQzt5QkFDMUU7d0JBQ0Qsa0JBQWtCLENBQUMscUJBQXFCLENBQUMsR0FBRyxJQUFJLENBQUMsQ0FBQyxrQkFBa0IsQ0FBQyx3QkFBd0IsQ0FBQyxDQUFDO3dCQUUvRixLQUFLLElBQUksQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLEdBQUcsV0FBVyxDQUFDLFVBQVUsQ0FBQyxDQUFDLE1BQU0sRUFBRSxDQUFDLEVBQUUsRUFBRTs0QkFDckQsa0JBQWtCLENBQUMscUJBQXFCLENBQUMsQ0FBQyxRQUFRLENBQUMsV0FBVyxDQUFDLFVBQVUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7eUJBQ2xGO3dCQUNELElBQUksQ0FBQyxRQUFRLENBQUMsa0JBQWtCLENBQUMscUJBQXFCLENBQUMsQ0FBQyxDQUFDO3FCQUM1RDtvQkFFRCxVQUFVLEVBQUUsQ0FBQztpQkFDaEI7YUFDSjs7Ozs7Ozs7O1FBRUQsT0FBTztZQUNILGFBQWEsRUFBRSxpQkFBaUI7WUFDaEMsY0FBYyxFQUFFLGtCQUFrQjtTQUNyQyxDQUFDO0lBQ04sQ0FBQztJQUVPLHNDQUFtQixHQUEzQixVQUE0QixPQUFPO1FBQy9CLElBQUksS0FBSyxHQUFXLE9BQU8sQ0FBQyxrQkFBa0IsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxVQUFRLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQztRQUMvRSxJQUFJLFlBQVksR0FBVyxDQUFDLE9BQU8sQ0FBQyxrQkFBa0IsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLGNBQWMsQ0FBQyxhQUFhLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsa0JBQWtCLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDLFVBQVEsQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLENBQUM7UUFDNU0sT0FBTyxJQUFJLENBQUMsQ0FBQyxPQUFPLENBQUMsRUFBRSxJQUFJLEVBQUUsYUFBYSxHQUFHLE9BQU8sQ0FBQyxhQUFhLEVBQUUsR0FBRyxlQUFlLEVBQUUsU0FBUyxFQUFFLGlCQUFpQixHQUFHLFlBQVksRUFBRSxRQUFRLEVBQUUsSUFBSSxDQUFDLENBQUMsS0FBSyxDQUFDLEVBQUUsRUFBRSxFQUFFLENBQUMsRUFBRSxDQUFDLENBQUM7SUFDMUssQ0FBQztJQUVNLG1DQUFnQixHQUF2QjtRQUNJLE9BQU87WUFDSCxPQUFPLEVBQUU7Z0JBQ0wsS0FBSyxFQUFFO29CQUNILGVBQWUsRUFBRSxTQUFTO29CQUMxQixVQUFVLEVBQUUsOEJBQThCO2lCQUM3QzthQUNKO1lBQ0QsS0FBSyxFQUFFO2dCQUNILElBQUksRUFBRSxFQUFFO2dCQUNSLEtBQUssRUFBRSxRQUFRO2FBQ2xCO1lBQ0QsUUFBUSxFQUFFO2dCQUNOLElBQUksRUFBRSxFQUFFO2dCQUNSLEtBQUssRUFBRSxRQUFRO2FBQ2xCO1lBQ0QsTUFBTSxFQUFFO2dCQUNKLEtBQUssRUFBRSxLQUFLO2dCQUNaLEtBQUssRUFBRSxNQUFNO2dCQUNiLGFBQWEsRUFBRSxRQUFRO2dCQUN2QixNQUFNLEVBQUUsWUFBWTtnQkFDcEIsS0FBSyxFQUFFO29CQUNILElBQUksRUFBRSxFQUFFO29CQUNSLEtBQUssRUFBRSxNQUFNO2lCQUNoQjtnQkFDRCxJQUFJLEVBQUU7b0JBQ0YsS0FBSyxFQUFFLEVBQUUsS0FBSyxFQUFFLFNBQVMsRUFBQztpQkFDN0I7YUFDSjtZQUNELE1BQU0sRUFBRTtnQkFDSixXQUFXLEVBQUU7b0JBQ1QsSUFBSSxFQUFFLEVBQUU7b0JBQ1IsS0FBSyxFQUFFLE9BQU87aUJBQ2pCO2dCQUNELFFBQVEsRUFBRTtvQkFDTixJQUFJLEVBQUUsRUFBRTtvQkFDUixLQUFLLEVBQUUsT0FBTztpQkFDakI7YUFDSjtTQUNKLENBQUM7SUFDTixDQUFDOztJQTdIYSxlQUFNLEdBQWtCLENBQUMsU0FBUyxFQUFFLFFBQVEsRUFBRSxRQUFRLEVBQUUsT0FBTyxFQUFFLE1BQU0sRUFBRSxXQUFXLEVBQUUsVUFBVSxDQUFDLENBQUM7SUFEdkcsUUFBUTtRQURwQixVQUFVLEVBQUU7T0FDQSxRQUFRLENBK0hwQjtJQUFELGVBQUM7Q0FBQSxBQS9IRCxJQStIQztTQS9IWSxRQUFRIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgSW5qZWN0YWJsZSB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xyXG5pbXBvcnQgKiBhcyBMIGZyb20gJ2xlYWZsZXQnO1xyXG5pbXBvcnQgJ2xlYWZsZXQubWFya2VyY2x1c3Rlcic7XHJcbmltcG9ydCAnbGVhZmxldC5hd2Vzb21lLW1hcmtlcnMvZGlzdC9sZWFmbGV0LmF3ZXNvbWUtbWFya2Vycyc7XHJcbmltcG9ydCB7XHJcbiAgICBJTWFwUG9zaXRpb24sXHJcbiAgICBJTWFwTWFya2VyLFxyXG4gICAgSU1hcENvbmZpZ1xyXG59IGZyb20gJy4va2QtYW5ndWxhci1tYXAtaW50ZXJmYWNlJztcclxuXHJcbmV4cG9ydCBpbnRlcmZhY2UgSU1hcFBvcHVsYXRlQ2x1c3RlckRhdGEge1xyXG4gICAgbWFya2Vyc0xlZ2VuZDogQXJyYXk8YW55PjtcclxuICAgIGNsdXN0ZXJNYXJrZXJzOiB7IFtrZXk6IHN0cmluZ106IEwuTWFya2VyQ2x1c3Rlckdyb3VwIH07XHJcbn1cclxuXHJcbkBJbmplY3RhYmxlKClcclxuZXhwb3J0IGNsYXNzIEtkTWFwU3ZjIHtcclxuICAgIHB1YmxpYyBzdGF0aWMgY29sb3JzOiBBcnJheTxzdHJpbmc+ID0gWydkYXJrcmVkJywgJ3B1cnBsZScsICdvcmFuZ2UnLCAnZ3JlZW4nLCAnYmx1ZScsICdkYXJrZ3JlZW4nLCAnZGFya2JsdWUnXTtcclxuXHJcbiAgICBwdWJsaWMgc2V0SWNvbihfb3B0aW9ucz86IElNYXBNYXJrZXIpOiBMLkljb24ge1xyXG4gICAgICAgIGxldCBkZWZhdWx0SWNvbjogYW55ID0ge1xyXG4gICAgICAgICAgICBpY29uOiAnY2lyY2xlJyxcclxuICAgICAgICAgICAgLy8gbWFya2VyQ29sb3I6ICdwdXJwbGUnLFxyXG4gICAgICAgICAgICBwcmVmaXg6ICdmYScsXHJcbiAgICAgICAgICAgIGljb25Db2xvcjogJ3doaXRlJyxcclxuICAgICAgICAgICAgLy8gdGl0bGU6ICdNeSBMb2NhdGlvbicsXHJcbiAgICAgICAgICAgIGlkOiAna2QtbWFwLW1hcmtlcidcclxuICAgICAgICB9O1xyXG5cclxuICAgICAgICBsZXQgbmV3SWNvbjogSU1hcE1hcmtlciA9ICh0eXBlb2YgX29wdGlvbnMgIT09ICd1bmRlZmluZWQnKSA/IE9iamVjdC5hc3NpZ24oe30sIGRlZmF1bHRJY29uLCBfb3B0aW9ucykgOiBkZWZhdWx0SWNvbjtcclxuXHJcbiAgICAgICAgcmV0dXJuIG5ldyBMLkF3ZXNvbWVNYXJrZXJzLmljb24obmV3SWNvbik7XHJcbiAgICB9XHJcblxyXG4gICAgcHVibGljIHBvcHVsYXRlTWFya2VycyhfZGF0YTogYW55LCBfbWFwOiBMLk1hcCwgX2Rpc3BsYXlUeXBlOiBzdHJpbmcpOiBJTWFwUG9wdWxhdGVDbHVzdGVyRGF0YSB7XHJcbiAgICAgICAgbGV0IHRlbXBtYXJrZXJzOiBBcnJheTxhbnk+ID0gW107XHJcbiAgICAgICAgbGV0IGdyb3VwQ291bnQ6IG51bWJlciA9IDA7XHJcblxyXG4gICAgICAgIGxldCB0ZW1wTWFya2Vyc0xlZ2VuZDogQXJyYXk8YW55PiA9IFtdO1xyXG4gICAgICAgIGxldCB0ZW1wQ2x1c3Rlck1hcmtlcnM6IHsgW2tleTogc3RyaW5nXTogTC5NYXJrZXJDbHVzdGVyR3JvdXAgfSA9IHt9O1xyXG5cclxuICAgICAgICBmb3IgKGxldCBncm91cCBvZiBPYmplY3Qua2V5cyhfZGF0YSkpIHtcclxuICAgICAgICAgICAgbGV0IGdycERhdGE6IGFueSA9IF9kYXRhW2dyb3VwXTtcclxuXHJcbiAgICAgICAgICAgIGlmIChncnBEYXRhLmhhc093blByb3BlcnR5KCdtYXJrZXInKSAmJiBncnBEYXRhLmhhc093blByb3BlcnR5KCdkYXRhJykpIHtcclxuICAgICAgICAgICAgICAgIGxldCBzZWxlY3RlZE1hcmtlckdyb3VwSWQ6IHN0cmluZyA9IChncnBEYXRhLm1hcmtlci5oYXNPd25Qcm9wZXJ0eSgnaWQnKSkgPyBncnBEYXRhLm1hcmtlci5pZCA6IGdyb3VwO1xyXG5cclxuICAgICAgICAgICAgICAgIGZvciAobGV0IGkgPSAwOyBpIDwgZ3JwRGF0YS5kYXRhLmxlbmd0aDsgaSsrKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgLy8gUHJlcGFyaW5nIGFsbCBtYXJrZXMgaW5mb3JtYXRpb25zXHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKHR5cGVvZiB0ZW1wbWFya2Vyc1tncm91cENvdW50XSA9PT0gJ3VuZGVmaW5lZCcpIHRlbXBtYXJrZXJzW2dyb3VwQ291bnRdID0gW107XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIGxldCBsYXRsb2c6IElNYXBQb3NpdGlvbiA9IEwubGF0TG5nKGdycERhdGEuZGF0YVtpXS5sYXQsIGdycERhdGEuZGF0YVtpXS5sbmcpO1xyXG4gICAgICAgICAgICAgICAgICAgIGxldCBpY29uTWFya2VyOiBMLkljb24gPSB0aGlzLnNldEljb24oZ3JwRGF0YS5tYXJrZXIpO1xyXG4gICAgICAgICAgICAgICAgICAgIGxldCBuZXdNYXJrZXIgPSBuZXcgTC5tYXJrZXIobGF0bG9nLCB7IGljb246IGljb25NYXJrZXIgfSk7XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIGlmIChncnBEYXRhLmRhdGFbaV0uY29udGVudCkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBuZXdNYXJrZXIuYmluZFBvcHVwKGdycERhdGEuZGF0YVtpXS5jb250ZW50KTtcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgbmV3TWFya2VyLmwgPSBncm91cENvdW50O1xyXG4gICAgICAgICAgICAgICAgICAgIHRlbXBtYXJrZXJzW2dyb3VwQ291bnRdLnB1c2gobmV3TWFya2VyKTtcclxuXHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKHR5cGVvZiB0ZW1wTWFya2Vyc0xlZ2VuZFtncm91cENvdW50XSA9PT0gJ3VuZGVmaW5lZCcpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgdGVtcE1hcmtlcnNMZWdlbmRbZ3JvdXBDb3VudF0gPSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpY29uOiBpY29uTWFya2VyLmNyZWF0ZUljb24oKSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxhYmVsOiBncnBEYXRhLm1hcmtlci50aXRsZSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlkOiBzZWxlY3RlZE1hcmtlckdyb3VwSWRcclxuICAgICAgICAgICAgICAgICAgICAgICAgfTtcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICAgICAgLy8gc2V0dGluZyB1cCBjbHVzdGVyaW5nXHJcbiAgICAgICAgICAgICAgICBpZiAodHlwZW9mIHRlbXBtYXJrZXJzW2dyb3VwQ291bnRdICE9PSAndW5kZWZpbmVkJykge1xyXG4gICAgICAgICAgICAgICAgICAgIGxldCBtYXJrZXJDbHVzdGVyR3JvdXBDb25maWc6IGFueSA9IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgbWF4Q2x1c3RlclJhZGl1czogMTAwXHJcbiAgICAgICAgICAgICAgICAgICAgfTtcclxuICAgICAgICAgICAgICAgICAgICBpZiAoX2Rpc3BsYXlUeXBlID09PSAnZ3JvdXAtY2x1c3RlcicpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgbWFya2VyQ2x1c3Rlckdyb3VwQ29uZmlnLmljb25DcmVhdGVGdW5jdGlvbiA9IHRoaXMuX2ljb25DcmVhdGVGdW5jdGlvbjtcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgdGVtcENsdXN0ZXJNYXJrZXJzW3NlbGVjdGVkTWFya2VyR3JvdXBJZF0gPSBuZXcgTC5NYXJrZXJDbHVzdGVyR3JvdXAobWFya2VyQ2x1c3Rlckdyb3VwQ29uZmlnKTtcclxuXHJcbiAgICAgICAgICAgICAgICAgICAgZm9yIChsZXQgaiA9IDA7IGogPCB0ZW1wbWFya2Vyc1tncm91cENvdW50XS5sZW5ndGg7IGorKykge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB0ZW1wQ2x1c3Rlck1hcmtlcnNbc2VsZWN0ZWRNYXJrZXJHcm91cElkXS5hZGRMYXllcih0ZW1wbWFya2Vyc1tncm91cENvdW50XVtqXSk7XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIF9tYXAuYWRkTGF5ZXIodGVtcENsdXN0ZXJNYXJrZXJzW3NlbGVjdGVkTWFya2VyR3JvdXBJZF0pO1xyXG4gICAgICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgICAgIGdyb3VwQ291bnQrKztcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgcmV0dXJuIHtcclxuICAgICAgICAgICAgbWFya2Vyc0xlZ2VuZDogdGVtcE1hcmtlcnNMZWdlbmQsXHJcbiAgICAgICAgICAgIGNsdXN0ZXJNYXJrZXJzOiB0ZW1wQ2x1c3Rlck1hcmtlcnNcclxuICAgICAgICB9O1xyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX2ljb25DcmVhdGVGdW5jdGlvbihjbHVzdGVyKTogTC5EaXZJY29uIHtcclxuICAgICAgICBsZXQgbGF5ZXI6IG51bWJlciA9IGNsdXN0ZXIuZ2V0QWxsQ2hpbGRNYXJrZXJzKClbMF0ubCAlIEtkTWFwU3ZjLmNvbG9ycy5sZW5ndGg7XHJcbiAgICAgICAgbGV0IGNsdXN0ZXJDb2xvcjogc3RyaW5nID0gKGNsdXN0ZXIuZ2V0QWxsQ2hpbGRNYXJrZXJzKClbMF0ub3B0aW9ucy5pY29uLm9wdGlvbnMuaGFzT3duUHJvcGVydHkoJ21hcmtlckNvbG9yJykpID8gY2x1c3Rlci5nZXRBbGxDaGlsZE1hcmtlcnMoKVswXS5vcHRpb25zLmljb24ub3B0aW9ucy5tYXJrZXJDb2xvciA6IEtkTWFwU3ZjLmNvbG9yc1tsYXllcl07XHJcbiAgICAgICAgcmV0dXJuIG5ldyBMLkRpdkljb24oeyBodG1sOiAnPGRpdj48c3Bhbj4nICsgY2x1c3Rlci5nZXRDaGlsZENvdW50KCkgKyAnPC9zcGFuPjwvZGl2PicsIGNsYXNzTmFtZTogJ21hcmtlci1jbHVzdGVyICcgKyBjbHVzdGVyQ29sb3IsIGljb25TaXplOiBuZXcgTC5Qb2ludCg0MCwgNDApIH0pO1xyXG4gICAgfVxyXG5cclxuICAgIHB1YmxpYyBnZXREZWZhdWx0Q29uZmlnKCk6IElNYXBDb25maWcge1xyXG4gICAgICAgIHJldHVybiB7XHJcbiAgICAgICAgICAgIG1hcEFyZWE6IHtcclxuICAgICAgICAgICAgICAgIHN0eWxlOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgYmFja2dyb3VuZENvbG9yOiAnI0ZGRkZGRicsXHJcbiAgICAgICAgICAgICAgICAgICAgZm9udEZhbWlseTogJ0FyaWFsLCBIZWx2ZXRpY2EsIHNhbnMtc2VyaWYnXHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgIHRpdGxlOiB7XHJcbiAgICAgICAgICAgICAgICB0ZXh0OiAnJyxcclxuICAgICAgICAgICAgICAgIGFsaWduOiAnY2VudGVyJ1xyXG4gICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICBzdWJ0aXRsZToge1xyXG4gICAgICAgICAgICAgICAgdGV4dDogJycsXHJcbiAgICAgICAgICAgICAgICBhbGlnbjogJ2NlbnRlcidcclxuICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgbGVnZW5kOiB7XHJcbiAgICAgICAgICAgICAgICBmbG9hdDogZmFsc2UsXHJcbiAgICAgICAgICAgICAgICBhbGlnbjogJ2xlZnQnLFxyXG4gICAgICAgICAgICAgICAgdmVydGljYWxBbGlnbjogJ2JvdHRvbScsXHJcbiAgICAgICAgICAgICAgICBsYXlvdXQ6ICdob3Jpem9udGFsJyxcclxuICAgICAgICAgICAgICAgIHRpdGxlOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgdGV4dDogJycsXHJcbiAgICAgICAgICAgICAgICAgICAgYWxpZ246ICdsZWZ0J1xyXG4gICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICAgIGl0ZW06IHtcclxuICAgICAgICAgICAgICAgICAgICBzdHlsZTogeyBjb2xvcjogJyMwMDAwMDAnfVxyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICBmb290ZXI6IHtcclxuICAgICAgICAgICAgICAgIGJvdHRvbUxhYmVsOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgdGV4dDogJycsXHJcbiAgICAgICAgICAgICAgICAgICAgYWxpZ246ICdyaWdodCdcclxuICAgICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICAgICBmb290Tm90ZToge1xyXG4gICAgICAgICAgICAgICAgICAgIHRleHQ6ICcnLFxyXG4gICAgICAgICAgICAgICAgICAgIGFsaWduOiAncmlnaHQnXHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9O1xyXG4gICAgfVxyXG59XHJcbiJdfQ==