import { __decorate, __metadata } from "tslib";
import { Component, ViewEncapsulation, Input, OnInit, OnChanges, SimpleChanges, OnDestroy, ElementRef, AfterViewInit, ViewChild, HostListener, HostBinding, ChangeDetectorRef } from '@angular/core';
// import { Subscription } from 'rxjs/Subscription';
import { timer } from 'rxjs';
// import { debounceTime } from 'rxjs/operators';
import * as L from 'leaflet';
import 'leaflet.markercluster';
import 'leaflet.awesome-markers/dist/leaflet.awesome-markers';
import { KdSplitterEvent } from '../kd-angular-splitter/index';
import { KdDomElemSvc } from '../kd-common/index';
import { KdMapSvc, IMapPopulateClusterData } from './kd-angular-map-svc';
import { KdDataSvc } from '../kd-common/index';
var KdMap = /** @class */ (function () {
    function KdMap(_elementRef, _kdSplitterEvent, _kdDomElemSvc, _kdMapSvc, _cd, _dataSvc) {
        this._elementRef = _elementRef;
        this._kdDomElemSvc = _kdDomElemSvc;
        this._kdMapSvc = _kdMapSvc;
        this._cd = _cd;
        this._dataSvc = _dataSvc;
        // private static mapPinImage: string = 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABkAAAApCAYAAADAk4LOAAAFgUlEQVR4Aa1XA5BjWRTN2oW17d3YaZtr2962HUzbDNpjszW24mRt28p47v7zq/bXZtrp/lWnXr337j3nPCe85NcypgSFdugCpW5YoDAMRaIMqRi6aKq5E3YqDQO3qAwjVWrD8Ncq/RBpykd8oZUb/kaJutow8r1aP9II0WmLKLIsJyv1w/kqw9Ch2MYdB++12Onxee/QMwvf4/Dk/Lfp/i4nxTXtOoQ4pW5Aj7wpici1A9erdAN2OH64x8OSP9j3Ft3b7aWkTg/Fm91siTra0f9on5sQr9INejH6CUUUpavjFNq1B+Oadhxmnfa8RfEmN8VNAsQhPqF55xHkMzz3jSmChWU6f7/XZKNH+9+hBLOHYozuKQPxyMPUKkrX/K0uWnfFaJGS1QPRtZsOPtr3NsW0uyh6NNCOkU3Yz+bXbT3I8G3xE5EXLXtCXbbqwCO9zPQYPRTZ5vIDXD7U+w7rFDEoUUf7ibHIR4y6bLVPXrz8JVZEql13trxwue/uDivd3fkWRbS6/IA2bID4uk0UpF1N8qLlbBlXs4Ee7HLTfV1j54APvODnSfOWBqtKVvjgLKzF5YdEk5ewRkGlK0i33Eofffc7HT56jD7/6U+qH3Cx7SBLNntH5YIPvODnyfIXZYRVDPqgHtLs5ABHD3YzLuespb7t79FY34DjMwrVrcTuwlT55YMPvOBnRrJ4VXTdNnYug5ucHLBjEpt30701A3Ts+HEa73u6dT3FNWwflY86eMHPk+Yu+i6pzUpRrW7SNDg5JHR4KapmM5Wv2E8Tfcb1HoqqHMHU+uWDD7zg54mz5/2BSnizi9T1Dg4QQXLToGNCkb6tb1NU+QAlGr1++eADrzhn/u8Q2YZhQVlZ5+CAOtqfbhmaUCS1ezNFVm2imDbPmPng5wmz+gwh+oHDce0eUtQ6OGDIyR0uUhUsoO3vfDmmgOezH0mZN59x7MBi++WDL1g/eEiU3avlidO671bkLfwbw5XV2P8Pzo0ydy4t2/0eu33xYSOMOD8hTf4CrBtGMSoXfPLchX+J0ruSePw3LZeK0juPJbYzrhkH0io7B3k164hiGvawhOKMLkrQLyVpZg8rHFW7E2uHOL888IBPlNZ1FPzstSJM694fWr6RwpvcJK60+0HCILTBzZLFNdtAzJaohze60T8qBzyh5ZuOg5e7uwQppofEmf2++DYvmySqGBuKaicF1blQjhuHdvCIMvp8whTTfZzI7RldpwtSzL+F1+wkdZ2TBOW2gIF88PBTzD/gpeREAMEbxnJcaJHNHrpzji0gQCS6hdkEeYt9DF/2qPcEC8RM28Hwmr3sdNyht00byAut2k3gufWNtgtOEOFGUwcXWNDbdNbpgBGxEvKkOQsxivJx33iow0Vw5S6SVTrpVq11ysA2Rp7gTfPfktc6zhtXBBC+adRLshf6sG2RfHPZ5EAc4sVZ83yCN00Fk/4kggu40ZTvIEm5g24qtU4KjBrx/BTTH8ifVASAG7gKrnWxJDcU7x8X6Ecczhm3o6YicvsLXWfh3Ch1W0k8x0nXF+0fFxgt4phz8QvypiwCCFKMqXCnqXExjq10beH+UUA7+nG6mdG/Pu0f3LgFcGrl2s0kNNjpmoJ9o4B29CMO8dMT4Q5ox8uitF6fqsrJOr8qnwNbRzv6hSnG5wP+64C7h9lp30hKNtKdWjtdkbuPA19nJ7Tz3zR/ibgARbhb4AlhavcBebmTHcFl2fvYEnW0ox9xMxKBS8btJ+KiEbq9zA4RthQXDhPa0T9TEe69gWupwc6uBUphquXgf+/FrIjweHQS4/pduMe5ERUMHUd9xv8ZR98CxkS4F2n3EUrUZ10EYNw7BWm9x1GiPssi3GgiGRDKWRYZfXlON+dfNbM+GgIwYdwAAAAASUVORK5CYII=';
        // private static mapPinShadowImage: string = 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACkAAAApCAQAAAACach9AAACMUlEQVR4Ae3ShY7jQBAE0Aoz/f9/HTMzhg1zrdKUrJbdx+Kd2nD8VNudfsL/Th///dyQN2TH6f3y/BGpC379rV+S+qqetBOxImNQXL8JCAr2V4iMQXHGNJxeCfZXhSRBcQMfvkOWUdtfzlLgAENmZDcmo2TVmt8OSM2eXxBp3DjHSMFutqS7SbmemzBiR+xpKCNUIRkdkkYxhAkyGoBvyQFEJEefwSmmvBfJuJ6aKqKWnAkvGZOaZXTUgFqYULWNSHUckZuR1HIIimUExutRxwzOLROIG4vKmCKQt364mIlhSyzAf1m9lHZHJZrlAOMMztRRiKimp/rpdJDc9Awry5xTZCte7FHtuS8wJgeYGrex28xNTd086Dik7vUMscQOa8y4DoGtCCSkAKlNwpgNtphjrC6MIHUkR6YWxxs6Sc5xqn222mmCRFzIt8lEdKx+ikCtg91qS2WpwVfBelJCiQJwvzixfI9cxZQWgiSJelKnwBElKYtDOb2MFbhmUigbReQBV0Cg4+qMXSxXSyGUn4UbF8l+7qdSGnTC0XLCmahIgUHLhLOhpVCtw4CzYXvLQWQbJNmxoCsOKAxSgBJno75avolkRw8iIAFcsdc02e9iyCd8tHwmeSSoKTowIgvscSGZUOA7PuCN5b2BX9mQM7S0wYhMNU74zgsPBj3HU7wguAfnxxjFQGBE6pwN+GjME9zHY7zGp8wVxMShYX9NXvEWD3HbwJf4giO4CFIQxXScH1/TM+04kkBiAAAAAElFTkSuQmCC';
        this.smallLoaderValue = null;
        this.isMapShown = true;
        this.isLayerLoading = true;
        this.isLinkToGoogle = false;
        this.googleLink = '';
        this.errorMessage = '';
        this.googleImage = 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADIAAAAyCAYAAAAeP4ixAAAABHNCSVQICAgIfAhkiAAAAAlwSFlzAAAOawAADmsBVP4NBgAAABl0RVh0U29mdHdhcmUAd3d3Lmlua3NjYXBlLm9yZ5vuPBoAAAatSURBVGiB7ZlbbBzVGcd/Z2Zn7L34Hmyyu97cHIfEjdNYMXUwRLaSUtJC1YoQqw1tKVIpyUPVclFLLyqR0zxUlYJUKYIIqQ/lhVDoRS2NiiEuIIpJ0lxMGyAbAontpNSX2PF6vbc5fXDH8WVmdtZeK63k/9PZ75zzne+335lvzp6FRf1vSdzoAAC6tzRWe4T4EshtQDVQAgwDl6SUf9EU9ferO7t6nHzcUJD3mjcG8Xj2SngA8DgMTQG/kobx5Lo3Tly2GnDDQP7R2rhVMTgMlOcwbUBIsfOW1995bWbHDQF5r3VTszTEq0DBHKaPS6G0ruvsenuq0REk+Mx9EUUojwlokFIUzmHRWaqKpbSDR3rWFScMp62UTVcMwca6zmNXTIOts+Az90UUlFNIyiQAch7rXtfXu4coThjzdXOzKmkHvmUabEEUxKNA2Uz7Em8xX1x1G+uXrERVFM4N9fLnC11Er/ZlXb0ylmbrhWuOYyQwljHwqYrjdpHwjXMtn9lrVjOH9Iq6mZZ7V9/BvtsfJKB5p9kf27STX578Lb84ftgxyC0XY6g2iZXAu7E4Z66Nk5AGBYqgPuClzleIIiyRtBSZHcBTAIo9B+pMiAOtewhoXuLpBH/r+yevXjxJf3yEjMxw+t/nHSEANv4rbtt3ejTOsZExEnJi2yUMybGRMc7E7OcIKbaabVcPXEmBn/bmbyIQnPwkyu6Op+gd7QfArxVSUxpyBVIZS1vazWxYqXt0nPqAz+YblxGzZZ+RKfrCiiaKdB9j6QQPdxyYhACIpcZdQQAUpawf8rhhkDSs91xKSuIZu+IgKsyWq4ysq1gGwKlPovSNDkzaT9z/NJW+0mljD535I+1vP2fpZ0wVVFjYvYqCrghLGE0IvKpNPpAjZttVRsyHLWNkL5uaYv/dfFyqW9oF8OmA17KvochuW4FAvGu2XWUkerUXgA2VKykp8DOciAFw/8v78SgedNXDc9ufIKB76Zmy7WaqM+Ln9ksxy746vxfJxEOfNCS6ItgQ8LLWZ//yF0JOlklXGfnTh13E0wmKdT8HWvZMlt+zgxfp7v+Qu5Y3EtC9SCSdl07Z+nkzEqDfq1r2CWC938uuqnLaKsvYVVXOer/XrvQC9Fwm8Dvzg7VXoPieTz0ALIeJBzqeTtJSvYFVpUF21G5hTXmYpmAdjzfu5O6VTQD8IfoWvz7bYQsiBfg12NDrUFIBXRFZD4FSyh/e+te3uszPrs87z3a/TJHu47sN93Kzv5y2Na3T+jsvneYHbz7r6KNKz/BgWxJ9WCH2/ryOKa+sff34wamGnA5uB078hiMX3qHtllZqy8KkMmn6YgMcuXCMN3rPYEj781iVnuH5+gFW+dIkv6rx0f4kRmJO57drhsjsETMOf7YZDB9qO4qkZS4rzdRUiMlo/p6h91Aqd2eK3LH26PEXZ5nnFaELVVpAABQ1qPg3l+Tka6ihPmkFAQsMUqlnOGwBARAzIgx8+QmMpUFXvoxgkJ577h6z618wkGwQH4w/RFoNkGjbBUqWMFSV8bavYXhsi+zCgDhCyGV8MP4QGTnxgzNTvYxUy9ZZ46Yq2boNI1ztOCbvIE4QGX0N8Yp9oPin2ROf3Y5RbnUKA6NiCaltd2VdN68g2SBGy/bi0UsIh6pR1SnbRNdJ3bnd0mfyc59HalrWtfMG4gZCCh8AmqYTXBqaBpNqaMQomV7FjJJS0hs3uVo/LyBOEO8PruF08jqEqYKCQsKhyHUYVSXd1DxtTGpzc/ZC8F/NG8QJ4mx/Ld/raOfHLwQ4d2X2XE3TpsGkGpvAPCQqCulbb3Mdx7xAskE8+to+YkkfsQT89AUlK4wsK8cIhQEwwhFkifsX5pxB3EKYcguTrqkFIFOzOqd45gSSK4QpNzCsWAlMvF9yUc4gc4UwlQ2matNmYGJr5aKcQOYLYcoJpiAUpvhHexE33ZRLaO5B8gVhygnG17h59kszi1yB5BvClPM20wnlAJMVZKEgTDnB6DnAOILY/SiC/ECYygeMLUh1YUZ/vn6AmgWGMJUNZmkwRIFHt43XtuPnNVdrrCCiQyv4/tEn8wphKpaA9pcUPra44yvUCwlXhWzvGGxB4oaY9e9pdGg5j3T8jOFE8VxjzarhMfjJYWuYnvHBqN08W5Bo3PPwSEZMXrmcvxrhkY79CwphyoT5qP/63ddIckxGB/t2281xvNA7+Mr2plpf+mk9VbVqf9fu1NB4ID9/JLpUmU8V37lT0xKey+ejg5e//fgdX+nKPmtRi1rUov4f9B+IBMnVIJV2nAAAAABJRU5ErkJggg==';
        this.markersLegend = [];
        this.htmlClass = '';
        this._clusterMarkers = {};
        this._isLayerError = false;
        this._isMarkerLoaded = false;
        this._isTilesLoaded = false;
        this._layerReloadTimes = 0;
        this._tileloadIndex = 0;
    }
    KdMap.prototype.ngOnInit = function () {
        window.addEventListener('resize', this._resizeMap);
        if (typeof this.config.id === 'undefined') {
            this.config.id = 'kdx-map-01';
        }
    };
    KdMap.prototype.ngOnChanges = function (_simpleChanges) {
        var _this = this;
        if (_simpleChanges.hasOwnProperty('api')) {
            this._initApi();
        }
        if (_simpleChanges.hasOwnProperty('position')) {
            this._validateLatLng(_simpleChanges.position.currentValue);
            if (!_simpleChanges['position'].firstChange && this.isMapShown) {
                if (typeof this._myMap === 'undefined') {
                    timer(200).subscribe(function () { _this._reinitMap(); });
                }
                else
                    this._myMap.panTo(this.position);
            }
        }
        if (_simpleChanges.hasOwnProperty('config')) {
            this.errorMessage = _simpleChanges.config.currentValue.errorMessage || 'Invalid latitude/longitude value';
            if (_simpleChanges.hasOwnProperty('position')) {
                if (_simpleChanges.config.currentValue.googleLink && _simpleChanges.config.currentValue.googleLink.display && this.isMapShown) {
                    this._setGoogleLink(_simpleChanges.position.currentValue);
                }
            }
            if (!_simpleChanges['config'].firstChange) {
                if (this.config.zoom) {
                    this._checkZoomConfig(this.config.zoom);
                    if (this.config.zoom.value) {
                        if (typeof this._myMap !== 'undefined')
                            this._myMap.setZoom(this.config.zoom.value);
                    }
                }
                if (this.config.attribution)
                    this._removeDefaultAttribution(this.config.attribution);
                if (this.config.type !== 'basic') {
                    this._removeAllMarkerLayers();
                    this._setMarkers();
                }
            }
            this._setDefaultConfig();
        }
        if (_simpleChanges.hasOwnProperty('data') && !_simpleChanges['data'].firstChange && this.config.type !== 'basic') {
            this._removeAllMarkerLayers();
            this._setMarkers();
        }
    };
    KdMap.prototype.ngAfterViewInit = function () {
        if (this.isMapShown) {
            this._initMap();
            this._cd.detectChanges();
            this._resizeMap();
        }
    };
    KdMap.prototype.ngOnDestroy = function () {
        window.removeEventListener('resize', this._resizeMap);
    };
    KdMap.prototype.onLegendClick = function (_legendItem) {
        var legendItemMarker = this._elementRef.nativeElement.querySelector('#kdli-' + _legendItem.id + ' .awesome-marker');
        var legendItemLabel = this._elementRef.nativeElement.querySelector('#kdli-' + _legendItem.id + ' .kdx-legend-label');
        var selectedMarkerGroup;
        switch (this.config.type) {
            case 'cluster':
            case 'group-cluster':
                selectedMarkerGroup = this._clusterMarkers[_legendItem.id];
                break;
            default:
                selectedMarkerGroup = this._marker;
                break;
        }
        if (this._myMap.hasLayer(selectedMarkerGroup)) {
            this._myMap.removeLayer(selectedMarkerGroup);
            this._kdDomElemSvc.addClass(legendItemMarker, 'awesome-marker-icon-lightgray');
            this._kdDomElemSvc.addClass(legendItemLabel, 'kdx-label-lightgray');
        }
        else {
            this._myMap.addLayer(selectedMarkerGroup);
            this._kdDomElemSvc.removeClass(legendItemMarker, 'awesome-marker-icon-lightgray');
            this._kdDomElemSvc.removeClass(legendItemLabel, 'kdx-label-lightgray');
        }
    };
    KdMap.prototype._validateLatLng = function (_position) {
        if (!_position) {
            this.isMapShown = false;
            this.isMapError = !this.isMapShown;
        }
        else {
            var _lat = _position.lat;
            var _lng = _position.lng;
            this.isMapShown = (typeof _lat === 'undefined') || (typeof _lng === 'undefined') || (_lng < -180 || _lng > 180) || (_lat < -90 || _lat > 90) ? false : true;
            this.isMapError = !this.isMapShown;
        }
        if (!this.isMapShown && this._myMap) {
            delete this._myMap;
            delete this._layer;
            delete this._marker;
            delete this._clusterMarkers;
            delete this.markersLegend;
        }
    };
    KdMap.prototype._initMap = function () {
        this._myMap = L.map(this.myMap.nativeElement, {
            center: this.position,
            zoom: (this.config.zoom && this.config.zoom.value) || 14,
        });
        if (this.config.zoom)
            this._checkZoomConfig(this.config.zoom);
        this._setLayer();
        this._setMarkers();
        this._removeDefaultAttribution(this.config.attribution);
        if (this.config.googleLink && this.config.googleLink.display && this.config.type === 'basic')
            this._setLinkStyle(this.config.zoom, this.config.googleLink.position);
    };
    KdMap.prototype._reinitMap = function () {
        var _this = this;
        timer(50).subscribe(function () {
            if (typeof _this.myMap === 'undefined')
                _this._reinitMap();
            else
                _this._initMap();
        });
    };
    KdMap.prototype._initApi = function () {
        var _this = this;
        if (typeof this.api !== 'undefined' && Object.keys(this.api).length === 0) {
            this.api.resizeMap = function () { return _this._resizeMap(); };
            this.api.getZoom = function () { return _this._myMap.getZoom(); };
        }
    };
    KdMap.prototype._checkZoomConfig = function (_config) {
        if (typeof this._myMap !== 'undefined') {
            _config.isZoomButton ? this._myMap.addControl(this._myMap.zoomControl) : this._myMap.removeControl(this._myMap.zoomControl);
            _config.isScrollZoom ? this._myMap.scrollWheelZoom.enable() : this._myMap.scrollWheelZoom.disable();
            _config.isTouchZoom ? this._myMap.touchZoom.enable() : this._myMap.touchZoom.disable();
            _config.isDoubleClickZoom ? this._myMap.doubleClickZoom.enable() : this._myMap.doubleClickZoom.disable();
        }
    };
    KdMap.prototype._setLayer = function () {
        if (this._layer)
            this._layer.remove();
        this._isLayerError = false;
        this.isLayerLoading = true;
        this._layer = L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
            attribution: '&copy; <a href="http://www.openstreetmap.org/copyright">OpenStreetMap</a>',
            maxZoom: 18,
        });
        this._layer.addTo(this._myMap);
        this._attachTileListener();
    };
    KdMap.prototype._removeDefaultAttribution = function (_attribution) {
        var attributionElement = this._elementRef.nativeElement.querySelector('.leaflet-control-attribution');
        if (attributionElement !== null) {
            var newAttributionElement = this._kdDomElemSvc.createElement(attributionElement, 'custom-attribution');
            newAttributionElement.innerText = _attribution || 'OpenEMIS';
            attributionElement.replaceChild(newAttributionElement, attributionElement.firstChild);
        }
    };
    KdMap.prototype._attachTileListener = function () {
        var _this = this;
        /* Checks every tile. Only called when some tile load has failed. */
        this._layer.on('tileerror', function (error) {
            // only execute the following for the first tile error
            if (!_this._isLayerError) {
                _this._isLayerError = true;
                _this._layerReloadTimes++;
                if (_this._layerReloadTimes < 5 || _this._layerReloadTimes === 5) {
                    _this._setLayer();
                }
                if (_this._layerReloadTimes > 5) {
                    _this.isMapShown = false;
                    _this.errorMessage = 'Max retry reached. Map cannot be loaded now. Please check your internet connection or try again later.';
                }
            }
        });
        /* Checks every tile. Only called when each tile load is successful. */
        this._layer.on('tileload', function () {
            _this._tileloadIndex++;
            if (_this.isLayerLoading && _this._tileloadIndex === Object.keys(_this._layer._tiles).length) {
                // only stop progress loader when last tile loaded successfully
                // this.isLayerLoading = false;
                _this._isTilesLoaded = true;
                _this._hideLoadingScreen();
                // reset counters
                _this._layerReloadTimes = 0;
                _this._tileloadIndex = 0;
            }
        });
    };
    KdMap.prototype._resizeMap = function () {
        var _this = this;
        if (this.isMapShown) {
            timer().subscribe(function () {
                _this._myMap.invalidateSize({});
            });
        }
    };
    KdMap.prototype._setGoogleLink = function (_position) {
        if (this.config.type === 'basic') {
            this.isLinkToGoogle = true;
            this.googleLink = 'https://www.google.com/maps/?q=' + _position.lat.toString() + ',' + _position.lng.toString();
        }
        else {
            this.isLinkToGoogle = false;
        }
    };
    KdMap.prototype._setLinkStyle = function (_zoomConfig, _linkPosition) {
        var linkElement = this._elementRef.nativeElement.querySelector('.kdx-map .link-wrapper');
        switch (_linkPosition) {
            case 'top-left':
            default:
                // only when Zoom Buttons are removed then we put googleLink at the position of the Zoom Buttons
                var newClass = _zoomConfig && _zoomConfig.isZoomButton === false ? '' : ' below-zoom';
                this._kdDomElemSvc.addClass(linkElement, 'leaflet-top leaflet-left' + newClass);
                break;
            case 'top-right':
                this._kdDomElemSvc.addClass(linkElement, 'leaflet-top leaflet-right');
                break;
            case 'bottom-left':
                this._kdDomElemSvc.addClass(linkElement, 'leaflet-bottom leaflet-left');
                break;
            case 'bottom-right':
                this._kdDomElemSvc.addClass(linkElement, 'leaflet-bottom leaflet-right above-attribution');
                break;
        }
    };
    KdMap.prototype._setMarkers = function () {
        if (typeof this._myMap !== 'undefined') {
            switch (this.config.type) {
                case 'cluster':
                case 'group-cluster':
                    if (typeof this.data !== 'undefined' && Object.keys(this.data).length !== 0) {
                        var clusterData = this._kdMapSvc.populateMarkers(this.data, this._myMap, this.config.type);
                        this.markersLegend = clusterData.markersLegend;
                        this._clusterMarkers = clusterData.clusterMarkers;
                        this._isMarkerLoaded = true;
                    }
                    break;
                default:
                    var defaultIcon = {
                        markerColor: 'purple',
                        title: this.config.marker.title
                    };
                    var iconMarker = this._kdMapSvc.setIcon(defaultIcon);
                    this._marker = L.marker(this.position, { icon: iconMarker }).addTo(this._myMap);
                    this._isMarkerLoaded = true;
                    if (this.config.hasOwnProperty('content')) {
                        this._marker.bindPopup(this.config.content);
                    }
                    if (this.config.hasOwnProperty('legend')) {
                        this.markersLegend = [{
                                icon: iconMarker.createIcon(),
                                label: this.config.marker.title,
                                id: this.config.marker.hasOwnProperty('id') ? this.config.marker.id : 'kdx-single-marker'
                            }];
                    }
                    break;
            }
        }
        this._hideLoadingScreen();
    };
    KdMap.prototype._hideLoadingScreen = function () {
        if (this._isMarkerLoaded && this._isTilesLoaded) {
            this.isLayerLoading = false;
        }
    };
    KdMap.prototype._removeAllMarkerLayers = function () {
        for (var legendItemId in this._clusterMarkers) {
            if (this._clusterMarkers[legendItemId])
                this._myMap.removeLayer(this._clusterMarkers[legendItemId]);
        }
        this.markersLegend = [];
    };
    KdMap.prototype._setDefaultConfig = function () {
        this.mapConfig = this._kdMapSvc.getDefaultConfig();
        this._dataSvc.deepMergeObject(this.mapConfig, this.config, false);
        this.mapConfig.legend.enabled = this._setEnabled('legend', ['title']);
        if (this.mapConfig.footer)
            this.mapConfig.footer.enabled = this._setEnabled('footer', ['bottomLabel', 'footNote']);
        this._setClassNames();
    };
    KdMap.prototype._setEnabled = function (_objKey, _textKeys) {
        if (this.mapConfig[_objKey] && typeof this.mapConfig[_objKey].enabled !== 'undefined') {
            return this.mapConfig[_objKey].enabled;
        }
        for (var i = _textKeys.length - 1; i >= 0; i--) {
            if (this.mapConfig[_objKey][_textKeys[i]] && this.mapConfig[_objKey][_textKeys[i]].text !== '') {
                return true;
            }
        }
        if (_objKey === 'legend' && this.markersLegend.length === 0) {
            return false;
        }
        return false;
    };
    /* To be revisit. Hot fix for downgrade component as ngclass value doesn't change.*/
    KdMap.prototype._setClassNames = function () {
        // htmlClassObj is a workaround for downgrade method
        this.htmlClass = '';
        if (typeof this.config.legend.float !== 'undefined' && this.config.legend.float) {
            this.htmlClass += 'legend-float ';
        }
        if (typeof this.config.legend.verticalAlign !== 'undefined') {
            this.htmlClass += this.config.legend.verticalAlign + ' ';
        }
        if (typeof this.config.legend.align !== 'undefined') {
            this.htmlClass += this.config.legend.align;
        }
    };
    KdMap.ctorParameters = function () { return [
        { type: ElementRef },
        { type: KdSplitterEvent },
        { type: KdDomElemSvc },
        { type: KdMapSvc },
        { type: ChangeDetectorRef },
        { type: KdDataSvc }
    ]; };
    __decorate([
        Input(),
        __metadata("design:type", Object)
    ], KdMap.prototype, "position", void 0);
    __decorate([
        Input(),
        __metadata("design:type", Object)
    ], KdMap.prototype, "config", void 0);
    __decorate([
        Input(),
        __metadata("design:type", Object)
    ], KdMap.prototype, "data", void 0);
    __decorate([
        Input(),
        __metadata("design:type", Object)
    ], KdMap.prototype, "api", void 0);
    __decorate([
        ViewChild('myMap'),
        __metadata("design:type", ElementRef)
    ], KdMap.prototype, "myMap", void 0);
    __decorate([
        HostBinding('class.error'),
        __metadata("design:type", Boolean)
    ], KdMap.prototype, "isMapError", void 0);
    KdMap = __decorate([
        Component({
            selector: 'kd-map',
            template: "<div class=\"kdx-charts-wrapper {{htmlClass}}\" id=\"{{config.id}}\">\r\n    <div class=\"kdx-charts-main\">\r\n        <div class=\"kdx-header-container\" *ngIf=\"mapConfig.title && mapConfig.title.text && mapConfig.title.text !== '' || mapConfig.subtitle && mapConfig.subtitle.text && mapConfig.subtitle.text !== ''\">\r\n            <div class=\"kdx-chart-title {{mapConfig.title.align}}\" *ngIf=\"mapConfig.title && mapConfig.title.text && mapConfig.title.text !== ''\" [ngStyle]=\"mapConfig.title.style\">\r\n                {{mapConfig.title.text}}\r\n            </div>\r\n            <div class=\"kdx-chart-subtitle {{mapConfig.subtitle.align}}\" *ngIf=\"mapConfig.subtitle && mapConfig.subtitle.text && mapConfig.subtitle.text !== ''\" [ngStyle]=\"mapConfig.subtitle.style\">\r\n                {{mapConfig.subtitle.text}}\r\n            </div>\r\n        </div>\r\n        <div class=\"kdx-chart-container\" *ngIf=\"isMapShown\" #myMap>\r\n            <div class=\"link-wrapper\" *ngIf=\"isLinkToGoogle\">\r\n                <a class=\"google-link leaflet-bar leaflet-control\" [attr.href]=\"googleLink\" target=\"_blank\">\r\n                    <img class=\"google-image\" [src]=\"googleImage\">\r\n                </a>\r\n            </div>\r\n        </div>\r\n        <div class=\"kdx-error-map\" *ngIf=\"!isMapShown\">\r\n            <div class=\"kdx-error-icon\"><i class=\"fa fa-map-o\"></i></div>\r\n            <div class=\"kdx-error-message\">{{errorMessage}}</div>\r\n        </div>\r\n    </div>\r\n    <div class=\"kdx-legend-container {{htmlClass}}\" *ngIf=\"mapConfig.legend.enabled && isMapShown\">\r\n        <div class=\"kdx-legends\" *ngIf=\"mapConfig.legend\" [ngStyle]=\"mapConfig.legend.style\">\r\n            <div class=\"kdx-legend-title-container {{mapConfig.legend.title.align}}\" *ngIf=\"mapConfig.legend.title && mapConfig.legend.title.text && mapConfig.legend.title.text !== ''\" [ngStyle]=\"mapConfig.legend.title.style\">\r\n                <div class=\"kdx-legend-title\">{{mapConfig.legend.title.text}}</div>\r\n            </div>\r\n            <div class=\"kdx-legend legend-scroll {{mapConfig.legend.layout}}\">\r\n                <div class=\"kdx-legend-item\" id=\"kdli-{{legendItem.id}}\" *ngFor=\"let legendItem of markersLegend\" (click)=\"onLegendClick(legendItem)\">\r\n                    <div class=\"kdx-legend-marker\" [innerHTML]=\"legendItem.icon.outerHTML\"></div>\r\n                    <div class=\"kdx-legend-label\" [ngStyle]=\"mapConfig.legend.item.style\">\r\n                        <div class=\"kdx-label-text\">{{legendItem.label}}</div>\r\n                    </div>\r\n                </div>\r\n            </div>\r\n        </div>\r\n    </div>\r\n    <kd-progressloader *ngIf=\"isLayerLoading && isMapShown\" configtype=\"small-spinner\" [configvalue]=\"smallLoaderValue\"></kd-progressloader>\r\n</div>\r\n<div class=\"kdx-charts-footer\" *ngIf=\"mapConfig.footer && mapConfig.footer.enabled\">\r\n    <div class=\"kdx-charts-bottom-label {{mapConfig.footer.bottomLabel.align}}\" *ngIf=\"mapConfig.footer && mapConfig.footer.bottomLabel && mapConfig.footer.bottomLabel.text && mapConfig.footer.bottomLabel.text !== ''\" [ngStyle]=\"mapConfig.footer.bottomLabel.style\">\r\n        {{mapConfig.footer.bottomLabel.text}}\r\n    </div>\r\n    <div class=\"kdx-charts-foot-note {{mapConfig.footer.footNote.align}}\" *ngIf=\"mapConfig.footer && mapConfig.footer.footNote && mapConfig.footer.footNote.text && mapConfig.footer.footNote.text !== ''\" [ngStyle]=\"mapConfig.footer.footNote.style\">\r\n        {{mapConfig.footer.footNote.text}}\r\n    </div>\r\n</div>",
            /*template: `
                    <div class="header-container">
                        <div class="chart-title left">{{config.legend.title.text}}</div>
                        <div class="chart-subtitle right">{{config.legend.title.text}}</div>
                    </div>
                    <div *ngIf="isMapShown" class="chart-container"  #myMap>
                        <div class="link-wrapper" *ngIf="isLinkToGoogle">
                            <a [attr.href]="googleLink" target="_blank" class="google-link leaflet-bar leaflet-control">
                                <img class="google-image" [src]="googleImage">
                            </a>
                        </div>
                    </div>
                    <div class="legend-container center" *ngIf="config.legend && isMapShown">
                        <div class="legends">
                            <div class="legend-title-container right" *ngIf="config.legend.title.text">
                                <div class="title">{{config.legend.title.text}}</div>
                            </div>
                            <div class="legend">
                                <div class="legend-item" id="kdli-{{legendItem.id}}" *ngFor="let legendItem of markersLegend" (click)="onLegendClick(legendItem)">
                                    <div class="legend-marker" [innerHTML]="legendItem.icon.outerHTML" ></div>
                                    <div class="legend-label"><div class="label-text">{{legendItem.label}}</div></div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div *ngIf="!isMapShown" class="error-map">
                        <div class="error-icon"><i class="fa fa-map-o"></i></div>
                        <div class="error-message">{{errorMessage}}</div>
                    </div>
                    <kd-progressloader *ngIf="isLayerLoading && isMapShown" configtype="small-spinner" [configvalue]="smallLoaderValue"></kd-progressloader>
        
            `,*/
            encapsulation: ViewEncapsulation.None,
            host: {
                'class': 'kdx-map',
                '[style.background-color]': 'mapConfig.mapArea.style.backgroundColor',
                '[style.font-family]': 'mapConfig.mapArea.style.fontFamily'
            },
            providers: [KdDomElemSvc, KdMapSvc, KdDataSvc]
        }),
        __metadata("design:paramtypes", [ElementRef,
            KdSplitterEvent,
            KdDomElemSvc,
            KdMapSvc,
            ChangeDetectorRef,
            KdDataSvc])
    ], KdMap);
    return KdMap;
}());
export { KdMap };
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoia2QtYW5ndWxhci1tYXAuanMiLCJzb3VyY2VSb290Ijoibmc6Ly9vcGVuZW1pcy1zdHlsZWd1aWRlLWxpYi8iLCJzb3VyY2VzIjpbImtkLWNvbXBvbmVudHMva2QtYW5ndWxhci1tYXAva2QtYW5ndWxhci1tYXAudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IjtBQUFBLE9BQU8sRUFDSCxTQUFTLEVBQ1QsaUJBQWlCLEVBQ2pCLEtBQUssRUFDTCxNQUFNLEVBQ04sU0FBUyxFQUNULGFBQWEsRUFDYixTQUFTLEVBQ1QsVUFBVSxFQUNWLGFBQWEsRUFDYixTQUFTLEVBQ1QsWUFBWSxFQUNaLFdBQVcsRUFDWCxpQkFBaUIsRUFDcEIsTUFBTSxlQUFlLENBQUM7QUFDdkIsb0RBQW9EO0FBQ3BELE9BQU8sRUFBRSxLQUFLLEVBQUUsTUFBTSxNQUFNLENBQUM7QUFDN0IsaURBQWlEO0FBQ2pELE9BQU8sS0FBSyxDQUFDLE1BQU0sU0FBUyxDQUFDO0FBQzdCLE9BQU8sdUJBQXVCLENBQUM7QUFDL0IsT0FBTyxzREFBc0QsQ0FBQztBQUM5RCxPQUFPLEVBQUUsZUFBZSxFQUFFLE1BQU0sOEJBQThCLENBQUM7QUFDL0QsT0FBTyxFQUFFLFlBQVksRUFBRSxNQUFNLG9CQUFvQixDQUFDO0FBQ2xELE9BQU8sRUFBRSxRQUFRLEVBQUUsdUJBQXVCLEVBQUUsTUFBTSxzQkFBc0IsQ0FBQztBQVN6RSxPQUFPLEVBQUUsU0FBUyxFQUFFLE1BQU0sb0JBQW9CLENBQUM7QUE4Qy9DO0lBd0NJLGVBQ1ksV0FBdUIsRUFDL0IsZ0JBQWlDLEVBQ3pCLGFBQTJCLEVBQzNCLFNBQW1CLEVBQ25CLEdBQXNCLEVBQ3RCLFFBQW1CO1FBTG5CLGdCQUFXLEdBQVgsV0FBVyxDQUFZO1FBRXZCLGtCQUFhLEdBQWIsYUFBYSxDQUFjO1FBQzNCLGNBQVMsR0FBVCxTQUFTLENBQVU7UUFDbkIsUUFBRyxHQUFILEdBQUcsQ0FBbUI7UUFDdEIsYUFBUSxHQUFSLFFBQVEsQ0FBVztRQTVDL0IscStEQUFxK0Q7UUFDcitELCszQkFBKzNCO1FBRXgzQixxQkFBZ0IsR0FBUSxJQUFJLENBQUM7UUFDN0IsZUFBVSxHQUFZLElBQUksQ0FBQztRQUMzQixtQkFBYyxHQUFZLElBQUksQ0FBQztRQUMvQixtQkFBYyxHQUFZLEtBQUssQ0FBQztRQUNoQyxlQUFVLEdBQVcsRUFBRSxDQUFDO1FBQ3hCLGlCQUFZLEdBQVcsRUFBRSxDQUFDO1FBQzFCLGdCQUFXLEdBQVcsZzdFQUFnN0UsQ0FBQztRQUV2OEUsa0JBQWEsR0FBZSxFQUFFLENBQUM7UUFFL0IsY0FBUyxHQUFXLEVBQUUsQ0FBQztRQVF0QixvQkFBZSxHQUE0QyxFQUFFLENBQUM7UUFFOUQsa0JBQWEsR0FBWSxLQUFLLENBQUM7UUFDL0Isb0JBQWUsR0FBWSxLQUFLLENBQUM7UUFDakMsbUJBQWMsR0FBWSxLQUFLLENBQUM7UUFDaEMsc0JBQWlCLEdBQVcsQ0FBQyxDQUFDO1FBQzlCLG1CQUFjLEdBQVcsQ0FBQyxDQUFDO0lBa0IvQixDQUFDO0lBRUwsd0JBQVEsR0FBUjtRQUNJLE1BQU0sQ0FBQyxnQkFBZ0IsQ0FBQyxRQUFRLEVBQUUsSUFBSSxDQUFDLFVBQVUsQ0FBQyxDQUFDO1FBRW5ELElBQUksT0FBTyxJQUFJLENBQUMsTUFBTSxDQUFDLEVBQUUsS0FBSyxXQUFXLEVBQUU7WUFDdkMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxFQUFFLEdBQUcsWUFBWSxDQUFDO1NBQ2pDO0lBQ0wsQ0FBQztJQUVELDJCQUFXLEdBQVgsVUFBWSxjQUE2QjtRQUF6QyxpQkFrREM7UUFqREcsSUFBSSxjQUFjLENBQUMsY0FBYyxDQUFDLEtBQUssQ0FBQyxFQUFFO1lBQ3RDLElBQUksQ0FBQyxRQUFRLEVBQUUsQ0FBQztTQUNuQjtRQUVELElBQUksY0FBYyxDQUFDLGNBQWMsQ0FBQyxVQUFVLENBQUMsRUFBRTtZQUMzQyxJQUFJLENBQUMsZUFBZSxDQUFDLGNBQWMsQ0FBQyxRQUFRLENBQUMsWUFBWSxDQUFDLENBQUM7WUFFM0QsSUFBSSxDQUFDLGNBQWMsQ0FBQyxVQUFVLENBQUMsQ0FBQyxXQUFXLElBQUksSUFBSSxDQUFDLFVBQVUsRUFBRTtnQkFFNUQsSUFBSSxPQUFPLElBQUksQ0FBQyxNQUFNLEtBQUssV0FBVyxFQUFFO29CQUNwQyxLQUFLLENBQUMsR0FBRyxDQUFDLENBQUMsU0FBUyxDQUFDLGNBQWMsS0FBSSxDQUFDLFVBQVUsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7aUJBQzVEOztvQkFDSSxJQUFJLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLENBQUM7YUFDekM7U0FDSjtRQUdELElBQUksY0FBYyxDQUFDLGNBQWMsQ0FBQyxRQUFRLENBQUMsRUFBRTtZQUN6QyxJQUFJLENBQUMsWUFBWSxHQUFHLGNBQWMsQ0FBQyxNQUFNLENBQUMsWUFBWSxDQUFDLFlBQVksSUFBSSxrQ0FBa0MsQ0FBQztZQUUxRyxJQUFJLGNBQWMsQ0FBQyxjQUFjLENBQUMsVUFBVSxDQUFDLEVBQUU7Z0JBQzNDLElBQUksY0FBYyxDQUFDLE1BQU0sQ0FBQyxZQUFZLENBQUMsVUFBVSxJQUFJLGNBQWMsQ0FBQyxNQUFNLENBQUMsWUFBWSxDQUFDLFVBQVUsQ0FBQyxPQUFPLElBQUksSUFBSSxDQUFDLFVBQVUsRUFBRTtvQkFDM0gsSUFBSSxDQUFDLGNBQWMsQ0FBQyxjQUFjLENBQUMsUUFBUSxDQUFDLFlBQVksQ0FBQyxDQUFDO2lCQUM3RDthQUNKO1lBQ0QsSUFBSSxDQUFDLGNBQWMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxXQUFXLEVBQUU7Z0JBQ3ZDLElBQUksSUFBSSxDQUFDLE1BQU0sQ0FBQyxJQUFJLEVBQUU7b0JBQ2xCLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxDQUFDO29CQUV4QyxJQUFJLElBQUksQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLEtBQUssRUFBRTt3QkFDeEIsSUFBSSxPQUFPLElBQUksQ0FBQyxNQUFNLEtBQUssV0FBVzs0QkFBRSxJQUFJLENBQUMsTUFBTSxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQztxQkFDdkY7aUJBQ0o7Z0JBRUQsSUFBSSxJQUFJLENBQUMsTUFBTSxDQUFDLFdBQVc7b0JBQUUsSUFBSSxDQUFDLHlCQUF5QixDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsV0FBVyxDQUFDLENBQUM7Z0JBRXJGLElBQUksSUFBSSxDQUFDLE1BQU0sQ0FBQyxJQUFJLEtBQUssT0FBTyxFQUFFO29CQUM5QixJQUFJLENBQUMsc0JBQXNCLEVBQUUsQ0FBQztvQkFDOUIsSUFBSSxDQUFDLFdBQVcsRUFBRSxDQUFDO2lCQUN0QjthQUNKO1lBRUQsSUFBSSxDQUFDLGlCQUFpQixFQUFFLENBQUM7U0FDNUI7UUFFRCxJQUFJLGNBQWMsQ0FBQyxjQUFjLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxjQUFjLENBQUMsTUFBTSxDQUFDLENBQUMsV0FBVyxJQUFJLElBQUksQ0FBQyxNQUFNLENBQUMsSUFBSSxLQUFLLE9BQU8sRUFBRTtZQUM5RyxJQUFJLENBQUMsc0JBQXNCLEVBQUUsQ0FBQztZQUM5QixJQUFJLENBQUMsV0FBVyxFQUFFLENBQUM7U0FDdEI7SUFDTCxDQUFDO0lBRUQsK0JBQWUsR0FBZjtRQUNJLElBQUksSUFBSSxDQUFDLFVBQVUsRUFBRTtZQUNqQixJQUFJLENBQUMsUUFBUSxFQUFFLENBQUM7WUFDaEIsSUFBSSxDQUFDLEdBQUcsQ0FBQyxhQUFhLEVBQUUsQ0FBQztZQUV6QixJQUFJLENBQUMsVUFBVSxFQUFFLENBQUM7U0FDckI7SUFDTCxDQUFDO0lBRUQsMkJBQVcsR0FBWDtRQUNJLE1BQU0sQ0FBQyxtQkFBbUIsQ0FBQyxRQUFRLEVBQUUsSUFBSSxDQUFDLFVBQVUsQ0FBQyxDQUFDO0lBQzFELENBQUM7SUFFTSw2QkFBYSxHQUFwQixVQUFxQixXQUFnQjtRQUNqQyxJQUFJLGdCQUFnQixHQUFnQixJQUFJLENBQUMsV0FBVyxDQUFDLGFBQWEsQ0FBQyxhQUFhLENBQUMsUUFBUSxHQUFHLFdBQVcsQ0FBQyxFQUFFLEdBQUcsa0JBQWtCLENBQUMsQ0FBQztRQUNqSSxJQUFJLGVBQWUsR0FBZ0IsSUFBSSxDQUFDLFdBQVcsQ0FBQyxhQUFhLENBQUMsYUFBYSxDQUFDLFFBQVEsR0FBRyxXQUFXLENBQUMsRUFBRSxHQUFHLG9CQUFvQixDQUFDLENBQUM7UUFDbEksSUFBSSxtQkFBb0QsQ0FBQztRQUV6RCxRQUFRLElBQUksQ0FBQyxNQUFNLENBQUMsSUFBSSxFQUFFO1lBQ3RCLEtBQUssU0FBUyxDQUFDO1lBQ2YsS0FBSyxlQUFlO2dCQUNoQixtQkFBbUIsR0FBRyxJQUFJLENBQUMsZUFBZSxDQUFDLFdBQVcsQ0FBQyxFQUFFLENBQUMsQ0FBQztnQkFDM0QsTUFBTTtZQUNWO2dCQUNJLG1CQUFtQixHQUFHLElBQUksQ0FBQyxPQUFPLENBQUM7Z0JBQ25DLE1BQU07U0FDYjtRQUVELElBQUksSUFBSSxDQUFDLE1BQU0sQ0FBQyxRQUFRLENBQUMsbUJBQW1CLENBQUMsRUFBRTtZQUMzQyxJQUFJLENBQUMsTUFBTSxDQUFDLFdBQVcsQ0FBQyxtQkFBbUIsQ0FBQyxDQUFDO1lBQzdDLElBQUksQ0FBQyxhQUFhLENBQUMsUUFBUSxDQUFDLGdCQUFnQixFQUFFLCtCQUErQixDQUFDLENBQUM7WUFDL0UsSUFBSSxDQUFDLGFBQWEsQ0FBQyxRQUFRLENBQUMsZUFBZSxFQUFFLHFCQUFxQixDQUFDLENBQUM7U0FDdkU7YUFDSTtZQUNELElBQUksQ0FBQyxNQUFNLENBQUMsUUFBUSxDQUFDLG1CQUFtQixDQUFDLENBQUM7WUFDMUMsSUFBSSxDQUFDLGFBQWEsQ0FBQyxXQUFXLENBQUMsZ0JBQWdCLEVBQUUsK0JBQStCLENBQUMsQ0FBQztZQUNsRixJQUFJLENBQUMsYUFBYSxDQUFDLFdBQVcsQ0FBQyxlQUFlLEVBQUUscUJBQXFCLENBQUMsQ0FBQztTQUMxRTtJQUNMLENBQUM7SUFFTywrQkFBZSxHQUF2QixVQUF3QixTQUF1QjtRQUMzQyxJQUFJLENBQUMsU0FBUyxFQUFFO1lBQ1osSUFBSSxDQUFDLFVBQVUsR0FBRyxLQUFLLENBQUM7WUFDeEIsSUFBSSxDQUFDLFVBQVUsR0FBRyxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUM7U0FDdEM7YUFBTTtZQUNILElBQUksSUFBSSxHQUFXLFNBQVMsQ0FBQyxHQUFHLENBQUM7WUFDakMsSUFBSSxJQUFJLEdBQVcsU0FBUyxDQUFDLEdBQUcsQ0FBQztZQUNqQyxJQUFJLENBQUMsVUFBVSxHQUFHLENBQUMsT0FBTyxJQUFJLEtBQUssV0FBVyxDQUFDLElBQUksQ0FBQyxPQUFPLElBQUksS0FBSyxXQUFXLENBQUMsSUFBSSxDQUFDLElBQUksR0FBRyxDQUFDLEdBQUcsSUFBSSxJQUFJLEdBQUcsR0FBRyxDQUFDLElBQUksQ0FBQyxJQUFJLEdBQUcsQ0FBQyxFQUFFLElBQUksSUFBSSxHQUFHLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQztZQUM1SixJQUFJLENBQUMsVUFBVSxHQUFHLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQztTQUN0QztRQUNELElBQUksQ0FBQyxJQUFJLENBQUMsVUFBVSxJQUFJLElBQUksQ0FBQyxNQUFNLEVBQUU7WUFDakMsT0FBTyxJQUFJLENBQUMsTUFBTSxDQUFDO1lBQ25CLE9BQU8sSUFBSSxDQUFDLE1BQU0sQ0FBQztZQUNuQixPQUFPLElBQUksQ0FBQyxPQUFPLENBQUM7WUFDcEIsT0FBTyxJQUFJLENBQUMsZUFBZSxDQUFDO1lBQzVCLE9BQU8sSUFBSSxDQUFDLGFBQWEsQ0FBQztTQUM3QjtJQUNMLENBQUM7SUFFTyx3QkFBUSxHQUFoQjtRQUVJLElBQUksQ0FBQyxNQUFNLEdBQUcsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLGFBQWEsRUFBRTtZQUMxQyxNQUFNLEVBQUUsSUFBSSxDQUFDLFFBQVE7WUFDckIsSUFBSSxFQUFFLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxJQUFJLElBQUksSUFBSSxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLElBQUksRUFBRTtTQUMzRCxDQUFDLENBQUM7UUFFSCxJQUFJLElBQUksQ0FBQyxNQUFNLENBQUMsSUFBSTtZQUFFLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxDQUFDO1FBRTlELElBQUksQ0FBQyxTQUFTLEVBQUUsQ0FBQztRQUNqQixJQUFJLENBQUMsV0FBVyxFQUFFLENBQUM7UUFFbkIsSUFBSSxDQUFDLHlCQUF5QixDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsV0FBVyxDQUFDLENBQUM7UUFDeEQsSUFBSSxJQUFJLENBQUMsTUFBTSxDQUFDLFVBQVUsSUFBSSxJQUFJLENBQUMsTUFBTSxDQUFDLFVBQVUsQ0FBQyxPQUFPLElBQUksSUFBSSxDQUFDLE1BQU0sQ0FBQyxJQUFJLEtBQUssT0FBTztZQUFFLElBQUksQ0FBQyxhQUFhLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxJQUFJLEVBQUUsSUFBSSxDQUFDLE1BQU0sQ0FBQyxVQUFVLENBQUMsUUFBUSxDQUFDLENBQUM7SUFDeEssQ0FBQztJQUVPLDBCQUFVLEdBQWxCO1FBQUEsaUJBS0M7UUFKRyxLQUFLLENBQUMsRUFBRSxDQUFDLENBQUMsU0FBUyxDQUFDO1lBQ2hCLElBQUksT0FBTyxLQUFJLENBQUMsS0FBSyxLQUFLLFdBQVc7Z0JBQUUsS0FBSSxDQUFDLFVBQVUsRUFBRSxDQUFDOztnQkFDcEQsS0FBSSxDQUFDLFFBQVEsRUFBRSxDQUFDO1FBQ3pCLENBQUMsQ0FBQyxDQUFDO0lBQ1AsQ0FBQztJQUVPLHdCQUFRLEdBQWhCO1FBQUEsaUJBS0M7UUFKRyxJQUFJLE9BQU8sSUFBSSxDQUFDLEdBQUcsS0FBSyxXQUFXLElBQUksTUFBTSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUMsTUFBTSxLQUFLLENBQUMsRUFBRTtZQUN2RSxJQUFJLENBQUMsR0FBRyxDQUFDLFNBQVMsR0FBRyxjQUFZLE9BQUEsS0FBSSxDQUFDLFVBQVUsRUFBRSxFQUFqQixDQUFpQixDQUFDO1lBQ25ELElBQUksQ0FBQyxHQUFHLENBQUMsT0FBTyxHQUFHLGNBQWMsT0FBQSxLQUFJLENBQUMsTUFBTSxDQUFDLE9BQU8sRUFBRSxFQUFyQixDQUFxQixDQUFDO1NBQzFEO0lBQ0wsQ0FBQztJQUVPLGdDQUFnQixHQUF4QixVQUF5QixPQUF1QjtRQUM1QyxJQUFJLE9BQU8sSUFBSSxDQUFDLE1BQU0sS0FBSyxXQUFXLEVBQUU7WUFDcEMsT0FBTyxDQUFDLFlBQVksQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxVQUFVLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxhQUFhLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxXQUFXLENBQUMsQ0FBQztZQUM1SCxPQUFPLENBQUMsWUFBWSxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLGVBQWUsQ0FBQyxNQUFNLEVBQUUsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxlQUFlLENBQUMsT0FBTyxFQUFFLENBQUM7WUFDcEcsT0FBTyxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxTQUFTLENBQUMsTUFBTSxFQUFFLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsU0FBUyxDQUFDLE9BQU8sRUFBRSxDQUFDO1lBQ3ZGLE9BQU8sQ0FBQyxpQkFBaUIsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxlQUFlLENBQUMsTUFBTSxFQUFFLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsZUFBZSxDQUFDLE9BQU8sRUFBRSxDQUFDO1NBQzVHO0lBQ0wsQ0FBQztJQUVPLHlCQUFTLEdBQWpCO1FBQ0ksSUFBSSxJQUFJLENBQUMsTUFBTTtZQUFFLElBQUksQ0FBQyxNQUFNLENBQUMsTUFBTSxFQUFFLENBQUM7UUFDdEMsSUFBSSxDQUFDLGFBQWEsR0FBRyxLQUFLLENBQUM7UUFDM0IsSUFBSSxDQUFDLGNBQWMsR0FBRyxJQUFJLENBQUM7UUFDM0IsSUFBSSxDQUFDLE1BQU0sR0FBRyxDQUFDLENBQUMsU0FBUyxDQUFDLG9EQUFvRCxFQUFFO1lBQzVFLFdBQVcsRUFBRSwyRUFBMkU7WUFDeEYsT0FBTyxFQUFFLEVBQUU7U0FDZCxDQUFDLENBQUM7UUFDSCxJQUFJLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUM7UUFDL0IsSUFBSSxDQUFDLG1CQUFtQixFQUFFLENBQUM7SUFDL0IsQ0FBQztJQUVPLHlDQUF5QixHQUFqQyxVQUFrQyxZQUFvQjtRQUNsRCxJQUFJLGtCQUFrQixHQUFZLElBQUksQ0FBQyxXQUFXLENBQUMsYUFBYSxDQUFDLGFBQWEsQ0FBQyw4QkFBOEIsQ0FBQyxDQUFDO1FBQy9HLElBQUksa0JBQWtCLEtBQUssSUFBSSxFQUFFO1lBQzdCLElBQUkscUJBQXFCLEdBQWdCLElBQUksQ0FBQyxhQUFhLENBQUMsYUFBYSxDQUFDLGtCQUFrQixFQUFFLG9CQUFvQixDQUFDLENBQUM7WUFDcEgscUJBQXFCLENBQUMsU0FBUyxHQUFHLFlBQVksSUFBSSxVQUFVLENBQUM7WUFDN0Qsa0JBQWtCLENBQUMsWUFBWSxDQUFDLHFCQUFxQixFQUFFLGtCQUFrQixDQUFDLFVBQVUsQ0FBQyxDQUFDO1NBQ3pGO0lBQ0wsQ0FBQztJQUVPLG1DQUFtQixHQUEzQjtRQUFBLGlCQThCQztRQTdCRyxvRUFBb0U7UUFDcEUsSUFBSSxDQUFDLE1BQU0sQ0FBQyxFQUFFLENBQUMsV0FBVyxFQUFFLFVBQUMsS0FBSztZQUM5QixzREFBc0Q7WUFDdEQsSUFBSSxDQUFDLEtBQUksQ0FBQyxhQUFhLEVBQUU7Z0JBQ3JCLEtBQUksQ0FBQyxhQUFhLEdBQUcsSUFBSSxDQUFDO2dCQUMxQixLQUFJLENBQUMsaUJBQWlCLEVBQUUsQ0FBQztnQkFDekIsSUFBSSxLQUFJLENBQUMsaUJBQWlCLEdBQUcsQ0FBQyxJQUFJLEtBQUksQ0FBQyxpQkFBaUIsS0FBSyxDQUFDLEVBQUU7b0JBQzVELEtBQUksQ0FBQyxTQUFTLEVBQUUsQ0FBQztpQkFDcEI7Z0JBQ0QsSUFBSSxLQUFJLENBQUMsaUJBQWlCLEdBQUcsQ0FBQyxFQUFFO29CQUM1QixLQUFJLENBQUMsVUFBVSxHQUFHLEtBQUssQ0FBQztvQkFDeEIsS0FBSSxDQUFDLFlBQVksR0FBRyx3R0FBd0csQ0FBQztpQkFDaEk7YUFDSjtRQUNMLENBQUMsQ0FBQyxDQUFDO1FBRUgsdUVBQXVFO1FBQ3ZFLElBQUksQ0FBQyxNQUFNLENBQUMsRUFBRSxDQUFDLFVBQVUsRUFBRTtZQUN2QixLQUFJLENBQUMsY0FBYyxFQUFFLENBQUM7WUFDdEIsSUFBSSxLQUFJLENBQUMsY0FBYyxJQUFJLEtBQUksQ0FBQyxjQUFjLEtBQUssTUFBTSxDQUFDLElBQUksQ0FBQyxLQUFJLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxDQUFDLE1BQU0sRUFBRTtnQkFDdkYsK0RBQStEO2dCQUMvRCwrQkFBK0I7Z0JBQy9CLEtBQUksQ0FBQyxjQUFjLEdBQUcsSUFBSSxDQUFDO2dCQUMzQixLQUFJLENBQUMsa0JBQWtCLEVBQUUsQ0FBQztnQkFDMUIsaUJBQWlCO2dCQUNqQixLQUFJLENBQUMsaUJBQWlCLEdBQUcsQ0FBQyxDQUFDO2dCQUMzQixLQUFJLENBQUMsY0FBYyxHQUFHLENBQUMsQ0FBQzthQUMzQjtRQUNMLENBQUMsQ0FBQyxDQUFDO0lBQ1AsQ0FBQztJQUVPLDBCQUFVLEdBQWxCO1FBQUEsaUJBTUM7UUFMRyxJQUFJLElBQUksQ0FBQyxVQUFVLEVBQUU7WUFDakIsS0FBSyxFQUFFLENBQUMsU0FBUyxDQUFDO2dCQUNkLEtBQUksQ0FBQyxNQUFNLENBQUMsY0FBYyxDQUFDLEVBQUUsQ0FBQyxDQUFDO1lBQ25DLENBQUMsQ0FBQyxDQUFDO1NBQ047SUFDTCxDQUFDO0lBRU8sOEJBQWMsR0FBdEIsVUFBdUIsU0FBdUI7UUFDMUMsSUFBSSxJQUFJLENBQUMsTUFBTSxDQUFDLElBQUksS0FBSyxPQUFPLEVBQUU7WUFDOUIsSUFBSSxDQUFDLGNBQWMsR0FBRyxJQUFJLENBQUM7WUFDM0IsSUFBSSxDQUFDLFVBQVUsR0FBRyxpQ0FBaUMsR0FBRyxTQUFTLENBQUMsR0FBRyxDQUFDLFFBQVEsRUFBRSxHQUFHLEdBQUcsR0FBRyxTQUFTLENBQUMsR0FBRyxDQUFDLFFBQVEsRUFBRSxDQUFDO1NBQ25IO2FBQ0k7WUFDRCxJQUFJLENBQUMsY0FBYyxHQUFHLEtBQUssQ0FBQztTQUMvQjtJQUNMLENBQUM7SUFFTyw2QkFBYSxHQUFyQixVQUFzQixXQUEyQixFQUFFLGFBQXFCO1FBQ3BFLElBQUksV0FBVyxHQUFnQixJQUFJLENBQUMsV0FBVyxDQUFDLGFBQWEsQ0FBQyxhQUFhLENBQUMsd0JBQXdCLENBQUMsQ0FBQztRQUN0RyxRQUFRLGFBQWEsRUFBRTtZQUNuQixLQUFLLFVBQVUsQ0FBQztZQUNoQjtnQkFDSSxnR0FBZ0c7Z0JBQ2hHLElBQUksUUFBUSxHQUFXLFdBQVcsSUFBSSxXQUFXLENBQUMsWUFBWSxLQUFLLEtBQUssQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxhQUFhLENBQUM7Z0JBQzlGLElBQUksQ0FBQyxhQUFhLENBQUMsUUFBUSxDQUFDLFdBQVcsRUFBRSwwQkFBMEIsR0FBRyxRQUFRLENBQUMsQ0FBQztnQkFDaEYsTUFBTTtZQUNWLEtBQUssV0FBVztnQkFDWixJQUFJLENBQUMsYUFBYSxDQUFDLFFBQVEsQ0FBQyxXQUFXLEVBQUUsMkJBQTJCLENBQUMsQ0FBQztnQkFDdEUsTUFBTTtZQUNWLEtBQUssYUFBYTtnQkFDZCxJQUFJLENBQUMsYUFBYSxDQUFDLFFBQVEsQ0FBQyxXQUFXLEVBQUUsNkJBQTZCLENBQUMsQ0FBQztnQkFDeEUsTUFBTTtZQUNWLEtBQUssY0FBYztnQkFDZixJQUFJLENBQUMsYUFBYSxDQUFDLFFBQVEsQ0FBQyxXQUFXLEVBQUUsZ0RBQWdELENBQUMsQ0FBQztnQkFDM0YsTUFBTTtTQUNiO0lBQ0wsQ0FBQztJQUVPLDJCQUFXLEdBQW5CO1FBQ0ksSUFBSSxPQUFPLElBQUksQ0FBQyxNQUFNLEtBQUssV0FBVyxFQUFFO1lBQ3BDLFFBQVEsSUFBSSxDQUFDLE1BQU0sQ0FBQyxJQUFJLEVBQUU7Z0JBQ3RCLEtBQUssU0FBUyxDQUFDO2dCQUNmLEtBQUssZUFBZTtvQkFDaEIsSUFBSSxPQUFPLElBQUksQ0FBQyxJQUFJLEtBQUssV0FBVyxJQUFJLE1BQU0sQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDLE1BQU0sS0FBSyxDQUFDLEVBQUU7d0JBQ3pFLElBQUksV0FBVyxHQUE0QixJQUFJLENBQUMsU0FBUyxDQUFDLGVBQWUsQ0FBQyxJQUFJLENBQUMsSUFBSSxFQUFFLElBQUksQ0FBQyxNQUFNLEVBQUUsSUFBSSxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsQ0FBQzt3QkFFcEgsSUFBSSxDQUFDLGFBQWEsR0FBRyxXQUFXLENBQUMsYUFBYSxDQUFDO3dCQUMvQyxJQUFJLENBQUMsZUFBZSxHQUFHLFdBQVcsQ0FBQyxjQUFjLENBQUM7d0JBQ2xELElBQUksQ0FBQyxlQUFlLEdBQUcsSUFBSSxDQUFDO3FCQUMvQjtvQkFDRCxNQUFNO2dCQUNWO29CQUNJLElBQUksV0FBVyxHQUFlO3dCQUMxQixXQUFXLEVBQUUsUUFBUTt3QkFDckIsS0FBSyxFQUFFLElBQUksQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLEtBQUs7cUJBQ2xDLENBQUM7b0JBQ0YsSUFBSSxVQUFVLEdBQVcsSUFBSSxDQUFDLFNBQVMsQ0FBQyxPQUFPLENBQUMsV0FBVyxDQUFDLENBQUM7b0JBQzdELElBQUksQ0FBQyxPQUFPLEdBQUcsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsUUFBUSxFQUFFLEVBQUUsSUFBSSxFQUFFLFVBQVUsRUFBRSxDQUFDLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQztvQkFDaEYsSUFBSSxDQUFDLGVBQWUsR0FBRyxJQUFJLENBQUM7b0JBQzVCLElBQUksSUFBSSxDQUFDLE1BQU0sQ0FBQyxjQUFjLENBQUMsU0FBUyxDQUFDLEVBQUU7d0JBQ3ZDLElBQUksQ0FBQyxPQUFPLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDLENBQUM7cUJBQy9DO29CQUVELElBQUksSUFBSSxDQUFDLE1BQU0sQ0FBQyxjQUFjLENBQUMsUUFBUSxDQUFDLEVBQUU7d0JBQ3RDLElBQUksQ0FBQyxhQUFhLEdBQUcsQ0FBQztnQ0FDbEIsSUFBSSxFQUFFLFVBQVUsQ0FBQyxVQUFVLEVBQUU7Z0NBQzdCLEtBQUssRUFBRSxJQUFJLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxLQUFLO2dDQUMvQixFQUFFLEVBQUUsSUFBSSxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsY0FBYyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLG1CQUFtQjs2QkFDNUYsQ0FBQyxDQUFDO3FCQUNOO29CQUNELE1BQU07YUFDYjtTQUVKO1FBRUQsSUFBSSxDQUFDLGtCQUFrQixFQUFFLENBQUM7SUFDOUIsQ0FBQztJQUVPLGtDQUFrQixHQUExQjtRQUNJLElBQUksSUFBSSxDQUFDLGVBQWUsSUFBSSxJQUFJLENBQUMsY0FBYyxFQUFFO1lBQzdDLElBQUksQ0FBQyxjQUFjLEdBQUcsS0FBSyxDQUFDO1NBQy9CO0lBQ0wsQ0FBQztJQUVPLHNDQUFzQixHQUE5QjtRQUNJLEtBQUssSUFBSSxZQUFZLElBQUksSUFBSSxDQUFDLGVBQWUsRUFBRTtZQUMzQyxJQUFJLElBQUksQ0FBQyxlQUFlLENBQUMsWUFBWSxDQUFDO2dCQUFFLElBQUksQ0FBQyxNQUFNLENBQUMsV0FBVyxDQUFDLElBQUksQ0FBQyxlQUFlLENBQUMsWUFBWSxDQUFDLENBQUMsQ0FBQztTQUN2RztRQUVELElBQUksQ0FBQyxhQUFhLEdBQUcsRUFBRSxDQUFDO0lBQzVCLENBQUM7SUFFTyxpQ0FBaUIsR0FBekI7UUFDSSxJQUFJLENBQUMsU0FBUyxHQUFHLElBQUksQ0FBQyxTQUFTLENBQUMsZ0JBQWdCLEVBQUUsQ0FBQztRQUNuRCxJQUFJLENBQUMsUUFBUSxDQUFDLGVBQWUsQ0FBQyxJQUFJLENBQUMsU0FBUyxFQUFFLElBQUksQ0FBQyxNQUFNLEVBQUUsS0FBSyxDQUFDLENBQUM7UUFFbEUsSUFBSSxDQUFDLFNBQVMsQ0FBQyxNQUFNLENBQUMsT0FBTyxHQUFHLElBQUksQ0FBQyxXQUFXLENBQUMsUUFBUSxFQUFFLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQztRQUN0RSxJQUFJLElBQUksQ0FBQyxTQUFTLENBQUMsTUFBTTtZQUFFLElBQUksQ0FBQyxTQUFTLENBQUMsTUFBTSxDQUFDLE9BQU8sR0FBRyxJQUFJLENBQUMsV0FBVyxDQUFDLFFBQVEsRUFBRSxDQUFDLGFBQWEsRUFBRSxVQUFVLENBQUMsQ0FBQyxDQUFDO1FBRW5ILElBQUksQ0FBQyxjQUFjLEVBQUUsQ0FBQztJQUMxQixDQUFDO0lBRU8sMkJBQVcsR0FBbkIsVUFBb0IsT0FBZSxFQUFFLFNBQXdCO1FBQ3pELElBQUksSUFBSSxDQUFDLFNBQVMsQ0FBQyxPQUFPLENBQUMsSUFBSSxPQUFPLElBQUksQ0FBQyxTQUFTLENBQUMsT0FBTyxDQUFDLENBQUMsT0FBTyxLQUFLLFdBQVcsRUFBRTtZQUNuRixPQUFPLElBQUksQ0FBQyxTQUFTLENBQUMsT0FBTyxDQUFDLENBQUMsT0FBTyxDQUFDO1NBQzFDO1FBRUQsS0FBSyxJQUFJLENBQUMsR0FBVyxTQUFTLENBQUMsTUFBTSxHQUFHLENBQUMsRUFBRSxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFO1lBQ3BELElBQUksSUFBSSxDQUFDLFNBQVMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxJQUFJLENBQUMsU0FBUyxDQUFDLE9BQU8sQ0FBQyxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksS0FBSyxFQUFFLEVBQUU7Z0JBQzVGLE9BQU8sSUFBSSxDQUFDO2FBQ2Y7U0FDSjtRQUVELElBQUksT0FBTyxLQUFLLFFBQVEsSUFBSSxJQUFJLENBQUMsYUFBYSxDQUFDLE1BQU0sS0FBSyxDQUFDLEVBQUU7WUFDekQsT0FBTyxLQUFLLENBQUM7U0FDaEI7UUFFRCxPQUFPLEtBQUssQ0FBQTtJQUNoQixDQUFDO0lBRUQsb0ZBQW9GO0lBQzVFLDhCQUFjLEdBQXRCO1FBRUksb0RBQW9EO1FBQ3BELElBQUksQ0FBQyxTQUFTLEdBQUcsRUFBRSxDQUFDO1FBRXBCLElBQUksT0FBTyxJQUFJLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxLQUFLLEtBQUssV0FBVyxJQUFJLElBQUksQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLEtBQUssRUFBRTtZQUM3RSxJQUFJLENBQUMsU0FBUyxJQUFJLGVBQWUsQ0FBQztTQUNyQztRQUVELElBQUksT0FBTyxJQUFJLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxhQUFhLEtBQUssV0FBVyxFQUFFO1lBQ3pELElBQUksQ0FBQyxTQUFTLElBQUksSUFBSSxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsYUFBYSxHQUFHLEdBQUcsQ0FBQztTQUM1RDtRQUVELElBQUksT0FBTyxJQUFJLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxLQUFLLEtBQUssV0FBVyxFQUFFO1lBQ2pELElBQUksQ0FBQyxTQUFTLElBQUksSUFBSSxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDO1NBQzlDO0lBQ0wsQ0FBQzs7Z0JBcld3QixVQUFVO2dCQUNiLGVBQWU7Z0JBQ1YsWUFBWTtnQkFDaEIsUUFBUTtnQkFDZCxpQkFBaUI7Z0JBQ1osU0FBUzs7SUFkdEI7UUFBUixLQUFLLEVBQUU7OzJDQUF3QjtJQUN2QjtRQUFSLEtBQUssRUFBRTs7eUNBQW9CO0lBQ25CO1FBQVIsS0FBSyxFQUFFOzt1Q0FBdUI7SUFDdEI7UUFBUixLQUFLLEVBQUU7O3NDQUFjO0lBRUY7UUFBbkIsU0FBUyxDQUFDLE9BQU8sQ0FBQztrQ0FBUSxVQUFVO3dDQUFDO0lBQ1Y7UUFBM0IsV0FBVyxDQUFDLGFBQWEsQ0FBQzs7NkNBQXFCO0lBdEN2QyxLQUFLO1FBNUNqQixTQUFTLENBQUM7WUFDUCxRQUFRLEVBQUUsUUFBUTtZQUNsQiwrakhBQW9DO1lBQ3BDOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O2dCQStCSTtZQUNKLGFBQWEsRUFBRSxpQkFBaUIsQ0FBQyxJQUFJO1lBQ3JDLElBQUksRUFBRTtnQkFDRixPQUFPLEVBQUUsU0FBUztnQkFDbEIsMEJBQTBCLEVBQUUseUNBQXlDO2dCQUNyRSxxQkFBcUIsRUFBRSxvQ0FBb0M7YUFDOUQ7WUFDRCxTQUFTLEVBQUUsQ0FBQyxZQUFZLEVBQUUsUUFBUSxFQUFFLFNBQVMsQ0FBQztTQUNqRCxDQUFDO3lDQTJDMkIsVUFBVTtZQUNiLGVBQWU7WUFDVixZQUFZO1lBQ2hCLFFBQVE7WUFDZCxpQkFBaUI7WUFDWixTQUFTO09BOUN0QixLQUFLLENBZ1pqQjtJQUFELFlBQUM7Q0FBQSxBQWhaRCxJQWdaQztTQWhaWSxLQUFLIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHtcclxuICAgIENvbXBvbmVudCxcclxuICAgIFZpZXdFbmNhcHN1bGF0aW9uLFxyXG4gICAgSW5wdXQsXHJcbiAgICBPbkluaXQsXHJcbiAgICBPbkNoYW5nZXMsXHJcbiAgICBTaW1wbGVDaGFuZ2VzLFxyXG4gICAgT25EZXN0cm95LFxyXG4gICAgRWxlbWVudFJlZixcclxuICAgIEFmdGVyVmlld0luaXQsXHJcbiAgICBWaWV3Q2hpbGQsXHJcbiAgICBIb3N0TGlzdGVuZXIsXHJcbiAgICBIb3N0QmluZGluZyxcclxuICAgIENoYW5nZURldGVjdG9yUmVmXHJcbn0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XHJcbi8vIGltcG9ydCB7IFN1YnNjcmlwdGlvbiB9IGZyb20gJ3J4anMvU3Vic2NyaXB0aW9uJztcclxuaW1wb3J0IHsgdGltZXIgfSBmcm9tICdyeGpzJztcclxuLy8gaW1wb3J0IHsgZGVib3VuY2VUaW1lIH0gZnJvbSAncnhqcy9vcGVyYXRvcnMnO1xyXG5pbXBvcnQgKiBhcyBMIGZyb20gJ2xlYWZsZXQnO1xyXG5pbXBvcnQgJ2xlYWZsZXQubWFya2VyY2x1c3Rlcic7XHJcbmltcG9ydCAnbGVhZmxldC5hd2Vzb21lLW1hcmtlcnMvZGlzdC9sZWFmbGV0LmF3ZXNvbWUtbWFya2Vycyc7XHJcbmltcG9ydCB7IEtkU3BsaXR0ZXJFdmVudCB9IGZyb20gJy4uL2tkLWFuZ3VsYXItc3BsaXR0ZXIvaW5kZXgnO1xyXG5pbXBvcnQgeyBLZERvbUVsZW1TdmMgfSBmcm9tICcuLi9rZC1jb21tb24vaW5kZXgnO1xyXG5pbXBvcnQgeyBLZE1hcFN2YywgSU1hcFBvcHVsYXRlQ2x1c3RlckRhdGEgfSBmcm9tICcuL2tkLWFuZ3VsYXItbWFwLXN2Yyc7XHJcbmltcG9ydCB7XHJcbiAgICBJTWFwQ29uZmlnLFxyXG4gICAgSU1hcFBvc2l0aW9uLFxyXG4gICAgSU1hcENsdXN0ZXJEYXRhLFxyXG4gICAgSU1hcFpvb21Db25maWcsXHJcbiAgICBJTWFwQXBpLFxyXG4gICAgSU1hcE1hcmtlcixcclxufSBmcm9tICcuL2tkLWFuZ3VsYXItbWFwLWludGVyZmFjZSc7XHJcbmltcG9ydCB7IEtkRGF0YVN2YyB9IGZyb20gJy4uL2tkLWNvbW1vbi9pbmRleCc7XHJcblxyXG5AQ29tcG9uZW50KHtcclxuICAgIHNlbGVjdG9yOiAna2QtbWFwJyxcclxuICAgIHRlbXBsYXRlVXJsOiAnLi9rZC1hbmd1bGFyLW1hcC5odG1sJyxcclxuICAgIC8qdGVtcGxhdGU6IGBcclxuICAgICAgICAgICAgPGRpdiBjbGFzcz1cImhlYWRlci1jb250YWluZXJcIj5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJjaGFydC10aXRsZSBsZWZ0XCI+e3tjb25maWcubGVnZW5kLnRpdGxlLnRleHR9fTwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cImNoYXJ0LXN1YnRpdGxlIHJpZ2h0XCI+e3tjb25maWcubGVnZW5kLnRpdGxlLnRleHR9fTwvZGl2PlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPGRpdiAqbmdJZj1cImlzTWFwU2hvd25cIiBjbGFzcz1cImNoYXJ0LWNvbnRhaW5lclwiICAjbXlNYXA+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwibGluay13cmFwcGVyXCIgKm5nSWY9XCJpc0xpbmtUb0dvb2dsZVwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxhIFthdHRyLmhyZWZdPVwiZ29vZ2xlTGlua1wiIHRhcmdldD1cIl9ibGFua1wiIGNsYXNzPVwiZ29vZ2xlLWxpbmsgbGVhZmxldC1iYXIgbGVhZmxldC1jb250cm9sXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxpbWcgY2xhc3M9XCJnb29nbGUtaW1hZ2VcIiBbc3JjXT1cImdvb2dsZUltYWdlXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9hPlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzPVwibGVnZW5kLWNvbnRhaW5lciBjZW50ZXJcIiAqbmdJZj1cImNvbmZpZy5sZWdlbmQgJiYgaXNNYXBTaG93blwiPlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cImxlZ2VuZHNcIj5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwibGVnZW5kLXRpdGxlLWNvbnRhaW5lciByaWdodFwiICpuZ0lmPVwiY29uZmlnLmxlZ2VuZC50aXRsZS50ZXh0XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJ0aXRsZVwiPnt7Y29uZmlnLmxlZ2VuZC50aXRsZS50ZXh0fX08L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwibGVnZW5kXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJsZWdlbmQtaXRlbVwiIGlkPVwia2RsaS17e2xlZ2VuZEl0ZW0uaWR9fVwiICpuZ0Zvcj1cImxldCBsZWdlbmRJdGVtIG9mIG1hcmtlcnNMZWdlbmRcIiAoY2xpY2spPVwib25MZWdlbmRDbGljayhsZWdlbmRJdGVtKVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cImxlZ2VuZC1tYXJrZXJcIiBbaW5uZXJIVE1MXT1cImxlZ2VuZEl0ZW0uaWNvbi5vdXRlckhUTUxcIiA+PC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwibGVnZW5kLWxhYmVsXCI+PGRpdiBjbGFzcz1cImxhYmVsLXRleHRcIj57e2xlZ2VuZEl0ZW0ubGFiZWx9fTwvZGl2PjwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPGRpdiAqbmdJZj1cIiFpc01hcFNob3duXCIgY2xhc3M9XCJlcnJvci1tYXBcIj5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJlcnJvci1pY29uXCI+PGkgY2xhc3M9XCJmYSBmYS1tYXAtb1wiPjwvaT48L2Rpdj5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJlcnJvci1tZXNzYWdlXCI+e3tlcnJvck1lc3NhZ2V9fTwvZGl2PlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPGtkLXByb2dyZXNzbG9hZGVyICpuZ0lmPVwiaXNMYXllckxvYWRpbmcgJiYgaXNNYXBTaG93blwiIGNvbmZpZ3R5cGU9XCJzbWFsbC1zcGlubmVyXCIgW2NvbmZpZ3ZhbHVlXT1cInNtYWxsTG9hZGVyVmFsdWVcIj48L2tkLXByb2dyZXNzbG9hZGVyPlxyXG5cclxuICAgIGAsKi9cclxuICAgIGVuY2Fwc3VsYXRpb246IFZpZXdFbmNhcHN1bGF0aW9uLk5vbmUsXHJcbiAgICBob3N0OiB7XHJcbiAgICAgICAgJ2NsYXNzJzogJ2tkeC1tYXAnLFxyXG4gICAgICAgICdbc3R5bGUuYmFja2dyb3VuZC1jb2xvcl0nOiAnbWFwQ29uZmlnLm1hcEFyZWEuc3R5bGUuYmFja2dyb3VuZENvbG9yJyxcclxuICAgICAgICAnW3N0eWxlLmZvbnQtZmFtaWx5XSc6ICdtYXBDb25maWcubWFwQXJlYS5zdHlsZS5mb250RmFtaWx5J1xyXG4gICAgfSxcclxuICAgIHByb3ZpZGVyczogW0tkRG9tRWxlbVN2YywgS2RNYXBTdmMsIEtkRGF0YVN2Y11cclxufSlcclxuXHJcbmV4cG9ydCBjbGFzcyBLZE1hcCBpbXBsZW1lbnRzIE9uSW5pdCwgT25DaGFuZ2VzLCBBZnRlclZpZXdJbml0LCBPbkRlc3Ryb3kge1xyXG5cclxuICAgIC8vIHByaXZhdGUgc3RhdGljIG1hcFBpbkltYWdlOiBzdHJpbmcgPSAnZGF0YTppbWFnZS9wbmc7YmFzZTY0LGlWQk9SdzBLR2dvQUFBQU5TVWhFVWdBQUFCa0FBQUFwQ0FZQUFBREFrNExPQUFBRmdVbEVRVlI0QWExWEE1QmpXUlROMm9XMTdkM1lhWnRyMjk2MkhVemJETnBqc3pXMjRtUnQyOHA0N3Y3enEvYlhadHJwL2xXblhyMzM3ajNuUENlODVOY3lwZ1NGZHVnQ3BXNVlvREFNUmFJTXFSaTZhS3E1RTNZcURRTzNxQXdqVldyRDhOY3EvUkJweWtkOG9aVWIva2FKdXRvdzhyMWFQOUlJMFdtTEtMSXNKeXYxdy9rcXc5Q2gyTVlkQisrMTJPbnhlZS9RTXd2ZjQvRGsvTGZwL2k0bnhUWHRPb1E0cFc1QWo3d3BpY2kxQTllcmRBTjJPSDY0eDhPU1A5ajNGdDNiN2FXa1RnL0ZtOTFzaVRyYTBmOW9uNXNRcjlJTmVqSDZDVVVVcGF2akZOcTFCK09hZGh4bW5mYThSZkVtTjhWTkFzUWhQcUY1NXhIa016ejNqU21DaFdVNmY3L1haS05IKzkraEJMT0hZb3p1S1FQeHlNUFVLa3JYL0swdVduZkZhSkdTMVFQUnRac09QdHIzTnNXMHV5aDZOTkNPa1UzWXorYlhiVDNJOEczeEU1RVhMWHRDWGJicXdDTzl6UFFZUFJUWjV2SURYRDdVK3c3ckZERW9VVWY3aWJISVI0eTZiTFZQWHJ6OEpWWkVxbDEzdHJ4d3VlL3VEaXZkM2ZrV1JiUzYvSUEyYklENHVrMFVwRjFOOHFMbGJCbFhzNEVlN0hMVGZWMWo1NEFQdk9EblNmT1dCcXRLVnZqZ0xLekY1WWRFazVld1JrR2xLMGkzM0VvZmZmYzdIVDU2akQ3LzZVK3FIM0N4N1NCTE5udEg1WUlQdk9EbnlmSVhaWVJWRFBxZ0h0THM1QUJIRDNZekx1ZXNwYjd0NzlGWTM0RGpNd3JWcmNUdXdsVDU1WU1Qdk9CblJySjRWWFRkTm5ZdWc1dWNITEJqRXB0MzA3MDFBM1RzK0hFYTczdTZkVDNGTld3ZmxZODZlTUhQaytZdStpNnB6VXBSclc3U05EZzVKSFI0S2FwbU01V3YyRThUZmNiMUhvcXFITUhVK3VXREQ3emc1NG16NS8yQlNuaXppOVQxRGc0UVFYTFRvR05Da2I2dGIxTlUrUUFsR3IxKytlQURyemhuL3U4UTJZWmhRVmxaNStDQU90cWZiaG1hVUNTMWV6TkZWbTJpbURiUG1Qbmc1d216K2d3aCtvSERjZTBlVXRRNk9HREl5UjB1VWhVc29PM3ZmRG1tZ09lekgwbVpONTl4N01CaSsrV0RMMWcvZUVpVTNhdmxpZE82NzFia0xmd2J3NVhWMlA4UHpvMHlkeTR0Mi8wZXUzM3hZU09NT0Q4aFRmNENyQnRHTVNvWGZQTGNoWCtKMHJ1U2VQdzNMWmVLMGp1UEpiWXpyaGtIMGlvN0IzazE2NGhpR3Zhd2hPS01Ma3JRTHlWcFpnOHJIRlc3RTJ1SE9MODg4SUJQbE5aMUZQenN0U0pNNjk0ZldyNlJ3cHZjSks2MCswSENJTFRCelpMRk5kdEF6SmFvaHplNjBUOHFCenloNVp1T2c1ZTd1d1FwcG9mRW1mMisrRFl2bXlTcUdCdUthaWNGMWJsUWpodUhkdkNJTXZwOHdoVFRmWnpJN1JsZHB3dFN6TCtGMSt3a2RaMlRCT1cyZ0lGODhQQlR6RC9ncGVSRUFNRWJ4bkpjYUpITkhycHpqaTBnUUNTNmhka0VlWXQ5REYvMnFQY0VDOFJNMjhId21yM3NkTnlodDAwYnlBdXQyazNndWZXTnRndE9FT0ZHVXdjWFdORGJkTmJwZ0JHeEV2S2tPUXN4aXZKeDMzaW93MFZ3NVM2U1ZUcnBWcTExeXNBMlJwN2dUZlBma3RjNnpodFhCQkMrYWRSTHNoZjZzRzJSZkhQWjVFQWM0c1ZaODN5Q04wMEZrLzRrZ2d1NDBaVHZJRW01ZzI0cXRVNEtqQnJ4L0JUVEg4aWZWQVNBRzdnS3JuV3hKRGNVN3g4WDZFY2N6aG0zbzZZaWN2c0xYV2ZoM0NoMVcwazh4MG5YRiswZkZ4Z3Q0cGh6OFF2eXBpd0NDRktNcVhDbnFYRXhqcTEwYmVIK1VVQTcrbkc2bWRHL1B1MGYzTGdGY0dybDJzMGtOTmpwbW9KOW80QjI5Q01POGRNVDRRNW94OHVpdEY2ZnFzckpPcjhxbndOYlJ6djZoU25HNXdQKzY0QzdoOWxwMzBoS050S2RXanRka2J1UEExOW5KN1R6M3pSL2liZ0FSYmhiNEFsaGF2Y0JlYm1USGNGbDJmdllFblcwb3g5eE14S0JTOGJ0SitLaUVicTl6QTRSdGhRWERoUGEwVDlURWU2OWdXdXB3YzZ1QlVwaHF1WGdmKy9Gcklqd2VIUVM0L3BkdU1lNUVSVU1IVWQ5eHY4WlI5OEN4a1M0RjJuM0VVclVaMTBFWU53N0JXbTl4MUdpUHNzaTNHZ2lHUkRLV1JZWmZYbE9OK2RmTmJNK0dnSXdZZHdBQUFBQVNVVk9SSzVDWUlJPSc7XHJcbiAgICAvLyBwcml2YXRlIHN0YXRpYyBtYXBQaW5TaGFkb3dJbWFnZTogc3RyaW5nID0gJ2RhdGE6aW1hZ2UvcG5nO2Jhc2U2NCxpVkJPUncwS0dnb0FBQUFOU1VoRVVnQUFBQ2tBQUFBcENBUUFBQUFDYWNoOUFBQUNNVWxFUVZSNEFlM1NoWTdqUUJBRTBBb3ovZjkvSFRNemhnMXpyZEtVckpiZHgrS2QybkQ4Vk51ZGZzTC9UaC8vL2R5UU4yVEg2ZjN5L0JHcEMzNzlyVitTK3FxZXRCT3hJbU5RWEw4SkNBcjJWNGlNUVhIR05KeGVDZlpYaFNSQmNRTWZ2a09XVWR0ZnpsTGdBRU5tWkRjbW8yVFZtdDhPU00yZVh4QnAzRGpIU01GdXRxUzdTYm1lbXpCaVIreHBLQ05VSVJrZGtrWXhoQWt5R29CdnlRRkVKRWVmd1NtbXZCZkp1SjZhS3FLV25Ba3ZHWk9hWlhUVWdGcVlVTFdOU0hVY2tadVIxSElJaW1VRXh1dFJ4d3pPTFJPSUc0dkttQ0tRdDM2NG1JbGhTeXpBZjFtOWxIWkhKWnJsQU9NTXp0UlJpS2ltcC9ycGRKRGM5QXdyeTV4VFpDdGU3Rkh0dVM4d0pnZVlHcmV4Mjh4TlRkMDg2RGlrN3ZVTXNjUU9hOHk0RG9HdENDU2tBS2xOd3BnTnRwaGpyQzZNSUhVa1I2WVd4eHM2U2M1eHFuMjIybW1DUkZ6SXQ4bEVkS3graWtDdGc5MXFTMldwd1ZmQmVsSkNpUUp3dnppeGZJOWN4WlFXZ2lTSmVsS253QkVsS1l0RE9iMk1GYmhtVWlnYlJlUUJWMENnNCtxTVhTeFhTeUdVbjRVYkY4bCs3cWRTR25UQzBYTENtYWhJZ1VITGhMT2hwVkN0dzRDellYdkxRV1FiSk5teG9Dc09LQXhTZ0JKbm83NWF2b2xrUnc4aUlBRmNzZGMwMmU5aXlDZDh0SHdtZVNTb0tUb3dJZ3ZzY1NHWlVPQTdQdUNONWIyQlg5bVFNN1Mwd1loTU5VNzR6Z3NQQmozSFU3d2d1QWZueHhqRlFHQkU2cHdOK0dqTUU5ekhZN3pHcDh3VnhNU2hZWDlOWHZFV0QzSGJ3SmY0Z2lPNENGSVF4WFNjSDEvVE0rMDRra0JpQUFBQUFFbEZUa1N1UW1DQyc7XHJcblxyXG4gICAgcHVibGljIHNtYWxsTG9hZGVyVmFsdWU6IGFueSA9IG51bGw7XHJcbiAgICBwdWJsaWMgaXNNYXBTaG93bjogYm9vbGVhbiA9IHRydWU7XHJcbiAgICBwdWJsaWMgaXNMYXllckxvYWRpbmc6IGJvb2xlYW4gPSB0cnVlO1xyXG4gICAgcHVibGljIGlzTGlua1RvR29vZ2xlOiBib29sZWFuID0gZmFsc2U7XHJcbiAgICBwdWJsaWMgZ29vZ2xlTGluazogc3RyaW5nID0gJyc7XHJcbiAgICBwdWJsaWMgZXJyb3JNZXNzYWdlOiBzdHJpbmcgPSAnJztcclxuICAgIHB1YmxpYyBnb29nbGVJbWFnZTogc3RyaW5nID0gJ2RhdGE6aW1hZ2UvcG5nO2Jhc2U2NCxpVkJPUncwS0dnb0FBQUFOU1VoRVVnQUFBRElBQUFBeUNBWUFBQUFlUDRpeEFBQUFCSE5DU1ZRSUNBZ0lmQWhraUFBQUFBbHdTRmx6QUFBT2F3QUFEbXNCVlA0TkJnQUFBQmwwUlZoMFUyOW1kSGRoY21VQWQzZDNMbWx1YTNOallYQmxMbTl5WjV2dVBCb0FBQWF0U1VSQlZHaUI3WmxiYkJ6VkdjZC9aMlpuN0wzNEhteXl1OTdjSElmRWpkTllNWFV3UkxhU1V0SkMxWW9RcXcxdEtWSXB5VVBWY2xGTEx5cVIwenhVbFlKVUtZSUlxUS9saFZEb1JTMk5paUV1SUlwSjBseE1HeUFiQW9udHBOU1gyUEY2dmJjNWZYREg4V1ZtZHRaZUs2M2svOVBaNzV6em5lKzMzNWx2enA2RlJmMXZTZHpvQUFDNnR6UldlNFQ0RXNodFFEVlFBZ3dEbDZTVWY5RVU5ZmVyTzd0Nm5IemNVSkQzbWpjRzhYajJTbmdBOERnTVRRRy9rb2J4NUxvM1RseTJHbkREUVA3UjJyaFZNVGdNbE9jd2JVQklzZk9XMTk5NWJXYkhEUUY1cjNWVHN6VEVxMERCSEthUFM2RzBydXZzZW51cTBSRWsrTXg5RVVVb2p3bG9rRklVem1IUldhcUtwYlNEUjNyV0ZTY01wNjJVVFZjTXdjYTZ6bU5YVElPdHMrQXo5MFVVbEZOSXlpUUFjaDdyWHRmWHU0Y29UaGp6ZFhPektta0h2bVVhYkVFVXhLTkEyVXo3RW04eFgxeDFHK3VYckVSVkZNNE45ZkxuQzExRXIvWmxYYjB5bG1icmhXdU9ZeVF3bGpId3FZcmpkcEh3alhNdG45bHJWak9IOUlxNm1aWjdWOS9CdnRzZkpLQjVwOWtmMjdTVFg1NzhMYjg0ZnRneHlDMFhZNmcyaVpYQXU3RTRaNjZOazVBR0JZcWdQdUNsemxlSUlpeVJ0QlNaSGNCVEFJbzlCK3BNaUFPdGV3aG9YdUxwQkgvcit5ZXZYanhKZjN5RWpNeHcrdC9uSFNFQU52NHJidHQzZWpUT3NaRXhFbkppMnlVTXliR1JNYzdFN09jSUtiYWFiVmNQWEVtQm4vYm1ieUlRblB3a3l1Nk9wK2dkN1FmQXJ4VlNVeHB5QlZJWlMxdmF6V3hZcVh0MG5QcUF6K1libHhHelpaK1JLZnJDaWlhS2RCOWo2UVFQZHh5WWhBQ0lwY1pkUVFBVXBhd2Y4cmhoa0RTczkxeEtTdUladStJZ0tzeVdxNHlzcTFnR3dLbFBvdlNORGt6YVQ5ei9OSlcrMG1sakQ1MzVJKzF2UDJmcFowd1ZWRmpZdllxQ3JnaExHRTBJdktwTlBwQWpadHRWUnN5SExXTmtMNXVhWXYvZGZGeXFXOW9GOE9tQTE3S3ZvY2h1VzRGQXZHdTJYV1VrZXJVWGdBMlZLeWtwOERPY2lBRncvOHY3OFNnZWROWERjOXVmSUtCNzZabXk3V2FxTStMbjlrc3h5NzQ2dnhmSnhFT2ZOQ1M2SXRnUThMTFdaLy95RjBKT2xrbFhHZm5UaDEzRTB3bUtkVDhIV3ZaTWx0K3pneGZwN3YrUXU1WTNFdEM5U0NTZGwwN1orbmt6RXFEZnExcjJDV0M5Mzh1dXFuTGFLc3ZZVlZYT2VyL1hydlFDOUZ3bThEdnpnN1ZYb1BpZVR6MEFMSWVKQnpxZVR0SlN2WUZWcFVGMjFHNWhUWG1ZcG1BZGp6ZnU1TzZWVFFEOElmb1d2ejdiWVFzaUJmZzEyTkRyVUZJQlhSRlpENEZTeWgvZSt0ZTN1c3pQcnM4N3ozYS9USkh1NDdzTjkzS3p2NXkyTmEzVCtqc3ZuZVlIYno3cjZLTkt6L0JnV3hKOVdDSDIvcnlPS2Erc2ZmMzR3YW1HbkE1dUIwNzhoaU1YM3FIdGxsWnF5OEtrTW1uNllnTWN1WENNTjNyUFlFajc4MWlWbnVINStnRlcrZElrdjZyeDBmNGtSbUpPNTdkcmhzanNFVE1PZjdZWkRCOXFPNHFrWlM0cnpkUlVpTWxvL3A2aDkxQXFkMmVLM0xIMjZQRVhaNW5uRmFFTFZWcEFBQlExcVBnM2wrVGthNmloUG1rRkFRc01VcWxuT0d3QkFSQXpJZ3g4K1FtTXBVRlh2b3hna0o1NzdoNno2MTh3a0d3UUg0dy9SRm9Oa0dqYkJVcVdNRlNWOGJhdllYaHNpK3pDZ0RoQ3lHVjhNUDRRR1RueGd6TlR2WXhVeTlaWjQ2WXEyYm9OSTF6dE9DYnZJRTRRR1gwTjhZcDlvUGluMlJPZjNZNVJiblVLQTZOaUNhbHRkMlZkTjY4ZzJTQkd5L2JpMFVzSWg2cFIxU25iUk5kSjNibmQwbWZ5YzU5SGFscld0Zk1HNGdaQ0NoOEFtcVlUWEJxYUJwTnFhTVFvbVY3RmpKSlMwaHMzdVZvL0x5Qk9FTzhQcnVGMDhqcUVxWUtDUXNLaHlIVVlWU1hkMUR4dFRHcHpjL1pDOEYvTkc4UUo0bXgvTGQvcmFPZkhMd1E0ZDJYMlhFM1Rwc0drR3B2QVBDUXFDdWxiYjNNZHg3eEFza0U4K3RvK1lra2ZzUVQ4OUFVbEs0d3NLOGNJaFFFd3doRmtpZnNYNXB4QjNFS1ljZ3VUcnFrRklGT3pPcWQ0NWdTU0s0UXBOekNzV0FsTXZGOXlVYzRnYzRVd2xRMm1hdE5tWUdKcjVhS2NRT1lMWWNvSnBpQVVwdmhIZXhFMzNaUkxhTzVCOGdWaHlnbkcxN2g1OWtzemkxeUI1QnZDbFBNMjB3bmxBSk1WWktFZ1REbkI2RG5BT0lMWS9TaUMvRUNZeWdlTUxVaDFZVVovdm42QW1nV0dNSlVOWm1rd1JJRkh0NDNYdHVQbk5WZHJyQ0NpUXl2NC90RW44d3BoS3BhQTlwY1VQcmE0NHl2VUN3bFhoV3p2R0d4QjRvYVk5ZTlwZEdnNWozVDhqT0ZFOFZ4anphcmhNZmpKWVd1WW52SEJxTjA4VzVCbzNQUHdTRVpNWHJtY3Z4cmhrWTc5Q3dwaHlvVDVxUC82M2RkSWNreEdCL3QyMjgxeHZOQTcrTXIycGxwZittazlWYlZxZjlmdTFOQjRJRDkvSkxwVW1VOFYzN2xUMHhLZXkrZWpnNWUvL2ZnZFgrbktQbXRSaTFyVW92NGY5QitJQk1uVklKVjJuQUFBQUFCSlJVNUVya0pnZ2c9PSc7XHJcblxyXG4gICAgcHVibGljIG1hcmtlcnNMZWdlbmQ6IEFycmF5PGFueT4gPSBbXTtcclxuXHJcbiAgICBwdWJsaWMgaHRtbENsYXNzOiBzdHJpbmcgPSAnJztcclxuXHJcbiAgICBwdWJsaWMgbWFwQ29uZmlnOiBJTWFwQ29uZmlnO1xyXG5cclxuICAgIHByaXZhdGUgX215TWFwOiBMLk1hcDtcclxuICAgIHByaXZhdGUgX21hcmtlcjogTC5NYXJrZXI7XHJcbiAgICBwcml2YXRlIF9sYXllcjogTC5UaWxlbGF5ZXI7XHJcblxyXG4gICAgcHJpdmF0ZSBfY2x1c3Rlck1hcmtlcnM6IHsgW2tleTogc3RyaW5nXTogTC5NYXJrZXJDbHVzdGVyR3JvdXAgfSA9IHt9O1xyXG5cclxuICAgIHByaXZhdGUgX2lzTGF5ZXJFcnJvcjogYm9vbGVhbiA9IGZhbHNlO1xyXG4gICAgcHJpdmF0ZSBfaXNNYXJrZXJMb2FkZWQ6IGJvb2xlYW4gPSBmYWxzZTtcclxuICAgIHByaXZhdGUgX2lzVGlsZXNMb2FkZWQ6IGJvb2xlYW4gPSBmYWxzZTtcclxuICAgIHByaXZhdGUgX2xheWVyUmVsb2FkVGltZXM6IG51bWJlciA9IDA7XHJcbiAgICBwcml2YXRlIF90aWxlbG9hZEluZGV4OiBudW1iZXIgPSAwO1xyXG5cclxuXHJcbiAgICBASW5wdXQoKSBwb3NpdGlvbjogSU1hcFBvc2l0aW9uO1xyXG4gICAgQElucHV0KCkgY29uZmlnOiBJTWFwQ29uZmlnO1xyXG4gICAgQElucHV0KCkgZGF0YTogSU1hcENsdXN0ZXJEYXRhO1xyXG4gICAgQElucHV0KCkgYXBpOiBJTWFwQXBpO1xyXG5cclxuICAgIEBWaWV3Q2hpbGQoJ215TWFwJykgbXlNYXA6IEVsZW1lbnRSZWY7XHJcbiAgICBASG9zdEJpbmRpbmcoJ2NsYXNzLmVycm9yJykgaXNNYXBFcnJvcjogYm9vbGVhbjtcclxuXHJcbiAgICBjb25zdHJ1Y3RvcihcclxuICAgICAgICBwcml2YXRlIF9lbGVtZW50UmVmOiBFbGVtZW50UmVmLFxyXG4gICAgICAgIF9rZFNwbGl0dGVyRXZlbnQ6IEtkU3BsaXR0ZXJFdmVudCxcclxuICAgICAgICBwcml2YXRlIF9rZERvbUVsZW1TdmM6IEtkRG9tRWxlbVN2YyxcclxuICAgICAgICBwcml2YXRlIF9rZE1hcFN2YzogS2RNYXBTdmMsXHJcbiAgICAgICAgcHJpdmF0ZSBfY2Q6IENoYW5nZURldGVjdG9yUmVmLFxyXG4gICAgICAgIHByaXZhdGUgX2RhdGFTdmM6IEtkRGF0YVN2Y1xyXG4gICAgKSB7IH1cclxuXHJcbiAgICBuZ09uSW5pdCgpOiB2b2lkIHtcclxuICAgICAgICB3aW5kb3cuYWRkRXZlbnRMaXN0ZW5lcigncmVzaXplJywgdGhpcy5fcmVzaXplTWFwKTtcclxuXHJcbiAgICAgICAgaWYgKHR5cGVvZiB0aGlzLmNvbmZpZy5pZCA9PT0gJ3VuZGVmaW5lZCcpIHtcclxuICAgICAgICAgICAgdGhpcy5jb25maWcuaWQgPSAna2R4LW1hcC0wMSc7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIG5nT25DaGFuZ2VzKF9zaW1wbGVDaGFuZ2VzOiBTaW1wbGVDaGFuZ2VzKTogdm9pZCB7XHJcbiAgICAgICAgaWYgKF9zaW1wbGVDaGFuZ2VzLmhhc093blByb3BlcnR5KCdhcGknKSkge1xyXG4gICAgICAgICAgICB0aGlzLl9pbml0QXBpKCk7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICBpZiAoX3NpbXBsZUNoYW5nZXMuaGFzT3duUHJvcGVydHkoJ3Bvc2l0aW9uJykpIHtcclxuICAgICAgICAgICAgdGhpcy5fdmFsaWRhdGVMYXRMbmcoX3NpbXBsZUNoYW5nZXMucG9zaXRpb24uY3VycmVudFZhbHVlKTtcclxuXHJcbiAgICAgICAgICAgIGlmICghX3NpbXBsZUNoYW5nZXNbJ3Bvc2l0aW9uJ10uZmlyc3RDaGFuZ2UgJiYgdGhpcy5pc01hcFNob3duKSB7XHJcblxyXG4gICAgICAgICAgICAgICAgaWYgKHR5cGVvZiB0aGlzLl9teU1hcCA9PT0gJ3VuZGVmaW5lZCcpIHtcclxuICAgICAgICAgICAgICAgICAgICB0aW1lcigyMDApLnN1YnNjcmliZSgoKTogdm9pZCA9PiB7IHRoaXMuX3JlaW5pdE1hcCgpOyB9KTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIGVsc2UgdGhpcy5fbXlNYXAucGFuVG8odGhpcy5wb3NpdGlvbik7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcblxyXG5cclxuICAgICAgICBpZiAoX3NpbXBsZUNoYW5nZXMuaGFzT3duUHJvcGVydHkoJ2NvbmZpZycpKSB7XHJcbiAgICAgICAgICAgIHRoaXMuZXJyb3JNZXNzYWdlID0gX3NpbXBsZUNoYW5nZXMuY29uZmlnLmN1cnJlbnRWYWx1ZS5lcnJvck1lc3NhZ2UgfHwgJ0ludmFsaWQgbGF0aXR1ZGUvbG9uZ2l0dWRlIHZhbHVlJztcclxuXHJcbiAgICAgICAgICAgIGlmIChfc2ltcGxlQ2hhbmdlcy5oYXNPd25Qcm9wZXJ0eSgncG9zaXRpb24nKSkge1xyXG4gICAgICAgICAgICAgICAgaWYgKF9zaW1wbGVDaGFuZ2VzLmNvbmZpZy5jdXJyZW50VmFsdWUuZ29vZ2xlTGluayAmJiBfc2ltcGxlQ2hhbmdlcy5jb25maWcuY3VycmVudFZhbHVlLmdvb2dsZUxpbmsuZGlzcGxheSAmJiB0aGlzLmlzTWFwU2hvd24pIHtcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLl9zZXRHb29nbGVMaW5rKF9zaW1wbGVDaGFuZ2VzLnBvc2l0aW9uLmN1cnJlbnRWYWx1ZSk7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgaWYgKCFfc2ltcGxlQ2hhbmdlc1snY29uZmlnJ10uZmlyc3RDaGFuZ2UpIHtcclxuICAgICAgICAgICAgICAgIGlmICh0aGlzLmNvbmZpZy56b29tKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5fY2hlY2tab29tQ29uZmlnKHRoaXMuY29uZmlnLnpvb20pO1xyXG5cclxuICAgICAgICAgICAgICAgICAgICBpZiAodGhpcy5jb25maWcuem9vbS52YWx1ZSkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAodHlwZW9mIHRoaXMuX215TWFwICE9PSAndW5kZWZpbmVkJykgdGhpcy5fbXlNYXAuc2V0Wm9vbSh0aGlzLmNvbmZpZy56b29tLnZhbHVlKTtcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICAgICAgaWYgKHRoaXMuY29uZmlnLmF0dHJpYnV0aW9uKSB0aGlzLl9yZW1vdmVEZWZhdWx0QXR0cmlidXRpb24odGhpcy5jb25maWcuYXR0cmlidXRpb24pO1xyXG5cclxuICAgICAgICAgICAgICAgIGlmICh0aGlzLmNvbmZpZy50eXBlICE9PSAnYmFzaWMnKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5fcmVtb3ZlQWxsTWFya2VyTGF5ZXJzKCk7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5fc2V0TWFya2VycygpO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICB0aGlzLl9zZXREZWZhdWx0Q29uZmlnKCk7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICBpZiAoX3NpbXBsZUNoYW5nZXMuaGFzT3duUHJvcGVydHkoJ2RhdGEnKSAmJiAhX3NpbXBsZUNoYW5nZXNbJ2RhdGEnXS5maXJzdENoYW5nZSAmJiB0aGlzLmNvbmZpZy50eXBlICE9PSAnYmFzaWMnKSB7XHJcbiAgICAgICAgICAgIHRoaXMuX3JlbW92ZUFsbE1hcmtlckxheWVycygpO1xyXG4gICAgICAgICAgICB0aGlzLl9zZXRNYXJrZXJzKCk7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIG5nQWZ0ZXJWaWV3SW5pdCgpOiB2b2lkIHtcclxuICAgICAgICBpZiAodGhpcy5pc01hcFNob3duKSB7XHJcbiAgICAgICAgICAgIHRoaXMuX2luaXRNYXAoKTtcclxuICAgICAgICAgICAgdGhpcy5fY2QuZGV0ZWN0Q2hhbmdlcygpO1xyXG5cclxuICAgICAgICAgICAgdGhpcy5fcmVzaXplTWFwKCk7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIG5nT25EZXN0cm95KCk6IHZvaWQge1xyXG4gICAgICAgIHdpbmRvdy5yZW1vdmVFdmVudExpc3RlbmVyKCdyZXNpemUnLCB0aGlzLl9yZXNpemVNYXApO1xyXG4gICAgfVxyXG5cclxuICAgIHB1YmxpYyBvbkxlZ2VuZENsaWNrKF9sZWdlbmRJdGVtOiBhbnkpIHtcclxuICAgICAgICBsZXQgbGVnZW5kSXRlbU1hcmtlcjogSFRNTEVsZW1lbnQgPSB0aGlzLl9lbGVtZW50UmVmLm5hdGl2ZUVsZW1lbnQucXVlcnlTZWxlY3RvcignI2tkbGktJyArIF9sZWdlbmRJdGVtLmlkICsgJyAuYXdlc29tZS1tYXJrZXInKTtcclxuICAgICAgICBsZXQgbGVnZW5kSXRlbUxhYmVsOiBIVE1MRWxlbWVudCA9IHRoaXMuX2VsZW1lbnRSZWYubmF0aXZlRWxlbWVudC5xdWVyeVNlbGVjdG9yKCcja2RsaS0nICsgX2xlZ2VuZEl0ZW0uaWQgKyAnIC5rZHgtbGVnZW5kLWxhYmVsJyk7XHJcbiAgICAgICAgbGV0IHNlbGVjdGVkTWFya2VyR3JvdXA6IEwuTWFya2VyQ2x1c3Rlckdyb3VwIHwgTC5tYXJrZXI7XHJcblxyXG4gICAgICAgIHN3aXRjaCAodGhpcy5jb25maWcudHlwZSkge1xyXG4gICAgICAgICAgICBjYXNlICdjbHVzdGVyJzpcclxuICAgICAgICAgICAgY2FzZSAnZ3JvdXAtY2x1c3Rlcic6XHJcbiAgICAgICAgICAgICAgICBzZWxlY3RlZE1hcmtlckdyb3VwID0gdGhpcy5fY2x1c3Rlck1hcmtlcnNbX2xlZ2VuZEl0ZW0uaWRdO1xyXG4gICAgICAgICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgICAgIGRlZmF1bHQ6XHJcbiAgICAgICAgICAgICAgICBzZWxlY3RlZE1hcmtlckdyb3VwID0gdGhpcy5fbWFya2VyO1xyXG4gICAgICAgICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICBpZiAodGhpcy5fbXlNYXAuaGFzTGF5ZXIoc2VsZWN0ZWRNYXJrZXJHcm91cCkpIHtcclxuICAgICAgICAgICAgdGhpcy5fbXlNYXAucmVtb3ZlTGF5ZXIoc2VsZWN0ZWRNYXJrZXJHcm91cCk7XHJcbiAgICAgICAgICAgIHRoaXMuX2tkRG9tRWxlbVN2Yy5hZGRDbGFzcyhsZWdlbmRJdGVtTWFya2VyLCAnYXdlc29tZS1tYXJrZXItaWNvbi1saWdodGdyYXknKTtcclxuICAgICAgICAgICAgdGhpcy5fa2REb21FbGVtU3ZjLmFkZENsYXNzKGxlZ2VuZEl0ZW1MYWJlbCwgJ2tkeC1sYWJlbC1saWdodGdyYXknKTtcclxuICAgICAgICB9XHJcbiAgICAgICAgZWxzZSB7XHJcbiAgICAgICAgICAgIHRoaXMuX215TWFwLmFkZExheWVyKHNlbGVjdGVkTWFya2VyR3JvdXApO1xyXG4gICAgICAgICAgICB0aGlzLl9rZERvbUVsZW1TdmMucmVtb3ZlQ2xhc3MobGVnZW5kSXRlbU1hcmtlciwgJ2F3ZXNvbWUtbWFya2VyLWljb24tbGlnaHRncmF5Jyk7XHJcbiAgICAgICAgICAgIHRoaXMuX2tkRG9tRWxlbVN2Yy5yZW1vdmVDbGFzcyhsZWdlbmRJdGVtTGFiZWwsICdrZHgtbGFiZWwtbGlnaHRncmF5Jyk7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX3ZhbGlkYXRlTGF0TG5nKF9wb3NpdGlvbjogSU1hcFBvc2l0aW9uKTogdm9pZCB7XHJcbiAgICAgICAgaWYgKCFfcG9zaXRpb24pIHtcclxuICAgICAgICAgICAgdGhpcy5pc01hcFNob3duID0gZmFsc2U7XHJcbiAgICAgICAgICAgIHRoaXMuaXNNYXBFcnJvciA9ICF0aGlzLmlzTWFwU2hvd247XHJcbiAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgbGV0IF9sYXQ6IG51bWJlciA9IF9wb3NpdGlvbi5sYXQ7XHJcbiAgICAgICAgICAgIGxldCBfbG5nOiBudW1iZXIgPSBfcG9zaXRpb24ubG5nO1xyXG4gICAgICAgICAgICB0aGlzLmlzTWFwU2hvd24gPSAodHlwZW9mIF9sYXQgPT09ICd1bmRlZmluZWQnKSB8fCAodHlwZW9mIF9sbmcgPT09ICd1bmRlZmluZWQnKSB8fCAoX2xuZyA8IC0xODAgfHwgX2xuZyA+IDE4MCkgfHwgKF9sYXQgPCAtOTAgfHwgX2xhdCA+IDkwKSA/IGZhbHNlIDogdHJ1ZTtcclxuICAgICAgICAgICAgdGhpcy5pc01hcEVycm9yID0gIXRoaXMuaXNNYXBTaG93bjtcclxuICAgICAgICB9XHJcbiAgICAgICAgaWYgKCF0aGlzLmlzTWFwU2hvd24gJiYgdGhpcy5fbXlNYXApIHtcclxuICAgICAgICAgICAgZGVsZXRlIHRoaXMuX215TWFwO1xyXG4gICAgICAgICAgICBkZWxldGUgdGhpcy5fbGF5ZXI7XHJcbiAgICAgICAgICAgIGRlbGV0ZSB0aGlzLl9tYXJrZXI7XHJcbiAgICAgICAgICAgIGRlbGV0ZSB0aGlzLl9jbHVzdGVyTWFya2VycztcclxuICAgICAgICAgICAgZGVsZXRlIHRoaXMubWFya2Vyc0xlZ2VuZDtcclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfaW5pdE1hcCgpOiB2b2lkIHtcclxuXHJcbiAgICAgICAgdGhpcy5fbXlNYXAgPSBMLm1hcCh0aGlzLm15TWFwLm5hdGl2ZUVsZW1lbnQsIHtcclxuICAgICAgICAgICAgY2VudGVyOiB0aGlzLnBvc2l0aW9uLFxyXG4gICAgICAgICAgICB6b29tOiAodGhpcy5jb25maWcuem9vbSAmJiB0aGlzLmNvbmZpZy56b29tLnZhbHVlKSB8fCAxNCxcclxuICAgICAgICB9KTtcclxuXHJcbiAgICAgICAgaWYgKHRoaXMuY29uZmlnLnpvb20pIHRoaXMuX2NoZWNrWm9vbUNvbmZpZyh0aGlzLmNvbmZpZy56b29tKTtcclxuXHJcbiAgICAgICAgdGhpcy5fc2V0TGF5ZXIoKTtcclxuICAgICAgICB0aGlzLl9zZXRNYXJrZXJzKCk7XHJcblxyXG4gICAgICAgIHRoaXMuX3JlbW92ZURlZmF1bHRBdHRyaWJ1dGlvbih0aGlzLmNvbmZpZy5hdHRyaWJ1dGlvbik7XHJcbiAgICAgICAgaWYgKHRoaXMuY29uZmlnLmdvb2dsZUxpbmsgJiYgdGhpcy5jb25maWcuZ29vZ2xlTGluay5kaXNwbGF5ICYmIHRoaXMuY29uZmlnLnR5cGUgPT09ICdiYXNpYycpIHRoaXMuX3NldExpbmtTdHlsZSh0aGlzLmNvbmZpZy56b29tLCB0aGlzLmNvbmZpZy5nb29nbGVMaW5rLnBvc2l0aW9uKTtcclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF9yZWluaXRNYXAoKTogdm9pZCB7XHJcbiAgICAgICAgdGltZXIoNTApLnN1YnNjcmliZSgoKTogdm9pZCA9PiB7XHJcbiAgICAgICAgICAgIGlmICh0eXBlb2YgdGhpcy5teU1hcCA9PT0gJ3VuZGVmaW5lZCcpIHRoaXMuX3JlaW5pdE1hcCgpO1xyXG4gICAgICAgICAgICBlbHNlIHRoaXMuX2luaXRNYXAoKTtcclxuICAgICAgICB9KTtcclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF9pbml0QXBpKCk6IHZvaWQge1xyXG4gICAgICAgIGlmICh0eXBlb2YgdGhpcy5hcGkgIT09ICd1bmRlZmluZWQnICYmIE9iamVjdC5rZXlzKHRoaXMuYXBpKS5sZW5ndGggPT09IDApIHtcclxuICAgICAgICAgICAgdGhpcy5hcGkucmVzaXplTWFwID0gKCk6IHZvaWQgPT4gdGhpcy5fcmVzaXplTWFwKCk7XHJcbiAgICAgICAgICAgIHRoaXMuYXBpLmdldFpvb20gPSAoKTogbnVtYmVyID0+IHRoaXMuX215TWFwLmdldFpvb20oKTtcclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfY2hlY2tab29tQ29uZmlnKF9jb25maWc6IElNYXBab29tQ29uZmlnKTogdm9pZCB7XHJcbiAgICAgICAgaWYgKHR5cGVvZiB0aGlzLl9teU1hcCAhPT0gJ3VuZGVmaW5lZCcpIHtcclxuICAgICAgICAgICAgX2NvbmZpZy5pc1pvb21CdXR0b24gPyB0aGlzLl9teU1hcC5hZGRDb250cm9sKHRoaXMuX215TWFwLnpvb21Db250cm9sKSA6IHRoaXMuX215TWFwLnJlbW92ZUNvbnRyb2wodGhpcy5fbXlNYXAuem9vbUNvbnRyb2wpO1xyXG4gICAgICAgICAgICBfY29uZmlnLmlzU2Nyb2xsWm9vbSA/IHRoaXMuX215TWFwLnNjcm9sbFdoZWVsWm9vbS5lbmFibGUoKSA6IHRoaXMuX215TWFwLnNjcm9sbFdoZWVsWm9vbS5kaXNhYmxlKCk7XHJcbiAgICAgICAgICAgIF9jb25maWcuaXNUb3VjaFpvb20gPyB0aGlzLl9teU1hcC50b3VjaFpvb20uZW5hYmxlKCkgOiB0aGlzLl9teU1hcC50b3VjaFpvb20uZGlzYWJsZSgpO1xyXG4gICAgICAgICAgICBfY29uZmlnLmlzRG91YmxlQ2xpY2tab29tID8gdGhpcy5fbXlNYXAuZG91YmxlQ2xpY2tab29tLmVuYWJsZSgpIDogdGhpcy5fbXlNYXAuZG91YmxlQ2xpY2tab29tLmRpc2FibGUoKTtcclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfc2V0TGF5ZXIoKTogdm9pZCB7XHJcbiAgICAgICAgaWYgKHRoaXMuX2xheWVyKSB0aGlzLl9sYXllci5yZW1vdmUoKTtcclxuICAgICAgICB0aGlzLl9pc0xheWVyRXJyb3IgPSBmYWxzZTtcclxuICAgICAgICB0aGlzLmlzTGF5ZXJMb2FkaW5nID0gdHJ1ZTtcclxuICAgICAgICB0aGlzLl9sYXllciA9IEwudGlsZUxheWVyKCdodHRwczovL3tzfS50aWxlLm9wZW5zdHJlZXRtYXAub3JnL3t6fS97eH0ve3l9LnBuZycsIHtcclxuICAgICAgICAgICAgYXR0cmlidXRpb246ICcmY29weTsgPGEgaHJlZj1cImh0dHA6Ly93d3cub3BlbnN0cmVldG1hcC5vcmcvY29weXJpZ2h0XCI+T3BlblN0cmVldE1hcDwvYT4nLFxyXG4gICAgICAgICAgICBtYXhab29tOiAxOCxcclxuICAgICAgICB9KTtcclxuICAgICAgICB0aGlzLl9sYXllci5hZGRUbyh0aGlzLl9teU1hcCk7XHJcbiAgICAgICAgdGhpcy5fYXR0YWNoVGlsZUxpc3RlbmVyKCk7XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfcmVtb3ZlRGVmYXVsdEF0dHJpYnV0aW9uKF9hdHRyaWJ1dGlvbjogc3RyaW5nKTogdm9pZCB7XHJcbiAgICAgICAgbGV0IGF0dHJpYnV0aW9uRWxlbWVudDogRWxlbWVudCA9IHRoaXMuX2VsZW1lbnRSZWYubmF0aXZlRWxlbWVudC5xdWVyeVNlbGVjdG9yKCcubGVhZmxldC1jb250cm9sLWF0dHJpYnV0aW9uJyk7XHJcbiAgICAgICAgaWYgKGF0dHJpYnV0aW9uRWxlbWVudCAhPT0gbnVsbCkge1xyXG4gICAgICAgICAgICBsZXQgbmV3QXR0cmlidXRpb25FbGVtZW50OiBIVE1MRWxlbWVudCA9IHRoaXMuX2tkRG9tRWxlbVN2Yy5jcmVhdGVFbGVtZW50KGF0dHJpYnV0aW9uRWxlbWVudCwgJ2N1c3RvbS1hdHRyaWJ1dGlvbicpO1xyXG4gICAgICAgICAgICBuZXdBdHRyaWJ1dGlvbkVsZW1lbnQuaW5uZXJUZXh0ID0gX2F0dHJpYnV0aW9uIHx8ICdPcGVuRU1JUyc7XHJcbiAgICAgICAgICAgIGF0dHJpYnV0aW9uRWxlbWVudC5yZXBsYWNlQ2hpbGQobmV3QXR0cmlidXRpb25FbGVtZW50LCBhdHRyaWJ1dGlvbkVsZW1lbnQuZmlyc3RDaGlsZCk7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX2F0dGFjaFRpbGVMaXN0ZW5lcigpOiB2b2lkIHtcclxuICAgICAgICAvKiBDaGVja3MgZXZlcnkgdGlsZS4gT25seSBjYWxsZWQgd2hlbiBzb21lIHRpbGUgbG9hZCBoYXMgZmFpbGVkLiAqL1xyXG4gICAgICAgIHRoaXMuX2xheWVyLm9uKCd0aWxlZXJyb3InLCAoZXJyb3IpOiB2b2lkID0+IHtcclxuICAgICAgICAgICAgLy8gb25seSBleGVjdXRlIHRoZSBmb2xsb3dpbmcgZm9yIHRoZSBmaXJzdCB0aWxlIGVycm9yXHJcbiAgICAgICAgICAgIGlmICghdGhpcy5faXNMYXllckVycm9yKSB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLl9pc0xheWVyRXJyb3IgPSB0cnVlO1xyXG4gICAgICAgICAgICAgICAgdGhpcy5fbGF5ZXJSZWxvYWRUaW1lcysrO1xyXG4gICAgICAgICAgICAgICAgaWYgKHRoaXMuX2xheWVyUmVsb2FkVGltZXMgPCA1IHx8IHRoaXMuX2xheWVyUmVsb2FkVGltZXMgPT09IDUpIHtcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLl9zZXRMYXllcigpO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgaWYgKHRoaXMuX2xheWVyUmVsb2FkVGltZXMgPiA1KSB7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5pc01hcFNob3duID0gZmFsc2U7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5lcnJvck1lc3NhZ2UgPSAnTWF4IHJldHJ5IHJlYWNoZWQuIE1hcCBjYW5ub3QgYmUgbG9hZGVkIG5vdy4gUGxlYXNlIGNoZWNrIHlvdXIgaW50ZXJuZXQgY29ubmVjdGlvbiBvciB0cnkgYWdhaW4gbGF0ZXIuJztcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH0pO1xyXG5cclxuICAgICAgICAvKiBDaGVja3MgZXZlcnkgdGlsZS4gT25seSBjYWxsZWQgd2hlbiBlYWNoIHRpbGUgbG9hZCBpcyBzdWNjZXNzZnVsLiAqL1xyXG4gICAgICAgIHRoaXMuX2xheWVyLm9uKCd0aWxlbG9hZCcsICgpOiB2b2lkID0+IHtcclxuICAgICAgICAgICAgdGhpcy5fdGlsZWxvYWRJbmRleCsrO1xyXG4gICAgICAgICAgICBpZiAodGhpcy5pc0xheWVyTG9hZGluZyAmJiB0aGlzLl90aWxlbG9hZEluZGV4ID09PSBPYmplY3Qua2V5cyh0aGlzLl9sYXllci5fdGlsZXMpLmxlbmd0aCkge1xyXG4gICAgICAgICAgICAgICAgLy8gb25seSBzdG9wIHByb2dyZXNzIGxvYWRlciB3aGVuIGxhc3QgdGlsZSBsb2FkZWQgc3VjY2Vzc2Z1bGx5XHJcbiAgICAgICAgICAgICAgICAvLyB0aGlzLmlzTGF5ZXJMb2FkaW5nID0gZmFsc2U7XHJcbiAgICAgICAgICAgICAgICB0aGlzLl9pc1RpbGVzTG9hZGVkID0gdHJ1ZTtcclxuICAgICAgICAgICAgICAgIHRoaXMuX2hpZGVMb2FkaW5nU2NyZWVuKCk7XHJcbiAgICAgICAgICAgICAgICAvLyByZXNldCBjb3VudGVyc1xyXG4gICAgICAgICAgICAgICAgdGhpcy5fbGF5ZXJSZWxvYWRUaW1lcyA9IDA7XHJcbiAgICAgICAgICAgICAgICB0aGlzLl90aWxlbG9hZEluZGV4ID0gMDtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH0pO1xyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX3Jlc2l6ZU1hcCgpOiB2b2lkIHtcclxuICAgICAgICBpZiAodGhpcy5pc01hcFNob3duKSB7XHJcbiAgICAgICAgICAgIHRpbWVyKCkuc3Vic2NyaWJlKCgpOiB2b2lkID0+IHtcclxuICAgICAgICAgICAgICAgIHRoaXMuX215TWFwLmludmFsaWRhdGVTaXplKHt9KTtcclxuICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX3NldEdvb2dsZUxpbmsoX3Bvc2l0aW9uOiBJTWFwUG9zaXRpb24pOiB2b2lkIHtcclxuICAgICAgICBpZiAodGhpcy5jb25maWcudHlwZSA9PT0gJ2Jhc2ljJykge1xyXG4gICAgICAgICAgICB0aGlzLmlzTGlua1RvR29vZ2xlID0gdHJ1ZTtcclxuICAgICAgICAgICAgdGhpcy5nb29nbGVMaW5rID0gJ2h0dHBzOi8vd3d3Lmdvb2dsZS5jb20vbWFwcy8/cT0nICsgX3Bvc2l0aW9uLmxhdC50b1N0cmluZygpICsgJywnICsgX3Bvc2l0aW9uLmxuZy50b1N0cmluZygpO1xyXG4gICAgICAgIH1cclxuICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgdGhpcy5pc0xpbmtUb0dvb2dsZSA9IGZhbHNlO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF9zZXRMaW5rU3R5bGUoX3pvb21Db25maWc6IElNYXBab29tQ29uZmlnLCBfbGlua1Bvc2l0aW9uOiBzdHJpbmcpOiB2b2lkIHtcclxuICAgICAgICBsZXQgbGlua0VsZW1lbnQ6IEhUTUxFbGVtZW50ID0gdGhpcy5fZWxlbWVudFJlZi5uYXRpdmVFbGVtZW50LnF1ZXJ5U2VsZWN0b3IoJy5rZHgtbWFwIC5saW5rLXdyYXBwZXInKTtcclxuICAgICAgICBzd2l0Y2ggKF9saW5rUG9zaXRpb24pIHtcclxuICAgICAgICAgICAgY2FzZSAndG9wLWxlZnQnOlxyXG4gICAgICAgICAgICBkZWZhdWx0OlxyXG4gICAgICAgICAgICAgICAgLy8gb25seSB3aGVuIFpvb20gQnV0dG9ucyBhcmUgcmVtb3ZlZCB0aGVuIHdlIHB1dCBnb29nbGVMaW5rIGF0IHRoZSBwb3NpdGlvbiBvZiB0aGUgWm9vbSBCdXR0b25zXHJcbiAgICAgICAgICAgICAgICBsZXQgbmV3Q2xhc3M6IHN0cmluZyA9IF96b29tQ29uZmlnICYmIF96b29tQ29uZmlnLmlzWm9vbUJ1dHRvbiA9PT0gZmFsc2UgPyAnJyA6ICcgYmVsb3ctem9vbSc7XHJcbiAgICAgICAgICAgICAgICB0aGlzLl9rZERvbUVsZW1TdmMuYWRkQ2xhc3MobGlua0VsZW1lbnQsICdsZWFmbGV0LXRvcCBsZWFmbGV0LWxlZnQnICsgbmV3Q2xhc3MpO1xyXG4gICAgICAgICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgICAgIGNhc2UgJ3RvcC1yaWdodCc6XHJcbiAgICAgICAgICAgICAgICB0aGlzLl9rZERvbUVsZW1TdmMuYWRkQ2xhc3MobGlua0VsZW1lbnQsICdsZWFmbGV0LXRvcCBsZWFmbGV0LXJpZ2h0Jyk7XHJcbiAgICAgICAgICAgICAgICBicmVhaztcclxuICAgICAgICAgICAgY2FzZSAnYm90dG9tLWxlZnQnOlxyXG4gICAgICAgICAgICAgICAgdGhpcy5fa2REb21FbGVtU3ZjLmFkZENsYXNzKGxpbmtFbGVtZW50LCAnbGVhZmxldC1ib3R0b20gbGVhZmxldC1sZWZ0Jyk7XHJcbiAgICAgICAgICAgICAgICBicmVhaztcclxuICAgICAgICAgICAgY2FzZSAnYm90dG9tLXJpZ2h0JzpcclxuICAgICAgICAgICAgICAgIHRoaXMuX2tkRG9tRWxlbVN2Yy5hZGRDbGFzcyhsaW5rRWxlbWVudCwgJ2xlYWZsZXQtYm90dG9tIGxlYWZsZXQtcmlnaHQgYWJvdmUtYXR0cmlidXRpb24nKTtcclxuICAgICAgICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF9zZXRNYXJrZXJzKCk6IHZvaWQge1xyXG4gICAgICAgIGlmICh0eXBlb2YgdGhpcy5fbXlNYXAgIT09ICd1bmRlZmluZWQnKSB7XHJcbiAgICAgICAgICAgIHN3aXRjaCAodGhpcy5jb25maWcudHlwZSkge1xyXG4gICAgICAgICAgICAgICAgY2FzZSAnY2x1c3Rlcic6XHJcbiAgICAgICAgICAgICAgICBjYXNlICdncm91cC1jbHVzdGVyJzpcclxuICAgICAgICAgICAgICAgICAgICBpZiAodHlwZW9mIHRoaXMuZGF0YSAhPT0gJ3VuZGVmaW5lZCcgJiYgT2JqZWN0LmtleXModGhpcy5kYXRhKS5sZW5ndGggIT09IDApIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgbGV0IGNsdXN0ZXJEYXRhOiBJTWFwUG9wdWxhdGVDbHVzdGVyRGF0YSA9IHRoaXMuX2tkTWFwU3ZjLnBvcHVsYXRlTWFya2Vycyh0aGlzLmRhdGEsIHRoaXMuX215TWFwLCB0aGlzLmNvbmZpZy50eXBlKTtcclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMubWFya2Vyc0xlZ2VuZCA9IGNsdXN0ZXJEYXRhLm1hcmtlcnNMZWdlbmQ7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuX2NsdXN0ZXJNYXJrZXJzID0gY2x1c3RlckRhdGEuY2x1c3Rlck1hcmtlcnM7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuX2lzTWFya2VyTG9hZGVkID0gdHJ1ZTtcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgICAgICAgICBkZWZhdWx0OlxyXG4gICAgICAgICAgICAgICAgICAgIGxldCBkZWZhdWx0SWNvbjogSU1hcE1hcmtlciA9IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgbWFya2VyQ29sb3I6ICdwdXJwbGUnLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICB0aXRsZTogdGhpcy5jb25maWcubWFya2VyLnRpdGxlXHJcbiAgICAgICAgICAgICAgICAgICAgfTtcclxuICAgICAgICAgICAgICAgICAgICBsZXQgaWNvbk1hcmtlcjogTC5JY29uID0gdGhpcy5fa2RNYXBTdmMuc2V0SWNvbihkZWZhdWx0SWNvbik7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5fbWFya2VyID0gTC5tYXJrZXIodGhpcy5wb3NpdGlvbiwgeyBpY29uOiBpY29uTWFya2VyIH0pLmFkZFRvKHRoaXMuX215TWFwKTtcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLl9pc01hcmtlckxvYWRlZCA9IHRydWU7XHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKHRoaXMuY29uZmlnLmhhc093blByb3BlcnR5KCdjb250ZW50JykpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5fbWFya2VyLmJpbmRQb3B1cCh0aGlzLmNvbmZpZy5jb250ZW50KTtcclxuICAgICAgICAgICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIGlmICh0aGlzLmNvbmZpZy5oYXNPd25Qcm9wZXJ0eSgnbGVnZW5kJykpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5tYXJrZXJzTGVnZW5kID0gW3tcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGljb246IGljb25NYXJrZXIuY3JlYXRlSWNvbigpLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgbGFiZWw6IHRoaXMuY29uZmlnLm1hcmtlci50aXRsZSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlkOiB0aGlzLmNvbmZpZy5tYXJrZXIuaGFzT3duUHJvcGVydHkoJ2lkJykgPyB0aGlzLmNvbmZpZy5tYXJrZXIuaWQgOiAna2R4LXNpbmdsZS1tYXJrZXInXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH1dO1xyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICBicmVhaztcclxuICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIHRoaXMuX2hpZGVMb2FkaW5nU2NyZWVuKCk7XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfaGlkZUxvYWRpbmdTY3JlZW4oKTogdm9pZCB7XHJcbiAgICAgICAgaWYgKHRoaXMuX2lzTWFya2VyTG9hZGVkICYmIHRoaXMuX2lzVGlsZXNMb2FkZWQpIHtcclxuICAgICAgICAgICAgdGhpcy5pc0xheWVyTG9hZGluZyA9IGZhbHNlO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF9yZW1vdmVBbGxNYXJrZXJMYXllcnMoKTogdm9pZCB7XHJcbiAgICAgICAgZm9yIChsZXQgbGVnZW5kSXRlbUlkIGluIHRoaXMuX2NsdXN0ZXJNYXJrZXJzKSB7XHJcbiAgICAgICAgICAgIGlmICh0aGlzLl9jbHVzdGVyTWFya2Vyc1tsZWdlbmRJdGVtSWRdKSB0aGlzLl9teU1hcC5yZW1vdmVMYXllcih0aGlzLl9jbHVzdGVyTWFya2Vyc1tsZWdlbmRJdGVtSWRdKTtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIHRoaXMubWFya2Vyc0xlZ2VuZCA9IFtdO1xyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX3NldERlZmF1bHRDb25maWcoKTogdm9pZCB7XHJcbiAgICAgICAgdGhpcy5tYXBDb25maWcgPSB0aGlzLl9rZE1hcFN2Yy5nZXREZWZhdWx0Q29uZmlnKCk7XHJcbiAgICAgICAgdGhpcy5fZGF0YVN2Yy5kZWVwTWVyZ2VPYmplY3QodGhpcy5tYXBDb25maWcsIHRoaXMuY29uZmlnLCBmYWxzZSk7XHJcblxyXG4gICAgICAgIHRoaXMubWFwQ29uZmlnLmxlZ2VuZC5lbmFibGVkID0gdGhpcy5fc2V0RW5hYmxlZCgnbGVnZW5kJywgWyd0aXRsZSddKTtcclxuICAgICAgICBpZiAodGhpcy5tYXBDb25maWcuZm9vdGVyKSB0aGlzLm1hcENvbmZpZy5mb290ZXIuZW5hYmxlZCA9IHRoaXMuX3NldEVuYWJsZWQoJ2Zvb3RlcicsIFsnYm90dG9tTGFiZWwnLCAnZm9vdE5vdGUnXSk7XHJcblxyXG4gICAgICAgIHRoaXMuX3NldENsYXNzTmFtZXMoKTtcclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF9zZXRFbmFibGVkKF9vYmpLZXk6IHN0cmluZywgX3RleHRLZXlzOiBBcnJheTxzdHJpbmc+KTogYm9vbGVhbiB7XHJcbiAgICAgICAgaWYgKHRoaXMubWFwQ29uZmlnW19vYmpLZXldICYmIHR5cGVvZiB0aGlzLm1hcENvbmZpZ1tfb2JqS2V5XS5lbmFibGVkICE9PSAndW5kZWZpbmVkJykge1xyXG4gICAgICAgICAgICByZXR1cm4gdGhpcy5tYXBDb25maWdbX29iaktleV0uZW5hYmxlZDtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIGZvciAobGV0IGk6IG51bWJlciA9IF90ZXh0S2V5cy5sZW5ndGggLSAxOyBpID49IDA7IGktLSkge1xyXG4gICAgICAgICAgICBpZiAodGhpcy5tYXBDb25maWdbX29iaktleV1bX3RleHRLZXlzW2ldXSAmJiB0aGlzLm1hcENvbmZpZ1tfb2JqS2V5XVtfdGV4dEtleXNbaV1dLnRleHQgIT09ICcnKSB7XHJcbiAgICAgICAgICAgICAgICByZXR1cm4gdHJ1ZTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgaWYgKF9vYmpLZXkgPT09ICdsZWdlbmQnICYmIHRoaXMubWFya2Vyc0xlZ2VuZC5sZW5ndGggPT09IDApIHtcclxuICAgICAgICAgICAgcmV0dXJuIGZhbHNlO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgcmV0dXJuIGZhbHNlXHJcbiAgICB9XHJcblxyXG4gICAgLyogVG8gYmUgcmV2aXNpdC4gSG90IGZpeCBmb3IgZG93bmdyYWRlIGNvbXBvbmVudCBhcyBuZ2NsYXNzIHZhbHVlIGRvZXNuJ3QgY2hhbmdlLiovXHJcbiAgICBwcml2YXRlIF9zZXRDbGFzc05hbWVzKCk6IHZvaWQge1xyXG5cclxuICAgICAgICAvLyBodG1sQ2xhc3NPYmogaXMgYSB3b3JrYXJvdW5kIGZvciBkb3duZ3JhZGUgbWV0aG9kXHJcbiAgICAgICAgdGhpcy5odG1sQ2xhc3MgPSAnJztcclxuXHJcbiAgICAgICAgaWYgKHR5cGVvZiB0aGlzLmNvbmZpZy5sZWdlbmQuZmxvYXQgIT09ICd1bmRlZmluZWQnICYmIHRoaXMuY29uZmlnLmxlZ2VuZC5mbG9hdCkge1xyXG4gICAgICAgICAgICB0aGlzLmh0bWxDbGFzcyArPSAnbGVnZW5kLWZsb2F0ICc7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICBpZiAodHlwZW9mIHRoaXMuY29uZmlnLmxlZ2VuZC52ZXJ0aWNhbEFsaWduICE9PSAndW5kZWZpbmVkJykge1xyXG4gICAgICAgICAgICB0aGlzLmh0bWxDbGFzcyArPSB0aGlzLmNvbmZpZy5sZWdlbmQudmVydGljYWxBbGlnbiArICcgJztcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIGlmICh0eXBlb2YgdGhpcy5jb25maWcubGVnZW5kLmFsaWduICE9PSAndW5kZWZpbmVkJykge1xyXG4gICAgICAgICAgICB0aGlzLmh0bWxDbGFzcyArPSB0aGlzLmNvbmZpZy5sZWdlbmQuYWxpZ247XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxufVxyXG4iXX0=