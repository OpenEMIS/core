import { __decorate, __metadata } from "tslib";
import { Component, Input, Output, EventEmitter, HostListener } from '@angular/core';
import { KdLoginFormControlService } from '../form/kd-loginform-control.service';
import { KdLoginSvc } from '../kd-angular-login-svc';
var KdLoginForm = /** @class */ (function () {
    function KdLoginForm(_loginSvc, _loginFormSvc) {
        this._loginSvc = _loginSvc;
        this._loginFormSvc = _loginFormSvc;
        this.loginForms = [];
        this.onFormSubmit = new EventEmitter();
        this.onLanguageChange = new EventEmitter();
    }
    KdLoginForm.prototype.onKeyUp = function (_keyEvent) {
        if (_keyEvent.key === 'Enter') {
            this.buttonSubmit();
        }
    };
    KdLoginForm.prototype.ngOnInit = function () {
        this.loginForms = this._loginFormSvc.getLoginForm(this.formData);
        this.form = this._loginFormSvc.toFormGroup(this.loginForms);
        //this.defaultVal = this.formData[2].value;
        //console.log('Default value: ' + this.defaultLangVal);
        this.selectedIndex = this.defaultLangVal;
    };
    KdLoginForm.prototype.buttonSubmit = function () {
        var tempData = {
            formInputs: this.loginForms,
            formValues: this.form.value
        };
        this.onFormSubmit.emit(tempData);
    };
    KdLoginForm.prototype.updateDefaultLanguage = function () {
        //console.log('From Child: ' + this.selectedIndex);
        this.onLanguageChange.emit(this.selectedIndex);
    };
    KdLoginForm.ctorParameters = function () { return [
        { type: KdLoginSvc },
        { type: KdLoginFormControlService }
    ]; };
    __decorate([
        Input(),
        __metadata("design:type", Array)
    ], KdLoginForm.prototype, "formData", void 0);
    __decorate([
        Input(),
        __metadata("design:type", Array)
    ], KdLoginForm.prototype, "loginForms", void 0);
    __decorate([
        Input(),
        __metadata("design:type", Object)
    ], KdLoginForm.prototype, "config", void 0);
    __decorate([
        Input(),
        __metadata("design:type", String)
    ], KdLoginForm.prototype, "buttonTitle", void 0);
    __decorate([
        Input(),
        __metadata("design:type", String)
    ], KdLoginForm.prototype, "defaultLangVal", void 0);
    __decorate([
        Output(),
        __metadata("design:type", EventEmitter)
    ], KdLoginForm.prototype, "onFormSubmit", void 0);
    __decorate([
        Output(),
        __metadata("design:type", EventEmitter)
    ], KdLoginForm.prototype, "onLanguageChange", void 0);
    __decorate([
        HostListener('document:keyup', ['$event']),
        __metadata("design:type", Function),
        __metadata("design:paramtypes", [KeyboardEvent]),
        __metadata("design:returntype", void 0)
    ], KdLoginForm.prototype, "onKeyUp", null);
    KdLoginForm = __decorate([
        Component({
            selector: 'kd-loginform',
            template: "<div *ngFor=\"let loginForm of loginForms\">\r\n    <div [formGroup]=\"form\">\r\n        <div [ngSwitch]=\"loginForm.controlType\">\r\n            <div [class]=\"loginForm.class\">\r\n                <!--<i class=\"fa fa-user\"></i>-->\r\n                <input *ngSwitchCase=\"'text'\" [placeholder]=\"loginForm.label\" [formControlName]=\"loginForm.key\" [id]=\"loginForm.key\" [type]=\"loginForm.type\"><i [class]=\"loginForm.iconClass\"></i>\r\n                <div class=\"loginForm.class\" *ngSwitchCase=\"'dropdown'\">\r\n                    <!--<select [id]=\"loginForm.key\" *ngSwitchCase=\"'dropdown'\" [formControlName]=\"loginForm.key\" (ngModelChange)=\"updateLanguage()\">-->\r\n                        <select [id]=\"loginForm.key\" *ngSwitchCase=\"'dropdown'\" [formControlName]=\"loginForm.key\" [(ngModel)]=\"selectedIndex\" (ngModelChange)=\"updateDefaultLanguage()\">\r\n                        <option *ngFor=\"let opt of loginForm.options\" [value]=\"opt.key\">{{opt.value}}</option>\r\n                    </select><i [class]=\"loginForm.iconClass\"></i>\r\n                </div>\r\n            </div>\r\n        </div>\r\n    </div>\r\n</div>\r\n<button name=\"submit\" class=\"btn btn-primary kdx-btn-login\" (click)=\"buttonSubmit()\">{{buttonTitle}}</button>\r\n",
            providers: [
                KdLoginFormControlService
            ],
            host: { 'class': 'kdx-login' }
        }),
        __metadata("design:paramtypes", [KdLoginSvc,
            KdLoginFormControlService])
    ], KdLoginForm);
    return KdLoginForm;
}());
export { KdLoginForm };
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoia2QtbG9naW5mb3JtLmpzIiwic291cmNlUm9vdCI6Im5nOi8vb3BlbmVtaXMtc3R5bGVndWlkZS1saWIvIiwic291cmNlcyI6WyJrZC1jb21wb25lbnRzL2tkLWFuZ3VsYXItbG9naW4vZm9ybS9rZC1sb2dpbmZvcm0udHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IjtBQUFBLE9BQU8sRUFDSCxTQUFTLEVBQ1QsS0FBSyxFQUNMLE1BQU0sRUFDTixZQUFZLEVBRVosWUFBWSxFQUVmLE1BQU0sZUFBZSxDQUFDO0FBR3ZCLE9BQU8sRUFBRSx5QkFBeUIsRUFBRSxNQUFNLHNDQUFzQyxDQUFDO0FBQ2pGLE9BQU8sRUFBRSxVQUFVLEVBQUUsTUFBTSx5QkFBeUIsQ0FBQztBQVVyRDtJQWFJLHFCQUNZLFNBQXFCLEVBQ3JCLGFBQXdDO1FBRHhDLGNBQVMsR0FBVCxTQUFTLENBQVk7UUFDckIsa0JBQWEsR0FBYixhQUFhLENBQTJCO1FBVjNDLGVBQVUsR0FBMkIsRUFBRSxDQUFDO1FBS3ZDLGlCQUFZLEdBQXNCLElBQUksWUFBWSxFQUFFLENBQUM7UUFDckQscUJBQWdCLEdBQXNCLElBQUksWUFBWSxFQUFFLENBQUM7SUFLL0QsQ0FBQztJQUdMLDZCQUFPLEdBQVAsVUFBUSxTQUF3QjtRQUM1QixJQUFJLFNBQVMsQ0FBQyxHQUFHLEtBQUssT0FBTyxFQUFFO1lBQzNCLElBQUksQ0FBQyxZQUFZLEVBQUUsQ0FBQztTQUN2QjtJQUNMLENBQUM7SUFFRCw4QkFBUSxHQUFSO1FBQ0ksSUFBSSxDQUFDLFVBQVUsR0FBRyxJQUFJLENBQUMsYUFBYSxDQUFDLFlBQVksQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLENBQUM7UUFDakUsSUFBSSxDQUFDLElBQUksR0FBRyxJQUFJLENBQUMsYUFBYSxDQUFDLFdBQVcsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLENBQUM7UUFDNUQsMkNBQTJDO1FBQzNDLHVEQUF1RDtRQUN2RCxJQUFJLENBQUMsYUFBYSxHQUFHLElBQUksQ0FBQyxjQUFjLENBQUM7SUFDN0MsQ0FBQztJQUVNLGtDQUFZLEdBQW5CO1FBQ0ksSUFBSSxRQUFRLEdBQVE7WUFDaEIsVUFBVSxFQUFFLElBQUksQ0FBQyxVQUFVO1lBQzNCLFVBQVUsRUFBRSxJQUFJLENBQUMsSUFBSSxDQUFDLEtBQUs7U0FDOUIsQ0FBQTtRQUNELElBQUksQ0FBQyxZQUFZLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxDQUFDO0lBQ3JDLENBQUM7SUFFTSwyQ0FBcUIsR0FBNUI7UUFDSSxtREFBbUQ7UUFDbkQsSUFBSSxDQUFDLGdCQUFnQixDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsYUFBYSxDQUFDLENBQUM7SUFFbkQsQ0FBQzs7Z0JBL0JzQixVQUFVO2dCQUNOLHlCQUF5Qjs7SUFYM0M7UUFBUixLQUFLLEVBQUU7a0NBQVcsS0FBSztpREFBTTtJQUNyQjtRQUFSLEtBQUssRUFBRTs7bURBQXlDO0lBRXhDO1FBQVIsS0FBSyxFQUFFOzsrQ0FBYTtJQUNaO1FBQVIsS0FBSyxFQUFFOztvREFBcUI7SUFDcEI7UUFBUixLQUFLLEVBQUU7O3VEQUF3QjtJQUN0QjtRQUFULE1BQU0sRUFBRTtrQ0FBZSxZQUFZO3FEQUEyQjtJQUNyRDtRQUFULE1BQU0sRUFBRTtrQ0FBbUIsWUFBWTt5REFBMkI7SUFRbkU7UUFEQyxZQUFZLENBQUMsZ0JBQWdCLEVBQUUsQ0FBQyxRQUFRLENBQUMsQ0FBQzs7eUNBQ3hCLGFBQWE7OzhDQUkvQjtJQXZCUSxXQUFXO1FBUnZCLFNBQVMsQ0FBQztZQUNQLFFBQVEsRUFBRSxjQUFjO1lBQ3hCLHV4Q0FBa0M7WUFDbEMsU0FBUyxFQUFFO2dCQUNQLHlCQUF5QjthQUFDO1lBQzlCLElBQUksRUFBRSxFQUFFLE9BQU8sRUFBRSxXQUFXLEVBQUU7U0FDakMsQ0FBQzt5Q0FnQnlCLFVBQVU7WUFDTix5QkFBeUI7T0FmM0MsV0FBVyxDQWlEdkI7SUFBRCxrQkFBQztDQUFBLEFBakRELElBaURDO1NBakRZLFdBQVciLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQge1xyXG4gICAgQ29tcG9uZW50LFxyXG4gICAgSW5wdXQsXHJcbiAgICBPdXRwdXQsXHJcbiAgICBFdmVudEVtaXR0ZXIsXHJcbiAgICBIb3N0QmluZGluZyxcclxuICAgIEhvc3RMaXN0ZW5lcixcclxuICAgIE9uSW5pdFxyXG59IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xyXG5pbXBvcnQgeyBGb3JtR3JvdXAgfSBmcm9tICdAYW5ndWxhci9mb3Jtcyc7XHJcbmltcG9ydCB7IEtkTG9naW5Gb3JtQmFzZSB9IGZyb20gJy4uL2Zvcm0va2QtbG9naW5mb3JtLWJhc2UnO1xyXG5pbXBvcnQgeyBLZExvZ2luRm9ybUNvbnRyb2xTZXJ2aWNlIH0gZnJvbSAnLi4vZm9ybS9rZC1sb2dpbmZvcm0tY29udHJvbC5zZXJ2aWNlJztcclxuaW1wb3J0IHsgS2RMb2dpblN2YyB9IGZyb20gJy4uL2tkLWFuZ3VsYXItbG9naW4tc3ZjJztcclxuXHJcbkBDb21wb25lbnQoe1xyXG4gICAgc2VsZWN0b3I6ICdrZC1sb2dpbmZvcm0nLFxyXG4gICAgdGVtcGxhdGVVcmw6ICcuL2tkLWxvZ2luZm9ybS5odG1sJyxcclxuICAgIHByb3ZpZGVyczogW1xyXG4gICAgICAgIEtkTG9naW5Gb3JtQ29udHJvbFNlcnZpY2VdLFxyXG4gICAgaG9zdDogeyAnY2xhc3MnOiAna2R4LWxvZ2luJyB9XHJcbn0pXHJcblxyXG5leHBvcnQgY2xhc3MgS2RMb2dpbkZvcm0gaW1wbGVtZW50cyBPbkluaXQge1xyXG4gICAgcHVibGljIGZvcm06IEZvcm1Hcm91cDtcclxuICAgIHB1YmxpYyBzZWxlY3RlZEluZGV4OiBzdHJpbmc7XHJcblxyXG4gICAgQElucHV0KCkgZm9ybURhdGE6IEFycmF5PGFueT47XHJcbiAgICBASW5wdXQoKSBsb2dpbkZvcm1zOiBLZExvZ2luRm9ybUJhc2U8YW55PltdID0gW107XHJcblxyXG4gICAgQElucHV0KCkgY29uZmlnOiBhbnk7XHJcbiAgICBASW5wdXQoKSBidXR0b25UaXRsZTogc3RyaW5nO1xyXG4gICAgQElucHV0KCkgZGVmYXVsdExhbmdWYWw6IHN0cmluZztcclxuICAgIEBPdXRwdXQoKSBvbkZvcm1TdWJtaXQ6IEV2ZW50RW1pdHRlcjxhbnk+ID0gbmV3IEV2ZW50RW1pdHRlcigpO1xyXG4gICAgQE91dHB1dCgpIG9uTGFuZ3VhZ2VDaGFuZ2U6IEV2ZW50RW1pdHRlcjxhbnk+ID0gbmV3IEV2ZW50RW1pdHRlcigpO1xyXG5cclxuICAgIGNvbnN0cnVjdG9yKFxyXG4gICAgICAgIHByaXZhdGUgX2xvZ2luU3ZjOiBLZExvZ2luU3ZjLFxyXG4gICAgICAgIHByaXZhdGUgX2xvZ2luRm9ybVN2YzogS2RMb2dpbkZvcm1Db250cm9sU2VydmljZSxcclxuICAgICkgeyB9XHJcblxyXG4gICAgQEhvc3RMaXN0ZW5lcignZG9jdW1lbnQ6a2V5dXAnLCBbJyRldmVudCddKVxyXG4gICAgb25LZXlVcChfa2V5RXZlbnQ6IEtleWJvYXJkRXZlbnQpIHtcclxuICAgICAgICBpZiAoX2tleUV2ZW50LmtleSA9PT0gJ0VudGVyJykge1xyXG4gICAgICAgICAgICB0aGlzLmJ1dHRvblN1Ym1pdCgpO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICBuZ09uSW5pdCgpOiB2b2lkIHtcclxuICAgICAgICB0aGlzLmxvZ2luRm9ybXMgPSB0aGlzLl9sb2dpbkZvcm1TdmMuZ2V0TG9naW5Gb3JtKHRoaXMuZm9ybURhdGEpO1xyXG4gICAgICAgIHRoaXMuZm9ybSA9IHRoaXMuX2xvZ2luRm9ybVN2Yy50b0Zvcm1Hcm91cCh0aGlzLmxvZ2luRm9ybXMpO1xyXG4gICAgICAgIC8vdGhpcy5kZWZhdWx0VmFsID0gdGhpcy5mb3JtRGF0YVsyXS52YWx1ZTtcclxuICAgICAgICAvL2NvbnNvbGUubG9nKCdEZWZhdWx0IHZhbHVlOiAnICsgdGhpcy5kZWZhdWx0TGFuZ1ZhbCk7XHJcbiAgICAgICAgdGhpcy5zZWxlY3RlZEluZGV4ID0gdGhpcy5kZWZhdWx0TGFuZ1ZhbDtcclxuICAgIH1cclxuXHJcbiAgICBwdWJsaWMgYnV0dG9uU3VibWl0KCk6IHZvaWQge1xyXG4gICAgICAgIGxldCB0ZW1wRGF0YTogYW55ID0ge1xyXG4gICAgICAgICAgICBmb3JtSW5wdXRzOiB0aGlzLmxvZ2luRm9ybXMsXHJcbiAgICAgICAgICAgIGZvcm1WYWx1ZXM6IHRoaXMuZm9ybS52YWx1ZVxyXG4gICAgICAgIH1cclxuICAgICAgICB0aGlzLm9uRm9ybVN1Ym1pdC5lbWl0KHRlbXBEYXRhKTtcclxuICAgIH1cclxuXHJcbiAgICBwdWJsaWMgdXBkYXRlRGVmYXVsdExhbmd1YWdlKCk6IHZvaWQge1xyXG4gICAgICAgIC8vY29uc29sZS5sb2coJ0Zyb20gQ2hpbGQ6ICcgKyB0aGlzLnNlbGVjdGVkSW5kZXgpO1xyXG4gICAgICAgIHRoaXMub25MYW5ndWFnZUNoYW5nZS5lbWl0KHRoaXMuc2VsZWN0ZWRJbmRleCk7XHJcblxyXG4gICAgfVxyXG5cclxuXHJcblxyXG59XHJcbiJdfQ==