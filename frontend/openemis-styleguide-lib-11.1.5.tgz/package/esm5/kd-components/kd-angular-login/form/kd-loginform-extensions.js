import { __extends } from "tslib";
import { KdLoginFormBase } from './kd-loginform-base';
var KdLoginFormDropdown = /** @class */ (function (_super) {
    __extends(KdLoginFormDropdown, _super);
    function KdLoginFormDropdown(options) {
        if (options === void 0) { options = {}; }
        var _this = _super.call(this, options) || this;
        _this.controlType = 'dropdown';
        _this.options = [];
        _this.options = options['options'] || [];
        return _this;
    }
    return KdLoginFormDropdown;
}(KdLoginFormBase));
export { KdLoginFormDropdown };
var KdLoginFormText = /** @class */ (function (_super) {
    __extends(KdLoginFormText, _super);
    function KdLoginFormText(options) {
        if (options === void 0) { options = {}; }
        var _this = _super.call(this, options) || this;
        _this.controlType = 'text';
        _this.type = options['type'] || '';
        return _this;
    }
    return KdLoginFormText;
}(KdLoginFormBase));
export { KdLoginFormText };
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoia2QtbG9naW5mb3JtLWV4dGVuc2lvbnMuanMiLCJzb3VyY2VSb290Ijoibmc6Ly9vcGVuZW1pcy1zdHlsZWd1aWRlLWxpYi8iLCJzb3VyY2VzIjpbImtkLWNvbXBvbmVudHMva2QtYW5ndWxhci1sb2dpbi9mb3JtL2tkLWxvZ2luZm9ybS1leHRlbnNpb25zLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7QUFBQSxPQUFPLEVBQUUsZUFBZSxFQUFFLE1BQU0scUJBQXFCLENBQUM7QUFFdEQ7SUFBeUMsdUNBQXVCO0lBSTlELDZCQUFZLE9BQWdCO1FBQWhCLHdCQUFBLEVBQUEsWUFBZ0I7UUFBNUIsWUFDRSxrQkFBTSxPQUFPLENBQUMsU0FFZjtRQU5ELGlCQUFXLEdBQUcsVUFBVSxDQUFDO1FBQ3pCLGFBQU8sR0FBbUMsRUFBRSxDQUFDO1FBSTNDLEtBQUksQ0FBQyxPQUFPLEdBQUcsT0FBTyxDQUFDLFNBQVMsQ0FBQyxJQUFJLEVBQUUsQ0FBQzs7SUFDMUMsQ0FBQztJQUNILDBCQUFDO0FBQUQsQ0FBQyxBQVJELENBQXlDLGVBQWUsR0FRdkQ7O0FBRUQ7SUFBcUMsbUNBQXVCO0lBSTFELHlCQUFZLE9BQWdCO1FBQWhCLHdCQUFBLEVBQUEsWUFBZ0I7UUFBNUIsWUFDRSxrQkFBTSxPQUFPLENBQUMsU0FFZjtRQU5ELGlCQUFXLEdBQUcsTUFBTSxDQUFDO1FBS25CLEtBQUksQ0FBQyxJQUFJLEdBQUcsT0FBTyxDQUFDLE1BQU0sQ0FBQyxJQUFJLEVBQUUsQ0FBQzs7SUFDcEMsQ0FBQztJQUNILHNCQUFDO0FBQUQsQ0FBQyxBQVJELENBQXFDLGVBQWUsR0FRbkQiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBLZExvZ2luRm9ybUJhc2UgfSBmcm9tICcuL2tkLWxvZ2luZm9ybS1iYXNlJztcclxuXHJcbmV4cG9ydCBjbGFzcyBLZExvZ2luRm9ybURyb3Bkb3duIGV4dGVuZHMgS2RMb2dpbkZvcm1CYXNlPHN0cmluZz4ge1xyXG4gIGNvbnRyb2xUeXBlID0gJ2Ryb3Bkb3duJztcclxuICBvcHRpb25zOiB7a2V5OiBzdHJpbmcsIHZhbHVlOiBzdHJpbmd9W10gPSBbXTtcclxuXHJcbiAgY29uc3RydWN0b3Iob3B0aW9uczoge30gPSB7fSkge1xyXG4gICAgc3VwZXIob3B0aW9ucyk7XHJcbiAgICB0aGlzLm9wdGlvbnMgPSBvcHRpb25zWydvcHRpb25zJ10gfHwgW107XHJcbiAgfVxyXG59XHJcblxyXG5leHBvcnQgY2xhc3MgS2RMb2dpbkZvcm1UZXh0IGV4dGVuZHMgS2RMb2dpbkZvcm1CYXNlPHN0cmluZz4ge1xyXG4gIGNvbnRyb2xUeXBlID0gJ3RleHQnO1xyXG4gIHR5cGU6IHN0cmluZztcclxuXHJcbiAgY29uc3RydWN0b3Iob3B0aW9uczoge30gPSB7fSkge1xyXG4gICAgc3VwZXIob3B0aW9ucyk7XHJcbiAgICB0aGlzLnR5cGUgPSBvcHRpb25zWyd0eXBlJ10gfHwgJyc7XHJcbiAgfVxyXG59XHJcbiJdfQ==