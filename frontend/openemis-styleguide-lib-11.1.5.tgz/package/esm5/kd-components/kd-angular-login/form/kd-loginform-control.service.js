import { __decorate, __metadata } from "tslib";
import { Injectable } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { KdLoginFormDropdown, KdLoginFormText } from './kd-loginform-extensions';
var KdLoginFormControlService = /** @class */ (function () {
    function KdLoginFormControlService() {
    }
    KdLoginFormControlService.prototype.toFormGroup = function (loginForms) {
        var group = {};
        loginForms.forEach(function (loginForm) {
            group[loginForm.key] = loginForm.required ? new FormControl(loginForm.value || '', Validators.required)
                : new FormControl(loginForm.value || '');
        });
        return new FormGroup(group);
    };
    KdLoginFormControlService.prototype.getLoginForm = function (formData) {
        var formList = [];
        for (var i = 0; i < formData.length; i++) {
            var loginForm = void 0;
            switch (formData[i].controlType) {
                case "password":
                    loginForm = new KdLoginFormText(formData[i]);
                    break;
                case "dropdown":
                    loginForm = new KdLoginFormDropdown(formData[i]);
                    break;
                default:
                    loginForm = new KdLoginFormText(formData[i]);
                    break;
            }
            formList.push(loginForm);
        }
        return formList;
    };
    KdLoginFormControlService = __decorate([
        Injectable(),
        __metadata("design:paramtypes", [])
    ], KdLoginFormControlService);
    return KdLoginFormControlService;
}());
export { KdLoginFormControlService };
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoia2QtbG9naW5mb3JtLWNvbnRyb2wuc2VydmljZS5qcyIsInNvdXJjZVJvb3QiOiJuZzovL29wZW5lbWlzLXN0eWxlZ3VpZGUtbGliLyIsInNvdXJjZXMiOlsia2QtY29tcG9uZW50cy9rZC1hbmd1bGFyLWxvZ2luL2Zvcm0va2QtbG9naW5mb3JtLWNvbnRyb2wuc2VydmljZS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiO0FBQUEsT0FBTyxFQUFFLFVBQVUsRUFBRSxNQUFNLGVBQWUsQ0FBQztBQUMzQyxPQUFPLEVBQUUsV0FBVyxFQUFFLFNBQVMsRUFBRSxVQUFVLEVBQUUsTUFBTSxnQkFBZ0IsQ0FBQztBQUlwRSxPQUFPLEVBQ0gsbUJBQW1CLEVBQ25CLGVBQWUsRUFDbEIsTUFBTSwyQkFBMkIsQ0FBQztBQUduQztJQUNJO0lBQWdCLENBQUM7SUFFakIsK0NBQVcsR0FBWCxVQUFZLFVBQWtDO1FBQzFDLElBQUksS0FBSyxHQUFRLEVBQUUsQ0FBQztRQUVwQixVQUFVLENBQUMsT0FBTyxDQUFDLFVBQUEsU0FBUztZQUN4QixLQUFLLENBQUMsU0FBUyxDQUFDLEdBQUcsQ0FBQyxHQUFHLFNBQVMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLElBQUksV0FBVyxDQUFDLFNBQVMsQ0FBQyxLQUFLLElBQUksRUFBRSxFQUFFLFVBQVUsQ0FBQyxRQUFRLENBQUM7Z0JBQ25HLENBQUMsQ0FBQyxJQUFJLFdBQVcsQ0FBQyxTQUFTLENBQUMsS0FBSyxJQUFJLEVBQUUsQ0FBQyxDQUFDO1FBQ2pELENBQUMsQ0FBQyxDQUFDO1FBQ0gsT0FBTyxJQUFJLFNBQVMsQ0FBQyxLQUFLLENBQUMsQ0FBQztJQUNoQyxDQUFDO0lBRUQsZ0RBQVksR0FBWixVQUFhLFFBQW9CO1FBQzdCLElBQUksUUFBUSxHQUFlLEVBQUUsQ0FBQztRQUM5QixLQUFLLElBQUksQ0FBQyxHQUFXLENBQUMsRUFBRSxDQUFDLEdBQUcsUUFBUSxDQUFDLE1BQU0sRUFBRSxDQUFDLEVBQUUsRUFBRTtZQUM5QyxJQUFJLFNBQVMsU0FBc0IsQ0FBQztZQUVwQyxRQUFRLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxXQUFXLEVBQUU7Z0JBQzdCLEtBQUssVUFBVTtvQkFDWCxTQUFTLEdBQUcsSUFBSSxlQUFlLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7b0JBQzdDLE1BQU07Z0JBQ1YsS0FBSyxVQUFVO29CQUNYLFNBQVMsR0FBRyxJQUFJLG1CQUFtQixDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO29CQUNqRCxNQUFNO2dCQUNWO29CQUNJLFNBQVMsR0FBRyxJQUFJLGVBQWUsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztvQkFDN0MsTUFBTTthQUNiO1lBQ0QsUUFBUSxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsQ0FBQztTQUM1QjtRQUVELE9BQU8sUUFBUSxDQUFDO0lBRXBCLENBQUM7SUFsQ1EseUJBQXlCO1FBRHJDLFVBQVUsRUFBRTs7T0FDQSx5QkFBeUIsQ0FvQ3JDO0lBQUQsZ0NBQUM7Q0FBQSxBQXBDRCxJQW9DQztTQXBDWSx5QkFBeUIiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBJbmplY3RhYmxlIH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XHJcbmltcG9ydCB7IEZvcm1Db250cm9sLCBGb3JtR3JvdXAsIFZhbGlkYXRvcnMgfSBmcm9tICdAYW5ndWxhci9mb3Jtcyc7XHJcblxyXG5pbXBvcnQgeyBLZExvZ2luRm9ybUJhc2UgfSBmcm9tICcuL2tkLWxvZ2luZm9ybS1iYXNlJztcclxuXHJcbmltcG9ydCB7XHJcbiAgICBLZExvZ2luRm9ybURyb3Bkb3duLFxyXG4gICAgS2RMb2dpbkZvcm1UZXh0XHJcbn0gZnJvbSAnLi9rZC1sb2dpbmZvcm0tZXh0ZW5zaW9ucyc7XHJcblxyXG5ASW5qZWN0YWJsZSgpXHJcbmV4cG9ydCBjbGFzcyBLZExvZ2luRm9ybUNvbnRyb2xTZXJ2aWNlIHtcclxuICAgIGNvbnN0cnVjdG9yKCkgeyB9XHJcblxyXG4gICAgdG9Gb3JtR3JvdXAobG9naW5Gb3JtczogS2RMb2dpbkZvcm1CYXNlPGFueT5bXSkge1xyXG4gICAgICAgIGxldCBncm91cDogYW55ID0ge307XHJcblxyXG4gICAgICAgIGxvZ2luRm9ybXMuZm9yRWFjaChsb2dpbkZvcm0gPT4ge1xyXG4gICAgICAgICAgICBncm91cFtsb2dpbkZvcm0ua2V5XSA9IGxvZ2luRm9ybS5yZXF1aXJlZCA/IG5ldyBGb3JtQ29udHJvbChsb2dpbkZvcm0udmFsdWUgfHwgJycsIFZhbGlkYXRvcnMucmVxdWlyZWQpXHJcbiAgICAgICAgICAgICAgICA6IG5ldyBGb3JtQ29udHJvbChsb2dpbkZvcm0udmFsdWUgfHwgJycpO1xyXG4gICAgICAgIH0pO1xyXG4gICAgICAgIHJldHVybiBuZXcgRm9ybUdyb3VwKGdyb3VwKTtcclxuICAgIH1cclxuXHJcbiAgICBnZXRMb2dpbkZvcm0oZm9ybURhdGE6IEFycmF5PGFueT4pOiBBcnJheTxhbnk+IHtcclxuICAgICAgICBsZXQgZm9ybUxpc3Q6IEFycmF5PGFueT4gPSBbXTtcclxuICAgICAgICBmb3IgKGxldCBpOiBudW1iZXIgPSAwOyBpIDwgZm9ybURhdGEubGVuZ3RoOyBpKyspIHtcclxuICAgICAgICAgICAgbGV0IGxvZ2luRm9ybTogS2RMb2dpbkZvcm1CYXNlPGFueT47XHJcblxyXG4gICAgICAgICAgICBzd2l0Y2ggKGZvcm1EYXRhW2ldLmNvbnRyb2xUeXBlKSB7XHJcbiAgICAgICAgICAgICAgICBjYXNlIFwicGFzc3dvcmRcIjpcclxuICAgICAgICAgICAgICAgICAgICBsb2dpbkZvcm0gPSBuZXcgS2RMb2dpbkZvcm1UZXh0KGZvcm1EYXRhW2ldKTtcclxuICAgICAgICAgICAgICAgICAgICBicmVhaztcclxuICAgICAgICAgICAgICAgIGNhc2UgXCJkcm9wZG93blwiOlxyXG4gICAgICAgICAgICAgICAgICAgIGxvZ2luRm9ybSA9IG5ldyBLZExvZ2luRm9ybURyb3Bkb3duKGZvcm1EYXRhW2ldKTtcclxuICAgICAgICAgICAgICAgICAgICBicmVhaztcclxuICAgICAgICAgICAgICAgIGRlZmF1bHQ6XHJcbiAgICAgICAgICAgICAgICAgICAgbG9naW5Gb3JtID0gbmV3IEtkTG9naW5Gb3JtVGV4dChmb3JtRGF0YVtpXSk7XHJcbiAgICAgICAgICAgICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgZm9ybUxpc3QucHVzaChsb2dpbkZvcm0pO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgcmV0dXJuIGZvcm1MaXN0O1xyXG5cclxuICAgIH1cclxuXHJcbn1cclxuIl19