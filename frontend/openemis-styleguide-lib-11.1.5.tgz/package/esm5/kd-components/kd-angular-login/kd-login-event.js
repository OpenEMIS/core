import { __decorate, __metadata } from "tslib";
import { Injectable } from '@angular/core';
import { KdBroadcaster, } from '../kd-common/index';
import * as i0 from "@angular/core";
import * as i1 from "../kd-common/kd-broadcaster-svc";
var KdLoginErrorEvent = /** @class */ (function () {
    function KdLoginErrorEvent(_broadcaster) {
        this._broadcaster = _broadcaster;
    }
    /*setErrorMsg(data?: any): void {
        this._broadcaster.broadcast('ErrorMsg', data);
    }*/
    KdLoginErrorEvent.prototype.setAlertStatus = function (status) {
        this._broadcaster.broadcast('AlertStatus', status);
    };
    /*onSetErrorMsg(): Observable<any> {
        return this._broadcaster.on<any>('ErrorMsg');
    }*/
    KdLoginErrorEvent.prototype.onSetAlertStatus = function () {
        return this._broadcaster.on('AlertStatus');
    };
    KdLoginErrorEvent.ctorParameters = function () { return [
        { type: KdBroadcaster }
    ]; };
    KdLoginErrorEvent.ɵprov = i0.ɵɵdefineInjectable({ factory: function KdLoginErrorEvent_Factory() { return new KdLoginErrorEvent(i0.ɵɵinject(i1.KdBroadcaster)); }, token: KdLoginErrorEvent, providedIn: "root" });
    KdLoginErrorEvent = __decorate([
        Injectable({
            providedIn: 'root'
        }),
        __metadata("design:paramtypes", [KdBroadcaster])
    ], KdLoginErrorEvent);
    return KdLoginErrorEvent;
}());
export { KdLoginErrorEvent };
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoia2QtbG9naW4tZXZlbnQuanMiLCJzb3VyY2VSb290Ijoibmc6Ly9vcGVuZW1pcy1zdHlsZWd1aWRlLWxpYi8iLCJzb3VyY2VzIjpbImtkLWNvbXBvbmVudHMva2QtYW5ndWxhci1sb2dpbi9rZC1sb2dpbi1ldmVudC50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiO0FBQUEsT0FBTyxFQUFFLFVBQVUsRUFBRSxNQUFNLGVBQWUsQ0FBQztBQUUzQyxPQUFPLEVBQUUsYUFBYSxHQUFHLE1BQU0sb0JBQW9CLENBQUM7OztBQUtwRDtJQUNJLDJCQUFvQixZQUEyQjtRQUEzQixpQkFBWSxHQUFaLFlBQVksQ0FBZTtJQUFJLENBQUM7SUFFcEQ7O09BRUc7SUFFSCwwQ0FBYyxHQUFkLFVBQWUsTUFBYztRQUN6QixJQUFJLENBQUMsWUFBWSxDQUFDLFNBQVMsQ0FBQyxhQUFhLEVBQUUsTUFBTSxDQUFDLENBQUM7SUFDdkQsQ0FBQztJQUVEOztPQUVHO0lBRU4sNENBQWdCLEdBQWhCO1FBQ08sT0FBTyxJQUFJLENBQUMsWUFBWSxDQUFDLEVBQUUsQ0FBTSxhQUFhLENBQUMsQ0FBQztJQUNwRCxDQUFDOztnQkFoQmlDLGFBQWE7OztJQUR0QyxpQkFBaUI7UUFIN0IsVUFBVSxDQUFDO1lBQ1IsVUFBVSxFQUFFLE1BQU07U0FDckIsQ0FBQzt5Q0FFb0MsYUFBYTtPQUR0QyxpQkFBaUIsQ0FtQjdCOzRCQTFCRDtDQTBCQyxBQW5CRCxJQW1CQztTQW5CWSxpQkFBaUIiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBJbmplY3RhYmxlIH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XHJcbmltcG9ydCB7IE9ic2VydmFibGUgfSBmcm9tICdyeGpzJztcclxuaW1wb3J0IHsgS2RCcm9hZGNhc3RlciwgfSBmcm9tICcuLi9rZC1jb21tb24vaW5kZXgnO1xyXG5cclxuQEluamVjdGFibGUoe1xyXG4gICAgcHJvdmlkZWRJbjogJ3Jvb3QnXHJcbn0pXHJcbmV4cG9ydCBjbGFzcyBLZExvZ2luRXJyb3JFdmVudCB7XHJcbiAgICBjb25zdHJ1Y3Rvcihwcml2YXRlIF9icm9hZGNhc3RlcjogS2RCcm9hZGNhc3RlcikgeyB9XHJcblxyXG4gICAgLypzZXRFcnJvck1zZyhkYXRhPzogYW55KTogdm9pZCB7XHJcbiAgICAgICAgdGhpcy5fYnJvYWRjYXN0ZXIuYnJvYWRjYXN0KCdFcnJvck1zZycsIGRhdGEpO1xyXG4gICAgfSovXHJcblxyXG4gICAgc2V0QWxlcnRTdGF0dXMoc3RhdHVzOiBzdHJpbmcpOiB2b2lkIHtcclxuICAgICAgICB0aGlzLl9icm9hZGNhc3Rlci5icm9hZGNhc3QoJ0FsZXJ0U3RhdHVzJywgc3RhdHVzKTtcclxuICAgIH1cclxuXHJcbiAgICAvKm9uU2V0RXJyb3JNc2coKTogT2JzZXJ2YWJsZTxhbnk+IHtcclxuICAgICAgICByZXR1cm4gdGhpcy5fYnJvYWRjYXN0ZXIub248YW55PignRXJyb3JNc2cnKTtcclxuICAgIH0qL1xyXG5cclxuXHRvblNldEFsZXJ0U3RhdHVzKCk6IE9ic2VydmFibGU8YW55PiB7XHJcbiAgICAgICAgcmV0dXJuIHRoaXMuX2Jyb2FkY2FzdGVyLm9uPGFueT4oJ0FsZXJ0U3RhdHVzJyk7XHJcbiAgICB9XHJcblxyXG59XHJcbiJdfQ==