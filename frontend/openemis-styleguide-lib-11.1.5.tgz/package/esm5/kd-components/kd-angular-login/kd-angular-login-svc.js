import { __decorate } from "tslib";
import { Injectable } from '@angular/core';
var KdLoginSvc = /** @class */ (function () {
    function KdLoginSvc() {
    }
    KdLoginSvc.prototype.getHeaderConfigValues = function (_config, _defaultConfig) {
        var updateHeaderConfig = {};
        if (typeof _config === 'undefined' || typeof _config.header === 'undefined') {
            if (typeof _defaultConfig !== 'undefined')
                updateHeaderConfig = JSON.parse(JSON.stringify(_defaultConfig));
            else
                updateHeaderConfig = { icon: 'kd-openemis', title: 'OpenEMIS' };
        }
        else {
            updateHeaderConfig = _config.header;
            if (typeof updateHeaderConfig.img !== 'undefined' && typeof updateHeaderConfig.icon !== 'undefined')
                updateHeaderConfig.img = '';
            if (typeof updateHeaderConfig.img === 'undefined' && typeof updateHeaderConfig.icon === 'undefined')
                updateHeaderConfig.icon = '';
            if (typeof updateHeaderConfig.icon !== 'undefined' && typeof updateHeaderConfig.title === 'undefined')
                updateHeaderConfig.title = '';
            if (typeof updateHeaderConfig.img !== 'undefined' && typeof updateHeaderConfig.imgSize === 'undefined')
                updateHeaderConfig.imgSize = 'none';
            if (typeof updateHeaderConfig.headerMsg !== 'undefined' && typeof updateHeaderConfig.headerMsg === 'undefined')
                updateHeaderConfig.headerMsg = '';
        }
        return this._setProductAppConfig(updateHeaderConfig);
    };
    /*
        set default language config
            - if config is undefined, langunage undefined, show undefined - return default
                - if config list is defined, list got item, and show is true - set config to show with toggle
                - else if config default is defined - set config with default language and toggle false
        - return config
     */
    KdLoginSvc.prototype.getLanguageConfigValues = function (_config) {
        if (_config.hasOwnProperty('language') && _config.language.hasOwnProperty('options')) {
            return _config.language.options;
        }
        return this.getSixDefaultLanguage();
    };
    KdLoginSvc.prototype.getLangageDefaultValue = function (_config) {
        var returnVal = 'en';
        if (_config.hasOwnProperty('language') && _config.language.hasOwnProperty('value')) {
            return _config.language.value;
        }
        return returnVal;
    };
    KdLoginSvc.prototype.getSixDefaultLanguage = function () {
        var defaultList = [
            {
                value: 'العربية', key: 'ar', dir: 'rtl'
            }, {
                value: '中文', key: 'zh', dir: 'ltr'
            }, {
                value: 'English', key: 'en', dir: 'ltr'
            }, {
                value: 'Français', key: 'fr', dir: 'ltr'
            }, {
                value: 'русский', key: 'ru', dir: 'ltr'
            }, {
                value: 'español', key: 'es', dir: 'ltr'
            } //,
            // value: 'en'
        ];
        return defaultList;
    };
    KdLoginSvc.prototype.updateLanguageDir = function (_config, _selectedIndex) {
        // console.log('Parent svc run: ' + _selectedIndex);
        var langOptions = this.getLanguageConfigValues(_config);
        var dir = this.checkLanguageDir(langOptions, _selectedIndex);
        // console.log('Return this: ' + dir);
        return dir;
    };
    KdLoginSvc.prototype.checkLanguageDir = function (_langOptions, _selectedIndex) {
        for (var i = 0; i < _langOptions.length; i++) {
            if (_langOptions[i].key === _selectedIndex) {
                // console.log('Detected this: ' + _langOptions[i].dir);
                return _langOptions[i].dir;
            }
        }
    };
    KdLoginSvc.prototype.getFormInputs = function (_type, _config) {
        var formInputs = [];
        switch (_type) {
            case "reset-password":
                formInputs = [
                    {
                        'key': 'newpassword',
                        'label': 'Confirm Password',
                        'class': 'input',
                        'iconClass': 'fa fa-key iconSizeS',
                        'controlType': 'password',
                        'type': 'password',
                        'value': ''
                    },
                    {
                        'key': 'confirmpassword',
                        'label': 'New Password',
                        'class': 'input',
                        'iconClass': 'fa fa-key iconSizeS',
                        'controlType': 'password',
                        'type': 'password',
                        'value': ''
                    }
                ];
                break;
            case "forget-username":
                formInputs = [
                    {
                        'key': 'useremail',
                        'label': 'Email',
                        'class': 'input',
                        'iconClass': 'fa fa-envelope-o iconSizeS',
                        'controlType': 'textbox',
                        'value': ''
                    }
                ];
                break;
            case "forget-password":
                formInputs = [
                    {
                        'key': 'userinput',
                        'label': 'User Name or Email',
                        'class': 'input',
                        'iconClass': 'fa fa-user',
                        'controlType': 'textbox',
                        'value': ''
                    }
                    // {
                    //     'key': 'useremail',
                    //     'label': 'Email',
                    //     'class': 'input email',
                    //     'controlType': 'textbox',
                    //     'value': ''
                    // }
                ];
                break;
            default:
                formInputs = [
                    {
                        'key': 'username',
                        'label': 'User Name',
                        'class': 'input',
                        'iconClass': 'fa fa-user',
                        'controlType': 'text',
                        'value': ''
                    },
                    {
                        'key': 'password',
                        'label': 'Password',
                        'class': 'input',
                        'iconClass': 'fa fa-key iconSizeS',
                        'controlType': 'text',
                        'type': 'password',
                        'value': ''
                    },
                    {
                        'key': 'language',
                        'class': 'kdx-input-select-wrapper',
                        'iconClass': 'fa fa-globe',
                        'value': _config.value,
                        'options': _config.options,
                        'controlType': 'dropdown'
                    }
                ];
                break;
        }
        return formInputs;
    };
    KdLoginSvc.prototype.getButtonLabel = function (_type, _label) {
        var tempLabel = "Submit";
        switch (_type) {
            case "reset-password":
                if (typeof _label !== 'undefined')
                    tempLabel = _label;
                else
                    tempLabel = 'Update Password';
                break;
            case "forget-username":
                if (typeof _label !== 'undefined')
                    tempLabel = _label;
                else
                    tempLabel = 'Recover Username';
                break;
            case "forget-password":
                if (typeof _label !== 'undefined')
                    tempLabel = _label;
                else
                    tempLabel = 'Reset Password';
                break;
            default:
                if (typeof _label !== 'undefined')
                    tempLabel = _label;
                else
                    tempLabel = 'Login';
                break;
        }
        return tempLabel;
    };
    KdLoginSvc.prototype.getFormLinks = function (_config, _type) {
        var returnData = [];
        var defaultLink = this.getDefaultFormLinks(_type);
        switch (_type) {
            case "reset-password":
                returnData.push(Object.assign(defaultLink.back, _config.formLinks.back));
                break;
            case "forget-username":
                returnData.push(Object.assign(defaultLink.back, _config.formLinks.back));
                break;
            case "forget-password":
                returnData.push(Object.assign(defaultLink.back, _config.formLinks.back));
                break;
            default:
                if (_config.formLinks && _config.formLinks.forgetPassword)
                    returnData.push(Object.assign(defaultLink.forgetPassword, _config.formLinks.forgetPassword));
                if (_config.formLinks && _config.formLinks.forgetUser)
                    returnData.push(Object.assign(defaultLink.forgetUser, _config.formLinks.forgetUser));
                break;
        }
        return returnData;
        // if (_config.hasOwnProperty('formLinks') && _config.formLinks.hasOwnProperty(_linkType) && _config.formLinks[_linkType].hasOwnProperty('path')) {
        //     //return _config.formLinks.forgetPassword.path;
        //     let forgetPassword: any = {
        //         path: _config.formLinks.forgetPassword.path
        //     }
        // return forgetPassword;
        // }
    };
    KdLoginSvc.prototype.getDefaultFormLinks = function (_type) {
        var returnData = {};
        switch (_type) {
            case "reset-password":
                returnData = {
                    back: {
                        label: 'Back to login?'
                    }
                };
                break;
            case "forget-username":
                returnData = {
                    back: {
                        label: 'Back to login?'
                    }
                };
                break;
            case "forget-password":
                returnData = {
                    back: {
                        label: 'Back to login?'
                    }
                };
                break;
            default:
                returnData = {
                    forgetPassword: {
                        label: 'Forget Password?'
                    },
                    forgetUser: {
                        label: 'Forget Username?'
                    }
                };
                break;
        }
        return returnData;
    };
    // public getFormAlerts(_config: ILoginConfig, _type: string): IFormAlertConfig | boolean {
    //     if (_config.hasOwnProperty('alert') && _config.alert.hasOwnProperty('errorMsg')) {
    //         let returnData: IFormAlertConfig = JSON.parse(JSON.stringify(_config.alert));
    //         if (!_config.alert.hasOwnProperty('successMsg') && _type !== 'login') {
    //             returnData['successMsg'] = 'An email will be send shortly. Please check your mailbox.';
    //         }
    //         return returnData;
    //     }
    //     return false;
    // }
    // public setAlertMessage(_value: string, _formAlerts: any): string {
    //     let returnVal: string;
    //     if (_value === 'success') {
    //         returnVal = _formAlerts.successMsg;
    //     } else if (_value === 'danger') {
    //         returnVal = _formAlerts.errorMsg;
    //     }
    //     return returnVal;
    // }
    KdLoginSvc.prototype._setProductAppConfig = function (_updateHeaderConfig) {
        // let tempHeaderConfig:any = _updateHeaderConfig;
        try {
            if (APP_CONFIGS.hasOwnProperty('product')) {
                var type = (APP_CONFIGS.product.hasOwnProperty('type')) ? APP_CONFIGS.product.type : 'icon';
                if (APP_CONFIGS.product.hasOwnProperty('name')) {
                    _updateHeaderConfig.title = APP_CONFIGS.product.name;
                }
                if (APP_CONFIGS.product.hasOwnProperty('src')) {
                    switch (type) {
                        case 'icon':
                            _updateHeaderConfig.icon = APP_CONFIGS.product.src;
                            break;
                        case 'image':
                            _updateHeaderConfig.img = APP_CONFIGS.product.src;
                            break;
                        default:
                            break;
                    }
                }
            }
        }
        catch (err) {
            // console.log(err);
        }
        return _updateHeaderConfig;
    };
    KdLoginSvc.prototype.getLogoSizeClass = function (headerConfig) {
        if (typeof headerConfig.imgSize !== 'undefined')
            return headerConfig.imgSize;
        if (typeof headerConfig.img !== 'undefined' && typeof headerConfig.title === 'undefined')
            return 'full';
        return 'small';
    };
    KdLoginSvc.prototype.getDemoLogin = function (requestString) {
        var tempString = requestString.replace(' ', '');
        var splitString = tempString.split(',');
        var demoInfo = {};
        if (splitString.length === 2) {
            demoInfo = {
                user: splitString[0],
                pass: splitString[1]
            };
        }
        return demoInfo;
    };
    KdLoginSvc = __decorate([
        Injectable()
    ], KdLoginSvc);
    return KdLoginSvc;
}());
export { KdLoginSvc };
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoia2QtYW5ndWxhci1sb2dpbi1zdmMuanMiLCJzb3VyY2VSb290Ijoibmc6Ly9vcGVuZW1pcy1zdHlsZWd1aWRlLWxpYi8iLCJzb3VyY2VzIjpbImtkLWNvbXBvbmVudHMva2QtYW5ndWxhci1sb2dpbi9rZC1hbmd1bGFyLWxvZ2luLXN2Yy50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiO0FBQUEsT0FBTyxFQUFFLFVBQVUsRUFBYSxNQUFNLGVBQWUsQ0FBQztBQWN0RDtJQUFBO0lBOFdBLENBQUM7SUExV1UsMENBQXFCLEdBQTVCLFVBQTZCLE9BQVksRUFBRSxjQUFtQjtRQUMxRCxJQUFJLGtCQUFrQixHQUFRLEVBQUUsQ0FBQztRQUNqQyxJQUFJLE9BQU8sT0FBTyxLQUFLLFdBQVcsSUFBSSxPQUFPLE9BQU8sQ0FBQyxNQUFNLEtBQUssV0FBVyxFQUFFO1lBQ3pFLElBQUksT0FBTyxjQUFjLEtBQUssV0FBVztnQkFBRSxrQkFBa0IsR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsY0FBYyxDQUFDLENBQUMsQ0FBQzs7Z0JBQ3RHLGtCQUFrQixHQUFHLEVBQUUsSUFBSSxFQUFFLGFBQWEsRUFBRSxLQUFLLEVBQUUsVUFBVSxFQUFFLENBQUM7U0FDeEU7YUFDSTtZQUNELGtCQUFrQixHQUFHLE9BQU8sQ0FBQyxNQUFNLENBQUM7WUFDcEMsSUFBSSxPQUFPLGtCQUFrQixDQUFDLEdBQUcsS0FBSyxXQUFXLElBQUksT0FBTyxrQkFBa0IsQ0FBQyxJQUFJLEtBQUssV0FBVztnQkFBRSxrQkFBa0IsQ0FBQyxHQUFHLEdBQUcsRUFBRSxDQUFDO1lBQ2pJLElBQUksT0FBTyxrQkFBa0IsQ0FBQyxHQUFHLEtBQUssV0FBVyxJQUFJLE9BQU8sa0JBQWtCLENBQUMsSUFBSSxLQUFLLFdBQVc7Z0JBQUUsa0JBQWtCLENBQUMsSUFBSSxHQUFHLEVBQUUsQ0FBQztZQUNsSSxJQUFJLE9BQU8sa0JBQWtCLENBQUMsSUFBSSxLQUFLLFdBQVcsSUFBSSxPQUFPLGtCQUFrQixDQUFDLEtBQUssS0FBSyxXQUFXO2dCQUFFLGtCQUFrQixDQUFDLEtBQUssR0FBRyxFQUFFLENBQUM7WUFDckksSUFBSSxPQUFPLGtCQUFrQixDQUFDLEdBQUcsS0FBSyxXQUFXLElBQUksT0FBTyxrQkFBa0IsQ0FBQyxPQUFPLEtBQUssV0FBVztnQkFBRSxrQkFBa0IsQ0FBQyxPQUFPLEdBQUcsTUFBTSxDQUFDO1lBQzVJLElBQUksT0FBTyxrQkFBa0IsQ0FBQyxTQUFTLEtBQUssV0FBVyxJQUFJLE9BQU8sa0JBQWtCLENBQUMsU0FBUyxLQUFLLFdBQVc7Z0JBQUUsa0JBQWtCLENBQUMsU0FBUyxHQUFHLEVBQUUsQ0FBQztTQUNySjtRQUVELE9BQU8sSUFBSSxDQUFDLG9CQUFvQixDQUFDLGtCQUFrQixDQUFDLENBQUM7SUFDekQsQ0FBQztJQUVEOzs7Ozs7T0FNRztJQUNJLDRDQUF1QixHQUE5QixVQUErQixPQUFxQjtRQUNoRCxJQUFJLE9BQU8sQ0FBQyxjQUFjLENBQUMsVUFBVSxDQUFDLElBQUksT0FBTyxDQUFDLFFBQVEsQ0FBQyxjQUFjLENBQUMsU0FBUyxDQUFDLEVBQUU7WUFDbEYsT0FBTyxPQUFPLENBQUMsUUFBUSxDQUFDLE9BQU8sQ0FBQztTQUNuQztRQUVELE9BQU8sSUFBSSxDQUFDLHFCQUFxQixFQUFFLENBQUM7SUFDeEMsQ0FBQztJQUVNLDJDQUFzQixHQUE3QixVQUE4QixPQUFxQjtRQUMvQyxJQUFJLFNBQVMsR0FBVyxJQUFJLENBQUM7UUFDN0IsSUFBSSxPQUFPLENBQUMsY0FBYyxDQUFDLFVBQVUsQ0FBQyxJQUFJLE9BQU8sQ0FBQyxRQUFRLENBQUMsY0FBYyxDQUFDLE9BQU8sQ0FBQyxFQUFFO1lBQ2hGLE9BQU8sT0FBTyxDQUFDLFFBQVEsQ0FBQyxLQUFLLENBQUM7U0FDakM7UUFFRCxPQUFPLFNBQVMsQ0FBQztJQUNyQixDQUFDO0lBRU0sMENBQXFCLEdBQTVCO1FBQ0ksSUFBSSxXQUFXLEdBQWU7WUFDMUI7Z0JBQ0ksS0FBSyxFQUFFLFNBQVMsRUFBRSxHQUFHLEVBQUUsSUFBSSxFQUFFLEdBQUcsRUFBRSxLQUFLO2FBQzFDLEVBQUU7Z0JBQ0MsS0FBSyxFQUFFLElBQUksRUFBRSxHQUFHLEVBQUUsSUFBSSxFQUFFLEdBQUcsRUFBRSxLQUFLO2FBQ3JDLEVBQUU7Z0JBQ0MsS0FBSyxFQUFFLFNBQVMsRUFBRSxHQUFHLEVBQUUsSUFBSSxFQUFFLEdBQUcsRUFBRSxLQUFLO2FBQzFDLEVBQUU7Z0JBQ0MsS0FBSyxFQUFFLFVBQVUsRUFBRSxHQUFHLEVBQUUsSUFBSSxFQUFFLEdBQUcsRUFBRSxLQUFLO2FBQzNDLEVBQUU7Z0JBQ0MsS0FBSyxFQUFFLFNBQVMsRUFBRSxHQUFHLEVBQUUsSUFBSSxFQUFFLEdBQUcsRUFBRSxLQUFLO2FBQzFDLEVBQUU7Z0JBQ0MsS0FBSyxFQUFFLFNBQVMsRUFBRSxHQUFHLEVBQUUsSUFBSSxFQUFFLEdBQUcsRUFBRSxLQUFLO2FBQzFDLENBQUEsR0FBRztZQUNKLGNBQWM7U0FDakIsQ0FBQztRQUVGLE9BQU8sV0FBVyxDQUFDO0lBQ3ZCLENBQUM7SUFFTSxzQ0FBaUIsR0FBeEIsVUFBeUIsT0FBcUIsRUFBRSxjQUFzQjtRQUNsRSxvREFBb0Q7UUFDcEQsSUFBSSxXQUFXLEdBQUcsSUFBSSxDQUFDLHVCQUF1QixDQUFDLE9BQU8sQ0FBQyxDQUFDO1FBQ3hELElBQUksR0FBRyxHQUFHLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxXQUFXLEVBQUUsY0FBYyxDQUFDLENBQUM7UUFDN0Qsc0NBQXNDO1FBQ3RDLE9BQU8sR0FBRyxDQUFDO0lBR2YsQ0FBQztJQUVNLHFDQUFnQixHQUF2QixVQUF3QixZQUFpQixFQUFFLGNBQXNCO1FBQzdELEtBQUssSUFBSSxDQUFDLEdBQVcsQ0FBQyxFQUFFLENBQUMsR0FBRyxZQUFZLENBQUMsTUFBTSxFQUFFLENBQUMsRUFBRSxFQUFFO1lBQ2xELElBQUksWUFBWSxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsS0FBSyxjQUFjLEVBQUU7Z0JBQ3hDLHdEQUF3RDtnQkFDeEQsT0FBTyxZQUFZLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDO2FBRTlCO1NBQ0o7SUFDTCxDQUFDO0lBRU0sa0NBQWEsR0FBcEIsVUFBcUIsS0FBYSxFQUFFLE9BQWE7UUFDN0MsSUFBSSxVQUFVLEdBQWUsRUFBRSxDQUFDO1FBQ2hDLFFBQVEsS0FBSyxFQUFFO1lBQ1gsS0FBSyxnQkFBZ0I7Z0JBQ2pCLFVBQVUsR0FBRztvQkFDVDt3QkFDSSxLQUFLLEVBQUUsYUFBYTt3QkFDcEIsT0FBTyxFQUFFLGtCQUFrQjt3QkFDM0IsT0FBTyxFQUFFLE9BQU87d0JBQ2hCLFdBQVcsRUFBRSxxQkFBcUI7d0JBQ2xDLGFBQWEsRUFBRSxVQUFVO3dCQUN6QixNQUFNLEVBQUUsVUFBVTt3QkFDbEIsT0FBTyxFQUFFLEVBQUU7cUJBQ2Q7b0JBQ0Q7d0JBQ0ksS0FBSyxFQUFFLGlCQUFpQjt3QkFDeEIsT0FBTyxFQUFFLGNBQWM7d0JBQ3ZCLE9BQU8sRUFBRSxPQUFPO3dCQUNoQixXQUFXLEVBQUUscUJBQXFCO3dCQUNsQyxhQUFhLEVBQUUsVUFBVTt3QkFDekIsTUFBTSxFQUFFLFVBQVU7d0JBQ2xCLE9BQU8sRUFBRSxFQUFFO3FCQUNkO2lCQUNKLENBQUE7Z0JBQ0QsTUFBTTtZQUNWLEtBQUssaUJBQWlCO2dCQUNsQixVQUFVLEdBQUc7b0JBQ1Q7d0JBQ0ksS0FBSyxFQUFFLFdBQVc7d0JBQ2xCLE9BQU8sRUFBRSxPQUFPO3dCQUNoQixPQUFPLEVBQUUsT0FBTzt3QkFDaEIsV0FBVyxFQUFFLDRCQUE0Qjt3QkFDekMsYUFBYSxFQUFFLFNBQVM7d0JBQ3hCLE9BQU8sRUFBRSxFQUFFO3FCQUNkO2lCQUNKLENBQUE7Z0JBQ0QsTUFBTTtZQUNWLEtBQUssaUJBQWlCO2dCQUNsQixVQUFVLEdBQUc7b0JBQ1Q7d0JBQ0ksS0FBSyxFQUFFLFdBQVc7d0JBQ2xCLE9BQU8sRUFBRSxvQkFBb0I7d0JBQzdCLE9BQU8sRUFBRSxPQUFPO3dCQUNoQixXQUFXLEVBQUUsWUFBWTt3QkFDekIsYUFBYSxFQUFFLFNBQVM7d0JBQ3hCLE9BQU8sRUFBRSxFQUFFO3FCQUNkO29CQUNELElBQUk7b0JBQ0osMEJBQTBCO29CQUMxQix3QkFBd0I7b0JBQ3hCLDhCQUE4QjtvQkFDOUIsZ0NBQWdDO29CQUNoQyxrQkFBa0I7b0JBQ2xCLElBQUk7aUJBQ1AsQ0FBQTtnQkFDRCxNQUFNO1lBQ1Y7Z0JBQ0ksVUFBVSxHQUFHO29CQUNUO3dCQUNJLEtBQUssRUFBRSxVQUFVO3dCQUNqQixPQUFPLEVBQUUsV0FBVzt3QkFDcEIsT0FBTyxFQUFFLE9BQU87d0JBQ2hCLFdBQVcsRUFBRSxZQUFZO3dCQUN6QixhQUFhLEVBQUUsTUFBTTt3QkFDckIsT0FBTyxFQUFFLEVBQUU7cUJBQ2Q7b0JBQ0Q7d0JBQ0ksS0FBSyxFQUFFLFVBQVU7d0JBQ2pCLE9BQU8sRUFBRSxVQUFVO3dCQUNuQixPQUFPLEVBQUUsT0FBTzt3QkFDaEIsV0FBVyxFQUFFLHFCQUFxQjt3QkFDbEMsYUFBYSxFQUFFLE1BQU07d0JBQ3JCLE1BQU0sRUFBRSxVQUFVO3dCQUNsQixPQUFPLEVBQUUsRUFBRTtxQkFDZDtvQkFDRDt3QkFDSSxLQUFLLEVBQUUsVUFBVTt3QkFDakIsT0FBTyxFQUFFLDBCQUEwQjt3QkFDbkMsV0FBVyxFQUFFLGFBQWE7d0JBQzFCLE9BQU8sRUFBRSxPQUFPLENBQUMsS0FBSzt3QkFDdEIsU0FBUyxFQUFFLE9BQU8sQ0FBQyxPQUFPO3dCQUMxQixhQUFhLEVBQUUsVUFBVTtxQkFDNUI7aUJBQ0osQ0FBQTtnQkFDRCxNQUFNO1NBQ2I7UUFFRCxPQUFPLFVBQVUsQ0FBQztJQUN0QixDQUFDO0lBRU0sbUNBQWMsR0FBckIsVUFBc0IsS0FBYSxFQUFFLE1BQWU7UUFDaEQsSUFBSSxTQUFTLEdBQVcsUUFBUSxDQUFDO1FBRWpDLFFBQVEsS0FBSyxFQUFFO1lBRVgsS0FBSyxnQkFBZ0I7Z0JBQ2pCLElBQUksT0FBTyxNQUFNLEtBQUssV0FBVztvQkFBRSxTQUFTLEdBQUcsTUFBTSxDQUFDOztvQkFDakQsU0FBUyxHQUFHLGlCQUFpQixDQUFBO2dCQUNsQyxNQUFNO1lBRVYsS0FBSyxpQkFBaUI7Z0JBQ2xCLElBQUksT0FBTyxNQUFNLEtBQUssV0FBVztvQkFBRSxTQUFTLEdBQUcsTUFBTSxDQUFDOztvQkFDakQsU0FBUyxHQUFHLGtCQUFrQixDQUFBO2dCQUNuQyxNQUFNO1lBRVYsS0FBSyxpQkFBaUI7Z0JBQ2xCLElBQUksT0FBTyxNQUFNLEtBQUssV0FBVztvQkFBRSxTQUFTLEdBQUcsTUFBTSxDQUFDOztvQkFDakQsU0FBUyxHQUFHLGdCQUFnQixDQUFBO2dCQUNqQyxNQUFNO1lBRVY7Z0JBQ0ksSUFBSSxPQUFPLE1BQU0sS0FBSyxXQUFXO29CQUFFLFNBQVMsR0FBRyxNQUFNLENBQUM7O29CQUNqRCxTQUFTLEdBQUcsT0FBTyxDQUFBO2dCQUN4QixNQUFNO1NBQ2I7UUFFRCxPQUFPLFNBQVMsQ0FBQztJQUNyQixDQUFDO0lBRU0saUNBQVksR0FBbkIsVUFBb0IsT0FBcUIsRUFBRSxLQUFhO1FBQ3BELElBQUksVUFBVSxHQUEyQixFQUFFLENBQUE7UUFFM0MsSUFBSSxXQUFXLEdBQVEsSUFBSSxDQUFDLG1CQUFtQixDQUFDLEtBQUssQ0FBQyxDQUFDO1FBRXZELFFBQVEsS0FBSyxFQUFFO1lBRVgsS0FBSyxnQkFBZ0I7Z0JBQ2pCLFVBQVUsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxXQUFXLENBQUMsSUFBSSxFQUFFLE9BQU8sQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQTtnQkFDeEUsTUFBTTtZQUVWLEtBQUssaUJBQWlCO2dCQUNsQixVQUFVLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsV0FBVyxDQUFDLElBQUksRUFBRSxPQUFPLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUE7Z0JBQ3hFLE1BQU07WUFFVixLQUFLLGlCQUFpQjtnQkFDbEIsVUFBVSxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLFdBQVcsQ0FBQyxJQUFJLEVBQUUsT0FBTyxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFBO2dCQUN4RSxNQUFNO1lBRVY7Z0JBQ0ksSUFBRyxPQUFPLENBQUMsU0FBUyxJQUFJLE9BQU8sQ0FBQyxTQUFTLENBQUMsY0FBYztvQkFDeEQsVUFBVSxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLFdBQVcsQ0FBQyxjQUFjLEVBQUUsT0FBTyxDQUFDLFNBQVMsQ0FBQyxjQUFjLENBQUMsQ0FBQyxDQUFBO2dCQUM1RixJQUFHLE9BQU8sQ0FBQyxTQUFTLElBQUksT0FBTyxDQUFDLFNBQVMsQ0FBQyxVQUFVO29CQUNwRCxVQUFVLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsV0FBVyxDQUFDLFVBQVUsRUFBRSxPQUFPLENBQUMsU0FBUyxDQUFDLFVBQVUsQ0FBQyxDQUFDLENBQUE7Z0JBQ3BGLE1BQU07U0FDYjtRQUVELE9BQU8sVUFBVSxDQUFDO1FBRWxCLG1KQUFtSjtRQUNuSixzREFBc0Q7UUFDdEQsa0NBQWtDO1FBQ2xDLHNEQUFzRDtRQUN0RCxRQUFRO1FBRVIseUJBQXlCO1FBQ3pCLElBQUk7SUFDUixDQUFDO0lBRU8sd0NBQW1CLEdBQTNCLFVBQTRCLEtBQWE7UUFDckMsSUFBSSxVQUFVLEdBQVEsRUFBRSxDQUFDO1FBRXpCLFFBQVEsS0FBSyxFQUFFO1lBRVgsS0FBSyxnQkFBZ0I7Z0JBQ2pCLFVBQVUsR0FBRztvQkFDVCxJQUFJLEVBQUU7d0JBQ0YsS0FBSyxFQUFFLGdCQUFnQjtxQkFDMUI7aUJBQ0osQ0FBQTtnQkFDRCxNQUFNO1lBRVYsS0FBSyxpQkFBaUI7Z0JBQ2xCLFVBQVUsR0FBRztvQkFDVCxJQUFJLEVBQUU7d0JBQ0YsS0FBSyxFQUFFLGdCQUFnQjtxQkFDMUI7aUJBQ0osQ0FBQTtnQkFDRCxNQUFNO1lBRVYsS0FBSyxpQkFBaUI7Z0JBQ2xCLFVBQVUsR0FBRztvQkFDVCxJQUFJLEVBQUU7d0JBQ0YsS0FBSyxFQUFFLGdCQUFnQjtxQkFDMUI7aUJBQ0osQ0FBQTtnQkFDRCxNQUFNO1lBRVY7Z0JBQ0ksVUFBVSxHQUFHO29CQUNULGNBQWMsRUFBRTt3QkFDWixLQUFLLEVBQUUsa0JBQWtCO3FCQUM1QjtvQkFDRCxVQUFVLEVBQUU7d0JBQ1IsS0FBSyxFQUFFLGtCQUFrQjtxQkFDNUI7aUJBQ0osQ0FBQTtnQkFDRCxNQUFNO1NBQ2I7UUFDRCxPQUFPLFVBQVUsQ0FBQztJQUN0QixDQUFDO0lBRUQsMkZBQTJGO0lBQzNGLHlGQUF5RjtJQUN6Rix3RkFBd0Y7SUFFeEYsa0ZBQWtGO0lBQ2xGLHNHQUFzRztJQUN0RyxZQUFZO0lBQ1osNkJBQTZCO0lBQzdCLFFBQVE7SUFDUixvQkFBb0I7SUFDcEIsSUFBSTtJQUVKLHFFQUFxRTtJQUNyRSw2QkFBNkI7SUFFN0Isa0NBQWtDO0lBQ2xDLDhDQUE4QztJQUM5Qyx3Q0FBd0M7SUFDeEMsNENBQTRDO0lBQzVDLFFBQVE7SUFFUix3QkFBd0I7SUFDeEIsSUFBSTtJQUtJLHlDQUFvQixHQUE1QixVQUE2QixtQkFBd0I7UUFDakQsa0RBQWtEO1FBQ2xELElBQUk7WUFDQSxJQUFJLFdBQVcsQ0FBQyxjQUFjLENBQUMsU0FBUyxDQUFDLEVBQUU7Z0JBQ3ZDLElBQUksSUFBSSxHQUFXLENBQUMsV0FBVyxDQUFDLE9BQU8sQ0FBQyxjQUFjLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsV0FBVyxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQztnQkFFcEcsSUFBSSxXQUFXLENBQUMsT0FBTyxDQUFDLGNBQWMsQ0FBQyxNQUFNLENBQUMsRUFBRTtvQkFDNUMsbUJBQW1CLENBQUMsS0FBSyxHQUFHLFdBQVcsQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDO2lCQUN4RDtnQkFFRCxJQUFJLFdBQVcsQ0FBQyxPQUFPLENBQUMsY0FBYyxDQUFDLEtBQUssQ0FBQyxFQUFFO29CQUMzQyxRQUFRLElBQUksRUFBRTt3QkFDVixLQUFLLE1BQU07NEJBQ1AsbUJBQW1CLENBQUMsSUFBSSxHQUFHLFdBQVcsQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDOzRCQUNuRCxNQUFNO3dCQUNWLEtBQUssT0FBTzs0QkFDUixtQkFBbUIsQ0FBQyxHQUFHLEdBQUcsV0FBVyxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUM7NEJBQ2xELE1BQU07d0JBQ1Y7NEJBQ0ksTUFBTTtxQkFDYjtpQkFDSjthQUNKO1NBQ0o7UUFBQyxPQUFPLEdBQUcsRUFBRTtZQUNWLG9CQUFvQjtTQUN2QjtRQUVELE9BQU8sbUJBQW1CLENBQUM7SUFDL0IsQ0FBQztJQUlELHFDQUFnQixHQUFoQixVQUFpQixZQUFpQjtRQUM5QixJQUFJLE9BQU8sWUFBWSxDQUFDLE9BQU8sS0FBSyxXQUFXO1lBQUUsT0FBTyxZQUFZLENBQUMsT0FBTyxDQUFDO1FBQzdFLElBQUksT0FBTyxZQUFZLENBQUMsR0FBRyxLQUFLLFdBQVcsSUFBSSxPQUFPLFlBQVksQ0FBQyxLQUFLLEtBQUssV0FBVztZQUFFLE9BQU8sTUFBTSxDQUFDO1FBQ3hHLE9BQU8sT0FBTyxDQUFDO0lBQ25CLENBQUM7SUFFRCxpQ0FBWSxHQUFaLFVBQWEsYUFBcUI7UUFDOUIsSUFBSSxVQUFVLEdBQVcsYUFBYSxDQUFDLE9BQU8sQ0FBQyxHQUFHLEVBQUUsRUFBRSxDQUFDLENBQUM7UUFDeEQsSUFBSSxXQUFXLEdBQWtCLFVBQVUsQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLENBQUM7UUFDdkQsSUFBSSxRQUFRLEdBQVEsRUFBRSxDQUFDO1FBQ3ZCLElBQUksV0FBVyxDQUFDLE1BQU0sS0FBSyxDQUFDLEVBQUU7WUFDMUIsUUFBUSxHQUFHO2dCQUNQLElBQUksRUFBRSxXQUFXLENBQUMsQ0FBQyxDQUFDO2dCQUNwQixJQUFJLEVBQUUsV0FBVyxDQUFDLENBQUMsQ0FBQzthQUN2QixDQUFDO1NBQ0w7UUFDRCxPQUFPLFFBQVEsQ0FBQztJQUNwQixDQUFDO0lBNVdRLFVBQVU7UUFEdEIsVUFBVSxFQUFFO09BQ0EsVUFBVSxDQThXdEI7SUFBRCxpQkFBQztDQUFBLEFBOVdELElBOFdDO1NBOVdZLFVBQVUiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBJbmplY3RhYmxlLCBSZW5kZXJlcjIgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcclxuaW1wb3J0IHsgS2REb21FbGVtU3ZjIH0gZnJvbSAnLi4va2QtY29tbW9uL2luZGV4JztcclxuaW1wb3J0IHtcclxuICAgIElMb2dpbkNvbmZpZyxcclxuICAgIElMYW5ndWFnZU9wdGlvbnNDb25maWcsXHJcbiAgICBJRm9ybUxpbmtDb25maWcsXHJcbiAgICBJRm9ybUFsZXJ0Q29uZmlnLFxyXG4gICAgSUxhbmd1YWdlQ29uZmlnXHJcbn0gZnJvbSAnLi9rZC1hbmd1bGFyLWxvZ2luLWludGVyZmFjZSc7XHJcblxyXG5cclxuZGVjbGFyZSBsZXQgQVBQX0NPTkZJR1M6IGFueTtcclxuXHJcbkBJbmplY3RhYmxlKClcclxuZXhwb3J0IGNsYXNzIEtkTG9naW5TdmMge1xyXG4gICAgcHJpdmF0ZSBfZG9tU3ZjOiBLZERvbUVsZW1TdmM7XHJcbiAgICBwcml2YXRlIF9yZW5kZXJlcjogUmVuZGVyZXIyO1xyXG5cclxuICAgIHB1YmxpYyBnZXRIZWFkZXJDb25maWdWYWx1ZXMoX2NvbmZpZzogYW55LCBfZGVmYXVsdENvbmZpZzogYW55KTogYW55IHtcclxuICAgICAgICBsZXQgdXBkYXRlSGVhZGVyQ29uZmlnOiBhbnkgPSB7fTtcclxuICAgICAgICBpZiAodHlwZW9mIF9jb25maWcgPT09ICd1bmRlZmluZWQnIHx8IHR5cGVvZiBfY29uZmlnLmhlYWRlciA9PT0gJ3VuZGVmaW5lZCcpIHtcclxuICAgICAgICAgICAgaWYgKHR5cGVvZiBfZGVmYXVsdENvbmZpZyAhPT0gJ3VuZGVmaW5lZCcpIHVwZGF0ZUhlYWRlckNvbmZpZyA9IEpTT04ucGFyc2UoSlNPTi5zdHJpbmdpZnkoX2RlZmF1bHRDb25maWcpKTtcclxuICAgICAgICAgICAgZWxzZSB1cGRhdGVIZWFkZXJDb25maWcgPSB7IGljb246ICdrZC1vcGVuZW1pcycsIHRpdGxlOiAnT3BlbkVNSVMnIH07XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICB1cGRhdGVIZWFkZXJDb25maWcgPSBfY29uZmlnLmhlYWRlcjtcclxuICAgICAgICAgICAgaWYgKHR5cGVvZiB1cGRhdGVIZWFkZXJDb25maWcuaW1nICE9PSAndW5kZWZpbmVkJyAmJiB0eXBlb2YgdXBkYXRlSGVhZGVyQ29uZmlnLmljb24gIT09ICd1bmRlZmluZWQnKSB1cGRhdGVIZWFkZXJDb25maWcuaW1nID0gJyc7XHJcbiAgICAgICAgICAgIGlmICh0eXBlb2YgdXBkYXRlSGVhZGVyQ29uZmlnLmltZyA9PT0gJ3VuZGVmaW5lZCcgJiYgdHlwZW9mIHVwZGF0ZUhlYWRlckNvbmZpZy5pY29uID09PSAndW5kZWZpbmVkJykgdXBkYXRlSGVhZGVyQ29uZmlnLmljb24gPSAnJztcclxuICAgICAgICAgICAgaWYgKHR5cGVvZiB1cGRhdGVIZWFkZXJDb25maWcuaWNvbiAhPT0gJ3VuZGVmaW5lZCcgJiYgdHlwZW9mIHVwZGF0ZUhlYWRlckNvbmZpZy50aXRsZSA9PT0gJ3VuZGVmaW5lZCcpIHVwZGF0ZUhlYWRlckNvbmZpZy50aXRsZSA9ICcnO1xyXG4gICAgICAgICAgICBpZiAodHlwZW9mIHVwZGF0ZUhlYWRlckNvbmZpZy5pbWcgIT09ICd1bmRlZmluZWQnICYmIHR5cGVvZiB1cGRhdGVIZWFkZXJDb25maWcuaW1nU2l6ZSA9PT0gJ3VuZGVmaW5lZCcpIHVwZGF0ZUhlYWRlckNvbmZpZy5pbWdTaXplID0gJ25vbmUnO1xyXG4gICAgICAgICAgICBpZiAodHlwZW9mIHVwZGF0ZUhlYWRlckNvbmZpZy5oZWFkZXJNc2cgIT09ICd1bmRlZmluZWQnICYmIHR5cGVvZiB1cGRhdGVIZWFkZXJDb25maWcuaGVhZGVyTXNnID09PSAndW5kZWZpbmVkJykgdXBkYXRlSGVhZGVyQ29uZmlnLmhlYWRlck1zZyA9ICcnO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgcmV0dXJuIHRoaXMuX3NldFByb2R1Y3RBcHBDb25maWcodXBkYXRlSGVhZGVyQ29uZmlnKTtcclxuICAgIH1cclxuXHJcbiAgICAvKlxyXG4gICAgICAgIHNldCBkZWZhdWx0IGxhbmd1YWdlIGNvbmZpZ1xyXG4gICAgICAgICAgICAtIGlmIGNvbmZpZyBpcyB1bmRlZmluZWQsIGxhbmd1bmFnZSB1bmRlZmluZWQsIHNob3cgdW5kZWZpbmVkIC0gcmV0dXJuIGRlZmF1bHRcclxuICAgICAgICAgICAgICAgIC0gaWYgY29uZmlnIGxpc3QgaXMgZGVmaW5lZCwgbGlzdCBnb3QgaXRlbSwgYW5kIHNob3cgaXMgdHJ1ZSAtIHNldCBjb25maWcgdG8gc2hvdyB3aXRoIHRvZ2dsZVxyXG4gICAgICAgICAgICAgICAgLSBlbHNlIGlmIGNvbmZpZyBkZWZhdWx0IGlzIGRlZmluZWQgLSBzZXQgY29uZmlnIHdpdGggZGVmYXVsdCBsYW5ndWFnZSBhbmQgdG9nZ2xlIGZhbHNlXHJcbiAgICAgICAgLSByZXR1cm4gY29uZmlnXHJcbiAgICAgKi9cclxuICAgIHB1YmxpYyBnZXRMYW5ndWFnZUNvbmZpZ1ZhbHVlcyhfY29uZmlnOiBJTG9naW5Db25maWcpOiBBcnJheTxJTGFuZ3VhZ2VPcHRpb25zQ29uZmlnPiB7XHJcbiAgICAgICAgaWYgKF9jb25maWcuaGFzT3duUHJvcGVydHkoJ2xhbmd1YWdlJykgJiYgX2NvbmZpZy5sYW5ndWFnZS5oYXNPd25Qcm9wZXJ0eSgnb3B0aW9ucycpKSB7XHJcbiAgICAgICAgICAgIHJldHVybiBfY29uZmlnLmxhbmd1YWdlLm9wdGlvbnM7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICByZXR1cm4gdGhpcy5nZXRTaXhEZWZhdWx0TGFuZ3VhZ2UoKTtcclxuICAgIH1cclxuXHJcbiAgICBwdWJsaWMgZ2V0TGFuZ2FnZURlZmF1bHRWYWx1ZShfY29uZmlnOiBJTG9naW5Db25maWcpOiBzdHJpbmcge1xyXG4gICAgICAgIGxldCByZXR1cm5WYWw6IHN0cmluZyA9ICdlbic7XHJcbiAgICAgICAgaWYgKF9jb25maWcuaGFzT3duUHJvcGVydHkoJ2xhbmd1YWdlJykgJiYgX2NvbmZpZy5sYW5ndWFnZS5oYXNPd25Qcm9wZXJ0eSgndmFsdWUnKSkge1xyXG4gICAgICAgICAgICByZXR1cm4gX2NvbmZpZy5sYW5ndWFnZS52YWx1ZTtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIHJldHVybiByZXR1cm5WYWw7XHJcbiAgICB9XHJcblxyXG4gICAgcHVibGljIGdldFNpeERlZmF1bHRMYW5ndWFnZSgpOiBBcnJheTxhbnk+IHtcclxuICAgICAgICBsZXQgZGVmYXVsdExpc3Q6IEFycmF5PGFueT4gPSBbXHJcbiAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICAgIHZhbHVlOiAn2KfZhNi52LHYqNmK2KknLCBrZXk6ICdhcicsIGRpcjogJ3J0bCdcclxuICAgICAgICAgICAgfSwge1xyXG4gICAgICAgICAgICAgICAgdmFsdWU6ICfkuK3mlocnLCBrZXk6ICd6aCcsIGRpcjogJ2x0cidcclxuICAgICAgICAgICAgfSwge1xyXG4gICAgICAgICAgICAgICAgdmFsdWU6ICdFbmdsaXNoJywga2V5OiAnZW4nLCBkaXI6ICdsdHInXHJcbiAgICAgICAgICAgIH0sIHtcclxuICAgICAgICAgICAgICAgIHZhbHVlOiAnRnJhbsOnYWlzJywga2V5OiAnZnInLCBkaXI6ICdsdHInXHJcbiAgICAgICAgICAgIH0sIHtcclxuICAgICAgICAgICAgICAgIHZhbHVlOiAn0YDRg9GB0YHQutC40LknLCBrZXk6ICdydScsIGRpcjogJ2x0cidcclxuICAgICAgICAgICAgfSwge1xyXG4gICAgICAgICAgICAgICAgdmFsdWU6ICdlc3Bhw7FvbCcsIGtleTogJ2VzJywgZGlyOiAnbHRyJ1xyXG4gICAgICAgICAgICB9Ly8sXHJcbiAgICAgICAgICAgIC8vIHZhbHVlOiAnZW4nXHJcbiAgICAgICAgXTtcclxuXHJcbiAgICAgICAgcmV0dXJuIGRlZmF1bHRMaXN0O1xyXG4gICAgfVxyXG5cclxuICAgIHB1YmxpYyB1cGRhdGVMYW5ndWFnZURpcihfY29uZmlnOiBJTG9naW5Db25maWcsIF9zZWxlY3RlZEluZGV4OiBzdHJpbmcpOiBzdHJpbmcge1xyXG4gICAgICAgIC8vIGNvbnNvbGUubG9nKCdQYXJlbnQgc3ZjIHJ1bjogJyArIF9zZWxlY3RlZEluZGV4KTtcclxuICAgICAgICBsZXQgbGFuZ09wdGlvbnMgPSB0aGlzLmdldExhbmd1YWdlQ29uZmlnVmFsdWVzKF9jb25maWcpO1xyXG4gICAgICAgIGxldCBkaXIgPSB0aGlzLmNoZWNrTGFuZ3VhZ2VEaXIobGFuZ09wdGlvbnMsIF9zZWxlY3RlZEluZGV4KTtcclxuICAgICAgICAvLyBjb25zb2xlLmxvZygnUmV0dXJuIHRoaXM6ICcgKyBkaXIpO1xyXG4gICAgICAgIHJldHVybiBkaXI7XHJcblxyXG5cclxuICAgIH1cclxuXHJcbiAgICBwdWJsaWMgY2hlY2tMYW5ndWFnZURpcihfbGFuZ09wdGlvbnM6IGFueSwgX3NlbGVjdGVkSW5kZXg6IHN0cmluZyk6IHN0cmluZyB7XHJcbiAgICAgICAgZm9yIChsZXQgaTogbnVtYmVyID0gMDsgaSA8IF9sYW5nT3B0aW9ucy5sZW5ndGg7IGkrKykge1xyXG4gICAgICAgICAgICBpZiAoX2xhbmdPcHRpb25zW2ldLmtleSA9PT0gX3NlbGVjdGVkSW5kZXgpIHtcclxuICAgICAgICAgICAgICAgIC8vIGNvbnNvbGUubG9nKCdEZXRlY3RlZCB0aGlzOiAnICsgX2xhbmdPcHRpb25zW2ldLmRpcik7XHJcbiAgICAgICAgICAgICAgICByZXR1cm4gX2xhbmdPcHRpb25zW2ldLmRpcjtcclxuXHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgcHVibGljIGdldEZvcm1JbnB1dHMoX3R5cGU6IHN0cmluZywgX2NvbmZpZz86IGFueSk6IEFycmF5PGFueT4ge1xyXG4gICAgICAgIGxldCBmb3JtSW5wdXRzOiBBcnJheTxhbnk+ID0gW107XHJcbiAgICAgICAgc3dpdGNoIChfdHlwZSkge1xyXG4gICAgICAgICAgICBjYXNlIFwicmVzZXQtcGFzc3dvcmRcIjpcclxuICAgICAgICAgICAgICAgIGZvcm1JbnB1dHMgPSBbXHJcbiAgICAgICAgICAgICAgICAgICAge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAna2V5JzogJ25ld3Bhc3N3b3JkJyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgJ2xhYmVsJzogJ0NvbmZpcm0gUGFzc3dvcmQnLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAnY2xhc3MnOiAnaW5wdXQnLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAnaWNvbkNsYXNzJzogJ2ZhIGZhLWtleSBpY29uU2l6ZVMnLCBcclxuICAgICAgICAgICAgICAgICAgICAgICAgJ2NvbnRyb2xUeXBlJzogJ3Bhc3N3b3JkJyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgJ3R5cGUnOiAncGFzc3dvcmQnLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAndmFsdWUnOiAnJ1xyXG4gICAgICAgICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICAgICAgICAge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAna2V5JzogJ2NvbmZpcm1wYXNzd29yZCcsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICdsYWJlbCc6ICdOZXcgUGFzc3dvcmQnLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAnY2xhc3MnOiAnaW5wdXQnLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAnaWNvbkNsYXNzJzogJ2ZhIGZhLWtleSBpY29uU2l6ZVMnLCBcclxuICAgICAgICAgICAgICAgICAgICAgICAgJ2NvbnRyb2xUeXBlJzogJ3Bhc3N3b3JkJyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgJ3R5cGUnOiAncGFzc3dvcmQnLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAndmFsdWUnOiAnJ1xyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIF1cclxuICAgICAgICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgICAgICBjYXNlIFwiZm9yZ2V0LXVzZXJuYW1lXCI6XHJcbiAgICAgICAgICAgICAgICBmb3JtSW5wdXRzID0gW1xyXG4gICAgICAgICAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgJ2tleSc6ICd1c2VyZW1haWwnLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAnbGFiZWwnOiAnRW1haWwnLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAnY2xhc3MnOiAnaW5wdXQnLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAnaWNvbkNsYXNzJzogJ2ZhIGZhLWVudmVsb3BlLW8gaWNvblNpemVTJywgXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICdjb250cm9sVHlwZSc6ICd0ZXh0Ym94JyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgJ3ZhbHVlJzogJydcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICBdXHJcbiAgICAgICAgICAgICAgICBicmVhaztcclxuICAgICAgICAgICAgY2FzZSBcImZvcmdldC1wYXNzd29yZFwiOlxyXG4gICAgICAgICAgICAgICAgZm9ybUlucHV0cyA9IFtcclxuICAgICAgICAgICAgICAgICAgICB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICdrZXknOiAndXNlcmlucHV0JyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgJ2xhYmVsJzogJ1VzZXIgTmFtZSBvciBFbWFpbCcsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICdjbGFzcyc6ICdpbnB1dCcsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICdpY29uQ2xhc3MnOiAnZmEgZmEtdXNlcicsIFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAnY29udHJvbFR5cGUnOiAndGV4dGJveCcsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICd2YWx1ZSc6ICcnXHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIC8vIHtcclxuICAgICAgICAgICAgICAgICAgICAvLyAgICAgJ2tleSc6ICd1c2VyZW1haWwnLFxyXG4gICAgICAgICAgICAgICAgICAgIC8vICAgICAnbGFiZWwnOiAnRW1haWwnLFxyXG4gICAgICAgICAgICAgICAgICAgIC8vICAgICAnY2xhc3MnOiAnaW5wdXQgZW1haWwnLFxyXG4gICAgICAgICAgICAgICAgICAgIC8vICAgICAnY29udHJvbFR5cGUnOiAndGV4dGJveCcsXHJcbiAgICAgICAgICAgICAgICAgICAgLy8gICAgICd2YWx1ZSc6ICcnXHJcbiAgICAgICAgICAgICAgICAgICAgLy8gfVxyXG4gICAgICAgICAgICAgICAgXVxyXG4gICAgICAgICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgICAgIGRlZmF1bHQ6XHJcbiAgICAgICAgICAgICAgICBmb3JtSW5wdXRzID0gW1xyXG4gICAgICAgICAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgJ2tleSc6ICd1c2VybmFtZScsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICdsYWJlbCc6ICdVc2VyIE5hbWUnLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAnY2xhc3MnOiAnaW5wdXQnLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAnaWNvbkNsYXNzJzogJ2ZhIGZhLXVzZXInLCBcclxuICAgICAgICAgICAgICAgICAgICAgICAgJ2NvbnRyb2xUeXBlJzogJ3RleHQnLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAndmFsdWUnOiAnJ1xyXG4gICAgICAgICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICAgICAgICAge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAna2V5JzogJ3Bhc3N3b3JkJyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgJ2xhYmVsJzogJ1Bhc3N3b3JkJyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgJ2NsYXNzJzogJ2lucHV0JyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgJ2ljb25DbGFzcyc6ICdmYSBmYS1rZXkgaWNvblNpemVTJywgXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICdjb250cm9sVHlwZSc6ICd0ZXh0JyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgJ3R5cGUnOiAncGFzc3dvcmQnLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAndmFsdWUnOiAnJ1xyXG4gICAgICAgICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICAgICAgICAge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAna2V5JzogJ2xhbmd1YWdlJyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgJ2NsYXNzJzogJ2tkeC1pbnB1dC1zZWxlY3Qtd3JhcHBlcicsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICdpY29uQ2xhc3MnOiAnZmEgZmEtZ2xvYmUnLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAndmFsdWUnOiBfY29uZmlnLnZhbHVlLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAnb3B0aW9ucyc6IF9jb25maWcub3B0aW9ucyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgJ2NvbnRyb2xUeXBlJzogJ2Ryb3Bkb3duJ1xyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIF1cclxuICAgICAgICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgcmV0dXJuIGZvcm1JbnB1dHM7XHJcbiAgICB9XHJcblxyXG4gICAgcHVibGljIGdldEJ1dHRvbkxhYmVsKF90eXBlOiBzdHJpbmcsIF9sYWJlbD86IHN0cmluZyk6IHN0cmluZyB7XHJcbiAgICAgICAgbGV0IHRlbXBMYWJlbDogc3RyaW5nID0gXCJTdWJtaXRcIjtcclxuXHJcbiAgICAgICAgc3dpdGNoIChfdHlwZSkge1xyXG5cclxuICAgICAgICAgICAgY2FzZSBcInJlc2V0LXBhc3N3b3JkXCI6XHJcbiAgICAgICAgICAgICAgICBpZiAodHlwZW9mIF9sYWJlbCAhPT0gJ3VuZGVmaW5lZCcpIHRlbXBMYWJlbCA9IF9sYWJlbDtcclxuICAgICAgICAgICAgICAgIGVsc2UgdGVtcExhYmVsID0gJ1VwZGF0ZSBQYXNzd29yZCdcclxuICAgICAgICAgICAgICAgIGJyZWFrO1xyXG5cclxuICAgICAgICAgICAgY2FzZSBcImZvcmdldC11c2VybmFtZVwiOlxyXG4gICAgICAgICAgICAgICAgaWYgKHR5cGVvZiBfbGFiZWwgIT09ICd1bmRlZmluZWQnKSB0ZW1wTGFiZWwgPSBfbGFiZWw7XHJcbiAgICAgICAgICAgICAgICBlbHNlIHRlbXBMYWJlbCA9ICdSZWNvdmVyIFVzZXJuYW1lJ1xyXG4gICAgICAgICAgICAgICAgYnJlYWs7XHJcblxyXG4gICAgICAgICAgICBjYXNlIFwiZm9yZ2V0LXBhc3N3b3JkXCI6XHJcbiAgICAgICAgICAgICAgICBpZiAodHlwZW9mIF9sYWJlbCAhPT0gJ3VuZGVmaW5lZCcpIHRlbXBMYWJlbCA9IF9sYWJlbDtcclxuICAgICAgICAgICAgICAgIGVsc2UgdGVtcExhYmVsID0gJ1Jlc2V0IFBhc3N3b3JkJ1xyXG4gICAgICAgICAgICAgICAgYnJlYWs7XHJcblxyXG4gICAgICAgICAgICBkZWZhdWx0OlxyXG4gICAgICAgICAgICAgICAgaWYgKHR5cGVvZiBfbGFiZWwgIT09ICd1bmRlZmluZWQnKSB0ZW1wTGFiZWwgPSBfbGFiZWw7XHJcbiAgICAgICAgICAgICAgICBlbHNlIHRlbXBMYWJlbCA9ICdMb2dpbidcclxuICAgICAgICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgcmV0dXJuIHRlbXBMYWJlbDtcclxuICAgIH1cclxuXHJcbiAgICBwdWJsaWMgZ2V0Rm9ybUxpbmtzKF9jb25maWc6IElMb2dpbkNvbmZpZywgX3R5cGU6IHN0cmluZyk6IEFycmF5PElGb3JtTGlua0NvbmZpZz4ge1xyXG4gICAgICAgIGxldCByZXR1cm5EYXRhOiBBcnJheTxJRm9ybUxpbmtDb25maWc+ID0gW11cclxuXHJcbiAgICAgICAgbGV0IGRlZmF1bHRMaW5rOiBhbnkgPSB0aGlzLmdldERlZmF1bHRGb3JtTGlua3MoX3R5cGUpO1xyXG5cclxuICAgICAgICBzd2l0Y2ggKF90eXBlKSB7XHJcblxyXG4gICAgICAgICAgICBjYXNlIFwicmVzZXQtcGFzc3dvcmRcIjpcclxuICAgICAgICAgICAgICAgIHJldHVybkRhdGEucHVzaChPYmplY3QuYXNzaWduKGRlZmF1bHRMaW5rLmJhY2ssIF9jb25maWcuZm9ybUxpbmtzLmJhY2spKVxyXG4gICAgICAgICAgICAgICAgYnJlYWs7XHJcblxyXG4gICAgICAgICAgICBjYXNlIFwiZm9yZ2V0LXVzZXJuYW1lXCI6XHJcbiAgICAgICAgICAgICAgICByZXR1cm5EYXRhLnB1c2goT2JqZWN0LmFzc2lnbihkZWZhdWx0TGluay5iYWNrLCBfY29uZmlnLmZvcm1MaW5rcy5iYWNrKSlcclxuICAgICAgICAgICAgICAgIGJyZWFrO1xyXG5cclxuICAgICAgICAgICAgY2FzZSBcImZvcmdldC1wYXNzd29yZFwiOlxyXG4gICAgICAgICAgICAgICAgcmV0dXJuRGF0YS5wdXNoKE9iamVjdC5hc3NpZ24oZGVmYXVsdExpbmsuYmFjaywgX2NvbmZpZy5mb3JtTGlua3MuYmFjaykpXHJcbiAgICAgICAgICAgICAgICBicmVhaztcclxuXHJcbiAgICAgICAgICAgIGRlZmF1bHQ6XHJcbiAgICAgICAgICAgICAgICBpZihfY29uZmlnLmZvcm1MaW5rcyAmJiBfY29uZmlnLmZvcm1MaW5rcy5mb3JnZXRQYXNzd29yZClcclxuICAgICAgICAgICAgICAgIHJldHVybkRhdGEucHVzaChPYmplY3QuYXNzaWduKGRlZmF1bHRMaW5rLmZvcmdldFBhc3N3b3JkLCBfY29uZmlnLmZvcm1MaW5rcy5mb3JnZXRQYXNzd29yZCkpXHJcbiAgICAgICAgICAgICAgICBpZihfY29uZmlnLmZvcm1MaW5rcyAmJiBfY29uZmlnLmZvcm1MaW5rcy5mb3JnZXRVc2VyKVxyXG4gICAgICAgICAgICAgICAgcmV0dXJuRGF0YS5wdXNoKE9iamVjdC5hc3NpZ24oZGVmYXVsdExpbmsuZm9yZ2V0VXNlciwgX2NvbmZpZy5mb3JtTGlua3MuZm9yZ2V0VXNlcikpXHJcbiAgICAgICAgICAgICAgICBicmVhaztcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIHJldHVybiByZXR1cm5EYXRhO1xyXG5cclxuICAgICAgICAvLyBpZiAoX2NvbmZpZy5oYXNPd25Qcm9wZXJ0eSgnZm9ybUxpbmtzJykgJiYgX2NvbmZpZy5mb3JtTGlua3MuaGFzT3duUHJvcGVydHkoX2xpbmtUeXBlKSAmJiBfY29uZmlnLmZvcm1MaW5rc1tfbGlua1R5cGVdLmhhc093blByb3BlcnR5KCdwYXRoJykpIHtcclxuICAgICAgICAvLyAgICAgLy9yZXR1cm4gX2NvbmZpZy5mb3JtTGlua3MuZm9yZ2V0UGFzc3dvcmQucGF0aDtcclxuICAgICAgICAvLyAgICAgbGV0IGZvcmdldFBhc3N3b3JkOiBhbnkgPSB7XHJcbiAgICAgICAgLy8gICAgICAgICBwYXRoOiBfY29uZmlnLmZvcm1MaW5rcy5mb3JnZXRQYXNzd29yZC5wYXRoXHJcbiAgICAgICAgLy8gICAgIH1cclxuXHJcbiAgICAgICAgLy8gcmV0dXJuIGZvcmdldFBhc3N3b3JkO1xyXG4gICAgICAgIC8vIH1cclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIGdldERlZmF1bHRGb3JtTGlua3MoX3R5cGU6IHN0cmluZyk6IGFueSB7XHJcbiAgICAgICAgbGV0IHJldHVybkRhdGE6IGFueSA9IHt9O1xyXG5cclxuICAgICAgICBzd2l0Y2ggKF90eXBlKSB7XHJcblxyXG4gICAgICAgICAgICBjYXNlIFwicmVzZXQtcGFzc3dvcmRcIjpcclxuICAgICAgICAgICAgICAgIHJldHVybkRhdGEgPSB7XHJcbiAgICAgICAgICAgICAgICAgICAgYmFjazoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBsYWJlbDogJ0JhY2sgdG8gbG9naW4/J1xyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIGJyZWFrO1xyXG5cclxuICAgICAgICAgICAgY2FzZSBcImZvcmdldC11c2VybmFtZVwiOlxyXG4gICAgICAgICAgICAgICAgcmV0dXJuRGF0YSA9IHtcclxuICAgICAgICAgICAgICAgICAgICBiYWNrOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGxhYmVsOiAnQmFjayB0byBsb2dpbj8nXHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgYnJlYWs7XHJcblxyXG4gICAgICAgICAgICBjYXNlIFwiZm9yZ2V0LXBhc3N3b3JkXCI6XHJcbiAgICAgICAgICAgICAgICByZXR1cm5EYXRhID0ge1xyXG4gICAgICAgICAgICAgICAgICAgIGJhY2s6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgbGFiZWw6ICdCYWNrIHRvIGxvZ2luPydcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICBicmVhaztcclxuXHJcbiAgICAgICAgICAgIGRlZmF1bHQ6XHJcbiAgICAgICAgICAgICAgICByZXR1cm5EYXRhID0ge1xyXG4gICAgICAgICAgICAgICAgICAgIGZvcmdldFBhc3N3b3JkOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGxhYmVsOiAnRm9yZ2V0IFBhc3N3b3JkPydcclxuICAgICAgICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgICAgICAgIGZvcmdldFVzZXI6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgbGFiZWw6ICdGb3JnZXQgVXNlcm5hbWU/J1xyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgIH1cclxuICAgICAgICByZXR1cm4gcmV0dXJuRGF0YTtcclxuICAgIH1cclxuXHJcbiAgICAvLyBwdWJsaWMgZ2V0Rm9ybUFsZXJ0cyhfY29uZmlnOiBJTG9naW5Db25maWcsIF90eXBlOiBzdHJpbmcpOiBJRm9ybUFsZXJ0Q29uZmlnIHwgYm9vbGVhbiB7XHJcbiAgICAvLyAgICAgaWYgKF9jb25maWcuaGFzT3duUHJvcGVydHkoJ2FsZXJ0JykgJiYgX2NvbmZpZy5hbGVydC5oYXNPd25Qcm9wZXJ0eSgnZXJyb3JNc2cnKSkge1xyXG4gICAgLy8gICAgICAgICBsZXQgcmV0dXJuRGF0YTogSUZvcm1BbGVydENvbmZpZyA9IEpTT04ucGFyc2UoSlNPTi5zdHJpbmdpZnkoX2NvbmZpZy5hbGVydCkpO1xyXG5cclxuICAgIC8vICAgICAgICAgaWYgKCFfY29uZmlnLmFsZXJ0Lmhhc093blByb3BlcnR5KCdzdWNjZXNzTXNnJykgJiYgX3R5cGUgIT09ICdsb2dpbicpIHtcclxuICAgIC8vICAgICAgICAgICAgIHJldHVybkRhdGFbJ3N1Y2Nlc3NNc2cnXSA9ICdBbiBlbWFpbCB3aWxsIGJlIHNlbmQgc2hvcnRseS4gUGxlYXNlIGNoZWNrIHlvdXIgbWFpbGJveC4nO1xyXG4gICAgLy8gICAgICAgICB9XHJcbiAgICAvLyAgICAgICAgIHJldHVybiByZXR1cm5EYXRhO1xyXG4gICAgLy8gICAgIH1cclxuICAgIC8vICAgICByZXR1cm4gZmFsc2U7XHJcbiAgICAvLyB9XHJcblxyXG4gICAgLy8gcHVibGljIHNldEFsZXJ0TWVzc2FnZShfdmFsdWU6IHN0cmluZywgX2Zvcm1BbGVydHM6IGFueSk6IHN0cmluZyB7XHJcbiAgICAvLyAgICAgbGV0IHJldHVyblZhbDogc3RyaW5nO1xyXG5cclxuICAgIC8vICAgICBpZiAoX3ZhbHVlID09PSAnc3VjY2VzcycpIHtcclxuICAgIC8vICAgICAgICAgcmV0dXJuVmFsID0gX2Zvcm1BbGVydHMuc3VjY2Vzc01zZztcclxuICAgIC8vICAgICB9IGVsc2UgaWYgKF92YWx1ZSA9PT0gJ2RhbmdlcicpIHtcclxuICAgIC8vICAgICAgICAgcmV0dXJuVmFsID0gX2Zvcm1BbGVydHMuZXJyb3JNc2c7XHJcbiAgICAvLyAgICAgfVxyXG5cclxuICAgIC8vICAgICByZXR1cm4gcmV0dXJuVmFsO1xyXG4gICAgLy8gfVxyXG5cclxuXHJcblxyXG5cclxuICAgIHByaXZhdGUgX3NldFByb2R1Y3RBcHBDb25maWcoX3VwZGF0ZUhlYWRlckNvbmZpZzogYW55KTogYW55IHtcclxuICAgICAgICAvLyBsZXQgdGVtcEhlYWRlckNvbmZpZzphbnkgPSBfdXBkYXRlSGVhZGVyQ29uZmlnO1xyXG4gICAgICAgIHRyeSB7XHJcbiAgICAgICAgICAgIGlmIChBUFBfQ09ORklHUy5oYXNPd25Qcm9wZXJ0eSgncHJvZHVjdCcpKSB7XHJcbiAgICAgICAgICAgICAgICBsZXQgdHlwZTogc3RyaW5nID0gKEFQUF9DT05GSUdTLnByb2R1Y3QuaGFzT3duUHJvcGVydHkoJ3R5cGUnKSkgPyBBUFBfQ09ORklHUy5wcm9kdWN0LnR5cGUgOiAnaWNvbic7XHJcblxyXG4gICAgICAgICAgICAgICAgaWYgKEFQUF9DT05GSUdTLnByb2R1Y3QuaGFzT3duUHJvcGVydHkoJ25hbWUnKSkge1xyXG4gICAgICAgICAgICAgICAgICAgIF91cGRhdGVIZWFkZXJDb25maWcudGl0bGUgPSBBUFBfQ09ORklHUy5wcm9kdWN0Lm5hbWU7XHJcbiAgICAgICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICAgICAgaWYgKEFQUF9DT05GSUdTLnByb2R1Y3QuaGFzT3duUHJvcGVydHkoJ3NyYycpKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgc3dpdGNoICh0eXBlKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNhc2UgJ2ljb24nOlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgX3VwZGF0ZUhlYWRlckNvbmZpZy5pY29uID0gQVBQX0NPTkZJR1MucHJvZHVjdC5zcmM7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBicmVhaztcclxuICAgICAgICAgICAgICAgICAgICAgICAgY2FzZSAnaW1hZ2UnOlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgX3VwZGF0ZUhlYWRlckNvbmZpZy5pbWcgPSBBUFBfQ09ORklHUy5wcm9kdWN0LnNyYztcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBkZWZhdWx0OlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfSBjYXRjaCAoZXJyKSB7XHJcbiAgICAgICAgICAgIC8vIGNvbnNvbGUubG9nKGVycik7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICByZXR1cm4gX3VwZGF0ZUhlYWRlckNvbmZpZztcclxuICAgIH1cclxuXHJcblxyXG5cclxuICAgIGdldExvZ29TaXplQ2xhc3MoaGVhZGVyQ29uZmlnOiBhbnkpOiBzdHJpbmcge1xyXG4gICAgICAgIGlmICh0eXBlb2YgaGVhZGVyQ29uZmlnLmltZ1NpemUgIT09ICd1bmRlZmluZWQnKSByZXR1cm4gaGVhZGVyQ29uZmlnLmltZ1NpemU7XHJcbiAgICAgICAgaWYgKHR5cGVvZiBoZWFkZXJDb25maWcuaW1nICE9PSAndW5kZWZpbmVkJyAmJiB0eXBlb2YgaGVhZGVyQ29uZmlnLnRpdGxlID09PSAndW5kZWZpbmVkJykgcmV0dXJuICdmdWxsJztcclxuICAgICAgICByZXR1cm4gJ3NtYWxsJztcclxuICAgIH1cclxuXHJcbiAgICBnZXREZW1vTG9naW4ocmVxdWVzdFN0cmluZzogc3RyaW5nKTogYW55IHtcclxuICAgICAgICBsZXQgdGVtcFN0cmluZzogc3RyaW5nID0gcmVxdWVzdFN0cmluZy5yZXBsYWNlKCcgJywgJycpO1xyXG4gICAgICAgIGxldCBzcGxpdFN0cmluZzogQXJyYXk8c3RyaW5nPiA9IHRlbXBTdHJpbmcuc3BsaXQoJywnKTtcclxuICAgICAgICBsZXQgZGVtb0luZm86IGFueSA9IHt9O1xyXG4gICAgICAgIGlmIChzcGxpdFN0cmluZy5sZW5ndGggPT09IDIpIHtcclxuICAgICAgICAgICAgZGVtb0luZm8gPSB7XHJcbiAgICAgICAgICAgICAgICB1c2VyOiBzcGxpdFN0cmluZ1swXSxcclxuICAgICAgICAgICAgICAgIHBhc3M6IHNwbGl0U3RyaW5nWzFdXHJcbiAgICAgICAgICAgIH07XHJcbiAgICAgICAgfVxyXG4gICAgICAgIHJldHVybiBkZW1vSW5mbztcclxuICAgIH1cclxuXHJcbn1cclxuIl19