import { __decorate } from "tslib";
import { Injectable } from '@angular/core';
var KdHeaderSvc = /** @class */ (function () {
    function KdHeaderSvc() {
    }
    KdHeaderSvc.prototype.getDefaultConfig = function () {
        return {
            brandLogo: {
                //  prefix: 'OpenEMIS',
                name: 'OpenEMIS Styleguide',
                type: 'icon',
                src: 'kd-openemis'
            },
            userInfo: {
                showUser: true,
                name: '',
                imgType: 'icon',
                imgSrc: 'kd-role',
                role: ''
            },
            btnGroup: [{
                    btnIcon: 'fa fa-home fa-lg',
                    dropdownType: 'default'
                }, {
                    btnIcon: 'kd-grid',
                    dropdownType: 'grid',
                    dropdownContent: [{
                            icon: 'kd-openemis kd-analyzer',
                            text: 'Analyzer',
                            theme: 'openemis-analyzer'
                        }, {
                            icon: 'kd-openemis kd-community',
                            text: 'Community',
                            theme: 'openemis-community'
                        }, {
                            icon: 'kd-openemis kd-connect',
                            text: 'Connect',
                            theme: 'openemis-connect'
                        }, {
                            icon: 'kd-openemis kd-core',
                            text: 'Core',
                            theme: 'openemis-core'
                        }, {
                            icon: 'kd-openemis kd-datamanager',
                            text: 'DataManager',
                            theme: 'openemis-datamanager'
                        }, {
                            icon: 'kd-openemis kd-dashboard',
                            text: 'Dashboard',
                            theme: 'openemis-dashboard'
                        }, {
                            icon: 'kd-openemis kd-exams',
                            text: 'Exams',
                            theme: 'openemis-exams'
                        }, {
                            icon: 'kd-openemis kd-identity',
                            text: 'Identity',
                            theme: 'openemis-identity'
                        }, {
                            icon: 'kd-openemis kd-insight',
                            text: 'Insight',
                            theme: 'openemis-insight'
                        }, {
                            icon: 'kd-openemis kd-integrator',
                            text: 'Integrator',
                            theme: 'openemis-integrator'
                        }, {
                            icon: 'kd-openemis kd-learning',
                            text: 'Learning',
                            theme: 'openemis-learning'
                        }, {
                            icon: 'kd-openemis kd-logistics',
                            text: 'Logistics',
                            theme: 'openemis-logistics'
                        }, {
                            icon: 'kd-openemis kd-modelling',
                            text: 'Modelling',
                            theme: 'openemis-modelling'
                        }, {
                            icon: 'kd-openemis kd-monitoring',
                            text: 'Monitoring',
                            theme: 'openemis-monitoring'
                        }, {
                            icon: 'kd-openemis kd-school',
                            text: 'School',
                            theme: 'openemis-school'
                        },
                        {
                            icon: 'kd-openemis kd-styleguide',
                            text: 'Styleguide',
                            theme: 'openemis-styleguide'
                        }]
                }, {
                    btnIcon: 'kd-ellipsis',
                    dropdownType: 'list',
                    dropdownContent: [{
                            icon: 'fa fa-user',
                            text: 'About'
                        }, {
                            icon: 'fa fa-cog',
                            text: 'Preferences'
                        }, {
                            icon: 'fa fa-question-circle',
                            text: 'Help'
                        }, {
                            icon: 'fa fa-power-off',
                            text: 'Logout'
                        }]
                }]
        };
    };
    KdHeaderSvc = __decorate([
        Injectable()
    ], KdHeaderSvc);
    return KdHeaderSvc;
}());
export { KdHeaderSvc };
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoia2QtYW5ndWxhci1oZWFkZXItc3ZjLmpzIiwic291cmNlUm9vdCI6Im5nOi8vb3BlbmVtaXMtc3R5bGVndWlkZS1saWIvIiwic291cmNlcyI6WyJrZC1jb21wb25lbnRzL2tkLWFuZ3VsYXItaGVhZGVyL2tkLWFuZ3VsYXItaGVhZGVyLXN2Yy50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiO0FBQUEsT0FBTyxFQUFFLFVBQVUsRUFBRSxNQUFNLGVBQWUsQ0FBQztBQVkzQztJQUFBO0lBK0dBLENBQUM7SUE3R1Usc0NBQWdCLEdBQXZCO1FBQ0ksT0FBTztZQUNILFNBQVMsRUFBRTtnQkFDUCx1QkFBdUI7Z0JBQ3ZCLElBQUksRUFBRSxxQkFBcUI7Z0JBQzNCLElBQUksRUFBRSxNQUFNO2dCQUNaLEdBQUcsRUFBRSxhQUFhO2FBQ3JCO1lBQ0QsUUFBUSxFQUFFO2dCQUNOLFFBQVEsRUFBRSxJQUFJO2dCQUNkLElBQUksRUFBRSxFQUFFO2dCQUNSLE9BQU8sRUFBRSxNQUFNO2dCQUNmLE1BQU0sRUFBRSxTQUFTO2dCQUNqQixJQUFJLEVBQUUsRUFBRTthQUNYO1lBQ0QsUUFBUSxFQUFFLENBQUM7b0JBQ1AsT0FBTyxFQUFFLGtCQUFrQjtvQkFDM0IsWUFBWSxFQUFFLFNBQVM7aUJBQzFCLEVBQUU7b0JBQ0MsT0FBTyxFQUFFLFNBQVM7b0JBQ2xCLFlBQVksRUFBRSxNQUFNO29CQUNwQixlQUFlLEVBQUUsQ0FBQzs0QkFDZCxJQUFJLEVBQUUseUJBQXlCOzRCQUMvQixJQUFJLEVBQUUsVUFBVTs0QkFDaEIsS0FBSyxFQUFFLG1CQUFtQjt5QkFDN0IsRUFBRTs0QkFDQyxJQUFJLEVBQUUsMEJBQTBCOzRCQUNoQyxJQUFJLEVBQUUsV0FBVzs0QkFDakIsS0FBSyxFQUFFLG9CQUFvQjt5QkFDOUIsRUFBRTs0QkFDQyxJQUFJLEVBQUUsd0JBQXdCOzRCQUM5QixJQUFJLEVBQUUsU0FBUzs0QkFDZixLQUFLLEVBQUUsa0JBQWtCO3lCQUM1QixFQUFFOzRCQUNDLElBQUksRUFBRSxxQkFBcUI7NEJBQzNCLElBQUksRUFBRSxNQUFNOzRCQUNaLEtBQUssRUFBRSxlQUFlO3lCQUN6QixFQUFFOzRCQUNDLElBQUksRUFBRSw0QkFBNEI7NEJBQ2xDLElBQUksRUFBRSxhQUFhOzRCQUNuQixLQUFLLEVBQUUsc0JBQXNCO3lCQUNoQyxFQUFFOzRCQUNDLElBQUksRUFBRSwwQkFBMEI7NEJBQ2hDLElBQUksRUFBRSxXQUFXOzRCQUNqQixLQUFLLEVBQUUsb0JBQW9CO3lCQUM5QixFQUFFOzRCQUNDLElBQUksRUFBRSxzQkFBc0I7NEJBQzVCLElBQUksRUFBRSxPQUFPOzRCQUNiLEtBQUssRUFBRSxnQkFBZ0I7eUJBQzFCLEVBQUU7NEJBQ0MsSUFBSSxFQUFFLHlCQUF5Qjs0QkFDL0IsSUFBSSxFQUFFLFVBQVU7NEJBQ2hCLEtBQUssRUFBRSxtQkFBbUI7eUJBQzdCLEVBQUU7NEJBQ0MsSUFBSSxFQUFFLHdCQUF3Qjs0QkFDOUIsSUFBSSxFQUFFLFNBQVM7NEJBQ2YsS0FBSyxFQUFFLGtCQUFrQjt5QkFDNUIsRUFBRTs0QkFDQyxJQUFJLEVBQUUsMkJBQTJCOzRCQUNqQyxJQUFJLEVBQUUsWUFBWTs0QkFDbEIsS0FBSyxFQUFFLHFCQUFxQjt5QkFDL0IsRUFBRTs0QkFDQyxJQUFJLEVBQUUseUJBQXlCOzRCQUMvQixJQUFJLEVBQUUsVUFBVTs0QkFDaEIsS0FBSyxFQUFFLG1CQUFtQjt5QkFDN0IsRUFBRTs0QkFDQyxJQUFJLEVBQUUsMEJBQTBCOzRCQUNoQyxJQUFJLEVBQUUsV0FBVzs0QkFDakIsS0FBSyxFQUFFLG9CQUFvQjt5QkFDOUIsRUFBRTs0QkFDQyxJQUFJLEVBQUUsMEJBQTBCOzRCQUNoQyxJQUFJLEVBQUUsV0FBVzs0QkFDakIsS0FBSyxFQUFFLG9CQUFvQjt5QkFDOUIsRUFBRTs0QkFDQyxJQUFJLEVBQUUsMkJBQTJCOzRCQUNqQyxJQUFJLEVBQUUsWUFBWTs0QkFDbEIsS0FBSyxFQUFFLHFCQUFxQjt5QkFDL0IsRUFBRTs0QkFDQyxJQUFJLEVBQUUsdUJBQXVCOzRCQUM3QixJQUFJLEVBQUUsUUFBUTs0QkFDZCxLQUFLLEVBQUUsaUJBQWlCO3lCQUMzQjt3QkFJSTs0QkFDRCxJQUFJLEVBQUUsMkJBQTJCOzRCQUNqQyxJQUFJLEVBQUUsWUFBWTs0QkFDbEIsS0FBSyxFQUFFLHFCQUFxQjt5QkFDL0IsQ0FBQztpQkFDTCxFQUFFO29CQUNDLE9BQU8sRUFBRSxhQUFhO29CQUN0QixZQUFZLEVBQUUsTUFBTTtvQkFDcEIsZUFBZSxFQUFFLENBQUM7NEJBQ2QsSUFBSSxFQUFFLFlBQVk7NEJBQ2xCLElBQUksRUFBRSxPQUFPO3lCQUNoQixFQUFFOzRCQUNDLElBQUksRUFBRSxXQUFXOzRCQUNqQixJQUFJLEVBQUUsYUFBYTt5QkFDdEIsRUFBRTs0QkFDQyxJQUFJLEVBQUUsdUJBQXVCOzRCQUM3QixJQUFJLEVBQUUsTUFBTTt5QkFDZixFQUFFOzRCQUNDLElBQUksRUFBRSxpQkFBaUI7NEJBQ3ZCLElBQUksRUFBRSxRQUFRO3lCQUNqQixDQUFDO2lCQUNMLENBQUM7U0FDTCxDQUFDO0lBQ04sQ0FBQztJQTlHUSxXQUFXO1FBRHZCLFVBQVUsRUFBRTtPQUNBLFdBQVcsQ0ErR3ZCO0lBQUQsa0JBQUM7Q0FBQSxBQS9HRCxJQStHQztTQS9HWSxXQUFXIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgSW5qZWN0YWJsZSB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xyXG5pbXBvcnQge1xyXG4gICAgLy8gSUhlYWRlckJ1dHRvbixcclxuICAgIC8vIElIZWFkZXJCcmFuZExvZ28sXHJcbiAgICAvLyBJSGVhZGVyRHJvcGRvd25JdGVtLFxyXG4gICAgLy8gSUhlYWRlclVzZXJJbmZvLFxyXG4gICAgLy8gSUhlYWRlckFQSSxcclxuICAgIElIZWFkZXJDb25maWdcclxufSBmcm9tICcuL2tkLWFuZ3VsYXItaGVhZGVyLWludGVyZmFjZSc7XHJcblxyXG5cclxuQEluamVjdGFibGUoKVxyXG5leHBvcnQgY2xhc3MgS2RIZWFkZXJTdmMge1xyXG5cclxuICAgIHB1YmxpYyBnZXREZWZhdWx0Q29uZmlnKCk6IElIZWFkZXJDb25maWcge1xyXG4gICAgICAgIHJldHVybiB7XHJcbiAgICAgICAgICAgIGJyYW5kTG9nbzoge1xyXG4gICAgICAgICAgICAgICAgLy8gIHByZWZpeDogJ09wZW5FTUlTJyxcclxuICAgICAgICAgICAgICAgIG5hbWU6ICdPcGVuRU1JUyBTdHlsZWd1aWRlJyxcclxuICAgICAgICAgICAgICAgIHR5cGU6ICdpY29uJywgLy8gaWNvbiwgaW1hZ2UsIG5vbmVcclxuICAgICAgICAgICAgICAgIHNyYzogJ2tkLW9wZW5lbWlzJ1xyXG4gICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICB1c2VySW5mbzoge1xyXG4gICAgICAgICAgICAgICAgc2hvd1VzZXI6IHRydWUsIC8vIHRydWUsIGZhbHNlXHJcbiAgICAgICAgICAgICAgICBuYW1lOiAnJyxcclxuICAgICAgICAgICAgICAgIGltZ1R5cGU6ICdpY29uJywgLy8gaWNvbiwgaW1hZ2UsIG5vbmVcclxuICAgICAgICAgICAgICAgIGltZ1NyYzogJ2tkLXJvbGUnLFxyXG4gICAgICAgICAgICAgICAgcm9sZTogJydcclxuICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgYnRuR3JvdXA6IFt7XHJcbiAgICAgICAgICAgICAgICBidG5JY29uOiAnZmEgZmEtaG9tZSBmYS1sZycsXHJcbiAgICAgICAgICAgICAgICBkcm9wZG93blR5cGU6ICdkZWZhdWx0J1xyXG4gICAgICAgICAgICB9LCB7XHJcbiAgICAgICAgICAgICAgICBidG5JY29uOiAna2QtZ3JpZCcsXHJcbiAgICAgICAgICAgICAgICBkcm9wZG93blR5cGU6ICdncmlkJyxcclxuICAgICAgICAgICAgICAgIGRyb3Bkb3duQ29udGVudDogW3tcclxuICAgICAgICAgICAgICAgICAgICBpY29uOiAna2Qtb3BlbmVtaXMga2QtYW5hbHl6ZXInLFxyXG4gICAgICAgICAgICAgICAgICAgIHRleHQ6ICdBbmFseXplcicsXHJcbiAgICAgICAgICAgICAgICAgICAgdGhlbWU6ICdvcGVuZW1pcy1hbmFseXplcidcclxuICAgICAgICAgICAgICAgIH0sIHtcclxuICAgICAgICAgICAgICAgICAgICBpY29uOiAna2Qtb3BlbmVtaXMga2QtY29tbXVuaXR5JyxcclxuICAgICAgICAgICAgICAgICAgICB0ZXh0OiAnQ29tbXVuaXR5JyxcclxuICAgICAgICAgICAgICAgICAgICB0aGVtZTogJ29wZW5lbWlzLWNvbW11bml0eSdcclxuICAgICAgICAgICAgICAgIH0sIHtcclxuICAgICAgICAgICAgICAgICAgICBpY29uOiAna2Qtb3BlbmVtaXMga2QtY29ubmVjdCcsXHJcbiAgICAgICAgICAgICAgICAgICAgdGV4dDogJ0Nvbm5lY3QnLFxyXG4gICAgICAgICAgICAgICAgICAgIHRoZW1lOiAnb3BlbmVtaXMtY29ubmVjdCdcclxuICAgICAgICAgICAgICAgIH0sIHtcclxuICAgICAgICAgICAgICAgICAgICBpY29uOiAna2Qtb3BlbmVtaXMga2QtY29yZScsXHJcbiAgICAgICAgICAgICAgICAgICAgdGV4dDogJ0NvcmUnLFxyXG4gICAgICAgICAgICAgICAgICAgIHRoZW1lOiAnb3BlbmVtaXMtY29yZSdcclxuICAgICAgICAgICAgICAgIH0sIHtcclxuICAgICAgICAgICAgICAgICAgICBpY29uOiAna2Qtb3BlbmVtaXMga2QtZGF0YW1hbmFnZXInLFxyXG4gICAgICAgICAgICAgICAgICAgIHRleHQ6ICdEYXRhTWFuYWdlcicsXHJcbiAgICAgICAgICAgICAgICAgICAgdGhlbWU6ICdvcGVuZW1pcy1kYXRhbWFuYWdlcidcclxuICAgICAgICAgICAgICAgIH0sIHtcclxuICAgICAgICAgICAgICAgICAgICBpY29uOiAna2Qtb3BlbmVtaXMga2QtZGFzaGJvYXJkJyxcclxuICAgICAgICAgICAgICAgICAgICB0ZXh0OiAnRGFzaGJvYXJkJyxcclxuICAgICAgICAgICAgICAgICAgICB0aGVtZTogJ29wZW5lbWlzLWRhc2hib2FyZCdcclxuICAgICAgICAgICAgICAgIH0sIHtcclxuICAgICAgICAgICAgICAgICAgICBpY29uOiAna2Qtb3BlbmVtaXMga2QtZXhhbXMnLFxyXG4gICAgICAgICAgICAgICAgICAgIHRleHQ6ICdFeGFtcycsXHJcbiAgICAgICAgICAgICAgICAgICAgdGhlbWU6ICdvcGVuZW1pcy1leGFtcydcclxuICAgICAgICAgICAgICAgIH0sIHtcclxuICAgICAgICAgICAgICAgICAgICBpY29uOiAna2Qtb3BlbmVtaXMga2QtaWRlbnRpdHknLFxyXG4gICAgICAgICAgICAgICAgICAgIHRleHQ6ICdJZGVudGl0eScsXHJcbiAgICAgICAgICAgICAgICAgICAgdGhlbWU6ICdvcGVuZW1pcy1pZGVudGl0eSdcclxuICAgICAgICAgICAgICAgIH0sIHtcclxuICAgICAgICAgICAgICAgICAgICBpY29uOiAna2Qtb3BlbmVtaXMga2QtaW5zaWdodCcsXHJcbiAgICAgICAgICAgICAgICAgICAgdGV4dDogJ0luc2lnaHQnLFxyXG4gICAgICAgICAgICAgICAgICAgIHRoZW1lOiAnb3BlbmVtaXMtaW5zaWdodCdcclxuICAgICAgICAgICAgICAgIH0sIHtcclxuICAgICAgICAgICAgICAgICAgICBpY29uOiAna2Qtb3BlbmVtaXMga2QtaW50ZWdyYXRvcicsXHJcbiAgICAgICAgICAgICAgICAgICAgdGV4dDogJ0ludGVncmF0b3InLFxyXG4gICAgICAgICAgICAgICAgICAgIHRoZW1lOiAnb3BlbmVtaXMtaW50ZWdyYXRvcidcclxuICAgICAgICAgICAgICAgIH0sIHtcclxuICAgICAgICAgICAgICAgICAgICBpY29uOiAna2Qtb3BlbmVtaXMga2QtbGVhcm5pbmcnLFxyXG4gICAgICAgICAgICAgICAgICAgIHRleHQ6ICdMZWFybmluZycsXHJcbiAgICAgICAgICAgICAgICAgICAgdGhlbWU6ICdvcGVuZW1pcy1sZWFybmluZydcclxuICAgICAgICAgICAgICAgIH0sIHtcclxuICAgICAgICAgICAgICAgICAgICBpY29uOiAna2Qtb3BlbmVtaXMga2QtbG9naXN0aWNzJyxcclxuICAgICAgICAgICAgICAgICAgICB0ZXh0OiAnTG9naXN0aWNzJyxcclxuICAgICAgICAgICAgICAgICAgICB0aGVtZTogJ29wZW5lbWlzLWxvZ2lzdGljcydcclxuICAgICAgICAgICAgICAgIH0sIHtcclxuICAgICAgICAgICAgICAgICAgICBpY29uOiAna2Qtb3BlbmVtaXMga2QtbW9kZWxsaW5nJyxcclxuICAgICAgICAgICAgICAgICAgICB0ZXh0OiAnTW9kZWxsaW5nJyxcclxuICAgICAgICAgICAgICAgICAgICB0aGVtZTogJ29wZW5lbWlzLW1vZGVsbGluZydcclxuICAgICAgICAgICAgICAgIH0sIHtcclxuICAgICAgICAgICAgICAgICAgICBpY29uOiAna2Qtb3BlbmVtaXMga2QtbW9uaXRvcmluZycsXHJcbiAgICAgICAgICAgICAgICAgICAgdGV4dDogJ01vbml0b3JpbmcnLFxyXG4gICAgICAgICAgICAgICAgICAgIHRoZW1lOiAnb3BlbmVtaXMtbW9uaXRvcmluZydcclxuICAgICAgICAgICAgICAgIH0sIHtcclxuICAgICAgICAgICAgICAgICAgICBpY29uOiAna2Qtb3BlbmVtaXMga2Qtc2Nob29sJyxcclxuICAgICAgICAgICAgICAgICAgICB0ZXh0OiAnU2Nob29sJyxcclxuICAgICAgICAgICAgICAgICAgICB0aGVtZTogJ29wZW5lbWlzLXNjaG9vbCdcclxuICAgICAgICAgICAgICAgIH0sIC8qe1xyXG4gICAgICAgICAgICAgICAgICAgIGljb246ICdrZC1vcGVuZW1pcyBrZC12aXN1YWxpemVyJyxcclxuICAgICAgICAgICAgICAgICAgICB0ZXh0OiAnVmlzdWFsaXplcicsXHJcbiAgICAgICAgICAgICAgICAgICAgdGhlbWU6ICdvcGVuZW1pcy12aXN1YWxpemVyJ1xyXG4gICAgICAgICAgICAgICAgfSwqLyB7XHJcbiAgICAgICAgICAgICAgICAgICAgaWNvbjogJ2tkLW9wZW5lbWlzIGtkLXN0eWxlZ3VpZGUnLFxyXG4gICAgICAgICAgICAgICAgICAgIHRleHQ6ICdTdHlsZWd1aWRlJyxcclxuICAgICAgICAgICAgICAgICAgICB0aGVtZTogJ29wZW5lbWlzLXN0eWxlZ3VpZGUnXHJcbiAgICAgICAgICAgICAgICB9XVxyXG4gICAgICAgICAgICB9LCB7XHJcbiAgICAgICAgICAgICAgICBidG5JY29uOiAna2QtZWxsaXBzaXMnLFxyXG4gICAgICAgICAgICAgICAgZHJvcGRvd25UeXBlOiAnbGlzdCcsXHJcbiAgICAgICAgICAgICAgICBkcm9wZG93bkNvbnRlbnQ6IFt7XHJcbiAgICAgICAgICAgICAgICAgICAgaWNvbjogJ2ZhIGZhLXVzZXInLFxyXG4gICAgICAgICAgICAgICAgICAgIHRleHQ6ICdBYm91dCdcclxuICAgICAgICAgICAgICAgIH0sIHtcclxuICAgICAgICAgICAgICAgICAgICBpY29uOiAnZmEgZmEtY29nJyxcclxuICAgICAgICAgICAgICAgICAgICB0ZXh0OiAnUHJlZmVyZW5jZXMnXHJcbiAgICAgICAgICAgICAgICB9LCB7XHJcbiAgICAgICAgICAgICAgICAgICAgaWNvbjogJ2ZhIGZhLXF1ZXN0aW9uLWNpcmNsZScsXHJcbiAgICAgICAgICAgICAgICAgICAgdGV4dDogJ0hlbHAnXHJcbiAgICAgICAgICAgICAgICB9LCB7XHJcbiAgICAgICAgICAgICAgICAgICAgaWNvbjogJ2ZhIGZhLXBvd2VyLW9mZicsXHJcbiAgICAgICAgICAgICAgICAgICAgdGV4dDogJ0xvZ291dCdcclxuICAgICAgICAgICAgICAgIH1dXHJcbiAgICAgICAgICAgIH1dXHJcbiAgICAgICAgfTtcclxuICAgIH1cclxufVxyXG4iXX0=