import { __decorate, __metadata, __read } from "tslib";
import { Component, Input, OnInit, OnChanges, ViewContainerRef, ElementRef, SimpleChanges, Renderer2 } from '@angular/core';
import { Router } from '@angular/router';
import { KdSplitterEvent } from '../kd-angular-splitter/index';
import { KdHeaderSvc } from './kd-angular-header-svc';
import { KdDataSvc } from '../kd-common/index';
var KdHeader = /** @class */ (function () {
    function KdHeader(_vcr, _router, _renderer, _kdsplitterEvent, _headerSvc, _dataSvc) {
        this._vcr = _vcr;
        this._router = _router;
        this._renderer = _renderer;
        this._kdsplitterEvent = _kdsplitterEvent;
        this._headerSvc = _headerSvc;
        this._dataSvc = _dataSvc;
        this._elem = _vcr.element;
    }
    KdHeader.prototype.ngOnInit = function () {
        this._initApi();
    };
    KdHeader.prototype.ngOnChanges = function (_simpleChanges) {
        this._setupHeaderConfig();
    };
    KdHeader.prototype.onClickHambugerMenu = function () {
        // console.log('open menu');
        this._kdsplitterEvent.fire('');
    };
    KdHeader.prototype.onClickLogo = function () {
        if ((typeof this.header.brandLogo.path !== 'undefined') && (typeof this.header.brandLogo.url === 'undefined')) {
            this._router.navigate([this.header.brandLogo.path]);
        }
        else if ((typeof this.header.brandLogo.url !== 'undefined') && (typeof this.header.brandLogo.path === 'undefined')) {
            window.open(this.header.brandLogo.url, this.header.brandLogo.target);
        }
        else if ((typeof this.header.brandLogo.path !== 'undefined') && (typeof this.header.brandLogo.url !== 'undefined')) {
            this._router.navigate([this.header.brandLogo.path]);
            this.header.brandLogo.url = null;
            this.header.brandLogo.target = null;
        }
    };
    KdHeader.prototype.onClickProfile = function () {
        if ((typeof this.header.userInfo.path !== 'undefined') && (typeof this.header.userInfo.url === 'undefined')) {
            this._router.navigate([this.header.userInfo.path]);
        }
        else if ((typeof this.header.userInfo.url !== 'undefined') && (typeof this.header.userInfo.path === 'undefined')) {
            window.open(this.header.userInfo.url, this.header.userInfo.target);
        }
        else if ((typeof this.header.userInfo.path !== 'undefined') && (typeof this.header.userInfo.url !== 'undefined')) {
            this._router.navigate([this.header.userInfo.path]);
            this.header.userInfo.url = null;
            this.header.userInfo.target = null;
        }
    };
    KdHeader.prototype.onClickHeaderButton = function (button) {
        if ((typeof button.callback === 'function')) {
            button.callback();
        }
        else if ((typeof button.path !== 'undefined') && (typeof button.url === 'undefined')) {
            this._router.navigate([button.path]);
        }
        else if ((typeof button.url !== 'undefined') && (typeof button.path === 'undefined')) {
            window.open(button.url, button.target);
        }
        else if ((typeof button.path !== 'undefined') && (typeof button.url !== 'undefined')) {
            this._router.navigate([this.header.userInfo.path]);
            button.url = null;
            button.target = null;
        }
    };
    KdHeader.prototype.onClickDropdownItem = function (item) {
        if ((typeof item.callback === 'function')) {
            item.callback();
        }
        else if ((typeof item.path !== 'undefined') && (typeof item.url === 'undefined')) {
            this._router.navigate([item.path]);
        }
        else if ((typeof item.url !== 'undefined') && (typeof item.path === 'undefined')) {
            window.open(item.url, item.target);
        }
        else if ((typeof item.path !== 'undefined') && (typeof item.url !== 'undefined')) {
            this._router.navigate([this.header.userInfo.path]);
            item.url = null;
            item.target = null;
        }
        if (typeof item.theme !== 'undefined') {
            __ngRendererSetElementAttributeHelper(this._renderer, this._elem.nativeElement.parentElement.parentElement.parentElement.offsetParent, 'class', item.theme);
        }
    };
    KdHeader.prototype._initApi = function () {
        var _this = this;
        if (!this.api)
            return;
        this.api.setUserInfo = function (_data) {
            Object.assign(_this.header.userInfo, _data);
            // this.cdr.detectChanges();
            if (typeof _this.header.userInfo !== 'undefined' && typeof _this.header.userInfo.imgSrc === 'undefined') {
                _this.header.userInfo.imgType = 'icon';
                _this.header.userInfo.imgSrc = 'kd-role';
            }
        };
        this.api.setGroupButton = function (_index, _button) {
            if (_this.header.btnGroup.length > 0 && _index <= 2) {
                _this.header.btnGroup[_index] = _button;
            }
        };
    };
    KdHeader.prototype._setupHeaderConfig = function () {
        if (typeof this.config !== 'undefined') {
            var defaultHeader = this._headerSvc.getDefaultConfig();
            var tempHeader = this._dataSvc.deepMergeObject(defaultHeader, this.config);
            try {
                // will try to fetch APP_CONFIGS from the file.
                tempHeader.brandLogo = Object.assign(tempHeader.brandLogo, APP_CONFIGS.product);
            }
            catch (err) {
                // console.log(err);
            }
            if (typeof tempHeader.userInfo !== 'undefined' && typeof tempHeader.userInfo.imgSrc === 'undefined') {
                tempHeader.userInfo.imgType = 'icon';
                tempHeader.userInfo.imgSrc = 'kd-role';
            }
            this.header = tempHeader;
        }
    };
    KdHeader.ctorParameters = function () { return [
        { type: ViewContainerRef },
        { type: Router },
        { type: Renderer2 },
        { type: KdSplitterEvent },
        { type: KdHeaderSvc },
        { type: KdDataSvc }
    ]; };
    __decorate([
        Input(),
        __metadata("design:type", Object)
    ], KdHeader.prototype, "config", void 0);
    __decorate([
        Input(),
        __metadata("design:type", Object)
    ], KdHeader.prototype, "api", void 0);
    KdHeader = __decorate([
        Component({
            selector: 'kd-header',
            template: "<nav class=\"kdx-navbar fixed-top\">\r\n    <div class=\"kdx-navbar-left\">\r\n        <div class=\"kdx-menu-handler\" (click)=\"onClickHambugerMenu()\">\r\n            <button class=\"kdx-menu-toggle\" type=\"button\">\r\n                <i class=\"fa fa-bars\"></i>\r\n            </button>\r\n        </div>\r\n        <div class=\"kdx-brand-logo\" (click)=\"onClickLogo()\">\r\n            <i *ngIf=\"header.brandLogo.type == 'icon'\" class=\"{{header.brandLogo.src}}\"></i>\r\n            <img *ngIf=\"header.brandLogo.type == 'image'\" src=\"{{header.brandLogo.src}}\" class=\"img-sm\">\r\n            <h1>{{header.brandLogo.name}}</h1>\r\n        </div>\r\n    </div>\r\n    <div class=\"kdx-navbar-right\">\r\n        <div class=\"kdx-header-navigation\">\r\n            <div class=\"kdx-username-wrapper\" ngbDropdown>\r\n                <a *ngIf=\"header.userInfo.showUser\" class=\"kdx-username\" ngbDropdownToggle>\r\n                    <span>{{header.userInfo.name}}</span>\r\n                    <div class=\"kdx-user-thumbnail\" *ngIf=\"header.userInfo.imgType == 'icon'\">\r\n                        <i class=\"{{header.userInfo.imgSrc}}\"></i>\r\n                    </div>\r\n                    <div class=\"kdx-user-thumbnail\" *ngIf=\"header.userInfo.imgType == 'image'\">\r\n                        <img src=\"{{header.userInfo.imgSrc}}\">\r\n                    </div>\r\n                </a>\r\n                <div ngbDropdownMenu class=\"dropdown-menu kdx-user-profile\">\r\n                    <div class=\"dropdown-arrow\">\r\n                        <i class=\"fa fa-caret-up\"></i>\r\n                    </div>\r\n                    <div class=\"dropdown-item\">\r\n                        <div class=\"kdx-user-thumbnail\" *ngIf=\"header.userInfo.imgType == 'icon'\">\r\n                            <i class=\"{{header.userInfo.imgSrc}}\"></i>\r\n                        </div>\r\n                        <div class=\"kdx-user-thumbnail\" *ngIf=\"header.userInfo.imgType == 'image'\">\r\n                            <img src=\"{{header.userInfo.imgSrc}}\">\r\n                        </div>\r\n                        <ul>\r\n                            <li><b>{{header.userInfo.name}}</b></li>\r\n                            <li>{{header.userInfo.role}}</li>\r\n                        </ul>\r\n                        <a class=\"btn\" *ngIf=\"header.userInfo.url || header.userInfo.path\" (click)=\"onClickProfile()\">\r\n                            <i class=\"fa fa-cog\"></i>\r\n                            <span>My Account</span>\r\n                        </a>\r\n                    </div>\r\n                </div>\r\n            </div>\r\n            <div class=\"kdx-btn-group-wrapper\">\r\n                <div class=\"btn-group\" *ngFor=\"let button of header.btnGroup | slice:0:3;\" [ngSwitch]=\"button.dropdownType\">\r\n                    <div *ngIf=\"button.dropdownContent && button.dropdownContent.length > 0\">\r\n                        <!-- Grid -->\r\n                        <div *ngSwitchCase=\"'grid'\" class=\"kdx-grid-btn\" ngbDropdown>\r\n                            <a type=\"button\" class=\"btn kdx-dropdown-toggle\" ngbDropdownToggle>\r\n                                <i class=\"{{button.btnIcon}}\"></i>\r\n                            </a>\r\n                            <!-- Number of item inside grid dropdown -->\r\n                            <div *ngIf=\"button.dropdownContent\" ngbDropdownMenu class=\"dropdown-menu kdx-grid-layout\">\r\n                                <div class=\"dropdown-arrow\">\r\n                                    <i class=\"fa fa-caret-up\"></i>\r\n                                </div>\r\n                                <a class=\"dropdown-item kdx-grid-item\" *ngFor=\"let item of button.dropdownContent;\" (click)=\"onClickDropdownItem(item)\">\r\n                                    <i *ngIf=\"item.icon\" class=\"{{item.icon}}\"></i>\r\n                                    <img *ngIf=\"!item.icon\" src=\"{{item.imgSrc}}\">\r\n                                    <span>{{item.text}}</span>\r\n                                </a>\r\n                            </div>\r\n                        </div>\r\n                        <!-- List -->\r\n                        <div *ngSwitchCase=\"'list'\" class=\"kdx-list-btn\" ngbDropdown>\r\n                            <a type=\"button\" class=\"btn kdx-dropdown-toggle\" ngbDropdownToggle>\r\n                                <i class=\"{{button.btnIcon}}\"></i>\r\n                            </a>\r\n                            <!-- Number of item inside list dropdown -->\r\n                            <div *ngIf=\"button.dropdownContent\" ngbDropdownMenu ngFor=\"let item of button.dropdownContent;\" class=\"dropdown-menu kdx-list-layout\">\r\n                                <div class=\"dropdown-arrow\">\r\n                                    <i class=\"fa fa-caret-up\"></i>\r\n                                </div>\r\n                                <a class=\"dropdown-item kdx-list-item\" *ngFor=\"let item of button.dropdownContent;\" (click)=\"onClickDropdownItem(item)\">\r\n                                    <i class=\"{{item.icon}}\"></i>\r\n                                    <span>{{item.text}}</span>\r\n                                </a>\r\n                            </div>\r\n                        </div>\r\n                    </div>\r\n                    <!-- Default -->\r\n                    <div *ngSwitchDefault>\r\n                        <a class=\"btn\" (click)=\"onClickHeaderButton(button)\">\r\n                            <i class=\"{{button.btnIcon}}\"></i>\r\n                        </a>\r\n                    </div>\r\n                </div>\r\n            </div>\r\n        </div>\r\n    </div>\r\n</nav>\r\n<!-- <router-outlet></router-outlet> -->\r\n",
            providers: [KdHeaderSvc, KdDataSvc]
        }),
        __metadata("design:paramtypes", [ViewContainerRef,
            Router,
            Renderer2,
            KdSplitterEvent,
            KdHeaderSvc,
            KdDataSvc])
    ], KdHeader);
    return KdHeader;
}());
export { KdHeader };
function __ngRendererSplitNamespaceHelper(name) {
    if (name[0] === ":") {
        var match = name.match(/^:([^:]+):(.+)$/);
        return [match[1], match[2]];
    }
    return ["", name];
}
function __ngRendererSetElementAttributeHelper(renderer, element, namespaceAndName, value) {
    var _a = __read(__ngRendererSplitNamespaceHelper(namespaceAndName), 2), namespace = _a[0], name = _a[1];
    if (value != null) {
        renderer.setAttribute(element, name, value, namespace);
    }
    else {
        renderer.removeAttribute(element, name, namespace);
    }
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoia2QtYW5ndWxhci1oZWFkZXIuanMiLCJzb3VyY2VSb290Ijoibmc6Ly9vcGVuZW1pcy1zdHlsZWd1aWRlLWxpYi8iLCJzb3VyY2VzIjpbImtkLWNvbXBvbmVudHMva2QtYW5ndWxhci1oZWFkZXIva2QtYW5ndWxhci1oZWFkZXIudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IjtBQUFBLE9BQU8sRUFBRSxTQUFTLEVBQUUsS0FBSyxFQUFFLE1BQU0sRUFBRSxTQUFTLEVBQUUsZ0JBQWdCLEVBQUUsVUFBVSxFQUFFLGFBQWEsRUFBRSxTQUFTLEVBQUUsTUFBTSxlQUFlLENBQUM7QUFFNUgsT0FBTyxFQUFFLE1BQU0sRUFBRSxNQUFNLGlCQUFpQixDQUFDO0FBQ3pDLE9BQU8sRUFBRSxlQUFlLEVBQUUsTUFBTSw4QkFBOEIsQ0FBQztBQUMvRCxPQUFPLEVBQUUsV0FBVyxFQUFFLE1BQU0seUJBQXlCLENBQUM7QUFDdEQsT0FBTyxFQUFFLFNBQVMsRUFBRSxNQUFNLG9CQUFvQixDQUFDO0FBZ0IvQztJQU9JLGtCQUNZLElBQXNCLEVBQ3RCLE9BQWUsRUFDZixTQUFvQixFQUNwQixnQkFBaUMsRUFDakMsVUFBdUIsRUFDdkIsUUFBbUI7UUFMbkIsU0FBSSxHQUFKLElBQUksQ0FBa0I7UUFDdEIsWUFBTyxHQUFQLE9BQU8sQ0FBUTtRQUNmLGNBQVMsR0FBVCxTQUFTLENBQVc7UUFDcEIscUJBQWdCLEdBQWhCLGdCQUFnQixDQUFpQjtRQUNqQyxlQUFVLEdBQVYsVUFBVSxDQUFhO1FBQ3ZCLGFBQVEsR0FBUixRQUFRLENBQVc7UUFFM0IsSUFBSSxDQUFDLEtBQUssR0FBRyxJQUFJLENBQUMsT0FBTyxDQUFDO0lBQzlCLENBQUM7SUFFRCwyQkFBUSxHQUFSO1FBQ0ksSUFBSSxDQUFDLFFBQVEsRUFBRSxDQUFDO0lBQ3BCLENBQUM7SUFFRCw4QkFBVyxHQUFYLFVBQVksY0FBNkI7UUFDckMsSUFBSSxDQUFDLGtCQUFrQixFQUFFLENBQUM7SUFDOUIsQ0FBQztJQUVNLHNDQUFtQixHQUExQjtRQUNJLDRCQUE0QjtRQUM1QixJQUFJLENBQUMsZ0JBQWdCLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxDQUFDO0lBQ25DLENBQUM7SUFFTSw4QkFBVyxHQUFsQjtRQUNJLElBQUksQ0FBQyxPQUFPLElBQUksQ0FBQyxNQUFNLENBQUMsU0FBUyxDQUFDLElBQUksS0FBSyxXQUFXLENBQUMsSUFBSSxDQUFDLE9BQU8sSUFBSSxDQUFDLE1BQU0sQ0FBQyxTQUFTLENBQUMsR0FBRyxLQUFLLFdBQVcsQ0FBQyxFQUFFO1lBQzNHLElBQUksQ0FBQyxPQUFPLENBQUMsUUFBUSxDQUFDLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQztTQUN2RDthQUVJLElBQUksQ0FBQyxPQUFPLElBQUksQ0FBQyxNQUFNLENBQUMsU0FBUyxDQUFDLEdBQUcsS0FBSyxXQUFXLENBQUMsSUFBSSxDQUFDLE9BQU8sSUFBSSxDQUFDLE1BQU0sQ0FBQyxTQUFTLENBQUMsSUFBSSxLQUFLLFdBQVcsQ0FBQyxFQUFFO1lBQ2hILE1BQU0sQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxTQUFTLENBQUMsR0FBRyxFQUFFLElBQUksQ0FBQyxNQUFNLENBQUMsU0FBUyxDQUFDLE1BQU0sQ0FBQyxDQUFDO1NBQ3hFO2FBRUksSUFBSSxDQUFDLE9BQU8sSUFBSSxDQUFDLE1BQU0sQ0FBQyxTQUFTLENBQUMsSUFBSSxLQUFLLFdBQVcsQ0FBQyxJQUFJLENBQUMsT0FBTyxJQUFJLENBQUMsTUFBTSxDQUFDLFNBQVMsQ0FBQyxHQUFHLEtBQUssV0FBVyxDQUFDLEVBQUU7WUFDaEgsSUFBSSxDQUFDLE9BQU8sQ0FBQyxRQUFRLENBQUMsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDO1lBQ3BELElBQUksQ0FBQyxNQUFNLENBQUMsU0FBUyxDQUFDLEdBQUcsR0FBRyxJQUFJLENBQUM7WUFDakMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxTQUFTLENBQUMsTUFBTSxHQUFHLElBQUksQ0FBQztTQUN2QztJQUNMLENBQUM7SUFFTSxpQ0FBYyxHQUFyQjtRQUNJLElBQUksQ0FBQyxPQUFPLElBQUksQ0FBQyxNQUFNLENBQUMsUUFBUSxDQUFDLElBQUksS0FBSyxXQUFXLENBQUMsSUFBSSxDQUFDLE9BQU8sSUFBSSxDQUFDLE1BQU0sQ0FBQyxRQUFRLENBQUMsR0FBRyxLQUFLLFdBQVcsQ0FBQyxFQUFFO1lBQ3pHLElBQUksQ0FBQyxPQUFPLENBQUMsUUFBUSxDQUFDLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQztTQUN0RDthQUVJLElBQUksQ0FBQyxPQUFPLElBQUksQ0FBQyxNQUFNLENBQUMsUUFBUSxDQUFDLEdBQUcsS0FBSyxXQUFXLENBQUMsSUFBSSxDQUFDLE9BQU8sSUFBSSxDQUFDLE1BQU0sQ0FBQyxRQUFRLENBQUMsSUFBSSxLQUFLLFdBQVcsQ0FBQyxFQUFFO1lBQzlHLE1BQU0sQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxRQUFRLENBQUMsR0FBRyxFQUFFLElBQUksQ0FBQyxNQUFNLENBQUMsUUFBUSxDQUFDLE1BQU0sQ0FBQyxDQUFDO1NBQ3RFO2FBRUksSUFBSSxDQUFDLE9BQU8sSUFBSSxDQUFDLE1BQU0sQ0FBQyxRQUFRLENBQUMsSUFBSSxLQUFLLFdBQVcsQ0FBQyxJQUFJLENBQUMsT0FBTyxJQUFJLENBQUMsTUFBTSxDQUFDLFFBQVEsQ0FBQyxHQUFHLEtBQUssV0FBVyxDQUFDLEVBQUU7WUFDOUcsSUFBSSxDQUFDLE9BQU8sQ0FBQyxRQUFRLENBQUMsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDO1lBQ25ELElBQUksQ0FBQyxNQUFNLENBQUMsUUFBUSxDQUFDLEdBQUcsR0FBRyxJQUFJLENBQUM7WUFDaEMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxRQUFRLENBQUMsTUFBTSxHQUFHLElBQUksQ0FBQztTQUN0QztJQUNMLENBQUM7SUFFTSxzQ0FBbUIsR0FBMUIsVUFBMkIsTUFBVztRQUNsQyxJQUFJLENBQUMsT0FBTyxNQUFNLENBQUMsUUFBUSxLQUFLLFVBQVUsQ0FBQyxFQUFFO1lBQ3pDLE1BQU0sQ0FBQyxRQUFRLEVBQUUsQ0FBQztTQUNyQjthQUNJLElBQUksQ0FBQyxPQUFPLE1BQU0sQ0FBQyxJQUFJLEtBQUssV0FBVyxDQUFDLElBQUksQ0FBQyxPQUFPLE1BQU0sQ0FBQyxHQUFHLEtBQUssV0FBVyxDQUFDLEVBQUU7WUFDbEYsSUFBSSxDQUFDLE9BQU8sQ0FBQyxRQUFRLENBQUMsQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQztTQUN4QzthQUVJLElBQUksQ0FBQyxPQUFPLE1BQU0sQ0FBQyxHQUFHLEtBQUssV0FBVyxDQUFDLElBQUksQ0FBQyxPQUFPLE1BQU0sQ0FBQyxJQUFJLEtBQUssV0FBVyxDQUFDLEVBQUU7WUFDbEYsTUFBTSxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsR0FBRyxFQUFFLE1BQU0sQ0FBQyxNQUFNLENBQUMsQ0FBQztTQUMxQzthQUVJLElBQUksQ0FBQyxPQUFPLE1BQU0sQ0FBQyxJQUFJLEtBQUssV0FBVyxDQUFDLElBQUksQ0FBQyxPQUFPLE1BQU0sQ0FBQyxHQUFHLEtBQUssV0FBVyxDQUFDLEVBQUU7WUFDbEYsSUFBSSxDQUFDLE9BQU8sQ0FBQyxRQUFRLENBQUMsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDO1lBQ25ELE1BQU0sQ0FBQyxHQUFHLEdBQUcsSUFBSSxDQUFDO1lBQ2xCLE1BQU0sQ0FBQyxNQUFNLEdBQUcsSUFBSSxDQUFDO1NBQ3hCO0lBQ0wsQ0FBQztJQUVNLHNDQUFtQixHQUExQixVQUEyQixJQUFTO1FBQ2hDLElBQUksQ0FBQyxPQUFPLElBQUksQ0FBQyxRQUFRLEtBQUssVUFBVSxDQUFDLEVBQUU7WUFDdkMsSUFBSSxDQUFDLFFBQVEsRUFBRSxDQUFDO1NBQ25CO2FBQU0sSUFBSSxDQUFDLE9BQU8sSUFBSSxDQUFDLElBQUksS0FBSyxXQUFXLENBQUMsSUFBSSxDQUFDLE9BQU8sSUFBSSxDQUFDLEdBQUcsS0FBSyxXQUFXLENBQUMsRUFBRTtZQUNoRixJQUFJLENBQUMsT0FBTyxDQUFDLFFBQVEsQ0FBQyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDO1NBQ3RDO2FBRUksSUFBSSxDQUFDLE9BQU8sSUFBSSxDQUFDLEdBQUcsS0FBSyxXQUFXLENBQUMsSUFBSSxDQUFDLE9BQU8sSUFBSSxDQUFDLElBQUksS0FBSyxXQUFXLENBQUMsRUFBRTtZQUM5RSxNQUFNLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxHQUFHLEVBQUUsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDO1NBQ3RDO2FBRUksSUFBSSxDQUFDLE9BQU8sSUFBSSxDQUFDLElBQUksS0FBSyxXQUFXLENBQUMsSUFBSSxDQUFDLE9BQU8sSUFBSSxDQUFDLEdBQUcsS0FBSyxXQUFXLENBQUMsRUFBRTtZQUM5RSxJQUFJLENBQUMsT0FBTyxDQUFDLFFBQVEsQ0FBQyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUM7WUFDbkQsSUFBSSxDQUFDLEdBQUcsR0FBRyxJQUFJLENBQUM7WUFDaEIsSUFBSSxDQUFDLE1BQU0sR0FBRyxJQUFJLENBQUM7U0FDdEI7UUFFRCxJQUFJLE9BQU8sSUFBSSxDQUFDLEtBQUssS0FBSyxXQUFXLEVBQUU7WUFDbkMscUNBQXFDLENBQUMsSUFBSSxDQUFDLFNBQVMsRUFBRSxJQUFJLENBQUMsS0FBSyxDQUFDLGFBQWEsQ0FBQyxhQUFhLENBQUMsYUFBYSxDQUFDLGFBQWEsQ0FBQyxZQUFZLEVBQUUsT0FBTyxFQUFFLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQztTQUMvSjtJQUNMLENBQUM7SUFFTywyQkFBUSxHQUFoQjtRQUFBLGlCQWtCQztRQWpCRyxJQUFJLENBQUMsSUFBSSxDQUFDLEdBQUc7WUFBRSxPQUFPO1FBRXRCLElBQUksQ0FBQyxHQUFHLENBQUMsV0FBVyxHQUFHLFVBQUMsS0FBc0I7WUFDcEMsTUFBTyxDQUFDLE1BQU0sQ0FBQyxLQUFJLENBQUMsTUFBTSxDQUFDLFFBQVEsRUFBRSxLQUFLLENBQUMsQ0FBQztZQUNsRCw0QkFBNEI7WUFFNUIsSUFBSSxPQUFPLEtBQUksQ0FBQyxNQUFNLENBQUMsUUFBUSxLQUFLLFdBQVcsSUFBSSxPQUFPLEtBQUksQ0FBQyxNQUFNLENBQUMsUUFBUSxDQUFDLE1BQU0sS0FBSyxXQUFXLEVBQUU7Z0JBQ25HLEtBQUksQ0FBQyxNQUFNLENBQUMsUUFBUSxDQUFDLE9BQU8sR0FBRyxNQUFNLENBQUM7Z0JBQ3RDLEtBQUksQ0FBQyxNQUFNLENBQUMsUUFBUSxDQUFDLE1BQU0sR0FBRyxTQUFTLENBQUM7YUFDM0M7UUFDTCxDQUFDLENBQUM7UUFFRixJQUFJLENBQUMsR0FBRyxDQUFDLGNBQWMsR0FBRyxVQUFDLE1BQWMsRUFBRSxPQUFzQjtZQUM3RCxJQUFJLEtBQUksQ0FBQyxNQUFNLENBQUMsUUFBUSxDQUFDLE1BQU0sR0FBRyxDQUFDLElBQUksTUFBTSxJQUFJLENBQUMsRUFBRTtnQkFDaEQsS0FBSSxDQUFDLE1BQU0sQ0FBQyxRQUFRLENBQUMsTUFBTSxDQUFDLEdBQUcsT0FBTyxDQUFDO2FBQzFDO1FBQ0wsQ0FBQyxDQUFDO0lBQ04sQ0FBQztJQUVPLHFDQUFrQixHQUExQjtRQUNJLElBQUksT0FBTyxJQUFJLENBQUMsTUFBTSxLQUFLLFdBQVcsRUFBRTtZQUNwQyxJQUFJLGFBQWEsR0FBa0IsSUFBSSxDQUFDLFVBQVUsQ0FBQyxnQkFBZ0IsRUFBRSxDQUFDO1lBQ3RFLElBQUksVUFBVSxHQUFrQixJQUFJLENBQUMsUUFBUSxDQUFDLGVBQWUsQ0FBQyxhQUFhLEVBQUUsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDO1lBRTFGLElBQUk7Z0JBQ0EsK0NBQStDO2dCQUMvQyxVQUFVLENBQUMsU0FBUyxHQUFTLE1BQU8sQ0FBQyxNQUFNLENBQUMsVUFBVSxDQUFDLFNBQVMsRUFBRSxXQUFXLENBQUMsT0FBTyxDQUFDLENBQUM7YUFDMUY7WUFBQyxPQUFPLEdBQUcsRUFBRTtnQkFDVixvQkFBb0I7YUFDdkI7WUFFRCxJQUFJLE9BQU8sVUFBVSxDQUFDLFFBQVEsS0FBSyxXQUFXLElBQUksT0FBTyxVQUFVLENBQUMsUUFBUSxDQUFDLE1BQU0sS0FBSyxXQUFXLEVBQUU7Z0JBQ2pHLFVBQVUsQ0FBQyxRQUFRLENBQUMsT0FBTyxHQUFHLE1BQU0sQ0FBQztnQkFDckMsVUFBVSxDQUFDLFFBQVEsQ0FBQyxNQUFNLEdBQUcsU0FBUyxDQUFDO2FBQzFDO1lBRUQsSUFBSSxDQUFDLE1BQU0sR0FBRyxVQUFVLENBQUM7U0FDNUI7SUFDTCxDQUFDOztnQkF2SWlCLGdCQUFnQjtnQkFDYixNQUFNO2dCQUNKLFNBQVM7Z0JBQ0YsZUFBZTtnQkFDckIsV0FBVztnQkFDYixTQUFTOztJQVp0QjtRQUFSLEtBQUssRUFBRTs7NENBQWE7SUFDWjtRQUFSLEtBQUssRUFBRTs7eUNBQVU7SUFGVCxRQUFRO1FBTnBCLFNBQVMsQ0FBQztZQUNQLFFBQVEsRUFBRSxXQUFXO1lBQ3JCLHF2TEFBdUM7WUFDdkMsU0FBUyxFQUFFLENBQUMsV0FBVyxFQUFFLFNBQVMsQ0FBQztTQUN0QyxDQUFDO3lDQVVvQixnQkFBZ0I7WUFDYixNQUFNO1lBQ0osU0FBUztZQUNGLGVBQWU7WUFDckIsV0FBVztZQUNiLFNBQVM7T0FidEIsUUFBUSxDQWdKcEI7SUFBRCxlQUFDO0NBQUEsQUFoSkQsSUFnSkM7U0FoSlksUUFBUTtBQW9KckIsU0FBUyxnQ0FBZ0MsQ0FBQyxJQUFnQztJQUN0RSxJQUFJLElBQUksQ0FBQyxDQUFDLENBQUMsS0FBSyxHQUFHLEVBQUU7UUFDakIsSUFBTSxLQUFLLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQyxpQkFBaUIsQ0FBQyxDQUFDO1FBQzVDLE9BQU8sQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLEVBQUUsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7S0FDL0I7SUFDRCxPQUFPLENBQUMsRUFBRSxFQUFFLElBQUksQ0FBQyxDQUFDO0FBQ3RCLENBQUM7QUFFRCxTQUFTLHFDQUFxQyxDQUFDLFFBQW9DLEVBQUUsT0FBbUMsRUFBRSxnQkFBNEMsRUFBRSxLQUFrQztJQUNoTSxJQUFBLGtFQUFzRSxFQUFyRSxpQkFBUyxFQUFFLFlBQTBELENBQUM7SUFDN0UsSUFBSSxLQUFLLElBQUksSUFBSSxFQUFFO1FBQ2YsUUFBUSxDQUFDLFlBQVksQ0FBQyxPQUFPLEVBQUUsSUFBSSxFQUFFLEtBQUssRUFBRSxTQUFTLENBQUMsQ0FBQztLQUMxRDtTQUNJO1FBQ0QsUUFBUSxDQUFDLGVBQWUsQ0FBQyxPQUFPLEVBQUUsSUFBSSxFQUFFLFNBQVMsQ0FBQyxDQUFDO0tBQ3REO0FBQ0wsQ0FBQyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IENvbXBvbmVudCwgSW5wdXQsIE9uSW5pdCwgT25DaGFuZ2VzLCBWaWV3Q29udGFpbmVyUmVmLCBFbGVtZW50UmVmLCBTaW1wbGVDaGFuZ2VzLCBSZW5kZXJlcjIgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcclxuXHJcbmltcG9ydCB7IFJvdXRlciB9IGZyb20gJ0Bhbmd1bGFyL3JvdXRlcic7XHJcbmltcG9ydCB7IEtkU3BsaXR0ZXJFdmVudCB9IGZyb20gJy4uL2tkLWFuZ3VsYXItc3BsaXR0ZXIvaW5kZXgnO1xyXG5pbXBvcnQgeyBLZEhlYWRlclN2YyB9IGZyb20gJy4va2QtYW5ndWxhci1oZWFkZXItc3ZjJztcclxuaW1wb3J0IHsgS2REYXRhU3ZjIH0gZnJvbSAnLi4va2QtY29tbW9uL2luZGV4JztcclxuaW1wb3J0IHtcclxuICAgIElIZWFkZXJDb25maWcsXHJcbiAgICBJSGVhZGVyVXNlckluZm8sXHJcbiAgICBJSGVhZGVyQnV0dG9uLFxyXG4gICAgLy8gSUhlYWRlckJyYW5kTG9nb1xyXG59IGZyb20gJy4va2QtYW5ndWxhci1oZWFkZXItaW50ZXJmYWNlJztcclxuXHJcbmRlY2xhcmUgbGV0IEFQUF9DT05GSUdTOiBhbnk7XHJcblxyXG5AQ29tcG9uZW50KHtcclxuICAgIHNlbGVjdG9yOiAna2QtaGVhZGVyJyxcclxuICAgIHRlbXBsYXRlVXJsOiAnLi9rZC1hbmd1bGFyLWhlYWRlci5odG1sJyxcclxuICAgIHByb3ZpZGVyczogW0tkSGVhZGVyU3ZjLCBLZERhdGFTdmNdXHJcbn0pXHJcblxyXG5leHBvcnQgY2xhc3MgS2RIZWFkZXIgaW1wbGVtZW50cyBPbkluaXQsIE9uQ2hhbmdlcyB7XHJcbiAgICBASW5wdXQoKSBjb25maWc6IGFueTtcclxuICAgIEBJbnB1dCgpIGFwaTogYW55O1xyXG5cclxuICAgIHB1YmxpYyBoZWFkZXI6IElIZWFkZXJDb25maWc7XHJcbiAgICBwcml2YXRlIF9lbGVtOiBFbGVtZW50UmVmO1xyXG5cclxuICAgIGNvbnN0cnVjdG9yKFxyXG4gICAgICAgIHByaXZhdGUgX3ZjcjogVmlld0NvbnRhaW5lclJlZixcclxuICAgICAgICBwcml2YXRlIF9yb3V0ZXI6IFJvdXRlcixcclxuICAgICAgICBwcml2YXRlIF9yZW5kZXJlcjogUmVuZGVyZXIyLFxyXG4gICAgICAgIHByaXZhdGUgX2tkc3BsaXR0ZXJFdmVudDogS2RTcGxpdHRlckV2ZW50LFxyXG4gICAgICAgIHByaXZhdGUgX2hlYWRlclN2YzogS2RIZWFkZXJTdmMsXHJcbiAgICAgICAgcHJpdmF0ZSBfZGF0YVN2YzogS2REYXRhU3ZjLFxyXG4gICAgKSB7XHJcbiAgICAgICAgdGhpcy5fZWxlbSA9IF92Y3IuZWxlbWVudDtcclxuICAgIH1cclxuXHJcbiAgICBuZ09uSW5pdCgpOiB2b2lkIHtcclxuICAgICAgICB0aGlzLl9pbml0QXBpKCk7XHJcbiAgICB9XHJcblxyXG4gICAgbmdPbkNoYW5nZXMoX3NpbXBsZUNoYW5nZXM6IFNpbXBsZUNoYW5nZXMpOiB2b2lkIHtcclxuICAgICAgICB0aGlzLl9zZXR1cEhlYWRlckNvbmZpZygpO1xyXG4gICAgfVxyXG5cclxuICAgIHB1YmxpYyBvbkNsaWNrSGFtYnVnZXJNZW51KCk6IHZvaWQge1xyXG4gICAgICAgIC8vIGNvbnNvbGUubG9nKCdvcGVuIG1lbnUnKTtcclxuICAgICAgICB0aGlzLl9rZHNwbGl0dGVyRXZlbnQuZmlyZSgnJyk7XHJcbiAgICB9XHJcblxyXG4gICAgcHVibGljIG9uQ2xpY2tMb2dvKCk6IHZvaWQge1xyXG4gICAgICAgIGlmICgodHlwZW9mIHRoaXMuaGVhZGVyLmJyYW5kTG9nby5wYXRoICE9PSAndW5kZWZpbmVkJykgJiYgKHR5cGVvZiB0aGlzLmhlYWRlci5icmFuZExvZ28udXJsID09PSAndW5kZWZpbmVkJykpIHtcclxuICAgICAgICAgICAgdGhpcy5fcm91dGVyLm5hdmlnYXRlKFt0aGlzLmhlYWRlci5icmFuZExvZ28ucGF0aF0pO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgZWxzZSBpZiAoKHR5cGVvZiB0aGlzLmhlYWRlci5icmFuZExvZ28udXJsICE9PSAndW5kZWZpbmVkJykgJiYgKHR5cGVvZiB0aGlzLmhlYWRlci5icmFuZExvZ28ucGF0aCA9PT0gJ3VuZGVmaW5lZCcpKSB7XHJcbiAgICAgICAgICAgIHdpbmRvdy5vcGVuKHRoaXMuaGVhZGVyLmJyYW5kTG9nby51cmwsIHRoaXMuaGVhZGVyLmJyYW5kTG9nby50YXJnZXQpO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgZWxzZSBpZiAoKHR5cGVvZiB0aGlzLmhlYWRlci5icmFuZExvZ28ucGF0aCAhPT0gJ3VuZGVmaW5lZCcpICYmICh0eXBlb2YgdGhpcy5oZWFkZXIuYnJhbmRMb2dvLnVybCAhPT0gJ3VuZGVmaW5lZCcpKSB7XHJcbiAgICAgICAgICAgIHRoaXMuX3JvdXRlci5uYXZpZ2F0ZShbdGhpcy5oZWFkZXIuYnJhbmRMb2dvLnBhdGhdKTtcclxuICAgICAgICAgICAgdGhpcy5oZWFkZXIuYnJhbmRMb2dvLnVybCA9IG51bGw7XHJcbiAgICAgICAgICAgIHRoaXMuaGVhZGVyLmJyYW5kTG9nby50YXJnZXQgPSBudWxsO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICBwdWJsaWMgb25DbGlja1Byb2ZpbGUoKTogdm9pZCB7XHJcbiAgICAgICAgaWYgKCh0eXBlb2YgdGhpcy5oZWFkZXIudXNlckluZm8ucGF0aCAhPT0gJ3VuZGVmaW5lZCcpICYmICh0eXBlb2YgdGhpcy5oZWFkZXIudXNlckluZm8udXJsID09PSAndW5kZWZpbmVkJykpIHtcclxuICAgICAgICAgICAgdGhpcy5fcm91dGVyLm5hdmlnYXRlKFt0aGlzLmhlYWRlci51c2VySW5mby5wYXRoXSk7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICBlbHNlIGlmICgodHlwZW9mIHRoaXMuaGVhZGVyLnVzZXJJbmZvLnVybCAhPT0gJ3VuZGVmaW5lZCcpICYmICh0eXBlb2YgdGhpcy5oZWFkZXIudXNlckluZm8ucGF0aCA9PT0gJ3VuZGVmaW5lZCcpKSB7XHJcbiAgICAgICAgICAgIHdpbmRvdy5vcGVuKHRoaXMuaGVhZGVyLnVzZXJJbmZvLnVybCwgdGhpcy5oZWFkZXIudXNlckluZm8udGFyZ2V0KTtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIGVsc2UgaWYgKCh0eXBlb2YgdGhpcy5oZWFkZXIudXNlckluZm8ucGF0aCAhPT0gJ3VuZGVmaW5lZCcpICYmICh0eXBlb2YgdGhpcy5oZWFkZXIudXNlckluZm8udXJsICE9PSAndW5kZWZpbmVkJykpIHtcclxuICAgICAgICAgICAgdGhpcy5fcm91dGVyLm5hdmlnYXRlKFt0aGlzLmhlYWRlci51c2VySW5mby5wYXRoXSk7XHJcbiAgICAgICAgICAgIHRoaXMuaGVhZGVyLnVzZXJJbmZvLnVybCA9IG51bGw7XHJcbiAgICAgICAgICAgIHRoaXMuaGVhZGVyLnVzZXJJbmZvLnRhcmdldCA9IG51bGw7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIHB1YmxpYyBvbkNsaWNrSGVhZGVyQnV0dG9uKGJ1dHRvbjogYW55KTogdm9pZCB7XHJcbiAgICAgICAgaWYgKCh0eXBlb2YgYnV0dG9uLmNhbGxiYWNrID09PSAnZnVuY3Rpb24nKSkge1xyXG4gICAgICAgICAgICBidXR0b24uY2FsbGJhY2soKTtcclxuICAgICAgICB9XHJcbiAgICAgICAgZWxzZSBpZiAoKHR5cGVvZiBidXR0b24ucGF0aCAhPT0gJ3VuZGVmaW5lZCcpICYmICh0eXBlb2YgYnV0dG9uLnVybCA9PT0gJ3VuZGVmaW5lZCcpKSB7XHJcbiAgICAgICAgICAgIHRoaXMuX3JvdXRlci5uYXZpZ2F0ZShbYnV0dG9uLnBhdGhdKTtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIGVsc2UgaWYgKCh0eXBlb2YgYnV0dG9uLnVybCAhPT0gJ3VuZGVmaW5lZCcpICYmICh0eXBlb2YgYnV0dG9uLnBhdGggPT09ICd1bmRlZmluZWQnKSkge1xyXG4gICAgICAgICAgICB3aW5kb3cub3BlbihidXR0b24udXJsLCBidXR0b24udGFyZ2V0KTtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIGVsc2UgaWYgKCh0eXBlb2YgYnV0dG9uLnBhdGggIT09ICd1bmRlZmluZWQnKSAmJiAodHlwZW9mIGJ1dHRvbi51cmwgIT09ICd1bmRlZmluZWQnKSkge1xyXG4gICAgICAgICAgICB0aGlzLl9yb3V0ZXIubmF2aWdhdGUoW3RoaXMuaGVhZGVyLnVzZXJJbmZvLnBhdGhdKTtcclxuICAgICAgICAgICAgYnV0dG9uLnVybCA9IG51bGw7XHJcbiAgICAgICAgICAgIGJ1dHRvbi50YXJnZXQgPSBudWxsO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICBwdWJsaWMgb25DbGlja0Ryb3Bkb3duSXRlbShpdGVtOiBhbnkpOiB2b2lkIHtcclxuICAgICAgICBpZiAoKHR5cGVvZiBpdGVtLmNhbGxiYWNrID09PSAnZnVuY3Rpb24nKSkge1xyXG4gICAgICAgICAgICBpdGVtLmNhbGxiYWNrKCk7XHJcbiAgICAgICAgfSBlbHNlIGlmICgodHlwZW9mIGl0ZW0ucGF0aCAhPT0gJ3VuZGVmaW5lZCcpICYmICh0eXBlb2YgaXRlbS51cmwgPT09ICd1bmRlZmluZWQnKSkge1xyXG4gICAgICAgICAgICB0aGlzLl9yb3V0ZXIubmF2aWdhdGUoW2l0ZW0ucGF0aF0pO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgZWxzZSBpZiAoKHR5cGVvZiBpdGVtLnVybCAhPT0gJ3VuZGVmaW5lZCcpICYmICh0eXBlb2YgaXRlbS5wYXRoID09PSAndW5kZWZpbmVkJykpIHtcclxuICAgICAgICAgICAgd2luZG93Lm9wZW4oaXRlbS51cmwsIGl0ZW0udGFyZ2V0KTtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIGVsc2UgaWYgKCh0eXBlb2YgaXRlbS5wYXRoICE9PSAndW5kZWZpbmVkJykgJiYgKHR5cGVvZiBpdGVtLnVybCAhPT0gJ3VuZGVmaW5lZCcpKSB7XHJcbiAgICAgICAgICAgIHRoaXMuX3JvdXRlci5uYXZpZ2F0ZShbdGhpcy5oZWFkZXIudXNlckluZm8ucGF0aF0pO1xyXG4gICAgICAgICAgICBpdGVtLnVybCA9IG51bGw7XHJcbiAgICAgICAgICAgIGl0ZW0udGFyZ2V0ID0gbnVsbDtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIGlmICh0eXBlb2YgaXRlbS50aGVtZSAhPT0gJ3VuZGVmaW5lZCcpIHtcclxuICAgICAgICAgICAgX19uZ1JlbmRlcmVyU2V0RWxlbWVudEF0dHJpYnV0ZUhlbHBlcih0aGlzLl9yZW5kZXJlciwgdGhpcy5fZWxlbS5uYXRpdmVFbGVtZW50LnBhcmVudEVsZW1lbnQucGFyZW50RWxlbWVudC5wYXJlbnRFbGVtZW50Lm9mZnNldFBhcmVudCwgJ2NsYXNzJywgaXRlbS50aGVtZSk7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX2luaXRBcGkoKSB7XHJcbiAgICAgICAgaWYgKCF0aGlzLmFwaSkgcmV0dXJuO1xyXG5cclxuICAgICAgICB0aGlzLmFwaS5zZXRVc2VySW5mbyA9IChfZGF0YTogSUhlYWRlclVzZXJJbmZvKTogdm9pZCA9PiB7XHJcbiAgICAgICAgICAgICg8YW55Pk9iamVjdCkuYXNzaWduKHRoaXMuaGVhZGVyLnVzZXJJbmZvLCBfZGF0YSk7XHJcbiAgICAgICAgICAgIC8vIHRoaXMuY2RyLmRldGVjdENoYW5nZXMoKTtcclxuXHJcbiAgICAgICAgICAgIGlmICh0eXBlb2YgdGhpcy5oZWFkZXIudXNlckluZm8gIT09ICd1bmRlZmluZWQnICYmIHR5cGVvZiB0aGlzLmhlYWRlci51c2VySW5mby5pbWdTcmMgPT09ICd1bmRlZmluZWQnKSB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLmhlYWRlci51c2VySW5mby5pbWdUeXBlID0gJ2ljb24nO1xyXG4gICAgICAgICAgICAgICAgdGhpcy5oZWFkZXIudXNlckluZm8uaW1nU3JjID0gJ2tkLXJvbGUnO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfTtcclxuXHJcbiAgICAgICAgdGhpcy5hcGkuc2V0R3JvdXBCdXR0b24gPSAoX2luZGV4OiBudW1iZXIsIF9idXR0b246IElIZWFkZXJCdXR0b24pOiB2b2lkID0+IHtcclxuICAgICAgICAgICAgaWYgKHRoaXMuaGVhZGVyLmJ0bkdyb3VwLmxlbmd0aCA+IDAgJiYgX2luZGV4IDw9IDIpIHtcclxuICAgICAgICAgICAgICAgIHRoaXMuaGVhZGVyLmJ0bkdyb3VwW19pbmRleF0gPSBfYnV0dG9uO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfTtcclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF9zZXR1cEhlYWRlckNvbmZpZygpOiB2b2lkIHtcclxuICAgICAgICBpZiAodHlwZW9mIHRoaXMuY29uZmlnICE9PSAndW5kZWZpbmVkJykge1xyXG4gICAgICAgICAgICBsZXQgZGVmYXVsdEhlYWRlcjogSUhlYWRlckNvbmZpZyA9IHRoaXMuX2hlYWRlclN2Yy5nZXREZWZhdWx0Q29uZmlnKCk7XHJcbiAgICAgICAgICAgIGxldCB0ZW1wSGVhZGVyOiBJSGVhZGVyQ29uZmlnID0gdGhpcy5fZGF0YVN2Yy5kZWVwTWVyZ2VPYmplY3QoZGVmYXVsdEhlYWRlciwgdGhpcy5jb25maWcpO1xyXG5cclxuICAgICAgICAgICAgdHJ5IHtcclxuICAgICAgICAgICAgICAgIC8vIHdpbGwgdHJ5IHRvIGZldGNoIEFQUF9DT05GSUdTIGZyb20gdGhlIGZpbGUuXHJcbiAgICAgICAgICAgICAgICB0ZW1wSGVhZGVyLmJyYW5kTG9nbyA9ICg8YW55Pk9iamVjdCkuYXNzaWduKHRlbXBIZWFkZXIuYnJhbmRMb2dvLCBBUFBfQ09ORklHUy5wcm9kdWN0KTtcclxuICAgICAgICAgICAgfSBjYXRjaCAoZXJyKSB7XHJcbiAgICAgICAgICAgICAgICAvLyBjb25zb2xlLmxvZyhlcnIpO1xyXG4gICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICBpZiAodHlwZW9mIHRlbXBIZWFkZXIudXNlckluZm8gIT09ICd1bmRlZmluZWQnICYmIHR5cGVvZiB0ZW1wSGVhZGVyLnVzZXJJbmZvLmltZ1NyYyA9PT0gJ3VuZGVmaW5lZCcpIHtcclxuICAgICAgICAgICAgICAgIHRlbXBIZWFkZXIudXNlckluZm8uaW1nVHlwZSA9ICdpY29uJztcclxuICAgICAgICAgICAgICAgIHRlbXBIZWFkZXIudXNlckluZm8uaW1nU3JjID0gJ2tkLXJvbGUnO1xyXG4gICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICB0aGlzLmhlYWRlciA9IHRlbXBIZWFkZXI7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG59XHJcblxyXG50eXBlIEFueUR1cmluZ1JlbmRlcmVyTWlncmF0aW9uID0gYW55O1xyXG5cclxuZnVuY3Rpb24gX19uZ1JlbmRlcmVyU3BsaXROYW1lc3BhY2VIZWxwZXIobmFtZTogQW55RHVyaW5nUmVuZGVyZXJNaWdyYXRpb24pIHtcclxuICAgIGlmIChuYW1lWzBdID09PSBcIjpcIikge1xyXG4gICAgICAgIGNvbnN0IG1hdGNoID0gbmFtZS5tYXRjaCgvXjooW146XSspOiguKykkLyk7XHJcbiAgICAgICAgcmV0dXJuIFttYXRjaFsxXSwgbWF0Y2hbMl1dO1xyXG4gICAgfVxyXG4gICAgcmV0dXJuIFtcIlwiLCBuYW1lXTtcclxufVxyXG5cclxuZnVuY3Rpb24gX19uZ1JlbmRlcmVyU2V0RWxlbWVudEF0dHJpYnV0ZUhlbHBlcihyZW5kZXJlcjogQW55RHVyaW5nUmVuZGVyZXJNaWdyYXRpb24sIGVsZW1lbnQ6IEFueUR1cmluZ1JlbmRlcmVyTWlncmF0aW9uLCBuYW1lc3BhY2VBbmROYW1lOiBBbnlEdXJpbmdSZW5kZXJlck1pZ3JhdGlvbiwgdmFsdWU/OiBBbnlEdXJpbmdSZW5kZXJlck1pZ3JhdGlvbikge1xyXG4gICAgY29uc3QgW25hbWVzcGFjZSwgbmFtZV0gPSBfX25nUmVuZGVyZXJTcGxpdE5hbWVzcGFjZUhlbHBlcihuYW1lc3BhY2VBbmROYW1lKTtcclxuICAgIGlmICh2YWx1ZSAhPSBudWxsKSB7XHJcbiAgICAgICAgcmVuZGVyZXIuc2V0QXR0cmlidXRlKGVsZW1lbnQsIG5hbWUsIHZhbHVlLCBuYW1lc3BhY2UpO1xyXG4gICAgfVxyXG4gICAgZWxzZSB7XHJcbiAgICAgICAgcmVuZGVyZXIucmVtb3ZlQXR0cmlidXRlKGVsZW1lbnQsIG5hbWUsIG5hbWVzcGFjZSk7XHJcbiAgICB9XHJcbn1cclxuIl19