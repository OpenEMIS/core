import { __decorate, __metadata } from "tslib";
import { timer as observableTimer, fromEvent } from 'rxjs';
import { debounceTime } from 'rxjs/operators';
/*******************************************************************************
    Component file     : kd-angular-pageheader.ts
    Service file       : kd-angular-pageheader-svc.ts
    Event file         : -
    Interface file     : kd-angular-pageheader-interface.ts
    Version            : 2.0
    Created by         : Cheng Kok Keong
    Purpose            : Show the title of the current page in the template area under breadcrumb

    Behaviour           :
        - Behaviour for page title element:
            --------------------------------------------------------------------------
            | Case | Left buttons | Search button | More button | Width              |
            --------------------------------------------------------------------------
            |  Left buttons                                                          |
            |      | (/)          | (/)           | (/)         | 200px              |
            |      | (/)          | (/)           | (x)         | 200px              |
            |      | (/)          | (x)           | (/)         | 200px              |
            |      | (/)          | (x)           | (x)         | 200px              |
            --------------------------------------------------------------------------
            |  Search buttons                                                        |
            |      | (x)          | (/)           | (/)         | calc(100% - 340px) |
            |      | (x)          | (/)           | (x)         | calc(100% - 300px) |
            --------------------------------------------------------------------------
            |  More buttons                                                          |
            |      | (x)          | (x)           | (/)         | calc(100% - 40px)  |
            --------------------------------------------------------------------------
            |  No buttons                                                            |
            |      | (x)          | (x)           | (x)         | 100%               |
            --------------------------------------------------------------------------

    Last change         :
        - Rewrite component and service

 *******************************************************************************/
import { Component, OnInit, AfterViewInit, OnChanges, SimpleChanges, OnDestroy, Input, ViewEncapsulation, HostBinding, ViewContainerRef, } from '@angular/core';
import { KdPageheaderSvc } from './kd-angular-pageheader-svc';
import { DELAY_TIME } from '../kd-common/index';
var KdPageheader = /** @class */ (function () {
    function KdPageheader(_vcr, _pageheaderSvc) {
        this._vcr = _vcr;
        this._pageheaderSvc = _pageheaderSvc;
        this.toolbarExist = false;
        this.expendTitle = false;
        this.toggleTransition = false;
        this.titleClickable = false;
        this.checkTitleComplete = false;
        this.hideToolbar = false;
        this._subscriptionObj = {};
        this.hasLeftBtns = false;
        this.hasSearchBtn = false;
        this.hasMoreBtn = false;
        this.mobileView = false;
    }
    /************************* Life cycles functions *****************************/
    KdPageheader.prototype.ngOnInit = function () {
        // console.log('-- Pageheader Component: OnInit --', this.config);
        this._setTransitionTo(false);
        this._setupObservableEvents();
        this._processConfigCycle();
        this._generateApi(this.api, this.config);
    };
    KdPageheader.prototype.ngOnChanges = function (_simpleChanges) {
        // console.log('-- Pageheader Component: OnChanges --', _simpleChanges);
        if (_simpleChanges.hasOwnProperty('config') && !_simpleChanges['config'].firstChange) {
            this._processConfigCycle();
            this._updateDOMCycle(DELAY_TIME);
        }
    };
    KdPageheader.prototype.ngAfterViewInit = function () {
        // console.log('-- Pageheader Component: AfterViewInit --');
        this._updateDOMCycle();
    };
    KdPageheader.prototype.ngOnDestroy = function () {
        // console.log('-- Pageheader Component: OnDestroy --');
        for (var subObject in this._subscriptionObj) {
            if (this._subscriptionObj.hasOwnProperty(subObject)) {
                this._subscriptionObj[subObject].unsubscribe();
            }
        }
    };
    /**************************** Events functions *******************************/
    KdPageheader.prototype.titleClicked = function (_event) {
        if (this.mobileView || !this.titleClickable)
            return;
        this.expendTitle = !this.expendTitle;
    };
    KdPageheader.prototype.updateSearchText = function (_searchText) {
        this.config.searchText = _searchText;
    };
    /**************************** Private functions ******************************/
    ///////////////////////////////////////////////////////
    /// Cycle events
    ///////////////////////////////////////////////////////
    KdPageheader.prototype._processConfigCycle = function () {
        if (typeof this.config === 'undefined') {
            this.config = {};
        }
        this.toolbarConfig = this._pageheaderSvc.updateToolbarConfig(this.config);
        this._updateToolbarExist();
        this._updateHostBinding();
    };
    KdPageheader.prototype._updateDOMCycle = function (_delayTime) {
        var _this = this;
        if (_delayTime === void 0) { _delayTime = 1; }
        observableTimer().subscribe(function () {
            _this._updateViewClass();
            _this._updateClickableCycle(_delayTime);
        });
    };
    KdPageheader.prototype._updateClickableCycle = function (_delayTime) {
        if (_delayTime === void 0) { _delayTime = 1; }
        if (this._subscriptionObj.hasOwnProperty('timer')) {
            this._subscriptionObj['timer'].unsubscribe();
        }
        this.checkTitleComplete = false;
        this._setTitleClickable(_delayTime);
    };
    ///////////////////////////////////////////////////////
    /// DOM Cycle function
    ///////////////////////////////////////////////////////
    KdPageheader.prototype._setupObservableEvents = function () {
        var _this = this;
        this._subscriptionObj['resize'] = fromEvent(window, 'resize')
            .pipe(debounceTime(DELAY_TIME))
            .subscribe(function (_event) {
            _this._updateDOMCycle();
        });
    };
    KdPageheader.prototype._updateViewClass = function () {
        this.mobileView = window.innerWidth <= 1024;
        if (this.mobileView) {
            this.expendTitle = false;
        }
    };
    KdPageheader.prototype._setTransitionTo = function (_toggle) {
        this.toggleTransition = _toggle;
    };
    KdPageheader.prototype._setTitleClickable = function (_delay) {
        var _this = this;
        this._subscriptionObj['timer'] = observableTimer(_delay)
            .subscribe(function () {
            var titleElement = _this._vcr.element.nativeElement.querySelector('.title');
            var actualElement = _this._vcr.element.nativeElement.querySelector('#heightCheck');
            if (titleElement !== null && actualElement !== null) {
                _this.titleClickable = titleElement.getBoundingClientRect().width < actualElement.getBoundingClientRect().width;
            }
            else {
                _this.titleClickable = false;
            }
            _this._setTransitionTo(true);
            _this.checkTitleComplete = true;
        });
    };
    KdPageheader.prototype._updateHostBinding = function () {
        this.hasLeftBtns = this.toolbarConfig.leftBtn.length > 0;
        this.hasMoreBtn = this.toolbarConfig.moreAction.length > 0;
        this.hasSearchBtn = this.toolbarConfig.searchBtn;
    };
    ///////////////////////////////////////////////////////
    /// API Generation
    ///////////////////////////////////////////////////////
    KdPageheader.prototype._generateApi = function (_api, _config) {
        var _this = this;
        if (typeof _api !== 'undefined') {
            _api.updateTitle = function (_newTitle) {
                if (_newTitle === void 0) { _newTitle = ''; }
                _config.pageheaderText = _newTitle;
                _this._updateClickableCycle();
            };
            _api.updateLeftButton = function (_newLeftBtn) {
                _this._setTransitionTo(false);
                _this.config.leftBtn = _newLeftBtn;
                _this._processConfigCycle();
                _this._updateClickableCycle(DELAY_TIME);
            };
            _api.updateMoreButton = function (_enabled, _list) {
                _this._setTransitionTo(false);
                _this.config.moreBtn = _enabled;
                _this.config.moreAction = _list;
                _this._processConfigCycle();
                _this._updateClickableCycle(DELAY_TIME);
            };
            _api.updateSearchButton = function (_searchConfig) {
                _this._setTransitionTo(false);
                _this.config = Object.assign(_this.config, _searchConfig);
                _this._processConfigCycle();
                _this._updateClickableCycle(DELAY_TIME);
            };
        }
        else {
            console.warn('KdPageheader warning: No api is passed in.');
        }
    };
    ///////////////////////////////////////////////////////
    /// Config functions
    ///////////////////////////////////////////////////////
    KdPageheader.prototype._updateToolbarExist = function () {
        this.toolbarExist = this._pageheaderSvc.isToolbarExist(this.config);
    };
    KdPageheader.ctorParameters = function () { return [
        { type: ViewContainerRef },
        { type: KdPageheaderSvc }
    ]; };
    __decorate([
        Input(),
        __metadata("design:type", Object)
    ], KdPageheader.prototype, "config", void 0);
    __decorate([
        Input(),
        __metadata("design:type", Object)
    ], KdPageheader.prototype, "api", void 0);
    __decorate([
        HostBinding('class.has-left-btn'),
        __metadata("design:type", Boolean)
    ], KdPageheader.prototype, "hasLeftBtns", void 0);
    __decorate([
        HostBinding('class.has-search-btn'),
        __metadata("design:type", Boolean)
    ], KdPageheader.prototype, "hasSearchBtn", void 0);
    __decorate([
        HostBinding('class.has-more-btn'),
        __metadata("design:type", Boolean)
    ], KdPageheader.prototype, "hasMoreBtn", void 0);
    __decorate([
        HostBinding('class.pageheader-mobile'),
        __metadata("design:type", Boolean)
    ], KdPageheader.prototype, "mobileView", void 0);
    KdPageheader = __decorate([
        Component({
            selector: 'kd-pageheader',
            template: "<div class='kdx-page-header'>\r\n    <div class='title' \r\n        [ngClass]=\" {\r\n            'expend-title': expendTitle && titleClickable,\r\n            'collapse-title': !expendTitle && titleClickable,\r\n            'animation': toggleTransition \r\n        }\" (click)='titleClicked($event)'>\r\n            <h2 class='page-title'>{{config.pageheaderText}}</h2>\r\n            <i class=\"arrow-icon\"></i>\r\n    </div>\r\n    <ng-template [ngIf]='toolbarExist'>\r\n        <kd-toolbar \r\n            class='page-toolbar'\r\n            [ngClass]=\"{'hide-toolbar': hideToolbar}\"\r\n            [config]='toolbarConfig'\r\n            [mobileView]='mobileView'\r\n            (searchTextChanged)='updateSearchText($event)'\r\n        ></kd-toolbar>\r\n    </ng-template>\r\n</div>\r\n<h2 *ngIf=\"!checkTitleComplete\" id='heightCheck' style=\"position: absolute; z-index: -1;\">{{config.pageheaderText}}</h2>\r\n",
            encapsulation: ViewEncapsulation.None,
            providers: [KdPageheaderSvc]
        }),
        __metadata("design:paramtypes", [ViewContainerRef,
            KdPageheaderSvc])
    ], KdPageheader);
    return KdPageheader;
}());
export { KdPageheader };
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoia2QtYW5ndWxhci1wYWdlaGVhZGVyLmpzIiwic291cmNlUm9vdCI6Im5nOi8vb3BlbmVtaXMtc3R5bGVndWlkZS1saWIvIiwic291cmNlcyI6WyJrZC1jb21wb25lbnRzL2tkLWFuZ3VsYXItcGFnZWhlYWRlci9rZC1hbmd1bGFyLXBhZ2VoZWFkZXIudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IjtBQUNBLE9BQU8sRUFBRSxLQUFLLElBQUksZUFBZSxFQUFnQixTQUFTLEVBQUUsTUFBTSxNQUFNLENBQUM7QUFDekUsT0FBTyxFQUFFLFlBQVksRUFBRSxNQUFNLGdCQUFnQixDQUFDO0FBQzlDOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O2lGQWtDaUY7QUFJakYsT0FBTyxFQUNILFNBQVMsRUFDVCxNQUFNLEVBQ04sYUFBYSxFQUNiLFNBQVMsRUFDVCxhQUFhLEVBQ2IsU0FBUyxFQUNULEtBQUssRUFDTCxpQkFBaUIsRUFDakIsV0FBVyxFQUNYLGdCQUFnQixHQUNuQixNQUFNLGVBQWUsQ0FBQztBQUN2QixPQUFPLEVBQUUsZUFBZSxFQUFFLE1BQU0sNkJBQTZCLENBQUM7QUFTOUQsT0FBTyxFQUFFLFVBQVUsRUFBRSxNQUFNLG9CQUFvQixDQUFDO0FBU2hEO0lBa0JJLHNCQUNZLElBQXNCLEVBQ3RCLGNBQStCO1FBRC9CLFNBQUksR0FBSixJQUFJLENBQWtCO1FBQ3RCLG1CQUFjLEdBQWQsY0FBYyxDQUFpQjtRQWxCcEMsaUJBQVksR0FBWSxLQUFLLENBQUM7UUFDOUIsZ0JBQVcsR0FBWSxLQUFLLENBQUM7UUFDN0IscUJBQWdCLEdBQVksS0FBSyxDQUFDO1FBQ2xDLG1CQUFjLEdBQVksS0FBSyxDQUFDO1FBQ2hDLHVCQUFrQixHQUFZLEtBQUssQ0FBQztRQUNwQyxnQkFBVyxHQUFZLEtBQUssQ0FBQztRQUU1QixxQkFBZ0IsR0FBb0MsRUFBRSxDQUFDO1FBSTVCLGdCQUFXLEdBQVksS0FBSyxDQUFDO1FBQzNCLGlCQUFZLEdBQVksS0FBSyxDQUFDO1FBQ2hDLGVBQVUsR0FBWSxLQUFLLENBQUM7UUFDdkIsZUFBVSxHQUFZLEtBQUssQ0FBQztJQUtoRSxDQUFDO0lBRUwsK0VBQStFO0lBQy9FLCtCQUFRLEdBQVI7UUFDSSxrRUFBa0U7UUFDbEUsSUFBSSxDQUFDLGdCQUFnQixDQUFDLEtBQUssQ0FBQyxDQUFDO1FBQzdCLElBQUksQ0FBQyxzQkFBc0IsRUFBRSxDQUFDO1FBQzlCLElBQUksQ0FBQyxtQkFBbUIsRUFBRSxDQUFDO1FBQzNCLElBQUksQ0FBQyxZQUFZLENBQUMsSUFBSSxDQUFDLEdBQUcsRUFBRSxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUM7SUFDN0MsQ0FBQztJQUVELGtDQUFXLEdBQVgsVUFBWSxjQUE2QjtRQUNyQyx3RUFBd0U7UUFDeEUsSUFBSSxjQUFjLENBQUMsY0FBYyxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsY0FBYyxDQUFDLFFBQVEsQ0FBQyxDQUFDLFdBQVcsRUFBRTtZQUNsRixJQUFJLENBQUMsbUJBQW1CLEVBQUUsQ0FBQztZQUMzQixJQUFJLENBQUMsZUFBZSxDQUFDLFVBQVUsQ0FBQyxDQUFDO1NBQ3BDO0lBQ0wsQ0FBQztJQUVELHNDQUFlLEdBQWY7UUFDSSw0REFBNEQ7UUFDNUQsSUFBSSxDQUFDLGVBQWUsRUFBRSxDQUFDO0lBQzNCLENBQUM7SUFFRCxrQ0FBVyxHQUFYO1FBQ0ksd0RBQXdEO1FBQ3hELEtBQUssSUFBSSxTQUFTLElBQUksSUFBSSxDQUFDLGdCQUFnQixFQUFFO1lBQ3pDLElBQUksSUFBSSxDQUFDLGdCQUFnQixDQUFDLGNBQWMsQ0FBQyxTQUFTLENBQUMsRUFBRTtnQkFDakQsSUFBSSxDQUFDLGdCQUFnQixDQUFDLFNBQVMsQ0FBQyxDQUFDLFdBQVcsRUFBRSxDQUFDO2FBQ2xEO1NBQ0o7SUFDTCxDQUFDO0lBRUQsK0VBQStFO0lBQ3hFLG1DQUFZLEdBQW5CLFVBQW9CLE1BQWE7UUFDN0IsSUFBSSxJQUFJLENBQUMsVUFBVSxJQUFJLENBQUMsSUFBSSxDQUFDLGNBQWM7WUFBRSxPQUFPO1FBRXBELElBQUksQ0FBQyxXQUFXLEdBQUcsQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFDO0lBQ3pDLENBQUM7SUFFTSx1Q0FBZ0IsR0FBdkIsVUFBd0IsV0FBbUI7UUFDdkMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxVQUFVLEdBQUcsV0FBVyxDQUFDO0lBQ3pDLENBQUM7SUFFRCwrRUFBK0U7SUFDL0UsdURBQXVEO0lBQ3ZELGdCQUFnQjtJQUNoQix1REFBdUQ7SUFDL0MsMENBQW1CLEdBQTNCO1FBQ0ksSUFBSSxPQUFPLElBQUksQ0FBQyxNQUFNLEtBQUssV0FBVyxFQUFFO1lBQ3BDLElBQUksQ0FBQyxNQUFNLEdBQUcsRUFBRSxDQUFDO1NBQ3BCO1FBRUQsSUFBSSxDQUFDLGFBQWEsR0FBRyxJQUFJLENBQUMsY0FBYyxDQUFDLG1CQUFtQixDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQztRQUMxRSxJQUFJLENBQUMsbUJBQW1CLEVBQUUsQ0FBQztRQUMzQixJQUFJLENBQUMsa0JBQWtCLEVBQUUsQ0FBQztJQUM5QixDQUFDO0lBRU8sc0NBQWUsR0FBdkIsVUFBd0IsVUFBc0I7UUFBOUMsaUJBS0M7UUFMdUIsMkJBQUEsRUFBQSxjQUFzQjtRQUMxQyxlQUFlLEVBQUUsQ0FBQyxTQUFTLENBQUM7WUFDeEIsS0FBSSxDQUFDLGdCQUFnQixFQUFFLENBQUM7WUFDeEIsS0FBSSxDQUFDLHFCQUFxQixDQUFDLFVBQVUsQ0FBQyxDQUFDO1FBQzNDLENBQUMsQ0FBQyxDQUFDO0lBQ1AsQ0FBQztJQUVPLDRDQUFxQixHQUE3QixVQUE4QixVQUFzQjtRQUF0QiwyQkFBQSxFQUFBLGNBQXNCO1FBQ2hELElBQUksSUFBSSxDQUFDLGdCQUFnQixDQUFDLGNBQWMsQ0FBQyxPQUFPLENBQUMsRUFBRTtZQUMvQyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsT0FBTyxDQUFDLENBQUMsV0FBVyxFQUFFLENBQUM7U0FDaEQ7UUFFRCxJQUFJLENBQUMsa0JBQWtCLEdBQUcsS0FBSyxDQUFDO1FBQ2hDLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxVQUFVLENBQUMsQ0FBQztJQUN4QyxDQUFDO0lBRUQsdURBQXVEO0lBQ3ZELHNCQUFzQjtJQUN0Qix1REFBdUQ7SUFDL0MsNkNBQXNCLEdBQTlCO1FBQUEsaUJBVUM7UUFURyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsUUFBUSxDQUFDLEdBQUcsU0FBUyxDQUFDLE1BQU0sRUFBRSxRQUFRLENBQUM7YUFDeEQsSUFBSSxDQUNELFlBQVksQ0FBQyxVQUFVLENBQUMsQ0FDM0I7YUFDQSxTQUFTLENBQ04sVUFBQyxNQUFhO1lBQ1YsS0FBSSxDQUFDLGVBQWUsRUFBRSxDQUFDO1FBQzNCLENBQUMsQ0FDSixDQUFDO0lBQ1YsQ0FBQztJQUVPLHVDQUFnQixHQUF4QjtRQUNJLElBQUksQ0FBQyxVQUFVLEdBQUcsTUFBTSxDQUFDLFVBQVUsSUFBSSxJQUFJLENBQUM7UUFFNUMsSUFBSSxJQUFJLENBQUMsVUFBVSxFQUFFO1lBQ2pCLElBQUksQ0FBQyxXQUFXLEdBQUcsS0FBSyxDQUFDO1NBQzVCO0lBQ0wsQ0FBQztJQUVPLHVDQUFnQixHQUF4QixVQUF5QixPQUFnQjtRQUNyQyxJQUFJLENBQUMsZ0JBQWdCLEdBQUcsT0FBTyxDQUFDO0lBQ3BDLENBQUM7SUFFTyx5Q0FBa0IsR0FBMUIsVUFBMkIsTUFBYztRQUF6QyxpQkFrQkM7UUFqQkcsSUFBSSxDQUFDLGdCQUFnQixDQUFDLE9BQU8sQ0FBQyxHQUFHLGVBQWUsQ0FBQyxNQUFNLENBQUM7YUFDbkQsU0FBUyxDQUNOO1lBQ0ksSUFBSSxZQUFZLEdBQVksS0FBSSxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsYUFBYSxDQUFDLGFBQWEsQ0FBQyxRQUFRLENBQUMsQ0FBQztZQUNwRixJQUFJLGFBQWEsR0FBWSxLQUFJLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxhQUFhLENBQUMsYUFBYSxDQUFDLGNBQWMsQ0FBQyxDQUFDO1lBRTNGLElBQUksWUFBWSxLQUFLLElBQUksSUFBSSxhQUFhLEtBQUssSUFBSSxFQUFFO2dCQUNqRCxLQUFJLENBQUMsY0FBYyxHQUFHLFlBQVksQ0FBQyxxQkFBcUIsRUFBRSxDQUFDLEtBQUssR0FBRyxhQUFhLENBQUMscUJBQXFCLEVBQUUsQ0FBQyxLQUFLLENBQUM7YUFDbEg7aUJBQ0k7Z0JBQ0QsS0FBSSxDQUFDLGNBQWMsR0FBRyxLQUFLLENBQUM7YUFDL0I7WUFFRCxLQUFJLENBQUMsZ0JBQWdCLENBQUMsSUFBSSxDQUFDLENBQUM7WUFDNUIsS0FBSSxDQUFDLGtCQUFrQixHQUFHLElBQUksQ0FBQztRQUNuQyxDQUFDLENBQ0osQ0FBQztJQUNWLENBQUM7SUFFTyx5Q0FBa0IsR0FBMUI7UUFDSSxJQUFJLENBQUMsV0FBVyxHQUFHLElBQUksQ0FBQyxhQUFhLENBQUMsT0FBTyxDQUFDLE1BQU0sR0FBRyxDQUFDLENBQUM7UUFDekQsSUFBSSxDQUFDLFVBQVUsR0FBRyxJQUFJLENBQUMsYUFBYSxDQUFDLFVBQVUsQ0FBQyxNQUFNLEdBQUcsQ0FBQyxDQUFDO1FBQzNELElBQUksQ0FBQyxZQUFZLEdBQUcsSUFBSSxDQUFDLGFBQWEsQ0FBQyxTQUFTLENBQUM7SUFDckQsQ0FBQztJQUVELHVEQUF1RDtJQUN2RCxrQkFBa0I7SUFDbEIsdURBQXVEO0lBQy9DLG1DQUFZLEdBQXBCLFVBQXFCLElBQW9CLEVBQUUsT0FBMEI7UUFBckUsaUJBZ0NDO1FBL0JHLElBQUksT0FBTyxJQUFJLEtBQUssV0FBVyxFQUFFO1lBQzdCLElBQUksQ0FBQyxXQUFXLEdBQUcsVUFBQyxTQUFzQjtnQkFBdEIsMEJBQUEsRUFBQSxjQUFzQjtnQkFDdEMsT0FBTyxDQUFDLGNBQWMsR0FBRyxTQUFTLENBQUM7Z0JBQ25DLEtBQUksQ0FBQyxxQkFBcUIsRUFBRSxDQUFDO1lBQ2pDLENBQUMsQ0FBQztZQUVGLElBQUksQ0FBQyxnQkFBZ0IsR0FBRyxVQUFDLFdBQW1DO2dCQUN4RCxLQUFJLENBQUMsZ0JBQWdCLENBQUMsS0FBSyxDQUFDLENBQUM7Z0JBQzdCLEtBQUksQ0FBQyxNQUFNLENBQUMsT0FBTyxHQUFHLFdBQVcsQ0FBQztnQkFDbEMsS0FBSSxDQUFDLG1CQUFtQixFQUFFLENBQUM7Z0JBQzNCLEtBQUksQ0FBQyxxQkFBcUIsQ0FBQyxVQUFVLENBQUMsQ0FBQztZQUMzQyxDQUFDLENBQUM7WUFFRixJQUFJLENBQUMsZ0JBQWdCLEdBQUcsVUFBQyxRQUFpQixFQUFFLEtBQWdDO2dCQUN4RSxLQUFJLENBQUMsZ0JBQWdCLENBQUMsS0FBSyxDQUFDLENBQUM7Z0JBQzdCLEtBQUksQ0FBQyxNQUFNLENBQUMsT0FBTyxHQUFHLFFBQVEsQ0FBQztnQkFDL0IsS0FBSSxDQUFDLE1BQU0sQ0FBQyxVQUFVLEdBQUcsS0FBSyxDQUFDO2dCQUMvQixLQUFJLENBQUMsbUJBQW1CLEVBQUUsQ0FBQztnQkFDM0IsS0FBSSxDQUFDLHFCQUFxQixDQUFDLFVBQVUsQ0FBQyxDQUFDO1lBQzNDLENBQUMsQ0FBQztZQUVGLElBQUksQ0FBQyxrQkFBa0IsR0FBRyxVQUFDLGFBQW9DO2dCQUMzRCxLQUFJLENBQUMsZ0JBQWdCLENBQUMsS0FBSyxDQUFDLENBQUM7Z0JBQzdCLEtBQUksQ0FBQyxNQUFNLEdBQUcsTUFBTSxDQUFDLE1BQU0sQ0FBNkMsS0FBSSxDQUFDLE1BQU0sRUFBRSxhQUFhLENBQUMsQ0FBQztnQkFDcEcsS0FBSSxDQUFDLG1CQUFtQixFQUFFLENBQUM7Z0JBQzNCLEtBQUksQ0FBQyxxQkFBcUIsQ0FBQyxVQUFVLENBQUMsQ0FBQztZQUMzQyxDQUFDLENBQUM7U0FDTDthQUNJO1lBQ0QsT0FBTyxDQUFDLElBQUksQ0FBQyw0Q0FBNEMsQ0FBQyxDQUFDO1NBQzlEO0lBQ0wsQ0FBQztJQUVELHVEQUF1RDtJQUN2RCxvQkFBb0I7SUFDcEIsdURBQXVEO0lBQy9DLDBDQUFtQixHQUEzQjtRQUNJLElBQUksQ0FBQyxZQUFZLEdBQUcsSUFBSSxDQUFDLGNBQWMsQ0FBQyxjQUFjLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDO0lBQ3hFLENBQUM7O2dCQTNLaUIsZ0JBQWdCO2dCQUNOLGVBQWU7O0lBVGxDO1FBQVIsS0FBSyxFQUFFOztnREFBMkI7SUFDMUI7UUFBUixLQUFLLEVBQUU7OzZDQUFxQjtJQUNNO1FBQWxDLFdBQVcsQ0FBQyxvQkFBb0IsQ0FBQzs7cURBQThCO0lBQzNCO1FBQXBDLFdBQVcsQ0FBQyxzQkFBc0IsQ0FBQzs7c0RBQStCO0lBQ2hDO1FBQWxDLFdBQVcsQ0FBQyxvQkFBb0IsQ0FBQzs7b0RBQTZCO0lBQ3ZCO1FBQXZDLFdBQVcsQ0FBQyx5QkFBeUIsQ0FBQzs7b0RBQTZCO0lBaEIzRCxZQUFZO1FBUHhCLFNBQVMsQ0FBQztZQUNQLFFBQVEsRUFBRSxlQUFlO1lBQ3pCLHc2QkFBMkM7WUFDM0MsYUFBYSxFQUFFLGlCQUFpQixDQUFDLElBQUk7WUFDckMsU0FBUyxFQUFFLENBQUMsZUFBZSxDQUFDO1NBQy9CLENBQUM7eUNBcUJvQixnQkFBZ0I7WUFDTixlQUFlO09BcEJsQyxZQUFZLENBK0x4QjtJQUFELG1CQUFDO0NBQUEsQUEvTEQsSUErTEM7U0EvTFksWUFBWSIsInNvdXJjZXNDb250ZW50IjpbIlxyXG5pbXBvcnQgeyB0aW1lciBhcyBvYnNlcnZhYmxlVGltZXIsIFN1YnNjcmlwdGlvbiwgZnJvbUV2ZW50IH0gZnJvbSAncnhqcyc7XHJcbmltcG9ydCB7IGRlYm91bmNlVGltZSB9IGZyb20gJ3J4anMvb3BlcmF0b3JzJztcclxuLyoqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKipcclxuICAgIENvbXBvbmVudCBmaWxlICAgICA6IGtkLWFuZ3VsYXItcGFnZWhlYWRlci50c1xyXG4gICAgU2VydmljZSBmaWxlICAgICAgIDoga2QtYW5ndWxhci1wYWdlaGVhZGVyLXN2Yy50c1xyXG4gICAgRXZlbnQgZmlsZSAgICAgICAgIDogLVxyXG4gICAgSW50ZXJmYWNlIGZpbGUgICAgIDoga2QtYW5ndWxhci1wYWdlaGVhZGVyLWludGVyZmFjZS50c1xyXG4gICAgVmVyc2lvbiAgICAgICAgICAgIDogMi4wXHJcbiAgICBDcmVhdGVkIGJ5ICAgICAgICAgOiBDaGVuZyBLb2sgS2VvbmdcclxuICAgIFB1cnBvc2UgICAgICAgICAgICA6IFNob3cgdGhlIHRpdGxlIG9mIHRoZSBjdXJyZW50IHBhZ2UgaW4gdGhlIHRlbXBsYXRlIGFyZWEgdW5kZXIgYnJlYWRjcnVtYlxyXG5cclxuICAgIEJlaGF2aW91ciAgICAgICAgICAgOlxyXG4gICAgICAgIC0gQmVoYXZpb3VyIGZvciBwYWdlIHRpdGxlIGVsZW1lbnQ6XHJcbiAgICAgICAgICAgIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXHJcbiAgICAgICAgICAgIHwgQ2FzZSB8IExlZnQgYnV0dG9ucyB8IFNlYXJjaCBidXR0b24gfCBNb3JlIGJ1dHRvbiB8IFdpZHRoICAgICAgICAgICAgICB8XHJcbiAgICAgICAgICAgIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXHJcbiAgICAgICAgICAgIHwgIExlZnQgYnV0dG9ucyAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB8XHJcbiAgICAgICAgICAgIHwgICAgICB8ICgvKSAgICAgICAgICB8ICgvKSAgICAgICAgICAgfCAoLykgICAgICAgICB8IDIwMHB4ICAgICAgICAgICAgICB8XHJcbiAgICAgICAgICAgIHwgICAgICB8ICgvKSAgICAgICAgICB8ICgvKSAgICAgICAgICAgfCAoeCkgICAgICAgICB8IDIwMHB4ICAgICAgICAgICAgICB8XHJcbiAgICAgICAgICAgIHwgICAgICB8ICgvKSAgICAgICAgICB8ICh4KSAgICAgICAgICAgfCAoLykgICAgICAgICB8IDIwMHB4ICAgICAgICAgICAgICB8XHJcbiAgICAgICAgICAgIHwgICAgICB8ICgvKSAgICAgICAgICB8ICh4KSAgICAgICAgICAgfCAoeCkgICAgICAgICB8IDIwMHB4ICAgICAgICAgICAgICB8XHJcbiAgICAgICAgICAgIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXHJcbiAgICAgICAgICAgIHwgIFNlYXJjaCBidXR0b25zICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB8XHJcbiAgICAgICAgICAgIHwgICAgICB8ICh4KSAgICAgICAgICB8ICgvKSAgICAgICAgICAgfCAoLykgICAgICAgICB8IGNhbGMoMTAwJSAtIDM0MHB4KSB8XHJcbiAgICAgICAgICAgIHwgICAgICB8ICh4KSAgICAgICAgICB8ICgvKSAgICAgICAgICAgfCAoeCkgICAgICAgICB8IGNhbGMoMTAwJSAtIDMwMHB4KSB8XHJcbiAgICAgICAgICAgIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXHJcbiAgICAgICAgICAgIHwgIE1vcmUgYnV0dG9ucyAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB8XHJcbiAgICAgICAgICAgIHwgICAgICB8ICh4KSAgICAgICAgICB8ICh4KSAgICAgICAgICAgfCAoLykgICAgICAgICB8IGNhbGMoMTAwJSAtIDQwcHgpICB8XHJcbiAgICAgICAgICAgIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXHJcbiAgICAgICAgICAgIHwgIE5vIGJ1dHRvbnMgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB8XHJcbiAgICAgICAgICAgIHwgICAgICB8ICh4KSAgICAgICAgICB8ICh4KSAgICAgICAgICAgfCAoeCkgICAgICAgICB8IDEwMCUgICAgICAgICAgICAgICB8XHJcbiAgICAgICAgICAgIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXHJcblxyXG4gICAgTGFzdCBjaGFuZ2UgICAgICAgICA6XHJcbiAgICAgICAgLSBSZXdyaXRlIGNvbXBvbmVudCBhbmQgc2VydmljZVxyXG5cclxuICoqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKiovXHJcblxyXG5cclxuXHJcbmltcG9ydCB7XHJcbiAgICBDb21wb25lbnQsXHJcbiAgICBPbkluaXQsXHJcbiAgICBBZnRlclZpZXdJbml0LFxyXG4gICAgT25DaGFuZ2VzLFxyXG4gICAgU2ltcGxlQ2hhbmdlcyxcclxuICAgIE9uRGVzdHJveSxcclxuICAgIElucHV0LFxyXG4gICAgVmlld0VuY2Fwc3VsYXRpb24sXHJcbiAgICBIb3N0QmluZGluZyxcclxuICAgIFZpZXdDb250YWluZXJSZWYsXHJcbn0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XHJcbmltcG9ydCB7IEtkUGFnZWhlYWRlclN2YyB9IGZyb20gJy4va2QtYW5ndWxhci1wYWdlaGVhZGVyLXN2Yyc7XHJcbmltcG9ydCB7XHJcbiAgICBJVG9vbGJhclNlYXJjaENvbmZpZyxcclxuICAgIElUb29sYmFyQ29uZmlnLFxyXG4gICAgSVRvb2xiYXJNb3JlQnV0dG9uLFxyXG4gICAgSVRvb2xiYXJCdXR0b24sXHJcbiAgICBJUGFnZWhlYWRlckNvbmZpZyxcclxuICAgIElQYWdlaGVhZGVyQXBpXHJcbn0gZnJvbSAnLi9rZC1hbmd1bGFyLXBhZ2VoZWFkZXItaW50ZXJmYWNlJztcclxuaW1wb3J0IHsgREVMQVlfVElNRSB9IGZyb20gJy4uL2tkLWNvbW1vbi9pbmRleCc7XHJcblxyXG5AQ29tcG9uZW50KHtcclxuICAgIHNlbGVjdG9yOiAna2QtcGFnZWhlYWRlcicsXHJcbiAgICB0ZW1wbGF0ZVVybDogJy4va2QtYW5ndWxhci1wYWdlaGVhZGVyLmh0bWwnLFxyXG4gICAgZW5jYXBzdWxhdGlvbjogVmlld0VuY2Fwc3VsYXRpb24uTm9uZSxcclxuICAgIHByb3ZpZGVyczogW0tkUGFnZWhlYWRlclN2Y11cclxufSlcclxuXHJcbmV4cG9ydCBjbGFzcyBLZFBhZ2VoZWFkZXIgaW1wbGVtZW50cyBPbkluaXQsIE9uQ2hhbmdlcywgQWZ0ZXJWaWV3SW5pdCwgT25EZXN0cm95IHtcclxuICAgIHB1YmxpYyB0b29sYmFyQ29uZmlnOiBJVG9vbGJhckNvbmZpZztcclxuICAgIHB1YmxpYyB0b29sYmFyRXhpc3Q6IGJvb2xlYW4gPSBmYWxzZTtcclxuICAgIHB1YmxpYyBleHBlbmRUaXRsZTogYm9vbGVhbiA9IGZhbHNlO1xyXG4gICAgcHVibGljIHRvZ2dsZVRyYW5zaXRpb246IGJvb2xlYW4gPSBmYWxzZTtcclxuICAgIHB1YmxpYyB0aXRsZUNsaWNrYWJsZTogYm9vbGVhbiA9IGZhbHNlO1xyXG4gICAgcHVibGljIGNoZWNrVGl0bGVDb21wbGV0ZTogYm9vbGVhbiA9IGZhbHNlO1xyXG4gICAgcHVibGljIGhpZGVUb29sYmFyOiBib29sZWFuID0gZmFsc2U7XHJcblxyXG4gICAgcHJpdmF0ZSBfc3Vic2NyaXB0aW9uT2JqOiB7IFtrZXk6IHN0cmluZ106IFN1YnNjcmlwdGlvbiB9ID0ge307XHJcblxyXG4gICAgQElucHV0KCkgY29uZmlnOiBJUGFnZWhlYWRlckNvbmZpZztcclxuICAgIEBJbnB1dCgpIGFwaTogSVBhZ2VoZWFkZXJBcGk7XHJcbiAgICBASG9zdEJpbmRpbmcoJ2NsYXNzLmhhcy1sZWZ0LWJ0bicpIGhhc0xlZnRCdG5zOiBib29sZWFuID0gZmFsc2U7XHJcbiAgICBASG9zdEJpbmRpbmcoJ2NsYXNzLmhhcy1zZWFyY2gtYnRuJykgaGFzU2VhcmNoQnRuOiBib29sZWFuID0gZmFsc2U7XHJcbiAgICBASG9zdEJpbmRpbmcoJ2NsYXNzLmhhcy1tb3JlLWJ0bicpIGhhc01vcmVCdG46IGJvb2xlYW4gPSBmYWxzZTtcclxuICAgIEBIb3N0QmluZGluZygnY2xhc3MucGFnZWhlYWRlci1tb2JpbGUnKSBtb2JpbGVWaWV3OiBib29sZWFuID0gZmFsc2U7XHJcblxyXG4gICAgY29uc3RydWN0b3IoXHJcbiAgICAgICAgcHJpdmF0ZSBfdmNyOiBWaWV3Q29udGFpbmVyUmVmLFxyXG4gICAgICAgIHByaXZhdGUgX3BhZ2VoZWFkZXJTdmM6IEtkUGFnZWhlYWRlclN2Y1xyXG4gICAgKSB7IH1cclxuXHJcbiAgICAvKioqKioqKioqKioqKioqKioqKioqKioqKiBMaWZlIGN5Y2xlcyBmdW5jdGlvbnMgKioqKioqKioqKioqKioqKioqKioqKioqKioqKiovXHJcbiAgICBuZ09uSW5pdCgpOiB2b2lkIHtcclxuICAgICAgICAvLyBjb25zb2xlLmxvZygnLS0gUGFnZWhlYWRlciBDb21wb25lbnQ6IE9uSW5pdCAtLScsIHRoaXMuY29uZmlnKTtcclxuICAgICAgICB0aGlzLl9zZXRUcmFuc2l0aW9uVG8oZmFsc2UpO1xyXG4gICAgICAgIHRoaXMuX3NldHVwT2JzZXJ2YWJsZUV2ZW50cygpO1xyXG4gICAgICAgIHRoaXMuX3Byb2Nlc3NDb25maWdDeWNsZSgpO1xyXG4gICAgICAgIHRoaXMuX2dlbmVyYXRlQXBpKHRoaXMuYXBpLCB0aGlzLmNvbmZpZyk7XHJcbiAgICB9XHJcblxyXG4gICAgbmdPbkNoYW5nZXMoX3NpbXBsZUNoYW5nZXM6IFNpbXBsZUNoYW5nZXMpOiB2b2lkIHtcclxuICAgICAgICAvLyBjb25zb2xlLmxvZygnLS0gUGFnZWhlYWRlciBDb21wb25lbnQ6IE9uQ2hhbmdlcyAtLScsIF9zaW1wbGVDaGFuZ2VzKTtcclxuICAgICAgICBpZiAoX3NpbXBsZUNoYW5nZXMuaGFzT3duUHJvcGVydHkoJ2NvbmZpZycpICYmICFfc2ltcGxlQ2hhbmdlc1snY29uZmlnJ10uZmlyc3RDaGFuZ2UpIHtcclxuICAgICAgICAgICAgdGhpcy5fcHJvY2Vzc0NvbmZpZ0N5Y2xlKCk7XHJcbiAgICAgICAgICAgIHRoaXMuX3VwZGF0ZURPTUN5Y2xlKERFTEFZX1RJTUUpO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICBuZ0FmdGVyVmlld0luaXQoKTogdm9pZCB7XHJcbiAgICAgICAgLy8gY29uc29sZS5sb2coJy0tIFBhZ2VoZWFkZXIgQ29tcG9uZW50OiBBZnRlclZpZXdJbml0IC0tJyk7XHJcbiAgICAgICAgdGhpcy5fdXBkYXRlRE9NQ3ljbGUoKTtcclxuICAgIH1cclxuXHJcbiAgICBuZ09uRGVzdHJveSgpOiB2b2lkIHtcclxuICAgICAgICAvLyBjb25zb2xlLmxvZygnLS0gUGFnZWhlYWRlciBDb21wb25lbnQ6IE9uRGVzdHJveSAtLScpO1xyXG4gICAgICAgIGZvciAobGV0IHN1Yk9iamVjdCBpbiB0aGlzLl9zdWJzY3JpcHRpb25PYmopIHtcclxuICAgICAgICAgICAgaWYgKHRoaXMuX3N1YnNjcmlwdGlvbk9iai5oYXNPd25Qcm9wZXJ0eShzdWJPYmplY3QpKSB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLl9zdWJzY3JpcHRpb25PYmpbc3ViT2JqZWN0XS51bnN1YnNjcmliZSgpO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIC8qKioqKioqKioqKioqKioqKioqKioqKioqKioqIEV2ZW50cyBmdW5jdGlvbnMgKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKi9cclxuICAgIHB1YmxpYyB0aXRsZUNsaWNrZWQoX2V2ZW50OiBFdmVudCk6IHZvaWQge1xyXG4gICAgICAgIGlmICh0aGlzLm1vYmlsZVZpZXcgfHwgIXRoaXMudGl0bGVDbGlja2FibGUpIHJldHVybjtcclxuXHJcbiAgICAgICAgdGhpcy5leHBlbmRUaXRsZSA9ICF0aGlzLmV4cGVuZFRpdGxlO1xyXG4gICAgfVxyXG5cclxuICAgIHB1YmxpYyB1cGRhdGVTZWFyY2hUZXh0KF9zZWFyY2hUZXh0OiBzdHJpbmcpOiB2b2lkIHtcclxuICAgICAgICB0aGlzLmNvbmZpZy5zZWFyY2hUZXh0ID0gX3NlYXJjaFRleHQ7XHJcbiAgICB9XHJcblxyXG4gICAgLyoqKioqKioqKioqKioqKioqKioqKioqKioqKiogUHJpdmF0ZSBmdW5jdGlvbnMgKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqL1xyXG4gICAgLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vL1xyXG4gICAgLy8vIEN5Y2xlIGV2ZW50c1xyXG4gICAgLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vL1xyXG4gICAgcHJpdmF0ZSBfcHJvY2Vzc0NvbmZpZ0N5Y2xlKCk6IHZvaWQge1xyXG4gICAgICAgIGlmICh0eXBlb2YgdGhpcy5jb25maWcgPT09ICd1bmRlZmluZWQnKSB7XHJcbiAgICAgICAgICAgIHRoaXMuY29uZmlnID0ge307XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICB0aGlzLnRvb2xiYXJDb25maWcgPSB0aGlzLl9wYWdlaGVhZGVyU3ZjLnVwZGF0ZVRvb2xiYXJDb25maWcodGhpcy5jb25maWcpO1xyXG4gICAgICAgIHRoaXMuX3VwZGF0ZVRvb2xiYXJFeGlzdCgpO1xyXG4gICAgICAgIHRoaXMuX3VwZGF0ZUhvc3RCaW5kaW5nKCk7XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfdXBkYXRlRE9NQ3ljbGUoX2RlbGF5VGltZTogbnVtYmVyID0gMSk6IHZvaWQge1xyXG4gICAgICAgIG9ic2VydmFibGVUaW1lcigpLnN1YnNjcmliZSgoKTogdm9pZCA9PiB7XHJcbiAgICAgICAgICAgIHRoaXMuX3VwZGF0ZVZpZXdDbGFzcygpO1xyXG4gICAgICAgICAgICB0aGlzLl91cGRhdGVDbGlja2FibGVDeWNsZShfZGVsYXlUaW1lKTtcclxuICAgICAgICB9KTtcclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF91cGRhdGVDbGlja2FibGVDeWNsZShfZGVsYXlUaW1lOiBudW1iZXIgPSAxKTogdm9pZCB7XHJcbiAgICAgICAgaWYgKHRoaXMuX3N1YnNjcmlwdGlvbk9iai5oYXNPd25Qcm9wZXJ0eSgndGltZXInKSkge1xyXG4gICAgICAgICAgICB0aGlzLl9zdWJzY3JpcHRpb25PYmpbJ3RpbWVyJ10udW5zdWJzY3JpYmUoKTtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIHRoaXMuY2hlY2tUaXRsZUNvbXBsZXRlID0gZmFsc2U7XHJcbiAgICAgICAgdGhpcy5fc2V0VGl0bGVDbGlja2FibGUoX2RlbGF5VGltZSk7XHJcbiAgICB9XHJcblxyXG4gICAgLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vL1xyXG4gICAgLy8vIERPTSBDeWNsZSBmdW5jdGlvblxyXG4gICAgLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vL1xyXG4gICAgcHJpdmF0ZSBfc2V0dXBPYnNlcnZhYmxlRXZlbnRzKCk6IHZvaWQge1xyXG4gICAgICAgIHRoaXMuX3N1YnNjcmlwdGlvbk9ialsncmVzaXplJ10gPSBmcm9tRXZlbnQod2luZG93LCAncmVzaXplJylcclxuICAgICAgICAgICAgLnBpcGUoXHJcbiAgICAgICAgICAgICAgICBkZWJvdW5jZVRpbWUoREVMQVlfVElNRSlcclxuICAgICAgICAgICAgKVxyXG4gICAgICAgICAgICAuc3Vic2NyaWJlKFxyXG4gICAgICAgICAgICAgICAgKF9ldmVudDogRXZlbnQpOiB2b2lkID0+IHtcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLl91cGRhdGVET01DeWNsZSgpO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICApO1xyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX3VwZGF0ZVZpZXdDbGFzcygpOiB2b2lkIHtcclxuICAgICAgICB0aGlzLm1vYmlsZVZpZXcgPSB3aW5kb3cuaW5uZXJXaWR0aCA8PSAxMDI0O1xyXG5cclxuICAgICAgICBpZiAodGhpcy5tb2JpbGVWaWV3KSB7XHJcbiAgICAgICAgICAgIHRoaXMuZXhwZW5kVGl0bGUgPSBmYWxzZTtcclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfc2V0VHJhbnNpdGlvblRvKF90b2dnbGU6IGJvb2xlYW4pOiB2b2lkIHtcclxuICAgICAgICB0aGlzLnRvZ2dsZVRyYW5zaXRpb24gPSBfdG9nZ2xlO1xyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX3NldFRpdGxlQ2xpY2thYmxlKF9kZWxheTogbnVtYmVyKTogdm9pZCB7XHJcbiAgICAgICAgdGhpcy5fc3Vic2NyaXB0aW9uT2JqWyd0aW1lciddID0gb2JzZXJ2YWJsZVRpbWVyKF9kZWxheSlcclxuICAgICAgICAgICAgLnN1YnNjcmliZShcclxuICAgICAgICAgICAgICAgICgpOiB2b2lkID0+IHtcclxuICAgICAgICAgICAgICAgICAgICBsZXQgdGl0bGVFbGVtZW50OiBFbGVtZW50ID0gdGhpcy5fdmNyLmVsZW1lbnQubmF0aXZlRWxlbWVudC5xdWVyeVNlbGVjdG9yKCcudGl0bGUnKTtcclxuICAgICAgICAgICAgICAgICAgICBsZXQgYWN0dWFsRWxlbWVudDogRWxlbWVudCA9IHRoaXMuX3Zjci5lbGVtZW50Lm5hdGl2ZUVsZW1lbnQucXVlcnlTZWxlY3RvcignI2hlaWdodENoZWNrJyk7XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIGlmICh0aXRsZUVsZW1lbnQgIT09IG51bGwgJiYgYWN0dWFsRWxlbWVudCAhPT0gbnVsbCkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLnRpdGxlQ2xpY2thYmxlID0gdGl0bGVFbGVtZW50LmdldEJvdW5kaW5nQ2xpZW50UmVjdCgpLndpZHRoIDwgYWN0dWFsRWxlbWVudC5nZXRCb3VuZGluZ0NsaWVudFJlY3QoKS53aWR0aDtcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgZWxzZSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMudGl0bGVDbGlja2FibGUgPSBmYWxzZTtcclxuICAgICAgICAgICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuX3NldFRyYW5zaXRpb25Ubyh0cnVlKTtcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLmNoZWNrVGl0bGVDb21wbGV0ZSA9IHRydWU7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICk7XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfdXBkYXRlSG9zdEJpbmRpbmcoKTogdm9pZCB7XHJcbiAgICAgICAgdGhpcy5oYXNMZWZ0QnRucyA9IHRoaXMudG9vbGJhckNvbmZpZy5sZWZ0QnRuLmxlbmd0aCA+IDA7XHJcbiAgICAgICAgdGhpcy5oYXNNb3JlQnRuID0gdGhpcy50b29sYmFyQ29uZmlnLm1vcmVBY3Rpb24ubGVuZ3RoID4gMDtcclxuICAgICAgICB0aGlzLmhhc1NlYXJjaEJ0biA9IHRoaXMudG9vbGJhckNvbmZpZy5zZWFyY2hCdG47XHJcbiAgICB9XHJcblxyXG4gICAgLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vL1xyXG4gICAgLy8vIEFQSSBHZW5lcmF0aW9uXHJcbiAgICAvLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vXHJcbiAgICBwcml2YXRlIF9nZW5lcmF0ZUFwaShfYXBpOiBJUGFnZWhlYWRlckFwaSwgX2NvbmZpZzogSVBhZ2VoZWFkZXJDb25maWcpOiB2b2lkIHtcclxuICAgICAgICBpZiAodHlwZW9mIF9hcGkgIT09ICd1bmRlZmluZWQnKSB7XHJcbiAgICAgICAgICAgIF9hcGkudXBkYXRlVGl0bGUgPSAoX25ld1RpdGxlOiBzdHJpbmcgPSAnJyk6IHZvaWQgPT4ge1xyXG4gICAgICAgICAgICAgICAgX2NvbmZpZy5wYWdlaGVhZGVyVGV4dCA9IF9uZXdUaXRsZTtcclxuICAgICAgICAgICAgICAgIHRoaXMuX3VwZGF0ZUNsaWNrYWJsZUN5Y2xlKCk7XHJcbiAgICAgICAgICAgIH07XHJcblxyXG4gICAgICAgICAgICBfYXBpLnVwZGF0ZUxlZnRCdXR0b24gPSAoX25ld0xlZnRCdG4/OiBBcnJheTxJVG9vbGJhckJ1dHRvbj4pOiB2b2lkID0+IHtcclxuICAgICAgICAgICAgICAgIHRoaXMuX3NldFRyYW5zaXRpb25UbyhmYWxzZSk7XHJcbiAgICAgICAgICAgICAgICB0aGlzLmNvbmZpZy5sZWZ0QnRuID0gX25ld0xlZnRCdG47XHJcbiAgICAgICAgICAgICAgICB0aGlzLl9wcm9jZXNzQ29uZmlnQ3ljbGUoKTtcclxuICAgICAgICAgICAgICAgIHRoaXMuX3VwZGF0ZUNsaWNrYWJsZUN5Y2xlKERFTEFZX1RJTUUpO1xyXG4gICAgICAgICAgICB9O1xyXG5cclxuICAgICAgICAgICAgX2FwaS51cGRhdGVNb3JlQnV0dG9uID0gKF9lbmFibGVkOiBib29sZWFuLCBfbGlzdDogQXJyYXk8SVRvb2xiYXJNb3JlQnV0dG9uPik6IHZvaWQgPT4ge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5fc2V0VHJhbnNpdGlvblRvKGZhbHNlKTtcclxuICAgICAgICAgICAgICAgIHRoaXMuY29uZmlnLm1vcmVCdG4gPSBfZW5hYmxlZDtcclxuICAgICAgICAgICAgICAgIHRoaXMuY29uZmlnLm1vcmVBY3Rpb24gPSBfbGlzdDtcclxuICAgICAgICAgICAgICAgIHRoaXMuX3Byb2Nlc3NDb25maWdDeWNsZSgpO1xyXG4gICAgICAgICAgICAgICAgdGhpcy5fdXBkYXRlQ2xpY2thYmxlQ3ljbGUoREVMQVlfVElNRSk7XHJcbiAgICAgICAgICAgIH07XHJcblxyXG4gICAgICAgICAgICBfYXBpLnVwZGF0ZVNlYXJjaEJ1dHRvbiA9IChfc2VhcmNoQ29uZmlnPzogSVRvb2xiYXJTZWFyY2hDb25maWcpOiB2b2lkID0+IHtcclxuICAgICAgICAgICAgICAgIHRoaXMuX3NldFRyYW5zaXRpb25UbyhmYWxzZSk7XHJcbiAgICAgICAgICAgICAgICB0aGlzLmNvbmZpZyA9IE9iamVjdC5hc3NpZ248SVRvb2xiYXJTZWFyY2hDb25maWcsIElUb29sYmFyU2VhcmNoQ29uZmlnPih0aGlzLmNvbmZpZywgX3NlYXJjaENvbmZpZyk7XHJcbiAgICAgICAgICAgICAgICB0aGlzLl9wcm9jZXNzQ29uZmlnQ3ljbGUoKTtcclxuICAgICAgICAgICAgICAgIHRoaXMuX3VwZGF0ZUNsaWNrYWJsZUN5Y2xlKERFTEFZX1RJTUUpO1xyXG4gICAgICAgICAgICB9O1xyXG4gICAgICAgIH1cclxuICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgY29uc29sZS53YXJuKCdLZFBhZ2VoZWFkZXIgd2FybmluZzogTm8gYXBpIGlzIHBhc3NlZCBpbi4nKTtcclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vL1xyXG4gICAgLy8vIENvbmZpZyBmdW5jdGlvbnNcclxuICAgIC8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy9cclxuICAgIHByaXZhdGUgX3VwZGF0ZVRvb2xiYXJFeGlzdCgpOiB2b2lkIHtcclxuICAgICAgICB0aGlzLnRvb2xiYXJFeGlzdCA9IHRoaXMuX3BhZ2VoZWFkZXJTdmMuaXNUb29sYmFyRXhpc3QodGhpcy5jb25maWcpO1xyXG4gICAgfVxyXG59XHJcbiJdfQ==