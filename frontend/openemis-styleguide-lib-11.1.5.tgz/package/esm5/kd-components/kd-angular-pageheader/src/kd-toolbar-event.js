import { __decorate, __metadata } from "tslib";
import { Injectable } from '@angular/core';
import { KdBroadcaster } from '../../kd-common/index';
import * as i0 from "@angular/core";
import * as i1 from "../../kd-common/kd-broadcaster-svc";
var KdToolbarEvent = /** @class */ (function () {
    function KdToolbarEvent(_broadcaster) {
        this._broadcaster = _broadcaster;
    }
    KdToolbarEvent.prototype.sendSearchText = function (data) {
        this._broadcaster.broadcast('sendSearchText', data);
    };
    KdToolbarEvent.prototype.onSendSearchText = function () {
        return this._broadcaster.on('sendSearchText');
    };
    KdToolbarEvent.ctorParameters = function () { return [
        { type: KdBroadcaster }
    ]; };
    KdToolbarEvent.ɵprov = i0.ɵɵdefineInjectable({ factory: function KdToolbarEvent_Factory() { return new KdToolbarEvent(i0.ɵɵinject(i1.KdBroadcaster)); }, token: KdToolbarEvent, providedIn: "root" });
    KdToolbarEvent = __decorate([
        Injectable({
            providedIn: 'root'
        }),
        __metadata("design:paramtypes", [KdBroadcaster])
    ], KdToolbarEvent);
    return KdToolbarEvent;
}());
export { KdToolbarEvent };
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoia2QtdG9vbGJhci1ldmVudC5qcyIsInNvdXJjZVJvb3QiOiJuZzovL29wZW5lbWlzLXN0eWxlZ3VpZGUtbGliLyIsInNvdXJjZXMiOlsia2QtY29tcG9uZW50cy9rZC1hbmd1bGFyLXBhZ2VoZWFkZXIvc3JjL2tkLXRvb2xiYXItZXZlbnQudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IjtBQUFBLE9BQU8sRUFBRSxVQUFVLEVBQUUsTUFBTSxlQUFlLENBQUM7QUFFM0MsT0FBTyxFQUFFLGFBQWEsRUFBRSxNQUFNLHVCQUF1QixDQUFDOzs7QUFLdEQ7SUFDSSx3QkFBb0IsWUFBMkI7UUFBM0IsaUJBQVksR0FBWixZQUFZLENBQWU7SUFBSSxDQUFDO0lBRXBELHVDQUFjLEdBQWQsVUFBZSxJQUFhO1FBQ3hCLElBQUksQ0FBQyxZQUFZLENBQUMsU0FBUyxDQUFDLGdCQUFnQixFQUFFLElBQUksQ0FBQyxDQUFDO0lBQ3hELENBQUM7SUFFRCx5Q0FBZ0IsR0FBaEI7UUFDSSxPQUFPLElBQUksQ0FBQyxZQUFZLENBQUMsRUFBRSxDQUFTLGdCQUFnQixDQUFDLENBQUM7SUFDMUQsQ0FBQzs7Z0JBUmlDLGFBQWE7OztJQUR0QyxjQUFjO1FBSDFCLFVBQVUsQ0FBQztZQUNSLFVBQVUsRUFBRSxNQUFNO1NBQ3JCLENBQUM7eUNBRW9DLGFBQWE7T0FEdEMsY0FBYyxDQVUxQjt5QkFqQkQ7Q0FpQkMsQUFWRCxJQVVDO1NBVlksY0FBYyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IEluamVjdGFibGUgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcclxuaW1wb3J0IHsgT2JzZXJ2YWJsZSB9IGZyb20gJ3J4anMnO1xyXG5pbXBvcnQgeyBLZEJyb2FkY2FzdGVyIH0gZnJvbSAnLi4vLi4va2QtY29tbW9uL2luZGV4JztcclxuXHJcbkBJbmplY3RhYmxlKHtcclxuICAgIHByb3ZpZGVkSW46ICdyb290J1xyXG59KVxyXG5leHBvcnQgY2xhc3MgS2RUb29sYmFyRXZlbnQge1xyXG4gICAgY29uc3RydWN0b3IocHJpdmF0ZSBfYnJvYWRjYXN0ZXI6IEtkQnJvYWRjYXN0ZXIpIHsgfVxyXG5cclxuICAgIHNlbmRTZWFyY2hUZXh0KGRhdGE/OiBzdHJpbmcpOiB2b2lkIHtcclxuICAgICAgICB0aGlzLl9icm9hZGNhc3Rlci5icm9hZGNhc3QoJ3NlbmRTZWFyY2hUZXh0JywgZGF0YSk7XHJcbiAgICB9XHJcblxyXG4gICAgb25TZW5kU2VhcmNoVGV4dCgpOiBPYnNlcnZhYmxlPHN0cmluZz4ge1xyXG4gICAgICAgIHJldHVybiB0aGlzLl9icm9hZGNhc3Rlci5vbjxzdHJpbmc+KCdzZW5kU2VhcmNoVGV4dCcpO1xyXG4gICAgfVxyXG59XHJcbiJdfQ==