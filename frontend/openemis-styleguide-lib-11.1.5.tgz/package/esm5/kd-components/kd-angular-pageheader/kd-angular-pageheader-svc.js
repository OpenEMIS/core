/****************************************************************************************
    File               : kd-angular-pageheader-svc.ts
    Version            : 2.0
    Created by         : Cheng Kok Keong
    Purpose            : Service file for kd-angular-pageheader.ts

    Functions          :
        - Variables:
            - PLACEHOLDER_DEFAULT - Default text for placeholder

        - Public functions:
            - isToolbarExist - Check if there is any configurations for toolbar and renders accordingly.
            - updateToolbarConfig - Update defaults and undefines for placeholder

        - Private functions:
            - _isLeftButtonExist
            - _isMoreBtnExist
            - _isSearchBtnExist

    Last changes       :
        - Rewrite component and service

 ****************************************************************************************/
import { __assign, __decorate } from "tslib";
import { Injectable } from '@angular/core';
var KdPageheaderSvc = /** @class */ (function () {
    function KdPageheaderSvc() {
        /*********************** Variables ************************/
        this.PLACEHOLDER_DEFAULT = 'Search';
    }
    /******************* Public function **********************/
    KdPageheaderSvc.prototype.isToolbarExist = function (_config) {
        return (this._isLeftButtonExist(_config.leftBtn) ||
            this._isMoreBtnExist(_config.moreBtn) ||
            this._isSearchBtnExist(_config.searchBtn));
    };
    KdPageheaderSvc.prototype.updateToolbarConfig = function (_config) {
        var toolbarConfig = {};
        var searchConfig = {};
        /// Title checks
        if (typeof _config.pageheaderText === 'undefined') {
            _config.pageheaderText = '';
        }
        /// More button checks
        if (typeof _config.moreAction === 'undefined' || (typeof _config.moreBtn === 'undefined' || !_config.moreBtn)) {
            _config.moreAction = [];
        }
        /// Left button checks
        if (typeof _config.leftBtn === 'undefined') {
            _config.leftBtn = [];
        }
        if (_config.leftBtn.length > 6) {
            console.warn('KdToolbar warning: Left buttons only take up to 6 buttons. Slicing to 6 buttons');
            _config.leftBtn.splice(6);
        }
        /// Search checks
        if (typeof _config.searchEvent === 'undefined') {
            _config.searchEvent = [];
        }
        if (typeof _config.searchPlaceholder === 'undefined') {
            _config.searchPlaceholder = this.PLACEHOLDER_DEFAULT;
        }
        if (typeof _config.searchText === 'undefined') {
            _config.searchText = '';
        }
        if (typeof _config.searchBtn === 'undefined') {
            _config.searchBtn = false;
        }
        if (_config.searchBtn) {
            searchConfig = {
                searchPlaceholder: _config.searchPlaceholder,
                searchCallback: _config.searchCallback,
                searchEvent: _config.searchEvent,
                searchText: _config.searchText
            };
        }
        toolbarConfig = {
            leftBtn: _config.leftBtn,
            moreAction: _config.moreAction,
            searchBtn: _config.searchBtn
        };
        return __assign(__assign({}, toolbarConfig), searchConfig);
    };
    /****************** Private function **********************/
    ///////////////////////////////////////////////////////
    /// Checking function
    ///////////////////////////////////////////////////////
    KdPageheaderSvc.prototype._isLeftButtonExist = function (_leftBtn) {
        return (typeof _leftBtn !== 'undefined' && _leftBtn.length > 0);
    };
    KdPageheaderSvc.prototype._isMoreBtnExist = function (_moreBtn) {
        return (typeof _moreBtn !== 'undefined' && _moreBtn);
    };
    KdPageheaderSvc.prototype._isSearchBtnExist = function (_searchBtn) {
        return (typeof _searchBtn !== 'undefined' && _searchBtn);
    };
    KdPageheaderSvc = __decorate([
        Injectable()
    ], KdPageheaderSvc);
    return KdPageheaderSvc;
}());
export { KdPageheaderSvc };
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoia2QtYW5ndWxhci1wYWdlaGVhZGVyLXN2Yy5qcyIsInNvdXJjZVJvb3QiOiJuZzovL29wZW5lbWlzLXN0eWxlZ3VpZGUtbGliLyIsInNvdXJjZXMiOlsia2QtY29tcG9uZW50cy9rZC1hbmd1bGFyLXBhZ2VoZWFkZXIva2QtYW5ndWxhci1wYWdlaGVhZGVyLXN2Yy50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OzswRkFzQjBGOztBQUUxRixPQUFPLEVBQUUsVUFBVSxFQUFFLE1BQU0sZUFBZSxDQUFDO0FBSTNDO0lBQUE7UUFDSSw0REFBNEQ7UUFDbkQsd0JBQW1CLEdBQVcsUUFBUSxDQUFDO0lBcUZwRCxDQUFDO0lBbkZHLDREQUE0RDtJQUNyRCx3Q0FBYyxHQUFyQixVQUFzQixPQUEwQjtRQUM1QyxPQUFPLENBQ0gsSUFBSSxDQUFDLGtCQUFrQixDQUFDLE9BQU8sQ0FBQyxPQUFPLENBQUM7WUFDeEMsSUFBSSxDQUFDLGVBQWUsQ0FBQyxPQUFPLENBQUMsT0FBTyxDQUFDO1lBQ3JDLElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxPQUFPLENBQUMsU0FBUyxDQUFDLENBQzVDLENBQUM7SUFDTixDQUFDO0lBRU0sNkNBQW1CLEdBQTFCLFVBQTRCLE9BQTBCO1FBQ2xELElBQUksYUFBYSxHQUFtQixFQUFFLENBQUM7UUFDdkMsSUFBSSxZQUFZLEdBQW1CLEVBQUUsQ0FBQztRQUV0QyxnQkFBZ0I7UUFDaEIsSUFBSSxPQUFPLE9BQU8sQ0FBQyxjQUFjLEtBQUssV0FBVyxFQUFFO1lBQy9DLE9BQU8sQ0FBQyxjQUFjLEdBQUcsRUFBRSxDQUFDO1NBQy9CO1FBRUQsc0JBQXNCO1FBQ3RCLElBQUksT0FBTyxPQUFPLENBQUMsVUFBVSxLQUFLLFdBQVcsSUFBSSxDQUFDLE9BQU8sT0FBTyxDQUFDLE9BQU8sS0FBSyxXQUFXLElBQUksQ0FBQyxPQUFPLENBQUMsT0FBTyxDQUFDLEVBQUU7WUFDM0csT0FBTyxDQUFDLFVBQVUsR0FBRyxFQUFFLENBQUM7U0FDM0I7UUFFRCxzQkFBc0I7UUFDdEIsSUFBSSxPQUFPLE9BQU8sQ0FBQyxPQUFPLEtBQUssV0FBVyxFQUFFO1lBQ3hDLE9BQU8sQ0FBQyxPQUFPLEdBQUcsRUFBRSxDQUFDO1NBQ3hCO1FBRUQsSUFBSSxPQUFPLENBQUMsT0FBTyxDQUFDLE1BQU0sR0FBRyxDQUFDLEVBQUU7WUFDNUIsT0FBTyxDQUFDLElBQUksQ0FBQyxpRkFBaUYsQ0FBQyxDQUFDO1lBQ2hHLE9BQU8sQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDO1NBQzdCO1FBRUQsaUJBQWlCO1FBQ2pCLElBQUksT0FBTyxPQUFPLENBQUMsV0FBVyxLQUFLLFdBQVcsRUFBRTtZQUM1QyxPQUFPLENBQUMsV0FBVyxHQUFHLEVBQUUsQ0FBQztTQUM1QjtRQUVELElBQUksT0FBTyxPQUFPLENBQUMsaUJBQWlCLEtBQUssV0FBVyxFQUFFO1lBQ2xELE9BQU8sQ0FBQyxpQkFBaUIsR0FBRyxJQUFJLENBQUMsbUJBQW1CLENBQUM7U0FDeEQ7UUFFRCxJQUFJLE9BQU8sT0FBTyxDQUFDLFVBQVUsS0FBSyxXQUFXLEVBQUU7WUFDM0MsT0FBTyxDQUFDLFVBQVUsR0FBRyxFQUFFLENBQUM7U0FDM0I7UUFFRCxJQUFJLE9BQU8sT0FBTyxDQUFDLFNBQVMsS0FBSyxXQUFXLEVBQUU7WUFDMUMsT0FBTyxDQUFDLFNBQVMsR0FBRyxLQUFLLENBQUM7U0FDN0I7UUFFRCxJQUFJLE9BQU8sQ0FBQyxTQUFTLEVBQUU7WUFDbkIsWUFBWSxHQUFHO2dCQUNYLGlCQUFpQixFQUFFLE9BQU8sQ0FBQyxpQkFBaUI7Z0JBQzVDLGNBQWMsRUFBRSxPQUFPLENBQUMsY0FBYztnQkFDdEMsV0FBVyxFQUFFLE9BQU8sQ0FBQyxXQUFXO2dCQUNoQyxVQUFVLEVBQUUsT0FBTyxDQUFDLFVBQVU7YUFDakMsQ0FBQztTQUNMO1FBRUQsYUFBYSxHQUFHO1lBQ1osT0FBTyxFQUFFLE9BQU8sQ0FBQyxPQUFPO1lBQ3hCLFVBQVUsRUFBRSxPQUFPLENBQUMsVUFBVTtZQUM5QixTQUFTLEVBQUUsT0FBTyxDQUFDLFNBQVM7U0FDL0IsQ0FBQztRQUVGLDZCQUFXLGFBQWEsR0FBSyxZQUFZLEVBQUU7SUFDL0MsQ0FBQztJQUVELDREQUE0RDtJQUM1RCx1REFBdUQ7SUFDdkQscUJBQXFCO0lBQ3JCLHVEQUF1RDtJQUMvQyw0Q0FBa0IsR0FBMUIsVUFBMkIsUUFBK0I7UUFDdEQsT0FBTyxDQUFDLE9BQU8sUUFBUSxLQUFLLFdBQVcsSUFBSSxRQUFRLENBQUMsTUFBTSxHQUFHLENBQUMsQ0FBQyxDQUFDO0lBQ3BFLENBQUM7SUFFTyx5Q0FBZSxHQUF2QixVQUF3QixRQUFpQjtRQUNyQyxPQUFPLENBQUMsT0FBTyxRQUFRLEtBQUssV0FBVyxJQUFJLFFBQVEsQ0FBQyxDQUFDO0lBQ3pELENBQUM7SUFFTywyQ0FBaUIsR0FBekIsVUFBMEIsVUFBbUI7UUFDekMsT0FBTyxDQUFDLE9BQU8sVUFBVSxLQUFLLFdBQVcsSUFBSSxVQUFVLENBQUMsQ0FBQztJQUM3RCxDQUFDO0lBdEZRLGVBQWU7UUFEM0IsVUFBVSxFQUFFO09BQ0EsZUFBZSxDQXVGM0I7SUFBRCxzQkFBQztDQUFBLEFBdkZELElBdUZDO1NBdkZZLGVBQWUiLCJzb3VyY2VzQ29udGVudCI6WyIvKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKlxyXG4gICAgRmlsZSAgICAgICAgICAgICAgIDoga2QtYW5ndWxhci1wYWdlaGVhZGVyLXN2Yy50c1xyXG4gICAgVmVyc2lvbiAgICAgICAgICAgIDogMi4wXHJcbiAgICBDcmVhdGVkIGJ5ICAgICAgICAgOiBDaGVuZyBLb2sgS2VvbmdcclxuICAgIFB1cnBvc2UgICAgICAgICAgICA6IFNlcnZpY2UgZmlsZSBmb3Iga2QtYW5ndWxhci1wYWdlaGVhZGVyLnRzXHJcblxyXG4gICAgRnVuY3Rpb25zICAgICAgICAgIDpcclxuICAgICAgICAtIFZhcmlhYmxlczpcclxuICAgICAgICAgICAgLSBQTEFDRUhPTERFUl9ERUZBVUxUIC0gRGVmYXVsdCB0ZXh0IGZvciBwbGFjZWhvbGRlclxyXG5cclxuICAgICAgICAtIFB1YmxpYyBmdW5jdGlvbnM6XHJcbiAgICAgICAgICAgIC0gaXNUb29sYmFyRXhpc3QgLSBDaGVjayBpZiB0aGVyZSBpcyBhbnkgY29uZmlndXJhdGlvbnMgZm9yIHRvb2xiYXIgYW5kIHJlbmRlcnMgYWNjb3JkaW5nbHkuXHJcbiAgICAgICAgICAgIC0gdXBkYXRlVG9vbGJhckNvbmZpZyAtIFVwZGF0ZSBkZWZhdWx0cyBhbmQgdW5kZWZpbmVzIGZvciBwbGFjZWhvbGRlclxyXG5cclxuICAgICAgICAtIFByaXZhdGUgZnVuY3Rpb25zOlxyXG4gICAgICAgICAgICAtIF9pc0xlZnRCdXR0b25FeGlzdFxyXG4gICAgICAgICAgICAtIF9pc01vcmVCdG5FeGlzdFxyXG4gICAgICAgICAgICAtIF9pc1NlYXJjaEJ0bkV4aXN0XHJcblxyXG4gICAgTGFzdCBjaGFuZ2VzICAgICAgIDpcclxuICAgICAgICAtIFJld3JpdGUgY29tcG9uZW50IGFuZCBzZXJ2aWNlXHJcblxyXG4gKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKi9cclxuXHJcbmltcG9ydCB7IEluamVjdGFibGUgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcclxuaW1wb3J0IHsgSVBhZ2VoZWFkZXJDb25maWcsIElUb29sYmFyQnV0dG9uLCBJVG9vbGJhckNvbmZpZyB9IGZyb20gJy4va2QtYW5ndWxhci1wYWdlaGVhZGVyLWludGVyZmFjZSc7XHJcblxyXG5ASW5qZWN0YWJsZSgpXHJcbmV4cG9ydCBjbGFzcyBLZFBhZ2VoZWFkZXJTdmMge1xyXG4gICAgLyoqKioqKioqKioqKioqKioqKioqKioqIFZhcmlhYmxlcyAqKioqKioqKioqKioqKioqKioqKioqKiovXHJcbiAgICByZWFkb25seSBQTEFDRUhPTERFUl9ERUZBVUxUOiBzdHJpbmcgPSAnU2VhcmNoJztcclxuXHJcbiAgICAvKioqKioqKioqKioqKioqKioqKiBQdWJsaWMgZnVuY3Rpb24gKioqKioqKioqKioqKioqKioqKioqKi9cclxuICAgIHB1YmxpYyBpc1Rvb2xiYXJFeGlzdChfY29uZmlnOiBJUGFnZWhlYWRlckNvbmZpZyk6IGJvb2xlYW4ge1xyXG4gICAgICAgIHJldHVybiAoXHJcbiAgICAgICAgICAgIHRoaXMuX2lzTGVmdEJ1dHRvbkV4aXN0KF9jb25maWcubGVmdEJ0bikgfHxcclxuICAgICAgICAgICAgdGhpcy5faXNNb3JlQnRuRXhpc3QoX2NvbmZpZy5tb3JlQnRuKSB8fFxyXG4gICAgICAgICAgICB0aGlzLl9pc1NlYXJjaEJ0bkV4aXN0KF9jb25maWcuc2VhcmNoQnRuKVxyXG4gICAgICAgICk7XHJcbiAgICB9XHJcblxyXG4gICAgcHVibGljIHVwZGF0ZVRvb2xiYXJDb25maWcgKF9jb25maWc6IElQYWdlaGVhZGVyQ29uZmlnKTogSVRvb2xiYXJDb25maWcge1xyXG4gICAgICAgIGxldCB0b29sYmFyQ29uZmlnOiBJVG9vbGJhckNvbmZpZyA9IHt9O1xyXG4gICAgICAgIGxldCBzZWFyY2hDb25maWc6IElUb29sYmFyQ29uZmlnID0ge307XHJcblxyXG4gICAgICAgIC8vLyBUaXRsZSBjaGVja3NcclxuICAgICAgICBpZiAodHlwZW9mIF9jb25maWcucGFnZWhlYWRlclRleHQgPT09ICd1bmRlZmluZWQnKSB7XHJcbiAgICAgICAgICAgIF9jb25maWcucGFnZWhlYWRlclRleHQgPSAnJztcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIC8vLyBNb3JlIGJ1dHRvbiBjaGVja3NcclxuICAgICAgICBpZiAodHlwZW9mIF9jb25maWcubW9yZUFjdGlvbiA9PT0gJ3VuZGVmaW5lZCcgfHwgKHR5cGVvZiBfY29uZmlnLm1vcmVCdG4gPT09ICd1bmRlZmluZWQnIHx8ICFfY29uZmlnLm1vcmVCdG4pKSB7XHJcbiAgICAgICAgICAgIF9jb25maWcubW9yZUFjdGlvbiA9IFtdO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgLy8vIExlZnQgYnV0dG9uIGNoZWNrc1xyXG4gICAgICAgIGlmICh0eXBlb2YgX2NvbmZpZy5sZWZ0QnRuID09PSAndW5kZWZpbmVkJykge1xyXG4gICAgICAgICAgICBfY29uZmlnLmxlZnRCdG4gPSBbXTtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIGlmIChfY29uZmlnLmxlZnRCdG4ubGVuZ3RoID4gNikge1xyXG4gICAgICAgICAgICBjb25zb2xlLndhcm4oJ0tkVG9vbGJhciB3YXJuaW5nOiBMZWZ0IGJ1dHRvbnMgb25seSB0YWtlIHVwIHRvIDYgYnV0dG9ucy4gU2xpY2luZyB0byA2IGJ1dHRvbnMnKTtcclxuICAgICAgICAgICAgX2NvbmZpZy5sZWZ0QnRuLnNwbGljZSg2KTtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIC8vLyBTZWFyY2ggY2hlY2tzXHJcbiAgICAgICAgaWYgKHR5cGVvZiBfY29uZmlnLnNlYXJjaEV2ZW50ID09PSAndW5kZWZpbmVkJykge1xyXG4gICAgICAgICAgICBfY29uZmlnLnNlYXJjaEV2ZW50ID0gW107XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICBpZiAodHlwZW9mIF9jb25maWcuc2VhcmNoUGxhY2Vob2xkZXIgPT09ICd1bmRlZmluZWQnKSB7XHJcbiAgICAgICAgICAgIF9jb25maWcuc2VhcmNoUGxhY2Vob2xkZXIgPSB0aGlzLlBMQUNFSE9MREVSX0RFRkFVTFQ7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICBpZiAodHlwZW9mIF9jb25maWcuc2VhcmNoVGV4dCA9PT0gJ3VuZGVmaW5lZCcpIHtcclxuICAgICAgICAgICAgX2NvbmZpZy5zZWFyY2hUZXh0ID0gJyc7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICBpZiAodHlwZW9mIF9jb25maWcuc2VhcmNoQnRuID09PSAndW5kZWZpbmVkJykge1xyXG4gICAgICAgICAgICBfY29uZmlnLnNlYXJjaEJ0biA9IGZhbHNlO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgaWYgKF9jb25maWcuc2VhcmNoQnRuKSB7XHJcbiAgICAgICAgICAgIHNlYXJjaENvbmZpZyA9IHtcclxuICAgICAgICAgICAgICAgIHNlYXJjaFBsYWNlaG9sZGVyOiBfY29uZmlnLnNlYXJjaFBsYWNlaG9sZGVyLFxyXG4gICAgICAgICAgICAgICAgc2VhcmNoQ2FsbGJhY2s6IF9jb25maWcuc2VhcmNoQ2FsbGJhY2ssXHJcbiAgICAgICAgICAgICAgICBzZWFyY2hFdmVudDogX2NvbmZpZy5zZWFyY2hFdmVudCxcclxuICAgICAgICAgICAgICAgIHNlYXJjaFRleHQ6IF9jb25maWcuc2VhcmNoVGV4dFxyXG4gICAgICAgICAgICB9O1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgdG9vbGJhckNvbmZpZyA9IHtcclxuICAgICAgICAgICAgbGVmdEJ0bjogX2NvbmZpZy5sZWZ0QnRuLFxyXG4gICAgICAgICAgICBtb3JlQWN0aW9uOiBfY29uZmlnLm1vcmVBY3Rpb24sXHJcbiAgICAgICAgICAgIHNlYXJjaEJ0bjogX2NvbmZpZy5zZWFyY2hCdG5cclxuICAgICAgICB9O1xyXG5cclxuICAgICAgICByZXR1cm4gey4uLnRvb2xiYXJDb25maWcsIC4uLnNlYXJjaENvbmZpZ307XHJcbiAgICB9XHJcblxyXG4gICAgLyoqKioqKioqKioqKioqKioqKiBQcml2YXRlIGZ1bmN0aW9uICoqKioqKioqKioqKioqKioqKioqKiovXHJcbiAgICAvLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vXHJcbiAgICAvLy8gQ2hlY2tpbmcgZnVuY3Rpb25cclxuICAgIC8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy9cclxuICAgIHByaXZhdGUgX2lzTGVmdEJ1dHRvbkV4aXN0KF9sZWZ0QnRuOiBBcnJheTxJVG9vbGJhckJ1dHRvbj4pOiBib29sZWFuIHtcclxuICAgICAgICByZXR1cm4gKHR5cGVvZiBfbGVmdEJ0biAhPT0gJ3VuZGVmaW5lZCcgJiYgX2xlZnRCdG4ubGVuZ3RoID4gMCk7XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfaXNNb3JlQnRuRXhpc3QoX21vcmVCdG46IGJvb2xlYW4pOiBib29sZWFuIHtcclxuICAgICAgICByZXR1cm4gKHR5cGVvZiBfbW9yZUJ0biAhPT0gJ3VuZGVmaW5lZCcgJiYgX21vcmVCdG4pO1xyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX2lzU2VhcmNoQnRuRXhpc3QoX3NlYXJjaEJ0bjogYm9vbGVhbikge1xyXG4gICAgICAgIHJldHVybiAodHlwZW9mIF9zZWFyY2hCdG4gIT09ICd1bmRlZmluZWQnICYmIF9zZWFyY2hCdG4pO1xyXG4gICAgfVxyXG59XHJcbiJdfQ==