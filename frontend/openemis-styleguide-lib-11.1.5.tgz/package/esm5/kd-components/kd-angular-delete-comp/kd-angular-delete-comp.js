import { __decorate, __metadata } from "tslib";
import { Component, Input, Output, EventEmitter, ViewEncapsulation, ViewChild } from '@angular/core';
import { KdView } from '../kd-angular-view/index';
var KdDelete = /** @class */ (function () {
    function KdDelete() {
        this._questionData = [];
        this._defaultBtn = [{
                type: 'submit',
                name: 'Delete',
                icon: 'kd-trash',
                class: 'btn-text',
                disabled: false
            }, {
                type: 'cancel',
                name: 'Cancel',
                class: 'btn-outline',
                icon: 'kd-cross',
                disabled: false
            }];
        this._sectionHeader = {
            key: 'SectionHeader',
            label: 'Are you sure you want to delete this?',
            controlType: 'section',
            visible: true,
            required: false
        };
        this.buttonCancelEvent = new EventEmitter();
        this.buttonDeleteEvent = new EventEmitter();
    }
    KdDelete.prototype.ngOnInit = function () {
        if (typeof this.question !== 'undefined' && this.question.length > 0)
            this._questionData = this.question;
        this._questionData.unshift(this._sectionHeader);
    };
    KdDelete.prototype.btnClick = function (_button) {
        this.buttonCancelEvent.emit();
    };
    KdDelete.prototype.submitClick = function (_formVal) {
        this.buttonDeleteEvent.emit(_formVal);
    };
    KdDelete.prototype.setDeleteDisabled = function (_toDisable) {
        this.kdViewComponent.setButtonDisabled('submit', _toDisable);
    };
    __decorate([
        Input(),
        __metadata("design:type", Array)
    ], KdDelete.prototype, "question", void 0);
    __decorate([
        Output(),
        __metadata("design:type", EventEmitter)
    ], KdDelete.prototype, "buttonCancelEvent", void 0);
    __decorate([
        Output(),
        __metadata("design:type", EventEmitter)
    ], KdDelete.prototype, "buttonDeleteEvent", void 0);
    __decorate([
        ViewChild(KdView, { static: true }),
        __metadata("design:type", KdView)
    ], KdDelete.prototype, "kdViewComponent", void 0);
    KdDelete = __decorate([
        Component({
            selector: 'kd-delete',
            template: "<kd-view displayType='form' [inputData]='_questionData' [button]='_defaultBtn' (buttonEvent)='btnClick($event)' (submitEvent)='submitClick($event)'></kd-view>",
            encapsulation: ViewEncapsulation.None
        })
    ], KdDelete);
    return KdDelete;
}());
export { KdDelete };
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoia2QtYW5ndWxhci1kZWxldGUtY29tcC5qcyIsInNvdXJjZVJvb3QiOiJuZzovL29wZW5lbWlzLXN0eWxlZ3VpZGUtbGliLyIsInNvdXJjZXMiOlsia2QtY29tcG9uZW50cy9rZC1hbmd1bGFyLWRlbGV0ZS1jb21wL2tkLWFuZ3VsYXItZGVsZXRlLWNvbXAudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IjtBQUFBLE9BQU8sRUFDSCxTQUFTLEVBQ1QsS0FBSyxFQUNMLE1BQU0sRUFDTixZQUFZLEVBQ1osaUJBQWlCLEVBRWpCLFNBQVMsRUFDWixNQUFNLGVBQWUsQ0FBQztBQUN2QixPQUFPLEVBQUUsTUFBTSxFQUFFLE1BQU0sMEJBQTBCLENBQUM7QUFRbEQ7SUFBQTtRQUNXLGtCQUFhLEdBQWUsRUFBRSxDQUFDO1FBQy9CLGdCQUFXLEdBQWUsQ0FBQztnQkFDOUIsSUFBSSxFQUFFLFFBQVE7Z0JBQ2QsSUFBSSxFQUFFLFFBQVE7Z0JBQ2QsSUFBSSxFQUFFLFVBQVU7Z0JBQ2hCLEtBQUssRUFBRSxVQUFVO2dCQUNqQixRQUFRLEVBQUUsS0FBSzthQUNsQixFQUFFO2dCQUNDLElBQUksRUFBRSxRQUFRO2dCQUNkLElBQUksRUFBRSxRQUFRO2dCQUNkLEtBQUssRUFBRSxhQUFhO2dCQUNwQixJQUFJLEVBQUUsVUFBVTtnQkFDaEIsUUFBUSxFQUFFLEtBQUs7YUFDbEIsQ0FBQyxDQUFDO1FBRUssbUJBQWMsR0FBUTtZQUMxQixHQUFHLEVBQUUsZUFBZTtZQUNwQixLQUFLLEVBQUUsdUNBQXVDO1lBQzlDLFdBQVcsRUFBRSxTQUFTO1lBQ3RCLE9BQU8sRUFBRSxJQUFJO1lBQ2IsUUFBUSxFQUFFLEtBQUs7U0FDbEIsQ0FBQztRQUdRLHNCQUFpQixHQUFzQixJQUFJLFlBQVksRUFBRSxDQUFDO1FBQzFELHNCQUFpQixHQUFzQixJQUFJLFlBQVksRUFBRSxDQUFDO0lBbUJ4RSxDQUFDO0lBaEJHLDJCQUFRLEdBQVI7UUFDSSxJQUFJLE9BQU8sSUFBSSxDQUFDLFFBQVEsS0FBSyxXQUFXLElBQUksSUFBSSxDQUFDLFFBQVEsQ0FBQyxNQUFNLEdBQUcsQ0FBQztZQUFFLElBQUksQ0FBQyxhQUFhLEdBQUcsSUFBSSxDQUFDLFFBQVEsQ0FBQztRQUN6RyxJQUFJLENBQUMsYUFBYSxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsY0FBYyxDQUFDLENBQUM7SUFDcEQsQ0FBQztJQUVELDJCQUFRLEdBQVIsVUFBUyxPQUFZO1FBQ2pCLElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxJQUFJLEVBQUUsQ0FBQztJQUNsQyxDQUFDO0lBRUQsOEJBQVcsR0FBWCxVQUFZLFFBQWE7UUFDckIsSUFBSSxDQUFDLGlCQUFpQixDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsQ0FBQztJQUMxQyxDQUFDO0lBRU0sb0NBQWlCLEdBQXhCLFVBQXlCLFVBQW1CO1FBQ3hDLElBQUksQ0FBQyxlQUFlLENBQUMsaUJBQWlCLENBQUMsUUFBUSxFQUFFLFVBQVUsQ0FBQyxDQUFDO0lBQ2pFLENBQUM7SUFwQlE7UUFBUixLQUFLLEVBQUU7a0NBQVcsS0FBSzs4Q0FBTTtJQUNwQjtRQUFULE1BQU0sRUFBRTtrQ0FBb0IsWUFBWTt1REFBMkI7SUFDMUQ7UUFBVCxNQUFNLEVBQUU7a0NBQW9CLFlBQVk7dURBQTJCO0lBQy9CO1FBQXBDLFNBQVMsQ0FBQyxNQUFNLEVBQUUsRUFBRSxNQUFNLEVBQUUsSUFBSSxFQUFFLENBQUM7a0NBQWtCLE1BQU07cURBQUM7SUEzQnBELFFBQVE7UUFOcEIsU0FBUyxDQUFDO1lBQ1AsUUFBUSxFQUFFLFdBQVc7WUFDckIsUUFBUSxFQUFFLGdLQUFnSztZQUMxSyxhQUFhLEVBQUUsaUJBQWlCLENBQUMsSUFBSTtTQUN4QyxDQUFDO09BRVcsUUFBUSxDQTZDcEI7SUFBRCxlQUFDO0NBQUEsQUE3Q0QsSUE2Q0M7U0E3Q1ksUUFBUSIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7XHJcbiAgICBDb21wb25lbnQsXHJcbiAgICBJbnB1dCxcclxuICAgIE91dHB1dCxcclxuICAgIEV2ZW50RW1pdHRlcixcclxuICAgIFZpZXdFbmNhcHN1bGF0aW9uLFxyXG4gICAgT25Jbml0LFxyXG4gICAgVmlld0NoaWxkXHJcbn0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XHJcbmltcG9ydCB7IEtkVmlldyB9IGZyb20gJy4uL2tkLWFuZ3VsYXItdmlldy9pbmRleCc7XHJcblxyXG5AQ29tcG9uZW50KHtcclxuICAgIHNlbGVjdG9yOiAna2QtZGVsZXRlJyxcclxuICAgIHRlbXBsYXRlOiBgPGtkLXZpZXcgZGlzcGxheVR5cGU9J2Zvcm0nIFtpbnB1dERhdGFdPSdfcXVlc3Rpb25EYXRhJyBbYnV0dG9uXT0nX2RlZmF1bHRCdG4nIChidXR0b25FdmVudCk9J2J0bkNsaWNrKCRldmVudCknIChzdWJtaXRFdmVudCk9J3N1Ym1pdENsaWNrKCRldmVudCknPjwva2Qtdmlldz5gLFxyXG4gICAgZW5jYXBzdWxhdGlvbjogVmlld0VuY2Fwc3VsYXRpb24uTm9uZVxyXG59KVxyXG5cclxuZXhwb3J0IGNsYXNzIEtkRGVsZXRlIGltcGxlbWVudHMgT25Jbml0IHtcclxuICAgIHB1YmxpYyBfcXVlc3Rpb25EYXRhOiBBcnJheTxhbnk+ID0gW107XHJcbiAgICBwdWJsaWMgX2RlZmF1bHRCdG46IEFycmF5PGFueT4gPSBbe1xyXG4gICAgICAgIHR5cGU6ICdzdWJtaXQnLFxyXG4gICAgICAgIG5hbWU6ICdEZWxldGUnLFxyXG4gICAgICAgIGljb246ICdrZC10cmFzaCcsXHJcbiAgICAgICAgY2xhc3M6ICdidG4tdGV4dCcsXHJcbiAgICAgICAgZGlzYWJsZWQ6IGZhbHNlXHJcbiAgICB9LCB7XHJcbiAgICAgICAgdHlwZTogJ2NhbmNlbCcsXHJcbiAgICAgICAgbmFtZTogJ0NhbmNlbCcsXHJcbiAgICAgICAgY2xhc3M6ICdidG4tb3V0bGluZScsXHJcbiAgICAgICAgaWNvbjogJ2tkLWNyb3NzJyxcclxuICAgICAgICBkaXNhYmxlZDogZmFsc2VcclxuICAgIH1dO1xyXG5cclxuICAgIHByaXZhdGUgX3NlY3Rpb25IZWFkZXI6IGFueSA9IHtcclxuICAgICAgICBrZXk6ICdTZWN0aW9uSGVhZGVyJyxcclxuICAgICAgICBsYWJlbDogJ0FyZSB5b3Ugc3VyZSB5b3Ugd2FudCB0byBkZWxldGUgdGhpcz8nLFxyXG4gICAgICAgIGNvbnRyb2xUeXBlOiAnc2VjdGlvbicsXHJcbiAgICAgICAgdmlzaWJsZTogdHJ1ZSxcclxuICAgICAgICByZXF1aXJlZDogZmFsc2VcclxuICAgIH07XHJcblxyXG4gICAgQElucHV0KCkgcXVlc3Rpb246IEFycmF5PGFueT47XHJcbiAgICBAT3V0cHV0KCkgYnV0dG9uQ2FuY2VsRXZlbnQ6IEV2ZW50RW1pdHRlcjxhbnk+ID0gbmV3IEV2ZW50RW1pdHRlcigpO1xyXG4gICAgQE91dHB1dCgpIGJ1dHRvbkRlbGV0ZUV2ZW50OiBFdmVudEVtaXR0ZXI8YW55PiA9IG5ldyBFdmVudEVtaXR0ZXIoKTtcclxuICAgIEBWaWV3Q2hpbGQoS2RWaWV3LCB7IHN0YXRpYzogdHJ1ZSB9KSBrZFZpZXdDb21wb25lbnQ6IEtkVmlldztcclxuXHJcbiAgICBuZ09uSW5pdCgpOiB2b2lkIHtcclxuICAgICAgICBpZiAodHlwZW9mIHRoaXMucXVlc3Rpb24gIT09ICd1bmRlZmluZWQnICYmIHRoaXMucXVlc3Rpb24ubGVuZ3RoID4gMCkgdGhpcy5fcXVlc3Rpb25EYXRhID0gdGhpcy5xdWVzdGlvbjtcclxuICAgICAgICB0aGlzLl9xdWVzdGlvbkRhdGEudW5zaGlmdCh0aGlzLl9zZWN0aW9uSGVhZGVyKTtcclxuICAgIH1cclxuXHJcbiAgICBidG5DbGljayhfYnV0dG9uOiBhbnkpOiB2b2lkIHtcclxuICAgICAgICB0aGlzLmJ1dHRvbkNhbmNlbEV2ZW50LmVtaXQoKTtcclxuICAgIH1cclxuXHJcbiAgICBzdWJtaXRDbGljayhfZm9ybVZhbDogYW55KTogdm9pZCB7XHJcbiAgICAgICAgdGhpcy5idXR0b25EZWxldGVFdmVudC5lbWl0KF9mb3JtVmFsKTtcclxuICAgIH1cclxuXHJcbiAgICBwdWJsaWMgc2V0RGVsZXRlRGlzYWJsZWQoX3RvRGlzYWJsZTogYm9vbGVhbik6IHZvaWQge1xyXG4gICAgICAgIHRoaXMua2RWaWV3Q29tcG9uZW50LnNldEJ1dHRvbkRpc2FibGVkKCdzdWJtaXQnLCBfdG9EaXNhYmxlKTtcclxuICAgIH1cclxufVxyXG4iXX0=