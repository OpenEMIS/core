import { __decorate } from "tslib";
import { Injectable } from '@angular/core';
import { KdTableAction } from '../table-components/kd-table-action';
import { KdTableCheckboxRadio } from '../table-components/kd-table-checkbox-radio';
import { KdTableInput } from '../table-components/kd-table-input';
import { KdTableImage } from '../table-components/kd-table-image';
import { KdDataSvc } from '../../kd-common/index';
/**
 * -- Documentation for kd-table-svc.ts
 *
 * - Public functions (Usable by both extended services):
 *     - Checking functions
 *         - isApiReady
 *         - hasSelectionAll
 *         - hasInputType
 *         - isInputType
 *         - isEnterpriseModel
 *     - Update functions
 *         - updateSelectDefaultValue
 *         - updateSelectionValues
 *         - updateGridButtons
 *         - updateRowDataWithColumn (Generations of input context in gridOptions.context if input exist)
 *         - generatedApiFunctions (Generation of APIs)
 *     - Misc function
 *         - getGridId
 *         - getImageSizeBy
 *         - getTableContextKey
 *         - getRouterPlaceholderPath (For pathMap of click type router)
 *         - b64toBlob
 *
 * - Protected function:
 *     - Grid Options function
 *         - getDefaultGridOptions
 *     - Column definition functions
 *         - generateColumnDefinitions
 *         - isColDefOfType
 *     - API generation function
 *     - Misc functions
 *         - generateGridId
 *         - generateContextKey
 *         - getImageSizeBy
 *
 * - Private functions:
 *     - Column definition functions
 *         - _generateColDefsFromColConfig (ColDef generation based on column config - checks normal columns, input column and image columns)
 *         - _generateColDefsFromConfig (ColDef generation based on grid config - checks action column and selection column)
 *         - _generateActionColDef (Action)
 *         - _generateCheckboxRadioColDef (Selection)
 *         - _generateImageColDef (Image)
 *         - _generateInputColDef (Input)
 *     - API generation functions
 *         - _generateInputApi (api.dynamicForms)
 *         - _generateGeneralApi (api.general)
 *     - Table input functions
 *         - _generateTableInputContext (Loop all columns and rows and each of the question to generate the context for input columns)
 *     - Selection functions
 *         - _convertDataValueToObject (set to object if config consist of return keys)
 *         - _appendDataValueKey
 *     - Misc functions
 *         - _updateFilterColDef
 *         - _getDefaultColumnConfig
 */
var KdTableSvcBase = /** @class */ (function () {
    function KdTableSvcBase() {
        /******************************** Variables *********************************/
        this.ROW_HEIGHT = 50;
        this.CONTEXT_DELIMITER = '~';
        this.TABLE_INPUT_CONTEXT_KEY = 'tableInputContext';
        this.DEFAULT_PAGESIZE = 25;
        this.IMAGE_PADDING = 20;
        this.DEFAULT_GRIDID = 'kd-table-grid';
        this.GIRD_PARAMS_KEY = {
            input: 'inputConfig',
            image: 'imageConfig'
        };
        this.dataSvc = new KdDataSvc();
        this.rowKey = 'id';
        /************************* End of private functions **************************/
    }
    /*************** Public functions (shared for both services) ****************/
    ////////////////////////////////////////////////////////
    /// Checking functions
    ////////////////////////////////////////////////////////
    KdTableSvcBase.prototype.isApiReady = function (_gridOptions) {
        if (typeof _gridOptions !== 'undefined' &&
            _gridOptions !== null &&
            typeof _gridOptions.api !== 'undefined') {
            return true;
        }
        return false;
    };
    KdTableSvcBase.prototype.hasSelectionAll = function (_gridConfig) {
        if (typeof _gridConfig !== 'undefined' &&
            typeof _gridConfig.selection !== 'undefined' &&
            typeof _gridConfig.selection.type !== 'undefined' &&
            _gridConfig.selection.type === 'all' &&
            _gridConfig.loadType !== 'infinite') {
            return true;
        }
        return false;
    };
    KdTableSvcBase.prototype.hasInputType = function (_tableColumn, _type) {
        if (typeof _tableColumn !== 'undefined') {
            for (var i = 0; i < _tableColumn.length; ++i) {
                if (this.isInputType(_tableColumn[i], _type)) {
                    return true;
                }
            }
        }
        return false;
    };
    KdTableSvcBase.prototype.isInputType = function (_column, _type) {
        return (typeof _column.type !== 'undefined' && _column.type === _type);
    };
    KdTableSvcBase.prototype.isEnterpriseModel = function (_loadType) {
        return (_loadType === 'oneshot' || _loadType === 'infinite' || _loadType === 'server');
    };
    ////////////////////////////////////////////////////////
    /// Selection functions
    ////////////////////////////////////////////////////////
    KdTableSvcBase.prototype.updateSelectDefaultValue = function (_gridConfig) {
        if (typeof _gridConfig.selection !== 'undefined') {
            if (typeof _gridConfig.selection.value === 'undefined') {
                _gridConfig.selection.value = [];
            }
            else if (_gridConfig.selection.type === 'single' && _gridConfig.selection.value.length > 1) {
                console.warn('KdTable warning: Single selection type contains more than 1 default values.');
                _gridConfig.selection.value = _gridConfig.selection.value.slice(0, 1);
            }
        }
    };
    /**
     * [updateSelectionValues() - Returns the selected nodes based on the returnKey specify.
     *  If is not specify, array of ids will be return on selection.
     *  Only works for normal, infinite and oneshot loadType.
     *     - Not specify - Return [ 1, 2, 3 ];
     *     - Specify     - Return [ {id: 1, grade: "1" }, {id: 2, grade: "1"}, {id: 3, grade: "2"}]
     * ]
     * _rowData       : [Current provided rowData]
     * _selectedIds   : [Current selected rowData ids]
     * _returnKey     : [List of property keys to return with id]
     * [Generated selection by returnKey]
     */
    KdTableSvcBase.prototype.updateSelectionValues = function (_rowData, _selectedIds, _returnKey, _loadType) {
        if (typeof _returnKey === 'undefined' ||
            _returnKey === null ||
            _returnKey.length === 0) {
            return _selectedIds;
        }
        var generatedSelection = [];
        for (var i = 0; i < _rowData.length; i++) {
            var dataItem = _rowData[i];
            var oneItem = {};
            if (_selectedIds.indexOf(dataItem[this.rowKey]) > -1) {
                oneItem[this.rowKey] = dataItem[this.rowKey];
                for (var j = 0; j < _returnKey.length; j++) {
                    if (dataItem.hasOwnProperty(_returnKey[j])) {
                        oneItem[_returnKey[j]] = dataItem[_returnKey[j]];
                    }
                    else if (_returnKey[j].indexOf('.') > 0) {
                        var returnVal = this.dataSvc.getDataValue(dataItem, _returnKey[j]);
                        if (returnVal !== null) {
                            var newItem = Object.assign({}, oneItem);
                            oneItem = this._convertDataValueToObject(newItem, _returnKey[j], returnVal);
                        }
                    }
                }
                generatedSelection.push(oneItem);
            }
        }
        return generatedSelection;
    };
    ////////////////////////////////////////////////////////
    /// Grid Button functions
    ////////////////////////////////////////////////////////
    KdTableSvcBase.prototype.updateGridButtons = function (_gridConfig) {
        if (typeof _gridConfig.button === 'undefined') {
            _gridConfig.button = [];
        }
        else if (_gridConfig.button.length > 4) {
            console.warn('KdTable warning: Max 4 buttons for table. Slicing to 4.');
            _gridConfig.button = _gridConfig.button.slice(0, 4);
        }
    };
    ////////////////////////////////////////////////////////
    /// Table Input functions
    ////////////////////////////////////////////////////////
    KdTableSvcBase.prototype.updateRowDataWithColumn = function (_rowData, _columnConfig, _gridId, _gridOptions) {
        if (this.hasInputType(_columnConfig, 'input')) {
            if (typeof _gridOptions.context[this.TABLE_INPUT_CONTEXT_KEY] === 'undefined') {
                _gridOptions.context[this.TABLE_INPUT_CONTEXT_KEY] = {};
            }
            var inputContext = this._generateTableInputContext(_columnConfig, _rowData, _gridId);
            _gridOptions.context[this.TABLE_INPUT_CONTEXT_KEY] = Object.assign(_gridOptions.context[this.TABLE_INPUT_CONTEXT_KEY], inputContext);
        }
    };
    ////////////////////////////////////////////////////////
    /// API Generation function
    ////////////////////////////////////////////////////////
    KdTableSvcBase.prototype.generatedApiFunctions = function (_gridApi, _apiParams) {
        _gridApi.dynamicForm = this._generateInputApi(_apiParams.id, _apiParams.event);
        _gridApi.general = this._generateGeneralApi(_apiParams.rows);
    };
    ////////////////////////////////////////////////////////
    /// Misc function
    ////////////////////////////////////////////////////////
    KdTableSvcBase.prototype.getGridId = function (_gridConfig) {
        if (typeof _gridConfig.id === 'undefined') {
            _gridConfig.id = this.DEFAULT_GRIDID;
        }
        return _gridConfig.id;
    };
    KdTableSvcBase.prototype.getImageSizeBy = function (_tableColumn, _dimension) {
        // Default placeholder width 150 + 20 gap
        var width = 150 + this.IMAGE_PADDING;
        if (typeof _tableColumn.config !== 'undefined' &&
            typeof _tableColumn.config.image !== 'undefined' &&
            typeof _tableColumn.config.image[_dimension] !== 'undefined') {
            width = _tableColumn.config.image[_dimension] + this.IMAGE_PADDING;
        }
        return width;
    };
    KdTableSvcBase.prototype.getTableContextKey = function () {
        return this.TABLE_INPUT_CONTEXT_KEY;
    };
    KdTableSvcBase.prototype.getRouterPlaceholderPath = function (_rowNode, _path) {
        return this.dataSvc.getPlaceholder(_rowNode.data, _path);
    };
    KdTableSvcBase.prototype.b64toBlob = function (b64Data, contentType) {
        var sliceSize = 512;
        var byteCharacters = atob(b64Data);
        var byteArrays = [];
        for (var offset = 0; offset < byteCharacters.length; offset += sliceSize) {
            var slice = byteCharacters.slice(offset, offset + sliceSize);
            var byteNumbers = new Array(slice.length);
            for (var i = 0; i < slice.length; i++) {
                byteNumbers[i] = slice.charCodeAt(i);
            }
            var byteArray = new Uint8Array(byteNumbers);
            byteArrays.push(byteArray);
        }
        var blob = new Blob(byteArrays, { type: contentType });
        return blob;
    };
    /********** End of public functions / Start of protected functions **********/
    ////////////////////////////////////////////////////////
    /// Grid Options functions
    ////////////////////////////////////////////////////////
    KdTableSvcBase.prototype.getDefaultGridOptions = function (_direction, _rowHeight) {
        this.direction = _direction;
        return {
            rowData: [],
            columnDefs: [],
            enableRtl: _direction === 'rtl',
            headerHeight: 38,
            rowHeight: (typeof _rowHeight !== 'undefined') ? _rowHeight + 20 : this.ROW_HEIGHT,
            // suppressMovableColumns: true,
            suppressDragLeaveHidesColumns: true,
            enableColResize: true,
            suppressContextMenu: true,
            suppressMenuHide: true,
            ensureDomOrder: true,
            suppressPropertyNamesCheck: true,
            // suppressColumnVirtualisation: true,
            animateRows: false,
            rowBuffer: 5,
            getRowNodeId: function (_data) {
                var id = _data.id;
                if (typeof _data.id === 'number') {
                    id = id.toString();
                }
                return id;
            },
            unSortIcon: true,
            icons: {
                filter: '<i class="fa fa-filter"/>',
                sortAscending: '<i class="fa fa-caret-down"/>',
                sortDescending: '<i class="fa fa-caret-up"/>',
                sortUnSort: '<i class="fa fa-sort"/>',
                // groupExpanded: '<i class="fa fa-minus-circle"/>',
                // groupContracted: '<i class="fa fa-plus-circle"/>',
                groupExpanded: '<i class="fa fa-angle-down"/>',
                groupContracted: '<i class="fa fa-angle-right"/>',
                menu: '<i class="fa fa-bars"/>'
            },
            autoGroupColumnDef: {
                icons: {
                    menu: '<i class="fa fa-bar" style="display:none"/>',
                }
            },
            context: {},
            overlayNoRowsTemplate: '<span class="ag-custom-overlay"><i class="fa fa-info-circle fa-lg margin-right10"></i>No record found</span>'
        };
    };
    ////////////////////////////////////////////////////////
    /// Column Definition functions
    ////////////////////////////////////////////////////////
    KdTableSvcBase.prototype.generateColumnDefinitions = function (_columnConfig, _gridConfig, _suppressMovableColumns) {
        if (_suppressMovableColumns === void 0) { _suppressMovableColumns = true; }
        var columnDef = this._generateColDefsFromColConfig(_columnConfig, _gridConfig, _suppressMovableColumns);
        var columnObjects = this._generateColDefsFromConfig(_gridConfig);
        if (columnObjects.hasOwnProperty('action')) {
            columnDef.push(columnObjects.action);
        }
        if (columnObjects.hasOwnProperty('selection')) {
            columnDef.unshift(columnObjects.selection);
        }
        return columnDef;
    };
    KdTableSvcBase.prototype.isColDefOfType = function (_colDef, _type) {
        if (typeof _colDef.cellRendererParams !== 'undefined' &&
            typeof _colDef.cellRendererParams.params !== 'undefined' &&
            typeof _colDef.cellRendererParams.params[_type] !== 'undefined') {
            return true;
        }
        return false;
    };
    ////////////////////////////////////////////////////////
    /// Misc function
    ////////////////////////////////////////////////////////
    KdTableSvcBase.prototype.generateContextKey = function (_gridId, _columnId, _rowId) {
        return _gridId + this.CONTEXT_DELIMITER + _columnId + this.CONTEXT_DELIMITER + _rowId;
    };
    /********** End of protected functions / Start of private functions **********/
    ////////////////////////////////////////////////////////
    /// ColDef - Column definition functions
    ////////////////////////////////////////////////////////
    KdTableSvcBase.prototype._generateColDefsFromColConfig = function (_columnConfig, _gridConfig, _suppressMovableColumns) {
        if (_suppressMovableColumns === void 0) { _suppressMovableColumns = true; }
        var columnDef = [];
        for (var i = 0; i < _columnConfig.length; i++) {
            var column = {};
            if (typeof _columnConfig[i] !== 'undefined') {
                var tempColumn = Object.assign(this._getDefaultColumnConfig(), _columnConfig[i]);
                tempColumn.suppressMovable = _suppressMovableColumns;
                switch (tempColumn.type) {
                    case 'input':
                        column = this._generateInputColDef(tempColumn, _gridConfig.id);
                        break;
                    case 'image':
                        column = this._generateImageColDef(tempColumn);
                        break;
                    default:
                        // TEMP fix for pivot
                        // value assignment instead of object direct assignment so to allow application to pass in other coldef
                        column = tempColumn;
                        column.headerName = tempColumn.headerName;
                        column.colId = tempColumn.field;
                        column.field = tempColumn.field;
                        column.cellClass = 'normal-cell ' + tempColumn.class;
                        column.hide = !tempColumn.visible;
                        column.suppressMenu = !tempColumn.filterable;
                        column.suppressSorting = !tempColumn.sortable;
                        column.minWidth = 100;
                        column.suppressMovable = tempColumn.suppressMovable;
                }
                if (tempColumn.filterable) {
                    this._updateFilterColDef(column, tempColumn.filterValue);
                }
            }
            columnDef.push(column);
        }
        return columnDef;
    };
    KdTableSvcBase.prototype._generateColDefsFromConfig = function (_config) {
        var colDefObject = {};
        if (typeof _config !== 'undefined' &&
            typeof _config.action !== 'undefined' &&
            _config.action.enabled) {
            colDefObject.action = this._generateActionColDef(_config.id, _config.action.list, _config.action.name);
        }
        if (typeof _config !== 'undefined' &&
            typeof _config.selection !== 'undefined' &&
            typeof _config.selection.type !== 'undefined') {
            colDefObject.selection = this._generateCheckboxRadioColDef(_config.selection, _config.id);
        }
        return colDefObject;
    };
    ////////////////////////////////////////////////////////
    /// ColDef - Action dropdown functions
    ////////////////////////////////////////////////////////
    KdTableSvcBase.prototype._generateActionColDef = function (_id, _list, _name) {
        return {
            headerName: (typeof _name !== 'undefined') ? _name : 'Action',
            suppressSorting: true,
            suppressFilter: true,
            suppressSizeToFit: true,
            suppressResize: true,
            suppressMenu: true,
            width: 120,
            minWidth: 120,
            maxWidth: 120,
            cellClass: 'dropdown-action',
            colId: 'ag-action',
            cellRendererFramework: KdTableAction,
            cellRendererParams: {
                params: _list,
                gridId: _id
            },
            suppressMovable: true
        };
    };
    ////////////////////////////////////////////////////////
    /// ColDef - Checkbox / Radio functions
    ////////////////////////////////////////////////////////
    KdTableSvcBase.prototype._generateCheckboxRadioColDef = function (_selectionObj, _gridId) {
        /// Have to set the type any as setting as ColDef will has issues
        /// on headerComponentFramework type is wrongly used.
        var checkboxRadioDirection = this.direction === 'ltr' ? 'left' : 'right';
        var tempColDef = {
            suppressSorting: true,
            suppressFilter: true,
            suppressSizeToFit: true,
            suppressMenu: true,
            suppressResize: true,
            width: 50,
            minWidth: 50,
            maxWidth: 50,
            cellClass: 'ag-default ag-checkbox-radio',
            pinned: checkboxRadioDirection,
            colId: (_selectionObj.type === 'single') ? 'radio' : 'checkbox',
            cellRendererFramework: KdTableCheckboxRadio,
            cellRendererParams: {
                params: {
                    inputType: (_selectionObj.type === 'single') ? 'radio' : 'checkbox',
                    default: _selectionObj.value,
                    gridId: _gridId
                }
            },
            suppressMovable: true
        };
        if (_selectionObj.type === 'all') {
            tempColDef.headerComponentFramework = KdTableCheckboxRadio;
            tempColDef.headerComponentParams = {
                params: {
                    default: _selectionObj.value,
                    gridId: _gridId
                }
            };
        }
        return tempColDef;
    };
    ////////////////////////////////////////////////////////
    /// ColDef - Table Image functions
    ////////////////////////////////////////////////////////
    KdTableSvcBase.prototype._generateImageColDef = function (_tempColumn) {
        var _a;
        var width = this.getImageSizeBy(_tempColumn, 'width');
        return {
            headerName: _tempColumn.headerName,
            field: _tempColumn.field,
            colId: _tempColumn.field,
            suppressSorting: true,
            suppressFilter: true,
            suppressMenu: true,
            suppressResize: true,
            hide: !_tempColumn.visible,
            minWidth: width,
            maxWidth: width,
            cellClass: _tempColumn.class,
            cellRendererFramework: KdTableImage,
            cellRendererParams: {
                params: (_a = {},
                    _a[this.GIRD_PARAMS_KEY.image] = _tempColumn.config.image,
                    _a)
            },
            suppressMovable: _tempColumn.suppressMovable
        };
    };
    ////////////////////////////////////////////////////////
    /// ColDef - Table Input functions
    ////////////////////////////////////////////////////////
    KdTableSvcBase.prototype._generateInputColDef = function (_tempColumn, _gridId) {
        var _a;
        return {
            headerName: _tempColumn.headerName,
            field: _tempColumn.field,
            suppressSorting: true,
            suppressFilter: true,
            suppressMenu: true,
            minWidth: 250,
            hide: !_tempColumn.visible,
            cellClass: _tempColumn.class,
            colId: _tempColumn.field,
            cellRendererFramework: KdTableInput,
            cellRendererParams: {
                params: (_a = {},
                    _a[this.GIRD_PARAMS_KEY.input] = _tempColumn.config,
                    _a.gridId = _gridId,
                    _a.contextKey = this.TABLE_INPUT_CONTEXT_KEY,
                    _a)
            },
            suppressMovable: _tempColumn.suppressMovable
        };
    };
    ////////////////////////////////////////////////////////
    /// API generation functions
    ////////////////////////////////////////////////////////
    KdTableSvcBase.prototype._generateInputApi = function (_gridId, _kdTableIntEvent) {
        var _this = this;
        return {
            getProperty: function (_tableParams) {
                var eventString = _this.generateContextKey(_gridId, _tableParams.colId, _tableParams.rowId);
                return _this.gridOptions.context.tableIndexContext[eventString][_tableParams.questionKey][_tableParams.property];
            },
            setProperty: function (_tableParams) {
                var eventString = _this.generateContextKey(_gridId, _tableParams.colId, _tableParams.rowId);
                if (typeof _this.gridOptions.context.tableInputContext[eventString] !== 'undefined') {
                    _this.gridOptions.context.tableInputContext[eventString][_tableParams.questionKey][_tableParams.property] = _tableParams.data;
                }
                var rowNode = _this.gridOptions.api.getRowNode(_tableParams.rowId.toString());
                if (_tableParams.property === 'visible') {
                    rowNode.setRowHeight(undefined);
                    /// Issues - Calling this api onRowHeightChanged causing the current input cell to lose focus
                    _this.gridOptions.api.onRowHeightChanged();
                }
                if (_tableParams.property === 'value') {
                    rowNode.data[_tableParams.colId][_tableParams.questionKey] = _tableParams.data;
                }
            }
        };
    };
    KdTableSvcBase.prototype._generateGeneralApi = function (_row) {
        var _this = this;
        return {
            getCurrentRows: function () {
                return _row.slice();
            },
            resetRowHeight: function () {
                _this.gridOptions.api.resetRowHeights();
            },
            setColumnVisible: function (_colId, _visible) {
                _this.gridOptions.columnApi.setColumnVisible(_colId, _visible);
            }
        };
    };
    ////////////////////////////////////////////////////////
    /// Table Input functions
    ////////////////////////////////////////////////////////
    /**
     * [_generateTableInputContext
     *     Generate the input configurations and values to the context of the gridOptions.
     *     All input configurations will be stored in tableInputContext (gridOptions.context.tableInputContext)
     *     Structure is as follows:
     *         delimiter: ~
     *         contextKey: [gridId][delimiter][columnId][delimiter][rowId]
     *             (e.g. tableForm~inputColumn~1)
     *         question: {
     *             questionKey: question configurations,
     *             questionKey: question configurations
     *         }
     *             (e.g. {
     *                 inputKey: {
     *                     controlType: 'text',
     *                     key: 'inputKey',
     *                     visible: true,
     *                     disabled: false,
     *                     value: 'Text'
     *                 },
     *                 dropdownKey: {
     *                     controlType: 'dropdown',
     *                     key: 'dropdownKey',
     *                     visible: true,
     *                     value: '1',
     *                     options: [
     *                         {
     *                             key: '',
     *                             value: '-- Please select --'
     *                         },
     *                         {
     *                             key: '1',
     *                             value: 'Female'
     *                         },
     *                         {
     *                             key: '2',
     *                             value: 'Male'
     *                         }
     *                     ]
     *                 }
     *             })
     *
     *
     *         context.tableInputContext[contextKey] = question
     * ]
     * _column    : [Column configurations]
     * _row       : [Row data]
     * _gridId    : [Grid ID]
     */
    KdTableSvcBase.prototype._generateTableInputContext = function (_column, _row, _gridId) {
        var tableInputContext = {};
        for (var i = 0; i < _column.length; ++i) {
            if (this.isInputType(_column[i], 'input')) {
                var currentColumn = _column[i];
                var currentColumnId = currentColumn.field;
                for (var j = 0; j < _row.length; ++j) {
                    if (typeof _row[j][this.rowKey] !== 'undefined') {
                        var contextObject = {};
                        // console.log('-------------------------------------------');
                        // console.log('currentColumn - ', currentColumn);
                        // console.log('currentColumnId - ', currentColumnId);
                        // console.log('_row[j] - ', _row[j]);
                        // Set the row data with the column key if is not defined
                        if (typeof _row[j][currentColumnId] === 'undefined') {
                            _row[j][currentColumnId] = {};
                        }
                        // Set the input to the contextObject
                        if (typeof currentColumn.config !== 'undefined' && typeof currentColumn.config.input !== 'undefined') {
                            var processInputData = (currentColumn.config.input instanceof Array) ? currentColumn.config.input : [currentColumn.config.input];
                            var rowColumnData = _row[j][currentColumnId];
                            for (var k = 0; k < processInputData.length; ++k) {
                                // Set the row data input key value if no input key of the column is defined
                                if (typeof rowColumnData[processInputData[k].key] === 'undefined') {
                                    rowColumnData[processInputData[k].key] = '';
                                }
                                contextObject[processInputData[k].key] = Object.assign({}, processInputData[k]);
                                contextObject[processInputData[k].key].value = rowColumnData[processInputData[k].key];
                            }
                        }
                        else {
                            console.error('KdTable error - Column specify as input but no config passed in. No input will be generated.');
                        }
                        var contextKey = this.generateContextKey(_gridId, currentColumnId, _row[j][this.rowKey]);
                        tableInputContext[contextKey] = Object.assign({}, contextObject);
                    }
                    else {
                        console.error('KdTable error - Row passed in with no rowKey (' + this.rowKey + '). Input cell component requires rowKey to generate.');
                    }
                }
            }
        }
        return tableInputContext;
    };
    ////////////////////////////////////////////////////////
    /// Selection function - Return value functions
    ////////////////////////////////////////////////////////
    /**
     * [_convertDataValueToObject - Convert return from dot separated to object value. Example:
     *     - From: "instutition_id.instutition_name": "Anderson Primary School";
     *     - To  : instutition_id: {
     *                 instutition_name:"Anderson Primary School"
     *             };
     * ]
     * _currentItem    : [Current selection key]
     * _objKey         : [Dot separated object keys]
     * _value          : [Data value for the object]
     *
     */
    KdTableSvcBase.prototype._convertDataValueToObject = function (_currentItem, _objKey, _value, _separator) {
        if (_separator === void 0) { _separator = '.'; }
        var objectKeyArr = _objKey.split(_separator);
        return this._appendDataValueKey(objectKeyArr, _currentItem, _value);
    };
    KdTableSvcBase.prototype._appendDataValueKey = function (_key, _currentObj, _value) {
        if (_key.length > 0) {
            var currentKey = _key[0];
            if (typeof _currentObj[currentKey] === 'undefined') {
                _currentObj[currentKey] = {};
            }
            _key.shift();
            _currentObj[currentKey] = this._appendDataValueKey(_key, _currentObj[currentKey], _value);
        }
        else {
            _currentObj = _value;
        }
        return _currentObj;
    };
    ////////////////////////////////////////////////////////
    /// Misc functions
    ////////////////////////////////////////////////////////
    KdTableSvcBase.prototype._updateFilterColDef = function (_colDef, _filterVal) {
        _colDef.menuTabs = ['filterMenuTab'];
        _colDef.filter = 'agSetColumnFilter';
        _colDef.filterParams = {
            newRowsAction: 'keep',
            cellHeight: 30,
            selectAllOnMiniFilter: true
        };
        if (typeof _filterVal !== 'undefined') {
            _colDef.filterParams.values = _filterVal;
        }
    };
    KdTableSvcBase.prototype._getDefaultColumnConfig = function () {
        return {
            sortable: false,
            filterable: false,
            visible: true,
        };
    };
    KdTableSvcBase = __decorate([
        Injectable()
    ], KdTableSvcBase);
    return KdTableSvcBase;
}());
export { KdTableSvcBase };
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoia2QtdGFibGUtc3ZjLmpzIiwic291cmNlUm9vdCI6Im5nOi8vb3BlbmVtaXMtc3R5bGVndWlkZS1saWIvIiwic291cmNlcyI6WyJrZC1jb21wb25lbnRzL2tkLWFuZ3VsYXItdGFibGUvdGFibGUtc2VydmljZXMva2QtdGFibGUtc3ZjLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7QUFBQSxPQUFPLEVBQUUsVUFBVSxFQUFFLE1BQU0sZUFBZSxDQUFDO0FBbUIzQyxPQUFPLEVBQUUsYUFBYSxFQUFFLE1BQU0scUNBQXFDLENBQUM7QUFDcEUsT0FBTyxFQUFFLG9CQUFvQixFQUFFLE1BQU0sNkNBQTZDLENBQUM7QUFDbkYsT0FBTyxFQUFFLFlBQVksRUFBRSxNQUFNLG9DQUFvQyxDQUFDO0FBQ2xFLE9BQU8sRUFBRSxZQUFZLEVBQUUsTUFBTSxvQ0FBb0MsQ0FBQztBQUlsRSxPQUFPLEVBQUUsU0FBUyxFQUFFLE1BQU0sdUJBQXVCLENBQUM7QUFFbEQ7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztHQXNERztBQUdIO0lBQUE7UUFDSSw4RUFBOEU7UUFDckUsZUFBVSxHQUFXLEVBQUUsQ0FBQztRQUN4QixzQkFBaUIsR0FBVyxHQUFHLENBQUM7UUFDaEMsNEJBQXVCLEdBQVcsbUJBQW1CLENBQUM7UUFDdEQscUJBQWdCLEdBQVcsRUFBRSxDQUFDO1FBQzlCLGtCQUFhLEdBQVcsRUFBRSxDQUFDO1FBQzNCLG1CQUFjLEdBQVcsZUFBZSxDQUFDO1FBQ3pDLG9CQUFlLEdBQThCO1lBQ2xELEtBQUssRUFBRSxhQUFhO1lBQ3BCLEtBQUssRUFBRSxhQUFhO1NBQ3ZCLENBQUM7UUFFUSxZQUFPLEdBQWMsSUFBSSxTQUFTLEVBQUUsQ0FBQztRQUdyQyxXQUFNLEdBQVcsSUFBSSxDQUFDO1FBK3JCaEMsK0VBQStFO0lBQ25GLENBQUM7SUE5ckJHLDhFQUE4RTtJQUM5RSx3REFBd0Q7SUFDeEQsc0JBQXNCO0lBQ3RCLHdEQUF3RDtJQUNqRCxtQ0FBVSxHQUFqQixVQUFrQixZQUF5QjtRQUN2QyxJQUFJLE9BQU8sWUFBWSxLQUFLLFdBQVc7WUFDbkMsWUFBWSxLQUFLLElBQUk7WUFDckIsT0FBTyxZQUFZLENBQUMsR0FBRyxLQUFLLFdBQVcsRUFBRTtZQUN6QyxPQUFPLElBQUksQ0FBQztTQUNmO1FBQ0QsT0FBTyxLQUFLLENBQUM7SUFDakIsQ0FBQztJQUVNLHdDQUFlLEdBQXRCLFVBQXVCLFdBQXlCO1FBQzVDLElBQUksT0FBTyxXQUFXLEtBQUssV0FBVztZQUNsQyxPQUFPLFdBQVcsQ0FBQyxTQUFTLEtBQUssV0FBVztZQUM1QyxPQUFPLFdBQVcsQ0FBQyxTQUFTLENBQUMsSUFBSSxLQUFLLFdBQVc7WUFDakQsV0FBVyxDQUFDLFNBQVMsQ0FBQyxJQUFJLEtBQUssS0FBSztZQUNwQyxXQUFXLENBQUMsUUFBUSxLQUFLLFVBQVUsRUFBRTtZQUNyQyxPQUFPLElBQUksQ0FBQztTQUNmO1FBRUQsT0FBTyxLQUFLLENBQUM7SUFDakIsQ0FBQztJQUVNLHFDQUFZLEdBQW5CLFVBQW9CLFlBQWlDLEVBQUUsS0FBYTtRQUNoRSxJQUFJLE9BQU8sWUFBWSxLQUFLLFdBQVcsRUFBRTtZQUNyQyxLQUFLLElBQUksQ0FBQyxHQUFXLENBQUMsRUFBRSxDQUFDLEdBQUcsWUFBWSxDQUFDLE1BQU0sRUFBRSxFQUFFLENBQUMsRUFBRTtnQkFDbEQsSUFBSSxJQUFJLENBQUMsV0FBVyxDQUFDLFlBQVksQ0FBQyxDQUFDLENBQUMsRUFBRSxLQUFLLENBQUMsRUFBRTtvQkFDMUMsT0FBTyxJQUFJLENBQUM7aUJBQ2Y7YUFDSjtTQUNKO1FBRUQsT0FBTyxLQUFLLENBQUM7SUFDakIsQ0FBQztJQUVNLG9DQUFXLEdBQWxCLFVBQW1CLE9BQXFCLEVBQUUsS0FBYTtRQUNuRCxPQUFPLENBQUMsT0FBTyxPQUFPLENBQUMsSUFBSSxLQUFLLFdBQVcsSUFBSSxPQUFPLENBQUMsSUFBSSxLQUFLLEtBQUssQ0FBQyxDQUFDO0lBQzNFLENBQUM7SUFFTSwwQ0FBaUIsR0FBeEIsVUFBeUIsU0FBaUI7UUFDdEMsT0FBTyxDQUFDLFNBQVMsS0FBSyxTQUFTLElBQUksU0FBUyxLQUFLLFVBQVUsSUFBSSxTQUFTLEtBQUssUUFBUSxDQUFDLENBQUM7SUFDM0YsQ0FBQztJQUVELHdEQUF3RDtJQUN4RCx1QkFBdUI7SUFDdkIsd0RBQXdEO0lBQ2pELGlEQUF3QixHQUEvQixVQUFnQyxXQUF5QjtRQUNyRCxJQUFJLE9BQU8sV0FBVyxDQUFDLFNBQVMsS0FBSyxXQUFXLEVBQUU7WUFDOUMsSUFBSSxPQUFPLFdBQVcsQ0FBQyxTQUFTLENBQUMsS0FBSyxLQUFLLFdBQVcsRUFBRTtnQkFDcEQsV0FBVyxDQUFDLFNBQVMsQ0FBQyxLQUFLLEdBQUcsRUFBRSxDQUFDO2FBQ3BDO2lCQUNJLElBQUksV0FBVyxDQUFDLFNBQVMsQ0FBQyxJQUFJLEtBQUssUUFBUSxJQUFJLFdBQVcsQ0FBQyxTQUFTLENBQUMsS0FBSyxDQUFDLE1BQU0sR0FBRyxDQUFDLEVBQUU7Z0JBQ3hGLE9BQU8sQ0FBQyxJQUFJLENBQUMsNkVBQTZFLENBQUMsQ0FBQztnQkFDNUYsV0FBVyxDQUFDLFNBQVMsQ0FBQyxLQUFLLEdBQUcsV0FBVyxDQUFDLFNBQVMsQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQzthQUN6RTtTQUNKO0lBQ0wsQ0FBQztJQUVEOzs7Ozs7Ozs7OztPQVdHO0lBQ0ksOENBQXFCLEdBQTVCLFVBQTZCLFFBQW9CLEVBQUUsWUFBb0MsRUFBRSxVQUF5QixFQUFFLFNBQWtCO1FBQ2xJLElBQUksT0FBTyxVQUFVLEtBQUssV0FBVztZQUNqQyxVQUFVLEtBQUssSUFBSTtZQUNuQixVQUFVLENBQUMsTUFBTSxLQUFLLENBQUMsRUFBRTtZQUN6QixPQUFPLFlBQVksQ0FBQztTQUN2QjtRQUVELElBQUksa0JBQWtCLEdBQWUsRUFBRSxDQUFDO1FBRXhDLEtBQUssSUFBSSxDQUFDLEdBQVcsQ0FBQyxFQUFFLENBQUMsR0FBRyxRQUFRLENBQUMsTUFBTSxFQUFFLENBQUMsRUFBRSxFQUFFO1lBQzlDLElBQUksUUFBUSxHQUFRLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQztZQUNoQyxJQUFJLE9BQU8sR0FBUSxFQUFFLENBQUM7WUFFdEIsSUFBSSxZQUFZLENBQUMsT0FBTyxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsRUFBRTtnQkFDbEQsT0FBTyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsR0FBRyxRQUFRLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDO2dCQUU3QyxLQUFLLElBQUksQ0FBQyxHQUFXLENBQUMsRUFBRSxDQUFDLEdBQUcsVUFBVSxDQUFDLE1BQU0sRUFBRSxDQUFDLEVBQUUsRUFBRTtvQkFDaEQsSUFBSSxRQUFRLENBQUMsY0FBYyxDQUFDLFVBQVUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFO3dCQUN4QyxPQUFPLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsUUFBUSxDQUFDLFVBQVUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO3FCQUNwRDt5QkFDSSxJQUFJLFVBQVUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxFQUFFO3dCQUNyQyxJQUFJLFNBQVMsR0FBUSxJQUFJLENBQUMsT0FBTyxDQUFDLFlBQVksQ0FBQyxRQUFRLEVBQUUsVUFBVSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7d0JBRXhFLElBQUksU0FBUyxLQUFLLElBQUksRUFBRTs0QkFDcEIsSUFBSSxPQUFPLEdBQWMsTUFBTyxDQUFDLE1BQU0sQ0FBQyxFQUFFLEVBQUUsT0FBTyxDQUFDLENBQUM7NEJBQ3JELE9BQU8sR0FBRyxJQUFJLENBQUMseUJBQXlCLENBQUMsT0FBTyxFQUFFLFVBQVUsQ0FBQyxDQUFDLENBQUMsRUFBRSxTQUFTLENBQUMsQ0FBQzt5QkFDL0U7cUJBQ0o7aUJBQ0o7Z0JBRUQsa0JBQWtCLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxDQUFDO2FBQ3BDO1NBQ0o7UUFFRCxPQUFPLGtCQUFrQixDQUFDO0lBQzlCLENBQUM7SUFFRCx3REFBd0Q7SUFDeEQseUJBQXlCO0lBQ3pCLHdEQUF3RDtJQUNqRCwwQ0FBaUIsR0FBeEIsVUFBeUIsV0FBeUI7UUFDOUMsSUFBSSxPQUFPLFdBQVcsQ0FBQyxNQUFNLEtBQUssV0FBVyxFQUFFO1lBQzNDLFdBQVcsQ0FBQyxNQUFNLEdBQUcsRUFBRSxDQUFDO1NBQzNCO2FBQ0ksSUFBSSxXQUFXLENBQUMsTUFBTSxDQUFDLE1BQU0sR0FBRyxDQUFDLEVBQUU7WUFDcEMsT0FBTyxDQUFDLElBQUksQ0FBQyx5REFBeUQsQ0FBQyxDQUFDO1lBQ3hFLFdBQVcsQ0FBQyxNQUFNLEdBQUcsV0FBVyxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDO1NBQ3ZEO0lBQ0wsQ0FBQztJQUVELHdEQUF3RDtJQUN4RCx5QkFBeUI7SUFDekIsd0RBQXdEO0lBQ2pELGdEQUF1QixHQUE5QixVQUErQixRQUFvQixFQUFFLGFBQWtDLEVBQUUsT0FBZSxFQUFFLFlBQXlCO1FBQy9ILElBQUksSUFBSSxDQUFDLFlBQVksQ0FBQyxhQUFhLEVBQUUsT0FBTyxDQUFDLEVBQUU7WUFDM0MsSUFBSSxPQUFPLFlBQVksQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLHVCQUF1QixDQUFDLEtBQUssV0FBVyxFQUFFO2dCQUMzRSxZQUFZLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyx1QkFBdUIsQ0FBQyxHQUFHLEVBQUUsQ0FBQzthQUMzRDtZQUVELElBQUksWUFBWSxHQUFRLElBQUksQ0FBQywwQkFBMEIsQ0FBQyxhQUFhLEVBQUUsUUFBUSxFQUFFLE9BQU8sQ0FBQyxDQUFDO1lBQzFGLFlBQVksQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLHVCQUF1QixDQUFDLEdBQVMsTUFBTyxDQUFDLE1BQU0sQ0FBQyxZQUFZLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyx1QkFBdUIsQ0FBQyxFQUFFLFlBQVksQ0FBQyxDQUFDO1NBQy9JO0lBQ0wsQ0FBQztJQUVELHdEQUF3RDtJQUN4RCwyQkFBMkI7SUFDM0Isd0RBQXdEO0lBQ2pELDhDQUFxQixHQUE1QixVQUE2QixRQUFtQixFQUFFLFVBQWU7UUFDN0QsUUFBUSxDQUFDLFdBQVcsR0FBRyxJQUFJLENBQUMsaUJBQWlCLENBQUMsVUFBVSxDQUFDLEVBQUUsRUFBRSxVQUFVLENBQUMsS0FBSyxDQUFDLENBQUM7UUFDL0UsUUFBUSxDQUFDLE9BQU8sR0FBRyxJQUFJLENBQUMsbUJBQW1CLENBQUMsVUFBVSxDQUFDLElBQUksQ0FBQyxDQUFDO0lBQ2pFLENBQUM7SUFFRCx3REFBd0Q7SUFDeEQsaUJBQWlCO0lBQ2pCLHdEQUF3RDtJQUNqRCxrQ0FBUyxHQUFoQixVQUFpQixXQUF5QjtRQUN0QyxJQUFJLE9BQU8sV0FBVyxDQUFDLEVBQUUsS0FBSyxXQUFXLEVBQUU7WUFDdkMsV0FBVyxDQUFDLEVBQUUsR0FBRyxJQUFJLENBQUMsY0FBYyxDQUFDO1NBQ3hDO1FBRUQsT0FBTyxXQUFXLENBQUMsRUFBRSxDQUFDO0lBQzFCLENBQUM7SUFFTSx1Q0FBYyxHQUFyQixVQUFzQixZQUEwQixFQUFFLFVBQThCO1FBQzVFLHlDQUF5QztRQUN6QyxJQUFJLEtBQUssR0FBVyxHQUFHLEdBQUcsSUFBSSxDQUFDLGFBQWEsQ0FBQztRQUU3QyxJQUFJLE9BQU8sWUFBWSxDQUFDLE1BQU0sS0FBSyxXQUFXO1lBQzFDLE9BQU8sWUFBWSxDQUFDLE1BQU0sQ0FBQyxLQUFLLEtBQUssV0FBVztZQUNoRCxPQUFPLFlBQVksQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLFVBQVUsQ0FBQyxLQUFLLFdBQVcsRUFBRTtZQUM5RCxLQUFLLEdBQUcsWUFBWSxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsVUFBVSxDQUFDLEdBQUcsSUFBSSxDQUFDLGFBQWEsQ0FBQztTQUN0RTtRQUVELE9BQU8sS0FBSyxDQUFDO0lBQ2pCLENBQUM7SUFFTSwyQ0FBa0IsR0FBekI7UUFDSSxPQUFPLElBQUksQ0FBQyx1QkFBdUIsQ0FBQztJQUN4QyxDQUFDO0lBRU0saURBQXdCLEdBQS9CLFVBQWdDLFFBQWlCLEVBQUUsS0FBYTtRQUM1RCxPQUFPLElBQUksQ0FBQyxPQUFPLENBQUMsY0FBYyxDQUFDLFFBQVEsQ0FBQyxJQUFJLEVBQUUsS0FBSyxDQUFDLENBQUM7SUFDN0QsQ0FBQztJQUVNLGtDQUFTLEdBQWhCLFVBQWlCLE9BQVksRUFBRSxXQUFtQjtRQUM5QyxJQUFJLFNBQVMsR0FBVyxHQUFHLENBQUM7UUFFNUIsSUFBSSxjQUFjLEdBQVEsSUFBSSxDQUFDLE9BQU8sQ0FBQyxDQUFDO1FBQ3hDLElBQUksVUFBVSxHQUFVLEVBQUUsQ0FBQztRQUUzQixLQUFLLElBQUksTUFBTSxHQUFHLENBQUMsRUFBRSxNQUFNLEdBQUcsY0FBYyxDQUFDLE1BQU0sRUFBRSxNQUFNLElBQUksU0FBUyxFQUFFO1lBQ3RFLElBQUksS0FBSyxHQUFRLGNBQWMsQ0FBQyxLQUFLLENBQUMsTUFBTSxFQUFFLE1BQU0sR0FBRyxTQUFTLENBQUMsQ0FBQztZQUVsRSxJQUFJLFdBQVcsR0FBVSxJQUFJLEtBQUssQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLENBQUM7WUFDakQsS0FBSyxJQUFJLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxHQUFHLEtBQUssQ0FBQyxNQUFNLEVBQUUsQ0FBQyxFQUFFLEVBQUU7Z0JBQ25DLFdBQVcsQ0FBQyxDQUFDLENBQUMsR0FBRyxLQUFLLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQyxDQUFDO2FBQ3hDO1lBRUQsSUFBSSxTQUFTLEdBQWUsSUFBSSxVQUFVLENBQUMsV0FBVyxDQUFDLENBQUM7WUFFeEQsVUFBVSxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsQ0FBQztTQUM5QjtRQUVELElBQUksSUFBSSxHQUFTLElBQUksSUFBSSxDQUFDLFVBQVUsRUFBRSxFQUFFLElBQUksRUFBRSxXQUFXLEVBQUUsQ0FBQyxDQUFDO1FBQzdELE9BQU8sSUFBSSxDQUFDO0lBQ2hCLENBQUM7SUFFRCw4RUFBOEU7SUFDOUUsd0RBQXdEO0lBQ3hELDBCQUEwQjtJQUMxQix3REFBd0Q7SUFDOUMsOENBQXFCLEdBQS9CLFVBQWdDLFVBQXlCLEVBQUUsVUFBa0I7UUFDekUsSUFBSSxDQUFDLFNBQVMsR0FBRyxVQUFVLENBQUM7UUFFNUIsT0FBTztZQUNILE9BQU8sRUFBRSxFQUFFO1lBQ1gsVUFBVSxFQUFFLEVBQUU7WUFDZCxTQUFTLEVBQUUsVUFBVSxLQUFLLEtBQUs7WUFFL0IsWUFBWSxFQUFFLEVBQUU7WUFDaEIsU0FBUyxFQUFFLENBQUMsT0FBTyxVQUFVLEtBQUssV0FBVyxDQUFDLENBQUMsQ0FBQyxDQUFDLFVBQVUsR0FBRyxFQUFFLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxVQUFVO1lBRWxGLGdDQUFnQztZQUNoQyw2QkFBNkIsRUFBRSxJQUFJO1lBQ25DLGVBQWUsRUFBRSxJQUFJO1lBRXJCLG1CQUFtQixFQUFFLElBQUk7WUFDekIsZ0JBQWdCLEVBQUUsSUFBSTtZQUN0QixjQUFjLEVBQUUsSUFBSTtZQUVwQiwwQkFBMEIsRUFBRSxJQUFJO1lBRWhDLHNDQUFzQztZQUV0QyxXQUFXLEVBQUUsS0FBSztZQUNsQixTQUFTLEVBQUUsQ0FBQztZQUVaLFlBQVksRUFBRSxVQUFDLEtBQVU7Z0JBQ3JCLElBQUksRUFBRSxHQUFXLEtBQUssQ0FBQyxFQUFFLENBQUM7Z0JBRTFCLElBQUksT0FBTyxLQUFLLENBQUMsRUFBRSxLQUFLLFFBQVEsRUFBRTtvQkFDOUIsRUFBRSxHQUFHLEVBQUUsQ0FBQyxRQUFRLEVBQUUsQ0FBQztpQkFDdEI7Z0JBRUQsT0FBTyxFQUFFLENBQUM7WUFDZCxDQUFDO1lBRUQsVUFBVSxFQUFFLElBQUk7WUFDaEIsS0FBSyxFQUFFO2dCQUNILE1BQU0sRUFBRSwyQkFBMkI7Z0JBQ25DLGFBQWEsRUFBRSwrQkFBK0I7Z0JBQzlDLGNBQWMsRUFBRSw2QkFBNkI7Z0JBQzdDLFVBQVUsRUFBRSx5QkFBeUI7Z0JBQ3JDLG9EQUFvRDtnQkFDcEQscURBQXFEO2dCQUNyRCxhQUFhLEVBQUUsK0JBQStCO2dCQUM5QyxlQUFlLEVBQUUsZ0NBQWdDO2dCQUVqRCxJQUFJLEVBQUUseUJBQXlCO2FBQ2xDO1lBQ0Qsa0JBQWtCLEVBQUU7Z0JBQ2hCLEtBQUssRUFBRTtvQkFDSCxJQUFJLEVBQUUsNkNBQTZDO2lCQUN0RDthQUNKO1lBQ0QsT0FBTyxFQUFFLEVBQUU7WUFDWCxxQkFBcUIsRUFBRSw4R0FBOEc7U0FDeEksQ0FBQztJQUNOLENBQUM7SUFFRCx3REFBd0Q7SUFDeEQsK0JBQStCO0lBQy9CLHdEQUF3RDtJQUM5QyxrREFBeUIsR0FBbkMsVUFBb0MsYUFBa0MsRUFBRSxXQUF5QixFQUFFLHVCQUFzQztRQUF0Qyx3Q0FBQSxFQUFBLDhCQUFzQztRQUNySSxJQUFJLFNBQVMsR0FBa0IsSUFBSSxDQUFDLDZCQUE2QixDQUFDLGFBQWEsRUFBRSxXQUFXLEVBQUUsdUJBQXVCLENBQUMsQ0FBQztRQUN2SCxJQUFJLGFBQWEsR0FBOEIsSUFBSSxDQUFDLDBCQUEwQixDQUFDLFdBQVcsQ0FBQyxDQUFDO1FBRTVGLElBQUksYUFBYSxDQUFDLGNBQWMsQ0FBQyxRQUFRLENBQUMsRUFBRTtZQUN4QyxTQUFTLENBQUMsSUFBSSxDQUFDLGFBQWEsQ0FBQyxNQUFNLENBQUMsQ0FBQztTQUN4QztRQUVELElBQUksYUFBYSxDQUFDLGNBQWMsQ0FBQyxXQUFXLENBQUMsRUFBRTtZQUMzQyxTQUFTLENBQUMsT0FBTyxDQUFDLGFBQWEsQ0FBQyxTQUFTLENBQUMsQ0FBQztTQUM5QztRQUVELE9BQU8sU0FBUyxDQUFDO0lBQ3JCLENBQUM7SUFFUyx1Q0FBYyxHQUF4QixVQUF5QixPQUFlLEVBQUUsS0FBYTtRQUNuRCxJQUFJLE9BQU8sT0FBTyxDQUFDLGtCQUFrQixLQUFLLFdBQVc7WUFDakQsT0FBTyxPQUFPLENBQUMsa0JBQWtCLENBQUMsTUFBTSxLQUFLLFdBQVc7WUFDeEQsT0FBTyxPQUFPLENBQUMsa0JBQWtCLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxLQUFLLFdBQVcsRUFBRTtZQUNqRSxPQUFPLElBQUksQ0FBQztTQUNmO1FBRUQsT0FBTyxLQUFLLENBQUM7SUFDakIsQ0FBQztJQUVELHdEQUF3RDtJQUN4RCxpQkFBaUI7SUFDakIsd0RBQXdEO0lBQzlDLDJDQUFrQixHQUE1QixVQUE2QixPQUFlLEVBQUUsU0FBaUIsRUFBRSxNQUF1QjtRQUNwRixPQUFPLE9BQU8sR0FBRyxJQUFJLENBQUMsaUJBQWlCLEdBQUcsU0FBUyxHQUFHLElBQUksQ0FBQyxpQkFBaUIsR0FBRyxNQUFNLENBQUM7SUFDMUYsQ0FBQztJQUVELCtFQUErRTtJQUMvRSx3REFBd0Q7SUFDeEQsd0NBQXdDO0lBQ3hDLHdEQUF3RDtJQUNoRCxzREFBNkIsR0FBckMsVUFBc0MsYUFBa0MsRUFBRSxXQUF5QixFQUFFLHVCQUF1QztRQUF2Qyx3Q0FBQSxFQUFBLDhCQUF1QztRQUN4SSxJQUFJLFNBQVMsR0FBa0IsRUFBRSxDQUFDO1FBRWxDLEtBQUssSUFBSSxDQUFDLEdBQVcsQ0FBQyxFQUFFLENBQUMsR0FBRyxhQUFhLENBQUMsTUFBTSxFQUFFLENBQUMsRUFBRSxFQUFFO1lBQ25ELElBQUksTUFBTSxHQUFXLEVBQUUsQ0FBQztZQUV4QixJQUFJLE9BQU8sYUFBYSxDQUFDLENBQUMsQ0FBQyxLQUFLLFdBQVcsRUFBRTtnQkFDekMsSUFBSSxVQUFVLEdBQXVCLE1BQU8sQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLHVCQUF1QixFQUFFLEVBQUUsYUFBYSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7Z0JBQ3RHLFVBQVUsQ0FBQyxlQUFlLEdBQUcsdUJBQXVCLENBQUM7Z0JBRXJELFFBQVEsVUFBVSxDQUFDLElBQUksRUFBRTtvQkFDckIsS0FBSyxPQUFPO3dCQUNSLE1BQU0sR0FBRyxJQUFJLENBQUMsb0JBQW9CLENBQUMsVUFBVSxFQUFFLFdBQVcsQ0FBQyxFQUFFLENBQUMsQ0FBQzt3QkFDL0QsTUFBTTtvQkFDVixLQUFLLE9BQU87d0JBQ1IsTUFBTSxHQUFHLElBQUksQ0FBQyxvQkFBb0IsQ0FBQyxVQUFVLENBQUMsQ0FBQzt3QkFDL0MsTUFBTTtvQkFDVjt3QkFDSSxxQkFBcUI7d0JBQ3JCLHVHQUF1Rzt3QkFDdkcsTUFBTSxHQUFHLFVBQVUsQ0FBQzt3QkFDcEIsTUFBTSxDQUFDLFVBQVUsR0FBRyxVQUFVLENBQUMsVUFBVSxDQUFDO3dCQUMxQyxNQUFNLENBQUMsS0FBSyxHQUFHLFVBQVUsQ0FBQyxLQUFLLENBQUM7d0JBQ2hDLE1BQU0sQ0FBQyxLQUFLLEdBQUcsVUFBVSxDQUFDLEtBQUssQ0FBQzt3QkFDaEMsTUFBTSxDQUFDLFNBQVMsR0FBRyxjQUFjLEdBQUcsVUFBVSxDQUFDLEtBQUssQ0FBQzt3QkFDckQsTUFBTSxDQUFDLElBQUksR0FBRyxDQUFDLFVBQVUsQ0FBQyxPQUFPLENBQUM7d0JBQ2xDLE1BQU0sQ0FBQyxZQUFZLEdBQUcsQ0FBQyxVQUFVLENBQUMsVUFBVSxDQUFDO3dCQUM3QyxNQUFNLENBQUMsZUFBZSxHQUFHLENBQUMsVUFBVSxDQUFDLFFBQVEsQ0FBQzt3QkFDOUMsTUFBTSxDQUFDLFFBQVEsR0FBRyxHQUFHLENBQUM7d0JBQ3RCLE1BQU0sQ0FBQyxlQUFlLEdBQUcsVUFBVSxDQUFDLGVBQWUsQ0FBQztpQkFDM0Q7Z0JBRUQsSUFBSSxVQUFVLENBQUMsVUFBVSxFQUFFO29CQUN2QixJQUFJLENBQUMsbUJBQW1CLENBQUMsTUFBTSxFQUFFLFVBQVUsQ0FBQyxXQUFXLENBQUMsQ0FBQztpQkFDNUQ7YUFDSjtZQUNELFNBQVMsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUM7U0FDMUI7UUFFRCxPQUFPLFNBQVMsQ0FBQztJQUNyQixDQUFDO0lBRU8sbURBQTBCLEdBQWxDLFVBQW1DLE9BQXFCO1FBQ3BELElBQUksWUFBWSxHQUE4QixFQUFFLENBQUM7UUFFakQsSUFBSSxPQUFPLE9BQU8sS0FBSyxXQUFXO1lBQzlCLE9BQU8sT0FBTyxDQUFDLE1BQU0sS0FBSyxXQUFXO1lBQ3JDLE9BQU8sQ0FBQyxNQUFNLENBQUMsT0FBTyxFQUFFO1lBQ3hCLFlBQVksQ0FBQyxNQUFNLEdBQUcsSUFBSSxDQUFDLHFCQUFxQixDQUFDLE9BQU8sQ0FBQyxFQUFFLEVBQUUsT0FBTyxDQUFDLE1BQU0sQ0FBQyxJQUFJLEVBQUUsT0FBTyxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsQ0FBQztTQUMxRztRQUVELElBQUksT0FBTyxPQUFPLEtBQUssV0FBVztZQUM5QixPQUFPLE9BQU8sQ0FBQyxTQUFTLEtBQUssV0FBVztZQUN4QyxPQUFPLE9BQU8sQ0FBQyxTQUFTLENBQUMsSUFBSSxLQUFLLFdBQVcsRUFBRTtZQUMvQyxZQUFZLENBQUMsU0FBUyxHQUFHLElBQUksQ0FBQyw0QkFBNEIsQ0FBQyxPQUFPLENBQUMsU0FBUyxFQUFFLE9BQU8sQ0FBQyxFQUFFLENBQUMsQ0FBQztTQUM3RjtRQUVELE9BQU8sWUFBWSxDQUFDO0lBQ3hCLENBQUM7SUFFRCx3REFBd0Q7SUFDeEQsc0NBQXNDO0lBQ3RDLHdEQUF3RDtJQUNoRCw4Q0FBcUIsR0FBN0IsVUFBOEIsR0FBVyxFQUFFLEtBQWtDLEVBQUUsS0FBYztRQUN6RixPQUFPO1lBQ0gsVUFBVSxFQUFFLENBQUMsT0FBTyxLQUFLLEtBQUssV0FBVyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsUUFBUTtZQUM3RCxlQUFlLEVBQUUsSUFBSTtZQUNyQixjQUFjLEVBQUUsSUFBSTtZQUNwQixpQkFBaUIsRUFBRSxJQUFJO1lBQ3ZCLGNBQWMsRUFBRSxJQUFJO1lBQ3BCLFlBQVksRUFBRSxJQUFJO1lBQ2xCLEtBQUssRUFBRSxHQUFHO1lBQ1YsUUFBUSxFQUFFLEdBQUc7WUFDYixRQUFRLEVBQUUsR0FBRztZQUNiLFNBQVMsRUFBRSxpQkFBaUI7WUFDNUIsS0FBSyxFQUFFLFdBQVc7WUFDbEIscUJBQXFCLEVBQUUsYUFBYTtZQUNwQyxrQkFBa0IsRUFBRTtnQkFDaEIsTUFBTSxFQUFFLEtBQUs7Z0JBQ2IsTUFBTSxFQUFFLEdBQUc7YUFDZDtZQUNELGVBQWUsRUFBRSxJQUFJO1NBQ3hCLENBQUM7SUFDTixDQUFDO0lBRUQsd0RBQXdEO0lBQ3hELHVDQUF1QztJQUN2Qyx3REFBd0Q7SUFDaEQscURBQTRCLEdBQXBDLFVBQXFDLGFBQWtCLEVBQUUsT0FBZTtRQUNwRSxpRUFBaUU7UUFDakUscURBQXFEO1FBRXJELElBQUksc0JBQXNCLEdBQVcsSUFBSSxDQUFDLFNBQVMsS0FBSyxLQUFLLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDO1FBRWpGLElBQUksVUFBVSxHQUFRO1lBQ2xCLGVBQWUsRUFBRSxJQUFJO1lBQ3JCLGNBQWMsRUFBRSxJQUFJO1lBQ3BCLGlCQUFpQixFQUFFLElBQUk7WUFDdkIsWUFBWSxFQUFFLElBQUk7WUFDbEIsY0FBYyxFQUFFLElBQUk7WUFDcEIsS0FBSyxFQUFFLEVBQUU7WUFDVCxRQUFRLEVBQUUsRUFBRTtZQUNaLFFBQVEsRUFBRSxFQUFFO1lBQ1osU0FBUyxFQUFFLDhCQUE4QjtZQUN6QyxNQUFNLEVBQUUsc0JBQXNCO1lBQzlCLEtBQUssRUFBRSxDQUFDLGFBQWEsQ0FBQyxJQUFJLEtBQUssUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsVUFBVTtZQUMvRCxxQkFBcUIsRUFBRSxvQkFBb0I7WUFDM0Msa0JBQWtCLEVBQUU7Z0JBQ2hCLE1BQU0sRUFBRTtvQkFDSixTQUFTLEVBQUUsQ0FBQyxhQUFhLENBQUMsSUFBSSxLQUFLLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLFVBQVU7b0JBQ25FLE9BQU8sRUFBRSxhQUFhLENBQUMsS0FBSztvQkFDNUIsTUFBTSxFQUFFLE9BQU87aUJBQ2xCO2FBQ0o7WUFDRCxlQUFlLEVBQUUsSUFBSTtTQUN4QixDQUFDO1FBRUYsSUFBSSxhQUFhLENBQUMsSUFBSSxLQUFLLEtBQUssRUFBRTtZQUM5QixVQUFVLENBQUMsd0JBQXdCLEdBQUcsb0JBQW9CLENBQUM7WUFDM0QsVUFBVSxDQUFDLHFCQUFxQixHQUFHO2dCQUMvQixNQUFNLEVBQUU7b0JBQ0osT0FBTyxFQUFFLGFBQWEsQ0FBQyxLQUFLO29CQUM1QixNQUFNLEVBQUUsT0FBTztpQkFDbEI7YUFDSixDQUFDO1NBQ0w7UUFFRCxPQUFPLFVBQVUsQ0FBQztJQUN0QixDQUFDO0lBRUQsd0RBQXdEO0lBQ3hELGtDQUFrQztJQUNsQyx3REFBd0Q7SUFDaEQsNkNBQW9CLEdBQTVCLFVBQTZCLFdBQXlCOztRQUNsRCxJQUFJLEtBQUssR0FBVyxJQUFJLENBQUMsY0FBYyxDQUFDLFdBQVcsRUFBRSxPQUFPLENBQUMsQ0FBQztRQUU5RCxPQUFPO1lBQ0gsVUFBVSxFQUFFLFdBQVcsQ0FBQyxVQUFVO1lBQ2xDLEtBQUssRUFBRSxXQUFXLENBQUMsS0FBSztZQUN4QixLQUFLLEVBQUUsV0FBVyxDQUFDLEtBQUs7WUFDeEIsZUFBZSxFQUFFLElBQUk7WUFDckIsY0FBYyxFQUFFLElBQUk7WUFDcEIsWUFBWSxFQUFFLElBQUk7WUFDbEIsY0FBYyxFQUFFLElBQUk7WUFDcEIsSUFBSSxFQUFFLENBQUMsV0FBVyxDQUFDLE9BQU87WUFDMUIsUUFBUSxFQUFFLEtBQUs7WUFDZixRQUFRLEVBQUUsS0FBSztZQUNmLFNBQVMsRUFBRSxXQUFXLENBQUMsS0FBSztZQUM1QixxQkFBcUIsRUFBRSxZQUFZO1lBQ25DLGtCQUFrQixFQUFFO2dCQUNoQixNQUFNO29CQUNGLEdBQUMsSUFBSSxDQUFDLGVBQWUsQ0FBQyxLQUFLLElBQUcsV0FBVyxDQUFDLE1BQU0sQ0FBQyxLQUFLO3VCQUN6RDthQUNKO1lBQ0QsZUFBZSxFQUFFLFdBQVcsQ0FBQyxlQUFlO1NBQy9DLENBQUM7SUFDTixDQUFDO0lBRUQsd0RBQXdEO0lBQ3hELGtDQUFrQztJQUNsQyx3REFBd0Q7SUFDaEQsNkNBQW9CLEdBQTVCLFVBQTZCLFdBQXlCLEVBQUUsT0FBZTs7UUFDbkUsT0FBTztZQUNILFVBQVUsRUFBRSxXQUFXLENBQUMsVUFBVTtZQUNsQyxLQUFLLEVBQUUsV0FBVyxDQUFDLEtBQUs7WUFDeEIsZUFBZSxFQUFFLElBQUk7WUFDckIsY0FBYyxFQUFFLElBQUk7WUFDcEIsWUFBWSxFQUFFLElBQUk7WUFDbEIsUUFBUSxFQUFFLEdBQUc7WUFDYixJQUFJLEVBQUUsQ0FBQyxXQUFXLENBQUMsT0FBTztZQUMxQixTQUFTLEVBQUUsV0FBVyxDQUFDLEtBQUs7WUFDNUIsS0FBSyxFQUFFLFdBQVcsQ0FBQyxLQUFLO1lBQ3hCLHFCQUFxQixFQUFFLFlBQVk7WUFDbkMsa0JBQWtCLEVBQUU7Z0JBQ2hCLE1BQU07b0JBQ0YsR0FBQyxJQUFJLENBQUMsZUFBZSxDQUFDLEtBQUssSUFBRyxXQUFXLENBQUMsTUFBTTtvQkFDaEQsU0FBTSxHQUFFLE9BQU87b0JBQ2YsYUFBVSxHQUFFLElBQUksQ0FBQyx1QkFBdUI7dUJBQzNDO2FBQ0o7WUFDRCxlQUFlLEVBQUUsV0FBVyxDQUFDLGVBQWU7U0FDL0MsQ0FBQztJQUNOLENBQUM7SUFFRCx3REFBd0Q7SUFDeEQsNEJBQTRCO0lBQzVCLHdEQUF3RDtJQUNoRCwwQ0FBaUIsR0FBekIsVUFBMEIsT0FBZSxFQUFFLGdCQUFpQztRQUE1RSxpQkEwQkM7UUF6QkcsT0FBTztZQUNILFdBQVcsRUFBRSxVQUFDLFlBQW9DO2dCQUM5QyxJQUFJLFdBQVcsR0FBRyxLQUFJLENBQUMsa0JBQWtCLENBQUMsT0FBTyxFQUFFLFlBQVksQ0FBQyxLQUFLLEVBQUUsWUFBWSxDQUFDLEtBQUssQ0FBQyxDQUFDO2dCQUMzRixPQUFPLEtBQUksQ0FBQyxXQUFXLENBQUMsT0FBTyxDQUFDLGlCQUFpQixDQUFDLFdBQVcsQ0FBQyxDQUFDLFlBQVksQ0FBQyxXQUFXLENBQUMsQ0FBQyxZQUFZLENBQUMsUUFBUSxDQUFDLENBQUM7WUFDcEgsQ0FBQztZQUNELFdBQVcsRUFBRSxVQUFDLFlBQW9DO2dCQUM5QyxJQUFJLFdBQVcsR0FBRyxLQUFJLENBQUMsa0JBQWtCLENBQUMsT0FBTyxFQUFFLFlBQVksQ0FBQyxLQUFLLEVBQUUsWUFBWSxDQUFDLEtBQUssQ0FBQyxDQUFDO2dCQUUzRixJQUFJLE9BQU8sS0FBSSxDQUFDLFdBQVcsQ0FBQyxPQUFPLENBQUMsaUJBQWlCLENBQUMsV0FBVyxDQUFDLEtBQUssV0FBVyxFQUFFO29CQUNoRixLQUFJLENBQUMsV0FBVyxDQUFDLE9BQU8sQ0FBQyxpQkFBaUIsQ0FBQyxXQUFXLENBQUMsQ0FBQyxZQUFZLENBQUMsV0FBVyxDQUFDLENBQUMsWUFBWSxDQUFDLFFBQVEsQ0FBQyxHQUFHLFlBQVksQ0FBQyxJQUFJLENBQUM7aUJBQ2hJO2dCQUVELElBQUksT0FBTyxHQUFZLEtBQUksQ0FBQyxXQUFXLENBQUMsR0FBRyxDQUFDLFVBQVUsQ0FBQyxZQUFZLENBQUMsS0FBSyxDQUFDLFFBQVEsRUFBRSxDQUFDLENBQUM7Z0JBRXRGLElBQUksWUFBWSxDQUFDLFFBQVEsS0FBSyxTQUFTLEVBQUU7b0JBQ3JDLE9BQU8sQ0FBQyxZQUFZLENBQUMsU0FBUyxDQUFDLENBQUM7b0JBQ2hDLDZGQUE2RjtvQkFDN0YsS0FBSSxDQUFDLFdBQVcsQ0FBQyxHQUFHLENBQUMsa0JBQWtCLEVBQUUsQ0FBQztpQkFDN0M7Z0JBRUQsSUFBSSxZQUFZLENBQUMsUUFBUSxLQUFLLE9BQU8sRUFBRTtvQkFDbkMsT0FBTyxDQUFDLElBQUksQ0FBQyxZQUFZLENBQUMsS0FBSyxDQUFDLENBQUMsWUFBWSxDQUFDLFdBQVcsQ0FBQyxHQUFHLFlBQVksQ0FBQyxJQUFJLENBQUM7aUJBQ2xGO1lBQ0wsQ0FBQztTQUNKLENBQUM7SUFDTixDQUFDO0lBRU8sNENBQW1CLEdBQTNCLFVBQTRCLElBQWdCO1FBQTVDLGlCQWNDO1FBYkcsT0FBTztZQUNILGNBQWMsRUFBRTtnQkFDWixPQUFPLElBQUksQ0FBQyxLQUFLLEVBQUUsQ0FBQztZQUN4QixDQUFDO1lBRUQsY0FBYyxFQUFFO2dCQUNaLEtBQUksQ0FBQyxXQUFXLENBQUMsR0FBRyxDQUFDLGVBQWUsRUFBRSxDQUFDO1lBQzNDLENBQUM7WUFFRCxnQkFBZ0IsRUFBRSxVQUFDLE1BQWMsRUFBRSxRQUFpQjtnQkFDaEQsS0FBSSxDQUFDLFdBQVcsQ0FBQyxTQUFTLENBQUMsZ0JBQWdCLENBQUMsTUFBTSxFQUFFLFFBQVEsQ0FBQyxDQUFDO1lBQ2xFLENBQUM7U0FDSixDQUFDO0lBQ04sQ0FBQztJQUVELHdEQUF3RDtJQUN4RCx5QkFBeUI7SUFDekIsd0RBQXdEO0lBQ3hEOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7T0FnREc7SUFDSyxtREFBMEIsR0FBbEMsVUFBbUMsT0FBNEIsRUFBRSxJQUFnQixFQUFFLE9BQWU7UUFDOUYsSUFBSSxpQkFBaUIsR0FBUSxFQUFFLENBQUM7UUFFaEMsS0FBSyxJQUFJLENBQUMsR0FBVyxDQUFDLEVBQUUsQ0FBQyxHQUFHLE9BQU8sQ0FBQyxNQUFNLEVBQUUsRUFBRSxDQUFDLEVBQUU7WUFDN0MsSUFBSSxJQUFJLENBQUMsV0FBVyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsRUFBRSxPQUFPLENBQUMsRUFBRTtnQkFDdkMsSUFBSSxhQUFhLEdBQWlCLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQztnQkFDN0MsSUFBSSxlQUFlLEdBQVcsYUFBYSxDQUFDLEtBQUssQ0FBQztnQkFFbEQsS0FBSyxJQUFJLENBQUMsR0FBVyxDQUFDLEVBQUUsQ0FBQyxHQUFHLElBQUksQ0FBQyxNQUFNLEVBQUUsRUFBRSxDQUFDLEVBQUU7b0JBQzFDLElBQUksT0FBTyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxLQUFLLFdBQVcsRUFBRTt3QkFDN0MsSUFBSSxhQUFhLEdBQVEsRUFBRSxDQUFDO3dCQUU1Qiw4REFBOEQ7d0JBQzlELGtEQUFrRDt3QkFDbEQsc0RBQXNEO3dCQUN0RCxzQ0FBc0M7d0JBRXRDLHlEQUF5RDt3QkFDekQsSUFBSSxPQUFPLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxlQUFlLENBQUMsS0FBSyxXQUFXLEVBQUU7NEJBQ2pELElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxlQUFlLENBQUMsR0FBRyxFQUFFLENBQUM7eUJBQ2pDO3dCQUVELHFDQUFxQzt3QkFDckMsSUFBSSxPQUFPLGFBQWEsQ0FBQyxNQUFNLEtBQUssV0FBVyxJQUFJLE9BQU8sYUFBYSxDQUFDLE1BQU0sQ0FBQyxLQUFLLEtBQUssV0FBVyxFQUFFOzRCQUNsRyxJQUFJLGdCQUFnQixHQUEyQixDQUFDLGFBQWEsQ0FBQyxNQUFNLENBQUMsS0FBSyxZQUFZLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxhQUFhLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxhQUFhLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxDQUFDOzRCQUN6SixJQUFJLGFBQWEsR0FBUSxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsZUFBZSxDQUFDLENBQUM7NEJBRWxELEtBQUssSUFBSSxDQUFDLEdBQVcsQ0FBQyxFQUFFLENBQUMsR0FBRyxnQkFBZ0IsQ0FBQyxNQUFNLEVBQUUsRUFBRSxDQUFDLEVBQUU7Z0NBQ3RELDRFQUE0RTtnQ0FDNUUsSUFBSSxPQUFPLGFBQWEsQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsS0FBSyxXQUFXLEVBQUU7b0NBQy9ELGFBQWEsQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsR0FBRyxFQUFFLENBQUM7aUNBQy9DO2dDQUVELGFBQWEsQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsR0FBUyxNQUFPLENBQUMsTUFBTSxDQUFDLEVBQUUsRUFBRSxnQkFBZ0IsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO2dDQUN2RixhQUFhLENBQUMsZ0JBQWdCLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsS0FBSyxHQUFHLGFBQWEsQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQzs2QkFDekY7eUJBQ0o7NkJBQ0k7NEJBQ0QsT0FBTyxDQUFDLEtBQUssQ0FBQyw4RkFBOEYsQ0FBQyxDQUFDO3lCQUNqSDt3QkFFRCxJQUFJLFVBQVUsR0FBVyxJQUFJLENBQUMsa0JBQWtCLENBQUMsT0FBTyxFQUFFLGVBQWUsRUFBRSxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUM7d0JBQ2pHLGlCQUFpQixDQUFDLFVBQVUsQ0FBQyxHQUFTLE1BQU8sQ0FBQyxNQUFNLENBQUMsRUFBRSxFQUFFLGFBQWEsQ0FBQyxDQUFDO3FCQUMzRTt5QkFDSTt3QkFDRCxPQUFPLENBQUMsS0FBSyxDQUFDLGdEQUFnRCxHQUFHLElBQUksQ0FBQyxNQUFNLEdBQUcsc0RBQXNELENBQUMsQ0FBQztxQkFDMUk7aUJBQ0o7YUFDSjtTQUNKO1FBRUQsT0FBTyxpQkFBaUIsQ0FBQztJQUM3QixDQUFDO0lBRUQsd0RBQXdEO0lBQ3hELCtDQUErQztJQUMvQyx3REFBd0Q7SUFDeEQ7Ozs7Ozs7Ozs7O09BV0c7SUFDSyxrREFBeUIsR0FBakMsVUFBa0MsWUFBaUIsRUFBRSxPQUFlLEVBQUUsTUFBVyxFQUFFLFVBQXdCO1FBQXhCLDJCQUFBLEVBQUEsZ0JBQXdCO1FBQ3ZHLElBQUksWUFBWSxHQUFrQixPQUFPLENBQUMsS0FBSyxDQUFDLFVBQVUsQ0FBQyxDQUFDO1FBQzVELE9BQU8sSUFBSSxDQUFDLG1CQUFtQixDQUFDLFlBQVksRUFBRSxZQUFZLEVBQUUsTUFBTSxDQUFDLENBQUM7SUFDeEUsQ0FBQztJQUVPLDRDQUFtQixHQUEzQixVQUE0QixJQUFtQixFQUFFLFdBQWdCLEVBQUUsTUFBVztRQUMxRSxJQUFJLElBQUksQ0FBQyxNQUFNLEdBQUcsQ0FBQyxFQUFFO1lBQ2pCLElBQUksVUFBVSxHQUFXLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQztZQUVqQyxJQUFJLE9BQU8sV0FBVyxDQUFDLFVBQVUsQ0FBQyxLQUFLLFdBQVcsRUFBRTtnQkFDaEQsV0FBVyxDQUFDLFVBQVUsQ0FBQyxHQUFHLEVBQUUsQ0FBQzthQUNoQztZQUVELElBQUksQ0FBQyxLQUFLLEVBQUUsQ0FBQztZQUNiLFdBQVcsQ0FBQyxVQUFVLENBQUMsR0FBRyxJQUFJLENBQUMsbUJBQW1CLENBQUMsSUFBSSxFQUFFLFdBQVcsQ0FBQyxVQUFVLENBQUMsRUFBRSxNQUFNLENBQUMsQ0FBQztTQUM3RjthQUNJO1lBQ0QsV0FBVyxHQUFHLE1BQU0sQ0FBQztTQUN4QjtRQUVELE9BQU8sV0FBVyxDQUFDO0lBQ3ZCLENBQUM7SUFFRCx3REFBd0Q7SUFDeEQsa0JBQWtCO0lBQ2xCLHdEQUF3RDtJQUNoRCw0Q0FBbUIsR0FBM0IsVUFBNEIsT0FBZSxFQUFFLFVBQTBCO1FBQ25FLE9BQU8sQ0FBQyxRQUFRLEdBQUcsQ0FBQyxlQUFlLENBQUMsQ0FBQztRQUNyQyxPQUFPLENBQUMsTUFBTSxHQUFHLG1CQUFtQixDQUFDO1FBQ3JDLE9BQU8sQ0FBQyxZQUFZLEdBQUc7WUFDbkIsYUFBYSxFQUFFLE1BQU07WUFDckIsVUFBVSxFQUFFLEVBQUU7WUFDZCxxQkFBcUIsRUFBRSxJQUFJO1NBQzlCLENBQUM7UUFFRixJQUFJLE9BQU8sVUFBVSxLQUFLLFdBQVcsRUFBRTtZQUNuQyxPQUFPLENBQUMsWUFBWSxDQUFDLE1BQU0sR0FBRyxVQUFVLENBQUM7U0FDNUM7SUFDTCxDQUFDO0lBRU8sZ0RBQXVCLEdBQS9CO1FBQ0ksT0FBTztZQUNILFFBQVEsRUFBRSxLQUFLO1lBQ2YsVUFBVSxFQUFFLEtBQUs7WUFDakIsT0FBTyxFQUFFLElBQUk7U0FDaEIsQ0FBQztJQUNOLENBQUM7SUE3c0JpQixjQUFjO1FBRG5DLFVBQVUsRUFBRTtPQUNTLGNBQWMsQ0FndEJuQztJQUFELHFCQUFDO0NBQUEsQUFodEJELElBZ3RCQztTQWh0QnFCLGNBQWMiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBJbmplY3RhYmxlIH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XHJcbmltcG9ydCB7XHJcbiAgICBHcmlkT3B0aW9ucyxcclxuICAgIENvbERlZixcclxuICAgIFJvd05vZGVcclxufSBmcm9tICdhZy1ncmlkLWNvbW11bml0eSc7XHJcblxyXG5pbXBvcnQge1xyXG4gICAgSVRhYmxlQ29sdW1uLFxyXG4gICAgSVRhYmxlQ29uZmlnLFxyXG4gICAgSVRhYmxlRm9ybUlucHV0LFxyXG4gICAgSVRhYmxlQXBpLFxyXG4gICAgSVRhYmxlRHluYW1pY0Zvcm1BcGksXHJcbiAgICBJVGFibGVHZW5lcmFsQXBpLFxyXG5cclxuICAgIElUYWJsZURyb3Bkb3duQWN0aW9uLFxyXG4gICAgSVRhYmxlRm9ybVVwZGF0ZVBhcmFtc1xyXG59IGZyb20gJy4uL2tkLWFuZ3VsYXItdGFibGUtaW50ZXJmYWNlJztcclxuXHJcbmltcG9ydCB7IEtkVGFibGVBY3Rpb24gfSBmcm9tICcuLi90YWJsZS1jb21wb25lbnRzL2tkLXRhYmxlLWFjdGlvbic7XHJcbmltcG9ydCB7IEtkVGFibGVDaGVja2JveFJhZGlvIH0gZnJvbSAnLi4vdGFibGUtY29tcG9uZW50cy9rZC10YWJsZS1jaGVja2JveC1yYWRpbyc7XHJcbmltcG9ydCB7IEtkVGFibGVJbnB1dCB9IGZyb20gJy4uL3RhYmxlLWNvbXBvbmVudHMva2QtdGFibGUtaW5wdXQnO1xyXG5pbXBvcnQgeyBLZFRhYmxlSW1hZ2UgfSBmcm9tICcuLi90YWJsZS1jb21wb25lbnRzL2tkLXRhYmxlLWltYWdlJztcclxuXHJcblxyXG5pbXBvcnQgeyBLZEludFRhYmxlRXZlbnQgfSBmcm9tICcuLi9rZC1hbmd1bGFyLXRhYmxlLWV2ZW50JztcclxuaW1wb3J0IHsgS2REYXRhU3ZjIH0gZnJvbSAnLi4vLi4va2QtY29tbW9uL2luZGV4JztcclxuXHJcbi8qKlxyXG4gKiAtLSBEb2N1bWVudGF0aW9uIGZvciBrZC10YWJsZS1zdmMudHNcclxuICpcclxuICogLSBQdWJsaWMgZnVuY3Rpb25zIChVc2FibGUgYnkgYm90aCBleHRlbmRlZCBzZXJ2aWNlcyk6XHJcbiAqICAgICAtIENoZWNraW5nIGZ1bmN0aW9uc1xyXG4gKiAgICAgICAgIC0gaXNBcGlSZWFkeVxyXG4gKiAgICAgICAgIC0gaGFzU2VsZWN0aW9uQWxsXHJcbiAqICAgICAgICAgLSBoYXNJbnB1dFR5cGVcclxuICogICAgICAgICAtIGlzSW5wdXRUeXBlXHJcbiAqICAgICAgICAgLSBpc0VudGVycHJpc2VNb2RlbFxyXG4gKiAgICAgLSBVcGRhdGUgZnVuY3Rpb25zXHJcbiAqICAgICAgICAgLSB1cGRhdGVTZWxlY3REZWZhdWx0VmFsdWVcclxuICogICAgICAgICAtIHVwZGF0ZVNlbGVjdGlvblZhbHVlc1xyXG4gKiAgICAgICAgIC0gdXBkYXRlR3JpZEJ1dHRvbnNcclxuICogICAgICAgICAtIHVwZGF0ZVJvd0RhdGFXaXRoQ29sdW1uIChHZW5lcmF0aW9ucyBvZiBpbnB1dCBjb250ZXh0IGluIGdyaWRPcHRpb25zLmNvbnRleHQgaWYgaW5wdXQgZXhpc3QpXHJcbiAqICAgICAgICAgLSBnZW5lcmF0ZWRBcGlGdW5jdGlvbnMgKEdlbmVyYXRpb24gb2YgQVBJcylcclxuICogICAgIC0gTWlzYyBmdW5jdGlvblxyXG4gKiAgICAgICAgIC0gZ2V0R3JpZElkXHJcbiAqICAgICAgICAgLSBnZXRJbWFnZVNpemVCeVxyXG4gKiAgICAgICAgIC0gZ2V0VGFibGVDb250ZXh0S2V5XHJcbiAqICAgICAgICAgLSBnZXRSb3V0ZXJQbGFjZWhvbGRlclBhdGggKEZvciBwYXRoTWFwIG9mIGNsaWNrIHR5cGUgcm91dGVyKVxyXG4gKiAgICAgICAgIC0gYjY0dG9CbG9iXHJcbiAqXHJcbiAqIC0gUHJvdGVjdGVkIGZ1bmN0aW9uOlxyXG4gKiAgICAgLSBHcmlkIE9wdGlvbnMgZnVuY3Rpb25cclxuICogICAgICAgICAtIGdldERlZmF1bHRHcmlkT3B0aW9uc1xyXG4gKiAgICAgLSBDb2x1bW4gZGVmaW5pdGlvbiBmdW5jdGlvbnNcclxuICogICAgICAgICAtIGdlbmVyYXRlQ29sdW1uRGVmaW5pdGlvbnNcclxuICogICAgICAgICAtIGlzQ29sRGVmT2ZUeXBlXHJcbiAqICAgICAtIEFQSSBnZW5lcmF0aW9uIGZ1bmN0aW9uXHJcbiAqICAgICAtIE1pc2MgZnVuY3Rpb25zXHJcbiAqICAgICAgICAgLSBnZW5lcmF0ZUdyaWRJZFxyXG4gKiAgICAgICAgIC0gZ2VuZXJhdGVDb250ZXh0S2V5XHJcbiAqICAgICAgICAgLSBnZXRJbWFnZVNpemVCeVxyXG4gKlxyXG4gKiAtIFByaXZhdGUgZnVuY3Rpb25zOlxyXG4gKiAgICAgLSBDb2x1bW4gZGVmaW5pdGlvbiBmdW5jdGlvbnNcclxuICogICAgICAgICAtIF9nZW5lcmF0ZUNvbERlZnNGcm9tQ29sQ29uZmlnIChDb2xEZWYgZ2VuZXJhdGlvbiBiYXNlZCBvbiBjb2x1bW4gY29uZmlnIC0gY2hlY2tzIG5vcm1hbCBjb2x1bW5zLCBpbnB1dCBjb2x1bW4gYW5kIGltYWdlIGNvbHVtbnMpXHJcbiAqICAgICAgICAgLSBfZ2VuZXJhdGVDb2xEZWZzRnJvbUNvbmZpZyAoQ29sRGVmIGdlbmVyYXRpb24gYmFzZWQgb24gZ3JpZCBjb25maWcgLSBjaGVja3MgYWN0aW9uIGNvbHVtbiBhbmQgc2VsZWN0aW9uIGNvbHVtbilcclxuICogICAgICAgICAtIF9nZW5lcmF0ZUFjdGlvbkNvbERlZiAoQWN0aW9uKVxyXG4gKiAgICAgICAgIC0gX2dlbmVyYXRlQ2hlY2tib3hSYWRpb0NvbERlZiAoU2VsZWN0aW9uKVxyXG4gKiAgICAgICAgIC0gX2dlbmVyYXRlSW1hZ2VDb2xEZWYgKEltYWdlKVxyXG4gKiAgICAgICAgIC0gX2dlbmVyYXRlSW5wdXRDb2xEZWYgKElucHV0KVxyXG4gKiAgICAgLSBBUEkgZ2VuZXJhdGlvbiBmdW5jdGlvbnNcclxuICogICAgICAgICAtIF9nZW5lcmF0ZUlucHV0QXBpIChhcGkuZHluYW1pY0Zvcm1zKVxyXG4gKiAgICAgICAgIC0gX2dlbmVyYXRlR2VuZXJhbEFwaSAoYXBpLmdlbmVyYWwpXHJcbiAqICAgICAtIFRhYmxlIGlucHV0IGZ1bmN0aW9uc1xyXG4gKiAgICAgICAgIC0gX2dlbmVyYXRlVGFibGVJbnB1dENvbnRleHQgKExvb3AgYWxsIGNvbHVtbnMgYW5kIHJvd3MgYW5kIGVhY2ggb2YgdGhlIHF1ZXN0aW9uIHRvIGdlbmVyYXRlIHRoZSBjb250ZXh0IGZvciBpbnB1dCBjb2x1bW5zKVxyXG4gKiAgICAgLSBTZWxlY3Rpb24gZnVuY3Rpb25zXHJcbiAqICAgICAgICAgLSBfY29udmVydERhdGFWYWx1ZVRvT2JqZWN0IChzZXQgdG8gb2JqZWN0IGlmIGNvbmZpZyBjb25zaXN0IG9mIHJldHVybiBrZXlzKVxyXG4gKiAgICAgICAgIC0gX2FwcGVuZERhdGFWYWx1ZUtleVxyXG4gKiAgICAgLSBNaXNjIGZ1bmN0aW9uc1xyXG4gKiAgICAgICAgIC0gX3VwZGF0ZUZpbHRlckNvbERlZlxyXG4gKiAgICAgICAgIC0gX2dldERlZmF1bHRDb2x1bW5Db25maWdcclxuICovXHJcblxyXG5ASW5qZWN0YWJsZSgpXHJcbmV4cG9ydCBhYnN0cmFjdCBjbGFzcyBLZFRhYmxlU3ZjQmFzZSB7XHJcbiAgICAvKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKiogVmFyaWFibGVzICoqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKi9cclxuICAgIHJlYWRvbmx5IFJPV19IRUlHSFQ6IG51bWJlciA9IDUwO1xyXG4gICAgcmVhZG9ubHkgQ09OVEVYVF9ERUxJTUlURVI6IHN0cmluZyA9ICd+JztcclxuICAgIHJlYWRvbmx5IFRBQkxFX0lOUFVUX0NPTlRFWFRfS0VZOiBzdHJpbmcgPSAndGFibGVJbnB1dENvbnRleHQnO1xyXG4gICAgcmVhZG9ubHkgREVGQVVMVF9QQUdFU0laRTogbnVtYmVyID0gMjU7XHJcbiAgICByZWFkb25seSBJTUFHRV9QQURESU5HOiBudW1iZXIgPSAyMDtcclxuICAgIHJlYWRvbmx5IERFRkFVTFRfR1JJRElEOiBzdHJpbmcgPSAna2QtdGFibGUtZ3JpZCc7XHJcbiAgICByZWFkb25seSBHSVJEX1BBUkFNU19LRVk6IHsgW2tleTogc3RyaW5nXTogc3RyaW5nIH0gPSB7XHJcbiAgICAgICAgaW5wdXQ6ICdpbnB1dENvbmZpZycsXHJcbiAgICAgICAgaW1hZ2U6ICdpbWFnZUNvbmZpZydcclxuICAgIH07XHJcblxyXG4gICAgcHJvdGVjdGVkIGRhdGFTdmM6IEtkRGF0YVN2YyA9IG5ldyBLZERhdGFTdmMoKTtcclxuICAgIHByb3RlY3RlZCBncmlkT3B0aW9uczogR3JpZE9wdGlvbnM7XHJcbiAgICBwcm90ZWN0ZWQgZGlyZWN0aW9uOiAnbHRyJyB8ICdydGwnO1xyXG4gICAgcHJvdGVjdGVkIHJvd0tleTogc3RyaW5nID0gJ2lkJztcclxuXHJcbiAgICAvKioqKioqKioqKioqKioqIFB1YmxpYyBmdW5jdGlvbnMgKHNoYXJlZCBmb3IgYm90aCBzZXJ2aWNlcykgKioqKioqKioqKioqKioqKi9cclxuICAgIC8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vXHJcbiAgICAvLy8gQ2hlY2tpbmcgZnVuY3Rpb25zXHJcbiAgICAvLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vL1xyXG4gICAgcHVibGljIGlzQXBpUmVhZHkoX2dyaWRPcHRpb25zOiBHcmlkT3B0aW9ucyk6IGJvb2xlYW4ge1xyXG4gICAgICAgIGlmICh0eXBlb2YgX2dyaWRPcHRpb25zICE9PSAndW5kZWZpbmVkJyAmJlxyXG4gICAgICAgICAgICBfZ3JpZE9wdGlvbnMgIT09IG51bGwgJiZcclxuICAgICAgICAgICAgdHlwZW9mIF9ncmlkT3B0aW9ucy5hcGkgIT09ICd1bmRlZmluZWQnKSB7XHJcbiAgICAgICAgICAgIHJldHVybiB0cnVlO1xyXG4gICAgICAgIH1cclxuICAgICAgICByZXR1cm4gZmFsc2U7XHJcbiAgICB9XHJcblxyXG4gICAgcHVibGljIGhhc1NlbGVjdGlvbkFsbChfZ3JpZENvbmZpZzogSVRhYmxlQ29uZmlnKTogYm9vbGVhbiB7XHJcbiAgICAgICAgaWYgKHR5cGVvZiBfZ3JpZENvbmZpZyAhPT0gJ3VuZGVmaW5lZCcgJiZcclxuICAgICAgICAgICAgdHlwZW9mIF9ncmlkQ29uZmlnLnNlbGVjdGlvbiAhPT0gJ3VuZGVmaW5lZCcgJiZcclxuICAgICAgICAgICAgdHlwZW9mIF9ncmlkQ29uZmlnLnNlbGVjdGlvbi50eXBlICE9PSAndW5kZWZpbmVkJyAmJlxyXG4gICAgICAgICAgICBfZ3JpZENvbmZpZy5zZWxlY3Rpb24udHlwZSA9PT0gJ2FsbCcgJiZcclxuICAgICAgICAgICAgX2dyaWRDb25maWcubG9hZFR5cGUgIT09ICdpbmZpbml0ZScpIHtcclxuICAgICAgICAgICAgcmV0dXJuIHRydWU7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICByZXR1cm4gZmFsc2U7XHJcbiAgICB9XHJcblxyXG4gICAgcHVibGljIGhhc0lucHV0VHlwZShfdGFibGVDb2x1bW46IEFycmF5PElUYWJsZUNvbHVtbj4sIF90eXBlOiBzdHJpbmcpOiBib29sZWFuIHtcclxuICAgICAgICBpZiAodHlwZW9mIF90YWJsZUNvbHVtbiAhPT0gJ3VuZGVmaW5lZCcpIHtcclxuICAgICAgICAgICAgZm9yIChsZXQgaTogbnVtYmVyID0gMDsgaSA8IF90YWJsZUNvbHVtbi5sZW5ndGg7ICsraSkge1xyXG4gICAgICAgICAgICAgICAgaWYgKHRoaXMuaXNJbnB1dFR5cGUoX3RhYmxlQ29sdW1uW2ldLCBfdHlwZSkpIHtcclxuICAgICAgICAgICAgICAgICAgICByZXR1cm4gdHJ1ZTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgcmV0dXJuIGZhbHNlO1xyXG4gICAgfVxyXG5cclxuICAgIHB1YmxpYyBpc0lucHV0VHlwZShfY29sdW1uOiBJVGFibGVDb2x1bW4sIF90eXBlOiBzdHJpbmcpOiBib29sZWFuIHtcclxuICAgICAgICByZXR1cm4gKHR5cGVvZiBfY29sdW1uLnR5cGUgIT09ICd1bmRlZmluZWQnICYmIF9jb2x1bW4udHlwZSA9PT0gX3R5cGUpO1xyXG4gICAgfVxyXG5cclxuICAgIHB1YmxpYyBpc0VudGVycHJpc2VNb2RlbChfbG9hZFR5cGU6IHN0cmluZyk6IGJvb2xlYW4ge1xyXG4gICAgICAgIHJldHVybiAoX2xvYWRUeXBlID09PSAnb25lc2hvdCcgfHwgX2xvYWRUeXBlID09PSAnaW5maW5pdGUnIHx8IF9sb2FkVHlwZSA9PT0gJ3NlcnZlcicpO1xyXG4gICAgfVxyXG5cclxuICAgIC8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vXHJcbiAgICAvLy8gU2VsZWN0aW9uIGZ1bmN0aW9uc1xyXG4gICAgLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy9cclxuICAgIHB1YmxpYyB1cGRhdGVTZWxlY3REZWZhdWx0VmFsdWUoX2dyaWRDb25maWc6IElUYWJsZUNvbmZpZyk6IHZvaWQge1xyXG4gICAgICAgIGlmICh0eXBlb2YgX2dyaWRDb25maWcuc2VsZWN0aW9uICE9PSAndW5kZWZpbmVkJykge1xyXG4gICAgICAgICAgICBpZiAodHlwZW9mIF9ncmlkQ29uZmlnLnNlbGVjdGlvbi52YWx1ZSA9PT0gJ3VuZGVmaW5lZCcpIHtcclxuICAgICAgICAgICAgICAgIF9ncmlkQ29uZmlnLnNlbGVjdGlvbi52YWx1ZSA9IFtdO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIGVsc2UgaWYgKF9ncmlkQ29uZmlnLnNlbGVjdGlvbi50eXBlID09PSAnc2luZ2xlJyAmJiBfZ3JpZENvbmZpZy5zZWxlY3Rpb24udmFsdWUubGVuZ3RoID4gMSkge1xyXG4gICAgICAgICAgICAgICAgY29uc29sZS53YXJuKCdLZFRhYmxlIHdhcm5pbmc6IFNpbmdsZSBzZWxlY3Rpb24gdHlwZSBjb250YWlucyBtb3JlIHRoYW4gMSBkZWZhdWx0IHZhbHVlcy4nKTtcclxuICAgICAgICAgICAgICAgIF9ncmlkQ29uZmlnLnNlbGVjdGlvbi52YWx1ZSA9IF9ncmlkQ29uZmlnLnNlbGVjdGlvbi52YWx1ZS5zbGljZSgwLCAxKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICAvKipcclxuICAgICAqIFt1cGRhdGVTZWxlY3Rpb25WYWx1ZXMoKSAtIFJldHVybnMgdGhlIHNlbGVjdGVkIG5vZGVzIGJhc2VkIG9uIHRoZSByZXR1cm5LZXkgc3BlY2lmeS5cclxuICAgICAqICBJZiBpcyBub3Qgc3BlY2lmeSwgYXJyYXkgb2YgaWRzIHdpbGwgYmUgcmV0dXJuIG9uIHNlbGVjdGlvbi5cclxuICAgICAqICBPbmx5IHdvcmtzIGZvciBub3JtYWwsIGluZmluaXRlIGFuZCBvbmVzaG90IGxvYWRUeXBlLlxyXG4gICAgICogICAgIC0gTm90IHNwZWNpZnkgLSBSZXR1cm4gWyAxLCAyLCAzIF07XHJcbiAgICAgKiAgICAgLSBTcGVjaWZ5ICAgICAtIFJldHVybiBbIHtpZDogMSwgZ3JhZGU6IFwiMVwiIH0sIHtpZDogMiwgZ3JhZGU6IFwiMVwifSwge2lkOiAzLCBncmFkZTogXCIyXCJ9XVxyXG4gICAgICogXVxyXG4gICAgICogX3Jvd0RhdGEgICAgICAgOiBbQ3VycmVudCBwcm92aWRlZCByb3dEYXRhXVxyXG4gICAgICogX3NlbGVjdGVkSWRzICAgOiBbQ3VycmVudCBzZWxlY3RlZCByb3dEYXRhIGlkc11cclxuICAgICAqIF9yZXR1cm5LZXkgICAgIDogW0xpc3Qgb2YgcHJvcGVydHkga2V5cyB0byByZXR1cm4gd2l0aCBpZF1cclxuICAgICAqIFtHZW5lcmF0ZWQgc2VsZWN0aW9uIGJ5IHJldHVybktleV1cclxuICAgICAqL1xyXG4gICAgcHVibGljIHVwZGF0ZVNlbGVjdGlvblZhbHVlcyhfcm93RGF0YTogQXJyYXk8YW55PiwgX3NlbGVjdGVkSWRzOiBBcnJheTxzdHJpbmcgfCBudW1iZXI+LCBfcmV0dXJuS2V5OiBBcnJheTxzdHJpbmc+LCBfbG9hZFR5cGU/OiBzdHJpbmcpOiBBcnJheTxhbnk+IHtcclxuICAgICAgICBpZiAodHlwZW9mIF9yZXR1cm5LZXkgPT09ICd1bmRlZmluZWQnIHx8XHJcbiAgICAgICAgICAgIF9yZXR1cm5LZXkgPT09IG51bGwgfHxcclxuICAgICAgICAgICAgX3JldHVybktleS5sZW5ndGggPT09IDApIHtcclxuICAgICAgICAgICAgcmV0dXJuIF9zZWxlY3RlZElkcztcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIGxldCBnZW5lcmF0ZWRTZWxlY3Rpb246IEFycmF5PGFueT4gPSBbXTtcclxuXHJcbiAgICAgICAgZm9yIChsZXQgaTogbnVtYmVyID0gMDsgaSA8IF9yb3dEYXRhLmxlbmd0aDsgaSsrKSB7XHJcbiAgICAgICAgICAgIGxldCBkYXRhSXRlbTogYW55ID0gX3Jvd0RhdGFbaV07XHJcbiAgICAgICAgICAgIGxldCBvbmVJdGVtOiBhbnkgPSB7fTtcclxuXHJcbiAgICAgICAgICAgIGlmIChfc2VsZWN0ZWRJZHMuaW5kZXhPZihkYXRhSXRlbVt0aGlzLnJvd0tleV0pID4gLTEpIHtcclxuICAgICAgICAgICAgICAgIG9uZUl0ZW1bdGhpcy5yb3dLZXldID0gZGF0YUl0ZW1bdGhpcy5yb3dLZXldO1xyXG5cclxuICAgICAgICAgICAgICAgIGZvciAobGV0IGo6IG51bWJlciA9IDA7IGogPCBfcmV0dXJuS2V5Lmxlbmd0aDsgaisrKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKGRhdGFJdGVtLmhhc093blByb3BlcnR5KF9yZXR1cm5LZXlbal0pKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG9uZUl0ZW1bX3JldHVybktleVtqXV0gPSBkYXRhSXRlbVtfcmV0dXJuS2V5W2pdXTtcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgZWxzZSBpZiAoX3JldHVybktleVtqXS5pbmRleE9mKCcuJykgPiAwKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGxldCByZXR1cm5WYWw6IGFueSA9IHRoaXMuZGF0YVN2Yy5nZXREYXRhVmFsdWUoZGF0YUl0ZW0sIF9yZXR1cm5LZXlbal0pO1xyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgaWYgKHJldHVyblZhbCAhPT0gbnVsbCkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgbGV0IG5ld0l0ZW06IGFueSA9ICg8YW55Pk9iamVjdCkuYXNzaWduKHt9LCBvbmVJdGVtKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uZUl0ZW0gPSB0aGlzLl9jb252ZXJ0RGF0YVZhbHVlVG9PYmplY3QobmV3SXRlbSwgX3JldHVybktleVtqXSwgcmV0dXJuVmFsKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgICAgICBnZW5lcmF0ZWRTZWxlY3Rpb24ucHVzaChvbmVJdGVtKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgcmV0dXJuIGdlbmVyYXRlZFNlbGVjdGlvbjtcclxuICAgIH1cclxuXHJcbiAgICAvLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vL1xyXG4gICAgLy8vIEdyaWQgQnV0dG9uIGZ1bmN0aW9uc1xyXG4gICAgLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy9cclxuICAgIHB1YmxpYyB1cGRhdGVHcmlkQnV0dG9ucyhfZ3JpZENvbmZpZzogSVRhYmxlQ29uZmlnKTogdm9pZCB7XHJcbiAgICAgICAgaWYgKHR5cGVvZiBfZ3JpZENvbmZpZy5idXR0b24gPT09ICd1bmRlZmluZWQnKSB7XHJcbiAgICAgICAgICAgIF9ncmlkQ29uZmlnLmJ1dHRvbiA9IFtdO1xyXG4gICAgICAgIH1cclxuICAgICAgICBlbHNlIGlmIChfZ3JpZENvbmZpZy5idXR0b24ubGVuZ3RoID4gNCkge1xyXG4gICAgICAgICAgICBjb25zb2xlLndhcm4oJ0tkVGFibGUgd2FybmluZzogTWF4IDQgYnV0dG9ucyBmb3IgdGFibGUuIFNsaWNpbmcgdG8gNC4nKTtcclxuICAgICAgICAgICAgX2dyaWRDb25maWcuYnV0dG9uID0gX2dyaWRDb25maWcuYnV0dG9uLnNsaWNlKDAsIDQpO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICAvLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vL1xyXG4gICAgLy8vIFRhYmxlIElucHV0IGZ1bmN0aW9uc1xyXG4gICAgLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy9cclxuICAgIHB1YmxpYyB1cGRhdGVSb3dEYXRhV2l0aENvbHVtbihfcm93RGF0YTogQXJyYXk8YW55PiwgX2NvbHVtbkNvbmZpZzogQXJyYXk8SVRhYmxlQ29sdW1uPiwgX2dyaWRJZDogc3RyaW5nLCBfZ3JpZE9wdGlvbnM6IEdyaWRPcHRpb25zKTogdm9pZCB7XHJcbiAgICAgICAgaWYgKHRoaXMuaGFzSW5wdXRUeXBlKF9jb2x1bW5Db25maWcsICdpbnB1dCcpKSB7XHJcbiAgICAgICAgICAgIGlmICh0eXBlb2YgX2dyaWRPcHRpb25zLmNvbnRleHRbdGhpcy5UQUJMRV9JTlBVVF9DT05URVhUX0tFWV0gPT09ICd1bmRlZmluZWQnKSB7XHJcbiAgICAgICAgICAgICAgICBfZ3JpZE9wdGlvbnMuY29udGV4dFt0aGlzLlRBQkxFX0lOUFVUX0NPTlRFWFRfS0VZXSA9IHt9O1xyXG4gICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICBsZXQgaW5wdXRDb250ZXh0OiBhbnkgPSB0aGlzLl9nZW5lcmF0ZVRhYmxlSW5wdXRDb250ZXh0KF9jb2x1bW5Db25maWcsIF9yb3dEYXRhLCBfZ3JpZElkKTtcclxuICAgICAgICAgICAgX2dyaWRPcHRpb25zLmNvbnRleHRbdGhpcy5UQUJMRV9JTlBVVF9DT05URVhUX0tFWV0gPSAoPGFueT5PYmplY3QpLmFzc2lnbihfZ3JpZE9wdGlvbnMuY29udGV4dFt0aGlzLlRBQkxFX0lOUFVUX0NPTlRFWFRfS0VZXSwgaW5wdXRDb250ZXh0KTtcclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy9cclxuICAgIC8vLyBBUEkgR2VuZXJhdGlvbiBmdW5jdGlvblxyXG4gICAgLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy9cclxuICAgIHB1YmxpYyBnZW5lcmF0ZWRBcGlGdW5jdGlvbnMoX2dyaWRBcGk6IElUYWJsZUFwaSwgX2FwaVBhcmFtczogYW55KTogdm9pZCB7XHJcbiAgICAgICAgX2dyaWRBcGkuZHluYW1pY0Zvcm0gPSB0aGlzLl9nZW5lcmF0ZUlucHV0QXBpKF9hcGlQYXJhbXMuaWQsIF9hcGlQYXJhbXMuZXZlbnQpO1xyXG4gICAgICAgIF9ncmlkQXBpLmdlbmVyYWwgPSB0aGlzLl9nZW5lcmF0ZUdlbmVyYWxBcGkoX2FwaVBhcmFtcy5yb3dzKTtcclxuICAgIH1cclxuXHJcbiAgICAvLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vL1xyXG4gICAgLy8vIE1pc2MgZnVuY3Rpb25cclxuICAgIC8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vXHJcbiAgICBwdWJsaWMgZ2V0R3JpZElkKF9ncmlkQ29uZmlnOiBJVGFibGVDb25maWcpOiBzdHJpbmcge1xyXG4gICAgICAgIGlmICh0eXBlb2YgX2dyaWRDb25maWcuaWQgPT09ICd1bmRlZmluZWQnKSB7XHJcbiAgICAgICAgICAgIF9ncmlkQ29uZmlnLmlkID0gdGhpcy5ERUZBVUxUX0dSSURJRDtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIHJldHVybiBfZ3JpZENvbmZpZy5pZDtcclxuICAgIH1cclxuXHJcbiAgICBwdWJsaWMgZ2V0SW1hZ2VTaXplQnkoX3RhYmxlQ29sdW1uOiBJVGFibGVDb2x1bW4sIF9kaW1lbnNpb246ICd3aWR0aCcgfCAnaGVpZ2h0Jyk6IG51bWJlciB7XHJcbiAgICAgICAgLy8gRGVmYXVsdCBwbGFjZWhvbGRlciB3aWR0aCAxNTAgKyAyMCBnYXBcclxuICAgICAgICBsZXQgd2lkdGg6IG51bWJlciA9IDE1MCArIHRoaXMuSU1BR0VfUEFERElORztcclxuXHJcbiAgICAgICAgaWYgKHR5cGVvZiBfdGFibGVDb2x1bW4uY29uZmlnICE9PSAndW5kZWZpbmVkJyAmJlxyXG4gICAgICAgICAgICB0eXBlb2YgX3RhYmxlQ29sdW1uLmNvbmZpZy5pbWFnZSAhPT0gJ3VuZGVmaW5lZCcgJiZcclxuICAgICAgICAgICAgdHlwZW9mIF90YWJsZUNvbHVtbi5jb25maWcuaW1hZ2VbX2RpbWVuc2lvbl0gIT09ICd1bmRlZmluZWQnKSB7XHJcbiAgICAgICAgICAgIHdpZHRoID0gX3RhYmxlQ29sdW1uLmNvbmZpZy5pbWFnZVtfZGltZW5zaW9uXSArIHRoaXMuSU1BR0VfUEFERElORztcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIHJldHVybiB3aWR0aDtcclxuICAgIH1cclxuXHJcbiAgICBwdWJsaWMgZ2V0VGFibGVDb250ZXh0S2V5KCk6IHN0cmluZyB7XHJcbiAgICAgICAgcmV0dXJuIHRoaXMuVEFCTEVfSU5QVVRfQ09OVEVYVF9LRVk7XHJcbiAgICB9XHJcblxyXG4gICAgcHVibGljIGdldFJvdXRlclBsYWNlaG9sZGVyUGF0aChfcm93Tm9kZTogUm93Tm9kZSwgX3BhdGg6IHN0cmluZyk6IHN0cmluZyB7XHJcbiAgICAgICAgcmV0dXJuIHRoaXMuZGF0YVN2Yy5nZXRQbGFjZWhvbGRlcihfcm93Tm9kZS5kYXRhLCBfcGF0aCk7XHJcbiAgICB9XHJcblxyXG4gICAgcHVibGljIGI2NHRvQmxvYihiNjREYXRhOiBhbnksIGNvbnRlbnRUeXBlOiBzdHJpbmcpOiBCbG9iIHtcclxuICAgICAgICBsZXQgc2xpY2VTaXplOiBudW1iZXIgPSA1MTI7XHJcblxyXG4gICAgICAgIGxldCBieXRlQ2hhcmFjdGVyczogYW55ID0gYXRvYihiNjREYXRhKTtcclxuICAgICAgICBsZXQgYnl0ZUFycmF5czogYW55W10gPSBbXTtcclxuXHJcbiAgICAgICAgZm9yIChsZXQgb2Zmc2V0ID0gMDsgb2Zmc2V0IDwgYnl0ZUNoYXJhY3RlcnMubGVuZ3RoOyBvZmZzZXQgKz0gc2xpY2VTaXplKSB7XHJcbiAgICAgICAgICAgIGxldCBzbGljZTogYW55ID0gYnl0ZUNoYXJhY3RlcnMuc2xpY2Uob2Zmc2V0LCBvZmZzZXQgKyBzbGljZVNpemUpO1xyXG5cclxuICAgICAgICAgICAgbGV0IGJ5dGVOdW1iZXJzOiBhbnlbXSA9IG5ldyBBcnJheShzbGljZS5sZW5ndGgpO1xyXG4gICAgICAgICAgICBmb3IgKGxldCBpID0gMDsgaSA8IHNsaWNlLmxlbmd0aDsgaSsrKSB7XHJcbiAgICAgICAgICAgICAgICBieXRlTnVtYmVyc1tpXSA9IHNsaWNlLmNoYXJDb2RlQXQoaSk7XHJcbiAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgIGxldCBieXRlQXJyYXk6IFVpbnQ4QXJyYXkgPSBuZXcgVWludDhBcnJheShieXRlTnVtYmVycyk7XHJcblxyXG4gICAgICAgICAgICBieXRlQXJyYXlzLnB1c2goYnl0ZUFycmF5KTtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIGxldCBibG9iOiBCbG9iID0gbmV3IEJsb2IoYnl0ZUFycmF5cywgeyB0eXBlOiBjb250ZW50VHlwZSB9KTtcclxuICAgICAgICByZXR1cm4gYmxvYjtcclxuICAgIH1cclxuXHJcbiAgICAvKioqKioqKioqKiBFbmQgb2YgcHVibGljIGZ1bmN0aW9ucyAvIFN0YXJ0IG9mIHByb3RlY3RlZCBmdW5jdGlvbnMgKioqKioqKioqKi9cclxuICAgIC8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vXHJcbiAgICAvLy8gR3JpZCBPcHRpb25zIGZ1bmN0aW9uc1xyXG4gICAgLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy9cclxuICAgIHByb3RlY3RlZCBnZXREZWZhdWx0R3JpZE9wdGlvbnMoX2RpcmVjdGlvbjogJ2x0cicgfCAncnRsJywgX3Jvd0hlaWdodDogbnVtYmVyKTogR3JpZE9wdGlvbnMge1xyXG4gICAgICAgIHRoaXMuZGlyZWN0aW9uID0gX2RpcmVjdGlvbjtcclxuXHJcbiAgICAgICAgcmV0dXJuIHtcclxuICAgICAgICAgICAgcm93RGF0YTogW10sXHJcbiAgICAgICAgICAgIGNvbHVtbkRlZnM6IFtdLFxyXG4gICAgICAgICAgICBlbmFibGVSdGw6IF9kaXJlY3Rpb24gPT09ICdydGwnLFxyXG5cclxuICAgICAgICAgICAgaGVhZGVySGVpZ2h0OiAzOCxcclxuICAgICAgICAgICAgcm93SGVpZ2h0OiAodHlwZW9mIF9yb3dIZWlnaHQgIT09ICd1bmRlZmluZWQnKSA/IF9yb3dIZWlnaHQgKyAyMCA6IHRoaXMuUk9XX0hFSUdIVCxcclxuXHJcbiAgICAgICAgICAgIC8vIHN1cHByZXNzTW92YWJsZUNvbHVtbnM6IHRydWUsXHJcbiAgICAgICAgICAgIHN1cHByZXNzRHJhZ0xlYXZlSGlkZXNDb2x1bW5zOiB0cnVlLFxyXG4gICAgICAgICAgICBlbmFibGVDb2xSZXNpemU6IHRydWUsXHJcblxyXG4gICAgICAgICAgICBzdXBwcmVzc0NvbnRleHRNZW51OiB0cnVlLFxyXG4gICAgICAgICAgICBzdXBwcmVzc01lbnVIaWRlOiB0cnVlLFxyXG4gICAgICAgICAgICBlbnN1cmVEb21PcmRlcjogdHJ1ZSxcclxuXHJcbiAgICAgICAgICAgIHN1cHByZXNzUHJvcGVydHlOYW1lc0NoZWNrOiB0cnVlLFxyXG5cclxuICAgICAgICAgICAgLy8gc3VwcHJlc3NDb2x1bW5WaXJ0dWFsaXNhdGlvbjogdHJ1ZSxcclxuXHJcbiAgICAgICAgICAgIGFuaW1hdGVSb3dzOiBmYWxzZSxcclxuICAgICAgICAgICAgcm93QnVmZmVyOiA1LFxyXG5cclxuICAgICAgICAgICAgZ2V0Um93Tm9kZUlkOiAoX2RhdGE6IGFueSk6IHN0cmluZyA9PiB7XHJcbiAgICAgICAgICAgICAgICBsZXQgaWQ6IHN0cmluZyA9IF9kYXRhLmlkO1xyXG5cclxuICAgICAgICAgICAgICAgIGlmICh0eXBlb2YgX2RhdGEuaWQgPT09ICdudW1iZXInKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgaWQgPSBpZC50b1N0cmluZygpO1xyXG4gICAgICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgICAgIHJldHVybiBpZDtcclxuICAgICAgICAgICAgfSxcclxuXHJcbiAgICAgICAgICAgIHVuU29ydEljb246IHRydWUsXHJcbiAgICAgICAgICAgIGljb25zOiB7XHJcbiAgICAgICAgICAgICAgICBmaWx0ZXI6ICc8aSBjbGFzcz1cImZhIGZhLWZpbHRlclwiLz4nLFxyXG4gICAgICAgICAgICAgICAgc29ydEFzY2VuZGluZzogJzxpIGNsYXNzPVwiZmEgZmEtY2FyZXQtZG93blwiLz4nLFxyXG4gICAgICAgICAgICAgICAgc29ydERlc2NlbmRpbmc6ICc8aSBjbGFzcz1cImZhIGZhLWNhcmV0LXVwXCIvPicsXHJcbiAgICAgICAgICAgICAgICBzb3J0VW5Tb3J0OiAnPGkgY2xhc3M9XCJmYSBmYS1zb3J0XCIvPicsXHJcbiAgICAgICAgICAgICAgICAvLyBncm91cEV4cGFuZGVkOiAnPGkgY2xhc3M9XCJmYSBmYS1taW51cy1jaXJjbGVcIi8+JyxcclxuICAgICAgICAgICAgICAgIC8vIGdyb3VwQ29udHJhY3RlZDogJzxpIGNsYXNzPVwiZmEgZmEtcGx1cy1jaXJjbGVcIi8+JyxcclxuICAgICAgICAgICAgICAgIGdyb3VwRXhwYW5kZWQ6ICc8aSBjbGFzcz1cImZhIGZhLWFuZ2xlLWRvd25cIi8+JyxcclxuICAgICAgICAgICAgICAgIGdyb3VwQ29udHJhY3RlZDogJzxpIGNsYXNzPVwiZmEgZmEtYW5nbGUtcmlnaHRcIi8+JyxcclxuXHJcbiAgICAgICAgICAgICAgICBtZW51OiAnPGkgY2xhc3M9XCJmYSBmYS1iYXJzXCIvPidcclxuICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgYXV0b0dyb3VwQ29sdW1uRGVmOiB7XHJcbiAgICAgICAgICAgICAgICBpY29uczoge1xyXG4gICAgICAgICAgICAgICAgICAgIG1lbnU6ICc8aSBjbGFzcz1cImZhIGZhLWJhclwiIHN0eWxlPVwiZGlzcGxheTpub25lXCIvPicsXHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgIGNvbnRleHQ6IHt9LFxyXG4gICAgICAgICAgICBvdmVybGF5Tm9Sb3dzVGVtcGxhdGU6ICc8c3BhbiBjbGFzcz1cImFnLWN1c3RvbS1vdmVybGF5XCI+PGkgY2xhc3M9XCJmYSBmYS1pbmZvLWNpcmNsZSBmYS1sZyBtYXJnaW4tcmlnaHQxMFwiPjwvaT5ObyByZWNvcmQgZm91bmQ8L3NwYW4+J1xyXG4gICAgICAgIH07XHJcbiAgICB9XHJcblxyXG4gICAgLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy9cclxuICAgIC8vLyBDb2x1bW4gRGVmaW5pdGlvbiBmdW5jdGlvbnNcclxuICAgIC8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vXHJcbiAgICBwcm90ZWN0ZWQgZ2VuZXJhdGVDb2x1bW5EZWZpbml0aW9ucyhfY29sdW1uQ29uZmlnOiBBcnJheTxJVGFibGVDb2x1bW4+LCBfZ3JpZENvbmZpZzogSVRhYmxlQ29uZmlnLCBfc3VwcHJlc3NNb3ZhYmxlQ29sdW1uczogYm9vbGVhbj0gdHJ1ZSk6IEFycmF5PENvbERlZj4ge1xyXG4gICAgICAgIGxldCBjb2x1bW5EZWY6IEFycmF5PENvbERlZj4gPSB0aGlzLl9nZW5lcmF0ZUNvbERlZnNGcm9tQ29sQ29uZmlnKF9jb2x1bW5Db25maWcsIF9ncmlkQ29uZmlnLCBfc3VwcHJlc3NNb3ZhYmxlQ29sdW1ucyk7XHJcbiAgICAgICAgbGV0IGNvbHVtbk9iamVjdHM6IHsgW2tleTogc3RyaW5nXTogQ29sRGVmIH0gPSB0aGlzLl9nZW5lcmF0ZUNvbERlZnNGcm9tQ29uZmlnKF9ncmlkQ29uZmlnKTtcclxuXHJcbiAgICAgICAgaWYgKGNvbHVtbk9iamVjdHMuaGFzT3duUHJvcGVydHkoJ2FjdGlvbicpKSB7XHJcbiAgICAgICAgICAgIGNvbHVtbkRlZi5wdXNoKGNvbHVtbk9iamVjdHMuYWN0aW9uKTtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIGlmIChjb2x1bW5PYmplY3RzLmhhc093blByb3BlcnR5KCdzZWxlY3Rpb24nKSkge1xyXG4gICAgICAgICAgICBjb2x1bW5EZWYudW5zaGlmdChjb2x1bW5PYmplY3RzLnNlbGVjdGlvbik7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICByZXR1cm4gY29sdW1uRGVmO1xyXG4gICAgfVxyXG5cclxuICAgIHByb3RlY3RlZCBpc0NvbERlZk9mVHlwZShfY29sRGVmOiBDb2xEZWYsIF90eXBlOiBzdHJpbmcpOiBib29sZWFuIHtcclxuICAgICAgICBpZiAodHlwZW9mIF9jb2xEZWYuY2VsbFJlbmRlcmVyUGFyYW1zICE9PSAndW5kZWZpbmVkJyAmJlxyXG4gICAgICAgICAgICB0eXBlb2YgX2NvbERlZi5jZWxsUmVuZGVyZXJQYXJhbXMucGFyYW1zICE9PSAndW5kZWZpbmVkJyAmJlxyXG4gICAgICAgICAgICB0eXBlb2YgX2NvbERlZi5jZWxsUmVuZGVyZXJQYXJhbXMucGFyYW1zW190eXBlXSAhPT0gJ3VuZGVmaW5lZCcpIHtcclxuICAgICAgICAgICAgcmV0dXJuIHRydWU7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICByZXR1cm4gZmFsc2U7XHJcbiAgICB9XHJcblxyXG4gICAgLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy9cclxuICAgIC8vLyBNaXNjIGZ1bmN0aW9uXHJcbiAgICAvLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vL1xyXG4gICAgcHJvdGVjdGVkIGdlbmVyYXRlQ29udGV4dEtleShfZ3JpZElkOiBzdHJpbmcsIF9jb2x1bW5JZDogc3RyaW5nLCBfcm93SWQ6IHN0cmluZyB8IG51bWJlcik6IHN0cmluZyB7XHJcbiAgICAgICAgcmV0dXJuIF9ncmlkSWQgKyB0aGlzLkNPTlRFWFRfREVMSU1JVEVSICsgX2NvbHVtbklkICsgdGhpcy5DT05URVhUX0RFTElNSVRFUiArIF9yb3dJZDtcclxuICAgIH1cclxuXHJcbiAgICAvKioqKioqKioqKiBFbmQgb2YgcHJvdGVjdGVkIGZ1bmN0aW9ucyAvIFN0YXJ0IG9mIHByaXZhdGUgZnVuY3Rpb25zICoqKioqKioqKiovXHJcbiAgICAvLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vL1xyXG4gICAgLy8vIENvbERlZiAtIENvbHVtbiBkZWZpbml0aW9uIGZ1bmN0aW9uc1xyXG4gICAgLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy9cclxuICAgIHByaXZhdGUgX2dlbmVyYXRlQ29sRGVmc0Zyb21Db2xDb25maWcoX2NvbHVtbkNvbmZpZzogQXJyYXk8SVRhYmxlQ29sdW1uPiwgX2dyaWRDb25maWc6IElUYWJsZUNvbmZpZywgX3N1cHByZXNzTW92YWJsZUNvbHVtbnM6IGJvb2xlYW4gPSB0cnVlKTogQXJyYXk8Q29sRGVmPiB7XHJcbiAgICAgICAgbGV0IGNvbHVtbkRlZjogQXJyYXk8Q29sRGVmPiA9IFtdO1xyXG5cclxuICAgICAgICBmb3IgKGxldCBpOiBudW1iZXIgPSAwOyBpIDwgX2NvbHVtbkNvbmZpZy5sZW5ndGg7IGkrKykge1xyXG4gICAgICAgICAgICBsZXQgY29sdW1uOiBDb2xEZWYgPSB7fTtcclxuXHJcbiAgICAgICAgICAgIGlmICh0eXBlb2YgX2NvbHVtbkNvbmZpZ1tpXSAhPT0gJ3VuZGVmaW5lZCcpIHtcclxuICAgICAgICAgICAgICAgIGxldCB0ZW1wQ29sdW1uOiBJVGFibGVDb2x1bW4gPSAoPGFueT5PYmplY3QpLmFzc2lnbih0aGlzLl9nZXREZWZhdWx0Q29sdW1uQ29uZmlnKCksIF9jb2x1bW5Db25maWdbaV0pO1xyXG4gICAgICAgICAgICAgICAgdGVtcENvbHVtbi5zdXBwcmVzc01vdmFibGUgPSBfc3VwcHJlc3NNb3ZhYmxlQ29sdW1ucztcclxuXHJcbiAgICAgICAgICAgICAgICBzd2l0Y2ggKHRlbXBDb2x1bW4udHlwZSkge1xyXG4gICAgICAgICAgICAgICAgICAgIGNhc2UgJ2lucHV0JzpcclxuICAgICAgICAgICAgICAgICAgICAgICAgY29sdW1uID0gdGhpcy5fZ2VuZXJhdGVJbnB1dENvbERlZih0ZW1wQ29sdW1uLCBfZ3JpZENvbmZpZy5pZCk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgICAgICAgICAgICAgIGNhc2UgJ2ltYWdlJzpcclxuICAgICAgICAgICAgICAgICAgICAgICAgY29sdW1uID0gdGhpcy5fZ2VuZXJhdGVJbWFnZUNvbERlZih0ZW1wQ29sdW1uKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgICAgICAgICAgICAgZGVmYXVsdDpcclxuICAgICAgICAgICAgICAgICAgICAgICAgLy8gVEVNUCBmaXggZm9yIHBpdm90XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC8vIHZhbHVlIGFzc2lnbm1lbnQgaW5zdGVhZCBvZiBvYmplY3QgZGlyZWN0IGFzc2lnbm1lbnQgc28gdG8gYWxsb3cgYXBwbGljYXRpb24gdG8gcGFzcyBpbiBvdGhlciBjb2xkZWZcclxuICAgICAgICAgICAgICAgICAgICAgICAgY29sdW1uID0gdGVtcENvbHVtbjtcclxuICAgICAgICAgICAgICAgICAgICAgICAgY29sdW1uLmhlYWRlck5hbWUgPSB0ZW1wQ29sdW1uLmhlYWRlck5hbWU7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbHVtbi5jb2xJZCA9IHRlbXBDb2x1bW4uZmllbGQ7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbHVtbi5maWVsZCA9IHRlbXBDb2x1bW4uZmllbGQ7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbHVtbi5jZWxsQ2xhc3MgPSAnbm9ybWFsLWNlbGwgJyArIHRlbXBDb2x1bW4uY2xhc3M7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbHVtbi5oaWRlID0gIXRlbXBDb2x1bW4udmlzaWJsZTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgY29sdW1uLnN1cHByZXNzTWVudSA9ICF0ZW1wQ29sdW1uLmZpbHRlcmFibGU7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbHVtbi5zdXBwcmVzc1NvcnRpbmcgPSAhdGVtcENvbHVtbi5zb3J0YWJsZTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgY29sdW1uLm1pbldpZHRoID0gMTAwO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBjb2x1bW4uc3VwcHJlc3NNb3ZhYmxlID0gdGVtcENvbHVtbi5zdXBwcmVzc01vdmFibGU7XHJcbiAgICAgICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICAgICAgaWYgKHRlbXBDb2x1bW4uZmlsdGVyYWJsZSkge1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuX3VwZGF0ZUZpbHRlckNvbERlZihjb2x1bW4sIHRlbXBDb2x1bW4uZmlsdGVyVmFsdWUpO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIGNvbHVtbkRlZi5wdXNoKGNvbHVtbik7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICByZXR1cm4gY29sdW1uRGVmO1xyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX2dlbmVyYXRlQ29sRGVmc0Zyb21Db25maWcoX2NvbmZpZzogSVRhYmxlQ29uZmlnKTogeyBba2V5OiBzdHJpbmddOiBDb2xEZWYgfSB7XHJcbiAgICAgICAgbGV0IGNvbERlZk9iamVjdDogeyBba2V5OiBzdHJpbmddOiBDb2xEZWYgfSA9IHt9O1xyXG5cclxuICAgICAgICBpZiAodHlwZW9mIF9jb25maWcgIT09ICd1bmRlZmluZWQnICYmXHJcbiAgICAgICAgICAgIHR5cGVvZiBfY29uZmlnLmFjdGlvbiAhPT0gJ3VuZGVmaW5lZCcgJiZcclxuICAgICAgICAgICAgX2NvbmZpZy5hY3Rpb24uZW5hYmxlZCkge1xyXG4gICAgICAgICAgICBjb2xEZWZPYmplY3QuYWN0aW9uID0gdGhpcy5fZ2VuZXJhdGVBY3Rpb25Db2xEZWYoX2NvbmZpZy5pZCwgX2NvbmZpZy5hY3Rpb24ubGlzdCwgX2NvbmZpZy5hY3Rpb24ubmFtZSk7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICBpZiAodHlwZW9mIF9jb25maWcgIT09ICd1bmRlZmluZWQnICYmXHJcbiAgICAgICAgICAgIHR5cGVvZiBfY29uZmlnLnNlbGVjdGlvbiAhPT0gJ3VuZGVmaW5lZCcgJiZcclxuICAgICAgICAgICAgdHlwZW9mIF9jb25maWcuc2VsZWN0aW9uLnR5cGUgIT09ICd1bmRlZmluZWQnKSB7XHJcbiAgICAgICAgICAgIGNvbERlZk9iamVjdC5zZWxlY3Rpb24gPSB0aGlzLl9nZW5lcmF0ZUNoZWNrYm94UmFkaW9Db2xEZWYoX2NvbmZpZy5zZWxlY3Rpb24sIF9jb25maWcuaWQpO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgcmV0dXJuIGNvbERlZk9iamVjdDtcclxuICAgIH1cclxuXHJcbiAgICAvLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vL1xyXG4gICAgLy8vIENvbERlZiAtIEFjdGlvbiBkcm9wZG93biBmdW5jdGlvbnNcclxuICAgIC8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vXHJcbiAgICBwcml2YXRlIF9nZW5lcmF0ZUFjdGlvbkNvbERlZihfaWQ6IHN0cmluZywgX2xpc3Q6IEFycmF5PElUYWJsZURyb3Bkb3duQWN0aW9uPiwgX25hbWU/OiBzdHJpbmcpOiBDb2xEZWYge1xyXG4gICAgICAgIHJldHVybiB7XHJcbiAgICAgICAgICAgIGhlYWRlck5hbWU6ICh0eXBlb2YgX25hbWUgIT09ICd1bmRlZmluZWQnKSA/IF9uYW1lIDogJ0FjdGlvbicsXHJcbiAgICAgICAgICAgIHN1cHByZXNzU29ydGluZzogdHJ1ZSxcclxuICAgICAgICAgICAgc3VwcHJlc3NGaWx0ZXI6IHRydWUsXHJcbiAgICAgICAgICAgIHN1cHByZXNzU2l6ZVRvRml0OiB0cnVlLFxyXG4gICAgICAgICAgICBzdXBwcmVzc1Jlc2l6ZTogdHJ1ZSxcclxuICAgICAgICAgICAgc3VwcHJlc3NNZW51OiB0cnVlLFxyXG4gICAgICAgICAgICB3aWR0aDogMTIwLFxyXG4gICAgICAgICAgICBtaW5XaWR0aDogMTIwLFxyXG4gICAgICAgICAgICBtYXhXaWR0aDogMTIwLFxyXG4gICAgICAgICAgICBjZWxsQ2xhc3M6ICdkcm9wZG93bi1hY3Rpb24nLFxyXG4gICAgICAgICAgICBjb2xJZDogJ2FnLWFjdGlvbicsXHJcbiAgICAgICAgICAgIGNlbGxSZW5kZXJlckZyYW1ld29yazogS2RUYWJsZUFjdGlvbixcclxuICAgICAgICAgICAgY2VsbFJlbmRlcmVyUGFyYW1zOiB7XHJcbiAgICAgICAgICAgICAgICBwYXJhbXM6IF9saXN0LFxyXG4gICAgICAgICAgICAgICAgZ3JpZElkOiBfaWRcclxuICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgc3VwcHJlc3NNb3ZhYmxlOiB0cnVlXHJcbiAgICAgICAgfTsgXHJcbiAgICB9XHJcblxyXG4gICAgLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy9cclxuICAgIC8vLyBDb2xEZWYgLSBDaGVja2JveCAvIFJhZGlvIGZ1bmN0aW9uc1xyXG4gICAgLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy9cclxuICAgIHByaXZhdGUgX2dlbmVyYXRlQ2hlY2tib3hSYWRpb0NvbERlZihfc2VsZWN0aW9uT2JqOiBhbnksIF9ncmlkSWQ6IHN0cmluZyk6IENvbERlZiB7XHJcbiAgICAgICAgLy8vIEhhdmUgdG8gc2V0IHRoZSB0eXBlIGFueSBhcyBzZXR0aW5nIGFzIENvbERlZiB3aWxsIGhhcyBpc3N1ZXNcclxuICAgICAgICAvLy8gb24gaGVhZGVyQ29tcG9uZW50RnJhbWV3b3JrIHR5cGUgaXMgd3JvbmdseSB1c2VkLlxyXG5cclxuICAgICAgICBsZXQgY2hlY2tib3hSYWRpb0RpcmVjdGlvbjogc3RyaW5nID0gdGhpcy5kaXJlY3Rpb24gPT09ICdsdHInID8gJ2xlZnQnIDogJ3JpZ2h0JztcclxuXHJcbiAgICAgICAgbGV0IHRlbXBDb2xEZWY6IGFueSA9IHtcclxuICAgICAgICAgICAgc3VwcHJlc3NTb3J0aW5nOiB0cnVlLFxyXG4gICAgICAgICAgICBzdXBwcmVzc0ZpbHRlcjogdHJ1ZSxcclxuICAgICAgICAgICAgc3VwcHJlc3NTaXplVG9GaXQ6IHRydWUsXHJcbiAgICAgICAgICAgIHN1cHByZXNzTWVudTogdHJ1ZSxcclxuICAgICAgICAgICAgc3VwcHJlc3NSZXNpemU6IHRydWUsXHJcbiAgICAgICAgICAgIHdpZHRoOiA1MCxcclxuICAgICAgICAgICAgbWluV2lkdGg6IDUwLFxyXG4gICAgICAgICAgICBtYXhXaWR0aDogNTAsXHJcbiAgICAgICAgICAgIGNlbGxDbGFzczogJ2FnLWRlZmF1bHQgYWctY2hlY2tib3gtcmFkaW8nLFxyXG4gICAgICAgICAgICBwaW5uZWQ6IGNoZWNrYm94UmFkaW9EaXJlY3Rpb24sXHJcbiAgICAgICAgICAgIGNvbElkOiAoX3NlbGVjdGlvbk9iai50eXBlID09PSAnc2luZ2xlJykgPyAncmFkaW8nIDogJ2NoZWNrYm94JyxcclxuICAgICAgICAgICAgY2VsbFJlbmRlcmVyRnJhbWV3b3JrOiBLZFRhYmxlQ2hlY2tib3hSYWRpbyxcclxuICAgICAgICAgICAgY2VsbFJlbmRlcmVyUGFyYW1zOiB7XHJcbiAgICAgICAgICAgICAgICBwYXJhbXM6IHtcclxuICAgICAgICAgICAgICAgICAgICBpbnB1dFR5cGU6IChfc2VsZWN0aW9uT2JqLnR5cGUgPT09ICdzaW5nbGUnKSA/ICdyYWRpbycgOiAnY2hlY2tib3gnLFxyXG4gICAgICAgICAgICAgICAgICAgIGRlZmF1bHQ6IF9zZWxlY3Rpb25PYmoudmFsdWUsXHJcbiAgICAgICAgICAgICAgICAgICAgZ3JpZElkOiBfZ3JpZElkXHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgIHN1cHByZXNzTW92YWJsZTogdHJ1ZVxyXG4gICAgICAgIH07XHJcblxyXG4gICAgICAgIGlmIChfc2VsZWN0aW9uT2JqLnR5cGUgPT09ICdhbGwnKSB7XHJcbiAgICAgICAgICAgIHRlbXBDb2xEZWYuaGVhZGVyQ29tcG9uZW50RnJhbWV3b3JrID0gS2RUYWJsZUNoZWNrYm94UmFkaW87XHJcbiAgICAgICAgICAgIHRlbXBDb2xEZWYuaGVhZGVyQ29tcG9uZW50UGFyYW1zID0ge1xyXG4gICAgICAgICAgICAgICAgcGFyYW1zOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgZGVmYXVsdDogX3NlbGVjdGlvbk9iai52YWx1ZSxcclxuICAgICAgICAgICAgICAgICAgICBncmlkSWQ6IF9ncmlkSWRcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfTtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIHJldHVybiB0ZW1wQ29sRGVmO1xyXG4gICAgfVxyXG5cclxuICAgIC8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vXHJcbiAgICAvLy8gQ29sRGVmIC0gVGFibGUgSW1hZ2UgZnVuY3Rpb25zXHJcbiAgICAvLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vL1xyXG4gICAgcHJpdmF0ZSBfZ2VuZXJhdGVJbWFnZUNvbERlZihfdGVtcENvbHVtbjogSVRhYmxlQ29sdW1uKTogQ29sRGVmIHtcclxuICAgICAgICBsZXQgd2lkdGg6IG51bWJlciA9IHRoaXMuZ2V0SW1hZ2VTaXplQnkoX3RlbXBDb2x1bW4sICd3aWR0aCcpO1xyXG5cclxuICAgICAgICByZXR1cm4ge1xyXG4gICAgICAgICAgICBoZWFkZXJOYW1lOiBfdGVtcENvbHVtbi5oZWFkZXJOYW1lLFxyXG4gICAgICAgICAgICBmaWVsZDogX3RlbXBDb2x1bW4uZmllbGQsXHJcbiAgICAgICAgICAgIGNvbElkOiBfdGVtcENvbHVtbi5maWVsZCxcclxuICAgICAgICAgICAgc3VwcHJlc3NTb3J0aW5nOiB0cnVlLFxyXG4gICAgICAgICAgICBzdXBwcmVzc0ZpbHRlcjogdHJ1ZSxcclxuICAgICAgICAgICAgc3VwcHJlc3NNZW51OiB0cnVlLFxyXG4gICAgICAgICAgICBzdXBwcmVzc1Jlc2l6ZTogdHJ1ZSxcclxuICAgICAgICAgICAgaGlkZTogIV90ZW1wQ29sdW1uLnZpc2libGUsXHJcbiAgICAgICAgICAgIG1pbldpZHRoOiB3aWR0aCxcclxuICAgICAgICAgICAgbWF4V2lkdGg6IHdpZHRoLFxyXG4gICAgICAgICAgICBjZWxsQ2xhc3M6IF90ZW1wQ29sdW1uLmNsYXNzLFxyXG4gICAgICAgICAgICBjZWxsUmVuZGVyZXJGcmFtZXdvcms6IEtkVGFibGVJbWFnZSxcclxuICAgICAgICAgICAgY2VsbFJlbmRlcmVyUGFyYW1zOiB7XHJcbiAgICAgICAgICAgICAgICBwYXJhbXM6IHtcclxuICAgICAgICAgICAgICAgICAgICBbdGhpcy5HSVJEX1BBUkFNU19LRVkuaW1hZ2VdOiBfdGVtcENvbHVtbi5jb25maWcuaW1hZ2UsXHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgIHN1cHByZXNzTW92YWJsZTogX3RlbXBDb2x1bW4uc3VwcHJlc3NNb3ZhYmxlXHJcbiAgICAgICAgfTtcclxuICAgIH1cclxuXHJcbiAgICAvLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vL1xyXG4gICAgLy8vIENvbERlZiAtIFRhYmxlIElucHV0IGZ1bmN0aW9uc1xyXG4gICAgLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy9cclxuICAgIHByaXZhdGUgX2dlbmVyYXRlSW5wdXRDb2xEZWYoX3RlbXBDb2x1bW46IElUYWJsZUNvbHVtbiwgX2dyaWRJZDogc3RyaW5nKTogQ29sRGVmIHtcclxuICAgICAgICByZXR1cm4ge1xyXG4gICAgICAgICAgICBoZWFkZXJOYW1lOiBfdGVtcENvbHVtbi5oZWFkZXJOYW1lLFxyXG4gICAgICAgICAgICBmaWVsZDogX3RlbXBDb2x1bW4uZmllbGQsXHJcbiAgICAgICAgICAgIHN1cHByZXNzU29ydGluZzogdHJ1ZSxcclxuICAgICAgICAgICAgc3VwcHJlc3NGaWx0ZXI6IHRydWUsXHJcbiAgICAgICAgICAgIHN1cHByZXNzTWVudTogdHJ1ZSxcclxuICAgICAgICAgICAgbWluV2lkdGg6IDI1MCxcclxuICAgICAgICAgICAgaGlkZTogIV90ZW1wQ29sdW1uLnZpc2libGUsXHJcbiAgICAgICAgICAgIGNlbGxDbGFzczogX3RlbXBDb2x1bW4uY2xhc3MsXHJcbiAgICAgICAgICAgIGNvbElkOiBfdGVtcENvbHVtbi5maWVsZCxcclxuICAgICAgICAgICAgY2VsbFJlbmRlcmVyRnJhbWV3b3JrOiBLZFRhYmxlSW5wdXQsXHJcbiAgICAgICAgICAgIGNlbGxSZW5kZXJlclBhcmFtczoge1xyXG4gICAgICAgICAgICAgICAgcGFyYW1zOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgW3RoaXMuR0lSRF9QQVJBTVNfS0VZLmlucHV0XTogX3RlbXBDb2x1bW4uY29uZmlnLFxyXG4gICAgICAgICAgICAgICAgICAgIGdyaWRJZDogX2dyaWRJZCxcclxuICAgICAgICAgICAgICAgICAgICBjb250ZXh0S2V5OiB0aGlzLlRBQkxFX0lOUFVUX0NPTlRFWFRfS0VZXHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgIHN1cHByZXNzTW92YWJsZTogX3RlbXBDb2x1bW4uc3VwcHJlc3NNb3ZhYmxlXHJcbiAgICAgICAgfTtcclxuICAgIH1cclxuXHJcbiAgICAvLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vL1xyXG4gICAgLy8vIEFQSSBnZW5lcmF0aW9uIGZ1bmN0aW9uc1xyXG4gICAgLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy9cclxuICAgIHByaXZhdGUgX2dlbmVyYXRlSW5wdXRBcGkoX2dyaWRJZDogc3RyaW5nLCBfa2RUYWJsZUludEV2ZW50OiBLZEludFRhYmxlRXZlbnQpOiBJVGFibGVEeW5hbWljRm9ybUFwaSB7XHJcbiAgICAgICAgcmV0dXJuIHtcclxuICAgICAgICAgICAgZ2V0UHJvcGVydHk6IChfdGFibGVQYXJhbXM6IElUYWJsZUZvcm1VcGRhdGVQYXJhbXMpOiBhbnkgPT4ge1xyXG4gICAgICAgICAgICAgICAgbGV0IGV2ZW50U3RyaW5nID0gdGhpcy5nZW5lcmF0ZUNvbnRleHRLZXkoX2dyaWRJZCwgX3RhYmxlUGFyYW1zLmNvbElkLCBfdGFibGVQYXJhbXMucm93SWQpO1xyXG4gICAgICAgICAgICAgICAgcmV0dXJuIHRoaXMuZ3JpZE9wdGlvbnMuY29udGV4dC50YWJsZUluZGV4Q29udGV4dFtldmVudFN0cmluZ11bX3RhYmxlUGFyYW1zLnF1ZXN0aW9uS2V5XVtfdGFibGVQYXJhbXMucHJvcGVydHldO1xyXG4gICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICBzZXRQcm9wZXJ0eTogKF90YWJsZVBhcmFtczogSVRhYmxlRm9ybVVwZGF0ZVBhcmFtcyk6IHZvaWQgPT4ge1xyXG4gICAgICAgICAgICAgICAgbGV0IGV2ZW50U3RyaW5nID0gdGhpcy5nZW5lcmF0ZUNvbnRleHRLZXkoX2dyaWRJZCwgX3RhYmxlUGFyYW1zLmNvbElkLCBfdGFibGVQYXJhbXMucm93SWQpO1xyXG5cclxuICAgICAgICAgICAgICAgIGlmICh0eXBlb2YgdGhpcy5ncmlkT3B0aW9ucy5jb250ZXh0LnRhYmxlSW5wdXRDb250ZXh0W2V2ZW50U3RyaW5nXSAhPT0gJ3VuZGVmaW5lZCcpIHtcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLmdyaWRPcHRpb25zLmNvbnRleHQudGFibGVJbnB1dENvbnRleHRbZXZlbnRTdHJpbmddW190YWJsZVBhcmFtcy5xdWVzdGlvbktleV1bX3RhYmxlUGFyYW1zLnByb3BlcnR5XSA9IF90YWJsZVBhcmFtcy5kYXRhO1xyXG4gICAgICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgICAgIGxldCByb3dOb2RlOiBSb3dOb2RlID0gdGhpcy5ncmlkT3B0aW9ucy5hcGkuZ2V0Um93Tm9kZShfdGFibGVQYXJhbXMucm93SWQudG9TdHJpbmcoKSk7XHJcblxyXG4gICAgICAgICAgICAgICAgaWYgKF90YWJsZVBhcmFtcy5wcm9wZXJ0eSA9PT0gJ3Zpc2libGUnKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgcm93Tm9kZS5zZXRSb3dIZWlnaHQodW5kZWZpbmVkKTtcclxuICAgICAgICAgICAgICAgICAgICAvLy8gSXNzdWVzIC0gQ2FsbGluZyB0aGlzIGFwaSBvblJvd0hlaWdodENoYW5nZWQgY2F1c2luZyB0aGUgY3VycmVudCBpbnB1dCBjZWxsIHRvIGxvc2UgZm9jdXNcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLmdyaWRPcHRpb25zLmFwaS5vblJvd0hlaWdodENoYW5nZWQoKTtcclxuICAgICAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgICAgICBpZiAoX3RhYmxlUGFyYW1zLnByb3BlcnR5ID09PSAndmFsdWUnKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgcm93Tm9kZS5kYXRhW190YWJsZVBhcmFtcy5jb2xJZF1bX3RhYmxlUGFyYW1zLnF1ZXN0aW9uS2V5XSA9IF90YWJsZVBhcmFtcy5kYXRhO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfTtcclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF9nZW5lcmF0ZUdlbmVyYWxBcGkoX3JvdzogQXJyYXk8YW55Pik6IElUYWJsZUdlbmVyYWxBcGkge1xyXG4gICAgICAgIHJldHVybiB7XHJcbiAgICAgICAgICAgIGdldEN1cnJlbnRSb3dzOiAoKTogQXJyYXk8YW55PiA9PiB7XHJcbiAgICAgICAgICAgICAgICByZXR1cm4gX3Jvdy5zbGljZSgpO1xyXG4gICAgICAgICAgICB9LFxyXG5cclxuICAgICAgICAgICAgcmVzZXRSb3dIZWlnaHQ6ICgpOiB2b2lkID0+IHtcclxuICAgICAgICAgICAgICAgIHRoaXMuZ3JpZE9wdGlvbnMuYXBpLnJlc2V0Um93SGVpZ2h0cygpO1xyXG4gICAgICAgICAgICB9LFxyXG5cclxuICAgICAgICAgICAgc2V0Q29sdW1uVmlzaWJsZTogKF9jb2xJZDogc3RyaW5nLCBfdmlzaWJsZTogYm9vbGVhbik6IHZvaWQgPT4ge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5ncmlkT3B0aW9ucy5jb2x1bW5BcGkuc2V0Q29sdW1uVmlzaWJsZShfY29sSWQsIF92aXNpYmxlKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH07XHJcbiAgICB9XHJcblxyXG4gICAgLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy9cclxuICAgIC8vLyBUYWJsZSBJbnB1dCBmdW5jdGlvbnNcclxuICAgIC8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vXHJcbiAgICAvKipcclxuICAgICAqIFtfZ2VuZXJhdGVUYWJsZUlucHV0Q29udGV4dFxyXG4gICAgICogICAgIEdlbmVyYXRlIHRoZSBpbnB1dCBjb25maWd1cmF0aW9ucyBhbmQgdmFsdWVzIHRvIHRoZSBjb250ZXh0IG9mIHRoZSBncmlkT3B0aW9ucy5cclxuICAgICAqICAgICBBbGwgaW5wdXQgY29uZmlndXJhdGlvbnMgd2lsbCBiZSBzdG9yZWQgaW4gdGFibGVJbnB1dENvbnRleHQgKGdyaWRPcHRpb25zLmNvbnRleHQudGFibGVJbnB1dENvbnRleHQpXHJcbiAgICAgKiAgICAgU3RydWN0dXJlIGlzIGFzIGZvbGxvd3M6XHJcbiAgICAgKiAgICAgICAgIGRlbGltaXRlcjogflxyXG4gICAgICogICAgICAgICBjb250ZXh0S2V5OiBbZ3JpZElkXVtkZWxpbWl0ZXJdW2NvbHVtbklkXVtkZWxpbWl0ZXJdW3Jvd0lkXVxyXG4gICAgICogICAgICAgICAgICAgKGUuZy4gdGFibGVGb3JtfmlucHV0Q29sdW1ufjEpXHJcbiAgICAgKiAgICAgICAgIHF1ZXN0aW9uOiB7XHJcbiAgICAgKiAgICAgICAgICAgICBxdWVzdGlvbktleTogcXVlc3Rpb24gY29uZmlndXJhdGlvbnMsXHJcbiAgICAgKiAgICAgICAgICAgICBxdWVzdGlvbktleTogcXVlc3Rpb24gY29uZmlndXJhdGlvbnNcclxuICAgICAqICAgICAgICAgfVxyXG4gICAgICogICAgICAgICAgICAgKGUuZy4ge1xyXG4gICAgICogICAgICAgICAgICAgICAgIGlucHV0S2V5OiB7XHJcbiAgICAgKiAgICAgICAgICAgICAgICAgICAgIGNvbnRyb2xUeXBlOiAndGV4dCcsXHJcbiAgICAgKiAgICAgICAgICAgICAgICAgICAgIGtleTogJ2lucHV0S2V5JyxcclxuICAgICAqICAgICAgICAgICAgICAgICAgICAgdmlzaWJsZTogdHJ1ZSxcclxuICAgICAqICAgICAgICAgICAgICAgICAgICAgZGlzYWJsZWQ6IGZhbHNlLFxyXG4gICAgICogICAgICAgICAgICAgICAgICAgICB2YWx1ZTogJ1RleHQnXHJcbiAgICAgKiAgICAgICAgICAgICAgICAgfSxcclxuICAgICAqICAgICAgICAgICAgICAgICBkcm9wZG93bktleToge1xyXG4gICAgICogICAgICAgICAgICAgICAgICAgICBjb250cm9sVHlwZTogJ2Ryb3Bkb3duJyxcclxuICAgICAqICAgICAgICAgICAgICAgICAgICAga2V5OiAnZHJvcGRvd25LZXknLFxyXG4gICAgICogICAgICAgICAgICAgICAgICAgICB2aXNpYmxlOiB0cnVlLFxyXG4gICAgICogICAgICAgICAgICAgICAgICAgICB2YWx1ZTogJzEnLFxyXG4gICAgICogICAgICAgICAgICAgICAgICAgICBvcHRpb25zOiBbXHJcbiAgICAgKiAgICAgICAgICAgICAgICAgICAgICAgICB7XHJcbiAgICAgKiAgICAgICAgICAgICAgICAgICAgICAgICAgICAga2V5OiAnJyxcclxuICAgICAqICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZTogJy0tIFBsZWFzZSBzZWxlY3QgLS0nXHJcbiAgICAgKiAgICAgICAgICAgICAgICAgICAgICAgICB9LFxyXG4gICAgICogICAgICAgICAgICAgICAgICAgICAgICAge1xyXG4gICAgICogICAgICAgICAgICAgICAgICAgICAgICAgICAgIGtleTogJzEnLFxyXG4gICAgICogICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlOiAnRmVtYWxlJ1xyXG4gICAgICogICAgICAgICAgICAgICAgICAgICAgICAgfSxcclxuICAgICAqICAgICAgICAgICAgICAgICAgICAgICAgIHtcclxuICAgICAqICAgICAgICAgICAgICAgICAgICAgICAgICAgICBrZXk6ICcyJyxcclxuICAgICAqICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZTogJ01hbGUnXHJcbiAgICAgKiAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgKiAgICAgICAgICAgICAgICAgICAgIF1cclxuICAgICAqICAgICAgICAgICAgICAgICB9XHJcbiAgICAgKiAgICAgICAgICAgICB9KVxyXG4gICAgICpcclxuICAgICAqXHJcbiAgICAgKiAgICAgICAgIGNvbnRleHQudGFibGVJbnB1dENvbnRleHRbY29udGV4dEtleV0gPSBxdWVzdGlvblxyXG4gICAgICogXVxyXG4gICAgICogX2NvbHVtbiAgICA6IFtDb2x1bW4gY29uZmlndXJhdGlvbnNdXHJcbiAgICAgKiBfcm93ICAgICAgIDogW1JvdyBkYXRhXVxyXG4gICAgICogX2dyaWRJZCAgICA6IFtHcmlkIElEXVxyXG4gICAgICovXHJcbiAgICBwcml2YXRlIF9nZW5lcmF0ZVRhYmxlSW5wdXRDb250ZXh0KF9jb2x1bW46IEFycmF5PElUYWJsZUNvbHVtbj4sIF9yb3c6IEFycmF5PGFueT4sIF9ncmlkSWQ6IHN0cmluZyk6IHsgW2tleTogc3RyaW5nXTogYW55IH0ge1xyXG4gICAgICAgIGxldCB0YWJsZUlucHV0Q29udGV4dDogYW55ID0ge307XHJcblxyXG4gICAgICAgIGZvciAobGV0IGk6IG51bWJlciA9IDA7IGkgPCBfY29sdW1uLmxlbmd0aDsgKytpKSB7XHJcbiAgICAgICAgICAgIGlmICh0aGlzLmlzSW5wdXRUeXBlKF9jb2x1bW5baV0sICdpbnB1dCcpKSB7XHJcbiAgICAgICAgICAgICAgICBsZXQgY3VycmVudENvbHVtbjogSVRhYmxlQ29sdW1uID0gX2NvbHVtbltpXTtcclxuICAgICAgICAgICAgICAgIGxldCBjdXJyZW50Q29sdW1uSWQ6IHN0cmluZyA9IGN1cnJlbnRDb2x1bW4uZmllbGQ7XHJcblxyXG4gICAgICAgICAgICAgICAgZm9yIChsZXQgajogbnVtYmVyID0gMDsgaiA8IF9yb3cubGVuZ3RoOyArK2opIHtcclxuICAgICAgICAgICAgICAgICAgICBpZiAodHlwZW9mIF9yb3dbal1bdGhpcy5yb3dLZXldICE9PSAndW5kZWZpbmVkJykge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBsZXQgY29udGV4dE9iamVjdDogYW55ID0ge307XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAvLyBjb25zb2xlLmxvZygnLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLScpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAvLyBjb25zb2xlLmxvZygnY3VycmVudENvbHVtbiAtICcsIGN1cnJlbnRDb2x1bW4pO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAvLyBjb25zb2xlLmxvZygnY3VycmVudENvbHVtbklkIC0gJywgY3VycmVudENvbHVtbklkKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgLy8gY29uc29sZS5sb2coJ19yb3dbal0gLSAnLCBfcm93W2pdKTtcclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC8vIFNldCB0aGUgcm93IGRhdGEgd2l0aCB0aGUgY29sdW1uIGtleSBpZiBpcyBub3QgZGVmaW5lZFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAodHlwZW9mIF9yb3dbal1bY3VycmVudENvbHVtbklkXSA9PT0gJ3VuZGVmaW5lZCcpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIF9yb3dbal1bY3VycmVudENvbHVtbklkXSA9IHt9O1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAvLyBTZXQgdGhlIGlucHV0IHRvIHRoZSBjb250ZXh0T2JqZWN0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGlmICh0eXBlb2YgY3VycmVudENvbHVtbi5jb25maWcgIT09ICd1bmRlZmluZWQnICYmIHR5cGVvZiBjdXJyZW50Q29sdW1uLmNvbmZpZy5pbnB1dCAhPT0gJ3VuZGVmaW5lZCcpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxldCBwcm9jZXNzSW5wdXREYXRhOiBBcnJheTxJVGFibGVGb3JtSW5wdXQ+ID0gKGN1cnJlbnRDb2x1bW4uY29uZmlnLmlucHV0IGluc3RhbmNlb2YgQXJyYXkpID8gY3VycmVudENvbHVtbi5jb25maWcuaW5wdXQgOiBbY3VycmVudENvbHVtbi5jb25maWcuaW5wdXRdO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgbGV0IHJvd0NvbHVtbkRhdGE6IGFueSA9IF9yb3dbal1bY3VycmVudENvbHVtbklkXTtcclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBmb3IgKGxldCBrOiBudW1iZXIgPSAwOyBrIDwgcHJvY2Vzc0lucHV0RGF0YS5sZW5ndGg7ICsraykge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIFNldCB0aGUgcm93IGRhdGEgaW5wdXQga2V5IHZhbHVlIGlmIG5vIGlucHV0IGtleSBvZiB0aGUgY29sdW1uIGlzIGRlZmluZWRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAodHlwZW9mIHJvd0NvbHVtbkRhdGFbcHJvY2Vzc0lucHV0RGF0YVtrXS5rZXldID09PSAndW5kZWZpbmVkJykge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICByb3dDb2x1bW5EYXRhW3Byb2Nlc3NJbnB1dERhdGFba10ua2V5XSA9ICcnO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29udGV4dE9iamVjdFtwcm9jZXNzSW5wdXREYXRhW2tdLmtleV0gPSAoPGFueT5PYmplY3QpLmFzc2lnbih7fSwgcHJvY2Vzc0lucHV0RGF0YVtrXSk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29udGV4dE9iamVjdFtwcm9jZXNzSW5wdXREYXRhW2tdLmtleV0udmFsdWUgPSByb3dDb2x1bW5EYXRhW3Byb2Nlc3NJbnB1dERhdGFba10ua2V5XTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnNvbGUuZXJyb3IoJ0tkVGFibGUgZXJyb3IgLSBDb2x1bW4gc3BlY2lmeSBhcyBpbnB1dCBidXQgbm8gY29uZmlnIHBhc3NlZCBpbi4gTm8gaW5wdXQgd2lsbCBiZSBnZW5lcmF0ZWQuJyk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGxldCBjb250ZXh0S2V5OiBzdHJpbmcgPSB0aGlzLmdlbmVyYXRlQ29udGV4dEtleShfZ3JpZElkLCBjdXJyZW50Q29sdW1uSWQsIF9yb3dbal1bdGhpcy5yb3dLZXldKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgdGFibGVJbnB1dENvbnRleHRbY29udGV4dEtleV0gPSAoPGFueT5PYmplY3QpLmFzc2lnbih7fSwgY29udGV4dE9iamVjdCk7XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBjb25zb2xlLmVycm9yKCdLZFRhYmxlIGVycm9yIC0gUm93IHBhc3NlZCBpbiB3aXRoIG5vIHJvd0tleSAoJyArIHRoaXMucm93S2V5ICsgJykuIElucHV0IGNlbGwgY29tcG9uZW50IHJlcXVpcmVzIHJvd0tleSB0byBnZW5lcmF0ZS4nKTtcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIHJldHVybiB0YWJsZUlucHV0Q29udGV4dDtcclxuICAgIH1cclxuXHJcbiAgICAvLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vL1xyXG4gICAgLy8vIFNlbGVjdGlvbiBmdW5jdGlvbiAtIFJldHVybiB2YWx1ZSBmdW5jdGlvbnNcclxuICAgIC8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vXHJcbiAgICAvKipcclxuICAgICAqIFtfY29udmVydERhdGFWYWx1ZVRvT2JqZWN0IC0gQ29udmVydCByZXR1cm4gZnJvbSBkb3Qgc2VwYXJhdGVkIHRvIG9iamVjdCB2YWx1ZS4gRXhhbXBsZTpcclxuICAgICAqICAgICAtIEZyb206IFwiaW5zdHV0aXRpb25faWQuaW5zdHV0aXRpb25fbmFtZVwiOiBcIkFuZGVyc29uIFByaW1hcnkgU2Nob29sXCI7XHJcbiAgICAgKiAgICAgLSBUbyAgOiBpbnN0dXRpdGlvbl9pZDoge1xyXG4gICAgICogICAgICAgICAgICAgICAgIGluc3R1dGl0aW9uX25hbWU6XCJBbmRlcnNvbiBQcmltYXJ5IFNjaG9vbFwiXHJcbiAgICAgKiAgICAgICAgICAgICB9O1xyXG4gICAgICogXVxyXG4gICAgICogX2N1cnJlbnRJdGVtICAgIDogW0N1cnJlbnQgc2VsZWN0aW9uIGtleV1cclxuICAgICAqIF9vYmpLZXkgICAgICAgICA6IFtEb3Qgc2VwYXJhdGVkIG9iamVjdCBrZXlzXVxyXG4gICAgICogX3ZhbHVlICAgICAgICAgIDogW0RhdGEgdmFsdWUgZm9yIHRoZSBvYmplY3RdXHJcbiAgICAgKlxyXG4gICAgICovXHJcbiAgICBwcml2YXRlIF9jb252ZXJ0RGF0YVZhbHVlVG9PYmplY3QoX2N1cnJlbnRJdGVtOiBhbnksIF9vYmpLZXk6IHN0cmluZywgX3ZhbHVlOiBhbnksIF9zZXBhcmF0b3I6IHN0cmluZyA9ICcuJyk6IGFueSB7XHJcbiAgICAgICAgbGV0IG9iamVjdEtleUFycjogQXJyYXk8c3RyaW5nPiA9IF9vYmpLZXkuc3BsaXQoX3NlcGFyYXRvcik7XHJcbiAgICAgICAgcmV0dXJuIHRoaXMuX2FwcGVuZERhdGFWYWx1ZUtleShvYmplY3RLZXlBcnIsIF9jdXJyZW50SXRlbSwgX3ZhbHVlKTtcclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF9hcHBlbmREYXRhVmFsdWVLZXkoX2tleTogQXJyYXk8c3RyaW5nPiwgX2N1cnJlbnRPYmo6IGFueSwgX3ZhbHVlOiBhbnkpOiBhbnkge1xyXG4gICAgICAgIGlmIChfa2V5Lmxlbmd0aCA+IDApIHtcclxuICAgICAgICAgICAgbGV0IGN1cnJlbnRLZXk6IHN0cmluZyA9IF9rZXlbMF07XHJcblxyXG4gICAgICAgICAgICBpZiAodHlwZW9mIF9jdXJyZW50T2JqW2N1cnJlbnRLZXldID09PSAndW5kZWZpbmVkJykge1xyXG4gICAgICAgICAgICAgICAgX2N1cnJlbnRPYmpbY3VycmVudEtleV0gPSB7fTtcclxuICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgX2tleS5zaGlmdCgpO1xyXG4gICAgICAgICAgICBfY3VycmVudE9ialtjdXJyZW50S2V5XSA9IHRoaXMuX2FwcGVuZERhdGFWYWx1ZUtleShfa2V5LCBfY3VycmVudE9ialtjdXJyZW50S2V5XSwgX3ZhbHVlKTtcclxuICAgICAgICB9XHJcbiAgICAgICAgZWxzZSB7XHJcbiAgICAgICAgICAgIF9jdXJyZW50T2JqID0gX3ZhbHVlO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgcmV0dXJuIF9jdXJyZW50T2JqO1xyXG4gICAgfVxyXG5cclxuICAgIC8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vXHJcbiAgICAvLy8gTWlzYyBmdW5jdGlvbnNcclxuICAgIC8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vXHJcbiAgICBwcml2YXRlIF91cGRhdGVGaWx0ZXJDb2xEZWYoX2NvbERlZjogQ29sRGVmLCBfZmlsdGVyVmFsPzogQXJyYXk8c3RyaW5nPik6IHZvaWQge1xyXG4gICAgICAgIF9jb2xEZWYubWVudVRhYnMgPSBbJ2ZpbHRlck1lbnVUYWInXTtcclxuICAgICAgICBfY29sRGVmLmZpbHRlciA9ICdhZ1NldENvbHVtbkZpbHRlcic7XHJcbiAgICAgICAgX2NvbERlZi5maWx0ZXJQYXJhbXMgPSB7XHJcbiAgICAgICAgICAgIG5ld1Jvd3NBY3Rpb246ICdrZWVwJyxcclxuICAgICAgICAgICAgY2VsbEhlaWdodDogMzAsXHJcbiAgICAgICAgICAgIHNlbGVjdEFsbE9uTWluaUZpbHRlcjogdHJ1ZVxyXG4gICAgICAgIH07XHJcblxyXG4gICAgICAgIGlmICh0eXBlb2YgX2ZpbHRlclZhbCAhPT0gJ3VuZGVmaW5lZCcpIHtcclxuICAgICAgICAgICAgX2NvbERlZi5maWx0ZXJQYXJhbXMudmFsdWVzID0gX2ZpbHRlclZhbDtcclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfZ2V0RGVmYXVsdENvbHVtbkNvbmZpZygpOiBJVGFibGVDb2x1bW4ge1xyXG4gICAgICAgIHJldHVybiB7XHJcbiAgICAgICAgICAgIHNvcnRhYmxlOiBmYWxzZSxcclxuICAgICAgICAgICAgZmlsdGVyYWJsZTogZmFsc2UsXHJcbiAgICAgICAgICAgIHZpc2libGU6IHRydWUsXHJcbiAgICAgICAgfTtcclxuICAgIH1cclxuXHJcbiAgICAvKioqKioqKioqKioqKioqKioqKioqKioqKiBFbmQgb2YgcHJpdmF0ZSBmdW5jdGlvbnMgKioqKioqKioqKioqKioqKioqKioqKioqKiovXHJcbn1cclxuIl19