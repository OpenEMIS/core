import { __decorate, __extends } from "tslib";
import { Injectable } from '@angular/core';
import { KdTableSvcBase } from './kd-table-svc';
/**
 * -- Documentation for kd-table-normal-svc.ts --
 *
 * Public function:
 *     - Grid Options function
 *         - generateGridOptions (GridOption generation with gridConfig)
 *         - setGridOptions
 *     - Column definition functions
 *         - setColumnDef (Column Definitions based on columnConfig and gridConfig)
 *         - generateColumnDefinitions
 *     - Row data functions
 *         - setRowData (Set the rowData to the grid)
 *
 * Private functions:
 *     - Grid Options function
 *         - _generateConfigOptions (additional GridOption from table config)
 *     - Row height functions
 *         - _getRowHeight
 *         - _calculateRowHeight
 *         - _getQuestionHeight
 */
var KdTableNormalSvc = /** @class */ (function (_super) {
    __extends(KdTableNormalSvc, _super);
    function KdTableNormalSvc() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this._movableColumn = false;
        return _this;
        /************************* End of private functions **************************/
    }
    /***************************** Public functions ******************************/
    ////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// Grid options functions
    ////////////////////////////////////////////////////////////////////////////////////////////////////////
    KdTableNormalSvc.prototype.generateGridOptions = function (_gridConfig, _direction) {
        var tempGridOptions = _super.prototype.getDefaultGridOptions.call(this, _direction, _gridConfig.rowContentHeight);
        delete tempGridOptions.rowHeight;
        var configOptions = this._generateConfigOptions(_gridConfig);
        Object.assign(tempGridOptions, configOptions);
        return tempGridOptions;
    };
    KdTableNormalSvc.prototype.setGridOptions = function (_gridOptions) {
        this.gridOptions = _gridOptions;
    };
    ////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// Column definition functions
    ////////////////////////////////////////////////////////////////////////////////////////////////////////
    KdTableNormalSvc.prototype.setColumnDef = function (_colDefConfig, _gridConfig, _suppressMovableColumns) {
        if (_suppressMovableColumns === void 0) { _suppressMovableColumns = true; }
        var updatedColumn = this.generateColumnDefinitions(_colDefConfig, _gridConfig, _suppressMovableColumns);
        this.gridOptions.columnDefs = updatedColumn;
        if (_super.prototype.isApiReady.call(this, this.gridOptions)) {
            this.gridOptions.api.setColumnDefs(updatedColumn);
        }
    };
    KdTableNormalSvc.prototype.generateColumnDefinitions = function (_colDefConfig, _gridConfig, _suppressMovableColumns) {
        if (_suppressMovableColumns === void 0) { _suppressMovableColumns = true; }
        return _super.prototype.generateColumnDefinitions.call(this, _colDefConfig, _gridConfig, _suppressMovableColumns);
    };
    ////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// Row Data functions
    ////////////////////////////////////////////////////////////////////////////////////////////////////////
    KdTableNormalSvc.prototype.setRowData = function (_rowData) {
        this.gridOptions.rowData = _rowData;
        if (_super.prototype.isApiReady.call(this, this.gridOptions)) {
            this.gridOptions.api.setRowData(_rowData);
        }
    };
    /************ End of public functions / Start of private functions ***********/
    ////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// Grid options functions
    ////////////////////////////////////////////////////////////////////////////////////////////////////////
    KdTableNormalSvc.prototype._generateConfigOptions = function (_config) {
        var _this = this;
        var sidebarValue = false;
        if ('pivot' in _config) {
            sidebarValue = _config.pivot.state.pivotMode;
        }
        var configOptions = {
            rowModelType: 'clientSide',
            enableSorting: true,
            enableFilter: true,
            getRowHeight: function (_params) {
                return _this._getRowHeight(_params);
            },
            sideBar: sidebarValue
        };
        if (typeof _config.rowIdKey !== 'undefined') {
            this.rowKey = _config.rowIdKey;
            configOptions.getRowNodeId = function (_data) {
                if (_data.hasOwnProperty(_config.rowIdKey)) {
                    var id = _data[_config.rowIdKey];
                    if (typeof _data[_config.rowIdKey] === 'number') {
                        id = id.toString();
                    }
                    return id;
                }
                else if (_data.hasOwnProperty('data')) {
                    var id = _data.data[_config.rowIdKey];
                    if (typeof _data.data[_config.rowIdKey] === 'number') {
                        id = id.toString();
                    }
                    return id;
                }
                return '';
            };
        }
        return configOptions;
    };
    ////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// Row Height functions
    ////////////////////////////////////////////////////////////////////////////////////////////////////////
    KdTableNormalSvc.prototype._getRowHeight = function (_params) {
        var maxHeight = this.ROW_HEIGHT;
        var allColumns = _params.node.columnApi.getAllColumns();
        var columnHeight = 0;
        for (var i = 0; i < allColumns.length; ++i) {
            columnHeight = this.ROW_HEIGHT;
            if (_super.prototype.isColDefOfType.call(this, allColumns[i].getColDef(), this.GIRD_PARAMS_KEY.input)) {
                var contextKey = _super.prototype.generateContextKey.call(this, _params.context.gridId, allColumns[i].getColDef().colId, _params.node.id);
                if (_params.context[this.TABLE_INPUT_CONTEXT_KEY].hasOwnProperty(contextKey)) {
                    columnHeight = this._calculateRowHeight(_params.context[this.TABLE_INPUT_CONTEXT_KEY][contextKey]);
                }
            }
            if (_super.prototype.isColDefOfType.call(this, allColumns[i].getColDef(), this.GIRD_PARAMS_KEY.image)) {
                var defaultColHeight = 150;
                if (typeof allColumns[i].getColDef().cellRendererParams.params.imageConfig.height !== 'undefined') {
                    columnHeight = allColumns[i].getColDef().cellRendererParams.params.imageConfig.height + this.IMAGE_PADDING;
                }
                else {
                    columnHeight = defaultColHeight + this.IMAGE_PADDING;
                }
            }
            if (columnHeight > maxHeight) {
                maxHeight = columnHeight;
            }
        }
        return maxHeight;
    };
    KdTableNormalSvc.prototype._calculateRowHeight = function (_contextData) {
        var height = 0;
        for (var item in _contextData) {
            if (_contextData.hasOwnProperty(item)) {
                height += this._getQuestionHeight(_contextData[item]);
            }
        }
        return height;
    };
    KdTableNormalSvc.prototype._getQuestionHeight = function (_tableDataItem) {
        var height = 0;
        if (_tableDataItem.visible) {
            height += 50;
        }
        if (_tableDataItem.visible && _tableDataItem.controlType === 'textarea') {
            height += 70;
        }
        return height;
    };
    KdTableNormalSvc = __decorate([
        Injectable()
    ], KdTableNormalSvc);
    return KdTableNormalSvc;
}(KdTableSvcBase));
export { KdTableNormalSvc };
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoia2QtdGFibGUtbm9ybWFsLXN2Yy5qcyIsInNvdXJjZVJvb3QiOiJuZzovL29wZW5lbWlzLXN0eWxlZ3VpZGUtbGliLyIsInNvdXJjZXMiOlsia2QtY29tcG9uZW50cy9rZC1hbmd1bGFyLXRhYmxlL3RhYmxlLXNlcnZpY2VzL2tkLXRhYmxlLW5vcm1hbC1zdmMudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IjtBQUFBLE9BQU8sRUFBRSxVQUFVLEVBQUUsTUFBTSxlQUFlLENBQUM7QUFZM0MsT0FBTyxFQUFFLGNBQWMsRUFBRSxNQUFNLGdCQUFnQixDQUFDO0FBRWhEOzs7Ozs7Ozs7Ozs7Ozs7Ozs7OztHQW9CRztBQUdIO0lBQXNDLG9DQUFjO0lBQXBEO1FBQUEscUVBaUtDO1FBaEtXLG9CQUFjLEdBQVksS0FBSyxDQUFDOztRQStKeEMsK0VBQStFO0lBQ25GLENBQUM7SUEvSkcsK0VBQStFO0lBQy9FLHdHQUF3RztJQUN4RywwQkFBMEI7SUFDMUIsd0dBQXdHO0lBQ2pHLDhDQUFtQixHQUExQixVQUEyQixXQUF5QixFQUFFLFVBQXlCO1FBQzNFLElBQUksZUFBZSxHQUFnQixpQkFBTSxxQkFBcUIsWUFBQyxVQUFVLEVBQUUsV0FBVyxDQUFDLGdCQUFnQixDQUFDLENBQUM7UUFFekcsT0FBTyxlQUFlLENBQUMsU0FBUyxDQUFDO1FBQ2pDLElBQUksYUFBYSxHQUFnQixJQUFJLENBQUMsc0JBQXNCLENBQUMsV0FBVyxDQUFDLENBQUM7UUFFcEUsTUFBTyxDQUFDLE1BQU0sQ0FBQyxlQUFlLEVBQUUsYUFBYSxDQUFDLENBQUM7UUFFckQsT0FBTyxlQUFlLENBQUM7SUFDM0IsQ0FBQztJQUVNLHlDQUFjLEdBQXJCLFVBQXNCLFlBQXlCO1FBQzNDLElBQUksQ0FBQyxXQUFXLEdBQUcsWUFBWSxDQUFDO0lBQ3BDLENBQUM7SUFFRCx3R0FBd0c7SUFDeEcsK0JBQStCO0lBQy9CLHdHQUF3RztJQUNqRyx1Q0FBWSxHQUFuQixVQUFvQixhQUFrQyxFQUFFLFdBQXlCLEVBQUUsdUJBQXVDO1FBQXZDLHdDQUFBLEVBQUEsOEJBQXVDO1FBQ3RILElBQUksYUFBYSxHQUFrQixJQUFJLENBQUMseUJBQXlCLENBQUMsYUFBYSxFQUFFLFdBQVcsRUFBRSx1QkFBdUIsQ0FBQyxDQUFDO1FBRXZILElBQUksQ0FBQyxXQUFXLENBQUMsVUFBVSxHQUFHLGFBQWEsQ0FBQztRQUU1QyxJQUFJLGlCQUFNLFVBQVUsWUFBQyxJQUFJLENBQUMsV0FBVyxDQUFDLEVBQUU7WUFDcEMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxHQUFHLENBQUMsYUFBYSxDQUFDLGFBQWEsQ0FBQyxDQUFDO1NBQ3JEO0lBQ0wsQ0FBQztJQUVNLG9EQUF5QixHQUFoQyxVQUFpQyxhQUFrQyxFQUFFLFdBQXlCLEVBQUUsdUJBQXVDO1FBQXZDLHdDQUFBLEVBQUEsOEJBQXVDO1FBQ25JLE9BQU8saUJBQU0seUJBQXlCLFlBQUMsYUFBYSxFQUFFLFdBQVcsRUFBRSx1QkFBdUIsQ0FBQyxDQUFDO0lBQ2hHLENBQUM7SUFFRCx3R0FBd0c7SUFDeEcsc0JBQXNCO0lBQ3RCLHdHQUF3RztJQUNqRyxxQ0FBVSxHQUFqQixVQUFrQixRQUFvQjtRQUNsQyxJQUFJLENBQUMsV0FBVyxDQUFDLE9BQU8sR0FBRyxRQUFRLENBQUM7UUFDcEMsSUFBSSxpQkFBTSxVQUFVLFlBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxFQUFFO1lBQ3BDLElBQUksQ0FBQyxXQUFXLENBQUMsR0FBRyxDQUFDLFVBQVUsQ0FBQyxRQUFRLENBQUMsQ0FBQztTQUM3QztJQUNMLENBQUM7SUFFRCwrRUFBK0U7SUFDL0Usd0dBQXdHO0lBQ3hHLDBCQUEwQjtJQUMxQix3R0FBd0c7SUFDaEcsaURBQXNCLEdBQTlCLFVBQStCLE9BQXFCO1FBQXBELGlCQTBDQztRQXpDRyxJQUFJLFlBQVksR0FBRyxLQUFLLENBQUM7UUFDekIsSUFBRyxPQUFPLElBQUksT0FBTyxFQUFFO1lBQ25CLFlBQVksR0FBRyxPQUFPLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxTQUFTLENBQUM7U0FDaEQ7UUFDRCxJQUFJLGFBQWEsR0FBZ0I7WUFDN0IsWUFBWSxFQUFFLFlBQVk7WUFDMUIsYUFBYSxFQUFFLElBQUk7WUFDbkIsWUFBWSxFQUFFLElBQUk7WUFDbEIsWUFBWSxFQUFFLFVBQUMsT0FBWTtnQkFDdkIsT0FBTyxLQUFJLENBQUMsYUFBYSxDQUFDLE9BQU8sQ0FBQyxDQUFDO1lBQ3ZDLENBQUM7WUFDRCxPQUFPLEVBQUcsWUFBWTtTQUN6QixDQUFDO1FBRUYsSUFBSSxPQUFPLE9BQU8sQ0FBQyxRQUFRLEtBQUssV0FBVyxFQUFFO1lBQ3pDLElBQUksQ0FBQyxNQUFNLEdBQUcsT0FBTyxDQUFDLFFBQVEsQ0FBQztZQUUvQixhQUFhLENBQUMsWUFBWSxHQUFHLFVBQUMsS0FBVTtnQkFDcEMsSUFBSSxLQUFLLENBQUMsY0FBYyxDQUFDLE9BQU8sQ0FBQyxRQUFRLENBQUMsRUFBRTtvQkFDeEMsSUFBSSxFQUFFLEdBQVcsS0FBSyxDQUFDLE9BQU8sQ0FBQyxRQUFRLENBQUMsQ0FBQztvQkFFekMsSUFBSSxPQUFPLEtBQUssQ0FBQyxPQUFPLENBQUMsUUFBUSxDQUFDLEtBQUssUUFBUSxFQUFFO3dCQUM3QyxFQUFFLEdBQUcsRUFBRSxDQUFDLFFBQVEsRUFBRSxDQUFDO3FCQUN0QjtvQkFFRCxPQUFPLEVBQUUsQ0FBQztpQkFDYjtxQkFBSyxJQUFHLEtBQUssQ0FBQyxjQUFjLENBQUMsTUFBTSxDQUFDLEVBQUM7b0JBQ2xDLElBQUksRUFBRSxHQUFXLEtBQUssQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLFFBQVEsQ0FBQyxDQUFDO29CQUU5QyxJQUFJLE9BQU8sS0FBSyxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsUUFBUSxDQUFDLEtBQUssUUFBUSxFQUFFO3dCQUNsRCxFQUFFLEdBQUcsRUFBRSxDQUFDLFFBQVEsRUFBRSxDQUFDO3FCQUN0QjtvQkFFRCxPQUFPLEVBQUUsQ0FBQztpQkFDYjtnQkFFRCxPQUFPLEVBQUUsQ0FBQztZQUNkLENBQUMsQ0FBQztTQUNMO1FBRUQsT0FBTyxhQUFhLENBQUM7SUFDekIsQ0FBQztJQUVELHdHQUF3RztJQUN4Ryx3QkFBd0I7SUFDeEIsd0dBQXdHO0lBQ2hHLHdDQUFhLEdBQXJCLFVBQXNCLE9BQStEO1FBQ2pGLElBQUksU0FBUyxHQUFXLElBQUksQ0FBQyxVQUFVLENBQUM7UUFDeEMsSUFBSSxVQUFVLEdBQXdCLE9BQU8sQ0FBQyxJQUFLLENBQUMsU0FBUyxDQUFDLGFBQWEsRUFBRSxDQUFDO1FBQzlFLElBQUksWUFBWSxHQUFXLENBQUMsQ0FBQztRQUU3QixLQUFLLElBQUksQ0FBQyxHQUFXLENBQUMsRUFBRSxDQUFDLEdBQUcsVUFBVSxDQUFDLE1BQU0sRUFBRSxFQUFFLENBQUMsRUFBRTtZQUNoRCxZQUFZLEdBQUcsSUFBSSxDQUFDLFVBQVUsQ0FBQztZQUUvQixJQUFJLGlCQUFNLGNBQWMsWUFBQyxVQUFVLENBQUMsQ0FBQyxDQUFDLENBQUMsU0FBUyxFQUFFLEVBQUUsSUFBSSxDQUFDLGVBQWUsQ0FBQyxLQUFLLENBQUMsRUFBRTtnQkFDN0UsSUFBSSxVQUFVLEdBQVcsaUJBQU0sa0JBQWtCLFlBQUMsT0FBTyxDQUFDLE9BQU8sQ0FBQyxNQUFNLEVBQUUsVUFBVSxDQUFDLENBQUMsQ0FBQyxDQUFDLFNBQVMsRUFBRSxDQUFDLEtBQUssRUFBRSxPQUFPLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxDQUFDO2dCQUU1SCxJQUFJLE9BQU8sQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLHVCQUF1QixDQUFDLENBQUMsY0FBYyxDQUFDLFVBQVUsQ0FBQyxFQUFFO29CQUMxRSxZQUFZLEdBQUcsSUFBSSxDQUFDLG1CQUFtQixDQUFDLE9BQU8sQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLHVCQUF1QixDQUFDLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQztpQkFDdEc7YUFDSjtZQUVELElBQUksaUJBQU0sY0FBYyxZQUFDLFVBQVUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxTQUFTLEVBQUUsRUFBRSxJQUFJLENBQUMsZUFBZSxDQUFDLEtBQUssQ0FBQyxFQUFFO2dCQUM3RSxJQUFNLGdCQUFnQixHQUFXLEdBQUcsQ0FBQztnQkFFckMsSUFBSSxPQUFPLFVBQVUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxTQUFTLEVBQUUsQ0FBQyxrQkFBa0IsQ0FBQyxNQUFNLENBQUMsV0FBVyxDQUFDLE1BQU0sS0FBSyxXQUFXLEVBQUU7b0JBQy9GLFlBQVksR0FBRyxVQUFVLENBQUMsQ0FBQyxDQUFDLENBQUMsU0FBUyxFQUFFLENBQUMsa0JBQWtCLENBQUMsTUFBTSxDQUFDLFdBQVcsQ0FBQyxNQUFNLEdBQUcsSUFBSSxDQUFDLGFBQWEsQ0FBQztpQkFDOUc7cUJBQ0k7b0JBQ0QsWUFBWSxHQUFHLGdCQUFnQixHQUFHLElBQUksQ0FBQyxhQUFhLENBQUM7aUJBQ3hEO2FBQ0o7WUFFRCxJQUFJLFlBQVksR0FBRyxTQUFTLEVBQUU7Z0JBQzFCLFNBQVMsR0FBRyxZQUFZLENBQUM7YUFDNUI7U0FDSjtRQUVELE9BQU8sU0FBUyxDQUFDO0lBQ3JCLENBQUM7SUFFTyw4Q0FBbUIsR0FBM0IsVUFBNEIsWUFBaUI7UUFDekMsSUFBSSxNQUFNLEdBQVcsQ0FBQyxDQUFDO1FBRXZCLEtBQUssSUFBSSxJQUFJLElBQUksWUFBWSxFQUFFO1lBQzNCLElBQUksWUFBWSxDQUFDLGNBQWMsQ0FBQyxJQUFJLENBQUMsRUFBRTtnQkFDbkMsTUFBTSxJQUFJLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxZQUFZLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQzthQUN6RDtTQUNKO1FBRUQsT0FBTyxNQUFNLENBQUM7SUFDbEIsQ0FBQztJQUVPLDZDQUFrQixHQUExQixVQUEyQixjQUFtQjtRQUMxQyxJQUFJLE1BQU0sR0FBVyxDQUFDLENBQUM7UUFFdkIsSUFBSSxjQUFjLENBQUMsT0FBTyxFQUFFO1lBQ3hCLE1BQU0sSUFBSSxFQUFFLENBQUM7U0FDaEI7UUFFRCxJQUFJLGNBQWMsQ0FBQyxPQUFPLElBQUksY0FBYyxDQUFDLFdBQVcsS0FBSyxVQUFVLEVBQUU7WUFDckUsTUFBTSxJQUFJLEVBQUUsQ0FBQztTQUNoQjtRQUVELE9BQU8sTUFBTSxDQUFDO0lBQ2xCLENBQUM7SUE5SlEsZ0JBQWdCO1FBRDVCLFVBQVUsRUFBRTtPQUNBLGdCQUFnQixDQWlLNUI7SUFBRCx1QkFBQztDQUFBLEFBaktELENBQXNDLGNBQWMsR0FpS25EO1NBaktZLGdCQUFnQiIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IEluamVjdGFibGUgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcclxuaW1wb3J0IHtcclxuICAgIEdyaWRPcHRpb25zLFxyXG4gICAgQ29sRGVmLFxyXG4gICAgQ29sdW1uLFxyXG4gICAgUm93Tm9kZSxcclxuICAgIEdyaWRBcGlcclxufSBmcm9tICdhZy1ncmlkLWNvbW11bml0eSc7XHJcbmltcG9ydCB7XHJcbiAgICBJVGFibGVDb2x1bW4sXHJcbiAgICBJVGFibGVDb25maWdcclxufSBmcm9tICcuLi9rZC1hbmd1bGFyLXRhYmxlLWludGVyZmFjZSc7XHJcbmltcG9ydCB7IEtkVGFibGVTdmNCYXNlIH0gZnJvbSAnLi9rZC10YWJsZS1zdmMnO1xyXG5cclxuLyoqXHJcbiAqIC0tIERvY3VtZW50YXRpb24gZm9yIGtkLXRhYmxlLW5vcm1hbC1zdmMudHMgLS1cclxuICpcclxuICogUHVibGljIGZ1bmN0aW9uOlxyXG4gKiAgICAgLSBHcmlkIE9wdGlvbnMgZnVuY3Rpb25cclxuICogICAgICAgICAtIGdlbmVyYXRlR3JpZE9wdGlvbnMgKEdyaWRPcHRpb24gZ2VuZXJhdGlvbiB3aXRoIGdyaWRDb25maWcpXHJcbiAqICAgICAgICAgLSBzZXRHcmlkT3B0aW9uc1xyXG4gKiAgICAgLSBDb2x1bW4gZGVmaW5pdGlvbiBmdW5jdGlvbnNcclxuICogICAgICAgICAtIHNldENvbHVtbkRlZiAoQ29sdW1uIERlZmluaXRpb25zIGJhc2VkIG9uIGNvbHVtbkNvbmZpZyBhbmQgZ3JpZENvbmZpZylcclxuICogICAgICAgICAtIGdlbmVyYXRlQ29sdW1uRGVmaW5pdGlvbnNcclxuICogICAgIC0gUm93IGRhdGEgZnVuY3Rpb25zXHJcbiAqICAgICAgICAgLSBzZXRSb3dEYXRhIChTZXQgdGhlIHJvd0RhdGEgdG8gdGhlIGdyaWQpXHJcbiAqXHJcbiAqIFByaXZhdGUgZnVuY3Rpb25zOlxyXG4gKiAgICAgLSBHcmlkIE9wdGlvbnMgZnVuY3Rpb25cclxuICogICAgICAgICAtIF9nZW5lcmF0ZUNvbmZpZ09wdGlvbnMgKGFkZGl0aW9uYWwgR3JpZE9wdGlvbiBmcm9tIHRhYmxlIGNvbmZpZylcclxuICogICAgIC0gUm93IGhlaWdodCBmdW5jdGlvbnNcclxuICogICAgICAgICAtIF9nZXRSb3dIZWlnaHRcclxuICogICAgICAgICAtIF9jYWxjdWxhdGVSb3dIZWlnaHRcclxuICogICAgICAgICAtIF9nZXRRdWVzdGlvbkhlaWdodFxyXG4gKi9cclxuXHJcbkBJbmplY3RhYmxlKClcclxuZXhwb3J0IGNsYXNzIEtkVGFibGVOb3JtYWxTdmMgZXh0ZW5kcyBLZFRhYmxlU3ZjQmFzZSB7XHJcbiAgICBwcml2YXRlIF9tb3ZhYmxlQ29sdW1uOiBib29sZWFuID0gZmFsc2U7XHJcbiAgICAvKioqKioqKioqKioqKioqKioqKioqKioqKioqKiogUHVibGljIGZ1bmN0aW9ucyAqKioqKioqKioqKioqKioqKioqKioqKioqKioqKiovXHJcbiAgICAvLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vL1xyXG4gICAgLy8vIEdyaWQgb3B0aW9ucyBmdW5jdGlvbnNcclxuICAgIC8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vXHJcbiAgICBwdWJsaWMgZ2VuZXJhdGVHcmlkT3B0aW9ucyhfZ3JpZENvbmZpZzogSVRhYmxlQ29uZmlnLCBfZGlyZWN0aW9uOiAnbHRyJyB8ICdydGwnKTogR3JpZE9wdGlvbnMge1xyXG4gICAgICAgIGxldCB0ZW1wR3JpZE9wdGlvbnM6IEdyaWRPcHRpb25zID0gc3VwZXIuZ2V0RGVmYXVsdEdyaWRPcHRpb25zKF9kaXJlY3Rpb24sIF9ncmlkQ29uZmlnLnJvd0NvbnRlbnRIZWlnaHQpO1xyXG5cclxuICAgICAgICBkZWxldGUgdGVtcEdyaWRPcHRpb25zLnJvd0hlaWdodDtcclxuICAgICAgICBsZXQgY29uZmlnT3B0aW9uczogR3JpZE9wdGlvbnMgPSB0aGlzLl9nZW5lcmF0ZUNvbmZpZ09wdGlvbnMoX2dyaWRDb25maWcpO1xyXG5cclxuICAgICAgICAoPGFueT5PYmplY3QpLmFzc2lnbih0ZW1wR3JpZE9wdGlvbnMsIGNvbmZpZ09wdGlvbnMpO1xyXG5cclxuICAgICAgICByZXR1cm4gdGVtcEdyaWRPcHRpb25zO1xyXG4gICAgfVxyXG5cclxuICAgIHB1YmxpYyBzZXRHcmlkT3B0aW9ucyhfZ3JpZE9wdGlvbnM6IEdyaWRPcHRpb25zKTogdm9pZCB7XHJcbiAgICAgICAgdGhpcy5ncmlkT3B0aW9ucyA9IF9ncmlkT3B0aW9ucztcclxuICAgIH1cclxuXHJcbiAgICAvLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vL1xyXG4gICAgLy8vIENvbHVtbiBkZWZpbml0aW9uIGZ1bmN0aW9uc1xyXG4gICAgLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy9cclxuICAgIHB1YmxpYyBzZXRDb2x1bW5EZWYoX2NvbERlZkNvbmZpZzogQXJyYXk8SVRhYmxlQ29sdW1uPiwgX2dyaWRDb25maWc6IElUYWJsZUNvbmZpZywgX3N1cHByZXNzTW92YWJsZUNvbHVtbnM6IGJvb2xlYW4gPSB0cnVlKTogdm9pZCB7XHJcbiAgICAgICAgbGV0IHVwZGF0ZWRDb2x1bW46IEFycmF5PENvbERlZj4gPSB0aGlzLmdlbmVyYXRlQ29sdW1uRGVmaW5pdGlvbnMoX2NvbERlZkNvbmZpZywgX2dyaWRDb25maWcsIF9zdXBwcmVzc01vdmFibGVDb2x1bW5zKTtcclxuXHJcbiAgICAgICAgdGhpcy5ncmlkT3B0aW9ucy5jb2x1bW5EZWZzID0gdXBkYXRlZENvbHVtbjtcclxuXHJcbiAgICAgICAgaWYgKHN1cGVyLmlzQXBpUmVhZHkodGhpcy5ncmlkT3B0aW9ucykpIHtcclxuICAgICAgICAgICAgdGhpcy5ncmlkT3B0aW9ucy5hcGkuc2V0Q29sdW1uRGVmcyh1cGRhdGVkQ29sdW1uKTtcclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgcHVibGljIGdlbmVyYXRlQ29sdW1uRGVmaW5pdGlvbnMoX2NvbERlZkNvbmZpZzogQXJyYXk8SVRhYmxlQ29sdW1uPiwgX2dyaWRDb25maWc6IElUYWJsZUNvbmZpZywgX3N1cHByZXNzTW92YWJsZUNvbHVtbnM6IGJvb2xlYW4gPSB0cnVlKTogQXJyYXk8Q29sRGVmPiB7XHJcbiAgICAgICAgcmV0dXJuIHN1cGVyLmdlbmVyYXRlQ29sdW1uRGVmaW5pdGlvbnMoX2NvbERlZkNvbmZpZywgX2dyaWRDb25maWcsIF9zdXBwcmVzc01vdmFibGVDb2x1bW5zKTtcclxuICAgIH1cclxuXHJcbiAgICAvLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vL1xyXG4gICAgLy8vIFJvdyBEYXRhIGZ1bmN0aW9uc1xyXG4gICAgLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy9cclxuICAgIHB1YmxpYyBzZXRSb3dEYXRhKF9yb3dEYXRhOiBBcnJheTxhbnk+KTogdm9pZCB7XHJcbiAgICAgICAgdGhpcy5ncmlkT3B0aW9ucy5yb3dEYXRhID0gX3Jvd0RhdGE7XHJcbiAgICAgICAgaWYgKHN1cGVyLmlzQXBpUmVhZHkodGhpcy5ncmlkT3B0aW9ucykpIHtcclxuICAgICAgICAgICAgdGhpcy5ncmlkT3B0aW9ucy5hcGkuc2V0Um93RGF0YShfcm93RGF0YSk7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIC8qKioqKioqKioqKiogRW5kIG9mIHB1YmxpYyBmdW5jdGlvbnMgLyBTdGFydCBvZiBwcml2YXRlIGZ1bmN0aW9ucyAqKioqKioqKioqKi9cclxuICAgIC8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vXHJcbiAgICAvLy8gR3JpZCBvcHRpb25zIGZ1bmN0aW9uc1xyXG4gICAgLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy9cclxuICAgIHByaXZhdGUgX2dlbmVyYXRlQ29uZmlnT3B0aW9ucyhfY29uZmlnOiBJVGFibGVDb25maWcpOiBHcmlkT3B0aW9ucyB7XHJcbiAgICAgICAgbGV0IHNpZGViYXJWYWx1ZSA9IGZhbHNlO1xyXG4gICAgICAgIGlmKCdwaXZvdCcgaW4gX2NvbmZpZykge1xyXG4gICAgICAgICAgICBzaWRlYmFyVmFsdWUgPSBfY29uZmlnLnBpdm90LnN0YXRlLnBpdm90TW9kZTtcclxuICAgICAgICB9XHJcbiAgICAgICAgbGV0IGNvbmZpZ09wdGlvbnM6IEdyaWRPcHRpb25zID0ge1xyXG4gICAgICAgICAgICByb3dNb2RlbFR5cGU6ICdjbGllbnRTaWRlJyxcclxuICAgICAgICAgICAgZW5hYmxlU29ydGluZzogdHJ1ZSxcclxuICAgICAgICAgICAgZW5hYmxlRmlsdGVyOiB0cnVlLFxyXG4gICAgICAgICAgICBnZXRSb3dIZWlnaHQ6IChfcGFyYW1zOiBhbnkpOiBudW1iZXIgPT4ge1xyXG4gICAgICAgICAgICAgICAgcmV0dXJuIHRoaXMuX2dldFJvd0hlaWdodChfcGFyYW1zKTtcclxuICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgc2lkZUJhciA6IHNpZGViYXJWYWx1ZVxyXG4gICAgICAgIH07XHJcblxyXG4gICAgICAgIGlmICh0eXBlb2YgX2NvbmZpZy5yb3dJZEtleSAhPT0gJ3VuZGVmaW5lZCcpIHtcclxuICAgICAgICAgICAgdGhpcy5yb3dLZXkgPSBfY29uZmlnLnJvd0lkS2V5O1xyXG5cclxuICAgICAgICAgICAgY29uZmlnT3B0aW9ucy5nZXRSb3dOb2RlSWQgPSAoX2RhdGE6IGFueSk6IHN0cmluZyA9PiB7XHJcbiAgICAgICAgICAgICAgICBpZiAoX2RhdGEuaGFzT3duUHJvcGVydHkoX2NvbmZpZy5yb3dJZEtleSkpIHtcclxuICAgICAgICAgICAgICAgICAgICBsZXQgaWQ6IHN0cmluZyA9IF9kYXRhW19jb25maWcucm93SWRLZXldO1xyXG5cclxuICAgICAgICAgICAgICAgICAgICBpZiAodHlwZW9mIF9kYXRhW19jb25maWcucm93SWRLZXldID09PSAnbnVtYmVyJykge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBpZCA9IGlkLnRvU3RyaW5nKCk7XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgICAgICAgICByZXR1cm4gaWQ7XHJcbiAgICAgICAgICAgICAgICB9ZWxzZSBpZihfZGF0YS5oYXNPd25Qcm9wZXJ0eSgnZGF0YScpKXtcclxuICAgICAgICAgICAgICAgICAgICBsZXQgaWQ6IHN0cmluZyA9IF9kYXRhLmRhdGFbX2NvbmZpZy5yb3dJZEtleV07XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIGlmICh0eXBlb2YgX2RhdGEuZGF0YVtfY29uZmlnLnJvd0lkS2V5XSA9PT0gJ251bWJlcicpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgaWQgPSBpZC50b1N0cmluZygpO1xyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIGlkO1xyXG4gICAgICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgICAgIHJldHVybiAnJztcclxuICAgICAgICAgICAgfTtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIHJldHVybiBjb25maWdPcHRpb25zO1xyXG4gICAgfVxyXG5cclxuICAgIC8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vXHJcbiAgICAvLy8gUm93IEhlaWdodCBmdW5jdGlvbnNcclxuICAgIC8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vXHJcbiAgICBwcml2YXRlIF9nZXRSb3dIZWlnaHQoX3BhcmFtczoge25vZGU6IFJvd05vZGUsIGRhdGE6IGFueSwgYXBpOiBHcmlkQXBpLCBjb250ZXh0OiBhbnl9KTogbnVtYmVyIHtcclxuICAgICAgICBsZXQgbWF4SGVpZ2h0OiBudW1iZXIgPSB0aGlzLlJPV19IRUlHSFQ7XHJcbiAgICAgICAgbGV0IGFsbENvbHVtbnM6IEFycmF5PENvbHVtbj4gPSAoPGFueT5fcGFyYW1zLm5vZGUpLmNvbHVtbkFwaS5nZXRBbGxDb2x1bW5zKCk7XHJcbiAgICAgICAgbGV0IGNvbHVtbkhlaWdodDogbnVtYmVyID0gMDtcclxuXHJcbiAgICAgICAgZm9yIChsZXQgaTogbnVtYmVyID0gMDsgaSA8IGFsbENvbHVtbnMubGVuZ3RoOyArK2kpIHtcclxuICAgICAgICAgICAgY29sdW1uSGVpZ2h0ID0gdGhpcy5ST1dfSEVJR0hUO1xyXG5cclxuICAgICAgICAgICAgaWYgKHN1cGVyLmlzQ29sRGVmT2ZUeXBlKGFsbENvbHVtbnNbaV0uZ2V0Q29sRGVmKCksIHRoaXMuR0lSRF9QQVJBTVNfS0VZLmlucHV0KSkge1xyXG4gICAgICAgICAgICAgICAgbGV0IGNvbnRleHRLZXk6IHN0cmluZyA9IHN1cGVyLmdlbmVyYXRlQ29udGV4dEtleShfcGFyYW1zLmNvbnRleHQuZ3JpZElkLCBhbGxDb2x1bW5zW2ldLmdldENvbERlZigpLmNvbElkLCBfcGFyYW1zLm5vZGUuaWQpO1xyXG5cclxuICAgICAgICAgICAgICAgIGlmIChfcGFyYW1zLmNvbnRleHRbdGhpcy5UQUJMRV9JTlBVVF9DT05URVhUX0tFWV0uaGFzT3duUHJvcGVydHkoY29udGV4dEtleSkpIHtcclxuICAgICAgICAgICAgICAgICAgICBjb2x1bW5IZWlnaHQgPSB0aGlzLl9jYWxjdWxhdGVSb3dIZWlnaHQoX3BhcmFtcy5jb250ZXh0W3RoaXMuVEFCTEVfSU5QVVRfQ09OVEVYVF9LRVldW2NvbnRleHRLZXldKTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgaWYgKHN1cGVyLmlzQ29sRGVmT2ZUeXBlKGFsbENvbHVtbnNbaV0uZ2V0Q29sRGVmKCksIHRoaXMuR0lSRF9QQVJBTVNfS0VZLmltYWdlKSkge1xyXG4gICAgICAgICAgICAgICAgY29uc3QgZGVmYXVsdENvbEhlaWdodDogbnVtYmVyID0gMTUwO1xyXG5cclxuICAgICAgICAgICAgICAgIGlmICh0eXBlb2YgYWxsQ29sdW1uc1tpXS5nZXRDb2xEZWYoKS5jZWxsUmVuZGVyZXJQYXJhbXMucGFyYW1zLmltYWdlQ29uZmlnLmhlaWdodCAhPT0gJ3VuZGVmaW5lZCcpIHtcclxuICAgICAgICAgICAgICAgICAgICBjb2x1bW5IZWlnaHQgPSBhbGxDb2x1bW5zW2ldLmdldENvbERlZigpLmNlbGxSZW5kZXJlclBhcmFtcy5wYXJhbXMuaW1hZ2VDb25maWcuaGVpZ2h0ICsgdGhpcy5JTUFHRV9QQURESU5HO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgZWxzZSB7XHJcbiAgICAgICAgICAgICAgICAgICAgY29sdW1uSGVpZ2h0ID0gZGVmYXVsdENvbEhlaWdodCArIHRoaXMuSU1BR0VfUEFERElORztcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgaWYgKGNvbHVtbkhlaWdodCA+IG1heEhlaWdodCkge1xyXG4gICAgICAgICAgICAgICAgbWF4SGVpZ2h0ID0gY29sdW1uSGVpZ2h0O1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICByZXR1cm4gbWF4SGVpZ2h0O1xyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX2NhbGN1bGF0ZVJvd0hlaWdodChfY29udGV4dERhdGE6IGFueSk6IG51bWJlciB7XHJcbiAgICAgICAgbGV0IGhlaWdodDogbnVtYmVyID0gMDtcclxuXHJcbiAgICAgICAgZm9yIChsZXQgaXRlbSBpbiBfY29udGV4dERhdGEpIHtcclxuICAgICAgICAgICAgaWYgKF9jb250ZXh0RGF0YS5oYXNPd25Qcm9wZXJ0eShpdGVtKSkge1xyXG4gICAgICAgICAgICAgICAgaGVpZ2h0ICs9IHRoaXMuX2dldFF1ZXN0aW9uSGVpZ2h0KF9jb250ZXh0RGF0YVtpdGVtXSk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIHJldHVybiBoZWlnaHQ7XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfZ2V0UXVlc3Rpb25IZWlnaHQoX3RhYmxlRGF0YUl0ZW06IGFueSk6IG51bWJlciB7XHJcbiAgICAgICAgbGV0IGhlaWdodDogbnVtYmVyID0gMDtcclxuXHJcbiAgICAgICAgaWYgKF90YWJsZURhdGFJdGVtLnZpc2libGUpIHtcclxuICAgICAgICAgICAgaGVpZ2h0ICs9IDUwO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgaWYgKF90YWJsZURhdGFJdGVtLnZpc2libGUgJiYgX3RhYmxlRGF0YUl0ZW0uY29udHJvbFR5cGUgPT09ICd0ZXh0YXJlYScpIHtcclxuICAgICAgICAgICAgaGVpZ2h0ICs9IDcwO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgcmV0dXJuIGhlaWdodDtcclxuICAgIH1cclxuXHJcbiAgICAvKioqKioqKioqKioqKioqKioqKioqKioqKiBFbmQgb2YgcHJpdmF0ZSBmdW5jdGlvbnMgKioqKioqKioqKioqKioqKioqKioqKioqKiovXHJcbn1cclxuIl19