import { __decorate, __extends } from "tslib";
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { KdTableSvcBase } from './kd-table-svc';
/**
 * -- Documentation for kd-table-enterprise-svc.ts --
 *
 * Public function:
 *     - Grid Options function
 *         - generateGridOptions (GridOption generation with gridConfig)
 *         - setGridOptions
 *     - Column definition functions
 *         - setColumnDef (Column Definitions based on columnConfig and gridConfig)
 *         - generateColumnDefinitions
 *     - Row data functions
 *         - setRowData (Set the rowData to the grid)
 *     - Datasource function
 *         - generateDatasourceRows (manual sorting / filtering of the datasource - For oneshot and infinite loadType)
 *
 * Public functions (from parent) - Overrides:
 *     - updateSelectionValues
 *
 * Private functions:
 *     - Grid Options function
 *         - _generateConfigOptions (additional GridOption from table config)
 *     - Column definition functions
 *         - _checkCheckboxSelectionType (Checking for selection type all - Infinite loadType not able to load)
 *         - _updateColDefConfig  (NOTE: Removing input columns here)
 *         - _checkColDefFilterableVal
 *     - Datasource function
 *         - _datasourceSortRow
 *         - _datasourceRowSortFormula
 *         - _datasourceFilterRow
 *     - Misc functions
 *         - _retrievePagesize
 */
var KdTableEnterpriseSvc = /** @class */ (function (_super) {
    __extends(KdTableEnterpriseSvc, _super);
    function KdTableEnterpriseSvc() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    /***************************** Public functions ******************************/
    ////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// Grid options functions
    ////////////////////////////////////////////////////////////////////////////////////////////////////////
    KdTableEnterpriseSvc.prototype.generateGridOptions = function (_gridConfig, _direction) {
        var tempGridOptions = _super.prototype.getDefaultGridOptions.call(this, _direction, _gridConfig.rowContentHeight);
        var configOptions = this._generateConfigOptions(_gridConfig);
        Object.assign(tempGridOptions, configOptions);
        return tempGridOptions;
    };
    KdTableEnterpriseSvc.prototype.setGridOptions = function (_gridOptions) {
        this.gridOptions = _gridOptions;
    };
    ////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// Column definitions functions
    ////////////////////////////////////////////////////////////////////////////////////////////////////////
    KdTableEnterpriseSvc.prototype.setColumnDef = function (_colDefConfig, _gridConfig, _suppressMovableColumns) {
        if (_suppressMovableColumns === void 0) { _suppressMovableColumns = true; }
        var updatedColumn = this.generateColumnDefinitions(_colDefConfig, _gridConfig, _suppressMovableColumns);
        this.gridOptions.columnDefs = updatedColumn;
        if (_super.prototype.isApiReady.call(this, this.gridOptions)) {
            this.gridOptions.api.setColumnDefs(updatedColumn);
        }
        // if (super.hasInputType(_colDefConfig, 'image')) {
        //     this._updateRowHeightForImg(_colDefConfig);
        // }
    };
    KdTableEnterpriseSvc.prototype.generateColumnDefinitions = function (_colDefConfig, _gridConfig, _suppressMovableColumns) {
        if (_suppressMovableColumns === void 0) { _suppressMovableColumns = true; }
        var updatedColDefConfig = this._updateColDefConfig(_colDefConfig);
        var generatedColDef = _super.prototype.generateColumnDefinitions.call(this, updatedColDefConfig, _gridConfig, _suppressMovableColumns);
        this._checkCheckboxSelectionType(_gridConfig, generatedColDef);
        return generatedColDef;
    };
    ////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// Row Data functions
    ////////////////////////////////////////////////////////////////////////////////////////////////////////
    KdTableEnterpriseSvc.prototype.setRowData = function (_rowData) {
        this.gridOptions.rowData = _rowData;
    };
    ////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// Datasource functions
    ////////////////////////////////////////////////////////////////////////////////////////////////////////
    KdTableEnterpriseSvc.prototype.generateDatasourceRows = function (_datasourceRequest, _rowData) {
        var _this = this;
        return new Observable(function (_observer) {
            // console.log('-- Grid state: generate Datasource rows --', _datasourceRequest);
            var tempRowModel = _this._datasourceFilterRow(_datasourceRequest.filterModel, _rowData);
            _this._datasourceSortRow(_datasourceRequest.sortModel, tempRowModel);
            var requestObj = {
                rows: tempRowModel.slice(_datasourceRequest.startRow, _datasourceRequest.endRow),
                total: tempRowModel.length
            };
            _observer.next(requestObj);
            _observer.complete();
        });
    };
    /************************ Public functions from parent ***********************/
    ////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// Overrides
    ////////////////////////////////////////////////////////////////////////////////////////////////////////
    KdTableEnterpriseSvc.prototype.updateSelectionValues = function (_rowData, _selectedId, _returnKey, _loadType) {
        if (_loadType === 'server' && typeof _returnKey !== 'undefined' && _returnKey.length > 0) {
            console.warn('KdTable warning: Selection value not able to return as objects specify in the returnKey property as there might have unknown data values for server loadType.');
            return _selectedId;
        }
        return _super.prototype.updateSelectionValues.call(this, _rowData, _selectedId, _returnKey);
    };
    /************ End of public functions / Start of private functions ***********/
    ////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// Grid options functions
    ////////////////////////////////////////////////////////////////////////////////////////////////////////
    KdTableEnterpriseSvc.prototype._generateConfigOptions = function (_config) {
        var pagesize = this._retrievePagesize(_config.paginationConfig);
        var configOptions = {
            rowModelType: 'enterprise',
            enableServerSideFilter: true,
            enableServerSideSorting: true,
            maxConcurrentDatasourceRequests: 2,
            cacheOverflowSize: 1,
            rowGroupPanelShow: 'never',
            toolPanelSuppressPivotMode: true,
            toolPanelSuppressValues: true,
            cacheBlockSize: pagesize
        };
        if (typeof _config.rowIdKey !== 'undefined') {
            this.rowKey = _config.rowIdKey;
            configOptions.getRowNodeId = function (_data) {
                if (_data.hasOwnProperty(_config.rowIdKey)) {
                    var id = _data[_config.rowIdKey];
                    if (typeof _data[_config.rowIdKey] === 'number') {
                        id = id.toString();
                    }
                    return id;
                }
                return '';
            };
        }
        if (typeof _config !== 'undefined' && typeof _config.loadType !== 'undefined') {
            if (_config.loadType !== 'infinite') {
                configOptions.pagination = true;
                configOptions.maxBlocksInCache = 0;
                configOptions.paginationPageSize = pagesize;
            }
            else {
                // Auto height takes a lot of height, will cause infinite retrieving issue
                configOptions.maxBlocksInCache = 5;
            }
            if (_config.loadType == 'normal') {
                configOptions.sideBar = true;
            }
            else {
                configOptions.sideBar = false;
            }
        }
        return configOptions;
    };
    ////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// Column definitions functions
    ////////////////////////////////////////////////////////////////////////////////////////////////////////
    KdTableEnterpriseSvc.prototype._checkCheckboxSelectionType = function (_gridConfig, _colDefs) {
        if (typeof _gridConfig.selection !== 'undefined' &&
            typeof _gridConfig.selection.type !== 'undefined' &&
            typeof _gridConfig.loadType !== 'undefined' &&
            _gridConfig.selection.type === 'all' &&
            _gridConfig.loadType === 'infinite') {
            console.warn('KdTable warning: Infinite loadType not able to support all selectionType.');
            delete _colDefs[0].headerComponentFramework;
        }
    };
    KdTableEnterpriseSvc.prototype._updateColDefConfig = function (_colDefConfig) {
        var updatedColDefConfig = [];
        for (var i = 0; i < _colDefConfig.length; i++) {
            if (_super.prototype.isInputType.call(this, _colDefConfig[i], 'input')) {
                console.error('KdTable error: input column type is only valid for normal loadType table. Removing columns with input type.');
            }
            else {
                this._checkColDefFilterableVal(_colDefConfig[i]);
                updatedColDefConfig.push(_colDefConfig[i]);
            }
        }
        return updatedColDefConfig;
    };
    KdTableEnterpriseSvc.prototype._checkColDefFilterableVal = function (_colDefItem) {
        if (typeof _colDefItem.filterable !== 'undefined' && _colDefItem.filterable &&
            (typeof _colDefItem.filterValue === 'undefined' || _colDefItem.filterValue === null || _colDefItem.filterValue.length === 0)) {
            console.error('KdTable error: Filter value for ' + _colDefItem.field + ' field is empty. Using filter for loadType oneshot/infinite/server requires to provide filterValue. Suppressing filtering menu.');
            _colDefItem.filterable = false;
        }
    };
    // private _updateRowHeightForImg(_colDefConfig: Array<ITableColumn>): void {
    //     let maxHeight: number = 50;
    //     for (let i: number = 0; i < _colDefConfig.length; ++i) {
    //         if (super.isInputType(_colDefConfig[i], 'image')) {
    //             let tempHeight: number = super.getImageSizeBy(_colDefConfig[i], 'height');
    //             if (tempHeight > maxHeight) {
    //                 maxHeight = tempHeight;
    //             }
    //         }
    //     }
    //     console.log('row height max: ', maxHeight);
    //     this.gridOptions.rowHeight = maxHeight;
    // }
    ////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// Datasource sort / filter functions
    ////////////////////////////////////////////////////////////////////////////////////////////////////////
    KdTableEnterpriseSvc.prototype._datasourceSortRow = function (_sortModel, _rowData) {
        var _this = this;
        if (_sortModel.length > 0) {
            var sortOptions_1 = _sortModel[0];
            var returnCondition_1 = (sortOptions_1.sort === 'asc') ? 1 : -1;
            _rowData.sort(function (_a, _b) {
                return _this._datasourceRowSortFormula(_a, _b, sortOptions_1.colId, returnCondition_1);
            });
        }
    };
    KdTableEnterpriseSvc.prototype._datasourceRowSortFormula = function (_a, _b, _dotDisplayFrom, _returnVal) {
        if (typeof _a !== 'undefined' && typeof _b !== 'undefined') {
            var aVal = this.dataSvc.getDataValue(_a, _dotDisplayFrom);
            var bVal = this.dataSvc.getDataValue(_b, _dotDisplayFrom);
            if (aVal > bVal)
                return _returnVal;
            else if (aVal < bVal)
                return -(_returnVal);
            return 0;
        }
        return 0;
    };
    KdTableEnterpriseSvc.prototype._datasourceFilterRow = function (_filterModel, _rowData) {
        var tempRowModel = [];
        if (Object.keys(_filterModel).length > 0) {
            for (var item in _filterModel) {
                if (_filterModel.hasOwnProperty(item)) {
                    var dataKey = item;
                    var filterModelItem = _filterModel[item].values;
                    if (filterModelItem.length > 0) {
                        for (var i = 0; i < _rowData.length; i++) {
                            var rowItem = _rowData[i];
                            if (rowItem.hasOwnProperty(dataKey) && filterModelItem.indexOf(rowItem[dataKey]) > -1) {
                                tempRowModel.push(rowItem);
                            }
                        }
                    }
                    else {
                        tempRowModel = [];
                        break;
                    }
                }
            }
        }
        else {
            tempRowModel = _rowData.slice();
        }
        return tempRowModel;
    };
    ////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// Misc functions
    ////////////////////////////////////////////////////////////////////////////////////////////////////////
    KdTableEnterpriseSvc.prototype._retrievePagesize = function (_paginationConfig) {
        if (typeof _paginationConfig !== 'undefined' &&
            typeof _paginationConfig.pagesize !== 'undefined') {
            return _paginationConfig.pagesize;
        }
        _paginationConfig.pagesize = this.DEFAULT_PAGESIZE;
        return this.DEFAULT_PAGESIZE;
    };
    KdTableEnterpriseSvc = __decorate([
        Injectable()
    ], KdTableEnterpriseSvc);
    return KdTableEnterpriseSvc;
}(KdTableSvcBase));
export { KdTableEnterpriseSvc };
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoia2QtdGFibGUtZW50ZXJwcmlzZS1zdmMuanMiLCJzb3VyY2VSb290Ijoibmc6Ly9vcGVuZW1pcy1zdHlsZWd1aWRlLWxpYi8iLCJzb3VyY2VzIjpbImtkLWNvbXBvbmVudHMva2QtYW5ndWxhci10YWJsZS90YWJsZS1zZXJ2aWNlcy9rZC10YWJsZS1lbnRlcnByaXNlLXN2Yy50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiO0FBQUEsT0FBTyxFQUFFLFVBQVUsRUFBRSxNQUFNLGVBQWUsQ0FBQztBQUMzQyxPQUFPLEVBQUUsVUFBVSxFQUFnQixNQUFNLE1BQU0sQ0FBQztBQWNoRCxPQUFPLEVBQUUsY0FBYyxFQUFFLE1BQU0sZ0JBQWdCLENBQUM7QUFFaEQ7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7R0ErQkc7QUFHSDtJQUEwQyx3Q0FBYztJQUF4RDs7SUEyUUEsQ0FBQztJQTFRRywrRUFBK0U7SUFDL0Usd0dBQXdHO0lBQ3hHLDBCQUEwQjtJQUMxQix3R0FBd0c7SUFDakcsa0RBQW1CLEdBQTFCLFVBQTJCLFdBQXlCLEVBQUUsVUFBeUI7UUFDM0UsSUFBSSxlQUFlLEdBQWdCLGlCQUFNLHFCQUFxQixZQUFDLFVBQVUsRUFBRSxXQUFXLENBQUMsZ0JBQWdCLENBQUMsQ0FBQztRQUN6RyxJQUFJLGFBQWEsR0FBZ0IsSUFBSSxDQUFDLHNCQUFzQixDQUFDLFdBQVcsQ0FBQyxDQUFDO1FBRXBFLE1BQU8sQ0FBQyxNQUFNLENBQUMsZUFBZSxFQUFFLGFBQWEsQ0FBQyxDQUFDO1FBRXJELE9BQU8sZUFBZSxDQUFDO0lBQzNCLENBQUM7SUFFTSw2Q0FBYyxHQUFyQixVQUFzQixZQUF5QjtRQUMzQyxJQUFJLENBQUMsV0FBVyxHQUFHLFlBQVksQ0FBQztJQUNwQyxDQUFDO0lBRUQsd0dBQXdHO0lBQ3hHLGdDQUFnQztJQUNoQyx3R0FBd0c7SUFDakcsMkNBQVksR0FBbkIsVUFBb0IsYUFBa0MsRUFBRSxXQUF5QixFQUFFLHVCQUF1QztRQUF2Qyx3Q0FBQSxFQUFBLDhCQUF1QztRQUN0SCxJQUFJLGFBQWEsR0FBa0IsSUFBSSxDQUFDLHlCQUF5QixDQUFDLGFBQWEsRUFBRSxXQUFXLEVBQUUsdUJBQXVCLENBQUMsQ0FBQztRQUV2SCxJQUFJLENBQUMsV0FBVyxDQUFDLFVBQVUsR0FBRyxhQUFhLENBQUM7UUFDNUMsSUFBSSxpQkFBTSxVQUFVLFlBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxFQUFFO1lBQ3BDLElBQUksQ0FBQyxXQUFXLENBQUMsR0FBRyxDQUFDLGFBQWEsQ0FBQyxhQUFhLENBQUMsQ0FBQztTQUNyRDtRQUVELG9EQUFvRDtRQUNwRCxrREFBa0Q7UUFDbEQsSUFBSTtJQUNSLENBQUM7SUFFTSx3REFBeUIsR0FBaEMsVUFBaUMsYUFBa0MsRUFBRSxXQUF5QixFQUFFLHVCQUF1QztRQUF2Qyx3Q0FBQSxFQUFBLDhCQUF1QztRQUNuSSxJQUFJLG1CQUFtQixHQUF3QixJQUFJLENBQUMsbUJBQW1CLENBQUMsYUFBYSxDQUFDLENBQUM7UUFFdkYsSUFBSSxlQUFlLEdBQWtCLGlCQUFNLHlCQUF5QixZQUFDLG1CQUFtQixFQUFFLFdBQVcsRUFBRSx1QkFBdUIsQ0FBQyxDQUFDO1FBQ2hJLElBQUksQ0FBQywyQkFBMkIsQ0FBQyxXQUFXLEVBQUUsZUFBZSxDQUFDLENBQUM7UUFFL0QsT0FBUSxlQUFlLENBQUM7SUFDNUIsQ0FBQztJQUVELHdHQUF3RztJQUN4RyxzQkFBc0I7SUFDdEIsd0dBQXdHO0lBQ2pHLHlDQUFVLEdBQWpCLFVBQWtCLFFBQW9CO1FBQ2xDLElBQUksQ0FBQyxXQUFXLENBQUMsT0FBTyxHQUFHLFFBQVEsQ0FBQztJQUN4QyxDQUFDO0lBRUQsd0dBQXdHO0lBQ3hHLHdCQUF3QjtJQUN4Qix3R0FBd0c7SUFDakcscURBQXNCLEdBQTdCLFVBQThCLGtCQUE2QyxFQUFFLFFBQW9CO1FBQWpHLGlCQWVDO1FBZEcsT0FBTyxJQUFJLFVBQVUsQ0FBTSxVQUFDLFNBQTBCO1lBQ2xELGlGQUFpRjtZQUVqRixJQUFJLFlBQVksR0FBZSxLQUFJLENBQUMsb0JBQW9CLENBQUMsa0JBQWtCLENBQUMsV0FBVyxFQUFFLFFBQVEsQ0FBQyxDQUFDO1lBQ25HLEtBQUksQ0FBQyxrQkFBa0IsQ0FBQyxrQkFBa0IsQ0FBQyxTQUFTLEVBQUUsWUFBWSxDQUFDLENBQUM7WUFFcEUsSUFBSSxVQUFVLEdBQXNDO2dCQUNoRCxJQUFJLEVBQUUsWUFBWSxDQUFDLEtBQUssQ0FBQyxrQkFBa0IsQ0FBQyxRQUFRLEVBQUUsa0JBQWtCLENBQUMsTUFBTSxDQUFDO2dCQUNoRixLQUFLLEVBQUUsWUFBWSxDQUFDLE1BQU07YUFDN0IsQ0FBQztZQUVGLFNBQVMsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLENBQUM7WUFDM0IsU0FBUyxDQUFDLFFBQVEsRUFBRSxDQUFDO1FBQ3pCLENBQUMsQ0FBQyxDQUFDO0lBQ1AsQ0FBQztJQUVELCtFQUErRTtJQUMvRSx3R0FBd0c7SUFDeEcsYUFBYTtJQUNiLHdHQUF3RztJQUNqRyxvREFBcUIsR0FBNUIsVUFBNkIsUUFBb0IsRUFBRSxXQUFtQyxFQUFFLFVBQXlCLEVBQUUsU0FBaUI7UUFDaEksSUFBSSxTQUFTLEtBQUssUUFBUSxJQUFJLE9BQU8sVUFBVSxLQUFLLFdBQVcsSUFBSSxVQUFVLENBQUMsTUFBTSxHQUFHLENBQUMsRUFBRTtZQUN0RixPQUFPLENBQUMsSUFBSSxDQUFDLCtKQUErSixDQUFDLENBQUM7WUFDOUssT0FBTyxXQUFXLENBQUM7U0FDdEI7UUFDRCxPQUFPLGlCQUFNLHFCQUFxQixZQUFDLFFBQVEsRUFBRSxXQUFXLEVBQUUsVUFBVSxDQUFDLENBQUM7SUFDMUUsQ0FBQztJQUVELCtFQUErRTtJQUMvRSx3R0FBd0c7SUFDeEcsMEJBQTBCO0lBQzFCLHdHQUF3RztJQUNoRyxxREFBc0IsR0FBOUIsVUFBK0IsT0FBcUI7UUFDaEQsSUFBSSxRQUFRLEdBQVcsSUFBSSxDQUFDLGlCQUFpQixDQUFDLE9BQU8sQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDO1FBRXhFLElBQUksYUFBYSxHQUFnQjtZQUM3QixZQUFZLEVBQUUsWUFBWTtZQUMxQixzQkFBc0IsRUFBRSxJQUFJO1lBQzVCLHVCQUF1QixFQUFFLElBQUk7WUFFN0IsK0JBQStCLEVBQUUsQ0FBQztZQUNsQyxpQkFBaUIsRUFBRSxDQUFDO1lBRXBCLGlCQUFpQixFQUFFLE9BQU87WUFDMUIsMEJBQTBCLEVBQUUsSUFBSTtZQUNoQyx1QkFBdUIsRUFBRSxJQUFJO1lBRTdCLGNBQWMsRUFBRSxRQUFRO1NBQzNCLENBQUM7UUFFRixJQUFJLE9BQU8sT0FBTyxDQUFDLFFBQVEsS0FBSyxXQUFXLEVBQUU7WUFDekMsSUFBSSxDQUFDLE1BQU0sR0FBRyxPQUFPLENBQUMsUUFBUSxDQUFDO1lBRS9CLGFBQWEsQ0FBQyxZQUFZLEdBQUcsVUFBQyxLQUFVO2dCQUNwQyxJQUFJLEtBQUssQ0FBQyxjQUFjLENBQUMsT0FBTyxDQUFDLFFBQVEsQ0FBQyxFQUFFO29CQUN4QyxJQUFJLEVBQUUsR0FBVyxLQUFLLENBQUMsT0FBTyxDQUFDLFFBQVEsQ0FBQyxDQUFDO29CQUV6QyxJQUFJLE9BQU8sS0FBSyxDQUFDLE9BQU8sQ0FBQyxRQUFRLENBQUMsS0FBSyxRQUFRLEVBQUU7d0JBQzdDLEVBQUUsR0FBRyxFQUFFLENBQUMsUUFBUSxFQUFFLENBQUM7cUJBQ3RCO29CQUVELE9BQU8sRUFBRSxDQUFDO2lCQUNiO2dCQUVELE9BQU8sRUFBRSxDQUFDO1lBQ2QsQ0FBQyxDQUFDO1NBQ0w7UUFFRCxJQUFJLE9BQU8sT0FBTyxLQUFLLFdBQVcsSUFBSSxPQUFPLE9BQU8sQ0FBQyxRQUFRLEtBQUssV0FBVyxFQUFFO1lBQzNFLElBQUksT0FBTyxDQUFDLFFBQVEsS0FBSyxVQUFVLEVBQUU7Z0JBQ2pDLGFBQWEsQ0FBQyxVQUFVLEdBQUcsSUFBSSxDQUFDO2dCQUNoQyxhQUFhLENBQUMsZ0JBQWdCLEdBQUcsQ0FBQyxDQUFDO2dCQUVuQyxhQUFhLENBQUMsa0JBQWtCLEdBQUcsUUFBUSxDQUFDO2FBQy9DO2lCQUNJO2dCQUNELDBFQUEwRTtnQkFDMUUsYUFBYSxDQUFDLGdCQUFnQixHQUFHLENBQUMsQ0FBQzthQUN0QztZQUNELElBQUksT0FBTyxDQUFDLFFBQVEsSUFBSSxRQUFRLEVBQUU7Z0JBQzlCLGFBQWEsQ0FBQyxPQUFPLEdBQUksSUFBSSxDQUFDO2FBQ2pDO2lCQUFNO2dCQUNILGFBQWEsQ0FBQyxPQUFPLEdBQUksS0FBSyxDQUFDO2FBQ2xDO1NBQ0o7UUFFRCxPQUFPLGFBQWEsQ0FBQztJQUN6QixDQUFDO0lBRUQsd0dBQXdHO0lBQ3hHLGdDQUFnQztJQUNoQyx3R0FBd0c7SUFDaEcsMERBQTJCLEdBQW5DLFVBQW9DLFdBQXlCLEVBQUUsUUFBdUI7UUFDbEYsSUFBSSxPQUFPLFdBQVcsQ0FBQyxTQUFTLEtBQUssV0FBVztZQUM1QyxPQUFPLFdBQVcsQ0FBQyxTQUFTLENBQUMsSUFBSSxLQUFLLFdBQVc7WUFDakQsT0FBTyxXQUFXLENBQUMsUUFBUSxLQUFLLFdBQVc7WUFDM0MsV0FBVyxDQUFDLFNBQVMsQ0FBQyxJQUFJLEtBQUssS0FBSztZQUNwQyxXQUFXLENBQUMsUUFBUSxLQUFLLFVBQVUsRUFBRTtZQUNqQyxPQUFPLENBQUMsSUFBSSxDQUFDLDJFQUEyRSxDQUFDLENBQUM7WUFDMUYsT0FBTyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsd0JBQXdCLENBQUM7U0FDbkQ7SUFDTCxDQUFDO0lBRU8sa0RBQW1CLEdBQTNCLFVBQTRCLGFBQWtDO1FBQzFELElBQUksbUJBQW1CLEdBQXdCLEVBQUUsQ0FBQztRQUVsRCxLQUFLLElBQUksQ0FBQyxHQUFXLENBQUMsRUFBRSxDQUFDLEdBQUcsYUFBYSxDQUFDLE1BQU0sRUFBRSxDQUFDLEVBQUUsRUFBRTtZQUNuRCxJQUFJLGlCQUFNLFdBQVcsWUFBQyxhQUFhLENBQUMsQ0FBQyxDQUFDLEVBQUUsT0FBTyxDQUFDLEVBQUU7Z0JBQzlDLE9BQU8sQ0FBQyxLQUFLLENBQUMsNkdBQTZHLENBQUMsQ0FBQzthQUNoSTtpQkFDSTtnQkFDRCxJQUFJLENBQUMseUJBQXlCLENBQUMsYUFBYSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7Z0JBQ2pELG1CQUFtQixDQUFDLElBQUksQ0FBQyxhQUFhLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQzthQUM5QztTQUNKO1FBRUQsT0FBTyxtQkFBbUIsQ0FBQztJQUMvQixDQUFDO0lBRU8sd0RBQXlCLEdBQWpDLFVBQWtDLFdBQXlCO1FBQ3ZELElBQUksT0FBTyxXQUFXLENBQUMsVUFBVSxLQUFLLFdBQVcsSUFBSSxXQUFXLENBQUMsVUFBVTtZQUN2RSxDQUFDLE9BQU8sV0FBVyxDQUFDLFdBQVcsS0FBSyxXQUFXLElBQUksV0FBVyxDQUFDLFdBQVcsS0FBSyxJQUFJLElBQUksV0FBVyxDQUFDLFdBQVcsQ0FBQyxNQUFNLEtBQUssQ0FBQyxDQUFFLEVBQUU7WUFDM0gsT0FBTyxDQUFDLEtBQUssQ0FBQyxrQ0FBa0MsR0FBRyxXQUFXLENBQUMsS0FBSyxHQUFHLGlJQUFpSSxDQUFDLENBQUM7WUFDMU0sV0FBVyxDQUFDLFVBQVUsR0FBRyxLQUFLLENBQUM7U0FDdEM7SUFDTCxDQUFDO0lBRUQsNkVBQTZFO0lBQzdFLGtDQUFrQztJQUNsQywrREFBK0Q7SUFDL0QsOERBQThEO0lBQzlELHlGQUF5RjtJQUV6Riw0Q0FBNEM7SUFDNUMsMENBQTBDO0lBQzFDLGdCQUFnQjtJQUNoQixZQUFZO0lBQ1osUUFBUTtJQUNSLGtEQUFrRDtJQUNsRCw4Q0FBOEM7SUFDOUMsSUFBSTtJQUVKLHdHQUF3RztJQUN4RyxzQ0FBc0M7SUFDdEMsd0dBQXdHO0lBQ2hHLGlEQUFrQixHQUExQixVQUEyQixVQUF3RCxFQUFFLFFBQW9CO1FBQXpHLGlCQVNDO1FBUkcsSUFBSSxVQUFVLENBQUMsTUFBTSxHQUFHLENBQUMsRUFBRTtZQUN2QixJQUFJLGFBQVcsR0FBMEMsVUFBVSxDQUFDLENBQUMsQ0FBQyxDQUFDO1lBQ3ZFLElBQUksaUJBQWUsR0FBVyxDQUFDLGFBQVcsQ0FBQyxJQUFJLEtBQUssS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7WUFFcEUsUUFBUSxDQUFDLElBQUksQ0FBQyxVQUFDLEVBQU8sRUFBRSxFQUFPO2dCQUMzQixPQUFPLEtBQUksQ0FBQyx5QkFBeUIsQ0FBQyxFQUFFLEVBQUUsRUFBRSxFQUFFLGFBQVcsQ0FBQyxLQUFLLEVBQUUsaUJBQWUsQ0FBQyxDQUFDO1lBQ3RGLENBQUMsQ0FBQyxDQUFDO1NBQ047SUFDTCxDQUFDO0lBRU8sd0RBQXlCLEdBQWpDLFVBQWtDLEVBQU8sRUFBRSxFQUFPLEVBQUUsZUFBdUIsRUFBRSxVQUFrQjtRQUMzRixJQUFJLE9BQU8sRUFBRSxLQUFLLFdBQVcsSUFBSSxPQUFPLEVBQUUsS0FBSyxXQUFXLEVBQUU7WUFDeEQsSUFBSSxJQUFJLEdBQVEsSUFBSSxDQUFDLE9BQU8sQ0FBQyxZQUFZLENBQUMsRUFBRSxFQUFFLGVBQWUsQ0FBQyxDQUFDO1lBQy9ELElBQUksSUFBSSxHQUFRLElBQUksQ0FBQyxPQUFPLENBQUMsWUFBWSxDQUFDLEVBQUUsRUFBRSxlQUFlLENBQUMsQ0FBQztZQUUvRCxJQUFJLElBQUksR0FBRyxJQUFJO2dCQUFFLE9BQU8sVUFBVSxDQUFDO2lCQUM5QixJQUFJLElBQUksR0FBRyxJQUFJO2dCQUFFLE9BQU8sQ0FBQyxDQUFDLFVBQVUsQ0FBQyxDQUFDO1lBQzNDLE9BQU8sQ0FBQyxDQUFDO1NBQ1o7UUFDRCxPQUFPLENBQUMsQ0FBQztJQUNiLENBQUM7SUFFTyxtREFBb0IsR0FBNUIsVUFBNkIsWUFBaUIsRUFBRSxRQUFvQjtRQUNoRSxJQUFJLFlBQVksR0FBZSxFQUFFLENBQUM7UUFFbEMsSUFBSSxNQUFNLENBQUMsSUFBSSxDQUFDLFlBQVksQ0FBQyxDQUFDLE1BQU0sR0FBRyxDQUFDLEVBQUU7WUFDdEMsS0FBSyxJQUFJLElBQUksSUFBSSxZQUFZLEVBQUU7Z0JBQzNCLElBQUksWUFBWSxDQUFDLGNBQWMsQ0FBQyxJQUFJLENBQUMsRUFBRTtvQkFDbkMsSUFBSSxPQUFPLEdBQVcsSUFBSSxDQUFDO29CQUMzQixJQUFJLGVBQWUsR0FBMkIsWUFBWSxDQUFDLElBQUksQ0FBQyxDQUFDLE1BQU0sQ0FBQztvQkFFeEUsSUFBSSxlQUFlLENBQUMsTUFBTSxHQUFHLENBQUMsRUFBRTt3QkFDNUIsS0FBSyxJQUFJLENBQUMsR0FBVyxDQUFDLEVBQUUsQ0FBQyxHQUFHLFFBQVEsQ0FBQyxNQUFNLEVBQUUsQ0FBQyxFQUFFLEVBQUU7NEJBQzlDLElBQUksT0FBTyxHQUFRLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQzs0QkFFL0IsSUFBSSxPQUFPLENBQUMsY0FBYyxDQUFDLE9BQU8sQ0FBQyxJQUFJLGVBQWUsQ0FBQyxPQUFPLENBQUMsT0FBTyxDQUFDLE9BQU8sQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLEVBQUU7Z0NBQ25GLFlBQVksQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLENBQUM7NkJBQzlCO3lCQUNKO3FCQUNKO3lCQUNJO3dCQUNELFlBQVksR0FBRyxFQUFFLENBQUM7d0JBQ2xCLE1BQU07cUJBQ1Q7aUJBQ0o7YUFDSjtTQUNKO2FBQ0k7WUFDRCxZQUFZLEdBQUcsUUFBUSxDQUFDLEtBQUssRUFBRSxDQUFDO1NBQ25DO1FBRUQsT0FBTyxZQUFZLENBQUM7SUFDeEIsQ0FBQztJQUVELHdHQUF3RztJQUN4RyxrQkFBa0I7SUFDbEIsd0dBQXdHO0lBQ2hHLGdEQUFpQixHQUF6QixVQUEwQixpQkFBc0I7UUFDNUMsSUFBSSxPQUFPLGlCQUFpQixLQUFLLFdBQVc7WUFDeEMsT0FBTyxpQkFBaUIsQ0FBQyxRQUFRLEtBQUssV0FBVyxFQUFFO1lBQy9DLE9BQU8saUJBQWlCLENBQUMsUUFBUSxDQUFDO1NBQ3pDO1FBQ0QsaUJBQWlCLENBQUMsUUFBUSxHQUFHLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQztRQUNuRCxPQUFPLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQztJQUNqQyxDQUFDO0lBeFFRLG9CQUFvQjtRQURoQyxVQUFVLEVBQUU7T0FDQSxvQkFBb0IsQ0EyUWhDO0lBQUQsMkJBQUM7Q0FBQSxBQTNRRCxDQUEwQyxjQUFjLEdBMlF2RDtTQTNRWSxvQkFBb0IiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBJbmplY3RhYmxlIH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XHJcbmltcG9ydCB7IE9ic2VydmFibGUgLCAgU3Vic2NyaWJlciB9IGZyb20gJ3J4anMnO1xyXG5pbXBvcnQge1xyXG4gICAgR3JpZE9wdGlvbnMsXHJcbiAgICBDb2xEZWYsXHJcbiAgICAvLyBJRW50ZXJwcmlzZUdldFJvd3NSZXF1ZXN0XHJcbn0gZnJvbSAnYWctZ3JpZC1jb21tdW5pdHknO1xyXG5cclxuaW1wb3J0IHtcclxuICAgICBJRW50ZXJwcmlzZUdldFJvd3NSZXF1ZXN0XHJcbn0gZnJvbSAnLi4vZW50ZXJwcmlzZS1kYXRhc291cmNlJztcclxuaW1wb3J0IHtcclxuICAgIElUYWJsZUNvbHVtbixcclxuICAgIElUYWJsZUNvbmZpZ1xyXG59IGZyb20gJy4uL2tkLWFuZ3VsYXItdGFibGUtaW50ZXJmYWNlJztcclxuaW1wb3J0IHsgS2RUYWJsZVN2Y0Jhc2UgfSBmcm9tICcuL2tkLXRhYmxlLXN2Yyc7XHJcblxyXG4vKipcclxuICogLS0gRG9jdW1lbnRhdGlvbiBmb3Iga2QtdGFibGUtZW50ZXJwcmlzZS1zdmMudHMgLS1cclxuICpcclxuICogUHVibGljIGZ1bmN0aW9uOlxyXG4gKiAgICAgLSBHcmlkIE9wdGlvbnMgZnVuY3Rpb25cclxuICogICAgICAgICAtIGdlbmVyYXRlR3JpZE9wdGlvbnMgKEdyaWRPcHRpb24gZ2VuZXJhdGlvbiB3aXRoIGdyaWRDb25maWcpXHJcbiAqICAgICAgICAgLSBzZXRHcmlkT3B0aW9uc1xyXG4gKiAgICAgLSBDb2x1bW4gZGVmaW5pdGlvbiBmdW5jdGlvbnNcclxuICogICAgICAgICAtIHNldENvbHVtbkRlZiAoQ29sdW1uIERlZmluaXRpb25zIGJhc2VkIG9uIGNvbHVtbkNvbmZpZyBhbmQgZ3JpZENvbmZpZylcclxuICogICAgICAgICAtIGdlbmVyYXRlQ29sdW1uRGVmaW5pdGlvbnNcclxuICogICAgIC0gUm93IGRhdGEgZnVuY3Rpb25zXHJcbiAqICAgICAgICAgLSBzZXRSb3dEYXRhIChTZXQgdGhlIHJvd0RhdGEgdG8gdGhlIGdyaWQpXHJcbiAqICAgICAtIERhdGFzb3VyY2UgZnVuY3Rpb25cclxuICogICAgICAgICAtIGdlbmVyYXRlRGF0YXNvdXJjZVJvd3MgKG1hbnVhbCBzb3J0aW5nIC8gZmlsdGVyaW5nIG9mIHRoZSBkYXRhc291cmNlIC0gRm9yIG9uZXNob3QgYW5kIGluZmluaXRlIGxvYWRUeXBlKVxyXG4gKlxyXG4gKiBQdWJsaWMgZnVuY3Rpb25zIChmcm9tIHBhcmVudCkgLSBPdmVycmlkZXM6XHJcbiAqICAgICAtIHVwZGF0ZVNlbGVjdGlvblZhbHVlc1xyXG4gKlxyXG4gKiBQcml2YXRlIGZ1bmN0aW9uczpcclxuICogICAgIC0gR3JpZCBPcHRpb25zIGZ1bmN0aW9uXHJcbiAqICAgICAgICAgLSBfZ2VuZXJhdGVDb25maWdPcHRpb25zIChhZGRpdGlvbmFsIEdyaWRPcHRpb24gZnJvbSB0YWJsZSBjb25maWcpXHJcbiAqICAgICAtIENvbHVtbiBkZWZpbml0aW9uIGZ1bmN0aW9uc1xyXG4gKiAgICAgICAgIC0gX2NoZWNrQ2hlY2tib3hTZWxlY3Rpb25UeXBlIChDaGVja2luZyBmb3Igc2VsZWN0aW9uIHR5cGUgYWxsIC0gSW5maW5pdGUgbG9hZFR5cGUgbm90IGFibGUgdG8gbG9hZClcclxuICogICAgICAgICAtIF91cGRhdGVDb2xEZWZDb25maWcgIChOT1RFOiBSZW1vdmluZyBpbnB1dCBjb2x1bW5zIGhlcmUpXHJcbiAqICAgICAgICAgLSBfY2hlY2tDb2xEZWZGaWx0ZXJhYmxlVmFsXHJcbiAqICAgICAtIERhdGFzb3VyY2UgZnVuY3Rpb25cclxuICogICAgICAgICAtIF9kYXRhc291cmNlU29ydFJvd1xyXG4gKiAgICAgICAgIC0gX2RhdGFzb3VyY2VSb3dTb3J0Rm9ybXVsYVxyXG4gKiAgICAgICAgIC0gX2RhdGFzb3VyY2VGaWx0ZXJSb3dcclxuICogICAgIC0gTWlzYyBmdW5jdGlvbnNcclxuICogICAgICAgICAtIF9yZXRyaWV2ZVBhZ2VzaXplXHJcbiAqL1xyXG5cclxuQEluamVjdGFibGUoKVxyXG5leHBvcnQgY2xhc3MgS2RUYWJsZUVudGVycHJpc2VTdmMgZXh0ZW5kcyBLZFRhYmxlU3ZjQmFzZSB7XHJcbiAgICAvKioqKioqKioqKioqKioqKioqKioqKioqKioqKiogUHVibGljIGZ1bmN0aW9ucyAqKioqKioqKioqKioqKioqKioqKioqKioqKioqKiovXHJcbiAgICAvLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vL1xyXG4gICAgLy8vIEdyaWQgb3B0aW9ucyBmdW5jdGlvbnNcclxuICAgIC8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vXHJcbiAgICBwdWJsaWMgZ2VuZXJhdGVHcmlkT3B0aW9ucyhfZ3JpZENvbmZpZzogSVRhYmxlQ29uZmlnLCBfZGlyZWN0aW9uOiAnbHRyJyB8ICdydGwnKTogR3JpZE9wdGlvbnMge1xyXG4gICAgICAgIGxldCB0ZW1wR3JpZE9wdGlvbnM6IEdyaWRPcHRpb25zID0gc3VwZXIuZ2V0RGVmYXVsdEdyaWRPcHRpb25zKF9kaXJlY3Rpb24sIF9ncmlkQ29uZmlnLnJvd0NvbnRlbnRIZWlnaHQpO1xyXG4gICAgICAgIGxldCBjb25maWdPcHRpb25zOiBHcmlkT3B0aW9ucyA9IHRoaXMuX2dlbmVyYXRlQ29uZmlnT3B0aW9ucyhfZ3JpZENvbmZpZyk7XHJcblxyXG4gICAgICAgICg8YW55Pk9iamVjdCkuYXNzaWduKHRlbXBHcmlkT3B0aW9ucywgY29uZmlnT3B0aW9ucyk7XHJcblxyXG4gICAgICAgIHJldHVybiB0ZW1wR3JpZE9wdGlvbnM7XHJcbiAgICB9XHJcblxyXG4gICAgcHVibGljIHNldEdyaWRPcHRpb25zKF9ncmlkT3B0aW9uczogR3JpZE9wdGlvbnMpOiB2b2lkIHtcclxuICAgICAgICB0aGlzLmdyaWRPcHRpb25zID0gX2dyaWRPcHRpb25zO1xyXG4gICAgfVxyXG5cclxuICAgIC8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vXHJcbiAgICAvLy8gQ29sdW1uIGRlZmluaXRpb25zIGZ1bmN0aW9uc1xyXG4gICAgLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy9cclxuICAgIHB1YmxpYyBzZXRDb2x1bW5EZWYoX2NvbERlZkNvbmZpZzogQXJyYXk8SVRhYmxlQ29sdW1uPiwgX2dyaWRDb25maWc6IElUYWJsZUNvbmZpZywgX3N1cHByZXNzTW92YWJsZUNvbHVtbnM6IGJvb2xlYW4gPSB0cnVlKTogdm9pZCB7XHJcbiAgICAgICAgbGV0IHVwZGF0ZWRDb2x1bW46IEFycmF5PENvbERlZj4gPSB0aGlzLmdlbmVyYXRlQ29sdW1uRGVmaW5pdGlvbnMoX2NvbERlZkNvbmZpZywgX2dyaWRDb25maWcsIF9zdXBwcmVzc01vdmFibGVDb2x1bW5zKTtcclxuXHJcbiAgICAgICAgdGhpcy5ncmlkT3B0aW9ucy5jb2x1bW5EZWZzID0gdXBkYXRlZENvbHVtbjtcclxuICAgICAgICBpZiAoc3VwZXIuaXNBcGlSZWFkeSh0aGlzLmdyaWRPcHRpb25zKSkge1xyXG4gICAgICAgICAgICB0aGlzLmdyaWRPcHRpb25zLmFwaS5zZXRDb2x1bW5EZWZzKHVwZGF0ZWRDb2x1bW4pO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgLy8gaWYgKHN1cGVyLmhhc0lucHV0VHlwZShfY29sRGVmQ29uZmlnLCAnaW1hZ2UnKSkge1xyXG4gICAgICAgIC8vICAgICB0aGlzLl91cGRhdGVSb3dIZWlnaHRGb3JJbWcoX2NvbERlZkNvbmZpZyk7XHJcbiAgICAgICAgLy8gfVxyXG4gICAgfVxyXG5cclxuICAgIHB1YmxpYyBnZW5lcmF0ZUNvbHVtbkRlZmluaXRpb25zKF9jb2xEZWZDb25maWc6IEFycmF5PElUYWJsZUNvbHVtbj4sIF9ncmlkQ29uZmlnOiBJVGFibGVDb25maWcsIF9zdXBwcmVzc01vdmFibGVDb2x1bW5zOiBib29sZWFuID0gdHJ1ZSk6IEFycmF5PENvbERlZj4ge1xyXG4gICAgICAgIGxldCB1cGRhdGVkQ29sRGVmQ29uZmlnOiBBcnJheTxJVGFibGVDb2x1bW4+ID0gdGhpcy5fdXBkYXRlQ29sRGVmQ29uZmlnKF9jb2xEZWZDb25maWcpO1xyXG5cclxuICAgICAgICBsZXQgZ2VuZXJhdGVkQ29sRGVmOiBBcnJheTxDb2xEZWY+ID0gc3VwZXIuZ2VuZXJhdGVDb2x1bW5EZWZpbml0aW9ucyh1cGRhdGVkQ29sRGVmQ29uZmlnLCBfZ3JpZENvbmZpZywgX3N1cHByZXNzTW92YWJsZUNvbHVtbnMpO1xyXG4gICAgICAgIHRoaXMuX2NoZWNrQ2hlY2tib3hTZWxlY3Rpb25UeXBlKF9ncmlkQ29uZmlnLCBnZW5lcmF0ZWRDb2xEZWYpO1xyXG5cclxuICAgICAgICByZXR1cm4gIGdlbmVyYXRlZENvbERlZjtcclxuICAgIH1cclxuXHJcbiAgICAvLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vL1xyXG4gICAgLy8vIFJvdyBEYXRhIGZ1bmN0aW9uc1xyXG4gICAgLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy9cclxuICAgIHB1YmxpYyBzZXRSb3dEYXRhKF9yb3dEYXRhOiBBcnJheTxhbnk+KTogdm9pZCB7XHJcbiAgICAgICAgdGhpcy5ncmlkT3B0aW9ucy5yb3dEYXRhID0gX3Jvd0RhdGE7XHJcbiAgICB9XHJcblxyXG4gICAgLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy9cclxuICAgIC8vLyBEYXRhc291cmNlIGZ1bmN0aW9uc1xyXG4gICAgLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy9cclxuICAgIHB1YmxpYyBnZW5lcmF0ZURhdGFzb3VyY2VSb3dzKF9kYXRhc291cmNlUmVxdWVzdDogSUVudGVycHJpc2VHZXRSb3dzUmVxdWVzdCwgX3Jvd0RhdGE6IEFycmF5PGFueT4pOiBPYnNlcnZhYmxlPGFueT4ge1xyXG4gICAgICAgIHJldHVybiBuZXcgT2JzZXJ2YWJsZTxhbnk+KChfb2JzZXJ2ZXI6IFN1YnNjcmliZXI8YW55Pik6IHZvaWQgPT4ge1xyXG4gICAgICAgICAgICAvLyBjb25zb2xlLmxvZygnLS0gR3JpZCBzdGF0ZTogZ2VuZXJhdGUgRGF0YXNvdXJjZSByb3dzIC0tJywgX2RhdGFzb3VyY2VSZXF1ZXN0KTtcclxuXHJcbiAgICAgICAgICAgIGxldCB0ZW1wUm93TW9kZWw6IEFycmF5PGFueT4gPSB0aGlzLl9kYXRhc291cmNlRmlsdGVyUm93KF9kYXRhc291cmNlUmVxdWVzdC5maWx0ZXJNb2RlbCwgX3Jvd0RhdGEpO1xyXG4gICAgICAgICAgICB0aGlzLl9kYXRhc291cmNlU29ydFJvdyhfZGF0YXNvdXJjZVJlcXVlc3Quc29ydE1vZGVsLCB0ZW1wUm93TW9kZWwpO1xyXG5cclxuICAgICAgICAgICAgbGV0IHJlcXVlc3RPYmo6IHtyb3dzOiBBcnJheTxhbnk+LCB0b3RhbDogbnVtYmVyfSA9IHtcclxuICAgICAgICAgICAgICAgIHJvd3M6IHRlbXBSb3dNb2RlbC5zbGljZShfZGF0YXNvdXJjZVJlcXVlc3Quc3RhcnRSb3csIF9kYXRhc291cmNlUmVxdWVzdC5lbmRSb3cpLFxyXG4gICAgICAgICAgICAgICAgdG90YWw6IHRlbXBSb3dNb2RlbC5sZW5ndGhcclxuICAgICAgICAgICAgfTtcclxuXHJcbiAgICAgICAgICAgIF9vYnNlcnZlci5uZXh0KHJlcXVlc3RPYmopO1xyXG4gICAgICAgICAgICBfb2JzZXJ2ZXIuY29tcGxldGUoKTtcclxuICAgICAgICB9KTtcclxuICAgIH1cclxuXHJcbiAgICAvKioqKioqKioqKioqKioqKioqKioqKioqIFB1YmxpYyBmdW5jdGlvbnMgZnJvbSBwYXJlbnQgKioqKioqKioqKioqKioqKioqKioqKiovXHJcbiAgICAvLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vL1xyXG4gICAgLy8vIE92ZXJyaWRlc1xyXG4gICAgLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy9cclxuICAgIHB1YmxpYyB1cGRhdGVTZWxlY3Rpb25WYWx1ZXMoX3Jvd0RhdGE6IEFycmF5PGFueT4sIF9zZWxlY3RlZElkOiBBcnJheTxzdHJpbmcgfCBudW1iZXI+LCBfcmV0dXJuS2V5OiBBcnJheTxzdHJpbmc+LCBfbG9hZFR5cGU6IHN0cmluZyk6IEFycmF5PGFueT4ge1xyXG4gICAgICAgIGlmIChfbG9hZFR5cGUgPT09ICdzZXJ2ZXInICYmIHR5cGVvZiBfcmV0dXJuS2V5ICE9PSAndW5kZWZpbmVkJyAmJiBfcmV0dXJuS2V5Lmxlbmd0aCA+IDApIHtcclxuICAgICAgICAgICAgY29uc29sZS53YXJuKCdLZFRhYmxlIHdhcm5pbmc6IFNlbGVjdGlvbiB2YWx1ZSBub3QgYWJsZSB0byByZXR1cm4gYXMgb2JqZWN0cyBzcGVjaWZ5IGluIHRoZSByZXR1cm5LZXkgcHJvcGVydHkgYXMgdGhlcmUgbWlnaHQgaGF2ZSB1bmtub3duIGRhdGEgdmFsdWVzIGZvciBzZXJ2ZXIgbG9hZFR5cGUuJyk7XHJcbiAgICAgICAgICAgIHJldHVybiBfc2VsZWN0ZWRJZDtcclxuICAgICAgICB9XHJcbiAgICAgICAgcmV0dXJuIHN1cGVyLnVwZGF0ZVNlbGVjdGlvblZhbHVlcyhfcm93RGF0YSwgX3NlbGVjdGVkSWQsIF9yZXR1cm5LZXkpO1xyXG4gICAgfVxyXG5cclxuICAgIC8qKioqKioqKioqKiogRW5kIG9mIHB1YmxpYyBmdW5jdGlvbnMgLyBTdGFydCBvZiBwcml2YXRlIGZ1bmN0aW9ucyAqKioqKioqKioqKi9cclxuICAgIC8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vXHJcbiAgICAvLy8gR3JpZCBvcHRpb25zIGZ1bmN0aW9uc1xyXG4gICAgLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy9cclxuICAgIHByaXZhdGUgX2dlbmVyYXRlQ29uZmlnT3B0aW9ucyhfY29uZmlnOiBJVGFibGVDb25maWcpOiBHcmlkT3B0aW9ucyB7XHJcbiAgICAgICAgbGV0IHBhZ2VzaXplOiBudW1iZXIgPSB0aGlzLl9yZXRyaWV2ZVBhZ2VzaXplKF9jb25maWcucGFnaW5hdGlvbkNvbmZpZyk7XHJcblxyXG4gICAgICAgIGxldCBjb25maWdPcHRpb25zOiBHcmlkT3B0aW9ucyA9IHtcclxuICAgICAgICAgICAgcm93TW9kZWxUeXBlOiAnZW50ZXJwcmlzZScsXHJcbiAgICAgICAgICAgIGVuYWJsZVNlcnZlclNpZGVGaWx0ZXI6IHRydWUsXHJcbiAgICAgICAgICAgIGVuYWJsZVNlcnZlclNpZGVTb3J0aW5nOiB0cnVlLFxyXG5cclxuICAgICAgICAgICAgbWF4Q29uY3VycmVudERhdGFzb3VyY2VSZXF1ZXN0czogMixcclxuICAgICAgICAgICAgY2FjaGVPdmVyZmxvd1NpemU6IDEsXHJcblxyXG4gICAgICAgICAgICByb3dHcm91cFBhbmVsU2hvdzogJ25ldmVyJyxcclxuICAgICAgICAgICAgdG9vbFBhbmVsU3VwcHJlc3NQaXZvdE1vZGU6IHRydWUsXHJcbiAgICAgICAgICAgIHRvb2xQYW5lbFN1cHByZXNzVmFsdWVzOiB0cnVlLFxyXG5cclxuICAgICAgICAgICAgY2FjaGVCbG9ja1NpemU6IHBhZ2VzaXplXHJcbiAgICAgICAgfTtcclxuXHJcbiAgICAgICAgaWYgKHR5cGVvZiBfY29uZmlnLnJvd0lkS2V5ICE9PSAndW5kZWZpbmVkJykge1xyXG4gICAgICAgICAgICB0aGlzLnJvd0tleSA9IF9jb25maWcucm93SWRLZXk7XHJcblxyXG4gICAgICAgICAgICBjb25maWdPcHRpb25zLmdldFJvd05vZGVJZCA9IChfZGF0YTogYW55KTogc3RyaW5nID0+IHtcclxuICAgICAgICAgICAgICAgIGlmIChfZGF0YS5oYXNPd25Qcm9wZXJ0eShfY29uZmlnLnJvd0lkS2V5KSkge1xyXG4gICAgICAgICAgICAgICAgICAgIGxldCBpZDogc3RyaW5nID0gX2RhdGFbX2NvbmZpZy5yb3dJZEtleV07XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIGlmICh0eXBlb2YgX2RhdGFbX2NvbmZpZy5yb3dJZEtleV0gPT09ICdudW1iZXInKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGlkID0gaWQudG9TdHJpbmcoKTtcclxuICAgICAgICAgICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBpZDtcclxuICAgICAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgICAgICByZXR1cm4gJyc7XHJcbiAgICAgICAgICAgIH07XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICBpZiAodHlwZW9mIF9jb25maWcgIT09ICd1bmRlZmluZWQnICYmIHR5cGVvZiBfY29uZmlnLmxvYWRUeXBlICE9PSAndW5kZWZpbmVkJykge1xyXG4gICAgICAgICAgICBpZiAoX2NvbmZpZy5sb2FkVHlwZSAhPT0gJ2luZmluaXRlJykge1xyXG4gICAgICAgICAgICAgICAgY29uZmlnT3B0aW9ucy5wYWdpbmF0aW9uID0gdHJ1ZTtcclxuICAgICAgICAgICAgICAgIGNvbmZpZ09wdGlvbnMubWF4QmxvY2tzSW5DYWNoZSA9IDA7XHJcblxyXG4gICAgICAgICAgICAgICAgY29uZmlnT3B0aW9ucy5wYWdpbmF0aW9uUGFnZVNpemUgPSBwYWdlc2l6ZTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgICAgIC8vIEF1dG8gaGVpZ2h0IHRha2VzIGEgbG90IG9mIGhlaWdodCwgd2lsbCBjYXVzZSBpbmZpbml0ZSByZXRyaWV2aW5nIGlzc3VlXHJcbiAgICAgICAgICAgICAgICBjb25maWdPcHRpb25zLm1heEJsb2Nrc0luQ2FjaGUgPSA1O1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIGlmIChfY29uZmlnLmxvYWRUeXBlID09ICdub3JtYWwnKSB7XHJcbiAgICAgICAgICAgICAgICBjb25maWdPcHRpb25zLnNpZGVCYXIgPSAgdHJ1ZTtcclxuICAgICAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgICAgIGNvbmZpZ09wdGlvbnMuc2lkZUJhciA9ICBmYWxzZTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgcmV0dXJuIGNvbmZpZ09wdGlvbnM7XHJcbiAgICB9XHJcblxyXG4gICAgLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy9cclxuICAgIC8vLyBDb2x1bW4gZGVmaW5pdGlvbnMgZnVuY3Rpb25zXHJcbiAgICAvLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vL1xyXG4gICAgcHJpdmF0ZSBfY2hlY2tDaGVja2JveFNlbGVjdGlvblR5cGUoX2dyaWRDb25maWc6IElUYWJsZUNvbmZpZywgX2NvbERlZnM6IEFycmF5PENvbERlZj4pOiB2b2lkIHtcclxuICAgICAgICBpZiAodHlwZW9mIF9ncmlkQ29uZmlnLnNlbGVjdGlvbiAhPT0gJ3VuZGVmaW5lZCcgJiZcclxuICAgICAgICAgICAgdHlwZW9mIF9ncmlkQ29uZmlnLnNlbGVjdGlvbi50eXBlICE9PSAndW5kZWZpbmVkJyAmJlxyXG4gICAgICAgICAgICB0eXBlb2YgX2dyaWRDb25maWcubG9hZFR5cGUgIT09ICd1bmRlZmluZWQnICYmXHJcbiAgICAgICAgICAgIF9ncmlkQ29uZmlnLnNlbGVjdGlvbi50eXBlID09PSAnYWxsJyAmJlxyXG4gICAgICAgICAgICBfZ3JpZENvbmZpZy5sb2FkVHlwZSA9PT0gJ2luZmluaXRlJykge1xyXG4gICAgICAgICAgICAgICAgY29uc29sZS53YXJuKCdLZFRhYmxlIHdhcm5pbmc6IEluZmluaXRlIGxvYWRUeXBlIG5vdCBhYmxlIHRvIHN1cHBvcnQgYWxsIHNlbGVjdGlvblR5cGUuJyk7XHJcbiAgICAgICAgICAgICAgICBkZWxldGUgX2NvbERlZnNbMF0uaGVhZGVyQ29tcG9uZW50RnJhbWV3b3JrO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF91cGRhdGVDb2xEZWZDb25maWcoX2NvbERlZkNvbmZpZzogQXJyYXk8SVRhYmxlQ29sdW1uPik6IEFycmF5PElUYWJsZUNvbHVtbj4ge1xyXG4gICAgICAgIGxldCB1cGRhdGVkQ29sRGVmQ29uZmlnOiBBcnJheTxJVGFibGVDb2x1bW4+ID0gW107XHJcblxyXG4gICAgICAgIGZvciAobGV0IGk6IG51bWJlciA9IDA7IGkgPCBfY29sRGVmQ29uZmlnLmxlbmd0aDsgaSsrKSB7XHJcbiAgICAgICAgICAgIGlmIChzdXBlci5pc0lucHV0VHlwZShfY29sRGVmQ29uZmlnW2ldLCAnaW5wdXQnKSkge1xyXG4gICAgICAgICAgICAgICAgY29uc29sZS5lcnJvcignS2RUYWJsZSBlcnJvcjogaW5wdXQgY29sdW1uIHR5cGUgaXMgb25seSB2YWxpZCBmb3Igbm9ybWFsIGxvYWRUeXBlIHRhYmxlLiBSZW1vdmluZyBjb2x1bW5zIHdpdGggaW5wdXQgdHlwZS4nKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgICAgIHRoaXMuX2NoZWNrQ29sRGVmRmlsdGVyYWJsZVZhbChfY29sRGVmQ29uZmlnW2ldKTtcclxuICAgICAgICAgICAgICAgIHVwZGF0ZWRDb2xEZWZDb25maWcucHVzaChfY29sRGVmQ29uZmlnW2ldKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgcmV0dXJuIHVwZGF0ZWRDb2xEZWZDb25maWc7XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfY2hlY2tDb2xEZWZGaWx0ZXJhYmxlVmFsKF9jb2xEZWZJdGVtOiBJVGFibGVDb2x1bW4pOiB2b2lkIHtcclxuICAgICAgICBpZiAodHlwZW9mIF9jb2xEZWZJdGVtLmZpbHRlcmFibGUgIT09ICd1bmRlZmluZWQnICYmIF9jb2xEZWZJdGVtLmZpbHRlcmFibGUgJiZcclxuICAgICAgICAgICAgKHR5cGVvZiBfY29sRGVmSXRlbS5maWx0ZXJWYWx1ZSA9PT0gJ3VuZGVmaW5lZCcgfHwgX2NvbERlZkl0ZW0uZmlsdGVyVmFsdWUgPT09IG51bGwgfHwgX2NvbERlZkl0ZW0uZmlsdGVyVmFsdWUubGVuZ3RoID09PSAwICkpIHtcclxuICAgICAgICAgICAgICAgIGNvbnNvbGUuZXJyb3IoJ0tkVGFibGUgZXJyb3I6IEZpbHRlciB2YWx1ZSBmb3IgJyArIF9jb2xEZWZJdGVtLmZpZWxkICsgJyBmaWVsZCBpcyBlbXB0eS4gVXNpbmcgZmlsdGVyIGZvciBsb2FkVHlwZSBvbmVzaG90L2luZmluaXRlL3NlcnZlciByZXF1aXJlcyB0byBwcm92aWRlIGZpbHRlclZhbHVlLiBTdXBwcmVzc2luZyBmaWx0ZXJpbmcgbWVudS4nKTtcclxuICAgICAgICAgICAgICAgIF9jb2xEZWZJdGVtLmZpbHRlcmFibGUgPSBmYWxzZTtcclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgLy8gcHJpdmF0ZSBfdXBkYXRlUm93SGVpZ2h0Rm9ySW1nKF9jb2xEZWZDb25maWc6IEFycmF5PElUYWJsZUNvbHVtbj4pOiB2b2lkIHtcclxuICAgIC8vICAgICBsZXQgbWF4SGVpZ2h0OiBudW1iZXIgPSA1MDtcclxuICAgIC8vICAgICBmb3IgKGxldCBpOiBudW1iZXIgPSAwOyBpIDwgX2NvbERlZkNvbmZpZy5sZW5ndGg7ICsraSkge1xyXG4gICAgLy8gICAgICAgICBpZiAoc3VwZXIuaXNJbnB1dFR5cGUoX2NvbERlZkNvbmZpZ1tpXSwgJ2ltYWdlJykpIHtcclxuICAgIC8vICAgICAgICAgICAgIGxldCB0ZW1wSGVpZ2h0OiBudW1iZXIgPSBzdXBlci5nZXRJbWFnZVNpemVCeShfY29sRGVmQ29uZmlnW2ldLCAnaGVpZ2h0Jyk7XHJcblxyXG4gICAgLy8gICAgICAgICAgICAgaWYgKHRlbXBIZWlnaHQgPiBtYXhIZWlnaHQpIHtcclxuICAgIC8vICAgICAgICAgICAgICAgICBtYXhIZWlnaHQgPSB0ZW1wSGVpZ2h0O1xyXG4gICAgLy8gICAgICAgICAgICAgfVxyXG4gICAgLy8gICAgICAgICB9XHJcbiAgICAvLyAgICAgfVxyXG4gICAgLy8gICAgIGNvbnNvbGUubG9nKCdyb3cgaGVpZ2h0IG1heDogJywgbWF4SGVpZ2h0KTtcclxuICAgIC8vICAgICB0aGlzLmdyaWRPcHRpb25zLnJvd0hlaWdodCA9IG1heEhlaWdodDtcclxuICAgIC8vIH1cclxuXHJcbiAgICAvLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vL1xyXG4gICAgLy8vIERhdGFzb3VyY2Ugc29ydCAvIGZpbHRlciBmdW5jdGlvbnNcclxuICAgIC8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vXHJcbiAgICBwcml2YXRlIF9kYXRhc291cmNlU29ydFJvdyhfc29ydE1vZGVsOiBBcnJheTx7Y29sSWQ6IHN0cmluZywgc29ydDogJ2FzYycgfCAnZGVzYyd9PiwgX3Jvd0RhdGE6IEFycmF5PGFueT4pOiB2b2lkIHtcclxuICAgICAgICBpZiAoX3NvcnRNb2RlbC5sZW5ndGggPiAwKSB7XHJcbiAgICAgICAgICAgIGxldCBzb3J0T3B0aW9uczoge2NvbElkOiBzdHJpbmcsIHNvcnQ6ICdhc2MnIHwgJ2Rlc2MnfSA9IF9zb3J0TW9kZWxbMF07XHJcbiAgICAgICAgICAgIGxldCByZXR1cm5Db25kaXRpb246IG51bWJlciA9IChzb3J0T3B0aW9ucy5zb3J0ID09PSAnYXNjJykgPyAxIDogLTE7XHJcblxyXG4gICAgICAgICAgICBfcm93RGF0YS5zb3J0KChfYTogYW55LCBfYjogYW55KTogbnVtYmVyID0+IHtcclxuICAgICAgICAgICAgICAgIHJldHVybiB0aGlzLl9kYXRhc291cmNlUm93U29ydEZvcm11bGEoX2EsIF9iLCBzb3J0T3B0aW9ucy5jb2xJZCwgcmV0dXJuQ29uZGl0aW9uKTtcclxuICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX2RhdGFzb3VyY2VSb3dTb3J0Rm9ybXVsYShfYTogYW55LCBfYjogYW55LCBfZG90RGlzcGxheUZyb206IHN0cmluZywgX3JldHVyblZhbDogbnVtYmVyKTogbnVtYmVyIHtcclxuICAgICAgICBpZiAodHlwZW9mIF9hICE9PSAndW5kZWZpbmVkJyAmJiB0eXBlb2YgX2IgIT09ICd1bmRlZmluZWQnKSB7XHJcbiAgICAgICAgICAgIGxldCBhVmFsOiBhbnkgPSB0aGlzLmRhdGFTdmMuZ2V0RGF0YVZhbHVlKF9hLCBfZG90RGlzcGxheUZyb20pO1xyXG4gICAgICAgICAgICBsZXQgYlZhbDogYW55ID0gdGhpcy5kYXRhU3ZjLmdldERhdGFWYWx1ZShfYiwgX2RvdERpc3BsYXlGcm9tKTtcclxuXHJcbiAgICAgICAgICAgIGlmIChhVmFsID4gYlZhbCkgcmV0dXJuIF9yZXR1cm5WYWw7XHJcbiAgICAgICAgICAgIGVsc2UgaWYgKGFWYWwgPCBiVmFsKSByZXR1cm4gLShfcmV0dXJuVmFsKTtcclxuICAgICAgICAgICAgcmV0dXJuIDA7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIHJldHVybiAwO1xyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX2RhdGFzb3VyY2VGaWx0ZXJSb3coX2ZpbHRlck1vZGVsOiBhbnksIF9yb3dEYXRhOiBBcnJheTxhbnk+KTogQXJyYXk8YW55PiB7XHJcbiAgICAgICAgbGV0IHRlbXBSb3dNb2RlbDogQXJyYXk8YW55PiA9IFtdO1xyXG5cclxuICAgICAgICBpZiAoT2JqZWN0LmtleXMoX2ZpbHRlck1vZGVsKS5sZW5ndGggPiAwKSB7XHJcbiAgICAgICAgICAgIGZvciAobGV0IGl0ZW0gaW4gX2ZpbHRlck1vZGVsKSB7XHJcbiAgICAgICAgICAgICAgICBpZiAoX2ZpbHRlck1vZGVsLmhhc093blByb3BlcnR5KGl0ZW0pKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgbGV0IGRhdGFLZXk6IHN0cmluZyA9IGl0ZW07XHJcbiAgICAgICAgICAgICAgICAgICAgbGV0IGZpbHRlck1vZGVsSXRlbTogQXJyYXk8c3RyaW5nIHwgbnVtYmVyPiA9IF9maWx0ZXJNb2RlbFtpdGVtXS52YWx1ZXM7XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIGlmIChmaWx0ZXJNb2RlbEl0ZW0ubGVuZ3RoID4gMCkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBmb3IgKGxldCBpOiBudW1iZXIgPSAwOyBpIDwgX3Jvd0RhdGEubGVuZ3RoOyBpKyspIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxldCByb3dJdGVtOiBhbnkgPSBfcm93RGF0YVtpXTtcclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAocm93SXRlbS5oYXNPd25Qcm9wZXJ0eShkYXRhS2V5KSAmJiBmaWx0ZXJNb2RlbEl0ZW0uaW5kZXhPZihyb3dJdGVtW2RhdGFLZXldKSA+IC0xKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdGVtcFJvd01vZGVsLnB1c2gocm93SXRlbSk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgZWxzZSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHRlbXBSb3dNb2RlbCA9IFtdO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBicmVhaztcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICAgICAgZWxzZSB7XHJcbiAgICAgICAgICAgIHRlbXBSb3dNb2RlbCA9IF9yb3dEYXRhLnNsaWNlKCk7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICByZXR1cm4gdGVtcFJvd01vZGVsO1xyXG4gICAgfVxyXG5cclxuICAgIC8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vXHJcbiAgICAvLy8gTWlzYyBmdW5jdGlvbnNcclxuICAgIC8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vXHJcbiAgICBwcml2YXRlIF9yZXRyaWV2ZVBhZ2VzaXplKF9wYWdpbmF0aW9uQ29uZmlnOiBhbnkpOiBudW1iZXIge1xyXG4gICAgICAgIGlmICh0eXBlb2YgX3BhZ2luYXRpb25Db25maWcgIT09ICd1bmRlZmluZWQnICYmXHJcbiAgICAgICAgICAgIHR5cGVvZiBfcGFnaW5hdGlvbkNvbmZpZy5wYWdlc2l6ZSAhPT0gJ3VuZGVmaW5lZCcpIHtcclxuICAgICAgICAgICAgICAgIHJldHVybiBfcGFnaW5hdGlvbkNvbmZpZy5wYWdlc2l6ZTtcclxuICAgICAgICB9XHJcbiAgICAgICAgX3BhZ2luYXRpb25Db25maWcucGFnZXNpemUgPSB0aGlzLkRFRkFVTFRfUEFHRVNJWkU7XHJcbiAgICAgICAgcmV0dXJuIHRoaXMuREVGQVVMVF9QQUdFU0laRTtcclxuICAgIH1cclxuXHJcbiAgICAvKioqKioqKioqKioqKioqKioqKioqKioqKiBFbmQgb2YgcHJpdmF0ZSBmdW5jdGlvbnMgKioqKioqKioqKioqKioqKioqKioqKioqKiovXHJcbn1cclxuIl19