import { __decorate, __metadata } from "tslib";
import { Component, OnInit, OnChanges, OnDestroy, SimpleChanges, ViewEncapsulation, Input, HostBinding, HostListener, ViewContainerRef, EventEmitter, Output } from '@angular/core';
import { Router } from '@angular/router';
import { Observable, timer } from 'rxjs';
import 'ag-grid-enterprise';
import * as XLSX from 'xlsx';
import { saveAs } from 'file-saver';
import { KdTableDatasourceEvent, KdTableSelectionUpdateEvent, KdTableInputUpdateEvent, KdTableButtonEvent } from './kd-angular-table-interface';
import { KdIntTableEvent } from './kd-angular-table-event';
import { KdTableNormalSvc } from './table-services/kd-table-normal-svc';
import { KdTableEnterpriseSvc } from './table-services/kd-table-enterprise-svc';
// import { KdSplitterEvent } from '../';
import { KdDomElemSvc, AG_GRID_KEY } from '../kd-common/index';
import { LicenseManager } from "ag-grid-enterprise";
/**
 * -- Documentation for kd-angular-table.ts (kd-table)
 *
 * - HostListener
 *     - onResize
 *
 * - Life cycles:
 *     - ngOnInit
 *     - ngOnChanges
 *     - ngOnDestroy

 * - ag-Grid events function:
 *     - onGridReady
 *     - onModelUpdated
 *     - onRowClicked
 *
 * - kd-table button function:
 *     - onButtonClicekd
 *
 * - Private functions:
 *     - Display / DOM functions:
 *         - _resizeColumn
 *         - _showLoadingOverlay
 *         - _updateParentNodeCSS
 *         - _setHeight
 *         - _setMobileHeight (flatten table)
 *         - _setWebHeighr (user configuration)
 *         - _isClickValid (click configuration)
 *
 *     - Grid Cycles:
 *         - _gridInitCycle
 *         - _gridReadyCycle
 *         - _gridReadyEnterpriseCycle
 *         - _gridReadyDOMCycle
 *         - _gridSelectionCycle
 *         - _gridSetRowCycle
 *         - _gridClickNavigateCycle
 *
 *     - Column / Row / Config generations/processing:
 *         - _setGridOptions
 *         - _setColumnDef
 *         - _setRowData
 *
 *     - Event functions:
 *         - _processEventParams<T>
 *         - _broadcastEventParams
 *         - _broadcastModelChanged
 *         - _setupSubscriptionEvents
 *
 *     - Selection functions:
 *         - _updateSelectionNodes
 *         - _processInitialSelection
 *
 *     - Input functions:
 *         - _processInputChanged
 *         - _emitInputUpdateEvent
 *         - _deleteNodeFromRowData
 *
 *     - Datasource functions:
 *         - _clearDatasource
 *         - _generateEnterpriseDatasource
 *         - _generateDatasourceRows
 *
 *     - API generations:
 *         - _initITableApi (TODO: update api setting all to table service)
 *
 *     - Misc functions:
 *         - _initGridService
 *         - _updateGridConfig
 */
var KdTable = /** @class */ (function () {
    function KdTable(_vcr, _router, _domSvc, 
    // private _splitterEvent: KdSplitterEvent,
    _tableIntEvent) {
        this._vcr = _vcr;
        this._router = _router;
        this._domSvc = _domSvc;
        this._tableIntEvent = _tableIntEvent;
        this.gridId = '';
        this.displayLoading = true;
        this._enterprise = require('ag-grid-enterprise');
        this._subscriptionObj = {};
        this._currentState = {
            columnState: [],
            pivotMode: false,
            groupState: []
        };
        this._isChangingState = false;
        this._pivotElement = {
            'pivot': null,
            'column-drop': null
        };
        this._suppressMovableColumns = true;
        this._direction = 'ltr';
        this.onExportPossible = new EventEmitter();
        this._classKdxTable = true;
        LicenseManager.setLicenseKey(AG_GRID_KEY.value);
    }
    KdTable.prototype.onResize = function (_event) {
        this._setHeight();
    };
    /************************* Life cycles functions *****************************/
    KdTable.prototype.ngOnInit = function () {
        // console.log("-- Grid state: Init --", this.row, this.column, this.config, this.api);
        this._showLoadingOverlay(true);
        this._gridInitCycle();
    };
    KdTable.prototype.ngOnChanges = function (_simpleChanges) {
        var _this = this;
        this._showLoadingOverlay(true);
        console.log("-- Grid state: Change -- ", _simpleChanges);
        if (typeof _simpleChanges.column !== 'undefined' &&
            !_simpleChanges.column.firstChange) {
            this._setColumnDef(_simpleChanges.column.currentValue);
            this._showLoadingOverlay(false);
        }
        if (typeof _simpleChanges.row !== 'undefined' &&
            !_simpleChanges.row.firstChange) {
            this._setRowData(_simpleChanges.row.currentValue);
            this._showLoadingOverlay(false);
        }
        if (typeof _simpleChanges.config !== 'undefined') {
            this._showLoadingOverlay(false);
            this.updateStyle(_simpleChanges.config.currentValue);
            timer(100).subscribe(function () {
                _this._configurePivotDisplay();
                if (typeof _this.config.suppressMovableColumns !== 'undefined') {
                    if (_this.config.suppressMovableColumns !== _this._suppressMovableColumns)
                        _this._enableColumnMovable(_this.config.suppressMovableColumns);
                }
                else {
                    _this.config.suppressMovableColumns = _this._suppressMovableColumns;
                }
            });
        }
    };
    KdTable.prototype.ngOnDestroy = function () {
        // console.log("-- Grid state: Destroying --");
        for (var item in this._subscriptionObj) {
            if (typeof this._subscriptionObj[item] !== 'undefined') {
                this._subscriptionObj[item].unsubscribe();
            }
        }
    };
    /******************************* Grid events *********************************/
    KdTable.prototype.onGridReady = function (_params) {
        // console.log('-- Grid state: Ready --', this.gridOptions);
        this._gridReadyCycle();
    };
    KdTable.prototype.onModelUpdated = function (_event) {
        /// For select all checkbox checking on change pagination/update row data
        if (this._tableService.hasSelectionAll(this.config)) {
            this._broadcastModelChangedEvent();
        }
        if (this._isMobileView) {
            var gridElement = document.querySelector('#' + this.gridId + '.stg-theme');
            if (gridElement !== null) {
                this._setMobileHeight(gridElement);
            }
        }
    };
    KdTable.prototype.onRowClicked = function (_params) {
        // console.log("-- Grid state: Row clicked --", _params);
        if (this._isClickValid(_params.event) && typeof this.config.click !== 'undefined') {
            switch (this.config.click.type) {
                case 'selection':
                    this._gridSelectionCycle(_params.node);
                    break;
                case 'router':
                    this._gridClickNavigateCycle(_params.node);
                    break;
                default:
                    break;
            }
            if (typeof this.config.click.callback !== 'undefined') {
                this.config.click.callback();
            }
        }
    };
    /***************************** Button functions ******************************/
    KdTable.prototype.onButtonClicked = function (_button) {
        var buttonEvent = new KdTableButtonEvent(_button);
        this._processEventParams('button', buttonEvent);
    };
    /**************************** Private functions ******************************/
    ////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// Grid cycles
    ////////////////////////////////////////////////////////////////////////////////////////////////////////
    KdTable.prototype._gridInitCycle = function () {
        if (typeof this.config !== 'undefined') {
            this._initGridService(this.config.loadType);
            this._updateGridConfig(this.config);
            this._setGridOptions(this.config);
            this._setupSubscriptionEvents();
        }
        if (typeof this.column !== 'undefined') {
            this._setColumnDef(this.column);
        }
        if (typeof this.row !== 'undefined') {
            this._setRowData(this.row);
        }
    };
    KdTable.prototype._gridReadyCycle = function () {
        this._initITableApi();
        if (this._tableService.isEnterpriseModel(this.config.loadType)) {
            this._gridReadyEnterpriseCycle();
        }
        this._gridReadyDOMCycle();
    };
    KdTable.prototype._gridReadyEnterpriseCycle = function () {
        this._clearDatasource();
        this._generateEnterpriseDatasource();
    };
    KdTable.prototype._gridReadyDOMCycle = function () {
        this._updateParentNodeCSS();
        this._setHeight();
        this._resizeColumn();
    };
    KdTable.prototype._gridSelectionCycle = function (_rowNode) {
        if (typeof this.config.selection === 'undefined') {
            console.error('KdTable error: User have set click type to be selection but no selection is defined. Do you mean click type to router?');
        }
        else if (this.config.selection.type === 'single') {
            if (this.config.selection.value.indexOf(_rowNode.id) < 0) {
                this.gridOptions.api.deselectAll();
                _rowNode.selectThisNode(true);
                this.config.selection.value.splice(0, this.config.selection.value.length);
                this.config.selection.value.push(_rowNode.data.id);
                this._broadcastModelChangedEvent();
                this._updateSelectionNodes(_rowNode);
            }
        }
        else {
            var selection = !_rowNode.isSelected();
            _rowNode.selectThisNode(selection);
            this._broadcastModelChangedEvent();
            if (selection) {
                this.config.selection.value.push(_rowNode.data.id);
            }
            else {
                this.config.selection.value.splice(this.config.selection.value.indexOf(_rowNode.data.id), 1);
            }
            this._updateSelectionNodes(_rowNode);
        }
    };
    KdTable.prototype._gridSetRowCycle = function () {
        if (typeof this.config.selection !== 'undefined' && typeof this.config.selection.type !== 'undefined') {
            this._processInitialSelection();
        }
        else if (this._tableService.hasInputType(this.column, 'input')) {
            this._emitInputUpdateEvent();
        }
    };
    KdTable.prototype._gridClickNavigateCycle = function (_rowNode) {
        if (typeof this.config.click.pathMap !== 'undefined') {
            if (typeof this.config.action !== 'undefined' &&
                typeof this.config.action.list !== 'undefined') {
                var routerPath = '';
                for (var i = 0; i < this.config.action.list.length; ++i) {
                    var actionItem = this.config.action.list[i];
                    if (actionItem.type.toLowerCase() === this.config.click.pathMap.toLowerCase()) {
                        routerPath = this._tableService.getRouterPlaceholderPath(_rowNode, actionItem.path);
                        break;
                    }
                }
                if (routerPath !== '') {
                    this._router.navigate([routerPath]);
                }
                else {
                    console.warn('KdTable warning: Table router pathMap not found. pathMap set to:', this.config.click.pathMap);
                }
            }
            else {
                console.error('KdTable error: Table click event set to router pathMap but no action list is defined. Do you mean path property instead of pathMap property?');
            }
        }
        else if (typeof this.config.click.path !== 'undefined') {
            this._router.navigate([this.config.click.path]);
        }
        else {
            console.error('KdTable error: Table click event type set at router but no path / pathMap is provided. Do you mean click type selection / none?');
        }
    };
    ////////////////////////////////////////////////////////////////////////////////////////////////////////
    // Display / DOM function
    ////////////////////////////////////////////////////////////////////////////////////////////////////////
    KdTable.prototype._showLoadingOverlay = function (_toggle) {
        this.displayLoading = _toggle;
    };
    KdTable.prototype._updateParentNodeCSS = function () {
        this._vcr.element.nativeElement.parentNode.className += ' has-aggrid';
        if (this._direction === 'rtl')
            document.querySelector('body').style.cssText += '--kdtable-header-text-align: right;';
    };
    KdTable.prototype._setHeight = function () {
        var domEleQuery = '#' + this.gridId + '.stg-theme';
        var gridElement = this._vcr.element.nativeElement.querySelector(domEleQuery);
        if (gridElement !== null) {
            var windowsWidth = document.body.clientWidth;
            if (windowsWidth <= 1024) {
                if (typeof this._isMobileView === 'undefined' || !this._isMobileView) {
                    this._showLoadingOverlay(true);
                    this._isMobileView = true;
                    this._setMobileHeight(gridElement);
                }
            }
            else if (windowsWidth > 1024) {
                if (typeof this._isMobileView === 'undefined' || this._isMobileView) {
                    this._showLoadingOverlay(true);
                    this._isMobileView = false;
                    this._setWebGridHeight(gridElement, this.config.gridHeight);
                }
                else {
                    this.gridOptions.api.sizeColumnsToFit();
                }
            }
        }
    };
    /**
     * add border bottom dynamically so that when the row is lesser than body-container, there wont be any hanging border bottom
     * when the row is more than container, there will be a border-bottom
     */
    KdTable.prototype._setTableBorderBottom = function () {
        var containerEleQuery = ' .ag-body-container';
        var containerEle = this._vcr.element.nativeElement.querySelector(containerEleQuery);
        if (containerEle === null)
            return;
        var viewportEleQuery = ' .ag-body-viewport';
        var viewportEle = this._vcr.element.nativeElement.querySelector(viewportEleQuery);
        if (containerEle.clientHeight > viewportEle.clientHeight &&
            viewportEle.className &&
            viewportEle.className.indexOf('has-border-bottom') === -1) {
            viewportEle.className += ' has-border-bottom';
        }
        else if (containerEle.clientHeight < viewportEle.clientHeight) {
            viewportEle.className = viewportEle.className.replace(/has-border-bottom/gi, '');
        }
    };
    KdTable.prototype._setMobileHeight = function (_gridElement) {
        var _this = this;
        var newHeight = 0;
        if (this.config.loadType !== 'infinite') {
            var agHeaderEle = this._vcr.element.nativeElement.querySelector('.ag-header');
            var agBodyEle = this._vcr.element.nativeElement.querySelector('.ag-body-container');
            var agPagePanelEle = this._vcr.element.nativeElement.querySelector('div[ref="south"]');
            newHeight = 25;
            if (agHeaderEle !== null) {
                newHeight += agHeaderEle.clientHeight;
            }
            if (agBodyEle !== null) {
                newHeight += agBodyEle.clientHeight;
            }
            if (agPagePanelEle !== null) {
                newHeight += agPagePanelEle.clientHeight;
            }
        }
        else {
            newHeight = 400;
        }
        this._domSvc.setElementStyle(_gridElement, 'height', newHeight + 'px');
        timer(10).subscribe(function () {
            _this.gridOptions.api.sizeColumnsToFit();
            _this._showLoadingOverlay(false);
        });
    };
    /**
     * [_setWebGridHeight number for pixel or string "auto"]
     *  _configHeight [description]
     */
    KdTable.prototype._setWebGridHeight = function (_gridElement, _configHeight) {
        var _this = this;
        if (typeof _configHeight === 'number') {
            var gridHeight = 600;
            if (typeof _configHeight !== 'undefined') {
                gridHeight = _configHeight;
            }
            this._domSvc.setElementStyle(_gridElement, 'height', gridHeight + 'px');
        }
        else if (_configHeight === 'auto') {
            this.displayFull = true;
        }
        // else if (_configHeight === 'rowHeight') {
        //     this.gridOptions.domLayout = 'autoHeight';
        //     delete this.gridOptions.rowHeight;
        //     delete this.gridOptions.getRowHeight;
        // }
        timer().subscribe(function () {
            _this.gridOptions.api.sizeColumnsToFit();
            _this._showLoadingOverlay(false);
        });
    };
    KdTable.prototype._isClickValid = function (_event) {
        var targetElement = _event.target;
        var invalidList = ['action-btn', 'checkbox-radio-input', 'fa-chevron-down'];
        for (var i = 0; i < invalidList.length; i++) {
            if (targetElement.classList.contains(invalidList[i])) {
                return false;
            }
        }
        return true;
    };
    KdTable.prototype._resizeColumn = function (_isResizeToContent) {
        var _this = this;
        if (_isResizeToContent === void 0) { _isResizeToContent = false; }
        if (this._tableService.isApiReady(this.gridOptions)) {
            timer(10).subscribe(function () {
                (_isResizeToContent) ? _this._resizeColumnToContent() : _this.gridOptions.api.sizeColumnsToFit();
                _this.onExportPossible.emit(true);
                _this._showLoadingOverlay(false);
            });
        }
    };
    /**
     * resize column to colDef width
     */
    KdTable.prototype._resizeColumnToContent = function () {
        var allColumnIds = [];
        this.gridOptions.columnApi.getAllDisplayedColumns().forEach(function (column) {
            allColumnIds.push(column.getColId());
        });
        this.gridOptions.columnApi.autoSizeColumns(allColumnIds);
    };
    /**
     * populate dynamic styling value
     * param {ITableConfig} _config: tableConfig
     */
    KdTable.prototype.updateStyle = function (_config) {
        if (!_config || !_config.config) {
            document.querySelector('body').style.cssText = '';
            return;
        }
        var config = _config.config;
        var bodyCss = '';
        bodyCss += this._updateHeaderStyle(config);
        if (config.body) {
            if (config.body.alternateRow === true) {
                if (config.body.odd && config.body.odd.backgroundColor) {
                    bodyCss += '--kdtable-row-odd-background: ' + config.body.odd.backgroundColor + ';';
                }
                if (config.body.even && config.body.even.backgroundColor) {
                    bodyCss += '--kdtable-row-even-background: ' + config.body.even.backgroundColor + ';';
                }
            }
            if (config.body.style) {
                if (config.body.style.borderWidth) {
                    bodyCss += '--kdtable-body-border-width: ' + config.body.style.borderWidth + ';';
                    bodyCss += '--kdtable-header-border-width: ' + config.body.style.borderWidth + ';';
                }
                if (config.body.style.borderColor) {
                    bodyCss += '--kdtable-body-border-color: ' + config.body.style.borderColor + ';';
                    bodyCss += '--kdtable-header-border-color: ' + config.body.style.borderColor + ';';
                }
                if (config.body.style.borderStyle) {
                    bodyCss += '--kdtable-body-border-style: ' + config.body.style.borderStyle + ';';
                    bodyCss += '--kdtable-header-border-style: ' + config.body.style.borderStyle + ';';
                }
            }
        }
        document.querySelector('body').style.cssText = bodyCss;
    };
    KdTable.prototype._updateHeaderStyle = function (_config) {
        if (!_config.header || !_config.header.style)
            return '';
        var bodyCss = '';
        var styleNames = [
            'backgroundColor',
            'textAlign',
            'verticalAlign',
            'color',
            'fontFamily',
            'fontSize',
            'fontWeight',
            'fontStyle',
            'textDecoration',
            // 'borderWidth',
            // 'borderColor',
            // 'borderStyle',
            'opacity'
        ];
        for (var i = 0; i < styleNames.length; ++i) {
            var styleName = styleNames[i];
            var value = _config.header.style[styleName];
            if (styleName === 'verticalAlign')
                value = this._getAlignItem(value);
            styleName = (styleName === 'backgroundColor') ? 'background' : styleName.replace(/([a-z])([A-Z])/g, '$1-$2').toLowerCase();
            if (typeof value !== 'undefined') {
                if (styleName === 'borderWidth' &&
                    (typeof value !== 'string' || value.indexOf('px') === -1))
                    value += 'px';
                bodyCss += '--kdtable-header-' + styleName + ': ' + value + ';';
            }
        }
        return bodyCss;
    };
    /**
     * convert text align into flex-box item align
     * param {string} _verticalAlign: text verticalAlign
     */
    KdTable.prototype._getAlignItem = function (_verticalAlign) {
        if (_verticalAlign === 'baseline' || _verticalAlign === 'bottom') {
            return 'flex-end';
        }
        else if (_verticalAlign === 'top') {
            return 'flex-start';
        }
        else { // including invalid input
            if (_verticalAlign !== 'middle' && _verticalAlign !== undefined) {
                console.warn('ERROR: the vertical align value of ' + _verticalAlign + ' is not yet recognised by KdTable. Please only use either top, center or bottom');
            }
            return 'center';
        }
    };
    // private _refreshTable(_tableCellParams?: ITableCellParams): void {
    //     if (this._tableService && this._tableService.isApiReady && this._tableService.isApiReady(this.gridOptions)) {
    //         let toUpdateNode: Array<RowNode> = [];
    //         let allColumnIds: Array<string> = [];
    //         if (!_tableCellParams) {
    //             this.gridOptions.columnApi.getAllDisplayedColumns().forEach((column) => {
    //                 allColumnIds.push(column.getColId());
    //             });
    //         }
    //         this.gridOptions.api.forEachNode((_rowNode: RowNode): void => {
    //             if (_tableCellParams && typeof _rowNode.id !== 'undefined' && _rowNode.id === _tableCellParams.rowId) {
    //                 _rowNode.data[_tableCellParams.colId] = _tableCellParams.data;
    //                 toUpdateNode.push(_rowNode);
    //             } else {
    //                 toUpdateNode.push(_rowNode);
    //             }
    //         });
    //         let refreshParams: { rowNodes: Array<RowNode>, columns: Array<any> } = {
    //             rowNodes: toUpdateNode,
    //             columns: (_tableCellParams) ? [_tableCellParams.colId] : allColumnIds
    //         };
    //         this.gridOptions.api.refreshCells(refreshParams);
    //     }
    // }
    ////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// Pivot Function
    ////////////////////////////////////////////////////////////////////////////////////////////////////////
    KdTable.prototype._isToolpanelTypeChanged = function () {
        var isTypeChanged = true;
        if (this._previousToolpanelType) {
            if (typeExist(this.config)) {
                isTypeChanged = this._previousToolpanelType !== this.config.pivot.toolpanel.type;
            }
        }
        else {
            if (typeExist(this.config)) {
                this._previousToolpanelType = this.config.pivot.toolpanel.type;
            }
        }
        return isTypeChanged;
        function typeExist(_config) {
            return _config && _config.pivot && _config.pivot.toolpanel && _config.pivot.toolpanel.type;
        }
    };
    KdTable.prototype._configurePivotDisplay = function () {
        var isStateChanged = true;
        if (this.config && this.config.pivot && this.config.pivot.state && this.config.pivot.state.columnState) {
            isStateChanged = this.config.pivot.state.columnState.length !== this._currentState.columnState.length;
        }
        if (this.config.loadType !== 'normal' || (this._isToolpanelTypeChanged() === false && isStateChanged === false))
            return;
        var showToolPanel = false;
        var showPivotMode = false;
        if (this.config.pivot && this.config.pivot.toolpanel) {
            showToolPanel = this.config.pivot.toolpanel.type !== 'none';
            showPivotMode = this.config.pivot.toolpanel.type === 'pivot';
        }
        this._showToolPanel(showToolPanel);
        this._showPivotMode(showPivotMode);
    };
    /**
     * resize column to fit table container if the width of the content column is smaller than container
     */
    KdTable.prototype._pivotResize = function () {
        var container = this._vcr.element.nativeElement.querySelector('.ag-header-container');
        var header = this._vcr.element.nativeElement.querySelector('.ag-header-container .ag-header-row');
        this._resizeColumn(header.getBoundingClientRect().width > container.getBoundingClientRect().width);
    };
    KdTable.prototype._resetPivotColumn = function () {
        this.gridOptions.columnApi.setRowGroupColumns([]);
        this.gridOptions.columnApi.setPivotColumns([]);
        this.gridOptions.columnApi.setValueColumns([]);
        this.gridOptions.columnApi.setSecondaryColumns([]);
    };
    /**
     * pass state to application.
     * (if setState was triggered before), wait until setState has done processing
     * return {ITablePivotState} [description]
     */
    KdTable.prototype._getPivotState = function () {
        var _this = this;
        // if state is changing, wait until state has been updated then get the most updated state
        var getState = function () {
            _this._currentState.columnState = _this.gridOptions.columnApi.getColumnState();
            _this._currentState.pivotMode = _this.gridOptions.columnApi.isPivotMode();
            _this._currentState.groupState = _this.gridOptions.columnApi.getColumnGroupState();
            return _this._currentState;
        };
        var check = function () {
            return _this._isChangingState === false;
        };
        return this.wait(check, getState);
    };
    /**
     * replace current state if a state is given, expandGroup base on config
     * should wait until column is present.
     * param {ITablePivotState} _state
     */
    KdTable.prototype._setPivotState = function (_state) {
        var _this = this;
        if (typeof (_state) === 'undefined' || !_state.hasOwnProperty('columnState'))
            return;
        var setState = function () {
            _this._isChangingState = true;
            if (_state.columnState.length === 0) {
                _this._isChangingState = false;
                _this._pivotResize();
                return;
            }
            _this._currentState = Object.assign(_this._currentState, _state);
            _this.gridOptions.columnApi.setColumnState(_state.columnState);
            _this.gridOptions.columnApi.setPivotMode(_state.pivotMode || false);
            _this.gridOptions.columnApi.setColumnGroupState(_state.groupState || []);
            _this._isChangingState = false;
            timer(100).subscribe(function () {
                _this._setPivotColumns();
                _this._expandGroup();
            });
        };
        var check = function () {
            return _this.column && _this.column.length > 0;
        };
        this.wait(check, setState);
    };
    /**
     * wait for something to finish then do something, breaks at 100th to prevent infinite loop
     * param {ITablePivotState} _state
     * return {any}
     */
    KdTable.prototype.wait = function (_check, _do, _limitCounter) {
        var _this = this;
        if (_limitCounter === void 0) { _limitCounter = 0; }
        if ((_check() && this._tableService.isApiReady(this.gridOptions)) || _limitCounter === 100) {
            if (_limitCounter === 100)
                console.log('Timeout: check fails. running', _do);
            return _do();
        }
        else {
            timer(10).subscribe(function () {
                _limitCounter++;
                _this.wait(_check, _do, _limitCounter);
            });
        }
    };
    KdTable.prototype._isPivotElmExist = function (_pivotElement) {
        return (typeof _pivotElement['pivot'] !== 'undefined' &&
            _pivotElement['pivot'] !== null &&
            typeof _pivotElement['column-drop'] !== 'undefined' &&
            _pivotElement['column-drop'] !== null);
    };
    /**
     * show pivot mode checkbox and label.
     * when pivot mode is hidden, all pivot data has to be reset.
     * param {boolean = true} _show: true to show, false to hide
     */
    KdTable.prototype._showPivotMode = function (_show) {
        var _this = this;
        if (_show === void 0) { _show = true; }
        var setPivotMode = function () {
            if (_show === true) {
                _this._pivotElement['pivot'].className = _this._pivotElement['pivot'].className.replace(/ hidden/gi, '');
                for (var i = 0; i < _this._pivotElement['column-drop'].length; ++i) {
                    _this._pivotElement['column-drop'][i].className = _this._pivotElement['column-drop'][i].className.replace(/ hidden/gi, '');
                }
                _this._setPivotState(_this.config.pivot && _this.config.pivot.state ? _this.config.pivot.state : {});
                return;
            }
            if (_this._pivotElement['pivot'] &&
                _this._pivotElement['pivot'].className &&
                _this._pivotElement['pivot'].className.indexOf('hidden') === -1) {
                _this._pivotElement['pivot'].className += ' hidden';
                for (var j = 0; j < _this._pivotElement['column-drop'].length; ++j) {
                    _this._pivotElement['column-drop'][j].className += ' hidden';
                }
            }
            _this._enabledPivotMode(false);
            _this._setPivotState({
                'columnState': [],
                'pivotMode': false,
                'groupState': []
            });
            _this._resetPivotColumn();
        };
        var check = function () {
            // if (this.config.pivot.toolpanel.type === 'none' || !this.config.pivot || !this.config.pivot.toolpanel) return true;
            if (_this.config.pivot &&
                _this.config.pivot.toolpanel &&
                _this.config.pivot.toolpanel.type &&
                _this.config.pivot.toolpanel.type !== 'none') {
                var isPivotElmExist = _this._isPivotElmExist(_this._pivotElement);
                if (isPivotElmExist === true)
                    return isPivotElmExist;
                var domEleQuery = '#' + _this.gridId + '.stg-theme .ag-side-bar';
                _this._pivotElement['pivot'] = _this._vcr.element.nativeElement.querySelector(domEleQuery + ' .ag-pivot-mode-panel');
                _this._pivotElement['column-drop'] = _this._vcr.element.nativeElement.querySelectorAll(domEleQuery + ' .ag-column-drop');
                return _this._isPivotElmExist(_this._pivotElement);
            }
            else {
                return true;
            }
        };
        this.wait(check, setPivotMode);
    };
    /**
     * hide and show toolpanel (pivot mode panel)
     * param {boolean} _show: true to show, false to hide
     */
    KdTable.prototype._showToolPanel = function (_show) {
        var _this = this;
        if (this._tableService.isApiReady(this.gridOptions)) {
            timer(10).subscribe(function () {
                _this.gridOptions.api.showToolPanel(_show);
            });
        }
    };
    /**
     * expand row group base on the status that passed in
     * param {boolean} _expand: true to expand, false to collapse
     */
    KdTable.prototype._expandGroup = function (_expand) {
        var _this = this;
        if (typeof _expand === 'undefined') {
            _expand = false;
            if (this.config.pivot && this.config.pivot.state && this.config.pivot.state.expandGroup) {
                _expand = this.config.pivot.state.expandGroup;
            }
        }
        if (this._tableService.isApiReady(this.gridOptions)) {
            timer(10).subscribe(function () {
                (_expand) ? _this.gridOptions.api.expandAll() : _this.gridOptions.api.collapseAll();
                _this._pivotResize();
            });
        }
    };
    /**
     * turn on and off pivot mode
     * If on, 'Column Label' will appear
     * If on, tick column name on toolpanel will assign column to 'Row Group' / 'Values' depends on colDef
     * If off, tick column name on toolpanel will trigger column hide and show
     * param {boolean = false} _enabled: true to check, false to uncheck
     */
    KdTable.prototype._enabledPivotMode = function (_enabled) {
        if (_enabled === void 0) { _enabled = false; }
        this.gridOptions.columnApi.setPivotMode(_enabled);
    };
    // TODO: to be revisit
    /**
     * suppressMovableColumns on pivotColumns and rowGroupColumns
     * columns on pivot mode does not listen to colDef.suppressMovableColumns = true
     * hence we need to access their private variable lockPosition and lockPinned to suppress the column movement
     * param {any} _columns [either passed in from gridEvent: column or will getAllDisplayedColumns]
     */
    KdTable.prototype._setPivotColumns = function (_columns) {
        var _this = this;
        var isPinned = false;
        if (!_columns)
            _columns = this.gridOptions.columnApi.getAllDisplayedColumns();
        _columns.forEach(function (column) {
            _this._setColumn(column);
            var columnDef = column.getColDef();
            if (columnDef.pivotValueColumn) {
                _this._setColumn(columnDef.pivotValueColumn);
            }
            else {
                if (column.parent) {
                    isPinned = true;
                    _this._setColumn(column.parent, false);
                    column.parent.pinned = 'left';
                    column.pinned = 'left';
                    columnDef.pinned = 'left';
                }
            }
        });
        if (isPinned)
            this._resizeColumn(true);
    };
    KdTable.prototype._setColumn = function (_column, _isSetColDef) {
        if (_isSetColDef === void 0) { _isSetColDef = true; }
        if (_isSetColDef) {
            var columnDef = _column.getColDef();
            columnDef.suppressMovable = this._suppressMovableColumns;
            columnDef.lockPosition = this._suppressMovableColumns;
            columnDef.lockPinned = this._suppressMovableColumns;
        }
        if (_column.setMoving) {
            _column.setMoving(!this._suppressMovableColumns);
        }
        else {
            _column.moving = !this._suppressMovableColumns;
        }
        _column.lockPosition = this._suppressMovableColumns;
        _column.lockPinned = this._suppressMovableColumns;
    };
    // TODO: to be revisit
    ////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// Column/Row/Configuration Generation
    ////////////////////////////////////////////////////////////////////////////////////////////////////////
    KdTable.prototype._setGridOptions = function (_tableConfig) {
        var _this = this;
        if (_tableConfig.hasOwnProperty('suppressMovableColumns'))
            this._suppressMovableColumns = _tableConfig.suppressMovableColumns;
        this._direction = this._domSvc.getDocumentDirection();
        this.gridOptions = this._tableService.generateGridOptions(_tableConfig, this._direction);
        this.gridOptions.context['gridId'] = this.gridId;
        this.gridOptions.suppressMovableColumns = false;
        this.gridOptions.onColumnRowGroupChanged = function (params) {
            _this._setPivotColumns(params.columns);
            _this._expandGroup();
        };
        this._tableService.setGridOptions(this.gridOptions);
    };
    KdTable.prototype._setColumnDef = function (_colDefConfig) {
        this._tableService.setColumnDef(_colDefConfig, this.config, this._suppressMovableColumns);
        this._resizeColumn();
    };
    KdTable.prototype._enableColumnMovable = function (_enabled) {
        if (_enabled === void 0) { _enabled = true; }
        if (this._tableService.isApiReady(this.gridOptions)) {
            this._suppressMovableColumns = _enabled;
            this._setColumnDef(this.column);
            if (this.config.loadType === 'normal' && this.config.pivot.toolpanel.type === 'pivot') {
                this._setPivotState(this._currentState);
            }
            this._pivotResize();
        }
    };
    KdTable.prototype._setRowData = function (_rowData, _setToGridOptions) {
        var _this = this;
        if (_setToGridOptions === void 0) { _setToGridOptions = true; }
        // this._tableService.updateRowDataWithColumnConfig(_rowData, this.column, this.gridId);
        this._tableService.updateRowDataWithColumn(_rowData, this.column, this.gridId, this.gridOptions);
        if (_setToGridOptions) {
            this._tableService.setRowData(_rowData);
        }
        if (this._tableService.isEnterpriseModel(this.config.loadType) && this._tableService.isApiReady(this.gridOptions)) {
            this._gridReadyEnterpriseCycle();
        }
        timer().subscribe(function () {
            _this._gridSetRowCycle();
            _this._setTableBorderBottom();
        });
    };
    ////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// Events - Subscriber / On functions
    ////////////////////////////////////////////////////////////////////////////////////////////////////////
    KdTable.prototype._processEventParams = function (_fromEvent, _additionalParams) {
        switch (_fromEvent) {
            case 'datasource':
            case 'selection':
            case 'input':
            case 'button':
                this._broadcastEventParams(_additionalParams);
                break;
            default:
                console.error('KdTable warning: No such event found for: ', _fromEvent);
        }
    };
    KdTable.prototype._broadcastEventParams = function (_params) {
        this._tableIntEvent.kdTableEventList(this.config.id, _params);
    };
    KdTable.prototype._broadcastModelChangedEvent = function () {
        this._tableIntEvent.modelChanged(this.config.id);
    };
    KdTable.prototype._setupSubscriptionEvents = function () {
        var _this = this;
        this._subscriptionObj.selectNodesSub = this._tableIntEvent.onSelectionChanged(this.config.id).subscribe(function (_rowNode) {
            _this._updateSelectionNodes(_rowNode);
        });
        this._subscriptionObj.gridQuestionSub = this._tableIntEvent.onInputChanged(this.config.id).subscribe(function (_formParams) {
            _this._processInputChanged(_formParams);
        });
        this._subscriptionObj.updateEmitRow = this._tableIntEvent.onUpdateEmitRowNodes(this.config.id).subscribe(function (_data) {
            if (_data.action === 'delete') {
                var rowKey = (typeof _this.config.rowIdKey !== 'undefined') ? _this.config.rowIdKey : 'id';
                _this._deleteNodeFromRowData([_data.rowData[rowKey]]);
                _this._emitInputUpdateEvent();
            }
        });
    };
    ////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// Selection - Checkbox / Radio functions
    ////////////////////////////////////////////////////////////////////////////////////////////////////////
    KdTable.prototype._updateSelectionNodes = function (_rowNode, _isInitial) {
        var triggerNode = (typeof _isInitial !== 'undefined' && _isInitial) ? 'initial' : 'all';
        if (typeof _rowNode !== 'undefined') {
            triggerNode = _rowNode.data.id;
        }
        var selectionParams = new KdTableSelectionUpdateEvent();
        selectionParams.triggerNode = triggerNode;
        selectionParams.selectedNodes = this._tableService.updateSelectionValues(this.gridOptions.rowData, this.config.selection.value, this.config.selection.returnKey, this.config.loadType);
        // selectionParams.selection = (_rowNode.isSelected()) ? 'selected' : 'unselected';
        this._processEventParams('selection', selectionParams);
    };
    KdTable.prototype._processInitialSelection = function () {
        this._updateSelectionNodes(undefined, true);
    };
    ////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// Input functions
    ////////////////////////////////////////////////////////////////////////////////////////////////////////
    KdTable.prototype._processInputChanged = function (_formParams) {
        var inputParams = new KdTableInputUpdateEvent();
        inputParams.colId = _formParams.colId;
        inputParams.rowId = _formParams.rowId;
        inputParams.questionKey = _formParams.questionKey;
        inputParams.question = _formParams.question;
        inputParams.value = _formParams.data;
        this._processEventParams('input', inputParams);
    };
    KdTable.prototype._emitInputUpdateEvent = function () {
        var inputParams = new KdTableInputUpdateEvent();
        this._processEventParams('input', inputParams);
    };
    KdTable.prototype._deleteNodeFromRowData = function (_dataList) {
        var rowIdKey = (typeof this.config.rowIdKey !== 'undefined') ? this.config.rowIdKey : 'id';
        for (var i = 0; i < _dataList.length; ++i) {
            for (var j = 0; j < this.row.length; ++j) {
                if (_dataList[i].toString() === this.row[j][rowIdKey].toString()) {
                    this.row.splice(j, 1);
                    break;
                }
            }
        }
    };
    ////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// Enterprise datasource functions
    ////////////////////////////////////////////////////////////////////////////////////////////////////////
    KdTable.prototype._clearDatasource = function () {
        if (this._tableService.isApiReady(this.gridOptions)) {
            this.gridOptions.api.setEnterpriseDatasource(null);
            this.gridOptions.api.setFilterModel(null);
            this.gridOptions.api.setSortModel(null);
            if (typeof this._subscriptionObj.datasourceSub !== 'undefined') {
                this._subscriptionObj.datasourceSub.unsubscribe();
            }
        }
    };
    KdTable.prototype._generateEnterpriseDatasource = function () {
        var _this = this;
        var datasource = {
            getRows: function (_params) {
                _this._showLoadingOverlay(true);
                if (typeof _this._subscriptionObj.datasourceSub !== 'undefined') {
                    _this._subscriptionObj.datasourceSub.unsubscribe();
                }
                _this._subscriptionObj.datasourceSub = _this._generateDatasourceRows(_params).subscribe(function (_response) {
                    _params.successCallback(_response.rows, _response.total);
                    _this._showLoadingOverlay(false);
                });
            }
        };
        this.gridOptions.api.setEnterpriseDatasource(datasource);
    };
    KdTable.prototype._generateDatasourceRows = function (_datasourceParams) {
        var _this = this;
        return new Observable(function (_observer) {
            switch (_this.config.loadType) {
                case 'infinite':
                case 'oneshot':
                    _this._tableService.generateDatasourceRows(_datasourceParams.request, _this.gridOptions.rowData.slice()).subscribe(function (_response) {
                        _observer.next(_response);
                        _observer.complete();
                    });
                    break;
                case 'server':
                    var serverParams = new KdTableDatasourceEvent(_datasourceParams.request, _observer);
                    _this._processEventParams('datasource', serverParams);
                    break;
                default:
                    console.error('KdTable warning: No such loadType find for: ', _this.config.loadType);
                    _observer.complete();
            }
        });
    };
    ////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// API functions
    ////////////////////////////////////////////////////////////////////////////////////////////////////////
    KdTable.prototype._initITableApi = function () {
        var _this = this;
        if (typeof this.api !== 'undefined') {
            var apiParams = {
                // gridOptions: this.gridOptions,
                event: this._tableIntEvent,
                id: this.config.id,
                rows: this.row,
                columns: this.column
            };
            this._tableService.generatedApiFunctions(this.api, apiParams);
            /// Temp fix to access loading variable //
            /********* General API **********/
            this.api.general.showLoading = function (_toggle) {
                _this.displayLoading = _toggle;
            };
            this.api.general.updateCell = function (_tableCellParams) {
                var toUpdateNode = [];
                _this.gridOptions.api.forEachNode(function (_rowNode) {
                    if (typeof _rowNode.id !== 'undefined' && _rowNode.id === _tableCellParams.rowId) {
                        _rowNode.data[_tableCellParams.colId] = _tableCellParams.data;
                        toUpdateNode.push(_rowNode);
                    }
                });
                var refreshParams = {
                    rowNodes: toUpdateNode,
                    columns: [_tableCellParams.colId]
                };
                _this.gridOptions.api.refreshCells(refreshParams);
            };
            this.api.general.searchRow = function (_searchText) {
                if (_this.config.loadType === 'normal') {
                    _this.gridOptions.api.setQuickFilter(_searchText);
                }
                else {
                    console.warn('KdTable warning: Quick filtering of data is not supported for oneshot/server/infinite loadType.');
                }
            };
            this.api.general.addRows = function (_rows, _scrollToVisible) {
                if (_scrollToVisible === void 0) { _scrollToVisible = false; }
                /*
                    ag-Grid did not export RowDataTransaction interface. Interface as:
                        {
                            add: [],
                            remove: [],
                            update: []
                        }
                 */
                if (typeof _this.config.loadType === 'undefined' || _this.config.loadType === 'normal') {
                    var rowKey = (typeof _this.config.rowIdKey !== 'undefined') ? _this.config.rowIdKey : 'id';
                    for (var i = 0; i < _rows.length; ++i) {
                        _this.row.push(_rows[i]);
                    }
                    _this._setRowData(_this.row, false);
                    _this.gridOptions.api.updateRowData({ add: _rows.slice() });
                    if (_scrollToVisible) {
                        _this.gridOptions.api.ensureIndexVisible(_this.gridOptions.api.getRowNode(_rows[0][rowKey].toString()).rowIndex);
                    }
                }
                else {
                    console.warn('KdTable warning: API function: addRows() can only be used for normal loadType.');
                }
            };
            this.api.general.deleteRows = function (_id) {
                var _a;
                if (typeof _this.config.loadType === 'undefined' || _this.config.loadType === 'normal') {
                    var deleteIdList = [];
                    if (typeof _id === 'string' || typeof _id === 'number') {
                        deleteIdList.push(_id.toString());
                    }
                    else {
                        for (var i = 0; i < _id.length; ++i) {
                            deleteIdList.push(_id.toString());
                        }
                    }
                    _this._deleteNodeFromRowData(deleteIdList);
                    var key = typeof _this.config.rowIdKey === 'undefined' ? 'id' : _this.config.rowIdKey;
                    var deleteRows = [];
                    for (var i = 0; i < deleteIdList.length; ++i) {
                        deleteRows.push((_a = {}, _a[key] = deleteIdList[i], _a));
                    }
                    /*
                        ag-Grid did not export RowDataTransaction interface. Interface as:
                            {
                                add: [],
                                remove: [],
                                update: []
                            }
                     */
                    var transactionObj = {
                        remove: deleteRows
                    };
                    _this.gridOptions.api.updateRowData(transactionObj);
                    _this._emitInputUpdateEvent();
                }
                else {
                    console.warn('KdTable warning: API function: addRows() can only be used for normal loadType.');
                }
            };
            this.api.general.setButtonDisabled = function (_buttonType, _toDisabled) {
                for (var i = 0; i < _this.config.button.length; ++i) {
                    if (_this.config.button[i].type === _buttonType) {
                        _this.config.button[i].disabled = _toDisabled;
                    }
                }
            };
            this.api.general.exportToExcel = function (_params) {
                var defaultParams = {
                    fileName: 'file',
                    allColumns: true,
                    suppressTextAsCDATA: true,
                };
                // xlsx only allow sheet name to be 31 characters long;
                if (_params.hasOwnProperty('sheetName'))
                    _params.sheetName = _params.sheetName.slice(0, 31);
                var params = Object.assign({}, defaultParams, _params);
                var content = _this.gridOptions.api.getDataAsExcel(params);
                var workbook = XLSX.read(content, { type: 'binary' });
                var xlsxContent = XLSX.write(workbook, { bookType: 'xlsx', type: 'base64' });
                var blobObject = _this._tableService.b64toBlob(xlsxContent, 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
                saveAs(blobObject, params.fileName + '.xlsx');
            };
            this.api.general.resizeColumn = function (_isResizeToContent) {
                if (_isResizeToContent === void 0) { _isResizeToContent = false; }
                _this._resizeColumn(_isResizeToContent);
            };
            this.api.general.enableColumnMovable = function (_enabled) {
                _this._enableColumnMovable(_enabled);
            };
            /********* Pivot API **********/
            if (typeof (this.api.pivot) === 'undefined')
                this.api.pivot = {};
            this.api.pivot.autoResize = function () {
                _this._pivotResize();
            };
            this.api.pivot.showToolPanel = function (_show) {
                _this._showToolPanel(_show);
            };
            this.api.pivot.expandGroup = function (_expand) {
                _this._expandGroup(_expand);
            };
            this.api.pivot.getPivotState = function () {
                return _this._getPivotState();
            };
            this.api.pivot.setPivotState = function (_state) {
                _this._setColumnDef(_this.column);
                _this._setPivotState(_state);
            };
            this.api.pivot.enabledPivotMode = function (_enabled) {
                _this._enabledPivotMode(_enabled);
            };
            this.api.pivot.showPivotMode = function (_show) {
                _this._showPivotMode(_show);
            };
            /********* Input API **********/
            this.api.dynamicForm.clearAllError = function () {
                var tableContext = _this.gridOptions.context[_this._tableService.getTableContextKey()];
                for (var item in tableContext) {
                    if (tableContext.hasOwnProperty(item)) {
                        var contextItem = tableContext[item];
                        for (var question in contextItem) {
                            if (contextItem.hasOwnProperty(question)) {
                                if (typeof contextItem[question].errors === 'undefined') {
                                    contextItem[question].errors = [];
                                }
                                contextItem[question].errors.length = 0;
                            }
                        }
                    }
                }
            };
        }
        else {
            console.warn('KdTable warning: No api property / undefined api property is passed in.');
        }
    };
    ////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// Misc functions
    ////////////////////////////////////////////////////////////////////////////////////////////////////////
    KdTable.prototype._initGridService = function (_loadType) {
        if (typeof _loadType === 'undefined' || _loadType === 'normal') {
            this._tableService = new KdTableNormalSvc();
        }
        else {
            this._tableService = new KdTableEnterpriseSvc();
        }
    };
    KdTable.prototype._updateGridConfig = function (_gridConfig) {
        this.gridId = this._tableService.getGridId(_gridConfig);
        this._tableService.updateGridButtons(_gridConfig);
        this._tableService.updateSelectDefaultValue(_gridConfig);
    };
    KdTable.ctorParameters = function () { return [
        { type: ViewContainerRef },
        { type: Router },
        { type: KdDomElemSvc },
        { type: KdIntTableEvent }
    ]; };
    __decorate([
        Input(),
        __metadata("design:type", Array)
    ], KdTable.prototype, "row", void 0);
    __decorate([
        Input(),
        __metadata("design:type", Array)
    ], KdTable.prototype, "column", void 0);
    __decorate([
        Input(),
        __metadata("design:type", Object)
    ], KdTable.prototype, "config", void 0);
    __decorate([
        Input(),
        __metadata("design:type", Object)
    ], KdTable.prototype, "api", void 0);
    __decorate([
        Output(),
        __metadata("design:type", EventEmitter)
    ], KdTable.prototype, "onExportPossible", void 0);
    __decorate([
        HostBinding('class.full-grid'),
        __metadata("design:type", Boolean)
    ], KdTable.prototype, "displayFull", void 0);
    __decorate([
        HostBinding('class.kdx-table'),
        __metadata("design:type", Boolean)
    ], KdTable.prototype, "_classKdxTable", void 0);
    __decorate([
        HostListener('window:resize', ['$event']),
        __metadata("design:type", Function),
        __metadata("design:paramtypes", [Event]),
        __metadata("design:returntype", void 0)
    ], KdTable.prototype, "onResize", null);
    KdTable = __decorate([
        Component({
            selector: 'kd-table',
            template: "<div class=\"kdx kdx-ag-grid-wrapper\">\r\n    <kd-progressloader *ngIf=\"displayLoading\" configtype=\"small-spinner\" [configvalue]=\"null\"></kd-progressloader>\r\n    <div *ngIf=\"config.button.length > 0\" class=\"gird-btn-wrapper\">\r\n        <button *ngFor=\"let item of config.button\" class=\"btn btn-icon\" type='button' [disabled]=\"item.disabled\" (click)=\"onButtonClicked(item)\">\r\n            <i [ngClass]=\"item.icon\"></i>\r\n            <span>{{item.label}}</span>\r\n        </button>\r\n    </div>\r\n    <ag-grid-angular\r\n    \t#agGrid\r\n    \tid=\"{{gridId}}\"\r\n    \tclass=\"stg-theme\"\r\n    \t[ngClass]=\"{'ag-row-clickable': config.click}\"\r\n        [gridOptions]=\"gridOptions\"\r\n        (gridReady)=\"onGridReady($event)\"\r\n        (modelUpdated)=\"onModelUpdated($event)\"\r\n        (rowClicked)=\"onRowClicked($event)\"\r\n    ></ag-grid-angular>\r\n</div>",
            encapsulation: ViewEncapsulation.None,
            providers: [KdDomElemSvc, KdIntTableEvent, KdTableNormalSvc, KdTableEnterpriseSvc],
            host: { 'class': 'kdx-table' }
        }),
        __metadata("design:paramtypes", [ViewContainerRef,
            Router,
            KdDomElemSvc,
            KdIntTableEvent])
    ], KdTable);
    return KdTable;
}());
export { KdTable };
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoia2QtYW5ndWxhci10YWJsZS5qcyIsInNvdXJjZVJvb3QiOiJuZzovL29wZW5lbWlzLXN0eWxlZ3VpZGUtbGliLyIsInNvdXJjZXMiOlsia2QtY29tcG9uZW50cy9rZC1hbmd1bGFyLXRhYmxlL2tkLWFuZ3VsYXItdGFibGUudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IjtBQUFBLE9BQU8sRUFDSCxTQUFTLEVBQ1QsTUFBTSxFQUNOLFNBQVMsRUFDVCxTQUFTLEVBQ1QsYUFBYSxFQUNiLGlCQUFpQixFQUNqQixLQUFLLEVBQ0wsV0FBVyxFQUNYLFlBQVksRUFDWixnQkFBZ0IsRUFDaEIsWUFBWSxFQUNaLE1BQU0sRUFDVCxNQUFNLGVBQWUsQ0FBQztBQUN2QixPQUFPLEVBQUUsTUFBTSxFQUFFLE1BQU0saUJBQWlCLENBQUM7QUFDekMsT0FBTyxFQUFFLFVBQVUsRUFBRSxLQUFLLEVBQTRCLE1BQU0sTUFBTSxDQUFDO0FBZ0JuRSxPQUFPLG9CQUFvQixDQUFDO0FBQzVCLE9BQU8sS0FBSyxJQUFJLE1BQU0sTUFBTSxDQUFDO0FBQzdCLE9BQU8sRUFBRSxNQUFNLEVBQUUsTUFBTSxZQUFZLENBQUM7QUFFcEMsT0FBTyxFQVdILHNCQUFzQixFQUN0QiwyQkFBMkIsRUFDM0IsdUJBQXVCLEVBQ3ZCLGtCQUFrQixFQUNyQixNQUFNLDhCQUE4QixDQUFDO0FBRXRDLE9BQU8sRUFBRSxlQUFlLEVBQUUsTUFBTSwwQkFBMEIsQ0FBQztBQUMzRCxPQUFPLEVBQUUsZ0JBQWdCLEVBQUUsTUFBTSxzQ0FBc0MsQ0FBQztBQUN4RSxPQUFPLEVBQUUsb0JBQW9CLEVBQUUsTUFBTSwwQ0FBMEMsQ0FBQztBQUNoRix5Q0FBeUM7QUFDekMsT0FBTyxFQUFFLFlBQVksRUFBRSxXQUFXLEVBQUUsTUFBTSxvQkFBb0IsQ0FBQztBQUMvRCxPQUFPLEVBQUMsY0FBYyxFQUFDLE1BQU0sb0JBQW9CLENBQUM7QUFJbEQ7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztHQXFFRztBQVlIO0lBa0NJLGlCQUNZLElBQXNCLEVBQ3RCLE9BQWUsRUFDZixPQUFxQjtJQUM3QiwyQ0FBMkM7SUFDbkMsY0FBK0I7UUFKL0IsU0FBSSxHQUFKLElBQUksQ0FBa0I7UUFDdEIsWUFBTyxHQUFQLE9BQU8sQ0FBUTtRQUNmLFlBQU8sR0FBUCxPQUFPLENBQWM7UUFFckIsbUJBQWMsR0FBZCxjQUFjLENBQWlCO1FBdENwQyxXQUFNLEdBQVcsRUFBRSxDQUFDO1FBRXBCLG1CQUFjLEdBQVksSUFBSSxDQUFDO1FBRTlCLGdCQUFXLEdBQUcsT0FBTyxDQUFDLG9CQUFvQixDQUFDLENBQUM7UUFHNUMscUJBQWdCLEdBQW9DLEVBQUUsQ0FBQztRQUV2RCxrQkFBYSxHQUFxQjtZQUN0QyxXQUFXLEVBQUUsRUFBRTtZQUNmLFNBQVMsRUFBRSxLQUFLO1lBQ2hCLFVBQVUsRUFBRSxFQUFFO1NBQ2pCLENBQUM7UUFDTSxxQkFBZ0IsR0FBWSxLQUFLLENBQUM7UUFDbEMsa0JBQWEsR0FBMkI7WUFDNUMsT0FBTyxFQUFFLElBQUk7WUFDYixhQUFhLEVBQUUsSUFBSTtTQUN0QixDQUFDO1FBRU0sNEJBQXVCLEdBQVksSUFBSSxDQUFDO1FBRXhDLGVBQVUsR0FBa0IsS0FBSyxDQUFDO1FBTWhDLHFCQUFnQixHQUEwQixJQUFJLFlBQVksRUFBRSxDQUFDO1FBRXZDLG1CQUFjLEdBQVksSUFBSSxDQUFDO1FBVTNELGNBQWMsQ0FBQyxhQUFhLENBQUMsV0FBVyxDQUFDLEtBQUssQ0FBQyxDQUFDO0lBQ3BELENBQUM7SUFHRCwwQkFBUSxHQUFSLFVBQVMsTUFBYTtRQUNsQixJQUFJLENBQUMsVUFBVSxFQUFFLENBQUM7SUFDdEIsQ0FBQztJQUVELCtFQUErRTtJQUMvRSwwQkFBUSxHQUFSO1FBQ0ksdUZBQXVGO1FBQ3ZGLElBQUksQ0FBQyxtQkFBbUIsQ0FBQyxJQUFJLENBQUMsQ0FBQztRQUMvQixJQUFJLENBQUMsY0FBYyxFQUFFLENBQUM7SUFDMUIsQ0FBQztJQUVELDZCQUFXLEdBQVgsVUFBWSxjQUE2QjtRQUF6QyxpQkFrQ0M7UUFqQ0csSUFBSSxDQUFDLG1CQUFtQixDQUFDLElBQUksQ0FBQyxDQUFDO1FBQy9CLE9BQU8sQ0FBQyxHQUFHLENBQUMsMkJBQTJCLEVBQUUsY0FBYyxDQUFDLENBQUM7UUFFekQsSUFBSSxPQUFPLGNBQWMsQ0FBQyxNQUFNLEtBQUssV0FBVztZQUM1QyxDQUFDLGNBQWMsQ0FBQyxNQUFNLENBQUMsV0FBVyxFQUNwQztZQUNFLElBQUksQ0FBQyxhQUFhLENBQUMsY0FBYyxDQUFDLE1BQU0sQ0FBQyxZQUFZLENBQUMsQ0FBQztZQUN2RCxJQUFJLENBQUMsbUJBQW1CLENBQUMsS0FBSyxDQUFDLENBQUM7U0FDbkM7UUFFRCxJQUFJLE9BQU8sY0FBYyxDQUFDLEdBQUcsS0FBSyxXQUFXO1lBQ3pDLENBQUMsY0FBYyxDQUFDLEdBQUcsQ0FBQyxXQUFXLEVBQ2pDO1lBQ0UsSUFBSSxDQUFDLFdBQVcsQ0FBQyxjQUFjLENBQUMsR0FBRyxDQUFDLFlBQVksQ0FBQyxDQUFDO1lBQ2xELElBQUksQ0FBQyxtQkFBbUIsQ0FBQyxLQUFLLENBQUMsQ0FBQztTQUNuQztRQUVELElBQUksT0FBTyxjQUFjLENBQUMsTUFBTSxLQUFLLFdBQVcsRUFBRTtZQUM5QyxJQUFJLENBQUMsbUJBQW1CLENBQUMsS0FBSyxDQUFDLENBQUM7WUFDaEMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxjQUFjLENBQUMsTUFBTSxDQUFDLFlBQVksQ0FBQyxDQUFDO1lBRXJELEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FBQyxTQUFTLENBQUM7Z0JBQ2pCLEtBQUksQ0FBQyxzQkFBc0IsRUFBRSxDQUFDO2dCQUU5QixJQUFJLE9BQU8sS0FBSSxDQUFDLE1BQU0sQ0FBQyxzQkFBc0IsS0FBSyxXQUFXLEVBQzNEO29CQUNFLElBQUksS0FBSSxDQUFDLE1BQU0sQ0FBQyxzQkFBc0IsS0FBSyxLQUFJLENBQUMsdUJBQXVCO3dCQUNuRSxLQUFJLENBQUMsb0JBQW9CLENBQUMsS0FBSSxDQUFDLE1BQU0sQ0FBQyxzQkFBc0IsQ0FBQyxDQUFDO2lCQUNyRTtxQkFBTTtvQkFDSCxLQUFJLENBQUMsTUFBTSxDQUFDLHNCQUFzQixHQUFHLEtBQUksQ0FBQyx1QkFBdUIsQ0FBQztpQkFDckU7WUFDTCxDQUFDLENBQUMsQ0FBQztTQUNOO0lBQ0wsQ0FBQztJQUVELDZCQUFXLEdBQVg7UUFDSSwrQ0FBK0M7UUFDL0MsS0FBSyxJQUFJLElBQUksSUFBSSxJQUFJLENBQUMsZ0JBQWdCLEVBQUU7WUFDcEMsSUFBSSxPQUFPLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxJQUFJLENBQUMsS0FBSyxXQUFXLEVBQUU7Z0JBQ3BELElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxJQUFJLENBQUMsQ0FBQyxXQUFXLEVBQUUsQ0FBQzthQUM3QztTQUNKO0lBQ0wsQ0FBQztJQUVELCtFQUErRTtJQUN4RSw2QkFBVyxHQUFsQixVQUFtQixPQUFZO1FBQzNCLDREQUE0RDtRQUM1RCxJQUFJLENBQUMsZUFBZSxFQUFFLENBQUM7SUFHM0IsQ0FBQztJQUVNLGdDQUFjLEdBQXJCLFVBQXNCLE1BQXlCO1FBQzNDLHlFQUF5RTtRQUN6RSxJQUFJLElBQUksQ0FBQyxhQUFhLENBQUMsZUFBZSxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsRUFBRTtZQUNqRCxJQUFJLENBQUMsMkJBQTJCLEVBQUUsQ0FBQztTQUN0QztRQUVELElBQUksSUFBSSxDQUFDLGFBQWEsRUFBRTtZQUNwQixJQUFJLFdBQVcsR0FBWSxRQUFRLENBQUMsYUFBYSxDQUFDLEdBQUcsR0FBRyxJQUFJLENBQUMsTUFBTSxHQUFHLFlBQVksQ0FBQyxDQUFDO1lBRXBGLElBQUksV0FBVyxLQUFLLElBQUksRUFBRTtnQkFDdEIsSUFBSSxDQUFDLGdCQUFnQixDQUFDLFdBQVcsQ0FBQyxDQUFDO2FBQ3RDO1NBQ0o7SUFDTCxDQUFDO0lBRU0sOEJBQVksR0FBbkIsVUFBb0IsT0FBaUI7UUFDakMseURBQXlEO1FBQ3pELElBQUksSUFBSSxDQUFDLGFBQWEsQ0FBQyxPQUFPLENBQUMsS0FBSyxDQUFDLElBQUksT0FBTyxJQUFJLENBQUMsTUFBTSxDQUFDLEtBQUssS0FBSyxXQUFXLEVBQUU7WUFDL0UsUUFBUSxJQUFJLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxJQUFJLEVBQUU7Z0JBQzVCLEtBQUssV0FBVztvQkFDWixJQUFJLENBQUMsbUJBQW1CLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxDQUFDO29CQUN2QyxNQUFNO2dCQUNWLEtBQUssUUFBUTtvQkFDVCxJQUFJLENBQUMsdUJBQXVCLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxDQUFDO29CQUMzQyxNQUFNO2dCQUNWO29CQUNJLE1BQU07YUFDYjtZQUVELElBQUksT0FBTyxJQUFJLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxRQUFRLEtBQUssV0FBVyxFQUFFO2dCQUNuRCxJQUFJLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxRQUFRLEVBQUUsQ0FBQzthQUNoQztTQUNKO0lBQ0wsQ0FBQztJQUVELCtFQUErRTtJQUN4RSxpQ0FBZSxHQUF0QixVQUF1QixPQUFxQjtRQUN4QyxJQUFJLFdBQVcsR0FBdUIsSUFBSSxrQkFBa0IsQ0FBQyxPQUFPLENBQUMsQ0FBQztRQUN0RSxJQUFJLENBQUMsbUJBQW1CLENBQXFCLFFBQVEsRUFBRSxXQUFXLENBQUMsQ0FBQztJQUN4RSxDQUFDO0lBRUQsK0VBQStFO0lBQy9FLHdHQUF3RztJQUN4RyxlQUFlO0lBQ2Ysd0dBQXdHO0lBQ2hHLGdDQUFjLEdBQXRCO1FBQ0ksSUFBSSxPQUFPLElBQUksQ0FBQyxNQUFNLEtBQUssV0FBVyxFQUFFO1lBQ3BDLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLFFBQVEsQ0FBQyxDQUFDO1lBQzVDLElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUM7WUFDcEMsSUFBSSxDQUFDLGVBQWUsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUM7WUFDbEMsSUFBSSxDQUFDLHdCQUF3QixFQUFFLENBQUM7U0FDbkM7UUFFRCxJQUFJLE9BQU8sSUFBSSxDQUFDLE1BQU0sS0FBSyxXQUFXLEVBQUU7WUFDcEMsSUFBSSxDQUFDLGFBQWEsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUM7U0FDbkM7UUFFRCxJQUFJLE9BQU8sSUFBSSxDQUFDLEdBQUcsS0FBSyxXQUFXLEVBQUU7WUFDakMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUM7U0FDOUI7SUFDTCxDQUFDO0lBRU8saUNBQWUsR0FBdkI7UUFDSSxJQUFJLENBQUMsY0FBYyxFQUFFLENBQUM7UUFFdEIsSUFBSSxJQUFJLENBQUMsYUFBYSxDQUFDLGlCQUFpQixDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsUUFBUSxDQUFDLEVBQUU7WUFDNUQsSUFBSSxDQUFDLHlCQUF5QixFQUFFLENBQUM7U0FDcEM7UUFFRCxJQUFJLENBQUMsa0JBQWtCLEVBQUUsQ0FBQztJQUM5QixDQUFDO0lBRU8sMkNBQXlCLEdBQWpDO1FBQ0ksSUFBSSxDQUFDLGdCQUFnQixFQUFFLENBQUM7UUFDeEIsSUFBSSxDQUFDLDZCQUE2QixFQUFFLENBQUM7SUFDekMsQ0FBQztJQUVPLG9DQUFrQixHQUExQjtRQUNJLElBQUksQ0FBQyxvQkFBb0IsRUFBRSxDQUFDO1FBQzVCLElBQUksQ0FBQyxVQUFVLEVBQUUsQ0FBQztRQUNsQixJQUFJLENBQUMsYUFBYSxFQUFFLENBQUM7SUFDekIsQ0FBQztJQUVPLHFDQUFtQixHQUEzQixVQUE0QixRQUFpQjtRQUN6QyxJQUFJLE9BQU8sSUFBSSxDQUFDLE1BQU0sQ0FBQyxTQUFTLEtBQUssV0FBVyxFQUFFO1lBQzlDLE9BQU8sQ0FBQyxLQUFLLENBQUMsd0hBQXdILENBQUMsQ0FBQztTQUMzSTthQUNJLElBQUksSUFBSSxDQUFDLE1BQU0sQ0FBQyxTQUFTLENBQUMsSUFBSSxLQUFLLFFBQVEsRUFBRTtZQUM5QyxJQUFJLElBQUksQ0FBQyxNQUFNLENBQUMsU0FBUyxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsUUFBUSxDQUFDLEVBQUUsQ0FBQyxHQUFHLENBQUMsRUFBRTtnQkFDdEQsSUFBSSxDQUFDLFdBQVcsQ0FBQyxHQUFHLENBQUMsV0FBVyxFQUFFLENBQUM7Z0JBQ25DLFFBQVEsQ0FBQyxjQUFjLENBQUMsSUFBSSxDQUFDLENBQUM7Z0JBRTlCLElBQUksQ0FBQyxNQUFNLENBQUMsU0FBUyxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsQ0FBQyxFQUFFLElBQUksQ0FBQyxNQUFNLENBQUMsU0FBUyxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsQ0FBQztnQkFDMUUsSUFBSSxDQUFDLE1BQU0sQ0FBQyxTQUFTLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxDQUFDO2dCQUVuRCxJQUFJLENBQUMsMkJBQTJCLEVBQUUsQ0FBQztnQkFDbkMsSUFBSSxDQUFDLHFCQUFxQixDQUFDLFFBQVEsQ0FBQyxDQUFDO2FBQ3hDO1NBQ0o7YUFDSTtZQUNELElBQUksU0FBUyxHQUFZLENBQUMsUUFBUSxDQUFDLFVBQVUsRUFBRSxDQUFDO1lBQ2hELFFBQVEsQ0FBQyxjQUFjLENBQUMsU0FBUyxDQUFDLENBQUM7WUFFbkMsSUFBSSxDQUFDLDJCQUEyQixFQUFFLENBQUM7WUFFbkMsSUFBSSxTQUFTLEVBQUU7Z0JBQ1gsSUFBSSxDQUFDLE1BQU0sQ0FBQyxTQUFTLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxDQUFDO2FBQ3REO2lCQUNJO2dCQUNELElBQUksQ0FBQyxNQUFNLENBQUMsU0FBUyxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxTQUFTLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDO2FBQ2hHO1lBRUQsSUFBSSxDQUFDLHFCQUFxQixDQUFDLFFBQVEsQ0FBQyxDQUFDO1NBQ3hDO0lBQ0wsQ0FBQztJQUVPLGtDQUFnQixHQUF4QjtRQUNJLElBQUksT0FBTyxJQUFJLENBQUMsTUFBTSxDQUFDLFNBQVMsS0FBSyxXQUFXLElBQUksT0FBTyxJQUFJLENBQUMsTUFBTSxDQUFDLFNBQVMsQ0FBQyxJQUFJLEtBQUssV0FBVyxFQUFFO1lBQ25HLElBQUksQ0FBQyx3QkFBd0IsRUFBRSxDQUFDO1NBQ25DO2FBRUksSUFBSSxJQUFJLENBQUMsYUFBYSxDQUFDLFlBQVksQ0FBQyxJQUFJLENBQUMsTUFBTSxFQUFFLE9BQU8sQ0FBQyxFQUFFO1lBQzVELElBQUksQ0FBQyxxQkFBcUIsRUFBRSxDQUFDO1NBQ2hDO0lBQ0wsQ0FBQztJQUVPLHlDQUF1QixHQUEvQixVQUFnQyxRQUFpQjtRQUM3QyxJQUFJLE9BQU8sSUFBSSxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsT0FBTyxLQUFLLFdBQVcsRUFBRTtZQUNsRCxJQUFJLE9BQU8sSUFBSSxDQUFDLE1BQU0sQ0FBQyxNQUFNLEtBQUssV0FBVztnQkFDekMsT0FBTyxJQUFJLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxJQUFJLEtBQUssV0FBVyxFQUFFO2dCQUNoRCxJQUFJLFVBQVUsR0FBVyxFQUFFLENBQUM7Z0JBRTVCLEtBQUssSUFBSSxDQUFDLEdBQVcsQ0FBQyxFQUFFLENBQUMsR0FBRyxJQUFJLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsTUFBTSxFQUFFLEVBQUUsQ0FBQyxFQUFFO29CQUM3RCxJQUFJLFVBQVUsR0FBeUIsSUFBSSxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDO29CQUVsRSxJQUFJLFVBQVUsQ0FBQyxJQUFJLENBQUMsV0FBVyxFQUFFLEtBQUssSUFBSSxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLFdBQVcsRUFBRSxFQUFFO3dCQUMzRSxVQUFVLEdBQUcsSUFBSSxDQUFDLGFBQWEsQ0FBQyx3QkFBd0IsQ0FBQyxRQUFRLEVBQUUsVUFBVSxDQUFDLElBQUksQ0FBQyxDQUFDO3dCQUNwRixNQUFNO3FCQUNUO2lCQUNKO2dCQUVELElBQUksVUFBVSxLQUFLLEVBQUUsRUFBRTtvQkFDbkIsSUFBSSxDQUFDLE9BQU8sQ0FBQyxRQUFRLENBQUMsQ0FBQyxVQUFVLENBQUMsQ0FBQyxDQUFDO2lCQUN2QztxQkFDSTtvQkFDRCxPQUFPLENBQUMsSUFBSSxDQUFDLGtFQUFrRSxFQUFFLElBQUksQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxDQUFDO2lCQUMvRzthQUNKO2lCQUNJO2dCQUNELE9BQU8sQ0FBQyxLQUFLLENBQUMsOElBQThJLENBQUMsQ0FBQzthQUNqSztTQUVKO2FBQ0ksSUFBSSxPQUFPLElBQUksQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLElBQUksS0FBSyxXQUFXLEVBQUU7WUFDcEQsSUFBSSxDQUFDLE9BQU8sQ0FBQyxRQUFRLENBQUMsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDO1NBQ25EO2FBQ0k7WUFDRCxPQUFPLENBQUMsS0FBSyxDQUFDLGlJQUFpSSxDQUFDLENBQUM7U0FDcEo7SUFDTCxDQUFDO0lBRUQsd0dBQXdHO0lBQ3hHLHlCQUF5QjtJQUN6Qix3R0FBd0c7SUFFaEcscUNBQW1CLEdBQTNCLFVBQTRCLE9BQWdCO1FBQ3hDLElBQUksQ0FBQyxjQUFjLEdBQUcsT0FBTyxDQUFDO0lBQ2xDLENBQUM7SUFFTyxzQ0FBb0IsR0FBNUI7UUFDSSxJQUFJLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxhQUFhLENBQUMsVUFBVSxDQUFDLFNBQVMsSUFBSSxhQUFhLENBQUM7UUFDdEUsSUFBSSxJQUFJLENBQUMsVUFBVSxLQUFLLEtBQUs7WUFBRSxRQUFRLENBQUMsYUFBYSxDQUFDLE1BQU0sQ0FBQyxDQUFDLEtBQUssQ0FBQyxPQUFPLElBQUkscUNBQXFDLENBQUM7SUFDekgsQ0FBQztJQUVPLDRCQUFVLEdBQWxCO1FBQ0ksSUFBSSxXQUFXLEdBQVcsR0FBRyxHQUFHLElBQUksQ0FBQyxNQUFNLEdBQUcsWUFBWSxDQUFDO1FBQzNELElBQUksV0FBVyxHQUFZLElBQUksQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLGFBQWEsQ0FBQyxhQUFhLENBQUMsV0FBVyxDQUFDLENBQUM7UUFFdEYsSUFBSSxXQUFXLEtBQUssSUFBSSxFQUFFO1lBQ3RCLElBQUksWUFBWSxHQUFXLFFBQVEsQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFDO1lBRXJELElBQUksWUFBWSxJQUFJLElBQUksRUFBRTtnQkFDdEIsSUFBSSxPQUFPLElBQUksQ0FBQyxhQUFhLEtBQUssV0FBVyxJQUFJLENBQUMsSUFBSSxDQUFDLGFBQWEsRUFBRTtvQkFDbEUsSUFBSSxDQUFDLG1CQUFtQixDQUFDLElBQUksQ0FBQyxDQUFDO29CQUMvQixJQUFJLENBQUMsYUFBYSxHQUFHLElBQUksQ0FBQztvQkFDMUIsSUFBSSxDQUFDLGdCQUFnQixDQUFDLFdBQVcsQ0FBQyxDQUFDO2lCQUN0QzthQUNKO2lCQUNJLElBQUksWUFBWSxHQUFHLElBQUksRUFBRTtnQkFDMUIsSUFBSSxPQUFPLElBQUksQ0FBQyxhQUFhLEtBQUssV0FBVyxJQUFJLElBQUksQ0FBQyxhQUFhLEVBQUU7b0JBQ2pFLElBQUksQ0FBQyxtQkFBbUIsQ0FBQyxJQUFJLENBQUMsQ0FBQztvQkFDL0IsSUFBSSxDQUFDLGFBQWEsR0FBRyxLQUFLLENBQUM7b0JBQzNCLElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxXQUFXLEVBQUUsSUFBSSxDQUFDLE1BQU0sQ0FBQyxVQUFVLENBQUMsQ0FBQztpQkFDL0Q7cUJBQ0k7b0JBQ0QsSUFBSSxDQUFDLFdBQVcsQ0FBQyxHQUFHLENBQUMsZ0JBQWdCLEVBQUUsQ0FBQztpQkFDM0M7YUFDSjtTQUNKO0lBQ0wsQ0FBQztJQUVEOzs7T0FHRztJQUNLLHVDQUFxQixHQUE3QjtRQUNJLElBQUksaUJBQWlCLEdBQVcscUJBQXFCLENBQUM7UUFDdEQsSUFBSSxZQUFZLEdBQVksSUFBSSxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsYUFBYSxDQUFDLGFBQWEsQ0FBQyxpQkFBaUIsQ0FBQyxDQUFDO1FBQzdGLElBQUksWUFBWSxLQUFLLElBQUk7WUFBRSxPQUFPO1FBRWxDLElBQUksZ0JBQWdCLEdBQVcsb0JBQW9CLENBQUM7UUFDcEQsSUFBSSxXQUFXLEdBQVksSUFBSSxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsYUFBYSxDQUFDLGFBQWEsQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDO1FBRTNGLElBQUksWUFBWSxDQUFDLFlBQVksR0FBRyxXQUFXLENBQUMsWUFBWTtZQUNwRCxXQUFXLENBQUMsU0FBUztZQUNyQixXQUFXLENBQUMsU0FBUyxDQUFDLE9BQU8sQ0FBQyxtQkFBbUIsQ0FBQyxLQUFLLENBQUMsQ0FBQyxFQUMzRDtZQUNFLFdBQVcsQ0FBQyxTQUFTLElBQUksb0JBQW9CLENBQUM7U0FDakQ7YUFBTSxJQUFJLFlBQVksQ0FBQyxZQUFZLEdBQUcsV0FBVyxDQUFDLFlBQVksRUFBRTtZQUM3RCxXQUFXLENBQUMsU0FBUyxHQUFHLFdBQVcsQ0FBQyxTQUFTLENBQUMsT0FBTyxDQUFDLHFCQUFxQixFQUFFLEVBQUUsQ0FBQyxDQUFDO1NBQ3BGO0lBQ0wsQ0FBQztJQUVPLGtDQUFnQixHQUF4QixVQUF5QixZQUFxQjtRQUE5QyxpQkFnQ0M7UUEvQkcsSUFBSSxTQUFTLEdBQVcsQ0FBQyxDQUFDO1FBRTFCLElBQUksSUFBSSxDQUFDLE1BQU0sQ0FBQyxRQUFRLEtBQUssVUFBVSxFQUFFO1lBQ3JDLElBQUksV0FBVyxHQUFZLElBQUksQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLGFBQWEsQ0FBQyxhQUFhLENBQUMsWUFBWSxDQUFDLENBQUM7WUFDdkYsSUFBSSxTQUFTLEdBQVksSUFBSSxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsYUFBYSxDQUFDLGFBQWEsQ0FBQyxvQkFBb0IsQ0FBQyxDQUFDO1lBQzdGLElBQUksY0FBYyxHQUFZLElBQUksQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLGFBQWEsQ0FBQyxhQUFhLENBQUMsa0JBQWtCLENBQUMsQ0FBQztZQUNoRyxTQUFTLEdBQUcsRUFBRSxDQUFDO1lBRWYsSUFBSSxXQUFXLEtBQUssSUFBSSxFQUFFO2dCQUN0QixTQUFTLElBQUksV0FBVyxDQUFDLFlBQVksQ0FBQzthQUN6QztZQUVELElBQUksU0FBUyxLQUFLLElBQUksRUFBRTtnQkFDcEIsU0FBUyxJQUFJLFNBQVMsQ0FBQyxZQUFZLENBQUM7YUFDdkM7WUFFRCxJQUFJLGNBQWMsS0FBSyxJQUFJLEVBQUU7Z0JBQ3pCLFNBQVMsSUFBSSxjQUFjLENBQUMsWUFBWSxDQUFDO2FBQzVDO1NBQ0o7YUFDSTtZQUNELFNBQVMsR0FBRyxHQUFHLENBQUM7U0FDbkI7UUFHRCxJQUFJLENBQUMsT0FBTyxDQUFDLGVBQWUsQ0FBQyxZQUFZLEVBQUUsUUFBUSxFQUFFLFNBQVMsR0FBRyxJQUFJLENBQUMsQ0FBQztRQUV2RSxLQUFLLENBQUMsRUFBRSxDQUFDLENBQUMsU0FBUyxDQUFDO1lBQ2hCLEtBQUksQ0FBQyxXQUFXLENBQUMsR0FBRyxDQUFDLGdCQUFnQixFQUFFLENBQUM7WUFDeEMsS0FBSSxDQUFDLG1CQUFtQixDQUFDLEtBQUssQ0FBQyxDQUFDO1FBQ3BDLENBQUMsQ0FBQyxDQUFDO0lBQ1AsQ0FBQztJQUVEOzs7T0FHRztJQUNLLG1DQUFpQixHQUF6QixVQUEwQixZQUFxQixFQUFFLGFBQThCO1FBQS9FLGlCQXVCQztRQXRCRyxJQUFJLE9BQU8sYUFBYSxLQUFLLFFBQVEsRUFBRTtZQUNuQyxJQUFJLFVBQVUsR0FBVyxHQUFHLENBQUM7WUFFN0IsSUFBSSxPQUFPLGFBQWEsS0FBSyxXQUFXLEVBQUU7Z0JBQ3RDLFVBQVUsR0FBRyxhQUFhLENBQUM7YUFDOUI7WUFFRCxJQUFJLENBQUMsT0FBTyxDQUFDLGVBQWUsQ0FBQyxZQUFZLEVBQUUsUUFBUSxFQUFFLFVBQVUsR0FBRyxJQUFJLENBQUMsQ0FBQztTQUMzRTthQUNJLElBQUksYUFBYSxLQUFLLE1BQU0sRUFBRTtZQUMvQixJQUFJLENBQUMsV0FBVyxHQUFHLElBQUksQ0FBQztTQUMzQjtRQUNELDRDQUE0QztRQUM1QyxpREFBaUQ7UUFDakQseUNBQXlDO1FBQ3pDLDRDQUE0QztRQUM1QyxJQUFJO1FBRUosS0FBSyxFQUFFLENBQUMsU0FBUyxDQUFDO1lBQ2QsS0FBSSxDQUFDLFdBQVcsQ0FBQyxHQUFHLENBQUMsZ0JBQWdCLEVBQUUsQ0FBQztZQUN4QyxLQUFJLENBQUMsbUJBQW1CLENBQUMsS0FBSyxDQUFDLENBQUM7UUFDcEMsQ0FBQyxDQUFDLENBQUM7SUFDUCxDQUFDO0lBRU8sK0JBQWEsR0FBckIsVUFBc0IsTUFBYTtRQUMvQixJQUFJLGFBQWEsR0FBNkIsTUFBTSxDQUFDLE1BQU0sQ0FBQztRQUM1RCxJQUFJLFdBQVcsR0FBa0IsQ0FBQyxZQUFZLEVBQUUsc0JBQXNCLEVBQUUsaUJBQWlCLENBQUMsQ0FBQztRQUUzRixLQUFLLElBQUksQ0FBQyxHQUFXLENBQUMsRUFBRSxDQUFDLEdBQUcsV0FBVyxDQUFDLE1BQU0sRUFBRSxDQUFDLEVBQUUsRUFBRTtZQUNqRCxJQUFJLGFBQWEsQ0FBQyxTQUFTLENBQUMsUUFBUSxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFO2dCQUNsRCxPQUFPLEtBQUssQ0FBQzthQUNoQjtTQUNKO1FBRUQsT0FBTyxJQUFJLENBQUM7SUFDaEIsQ0FBQztJQUVPLCtCQUFhLEdBQXJCLFVBQXNCLGtCQUFtQztRQUF6RCxpQkFRQztRQVJxQixtQ0FBQSxFQUFBLDBCQUFtQztRQUNyRCxJQUFJLElBQUksQ0FBQyxhQUFhLENBQUMsVUFBVSxDQUFDLElBQUksQ0FBQyxXQUFXLENBQUMsRUFBRTtZQUNqRCxLQUFLLENBQUMsRUFBRSxDQUFDLENBQUMsU0FBUyxDQUFDO2dCQUNoQixDQUFDLGtCQUFrQixDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUksQ0FBQyxzQkFBc0IsRUFBRSxDQUFDLENBQUMsQ0FBQyxLQUFJLENBQUMsV0FBVyxDQUFDLEdBQUcsQ0FBQyxnQkFBZ0IsRUFBRSxDQUFDO2dCQUMvRixLQUFJLENBQUMsZ0JBQWdCLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDO2dCQUNqQyxLQUFJLENBQUMsbUJBQW1CLENBQUMsS0FBSyxDQUFDLENBQUM7WUFDcEMsQ0FBQyxDQUFDLENBQUM7U0FDTjtJQUNMLENBQUM7SUFFRDs7T0FFRztJQUNLLHdDQUFzQixHQUE5QjtRQUNJLElBQUksWUFBWSxHQUFrQixFQUFFLENBQUM7UUFDckMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxTQUFTLENBQUMsc0JBQXNCLEVBQUUsQ0FBQyxPQUFPLENBQUMsVUFBQyxNQUFjO1lBQ3ZFLFlBQVksQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLFFBQVEsRUFBRSxDQUFDLENBQUM7UUFDekMsQ0FBQyxDQUFDLENBQUM7UUFDSCxJQUFJLENBQUMsV0FBVyxDQUFDLFNBQVMsQ0FBQyxlQUFlLENBQUMsWUFBWSxDQUFDLENBQUM7SUFDN0QsQ0FBQztJQUVEOzs7T0FHRztJQUNJLDZCQUFXLEdBQWxCLFVBQW1CLE9BQXFCO1FBQ3BDLElBQUksQ0FBQyxPQUFPLElBQUksQ0FBQyxPQUFPLENBQUMsTUFBTSxFQUFFO1lBQzdCLFFBQVEsQ0FBQyxhQUFhLENBQUMsTUFBTSxDQUFDLENBQUMsS0FBSyxDQUFDLE9BQU8sR0FBRyxFQUFFLENBQUM7WUFDbEQsT0FBTztTQUNWO1FBQ0QsSUFBSSxNQUFNLEdBQW1CLE9BQU8sQ0FBQyxNQUFNLENBQUM7UUFFNUMsSUFBSSxPQUFPLEdBQVcsRUFBRSxDQUFDO1FBRXpCLE9BQU8sSUFBSSxJQUFJLENBQUMsa0JBQWtCLENBQUMsTUFBTSxDQUFDLENBQUM7UUFFM0MsSUFBSSxNQUFNLENBQUMsSUFBSSxFQUFFO1lBQ2IsSUFBSSxNQUFNLENBQUMsSUFBSSxDQUFDLFlBQVksS0FBSyxJQUFJLEVBQUU7Z0JBQ25DLElBQUksTUFBTSxDQUFDLElBQUksQ0FBQyxHQUFHLElBQUksTUFBTSxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsZUFBZSxFQUFFO29CQUNwRCxPQUFPLElBQUksZ0NBQWdDLEdBQUcsTUFBTSxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsZUFBZSxHQUFHLEdBQUcsQ0FBQztpQkFDdkY7Z0JBQ0QsSUFBSSxNQUFNLENBQUMsSUFBSSxDQUFDLElBQUksSUFBSSxNQUFNLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxlQUFlLEVBQUU7b0JBQ3RELE9BQU8sSUFBSSxpQ0FBaUMsR0FBRyxNQUFNLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxlQUFlLEdBQUcsR0FBRyxDQUFDO2lCQUN6RjthQUNKO1lBQ0QsSUFBSSxNQUFNLENBQUMsSUFBSSxDQUFDLEtBQUssRUFBRTtnQkFDbkIsSUFBSSxNQUFNLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxXQUFXLEVBQUU7b0JBQy9CLE9BQU8sSUFBSSwrQkFBK0IsR0FBRyxNQUFNLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxXQUFXLEdBQUcsR0FBRyxDQUFDO29CQUNqRixPQUFPLElBQUksaUNBQWlDLEdBQUcsTUFBTSxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsV0FBVyxHQUFHLEdBQUcsQ0FBQztpQkFDdEY7Z0JBQ0QsSUFBSSxNQUFNLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxXQUFXLEVBQUU7b0JBQy9CLE9BQU8sSUFBSSwrQkFBK0IsR0FBRyxNQUFNLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxXQUFXLEdBQUcsR0FBRyxDQUFDO29CQUNqRixPQUFPLElBQUksaUNBQWlDLEdBQUcsTUFBTSxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsV0FBVyxHQUFHLEdBQUcsQ0FBQztpQkFDdEY7Z0JBQ0QsSUFBSSxNQUFNLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxXQUFXLEVBQUU7b0JBQy9CLE9BQU8sSUFBSSwrQkFBK0IsR0FBRyxNQUFNLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxXQUFXLEdBQUcsR0FBRyxDQUFDO29CQUNqRixPQUFPLElBQUksaUNBQWlDLEdBQUcsTUFBTSxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsV0FBVyxHQUFHLEdBQUcsQ0FBQztpQkFDdEY7YUFDSjtTQUNKO1FBRUQsUUFBUSxDQUFDLGFBQWEsQ0FBQyxNQUFNLENBQUMsQ0FBQyxLQUFLLENBQUMsT0FBTyxHQUFHLE9BQU8sQ0FBQztJQUMzRCxDQUFDO0lBRU8sb0NBQWtCLEdBQTFCLFVBQTJCLE9BQXVCO1FBQzlDLElBQUksQ0FBQyxPQUFPLENBQUMsTUFBTSxJQUFJLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxLQUFLO1lBQUUsT0FBTyxFQUFFLENBQUM7UUFFeEQsSUFBSSxPQUFPLEdBQVcsRUFBRSxDQUFDO1FBQ3pCLElBQUksVUFBVSxHQUFrQjtZQUM1QixpQkFBaUI7WUFDakIsV0FBVztZQUNYLGVBQWU7WUFDZixPQUFPO1lBQ1AsWUFBWTtZQUNaLFVBQVU7WUFDVixZQUFZO1lBQ1osV0FBVztZQUNYLGdCQUFnQjtZQUNoQixpQkFBaUI7WUFDakIsaUJBQWlCO1lBQ2pCLGlCQUFpQjtZQUNqQixTQUFTO1NBQ1osQ0FBQztRQUNGLEtBQUssSUFBSSxDQUFDLEdBQVcsQ0FBQyxFQUFFLENBQUMsR0FBRyxVQUFVLENBQUMsTUFBTSxFQUFFLEVBQUUsQ0FBQyxFQUFFO1lBQ2hELElBQUksU0FBUyxHQUFXLFVBQVUsQ0FBQyxDQUFDLENBQUMsQ0FBQztZQUN0QyxJQUFJLEtBQUssR0FBVyxPQUFPLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxTQUFTLENBQUMsQ0FBQztZQUNwRCxJQUFJLFNBQVMsS0FBSyxlQUFlO2dCQUFFLEtBQUssR0FBRyxJQUFJLENBQUMsYUFBYSxDQUFDLEtBQUssQ0FBQyxDQUFDO1lBQ3JFLFNBQVMsR0FBRyxDQUFDLFNBQVMsS0FBSyxpQkFBaUIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxZQUFZLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxPQUFPLENBQUMsaUJBQWlCLEVBQUUsT0FBTyxDQUFDLENBQUMsV0FBVyxFQUFFLENBQUM7WUFDM0gsSUFBSSxPQUFPLEtBQUssS0FBSyxXQUFXLEVBQUU7Z0JBQzlCLElBQUksU0FBUyxLQUFLLGFBQWE7b0JBQzNCLENBQUMsT0FBTyxLQUFLLEtBQUssUUFBUSxJQUFJLEtBQUssQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUM7b0JBQzNELEtBQUssSUFBSSxJQUFJLENBQUM7Z0JBQ2hCLE9BQU8sSUFBSSxtQkFBbUIsR0FBRyxTQUFTLEdBQUcsSUFBSSxHQUFHLEtBQUssR0FBRyxHQUFHLENBQUM7YUFDbkU7U0FDSjtRQUNELE9BQU8sT0FBTyxDQUFDO0lBQ25CLENBQUM7SUFFRDs7O09BR0c7SUFDSywrQkFBYSxHQUFyQixVQUFzQixjQUFzQjtRQUN4QyxJQUFJLGNBQWMsS0FBSyxVQUFVLElBQUksY0FBYyxLQUFLLFFBQVEsRUFBRTtZQUM5RCxPQUFPLFVBQVUsQ0FBQztTQUNyQjthQUFNLElBQUksY0FBYyxLQUFLLEtBQUssRUFBRTtZQUNqQyxPQUFPLFlBQVksQ0FBQztTQUN2QjthQUFNLEVBQUUsMEJBQTBCO1lBQy9CLElBQUksY0FBYyxLQUFLLFFBQVEsSUFBSSxjQUFjLEtBQUssU0FBUyxFQUFFO2dCQUM3RCxPQUFPLENBQUMsSUFBSSxDQUFDLHFDQUFxQyxHQUFHLGNBQWMsR0FBRyxpRkFBaUYsQ0FBQyxDQUFDO2FBQzVKO1lBQ0QsT0FBTyxRQUFRLENBQUM7U0FDbkI7SUFDTCxDQUFDO0lBRUQscUVBQXFFO0lBQ3JFLG9IQUFvSDtJQUNwSCxpREFBaUQ7SUFDakQsZ0RBQWdEO0lBRWhELG1DQUFtQztJQUNuQyx3RkFBd0Y7SUFDeEYsd0RBQXdEO0lBQ3hELGtCQUFrQjtJQUNsQixZQUFZO0lBRVosMEVBQTBFO0lBQzFFLHNIQUFzSDtJQUN0SCxpRkFBaUY7SUFDakYsK0NBQStDO0lBQy9DLHVCQUF1QjtJQUN2QiwrQ0FBK0M7SUFDL0MsZ0JBQWdCO0lBQ2hCLGNBQWM7SUFFZCxtRkFBbUY7SUFDbkYsc0NBQXNDO0lBQ3RDLG9GQUFvRjtJQUNwRixhQUFhO0lBRWIsNERBQTREO0lBQzVELFFBQVE7SUFDUixJQUFJO0lBRUosd0dBQXdHO0lBQ3hHLGtCQUFrQjtJQUNsQix3R0FBd0c7SUFDaEcseUNBQXVCLEdBQS9CO1FBQ0ksSUFBSSxhQUFhLEdBQVksSUFBSSxDQUFDO1FBQ2xDLElBQUksSUFBSSxDQUFDLHNCQUFzQixFQUFFO1lBQzdCLElBQUksU0FBUyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsRUFBRTtnQkFDeEIsYUFBYSxHQUFHLElBQUksQ0FBQyxzQkFBc0IsS0FBSyxJQUFJLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDO2FBQ3BGO1NBQ0o7YUFBTTtZQUNILElBQUksU0FBUyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsRUFBRTtnQkFDeEIsSUFBSSxDQUFDLHNCQUFzQixHQUFHLElBQUksQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUM7YUFDbEU7U0FDSjtRQUNELE9BQU8sYUFBYSxDQUFDO1FBRXJCLFNBQVMsU0FBUyxDQUFDLE9BQU87WUFDdEIsT0FBTyxPQUFPLElBQUksT0FBTyxDQUFDLEtBQUssSUFBSSxPQUFPLENBQUMsS0FBSyxDQUFDLFNBQVMsSUFBSSxPQUFPLENBQUMsS0FBSyxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUE7UUFDOUYsQ0FBQztJQUNMLENBQUM7SUFFTyx3Q0FBc0IsR0FBOUI7UUFDSSxJQUFJLGNBQWMsR0FBWSxJQUFJLENBQUM7UUFDbkMsSUFBSSxJQUFJLENBQUMsTUFBTSxJQUFJLElBQUksQ0FBQyxNQUFNLENBQUMsS0FBSyxJQUFJLElBQUksQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLEtBQUssSUFBSSxJQUFJLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsV0FBVyxFQUFFO1lBQ3BHLGNBQWMsR0FBRyxJQUFJLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsV0FBVyxDQUFDLE1BQU0sS0FBSyxJQUFJLENBQUMsYUFBYSxDQUFDLFdBQVcsQ0FBQyxNQUFNLENBQUM7U0FDekc7UUFDRCxJQUFJLElBQUksQ0FBQyxNQUFNLENBQUMsUUFBUSxLQUFLLFFBQVEsSUFBSSxDQUFDLElBQUksQ0FBQyx1QkFBdUIsRUFBRSxLQUFLLEtBQUssSUFBSSxjQUFjLEtBQUssS0FBSyxDQUFDO1lBQUUsT0FBTztRQUV4SCxJQUFJLGFBQWEsR0FBWSxLQUFLLENBQUM7UUFDbkMsSUFBSSxhQUFhLEdBQVksS0FBSyxDQUFDO1FBQ25DLElBQUksSUFBSSxDQUFDLE1BQU0sQ0FBQyxLQUFLLElBQUksSUFBSSxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsU0FBUyxFQUFFO1lBQ2xELGFBQWEsR0FBRyxJQUFJLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxTQUFTLENBQUMsSUFBSSxLQUFLLE1BQU0sQ0FBQztZQUM1RCxhQUFhLEdBQUcsSUFBSSxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsU0FBUyxDQUFDLElBQUksS0FBSyxPQUFPLENBQUM7U0FDaEU7UUFDRCxJQUFJLENBQUMsY0FBYyxDQUFDLGFBQWEsQ0FBQyxDQUFDO1FBQ25DLElBQUksQ0FBQyxjQUFjLENBQUMsYUFBYSxDQUFDLENBQUM7SUFDdkMsQ0FBQztJQUVEOztPQUVHO0lBQ0ssOEJBQVksR0FBcEI7UUFDSSxJQUFJLFNBQVMsR0FBWSxJQUFJLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxhQUFhLENBQUMsYUFBYSxDQUFDLHNCQUFzQixDQUFDLENBQUM7UUFDL0YsSUFBSSxNQUFNLEdBQVksSUFBSSxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsYUFBYSxDQUFDLGFBQWEsQ0FBQyxxQ0FBcUMsQ0FBQyxDQUFDO1FBRTNHLElBQUksQ0FBQyxhQUFhLENBQUMsTUFBTSxDQUFDLHFCQUFxQixFQUFFLENBQUMsS0FBSyxHQUFHLFNBQVMsQ0FBQyxxQkFBcUIsRUFBRSxDQUFDLEtBQUssQ0FBQyxDQUFDO0lBQ3ZHLENBQUM7SUFFTyxtQ0FBaUIsR0FBekI7UUFDSSxJQUFJLENBQUMsV0FBVyxDQUFDLFNBQVMsQ0FBQyxrQkFBa0IsQ0FBQyxFQUFFLENBQUMsQ0FBQztRQUNsRCxJQUFJLENBQUMsV0FBVyxDQUFDLFNBQVMsQ0FBQyxlQUFlLENBQUMsRUFBRSxDQUFDLENBQUM7UUFDL0MsSUFBSSxDQUFDLFdBQVcsQ0FBQyxTQUFTLENBQUMsZUFBZSxDQUFDLEVBQUUsQ0FBQyxDQUFDO1FBQy9DLElBQUksQ0FBQyxXQUFXLENBQUMsU0FBUyxDQUFDLG1CQUFtQixDQUFDLEVBQUUsQ0FBQyxDQUFDO0lBQ3ZELENBQUM7SUFFRDs7OztPQUlHO0lBQ0ssZ0NBQWMsR0FBdEI7UUFBQSxpQkFZQztRQVhHLDBGQUEwRjtRQUMxRixJQUFJLFFBQVEsR0FBRztZQUNYLEtBQUksQ0FBQyxhQUFhLENBQUMsV0FBVyxHQUFHLEtBQUksQ0FBQyxXQUFXLENBQUMsU0FBUyxDQUFDLGNBQWMsRUFBRSxDQUFDO1lBQzdFLEtBQUksQ0FBQyxhQUFhLENBQUMsU0FBUyxHQUFHLEtBQUksQ0FBQyxXQUFXLENBQUMsU0FBUyxDQUFDLFdBQVcsRUFBRSxDQUFDO1lBQ3hFLEtBQUksQ0FBQyxhQUFhLENBQUMsVUFBVSxHQUFHLEtBQUksQ0FBQyxXQUFXLENBQUMsU0FBUyxDQUFDLG1CQUFtQixFQUFFLENBQUM7WUFDakYsT0FBTyxLQUFJLENBQUMsYUFBYSxDQUFDO1FBQzlCLENBQUMsQ0FBQztRQUNGLElBQUksS0FBSyxHQUFHO1lBQ1IsT0FBTyxLQUFJLENBQUMsZ0JBQWdCLEtBQUssS0FBSyxDQUFDO1FBQzNDLENBQUMsQ0FBQztRQUNGLE9BQU8sSUFBSSxDQUFDLElBQUksQ0FBQyxLQUFLLEVBQUUsUUFBUSxDQUFDLENBQUM7SUFDdEMsQ0FBQztJQUVEOzs7O09BSUc7SUFDSyxnQ0FBYyxHQUF0QixVQUF1QixNQUF3QjtRQUEvQyxpQkF5QkM7UUF4QkcsSUFBSSxPQUFPLENBQUMsTUFBTSxDQUFDLEtBQUssV0FBVyxJQUFJLENBQUMsTUFBTSxDQUFDLGNBQWMsQ0FBQyxhQUFhLENBQUM7WUFBRSxPQUFPO1FBRXJGLElBQUksUUFBUSxHQUFHO1lBQ1gsS0FBSSxDQUFDLGdCQUFnQixHQUFHLElBQUksQ0FBQztZQUM3QixJQUFJLE1BQU0sQ0FBQyxXQUFXLENBQUMsTUFBTSxLQUFLLENBQUMsRUFBRTtnQkFDakMsS0FBSSxDQUFDLGdCQUFnQixHQUFHLEtBQUssQ0FBQztnQkFDOUIsS0FBSSxDQUFDLFlBQVksRUFBRSxDQUFDO2dCQUNwQixPQUFPO2FBQ1Y7WUFDRCxLQUFJLENBQUMsYUFBYSxHQUFHLE1BQU0sQ0FBQyxNQUFNLENBQUMsS0FBSSxDQUFDLGFBQWEsRUFBRSxNQUFNLENBQUMsQ0FBQztZQUMvRCxLQUFJLENBQUMsV0FBVyxDQUFDLFNBQVMsQ0FBQyxjQUFjLENBQUMsTUFBTSxDQUFDLFdBQVcsQ0FBQyxDQUFDO1lBQzlELEtBQUksQ0FBQyxXQUFXLENBQUMsU0FBUyxDQUFDLFlBQVksQ0FBQyxNQUFNLENBQUMsU0FBUyxJQUFJLEtBQUssQ0FBQyxDQUFDO1lBQ25FLEtBQUksQ0FBQyxXQUFXLENBQUMsU0FBUyxDQUFDLG1CQUFtQixDQUFDLE1BQU0sQ0FBQyxVQUFVLElBQUksRUFBRSxDQUFDLENBQUM7WUFDeEUsS0FBSSxDQUFDLGdCQUFnQixHQUFHLEtBQUssQ0FBQztZQUU5QixLQUFLLENBQUMsR0FBRyxDQUFDLENBQUMsU0FBUyxDQUFDO2dCQUNqQixLQUFJLENBQUMsZ0JBQWdCLEVBQUUsQ0FBQztnQkFDeEIsS0FBSSxDQUFDLFlBQVksRUFBRSxDQUFDO1lBQ3hCLENBQUMsQ0FBQyxDQUFDO1FBQ1AsQ0FBQyxDQUFDO1FBQ0YsSUFBSSxLQUFLLEdBQUc7WUFDUixPQUFPLEtBQUksQ0FBQyxNQUFNLElBQUksS0FBSSxDQUFDLE1BQU0sQ0FBQyxNQUFNLEdBQUcsQ0FBQyxDQUFDO1FBQ2pELENBQUMsQ0FBQztRQUNGLElBQUksQ0FBQyxJQUFJLENBQUMsS0FBSyxFQUFFLFFBQVEsQ0FBQyxDQUFDO0lBQy9CLENBQUM7SUFFRDs7OztPQUlHO0lBQ0ssc0JBQUksR0FBWixVQUFhLE1BQWdCLEVBQUUsR0FBYSxFQUFFLGFBQWlCO1FBQS9ELGlCQVVDO1FBVjZDLDhCQUFBLEVBQUEsaUJBQWlCO1FBQzNELElBQUksQ0FBQyxNQUFNLEVBQUUsSUFBSSxJQUFJLENBQUMsYUFBYSxDQUFDLFVBQVUsQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFDLENBQUMsSUFBSSxhQUFhLEtBQUssR0FBRyxFQUFFO1lBQ3hGLElBQUksYUFBYSxLQUFLLEdBQUc7Z0JBQUUsT0FBTyxDQUFDLEdBQUcsQ0FBQywrQkFBK0IsRUFBRSxHQUFHLENBQUMsQ0FBQztZQUM3RSxPQUFPLEdBQUcsRUFBRSxDQUFDO1NBQ2hCO2FBQU07WUFDSCxLQUFLLENBQUMsRUFBRSxDQUFDLENBQUMsU0FBUyxDQUFDO2dCQUNoQixhQUFhLEVBQUUsQ0FBQztnQkFDaEIsS0FBSSxDQUFDLElBQUksQ0FBQyxNQUFNLEVBQUUsR0FBRyxFQUFFLGFBQWEsQ0FBQyxDQUFDO1lBQzFDLENBQUMsQ0FBQyxDQUFDO1NBQ047SUFDTCxDQUFDO0lBRU8sa0NBQWdCLEdBQXhCLFVBQXlCLGFBQWE7UUFDbEMsT0FBTyxDQUNILE9BQU8sYUFBYSxDQUFDLE9BQU8sQ0FBQyxLQUFLLFdBQVc7WUFDN0MsYUFBYSxDQUFDLE9BQU8sQ0FBQyxLQUFLLElBQUk7WUFDL0IsT0FBTyxhQUFhLENBQUMsYUFBYSxDQUFDLEtBQUssV0FBVztZQUNuRCxhQUFhLENBQUMsYUFBYSxDQUFDLEtBQUssSUFBSSxDQUN4QyxDQUFDO0lBQ04sQ0FBQztJQUVEOzs7O09BSUc7SUFDSyxnQ0FBYyxHQUF0QixVQUF1QixLQUFxQjtRQUE1QyxpQkFnREM7UUFoRHNCLHNCQUFBLEVBQUEsWUFBcUI7UUFDeEMsSUFBSSxZQUFZLEdBQUc7WUFDZixJQUFJLEtBQUssS0FBSyxJQUFJLEVBQUU7Z0JBQ2hCLEtBQUksQ0FBQyxhQUFhLENBQUMsT0FBTyxDQUFDLENBQUMsU0FBUyxHQUFHLEtBQUksQ0FBQyxhQUFhLENBQUMsT0FBTyxDQUFDLENBQUMsU0FBUyxDQUFDLE9BQU8sQ0FBQyxXQUFXLEVBQUUsRUFBRSxDQUFDLENBQUM7Z0JBQ3ZHLEtBQUssSUFBSSxDQUFDLEdBQVcsQ0FBQyxFQUFFLENBQUMsR0FBRyxLQUFJLENBQUMsYUFBYSxDQUFDLGFBQWEsQ0FBQyxDQUFDLE1BQU0sRUFBRSxFQUFFLENBQUMsRUFBRTtvQkFDdkUsS0FBSSxDQUFDLGFBQWEsQ0FBQyxhQUFhLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxTQUFTLEdBQUcsS0FBSSxDQUFDLGFBQWEsQ0FBQyxhQUFhLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUMsT0FBTyxDQUFDLFdBQVcsRUFBRSxFQUFFLENBQUMsQ0FBQztpQkFDNUg7Z0JBQ0QsS0FBSSxDQUFDLGNBQWMsQ0FBQyxLQUFJLENBQUMsTUFBTSxDQUFDLEtBQUssSUFBSSxLQUFJLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLEtBQUksQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUM7Z0JBQ2pHLE9BQU87YUFDVjtZQUVELElBQUksS0FBSSxDQUFDLGFBQWEsQ0FBQyxPQUFPLENBQUM7Z0JBQzNCLEtBQUksQ0FBQyxhQUFhLENBQUMsT0FBTyxDQUFDLENBQUMsU0FBUztnQkFDckMsS0FBSSxDQUFDLGFBQWEsQ0FBQyxPQUFPLENBQUMsQ0FBQyxTQUFTLENBQUMsT0FBTyxDQUFDLFFBQVEsQ0FBQyxLQUFLLENBQUMsQ0FBQyxFQUNoRTtnQkFDRSxLQUFJLENBQUMsYUFBYSxDQUFDLE9BQU8sQ0FBQyxDQUFDLFNBQVMsSUFBSSxTQUFTLENBQUM7Z0JBQ25ELEtBQUssSUFBSSxDQUFDLEdBQVcsQ0FBQyxFQUFFLENBQUMsR0FBRyxLQUFJLENBQUMsYUFBYSxDQUFDLGFBQWEsQ0FBQyxDQUFDLE1BQU0sRUFBRSxFQUFFLENBQUMsRUFBRTtvQkFDdkUsS0FBSSxDQUFDLGFBQWEsQ0FBQyxhQUFhLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxTQUFTLElBQUksU0FBUyxDQUFDO2lCQUMvRDthQUNKO1lBQ0QsS0FBSSxDQUFDLGlCQUFpQixDQUFDLEtBQUssQ0FBQyxDQUFDO1lBRTlCLEtBQUksQ0FBQyxjQUFjLENBQUM7Z0JBQ2hCLGFBQWEsRUFBRSxFQUFFO2dCQUNqQixXQUFXLEVBQUUsS0FBSztnQkFDbEIsWUFBWSxFQUFFLEVBQUU7YUFDbkIsQ0FBQyxDQUFDO1lBQ0gsS0FBSSxDQUFDLGlCQUFpQixFQUFFLENBQUM7UUFDN0IsQ0FBQyxDQUFDO1FBQ0YsSUFBSSxLQUFLLEdBQUc7WUFDUixzSEFBc0g7WUFDdEgsSUFBSSxLQUFJLENBQUMsTUFBTSxDQUFDLEtBQUs7Z0JBQ2pCLEtBQUksQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLFNBQVM7Z0JBQzNCLEtBQUksQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLFNBQVMsQ0FBQyxJQUFJO2dCQUNoQyxLQUFJLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxTQUFTLENBQUMsSUFBSSxLQUFLLE1BQU0sRUFDN0M7Z0JBQ0UsSUFBSSxlQUFlLEdBQVksS0FBSSxDQUFDLGdCQUFnQixDQUFDLEtBQUksQ0FBQyxhQUFhLENBQUMsQ0FBQztnQkFDekUsSUFBSSxlQUFlLEtBQUssSUFBSTtvQkFBRSxPQUFPLGVBQWUsQ0FBQztnQkFFckQsSUFBSSxXQUFXLEdBQVcsR0FBRyxHQUFHLEtBQUksQ0FBQyxNQUFNLEdBQUcseUJBQXlCLENBQUM7Z0JBQ3hFLEtBQUksQ0FBQyxhQUFhLENBQUMsT0FBTyxDQUFDLEdBQUcsS0FBSSxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsYUFBYSxDQUFDLGFBQWEsQ0FBQyxXQUFXLEdBQUcsdUJBQXVCLENBQUMsQ0FBQztnQkFDbkgsS0FBSSxDQUFDLGFBQWEsQ0FBQyxhQUFhLENBQUMsR0FBRyxLQUFJLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxhQUFhLENBQUMsZ0JBQWdCLENBQUMsV0FBVyxHQUFHLGtCQUFrQixDQUFDLENBQUM7Z0JBQ3ZILE9BQU8sS0FBSSxDQUFDLGdCQUFnQixDQUFDLEtBQUksQ0FBQyxhQUFhLENBQUMsQ0FBQzthQUNwRDtpQkFBTTtnQkFDSCxPQUFPLElBQUksQ0FBQzthQUNmO1FBQ0wsQ0FBQyxDQUFDO1FBQ0YsSUFBSSxDQUFDLElBQUksQ0FBQyxLQUFLLEVBQUUsWUFBWSxDQUFDLENBQUM7SUFDbkMsQ0FBQztJQUdEOzs7T0FHRztJQUNLLGdDQUFjLEdBQXRCLFVBQXVCLEtBQWM7UUFBckMsaUJBTUM7UUFMRyxJQUFJLElBQUksQ0FBQyxhQUFhLENBQUMsVUFBVSxDQUFDLElBQUksQ0FBQyxXQUFXLENBQUMsRUFBRTtZQUNqRCxLQUFLLENBQUMsRUFBRSxDQUFDLENBQUMsU0FBUyxDQUFDO2dCQUNoQixLQUFJLENBQUMsV0FBVyxDQUFDLEdBQUcsQ0FBQyxhQUFhLENBQUMsS0FBSyxDQUFDLENBQUM7WUFDOUMsQ0FBQyxDQUFDLENBQUM7U0FDTjtJQUNMLENBQUM7SUFFRDs7O09BR0c7SUFDSyw4QkFBWSxHQUFwQixVQUFxQixPQUFpQjtRQUF0QyxpQkFhQztRQVpHLElBQUksT0FBTyxPQUFPLEtBQUssV0FBVyxFQUFFO1lBQ2hDLE9BQU8sR0FBRyxLQUFLLENBQUM7WUFDaEIsSUFBSSxJQUFJLENBQUMsTUFBTSxDQUFDLEtBQUssSUFBSSxJQUFJLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxLQUFLLElBQUksSUFBSSxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLFdBQVcsRUFBRTtnQkFDckYsT0FBTyxHQUFHLElBQUksQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxXQUFXLENBQUM7YUFDakQ7U0FDSjtRQUNELElBQUksSUFBSSxDQUFDLGFBQWEsQ0FBQyxVQUFVLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxFQUFFO1lBQ2pELEtBQUssQ0FBQyxFQUFFLENBQUMsQ0FBQyxTQUFTLENBQUM7Z0JBQ2hCLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUksQ0FBQyxXQUFXLENBQUMsR0FBRyxDQUFDLFNBQVMsRUFBRSxDQUFDLENBQUMsQ0FBQyxLQUFJLENBQUMsV0FBVyxDQUFDLEdBQUcsQ0FBQyxXQUFXLEVBQUUsQ0FBQztnQkFDbEYsS0FBSSxDQUFDLFlBQVksRUFBRSxDQUFDO1lBQ3hCLENBQUMsQ0FBQyxDQUFDO1NBQ047SUFDTCxDQUFDO0lBRUQ7Ozs7OztPQU1HO0lBQ0ssbUNBQWlCLEdBQXpCLFVBQTBCLFFBQXlCO1FBQXpCLHlCQUFBLEVBQUEsZ0JBQXlCO1FBQy9DLElBQUksQ0FBQyxXQUFXLENBQUMsU0FBUyxDQUFDLFlBQVksQ0FBQyxRQUFRLENBQUMsQ0FBQztJQUN0RCxDQUFDO0lBRUQsc0JBQXNCO0lBQ3RCOzs7OztPQUtHO0lBQ0ssa0NBQWdCLEdBQXhCLFVBQXlCLFFBQWM7UUFBdkMsaUJBbUJDO1FBbEJHLElBQUksUUFBUSxHQUFZLEtBQUssQ0FBQztRQUM5QixJQUFJLENBQUMsUUFBUTtZQUFFLFFBQVEsR0FBRyxJQUFJLENBQUMsV0FBVyxDQUFDLFNBQVMsQ0FBQyxzQkFBc0IsRUFBRSxDQUFDO1FBQzlFLFFBQVEsQ0FBQyxPQUFPLENBQUMsVUFBQyxNQUFXO1lBQ3pCLEtBQUksQ0FBQyxVQUFVLENBQUMsTUFBTSxDQUFDLENBQUM7WUFDeEIsSUFBSSxTQUFTLEdBQUcsTUFBTSxDQUFDLFNBQVMsRUFBRSxDQUFDO1lBQ25DLElBQUksU0FBUyxDQUFDLGdCQUFnQixFQUFFO2dCQUM1QixLQUFJLENBQUMsVUFBVSxDQUFDLFNBQVMsQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFBO2FBQzlDO2lCQUFNO2dCQUNILElBQUksTUFBTSxDQUFDLE1BQU0sRUFBRTtvQkFDZixRQUFRLEdBQUcsSUFBSSxDQUFDO29CQUNoQixLQUFJLENBQUMsVUFBVSxDQUFDLE1BQU0sQ0FBQyxNQUFNLEVBQUUsS0FBSyxDQUFDLENBQUM7b0JBQ3RDLE1BQU0sQ0FBQyxNQUFNLENBQUMsTUFBTSxHQUFHLE1BQU0sQ0FBQztvQkFDOUIsTUFBTSxDQUFDLE1BQU0sR0FBRyxNQUFNLENBQUM7b0JBQ3ZCLFNBQVMsQ0FBQyxNQUFNLEdBQUcsTUFBTSxDQUFDO2lCQUM3QjthQUNKO1FBQ0wsQ0FBQyxDQUFDLENBQUM7UUFDSCxJQUFJLFFBQVE7WUFBRSxJQUFJLENBQUMsYUFBYSxDQUFDLElBQUksQ0FBQyxDQUFDO0lBQzNDLENBQUM7SUFFTyw0QkFBVSxHQUFsQixVQUFtQixPQUFZLEVBQUUsWUFBNEI7UUFBNUIsNkJBQUEsRUFBQSxtQkFBNEI7UUFDekQsSUFBSSxZQUFZLEVBQUU7WUFDZCxJQUFJLFNBQVMsR0FBRyxPQUFPLENBQUMsU0FBUyxFQUFFLENBQUM7WUFDcEMsU0FBUyxDQUFDLGVBQWUsR0FBRyxJQUFJLENBQUMsdUJBQXVCLENBQUM7WUFDekQsU0FBUyxDQUFDLFlBQVksR0FBRyxJQUFJLENBQUMsdUJBQXVCLENBQUM7WUFDdEQsU0FBUyxDQUFDLFVBQVUsR0FBRyxJQUFJLENBQUMsdUJBQXVCLENBQUM7U0FDdkQ7UUFDRCxJQUFJLE9BQU8sQ0FBQyxTQUFTLEVBQUU7WUFDbkIsT0FBTyxDQUFDLFNBQVMsQ0FBQyxDQUFDLElBQUksQ0FBQyx1QkFBdUIsQ0FBQyxDQUFDO1NBQ3BEO2FBQU07WUFDSCxPQUFPLENBQUMsTUFBTSxHQUFHLENBQUMsSUFBSSxDQUFDLHVCQUF1QixDQUFDO1NBQ2xEO1FBQ0QsT0FBTyxDQUFDLFlBQVksR0FBRyxJQUFJLENBQUMsdUJBQXVCLENBQUM7UUFDcEQsT0FBTyxDQUFDLFVBQVUsR0FBRyxJQUFJLENBQUMsdUJBQXVCLENBQUM7SUFDdEQsQ0FBQztJQUNELHNCQUFzQjtJQUV0Qix3R0FBd0c7SUFDeEcsdUNBQXVDO0lBQ3ZDLHdHQUF3RztJQUNoRyxpQ0FBZSxHQUF2QixVQUF3QixZQUEwQjtRQUFsRCxpQkFhQztRQVpHLElBQUksWUFBWSxDQUFDLGNBQWMsQ0FBQyx3QkFBd0IsQ0FBQztZQUFFLElBQUksQ0FBQyx1QkFBdUIsR0FBRyxZQUFZLENBQUMsc0JBQXNCLENBQUM7UUFDOUgsSUFBSSxDQUFDLFVBQVUsR0FBa0IsSUFBSSxDQUFDLE9BQU8sQ0FBQyxvQkFBb0IsRUFBRSxDQUFDO1FBRXJFLElBQUksQ0FBQyxXQUFXLEdBQUcsSUFBSSxDQUFDLGFBQWEsQ0FBQyxtQkFBbUIsQ0FBQyxZQUFZLEVBQUUsSUFBSSxDQUFDLFVBQVUsQ0FBQyxDQUFDO1FBQ3pGLElBQUksQ0FBQyxXQUFXLENBQUMsT0FBTyxDQUFDLFFBQVEsQ0FBQyxHQUFHLElBQUksQ0FBQyxNQUFNLENBQUM7UUFDakQsSUFBSSxDQUFDLFdBQVcsQ0FBQyxzQkFBc0IsR0FBRyxLQUFLLENBQUM7UUFDaEQsSUFBSSxDQUFDLFdBQVcsQ0FBQyx1QkFBdUIsR0FBRyxVQUFDLE1BQVc7WUFDbkQsS0FBSSxDQUFDLGdCQUFnQixDQUFDLE1BQU0sQ0FBQyxPQUFPLENBQUMsQ0FBQztZQUN0QyxLQUFJLENBQUMsWUFBWSxFQUFFLENBQUM7UUFDeEIsQ0FBQyxDQUFBO1FBRUQsSUFBSSxDQUFDLGFBQWEsQ0FBQyxjQUFjLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxDQUFDO0lBQ3hELENBQUM7SUFFTywrQkFBYSxHQUFyQixVQUFzQixhQUFrQztRQUNwRCxJQUFJLENBQUMsYUFBYSxDQUFDLFlBQVksQ0FBQyxhQUFhLEVBQUUsSUFBSSxDQUFDLE1BQU0sRUFBRSxJQUFJLENBQUMsdUJBQXVCLENBQUMsQ0FBQztRQUMxRixJQUFJLENBQUMsYUFBYSxFQUFFLENBQUM7SUFDekIsQ0FBQztJQUVPLHNDQUFvQixHQUE1QixVQUE2QixRQUF3QjtRQUF4Qix5QkFBQSxFQUFBLGVBQXdCO1FBQ2pELElBQUksSUFBSSxDQUFDLGFBQWEsQ0FBQyxVQUFVLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxFQUFFO1lBQ2pELElBQUksQ0FBQyx1QkFBdUIsR0FBRyxRQUFRLENBQUM7WUFFeEMsSUFBSSxDQUFDLGFBQWEsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUM7WUFDaEMsSUFBSSxJQUFJLENBQUMsTUFBTSxDQUFDLFFBQVEsS0FBSyxRQUFRLElBQUksSUFBSSxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsU0FBUyxDQUFDLElBQUksS0FBSyxPQUFPLEVBQUU7Z0JBQ25GLElBQUksQ0FBQyxjQUFjLENBQUMsSUFBSSxDQUFDLGFBQWEsQ0FBQyxDQUFDO2FBQzNDO1lBRUQsSUFBSSxDQUFDLFlBQVksRUFBRSxDQUFDO1NBQ3ZCO0lBQ0wsQ0FBQztJQUVPLDZCQUFXLEdBQW5CLFVBQW9CLFFBQW9CLEVBQUUsaUJBQWlDO1FBQTNFLGlCQWdCQztRQWhCeUMsa0NBQUEsRUFBQSx3QkFBaUM7UUFDdkUsd0ZBQXdGO1FBQ3hGLElBQUksQ0FBQyxhQUFhLENBQUMsdUJBQXVCLENBQUMsUUFBUSxFQUFFLElBQUksQ0FBQyxNQUFNLEVBQUUsSUFBSSxDQUFDLE1BQU0sRUFBRSxJQUFJLENBQUMsV0FBVyxDQUFDLENBQUM7UUFFakcsSUFBSSxpQkFBaUIsRUFBRTtZQUNuQixJQUFJLENBQUMsYUFBYSxDQUFDLFVBQVUsQ0FBQyxRQUFRLENBQUMsQ0FBQztTQUMzQztRQUVELElBQUksSUFBSSxDQUFDLGFBQWEsQ0FBQyxpQkFBaUIsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLFFBQVEsQ0FBQyxJQUFJLElBQUksQ0FBQyxhQUFhLENBQUMsVUFBVSxDQUFDLElBQUksQ0FBQyxXQUFXLENBQUMsRUFBRTtZQUMvRyxJQUFJLENBQUMseUJBQXlCLEVBQUUsQ0FBQztTQUNwQztRQUVELEtBQUssRUFBRSxDQUFDLFNBQVMsQ0FBQztZQUNkLEtBQUksQ0FBQyxnQkFBZ0IsRUFBRSxDQUFDO1lBQ3hCLEtBQUksQ0FBQyxxQkFBcUIsRUFBRSxDQUFDO1FBQ2pDLENBQUMsQ0FBQyxDQUFDO0lBQ1AsQ0FBQztJQUVELHdHQUF3RztJQUN4RyxzQ0FBc0M7SUFDdEMsd0dBQXdHO0lBQ2hHLHFDQUFtQixHQUEzQixVQUErQixVQUFrQixFQUFFLGlCQUFvQjtRQUNuRSxRQUFRLFVBQVUsRUFBRTtZQUNoQixLQUFLLFlBQVksQ0FBQztZQUNsQixLQUFLLFdBQVcsQ0FBQztZQUNqQixLQUFLLE9BQU8sQ0FBQztZQUNiLEtBQUssUUFBUTtnQkFDVCxJQUFJLENBQUMscUJBQXFCLENBQUksaUJBQWlCLENBQUMsQ0FBQztnQkFDakQsTUFBTTtZQUNWO2dCQUNJLE9BQU8sQ0FBQyxLQUFLLENBQUMsNENBQTRDLEVBQUUsVUFBVSxDQUFDLENBQUM7U0FDL0U7SUFDTCxDQUFDO0lBRU8sdUNBQXFCLEdBQTdCLFVBQWlDLE9BQVU7UUFDdkMsSUFBSSxDQUFDLGNBQWMsQ0FBQyxnQkFBZ0IsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLEVBQUUsRUFBRSxPQUFPLENBQUMsQ0FBQztJQUNsRSxDQUFDO0lBRU8sNkNBQTJCLEdBQW5DO1FBQ0ksSUFBSSxDQUFDLGNBQWMsQ0FBQyxZQUFZLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxFQUFFLENBQUMsQ0FBQztJQUNyRCxDQUFDO0lBRU8sMENBQXdCLEdBQWhDO1FBQUEsaUJBZ0JDO1FBZkcsSUFBSSxDQUFDLGdCQUFnQixDQUFDLGNBQWMsR0FBRyxJQUFJLENBQUMsY0FBYyxDQUFDLGtCQUFrQixDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsRUFBRSxDQUFDLENBQUMsU0FBUyxDQUFDLFVBQUMsUUFBaUI7WUFDdEgsS0FBSSxDQUFDLHFCQUFxQixDQUFDLFFBQVEsQ0FBQyxDQUFDO1FBQ3pDLENBQUMsQ0FBQyxDQUFDO1FBRUgsSUFBSSxDQUFDLGdCQUFnQixDQUFDLGVBQWUsR0FBRyxJQUFJLENBQUMsY0FBYyxDQUFDLGNBQWMsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLEVBQUUsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxVQUFDLFdBQWlDO1lBQ25JLEtBQUksQ0FBQyxvQkFBb0IsQ0FBQyxXQUFXLENBQUMsQ0FBQztRQUMzQyxDQUFDLENBQUMsQ0FBQztRQUVILElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxhQUFhLEdBQUcsSUFBSSxDQUFDLGNBQWMsQ0FBQyxvQkFBb0IsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLEVBQUUsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxVQUFDLEtBQXVDO1lBQzdJLElBQUksS0FBSyxDQUFDLE1BQU0sS0FBSyxRQUFRLEVBQUU7Z0JBQzNCLElBQUksTUFBTSxHQUFXLENBQUMsT0FBTyxLQUFJLENBQUMsTUFBTSxDQUFDLFFBQVEsS0FBSyxXQUFXLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSSxDQUFDLE1BQU0sQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQztnQkFDakcsS0FBSSxDQUFDLHNCQUFzQixDQUFDLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUM7Z0JBQ3JELEtBQUksQ0FBQyxxQkFBcUIsRUFBRSxDQUFDO2FBQ2hDO1FBQ0wsQ0FBQyxDQUFDLENBQUM7SUFDUCxDQUFDO0lBRUQsd0dBQXdHO0lBQ3hHLDBDQUEwQztJQUMxQyx3R0FBd0c7SUFDaEcsdUNBQXFCLEdBQTdCLFVBQThCLFFBQWlCLEVBQUUsVUFBb0I7UUFDakUsSUFBSSxXQUFXLEdBQVcsQ0FBQyxPQUFPLFVBQVUsS0FBSyxXQUFXLElBQUksVUFBVSxDQUFDLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDO1FBQ2hHLElBQUksT0FBTyxRQUFRLEtBQUssV0FBVyxFQUFFO1lBQ2pDLFdBQVcsR0FBRyxRQUFRLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQztTQUNsQztRQUVELElBQUksZUFBZSxHQUFnQyxJQUFJLDJCQUEyQixFQUFFLENBQUM7UUFFckYsZUFBZSxDQUFDLFdBQVcsR0FBRyxXQUFXLENBQUM7UUFDMUMsZUFBZSxDQUFDLGFBQWEsR0FBRyxJQUFJLENBQUMsYUFBYSxDQUFDLHFCQUFxQixDQUFDLElBQUksQ0FBQyxXQUFXLENBQUMsT0FBTyxFQUFFLElBQUksQ0FBQyxNQUFNLENBQUMsU0FBUyxDQUFDLEtBQUssRUFBRSxJQUFJLENBQUMsTUFBTSxDQUFDLFNBQVMsQ0FBQyxTQUFTLEVBQUUsSUFBSSxDQUFDLE1BQU0sQ0FBQyxRQUFRLENBQUMsQ0FBQztRQUN2TCxtRkFBbUY7UUFFbkYsSUFBSSxDQUFDLG1CQUFtQixDQUE4QixXQUFXLEVBQUUsZUFBZSxDQUFDLENBQUM7SUFDeEYsQ0FBQztJQUVPLDBDQUF3QixHQUFoQztRQUNJLElBQUksQ0FBQyxxQkFBcUIsQ0FBQyxTQUFTLEVBQUUsSUFBSSxDQUFDLENBQUM7SUFDaEQsQ0FBQztJQUVELHdHQUF3RztJQUN4RyxtQkFBbUI7SUFDbkIsd0dBQXdHO0lBQ2hHLHNDQUFvQixHQUE1QixVQUE2QixXQUFpQztRQUMxRCxJQUFJLFdBQVcsR0FBNEIsSUFBSSx1QkFBdUIsRUFBRSxDQUFDO1FBRXpFLFdBQVcsQ0FBQyxLQUFLLEdBQUcsV0FBVyxDQUFDLEtBQUssQ0FBQztRQUN0QyxXQUFXLENBQUMsS0FBSyxHQUFHLFdBQVcsQ0FBQyxLQUFLLENBQUM7UUFDdEMsV0FBVyxDQUFDLFdBQVcsR0FBRyxXQUFXLENBQUMsV0FBVyxDQUFDO1FBQ2xELFdBQVcsQ0FBQyxRQUFRLEdBQUcsV0FBVyxDQUFDLFFBQVEsQ0FBQztRQUM1QyxXQUFXLENBQUMsS0FBSyxHQUFHLFdBQVcsQ0FBQyxJQUFJLENBQUM7UUFFckMsSUFBSSxDQUFDLG1CQUFtQixDQUEwQixPQUFPLEVBQUUsV0FBVyxDQUFDLENBQUM7SUFDNUUsQ0FBQztJQUVPLHVDQUFxQixHQUE3QjtRQUNJLElBQUksV0FBVyxHQUE0QixJQUFJLHVCQUF1QixFQUFFLENBQUM7UUFDekUsSUFBSSxDQUFDLG1CQUFtQixDQUEwQixPQUFPLEVBQUUsV0FBVyxDQUFDLENBQUM7SUFDNUUsQ0FBQztJQUVPLHdDQUFzQixHQUE5QixVQUErQixTQUF3QjtRQUNuRCxJQUFJLFFBQVEsR0FBVyxDQUFDLE9BQU8sSUFBSSxDQUFDLE1BQU0sQ0FBQyxRQUFRLEtBQUssV0FBVyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUM7UUFFbkcsS0FBSyxJQUFJLENBQUMsR0FBVyxDQUFDLEVBQUUsQ0FBQyxHQUFHLFNBQVMsQ0FBQyxNQUFNLEVBQUUsRUFBRSxDQUFDLEVBQUU7WUFDL0MsS0FBSyxJQUFJLENBQUMsR0FBVyxDQUFDLEVBQUUsQ0FBQyxHQUFHLElBQUksQ0FBQyxHQUFHLENBQUMsTUFBTSxFQUFFLEVBQUUsQ0FBQyxFQUFFO2dCQUM5QyxJQUFJLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLEVBQUUsS0FBSyxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLFFBQVEsRUFBRSxFQUFFO29CQUM5RCxJQUFJLENBQUMsR0FBRyxDQUFDLE1BQU0sQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUM7b0JBQ3RCLE1BQU07aUJBQ1Q7YUFDSjtTQUNKO0lBQ0wsQ0FBQztJQUVELHdHQUF3RztJQUN4RyxtQ0FBbUM7SUFDbkMsd0dBQXdHO0lBQ2hHLGtDQUFnQixHQUF4QjtRQUNJLElBQUksSUFBSSxDQUFDLGFBQWEsQ0FBQyxVQUFVLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxFQUFFO1lBQ2pELElBQUksQ0FBQyxXQUFXLENBQUMsR0FBRyxDQUFDLHVCQUF1QixDQUFDLElBQUksQ0FBQyxDQUFDO1lBQ25ELElBQUksQ0FBQyxXQUFXLENBQUMsR0FBRyxDQUFDLGNBQWMsQ0FBQyxJQUFJLENBQUMsQ0FBQztZQUMxQyxJQUFJLENBQUMsV0FBVyxDQUFDLEdBQUcsQ0FBQyxZQUFZLENBQUMsSUFBSSxDQUFDLENBQUM7WUFFeEMsSUFBSSxPQUFPLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxhQUFhLEtBQUssV0FBVyxFQUFFO2dCQUM1RCxJQUFJLENBQUMsZ0JBQWdCLENBQUMsYUFBYSxDQUFDLFdBQVcsRUFBRSxDQUFDO2FBQ3JEO1NBQ0o7SUFDTCxDQUFDO0lBRU8sK0NBQTZCLEdBQXJDO1FBQUEsaUJBZ0JDO1FBZkcsSUFBSSxVQUFVLEdBQTBCO1lBQ3BDLE9BQU8sRUFBRSxVQUFDLE9BQWlDO2dCQUN2QyxLQUFJLENBQUMsbUJBQW1CLENBQUMsSUFBSSxDQUFDLENBQUM7Z0JBRS9CLElBQUksT0FBTyxLQUFJLENBQUMsZ0JBQWdCLENBQUMsYUFBYSxLQUFLLFdBQVcsRUFBRTtvQkFDNUQsS0FBSSxDQUFDLGdCQUFnQixDQUFDLGFBQWEsQ0FBQyxXQUFXLEVBQUUsQ0FBQztpQkFDckQ7Z0JBQ0QsS0FBSSxDQUFDLGdCQUFnQixDQUFDLGFBQWEsR0FBRyxLQUFJLENBQUMsdUJBQXVCLENBQUMsT0FBTyxDQUFDLENBQUMsU0FBUyxDQUFDLFVBQUMsU0FBaUM7b0JBQ3BILE9BQU8sQ0FBQyxlQUFlLENBQUMsU0FBUyxDQUFDLElBQUksRUFBRSxTQUFTLENBQUMsS0FBSyxDQUFDLENBQUM7b0JBQ3pELEtBQUksQ0FBQyxtQkFBbUIsQ0FBQyxLQUFLLENBQUMsQ0FBQztnQkFDcEMsQ0FBQyxDQUFDLENBQUM7WUFDUCxDQUFDO1NBQ0osQ0FBQztRQUVGLElBQUksQ0FBQyxXQUFXLENBQUMsR0FBRyxDQUFDLHVCQUF1QixDQUFDLFVBQVUsQ0FBQyxDQUFDO0lBQzdELENBQUM7SUFFTyx5Q0FBdUIsR0FBL0IsVUFBZ0MsaUJBQTJDO1FBQTNFLGlCQXFCQztRQXBCRyxPQUFPLElBQUksVUFBVSxDQUF5QixVQUFDLFNBQTZDO1lBQ3hGLFFBQVEsS0FBSSxDQUFDLE1BQU0sQ0FBQyxRQUFRLEVBQUU7Z0JBQzFCLEtBQUssVUFBVSxDQUFDO2dCQUNoQixLQUFLLFNBQVM7b0JBQ2EsS0FBSSxDQUFDLGFBQWMsQ0FBQyxzQkFBc0IsQ0FBQyxpQkFBaUIsQ0FBQyxPQUFPLEVBQUUsS0FBSSxDQUFDLFdBQVcsQ0FBQyxPQUFPLENBQUMsS0FBSyxFQUFFLENBQUMsQ0FBQyxTQUFTLENBQUMsVUFBQyxTQUFpQzt3QkFDdkssU0FBUyxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsQ0FBQzt3QkFDMUIsU0FBUyxDQUFDLFFBQVEsRUFBRSxDQUFDO29CQUN6QixDQUFDLENBQUMsQ0FBQztvQkFFSCxNQUFNO2dCQUNWLEtBQUssUUFBUTtvQkFDVCxJQUFJLFlBQVksR0FBMkIsSUFBSSxzQkFBc0IsQ0FBQyxpQkFBaUIsQ0FBQyxPQUFPLEVBQUUsU0FBUyxDQUFDLENBQUM7b0JBQzVHLEtBQUksQ0FBQyxtQkFBbUIsQ0FBeUIsWUFBWSxFQUFFLFlBQVksQ0FBQyxDQUFDO29CQUU3RSxNQUFNO2dCQUNWO29CQUNJLE9BQU8sQ0FBQyxLQUFLLENBQUMsOENBQThDLEVBQUUsS0FBSSxDQUFDLE1BQU0sQ0FBQyxRQUFRLENBQUMsQ0FBQztvQkFDcEYsU0FBUyxDQUFDLFFBQVEsRUFBRSxDQUFDO2FBQzVCO1FBQ0wsQ0FBQyxDQUFDLENBQUM7SUFDUCxDQUFDO0lBRUQsd0dBQXdHO0lBQ3hHLGlCQUFpQjtJQUNqQix3R0FBd0c7SUFDaEcsZ0NBQWMsR0FBdEI7UUFBQSxpQkEyTUM7UUExTUcsSUFBSSxPQUFPLElBQUksQ0FBQyxHQUFHLEtBQUssV0FBVyxFQUFFO1lBQ2pDLElBQUksU0FBUyxHQUFRO2dCQUNqQixpQ0FBaUM7Z0JBQ2pDLEtBQUssRUFBRSxJQUFJLENBQUMsY0FBYztnQkFDMUIsRUFBRSxFQUFFLElBQUksQ0FBQyxNQUFNLENBQUMsRUFBRTtnQkFDbEIsSUFBSSxFQUFFLElBQUksQ0FBQyxHQUFHO2dCQUNkLE9BQU8sRUFBRSxJQUFJLENBQUMsTUFBTTthQUN2QixDQUFDO1lBRUYsSUFBSSxDQUFDLGFBQWEsQ0FBQyxxQkFBcUIsQ0FBQyxJQUFJLENBQUMsR0FBRyxFQUFFLFNBQVMsQ0FBQyxDQUFDO1lBRTlELDBDQUEwQztZQUMxQyxrQ0FBa0M7WUFDbEMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxPQUFPLENBQUMsV0FBVyxHQUFHLFVBQUMsT0FBZ0I7Z0JBQzVDLEtBQUksQ0FBQyxjQUFjLEdBQUcsT0FBTyxDQUFDO1lBQ2xDLENBQUMsQ0FBQztZQUVGLElBQUksQ0FBQyxHQUFHLENBQUMsT0FBTyxDQUFDLFVBQVUsR0FBRyxVQUFDLGdCQUFrQztnQkFDN0QsSUFBSSxZQUFZLEdBQW1CLEVBQUUsQ0FBQztnQkFFdEMsS0FBSSxDQUFDLFdBQVcsQ0FBQyxHQUFHLENBQUMsV0FBVyxDQUFDLFVBQUMsUUFBaUI7b0JBQy9DLElBQUksT0FBTyxRQUFRLENBQUMsRUFBRSxLQUFLLFdBQVcsSUFBSSxRQUFRLENBQUMsRUFBRSxLQUFLLGdCQUFnQixDQUFDLEtBQUssRUFBRTt3QkFDOUUsUUFBUSxDQUFDLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxLQUFLLENBQUMsR0FBRyxnQkFBZ0IsQ0FBQyxJQUFJLENBQUM7d0JBQzlELFlBQVksQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLENBQUM7cUJBQy9CO2dCQUNMLENBQUMsQ0FBQyxDQUFDO2dCQUVILElBQUksYUFBYSxHQUFzRDtvQkFDbkUsUUFBUSxFQUFFLFlBQVk7b0JBQ3RCLE9BQU8sRUFBRSxDQUFDLGdCQUFnQixDQUFDLEtBQUssQ0FBQztpQkFDcEMsQ0FBQztnQkFFRixLQUFJLENBQUMsV0FBVyxDQUFDLEdBQUcsQ0FBQyxZQUFZLENBQUMsYUFBYSxDQUFDLENBQUM7WUFDckQsQ0FBQyxDQUFDO1lBRUYsSUFBSSxDQUFDLEdBQUcsQ0FBQyxPQUFPLENBQUMsU0FBUyxHQUFHLFVBQUMsV0FBbUI7Z0JBQzdDLElBQUksS0FBSSxDQUFDLE1BQU0sQ0FBQyxRQUFRLEtBQUssUUFBUSxFQUFFO29CQUNuQyxLQUFJLENBQUMsV0FBVyxDQUFDLEdBQUcsQ0FBQyxjQUFjLENBQUMsV0FBVyxDQUFDLENBQUM7aUJBQ3BEO3FCQUNJO29CQUNELE9BQU8sQ0FBQyxJQUFJLENBQUMsaUdBQWlHLENBQUMsQ0FBQztpQkFDbkg7WUFDTCxDQUFDLENBQUM7WUFFRixJQUFJLENBQUMsR0FBRyxDQUFDLE9BQU8sQ0FBQyxPQUFPLEdBQUcsVUFBQyxLQUFpQixFQUFFLGdCQUFpQztnQkFBakMsaUNBQUEsRUFBQSx3QkFBaUM7Z0JBQzVFOzs7Ozs7O21CQU9HO2dCQUNILElBQUksT0FBTyxLQUFJLENBQUMsTUFBTSxDQUFDLFFBQVEsS0FBSyxXQUFXLElBQUksS0FBSSxDQUFDLE1BQU0sQ0FBQyxRQUFRLEtBQUssUUFBUSxFQUFFO29CQUNsRixJQUFJLE1BQU0sR0FBVyxDQUFDLE9BQU8sS0FBSSxDQUFDLE1BQU0sQ0FBQyxRQUFRLEtBQUssV0FBVyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUksQ0FBQyxNQUFNLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUM7b0JBRWpHLEtBQUssSUFBSSxDQUFDLEdBQVcsQ0FBQyxFQUFFLENBQUMsR0FBRyxLQUFLLENBQUMsTUFBTSxFQUFFLEVBQUUsQ0FBQyxFQUFFO3dCQUMzQyxLQUFJLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztxQkFDM0I7b0JBRUQsS0FBSSxDQUFDLFdBQVcsQ0FBQyxLQUFJLENBQUMsR0FBRyxFQUFFLEtBQUssQ0FBQyxDQUFDO29CQUNsQyxLQUFJLENBQUMsV0FBVyxDQUFDLEdBQUcsQ0FBQyxhQUFhLENBQUMsRUFBRSxHQUFHLEVBQUUsS0FBSyxDQUFDLEtBQUssRUFBRSxFQUFFLENBQUMsQ0FBQztvQkFFM0QsSUFBSSxnQkFBZ0IsRUFBRTt3QkFDbEIsS0FBSSxDQUFDLFdBQVcsQ0FBQyxHQUFHLENBQUMsa0JBQWtCLENBQUMsS0FBSSxDQUFDLFdBQVcsQ0FBQyxHQUFHLENBQUMsVUFBVSxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxRQUFRLEVBQUUsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDO3FCQUNsSDtpQkFDSjtxQkFDSTtvQkFDRCxPQUFPLENBQUMsSUFBSSxDQUFDLGdGQUFnRixDQUFDLENBQUM7aUJBQ2xHO1lBQ0wsQ0FBQyxDQUFDO1lBRUYsSUFBSSxDQUFDLEdBQUcsQ0FBQyxPQUFPLENBQUMsVUFBVSxHQUFHLFVBQUMsR0FBNkM7O2dCQUN4RSxJQUFJLE9BQU8sS0FBSSxDQUFDLE1BQU0sQ0FBQyxRQUFRLEtBQUssV0FBVyxJQUFJLEtBQUksQ0FBQyxNQUFNLENBQUMsUUFBUSxLQUFLLFFBQVEsRUFBRTtvQkFDbEYsSUFBSSxZQUFZLEdBQWtCLEVBQUUsQ0FBQztvQkFFckMsSUFBSSxPQUFPLEdBQUcsS0FBSyxRQUFRLElBQUksT0FBTyxHQUFHLEtBQUssUUFBUSxFQUFFO3dCQUNwRCxZQUFZLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxRQUFRLEVBQUUsQ0FBQyxDQUFDO3FCQUNyQzt5QkFDSTt3QkFDRCxLQUFLLElBQUksQ0FBQyxHQUFXLENBQUMsRUFBRSxDQUFDLEdBQUcsR0FBRyxDQUFDLE1BQU0sRUFBRSxFQUFFLENBQUMsRUFBRTs0QkFDekMsWUFBWSxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsUUFBUSxFQUFFLENBQUMsQ0FBQzt5QkFDckM7cUJBQ0o7b0JBRUQsS0FBSSxDQUFDLHNCQUFzQixDQUFDLFlBQVksQ0FBQyxDQUFDO29CQUUxQyxJQUFJLEdBQUcsR0FBVyxPQUFPLEtBQUksQ0FBQyxNQUFNLENBQUMsUUFBUSxLQUFLLFdBQVcsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxLQUFJLENBQUMsTUFBTSxDQUFDLFFBQVEsQ0FBQztvQkFDNUYsSUFBSSxVQUFVLEdBQWUsRUFBRSxDQUFDO29CQUVoQyxLQUFLLElBQUksQ0FBQyxHQUFXLENBQUMsRUFBRSxDQUFDLEdBQUcsWUFBWSxDQUFDLE1BQU0sRUFBRSxFQUFFLENBQUMsRUFBRTt3QkFDbEQsVUFBVSxDQUFDLElBQUksV0FBRyxHQUFDLEdBQUcsSUFBRyxZQUFZLENBQUMsQ0FBQyxDQUFDLE1BQUcsQ0FBQztxQkFDL0M7b0JBRUQ7Ozs7Ozs7dUJBT0c7b0JBRUgsSUFBSSxjQUFjLEdBQW1FO3dCQUNqRixNQUFNLEVBQUUsVUFBVTtxQkFDckIsQ0FBQztvQkFFRixLQUFJLENBQUMsV0FBVyxDQUFDLEdBQUcsQ0FBQyxhQUFhLENBQUMsY0FBYyxDQUFDLENBQUM7b0JBQ25ELEtBQUksQ0FBQyxxQkFBcUIsRUFBRSxDQUFDO2lCQUNoQztxQkFDSTtvQkFDRCxPQUFPLENBQUMsSUFBSSxDQUFDLGdGQUFnRixDQUFDLENBQUM7aUJBQ2xHO1lBQ0wsQ0FBQyxDQUFDO1lBRUYsSUFBSSxDQUFDLEdBQUcsQ0FBQyxPQUFPLENBQUMsaUJBQWlCLEdBQUcsVUFBQyxXQUFtQixFQUFFLFdBQW9CO2dCQUMzRSxLQUFLLElBQUksQ0FBQyxHQUFXLENBQUMsRUFBRSxDQUFDLEdBQUcsS0FBSSxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsTUFBTSxFQUFFLEVBQUUsQ0FBQyxFQUFFO29CQUN4RCxJQUFJLEtBQUksQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksS0FBSyxXQUFXLEVBQUU7d0JBQzVDLEtBQUksQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsR0FBRyxXQUFXLENBQUM7cUJBQ2hEO2lCQUNKO1lBQ0wsQ0FBQyxDQUFDO1lBRUYsSUFBSSxDQUFDLEdBQUcsQ0FBQyxPQUFPLENBQUMsYUFBYSxHQUFHLFVBQUMsT0FBMEI7Z0JBQ3hELElBQUksYUFBYSxHQUFzQjtvQkFDbkMsUUFBUSxFQUFFLE1BQU07b0JBQ2hCLFVBQVUsRUFBRSxJQUFJO29CQUNoQixtQkFBbUIsRUFBRSxJQUFJO2lCQUM1QixDQUFDO2dCQUNGLHVEQUF1RDtnQkFDdkQsSUFBSSxPQUFPLENBQUMsY0FBYyxDQUFDLFdBQVcsQ0FBQztvQkFBRSxPQUFPLENBQUMsU0FBUyxHQUFHLE9BQU8sQ0FBQyxTQUFTLENBQUMsS0FBSyxDQUFDLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQztnQkFDNUYsSUFBSSxNQUFNLEdBQXNCLE1BQU0sQ0FBQyxNQUFNLENBQUMsRUFBRSxFQUFFLGFBQWEsRUFBRSxPQUFPLENBQUMsQ0FBQztnQkFDMUUsSUFBSSxPQUFPLEdBQVEsS0FBSSxDQUFDLFdBQVcsQ0FBQyxHQUFHLENBQUMsY0FBYyxDQUFDLE1BQU0sQ0FBQyxDQUFDO2dCQUMvRCxJQUFJLFFBQVEsR0FBUSxJQUFJLENBQUMsSUFBSSxDQUFDLE9BQU8sRUFBRSxFQUFFLElBQUksRUFBRSxRQUFRLEVBQUUsQ0FBQyxDQUFDO2dCQUMzRCxJQUFJLFdBQVcsR0FBUSxJQUFJLENBQUMsS0FBSyxDQUFDLFFBQVEsRUFBRSxFQUFFLFFBQVEsRUFBRSxNQUFNLEVBQUUsSUFBSSxFQUFFLFFBQVEsRUFBRSxDQUFDLENBQUM7Z0JBQ2xGLElBQUksVUFBVSxHQUFTLEtBQUksQ0FBQyxhQUFhLENBQUMsU0FBUyxDQUFDLFdBQVcsRUFBRSxtRUFBbUUsQ0FBQyxDQUFDO2dCQUN0SSxNQUFNLENBQUMsVUFBVSxFQUFFLE1BQU0sQ0FBQyxRQUFRLEdBQUcsT0FBTyxDQUFDLENBQUM7WUFDbEQsQ0FBQyxDQUFDO1lBRUYsSUFBSSxDQUFDLEdBQUcsQ0FBQyxPQUFPLENBQUMsWUFBWSxHQUFHLFVBQUMsa0JBQW1DO2dCQUFuQyxtQ0FBQSxFQUFBLDBCQUFtQztnQkFDaEUsS0FBSSxDQUFDLGFBQWEsQ0FBQyxrQkFBa0IsQ0FBQyxDQUFDO1lBQzNDLENBQUMsQ0FBQztZQUVGLElBQUksQ0FBQyxHQUFHLENBQUMsT0FBTyxDQUFDLG1CQUFtQixHQUFHLFVBQUMsUUFBaUI7Z0JBQ3JELEtBQUksQ0FBQyxvQkFBb0IsQ0FBQyxRQUFRLENBQUMsQ0FBQztZQUN4QyxDQUFDLENBQUM7WUFFRixnQ0FBZ0M7WUFDaEMsSUFBSSxPQUFPLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsS0FBSyxXQUFXO2dCQUFFLElBQUksQ0FBQyxHQUFHLENBQUMsS0FBSyxHQUFHLEVBQUUsQ0FBQztZQUNqRSxJQUFJLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxVQUFVLEdBQUc7Z0JBQ3hCLEtBQUksQ0FBQyxZQUFZLEVBQUUsQ0FBQztZQUN4QixDQUFDLENBQUM7WUFFRixJQUFJLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxhQUFhLEdBQUcsVUFBQyxLQUFjO2dCQUMxQyxLQUFJLENBQUMsY0FBYyxDQUFDLEtBQUssQ0FBQyxDQUFDO1lBQy9CLENBQUMsQ0FBQztZQUVGLElBQUksQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLFdBQVcsR0FBRyxVQUFDLE9BQWdCO2dCQUMxQyxLQUFJLENBQUMsWUFBWSxDQUFDLE9BQU8sQ0FBQyxDQUFDO1lBQy9CLENBQUMsQ0FBQztZQUVGLElBQUksQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLGFBQWEsR0FBRztnQkFDM0IsT0FBTyxLQUFJLENBQUMsY0FBYyxFQUFFLENBQUM7WUFDakMsQ0FBQyxDQUFDO1lBRUYsSUFBSSxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsYUFBYSxHQUFHLFVBQUMsTUFBd0I7Z0JBQ3BELEtBQUksQ0FBQyxhQUFhLENBQUMsS0FBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDO2dCQUNoQyxLQUFJLENBQUMsY0FBYyxDQUFDLE1BQU0sQ0FBQyxDQUFDO1lBQ2hDLENBQUMsQ0FBQztZQUVGLElBQUksQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLGdCQUFnQixHQUFHLFVBQUMsUUFBaUI7Z0JBQ2hELEtBQUksQ0FBQyxpQkFBaUIsQ0FBQyxRQUFRLENBQUMsQ0FBQztZQUNyQyxDQUFDLENBQUM7WUFFRixJQUFJLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxhQUFhLEdBQUcsVUFBQyxLQUFjO2dCQUMxQyxLQUFJLENBQUMsY0FBYyxDQUFDLEtBQUssQ0FBQyxDQUFDO1lBQy9CLENBQUMsQ0FBQztZQUVGLGdDQUFnQztZQUNoQyxJQUFJLENBQUMsR0FBRyxDQUFDLFdBQVcsQ0FBQyxhQUFhLEdBQUc7Z0JBQ2pDLElBQUksWUFBWSxHQUEyQixLQUFJLENBQUMsV0FBVyxDQUFDLE9BQU8sQ0FBQyxLQUFJLENBQUMsYUFBYSxDQUFDLGtCQUFrQixFQUFFLENBQUMsQ0FBQztnQkFFN0csS0FBSyxJQUFJLElBQUksSUFBSSxZQUFZLEVBQUU7b0JBQzNCLElBQUksWUFBWSxDQUFDLGNBQWMsQ0FBQyxJQUFJLENBQUMsRUFBRTt3QkFDbkMsSUFBSSxXQUFXLEdBQVEsWUFBWSxDQUFDLElBQUksQ0FBQyxDQUFDO3dCQUUxQyxLQUFLLElBQUksUUFBUSxJQUFJLFdBQVcsRUFBRTs0QkFDOUIsSUFBSSxXQUFXLENBQUMsY0FBYyxDQUFDLFFBQVEsQ0FBQyxFQUFFO2dDQUN0QyxJQUFJLE9BQU8sV0FBVyxDQUFDLFFBQVEsQ0FBQyxDQUFDLE1BQU0sS0FBSyxXQUFXLEVBQUU7b0NBQ3JELFdBQVcsQ0FBQyxRQUFRLENBQUMsQ0FBQyxNQUFNLEdBQUcsRUFBRSxDQUFDO2lDQUNyQztnQ0FFRCxXQUFXLENBQUMsUUFBUSxDQUFDLENBQUMsTUFBTSxDQUFDLE1BQU0sR0FBRyxDQUFDLENBQUM7NkJBQzNDO3lCQUNKO3FCQUNKO2lCQUNKO1lBQ0wsQ0FBQyxDQUFDO1NBQ0w7YUFDSTtZQUNELE9BQU8sQ0FBQyxJQUFJLENBQUMseUVBQXlFLENBQUMsQ0FBQztTQUMzRjtJQUNMLENBQUM7SUFFRCx3R0FBd0c7SUFDeEcsa0JBQWtCO0lBQ2xCLHdHQUF3RztJQUNoRyxrQ0FBZ0IsR0FBeEIsVUFBeUIsU0FBaUI7UUFDdEMsSUFBSSxPQUFPLFNBQVMsS0FBSyxXQUFXLElBQUksU0FBUyxLQUFLLFFBQVEsRUFBRTtZQUM1RCxJQUFJLENBQUMsYUFBYSxHQUFHLElBQUksZ0JBQWdCLEVBQUUsQ0FBQztTQUMvQzthQUNJO1lBQ0QsSUFBSSxDQUFDLGFBQWEsR0FBRyxJQUFJLG9CQUFvQixFQUFFLENBQUM7U0FDbkQ7SUFDTCxDQUFDO0lBRU8sbUNBQWlCLEdBQXpCLFVBQTBCLFdBQXlCO1FBQy9DLElBQUksQ0FBQyxNQUFNLEdBQUcsSUFBSSxDQUFDLGFBQWEsQ0FBQyxTQUFTLENBQUMsV0FBVyxDQUFDLENBQUM7UUFFeEQsSUFBSSxDQUFDLGFBQWEsQ0FBQyxpQkFBaUIsQ0FBQyxXQUFXLENBQUMsQ0FBQztRQUNsRCxJQUFJLENBQUMsYUFBYSxDQUFDLHdCQUF3QixDQUFDLFdBQVcsQ0FBQyxDQUFDO0lBQzdELENBQUM7O2dCQXhzQ2lCLGdCQUFnQjtnQkFDYixNQUFNO2dCQUNOLFlBQVk7Z0JBRUwsZUFBZTs7SUFkbEM7UUFBUixLQUFLLEVBQUU7a0NBQU0sS0FBSzt3Q0FBTTtJQUNoQjtRQUFSLEtBQUssRUFBRTtrQ0FBUyxLQUFLOzJDQUFlO0lBQzVCO1FBQVIsS0FBSyxFQUFFOzsyQ0FBc0I7SUFDckI7UUFBUixLQUFLLEVBQUU7O3dDQUFnQjtJQUNkO1FBQVQsTUFBTSxFQUFFO2tDQUFtQixZQUFZO3FEQUErQjtJQUN2QztRQUEvQixXQUFXLENBQUMsaUJBQWlCLENBQUM7O2dEQUFzQjtJQUNyQjtRQUEvQixXQUFXLENBQUMsaUJBQWlCLENBQUM7O21EQUFnQztJQWMvRDtRQURDLFlBQVksQ0FBQyxlQUFlLEVBQUUsQ0FBQyxRQUFRLENBQUMsQ0FBQzs7eUNBQ3pCLEtBQUs7OzJDQUVyQjtJQS9DUSxPQUFPO1FBUm5CLFNBQVMsQ0FBQztZQUNQLFFBQVEsRUFBRSxVQUFVO1lBQ3BCLGs1QkFBc0M7WUFDdEMsYUFBYSxFQUFFLGlCQUFpQixDQUFDLElBQUk7WUFDckMsU0FBUyxFQUFFLENBQUMsWUFBWSxFQUFFLGVBQWUsRUFBRSxnQkFBZ0IsRUFBRSxvQkFBb0IsQ0FBQztZQUNsRixJQUFJLEVBQUUsRUFBRSxPQUFPLEVBQUUsV0FBVyxFQUFFO1NBQ2pDLENBQUM7eUNBcUNvQixnQkFBZ0I7WUFDYixNQUFNO1lBQ04sWUFBWTtZQUVMLGVBQWU7T0F2Q2xDLE9BQU8sQ0E0dUNuQjtJQUFELGNBQUM7Q0FBQSxBQTV1Q0QsSUE0dUNDO1NBNXVDWSxPQUFPIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHtcclxuICAgIENvbXBvbmVudCxcclxuICAgIE9uSW5pdCxcclxuICAgIE9uQ2hhbmdlcyxcclxuICAgIE9uRGVzdHJveSxcclxuICAgIFNpbXBsZUNoYW5nZXMsXHJcbiAgICBWaWV3RW5jYXBzdWxhdGlvbixcclxuICAgIElucHV0LFxyXG4gICAgSG9zdEJpbmRpbmcsXHJcbiAgICBIb3N0TGlzdGVuZXIsXHJcbiAgICBWaWV3Q29udGFpbmVyUmVmLFxyXG4gICAgRXZlbnRFbWl0dGVyLFxyXG4gICAgT3V0cHV0XHJcbn0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XHJcbmltcG9ydCB7IFJvdXRlciB9IGZyb20gJ0Bhbmd1bGFyL3JvdXRlcic7XHJcbmltcG9ydCB7IE9ic2VydmFibGUsIHRpbWVyLCBTdWJzY3JpcHRpb24sIFN1YnNjcmliZXIgfSBmcm9tICdyeGpzJztcclxuaW1wb3J0IHtcclxuICAgIEdyaWRPcHRpb25zLFxyXG4gICAgUm93Tm9kZSxcclxuICAgIFJvd0V2ZW50LFxyXG4gICAgTW9kZWxVcGRhdGVkRXZlbnQsXHJcbiAgICBFeGNlbEV4cG9ydFBhcmFtcyxcclxuICAgIENvbHVtbixcclxuICAgIC8vIENvbERlZixcclxuICAgIC8vIElFbnRlcnByaXNlRGF0YXNvdXJjZSxcclxuICAgIC8vIElFbnRlcnByaXNlR2V0Um93c1BhcmFtcyxcclxufSBmcm9tICdhZy1ncmlkLWNvbW11bml0eSc7XHJcbmltcG9ydCB7XHJcbiAgICAgICAgIElFbnRlcnByaXNlRGF0YXNvdXJjZSxcclxuICAgICAgICAgSUVudGVycHJpc2VHZXRSb3dzUGFyYW1zLFxyXG4gICAgfSBmcm9tICcuL2VudGVycHJpc2UtZGF0YXNvdXJjZSc7IFxyXG5pbXBvcnQgJ2FnLWdyaWQtZW50ZXJwcmlzZSc7XHJcbmltcG9ydCAqIGFzIFhMU1ggZnJvbSAneGxzeCc7XHJcbmltcG9ydCB7IHNhdmVBcyB9IGZyb20gJ2ZpbGUtc2F2ZXInO1xyXG5cclxuaW1wb3J0IHtcclxuICAgIElUYWJsZUNvbHVtbixcclxuICAgIElUYWJsZUNvbmZpZyxcclxuICAgIElTdHlsaW5nQ29uZmlnLFxyXG4gICAgSVRhYmxlUGl2b3RTdGF0ZSxcclxuICAgIElUYWJsZUJ1dHRvbixcclxuICAgIElUYWJsZUNlbGxQYXJhbXMsXHJcbiAgICBJVGFibGVGb3JtRW1pdFBhcmFtcyxcclxuICAgIElUYWJsZURhdGFzb3VyY2VQYXJhbXMsXHJcbiAgICBJVGFibGVBcGksXHJcbiAgICBJVGFibGVEcm9wZG93bkFjdGlvbixcclxuICAgIEtkVGFibGVEYXRhc291cmNlRXZlbnQsXHJcbiAgICBLZFRhYmxlU2VsZWN0aW9uVXBkYXRlRXZlbnQsXHJcbiAgICBLZFRhYmxlSW5wdXRVcGRhdGVFdmVudCxcclxuICAgIEtkVGFibGVCdXR0b25FdmVudFxyXG59IGZyb20gJy4va2QtYW5ndWxhci10YWJsZS1pbnRlcmZhY2UnO1xyXG5cclxuaW1wb3J0IHsgS2RJbnRUYWJsZUV2ZW50IH0gZnJvbSAnLi9rZC1hbmd1bGFyLXRhYmxlLWV2ZW50JztcclxuaW1wb3J0IHsgS2RUYWJsZU5vcm1hbFN2YyB9IGZyb20gJy4vdGFibGUtc2VydmljZXMva2QtdGFibGUtbm9ybWFsLXN2Yyc7XHJcbmltcG9ydCB7IEtkVGFibGVFbnRlcnByaXNlU3ZjIH0gZnJvbSAnLi90YWJsZS1zZXJ2aWNlcy9rZC10YWJsZS1lbnRlcnByaXNlLXN2Yyc7XHJcbi8vIGltcG9ydCB7IEtkU3BsaXR0ZXJFdmVudCB9IGZyb20gJy4uLyc7XHJcbmltcG9ydCB7IEtkRG9tRWxlbVN2YywgQUdfR1JJRF9LRVkgfSBmcm9tICcuLi9rZC1jb21tb24vaW5kZXgnO1xyXG5pbXBvcnQge0xpY2Vuc2VNYW5hZ2VyfSBmcm9tIFwiYWctZ3JpZC1lbnRlcnByaXNlXCI7XHJcblxyXG5kZWNsYXJlIHZhciByZXF1aXJlOiBhbnk7XHJcblxyXG4vKipcclxuICogLS0gRG9jdW1lbnRhdGlvbiBmb3Iga2QtYW5ndWxhci10YWJsZS50cyAoa2QtdGFibGUpXHJcbiAqXHJcbiAqIC0gSG9zdExpc3RlbmVyXHJcbiAqICAgICAtIG9uUmVzaXplXHJcbiAqXHJcbiAqIC0gTGlmZSBjeWNsZXM6XHJcbiAqICAgICAtIG5nT25Jbml0XHJcbiAqICAgICAtIG5nT25DaGFuZ2VzXHJcbiAqICAgICAtIG5nT25EZXN0cm95XHJcblxyXG4gKiAtIGFnLUdyaWQgZXZlbnRzIGZ1bmN0aW9uOlxyXG4gKiAgICAgLSBvbkdyaWRSZWFkeVxyXG4gKiAgICAgLSBvbk1vZGVsVXBkYXRlZFxyXG4gKiAgICAgLSBvblJvd0NsaWNrZWRcclxuICpcclxuICogLSBrZC10YWJsZSBidXR0b24gZnVuY3Rpb246XHJcbiAqICAgICAtIG9uQnV0dG9uQ2xpY2VrZFxyXG4gKlxyXG4gKiAtIFByaXZhdGUgZnVuY3Rpb25zOlxyXG4gKiAgICAgLSBEaXNwbGF5IC8gRE9NIGZ1bmN0aW9uczpcclxuICogICAgICAgICAtIF9yZXNpemVDb2x1bW5cclxuICogICAgICAgICAtIF9zaG93TG9hZGluZ092ZXJsYXlcclxuICogICAgICAgICAtIF91cGRhdGVQYXJlbnROb2RlQ1NTXHJcbiAqICAgICAgICAgLSBfc2V0SGVpZ2h0XHJcbiAqICAgICAgICAgLSBfc2V0TW9iaWxlSGVpZ2h0IChmbGF0dGVuIHRhYmxlKVxyXG4gKiAgICAgICAgIC0gX3NldFdlYkhlaWdociAodXNlciBjb25maWd1cmF0aW9uKVxyXG4gKiAgICAgICAgIC0gX2lzQ2xpY2tWYWxpZCAoY2xpY2sgY29uZmlndXJhdGlvbilcclxuICpcclxuICogICAgIC0gR3JpZCBDeWNsZXM6XHJcbiAqICAgICAgICAgLSBfZ3JpZEluaXRDeWNsZVxyXG4gKiAgICAgICAgIC0gX2dyaWRSZWFkeUN5Y2xlXHJcbiAqICAgICAgICAgLSBfZ3JpZFJlYWR5RW50ZXJwcmlzZUN5Y2xlXHJcbiAqICAgICAgICAgLSBfZ3JpZFJlYWR5RE9NQ3ljbGVcclxuICogICAgICAgICAtIF9ncmlkU2VsZWN0aW9uQ3ljbGVcclxuICogICAgICAgICAtIF9ncmlkU2V0Um93Q3ljbGVcclxuICogICAgICAgICAtIF9ncmlkQ2xpY2tOYXZpZ2F0ZUN5Y2xlXHJcbiAqXHJcbiAqICAgICAtIENvbHVtbiAvIFJvdyAvIENvbmZpZyBnZW5lcmF0aW9ucy9wcm9jZXNzaW5nOlxyXG4gKiAgICAgICAgIC0gX3NldEdyaWRPcHRpb25zXHJcbiAqICAgICAgICAgLSBfc2V0Q29sdW1uRGVmXHJcbiAqICAgICAgICAgLSBfc2V0Um93RGF0YVxyXG4gKlxyXG4gKiAgICAgLSBFdmVudCBmdW5jdGlvbnM6XHJcbiAqICAgICAgICAgLSBfcHJvY2Vzc0V2ZW50UGFyYW1zPFQ+XHJcbiAqICAgICAgICAgLSBfYnJvYWRjYXN0RXZlbnRQYXJhbXNcclxuICogICAgICAgICAtIF9icm9hZGNhc3RNb2RlbENoYW5nZWRcclxuICogICAgICAgICAtIF9zZXR1cFN1YnNjcmlwdGlvbkV2ZW50c1xyXG4gKlxyXG4gKiAgICAgLSBTZWxlY3Rpb24gZnVuY3Rpb25zOlxyXG4gKiAgICAgICAgIC0gX3VwZGF0ZVNlbGVjdGlvbk5vZGVzXHJcbiAqICAgICAgICAgLSBfcHJvY2Vzc0luaXRpYWxTZWxlY3Rpb25cclxuICpcclxuICogICAgIC0gSW5wdXQgZnVuY3Rpb25zOlxyXG4gKiAgICAgICAgIC0gX3Byb2Nlc3NJbnB1dENoYW5nZWRcclxuICogICAgICAgICAtIF9lbWl0SW5wdXRVcGRhdGVFdmVudFxyXG4gKiAgICAgICAgIC0gX2RlbGV0ZU5vZGVGcm9tUm93RGF0YVxyXG4gKlxyXG4gKiAgICAgLSBEYXRhc291cmNlIGZ1bmN0aW9uczpcclxuICogICAgICAgICAtIF9jbGVhckRhdGFzb3VyY2VcclxuICogICAgICAgICAtIF9nZW5lcmF0ZUVudGVycHJpc2VEYXRhc291cmNlXHJcbiAqICAgICAgICAgLSBfZ2VuZXJhdGVEYXRhc291cmNlUm93c1xyXG4gKlxyXG4gKiAgICAgLSBBUEkgZ2VuZXJhdGlvbnM6XHJcbiAqICAgICAgICAgLSBfaW5pdElUYWJsZUFwaSAoVE9ETzogdXBkYXRlIGFwaSBzZXR0aW5nIGFsbCB0byB0YWJsZSBzZXJ2aWNlKVxyXG4gKlxyXG4gKiAgICAgLSBNaXNjIGZ1bmN0aW9uczpcclxuICogICAgICAgICAtIF9pbml0R3JpZFNlcnZpY2VcclxuICogICAgICAgICAtIF91cGRhdGVHcmlkQ29uZmlnXHJcbiAqL1xyXG5cclxuXHJcblxyXG5AQ29tcG9uZW50KHtcclxuICAgIHNlbGVjdG9yOiAna2QtdGFibGUnLFxyXG4gICAgdGVtcGxhdGVVcmw6ICcuL2tkLWFuZ3VsYXItdGFibGUuaHRtbCcsXHJcbiAgICBlbmNhcHN1bGF0aW9uOiBWaWV3RW5jYXBzdWxhdGlvbi5Ob25lLFxyXG4gICAgcHJvdmlkZXJzOiBbS2REb21FbGVtU3ZjLCBLZEludFRhYmxlRXZlbnQsIEtkVGFibGVOb3JtYWxTdmMsIEtkVGFibGVFbnRlcnByaXNlU3ZjXSxcclxuICAgIGhvc3Q6IHsgJ2NsYXNzJzogJ2tkeC10YWJsZScgfVxyXG59KVxyXG5cclxuZXhwb3J0IGNsYXNzIEtkVGFibGUgaW1wbGVtZW50cyBPbkluaXQsIE9uQ2hhbmdlcywgT25EZXN0cm95IHtcclxuICAgIHB1YmxpYyBncmlkSWQ6IHN0cmluZyA9ICcnO1xyXG4gICAgcHVibGljIGdyaWRPcHRpb25zOiBHcmlkT3B0aW9ucztcclxuICAgIHB1YmxpYyBkaXNwbGF5TG9hZGluZzogYm9vbGVhbiA9IHRydWU7XHJcblxyXG4gICAgcHJpdmF0ZSBfZW50ZXJwcmlzZSA9IHJlcXVpcmUoJ2FnLWdyaWQtZW50ZXJwcmlzZScpO1xyXG4gICAgcHJpdmF0ZSBfaXNNb2JpbGVWaWV3OiBib29sZWFuO1xyXG4gICAgcHJpdmF0ZSBfdGFibGVTZXJ2aWNlOiBLZFRhYmxlTm9ybWFsU3ZjIHwgS2RUYWJsZUVudGVycHJpc2VTdmM7XHJcbiAgICBwcml2YXRlIF9zdWJzY3JpcHRpb25PYmo6IHsgW2tleTogc3RyaW5nXTogU3Vic2NyaXB0aW9uIH0gPSB7fTtcclxuXHJcbiAgICBwcml2YXRlIF9jdXJyZW50U3RhdGU6IElUYWJsZVBpdm90U3RhdGUgPSB7XHJcbiAgICAgICAgY29sdW1uU3RhdGU6IFtdLFxyXG4gICAgICAgIHBpdm90TW9kZTogZmFsc2UsXHJcbiAgICAgICAgZ3JvdXBTdGF0ZTogW11cclxuICAgIH07XHJcbiAgICBwcml2YXRlIF9pc0NoYW5naW5nU3RhdGU6IGJvb2xlYW4gPSBmYWxzZTtcclxuICAgIHByaXZhdGUgX3Bpdm90RWxlbWVudDogeyBba2V5OiBzdHJpbmddOiBhbnkgfSA9IHtcclxuICAgICAgICAncGl2b3QnOiBudWxsLFxyXG4gICAgICAgICdjb2x1bW4tZHJvcCc6IG51bGxcclxuICAgIH07XHJcbiAgICBwcml2YXRlIF9wcmV2aW91c1Rvb2xwYW5lbFR5cGU6ICdub25lJyB8ICdjb2x1bW5zJyB8ICdwaXZvdCc7XHJcbiAgICBwcml2YXRlIF9zdXBwcmVzc01vdmFibGVDb2x1bW5zOiBib29sZWFuID0gdHJ1ZTtcclxuXHJcbiAgICBwcml2YXRlIF9kaXJlY3Rpb246ICdsdHInIHwgJ3J0bCcgPSAnbHRyJztcclxuXHJcbiAgICBASW5wdXQoKSByb3c6IEFycmF5PGFueT47XHJcbiAgICBASW5wdXQoKSBjb2x1bW46IEFycmF5PElUYWJsZUNvbHVtbj47XHJcbiAgICBASW5wdXQoKSBjb25maWc6IElUYWJsZUNvbmZpZztcclxuICAgIEBJbnB1dCgpIGFwaTogSVRhYmxlQXBpO1xyXG4gICAgQE91dHB1dCgpIG9uRXhwb3J0UG9zc2libGU6IEV2ZW50RW1pdHRlcjxib29sZWFuPiA9IG5ldyBFdmVudEVtaXR0ZXIoKTtcclxuICAgIEBIb3N0QmluZGluZygnY2xhc3MuZnVsbC1ncmlkJykgZGlzcGxheUZ1bGw6IGJvb2xlYW47XHJcbiAgICBASG9zdEJpbmRpbmcoJ2NsYXNzLmtkeC10YWJsZScpIF9jbGFzc0tkeFRhYmxlOiBib29sZWFuID0gdHJ1ZTtcclxuICAgIFxyXG4gICAgcHVibGljIGRlZmF1bHRDb2xEZWY6YW55O1xyXG4gICAgY29uc3RydWN0b3IoXHJcbiAgICAgICAgcHJpdmF0ZSBfdmNyOiBWaWV3Q29udGFpbmVyUmVmLFxyXG4gICAgICAgIHByaXZhdGUgX3JvdXRlcjogUm91dGVyLFxyXG4gICAgICAgIHByaXZhdGUgX2RvbVN2YzogS2REb21FbGVtU3ZjLFxyXG4gICAgICAgIC8vIHByaXZhdGUgX3NwbGl0dGVyRXZlbnQ6IEtkU3BsaXR0ZXJFdmVudCxcclxuICAgICAgICBwcml2YXRlIF90YWJsZUludEV2ZW50OiBLZEludFRhYmxlRXZlbnQsXHJcbiAgICApIHtcclxuICAgICAgICBMaWNlbnNlTWFuYWdlci5zZXRMaWNlbnNlS2V5KEFHX0dSSURfS0VZLnZhbHVlKTtcclxuICAgIH1cclxuXHJcbiAgICBASG9zdExpc3RlbmVyKCd3aW5kb3c6cmVzaXplJywgWyckZXZlbnQnXSlcclxuICAgIG9uUmVzaXplKF9ldmVudDogRXZlbnQpOiB2b2lkIHtcclxuICAgICAgICB0aGlzLl9zZXRIZWlnaHQoKTtcclxuICAgIH1cclxuXHJcbiAgICAvKioqKioqKioqKioqKioqKioqKioqKioqKiBMaWZlIGN5Y2xlcyBmdW5jdGlvbnMgKioqKioqKioqKioqKioqKioqKioqKioqKioqKiovXHJcbiAgICBuZ09uSW5pdCgpOiB2b2lkIHtcclxuICAgICAgICAvLyBjb25zb2xlLmxvZyhcIi0tIEdyaWQgc3RhdGU6IEluaXQgLS1cIiwgdGhpcy5yb3csIHRoaXMuY29sdW1uLCB0aGlzLmNvbmZpZywgdGhpcy5hcGkpO1xyXG4gICAgICAgIHRoaXMuX3Nob3dMb2FkaW5nT3ZlcmxheSh0cnVlKTtcclxuICAgICAgICB0aGlzLl9ncmlkSW5pdEN5Y2xlKCk7XHJcbiAgICB9XHJcblxyXG4gICAgbmdPbkNoYW5nZXMoX3NpbXBsZUNoYW5nZXM6IFNpbXBsZUNoYW5nZXMpOiB2b2lkIHtcclxuICAgICAgICB0aGlzLl9zaG93TG9hZGluZ092ZXJsYXkodHJ1ZSk7XHJcbiAgICAgICAgY29uc29sZS5sb2coXCItLSBHcmlkIHN0YXRlOiBDaGFuZ2UgLS0gXCIsIF9zaW1wbGVDaGFuZ2VzKTtcclxuXHJcbiAgICAgICAgaWYgKHR5cGVvZiBfc2ltcGxlQ2hhbmdlcy5jb2x1bW4gIT09ICd1bmRlZmluZWQnICYmXHJcbiAgICAgICAgICAgICFfc2ltcGxlQ2hhbmdlcy5jb2x1bW4uZmlyc3RDaGFuZ2VcclxuICAgICAgICApIHtcclxuICAgICAgICAgICAgdGhpcy5fc2V0Q29sdW1uRGVmKF9zaW1wbGVDaGFuZ2VzLmNvbHVtbi5jdXJyZW50VmFsdWUpO1xyXG4gICAgICAgICAgICB0aGlzLl9zaG93TG9hZGluZ092ZXJsYXkoZmFsc2UpO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgaWYgKHR5cGVvZiBfc2ltcGxlQ2hhbmdlcy5yb3cgIT09ICd1bmRlZmluZWQnICYmXHJcbiAgICAgICAgICAgICFfc2ltcGxlQ2hhbmdlcy5yb3cuZmlyc3RDaGFuZ2VcclxuICAgICAgICApIHtcclxuICAgICAgICAgICAgdGhpcy5fc2V0Um93RGF0YShfc2ltcGxlQ2hhbmdlcy5yb3cuY3VycmVudFZhbHVlKTtcclxuICAgICAgICAgICAgdGhpcy5fc2hvd0xvYWRpbmdPdmVybGF5KGZhbHNlKTtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIGlmICh0eXBlb2YgX3NpbXBsZUNoYW5nZXMuY29uZmlnICE9PSAndW5kZWZpbmVkJykge1xyXG4gICAgICAgICAgICB0aGlzLl9zaG93TG9hZGluZ092ZXJsYXkoZmFsc2UpO1xyXG4gICAgICAgICAgICB0aGlzLnVwZGF0ZVN0eWxlKF9zaW1wbGVDaGFuZ2VzLmNvbmZpZy5jdXJyZW50VmFsdWUpO1xyXG5cclxuICAgICAgICAgICAgdGltZXIoMTAwKS5zdWJzY3JpYmUoKCk6IHZvaWQgPT4ge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5fY29uZmlndXJlUGl2b3REaXNwbGF5KCk7XHJcblxyXG4gICAgICAgICAgICAgICAgaWYgKHR5cGVvZiB0aGlzLmNvbmZpZy5zdXBwcmVzc01vdmFibGVDb2x1bW5zICE9PSAndW5kZWZpbmVkJ1xyXG4gICAgICAgICAgICAgICAgKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKHRoaXMuY29uZmlnLnN1cHByZXNzTW92YWJsZUNvbHVtbnMgIT09IHRoaXMuX3N1cHByZXNzTW92YWJsZUNvbHVtbnMpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuX2VuYWJsZUNvbHVtbk1vdmFibGUodGhpcy5jb25maWcuc3VwcHJlc3NNb3ZhYmxlQ29sdW1ucyk7XHJcbiAgICAgICAgICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuY29uZmlnLnN1cHByZXNzTW92YWJsZUNvbHVtbnMgPSB0aGlzLl9zdXBwcmVzc01vdmFibGVDb2x1bW5zO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9KTtcclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgbmdPbkRlc3Ryb3koKTogdm9pZCB7XHJcbiAgICAgICAgLy8gY29uc29sZS5sb2coXCItLSBHcmlkIHN0YXRlOiBEZXN0cm95aW5nIC0tXCIpO1xyXG4gICAgICAgIGZvciAobGV0IGl0ZW0gaW4gdGhpcy5fc3Vic2NyaXB0aW9uT2JqKSB7XHJcbiAgICAgICAgICAgIGlmICh0eXBlb2YgdGhpcy5fc3Vic2NyaXB0aW9uT2JqW2l0ZW1dICE9PSAndW5kZWZpbmVkJykge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5fc3Vic2NyaXB0aW9uT2JqW2l0ZW1dLnVuc3Vic2NyaWJlKCk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgLyoqKioqKioqKioqKioqKioqKioqKioqKioqKioqKiogR3JpZCBldmVudHMgKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqL1xyXG4gICAgcHVibGljIG9uR3JpZFJlYWR5KF9wYXJhbXM6IGFueSk6IHZvaWQge1xyXG4gICAgICAgIC8vIGNvbnNvbGUubG9nKCctLSBHcmlkIHN0YXRlOiBSZWFkeSAtLScsIHRoaXMuZ3JpZE9wdGlvbnMpO1xyXG4gICAgICAgIHRoaXMuX2dyaWRSZWFkeUN5Y2xlKCk7XHJcblxyXG4gICAgICAgIFxyXG4gICAgfVxyXG5cclxuICAgIHB1YmxpYyBvbk1vZGVsVXBkYXRlZChfZXZlbnQ6IE1vZGVsVXBkYXRlZEV2ZW50KTogdm9pZCB7XHJcbiAgICAgICAgLy8vIEZvciBzZWxlY3QgYWxsIGNoZWNrYm94IGNoZWNraW5nIG9uIGNoYW5nZSBwYWdpbmF0aW9uL3VwZGF0ZSByb3cgZGF0YVxyXG4gICAgICAgIGlmICh0aGlzLl90YWJsZVNlcnZpY2UuaGFzU2VsZWN0aW9uQWxsKHRoaXMuY29uZmlnKSkge1xyXG4gICAgICAgICAgICB0aGlzLl9icm9hZGNhc3RNb2RlbENoYW5nZWRFdmVudCgpO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgaWYgKHRoaXMuX2lzTW9iaWxlVmlldykge1xyXG4gICAgICAgICAgICBsZXQgZ3JpZEVsZW1lbnQ6IEVsZW1lbnQgPSBkb2N1bWVudC5xdWVyeVNlbGVjdG9yKCcjJyArIHRoaXMuZ3JpZElkICsgJy5zdGctdGhlbWUnKTtcclxuXHJcbiAgICAgICAgICAgIGlmIChncmlkRWxlbWVudCAhPT0gbnVsbCkge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5fc2V0TW9iaWxlSGVpZ2h0KGdyaWRFbGVtZW50KTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICBwdWJsaWMgb25Sb3dDbGlja2VkKF9wYXJhbXM6IFJvd0V2ZW50KTogdm9pZCB7XHJcbiAgICAgICAgLy8gY29uc29sZS5sb2coXCItLSBHcmlkIHN0YXRlOiBSb3cgY2xpY2tlZCAtLVwiLCBfcGFyYW1zKTtcclxuICAgICAgICBpZiAodGhpcy5faXNDbGlja1ZhbGlkKF9wYXJhbXMuZXZlbnQpICYmIHR5cGVvZiB0aGlzLmNvbmZpZy5jbGljayAhPT0gJ3VuZGVmaW5lZCcpIHtcclxuICAgICAgICAgICAgc3dpdGNoICh0aGlzLmNvbmZpZy5jbGljay50eXBlKSB7XHJcbiAgICAgICAgICAgICAgICBjYXNlICdzZWxlY3Rpb24nOlxyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuX2dyaWRTZWxlY3Rpb25DeWNsZShfcGFyYW1zLm5vZGUpO1xyXG4gICAgICAgICAgICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgICAgICAgICAgY2FzZSAncm91dGVyJzpcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLl9ncmlkQ2xpY2tOYXZpZ2F0ZUN5Y2xlKF9wYXJhbXMubm9kZSk7XHJcbiAgICAgICAgICAgICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgICAgICAgICBkZWZhdWx0OlxyXG4gICAgICAgICAgICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICBpZiAodHlwZW9mIHRoaXMuY29uZmlnLmNsaWNrLmNhbGxiYWNrICE9PSAndW5kZWZpbmVkJykge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5jb25maWcuY2xpY2suY2FsbGJhY2soKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICAvKioqKioqKioqKioqKioqKioqKioqKioqKioqKiogQnV0dG9uIGZ1bmN0aW9ucyAqKioqKioqKioqKioqKioqKioqKioqKioqKioqKiovXHJcbiAgICBwdWJsaWMgb25CdXR0b25DbGlja2VkKF9idXR0b246IElUYWJsZUJ1dHRvbik6IHZvaWQge1xyXG4gICAgICAgIGxldCBidXR0b25FdmVudDogS2RUYWJsZUJ1dHRvbkV2ZW50ID0gbmV3IEtkVGFibGVCdXR0b25FdmVudChfYnV0dG9uKTtcclxuICAgICAgICB0aGlzLl9wcm9jZXNzRXZlbnRQYXJhbXM8S2RUYWJsZUJ1dHRvbkV2ZW50PignYnV0dG9uJywgYnV0dG9uRXZlbnQpO1xyXG4gICAgfVxyXG5cclxuICAgIC8qKioqKioqKioqKioqKioqKioqKioqKioqKioqIFByaXZhdGUgZnVuY3Rpb25zICoqKioqKioqKioqKioqKioqKioqKioqKioqKioqKi9cclxuICAgIC8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vXHJcbiAgICAvLy8gR3JpZCBjeWNsZXNcclxuICAgIC8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vXHJcbiAgICBwcml2YXRlIF9ncmlkSW5pdEN5Y2xlKCk6IHZvaWQge1xyXG4gICAgICAgIGlmICh0eXBlb2YgdGhpcy5jb25maWcgIT09ICd1bmRlZmluZWQnKSB7XHJcbiAgICAgICAgICAgIHRoaXMuX2luaXRHcmlkU2VydmljZSh0aGlzLmNvbmZpZy5sb2FkVHlwZSk7XHJcbiAgICAgICAgICAgIHRoaXMuX3VwZGF0ZUdyaWRDb25maWcodGhpcy5jb25maWcpO1xyXG4gICAgICAgICAgICB0aGlzLl9zZXRHcmlkT3B0aW9ucyh0aGlzLmNvbmZpZyk7XHJcbiAgICAgICAgICAgIHRoaXMuX3NldHVwU3Vic2NyaXB0aW9uRXZlbnRzKCk7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICBpZiAodHlwZW9mIHRoaXMuY29sdW1uICE9PSAndW5kZWZpbmVkJykge1xyXG4gICAgICAgICAgICB0aGlzLl9zZXRDb2x1bW5EZWYodGhpcy5jb2x1bW4pO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgaWYgKHR5cGVvZiB0aGlzLnJvdyAhPT0gJ3VuZGVmaW5lZCcpIHtcclxuICAgICAgICAgICAgdGhpcy5fc2V0Um93RGF0YSh0aGlzLnJvdyk7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX2dyaWRSZWFkeUN5Y2xlKCk6IHZvaWQge1xyXG4gICAgICAgIHRoaXMuX2luaXRJVGFibGVBcGkoKTtcclxuXHJcbiAgICAgICAgaWYgKHRoaXMuX3RhYmxlU2VydmljZS5pc0VudGVycHJpc2VNb2RlbCh0aGlzLmNvbmZpZy5sb2FkVHlwZSkpIHtcclxuICAgICAgICAgICAgdGhpcy5fZ3JpZFJlYWR5RW50ZXJwcmlzZUN5Y2xlKCk7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICB0aGlzLl9ncmlkUmVhZHlET01DeWNsZSgpO1xyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX2dyaWRSZWFkeUVudGVycHJpc2VDeWNsZSgpOiB2b2lkIHtcclxuICAgICAgICB0aGlzLl9jbGVhckRhdGFzb3VyY2UoKTtcclxuICAgICAgICB0aGlzLl9nZW5lcmF0ZUVudGVycHJpc2VEYXRhc291cmNlKCk7XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfZ3JpZFJlYWR5RE9NQ3ljbGUoKTogdm9pZCB7XHJcbiAgICAgICAgdGhpcy5fdXBkYXRlUGFyZW50Tm9kZUNTUygpO1xyXG4gICAgICAgIHRoaXMuX3NldEhlaWdodCgpO1xyXG4gICAgICAgIHRoaXMuX3Jlc2l6ZUNvbHVtbigpO1xyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX2dyaWRTZWxlY3Rpb25DeWNsZShfcm93Tm9kZTogUm93Tm9kZSk6IHZvaWQge1xyXG4gICAgICAgIGlmICh0eXBlb2YgdGhpcy5jb25maWcuc2VsZWN0aW9uID09PSAndW5kZWZpbmVkJykge1xyXG4gICAgICAgICAgICBjb25zb2xlLmVycm9yKCdLZFRhYmxlIGVycm9yOiBVc2VyIGhhdmUgc2V0IGNsaWNrIHR5cGUgdG8gYmUgc2VsZWN0aW9uIGJ1dCBubyBzZWxlY3Rpb24gaXMgZGVmaW5lZC4gRG8geW91IG1lYW4gY2xpY2sgdHlwZSB0byByb3V0ZXI/Jyk7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGVsc2UgaWYgKHRoaXMuY29uZmlnLnNlbGVjdGlvbi50eXBlID09PSAnc2luZ2xlJykge1xyXG4gICAgICAgICAgICBpZiAodGhpcy5jb25maWcuc2VsZWN0aW9uLnZhbHVlLmluZGV4T2YoX3Jvd05vZGUuaWQpIDwgMCkge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5ncmlkT3B0aW9ucy5hcGkuZGVzZWxlY3RBbGwoKTtcclxuICAgICAgICAgICAgICAgIF9yb3dOb2RlLnNlbGVjdFRoaXNOb2RlKHRydWUpO1xyXG5cclxuICAgICAgICAgICAgICAgIHRoaXMuY29uZmlnLnNlbGVjdGlvbi52YWx1ZS5zcGxpY2UoMCwgdGhpcy5jb25maWcuc2VsZWN0aW9uLnZhbHVlLmxlbmd0aCk7XHJcbiAgICAgICAgICAgICAgICB0aGlzLmNvbmZpZy5zZWxlY3Rpb24udmFsdWUucHVzaChfcm93Tm9kZS5kYXRhLmlkKTtcclxuXHJcbiAgICAgICAgICAgICAgICB0aGlzLl9icm9hZGNhc3RNb2RlbENoYW5nZWRFdmVudCgpO1xyXG4gICAgICAgICAgICAgICAgdGhpcy5fdXBkYXRlU2VsZWN0aW9uTm9kZXMoX3Jvd05vZGUpO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICBsZXQgc2VsZWN0aW9uOiBib29sZWFuID0gIV9yb3dOb2RlLmlzU2VsZWN0ZWQoKTtcclxuICAgICAgICAgICAgX3Jvd05vZGUuc2VsZWN0VGhpc05vZGUoc2VsZWN0aW9uKTtcclxuXHJcbiAgICAgICAgICAgIHRoaXMuX2Jyb2FkY2FzdE1vZGVsQ2hhbmdlZEV2ZW50KCk7XHJcblxyXG4gICAgICAgICAgICBpZiAoc2VsZWN0aW9uKSB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLmNvbmZpZy5zZWxlY3Rpb24udmFsdWUucHVzaChfcm93Tm9kZS5kYXRhLmlkKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgICAgIHRoaXMuY29uZmlnLnNlbGVjdGlvbi52YWx1ZS5zcGxpY2UodGhpcy5jb25maWcuc2VsZWN0aW9uLnZhbHVlLmluZGV4T2YoX3Jvd05vZGUuZGF0YS5pZCksIDEpO1xyXG4gICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICB0aGlzLl91cGRhdGVTZWxlY3Rpb25Ob2Rlcyhfcm93Tm9kZSk7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX2dyaWRTZXRSb3dDeWNsZSgpOiB2b2lkIHtcclxuICAgICAgICBpZiAodHlwZW9mIHRoaXMuY29uZmlnLnNlbGVjdGlvbiAhPT0gJ3VuZGVmaW5lZCcgJiYgdHlwZW9mIHRoaXMuY29uZmlnLnNlbGVjdGlvbi50eXBlICE9PSAndW5kZWZpbmVkJykge1xyXG4gICAgICAgICAgICB0aGlzLl9wcm9jZXNzSW5pdGlhbFNlbGVjdGlvbigpO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgZWxzZSBpZiAodGhpcy5fdGFibGVTZXJ2aWNlLmhhc0lucHV0VHlwZSh0aGlzLmNvbHVtbiwgJ2lucHV0JykpIHtcclxuICAgICAgICAgICAgdGhpcy5fZW1pdElucHV0VXBkYXRlRXZlbnQoKTtcclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfZ3JpZENsaWNrTmF2aWdhdGVDeWNsZShfcm93Tm9kZTogUm93Tm9kZSk6IHZvaWQge1xyXG4gICAgICAgIGlmICh0eXBlb2YgdGhpcy5jb25maWcuY2xpY2sucGF0aE1hcCAhPT0gJ3VuZGVmaW5lZCcpIHtcclxuICAgICAgICAgICAgaWYgKHR5cGVvZiB0aGlzLmNvbmZpZy5hY3Rpb24gIT09ICd1bmRlZmluZWQnICYmXHJcbiAgICAgICAgICAgICAgICB0eXBlb2YgdGhpcy5jb25maWcuYWN0aW9uLmxpc3QgIT09ICd1bmRlZmluZWQnKSB7XHJcbiAgICAgICAgICAgICAgICBsZXQgcm91dGVyUGF0aDogc3RyaW5nID0gJyc7XHJcblxyXG4gICAgICAgICAgICAgICAgZm9yIChsZXQgaTogbnVtYmVyID0gMDsgaSA8IHRoaXMuY29uZmlnLmFjdGlvbi5saXN0Lmxlbmd0aDsgKytpKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgbGV0IGFjdGlvbkl0ZW06IElUYWJsZURyb3Bkb3duQWN0aW9uID0gdGhpcy5jb25maWcuYWN0aW9uLmxpc3RbaV07XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIGlmIChhY3Rpb25JdGVtLnR5cGUudG9Mb3dlckNhc2UoKSA9PT0gdGhpcy5jb25maWcuY2xpY2sucGF0aE1hcC50b0xvd2VyQ2FzZSgpKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHJvdXRlclBhdGggPSB0aGlzLl90YWJsZVNlcnZpY2UuZ2V0Um91dGVyUGxhY2Vob2xkZXJQYXRoKF9yb3dOb2RlLCBhY3Rpb25JdGVtLnBhdGgpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBicmVhaztcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICAgICAgaWYgKHJvdXRlclBhdGggIT09ICcnKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5fcm91dGVyLm5hdmlnYXRlKFtyb3V0ZXJQYXRoXSk7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgICAgICAgICBjb25zb2xlLndhcm4oJ0tkVGFibGUgd2FybmluZzogVGFibGUgcm91dGVyIHBhdGhNYXAgbm90IGZvdW5kLiBwYXRoTWFwIHNldCB0bzonLCB0aGlzLmNvbmZpZy5jbGljay5wYXRoTWFwKTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgICAgIGNvbnNvbGUuZXJyb3IoJ0tkVGFibGUgZXJyb3I6IFRhYmxlIGNsaWNrIGV2ZW50IHNldCB0byByb3V0ZXIgcGF0aE1hcCBidXQgbm8gYWN0aW9uIGxpc3QgaXMgZGVmaW5lZC4gRG8geW91IG1lYW4gcGF0aCBwcm9wZXJ0eSBpbnN0ZWFkIG9mIHBhdGhNYXAgcHJvcGVydHk/Jyk7XHJcbiAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgfVxyXG4gICAgICAgIGVsc2UgaWYgKHR5cGVvZiB0aGlzLmNvbmZpZy5jbGljay5wYXRoICE9PSAndW5kZWZpbmVkJykge1xyXG4gICAgICAgICAgICB0aGlzLl9yb3V0ZXIubmF2aWdhdGUoW3RoaXMuY29uZmlnLmNsaWNrLnBhdGhdKTtcclxuICAgICAgICB9XHJcbiAgICAgICAgZWxzZSB7XHJcbiAgICAgICAgICAgIGNvbnNvbGUuZXJyb3IoJ0tkVGFibGUgZXJyb3I6IFRhYmxlIGNsaWNrIGV2ZW50IHR5cGUgc2V0IGF0IHJvdXRlciBidXQgbm8gcGF0aCAvIHBhdGhNYXAgaXMgcHJvdmlkZWQuIERvIHlvdSBtZWFuIGNsaWNrIHR5cGUgc2VsZWN0aW9uIC8gbm9uZT8nKTtcclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy9cclxuICAgIC8vIERpc3BsYXkgLyBET00gZnVuY3Rpb25cclxuICAgIC8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vXHJcblxyXG4gICAgcHJpdmF0ZSBfc2hvd0xvYWRpbmdPdmVybGF5KF90b2dnbGU6IGJvb2xlYW4pOiB2b2lkIHtcclxuICAgICAgICB0aGlzLmRpc3BsYXlMb2FkaW5nID0gX3RvZ2dsZTtcclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF91cGRhdGVQYXJlbnROb2RlQ1NTKCk6IHZvaWQge1xyXG4gICAgICAgIHRoaXMuX3Zjci5lbGVtZW50Lm5hdGl2ZUVsZW1lbnQucGFyZW50Tm9kZS5jbGFzc05hbWUgKz0gJyBoYXMtYWdncmlkJztcclxuICAgICAgICBpZiAodGhpcy5fZGlyZWN0aW9uID09PSAncnRsJykgZG9jdW1lbnQucXVlcnlTZWxlY3RvcignYm9keScpLnN0eWxlLmNzc1RleHQgKz0gJy0ta2R0YWJsZS1oZWFkZXItdGV4dC1hbGlnbjogcmlnaHQ7JztcclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF9zZXRIZWlnaHQoKTogdm9pZCB7XHJcbiAgICAgICAgbGV0IGRvbUVsZVF1ZXJ5OiBzdHJpbmcgPSAnIycgKyB0aGlzLmdyaWRJZCArICcuc3RnLXRoZW1lJztcclxuICAgICAgICBsZXQgZ3JpZEVsZW1lbnQ6IEVsZW1lbnQgPSB0aGlzLl92Y3IuZWxlbWVudC5uYXRpdmVFbGVtZW50LnF1ZXJ5U2VsZWN0b3IoZG9tRWxlUXVlcnkpO1xyXG5cclxuICAgICAgICBpZiAoZ3JpZEVsZW1lbnQgIT09IG51bGwpIHtcclxuICAgICAgICAgICAgbGV0IHdpbmRvd3NXaWR0aDogbnVtYmVyID0gZG9jdW1lbnQuYm9keS5jbGllbnRXaWR0aDtcclxuXHJcbiAgICAgICAgICAgIGlmICh3aW5kb3dzV2lkdGggPD0gMTAyNCkge1xyXG4gICAgICAgICAgICAgICAgaWYgKHR5cGVvZiB0aGlzLl9pc01vYmlsZVZpZXcgPT09ICd1bmRlZmluZWQnIHx8ICF0aGlzLl9pc01vYmlsZVZpZXcpIHtcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLl9zaG93TG9hZGluZ092ZXJsYXkodHJ1ZSk7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5faXNNb2JpbGVWaWV3ID0gdHJ1ZTtcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLl9zZXRNb2JpbGVIZWlnaHQoZ3JpZEVsZW1lbnQpO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIGVsc2UgaWYgKHdpbmRvd3NXaWR0aCA+IDEwMjQpIHtcclxuICAgICAgICAgICAgICAgIGlmICh0eXBlb2YgdGhpcy5faXNNb2JpbGVWaWV3ID09PSAndW5kZWZpbmVkJyB8fCB0aGlzLl9pc01vYmlsZVZpZXcpIHtcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLl9zaG93TG9hZGluZ092ZXJsYXkodHJ1ZSk7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5faXNNb2JpbGVWaWV3ID0gZmFsc2U7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5fc2V0V2ViR3JpZEhlaWdodChncmlkRWxlbWVudCwgdGhpcy5jb25maWcuZ3JpZEhlaWdodCk7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLmdyaWRPcHRpb25zLmFwaS5zaXplQ29sdW1uc1RvRml0KCk7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgLyoqXHJcbiAgICAgKiBhZGQgYm9yZGVyIGJvdHRvbSBkeW5hbWljYWxseSBzbyB0aGF0IHdoZW4gdGhlIHJvdyBpcyBsZXNzZXIgdGhhbiBib2R5LWNvbnRhaW5lciwgdGhlcmUgd29udCBiZSBhbnkgaGFuZ2luZyBib3JkZXIgYm90dG9tXHJcbiAgICAgKiB3aGVuIHRoZSByb3cgaXMgbW9yZSB0aGFuIGNvbnRhaW5lciwgdGhlcmUgd2lsbCBiZSBhIGJvcmRlci1ib3R0b21cclxuICAgICAqL1xyXG4gICAgcHJpdmF0ZSBfc2V0VGFibGVCb3JkZXJCb3R0b20oKTogdm9pZCB7XHJcbiAgICAgICAgbGV0IGNvbnRhaW5lckVsZVF1ZXJ5OiBzdHJpbmcgPSAnIC5hZy1ib2R5LWNvbnRhaW5lcic7XHJcbiAgICAgICAgbGV0IGNvbnRhaW5lckVsZTogRWxlbWVudCA9IHRoaXMuX3Zjci5lbGVtZW50Lm5hdGl2ZUVsZW1lbnQucXVlcnlTZWxlY3Rvcihjb250YWluZXJFbGVRdWVyeSk7XHJcbiAgICAgICAgaWYgKGNvbnRhaW5lckVsZSA9PT0gbnVsbCkgcmV0dXJuO1xyXG5cclxuICAgICAgICBsZXQgdmlld3BvcnRFbGVRdWVyeTogc3RyaW5nID0gJyAuYWctYm9keS12aWV3cG9ydCc7XHJcbiAgICAgICAgbGV0IHZpZXdwb3J0RWxlOiBFbGVtZW50ID0gdGhpcy5fdmNyLmVsZW1lbnQubmF0aXZlRWxlbWVudC5xdWVyeVNlbGVjdG9yKHZpZXdwb3J0RWxlUXVlcnkpO1xyXG5cclxuICAgICAgICBpZiAoY29udGFpbmVyRWxlLmNsaWVudEhlaWdodCA+IHZpZXdwb3J0RWxlLmNsaWVudEhlaWdodCAmJlxyXG4gICAgICAgICAgICB2aWV3cG9ydEVsZS5jbGFzc05hbWUgJiZcclxuICAgICAgICAgICAgdmlld3BvcnRFbGUuY2xhc3NOYW1lLmluZGV4T2YoJ2hhcy1ib3JkZXItYm90dG9tJykgPT09IC0xXHJcbiAgICAgICAgKSB7XHJcbiAgICAgICAgICAgIHZpZXdwb3J0RWxlLmNsYXNzTmFtZSArPSAnIGhhcy1ib3JkZXItYm90dG9tJztcclxuICAgICAgICB9IGVsc2UgaWYgKGNvbnRhaW5lckVsZS5jbGllbnRIZWlnaHQgPCB2aWV3cG9ydEVsZS5jbGllbnRIZWlnaHQpIHtcclxuICAgICAgICAgICAgdmlld3BvcnRFbGUuY2xhc3NOYW1lID0gdmlld3BvcnRFbGUuY2xhc3NOYW1lLnJlcGxhY2UoL2hhcy1ib3JkZXItYm90dG9tL2dpLCAnJyk7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX3NldE1vYmlsZUhlaWdodChfZ3JpZEVsZW1lbnQ6IEVsZW1lbnQpOiB2b2lkIHtcclxuICAgICAgICBsZXQgbmV3SGVpZ2h0OiBudW1iZXIgPSAwO1xyXG5cclxuICAgICAgICBpZiAodGhpcy5jb25maWcubG9hZFR5cGUgIT09ICdpbmZpbml0ZScpIHtcclxuICAgICAgICAgICAgbGV0IGFnSGVhZGVyRWxlOiBFbGVtZW50ID0gdGhpcy5fdmNyLmVsZW1lbnQubmF0aXZlRWxlbWVudC5xdWVyeVNlbGVjdG9yKCcuYWctaGVhZGVyJyk7XHJcbiAgICAgICAgICAgIGxldCBhZ0JvZHlFbGU6IEVsZW1lbnQgPSB0aGlzLl92Y3IuZWxlbWVudC5uYXRpdmVFbGVtZW50LnF1ZXJ5U2VsZWN0b3IoJy5hZy1ib2R5LWNvbnRhaW5lcicpO1xyXG4gICAgICAgICAgICBsZXQgYWdQYWdlUGFuZWxFbGU6IEVsZW1lbnQgPSB0aGlzLl92Y3IuZWxlbWVudC5uYXRpdmVFbGVtZW50LnF1ZXJ5U2VsZWN0b3IoJ2RpdltyZWY9XCJzb3V0aFwiXScpO1xyXG4gICAgICAgICAgICBuZXdIZWlnaHQgPSAyNTtcclxuXHJcbiAgICAgICAgICAgIGlmIChhZ0hlYWRlckVsZSAhPT0gbnVsbCkge1xyXG4gICAgICAgICAgICAgICAgbmV3SGVpZ2h0ICs9IGFnSGVhZGVyRWxlLmNsaWVudEhlaWdodDtcclxuICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgaWYgKGFnQm9keUVsZSAhPT0gbnVsbCkge1xyXG4gICAgICAgICAgICAgICAgbmV3SGVpZ2h0ICs9IGFnQm9keUVsZS5jbGllbnRIZWlnaHQ7XHJcbiAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgIGlmIChhZ1BhZ2VQYW5lbEVsZSAhPT0gbnVsbCkge1xyXG4gICAgICAgICAgICAgICAgbmV3SGVpZ2h0ICs9IGFnUGFnZVBhbmVsRWxlLmNsaWVudEhlaWdodDtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgbmV3SGVpZ2h0ID0gNDAwO1xyXG4gICAgICAgIH1cclxuXHJcblxyXG4gICAgICAgIHRoaXMuX2RvbVN2Yy5zZXRFbGVtZW50U3R5bGUoX2dyaWRFbGVtZW50LCAnaGVpZ2h0JywgbmV3SGVpZ2h0ICsgJ3B4Jyk7XHJcblxyXG4gICAgICAgIHRpbWVyKDEwKS5zdWJzY3JpYmUoKCk6IHZvaWQgPT4ge1xyXG4gICAgICAgICAgICB0aGlzLmdyaWRPcHRpb25zLmFwaS5zaXplQ29sdW1uc1RvRml0KCk7XHJcbiAgICAgICAgICAgIHRoaXMuX3Nob3dMb2FkaW5nT3ZlcmxheShmYWxzZSk7XHJcbiAgICAgICAgfSk7XHJcbiAgICB9XHJcblxyXG4gICAgLyoqXHJcbiAgICAgKiBbX3NldFdlYkdyaWRIZWlnaHQgbnVtYmVyIGZvciBwaXhlbCBvciBzdHJpbmcgXCJhdXRvXCJdXHJcbiAgICAgKiAgX2NvbmZpZ0hlaWdodCBbZGVzY3JpcHRpb25dXHJcbiAgICAgKi9cclxuICAgIHByaXZhdGUgX3NldFdlYkdyaWRIZWlnaHQoX2dyaWRFbGVtZW50OiBFbGVtZW50LCBfY29uZmlnSGVpZ2h0OiBudW1iZXIgfCBzdHJpbmcpOiB2b2lkIHtcclxuICAgICAgICBpZiAodHlwZW9mIF9jb25maWdIZWlnaHQgPT09ICdudW1iZXInKSB7XHJcbiAgICAgICAgICAgIGxldCBncmlkSGVpZ2h0OiBudW1iZXIgPSA2MDA7XHJcblxyXG4gICAgICAgICAgICBpZiAodHlwZW9mIF9jb25maWdIZWlnaHQgIT09ICd1bmRlZmluZWQnKSB7XHJcbiAgICAgICAgICAgICAgICBncmlkSGVpZ2h0ID0gX2NvbmZpZ0hlaWdodDtcclxuICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgdGhpcy5fZG9tU3ZjLnNldEVsZW1lbnRTdHlsZShfZ3JpZEVsZW1lbnQsICdoZWlnaHQnLCBncmlkSGVpZ2h0ICsgJ3B4Jyk7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGVsc2UgaWYgKF9jb25maWdIZWlnaHQgPT09ICdhdXRvJykge1xyXG4gICAgICAgICAgICB0aGlzLmRpc3BsYXlGdWxsID0gdHJ1ZTtcclxuICAgICAgICB9XHJcbiAgICAgICAgLy8gZWxzZSBpZiAoX2NvbmZpZ0hlaWdodCA9PT0gJ3Jvd0hlaWdodCcpIHtcclxuICAgICAgICAvLyAgICAgdGhpcy5ncmlkT3B0aW9ucy5kb21MYXlvdXQgPSAnYXV0b0hlaWdodCc7XHJcbiAgICAgICAgLy8gICAgIGRlbGV0ZSB0aGlzLmdyaWRPcHRpb25zLnJvd0hlaWdodDtcclxuICAgICAgICAvLyAgICAgZGVsZXRlIHRoaXMuZ3JpZE9wdGlvbnMuZ2V0Um93SGVpZ2h0O1xyXG4gICAgICAgIC8vIH1cclxuXHJcbiAgICAgICAgdGltZXIoKS5zdWJzY3JpYmUoKCk6IHZvaWQgPT4ge1xyXG4gICAgICAgICAgICB0aGlzLmdyaWRPcHRpb25zLmFwaS5zaXplQ29sdW1uc1RvRml0KCk7XHJcbiAgICAgICAgICAgIHRoaXMuX3Nob3dMb2FkaW5nT3ZlcmxheShmYWxzZSk7XHJcbiAgICAgICAgfSk7XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfaXNDbGlja1ZhbGlkKF9ldmVudDogRXZlbnQpOiBib29sZWFuIHtcclxuICAgICAgICBsZXQgdGFyZ2V0RWxlbWVudDogSFRNTEVsZW1lbnQgPSA8SFRNTEVsZW1lbnQ+X2V2ZW50LnRhcmdldDtcclxuICAgICAgICBsZXQgaW52YWxpZExpc3Q6IEFycmF5PHN0cmluZz4gPSBbJ2FjdGlvbi1idG4nLCAnY2hlY2tib3gtcmFkaW8taW5wdXQnLCAnZmEtY2hldnJvbi1kb3duJ107XHJcblxyXG4gICAgICAgIGZvciAobGV0IGk6IG51bWJlciA9IDA7IGkgPCBpbnZhbGlkTGlzdC5sZW5ndGg7IGkrKykge1xyXG4gICAgICAgICAgICBpZiAodGFyZ2V0RWxlbWVudC5jbGFzc0xpc3QuY29udGFpbnMoaW52YWxpZExpc3RbaV0pKSB7XHJcbiAgICAgICAgICAgICAgICByZXR1cm4gZmFsc2U7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIHJldHVybiB0cnVlO1xyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX3Jlc2l6ZUNvbHVtbihfaXNSZXNpemVUb0NvbnRlbnQ6IGJvb2xlYW4gPSBmYWxzZSk6IHZvaWQge1xyXG4gICAgICAgIGlmICh0aGlzLl90YWJsZVNlcnZpY2UuaXNBcGlSZWFkeSh0aGlzLmdyaWRPcHRpb25zKSkge1xyXG4gICAgICAgICAgICB0aW1lcigxMCkuc3Vic2NyaWJlKCgpOiB2b2lkID0+IHtcclxuICAgICAgICAgICAgICAgIChfaXNSZXNpemVUb0NvbnRlbnQpID8gdGhpcy5fcmVzaXplQ29sdW1uVG9Db250ZW50KCkgOiB0aGlzLmdyaWRPcHRpb25zLmFwaS5zaXplQ29sdW1uc1RvRml0KCk7XHJcbiAgICAgICAgICAgICAgICB0aGlzLm9uRXhwb3J0UG9zc2libGUuZW1pdCh0cnVlKTtcclxuICAgICAgICAgICAgICAgIHRoaXMuX3Nob3dMb2FkaW5nT3ZlcmxheShmYWxzZSk7XHJcbiAgICAgICAgICAgIH0pO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICAvKipcclxuICAgICAqIHJlc2l6ZSBjb2x1bW4gdG8gY29sRGVmIHdpZHRoXHJcbiAgICAgKi9cclxuICAgIHByaXZhdGUgX3Jlc2l6ZUNvbHVtblRvQ29udGVudCgpOiB2b2lkIHtcclxuICAgICAgICBsZXQgYWxsQ29sdW1uSWRzOiBBcnJheTxzdHJpbmc+ID0gW107XHJcbiAgICAgICAgdGhpcy5ncmlkT3B0aW9ucy5jb2x1bW5BcGkuZ2V0QWxsRGlzcGxheWVkQ29sdW1ucygpLmZvckVhY2goKGNvbHVtbjogQ29sdW1uKSA9PiB7XHJcbiAgICAgICAgICAgIGFsbENvbHVtbklkcy5wdXNoKGNvbHVtbi5nZXRDb2xJZCgpKTtcclxuICAgICAgICB9KTtcclxuICAgICAgICB0aGlzLmdyaWRPcHRpb25zLmNvbHVtbkFwaS5hdXRvU2l6ZUNvbHVtbnMoYWxsQ29sdW1uSWRzKTtcclxuICAgIH1cclxuXHJcbiAgICAvKipcclxuICAgICAqIHBvcHVsYXRlIGR5bmFtaWMgc3R5bGluZyB2YWx1ZVxyXG4gICAgICogcGFyYW0ge0lUYWJsZUNvbmZpZ30gX2NvbmZpZzogdGFibGVDb25maWdcclxuICAgICAqL1xyXG4gICAgcHVibGljIHVwZGF0ZVN0eWxlKF9jb25maWc6IElUYWJsZUNvbmZpZyk6IHZvaWQge1xyXG4gICAgICAgIGlmICghX2NvbmZpZyB8fCAhX2NvbmZpZy5jb25maWcpIHtcclxuICAgICAgICAgICAgZG9jdW1lbnQucXVlcnlTZWxlY3RvcignYm9keScpLnN0eWxlLmNzc1RleHQgPSAnJztcclxuICAgICAgICAgICAgcmV0dXJuO1xyXG4gICAgICAgIH1cclxuICAgICAgICBsZXQgY29uZmlnOiBJU3R5bGluZ0NvbmZpZyA9IF9jb25maWcuY29uZmlnO1xyXG5cclxuICAgICAgICBsZXQgYm9keUNzczogc3RyaW5nID0gJyc7XHJcblxyXG4gICAgICAgIGJvZHlDc3MgKz0gdGhpcy5fdXBkYXRlSGVhZGVyU3R5bGUoY29uZmlnKTtcclxuXHJcbiAgICAgICAgaWYgKGNvbmZpZy5ib2R5KSB7XHJcbiAgICAgICAgICAgIGlmIChjb25maWcuYm9keS5hbHRlcm5hdGVSb3cgPT09IHRydWUpIHtcclxuICAgICAgICAgICAgICAgIGlmIChjb25maWcuYm9keS5vZGQgJiYgY29uZmlnLmJvZHkub2RkLmJhY2tncm91bmRDb2xvcikge1xyXG4gICAgICAgICAgICAgICAgICAgIGJvZHlDc3MgKz0gJy0ta2R0YWJsZS1yb3ctb2RkLWJhY2tncm91bmQ6ICcgKyBjb25maWcuYm9keS5vZGQuYmFja2dyb3VuZENvbG9yICsgJzsnO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgaWYgKGNvbmZpZy5ib2R5LmV2ZW4gJiYgY29uZmlnLmJvZHkuZXZlbi5iYWNrZ3JvdW5kQ29sb3IpIHtcclxuICAgICAgICAgICAgICAgICAgICBib2R5Q3NzICs9ICctLWtkdGFibGUtcm93LWV2ZW4tYmFja2dyb3VuZDogJyArIGNvbmZpZy5ib2R5LmV2ZW4uYmFja2dyb3VuZENvbG9yICsgJzsnO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIGlmIChjb25maWcuYm9keS5zdHlsZSkge1xyXG4gICAgICAgICAgICAgICAgaWYgKGNvbmZpZy5ib2R5LnN0eWxlLmJvcmRlcldpZHRoKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgYm9keUNzcyArPSAnLS1rZHRhYmxlLWJvZHktYm9yZGVyLXdpZHRoOiAnICsgY29uZmlnLmJvZHkuc3R5bGUuYm9yZGVyV2lkdGggKyAnOyc7XHJcbiAgICAgICAgICAgICAgICAgICAgYm9keUNzcyArPSAnLS1rZHRhYmxlLWhlYWRlci1ib3JkZXItd2lkdGg6ICcgKyBjb25maWcuYm9keS5zdHlsZS5ib3JkZXJXaWR0aCArICc7JztcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIGlmIChjb25maWcuYm9keS5zdHlsZS5ib3JkZXJDb2xvcikge1xyXG4gICAgICAgICAgICAgICAgICAgIGJvZHlDc3MgKz0gJy0ta2R0YWJsZS1ib2R5LWJvcmRlci1jb2xvcjogJyArIGNvbmZpZy5ib2R5LnN0eWxlLmJvcmRlckNvbG9yICsgJzsnO1xyXG4gICAgICAgICAgICAgICAgICAgIGJvZHlDc3MgKz0gJy0ta2R0YWJsZS1oZWFkZXItYm9yZGVyLWNvbG9yOiAnICsgY29uZmlnLmJvZHkuc3R5bGUuYm9yZGVyQ29sb3IgKyAnOyc7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICBpZiAoY29uZmlnLmJvZHkuc3R5bGUuYm9yZGVyU3R5bGUpIHtcclxuICAgICAgICAgICAgICAgICAgICBib2R5Q3NzICs9ICctLWtkdGFibGUtYm9keS1ib3JkZXItc3R5bGU6ICcgKyBjb25maWcuYm9keS5zdHlsZS5ib3JkZXJTdHlsZSArICc7JztcclxuICAgICAgICAgICAgICAgICAgICBib2R5Q3NzICs9ICctLWtkdGFibGUtaGVhZGVyLWJvcmRlci1zdHlsZTogJyArIGNvbmZpZy5ib2R5LnN0eWxlLmJvcmRlclN0eWxlICsgJzsnO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICBkb2N1bWVudC5xdWVyeVNlbGVjdG9yKCdib2R5Jykuc3R5bGUuY3NzVGV4dCA9IGJvZHlDc3M7XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfdXBkYXRlSGVhZGVyU3R5bGUoX2NvbmZpZzogSVN0eWxpbmdDb25maWcpOiBzdHJpbmcge1xyXG4gICAgICAgIGlmICghX2NvbmZpZy5oZWFkZXIgfHwgIV9jb25maWcuaGVhZGVyLnN0eWxlKSByZXR1cm4gJyc7XHJcblxyXG4gICAgICAgIGxldCBib2R5Q3NzOiBzdHJpbmcgPSAnJztcclxuICAgICAgICBsZXQgc3R5bGVOYW1lczogQXJyYXk8c3RyaW5nPiA9IFtcclxuICAgICAgICAgICAgJ2JhY2tncm91bmRDb2xvcicsXHJcbiAgICAgICAgICAgICd0ZXh0QWxpZ24nLFxyXG4gICAgICAgICAgICAndmVydGljYWxBbGlnbicsXHJcbiAgICAgICAgICAgICdjb2xvcicsXHJcbiAgICAgICAgICAgICdmb250RmFtaWx5JyxcclxuICAgICAgICAgICAgJ2ZvbnRTaXplJyxcclxuICAgICAgICAgICAgJ2ZvbnRXZWlnaHQnLFxyXG4gICAgICAgICAgICAnZm9udFN0eWxlJyxcclxuICAgICAgICAgICAgJ3RleHREZWNvcmF0aW9uJyxcclxuICAgICAgICAgICAgLy8gJ2JvcmRlcldpZHRoJyxcclxuICAgICAgICAgICAgLy8gJ2JvcmRlckNvbG9yJyxcclxuICAgICAgICAgICAgLy8gJ2JvcmRlclN0eWxlJyxcclxuICAgICAgICAgICAgJ29wYWNpdHknXHJcbiAgICAgICAgXTtcclxuICAgICAgICBmb3IgKGxldCBpOiBudW1iZXIgPSAwOyBpIDwgc3R5bGVOYW1lcy5sZW5ndGg7ICsraSkge1xyXG4gICAgICAgICAgICBsZXQgc3R5bGVOYW1lOiBzdHJpbmcgPSBzdHlsZU5hbWVzW2ldO1xyXG4gICAgICAgICAgICBsZXQgdmFsdWU6IHN0cmluZyA9IF9jb25maWcuaGVhZGVyLnN0eWxlW3N0eWxlTmFtZV07XHJcbiAgICAgICAgICAgIGlmIChzdHlsZU5hbWUgPT09ICd2ZXJ0aWNhbEFsaWduJykgdmFsdWUgPSB0aGlzLl9nZXRBbGlnbkl0ZW0odmFsdWUpO1xyXG4gICAgICAgICAgICBzdHlsZU5hbWUgPSAoc3R5bGVOYW1lID09PSAnYmFja2dyb3VuZENvbG9yJykgPyAnYmFja2dyb3VuZCcgOiBzdHlsZU5hbWUucmVwbGFjZSgvKFthLXpdKShbQS1aXSkvZywgJyQxLSQyJykudG9Mb3dlckNhc2UoKTtcclxuICAgICAgICAgICAgaWYgKHR5cGVvZiB2YWx1ZSAhPT0gJ3VuZGVmaW5lZCcpIHtcclxuICAgICAgICAgICAgICAgIGlmIChzdHlsZU5hbWUgPT09ICdib3JkZXJXaWR0aCcgJiZcclxuICAgICAgICAgICAgICAgICAgICAodHlwZW9mIHZhbHVlICE9PSAnc3RyaW5nJyB8fCB2YWx1ZS5pbmRleE9mKCdweCcpID09PSAtMSlcclxuICAgICAgICAgICAgICAgICkgdmFsdWUgKz0gJ3B4JztcclxuICAgICAgICAgICAgICAgIGJvZHlDc3MgKz0gJy0ta2R0YWJsZS1oZWFkZXItJyArIHN0eWxlTmFtZSArICc6ICcgKyB2YWx1ZSArICc7JztcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgICAgICByZXR1cm4gYm9keUNzcztcclxuICAgIH1cclxuXHJcbiAgICAvKipcclxuICAgICAqIGNvbnZlcnQgdGV4dCBhbGlnbiBpbnRvIGZsZXgtYm94IGl0ZW0gYWxpZ25cclxuICAgICAqIHBhcmFtIHtzdHJpbmd9IF92ZXJ0aWNhbEFsaWduOiB0ZXh0IHZlcnRpY2FsQWxpZ25cclxuICAgICAqL1xyXG4gICAgcHJpdmF0ZSBfZ2V0QWxpZ25JdGVtKF92ZXJ0aWNhbEFsaWduOiBzdHJpbmcpOiBzdHJpbmcge1xyXG4gICAgICAgIGlmIChfdmVydGljYWxBbGlnbiA9PT0gJ2Jhc2VsaW5lJyB8fCBfdmVydGljYWxBbGlnbiA9PT0gJ2JvdHRvbScpIHtcclxuICAgICAgICAgICAgcmV0dXJuICdmbGV4LWVuZCc7XHJcbiAgICAgICAgfSBlbHNlIGlmIChfdmVydGljYWxBbGlnbiA9PT0gJ3RvcCcpIHtcclxuICAgICAgICAgICAgcmV0dXJuICdmbGV4LXN0YXJ0JztcclxuICAgICAgICB9IGVsc2UgeyAvLyBpbmNsdWRpbmcgaW52YWxpZCBpbnB1dFxyXG4gICAgICAgICAgICBpZiAoX3ZlcnRpY2FsQWxpZ24gIT09ICdtaWRkbGUnICYmIF92ZXJ0aWNhbEFsaWduICE9PSB1bmRlZmluZWQpIHtcclxuICAgICAgICAgICAgICAgIGNvbnNvbGUud2FybignRVJST1I6IHRoZSB2ZXJ0aWNhbCBhbGlnbiB2YWx1ZSBvZiAnICsgX3ZlcnRpY2FsQWxpZ24gKyAnIGlzIG5vdCB5ZXQgcmVjb2duaXNlZCBieSBLZFRhYmxlLiBQbGVhc2Ugb25seSB1c2UgZWl0aGVyIHRvcCwgY2VudGVyIG9yIGJvdHRvbScpO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIHJldHVybiAnY2VudGVyJztcclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgLy8gcHJpdmF0ZSBfcmVmcmVzaFRhYmxlKF90YWJsZUNlbGxQYXJhbXM/OiBJVGFibGVDZWxsUGFyYW1zKTogdm9pZCB7XHJcbiAgICAvLyAgICAgaWYgKHRoaXMuX3RhYmxlU2VydmljZSAmJiB0aGlzLl90YWJsZVNlcnZpY2UuaXNBcGlSZWFkeSAmJiB0aGlzLl90YWJsZVNlcnZpY2UuaXNBcGlSZWFkeSh0aGlzLmdyaWRPcHRpb25zKSkge1xyXG4gICAgLy8gICAgICAgICBsZXQgdG9VcGRhdGVOb2RlOiBBcnJheTxSb3dOb2RlPiA9IFtdO1xyXG4gICAgLy8gICAgICAgICBsZXQgYWxsQ29sdW1uSWRzOiBBcnJheTxzdHJpbmc+ID0gW107XHJcblxyXG4gICAgLy8gICAgICAgICBpZiAoIV90YWJsZUNlbGxQYXJhbXMpIHtcclxuICAgIC8vICAgICAgICAgICAgIHRoaXMuZ3JpZE9wdGlvbnMuY29sdW1uQXBpLmdldEFsbERpc3BsYXllZENvbHVtbnMoKS5mb3JFYWNoKChjb2x1bW4pID0+IHtcclxuICAgIC8vICAgICAgICAgICAgICAgICBhbGxDb2x1bW5JZHMucHVzaChjb2x1bW4uZ2V0Q29sSWQoKSk7XHJcbiAgICAvLyAgICAgICAgICAgICB9KTtcclxuICAgIC8vICAgICAgICAgfVxyXG5cclxuICAgIC8vICAgICAgICAgdGhpcy5ncmlkT3B0aW9ucy5hcGkuZm9yRWFjaE5vZGUoKF9yb3dOb2RlOiBSb3dOb2RlKTogdm9pZCA9PiB7XHJcbiAgICAvLyAgICAgICAgICAgICBpZiAoX3RhYmxlQ2VsbFBhcmFtcyAmJiB0eXBlb2YgX3Jvd05vZGUuaWQgIT09ICd1bmRlZmluZWQnICYmIF9yb3dOb2RlLmlkID09PSBfdGFibGVDZWxsUGFyYW1zLnJvd0lkKSB7XHJcbiAgICAvLyAgICAgICAgICAgICAgICAgX3Jvd05vZGUuZGF0YVtfdGFibGVDZWxsUGFyYW1zLmNvbElkXSA9IF90YWJsZUNlbGxQYXJhbXMuZGF0YTtcclxuICAgIC8vICAgICAgICAgICAgICAgICB0b1VwZGF0ZU5vZGUucHVzaChfcm93Tm9kZSk7XHJcbiAgICAvLyAgICAgICAgICAgICB9IGVsc2Uge1xyXG4gICAgLy8gICAgICAgICAgICAgICAgIHRvVXBkYXRlTm9kZS5wdXNoKF9yb3dOb2RlKTtcclxuICAgIC8vICAgICAgICAgICAgIH1cclxuICAgIC8vICAgICAgICAgfSk7XHJcblxyXG4gICAgLy8gICAgICAgICBsZXQgcmVmcmVzaFBhcmFtczogeyByb3dOb2RlczogQXJyYXk8Um93Tm9kZT4sIGNvbHVtbnM6IEFycmF5PGFueT4gfSA9IHtcclxuICAgIC8vICAgICAgICAgICAgIHJvd05vZGVzOiB0b1VwZGF0ZU5vZGUsXHJcbiAgICAvLyAgICAgICAgICAgICBjb2x1bW5zOiAoX3RhYmxlQ2VsbFBhcmFtcykgPyBbX3RhYmxlQ2VsbFBhcmFtcy5jb2xJZF0gOiBhbGxDb2x1bW5JZHNcclxuICAgIC8vICAgICAgICAgfTtcclxuXHJcbiAgICAvLyAgICAgICAgIHRoaXMuZ3JpZE9wdGlvbnMuYXBpLnJlZnJlc2hDZWxscyhyZWZyZXNoUGFyYW1zKTtcclxuICAgIC8vICAgICB9XHJcbiAgICAvLyB9XHJcblxyXG4gICAgLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy9cclxuICAgIC8vLyBQaXZvdCBGdW5jdGlvblxyXG4gICAgLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy9cclxuICAgIHByaXZhdGUgX2lzVG9vbHBhbmVsVHlwZUNoYW5nZWQoKTogYm9vbGVhbiB7XHJcbiAgICAgICAgbGV0IGlzVHlwZUNoYW5nZWQ6IGJvb2xlYW4gPSB0cnVlO1xyXG4gICAgICAgIGlmICh0aGlzLl9wcmV2aW91c1Rvb2xwYW5lbFR5cGUpIHtcclxuICAgICAgICAgICAgaWYgKHR5cGVFeGlzdCh0aGlzLmNvbmZpZykpIHtcclxuICAgICAgICAgICAgICAgIGlzVHlwZUNoYW5nZWQgPSB0aGlzLl9wcmV2aW91c1Rvb2xwYW5lbFR5cGUgIT09IHRoaXMuY29uZmlnLnBpdm90LnRvb2xwYW5lbC50eXBlO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgaWYgKHR5cGVFeGlzdCh0aGlzLmNvbmZpZykpIHtcclxuICAgICAgICAgICAgICAgIHRoaXMuX3ByZXZpb3VzVG9vbHBhbmVsVHlwZSA9IHRoaXMuY29uZmlnLnBpdm90LnRvb2xwYW5lbC50eXBlO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgICAgIHJldHVybiBpc1R5cGVDaGFuZ2VkO1xyXG5cclxuICAgICAgICBmdW5jdGlvbiB0eXBlRXhpc3QoX2NvbmZpZykge1xyXG4gICAgICAgICAgICByZXR1cm4gX2NvbmZpZyAmJiBfY29uZmlnLnBpdm90ICYmIF9jb25maWcucGl2b3QudG9vbHBhbmVsICYmIF9jb25maWcucGl2b3QudG9vbHBhbmVsLnR5cGVcclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfY29uZmlndXJlUGl2b3REaXNwbGF5KCk6IHZvaWQge1xyXG4gICAgICAgIGxldCBpc1N0YXRlQ2hhbmdlZDogYm9vbGVhbiA9IHRydWU7XHJcbiAgICAgICAgaWYgKHRoaXMuY29uZmlnICYmIHRoaXMuY29uZmlnLnBpdm90ICYmIHRoaXMuY29uZmlnLnBpdm90LnN0YXRlICYmIHRoaXMuY29uZmlnLnBpdm90LnN0YXRlLmNvbHVtblN0YXRlKSB7XHJcbiAgICAgICAgICAgIGlzU3RhdGVDaGFuZ2VkID0gdGhpcy5jb25maWcucGl2b3Quc3RhdGUuY29sdW1uU3RhdGUubGVuZ3RoICE9PSB0aGlzLl9jdXJyZW50U3RhdGUuY29sdW1uU3RhdGUubGVuZ3RoO1xyXG4gICAgICAgIH1cclxuICAgICAgICBpZiAodGhpcy5jb25maWcubG9hZFR5cGUgIT09ICdub3JtYWwnIHx8ICh0aGlzLl9pc1Rvb2xwYW5lbFR5cGVDaGFuZ2VkKCkgPT09IGZhbHNlICYmIGlzU3RhdGVDaGFuZ2VkID09PSBmYWxzZSkpIHJldHVybjtcclxuXHJcbiAgICAgICAgbGV0IHNob3dUb29sUGFuZWw6IGJvb2xlYW4gPSBmYWxzZTtcclxuICAgICAgICBsZXQgc2hvd1Bpdm90TW9kZTogYm9vbGVhbiA9IGZhbHNlO1xyXG4gICAgICAgIGlmICh0aGlzLmNvbmZpZy5waXZvdCAmJiB0aGlzLmNvbmZpZy5waXZvdC50b29scGFuZWwpIHtcclxuICAgICAgICAgICAgc2hvd1Rvb2xQYW5lbCA9IHRoaXMuY29uZmlnLnBpdm90LnRvb2xwYW5lbC50eXBlICE9PSAnbm9uZSc7XHJcbiAgICAgICAgICAgIHNob3dQaXZvdE1vZGUgPSB0aGlzLmNvbmZpZy5waXZvdC50b29scGFuZWwudHlwZSA9PT0gJ3Bpdm90JztcclxuICAgICAgICB9XHJcbiAgICAgICAgdGhpcy5fc2hvd1Rvb2xQYW5lbChzaG93VG9vbFBhbmVsKTtcclxuICAgICAgICB0aGlzLl9zaG93UGl2b3RNb2RlKHNob3dQaXZvdE1vZGUpO1xyXG4gICAgfVxyXG5cclxuICAgIC8qKlxyXG4gICAgICogcmVzaXplIGNvbHVtbiB0byBmaXQgdGFibGUgY29udGFpbmVyIGlmIHRoZSB3aWR0aCBvZiB0aGUgY29udGVudCBjb2x1bW4gaXMgc21hbGxlciB0aGFuIGNvbnRhaW5lclxyXG4gICAgICovXHJcbiAgICBwcml2YXRlIF9waXZvdFJlc2l6ZSgpOiB2b2lkIHtcclxuICAgICAgICBsZXQgY29udGFpbmVyOiBFbGVtZW50ID0gdGhpcy5fdmNyLmVsZW1lbnQubmF0aXZlRWxlbWVudC5xdWVyeVNlbGVjdG9yKCcuYWctaGVhZGVyLWNvbnRhaW5lcicpO1xyXG4gICAgICAgIGxldCBoZWFkZXI6IEVsZW1lbnQgPSB0aGlzLl92Y3IuZWxlbWVudC5uYXRpdmVFbGVtZW50LnF1ZXJ5U2VsZWN0b3IoJy5hZy1oZWFkZXItY29udGFpbmVyIC5hZy1oZWFkZXItcm93Jyk7XHJcblxyXG4gICAgICAgIHRoaXMuX3Jlc2l6ZUNvbHVtbihoZWFkZXIuZ2V0Qm91bmRpbmdDbGllbnRSZWN0KCkud2lkdGggPiBjb250YWluZXIuZ2V0Qm91bmRpbmdDbGllbnRSZWN0KCkud2lkdGgpO1xyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX3Jlc2V0UGl2b3RDb2x1bW4oKTogdm9pZCB7XHJcbiAgICAgICAgdGhpcy5ncmlkT3B0aW9ucy5jb2x1bW5BcGkuc2V0Um93R3JvdXBDb2x1bW5zKFtdKTtcclxuICAgICAgICB0aGlzLmdyaWRPcHRpb25zLmNvbHVtbkFwaS5zZXRQaXZvdENvbHVtbnMoW10pO1xyXG4gICAgICAgIHRoaXMuZ3JpZE9wdGlvbnMuY29sdW1uQXBpLnNldFZhbHVlQ29sdW1ucyhbXSk7XHJcbiAgICAgICAgdGhpcy5ncmlkT3B0aW9ucy5jb2x1bW5BcGkuc2V0U2Vjb25kYXJ5Q29sdW1ucyhbXSk7XHJcbiAgICB9XHJcblxyXG4gICAgLyoqXHJcbiAgICAgKiBwYXNzIHN0YXRlIHRvIGFwcGxpY2F0aW9uLlxyXG4gICAgICogKGlmIHNldFN0YXRlIHdhcyB0cmlnZ2VyZWQgYmVmb3JlKSwgd2FpdCB1bnRpbCBzZXRTdGF0ZSBoYXMgZG9uZSBwcm9jZXNzaW5nXHJcbiAgICAgKiByZXR1cm4ge0lUYWJsZVBpdm90U3RhdGV9IFtkZXNjcmlwdGlvbl1cclxuICAgICAqL1xyXG4gICAgcHJpdmF0ZSBfZ2V0UGl2b3RTdGF0ZSgpOiBJVGFibGVQaXZvdFN0YXRlIHtcclxuICAgICAgICAvLyBpZiBzdGF0ZSBpcyBjaGFuZ2luZywgd2FpdCB1bnRpbCBzdGF0ZSBoYXMgYmVlbiB1cGRhdGVkIHRoZW4gZ2V0IHRoZSBtb3N0IHVwZGF0ZWQgc3RhdGVcclxuICAgICAgICBsZXQgZ2V0U3RhdGUgPSAoKTogYW55ID0+IHtcclxuICAgICAgICAgICAgdGhpcy5fY3VycmVudFN0YXRlLmNvbHVtblN0YXRlID0gdGhpcy5ncmlkT3B0aW9ucy5jb2x1bW5BcGkuZ2V0Q29sdW1uU3RhdGUoKTtcclxuICAgICAgICAgICAgdGhpcy5fY3VycmVudFN0YXRlLnBpdm90TW9kZSA9IHRoaXMuZ3JpZE9wdGlvbnMuY29sdW1uQXBpLmlzUGl2b3RNb2RlKCk7XHJcbiAgICAgICAgICAgIHRoaXMuX2N1cnJlbnRTdGF0ZS5ncm91cFN0YXRlID0gdGhpcy5ncmlkT3B0aW9ucy5jb2x1bW5BcGkuZ2V0Q29sdW1uR3JvdXBTdGF0ZSgpO1xyXG4gICAgICAgICAgICByZXR1cm4gdGhpcy5fY3VycmVudFN0YXRlO1xyXG4gICAgICAgIH07XHJcbiAgICAgICAgbGV0IGNoZWNrID0gKCk6IGJvb2xlYW4gPT4ge1xyXG4gICAgICAgICAgICByZXR1cm4gdGhpcy5faXNDaGFuZ2luZ1N0YXRlID09PSBmYWxzZTtcclxuICAgICAgICB9O1xyXG4gICAgICAgIHJldHVybiB0aGlzLndhaXQoY2hlY2ssIGdldFN0YXRlKTtcclxuICAgIH1cclxuXHJcbiAgICAvKipcclxuICAgICAqIHJlcGxhY2UgY3VycmVudCBzdGF0ZSBpZiBhIHN0YXRlIGlzIGdpdmVuLCBleHBhbmRHcm91cCBiYXNlIG9uIGNvbmZpZ1xyXG4gICAgICogc2hvdWxkIHdhaXQgdW50aWwgY29sdW1uIGlzIHByZXNlbnQuXHJcbiAgICAgKiBwYXJhbSB7SVRhYmxlUGl2b3RTdGF0ZX0gX3N0YXRlXHJcbiAgICAgKi9cclxuICAgIHByaXZhdGUgX3NldFBpdm90U3RhdGUoX3N0YXRlOiBJVGFibGVQaXZvdFN0YXRlKTogdm9pZCB7XHJcbiAgICAgICAgaWYgKHR5cGVvZiAoX3N0YXRlKSA9PT0gJ3VuZGVmaW5lZCcgfHwgIV9zdGF0ZS5oYXNPd25Qcm9wZXJ0eSgnY29sdW1uU3RhdGUnKSkgcmV0dXJuO1xyXG5cclxuICAgICAgICBsZXQgc2V0U3RhdGUgPSAoKTogdm9pZCA9PiB7XHJcbiAgICAgICAgICAgIHRoaXMuX2lzQ2hhbmdpbmdTdGF0ZSA9IHRydWU7XHJcbiAgICAgICAgICAgIGlmIChfc3RhdGUuY29sdW1uU3RhdGUubGVuZ3RoID09PSAwKSB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLl9pc0NoYW5naW5nU3RhdGUgPSBmYWxzZTtcclxuICAgICAgICAgICAgICAgIHRoaXMuX3Bpdm90UmVzaXplKCk7XHJcbiAgICAgICAgICAgICAgICByZXR1cm47XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgdGhpcy5fY3VycmVudFN0YXRlID0gT2JqZWN0LmFzc2lnbih0aGlzLl9jdXJyZW50U3RhdGUsIF9zdGF0ZSk7XHJcbiAgICAgICAgICAgIHRoaXMuZ3JpZE9wdGlvbnMuY29sdW1uQXBpLnNldENvbHVtblN0YXRlKF9zdGF0ZS5jb2x1bW5TdGF0ZSk7XHJcbiAgICAgICAgICAgIHRoaXMuZ3JpZE9wdGlvbnMuY29sdW1uQXBpLnNldFBpdm90TW9kZShfc3RhdGUucGl2b3RNb2RlIHx8IGZhbHNlKTtcclxuICAgICAgICAgICAgdGhpcy5ncmlkT3B0aW9ucy5jb2x1bW5BcGkuc2V0Q29sdW1uR3JvdXBTdGF0ZShfc3RhdGUuZ3JvdXBTdGF0ZSB8fCBbXSk7XHJcbiAgICAgICAgICAgIHRoaXMuX2lzQ2hhbmdpbmdTdGF0ZSA9IGZhbHNlO1xyXG5cclxuICAgICAgICAgICAgdGltZXIoMTAwKS5zdWJzY3JpYmUoKCk6IHZvaWQgPT4ge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5fc2V0UGl2b3RDb2x1bW5zKCk7XHJcbiAgICAgICAgICAgICAgICB0aGlzLl9leHBhbmRHcm91cCgpO1xyXG4gICAgICAgICAgICB9KTtcclxuICAgICAgICB9O1xyXG4gICAgICAgIGxldCBjaGVjayA9ICgpOiBib29sZWFuID0+IHtcclxuICAgICAgICAgICAgcmV0dXJuIHRoaXMuY29sdW1uICYmIHRoaXMuY29sdW1uLmxlbmd0aCA+IDA7XHJcbiAgICAgICAgfTtcclxuICAgICAgICB0aGlzLndhaXQoY2hlY2ssIHNldFN0YXRlKTtcclxuICAgIH1cclxuXHJcbiAgICAvKipcclxuICAgICAqIHdhaXQgZm9yIHNvbWV0aGluZyB0byBmaW5pc2ggdGhlbiBkbyBzb21ldGhpbmcsIGJyZWFrcyBhdCAxMDB0aCB0byBwcmV2ZW50IGluZmluaXRlIGxvb3BcclxuICAgICAqIHBhcmFtIHtJVGFibGVQaXZvdFN0YXRlfSBfc3RhdGVcclxuICAgICAqIHJldHVybiB7YW55fVxyXG4gICAgICovXHJcbiAgICBwcml2YXRlIHdhaXQoX2NoZWNrOiBGdW5jdGlvbiwgX2RvOiBGdW5jdGlvbiwgX2xpbWl0Q291bnRlciA9IDApOiBhbnkge1xyXG4gICAgICAgIGlmICgoX2NoZWNrKCkgJiYgdGhpcy5fdGFibGVTZXJ2aWNlLmlzQXBpUmVhZHkodGhpcy5ncmlkT3B0aW9ucykpIHx8IF9saW1pdENvdW50ZXIgPT09IDEwMCkge1xyXG4gICAgICAgICAgICBpZiAoX2xpbWl0Q291bnRlciA9PT0gMTAwKSBjb25zb2xlLmxvZygnVGltZW91dDogY2hlY2sgZmFpbHMuIHJ1bm5pbmcnLCBfZG8pO1xyXG4gICAgICAgICAgICByZXR1cm4gX2RvKCk7XHJcbiAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgdGltZXIoMTApLnN1YnNjcmliZSgoKTogdm9pZCA9PiB7XHJcbiAgICAgICAgICAgICAgICBfbGltaXRDb3VudGVyKys7XHJcbiAgICAgICAgICAgICAgICB0aGlzLndhaXQoX2NoZWNrLCBfZG8sIF9saW1pdENvdW50ZXIpO1xyXG4gICAgICAgICAgICB9KTtcclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfaXNQaXZvdEVsbUV4aXN0KF9waXZvdEVsZW1lbnQpOiBib29sZWFuIHsgXHJcbiAgICAgICAgcmV0dXJuIChcclxuICAgICAgICAgICAgdHlwZW9mIF9waXZvdEVsZW1lbnRbJ3Bpdm90J10gIT09ICd1bmRlZmluZWQnICYmXHJcbiAgICAgICAgICAgIF9waXZvdEVsZW1lbnRbJ3Bpdm90J10gIT09IG51bGwgJiZcclxuICAgICAgICAgICAgdHlwZW9mIF9waXZvdEVsZW1lbnRbJ2NvbHVtbi1kcm9wJ10gIT09ICd1bmRlZmluZWQnICYmXHJcbiAgICAgICAgICAgIF9waXZvdEVsZW1lbnRbJ2NvbHVtbi1kcm9wJ10gIT09IG51bGxcclxuICAgICAgICApO1xyXG4gICAgfVxyXG5cclxuICAgIC8qKlxyXG4gICAgICogc2hvdyBwaXZvdCBtb2RlIGNoZWNrYm94IGFuZCBsYWJlbC5cclxuICAgICAqIHdoZW4gcGl2b3QgbW9kZSBpcyBoaWRkZW4sIGFsbCBwaXZvdCBkYXRhIGhhcyB0byBiZSByZXNldC5cclxuICAgICAqIHBhcmFtIHtib29sZWFuID0gdHJ1ZX0gX3Nob3c6IHRydWUgdG8gc2hvdywgZmFsc2UgdG8gaGlkZVxyXG4gICAgICovXHJcbiAgICBwcml2YXRlIF9zaG93UGl2b3RNb2RlKF9zaG93OiBib29sZWFuID0gdHJ1ZSk6IHZvaWQge1xyXG4gICAgICAgIGxldCBzZXRQaXZvdE1vZGUgPSAoKTogdm9pZCA9PiB7XHJcbiAgICAgICAgICAgIGlmIChfc2hvdyA9PT0gdHJ1ZSkge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5fcGl2b3RFbGVtZW50WydwaXZvdCddLmNsYXNzTmFtZSA9IHRoaXMuX3Bpdm90RWxlbWVudFsncGl2b3QnXS5jbGFzc05hbWUucmVwbGFjZSgvIGhpZGRlbi9naSwgJycpO1xyXG4gICAgICAgICAgICAgICAgZm9yIChsZXQgaTogbnVtYmVyID0gMDsgaSA8IHRoaXMuX3Bpdm90RWxlbWVudFsnY29sdW1uLWRyb3AnXS5sZW5ndGg7ICsraSkge1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuX3Bpdm90RWxlbWVudFsnY29sdW1uLWRyb3AnXVtpXS5jbGFzc05hbWUgPSB0aGlzLl9waXZvdEVsZW1lbnRbJ2NvbHVtbi1kcm9wJ11baV0uY2xhc3NOYW1lLnJlcGxhY2UoLyBoaWRkZW4vZ2ksICcnKTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIHRoaXMuX3NldFBpdm90U3RhdGUodGhpcy5jb25maWcucGl2b3QgJiYgdGhpcy5jb25maWcucGl2b3Quc3RhdGUgPyB0aGlzLmNvbmZpZy5waXZvdC5zdGF0ZSA6IHt9KTtcclxuICAgICAgICAgICAgICAgIHJldHVybjtcclxuICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgaWYgKHRoaXMuX3Bpdm90RWxlbWVudFsncGl2b3QnXSAmJlxyXG4gICAgICAgICAgICAgICAgdGhpcy5fcGl2b3RFbGVtZW50WydwaXZvdCddLmNsYXNzTmFtZSAmJlxyXG4gICAgICAgICAgICAgICAgdGhpcy5fcGl2b3RFbGVtZW50WydwaXZvdCddLmNsYXNzTmFtZS5pbmRleE9mKCdoaWRkZW4nKSA9PT0gLTFcclxuICAgICAgICAgICAgKSB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLl9waXZvdEVsZW1lbnRbJ3Bpdm90J10uY2xhc3NOYW1lICs9ICcgaGlkZGVuJztcclxuICAgICAgICAgICAgICAgIGZvciAobGV0IGo6IG51bWJlciA9IDA7IGogPCB0aGlzLl9waXZvdEVsZW1lbnRbJ2NvbHVtbi1kcm9wJ10ubGVuZ3RoOyArK2opIHtcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLl9waXZvdEVsZW1lbnRbJ2NvbHVtbi1kcm9wJ11bal0uY2xhc3NOYW1lICs9ICcgaGlkZGVuJztcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB0aGlzLl9lbmFibGVkUGl2b3RNb2RlKGZhbHNlKTtcclxuXHJcbiAgICAgICAgICAgIHRoaXMuX3NldFBpdm90U3RhdGUoe1xyXG4gICAgICAgICAgICAgICAgJ2NvbHVtblN0YXRlJzogW10sXHJcbiAgICAgICAgICAgICAgICAncGl2b3RNb2RlJzogZmFsc2UsXHJcbiAgICAgICAgICAgICAgICAnZ3JvdXBTdGF0ZSc6IFtdXHJcbiAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICB0aGlzLl9yZXNldFBpdm90Q29sdW1uKCk7XHJcbiAgICAgICAgfTtcclxuICAgICAgICBsZXQgY2hlY2sgPSAoKTogYm9vbGVhbiA9PiB7XHJcbiAgICAgICAgICAgIC8vIGlmICh0aGlzLmNvbmZpZy5waXZvdC50b29scGFuZWwudHlwZSA9PT0gJ25vbmUnIHx8ICF0aGlzLmNvbmZpZy5waXZvdCB8fCAhdGhpcy5jb25maWcucGl2b3QudG9vbHBhbmVsKSByZXR1cm4gdHJ1ZTtcclxuICAgICAgICAgICAgaWYgKHRoaXMuY29uZmlnLnBpdm90ICYmXHJcbiAgICAgICAgICAgICAgICB0aGlzLmNvbmZpZy5waXZvdC50b29scGFuZWwgJiZcclxuICAgICAgICAgICAgICAgIHRoaXMuY29uZmlnLnBpdm90LnRvb2xwYW5lbC50eXBlICYmXHJcbiAgICAgICAgICAgICAgICB0aGlzLmNvbmZpZy5waXZvdC50b29scGFuZWwudHlwZSAhPT0gJ25vbmUnXHJcbiAgICAgICAgICAgICkge1xyXG4gICAgICAgICAgICAgICAgbGV0IGlzUGl2b3RFbG1FeGlzdDogYm9vbGVhbiA9IHRoaXMuX2lzUGl2b3RFbG1FeGlzdCh0aGlzLl9waXZvdEVsZW1lbnQpO1xyXG4gICAgICAgICAgICAgICAgaWYgKGlzUGl2b3RFbG1FeGlzdCA9PT0gdHJ1ZSkgcmV0dXJuIGlzUGl2b3RFbG1FeGlzdDtcclxuXHJcbiAgICAgICAgICAgICAgICBsZXQgZG9tRWxlUXVlcnk6IHN0cmluZyA9ICcjJyArIHRoaXMuZ3JpZElkICsgJy5zdGctdGhlbWUgLmFnLXNpZGUtYmFyJztcclxuICAgICAgICAgICAgICAgIHRoaXMuX3Bpdm90RWxlbWVudFsncGl2b3QnXSA9IHRoaXMuX3Zjci5lbGVtZW50Lm5hdGl2ZUVsZW1lbnQucXVlcnlTZWxlY3Rvcihkb21FbGVRdWVyeSArICcgLmFnLXBpdm90LW1vZGUtcGFuZWwnKTtcclxuICAgICAgICAgICAgICAgIHRoaXMuX3Bpdm90RWxlbWVudFsnY29sdW1uLWRyb3AnXSA9IHRoaXMuX3Zjci5lbGVtZW50Lm5hdGl2ZUVsZW1lbnQucXVlcnlTZWxlY3RvckFsbChkb21FbGVRdWVyeSArICcgLmFnLWNvbHVtbi1kcm9wJyk7XHJcbiAgICAgICAgICAgICAgICByZXR1cm4gdGhpcy5faXNQaXZvdEVsbUV4aXN0KHRoaXMuX3Bpdm90RWxlbWVudCk7XHJcbiAgICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgICAgICByZXR1cm4gdHJ1ZTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH07XHJcbiAgICAgICAgdGhpcy53YWl0KGNoZWNrLCBzZXRQaXZvdE1vZGUpO1xyXG4gICAgfVxyXG5cclxuXHJcbiAgICAvKipcclxuICAgICAqIGhpZGUgYW5kIHNob3cgdG9vbHBhbmVsIChwaXZvdCBtb2RlIHBhbmVsKVxyXG4gICAgICogcGFyYW0ge2Jvb2xlYW59IF9zaG93OiB0cnVlIHRvIHNob3csIGZhbHNlIHRvIGhpZGVcclxuICAgICAqL1xyXG4gICAgcHJpdmF0ZSBfc2hvd1Rvb2xQYW5lbChfc2hvdzogYm9vbGVhbik6IHZvaWQge1xyXG4gICAgICAgIGlmICh0aGlzLl90YWJsZVNlcnZpY2UuaXNBcGlSZWFkeSh0aGlzLmdyaWRPcHRpb25zKSkge1xyXG4gICAgICAgICAgICB0aW1lcigxMCkuc3Vic2NyaWJlKCgpOiB2b2lkID0+IHtcclxuICAgICAgICAgICAgICAgIHRoaXMuZ3JpZE9wdGlvbnMuYXBpLnNob3dUb29sUGFuZWwoX3Nob3cpO1xyXG4gICAgICAgICAgICB9KTtcclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgLyoqXHJcbiAgICAgKiBleHBhbmQgcm93IGdyb3VwIGJhc2Ugb24gdGhlIHN0YXR1cyB0aGF0IHBhc3NlZCBpblxyXG4gICAgICogcGFyYW0ge2Jvb2xlYW59IF9leHBhbmQ6IHRydWUgdG8gZXhwYW5kLCBmYWxzZSB0byBjb2xsYXBzZVxyXG4gICAgICovXHJcbiAgICBwcml2YXRlIF9leHBhbmRHcm91cChfZXhwYW5kPzogYm9vbGVhbik6IHZvaWQge1xyXG4gICAgICAgIGlmICh0eXBlb2YgX2V4cGFuZCA9PT0gJ3VuZGVmaW5lZCcpIHtcclxuICAgICAgICAgICAgX2V4cGFuZCA9IGZhbHNlO1xyXG4gICAgICAgICAgICBpZiAodGhpcy5jb25maWcucGl2b3QgJiYgdGhpcy5jb25maWcucGl2b3Quc3RhdGUgJiYgdGhpcy5jb25maWcucGl2b3Quc3RhdGUuZXhwYW5kR3JvdXApIHtcclxuICAgICAgICAgICAgICAgIF9leHBhbmQgPSB0aGlzLmNvbmZpZy5waXZvdC5zdGF0ZS5leHBhbmRHcm91cDtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgICAgICBpZiAodGhpcy5fdGFibGVTZXJ2aWNlLmlzQXBpUmVhZHkodGhpcy5ncmlkT3B0aW9ucykpIHtcclxuICAgICAgICAgICAgdGltZXIoMTApLnN1YnNjcmliZSgoKTogdm9pZCA9PiB7XHJcbiAgICAgICAgICAgICAgICAoX2V4cGFuZCkgPyB0aGlzLmdyaWRPcHRpb25zLmFwaS5leHBhbmRBbGwoKSA6IHRoaXMuZ3JpZE9wdGlvbnMuYXBpLmNvbGxhcHNlQWxsKCk7XHJcbiAgICAgICAgICAgICAgICB0aGlzLl9waXZvdFJlc2l6ZSgpO1xyXG4gICAgICAgICAgICB9KTtcclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgLyoqXHJcbiAgICAgKiB0dXJuIG9uIGFuZCBvZmYgcGl2b3QgbW9kZVxyXG4gICAgICogSWYgb24sICdDb2x1bW4gTGFiZWwnIHdpbGwgYXBwZWFyXHJcbiAgICAgKiBJZiBvbiwgdGljayBjb2x1bW4gbmFtZSBvbiB0b29scGFuZWwgd2lsbCBhc3NpZ24gY29sdW1uIHRvICdSb3cgR3JvdXAnIC8gJ1ZhbHVlcycgZGVwZW5kcyBvbiBjb2xEZWZcclxuICAgICAqIElmIG9mZiwgdGljayBjb2x1bW4gbmFtZSBvbiB0b29scGFuZWwgd2lsbCB0cmlnZ2VyIGNvbHVtbiBoaWRlIGFuZCBzaG93XHJcbiAgICAgKiBwYXJhbSB7Ym9vbGVhbiA9IGZhbHNlfSBfZW5hYmxlZDogdHJ1ZSB0byBjaGVjaywgZmFsc2UgdG8gdW5jaGVja1xyXG4gICAgICovXHJcbiAgICBwcml2YXRlIF9lbmFibGVkUGl2b3RNb2RlKF9lbmFibGVkOiBib29sZWFuID0gZmFsc2UpOiB2b2lkIHtcclxuICAgICAgICB0aGlzLmdyaWRPcHRpb25zLmNvbHVtbkFwaS5zZXRQaXZvdE1vZGUoX2VuYWJsZWQpO1xyXG4gICAgfVxyXG5cclxuICAgIC8vIFRPRE86IHRvIGJlIHJldmlzaXRcclxuICAgIC8qKlxyXG4gICAgICogc3VwcHJlc3NNb3ZhYmxlQ29sdW1ucyBvbiBwaXZvdENvbHVtbnMgYW5kIHJvd0dyb3VwQ29sdW1uc1xyXG4gICAgICogY29sdW1ucyBvbiBwaXZvdCBtb2RlIGRvZXMgbm90IGxpc3RlbiB0byBjb2xEZWYuc3VwcHJlc3NNb3ZhYmxlQ29sdW1ucyA9IHRydWVcclxuICAgICAqIGhlbmNlIHdlIG5lZWQgdG8gYWNjZXNzIHRoZWlyIHByaXZhdGUgdmFyaWFibGUgbG9ja1Bvc2l0aW9uIGFuZCBsb2NrUGlubmVkIHRvIHN1cHByZXNzIHRoZSBjb2x1bW4gbW92ZW1lbnRcclxuICAgICAqIHBhcmFtIHthbnl9IF9jb2x1bW5zIFtlaXRoZXIgcGFzc2VkIGluIGZyb20gZ3JpZEV2ZW50OiBjb2x1bW4gb3Igd2lsbCBnZXRBbGxEaXNwbGF5ZWRDb2x1bW5zXVxyXG4gICAgICovXHJcbiAgICBwcml2YXRlIF9zZXRQaXZvdENvbHVtbnMoX2NvbHVtbnM/OiBhbnkpOiB2b2lkIHtcclxuICAgICAgICBsZXQgaXNQaW5uZWQ6IGJvb2xlYW4gPSBmYWxzZTtcclxuICAgICAgICBpZiAoIV9jb2x1bW5zKSBfY29sdW1ucyA9IHRoaXMuZ3JpZE9wdGlvbnMuY29sdW1uQXBpLmdldEFsbERpc3BsYXllZENvbHVtbnMoKTtcclxuICAgICAgICBfY29sdW1ucy5mb3JFYWNoKChjb2x1bW46IGFueSkgPT4ge1xyXG4gICAgICAgICAgICB0aGlzLl9zZXRDb2x1bW4oY29sdW1uKTtcclxuICAgICAgICAgICAgbGV0IGNvbHVtbkRlZiA9IGNvbHVtbi5nZXRDb2xEZWYoKTtcclxuICAgICAgICAgICAgaWYgKGNvbHVtbkRlZi5waXZvdFZhbHVlQ29sdW1uKSB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLl9zZXRDb2x1bW4oY29sdW1uRGVmLnBpdm90VmFsdWVDb2x1bW4pXHJcbiAgICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgICAgICBpZiAoY29sdW1uLnBhcmVudCkge1xyXG4gICAgICAgICAgICAgICAgICAgIGlzUGlubmVkID0gdHJ1ZTtcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLl9zZXRDb2x1bW4oY29sdW1uLnBhcmVudCwgZmFsc2UpO1xyXG4gICAgICAgICAgICAgICAgICAgIGNvbHVtbi5wYXJlbnQucGlubmVkID0gJ2xlZnQnO1xyXG4gICAgICAgICAgICAgICAgICAgIGNvbHVtbi5waW5uZWQgPSAnbGVmdCc7XHJcbiAgICAgICAgICAgICAgICAgICAgY29sdW1uRGVmLnBpbm5lZCA9ICdsZWZ0JztcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH0pO1xyXG4gICAgICAgIGlmIChpc1Bpbm5lZCkgdGhpcy5fcmVzaXplQ29sdW1uKHRydWUpO1xyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX3NldENvbHVtbihfY29sdW1uOiBhbnksIF9pc1NldENvbERlZjogYm9vbGVhbiA9IHRydWUpOiB2b2lkIHtcclxuICAgICAgICBpZiAoX2lzU2V0Q29sRGVmKSB7XHJcbiAgICAgICAgICAgIGxldCBjb2x1bW5EZWYgPSBfY29sdW1uLmdldENvbERlZigpO1xyXG4gICAgICAgICAgICBjb2x1bW5EZWYuc3VwcHJlc3NNb3ZhYmxlID0gdGhpcy5fc3VwcHJlc3NNb3ZhYmxlQ29sdW1ucztcclxuICAgICAgICAgICAgY29sdW1uRGVmLmxvY2tQb3NpdGlvbiA9IHRoaXMuX3N1cHByZXNzTW92YWJsZUNvbHVtbnM7XHJcbiAgICAgICAgICAgIGNvbHVtbkRlZi5sb2NrUGlubmVkID0gdGhpcy5fc3VwcHJlc3NNb3ZhYmxlQ29sdW1ucztcclxuICAgICAgICB9XHJcbiAgICAgICAgaWYgKF9jb2x1bW4uc2V0TW92aW5nKSB7XHJcbiAgICAgICAgICAgIF9jb2x1bW4uc2V0TW92aW5nKCF0aGlzLl9zdXBwcmVzc01vdmFibGVDb2x1bW5zKTtcclxuICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICBfY29sdW1uLm1vdmluZyA9ICF0aGlzLl9zdXBwcmVzc01vdmFibGVDb2x1bW5zO1xyXG4gICAgICAgIH1cclxuICAgICAgICBfY29sdW1uLmxvY2tQb3NpdGlvbiA9IHRoaXMuX3N1cHByZXNzTW92YWJsZUNvbHVtbnM7XHJcbiAgICAgICAgX2NvbHVtbi5sb2NrUGlubmVkID0gdGhpcy5fc3VwcHJlc3NNb3ZhYmxlQ29sdW1ucztcclxuICAgIH1cclxuICAgIC8vIFRPRE86IHRvIGJlIHJldmlzaXRcclxuXHJcbiAgICAvLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vL1xyXG4gICAgLy8vIENvbHVtbi9Sb3cvQ29uZmlndXJhdGlvbiBHZW5lcmF0aW9uXHJcbiAgICAvLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vL1xyXG4gICAgcHJpdmF0ZSBfc2V0R3JpZE9wdGlvbnMoX3RhYmxlQ29uZmlnOiBJVGFibGVDb25maWcpOiB2b2lkIHtcclxuICAgICAgICBpZiAoX3RhYmxlQ29uZmlnLmhhc093blByb3BlcnR5KCdzdXBwcmVzc01vdmFibGVDb2x1bW5zJykpIHRoaXMuX3N1cHByZXNzTW92YWJsZUNvbHVtbnMgPSBfdGFibGVDb25maWcuc3VwcHJlc3NNb3ZhYmxlQ29sdW1ucztcclxuICAgICAgICB0aGlzLl9kaXJlY3Rpb24gPSA8J3J0bCcgfCAnbHRyJz50aGlzLl9kb21TdmMuZ2V0RG9jdW1lbnREaXJlY3Rpb24oKTtcclxuXHJcbiAgICAgICAgdGhpcy5ncmlkT3B0aW9ucyA9IHRoaXMuX3RhYmxlU2VydmljZS5nZW5lcmF0ZUdyaWRPcHRpb25zKF90YWJsZUNvbmZpZywgdGhpcy5fZGlyZWN0aW9uKTtcclxuICAgICAgICB0aGlzLmdyaWRPcHRpb25zLmNvbnRleHRbJ2dyaWRJZCddID0gdGhpcy5ncmlkSWQ7XHJcbiAgICAgICAgdGhpcy5ncmlkT3B0aW9ucy5zdXBwcmVzc01vdmFibGVDb2x1bW5zID0gZmFsc2U7XHJcbiAgICAgICAgdGhpcy5ncmlkT3B0aW9ucy5vbkNvbHVtblJvd0dyb3VwQ2hhbmdlZCA9IChwYXJhbXM6IGFueSk6IHZvaWQgPT4ge1xyXG4gICAgICAgICAgICB0aGlzLl9zZXRQaXZvdENvbHVtbnMocGFyYW1zLmNvbHVtbnMpO1xyXG4gICAgICAgICAgICB0aGlzLl9leHBhbmRHcm91cCgpO1xyXG4gICAgICAgIH1cclxuICAgICAgICBcclxuICAgICAgICB0aGlzLl90YWJsZVNlcnZpY2Uuc2V0R3JpZE9wdGlvbnModGhpcy5ncmlkT3B0aW9ucyk7XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfc2V0Q29sdW1uRGVmKF9jb2xEZWZDb25maWc6IEFycmF5PElUYWJsZUNvbHVtbj4pOiB2b2lkIHtcclxuICAgICAgICB0aGlzLl90YWJsZVNlcnZpY2Uuc2V0Q29sdW1uRGVmKF9jb2xEZWZDb25maWcsIHRoaXMuY29uZmlnLCB0aGlzLl9zdXBwcmVzc01vdmFibGVDb2x1bW5zKTtcclxuICAgICAgICB0aGlzLl9yZXNpemVDb2x1bW4oKTtcclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF9lbmFibGVDb2x1bW5Nb3ZhYmxlKF9lbmFibGVkOiBib29sZWFuID0gdHJ1ZSk6IHZvaWQge1xyXG4gICAgICAgIGlmICh0aGlzLl90YWJsZVNlcnZpY2UuaXNBcGlSZWFkeSh0aGlzLmdyaWRPcHRpb25zKSkge1xyXG4gICAgICAgICAgICB0aGlzLl9zdXBwcmVzc01vdmFibGVDb2x1bW5zID0gX2VuYWJsZWQ7XHJcblxyXG4gICAgICAgICAgICB0aGlzLl9zZXRDb2x1bW5EZWYodGhpcy5jb2x1bW4pO1xyXG4gICAgICAgICAgICBpZiAodGhpcy5jb25maWcubG9hZFR5cGUgPT09ICdub3JtYWwnICYmIHRoaXMuY29uZmlnLnBpdm90LnRvb2xwYW5lbC50eXBlID09PSAncGl2b3QnKSB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLl9zZXRQaXZvdFN0YXRlKHRoaXMuX2N1cnJlbnRTdGF0ZSk7XHJcbiAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgIHRoaXMuX3Bpdm90UmVzaXplKCk7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX3NldFJvd0RhdGEoX3Jvd0RhdGE6IEFycmF5PGFueT4sIF9zZXRUb0dyaWRPcHRpb25zOiBib29sZWFuID0gdHJ1ZSk6IHZvaWQge1xyXG4gICAgICAgIC8vIHRoaXMuX3RhYmxlU2VydmljZS51cGRhdGVSb3dEYXRhV2l0aENvbHVtbkNvbmZpZyhfcm93RGF0YSwgdGhpcy5jb2x1bW4sIHRoaXMuZ3JpZElkKTtcclxuICAgICAgICB0aGlzLl90YWJsZVNlcnZpY2UudXBkYXRlUm93RGF0YVdpdGhDb2x1bW4oX3Jvd0RhdGEsIHRoaXMuY29sdW1uLCB0aGlzLmdyaWRJZCwgdGhpcy5ncmlkT3B0aW9ucyk7XHJcblxyXG4gICAgICAgIGlmIChfc2V0VG9HcmlkT3B0aW9ucykge1xyXG4gICAgICAgICAgICB0aGlzLl90YWJsZVNlcnZpY2Uuc2V0Um93RGF0YShfcm93RGF0YSk7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICBpZiAodGhpcy5fdGFibGVTZXJ2aWNlLmlzRW50ZXJwcmlzZU1vZGVsKHRoaXMuY29uZmlnLmxvYWRUeXBlKSAmJiB0aGlzLl90YWJsZVNlcnZpY2UuaXNBcGlSZWFkeSh0aGlzLmdyaWRPcHRpb25zKSkge1xyXG4gICAgICAgICAgICB0aGlzLl9ncmlkUmVhZHlFbnRlcnByaXNlQ3ljbGUoKTtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIHRpbWVyKCkuc3Vic2NyaWJlKCgpOiB2b2lkID0+IHtcclxuICAgICAgICAgICAgdGhpcy5fZ3JpZFNldFJvd0N5Y2xlKCk7XHJcbiAgICAgICAgICAgIHRoaXMuX3NldFRhYmxlQm9yZGVyQm90dG9tKCk7XHJcbiAgICAgICAgfSk7XHJcbiAgICB9XHJcblxyXG4gICAgLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy9cclxuICAgIC8vLyBFdmVudHMgLSBTdWJzY3JpYmVyIC8gT24gZnVuY3Rpb25zXHJcbiAgICAvLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vL1xyXG4gICAgcHJpdmF0ZSBfcHJvY2Vzc0V2ZW50UGFyYW1zPFQ+KF9mcm9tRXZlbnQ6IHN0cmluZywgX2FkZGl0aW9uYWxQYXJhbXM6IFQpOiB2b2lkIHtcclxuICAgICAgICBzd2l0Y2ggKF9mcm9tRXZlbnQpIHtcclxuICAgICAgICAgICAgY2FzZSAnZGF0YXNvdXJjZSc6XHJcbiAgICAgICAgICAgIGNhc2UgJ3NlbGVjdGlvbic6XHJcbiAgICAgICAgICAgIGNhc2UgJ2lucHV0JzpcclxuICAgICAgICAgICAgY2FzZSAnYnV0dG9uJzpcclxuICAgICAgICAgICAgICAgIHRoaXMuX2Jyb2FkY2FzdEV2ZW50UGFyYW1zPFQ+KF9hZGRpdGlvbmFsUGFyYW1zKTtcclxuICAgICAgICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgICAgICBkZWZhdWx0OlxyXG4gICAgICAgICAgICAgICAgY29uc29sZS5lcnJvcignS2RUYWJsZSB3YXJuaW5nOiBObyBzdWNoIGV2ZW50IGZvdW5kIGZvcjogJywgX2Zyb21FdmVudCk7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX2Jyb2FkY2FzdEV2ZW50UGFyYW1zPFQ+KF9wYXJhbXM6IFQpOiB2b2lkIHtcclxuICAgICAgICB0aGlzLl90YWJsZUludEV2ZW50LmtkVGFibGVFdmVudExpc3QodGhpcy5jb25maWcuaWQsIF9wYXJhbXMpO1xyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX2Jyb2FkY2FzdE1vZGVsQ2hhbmdlZEV2ZW50KCk6IHZvaWQge1xyXG4gICAgICAgIHRoaXMuX3RhYmxlSW50RXZlbnQubW9kZWxDaGFuZ2VkKHRoaXMuY29uZmlnLmlkKTtcclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF9zZXR1cFN1YnNjcmlwdGlvbkV2ZW50cygpIHtcclxuICAgICAgICB0aGlzLl9zdWJzY3JpcHRpb25PYmouc2VsZWN0Tm9kZXNTdWIgPSB0aGlzLl90YWJsZUludEV2ZW50Lm9uU2VsZWN0aW9uQ2hhbmdlZCh0aGlzLmNvbmZpZy5pZCkuc3Vic2NyaWJlKChfcm93Tm9kZTogUm93Tm9kZSk6IHZvaWQgPT4ge1xyXG4gICAgICAgICAgICB0aGlzLl91cGRhdGVTZWxlY3Rpb25Ob2Rlcyhfcm93Tm9kZSk7XHJcbiAgICAgICAgfSk7XHJcblxyXG4gICAgICAgIHRoaXMuX3N1YnNjcmlwdGlvbk9iai5ncmlkUXVlc3Rpb25TdWIgPSB0aGlzLl90YWJsZUludEV2ZW50Lm9uSW5wdXRDaGFuZ2VkKHRoaXMuY29uZmlnLmlkKS5zdWJzY3JpYmUoKF9mb3JtUGFyYW1zOiBJVGFibGVGb3JtRW1pdFBhcmFtcyk6IHZvaWQgPT4ge1xyXG4gICAgICAgICAgICB0aGlzLl9wcm9jZXNzSW5wdXRDaGFuZ2VkKF9mb3JtUGFyYW1zKTtcclxuICAgICAgICB9KTtcclxuXHJcbiAgICAgICAgdGhpcy5fc3Vic2NyaXB0aW9uT2JqLnVwZGF0ZUVtaXRSb3cgPSB0aGlzLl90YWJsZUludEV2ZW50Lm9uVXBkYXRlRW1pdFJvd05vZGVzKHRoaXMuY29uZmlnLmlkKS5zdWJzY3JpYmUoKF9kYXRhOiB7IGFjdGlvbjogc3RyaW5nLCByb3dEYXRhOiBhbnkgfSk6IHZvaWQgPT4ge1xyXG4gICAgICAgICAgICBpZiAoX2RhdGEuYWN0aW9uID09PSAnZGVsZXRlJykge1xyXG4gICAgICAgICAgICAgICAgbGV0IHJvd0tleTogc3RyaW5nID0gKHR5cGVvZiB0aGlzLmNvbmZpZy5yb3dJZEtleSAhPT0gJ3VuZGVmaW5lZCcpID8gdGhpcy5jb25maWcucm93SWRLZXkgOiAnaWQnO1xyXG4gICAgICAgICAgICAgICAgdGhpcy5fZGVsZXRlTm9kZUZyb21Sb3dEYXRhKFtfZGF0YS5yb3dEYXRhW3Jvd0tleV1dKTtcclxuICAgICAgICAgICAgICAgIHRoaXMuX2VtaXRJbnB1dFVwZGF0ZUV2ZW50KCk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9KTtcclxuICAgIH1cclxuXHJcbiAgICAvLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vL1xyXG4gICAgLy8vIFNlbGVjdGlvbiAtIENoZWNrYm94IC8gUmFkaW8gZnVuY3Rpb25zXHJcbiAgICAvLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vL1xyXG4gICAgcHJpdmF0ZSBfdXBkYXRlU2VsZWN0aW9uTm9kZXMoX3Jvd05vZGU6IFJvd05vZGUsIF9pc0luaXRpYWw/OiBib29sZWFuKTogdm9pZCB7XHJcbiAgICAgICAgbGV0IHRyaWdnZXJOb2RlOiBzdHJpbmcgPSAodHlwZW9mIF9pc0luaXRpYWwgIT09ICd1bmRlZmluZWQnICYmIF9pc0luaXRpYWwpID8gJ2luaXRpYWwnIDogJ2FsbCc7XHJcbiAgICAgICAgaWYgKHR5cGVvZiBfcm93Tm9kZSAhPT0gJ3VuZGVmaW5lZCcpIHtcclxuICAgICAgICAgICAgdHJpZ2dlck5vZGUgPSBfcm93Tm9kZS5kYXRhLmlkO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgbGV0IHNlbGVjdGlvblBhcmFtczogS2RUYWJsZVNlbGVjdGlvblVwZGF0ZUV2ZW50ID0gbmV3IEtkVGFibGVTZWxlY3Rpb25VcGRhdGVFdmVudCgpO1xyXG5cclxuICAgICAgICBzZWxlY3Rpb25QYXJhbXMudHJpZ2dlck5vZGUgPSB0cmlnZ2VyTm9kZTtcclxuICAgICAgICBzZWxlY3Rpb25QYXJhbXMuc2VsZWN0ZWROb2RlcyA9IHRoaXMuX3RhYmxlU2VydmljZS51cGRhdGVTZWxlY3Rpb25WYWx1ZXModGhpcy5ncmlkT3B0aW9ucy5yb3dEYXRhLCB0aGlzLmNvbmZpZy5zZWxlY3Rpb24udmFsdWUsIHRoaXMuY29uZmlnLnNlbGVjdGlvbi5yZXR1cm5LZXksIHRoaXMuY29uZmlnLmxvYWRUeXBlKTtcclxuICAgICAgICAvLyBzZWxlY3Rpb25QYXJhbXMuc2VsZWN0aW9uID0gKF9yb3dOb2RlLmlzU2VsZWN0ZWQoKSkgPyAnc2VsZWN0ZWQnIDogJ3Vuc2VsZWN0ZWQnO1xyXG5cclxuICAgICAgICB0aGlzLl9wcm9jZXNzRXZlbnRQYXJhbXM8S2RUYWJsZVNlbGVjdGlvblVwZGF0ZUV2ZW50Pignc2VsZWN0aW9uJywgc2VsZWN0aW9uUGFyYW1zKTtcclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF9wcm9jZXNzSW5pdGlhbFNlbGVjdGlvbigpOiB2b2lkIHtcclxuICAgICAgICB0aGlzLl91cGRhdGVTZWxlY3Rpb25Ob2Rlcyh1bmRlZmluZWQsIHRydWUpO1xyXG4gICAgfVxyXG5cclxuICAgIC8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vXHJcbiAgICAvLy8gSW5wdXQgZnVuY3Rpb25zXHJcbiAgICAvLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vL1xyXG4gICAgcHJpdmF0ZSBfcHJvY2Vzc0lucHV0Q2hhbmdlZChfZm9ybVBhcmFtczogSVRhYmxlRm9ybUVtaXRQYXJhbXMpOiB2b2lkIHtcclxuICAgICAgICBsZXQgaW5wdXRQYXJhbXM6IEtkVGFibGVJbnB1dFVwZGF0ZUV2ZW50ID0gbmV3IEtkVGFibGVJbnB1dFVwZGF0ZUV2ZW50KCk7XHJcblxyXG4gICAgICAgIGlucHV0UGFyYW1zLmNvbElkID0gX2Zvcm1QYXJhbXMuY29sSWQ7XHJcbiAgICAgICAgaW5wdXRQYXJhbXMucm93SWQgPSBfZm9ybVBhcmFtcy5yb3dJZDtcclxuICAgICAgICBpbnB1dFBhcmFtcy5xdWVzdGlvbktleSA9IF9mb3JtUGFyYW1zLnF1ZXN0aW9uS2V5O1xyXG4gICAgICAgIGlucHV0UGFyYW1zLnF1ZXN0aW9uID0gX2Zvcm1QYXJhbXMucXVlc3Rpb247XHJcbiAgICAgICAgaW5wdXRQYXJhbXMudmFsdWUgPSBfZm9ybVBhcmFtcy5kYXRhO1xyXG5cclxuICAgICAgICB0aGlzLl9wcm9jZXNzRXZlbnRQYXJhbXM8S2RUYWJsZUlucHV0VXBkYXRlRXZlbnQ+KCdpbnB1dCcsIGlucHV0UGFyYW1zKTtcclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF9lbWl0SW5wdXRVcGRhdGVFdmVudCgpOiB2b2lkIHtcclxuICAgICAgICBsZXQgaW5wdXRQYXJhbXM6IEtkVGFibGVJbnB1dFVwZGF0ZUV2ZW50ID0gbmV3IEtkVGFibGVJbnB1dFVwZGF0ZUV2ZW50KCk7XHJcbiAgICAgICAgdGhpcy5fcHJvY2Vzc0V2ZW50UGFyYW1zPEtkVGFibGVJbnB1dFVwZGF0ZUV2ZW50PignaW5wdXQnLCBpbnB1dFBhcmFtcyk7XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfZGVsZXRlTm9kZUZyb21Sb3dEYXRhKF9kYXRhTGlzdDogQXJyYXk8c3RyaW5nPik6IHZvaWQge1xyXG4gICAgICAgIGxldCByb3dJZEtleTogc3RyaW5nID0gKHR5cGVvZiB0aGlzLmNvbmZpZy5yb3dJZEtleSAhPT0gJ3VuZGVmaW5lZCcpID8gdGhpcy5jb25maWcucm93SWRLZXkgOiAnaWQnO1xyXG5cclxuICAgICAgICBmb3IgKGxldCBpOiBudW1iZXIgPSAwOyBpIDwgX2RhdGFMaXN0Lmxlbmd0aDsgKytpKSB7XHJcbiAgICAgICAgICAgIGZvciAobGV0IGo6IG51bWJlciA9IDA7IGogPCB0aGlzLnJvdy5sZW5ndGg7ICsraikge1xyXG4gICAgICAgICAgICAgICAgaWYgKF9kYXRhTGlzdFtpXS50b1N0cmluZygpID09PSB0aGlzLnJvd1tqXVtyb3dJZEtleV0udG9TdHJpbmcoKSkge1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMucm93LnNwbGljZShqLCAxKTtcclxuICAgICAgICAgICAgICAgICAgICBicmVhaztcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICAvLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vL1xyXG4gICAgLy8vIEVudGVycHJpc2UgZGF0YXNvdXJjZSBmdW5jdGlvbnNcclxuICAgIC8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vXHJcbiAgICBwcml2YXRlIF9jbGVhckRhdGFzb3VyY2UoKTogdm9pZCB7XHJcbiAgICAgICAgaWYgKHRoaXMuX3RhYmxlU2VydmljZS5pc0FwaVJlYWR5KHRoaXMuZ3JpZE9wdGlvbnMpKSB7XHJcbiAgICAgICAgICAgIHRoaXMuZ3JpZE9wdGlvbnMuYXBpLnNldEVudGVycHJpc2VEYXRhc291cmNlKG51bGwpO1xyXG4gICAgICAgICAgICB0aGlzLmdyaWRPcHRpb25zLmFwaS5zZXRGaWx0ZXJNb2RlbChudWxsKTtcclxuICAgICAgICAgICAgdGhpcy5ncmlkT3B0aW9ucy5hcGkuc2V0U29ydE1vZGVsKG51bGwpO1xyXG5cclxuICAgICAgICAgICAgaWYgKHR5cGVvZiB0aGlzLl9zdWJzY3JpcHRpb25PYmouZGF0YXNvdXJjZVN1YiAhPT0gJ3VuZGVmaW5lZCcpIHtcclxuICAgICAgICAgICAgICAgIHRoaXMuX3N1YnNjcmlwdGlvbk9iai5kYXRhc291cmNlU3ViLnVuc3Vic2NyaWJlKCk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfZ2VuZXJhdGVFbnRlcnByaXNlRGF0YXNvdXJjZSgpOiB2b2lkIHtcclxuICAgICAgICBsZXQgZGF0YXNvdXJjZTogSUVudGVycHJpc2VEYXRhc291cmNlID0ge1xyXG4gICAgICAgICAgICBnZXRSb3dzOiAoX3BhcmFtczogSUVudGVycHJpc2VHZXRSb3dzUGFyYW1zKTogdm9pZCA9PiB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLl9zaG93TG9hZGluZ092ZXJsYXkodHJ1ZSk7XHJcblxyXG4gICAgICAgICAgICAgICAgaWYgKHR5cGVvZiB0aGlzLl9zdWJzY3JpcHRpb25PYmouZGF0YXNvdXJjZVN1YiAhPT0gJ3VuZGVmaW5lZCcpIHtcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLl9zdWJzY3JpcHRpb25PYmouZGF0YXNvdXJjZVN1Yi51bnN1YnNjcmliZSgpO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgdGhpcy5fc3Vic2NyaXB0aW9uT2JqLmRhdGFzb3VyY2VTdWIgPSB0aGlzLl9nZW5lcmF0ZURhdGFzb3VyY2VSb3dzKF9wYXJhbXMpLnN1YnNjcmliZSgoX3Jlc3BvbnNlOiBJVGFibGVEYXRhc291cmNlUGFyYW1zKTogdm9pZCA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgX3BhcmFtcy5zdWNjZXNzQ2FsbGJhY2soX3Jlc3BvbnNlLnJvd3MsIF9yZXNwb25zZS50b3RhbCk7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5fc2hvd0xvYWRpbmdPdmVybGF5KGZhbHNlKTtcclxuICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfTtcclxuXHJcbiAgICAgICAgdGhpcy5ncmlkT3B0aW9ucy5hcGkuc2V0RW50ZXJwcmlzZURhdGFzb3VyY2UoZGF0YXNvdXJjZSk7XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfZ2VuZXJhdGVEYXRhc291cmNlUm93cyhfZGF0YXNvdXJjZVBhcmFtczogSUVudGVycHJpc2VHZXRSb3dzUGFyYW1zKTogT2JzZXJ2YWJsZTxJVGFibGVEYXRhc291cmNlUGFyYW1zPiB7XHJcbiAgICAgICAgcmV0dXJuIG5ldyBPYnNlcnZhYmxlPElUYWJsZURhdGFzb3VyY2VQYXJhbXM+KChfb2JzZXJ2ZXI6IFN1YnNjcmliZXI8SVRhYmxlRGF0YXNvdXJjZVBhcmFtcz4pOiB2b2lkID0+IHtcclxuICAgICAgICAgICAgc3dpdGNoICh0aGlzLmNvbmZpZy5sb2FkVHlwZSkge1xyXG4gICAgICAgICAgICAgICAgY2FzZSAnaW5maW5pdGUnOlxyXG4gICAgICAgICAgICAgICAgY2FzZSAnb25lc2hvdCc6XHJcbiAgICAgICAgICAgICAgICAgICAgKDxLZFRhYmxlRW50ZXJwcmlzZVN2Yz50aGlzLl90YWJsZVNlcnZpY2UpLmdlbmVyYXRlRGF0YXNvdXJjZVJvd3MoX2RhdGFzb3VyY2VQYXJhbXMucmVxdWVzdCwgdGhpcy5ncmlkT3B0aW9ucy5yb3dEYXRhLnNsaWNlKCkpLnN1YnNjcmliZSgoX3Jlc3BvbnNlOiBJVGFibGVEYXRhc291cmNlUGFyYW1zKTogdm9pZCA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIF9vYnNlcnZlci5uZXh0KF9yZXNwb25zZSk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIF9vYnNlcnZlci5jb21wbGV0ZSgpO1xyXG4gICAgICAgICAgICAgICAgICAgIH0pO1xyXG5cclxuICAgICAgICAgICAgICAgICAgICBicmVhaztcclxuICAgICAgICAgICAgICAgIGNhc2UgJ3NlcnZlcic6XHJcbiAgICAgICAgICAgICAgICAgICAgbGV0IHNlcnZlclBhcmFtczogS2RUYWJsZURhdGFzb3VyY2VFdmVudCA9IG5ldyBLZFRhYmxlRGF0YXNvdXJjZUV2ZW50KF9kYXRhc291cmNlUGFyYW1zLnJlcXVlc3QsIF9vYnNlcnZlcik7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5fcHJvY2Vzc0V2ZW50UGFyYW1zPEtkVGFibGVEYXRhc291cmNlRXZlbnQ+KCdkYXRhc291cmNlJywgc2VydmVyUGFyYW1zKTtcclxuXHJcbiAgICAgICAgICAgICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgICAgICAgICBkZWZhdWx0OlxyXG4gICAgICAgICAgICAgICAgICAgIGNvbnNvbGUuZXJyb3IoJ0tkVGFibGUgd2FybmluZzogTm8gc3VjaCBsb2FkVHlwZSBmaW5kIGZvcjogJywgdGhpcy5jb25maWcubG9hZFR5cGUpO1xyXG4gICAgICAgICAgICAgICAgICAgIF9vYnNlcnZlci5jb21wbGV0ZSgpO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfSk7XHJcbiAgICB9XHJcblxyXG4gICAgLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy9cclxuICAgIC8vLyBBUEkgZnVuY3Rpb25zXHJcbiAgICAvLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vL1xyXG4gICAgcHJpdmF0ZSBfaW5pdElUYWJsZUFwaSgpOiB2b2lkIHtcclxuICAgICAgICBpZiAodHlwZW9mIHRoaXMuYXBpICE9PSAndW5kZWZpbmVkJykge1xyXG4gICAgICAgICAgICBsZXQgYXBpUGFyYW1zOiBhbnkgPSB7XHJcbiAgICAgICAgICAgICAgICAvLyBncmlkT3B0aW9uczogdGhpcy5ncmlkT3B0aW9ucyxcclxuICAgICAgICAgICAgICAgIGV2ZW50OiB0aGlzLl90YWJsZUludEV2ZW50LFxyXG4gICAgICAgICAgICAgICAgaWQ6IHRoaXMuY29uZmlnLmlkLFxyXG4gICAgICAgICAgICAgICAgcm93czogdGhpcy5yb3csXHJcbiAgICAgICAgICAgICAgICBjb2x1bW5zOiB0aGlzLmNvbHVtblxyXG4gICAgICAgICAgICB9O1xyXG5cclxuICAgICAgICAgICAgdGhpcy5fdGFibGVTZXJ2aWNlLmdlbmVyYXRlZEFwaUZ1bmN0aW9ucyh0aGlzLmFwaSwgYXBpUGFyYW1zKTtcclxuXHJcbiAgICAgICAgICAgIC8vLyBUZW1wIGZpeCB0byBhY2Nlc3MgbG9hZGluZyB2YXJpYWJsZSAvL1xyXG4gICAgICAgICAgICAvKioqKioqKioqIEdlbmVyYWwgQVBJICoqKioqKioqKiovXHJcbiAgICAgICAgICAgIHRoaXMuYXBpLmdlbmVyYWwuc2hvd0xvYWRpbmcgPSAoX3RvZ2dsZTogYm9vbGVhbik6IHZvaWQgPT4ge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5kaXNwbGF5TG9hZGluZyA9IF90b2dnbGU7XHJcbiAgICAgICAgICAgIH07XHJcblxyXG4gICAgICAgICAgICB0aGlzLmFwaS5nZW5lcmFsLnVwZGF0ZUNlbGwgPSAoX3RhYmxlQ2VsbFBhcmFtczogSVRhYmxlQ2VsbFBhcmFtcyk6IHZvaWQgPT4ge1xyXG4gICAgICAgICAgICAgICAgbGV0IHRvVXBkYXRlTm9kZTogQXJyYXk8Um93Tm9kZT4gPSBbXTtcclxuXHJcbiAgICAgICAgICAgICAgICB0aGlzLmdyaWRPcHRpb25zLmFwaS5mb3JFYWNoTm9kZSgoX3Jvd05vZGU6IFJvd05vZGUpOiB2b2lkID0+IHtcclxuICAgICAgICAgICAgICAgICAgICBpZiAodHlwZW9mIF9yb3dOb2RlLmlkICE9PSAndW5kZWZpbmVkJyAmJiBfcm93Tm9kZS5pZCA9PT0gX3RhYmxlQ2VsbFBhcmFtcy5yb3dJZCkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBfcm93Tm9kZS5kYXRhW190YWJsZUNlbGxQYXJhbXMuY29sSWRdID0gX3RhYmxlQ2VsbFBhcmFtcy5kYXRhO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB0b1VwZGF0ZU5vZGUucHVzaChfcm93Tm9kZSk7XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgfSk7XHJcblxyXG4gICAgICAgICAgICAgICAgbGV0IHJlZnJlc2hQYXJhbXM6IHsgcm93Tm9kZXM6IEFycmF5PFJvd05vZGU+LCBjb2x1bW5zOiBBcnJheTxhbnk+IH0gPSB7XHJcbiAgICAgICAgICAgICAgICAgICAgcm93Tm9kZXM6IHRvVXBkYXRlTm9kZSxcclxuICAgICAgICAgICAgICAgICAgICBjb2x1bW5zOiBbX3RhYmxlQ2VsbFBhcmFtcy5jb2xJZF1cclxuICAgICAgICAgICAgICAgIH07XHJcblxyXG4gICAgICAgICAgICAgICAgdGhpcy5ncmlkT3B0aW9ucy5hcGkucmVmcmVzaENlbGxzKHJlZnJlc2hQYXJhbXMpO1xyXG4gICAgICAgICAgICB9O1xyXG5cclxuICAgICAgICAgICAgdGhpcy5hcGkuZ2VuZXJhbC5zZWFyY2hSb3cgPSAoX3NlYXJjaFRleHQ6IHN0cmluZyk6IHZvaWQgPT4ge1xyXG4gICAgICAgICAgICAgICAgaWYgKHRoaXMuY29uZmlnLmxvYWRUeXBlID09PSAnbm9ybWFsJykge1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuZ3JpZE9wdGlvbnMuYXBpLnNldFF1aWNrRmlsdGVyKF9zZWFyY2hUZXh0KTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgICAgIGNvbnNvbGUud2FybignS2RUYWJsZSB3YXJuaW5nOiBRdWljayBmaWx0ZXJpbmcgb2YgZGF0YSBpcyBub3Qgc3VwcG9ydGVkIGZvciBvbmVzaG90L3NlcnZlci9pbmZpbml0ZSBsb2FkVHlwZS4nKTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfTtcclxuXHJcbiAgICAgICAgICAgIHRoaXMuYXBpLmdlbmVyYWwuYWRkUm93cyA9IChfcm93czogQXJyYXk8YW55PiwgX3Njcm9sbFRvVmlzaWJsZTogYm9vbGVhbiA9IGZhbHNlKTogdm9pZCA9PiB7XHJcbiAgICAgICAgICAgICAgICAvKlxyXG4gICAgICAgICAgICAgICAgICAgIGFnLUdyaWQgZGlkIG5vdCBleHBvcnQgUm93RGF0YVRyYW5zYWN0aW9uIGludGVyZmFjZS4gSW50ZXJmYWNlIGFzOlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBhZGQ6IFtdLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcmVtb3ZlOiBbXSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHVwZGF0ZTogW11cclxuICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICovXHJcbiAgICAgICAgICAgICAgICBpZiAodHlwZW9mIHRoaXMuY29uZmlnLmxvYWRUeXBlID09PSAndW5kZWZpbmVkJyB8fCB0aGlzLmNvbmZpZy5sb2FkVHlwZSA9PT0gJ25vcm1hbCcpIHtcclxuICAgICAgICAgICAgICAgICAgICBsZXQgcm93S2V5OiBzdHJpbmcgPSAodHlwZW9mIHRoaXMuY29uZmlnLnJvd0lkS2V5ICE9PSAndW5kZWZpbmVkJykgPyB0aGlzLmNvbmZpZy5yb3dJZEtleSA6ICdpZCc7XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIGZvciAobGV0IGk6IG51bWJlciA9IDA7IGkgPCBfcm93cy5sZW5ndGg7ICsraSkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLnJvdy5wdXNoKF9yb3dzW2ldKTtcclxuICAgICAgICAgICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuX3NldFJvd0RhdGEodGhpcy5yb3csIGZhbHNlKTtcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLmdyaWRPcHRpb25zLmFwaS51cGRhdGVSb3dEYXRhKHsgYWRkOiBfcm93cy5zbGljZSgpIH0pO1xyXG5cclxuICAgICAgICAgICAgICAgICAgICBpZiAoX3Njcm9sbFRvVmlzaWJsZSkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLmdyaWRPcHRpb25zLmFwaS5lbnN1cmVJbmRleFZpc2libGUodGhpcy5ncmlkT3B0aW9ucy5hcGkuZ2V0Um93Tm9kZShfcm93c1swXVtyb3dLZXldLnRvU3RyaW5nKCkpLnJvd0luZGV4KTtcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgICAgICAgICBjb25zb2xlLndhcm4oJ0tkVGFibGUgd2FybmluZzogQVBJIGZ1bmN0aW9uOiBhZGRSb3dzKCkgY2FuIG9ubHkgYmUgdXNlZCBmb3Igbm9ybWFsIGxvYWRUeXBlLicpO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9O1xyXG5cclxuICAgICAgICAgICAgdGhpcy5hcGkuZ2VuZXJhbC5kZWxldGVSb3dzID0gKF9pZDogQXJyYXk8c3RyaW5nIHwgbnVtYmVyPiB8IHN0cmluZyB8IG51bWJlcik6IHZvaWQgPT4ge1xyXG4gICAgICAgICAgICAgICAgaWYgKHR5cGVvZiB0aGlzLmNvbmZpZy5sb2FkVHlwZSA9PT0gJ3VuZGVmaW5lZCcgfHwgdGhpcy5jb25maWcubG9hZFR5cGUgPT09ICdub3JtYWwnKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgbGV0IGRlbGV0ZUlkTGlzdDogQXJyYXk8c3RyaW5nPiA9IFtdO1xyXG5cclxuICAgICAgICAgICAgICAgICAgICBpZiAodHlwZW9mIF9pZCA9PT0gJ3N0cmluZycgfHwgdHlwZW9mIF9pZCA9PT0gJ251bWJlcicpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgZGVsZXRlSWRMaXN0LnB1c2goX2lkLnRvU3RyaW5nKCkpO1xyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgZm9yIChsZXQgaTogbnVtYmVyID0gMDsgaSA8IF9pZC5sZW5ndGg7ICsraSkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgZGVsZXRlSWRMaXN0LnB1c2goX2lkLnRvU3RyaW5nKCkpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgICAgICAgICB0aGlzLl9kZWxldGVOb2RlRnJvbVJvd0RhdGEoZGVsZXRlSWRMaXN0KTtcclxuXHJcbiAgICAgICAgICAgICAgICAgICAgbGV0IGtleTogc3RyaW5nID0gdHlwZW9mIHRoaXMuY29uZmlnLnJvd0lkS2V5ID09PSAndW5kZWZpbmVkJyA/ICdpZCcgOiB0aGlzLmNvbmZpZy5yb3dJZEtleTtcclxuICAgICAgICAgICAgICAgICAgICBsZXQgZGVsZXRlUm93czogQXJyYXk8YW55PiA9IFtdO1xyXG5cclxuICAgICAgICAgICAgICAgICAgICBmb3IgKGxldCBpOiBudW1iZXIgPSAwOyBpIDwgZGVsZXRlSWRMaXN0Lmxlbmd0aDsgKytpKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGRlbGV0ZVJvd3MucHVzaCh7IFtrZXldOiBkZWxldGVJZExpc3RbaV0gfSk7XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgICAgICAgICAvKlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBhZy1HcmlkIGRpZCBub3QgZXhwb3J0IFJvd0RhdGFUcmFuc2FjdGlvbiBpbnRlcmZhY2UuIEludGVyZmFjZSBhczpcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBhZGQ6IFtdLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJlbW92ZTogW10sXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdXBkYXRlOiBbXVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAqL1xyXG5cclxuICAgICAgICAgICAgICAgICAgICBsZXQgdHJhbnNhY3Rpb25PYmo6IHsgYWRkPzogQXJyYXk8YW55PiwgcmVtb3ZlPzogQXJyYXk8YW55PiwgdXBkYXRlPzogQXJyYXk8YW55PiB9ID0ge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICByZW1vdmU6IGRlbGV0ZVJvd3NcclxuICAgICAgICAgICAgICAgICAgICB9O1xyXG5cclxuICAgICAgICAgICAgICAgICAgICB0aGlzLmdyaWRPcHRpb25zLmFwaS51cGRhdGVSb3dEYXRhKHRyYW5zYWN0aW9uT2JqKTtcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLl9lbWl0SW5wdXRVcGRhdGVFdmVudCgpO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgZWxzZSB7XHJcbiAgICAgICAgICAgICAgICAgICAgY29uc29sZS53YXJuKCdLZFRhYmxlIHdhcm5pbmc6IEFQSSBmdW5jdGlvbjogYWRkUm93cygpIGNhbiBvbmx5IGJlIHVzZWQgZm9yIG5vcm1hbCBsb2FkVHlwZS4nKTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfTtcclxuXHJcbiAgICAgICAgICAgIHRoaXMuYXBpLmdlbmVyYWwuc2V0QnV0dG9uRGlzYWJsZWQgPSAoX2J1dHRvblR5cGU6IHN0cmluZywgX3RvRGlzYWJsZWQ6IGJvb2xlYW4pID0+IHtcclxuICAgICAgICAgICAgICAgIGZvciAobGV0IGk6IG51bWJlciA9IDA7IGkgPCB0aGlzLmNvbmZpZy5idXR0b24ubGVuZ3RoOyArK2kpIHtcclxuICAgICAgICAgICAgICAgICAgICBpZiAodGhpcy5jb25maWcuYnV0dG9uW2ldLnR5cGUgPT09IF9idXR0b25UeXBlKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuY29uZmlnLmJ1dHRvbltpXS5kaXNhYmxlZCA9IF90b0Rpc2FibGVkO1xyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfTtcclxuXHJcbiAgICAgICAgICAgIHRoaXMuYXBpLmdlbmVyYWwuZXhwb3J0VG9FeGNlbCA9IChfcGFyYW1zOiBFeGNlbEV4cG9ydFBhcmFtcyk6IHZvaWQgPT4ge1xyXG4gICAgICAgICAgICAgICAgbGV0IGRlZmF1bHRQYXJhbXM6IEV4Y2VsRXhwb3J0UGFyYW1zID0ge1xyXG4gICAgICAgICAgICAgICAgICAgIGZpbGVOYW1lOiAnZmlsZScsXHJcbiAgICAgICAgICAgICAgICAgICAgYWxsQ29sdW1uczogdHJ1ZSxcclxuICAgICAgICAgICAgICAgICAgICBzdXBwcmVzc1RleHRBc0NEQVRBOiB0cnVlLFxyXG4gICAgICAgICAgICAgICAgfTtcclxuICAgICAgICAgICAgICAgIC8vIHhsc3ggb25seSBhbGxvdyBzaGVldCBuYW1lIHRvIGJlIDMxIGNoYXJhY3RlcnMgbG9uZztcclxuICAgICAgICAgICAgICAgIGlmIChfcGFyYW1zLmhhc093blByb3BlcnR5KCdzaGVldE5hbWUnKSkgX3BhcmFtcy5zaGVldE5hbWUgPSBfcGFyYW1zLnNoZWV0TmFtZS5zbGljZSgwLCAzMSk7XHJcbiAgICAgICAgICAgICAgICBsZXQgcGFyYW1zOiBFeGNlbEV4cG9ydFBhcmFtcyA9IE9iamVjdC5hc3NpZ24oe30sIGRlZmF1bHRQYXJhbXMsIF9wYXJhbXMpO1xyXG4gICAgICAgICAgICAgICAgbGV0IGNvbnRlbnQ6IGFueSA9IHRoaXMuZ3JpZE9wdGlvbnMuYXBpLmdldERhdGFBc0V4Y2VsKHBhcmFtcyk7XHJcbiAgICAgICAgICAgICAgICBsZXQgd29ya2Jvb2s6IGFueSA9IFhMU1gucmVhZChjb250ZW50LCB7IHR5cGU6ICdiaW5hcnknIH0pO1xyXG4gICAgICAgICAgICAgICAgbGV0IHhsc3hDb250ZW50OiBhbnkgPSBYTFNYLndyaXRlKHdvcmtib29rLCB7IGJvb2tUeXBlOiAneGxzeCcsIHR5cGU6ICdiYXNlNjQnIH0pO1xyXG4gICAgICAgICAgICAgICAgbGV0IGJsb2JPYmplY3Q6IEJsb2IgPSB0aGlzLl90YWJsZVNlcnZpY2UuYjY0dG9CbG9iKHhsc3hDb250ZW50LCAnYXBwbGljYXRpb24vdm5kLm9wZW54bWxmb3JtYXRzLW9mZmljZWRvY3VtZW50LnNwcmVhZHNoZWV0bWwuc2hlZXQnKTtcclxuICAgICAgICAgICAgICAgIHNhdmVBcyhibG9iT2JqZWN0LCBwYXJhbXMuZmlsZU5hbWUgKyAnLnhsc3gnKTtcclxuICAgICAgICAgICAgfTtcclxuXHJcbiAgICAgICAgICAgIHRoaXMuYXBpLmdlbmVyYWwucmVzaXplQ29sdW1uID0gKF9pc1Jlc2l6ZVRvQ29udGVudDogYm9vbGVhbiA9IGZhbHNlKTogdm9pZCA9PiB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLl9yZXNpemVDb2x1bW4oX2lzUmVzaXplVG9Db250ZW50KTtcclxuICAgICAgICAgICAgfTtcclxuXHJcbiAgICAgICAgICAgIHRoaXMuYXBpLmdlbmVyYWwuZW5hYmxlQ29sdW1uTW92YWJsZSA9IChfZW5hYmxlZDogYm9vbGVhbik6IHZvaWQgPT4ge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5fZW5hYmxlQ29sdW1uTW92YWJsZShfZW5hYmxlZCk7XHJcbiAgICAgICAgICAgIH07XHJcblxyXG4gICAgICAgICAgICAvKioqKioqKioqIFBpdm90IEFQSSAqKioqKioqKioqL1xyXG4gICAgICAgICAgICBpZiAodHlwZW9mICh0aGlzLmFwaS5waXZvdCkgPT09ICd1bmRlZmluZWQnKSB0aGlzLmFwaS5waXZvdCA9IHt9O1xyXG4gICAgICAgICAgICB0aGlzLmFwaS5waXZvdC5hdXRvUmVzaXplID0gKCk6IHZvaWQgPT4ge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5fcGl2b3RSZXNpemUoKTtcclxuICAgICAgICAgICAgfTtcclxuXHJcbiAgICAgICAgICAgIHRoaXMuYXBpLnBpdm90LnNob3dUb29sUGFuZWwgPSAoX3Nob3c6IGJvb2xlYW4pOiB2b2lkID0+IHtcclxuICAgICAgICAgICAgICAgIHRoaXMuX3Nob3dUb29sUGFuZWwoX3Nob3cpO1xyXG4gICAgICAgICAgICB9O1xyXG5cclxuICAgICAgICAgICAgdGhpcy5hcGkucGl2b3QuZXhwYW5kR3JvdXAgPSAoX2V4cGFuZDogYm9vbGVhbik6IHZvaWQgPT4ge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5fZXhwYW5kR3JvdXAoX2V4cGFuZCk7XHJcbiAgICAgICAgICAgIH07XHJcblxyXG4gICAgICAgICAgICB0aGlzLmFwaS5waXZvdC5nZXRQaXZvdFN0YXRlID0gKCk6IElUYWJsZVBpdm90U3RhdGUgPT4ge1xyXG4gICAgICAgICAgICAgICAgcmV0dXJuIHRoaXMuX2dldFBpdm90U3RhdGUoKTtcclxuICAgICAgICAgICAgfTtcclxuXHJcbiAgICAgICAgICAgIHRoaXMuYXBpLnBpdm90LnNldFBpdm90U3RhdGUgPSAoX3N0YXRlOiBJVGFibGVQaXZvdFN0YXRlKTogdm9pZCA9PiB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLl9zZXRDb2x1bW5EZWYodGhpcy5jb2x1bW4pO1xyXG4gICAgICAgICAgICAgICAgdGhpcy5fc2V0UGl2b3RTdGF0ZShfc3RhdGUpO1xyXG4gICAgICAgICAgICB9O1xyXG5cclxuICAgICAgICAgICAgdGhpcy5hcGkucGl2b3QuZW5hYmxlZFBpdm90TW9kZSA9IChfZW5hYmxlZDogYm9vbGVhbik6IHZvaWQgPT4ge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5fZW5hYmxlZFBpdm90TW9kZShfZW5hYmxlZCk7XHJcbiAgICAgICAgICAgIH07XHJcblxyXG4gICAgICAgICAgICB0aGlzLmFwaS5waXZvdC5zaG93UGl2b3RNb2RlID0gKF9zaG93OiBib29sZWFuKTogdm9pZCA9PiB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLl9zaG93UGl2b3RNb2RlKF9zaG93KTtcclxuICAgICAgICAgICAgfTtcclxuXHJcbiAgICAgICAgICAgIC8qKioqKioqKiogSW5wdXQgQVBJICoqKioqKioqKiovXHJcbiAgICAgICAgICAgIHRoaXMuYXBpLmR5bmFtaWNGb3JtLmNsZWFyQWxsRXJyb3IgPSAoKTogdm9pZCA9PiB7XHJcbiAgICAgICAgICAgICAgICBsZXQgdGFibGVDb250ZXh0OiB7IFtrZXk6IHN0cmluZ106IGFueSB9ID0gdGhpcy5ncmlkT3B0aW9ucy5jb250ZXh0W3RoaXMuX3RhYmxlU2VydmljZS5nZXRUYWJsZUNvbnRleHRLZXkoKV07XHJcblxyXG4gICAgICAgICAgICAgICAgZm9yIChsZXQgaXRlbSBpbiB0YWJsZUNvbnRleHQpIHtcclxuICAgICAgICAgICAgICAgICAgICBpZiAodGFibGVDb250ZXh0Lmhhc093blByb3BlcnR5KGl0ZW0pKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGxldCBjb250ZXh0SXRlbTogYW55ID0gdGFibGVDb250ZXh0W2l0ZW1dO1xyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgZm9yIChsZXQgcXVlc3Rpb24gaW4gY29udGV4dEl0ZW0pIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmIChjb250ZXh0SXRlbS5oYXNPd25Qcm9wZXJ0eShxdWVzdGlvbikpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAodHlwZW9mIGNvbnRleHRJdGVtW3F1ZXN0aW9uXS5lcnJvcnMgPT09ICd1bmRlZmluZWQnKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnRleHRJdGVtW3F1ZXN0aW9uXS5lcnJvcnMgPSBbXTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnRleHRJdGVtW3F1ZXN0aW9uXS5lcnJvcnMubGVuZ3RoID0gMDtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfTtcclxuICAgICAgICB9XHJcbiAgICAgICAgZWxzZSB7XHJcbiAgICAgICAgICAgIGNvbnNvbGUud2FybignS2RUYWJsZSB3YXJuaW5nOiBObyBhcGkgcHJvcGVydHkgLyB1bmRlZmluZWQgYXBpIHByb3BlcnR5IGlzIHBhc3NlZCBpbi4nKTtcclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy9cclxuICAgIC8vLyBNaXNjIGZ1bmN0aW9uc1xyXG4gICAgLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy9cclxuICAgIHByaXZhdGUgX2luaXRHcmlkU2VydmljZShfbG9hZFR5cGU6IHN0cmluZyk6IHZvaWQge1xyXG4gICAgICAgIGlmICh0eXBlb2YgX2xvYWRUeXBlID09PSAndW5kZWZpbmVkJyB8fCBfbG9hZFR5cGUgPT09ICdub3JtYWwnKSB7XHJcbiAgICAgICAgICAgIHRoaXMuX3RhYmxlU2VydmljZSA9IG5ldyBLZFRhYmxlTm9ybWFsU3ZjKCk7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICB0aGlzLl90YWJsZVNlcnZpY2UgPSBuZXcgS2RUYWJsZUVudGVycHJpc2VTdmMoKTtcclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfdXBkYXRlR3JpZENvbmZpZyhfZ3JpZENvbmZpZzogSVRhYmxlQ29uZmlnKTogdm9pZCB7XHJcbiAgICAgICAgdGhpcy5ncmlkSWQgPSB0aGlzLl90YWJsZVNlcnZpY2UuZ2V0R3JpZElkKF9ncmlkQ29uZmlnKTtcclxuXHJcbiAgICAgICAgdGhpcy5fdGFibGVTZXJ2aWNlLnVwZGF0ZUdyaWRCdXR0b25zKF9ncmlkQ29uZmlnKTtcclxuICAgICAgICB0aGlzLl90YWJsZVNlcnZpY2UudXBkYXRlU2VsZWN0RGVmYXVsdFZhbHVlKF9ncmlkQ29uZmlnKTtcclxuICAgIH1cclxufVxyXG4iXX0=