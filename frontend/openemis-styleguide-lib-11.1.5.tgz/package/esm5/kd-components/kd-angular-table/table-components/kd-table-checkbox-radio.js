import { __decorate, __metadata } from "tslib";
import { Component } from '@angular/core';
import { KdIntTableEvent } from '../kd-angular-table-event';
var KdTableCheckboxRadio = /** @class */ (function () {
    function KdTableCheckboxRadio(_kdIntTableEvent) {
        this._kdIntTableEvent = _kdIntTableEvent;
        this._inputType = 'checkbox';
        this._isHeader = false;
        this._selectAll = false;
        this._paramsDefault = [];
        this._paramGridId = 'kd-table-grid';
        this._subscriptionObj = {};
    }
    /********************* Component Life cycles functions *************************/
    KdTableCheckboxRadio.prototype.agInit = function (_params) {
        // console.log("-- Grid state: Checkbox/Radio agInit --", _params);
        this._params = _params;
        this._paramsApi = this._params.api;
        this._paramGridId = this._params.params.gridId;
        this._isHeader = typeof this._params.rowIndex === 'undefined';
        this._getDefaultSelection();
        this._updateInputType();
        if (!this._isHeader) {
            this._paramNode = this._params.node;
            this._updateInitialSelection();
        }
        this._setupSubscriptionEvents();
    };
    KdTableCheckboxRadio.prototype.refresh = function (_params) {
        return false;
    };
    KdTableCheckboxRadio.prototype.ngOnDestroy = function () {
        for (var item in this._subscriptionObj) {
            if (this._subscriptionObj.hasOwnProperty(item)) {
                this._subscriptionObj[item].unsubscribe();
            }
        }
    };
    KdTableCheckboxRadio.prototype._updateCheckbox = function (_event) {
        // console.log("-- Grid state: Checkbox/Radio checked --")
        var inputTarget = event.target;
        this._updateSelection(inputTarget.checked);
    };
    /**************************** Private functions ********************************/
    ///////////////////////////////////////////////////////////////////////////////////////////////
    /// Update functions
    ///////////////////////////////////////////////////////////////////////////////////////////////
    KdTableCheckboxRadio.prototype._updateSelection = function (_isChecked) {
        if (this._isHeader) {
            this._selectAll = _isChecked;
            this._updateAllCheckbox();
        }
        else {
            if (this._inputType === 'checkbox') {
                this._paramNode.selectThisNode(_isChecked);
                this._updateDefaultValue(this._paramNode.id, _isChecked);
            }
            else {
                this._paramsApi.deselectAll();
                this._paramNode.selectThisNode(true);
                this._updateDefaultValue(this._paramNode.id, true, true);
            }
        }
        this._emitSelectionChanged();
    };
    ///////////////////////////////////////////////////////////////////////////////////////////////
    /// Checkbox / Checkbox all functions
    ///////////////////////////////////////////////////////////////////////////////////////////////
    KdTableCheckboxRadio.prototype._updateAllCheckbox = function () {
        var _this = this;
        var currentModel = this._getCurrentRowModel();
        if (currentModel !== null) {
            currentModel.forEachNode(function (_rowNode) {
                _rowNode.selectThisNode(_this._selectAll);
                _this._updateDefaultValue(_rowNode.data.id, _this._selectAll);
            });
        }
    };
    KdTableCheckboxRadio.prototype._checkSelectAll = function () {
        var currentModel = this._getCurrentRowModel();
        var selectAll = true;
        if (currentModel !== null) {
            if (currentModel.getRowCount() === 0) {
                selectAll = false;
            }
            else {
                currentModel.forEachNode(function (_rowNode) {
                    if (selectAll && !_rowNode.isSelected()) {
                        selectAll = false;
                    }
                });
            }
        }
        this._selectAll = selectAll;
    };
    ///////////////////////////////////////////////////////////////////////////////////////////////
    /// Default value functions
    ///////////////////////////////////////////////////////////////////////////////////////////////
    KdTableCheckboxRadio.prototype._updateInitialSelection = function () {
        var isSelected = false;
        if (typeof this._paramsDefault !== 'undefined') {
            for (var i = 0; i < this._paramsDefault.length; ++i) {
                if (this._paramsDefault[i].toString() === this._paramNode.id) {
                    isSelected = true;
                    break;
                }
            }
        }
        this._paramNode.selectThisNode(isSelected);
    };
    KdTableCheckboxRadio.prototype._getDefaultSelection = function () {
        if (typeof this._params.params !== 'undefined' &&
            typeof this._params.params.default !== 'undefined') {
            this._paramsDefault = this._params.params.default;
        }
    };
    KdTableCheckboxRadio.prototype._updateDefaultValue = function (_id, _isSelected, _toEmptyDefault) {
        if (_toEmptyDefault) {
            this._paramsDefault.splice(0, this._paramsDefault.length);
        }
        if (_isSelected && this._paramsDefault.indexOf(_id) < 0) {
            this._paramsDefault.push(_id);
        }
        else if (!_isSelected && this._paramsDefault.indexOf(_id) > -1) {
            this._paramsDefault.splice(this._paramsDefault.indexOf(_id), 1);
        }
        this._sortDefaultValue();
    };
    ///////////////////////////////////////////////////////////////////////////////////////////////
    /// Events - Subscriber / On functions
    ///////////////////////////////////////////////////////////////////////////////////////////////
    KdTableCheckboxRadio.prototype._emitSelectionChanged = function () {
        this._kdIntTableEvent.selectionChanged(this._paramGridId, this._paramNode);
    };
    KdTableCheckboxRadio.prototype._setupSubscriptionEvents = function () {
        var _this = this;
        if (this._isHeader) {
            this._subscriptionObj.headerCheckboxSub = this._kdIntTableEvent.onModelChanged(this._paramGridId).subscribe(function () {
                _this._checkSelectAll();
            });
            this._subscriptionObj.selectedChangeSub = this._kdIntTableEvent.onSelectionChanged(this._paramGridId).subscribe(function () {
                _this._checkSelectAll();
            });
        }
    };
    ///////////////////////////////////////////////////////////////////////////////////////////////
    /// Misc functions
    ///////////////////////////////////////////////////////////////////////////////////////////////
    KdTableCheckboxRadio.prototype._updateInputType = function () {
        if (typeof this._params.params !== 'undefined') {
            this._inputType = this._params.params.inputType;
        }
        else {
            this._inputType = 'checkbox';
        }
    };
    KdTableCheckboxRadio.prototype._getCurrentRowModel = function () {
        if (typeof this._paramsApi !== 'undefined') {
            return this._paramsApi.getModel();
        }
        return null;
    };
    KdTableCheckboxRadio.prototype._sortDefaultValue = function () {
        this._paramsDefault.sort(function (_a, _b) {
            if (_a > _b)
                return 1;
            else if (_a < _b)
                return -1;
            return 0;
        });
    };
    KdTableCheckboxRadio.ctorParameters = function () { return [
        { type: KdIntTableEvent }
    ]; };
    KdTableCheckboxRadio = __decorate([
        Component({
            selector: 'ag-checkbox-radio',
            template: "\n        <div class=\"selection-wrapper\">\n            <input *ngIf=\"_isHeader\" class=\"checkbox-radio-input\"\n                type=\"checkbox\"\n                [checked]=\"_selectAll\"\n                (change)=\"_updateCheckbox($event)\"\n            />\n\n            <input *ngIf=\"!_isHeader\" class=\"checkbox-radio-input\"\n                [type]=\"_inputType\"\n                [attr.name]=\"_inputType\"\n                [checked]=\"(_paramNode) ? _paramNode.isSelected() : false\"\n                (change)=\"_updateCheckbox($event)\"\n            />\n            <label></label>\n        </div>\n    ",
            host: { class: 'kdx-ag-checkbox-radio' }
        }),
        __metadata("design:paramtypes", [KdIntTableEvent])
    ], KdTableCheckboxRadio);
    return KdTableCheckboxRadio;
}());
export { KdTableCheckboxRadio };
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoia2QtdGFibGUtY2hlY2tib3gtcmFkaW8uanMiLCJzb3VyY2VSb290Ijoibmc6Ly9vcGVuZW1pcy1zdHlsZWd1aWRlLWxpYi8iLCJzb3VyY2VzIjpbImtkLWNvbXBvbmVudHMva2QtYW5ndWxhci10YWJsZS90YWJsZS1jb21wb25lbnRzL2tkLXRhYmxlLWNoZWNrYm94LXJhZGlvLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7QUFBQSxPQUFPLEVBQUUsU0FBUyxFQUFhLE1BQU0sZUFBZSxDQUFDO0FBV3JELE9BQU8sRUFBRSxlQUFlLEVBQUUsTUFBTSwyQkFBMkIsQ0FBQztBQWdDNUQ7SUFZSSw4QkFDWSxnQkFBaUM7UUFBakMscUJBQWdCLEdBQWhCLGdCQUFnQixDQUFpQjtRQVp0QyxlQUFVLEdBQVcsVUFBVSxDQUFDO1FBQ2hDLGNBQVMsR0FBWSxLQUFLLENBQUM7UUFFM0IsZUFBVSxHQUFZLEtBQUssQ0FBQztRQUkzQixtQkFBYyxHQUEyQixFQUFFLENBQUM7UUFDNUMsaUJBQVksR0FBVyxlQUFlLENBQUM7UUFDdkMscUJBQWdCLEdBQWtDLEVBQUUsQ0FBQztJQUl6RCxDQUFDO0lBRUwsaUZBQWlGO0lBQ2pGLHFDQUFNLEdBQU4sVUFBTyxPQUFZO1FBQ2YsbUVBQW1FO1FBQ25FLElBQUksQ0FBQyxPQUFPLEdBQUcsT0FBTyxDQUFDO1FBQ3ZCLElBQUksQ0FBQyxVQUFVLEdBQUcsSUFBSSxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUM7UUFDbkMsSUFBSSxDQUFDLFlBQVksR0FBRyxJQUFJLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUM7UUFDL0MsSUFBSSxDQUFDLFNBQVMsR0FBRyxPQUFPLElBQUksQ0FBQyxPQUFPLENBQUMsUUFBUSxLQUFLLFdBQVcsQ0FBQztRQUU5RCxJQUFJLENBQUMsb0JBQW9CLEVBQUUsQ0FBQztRQUM1QixJQUFJLENBQUMsZ0JBQWdCLEVBQUUsQ0FBQztRQUV4QixJQUFJLENBQUMsSUFBSSxDQUFDLFNBQVMsRUFBRTtZQUNqQixJQUFJLENBQUMsVUFBVSxHQUFHLElBQUksQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDO1lBQ3BDLElBQUksQ0FBQyx1QkFBdUIsRUFBRSxDQUFDO1NBQ2xDO1FBRUQsSUFBSSxDQUFDLHdCQUF3QixFQUFFLENBQUM7SUFDcEMsQ0FBQztJQUVELHNDQUFPLEdBQVAsVUFBUSxPQUFZO1FBQ2hCLE9BQU8sS0FBSyxDQUFDO0lBQ2pCLENBQUM7SUFFRCwwQ0FBVyxHQUFYO1FBQ0ksS0FBSyxJQUFJLElBQUksSUFBSSxJQUFJLENBQUMsZ0JBQWdCLEVBQUU7WUFDcEMsSUFBSSxJQUFJLENBQUMsZ0JBQWdCLENBQUMsY0FBYyxDQUFDLElBQUksQ0FBQyxFQUFFO2dCQUM1QyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsSUFBSSxDQUFDLENBQUMsV0FBVyxFQUFFLENBQUM7YUFDN0M7U0FDSjtJQUNMLENBQUM7SUFFTSw4Q0FBZSxHQUF0QixVQUF1QixNQUFXO1FBQzlCLDBEQUEwRDtRQUMxRCxJQUFJLFdBQVcsR0FBdUMsS0FBSyxDQUFDLE1BQU0sQ0FBQztRQUNuRSxJQUFJLENBQUMsZ0JBQWdCLENBQUMsV0FBVyxDQUFDLE9BQU8sQ0FBQyxDQUFDO0lBQy9DLENBQUM7SUFFRCxpRkFBaUY7SUFDakYsK0ZBQStGO0lBQy9GLG9CQUFvQjtJQUNwQiwrRkFBK0Y7SUFDdkYsK0NBQWdCLEdBQXhCLFVBQXlCLFVBQW1CO1FBQ3hDLElBQUksSUFBSSxDQUFDLFNBQVMsRUFBRTtZQUNoQixJQUFJLENBQUMsVUFBVSxHQUFHLFVBQVUsQ0FBQztZQUM3QixJQUFJLENBQUMsa0JBQWtCLEVBQUUsQ0FBQztTQUU3QjthQUNJO1lBQ0QsSUFBSSxJQUFJLENBQUMsVUFBVSxLQUFLLFVBQVUsRUFBRTtnQkFDaEMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxjQUFjLENBQUMsVUFBVSxDQUFDLENBQUM7Z0JBQzNDLElBQUksQ0FBQyxtQkFBbUIsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLEVBQUUsRUFBRSxVQUFVLENBQUMsQ0FBQzthQUM1RDtpQkFDSTtnQkFDRCxJQUFJLENBQUMsVUFBVSxDQUFDLFdBQVcsRUFBRSxDQUFDO2dCQUM5QixJQUFJLENBQUMsVUFBVSxDQUFDLGNBQWMsQ0FBQyxJQUFJLENBQUMsQ0FBQztnQkFDckMsSUFBSSxDQUFDLG1CQUFtQixDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsRUFBRSxFQUFFLElBQUksRUFBRSxJQUFJLENBQUMsQ0FBQzthQUM1RDtTQUNKO1FBRUQsSUFBSSxDQUFDLHFCQUFxQixFQUFFLENBQUM7SUFDakMsQ0FBQztJQUVELCtGQUErRjtJQUMvRixxQ0FBcUM7SUFDckMsK0ZBQStGO0lBQ3ZGLGlEQUFrQixHQUExQjtRQUFBLGlCQVNDO1FBUkcsSUFBSSxZQUFZLEdBQUcsSUFBSSxDQUFDLG1CQUFtQixFQUFFLENBQUM7UUFFOUMsSUFBSSxZQUFZLEtBQUssSUFBSSxFQUFFO1lBQ3ZCLFlBQVksQ0FBQyxXQUFXLENBQUMsVUFBQyxRQUFpQjtnQkFDdkMsUUFBUSxDQUFDLGNBQWMsQ0FBQyxLQUFJLENBQUMsVUFBVSxDQUFDLENBQUM7Z0JBQ3pDLEtBQUksQ0FBQyxtQkFBbUIsQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLEVBQUUsRUFBRSxLQUFJLENBQUMsVUFBVSxDQUFDLENBQUM7WUFDaEUsQ0FBQyxDQUFDLENBQUM7U0FDTjtJQUNMLENBQUM7SUFFTyw4Q0FBZSxHQUF2QjtRQUNJLElBQUksWUFBWSxHQUFHLElBQUksQ0FBQyxtQkFBbUIsRUFBRSxDQUFDO1FBQzlDLElBQUksU0FBUyxHQUFZLElBQUksQ0FBQztRQUM5QixJQUFJLFlBQVksS0FBSyxJQUFJLEVBQUU7WUFDdkIsSUFBSSxZQUFZLENBQUMsV0FBVyxFQUFFLEtBQUssQ0FBQyxFQUFFO2dCQUNsQyxTQUFTLEdBQUcsS0FBSyxDQUFDO2FBQ3JCO2lCQUNJO2dCQUNELFlBQVksQ0FBQyxXQUFXLENBQUMsVUFBQyxRQUFpQjtvQkFDdkMsSUFBSSxTQUFTLElBQUksQ0FBQyxRQUFRLENBQUMsVUFBVSxFQUFFLEVBQUU7d0JBQ3JDLFNBQVMsR0FBRyxLQUFLLENBQUM7cUJBQ3JCO2dCQUNMLENBQUMsQ0FBQyxDQUFDO2FBQ047U0FDSjtRQUNELElBQUksQ0FBQyxVQUFVLEdBQUcsU0FBUyxDQUFDO0lBQ2hDLENBQUM7SUFDRCwrRkFBK0Y7SUFDL0YsMkJBQTJCO0lBQzNCLCtGQUErRjtJQUN2RixzREFBdUIsR0FBL0I7UUFDSSxJQUFJLFVBQVUsR0FBWSxLQUFLLENBQUM7UUFFaEMsSUFBSSxPQUFPLElBQUksQ0FBQyxjQUFjLEtBQUssV0FBVyxFQUFFO1lBQzVDLEtBQUssSUFBSSxDQUFDLEdBQVcsQ0FBQyxFQUFFLENBQUMsR0FBRyxJQUFJLENBQUMsY0FBYyxDQUFDLE1BQU0sRUFBRSxFQUFFLENBQUMsRUFBRTtnQkFDekQsSUFBSSxJQUFJLENBQUMsY0FBYyxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsRUFBRSxLQUFLLElBQUksQ0FBQyxVQUFVLENBQUMsRUFBRSxFQUFFO29CQUMxRCxVQUFVLEdBQUcsSUFBSSxDQUFDO29CQUNsQixNQUFNO2lCQUNUO2FBQ0o7U0FDSjtRQUVELElBQUksQ0FBQyxVQUFVLENBQUMsY0FBYyxDQUFDLFVBQVUsQ0FBQyxDQUFDO0lBQy9DLENBQUM7SUFFTyxtREFBb0IsR0FBNUI7UUFDSSxJQUFJLE9BQU8sSUFBSSxDQUFDLE9BQU8sQ0FBQyxNQUFNLEtBQUssV0FBVztZQUMxQyxPQUFPLElBQUksQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLE9BQU8sS0FBSyxXQUFXLEVBQUU7WUFDaEQsSUFBSSxDQUFDLGNBQWMsR0FBRyxJQUFJLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxPQUFPLENBQUM7U0FDekQ7SUFDTCxDQUFDO0lBRU8sa0RBQW1CLEdBQTNCLFVBQTRCLEdBQW9CLEVBQUUsV0FBb0IsRUFBRSxlQUF5QjtRQUM3RixJQUFJLGVBQWUsRUFBRTtZQUNqQixJQUFJLENBQUMsY0FBYyxDQUFDLE1BQU0sQ0FBQyxDQUFDLEVBQUUsSUFBSSxDQUFDLGNBQWMsQ0FBQyxNQUFNLENBQUMsQ0FBQztTQUM3RDtRQUVELElBQUksV0FBVyxJQUFJLElBQUksQ0FBQyxjQUFjLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUMsRUFBRTtZQUNyRCxJQUFJLENBQUMsY0FBYyxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQztTQUNqQzthQUNJLElBQUksQ0FBQyxXQUFXLElBQUksSUFBSSxDQUFDLGNBQWMsQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxDQUFDLEVBQUU7WUFDNUQsSUFBSSxDQUFDLGNBQWMsQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLGNBQWMsQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUM7U0FDbkU7UUFDRCxJQUFJLENBQUMsaUJBQWlCLEVBQUUsQ0FBQztJQUM3QixDQUFDO0lBRUQsK0ZBQStGO0lBQy9GLHNDQUFzQztJQUN0QywrRkFBK0Y7SUFDdkYsb0RBQXFCLEdBQTdCO1FBQ0ksSUFBSSxDQUFDLGdCQUFnQixDQUFDLGdCQUFnQixDQUFDLElBQUksQ0FBQyxZQUFZLEVBQUUsSUFBSSxDQUFDLFVBQVUsQ0FBQyxDQUFDO0lBQy9FLENBQUM7SUFFTyx1REFBd0IsR0FBaEM7UUFBQSxpQkFVQztRQVRHLElBQUksSUFBSSxDQUFDLFNBQVMsRUFBRTtZQUNoQixJQUFJLENBQUMsZ0JBQWdCLENBQUMsaUJBQWlCLEdBQUcsSUFBSSxDQUFDLGdCQUFnQixDQUFDLGNBQWMsQ0FBQyxJQUFJLENBQUMsWUFBWSxDQUFDLENBQUMsU0FBUyxDQUFDO2dCQUN4RyxLQUFJLENBQUMsZUFBZSxFQUFFLENBQUM7WUFDM0IsQ0FBQyxDQUFDLENBQUM7WUFFSCxJQUFJLENBQUMsZ0JBQWdCLENBQUMsaUJBQWlCLEdBQUcsSUFBSSxDQUFDLGdCQUFnQixDQUFDLGtCQUFrQixDQUFDLElBQUksQ0FBQyxZQUFZLENBQUMsQ0FBQyxTQUFTLENBQUM7Z0JBQzVHLEtBQUksQ0FBQyxlQUFlLEVBQUUsQ0FBQztZQUMzQixDQUFDLENBQUMsQ0FBQztTQUNOO0lBQ0wsQ0FBQztJQUVELCtGQUErRjtJQUMvRixrQkFBa0I7SUFDbEIsK0ZBQStGO0lBQ3ZGLCtDQUFnQixHQUF4QjtRQUNJLElBQUksT0FBTyxJQUFJLENBQUMsT0FBTyxDQUFDLE1BQU0sS0FBSyxXQUFXLEVBQUU7WUFDNUMsSUFBSSxDQUFDLFVBQVUsR0FBRyxJQUFJLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxTQUFTLENBQUM7U0FDbkQ7YUFDSTtZQUNELElBQUksQ0FBQyxVQUFVLEdBQUcsVUFBVSxDQUFDO1NBQ2hDO0lBQ0wsQ0FBQztJQUVPLGtEQUFtQixHQUEzQjtRQUNJLElBQUksT0FBTyxJQUFJLENBQUMsVUFBVSxLQUFLLFdBQVcsRUFBRTtZQUN4QyxPQUFPLElBQUksQ0FBQyxVQUFVLENBQUMsUUFBUSxFQUFFLENBQUM7U0FDckM7UUFDRCxPQUFPLElBQUksQ0FBQztJQUNoQixDQUFDO0lBRU8sZ0RBQWlCLEdBQXpCO1FBQ0ksSUFBSSxDQUFDLGNBQWMsQ0FBQyxJQUFJLENBQUMsVUFBQyxFQUFPLEVBQUUsRUFBTztZQUN0QyxJQUFJLEVBQUUsR0FBRyxFQUFFO2dCQUFFLE9BQU8sQ0FBQyxDQUFDO2lCQUNqQixJQUFJLEVBQUUsR0FBRyxFQUFFO2dCQUFFLE9BQU8sQ0FBQyxDQUFDLENBQUM7WUFDNUIsT0FBTyxDQUFDLENBQUM7UUFDYixDQUFDLENBQUMsQ0FBQztJQUNQLENBQUM7O2dCQW5MNkIsZUFBZTs7SUFicEMsb0JBQW9CO1FBdEJoQyxTQUFTLENBQUM7WUFDUCxRQUFRLEVBQUUsbUJBQW1CO1lBQzdCLFFBQVEsRUFBRSwybUJBZ0JUO1lBQ0QsSUFBSSxFQUFFLEVBQUUsS0FBSyxFQUFHLHVCQUF1QixFQUFFO1NBQzVDLENBQUM7eUNBZWdDLGVBQWU7T0FicEMsb0JBQW9CLENBaU1oQztJQUFELDJCQUFDO0NBQUEsQUFqTUQsSUFpTUM7U0FqTVksb0JBQW9CIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgQ29tcG9uZW50LCBPbkRlc3Ryb3kgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcclxuaW1wb3J0IHsgU3Vic2NyaXB0aW9uIH0gZnJvbSAncnhqcyc7XHJcbmltcG9ydCB7IEFnUmVuZGVyZXJDb21wb25lbnQgfSBmcm9tICdhZy1ncmlkLWFuZ3VsYXInO1xyXG5pbXBvcnQge1xyXG4gICAgUm93Tm9kZSxcclxuICAgIEdyaWRBcGksXHJcbiAgICAvLyBJRW50ZXJwcmlzZVJvd01vZGVsLFxyXG4gICAgSUNlbGxSZW5kZXJlclBhcmFtc1xyXG59IGZyb20gJ2FnLWdyaWQtY29tbXVuaXR5JztcclxuXHJcblxyXG5pbXBvcnQgeyBLZEludFRhYmxlRXZlbnQgfSBmcm9tICcuLi9rZC1hbmd1bGFyLXRhYmxlLWV2ZW50JztcclxuXHJcbmludGVyZmFjZSBJS2RUYWJsZVNlbGVjdGlvblBhcmFtcyBleHRlbmRzIElDZWxsUmVuZGVyZXJQYXJhbXMge1xyXG4gICAgcGFyYW1zOiB7XHJcbiAgICAgICAgaW5wdXRUeXBlPzogJ3JhZGlvJyB8ICdjaGVja2JveCcsXHJcbiAgICAgICAgZGVmYXVsdD86IEFycmF5PGFueT4sXHJcbiAgICAgICAgZ3JpZElkPzogc3RyaW5nXHJcbiAgICB9O1xyXG59XHJcblxyXG5AQ29tcG9uZW50KHtcclxuICAgIHNlbGVjdG9yOiAnYWctY2hlY2tib3gtcmFkaW8nLFxyXG4gICAgdGVtcGxhdGU6IGBcclxuICAgICAgICA8ZGl2IGNsYXNzPVwic2VsZWN0aW9uLXdyYXBwZXJcIj5cclxuICAgICAgICAgICAgPGlucHV0ICpuZ0lmPVwiX2lzSGVhZGVyXCIgY2xhc3M9XCJjaGVja2JveC1yYWRpby1pbnB1dFwiXHJcbiAgICAgICAgICAgICAgICB0eXBlPVwiY2hlY2tib3hcIlxyXG4gICAgICAgICAgICAgICAgW2NoZWNrZWRdPVwiX3NlbGVjdEFsbFwiXHJcbiAgICAgICAgICAgICAgICAoY2hhbmdlKT1cIl91cGRhdGVDaGVja2JveCgkZXZlbnQpXCJcclxuICAgICAgICAgICAgLz5cclxuXHJcbiAgICAgICAgICAgIDxpbnB1dCAqbmdJZj1cIiFfaXNIZWFkZXJcIiBjbGFzcz1cImNoZWNrYm94LXJhZGlvLWlucHV0XCJcclxuICAgICAgICAgICAgICAgIFt0eXBlXT1cIl9pbnB1dFR5cGVcIlxyXG4gICAgICAgICAgICAgICAgW2F0dHIubmFtZV09XCJfaW5wdXRUeXBlXCJcclxuICAgICAgICAgICAgICAgIFtjaGVja2VkXT1cIihfcGFyYW1Ob2RlKSA/IF9wYXJhbU5vZGUuaXNTZWxlY3RlZCgpIDogZmFsc2VcIlxyXG4gICAgICAgICAgICAgICAgKGNoYW5nZSk9XCJfdXBkYXRlQ2hlY2tib3goJGV2ZW50KVwiXHJcbiAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgIDxsYWJlbD48L2xhYmVsPlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgYCxcclxuICAgIGhvc3Q6IHsgY2xhc3MgOiAna2R4LWFnLWNoZWNrYm94LXJhZGlvJyB9XHJcbn0pXHJcblxyXG5leHBvcnQgY2xhc3MgS2RUYWJsZUNoZWNrYm94UmFkaW8gaW1wbGVtZW50cyBBZ1JlbmRlcmVyQ29tcG9uZW50LCBPbkRlc3Ryb3kge1xyXG4gICAgcHVibGljIF9pbnB1dFR5cGU6IHN0cmluZyA9ICdjaGVja2JveCc7XHJcbiAgICBwdWJsaWMgX2lzSGVhZGVyOiBib29sZWFuID0gZmFsc2U7XHJcbiAgICBwdWJsaWMgX3BhcmFtTm9kZTogUm93Tm9kZTtcclxuICAgIHB1YmxpYyBfc2VsZWN0QWxsOiBib29sZWFuID0gZmFsc2U7XHJcblxyXG4gICAgcHJpdmF0ZSBfcGFyYW1zOiBJS2RUYWJsZVNlbGVjdGlvblBhcmFtcztcclxuICAgIHByaXZhdGUgX3BhcmFtc0FwaTogR3JpZEFwaTtcclxuICAgIHByaXZhdGUgX3BhcmFtc0RlZmF1bHQ6IEFycmF5PHN0cmluZyB8IG51bWJlcj4gPSBbXTtcclxuICAgIHByaXZhdGUgX3BhcmFtR3JpZElkOiBzdHJpbmcgPSAna2QtdGFibGUtZ3JpZCc7XHJcbiAgICBwcml2YXRlIF9zdWJzY3JpcHRpb25PYmo6IHtba2V5OiBzdHJpbmddOiBTdWJzY3JpcHRpb259ID0ge307XHJcblxyXG4gICAgY29uc3RydWN0b3IoXHJcbiAgICAgICAgcHJpdmF0ZSBfa2RJbnRUYWJsZUV2ZW50OiBLZEludFRhYmxlRXZlbnRcclxuICAgICkgeyB9XHJcblxyXG4gICAgLyoqKioqKioqKioqKioqKioqKioqKiBDb21wb25lbnQgTGlmZSBjeWNsZXMgZnVuY3Rpb25zICoqKioqKioqKioqKioqKioqKioqKioqKiovXHJcbiAgICBhZ0luaXQoX3BhcmFtczogYW55KTogdm9pZCB7XHJcbiAgICAgICAgLy8gY29uc29sZS5sb2coXCItLSBHcmlkIHN0YXRlOiBDaGVja2JveC9SYWRpbyBhZ0luaXQgLS1cIiwgX3BhcmFtcyk7XHJcbiAgICAgICAgdGhpcy5fcGFyYW1zID0gX3BhcmFtcztcclxuICAgICAgICB0aGlzLl9wYXJhbXNBcGkgPSB0aGlzLl9wYXJhbXMuYXBpO1xyXG4gICAgICAgIHRoaXMuX3BhcmFtR3JpZElkID0gdGhpcy5fcGFyYW1zLnBhcmFtcy5ncmlkSWQ7XHJcbiAgICAgICAgdGhpcy5faXNIZWFkZXIgPSB0eXBlb2YgdGhpcy5fcGFyYW1zLnJvd0luZGV4ID09PSAndW5kZWZpbmVkJztcclxuXHJcbiAgICAgICAgdGhpcy5fZ2V0RGVmYXVsdFNlbGVjdGlvbigpO1xyXG4gICAgICAgIHRoaXMuX3VwZGF0ZUlucHV0VHlwZSgpO1xyXG5cclxuICAgICAgICBpZiAoIXRoaXMuX2lzSGVhZGVyKSB7XHJcbiAgICAgICAgICAgIHRoaXMuX3BhcmFtTm9kZSA9IHRoaXMuX3BhcmFtcy5ub2RlO1xyXG4gICAgICAgICAgICB0aGlzLl91cGRhdGVJbml0aWFsU2VsZWN0aW9uKCk7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICB0aGlzLl9zZXR1cFN1YnNjcmlwdGlvbkV2ZW50cygpO1xyXG4gICAgfVxyXG5cclxuICAgIHJlZnJlc2goX3BhcmFtczogYW55KTogYm9vbGVhbiB7XHJcbiAgICAgICAgcmV0dXJuIGZhbHNlO1xyXG4gICAgfVxyXG5cclxuICAgIG5nT25EZXN0cm95KCk6IHZvaWQge1xyXG4gICAgICAgIGZvciAobGV0IGl0ZW0gaW4gdGhpcy5fc3Vic2NyaXB0aW9uT2JqKSB7XHJcbiAgICAgICAgICAgIGlmICh0aGlzLl9zdWJzY3JpcHRpb25PYmouaGFzT3duUHJvcGVydHkoaXRlbSkpIHtcclxuICAgICAgICAgICAgICAgIHRoaXMuX3N1YnNjcmlwdGlvbk9ialtpdGVtXS51bnN1YnNjcmliZSgpO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIHB1YmxpYyBfdXBkYXRlQ2hlY2tib3goX2V2ZW50OiBhbnkpOiB2b2lkIHtcclxuICAgICAgICAvLyBjb25zb2xlLmxvZyhcIi0tIEdyaWQgc3RhdGU6IENoZWNrYm94L1JhZGlvIGNoZWNrZWQgLS1cIilcclxuICAgICAgICBsZXQgaW5wdXRUYXJnZXQ6IEhUTUxJbnB1dEVsZW1lbnQgPSA8SFRNTElucHV0RWxlbWVudD5ldmVudC50YXJnZXQ7XHJcbiAgICAgICAgdGhpcy5fdXBkYXRlU2VsZWN0aW9uKGlucHV0VGFyZ2V0LmNoZWNrZWQpO1xyXG4gICAgfVxyXG5cclxuICAgIC8qKioqKioqKioqKioqKioqKioqKioqKioqKioqIFByaXZhdGUgZnVuY3Rpb25zICoqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqL1xyXG4gICAgLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy9cclxuICAgIC8vLyBVcGRhdGUgZnVuY3Rpb25zXHJcbiAgICAvLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vL1xyXG4gICAgcHJpdmF0ZSBfdXBkYXRlU2VsZWN0aW9uKF9pc0NoZWNrZWQ6IGJvb2xlYW4pOiB2b2lkIHtcclxuICAgICAgICBpZiAodGhpcy5faXNIZWFkZXIpIHtcclxuICAgICAgICAgICAgdGhpcy5fc2VsZWN0QWxsID0gX2lzQ2hlY2tlZDtcclxuICAgICAgICAgICAgdGhpcy5fdXBkYXRlQWxsQ2hlY2tib3goKTtcclxuXHJcbiAgICAgICAgfVxyXG4gICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICBpZiAodGhpcy5faW5wdXRUeXBlID09PSAnY2hlY2tib3gnKSB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLl9wYXJhbU5vZGUuc2VsZWN0VGhpc05vZGUoX2lzQ2hlY2tlZCk7XHJcbiAgICAgICAgICAgICAgICB0aGlzLl91cGRhdGVEZWZhdWx0VmFsdWUodGhpcy5fcGFyYW1Ob2RlLmlkLCBfaXNDaGVja2VkKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgICAgIHRoaXMuX3BhcmFtc0FwaS5kZXNlbGVjdEFsbCgpO1xyXG4gICAgICAgICAgICAgICAgdGhpcy5fcGFyYW1Ob2RlLnNlbGVjdFRoaXNOb2RlKHRydWUpO1xyXG4gICAgICAgICAgICAgICAgdGhpcy5fdXBkYXRlRGVmYXVsdFZhbHVlKHRoaXMuX3BhcmFtTm9kZS5pZCwgdHJ1ZSwgdHJ1ZSk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIHRoaXMuX2VtaXRTZWxlY3Rpb25DaGFuZ2VkKCk7XHJcbiAgICB9XHJcblxyXG4gICAgLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy9cclxuICAgIC8vLyBDaGVja2JveCAvIENoZWNrYm94IGFsbCBmdW5jdGlvbnNcclxuICAgIC8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vXHJcbiAgICBwcml2YXRlIF91cGRhdGVBbGxDaGVja2JveCgpOiB2b2lkIHtcclxuICAgICAgICBsZXQgY3VycmVudE1vZGVsID0gdGhpcy5fZ2V0Q3VycmVudFJvd01vZGVsKCk7XHJcblxyXG4gICAgICAgIGlmIChjdXJyZW50TW9kZWwgIT09IG51bGwpIHtcclxuICAgICAgICAgICAgY3VycmVudE1vZGVsLmZvckVhY2hOb2RlKChfcm93Tm9kZTogUm93Tm9kZSk6IHZvaWQgPT4ge1xyXG4gICAgICAgICAgICAgICAgX3Jvd05vZGUuc2VsZWN0VGhpc05vZGUodGhpcy5fc2VsZWN0QWxsKTtcclxuICAgICAgICAgICAgICAgIHRoaXMuX3VwZGF0ZURlZmF1bHRWYWx1ZShfcm93Tm9kZS5kYXRhLmlkLCB0aGlzLl9zZWxlY3RBbGwpO1xyXG4gICAgICAgICAgICB9KTtcclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfY2hlY2tTZWxlY3RBbGwoKTogdm9pZCB7XHJcbiAgICAgICAgbGV0IGN1cnJlbnRNb2RlbCA9IHRoaXMuX2dldEN1cnJlbnRSb3dNb2RlbCgpO1xyXG4gICAgICAgIGxldCBzZWxlY3RBbGw6IGJvb2xlYW4gPSB0cnVlO1xyXG4gICAgICAgIGlmIChjdXJyZW50TW9kZWwgIT09IG51bGwpIHtcclxuICAgICAgICAgICAgaWYgKGN1cnJlbnRNb2RlbC5nZXRSb3dDb3VudCgpID09PSAwKSB7XHJcbiAgICAgICAgICAgICAgICBzZWxlY3RBbGwgPSBmYWxzZTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgICAgIGN1cnJlbnRNb2RlbC5mb3JFYWNoTm9kZSgoX3Jvd05vZGU6IFJvd05vZGUpOiB2b2lkID0+IHtcclxuICAgICAgICAgICAgICAgICAgICBpZiAoc2VsZWN0QWxsICYmICFfcm93Tm9kZS5pc1NlbGVjdGVkKCkpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgc2VsZWN0QWxsID0gZmFsc2U7XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICAgICAgdGhpcy5fc2VsZWN0QWxsID0gc2VsZWN0QWxsO1xyXG4gICAgfVxyXG4gICAgLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy9cclxuICAgIC8vLyBEZWZhdWx0IHZhbHVlIGZ1bmN0aW9uc1xyXG4gICAgLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy9cclxuICAgIHByaXZhdGUgX3VwZGF0ZUluaXRpYWxTZWxlY3Rpb24oKTogdm9pZCB7XHJcbiAgICAgICAgbGV0IGlzU2VsZWN0ZWQ6IGJvb2xlYW4gPSBmYWxzZTtcclxuXHJcbiAgICAgICAgaWYgKHR5cGVvZiB0aGlzLl9wYXJhbXNEZWZhdWx0ICE9PSAndW5kZWZpbmVkJykge1xyXG4gICAgICAgICAgICBmb3IgKGxldCBpOiBudW1iZXIgPSAwOyBpIDwgdGhpcy5fcGFyYW1zRGVmYXVsdC5sZW5ndGg7ICsraSkge1xyXG4gICAgICAgICAgICAgICAgaWYgKHRoaXMuX3BhcmFtc0RlZmF1bHRbaV0udG9TdHJpbmcoKSA9PT0gdGhpcy5fcGFyYW1Ob2RlLmlkKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgaXNTZWxlY3RlZCA9IHRydWU7XHJcbiAgICAgICAgICAgICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIHRoaXMuX3BhcmFtTm9kZS5zZWxlY3RUaGlzTm9kZShpc1NlbGVjdGVkKTtcclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF9nZXREZWZhdWx0U2VsZWN0aW9uKCk6IHZvaWQge1xyXG4gICAgICAgIGlmICh0eXBlb2YgdGhpcy5fcGFyYW1zLnBhcmFtcyAhPT0gJ3VuZGVmaW5lZCcgJiZcclxuICAgICAgICAgICAgdHlwZW9mIHRoaXMuX3BhcmFtcy5wYXJhbXMuZGVmYXVsdCAhPT0gJ3VuZGVmaW5lZCcpIHtcclxuICAgICAgICAgICAgICAgIHRoaXMuX3BhcmFtc0RlZmF1bHQgPSB0aGlzLl9wYXJhbXMucGFyYW1zLmRlZmF1bHQ7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX3VwZGF0ZURlZmF1bHRWYWx1ZShfaWQ6IG51bWJlciB8IHN0cmluZywgX2lzU2VsZWN0ZWQ6IGJvb2xlYW4sIF90b0VtcHR5RGVmYXVsdD86IGJvb2xlYW4pOiB2b2lkIHtcclxuICAgICAgICBpZiAoX3RvRW1wdHlEZWZhdWx0KSB7XHJcbiAgICAgICAgICAgIHRoaXMuX3BhcmFtc0RlZmF1bHQuc3BsaWNlKDAsIHRoaXMuX3BhcmFtc0RlZmF1bHQubGVuZ3RoKTtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIGlmIChfaXNTZWxlY3RlZCAmJiB0aGlzLl9wYXJhbXNEZWZhdWx0LmluZGV4T2YoX2lkKSA8IDApIHtcclxuICAgICAgICAgICAgdGhpcy5fcGFyYW1zRGVmYXVsdC5wdXNoKF9pZCk7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGVsc2UgaWYgKCFfaXNTZWxlY3RlZCAmJiB0aGlzLl9wYXJhbXNEZWZhdWx0LmluZGV4T2YoX2lkKSA+IC0xKSB7XHJcbiAgICAgICAgICAgIHRoaXMuX3BhcmFtc0RlZmF1bHQuc3BsaWNlKHRoaXMuX3BhcmFtc0RlZmF1bHQuaW5kZXhPZihfaWQpLCAxKTtcclxuICAgICAgICB9XHJcbiAgICAgICAgdGhpcy5fc29ydERlZmF1bHRWYWx1ZSgpO1xyXG4gICAgfVxyXG5cclxuICAgIC8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vXHJcbiAgICAvLy8gRXZlbnRzIC0gU3Vic2NyaWJlciAvIE9uIGZ1bmN0aW9uc1xyXG4gICAgLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy9cclxuICAgIHByaXZhdGUgX2VtaXRTZWxlY3Rpb25DaGFuZ2VkKCk6IHZvaWQge1xyXG4gICAgICAgIHRoaXMuX2tkSW50VGFibGVFdmVudC5zZWxlY3Rpb25DaGFuZ2VkKHRoaXMuX3BhcmFtR3JpZElkLCB0aGlzLl9wYXJhbU5vZGUpO1xyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX3NldHVwU3Vic2NyaXB0aW9uRXZlbnRzKCk6IHZvaWQge1xyXG4gICAgICAgIGlmICh0aGlzLl9pc0hlYWRlcikge1xyXG4gICAgICAgICAgICB0aGlzLl9zdWJzY3JpcHRpb25PYmouaGVhZGVyQ2hlY2tib3hTdWIgPSB0aGlzLl9rZEludFRhYmxlRXZlbnQub25Nb2RlbENoYW5nZWQodGhpcy5fcGFyYW1HcmlkSWQpLnN1YnNjcmliZSgoKTogdm9pZCA9PiB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLl9jaGVja1NlbGVjdEFsbCgpO1xyXG4gICAgICAgICAgICB9KTtcclxuXHJcbiAgICAgICAgICAgIHRoaXMuX3N1YnNjcmlwdGlvbk9iai5zZWxlY3RlZENoYW5nZVN1YiA9IHRoaXMuX2tkSW50VGFibGVFdmVudC5vblNlbGVjdGlvbkNoYW5nZWQodGhpcy5fcGFyYW1HcmlkSWQpLnN1YnNjcmliZSgoKTogdm9pZCA9PiB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLl9jaGVja1NlbGVjdEFsbCgpO1xyXG4gICAgICAgICAgICB9KTtcclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy9cclxuICAgIC8vLyBNaXNjIGZ1bmN0aW9uc1xyXG4gICAgLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy9cclxuICAgIHByaXZhdGUgX3VwZGF0ZUlucHV0VHlwZSgpOiB2b2lkIHtcclxuICAgICAgICBpZiAodHlwZW9mIHRoaXMuX3BhcmFtcy5wYXJhbXMgIT09ICd1bmRlZmluZWQnKSB7XHJcbiAgICAgICAgICAgIHRoaXMuX2lucHV0VHlwZSA9IHRoaXMuX3BhcmFtcy5wYXJhbXMuaW5wdXRUeXBlO1xyXG4gICAgICAgIH1cclxuICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgdGhpcy5faW5wdXRUeXBlID0gJ2NoZWNrYm94JztcclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfZ2V0Q3VycmVudFJvd01vZGVsKCkge1xyXG4gICAgICAgIGlmICh0eXBlb2YgdGhpcy5fcGFyYW1zQXBpICE9PSAndW5kZWZpbmVkJykge1xyXG4gICAgICAgICAgICByZXR1cm4gdGhpcy5fcGFyYW1zQXBpLmdldE1vZGVsKCk7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIHJldHVybiBudWxsO1xyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX3NvcnREZWZhdWx0VmFsdWUoKTogdm9pZCB7XHJcbiAgICAgICAgdGhpcy5fcGFyYW1zRGVmYXVsdC5zb3J0KChfYTogYW55LCBfYjogYW55KTogbnVtYmVyID0+IHtcclxuICAgICAgICAgICAgaWYgKF9hID4gX2IpIHJldHVybiAxO1xyXG4gICAgICAgICAgICBlbHNlIGlmIChfYSA8IF9iKSByZXR1cm4gLTE7XHJcbiAgICAgICAgICAgIHJldHVybiAwO1xyXG4gICAgICAgIH0pO1xyXG4gICAgfVxyXG59XHJcbiJdfQ==