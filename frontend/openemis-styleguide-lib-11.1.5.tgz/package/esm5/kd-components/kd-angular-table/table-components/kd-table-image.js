import { __decorate } from "tslib";
import { Component } from '@angular/core';
var KdTableImage = /** @class */ (function () {
    function KdTableImage() {
        this.config = {};
        this.value = {};
    }
    KdTableImage.prototype.agInit = function (_params) {
        // console.log('_params', _params);
        this._params = _params;
        this.config = this._params.params.imageConfig;
        this.value = this._params.value;
    };
    KdTableImage.prototype.refresh = function () {
        return false;
    };
    KdTableImage = __decorate([
        Component({
            selector: 'kd-table-image',
            template: "\n        <kd-placeholder [config]='config' [value]='value'></kd-placeholder>\n    "
        })
    ], KdTableImage);
    return KdTableImage;
}());
export { KdTableImage };
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoia2QtdGFibGUtaW1hZ2UuanMiLCJzb3VyY2VSb290Ijoibmc6Ly9vcGVuZW1pcy1zdHlsZWd1aWRlLWxpYi8iLCJzb3VyY2VzIjpbImtkLWNvbXBvbmVudHMva2QtYW5ndWxhci10YWJsZS90YWJsZS1jb21wb25lbnRzL2tkLXRhYmxlLWltYWdlLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7QUFBQSxPQUFPLEVBQUUsU0FBUyxFQUFFLE1BQU0sZUFBZSxDQUFDO0FBdUIxQztJQUFBO1FBQ1csV0FBTSxHQUFRLEVBQUUsQ0FBQztRQUNqQixVQUFLLEdBQVEsRUFBRSxDQUFDO0lBYTNCLENBQUM7SUFWVSw2QkFBTSxHQUFiLFVBQWMsT0FBNEI7UUFDdEMsbUNBQW1DO1FBQ25DLElBQUksQ0FBQyxPQUFPLEdBQUcsT0FBTyxDQUFDO1FBQ3ZCLElBQUksQ0FBQyxNQUFNLEdBQUcsSUFBSSxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsV0FBVyxDQUFDO1FBQzlDLElBQUksQ0FBQyxLQUFLLEdBQUcsSUFBSSxDQUFDLE9BQU8sQ0FBQyxLQUFLLENBQUM7SUFDcEMsQ0FBQztJQUVNLDhCQUFPLEdBQWQ7UUFDSSxPQUFPLEtBQUssQ0FBQztJQUNqQixDQUFDO0lBZFEsWUFBWTtRQVB4QixTQUFTLENBQUM7WUFDUCxRQUFRLEVBQUUsZ0JBQWdCO1lBQzFCLFFBQVEsRUFBRSxxRkFFVDtTQUNKLENBQUM7T0FFVyxZQUFZLENBZXhCO0lBQUQsbUJBQUM7Q0FBQSxBQWZELElBZUM7U0FmWSxZQUFZIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgQ29tcG9uZW50IH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XHJcbmltcG9ydCB7IElDZWxsUmVuZGVyZXJQYXJhbXMgfSBmcm9tICdhZy1ncmlkLWNvbW11bml0eSc7XHJcbmltcG9ydCB7IElDZWxsUmVuZGVyZXJBbmd1bGFyQ29tcCB9IGZyb20gJ2FnLWdyaWQtYW5ndWxhcic7XHJcblxyXG5leHBvcnQgaW50ZXJmYWNlIElLZFRhYmxlSW1hZ2VQYXJhbXMgZXh0ZW5kcyBJQ2VsbFJlbmRlcmVyUGFyYW1zIHtcclxuICAgIHBhcmFtcz86IHtcclxuICAgICAgICBpbWFnZUNvbmZpZz86IHtcclxuICAgICAgICAgICAgYm9yZGVyVHlwZT86IHN0cmluZyxcclxuICAgICAgICAgICAgaGVpZ2h0PzogbnVtYmVyLFxyXG4gICAgICAgICAgICB3aWR0aD86IG51bWJlcixcclxuICAgICAgICAgICAgaXNFeHBlbmRhYmxlPzogYm9vbGVhbixcclxuICAgICAgICAgICAgaWNvbj86IHN0cmluZ1xyXG4gICAgICAgIH07XHJcbiAgICB9O1xyXG59XHJcblxyXG5AQ29tcG9uZW50KHtcclxuICAgIHNlbGVjdG9yOiAna2QtdGFibGUtaW1hZ2UnLFxyXG4gICAgdGVtcGxhdGU6IGBcclxuICAgICAgICA8a2QtcGxhY2Vob2xkZXIgW2NvbmZpZ109J2NvbmZpZycgW3ZhbHVlXT0ndmFsdWUnPjwva2QtcGxhY2Vob2xkZXI+XHJcbiAgICBgXHJcbn0pXHJcblxyXG5leHBvcnQgY2xhc3MgS2RUYWJsZUltYWdlIGltcGxlbWVudHMgSUNlbGxSZW5kZXJlckFuZ3VsYXJDb21wIHtcclxuICAgIHB1YmxpYyBjb25maWc6IGFueSA9IHt9O1xyXG4gICAgcHVibGljIHZhbHVlOiBhbnkgPSB7fTtcclxuICAgIHByaXZhdGUgX3BhcmFtczogSUtkVGFibGVJbWFnZVBhcmFtcztcclxuXHJcbiAgICBwdWJsaWMgYWdJbml0KF9wYXJhbXM6IElLZFRhYmxlSW1hZ2VQYXJhbXMpOiB2b2lkIHtcclxuICAgICAgICAvLyBjb25zb2xlLmxvZygnX3BhcmFtcycsIF9wYXJhbXMpO1xyXG4gICAgICAgIHRoaXMuX3BhcmFtcyA9IF9wYXJhbXM7XHJcbiAgICAgICAgdGhpcy5jb25maWcgPSB0aGlzLl9wYXJhbXMucGFyYW1zLmltYWdlQ29uZmlnO1xyXG4gICAgICAgIHRoaXMudmFsdWUgPSB0aGlzLl9wYXJhbXMudmFsdWU7XHJcbiAgICB9XHJcblxyXG4gICAgcHVibGljIHJlZnJlc2goKTogYm9vbGVhbiB7XHJcbiAgICAgICAgcmV0dXJuIGZhbHNlO1xyXG4gICAgfVxyXG59XHJcbiJdfQ==