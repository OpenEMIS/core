import { __decorate, __metadata } from "tslib";
import { Component, OnDestroy, Renderer2, ViewChild } from '@angular/core';
import { Menu } from 'primeng/menu';
import { KdIntTableEvent } from '../kd-angular-table-event';
import { KdDataSvc } from '../../kd-common/index';
var KdTableAction = /** @class */ (function () {
    function KdTableAction(_renderer, _kdIntEvent) {
        this._renderer = _renderer;
        this._kdIntEvent = _kdIntEvent;
        this._dataSvc = new KdDataSvc();
    }
    KdTableAction.prototype.agInit = function (params) {
        this._params = params;
        this._actionList = this._updateAction(this._getActionList());
    };
    KdTableAction.prototype.refresh = function () {
        return false;
    };
    KdTableAction.prototype.ngOnDestroy = function () {
        this._destroyListener();
        // this._removeMenuFromDOM();
    };
    KdTableAction.prototype.toggleMenu = function (_e) {
        // _e.stopPropagation();
        this.dropdownMenu.toggle(_e);
        this._setListener();
    };
    KdTableAction.prototype._getNewArray = function (items) {
        var newArray = [];
        for (var i = 0; i < items.length; i++) {
            var item = Object.assign({}, items[i]);
            newArray.push(item);
        }
        return newArray;
    };
    KdTableAction.prototype._updateAction = function (_actionList) {
        var _this = this;
        var updatedArray = [];
        for (var i = 0; i < _actionList.length; i++) {
            var item = _actionList[i];
            item.label = item.name;
            if (typeof item.path !== 'undefined' && item.path !== null) {
                item.routerLink = [this._dataSvc.getPlaceholder(this._params.data, item.path)];
            }
            else if (typeof item.callback !== 'undefined' && item.callback != null) {
                item.params = this._params;
                item.command = function (_event) {
                    var tableApi = {
                        deleteThisRow: function () {
                            if (_this._params.api.getModel()) {
                                var removeNode = [_this._params.node];
                                _this._params.api.updateRowData({ remove: removeNode });
                                _this._kdIntEvent.updateEmitRowNodes(_this._params.gridId, 'delete', _this._params.node.data);
                            }
                            else {
                                console.error('KdTable action error: DeleteThisRow function only for normal loadType.');
                            }
                        }
                    };
                    _event.item.callback(_this._params.node, tableApi);
                };
            }
            if (typeof item.custom === 'undefined' || !item.custom) {
                item = this._checkCustomButton(item);
            }
            updatedArray.push(item);
        }
        return updatedArray;
    };
    KdTableAction.prototype._checkCustomButton = function (item) {
        var newItem = Object.assign({}, item);
        switch (newItem.type.toLowerCase()) {
            case 'edit':
                newItem.label = 'Edit';
                newItem.icon = 'fa fa-pencil';
                break;
            case 'delete':
                newItem.label = 'Delete';
                newItem.icon = 'fa fa-trash';
                break;
            case 'view':
                newItem.label = 'View';
                newItem.icon = 'fa fa-eye';
                break;
            default:
                console.error('No such custom button found for ' + newItem.type);
                break;
        }
        return newItem;
    };
    KdTableAction.prototype._setListener = function () {
        var _this = this;
        this._firefoxMouseEvent = this._renderer.listen('document', 'DOMMouseScroll', function (ffMouseEvent) {
            _this._hideMenu();
        });
        this._touchmoveEvent = this._renderer.listen('document', 'touchmove', function (touchEvent) {
            _this._hideMenu();
        });
        this._windowResizeEvent = this._renderer.listen('window', 'resize', function (event) {
            _this._hideMenu();
        });
        this._windowMouseScrollEvent = this._renderer.listen('document', 'mousewheel', function (event) {
            _this._hideMenu();
        });
    };
    KdTableAction.prototype._hideMenu = function () {
        this._destroyListener();
        this.dropdownMenu.hide();
    };
    KdTableAction.prototype._destroyListener = function () {
        if (this._firefoxMouseEvent instanceof Function)
            this._firefoxMouseEvent();
        if (this._touchmoveEvent instanceof Function)
            this._touchmoveEvent();
        if (this._windowResizeEvent instanceof Function)
            this._windowResizeEvent();
        if (this._windowMouseScrollEvent instanceof Function)
            this._windowMouseScrollEvent();
    };
    KdTableAction.prototype._getActionList = function () {
        var returnArray = [];
        if (typeof this._params.data !== 'undefined' &&
            typeof this._params.data.action !== 'undefined') {
            returnArray = this._params.data.action;
        }
        else if (typeof this._params.params !== 'undefined') {
            returnArray = this._getNewArray(this._params.params);
        }
        return returnArray;
    };
    KdTableAction.ctorParameters = function () { return [
        { type: Renderer2 },
        { type: KdIntTableEvent }
    ]; };
    __decorate([
        ViewChild('menu'),
        __metadata("design:type", Menu)
    ], KdTableAction.prototype, "dropdownMenu", void 0);
    KdTableAction = __decorate([
        Component({
            template: "\n        <p-menu #menu popup=\"popup\" [appendTo]=\"'body'\" [model]=\"_actionList\"></p-menu>\n        <div class=\"action-btn\" (click)=\"toggleMenu($event)\">\n            <span>Select</span>\n             <i class=\"fa fa-chevron-down\"></i>\n        </div>\n    "
        }),
        __metadata("design:paramtypes", [Renderer2,
            KdIntTableEvent])
    ], KdTableAction);
    return KdTableAction;
}());
export { KdTableAction };
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoia2QtdGFibGUtYWN0aW9uLmpzIiwic291cmNlUm9vdCI6Im5nOi8vb3BlbmVtaXMtc3R5bGVndWlkZS1saWIvIiwic291cmNlcyI6WyJrZC1jb21wb25lbnRzL2tkLWFuZ3VsYXItdGFibGUvdGFibGUtY29tcG9uZW50cy9rZC10YWJsZS1hY3Rpb24udHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IjtBQUFBLE9BQU8sRUFDSCxTQUFTLEVBQ1QsU0FBUyxFQUNULFNBQVMsRUFDVCxTQUFTLEVBQ1osTUFBTSxlQUFlLENBQUM7QUFZdkIsT0FBTyxFQUFFLElBQUksRUFBRSxNQUFNLGNBQWMsQ0FBQztBQUVwQyxPQUFPLEVBQUUsZUFBZSxFQUFFLE1BQU0sMkJBQTJCLENBQUM7QUFDNUQsT0FBTyxFQUFFLFNBQVMsRUFBRSxNQUFNLHVCQUF1QixDQUFDO0FBaUJsRDtJQWFJLHVCQUNZLFNBQW9CLEVBQ3BCLFdBQTRCO1FBRDVCLGNBQVMsR0FBVCxTQUFTLENBQVc7UUFDcEIsZ0JBQVcsR0FBWCxXQUFXLENBQWlCO1FBWGhDLGFBQVEsR0FBYyxJQUFJLFNBQVMsRUFBRSxDQUFDO0lBWTFDLENBQUM7SUFFTCw4QkFBTSxHQUFOLFVBQU8sTUFBVztRQUNkLElBQUksQ0FBQyxPQUFPLEdBQUcsTUFBTSxDQUFDO1FBQ3RCLElBQUksQ0FBQyxXQUFXLEdBQUcsSUFBSSxDQUFDLGFBQWEsQ0FBQyxJQUFJLENBQUMsY0FBYyxFQUFFLENBQUMsQ0FBQztJQUNqRSxDQUFDO0lBRUQsK0JBQU8sR0FBUDtRQUNJLE9BQU8sS0FBSyxDQUFDO0lBQ2pCLENBQUM7SUFFRCxtQ0FBVyxHQUFYO1FBQ0ksSUFBSSxDQUFDLGdCQUFnQixFQUFFLENBQUM7UUFDeEIsNkJBQTZCO0lBQ2pDLENBQUM7SUFFTSxrQ0FBVSxHQUFqQixVQUFrQixFQUFTO1FBQ3ZCLHdCQUF3QjtRQUN4QixJQUFJLENBQUMsWUFBWSxDQUFDLE1BQU0sQ0FBQyxFQUFFLENBQUMsQ0FBQztRQUM3QixJQUFJLENBQUMsWUFBWSxFQUFFLENBQUM7SUFDeEIsQ0FBQztJQUVPLG9DQUFZLEdBQXBCLFVBQXFCLEtBQWlCO1FBQ2xDLElBQUksUUFBUSxHQUFlLEVBQUUsQ0FBQztRQUM5QixLQUFLLElBQUksQ0FBQyxHQUFXLENBQUMsRUFBRSxDQUFDLEdBQUcsS0FBSyxDQUFDLE1BQU0sRUFBRSxDQUFDLEVBQUUsRUFBRTtZQUMzQyxJQUFJLElBQUksR0FBYyxNQUFPLENBQUMsTUFBTSxDQUFDLEVBQUUsRUFBRSxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztZQUNuRCxRQUFRLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDO1NBQ3ZCO1FBQ0QsT0FBTyxRQUFRLENBQUM7SUFDcEIsQ0FBQztJQUVPLHFDQUFhLEdBQXJCLFVBQXNCLFdBQXVCO1FBQTdDLGlCQXNDQztRQXJDRyxJQUFJLFlBQVksR0FBZSxFQUFFLENBQUM7UUFFbEMsS0FBSyxJQUFJLENBQUMsR0FBVyxDQUFDLEVBQUUsQ0FBQyxHQUFHLFdBQVcsQ0FBQyxNQUFNLEVBQUUsQ0FBQyxFQUFFLEVBQUU7WUFDakQsSUFBSSxJQUFJLEdBQVEsV0FBVyxDQUFDLENBQUMsQ0FBQyxDQUFDO1lBRS9CLElBQUksQ0FBQyxLQUFLLEdBQUcsSUFBSSxDQUFDLElBQUksQ0FBQztZQUV2QixJQUFJLE9BQU8sSUFBSSxDQUFDLElBQUksS0FBSyxXQUFXLElBQUksSUFBSSxDQUFDLElBQUksS0FBSyxJQUFJLEVBQUU7Z0JBQ3hELElBQUksQ0FBQyxVQUFVLEdBQUcsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLGNBQWMsQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLElBQUksRUFBRSxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQzthQUNsRjtpQkFDSSxJQUFJLE9BQU8sSUFBSSxDQUFDLFFBQVEsS0FBSyxXQUFXLElBQUksSUFBSSxDQUFDLFFBQVEsSUFBSSxJQUFJLEVBQUU7Z0JBQ3BFLElBQUksQ0FBQyxNQUFNLEdBQUcsSUFBSSxDQUFDLE9BQU8sQ0FBQztnQkFDM0IsSUFBSSxDQUFDLE9BQU8sR0FBRyxVQUFDLE1BQVc7b0JBQ3ZCLElBQUksUUFBUSxHQUFvQjt3QkFDNUIsYUFBYSxFQUFFOzRCQUNYLElBQUksS0FBSSxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsUUFBUSxFQUFFLEVBQUU7Z0NBQzdCLElBQUksVUFBVSxHQUFtQixDQUFDLEtBQUksQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLENBQUM7Z0NBQ3JELEtBQUksQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLGFBQWEsQ0FBQyxFQUFDLE1BQU0sRUFBRSxVQUFVLEVBQUMsQ0FBQyxDQUFDO2dDQUNyRCxLQUFJLENBQUMsV0FBVyxDQUFDLGtCQUFrQixDQUFDLEtBQUksQ0FBQyxPQUFPLENBQUMsTUFBTSxFQUFFLFFBQVEsRUFBRSxLQUFJLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQzs2QkFDOUY7aUNBQ0k7Z0NBQ0QsT0FBTyxDQUFDLEtBQUssQ0FBRSx3RUFBd0UsQ0FBQyxDQUFDOzZCQUM1Rjt3QkFDTCxDQUFDO3FCQUNKLENBQUM7b0JBRUYsTUFBTSxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsS0FBSSxDQUFDLE9BQU8sQ0FBQyxJQUFJLEVBQUUsUUFBUSxDQUFDLENBQUM7Z0JBQ3RELENBQUMsQ0FBQzthQUNMO1lBRUQsSUFBSSxPQUFPLElBQUksQ0FBQyxNQUFNLEtBQUssV0FBVyxJQUFJLENBQUMsSUFBSSxDQUFDLE1BQU0sRUFBRTtnQkFDcEQsSUFBSSxHQUFHLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxJQUFJLENBQUMsQ0FBQzthQUN4QztZQUVELFlBQVksQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUM7U0FDM0I7UUFDRCxPQUFPLFlBQVksQ0FBQztJQUN4QixDQUFDO0lBRU8sMENBQWtCLEdBQTFCLFVBQTJCLElBQVM7UUFDaEMsSUFBSSxPQUFPLEdBQWMsTUFBTyxDQUFDLE1BQU0sQ0FBQyxFQUFFLEVBQUUsSUFBSSxDQUFDLENBQUM7UUFDbEQsUUFBUSxPQUFPLENBQUMsSUFBSSxDQUFDLFdBQVcsRUFBRSxFQUFFO1lBQ2hDLEtBQUssTUFBTTtnQkFDUCxPQUFPLENBQUMsS0FBSyxHQUFHLE1BQU0sQ0FBQztnQkFDdkIsT0FBTyxDQUFDLElBQUksR0FBRyxjQUFjLENBQUM7Z0JBQzlCLE1BQU07WUFDVixLQUFLLFFBQVE7Z0JBQ1QsT0FBTyxDQUFDLEtBQUssR0FBRyxRQUFRLENBQUM7Z0JBQ3pCLE9BQU8sQ0FBQyxJQUFJLEdBQUcsYUFBYSxDQUFDO2dCQUM3QixNQUFNO1lBQ1YsS0FBSyxNQUFNO2dCQUNQLE9BQU8sQ0FBQyxLQUFLLEdBQUcsTUFBTSxDQUFDO2dCQUN2QixPQUFPLENBQUMsSUFBSSxHQUFHLFdBQVcsQ0FBQztnQkFDM0IsTUFBTTtZQUNWO2dCQUNJLE9BQU8sQ0FBQyxLQUFLLENBQUMsa0NBQWtDLEdBQUcsT0FBTyxDQUFDLElBQUksQ0FBQyxDQUFDO2dCQUNqRSxNQUFNO1NBQ2I7UUFDRCxPQUFPLE9BQU8sQ0FBQztJQUNuQixDQUFDO0lBRU8sb0NBQVksR0FBcEI7UUFBQSxpQkFnQkM7UUFmRyxJQUFJLENBQUMsa0JBQWtCLEdBQUcsSUFBSSxDQUFDLFNBQVMsQ0FBQyxNQUFNLENBQUMsVUFBVSxFQUFFLGdCQUFnQixFQUFFLFVBQUMsWUFBd0I7WUFDbkcsS0FBSSxDQUFDLFNBQVMsRUFBRSxDQUFDO1FBQ3JCLENBQUMsQ0FBQyxDQUFDO1FBRUgsSUFBSSxDQUFDLGVBQWUsR0FBRyxJQUFJLENBQUMsU0FBUyxDQUFDLE1BQU0sQ0FBQyxVQUFVLEVBQUUsV0FBVyxFQUFFLFVBQUMsVUFBc0I7WUFDekYsS0FBSSxDQUFDLFNBQVMsRUFBRSxDQUFDO1FBQ3JCLENBQUMsQ0FBQyxDQUFDO1FBRUgsSUFBSSxDQUFDLGtCQUFrQixHQUFHLElBQUksQ0FBQyxTQUFTLENBQUMsTUFBTSxDQUFDLFFBQVEsRUFBRSxRQUFRLEVBQUUsVUFBQyxLQUFZO1lBQzdFLEtBQUksQ0FBQyxTQUFTLEVBQUUsQ0FBQztRQUNyQixDQUFDLENBQUMsQ0FBQztRQUVILElBQUksQ0FBQyx1QkFBdUIsR0FBRyxJQUFJLENBQUMsU0FBUyxDQUFDLE1BQU0sQ0FBQyxVQUFVLEVBQUUsWUFBWSxFQUFFLFVBQUMsS0FBWTtZQUN4RixLQUFJLENBQUMsU0FBUyxFQUFFLENBQUM7UUFDckIsQ0FBQyxDQUFDLENBQUM7SUFDUCxDQUFDO0lBRU8saUNBQVMsR0FBakI7UUFDSSxJQUFJLENBQUMsZ0JBQWdCLEVBQUUsQ0FBQztRQUN4QixJQUFJLENBQUMsWUFBWSxDQUFDLElBQUksRUFBRSxDQUFDO0lBQzdCLENBQUM7SUFFTyx3Q0FBZ0IsR0FBeEI7UUFDSSxJQUFJLElBQUksQ0FBQyxrQkFBa0IsWUFBWSxRQUFRO1lBQUUsSUFBSSxDQUFDLGtCQUFrQixFQUFFLENBQUM7UUFDM0UsSUFBSSxJQUFJLENBQUMsZUFBZSxZQUFZLFFBQVE7WUFBRSxJQUFJLENBQUMsZUFBZSxFQUFFLENBQUM7UUFDckUsSUFBSSxJQUFJLENBQUMsa0JBQWtCLFlBQVksUUFBUTtZQUFFLElBQUksQ0FBQyxrQkFBa0IsRUFBRSxDQUFDO1FBQzNFLElBQUksSUFBSSxDQUFDLHVCQUF1QixZQUFZLFFBQVE7WUFBRSxJQUFJLENBQUMsdUJBQXVCLEVBQUUsQ0FBQztJQUN6RixDQUFDO0lBRU8sc0NBQWMsR0FBdEI7UUFDSSxJQUFJLFdBQVcsR0FBZSxFQUFFLENBQUM7UUFFakMsSUFBSSxPQUFPLElBQUksQ0FBQyxPQUFPLENBQUMsSUFBSSxLQUFLLFdBQVc7WUFDeEMsT0FBTyxJQUFJLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxNQUFNLEtBQUssV0FBVyxFQUFFO1lBQzdDLFdBQVcsR0FBRyxJQUFJLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUM7U0FDOUM7YUFDSSxJQUFJLE9BQU8sSUFBSSxDQUFDLE9BQU8sQ0FBQyxNQUFNLEtBQUssV0FBVyxFQUFFO1lBQzdDLFdBQVcsR0FBRyxJQUFJLENBQUMsWUFBWSxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLENBQUM7U0FDNUQ7UUFFRCxPQUFPLFdBQVcsQ0FBQztJQUN2QixDQUFDOztnQkF6SXNCLFNBQVM7Z0JBQ1AsZUFBZTs7SUFKckI7UUFBbEIsU0FBUyxDQUFDLE1BQU0sQ0FBQztrQ0FBZSxJQUFJO3VEQUFDO0lBWDdCLGFBQWE7UUFWekIsU0FBUyxDQUFDO1lBQ1AsUUFBUSxFQUFFLDhRQU1UO1NBQ0osQ0FBQzt5Q0FnQnlCLFNBQVM7WUFDUCxlQUFlO09BZi9CLGFBQWEsQ0F3SnpCO0lBQUQsb0JBQUM7Q0FBQSxBQXhKRCxJQXdKQztTQXhKWSxhQUFhIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHtcclxuICAgIENvbXBvbmVudCxcclxuICAgIE9uRGVzdHJveSxcclxuICAgIFJlbmRlcmVyMixcclxuICAgIFZpZXdDaGlsZFxyXG59IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xyXG5pbXBvcnQge1xyXG4gICAgUm93Tm9kZSxcclxuICAgIElDZWxsUmVuZGVyZXJQYXJhbXMsXHJcbn0gZnJvbSAnYWctZ3JpZC1jb21tdW5pdHknO1xyXG5cclxuLy8gaW1wb3J0IHtcclxuLy8gICAgIEluTWVtb3J5Um93TW9kZWxcclxuLy8gfSBmcm9tICcuLi9saWIvcm93TW9kZWxzL2luTWVtb3J5L2luTWVtb3J5Um93TW9kZWwnO1xyXG5cclxuLy8gaW1wb3J0IHsgUm93TX0gZnJvbSAnYWctZ3JpZC1lbnRlcnByaXNlL21haW4nO1xyXG5pbXBvcnQgeyBBZ1JlbmRlcmVyQ29tcG9uZW50IH0gZnJvbSAnYWctZ3JpZC1hbmd1bGFyJztcclxuaW1wb3J0IHsgTWVudSB9IGZyb20gJ3ByaW1lbmcvbWVudSc7XHJcbmltcG9ydCB7IElUYWJsZURyb3Bkb3duQWN0aW9uLCBJVGFibGVBY3Rpb25BcGkgfSBmcm9tICcuLi9pbmRleCc7XHJcbmltcG9ydCB7IEtkSW50VGFibGVFdmVudCB9IGZyb20gJy4uL2tkLWFuZ3VsYXItdGFibGUtZXZlbnQnO1xyXG5pbXBvcnQgeyBLZERhdGFTdmMgfSBmcm9tICcuLi8uLi9rZC1jb21tb24vaW5kZXgnO1xyXG5cclxuaW50ZXJmYWNlIEtkVGFibGVBY3Rpb25DZWxsUGFyYW0gZXh0ZW5kcyBJQ2VsbFJlbmRlcmVyUGFyYW1zIHtcclxuICAgIHBhcmFtcz86IEFycmF5PElUYWJsZURyb3Bkb3duQWN0aW9uPjtcclxuICAgIGdyaWRJZD86IHN0cmluZztcclxufVxyXG5cclxuQENvbXBvbmVudCh7XHJcbiAgICB0ZW1wbGF0ZTogYFxyXG4gICAgICAgIDxwLW1lbnUgI21lbnUgcG9wdXA9XCJwb3B1cFwiIFthcHBlbmRUb109XCInYm9keSdcIiBbbW9kZWxdPVwiX2FjdGlvbkxpc3RcIj48L3AtbWVudT5cclxuICAgICAgICA8ZGl2IGNsYXNzPVwiYWN0aW9uLWJ0blwiIChjbGljayk9XCJ0b2dnbGVNZW51KCRldmVudClcIj5cclxuICAgICAgICAgICAgPHNwYW4+U2VsZWN0PC9zcGFuPlxyXG4gICAgICAgICAgICAgPGkgY2xhc3M9XCJmYSBmYS1jaGV2cm9uLWRvd25cIj48L2k+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICBgXHJcbn0pXHJcblxyXG5leHBvcnQgY2xhc3MgS2RUYWJsZUFjdGlvbiBpbXBsZW1lbnRzIEFnUmVuZGVyZXJDb21wb25lbnQsIE9uRGVzdHJveSB7XHJcbiAgICBwdWJsaWMgX2FjdGlvbkxpc3Q6IEFycmF5PGFueT47XHJcblxyXG4gICAgcHJpdmF0ZSBfcGFyYW1zOiBLZFRhYmxlQWN0aW9uQ2VsbFBhcmFtO1xyXG4gICAgcHJpdmF0ZSBfZGF0YVN2YzogS2REYXRhU3ZjID0gbmV3IEtkRGF0YVN2YygpO1xyXG5cclxuICAgIHByaXZhdGUgX3RvdWNobW92ZUV2ZW50OiBGdW5jdGlvbjtcclxuICAgIHByaXZhdGUgX2ZpcmVmb3hNb3VzZUV2ZW50OiBGdW5jdGlvbjtcclxuICAgIHByaXZhdGUgX3dpbmRvd1Jlc2l6ZUV2ZW50OiBGdW5jdGlvbjtcclxuICAgIHByaXZhdGUgX3dpbmRvd01vdXNlU2Nyb2xsRXZlbnQ6IEZ1bmN0aW9uO1xyXG5cclxuICAgIEBWaWV3Q2hpbGQoJ21lbnUnKSBkcm9wZG93bk1lbnU6IE1lbnU7XHJcblxyXG4gICAgY29uc3RydWN0b3IoXHJcbiAgICAgICAgcHJpdmF0ZSBfcmVuZGVyZXI6IFJlbmRlcmVyMixcclxuICAgICAgICBwcml2YXRlIF9rZEludEV2ZW50OiBLZEludFRhYmxlRXZlbnRcclxuICAgICkgeyB9XHJcblxyXG4gICAgYWdJbml0KHBhcmFtczogYW55KTogdm9pZCB7XHJcbiAgICAgICAgdGhpcy5fcGFyYW1zID0gcGFyYW1zO1xyXG4gICAgICAgIHRoaXMuX2FjdGlvbkxpc3QgPSB0aGlzLl91cGRhdGVBY3Rpb24odGhpcy5fZ2V0QWN0aW9uTGlzdCgpKTtcclxuICAgIH1cclxuXHJcbiAgICByZWZyZXNoKCk6IGJvb2xlYW4ge1xyXG4gICAgICAgIHJldHVybiBmYWxzZTtcclxuICAgIH1cclxuXHJcbiAgICBuZ09uRGVzdHJveSgpOiB2b2lkIHtcclxuICAgICAgICB0aGlzLl9kZXN0cm95TGlzdGVuZXIoKTtcclxuICAgICAgICAvLyB0aGlzLl9yZW1vdmVNZW51RnJvbURPTSgpO1xyXG4gICAgfVxyXG5cclxuICAgIHB1YmxpYyB0b2dnbGVNZW51KF9lOiBFdmVudCk6IHZvaWQge1xyXG4gICAgICAgIC8vIF9lLnN0b3BQcm9wYWdhdGlvbigpO1xyXG4gICAgICAgIHRoaXMuZHJvcGRvd25NZW51LnRvZ2dsZShfZSk7XHJcbiAgICAgICAgdGhpcy5fc2V0TGlzdGVuZXIoKTtcclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF9nZXROZXdBcnJheShpdGVtczogQXJyYXk8YW55Pik6IEFycmF5PGFueT4ge1xyXG4gICAgICAgIGxldCBuZXdBcnJheTogQXJyYXk8YW55PiA9IFtdO1xyXG4gICAgICAgIGZvciAobGV0IGk6IG51bWJlciA9IDA7IGkgPCBpdGVtcy5sZW5ndGg7IGkrKykge1xyXG4gICAgICAgICAgICBsZXQgaXRlbTogYW55ID0gKDxhbnk+T2JqZWN0KS5hc3NpZ24oe30sIGl0ZW1zW2ldKTtcclxuICAgICAgICAgICAgbmV3QXJyYXkucHVzaChpdGVtKTtcclxuICAgICAgICB9XHJcbiAgICAgICAgcmV0dXJuIG5ld0FycmF5O1xyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX3VwZGF0ZUFjdGlvbihfYWN0aW9uTGlzdDogQXJyYXk8YW55Pik6IEFycmF5PGFueT4ge1xyXG4gICAgICAgIGxldCB1cGRhdGVkQXJyYXk6IEFycmF5PGFueT4gPSBbXTtcclxuXHJcbiAgICAgICAgZm9yIChsZXQgaTogbnVtYmVyID0gMDsgaSA8IF9hY3Rpb25MaXN0Lmxlbmd0aDsgaSsrKSB7XHJcbiAgICAgICAgICAgIGxldCBpdGVtOiBhbnkgPSBfYWN0aW9uTGlzdFtpXTtcclxuXHJcbiAgICAgICAgICAgIGl0ZW0ubGFiZWwgPSBpdGVtLm5hbWU7XHJcblxyXG4gICAgICAgICAgICBpZiAodHlwZW9mIGl0ZW0ucGF0aCAhPT0gJ3VuZGVmaW5lZCcgJiYgaXRlbS5wYXRoICE9PSBudWxsKSB7XHJcbiAgICAgICAgICAgICAgICBpdGVtLnJvdXRlckxpbmsgPSBbdGhpcy5fZGF0YVN2Yy5nZXRQbGFjZWhvbGRlcih0aGlzLl9wYXJhbXMuZGF0YSwgaXRlbS5wYXRoKV07XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgZWxzZSBpZiAodHlwZW9mIGl0ZW0uY2FsbGJhY2sgIT09ICd1bmRlZmluZWQnICYmIGl0ZW0uY2FsbGJhY2sgIT0gbnVsbCkge1xyXG4gICAgICAgICAgICAgICAgaXRlbS5wYXJhbXMgPSB0aGlzLl9wYXJhbXM7XHJcbiAgICAgICAgICAgICAgICBpdGVtLmNvbW1hbmQgPSAoX2V2ZW50OiBhbnkpOiB2b2lkID0+IHtcclxuICAgICAgICAgICAgICAgICAgICBsZXQgdGFibGVBcGk6IElUYWJsZUFjdGlvbkFwaSA9IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgZGVsZXRlVGhpc1JvdzogKCk6IHZvaWQgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKHRoaXMuX3BhcmFtcy5hcGkuZ2V0TW9kZWwoKSkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxldCByZW1vdmVOb2RlOiBBcnJheTxSb3dOb2RlPiA9IFt0aGlzLl9wYXJhbXMubm9kZV07XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5fcGFyYW1zLmFwaS51cGRhdGVSb3dEYXRhKHtyZW1vdmU6IHJlbW92ZU5vZGV9KTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0aGlzLl9rZEludEV2ZW50LnVwZGF0ZUVtaXRSb3dOb2Rlcyh0aGlzLl9wYXJhbXMuZ3JpZElkLCAnZGVsZXRlJywgdGhpcy5fcGFyYW1zLm5vZGUuZGF0YSk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb25zb2xlLmVycm9yICgnS2RUYWJsZSBhY3Rpb24gZXJyb3I6IERlbGV0ZVRoaXNSb3cgZnVuY3Rpb24gb25seSBmb3Igbm9ybWFsIGxvYWRUeXBlLicpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgfTtcclxuXHJcbiAgICAgICAgICAgICAgICAgICAgX2V2ZW50Lml0ZW0uY2FsbGJhY2sodGhpcy5fcGFyYW1zLm5vZGUsIHRhYmxlQXBpKTtcclxuICAgICAgICAgICAgICAgIH07XHJcbiAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgIGlmICh0eXBlb2YgaXRlbS5jdXN0b20gPT09ICd1bmRlZmluZWQnIHx8ICFpdGVtLmN1c3RvbSkge1xyXG4gICAgICAgICAgICAgICAgaXRlbSA9IHRoaXMuX2NoZWNrQ3VzdG9tQnV0dG9uKGl0ZW0pO1xyXG4gICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICB1cGRhdGVkQXJyYXkucHVzaChpdGVtKTtcclxuICAgICAgICB9XHJcbiAgICAgICAgcmV0dXJuIHVwZGF0ZWRBcnJheTtcclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF9jaGVja0N1c3RvbUJ1dHRvbihpdGVtOiBhbnkpOiBhbnkge1xyXG4gICAgICAgIGxldCBuZXdJdGVtOiBhbnkgPSAoPGFueT5PYmplY3QpLmFzc2lnbih7fSwgaXRlbSk7XHJcbiAgICAgICAgc3dpdGNoIChuZXdJdGVtLnR5cGUudG9Mb3dlckNhc2UoKSkge1xyXG4gICAgICAgICAgICBjYXNlICdlZGl0JzpcclxuICAgICAgICAgICAgICAgIG5ld0l0ZW0ubGFiZWwgPSAnRWRpdCc7XHJcbiAgICAgICAgICAgICAgICBuZXdJdGVtLmljb24gPSAnZmEgZmEtcGVuY2lsJztcclxuICAgICAgICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgICAgICBjYXNlICdkZWxldGUnOlxyXG4gICAgICAgICAgICAgICAgbmV3SXRlbS5sYWJlbCA9ICdEZWxldGUnO1xyXG4gICAgICAgICAgICAgICAgbmV3SXRlbS5pY29uID0gJ2ZhIGZhLXRyYXNoJztcclxuICAgICAgICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgICAgICBjYXNlICd2aWV3JzpcclxuICAgICAgICAgICAgICAgIG5ld0l0ZW0ubGFiZWwgPSAnVmlldyc7XHJcbiAgICAgICAgICAgICAgICBuZXdJdGVtLmljb24gPSAnZmEgZmEtZXllJztcclxuICAgICAgICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgICAgICBkZWZhdWx0OlxyXG4gICAgICAgICAgICAgICAgY29uc29sZS5lcnJvcignTm8gc3VjaCBjdXN0b20gYnV0dG9uIGZvdW5kIGZvciAnICsgbmV3SXRlbS50eXBlKTtcclxuICAgICAgICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgIH1cclxuICAgICAgICByZXR1cm4gbmV3SXRlbTtcclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF9zZXRMaXN0ZW5lcigpOiB2b2lkIHtcclxuICAgICAgICB0aGlzLl9maXJlZm94TW91c2VFdmVudCA9IHRoaXMuX3JlbmRlcmVyLmxpc3RlbignZG9jdW1lbnQnLCAnRE9NTW91c2VTY3JvbGwnLCAoZmZNb3VzZUV2ZW50OiBNb3VzZUV2ZW50KTogdm9pZCA9PiB7XHJcbiAgICAgICAgICAgIHRoaXMuX2hpZGVNZW51KCk7XHJcbiAgICAgICAgfSk7XHJcblxyXG4gICAgICAgIHRoaXMuX3RvdWNobW92ZUV2ZW50ID0gdGhpcy5fcmVuZGVyZXIubGlzdGVuKCdkb2N1bWVudCcsICd0b3VjaG1vdmUnLCAodG91Y2hFdmVudDogVG91Y2hFdmVudCk6IHZvaWQgPT4ge1xyXG4gICAgICAgICAgICB0aGlzLl9oaWRlTWVudSgpO1xyXG4gICAgICAgIH0pO1xyXG5cclxuICAgICAgICB0aGlzLl93aW5kb3dSZXNpemVFdmVudCA9IHRoaXMuX3JlbmRlcmVyLmxpc3Rlbignd2luZG93JywgJ3Jlc2l6ZScsIChldmVudDogRXZlbnQpOiB2b2lkID0+IHtcclxuICAgICAgICAgICAgdGhpcy5faGlkZU1lbnUoKTtcclxuICAgICAgICB9KTtcclxuXHJcbiAgICAgICAgdGhpcy5fd2luZG93TW91c2VTY3JvbGxFdmVudCA9IHRoaXMuX3JlbmRlcmVyLmxpc3RlbignZG9jdW1lbnQnLCAnbW91c2V3aGVlbCcsIChldmVudDogRXZlbnQpOiB2b2lkID0+IHtcclxuICAgICAgICAgICAgdGhpcy5faGlkZU1lbnUoKTtcclxuICAgICAgICB9KTtcclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF9oaWRlTWVudSgpOiB2b2lkIHtcclxuICAgICAgICB0aGlzLl9kZXN0cm95TGlzdGVuZXIoKTtcclxuICAgICAgICB0aGlzLmRyb3Bkb3duTWVudS5oaWRlKCk7XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfZGVzdHJveUxpc3RlbmVyKCk6IHZvaWQge1xyXG4gICAgICAgIGlmICh0aGlzLl9maXJlZm94TW91c2VFdmVudCBpbnN0YW5jZW9mIEZ1bmN0aW9uKSB0aGlzLl9maXJlZm94TW91c2VFdmVudCgpO1xyXG4gICAgICAgIGlmICh0aGlzLl90b3VjaG1vdmVFdmVudCBpbnN0YW5jZW9mIEZ1bmN0aW9uKSB0aGlzLl90b3VjaG1vdmVFdmVudCgpO1xyXG4gICAgICAgIGlmICh0aGlzLl93aW5kb3dSZXNpemVFdmVudCBpbnN0YW5jZW9mIEZ1bmN0aW9uKSB0aGlzLl93aW5kb3dSZXNpemVFdmVudCgpO1xyXG4gICAgICAgIGlmICh0aGlzLl93aW5kb3dNb3VzZVNjcm9sbEV2ZW50IGluc3RhbmNlb2YgRnVuY3Rpb24pIHRoaXMuX3dpbmRvd01vdXNlU2Nyb2xsRXZlbnQoKTtcclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF9nZXRBY3Rpb25MaXN0KCk6IEFycmF5PGFueT4ge1xyXG4gICAgICAgIGxldCByZXR1cm5BcnJheTogQXJyYXk8YW55PiA9IFtdO1xyXG5cclxuICAgICAgICBpZiAodHlwZW9mIHRoaXMuX3BhcmFtcy5kYXRhICE9PSAndW5kZWZpbmVkJyAmJlxyXG4gICAgICAgICAgICB0eXBlb2YgdGhpcy5fcGFyYW1zLmRhdGEuYWN0aW9uICE9PSAndW5kZWZpbmVkJykge1xyXG4gICAgICAgICAgICAgICAgcmV0dXJuQXJyYXkgPSB0aGlzLl9wYXJhbXMuZGF0YS5hY3Rpb247XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGVsc2UgaWYgKHR5cGVvZiB0aGlzLl9wYXJhbXMucGFyYW1zICE9PSAndW5kZWZpbmVkJykge1xyXG4gICAgICAgICAgICAgICAgcmV0dXJuQXJyYXkgPSB0aGlzLl9nZXROZXdBcnJheSh0aGlzLl9wYXJhbXMucGFyYW1zKTtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIHJldHVybiByZXR1cm5BcnJheTtcclxuICAgIH1cclxufVxyXG4iXX0=