import { __decorate, __metadata } from "tslib";
import { Injectable } from '@angular/core';
import { KdBroadcaster } from '../kd-common/index';
import * as i0 from "@angular/core";
import * as i1 from "../kd-common/kd-broadcaster-svc";
var KdTableEvent = /** @class */ (function () {
    function KdTableEvent(_broadcaster) {
        this._broadcaster = _broadcaster;
    }
    /// For any component using KdTable to capture all the informations KdTable emits
    KdTableEvent.prototype.onKdTableEventList = function (_gridId) {
        return this._broadcaster.on(_gridId + 'KdTableEvent');
    };
    KdTableEvent.ctorParameters = function () { return [
        { type: KdBroadcaster }
    ]; };
    KdTableEvent.ɵprov = i0.ɵɵdefineInjectable({ factory: function KdTableEvent_Factory() { return new KdTableEvent(i0.ɵɵinject(i1.KdBroadcaster)); }, token: KdTableEvent, providedIn: "root" });
    KdTableEvent = __decorate([
        Injectable({
            providedIn: 'root'
        }),
        __metadata("design:paramtypes", [KdBroadcaster])
    ], KdTableEvent);
    return KdTableEvent;
}());
export { KdTableEvent };
var KdIntTableEvent = /** @class */ (function () {
    function KdIntTableEvent(_broadcaster) {
        this._broadcaster = _broadcaster;
    }
    /// Broadcast any events for components using KdTable
    KdIntTableEvent.prototype.kdTableEventList = function (_gridId, _event) {
        this._broadcaster.broadcast(_gridId + 'KdTableEvent', _event);
    };
    /// Used on kd-table-action.ts - For delete node params to update the row data accordingly
    KdIntTableEvent.prototype.updateEmitRowNodes = function (_gridId, _action, _rowData) {
        var data = {
            action: _action,
            rowData: _rowData
        };
        this._broadcaster.broadcast(_gridId + 'KdTableRowUpdated', data);
    };
    /// Used on kd-angular-table.ts - For update the delete node params in kd-table-action.ts
    KdIntTableEvent.prototype.onUpdateEmitRowNodes = function (_gridId) {
        return this._broadcaster.on(_gridId + 'KdTableRowUpdated');
    };
    /// Used on kd-table-checkbox-radio.ts - Checkbox / radio emit change event
    KdIntTableEvent.prototype.selectionChanged = function (_gridId, _data) {
        this._broadcaster.broadcast(_gridId + 'KdTableUpdateNodes', _data);
    };
    /// Used on kd-table-checkbox-radio.ts - To recheck the select all checkbox
    KdIntTableEvent.prototype.onSelectionChanged = function (_gridId) {
        return this._broadcaster.on(_gridId + 'KdTableUpdateNodes');
    };
    /// Used on kd-angular-table.ts - Emit on row data / model changed
    KdIntTableEvent.prototype.modelChanged = function (_gridId, _data) {
        this._broadcaster.broadcast(_gridId + 'KdModelUpdated', _data);
    };
    /// Used on kd-table-checkbox-radio.ts - To recheck the select all checkbox
    KdIntTableEvent.prototype.onModelChanged = function (_gridId) {
        return this._broadcaster.on(_gridId + 'KdModelUpdated');
    };
    /// Used on kd-table-input.ts - For emitting any form changes to output to dynamicForm
    KdIntTableEvent.prototype.inputChanged = function (_gridId, _data) {
        this._broadcaster.broadcast(_gridId + 'KdTableInputChanged', _data);
    };
    /// Used on kd-angular-table.ts - Capture the change params and emit to anyone using the output
    KdIntTableEvent.prototype.onInputChanged = function (_gridId) {
        return this._broadcaster.on(_gridId + 'KdTableInputChanged');
    };
    KdIntTableEvent.ctorParameters = function () { return [
        { type: KdBroadcaster }
    ]; };
    KdIntTableEvent = __decorate([
        Injectable(),
        __metadata("design:paramtypes", [KdBroadcaster])
    ], KdIntTableEvent);
    return KdIntTableEvent;
}());
export { KdIntTableEvent };
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoia2QtYW5ndWxhci10YWJsZS1ldmVudC5qcyIsInNvdXJjZVJvb3QiOiJuZzovL29wZW5lbWlzLXN0eWxlZ3VpZGUtbGliLyIsInNvdXJjZXMiOlsia2QtY29tcG9uZW50cy9rZC1hbmd1bGFyLXRhYmxlL2tkLWFuZ3VsYXItdGFibGUtZXZlbnQudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IjtBQUFBLE9BQU8sRUFBRSxVQUFVLEVBQUUsTUFBTSxlQUFlLENBQUM7QUFFM0MsT0FBTyxFQUFFLGFBQWEsRUFBRSxNQUFNLG9CQUFvQixDQUFDOzs7QUFNbkQ7SUFDSSxzQkFDWSxZQUEyQjtRQUEzQixpQkFBWSxHQUFaLFlBQVksQ0FBZTtJQUNuQyxDQUFDO0lBRUwsaUZBQWlGO0lBQzFFLHlDQUFrQixHQUF6QixVQUEwQixPQUFlO1FBQ3JDLE9BQU8sSUFBSSxDQUFDLFlBQVksQ0FBQyxFQUFFLENBQU0sT0FBTyxHQUFHLGNBQWMsQ0FBQyxDQUFDO0lBQy9ELENBQUM7O2dCQU55QixhQUFhOzs7SUFGOUIsWUFBWTtRQUh4QixVQUFVLENBQUM7WUFDUixVQUFVLEVBQUUsTUFBTTtTQUNyQixDQUFDO3lDQUc0QixhQUFhO09BRjlCLFlBQVksQ0FTeEI7dUJBakJEO0NBaUJDLEFBVEQsSUFTQztTQVRZLFlBQVk7QUFZekI7SUFDSSx5QkFDWSxZQUEyQjtRQUEzQixpQkFBWSxHQUFaLFlBQVksQ0FBZTtJQUNuQyxDQUFDO0lBRUwscURBQXFEO0lBQzlDLDBDQUFnQixHQUF2QixVQUF3QixPQUFlLEVBQUUsTUFBWTtRQUNqRCxJQUFJLENBQUMsWUFBWSxDQUFDLFNBQVMsQ0FBQyxPQUFPLEdBQUcsY0FBYyxFQUFFLE1BQU0sQ0FBQyxDQUFDO0lBQ2xFLENBQUM7SUFFRCwwRkFBMEY7SUFDbkYsNENBQWtCLEdBQXpCLFVBQTBCLE9BQWUsRUFBRSxPQUFlLEVBQUUsUUFBYTtRQUNyRSxJQUFJLElBQUksR0FBcUM7WUFDekMsTUFBTSxFQUFFLE9BQU87WUFDZixPQUFPLEVBQUUsUUFBUTtTQUNwQixDQUFDO1FBQ0YsSUFBSSxDQUFDLFlBQVksQ0FBQyxTQUFTLENBQUMsT0FBTyxHQUFHLG1CQUFtQixFQUFFLElBQUksQ0FBQyxDQUFDO0lBQ3JFLENBQUM7SUFFRCx5RkFBeUY7SUFDbEYsOENBQW9CLEdBQTNCLFVBQTRCLE9BQWU7UUFDdkMsT0FBTyxJQUFJLENBQUMsWUFBWSxDQUFDLEVBQUUsQ0FBTSxPQUFPLEdBQUcsbUJBQW1CLENBQUMsQ0FBQztJQUNwRSxDQUFDO0lBRUQsMkVBQTJFO0lBQ3BFLDBDQUFnQixHQUF2QixVQUF3QixPQUFlLEVBQUUsS0FBVztRQUNoRCxJQUFJLENBQUMsWUFBWSxDQUFDLFNBQVMsQ0FBQyxPQUFPLEdBQUcsb0JBQW9CLEVBQUUsS0FBSyxDQUFDLENBQUM7SUFDdkUsQ0FBQztJQUVELDJFQUEyRTtJQUNwRSw0Q0FBa0IsR0FBekIsVUFBMEIsT0FBZTtRQUNyQyxPQUFPLElBQUksQ0FBQyxZQUFZLENBQUMsRUFBRSxDQUFNLE9BQU8sR0FBRyxvQkFBb0IsQ0FBQyxDQUFDO0lBQ3JFLENBQUM7SUFFRCxrRUFBa0U7SUFDM0Qsc0NBQVksR0FBbkIsVUFBb0IsT0FBZSxFQUFFLEtBQVc7UUFDNUMsSUFBSSxDQUFDLFlBQVksQ0FBQyxTQUFTLENBQUMsT0FBTyxHQUFHLGdCQUFnQixFQUFFLEtBQUssQ0FBQyxDQUFDO0lBQ25FLENBQUM7SUFFRCwyRUFBMkU7SUFDcEUsd0NBQWMsR0FBckIsVUFBc0IsT0FBZTtRQUNqQyxPQUFPLElBQUksQ0FBQyxZQUFZLENBQUMsRUFBRSxDQUFNLE9BQU8sR0FBRyxnQkFBZ0IsQ0FBQyxDQUFDO0lBQ2pFLENBQUM7SUFFRCxzRkFBc0Y7SUFDL0Usc0NBQVksR0FBbkIsVUFBb0IsT0FBZSxFQUFFLEtBQXdCO1FBQ3pELElBQUksQ0FBQyxZQUFZLENBQUMsU0FBUyxDQUFDLE9BQU8sR0FBRyxxQkFBcUIsRUFBRSxLQUFLLENBQUMsQ0FBQztJQUN4RSxDQUFDO0lBRUQsK0ZBQStGO0lBQ3hGLHdDQUFjLEdBQXJCLFVBQXNCLE9BQWU7UUFDakMsT0FBTyxJQUFJLENBQUMsWUFBWSxDQUFDLEVBQUUsQ0FBbUIsT0FBTyxHQUFHLHFCQUFxQixDQUFDLENBQUM7SUFDbkYsQ0FBQzs7Z0JBbER5QixhQUFhOztJQUY5QixlQUFlO1FBRDNCLFVBQVUsRUFBRTt5Q0FHaUIsYUFBYTtPQUY5QixlQUFlLENBcUQzQjtJQUFELHNCQUFDO0NBQUEsQUFyREQsSUFxREM7U0FyRFksZUFBZSIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IEluamVjdGFibGUgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcclxuaW1wb3J0IHsgT2JzZXJ2YWJsZSB9IGZyb20gJ3J4anMnO1xyXG5pbXBvcnQgeyBLZEJyb2FkY2FzdGVyIH0gZnJvbSAnLi4va2QtY29tbW9uL2luZGV4JztcclxuaW1wb3J0IHsgSVRhYmxlRm9ybVBhcmFtcyB9IGZyb20gJy4va2QtYW5ndWxhci10YWJsZS1pbnRlcmZhY2UnO1xyXG5cclxuQEluamVjdGFibGUoe1xyXG4gICAgcHJvdmlkZWRJbjogJ3Jvb3QnXHJcbn0pXHJcbmV4cG9ydCBjbGFzcyBLZFRhYmxlRXZlbnQge1xyXG4gICAgY29uc3RydWN0b3IoXHJcbiAgICAgICAgcHJpdmF0ZSBfYnJvYWRjYXN0ZXI6IEtkQnJvYWRjYXN0ZXJcclxuICAgICkgeyB9XHJcblxyXG4gICAgLy8vIEZvciBhbnkgY29tcG9uZW50IHVzaW5nIEtkVGFibGUgdG8gY2FwdHVyZSBhbGwgdGhlIGluZm9ybWF0aW9ucyBLZFRhYmxlIGVtaXRzXHJcbiAgICBwdWJsaWMgb25LZFRhYmxlRXZlbnRMaXN0KF9ncmlkSWQ6IHN0cmluZyk6IE9ic2VydmFibGU8YW55PiB7XHJcbiAgICAgICAgcmV0dXJuIHRoaXMuX2Jyb2FkY2FzdGVyLm9uPGFueT4oX2dyaWRJZCArICdLZFRhYmxlRXZlbnQnKTtcclxuICAgIH1cclxufVxyXG5cclxuQEluamVjdGFibGUoKVxyXG5leHBvcnQgY2xhc3MgS2RJbnRUYWJsZUV2ZW50IHtcclxuICAgIGNvbnN0cnVjdG9yKFxyXG4gICAgICAgIHByaXZhdGUgX2Jyb2FkY2FzdGVyOiBLZEJyb2FkY2FzdGVyXHJcbiAgICApIHsgfVxyXG5cclxuICAgIC8vLyBCcm9hZGNhc3QgYW55IGV2ZW50cyBmb3IgY29tcG9uZW50cyB1c2luZyBLZFRhYmxlXHJcbiAgICBwdWJsaWMga2RUYWJsZUV2ZW50TGlzdChfZ3JpZElkOiBzdHJpbmcsIF9ldmVudD86IGFueSk6IHZvaWQge1xyXG4gICAgICAgIHRoaXMuX2Jyb2FkY2FzdGVyLmJyb2FkY2FzdChfZ3JpZElkICsgJ0tkVGFibGVFdmVudCcsIF9ldmVudCk7XHJcbiAgICB9XHJcblxyXG4gICAgLy8vIFVzZWQgb24ga2QtdGFibGUtYWN0aW9uLnRzIC0gRm9yIGRlbGV0ZSBub2RlIHBhcmFtcyB0byB1cGRhdGUgdGhlIHJvdyBkYXRhIGFjY29yZGluZ2x5XHJcbiAgICBwdWJsaWMgdXBkYXRlRW1pdFJvd05vZGVzKF9ncmlkSWQ6IHN0cmluZywgX2FjdGlvbjogc3RyaW5nLCBfcm93RGF0YTogYW55KTogdm9pZCB7XHJcbiAgICAgICAgbGV0IGRhdGE6IHsgYWN0aW9uOiBzdHJpbmcsIHJvd0RhdGE6IGFueSB9ID0ge1xyXG4gICAgICAgICAgICBhY3Rpb246IF9hY3Rpb24sXHJcbiAgICAgICAgICAgIHJvd0RhdGE6IF9yb3dEYXRhXHJcbiAgICAgICAgfTtcclxuICAgICAgICB0aGlzLl9icm9hZGNhc3Rlci5icm9hZGNhc3QoX2dyaWRJZCArICdLZFRhYmxlUm93VXBkYXRlZCcsIGRhdGEpO1xyXG4gICAgfVxyXG5cclxuICAgIC8vLyBVc2VkIG9uIGtkLWFuZ3VsYXItdGFibGUudHMgLSBGb3IgdXBkYXRlIHRoZSBkZWxldGUgbm9kZSBwYXJhbXMgaW4ga2QtdGFibGUtYWN0aW9uLnRzXHJcbiAgICBwdWJsaWMgb25VcGRhdGVFbWl0Um93Tm9kZXMoX2dyaWRJZDogc3RyaW5nKTogT2JzZXJ2YWJsZTxhbnk+IHtcclxuICAgICAgICByZXR1cm4gdGhpcy5fYnJvYWRjYXN0ZXIub248YW55PihfZ3JpZElkICsgJ0tkVGFibGVSb3dVcGRhdGVkJyk7XHJcbiAgICB9XHJcblxyXG4gICAgLy8vIFVzZWQgb24ga2QtdGFibGUtY2hlY2tib3gtcmFkaW8udHMgLSBDaGVja2JveCAvIHJhZGlvIGVtaXQgY2hhbmdlIGV2ZW50XHJcbiAgICBwdWJsaWMgc2VsZWN0aW9uQ2hhbmdlZChfZ3JpZElkOiBzdHJpbmcsIF9kYXRhPzogYW55KTogdm9pZCB7XHJcbiAgICAgICAgdGhpcy5fYnJvYWRjYXN0ZXIuYnJvYWRjYXN0KF9ncmlkSWQgKyAnS2RUYWJsZVVwZGF0ZU5vZGVzJywgX2RhdGEpO1xyXG4gICAgfVxyXG5cclxuICAgIC8vLyBVc2VkIG9uIGtkLXRhYmxlLWNoZWNrYm94LXJhZGlvLnRzIC0gVG8gcmVjaGVjayB0aGUgc2VsZWN0IGFsbCBjaGVja2JveFxyXG4gICAgcHVibGljIG9uU2VsZWN0aW9uQ2hhbmdlZChfZ3JpZElkOiBzdHJpbmcpOiBPYnNlcnZhYmxlPGFueT4ge1xyXG4gICAgICAgIHJldHVybiB0aGlzLl9icm9hZGNhc3Rlci5vbjxhbnk+KF9ncmlkSWQgKyAnS2RUYWJsZVVwZGF0ZU5vZGVzJyk7XHJcbiAgICB9XHJcblxyXG4gICAgLy8vIFVzZWQgb24ga2QtYW5ndWxhci10YWJsZS50cyAtIEVtaXQgb24gcm93IGRhdGEgLyBtb2RlbCBjaGFuZ2VkXHJcbiAgICBwdWJsaWMgbW9kZWxDaGFuZ2VkKF9ncmlkSWQ6IHN0cmluZywgX2RhdGE/OiBhbnkpOiB2b2lkIHtcclxuICAgICAgICB0aGlzLl9icm9hZGNhc3Rlci5icm9hZGNhc3QoX2dyaWRJZCArICdLZE1vZGVsVXBkYXRlZCcsIF9kYXRhKTtcclxuICAgIH1cclxuXHJcbiAgICAvLy8gVXNlZCBvbiBrZC10YWJsZS1jaGVja2JveC1yYWRpby50cyAtIFRvIHJlY2hlY2sgdGhlIHNlbGVjdCBhbGwgY2hlY2tib3hcclxuICAgIHB1YmxpYyBvbk1vZGVsQ2hhbmdlZChfZ3JpZElkOiBzdHJpbmcpOiBPYnNlcnZhYmxlPGFueT4ge1xyXG4gICAgICAgIHJldHVybiB0aGlzLl9icm9hZGNhc3Rlci5vbjxhbnk+KF9ncmlkSWQgKyAnS2RNb2RlbFVwZGF0ZWQnKTtcclxuICAgIH1cclxuXHJcbiAgICAvLy8gVXNlZCBvbiBrZC10YWJsZS1pbnB1dC50cyAtIEZvciBlbWl0dGluZyBhbnkgZm9ybSBjaGFuZ2VzIHRvIG91dHB1dCB0byBkeW5hbWljRm9ybVxyXG4gICAgcHVibGljIGlucHV0Q2hhbmdlZChfZ3JpZElkOiBzdHJpbmcsIF9kYXRhPzogSVRhYmxlRm9ybVBhcmFtcyk6IHZvaWQge1xyXG4gICAgICAgIHRoaXMuX2Jyb2FkY2FzdGVyLmJyb2FkY2FzdChfZ3JpZElkICsgJ0tkVGFibGVJbnB1dENoYW5nZWQnLCBfZGF0YSk7XHJcbiAgICB9XHJcblxyXG4gICAgLy8vIFVzZWQgb24ga2QtYW5ndWxhci10YWJsZS50cyAtIENhcHR1cmUgdGhlIGNoYW5nZSBwYXJhbXMgYW5kIGVtaXQgdG8gYW55b25lIHVzaW5nIHRoZSBvdXRwdXRcclxuICAgIHB1YmxpYyBvbklucHV0Q2hhbmdlZChfZ3JpZElkOiBzdHJpbmcpOiBPYnNlcnZhYmxlPElUYWJsZUZvcm1QYXJhbXM+IHtcclxuICAgICAgICByZXR1cm4gdGhpcy5fYnJvYWRjYXN0ZXIub248SVRhYmxlRm9ybVBhcmFtcz4oX2dyaWRJZCArICdLZFRhYmxlSW5wdXRDaGFuZ2VkJyk7XHJcbiAgICB9XHJcbn1cclxuIl19