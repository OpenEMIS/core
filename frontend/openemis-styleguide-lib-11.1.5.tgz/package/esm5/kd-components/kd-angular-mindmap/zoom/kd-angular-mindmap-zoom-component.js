import { __decorate, __metadata } from "tslib";
import { Component, ViewEncapsulation, Input } from '@angular/core';
var KdMindmapZoomButton = /** @class */ (function () {
    function KdMindmapZoomButton() {
        this.iconType = 'plus';
    }
    KdMindmapZoomButton.prototype.ngOnInit = function () {
        this.iconType = this.action === 'zoom_in' ? 'plus' : 'minus';
    };
    KdMindmapZoomButton.prototype.onClick = function (_event) {
        _event.stopPropagation();
        if (typeof this.internalApi !== 'undefined') {
            this.internalApi.zoom(this.action);
        }
    };
    __decorate([
        Input(),
        __metadata("design:type", Object)
    ], KdMindmapZoomButton.prototype, "config", void 0);
    __decorate([
        Input('zoomButton'),
        __metadata("design:type", String)
    ], KdMindmapZoomButton.prototype, "action", void 0);
    __decorate([
        Input('api'),
        __metadata("design:type", Object)
    ], KdMindmapZoomButton.prototype, "internalApi", void 0);
    KdMindmapZoomButton = __decorate([
        Component({
            selector: '[zoomButton]',
            template: "\n        <svg:rect\n            class=\"kdx-mindmap-zoom-button-wrapper kdx-mindmap-zoom-in\"\n            x=\"0\"\n            y=\"0\"\n            rx=\"2\"\n            ry=\"2\"\n            [attr.width]=\"config.size\"\n            [attr.height]=\"config.size\"\n        ></svg:rect>\n        <svg [attr.width]=\"config.iconSize\"\n             [attr.height]=\"config.iconSize\"\n             [attr.x]=\"config.size/2 - config.iconSize/2\"\n             [attr.y]=\"config.size/2 - config.iconSize/2\">\n            <use class=\"kdx-mindmap-zoom-button-icon\"\n                 [attr.href]=\"config.iconLinkPath + iconType\" ></use>\n        </svg>\n    ",
            encapsulation: ViewEncapsulation.None,
            host: {
                'class': 'kdx-mindmap-zoom-button',
                '(click)': 'onClick($event)',
            }
        })
    ], KdMindmapZoomButton);
    return KdMindmapZoomButton;
}());
export { KdMindmapZoomButton };
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoia2QtYW5ndWxhci1taW5kbWFwLXpvb20tY29tcG9uZW50LmpzIiwic291cmNlUm9vdCI6Im5nOi8vb3BlbmVtaXMtc3R5bGVndWlkZS1saWIvIiwic291cmNlcyI6WyJrZC1jb21wb25lbnRzL2tkLWFuZ3VsYXItbWluZG1hcC96b29tL2tkLWFuZ3VsYXItbWluZG1hcC16b29tLWNvbXBvbmVudC50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiO0FBQUEsT0FBTyxFQUNILFNBQVMsRUFDVCxpQkFBaUIsRUFDakIsS0FBSyxFQUVSLE1BQU0sZUFBZSxDQUFDO0FBOEJ2QjtJQUFBO1FBQ1csYUFBUSxHQUFXLE1BQU0sQ0FBQztJQWVyQyxDQUFDO0lBVkcsc0NBQVEsR0FBUjtRQUNJLElBQUksQ0FBQyxRQUFRLEdBQUcsSUFBSSxDQUFDLE1BQU0sS0FBSyxTQUFTLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDO0lBQ2pFLENBQUM7SUFFTSxxQ0FBTyxHQUFkLFVBQWUsTUFBYTtRQUN4QixNQUFNLENBQUMsZUFBZSxFQUFFLENBQUM7UUFDekIsSUFBSSxPQUFPLElBQUksQ0FBQyxXQUFXLEtBQUssV0FBVyxFQUFFO1lBQ3pDLElBQUksQ0FBQyxXQUFXLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQztTQUN0QztJQUNMLENBQUM7SUFiUTtRQUFSLEtBQUssRUFBRTs7dURBQTJCO0lBQ2Q7UUFBcEIsS0FBSyxDQUFDLFlBQVksQ0FBQzs7dURBQWdCO0lBQ3RCO1FBQWIsS0FBSyxDQUFDLEtBQUssQ0FBQzs7NERBQWtDO0lBSnRDLG1CQUFtQjtRQTNCL0IsU0FBUyxDQUFDO1lBQ1AsUUFBUSxFQUFFLGNBQWM7WUFDeEIsUUFBUSxFQUFFLG1wQkFpQlQ7WUFDRCxhQUFhLEVBQUUsaUJBQWlCLENBQUMsSUFBSTtZQUNyQyxJQUFJLEVBQUU7Z0JBQ0YsT0FBTyxFQUFFLHlCQUF5QjtnQkFDbEMsU0FBUyxFQUFFLGlCQUFpQjthQUMvQjtTQUNKLENBQUM7T0FFVyxtQkFBbUIsQ0FnQi9CO0lBQUQsMEJBQUM7Q0FBQSxBQWhCRCxJQWdCQztTQWhCWSxtQkFBbUIiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQge1xyXG4gICAgQ29tcG9uZW50LFxyXG4gICAgVmlld0VuY2Fwc3VsYXRpb24sXHJcbiAgICBJbnB1dCxcclxuICAgIE9uSW5pdFxyXG59IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xyXG5pbXBvcnQgeyBJWm9vbUJ1dHRvbkNvbmZpZywgSU1pbmRtYXBJbnRlcm5hbEFwaSB9IGZyb20gJy4uL2tkLWFuZ3VsYXItbWluZG1hcC1pbnRlcmZhY2UnO1xyXG5cclxuQENvbXBvbmVudCh7XHJcbiAgICBzZWxlY3RvcjogJ1t6b29tQnV0dG9uXScsXHJcbiAgICB0ZW1wbGF0ZTogYFxyXG4gICAgICAgIDxzdmc6cmVjdFxyXG4gICAgICAgICAgICBjbGFzcz1cImtkeC1taW5kbWFwLXpvb20tYnV0dG9uLXdyYXBwZXIga2R4LW1pbmRtYXAtem9vbS1pblwiXHJcbiAgICAgICAgICAgIHg9XCIwXCJcclxuICAgICAgICAgICAgeT1cIjBcIlxyXG4gICAgICAgICAgICByeD1cIjJcIlxyXG4gICAgICAgICAgICByeT1cIjJcIlxyXG4gICAgICAgICAgICBbYXR0ci53aWR0aF09XCJjb25maWcuc2l6ZVwiXHJcbiAgICAgICAgICAgIFthdHRyLmhlaWdodF09XCJjb25maWcuc2l6ZVwiXHJcbiAgICAgICAgPjwvc3ZnOnJlY3Q+XHJcbiAgICAgICAgPHN2ZyBbYXR0ci53aWR0aF09XCJjb25maWcuaWNvblNpemVcIlxyXG4gICAgICAgICAgICAgW2F0dHIuaGVpZ2h0XT1cImNvbmZpZy5pY29uU2l6ZVwiXHJcbiAgICAgICAgICAgICBbYXR0ci54XT1cImNvbmZpZy5zaXplLzIgLSBjb25maWcuaWNvblNpemUvMlwiXHJcbiAgICAgICAgICAgICBbYXR0ci55XT1cImNvbmZpZy5zaXplLzIgLSBjb25maWcuaWNvblNpemUvMlwiPlxyXG4gICAgICAgICAgICA8dXNlIGNsYXNzPVwia2R4LW1pbmRtYXAtem9vbS1idXR0b24taWNvblwiXHJcbiAgICAgICAgICAgICAgICAgW2F0dHIuaHJlZl09XCJjb25maWcuaWNvbkxpbmtQYXRoICsgaWNvblR5cGVcIiA+PC91c2U+XHJcbiAgICAgICAgPC9zdmc+XHJcbiAgICBgLFxyXG4gICAgZW5jYXBzdWxhdGlvbjogVmlld0VuY2Fwc3VsYXRpb24uTm9uZSxcclxuICAgIGhvc3Q6IHtcclxuICAgICAgICAnY2xhc3MnOiAna2R4LW1pbmRtYXAtem9vbS1idXR0b24nLFxyXG4gICAgICAgICcoY2xpY2spJzogJ29uQ2xpY2soJGV2ZW50KScsXHJcbiAgICB9XHJcbn0pXHJcblxyXG5leHBvcnQgY2xhc3MgS2RNaW5kbWFwWm9vbUJ1dHRvbiBpbXBsZW1lbnRzIE9uSW5pdCB7XHJcbiAgICBwdWJsaWMgaWNvblR5cGU6IHN0cmluZyA9ICdwbHVzJztcclxuICAgIEBJbnB1dCgpIGNvbmZpZzogSVpvb21CdXR0b25Db25maWc7XHJcbiAgICBASW5wdXQoJ3pvb21CdXR0b24nKSBhY3Rpb246IHN0cmluZztcclxuICAgIEBJbnB1dCgnYXBpJykgaW50ZXJuYWxBcGk6IElNaW5kbWFwSW50ZXJuYWxBcGk7XHJcblxyXG4gICAgbmdPbkluaXQoKTogdm9pZCB7XHJcbiAgICAgICAgdGhpcy5pY29uVHlwZSA9IHRoaXMuYWN0aW9uID09PSAnem9vbV9pbicgPyAncGx1cycgOiAnbWludXMnO1xyXG4gICAgfVxyXG5cclxuICAgIHB1YmxpYyBvbkNsaWNrKF9ldmVudDogRXZlbnQpOiB2b2lkIHtcclxuICAgICAgICBfZXZlbnQuc3RvcFByb3BhZ2F0aW9uKCk7XHJcbiAgICAgICAgaWYgKHR5cGVvZiB0aGlzLmludGVybmFsQXBpICE9PSAndW5kZWZpbmVkJykge1xyXG4gICAgICAgICAgICB0aGlzLmludGVybmFsQXBpLnpvb20odGhpcy5hY3Rpb24pO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxufVxyXG4iXX0=