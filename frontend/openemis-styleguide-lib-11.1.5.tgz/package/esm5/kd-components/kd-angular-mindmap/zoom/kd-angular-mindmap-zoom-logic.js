import * as d3 from 'd3';
var ZoomClass = /** @class */ (function () {
    function ZoomClass(svgElement, containerElement) {
        this._svg = d3.select(svgElement);
        this._container = d3.select(containerElement);
    }
    /** This class will provide methods to enable user interaction with elements
    * while maintaining the d3 simulations physics
    */
    /** A method to bind a pan and zoom behaviour to an svg element */
    ZoomClass.prototype.applyZoomableBehaviour = function () {
        var _this = this;
        var zoomed;
        zoomed = function () {
            var transform = d3.event.transform;
            _this._container.attr('transform', 'translate(' + transform.x + ',' + transform.y + ') scale(' + transform.k + ')');
        };
        this._zoomObj = d3.zoom().on('zoom', zoomed);
        this._svg.call(this._zoomObj);
    };
    ZoomClass.prototype.scaleTo = function (_scale) {
        this._zoomObj.scaleTo(this._svg, _scale);
    };
    ZoomClass.prototype.customZoom = function (_action) {
        var scaleFactor = _action === 'zoom_in' ? 1.2 : 0.8;
        this._zoomObj.scaleBy(this._svg, scaleFactor);
    };
    ZoomClass.prototype.translateSVG = function (_x, _y, _delay) {
        // let delayTime: number = _delay || 0;
        return this._svg.transition().duration(_delay).call(this._zoomObj.translateBy, _x || 0, _y || 0);
    };
    return ZoomClass;
}());
export { ZoomClass };
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoia2QtYW5ndWxhci1taW5kbWFwLXpvb20tbG9naWMuanMiLCJzb3VyY2VSb290Ijoibmc6Ly9vcGVuZW1pcy1zdHlsZWd1aWRlLWxpYi8iLCJzb3VyY2VzIjpbImtkLWNvbXBvbmVudHMva2QtYW5ndWxhci1taW5kbWFwL3pvb20va2QtYW5ndWxhci1taW5kbWFwLXpvb20tbG9naWMudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQ0EsT0FBTyxLQUFLLEVBQUUsTUFBTSxJQUFJLENBQUM7QUFFekI7SUFLSSxtQkFBWSxVQUFzQixFQUFFLGdCQUE2QjtRQUM3RCxJQUFJLENBQUMsSUFBSSxHQUFHLEVBQUUsQ0FBQyxNQUFNLENBQUMsVUFBVSxDQUFDLENBQUM7UUFDbEMsSUFBSSxDQUFDLFVBQVUsR0FBRyxFQUFFLENBQUMsTUFBTSxDQUFDLGdCQUFnQixDQUFDLENBQUM7SUFDbEQsQ0FBQztJQUVEOztNQUVFO0lBQ0Ysa0VBQWtFO0lBQzNELDBDQUFzQixHQUE3QjtRQUFBLGlCQVVDO1FBVEcsSUFBSSxNQUFnQixDQUFDO1FBRXJCLE1BQU0sR0FBRztZQUNMLElBQU0sU0FBUyxHQUFHLEVBQUUsQ0FBQyxLQUFLLENBQUMsU0FBUyxDQUFDO1lBQ3JDLEtBQUksQ0FBQyxVQUFVLENBQUMsSUFBSSxDQUFDLFdBQVcsRUFBRSxZQUFZLEdBQUcsU0FBUyxDQUFDLENBQUMsR0FBRyxHQUFHLEdBQUcsU0FBUyxDQUFDLENBQUMsR0FBRyxVQUFVLEdBQUcsU0FBUyxDQUFDLENBQUMsR0FBRyxHQUFHLENBQUMsQ0FBQztRQUN2SCxDQUFDLENBQUM7UUFFRixJQUFJLENBQUMsUUFBUSxHQUFHLEVBQUUsQ0FBQyxJQUFJLEVBQUUsQ0FBQyxFQUFFLENBQUMsTUFBTSxFQUFFLE1BQU0sQ0FBQyxDQUFDO1FBQzdDLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsQ0FBQztJQUNsQyxDQUFDO0lBRU0sMkJBQU8sR0FBZCxVQUFlLE1BQWM7UUFDekIsSUFBSSxDQUFDLFFBQVEsQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLElBQUksRUFBRSxNQUFNLENBQUMsQ0FBQztJQUM3QyxDQUFDO0lBRU0sOEJBQVUsR0FBakIsVUFBa0IsT0FBZTtRQUM3QixJQUFJLFdBQVcsR0FBVyxPQUFPLEtBQUssU0FBUyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQztRQUM1RCxJQUFJLENBQUMsUUFBUSxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsSUFBSSxFQUFFLFdBQVcsQ0FBQyxDQUFDO0lBQ2xELENBQUM7SUFFTSxnQ0FBWSxHQUFuQixVQUFvQixFQUFVLEVBQUUsRUFBVyxFQUFFLE1BQWU7UUFDeEQsdUNBQXVDO1FBQ3ZDLE9BQU8sSUFBSSxDQUFDLElBQUksQ0FBQyxVQUFVLEVBQUUsQ0FBQyxRQUFRLENBQUMsTUFBTSxDQUFDLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsV0FBVyxFQUFFLEVBQUUsSUFBSSxDQUFDLEVBQUUsRUFBRSxJQUFJLENBQUMsQ0FBQyxDQUFDO0lBQ3JHLENBQUM7SUFDTCxnQkFBQztBQUFELENBQUMsQUF2Q0QsSUF1Q0MiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBFbGVtZW50UmVmIH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XHJcbmltcG9ydCAqIGFzIGQzIGZyb20gJ2QzJztcclxuXHJcbmV4cG9ydCBjbGFzcyBab29tQ2xhc3Mge1xyXG4gICAgcHJpdmF0ZSBfc3ZnOiBhbnk7XHJcbiAgICBwcml2YXRlIF9jb250YWluZXI6IGFueTtcclxuICAgIHByaXZhdGUgX3pvb21PYmo7XHJcblxyXG4gICAgY29uc3RydWN0b3Ioc3ZnRWxlbWVudDogRWxlbWVudFJlZiwgY29udGFpbmVyRWxlbWVudDogSFRNTEVsZW1lbnQpIHtcclxuICAgICAgICB0aGlzLl9zdmcgPSBkMy5zZWxlY3Qoc3ZnRWxlbWVudCk7XHJcbiAgICAgICAgdGhpcy5fY29udGFpbmVyID0gZDMuc2VsZWN0KGNvbnRhaW5lckVsZW1lbnQpO1xyXG4gICAgfVxyXG5cclxuICAgIC8qKiBUaGlzIGNsYXNzIHdpbGwgcHJvdmlkZSBtZXRob2RzIHRvIGVuYWJsZSB1c2VyIGludGVyYWN0aW9uIHdpdGggZWxlbWVudHNcclxuICAgICogd2hpbGUgbWFpbnRhaW5pbmcgdGhlIGQzIHNpbXVsYXRpb25zIHBoeXNpY3NcclxuICAgICovXHJcbiAgICAvKiogQSBtZXRob2QgdG8gYmluZCBhIHBhbiBhbmQgem9vbSBiZWhhdmlvdXIgdG8gYW4gc3ZnIGVsZW1lbnQgKi9cclxuICAgIHB1YmxpYyBhcHBseVpvb21hYmxlQmVoYXZpb3VyKCk6IHZvaWQge1xyXG4gICAgICAgIGxldCB6b29tZWQ6IEZ1bmN0aW9uO1xyXG5cclxuICAgICAgICB6b29tZWQgPSAoKSA9PiB7XHJcbiAgICAgICAgICAgIGNvbnN0IHRyYW5zZm9ybSA9IGQzLmV2ZW50LnRyYW5zZm9ybTtcclxuICAgICAgICAgICAgdGhpcy5fY29udGFpbmVyLmF0dHIoJ3RyYW5zZm9ybScsICd0cmFuc2xhdGUoJyArIHRyYW5zZm9ybS54ICsgJywnICsgdHJhbnNmb3JtLnkgKyAnKSBzY2FsZSgnICsgdHJhbnNmb3JtLmsgKyAnKScpO1xyXG4gICAgICAgIH07XHJcblxyXG4gICAgICAgIHRoaXMuX3pvb21PYmogPSBkMy56b29tKCkub24oJ3pvb20nLCB6b29tZWQpO1xyXG4gICAgICAgIHRoaXMuX3N2Zy5jYWxsKHRoaXMuX3pvb21PYmopO1xyXG4gICAgfVxyXG5cclxuICAgIHB1YmxpYyBzY2FsZVRvKF9zY2FsZTogbnVtYmVyKTogdm9pZCB7XHJcbiAgICAgICAgdGhpcy5fem9vbU9iai5zY2FsZVRvKHRoaXMuX3N2ZywgX3NjYWxlKTtcclxuICAgIH1cclxuXHJcbiAgICBwdWJsaWMgY3VzdG9tWm9vbShfYWN0aW9uOiBzdHJpbmcpOiB2b2lkIHtcclxuICAgICAgICBsZXQgc2NhbGVGYWN0b3I6IG51bWJlciA9IF9hY3Rpb24gPT09ICd6b29tX2luJyA/IDEuMiA6IDAuODtcclxuICAgICAgICB0aGlzLl96b29tT2JqLnNjYWxlQnkodGhpcy5fc3ZnLCBzY2FsZUZhY3Rvcik7XHJcbiAgICB9XHJcblxyXG4gICAgcHVibGljIHRyYW5zbGF0ZVNWRyhfeDogbnVtYmVyLCBfeT86IG51bWJlciwgX2RlbGF5PzogbnVtYmVyKTogYW55IHtcclxuICAgICAgICAvLyBsZXQgZGVsYXlUaW1lOiBudW1iZXIgPSBfZGVsYXkgfHwgMDtcclxuICAgICAgICByZXR1cm4gdGhpcy5fc3ZnLnRyYW5zaXRpb24oKS5kdXJhdGlvbihfZGVsYXkpLmNhbGwodGhpcy5fem9vbU9iai50cmFuc2xhdGVCeSwgX3ggfHwgMCwgX3kgfHwgMCk7XHJcbiAgICB9XHJcbn1cclxuIl19