import { __decorate, __metadata } from "tslib";
import { Directive, Input, ElementRef, OnInit } from '@angular/core';
import { KdMindmapSvc } from './kd-angular-mindmap-svc';
import { ForceDirectedGraph } from './kd-angular-mindmap-force-logic';
var KdMindmapZoomDirective = /** @class */ (function () {
    function KdMindmapZoomDirective(_mindmapSvc, _element) {
        this._mindmapSvc = _mindmapSvc;
        this._element = _element;
    }
    KdMindmapZoomDirective.prototype.ngOnInit = function () {
        this._zoomClass = this._mindmapSvc.getZoomClass(this.zoomableOf, this._element.nativeElement);
        this._zoomClass.applyZoomableBehaviour();
        this._initApi();
    };
    KdMindmapZoomDirective.prototype._initApi = function () {
        var _this = this;
        if (typeof this.internalApi !== 'undefined') {
            this.internalApi.zoom = function (_action) { return _this._zoomClass.customZoom(_action); };
            this.internalApi.scaleTo = function (_scale) { return _this._zoomClass.scaleTo(_scale); };
            this.internalApi.translate = function (_x, _y) { return _this._zoomClass.translateSVG(_x, _y); };
        }
    };
    KdMindmapZoomDirective.ctorParameters = function () { return [
        { type: KdMindmapSvc },
        { type: ElementRef }
    ]; };
    __decorate([
        Input('zoomableOf'),
        __metadata("design:type", ElementRef)
    ], KdMindmapZoomDirective.prototype, "zoomableOf", void 0);
    __decorate([
        Input('api'),
        __metadata("design:type", Object)
    ], KdMindmapZoomDirective.prototype, "internalApi", void 0);
    KdMindmapZoomDirective = __decorate([
        Directive({
            selector: '[zoomableOf]',
        }),
        __metadata("design:paramtypes", [KdMindmapSvc, ElementRef])
    ], KdMindmapZoomDirective);
    return KdMindmapZoomDirective;
}());
export { KdMindmapZoomDirective };
var KdMindmapDragDirective = /** @class */ (function () {
    function KdMindmapDragDirective(_mindmapSvc, _element) {
        this._mindmapSvc = _mindmapSvc;
        this._element = _element;
    }
    KdMindmapDragDirective.prototype.ngOnInit = function () {
        this._mindmapSvc.applyDraggableBehaviour(this._element.nativeElement, this.draggableNode, this.draggableInGraph);
    };
    KdMindmapDragDirective.ctorParameters = function () { return [
        { type: KdMindmapSvc },
        { type: ElementRef }
    ]; };
    __decorate([
        Input('draggableNode'),
        __metadata("design:type", Object)
    ], KdMindmapDragDirective.prototype, "draggableNode", void 0);
    __decorate([
        Input('draggableInGraph'),
        __metadata("design:type", ForceDirectedGraph)
    ], KdMindmapDragDirective.prototype, "draggableInGraph", void 0);
    KdMindmapDragDirective = __decorate([
        Directive({
            selector: '[draggableNode]'
        }),
        __metadata("design:paramtypes", [KdMindmapSvc, ElementRef])
    ], KdMindmapDragDirective);
    return KdMindmapDragDirective;
}());
export { KdMindmapDragDirective };
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoia2QtYW5ndWxhci1taW5kbWFwLWRpcmVjdGl2ZXMuanMiLCJzb3VyY2VSb290Ijoibmc6Ly9vcGVuZW1pcy1zdHlsZWd1aWRlLWxpYi8iLCJzb3VyY2VzIjpbImtkLWNvbXBvbmVudHMva2QtYW5ndWxhci1taW5kbWFwL2tkLWFuZ3VsYXItbWluZG1hcC1kaXJlY3RpdmVzLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7QUFBQSxPQUFPLEVBQUUsU0FBUyxFQUFFLEtBQUssRUFBRSxVQUFVLEVBQUUsTUFBTSxFQUFFLE1BQU0sZUFBZSxDQUFDO0FBQ3JFLE9BQU8sRUFBRSxZQUFZLEVBQUUsTUFBTSwwQkFBMEIsQ0FBQztBQUN4RCxPQUFPLEVBQUUsa0JBQWtCLEVBQUUsTUFBTSxrQ0FBa0MsQ0FBQztBQU90RTtJQU1JLGdDQUFvQixXQUF5QixFQUFVLFFBQW9CO1FBQXZELGdCQUFXLEdBQVgsV0FBVyxDQUFjO1FBQVUsYUFBUSxHQUFSLFFBQVEsQ0FBWTtJQUFJLENBQUM7SUFFaEYseUNBQVEsR0FBUjtRQUNJLElBQUksQ0FBQyxVQUFVLEdBQUcsSUFBSSxDQUFDLFdBQVcsQ0FBQyxZQUFZLENBQUMsSUFBSSxDQUFDLFVBQVUsRUFBRSxJQUFJLENBQUMsUUFBUSxDQUFDLGFBQWEsQ0FBQyxDQUFDO1FBQzlGLElBQUksQ0FBQyxVQUFVLENBQUMsc0JBQXNCLEVBQUUsQ0FBQztRQUN6QyxJQUFJLENBQUMsUUFBUSxFQUFFLENBQUM7SUFDcEIsQ0FBQztJQUVPLHlDQUFRLEdBQWhCO1FBQUEsaUJBTUM7UUFMRyxJQUFJLE9BQU8sSUFBSSxDQUFDLFdBQVcsS0FBSyxXQUFXLEVBQUU7WUFDekMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxJQUFJLEdBQUcsVUFBQyxPQUFlLElBQVcsT0FBQSxLQUFJLENBQUMsVUFBVSxDQUFDLFVBQVUsQ0FBQyxPQUFPLENBQUMsRUFBbkMsQ0FBbUMsQ0FBQztZQUN2RixJQUFJLENBQUMsV0FBVyxDQUFDLE9BQU8sR0FBRyxVQUFDLE1BQWMsSUFBVyxPQUFBLEtBQUksQ0FBQyxVQUFVLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxFQUEvQixDQUErQixDQUFDO1lBQ3JGLElBQUksQ0FBQyxXQUFXLENBQUMsU0FBUyxHQUFHLFVBQUMsRUFBVSxFQUFFLEVBQVcsSUFBVSxPQUFBLEtBQUksQ0FBQyxVQUFVLENBQUMsWUFBWSxDQUFDLEVBQUUsRUFBRSxFQUFFLENBQUMsRUFBcEMsQ0FBb0MsQ0FBQztTQUN2RztJQUNMLENBQUM7O2dCQWRnQyxZQUFZO2dCQUFvQixVQUFVOztJQUh0RDtRQUFwQixLQUFLLENBQUMsWUFBWSxDQUFDO2tDQUFhLFVBQVU7OERBQUM7SUFDOUI7UUFBYixLQUFLLENBQUMsS0FBSyxDQUFDOzsrREFBa0M7SUFKdEMsc0JBQXNCO1FBSGxDLFNBQVMsQ0FBQztZQUNQLFFBQVEsRUFBRSxjQUFjO1NBQzNCLENBQUM7eUNBT21DLFlBQVksRUFBb0IsVUFBVTtPQU5sRSxzQkFBc0IsQ0FxQmxDO0lBQUQsNkJBQUM7Q0FBQSxBQXJCRCxJQXFCQztTQXJCWSxzQkFBc0I7QUEyQm5DO0lBSUksZ0NBQW9CLFdBQXlCLEVBQVUsUUFBb0I7UUFBdkQsZ0JBQVcsR0FBWCxXQUFXLENBQWM7UUFBVSxhQUFRLEdBQVIsUUFBUSxDQUFZO0lBQUksQ0FBQztJQUVoRix5Q0FBUSxHQUFSO1FBQ0ksSUFBSSxDQUFDLFdBQVcsQ0FBQyx1QkFBdUIsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLGFBQWEsRUFBRSxJQUFJLENBQUMsYUFBYSxFQUFFLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDO0lBQ3JILENBQUM7O2dCQUpnQyxZQUFZO2dCQUFvQixVQUFVOztJQUhuRDtRQUF2QixLQUFLLENBQUMsZUFBZSxDQUFDOztpRUFBNkI7SUFDekI7UUFBMUIsS0FBSyxDQUFDLGtCQUFrQixDQUFDO2tDQUFtQixrQkFBa0I7b0VBQUM7SUFGdkQsc0JBQXNCO1FBSGxDLFNBQVMsQ0FBQztZQUNQLFFBQVEsRUFBRSxpQkFBaUI7U0FDOUIsQ0FBQzt5Q0FLbUMsWUFBWSxFQUFvQixVQUFVO09BSmxFLHNCQUFzQixDQVNsQztJQUFELDZCQUFDO0NBQUEsQUFURCxJQVNDO1NBVFksc0JBQXNCIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgRGlyZWN0aXZlLCBJbnB1dCwgRWxlbWVudFJlZiwgT25Jbml0IH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XHJcbmltcG9ydCB7IEtkTWluZG1hcFN2YyB9IGZyb20gJy4va2QtYW5ndWxhci1taW5kbWFwLXN2Yyc7XHJcbmltcG9ydCB7IEZvcmNlRGlyZWN0ZWRHcmFwaCB9IGZyb20gJy4va2QtYW5ndWxhci1taW5kbWFwLWZvcmNlLWxvZ2ljJztcclxuaW1wb3J0IHsgWm9vbUNsYXNzIH0gZnJvbSAnLi96b29tL2tkLWFuZ3VsYXItbWluZG1hcC16b29tLWxvZ2ljJztcclxuaW1wb3J0IHsgSU1pbmRtYXBOb2RlLCBJTWluZG1hcEludGVybmFsQXBpIH0gZnJvbSAnLi9rZC1hbmd1bGFyLW1pbmRtYXAtaW50ZXJmYWNlJztcclxuXHJcbkBEaXJlY3RpdmUoe1xyXG4gICAgc2VsZWN0b3I6ICdbem9vbWFibGVPZl0nLFxyXG59KVxyXG5leHBvcnQgY2xhc3MgS2RNaW5kbWFwWm9vbURpcmVjdGl2ZSBpbXBsZW1lbnRzIE9uSW5pdCB7XHJcbiAgICBwcml2YXRlIF96b29tQ2xhc3M6IFpvb21DbGFzcztcclxuXHJcbiAgICBASW5wdXQoJ3pvb21hYmxlT2YnKSB6b29tYWJsZU9mOiBFbGVtZW50UmVmO1xyXG4gICAgQElucHV0KCdhcGknKSBpbnRlcm5hbEFwaTogSU1pbmRtYXBJbnRlcm5hbEFwaTtcclxuXHJcbiAgICBjb25zdHJ1Y3Rvcihwcml2YXRlIF9taW5kbWFwU3ZjOiBLZE1pbmRtYXBTdmMsIHByaXZhdGUgX2VsZW1lbnQ6IEVsZW1lbnRSZWYpIHsgfVxyXG5cclxuICAgIG5nT25Jbml0KCkge1xyXG4gICAgICAgIHRoaXMuX3pvb21DbGFzcyA9IHRoaXMuX21pbmRtYXBTdmMuZ2V0Wm9vbUNsYXNzKHRoaXMuem9vbWFibGVPZiwgdGhpcy5fZWxlbWVudC5uYXRpdmVFbGVtZW50KTtcclxuICAgICAgICB0aGlzLl96b29tQ2xhc3MuYXBwbHlab29tYWJsZUJlaGF2aW91cigpO1xyXG4gICAgICAgIHRoaXMuX2luaXRBcGkoKTtcclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF9pbml0QXBpKCk6IHZvaWQge1xyXG4gICAgICAgIGlmICh0eXBlb2YgdGhpcy5pbnRlcm5hbEFwaSAhPT0gJ3VuZGVmaW5lZCcpIHtcclxuICAgICAgICAgICAgdGhpcy5pbnRlcm5hbEFwaS56b29tID0gKF9hY3Rpb246IHN0cmluZyk6IHZvaWQgPT4gdGhpcy5fem9vbUNsYXNzLmN1c3RvbVpvb20oX2FjdGlvbik7XHJcbiAgICAgICAgICAgIHRoaXMuaW50ZXJuYWxBcGkuc2NhbGVUbyA9IChfc2NhbGU6IG51bWJlcik6IHZvaWQgPT4gdGhpcy5fem9vbUNsYXNzLnNjYWxlVG8oX3NjYWxlKTtcclxuICAgICAgICAgICAgdGhpcy5pbnRlcm5hbEFwaS50cmFuc2xhdGUgPSAoX3g6IG51bWJlciwgX3k/OiBudW1iZXIpOiBhbnkgPT4gdGhpcy5fem9vbUNsYXNzLnRyYW5zbGF0ZVNWRyhfeCwgX3kpO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxufVxyXG5cclxuXHJcbkBEaXJlY3RpdmUoe1xyXG4gICAgc2VsZWN0b3I6ICdbZHJhZ2dhYmxlTm9kZV0nXHJcbn0pXHJcbmV4cG9ydCBjbGFzcyBLZE1pbmRtYXBEcmFnRGlyZWN0aXZlIGltcGxlbWVudHMgT25Jbml0IHtcclxuICAgIEBJbnB1dCgnZHJhZ2dhYmxlTm9kZScpIGRyYWdnYWJsZU5vZGU6IElNaW5kbWFwTm9kZTtcclxuICAgIEBJbnB1dCgnZHJhZ2dhYmxlSW5HcmFwaCcpIGRyYWdnYWJsZUluR3JhcGg6IEZvcmNlRGlyZWN0ZWRHcmFwaDtcclxuXHJcbiAgICBjb25zdHJ1Y3Rvcihwcml2YXRlIF9taW5kbWFwU3ZjOiBLZE1pbmRtYXBTdmMsIHByaXZhdGUgX2VsZW1lbnQ6IEVsZW1lbnRSZWYpIHsgfVxyXG5cclxuICAgIG5nT25Jbml0KCkge1xyXG4gICAgICAgIHRoaXMuX21pbmRtYXBTdmMuYXBwbHlEcmFnZ2FibGVCZWhhdmlvdXIodGhpcy5fZWxlbWVudC5uYXRpdmVFbGVtZW50LCB0aGlzLmRyYWdnYWJsZU5vZGUsIHRoaXMuZHJhZ2dhYmxlSW5HcmFwaCk7XHJcbiAgICB9XHJcbn1cclxuIl19