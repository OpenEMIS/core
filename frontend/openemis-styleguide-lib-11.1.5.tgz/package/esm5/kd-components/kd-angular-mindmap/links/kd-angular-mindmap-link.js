import { __decorate, __metadata } from "tslib";
import { Component, Input, ViewEncapsulation, OnInit, OnChanges, SimpleChanges, OnDestroy, ElementRef, } from '@angular/core';
import { KdDomElemSvc } from '../../kd-common/index';
import { KdMindmapEvent } from '../kd-angular-mindmap-event';
var KdMindmapLink = /** @class */ (function () {
    function KdMindmapLink(_mindmapEvent, _domSvc, _elemRef) {
        this._mindmapEvent = _mindmapEvent;
        this._domSvc = _domSvc;
        this._elemRef = _elemRef;
        this.offset = 0;
        this._linkActive = false;
    }
    KdMindmapLink.prototype.ngOnInit = function () {
        var _this = this;
        this._initApi();
        this._setConfig(this.allConfig);
        this._nodeSelectedSub = this._mindmapEvent
            .onNodeSelected(this.mindmapId)
            .subscribe(function (_node) { return _this._linkActiveSwitch(_node); });
    };
    KdMindmapLink.prototype.ngOnChanges = function (_simpleChanges) {
        if (_simpleChanges.hasOwnProperty('allConfig') && !_simpleChanges['allConfig'].firstChange) {
            this._setConfig(this.allConfig);
        }
    };
    KdMindmapLink.prototype.ngOnDestroy = function () {
        this._nodeSelectedSub.unsubscribe();
    };
    KdMindmapLink.prototype._initApi = function () {
        var _this = this;
        if (typeof this.internalLinkApiRef !== 'undefined') {
            this.internalLinkApiRef[this.link.index] = {};
            this.internalLinkApiRef[this.link.index].setLinkOffset = function (_offset) { _this.offset = _offset || 0; };
        }
    };
    KdMindmapLink.prototype._linkActiveSwitch = function (_node) {
        if (this.link.target.index !== _node.index && this.link.source.index !== _node.index) {
            if (this._linkActive) {
                this._domSvc.removeClass(this._elemRef.nativeElement, this.config.link.activeClass);
                if (this.config.link.type)
                    this._setMarkerType(this.config.link.type, 'url(#arrowStart)', 'url(#arrowEnd)');
                this._linkActive = false;
            }
        }
        else {
            if (!this._linkActive) {
                this._domSvc.addClass(this._elemRef.nativeElement, this.config.link.activeClass);
                if (this.config.link.type)
                    this._setMarkerType(this.config.link.type, 'url(#arrowStartActive)', 'url(#arrowEndActive)');
                this._linkActive = true;
            }
        }
    };
    KdMindmapLink.prototype._setConfig = function (_config) {
        this.config = Object.assign({}, _config);
        this.config.link = Object.assign({}, _config.link);
        this._setMarker();
        if (this.config.link.class)
            this._domSvc.addClass(this._elemRef.nativeElement, this.config.link.class);
    };
    /**
     * [_setMarker is setting whether the arrow heads should appear]
     */
    KdMindmapLink.prototype._setMarker = function () {
        if (this.link.type)
            this.config.link.type = this.link.type;
        if (!this.config.link.type)
            return;
        this._setMarkerType(this.config.link.type, 'url(#arrowStart)', 'url(#arrowEnd)');
    };
    KdMindmapLink.prototype._setMarkerType = function (_configType, _urlStart, _urlEnd) {
        if (_configType === 'direction' || _configType === 'two-direction') {
            this._domSvc.setAttribute(this._elemRef.nativeElement.querySelector('.kdx-mindmap-link-line'), 'marker-end', _urlEnd);
        }
        if (_configType === 'two-direction') {
            this._domSvc.setAttribute(this._elemRef.nativeElement.querySelector('.kdx-mindmap-link-line'), 'marker-start', _urlStart);
        }
    };
    KdMindmapLink.ctorParameters = function () { return [
        { type: KdMindmapEvent },
        { type: KdDomElemSvc },
        { type: ElementRef }
    ]; };
    __decorate([
        Input(),
        __metadata("design:type", String)
    ], KdMindmapLink.prototype, "mindmapId", void 0);
    __decorate([
        Input('kdx-mindmap-link'),
        __metadata("design:type", Object)
    ], KdMindmapLink.prototype, "link", void 0);
    __decorate([
        Input('config'),
        __metadata("design:type", Object)
    ], KdMindmapLink.prototype, "allConfig", void 0);
    __decorate([
        Input('api'),
        __metadata("design:type", Object)
    ], KdMindmapLink.prototype, "internalLinkApiRef", void 0);
    KdMindmapLink = __decorate([
        Component({
            selector: '[kdx-mindmap-link]',
            template: "\n        <svg:line\n            class=\"kdx-mindmap-link-line\"\n            [attr.aria-source]=\"link.source.title\"\n            [attr.aria-target]=\"link.target.title\"\n            [attr.x1]=\"link.source.x + config.node.width/2\"\n            [attr.y1]=\"link.source.y\"\n            [attr.x2]=\"link.target.x - config.node.width/2\"\n            [attr.y2]=\"link.target.y + offset\"\n            [attr.stroke-dasharray]=\"config.link.dash || link.dash? config.link.dashArray : []\"\n        ></svg:line>\n    ",
            encapsulation: ViewEncapsulation.None,
            providers: [KdMindmapEvent, KdDomElemSvc],
            host: {
                'class': 'kdx-mindmap-link'
            }
        }),
        __metadata("design:paramtypes", [KdMindmapEvent,
            KdDomElemSvc,
            ElementRef])
    ], KdMindmapLink);
    return KdMindmapLink;
}());
export { KdMindmapLink };
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoia2QtYW5ndWxhci1taW5kbWFwLWxpbmsuanMiLCJzb3VyY2VSb290Ijoibmc6Ly9vcGVuZW1pcy1zdHlsZWd1aWRlLWxpYi8iLCJzb3VyY2VzIjpbImtkLWNvbXBvbmVudHMva2QtYW5ndWxhci1taW5kbWFwL2xpbmtzL2tkLWFuZ3VsYXItbWluZG1hcC1saW5rLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7QUFBQSxPQUFPLEVBQ0gsU0FBUyxFQUNULEtBQUssRUFDTCxpQkFBaUIsRUFDakIsTUFBTSxFQUNOLFNBQVMsRUFDVCxhQUFhLEVBQ2IsU0FBUyxFQUNULFVBQVUsR0FDYixNQUFNLGVBQWUsQ0FBQztBQUV2QixPQUFPLEVBQUUsWUFBWSxFQUFFLE1BQU0sdUJBQXVCLENBQUM7QUFDckQsT0FBTyxFQUFFLGNBQWMsRUFBRSxNQUFNLDZCQUE2QixDQUFDO0FBMkI3RDtJQVdJLHVCQUNZLGFBQTZCLEVBQzdCLE9BQXFCLEVBQ3JCLFFBQW9CO1FBRnBCLGtCQUFhLEdBQWIsYUFBYSxDQUFnQjtRQUM3QixZQUFPLEdBQVAsT0FBTyxDQUFjO1FBQ3JCLGFBQVEsR0FBUixRQUFRLENBQVk7UUFaekIsV0FBTSxHQUFXLENBQUMsQ0FBQztRQUVsQixnQkFBVyxHQUFZLEtBQUssQ0FBQztJQVdqQyxDQUFDO0lBRUwsZ0NBQVEsR0FBUjtRQUFBLGlCQU1DO1FBTEcsSUFBSSxDQUFDLFFBQVEsRUFBRSxDQUFDO1FBQ2hCLElBQUksQ0FBQyxVQUFVLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDO1FBQ2hDLElBQUksQ0FBQyxnQkFBZ0IsR0FBRyxJQUFJLENBQUMsYUFBYTthQUNyQyxjQUFjLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQzthQUM5QixTQUFTLENBQUMsVUFBQyxLQUFtQixJQUFXLE9BQUEsS0FBSSxDQUFDLGlCQUFpQixDQUFDLEtBQUssQ0FBQyxFQUE3QixDQUE2QixDQUFDLENBQUM7SUFDakYsQ0FBQztJQUVELG1DQUFXLEdBQVgsVUFBWSxjQUE2QjtRQUNyQyxJQUFJLGNBQWMsQ0FBQyxjQUFjLENBQUMsV0FBVyxDQUFDLElBQUksQ0FBQyxjQUFjLENBQUMsV0FBVyxDQUFDLENBQUMsV0FBVyxFQUFFO1lBQ3hGLElBQUksQ0FBQyxVQUFVLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDO1NBQ25DO0lBQ0wsQ0FBQztJQUVELG1DQUFXLEdBQVg7UUFDSSxJQUFJLENBQUMsZ0JBQWdCLENBQUMsV0FBVyxFQUFFLENBQUM7SUFDeEMsQ0FBQztJQUVPLGdDQUFRLEdBQWhCO1FBQUEsaUJBS0M7UUFKRyxJQUFJLE9BQU8sSUFBSSxDQUFDLGtCQUFrQixLQUFLLFdBQVcsRUFBRTtZQUNoRCxJQUFJLENBQUMsa0JBQWtCLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsR0FBRyxFQUFFLENBQUM7WUFDOUMsSUFBSSxDQUFDLGtCQUFrQixDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLENBQUMsYUFBYSxHQUFHLFVBQUMsT0FBZSxJQUFhLEtBQUksQ0FBQyxNQUFNLEdBQUcsT0FBTyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztTQUN2SDtJQUNMLENBQUM7SUFFTyx5Q0FBaUIsR0FBekIsVUFBMEIsS0FBbUI7UUFDekMsSUFBSSxJQUFJLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxLQUFLLEtBQUssS0FBSyxDQUFDLEtBQUssSUFBSSxJQUFJLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxLQUFLLEtBQUssS0FBSyxDQUFDLEtBQUssRUFBRTtZQUNsRixJQUFJLElBQUksQ0FBQyxXQUFXLEVBQUU7Z0JBQ2xCLElBQUksQ0FBQyxPQUFPLENBQUMsV0FBVyxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsYUFBYSxFQUFFLElBQUksQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxDQUFDO2dCQUNwRixJQUFJLElBQUksQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLElBQUk7b0JBQUUsSUFBSSxDQUFDLGNBQWMsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxJQUFJLEVBQUUsa0JBQWtCLEVBQUUsZ0JBQWdCLENBQUMsQ0FBQztnQkFDNUcsSUFBSSxDQUFDLFdBQVcsR0FBRyxLQUFLLENBQUM7YUFDNUI7U0FDSjthQUFNO1lBQ0gsSUFBSSxDQUFDLElBQUksQ0FBQyxXQUFXLEVBQUU7Z0JBQ25CLElBQUksQ0FBQyxPQUFPLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsYUFBYSxFQUFFLElBQUksQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxDQUFDO2dCQUNqRixJQUFJLElBQUksQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLElBQUk7b0JBQUUsSUFBSSxDQUFDLGNBQWMsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxJQUFJLEVBQUUsd0JBQXdCLEVBQUUsc0JBQXNCLENBQUMsQ0FBQztnQkFDeEgsSUFBSSxDQUFDLFdBQVcsR0FBRyxJQUFJLENBQUM7YUFDM0I7U0FDSjtJQUNMLENBQUM7SUFFTyxrQ0FBVSxHQUFsQixVQUFtQixPQUFPO1FBQ3RCLElBQUksQ0FBQyxNQUFNLEdBQUcsTUFBTSxDQUFDLE1BQU0sQ0FBQyxFQUFFLEVBQUUsT0FBTyxDQUFDLENBQUM7UUFDekMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxJQUFJLEdBQUcsTUFBTSxDQUFDLE1BQU0sQ0FBQyxFQUFFLEVBQUUsT0FBTyxDQUFDLElBQUksQ0FBQyxDQUFDO1FBQ25ELElBQUksQ0FBQyxVQUFVLEVBQUUsQ0FBQztRQUNsQixJQUFJLElBQUksQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLEtBQUs7WUFBRSxJQUFJLENBQUMsT0FBTyxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLGFBQWEsRUFBRSxJQUFJLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQztJQUMzRyxDQUFDO0lBRUQ7O09BRUc7SUFDSyxrQ0FBVSxHQUFsQjtRQUNJLElBQUksSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJO1lBQUUsSUFBSSxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsSUFBSSxHQUFHLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDO1FBQzNELElBQUksQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxJQUFJO1lBQUUsT0FBTztRQUNuQyxJQUFJLENBQUMsY0FBYyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLElBQUksRUFBRSxrQkFBa0IsRUFBRSxnQkFBZ0IsQ0FBQyxDQUFDO0lBQ3JGLENBQUM7SUFFTyxzQ0FBYyxHQUF0QixVQUF1QixXQUFtQixFQUFFLFNBQWlCLEVBQUUsT0FBZTtRQUMxRSxJQUFJLFdBQVcsS0FBSyxXQUFXLElBQUksV0FBVyxLQUFLLGVBQWUsRUFBRTtZQUNoRSxJQUFJLENBQUMsT0FBTyxDQUFDLFlBQVksQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLGFBQWEsQ0FBQyxhQUFhLENBQUMsd0JBQXdCLENBQUMsRUFBRSxZQUFZLEVBQUUsT0FBTyxDQUFDLENBQUM7U0FDekg7UUFDRCxJQUFJLFdBQVcsS0FBSyxlQUFlLEVBQUU7WUFDakMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxZQUFZLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxhQUFhLENBQUMsYUFBYSxDQUFDLHdCQUF3QixDQUFDLEVBQUUsY0FBYyxFQUFFLFNBQVMsQ0FBQyxDQUFDO1NBQzdIO0lBQ0wsQ0FBQzs7Z0JBckUwQixjQUFjO2dCQUNwQixZQUFZO2dCQUNYLFVBQVU7O0lBUnZCO1FBQVIsS0FBSyxFQUFFOztvREFBbUI7SUFDQTtRQUExQixLQUFLLENBQUMsa0JBQWtCLENBQUM7OytDQUFXO0lBQ3BCO1FBQWhCLEtBQUssQ0FBQyxRQUFRLENBQUM7O29EQUErQjtJQUNqQztRQUFiLEtBQUssQ0FBQyxLQUFLLENBQUM7OzZEQUFnRDtJQVRwRCxhQUFhO1FBcEJ6QixTQUFTLENBQUM7WUFDUCxRQUFRLEVBQUUsb0JBQW9CO1lBQzlCLFFBQVEsRUFBRSxzZ0JBV1Q7WUFDRCxhQUFhLEVBQUUsaUJBQWlCLENBQUMsSUFBSTtZQUNyQyxTQUFTLEVBQUUsQ0FBQyxjQUFjLEVBQUUsWUFBWSxDQUFDO1lBQ3pDLElBQUksRUFBRTtnQkFDRixPQUFPLEVBQUUsa0JBQWtCO2FBQzlCO1NBQ0osQ0FBQzt5Q0FhNkIsY0FBYztZQUNwQixZQUFZO1lBQ1gsVUFBVTtPQWR2QixhQUFhLENBa0Z6QjtJQUFELG9CQUFDO0NBQUEsQUFsRkQsSUFrRkM7U0FsRlksYUFBYSIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7XHJcbiAgICBDb21wb25lbnQsXHJcbiAgICBJbnB1dCxcclxuICAgIFZpZXdFbmNhcHN1bGF0aW9uLFxyXG4gICAgT25Jbml0LFxyXG4gICAgT25DaGFuZ2VzLFxyXG4gICAgU2ltcGxlQ2hhbmdlcyxcclxuICAgIE9uRGVzdHJveSxcclxuICAgIEVsZW1lbnRSZWYsXHJcbn0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XHJcbmltcG9ydCB7IFN1YnNjcmlwdGlvbiB9IGZyb20gJ3J4anMnO1xyXG5pbXBvcnQgeyBLZERvbUVsZW1TdmMgfSBmcm9tICcuLi8uLi9rZC1jb21tb24vaW5kZXgnO1xyXG5pbXBvcnQgeyBLZE1pbmRtYXBFdmVudCB9IGZyb20gJy4uL2tkLWFuZ3VsYXItbWluZG1hcC1ldmVudCc7XHJcbmltcG9ydCB7IFxyXG4gICAgSU1pbmRtYXBOb2RlLCBcclxuICAgIElJbnRlcm5hbEFsbENvbmZpZywgXHJcbiAgICBJTWluZG1hcEludGVybmFsTGlua0FwaVJlZiBcclxufSBmcm9tICcuLi9rZC1hbmd1bGFyLW1pbmRtYXAtaW50ZXJmYWNlJztcclxuXHJcbkBDb21wb25lbnQoe1xyXG4gICAgc2VsZWN0b3I6ICdba2R4LW1pbmRtYXAtbGlua10nLFxyXG4gICAgdGVtcGxhdGU6IGBcclxuICAgICAgICA8c3ZnOmxpbmVcclxuICAgICAgICAgICAgY2xhc3M9XCJrZHgtbWluZG1hcC1saW5rLWxpbmVcIlxyXG4gICAgICAgICAgICBbYXR0ci5hcmlhLXNvdXJjZV09XCJsaW5rLnNvdXJjZS50aXRsZVwiXHJcbiAgICAgICAgICAgIFthdHRyLmFyaWEtdGFyZ2V0XT1cImxpbmsudGFyZ2V0LnRpdGxlXCJcclxuICAgICAgICAgICAgW2F0dHIueDFdPVwibGluay5zb3VyY2UueCArIGNvbmZpZy5ub2RlLndpZHRoLzJcIlxyXG4gICAgICAgICAgICBbYXR0ci55MV09XCJsaW5rLnNvdXJjZS55XCJcclxuICAgICAgICAgICAgW2F0dHIueDJdPVwibGluay50YXJnZXQueCAtIGNvbmZpZy5ub2RlLndpZHRoLzJcIlxyXG4gICAgICAgICAgICBbYXR0ci55Ml09XCJsaW5rLnRhcmdldC55ICsgb2Zmc2V0XCJcclxuICAgICAgICAgICAgW2F0dHIuc3Ryb2tlLWRhc2hhcnJheV09XCJjb25maWcubGluay5kYXNoIHx8IGxpbmsuZGFzaD8gY29uZmlnLmxpbmsuZGFzaEFycmF5IDogW11cIlxyXG4gICAgICAgID48L3N2ZzpsaW5lPlxyXG4gICAgYCxcclxuICAgIGVuY2Fwc3VsYXRpb246IFZpZXdFbmNhcHN1bGF0aW9uLk5vbmUsXHJcbiAgICBwcm92aWRlcnM6IFtLZE1pbmRtYXBFdmVudCwgS2REb21FbGVtU3ZjXSxcclxuICAgIGhvc3Q6IHtcclxuICAgICAgICAnY2xhc3MnOiAna2R4LW1pbmRtYXAtbGluaydcclxuICAgIH1cclxufSlcclxuZXhwb3J0IGNsYXNzIEtkTWluZG1hcExpbmsgaW1wbGVtZW50cyBPbkluaXQsIE9uQ2hhbmdlcywgT25EZXN0cm95IHtcclxuICAgIHB1YmxpYyBjb25maWc6IElJbnRlcm5hbEFsbENvbmZpZztcclxuICAgIHB1YmxpYyBvZmZzZXQ6IG51bWJlciA9IDA7XHJcbiAgICBwcml2YXRlIF9ub2RlU2VsZWN0ZWRTdWI6IFN1YnNjcmlwdGlvbjtcclxuICAgIHByaXZhdGUgX2xpbmtBY3RpdmU6IGJvb2xlYW4gPSBmYWxzZTtcclxuXHJcbiAgICBASW5wdXQoKSBtaW5kbWFwSWQ6IHN0cmluZztcclxuICAgIEBJbnB1dCgna2R4LW1pbmRtYXAtbGluaycpIGxpbms6IGFueTtcclxuICAgIEBJbnB1dCgnY29uZmlnJykgYWxsQ29uZmlnOiBJSW50ZXJuYWxBbGxDb25maWc7XHJcbiAgICBASW5wdXQoJ2FwaScpIGludGVybmFsTGlua0FwaVJlZjogSU1pbmRtYXBJbnRlcm5hbExpbmtBcGlSZWY7XHJcblxyXG4gICAgY29uc3RydWN0b3IoXHJcbiAgICAgICAgcHJpdmF0ZSBfbWluZG1hcEV2ZW50OiBLZE1pbmRtYXBFdmVudCxcclxuICAgICAgICBwcml2YXRlIF9kb21TdmM6IEtkRG9tRWxlbVN2YyxcclxuICAgICAgICBwcml2YXRlIF9lbGVtUmVmOiBFbGVtZW50UmVmXHJcbiAgICApIHsgfVxyXG5cclxuICAgIG5nT25Jbml0KCk6IHZvaWQge1xyXG4gICAgICAgIHRoaXMuX2luaXRBcGkoKTtcclxuICAgICAgICB0aGlzLl9zZXRDb25maWcodGhpcy5hbGxDb25maWcpO1xyXG4gICAgICAgIHRoaXMuX25vZGVTZWxlY3RlZFN1YiA9IHRoaXMuX21pbmRtYXBFdmVudFxyXG4gICAgICAgICAgICAub25Ob2RlU2VsZWN0ZWQodGhpcy5taW5kbWFwSWQpXHJcbiAgICAgICAgICAgIC5zdWJzY3JpYmUoKF9ub2RlOiBJTWluZG1hcE5vZGUpOiB2b2lkID0+IHRoaXMuX2xpbmtBY3RpdmVTd2l0Y2goX25vZGUpKTtcclxuICAgIH1cclxuXHJcbiAgICBuZ09uQ2hhbmdlcyhfc2ltcGxlQ2hhbmdlczogU2ltcGxlQ2hhbmdlcyk6IHZvaWQge1xyXG4gICAgICAgIGlmIChfc2ltcGxlQ2hhbmdlcy5oYXNPd25Qcm9wZXJ0eSgnYWxsQ29uZmlnJykgJiYgIV9zaW1wbGVDaGFuZ2VzWydhbGxDb25maWcnXS5maXJzdENoYW5nZSkge1xyXG4gICAgICAgICAgICB0aGlzLl9zZXRDb25maWcodGhpcy5hbGxDb25maWcpO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICBuZ09uRGVzdHJveSgpOiB2b2lkIHtcclxuICAgICAgICB0aGlzLl9ub2RlU2VsZWN0ZWRTdWIudW5zdWJzY3JpYmUoKTtcclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF9pbml0QXBpKCk6IHZvaWQge1xyXG4gICAgICAgIGlmICh0eXBlb2YgdGhpcy5pbnRlcm5hbExpbmtBcGlSZWYgIT09ICd1bmRlZmluZWQnKSB7XHJcbiAgICAgICAgICAgIHRoaXMuaW50ZXJuYWxMaW5rQXBpUmVmW3RoaXMubGluay5pbmRleF0gPSB7fTtcclxuICAgICAgICAgICAgdGhpcy5pbnRlcm5hbExpbmtBcGlSZWZbdGhpcy5saW5rLmluZGV4XS5zZXRMaW5rT2Zmc2V0ID0gKF9vZmZzZXQ6IG51bWJlcik6IHZvaWQgPT4geyB0aGlzLm9mZnNldCA9IF9vZmZzZXQgfHwgMDsgfTtcclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfbGlua0FjdGl2ZVN3aXRjaChfbm9kZTogSU1pbmRtYXBOb2RlKTogdm9pZCB7XHJcbiAgICAgICAgaWYgKHRoaXMubGluay50YXJnZXQuaW5kZXggIT09IF9ub2RlLmluZGV4ICYmIHRoaXMubGluay5zb3VyY2UuaW5kZXggIT09IF9ub2RlLmluZGV4KSB7XHJcbiAgICAgICAgICAgIGlmICh0aGlzLl9saW5rQWN0aXZlKSB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLl9kb21TdmMucmVtb3ZlQ2xhc3ModGhpcy5fZWxlbVJlZi5uYXRpdmVFbGVtZW50LCB0aGlzLmNvbmZpZy5saW5rLmFjdGl2ZUNsYXNzKTtcclxuICAgICAgICAgICAgICAgIGlmICh0aGlzLmNvbmZpZy5saW5rLnR5cGUpIHRoaXMuX3NldE1hcmtlclR5cGUodGhpcy5jb25maWcubGluay50eXBlLCAndXJsKCNhcnJvd1N0YXJ0KScsICd1cmwoI2Fycm93RW5kKScpO1xyXG4gICAgICAgICAgICAgICAgdGhpcy5fbGlua0FjdGl2ZSA9IGZhbHNlO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgaWYgKCF0aGlzLl9saW5rQWN0aXZlKSB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLl9kb21TdmMuYWRkQ2xhc3ModGhpcy5fZWxlbVJlZi5uYXRpdmVFbGVtZW50LCB0aGlzLmNvbmZpZy5saW5rLmFjdGl2ZUNsYXNzKTtcclxuICAgICAgICAgICAgICAgIGlmICh0aGlzLmNvbmZpZy5saW5rLnR5cGUpIHRoaXMuX3NldE1hcmtlclR5cGUodGhpcy5jb25maWcubGluay50eXBlLCAndXJsKCNhcnJvd1N0YXJ0QWN0aXZlKScsICd1cmwoI2Fycm93RW5kQWN0aXZlKScpO1xyXG4gICAgICAgICAgICAgICAgdGhpcy5fbGlua0FjdGl2ZSA9IHRydWU7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfc2V0Q29uZmlnKF9jb25maWcpOiB2b2lkIHtcclxuICAgICAgICB0aGlzLmNvbmZpZyA9IE9iamVjdC5hc3NpZ24oe30sIF9jb25maWcpO1xyXG4gICAgICAgIHRoaXMuY29uZmlnLmxpbmsgPSBPYmplY3QuYXNzaWduKHt9LCBfY29uZmlnLmxpbmspO1xyXG4gICAgICAgIHRoaXMuX3NldE1hcmtlcigpO1xyXG4gICAgICAgIGlmICh0aGlzLmNvbmZpZy5saW5rLmNsYXNzKSB0aGlzLl9kb21TdmMuYWRkQ2xhc3ModGhpcy5fZWxlbVJlZi5uYXRpdmVFbGVtZW50LCB0aGlzLmNvbmZpZy5saW5rLmNsYXNzKTtcclxuICAgIH1cclxuXHJcbiAgICAvKipcclxuICAgICAqIFtfc2V0TWFya2VyIGlzIHNldHRpbmcgd2hldGhlciB0aGUgYXJyb3cgaGVhZHMgc2hvdWxkIGFwcGVhcl1cclxuICAgICAqL1xyXG4gICAgcHJpdmF0ZSBfc2V0TWFya2VyKCk6IHZvaWQge1xyXG4gICAgICAgIGlmICh0aGlzLmxpbmsudHlwZSkgdGhpcy5jb25maWcubGluay50eXBlID0gdGhpcy5saW5rLnR5cGU7XHJcbiAgICAgICAgaWYgKCF0aGlzLmNvbmZpZy5saW5rLnR5cGUpIHJldHVybjtcclxuICAgICAgICB0aGlzLl9zZXRNYXJrZXJUeXBlKHRoaXMuY29uZmlnLmxpbmsudHlwZSwgJ3VybCgjYXJyb3dTdGFydCknLCAndXJsKCNhcnJvd0VuZCknKTtcclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF9zZXRNYXJrZXJUeXBlKF9jb25maWdUeXBlOiBzdHJpbmcsIF91cmxTdGFydDogc3RyaW5nLCBfdXJsRW5kOiBzdHJpbmcpOiB2b2lkIHtcclxuICAgICAgICBpZiAoX2NvbmZpZ1R5cGUgPT09ICdkaXJlY3Rpb24nIHx8IF9jb25maWdUeXBlID09PSAndHdvLWRpcmVjdGlvbicpIHtcclxuICAgICAgICAgICAgdGhpcy5fZG9tU3ZjLnNldEF0dHJpYnV0ZSh0aGlzLl9lbGVtUmVmLm5hdGl2ZUVsZW1lbnQucXVlcnlTZWxlY3RvcignLmtkeC1taW5kbWFwLWxpbmstbGluZScpLCAnbWFya2VyLWVuZCcsIF91cmxFbmQpO1xyXG4gICAgICAgIH1cclxuICAgICAgICBpZiAoX2NvbmZpZ1R5cGUgPT09ICd0d28tZGlyZWN0aW9uJykge1xyXG4gICAgICAgICAgICB0aGlzLl9kb21TdmMuc2V0QXR0cmlidXRlKHRoaXMuX2VsZW1SZWYubmF0aXZlRWxlbWVudC5xdWVyeVNlbGVjdG9yKCcua2R4LW1pbmRtYXAtbGluay1saW5lJyksICdtYXJrZXItc3RhcnQnLCBfdXJsU3RhcnQpO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxufVxyXG4iXX0=