import { __decorate, __metadata } from "tslib";
import { Injectable } from '@angular/core';
import { KdBroadcaster, } from '../kd-common/index';
import * as i0 from "@angular/core";
import * as i1 from "../kd-common/kd-broadcaster-svc";
var KdMindmapEvent = /** @class */ (function () {
    function KdMindmapEvent(_broadcaster) {
        this._broadcaster = _broadcaster;
    }
    KdMindmapEvent.prototype.nodeSelected = function (_mindmapId, _selectedNode) {
        this._broadcaster.broadcast(_mindmapId + 'kdMindmapNodeClicked', _selectedNode);
    };
    KdMindmapEvent.prototype.onNodeSelected = function (_mindmapId) {
        return this._broadcaster.on(_mindmapId + 'kdMindmapNodeClicked');
    };
    KdMindmapEvent.ctorParameters = function () { return [
        { type: KdBroadcaster }
    ]; };
    KdMindmapEvent.ɵprov = i0.ɵɵdefineInjectable({ factory: function KdMindmapEvent_Factory() { return new KdMindmapEvent(i0.ɵɵinject(i1.KdBroadcaster)); }, token: KdMindmapEvent, providedIn: "root" });
    KdMindmapEvent = __decorate([
        Injectable({
            providedIn: 'root'
        }),
        __metadata("design:paramtypes", [KdBroadcaster])
    ], KdMindmapEvent);
    return KdMindmapEvent;
}());
export { KdMindmapEvent };
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoia2QtYW5ndWxhci1taW5kbWFwLWV2ZW50LmpzIiwic291cmNlUm9vdCI6Im5nOi8vb3BlbmVtaXMtc3R5bGVndWlkZS1saWIvIiwic291cmNlcyI6WyJrZC1jb21wb25lbnRzL2tkLWFuZ3VsYXItbWluZG1hcC9rZC1hbmd1bGFyLW1pbmRtYXAtZXZlbnQudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IjtBQUFBLE9BQU8sRUFBRSxVQUFVLEVBQUUsTUFBTSxlQUFlLENBQUM7QUFHM0MsT0FBTyxFQUFFLGFBQWEsR0FBRyxNQUFNLG9CQUFvQixDQUFDOzs7QUFLcEQ7SUFFSSx3QkFBb0IsWUFBMkI7UUFBM0IsaUJBQVksR0FBWixZQUFZLENBQWU7SUFBSSxDQUFDO0lBRTdDLHFDQUFZLEdBQW5CLFVBQW9CLFVBQWtCLEVBQUUsYUFBNEI7UUFDaEUsSUFBSSxDQUFDLFlBQVksQ0FBQyxTQUFTLENBQUMsVUFBVSxHQUFHLHNCQUFzQixFQUFFLGFBQWEsQ0FBQyxDQUFDO0lBQ3BGLENBQUM7SUFFTSx1Q0FBYyxHQUFyQixVQUFzQixVQUFrQjtRQUNwQyxPQUFPLElBQUksQ0FBQyxZQUFZLENBQUMsRUFBRSxDQUFNLFVBQVUsR0FBRyxzQkFBc0IsQ0FBQyxDQUFDO0lBQzFFLENBQUM7O2dCQVJpQyxhQUFhOzs7SUFGdEMsY0FBYztRQUgxQixVQUFVLENBQUM7WUFDUixVQUFVLEVBQUUsTUFBTTtTQUNyQixDQUFDO3lDQUdvQyxhQUFhO09BRnRDLGNBQWMsQ0FXMUI7eUJBbkJEO0NBbUJDLEFBWEQsSUFXQztTQVhZLGNBQWMiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBJbmplY3RhYmxlIH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XHJcbmltcG9ydCB7IE9ic2VydmFibGUgfSBmcm9tICdyeGpzJztcclxuaW1wb3J0IHsgSU1pbmRtYXBOb2RlIH0gZnJvbSAnLi9rZC1hbmd1bGFyLW1pbmRtYXAtaW50ZXJmYWNlJztcclxuaW1wb3J0IHsgS2RCcm9hZGNhc3RlciwgfSBmcm9tICcuLi9rZC1jb21tb24vaW5kZXgnO1xyXG5cclxuQEluamVjdGFibGUoe1xyXG4gICAgcHJvdmlkZWRJbjogJ3Jvb3QnXHJcbn0pXHJcbmV4cG9ydCBjbGFzcyBLZE1pbmRtYXBFdmVudCB7XHJcblxyXG4gICAgY29uc3RydWN0b3IocHJpdmF0ZSBfYnJvYWRjYXN0ZXI6IEtkQnJvYWRjYXN0ZXIpIHsgfVxyXG5cclxuICAgIHB1YmxpYyBub2RlU2VsZWN0ZWQoX21pbmRtYXBJZDogc3RyaW5nLCBfc2VsZWN0ZWROb2RlPzogSU1pbmRtYXBOb2RlKTogdm9pZCB7XHJcbiAgICAgICAgdGhpcy5fYnJvYWRjYXN0ZXIuYnJvYWRjYXN0KF9taW5kbWFwSWQgKyAna2RNaW5kbWFwTm9kZUNsaWNrZWQnLCBfc2VsZWN0ZWROb2RlKTtcclxuICAgIH1cclxuXHJcbiAgICBwdWJsaWMgb25Ob2RlU2VsZWN0ZWQoX21pbmRtYXBJZDogc3RyaW5nKTogT2JzZXJ2YWJsZTxhbnk+IHtcclxuICAgICAgICByZXR1cm4gdGhpcy5fYnJvYWRjYXN0ZXIub248YW55PihfbWluZG1hcElkICsgJ2tkTWluZG1hcE5vZGVDbGlja2VkJyk7XHJcbiAgICB9XHJcbn1cclxuXHJcbiJdfQ==