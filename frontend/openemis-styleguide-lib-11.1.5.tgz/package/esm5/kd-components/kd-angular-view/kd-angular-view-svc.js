import { __decorate } from "tslib";
import { Injectable } from '@angular/core';
import { KdInputCheckbox, KdInputDate, 
// KdInputDisabled,
KdInputDropdown, KdInputFileinput, KdInputFloat, KdInputHidden, KdInputInteger, KdInputPassword, KdInputRadio, KdInputText, KdInputTextarea, KdInputTime, 
// KdInputReadOnly,
KdInputTreeDropdown, KdInputSlider, KdInputMultiSelectTable, KdInputSection, KdInputSymbol, KdInputTable, KdInputButtonGroup } from '../kd-angular-input/src/kd-input-extensions';
var KdViewSvc = /** @class */ (function () {
    function KdViewSvc() {
    }
    KdViewSvc.prototype.convertDataType = function (_inputData, _convertSvc) {
        var updateDfQuestion = [];
        if (typeof _inputData !== 'undefined') {
            for (var i = 0; i < _inputData.length; i++) {
                var newItem = _convertSvc.createNewObject(_inputData[i]);
                updateDfQuestion.push(this._convertItem(newItem));
            }
        }
        // else{
        //     console.log('KdViewSvc > convertDataType() > ', _inputData);
        // }
        return updateDfQuestion;
    };
    KdViewSvc.prototype._convertItem = function (_item) {
        switch (_item.controlType) {
            case 'integer':
                return new KdInputInteger(_item);
            case 'decimal':
                return new KdInputFloat(_item);
            case 'date':
                return new KdInputDate(_item);
            case 'time':
                return new KdInputTime(_item);
            case 'password':
                return new KdInputPassword(_item);
            case 'textarea':
                return new KdInputTextarea(_item);
            case 'hidden':
                return new KdInputHidden(_item);
            // case 'disabled':
            //     return new KdInputDisabled(_item);
            // case 'readonly':
            //     return new KdInputReadOnly(_item);
            case 'file-input':
                return new KdInputFileinput(_item);
            case 'dropdown':
                return new KdInputDropdown(_item);
            case 'radio':
                return new KdInputRadio(_item);
            case 'checkbox':
                return new KdInputCheckbox(_item);
            case 'tree':
                return new KdInputTreeDropdown(_item);
            case 'slider':
                return new KdInputSlider(_item);
            case 'multi-table':
                return new KdInputMultiSelectTable(_item);
            case 'section':
                return new KdInputSection(_item);
            case 'symbol':
                return new KdInputSymbol(_item);
            case 'table':
                return new KdInputTable(_item);
            case 'button-group':
                return new KdInputButtonGroup(_item);
            default:
                return new KdInputText(_item);
        }
    };
    KdViewSvc = __decorate([
        Injectable()
    ], KdViewSvc);
    return KdViewSvc;
}());
export { KdViewSvc };
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoia2QtYW5ndWxhci12aWV3LXN2Yy5qcyIsInNvdXJjZVJvb3QiOiJuZzovL29wZW5lbWlzLXN0eWxlZ3VpZGUtbGliLyIsInNvdXJjZXMiOlsia2QtY29tcG9uZW50cy9rZC1hbmd1bGFyLXZpZXcva2QtYW5ndWxhci12aWV3LXN2Yy50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiO0FBQUEsT0FBTyxFQUFFLFVBQVUsRUFBRSxNQUFNLGVBQWUsQ0FBQztBQUUzQyxPQUFPLEVBQ0gsZUFBZSxFQUNmLFdBQVc7QUFDWCxtQkFBbUI7QUFDbkIsZUFBZSxFQUNmLGdCQUFnQixFQUNoQixZQUFZLEVBQ1osYUFBYSxFQUNiLGNBQWMsRUFDZCxlQUFlLEVBQ2YsWUFBWSxFQUNaLFdBQVcsRUFDWCxlQUFlLEVBQ2YsV0FBVztBQUNYLG1CQUFtQjtBQUNuQixtQkFBbUIsRUFDbkIsYUFBYSxFQUNiLHVCQUF1QixFQUN2QixjQUFjLEVBQ2QsYUFBYSxFQUNiLFlBQVksRUFDWixrQkFBa0IsRUFDckIsTUFBTSw2Q0FBNkMsQ0FBQztBQUdyRDtJQUFBO0lBOERBLENBQUM7SUE3REcsbUNBQWUsR0FBZixVQUFnQixVQUFzQixFQUFFLFdBQTRCO1FBQ2hFLElBQUksZ0JBQWdCLEdBQWUsRUFBRSxDQUFDO1FBQ3RDLElBQUksT0FBTyxVQUFVLEtBQUssV0FBVyxFQUFFO1lBQ25DLEtBQUssSUFBSSxDQUFDLEdBQVcsQ0FBQyxFQUFFLENBQUMsR0FBRyxVQUFVLENBQUMsTUFBTSxFQUFFLENBQUMsRUFBRSxFQUFFO2dCQUNoRCxJQUFJLE9BQU8sR0FBUSxXQUFXLENBQUMsZUFBZSxDQUFDLFVBQVUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO2dCQUM5RCxnQkFBZ0IsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLFlBQVksQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDO2FBQ3JEO1NBQ0o7UUFDRCxRQUFRO1FBQ1IsbUVBQW1FO1FBQ25FLElBQUk7UUFFSixPQUFPLGdCQUFnQixDQUFDO0lBQzVCLENBQUM7SUFFTyxnQ0FBWSxHQUFwQixVQUFxQixLQUFVO1FBQzNCLFFBQVEsS0FBSyxDQUFDLFdBQVcsRUFBRTtZQUN2QixLQUFLLFNBQVM7Z0JBQ1YsT0FBTyxJQUFJLGNBQWMsQ0FBQyxLQUFLLENBQUMsQ0FBQztZQUNyQyxLQUFLLFNBQVM7Z0JBQ1YsT0FBTyxJQUFJLFlBQVksQ0FBQyxLQUFLLENBQUMsQ0FBQztZQUNuQyxLQUFLLE1BQU07Z0JBQ1AsT0FBTyxJQUFJLFdBQVcsQ0FBQyxLQUFLLENBQUMsQ0FBQztZQUNsQyxLQUFLLE1BQU07Z0JBQ1AsT0FBTyxJQUFJLFdBQVcsQ0FBQyxLQUFLLENBQUMsQ0FBQztZQUNsQyxLQUFLLFVBQVU7Z0JBQ1gsT0FBTyxJQUFJLGVBQWUsQ0FBQyxLQUFLLENBQUMsQ0FBQztZQUN0QyxLQUFLLFVBQVU7Z0JBQ1gsT0FBTyxJQUFJLGVBQWUsQ0FBQyxLQUFLLENBQUMsQ0FBQztZQUN0QyxLQUFLLFFBQVE7Z0JBQ1QsT0FBTyxJQUFJLGFBQWEsQ0FBQyxLQUFLLENBQUMsQ0FBQztZQUNwQyxtQkFBbUI7WUFDbkIseUNBQXlDO1lBQ3pDLG1CQUFtQjtZQUNuQix5Q0FBeUM7WUFDekMsS0FBSyxZQUFZO2dCQUNiLE9BQU8sSUFBSSxnQkFBZ0IsQ0FBQyxLQUFLLENBQUMsQ0FBQztZQUN2QyxLQUFLLFVBQVU7Z0JBQ1gsT0FBTyxJQUFJLGVBQWUsQ0FBQyxLQUFLLENBQUMsQ0FBQztZQUN0QyxLQUFLLE9BQU87Z0JBQ1IsT0FBTyxJQUFJLFlBQVksQ0FBQyxLQUFLLENBQUMsQ0FBQztZQUNuQyxLQUFLLFVBQVU7Z0JBQ1gsT0FBTyxJQUFJLGVBQWUsQ0FBQyxLQUFLLENBQUMsQ0FBQztZQUN0QyxLQUFLLE1BQU07Z0JBQ1AsT0FBTyxJQUFJLG1CQUFtQixDQUFDLEtBQUssQ0FBQyxDQUFDO1lBQzFDLEtBQUssUUFBUTtnQkFDVCxPQUFPLElBQUksYUFBYSxDQUFDLEtBQUssQ0FBQyxDQUFDO1lBQ3BDLEtBQUssYUFBYTtnQkFDZCxPQUFPLElBQUksdUJBQXVCLENBQUMsS0FBSyxDQUFDLENBQUM7WUFDOUMsS0FBSyxTQUFTO2dCQUNWLE9BQU8sSUFBSSxjQUFjLENBQUMsS0FBSyxDQUFDLENBQUM7WUFDckMsS0FBSyxRQUFRO2dCQUNULE9BQU8sSUFBSSxhQUFhLENBQUMsS0FBSyxDQUFDLENBQUM7WUFDcEMsS0FBSyxPQUFPO2dCQUNSLE9BQU8sSUFBSSxZQUFZLENBQUMsS0FBSyxDQUFDLENBQUM7WUFDbkMsS0FBSyxjQUFjO2dCQUNmLE9BQU8sSUFBSSxrQkFBa0IsQ0FBQyxLQUFLLENBQUMsQ0FBQztZQUN6QztnQkFDSSxPQUFPLElBQUksV0FBVyxDQUFDLEtBQUssQ0FBQyxDQUFDO1NBQ3JDO0lBQ0wsQ0FBQztJQTdEUSxTQUFTO1FBRHJCLFVBQVUsRUFBRTtPQUNBLFNBQVMsQ0E4RHJCO0lBQUQsZ0JBQUM7Q0FBQSxBQTlERCxJQThEQztTQTlEWSxTQUFTIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgSW5qZWN0YWJsZSB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xyXG5pbXBvcnQgeyBLZENvbnZlcnRpb25TdmMgfSBmcm9tICcuLi9rZC1jb21tb24nO1xyXG5pbXBvcnQge1xyXG4gICAgS2RJbnB1dENoZWNrYm94LFxyXG4gICAgS2RJbnB1dERhdGUsXHJcbiAgICAvLyBLZElucHV0RGlzYWJsZWQsXHJcbiAgICBLZElucHV0RHJvcGRvd24sXHJcbiAgICBLZElucHV0RmlsZWlucHV0LFxyXG4gICAgS2RJbnB1dEZsb2F0LFxyXG4gICAgS2RJbnB1dEhpZGRlbixcclxuICAgIEtkSW5wdXRJbnRlZ2VyLFxyXG4gICAgS2RJbnB1dFBhc3N3b3JkLFxyXG4gICAgS2RJbnB1dFJhZGlvLFxyXG4gICAgS2RJbnB1dFRleHQsXHJcbiAgICBLZElucHV0VGV4dGFyZWEsXHJcbiAgICBLZElucHV0VGltZSxcclxuICAgIC8vIEtkSW5wdXRSZWFkT25seSxcclxuICAgIEtkSW5wdXRUcmVlRHJvcGRvd24sXHJcbiAgICBLZElucHV0U2xpZGVyLFxyXG4gICAgS2RJbnB1dE11bHRpU2VsZWN0VGFibGUsXHJcbiAgICBLZElucHV0U2VjdGlvbixcclxuICAgIEtkSW5wdXRTeW1ib2wsXHJcbiAgICBLZElucHV0VGFibGUsXHJcbiAgICBLZElucHV0QnV0dG9uR3JvdXBcclxufSBmcm9tICcuLi9rZC1hbmd1bGFyLWlucHV0L3NyYy9rZC1pbnB1dC1leHRlbnNpb25zJztcclxuXHJcbkBJbmplY3RhYmxlKClcclxuZXhwb3J0IGNsYXNzIEtkVmlld1N2YyB7XHJcbiAgICBjb252ZXJ0RGF0YVR5cGUoX2lucHV0RGF0YTogQXJyYXk8YW55PiwgX2NvbnZlcnRTdmM6IEtkQ29udmVydGlvblN2Yyk6IEFycmF5PGFueT4ge1xyXG4gICAgICAgIGxldCB1cGRhdGVEZlF1ZXN0aW9uOiBBcnJheTxhbnk+ID0gW107XHJcbiAgICAgICAgaWYgKHR5cGVvZiBfaW5wdXREYXRhICE9PSAndW5kZWZpbmVkJykge1xyXG4gICAgICAgICAgICBmb3IgKGxldCBpOiBudW1iZXIgPSAwOyBpIDwgX2lucHV0RGF0YS5sZW5ndGg7IGkrKykge1xyXG4gICAgICAgICAgICAgICAgbGV0IG5ld0l0ZW06IGFueSA9IF9jb252ZXJ0U3ZjLmNyZWF0ZU5ld09iamVjdChfaW5wdXREYXRhW2ldKTtcclxuICAgICAgICAgICAgICAgIHVwZGF0ZURmUXVlc3Rpb24ucHVzaCh0aGlzLl9jb252ZXJ0SXRlbShuZXdJdGVtKSk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICAgICAgLy8gZWxzZXtcclxuICAgICAgICAvLyAgICAgY29uc29sZS5sb2coJ0tkVmlld1N2YyA+IGNvbnZlcnREYXRhVHlwZSgpID4gJywgX2lucHV0RGF0YSk7XHJcbiAgICAgICAgLy8gfVxyXG5cclxuICAgICAgICByZXR1cm4gdXBkYXRlRGZRdWVzdGlvbjtcclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF9jb252ZXJ0SXRlbShfaXRlbTogYW55KTogYW55IHtcclxuICAgICAgICBzd2l0Y2ggKF9pdGVtLmNvbnRyb2xUeXBlKSB7XHJcbiAgICAgICAgICAgIGNhc2UgJ2ludGVnZXInOlxyXG4gICAgICAgICAgICAgICAgcmV0dXJuIG5ldyBLZElucHV0SW50ZWdlcihfaXRlbSk7XHJcbiAgICAgICAgICAgIGNhc2UgJ2RlY2ltYWwnOlxyXG4gICAgICAgICAgICAgICAgcmV0dXJuIG5ldyBLZElucHV0RmxvYXQoX2l0ZW0pO1xyXG4gICAgICAgICAgICBjYXNlICdkYXRlJzpcclxuICAgICAgICAgICAgICAgIHJldHVybiBuZXcgS2RJbnB1dERhdGUoX2l0ZW0pO1xyXG4gICAgICAgICAgICBjYXNlICd0aW1lJzpcclxuICAgICAgICAgICAgICAgIHJldHVybiBuZXcgS2RJbnB1dFRpbWUoX2l0ZW0pO1xyXG4gICAgICAgICAgICBjYXNlICdwYXNzd29yZCc6XHJcbiAgICAgICAgICAgICAgICByZXR1cm4gbmV3IEtkSW5wdXRQYXNzd29yZChfaXRlbSk7XHJcbiAgICAgICAgICAgIGNhc2UgJ3RleHRhcmVhJzpcclxuICAgICAgICAgICAgICAgIHJldHVybiBuZXcgS2RJbnB1dFRleHRhcmVhKF9pdGVtKTtcclxuICAgICAgICAgICAgY2FzZSAnaGlkZGVuJzpcclxuICAgICAgICAgICAgICAgIHJldHVybiBuZXcgS2RJbnB1dEhpZGRlbihfaXRlbSk7XHJcbiAgICAgICAgICAgIC8vIGNhc2UgJ2Rpc2FibGVkJzpcclxuICAgICAgICAgICAgLy8gICAgIHJldHVybiBuZXcgS2RJbnB1dERpc2FibGVkKF9pdGVtKTtcclxuICAgICAgICAgICAgLy8gY2FzZSAncmVhZG9ubHknOlxyXG4gICAgICAgICAgICAvLyAgICAgcmV0dXJuIG5ldyBLZElucHV0UmVhZE9ubHkoX2l0ZW0pO1xyXG4gICAgICAgICAgICBjYXNlICdmaWxlLWlucHV0JzpcclxuICAgICAgICAgICAgICAgIHJldHVybiBuZXcgS2RJbnB1dEZpbGVpbnB1dChfaXRlbSk7XHJcbiAgICAgICAgICAgIGNhc2UgJ2Ryb3Bkb3duJzpcclxuICAgICAgICAgICAgICAgIHJldHVybiBuZXcgS2RJbnB1dERyb3Bkb3duKF9pdGVtKTtcclxuICAgICAgICAgICAgY2FzZSAncmFkaW8nOlxyXG4gICAgICAgICAgICAgICAgcmV0dXJuIG5ldyBLZElucHV0UmFkaW8oX2l0ZW0pO1xyXG4gICAgICAgICAgICBjYXNlICdjaGVja2JveCc6XHJcbiAgICAgICAgICAgICAgICByZXR1cm4gbmV3IEtkSW5wdXRDaGVja2JveChfaXRlbSk7XHJcbiAgICAgICAgICAgIGNhc2UgJ3RyZWUnOlxyXG4gICAgICAgICAgICAgICAgcmV0dXJuIG5ldyBLZElucHV0VHJlZURyb3Bkb3duKF9pdGVtKTtcclxuICAgICAgICAgICAgY2FzZSAnc2xpZGVyJzpcclxuICAgICAgICAgICAgICAgIHJldHVybiBuZXcgS2RJbnB1dFNsaWRlcihfaXRlbSk7XHJcbiAgICAgICAgICAgIGNhc2UgJ211bHRpLXRhYmxlJzpcclxuICAgICAgICAgICAgICAgIHJldHVybiBuZXcgS2RJbnB1dE11bHRpU2VsZWN0VGFibGUoX2l0ZW0pO1xyXG4gICAgICAgICAgICBjYXNlICdzZWN0aW9uJzpcclxuICAgICAgICAgICAgICAgIHJldHVybiBuZXcgS2RJbnB1dFNlY3Rpb24oX2l0ZW0pO1xyXG4gICAgICAgICAgICBjYXNlICdzeW1ib2wnOlxyXG4gICAgICAgICAgICAgICAgcmV0dXJuIG5ldyBLZElucHV0U3ltYm9sKF9pdGVtKTtcclxuICAgICAgICAgICAgY2FzZSAndGFibGUnOlxyXG4gICAgICAgICAgICAgICAgcmV0dXJuIG5ldyBLZElucHV0VGFibGUoX2l0ZW0pO1xyXG4gICAgICAgICAgICBjYXNlICdidXR0b24tZ3JvdXAnOlxyXG4gICAgICAgICAgICAgICAgcmV0dXJuIG5ldyBLZElucHV0QnV0dG9uR3JvdXAoX2l0ZW0pO1xyXG4gICAgICAgICAgICBkZWZhdWx0OlxyXG4gICAgICAgICAgICAgICAgcmV0dXJuIG5ldyBLZElucHV0VGV4dChfaXRlbSk7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG59XHJcbiJdfQ==