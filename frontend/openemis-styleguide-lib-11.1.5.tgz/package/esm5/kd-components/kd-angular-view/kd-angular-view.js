import { __decorate, __metadata } from "tslib";
import { Component, Input, Output, EventEmitter, OnInit, OnDestroy, OnChanges, ViewChildren, ElementRef } from '@angular/core';
import { timer } from 'rxjs';
import { KdInput } from '../kd-angular-input/kd-angular-input';
import { KdInputControlService } from '../kd-angular-input/src/kd-angular-form.control';
import { KdFormEvent } from './src/kd-form-event';
import { KdDomElemSvc, KdConvertionSvc } from '../kd-common/index';
import { KdViewSvc } from './kd-angular-view-svc';
var KdView = /** @class */ (function () {
    function KdView(_dfControl, _formEvent, _domSvc, _kdViewSvc, _convertSvc, _elementRef) {
        this._dfControl = _dfControl;
        this._formEvent = _formEvent;
        this._domSvc = _domSvc;
        this._kdViewSvc = _kdViewSvc;
        this._convertSvc = _convertSvc;
        this._elementRef = _elementRef;
        this._dfQuestions = [];
        this._formBtn = [];
        this._firstLoad = true;
        this.detectFrom = new EventEmitter();
        this.detectGridQuestion = new EventEmitter();
        this.submitEvent = new EventEmitter();
        this.resetEvent = new EventEmitter();
        this.buttonEvent = new EventEmitter();
        this.gridCellChanged = new EventEmitter();
        this.gridButtonClicked = new EventEmitter();
    }
    KdView.prototype.ngOnInit = function () {
        var _this = this;
        this._displayType = this.displayType; // (typeof this.displayType !== 'undefined') ? this.displayType : 'view';
        this.isStackedFrom = this._displayType === 'stacked-form';
        this._setQuestions();
        this._setButtons();
        this._updateFormApi();
        this._formVisibleSub = this._formEvent.onSetVisiableInput().subscribe(function (val) {
            for (var i = 0; i < _this._dfQuestions.length; i++) {
                if (_this._dfQuestions[i].key === val.key) {
                    _this._dfQuestions[i].setVisible(val.visible);
                    break;
                }
            }
        });
        this._formDropdownSub = this._formEvent.onSetDropdownList().subscribe(function (val) {
            for (var i = 0; i < _this._dfQuestions.length; i++) {
                if (_this._dfQuestions[i].key === val.key) {
                    _this._dfQuestions[i].setOptions(val.options);
                    break;
                }
            }
        });
        this._firstLoad = false;
        // console.log('KdView - this is the view just initialized', this.inputData);
    };
    KdView.prototype.ngOnChanges = function () {
        if (!this._firstLoad) {
            // console.log('KdView - this is the view change event', this.inputData);
            this._displayType = (typeof this.displayType !== 'undefined') ? this.displayType : 'view';
            this._setQuestions();
            this._setButtons();
        }
    };
    KdView.prototype.ngOnDestroy = function () {
        if (this._formVisibleSub)
            this._formVisibleSub.unsubscribe();
        if (this._formDropdownSub)
            this._formDropdownSub.unsubscribe();
    };
    KdView.prototype.getInputProperty = function (key, propertyName) {
        for (var i = 0; i < this._dfQuestions.length; i++) {
            if (this._dfQuestions[i].getProperty('key') === key)
                return this._dfQuestions[i].getProperty(propertyName);
        }
    };
    KdView.prototype.setInputProperty = function (key, propertyName, data) {
        for (var i = 0; i < this._dfQuestions.length; i++) {
            if (this._dfQuestions[i].getProperty('key') === key) {
                if (propertyName !== 'visible') {
                    this._dfQuestions[i].setProperty(propertyName, data);
                }
                else {
                    this._dfQuestions[i].setVisible(data);
                }
                break;
            }
        }
    };
    KdView.prototype.resetGridHeight = function (_gridId) {
        this.inputComponent.forEach(function (item) {
            if (_gridId === item.question.getProperty('key')) {
                item.resetHeight();
            }
        });
    };
    ///// Table controltype
    KdView.prototype.updateTableCell = function (_questionKey, _cellParams) {
        this.inputComponent.forEach(function (item) {
            if (_questionKey === item.question.getProperty('key')) {
                item.setTableCellData(_cellParams);
            }
        });
    };
    KdView.prototype.updateTableCellProperty = function (_questionKey, _cellParams) {
        this.inputComponent.forEach(function (item) {
            if (_questionKey === item.question.getProperty('key')) {
                item.setTableCellQuestionProperty(_cellParams);
            }
        });
    };
    //////// till here
    KdView.prototype.setButtonDisabled = function (_type, _disabled) {
        for (var i = 0; i < this._formBtn.length; i++) {
            if (_type === this._formBtn[i].type) {
                this._formBtn[i].disabled = _disabled;
                this._formBtn = this._formBtn.slice();
            }
        }
    };
    KdView.prototype.isFormOrStackedForm = function () {
        if (this._displayType === 'form' || this._displayType === 'stacked-form') {
            return this._displayType;
        }
        else {
            return '-';
        }
    };
    // change to public due to lint
    KdView.prototype.changeDetectForm = function (_question) {
        this.detectFrom.emit(_question);
    };
    // change to public due to lint
    KdView.prototype.changeDetectFromGrid = function (_gridCellQuestion) {
        this.detectGridQuestion.emit(_gridCellQuestion);
    };
    /************************ Dynamic Form API updates *************************/
    KdView.prototype._updateFormApi = function () {
        var _this = this;
        if (typeof this.api === 'undefined') {
            console.warn('KdView warning: No api object is passed in. No API will be initialize');
            return;
        }
        this.api.submitForm = function () {
            _this._submitClick();
        };
        this.api.setProperty = function (_questionKey, _property, _data) {
            for (var i = 0; i < _this._dfQuestions.length; i++) {
                if (_this._dfQuestions[i].getProperty('key') === _questionKey) {
                    _this._dfQuestions[i].setProperty(_property, _data);
                    break;
                }
            }
        };
        this.api.getProperty = function (_questionKey, _property) {
            for (var i = 0; i < _this._dfQuestions.length; i++) {
                if (_this._dfQuestions[i].getProperty('key') === _questionKey) {
                    return _this._dfQuestions[i].getProperty(_property);
                }
            }
        };
        this.api.table = function (_questionKey) {
            var tableApi;
            for (var i = 0; i < _this._dfQuestions.length; ++i) {
                if (_this._dfQuestions[i].getProperty('key') === _questionKey) {
                    tableApi = _this._dfQuestions[i].getProperty('api');
                    break;
                }
            }
            return {
                setTableCellInputProperty: function (_formParams) {
                    tableApi.dynamicForm.setProperty(_formParams);
                },
                updateTableCellProperty: function (_cellParams) {
                    tableApi.general.updateCell(_cellParams);
                },
                getTableCellInputProperty: function (_formParams) {
                    tableApi.dynamicForm.getProperty(_formParams);
                },
                addRow: function (_rows, _scrollToVisible) {
                    if (_scrollToVisible === void 0) { _scrollToVisible = false; }
                    tableApi.general.addRows(_rows, _scrollToVisible);
                },
                deleteRows: function (_id) {
                    tableApi.general.deleteRows(_id);
                },
                clearError: function () {
                    tableApi.dynamicForm.clearAllError();
                },
                setButtonDisabled: function (_buttonType, _toDisabled) {
                    tableApi.general.setButtonDisabled(_buttonType, _toDisabled);
                }
            };
        };
        this.api.treedropdown = function (_questionKey) {
            var treeApi;
            for (var i = 0; i < _this._dfQuestions.length; ++i) {
                if (_this._dfQuestions[i].getProperty('key') === _questionKey) {
                    treeApi = _this._dfQuestions[i].getProperty('api');
                    break;
                }
            }
            return treeApi;
        };
        this.api.sliderApi = function (_questionKey) {
            var sliderApi;
            for (var i = 0; i < _this._dfQuestions.length; ++i) {
                if (_this._dfQuestions[i].getProperty('key') === _questionKey) {
                    sliderApi = _this._dfQuestions[i].getProperty('api');
                    break;
                }
            }
            return sliderApi;
        };
    };
    KdView.prototype._btnClick = function (_btn) {
        if (_btn.type === 'reset')
            this._resetForm();
        else if (_btn.type !== 'submit')
            this.buttonEvent.emit(_btn);
        // if(typeof _btn.callback === 'function') _btn.callback(this._form.value);
        // else if(typeof _btn.callback === 'undefined' && _btn.type !== 'submit') console.error('Please provide callback');
    };
    KdView.prototype._resetError = function () {
        for (var i = 0; i < this._dfQuestions.length; ++i) {
            this._dfQuestions[i].setProperty('errors', []);
        }
    };
    KdView.prototype._getFormValidationError = function () {
        for (var i = 0; i < this._dfQuestions.length; ++i) {
            this._dfQuestions[i].setProperty('errors', []);
            var errorArr = [];
            var errors = this._form.get(this._dfQuestions[i].getProperty('key')).errors;
            if (errors !== null) {
                for (var key in errors) {
                    if (errors.hasOwnProperty(key)) {
                        errorArr.push(errors[key]);
                    }
                }
                this._dfQuestions[i].setProperty('errors', errorArr);
            }
        }
    };
    KdView.prototype._submitClick = function () {
        var updatedForm = this._updateFormValue(this._dfQuestions, this._form.value);
        if (this._form.valid) {
            this.submitEvent.emit(updatedForm);
            this._resetError();
        }
        else {
            this._getFormValidationError();
        }
    };
    // private _submitClick(): void {
    //     let updatedForm: any = this._updateFormValue(this._dfQuestions, this._form.value);
    //     this.submitEvent.emit(updatedForm);
    // }
    KdView.prototype._resetForm = function () {
        this._setQuestions();
        var contentBody = (this._domSvc.isMobile()) ? document.body.querySelector('.main-wrapper') : document.body.querySelector('.content-area');
        contentBody.scrollTop = 0;
        this.resetEvent.emit();
    };
    KdView.prototype._setQuestions = function () {
        var _this = this;
        this._form = this._dfControl.emptyFormGroup();
        timer(50).subscribe(function () {
            _this._dfQuestions = _this._kdViewSvc.convertDataType(_this.inputData, _this._convertSvc);
            _this._form = _this._dfControl.toFormGroup(_this._dfQuestions);
        });
    };
    KdView.prototype._setButtons = function () {
        this._formBtn = (typeof this.button === 'undefined') ? this._setDefaultBtn() : this._setCustomBtn(this.button);
    };
    KdView.prototype._setDefaultBtn = function () {
        var defaultBtn = [{
                type: 'submit',
                name: 'Submit',
                icon: 'kd-check',
                class: 'btn-text',
                disabled: false
            }, {
                type: 'reset',
                name: 'Reset',
                class: 'btn-outline',
                icon: 'kd-cross',
                disabled: false
            }];
        return defaultBtn;
    };
    KdView.prototype._setCustomBtn = function (_btn) {
        var _this = this;
        var updatedBtn = [];
        var buttonLength = (this.button.length > 4) ? 4 : this.button.length;
        for (var i = 0; i < buttonLength; i++) {
            var item = _btn[i];
            if (typeof item.name === 'undefined')
                item.name = 'Undefined';
            if (typeof item.class === 'undefined')
                item.class = 'btn btn-text';
            if (typeof item.type === 'undefined')
                item.type = 'button';
            if (typeof item.disabled === 'undefined')
                item.disabled = false;
            if (item.type === 'reset') {
                item.callback = function () {
                    _this._resetForm();
                };
            }
            updatedBtn.push(item);
        }
        return updatedBtn;
    };
    KdView.prototype._updateFormValue = function (_question, _formValue) {
        var updatedFormVal = Object.assign({}, _formValue);
        for (var i = 0; i < _question.length; i++) {
            if (_question[i].controlType === 'section' && updatedFormVal && typeof updatedFormVal[_question[i].key] !== 'undefined') {
                delete updatedFormVal[_question[i].key];
            }
            else if (typeof _question[i].disabled !== 'undefined' && _question[i].disabled) {
                delete updatedFormVal[_question[i].key];
            }
        }
        return updatedFormVal;
    };
    /// table controltype
    KdView.prototype._gridCellValueChanged = function (_emitParams) {
        this.gridCellChanged.emit(_emitParams);
    };
    KdView.prototype._gridButtonClicked = function (_emitParams) {
        this.gridButtonClicked.emit(_emitParams);
    };
    KdView.ctorParameters = function () { return [
        { type: KdInputControlService },
        { type: KdFormEvent },
        { type: KdDomElemSvc },
        { type: KdViewSvc },
        { type: KdConvertionSvc },
        { type: ElementRef }
    ]; };
    __decorate([
        Input(),
        __metadata("design:type", Array)
    ], KdView.prototype, "inputData", void 0);
    __decorate([
        Input(),
        __metadata("design:type", Array)
    ], KdView.prototype, "button", void 0);
    __decorate([
        Input(),
        __metadata("design:type", String)
    ], KdView.prototype, "displayType", void 0);
    __decorate([
        Input(),
        __metadata("design:type", Object)
    ], KdView.prototype, "api", void 0);
    __decorate([
        Output(),
        __metadata("design:type", EventEmitter)
    ], KdView.prototype, "detectFrom", void 0);
    __decorate([
        Output(),
        __metadata("design:type", EventEmitter)
    ], KdView.prototype, "detectGridQuestion", void 0);
    __decorate([
        Output(),
        __metadata("design:type", EventEmitter)
    ], KdView.prototype, "submitEvent", void 0);
    __decorate([
        Output(),
        __metadata("design:type", EventEmitter)
    ], KdView.prototype, "resetEvent", void 0);
    __decorate([
        Output(),
        __metadata("design:type", EventEmitter)
    ], KdView.prototype, "buttonEvent", void 0);
    __decorate([
        ViewChildren(KdInput),
        __metadata("design:type", Array)
    ], KdView.prototype, "inputComponent", void 0);
    __decorate([
        Output(),
        __metadata("design:type", EventEmitter)
    ], KdView.prototype, "gridCellChanged", void 0);
    __decorate([
        Output(),
        __metadata("design:type", EventEmitter)
    ], KdView.prototype, "gridButtonClicked", void 0);
    KdView = __decorate([
        Component({
            selector: 'kd-view',
            template: "<div class='section-header'>{{_displayType}}</div>\r\n<ng-container [ngSwitch]=\"_displayType\">\r\n\r\n    <ng-container *ngSwitchCase=\"isFormOrStackedForm()\" >\r\n        <form class=\"form-vertical kdx\" [class.stacked]='isStackedFrom' *ngIf=\"_dfQuestions.length>0\" [formGroup]=\"_form\" (ngSubmit)=\"_submitClick()\">\r\n            <div *ngFor=\"let question of _dfQuestions\" class=\"form-row\" [class.section-header]=\"question.controlType == 'section'\">\r\n\r\n                <kd-input \r\n                    [question]=\"question\" \r\n                    [form]=\"_form\" \r\n                    (changeDetectFromQuestion)=\"changeDetectForm($event)\" \r\n                    (changeDetectFromGrid)=\"changeDetectFromGrid($event)\" \r\n                    (gridCellValueChanged)=\"_gridCellValueChanged($event)\"\r\n                    (gridButtonClicked)=\"_gridButtonClicked($event)\"\r\n                ></kd-input>\r\n            </div>\r\n            <div *ngIf=\"_formBtn.length>0\" class=\"form-buttons\">\r\n                <div class=\"button-label\"></div>\r\n                <button *ngFor=\"let btn of _formBtn\" [type]=\"(btn.type=='submit')?'submit':'button'\" class=\"btn btn-icon\" [ngClass]=\"btn.class\" (click)=\"_btnClick(btn)\" [disabled]=\"btn.disabled\">\r\n                    <i [class]=\"btn.icon\"></i>\r\n                    <span>{{btn.name}}</span>\r\n                </button>\r\n            </div>\r\n        </form>\r\n    </ng-container>\r\n\r\n    <ng-container *ngSwitchCase=\"'horizontal-form'\">\r\n        <div *ngIf=\"_dfQuestions.length>0\" class=\"form-horizontal-wrapper\">\r\n            <form class=\"form-horizontal\" [formGroup]=\"_form\">\r\n                <div *ngFor=\"let question of _dfQuestions\" class=\"form-row\">\r\n                    <kd-input [question]=\"question\" [form]=\"_form\" [horizontal]=\"true\" (changeDetectFromQuestion)=\"changeDetectForm($event)\"></kd-input>\r\n                </div>\r\n            </form>\r\n        </div>\r\n    </ng-container>\r\n\r\n    <ng-container *ngSwitchDefault> \r\n        <!-- View -->\r\n        <div [ngClass]=\"item.controlType!='section' ? 'kdx-view-list':'section-header' \" *ngFor=\"let item of _dfQuestions\">\r\n    <!-- <div class=\"view-list\" *ngFor=\"let item of _dfQuestions\"> -->\r\n            <h6 *ngIf=\"item.controlType=='section'\" >{{item.label}}</h6>\r\n            \r\n            <div *ngIf=\"item.visible && item.controlType!='section'\">\r\n                <div class=\"kdx-view-label\">{{item.label}}</div>\r\n                <div class=\"view-data\"  [ngSwitch]=\"item.controlType\">\r\n                    <div *ngSwitchCase=\"'file-input'\">\r\n                        <kd-placeholder \r\n                            *ngIf=\"item.config.fileType == 'image' && item.config.preview\"\r\n                            [config]='item.config.imageConfig'\r\n                            [value]='item.value'\r\n                        ></kd-placeholder>\r\n                        <div *ngIf=\"item.config.fileType != 'image' || !item.config.preview\">\r\n                            <a [href]=\"item.value.src\" style=\"text-decoration: none;\" placement=\"right\" ngbTooltip=\"Download\" container=\"body\" target=\"_blank\"> \r\n                                <i class=\"fa fa-paperclip\"></i>\r\n                                {{item.value.filename}}\r\n                            </a>\r\n                        </div>\r\n                    </div>\r\n                    <div *ngSwitchCase=\"'table'\" class=\"kdx-input-table-wrapper\">\r\n                        <kd-table [config]='item.config' [row]='item.row' [column]='item.column'></kd-table>\r\n                    </div>\r\n                    <div *ngSwitchCase=\"'symbol'\">\r\n                        <i [ngClass]=\"item.value\"></i>\r\n                    </div>\r\n                    <div *ngSwitchDefault [class]=\"item.class\">{{item.value}}</div>\r\n                    <i [class]=\"item.class\"></i>\r\n                </div>\r\n            </div>\r\n        </div>\r\n    </ng-container>\r\n\r\n</ng-container>\r\n\r\n<!-- \r\n<div *ngIf=\"_displayType!='form' && _displayType !='horizontal-form'\">\r\n    <div [ngClass]=\"item.controlType!='section' ? 'kdx-view-list':'section-header' \" *ngFor=\"let item of _dfQuestions\">\r\n        <h6 *ngIf=\"item.controlType=='section'\" >{{item.label}}</h6>\r\n        \r\n        <div *ngIf=\"item.visible && item.controlType!='section'\">\r\n            <div class=\"kdx-view-label\">{{item.label}}</div>\r\n            <div class=\"view-data\"  [ngSwitch]=\"item.controlType\">\r\n                <div *ngSwitchCase=\"'file-input'\">\r\n                    <kd-placeholder \r\n                        *ngIf=\"item.config.fileType == 'image' && item.config.preview\"\r\n                        [config]='item.config.imageConfig'\r\n                        [value]='item.value'\r\n                    ></kd-placeholder>\r\n                    <div *ngIf=\"item.config.fileType != 'image' || !item.config.preview\">\r\n                        <a [href]=\"item.value.src\" style=\"text-decoration: none;\" placement=\"right\" ngbTooltip=\"Download\" container=\"body\" target=\"_blank\"> \r\n                            <i class=\"fa fa-paperclip\"></i>\r\n                            {{item.value.filename}}\r\n                        </a>\r\n                    </div>\r\n                </div>\r\n                <div *ngSwitchCase=\"'table'\" class=\"kdx-input-table-wrapper\">\r\n                    <kd-table [config]='item.config' [row]='item.row' [column]='item.column'></kd-table>\r\n                </div>\r\n                <div *ngSwitchCase=\"'symbol'\">\r\n                    <i [ngClass]=\"item.value\"></i>\r\n                </div>\r\n                <div *ngSwitchDefault [class]=\"item.class\">{{item.value}}</div>\r\n                <i [class]=\"item.class\"></i>\r\n            </div>\r\n        </div>\r\n    </div>\r\n</div>\r\n\r\n<form class=\"form-vertical kdx\" *ngIf=\"_displayType=='form' && _dfQuestions.length>0\" [formGroup]=\"_form\" (ngSubmit)=\"_submitClick()\">\r\n    <div *ngFor=\"let question of _dfQuestions\" class=\"form-row\" [class.section-header]=\"question.controlType == 'section'\">\r\n\r\n        <kd-input \r\n            [question]=\"question\" \r\n            [form]=\"_form\" \r\n            (changeDetectFromQuestion)=\"changeDetectForm($event)\" \r\n            (changeDetectFromGrid)=\"changeDetectFromGrid($event)\" \r\n            (gridCellValueChanged)=\"_gridCellValueChanged($event)\"\r\n            (gridButtonClicked)=\"_gridButtonClicked($event)\"\r\n        ></kd-input>\r\n    </div>\r\n    <div *ngIf=\"_formBtn.length>0\" class=\"form-buttons\">\r\n        <div class=\"button-label\"></div>\r\n        <button *ngFor=\"let btn of _formBtn\" [type]=\"(btn.type=='submit')?'submit':'button'\" class=\"btn btn-icon\" [ngClass]=\"btn.class\" (click)=\"_btnClick(btn)\" [disabled]=\"btn.disabled\">\r\n            <i [class]=\"btn.icon\"></i>\r\n            <span>{{btn.name}}</span>\r\n        </button>\r\n    </div>\r\n</form>\r\n\r\n<div *ngIf=\"_displayType=='horizontal-form' && _dfQuestions.length>0\" class=\"form-horizontal-wrapper\">\r\n    <form class=\"form-horizontal\" [formGroup]=\"_form\">\r\n        <div *ngFor=\"let question of _dfQuestions\" class=\"form-row\">\r\n            <kd-input [question]=\"question\" [form]=\"_form\" [horizontal]=\"true\" (changeDetectFromQuestion)=\"changeDetectForm($event)\"></kd-input>\r\n        </div>\r\n    </form>\r\n</div>\r\n -->",
            providers: [KdInputControlService, KdFormEvent, KdDomElemSvc, KdViewSvc, KdConvertionSvc],
            host: {
                'class': 'kdx-view'
            }
        }),
        __metadata("design:paramtypes", [KdInputControlService,
            KdFormEvent,
            KdDomElemSvc,
            KdViewSvc,
            KdConvertionSvc,
            ElementRef])
    ], KdView);
    return KdView;
}());
export { KdView };
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoia2QtYW5ndWxhci12aWV3LmpzIiwic291cmNlUm9vdCI6Im5nOi8vb3BlbmVtaXMtc3R5bGVndWlkZS1saWIvIiwic291cmNlcyI6WyJrZC1jb21wb25lbnRzL2tkLWFuZ3VsYXItdmlldy9rZC1hbmd1bGFyLXZpZXcudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IjtBQUFBLE9BQU8sRUFDSCxTQUFTLEVBQ1QsS0FBSyxFQUNMLE1BQU0sRUFDTixZQUFZLEVBQ1osTUFBTSxFQUNOLFNBQVMsRUFDVCxTQUFTLEVBQ1QsWUFBWSxFQUNaLFVBQVUsRUFDYixNQUFNLGVBQWUsQ0FBQztBQUN2QixPQUFPLEVBQUUsS0FBSyxFQUFrQixNQUFNLE1BQU0sQ0FBQztBQUU3QyxPQUFPLEVBQUUsT0FBTyxFQUFFLE1BQU0sc0NBQXNDLENBQUM7QUFFL0QsT0FBTyxFQUFFLHFCQUFxQixFQUFFLE1BQU0saURBQWlELENBQUM7QUFDeEYsT0FBTyxFQUFFLFdBQVcsRUFBRSxNQUFNLHFCQUFxQixDQUFDO0FBQ2xELE9BQU8sRUFBRSxZQUFZLEVBQUUsZUFBZSxFQUFFLE1BQU0sb0JBQW9CLENBQUM7QUFDbkUsT0FBTyxFQUFFLFNBQVMsRUFBRSxNQUFNLHVCQUF1QixDQUFDO0FBdUJsRDtJQXlCSSxnQkFDWSxVQUFpQyxFQUNqQyxVQUF1QixFQUN2QixPQUFxQixFQUNyQixVQUFxQixFQUNyQixXQUE0QixFQUM1QixXQUF1QjtRQUx2QixlQUFVLEdBQVYsVUFBVSxDQUF1QjtRQUNqQyxlQUFVLEdBQVYsVUFBVSxDQUFhO1FBQ3ZCLFlBQU8sR0FBUCxPQUFPLENBQWM7UUFDckIsZUFBVSxHQUFWLFVBQVUsQ0FBVztRQUNyQixnQkFBVyxHQUFYLFdBQVcsQ0FBaUI7UUFDNUIsZ0JBQVcsR0FBWCxXQUFXLENBQVk7UUE5QjVCLGlCQUFZLEdBQWUsRUFBRSxDQUFDO1FBSzlCLGFBQVEsR0FBZSxFQUFFLENBQUM7UUFDekIsZUFBVSxHQUFZLElBQUksQ0FBQztRQVF6QixlQUFVLEdBQXNCLElBQUksWUFBWSxFQUFFLENBQUM7UUFDbkQsdUJBQWtCLEdBQXNCLElBQUksWUFBWSxFQUFFLENBQUM7UUFDM0QsZ0JBQVcsR0FBc0IsSUFBSSxZQUFZLEVBQUUsQ0FBQztRQUNwRCxlQUFVLEdBQXNCLElBQUksWUFBWSxFQUFFLENBQUM7UUFDbkQsZ0JBQVcsR0FBc0IsSUFBSSxZQUFZLEVBQUUsQ0FBQztRQUdwRCxvQkFBZSxHQUF1RSxJQUFJLFlBQVksRUFBRSxDQUFDO1FBQ3pHLHNCQUFpQixHQUFrRSxJQUFJLFlBQVksRUFBRSxDQUFDO0lBUzVHLENBQUM7SUFFTCx5QkFBUSxHQUFSO1FBQUEsaUJBNkJDO1FBM0JHLElBQUksQ0FBQyxZQUFZLEdBQUcsSUFBSSxDQUFDLFdBQVcsQ0FBQyxDQUFDLHlFQUF5RTtRQUMvRyxJQUFJLENBQUMsYUFBYSxHQUFHLElBQUksQ0FBQyxZQUFZLEtBQUssY0FBYyxDQUFDO1FBRTFELElBQUksQ0FBQyxhQUFhLEVBQUUsQ0FBQztRQUNyQixJQUFJLENBQUMsV0FBVyxFQUFFLENBQUM7UUFDbkIsSUFBSSxDQUFDLGNBQWMsRUFBRSxDQUFDO1FBRXRCLElBQUksQ0FBQyxlQUFlLEdBQUcsSUFBSSxDQUFDLFVBQVUsQ0FBQyxrQkFBa0IsRUFBRSxDQUFDLFNBQVMsQ0FBQyxVQUFBLEdBQUc7WUFDckUsS0FBSyxJQUFJLENBQUMsR0FBVyxDQUFDLEVBQUUsQ0FBQyxHQUFHLEtBQUksQ0FBQyxZQUFZLENBQUMsTUFBTSxFQUFFLENBQUMsRUFBRSxFQUFFO2dCQUN2RCxJQUFJLEtBQUksQ0FBQyxZQUFZLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxLQUFLLEdBQUcsQ0FBQyxHQUFHLEVBQUU7b0JBQ3RDLEtBQUksQ0FBQyxZQUFZLENBQUMsQ0FBQyxDQUFDLENBQUMsVUFBVSxDQUFDLEdBQUcsQ0FBQyxPQUFPLENBQUMsQ0FBQztvQkFDN0MsTUFBTTtpQkFDVDthQUNKO1FBQ0wsQ0FBQyxDQUFDLENBQUM7UUFFSCxJQUFJLENBQUMsZ0JBQWdCLEdBQUcsSUFBSSxDQUFDLFVBQVUsQ0FBQyxpQkFBaUIsRUFBRSxDQUFDLFNBQVMsQ0FBQyxVQUFBLEdBQUc7WUFDckUsS0FBSyxJQUFJLENBQUMsR0FBVyxDQUFDLEVBQUUsQ0FBQyxHQUFHLEtBQUksQ0FBQyxZQUFZLENBQUMsTUFBTSxFQUFFLENBQUMsRUFBRSxFQUFFO2dCQUN2RCxJQUFJLEtBQUksQ0FBQyxZQUFZLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxLQUFLLEdBQUcsQ0FBQyxHQUFHLEVBQUU7b0JBQ3RDLEtBQUksQ0FBQyxZQUFZLENBQUMsQ0FBQyxDQUFDLENBQUMsVUFBVSxDQUFDLEdBQUcsQ0FBQyxPQUFPLENBQUMsQ0FBQztvQkFDN0MsTUFBTTtpQkFDVDthQUNKO1FBQ0wsQ0FBQyxDQUFDLENBQUM7UUFFSCxJQUFJLENBQUMsVUFBVSxHQUFHLEtBQUssQ0FBQztRQUN4Qiw2RUFBNkU7SUFDakYsQ0FBQztJQUVELDRCQUFXLEdBQVg7UUFDSSxJQUFJLENBQUMsSUFBSSxDQUFDLFVBQVUsRUFBRTtZQUNsQix5RUFBeUU7WUFDekUsSUFBSSxDQUFDLFlBQVksR0FBRyxDQUFDLE9BQU8sSUFBSSxDQUFDLFdBQVcsS0FBSyxXQUFXLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDO1lBQzFGLElBQUksQ0FBQyxhQUFhLEVBQUUsQ0FBQztZQUNyQixJQUFJLENBQUMsV0FBVyxFQUFFLENBQUM7U0FDdEI7SUFDTCxDQUFDO0lBRUQsNEJBQVcsR0FBWDtRQUNJLElBQUcsSUFBSSxDQUFDLGVBQWU7WUFBRSxJQUFJLENBQUMsZUFBZSxDQUFDLFdBQVcsRUFBRSxDQUFDO1FBQzVELElBQUcsSUFBSSxDQUFDLGdCQUFnQjtZQUFFLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxXQUFXLEVBQUUsQ0FBQztJQUNsRSxDQUFDO0lBRU0saUNBQWdCLEdBQXZCLFVBQXdCLEdBQVcsRUFBRSxZQUFvQjtRQUNyRCxLQUFLLElBQUksQ0FBQyxHQUFXLENBQUMsRUFBRSxDQUFDLEdBQUcsSUFBSSxDQUFDLFlBQVksQ0FBQyxNQUFNLEVBQUUsQ0FBQyxFQUFFLEVBQUU7WUFDdkQsSUFBSSxJQUFJLENBQUMsWUFBWSxDQUFDLENBQUMsQ0FBQyxDQUFDLFdBQVcsQ0FBQyxLQUFLLENBQUMsS0FBSyxHQUFHO2dCQUFFLE9BQU8sSUFBSSxDQUFDLFlBQVksQ0FBQyxDQUFDLENBQUMsQ0FBQyxXQUFXLENBQUMsWUFBWSxDQUFDLENBQUM7U0FDOUc7SUFDTCxDQUFDO0lBRU0saUNBQWdCLEdBQXZCLFVBQXdCLEdBQVcsRUFBRSxZQUFvQixFQUFFLElBQVM7UUFDaEUsS0FBSyxJQUFJLENBQUMsR0FBVyxDQUFDLEVBQUUsQ0FBQyxHQUFHLElBQUksQ0FBQyxZQUFZLENBQUMsTUFBTSxFQUFFLENBQUMsRUFBRSxFQUFFO1lBQ3ZELElBQUksSUFBSSxDQUFDLFlBQVksQ0FBQyxDQUFDLENBQUMsQ0FBQyxXQUFXLENBQUMsS0FBSyxDQUFDLEtBQUssR0FBRyxFQUFFO2dCQUNqRCxJQUFJLFlBQVksS0FBSyxTQUFTLEVBQUU7b0JBQzVCLElBQUksQ0FBQyxZQUFZLENBQUMsQ0FBQyxDQUFDLENBQUMsV0FBVyxDQUFDLFlBQVksRUFBRSxJQUFJLENBQUMsQ0FBQztpQkFDeEQ7cUJBQ0k7b0JBQ0QsSUFBSSxDQUFDLFlBQVksQ0FBQyxDQUFDLENBQUMsQ0FBQyxVQUFVLENBQUMsSUFBSSxDQUFDLENBQUM7aUJBQ3pDO2dCQUNELE1BQU07YUFDVDtTQUNKO0lBQ0wsQ0FBQztJQUVNLGdDQUFlLEdBQXRCLFVBQXVCLE9BQWU7UUFDbEMsSUFBSSxDQUFDLGNBQWMsQ0FBQyxPQUFPLENBQUMsVUFBQyxJQUFhO1lBQ3RDLElBQUksT0FBTyxLQUFLLElBQUksQ0FBQyxRQUFRLENBQUMsV0FBVyxDQUFDLEtBQUssQ0FBQyxFQUFFO2dCQUM5QyxJQUFJLENBQUMsV0FBVyxFQUFFLENBQUM7YUFDdEI7UUFDTCxDQUFDLENBQUMsQ0FBQztJQUNQLENBQUM7SUFFRCx1QkFBdUI7SUFDaEIsZ0NBQWUsR0FBdEIsVUFBdUIsWUFBb0IsRUFBRSxXQUE2QjtRQUN0RSxJQUFJLENBQUMsY0FBYyxDQUFDLE9BQU8sQ0FBQyxVQUFDLElBQWE7WUFDdEMsSUFBSSxZQUFZLEtBQUssSUFBSSxDQUFDLFFBQVEsQ0FBQyxXQUFXLENBQUMsS0FBSyxDQUFDLEVBQUU7Z0JBQ25ELElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxXQUFXLENBQUMsQ0FBQzthQUN0QztRQUNMLENBQUMsQ0FBQyxDQUFDO0lBQ1AsQ0FBQztJQUVNLHdDQUF1QixHQUE5QixVQUErQixZQUFvQixFQUFFLFdBQW1DO1FBQ3BGLElBQUksQ0FBQyxjQUFjLENBQUMsT0FBTyxDQUFDLFVBQUMsSUFBYTtZQUN0QyxJQUFJLFlBQVksS0FBSyxJQUFJLENBQUMsUUFBUSxDQUFDLFdBQVcsQ0FBQyxLQUFLLENBQUMsRUFBRTtnQkFDbkQsSUFBSSxDQUFDLDRCQUE0QixDQUFDLFdBQVcsQ0FBQyxDQUFDO2FBQ2xEO1FBQ0wsQ0FBQyxDQUFDLENBQUM7SUFDUCxDQUFDO0lBQ0Qsa0JBQWtCO0lBRVgsa0NBQWlCLEdBQXhCLFVBQXlCLEtBQWEsRUFBRSxTQUFrQjtRQUN0RCxLQUFLLElBQUksQ0FBQyxHQUFXLENBQUMsRUFBRSxDQUFDLEdBQUcsSUFBSSxDQUFDLFFBQVEsQ0FBQyxNQUFNLEVBQUUsQ0FBQyxFQUFFLEVBQUU7WUFDbkQsSUFBSSxLQUFLLEtBQUssSUFBSSxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLEVBQUU7Z0JBQ2pDLElBQUksQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxHQUFHLFNBQVMsQ0FBQztnQkFDdEMsSUFBSSxDQUFDLFFBQVEsR0FBRyxJQUFJLENBQUMsUUFBUSxDQUFDLEtBQUssRUFBRSxDQUFDO2FBQ3pDO1NBQ0o7SUFDTCxDQUFDO0lBRU0sb0NBQW1CLEdBQTFCO1FBQ0ksSUFBSSxJQUFJLENBQUMsWUFBWSxLQUFLLE1BQU0sSUFBSSxJQUFJLENBQUMsWUFBWSxLQUFLLGNBQWMsRUFBRTtZQUN0RSxPQUFPLElBQUksQ0FBQyxZQUFZLENBQUM7U0FDNUI7YUFBTTtZQUNILE9BQU8sR0FBRyxDQUFDO1NBQ2Q7SUFDTCxDQUFDO0lBRUQsK0JBQStCO0lBQ3hCLGlDQUFnQixHQUF2QixVQUF3QixTQUF5QjtRQUM3QyxJQUFJLENBQUMsVUFBVSxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsQ0FBQztJQUNwQyxDQUFDO0lBRUQsK0JBQStCO0lBQ3hCLHFDQUFvQixHQUEzQixVQUE0QixpQkFBc0I7UUFDOUMsSUFBSSxDQUFDLGtCQUFrQixDQUFDLElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxDQUFDO0lBQ3BELENBQUM7SUFFRCw2RUFBNkU7SUFDckUsK0JBQWMsR0FBdEI7UUFBQSxpQkFxRkM7UUFwRkcsSUFBSSxPQUFPLElBQUksQ0FBQyxHQUFHLEtBQUssV0FBVyxFQUFFO1lBQ2pDLE9BQU8sQ0FBQyxJQUFJLENBQUMsdUVBQXVFLENBQUMsQ0FBQztZQUN0RixPQUFPO1NBQ1Y7UUFFRCxJQUFJLENBQUMsR0FBRyxDQUFDLFVBQVUsR0FBRztZQUNsQixLQUFJLENBQUMsWUFBWSxFQUFFLENBQUM7UUFDeEIsQ0FBQyxDQUFDO1FBRUYsSUFBSSxDQUFDLEdBQUcsQ0FBQyxXQUFXLEdBQUcsVUFBQyxZQUFvQixFQUFFLFNBQWlCLEVBQUUsS0FBVTtZQUN2RSxLQUFLLElBQUksQ0FBQyxHQUFXLENBQUMsRUFBRSxDQUFDLEdBQUcsS0FBSSxDQUFDLFlBQVksQ0FBQyxNQUFNLEVBQUUsQ0FBQyxFQUFFLEVBQUU7Z0JBQ3ZELElBQUksS0FBSSxDQUFDLFlBQVksQ0FBQyxDQUFDLENBQUMsQ0FBQyxXQUFXLENBQUMsS0FBSyxDQUFDLEtBQUssWUFBWSxFQUFFO29CQUMxRCxLQUFJLENBQUMsWUFBWSxDQUFDLENBQUMsQ0FBQyxDQUFDLFdBQVcsQ0FBQyxTQUFTLEVBQUUsS0FBSyxDQUFDLENBQUM7b0JBQ25ELE1BQU07aUJBQ1Q7YUFDSjtRQUNMLENBQUMsQ0FBQztRQUVGLElBQUksQ0FBQyxHQUFHLENBQUMsV0FBVyxHQUFHLFVBQUMsWUFBb0IsRUFBRSxTQUFpQjtZQUMzRCxLQUFLLElBQUksQ0FBQyxHQUFXLENBQUMsRUFBRSxDQUFDLEdBQUcsS0FBSSxDQUFDLFlBQVksQ0FBQyxNQUFNLEVBQUUsQ0FBQyxFQUFFLEVBQUU7Z0JBQ3ZELElBQUksS0FBSSxDQUFDLFlBQVksQ0FBQyxDQUFDLENBQUMsQ0FBQyxXQUFXLENBQUMsS0FBSyxDQUFDLEtBQUssWUFBWSxFQUFFO29CQUMxRCxPQUFPLEtBQUksQ0FBQyxZQUFZLENBQUMsQ0FBQyxDQUFDLENBQUMsV0FBVyxDQUFDLFNBQVMsQ0FBQyxDQUFDO2lCQUN0RDthQUNKO1FBQ0wsQ0FBQyxDQUFDO1FBRUYsSUFBSSxDQUFDLEdBQUcsQ0FBQyxLQUFLLEdBQUcsVUFBQyxZQUFvQjtZQUNsQyxJQUFJLFFBQW1CLENBQUM7WUFFeEIsS0FBSyxJQUFJLENBQUMsR0FBVyxDQUFDLEVBQUUsQ0FBQyxHQUFHLEtBQUksQ0FBQyxZQUFZLENBQUMsTUFBTSxFQUFFLEVBQUUsQ0FBQyxFQUFFO2dCQUN2RCxJQUFJLEtBQUksQ0FBQyxZQUFZLENBQUMsQ0FBQyxDQUFDLENBQUMsV0FBVyxDQUFDLEtBQUssQ0FBQyxLQUFLLFlBQVksRUFBRTtvQkFDMUQsUUFBUSxHQUFHLEtBQUksQ0FBQyxZQUFZLENBQUMsQ0FBQyxDQUFDLENBQUMsV0FBVyxDQUFDLEtBQUssQ0FBQyxDQUFDO29CQUNuRCxNQUFNO2lCQUNUO2FBQ0o7WUFFRCxPQUFPO2dCQUNILHlCQUF5QixFQUFFLFVBQUMsV0FBbUM7b0JBQzNELFFBQVEsQ0FBQyxXQUFXLENBQUMsV0FBVyxDQUFDLFdBQVcsQ0FBQyxDQUFDO2dCQUNsRCxDQUFDO2dCQUNELHVCQUF1QixFQUFFLFVBQUMsV0FBNkI7b0JBQ25ELFFBQVEsQ0FBQyxPQUFPLENBQUMsVUFBVSxDQUFDLFdBQVcsQ0FBQyxDQUFDO2dCQUM3QyxDQUFDO2dCQUNELHlCQUF5QixFQUFFLFVBQUMsV0FBbUM7b0JBQzNELFFBQVEsQ0FBQyxXQUFXLENBQUMsV0FBVyxDQUFDLFdBQVcsQ0FBQyxDQUFDO2dCQUNsRCxDQUFDO2dCQUNELE1BQU0sRUFBRSxVQUFDLEtBQWlCLEVBQUUsZ0JBQWlDO29CQUFqQyxpQ0FBQSxFQUFBLHdCQUFpQztvQkFDekQsUUFBUSxDQUFDLE9BQU8sQ0FBQyxPQUFPLENBQUMsS0FBSyxFQUFFLGdCQUFnQixDQUFDLENBQUM7Z0JBQ3RELENBQUM7Z0JBQ0QsVUFBVSxFQUFFLFVBQUMsR0FBNkM7b0JBQ3RELFFBQVEsQ0FBQyxPQUFPLENBQUMsVUFBVSxDQUFDLEdBQUcsQ0FBQyxDQUFDO2dCQUNyQyxDQUFDO2dCQUNELFVBQVUsRUFBRTtvQkFDUixRQUFRLENBQUMsV0FBVyxDQUFDLGFBQWEsRUFBRSxDQUFDO2dCQUN6QyxDQUFDO2dCQUNELGlCQUFpQixFQUFFLFVBQUMsV0FBbUIsRUFBRSxXQUFvQjtvQkFDekQsUUFBUSxDQUFDLE9BQU8sQ0FBQyxpQkFBaUIsQ0FBQyxXQUFXLEVBQUUsV0FBVyxDQUFDLENBQUM7Z0JBQ2pFLENBQUM7YUFDSixDQUFDO1FBQ04sQ0FBQyxDQUFDO1FBRUYsSUFBSSxDQUFDLEdBQUcsQ0FBQyxZQUFZLEdBQUcsVUFBQyxZQUFvQjtZQUN6QyxJQUFJLE9BQWlCLENBQUM7WUFDdEIsS0FBSyxJQUFJLENBQUMsR0FBVyxDQUFDLEVBQUUsQ0FBQyxHQUFHLEtBQUksQ0FBQyxZQUFZLENBQUMsTUFBTSxFQUFFLEVBQUUsQ0FBQyxFQUFFO2dCQUN2RCxJQUFJLEtBQUksQ0FBQyxZQUFZLENBQUMsQ0FBQyxDQUFDLENBQUMsV0FBVyxDQUFDLEtBQUssQ0FBQyxLQUFLLFlBQVksRUFBRTtvQkFDMUQsT0FBTyxHQUFHLEtBQUksQ0FBQyxZQUFZLENBQUMsQ0FBQyxDQUFDLENBQUMsV0FBVyxDQUFDLEtBQUssQ0FBQyxDQUFDO29CQUNsRCxNQUFNO2lCQUNUO2FBQ0o7WUFDRCxPQUFPLE9BQU8sQ0FBQztRQUNuQixDQUFDLENBQUM7UUFFRixJQUFJLENBQUMsR0FBRyxDQUFDLFNBQVMsR0FBRyxVQUFDLFlBQW9CO1lBQ3RDLElBQUksU0FBcUIsQ0FBQztZQUUxQixLQUFLLElBQUksQ0FBQyxHQUFXLENBQUMsRUFBRSxDQUFDLEdBQUcsS0FBSSxDQUFDLFlBQVksQ0FBQyxNQUFNLEVBQUUsRUFBRSxDQUFDLEVBQUU7Z0JBQ3ZELElBQUksS0FBSSxDQUFDLFlBQVksQ0FBQyxDQUFDLENBQUMsQ0FBQyxXQUFXLENBQUMsS0FBSyxDQUFDLEtBQUssWUFBWSxFQUFFO29CQUMxRCxTQUFTLEdBQUcsS0FBSSxDQUFDLFlBQVksQ0FBQyxDQUFDLENBQUMsQ0FBQyxXQUFXLENBQUMsS0FBSyxDQUFDLENBQUM7b0JBQ3BELE1BQU07aUJBQ1Q7YUFDSjtZQUVELE9BQU8sU0FBUyxDQUFDO1FBQ3JCLENBQUMsQ0FBQztJQUNOLENBQUM7SUFHTSwwQkFBUyxHQUFoQixVQUFpQixJQUFTO1FBQ3RCLElBQUksSUFBSSxDQUFDLElBQUksS0FBSyxPQUFPO1lBQUUsSUFBSSxDQUFDLFVBQVUsRUFBRSxDQUFDO2FBQ3hDLElBQUksSUFBSSxDQUFDLElBQUksS0FBSyxRQUFRO1lBQUUsSUFBSSxDQUFDLFdBQVcsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUM7UUFDN0QsMkVBQTJFO1FBQzNFLG9IQUFvSDtJQUN4SCxDQUFDO0lBRU8sNEJBQVcsR0FBbkI7UUFDSSxLQUFLLElBQUksQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLEdBQUcsSUFBSSxDQUFDLFlBQVksQ0FBQyxNQUFNLEVBQUUsRUFBRSxDQUFDLEVBQUU7WUFDL0MsSUFBSSxDQUFDLFlBQVksQ0FBQyxDQUFDLENBQUMsQ0FBQyxXQUFXLENBQUMsUUFBUSxFQUFFLEVBQUUsQ0FBQyxDQUFDO1NBQ2xEO0lBQ0wsQ0FBQztJQUVPLHdDQUF1QixHQUEvQjtRQUNJLEtBQUssSUFBSSxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsR0FBRyxJQUFJLENBQUMsWUFBWSxDQUFDLE1BQU0sRUFBRSxFQUFFLENBQUMsRUFBRTtZQUMvQyxJQUFJLENBQUMsWUFBWSxDQUFDLENBQUMsQ0FBQyxDQUFDLFdBQVcsQ0FBQyxRQUFRLEVBQUUsRUFBRSxDQUFDLENBQUM7WUFDL0MsSUFBSSxRQUFRLEdBQWtCLEVBQUUsQ0FBQztZQUNqQyxJQUFNLE1BQU0sR0FBTyxJQUFJLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsWUFBWSxDQUFDLENBQUMsQ0FBQyxDQUFDLFdBQVcsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQztZQUNsRixJQUFJLE1BQU0sS0FBSyxJQUFJLEVBQUU7Z0JBQ2pCLEtBQUssSUFBSSxHQUFHLElBQUksTUFBTSxFQUFFO29CQUNwQixJQUFJLE1BQU0sQ0FBQyxjQUFjLENBQUMsR0FBRyxDQUFDLEVBQUU7d0JBQzVCLFFBQVEsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUM7cUJBQzlCO2lCQUNKO2dCQUNELElBQUksQ0FBQyxZQUFZLENBQUMsQ0FBQyxDQUFDLENBQUMsV0FBVyxDQUFDLFFBQVEsRUFBRSxRQUFRLENBQUMsQ0FBQzthQUN4RDtTQUNKO0lBQ0wsQ0FBQztJQUVNLDZCQUFZLEdBQW5CO1FBQ0ksSUFBSSxXQUFXLEdBQVEsSUFBSSxDQUFDLGdCQUFnQixDQUFDLElBQUksQ0FBQyxZQUFZLEVBQUUsSUFBSSxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsQ0FBQztRQUNsRixJQUFJLElBQUksQ0FBQyxLQUFLLENBQUMsS0FBSyxFQUFFO1lBQ2xCLElBQUksQ0FBQyxXQUFXLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxDQUFDO1lBQ25DLElBQUksQ0FBQyxXQUFXLEVBQUUsQ0FBQztTQUN0QjthQUFNO1lBQ0gsSUFBSSxDQUFDLHVCQUF1QixFQUFFLENBQUM7U0FDbEM7SUFDTCxDQUFDO0lBRUQsaUNBQWlDO0lBQ2pDLHlGQUF5RjtJQUN6RiwwQ0FBMEM7SUFDMUMsSUFBSTtJQUVJLDJCQUFVLEdBQWxCO1FBQ0ksSUFBSSxDQUFDLGFBQWEsRUFBRSxDQUFDO1FBQ3JCLElBQUksV0FBVyxHQUFZLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxRQUFRLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLGFBQWEsQ0FBQyxlQUFlLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxhQUFhLENBQUMsZUFBZSxDQUFDLENBQUM7UUFDbkosV0FBVyxDQUFDLFNBQVMsR0FBRyxDQUFDLENBQUM7UUFDMUIsSUFBSSxDQUFDLFVBQVUsQ0FBQyxJQUFJLEVBQUUsQ0FBQztJQUMzQixDQUFDO0lBRU8sOEJBQWEsR0FBckI7UUFBQSxpQkFNQztRQUxHLElBQUksQ0FBQyxLQUFLLEdBQUcsSUFBSSxDQUFDLFVBQVUsQ0FBQyxjQUFjLEVBQUUsQ0FBQztRQUM5QyxLQUFLLENBQUMsRUFBRSxDQUFDLENBQUMsU0FBUyxDQUFDO1lBQ2hCLEtBQUksQ0FBQyxZQUFZLEdBQUcsS0FBSSxDQUFDLFVBQVUsQ0FBQyxlQUFlLENBQUMsS0FBSSxDQUFDLFNBQVMsRUFBRSxLQUFJLENBQUMsV0FBVyxDQUFDLENBQUM7WUFDdEYsS0FBSSxDQUFDLEtBQUssR0FBRyxLQUFJLENBQUMsVUFBVSxDQUFDLFdBQVcsQ0FBQyxLQUFJLENBQUMsWUFBWSxDQUFDLENBQUM7UUFDaEUsQ0FBQyxDQUFDLENBQUM7SUFDUCxDQUFDO0lBRU8sNEJBQVcsR0FBbkI7UUFDSSxJQUFJLENBQUMsUUFBUSxHQUFHLENBQUMsT0FBTyxJQUFJLENBQUMsTUFBTSxLQUFLLFdBQVcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsY0FBYyxFQUFFLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxhQUFhLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDO0lBQ25ILENBQUM7SUFFTywrQkFBYyxHQUF0QjtRQUNJLElBQUksVUFBVSxHQUFlLENBQUM7Z0JBQzFCLElBQUksRUFBRSxRQUFRO2dCQUNkLElBQUksRUFBRSxRQUFRO2dCQUNkLElBQUksRUFBRSxVQUFVO2dCQUNoQixLQUFLLEVBQUUsVUFBVTtnQkFDakIsUUFBUSxFQUFFLEtBQUs7YUFDbEIsRUFBRTtnQkFDQyxJQUFJLEVBQUUsT0FBTztnQkFDYixJQUFJLEVBQUUsT0FBTztnQkFDYixLQUFLLEVBQUUsYUFBYTtnQkFDcEIsSUFBSSxFQUFFLFVBQVU7Z0JBQ2hCLFFBQVEsRUFBRSxLQUFLO2FBQ2xCLENBQUMsQ0FBQztRQUNILE9BQU8sVUFBVSxDQUFDO0lBQ3RCLENBQUM7SUFFTyw4QkFBYSxHQUFyQixVQUFzQixJQUFnQjtRQUF0QyxpQkFpQkM7UUFoQkcsSUFBSSxVQUFVLEdBQWUsRUFBRSxDQUFDO1FBQ2hDLElBQUksWUFBWSxHQUFXLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxNQUFNLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUM7UUFDN0UsS0FBSyxJQUFJLENBQUMsR0FBVyxDQUFDLEVBQUUsQ0FBQyxHQUFHLFlBQVksRUFBRSxDQUFDLEVBQUUsRUFBRTtZQUMzQyxJQUFJLElBQUksR0FBUSxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUM7WUFDeEIsSUFBSSxPQUFPLElBQUksQ0FBQyxJQUFJLEtBQUssV0FBVztnQkFBRSxJQUFJLENBQUMsSUFBSSxHQUFHLFdBQVcsQ0FBQztZQUM5RCxJQUFJLE9BQU8sSUFBSSxDQUFDLEtBQUssS0FBSyxXQUFXO2dCQUFFLElBQUksQ0FBQyxLQUFLLEdBQUcsY0FBYyxDQUFDO1lBQ25FLElBQUksT0FBTyxJQUFJLENBQUMsSUFBSSxLQUFLLFdBQVc7Z0JBQUUsSUFBSSxDQUFDLElBQUksR0FBRyxRQUFRLENBQUM7WUFDM0QsSUFBSSxPQUFPLElBQUksQ0FBQyxRQUFRLEtBQUssV0FBVztnQkFBRSxJQUFJLENBQUMsUUFBUSxHQUFHLEtBQUssQ0FBQztZQUNoRSxJQUFJLElBQUksQ0FBQyxJQUFJLEtBQUssT0FBTyxFQUFFO2dCQUN2QixJQUFJLENBQUMsUUFBUSxHQUFHO29CQUNaLEtBQUksQ0FBQyxVQUFVLEVBQUUsQ0FBQztnQkFDdEIsQ0FBQyxDQUFDO2FBQ0w7WUFDRCxVQUFVLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDO1NBQ3pCO1FBQ0QsT0FBTyxVQUFVLENBQUM7SUFDdEIsQ0FBQztJQUVPLGlDQUFnQixHQUF4QixVQUF5QixTQUFxQixFQUFFLFVBQWU7UUFDM0QsSUFBSSxjQUFjLEdBQVEsTUFBTSxDQUFDLE1BQU0sQ0FBQyxFQUFFLEVBQUUsVUFBVSxDQUFDLENBQUM7UUFDeEQsS0FBSyxJQUFJLENBQUMsR0FBVyxDQUFDLEVBQUUsQ0FBQyxHQUFHLFNBQVMsQ0FBQyxNQUFNLEVBQUUsQ0FBQyxFQUFFLEVBQUU7WUFDL0MsSUFBSSxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsV0FBVyxLQUFLLFNBQVMsSUFBSSxjQUFjLElBQUksT0FBTyxjQUFjLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxLQUFLLFdBQVcsRUFBRTtnQkFDckgsT0FBTyxjQUFjLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDO2FBQzNDO2lCQUNJLElBQUksT0FBTyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxLQUFLLFdBQVcsSUFBSSxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxFQUFFO2dCQUM1RSxPQUFPLGNBQWMsQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUM7YUFDM0M7U0FDSjtRQUNELE9BQU8sY0FBYyxDQUFDO0lBQzFCLENBQUM7SUFFRCxxQkFBcUI7SUFDZCxzQ0FBcUIsR0FBNUIsVUFBNkIsV0FBZ0I7UUFDekMsSUFBSSxDQUFDLGVBQWUsQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFDLENBQUM7SUFDM0MsQ0FBQztJQUVNLG1DQUFrQixHQUF6QixVQUEwQixXQUFnQjtRQUN0QyxJQUFJLENBQUMsaUJBQWlCLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxDQUFDO0lBQzdDLENBQUM7O2dCQTlVdUIscUJBQXFCO2dCQUNyQixXQUFXO2dCQUNkLFlBQVk7Z0JBQ1QsU0FBUztnQkFDUixlQUFlO2dCQUNmLFVBQVU7O0lBcEIxQjtRQUFSLEtBQUssRUFBRTtrQ0FBWSxLQUFLOzZDQUFNO0lBQ3RCO1FBQVIsS0FBSyxFQUFFO2tDQUFTLEtBQUs7MENBQU07SUFDbkI7UUFBUixLQUFLLEVBQUU7OytDQUFxQjtJQUNwQjtRQUFSLEtBQUssRUFBRTs7dUNBQXNCO0lBQ3BCO1FBQVQsTUFBTSxFQUFFO2tDQUFhLFlBQVk7OENBQTJCO0lBQ25EO1FBQVQsTUFBTSxFQUFFO2tDQUFxQixZQUFZO3NEQUEyQjtJQUMzRDtRQUFULE1BQU0sRUFBRTtrQ0FBYyxZQUFZOytDQUEyQjtJQUNwRDtRQUFULE1BQU0sRUFBRTtrQ0FBYSxZQUFZOzhDQUEyQjtJQUNuRDtRQUFULE1BQU0sRUFBRTtrQ0FBYyxZQUFZOytDQUEyQjtJQUN2QztRQUF0QixZQUFZLENBQUMsT0FBTyxDQUFDO2tDQUFpQixLQUFLO2tEQUFVO0lBRTVDO1FBQVQsTUFBTSxFQUFFO2tDQUFrQixZQUFZO21EQUE0RTtJQUN6RztRQUFULE1BQU0sRUFBRTtrQ0FBb0IsWUFBWTtxREFBdUU7SUF2QnZHLE1BQU07UUFUbEIsU0FBUyxDQUFDO1lBQ1AsUUFBUSxFQUFFLFNBQVM7WUFDbkIsZzlPQUFxQztZQUNyQyxTQUFTLEVBQUUsQ0FBQyxxQkFBcUIsRUFBRSxXQUFXLEVBQUUsWUFBWSxFQUFFLFNBQVMsRUFBRSxlQUFlLENBQUM7WUFDekYsSUFBSSxFQUFFO2dCQUNGLE9BQU8sRUFBRSxVQUFVO2FBQ3RCO1NBQ0osQ0FBQzt5Q0E0QjBCLHFCQUFxQjtZQUNyQixXQUFXO1lBQ2QsWUFBWTtZQUNULFNBQVM7WUFDUixlQUFlO1lBQ2YsVUFBVTtPQS9CMUIsTUFBTSxDQXlXbEI7SUFBRCxhQUFDO0NBQUEsQUF6V0QsSUF5V0M7U0F6V1ksTUFBTSIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7XHJcbiAgICBDb21wb25lbnQsXHJcbiAgICBJbnB1dCxcclxuICAgIE91dHB1dCxcclxuICAgIEV2ZW50RW1pdHRlcixcclxuICAgIE9uSW5pdCxcclxuICAgIE9uRGVzdHJveSxcclxuICAgIE9uQ2hhbmdlcyxcclxuICAgIFZpZXdDaGlsZHJlbixcclxuICAgIEVsZW1lbnRSZWZcclxufSBmcm9tICdAYW5ndWxhci9jb3JlJztcclxuaW1wb3J0IHsgdGltZXIgLCAgU3Vic2NyaXB0aW9uIH0gZnJvbSAncnhqcyc7XHJcbmltcG9ydCB7IEZvcm1Hcm91cCB9IGZyb20gJ0Bhbmd1bGFyL2Zvcm1zJztcclxuaW1wb3J0IHsgS2RJbnB1dCB9IGZyb20gJy4uL2tkLWFuZ3VsYXItaW5wdXQva2QtYW5ndWxhci1pbnB1dCc7XHJcbmltcG9ydCB7IElucHV0QmFzZSB9IGZyb20gJy4uL2tkLWFuZ3VsYXItaW5wdXQvc3JjL2tkLWlucHV0LWJhc2UnO1xyXG5pbXBvcnQgeyBLZElucHV0Q29udHJvbFNlcnZpY2UgfSBmcm9tICcuLi9rZC1hbmd1bGFyLWlucHV0L3NyYy9rZC1hbmd1bGFyLWZvcm0uY29udHJvbCc7XHJcbmltcG9ydCB7IEtkRm9ybUV2ZW50IH0gZnJvbSAnLi9zcmMva2QtZm9ybS1ldmVudCc7XHJcbmltcG9ydCB7IEtkRG9tRWxlbVN2YywgS2RDb252ZXJ0aW9uU3ZjIH0gZnJvbSAnLi4va2QtY29tbW9uL2luZGV4JztcclxuaW1wb3J0IHsgS2RWaWV3U3ZjIH0gZnJvbSAnLi9rZC1hbmd1bGFyLXZpZXctc3ZjJztcclxuaW1wb3J0IHsgSVRyZWVBcGkgfSBmcm9tICcuLi9rZC1hbmd1bGFyLXRyZWVkcm9wZG93bi9rZC10cmVlZHJvcGRvd24taW50ZXJmYWNlJztcclxuaW1wb3J0IHsgSUR5bmFtaWNGb3JtQXBpLCBJRHluYW1pY0Zvcm1UYWJsZUFwaSB9IGZyb20gJy4va2QtYW5ndWxhci12aWV3LWludGVyZmFjZSc7XHJcblxyXG5pbXBvcnQge1xyXG4gICAgSVRhYmxlQXBpLFxyXG4gICAgSVRhYmxlQ2VsbFBhcmFtcyxcclxuICAgIEtkVGFibGVJbnB1dFVwZGF0ZUV2ZW50LFxyXG4gICAgS2RUYWJsZUJ1dHRvbkV2ZW50LFxyXG4gICAgSVRhYmxlRm9ybVVwZGF0ZVBhcmFtcyxcclxufSBmcm9tICcuLi9rZC1hbmd1bGFyLXRhYmxlL2luZGV4JztcclxuXHJcbmltcG9ydCB7IElTbGlkZXJBcGkgfSBmcm9tICcuLi9rZC1hbmd1bGFyLXNsaWRlci9pbmRleCc7XHJcblxyXG5AQ29tcG9uZW50KHtcclxuICAgIHNlbGVjdG9yOiAna2QtdmlldycsXHJcbiAgICB0ZW1wbGF0ZVVybDogJy4va2QtYW5ndWxhci12aWV3Lmh0bWwnLFxyXG4gICAgcHJvdmlkZXJzOiBbS2RJbnB1dENvbnRyb2xTZXJ2aWNlLCBLZEZvcm1FdmVudCwgS2REb21FbGVtU3ZjLCBLZFZpZXdTdmMsIEtkQ29udmVydGlvblN2Y10sXHJcbiAgICBob3N0OiB7XHJcbiAgICAgICAgJ2NsYXNzJzogJ2tkeC12aWV3J1xyXG4gICAgfVxyXG59KVxyXG5cclxuZXhwb3J0IGNsYXNzIEtkVmlldyBpbXBsZW1lbnRzIE9uSW5pdCwgT25EZXN0cm95LCBPbkNoYW5nZXMge1xyXG4gICAgcHVibGljIF9kZlF1ZXN0aW9uczogQXJyYXk8YW55PiA9IFtdO1xyXG4gICAgcHVibGljIF9kaXNwbGF5VHlwZTogc3RyaW5nO1xyXG4gICAgcHVibGljIGlzU3RhY2tlZEZyb206IGJvb2xlYW47XHJcblxyXG4gICAgcHVibGljIF9mb3JtOiBGb3JtR3JvdXA7XHJcbiAgICBwdWJsaWMgX2Zvcm1CdG46IEFycmF5PGFueT4gPSBbXTtcclxuICAgIHByaXZhdGUgX2ZpcnN0TG9hZDogYm9vbGVhbiA9IHRydWU7XHJcbiAgICBwcml2YXRlIF9mb3JtRHJvcGRvd25TdWI6IFN1YnNjcmlwdGlvbjtcclxuICAgIHByaXZhdGUgX2Zvcm1WaXNpYmxlU3ViOiBTdWJzY3JpcHRpb247XHJcblxyXG4gICAgQElucHV0KCkgaW5wdXREYXRhOiBBcnJheTxhbnk+O1xyXG4gICAgQElucHV0KCkgYnV0dG9uOiBBcnJheTxhbnk+O1xyXG4gICAgQElucHV0KCkgZGlzcGxheVR5cGU6IHN0cmluZztcclxuICAgIEBJbnB1dCgpIGFwaTogSUR5bmFtaWNGb3JtQXBpO1xyXG4gICAgQE91dHB1dCgpIGRldGVjdEZyb206IEV2ZW50RW1pdHRlcjxhbnk+ID0gbmV3IEV2ZW50RW1pdHRlcigpO1xyXG4gICAgQE91dHB1dCgpIGRldGVjdEdyaWRRdWVzdGlvbjogRXZlbnRFbWl0dGVyPGFueT4gPSBuZXcgRXZlbnRFbWl0dGVyKCk7XHJcbiAgICBAT3V0cHV0KCkgc3VibWl0RXZlbnQ6IEV2ZW50RW1pdHRlcjxhbnk+ID0gbmV3IEV2ZW50RW1pdHRlcigpO1xyXG4gICAgQE91dHB1dCgpIHJlc2V0RXZlbnQ6IEV2ZW50RW1pdHRlcjxhbnk+ID0gbmV3IEV2ZW50RW1pdHRlcigpO1xyXG4gICAgQE91dHB1dCgpIGJ1dHRvbkV2ZW50OiBFdmVudEVtaXR0ZXI8YW55PiA9IG5ldyBFdmVudEVtaXR0ZXIoKTtcclxuICAgIEBWaWV3Q2hpbGRyZW4oS2RJbnB1dCkgaW5wdXRDb21wb25lbnQ6IEFycmF5PEtkSW5wdXQ+O1xyXG5cclxuICAgIEBPdXRwdXQoKSBncmlkQ2VsbENoYW5nZWQ6IEV2ZW50RW1pdHRlcjx7IGZvcm1LZXk6IHN0cmluZywgcGFyYW1zOiBLZFRhYmxlSW5wdXRVcGRhdGVFdmVudCB9PiA9IG5ldyBFdmVudEVtaXR0ZXIoKTtcclxuICAgIEBPdXRwdXQoKSBncmlkQnV0dG9uQ2xpY2tlZDogRXZlbnRFbWl0dGVyPHsgZm9ybUtleTogc3RyaW5nLCBwYXJhbXM6IEtkVGFibGVCdXR0b25FdmVudCB9PiA9IG5ldyBFdmVudEVtaXR0ZXIoKTtcclxuXHJcbiAgICBjb25zdHJ1Y3RvcihcclxuICAgICAgICBwcml2YXRlIF9kZkNvbnRyb2w6IEtkSW5wdXRDb250cm9sU2VydmljZSxcclxuICAgICAgICBwcml2YXRlIF9mb3JtRXZlbnQ6IEtkRm9ybUV2ZW50LFxyXG4gICAgICAgIHByaXZhdGUgX2RvbVN2YzogS2REb21FbGVtU3ZjLFxyXG4gICAgICAgIHByaXZhdGUgX2tkVmlld1N2YzogS2RWaWV3U3ZjLFxyXG4gICAgICAgIHByaXZhdGUgX2NvbnZlcnRTdmM6IEtkQ29udmVydGlvblN2YyxcclxuICAgICAgICBwcml2YXRlIF9lbGVtZW50UmVmOiBFbGVtZW50UmVmXHJcbiAgICApIHsgfVxyXG5cclxuICAgIG5nT25Jbml0KCk6IHZvaWQge1xyXG5cclxuICAgICAgICB0aGlzLl9kaXNwbGF5VHlwZSA9IHRoaXMuZGlzcGxheVR5cGU7IC8vICh0eXBlb2YgdGhpcy5kaXNwbGF5VHlwZSAhPT0gJ3VuZGVmaW5lZCcpID8gdGhpcy5kaXNwbGF5VHlwZSA6ICd2aWV3JztcclxuICAgICAgICB0aGlzLmlzU3RhY2tlZEZyb20gPSB0aGlzLl9kaXNwbGF5VHlwZSA9PT0gJ3N0YWNrZWQtZm9ybSc7XHJcblxyXG4gICAgICAgIHRoaXMuX3NldFF1ZXN0aW9ucygpO1xyXG4gICAgICAgIHRoaXMuX3NldEJ1dHRvbnMoKTtcclxuICAgICAgICB0aGlzLl91cGRhdGVGb3JtQXBpKCk7XHJcblxyXG4gICAgICAgIHRoaXMuX2Zvcm1WaXNpYmxlU3ViID0gdGhpcy5fZm9ybUV2ZW50Lm9uU2V0VmlzaWFibGVJbnB1dCgpLnN1YnNjcmliZSh2YWwgPT4ge1xyXG4gICAgICAgICAgICBmb3IgKGxldCBpOiBudW1iZXIgPSAwOyBpIDwgdGhpcy5fZGZRdWVzdGlvbnMubGVuZ3RoOyBpKyspIHtcclxuICAgICAgICAgICAgICAgIGlmICh0aGlzLl9kZlF1ZXN0aW9uc1tpXS5rZXkgPT09IHZhbC5rZXkpIHtcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLl9kZlF1ZXN0aW9uc1tpXS5zZXRWaXNpYmxlKHZhbC52aXNpYmxlKTtcclxuICAgICAgICAgICAgICAgICAgICBicmVhaztcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH0pO1xyXG5cclxuICAgICAgICB0aGlzLl9mb3JtRHJvcGRvd25TdWIgPSB0aGlzLl9mb3JtRXZlbnQub25TZXREcm9wZG93bkxpc3QoKS5zdWJzY3JpYmUodmFsID0+IHtcclxuICAgICAgICAgICAgZm9yIChsZXQgaTogbnVtYmVyID0gMDsgaSA8IHRoaXMuX2RmUXVlc3Rpb25zLmxlbmd0aDsgaSsrKSB7XHJcbiAgICAgICAgICAgICAgICBpZiAodGhpcy5fZGZRdWVzdGlvbnNbaV0ua2V5ID09PSB2YWwua2V5KSB7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5fZGZRdWVzdGlvbnNbaV0uc2V0T3B0aW9ucyh2YWwub3B0aW9ucyk7XHJcbiAgICAgICAgICAgICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9KTtcclxuXHJcbiAgICAgICAgdGhpcy5fZmlyc3RMb2FkID0gZmFsc2U7XHJcbiAgICAgICAgLy8gY29uc29sZS5sb2coJ0tkVmlldyAtIHRoaXMgaXMgdGhlIHZpZXcganVzdCBpbml0aWFsaXplZCcsIHRoaXMuaW5wdXREYXRhKTtcclxuICAgIH1cclxuXHJcbiAgICBuZ09uQ2hhbmdlcygpOiB2b2lkIHtcclxuICAgICAgICBpZiAoIXRoaXMuX2ZpcnN0TG9hZCkge1xyXG4gICAgICAgICAgICAvLyBjb25zb2xlLmxvZygnS2RWaWV3IC0gdGhpcyBpcyB0aGUgdmlldyBjaGFuZ2UgZXZlbnQnLCB0aGlzLmlucHV0RGF0YSk7XHJcbiAgICAgICAgICAgIHRoaXMuX2Rpc3BsYXlUeXBlID0gKHR5cGVvZiB0aGlzLmRpc3BsYXlUeXBlICE9PSAndW5kZWZpbmVkJykgPyB0aGlzLmRpc3BsYXlUeXBlIDogJ3ZpZXcnO1xyXG4gICAgICAgICAgICB0aGlzLl9zZXRRdWVzdGlvbnMoKTtcclxuICAgICAgICAgICAgdGhpcy5fc2V0QnV0dG9ucygpO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICBuZ09uRGVzdHJveSgpOiB2b2lkIHtcclxuICAgICAgICBpZih0aGlzLl9mb3JtVmlzaWJsZVN1YikgdGhpcy5fZm9ybVZpc2libGVTdWIudW5zdWJzY3JpYmUoKTtcclxuICAgICAgICBpZih0aGlzLl9mb3JtRHJvcGRvd25TdWIpIHRoaXMuX2Zvcm1Ecm9wZG93blN1Yi51bnN1YnNjcmliZSgpO1xyXG4gICAgfVxyXG5cclxuICAgIHB1YmxpYyBnZXRJbnB1dFByb3BlcnR5KGtleTogc3RyaW5nLCBwcm9wZXJ0eU5hbWU6IHN0cmluZyk6IGFueSB7XHJcbiAgICAgICAgZm9yIChsZXQgaTogbnVtYmVyID0gMDsgaSA8IHRoaXMuX2RmUXVlc3Rpb25zLmxlbmd0aDsgaSsrKSB7XHJcbiAgICAgICAgICAgIGlmICh0aGlzLl9kZlF1ZXN0aW9uc1tpXS5nZXRQcm9wZXJ0eSgna2V5JykgPT09IGtleSkgcmV0dXJuIHRoaXMuX2RmUXVlc3Rpb25zW2ldLmdldFByb3BlcnR5KHByb3BlcnR5TmFtZSk7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIHB1YmxpYyBzZXRJbnB1dFByb3BlcnR5KGtleTogc3RyaW5nLCBwcm9wZXJ0eU5hbWU6IHN0cmluZywgZGF0YTogYW55KTogdm9pZCB7XHJcbiAgICAgICAgZm9yIChsZXQgaTogbnVtYmVyID0gMDsgaSA8IHRoaXMuX2RmUXVlc3Rpb25zLmxlbmd0aDsgaSsrKSB7XHJcbiAgICAgICAgICAgIGlmICh0aGlzLl9kZlF1ZXN0aW9uc1tpXS5nZXRQcm9wZXJ0eSgna2V5JykgPT09IGtleSkge1xyXG4gICAgICAgICAgICAgICAgaWYgKHByb3BlcnR5TmFtZSAhPT0gJ3Zpc2libGUnKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5fZGZRdWVzdGlvbnNbaV0uc2V0UHJvcGVydHkocHJvcGVydHlOYW1lLCBkYXRhKTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuX2RmUXVlc3Rpb25zW2ldLnNldFZpc2libGUoZGF0YSk7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICBicmVhaztcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICBwdWJsaWMgcmVzZXRHcmlkSGVpZ2h0KF9ncmlkSWQ6IHN0cmluZyk6IHZvaWQge1xyXG4gICAgICAgIHRoaXMuaW5wdXRDb21wb25lbnQuZm9yRWFjaCgoaXRlbTogS2RJbnB1dCk6IHZvaWQgPT4ge1xyXG4gICAgICAgICAgICBpZiAoX2dyaWRJZCA9PT0gaXRlbS5xdWVzdGlvbi5nZXRQcm9wZXJ0eSgna2V5JykpIHtcclxuICAgICAgICAgICAgICAgIGl0ZW0ucmVzZXRIZWlnaHQoKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH0pO1xyXG4gICAgfVxyXG5cclxuICAgIC8vLy8vIFRhYmxlIGNvbnRyb2x0eXBlXHJcbiAgICBwdWJsaWMgdXBkYXRlVGFibGVDZWxsKF9xdWVzdGlvbktleTogc3RyaW5nLCBfY2VsbFBhcmFtczogSVRhYmxlQ2VsbFBhcmFtcyk6IHZvaWQge1xyXG4gICAgICAgIHRoaXMuaW5wdXRDb21wb25lbnQuZm9yRWFjaCgoaXRlbTogS2RJbnB1dCk6IHZvaWQgPT4ge1xyXG4gICAgICAgICAgICBpZiAoX3F1ZXN0aW9uS2V5ID09PSBpdGVtLnF1ZXN0aW9uLmdldFByb3BlcnR5KCdrZXknKSkge1xyXG4gICAgICAgICAgICAgICAgaXRlbS5zZXRUYWJsZUNlbGxEYXRhKF9jZWxsUGFyYW1zKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH0pO1xyXG4gICAgfVxyXG5cclxuICAgIHB1YmxpYyB1cGRhdGVUYWJsZUNlbGxQcm9wZXJ0eShfcXVlc3Rpb25LZXk6IHN0cmluZywgX2NlbGxQYXJhbXM6IElUYWJsZUZvcm1VcGRhdGVQYXJhbXMpOiB2b2lkIHtcclxuICAgICAgICB0aGlzLmlucHV0Q29tcG9uZW50LmZvckVhY2goKGl0ZW06IEtkSW5wdXQpOiB2b2lkID0+IHtcclxuICAgICAgICAgICAgaWYgKF9xdWVzdGlvbktleSA9PT0gaXRlbS5xdWVzdGlvbi5nZXRQcm9wZXJ0eSgna2V5JykpIHtcclxuICAgICAgICAgICAgICAgIGl0ZW0uc2V0VGFibGVDZWxsUXVlc3Rpb25Qcm9wZXJ0eShfY2VsbFBhcmFtcyk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9KTtcclxuICAgIH1cclxuICAgIC8vLy8vLy8vIHRpbGwgaGVyZVxyXG5cclxuICAgIHB1YmxpYyBzZXRCdXR0b25EaXNhYmxlZChfdHlwZTogc3RyaW5nLCBfZGlzYWJsZWQ6IGJvb2xlYW4pOiB2b2lkIHtcclxuICAgICAgICBmb3IgKGxldCBpOiBudW1iZXIgPSAwOyBpIDwgdGhpcy5fZm9ybUJ0bi5sZW5ndGg7IGkrKykge1xyXG4gICAgICAgICAgICBpZiAoX3R5cGUgPT09IHRoaXMuX2Zvcm1CdG5baV0udHlwZSkge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5fZm9ybUJ0bltpXS5kaXNhYmxlZCA9IF9kaXNhYmxlZDtcclxuICAgICAgICAgICAgICAgIHRoaXMuX2Zvcm1CdG4gPSB0aGlzLl9mb3JtQnRuLnNsaWNlKCk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgcHVibGljIGlzRm9ybU9yU3RhY2tlZEZvcm0oKTogc3RyaW5nIHtcclxuICAgICAgICBpZiAodGhpcy5fZGlzcGxheVR5cGUgPT09ICdmb3JtJyB8fCB0aGlzLl9kaXNwbGF5VHlwZSA9PT0gJ3N0YWNrZWQtZm9ybScpIHtcclxuICAgICAgICAgICAgcmV0dXJuIHRoaXMuX2Rpc3BsYXlUeXBlO1xyXG4gICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgIHJldHVybiAnLSc7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIC8vIGNoYW5nZSB0byBwdWJsaWMgZHVlIHRvIGxpbnRcclxuICAgIHB1YmxpYyBjaGFuZ2VEZXRlY3RGb3JtKF9xdWVzdGlvbjogSW5wdXRCYXNlPGFueT4pOiB2b2lkIHtcclxuICAgICAgICB0aGlzLmRldGVjdEZyb20uZW1pdChfcXVlc3Rpb24pO1xyXG4gICAgfVxyXG5cclxuICAgIC8vIGNoYW5nZSB0byBwdWJsaWMgZHVlIHRvIGxpbnRcclxuICAgIHB1YmxpYyBjaGFuZ2VEZXRlY3RGcm9tR3JpZChfZ3JpZENlbGxRdWVzdGlvbjogYW55KTogdm9pZCB7XHJcbiAgICAgICAgdGhpcy5kZXRlY3RHcmlkUXVlc3Rpb24uZW1pdChfZ3JpZENlbGxRdWVzdGlvbik7XHJcbiAgICB9XHJcblxyXG4gICAgLyoqKioqKioqKioqKioqKioqKioqKioqKiBEeW5hbWljIEZvcm0gQVBJIHVwZGF0ZXMgKioqKioqKioqKioqKioqKioqKioqKioqKi9cclxuICAgIHByaXZhdGUgX3VwZGF0ZUZvcm1BcGkoKTogdm9pZCB7XHJcbiAgICAgICAgaWYgKHR5cGVvZiB0aGlzLmFwaSA9PT0gJ3VuZGVmaW5lZCcpIHtcclxuICAgICAgICAgICAgY29uc29sZS53YXJuKCdLZFZpZXcgd2FybmluZzogTm8gYXBpIG9iamVjdCBpcyBwYXNzZWQgaW4uIE5vIEFQSSB3aWxsIGJlIGluaXRpYWxpemUnKTtcclxuICAgICAgICAgICAgcmV0dXJuO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgdGhpcy5hcGkuc3VibWl0Rm9ybSA9ICgpOiB2b2lkID0+IHtcclxuICAgICAgICAgICAgdGhpcy5fc3VibWl0Q2xpY2soKTtcclxuICAgICAgICB9O1xyXG5cclxuICAgICAgICB0aGlzLmFwaS5zZXRQcm9wZXJ0eSA9IChfcXVlc3Rpb25LZXk6IHN0cmluZywgX3Byb3BlcnR5OiBzdHJpbmcsIF9kYXRhOiBhbnkpOiB2b2lkID0+IHtcclxuICAgICAgICAgICAgZm9yIChsZXQgaTogbnVtYmVyID0gMDsgaSA8IHRoaXMuX2RmUXVlc3Rpb25zLmxlbmd0aDsgaSsrKSB7XHJcbiAgICAgICAgICAgICAgICBpZiAodGhpcy5fZGZRdWVzdGlvbnNbaV0uZ2V0UHJvcGVydHkoJ2tleScpID09PSBfcXVlc3Rpb25LZXkpIHtcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLl9kZlF1ZXN0aW9uc1tpXS5zZXRQcm9wZXJ0eShfcHJvcGVydHksIF9kYXRhKTtcclxuICAgICAgICAgICAgICAgICAgICBicmVhaztcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH07XHJcblxyXG4gICAgICAgIHRoaXMuYXBpLmdldFByb3BlcnR5ID0gKF9xdWVzdGlvbktleTogc3RyaW5nLCBfcHJvcGVydHk6IHN0cmluZyk6IGFueSA9PiB7XHJcbiAgICAgICAgICAgIGZvciAobGV0IGk6IG51bWJlciA9IDA7IGkgPCB0aGlzLl9kZlF1ZXN0aW9ucy5sZW5ndGg7IGkrKykge1xyXG4gICAgICAgICAgICAgICAgaWYgKHRoaXMuX2RmUXVlc3Rpb25zW2ldLmdldFByb3BlcnR5KCdrZXknKSA9PT0gX3F1ZXN0aW9uS2V5KSB7XHJcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIHRoaXMuX2RmUXVlc3Rpb25zW2ldLmdldFByb3BlcnR5KF9wcm9wZXJ0eSk7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9O1xyXG5cclxuICAgICAgICB0aGlzLmFwaS50YWJsZSA9IChfcXVlc3Rpb25LZXk6IHN0cmluZyk6IElEeW5hbWljRm9ybVRhYmxlQXBpID0+IHtcclxuICAgICAgICAgICAgbGV0IHRhYmxlQXBpOiBJVGFibGVBcGk7XHJcblxyXG4gICAgICAgICAgICBmb3IgKGxldCBpOiBudW1iZXIgPSAwOyBpIDwgdGhpcy5fZGZRdWVzdGlvbnMubGVuZ3RoOyArK2kpIHtcclxuICAgICAgICAgICAgICAgIGlmICh0aGlzLl9kZlF1ZXN0aW9uc1tpXS5nZXRQcm9wZXJ0eSgna2V5JykgPT09IF9xdWVzdGlvbktleSkge1xyXG4gICAgICAgICAgICAgICAgICAgIHRhYmxlQXBpID0gdGhpcy5fZGZRdWVzdGlvbnNbaV0uZ2V0UHJvcGVydHkoJ2FwaScpO1xyXG4gICAgICAgICAgICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICByZXR1cm4ge1xyXG4gICAgICAgICAgICAgICAgc2V0VGFibGVDZWxsSW5wdXRQcm9wZXJ0eTogKF9mb3JtUGFyYW1zOiBJVGFibGVGb3JtVXBkYXRlUGFyYW1zKTogdm9pZCA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgdGFibGVBcGkuZHluYW1pY0Zvcm0uc2V0UHJvcGVydHkoX2Zvcm1QYXJhbXMpO1xyXG4gICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICAgIHVwZGF0ZVRhYmxlQ2VsbFByb3BlcnR5OiAoX2NlbGxQYXJhbXM6IElUYWJsZUNlbGxQYXJhbXMpOiB2b2lkID0+IHtcclxuICAgICAgICAgICAgICAgICAgICB0YWJsZUFwaS5nZW5lcmFsLnVwZGF0ZUNlbGwoX2NlbGxQYXJhbXMpO1xyXG4gICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICAgIGdldFRhYmxlQ2VsbElucHV0UHJvcGVydHk6IChfZm9ybVBhcmFtczogSVRhYmxlRm9ybVVwZGF0ZVBhcmFtcyk6IHZvaWQgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgIHRhYmxlQXBpLmR5bmFtaWNGb3JtLmdldFByb3BlcnR5KF9mb3JtUGFyYW1zKTtcclxuICAgICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICAgICBhZGRSb3c6IChfcm93czogQXJyYXk8YW55PiwgX3Njcm9sbFRvVmlzaWJsZTogYm9vbGVhbiA9IGZhbHNlKTogdm9pZCA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgdGFibGVBcGkuZ2VuZXJhbC5hZGRSb3dzKF9yb3dzLCBfc2Nyb2xsVG9WaXNpYmxlKTtcclxuICAgICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICAgICBkZWxldGVSb3dzOiAoX2lkOiBBcnJheTxzdHJpbmcgfCBudW1iZXI+IHwgbnVtYmVyIHwgc3RyaW5nKTogdm9pZCA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgdGFibGVBcGkuZ2VuZXJhbC5kZWxldGVSb3dzKF9pZCk7XHJcbiAgICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgICAgY2xlYXJFcnJvcjogKCk6IHZvaWQgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgIHRhYmxlQXBpLmR5bmFtaWNGb3JtLmNsZWFyQWxsRXJyb3IoKTtcclxuICAgICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICAgICBzZXRCdXR0b25EaXNhYmxlZDogKF9idXR0b25UeXBlOiBzdHJpbmcsIF90b0Rpc2FibGVkOiBib29sZWFuKTogdm9pZCA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgdGFibGVBcGkuZ2VuZXJhbC5zZXRCdXR0b25EaXNhYmxlZChfYnV0dG9uVHlwZSwgX3RvRGlzYWJsZWQpO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9O1xyXG4gICAgICAgIH07XHJcblxyXG4gICAgICAgIHRoaXMuYXBpLnRyZWVkcm9wZG93biA9IChfcXVlc3Rpb25LZXk6IHN0cmluZyk6IElUcmVlQXBpID0+IHtcclxuICAgICAgICAgICAgbGV0IHRyZWVBcGk6IElUcmVlQXBpO1xyXG4gICAgICAgICAgICBmb3IgKGxldCBpOiBudW1iZXIgPSAwOyBpIDwgdGhpcy5fZGZRdWVzdGlvbnMubGVuZ3RoOyArK2kpIHtcclxuICAgICAgICAgICAgICAgIGlmICh0aGlzLl9kZlF1ZXN0aW9uc1tpXS5nZXRQcm9wZXJ0eSgna2V5JykgPT09IF9xdWVzdGlvbktleSkge1xyXG4gICAgICAgICAgICAgICAgICAgIHRyZWVBcGkgPSB0aGlzLl9kZlF1ZXN0aW9uc1tpXS5nZXRQcm9wZXJ0eSgnYXBpJyk7XHJcbiAgICAgICAgICAgICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgcmV0dXJuIHRyZWVBcGk7XHJcbiAgICAgICAgfTtcclxuXHJcbiAgICAgICAgdGhpcy5hcGkuc2xpZGVyQXBpID0gKF9xdWVzdGlvbktleTogc3RyaW5nKTogSVNsaWRlckFwaSA9PiB7XHJcbiAgICAgICAgICAgIGxldCBzbGlkZXJBcGk6IElTbGlkZXJBcGk7XHJcblxyXG4gICAgICAgICAgICBmb3IgKGxldCBpOiBudW1iZXIgPSAwOyBpIDwgdGhpcy5fZGZRdWVzdGlvbnMubGVuZ3RoOyArK2kpIHtcclxuICAgICAgICAgICAgICAgIGlmICh0aGlzLl9kZlF1ZXN0aW9uc1tpXS5nZXRQcm9wZXJ0eSgna2V5JykgPT09IF9xdWVzdGlvbktleSkge1xyXG4gICAgICAgICAgICAgICAgICAgIHNsaWRlckFwaSA9IHRoaXMuX2RmUXVlc3Rpb25zW2ldLmdldFByb3BlcnR5KCdhcGknKTtcclxuICAgICAgICAgICAgICAgICAgICBicmVhaztcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgcmV0dXJuIHNsaWRlckFwaTtcclxuICAgICAgICB9O1xyXG4gICAgfVxyXG5cclxuXHJcbiAgICBwdWJsaWMgX2J0bkNsaWNrKF9idG46IGFueSk6IHZvaWQge1xyXG4gICAgICAgIGlmIChfYnRuLnR5cGUgPT09ICdyZXNldCcpIHRoaXMuX3Jlc2V0Rm9ybSgpO1xyXG4gICAgICAgIGVsc2UgaWYgKF9idG4udHlwZSAhPT0gJ3N1Ym1pdCcpIHRoaXMuYnV0dG9uRXZlbnQuZW1pdChfYnRuKTtcclxuICAgICAgICAvLyBpZih0eXBlb2YgX2J0bi5jYWxsYmFjayA9PT0gJ2Z1bmN0aW9uJykgX2J0bi5jYWxsYmFjayh0aGlzLl9mb3JtLnZhbHVlKTtcclxuICAgICAgICAvLyBlbHNlIGlmKHR5cGVvZiBfYnRuLmNhbGxiYWNrID09PSAndW5kZWZpbmVkJyAmJiBfYnRuLnR5cGUgIT09ICdzdWJtaXQnKSBjb25zb2xlLmVycm9yKCdQbGVhc2UgcHJvdmlkZSBjYWxsYmFjaycpO1xyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX3Jlc2V0RXJyb3IoKTogdm9pZCB7XHJcbiAgICAgICAgZm9yIChsZXQgaSA9IDA7IGkgPCB0aGlzLl9kZlF1ZXN0aW9ucy5sZW5ndGg7ICsraSkge1xyXG4gICAgICAgICAgICB0aGlzLl9kZlF1ZXN0aW9uc1tpXS5zZXRQcm9wZXJ0eSgnZXJyb3JzJywgW10pO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF9nZXRGb3JtVmFsaWRhdGlvbkVycm9yKCk6IHZvaWQge1xyXG4gICAgICAgIGZvciAobGV0IGkgPSAwOyBpIDwgdGhpcy5fZGZRdWVzdGlvbnMubGVuZ3RoOyArK2kpIHtcclxuICAgICAgICAgICAgdGhpcy5fZGZRdWVzdGlvbnNbaV0uc2V0UHJvcGVydHkoJ2Vycm9ycycsIFtdKTtcclxuICAgICAgICAgICAgbGV0IGVycm9yQXJyOiBBcnJheTxzdHJpbmc+ID0gW107XHJcbiAgICAgICAgICAgIGNvbnN0IGVycm9yczoge30gPSB0aGlzLl9mb3JtLmdldCh0aGlzLl9kZlF1ZXN0aW9uc1tpXS5nZXRQcm9wZXJ0eSgna2V5JykpLmVycm9ycztcclxuICAgICAgICAgICAgaWYgKGVycm9ycyAhPT0gbnVsbCkge1xyXG4gICAgICAgICAgICAgICAgZm9yIChsZXQga2V5IGluIGVycm9ycykge1xyXG4gICAgICAgICAgICAgICAgICAgIGlmIChlcnJvcnMuaGFzT3duUHJvcGVydHkoa2V5KSkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBlcnJvckFyci5wdXNoKGVycm9yc1trZXldKTtcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICB0aGlzLl9kZlF1ZXN0aW9uc1tpXS5zZXRQcm9wZXJ0eSgnZXJyb3JzJywgZXJyb3JBcnIpO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIHB1YmxpYyBfc3VibWl0Q2xpY2soKTogdm9pZCB7XHJcbiAgICAgICAgbGV0IHVwZGF0ZWRGb3JtOiBhbnkgPSB0aGlzLl91cGRhdGVGb3JtVmFsdWUodGhpcy5fZGZRdWVzdGlvbnMsIHRoaXMuX2Zvcm0udmFsdWUpO1xyXG4gICAgICAgIGlmICh0aGlzLl9mb3JtLnZhbGlkKSB7XHJcbiAgICAgICAgICAgIHRoaXMuc3VibWl0RXZlbnQuZW1pdCh1cGRhdGVkRm9ybSk7XHJcbiAgICAgICAgICAgIHRoaXMuX3Jlc2V0RXJyb3IoKTtcclxuICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICB0aGlzLl9nZXRGb3JtVmFsaWRhdGlvbkVycm9yKCk7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIC8vIHByaXZhdGUgX3N1Ym1pdENsaWNrKCk6IHZvaWQge1xyXG4gICAgLy8gICAgIGxldCB1cGRhdGVkRm9ybTogYW55ID0gdGhpcy5fdXBkYXRlRm9ybVZhbHVlKHRoaXMuX2RmUXVlc3Rpb25zLCB0aGlzLl9mb3JtLnZhbHVlKTtcclxuICAgIC8vICAgICB0aGlzLnN1Ym1pdEV2ZW50LmVtaXQodXBkYXRlZEZvcm0pO1xyXG4gICAgLy8gfVxyXG5cclxuICAgIHByaXZhdGUgX3Jlc2V0Rm9ybSgpOiB2b2lkIHtcclxuICAgICAgICB0aGlzLl9zZXRRdWVzdGlvbnMoKTtcclxuICAgICAgICBsZXQgY29udGVudEJvZHk6IEVsZW1lbnQgPSAodGhpcy5fZG9tU3ZjLmlzTW9iaWxlKCkpID8gZG9jdW1lbnQuYm9keS5xdWVyeVNlbGVjdG9yKCcubWFpbi13cmFwcGVyJykgOiBkb2N1bWVudC5ib2R5LnF1ZXJ5U2VsZWN0b3IoJy5jb250ZW50LWFyZWEnKTtcclxuICAgICAgICBjb250ZW50Qm9keS5zY3JvbGxUb3AgPSAwO1xyXG4gICAgICAgIHRoaXMucmVzZXRFdmVudC5lbWl0KCk7XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfc2V0UXVlc3Rpb25zKCk6IHZvaWQge1xyXG4gICAgICAgIHRoaXMuX2Zvcm0gPSB0aGlzLl9kZkNvbnRyb2wuZW1wdHlGb3JtR3JvdXAoKTtcclxuICAgICAgICB0aW1lcig1MCkuc3Vic2NyaWJlKCgpOiB2b2lkID0+IHtcclxuICAgICAgICAgICAgdGhpcy5fZGZRdWVzdGlvbnMgPSB0aGlzLl9rZFZpZXdTdmMuY29udmVydERhdGFUeXBlKHRoaXMuaW5wdXREYXRhLCB0aGlzLl9jb252ZXJ0U3ZjKTtcclxuICAgICAgICAgICAgdGhpcy5fZm9ybSA9IHRoaXMuX2RmQ29udHJvbC50b0Zvcm1Hcm91cCh0aGlzLl9kZlF1ZXN0aW9ucyk7XHJcbiAgICAgICAgfSk7XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfc2V0QnV0dG9ucygpOiB2b2lkIHtcclxuICAgICAgICB0aGlzLl9mb3JtQnRuID0gKHR5cGVvZiB0aGlzLmJ1dHRvbiA9PT0gJ3VuZGVmaW5lZCcpID8gdGhpcy5fc2V0RGVmYXVsdEJ0bigpIDogdGhpcy5fc2V0Q3VzdG9tQnRuKHRoaXMuYnV0dG9uKTtcclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF9zZXREZWZhdWx0QnRuKCk6IEFycmF5PGFueT4ge1xyXG4gICAgICAgIGxldCBkZWZhdWx0QnRuOiBBcnJheTxhbnk+ID0gW3tcclxuICAgICAgICAgICAgdHlwZTogJ3N1Ym1pdCcsXHJcbiAgICAgICAgICAgIG5hbWU6ICdTdWJtaXQnLFxyXG4gICAgICAgICAgICBpY29uOiAna2QtY2hlY2snLFxyXG4gICAgICAgICAgICBjbGFzczogJ2J0bi10ZXh0JyxcclxuICAgICAgICAgICAgZGlzYWJsZWQ6IGZhbHNlXHJcbiAgICAgICAgfSwge1xyXG4gICAgICAgICAgICB0eXBlOiAncmVzZXQnLFxyXG4gICAgICAgICAgICBuYW1lOiAnUmVzZXQnLFxyXG4gICAgICAgICAgICBjbGFzczogJ2J0bi1vdXRsaW5lJyxcclxuICAgICAgICAgICAgaWNvbjogJ2tkLWNyb3NzJyxcclxuICAgICAgICAgICAgZGlzYWJsZWQ6IGZhbHNlXHJcbiAgICAgICAgfV07XHJcbiAgICAgICAgcmV0dXJuIGRlZmF1bHRCdG47XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfc2V0Q3VzdG9tQnRuKF9idG46IEFycmF5PGFueT4pOiBBcnJheTxhbnk+IHtcclxuICAgICAgICBsZXQgdXBkYXRlZEJ0bjogQXJyYXk8YW55PiA9IFtdO1xyXG4gICAgICAgIGxldCBidXR0b25MZW5ndGg6IG51bWJlciA9ICh0aGlzLmJ1dHRvbi5sZW5ndGggPiA0KSA/IDQgOiB0aGlzLmJ1dHRvbi5sZW5ndGg7XHJcbiAgICAgICAgZm9yIChsZXQgaTogbnVtYmVyID0gMDsgaSA8IGJ1dHRvbkxlbmd0aDsgaSsrKSB7XHJcbiAgICAgICAgICAgIGxldCBpdGVtOiBhbnkgPSBfYnRuW2ldO1xyXG4gICAgICAgICAgICBpZiAodHlwZW9mIGl0ZW0ubmFtZSA9PT0gJ3VuZGVmaW5lZCcpIGl0ZW0ubmFtZSA9ICdVbmRlZmluZWQnO1xyXG4gICAgICAgICAgICBpZiAodHlwZW9mIGl0ZW0uY2xhc3MgPT09ICd1bmRlZmluZWQnKSBpdGVtLmNsYXNzID0gJ2J0biBidG4tdGV4dCc7XHJcbiAgICAgICAgICAgIGlmICh0eXBlb2YgaXRlbS50eXBlID09PSAndW5kZWZpbmVkJykgaXRlbS50eXBlID0gJ2J1dHRvbic7XHJcbiAgICAgICAgICAgIGlmICh0eXBlb2YgaXRlbS5kaXNhYmxlZCA9PT0gJ3VuZGVmaW5lZCcpIGl0ZW0uZGlzYWJsZWQgPSBmYWxzZTtcclxuICAgICAgICAgICAgaWYgKGl0ZW0udHlwZSA9PT0gJ3Jlc2V0Jykge1xyXG4gICAgICAgICAgICAgICAgaXRlbS5jYWxsYmFjayA9ICgpOiB2b2lkID0+IHtcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLl9yZXNldEZvcm0oKTtcclxuICAgICAgICAgICAgICAgIH07XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgdXBkYXRlZEJ0bi5wdXNoKGl0ZW0pO1xyXG4gICAgICAgIH1cclxuICAgICAgICByZXR1cm4gdXBkYXRlZEJ0bjtcclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF91cGRhdGVGb3JtVmFsdWUoX3F1ZXN0aW9uOiBBcnJheTxhbnk+LCBfZm9ybVZhbHVlOiBhbnkpOiBhbnkge1xyXG4gICAgICAgIGxldCB1cGRhdGVkRm9ybVZhbDogYW55ID0gT2JqZWN0LmFzc2lnbih7fSwgX2Zvcm1WYWx1ZSk7XHJcbiAgICAgICAgZm9yIChsZXQgaTogbnVtYmVyID0gMDsgaSA8IF9xdWVzdGlvbi5sZW5ndGg7IGkrKykge1xyXG4gICAgICAgICAgICBpZiAoX3F1ZXN0aW9uW2ldLmNvbnRyb2xUeXBlID09PSAnc2VjdGlvbicgJiYgdXBkYXRlZEZvcm1WYWwgJiYgdHlwZW9mIHVwZGF0ZWRGb3JtVmFsW19xdWVzdGlvbltpXS5rZXldICE9PSAndW5kZWZpbmVkJykge1xyXG4gICAgICAgICAgICAgICAgZGVsZXRlIHVwZGF0ZWRGb3JtVmFsW19xdWVzdGlvbltpXS5rZXldO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIGVsc2UgaWYgKHR5cGVvZiBfcXVlc3Rpb25baV0uZGlzYWJsZWQgIT09ICd1bmRlZmluZWQnICYmIF9xdWVzdGlvbltpXS5kaXNhYmxlZCkge1xyXG4gICAgICAgICAgICAgICAgZGVsZXRlIHVwZGF0ZWRGb3JtVmFsW19xdWVzdGlvbltpXS5rZXldO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgICAgIHJldHVybiB1cGRhdGVkRm9ybVZhbDtcclxuICAgIH1cclxuXHJcbiAgICAvLy8gdGFibGUgY29udHJvbHR5cGVcclxuICAgIHB1YmxpYyBfZ3JpZENlbGxWYWx1ZUNoYW5nZWQoX2VtaXRQYXJhbXM6IGFueSk6IHZvaWQge1xyXG4gICAgICAgIHRoaXMuZ3JpZENlbGxDaGFuZ2VkLmVtaXQoX2VtaXRQYXJhbXMpO1xyXG4gICAgfVxyXG5cclxuICAgIHB1YmxpYyBfZ3JpZEJ1dHRvbkNsaWNrZWQoX2VtaXRQYXJhbXM6IGFueSk6IHZvaWQge1xyXG4gICAgICAgIHRoaXMuZ3JpZEJ1dHRvbkNsaWNrZWQuZW1pdChfZW1pdFBhcmFtcyk7XHJcbiAgICB9XHJcbn1cclxuIl19