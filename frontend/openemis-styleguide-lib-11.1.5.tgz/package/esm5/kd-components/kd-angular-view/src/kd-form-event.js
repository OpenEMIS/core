import { __decorate, __metadata } from "tslib";
import { Injectable } from '@angular/core';
import { KdBroadcaster } from '../../kd-common/index';
import * as i0 from "@angular/core";
import * as i1 from "../../kd-common/kd-broadcaster-svc";
var KdFormEvent = /** @class */ (function () {
    function KdFormEvent(_broadcaster) {
        this._broadcaster = _broadcaster;
    }
    KdFormEvent.prototype.setDropdownList = function (data) {
        this._broadcaster.broadcast('KdSetDropdownList', data);
    };
    KdFormEvent.prototype.onSetDropdownList = function () {
        return this._broadcaster.on('KdSetDropdownList');
    };
    KdFormEvent.prototype.setVisiableInput = function (data) {
        this._broadcaster.broadcast('KdSetVisiableInput', data);
    };
    KdFormEvent.prototype.onSetVisiableInput = function () {
        return this._broadcaster.on('KdSetVisiableInput');
    };
    KdFormEvent.ctorParameters = function () { return [
        { type: KdBroadcaster }
    ]; };
    KdFormEvent.ɵprov = i0.ɵɵdefineInjectable({ factory: function KdFormEvent_Factory() { return new KdFormEvent(i0.ɵɵinject(i1.KdBroadcaster)); }, token: KdFormEvent, providedIn: "root" });
    KdFormEvent = __decorate([
        Injectable({
            providedIn: 'root'
        }),
        __metadata("design:paramtypes", [KdBroadcaster])
    ], KdFormEvent);
    return KdFormEvent;
}());
export { KdFormEvent };
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoia2QtZm9ybS1ldmVudC5qcyIsInNvdXJjZVJvb3QiOiJuZzovL29wZW5lbWlzLXN0eWxlZ3VpZGUtbGliLyIsInNvdXJjZXMiOlsia2QtY29tcG9uZW50cy9rZC1hbmd1bGFyLXZpZXcvc3JjL2tkLWZvcm0tZXZlbnQudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IjtBQUFBLE9BQU8sRUFBRSxVQUFVLEVBQUUsTUFBTSxlQUFlLENBQUM7QUFFM0MsT0FBTyxFQUFFLGFBQWEsRUFBRSxNQUFNLHVCQUF1QixDQUFDOzs7QUFLdEQ7SUFDSSxxQkFBb0IsWUFBMkI7UUFBM0IsaUJBQVksR0FBWixZQUFZLENBQWU7SUFBSSxDQUFDO0lBRXBELHFDQUFlLEdBQWYsVUFBZ0IsSUFBVTtRQUN0QixJQUFJLENBQUMsWUFBWSxDQUFDLFNBQVMsQ0FBQyxtQkFBbUIsRUFBRSxJQUFJLENBQUMsQ0FBQztJQUMzRCxDQUFDO0lBRUQsdUNBQWlCLEdBQWpCO1FBQ0ksT0FBTyxJQUFJLENBQUMsWUFBWSxDQUFDLEVBQUUsQ0FBTSxtQkFBbUIsQ0FBQyxDQUFDO0lBQzFELENBQUM7SUFFRCxzQ0FBZ0IsR0FBaEIsVUFBaUIsSUFBVTtRQUN2QixJQUFJLENBQUMsWUFBWSxDQUFDLFNBQVMsQ0FBQyxvQkFBb0IsRUFBRSxJQUFJLENBQUMsQ0FBQztJQUM1RCxDQUFDO0lBRUQsd0NBQWtCLEdBQWxCO1FBQ0ksT0FBTyxJQUFJLENBQUMsWUFBWSxDQUFDLEVBQUUsQ0FBTSxvQkFBb0IsQ0FBQyxDQUFDO0lBQzNELENBQUM7O2dCQWhCaUMsYUFBYTs7O0lBRHRDLFdBQVc7UUFIdkIsVUFBVSxDQUFDO1lBQ1IsVUFBVSxFQUFFLE1BQU07U0FDckIsQ0FBQzt5Q0FFb0MsYUFBYTtPQUR0QyxXQUFXLENBa0J2QjtzQkF6QkQ7Q0F5QkMsQUFsQkQsSUFrQkM7U0FsQlksV0FBVyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IEluamVjdGFibGUgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcclxuaW1wb3J0IHsgT2JzZXJ2YWJsZSB9IGZyb20gJ3J4anMnO1xyXG5pbXBvcnQgeyBLZEJyb2FkY2FzdGVyIH0gZnJvbSAnLi4vLi4va2QtY29tbW9uL2luZGV4JztcclxuXHJcbkBJbmplY3RhYmxlKHtcclxuICAgIHByb3ZpZGVkSW46ICdyb290J1xyXG59KVxyXG5leHBvcnQgY2xhc3MgS2RGb3JtRXZlbnQge1xyXG4gICAgY29uc3RydWN0b3IocHJpdmF0ZSBfYnJvYWRjYXN0ZXI6IEtkQnJvYWRjYXN0ZXIpIHsgfVxyXG5cclxuICAgIHNldERyb3Bkb3duTGlzdChkYXRhPzogYW55KTogdm9pZCB7XHJcbiAgICAgICAgdGhpcy5fYnJvYWRjYXN0ZXIuYnJvYWRjYXN0KCdLZFNldERyb3Bkb3duTGlzdCcsIGRhdGEpO1xyXG4gICAgfVxyXG5cclxuICAgIG9uU2V0RHJvcGRvd25MaXN0KCk6IE9ic2VydmFibGU8YW55PiB7XHJcbiAgICAgICAgcmV0dXJuIHRoaXMuX2Jyb2FkY2FzdGVyLm9uPGFueT4oJ0tkU2V0RHJvcGRvd25MaXN0Jyk7XHJcbiAgICB9XHJcblxyXG4gICAgc2V0VmlzaWFibGVJbnB1dChkYXRhPzogYW55KTogdm9pZCB7XHJcbiAgICAgICAgdGhpcy5fYnJvYWRjYXN0ZXIuYnJvYWRjYXN0KCdLZFNldFZpc2lhYmxlSW5wdXQnLCBkYXRhKTtcclxuICAgIH1cclxuXHJcbiAgICBvblNldFZpc2lhYmxlSW5wdXQoKTogT2JzZXJ2YWJsZTxhbnk+IHtcclxuICAgICAgICByZXR1cm4gdGhpcy5fYnJvYWRjYXN0ZXIub248YW55PignS2RTZXRWaXNpYWJsZUlucHV0Jyk7XHJcbiAgICB9XHJcbn1cclxuIl19