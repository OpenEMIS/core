import * as d3 from 'd3';
import { LABEL_TEXT_VERTICAL_ALIGN_STORE, TOOLTIP_DEFAULT_STYLE } from './kd-angular-charts-config';
var KdChartBaseClass = /** @class */ (function () {
    function KdChartBaseClass(_chartSvc, _domSvc) {
        this._chartSvc = _chartSvc;
        this._domSvc = _domSvc;
        // Chart Setting
        this.isRtl = false;
        this.config = {};
        this.data = [];
        this.initData = [];
        this.xAxisArr = [];
        this.axisMin = 0;
        this.axisLabelContainerArr = [];
        this.haveNegative = false;
        /**
         * used only by bar.
         * barGroupPadding is used only for cluster --> the padding between each rect in a category
         * bandPadding is given to d3 --> the padding between each category
         * type {IBaseClassBarObj}
         */
        this.bar = {
            isInvert: false,
            clusterPaddingPercent: 0.1,
            bandPadding: 0.2,
        };
        this.lengthOfTransition = 1000;
        this.errorMsg = '100% stack does not support negative values.';
        this.isRtl = _domSvc.getDocumentDirection(true) === 'right';
    }
    // ================================= Chart ==================================
    KdChartBaseClass.prototype.setSvg = function () {
        this.svg = d3.select('#' + this.config.id + '.kdx-charts svg');
        if (!this.graph)
            this.graph = this.svg.append('g').attr('class', 'graph');
        // if (this.svg.select('.graph').empty()) this.graph = this.svg.append('g').attr('class', 'graph');
        this.svgParent = d3.select('#' + this.config.id + '.kdx-charts .kdx-chart-container');
        this.svgContainer = d3.select('#' + this.config.id + '.kdx-charts .kdx-charts-svg-container');
        this._setLabelContainer();
        this._setChartSvc();
        this.rangeList = {};
    };
    /**
     * set svg width and height. this function is becos of export feature, the export plugins requires svg width and height to be inline attributes with definite number
     * have to be called by all charts
     * param {'x' | 'y'} _axis
     */
    KdChartBaseClass.prototype.setSvgDimension = function (_axis) {
        var svgContainerRect = this.svgContainer.node().getBoundingClientRect();
        var type = _axis === 'x' ? (this.bar.isInvert ? 'height' : 'width') : (this.bar.isInvert ? 'width' : 'height');
        this.svg.attr(type, svgContainerRect[type]);
    };
    KdChartBaseClass.prototype._clearSvgDimension = function () {
        if (!this.svg)
            return;
        this.svg
            .attr('width', 0)
            .attr('height', 0);
    };
    /**
     * set this.width and this.height for axis scales. only called by charts with axis
     * param {'x' |'y'}         _axis
     * param {boolean} _skipCal : skip getSvgOffset calculations
     */
    KdChartBaseClass.prototype._setGraphDimension = function (_axis) {
        this.svgRect = this.svg.node().getBoundingClientRect();
        this._chartSvc.svgRect = this.svgRect;
        var type = _axis === 'x' ? (this.bar.isInvert ? 'height' : 'width') : (this.bar.isInvert ? 'width' : 'height');
        var value = this._chartSvc.getSvgOffset(_axis, { axisMax: this.axisMax, axisMin: this.axisMin });
        this[type] = value < 0 ? 0 : value;
    };
    /**
     * set Chart Service variables
     */
    KdChartBaseClass.prototype._setChartSvc = function () {
        this._chartSvc.config = this.config;
        this._chartSvc.chartType = this.chartType;
        this._chartSvc.chartCategory = this.chartCategory;
        this._chartSvc.svgParentRect = this.svgParent.node().getBoundingClientRect();
        this._chartSvc.svg = this.svg;
        this._chartSvc.isRtl = this.isRtl;
        this._chartSvc.isXReversed = this.config.xAxis.reversed;
        this._chartSvc.isYReversed = this.config.yAxis.reversed;
    };
    KdChartBaseClass.prototype._setLinearScale = function () {
        var rangeRoundVal = this._getRangeVal('y');
        this.y = d3.scaleLinear().rangeRound(rangeRoundVal);
    };
    KdChartBaseClass.prototype._setBandScale = function () {
        var rangeVal = this._getRangeVal('x');
        this.x = d3.scaleBand().range(rangeVal);
        if (this.chartCategory === 'bar') {
            this.x.paddingInner(this.bar.bandPadding).paddingOuter(this.bar.bandPadding / 2);
        }
    };
    KdChartBaseClass.prototype._getRangeVal = function (_axis) {
        var rangeVal;
        var reversed = _axis === 'x' ? 'isXReversed' : 'isYReversed';
        if (this.bar.isInvert) {
            rangeVal = _axis === 'x' ? [0, this.height] : [0, this.width];
        }
        else {
            rangeVal = _axis === 'x' ? [0, this.width] : [this.height, 0];
        }
        return this._chartSvc[reversed] ? rangeVal.reverse() : rangeVal;
    };
    KdChartBaseClass.prototype._setRange = function (isBand) {
        var chartWidth = this.width;
        if (!isBand && this.data.length <= 0) {
            this.rangeList[0] = chartWidth;
            return [0, chartWidth];
        }
        var xPosition = 0;
        var rangeArray = [];
        var bandWidth = chartWidth / this.data.length;
        for (var i = 0; i < this.data.length; i++) {
            if (isBand) {
                xPosition = this._getCenterBandPosition(bandWidth, i);
            }
            else {
                xPosition = chartWidth / (this.data.length - 1) * i;
            }
            if (this._chartSvc.isXReversed)
                xPosition = chartWidth - xPosition;
            rangeArray.push(xPosition);
            this.rangeList[this.data[i].x.value] = xPosition;
        }
        return rangeArray;
    };
    KdChartBaseClass.prototype._getCenterBandPosition = function (_bandWidth, _position) {
        return (_bandWidth / 2) + (_bandWidth * _position);
    };
    KdChartBaseClass.prototype._setScaleByDirection = function (_axis, _xScaleType) {
        if (_axis === 'x') {
            if (_xScaleType !== 'string')
                this._setBandScale();
            if (this.chartCategory === 'line')
                this._setLineScaleX(_xScaleType);
        }
        else {
            this._setLinearScale();
        }
    };
    /**
     * (for line only)
     * happens at first load and on change and may happen if data is sliced during trimX()
     */
    KdChartBaseClass.prototype._setLineScaleX = function (_xScaleType) {
        if (_xScaleType === 'string') {
            this.x = d3.scaleOrdinal().range(this._setRange(false));
        }
        else {
            this._setRange(true);
        }
    };
    // ================================= Domain ==================================
    KdChartBaseClass.prototype.setDomain = function (_xScaleType) {
        this._chartSvc.xScaleType = _xScaleType;
        this.svg.attr('visibility', 'hidden');
        // setting the class name of chart-wrapper (for flex-reverse)
        this._chartSvc.setVertAxisAndChartMargin(this.config.id);
        // everytime the graph resets, if trimming have occured before (ie: this.data and initData length differs), reset this.data so that the trimming calculation uses full dataset
        if (this.initData && this.data.length !== this.initData.length) {
            this.data = JSON.parse(JSON.stringify(this.initData));
            // this._chartSvc.setAxisLabelDummyText(this.categories, this.config.xAxis.labels.format);
        }
        // set this.width,height, scale, domain and tickValues
        this._setDomain(_xScaleType);
        this.svg.attr('visibility', 'visible');
        // set major and minor grid lines
        this._setGridLines();
        // set y and x axis lines
        this.setAxis();
        // transform graph according to width of vertical axis
        this._chartSvc.transformGraphContainer(this.graph);
        // reposition Data Label according to width of vertical axis
        if (this.config.chart.labels.enabled) {
            this.dataLabelContainer.style('width', this.width + 'px');
            this._chartSvc.repositionDataLabel(this.dataLabelContainer, this.axisLabelContainerArr[0]);
        }
        // reposition vertical axis
        this._chartSvc.repositionVerticalAxisTitle();
        // set clip path to this.width and this.height to make sure graph will not be drawn out of graphing region
        this._setClipPath();
    };
    KdChartBaseClass.prototype._setDomain = function (_xScaleType) {
        // finding the max/min value and axisMax/axisMin
        var axisLabelConfig = this.config.yAxis;
        var result = this._chartSvc.setMaxAndMin(axisLabelConfig, this.dataRange);
        this._chartSvc.setAxisD3Format(result.interval);
        this._setAxisMaxAndMin(result.maxValue, result.minValue, result.interval);
        var xInfo = this._chartSvc.getXInfo(this.data, this.config);
        this._setWidthHeightScale('x', _xScaleType);
        this.x.domain(xInfo.value);
        this._setXAxisLabel(_xScaleType, xInfo.longestText);
        this._setWidthHeightScale('y', _xScaleType);
        var tickValueReturn = this._findIntervalForNoOverlap(result);
        if (tickValueReturn && tickValueReturn.needRedraw) {
            this._setWidthHeightScale('x', _xScaleType);
            this.x.domain(xInfo.value);
            this._setXAxisLabel(_xScaleType, xInfo.longestText);
            this._setWidthHeightScale('y', _xScaleType);
        }
        // only generate range arr when interval is stablized
        this.tickValues = this._chartSvc.getTickValues(this.axisMin, this.axisMax, tickValueReturn.interval);
        // set Y domain
        this.domainMax = axisLabelConfig.autoRoundToMax ? this.axisMax : result.maxValue;
        this.domainMin = axisLabelConfig.autoRoundToMin ? this.axisMin : result.minValue;
        this.y.domain([this.domainMin, this.domainMax]);
    };
    KdChartBaseClass.prototype._setWidthHeightScale = function (_axis, _xScaleType) {
        this.setSvgDimension(_axis);
        this._setGraphDimension(_axis);
        this._setScaleByDirection(_axis, _xScaleType);
    };
    /**
     * set clip path to this.width and this.height to make sure graph will not be drawn out of graphing region
     */
    KdChartBaseClass.prototype._setClipPath = function () {
        var clipPathRect = this.svg.selectAll('defs #kd-charts-clip-path-' + this.config.id + ' rect');
        if (clipPathRect.empty()) {
            clipPathRect = this.svg.insert('defs').append('clipPath').attr('id', 'kd-charts-clip-path-' + this.config.id).append('rect');
            clipPathRect
                .attr('x', 0)
                .attr('y', 0)
                .attr('fill', 'none');
        }
        clipPathRect
            .attr('width', this.width)
            .attr('height', this.height);
    };
    KdChartBaseClass.prototype._setAxisMaxAndMin = function (_maxValue, _minValue, _interval) {
        var yAxisConfig = this.config.yAxis;
        this.axisMax = this._chartSvc.setAxisRoundValue(_maxValue, _interval, yAxisConfig.autoRoundToMax, 'up');
        this.axisMin = this._chartSvc.setAxisRoundValue(_minValue, _interval, yAxisConfig.autoRoundToMin, 'down');
    };
    /**
   * will return an object with following properties
   * needRedraw: to determine whether to redraw the axis (and reset the domain)
   * interval: pass out the lastest interval (that have no overlap) for performance reasons, so that the while loop will only run once on needRedraw
   */
    KdChartBaseClass.prototype._findIntervalForNoOverlap = function (_initInfo) {
        var length = this.bar.isInvert ? this.width : this.height;
        if (length <= 0)
            return { needRedraw: false, interval: 0 };
        var tickLength;
        var initYAxisLabelWidth = Object.assign({}, this._chartSvc.yAxisLabelWidth);
        if (this.bar.isInvert) {
            // axisMax and axisMin is already appended as dummy to svg when calculating for this.width and this.height
            // we can direct access to the actual width instead of doing approximation calculation based on font-size (error as high as 1/2 of actual width)
            tickLength = Math.max(initYAxisLabelWidth.axisMax, initYAxisLabelWidth.axisMin);
        }
        else {
            tickLength = this._chartSvc.replaceStringWithNumber(this.config.yAxis.labels.style.fontSize);
        }
        var initInterval = _initInfo.interval;
        var interval = initInterval;
        var noOfTicks = Math.round((this.axisMax + interval - this.axisMin) / interval);
        if (length < tickLength || noOfTicks === 0)
            return { needRedraw: false, interval: 0 };
        var initLongerNum = this._chartSvc.getLongerNumber(this.axisMax, this.axisMin).toString().length;
        while ((length / noOfTicks) < tickLength && noOfTicks > 2) {
            interval = interval * 2;
            this._setAxisMaxAndMin(_initInfo.maxValue, _initInfo.minValue, interval);
            // when the interval changes, axisMax or axisMin does not change significantly (changes at most 1 digits place)
            // check that the current axisMax/Min is indeed longer than the initial axisMax/Min
            if (this.bar.isInvert && this._chartSvc.getLongerNumber(this.axisMax, this.axisMin).toString().length > initLongerNum) {
                tickLength = this._chartSvc.setDummyAxisLabel(this._chartSvc.getLongerNumber(this.axisMax, this.axisMin), 'axisMax');
            }
            noOfTicks = Math.round((this.axisMax + interval - this.axisMin) / interval);
        }
        // when overlap finishes, interval and axisMax/Min is changed compared to when getSvgOffset()
        // check that current interval results in same max label length, if not, redraw the axis and run getSvgOffset() again
        if (initInterval !== interval) {
            this._chartSvc.setAxisD3Format(interval);
            var newYAxisLabelWidth = this._chartSvc.getYAxisMaxAndMinLabelWidth({ axisMin: this.axisMin, axisMax: this.axisMax });
            if (newYAxisLabelWidth.axisMax !== initYAxisLabelWidth.axisMax || newYAxisLabelWidth.axisMin !== initYAxisLabelWidth.axisMin) {
                return { needRedraw: true, interval: interval };
            }
        }
        return { needRedraw: false, interval: interval };
    };
    // ================================= Grid Lines ==================================
    KdChartBaseClass.prototype._setGridLines = function () {
        if (!this.gridLinesContainer)
            this.gridLinesContainer = this.graph.append('g').attr('class', 'kdx-charts-grid-line-container');
        this._chartSvc.gridSvc.graphDimension = { width: this.width, height: this.height };
        if (this._chartSvc.gridSvc.haveGrid(this.config, 'xAxis', 'gridLine'))
            this._setXAxisGrid();
        if (this._chartSvc.gridSvc.haveGrid(this.config, 'yAxis', 'minorGridLine'))
            this._setYAxisMinorGrid();
        if (this._chartSvc.gridSvc.haveGrid(this.config, 'yAxis', 'gridLine'))
            this._setYAxisGrid();
    };
    KdChartBaseClass.prototype._setXAxisGrid = function () {
        // wrapper function around this.x so that grid will be drawn in center of paddingInner
        var scale = this._chartSvc.gridSvc.xAxisGridScale(this.x);
        // concat space to draw first grid line, Note: this.data may have been spliced by trimX
        var xData = [''].concat(this.data.map(function (data) { return data.x.value; }));
        // let xData: Array<string> = [''].concat(_categories);
        this._chartSvc.gridSvc.drawGridLine(this.gridLinesContainer, xData, 'xAxis', 'gridLine', scale);
    };
    // draw major grid line
    KdChartBaseClass.prototype._setYAxisGrid = function () {
        this._chartSvc.gridSvc.drawGridLine(this.gridLinesContainer, this.tickValues, 'yAxis', 'gridLine', this.y);
    };
    KdChartBaseClass.prototype._setYAxisMinorGrid = function () {
        var yAxisConfig = this.config.yAxis;
        if (yAxisConfig.minorTickInterval >= yAxisConfig.tickInterval || !yAxisConfig.minorTickInterval)
            return;
        var upperbound = this._chartSvc.setAxisRoundValue(this.domainMax, yAxisConfig.minorTickInterval, false, 'up');
        var lowerbound = this._chartSvc.setAxisRoundValue(this.domainMin, yAxisConfig.minorTickInterval, false, 'down');
        var minorTickValues = this._chartSvc.getTickValues(lowerbound, upperbound, yAxisConfig.minorTickInterval);
        this._chartSvc.gridSvc.drawGridLine(this.gridLinesContainer, minorTickValues, 'yAxis', 'minorGridLine', this.y);
    };
    // ================================= Axis ==================================
    KdChartBaseClass.prototype.setAxis = function () {
        var transformPos = {
            right: 'translate(' + this.width + ',0)',
            left: 'translate(0,0)',
            top: 'translate(0,0)',
            bottom: 'translate(0,' + this.height + ')'
        };
        var xAxisConfig = this.config.xAxis;
        var yAxisConfig = this.config.yAxis;
        var invert = this.bar.isInvert;
        var opposite = {
            x: invert ? xAxisConfig.opposite !== this.isRtl : xAxisConfig.opposite,
            y: invert ? yAxisConfig.opposite : yAxisConfig.opposite !== this.isRtl
        };
        var xAxis = this._getEachAxisFunc('x', opposite.x, invert);
        this.xAxisArr.push(xAxis);
        this.yAxis = this._getEachAxisFunc('y', opposite.y, invert);
        xAxis.attr('transform', this._chartSvc.getAxisTransformPos('x', opposite.x, transformPos));
        this.yAxis.attr('transform', this._chartSvc.getAxisTransformPos('y', opposite.y, transformPos));
        this._chartSvc.setAxisLabelConfig(xAxis, 'x');
        this._chartSvc.setAxisLabelConfig(this.yAxis, 'y');
        if (this._chartSvc.isNegativeStack) {
            var secondXAxis = this._getEachAxisFunc('x', !opposite.x, this.bar.isInvert);
            secondXAxis.attr('transform', this._chartSvc.getAxisTransformPos('x', !opposite.x, transformPos));
            this._chartSvc.setAxisLabelConfig(secondXAxis, 'x');
            this.xAxisArr.push(secondXAxis);
        }
    };
    KdChartBaseClass.prototype._getEachAxisFunc = function (_axis, _opposite, _invert) {
        var _this = this;
        var axisFunc = getAxisFunc(_axis, this[_axis]);
        var axisClass = 'kdx-charts-axis axis-' + _axis;
        if ((_invert && _axis === 'x') || (!_invert && _axis === 'y')) {
            axisClass += ' kdx-charts-axis-vertical';
        }
        if (_opposite)
            axisClass += ' kdx-charts-axis-opposite';
        if (_axis === 'y') {
            axisFunc
                .tickValues(this.tickValues)
                .tickFormat(function (d) {
                // note: only usecase is negative stack bar (in v3.7.0). will affect both yAxis label and tooltip and dataLabels
                var value = _this._chartSvc.checkAndReturnLabelsPositive(d);
                return _this._chartSvc.getYAxisLabelText(_this.config.yAxis, value);
            });
        }
        var axisElem = this.graph.append('g').attr('class', axisClass).call(axisFunc);
        return axisElem;
        function getAxisFunc(_type, _scale) {
            if (_invert) {
                if (_type === 'x') {
                    if (_opposite)
                        return d3.axisRight(_scale);
                    return d3.axisLeft(_scale);
                }
                if (_type === 'y') {
                    if (_opposite)
                        return d3.axisTop(_scale);
                    return d3.axisBottom(_scale);
                }
            }
            else {
                if (_type === 'x') {
                    if (_opposite)
                        return d3.axisTop(_scale);
                    return d3.axisBottom(_scale);
                }
                if (_type === 'y') {
                    if (_opposite)
                        return d3.axisRight(_scale);
                    return d3.axisLeft(_scale);
                }
            }
        }
    };
    // ================================= Remove Chart ==================================
    KdChartBaseClass.prototype.chartTimeout = function (_callback) {
        // let delay = this.config.legend.enabled && this.chartCategory === 'pie'? 500 : 10;
        clearTimeout(this._setChartTimeout);
        this._setChartTimeout = setTimeout(function () {
            _callback();
        });
    };
    KdChartBaseClass.prototype.removeChart = function () {
        clearTimeout(this._setChartTimeout);
        this._removeElemInArrayForm('xAxisArr', function (axis) { return axis.remove(); });
        if (this.yAxis)
            this.yAxis.remove();
        if (this.dataLabelContainer)
            this.dataLabelContainer.selectAll('*').remove();
        this._removeElemInArrayForm('axisLabelContainerArr', function (container) { return container.selectAll('*').remove(); });
        if (this.gridLinesContainer)
            this.gridLinesContainer.selectAll('*').remove();
        this._clearSvgDimension();
    };
    KdChartBaseClass.prototype._removeElemInArrayForm = function (_key, callback) {
        if (this[_key].length !== 0) {
            this[_key].forEach(function (element) { return callback(element); });
            this[_key] = [];
        }
    };
    // ================================= Axis Label ==================================
    KdChartBaseClass.prototype._setXAxisLabel = function (_xScaleType, _longestText) {
        var _this = this;
        if (!this.config.xAxis.enabled || !this.config.xAxis.labels.enabled)
            return;
        if (this.axisLabelContainerArr.length !== 0) {
            this._removeElemInArrayForm('axisLabelContainerArr', function (container) { return container.selectAll('*').remove(); });
        }
        var xSpacing = this._calculateXSpacing(_xScaleType);
        this._chartSvc.setAxisLabelDummy(this.config.id, xSpacing, _longestText);
        this._chartSvc._setAxisLabelLength();
        this._setAxisLabelContainer();
        if (this._chartSvc.labelLength !== 0)
            this._trimX(_xScaleType);
        this.axisLabelContainerArr.forEach(function (_axisLabelContainer, index) {
            _this._chartSvc.setAxisLabelContainerStyle(_axisLabelContainer);
            // if drawing 2nd axis, set to complement of opposite of 1st axis
            if (_this._chartSvc.labelLength !== 0) {
                var opposite = index === 1 ? !_this.config.xAxis.opposite : _this.config.xAxis.opposite;
                _this._drawAxisLabel(_axisLabelContainer, { labelHeight: _this._chartSvc.labelLength, labelWidth: xSpacing }, { isRotate: _this._chartSvc.isRotate, opposite: opposite });
            }
        });
    };
    KdChartBaseClass.prototype._setAxisLabelContainer = function () {
        this.axisLabelContainerArr.push(this._chartSvc.setAxisLabelContainer());
        // render 2nd axis
        if (this._chartSvc.isNegativeStack) {
            this.axisLabelContainerArr.push(this._chartSvc.setAxisLabelContainer('.kdx-charts-double-axis-x'));
        }
    };
    KdChartBaseClass.prototype._calculateXSpacing = function (_xScaleType) {
        return (_xScaleType === 'band') ? this.x.bandwidth() + this.x.paddingInner() * this.x.step() : this.width / (this.data.length - 1);
    };
    KdChartBaseClass.prototype._trimX = function (_xScaleType) {
        var maxNoOfX = this._calculateMaxNoOfX(this._chartSvc.isRotate, _xScaleType);
        if (maxNoOfX === this.initData.length)
            return;
        // if the inital data cannot fit into maxSpace, slice and save to this.data
        this.data = this.initData.slice(0, maxNoOfX);
        var xInfo = this._chartSvc.getXInfo(this.data, this.config);
        // update domain with the updated this.data
        if (this.chartCategory === 'line')
            this._setLineScaleX(_xScaleType);
        this.x.domain(xInfo.value);
        // after trimming, the longest axis label may not be same. hence recalculate the axis label container height
        this._chartSvc.setAxisLabelDummyText(xInfo.longestText);
        this._chartSvc._setAxisLabelLength();
    };
    // this.data will be changed/trimed according to space given
    KdChartBaseClass.prototype._calculateMaxNoOfX = function (_isRotate, _xScaleType) {
        if (!_isRotate && !this.bar.isInvert)
            return this.initData.length;
        var offset = this.chartCategory === 'bar' ? (this.x.paddingOuter()) * 2 : 0;
        var maxSpace = (this.bar.isInvert ? this.height : this.width) - offset;
        // note: when rotating or when chartType == 'bar', axisLAbelDummy will not text-wrap
        var eachItemSize = this._chartSvc.getAxisLabelDummyRect().height;
        var maxNoOfX = Math.floor(maxSpace / eachItemSize);
        if (_xScaleType === 'string')
            maxNoOfX += 1;
        return Math.min(this.initData.length, maxNoOfX);
    };
    KdChartBaseClass.prototype._drawAxisLabel = function (_container, _labelDimenstion, _booleanChecks) {
        var _this = this;
        var firstTick = 0, xAxisLabelConfig = this.config.xAxis.labels;
        if (this.chartCategory === 'bar')
            firstTick = this.x.paddingOuter() * this.x.step() + this.x.bandwidth() / 2;
        this.data.forEach(function (d, xIndex) {
            var labelContainer, tickPos;
            labelContainer = _container.append('div')
                .attr('class', 'kdx-charts-axis-label x-' + xIndex)
                .html(_this._chartSvc.getLabelFormatReplace(xAxisLabelConfig.format, d.x.label));
            if (_booleanChecks.isRotate) {
                labelContainer.style('max-width', _labelDimenstion.labelHeight + 'px');
            }
            else {
                if (!_this.bar.isInvert)
                    labelContainer.style('max-width', _labelDimenstion.labelWidth + 'px');
            }
            if (_this.chartCategory === 'bar') {
                var orderFromLeft = _this._chartSvc.isXReversed ? _this.data.length - xIndex - 1 : xIndex;
                tickPos = firstTick + _this.x.step() * orderFromLeft;
            }
            else {
                tickPos = _this.rangeList[_this.data[xIndex].x.value];
            }
            _this._chartSvc.setAxisLabelPosition(labelContainer, tickPos, Object.assign(_booleanChecks, { isLast: xIndex === _this.data.length - 1 }));
        });
    };
    // ================================= Capture Hover Event ==================================
    /**
     * _params can be ID3DataData or can contain callbacks
     * {
     *     ...
     *     callbacks: {
     *         'mouseover': Function,
     *         'mouseout': Function
     *     }
     * }
     */
    KdChartBaseClass.prototype._initMouseEvents = function (_path, _params) {
        var _this = this;
        var mapCondition = (this.chartType[0] === 'map' && (this.chartType[1] === 'full' || this.chartType[1] === 'filter'));
        if (!this.config.tooltip.enabled)
            return;
        var tooltip;
        _path.on('mouseover', function (d, index) {
            var top = mapCondition ? parseInt(_params.fullGraph.node().style.top) + d3.event.layerY : d3.event.layerY;
            var left = mapCondition ? parseInt(_params.fullGraph.node().style.left) + d3.event.layerX : d3.event.layerX;
            var graphPointer = (mapCondition && _params.tooltipLayer) ? _params.tooltipLayer : _this.svgParent;
            tooltip = graphPointer.select('.kdx-charts-tooltip');
            // if tooltip already exist (in case mouseout did not happen), don't append anymore.
            if (tooltip.empty()) {
                tooltip = graphPointer.append('div').attr('class', 'kdx-charts-tooltip');
                tooltip.append('div').attr('class', 'kdx-charts-tooltip-label');
                tooltip.append('div').attr('class', 'kdx-charts-tooltip-count');
            }
            var label;
            var count;
            // let config: IChartConfig = this._chartSvc.config;
            var value;
            if (_this.chartType && (_this.chartType[0] === 'pie' || _this.chartType[0] === 'donut')) {
                label = d.data.x.replace(/¬/g, ' ');
                count = d.data.y;
                _params.pathAnim(d3.select(_path._groups[0][index]), true, _params.innerRadius, _params.outerRadius);
                d3.select(_path._groups[0][index]).style('opacity', '0.7');
            }
            else if (_this.chartType && _this.chartType[0] === 'radial') {
                label = d.x.replace(/¬/g, ' ');
                count = d.y;
                d3.select(_path._groups[0][index]).style('opacity', '0.7');
            }
            else if (_this.chartCategory === 'bar') {
                label = _params.data.x.label;
                count = _this._chartSvc.checkAndReturnLabelsPositive(d.value || 0);
                label = label.toString() + ' ' + _this.legendData[d.id].name;
                d3.select(_path._groups[0][index]).style('opacity', '0.7');
            }
            else if (_this.chartCategory === 'line') {
                label = _params.data.x.label;
                count = _params.data.y[index].value;
                label = label.toString() + ' ' + _this.legendData[d].name;
            }
            else if (_this.chartCategory === 'map') {
                for (var i = 0; i < _params.seriesData.length; i++) {
                    if (d.properties.ID_ == _params.seriesData[i].id) {
                        label = _params.seriesData[i].name;
                        count = _params.seriesName + ': ' + _params.seriesData[i].value;
                        value = _params.seriesData[i].value;
                        break;
                    }
                }
            }
            count = _this._chartSvc.getLabelText(_this.config.tooltip.format, count);
            tooltip.select('.kdx-charts-tooltip-label').html(label.toUpperCase());
            if (_this.chartType[1] !== 'filter')
                tooltip.select('.kdx-charts-tooltip-count').html(count).style('font-weight', 'bold');
            tooltip.attr('style', _this._chartSvc.getStyle(Object.assign({}, TOOLTIP_DEFAULT_STYLE), true));
            tooltip.style('display', 'block');
            tooltip.style('opacity', 2);
            tooltip.style('z-index', 403);
            if (_this.chartCategory === 'line') {
                _params.dotHover(_this.getDotId(_params.xIndex, d), true);
            }
            if (_params && _params.callbacks && _params.callbacks.mouseover)
                _params.callbacks.mouseover(value);
            // in case mousemove did not trigger, position tooltip once tooltip is created
            if (_this.chartCategory !== 'map') {
                _this._chartSvc.tooltipSvc.positionTooltip(tooltip, { top: d3.event.layerY, left: d3.event.layerX });
            }
            else {
                if (value || value === 0)
                    _this._chartSvc.tooltipSvc.positionTooltip(tooltip, { top: top, left: left });
                else
                    tooltip.remove();
            }
        });
        _path.on('mousemove', function (d) {
            var top = mapCondition ? parseInt(_params.fullGraph.node().style.top) + d3.event.layerY : d3.event.layerY;
            var left = mapCondition ? parseInt(_params.fullGraph.node().style.left) + d3.event.layerX : d3.event.layerX;
            // position the tooltip to the cursor
            _this._chartSvc.tooltipSvc.positionTooltip(tooltip, { top: top, left: left });
        });
        _path.on('mouseout', function (d, index) {
            if (_this.chartType && (_this.chartType[0] === 'pie' || _this.chartType[0] === 'donut' || _this.chartType[0] === 'radial' || _this.chartCategory === 'bar')) {
                if (_this.chartType[0] === 'pie' || _this.chartType[0] === 'donut') {
                    var thisPath = d3.select(_path._groups[0][index]);
                    if (!thisPath.classed('clicked')) {
                        _params.pathAnim(thisPath, false, _params.innerRadius, _params.outerRadius);
                    }
                }
                d3.select(_path._groups[0][index]).style('opacity', '1');
            }
            // tooltip.style('display', 'none');
            // tooltip.style('opacity', 0);
            tooltip.remove();
            if (_this.chartCategory === 'line') {
                _params.dotHover(_this.getDotId(_params.xIndex, d));
            }
            if (_params && _params.callbacks && _params.callbacks.mouseout)
                _params.callbacks.mouseout();
        });
        _path.on('click', function (d, index) {
            if (_this.chartType && (_this.chartType[0] === 'pie' || _this.chartType[0] === 'donut')) {
                var thisPath = d3.select(_path._groups[0][index]);
                var clicked = thisPath.classed('clicked');
                _params.pathAnim(thisPath, !clicked, _params.innerRadius, _params.outerRadius);
                thisPath.classed('clicked', !clicked);
            }
        });
    };
    // ================================= LABEL ==================================
    KdChartBaseClass.prototype.setLabel = function (_yData, _xData, _xPosition, _yPosition) {
        if (!this.config.chart.labels.enabled)
            return;
        var labelConfig = this.config.chart.labels;
        var labelContainer = this.dataLabelContainer.append('div')
            .attr('class', 'kdx-charts-data-label x-' + _xData + ' y-' + _yData.id);
        var labelText = this._chartSvc.getLabelText(labelConfig.format, _yData.value);
        labelContainer
            .append('div')
            .attr('class', 'kdx-charts-data-label-text')
            .html(labelText)
            .attr('style', this._chartSvc.getStyle(labelConfig.style));
        this._setLabelPosition(labelContainer, _yData.sum || _yData.value, _xPosition, _yPosition);
        return labelContainer;
    };
    KdChartBaseClass.prototype.transformPosition = function (x, y, isAttribute) {
        return 'translate(' + x + ((isAttribute) ? ',' : 'px,') + y + ((isAttribute) ? ')' : 'px)');
    };
    KdChartBaseClass.prototype.getDotId = function (xData, yId) {
        return 'kdx-charts-point-dot x-' + xData + ' y-' + yId;
    };
    KdChartBaseClass.prototype.isDataExist = function (_item, _yIndex) {
        return this._chartSvc.isExist(_item.y[_yIndex]);
    };
    KdChartBaseClass.prototype._setLabelContainer = function () {
        this.dataLabelContainer = d3.select('#' + this.config.id + '.kdx-charts ' + '.kdx-charts-data-label-container');
    };
    /**
     * _params for bar: { valueSign: -1 or 0 or 1, dimensions: width, height, xPos, yPos}
     * _params for line: { dotSize: number, labelLength: number}
     */
    // affects all charts except pie, map, horizontal bar (which uses flex for vertical align, refer to kd-bar-chart)
    KdChartBaseClass.prototype.setLabelTextPosition = function (labelText, _yPosition, _params) {
        var _this = this;
        if (_params === void 0) { _params = {}; }
        var store = LABEL_TEXT_VERTICAL_ALIGN_STORE;
        var verticalAlign = this._chartSvc.getDefaultVerticalAlign(this.config, _params);
        var dotSize = _params.dotSize ? _params.dotSize : 0;
        var offset = dotSize / 2;
        if (verticalAlign === 'middle') {
            var checks = ['top', 'bottom'];
            checks.forEach(function (key) {
                if (_this._chartSvc._checkBoundary(store[key].check, _yPosition, _this.height, dotSize)) {
                    verticalAlign = store[key].changeTo;
                }
            });
        }
        else if (this._chartSvc._checkBoundary(store[verticalAlign].check, _yPosition, this.height, dotSize)) {
            verticalAlign = store[verticalAlign].changeTo;
        }
        var yPos = '';
        if (verticalAlign === 'middle') {
            yPos = store[verticalAlign].percent;
        }
        else {
            var sign = verticalAlign === 'top' ? ' - ' : ' + ';
            if (this.chartCategory === 'bar' && this._chartSvc.needOffsetForColumn(verticalAlign, _params))
                offset += _params.dimensions.height;
            yPos = 'calc(' + store[verticalAlign].percent + sign + offset.toString() + 'px)';
        }
        var xPos = (_params.labelLength && _params.labelLength > 1) ? 'calc(-50% + ' + dotSize / 2 + 'px)' : '0%';
        var translate = this.chartCategory === 'line' ? this.transformPosition(xPos, yPos, true) : 'translateY(' + yPos + ')';
        labelText.style('transform', translate);
    };
    KdChartBaseClass.prototype._setLabelPosition = function (labelContainer, _yValue, _xPosition, _yPosition) {
        var defaultPosition = {
            x: ((this.bar.isInvert) ? this.height : 0),
            y: ((this.bar.isInvert) ? this.width : 0)
        };
        var x = (typeof _xPosition === 'number') ? _xPosition : defaultPosition.x;
        var y = (typeof _yPosition === 'number') ? _yPosition : defaultPosition.y;
        // if (_yPosition < this.dataLabelPushDownRange) {
        //     y = 5;
        // }
        if (this.isRtl)
            x = (this.width * -1) + x;
        if (_yValue && (_yValue > this.domainMax || _yValue < this.domainMin)) {
            labelContainer.style('display', 'none');
        }
        this._applyLabelPosition(labelContainer, x, y);
    };
    KdChartBaseClass.prototype._applyLabelPosition = function (labelContainer, _xPosition, _yPosition) {
        var rotate = '';
        var labelStyle = this.config.chart.labels.style;
        // this.config.chart.labels.rotation cannot be '' or null or other non-value
        if (labelStyle.hasOwnProperty('rotation') && labelStyle.rotation) {
            rotate = ' rotate(' + labelStyle.rotation + 'deg)';
        }
        labelContainer
            .style('transform', this.transformPosition(_xPosition, _yPosition) + rotate);
        if (this.isRtl)
            labelContainer.style('text-align', 'right');
    };
    return KdChartBaseClass;
}());
export { KdChartBaseClass };
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoia2QtYW5ndWxhci1jaGFydC1iYXNlLWNsYXNzLmpzIiwic291cmNlUm9vdCI6Im5nOi8vb3BlbmVtaXMtc3R5bGVndWlkZS1saWIvIiwic291cmNlcyI6WyJrZC1jb21wb25lbnRzL2tkLWFuZ3VsYXItY2hhcnRzL2tkLWFuZ3VsYXItY2hhcnQtYmFzZS1jbGFzcy50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQSxPQUFPLEtBQUssRUFBRSxNQUFNLElBQUksQ0FBQztBQW1CekIsT0FBTyxFQUFFLCtCQUErQixFQUFFLHFCQUFxQixFQUFFLE1BQU0sNEJBQTRCLENBQUM7QUFHcEc7SUFnRUksMEJBQW1CLFNBQXNCLEVBQVMsT0FBcUI7UUFBcEQsY0FBUyxHQUFULFNBQVMsQ0FBYTtRQUFTLFlBQU8sR0FBUCxPQUFPLENBQWM7UUE5RHZFLGdCQUFnQjtRQUNULFVBQUssR0FBWSxLQUFLLENBQUM7UUFDdkIsV0FBTSxHQUFpQixFQUFFLENBQUM7UUFDMUIsU0FBSSxHQUF1QixFQUFFLENBQUM7UUFDOUIsYUFBUSxHQUF1QixFQUFFLENBQUM7UUFvQmxDLGFBQVEsR0FBZSxFQUFFLENBQUM7UUFNMUIsWUFBTyxHQUFXLENBQUMsQ0FBQztRQUtwQiwwQkFBcUIsR0FBZSxFQUFFLENBQUM7UUFFdkMsaUJBQVksR0FBWSxLQUFLLENBQUM7UUFDckM7Ozs7O1dBS0c7UUFDSSxRQUFHLEdBQThFO1lBQ3BGLFFBQVEsRUFBRSxLQUFLO1lBQ2YscUJBQXFCLEVBQUUsR0FBRztZQUMxQixXQUFXLEVBQUUsR0FBRztTQUNuQixDQUFDO1FBR0ssdUJBQWtCLEdBQVcsSUFBSSxDQUFDO1FBT2xDLGFBQVEsR0FBVyw4Q0FBOEMsQ0FBQztRQUtyRSxJQUFJLENBQUMsS0FBSyxHQUFHLE9BQU8sQ0FBQyxvQkFBb0IsQ0FBQyxJQUFJLENBQUMsS0FBSyxPQUFPLENBQUM7SUFDaEUsQ0FBQztJQUVELDZFQUE2RTtJQUV0RSxpQ0FBTSxHQUFiO1FBQ0ksSUFBSSxDQUFDLEdBQUcsR0FBRyxFQUFFLENBQUMsTUFBTSxDQUFDLEdBQUcsR0FBRyxJQUFJLENBQUMsTUFBTSxDQUFDLEVBQUUsR0FBRyxpQkFBaUIsQ0FBQyxDQUFDO1FBQy9ELElBQUksQ0FBQyxJQUFJLENBQUMsS0FBSztZQUFFLElBQUksQ0FBQyxLQUFLLEdBQUcsSUFBSSxDQUFDLEdBQUcsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDLE9BQU8sRUFBRSxPQUFPLENBQUMsQ0FBQztRQUMxRSxtR0FBbUc7UUFDbkcsSUFBSSxDQUFDLFNBQVMsR0FBRyxFQUFFLENBQUMsTUFBTSxDQUFDLEdBQUcsR0FBRyxJQUFJLENBQUMsTUFBTSxDQUFDLEVBQUUsR0FBRyxrQ0FBa0MsQ0FBQyxDQUFDO1FBQ3RGLElBQUksQ0FBQyxZQUFZLEdBQUcsRUFBRSxDQUFDLE1BQU0sQ0FBQyxHQUFHLEdBQUcsSUFBSSxDQUFDLE1BQU0sQ0FBQyxFQUFFLEdBQUcsdUNBQXVDLENBQUMsQ0FBQztRQUU5RixJQUFJLENBQUMsa0JBQWtCLEVBQUUsQ0FBQztRQUMxQixJQUFJLENBQUMsWUFBWSxFQUFFLENBQUM7UUFDcEIsSUFBSSxDQUFDLFNBQVMsR0FBRyxFQUFFLENBQUM7SUFDeEIsQ0FBQztJQUVEOzs7O09BSUc7SUFDSSwwQ0FBZSxHQUF0QixVQUF1QixLQUFnQjtRQUNuQyxJQUFJLGdCQUFnQixHQUFRLElBQUksQ0FBQyxZQUFZLENBQUMsSUFBSSxFQUFFLENBQUMscUJBQXFCLEVBQUUsQ0FBQztRQUM3RSxJQUFJLElBQUksR0FBdUIsS0FBSyxLQUFLLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQztRQUVuSSxJQUFJLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxJQUFJLEVBQUUsZ0JBQWdCLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQztJQUNoRCxDQUFDO0lBRU8sNkNBQWtCLEdBQTFCO1FBQ0ksSUFBSSxDQUFDLElBQUksQ0FBQyxHQUFHO1lBQUUsT0FBTztRQUN0QixJQUFJLENBQUMsR0FBRzthQUNILElBQUksQ0FBQyxPQUFPLEVBQUUsQ0FBQyxDQUFDO2FBQ2hCLElBQUksQ0FBQyxRQUFRLEVBQUUsQ0FBQyxDQUFDLENBQUM7SUFDM0IsQ0FBQztJQUVEOzs7O09BSUc7SUFDSyw2Q0FBa0IsR0FBMUIsVUFBMkIsS0FBZ0I7UUFDdkMsSUFBSSxDQUFDLE9BQU8sR0FBRyxJQUFJLENBQUMsR0FBRyxDQUFDLElBQUksRUFBRSxDQUFDLHFCQUFxQixFQUFFLENBQUM7UUFDdkQsSUFBSSxDQUFDLFNBQVMsQ0FBQyxPQUFPLEdBQUcsSUFBSSxDQUFDLE9BQU8sQ0FBQztRQUV0QyxJQUFJLElBQUksR0FBdUIsS0FBSyxLQUFLLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQztRQUVuSSxJQUFJLEtBQUssR0FBVyxJQUFJLENBQUMsU0FBUyxDQUFDLFlBQVksQ0FBQyxLQUFLLEVBQUUsRUFBRSxPQUFPLEVBQUUsSUFBSSxDQUFDLE9BQU8sRUFBRSxPQUFPLEVBQUUsSUFBSSxDQUFDLE9BQU8sRUFBRSxDQUFDLENBQUM7UUFFekcsSUFBSSxDQUFDLElBQUksQ0FBQyxHQUFHLEtBQUssR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDO0lBQ3ZDLENBQUM7SUFFRDs7T0FFRztJQUNLLHVDQUFZLEdBQXBCO1FBQ0ksSUFBSSxDQUFDLFNBQVMsQ0FBQyxNQUFNLEdBQUcsSUFBSSxDQUFDLE1BQU0sQ0FBQztRQUNwQyxJQUFJLENBQUMsU0FBUyxDQUFDLFNBQVMsR0FBRyxJQUFJLENBQUMsU0FBUyxDQUFDO1FBQzFDLElBQUksQ0FBQyxTQUFTLENBQUMsYUFBYSxHQUFHLElBQUksQ0FBQyxhQUFhLENBQUM7UUFDbEQsSUFBSSxDQUFDLFNBQVMsQ0FBQyxhQUFhLEdBQUcsSUFBSSxDQUFDLFNBQVMsQ0FBQyxJQUFJLEVBQUUsQ0FBQyxxQkFBcUIsRUFBRSxDQUFDO1FBQzdFLElBQUksQ0FBQyxTQUFTLENBQUMsR0FBRyxHQUFHLElBQUksQ0FBQyxHQUFHLENBQUM7UUFDOUIsSUFBSSxDQUFDLFNBQVMsQ0FBQyxLQUFLLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQztRQUNsQyxJQUFJLENBQUMsU0FBUyxDQUFDLFdBQVcsR0FBRyxJQUFJLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxRQUFRLENBQUM7UUFDeEQsSUFBSSxDQUFDLFNBQVMsQ0FBQyxXQUFXLEdBQUcsSUFBSSxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsUUFBUSxDQUFDO0lBQzVELENBQUM7SUFFTywwQ0FBZSxHQUF2QjtRQUNJLElBQUksYUFBYSxHQUFrQixJQUFJLENBQUMsWUFBWSxDQUFDLEdBQUcsQ0FBQyxDQUFDO1FBQzFELElBQUksQ0FBQyxDQUFDLEdBQUcsRUFBRSxDQUFDLFdBQVcsRUFBRSxDQUFDLFVBQVUsQ0FBQyxhQUFhLENBQUMsQ0FBQztJQUN4RCxDQUFDO0lBRU8sd0NBQWEsR0FBckI7UUFDSSxJQUFJLFFBQVEsR0FBa0IsSUFBSSxDQUFDLFlBQVksQ0FBQyxHQUFHLENBQUMsQ0FBQztRQUVyRCxJQUFJLENBQUMsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxTQUFTLEVBQUUsQ0FBQyxLQUFLLENBQUMsUUFBUSxDQUFDLENBQUM7UUFFeEMsSUFBSSxJQUFJLENBQUMsYUFBYSxLQUFLLEtBQUssRUFBRTtZQUM5QixJQUFJLENBQUMsQ0FBQyxDQUFDLFlBQVksQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLFdBQVcsQ0FBQyxDQUFDLFlBQVksQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLFdBQVcsR0FBRyxDQUFDLENBQUMsQ0FBQztTQUNwRjtJQUNMLENBQUM7SUFFTyx1Q0FBWSxHQUFwQixVQUFxQixLQUFnQjtRQUNqQyxJQUFJLFFBQWtCLENBQUM7UUFDdkIsSUFBSSxRQUFRLEdBQWtDLEtBQUssS0FBSyxHQUFHLENBQUMsQ0FBQyxDQUFDLGFBQWEsQ0FBQyxDQUFDLENBQUMsYUFBYSxDQUFDO1FBRTVGLElBQUksSUFBSSxDQUFDLEdBQUcsQ0FBQyxRQUFRLEVBQUU7WUFDbkIsUUFBUSxHQUFHLEtBQUssS0FBSyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFDO1NBQ2pFO2FBQU07WUFDSCxRQUFRLEdBQUcsS0FBSyxLQUFLLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxNQUFNLEVBQUUsQ0FBQyxDQUFDLENBQUM7U0FDakU7UUFFRCxPQUFPLElBQUksQ0FBQyxTQUFTLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxPQUFPLEVBQUUsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDO0lBQ3BFLENBQUM7SUFFTyxvQ0FBUyxHQUFqQixVQUFrQixNQUFnQjtRQUM5QixJQUFJLFVBQVUsR0FBVyxJQUFJLENBQUMsS0FBSyxDQUFDO1FBRXBDLElBQUksQ0FBQyxNQUFNLElBQUksSUFBSSxDQUFDLElBQUksQ0FBQyxNQUFNLElBQUksQ0FBQyxFQUFFO1lBQ2xDLElBQUksQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLEdBQUcsVUFBVSxDQUFDO1lBQy9CLE9BQU8sQ0FBQyxDQUFDLEVBQUUsVUFBVSxDQUFDLENBQUM7U0FDMUI7UUFFRCxJQUFJLFNBQVMsR0FBVyxDQUFDLENBQUM7UUFDMUIsSUFBSSxVQUFVLEdBQWtCLEVBQUUsQ0FBQztRQUNuQyxJQUFJLFNBQVMsR0FBVyxVQUFVLEdBQUcsSUFBSSxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUM7UUFFdEQsS0FBSyxJQUFJLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxHQUFHLElBQUksQ0FBQyxJQUFJLENBQUMsTUFBTSxFQUFFLENBQUMsRUFBRSxFQUFFO1lBRXZDLElBQUksTUFBTSxFQUFFO2dCQUNSLFNBQVMsR0FBRyxJQUFJLENBQUMsc0JBQXNCLENBQUMsU0FBUyxFQUFFLENBQUMsQ0FBQyxDQUFDO2FBQ3pEO2lCQUFNO2dCQUNILFNBQVMsR0FBRyxVQUFVLEdBQUcsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLE1BQU0sR0FBRyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUM7YUFDdkQ7WUFFRCxJQUFJLElBQUksQ0FBQyxTQUFTLENBQUMsV0FBVztnQkFBRSxTQUFTLEdBQUcsVUFBVSxHQUFHLFNBQVMsQ0FBQztZQUVuRSxVQUFVLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDO1lBQzNCLElBQUksQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLEdBQUcsU0FBUyxDQUFDO1NBQ3BEO1FBRUQsT0FBTyxVQUFVLENBQUM7SUFDdEIsQ0FBQztJQUVPLGlEQUFzQixHQUE5QixVQUErQixVQUFrQixFQUFFLFNBQWlCO1FBQ2hFLE9BQU8sQ0FBQyxVQUFVLEdBQUcsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxVQUFVLEdBQUcsU0FBUyxDQUFDLENBQUM7SUFDdkQsQ0FBQztJQUVPLCtDQUFvQixHQUE1QixVQUE2QixLQUFnQixFQUFFLFdBQStCO1FBQzFFLElBQUksS0FBSyxLQUFLLEdBQUcsRUFBRTtZQUNmLElBQUksV0FBVyxLQUFLLFFBQVE7Z0JBQUUsSUFBSSxDQUFDLGFBQWEsRUFBRSxDQUFDO1lBQ25ELElBQUksSUFBSSxDQUFDLGFBQWEsS0FBSyxNQUFNO2dCQUFFLElBQUksQ0FBQyxjQUFjLENBQUMsV0FBVyxDQUFDLENBQUM7U0FDdkU7YUFBTTtZQUNILElBQUksQ0FBQyxlQUFlLEVBQUUsQ0FBQztTQUMxQjtJQUNMLENBQUM7SUFFRDs7O09BR0c7SUFDSyx5Q0FBYyxHQUF0QixVQUF1QixXQUE4QjtRQUNqRCxJQUFJLFdBQVcsS0FBSyxRQUFRLEVBQUU7WUFDMUIsSUFBSSxDQUFDLENBQUMsR0FBRyxFQUFFLENBQUMsWUFBWSxFQUFFLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQztTQUMzRDthQUFNO1lBQ0gsSUFBSSxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsQ0FBQztTQUN4QjtJQUNMLENBQUM7SUFFRCw4RUFBOEU7SUFFdkUsb0NBQVMsR0FBaEIsVUFBaUIsV0FBOEI7UUFFM0MsSUFBSSxDQUFDLFNBQVMsQ0FBQyxVQUFVLEdBQUcsV0FBVyxDQUFDO1FBRXhDLElBQUksQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLFlBQVksRUFBRSxRQUFRLENBQUMsQ0FBQztRQUV0Qyw2REFBNkQ7UUFDN0QsSUFBSSxDQUFDLFNBQVMsQ0FBQyx5QkFBeUIsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLEVBQUUsQ0FBQyxDQUFDO1FBRXpELDhLQUE4SztRQUM5SyxJQUFJLElBQUksQ0FBQyxRQUFRLElBQUksSUFBSSxDQUFDLElBQUksQ0FBQyxNQUFNLEtBQUssSUFBSSxDQUFDLFFBQVEsQ0FBQyxNQUFNLEVBQUU7WUFDNUQsSUFBSSxDQUFDLElBQUksR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUM7WUFDdEQsMEZBQTBGO1NBQzdGO1FBRUQsc0RBQXNEO1FBQ3RELElBQUksQ0FBQyxVQUFVLENBQUMsV0FBVyxDQUFDLENBQUM7UUFFN0IsSUFBSSxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsWUFBWSxFQUFFLFNBQVMsQ0FBQyxDQUFDO1FBRXZDLGlDQUFpQztRQUNqQyxJQUFJLENBQUMsYUFBYSxFQUFFLENBQUM7UUFFckIseUJBQXlCO1FBQ3pCLElBQUksQ0FBQyxPQUFPLEVBQUUsQ0FBQztRQUVmLHNEQUFzRDtRQUN0RCxJQUFJLENBQUMsU0FBUyxDQUFDLHVCQUF1QixDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQztRQUVuRCw0REFBNEQ7UUFDNUQsSUFBSSxJQUFJLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsT0FBTyxFQUFFO1lBQ2xDLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxLQUFLLENBQUMsT0FBTyxFQUFFLElBQUksQ0FBQyxLQUFLLEdBQUcsSUFBSSxDQUFDLENBQUM7WUFDMUQsSUFBSSxDQUFDLFNBQVMsQ0FBQyxtQkFBbUIsQ0FBQyxJQUFJLENBQUMsa0JBQWtCLEVBQUUsSUFBSSxDQUFDLHFCQUFxQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7U0FDOUY7UUFFRCwyQkFBMkI7UUFDM0IsSUFBSSxDQUFDLFNBQVMsQ0FBQywyQkFBMkIsRUFBRSxDQUFDO1FBRTdDLDBHQUEwRztRQUMxRyxJQUFJLENBQUMsWUFBWSxFQUFFLENBQUM7SUFDeEIsQ0FBQztJQUVPLHFDQUFVLEdBQWxCLFVBQW1CLFdBQThCO1FBQzdDLGdEQUFnRDtRQUNoRCxJQUFJLGVBQWUsR0FBaUIsSUFBSSxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUM7UUFDdEQsSUFBSSxNQUFNLEdBQW9CLElBQUksQ0FBQyxTQUFTLENBQUMsWUFBWSxDQUFDLGVBQWUsRUFBRSxJQUFJLENBQUMsU0FBUyxDQUFDLENBQUM7UUFDM0YsSUFBSSxDQUFDLFNBQVMsQ0FBQyxlQUFlLENBQUMsTUFBTSxDQUFDLFFBQVEsQ0FBQyxDQUFDO1FBRWhELElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxNQUFNLENBQUMsUUFBUSxFQUFFLE1BQU0sQ0FBQyxRQUFRLEVBQUUsTUFBTSxDQUFDLFFBQVEsQ0FBQyxDQUFDO1FBRTFFLElBQUksS0FBSyxHQUFXLElBQUksQ0FBQyxTQUFTLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxJQUFJLEVBQUUsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDO1FBQ3BFLElBQUksQ0FBQyxvQkFBb0IsQ0FBQyxHQUFHLEVBQUUsV0FBVyxDQUFDLENBQUM7UUFDNUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxDQUFDO1FBQzNCLElBQUksQ0FBQyxjQUFjLENBQUMsV0FBVyxFQUFFLEtBQUssQ0FBQyxXQUFXLENBQUMsQ0FBQztRQUVwRCxJQUFJLENBQUMsb0JBQW9CLENBQUMsR0FBRyxFQUFFLFdBQVcsQ0FBQyxDQUFDO1FBRTVDLElBQUksZUFBZSxHQUF3QixJQUFJLENBQUMseUJBQXlCLENBQUMsTUFBTSxDQUFDLENBQUM7UUFFbEYsSUFBSSxlQUFlLElBQUksZUFBZSxDQUFDLFVBQVUsRUFBRTtZQUMvQyxJQUFJLENBQUMsb0JBQW9CLENBQUMsR0FBRyxFQUFFLFdBQVcsQ0FBQyxDQUFDO1lBQzVDLElBQUksQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsQ0FBQztZQUMzQixJQUFJLENBQUMsY0FBYyxDQUFDLFdBQVcsRUFBRSxLQUFLLENBQUMsV0FBVyxDQUFDLENBQUM7WUFFcEQsSUFBSSxDQUFDLG9CQUFvQixDQUFDLEdBQUcsRUFBRSxXQUFXLENBQUMsQ0FBQztTQUMvQztRQUVELHFEQUFxRDtRQUNyRCxJQUFJLENBQUMsVUFBVSxHQUFHLElBQUksQ0FBQyxTQUFTLENBQUMsYUFBYSxDQUFDLElBQUksQ0FBQyxPQUFPLEVBQUUsSUFBSSxDQUFDLE9BQU8sRUFBRSxlQUFlLENBQUMsUUFBUSxDQUFDLENBQUM7UUFFckcsZUFBZTtRQUNmLElBQUksQ0FBQyxTQUFTLEdBQUcsZUFBZSxDQUFDLGNBQWMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLFFBQVEsQ0FBQztRQUNqRixJQUFJLENBQUMsU0FBUyxHQUFHLGVBQWUsQ0FBQyxjQUFjLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxRQUFRLENBQUM7UUFDakYsSUFBSSxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxJQUFJLENBQUMsU0FBUyxFQUFFLElBQUksQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDO0lBQ3BELENBQUM7SUFHTywrQ0FBb0IsR0FBNUIsVUFBNkIsS0FBZ0IsRUFBRSxXQUE4QjtRQUN6RSxJQUFJLENBQUMsZUFBZSxDQUFDLEtBQUssQ0FBQyxDQUFDO1FBQzVCLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxLQUFLLENBQUMsQ0FBQztRQUMvQixJQUFJLENBQUMsb0JBQW9CLENBQUMsS0FBSyxFQUFFLFdBQVcsQ0FBQyxDQUFDO0lBQ2xELENBQUM7SUFFRDs7T0FFRztJQUNLLHVDQUFZLEdBQXBCO1FBQ0ksSUFBSSxZQUFZLEdBQVEsSUFBSSxDQUFDLEdBQUcsQ0FBQyxTQUFTLENBQUMsNEJBQTRCLEdBQUcsSUFBSSxDQUFDLE1BQU0sQ0FBQyxFQUFFLEdBQUcsT0FBTyxDQUFDLENBQUM7UUFDcEcsSUFBSSxZQUFZLENBQUMsS0FBSyxFQUFFLEVBQUU7WUFDdEIsWUFBWSxHQUFHLElBQUksQ0FBQyxHQUFHLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxDQUFDLE1BQU0sQ0FBQyxVQUFVLENBQUMsQ0FBQyxJQUFJLENBQUMsSUFBSSxFQUFFLHNCQUFzQixHQUFHLElBQUksQ0FBQyxNQUFNLENBQUMsRUFBRSxDQUFDLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxDQUFDO1lBQzdILFlBQVk7aUJBQ1AsSUFBSSxDQUFDLEdBQUcsRUFBRSxDQUFDLENBQUM7aUJBQ1osSUFBSSxDQUFDLEdBQUcsRUFBRSxDQUFDLENBQUM7aUJBQ1osSUFBSSxDQUFDLE1BQU0sRUFBRSxNQUFNLENBQUMsQ0FBQztTQUM3QjtRQUNELFlBQVk7YUFDUCxJQUFJLENBQUMsT0FBTyxFQUFFLElBQUksQ0FBQyxLQUFLLENBQUM7YUFDekIsSUFBSSxDQUFDLFFBQVEsRUFBRSxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUM7SUFDckMsQ0FBQztJQUVPLDRDQUFpQixHQUF6QixVQUEwQixTQUFpQixFQUFFLFNBQWlCLEVBQUUsU0FBaUI7UUFDN0UsSUFBSSxXQUFXLEdBQWlCLElBQUksQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDO1FBQ2xELElBQUksQ0FBQyxPQUFPLEdBQUcsSUFBSSxDQUFDLFNBQVMsQ0FBQyxpQkFBaUIsQ0FBQyxTQUFTLEVBQUUsU0FBUyxFQUFFLFdBQVcsQ0FBQyxjQUFjLEVBQUUsSUFBSSxDQUFDLENBQUM7UUFDeEcsSUFBSSxDQUFDLE9BQU8sR0FBRyxJQUFJLENBQUMsU0FBUyxDQUFDLGlCQUFpQixDQUFDLFNBQVMsRUFBRSxTQUFTLEVBQUUsV0FBVyxDQUFDLGNBQWMsRUFBRSxNQUFNLENBQUMsQ0FBQztJQUM5RyxDQUFDO0lBRUQ7Ozs7S0FJQztJQUNPLG9EQUF5QixHQUFqQyxVQUFrQyxTQUEwQjtRQUN4RCxJQUFJLE1BQU0sR0FBVyxJQUFJLENBQUMsR0FBRyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQztRQUNsRSxJQUFJLE1BQU0sSUFBSSxDQUFDO1lBQUUsT0FBTyxFQUFFLFVBQVUsRUFBRSxLQUFLLEVBQUUsUUFBUSxFQUFFLENBQUMsRUFBRSxDQUFDO1FBRTNELElBQUksVUFBa0IsQ0FBQztRQUN2QixJQUFJLG1CQUFtQixHQUFxQixNQUFNLENBQUMsTUFBTSxDQUFDLEVBQUUsRUFBRSxJQUFJLENBQUMsU0FBUyxDQUFDLGVBQWUsQ0FBQyxDQUFDO1FBRTlGLElBQUksSUFBSSxDQUFDLEdBQUcsQ0FBQyxRQUFRLEVBQUU7WUFDbkIsMEdBQTBHO1lBQzFHLGdKQUFnSjtZQUNoSixVQUFVLEdBQUcsSUFBSSxDQUFDLEdBQUcsQ0FBQyxtQkFBbUIsQ0FBQyxPQUFPLEVBQUUsbUJBQW1CLENBQUMsT0FBTyxDQUFDLENBQUM7U0FDbkY7YUFBTTtZQUNILFVBQVUsR0FBRyxJQUFJLENBQUMsU0FBUyxDQUFDLHVCQUF1QixDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsUUFBUSxDQUFDLENBQUM7U0FDaEc7UUFFRCxJQUFJLFlBQVksR0FBVyxTQUFTLENBQUMsUUFBUSxDQUFDO1FBQzlDLElBQUksUUFBUSxHQUFXLFlBQVksQ0FBQztRQUNwQyxJQUFJLFNBQVMsR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDLENBQUMsSUFBSSxDQUFDLE9BQU8sR0FBRyxRQUFRLEdBQUcsSUFBSSxDQUFDLE9BQU8sQ0FBQyxHQUFHLFFBQVEsQ0FBQyxDQUFDO1FBRWhGLElBQUksTUFBTSxHQUFHLFVBQVUsSUFBSSxTQUFTLEtBQUssQ0FBQztZQUFFLE9BQU8sRUFBRSxVQUFVLEVBQUUsS0FBSyxFQUFFLFFBQVEsRUFBRSxDQUFDLEVBQUUsQ0FBQztRQUV0RixJQUFJLGFBQWEsR0FBVyxJQUFJLENBQUMsU0FBUyxDQUFDLGVBQWUsQ0FBQyxJQUFJLENBQUMsT0FBTyxFQUFFLElBQUksQ0FBQyxPQUFPLENBQUMsQ0FBQyxRQUFRLEVBQUUsQ0FBQyxNQUFNLENBQUM7UUFFekcsT0FBTyxDQUFDLE1BQU0sR0FBRyxTQUFTLENBQUMsR0FBRyxVQUFVLElBQUksU0FBUyxHQUFHLENBQUMsRUFBRTtZQUN2RCxRQUFRLEdBQUcsUUFBUSxHQUFHLENBQUMsQ0FBQztZQUN4QixJQUFJLENBQUMsaUJBQWlCLENBQUMsU0FBUyxDQUFDLFFBQVEsRUFBRSxTQUFTLENBQUMsUUFBUSxFQUFFLFFBQVEsQ0FBQyxDQUFDO1lBRXpFLCtHQUErRztZQUMvRyxtRkFBbUY7WUFDbkYsSUFBSSxJQUFJLENBQUMsR0FBRyxDQUFDLFFBQVEsSUFBSSxJQUFJLENBQUMsU0FBUyxDQUFDLGVBQWUsQ0FBQyxJQUFJLENBQUMsT0FBTyxFQUFFLElBQUksQ0FBQyxPQUFPLENBQUMsQ0FBQyxRQUFRLEVBQUUsQ0FBQyxNQUFNLEdBQUcsYUFBYSxFQUFFO2dCQUNuSCxVQUFVLEdBQUcsSUFBSSxDQUFDLFNBQVMsQ0FBQyxpQkFBaUIsQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLGVBQWUsQ0FBQyxJQUFJLENBQUMsT0FBTyxFQUFFLElBQUksQ0FBQyxPQUFPLENBQUMsRUFBRSxTQUFTLENBQUMsQ0FBQzthQUN4SDtZQUVELFNBQVMsR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDLENBQUMsSUFBSSxDQUFDLE9BQU8sR0FBRyxRQUFRLEdBQUcsSUFBSSxDQUFDLE9BQU8sQ0FBQyxHQUFHLFFBQVEsQ0FBQyxDQUFDO1NBQy9FO1FBRUQsNkZBQTZGO1FBQzdGLHFIQUFxSDtRQUNySCxJQUFJLFlBQVksS0FBSyxRQUFRLEVBQUU7WUFDM0IsSUFBSSxDQUFDLFNBQVMsQ0FBQyxlQUFlLENBQUMsUUFBUSxDQUFDLENBQUM7WUFDekMsSUFBSSxrQkFBa0IsR0FBcUIsSUFBSSxDQUFDLFNBQVMsQ0FBQywyQkFBMkIsQ0FBQyxFQUFFLE9BQU8sRUFBRSxJQUFJLENBQUMsT0FBTyxFQUFFLE9BQU8sRUFBRSxJQUFJLENBQUMsT0FBTyxFQUFFLENBQUMsQ0FBQztZQUN4SSxJQUFJLGtCQUFrQixDQUFDLE9BQU8sS0FBSyxtQkFBbUIsQ0FBQyxPQUFPLElBQUksa0JBQWtCLENBQUMsT0FBTyxLQUFLLG1CQUFtQixDQUFDLE9BQU8sRUFBRTtnQkFDMUgsT0FBTyxFQUFFLFVBQVUsRUFBRSxJQUFJLEVBQUUsUUFBUSxFQUFFLFFBQVEsRUFBRSxDQUFDO2FBQ25EO1NBQ0o7UUFFRCxPQUFPLEVBQUUsVUFBVSxFQUFFLEtBQUssRUFBRSxRQUFRLEVBQUUsUUFBUSxFQUFFLENBQUM7SUFDckQsQ0FBQztJQUVELGtGQUFrRjtJQUUxRSx3Q0FBYSxHQUFyQjtRQUNJLElBQUksQ0FBQyxJQUFJLENBQUMsa0JBQWtCO1lBQUUsSUFBSSxDQUFDLGtCQUFrQixHQUFHLElBQUksQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQyxPQUFPLEVBQUUsZ0NBQWdDLENBQUMsQ0FBQztRQUMvSCxJQUFJLENBQUMsU0FBUyxDQUFDLE9BQU8sQ0FBQyxjQUFjLEdBQUcsRUFBRSxLQUFLLEVBQUUsSUFBSSxDQUFDLEtBQUssRUFBRSxNQUFNLEVBQUUsSUFBSSxDQUFDLE1BQU0sRUFBRSxDQUFDO1FBQ25GLElBQUksSUFBSSxDQUFDLFNBQVMsQ0FBQyxPQUFPLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxNQUFNLEVBQUUsT0FBTyxFQUFFLFVBQVUsQ0FBQztZQUFFLElBQUksQ0FBQyxhQUFhLEVBQUUsQ0FBQztRQUM1RixJQUFJLElBQUksQ0FBQyxTQUFTLENBQUMsT0FBTyxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsTUFBTSxFQUFFLE9BQU8sRUFBRSxlQUFlLENBQUM7WUFBRSxJQUFJLENBQUMsa0JBQWtCLEVBQUUsQ0FBQztRQUN0RyxJQUFJLElBQUksQ0FBQyxTQUFTLENBQUMsT0FBTyxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsTUFBTSxFQUFFLE9BQU8sRUFBRSxVQUFVLENBQUM7WUFBRSxJQUFJLENBQUMsYUFBYSxFQUFFLENBQUM7SUFDaEcsQ0FBQztJQUVPLHdDQUFhLEdBQXJCO1FBQ0ksc0ZBQXNGO1FBQ3RGLElBQUksS0FBSyxHQUFHLElBQUksQ0FBQyxTQUFTLENBQUMsT0FBTyxDQUFDLGNBQWMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUM7UUFDMUQsdUZBQXVGO1FBQ3ZGLElBQUksS0FBSyxHQUFrQixDQUFDLEVBQUUsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxVQUFBLElBQUksSUFBSSxPQUFBLElBQUksQ0FBQyxDQUFDLENBQUMsS0FBSyxFQUFaLENBQVksQ0FBQyxDQUFDLENBQUM7UUFDNUUsdURBQXVEO1FBQ3ZELElBQUksQ0FBQyxTQUFTLENBQUMsT0FBTyxDQUFDLFlBQVksQ0FBQyxJQUFJLENBQUMsa0JBQWtCLEVBQUUsS0FBSyxFQUFFLE9BQU8sRUFBRSxVQUFVLEVBQUUsS0FBSyxDQUFDLENBQUM7SUFDcEcsQ0FBQztJQUVELHVCQUF1QjtJQUNmLHdDQUFhLEdBQXJCO1FBQ0ksSUFBSSxDQUFDLFNBQVMsQ0FBQyxPQUFPLENBQUMsWUFBWSxDQUFDLElBQUksQ0FBQyxrQkFBa0IsRUFBRSxJQUFJLENBQUMsVUFBVSxFQUFFLE9BQU8sRUFBRSxVQUFVLEVBQUUsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDO0lBQy9HLENBQUM7SUFFTyw2Q0FBa0IsR0FBMUI7UUFDSSxJQUFJLFdBQVcsR0FBaUIsSUFBSSxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUM7UUFDbEQsSUFBSSxXQUFXLENBQUMsaUJBQWlCLElBQUksV0FBVyxDQUFDLFlBQVksSUFBSSxDQUFDLFdBQVcsQ0FBQyxpQkFBaUI7WUFBRSxPQUFPO1FBRXhHLElBQUksVUFBVSxHQUFXLElBQUksQ0FBQyxTQUFTLENBQUMsaUJBQWlCLENBQUMsSUFBSSxDQUFDLFNBQVMsRUFBRSxXQUFXLENBQUMsaUJBQWlCLEVBQUUsS0FBSyxFQUFFLElBQUksQ0FBQyxDQUFDO1FBQ3RILElBQUksVUFBVSxHQUFXLElBQUksQ0FBQyxTQUFTLENBQUMsaUJBQWlCLENBQUMsSUFBSSxDQUFDLFNBQVMsRUFBRSxXQUFXLENBQUMsaUJBQWlCLEVBQUUsS0FBSyxFQUFFLE1BQU0sQ0FBQyxDQUFDO1FBQ3hILElBQUksZUFBZSxHQUFrQixJQUFJLENBQUMsU0FBUyxDQUFDLGFBQWEsQ0FBQyxVQUFVLEVBQUUsVUFBVSxFQUFFLFdBQVcsQ0FBQyxpQkFBaUIsQ0FBQyxDQUFDO1FBRXpILElBQUksQ0FBQyxTQUFTLENBQUMsT0FBTyxDQUFDLFlBQVksQ0FBQyxJQUFJLENBQUMsa0JBQWtCLEVBQUUsZUFBZSxFQUFFLE9BQU8sRUFBRSxlQUFlLEVBQUUsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDO0lBQ3BILENBQUM7SUFFRCw0RUFBNEU7SUFFckUsa0NBQU8sR0FBZDtRQUNJLElBQUksWUFBWSxHQUFzQjtZQUNsQyxLQUFLLEVBQUUsWUFBWSxHQUFHLElBQUksQ0FBQyxLQUFLLEdBQUcsS0FBSztZQUN4QyxJQUFJLEVBQUUsZ0JBQWdCO1lBQ3RCLEdBQUcsRUFBRSxnQkFBZ0I7WUFDckIsTUFBTSxFQUFFLGNBQWMsR0FBRyxJQUFJLENBQUMsTUFBTSxHQUFHLEdBQUc7U0FDN0MsQ0FBQztRQUVGLElBQUksV0FBVyxHQUFpQixJQUFJLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQztRQUNsRCxJQUFJLFdBQVcsR0FBaUIsSUFBSSxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUM7UUFDbEQsSUFBSSxNQUFNLEdBQVksSUFBSSxDQUFDLEdBQUcsQ0FBQyxRQUFRLENBQUM7UUFDeEMsSUFBSSxRQUFRLEdBQStCO1lBQ3ZDLENBQUMsRUFBRSxNQUFNLENBQUMsQ0FBQyxDQUFDLFdBQVcsQ0FBQyxRQUFRLEtBQUssSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsV0FBVyxDQUFDLFFBQVE7WUFDdEUsQ0FBQyxFQUFFLE1BQU0sQ0FBQyxDQUFDLENBQUMsV0FBVyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsV0FBVyxDQUFDLFFBQVEsS0FBSyxJQUFJLENBQUMsS0FBSztTQUN6RSxDQUFDO1FBRUYsSUFBSSxLQUFLLEdBQUcsSUFBSSxDQUFDLGdCQUFnQixDQUFDLEdBQUcsRUFBRSxRQUFRLENBQUMsQ0FBQyxFQUFFLE1BQU0sQ0FBQyxDQUFDO1FBQzNELElBQUksQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFDO1FBQzFCLElBQUksQ0FBQyxLQUFLLEdBQUcsSUFBSSxDQUFDLGdCQUFnQixDQUFDLEdBQUcsRUFBRSxRQUFRLENBQUMsQ0FBQyxFQUFFLE1BQU0sQ0FBQyxDQUFDO1FBRTVELEtBQUssQ0FBQyxJQUFJLENBQUMsV0FBVyxFQUFFLElBQUksQ0FBQyxTQUFTLENBQUMsbUJBQW1CLENBQUMsR0FBRyxFQUFFLFFBQVEsQ0FBQyxDQUFDLEVBQUUsWUFBWSxDQUFDLENBQUMsQ0FBQztRQUMzRixJQUFJLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxXQUFXLEVBQUUsSUFBSSxDQUFDLFNBQVMsQ0FBQyxtQkFBbUIsQ0FBQyxHQUFHLEVBQUUsUUFBUSxDQUFDLENBQUMsRUFBRSxZQUFZLENBQUMsQ0FBQyxDQUFDO1FBRWhHLElBQUksQ0FBQyxTQUFTLENBQUMsa0JBQWtCLENBQUMsS0FBSyxFQUFFLEdBQUcsQ0FBQyxDQUFDO1FBQzlDLElBQUksQ0FBQyxTQUFTLENBQUMsa0JBQWtCLENBQUMsSUFBSSxDQUFDLEtBQUssRUFBRSxHQUFHLENBQUMsQ0FBQztRQUVuRCxJQUFJLElBQUksQ0FBQyxTQUFTLENBQUMsZUFBZSxFQUFFO1lBQ2hDLElBQUksV0FBVyxHQUFHLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxRQUFRLENBQUMsQ0FBQyxFQUFFLElBQUksQ0FBQyxHQUFHLENBQUMsUUFBUSxDQUFDLENBQUM7WUFDN0UsV0FBVyxDQUFDLElBQUksQ0FBQyxXQUFXLEVBQUUsSUFBSSxDQUFDLFNBQVMsQ0FBQyxtQkFBbUIsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxRQUFRLENBQUMsQ0FBQyxFQUFFLFlBQVksQ0FBQyxDQUFDLENBQUM7WUFDbEcsSUFBSSxDQUFDLFNBQVMsQ0FBQyxrQkFBa0IsQ0FBQyxXQUFXLEVBQUUsR0FBRyxDQUFDLENBQUM7WUFDcEQsSUFBSSxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFDLENBQUM7U0FDbkM7SUFDTCxDQUFDO0lBRU8sMkNBQWdCLEdBQXhCLFVBQXlCLEtBQWdCLEVBQUUsU0FBa0IsRUFBRSxPQUFnQjtRQUEvRSxpQkE4Q0M7UUE3Q0csSUFBSSxRQUFRLEdBQUcsV0FBVyxDQUFDLEtBQUssRUFBRSxJQUFJLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQztRQUMvQyxJQUFJLFNBQVMsR0FBVyx1QkFBdUIsR0FBRyxLQUFLLENBQUM7UUFFeEQsSUFBSSxDQUFDLE9BQU8sSUFBSSxLQUFLLEtBQUssR0FBRyxDQUFDLElBQUksQ0FBQyxDQUFDLE9BQU8sSUFBSSxLQUFLLEtBQUssR0FBRyxDQUFDLEVBQUU7WUFDM0QsU0FBUyxJQUFJLDJCQUEyQixDQUFDO1NBQzVDO1FBRUQsSUFBSSxTQUFTO1lBQUUsU0FBUyxJQUFJLDJCQUEyQixDQUFDO1FBRXhELElBQUksS0FBSyxLQUFLLEdBQUcsRUFBRTtZQUNmLFFBQVE7aUJBQ0gsVUFBVSxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUM7aUJBQzNCLFVBQVUsQ0FBQyxVQUFDLENBQUM7Z0JBQ1YsZ0hBQWdIO2dCQUNoSCxJQUFJLEtBQUssR0FBRyxLQUFJLENBQUMsU0FBUyxDQUFDLDRCQUE0QixDQUFDLENBQUMsQ0FBQyxDQUFDO2dCQUMzRCxPQUFPLEtBQUksQ0FBQyxTQUFTLENBQUMsaUJBQWlCLENBQUMsS0FBSSxDQUFDLE1BQU0sQ0FBQyxLQUFLLEVBQUUsS0FBSyxDQUFDLENBQUM7WUFDdEUsQ0FBQyxDQUFDLENBQUM7U0FDVjtRQUVELElBQUksUUFBUSxHQUFHLElBQUksQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQyxPQUFPLEVBQUUsU0FBUyxDQUFDLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxDQUFDO1FBRTlFLE9BQU8sUUFBUSxDQUFDO1FBRWhCLFNBQVMsV0FBVyxDQUFDLEtBQWdCLEVBQUUsTUFBTTtZQUN6QyxJQUFJLE9BQU8sRUFBRTtnQkFDVCxJQUFJLEtBQUssS0FBSyxHQUFHLEVBQUU7b0JBQ2YsSUFBSSxTQUFTO3dCQUFFLE9BQU8sRUFBRSxDQUFDLFNBQVMsQ0FBQyxNQUFNLENBQUMsQ0FBQztvQkFDM0MsT0FBTyxFQUFFLENBQUMsUUFBUSxDQUFDLE1BQU0sQ0FBQyxDQUFDO2lCQUM5QjtnQkFDRCxJQUFJLEtBQUssS0FBSyxHQUFHLEVBQUU7b0JBQ2YsSUFBSSxTQUFTO3dCQUFFLE9BQU8sRUFBRSxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsQ0FBQztvQkFDekMsT0FBTyxFQUFFLENBQUMsVUFBVSxDQUFDLE1BQU0sQ0FBQyxDQUFDO2lCQUNoQzthQUNKO2lCQUFNO2dCQUNILElBQUksS0FBSyxLQUFLLEdBQUcsRUFBRTtvQkFDZixJQUFJLFNBQVM7d0JBQUUsT0FBTyxFQUFFLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxDQUFDO29CQUN6QyxPQUFPLEVBQUUsQ0FBQyxVQUFVLENBQUMsTUFBTSxDQUFDLENBQUM7aUJBQ2hDO2dCQUNELElBQUksS0FBSyxLQUFLLEdBQUcsRUFBRTtvQkFDZixJQUFJLFNBQVM7d0JBQUUsT0FBTyxFQUFFLENBQUMsU0FBUyxDQUFDLE1BQU0sQ0FBQyxDQUFDO29CQUMzQyxPQUFPLEVBQUUsQ0FBQyxRQUFRLENBQUMsTUFBTSxDQUFDLENBQUM7aUJBQzlCO2FBQ0o7UUFDTCxDQUFDO0lBRUwsQ0FBQztJQUVELG9GQUFvRjtJQUU3RSx1Q0FBWSxHQUFuQixVQUFvQixTQUFtQjtRQUNuQyxvRkFBb0Y7UUFDcEYsWUFBWSxDQUFDLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDO1FBQ3BDLElBQUksQ0FBQyxnQkFBZ0IsR0FBRyxVQUFVLENBQUM7WUFDL0IsU0FBUyxFQUFFLENBQUM7UUFDaEIsQ0FBQyxDQUFDLENBQUM7SUFDUCxDQUFDO0lBR00sc0NBQVcsR0FBbEI7UUFDSSxZQUFZLENBQUMsSUFBSSxDQUFDLGdCQUFnQixDQUFDLENBQUM7UUFDcEMsSUFBSSxDQUFDLHNCQUFzQixDQUFDLFVBQVUsRUFBRSxVQUFDLElBQUksSUFBSyxPQUFBLElBQUksQ0FBQyxNQUFNLEVBQUUsRUFBYixDQUFhLENBQUMsQ0FBQztRQUNqRSxJQUFJLElBQUksQ0FBQyxLQUFLO1lBQUUsSUFBSSxDQUFDLEtBQUssQ0FBQyxNQUFNLEVBQUUsQ0FBQztRQUNwQyxJQUFJLElBQUksQ0FBQyxrQkFBa0I7WUFBRSxJQUFJLENBQUMsa0JBQWtCLENBQUMsU0FBUyxDQUFDLEdBQUcsQ0FBQyxDQUFDLE1BQU0sRUFBRSxDQUFDO1FBQzdFLElBQUksQ0FBQyxzQkFBc0IsQ0FBQyx1QkFBdUIsRUFBRSxVQUFDLFNBQVMsSUFBSyxPQUFBLFNBQVMsQ0FBQyxTQUFTLENBQUMsR0FBRyxDQUFDLENBQUMsTUFBTSxFQUFFLEVBQWpDLENBQWlDLENBQUMsQ0FBQztRQUN2RyxJQUFJLElBQUksQ0FBQyxrQkFBa0I7WUFBRSxJQUFJLENBQUMsa0JBQWtCLENBQUMsU0FBUyxDQUFDLEdBQUcsQ0FBQyxDQUFDLE1BQU0sRUFBRSxDQUFDO1FBQzdFLElBQUksQ0FBQyxrQkFBa0IsRUFBRSxDQUFDO0lBQzlCLENBQUM7SUFFTyxpREFBc0IsR0FBOUIsVUFBK0IsSUFBWSxFQUFFLFFBQWtCO1FBQzNELElBQUksSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDLE1BQU0sS0FBSyxDQUFDLEVBQUU7WUFDekIsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDLE9BQU8sQ0FBQyxVQUFBLE9BQU8sSUFBSSxPQUFBLFFBQVEsQ0FBQyxPQUFPLENBQUMsRUFBakIsQ0FBaUIsQ0FBQyxDQUFDO1lBQ2pELElBQUksQ0FBQyxJQUFJLENBQUMsR0FBRyxFQUFFLENBQUM7U0FDbkI7SUFDTCxDQUFDO0lBRUQsa0ZBQWtGO0lBRTFFLHlDQUFjLEdBQXRCLFVBQXVCLFdBQThCLEVBQUUsWUFBb0I7UUFBM0UsaUJBNEJDO1FBM0JHLElBQUksQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxPQUFPLElBQUksQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsT0FBTztZQUFFLE9BQU87UUFFNUUsSUFBSSxJQUFJLENBQUMscUJBQXFCLENBQUMsTUFBTSxLQUFLLENBQUMsRUFBRTtZQUN6QyxJQUFJLENBQUMsc0JBQXNCLENBQUMsdUJBQXVCLEVBQUUsVUFBQyxTQUFTLElBQUssT0FBQSxTQUFTLENBQUMsU0FBUyxDQUFDLEdBQUcsQ0FBQyxDQUFDLE1BQU0sRUFBRSxFQUFqQyxDQUFpQyxDQUFDLENBQUM7U0FDMUc7UUFFRCxJQUFJLFFBQVEsR0FBVyxJQUFJLENBQUMsa0JBQWtCLENBQUMsV0FBVyxDQUFDLENBQUM7UUFFNUQsSUFBSSxDQUFDLFNBQVMsQ0FBQyxpQkFBaUIsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLEVBQUUsRUFBRSxRQUFRLEVBQUUsWUFBWSxDQUFDLENBQUM7UUFDekUsSUFBSSxDQUFDLFNBQVMsQ0FBQyxtQkFBbUIsRUFBRSxDQUFDO1FBRXJDLElBQUksQ0FBQyxzQkFBc0IsRUFBRSxDQUFDO1FBRTlCLElBQUksSUFBSSxDQUFDLFNBQVMsQ0FBQyxXQUFXLEtBQUssQ0FBQztZQUFFLElBQUksQ0FBQyxNQUFNLENBQUMsV0FBVyxDQUFDLENBQUM7UUFFL0QsSUFBSSxDQUFDLHFCQUFxQixDQUFDLE9BQU8sQ0FBQyxVQUFDLG1CQUFtQixFQUFFLEtBQUs7WUFDMUQsS0FBSSxDQUFDLFNBQVMsQ0FBQywwQkFBMEIsQ0FBQyxtQkFBbUIsQ0FBQyxDQUFDO1lBQy9ELGlFQUFpRTtZQUNqRSxJQUFJLEtBQUksQ0FBQyxTQUFTLENBQUMsV0FBVyxLQUFLLENBQUMsRUFBRTtnQkFDbEMsSUFBSSxRQUFRLEdBQUcsS0FBSyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFJLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLEtBQUksQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLFFBQVEsQ0FBQztnQkFDdEYsS0FBSSxDQUFDLGNBQWMsQ0FDZixtQkFBbUIsRUFDbkIsRUFBRSxXQUFXLEVBQUUsS0FBSSxDQUFDLFNBQVMsQ0FBQyxXQUFXLEVBQUUsVUFBVSxFQUFFLFFBQVEsRUFBRSxFQUNqRSxFQUFFLFFBQVEsRUFBRSxLQUFJLENBQUMsU0FBUyxDQUFDLFFBQVEsRUFBRSxRQUFRLEVBQUUsUUFBUSxFQUFFLENBQzVELENBQUM7YUFDTDtRQUNMLENBQUMsQ0FBQyxDQUFDO0lBQ1AsQ0FBQztJQUVPLGlEQUFzQixHQUE5QjtRQUNJLElBQUksQ0FBQyxxQkFBcUIsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxxQkFBcUIsRUFBRSxDQUFDLENBQUM7UUFFeEUsa0JBQWtCO1FBQ2xCLElBQUksSUFBSSxDQUFDLFNBQVMsQ0FBQyxlQUFlLEVBQUU7WUFDaEMsSUFBSSxDQUFDLHFCQUFxQixDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLHFCQUFxQixDQUFDLDJCQUEyQixDQUFDLENBQUMsQ0FBQztTQUN0RztJQUNMLENBQUM7SUFFTyw2Q0FBa0IsR0FBMUIsVUFBMkIsV0FBOEI7UUFDckQsT0FBTyxDQUFDLFdBQVcsS0FBSyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxTQUFTLEVBQUUsR0FBRyxJQUFJLENBQUMsQ0FBQyxDQUFDLFlBQVksRUFBRSxHQUFHLElBQUksQ0FBQyxDQUFDLENBQUMsSUFBSSxFQUFFLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxLQUFLLEdBQUcsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLE1BQU0sR0FBRyxDQUFDLENBQUMsQ0FBQztJQUN2SSxDQUFDO0lBRU8saUNBQU0sR0FBZCxVQUFlLFdBQThCO1FBQ3pDLElBQUksUUFBUSxHQUFXLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLFFBQVEsRUFBRSxXQUFXLENBQUMsQ0FBQztRQUVyRixJQUFJLFFBQVEsS0FBSyxJQUFJLENBQUMsUUFBUSxDQUFDLE1BQU07WUFBRSxPQUFPO1FBRTlDLDJFQUEyRTtRQUMzRSxJQUFJLENBQUMsSUFBSSxHQUFHLElBQUksQ0FBQyxRQUFRLENBQUMsS0FBSyxDQUFDLENBQUMsRUFBRSxRQUFRLENBQUMsQ0FBQztRQUM3QyxJQUFJLEtBQUssR0FBVyxJQUFJLENBQUMsU0FBUyxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsSUFBSSxFQUFFLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQztRQUVwRSwyQ0FBMkM7UUFDM0MsSUFBSSxJQUFJLENBQUMsYUFBYSxLQUFLLE1BQU07WUFBRSxJQUFJLENBQUMsY0FBYyxDQUFDLFdBQVcsQ0FBQyxDQUFDO1FBQ3BFLElBQUksQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsQ0FBQztRQUUzQiw0R0FBNEc7UUFDNUcsSUFBSSxDQUFDLFNBQVMsQ0FBQyxxQkFBcUIsQ0FBQyxLQUFLLENBQUMsV0FBVyxDQUFDLENBQUM7UUFDeEQsSUFBSSxDQUFDLFNBQVMsQ0FBQyxtQkFBbUIsRUFBRSxDQUFDO0lBQ3pDLENBQUM7SUFFRCw0REFBNEQ7SUFDcEQsNkNBQWtCLEdBQTFCLFVBQTJCLFNBQWtCLEVBQUUsV0FBOEI7UUFDekUsSUFBSSxDQUFDLFNBQVMsSUFBSSxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsUUFBUTtZQUFFLE9BQU8sSUFBSSxDQUFDLFFBQVEsQ0FBQyxNQUFNLENBQUM7UUFFbEUsSUFBSSxNQUFNLEdBQVcsSUFBSSxDQUFDLGFBQWEsS0FBSyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxZQUFZLEVBQUUsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO1FBQ3BGLElBQUksUUFBUSxHQUFXLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsR0FBRyxNQUFNLENBQUM7UUFDL0Usb0ZBQW9GO1FBQ3BGLElBQUksWUFBWSxHQUFXLElBQUksQ0FBQyxTQUFTLENBQUMscUJBQXFCLEVBQUUsQ0FBQyxNQUFNLENBQUM7UUFDekUsSUFBSSxRQUFRLEdBQVcsSUFBSSxDQUFDLEtBQUssQ0FBQyxRQUFRLEdBQUcsWUFBWSxDQUFDLENBQUM7UUFFM0QsSUFBSSxXQUFXLEtBQUssUUFBUTtZQUFFLFFBQVEsSUFBSSxDQUFDLENBQUM7UUFFNUMsT0FBTyxJQUFJLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsTUFBTSxFQUFFLFFBQVEsQ0FBQyxDQUFDO0lBQ3BELENBQUM7SUFFTyx5Q0FBYyxHQUF0QixVQUF1QixVQUFlLEVBQUUsZ0JBQTZELEVBQUUsY0FBdUM7UUFBOUksaUJBeUJDO1FBeEJHLElBQUksU0FBUyxHQUFXLENBQUMsRUFBRSxnQkFBZ0IsR0FBRyxJQUFJLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUM7UUFDdkUsSUFBSSxJQUFJLENBQUMsYUFBYSxLQUFLLEtBQUs7WUFBRSxTQUFTLEdBQUcsSUFBSSxDQUFDLENBQUMsQ0FBQyxZQUFZLEVBQUUsR0FBRyxJQUFJLENBQUMsQ0FBQyxDQUFDLElBQUksRUFBRSxHQUFHLElBQUksQ0FBQyxDQUFDLENBQUMsU0FBUyxFQUFFLEdBQUcsQ0FBQyxDQUFDO1FBRTdHLElBQUksQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLFVBQUMsQ0FBQyxFQUFFLE1BQU07WUFDeEIsSUFBSSxjQUFtQixFQUFFLE9BQWUsQ0FBQztZQUN6QyxjQUFjLEdBQUcsVUFBVSxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUM7aUJBQ3BDLElBQUksQ0FBQyxPQUFPLEVBQUUsMEJBQTBCLEdBQUcsTUFBTSxDQUFDO2lCQUNsRCxJQUFJLENBQUMsS0FBSSxDQUFDLFNBQVMsQ0FBQyxxQkFBcUIsQ0FBQyxnQkFBZ0IsQ0FBQyxNQUFNLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDO1lBRXBGLElBQUksY0FBYyxDQUFDLFFBQVEsRUFBRTtnQkFDekIsY0FBYyxDQUFDLEtBQUssQ0FBQyxXQUFXLEVBQUUsZ0JBQWdCLENBQUMsV0FBVyxHQUFHLElBQUksQ0FBQyxDQUFDO2FBQzFFO2lCQUFNO2dCQUNILElBQUksQ0FBQyxLQUFJLENBQUMsR0FBRyxDQUFDLFFBQVE7b0JBQUUsY0FBYyxDQUFDLEtBQUssQ0FBQyxXQUFXLEVBQUUsZ0JBQWdCLENBQUMsVUFBVSxHQUFHLElBQUksQ0FBQyxDQUFDO2FBQ2pHO1lBRUQsSUFBSSxLQUFJLENBQUMsYUFBYSxLQUFLLEtBQUssRUFBRTtnQkFDOUIsSUFBSSxhQUFhLEdBQUcsS0FBSSxDQUFDLFNBQVMsQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDLEtBQUksQ0FBQyxJQUFJLENBQUMsTUFBTSxHQUFHLE1BQU0sR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQztnQkFDeEYsT0FBTyxHQUFHLFNBQVMsR0FBRyxLQUFJLENBQUMsQ0FBQyxDQUFDLElBQUksRUFBRSxHQUFHLGFBQWEsQ0FBQzthQUN2RDtpQkFBTTtnQkFDSCxPQUFPLEdBQUcsS0FBSSxDQUFDLFNBQVMsQ0FBQyxLQUFJLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQzthQUN2RDtZQUVELEtBQUksQ0FBQyxTQUFTLENBQUMsb0JBQW9CLENBQUMsY0FBYyxFQUFFLE9BQU8sRUFBRSxNQUFNLENBQUMsTUFBTSxDQUFDLGNBQWMsRUFBRSxFQUFFLE1BQU0sRUFBRSxNQUFNLEtBQUssS0FBSSxDQUFDLElBQUksQ0FBQyxNQUFNLEdBQUcsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDO1FBQzdJLENBQUMsQ0FBQyxDQUFDO0lBQ1AsQ0FBQztJQUVELDJGQUEyRjtJQUUzRjs7Ozs7Ozs7O09BU0c7SUFFSSwyQ0FBZ0IsR0FBdkIsVUFBd0IsS0FBVSxFQUFFLE9BQWE7UUFBakQsaUJBK0dDO1FBOUdFLElBQUksWUFBWSxHQUFZLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsS0FBSyxLQUFLLElBQUksQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxLQUFLLE1BQU0sSUFBSSxJQUFJLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxLQUFLLFFBQVEsQ0FBQyxDQUFDLENBQUM7UUFDN0gsSUFBSSxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDLE9BQU87WUFBRSxPQUFPO1FBRXpDLElBQUksT0FBWSxDQUFDO1FBQ2pCLEtBQUssQ0FBQyxFQUFFLENBQUMsV0FBVyxFQUFFLFVBQUMsQ0FBQyxFQUFFLEtBQUs7WUFDM0IsSUFBSSxHQUFHLEdBQVcsWUFBWSxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsT0FBTyxDQUFDLFNBQVMsQ0FBQyxJQUFJLEVBQUUsQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLEdBQUcsRUFBRSxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDO1lBQ2xILElBQUksSUFBSSxHQUFXLFlBQVksQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLE9BQU8sQ0FBQyxTQUFTLENBQUMsSUFBSSxFQUFFLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxHQUFHLEVBQUUsQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQztZQUNwSCxJQUFJLFlBQVksR0FBUSxDQUFDLFlBQVksSUFBSSxPQUFPLENBQUMsWUFBWSxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxZQUFZLENBQUMsQ0FBQyxDQUFDLEtBQUksQ0FBQyxTQUFTLENBQUM7WUFDdkcsT0FBTyxHQUFHLFlBQVksQ0FBQyxNQUFNLENBQUMscUJBQXFCLENBQUMsQ0FBQztZQUVyRCxvRkFBb0Y7WUFDcEYsSUFBSSxPQUFPLENBQUMsS0FBSyxFQUFFLEVBQUU7Z0JBQ2pCLE9BQU8sR0FBRyxZQUFZLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxDQUFDLElBQUksQ0FBQyxPQUFPLEVBQUUsb0JBQW9CLENBQUMsQ0FBQztnQkFDekUsT0FBTyxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsQ0FBQyxJQUFJLENBQUMsT0FBTyxFQUFFLDBCQUEwQixDQUFDLENBQUM7Z0JBQ2hFLE9BQU8sQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLENBQUMsSUFBSSxDQUFDLE9BQU8sRUFBRSwwQkFBMEIsQ0FBQyxDQUFDO2FBQ25FO1lBRUQsSUFBSSxLQUFhLENBQUM7WUFDbEIsSUFBSSxLQUFzQixDQUFDO1lBQzNCLG9EQUFvRDtZQUNwRCxJQUFJLEtBQWEsQ0FBQztZQUVsQixJQUFJLEtBQUksQ0FBQyxTQUFTLElBQUksQ0FBQyxLQUFJLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxLQUFLLEtBQUssSUFBSSxLQUFJLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxLQUFLLE9BQU8sQ0FBQyxFQUFFO2dCQUNsRixLQUFLLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLElBQUksRUFBRSxHQUFHLENBQUMsQ0FBQztnQkFDcEMsS0FBSyxHQUFHLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDO2dCQUNqQixPQUFPLENBQUMsUUFBUSxDQUFDLEVBQUUsQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxFQUFFLElBQUksRUFBRSxPQUFPLENBQUMsV0FBVyxFQUFFLE9BQU8sQ0FBQyxXQUFXLENBQUMsQ0FBQztnQkFDckcsRUFBRSxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLFNBQVMsRUFBRSxLQUFLLENBQUMsQ0FBQzthQUM5RDtpQkFBTSxJQUFJLEtBQUksQ0FBQyxTQUFTLElBQUksS0FBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsS0FBSyxRQUFRLEVBQUU7Z0JBQ3pELEtBQUssR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxJQUFJLEVBQUUsR0FBRyxDQUFDLENBQUM7Z0JBQy9CLEtBQUssR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDO2dCQUNaLEVBQUUsQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxTQUFTLEVBQUUsS0FBSyxDQUFDLENBQUM7YUFDOUQ7aUJBQU0sSUFBSSxLQUFJLENBQUMsYUFBYSxLQUFLLEtBQUssRUFBRTtnQkFDckMsS0FBSyxHQUFHLE9BQU8sQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQztnQkFDN0IsS0FBSyxHQUFHLEtBQUksQ0FBQyxTQUFTLENBQUMsNEJBQTRCLENBQUMsQ0FBQyxDQUFDLEtBQUssSUFBSSxDQUFDLENBQUMsQ0FBQztnQkFDbEUsS0FBSyxHQUFHLEtBQUssQ0FBQyxRQUFRLEVBQUUsR0FBRyxHQUFHLEdBQUcsS0FBSSxDQUFDLFVBQVUsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDO2dCQUM1RCxFQUFFLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsU0FBUyxFQUFFLEtBQUssQ0FBQyxDQUFDO2FBQzlEO2lCQUFNLElBQUksS0FBSSxDQUFDLGFBQWEsS0FBSyxNQUFNLEVBQUU7Z0JBQ3RDLEtBQUssR0FBRyxPQUFPLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUM7Z0JBQzdCLEtBQUssR0FBRyxPQUFPLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxLQUFLLENBQUM7Z0JBQ3BDLEtBQUssR0FBRyxLQUFLLENBQUMsUUFBUSxFQUFFLEdBQUcsR0FBRyxHQUFHLEtBQUksQ0FBQyxVQUFVLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDO2FBQzVEO2lCQUFNLElBQUksS0FBSSxDQUFDLGFBQWEsS0FBSyxLQUFLLEVBQUU7Z0JBQ3JDLEtBQUssSUFBSSxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsR0FBRyxPQUFPLENBQUMsVUFBVSxDQUFDLE1BQU0sRUFBRSxDQUFDLEVBQUUsRUFBRTtvQkFDaEQsSUFBSSxDQUFDLENBQUMsVUFBVSxDQUFDLEdBQUcsSUFBSSxPQUFPLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsRUFBRTt3QkFDOUMsS0FBSyxHQUFHLE9BQU8sQ0FBQyxVQUFVLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDO3dCQUNuQyxLQUFLLEdBQUcsT0FBTyxDQUFDLFVBQVUsR0FBRyxJQUFJLEdBQUcsT0FBTyxDQUFDLFVBQVUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUM7d0JBQ2hFLEtBQUssR0FBRyxPQUFPLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQzt3QkFDcEMsTUFBTTtxQkFDVDtpQkFDSjthQUNKO1lBRUQsS0FBSyxHQUFHLEtBQUksQ0FBQyxTQUFTLENBQUMsWUFBWSxDQUFDLEtBQUksQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDLE1BQU0sRUFBRSxLQUFLLENBQUMsQ0FBQztZQUN2RSxPQUFPLENBQUMsTUFBTSxDQUFDLDJCQUEyQixDQUFDLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxXQUFXLEVBQUUsQ0FBQyxDQUFDO1lBQ3RFLElBQUksS0FBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsS0FBSyxRQUFRO2dCQUFFLE9BQU8sQ0FBQyxNQUFNLENBQUMsMkJBQTJCLENBQUMsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLENBQUMsS0FBSyxDQUFDLGFBQWEsRUFBRSxNQUFNLENBQUMsQ0FBQztZQUV6SCxPQUFPLENBQUMsSUFBSSxDQUFDLE9BQU8sRUFBRSxLQUFJLENBQUMsU0FBUyxDQUFDLFFBQVEsQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLEVBQUUsRUFBRSxxQkFBcUIsQ0FBQyxFQUFFLElBQUksQ0FBQyxDQUFDLENBQUM7WUFDL0YsT0FBTyxDQUFDLEtBQUssQ0FBQyxTQUFTLEVBQUUsT0FBTyxDQUFDLENBQUM7WUFDbEMsT0FBTyxDQUFDLEtBQUssQ0FBQyxTQUFTLEVBQUUsQ0FBQyxDQUFDLENBQUM7WUFDNUIsT0FBTyxDQUFDLEtBQUssQ0FBQyxTQUFTLEVBQUUsR0FBRyxDQUFDLENBQUM7WUFFOUIsSUFBSSxLQUFJLENBQUMsYUFBYSxLQUFLLE1BQU0sRUFBRTtnQkFDL0IsT0FBTyxDQUFDLFFBQVEsQ0FBQyxLQUFJLENBQUMsUUFBUSxDQUFDLE9BQU8sQ0FBQyxNQUFNLEVBQUUsQ0FBQyxDQUFDLEVBQUUsSUFBSSxDQUFDLENBQUM7YUFDNUQ7WUFFRCxJQUFJLE9BQU8sSUFBSSxPQUFPLENBQUMsU0FBUyxJQUFJLE9BQU8sQ0FBQyxTQUFTLENBQUMsU0FBUztnQkFBRSxPQUFPLENBQUMsU0FBUyxDQUFDLFNBQVMsQ0FBQyxLQUFLLENBQUMsQ0FBQztZQUVwRyw4RUFBOEU7WUFDOUUsSUFBSSxLQUFJLENBQUMsYUFBYSxLQUFLLEtBQUssRUFBRTtnQkFDOUIsS0FBSSxDQUFDLFNBQVMsQ0FBQyxVQUFVLENBQUMsZUFBZSxDQUFDLE9BQU8sRUFBRSxFQUFFLEdBQUcsRUFBRSxFQUFFLENBQUMsS0FBSyxDQUFDLE1BQU0sRUFBRSxJQUFJLEVBQUUsRUFBRSxDQUFDLEtBQUssQ0FBQyxNQUFNLEVBQUUsQ0FBQyxDQUFDO2FBQ3ZHO2lCQUFNO2dCQUNILElBQUksS0FBSyxJQUFJLEtBQUssS0FBSyxDQUFDO29CQUFFLEtBQUksQ0FBQyxTQUFTLENBQUMsVUFBVSxDQUFDLGVBQWUsQ0FBQyxPQUFPLEVBQUUsRUFBRSxHQUFHLEVBQUUsR0FBRyxFQUFFLElBQUksRUFBRSxJQUFJLEVBQUUsQ0FBQyxDQUFDOztvQkFDbEcsT0FBTyxDQUFDLE1BQU0sRUFBRSxDQUFDO2FBQ3pCO1FBQ0wsQ0FBQyxDQUFDLENBQUM7UUFFSCxLQUFLLENBQUMsRUFBRSxDQUFDLFdBQVcsRUFBRSxVQUFDLENBQUM7WUFDcEIsSUFBSSxHQUFHLEdBQVcsWUFBWSxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsT0FBTyxDQUFDLFNBQVMsQ0FBQyxJQUFJLEVBQUUsQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLEdBQUcsRUFBRSxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDO1lBQ2xILElBQUksSUFBSSxHQUFXLFlBQVksQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLE9BQU8sQ0FBQyxTQUFTLENBQUMsSUFBSSxFQUFFLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxHQUFHLEVBQUUsQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQztZQUNwSCxxQ0FBcUM7WUFDckMsS0FBSSxDQUFDLFNBQVMsQ0FBQyxVQUFVLENBQUMsZUFBZSxDQUFDLE9BQU8sRUFBRSxFQUFFLEdBQUcsRUFBRSxHQUFHLEVBQUUsSUFBSSxFQUFFLElBQUksRUFBRSxDQUFDLENBQUM7UUFDakYsQ0FBQyxDQUFDLENBQUM7UUFFSCxLQUFLLENBQUMsRUFBRSxDQUFDLFVBQVUsRUFBRSxVQUFDLENBQUMsRUFBRSxLQUFLO1lBQzFCLElBQUksS0FBSSxDQUFDLFNBQVMsSUFBSSxDQUFDLEtBQUksQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLEtBQUssS0FBSyxJQUFJLEtBQUksQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLEtBQUssT0FBTyxJQUFJLEtBQUksQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLEtBQUssUUFBUSxJQUFJLEtBQUksQ0FBQyxhQUFhLEtBQUssS0FBSyxDQUFDLEVBQUU7Z0JBQ3BKLElBQUksS0FBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsS0FBSyxLQUFLLElBQUksS0FBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsS0FBSyxPQUFPLEVBQUU7b0JBQzlELElBQUksUUFBUSxHQUFRLEVBQUUsQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDO29CQUN2RCxJQUFJLENBQUMsUUFBUSxDQUFDLE9BQU8sQ0FBQyxTQUFTLENBQUMsRUFBRTt3QkFDOUIsT0FBTyxDQUFDLFFBQVEsQ0FBQyxRQUFRLEVBQUUsS0FBSyxFQUFFLE9BQU8sQ0FBQyxXQUFXLEVBQUUsT0FBTyxDQUFDLFdBQVcsQ0FBQyxDQUFDO3FCQUMvRTtpQkFDSjtnQkFDRCxFQUFFLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsU0FBUyxFQUFFLEdBQUcsQ0FBQyxDQUFDO2FBQzVEO1lBQ0Qsb0NBQW9DO1lBQ3BDLCtCQUErQjtZQUMvQixPQUFPLENBQUMsTUFBTSxFQUFFLENBQUM7WUFFakIsSUFBSSxLQUFJLENBQUMsYUFBYSxLQUFLLE1BQU0sRUFBRTtnQkFDL0IsT0FBTyxDQUFDLFFBQVEsQ0FBQyxLQUFJLENBQUMsUUFBUSxDQUFDLE9BQU8sQ0FBQyxNQUFNLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQzthQUN0RDtZQUNELElBQUksT0FBTyxJQUFJLE9BQU8sQ0FBQyxTQUFTLElBQUksT0FBTyxDQUFDLFNBQVMsQ0FBQyxRQUFRO2dCQUFFLE9BQU8sQ0FBQyxTQUFTLENBQUMsUUFBUSxFQUFFLENBQUM7UUFDakcsQ0FBQyxDQUFDLENBQUM7UUFFSCxLQUFLLENBQUMsRUFBRSxDQUFDLE9BQU8sRUFBRSxVQUFDLENBQUMsRUFBRSxLQUFLO1lBQ3ZCLElBQUksS0FBSSxDQUFDLFNBQVMsSUFBSSxDQUFDLEtBQUksQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLEtBQUssS0FBSyxJQUFJLEtBQUksQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLEtBQUssT0FBTyxDQUFDLEVBQUU7Z0JBQ2xGLElBQUksUUFBUSxHQUFRLEVBQUUsQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDO2dCQUN2RCxJQUFJLE9BQU8sR0FBWSxRQUFRLENBQUMsT0FBTyxDQUFDLFNBQVMsQ0FBQyxDQUFDO2dCQUNuRCxPQUFPLENBQUMsUUFBUSxDQUFDLFFBQVEsRUFBRSxDQUFDLE9BQU8sRUFBRSxPQUFPLENBQUMsV0FBVyxFQUFFLE9BQU8sQ0FBQyxXQUFXLENBQUMsQ0FBQztnQkFDL0UsUUFBUSxDQUFDLE9BQU8sQ0FBQyxTQUFTLEVBQUUsQ0FBQyxPQUFPLENBQUMsQ0FBQzthQUN6QztRQUNMLENBQUMsQ0FBQyxDQUFDO0lBQ1AsQ0FBQztJQUVELDZFQUE2RTtJQUV0RSxtQ0FBUSxHQUFmLFVBQWdCLE1BQWdCLEVBQUUsTUFBdUIsRUFBRSxVQUFrQixFQUFFLFVBQWtCO1FBQzdGLElBQUksQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsT0FBTztZQUFFLE9BQU87UUFFOUMsSUFBSSxXQUFXLEdBQWUsSUFBSSxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDO1FBRXZELElBQUksY0FBYyxHQUFRLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDO2FBQzFELElBQUksQ0FBQyxPQUFPLEVBQUUsMEJBQTBCLEdBQUcsTUFBTSxHQUFHLEtBQUssR0FBRyxNQUFNLENBQUMsRUFBRSxDQUFDLENBQUM7UUFFNUUsSUFBSSxTQUFTLEdBQVcsSUFBSSxDQUFDLFNBQVMsQ0FBQyxZQUFZLENBQUMsV0FBVyxDQUFDLE1BQU0sRUFBRSxNQUFNLENBQUMsS0FBSyxDQUFDLENBQUM7UUFFdEYsY0FBYzthQUNULE1BQU0sQ0FBQyxLQUFLLENBQUM7YUFDYixJQUFJLENBQUMsT0FBTyxFQUFFLDRCQUE0QixDQUFDO2FBQzNDLElBQUksQ0FBQyxTQUFTLENBQUM7YUFDZixJQUFJLENBQUMsT0FBTyxFQUFFLElBQUksQ0FBQyxTQUFTLENBQUMsUUFBUSxDQUFDLFdBQVcsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDO1FBRS9ELElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxjQUFjLEVBQUUsTUFBTSxDQUFDLEdBQUcsSUFBSSxNQUFNLENBQUMsS0FBSyxFQUFFLFVBQVUsRUFBRSxVQUFVLENBQUMsQ0FBQztRQUUzRixPQUFPLGNBQWMsQ0FBQztJQUMxQixDQUFDO0lBRU0sNENBQWlCLEdBQXhCLFVBQXlCLENBQWtCLEVBQUUsQ0FBa0IsRUFBRSxXQUFxQjtRQUNsRixPQUFPLFlBQVksR0FBRyxDQUFDLEdBQUcsQ0FBQyxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUM7SUFDaEcsQ0FBQztJQUVNLG1DQUFRLEdBQWYsVUFBZ0IsS0FBc0IsRUFBRSxHQUFXO1FBQy9DLE9BQU8seUJBQXlCLEdBQUcsS0FBSyxHQUFHLEtBQUssR0FBRyxHQUFHLENBQUM7SUFDM0QsQ0FBQztJQUVNLHNDQUFXLEdBQWxCLFVBQW1CLEtBQVUsRUFBRSxPQUFlO1FBQzFDLE9BQU8sSUFBSSxDQUFDLFNBQVMsQ0FBQyxPQUFPLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDO0lBQ3BELENBQUM7SUFFTyw2Q0FBa0IsR0FBMUI7UUFDSSxJQUFJLENBQUMsa0JBQWtCLEdBQUcsRUFBRSxDQUFDLE1BQU0sQ0FBQyxHQUFHLEdBQUcsSUFBSSxDQUFDLE1BQU0sQ0FBQyxFQUFFLEdBQUcsY0FBYyxHQUFHLGtDQUFrQyxDQUFDLENBQUM7SUFDcEgsQ0FBQztJQUVEOzs7T0FHRztJQUNILGlIQUFpSDtJQUMxRywrQ0FBb0IsR0FBM0IsVUFBNEIsU0FBUyxFQUFFLFVBQWtCLEVBQUUsT0FBb0M7UUFBL0YsaUJBOEJDO1FBOUIwRCx3QkFBQSxFQUFBLFlBQW9DO1FBQzNGLElBQUksS0FBSyxHQUFpQywrQkFBK0IsQ0FBQztRQUMxRSxJQUFJLGFBQWEsR0FBZ0MsSUFBSSxDQUFDLFNBQVMsQ0FBQyx1QkFBdUIsQ0FBQyxJQUFJLENBQUMsTUFBTSxFQUFFLE9BQU8sQ0FBQyxDQUFDO1FBQzlHLElBQUksT0FBTyxHQUFXLE9BQU8sQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztRQUM1RCxJQUFJLE1BQU0sR0FBVyxPQUFPLEdBQUcsQ0FBQyxDQUFDO1FBRWpDLElBQUksYUFBYSxLQUFLLFFBQVEsRUFBRTtZQUM1QixJQUFJLE1BQU0sR0FBRyxDQUFDLEtBQUssRUFBRSxRQUFRLENBQUMsQ0FBQztZQUMvQixNQUFNLENBQUMsT0FBTyxDQUFDLFVBQUEsR0FBRztnQkFDZCxJQUFJLEtBQUksQ0FBQyxTQUFTLENBQUMsY0FBYyxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FBQyxLQUFLLEVBQUUsVUFBVSxFQUFFLEtBQUksQ0FBQyxNQUFNLEVBQUUsT0FBTyxDQUFDLEVBQUU7b0JBQ25GLGFBQWEsR0FBRyxLQUFLLENBQUMsR0FBRyxDQUFDLENBQUMsUUFBUSxDQUFDO2lCQUN2QztZQUNMLENBQUMsQ0FBQyxDQUFDO1NBQ047YUFBTSxJQUFJLElBQUksQ0FBQyxTQUFTLENBQUMsY0FBYyxDQUFDLEtBQUssQ0FBQyxhQUFhLENBQUMsQ0FBQyxLQUFLLEVBQUUsVUFBVSxFQUFFLElBQUksQ0FBQyxNQUFNLEVBQUUsT0FBTyxDQUFDLEVBQUU7WUFDcEcsYUFBYSxHQUFHLEtBQUssQ0FBQyxhQUFhLENBQUMsQ0FBQyxRQUFRLENBQUM7U0FDakQ7UUFFRCxJQUFJLElBQUksR0FBVyxFQUFFLENBQUM7UUFDdEIsSUFBSSxhQUFhLEtBQUssUUFBUSxFQUFFO1lBQzVCLElBQUksR0FBRyxLQUFLLENBQUMsYUFBYSxDQUFDLENBQUMsT0FBTyxDQUFDO1NBQ3ZDO2FBQU07WUFDSCxJQUFJLElBQUksR0FBVyxhQUFhLEtBQUssS0FBSyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQztZQUMzRCxJQUFJLElBQUksQ0FBQyxhQUFhLEtBQUssS0FBSyxJQUFJLElBQUksQ0FBQyxTQUFTLENBQUMsbUJBQW1CLENBQUMsYUFBYSxFQUFFLE9BQU8sQ0FBQztnQkFBRSxNQUFNLElBQUksT0FBTyxDQUFDLFVBQVUsQ0FBQyxNQUFNLENBQUM7WUFDcEksSUFBSSxHQUFHLE9BQU8sR0FBRyxLQUFLLENBQUMsYUFBYSxDQUFDLENBQUMsT0FBTyxHQUFHLElBQUksR0FBRyxNQUFNLENBQUMsUUFBUSxFQUFFLEdBQUcsS0FBSyxDQUFDO1NBQ3BGO1FBRUQsSUFBSSxJQUFJLEdBQVcsQ0FBQyxPQUFPLENBQUMsV0FBVyxJQUFJLE9BQU8sQ0FBQyxXQUFXLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLGNBQWMsR0FBRyxPQUFPLEdBQUcsQ0FBQyxHQUFHLEtBQUssQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDO1FBRWxILElBQUksU0FBUyxHQUFXLElBQUksQ0FBQyxhQUFhLEtBQUssTUFBTSxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsaUJBQWlCLENBQUMsSUFBSSxFQUFFLElBQUksRUFBRSxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsYUFBYSxHQUFHLElBQUksR0FBRyxHQUFHLENBQUM7UUFDOUgsU0FBUyxDQUFDLEtBQUssQ0FBQyxXQUFXLEVBQUUsU0FBUyxDQUFDLENBQUM7SUFDNUMsQ0FBQztJQUVPLDRDQUFpQixHQUF6QixVQUEwQixjQUFtQixFQUFFLE9BQWUsRUFBRSxVQUFrQixFQUFFLFVBQWtCO1FBQ2xHLElBQUksZUFBZSxHQUE2QjtZQUM1QyxDQUFDLEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztZQUMxQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztTQUM1QyxDQUFDO1FBQ0YsSUFBSSxDQUFDLEdBQVcsQ0FBQyxPQUFPLFVBQVUsS0FBSyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQyxlQUFlLENBQUMsQ0FBQyxDQUFDO1FBQ2xGLElBQUksQ0FBQyxHQUFXLENBQUMsT0FBTyxVQUFVLEtBQUssUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLFVBQVUsQ0FBQyxDQUFDLENBQUMsZUFBZSxDQUFDLENBQUMsQ0FBQztRQUVsRixrREFBa0Q7UUFDbEQsYUFBYTtRQUNiLElBQUk7UUFFSixJQUFJLElBQUksQ0FBQyxLQUFLO1lBQUUsQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLEtBQUssR0FBRyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQztRQUUxQyxJQUFJLE9BQU8sSUFBSSxDQUFDLE9BQU8sR0FBRyxJQUFJLENBQUMsU0FBUyxJQUFJLE9BQU8sR0FBRyxJQUFJLENBQUMsU0FBUyxDQUFDLEVBQUU7WUFDbkUsY0FBYyxDQUFDLEtBQUssQ0FBQyxTQUFTLEVBQUUsTUFBTSxDQUFDLENBQUM7U0FDM0M7UUFFRCxJQUFJLENBQUMsbUJBQW1CLENBQUMsY0FBYyxFQUFFLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQztJQUNuRCxDQUFDO0lBRU8sOENBQW1CLEdBQTNCLFVBQTRCLGNBQW1CLEVBQUUsVUFBa0IsRUFBRSxVQUFrQjtRQUNuRixJQUFJLE1BQU0sR0FBVyxFQUFFLENBQUM7UUFDeEIsSUFBSSxVQUFVLEdBQThCLElBQUksQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUM7UUFFM0UsNEVBQTRFO1FBQzVFLElBQUksVUFBVSxDQUFDLGNBQWMsQ0FBQyxVQUFVLENBQUMsSUFBSSxVQUFVLENBQUMsUUFBUSxFQUFFO1lBQzlELE1BQU0sR0FBRyxVQUFVLEdBQUcsVUFBVSxDQUFDLFFBQVEsR0FBRyxNQUFNLENBQUM7U0FDdEQ7UUFFRCxjQUFjO2FBQ1QsS0FBSyxDQUFDLFdBQVcsRUFBRSxJQUFJLENBQUMsaUJBQWlCLENBQUMsVUFBVSxFQUFFLFVBQVUsQ0FBQyxHQUFHLE1BQU0sQ0FBQyxDQUFDO1FBRWpGLElBQUksSUFBSSxDQUFDLEtBQUs7WUFBRSxjQUFjLENBQUMsS0FBSyxDQUFDLFlBQVksRUFBRSxPQUFPLENBQUMsQ0FBQztJQUNoRSxDQUFDO0lBQ0wsdUJBQUM7QUFBRCxDQUFDLEFBaDJCRCxJQWcyQkMiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgKiBhcyBkMyBmcm9tICdkMyc7XHJcbmltcG9ydCB7IEtkQ2hhcnRzU3ZjIH0gZnJvbSAnLi9rZC1hbmd1bGFyLWNoYXJ0cy1zdmMnO1xyXG5pbXBvcnQge1xyXG4gICAgSUNoYXJ0Q29uZmlnLFxyXG4gICAgSUQzRGF0YURhdGEsXHJcbiAgICBJRDNEYXRhUmFuZ2UsXHJcbiAgICBJRDNZRGF0YSxcclxuICAgIElZQXhpc0NvbmZpZyxcclxuICAgIElYQXhpc0NvbmZpZyxcclxuICAgIElNYXhNaW5JbnRlcnZhbCxcclxuICAgIElMZWdlbmREYXRhLFxyXG4gICAgSURhdGFMYWJlbCxcclxuICAgIElBeGlzTGFiZWxCb29sZWFuQ2hlY2tzLFxyXG4gICAgSUxhYmVsVGV4dFZlcnRpY2FsQWxpZ25TdG9yZSxcclxuICAgIElTZXRUaWNrVmFsdWVSZXR1cm4sXHJcbiAgICBJQXhpc1RyYW5zZm9ybVBvcyxcclxuICAgIElYSW5mbyxcclxuICAgIElZQXhpc0xhYmVsUmFuZ2VcclxufSBmcm9tICcuL2tkLWFuZ3VsYXItY2hhcnRzLWludGVyZmFjZSc7XHJcbmltcG9ydCB7IExBQkVMX1RFWFRfVkVSVElDQUxfQUxJR05fU1RPUkUsIFRPT0xUSVBfREVGQVVMVF9TVFlMRSB9IGZyb20gJy4va2QtYW5ndWxhci1jaGFydHMtY29uZmlnJztcclxuaW1wb3J0IHsgS2REb21FbGVtU3ZjIH0gZnJvbSAnLi4va2QtY29tbW9uL2luZGV4JztcclxuXHJcbmV4cG9ydCBjbGFzcyBLZENoYXJ0QmFzZUNsYXNzIHtcclxuXHJcbiAgICAvLyBDaGFydCBTZXR0aW5nXHJcbiAgICBwdWJsaWMgaXNSdGw6IGJvb2xlYW4gPSBmYWxzZTtcclxuICAgIHB1YmxpYyBjb25maWc6IElDaGFydENvbmZpZyA9IHt9O1xyXG4gICAgcHVibGljIGRhdGE6IEFycmF5PElEM0RhdGFEYXRhPiA9IFtdO1xyXG4gICAgcHVibGljIGluaXREYXRhOiBBcnJheTxJRDNEYXRhRGF0YT4gPSBbXTtcclxuICAgIHB1YmxpYyBjaGFydFR5cGU6IEFycmF5PHN0cmluZz47XHJcbiAgICBwdWJsaWMgY2hhcnRDYXRlZ29yeTogJ3BpZScgfCAnYmFyJyB8ICdjb2x1bW4nIHwgJ2xpbmUnIHwgJ2FyZWEnIHwgJ2RvdCcgfCAnc3BsaW5lJyB8ICdtYXAnO1xyXG4gICAgLyoqXHJcbiAgICAgKiBtYXggYW5kIG1pbiB2YWx1ZSBvZiBhY3Jvc3MgYWxsIHNlcmllc1xyXG4gICAgICogdHlwZSB7SUQzRGF0YVJhbmdlfVxyXG4gICAgICovXHJcbiAgICBwdWJsaWMgZGF0YVJhbmdlOiBJRDNEYXRhUmFuZ2U7XHJcbiAgICBwdWJsaWMgc3ZnOiBhbnk7XHJcbiAgICAvLyB0aGlzIGlzIGNoYXJ0LWNvbnRhaW5lciAoY2xhc3NOYW1lKVxyXG4gICAgcHVibGljIHN2Z1BhcmVudDogYW55O1xyXG4gICAgLy8gdGhpcyBpcyB0aGUgaW1tZWRpYXRlIGRpdiBwYXJlbnQgb2Ygc3ZnXHJcbiAgICBwdWJsaWMgc3ZnQ29udGFpbmVyOiBhbnk7XHJcbiAgICBwdWJsaWMgc3ZnUmVjdDogYW55O1xyXG4gICAgcHVibGljIGdyYXBoOiBhbnk7XHJcbiAgICBwdWJsaWMgd2lkdGg6IG51bWJlcjtcclxuICAgIHB1YmxpYyBoZWlnaHQ6IG51bWJlcjtcclxuICAgIC8vIGQzIHNjYWxlcy4gRGVmaW5pdGlvbjogZ2l2ZSBkb21haW4gYW5kIHJhbmdlLiBVc2FnZTogdGhpcy54KHZhbHVlKSB3aWxsIG91dHB1dCBhIHZhbHVlIGluIHRoZSByYW5nZVxyXG4gICAgcHVibGljIHg6IGFueTtcclxuICAgIHB1YmxpYyB5OiBhbnk7XHJcbiAgICBwdWJsaWMgeEF4aXNBcnI6IEFycmF5PGFueT4gPSBbXTtcclxuICAgIHB1YmxpYyB5QXhpczogYW55O1xyXG4gICAgcHVibGljIHhBeGlzRnVuYzogYW55O1xyXG4gICAgcHVibGljIHlBeGlzRnVuYzogYW55O1xyXG4gICAgLy8gYXhpc01heC9NaW4gaXMgdXNlZCBvbmx5IHdoZW4gYXV0b1JvdW5kVG9NYXgsIGV2ZW50dWFsbHkgc3RvcmVkIGludG8gZG9tYWluTWF4L01pblxyXG4gICAgcHVibGljIGF4aXNNYXg6IG51bWJlcjtcclxuICAgIHB1YmxpYyBheGlzTWluOiBudW1iZXIgPSAwO1xyXG4gICAgLy8gZmluYWwgYXhpcyB2YWx1ZXMgcGFzc2VkIHRvIGQzLnNjYWxlXHJcbiAgICBwdWJsaWMgZG9tYWluTWF4OiBudW1iZXI7XHJcbiAgICBwdWJsaWMgZG9tYWluTWluOiBudW1iZXI7XHJcbiAgICBwdWJsaWMgZ3JpZExpbmVzQ29udGFpbmVyOiBhbnk7XHJcbiAgICBwdWJsaWMgYXhpc0xhYmVsQ29udGFpbmVyQXJyOiBBcnJheTxhbnk+ID0gW107XHJcbiAgICBwdWJsaWMgdGlja1ZhbHVlczogQXJyYXk8bnVtYmVyPjtcclxuICAgIHB1YmxpYyBoYXZlTmVnYXRpdmU6IGJvb2xlYW4gPSBmYWxzZTtcclxuICAgIC8qKlxyXG4gICAgICogdXNlZCBvbmx5IGJ5IGJhci5cclxuICAgICAqIGJhckdyb3VwUGFkZGluZyBpcyB1c2VkIG9ubHkgZm9yIGNsdXN0ZXIgLS0+IHRoZSBwYWRkaW5nIGJldHdlZW4gZWFjaCByZWN0IGluIGEgY2F0ZWdvcnlcclxuICAgICAqIGJhbmRQYWRkaW5nIGlzIGdpdmVuIHRvIGQzIC0tPiB0aGUgcGFkZGluZyBiZXR3ZWVuIGVhY2ggY2F0ZWdvcnlcclxuICAgICAqIHR5cGUge0lCYXNlQ2xhc3NCYXJPYmp9XHJcbiAgICAgKi9cclxuICAgIHB1YmxpYyBiYXI6IHsgaXNJbnZlcnQ6IGJvb2xlYW47IGNsdXN0ZXJQYWRkaW5nUGVyY2VudDogbnVtYmVyOyBiYW5kUGFkZGluZzogbnVtYmVyIH0gPSB7XHJcbiAgICAgICAgaXNJbnZlcnQ6IGZhbHNlLFxyXG4gICAgICAgIGNsdXN0ZXJQYWRkaW5nUGVyY2VudDogMC4xLFxyXG4gICAgICAgIGJhbmRQYWRkaW5nOiAwLjIsXHJcbiAgICB9O1xyXG5cclxuICAgIHB1YmxpYyByYW5nZUxpc3Q6IG9iamVjdDtcclxuICAgIHB1YmxpYyBsZW5ndGhPZlRyYW5zaXRpb246IG51bWJlciA9IDEwMDA7XHJcblxyXG4gICAgLy8gRGF0YSBsYWJlbCBTZXR0aW5nXHJcbiAgICBwdWJsaWMgZGF0YUxhYmVsQ29udGFpbmVyO1xyXG5cclxuICAgIHB1YmxpYyBsZWdlbmREYXRhOiB7IFtrZXk6IHN0cmluZ106IElMZWdlbmREYXRhIH07XHJcblxyXG4gICAgcHVibGljIGVycm9yTXNnOiBzdHJpbmcgPSAnMTAwJSBzdGFjayBkb2VzIG5vdCBzdXBwb3J0IG5lZ2F0aXZlIHZhbHVlcy4nO1xyXG5cclxuICAgIHByaXZhdGUgX3NldENoYXJ0VGltZW91dDogYW55O1xyXG5cclxuICAgIGNvbnN0cnVjdG9yKHB1YmxpYyBfY2hhcnRTdmM6IEtkQ2hhcnRzU3ZjLCBwdWJsaWMgX2RvbVN2YzogS2REb21FbGVtU3ZjKSB7XHJcbiAgICAgICAgdGhpcy5pc1J0bCA9IF9kb21TdmMuZ2V0RG9jdW1lbnREaXJlY3Rpb24odHJ1ZSkgPT09ICdyaWdodCc7XHJcbiAgICB9XHJcblxyXG4gICAgLy8gPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09IENoYXJ0ID09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT1cclxuXHJcbiAgICBwdWJsaWMgc2V0U3ZnKCk6IHZvaWQge1xyXG4gICAgICAgIHRoaXMuc3ZnID0gZDMuc2VsZWN0KCcjJyArIHRoaXMuY29uZmlnLmlkICsgJy5rZHgtY2hhcnRzIHN2ZycpO1xyXG4gICAgICAgIGlmICghdGhpcy5ncmFwaCkgdGhpcy5ncmFwaCA9IHRoaXMuc3ZnLmFwcGVuZCgnZycpLmF0dHIoJ2NsYXNzJywgJ2dyYXBoJyk7XHJcbiAgICAgICAgLy8gaWYgKHRoaXMuc3ZnLnNlbGVjdCgnLmdyYXBoJykuZW1wdHkoKSkgdGhpcy5ncmFwaCA9IHRoaXMuc3ZnLmFwcGVuZCgnZycpLmF0dHIoJ2NsYXNzJywgJ2dyYXBoJyk7XHJcbiAgICAgICAgdGhpcy5zdmdQYXJlbnQgPSBkMy5zZWxlY3QoJyMnICsgdGhpcy5jb25maWcuaWQgKyAnLmtkeC1jaGFydHMgLmtkeC1jaGFydC1jb250YWluZXInKTtcclxuICAgICAgICB0aGlzLnN2Z0NvbnRhaW5lciA9IGQzLnNlbGVjdCgnIycgKyB0aGlzLmNvbmZpZy5pZCArICcua2R4LWNoYXJ0cyAua2R4LWNoYXJ0cy1zdmctY29udGFpbmVyJyk7XHJcblxyXG4gICAgICAgIHRoaXMuX3NldExhYmVsQ29udGFpbmVyKCk7XHJcbiAgICAgICAgdGhpcy5fc2V0Q2hhcnRTdmMoKTtcclxuICAgICAgICB0aGlzLnJhbmdlTGlzdCA9IHt9O1xyXG4gICAgfVxyXG5cclxuICAgIC8qKlxyXG4gICAgICogc2V0IHN2ZyB3aWR0aCBhbmQgaGVpZ2h0LiB0aGlzIGZ1bmN0aW9uIGlzIGJlY29zIG9mIGV4cG9ydCBmZWF0dXJlLCB0aGUgZXhwb3J0IHBsdWdpbnMgcmVxdWlyZXMgc3ZnIHdpZHRoIGFuZCBoZWlnaHQgdG8gYmUgaW5saW5lIGF0dHJpYnV0ZXMgd2l0aCBkZWZpbml0ZSBudW1iZXJcclxuICAgICAqIGhhdmUgdG8gYmUgY2FsbGVkIGJ5IGFsbCBjaGFydHNcclxuICAgICAqIHBhcmFtIHsneCcgfCAneSd9IF9heGlzXHJcbiAgICAgKi9cclxuICAgIHB1YmxpYyBzZXRTdmdEaW1lbnNpb24oX2F4aXM6ICd4JyB8ICd5Jyk6IHZvaWQge1xyXG4gICAgICAgIGxldCBzdmdDb250YWluZXJSZWN0OiBhbnkgPSB0aGlzLnN2Z0NvbnRhaW5lci5ub2RlKCkuZ2V0Qm91bmRpbmdDbGllbnRSZWN0KCk7XHJcbiAgICAgICAgbGV0IHR5cGU6ICd3aWR0aCcgfCAnaGVpZ2h0JyA9IF9heGlzID09PSAneCcgPyAodGhpcy5iYXIuaXNJbnZlcnQgPyAnaGVpZ2h0JyA6ICd3aWR0aCcpIDogKHRoaXMuYmFyLmlzSW52ZXJ0ID8gJ3dpZHRoJyA6ICdoZWlnaHQnKTtcclxuXHJcbiAgICAgICAgdGhpcy5zdmcuYXR0cih0eXBlLCBzdmdDb250YWluZXJSZWN0W3R5cGVdKTtcclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF9jbGVhclN2Z0RpbWVuc2lvbigpOiB2b2lkIHtcclxuICAgICAgICBpZiAoIXRoaXMuc3ZnKSByZXR1cm47XHJcbiAgICAgICAgdGhpcy5zdmdcclxuICAgICAgICAgICAgLmF0dHIoJ3dpZHRoJywgMClcclxuICAgICAgICAgICAgLmF0dHIoJ2hlaWdodCcsIDApO1xyXG4gICAgfVxyXG5cclxuICAgIC8qKlxyXG4gICAgICogc2V0IHRoaXMud2lkdGggYW5kIHRoaXMuaGVpZ2h0IGZvciBheGlzIHNjYWxlcy4gb25seSBjYWxsZWQgYnkgY2hhcnRzIHdpdGggYXhpc1xyXG4gICAgICogcGFyYW0geyd4JyB8J3knfSAgICAgICAgIF9heGlzXHJcbiAgICAgKiBwYXJhbSB7Ym9vbGVhbn0gX3NraXBDYWwgOiBza2lwIGdldFN2Z09mZnNldCBjYWxjdWxhdGlvbnNcclxuICAgICAqL1xyXG4gICAgcHJpdmF0ZSBfc2V0R3JhcGhEaW1lbnNpb24oX2F4aXM6ICd4JyB8ICd5Jyk6IHZvaWQge1xyXG4gICAgICAgIHRoaXMuc3ZnUmVjdCA9IHRoaXMuc3ZnLm5vZGUoKS5nZXRCb3VuZGluZ0NsaWVudFJlY3QoKTtcclxuICAgICAgICB0aGlzLl9jaGFydFN2Yy5zdmdSZWN0ID0gdGhpcy5zdmdSZWN0O1xyXG5cclxuICAgICAgICBsZXQgdHlwZTogJ3dpZHRoJyB8ICdoZWlnaHQnID0gX2F4aXMgPT09ICd4JyA/ICh0aGlzLmJhci5pc0ludmVydCA/ICdoZWlnaHQnIDogJ3dpZHRoJykgOiAodGhpcy5iYXIuaXNJbnZlcnQgPyAnd2lkdGgnIDogJ2hlaWdodCcpO1xyXG5cclxuICAgICAgICBsZXQgdmFsdWU6IG51bWJlciA9IHRoaXMuX2NoYXJ0U3ZjLmdldFN2Z09mZnNldChfYXhpcywgeyBheGlzTWF4OiB0aGlzLmF4aXNNYXgsIGF4aXNNaW46IHRoaXMuYXhpc01pbiB9KTtcclxuXHJcbiAgICAgICAgdGhpc1t0eXBlXSA9IHZhbHVlIDwgMCA/IDAgOiB2YWx1ZTtcclxuICAgIH1cclxuXHJcbiAgICAvKipcclxuICAgICAqIHNldCBDaGFydCBTZXJ2aWNlIHZhcmlhYmxlc1xyXG4gICAgICovXHJcbiAgICBwcml2YXRlIF9zZXRDaGFydFN2YygpOiB2b2lkIHtcclxuICAgICAgICB0aGlzLl9jaGFydFN2Yy5jb25maWcgPSB0aGlzLmNvbmZpZztcclxuICAgICAgICB0aGlzLl9jaGFydFN2Yy5jaGFydFR5cGUgPSB0aGlzLmNoYXJ0VHlwZTtcclxuICAgICAgICB0aGlzLl9jaGFydFN2Yy5jaGFydENhdGVnb3J5ID0gdGhpcy5jaGFydENhdGVnb3J5O1xyXG4gICAgICAgIHRoaXMuX2NoYXJ0U3ZjLnN2Z1BhcmVudFJlY3QgPSB0aGlzLnN2Z1BhcmVudC5ub2RlKCkuZ2V0Qm91bmRpbmdDbGllbnRSZWN0KCk7XHJcbiAgICAgICAgdGhpcy5fY2hhcnRTdmMuc3ZnID0gdGhpcy5zdmc7XHJcbiAgICAgICAgdGhpcy5fY2hhcnRTdmMuaXNSdGwgPSB0aGlzLmlzUnRsO1xyXG4gICAgICAgIHRoaXMuX2NoYXJ0U3ZjLmlzWFJldmVyc2VkID0gdGhpcy5jb25maWcueEF4aXMucmV2ZXJzZWQ7XHJcbiAgICAgICAgdGhpcy5fY2hhcnRTdmMuaXNZUmV2ZXJzZWQgPSB0aGlzLmNvbmZpZy55QXhpcy5yZXZlcnNlZDtcclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF9zZXRMaW5lYXJTY2FsZSgpOiB2b2lkIHtcclxuICAgICAgICBsZXQgcmFuZ2VSb3VuZFZhbDogQXJyYXk8bnVtYmVyPiA9IHRoaXMuX2dldFJhbmdlVmFsKCd5Jyk7XHJcbiAgICAgICAgdGhpcy55ID0gZDMuc2NhbGVMaW5lYXIoKS5yYW5nZVJvdW5kKHJhbmdlUm91bmRWYWwpO1xyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX3NldEJhbmRTY2FsZSgpOiB2b2lkIHtcclxuICAgICAgICBsZXQgcmFuZ2VWYWw6IEFycmF5PG51bWJlcj4gPSB0aGlzLl9nZXRSYW5nZVZhbCgneCcpO1xyXG5cclxuICAgICAgICB0aGlzLnggPSBkMy5zY2FsZUJhbmQoKS5yYW5nZShyYW5nZVZhbCk7XHJcblxyXG4gICAgICAgIGlmICh0aGlzLmNoYXJ0Q2F0ZWdvcnkgPT09ICdiYXInKSB7XHJcbiAgICAgICAgICAgIHRoaXMueC5wYWRkaW5nSW5uZXIodGhpcy5iYXIuYmFuZFBhZGRpbmcpLnBhZGRpbmdPdXRlcih0aGlzLmJhci5iYW5kUGFkZGluZyAvIDIpO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF9nZXRSYW5nZVZhbChfYXhpczogJ3gnIHwgJ3knKTogbnVtYmVyW10ge1xyXG4gICAgICAgIGxldCByYW5nZVZhbDogbnVtYmVyW107XHJcbiAgICAgICAgbGV0IHJldmVyc2VkOiAnaXNYUmV2ZXJzZWQnIHwgJ2lzWVJldmVyc2VkJyA9IF9heGlzID09PSAneCcgPyAnaXNYUmV2ZXJzZWQnIDogJ2lzWVJldmVyc2VkJztcclxuXHJcbiAgICAgICAgaWYgKHRoaXMuYmFyLmlzSW52ZXJ0KSB7XHJcbiAgICAgICAgICAgIHJhbmdlVmFsID0gX2F4aXMgPT09ICd4JyA/IFswLCB0aGlzLmhlaWdodF0gOiBbMCwgdGhpcy53aWR0aF07XHJcbiAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgcmFuZ2VWYWwgPSBfYXhpcyA9PT0gJ3gnID8gWzAsIHRoaXMud2lkdGhdIDogW3RoaXMuaGVpZ2h0LCAwXTtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIHJldHVybiB0aGlzLl9jaGFydFN2Y1tyZXZlcnNlZF0gPyByYW5nZVZhbC5yZXZlcnNlKCkgOiByYW5nZVZhbDtcclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF9zZXRSYW5nZShpc0JhbmQ/OiBib29sZWFuKTogQXJyYXk8bnVtYmVyPiB7XHJcbiAgICAgICAgbGV0IGNoYXJ0V2lkdGg6IG51bWJlciA9IHRoaXMud2lkdGg7XHJcblxyXG4gICAgICAgIGlmICghaXNCYW5kICYmIHRoaXMuZGF0YS5sZW5ndGggPD0gMCkge1xyXG4gICAgICAgICAgICB0aGlzLnJhbmdlTGlzdFswXSA9IGNoYXJ0V2lkdGg7XHJcbiAgICAgICAgICAgIHJldHVybiBbMCwgY2hhcnRXaWR0aF07XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICBsZXQgeFBvc2l0aW9uOiBudW1iZXIgPSAwO1xyXG4gICAgICAgIGxldCByYW5nZUFycmF5OiBBcnJheTxudW1iZXI+ID0gW107XHJcbiAgICAgICAgbGV0IGJhbmRXaWR0aDogbnVtYmVyID0gY2hhcnRXaWR0aCAvIHRoaXMuZGF0YS5sZW5ndGg7XHJcblxyXG4gICAgICAgIGZvciAobGV0IGkgPSAwOyBpIDwgdGhpcy5kYXRhLmxlbmd0aDsgaSsrKSB7XHJcblxyXG4gICAgICAgICAgICBpZiAoaXNCYW5kKSB7XHJcbiAgICAgICAgICAgICAgICB4UG9zaXRpb24gPSB0aGlzLl9nZXRDZW50ZXJCYW5kUG9zaXRpb24oYmFuZFdpZHRoLCBpKTtcclxuICAgICAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgICAgIHhQb3NpdGlvbiA9IGNoYXJ0V2lkdGggLyAodGhpcy5kYXRhLmxlbmd0aCAtIDEpICogaTtcclxuICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgaWYgKHRoaXMuX2NoYXJ0U3ZjLmlzWFJldmVyc2VkKSB4UG9zaXRpb24gPSBjaGFydFdpZHRoIC0geFBvc2l0aW9uO1xyXG5cclxuICAgICAgICAgICAgcmFuZ2VBcnJheS5wdXNoKHhQb3NpdGlvbik7XHJcbiAgICAgICAgICAgIHRoaXMucmFuZ2VMaXN0W3RoaXMuZGF0YVtpXS54LnZhbHVlXSA9IHhQb3NpdGlvbjtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIHJldHVybiByYW5nZUFycmF5O1xyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX2dldENlbnRlckJhbmRQb3NpdGlvbihfYmFuZFdpZHRoOiBudW1iZXIsIF9wb3NpdGlvbjogbnVtYmVyKTogbnVtYmVyIHtcclxuICAgICAgICByZXR1cm4gKF9iYW5kV2lkdGggLyAyKSArIChfYmFuZFdpZHRoICogX3Bvc2l0aW9uKTtcclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF9zZXRTY2FsZUJ5RGlyZWN0aW9uKF9heGlzOiAneCcgfCAneScsIF94U2NhbGVUeXBlPzogJ2JhbmQnIHwgJ3N0cmluZycpOiB2b2lkIHtcclxuICAgICAgICBpZiAoX2F4aXMgPT09ICd4Jykge1xyXG4gICAgICAgICAgICBpZiAoX3hTY2FsZVR5cGUgIT09ICdzdHJpbmcnKSB0aGlzLl9zZXRCYW5kU2NhbGUoKTtcclxuICAgICAgICAgICAgaWYgKHRoaXMuY2hhcnRDYXRlZ29yeSA9PT0gJ2xpbmUnKSB0aGlzLl9zZXRMaW5lU2NhbGVYKF94U2NhbGVUeXBlKTtcclxuICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICB0aGlzLl9zZXRMaW5lYXJTY2FsZSgpO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICAvKipcclxuICAgICAqIChmb3IgbGluZSBvbmx5KVxyXG4gICAgICogaGFwcGVucyBhdCBmaXJzdCBsb2FkIGFuZCBvbiBjaGFuZ2UgYW5kIG1heSBoYXBwZW4gaWYgZGF0YSBpcyBzbGljZWQgZHVyaW5nIHRyaW1YKClcclxuICAgICAqL1xyXG4gICAgcHJpdmF0ZSBfc2V0TGluZVNjYWxlWChfeFNjYWxlVHlwZTogJ3N0cmluZycgfCAnYmFuZCcpOiB2b2lkIHtcclxuICAgICAgICBpZiAoX3hTY2FsZVR5cGUgPT09ICdzdHJpbmcnKSB7XHJcbiAgICAgICAgICAgIHRoaXMueCA9IGQzLnNjYWxlT3JkaW5hbCgpLnJhbmdlKHRoaXMuX3NldFJhbmdlKGZhbHNlKSk7XHJcbiAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgdGhpcy5fc2V0UmFuZ2UodHJ1ZSk7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIC8vID09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PSBEb21haW4gPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PVxyXG5cclxuICAgIHB1YmxpYyBzZXREb21haW4oX3hTY2FsZVR5cGU6ICdzdHJpbmcnIHwgJ2JhbmQnKTogdm9pZCB7XHJcblxyXG4gICAgICAgIHRoaXMuX2NoYXJ0U3ZjLnhTY2FsZVR5cGUgPSBfeFNjYWxlVHlwZTtcclxuXHJcbiAgICAgICAgdGhpcy5zdmcuYXR0cigndmlzaWJpbGl0eScsICdoaWRkZW4nKTtcclxuXHJcbiAgICAgICAgLy8gc2V0dGluZyB0aGUgY2xhc3MgbmFtZSBvZiBjaGFydC13cmFwcGVyIChmb3IgZmxleC1yZXZlcnNlKVxyXG4gICAgICAgIHRoaXMuX2NoYXJ0U3ZjLnNldFZlcnRBeGlzQW5kQ2hhcnRNYXJnaW4odGhpcy5jb25maWcuaWQpO1xyXG5cclxuICAgICAgICAvLyBldmVyeXRpbWUgdGhlIGdyYXBoIHJlc2V0cywgaWYgdHJpbW1pbmcgaGF2ZSBvY2N1cmVkIGJlZm9yZSAoaWU6IHRoaXMuZGF0YSBhbmQgaW5pdERhdGEgbGVuZ3RoIGRpZmZlcnMpLCByZXNldCB0aGlzLmRhdGEgc28gdGhhdCB0aGUgdHJpbW1pbmcgY2FsY3VsYXRpb24gdXNlcyBmdWxsIGRhdGFzZXRcclxuICAgICAgICBpZiAodGhpcy5pbml0RGF0YSAmJiB0aGlzLmRhdGEubGVuZ3RoICE9PSB0aGlzLmluaXREYXRhLmxlbmd0aCkge1xyXG4gICAgICAgICAgICB0aGlzLmRhdGEgPSBKU09OLnBhcnNlKEpTT04uc3RyaW5naWZ5KHRoaXMuaW5pdERhdGEpKTtcclxuICAgICAgICAgICAgLy8gdGhpcy5fY2hhcnRTdmMuc2V0QXhpc0xhYmVsRHVtbXlUZXh0KHRoaXMuY2F0ZWdvcmllcywgdGhpcy5jb25maWcueEF4aXMubGFiZWxzLmZvcm1hdCk7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICAvLyBzZXQgdGhpcy53aWR0aCxoZWlnaHQsIHNjYWxlLCBkb21haW4gYW5kIHRpY2tWYWx1ZXNcclxuICAgICAgICB0aGlzLl9zZXREb21haW4oX3hTY2FsZVR5cGUpO1xyXG5cclxuICAgICAgICB0aGlzLnN2Zy5hdHRyKCd2aXNpYmlsaXR5JywgJ3Zpc2libGUnKTtcclxuXHJcbiAgICAgICAgLy8gc2V0IG1ham9yIGFuZCBtaW5vciBncmlkIGxpbmVzXHJcbiAgICAgICAgdGhpcy5fc2V0R3JpZExpbmVzKCk7XHJcblxyXG4gICAgICAgIC8vIHNldCB5IGFuZCB4IGF4aXMgbGluZXNcclxuICAgICAgICB0aGlzLnNldEF4aXMoKTtcclxuXHJcbiAgICAgICAgLy8gdHJhbnNmb3JtIGdyYXBoIGFjY29yZGluZyB0byB3aWR0aCBvZiB2ZXJ0aWNhbCBheGlzXHJcbiAgICAgICAgdGhpcy5fY2hhcnRTdmMudHJhbnNmb3JtR3JhcGhDb250YWluZXIodGhpcy5ncmFwaCk7XHJcblxyXG4gICAgICAgIC8vIHJlcG9zaXRpb24gRGF0YSBMYWJlbCBhY2NvcmRpbmcgdG8gd2lkdGggb2YgdmVydGljYWwgYXhpc1xyXG4gICAgICAgIGlmICh0aGlzLmNvbmZpZy5jaGFydC5sYWJlbHMuZW5hYmxlZCkge1xyXG4gICAgICAgICAgICB0aGlzLmRhdGFMYWJlbENvbnRhaW5lci5zdHlsZSgnd2lkdGgnLCB0aGlzLndpZHRoICsgJ3B4Jyk7XHJcbiAgICAgICAgICAgIHRoaXMuX2NoYXJ0U3ZjLnJlcG9zaXRpb25EYXRhTGFiZWwodGhpcy5kYXRhTGFiZWxDb250YWluZXIsIHRoaXMuYXhpc0xhYmVsQ29udGFpbmVyQXJyWzBdKTtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIC8vIHJlcG9zaXRpb24gdmVydGljYWwgYXhpc1xyXG4gICAgICAgIHRoaXMuX2NoYXJ0U3ZjLnJlcG9zaXRpb25WZXJ0aWNhbEF4aXNUaXRsZSgpO1xyXG5cclxuICAgICAgICAvLyBzZXQgY2xpcCBwYXRoIHRvIHRoaXMud2lkdGggYW5kIHRoaXMuaGVpZ2h0IHRvIG1ha2Ugc3VyZSBncmFwaCB3aWxsIG5vdCBiZSBkcmF3biBvdXQgb2YgZ3JhcGhpbmcgcmVnaW9uXHJcbiAgICAgICAgdGhpcy5fc2V0Q2xpcFBhdGgoKTtcclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF9zZXREb21haW4oX3hTY2FsZVR5cGU6ICdzdHJpbmcnIHwgJ2JhbmQnKTogdm9pZCB7XHJcbiAgICAgICAgLy8gZmluZGluZyB0aGUgbWF4L21pbiB2YWx1ZSBhbmQgYXhpc01heC9heGlzTWluXHJcbiAgICAgICAgbGV0IGF4aXNMYWJlbENvbmZpZzogSVlBeGlzQ29uZmlnID0gdGhpcy5jb25maWcueUF4aXM7XHJcbiAgICAgICAgbGV0IHJlc3VsdDogSU1heE1pbkludGVydmFsID0gdGhpcy5fY2hhcnRTdmMuc2V0TWF4QW5kTWluKGF4aXNMYWJlbENvbmZpZywgdGhpcy5kYXRhUmFuZ2UpO1xyXG4gICAgICAgIHRoaXMuX2NoYXJ0U3ZjLnNldEF4aXNEM0Zvcm1hdChyZXN1bHQuaW50ZXJ2YWwpO1xyXG5cclxuICAgICAgICB0aGlzLl9zZXRBeGlzTWF4QW5kTWluKHJlc3VsdC5tYXhWYWx1ZSwgcmVzdWx0Lm1pblZhbHVlLCByZXN1bHQuaW50ZXJ2YWwpO1xyXG5cclxuICAgICAgICBsZXQgeEluZm86IElYSW5mbyA9IHRoaXMuX2NoYXJ0U3ZjLmdldFhJbmZvKHRoaXMuZGF0YSwgdGhpcy5jb25maWcpO1xyXG4gICAgICAgIHRoaXMuX3NldFdpZHRoSGVpZ2h0U2NhbGUoJ3gnLCBfeFNjYWxlVHlwZSk7XHJcbiAgICAgICAgdGhpcy54LmRvbWFpbih4SW5mby52YWx1ZSk7XHJcbiAgICAgICAgdGhpcy5fc2V0WEF4aXNMYWJlbChfeFNjYWxlVHlwZSwgeEluZm8ubG9uZ2VzdFRleHQpO1xyXG5cclxuICAgICAgICB0aGlzLl9zZXRXaWR0aEhlaWdodFNjYWxlKCd5JywgX3hTY2FsZVR5cGUpO1xyXG5cclxuICAgICAgICBsZXQgdGlja1ZhbHVlUmV0dXJuOiBJU2V0VGlja1ZhbHVlUmV0dXJuID0gdGhpcy5fZmluZEludGVydmFsRm9yTm9PdmVybGFwKHJlc3VsdCk7XHJcblxyXG4gICAgICAgIGlmICh0aWNrVmFsdWVSZXR1cm4gJiYgdGlja1ZhbHVlUmV0dXJuLm5lZWRSZWRyYXcpIHtcclxuICAgICAgICAgICAgdGhpcy5fc2V0V2lkdGhIZWlnaHRTY2FsZSgneCcsIF94U2NhbGVUeXBlKTtcclxuICAgICAgICAgICAgdGhpcy54LmRvbWFpbih4SW5mby52YWx1ZSk7XHJcbiAgICAgICAgICAgIHRoaXMuX3NldFhBeGlzTGFiZWwoX3hTY2FsZVR5cGUsIHhJbmZvLmxvbmdlc3RUZXh0KTtcclxuXHJcbiAgICAgICAgICAgIHRoaXMuX3NldFdpZHRoSGVpZ2h0U2NhbGUoJ3knLCBfeFNjYWxlVHlwZSk7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICAvLyBvbmx5IGdlbmVyYXRlIHJhbmdlIGFyciB3aGVuIGludGVydmFsIGlzIHN0YWJsaXplZFxyXG4gICAgICAgIHRoaXMudGlja1ZhbHVlcyA9IHRoaXMuX2NoYXJ0U3ZjLmdldFRpY2tWYWx1ZXModGhpcy5heGlzTWluLCB0aGlzLmF4aXNNYXgsIHRpY2tWYWx1ZVJldHVybi5pbnRlcnZhbCk7XHJcblxyXG4gICAgICAgIC8vIHNldCBZIGRvbWFpblxyXG4gICAgICAgIHRoaXMuZG9tYWluTWF4ID0gYXhpc0xhYmVsQ29uZmlnLmF1dG9Sb3VuZFRvTWF4ID8gdGhpcy5heGlzTWF4IDogcmVzdWx0Lm1heFZhbHVlO1xyXG4gICAgICAgIHRoaXMuZG9tYWluTWluID0gYXhpc0xhYmVsQ29uZmlnLmF1dG9Sb3VuZFRvTWluID8gdGhpcy5heGlzTWluIDogcmVzdWx0Lm1pblZhbHVlO1xyXG4gICAgICAgIHRoaXMueS5kb21haW4oW3RoaXMuZG9tYWluTWluLCB0aGlzLmRvbWFpbk1heF0pO1xyXG4gICAgfVxyXG5cclxuXHJcbiAgICBwcml2YXRlIF9zZXRXaWR0aEhlaWdodFNjYWxlKF9heGlzOiAneCcgfCAneScsIF94U2NhbGVUeXBlOiAnc3RyaW5nJyB8ICdiYW5kJyk6IHZvaWQge1xyXG4gICAgICAgIHRoaXMuc2V0U3ZnRGltZW5zaW9uKF9heGlzKTtcclxuICAgICAgICB0aGlzLl9zZXRHcmFwaERpbWVuc2lvbihfYXhpcyk7XHJcbiAgICAgICAgdGhpcy5fc2V0U2NhbGVCeURpcmVjdGlvbihfYXhpcywgX3hTY2FsZVR5cGUpO1xyXG4gICAgfVxyXG5cclxuICAgIC8qKlxyXG4gICAgICogc2V0IGNsaXAgcGF0aCB0byB0aGlzLndpZHRoIGFuZCB0aGlzLmhlaWdodCB0byBtYWtlIHN1cmUgZ3JhcGggd2lsbCBub3QgYmUgZHJhd24gb3V0IG9mIGdyYXBoaW5nIHJlZ2lvblxyXG4gICAgICovXHJcbiAgICBwcml2YXRlIF9zZXRDbGlwUGF0aCgpOiB2b2lkIHtcclxuICAgICAgICBsZXQgY2xpcFBhdGhSZWN0OiBhbnkgPSB0aGlzLnN2Zy5zZWxlY3RBbGwoJ2RlZnMgI2tkLWNoYXJ0cy1jbGlwLXBhdGgtJyArIHRoaXMuY29uZmlnLmlkICsgJyByZWN0Jyk7XHJcbiAgICAgICAgaWYgKGNsaXBQYXRoUmVjdC5lbXB0eSgpKSB7XHJcbiAgICAgICAgICAgIGNsaXBQYXRoUmVjdCA9IHRoaXMuc3ZnLmluc2VydCgnZGVmcycpLmFwcGVuZCgnY2xpcFBhdGgnKS5hdHRyKCdpZCcsICdrZC1jaGFydHMtY2xpcC1wYXRoLScgKyB0aGlzLmNvbmZpZy5pZCkuYXBwZW5kKCdyZWN0Jyk7XHJcbiAgICAgICAgICAgIGNsaXBQYXRoUmVjdFxyXG4gICAgICAgICAgICAgICAgLmF0dHIoJ3gnLCAwKVxyXG4gICAgICAgICAgICAgICAgLmF0dHIoJ3knLCAwKVxyXG4gICAgICAgICAgICAgICAgLmF0dHIoJ2ZpbGwnLCAnbm9uZScpO1xyXG4gICAgICAgIH1cclxuICAgICAgICBjbGlwUGF0aFJlY3RcclxuICAgICAgICAgICAgLmF0dHIoJ3dpZHRoJywgdGhpcy53aWR0aClcclxuICAgICAgICAgICAgLmF0dHIoJ2hlaWdodCcsIHRoaXMuaGVpZ2h0KTtcclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF9zZXRBeGlzTWF4QW5kTWluKF9tYXhWYWx1ZTogbnVtYmVyLCBfbWluVmFsdWU6IG51bWJlciwgX2ludGVydmFsOiBudW1iZXIpOiB2b2lkIHtcclxuICAgICAgICBsZXQgeUF4aXNDb25maWc6IElZQXhpc0NvbmZpZyA9IHRoaXMuY29uZmlnLnlBeGlzO1xyXG4gICAgICAgIHRoaXMuYXhpc01heCA9IHRoaXMuX2NoYXJ0U3ZjLnNldEF4aXNSb3VuZFZhbHVlKF9tYXhWYWx1ZSwgX2ludGVydmFsLCB5QXhpc0NvbmZpZy5hdXRvUm91bmRUb01heCwgJ3VwJyk7XHJcbiAgICAgICAgdGhpcy5heGlzTWluID0gdGhpcy5fY2hhcnRTdmMuc2V0QXhpc1JvdW5kVmFsdWUoX21pblZhbHVlLCBfaW50ZXJ2YWwsIHlBeGlzQ29uZmlnLmF1dG9Sb3VuZFRvTWluLCAnZG93bicpO1xyXG4gICAgfVxyXG5cclxuICAgIC8qKlxyXG4gICAqIHdpbGwgcmV0dXJuIGFuIG9iamVjdCB3aXRoIGZvbGxvd2luZyBwcm9wZXJ0aWVzXHJcbiAgICogbmVlZFJlZHJhdzogdG8gZGV0ZXJtaW5lIHdoZXRoZXIgdG8gcmVkcmF3IHRoZSBheGlzIChhbmQgcmVzZXQgdGhlIGRvbWFpbilcclxuICAgKiBpbnRlcnZhbDogcGFzcyBvdXQgdGhlIGxhc3Rlc3QgaW50ZXJ2YWwgKHRoYXQgaGF2ZSBubyBvdmVybGFwKSBmb3IgcGVyZm9ybWFuY2UgcmVhc29ucywgc28gdGhhdCB0aGUgd2hpbGUgbG9vcCB3aWxsIG9ubHkgcnVuIG9uY2Ugb24gbmVlZFJlZHJhd1xyXG4gICAqL1xyXG4gICAgcHJpdmF0ZSBfZmluZEludGVydmFsRm9yTm9PdmVybGFwKF9pbml0SW5mbzogSU1heE1pbkludGVydmFsKTogSVNldFRpY2tWYWx1ZVJldHVybiB7XHJcbiAgICAgICAgbGV0IGxlbmd0aDogbnVtYmVyID0gdGhpcy5iYXIuaXNJbnZlcnQgPyB0aGlzLndpZHRoIDogdGhpcy5oZWlnaHQ7XHJcbiAgICAgICAgaWYgKGxlbmd0aCA8PSAwKSByZXR1cm4geyBuZWVkUmVkcmF3OiBmYWxzZSwgaW50ZXJ2YWw6IDAgfTtcclxuXHJcbiAgICAgICAgbGV0IHRpY2tMZW5ndGg6IG51bWJlcjtcclxuICAgICAgICBsZXQgaW5pdFlBeGlzTGFiZWxXaWR0aDogSVlBeGlzTGFiZWxSYW5nZSA9IE9iamVjdC5hc3NpZ24oe30sIHRoaXMuX2NoYXJ0U3ZjLnlBeGlzTGFiZWxXaWR0aCk7XHJcblxyXG4gICAgICAgIGlmICh0aGlzLmJhci5pc0ludmVydCkge1xyXG4gICAgICAgICAgICAvLyBheGlzTWF4IGFuZCBheGlzTWluIGlzIGFscmVhZHkgYXBwZW5kZWQgYXMgZHVtbXkgdG8gc3ZnIHdoZW4gY2FsY3VsYXRpbmcgZm9yIHRoaXMud2lkdGggYW5kIHRoaXMuaGVpZ2h0XHJcbiAgICAgICAgICAgIC8vIHdlIGNhbiBkaXJlY3QgYWNjZXNzIHRvIHRoZSBhY3R1YWwgd2lkdGggaW5zdGVhZCBvZiBkb2luZyBhcHByb3hpbWF0aW9uIGNhbGN1bGF0aW9uIGJhc2VkIG9uIGZvbnQtc2l6ZSAoZXJyb3IgYXMgaGlnaCBhcyAxLzIgb2YgYWN0dWFsIHdpZHRoKVxyXG4gICAgICAgICAgICB0aWNrTGVuZ3RoID0gTWF0aC5tYXgoaW5pdFlBeGlzTGFiZWxXaWR0aC5heGlzTWF4LCBpbml0WUF4aXNMYWJlbFdpZHRoLmF4aXNNaW4pO1xyXG4gICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgIHRpY2tMZW5ndGggPSB0aGlzLl9jaGFydFN2Yy5yZXBsYWNlU3RyaW5nV2l0aE51bWJlcih0aGlzLmNvbmZpZy55QXhpcy5sYWJlbHMuc3R5bGUuZm9udFNpemUpO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgbGV0IGluaXRJbnRlcnZhbDogbnVtYmVyID0gX2luaXRJbmZvLmludGVydmFsO1xyXG4gICAgICAgIGxldCBpbnRlcnZhbDogbnVtYmVyID0gaW5pdEludGVydmFsO1xyXG4gICAgICAgIGxldCBub09mVGlja3MgPSBNYXRoLnJvdW5kKCh0aGlzLmF4aXNNYXggKyBpbnRlcnZhbCAtIHRoaXMuYXhpc01pbikgLyBpbnRlcnZhbCk7XHJcblxyXG4gICAgICAgIGlmIChsZW5ndGggPCB0aWNrTGVuZ3RoIHx8IG5vT2ZUaWNrcyA9PT0gMCkgcmV0dXJuIHsgbmVlZFJlZHJhdzogZmFsc2UsIGludGVydmFsOiAwIH07XHJcblxyXG4gICAgICAgIGxldCBpbml0TG9uZ2VyTnVtOiBudW1iZXIgPSB0aGlzLl9jaGFydFN2Yy5nZXRMb25nZXJOdW1iZXIodGhpcy5heGlzTWF4LCB0aGlzLmF4aXNNaW4pLnRvU3RyaW5nKCkubGVuZ3RoO1xyXG5cclxuICAgICAgICB3aGlsZSAoKGxlbmd0aCAvIG5vT2ZUaWNrcykgPCB0aWNrTGVuZ3RoICYmIG5vT2ZUaWNrcyA+IDIpIHtcclxuICAgICAgICAgICAgaW50ZXJ2YWwgPSBpbnRlcnZhbCAqIDI7XHJcbiAgICAgICAgICAgIHRoaXMuX3NldEF4aXNNYXhBbmRNaW4oX2luaXRJbmZvLm1heFZhbHVlLCBfaW5pdEluZm8ubWluVmFsdWUsIGludGVydmFsKTtcclxuXHJcbiAgICAgICAgICAgIC8vIHdoZW4gdGhlIGludGVydmFsIGNoYW5nZXMsIGF4aXNNYXggb3IgYXhpc01pbiBkb2VzIG5vdCBjaGFuZ2Ugc2lnbmlmaWNhbnRseSAoY2hhbmdlcyBhdCBtb3N0IDEgZGlnaXRzIHBsYWNlKVxyXG4gICAgICAgICAgICAvLyBjaGVjayB0aGF0IHRoZSBjdXJyZW50IGF4aXNNYXgvTWluIGlzIGluZGVlZCBsb25nZXIgdGhhbiB0aGUgaW5pdGlhbCBheGlzTWF4L01pblxyXG4gICAgICAgICAgICBpZiAodGhpcy5iYXIuaXNJbnZlcnQgJiYgdGhpcy5fY2hhcnRTdmMuZ2V0TG9uZ2VyTnVtYmVyKHRoaXMuYXhpc01heCwgdGhpcy5heGlzTWluKS50b1N0cmluZygpLmxlbmd0aCA+IGluaXRMb25nZXJOdW0pIHtcclxuICAgICAgICAgICAgICAgIHRpY2tMZW5ndGggPSB0aGlzLl9jaGFydFN2Yy5zZXREdW1teUF4aXNMYWJlbCh0aGlzLl9jaGFydFN2Yy5nZXRMb25nZXJOdW1iZXIodGhpcy5heGlzTWF4LCB0aGlzLmF4aXNNaW4pLCAnYXhpc01heCcpO1xyXG4gICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICBub09mVGlja3MgPSBNYXRoLnJvdW5kKCh0aGlzLmF4aXNNYXggKyBpbnRlcnZhbCAtIHRoaXMuYXhpc01pbikgLyBpbnRlcnZhbCk7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICAvLyB3aGVuIG92ZXJsYXAgZmluaXNoZXMsIGludGVydmFsIGFuZCBheGlzTWF4L01pbiBpcyBjaGFuZ2VkIGNvbXBhcmVkIHRvIHdoZW4gZ2V0U3ZnT2Zmc2V0KClcclxuICAgICAgICAvLyBjaGVjayB0aGF0IGN1cnJlbnQgaW50ZXJ2YWwgcmVzdWx0cyBpbiBzYW1lIG1heCBsYWJlbCBsZW5ndGgsIGlmIG5vdCwgcmVkcmF3IHRoZSBheGlzIGFuZCBydW4gZ2V0U3ZnT2Zmc2V0KCkgYWdhaW5cclxuICAgICAgICBpZiAoaW5pdEludGVydmFsICE9PSBpbnRlcnZhbCkge1xyXG4gICAgICAgICAgICB0aGlzLl9jaGFydFN2Yy5zZXRBeGlzRDNGb3JtYXQoaW50ZXJ2YWwpO1xyXG4gICAgICAgICAgICBsZXQgbmV3WUF4aXNMYWJlbFdpZHRoOiBJWUF4aXNMYWJlbFJhbmdlID0gdGhpcy5fY2hhcnRTdmMuZ2V0WUF4aXNNYXhBbmRNaW5MYWJlbFdpZHRoKHsgYXhpc01pbjogdGhpcy5heGlzTWluLCBheGlzTWF4OiB0aGlzLmF4aXNNYXggfSk7XHJcbiAgICAgICAgICAgIGlmIChuZXdZQXhpc0xhYmVsV2lkdGguYXhpc01heCAhPT0gaW5pdFlBeGlzTGFiZWxXaWR0aC5heGlzTWF4IHx8IG5ld1lBeGlzTGFiZWxXaWR0aC5heGlzTWluICE9PSBpbml0WUF4aXNMYWJlbFdpZHRoLmF4aXNNaW4pIHtcclxuICAgICAgICAgICAgICAgIHJldHVybiB7IG5lZWRSZWRyYXc6IHRydWUsIGludGVydmFsOiBpbnRlcnZhbCB9O1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICByZXR1cm4geyBuZWVkUmVkcmF3OiBmYWxzZSwgaW50ZXJ2YWw6IGludGVydmFsIH07XHJcbiAgICB9XHJcblxyXG4gICAgLy8gPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09IEdyaWQgTGluZXMgPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PVxyXG5cclxuICAgIHByaXZhdGUgX3NldEdyaWRMaW5lcygpOiB2b2lkIHtcclxuICAgICAgICBpZiAoIXRoaXMuZ3JpZExpbmVzQ29udGFpbmVyKSB0aGlzLmdyaWRMaW5lc0NvbnRhaW5lciA9IHRoaXMuZ3JhcGguYXBwZW5kKCdnJykuYXR0cignY2xhc3MnLCAna2R4LWNoYXJ0cy1ncmlkLWxpbmUtY29udGFpbmVyJyk7XHJcbiAgICAgICAgdGhpcy5fY2hhcnRTdmMuZ3JpZFN2Yy5ncmFwaERpbWVuc2lvbiA9IHsgd2lkdGg6IHRoaXMud2lkdGgsIGhlaWdodDogdGhpcy5oZWlnaHQgfTtcclxuICAgICAgICBpZiAodGhpcy5fY2hhcnRTdmMuZ3JpZFN2Yy5oYXZlR3JpZCh0aGlzLmNvbmZpZywgJ3hBeGlzJywgJ2dyaWRMaW5lJykpIHRoaXMuX3NldFhBeGlzR3JpZCgpO1xyXG4gICAgICAgIGlmICh0aGlzLl9jaGFydFN2Yy5ncmlkU3ZjLmhhdmVHcmlkKHRoaXMuY29uZmlnLCAneUF4aXMnLCAnbWlub3JHcmlkTGluZScpKSB0aGlzLl9zZXRZQXhpc01pbm9yR3JpZCgpO1xyXG4gICAgICAgIGlmICh0aGlzLl9jaGFydFN2Yy5ncmlkU3ZjLmhhdmVHcmlkKHRoaXMuY29uZmlnLCAneUF4aXMnLCAnZ3JpZExpbmUnKSkgdGhpcy5fc2V0WUF4aXNHcmlkKCk7XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfc2V0WEF4aXNHcmlkKCkge1xyXG4gICAgICAgIC8vIHdyYXBwZXIgZnVuY3Rpb24gYXJvdW5kIHRoaXMueCBzbyB0aGF0IGdyaWQgd2lsbCBiZSBkcmF3biBpbiBjZW50ZXIgb2YgcGFkZGluZ0lubmVyXHJcbiAgICAgICAgbGV0IHNjYWxlID0gdGhpcy5fY2hhcnRTdmMuZ3JpZFN2Yy54QXhpc0dyaWRTY2FsZSh0aGlzLngpO1xyXG4gICAgICAgIC8vIGNvbmNhdCBzcGFjZSB0byBkcmF3IGZpcnN0IGdyaWQgbGluZSwgTm90ZTogdGhpcy5kYXRhIG1heSBoYXZlIGJlZW4gc3BsaWNlZCBieSB0cmltWFxyXG4gICAgICAgIGxldCB4RGF0YTogQXJyYXk8c3RyaW5nPiA9IFsnJ10uY29uY2F0KHRoaXMuZGF0YS5tYXAoZGF0YSA9PiBkYXRhLngudmFsdWUpKTtcclxuICAgICAgICAvLyBsZXQgeERhdGE6IEFycmF5PHN0cmluZz4gPSBbJyddLmNvbmNhdChfY2F0ZWdvcmllcyk7XHJcbiAgICAgICAgdGhpcy5fY2hhcnRTdmMuZ3JpZFN2Yy5kcmF3R3JpZExpbmUodGhpcy5ncmlkTGluZXNDb250YWluZXIsIHhEYXRhLCAneEF4aXMnLCAnZ3JpZExpbmUnLCBzY2FsZSk7XHJcbiAgICB9XHJcblxyXG4gICAgLy8gZHJhdyBtYWpvciBncmlkIGxpbmVcclxuICAgIHByaXZhdGUgX3NldFlBeGlzR3JpZCgpIHtcclxuICAgICAgICB0aGlzLl9jaGFydFN2Yy5ncmlkU3ZjLmRyYXdHcmlkTGluZSh0aGlzLmdyaWRMaW5lc0NvbnRhaW5lciwgdGhpcy50aWNrVmFsdWVzLCAneUF4aXMnLCAnZ3JpZExpbmUnLCB0aGlzLnkpO1xyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX3NldFlBeGlzTWlub3JHcmlkKCkge1xyXG4gICAgICAgIGxldCB5QXhpc0NvbmZpZzogSVlBeGlzQ29uZmlnID0gdGhpcy5jb25maWcueUF4aXM7XHJcbiAgICAgICAgaWYgKHlBeGlzQ29uZmlnLm1pbm9yVGlja0ludGVydmFsID49IHlBeGlzQ29uZmlnLnRpY2tJbnRlcnZhbCB8fCAheUF4aXNDb25maWcubWlub3JUaWNrSW50ZXJ2YWwpIHJldHVybjtcclxuXHJcbiAgICAgICAgbGV0IHVwcGVyYm91bmQ6IG51bWJlciA9IHRoaXMuX2NoYXJ0U3ZjLnNldEF4aXNSb3VuZFZhbHVlKHRoaXMuZG9tYWluTWF4LCB5QXhpc0NvbmZpZy5taW5vclRpY2tJbnRlcnZhbCwgZmFsc2UsICd1cCcpO1xyXG4gICAgICAgIGxldCBsb3dlcmJvdW5kOiBudW1iZXIgPSB0aGlzLl9jaGFydFN2Yy5zZXRBeGlzUm91bmRWYWx1ZSh0aGlzLmRvbWFpbk1pbiwgeUF4aXNDb25maWcubWlub3JUaWNrSW50ZXJ2YWwsIGZhbHNlLCAnZG93bicpO1xyXG4gICAgICAgIGxldCBtaW5vclRpY2tWYWx1ZXM6IEFycmF5PG51bWJlcj4gPSB0aGlzLl9jaGFydFN2Yy5nZXRUaWNrVmFsdWVzKGxvd2VyYm91bmQsIHVwcGVyYm91bmQsIHlBeGlzQ29uZmlnLm1pbm9yVGlja0ludGVydmFsKTtcclxuXHJcbiAgICAgICAgdGhpcy5fY2hhcnRTdmMuZ3JpZFN2Yy5kcmF3R3JpZExpbmUodGhpcy5ncmlkTGluZXNDb250YWluZXIsIG1pbm9yVGlja1ZhbHVlcywgJ3lBeGlzJywgJ21pbm9yR3JpZExpbmUnLCB0aGlzLnkpO1xyXG4gICAgfVxyXG5cclxuICAgIC8vID09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PSBBeGlzID09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT1cclxuXHJcbiAgICBwdWJsaWMgc2V0QXhpcygpOiB2b2lkIHtcclxuICAgICAgICBsZXQgdHJhbnNmb3JtUG9zOiBJQXhpc1RyYW5zZm9ybVBvcyA9IHtcclxuICAgICAgICAgICAgcmlnaHQ6ICd0cmFuc2xhdGUoJyArIHRoaXMud2lkdGggKyAnLDApJyxcclxuICAgICAgICAgICAgbGVmdDogJ3RyYW5zbGF0ZSgwLDApJyxcclxuICAgICAgICAgICAgdG9wOiAndHJhbnNsYXRlKDAsMCknLFxyXG4gICAgICAgICAgICBib3R0b206ICd0cmFuc2xhdGUoMCwnICsgdGhpcy5oZWlnaHQgKyAnKSdcclxuICAgICAgICB9O1xyXG5cclxuICAgICAgICBsZXQgeEF4aXNDb25maWc6IElYQXhpc0NvbmZpZyA9IHRoaXMuY29uZmlnLnhBeGlzO1xyXG4gICAgICAgIGxldCB5QXhpc0NvbmZpZzogSVlBeGlzQ29uZmlnID0gdGhpcy5jb25maWcueUF4aXM7XHJcbiAgICAgICAgbGV0IGludmVydDogYm9vbGVhbiA9IHRoaXMuYmFyLmlzSW52ZXJ0O1xyXG4gICAgICAgIGxldCBvcHBvc2l0ZTogeyB4OiBib29sZWFuLCB5OiBib29sZWFuIH0gPSB7XHJcbiAgICAgICAgICAgIHg6IGludmVydCA/IHhBeGlzQ29uZmlnLm9wcG9zaXRlICE9PSB0aGlzLmlzUnRsIDogeEF4aXNDb25maWcub3Bwb3NpdGUsXHJcbiAgICAgICAgICAgIHk6IGludmVydCA/IHlBeGlzQ29uZmlnLm9wcG9zaXRlIDogeUF4aXNDb25maWcub3Bwb3NpdGUgIT09IHRoaXMuaXNSdGxcclxuICAgICAgICB9O1xyXG5cclxuICAgICAgICBsZXQgeEF4aXMgPSB0aGlzLl9nZXRFYWNoQXhpc0Z1bmMoJ3gnLCBvcHBvc2l0ZS54LCBpbnZlcnQpO1xyXG4gICAgICAgIHRoaXMueEF4aXNBcnIucHVzaCh4QXhpcyk7XHJcbiAgICAgICAgdGhpcy55QXhpcyA9IHRoaXMuX2dldEVhY2hBeGlzRnVuYygneScsIG9wcG9zaXRlLnksIGludmVydCk7XHJcblxyXG4gICAgICAgIHhBeGlzLmF0dHIoJ3RyYW5zZm9ybScsIHRoaXMuX2NoYXJ0U3ZjLmdldEF4aXNUcmFuc2Zvcm1Qb3MoJ3gnLCBvcHBvc2l0ZS54LCB0cmFuc2Zvcm1Qb3MpKTtcclxuICAgICAgICB0aGlzLnlBeGlzLmF0dHIoJ3RyYW5zZm9ybScsIHRoaXMuX2NoYXJ0U3ZjLmdldEF4aXNUcmFuc2Zvcm1Qb3MoJ3knLCBvcHBvc2l0ZS55LCB0cmFuc2Zvcm1Qb3MpKTtcclxuXHJcbiAgICAgICAgdGhpcy5fY2hhcnRTdmMuc2V0QXhpc0xhYmVsQ29uZmlnKHhBeGlzLCAneCcpO1xyXG4gICAgICAgIHRoaXMuX2NoYXJ0U3ZjLnNldEF4aXNMYWJlbENvbmZpZyh0aGlzLnlBeGlzLCAneScpO1xyXG5cclxuICAgICAgICBpZiAodGhpcy5fY2hhcnRTdmMuaXNOZWdhdGl2ZVN0YWNrKSB7XHJcbiAgICAgICAgICAgIGxldCBzZWNvbmRYQXhpcyA9IHRoaXMuX2dldEVhY2hBeGlzRnVuYygneCcsICFvcHBvc2l0ZS54LCB0aGlzLmJhci5pc0ludmVydCk7XHJcbiAgICAgICAgICAgIHNlY29uZFhBeGlzLmF0dHIoJ3RyYW5zZm9ybScsIHRoaXMuX2NoYXJ0U3ZjLmdldEF4aXNUcmFuc2Zvcm1Qb3MoJ3gnLCAhb3Bwb3NpdGUueCwgdHJhbnNmb3JtUG9zKSk7XHJcbiAgICAgICAgICAgIHRoaXMuX2NoYXJ0U3ZjLnNldEF4aXNMYWJlbENvbmZpZyhzZWNvbmRYQXhpcywgJ3gnKTtcclxuICAgICAgICAgICAgdGhpcy54QXhpc0Fyci5wdXNoKHNlY29uZFhBeGlzKTtcclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfZ2V0RWFjaEF4aXNGdW5jKF9heGlzOiAneCcgfCAneScsIF9vcHBvc2l0ZTogYm9vbGVhbiwgX2ludmVydDogYm9vbGVhbik6IGFueSB7XHJcbiAgICAgICAgbGV0IGF4aXNGdW5jID0gZ2V0QXhpc0Z1bmMoX2F4aXMsIHRoaXNbX2F4aXNdKTtcclxuICAgICAgICBsZXQgYXhpc0NsYXNzOiBzdHJpbmcgPSAna2R4LWNoYXJ0cy1heGlzIGF4aXMtJyArIF9heGlzO1xyXG5cclxuICAgICAgICBpZiAoKF9pbnZlcnQgJiYgX2F4aXMgPT09ICd4JykgfHwgKCFfaW52ZXJ0ICYmIF9heGlzID09PSAneScpKSB7XHJcbiAgICAgICAgICAgIGF4aXNDbGFzcyArPSAnIGtkeC1jaGFydHMtYXhpcy12ZXJ0aWNhbCc7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICBpZiAoX29wcG9zaXRlKSBheGlzQ2xhc3MgKz0gJyBrZHgtY2hhcnRzLWF4aXMtb3Bwb3NpdGUnO1xyXG5cclxuICAgICAgICBpZiAoX2F4aXMgPT09ICd5Jykge1xyXG4gICAgICAgICAgICBheGlzRnVuY1xyXG4gICAgICAgICAgICAgICAgLnRpY2tWYWx1ZXModGhpcy50aWNrVmFsdWVzKVxyXG4gICAgICAgICAgICAgICAgLnRpY2tGb3JtYXQoKGQpID0+IHtcclxuICAgICAgICAgICAgICAgICAgICAvLyBub3RlOiBvbmx5IHVzZWNhc2UgaXMgbmVnYXRpdmUgc3RhY2sgYmFyIChpbiB2My43LjApLiB3aWxsIGFmZmVjdCBib3RoIHlBeGlzIGxhYmVsIGFuZCB0b29sdGlwIGFuZCBkYXRhTGFiZWxzXHJcbiAgICAgICAgICAgICAgICAgICAgbGV0IHZhbHVlID0gdGhpcy5fY2hhcnRTdmMuY2hlY2tBbmRSZXR1cm5MYWJlbHNQb3NpdGl2ZShkKTtcclxuICAgICAgICAgICAgICAgICAgICByZXR1cm4gdGhpcy5fY2hhcnRTdmMuZ2V0WUF4aXNMYWJlbFRleHQodGhpcy5jb25maWcueUF4aXMsIHZhbHVlKTtcclxuICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgbGV0IGF4aXNFbGVtID0gdGhpcy5ncmFwaC5hcHBlbmQoJ2cnKS5hdHRyKCdjbGFzcycsIGF4aXNDbGFzcykuY2FsbChheGlzRnVuYyk7XHJcblxyXG4gICAgICAgIHJldHVybiBheGlzRWxlbTtcclxuXHJcbiAgICAgICAgZnVuY3Rpb24gZ2V0QXhpc0Z1bmMoX3R5cGU6ICd4JyB8ICd5JywgX3NjYWxlKTogYW55IHtcclxuICAgICAgICAgICAgaWYgKF9pbnZlcnQpIHtcclxuICAgICAgICAgICAgICAgIGlmIChfdHlwZSA9PT0gJ3gnKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKF9vcHBvc2l0ZSkgcmV0dXJuIGQzLmF4aXNSaWdodChfc2NhbGUpO1xyXG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBkMy5heGlzTGVmdChfc2NhbGUpO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgaWYgKF90eXBlID09PSAneScpIHtcclxuICAgICAgICAgICAgICAgICAgICBpZiAoX29wcG9zaXRlKSByZXR1cm4gZDMuYXhpc1RvcChfc2NhbGUpO1xyXG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBkMy5heGlzQm90dG9tKF9zY2FsZSk7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgICAgICBpZiAoX3R5cGUgPT09ICd4Jykge1xyXG4gICAgICAgICAgICAgICAgICAgIGlmIChfb3Bwb3NpdGUpIHJldHVybiBkMy5heGlzVG9wKF9zY2FsZSk7XHJcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIGQzLmF4aXNCb3R0b20oX3NjYWxlKTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIGlmIChfdHlwZSA9PT0gJ3knKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKF9vcHBvc2l0ZSkgcmV0dXJuIGQzLmF4aXNSaWdodChfc2NhbGUpO1xyXG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBkMy5heGlzTGVmdChfc2NhbGUpO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG5cclxuICAgIH1cclxuXHJcbiAgICAvLyA9PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT0gUmVtb3ZlIENoYXJ0ID09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT1cclxuXHJcbiAgICBwdWJsaWMgY2hhcnRUaW1lb3V0KF9jYWxsYmFjazogRnVuY3Rpb24pOiB2b2lkIHtcclxuICAgICAgICAvLyBsZXQgZGVsYXkgPSB0aGlzLmNvbmZpZy5sZWdlbmQuZW5hYmxlZCAmJiB0aGlzLmNoYXJ0Q2F0ZWdvcnkgPT09ICdwaWUnPyA1MDAgOiAxMDtcclxuICAgICAgICBjbGVhclRpbWVvdXQodGhpcy5fc2V0Q2hhcnRUaW1lb3V0KTtcclxuICAgICAgICB0aGlzLl9zZXRDaGFydFRpbWVvdXQgPSBzZXRUaW1lb3V0KCgpOiB2b2lkID0+IHtcclxuICAgICAgICAgICAgX2NhbGxiYWNrKCk7XHJcbiAgICAgICAgfSk7XHJcbiAgICB9XHJcblxyXG5cclxuICAgIHB1YmxpYyByZW1vdmVDaGFydCgpOiB2b2lkIHtcclxuICAgICAgICBjbGVhclRpbWVvdXQodGhpcy5fc2V0Q2hhcnRUaW1lb3V0KTtcclxuICAgICAgICB0aGlzLl9yZW1vdmVFbGVtSW5BcnJheUZvcm0oJ3hBeGlzQXJyJywgKGF4aXMpID0+IGF4aXMucmVtb3ZlKCkpO1xyXG4gICAgICAgIGlmICh0aGlzLnlBeGlzKSB0aGlzLnlBeGlzLnJlbW92ZSgpO1xyXG4gICAgICAgIGlmICh0aGlzLmRhdGFMYWJlbENvbnRhaW5lcikgdGhpcy5kYXRhTGFiZWxDb250YWluZXIuc2VsZWN0QWxsKCcqJykucmVtb3ZlKCk7XHJcbiAgICAgICAgdGhpcy5fcmVtb3ZlRWxlbUluQXJyYXlGb3JtKCdheGlzTGFiZWxDb250YWluZXJBcnInLCAoY29udGFpbmVyKSA9PiBjb250YWluZXIuc2VsZWN0QWxsKCcqJykucmVtb3ZlKCkpO1xyXG4gICAgICAgIGlmICh0aGlzLmdyaWRMaW5lc0NvbnRhaW5lcikgdGhpcy5ncmlkTGluZXNDb250YWluZXIuc2VsZWN0QWxsKCcqJykucmVtb3ZlKCk7XHJcbiAgICAgICAgdGhpcy5fY2xlYXJTdmdEaW1lbnNpb24oKTtcclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF9yZW1vdmVFbGVtSW5BcnJheUZvcm0oX2tleTogc3RyaW5nLCBjYWxsYmFjazogRnVuY3Rpb24pOiB2b2lkIHtcclxuICAgICAgICBpZiAodGhpc1tfa2V5XS5sZW5ndGggIT09IDApIHtcclxuICAgICAgICAgICAgdGhpc1tfa2V5XS5mb3JFYWNoKGVsZW1lbnQgPT4gY2FsbGJhY2soZWxlbWVudCkpO1xyXG4gICAgICAgICAgICB0aGlzW19rZXldID0gW107XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIC8vID09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PSBBeGlzIExhYmVsID09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT1cclxuXHJcbiAgICBwcml2YXRlIF9zZXRYQXhpc0xhYmVsKF94U2NhbGVUeXBlOiAnc3RyaW5nJyB8ICdiYW5kJywgX2xvbmdlc3RUZXh0OiBzdHJpbmcpOiB2b2lkIHtcclxuICAgICAgICBpZiAoIXRoaXMuY29uZmlnLnhBeGlzLmVuYWJsZWQgfHwgIXRoaXMuY29uZmlnLnhBeGlzLmxhYmVscy5lbmFibGVkKSByZXR1cm47XHJcblxyXG4gICAgICAgIGlmICh0aGlzLmF4aXNMYWJlbENvbnRhaW5lckFyci5sZW5ndGggIT09IDApIHtcclxuICAgICAgICAgICAgdGhpcy5fcmVtb3ZlRWxlbUluQXJyYXlGb3JtKCdheGlzTGFiZWxDb250YWluZXJBcnInLCAoY29udGFpbmVyKSA9PiBjb250YWluZXIuc2VsZWN0QWxsKCcqJykucmVtb3ZlKCkpO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgbGV0IHhTcGFjaW5nOiBudW1iZXIgPSB0aGlzLl9jYWxjdWxhdGVYU3BhY2luZyhfeFNjYWxlVHlwZSk7XHJcblxyXG4gICAgICAgIHRoaXMuX2NoYXJ0U3ZjLnNldEF4aXNMYWJlbER1bW15KHRoaXMuY29uZmlnLmlkLCB4U3BhY2luZywgX2xvbmdlc3RUZXh0KTtcclxuICAgICAgICB0aGlzLl9jaGFydFN2Yy5fc2V0QXhpc0xhYmVsTGVuZ3RoKCk7XHJcblxyXG4gICAgICAgIHRoaXMuX3NldEF4aXNMYWJlbENvbnRhaW5lcigpO1xyXG5cclxuICAgICAgICBpZiAodGhpcy5fY2hhcnRTdmMubGFiZWxMZW5ndGggIT09IDApIHRoaXMuX3RyaW1YKF94U2NhbGVUeXBlKTtcclxuXHJcbiAgICAgICAgdGhpcy5heGlzTGFiZWxDb250YWluZXJBcnIuZm9yRWFjaCgoX2F4aXNMYWJlbENvbnRhaW5lciwgaW5kZXgpID0+IHtcclxuICAgICAgICAgICAgdGhpcy5fY2hhcnRTdmMuc2V0QXhpc0xhYmVsQ29udGFpbmVyU3R5bGUoX2F4aXNMYWJlbENvbnRhaW5lcik7XHJcbiAgICAgICAgICAgIC8vIGlmIGRyYXdpbmcgMm5kIGF4aXMsIHNldCB0byBjb21wbGVtZW50IG9mIG9wcG9zaXRlIG9mIDFzdCBheGlzXHJcbiAgICAgICAgICAgIGlmICh0aGlzLl9jaGFydFN2Yy5sYWJlbExlbmd0aCAhPT0gMCkge1xyXG4gICAgICAgICAgICAgICAgbGV0IG9wcG9zaXRlID0gaW5kZXggPT09IDEgPyAhdGhpcy5jb25maWcueEF4aXMub3Bwb3NpdGUgOiB0aGlzLmNvbmZpZy54QXhpcy5vcHBvc2l0ZTtcclxuICAgICAgICAgICAgICAgIHRoaXMuX2RyYXdBeGlzTGFiZWwoXHJcbiAgICAgICAgICAgICAgICAgICAgX2F4aXNMYWJlbENvbnRhaW5lcixcclxuICAgICAgICAgICAgICAgICAgICB7IGxhYmVsSGVpZ2h0OiB0aGlzLl9jaGFydFN2Yy5sYWJlbExlbmd0aCwgbGFiZWxXaWR0aDogeFNwYWNpbmcgfSxcclxuICAgICAgICAgICAgICAgICAgICB7IGlzUm90YXRlOiB0aGlzLl9jaGFydFN2Yy5pc1JvdGF0ZSwgb3Bwb3NpdGU6IG9wcG9zaXRlIH1cclxuICAgICAgICAgICAgICAgICk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9KTtcclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF9zZXRBeGlzTGFiZWxDb250YWluZXIoKTogdm9pZCB7XHJcbiAgICAgICAgdGhpcy5heGlzTGFiZWxDb250YWluZXJBcnIucHVzaCh0aGlzLl9jaGFydFN2Yy5zZXRBeGlzTGFiZWxDb250YWluZXIoKSk7XHJcblxyXG4gICAgICAgIC8vIHJlbmRlciAybmQgYXhpc1xyXG4gICAgICAgIGlmICh0aGlzLl9jaGFydFN2Yy5pc05lZ2F0aXZlU3RhY2spIHtcclxuICAgICAgICAgICAgdGhpcy5heGlzTGFiZWxDb250YWluZXJBcnIucHVzaCh0aGlzLl9jaGFydFN2Yy5zZXRBeGlzTGFiZWxDb250YWluZXIoJy5rZHgtY2hhcnRzLWRvdWJsZS1heGlzLXgnKSk7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX2NhbGN1bGF0ZVhTcGFjaW5nKF94U2NhbGVUeXBlOiAnc3RyaW5nJyB8ICdiYW5kJyk6IG51bWJlciB7XHJcbiAgICAgICAgcmV0dXJuIChfeFNjYWxlVHlwZSA9PT0gJ2JhbmQnKSA/IHRoaXMueC5iYW5kd2lkdGgoKSArIHRoaXMueC5wYWRkaW5nSW5uZXIoKSAqIHRoaXMueC5zdGVwKCkgOiB0aGlzLndpZHRoIC8gKHRoaXMuZGF0YS5sZW5ndGggLSAxKTtcclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF90cmltWChfeFNjYWxlVHlwZTogJ3N0cmluZycgfCAnYmFuZCcpOiB2b2lkIHtcclxuICAgICAgICBsZXQgbWF4Tm9PZlg6IG51bWJlciA9IHRoaXMuX2NhbGN1bGF0ZU1heE5vT2ZYKHRoaXMuX2NoYXJ0U3ZjLmlzUm90YXRlLCBfeFNjYWxlVHlwZSk7XHJcblxyXG4gICAgICAgIGlmIChtYXhOb09mWCA9PT0gdGhpcy5pbml0RGF0YS5sZW5ndGgpIHJldHVybjtcclxuXHJcbiAgICAgICAgLy8gaWYgdGhlIGluaXRhbCBkYXRhIGNhbm5vdCBmaXQgaW50byBtYXhTcGFjZSwgc2xpY2UgYW5kIHNhdmUgdG8gdGhpcy5kYXRhXHJcbiAgICAgICAgdGhpcy5kYXRhID0gdGhpcy5pbml0RGF0YS5zbGljZSgwLCBtYXhOb09mWCk7XHJcbiAgICAgICAgbGV0IHhJbmZvOiBJWEluZm8gPSB0aGlzLl9jaGFydFN2Yy5nZXRYSW5mbyh0aGlzLmRhdGEsIHRoaXMuY29uZmlnKTtcclxuXHJcbiAgICAgICAgLy8gdXBkYXRlIGRvbWFpbiB3aXRoIHRoZSB1cGRhdGVkIHRoaXMuZGF0YVxyXG4gICAgICAgIGlmICh0aGlzLmNoYXJ0Q2F0ZWdvcnkgPT09ICdsaW5lJykgdGhpcy5fc2V0TGluZVNjYWxlWChfeFNjYWxlVHlwZSk7XHJcbiAgICAgICAgdGhpcy54LmRvbWFpbih4SW5mby52YWx1ZSk7XHJcblxyXG4gICAgICAgIC8vIGFmdGVyIHRyaW1taW5nLCB0aGUgbG9uZ2VzdCBheGlzIGxhYmVsIG1heSBub3QgYmUgc2FtZS4gaGVuY2UgcmVjYWxjdWxhdGUgdGhlIGF4aXMgbGFiZWwgY29udGFpbmVyIGhlaWdodFxyXG4gICAgICAgIHRoaXMuX2NoYXJ0U3ZjLnNldEF4aXNMYWJlbER1bW15VGV4dCh4SW5mby5sb25nZXN0VGV4dCk7XHJcbiAgICAgICAgdGhpcy5fY2hhcnRTdmMuX3NldEF4aXNMYWJlbExlbmd0aCgpO1xyXG4gICAgfVxyXG5cclxuICAgIC8vIHRoaXMuZGF0YSB3aWxsIGJlIGNoYW5nZWQvdHJpbWVkIGFjY29yZGluZyB0byBzcGFjZSBnaXZlblxyXG4gICAgcHJpdmF0ZSBfY2FsY3VsYXRlTWF4Tm9PZlgoX2lzUm90YXRlOiBib29sZWFuLCBfeFNjYWxlVHlwZTogJ3N0cmluZycgfCAnYmFuZCcpOiBudW1iZXIge1xyXG4gICAgICAgIGlmICghX2lzUm90YXRlICYmICF0aGlzLmJhci5pc0ludmVydCkgcmV0dXJuIHRoaXMuaW5pdERhdGEubGVuZ3RoO1xyXG5cclxuICAgICAgICBsZXQgb2Zmc2V0OiBudW1iZXIgPSB0aGlzLmNoYXJ0Q2F0ZWdvcnkgPT09ICdiYXInID8gKHRoaXMueC5wYWRkaW5nT3V0ZXIoKSkgKiAyIDogMDtcclxuICAgICAgICBsZXQgbWF4U3BhY2U6IG51bWJlciA9ICh0aGlzLmJhci5pc0ludmVydCA/IHRoaXMuaGVpZ2h0IDogdGhpcy53aWR0aCkgLSBvZmZzZXQ7XHJcbiAgICAgICAgLy8gbm90ZTogd2hlbiByb3RhdGluZyBvciB3aGVuIGNoYXJ0VHlwZSA9PSAnYmFyJywgYXhpc0xBYmVsRHVtbXkgd2lsbCBub3QgdGV4dC13cmFwXHJcbiAgICAgICAgbGV0IGVhY2hJdGVtU2l6ZTogbnVtYmVyID0gdGhpcy5fY2hhcnRTdmMuZ2V0QXhpc0xhYmVsRHVtbXlSZWN0KCkuaGVpZ2h0O1xyXG4gICAgICAgIGxldCBtYXhOb09mWDogbnVtYmVyID0gTWF0aC5mbG9vcihtYXhTcGFjZSAvIGVhY2hJdGVtU2l6ZSk7XHJcblxyXG4gICAgICAgIGlmIChfeFNjYWxlVHlwZSA9PT0gJ3N0cmluZycpIG1heE5vT2ZYICs9IDE7XHJcblxyXG4gICAgICAgIHJldHVybiBNYXRoLm1pbih0aGlzLmluaXREYXRhLmxlbmd0aCwgbWF4Tm9PZlgpO1xyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX2RyYXdBeGlzTGFiZWwoX2NvbnRhaW5lcjogYW55LCBfbGFiZWxEaW1lbnN0aW9uOiB7IGxhYmVsSGVpZ2h0OiBudW1iZXIsIGxhYmVsV2lkdGg6IG51bWJlciB9LCBfYm9vbGVhbkNoZWNrczogSUF4aXNMYWJlbEJvb2xlYW5DaGVja3MpOiB2b2lkIHtcclxuICAgICAgICBsZXQgZmlyc3RUaWNrOiBudW1iZXIgPSAwLCB4QXhpc0xhYmVsQ29uZmlnID0gdGhpcy5jb25maWcueEF4aXMubGFiZWxzO1xyXG4gICAgICAgIGlmICh0aGlzLmNoYXJ0Q2F0ZWdvcnkgPT09ICdiYXInKSBmaXJzdFRpY2sgPSB0aGlzLngucGFkZGluZ091dGVyKCkgKiB0aGlzLnguc3RlcCgpICsgdGhpcy54LmJhbmR3aWR0aCgpIC8gMjtcclxuXHJcbiAgICAgICAgdGhpcy5kYXRhLmZvckVhY2goKGQsIHhJbmRleCkgPT4ge1xyXG4gICAgICAgICAgICBsZXQgbGFiZWxDb250YWluZXI6IGFueSwgdGlja1BvczogbnVtYmVyO1xyXG4gICAgICAgICAgICBsYWJlbENvbnRhaW5lciA9IF9jb250YWluZXIuYXBwZW5kKCdkaXYnKVxyXG4gICAgICAgICAgICAgICAgLmF0dHIoJ2NsYXNzJywgJ2tkeC1jaGFydHMtYXhpcy1sYWJlbCB4LScgKyB4SW5kZXgpXHJcbiAgICAgICAgICAgICAgICAuaHRtbCh0aGlzLl9jaGFydFN2Yy5nZXRMYWJlbEZvcm1hdFJlcGxhY2UoeEF4aXNMYWJlbENvbmZpZy5mb3JtYXQsIGQueC5sYWJlbCkpO1xyXG5cclxuICAgICAgICAgICAgaWYgKF9ib29sZWFuQ2hlY2tzLmlzUm90YXRlKSB7XHJcbiAgICAgICAgICAgICAgICBsYWJlbENvbnRhaW5lci5zdHlsZSgnbWF4LXdpZHRoJywgX2xhYmVsRGltZW5zdGlvbi5sYWJlbEhlaWdodCArICdweCcpO1xyXG4gICAgICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgaWYgKCF0aGlzLmJhci5pc0ludmVydCkgbGFiZWxDb250YWluZXIuc3R5bGUoJ21heC13aWR0aCcsIF9sYWJlbERpbWVuc3Rpb24ubGFiZWxXaWR0aCArICdweCcpO1xyXG4gICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICBpZiAodGhpcy5jaGFydENhdGVnb3J5ID09PSAnYmFyJykge1xyXG4gICAgICAgICAgICAgICAgbGV0IG9yZGVyRnJvbUxlZnQgPSB0aGlzLl9jaGFydFN2Yy5pc1hSZXZlcnNlZCA/IHRoaXMuZGF0YS5sZW5ndGggLSB4SW5kZXggLSAxIDogeEluZGV4O1xyXG4gICAgICAgICAgICAgICAgdGlja1BvcyA9IGZpcnN0VGljayArIHRoaXMueC5zdGVwKCkgKiBvcmRlckZyb21MZWZ0O1xyXG4gICAgICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgdGlja1BvcyA9IHRoaXMucmFuZ2VMaXN0W3RoaXMuZGF0YVt4SW5kZXhdLngudmFsdWVdO1xyXG4gICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICB0aGlzLl9jaGFydFN2Yy5zZXRBeGlzTGFiZWxQb3NpdGlvbihsYWJlbENvbnRhaW5lciwgdGlja1BvcywgT2JqZWN0LmFzc2lnbihfYm9vbGVhbkNoZWNrcywgeyBpc0xhc3Q6IHhJbmRleCA9PT0gdGhpcy5kYXRhLmxlbmd0aCAtIDEgfSkpO1xyXG4gICAgICAgIH0pO1xyXG4gICAgfVxyXG5cclxuICAgIC8vID09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PSBDYXB0dXJlIEhvdmVyIEV2ZW50ID09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT1cclxuXHJcbiAgICAvKipcclxuICAgICAqIF9wYXJhbXMgY2FuIGJlIElEM0RhdGFEYXRhIG9yIGNhbiBjb250YWluIGNhbGxiYWNrc1xyXG4gICAgICoge1xyXG4gICAgICogICAgIC4uLlxyXG4gICAgICogICAgIGNhbGxiYWNrczoge1xyXG4gICAgICogICAgICAgICAnbW91c2VvdmVyJzogRnVuY3Rpb24sXHJcbiAgICAgKiAgICAgICAgICdtb3VzZW91dCc6IEZ1bmN0aW9uXHJcbiAgICAgKiAgICAgfVxyXG4gICAgICogfVxyXG4gICAgICovXHJcblxyXG4gICAgcHVibGljIF9pbml0TW91c2VFdmVudHMoX3BhdGg6IGFueSwgX3BhcmFtcz86IGFueSk6IHZvaWQgeyAgICAgICBcclxuICAgICAgIGxldCBtYXBDb25kaXRpb246IGJvb2xlYW4gPSAodGhpcy5jaGFydFR5cGVbMF0gPT09ICdtYXAnICYmICh0aGlzLmNoYXJ0VHlwZVsxXSA9PT0gJ2Z1bGwnIHx8IHRoaXMuY2hhcnRUeXBlWzFdID09PSAnZmlsdGVyJykpO1xyXG4gICAgICAgIGlmICghdGhpcy5jb25maWcudG9vbHRpcC5lbmFibGVkKSByZXR1cm47XHJcblxyXG4gICAgICAgIGxldCB0b29sdGlwOiBhbnk7XHJcbiAgICAgICAgX3BhdGgub24oJ21vdXNlb3ZlcicsIChkLCBpbmRleCkgPT4ge1xyXG4gICAgICAgICAgICBsZXQgdG9wOiBudW1iZXIgPSBtYXBDb25kaXRpb24gPyBwYXJzZUludChfcGFyYW1zLmZ1bGxHcmFwaC5ub2RlKCkuc3R5bGUudG9wKSArIGQzLmV2ZW50LmxheWVyWSA6IGQzLmV2ZW50LmxheWVyWTtcclxuICAgICAgICAgICAgbGV0IGxlZnQ6IG51bWJlciA9IG1hcENvbmRpdGlvbiA/IHBhcnNlSW50KF9wYXJhbXMuZnVsbEdyYXBoLm5vZGUoKS5zdHlsZS5sZWZ0KSArIGQzLmV2ZW50LmxheWVyWCA6IGQzLmV2ZW50LmxheWVyWDtcclxuICAgICAgICAgICAgbGV0IGdyYXBoUG9pbnRlcjogYW55ID0gKG1hcENvbmRpdGlvbiAmJiBfcGFyYW1zLnRvb2x0aXBMYXllcikgPyBfcGFyYW1zLnRvb2x0aXBMYXllciA6IHRoaXMuc3ZnUGFyZW50O1xyXG4gICAgICAgICAgICB0b29sdGlwID0gZ3JhcGhQb2ludGVyLnNlbGVjdCgnLmtkeC1jaGFydHMtdG9vbHRpcCcpO1xyXG5cclxuICAgICAgICAgICAgLy8gaWYgdG9vbHRpcCBhbHJlYWR5IGV4aXN0IChpbiBjYXNlIG1vdXNlb3V0IGRpZCBub3QgaGFwcGVuKSwgZG9uJ3QgYXBwZW5kIGFueW1vcmUuXHJcbiAgICAgICAgICAgIGlmICh0b29sdGlwLmVtcHR5KCkpIHtcclxuICAgICAgICAgICAgICAgIHRvb2x0aXAgPSBncmFwaFBvaW50ZXIuYXBwZW5kKCdkaXYnKS5hdHRyKCdjbGFzcycsICdrZHgtY2hhcnRzLXRvb2x0aXAnKTtcclxuICAgICAgICAgICAgICAgIHRvb2x0aXAuYXBwZW5kKCdkaXYnKS5hdHRyKCdjbGFzcycsICdrZHgtY2hhcnRzLXRvb2x0aXAtbGFiZWwnKTtcclxuICAgICAgICAgICAgICAgIHRvb2x0aXAuYXBwZW5kKCdkaXYnKS5hdHRyKCdjbGFzcycsICdrZHgtY2hhcnRzLXRvb2x0aXAtY291bnQnKTtcclxuICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgbGV0IGxhYmVsOiBzdHJpbmc7XHJcbiAgICAgICAgICAgIGxldCBjb3VudDogbnVtYmVyIHwgc3RyaW5nO1xyXG4gICAgICAgICAgICAvLyBsZXQgY29uZmlnOiBJQ2hhcnRDb25maWcgPSB0aGlzLl9jaGFydFN2Yy5jb25maWc7XHJcbiAgICAgICAgICAgIGxldCB2YWx1ZTogbnVtYmVyO1xyXG5cclxuICAgICAgICAgICAgaWYgKHRoaXMuY2hhcnRUeXBlICYmICh0aGlzLmNoYXJ0VHlwZVswXSA9PT0gJ3BpZScgfHwgdGhpcy5jaGFydFR5cGVbMF0gPT09ICdkb251dCcpKSB7XHJcbiAgICAgICAgICAgICAgICBsYWJlbCA9IGQuZGF0YS54LnJlcGxhY2UoL8KsL2csICcgJyk7XHJcbiAgICAgICAgICAgICAgICBjb3VudCA9IGQuZGF0YS55O1xyXG4gICAgICAgICAgICAgICAgX3BhcmFtcy5wYXRoQW5pbShkMy5zZWxlY3QoX3BhdGguX2dyb3Vwc1swXVtpbmRleF0pLCB0cnVlLCBfcGFyYW1zLmlubmVyUmFkaXVzLCBfcGFyYW1zLm91dGVyUmFkaXVzKTtcclxuICAgICAgICAgICAgICAgIGQzLnNlbGVjdChfcGF0aC5fZ3JvdXBzWzBdW2luZGV4XSkuc3R5bGUoJ29wYWNpdHknLCAnMC43Jyk7XHJcbiAgICAgICAgICAgIH0gZWxzZSBpZiAodGhpcy5jaGFydFR5cGUgJiYgdGhpcy5jaGFydFR5cGVbMF0gPT09ICdyYWRpYWwnKSB7XHJcbiAgICAgICAgICAgICAgICBsYWJlbCA9IGQueC5yZXBsYWNlKC/CrC9nLCAnICcpO1xyXG4gICAgICAgICAgICAgICAgY291bnQgPSBkLnk7XHJcbiAgICAgICAgICAgICAgICBkMy5zZWxlY3QoX3BhdGguX2dyb3Vwc1swXVtpbmRleF0pLnN0eWxlKCdvcGFjaXR5JywgJzAuNycpO1xyXG4gICAgICAgICAgICB9IGVsc2UgaWYgKHRoaXMuY2hhcnRDYXRlZ29yeSA9PT0gJ2JhcicpIHtcclxuICAgICAgICAgICAgICAgIGxhYmVsID0gX3BhcmFtcy5kYXRhLngubGFiZWw7XHJcbiAgICAgICAgICAgICAgICBjb3VudCA9IHRoaXMuX2NoYXJ0U3ZjLmNoZWNrQW5kUmV0dXJuTGFiZWxzUG9zaXRpdmUoZC52YWx1ZSB8fCAwKTtcclxuICAgICAgICAgICAgICAgIGxhYmVsID0gbGFiZWwudG9TdHJpbmcoKSArICcgJyArIHRoaXMubGVnZW5kRGF0YVtkLmlkXS5uYW1lO1xyXG4gICAgICAgICAgICAgICAgZDMuc2VsZWN0KF9wYXRoLl9ncm91cHNbMF1baW5kZXhdKS5zdHlsZSgnb3BhY2l0eScsICcwLjcnKTtcclxuICAgICAgICAgICAgfSBlbHNlIGlmICh0aGlzLmNoYXJ0Q2F0ZWdvcnkgPT09ICdsaW5lJykge1xyXG4gICAgICAgICAgICAgICAgbGFiZWwgPSBfcGFyYW1zLmRhdGEueC5sYWJlbDtcclxuICAgICAgICAgICAgICAgIGNvdW50ID0gX3BhcmFtcy5kYXRhLnlbaW5kZXhdLnZhbHVlO1xyXG4gICAgICAgICAgICAgICAgbGFiZWwgPSBsYWJlbC50b1N0cmluZygpICsgJyAnICsgdGhpcy5sZWdlbmREYXRhW2RdLm5hbWU7XHJcbiAgICAgICAgICAgIH0gZWxzZSBpZiAodGhpcy5jaGFydENhdGVnb3J5ID09PSAnbWFwJykge1xyXG4gICAgICAgICAgICAgICAgZm9yIChsZXQgaSA9IDA7IGkgPCBfcGFyYW1zLnNlcmllc0RhdGEubGVuZ3RoOyBpKyspIHtcclxuICAgICAgICAgICAgICAgICAgICBpZiAoZC5wcm9wZXJ0aWVzLklEXyA9PSBfcGFyYW1zLnNlcmllc0RhdGFbaV0uaWQpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgbGFiZWwgPSBfcGFyYW1zLnNlcmllc0RhdGFbaV0ubmFtZTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgY291bnQgPSBfcGFyYW1zLnNlcmllc05hbWUgKyAnOiAnICsgX3BhcmFtcy5zZXJpZXNEYXRhW2ldLnZhbHVlO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZSA9IF9wYXJhbXMuc2VyaWVzRGF0YVtpXS52YWx1ZTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICBjb3VudCA9IHRoaXMuX2NoYXJ0U3ZjLmdldExhYmVsVGV4dCh0aGlzLmNvbmZpZy50b29sdGlwLmZvcm1hdCwgY291bnQpO1xyXG4gICAgICAgICAgICB0b29sdGlwLnNlbGVjdCgnLmtkeC1jaGFydHMtdG9vbHRpcC1sYWJlbCcpLmh0bWwobGFiZWwudG9VcHBlckNhc2UoKSk7XHJcbiAgICAgICAgICAgIGlmICh0aGlzLmNoYXJ0VHlwZVsxXSAhPT0gJ2ZpbHRlcicpIHRvb2x0aXAuc2VsZWN0KCcua2R4LWNoYXJ0cy10b29sdGlwLWNvdW50JykuaHRtbChjb3VudCkuc3R5bGUoJ2ZvbnQtd2VpZ2h0JywgJ2JvbGQnKTtcclxuXHJcbiAgICAgICAgICAgIHRvb2x0aXAuYXR0cignc3R5bGUnLCB0aGlzLl9jaGFydFN2Yy5nZXRTdHlsZShPYmplY3QuYXNzaWduKHt9LCBUT09MVElQX0RFRkFVTFRfU1RZTEUpLCB0cnVlKSk7XHJcbiAgICAgICAgICAgIHRvb2x0aXAuc3R5bGUoJ2Rpc3BsYXknLCAnYmxvY2snKTtcclxuICAgICAgICAgICAgdG9vbHRpcC5zdHlsZSgnb3BhY2l0eScsIDIpO1xyXG4gICAgICAgICAgICB0b29sdGlwLnN0eWxlKCd6LWluZGV4JywgNDAzKTtcclxuXHJcbiAgICAgICAgICAgIGlmICh0aGlzLmNoYXJ0Q2F0ZWdvcnkgPT09ICdsaW5lJykge1xyXG4gICAgICAgICAgICAgICAgX3BhcmFtcy5kb3RIb3Zlcih0aGlzLmdldERvdElkKF9wYXJhbXMueEluZGV4LCBkKSwgdHJ1ZSk7XHJcbiAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgIGlmIChfcGFyYW1zICYmIF9wYXJhbXMuY2FsbGJhY2tzICYmIF9wYXJhbXMuY2FsbGJhY2tzLm1vdXNlb3ZlcikgX3BhcmFtcy5jYWxsYmFja3MubW91c2VvdmVyKHZhbHVlKTtcclxuXHJcbiAgICAgICAgICAgIC8vIGluIGNhc2UgbW91c2Vtb3ZlIGRpZCBub3QgdHJpZ2dlciwgcG9zaXRpb24gdG9vbHRpcCBvbmNlIHRvb2x0aXAgaXMgY3JlYXRlZFxyXG4gICAgICAgICAgICBpZiAodGhpcy5jaGFydENhdGVnb3J5ICE9PSAnbWFwJykge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5fY2hhcnRTdmMudG9vbHRpcFN2Yy5wb3NpdGlvblRvb2x0aXAodG9vbHRpcCwgeyB0b3A6IGQzLmV2ZW50LmxheWVyWSwgbGVmdDogZDMuZXZlbnQubGF5ZXJYIH0pO1xyXG4gICAgICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgaWYgKHZhbHVlIHx8IHZhbHVlID09PSAwKSB0aGlzLl9jaGFydFN2Yy50b29sdGlwU3ZjLnBvc2l0aW9uVG9vbHRpcCh0b29sdGlwLCB7IHRvcDogdG9wLCBsZWZ0OiBsZWZ0IH0pO1xyXG4gICAgICAgICAgICAgICAgZWxzZSB0b29sdGlwLnJlbW92ZSgpO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfSk7XHJcblxyXG4gICAgICAgIF9wYXRoLm9uKCdtb3VzZW1vdmUnLCAoZCkgPT4ge1xyXG4gICAgICAgICAgICBsZXQgdG9wOiBudW1iZXIgPSBtYXBDb25kaXRpb24gPyBwYXJzZUludChfcGFyYW1zLmZ1bGxHcmFwaC5ub2RlKCkuc3R5bGUudG9wKSArIGQzLmV2ZW50LmxheWVyWSA6IGQzLmV2ZW50LmxheWVyWTtcclxuICAgICAgICAgICAgbGV0IGxlZnQ6IG51bWJlciA9IG1hcENvbmRpdGlvbiA/IHBhcnNlSW50KF9wYXJhbXMuZnVsbEdyYXBoLm5vZGUoKS5zdHlsZS5sZWZ0KSArIGQzLmV2ZW50LmxheWVyWCA6IGQzLmV2ZW50LmxheWVyWDtcclxuICAgICAgICAgICAgLy8gcG9zaXRpb24gdGhlIHRvb2x0aXAgdG8gdGhlIGN1cnNvclxyXG4gICAgICAgICAgICB0aGlzLl9jaGFydFN2Yy50b29sdGlwU3ZjLnBvc2l0aW9uVG9vbHRpcCh0b29sdGlwLCB7IHRvcDogdG9wLCBsZWZ0OiBsZWZ0IH0pO1xyXG4gICAgICAgIH0pO1xyXG5cclxuICAgICAgICBfcGF0aC5vbignbW91c2VvdXQnLCAoZCwgaW5kZXgpID0+IHtcclxuICAgICAgICAgICAgaWYgKHRoaXMuY2hhcnRUeXBlICYmICh0aGlzLmNoYXJ0VHlwZVswXSA9PT0gJ3BpZScgfHwgdGhpcy5jaGFydFR5cGVbMF0gPT09ICdkb251dCcgfHwgdGhpcy5jaGFydFR5cGVbMF0gPT09ICdyYWRpYWwnIHx8IHRoaXMuY2hhcnRDYXRlZ29yeSA9PT0gJ2JhcicpKSB7XHJcbiAgICAgICAgICAgICAgICBpZiAodGhpcy5jaGFydFR5cGVbMF0gPT09ICdwaWUnIHx8IHRoaXMuY2hhcnRUeXBlWzBdID09PSAnZG9udXQnKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgbGV0IHRoaXNQYXRoOiBhbnkgPSBkMy5zZWxlY3QoX3BhdGguX2dyb3Vwc1swXVtpbmRleF0pO1xyXG4gICAgICAgICAgICAgICAgICAgIGlmICghdGhpc1BhdGguY2xhc3NlZCgnY2xpY2tlZCcpKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIF9wYXJhbXMucGF0aEFuaW0odGhpc1BhdGgsIGZhbHNlLCBfcGFyYW1zLmlubmVyUmFkaXVzLCBfcGFyYW1zLm91dGVyUmFkaXVzKTtcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICBkMy5zZWxlY3QoX3BhdGguX2dyb3Vwc1swXVtpbmRleF0pLnN0eWxlKCdvcGFjaXR5JywgJzEnKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAvLyB0b29sdGlwLnN0eWxlKCdkaXNwbGF5JywgJ25vbmUnKTtcclxuICAgICAgICAgICAgLy8gdG9vbHRpcC5zdHlsZSgnb3BhY2l0eScsIDApO1xyXG4gICAgICAgICAgICB0b29sdGlwLnJlbW92ZSgpO1xyXG5cclxuICAgICAgICAgICAgaWYgKHRoaXMuY2hhcnRDYXRlZ29yeSA9PT0gJ2xpbmUnKSB7XHJcbiAgICAgICAgICAgICAgICBfcGFyYW1zLmRvdEhvdmVyKHRoaXMuZ2V0RG90SWQoX3BhcmFtcy54SW5kZXgsIGQpKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBpZiAoX3BhcmFtcyAmJiBfcGFyYW1zLmNhbGxiYWNrcyAmJiBfcGFyYW1zLmNhbGxiYWNrcy5tb3VzZW91dCkgX3BhcmFtcy5jYWxsYmFja3MubW91c2VvdXQoKTtcclxuICAgICAgICB9KTtcclxuXHJcbiAgICAgICAgX3BhdGgub24oJ2NsaWNrJywgKGQsIGluZGV4KSA9PiB7XHJcbiAgICAgICAgICAgIGlmICh0aGlzLmNoYXJ0VHlwZSAmJiAodGhpcy5jaGFydFR5cGVbMF0gPT09ICdwaWUnIHx8IHRoaXMuY2hhcnRUeXBlWzBdID09PSAnZG9udXQnKSkge1xyXG4gICAgICAgICAgICAgICAgbGV0IHRoaXNQYXRoOiBhbnkgPSBkMy5zZWxlY3QoX3BhdGguX2dyb3Vwc1swXVtpbmRleF0pO1xyXG4gICAgICAgICAgICAgICAgbGV0IGNsaWNrZWQ6IGJvb2xlYW4gPSB0aGlzUGF0aC5jbGFzc2VkKCdjbGlja2VkJyk7XHJcbiAgICAgICAgICAgICAgICBfcGFyYW1zLnBhdGhBbmltKHRoaXNQYXRoLCAhY2xpY2tlZCwgX3BhcmFtcy5pbm5lclJhZGl1cywgX3BhcmFtcy5vdXRlclJhZGl1cyk7XHJcbiAgICAgICAgICAgICAgICB0aGlzUGF0aC5jbGFzc2VkKCdjbGlja2VkJywgIWNsaWNrZWQpO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfSk7XHJcbiAgICB9XHJcblxyXG4gICAgLy8gPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09IExBQkVMID09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT1cclxuXHJcbiAgICBwdWJsaWMgc2V0TGFiZWwoX3lEYXRhOiBJRDNZRGF0YSwgX3hEYXRhOiBzdHJpbmcgfCBudW1iZXIsIF94UG9zaXRpb246IG51bWJlciwgX3lQb3NpdGlvbjogbnVtYmVyKTogYW55IHtcclxuICAgICAgICBpZiAoIXRoaXMuY29uZmlnLmNoYXJ0LmxhYmVscy5lbmFibGVkKSByZXR1cm47XHJcblxyXG4gICAgICAgIGxldCBsYWJlbENvbmZpZzogSURhdGFMYWJlbCA9IHRoaXMuY29uZmlnLmNoYXJ0LmxhYmVscztcclxuXHJcbiAgICAgICAgbGV0IGxhYmVsQ29udGFpbmVyOiBhbnkgPSB0aGlzLmRhdGFMYWJlbENvbnRhaW5lci5hcHBlbmQoJ2RpdicpXHJcbiAgICAgICAgICAgIC5hdHRyKCdjbGFzcycsICdrZHgtY2hhcnRzLWRhdGEtbGFiZWwgeC0nICsgX3hEYXRhICsgJyB5LScgKyBfeURhdGEuaWQpO1xyXG5cclxuICAgICAgICBsZXQgbGFiZWxUZXh0OiBzdHJpbmcgPSB0aGlzLl9jaGFydFN2Yy5nZXRMYWJlbFRleHQobGFiZWxDb25maWcuZm9ybWF0LCBfeURhdGEudmFsdWUpO1xyXG5cclxuICAgICAgICBsYWJlbENvbnRhaW5lclxyXG4gICAgICAgICAgICAuYXBwZW5kKCdkaXYnKVxyXG4gICAgICAgICAgICAuYXR0cignY2xhc3MnLCAna2R4LWNoYXJ0cy1kYXRhLWxhYmVsLXRleHQnKVxyXG4gICAgICAgICAgICAuaHRtbChsYWJlbFRleHQpXHJcbiAgICAgICAgICAgIC5hdHRyKCdzdHlsZScsIHRoaXMuX2NoYXJ0U3ZjLmdldFN0eWxlKGxhYmVsQ29uZmlnLnN0eWxlKSk7XHJcblxyXG4gICAgICAgIHRoaXMuX3NldExhYmVsUG9zaXRpb24obGFiZWxDb250YWluZXIsIF95RGF0YS5zdW0gfHwgX3lEYXRhLnZhbHVlLCBfeFBvc2l0aW9uLCBfeVBvc2l0aW9uKTtcclxuXHJcbiAgICAgICAgcmV0dXJuIGxhYmVsQ29udGFpbmVyO1xyXG4gICAgfVxyXG5cclxuICAgIHB1YmxpYyB0cmFuc2Zvcm1Qb3NpdGlvbih4OiBudW1iZXIgfCBzdHJpbmcsIHk6IG51bWJlciB8IHN0cmluZywgaXNBdHRyaWJ1dGU/OiBib29sZWFuKTogc3RyaW5nIHtcclxuICAgICAgICByZXR1cm4gJ3RyYW5zbGF0ZSgnICsgeCArICgoaXNBdHRyaWJ1dGUpID8gJywnIDogJ3B4LCcpICsgeSArICgoaXNBdHRyaWJ1dGUpID8gJyknIDogJ3B4KScpO1xyXG4gICAgfVxyXG5cclxuICAgIHB1YmxpYyBnZXREb3RJZCh4RGF0YTogc3RyaW5nIHwgbnVtYmVyLCB5SWQ6IHN0cmluZyk6IHN0cmluZyB7XHJcbiAgICAgICAgcmV0dXJuICdrZHgtY2hhcnRzLXBvaW50LWRvdCB4LScgKyB4RGF0YSArICcgeS0nICsgeUlkO1xyXG4gICAgfVxyXG5cclxuICAgIHB1YmxpYyBpc0RhdGFFeGlzdChfaXRlbTogYW55LCBfeUluZGV4OiBudW1iZXIpOiBib29sZWFuIHtcclxuICAgICAgICByZXR1cm4gdGhpcy5fY2hhcnRTdmMuaXNFeGlzdChfaXRlbS55W195SW5kZXhdKTtcclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF9zZXRMYWJlbENvbnRhaW5lcigpOiB2b2lkIHtcclxuICAgICAgICB0aGlzLmRhdGFMYWJlbENvbnRhaW5lciA9IGQzLnNlbGVjdCgnIycgKyB0aGlzLmNvbmZpZy5pZCArICcua2R4LWNoYXJ0cyAnICsgJy5rZHgtY2hhcnRzLWRhdGEtbGFiZWwtY29udGFpbmVyJyk7XHJcbiAgICB9XHJcblxyXG4gICAgLyoqXHJcbiAgICAgKiBfcGFyYW1zIGZvciBiYXI6IHsgdmFsdWVTaWduOiAtMSBvciAwIG9yIDEsIGRpbWVuc2lvbnM6IHdpZHRoLCBoZWlnaHQsIHhQb3MsIHlQb3N9XHJcbiAgICAgKiBfcGFyYW1zIGZvciBsaW5lOiB7IGRvdFNpemU6IG51bWJlciwgbGFiZWxMZW5ndGg6IG51bWJlcn1cclxuICAgICAqL1xyXG4gICAgLy8gYWZmZWN0cyBhbGwgY2hhcnRzIGV4Y2VwdCBwaWUsIG1hcCwgaG9yaXpvbnRhbCBiYXIgKHdoaWNoIHVzZXMgZmxleCBmb3IgdmVydGljYWwgYWxpZ24sIHJlZmVyIHRvIGtkLWJhci1jaGFydClcclxuICAgIHB1YmxpYyBzZXRMYWJlbFRleHRQb3NpdGlvbihsYWJlbFRleHQsIF95UG9zaXRpb246IG51bWJlciwgX3BhcmFtczogeyBba2V5OiBzdHJpbmddOiBhbnkgfSA9IHt9KTogdm9pZCB7XHJcbiAgICAgICAgbGV0IHN0b3JlOiBJTGFiZWxUZXh0VmVydGljYWxBbGlnblN0b3JlID0gTEFCRUxfVEVYVF9WRVJUSUNBTF9BTElHTl9TVE9SRTtcclxuICAgICAgICBsZXQgdmVydGljYWxBbGlnbjogJ3RvcCcgfCAnbWlkZGxlJyB8ICdib3R0b20nID0gdGhpcy5fY2hhcnRTdmMuZ2V0RGVmYXVsdFZlcnRpY2FsQWxpZ24odGhpcy5jb25maWcsIF9wYXJhbXMpO1xyXG4gICAgICAgIGxldCBkb3RTaXplOiBudW1iZXIgPSBfcGFyYW1zLmRvdFNpemUgPyBfcGFyYW1zLmRvdFNpemUgOiAwO1xyXG4gICAgICAgIGxldCBvZmZzZXQ6IG51bWJlciA9IGRvdFNpemUgLyAyO1xyXG5cclxuICAgICAgICBpZiAodmVydGljYWxBbGlnbiA9PT0gJ21pZGRsZScpIHtcclxuICAgICAgICAgICAgbGV0IGNoZWNrcyA9IFsndG9wJywgJ2JvdHRvbSddO1xyXG4gICAgICAgICAgICBjaGVja3MuZm9yRWFjaChrZXkgPT4ge1xyXG4gICAgICAgICAgICAgICAgaWYgKHRoaXMuX2NoYXJ0U3ZjLl9jaGVja0JvdW5kYXJ5KHN0b3JlW2tleV0uY2hlY2ssIF95UG9zaXRpb24sIHRoaXMuaGVpZ2h0LCBkb3RTaXplKSkge1xyXG4gICAgICAgICAgICAgICAgICAgIHZlcnRpY2FsQWxpZ24gPSBzdG9yZVtrZXldLmNoYW5nZVRvO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9KTtcclxuICAgICAgICB9IGVsc2UgaWYgKHRoaXMuX2NoYXJ0U3ZjLl9jaGVja0JvdW5kYXJ5KHN0b3JlW3ZlcnRpY2FsQWxpZ25dLmNoZWNrLCBfeVBvc2l0aW9uLCB0aGlzLmhlaWdodCwgZG90U2l6ZSkpIHtcclxuICAgICAgICAgICAgdmVydGljYWxBbGlnbiA9IHN0b3JlW3ZlcnRpY2FsQWxpZ25dLmNoYW5nZVRvO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgbGV0IHlQb3M6IHN0cmluZyA9ICcnO1xyXG4gICAgICAgIGlmICh2ZXJ0aWNhbEFsaWduID09PSAnbWlkZGxlJykge1xyXG4gICAgICAgICAgICB5UG9zID0gc3RvcmVbdmVydGljYWxBbGlnbl0ucGVyY2VudDtcclxuICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICBsZXQgc2lnbjogc3RyaW5nID0gdmVydGljYWxBbGlnbiA9PT0gJ3RvcCcgPyAnIC0gJyA6ICcgKyAnO1xyXG4gICAgICAgICAgICBpZiAodGhpcy5jaGFydENhdGVnb3J5ID09PSAnYmFyJyAmJiB0aGlzLl9jaGFydFN2Yy5uZWVkT2Zmc2V0Rm9yQ29sdW1uKHZlcnRpY2FsQWxpZ24sIF9wYXJhbXMpKSBvZmZzZXQgKz0gX3BhcmFtcy5kaW1lbnNpb25zLmhlaWdodDtcclxuICAgICAgICAgICAgeVBvcyA9ICdjYWxjKCcgKyBzdG9yZVt2ZXJ0aWNhbEFsaWduXS5wZXJjZW50ICsgc2lnbiArIG9mZnNldC50b1N0cmluZygpICsgJ3B4KSc7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICBsZXQgeFBvczogc3RyaW5nID0gKF9wYXJhbXMubGFiZWxMZW5ndGggJiYgX3BhcmFtcy5sYWJlbExlbmd0aCA+IDEpID8gJ2NhbGMoLTUwJSArICcgKyBkb3RTaXplIC8gMiArICdweCknIDogJzAlJztcclxuXHJcbiAgICAgICAgbGV0IHRyYW5zbGF0ZTogc3RyaW5nID0gdGhpcy5jaGFydENhdGVnb3J5ID09PSAnbGluZScgPyB0aGlzLnRyYW5zZm9ybVBvc2l0aW9uKHhQb3MsIHlQb3MsIHRydWUpIDogJ3RyYW5zbGF0ZVkoJyArIHlQb3MgKyAnKSc7XHJcbiAgICAgICAgbGFiZWxUZXh0LnN0eWxlKCd0cmFuc2Zvcm0nLCB0cmFuc2xhdGUpO1xyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX3NldExhYmVsUG9zaXRpb24obGFiZWxDb250YWluZXI6IGFueSwgX3lWYWx1ZTogbnVtYmVyLCBfeFBvc2l0aW9uOiBudW1iZXIsIF95UG9zaXRpb246IG51bWJlcik6IHZvaWQge1xyXG4gICAgICAgIGxldCBkZWZhdWx0UG9zaXRpb246IHsgeDogbnVtYmVyLCB5OiBudW1iZXIgfSA9IHtcclxuICAgICAgICAgICAgeDogKCh0aGlzLmJhci5pc0ludmVydCkgPyB0aGlzLmhlaWdodCA6IDApLFxyXG4gICAgICAgICAgICB5OiAoKHRoaXMuYmFyLmlzSW52ZXJ0KSA/IHRoaXMud2lkdGggOiAwKVxyXG4gICAgICAgIH07XHJcbiAgICAgICAgbGV0IHg6IG51bWJlciA9ICh0eXBlb2YgX3hQb3NpdGlvbiA9PT0gJ251bWJlcicpID8gX3hQb3NpdGlvbiA6IGRlZmF1bHRQb3NpdGlvbi54O1xyXG4gICAgICAgIGxldCB5OiBudW1iZXIgPSAodHlwZW9mIF95UG9zaXRpb24gPT09ICdudW1iZXInKSA/IF95UG9zaXRpb24gOiBkZWZhdWx0UG9zaXRpb24ueTtcclxuXHJcbiAgICAgICAgLy8gaWYgKF95UG9zaXRpb24gPCB0aGlzLmRhdGFMYWJlbFB1c2hEb3duUmFuZ2UpIHtcclxuICAgICAgICAvLyAgICAgeSA9IDU7XHJcbiAgICAgICAgLy8gfVxyXG5cclxuICAgICAgICBpZiAodGhpcy5pc1J0bCkgeCA9ICh0aGlzLndpZHRoICogLTEpICsgeDtcclxuXHJcbiAgICAgICAgaWYgKF95VmFsdWUgJiYgKF95VmFsdWUgPiB0aGlzLmRvbWFpbk1heCB8fCBfeVZhbHVlIDwgdGhpcy5kb21haW5NaW4pKSB7XHJcbiAgICAgICAgICAgIGxhYmVsQ29udGFpbmVyLnN0eWxlKCdkaXNwbGF5JywgJ25vbmUnKTtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIHRoaXMuX2FwcGx5TGFiZWxQb3NpdGlvbihsYWJlbENvbnRhaW5lciwgeCwgeSk7XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfYXBwbHlMYWJlbFBvc2l0aW9uKGxhYmVsQ29udGFpbmVyOiBhbnksIF94UG9zaXRpb246IG51bWJlciwgX3lQb3NpdGlvbjogbnVtYmVyKTogdm9pZCB7XHJcbiAgICAgICAgbGV0IHJvdGF0ZTogc3RyaW5nID0gJyc7XHJcbiAgICAgICAgbGV0IGxhYmVsU3R5bGU6IHsgW2tleTogc3RyaW5nXTogc3RyaW5nIH0gPSB0aGlzLmNvbmZpZy5jaGFydC5sYWJlbHMuc3R5bGU7XHJcblxyXG4gICAgICAgIC8vIHRoaXMuY29uZmlnLmNoYXJ0LmxhYmVscy5yb3RhdGlvbiBjYW5ub3QgYmUgJycgb3IgbnVsbCBvciBvdGhlciBub24tdmFsdWVcclxuICAgICAgICBpZiAobGFiZWxTdHlsZS5oYXNPd25Qcm9wZXJ0eSgncm90YXRpb24nKSAmJiBsYWJlbFN0eWxlLnJvdGF0aW9uKSB7XHJcbiAgICAgICAgICAgIHJvdGF0ZSA9ICcgcm90YXRlKCcgKyBsYWJlbFN0eWxlLnJvdGF0aW9uICsgJ2RlZyknO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgbGFiZWxDb250YWluZXJcclxuICAgICAgICAgICAgLnN0eWxlKCd0cmFuc2Zvcm0nLCB0aGlzLnRyYW5zZm9ybVBvc2l0aW9uKF94UG9zaXRpb24sIF95UG9zaXRpb24pICsgcm90YXRlKTtcclxuXHJcbiAgICAgICAgaWYgKHRoaXMuaXNSdGwpIGxhYmVsQ29udGFpbmVyLnN0eWxlKCd0ZXh0LWFsaWduJywgJ3JpZ2h0Jyk7XHJcbiAgICB9XHJcbn1cclxuIl19