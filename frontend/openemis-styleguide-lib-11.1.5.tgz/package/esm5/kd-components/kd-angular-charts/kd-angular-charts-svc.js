import { __decorate, __metadata, __values } from "tslib";
import { Injectable } from '@angular/core';
import { KdDomElemSvc } from '../kd-common/index';
import * as d3 from 'd3';
import * as helper from './helper-svc/index';
var KdChartsSvc = /** @class */ (function () {
    function KdChartsSvc(_domSvc) {
        this._domSvc = _domSvc;
        this._isInvert = false;
        this._isRotate = false;
        this._isRtl = false;
        this._defaultSvgMargin = {
            top: 20,
            x: 9,
            y: 12,
            oppVert: 20
        };
        this._svgMargin = {
            top: 0,
            right: 0,
            bottom: 0,
            left: 0
        };
        this._yAxisLabelWidth = {
            axisMax: 0,
            axisMin: 0
        };
        this._minXSpacing = 50;
        this._axisD3Format = '';
        this._isXReversed = false;
        this._isYReversed = false;
        this.dataLabelPushDownRange = 0;
        this._isNegativeStack = false;
        this.gridSvc = new helper.KdChartsGridSvc(this._config);
        this.tooltipSvc = new helper.KdChartsTooltipSvc();
    }
    Object.defineProperty(KdChartsSvc.prototype, "config", {
        get: function () { return this._config; },
        set: function (_config) {
            this._config = _config;
            this.gridSvc.config = _config;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(KdChartsSvc.prototype, "svg", {
        set: function (_svg) { this._svg = _svg; },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(KdChartsSvc.prototype, "svgRect", {
        set: function (_svgRect) { this._svgRect = _svgRect; },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(KdChartsSvc.prototype, "chartType", {
        set: function (_chartType) { this._chartType = _chartType; },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(KdChartsSvc.prototype, "chartCategory", {
        set: function (_chartCategory) { this._chartCategory = _chartCategory; },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(KdChartsSvc.prototype, "isInvert", {
        set: function (_isInvert) {
            this._isInvert = _isInvert;
            this.gridSvc.isInvert = _isInvert;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(KdChartsSvc.prototype, "svgParentRect", {
        set: function (_svgParentRect) { this._svgParentRect = _svgParentRect; },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(KdChartsSvc.prototype, "isRotate", {
        get: function () { return this._isRotate; },
        set: function (_isRotate) { this._isRotate = _isRotate; },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(KdChartsSvc.prototype, "labelLength", {
        get: function () { return this._labelLength; },
        set: function (_labelLength) { this._labelLength = _labelLength; },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(KdChartsSvc.prototype, "svgMargin", {
        get: function () { return this._svgMargin; },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(KdChartsSvc.prototype, "xScaleType", {
        get: function () { return this._xScaleType; },
        set: function (_xScaleType) { this._xScaleType = _xScaleType; },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(KdChartsSvc.prototype, "xSpacing", {
        get: function () { return this._xSpacing; },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(KdChartsSvc.prototype, "axisD3Format", {
        get: function () { return this._axisD3Format; },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(KdChartsSvc.prototype, "yAxisLabelWidth", {
        get: function () { return this._yAxisLabelWidth; },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(KdChartsSvc.prototype, "isRtl", {
        set: function (_isRtl) { this._isRtl = _isRtl; },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(KdChartsSvc.prototype, "isXReversed", {
        get: function () { return this._isXReversed; },
        set: function (_isXReversed) {
            if (!this._isInvert) {
                this._isXReversed = _isXReversed !== this._isRtl;
            }
            else {
                this._isXReversed = _isXReversed;
            }
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(KdChartsSvc.prototype, "isYReversed", {
        get: function () { return this._isYReversed; },
        set: function (_isYReversed) {
            if (this._isInvert) {
                this._isYReversed = _isYReversed !== this._isRtl;
            }
            else {
                this._isYReversed = _isYReversed;
            }
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(KdChartsSvc.prototype, "isNegativeStack", {
        get: function () { return this._isNegativeStack; },
        set: function (_isNegativeStack) { this._isNegativeStack = _isNegativeStack; },
        enumerable: true,
        configurable: true
    });
    // ================================= Vertical Axis ==================================
    /**
     * for rotating vertical axis. if axis is enabled, appends class-name 'rotate-title' to kd charts.
     * param  {Array<string>} _type   chart type: if horizontal bar, use xAxis's(the vertical axis) config
     * param  {any}           _config
     * return {boolean}
     */
    KdChartsSvc.prototype.checkRotateTitleEnabled = function (_type, _config) {
        var axisConfig = _type[0] === 'bar' ? _config.xAxis : _config.yAxis;
        return axisConfig.enabled && axisConfig.title.text !== '';
    };
    KdChartsSvc.prototype.setVertAxisAndChartMargin = function (_id) {
        var chartContainer = document.querySelector('#' + _id + '.kdx-charts .kdx-chart-container');
        var axisConfig = this._isInvert ? this._config.xAxis : this._config.yAxis;
        // setting css for vertical axis
        if (axisConfig.enabled && axisConfig.title.text !== '') {
            var currAxisTitleClass = this._isInvert ? '.kdx-charts-axis-title-x' : '.kdx-charts-axis-title-y';
            this._currVertAxisTitle = document.querySelector('#' + _id + '.kdx-charts ' + currAxisTitleClass + '.kdx-charts-axis-title');
        }
        else {
            this._currVertAxisTitle = null;
        }
        this.setChartContainerMargin(chartContainer);
    };
    KdChartsSvc.prototype.repositionVerticalAxisTitle = function () {
        var _this = this;
        if (!this.isValueExist(this._currVertAxisTitle))
            return;
        var axisTitleClass = this._isInvert ? '.kdx-charts-axis-title-x' : '.kdx-charts-axis-title-y';
        var axisTitleTextArr = document.querySelectorAll('#' + this._config.id + '.kdx-charts ' + axisTitleClass + ' .kdx-charts-axis-title-text');
        axisTitleTextArr.forEach(function (axisTitleText) {
            axisTitleText.style.top = _this._currVertAxisTitle.getBoundingClientRect().height / 2 + axisTitleText.getBoundingClientRect().height / 2 + 'px';
            axisTitleText.style.visibility = 'unset';
        });
    };
    // ================================= Y Axis Label ==================================
    KdChartsSvc.prototype.setMaxAndMin = function (_yAxisConfig, _dataRange) {
        var maxValue = this.isValueExist(_yAxisConfig.maxValue) ? _yAxisConfig.maxValue : _dataRange.max;
        var minValue = this.isValueExist(_yAxisConfig.minValue) ? _yAxisConfig.minValue : _dataRange.min;
        // ensure that min value will not exceed max, vice verse
        maxValue = Math.max(maxValue, minValue);
        minValue = Math.min(maxValue, minValue);
        var interval = d3.max([_yAxisConfig.tickInterval, _yAxisConfig.minorTickInterval]);
        if (!interval || interval <= 0)
            interval = 1;
        // to prevent tick calculation causing stop-script, only allow at most around 1000 ticks (excluding first tick)
        var smallestPossibleInterval = (maxValue - minValue) / 1000;
        if (smallestPossibleInterval > interval) {
            interval = this.isInterger(interval) ? Math.floor(smallestPossibleInterval) : smallestPossibleInterval;
        }
        return {
            maxValue: maxValue,
            minValue: minValue,
            interval: interval
        };
    };
    KdChartsSvc.prototype.setAxisD3Format = function (_interval) {
        var decimalPlace = this.findDecimalPlace(_interval);
        this._axisD3Format = this.getD3Format(_interval, decimalPlace);
    };
    KdChartsSvc.prototype.getYAxisLabelText = function (_yAxisConfig, _value) {
        return this.getLabelText(_yAxisConfig.labels.format, _value, false, this._axisD3Format);
    };
    /**
     * Y axis label dummy. appends text element to svg and returns the width of label
     * param  {number |      string}      _value: label's value
     * param  {string}                    _class: class name for dummy
     * return {number}                    returns actual rendered width of label
     */
    KdChartsSvc.prototype.setDummyAxisLabel = function (_value, _class) {
        // if (!this._config.yAxis.enabled) return 0;
        var yAxisConfig = this._config.yAxis;
        // if axis is enabled, draw axisMax string and axisMin string to compute this.width/height
        var textSelection = this._svg.selectAll('.dummy-' + _class);
        var text = this.getYAxisLabelText(yAxisConfig, _value);
        // element should only be appended once
        if (textSelection.empty())
            textSelection = this._svg.append('text');
        this.setSvgAttribute(textSelection, Object.assign({}, yAxisConfig.labels.style, { class: 'kdx-charts-dummy dummy-' + _class, opacity: 0 }));
        textSelection.text(text);
        return textSelection.node().getBBox().width;
    };
    /**
     * chart width and height have to be calculated based on how long y axis labels are (eg: a lot of space allocated for 1,000,000 as compared to 10)
     * returns this.width or this.height depending on _axis given
     * param  {'x'|'y'}         _axis
     * param  { axisMax: number, axisMin: number } _axisVal
     * return {number}
     */
    KdChartsSvc.prototype.getSvgOffset = function (_axis, _axisVal) {
        var axisOpposite = _axis === 'x' ? this._config.yAxis.opposite : this._config.xAxis.opposite;
        var opposite = axisOpposite !== this._isRtl;
        var yAxisLabelsNotVisible = !this._config.yAxis.enabled || !this._config.yAxis.labels.enabled;
        if (_axis === 'x')
            this._yAxisLabelWidth = this.getYAxisMaxAndMinLabelWidth(_axisVal);
        var internalYAxisLabelWidth = this._yAxisLabelWidth;
        if (yAxisLabelsNotVisible)
            internalYAxisLabelWidth = { axisMax: 0, axisMin: 0 };
        if (!this._isInvert) {
            if (_axis === 'x') {
                var start = opposite ? 'right' : 'left';
                var end = opposite ? 'left' : 'right';
                this._svgMargin[start] = this._defaultSvgMargin.y + Math.max(internalYAxisLabelWidth.axisMax, internalYAxisLabelWidth.axisMin);
                this._svgMargin[end] = this._defaultSvgMargin.oppVert;
                return this._svgRect.width - this._svgMargin[start] - this._svgMargin[end];
            }
            else {
                var start = axisOpposite ? 'bottom' : 'top';
                var end = axisOpposite ? 'top' : 'bottom';
                var labelFontSize = yAxisLabelsNotVisible ? 0 : this.replaceStringWithNumber(this._config.yAxis.labels.style.fontSize);
                this._svgMargin[end] = Math.max(this._defaultSvgMargin.x, 0.5 * labelFontSize);
                this._svgMargin[start] = this.isNegativeStack ? this._svgMargin[end] : this._defaultSvgMargin.top;
                return this._svgRect.height - this._svgMargin[start] - this._svgMargin[end];
            }
        }
        else {
            if (_axis === 'x') {
                var start = axisOpposite ? 'bottom' : 'top';
                var end = axisOpposite ? 'top' : 'bottom';
                var labelFontSize = yAxisLabelsNotVisible ? 0 : this.replaceStringWithNumber(this._config.yAxis.labels.style.fontSize);
                this._svgMargin[start] = this._defaultSvgMargin.top;
                this._svgMargin[end] = this._defaultSvgMargin.y + labelFontSize;
                return this._svgRect.height - this._svgMargin[start] - this._svgMargin[end];
            }
            else {
                var start = opposite ? 'right' : 'left';
                var end = opposite ? 'left' : 'right';
                var startLabelWidth = opposite === this.isYReversed ? internalYAxisLabelWidth.axisMin : internalYAxisLabelWidth.axisMax;
                var endLabelWidth = opposite === this.isYReversed ? internalYAxisLabelWidth.axisMax : internalYAxisLabelWidth.axisMin;
                this._svgMargin[start] = Math.max(this._defaultSvgMargin.x, startLabelWidth / 2);
                this._svgMargin[end] = this.isNegativeStack ? Math.max(this._defaultSvgMargin.x, endLabelWidth / 2) : endLabelWidth / 2 + this._defaultSvgMargin.oppVert;
                return this._svgRect.width - this._svgMargin[start] - this._svgMargin[end];
            }
        }
    };
    /**
     * round axisMax/Min value to interval (eg: Max value is 10 but interval is 3, so max value will be rounded to either 9 or 12)
     * _isAutoRoundToNextInterval is enabled, round to 12
     * _isAutoRoundToNextInterval is disabled, round to 9
     *
     * param  {number}  _value
     * param  {number}  _interval
     * param  {boolean} _isAutoRoundToNextInterval
     * param  {'up' | 'down'}      _roundDir
     * return {number}
     */
    KdChartsSvc.prototype.setAxisRoundValue = function (_value, _interval, _isAutoRoundToNextInterval, _roundDir) {
        // if value is 0, don't round
        if (_value === 0)
            return _value;
        var decimalPlaces = Math.max(this.findDecimalPlace(_value), this.findDecimalPlace(_interval));
        if (decimalPlaces !== 0) {
            // if _value or _interval have decimal, convert them to whole numbers
            _value = _value * Math.pow(10, decimalPlaces);
            _interval = _interval * Math.pow(10, decimalPlaces);
        }
        var sign = Math.sign(_value);
        var newValue = _value - _value % _interval;
        if (_roundDir === 'up') {
            if (sign < 0) {
                if (!_isAutoRoundToNextInterval)
                    newValue = newValue - _interval;
            }
            else {
                if (_isAutoRoundToNextInterval)
                    newValue = newValue + _interval;
            }
        }
        else {
            if (sign < 0) {
                if (_isAutoRoundToNextInterval)
                    newValue = newValue - _interval;
            }
            else {
                if (!_isAutoRoundToNextInterval)
                    newValue = newValue + _interval;
            }
        }
        if (decimalPlaces !== 0)
            newValue = newValue / Math.pow(10, decimalPlaces);
        return newValue;
    };
    KdChartsSvc.prototype.getTickValues = function (_min, _max, _interval) {
        if (!_interval || typeof _min === 'undefined' || typeof _max === 'undefined')
            return [];
        _max = this._getUpperBoundForTickValues(_max, _interval);
        return d3.range(_min, _max, _interval);
    };
    /**
     * set Y axis Label Config
     * param {any}        _axis is Element/d3-selection
     * param {'xAxis' | 'yAxis'}     _direction
     */
    KdChartsSvc.prototype.setAxisLabelConfig = function (_axis, _direction) {
        var axisDir = _direction + 'Axis';
        if (!this._config[axisDir])
            return;
        var axisConfig = this._config[axisDir];
        _axis.selectAll('path')
            .attr('stroke-width', axisConfig.lineWidth)
            .attr('stroke', axisConfig.lineColor);
        _axis.selectAll('line')
            .attr('stroke-width', axisConfig.lineWidth)
            .attr('stroke', axisConfig.lineColor);
        if (_direction === 'x' || !axisConfig.enabled || !this._config[axisDir].labels.enabled) {
            this.setSvgAttribute(_axis.selectAll('text'), { display: 'none' });
        }
        else {
            this.setSvgAttribute(_axis.selectAll('text'), axisConfig.labels.style);
            this.setSvgAttribute(_axis.selectAll('text'), { class: 'kdx-charts-display-number-inside-svg kdx-charts-display-number' });
        }
    };
    KdChartsSvc.prototype.getYAxisMaxAndMinLabelWidth = function (_axisVal) {
        var widthObj = { axisMax: 0, axisMin: 0 };
        // if (this._config.yAxis.labels.enabled) {
        widthObj.axisMax = this.setDummyAxisLabel(_axisVal.axisMax, 'axisMax');
        widthObj.axisMin = this.setDummyAxisLabel(_axisVal.axisMin, 'axisMin');
        // }
        return widthObj;
    };
    KdChartsSvc.prototype._getUpperBoundForTickValues = function (_max, _interval) {
        var decimalPlaces = Math.max(this.findDecimalPlace(_max), this.findDecimalPlace(_interval));
        _max = _max * Math.pow(10, decimalPlaces);
        _interval = _interval * Math.pow(10, decimalPlaces);
        return (_max + _interval) / Math.pow(10, decimalPlaces);
    };
    // ================================= X Axis Label ==================================
    /**
     * set axis Label Container (currently only used for X axis)
     * param  {number} _xSpacing
     * param  {string} _extraClassName [same level as .kdx-charts-axis-label-container. Additional className in case of doubleAxis]
     * return {any}
     */
    KdChartsSvc.prototype.setAxisLabelContainer = function (_extraClassName) {
        if (_extraClassName === void 0) { _extraClassName = ''; }
        this._axisLabelContainer = d3.select('#' + this._config.id + '.kdx-charts .kdx-charts-axis-label-container' + _extraClassName);
        if (!this.isValueExist(this._axisLabelContainer.node()))
            return;
        return this._axisLabelContainer;
    };
    /**** Axis Label Dummy *******/
    KdChartsSvc.prototype.setAxisLabelDummy = function (_id, _xSpacing, _longestText) {
        this._setAxisLabelDummyElement(_id);
        this.setAxisLabelDummyText(_longestText);
        this.isRotate = this._checkRotate(this._isInvert, _xSpacing, this._minXSpacing);
        this._setAxisLabelDummyStyle(_xSpacing);
    };
    KdChartsSvc.prototype.setAxisLabelDummyText = function (_longestText) {
        if (!this._axisLabelDummy)
            return;
        _longestText = this.getLabelFormatReplace(this.config.xAxis.labels.format, _longestText);
        this._setAxisLabelDummyHtml(_longestText);
    };
    KdChartsSvc.prototype.getAxisLabelDummyRect = function () {
        if (!this._axisLabelDummy)
            return 0;
        return this._axisLabelDummy.getBoundingClientRect();
    };
    KdChartsSvc.prototype._setAxisLabelDummyElement = function (_id) {
        if (typeof this._axisLabelDummy === 'undefined') {
            this._axisLabelDummy = document.querySelector('#' + _id + '.kdx-charts .kdx-charts-invisible-axis-label');
        }
    };
    KdChartsSvc.prototype._setAxisLabelDummyHtml = function (_text) {
        if (!this._axisLabelDummy)
            return;
        this._axisLabelDummy.innerHTML = _text;
    };
    KdChartsSvc.prototype._setAxisLabelDummyStyle = function (_xSpacing) {
        if (!this._isInvert && !this.isRotate) {
            this._axisLabelDummy.style.maxWidth = _xSpacing + 'px';
        }
    };
    /**** Others *******/
    KdChartsSvc.prototype._checkRotate = function (_isInvert, _xSpacing, _minXSpacing) {
        // if each bar/xSpacing has at least 50 px, do not rotate, let the label word-wrap
        if (_xSpacing >= _minXSpacing || _isInvert)
            return false;
        // rotate only if xSpacing < 50px AND the actual text(with paddding) length > each bar/xSpacing
        return this.getAxisLabelDummyRect().width > _xSpacing;
    };
    KdChartsSvc.prototype._setAxisLabelLength = function () {
        var longestLength = this.getAxisLabelDummyRect().width || 0, svgParentRect = this._svgParentRect, svgLength = (this._isInvert ? svgParentRect.width : svgParentRect.height) || 0, labelLength = Math.min(longestLength, 0.3 * svgLength);
        this._labelLength = labelLength;
    };
    KdChartsSvc.prototype._getAxisMargin = function (_isInvert, _isRotate) {
        var axisMargin = { top: 0, left: 0, right: 0 };
        var opposite = this._config.yAxis.opposite || false;
        if (!_isInvert) {
            var titleWidth = 0;
            var side = this._isRtl ? 'right' : 'left';
            var sign = this._isRtl ? -1 : 1;
            opposite = opposite !== this._isRtl;
            if (!opposite && this.isValueExist(this._currVertAxisTitle)) {
                titleWidth = this._currVertAxisTitle.getBoundingClientRect().width;
            }
            axisMargin[side] = sign * (this._svgMargin.left + titleWidth);
        }
        else {
            axisMargin.top = this._svgMargin.top;
            if (opposite)
                axisMargin.top += this._getHorizTitleHeight();
            axisMargin.right = 2;
        }
        return axisMargin;
    };
    KdChartsSvc.prototype.setAxisLabelContainerStyle = function (_container) {
        var styleType = this._isInvert ? 'width' : 'height';
        var styleVal = this.labelLength;
        if (!this._isInvert && !this.isRotate) {
            styleVal = this.getAxisLabelDummyRect().height;
        }
        _container.style(styleType, styleVal + 'px');
        if (!this._isInvert)
            _container.style('width', '100%');
        this._axisLabelDummy.style.maxWidth = '100%';
        var margin = this._getAxisMargin(this._isInvert, this.isRotate);
        _container
            .style('margin-top', margin.top + 'px')
            .style('margin-right', margin.right + 'px')
            .style('margin-left', margin.left + 'px');
        this._axisLabelContainerMarginLeft = margin.left;
    };
    /**
     * set X axis Label Position
     * param {any}     _labelContainer
     * param {number}  _tickPos
     * param {IAxisLabelBooleanChecks} _booleanChecks
     */
    KdChartsSvc.prototype.setAxisLabelPosition = function (_labelContainer, _tickPos, _booleanChecks) {
        if (this._isInvert || _booleanChecks.isRotate || (_booleanChecks.isLast && this._xScaleType === 'string')) {
            this._domSvc.addClass(_labelContainer.node(), 'ellipsis');
        }
        // when rotating, there shouldn't be any padding(.kdx-charts-child-padding-both) or 'special' padding (.kdx-charts-child-special-padding)
        // must execute before offset position
        if (_booleanChecks.isRotate)
            _labelContainer.style('padding', 0);
        var labelRect = _labelContainer.node().getBoundingClientRect(), offset = !this._isInvert && !_booleanChecks.isRotate ? labelRect.width / 2 : labelRect.height / 2, offSetSign = _booleanChecks.isRotate && _booleanChecks.opposite ? -1 : 1, position = _tickPos - offset * offSetSign;
        // for horizontal bar
        if (this._isInvert) {
            var horizDir = this._isRtl !== _booleanChecks.opposite ? 'left' : 'right';
            _labelContainer
                .style('top', position + 'px')
                .style(horizDir, 0 + 'px');
            return;
        }
        var vertDir = _booleanChecks.opposite ? 'bottom' : 'top';
        // for all other axis charts
        if (_booleanChecks.isRotate) {
            var vertDist = _booleanChecks.isRotate && !_booleanChecks.opposite ? labelRect.width : 0;
            _labelContainer
                .style(vertDir, vertDist + 'px')
                .style('transform', 'rotate(-90deg)');
        }
        else {
            if (this._xScaleType === 'string') {
                // when position is negative and it's absolute value is more than the margin of axisLabelContainer
                if (position + this._axisLabelContainerMarginLeft < 0) {
                    var diff = Math.abs(position) - this._axisLabelContainerMarginLeft;
                    _labelContainer.style('max-width', (labelRect.width - 2 * diff) + 'px');
                    position = -1 * this._axisLabelContainerMarginLeft;
                }
                if (_booleanChecks.isLast)
                    _labelContainer.style('max-width', (labelRect.width / 2 + this._svgMargin.right) + 'px');
            }
            _labelContainer.style(vertDir, 0 + 'px');
        }
        _labelContainer.style('left', position + 'px');
    };
    // ================================= Data Labels ==================================
    /**
     * data labels have to be repositioned according to title and axis Labels's width and position
     * param {any} _dataLabelContainer d3-selection
     * param {any} _axisLabelContainer d3-selection
     */
    KdChartsSvc.prototype.repositionDataLabel = function (_dataLabelContainer, _axisLabelContainer) {
        var axisLabelContainerRect = this.isValueExist(_axisLabelContainer) ? _axisLabelContainer.node().getBoundingClientRect() : { width: 0, height: 0 };
        var left = this._calculateDataLabelLeft(axisLabelContainerRect.width);
        var top = this._calculateDataLabelTop(axisLabelContainerRect.height);
        _dataLabelContainer
            .style('left', left + 'px')
            .style('top', top + 'px');
    };
    KdChartsSvc.prototype._calculateDataLabelLeft = function (_labelWidth) {
        var opposite = this._isInvert ? this._config.xAxis.opposite : this._config.yAxis.opposite;
        var chartMarginLeft = this._config.chart.margin.left;
        // when vertical axis on right (only one axis), left side have no axis
        // NOTE: do not run this step when column/bar-stack-negative, since both left and right side have vertical axis
        if (opposite !== this._isRtl && !this.isNegativeStack) {
            return this._svgMargin.left + this.replaceStringWithNumber(chartMarginLeft);
        }
        // when vertical axis on left
        var titleWidth = this.isValueExist(this._currVertAxisTitle) ? this._currVertAxisTitle.getBoundingClientRect().width : 0;
        var left = this.replaceStringWithNumber(chartMarginLeft);
        left += this._isInvert ? titleWidth + _labelWidth + this._svgMargin.left + 2 : titleWidth + this._svgMargin.left;
        return left;
    };
    KdChartsSvc.prototype._calculateDataLabelTop = function (_labelHeight) {
        var opposite = this._isInvert ? this._config.yAxis.opposite : this._config.xAxis.opposite;
        // when horizontal axis is at bottom
        // NOTE: do not run this step when column/bar-stack-negative, since both above and below have horizontal axis
        if (!opposite && !this.isNegativeStack) {
            return this._svgMargin.top + this.replaceStringWithNumber(this._config.chart.margin.top);
        }
        // when horizontal axis on top
        var horizTitleHeight = this._getHorizTitleHeight();
        var top = this.replaceStringWithNumber(this._config.chart.margin.top);
        top += this._isInvert ? horizTitleHeight + this._svgMargin.top : horizTitleHeight + this._svgMargin.top + _labelHeight;
        return top;
    };
    KdChartsSvc.prototype._getHorizTitleHeight = function () {
        var className = '#' + this._config.id + '.kdx-charts .kdx-charts-axis-title';
        className += this._isInvert ? '-y' : '-x';
        var horizTitleElement = document.querySelector(className);
        return this.isValueExist(horizTitleElement) ? horizTitleElement.getBoundingClientRect().height : 0;
    };
    /****Vertical Align*****/
    KdChartsSvc.prototype._getLabelTextHeight = function () {
        var labelStyle = this._config.chart.labels.style;
        var fontSize = this.replaceStringWithNumber(labelStyle.fontSize);
        var borderWidth = this.replaceStringWithNumber(labelStyle.borderWidth);
        return fontSize * 1.3 + borderWidth * 2;
    };
    KdChartsSvc.prototype._checkBoundary = function (_type, _yPosition, _chartHeight, _dotSize) {
        if (_dotSize === void 0) { _dotSize = 0; }
        var textSize = this._getLabelTextHeight() + _dotSize / 2;
        if (_type === 'max') {
            return _yPosition - textSize < this.dataLabelPushDownRange;
        }
        else {
            return _yPosition + textSize > _chartHeight - this.dataLabelPushDownRange;
        }
    };
    KdChartsSvc.prototype.needOffsetForColumn = function (_verticalAlign, _params) {
        if (_params === void 0) { _params = {}; }
        if (!_params.dimensions)
            return false;
        if (_params.valueSign < 0) {
            if (_verticalAlign === 'top')
                return -1; // needs offset, returning true condition
        }
        else {
            if (_verticalAlign === 'bottom')
                return 1; // needs offset, returning true condition
        }
        return false;
    };
    // NOTE: data label vertical align is not defined in default config (as of v3.7.0 becos behaviour changes with different chart types)
    KdChartsSvc.prototype.getDefaultVerticalAlign = function (_config, _params) {
        if (_config.chart.labels.verticalAlign)
            return _config.chart.labels.verticalAlign;
        var defaultValue = 'top';
        // for column, negative values need to be placed on bottom
        if (_params.valueSign < 0)
            defaultValue = 'bottom';
        return defaultValue;
    };
    // ================================= General ==================================
    /**
     * in arabic, numbers are in ltr mode (eg: negative sign is typed first)
     * Hence wrapping a div around number (only) with className '.kdx-charts-display-number' to force direction: ltr
     * param  {number} _number
     * return {string}
     */
    KdChartsSvc.prototype.wrapNumberInInlineDiv = function (_number) {
        return '<div class="kdx-charts-display-number" style="display: inline-block;" dir="ltr">' + _number + '</div>';
    };
    KdChartsSvc.prototype.replaceStringWithNumber = function (_value) {
        if (typeof _value === 'number')
            return _value;
        return parseFloat(_value.replace(/[^0-9.]/g, ''));
    };
    KdChartsSvc.prototype.getForLoopSequence = function (_chartType) {
        return _chartType[0] !== 'bar' && (_chartType[1] === 'stack' || _chartType[1] === '100') ? 'descending' : 'ascending';
    };
    KdChartsSvc.prototype.getForLoopInfo = function (_type, arrLength) {
        return {
            start: _type === 'ascending' ? 0 : arrLength - 1,
            end: _type === 'ascending' ? arrLength : -1,
            check: _type === 'ascending' ? function (i, end) { return i < end; } : function (i, end) { return i > end; },
            iterate: _type === 'ascending' ? function (i) { return i + 1; } : function (i) { return i - 1; },
        };
    };
    KdChartsSvc.prototype.getXInfo = function (_data, _config) {
        var _this = this;
        var xInfo = {
            value: [],
            longestText: ''
        };
        var longestTextWidth = 0;
        var showValueInLabel = _config.xAxis.labels.format.indexOf('{value}') > -1 && _config.xAxis.enabled && _config.xAxis.labels.enabled;
        if (showValueInLabel)
            this._setAxisLabelDummyElement(_config.id);
        _data.forEach(function (d) {
            xInfo.value.push(d.x.value);
            // if no value needs to be showed in label, then no need check longest text
            if (showValueInLabel) {
                _this._setAxisLabelDummyHtml(d.x.label);
                var currentWidth = _this.getAxisLabelDummyRect().width;
                if (currentWidth > longestTextWidth) {
                    longestTextWidth = currentWidth;
                    xInfo.longestText = d.x.label;
                }
            }
        });
        return xInfo;
    };
    KdChartsSvc.prototype.checkAndReturnLabelsPositive = function (_value) {
        if (this.isNegativeStack) {
            var plotOptions = this.config.plotOptions;
            if (plotOptions && plotOptions.bar && typeof plotOptions.bar.allLabelsPositive !== 'undefined') {
                return this.config.plotOptions.bar.allLabelsPositive ? Math.abs(_value) : _value;
            }
            return Math.abs(_value);
        }
        return _value;
    };
    KdChartsSvc.prototype.findDecimalPlace = function (_number) {
        if (parseInt(_number.toString()) === _number)
            return 0;
        var result = 0;
        var stringForm = Math.abs(_number).toString();
        var splitByDot = stringForm.split('.');
        if (stringForm.indexOf('e') < 0) {
            result = splitByDot[1].length;
        }
        else {
            result = parseInt(stringForm.split('e-')[1]);
            if (typeof splitByDot[1] !== 'undefined')
                result += splitByDot[1].length;
        }
        return result;
    };
    KdChartsSvc.prototype.getLabelText = function (_format, _value, _isHTML, _d3Format) {
        if (_isHTML === void 0) { _isHTML = true; }
        var d3Format = typeof _d3Format === 'undefined' ? this.getD3Format(_value) : _d3Format;
        var text = this.changeValueToD3Format(_value, d3Format);
        if (_isHTML)
            text = this.wrapNumberInInlineDiv(text);
        return this.getLabelFormatReplace(_format, text);
    };
    KdChartsSvc.prototype.getLabelFormatReplace = function (_format, _text) {
        return _format.replace(/{value}/g, _text);
    };
    KdChartsSvc.prototype.isInterger = function (_value) {
        return typeof _value === 'number' && (_value % 1) === 0;
    };
    KdChartsSvc.prototype.getD3Format = function (_value, _toDecimalPlace) {
        if (typeof _value === 'string')
            return '';
        if (Math.abs(_value) > 10000000)
            return '.2e';
        if (this.isInterger(_value)) {
            return ',';
        }
        else {
            // is decimal
            if (Math.abs(_value) < 0.00000001)
                return '.2e';
            if (typeof _toDecimalPlace !== 'undefined' && _toDecimalPlace !== 0) {
                // if precision is given
                return '.' + _toDecimalPlace.toString() + 'f';
            }
        }
        return '';
    };
    KdChartsSvc.prototype.changeValueToD3Format = function (_value, _format) {
        if (typeof _value === 'string')
            return _value;
        return d3.format(_format)(_value);
    };
    KdChartsSvc.prototype.getLongerNumber = function (_num1, _num2) {
        return _num1.toString().length > _num2.toString().length ? _num1 : _num2;
    };
    KdChartsSvc.prototype.setChartContainerMargin = function (_chartContainer) {
        var margin = this._config.chart.margin;
        _chartContainer.style.padding = margin.top + ' ' + margin.right + ' ' + margin.bottom + ' ' + margin.left;
    };
    KdChartsSvc.prototype.transformGraphContainer = function (_container) {
        _container.attr('transform', 'translate(' + this._svgMargin.left + ',' + this._svgMargin.top + ')');
    };
    KdChartsSvc.prototype.setSvgAttribute = function (_element, _config) {
        for (var key in _config) {
            if (!this.isValueExist(_config[key]))
                continue;
            var attributeStr = key === 'color' ? 'fill' : key.replace(/([a-zA-Z])(?=[A-Z])/g, '$1-').toLowerCase();
            _element.attr(attributeStr, _config[key]);
        }
    };
    KdChartsSvc.prototype.isExist = function (_yElem) {
        return (typeof _yElem !== 'undefined' && _yElem !== null && _yElem.value !== null);
    };
    KdChartsSvc.prototype.isValueExist = function (_val) {
        return (typeof _val !== 'undefined' && _val !== null && _val !== '');
    };
    KdChartsSvc.prototype.getD3MaxOrMin = function (_arr, _type) {
        if (_type === 'max')
            return d3.max(_arr);
        if (_type === 'min')
            return d3.min(_arr);
    };
    KdChartsSvc.prototype.getAxisTransformPos = function (_axis, _opposite, _transformPos) {
        if (this._isInvert) {
            if (_axis === 'x') {
                if (_opposite)
                    return _transformPos.right;
                return _transformPos.left;
            }
            if (_axis === 'y') {
                if (_opposite)
                    return _transformPos.top;
                return _transformPos.bottom;
            }
        }
        else {
            if (_axis === 'x') {
                if (_opposite)
                    return _transformPos.top;
                return _transformPos.bottom;
            }
            if (_axis === 'y') {
                if (_opposite)
                    return _transformPos.right;
                return _transformPos.left;
            }
        }
    };
    KdChartsSvc.prototype.getLimitedCategories = function (_initCategories, _xThreshold) {
        if (!_initCategories)
            return [];
        return _xThreshold && _initCategories.length > _xThreshold ? _initCategories.slice(0, _xThreshold) : _initCategories;
    };
    /**
     * return config into css string so can be added into element
     * param  {object}  defaultConfig config
     * param  {boolean} isForTooltip  if tooltip, compare default config with config pass from user
     * return {string}                css styling
     */
    KdChartsSvc.prototype.getStyle = function (defaultConfig, isForTooltip) {
        var e_1, _a;
        var config = {};
        if (isForTooltip) {
            config = this._config.tooltip.style;
        }
        var styling = '';
        if (defaultConfig) {
            try {
                for (var _b = __values(Object.keys(defaultConfig)), _c = _b.next(); !_c.done; _c = _b.next()) {
                    var defaultKey = _c.value;
                    styling += defaultKey.replace(/([a-zA-Z])(?=[A-Z])/g, '$1-').toLowerCase();
                    styling += ':';
                    styling += (config && config.hasOwnProperty(defaultKey)) ? config[defaultKey] : defaultConfig[defaultKey];
                    styling += ';';
                }
            }
            catch (e_1_1) { e_1 = { error: e_1_1 }; }
            finally {
                try {
                    if (_c && !_c.done && (_a = _b.return)) _a.call(_b);
                }
                finally { if (e_1) throw e_1.error; }
            }
        }
        return styling;
    };
    // ================================= Line only ==================================
    /**
     * check if line missing
     * param {[type]} _data        data
     * param {[type]} _dataIndex   xIndex
     * param {[type]} _seriesIndex yIndex / yValueIndex
     */
    KdChartsSvc.prototype.isSeriesNull = function (_data, _dataIndex, _seriesIndex) {
        var currentVal = 0;
        var dataLength = 0;
        var isIChartData = this._isChartData;
        if (isIChartData(_data)) {
            currentVal = _data.series[_seriesIndex].data[_dataIndex].value;
            dataLength = _data.xAxis.categories.length;
        }
        else {
            currentVal = _data[_dataIndex].y[_seriesIndex].value;
            dataLength = _data.length;
        }
        function getValue(when, isNull) {
            var index = 0;
            if (when === 'prev') {
                if (_dataIndex > 0) {
                    index = _dataIndex - 1;
                }
                else {
                    return false;
                }
            }
            else {
                if (_dataIndex < dataLength - 1) {
                    index = _dataIndex + 1;
                }
                else {
                    return false;
                }
            }
            var value = (isIChartData(_data) ? _data.series[_seriesIndex].data[index].value : _data[index].y[_seriesIndex].value);
            if (isNull) {
                return value === null;
            }
            return value !== null;
        }
        var isPrevNull = getValue('prev', true);
        var isPrevNotNull = getValue('prev', false);
        var isNextNull = getValue('next', true);
        var isNextNotNull = getValue('next', false);
        var isAppearing = isNextNotNull && currentVal !== null && isPrevNull;
        var isDisappearing = isNextNull && currentVal !== null && isPrevNotNull;
        return {
            isPrevNull: isPrevNull,
            isPrevNotNull: isPrevNotNull,
            isNextNull: isNextNull,
            isNextNotNull: isNextNotNull,
            isAppearing: isAppearing,
            isDisappearing: isDisappearing
        };
    };
    KdChartsSvc.prototype._isChartData = function (object) {
        return 'series' in object;
    };
    // ================================= Kd Chart only ==================================
    /**
     * required for percentage calculation of 100 stack. returns a array of total sum of data value of each categories.
     * param  {Array<ISeries>} _seriesArr
     * param  {Array<string>}  _categories
     * return {Array<number>}
     */
    KdChartsSvc.prototype.getTotalSumArrFromSeries = function (_seriesArr, _categories, seriesLength) {
        var sumArr = [];
        for (var i = 0; i < _categories.length; ++i) {
            var sum = 0;
            for (var j = 0; j < seriesLength; ++j) {
                if (typeof _seriesArr[j].data[i] === 'undefined')
                    continue;
                var currentVal = _seriesArr[j].data[i].value;
                if (typeof currentVal === 'undefined')
                    continue;
                sum = (currentVal === null) ? sum : sum + currentVal;
            }
            sumArr.push(sum);
        }
        return sumArr;
    };
    // ================================= Pie only ==================================
    /**
     * check if line missing
     * param {[key: string]: ILegendData} _legendData pie chart legend data
     * param {any} _data pie chart data
     * param {IChartConfig} _config pie chart legend config
     */
    KdChartsSvc.prototype.setPieData = function (_legendData, _data, _config, _seriesThreshold) {
        var pieData = [];
        var pieColor = [];
        var legendId;
        var pieDataArrayLength = 0;
        var configDataArray = Object.keys(_legendData).map(function (key) { return _legendData[key]; });
        _legendData = {};
        for (var i = 0; i < _data.data.length; i++) {
            for (var j = 0; j < _data.data[i].y.length; j++) {
                for (var k = 0; k < configDataArray.length; k++) {
                    if (_data.data[i].y[j]['id'] === configDataArray[k].id) {
                        if (typeof _data.series[0].data[i].y !== 'undefined') {
                            if ((_seriesThreshold !== undefined && _seriesThreshold !== null && pieDataArrayLength < _seriesThreshold) || _seriesThreshold === undefined || _seriesThreshold === null) {
                                var colorPointer = _data.data[i].y[j]['color'];
                                var colorValue = (colorPointer && colorPointer != null && colorPointer != null) ? colorPointer : this.getDefaultConfig('color', pieDataArrayLength, _config);
                                legendId = 'id' + pieDataArrayLength;
                                _legendData[legendId] = {
                                    'name': _data.data[i].x + ' ' + configDataArray[k].name,
                                    'id': legendId,
                                    'shape': 'circle',
                                    'x': _data.data[i].x + ' ' + configDataArray[k].name,
                                    'y': _data.data[i].y[j]['value'],
                                    'xBase': _data.data[i].x,
                                    'index': 'pie' + pieDataArrayLength,
                                    'color': colorValue,
                                    'seriesIndex': j,
                                    'dataIndex': i
                                };
                                pieColor.push(colorValue);
                                pieData.push({
                                    'id': legendId,
                                    'x': _data.data[i].x + ' ' + configDataArray[k].name,
                                    'y': _data.data[i].y[j]['value'],
                                    'xBase': _data.data[i].x,
                                    'index': 'pie' + pieDataArrayLength,
                                    'color': colorValue,
                                    'seriesIndex': j,
                                    'dataIndex': i
                                });
                                pieDataArrayLength++;
                                break;
                            }
                        }
                    }
                }
            }
        }
        var returnParams = {
            'pieData': pieData,
            'pieColor': pieColor,
            'legendData': _legendData
        };
        return returnParams;
    };
    KdChartsSvc.prototype.singlePieDataMassage = function (_legendData, _data, _config, _seriesThreshold) {
        var pieData = [];
        var pieColor = [];
        var legendId;
        var pieDataArrayLength = 0;
        _legendData = {};
        if (_data.series && _data.series[0] && _data.series[0].data) {
            for (var i = 0; i < _data.series[0].data.length; i++) {
                if (typeof _data.series[0].data[i].y !== 'undefined') {
                    if ((_seriesThreshold != undefined && _seriesThreshold != null && pieDataArrayLength < _seriesThreshold) || _seriesThreshold == undefined || _seriesThreshold == null) {
                        var colorPointer = _data.series[0].data[i]['color'];
                        var colorValue = (colorPointer && colorPointer != null && colorPointer != null) ? colorPointer : this.getDefaultConfig('color', pieDataArrayLength, _config);
                        legendId = 'id' + pieDataArrayLength;
                        _legendData[legendId] = {
                            'name': _data.series[0].data[i].name.replace(/¬/g, ' '),
                            'id': legendId,
                            'shape': 'circle',
                            'x': _data.series[0].data[i].name,
                            'y': _data.series[0].data[i].y,
                            'xBase': _data.series[0].data[i].name,
                            'index': 'pie' + pieDataArrayLength,
                            'color': colorValue,
                        };
                        pieColor.push(colorValue);
                        if (_data.series[0].data[i].y && _data.series[0].data[i].y > 0) {
                            pieData.push({
                                'id': legendId,
                                'x': _data.series[0].data[i].name,
                                'y': _data.series[0].data[i].y,
                                'xBase': _data.series[0].data[i].name,
                                'index': 'pie' + pieDataArrayLength,
                                'color': colorValue,
                            });
                        }
                        pieDataArrayLength++;
                    }
                }
            }
        }
        var returnParams = {
            'pieData': pieData,
            'pieColor': pieColor,
            'legendData': _legendData
        };
        return returnParams;
    };
    KdChartsSvc.prototype.setMapLegendData = function (_legendData, _data, _config) {
        var legendId;
        _legendData = {};
        for (var i = 0; i < _data.length; i++) {
            if (_data[i].name != undefined) {
                var colorPointer = _data[i].color;
                legendId = 'id' + i;
                _legendData[legendId] = {
                    'name': _data[i].name,
                    'id': legendId,
                    'shape': 'circle',
                    'x': _data[i].name,
                    'y': _data[i].data[0].value,
                    'xBase': _data[i].name,
                    'color': (colorPointer && colorPointer != null && colorPointer != undefined) ? colorPointer : this.getDefaultConfig('color', i, _config),
                    'mapSeriesId': _data[i].id,
                    'deactive': _data[i].deactive
                };
            }
        }
        return _legendData;
    };
    KdChartsSvc.prototype.getDefaultConfig = function (_element, _seriesIndex, _config) {
        if (_element === 'shape')
            return 'circle';
        if (_seriesIndex || _seriesIndex === 0) {
            return _config.colors[_seriesIndex % _config.colors.length];
        }
    };
    KdChartsSvc.prototype.setSingleLegendLevels = function (_dataClasses, _decimalPrecison, _valueSuffix, _originalLegend) {
        var _legendData = {};
        for (var i = 0; i < _dataClasses.length; i++) {
            var legendId = 'id' + i;
            _legendData[legendId] = {
                'name': _dataClasses[i].from.toFixed(_decimalPrecison) + _valueSuffix + ' - ' + _dataClasses[i].to.toFixed(_decimalPrecison) + _valueSuffix,
                'id': legendId,
                'shape': 'circle',
                'color': _dataClasses[i].color,
                'deactive': _originalLegend && _originalLegend[legendId] ? _originalLegend[legendId].deactive : false
            };
        }
        return _legendData;
    };
    KdChartsSvc.ctorParameters = function () { return [
        { type: KdDomElemSvc }
    ]; };
    KdChartsSvc = __decorate([
        Injectable(),
        __metadata("design:paramtypes", [KdDomElemSvc])
    ], KdChartsSvc);
    return KdChartsSvc;
}());
export { KdChartsSvc };
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoia2QtYW5ndWxhci1jaGFydHMtc3ZjLmpzIiwic291cmNlUm9vdCI6Im5nOi8vb3BlbmVtaXMtc3R5bGVndWlkZS1saWIvIiwic291cmNlcyI6WyJrZC1jb21wb25lbnRzL2tkLWFuZ3VsYXItY2hhcnRzL2tkLWFuZ3VsYXItY2hhcnRzLXN2Yy50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiO0FBQUEsT0FBTyxFQUFFLFVBQVUsRUFBRSxNQUFNLGVBQWUsQ0FBQztBQUMzQyxPQUFPLEVBQUUsWUFBWSxFQUFFLE1BQU0sb0JBQW9CLENBQUM7QUFDbEQsT0FBTyxLQUFLLEVBQUUsTUFBTSxJQUFJLENBQUM7QUFDekIsT0FBTyxLQUFLLE1BQU0sTUFBTSxvQkFBb0IsQ0FBQztBQW9CN0M7SUE0Q0kscUJBQW9CLE9BQXFCO1FBQXJCLFlBQU8sR0FBUCxPQUFPLENBQWM7UUF0Q2pDLGNBQVMsR0FBWSxLQUFLLENBQUM7UUFHM0IsY0FBUyxHQUFZLEtBQUssQ0FBQztRQUczQixXQUFNLEdBQVksS0FBSyxDQUFDO1FBQ3hCLHNCQUFpQixHQUE0RDtZQUNqRixHQUFHLEVBQUUsRUFBRTtZQUNQLENBQUMsRUFBRSxDQUFDO1lBQ0osQ0FBQyxFQUFFLEVBQUU7WUFDTCxPQUFPLEVBQUUsRUFBRTtTQUNkLENBQUM7UUFDTSxlQUFVLEdBQWtFO1lBQ2hGLEdBQUcsRUFBRSxDQUFDO1lBQ04sS0FBSyxFQUFFLENBQUM7WUFDUixNQUFNLEVBQUUsQ0FBQztZQUNULElBQUksRUFBRSxDQUFDO1NBQ1YsQ0FBQztRQUNNLHFCQUFnQixHQUFxQjtZQUN6QyxPQUFPLEVBQUUsQ0FBQztZQUNWLE9BQU8sRUFBRSxDQUFDO1NBQ2IsQ0FBQztRQUlNLGlCQUFZLEdBQVcsRUFBRSxDQUFDO1FBRzFCLGtCQUFhLEdBQVcsRUFBRSxDQUFDO1FBQzNCLGlCQUFZLEdBQVksS0FBSyxDQUFDO1FBQzlCLGlCQUFZLEdBQVksS0FBSyxDQUFDO1FBQzlCLDJCQUFzQixHQUFXLENBQUMsQ0FBQztRQUNuQyxxQkFBZ0IsR0FBWSxLQUFLLENBQUM7UUFNdEMsSUFBSSxDQUFDLE9BQU8sR0FBRyxJQUFJLE1BQU0sQ0FBQyxlQUFlLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxDQUFDO1FBQ3hELElBQUksQ0FBQyxVQUFVLEdBQUcsSUFBSSxNQUFNLENBQUMsa0JBQWtCLEVBQUUsQ0FBQztJQUN0RCxDQUFDO0lBRUQsc0JBQUksK0JBQU07YUFJVixjQUE2QixPQUFPLElBQUksQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDO2FBSm5ELFVBQVcsT0FBTztZQUNkLElBQUksQ0FBQyxPQUFPLEdBQUcsT0FBTyxDQUFDO1lBQ3ZCLElBQUksQ0FBQyxPQUFPLENBQUMsTUFBTSxHQUFHLE9BQU8sQ0FBQztRQUNsQyxDQUFDOzs7T0FBQTtJQUdELHNCQUFJLDRCQUFHO2FBQVAsVUFBUSxJQUFJLElBQUksSUFBSSxDQUFDLElBQUksR0FBRyxJQUFJLENBQUMsQ0FBQyxDQUFDOzs7T0FBQTtJQUVuQyxzQkFBSSxnQ0FBTzthQUFYLFVBQVksUUFBUSxJQUFJLElBQUksQ0FBQyxRQUFRLEdBQUcsUUFBUSxDQUFDLENBQUMsQ0FBQzs7O09BQUE7SUFFbkQsc0JBQUksa0NBQVM7YUFBYixVQUFjLFVBQVUsSUFBSSxJQUFJLENBQUMsVUFBVSxHQUFHLFVBQVUsQ0FBQyxDQUFDLENBQUM7OztPQUFBO0lBQzNELHNCQUFJLHNDQUFhO2FBQWpCLFVBQWtCLGNBQWMsSUFBSSxJQUFJLENBQUMsY0FBYyxHQUFHLGNBQWMsQ0FBQyxDQUFDLENBQUM7OztPQUFBO0lBRTNFLHNCQUFJLGlDQUFRO2FBQVosVUFBYSxTQUFTO1lBQ2xCLElBQUksQ0FBQyxTQUFTLEdBQUcsU0FBUyxDQUFDO1lBQzNCLElBQUksQ0FBQyxPQUFPLENBQUMsUUFBUSxHQUFHLFNBQVMsQ0FBQztRQUN0QyxDQUFDOzs7T0FBQTtJQUVELHNCQUFJLHNDQUFhO2FBQWpCLFVBQWtCLGNBQWMsSUFBSSxJQUFJLENBQUMsY0FBYyxHQUFHLGNBQWMsQ0FBQyxDQUFDLENBQUM7OztPQUFBO0lBRTNFLHNCQUFJLGlDQUFRO2FBQ1osY0FBMEIsT0FBTyxJQUFJLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQzthQURsRCxVQUFhLFNBQVMsSUFBSSxJQUFJLENBQUMsU0FBUyxHQUFHLFNBQVMsQ0FBQyxDQUFDLENBQUM7OztPQUFBO0lBR3ZELHNCQUFJLG9DQUFXO2FBQ2YsY0FBNEIsT0FBTyxJQUFJLENBQUMsWUFBWSxDQUFDLENBQUMsQ0FBQzthQUR2RCxVQUFnQixZQUFZLElBQUksSUFBSSxDQUFDLFlBQVksR0FBRyxZQUFZLENBQUMsQ0FBQyxDQUFDOzs7T0FBQTtJQUduRSxzQkFBSSxrQ0FBUzthQUFiLGNBQWtCLE9BQU8sSUFBSSxDQUFDLFVBQVUsQ0FBQyxDQUFDLENBQUM7OztPQUFBO0lBRTNDLHNCQUFJLG1DQUFVO2FBQ2QsY0FBbUIsT0FBTyxJQUFJLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQzthQUQ3QyxVQUFlLFdBQVcsSUFBSSxJQUFJLENBQUMsV0FBVyxHQUFHLFdBQVcsQ0FBQyxDQUFDLENBQUM7OztPQUFBO0lBRy9ELHNCQUFJLGlDQUFRO2FBQVosY0FBaUIsT0FBTyxJQUFJLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQzs7O09BQUE7SUFFekMsc0JBQUkscUNBQVk7YUFBaEIsY0FBcUIsT0FBTyxJQUFJLENBQUMsYUFBYSxDQUFDLENBQUMsQ0FBQzs7O09BQUE7SUFFakQsc0JBQUksd0NBQWU7YUFBbkIsY0FBd0IsT0FBTyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsQ0FBQyxDQUFDOzs7T0FBQTtJQUV2RCxzQkFBSSw4QkFBSzthQUFULFVBQVUsTUFBTSxJQUFJLElBQUksQ0FBQyxNQUFNLEdBQUcsTUFBTSxDQUFDLENBQUMsQ0FBQzs7O09BQUE7SUFFM0Msc0JBQUksb0NBQVc7YUFPZixjQUFvQixPQUFPLElBQUksQ0FBQyxZQUFZLENBQUMsQ0FBQyxDQUFDO2FBUC9DLFVBQWdCLFlBQVk7WUFDeEIsSUFBSSxDQUFDLElBQUksQ0FBQyxTQUFTLEVBQUU7Z0JBQ2pCLElBQUksQ0FBQyxZQUFZLEdBQUcsWUFBWSxLQUFLLElBQUksQ0FBQyxNQUFNLENBQUM7YUFDcEQ7aUJBQU07Z0JBQ0gsSUFBSSxDQUFDLFlBQVksR0FBRyxZQUFZLENBQUM7YUFDcEM7UUFDTCxDQUFDOzs7T0FBQTtJQUdELHNCQUFJLG9DQUFXO2FBT2YsY0FBb0IsT0FBTyxJQUFJLENBQUMsWUFBWSxDQUFDLENBQUMsQ0FBQzthQVAvQyxVQUFnQixZQUFZO1lBQ3hCLElBQUksSUFBSSxDQUFDLFNBQVMsRUFBRTtnQkFDaEIsSUFBSSxDQUFDLFlBQVksR0FBRyxZQUFZLEtBQUssSUFBSSxDQUFDLE1BQU0sQ0FBQzthQUNwRDtpQkFBTTtnQkFDSCxJQUFJLENBQUMsWUFBWSxHQUFHLFlBQVksQ0FBQzthQUNwQztRQUNMLENBQUM7OztPQUFBO0lBR0Qsc0JBQUksd0NBQWU7YUFDbkIsY0FBaUMsT0FBTyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsQ0FBQyxDQUFDO2FBRGhFLFVBQW9CLGdCQUF5QixJQUFJLElBQUksQ0FBQyxnQkFBZ0IsR0FBRyxnQkFBZ0IsQ0FBQyxDQUFDLENBQUM7OztPQUFBO0lBRzVGLHFGQUFxRjtJQUVyRjs7Ozs7T0FLRztJQUNJLDZDQUF1QixHQUE5QixVQUErQixLQUFvQixFQUFFLE9BQVk7UUFDN0QsSUFBSSxVQUFVLEdBQVEsS0FBSyxDQUFDLENBQUMsQ0FBQyxLQUFLLEtBQUssQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLEtBQUssQ0FBQztRQUN6RSxPQUFPLFVBQVUsQ0FBQyxPQUFPLElBQUksVUFBVSxDQUFDLEtBQUssQ0FBQyxJQUFJLEtBQUssRUFBRSxDQUFDO0lBQzlELENBQUM7SUFFTSwrQ0FBeUIsR0FBaEMsVUFBaUMsR0FBVztRQUN4QyxJQUFJLGNBQWMsR0FBWSxRQUFRLENBQUMsYUFBYSxDQUFDLEdBQUcsR0FBRyxHQUFHLEdBQUcsa0NBQWtDLENBQUMsQ0FBQztRQUNyRyxJQUFJLFVBQVUsR0FBUSxJQUFJLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxLQUFLLENBQUM7UUFFL0UsZ0NBQWdDO1FBQ2hDLElBQUksVUFBVSxDQUFDLE9BQU8sSUFBSSxVQUFVLENBQUMsS0FBSyxDQUFDLElBQUksS0FBSyxFQUFFLEVBQUU7WUFDcEQsSUFBSSxrQkFBa0IsR0FBVyxJQUFJLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQywwQkFBMEIsQ0FBQyxDQUFDLENBQUMsMEJBQTBCLENBQUM7WUFDMUcsSUFBSSxDQUFDLGtCQUFrQixHQUFHLFFBQVEsQ0FBQyxhQUFhLENBQUMsR0FBRyxHQUFHLEdBQUcsR0FBRyxjQUFjLEdBQUcsa0JBQWtCLEdBQUcsd0JBQXdCLENBQUMsQ0FBQztTQUNoSTthQUFNO1lBQ0gsSUFBSSxDQUFDLGtCQUFrQixHQUFHLElBQUksQ0FBQztTQUNsQztRQUVELElBQUksQ0FBQyx1QkFBdUIsQ0FBQyxjQUFjLENBQUMsQ0FBQztJQUNqRCxDQUFDO0lBRU0saURBQTJCLEdBQWxDO1FBQUEsaUJBU0M7UUFSRyxJQUFJLENBQUMsSUFBSSxDQUFDLFlBQVksQ0FBQyxJQUFJLENBQUMsa0JBQWtCLENBQUM7WUFBRSxPQUFPO1FBRXhELElBQUksY0FBYyxHQUFXLElBQUksQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLDBCQUEwQixDQUFDLENBQUMsQ0FBQywwQkFBMEIsQ0FBQztRQUN0RyxJQUFJLGdCQUFnQixHQUFRLFFBQVEsQ0FBQyxnQkFBZ0IsQ0FBQyxHQUFHLEdBQUcsSUFBSSxDQUFDLE9BQU8sQ0FBQyxFQUFFLEdBQUcsY0FBYyxHQUFHLGNBQWMsR0FBRyw4QkFBOEIsQ0FBQyxDQUFDO1FBQ2hKLGdCQUFnQixDQUFDLE9BQU8sQ0FBQyxVQUFBLGFBQWE7WUFDbEMsYUFBYSxDQUFDLEtBQUssQ0FBQyxHQUFHLEdBQUcsS0FBSSxDQUFDLGtCQUFrQixDQUFDLHFCQUFxQixFQUFFLENBQUMsTUFBTSxHQUFHLENBQUMsR0FBRyxhQUFhLENBQUMscUJBQXFCLEVBQUUsQ0FBQyxNQUFNLEdBQUcsQ0FBQyxHQUFHLElBQUksQ0FBQztZQUMvSSxhQUFhLENBQUMsS0FBSyxDQUFDLFVBQVUsR0FBRyxPQUFPLENBQUM7UUFDN0MsQ0FBQyxDQUFDLENBQUM7SUFDUCxDQUFDO0lBRUQsb0ZBQW9GO0lBRTdFLGtDQUFZLEdBQW5CLFVBQW9CLFlBQTBCLEVBQUUsVUFBd0I7UUFDcEUsSUFBSSxRQUFRLEdBQVcsSUFBSSxDQUFDLFlBQVksQ0FBQyxZQUFZLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLFlBQVksQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLFVBQVUsQ0FBQyxHQUFHLENBQUM7UUFDekcsSUFBSSxRQUFRLEdBQVcsSUFBSSxDQUFDLFlBQVksQ0FBQyxZQUFZLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLFlBQVksQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLFVBQVUsQ0FBQyxHQUFHLENBQUM7UUFFekcsd0RBQXdEO1FBQ3hELFFBQVEsR0FBRyxJQUFJLENBQUMsR0FBRyxDQUFDLFFBQVEsRUFBRSxRQUFRLENBQUMsQ0FBQztRQUN4QyxRQUFRLEdBQUcsSUFBSSxDQUFDLEdBQUcsQ0FBQyxRQUFRLEVBQUUsUUFBUSxDQUFDLENBQUM7UUFFeEMsSUFBSSxRQUFRLEdBQVcsRUFBRSxDQUFDLEdBQUcsQ0FBQyxDQUFDLFlBQVksQ0FBQyxZQUFZLEVBQUUsWUFBWSxDQUFDLGlCQUFpQixDQUFDLENBQUMsQ0FBQztRQUUzRixJQUFJLENBQUMsUUFBUSxJQUFJLFFBQVEsSUFBSSxDQUFDO1lBQUUsUUFBUSxHQUFHLENBQUMsQ0FBQztRQUU3QywrR0FBK0c7UUFDL0csSUFBSSx3QkFBd0IsR0FBVyxDQUFDLFFBQVEsR0FBRyxRQUFRLENBQUMsR0FBRyxJQUFJLENBQUM7UUFDcEUsSUFBSSx3QkFBd0IsR0FBRyxRQUFRLEVBQUU7WUFDckMsUUFBUSxHQUFHLElBQUksQ0FBQyxVQUFVLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsd0JBQXdCLENBQUMsQ0FBQyxDQUFDLENBQUMsd0JBQXdCLENBQUM7U0FDMUc7UUFFRCxPQUFPO1lBQ0gsUUFBUSxFQUFFLFFBQVE7WUFDbEIsUUFBUSxFQUFFLFFBQVE7WUFDbEIsUUFBUSxFQUFFLFFBQVE7U0FDckIsQ0FBQztJQUNOLENBQUM7SUFFTSxxQ0FBZSxHQUF0QixVQUF1QixTQUFpQjtRQUNwQyxJQUFJLFlBQVksR0FBVyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsU0FBUyxDQUFDLENBQUM7UUFDNUQsSUFBSSxDQUFDLGFBQWEsR0FBRyxJQUFJLENBQUMsV0FBVyxDQUFDLFNBQVMsRUFBRSxZQUFZLENBQUMsQ0FBQztJQUNuRSxDQUFDO0lBRU0sdUNBQWlCLEdBQXhCLFVBQXlCLFlBQTBCLEVBQUUsTUFBYztRQUMvRCxPQUFPLElBQUksQ0FBQyxZQUFZLENBQUMsWUFBWSxDQUFDLE1BQU0sQ0FBQyxNQUFNLEVBQUUsTUFBTSxFQUFFLEtBQUssRUFBRSxJQUFJLENBQUMsYUFBYSxDQUFDLENBQUM7SUFDNUYsQ0FBQztJQUVEOzs7OztPQUtHO0lBQ0ksdUNBQWlCLEdBQXhCLFVBQXlCLE1BQWMsRUFBRSxNQUFjO1FBQ25ELDZDQUE2QztRQUU3QyxJQUFJLFdBQVcsR0FBaUIsSUFBSSxDQUFDLE9BQU8sQ0FBQyxLQUFLLENBQUM7UUFFbkQsMEZBQTBGO1FBQzFGLElBQUksYUFBYSxHQUFRLElBQUksQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLFNBQVMsR0FBRyxNQUFNLENBQUMsQ0FBQztRQUNqRSxJQUFJLElBQUksR0FBVyxJQUFJLENBQUMsaUJBQWlCLENBQUMsV0FBVyxFQUFFLE1BQU0sQ0FBQyxDQUFDO1FBRS9ELHVDQUF1QztRQUN2QyxJQUFJLGFBQWEsQ0FBQyxLQUFLLEVBQUU7WUFBRSxhQUFhLEdBQUcsSUFBSSxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLENBQUM7UUFFcEUsSUFBSSxDQUFDLGVBQWUsQ0FBQyxhQUFhLEVBQUUsTUFBTSxDQUFDLE1BQU0sQ0FBQyxFQUFFLEVBQUUsV0FBVyxDQUFDLE1BQU0sQ0FBQyxLQUFLLEVBQUUsRUFBRSxLQUFLLEVBQUUseUJBQXlCLEdBQUcsTUFBTSxFQUFFLE9BQU8sRUFBRSxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUM7UUFFNUksYUFBYSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQztRQUV6QixPQUFPLGFBQWEsQ0FBQyxJQUFJLEVBQUUsQ0FBQyxPQUFPLEVBQUUsQ0FBQyxLQUFLLENBQUM7SUFDaEQsQ0FBQztJQUVEOzs7Ozs7T0FNRztJQUNJLGtDQUFZLEdBQW5CLFVBQW9CLEtBQWdCLEVBQUUsUUFBMEI7UUFDNUQsSUFBSSxZQUFZLEdBQVksS0FBSyxLQUFLLEdBQUcsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxLQUFLLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLEtBQUssQ0FBQyxRQUFRLENBQUM7UUFDdEcsSUFBSSxRQUFRLEdBQVksWUFBWSxLQUFLLElBQUksQ0FBQyxNQUFNLENBQUM7UUFDckQsSUFBSSxxQkFBcUIsR0FBWSxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsS0FBSyxDQUFDLE9BQU8sSUFBSSxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxPQUFPLENBQUM7UUFFdkcsSUFBSSxLQUFLLEtBQUssR0FBRztZQUFFLElBQUksQ0FBQyxnQkFBZ0IsR0FBRyxJQUFJLENBQUMsMkJBQTJCLENBQUMsUUFBUSxDQUFDLENBQUM7UUFFdEYsSUFBSSx1QkFBdUIsR0FBeUMsSUFBSSxDQUFDLGdCQUFnQixDQUFDO1FBQzFGLElBQUkscUJBQXFCO1lBQUUsdUJBQXVCLEdBQUcsRUFBRSxPQUFPLEVBQUUsQ0FBQyxFQUFFLE9BQU8sRUFBRSxDQUFDLEVBQUUsQ0FBQztRQUVoRixJQUFJLENBQUMsSUFBSSxDQUFDLFNBQVMsRUFBRTtZQUNqQixJQUFJLEtBQUssS0FBSyxHQUFHLEVBQUU7Z0JBQ2YsSUFBSSxLQUFLLEdBQXFCLFFBQVEsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUM7Z0JBQzFELElBQUksR0FBRyxHQUFxQixRQUFRLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDO2dCQUN4RCxJQUFJLENBQUMsVUFBVSxDQUFDLEtBQUssQ0FBQyxHQUFHLElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxDQUFDLEdBQUcsSUFBSSxDQUFDLEdBQUcsQ0FBQyx1QkFBdUIsQ0FBQyxPQUFPLEVBQUUsdUJBQXVCLENBQUMsT0FBTyxDQUFDLENBQUM7Z0JBQy9ILElBQUksQ0FBQyxVQUFVLENBQUMsR0FBRyxDQUFDLEdBQUcsSUFBSSxDQUFDLGlCQUFpQixDQUFDLE9BQU8sQ0FBQztnQkFDdEQsT0FBTyxJQUFJLENBQUMsUUFBUSxDQUFDLEtBQUssR0FBRyxJQUFJLENBQUMsVUFBVSxDQUFDLEtBQUssQ0FBQyxHQUFHLElBQUksQ0FBQyxVQUFVLENBQUMsR0FBRyxDQUFDLENBQUM7YUFDOUU7aUJBQU07Z0JBQ0gsSUFBSSxLQUFLLEdBQXFCLFlBQVksQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUM7Z0JBQzlELElBQUksR0FBRyxHQUFxQixZQUFZLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDO2dCQUM1RCxJQUFJLGFBQWEsR0FBVyxxQkFBcUIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsdUJBQXVCLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxRQUFRLENBQUMsQ0FBQztnQkFDL0gsSUFBSSxDQUFDLFVBQVUsQ0FBQyxHQUFHLENBQUMsR0FBRyxJQUFJLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxDQUFDLEVBQUUsR0FBRyxHQUFHLGFBQWEsQ0FBQyxDQUFDO2dCQUMvRSxJQUFJLENBQUMsVUFBVSxDQUFDLEtBQUssQ0FBQyxHQUFHLElBQUksQ0FBQyxlQUFlLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxHQUFHLENBQUM7Z0JBQ2xHLE9BQU8sSUFBSSxDQUFDLFFBQVEsQ0FBQyxNQUFNLEdBQUcsSUFBSSxDQUFDLFVBQVUsQ0FBQyxLQUFLLENBQUMsR0FBRyxJQUFJLENBQUMsVUFBVSxDQUFDLEdBQUcsQ0FBQyxDQUFDO2FBQy9FO1NBQ0o7YUFBTTtZQUNILElBQUksS0FBSyxLQUFLLEdBQUcsRUFBRTtnQkFDZixJQUFJLEtBQUssR0FBcUIsWUFBWSxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQztnQkFDOUQsSUFBSSxHQUFHLEdBQXFCLFlBQVksQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUM7Z0JBQzVELElBQUksYUFBYSxHQUFXLHFCQUFxQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyx1QkFBdUIsQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLFFBQVEsQ0FBQyxDQUFDO2dCQUMvSCxJQUFJLENBQUMsVUFBVSxDQUFDLEtBQUssQ0FBQyxHQUFHLElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxHQUFHLENBQUM7Z0JBQ3BELElBQUksQ0FBQyxVQUFVLENBQUMsR0FBRyxDQUFDLEdBQUcsSUFBSSxDQUFDLGlCQUFpQixDQUFDLENBQUMsR0FBRyxhQUFhLENBQUM7Z0JBQ2hFLE9BQU8sSUFBSSxDQUFDLFFBQVEsQ0FBQyxNQUFNLEdBQUcsSUFBSSxDQUFDLFVBQVUsQ0FBQyxLQUFLLENBQUMsR0FBRyxJQUFJLENBQUMsVUFBVSxDQUFDLEdBQUcsQ0FBQyxDQUFDO2FBQy9FO2lCQUFNO2dCQUNILElBQUksS0FBSyxHQUFxQixRQUFRLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDO2dCQUMxRCxJQUFJLEdBQUcsR0FBcUIsUUFBUSxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQztnQkFDeEQsSUFBSSxlQUFlLEdBQVcsUUFBUSxLQUFLLElBQUksQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDLHVCQUF1QixDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsdUJBQXVCLENBQUMsT0FBTyxDQUFDO2dCQUNoSSxJQUFJLGFBQWEsR0FBVyxRQUFRLEtBQUssSUFBSSxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUMsdUJBQXVCLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyx1QkFBdUIsQ0FBQyxPQUFPLENBQUM7Z0JBQzlILElBQUksQ0FBQyxVQUFVLENBQUMsS0FBSyxDQUFDLEdBQUcsSUFBSSxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsaUJBQWlCLENBQUMsQ0FBQyxFQUFFLGVBQWUsR0FBRyxDQUFDLENBQUMsQ0FBQztnQkFDakYsSUFBSSxDQUFDLFVBQVUsQ0FBQyxHQUFHLENBQUMsR0FBRyxJQUFJLENBQUMsZUFBZSxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxDQUFDLEVBQUUsYUFBYSxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxhQUFhLEdBQUcsQ0FBQyxHQUFHLElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxPQUFPLENBQUM7Z0JBQ3pKLE9BQU8sSUFBSSxDQUFDLFFBQVEsQ0FBQyxLQUFLLEdBQUcsSUFBSSxDQUFDLFVBQVUsQ0FBQyxLQUFLLENBQUMsR0FBRyxJQUFJLENBQUMsVUFBVSxDQUFDLEdBQUcsQ0FBQyxDQUFDO2FBQzlFO1NBQ0o7SUFDTCxDQUFDO0lBRUQ7Ozs7Ozs7Ozs7T0FVRztJQUNJLHVDQUFpQixHQUF4QixVQUF5QixNQUFjLEVBQUUsU0FBaUIsRUFBRSwwQkFBbUMsRUFBRSxTQUF3QjtRQUNySCw2QkFBNkI7UUFDN0IsSUFBSSxNQUFNLEtBQUssQ0FBQztZQUFFLE9BQU8sTUFBTSxDQUFDO1FBRWhDLElBQUksYUFBYSxHQUFXLElBQUksQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLGdCQUFnQixDQUFDLE1BQU0sQ0FBQyxFQUFFLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDO1FBRXRHLElBQUksYUFBYSxLQUFLLENBQUMsRUFBRTtZQUNyQixxRUFBcUU7WUFDckUsTUFBTSxHQUFHLE1BQU0sR0FBRyxJQUFJLENBQUMsR0FBRyxDQUFDLEVBQUUsRUFBRSxhQUFhLENBQUMsQ0FBQztZQUM5QyxTQUFTLEdBQUcsU0FBUyxHQUFHLElBQUksQ0FBQyxHQUFHLENBQUMsRUFBRSxFQUFFLGFBQWEsQ0FBQyxDQUFDO1NBQ3ZEO1FBRUQsSUFBSSxJQUFJLEdBQVcsSUFBSSxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQztRQUNyQyxJQUFJLFFBQVEsR0FBVyxNQUFNLEdBQUcsTUFBTSxHQUFHLFNBQVMsQ0FBQztRQUVuRCxJQUFJLFNBQVMsS0FBSyxJQUFJLEVBQUU7WUFDcEIsSUFBSSxJQUFJLEdBQUcsQ0FBQyxFQUFFO2dCQUNWLElBQUksQ0FBQywwQkFBMEI7b0JBQUUsUUFBUSxHQUFHLFFBQVEsR0FBRyxTQUFTLENBQUM7YUFDcEU7aUJBQU07Z0JBQ0gsSUFBSSwwQkFBMEI7b0JBQUUsUUFBUSxHQUFHLFFBQVEsR0FBRyxTQUFTLENBQUM7YUFDbkU7U0FDSjthQUFNO1lBQ0gsSUFBSSxJQUFJLEdBQUcsQ0FBQyxFQUFFO2dCQUNWLElBQUksMEJBQTBCO29CQUFFLFFBQVEsR0FBRyxRQUFRLEdBQUcsU0FBUyxDQUFDO2FBQ25FO2lCQUFNO2dCQUNILElBQUksQ0FBQywwQkFBMEI7b0JBQUUsUUFBUSxHQUFHLFFBQVEsR0FBRyxTQUFTLENBQUM7YUFDcEU7U0FDSjtRQUVELElBQUksYUFBYSxLQUFLLENBQUM7WUFBRSxRQUFRLEdBQUcsUUFBUSxHQUFHLElBQUksQ0FBQyxHQUFHLENBQUMsRUFBRSxFQUFFLGFBQWEsQ0FBQyxDQUFDO1FBRTNFLE9BQU8sUUFBUSxDQUFDO0lBQ3BCLENBQUM7SUFFTSxtQ0FBYSxHQUFwQixVQUFxQixJQUFZLEVBQUUsSUFBWSxFQUFFLFNBQWlCO1FBQzlELElBQUksQ0FBQyxTQUFTLElBQUksT0FBTyxJQUFJLEtBQUssV0FBVyxJQUFJLE9BQU8sSUFBSSxLQUFLLFdBQVc7WUFBRSxPQUFPLEVBQUUsQ0FBQztRQUV4RixJQUFJLEdBQUcsSUFBSSxDQUFDLDJCQUEyQixDQUFDLElBQUksRUFBRSxTQUFTLENBQUMsQ0FBQztRQUV6RCxPQUFPLEVBQUUsQ0FBQyxLQUFLLENBQUMsSUFBSSxFQUFFLElBQUksRUFBRSxTQUFTLENBQUMsQ0FBQztJQUMzQyxDQUFDO0lBRUQ7Ozs7T0FJRztJQUNJLHdDQUFrQixHQUF6QixVQUEwQixLQUFVLEVBQUUsVUFBcUI7UUFDdkQsSUFBSSxPQUFPLEdBQVcsVUFBVSxHQUFHLE1BQU0sQ0FBQztRQUMxQyxJQUFJLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxPQUFPLENBQUM7WUFBRSxPQUFPO1FBQ25DLElBQUksVUFBVSxHQUFHLElBQUksQ0FBQyxPQUFPLENBQUMsT0FBTyxDQUFDLENBQUM7UUFFdkMsS0FBSyxDQUFDLFNBQVMsQ0FBQyxNQUFNLENBQUM7YUFDbEIsSUFBSSxDQUFDLGNBQWMsRUFBRSxVQUFVLENBQUMsU0FBUyxDQUFDO2FBQzFDLElBQUksQ0FBQyxRQUFRLEVBQUUsVUFBVSxDQUFDLFNBQVMsQ0FBQyxDQUFDO1FBRTFDLEtBQUssQ0FBQyxTQUFTLENBQUMsTUFBTSxDQUFDO2FBQ2xCLElBQUksQ0FBQyxjQUFjLEVBQUUsVUFBVSxDQUFDLFNBQVMsQ0FBQzthQUMxQyxJQUFJLENBQUMsUUFBUSxFQUFFLFVBQVUsQ0FBQyxTQUFTLENBQUMsQ0FBQztRQUUxQyxJQUFJLFVBQVUsS0FBSyxHQUFHLElBQUksQ0FBQyxVQUFVLENBQUMsT0FBTyxJQUFJLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxPQUFPLENBQUMsQ0FBQyxNQUFNLENBQUMsT0FBTyxFQUFFO1lBQ3BGLElBQUksQ0FBQyxlQUFlLENBQUMsS0FBSyxDQUFDLFNBQVMsQ0FBQyxNQUFNLENBQUMsRUFBRSxFQUFFLE9BQU8sRUFBRSxNQUFNLEVBQUUsQ0FBQyxDQUFDO1NBQ3RFO2FBQU07WUFDSCxJQUFJLENBQUMsZUFBZSxDQUFDLEtBQUssQ0FBQyxTQUFTLENBQUMsTUFBTSxDQUFDLEVBQUUsVUFBVSxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsQ0FBQztZQUN2RSxJQUFJLENBQUMsZUFBZSxDQUFDLEtBQUssQ0FBQyxTQUFTLENBQUMsTUFBTSxDQUFDLEVBQUUsRUFBRSxLQUFLLEVBQUUsZ0VBQWdFLEVBQUUsQ0FBQyxDQUFDO1NBQzlIO0lBQ0wsQ0FBQztJQUVNLGlEQUEyQixHQUFsQyxVQUFtQyxRQUEwQjtRQUN6RCxJQUFJLFFBQVEsR0FBcUIsRUFBRSxPQUFPLEVBQUUsQ0FBQyxFQUFFLE9BQU8sRUFBRSxDQUFDLEVBQUUsQ0FBQztRQUU1RCwyQ0FBMkM7UUFDM0MsUUFBUSxDQUFDLE9BQU8sR0FBRyxJQUFJLENBQUMsaUJBQWlCLENBQUMsUUFBUSxDQUFDLE9BQU8sRUFBRSxTQUFTLENBQUMsQ0FBQztRQUN2RSxRQUFRLENBQUMsT0FBTyxHQUFHLElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxRQUFRLENBQUMsT0FBTyxFQUFFLFNBQVMsQ0FBQyxDQUFDO1FBQ3ZFLElBQUk7UUFFSixPQUFPLFFBQVEsQ0FBQztJQUNwQixDQUFDO0lBRU8saURBQTJCLEdBQW5DLFVBQW9DLElBQVksRUFBRSxTQUFpQjtRQUMvRCxJQUFJLGFBQWEsR0FBVyxJQUFJLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxJQUFJLENBQUMsRUFBRSxJQUFJLENBQUMsZ0JBQWdCLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQztRQUVwRyxJQUFJLEdBQUcsSUFBSSxHQUFHLElBQUksQ0FBQyxHQUFHLENBQUMsRUFBRSxFQUFFLGFBQWEsQ0FBQyxDQUFDO1FBQzFDLFNBQVMsR0FBRyxTQUFTLEdBQUcsSUFBSSxDQUFDLEdBQUcsQ0FBQyxFQUFFLEVBQUUsYUFBYSxDQUFDLENBQUM7UUFFcEQsT0FBTyxDQUFDLElBQUksR0FBRyxTQUFTLENBQUMsR0FBRyxJQUFJLENBQUMsR0FBRyxDQUFDLEVBQUUsRUFBRSxhQUFhLENBQUMsQ0FBQztJQUM1RCxDQUFDO0lBRUQsb0ZBQW9GO0lBRXBGOzs7OztPQUtHO0lBQ0ksMkNBQXFCLEdBQTVCLFVBQTZCLGVBQTRCO1FBQTVCLGdDQUFBLEVBQUEsb0JBQTRCO1FBQ3JELElBQUksQ0FBQyxtQkFBbUIsR0FBRyxFQUFFLENBQUMsTUFBTSxDQUFDLEdBQUcsR0FBRyxJQUFJLENBQUMsT0FBTyxDQUFDLEVBQUUsR0FBRyw4Q0FBOEMsR0FBRyxlQUFlLENBQUMsQ0FBQztRQUMvSCxJQUFJLENBQUMsSUFBSSxDQUFDLFlBQVksQ0FBQyxJQUFJLENBQUMsbUJBQW1CLENBQUMsSUFBSSxFQUFFLENBQUM7WUFBRSxPQUFPO1FBRWhFLE9BQU8sSUFBSSxDQUFDLG1CQUFtQixDQUFDO0lBQ3BDLENBQUM7SUFFRCwrQkFBK0I7SUFFeEIsdUNBQWlCLEdBQXhCLFVBQXlCLEdBQVcsRUFBRSxTQUFpQixFQUFFLFlBQW9CO1FBQ3pFLElBQUksQ0FBQyx5QkFBeUIsQ0FBQyxHQUFHLENBQUMsQ0FBQztRQUNwQyxJQUFJLENBQUMscUJBQXFCLENBQUMsWUFBWSxDQUFDLENBQUM7UUFDekMsSUFBSSxDQUFDLFFBQVEsR0FBRyxJQUFJLENBQUMsWUFBWSxDQUFDLElBQUksQ0FBQyxTQUFTLEVBQUUsU0FBUyxFQUFFLElBQUksQ0FBQyxZQUFZLENBQUMsQ0FBQztRQUNoRixJQUFJLENBQUMsdUJBQXVCLENBQUMsU0FBUyxDQUFDLENBQUM7SUFDNUMsQ0FBQztJQUVNLDJDQUFxQixHQUE1QixVQUE2QixZQUFvQjtRQUM3QyxJQUFJLENBQUMsSUFBSSxDQUFDLGVBQWU7WUFBRSxPQUFPO1FBQ2xDLFlBQVksR0FBRyxJQUFJLENBQUMscUJBQXFCLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLE1BQU0sRUFBRSxZQUFZLENBQUMsQ0FBQztRQUN6RixJQUFJLENBQUMsc0JBQXNCLENBQUMsWUFBWSxDQUFDLENBQUM7SUFDOUMsQ0FBQztJQUVNLDJDQUFxQixHQUE1QjtRQUNJLElBQUksQ0FBQyxJQUFJLENBQUMsZUFBZTtZQUFFLE9BQU8sQ0FBQyxDQUFDO1FBQ3BDLE9BQU8sSUFBSSxDQUFDLGVBQWUsQ0FBQyxxQkFBcUIsRUFBRSxDQUFDO0lBQ3hELENBQUM7SUFFTywrQ0FBeUIsR0FBakMsVUFBa0MsR0FBVztRQUN6QyxJQUFJLE9BQU8sSUFBSSxDQUFDLGVBQWUsS0FBSyxXQUFXLEVBQUU7WUFDN0MsSUFBSSxDQUFDLGVBQWUsR0FBRyxRQUFRLENBQUMsYUFBYSxDQUFDLEdBQUcsR0FBRyxHQUFHLEdBQUcsOENBQThDLENBQUMsQ0FBQztTQUM3RztJQUNMLENBQUM7SUFFTyw0Q0FBc0IsR0FBOUIsVUFBK0IsS0FBYTtRQUN4QyxJQUFJLENBQUMsSUFBSSxDQUFDLGVBQWU7WUFBRSxPQUFPO1FBQ2xDLElBQUksQ0FBQyxlQUFlLENBQUMsU0FBUyxHQUFHLEtBQUssQ0FBQztJQUMzQyxDQUFDO0lBRU8sNkNBQXVCLEdBQS9CLFVBQWdDLFNBQWlCO1FBQzdDLElBQUksQ0FBQyxJQUFJLENBQUMsU0FBUyxJQUFJLENBQUMsSUFBSSxDQUFDLFFBQVEsRUFBRTtZQUNuQyxJQUFJLENBQUMsZUFBZSxDQUFDLEtBQUssQ0FBQyxRQUFRLEdBQUcsU0FBUyxHQUFHLElBQUksQ0FBQztTQUMxRDtJQUNMLENBQUM7SUFFRCxxQkFBcUI7SUFFYixrQ0FBWSxHQUFwQixVQUFxQixTQUFrQixFQUFFLFNBQWlCLEVBQUUsWUFBb0I7UUFDNUUsa0ZBQWtGO1FBQ2xGLElBQUksU0FBUyxJQUFJLFlBQVksSUFBSSxTQUFTO1lBQUUsT0FBTyxLQUFLLENBQUM7UUFDekQsK0ZBQStGO1FBQy9GLE9BQU8sSUFBSSxDQUFDLHFCQUFxQixFQUFFLENBQUMsS0FBSyxHQUFHLFNBQVMsQ0FBQztJQUMxRCxDQUFDO0lBRU0seUNBQW1CLEdBQTFCO1FBQ0ksSUFBSSxhQUFhLEdBQVcsSUFBSSxDQUFDLHFCQUFxQixFQUFFLENBQUMsS0FBSyxJQUFJLENBQUMsRUFDL0QsYUFBYSxHQUFRLElBQUksQ0FBQyxjQUFjLEVBQ3hDLFNBQVMsR0FBVyxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLGFBQWEsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLGFBQWEsQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLEVBQ3RGLFdBQVcsR0FBVyxJQUFJLENBQUMsR0FBRyxDQUFDLGFBQWEsRUFBRSxHQUFHLEdBQUcsU0FBUyxDQUFDLENBQUM7UUFFbkUsSUFBSSxDQUFDLFlBQVksR0FBRyxXQUFXLENBQUM7SUFDcEMsQ0FBQztJQUVPLG9DQUFjLEdBQXRCLFVBQXVCLFNBQWtCLEVBQUUsU0FBa0I7UUFDekQsSUFBSSxVQUFVLEdBQWtELEVBQUUsR0FBRyxFQUFFLENBQUMsRUFBRSxJQUFJLEVBQUUsQ0FBQyxFQUFFLEtBQUssRUFBRSxDQUFDLEVBQUUsQ0FBQztRQUM5RixJQUFJLFFBQVEsR0FBWSxJQUFJLENBQUMsT0FBTyxDQUFDLEtBQUssQ0FBQyxRQUFRLElBQUksS0FBSyxDQUFDO1FBRTdELElBQUksQ0FBQyxTQUFTLEVBQUU7WUFDWixJQUFJLFVBQVUsR0FBVyxDQUFDLENBQUM7WUFDM0IsSUFBSSxJQUFJLEdBQXFCLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDO1lBQzVELElBQUksSUFBSSxHQUFXLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7WUFDeEMsUUFBUSxHQUFHLFFBQVEsS0FBSyxJQUFJLENBQUMsTUFBTSxDQUFDO1lBRXBDLElBQUksQ0FBQyxRQUFRLElBQUksSUFBSSxDQUFDLFlBQVksQ0FBQyxJQUFJLENBQUMsa0JBQWtCLENBQUMsRUFBRTtnQkFDekQsVUFBVSxHQUFHLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxxQkFBcUIsRUFBRSxDQUFDLEtBQUssQ0FBQzthQUN0RTtZQUVELFVBQVUsQ0FBQyxJQUFJLENBQUMsR0FBRyxJQUFJLEdBQUcsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLElBQUksR0FBRyxVQUFVLENBQUMsQ0FBQztTQUNqRTthQUFNO1lBQ0gsVUFBVSxDQUFDLEdBQUcsR0FBRyxJQUFJLENBQUMsVUFBVSxDQUFDLEdBQUcsQ0FBQztZQUNyQyxJQUFJLFFBQVE7Z0JBQUUsVUFBVSxDQUFDLEdBQUcsSUFBSSxJQUFJLENBQUMsb0JBQW9CLEVBQUUsQ0FBQztZQUU1RCxVQUFVLENBQUMsS0FBSyxHQUFHLENBQUMsQ0FBQztTQUN4QjtRQUNELE9BQU8sVUFBVSxDQUFDO0lBQ3RCLENBQUM7SUFFTSxnREFBMEIsR0FBakMsVUFBa0MsVUFBZTtRQUM3QyxJQUFJLFNBQVMsR0FBdUIsSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUM7UUFDeEUsSUFBSSxRQUFRLEdBQVcsSUFBSSxDQUFDLFdBQVcsQ0FBQztRQUV4QyxJQUFJLENBQUMsSUFBSSxDQUFDLFNBQVMsSUFBSSxDQUFDLElBQUksQ0FBQyxRQUFRLEVBQUU7WUFDbkMsUUFBUSxHQUFHLElBQUksQ0FBQyxxQkFBcUIsRUFBRSxDQUFDLE1BQU0sQ0FBQztTQUNsRDtRQUVELFVBQVUsQ0FBQyxLQUFLLENBQUMsU0FBUyxFQUFFLFFBQVEsR0FBRyxJQUFJLENBQUMsQ0FBQztRQUM3QyxJQUFJLENBQUMsSUFBSSxDQUFDLFNBQVM7WUFBRSxVQUFVLENBQUMsS0FBSyxDQUFDLE9BQU8sRUFBRSxNQUFNLENBQUMsQ0FBQztRQUV2RCxJQUFJLENBQUMsZUFBZSxDQUFDLEtBQUssQ0FBQyxRQUFRLEdBQUcsTUFBTSxDQUFDO1FBRzdDLElBQUksTUFBTSxHQUFrRCxJQUFJLENBQUMsY0FBYyxDQUFDLElBQUksQ0FBQyxTQUFTLEVBQUUsSUFBSSxDQUFDLFFBQVEsQ0FBQyxDQUFDO1FBRS9HLFVBQVU7YUFDTCxLQUFLLENBQUMsWUFBWSxFQUFFLE1BQU0sQ0FBQyxHQUFHLEdBQUcsSUFBSSxDQUFDO2FBQ3RDLEtBQUssQ0FBQyxjQUFjLEVBQUUsTUFBTSxDQUFDLEtBQUssR0FBRyxJQUFJLENBQUM7YUFDMUMsS0FBSyxDQUFDLGFBQWEsRUFBRSxNQUFNLENBQUMsSUFBSSxHQUFHLElBQUksQ0FBQyxDQUFDO1FBRTlDLElBQUksQ0FBQyw2QkFBNkIsR0FBRyxNQUFNLENBQUMsSUFBSSxDQUFDO0lBQ3JELENBQUM7SUFFRDs7Ozs7T0FLRztJQUNJLDBDQUFvQixHQUEzQixVQUE0QixlQUFvQixFQUFFLFFBQWdCLEVBQUUsY0FBdUM7UUFDdkcsSUFBSSxJQUFJLENBQUMsU0FBUyxJQUFJLGNBQWMsQ0FBQyxRQUFRLElBQUksQ0FBQyxjQUFjLENBQUMsTUFBTSxJQUFJLElBQUksQ0FBQyxXQUFXLEtBQUssUUFBUSxDQUFDLEVBQUU7WUFDdkcsSUFBSSxDQUFDLE9BQU8sQ0FBQyxRQUFRLENBQUMsZUFBZSxDQUFDLElBQUksRUFBRSxFQUFFLFVBQVUsQ0FBQyxDQUFDO1NBQzdEO1FBRUQseUlBQXlJO1FBQ3pJLHNDQUFzQztRQUN0QyxJQUFJLGNBQWMsQ0FBQyxRQUFRO1lBQUUsZUFBZSxDQUFDLEtBQUssQ0FBQyxTQUFTLEVBQUUsQ0FBQyxDQUFDLENBQUM7UUFFakUsSUFBSSxTQUFTLEdBQVEsZUFBZSxDQUFDLElBQUksRUFBRSxDQUFDLHFCQUFxQixFQUFFLEVBQy9ELE1BQU0sR0FBVyxDQUFDLElBQUksQ0FBQyxTQUFTLElBQUksQ0FBQyxjQUFjLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUMsS0FBSyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDLE1BQU0sR0FBRyxDQUFDLEVBQ3pHLFVBQVUsR0FBVyxjQUFjLENBQUMsUUFBUSxJQUFJLGNBQWMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQ2hGLFFBQVEsR0FBVyxRQUFRLEdBQUcsTUFBTSxHQUFHLFVBQVUsQ0FBQztRQUV0RCxxQkFBcUI7UUFDckIsSUFBSSxJQUFJLENBQUMsU0FBUyxFQUFFO1lBQ2hCLElBQUksUUFBUSxHQUFXLElBQUksQ0FBQyxNQUFNLEtBQUssY0FBYyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUM7WUFDbEYsZUFBZTtpQkFDVixLQUFLLENBQUMsS0FBSyxFQUFFLFFBQVEsR0FBRyxJQUFJLENBQUM7aUJBQzdCLEtBQUssQ0FBQyxRQUFRLEVBQUUsQ0FBQyxHQUFHLElBQUksQ0FBQyxDQUFDO1lBQy9CLE9BQU87U0FDVjtRQUVELElBQUksT0FBTyxHQUFXLGNBQWMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDO1FBRWpFLDRCQUE0QjtRQUM1QixJQUFJLGNBQWMsQ0FBQyxRQUFRLEVBQUU7WUFDekIsSUFBSSxRQUFRLEdBQVcsY0FBYyxDQUFDLFFBQVEsSUFBSSxDQUFDLGNBQWMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztZQUVqRyxlQUFlO2lCQUNWLEtBQUssQ0FBQyxPQUFPLEVBQUUsUUFBUSxHQUFHLElBQUksQ0FBQztpQkFDL0IsS0FBSyxDQUFDLFdBQVcsRUFBRSxnQkFBZ0IsQ0FBQyxDQUFDO1NBRTdDO2FBQU07WUFDSCxJQUFJLElBQUksQ0FBQyxXQUFXLEtBQUssUUFBUSxFQUFFO2dCQUMvQixrR0FBa0c7Z0JBQ2xHLElBQUksUUFBUSxHQUFHLElBQUksQ0FBQyw2QkFBNkIsR0FBRyxDQUFDLEVBQUU7b0JBQ25ELElBQUksSUFBSSxHQUFXLElBQUksQ0FBQyxHQUFHLENBQUMsUUFBUSxDQUFDLEdBQUcsSUFBSSxDQUFDLDZCQUE2QixDQUFDO29CQUMzRSxlQUFlLENBQUMsS0FBSyxDQUFDLFdBQVcsRUFBRSxDQUFDLFNBQVMsQ0FBQyxLQUFLLEdBQUcsQ0FBQyxHQUFHLElBQUksQ0FBQyxHQUFHLElBQUksQ0FBQyxDQUFDO29CQUN4RSxRQUFRLEdBQUcsQ0FBQyxDQUFDLEdBQUcsSUFBSSxDQUFDLDZCQUE2QixDQUFDO2lCQUN0RDtnQkFDRCxJQUFJLGNBQWMsQ0FBQyxNQUFNO29CQUFFLGVBQWUsQ0FBQyxLQUFLLENBQUMsV0FBVyxFQUFFLENBQUMsU0FBUyxDQUFDLEtBQUssR0FBRyxDQUFDLEdBQUcsSUFBSSxDQUFDLFVBQVUsQ0FBQyxLQUFLLENBQUMsR0FBRyxJQUFJLENBQUMsQ0FBQzthQUN2SDtZQUVELGVBQWUsQ0FBQyxLQUFLLENBQUMsT0FBTyxFQUFFLENBQUMsR0FBRyxJQUFJLENBQUMsQ0FBQztTQUM1QztRQUVELGVBQWUsQ0FBQyxLQUFLLENBQUMsTUFBTSxFQUFFLFFBQVEsR0FBRyxJQUFJLENBQUMsQ0FBQztJQUNuRCxDQUFDO0lBRUQsbUZBQW1GO0lBRW5GOzs7O09BSUc7SUFDSSx5Q0FBbUIsR0FBMUIsVUFBMkIsbUJBQXdCLEVBQUUsbUJBQXlCO1FBQzFFLElBQUksc0JBQXNCLEdBQUcsSUFBSSxDQUFDLFlBQVksQ0FBQyxtQkFBbUIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxtQkFBbUIsQ0FBQyxJQUFJLEVBQUUsQ0FBQyxxQkFBcUIsRUFBRSxDQUFDLENBQUMsQ0FBQyxFQUFFLEtBQUssRUFBRSxDQUFDLEVBQUUsTUFBTSxFQUFFLENBQUMsRUFBRSxDQUFDO1FBRW5KLElBQUksSUFBSSxHQUFXLElBQUksQ0FBQyx1QkFBdUIsQ0FBQyxzQkFBc0IsQ0FBQyxLQUFLLENBQUMsQ0FBQztRQUM5RSxJQUFJLEdBQUcsR0FBVyxJQUFJLENBQUMsc0JBQXNCLENBQUMsc0JBQXNCLENBQUMsTUFBTSxDQUFDLENBQUM7UUFFN0UsbUJBQW1CO2FBQ2QsS0FBSyxDQUFDLE1BQU0sRUFBRSxJQUFJLEdBQUcsSUFBSSxDQUFDO2FBQzFCLEtBQUssQ0FBQyxLQUFLLEVBQUUsR0FBRyxHQUFHLElBQUksQ0FBQyxDQUFDO0lBQ2xDLENBQUM7SUFFTyw2Q0FBdUIsR0FBL0IsVUFBZ0MsV0FBVztRQUN2QyxJQUFJLFFBQVEsR0FBWSxJQUFJLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLEtBQUssQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsS0FBSyxDQUFDLFFBQVEsQ0FBQztRQUNuRyxJQUFJLGVBQWUsR0FBVyxJQUFJLENBQUMsT0FBTyxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDO1FBRTdELHNFQUFzRTtRQUN0RSwrR0FBK0c7UUFDL0csSUFBSSxRQUFRLEtBQUssSUFBSSxDQUFDLE1BQU0sSUFBSSxDQUFDLElBQUksQ0FBQyxlQUFlLEVBQUU7WUFDbkQsT0FBTyxJQUFJLENBQUMsVUFBVSxDQUFDLElBQUksR0FBRyxJQUFJLENBQUMsdUJBQXVCLENBQUMsZUFBZSxDQUFDLENBQUM7U0FDL0U7UUFFRCw2QkFBNkI7UUFDN0IsSUFBSSxVQUFVLEdBQVcsSUFBSSxDQUFDLFlBQVksQ0FBQyxJQUFJLENBQUMsa0JBQWtCLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLGtCQUFrQixDQUFDLHFCQUFxQixFQUFFLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7UUFDaEksSUFBSSxJQUFJLEdBQVcsSUFBSSxDQUFDLHVCQUF1QixDQUFDLGVBQWUsQ0FBQyxDQUFDO1FBRWpFLElBQUksSUFBSSxJQUFJLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxVQUFVLEdBQUcsV0FBVyxHQUFHLElBQUksQ0FBQyxVQUFVLENBQUMsSUFBSSxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsVUFBVSxHQUFHLElBQUksQ0FBQyxVQUFVLENBQUMsSUFBSSxDQUFDO1FBRWpILE9BQU8sSUFBSSxDQUFDO0lBQ2hCLENBQUM7SUFFTyw0Q0FBc0IsR0FBOUIsVUFBK0IsWUFBWTtRQUN2QyxJQUFJLFFBQVEsR0FBWSxJQUFJLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLEtBQUssQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsS0FBSyxDQUFDLFFBQVEsQ0FBQztRQUVuRyxvQ0FBb0M7UUFDcEMsNkdBQTZHO1FBQzdHLElBQUksQ0FBQyxRQUFRLElBQUksQ0FBQyxJQUFJLENBQUMsZUFBZSxFQUFFO1lBQ3BDLE9BQU8sSUFBSSxDQUFDLFVBQVUsQ0FBQyxHQUFHLEdBQUcsSUFBSSxDQUFDLHVCQUF1QixDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsQ0FBQztTQUM1RjtRQUVELDhCQUE4QjtRQUM5QixJQUFJLGdCQUFnQixHQUFXLElBQUksQ0FBQyxvQkFBb0IsRUFBRSxDQUFDO1FBQzNELElBQUksR0FBRyxHQUFXLElBQUksQ0FBQyx1QkFBdUIsQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLENBQUM7UUFFOUUsR0FBRyxJQUFJLElBQUksQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLGdCQUFnQixHQUFHLElBQUksQ0FBQyxVQUFVLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxnQkFBZ0IsR0FBRyxJQUFJLENBQUMsVUFBVSxDQUFDLEdBQUcsR0FBRyxZQUFZLENBQUM7UUFFdkgsT0FBTyxHQUFHLENBQUM7SUFDZixDQUFDO0lBRU8sMENBQW9CLEdBQTVCO1FBQ0ksSUFBSSxTQUFTLEdBQVcsR0FBRyxHQUFHLElBQUksQ0FBQyxPQUFPLENBQUMsRUFBRSxHQUFHLG9DQUFvQyxDQUFDO1FBQ3JGLFNBQVMsSUFBSSxJQUFJLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQztRQUMxQyxJQUFJLGlCQUFpQixHQUFHLFFBQVEsQ0FBQyxhQUFhLENBQUMsU0FBUyxDQUFDLENBQUM7UUFFMUQsT0FBTyxJQUFJLENBQUMsWUFBWSxDQUFDLGlCQUFpQixDQUFDLENBQUMsQ0FBQyxDQUFDLGlCQUFpQixDQUFDLHFCQUFxQixFQUFFLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7SUFDdkcsQ0FBQztJQUVELHlCQUF5QjtJQUVsQix5Q0FBbUIsR0FBMUI7UUFDSSxJQUFJLFVBQVUsR0FBOEIsSUFBSSxDQUFDLE9BQU8sQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQztRQUM1RSxJQUFJLFFBQVEsR0FBVyxJQUFJLENBQUMsdUJBQXVCLENBQUMsVUFBVSxDQUFDLFFBQVEsQ0FBQyxDQUFDO1FBQ3pFLElBQUksV0FBVyxHQUFXLElBQUksQ0FBQyx1QkFBdUIsQ0FBQyxVQUFVLENBQUMsV0FBVyxDQUFDLENBQUM7UUFDL0UsT0FBTyxRQUFRLEdBQUcsR0FBRyxHQUFHLFdBQVcsR0FBRyxDQUFDLENBQUM7SUFDNUMsQ0FBQztJQUVNLG9DQUFjLEdBQXJCLFVBQXNCLEtBQVUsRUFBRSxVQUFrQixFQUFFLFlBQW9CLEVBQUUsUUFBb0I7UUFBcEIseUJBQUEsRUFBQSxZQUFvQjtRQUM1RixJQUFJLFFBQVEsR0FBVyxJQUFJLENBQUMsbUJBQW1CLEVBQUUsR0FBRyxRQUFRLEdBQUcsQ0FBQyxDQUFDO1FBRWpFLElBQUksS0FBSyxLQUFLLEtBQUssRUFBRTtZQUNqQixPQUFPLFVBQVUsR0FBRyxRQUFRLEdBQUcsSUFBSSxDQUFDLHNCQUFzQixDQUFDO1NBQzlEO2FBQU07WUFDSCxPQUFPLFVBQVUsR0FBRyxRQUFRLEdBQUcsWUFBWSxHQUFHLElBQUksQ0FBQyxzQkFBc0IsQ0FBQztTQUM3RTtJQUNMLENBQUM7SUFFTSx5Q0FBbUIsR0FBMUIsVUFBMkIsY0FBMkMsRUFBRSxPQUFvQztRQUFwQyx3QkFBQSxFQUFBLFlBQW9DO1FBQ3hHLElBQUksQ0FBQyxPQUFPLENBQUMsVUFBVTtZQUFFLE9BQU8sS0FBSyxDQUFDO1FBQ3RDLElBQUksT0FBTyxDQUFDLFNBQVMsR0FBRyxDQUFDLEVBQUU7WUFDdkIsSUFBSSxjQUFjLEtBQUssS0FBSztnQkFBRSxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMseUNBQXlDO1NBQ3JGO2FBQU07WUFDSCxJQUFJLGNBQWMsS0FBSyxRQUFRO2dCQUFFLE9BQU8sQ0FBQyxDQUFDLENBQUMseUNBQXlDO1NBQ3ZGO1FBQ0QsT0FBTyxLQUFLLENBQUM7SUFDakIsQ0FBQztJQUVELHFJQUFxSTtJQUM5SCw2Q0FBdUIsR0FBOUIsVUFBK0IsT0FBTyxFQUFFLE9BQU87UUFDM0MsSUFBSSxPQUFPLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxhQUFhO1lBQUUsT0FBTyxPQUFPLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxhQUFhLENBQUM7UUFDbEYsSUFBSSxZQUFZLEdBQWdDLEtBQUssQ0FBQztRQUN0RCwwREFBMEQ7UUFDMUQsSUFBSSxPQUFPLENBQUMsU0FBUyxHQUFHLENBQUM7WUFBRSxZQUFZLEdBQUcsUUFBUSxDQUFDO1FBQ25ELE9BQU8sWUFBWSxDQUFDO0lBQ3hCLENBQUM7SUFFRCwrRUFBK0U7SUFFL0U7Ozs7O09BS0c7SUFDSSwyQ0FBcUIsR0FBNUIsVUFBNkIsT0FBd0I7UUFDakQsT0FBTyxrRkFBa0YsR0FBRyxPQUFPLEdBQUcsUUFBUSxDQUFDO0lBQ25ILENBQUM7SUFFTSw2Q0FBdUIsR0FBOUIsVUFBK0IsTUFBdUI7UUFDbEQsSUFBSSxPQUFPLE1BQU0sS0FBSyxRQUFRO1lBQUUsT0FBTyxNQUFNLENBQUM7UUFDOUMsT0FBTyxVQUFVLENBQUMsTUFBTSxDQUFDLE9BQU8sQ0FBQyxVQUFVLEVBQUUsRUFBRSxDQUFDLENBQUMsQ0FBQztJQUN0RCxDQUFDO0lBRU0sd0NBQWtCLEdBQXpCLFVBQTBCLFVBQW9CO1FBQzFDLE9BQU8sVUFBVSxDQUFDLENBQUMsQ0FBQyxLQUFLLEtBQUssSUFBSSxDQUFDLFVBQVUsQ0FBQyxDQUFDLENBQUMsS0FBSyxPQUFPLElBQUksVUFBVSxDQUFDLENBQUMsQ0FBQyxLQUFLLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxZQUFZLENBQUMsQ0FBQyxDQUFDLFdBQVcsQ0FBQztJQUMxSCxDQUFDO0lBRU0sb0NBQWMsR0FBckIsVUFBc0IsS0FBaUMsRUFBRSxTQUFpQjtRQUN0RSxPQUFPO1lBQ0gsS0FBSyxFQUFFLEtBQUssS0FBSyxXQUFXLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsU0FBUyxHQUFHLENBQUM7WUFDaEQsR0FBRyxFQUFFLEtBQUssS0FBSyxXQUFXLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO1lBQzNDLEtBQUssRUFBRSxLQUFLLEtBQUssV0FBVyxDQUFDLENBQUMsQ0FBQyxVQUFDLENBQUMsRUFBRSxHQUFHLElBQUssT0FBQSxDQUFDLEdBQUcsR0FBRyxFQUFQLENBQU8sQ0FBQyxDQUFDLENBQUMsVUFBQyxDQUFDLEVBQUUsR0FBRyxJQUFLLE9BQUEsQ0FBQyxHQUFHLEdBQUcsRUFBUCxDQUFPO1lBQ3hFLE9BQU8sRUFBRSxLQUFLLEtBQUssV0FBVyxDQUFDLENBQUMsQ0FBQyxVQUFDLENBQUMsSUFBSyxPQUFBLENBQUMsR0FBRyxDQUFDLEVBQUwsQ0FBSyxDQUFDLENBQUMsQ0FBQyxVQUFDLENBQUMsSUFBSyxPQUFBLENBQUMsR0FBRyxDQUFDLEVBQUwsQ0FBSztTQUMvRCxDQUFDO0lBQ04sQ0FBQztJQUVNLDhCQUFRLEdBQWYsVUFBZ0IsS0FBeUIsRUFBRSxPQUFxQjtRQUFoRSxpQkF3QkM7UUF2QkcsSUFBSSxLQUFLLEdBQVc7WUFDaEIsS0FBSyxFQUFFLEVBQUU7WUFDVCxXQUFXLEVBQUUsRUFBRTtTQUNsQixDQUFDO1FBQ0YsSUFBSSxnQkFBZ0IsR0FBVyxDQUFDLENBQUM7UUFDakMsSUFBSSxnQkFBZ0IsR0FBWSxPQUFPLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDLFNBQVMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxJQUFJLE9BQU8sQ0FBQyxLQUFLLENBQUMsT0FBTyxJQUFJLE9BQU8sQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLE9BQU8sQ0FBQztRQUM3SSxJQUFJLGdCQUFnQjtZQUFFLElBQUksQ0FBQyx5QkFBeUIsQ0FBQyxPQUFPLENBQUMsRUFBRSxDQUFDLENBQUM7UUFFakUsS0FBSyxDQUFDLE9BQU8sQ0FBQyxVQUFBLENBQUM7WUFDWCxLQUFLLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDO1lBRTVCLDJFQUEyRTtZQUMzRSxJQUFJLGdCQUFnQixFQUFFO2dCQUNsQixLQUFJLENBQUMsc0JBQXNCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQztnQkFDdkMsSUFBSSxZQUFZLEdBQVcsS0FBSSxDQUFDLHFCQUFxQixFQUFFLENBQUMsS0FBSyxDQUFDO2dCQUM5RCxJQUFJLFlBQVksR0FBRyxnQkFBZ0IsRUFBRTtvQkFDakMsZ0JBQWdCLEdBQUcsWUFBWSxDQUFDO29CQUNoQyxLQUFLLENBQUMsV0FBVyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDO2lCQUNqQzthQUNKO1FBQ0wsQ0FBQyxDQUFDLENBQUM7UUFFSCxPQUFPLEtBQUssQ0FBQztJQUNqQixDQUFDO0lBRU0sa0RBQTRCLEdBQW5DLFVBQW9DLE1BQWM7UUFDOUMsSUFBSSxJQUFJLENBQUMsZUFBZSxFQUFFO1lBQ3RCLElBQUksV0FBVyxHQUFpQixJQUFJLENBQUMsTUFBTSxDQUFDLFdBQVcsQ0FBQztZQUN4RCxJQUFJLFdBQVcsSUFBSSxXQUFXLENBQUMsR0FBRyxJQUFJLE9BQU8sV0FBVyxDQUFDLEdBQUcsQ0FBQyxpQkFBaUIsS0FBSyxXQUFXLEVBQUU7Z0JBQzVGLE9BQU8sSUFBSSxDQUFDLE1BQU0sQ0FBQyxXQUFXLENBQUMsR0FBRyxDQUFDLGlCQUFpQixDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUM7YUFDcEY7WUFDRCxPQUFPLElBQUksQ0FBQyxHQUFHLENBQUMsTUFBTSxDQUFDLENBQUM7U0FDM0I7UUFDRCxPQUFPLE1BQU0sQ0FBQztJQUNsQixDQUFDO0lBRU0sc0NBQWdCLEdBQXZCLFVBQXdCLE9BQWU7UUFDbkMsSUFBSSxRQUFRLENBQUMsT0FBTyxDQUFDLFFBQVEsRUFBRSxDQUFDLEtBQUssT0FBTztZQUFFLE9BQU8sQ0FBQyxDQUFDO1FBQ3ZELElBQUksTUFBTSxHQUFXLENBQUMsQ0FBQztRQUN2QixJQUFJLFVBQVUsR0FBVyxJQUFJLENBQUMsR0FBRyxDQUFDLE9BQU8sQ0FBQyxDQUFDLFFBQVEsRUFBRSxDQUFDO1FBQ3RELElBQUksVUFBVSxHQUFrQixVQUFVLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDO1FBRXRELElBQUksVUFBVSxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDLEVBQUU7WUFDN0IsTUFBTSxHQUFHLFVBQVUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUM7U0FDakM7YUFBTTtZQUNILE1BQU0sR0FBRyxRQUFRLENBQUMsVUFBVSxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO1lBQzdDLElBQUksT0FBTyxVQUFVLENBQUMsQ0FBQyxDQUFDLEtBQUssV0FBVztnQkFBRSxNQUFNLElBQUksVUFBVSxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQztTQUM1RTtRQUVELE9BQU8sTUFBTSxDQUFDO0lBQ2xCLENBQUM7SUFFTSxrQ0FBWSxHQUFuQixVQUFvQixPQUFlLEVBQUUsTUFBdUIsRUFBRSxPQUF1QixFQUFFLFNBQWtCO1FBQTNDLHdCQUFBLEVBQUEsY0FBdUI7UUFDakYsSUFBSSxRQUFRLEdBQVcsT0FBTyxTQUFTLEtBQUssV0FBVyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUM7UUFDL0YsSUFBSSxJQUFJLEdBQVcsSUFBSSxDQUFDLHFCQUFxQixDQUFDLE1BQU0sRUFBRSxRQUFRLENBQUMsQ0FBQztRQUVoRSxJQUFJLE9BQU87WUFBRSxJQUFJLEdBQUcsSUFBSSxDQUFDLHFCQUFxQixDQUFDLElBQUksQ0FBQyxDQUFDO1FBRXJELE9BQU8sSUFBSSxDQUFDLHFCQUFxQixDQUFDLE9BQU8sRUFBRSxJQUFJLENBQUMsQ0FBQztJQUNyRCxDQUFDO0lBRU0sMkNBQXFCLEdBQTVCLFVBQTZCLE9BQWUsRUFBRSxLQUFhO1FBQ3ZELE9BQU8sT0FBTyxDQUFDLE9BQU8sQ0FBQyxVQUFVLEVBQUUsS0FBSyxDQUFDLENBQUM7SUFDOUMsQ0FBQztJQUVNLGdDQUFVLEdBQWpCLFVBQWtCLE1BQXVCO1FBQ3JDLE9BQU8sT0FBTyxNQUFNLEtBQUssUUFBUSxJQUFJLENBQUMsTUFBTSxHQUFHLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQztJQUM1RCxDQUFDO0lBRU0saUNBQVcsR0FBbEIsVUFBbUIsTUFBdUIsRUFBRSxlQUF3QjtRQUNoRSxJQUFJLE9BQU8sTUFBTSxLQUFLLFFBQVE7WUFBRSxPQUFPLEVBQUUsQ0FBQztRQUUxQyxJQUFJLElBQUksQ0FBQyxHQUFHLENBQUMsTUFBTSxDQUFDLEdBQUcsUUFBUTtZQUFFLE9BQU8sS0FBSyxDQUFDO1FBRTlDLElBQUksSUFBSSxDQUFDLFVBQVUsQ0FBQyxNQUFNLENBQUMsRUFBRTtZQUN6QixPQUFPLEdBQUcsQ0FBQztTQUNkO2FBQU07WUFDSCxhQUFhO1lBQ2IsSUFBSSxJQUFJLENBQUMsR0FBRyxDQUFDLE1BQU0sQ0FBQyxHQUFHLFVBQVU7Z0JBQUUsT0FBTyxLQUFLLENBQUM7WUFFaEQsSUFBSSxPQUFPLGVBQWUsS0FBSyxXQUFXLElBQUksZUFBZSxLQUFLLENBQUMsRUFBRTtnQkFDakUsd0JBQXdCO2dCQUN4QixPQUFPLEdBQUcsR0FBRyxlQUFlLENBQUMsUUFBUSxFQUFFLEdBQUcsR0FBRyxDQUFDO2FBQ2pEO1NBQ0o7UUFFRCxPQUFPLEVBQUUsQ0FBQztJQUNkLENBQUM7SUFFTSwyQ0FBcUIsR0FBNUIsVUFBNkIsTUFBdUIsRUFBRSxPQUFlO1FBQ2pFLElBQUksT0FBTyxNQUFNLEtBQUssUUFBUTtZQUFFLE9BQU8sTUFBTSxDQUFDO1FBQzlDLE9BQU8sRUFBRSxDQUFDLE1BQU0sQ0FBQyxPQUFPLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQztJQUN0QyxDQUFDO0lBRU0scUNBQWUsR0FBdEIsVUFBdUIsS0FBYSxFQUFFLEtBQWE7UUFDL0MsT0FBTyxLQUFLLENBQUMsUUFBUSxFQUFFLENBQUMsTUFBTSxHQUFHLEtBQUssQ0FBQyxRQUFRLEVBQUUsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDO0lBQzdFLENBQUM7SUFFTSw2Q0FBdUIsR0FBOUIsVUFBK0IsZUFBb0I7UUFDL0MsSUFBSSxNQUFNLEdBQWlCLElBQUksQ0FBQyxPQUFPLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQztRQUNyRCxlQUFlLENBQUMsS0FBSyxDQUFDLE9BQU8sR0FBRyxNQUFNLENBQUMsR0FBRyxHQUFHLEdBQUcsR0FBRyxNQUFNLENBQUMsS0FBSyxHQUFHLEdBQUcsR0FBRyxNQUFNLENBQUMsTUFBTSxHQUFHLEdBQUcsR0FBRyxNQUFNLENBQUMsSUFBSSxDQUFDO0lBQzlHLENBQUM7SUFFTSw2Q0FBdUIsR0FBOUIsVUFBK0IsVUFBZTtRQUMxQyxVQUFVLENBQUMsSUFBSSxDQUFDLFdBQVcsRUFBRSxZQUFZLEdBQUcsSUFBSSxDQUFDLFVBQVUsQ0FBQyxJQUFJLEdBQUcsR0FBRyxHQUFHLElBQUksQ0FBQyxVQUFVLENBQUMsR0FBRyxHQUFHLEdBQUcsQ0FBQyxDQUFDO0lBQ3hHLENBQUM7SUFFTSxxQ0FBZSxHQUF0QixVQUF1QixRQUFhLEVBQUUsT0FBMkM7UUFDN0UsS0FBSyxJQUFJLEdBQUcsSUFBSSxPQUFPLEVBQUU7WUFDckIsSUFBSSxDQUFDLElBQUksQ0FBQyxZQUFZLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxDQUFDO2dCQUFFLFNBQVM7WUFDL0MsSUFBSSxZQUFZLEdBQVcsR0FBRyxLQUFLLE9BQU8sQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsT0FBTyxDQUFDLHNCQUFzQixFQUFFLEtBQUssQ0FBQyxDQUFDLFdBQVcsRUFBRSxDQUFDO1lBQy9HLFFBQVEsQ0FBQyxJQUFJLENBQUMsWUFBWSxFQUFFLE9BQU8sQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDO1NBQzdDO0lBQ0wsQ0FBQztJQUVNLDZCQUFPLEdBQWQsVUFBZSxNQUFXO1FBQ3RCLE9BQU8sQ0FBQyxPQUFPLE1BQU0sS0FBSyxXQUFXLElBQUksTUFBTSxLQUFLLElBQUksSUFBSSxNQUFNLENBQUMsS0FBSyxLQUFLLElBQUksQ0FBQyxDQUFDO0lBQ3ZGLENBQUM7SUFFTSxrQ0FBWSxHQUFuQixVQUFvQixJQUFTO1FBQ3pCLE9BQU8sQ0FBQyxPQUFPLElBQUksS0FBSyxXQUFXLElBQUksSUFBSSxLQUFLLElBQUksSUFBSSxJQUFJLEtBQUssRUFBRSxDQUFDLENBQUM7SUFDekUsQ0FBQztJQUVNLG1DQUFhLEdBQXBCLFVBQXFCLElBQW1CLEVBQUUsS0FBb0I7UUFDMUQsSUFBSSxLQUFLLEtBQUssS0FBSztZQUFFLE9BQU8sRUFBRSxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsQ0FBQztRQUN6QyxJQUFJLEtBQUssS0FBSyxLQUFLO1lBQUUsT0FBTyxFQUFFLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxDQUFDO0lBQzdDLENBQUM7SUFFTSx5Q0FBbUIsR0FBMUIsVUFBMkIsS0FBZ0IsRUFBRSxTQUFrQixFQUFFLGFBQWdDO1FBQzdGLElBQUksSUFBSSxDQUFDLFNBQVMsRUFBRTtZQUNoQixJQUFJLEtBQUssS0FBSyxHQUFHLEVBQUU7Z0JBQ2YsSUFBSSxTQUFTO29CQUFFLE9BQU8sYUFBYSxDQUFDLEtBQUssQ0FBQztnQkFDMUMsT0FBTyxhQUFhLENBQUMsSUFBSSxDQUFDO2FBQzdCO1lBQ0QsSUFBSSxLQUFLLEtBQUssR0FBRyxFQUFFO2dCQUNmLElBQUksU0FBUztvQkFBRSxPQUFPLGFBQWEsQ0FBQyxHQUFHLENBQUM7Z0JBQ3hDLE9BQU8sYUFBYSxDQUFDLE1BQU0sQ0FBQzthQUMvQjtTQUNKO2FBQU07WUFDSCxJQUFJLEtBQUssS0FBSyxHQUFHLEVBQUU7Z0JBQ2YsSUFBSSxTQUFTO29CQUFFLE9BQU8sYUFBYSxDQUFDLEdBQUcsQ0FBQztnQkFDeEMsT0FBTyxhQUFhLENBQUMsTUFBTSxDQUFDO2FBQy9CO1lBQ0QsSUFBSSxLQUFLLEtBQUssR0FBRyxFQUFFO2dCQUNmLElBQUksU0FBUztvQkFBRSxPQUFPLGFBQWEsQ0FBQyxLQUFLLENBQUM7Z0JBQzFDLE9BQU8sYUFBYSxDQUFDLElBQUksQ0FBQzthQUM3QjtTQUNKO0lBQ0wsQ0FBQztJQUVNLDBDQUFvQixHQUEzQixVQUE0QixlQUE4QixFQUFFLFdBQW1CO1FBQzNFLElBQUksQ0FBQyxlQUFlO1lBQUUsT0FBTyxFQUFFLENBQUM7UUFDaEMsT0FBTyxXQUFXLElBQUksZUFBZSxDQUFDLE1BQU0sR0FBRyxXQUFXLENBQUMsQ0FBQyxDQUFDLGVBQWUsQ0FBQyxLQUFLLENBQUMsQ0FBQyxFQUFFLFdBQVcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxlQUFlLENBQUM7SUFDekgsQ0FBQztJQUVEOzs7OztPQUtHO0lBQ0ksOEJBQVEsR0FBZixVQUFnQixhQUFxQixFQUFFLFlBQXNCOztRQUN6RCxJQUFJLE1BQU0sR0FBVyxFQUFFLENBQUM7UUFDeEIsSUFBSSxZQUFZLEVBQUU7WUFDZCxNQUFNLEdBQUcsSUFBSSxDQUFDLE9BQU8sQ0FBQyxPQUFPLENBQUMsS0FBSyxDQUFDO1NBQ3ZDO1FBQ0QsSUFBSSxPQUFPLEdBQVcsRUFBRSxDQUFDO1FBRXpCLElBQUksYUFBYSxFQUFFOztnQkFDZixLQUF1QixJQUFBLEtBQUEsU0FBQSxNQUFNLENBQUMsSUFBSSxDQUFDLGFBQWEsQ0FBQyxDQUFBLGdCQUFBLDRCQUFFO29CQUE5QyxJQUFJLFVBQVUsV0FBQTtvQkFDZixPQUFPLElBQUksVUFBVSxDQUFDLE9BQU8sQ0FBQyxzQkFBc0IsRUFBRSxLQUFLLENBQUMsQ0FBQyxXQUFXLEVBQUUsQ0FBQztvQkFDM0UsT0FBTyxJQUFJLEdBQUcsQ0FBQztvQkFDZixPQUFPLElBQUksQ0FBQyxNQUFNLElBQUksTUFBTSxDQUFDLGNBQWMsQ0FBQyxVQUFVLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQyxDQUFDLGFBQWEsQ0FBQyxVQUFVLENBQUMsQ0FBQztvQkFDMUcsT0FBTyxJQUFJLEdBQUcsQ0FBQztpQkFDbEI7Ozs7Ozs7OztTQUNKO1FBQ0QsT0FBTyxPQUFPLENBQUM7SUFDbkIsQ0FBQztJQUVELGlGQUFpRjtJQUVqRjs7Ozs7T0FLRztJQUNJLGtDQUFZLEdBQW5CLFVBQW9CLEtBQXNDLEVBQUUsVUFBa0IsRUFBRSxZQUFvQjtRQVNoRyxJQUFJLFVBQVUsR0FBVyxDQUFDLENBQUM7UUFDM0IsSUFBSSxVQUFVLEdBQVcsQ0FBQyxDQUFDO1FBQzNCLElBQUksWUFBWSxHQUFHLElBQUksQ0FBQyxZQUFZLENBQUM7UUFFckMsSUFBSSxZQUFZLENBQUMsS0FBSyxDQUFDLEVBQUU7WUFDckIsVUFBVSxHQUFHLEtBQUssQ0FBQyxNQUFNLENBQUMsWUFBWSxDQUFDLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxDQUFDLEtBQUssQ0FBQztZQUMvRCxVQUFVLEdBQUcsS0FBSyxDQUFDLEtBQUssQ0FBQyxVQUFVLENBQUMsTUFBTSxDQUFDO1NBQzlDO2FBQU07WUFDSCxVQUFVLEdBQUcsS0FBSyxDQUFDLFVBQVUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxZQUFZLENBQUMsQ0FBQyxLQUFLLENBQUM7WUFDckQsVUFBVSxHQUFHLEtBQUssQ0FBQyxNQUFNLENBQUM7U0FDN0I7UUFFRCxTQUFTLFFBQVEsQ0FBQyxJQUFZLEVBQUUsTUFBZTtZQUMzQyxJQUFJLEtBQUssR0FBVyxDQUFDLENBQUM7WUFDdEIsSUFBSSxJQUFJLEtBQUssTUFBTSxFQUFFO2dCQUNqQixJQUFJLFVBQVUsR0FBRyxDQUFDLEVBQUU7b0JBQ2hCLEtBQUssR0FBRyxVQUFVLEdBQUcsQ0FBQyxDQUFDO2lCQUMxQjtxQkFBTTtvQkFDSCxPQUFPLEtBQUssQ0FBQztpQkFDaEI7YUFDSjtpQkFBTTtnQkFDSCxJQUFJLFVBQVUsR0FBRyxVQUFVLEdBQUcsQ0FBQyxFQUFFO29CQUM3QixLQUFLLEdBQUcsVUFBVSxHQUFHLENBQUMsQ0FBQztpQkFDMUI7cUJBQU07b0JBQ0gsT0FBTyxLQUFLLENBQUM7aUJBQ2hCO2FBQ0o7WUFFRCxJQUFJLEtBQUssR0FBVyxDQUFDLFlBQVksQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxZQUFZLENBQUMsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLFlBQVksQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDO1lBRTlILElBQUksTUFBTSxFQUFFO2dCQUNSLE9BQU8sS0FBSyxLQUFLLElBQUksQ0FBQzthQUN6QjtZQUNELE9BQU8sS0FBSyxLQUFLLElBQUksQ0FBQztRQUMxQixDQUFDO1FBRUQsSUFBSSxVQUFVLEdBQVksUUFBUSxDQUFDLE1BQU0sRUFBRSxJQUFJLENBQUMsQ0FBQztRQUNqRCxJQUFJLGFBQWEsR0FBWSxRQUFRLENBQUMsTUFBTSxFQUFFLEtBQUssQ0FBQyxDQUFDO1FBQ3JELElBQUksVUFBVSxHQUFZLFFBQVEsQ0FBQyxNQUFNLEVBQUUsSUFBSSxDQUFDLENBQUM7UUFDakQsSUFBSSxhQUFhLEdBQVksUUFBUSxDQUFDLE1BQU0sRUFBRSxLQUFLLENBQUMsQ0FBQztRQUVyRCxJQUFJLFdBQVcsR0FBWSxhQUFhLElBQUksVUFBVSxLQUFLLElBQUksSUFBSSxVQUFVLENBQUM7UUFFOUUsSUFBSSxjQUFjLEdBQVksVUFBVSxJQUFJLFVBQVUsS0FBSyxJQUFJLElBQUksYUFBYSxDQUFDO1FBRWpGLE9BQU87WUFDSCxVQUFVLEVBQUUsVUFBVTtZQUN0QixhQUFhLEVBQUUsYUFBYTtZQUM1QixVQUFVLEVBQUUsVUFBVTtZQUN0QixhQUFhLEVBQUUsYUFBYTtZQUM1QixXQUFXLEVBQUUsV0FBVztZQUN4QixjQUFjLEVBQUUsY0FBYztTQUNqQyxDQUFDO0lBQ04sQ0FBQztJQUVNLGtDQUFZLEdBQW5CLFVBQW9CLE1BQVc7UUFDM0IsT0FBTyxRQUFRLElBQUksTUFBTSxDQUFDO0lBQzlCLENBQUM7SUFFRCxxRkFBcUY7SUFFckY7Ozs7O09BS0c7SUFDSSw4Q0FBd0IsR0FBL0IsVUFBZ0MsVUFBMEIsRUFBRSxXQUEwQixFQUFFLFlBQW9CO1FBQ3hHLElBQUksTUFBTSxHQUFrQixFQUFFLENBQUM7UUFDL0IsS0FBSyxJQUFJLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxHQUFHLFdBQVcsQ0FBQyxNQUFNLEVBQUUsRUFBRSxDQUFDLEVBQUU7WUFDekMsSUFBSSxHQUFHLEdBQVcsQ0FBQyxDQUFDO1lBQ3BCLEtBQUssSUFBSSxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsR0FBRyxZQUFZLEVBQUUsRUFBRSxDQUFDLEVBQUU7Z0JBQ25DLElBQUksT0FBTyxVQUFVLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxLQUFLLFdBQVc7b0JBQUUsU0FBUztnQkFDM0QsSUFBSSxVQUFVLEdBQWtCLFVBQVUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDO2dCQUM1RCxJQUFJLE9BQU8sVUFBVSxLQUFLLFdBQVc7b0JBQUUsU0FBUztnQkFDaEQsR0FBRyxHQUFHLENBQUMsVUFBVSxLQUFLLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLEdBQUcsR0FBRyxVQUFVLENBQUM7YUFDeEQ7WUFDRCxNQUFNLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFDO1NBQ3BCO1FBQ0QsT0FBTyxNQUFNLENBQUM7SUFDbEIsQ0FBQztJQUVELGdGQUFnRjtJQUNoRjs7Ozs7T0FLRztJQUNJLGdDQUFVLEdBQWpCLFVBQWtCLFdBQTJDLEVBQUUsS0FBVSxFQUFFLE9BQXFCLEVBQUUsZ0JBQXdCO1FBS3RILElBQUksT0FBTyxHQUFlLEVBQUUsQ0FBQztRQUM3QixJQUFJLFFBQVEsR0FBa0IsRUFBRSxDQUFDO1FBQ2pDLElBQUksUUFBZ0IsQ0FBQztRQUNyQixJQUFJLGtCQUFrQixHQUFXLENBQUMsQ0FBQztRQUNuQyxJQUFJLGVBQWUsR0FBdUIsTUFBTSxDQUFDLElBQUksQ0FBQyxXQUFXLENBQUMsQ0FBQyxHQUFHLENBQUMsVUFBQSxHQUFHLElBQUksT0FBQSxXQUFXLENBQUMsR0FBRyxDQUFDLEVBQWhCLENBQWdCLENBQUMsQ0FBQztRQUNoRyxXQUFXLEdBQUcsRUFBRSxDQUFDO1FBQ2pCLEtBQUssSUFBSSxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsR0FBRyxLQUFLLENBQUMsSUFBSSxDQUFDLE1BQU0sRUFBRSxDQUFDLEVBQUUsRUFBRTtZQUN4QyxLQUFLLElBQUksQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLEdBQUcsS0FBSyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxFQUFFLENBQUMsRUFBRSxFQUFFO2dCQUM3QyxLQUFLLElBQUksQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLEdBQUcsZUFBZSxDQUFDLE1BQU0sRUFBRSxDQUFDLEVBQUUsRUFBRTtvQkFDN0MsSUFBSSxLQUFLLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsS0FBSyxlQUFlLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxFQUFFO3dCQUNwRCxJQUFJLE9BQU8sS0FBSyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLFdBQVcsRUFBRTs0QkFDbEQsSUFBSSxDQUFDLGdCQUFnQixLQUFLLFNBQVMsSUFBSSxnQkFBZ0IsS0FBSyxJQUFJLElBQUksa0JBQWtCLEdBQUcsZ0JBQWdCLENBQUMsSUFBSSxnQkFBZ0IsS0FBSyxTQUFTLElBQUksZ0JBQWdCLEtBQUssSUFBSSxFQUFFO2dDQUN2SyxJQUFJLFlBQVksR0FBRyxLQUFLLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQztnQ0FDL0MsSUFBSSxVQUFVLEdBQUcsQ0FBQyxZQUFZLElBQUksWUFBWSxJQUFJLElBQUksSUFBSSxZQUFZLElBQUksSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLFlBQVksQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLGdCQUFnQixDQUFDLE9BQU8sRUFBRSxrQkFBa0IsRUFBRSxPQUFPLENBQUMsQ0FBQztnQ0FDN0osUUFBUSxHQUFHLElBQUksR0FBRyxrQkFBa0IsQ0FBQztnQ0FDckMsV0FBVyxDQUFDLFFBQVEsQ0FBQyxHQUFHO29DQUNwQixNQUFNLEVBQUUsS0FBSyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsR0FBRyxHQUFHLGVBQWUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJO29DQUN2RCxJQUFJLEVBQUUsUUFBUTtvQ0FDZCxPQUFPLEVBQUUsUUFBUTtvQ0FDakIsR0FBRyxFQUFFLEtBQUssQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLEdBQUcsR0FBRyxlQUFlLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSTtvQ0FDcEQsR0FBRyxFQUFFLEtBQUssQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQztvQ0FDaEMsT0FBTyxFQUFFLEtBQUssQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztvQ0FDeEIsT0FBTyxFQUFFLEtBQUssR0FBRyxrQkFBa0I7b0NBQ25DLE9BQU8sRUFBRSxVQUFVO29DQUNuQixhQUFhLEVBQUUsQ0FBQztvQ0FDaEIsV0FBVyxFQUFFLENBQUM7aUNBQ2pCLENBQUM7Z0NBQ0YsUUFBUSxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsQ0FBQztnQ0FDMUIsT0FBTyxDQUFDLElBQUksQ0FBQztvQ0FDVCxJQUFJLEVBQUUsUUFBUTtvQ0FDZCxHQUFHLEVBQUUsS0FBSyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsR0FBRyxHQUFHLGVBQWUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJO29DQUNwRCxHQUFHLEVBQUUsS0FBSyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDO29DQUNoQyxPQUFPLEVBQUUsS0FBSyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO29DQUN4QixPQUFPLEVBQUUsS0FBSyxHQUFHLGtCQUFrQjtvQ0FDbkMsT0FBTyxFQUFFLFVBQVU7b0NBQ25CLGFBQWEsRUFBRSxDQUFDO29DQUNoQixXQUFXLEVBQUUsQ0FBQztpQ0FDakIsQ0FBQyxDQUFDO2dDQUNILGtCQUFrQixFQUFFLENBQUM7Z0NBQ3JCLE1BQU07NkJBQ1Q7eUJBQ0o7cUJBQ0o7aUJBQ0o7YUFDSjtTQUNKO1FBQ0QsSUFBSSxZQUFZLEdBQUc7WUFDZixTQUFTLEVBQUUsT0FBTztZQUNsQixVQUFVLEVBQUUsUUFBUTtZQUNwQixZQUFZLEVBQUUsV0FBVztTQUM1QixDQUFDO1FBQ0YsT0FBTyxZQUFZLENBQUM7SUFDeEIsQ0FBQztJQUVNLDBDQUFvQixHQUEzQixVQUE0QixXQUEyQyxFQUFFLEtBQVUsRUFBRSxPQUFxQixFQUFFLGdCQUF3QjtRQUNoSSxJQUFJLE9BQU8sR0FBZSxFQUFFLENBQUM7UUFDN0IsSUFBSSxRQUFRLEdBQWtCLEVBQUUsQ0FBQztRQUNqQyxJQUFJLFFBQWdCLENBQUM7UUFDckIsSUFBSSxrQkFBa0IsR0FBVyxDQUFDLENBQUM7UUFDbkMsV0FBVyxHQUFHLEVBQUUsQ0FBQztRQUNqQixJQUFJLEtBQUssQ0FBQyxNQUFNLElBQUksS0FBSyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsSUFBSSxLQUFLLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksRUFBRTtZQUN6RCxLQUFLLElBQUksQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLEdBQUcsS0FBSyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsTUFBTSxFQUFFLENBQUMsRUFBRSxFQUFFO2dCQUNsRCxJQUFJLE9BQU8sS0FBSyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLFdBQVcsRUFBRTtvQkFDbEQsSUFBSSxDQUFDLGdCQUFnQixJQUFJLFNBQVMsSUFBSSxnQkFBZ0IsSUFBSSxJQUFJLElBQUksa0JBQWtCLEdBQUcsZ0JBQWdCLENBQUMsSUFBSSxnQkFBZ0IsSUFBSSxTQUFTLElBQUksZ0JBQWdCLElBQUksSUFBSSxFQUFFO3dCQUNuSyxJQUFJLFlBQVksR0FBRyxLQUFLLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQzt3QkFDcEQsSUFBSSxVQUFVLEdBQUcsQ0FBQyxZQUFZLElBQUksWUFBWSxJQUFJLElBQUksSUFBSSxZQUFZLElBQUksSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLFlBQVksQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLGdCQUFnQixDQUFDLE9BQU8sRUFBRSxrQkFBa0IsRUFBRSxPQUFPLENBQUMsQ0FBQzt3QkFDN0osUUFBUSxHQUFHLElBQUksR0FBRyxrQkFBa0IsQ0FBQzt3QkFDckMsV0FBVyxDQUFDLFFBQVEsQ0FBQyxHQUFHOzRCQUNwQixNQUFNLEVBQUUsS0FBSyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxJQUFJLEVBQUUsR0FBRyxDQUFDOzRCQUN2RCxJQUFJLEVBQUUsUUFBUTs0QkFDZCxPQUFPLEVBQUUsUUFBUTs0QkFDakIsR0FBRyxFQUFFLEtBQUssQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUk7NEJBQ2pDLEdBQUcsRUFBRSxLQUFLLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDOzRCQUM5QixPQUFPLEVBQUUsS0FBSyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSTs0QkFDckMsT0FBTyxFQUFFLEtBQUssR0FBRyxrQkFBa0I7NEJBQ25DLE9BQU8sRUFBRSxVQUFVO3lCQUN0QixDQUFDO3dCQUNGLFFBQVEsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLENBQUM7d0JBQzFCLElBQUksS0FBSyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLEtBQUssQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLEVBQUU7NEJBQzVELE9BQU8sQ0FBQyxJQUFJLENBQUM7Z0NBQ1QsSUFBSSxFQUFFLFFBQVE7Z0NBQ2QsR0FBRyxFQUFFLEtBQUssQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUk7Z0NBQ2pDLEdBQUcsRUFBRSxLQUFLLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO2dDQUM5QixPQUFPLEVBQUUsS0FBSyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSTtnQ0FDckMsT0FBTyxFQUFFLEtBQUssR0FBRyxrQkFBa0I7Z0NBQ25DLE9BQU8sRUFBRSxVQUFVOzZCQUN0QixDQUFDLENBQUM7eUJBQ047d0JBRUQsa0JBQWtCLEVBQUUsQ0FBQztxQkFDeEI7aUJBQ0o7YUFDSjtTQUNKO1FBQ0QsSUFBSSxZQUFZLEdBQUc7WUFDZixTQUFTLEVBQUUsT0FBTztZQUNsQixVQUFVLEVBQUUsUUFBUTtZQUNwQixZQUFZLEVBQUUsV0FBVztTQUM1QixDQUFDO1FBQ0YsT0FBTyxZQUFZLENBQUM7SUFDeEIsQ0FBQztJQUVNLHNDQUFnQixHQUF2QixVQUF3QixXQUEyQyxFQUFFLEtBQVUsRUFBRSxPQUFxQjtRQUNsRyxJQUFJLFFBQWdCLENBQUM7UUFDckIsV0FBVyxHQUFHLEVBQUUsQ0FBQztRQUNqQixLQUFLLElBQUksQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLEdBQUcsS0FBSyxDQUFDLE1BQU0sRUFBRSxDQUFDLEVBQUUsRUFBRTtZQUNuQyxJQUFJLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLElBQUksU0FBUyxFQUFFO2dCQUM1QixJQUFJLFlBQVksR0FBRyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDO2dCQUNsQyxRQUFRLEdBQUcsSUFBSSxHQUFHLENBQUMsQ0FBQztnQkFDcEIsV0FBVyxDQUFDLFFBQVEsQ0FBQyxHQUFHO29CQUNwQixNQUFNLEVBQUUsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUk7b0JBQ3JCLElBQUksRUFBRSxRQUFRO29CQUNkLE9BQU8sRUFBRSxRQUFRO29CQUNqQixHQUFHLEVBQUUsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUk7b0JBQ2xCLEdBQUcsRUFBRSxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUs7b0JBQzNCLE9BQU8sRUFBRSxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSTtvQkFDdEIsT0FBTyxFQUFFLENBQUMsWUFBWSxJQUFJLFlBQVksSUFBSSxJQUFJLElBQUksWUFBWSxJQUFJLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxZQUFZLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxPQUFPLEVBQUUsQ0FBQyxFQUFFLE9BQU8sQ0FBQztvQkFDeEksYUFBYSxFQUFFLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFO29CQUMxQixVQUFVLEVBQUUsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVE7aUJBQ2hDLENBQUM7YUFDTDtTQUNKO1FBQ0QsT0FBTyxXQUFXLENBQUM7SUFDdkIsQ0FBQztJQUVNLHNDQUFnQixHQUF2QixVQUF3QixRQUFhLEVBQUUsWUFBb0IsRUFBRSxPQUFxQjtRQUM5RSxJQUFJLFFBQVEsS0FBSyxPQUFPO1lBQUUsT0FBTyxRQUFRLENBQUM7UUFFMUMsSUFBSSxZQUFZLElBQUksWUFBWSxLQUFLLENBQUMsRUFBRTtZQUNwQyxPQUFPLE9BQU8sQ0FBQyxNQUFNLENBQUMsWUFBWSxHQUFHLE9BQU8sQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLENBQUM7U0FDL0Q7SUFDTCxDQUFDO0lBRU0sMkNBQXFCLEdBQTVCLFVBQTZCLFlBQXdCLEVBQUUsZ0JBQXdCLEVBQUUsWUFBb0IsRUFBRSxlQUFnRDtRQUNuSixJQUFJLFdBQVcsR0FBbUMsRUFBRSxDQUFDO1FBQ3JELEtBQUssSUFBSSxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsR0FBRyxZQUFZLENBQUMsTUFBTSxFQUFFLENBQUMsRUFBRSxFQUFFO1lBQzFDLElBQUksUUFBUSxHQUFXLElBQUksR0FBRyxDQUFDLENBQUM7WUFDaEMsV0FBVyxDQUFDLFFBQVEsQ0FBQyxHQUFHO2dCQUNwQixNQUFNLEVBQUUsWUFBWSxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsZ0JBQWdCLENBQUMsR0FBRyxZQUFZLEdBQUcsS0FBSyxHQUFHLFlBQVksQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsT0FBTyxDQUFDLGdCQUFnQixDQUFDLEdBQUcsWUFBWTtnQkFDM0ksSUFBSSxFQUFFLFFBQVE7Z0JBQ2QsT0FBTyxFQUFFLFFBQVE7Z0JBQ2pCLE9BQU8sRUFBRSxZQUFZLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSztnQkFDOUIsVUFBVSxFQUFFLGVBQWUsSUFBSSxlQUFlLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLGVBQWUsQ0FBQyxRQUFRLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLEtBQUs7YUFDeEcsQ0FBQztTQUVMO1FBQ0QsT0FBTyxXQUFXLENBQUM7SUFDdkIsQ0FBQzs7Z0JBbmlDNEIsWUFBWTs7SUE1Q2hDLFdBQVc7UUFEdkIsVUFBVSxFQUFFO3lDQTZDb0IsWUFBWTtPQTVDaEMsV0FBVyxDQWdsQ3ZCO0lBQUQsa0JBQUM7Q0FBQSxBQWhsQ0QsSUFnbENDO1NBaGxDWSxXQUFXIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgSW5qZWN0YWJsZSB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xyXG5pbXBvcnQgeyBLZERvbUVsZW1TdmMgfSBmcm9tICcuLi9rZC1jb21tb24vaW5kZXgnO1xyXG5pbXBvcnQgKiBhcyBkMyBmcm9tICdkMyc7XHJcbmltcG9ydCAqIGFzIGhlbHBlciBmcm9tICcuL2hlbHBlci1zdmMvaW5kZXgnO1xyXG5pbXBvcnQge1xyXG4gICAgSVNlcmllcyxcclxuICAgIElDaGFydENvbmZpZyxcclxuICAgIElDaGFydE1hcmdpbixcclxuICAgIElZQXhpc0NvbmZpZyxcclxuICAgIElDaGFydERhdGEsXHJcbiAgICBJRDNEYXRhRGF0YSxcclxuICAgIElNYXhNaW5JbnRlcnZhbCxcclxuICAgIElEM0RhdGFSYW5nZSxcclxuICAgIElMZWdlbmREYXRhLFxyXG4gICAgSUZvckxvb3BJbmZvLFxyXG4gICAgSUF4aXNMYWJlbEJvb2xlYW5DaGVja3MsXHJcbiAgICBJUGxvdE9wdGlvbnMsXHJcbiAgICBJQXhpc1RyYW5zZm9ybVBvcyxcclxuICAgIElYSW5mbyxcclxuICAgIElZQXhpc0xhYmVsUmFuZ2VcclxufSBmcm9tICcuL2tkLWFuZ3VsYXItY2hhcnRzLWludGVyZmFjZSc7XHJcblxyXG5ASW5qZWN0YWJsZSgpXHJcbmV4cG9ydCBjbGFzcyBLZENoYXJ0c1N2YyB7XHJcblxyXG4gICAgcHJpdmF0ZSBfY29uZmlnOiBJQ2hhcnRDb25maWc7XHJcbiAgICBwcml2YXRlIF9zdmc6IGFueTtcclxuICAgIHByaXZhdGUgX3N2Z1JlY3Q6IGFueTtcclxuICAgIHByaXZhdGUgX3N2Z1BhcmVudFJlY3Q6IGFueTtcclxuICAgIHByaXZhdGUgX2lzSW52ZXJ0OiBib29sZWFuID0gZmFsc2U7XHJcbiAgICBwcml2YXRlIF9jaGFydFR5cGU6IEFycmF5PHN0cmluZz47XHJcbiAgICBwcml2YXRlIF9jaGFydENhdGVnb3J5OiAncGllJyB8ICdiYXInIHwgJ2NvbHVtbicgfCAnbGluZScgfCAnYXJlYScgfCAnZG90JyB8ICdzcGxpbmUnIHwgJ21hcCc7XHJcbiAgICBwcml2YXRlIF9pc1JvdGF0ZTogYm9vbGVhbiA9IGZhbHNlO1xyXG4gICAgcHJpdmF0ZSBfbGFiZWxMZW5ndGg6IG51bWJlcjtcclxuICAgIHByaXZhdGUgX2N1cnJWZXJ0QXhpc1RpdGxlOiBFbGVtZW50O1xyXG4gICAgcHJpdmF0ZSBfaXNSdGw6IGJvb2xlYW4gPSBmYWxzZTtcclxuICAgIHByaXZhdGUgX2RlZmF1bHRTdmdNYXJnaW46IHsgdG9wOiBudW1iZXI7IHg6IG51bWJlcjsgeTogbnVtYmVyOyBvcHBWZXJ0OiBudW1iZXI7IH0gPSB7XHJcbiAgICAgICAgdG9wOiAyMCxcclxuICAgICAgICB4OiA5LFxyXG4gICAgICAgIHk6IDEyLFxyXG4gICAgICAgIG9wcFZlcnQ6IDIwXHJcbiAgICB9O1xyXG4gICAgcHJpdmF0ZSBfc3ZnTWFyZ2luOiB7IHRvcDogbnVtYmVyOyByaWdodDogbnVtYmVyOyBib3R0b206IG51bWJlcjsgbGVmdDogbnVtYmVyOyB9ID0ge1xyXG4gICAgICAgIHRvcDogMCxcclxuICAgICAgICByaWdodDogMCxcclxuICAgICAgICBib3R0b206IDAsXHJcbiAgICAgICAgbGVmdDogMFxyXG4gICAgfTtcclxuICAgIHByaXZhdGUgX3lBeGlzTGFiZWxXaWR0aDogSVlBeGlzTGFiZWxSYW5nZSA9IHtcclxuICAgICAgICBheGlzTWF4OiAwLFxyXG4gICAgICAgIGF4aXNNaW46IDBcclxuICAgIH07XHJcbiAgICBwcml2YXRlIF9heGlzTGFiZWxDb250YWluZXI6IGFueTtcclxuICAgIHByaXZhdGUgX2F4aXNMYWJlbER1bW15OiBhbnk7XHJcbiAgICBwcml2YXRlIF9heGlzTGFiZWxDb250YWluZXJNYXJnaW5MZWZ0OiBudW1iZXI7XHJcbiAgICBwcml2YXRlIF9taW5YU3BhY2luZzogbnVtYmVyID0gNTA7XHJcbiAgICBwcml2YXRlIF94U3BhY2luZzogbnVtYmVyO1xyXG4gICAgcHJpdmF0ZSBfeFNjYWxlVHlwZTogJ3N0cmluZycgfCAnYmFuZCc7XHJcbiAgICBwcml2YXRlIF9heGlzRDNGb3JtYXQ6IHN0cmluZyA9ICcnO1xyXG4gICAgcHJpdmF0ZSBfaXNYUmV2ZXJzZWQ6IGJvb2xlYW4gPSBmYWxzZTtcclxuICAgIHByaXZhdGUgX2lzWVJldmVyc2VkOiBib29sZWFuID0gZmFsc2U7XHJcbiAgICBwcml2YXRlIGRhdGFMYWJlbFB1c2hEb3duUmFuZ2U6IG51bWJlciA9IDA7XHJcbiAgICBwcml2YXRlIF9pc05lZ2F0aXZlU3RhY2s6IGJvb2xlYW4gPSBmYWxzZTtcclxuXHJcbiAgICBwdWJsaWMgZ3JpZFN2YzogaGVscGVyLktkQ2hhcnRzR3JpZFN2YztcclxuICAgIHB1YmxpYyB0b29sdGlwU3ZjOiBoZWxwZXIuS2RDaGFydHNUb29sdGlwU3ZjO1xyXG5cclxuICAgIGNvbnN0cnVjdG9yKHByaXZhdGUgX2RvbVN2YzogS2REb21FbGVtU3ZjKSB7XHJcbiAgICAgICAgdGhpcy5ncmlkU3ZjID0gbmV3IGhlbHBlci5LZENoYXJ0c0dyaWRTdmModGhpcy5fY29uZmlnKTtcclxuICAgICAgICB0aGlzLnRvb2x0aXBTdmMgPSBuZXcgaGVscGVyLktkQ2hhcnRzVG9vbHRpcFN2YygpO1xyXG4gICAgfVxyXG5cclxuICAgIHNldCBjb25maWcoX2NvbmZpZykge1xyXG4gICAgICAgIHRoaXMuX2NvbmZpZyA9IF9jb25maWc7XHJcbiAgICAgICAgdGhpcy5ncmlkU3ZjLmNvbmZpZyA9IF9jb25maWc7XHJcbiAgICB9XHJcbiAgICBnZXQgY29uZmlnKCk6IElDaGFydENvbmZpZyB7IHJldHVybiB0aGlzLl9jb25maWc7IH1cclxuXHJcbiAgICBzZXQgc3ZnKF9zdmcpIHsgdGhpcy5fc3ZnID0gX3N2ZzsgfVxyXG5cclxuICAgIHNldCBzdmdSZWN0KF9zdmdSZWN0KSB7IHRoaXMuX3N2Z1JlY3QgPSBfc3ZnUmVjdDsgfVxyXG5cclxuICAgIHNldCBjaGFydFR5cGUoX2NoYXJ0VHlwZSkgeyB0aGlzLl9jaGFydFR5cGUgPSBfY2hhcnRUeXBlOyB9XHJcbiAgICBzZXQgY2hhcnRDYXRlZ29yeShfY2hhcnRDYXRlZ29yeSkgeyB0aGlzLl9jaGFydENhdGVnb3J5ID0gX2NoYXJ0Q2F0ZWdvcnk7IH1cclxuXHJcbiAgICBzZXQgaXNJbnZlcnQoX2lzSW52ZXJ0KSB7XHJcbiAgICAgICAgdGhpcy5faXNJbnZlcnQgPSBfaXNJbnZlcnQ7XHJcbiAgICAgICAgdGhpcy5ncmlkU3ZjLmlzSW52ZXJ0ID0gX2lzSW52ZXJ0O1xyXG4gICAgfVxyXG5cclxuICAgIHNldCBzdmdQYXJlbnRSZWN0KF9zdmdQYXJlbnRSZWN0KSB7IHRoaXMuX3N2Z1BhcmVudFJlY3QgPSBfc3ZnUGFyZW50UmVjdDsgfVxyXG5cclxuICAgIHNldCBpc1JvdGF0ZShfaXNSb3RhdGUpIHsgdGhpcy5faXNSb3RhdGUgPSBfaXNSb3RhdGU7IH1cclxuICAgIGdldCBpc1JvdGF0ZSgpOiBib29sZWFuIHsgcmV0dXJuIHRoaXMuX2lzUm90YXRlOyB9XHJcblxyXG4gICAgc2V0IGxhYmVsTGVuZ3RoKF9sYWJlbExlbmd0aCkgeyB0aGlzLl9sYWJlbExlbmd0aCA9IF9sYWJlbExlbmd0aDsgfVxyXG4gICAgZ2V0IGxhYmVsTGVuZ3RoKCk6IG51bWJlciB7IHJldHVybiB0aGlzLl9sYWJlbExlbmd0aDsgfVxyXG5cclxuICAgIGdldCBzdmdNYXJnaW4oKSB7IHJldHVybiB0aGlzLl9zdmdNYXJnaW47IH1cclxuXHJcbiAgICBzZXQgeFNjYWxlVHlwZShfeFNjYWxlVHlwZSkgeyB0aGlzLl94U2NhbGVUeXBlID0gX3hTY2FsZVR5cGU7IH1cclxuICAgIGdldCB4U2NhbGVUeXBlKCkgeyByZXR1cm4gdGhpcy5feFNjYWxlVHlwZTsgfVxyXG5cclxuICAgIGdldCB4U3BhY2luZygpIHsgcmV0dXJuIHRoaXMuX3hTcGFjaW5nOyB9XHJcblxyXG4gICAgZ2V0IGF4aXNEM0Zvcm1hdCgpIHsgcmV0dXJuIHRoaXMuX2F4aXNEM0Zvcm1hdDsgfVxyXG5cclxuICAgIGdldCB5QXhpc0xhYmVsV2lkdGgoKSB7IHJldHVybiB0aGlzLl95QXhpc0xhYmVsV2lkdGg7IH1cclxuXHJcbiAgICBzZXQgaXNSdGwoX2lzUnRsKSB7IHRoaXMuX2lzUnRsID0gX2lzUnRsOyB9XHJcblxyXG4gICAgc2V0IGlzWFJldmVyc2VkKF9pc1hSZXZlcnNlZCkge1xyXG4gICAgICAgIGlmICghdGhpcy5faXNJbnZlcnQpIHtcclxuICAgICAgICAgICAgdGhpcy5faXNYUmV2ZXJzZWQgPSBfaXNYUmV2ZXJzZWQgIT09IHRoaXMuX2lzUnRsO1xyXG4gICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgIHRoaXMuX2lzWFJldmVyc2VkID0gX2lzWFJldmVyc2VkO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuICAgIGdldCBpc1hSZXZlcnNlZCgpIHsgcmV0dXJuIHRoaXMuX2lzWFJldmVyc2VkOyB9XHJcblxyXG4gICAgc2V0IGlzWVJldmVyc2VkKF9pc1lSZXZlcnNlZCkge1xyXG4gICAgICAgIGlmICh0aGlzLl9pc0ludmVydCkge1xyXG4gICAgICAgICAgICB0aGlzLl9pc1lSZXZlcnNlZCA9IF9pc1lSZXZlcnNlZCAhPT0gdGhpcy5faXNSdGw7XHJcbiAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgdGhpcy5faXNZUmV2ZXJzZWQgPSBfaXNZUmV2ZXJzZWQ7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG4gICAgZ2V0IGlzWVJldmVyc2VkKCkgeyByZXR1cm4gdGhpcy5faXNZUmV2ZXJzZWQ7IH1cclxuXHJcbiAgICBzZXQgaXNOZWdhdGl2ZVN0YWNrKF9pc05lZ2F0aXZlU3RhY2s6IGJvb2xlYW4pIHsgdGhpcy5faXNOZWdhdGl2ZVN0YWNrID0gX2lzTmVnYXRpdmVTdGFjazsgfVxyXG4gICAgZ2V0IGlzTmVnYXRpdmVTdGFjaygpOiBib29sZWFuIHsgcmV0dXJuIHRoaXMuX2lzTmVnYXRpdmVTdGFjazsgfVxyXG5cclxuICAgIC8vID09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PSBWZXJ0aWNhbCBBeGlzID09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT1cclxuXHJcbiAgICAvKipcclxuICAgICAqIGZvciByb3RhdGluZyB2ZXJ0aWNhbCBheGlzLiBpZiBheGlzIGlzIGVuYWJsZWQsIGFwcGVuZHMgY2xhc3MtbmFtZSAncm90YXRlLXRpdGxlJyB0byBrZCBjaGFydHMuXHJcbiAgICAgKiBwYXJhbSAge0FycmF5PHN0cmluZz59IF90eXBlICAgY2hhcnQgdHlwZTogaWYgaG9yaXpvbnRhbCBiYXIsIHVzZSB4QXhpcydzKHRoZSB2ZXJ0aWNhbCBheGlzKSBjb25maWdcclxuICAgICAqIHBhcmFtICB7YW55fSAgICAgICAgICAgX2NvbmZpZ1xyXG4gICAgICogcmV0dXJuIHtib29sZWFufVxyXG4gICAgICovXHJcbiAgICBwdWJsaWMgY2hlY2tSb3RhdGVUaXRsZUVuYWJsZWQoX3R5cGU6IEFycmF5PHN0cmluZz4sIF9jb25maWc6IGFueSk6IGJvb2xlYW4ge1xyXG4gICAgICAgIGxldCBheGlzQ29uZmlnOiBhbnkgPSBfdHlwZVswXSA9PT0gJ2JhcicgPyBfY29uZmlnLnhBeGlzIDogX2NvbmZpZy55QXhpcztcclxuICAgICAgICByZXR1cm4gYXhpc0NvbmZpZy5lbmFibGVkICYmIGF4aXNDb25maWcudGl0bGUudGV4dCAhPT0gJyc7XHJcbiAgICB9XHJcblxyXG4gICAgcHVibGljIHNldFZlcnRBeGlzQW5kQ2hhcnRNYXJnaW4oX2lkOiBzdHJpbmcpOiB2b2lkIHtcclxuICAgICAgICBsZXQgY2hhcnRDb250YWluZXI6IEVsZW1lbnQgPSBkb2N1bWVudC5xdWVyeVNlbGVjdG9yKCcjJyArIF9pZCArICcua2R4LWNoYXJ0cyAua2R4LWNoYXJ0LWNvbnRhaW5lcicpO1xyXG4gICAgICAgIGxldCBheGlzQ29uZmlnOiBhbnkgPSB0aGlzLl9pc0ludmVydCA/IHRoaXMuX2NvbmZpZy54QXhpcyA6IHRoaXMuX2NvbmZpZy55QXhpcztcclxuXHJcbiAgICAgICAgLy8gc2V0dGluZyBjc3MgZm9yIHZlcnRpY2FsIGF4aXNcclxuICAgICAgICBpZiAoYXhpc0NvbmZpZy5lbmFibGVkICYmIGF4aXNDb25maWcudGl0bGUudGV4dCAhPT0gJycpIHtcclxuICAgICAgICAgICAgbGV0IGN1cnJBeGlzVGl0bGVDbGFzczogc3RyaW5nID0gdGhpcy5faXNJbnZlcnQgPyAnLmtkeC1jaGFydHMtYXhpcy10aXRsZS14JyA6ICcua2R4LWNoYXJ0cy1heGlzLXRpdGxlLXknO1xyXG4gICAgICAgICAgICB0aGlzLl9jdXJyVmVydEF4aXNUaXRsZSA9IGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3IoJyMnICsgX2lkICsgJy5rZHgtY2hhcnRzICcgKyBjdXJyQXhpc1RpdGxlQ2xhc3MgKyAnLmtkeC1jaGFydHMtYXhpcy10aXRsZScpO1xyXG4gICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgIHRoaXMuX2N1cnJWZXJ0QXhpc1RpdGxlID0gbnVsbDtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIHRoaXMuc2V0Q2hhcnRDb250YWluZXJNYXJnaW4oY2hhcnRDb250YWluZXIpO1xyXG4gICAgfVxyXG5cclxuICAgIHB1YmxpYyByZXBvc2l0aW9uVmVydGljYWxBeGlzVGl0bGUoKTogdm9pZCB7XHJcbiAgICAgICAgaWYgKCF0aGlzLmlzVmFsdWVFeGlzdCh0aGlzLl9jdXJyVmVydEF4aXNUaXRsZSkpIHJldHVybjtcclxuXHJcbiAgICAgICAgbGV0IGF4aXNUaXRsZUNsYXNzOiBzdHJpbmcgPSB0aGlzLl9pc0ludmVydCA/ICcua2R4LWNoYXJ0cy1heGlzLXRpdGxlLXgnIDogJy5rZHgtY2hhcnRzLWF4aXMtdGl0bGUteSc7XHJcbiAgICAgICAgbGV0IGF4aXNUaXRsZVRleHRBcnI6IGFueSA9IGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3JBbGwoJyMnICsgdGhpcy5fY29uZmlnLmlkICsgJy5rZHgtY2hhcnRzICcgKyBheGlzVGl0bGVDbGFzcyArICcgLmtkeC1jaGFydHMtYXhpcy10aXRsZS10ZXh0Jyk7XHJcbiAgICAgICAgYXhpc1RpdGxlVGV4dEFyci5mb3JFYWNoKGF4aXNUaXRsZVRleHQgPT4ge1xyXG4gICAgICAgICAgICBheGlzVGl0bGVUZXh0LnN0eWxlLnRvcCA9IHRoaXMuX2N1cnJWZXJ0QXhpc1RpdGxlLmdldEJvdW5kaW5nQ2xpZW50UmVjdCgpLmhlaWdodCAvIDIgKyBheGlzVGl0bGVUZXh0LmdldEJvdW5kaW5nQ2xpZW50UmVjdCgpLmhlaWdodCAvIDIgKyAncHgnO1xyXG4gICAgICAgICAgICBheGlzVGl0bGVUZXh0LnN0eWxlLnZpc2liaWxpdHkgPSAndW5zZXQnO1xyXG4gICAgICAgIH0pO1xyXG4gICAgfVxyXG5cclxuICAgIC8vID09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PSBZIEF4aXMgTGFiZWwgPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PVxyXG5cclxuICAgIHB1YmxpYyBzZXRNYXhBbmRNaW4oX3lBeGlzQ29uZmlnOiBJWUF4aXNDb25maWcsIF9kYXRhUmFuZ2U6IElEM0RhdGFSYW5nZSk6IElNYXhNaW5JbnRlcnZhbCB7XHJcbiAgICAgICAgbGV0IG1heFZhbHVlOiBudW1iZXIgPSB0aGlzLmlzVmFsdWVFeGlzdChfeUF4aXNDb25maWcubWF4VmFsdWUpID8gX3lBeGlzQ29uZmlnLm1heFZhbHVlIDogX2RhdGFSYW5nZS5tYXg7XHJcbiAgICAgICAgbGV0IG1pblZhbHVlOiBudW1iZXIgPSB0aGlzLmlzVmFsdWVFeGlzdChfeUF4aXNDb25maWcubWluVmFsdWUpID8gX3lBeGlzQ29uZmlnLm1pblZhbHVlIDogX2RhdGFSYW5nZS5taW47XHJcblxyXG4gICAgICAgIC8vIGVuc3VyZSB0aGF0IG1pbiB2YWx1ZSB3aWxsIG5vdCBleGNlZWQgbWF4LCB2aWNlIHZlcnNlXHJcbiAgICAgICAgbWF4VmFsdWUgPSBNYXRoLm1heChtYXhWYWx1ZSwgbWluVmFsdWUpO1xyXG4gICAgICAgIG1pblZhbHVlID0gTWF0aC5taW4obWF4VmFsdWUsIG1pblZhbHVlKTtcclxuXHJcbiAgICAgICAgbGV0IGludGVydmFsOiBudW1iZXIgPSBkMy5tYXgoW195QXhpc0NvbmZpZy50aWNrSW50ZXJ2YWwsIF95QXhpc0NvbmZpZy5taW5vclRpY2tJbnRlcnZhbF0pO1xyXG5cclxuICAgICAgICBpZiAoIWludGVydmFsIHx8IGludGVydmFsIDw9IDApIGludGVydmFsID0gMTtcclxuXHJcbiAgICAgICAgLy8gdG8gcHJldmVudCB0aWNrIGNhbGN1bGF0aW9uIGNhdXNpbmcgc3RvcC1zY3JpcHQsIG9ubHkgYWxsb3cgYXQgbW9zdCBhcm91bmQgMTAwMCB0aWNrcyAoZXhjbHVkaW5nIGZpcnN0IHRpY2spXHJcbiAgICAgICAgbGV0IHNtYWxsZXN0UG9zc2libGVJbnRlcnZhbDogbnVtYmVyID0gKG1heFZhbHVlIC0gbWluVmFsdWUpIC8gMTAwMDtcclxuICAgICAgICBpZiAoc21hbGxlc3RQb3NzaWJsZUludGVydmFsID4gaW50ZXJ2YWwpIHtcclxuICAgICAgICAgICAgaW50ZXJ2YWwgPSB0aGlzLmlzSW50ZXJnZXIoaW50ZXJ2YWwpID8gTWF0aC5mbG9vcihzbWFsbGVzdFBvc3NpYmxlSW50ZXJ2YWwpIDogc21hbGxlc3RQb3NzaWJsZUludGVydmFsO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgcmV0dXJuIHtcclxuICAgICAgICAgICAgbWF4VmFsdWU6IG1heFZhbHVlLFxyXG4gICAgICAgICAgICBtaW5WYWx1ZTogbWluVmFsdWUsXHJcbiAgICAgICAgICAgIGludGVydmFsOiBpbnRlcnZhbFxyXG4gICAgICAgIH07XHJcbiAgICB9XHJcblxyXG4gICAgcHVibGljIHNldEF4aXNEM0Zvcm1hdChfaW50ZXJ2YWw6IG51bWJlcik6IHZvaWQge1xyXG4gICAgICAgIGxldCBkZWNpbWFsUGxhY2U6IG51bWJlciA9IHRoaXMuZmluZERlY2ltYWxQbGFjZShfaW50ZXJ2YWwpO1xyXG4gICAgICAgIHRoaXMuX2F4aXNEM0Zvcm1hdCA9IHRoaXMuZ2V0RDNGb3JtYXQoX2ludGVydmFsLCBkZWNpbWFsUGxhY2UpO1xyXG4gICAgfVxyXG5cclxuICAgIHB1YmxpYyBnZXRZQXhpc0xhYmVsVGV4dChfeUF4aXNDb25maWc6IElZQXhpc0NvbmZpZywgX3ZhbHVlOiBudW1iZXIpOiBzdHJpbmcge1xyXG4gICAgICAgIHJldHVybiB0aGlzLmdldExhYmVsVGV4dChfeUF4aXNDb25maWcubGFiZWxzLmZvcm1hdCwgX3ZhbHVlLCBmYWxzZSwgdGhpcy5fYXhpc0QzRm9ybWF0KTtcclxuICAgIH1cclxuXHJcbiAgICAvKipcclxuICAgICAqIFkgYXhpcyBsYWJlbCBkdW1teS4gYXBwZW5kcyB0ZXh0IGVsZW1lbnQgdG8gc3ZnIGFuZCByZXR1cm5zIHRoZSB3aWR0aCBvZiBsYWJlbFxyXG4gICAgICogcGFyYW0gIHtudW1iZXIgfCAgICAgIHN0cmluZ30gICAgICBfdmFsdWU6IGxhYmVsJ3MgdmFsdWVcclxuICAgICAqIHBhcmFtICB7c3RyaW5nfSAgICAgICAgICAgICAgICAgICAgX2NsYXNzOiBjbGFzcyBuYW1lIGZvciBkdW1teVxyXG4gICAgICogcmV0dXJuIHtudW1iZXJ9ICAgICAgICAgICAgICAgICAgICByZXR1cm5zIGFjdHVhbCByZW5kZXJlZCB3aWR0aCBvZiBsYWJlbFxyXG4gICAgICovXHJcbiAgICBwdWJsaWMgc2V0RHVtbXlBeGlzTGFiZWwoX3ZhbHVlOiBudW1iZXIsIF9jbGFzczogc3RyaW5nKTogbnVtYmVyIHtcclxuICAgICAgICAvLyBpZiAoIXRoaXMuX2NvbmZpZy55QXhpcy5lbmFibGVkKSByZXR1cm4gMDtcclxuXHJcbiAgICAgICAgbGV0IHlBeGlzQ29uZmlnOiBJWUF4aXNDb25maWcgPSB0aGlzLl9jb25maWcueUF4aXM7XHJcblxyXG4gICAgICAgIC8vIGlmIGF4aXMgaXMgZW5hYmxlZCwgZHJhdyBheGlzTWF4IHN0cmluZyBhbmQgYXhpc01pbiBzdHJpbmcgdG8gY29tcHV0ZSB0aGlzLndpZHRoL2hlaWdodFxyXG4gICAgICAgIGxldCB0ZXh0U2VsZWN0aW9uOiBhbnkgPSB0aGlzLl9zdmcuc2VsZWN0QWxsKCcuZHVtbXktJyArIF9jbGFzcyk7XHJcbiAgICAgICAgbGV0IHRleHQ6IHN0cmluZyA9IHRoaXMuZ2V0WUF4aXNMYWJlbFRleHQoeUF4aXNDb25maWcsIF92YWx1ZSk7XHJcblxyXG4gICAgICAgIC8vIGVsZW1lbnQgc2hvdWxkIG9ubHkgYmUgYXBwZW5kZWQgb25jZVxyXG4gICAgICAgIGlmICh0ZXh0U2VsZWN0aW9uLmVtcHR5KCkpIHRleHRTZWxlY3Rpb24gPSB0aGlzLl9zdmcuYXBwZW5kKCd0ZXh0Jyk7XHJcblxyXG4gICAgICAgIHRoaXMuc2V0U3ZnQXR0cmlidXRlKHRleHRTZWxlY3Rpb24sIE9iamVjdC5hc3NpZ24oe30sIHlBeGlzQ29uZmlnLmxhYmVscy5zdHlsZSwgeyBjbGFzczogJ2tkeC1jaGFydHMtZHVtbXkgZHVtbXktJyArIF9jbGFzcywgb3BhY2l0eTogMCB9KSk7XHJcblxyXG4gICAgICAgIHRleHRTZWxlY3Rpb24udGV4dCh0ZXh0KTtcclxuXHJcbiAgICAgICAgcmV0dXJuIHRleHRTZWxlY3Rpb24ubm9kZSgpLmdldEJCb3goKS53aWR0aDtcclxuICAgIH1cclxuXHJcbiAgICAvKipcclxuICAgICAqIGNoYXJ0IHdpZHRoIGFuZCBoZWlnaHQgaGF2ZSB0byBiZSBjYWxjdWxhdGVkIGJhc2VkIG9uIGhvdyBsb25nIHkgYXhpcyBsYWJlbHMgYXJlIChlZzogYSBsb3Qgb2Ygc3BhY2UgYWxsb2NhdGVkIGZvciAxLDAwMCwwMDAgYXMgY29tcGFyZWQgdG8gMTApXHJcbiAgICAgKiByZXR1cm5zIHRoaXMud2lkdGggb3IgdGhpcy5oZWlnaHQgZGVwZW5kaW5nIG9uIF9heGlzIGdpdmVuXHJcbiAgICAgKiBwYXJhbSAgeyd4J3wneSd9ICAgICAgICAgX2F4aXNcclxuICAgICAqIHBhcmFtICB7IGF4aXNNYXg6IG51bWJlciwgYXhpc01pbjogbnVtYmVyIH0gX2F4aXNWYWxcclxuICAgICAqIHJldHVybiB7bnVtYmVyfVxyXG4gICAgICovXHJcbiAgICBwdWJsaWMgZ2V0U3ZnT2Zmc2V0KF9heGlzOiAneCcgfCAneScsIF9heGlzVmFsOiBJWUF4aXNMYWJlbFJhbmdlKTogbnVtYmVyIHtcclxuICAgICAgICBsZXQgYXhpc09wcG9zaXRlOiBib29sZWFuID0gX2F4aXMgPT09ICd4JyA/IHRoaXMuX2NvbmZpZy55QXhpcy5vcHBvc2l0ZSA6IHRoaXMuX2NvbmZpZy54QXhpcy5vcHBvc2l0ZTtcclxuICAgICAgICBsZXQgb3Bwb3NpdGU6IGJvb2xlYW4gPSBheGlzT3Bwb3NpdGUgIT09IHRoaXMuX2lzUnRsO1xyXG4gICAgICAgIGxldCB5QXhpc0xhYmVsc05vdFZpc2libGU6IGJvb2xlYW4gPSAhdGhpcy5fY29uZmlnLnlBeGlzLmVuYWJsZWQgfHwgIXRoaXMuX2NvbmZpZy55QXhpcy5sYWJlbHMuZW5hYmxlZDtcclxuXHJcbiAgICAgICAgaWYgKF9heGlzID09PSAneCcpIHRoaXMuX3lBeGlzTGFiZWxXaWR0aCA9IHRoaXMuZ2V0WUF4aXNNYXhBbmRNaW5MYWJlbFdpZHRoKF9heGlzVmFsKTtcclxuXHJcbiAgICAgICAgbGV0IGludGVybmFsWUF4aXNMYWJlbFdpZHRoOiB7IGF4aXNNYXg6IG51bWJlciwgYXhpc01pbjogbnVtYmVyIH0gPSB0aGlzLl95QXhpc0xhYmVsV2lkdGg7XHJcbiAgICAgICAgaWYgKHlBeGlzTGFiZWxzTm90VmlzaWJsZSkgaW50ZXJuYWxZQXhpc0xhYmVsV2lkdGggPSB7IGF4aXNNYXg6IDAsIGF4aXNNaW46IDAgfTtcclxuXHJcbiAgICAgICAgaWYgKCF0aGlzLl9pc0ludmVydCkge1xyXG4gICAgICAgICAgICBpZiAoX2F4aXMgPT09ICd4Jykge1xyXG4gICAgICAgICAgICAgICAgbGV0IHN0YXJ0OiAncmlnaHQnIHwgJ2xlZnQnID0gb3Bwb3NpdGUgPyAncmlnaHQnIDogJ2xlZnQnO1xyXG4gICAgICAgICAgICAgICAgbGV0IGVuZDogJ3JpZ2h0JyB8ICdsZWZ0JyA9IG9wcG9zaXRlID8gJ2xlZnQnIDogJ3JpZ2h0JztcclxuICAgICAgICAgICAgICAgIHRoaXMuX3N2Z01hcmdpbltzdGFydF0gPSB0aGlzLl9kZWZhdWx0U3ZnTWFyZ2luLnkgKyBNYXRoLm1heChpbnRlcm5hbFlBeGlzTGFiZWxXaWR0aC5heGlzTWF4LCBpbnRlcm5hbFlBeGlzTGFiZWxXaWR0aC5heGlzTWluKTtcclxuICAgICAgICAgICAgICAgIHRoaXMuX3N2Z01hcmdpbltlbmRdID0gdGhpcy5fZGVmYXVsdFN2Z01hcmdpbi5vcHBWZXJ0O1xyXG4gICAgICAgICAgICAgICAgcmV0dXJuIHRoaXMuX3N2Z1JlY3Qud2lkdGggLSB0aGlzLl9zdmdNYXJnaW5bc3RhcnRdIC0gdGhpcy5fc3ZnTWFyZ2luW2VuZF07XHJcbiAgICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgICAgICBsZXQgc3RhcnQ6ICd0b3AnIHwgJ2JvdHRvbScgPSBheGlzT3Bwb3NpdGUgPyAnYm90dG9tJyA6ICd0b3AnO1xyXG4gICAgICAgICAgICAgICAgbGV0IGVuZDogJ3RvcCcgfCAnYm90dG9tJyA9IGF4aXNPcHBvc2l0ZSA/ICd0b3AnIDogJ2JvdHRvbSc7XHJcbiAgICAgICAgICAgICAgICBsZXQgbGFiZWxGb250U2l6ZTogbnVtYmVyID0geUF4aXNMYWJlbHNOb3RWaXNpYmxlID8gMCA6IHRoaXMucmVwbGFjZVN0cmluZ1dpdGhOdW1iZXIodGhpcy5fY29uZmlnLnlBeGlzLmxhYmVscy5zdHlsZS5mb250U2l6ZSk7XHJcbiAgICAgICAgICAgICAgICB0aGlzLl9zdmdNYXJnaW5bZW5kXSA9IE1hdGgubWF4KHRoaXMuX2RlZmF1bHRTdmdNYXJnaW4ueCwgMC41ICogbGFiZWxGb250U2l6ZSk7XHJcbiAgICAgICAgICAgICAgICB0aGlzLl9zdmdNYXJnaW5bc3RhcnRdID0gdGhpcy5pc05lZ2F0aXZlU3RhY2sgPyB0aGlzLl9zdmdNYXJnaW5bZW5kXSA6IHRoaXMuX2RlZmF1bHRTdmdNYXJnaW4udG9wO1xyXG4gICAgICAgICAgICAgICAgcmV0dXJuIHRoaXMuX3N2Z1JlY3QuaGVpZ2h0IC0gdGhpcy5fc3ZnTWFyZ2luW3N0YXJ0XSAtIHRoaXMuX3N2Z01hcmdpbltlbmRdO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgaWYgKF9heGlzID09PSAneCcpIHtcclxuICAgICAgICAgICAgICAgIGxldCBzdGFydDogJ3RvcCcgfCAnYm90dG9tJyA9IGF4aXNPcHBvc2l0ZSA/ICdib3R0b20nIDogJ3RvcCc7XHJcbiAgICAgICAgICAgICAgICBsZXQgZW5kOiAndG9wJyB8ICdib3R0b20nID0gYXhpc09wcG9zaXRlID8gJ3RvcCcgOiAnYm90dG9tJztcclxuICAgICAgICAgICAgICAgIGxldCBsYWJlbEZvbnRTaXplOiBudW1iZXIgPSB5QXhpc0xhYmVsc05vdFZpc2libGUgPyAwIDogdGhpcy5yZXBsYWNlU3RyaW5nV2l0aE51bWJlcih0aGlzLl9jb25maWcueUF4aXMubGFiZWxzLnN0eWxlLmZvbnRTaXplKTtcclxuICAgICAgICAgICAgICAgIHRoaXMuX3N2Z01hcmdpbltzdGFydF0gPSB0aGlzLl9kZWZhdWx0U3ZnTWFyZ2luLnRvcDtcclxuICAgICAgICAgICAgICAgIHRoaXMuX3N2Z01hcmdpbltlbmRdID0gdGhpcy5fZGVmYXVsdFN2Z01hcmdpbi55ICsgbGFiZWxGb250U2l6ZTtcclxuICAgICAgICAgICAgICAgIHJldHVybiB0aGlzLl9zdmdSZWN0LmhlaWdodCAtIHRoaXMuX3N2Z01hcmdpbltzdGFydF0gLSB0aGlzLl9zdmdNYXJnaW5bZW5kXTtcclxuICAgICAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgICAgIGxldCBzdGFydDogJ3JpZ2h0JyB8ICdsZWZ0JyA9IG9wcG9zaXRlID8gJ3JpZ2h0JyA6ICdsZWZ0JztcclxuICAgICAgICAgICAgICAgIGxldCBlbmQ6ICdyaWdodCcgfCAnbGVmdCcgPSBvcHBvc2l0ZSA/ICdsZWZ0JyA6ICdyaWdodCc7XHJcbiAgICAgICAgICAgICAgICBsZXQgc3RhcnRMYWJlbFdpZHRoOiBudW1iZXIgPSBvcHBvc2l0ZSA9PT0gdGhpcy5pc1lSZXZlcnNlZCA/IGludGVybmFsWUF4aXNMYWJlbFdpZHRoLmF4aXNNaW4gOiBpbnRlcm5hbFlBeGlzTGFiZWxXaWR0aC5heGlzTWF4O1xyXG4gICAgICAgICAgICAgICAgbGV0IGVuZExhYmVsV2lkdGg6IG51bWJlciA9IG9wcG9zaXRlID09PSB0aGlzLmlzWVJldmVyc2VkID8gaW50ZXJuYWxZQXhpc0xhYmVsV2lkdGguYXhpc01heCA6IGludGVybmFsWUF4aXNMYWJlbFdpZHRoLmF4aXNNaW47XHJcbiAgICAgICAgICAgICAgICB0aGlzLl9zdmdNYXJnaW5bc3RhcnRdID0gTWF0aC5tYXgodGhpcy5fZGVmYXVsdFN2Z01hcmdpbi54LCBzdGFydExhYmVsV2lkdGggLyAyKTtcclxuICAgICAgICAgICAgICAgIHRoaXMuX3N2Z01hcmdpbltlbmRdID0gdGhpcy5pc05lZ2F0aXZlU3RhY2sgPyBNYXRoLm1heCh0aGlzLl9kZWZhdWx0U3ZnTWFyZ2luLngsIGVuZExhYmVsV2lkdGggLyAyKSA6IGVuZExhYmVsV2lkdGggLyAyICsgdGhpcy5fZGVmYXVsdFN2Z01hcmdpbi5vcHBWZXJ0O1xyXG4gICAgICAgICAgICAgICAgcmV0dXJuIHRoaXMuX3N2Z1JlY3Qud2lkdGggLSB0aGlzLl9zdmdNYXJnaW5bc3RhcnRdIC0gdGhpcy5fc3ZnTWFyZ2luW2VuZF07XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgLyoqXHJcbiAgICAgKiByb3VuZCBheGlzTWF4L01pbiB2YWx1ZSB0byBpbnRlcnZhbCAoZWc6IE1heCB2YWx1ZSBpcyAxMCBidXQgaW50ZXJ2YWwgaXMgMywgc28gbWF4IHZhbHVlIHdpbGwgYmUgcm91bmRlZCB0byBlaXRoZXIgOSBvciAxMilcclxuICAgICAqIF9pc0F1dG9Sb3VuZFRvTmV4dEludGVydmFsIGlzIGVuYWJsZWQsIHJvdW5kIHRvIDEyXHJcbiAgICAgKiBfaXNBdXRvUm91bmRUb05leHRJbnRlcnZhbCBpcyBkaXNhYmxlZCwgcm91bmQgdG8gOVxyXG4gICAgICpcclxuICAgICAqIHBhcmFtICB7bnVtYmVyfSAgX3ZhbHVlXHJcbiAgICAgKiBwYXJhbSAge251bWJlcn0gIF9pbnRlcnZhbFxyXG4gICAgICogcGFyYW0gIHtib29sZWFufSBfaXNBdXRvUm91bmRUb05leHRJbnRlcnZhbFxyXG4gICAgICogcGFyYW0gIHsndXAnIHwgJ2Rvd24nfSAgICAgIF9yb3VuZERpclxyXG4gICAgICogcmV0dXJuIHtudW1iZXJ9XHJcbiAgICAgKi9cclxuICAgIHB1YmxpYyBzZXRBeGlzUm91bmRWYWx1ZShfdmFsdWU6IG51bWJlciwgX2ludGVydmFsOiBudW1iZXIsIF9pc0F1dG9Sb3VuZFRvTmV4dEludGVydmFsOiBib29sZWFuLCBfcm91bmREaXI6ICd1cCcgfCAnZG93bicpOiBudW1iZXIge1xyXG4gICAgICAgIC8vIGlmIHZhbHVlIGlzIDAsIGRvbid0IHJvdW5kXHJcbiAgICAgICAgaWYgKF92YWx1ZSA9PT0gMCkgcmV0dXJuIF92YWx1ZTtcclxuXHJcbiAgICAgICAgbGV0IGRlY2ltYWxQbGFjZXM6IG51bWJlciA9IE1hdGgubWF4KHRoaXMuZmluZERlY2ltYWxQbGFjZShfdmFsdWUpLCB0aGlzLmZpbmREZWNpbWFsUGxhY2UoX2ludGVydmFsKSk7XHJcblxyXG4gICAgICAgIGlmIChkZWNpbWFsUGxhY2VzICE9PSAwKSB7XHJcbiAgICAgICAgICAgIC8vIGlmIF92YWx1ZSBvciBfaW50ZXJ2YWwgaGF2ZSBkZWNpbWFsLCBjb252ZXJ0IHRoZW0gdG8gd2hvbGUgbnVtYmVyc1xyXG4gICAgICAgICAgICBfdmFsdWUgPSBfdmFsdWUgKiBNYXRoLnBvdygxMCwgZGVjaW1hbFBsYWNlcyk7XHJcbiAgICAgICAgICAgIF9pbnRlcnZhbCA9IF9pbnRlcnZhbCAqIE1hdGgucG93KDEwLCBkZWNpbWFsUGxhY2VzKTtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIGxldCBzaWduOiBudW1iZXIgPSBNYXRoLnNpZ24oX3ZhbHVlKTtcclxuICAgICAgICBsZXQgbmV3VmFsdWU6IG51bWJlciA9IF92YWx1ZSAtIF92YWx1ZSAlIF9pbnRlcnZhbDtcclxuXHJcbiAgICAgICAgaWYgKF9yb3VuZERpciA9PT0gJ3VwJykge1xyXG4gICAgICAgICAgICBpZiAoc2lnbiA8IDApIHtcclxuICAgICAgICAgICAgICAgIGlmICghX2lzQXV0b1JvdW5kVG9OZXh0SW50ZXJ2YWwpIG5ld1ZhbHVlID0gbmV3VmFsdWUgLSBfaW50ZXJ2YWw7XHJcbiAgICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgICAgICBpZiAoX2lzQXV0b1JvdW5kVG9OZXh0SW50ZXJ2YWwpIG5ld1ZhbHVlID0gbmV3VmFsdWUgKyBfaW50ZXJ2YWw7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICBpZiAoc2lnbiA8IDApIHtcclxuICAgICAgICAgICAgICAgIGlmIChfaXNBdXRvUm91bmRUb05leHRJbnRlcnZhbCkgbmV3VmFsdWUgPSBuZXdWYWx1ZSAtIF9pbnRlcnZhbDtcclxuICAgICAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgICAgIGlmICghX2lzQXV0b1JvdW5kVG9OZXh0SW50ZXJ2YWwpIG5ld1ZhbHVlID0gbmV3VmFsdWUgKyBfaW50ZXJ2YWw7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIGlmIChkZWNpbWFsUGxhY2VzICE9PSAwKSBuZXdWYWx1ZSA9IG5ld1ZhbHVlIC8gTWF0aC5wb3coMTAsIGRlY2ltYWxQbGFjZXMpO1xyXG5cclxuICAgICAgICByZXR1cm4gbmV3VmFsdWU7XHJcbiAgICB9XHJcblxyXG4gICAgcHVibGljIGdldFRpY2tWYWx1ZXMoX21pbjogbnVtYmVyLCBfbWF4OiBudW1iZXIsIF9pbnRlcnZhbDogbnVtYmVyKTogQXJyYXk8bnVtYmVyPiB7XHJcbiAgICAgICAgaWYgKCFfaW50ZXJ2YWwgfHwgdHlwZW9mIF9taW4gPT09ICd1bmRlZmluZWQnIHx8IHR5cGVvZiBfbWF4ID09PSAndW5kZWZpbmVkJykgcmV0dXJuIFtdO1xyXG5cclxuICAgICAgICBfbWF4ID0gdGhpcy5fZ2V0VXBwZXJCb3VuZEZvclRpY2tWYWx1ZXMoX21heCwgX2ludGVydmFsKTtcclxuXHJcbiAgICAgICAgcmV0dXJuIGQzLnJhbmdlKF9taW4sIF9tYXgsIF9pbnRlcnZhbCk7XHJcbiAgICB9XHJcblxyXG4gICAgLyoqXHJcbiAgICAgKiBzZXQgWSBheGlzIExhYmVsIENvbmZpZ1xyXG4gICAgICogcGFyYW0ge2FueX0gICAgICAgIF9heGlzIGlzIEVsZW1lbnQvZDMtc2VsZWN0aW9uXHJcbiAgICAgKiBwYXJhbSB7J3hBeGlzJyB8ICd5QXhpcyd9ICAgICBfZGlyZWN0aW9uXHJcbiAgICAgKi9cclxuICAgIHB1YmxpYyBzZXRBeGlzTGFiZWxDb25maWcoX2F4aXM6IGFueSwgX2RpcmVjdGlvbjogJ3gnIHwgJ3knKTogdm9pZCB7XHJcbiAgICAgICAgbGV0IGF4aXNEaXI6IHN0cmluZyA9IF9kaXJlY3Rpb24gKyAnQXhpcyc7XHJcbiAgICAgICAgaWYgKCF0aGlzLl9jb25maWdbYXhpc0Rpcl0pIHJldHVybjtcclxuICAgICAgICBsZXQgYXhpc0NvbmZpZyA9IHRoaXMuX2NvbmZpZ1theGlzRGlyXTtcclxuXHJcbiAgICAgICAgX2F4aXMuc2VsZWN0QWxsKCdwYXRoJylcclxuICAgICAgICAgICAgLmF0dHIoJ3N0cm9rZS13aWR0aCcsIGF4aXNDb25maWcubGluZVdpZHRoKVxyXG4gICAgICAgICAgICAuYXR0cignc3Ryb2tlJywgYXhpc0NvbmZpZy5saW5lQ29sb3IpO1xyXG5cclxuICAgICAgICBfYXhpcy5zZWxlY3RBbGwoJ2xpbmUnKVxyXG4gICAgICAgICAgICAuYXR0cignc3Ryb2tlLXdpZHRoJywgYXhpc0NvbmZpZy5saW5lV2lkdGgpXHJcbiAgICAgICAgICAgIC5hdHRyKCdzdHJva2UnLCBheGlzQ29uZmlnLmxpbmVDb2xvcik7XHJcblxyXG4gICAgICAgIGlmIChfZGlyZWN0aW9uID09PSAneCcgfHwgIWF4aXNDb25maWcuZW5hYmxlZCB8fCAhdGhpcy5fY29uZmlnW2F4aXNEaXJdLmxhYmVscy5lbmFibGVkKSB7XHJcbiAgICAgICAgICAgIHRoaXMuc2V0U3ZnQXR0cmlidXRlKF9heGlzLnNlbGVjdEFsbCgndGV4dCcpLCB7IGRpc3BsYXk6ICdub25lJyB9KTtcclxuICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICB0aGlzLnNldFN2Z0F0dHJpYnV0ZShfYXhpcy5zZWxlY3RBbGwoJ3RleHQnKSwgYXhpc0NvbmZpZy5sYWJlbHMuc3R5bGUpO1xyXG4gICAgICAgICAgICB0aGlzLnNldFN2Z0F0dHJpYnV0ZShfYXhpcy5zZWxlY3RBbGwoJ3RleHQnKSwgeyBjbGFzczogJ2tkeC1jaGFydHMtZGlzcGxheS1udW1iZXItaW5zaWRlLXN2ZyBrZHgtY2hhcnRzLWRpc3BsYXktbnVtYmVyJyB9KTtcclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgcHVibGljIGdldFlBeGlzTWF4QW5kTWluTGFiZWxXaWR0aChfYXhpc1ZhbDogSVlBeGlzTGFiZWxSYW5nZSk6IElZQXhpc0xhYmVsUmFuZ2Uge1xyXG4gICAgICAgIGxldCB3aWR0aE9iajogSVlBeGlzTGFiZWxSYW5nZSA9IHsgYXhpc01heDogMCwgYXhpc01pbjogMCB9O1xyXG5cclxuICAgICAgICAvLyBpZiAodGhpcy5fY29uZmlnLnlBeGlzLmxhYmVscy5lbmFibGVkKSB7XHJcbiAgICAgICAgd2lkdGhPYmouYXhpc01heCA9IHRoaXMuc2V0RHVtbXlBeGlzTGFiZWwoX2F4aXNWYWwuYXhpc01heCwgJ2F4aXNNYXgnKTtcclxuICAgICAgICB3aWR0aE9iai5heGlzTWluID0gdGhpcy5zZXREdW1teUF4aXNMYWJlbChfYXhpc1ZhbC5heGlzTWluLCAnYXhpc01pbicpO1xyXG4gICAgICAgIC8vIH1cclxuXHJcbiAgICAgICAgcmV0dXJuIHdpZHRoT2JqO1xyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX2dldFVwcGVyQm91bmRGb3JUaWNrVmFsdWVzKF9tYXg6IG51bWJlciwgX2ludGVydmFsOiBudW1iZXIpOiBudW1iZXIge1xyXG4gICAgICAgIGxldCBkZWNpbWFsUGxhY2VzOiBudW1iZXIgPSBNYXRoLm1heCh0aGlzLmZpbmREZWNpbWFsUGxhY2UoX21heCksIHRoaXMuZmluZERlY2ltYWxQbGFjZShfaW50ZXJ2YWwpKTtcclxuXHJcbiAgICAgICAgX21heCA9IF9tYXggKiBNYXRoLnBvdygxMCwgZGVjaW1hbFBsYWNlcyk7XHJcbiAgICAgICAgX2ludGVydmFsID0gX2ludGVydmFsICogTWF0aC5wb3coMTAsIGRlY2ltYWxQbGFjZXMpO1xyXG5cclxuICAgICAgICByZXR1cm4gKF9tYXggKyBfaW50ZXJ2YWwpIC8gTWF0aC5wb3coMTAsIGRlY2ltYWxQbGFjZXMpO1xyXG4gICAgfVxyXG5cclxuICAgIC8vID09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PSBYIEF4aXMgTGFiZWwgPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PVxyXG5cclxuICAgIC8qKlxyXG4gICAgICogc2V0IGF4aXMgTGFiZWwgQ29udGFpbmVyIChjdXJyZW50bHkgb25seSB1c2VkIGZvciBYIGF4aXMpXHJcbiAgICAgKiBwYXJhbSAge251bWJlcn0gX3hTcGFjaW5nXHJcbiAgICAgKiBwYXJhbSAge3N0cmluZ30gX2V4dHJhQ2xhc3NOYW1lIFtzYW1lIGxldmVsIGFzIC5rZHgtY2hhcnRzLWF4aXMtbGFiZWwtY29udGFpbmVyLiBBZGRpdGlvbmFsIGNsYXNzTmFtZSBpbiBjYXNlIG9mIGRvdWJsZUF4aXNdXHJcbiAgICAgKiByZXR1cm4ge2FueX1cclxuICAgICAqL1xyXG4gICAgcHVibGljIHNldEF4aXNMYWJlbENvbnRhaW5lcihfZXh0cmFDbGFzc05hbWU6IHN0cmluZyA9ICcnKTogYW55IHtcclxuICAgICAgICB0aGlzLl9heGlzTGFiZWxDb250YWluZXIgPSBkMy5zZWxlY3QoJyMnICsgdGhpcy5fY29uZmlnLmlkICsgJy5rZHgtY2hhcnRzIC5rZHgtY2hhcnRzLWF4aXMtbGFiZWwtY29udGFpbmVyJyArIF9leHRyYUNsYXNzTmFtZSk7XHJcbiAgICAgICAgaWYgKCF0aGlzLmlzVmFsdWVFeGlzdCh0aGlzLl9heGlzTGFiZWxDb250YWluZXIubm9kZSgpKSkgcmV0dXJuO1xyXG5cclxuICAgICAgICByZXR1cm4gdGhpcy5fYXhpc0xhYmVsQ29udGFpbmVyO1xyXG4gICAgfVxyXG5cclxuICAgIC8qKioqIEF4aXMgTGFiZWwgRHVtbXkgKioqKioqKi9cclxuXHJcbiAgICBwdWJsaWMgc2V0QXhpc0xhYmVsRHVtbXkoX2lkOiBzdHJpbmcsIF94U3BhY2luZzogbnVtYmVyLCBfbG9uZ2VzdFRleHQ6IHN0cmluZyk6IHZvaWQge1xyXG4gICAgICAgIHRoaXMuX3NldEF4aXNMYWJlbER1bW15RWxlbWVudChfaWQpO1xyXG4gICAgICAgIHRoaXMuc2V0QXhpc0xhYmVsRHVtbXlUZXh0KF9sb25nZXN0VGV4dCk7XHJcbiAgICAgICAgdGhpcy5pc1JvdGF0ZSA9IHRoaXMuX2NoZWNrUm90YXRlKHRoaXMuX2lzSW52ZXJ0LCBfeFNwYWNpbmcsIHRoaXMuX21pblhTcGFjaW5nKTtcclxuICAgICAgICB0aGlzLl9zZXRBeGlzTGFiZWxEdW1teVN0eWxlKF94U3BhY2luZyk7XHJcbiAgICB9XHJcblxyXG4gICAgcHVibGljIHNldEF4aXNMYWJlbER1bW15VGV4dChfbG9uZ2VzdFRleHQ6IHN0cmluZyk6IHZvaWQge1xyXG4gICAgICAgIGlmICghdGhpcy5fYXhpc0xhYmVsRHVtbXkpIHJldHVybjtcclxuICAgICAgICBfbG9uZ2VzdFRleHQgPSB0aGlzLmdldExhYmVsRm9ybWF0UmVwbGFjZSh0aGlzLmNvbmZpZy54QXhpcy5sYWJlbHMuZm9ybWF0LCBfbG9uZ2VzdFRleHQpO1xyXG4gICAgICAgIHRoaXMuX3NldEF4aXNMYWJlbER1bW15SHRtbChfbG9uZ2VzdFRleHQpO1xyXG4gICAgfVxyXG5cclxuICAgIHB1YmxpYyBnZXRBeGlzTGFiZWxEdW1teVJlY3QoKTogYW55IHtcclxuICAgICAgICBpZiAoIXRoaXMuX2F4aXNMYWJlbER1bW15KSByZXR1cm4gMDtcclxuICAgICAgICByZXR1cm4gdGhpcy5fYXhpc0xhYmVsRHVtbXkuZ2V0Qm91bmRpbmdDbGllbnRSZWN0KCk7XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfc2V0QXhpc0xhYmVsRHVtbXlFbGVtZW50KF9pZDogc3RyaW5nKTogdm9pZCB7XHJcbiAgICAgICAgaWYgKHR5cGVvZiB0aGlzLl9heGlzTGFiZWxEdW1teSA9PT0gJ3VuZGVmaW5lZCcpIHtcclxuICAgICAgICAgICAgdGhpcy5fYXhpc0xhYmVsRHVtbXkgPSBkb2N1bWVudC5xdWVyeVNlbGVjdG9yKCcjJyArIF9pZCArICcua2R4LWNoYXJ0cyAua2R4LWNoYXJ0cy1pbnZpc2libGUtYXhpcy1sYWJlbCcpO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF9zZXRBeGlzTGFiZWxEdW1teUh0bWwoX3RleHQ6IHN0cmluZyk6IHZvaWQge1xyXG4gICAgICAgIGlmICghdGhpcy5fYXhpc0xhYmVsRHVtbXkpIHJldHVybjtcclxuICAgICAgICB0aGlzLl9heGlzTGFiZWxEdW1teS5pbm5lckhUTUwgPSBfdGV4dDtcclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF9zZXRBeGlzTGFiZWxEdW1teVN0eWxlKF94U3BhY2luZzogbnVtYmVyKTogdm9pZCB7XHJcbiAgICAgICAgaWYgKCF0aGlzLl9pc0ludmVydCAmJiAhdGhpcy5pc1JvdGF0ZSkge1xyXG4gICAgICAgICAgICB0aGlzLl9heGlzTGFiZWxEdW1teS5zdHlsZS5tYXhXaWR0aCA9IF94U3BhY2luZyArICdweCc7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIC8qKioqIE90aGVycyAqKioqKioqL1xyXG5cclxuICAgIHByaXZhdGUgX2NoZWNrUm90YXRlKF9pc0ludmVydDogYm9vbGVhbiwgX3hTcGFjaW5nOiBudW1iZXIsIF9taW5YU3BhY2luZzogbnVtYmVyKTogYm9vbGVhbiB7XHJcbiAgICAgICAgLy8gaWYgZWFjaCBiYXIveFNwYWNpbmcgaGFzIGF0IGxlYXN0IDUwIHB4LCBkbyBub3Qgcm90YXRlLCBsZXQgdGhlIGxhYmVsIHdvcmQtd3JhcFxyXG4gICAgICAgIGlmIChfeFNwYWNpbmcgPj0gX21pblhTcGFjaW5nIHx8IF9pc0ludmVydCkgcmV0dXJuIGZhbHNlO1xyXG4gICAgICAgIC8vIHJvdGF0ZSBvbmx5IGlmIHhTcGFjaW5nIDwgNTBweCBBTkQgdGhlIGFjdHVhbCB0ZXh0KHdpdGggcGFkZGRpbmcpIGxlbmd0aCA+IGVhY2ggYmFyL3hTcGFjaW5nXHJcbiAgICAgICAgcmV0dXJuIHRoaXMuZ2V0QXhpc0xhYmVsRHVtbXlSZWN0KCkud2lkdGggPiBfeFNwYWNpbmc7XHJcbiAgICB9XHJcblxyXG4gICAgcHVibGljIF9zZXRBeGlzTGFiZWxMZW5ndGgoKTogdm9pZCB7XHJcbiAgICAgICAgbGV0IGxvbmdlc3RMZW5ndGg6IG51bWJlciA9IHRoaXMuZ2V0QXhpc0xhYmVsRHVtbXlSZWN0KCkud2lkdGggfHwgMCxcclxuICAgICAgICAgICAgc3ZnUGFyZW50UmVjdDogYW55ID0gdGhpcy5fc3ZnUGFyZW50UmVjdCxcclxuICAgICAgICAgICAgc3ZnTGVuZ3RoOiBudW1iZXIgPSAodGhpcy5faXNJbnZlcnQgPyBzdmdQYXJlbnRSZWN0LndpZHRoIDogc3ZnUGFyZW50UmVjdC5oZWlnaHQpIHx8IDAsXHJcbiAgICAgICAgICAgIGxhYmVsTGVuZ3RoOiBudW1iZXIgPSBNYXRoLm1pbihsb25nZXN0TGVuZ3RoLCAwLjMgKiBzdmdMZW5ndGgpO1xyXG5cclxuICAgICAgICB0aGlzLl9sYWJlbExlbmd0aCA9IGxhYmVsTGVuZ3RoO1xyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX2dldEF4aXNNYXJnaW4oX2lzSW52ZXJ0OiBib29sZWFuLCBfaXNSb3RhdGU6IGJvb2xlYW4pOiB7IHRvcDogbnVtYmVyOyBsZWZ0OiBudW1iZXI7IHJpZ2h0OiBudW1iZXI7IH0ge1xyXG4gICAgICAgIGxldCBheGlzTWFyZ2luOiB7IHRvcDogbnVtYmVyOyBsZWZ0OiBudW1iZXI7IHJpZ2h0OiBudW1iZXI7IH0gPSB7IHRvcDogMCwgbGVmdDogMCwgcmlnaHQ6IDAgfTtcclxuICAgICAgICBsZXQgb3Bwb3NpdGU6IGJvb2xlYW4gPSB0aGlzLl9jb25maWcueUF4aXMub3Bwb3NpdGUgfHwgZmFsc2U7XHJcblxyXG4gICAgICAgIGlmICghX2lzSW52ZXJ0KSB7XHJcbiAgICAgICAgICAgIGxldCB0aXRsZVdpZHRoOiBudW1iZXIgPSAwO1xyXG4gICAgICAgICAgICBsZXQgc2lkZTogJ3JpZ2h0JyB8ICdsZWZ0JyA9IHRoaXMuX2lzUnRsID8gJ3JpZ2h0JyA6ICdsZWZ0JztcclxuICAgICAgICAgICAgbGV0IHNpZ246IG51bWJlciA9IHRoaXMuX2lzUnRsID8gLTEgOiAxO1xyXG4gICAgICAgICAgICBvcHBvc2l0ZSA9IG9wcG9zaXRlICE9PSB0aGlzLl9pc1J0bDtcclxuXHJcbiAgICAgICAgICAgIGlmICghb3Bwb3NpdGUgJiYgdGhpcy5pc1ZhbHVlRXhpc3QodGhpcy5fY3VyclZlcnRBeGlzVGl0bGUpKSB7XHJcbiAgICAgICAgICAgICAgICB0aXRsZVdpZHRoID0gdGhpcy5fY3VyclZlcnRBeGlzVGl0bGUuZ2V0Qm91bmRpbmdDbGllbnRSZWN0KCkud2lkdGg7XHJcbiAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgIGF4aXNNYXJnaW5bc2lkZV0gPSBzaWduICogKHRoaXMuX3N2Z01hcmdpbi5sZWZ0ICsgdGl0bGVXaWR0aCk7XHJcbiAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgYXhpc01hcmdpbi50b3AgPSB0aGlzLl9zdmdNYXJnaW4udG9wO1xyXG4gICAgICAgICAgICBpZiAob3Bwb3NpdGUpIGF4aXNNYXJnaW4udG9wICs9IHRoaXMuX2dldEhvcml6VGl0bGVIZWlnaHQoKTtcclxuXHJcbiAgICAgICAgICAgIGF4aXNNYXJnaW4ucmlnaHQgPSAyO1xyXG4gICAgICAgIH1cclxuICAgICAgICByZXR1cm4gYXhpc01hcmdpbjtcclxuICAgIH1cclxuXHJcbiAgICBwdWJsaWMgc2V0QXhpc0xhYmVsQ29udGFpbmVyU3R5bGUoX2NvbnRhaW5lcjogYW55KTogdm9pZCB7XHJcbiAgICAgICAgbGV0IHN0eWxlVHlwZTogJ3dpZHRoJyB8ICdoZWlnaHQnID0gdGhpcy5faXNJbnZlcnQgPyAnd2lkdGgnIDogJ2hlaWdodCc7XHJcbiAgICAgICAgbGV0IHN0eWxlVmFsOiBudW1iZXIgPSB0aGlzLmxhYmVsTGVuZ3RoO1xyXG5cclxuICAgICAgICBpZiAoIXRoaXMuX2lzSW52ZXJ0ICYmICF0aGlzLmlzUm90YXRlKSB7XHJcbiAgICAgICAgICAgIHN0eWxlVmFsID0gdGhpcy5nZXRBeGlzTGFiZWxEdW1teVJlY3QoKS5oZWlnaHQ7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICBfY29udGFpbmVyLnN0eWxlKHN0eWxlVHlwZSwgc3R5bGVWYWwgKyAncHgnKTtcclxuICAgICAgICBpZiAoIXRoaXMuX2lzSW52ZXJ0KSBfY29udGFpbmVyLnN0eWxlKCd3aWR0aCcsICcxMDAlJyk7XHJcblxyXG4gICAgICAgIHRoaXMuX2F4aXNMYWJlbER1bW15LnN0eWxlLm1heFdpZHRoID0gJzEwMCUnO1xyXG5cclxuXHJcbiAgICAgICAgbGV0IG1hcmdpbjogeyB0b3A6IG51bWJlcjsgbGVmdDogbnVtYmVyOyByaWdodDogbnVtYmVyOyB9ID0gdGhpcy5fZ2V0QXhpc01hcmdpbih0aGlzLl9pc0ludmVydCwgdGhpcy5pc1JvdGF0ZSk7XHJcblxyXG4gICAgICAgIF9jb250YWluZXJcclxuICAgICAgICAgICAgLnN0eWxlKCdtYXJnaW4tdG9wJywgbWFyZ2luLnRvcCArICdweCcpXHJcbiAgICAgICAgICAgIC5zdHlsZSgnbWFyZ2luLXJpZ2h0JywgbWFyZ2luLnJpZ2h0ICsgJ3B4JylcclxuICAgICAgICAgICAgLnN0eWxlKCdtYXJnaW4tbGVmdCcsIG1hcmdpbi5sZWZ0ICsgJ3B4Jyk7XHJcblxyXG4gICAgICAgIHRoaXMuX2F4aXNMYWJlbENvbnRhaW5lck1hcmdpbkxlZnQgPSBtYXJnaW4ubGVmdDtcclxuICAgIH1cclxuXHJcbiAgICAvKipcclxuICAgICAqIHNldCBYIGF4aXMgTGFiZWwgUG9zaXRpb25cclxuICAgICAqIHBhcmFtIHthbnl9ICAgICBfbGFiZWxDb250YWluZXJcclxuICAgICAqIHBhcmFtIHtudW1iZXJ9ICBfdGlja1Bvc1xyXG4gICAgICogcGFyYW0ge0lBeGlzTGFiZWxCb29sZWFuQ2hlY2tzfSBfYm9vbGVhbkNoZWNrc1xyXG4gICAgICovXHJcbiAgICBwdWJsaWMgc2V0QXhpc0xhYmVsUG9zaXRpb24oX2xhYmVsQ29udGFpbmVyOiBhbnksIF90aWNrUG9zOiBudW1iZXIsIF9ib29sZWFuQ2hlY2tzOiBJQXhpc0xhYmVsQm9vbGVhbkNoZWNrcyk6IHZvaWQge1xyXG4gICAgICAgIGlmICh0aGlzLl9pc0ludmVydCB8fCBfYm9vbGVhbkNoZWNrcy5pc1JvdGF0ZSB8fCAoX2Jvb2xlYW5DaGVja3MuaXNMYXN0ICYmIHRoaXMuX3hTY2FsZVR5cGUgPT09ICdzdHJpbmcnKSkge1xyXG4gICAgICAgICAgICB0aGlzLl9kb21TdmMuYWRkQ2xhc3MoX2xhYmVsQ29udGFpbmVyLm5vZGUoKSwgJ2VsbGlwc2lzJyk7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICAvLyB3aGVuIHJvdGF0aW5nLCB0aGVyZSBzaG91bGRuJ3QgYmUgYW55IHBhZGRpbmcoLmtkeC1jaGFydHMtY2hpbGQtcGFkZGluZy1ib3RoKSBvciAnc3BlY2lhbCcgcGFkZGluZyAoLmtkeC1jaGFydHMtY2hpbGQtc3BlY2lhbC1wYWRkaW5nKVxyXG4gICAgICAgIC8vIG11c3QgZXhlY3V0ZSBiZWZvcmUgb2Zmc2V0IHBvc2l0aW9uXHJcbiAgICAgICAgaWYgKF9ib29sZWFuQ2hlY2tzLmlzUm90YXRlKSBfbGFiZWxDb250YWluZXIuc3R5bGUoJ3BhZGRpbmcnLCAwKTtcclxuXHJcbiAgICAgICAgbGV0IGxhYmVsUmVjdDogYW55ID0gX2xhYmVsQ29udGFpbmVyLm5vZGUoKS5nZXRCb3VuZGluZ0NsaWVudFJlY3QoKSxcclxuICAgICAgICAgICAgb2Zmc2V0OiBudW1iZXIgPSAhdGhpcy5faXNJbnZlcnQgJiYgIV9ib29sZWFuQ2hlY2tzLmlzUm90YXRlID8gbGFiZWxSZWN0LndpZHRoIC8gMiA6IGxhYmVsUmVjdC5oZWlnaHQgLyAyLFxyXG4gICAgICAgICAgICBvZmZTZXRTaWduOiBudW1iZXIgPSBfYm9vbGVhbkNoZWNrcy5pc1JvdGF0ZSAmJiBfYm9vbGVhbkNoZWNrcy5vcHBvc2l0ZSA/IC0xIDogMSxcclxuICAgICAgICAgICAgcG9zaXRpb246IG51bWJlciA9IF90aWNrUG9zIC0gb2Zmc2V0ICogb2ZmU2V0U2lnbjtcclxuXHJcbiAgICAgICAgLy8gZm9yIGhvcml6b250YWwgYmFyXHJcbiAgICAgICAgaWYgKHRoaXMuX2lzSW52ZXJ0KSB7XHJcbiAgICAgICAgICAgIGxldCBob3JpekRpcjogc3RyaW5nID0gdGhpcy5faXNSdGwgIT09IF9ib29sZWFuQ2hlY2tzLm9wcG9zaXRlID8gJ2xlZnQnIDogJ3JpZ2h0JztcclxuICAgICAgICAgICAgX2xhYmVsQ29udGFpbmVyXHJcbiAgICAgICAgICAgICAgICAuc3R5bGUoJ3RvcCcsIHBvc2l0aW9uICsgJ3B4JylcclxuICAgICAgICAgICAgICAgIC5zdHlsZShob3JpekRpciwgMCArICdweCcpO1xyXG4gICAgICAgICAgICByZXR1cm47XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICBsZXQgdmVydERpcjogc3RyaW5nID0gX2Jvb2xlYW5DaGVja3Mub3Bwb3NpdGUgPyAnYm90dG9tJyA6ICd0b3AnO1xyXG5cclxuICAgICAgICAvLyBmb3IgYWxsIG90aGVyIGF4aXMgY2hhcnRzXHJcbiAgICAgICAgaWYgKF9ib29sZWFuQ2hlY2tzLmlzUm90YXRlKSB7XHJcbiAgICAgICAgICAgIGxldCB2ZXJ0RGlzdDogbnVtYmVyID0gX2Jvb2xlYW5DaGVja3MuaXNSb3RhdGUgJiYgIV9ib29sZWFuQ2hlY2tzLm9wcG9zaXRlID8gbGFiZWxSZWN0LndpZHRoIDogMDtcclxuXHJcbiAgICAgICAgICAgIF9sYWJlbENvbnRhaW5lclxyXG4gICAgICAgICAgICAgICAgLnN0eWxlKHZlcnREaXIsIHZlcnREaXN0ICsgJ3B4JylcclxuICAgICAgICAgICAgICAgIC5zdHlsZSgndHJhbnNmb3JtJywgJ3JvdGF0ZSgtOTBkZWcpJyk7XHJcblxyXG4gICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgIGlmICh0aGlzLl94U2NhbGVUeXBlID09PSAnc3RyaW5nJykge1xyXG4gICAgICAgICAgICAgICAgLy8gd2hlbiBwb3NpdGlvbiBpcyBuZWdhdGl2ZSBhbmQgaXQncyBhYnNvbHV0ZSB2YWx1ZSBpcyBtb3JlIHRoYW4gdGhlIG1hcmdpbiBvZiBheGlzTGFiZWxDb250YWluZXJcclxuICAgICAgICAgICAgICAgIGlmIChwb3NpdGlvbiArIHRoaXMuX2F4aXNMYWJlbENvbnRhaW5lck1hcmdpbkxlZnQgPCAwKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgbGV0IGRpZmY6IG51bWJlciA9IE1hdGguYWJzKHBvc2l0aW9uKSAtIHRoaXMuX2F4aXNMYWJlbENvbnRhaW5lck1hcmdpbkxlZnQ7XHJcbiAgICAgICAgICAgICAgICAgICAgX2xhYmVsQ29udGFpbmVyLnN0eWxlKCdtYXgtd2lkdGgnLCAobGFiZWxSZWN0LndpZHRoIC0gMiAqIGRpZmYpICsgJ3B4Jyk7XHJcbiAgICAgICAgICAgICAgICAgICAgcG9zaXRpb24gPSAtMSAqIHRoaXMuX2F4aXNMYWJlbENvbnRhaW5lck1hcmdpbkxlZnQ7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICBpZiAoX2Jvb2xlYW5DaGVja3MuaXNMYXN0KSBfbGFiZWxDb250YWluZXIuc3R5bGUoJ21heC13aWR0aCcsIChsYWJlbFJlY3Qud2lkdGggLyAyICsgdGhpcy5fc3ZnTWFyZ2luLnJpZ2h0KSArICdweCcpO1xyXG4gICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICBfbGFiZWxDb250YWluZXIuc3R5bGUodmVydERpciwgMCArICdweCcpO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgX2xhYmVsQ29udGFpbmVyLnN0eWxlKCdsZWZ0JywgcG9zaXRpb24gKyAncHgnKTtcclxuICAgIH1cclxuXHJcbiAgICAvLyA9PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT0gRGF0YSBMYWJlbHMgPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PVxyXG5cclxuICAgIC8qKlxyXG4gICAgICogZGF0YSBsYWJlbHMgaGF2ZSB0byBiZSByZXBvc2l0aW9uZWQgYWNjb3JkaW5nIHRvIHRpdGxlIGFuZCBheGlzIExhYmVscydzIHdpZHRoIGFuZCBwb3NpdGlvblxyXG4gICAgICogcGFyYW0ge2FueX0gX2RhdGFMYWJlbENvbnRhaW5lciBkMy1zZWxlY3Rpb25cclxuICAgICAqIHBhcmFtIHthbnl9IF9heGlzTGFiZWxDb250YWluZXIgZDMtc2VsZWN0aW9uXHJcbiAgICAgKi9cclxuICAgIHB1YmxpYyByZXBvc2l0aW9uRGF0YUxhYmVsKF9kYXRhTGFiZWxDb250YWluZXI6IGFueSwgX2F4aXNMYWJlbENvbnRhaW5lcj86IGFueSk6IHZvaWQge1xyXG4gICAgICAgIGxldCBheGlzTGFiZWxDb250YWluZXJSZWN0ID0gdGhpcy5pc1ZhbHVlRXhpc3QoX2F4aXNMYWJlbENvbnRhaW5lcikgPyBfYXhpc0xhYmVsQ29udGFpbmVyLm5vZGUoKS5nZXRCb3VuZGluZ0NsaWVudFJlY3QoKSA6IHsgd2lkdGg6IDAsIGhlaWdodDogMCB9O1xyXG5cclxuICAgICAgICBsZXQgbGVmdDogbnVtYmVyID0gdGhpcy5fY2FsY3VsYXRlRGF0YUxhYmVsTGVmdChheGlzTGFiZWxDb250YWluZXJSZWN0LndpZHRoKTtcclxuICAgICAgICBsZXQgdG9wOiBudW1iZXIgPSB0aGlzLl9jYWxjdWxhdGVEYXRhTGFiZWxUb3AoYXhpc0xhYmVsQ29udGFpbmVyUmVjdC5oZWlnaHQpO1xyXG5cclxuICAgICAgICBfZGF0YUxhYmVsQ29udGFpbmVyXHJcbiAgICAgICAgICAgIC5zdHlsZSgnbGVmdCcsIGxlZnQgKyAncHgnKVxyXG4gICAgICAgICAgICAuc3R5bGUoJ3RvcCcsIHRvcCArICdweCcpO1xyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX2NhbGN1bGF0ZURhdGFMYWJlbExlZnQoX2xhYmVsV2lkdGgpOiBudW1iZXIge1xyXG4gICAgICAgIGxldCBvcHBvc2l0ZTogYm9vbGVhbiA9IHRoaXMuX2lzSW52ZXJ0ID8gdGhpcy5fY29uZmlnLnhBeGlzLm9wcG9zaXRlIDogdGhpcy5fY29uZmlnLnlBeGlzLm9wcG9zaXRlO1xyXG4gICAgICAgIGxldCBjaGFydE1hcmdpbkxlZnQ6IHN0cmluZyA9IHRoaXMuX2NvbmZpZy5jaGFydC5tYXJnaW4ubGVmdDtcclxuXHJcbiAgICAgICAgLy8gd2hlbiB2ZXJ0aWNhbCBheGlzIG9uIHJpZ2h0IChvbmx5IG9uZSBheGlzKSwgbGVmdCBzaWRlIGhhdmUgbm8gYXhpc1xyXG4gICAgICAgIC8vIE5PVEU6IGRvIG5vdCBydW4gdGhpcyBzdGVwIHdoZW4gY29sdW1uL2Jhci1zdGFjay1uZWdhdGl2ZSwgc2luY2UgYm90aCBsZWZ0IGFuZCByaWdodCBzaWRlIGhhdmUgdmVydGljYWwgYXhpc1xyXG4gICAgICAgIGlmIChvcHBvc2l0ZSAhPT0gdGhpcy5faXNSdGwgJiYgIXRoaXMuaXNOZWdhdGl2ZVN0YWNrKSB7XHJcbiAgICAgICAgICAgIHJldHVybiB0aGlzLl9zdmdNYXJnaW4ubGVmdCArIHRoaXMucmVwbGFjZVN0cmluZ1dpdGhOdW1iZXIoY2hhcnRNYXJnaW5MZWZ0KTtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIC8vIHdoZW4gdmVydGljYWwgYXhpcyBvbiBsZWZ0XHJcbiAgICAgICAgbGV0IHRpdGxlV2lkdGg6IG51bWJlciA9IHRoaXMuaXNWYWx1ZUV4aXN0KHRoaXMuX2N1cnJWZXJ0QXhpc1RpdGxlKSA/IHRoaXMuX2N1cnJWZXJ0QXhpc1RpdGxlLmdldEJvdW5kaW5nQ2xpZW50UmVjdCgpLndpZHRoIDogMDtcclxuICAgICAgICBsZXQgbGVmdDogbnVtYmVyID0gdGhpcy5yZXBsYWNlU3RyaW5nV2l0aE51bWJlcihjaGFydE1hcmdpbkxlZnQpO1xyXG5cclxuICAgICAgICBsZWZ0ICs9IHRoaXMuX2lzSW52ZXJ0ID8gdGl0bGVXaWR0aCArIF9sYWJlbFdpZHRoICsgdGhpcy5fc3ZnTWFyZ2luLmxlZnQgKyAyIDogdGl0bGVXaWR0aCArIHRoaXMuX3N2Z01hcmdpbi5sZWZ0O1xyXG5cclxuICAgICAgICByZXR1cm4gbGVmdDtcclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF9jYWxjdWxhdGVEYXRhTGFiZWxUb3AoX2xhYmVsSGVpZ2h0KTogbnVtYmVyIHtcclxuICAgICAgICBsZXQgb3Bwb3NpdGU6IGJvb2xlYW4gPSB0aGlzLl9pc0ludmVydCA/IHRoaXMuX2NvbmZpZy55QXhpcy5vcHBvc2l0ZSA6IHRoaXMuX2NvbmZpZy54QXhpcy5vcHBvc2l0ZTtcclxuXHJcbiAgICAgICAgLy8gd2hlbiBob3Jpem9udGFsIGF4aXMgaXMgYXQgYm90dG9tXHJcbiAgICAgICAgLy8gTk9URTogZG8gbm90IHJ1biB0aGlzIHN0ZXAgd2hlbiBjb2x1bW4vYmFyLXN0YWNrLW5lZ2F0aXZlLCBzaW5jZSBib3RoIGFib3ZlIGFuZCBiZWxvdyBoYXZlIGhvcml6b250YWwgYXhpc1xyXG4gICAgICAgIGlmICghb3Bwb3NpdGUgJiYgIXRoaXMuaXNOZWdhdGl2ZVN0YWNrKSB7XHJcbiAgICAgICAgICAgIHJldHVybiB0aGlzLl9zdmdNYXJnaW4udG9wICsgdGhpcy5yZXBsYWNlU3RyaW5nV2l0aE51bWJlcih0aGlzLl9jb25maWcuY2hhcnQubWFyZ2luLnRvcCk7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICAvLyB3aGVuIGhvcml6b250YWwgYXhpcyBvbiB0b3BcclxuICAgICAgICBsZXQgaG9yaXpUaXRsZUhlaWdodDogbnVtYmVyID0gdGhpcy5fZ2V0SG9yaXpUaXRsZUhlaWdodCgpO1xyXG4gICAgICAgIGxldCB0b3A6IG51bWJlciA9IHRoaXMucmVwbGFjZVN0cmluZ1dpdGhOdW1iZXIodGhpcy5fY29uZmlnLmNoYXJ0Lm1hcmdpbi50b3ApO1xyXG5cclxuICAgICAgICB0b3AgKz0gdGhpcy5faXNJbnZlcnQgPyBob3JpelRpdGxlSGVpZ2h0ICsgdGhpcy5fc3ZnTWFyZ2luLnRvcCA6IGhvcml6VGl0bGVIZWlnaHQgKyB0aGlzLl9zdmdNYXJnaW4udG9wICsgX2xhYmVsSGVpZ2h0O1xyXG5cclxuICAgICAgICByZXR1cm4gdG9wO1xyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX2dldEhvcml6VGl0bGVIZWlnaHQoKTogbnVtYmVyIHtcclxuICAgICAgICBsZXQgY2xhc3NOYW1lOiBzdHJpbmcgPSAnIycgKyB0aGlzLl9jb25maWcuaWQgKyAnLmtkeC1jaGFydHMgLmtkeC1jaGFydHMtYXhpcy10aXRsZSc7XHJcbiAgICAgICAgY2xhc3NOYW1lICs9IHRoaXMuX2lzSW52ZXJ0ID8gJy15JyA6ICcteCc7XHJcbiAgICAgICAgbGV0IGhvcml6VGl0bGVFbGVtZW50ID0gZG9jdW1lbnQucXVlcnlTZWxlY3RvcihjbGFzc05hbWUpO1xyXG5cclxuICAgICAgICByZXR1cm4gdGhpcy5pc1ZhbHVlRXhpc3QoaG9yaXpUaXRsZUVsZW1lbnQpID8gaG9yaXpUaXRsZUVsZW1lbnQuZ2V0Qm91bmRpbmdDbGllbnRSZWN0KCkuaGVpZ2h0IDogMDtcclxuICAgIH1cclxuXHJcbiAgICAvKioqKlZlcnRpY2FsIEFsaWduKioqKiovXHJcblxyXG4gICAgcHVibGljIF9nZXRMYWJlbFRleHRIZWlnaHQoKTogbnVtYmVyIHtcclxuICAgICAgICBsZXQgbGFiZWxTdHlsZTogeyBba2V5OiBzdHJpbmddOiBzdHJpbmcgfSA9IHRoaXMuX2NvbmZpZy5jaGFydC5sYWJlbHMuc3R5bGU7XHJcbiAgICAgICAgbGV0IGZvbnRTaXplOiBudW1iZXIgPSB0aGlzLnJlcGxhY2VTdHJpbmdXaXRoTnVtYmVyKGxhYmVsU3R5bGUuZm9udFNpemUpO1xyXG4gICAgICAgIGxldCBib3JkZXJXaWR0aDogbnVtYmVyID0gdGhpcy5yZXBsYWNlU3RyaW5nV2l0aE51bWJlcihsYWJlbFN0eWxlLmJvcmRlcldpZHRoKTtcclxuICAgICAgICByZXR1cm4gZm9udFNpemUgKiAxLjMgKyBib3JkZXJXaWR0aCAqIDI7XHJcbiAgICB9XHJcblxyXG4gICAgcHVibGljIF9jaGVja0JvdW5kYXJ5KF90eXBlOiBhbnksIF95UG9zaXRpb246IG51bWJlciwgX2NoYXJ0SGVpZ2h0OiBudW1iZXIsIF9kb3RTaXplOiBudW1iZXIgPSAwKTogYm9vbGVhbiB7XHJcbiAgICAgICAgbGV0IHRleHRTaXplOiBudW1iZXIgPSB0aGlzLl9nZXRMYWJlbFRleHRIZWlnaHQoKSArIF9kb3RTaXplIC8gMjtcclxuXHJcbiAgICAgICAgaWYgKF90eXBlID09PSAnbWF4Jykge1xyXG4gICAgICAgICAgICByZXR1cm4gX3lQb3NpdGlvbiAtIHRleHRTaXplIDwgdGhpcy5kYXRhTGFiZWxQdXNoRG93blJhbmdlO1xyXG4gICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgIHJldHVybiBfeVBvc2l0aW9uICsgdGV4dFNpemUgPiBfY2hhcnRIZWlnaHQgLSB0aGlzLmRhdGFMYWJlbFB1c2hEb3duUmFuZ2U7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIHB1YmxpYyBuZWVkT2Zmc2V0Rm9yQ29sdW1uKF92ZXJ0aWNhbEFsaWduOiAndG9wJyB8ICdtaWRkbGUnIHwgJ2JvdHRvbScsIF9wYXJhbXM6IHsgW2tleTogc3RyaW5nXTogYW55IH0gPSB7fSk6IGJvb2xlYW4gfCBudW1iZXIge1xyXG4gICAgICAgIGlmICghX3BhcmFtcy5kaW1lbnNpb25zKSByZXR1cm4gZmFsc2U7XHJcbiAgICAgICAgaWYgKF9wYXJhbXMudmFsdWVTaWduIDwgMCkge1xyXG4gICAgICAgICAgICBpZiAoX3ZlcnRpY2FsQWxpZ24gPT09ICd0b3AnKSByZXR1cm4gLTE7IC8vIG5lZWRzIG9mZnNldCwgcmV0dXJuaW5nIHRydWUgY29uZGl0aW9uXHJcbiAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgaWYgKF92ZXJ0aWNhbEFsaWduID09PSAnYm90dG9tJykgcmV0dXJuIDE7IC8vIG5lZWRzIG9mZnNldCwgcmV0dXJuaW5nIHRydWUgY29uZGl0aW9uXHJcbiAgICAgICAgfVxyXG4gICAgICAgIHJldHVybiBmYWxzZTtcclxuICAgIH1cclxuXHJcbiAgICAvLyBOT1RFOiBkYXRhIGxhYmVsIHZlcnRpY2FsIGFsaWduIGlzIG5vdCBkZWZpbmVkIGluIGRlZmF1bHQgY29uZmlnIChhcyBvZiB2My43LjAgYmVjb3MgYmVoYXZpb3VyIGNoYW5nZXMgd2l0aCBkaWZmZXJlbnQgY2hhcnQgdHlwZXMpXHJcbiAgICBwdWJsaWMgZ2V0RGVmYXVsdFZlcnRpY2FsQWxpZ24oX2NvbmZpZywgX3BhcmFtcyk6ICd0b3AnIHwgJ21pZGRsZScgfCAnYm90dG9tJyB7XHJcbiAgICAgICAgaWYgKF9jb25maWcuY2hhcnQubGFiZWxzLnZlcnRpY2FsQWxpZ24pIHJldHVybiBfY29uZmlnLmNoYXJ0LmxhYmVscy52ZXJ0aWNhbEFsaWduO1xyXG4gICAgICAgIGxldCBkZWZhdWx0VmFsdWU6ICd0b3AnIHwgJ21pZGRsZScgfCAnYm90dG9tJyA9ICd0b3AnO1xyXG4gICAgICAgIC8vIGZvciBjb2x1bW4sIG5lZ2F0aXZlIHZhbHVlcyBuZWVkIHRvIGJlIHBsYWNlZCBvbiBib3R0b21cclxuICAgICAgICBpZiAoX3BhcmFtcy52YWx1ZVNpZ24gPCAwKSBkZWZhdWx0VmFsdWUgPSAnYm90dG9tJztcclxuICAgICAgICByZXR1cm4gZGVmYXVsdFZhbHVlO1xyXG4gICAgfVxyXG5cclxuICAgIC8vID09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PSBHZW5lcmFsID09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT1cclxuXHJcbiAgICAvKipcclxuICAgICAqIGluIGFyYWJpYywgbnVtYmVycyBhcmUgaW4gbHRyIG1vZGUgKGVnOiBuZWdhdGl2ZSBzaWduIGlzIHR5cGVkIGZpcnN0KVxyXG4gICAgICogSGVuY2Ugd3JhcHBpbmcgYSBkaXYgYXJvdW5kIG51bWJlciAob25seSkgd2l0aCBjbGFzc05hbWUgJy5rZHgtY2hhcnRzLWRpc3BsYXktbnVtYmVyJyB0byBmb3JjZSBkaXJlY3Rpb246IGx0clxyXG4gICAgICogcGFyYW0gIHtudW1iZXJ9IF9udW1iZXJcclxuICAgICAqIHJldHVybiB7c3RyaW5nfVxyXG4gICAgICovXHJcbiAgICBwdWJsaWMgd3JhcE51bWJlckluSW5saW5lRGl2KF9udW1iZXI6IG51bWJlciB8IHN0cmluZyk6IHN0cmluZyB7XHJcbiAgICAgICAgcmV0dXJuICc8ZGl2IGNsYXNzPVwia2R4LWNoYXJ0cy1kaXNwbGF5LW51bWJlclwiIHN0eWxlPVwiZGlzcGxheTogaW5saW5lLWJsb2NrO1wiIGRpcj1cImx0clwiPicgKyBfbnVtYmVyICsgJzwvZGl2Pic7XHJcbiAgICB9XHJcblxyXG4gICAgcHVibGljIHJlcGxhY2VTdHJpbmdXaXRoTnVtYmVyKF92YWx1ZTogc3RyaW5nIHwgbnVtYmVyKTogbnVtYmVyIHtcclxuICAgICAgICBpZiAodHlwZW9mIF92YWx1ZSA9PT0gJ251bWJlcicpIHJldHVybiBfdmFsdWU7XHJcbiAgICAgICAgcmV0dXJuIHBhcnNlRmxvYXQoX3ZhbHVlLnJlcGxhY2UoL1teMC05Ll0vZywgJycpKTtcclxuICAgIH1cclxuXHJcbiAgICBwdWJsaWMgZ2V0Rm9yTG9vcFNlcXVlbmNlKF9jaGFydFR5cGU6IHN0cmluZ1tdKTogJ2FzY2VuZGluZycgfCAnZGVzY2VuZGluZycge1xyXG4gICAgICAgIHJldHVybiBfY2hhcnRUeXBlWzBdICE9PSAnYmFyJyAmJiAoX2NoYXJ0VHlwZVsxXSA9PT0gJ3N0YWNrJyB8fCBfY2hhcnRUeXBlWzFdID09PSAnMTAwJykgPyAnZGVzY2VuZGluZycgOiAnYXNjZW5kaW5nJztcclxuICAgIH1cclxuXHJcbiAgICBwdWJsaWMgZ2V0Rm9yTG9vcEluZm8oX3R5cGU6ICdhc2NlbmRpbmcnIHwgJ2Rlc2NlbmRpbmcnLCBhcnJMZW5ndGg6IG51bWJlcik6IElGb3JMb29wSW5mbyB7XHJcbiAgICAgICAgcmV0dXJuIHtcclxuICAgICAgICAgICAgc3RhcnQ6IF90eXBlID09PSAnYXNjZW5kaW5nJyA/IDAgOiBhcnJMZW5ndGggLSAxLFxyXG4gICAgICAgICAgICBlbmQ6IF90eXBlID09PSAnYXNjZW5kaW5nJyA/IGFyckxlbmd0aCA6IC0xLFxyXG4gICAgICAgICAgICBjaGVjazogX3R5cGUgPT09ICdhc2NlbmRpbmcnID8gKGksIGVuZCkgPT4gaSA8IGVuZCA6IChpLCBlbmQpID0+IGkgPiBlbmQsXHJcbiAgICAgICAgICAgIGl0ZXJhdGU6IF90eXBlID09PSAnYXNjZW5kaW5nJyA/IChpKSA9PiBpICsgMSA6IChpKSA9PiBpIC0gMSxcclxuICAgICAgICB9O1xyXG4gICAgfVxyXG5cclxuICAgIHB1YmxpYyBnZXRYSW5mbyhfZGF0YTogQXJyYXk8SUQzRGF0YURhdGE+LCBfY29uZmlnOiBJQ2hhcnRDb25maWcpOiBJWEluZm8ge1xyXG4gICAgICAgIGxldCB4SW5mbzogSVhJbmZvID0ge1xyXG4gICAgICAgICAgICB2YWx1ZTogW10sXHJcbiAgICAgICAgICAgIGxvbmdlc3RUZXh0OiAnJ1xyXG4gICAgICAgIH07XHJcbiAgICAgICAgbGV0IGxvbmdlc3RUZXh0V2lkdGg6IG51bWJlciA9IDA7XHJcbiAgICAgICAgbGV0IHNob3dWYWx1ZUluTGFiZWw6IGJvb2xlYW4gPSBfY29uZmlnLnhBeGlzLmxhYmVscy5mb3JtYXQuaW5kZXhPZigne3ZhbHVlfScpID4gLTEgJiYgX2NvbmZpZy54QXhpcy5lbmFibGVkICYmIF9jb25maWcueEF4aXMubGFiZWxzLmVuYWJsZWQ7XHJcbiAgICAgICAgaWYgKHNob3dWYWx1ZUluTGFiZWwpIHRoaXMuX3NldEF4aXNMYWJlbER1bW15RWxlbWVudChfY29uZmlnLmlkKTtcclxuXHJcbiAgICAgICAgX2RhdGEuZm9yRWFjaChkID0+IHtcclxuICAgICAgICAgICAgeEluZm8udmFsdWUucHVzaChkLngudmFsdWUpO1xyXG5cclxuICAgICAgICAgICAgLy8gaWYgbm8gdmFsdWUgbmVlZHMgdG8gYmUgc2hvd2VkIGluIGxhYmVsLCB0aGVuIG5vIG5lZWQgY2hlY2sgbG9uZ2VzdCB0ZXh0XHJcbiAgICAgICAgICAgIGlmIChzaG93VmFsdWVJbkxhYmVsKSB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLl9zZXRBeGlzTGFiZWxEdW1teUh0bWwoZC54LmxhYmVsKTtcclxuICAgICAgICAgICAgICAgIGxldCBjdXJyZW50V2lkdGg6IG51bWJlciA9IHRoaXMuZ2V0QXhpc0xhYmVsRHVtbXlSZWN0KCkud2lkdGg7XHJcbiAgICAgICAgICAgICAgICBpZiAoY3VycmVudFdpZHRoID4gbG9uZ2VzdFRleHRXaWR0aCkge1xyXG4gICAgICAgICAgICAgICAgICAgIGxvbmdlc3RUZXh0V2lkdGggPSBjdXJyZW50V2lkdGg7XHJcbiAgICAgICAgICAgICAgICAgICAgeEluZm8ubG9uZ2VzdFRleHQgPSBkLngubGFiZWw7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9KTtcclxuXHJcbiAgICAgICAgcmV0dXJuIHhJbmZvO1xyXG4gICAgfVxyXG5cclxuICAgIHB1YmxpYyBjaGVja0FuZFJldHVybkxhYmVsc1Bvc2l0aXZlKF92YWx1ZTogbnVtYmVyKTogbnVtYmVyIHtcclxuICAgICAgICBpZiAodGhpcy5pc05lZ2F0aXZlU3RhY2spIHtcclxuICAgICAgICAgICAgbGV0IHBsb3RPcHRpb25zOiBJUGxvdE9wdGlvbnMgPSB0aGlzLmNvbmZpZy5wbG90T3B0aW9ucztcclxuICAgICAgICAgICAgaWYgKHBsb3RPcHRpb25zICYmIHBsb3RPcHRpb25zLmJhciAmJiB0eXBlb2YgcGxvdE9wdGlvbnMuYmFyLmFsbExhYmVsc1Bvc2l0aXZlICE9PSAndW5kZWZpbmVkJykge1xyXG4gICAgICAgICAgICAgICAgcmV0dXJuIHRoaXMuY29uZmlnLnBsb3RPcHRpb25zLmJhci5hbGxMYWJlbHNQb3NpdGl2ZSA/IE1hdGguYWJzKF92YWx1ZSkgOiBfdmFsdWU7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgcmV0dXJuIE1hdGguYWJzKF92YWx1ZSk7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIHJldHVybiBfdmFsdWU7XHJcbiAgICB9XHJcblxyXG4gICAgcHVibGljIGZpbmREZWNpbWFsUGxhY2UoX251bWJlcjogbnVtYmVyKTogbnVtYmVyIHtcclxuICAgICAgICBpZiAocGFyc2VJbnQoX251bWJlci50b1N0cmluZygpKSA9PT0gX251bWJlcikgcmV0dXJuIDA7XHJcbiAgICAgICAgbGV0IHJlc3VsdDogbnVtYmVyID0gMDtcclxuICAgICAgICBsZXQgc3RyaW5nRm9ybTogc3RyaW5nID0gTWF0aC5hYnMoX251bWJlcikudG9TdHJpbmcoKTtcclxuICAgICAgICBsZXQgc3BsaXRCeURvdDogQXJyYXk8c3RyaW5nPiA9IHN0cmluZ0Zvcm0uc3BsaXQoJy4nKTtcclxuXHJcbiAgICAgICAgaWYgKHN0cmluZ0Zvcm0uaW5kZXhPZignZScpIDwgMCkge1xyXG4gICAgICAgICAgICByZXN1bHQgPSBzcGxpdEJ5RG90WzFdLmxlbmd0aDtcclxuICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICByZXN1bHQgPSBwYXJzZUludChzdHJpbmdGb3JtLnNwbGl0KCdlLScpWzFdKTtcclxuICAgICAgICAgICAgaWYgKHR5cGVvZiBzcGxpdEJ5RG90WzFdICE9PSAndW5kZWZpbmVkJykgcmVzdWx0ICs9IHNwbGl0QnlEb3RbMV0ubGVuZ3RoO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgcmV0dXJuIHJlc3VsdDtcclxuICAgIH1cclxuXHJcbiAgICBwdWJsaWMgZ2V0TGFiZWxUZXh0KF9mb3JtYXQ6IHN0cmluZywgX3ZhbHVlOiBudW1iZXIgfCBzdHJpbmcsIF9pc0hUTUw6IGJvb2xlYW4gPSB0cnVlLCBfZDNGb3JtYXQ/OiBzdHJpbmcpOiBzdHJpbmcge1xyXG4gICAgICAgIGxldCBkM0Zvcm1hdDogc3RyaW5nID0gdHlwZW9mIF9kM0Zvcm1hdCA9PT0gJ3VuZGVmaW5lZCcgPyB0aGlzLmdldEQzRm9ybWF0KF92YWx1ZSkgOiBfZDNGb3JtYXQ7XHJcbiAgICAgICAgbGV0IHRleHQ6IHN0cmluZyA9IHRoaXMuY2hhbmdlVmFsdWVUb0QzRm9ybWF0KF92YWx1ZSwgZDNGb3JtYXQpO1xyXG5cclxuICAgICAgICBpZiAoX2lzSFRNTCkgdGV4dCA9IHRoaXMud3JhcE51bWJlckluSW5saW5lRGl2KHRleHQpO1xyXG5cclxuICAgICAgICByZXR1cm4gdGhpcy5nZXRMYWJlbEZvcm1hdFJlcGxhY2UoX2Zvcm1hdCwgdGV4dCk7XHJcbiAgICB9XHJcblxyXG4gICAgcHVibGljIGdldExhYmVsRm9ybWF0UmVwbGFjZShfZm9ybWF0OiBzdHJpbmcsIF90ZXh0OiBzdHJpbmcpOiBzdHJpbmcge1xyXG4gICAgICAgIHJldHVybiBfZm9ybWF0LnJlcGxhY2UoL3t2YWx1ZX0vZywgX3RleHQpO1xyXG4gICAgfVxyXG5cclxuICAgIHB1YmxpYyBpc0ludGVyZ2VyKF92YWx1ZTogbnVtYmVyIHwgc3RyaW5nKTogYm9vbGVhbiB7XHJcbiAgICAgICAgcmV0dXJuIHR5cGVvZiBfdmFsdWUgPT09ICdudW1iZXInICYmIChfdmFsdWUgJSAxKSA9PT0gMDtcclxuICAgIH1cclxuXHJcbiAgICBwdWJsaWMgZ2V0RDNGb3JtYXQoX3ZhbHVlOiBzdHJpbmcgfCBudW1iZXIsIF90b0RlY2ltYWxQbGFjZT86IG51bWJlcik6IHN0cmluZyB7XHJcbiAgICAgICAgaWYgKHR5cGVvZiBfdmFsdWUgPT09ICdzdHJpbmcnKSByZXR1cm4gJyc7XHJcblxyXG4gICAgICAgIGlmIChNYXRoLmFicyhfdmFsdWUpID4gMTAwMDAwMDApIHJldHVybiAnLjJlJztcclxuXHJcbiAgICAgICAgaWYgKHRoaXMuaXNJbnRlcmdlcihfdmFsdWUpKSB7XHJcbiAgICAgICAgICAgIHJldHVybiAnLCc7XHJcbiAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgLy8gaXMgZGVjaW1hbFxyXG4gICAgICAgICAgICBpZiAoTWF0aC5hYnMoX3ZhbHVlKSA8IDAuMDAwMDAwMDEpIHJldHVybiAnLjJlJztcclxuXHJcbiAgICAgICAgICAgIGlmICh0eXBlb2YgX3RvRGVjaW1hbFBsYWNlICE9PSAndW5kZWZpbmVkJyAmJiBfdG9EZWNpbWFsUGxhY2UgIT09IDApIHtcclxuICAgICAgICAgICAgICAgIC8vIGlmIHByZWNpc2lvbiBpcyBnaXZlblxyXG4gICAgICAgICAgICAgICAgcmV0dXJuICcuJyArIF90b0RlY2ltYWxQbGFjZS50b1N0cmluZygpICsgJ2YnO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICByZXR1cm4gJyc7XHJcbiAgICB9XHJcblxyXG4gICAgcHVibGljIGNoYW5nZVZhbHVlVG9EM0Zvcm1hdChfdmFsdWU6IHN0cmluZyB8IG51bWJlciwgX2Zvcm1hdDogc3RyaW5nKTogc3RyaW5nIHtcclxuICAgICAgICBpZiAodHlwZW9mIF92YWx1ZSA9PT0gJ3N0cmluZycpIHJldHVybiBfdmFsdWU7XHJcbiAgICAgICAgcmV0dXJuIGQzLmZvcm1hdChfZm9ybWF0KShfdmFsdWUpO1xyXG4gICAgfVxyXG5cclxuICAgIHB1YmxpYyBnZXRMb25nZXJOdW1iZXIoX251bTE6IG51bWJlciwgX251bTI6IG51bWJlcik6IG51bWJlciB7XHJcbiAgICAgICAgcmV0dXJuIF9udW0xLnRvU3RyaW5nKCkubGVuZ3RoID4gX251bTIudG9TdHJpbmcoKS5sZW5ndGggPyBfbnVtMSA6IF9udW0yO1xyXG4gICAgfVxyXG5cclxuICAgIHB1YmxpYyBzZXRDaGFydENvbnRhaW5lck1hcmdpbihfY2hhcnRDb250YWluZXI6IGFueSk6IHZvaWQge1xyXG4gICAgICAgIGxldCBtYXJnaW46IElDaGFydE1hcmdpbiA9IHRoaXMuX2NvbmZpZy5jaGFydC5tYXJnaW47XHJcbiAgICAgICAgX2NoYXJ0Q29udGFpbmVyLnN0eWxlLnBhZGRpbmcgPSBtYXJnaW4udG9wICsgJyAnICsgbWFyZ2luLnJpZ2h0ICsgJyAnICsgbWFyZ2luLmJvdHRvbSArICcgJyArIG1hcmdpbi5sZWZ0O1xyXG4gICAgfVxyXG5cclxuICAgIHB1YmxpYyB0cmFuc2Zvcm1HcmFwaENvbnRhaW5lcihfY29udGFpbmVyOiBhbnkpOiB2b2lkIHtcclxuICAgICAgICBfY29udGFpbmVyLmF0dHIoJ3RyYW5zZm9ybScsICd0cmFuc2xhdGUoJyArIHRoaXMuX3N2Z01hcmdpbi5sZWZ0ICsgJywnICsgdGhpcy5fc3ZnTWFyZ2luLnRvcCArICcpJyk7XHJcbiAgICB9XHJcblxyXG4gICAgcHVibGljIHNldFN2Z0F0dHJpYnV0ZShfZWxlbWVudDogYW55LCBfY29uZmlnOiB7IFtrZXk6IHN0cmluZ106IHN0cmluZyB8IG51bWJlciB9KTogdm9pZCB7XHJcbiAgICAgICAgZm9yIChsZXQga2V5IGluIF9jb25maWcpIHtcclxuICAgICAgICAgICAgaWYgKCF0aGlzLmlzVmFsdWVFeGlzdChfY29uZmlnW2tleV0pKSBjb250aW51ZTtcclxuICAgICAgICAgICAgbGV0IGF0dHJpYnV0ZVN0cjogc3RyaW5nID0ga2V5ID09PSAnY29sb3InID8gJ2ZpbGwnIDoga2V5LnJlcGxhY2UoLyhbYS16QS1aXSkoPz1bQS1aXSkvZywgJyQxLScpLnRvTG93ZXJDYXNlKCk7XHJcbiAgICAgICAgICAgIF9lbGVtZW50LmF0dHIoYXR0cmlidXRlU3RyLCBfY29uZmlnW2tleV0pO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICBwdWJsaWMgaXNFeGlzdChfeUVsZW06IGFueSk6IGJvb2xlYW4ge1xyXG4gICAgICAgIHJldHVybiAodHlwZW9mIF95RWxlbSAhPT0gJ3VuZGVmaW5lZCcgJiYgX3lFbGVtICE9PSBudWxsICYmIF95RWxlbS52YWx1ZSAhPT0gbnVsbCk7XHJcbiAgICB9XHJcblxyXG4gICAgcHVibGljIGlzVmFsdWVFeGlzdChfdmFsOiBhbnkpOiBib29sZWFuIHtcclxuICAgICAgICByZXR1cm4gKHR5cGVvZiBfdmFsICE9PSAndW5kZWZpbmVkJyAmJiBfdmFsICE9PSBudWxsICYmIF92YWwgIT09ICcnKTtcclxuICAgIH1cclxuXHJcbiAgICBwdWJsaWMgZ2V0RDNNYXhPck1pbihfYXJyOiBBcnJheTxudW1iZXI+LCBfdHlwZTogJ21heCcgfCAnbWluJyk6IG51bWJlciB7XHJcbiAgICAgICAgaWYgKF90eXBlID09PSAnbWF4JykgcmV0dXJuIGQzLm1heChfYXJyKTtcclxuICAgICAgICBpZiAoX3R5cGUgPT09ICdtaW4nKSByZXR1cm4gZDMubWluKF9hcnIpO1xyXG4gICAgfVxyXG5cclxuICAgIHB1YmxpYyBnZXRBeGlzVHJhbnNmb3JtUG9zKF9heGlzOiAneCcgfCAneScsIF9vcHBvc2l0ZTogYm9vbGVhbiwgX3RyYW5zZm9ybVBvczogSUF4aXNUcmFuc2Zvcm1Qb3MpOiBzdHJpbmcge1xyXG4gICAgICAgIGlmICh0aGlzLl9pc0ludmVydCkge1xyXG4gICAgICAgICAgICBpZiAoX2F4aXMgPT09ICd4Jykge1xyXG4gICAgICAgICAgICAgICAgaWYgKF9vcHBvc2l0ZSkgcmV0dXJuIF90cmFuc2Zvcm1Qb3MucmlnaHQ7XHJcbiAgICAgICAgICAgICAgICByZXR1cm4gX3RyYW5zZm9ybVBvcy5sZWZ0O1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIGlmIChfYXhpcyA9PT0gJ3knKSB7XHJcbiAgICAgICAgICAgICAgICBpZiAoX29wcG9zaXRlKSByZXR1cm4gX3RyYW5zZm9ybVBvcy50b3A7XHJcbiAgICAgICAgICAgICAgICByZXR1cm4gX3RyYW5zZm9ybVBvcy5ib3R0b207XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICBpZiAoX2F4aXMgPT09ICd4Jykge1xyXG4gICAgICAgICAgICAgICAgaWYgKF9vcHBvc2l0ZSkgcmV0dXJuIF90cmFuc2Zvcm1Qb3MudG9wO1xyXG4gICAgICAgICAgICAgICAgcmV0dXJuIF90cmFuc2Zvcm1Qb3MuYm90dG9tO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIGlmIChfYXhpcyA9PT0gJ3knKSB7XHJcbiAgICAgICAgICAgICAgICBpZiAoX29wcG9zaXRlKSByZXR1cm4gX3RyYW5zZm9ybVBvcy5yaWdodDtcclxuICAgICAgICAgICAgICAgIHJldHVybiBfdHJhbnNmb3JtUG9zLmxlZnQ7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgcHVibGljIGdldExpbWl0ZWRDYXRlZ29yaWVzKF9pbml0Q2F0ZWdvcmllczogQXJyYXk8c3RyaW5nPiwgX3hUaHJlc2hvbGQ6IG51bWJlcik6IEFycmF5PHN0cmluZz4ge1xyXG4gICAgICAgIGlmICghX2luaXRDYXRlZ29yaWVzKSByZXR1cm4gW107XHJcbiAgICAgICAgcmV0dXJuIF94VGhyZXNob2xkICYmIF9pbml0Q2F0ZWdvcmllcy5sZW5ndGggPiBfeFRocmVzaG9sZCA/IF9pbml0Q2F0ZWdvcmllcy5zbGljZSgwLCBfeFRocmVzaG9sZCkgOiBfaW5pdENhdGVnb3JpZXM7XHJcbiAgICB9XHJcblxyXG4gICAgLyoqXHJcbiAgICAgKiByZXR1cm4gY29uZmlnIGludG8gY3NzIHN0cmluZyBzbyBjYW4gYmUgYWRkZWQgaW50byBlbGVtZW50XHJcbiAgICAgKiBwYXJhbSAge29iamVjdH0gIGRlZmF1bHRDb25maWcgY29uZmlnXHJcbiAgICAgKiBwYXJhbSAge2Jvb2xlYW59IGlzRm9yVG9vbHRpcCAgaWYgdG9vbHRpcCwgY29tcGFyZSBkZWZhdWx0IGNvbmZpZyB3aXRoIGNvbmZpZyBwYXNzIGZyb20gdXNlclxyXG4gICAgICogcmV0dXJuIHtzdHJpbmd9ICAgICAgICAgICAgICAgIGNzcyBzdHlsaW5nXHJcbiAgICAgKi9cclxuICAgIHB1YmxpYyBnZXRTdHlsZShkZWZhdWx0Q29uZmlnOiBvYmplY3QsIGlzRm9yVG9vbHRpcD86IGJvb2xlYW4pOiBzdHJpbmcge1xyXG4gICAgICAgIGxldCBjb25maWc6IG9iamVjdCA9IHt9O1xyXG4gICAgICAgIGlmIChpc0ZvclRvb2x0aXApIHtcclxuICAgICAgICAgICAgY29uZmlnID0gdGhpcy5fY29uZmlnLnRvb2x0aXAuc3R5bGU7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGxldCBzdHlsaW5nOiBzdHJpbmcgPSAnJztcclxuXHJcbiAgICAgICAgaWYgKGRlZmF1bHRDb25maWcpIHtcclxuICAgICAgICAgICAgZm9yIChsZXQgZGVmYXVsdEtleSBvZiBPYmplY3Qua2V5cyhkZWZhdWx0Q29uZmlnKSkge1xyXG4gICAgICAgICAgICAgICAgc3R5bGluZyArPSBkZWZhdWx0S2V5LnJlcGxhY2UoLyhbYS16QS1aXSkoPz1bQS1aXSkvZywgJyQxLScpLnRvTG93ZXJDYXNlKCk7XHJcbiAgICAgICAgICAgICAgICBzdHlsaW5nICs9ICc6JztcclxuICAgICAgICAgICAgICAgIHN0eWxpbmcgKz0gKGNvbmZpZyAmJiBjb25maWcuaGFzT3duUHJvcGVydHkoZGVmYXVsdEtleSkpID8gY29uZmlnW2RlZmF1bHRLZXldIDogZGVmYXVsdENvbmZpZ1tkZWZhdWx0S2V5XTtcclxuICAgICAgICAgICAgICAgIHN0eWxpbmcgKz0gJzsnO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgICAgIHJldHVybiBzdHlsaW5nO1xyXG4gICAgfVxyXG5cclxuICAgIC8vID09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PSBMaW5lIG9ubHkgPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PVxyXG5cclxuICAgIC8qKlxyXG4gICAgICogY2hlY2sgaWYgbGluZSBtaXNzaW5nXHJcbiAgICAgKiBwYXJhbSB7W3R5cGVdfSBfZGF0YSAgICAgICAgZGF0YVxyXG4gICAgICogcGFyYW0ge1t0eXBlXX0gX2RhdGFJbmRleCAgIHhJbmRleFxyXG4gICAgICogcGFyYW0ge1t0eXBlXX0gX3Nlcmllc0luZGV4IHlJbmRleCAvIHlWYWx1ZUluZGV4XHJcbiAgICAgKi9cclxuICAgIHB1YmxpYyBpc1Nlcmllc051bGwoX2RhdGE6IElDaGFydERhdGEgfCBBcnJheTxJRDNEYXRhRGF0YT4sIF9kYXRhSW5kZXg6IG51bWJlciwgX3Nlcmllc0luZGV4OiBudW1iZXIpOiB7XHJcbiAgICAgICAgaXNQcmV2TnVsbDogYm9vbGVhbixcclxuICAgICAgICBpc1ByZXZOb3ROdWxsOiBib29sZWFuLFxyXG4gICAgICAgIGlzTmV4dE51bGw6IGJvb2xlYW4sXHJcbiAgICAgICAgaXNOZXh0Tm90TnVsbDogYm9vbGVhbixcclxuICAgICAgICBpc0FwcGVhcmluZzogYm9vbGVhbixcclxuICAgICAgICBpc0Rpc2FwcGVhcmluZzogYm9vbGVhblxyXG4gICAgfSB7XHJcblxyXG4gICAgICAgIGxldCBjdXJyZW50VmFsOiBudW1iZXIgPSAwO1xyXG4gICAgICAgIGxldCBkYXRhTGVuZ3RoOiBudW1iZXIgPSAwO1xyXG4gICAgICAgIGxldCBpc0lDaGFydERhdGEgPSB0aGlzLl9pc0NoYXJ0RGF0YTtcclxuXHJcbiAgICAgICAgaWYgKGlzSUNoYXJ0RGF0YShfZGF0YSkpIHtcclxuICAgICAgICAgICAgY3VycmVudFZhbCA9IF9kYXRhLnNlcmllc1tfc2VyaWVzSW5kZXhdLmRhdGFbX2RhdGFJbmRleF0udmFsdWU7XHJcbiAgICAgICAgICAgIGRhdGFMZW5ndGggPSBfZGF0YS54QXhpcy5jYXRlZ29yaWVzLmxlbmd0aDtcclxuICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICBjdXJyZW50VmFsID0gX2RhdGFbX2RhdGFJbmRleF0ueVtfc2VyaWVzSW5kZXhdLnZhbHVlO1xyXG4gICAgICAgICAgICBkYXRhTGVuZ3RoID0gX2RhdGEubGVuZ3RoO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgZnVuY3Rpb24gZ2V0VmFsdWUod2hlbjogc3RyaW5nLCBpc051bGw6IGJvb2xlYW4pOiBib29sZWFuIHtcclxuICAgICAgICAgICAgbGV0IGluZGV4OiBudW1iZXIgPSAwO1xyXG4gICAgICAgICAgICBpZiAod2hlbiA9PT0gJ3ByZXYnKSB7XHJcbiAgICAgICAgICAgICAgICBpZiAoX2RhdGFJbmRleCA+IDApIHtcclxuICAgICAgICAgICAgICAgICAgICBpbmRleCA9IF9kYXRhSW5kZXggLSAxO1xyXG4gICAgICAgICAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgICAgICAgICByZXR1cm4gZmFsc2U7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgICAgICBpZiAoX2RhdGFJbmRleCA8IGRhdGFMZW5ndGggLSAxKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgaW5kZXggPSBfZGF0YUluZGV4ICsgMTtcclxuICAgICAgICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIGZhbHNlO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICBsZXQgdmFsdWU6IG51bWJlciA9IChpc0lDaGFydERhdGEoX2RhdGEpID8gX2RhdGEuc2VyaWVzW19zZXJpZXNJbmRleF0uZGF0YVtpbmRleF0udmFsdWUgOiBfZGF0YVtpbmRleF0ueVtfc2VyaWVzSW5kZXhdLnZhbHVlKTtcclxuXHJcbiAgICAgICAgICAgIGlmIChpc051bGwpIHtcclxuICAgICAgICAgICAgICAgIHJldHVybiB2YWx1ZSA9PT0gbnVsbDtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICByZXR1cm4gdmFsdWUgIT09IG51bGw7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICBsZXQgaXNQcmV2TnVsbDogYm9vbGVhbiA9IGdldFZhbHVlKCdwcmV2JywgdHJ1ZSk7XHJcbiAgICAgICAgbGV0IGlzUHJldk5vdE51bGw6IGJvb2xlYW4gPSBnZXRWYWx1ZSgncHJldicsIGZhbHNlKTtcclxuICAgICAgICBsZXQgaXNOZXh0TnVsbDogYm9vbGVhbiA9IGdldFZhbHVlKCduZXh0JywgdHJ1ZSk7XHJcbiAgICAgICAgbGV0IGlzTmV4dE5vdE51bGw6IGJvb2xlYW4gPSBnZXRWYWx1ZSgnbmV4dCcsIGZhbHNlKTtcclxuXHJcbiAgICAgICAgbGV0IGlzQXBwZWFyaW5nOiBib29sZWFuID0gaXNOZXh0Tm90TnVsbCAmJiBjdXJyZW50VmFsICE9PSBudWxsICYmIGlzUHJldk51bGw7XHJcblxyXG4gICAgICAgIGxldCBpc0Rpc2FwcGVhcmluZzogYm9vbGVhbiA9IGlzTmV4dE51bGwgJiYgY3VycmVudFZhbCAhPT0gbnVsbCAmJiBpc1ByZXZOb3ROdWxsO1xyXG5cclxuICAgICAgICByZXR1cm4ge1xyXG4gICAgICAgICAgICBpc1ByZXZOdWxsOiBpc1ByZXZOdWxsLFxyXG4gICAgICAgICAgICBpc1ByZXZOb3ROdWxsOiBpc1ByZXZOb3ROdWxsLFxyXG4gICAgICAgICAgICBpc05leHROdWxsOiBpc05leHROdWxsLFxyXG4gICAgICAgICAgICBpc05leHROb3ROdWxsOiBpc05leHROb3ROdWxsLFxyXG4gICAgICAgICAgICBpc0FwcGVhcmluZzogaXNBcHBlYXJpbmcsXHJcbiAgICAgICAgICAgIGlzRGlzYXBwZWFyaW5nOiBpc0Rpc2FwcGVhcmluZ1xyXG4gICAgICAgIH07XHJcbiAgICB9XHJcblxyXG4gICAgcHVibGljIF9pc0NoYXJ0RGF0YShvYmplY3Q6IGFueSk6IG9iamVjdCBpcyBJQ2hhcnREYXRhIHtcclxuICAgICAgICByZXR1cm4gJ3NlcmllcycgaW4gb2JqZWN0O1xyXG4gICAgfVxyXG5cclxuICAgIC8vID09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PSBLZCBDaGFydCBvbmx5ID09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT1cclxuXHJcbiAgICAvKipcclxuICAgICAqIHJlcXVpcmVkIGZvciBwZXJjZW50YWdlIGNhbGN1bGF0aW9uIG9mIDEwMCBzdGFjay4gcmV0dXJucyBhIGFycmF5IG9mIHRvdGFsIHN1bSBvZiBkYXRhIHZhbHVlIG9mIGVhY2ggY2F0ZWdvcmllcy5cclxuICAgICAqIHBhcmFtICB7QXJyYXk8SVNlcmllcz59IF9zZXJpZXNBcnJcclxuICAgICAqIHBhcmFtICB7QXJyYXk8c3RyaW5nPn0gIF9jYXRlZ29yaWVzXHJcbiAgICAgKiByZXR1cm4ge0FycmF5PG51bWJlcj59XHJcbiAgICAgKi9cclxuICAgIHB1YmxpYyBnZXRUb3RhbFN1bUFyckZyb21TZXJpZXMoX3Nlcmllc0FycjogQXJyYXk8SVNlcmllcz4sIF9jYXRlZ29yaWVzOiBBcnJheTxzdHJpbmc+LCBzZXJpZXNMZW5ndGg6IG51bWJlcik6IEFycmF5PG51bWJlcj4ge1xyXG4gICAgICAgIGxldCBzdW1BcnI6IEFycmF5PG51bWJlcj4gPSBbXTtcclxuICAgICAgICBmb3IgKGxldCBpID0gMDsgaSA8IF9jYXRlZ29yaWVzLmxlbmd0aDsgKytpKSB7XHJcbiAgICAgICAgICAgIGxldCBzdW06IG51bWJlciA9IDA7XHJcbiAgICAgICAgICAgIGZvciAobGV0IGogPSAwOyBqIDwgc2VyaWVzTGVuZ3RoOyArK2opIHtcclxuICAgICAgICAgICAgICAgIGlmICh0eXBlb2YgX3Nlcmllc0FycltqXS5kYXRhW2ldID09PSAndW5kZWZpbmVkJykgY29udGludWU7XHJcbiAgICAgICAgICAgICAgICBsZXQgY3VycmVudFZhbDogbnVtYmVyIHwgbnVsbCA9IF9zZXJpZXNBcnJbal0uZGF0YVtpXS52YWx1ZTtcclxuICAgICAgICAgICAgICAgIGlmICh0eXBlb2YgY3VycmVudFZhbCA9PT0gJ3VuZGVmaW5lZCcpIGNvbnRpbnVlO1xyXG4gICAgICAgICAgICAgICAgc3VtID0gKGN1cnJlbnRWYWwgPT09IG51bGwpID8gc3VtIDogc3VtICsgY3VycmVudFZhbDtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBzdW1BcnIucHVzaChzdW0pO1xyXG4gICAgICAgIH1cclxuICAgICAgICByZXR1cm4gc3VtQXJyO1xyXG4gICAgfVxyXG5cclxuICAgIC8vID09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PSBQaWUgb25seSA9PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09XHJcbiAgICAvKipcclxuICAgICAqIGNoZWNrIGlmIGxpbmUgbWlzc2luZ1xyXG4gICAgICogcGFyYW0ge1trZXk6IHN0cmluZ106IElMZWdlbmREYXRhfSBfbGVnZW5kRGF0YSBwaWUgY2hhcnQgbGVnZW5kIGRhdGFcclxuICAgICAqIHBhcmFtIHthbnl9IF9kYXRhIHBpZSBjaGFydCBkYXRhXHJcbiAgICAgKiBwYXJhbSB7SUNoYXJ0Q29uZmlnfSBfY29uZmlnIHBpZSBjaGFydCBsZWdlbmQgY29uZmlnXHJcbiAgICAgKi9cclxuICAgIHB1YmxpYyBzZXRQaWVEYXRhKF9sZWdlbmREYXRhOiB7IFtrZXk6IHN0cmluZ106IElMZWdlbmREYXRhIH0sIF9kYXRhOiBhbnksIF9jb25maWc6IElDaGFydENvbmZpZywgX3Nlcmllc1RocmVzaG9sZDogbnVtYmVyKToge1xyXG4gICAgICAgIHBpZURhdGE6IEFycmF5PGFueT4sXHJcbiAgICAgICAgcGllQ29sb3I6IEFycmF5PHN0cmluZz4sXHJcbiAgICAgICAgbGVnZW5kRGF0YTogeyBba2V5OiBzdHJpbmddOiBJTGVnZW5kRGF0YSB9LFxyXG4gICAgfSB7XHJcbiAgICAgICAgbGV0IHBpZURhdGE6IEFycmF5PGFueT4gPSBbXTtcclxuICAgICAgICBsZXQgcGllQ29sb3I6IEFycmF5PHN0cmluZz4gPSBbXTtcclxuICAgICAgICBsZXQgbGVnZW5kSWQ6IHN0cmluZztcclxuICAgICAgICBsZXQgcGllRGF0YUFycmF5TGVuZ3RoOiBudW1iZXIgPSAwO1xyXG4gICAgICAgIGxldCBjb25maWdEYXRhQXJyYXk6IEFycmF5PElMZWdlbmREYXRhPiA9IE9iamVjdC5rZXlzKF9sZWdlbmREYXRhKS5tYXAoa2V5ID0+IF9sZWdlbmREYXRhW2tleV0pO1xyXG4gICAgICAgIF9sZWdlbmREYXRhID0ge307XHJcbiAgICAgICAgZm9yIChsZXQgaSA9IDA7IGkgPCBfZGF0YS5kYXRhLmxlbmd0aDsgaSsrKSB7XHJcbiAgICAgICAgICAgIGZvciAobGV0IGogPSAwOyBqIDwgX2RhdGEuZGF0YVtpXS55Lmxlbmd0aDsgaisrKSB7XHJcbiAgICAgICAgICAgICAgICBmb3IgKGxldCBrID0gMDsgayA8IGNvbmZpZ0RhdGFBcnJheS5sZW5ndGg7IGsrKykge1xyXG4gICAgICAgICAgICAgICAgICAgIGlmIChfZGF0YS5kYXRhW2ldLnlbal1bJ2lkJ10gPT09IGNvbmZpZ0RhdGFBcnJheVtrXS5pZCkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAodHlwZW9mIF9kYXRhLnNlcmllc1swXS5kYXRhW2ldLnkgIT09ICd1bmRlZmluZWQnKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAoKF9zZXJpZXNUaHJlc2hvbGQgIT09IHVuZGVmaW5lZCAmJiBfc2VyaWVzVGhyZXNob2xkICE9PSBudWxsICYmIHBpZURhdGFBcnJheUxlbmd0aCA8IF9zZXJpZXNUaHJlc2hvbGQpIHx8IF9zZXJpZXNUaHJlc2hvbGQgPT09IHVuZGVmaW5lZCB8fCBfc2VyaWVzVGhyZXNob2xkID09PSBudWxsKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbGV0IGNvbG9yUG9pbnRlciA9IF9kYXRhLmRhdGFbaV0ueVtqXVsnY29sb3InXTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBsZXQgY29sb3JWYWx1ZSA9IChjb2xvclBvaW50ZXIgJiYgY29sb3JQb2ludGVyICE9IG51bGwgJiYgY29sb3JQb2ludGVyICE9IG51bGwpID8gY29sb3JQb2ludGVyIDogdGhpcy5nZXREZWZhdWx0Q29uZmlnKCdjb2xvcicsIHBpZURhdGFBcnJheUxlbmd0aCwgX2NvbmZpZyk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbGVnZW5kSWQgPSAnaWQnICsgcGllRGF0YUFycmF5TGVuZ3RoO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIF9sZWdlbmREYXRhW2xlZ2VuZElkXSA9IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgJ25hbWUnOiBfZGF0YS5kYXRhW2ldLnggKyAnICcgKyBjb25maWdEYXRhQXJyYXlba10ubmFtZSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgJ2lkJzogbGVnZW5kSWQsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICdzaGFwZSc6ICdjaXJjbGUnLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAneCc6IF9kYXRhLmRhdGFbaV0ueCArICcgJyArIGNvbmZpZ0RhdGFBcnJheVtrXS5uYW1lLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAneSc6IF9kYXRhLmRhdGFbaV0ueVtqXVsndmFsdWUnXSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgJ3hCYXNlJzogX2RhdGEuZGF0YVtpXS54LFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAnaW5kZXgnOiAncGllJyArIHBpZURhdGFBcnJheUxlbmd0aCxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgJ2NvbG9yJzogY29sb3JWYWx1ZSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgJ3Nlcmllc0luZGV4JzogaixcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgJ2RhdGFJbmRleCc6IGlcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9O1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHBpZUNvbG9yLnB1c2goY29sb3JWYWx1ZSk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcGllRGF0YS5wdXNoKHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgJ2lkJzogbGVnZW5kSWQsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICd4JzogX2RhdGEuZGF0YVtpXS54ICsgJyAnICsgY29uZmlnRGF0YUFycmF5W2tdLm5hbWUsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICd5JzogX2RhdGEuZGF0YVtpXS55W2pdWyd2YWx1ZSddLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAneEJhc2UnOiBfZGF0YS5kYXRhW2ldLngsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICdpbmRleCc6ICdwaWUnICsgcGllRGF0YUFycmF5TGVuZ3RoLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAnY29sb3InOiBjb2xvclZhbHVlLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAnc2VyaWVzSW5kZXgnOiBqLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAnZGF0YUluZGV4JzogaVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHBpZURhdGFBcnJheUxlbmd0aCsrO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGxldCByZXR1cm5QYXJhbXMgPSB7XHJcbiAgICAgICAgICAgICdwaWVEYXRhJzogcGllRGF0YSxcclxuICAgICAgICAgICAgJ3BpZUNvbG9yJzogcGllQ29sb3IsXHJcbiAgICAgICAgICAgICdsZWdlbmREYXRhJzogX2xlZ2VuZERhdGFcclxuICAgICAgICB9O1xyXG4gICAgICAgIHJldHVybiByZXR1cm5QYXJhbXM7XHJcbiAgICB9XHJcblxyXG4gICAgcHVibGljIHNpbmdsZVBpZURhdGFNYXNzYWdlKF9sZWdlbmREYXRhOiB7IFtrZXk6IHN0cmluZ106IElMZWdlbmREYXRhIH0sIF9kYXRhOiBhbnksIF9jb25maWc6IElDaGFydENvbmZpZywgX3Nlcmllc1RocmVzaG9sZDogbnVtYmVyKSB7XHJcbiAgICAgICAgbGV0IHBpZURhdGE6IEFycmF5PGFueT4gPSBbXTtcclxuICAgICAgICBsZXQgcGllQ29sb3I6IEFycmF5PHN0cmluZz4gPSBbXTtcclxuICAgICAgICBsZXQgbGVnZW5kSWQ6IHN0cmluZztcclxuICAgICAgICBsZXQgcGllRGF0YUFycmF5TGVuZ3RoOiBudW1iZXIgPSAwO1xyXG4gICAgICAgIF9sZWdlbmREYXRhID0ge307XHJcbiAgICAgICAgaWYgKF9kYXRhLnNlcmllcyAmJiBfZGF0YS5zZXJpZXNbMF0gJiYgX2RhdGEuc2VyaWVzWzBdLmRhdGEpIHtcclxuICAgICAgICAgICAgZm9yIChsZXQgaSA9IDA7IGkgPCBfZGF0YS5zZXJpZXNbMF0uZGF0YS5sZW5ndGg7IGkrKykge1xyXG4gICAgICAgICAgICAgICAgaWYgKHR5cGVvZiBfZGF0YS5zZXJpZXNbMF0uZGF0YVtpXS55ICE9PSAndW5kZWZpbmVkJykge1xyXG4gICAgICAgICAgICAgICAgICAgIGlmICgoX3Nlcmllc1RocmVzaG9sZCAhPSB1bmRlZmluZWQgJiYgX3Nlcmllc1RocmVzaG9sZCAhPSBudWxsICYmIHBpZURhdGFBcnJheUxlbmd0aCA8IF9zZXJpZXNUaHJlc2hvbGQpIHx8IF9zZXJpZXNUaHJlc2hvbGQgPT0gdW5kZWZpbmVkIHx8IF9zZXJpZXNUaHJlc2hvbGQgPT0gbnVsbCkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBsZXQgY29sb3JQb2ludGVyID0gX2RhdGEuc2VyaWVzWzBdLmRhdGFbaV1bJ2NvbG9yJ107XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGxldCBjb2xvclZhbHVlID0gKGNvbG9yUG9pbnRlciAmJiBjb2xvclBvaW50ZXIgIT0gbnVsbCAmJiBjb2xvclBvaW50ZXIgIT0gbnVsbCkgPyBjb2xvclBvaW50ZXIgOiB0aGlzLmdldERlZmF1bHRDb25maWcoJ2NvbG9yJywgcGllRGF0YUFycmF5TGVuZ3RoLCBfY29uZmlnKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgbGVnZW5kSWQgPSAnaWQnICsgcGllRGF0YUFycmF5TGVuZ3RoO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBfbGVnZW5kRGF0YVtsZWdlbmRJZF0gPSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAnbmFtZSc6IF9kYXRhLnNlcmllc1swXS5kYXRhW2ldLm5hbWUucmVwbGFjZSgvwqwvZywgJyAnKSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICdpZCc6IGxlZ2VuZElkLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgJ3NoYXBlJzogJ2NpcmNsZScsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAneCc6IF9kYXRhLnNlcmllc1swXS5kYXRhW2ldLm5hbWUsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAneSc6IF9kYXRhLnNlcmllc1swXS5kYXRhW2ldLnksXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAneEJhc2UnOiBfZGF0YS5zZXJpZXNbMF0uZGF0YVtpXS5uYW1lLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgJ2luZGV4JzogJ3BpZScgKyBwaWVEYXRhQXJyYXlMZW5ndGgsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAnY29sb3InOiBjb2xvclZhbHVlLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9O1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBwaWVDb2xvci5wdXNoKGNvbG9yVmFsdWUpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAoX2RhdGEuc2VyaWVzWzBdLmRhdGFbaV0ueSAmJiBfZGF0YS5zZXJpZXNbMF0uZGF0YVtpXS55ID4gMCkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcGllRGF0YS5wdXNoKHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAnaWQnOiBsZWdlbmRJZCxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAneCc6IF9kYXRhLnNlcmllc1swXS5kYXRhW2ldLm5hbWUsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgJ3knOiBfZGF0YS5zZXJpZXNbMF0uZGF0YVtpXS55LFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICd4QmFzZSc6IF9kYXRhLnNlcmllc1swXS5kYXRhW2ldLm5hbWUsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgJ2luZGV4JzogJ3BpZScgKyBwaWVEYXRhQXJyYXlMZW5ndGgsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgJ2NvbG9yJzogY29sb3JWYWx1ZSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICBwaWVEYXRhQXJyYXlMZW5ndGgrKztcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICAgICAgbGV0IHJldHVyblBhcmFtcyA9IHtcclxuICAgICAgICAgICAgJ3BpZURhdGEnOiBwaWVEYXRhLFxyXG4gICAgICAgICAgICAncGllQ29sb3InOiBwaWVDb2xvcixcclxuICAgICAgICAgICAgJ2xlZ2VuZERhdGEnOiBfbGVnZW5kRGF0YVxyXG4gICAgICAgIH07XHJcbiAgICAgICAgcmV0dXJuIHJldHVyblBhcmFtcztcclxuICAgIH1cclxuXHJcbiAgICBwdWJsaWMgc2V0TWFwTGVnZW5kRGF0YShfbGVnZW5kRGF0YTogeyBba2V5OiBzdHJpbmddOiBJTGVnZW5kRGF0YSB9LCBfZGF0YTogYW55LCBfY29uZmlnOiBJQ2hhcnRDb25maWcpIHtcclxuICAgICAgICBsZXQgbGVnZW5kSWQ6IHN0cmluZztcclxuICAgICAgICBfbGVnZW5kRGF0YSA9IHt9O1xyXG4gICAgICAgIGZvciAobGV0IGkgPSAwOyBpIDwgX2RhdGEubGVuZ3RoOyBpKyspIHtcclxuICAgICAgICAgICAgaWYgKF9kYXRhW2ldLm5hbWUgIT0gdW5kZWZpbmVkKSB7XHJcbiAgICAgICAgICAgICAgICBsZXQgY29sb3JQb2ludGVyID0gX2RhdGFbaV0uY29sb3I7XHJcbiAgICAgICAgICAgICAgICBsZWdlbmRJZCA9ICdpZCcgKyBpO1xyXG4gICAgICAgICAgICAgICAgX2xlZ2VuZERhdGFbbGVnZW5kSWRdID0ge1xyXG4gICAgICAgICAgICAgICAgICAgICduYW1lJzogX2RhdGFbaV0ubmFtZSxcclxuICAgICAgICAgICAgICAgICAgICAnaWQnOiBsZWdlbmRJZCxcclxuICAgICAgICAgICAgICAgICAgICAnc2hhcGUnOiAnY2lyY2xlJyxcclxuICAgICAgICAgICAgICAgICAgICAneCc6IF9kYXRhW2ldLm5hbWUsXHJcbiAgICAgICAgICAgICAgICAgICAgJ3knOiBfZGF0YVtpXS5kYXRhWzBdLnZhbHVlLFxyXG4gICAgICAgICAgICAgICAgICAgICd4QmFzZSc6IF9kYXRhW2ldLm5hbWUsXHJcbiAgICAgICAgICAgICAgICAgICAgJ2NvbG9yJzogKGNvbG9yUG9pbnRlciAmJiBjb2xvclBvaW50ZXIgIT0gbnVsbCAmJiBjb2xvclBvaW50ZXIgIT0gdW5kZWZpbmVkKSA/IGNvbG9yUG9pbnRlciA6IHRoaXMuZ2V0RGVmYXVsdENvbmZpZygnY29sb3InLCBpLCBfY29uZmlnKSxcclxuICAgICAgICAgICAgICAgICAgICAnbWFwU2VyaWVzSWQnOiBfZGF0YVtpXS5pZCxcclxuICAgICAgICAgICAgICAgICAgICAnZGVhY3RpdmUnOiBfZGF0YVtpXS5kZWFjdGl2ZVxyXG4gICAgICAgICAgICAgICAgfTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgICAgICByZXR1cm4gX2xlZ2VuZERhdGE7XHJcbiAgICB9XHJcblxyXG4gICAgcHVibGljIGdldERlZmF1bHRDb25maWcoX2VsZW1lbnQ6IGFueSwgX3Nlcmllc0luZGV4OiBudW1iZXIsIF9jb25maWc6IElDaGFydENvbmZpZyk6IHN0cmluZyB7XHJcbiAgICAgICAgaWYgKF9lbGVtZW50ID09PSAnc2hhcGUnKSByZXR1cm4gJ2NpcmNsZSc7XHJcblxyXG4gICAgICAgIGlmIChfc2VyaWVzSW5kZXggfHwgX3Nlcmllc0luZGV4ID09PSAwKSB7XHJcbiAgICAgICAgICAgIHJldHVybiBfY29uZmlnLmNvbG9yc1tfc2VyaWVzSW5kZXggJSBfY29uZmlnLmNvbG9ycy5sZW5ndGhdO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICBwdWJsaWMgc2V0U2luZ2xlTGVnZW5kTGV2ZWxzKF9kYXRhQ2xhc3NlczogQXJyYXk8YW55PiwgX2RlY2ltYWxQcmVjaXNvbjogbnVtYmVyLCBfdmFsdWVTdWZmaXg6IHN0cmluZywgX29yaWdpbmFsTGVnZW5kPzogeyBba2V5OiBzdHJpbmddOiBJTGVnZW5kRGF0YSB9KTogeyBba2V5OiBzdHJpbmddOiBJTGVnZW5kRGF0YSB9IHtcclxuICAgICAgICBsZXQgX2xlZ2VuZERhdGE6IHsgW2tleTogc3RyaW5nXTogSUxlZ2VuZERhdGEgfSA9IHt9O1xyXG4gICAgICAgIGZvciAobGV0IGkgPSAwOyBpIDwgX2RhdGFDbGFzc2VzLmxlbmd0aDsgaSsrKSB7XHJcbiAgICAgICAgICAgIGxldCBsZWdlbmRJZDogc3RyaW5nID0gJ2lkJyArIGk7XHJcbiAgICAgICAgICAgIF9sZWdlbmREYXRhW2xlZ2VuZElkXSA9IHtcclxuICAgICAgICAgICAgICAgICduYW1lJzogX2RhdGFDbGFzc2VzW2ldLmZyb20udG9GaXhlZChfZGVjaW1hbFByZWNpc29uKSArIF92YWx1ZVN1ZmZpeCArICcgLSAnICsgX2RhdGFDbGFzc2VzW2ldLnRvLnRvRml4ZWQoX2RlY2ltYWxQcmVjaXNvbikgKyBfdmFsdWVTdWZmaXgsXHJcbiAgICAgICAgICAgICAgICAnaWQnOiBsZWdlbmRJZCxcclxuICAgICAgICAgICAgICAgICdzaGFwZSc6ICdjaXJjbGUnLFxyXG4gICAgICAgICAgICAgICAgJ2NvbG9yJzogX2RhdGFDbGFzc2VzW2ldLmNvbG9yLFxyXG4gICAgICAgICAgICAgICAgJ2RlYWN0aXZlJzogX29yaWdpbmFsTGVnZW5kICYmIF9vcmlnaW5hbExlZ2VuZFtsZWdlbmRJZF0gPyBfb3JpZ2luYWxMZWdlbmRbbGVnZW5kSWRdLmRlYWN0aXZlIDogZmFsc2VcclxuICAgICAgICAgICAgfTtcclxuXHJcbiAgICAgICAgfVxyXG4gICAgICAgIHJldHVybiBfbGVnZW5kRGF0YTtcclxuICAgIH1cclxufVxyXG4iXX0=