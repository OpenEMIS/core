import { __decorate, __extends, __metadata } from "tslib";
import { Component, ViewEncapsulation, Input, Output, EventEmitter } from '@angular/core';
import { KdChartBaseClass } from '../kd-angular-chart-base-class';
import { KdChartsSvc } from '../kd-angular-charts-svc';
import { KdDomElemSvc } from '../../kd-common/index';
import * as d3 from 'd3';
var PI = Math.PI, arcMinRadius = 10, arcPadding = 10, labelPadding = -5, numTicks = 10;
var KdPieChart = /** @class */ (function (_super) {
    __extends(KdPieChart, _super);
    function KdPieChart(_chartSvc, _domSvc) {
        var _this = _super.call(this, _chartSvc, _domSvc) || this;
        _this._chartSvc = _chartSvc;
        _this._domSvc = _domSvc;
        _this.pieData = [];
        _this._posArray = [];
        _this.outputLegend = new EventEmitter(true);
        _this.outputData = new EventEmitter(true);
        return _this;
    }
    KdPieChart.prototype.ngOnInit = function () {
        var _this = this;
        this.config = Object.assign({}, this.pieConfig);
        this._setData();
        _super.prototype.chartTimeout.call(this, function () { return _this._setChart(); });
        this.api.legendClick = function (_data, legendData) {
            _this.pieData = [];
            if (_this.dataLabelContainer)
                _this.dataLabelContainer.selectAll('*').remove();
            // if (_config) this.config = _config;
            _this.data = _data;
            if (legendData) {
                // let newColor = [];
                _this.pieData = _this.data.data;
                // this.pieData = Object.keys(_config.legendData).map(key => _config.legendData[key]).map((value) => (value));
                // for (let i = 0; i < this.pieData.length; i++) {
                //     newColor.push(this.pieData[i].color);
                // }
                // this.pieConfig['pieColor'] = newColor;
                _this._redrawChart();
            }
            else {
                // fail-safe in case data massage haven't create legendData
                _this._setData();
                _this._setChart();
            }
        };
        this.api.redraw = function () {
            _this._redrawChart();
        };
    };
    KdPieChart.prototype.ngOnChanges = function (_simpleChanges) {
        if (_simpleChanges.hasOwnProperty('data') && !_simpleChanges['data'].firstChange) {
            this.data = _simpleChanges.data.currentValue;
            this._redrawChart('data');
        }
        if (_simpleChanges.hasOwnProperty('pieConfig') && !_simpleChanges['pieConfig'].firstChange) {
            this.pieConfig = _simpleChanges.pieConfig.currentValue;
            this._redrawChart('config');
        }
    };
    KdPieChart.prototype.ngOnDestroy = function () {
        this._resetChart();
    };
    KdPieChart.prototype._redrawChart = function (_changes) {
        var _this = this;
        this._resetChart();
        if (_changes === 'data') {
            this.pieData = [];
            this._setData();
        }
        else {
            this.pieConfig['legendData'] = this.config['legendData'];
            this.config = Object.assign({}, this.pieConfig);
        }
        _super.prototype.chartTimeout.call(this, function () { return _this._setChart(); });
    };
    KdPieChart.prototype._setChart = function () {
        _super.prototype.setSvg.call(this);
        _super.prototype.setSvgDimension.call(this, 'x');
        _super.prototype.setSvgDimension.call(this, 'y');
        this.chartType = this.data.layout.split('-');
        this.chartCategory = this.data.type;
        // moving pie chart to center of svg
        var height = this.svgContainer.node().getBoundingClientRect().height;
        var width = this.svgContainer.node().getBoundingClientRect().width;
        this.width = width;
        this.graph.attr('transform', 'translate(' + (width / 2) + ',' + (height / 2) + ')');
        // let color = this.pieConfig['pieColor'] ? d3.scaleOrdinal().range(this.pieConfig['pieColor']) : d3.scaleOrdinal().range(this.config.colors);
        // let chartParams = {
        //     'color': color
        // };
        this.dataLabelContainer.style('top', 0);
        this.dataLabelContainer.style('left', 0);
        if (this.chartType[0] === 'radial') {
            this._drawRadial({ height: height });
        }
        else if (this.chartType[0] === 'gauge') {
            this._drawGauge({ height: height });
        }
        else {
            this._drawPieDonut({ height: height, width: width });
        }
    };
    /**
     * when receiving data and legend, the structure is customise to for line/area and bar. pie needs to recalculate the legend
     * _setData generate pieData and new legend from the previous legend
     *
     * Note: this.pieData is used for rendering.
     * Note2: data.pieData it will not be changed onLegendClick
     * (onLegendClick affects data.data which is stored into this.pieData via api)
     */
    KdPieChart.prototype._setData = function () {
        if (!this.config.skipMassage) {
            if (this.data['piedata']) {
                this.pieData = this.data.piedata;
                // saving massaged piedata to this.data for export
                this.data.data = this.data.piedata;
            }
        }
        else {
            // when skip massage, no generation of pieData needed.
            this.pieData = this.data.data;
        }
    };
    KdPieChart.prototype._resetChart = function () {
        if (typeof this._path !== 'undefined')
            this._path.remove();
        if (typeof this._radialAxis !== 'undefined')
            this._radialAxis.remove();
        if (typeof this._axialAxis !== 'undefined')
            this._axialAxis.remove();
        if (typeof this._text !== 'undefined')
            this._text.remove();
        if (typeof this._polyline !== 'undefined')
            this._polyline.remove();
        if (typeof this._pointer !== 'undefined')
            this._pointer.remove();
        if (typeof this._percentageText !== 'undefined')
            this._percentageText.remove();
        if (this.dataLabelContainer)
            this.dataLabelContainer.selectAll('*').remove();
        this._posArray = [];
        clearInterval(this._interval);
        _super.prototype.removeChart.call(this);
    };
    KdPieChart.prototype._drawPieDonut = function (_params) {
        var _this = this;
        var radius = Math.min(_params.width, _params.height) / 2;
        if (this.chartType[1] && this.chartType[1] === 'half') {
            radius = (Math.min(_params.width, _params.height) / 5) * 3;
            this.graph.attr('transform', 'translate(' + (_params.width / 2) + ',' + ((_params.height / 4) * 3) + ')');
        }
        var innerRadius = this.chartType[0] === 'pie' ? 0 : (this.config.plotOptions.pie.innerRadius / 100) * radius * 0.8;
        var arc = d3.arc().innerRadius(innerRadius).outerRadius(radius * 0.8);
        var outerarc = d3.arc().innerRadius(radius * 0.9).outerRadius(radius * 0.9);
        // let arc = d3.arc().innerRadius(innerRadius).outerRadius(radius);
        var pie = d3.pie().sort(null).value(function (d) { return d.y; });
        var dataLabelCheck = this.chartType[1] === 'full' ? Math.PI : 0;
        pie = this.chartType[1] === 'full' ? pie.startAngle(0).endAngle(Math.PI * 2) : pie.startAngle(-90 * (Math.PI / 180)).endAngle(90 * (Math.PI / 180));
        this._path = this.graph.selectAll('path')
            .data(pie(this.pieData))
            .enter()
            .append('path')
            .attr('aria-value', function (d) { return d.data.y; })
            .attr('aria-series-name', function (d) { return _this.legend[d.data.id].name; })
            .attr('class', function (d) {
            _this._posArray.push({ 'x': d.data.index, 'value': d.data.y, 'id': d.data.index });
            return 'x-' + d.data.index + ' y-' + d.data.index;
            // return 'x-' + (d.data.xBase).replace(/ /g,'') + ' y-' + seriesId;
        })
            .attr('id', function (d) {
            return d.data.index;
            // return (d.data.x).replace(/ /g,'');
        })
            .attr('fill', function (d, i) {
            return _this.legend[d.data.id].color; // color should follow legendData
        })
            // .attr('d', arc)
            .style('stroke', this.config.plotOptions.pie.borderColor)
            .style('stroke-width', this.config.plotOptions.pie.borderWidth || 0);
        var labelParams = {
            'pie': pie,
            'arc': arc,
            'outerarc': outerarc,
            'radius': radius,
            'dataLabelCheck': dataLabelCheck,
        };
        if (!this.config.animation) {
            this._path
                .attr('d', function (d) { return arc(d); })
                .attr('pos', function (d) { return getPos(d, _this.chartType[1]); });
            this._setDataLabel(labelParams);
        }
        else {
            this._path.transition()
                .delay(function (d, i) {
                return i * 20;
            })
                .attrTween('d', function (d) {
                var i = d3.interpolate(d.startAngle, d.endAngle);
                return function (t) {
                    d.endAngle = i(t);
                    return arc(d);
                };
            })
                .attrTween('pos', function (d) {
                var current;
                current = current || d;
                var interpolate = d3.interpolate(current, d);
                current = interpolate(0);
                return function (t) {
                    var d2 = interpolate(t);
                    return getPos(d2, _this.chartType[1]);
                };
            })
                .on('end', function (d, i) {
                if (i === (_this.pieData.length - 1)) {
                    setTimeout(function () {
                        _this._setDataLabel(labelParams);
                    });
                }
            });
        }
        this._path.exit().remove();
        function getPos(_d2, _chartType) {
            var pos = outerarc.centroid(_d2);
            if (_chartType && _chartType === 'half') {
                pos[0] = radius * (midAngle(_d2) < dataLabelCheck ? -1 : 1);
            }
            else {
                pos[0] = radius * (midAngle(_d2) < dataLabelCheck ? 1 : -1);
            }
            return pos;
        }
        function midAngle(_d) {
            return _d.startAngle + (_d.endAngle - _d.startAngle) / 2;
        }
        var eventsParam = {
            'innerRadius': innerRadius,
            'outerRadius': radius * 0.8,
            'pathAnim': this._pathAnim,
        };
        _super.prototype._initMouseEvents.call(this, this._path, eventsParam);
    };
    KdPieChart.prototype._drawRadial = function (_params) {
        var _this = this;
        // let height = document.querySelector('#' + this.config.id + '.kdx-charts .svg-container').getBoundingClientRect().height;
        var chartRadius = _params.height / 2 - 40;
        var scale = d3.scaleLinear()
            .domain([0, d3.max(this.pieData, function (d) { return d.y; }) * 1.1])
            .range([0, 2 * PI]);
        var ticks = scale.ticks(numTicks).slice(0, -1);
        var keys = this.pieData.map(function (d, i) { return d.x; });
        // number of arcs
        var numArcs = keys.length;
        var arcWidth = (chartRadius - arcMinRadius - numArcs * arcPadding) / numArcs;
        var arc = d3.arc()
            .innerRadius(function (d, i) { return _this._getInnerRadius(i, numArcs, arcWidth); })
            .outerRadius(function (d, i) { return _this._getOuterRadius(i, numArcs, arcWidth); })
            .startAngle(0)
            .endAngle(function (d, i) { return scale(d); });
        this._radialAxis = this.graph.append('g')
            .attr('class', 'kdx-charts-r kdx-charts-axis-radial')
            .selectAll('g')
            .data(this.pieData)
            .enter().append('g');
        this._radialAxis.append('circle')
            .attr('r', function (d, i) { return _this._getOuterRadius(i, numArcs, arcWidth) + arcPadding; });
        this._radialAxis.append('text')
            .attr('x', labelPadding)
            .attr('y', function (d, i) { return -_this._getOuterRadius(i, numArcs, arcWidth) + arcPadding; })
            .style('font-size', '10px')
            .text(function (d) { return d.x; });
        this._axialAxis = this.graph.append('g')
            .attr('class', 'kdx-charts-a kdx-charts-axis-radial')
            .selectAll('g')
            .data(ticks)
            .enter().append('g')
            .attr('transform', function (d) { return 'rotate(' + (_this._rad2deg(scale(d)) - 90) + ')'; });
        this._axialAxis.append('line')
            .attr('x2', chartRadius);
        this._axialAxis.append('text')
            .attr('x', chartRadius + 10)
            .style('text-anchor', function (d) { return (scale(d) >= PI && scale(d) < 2 * PI ? 'end' : null); })
            .style('font-size', '10px')
            .attr('transform', function (d) { return 'rotate(' + (90 - _this._rad2deg(scale(d))) + ',' + (chartRadius + 10) + ',0)'; })
            .text(function (d) { return d; });
        // data arcs
        this._path = this.graph.append('g')
            .selectAll('path')
            .data(this.pieData)
            .enter().append('path')
            .attr('class', function (d) {
            return 'x-' + d.xBase + ' y-' + d.x;
        })
            .style('fill', function (d, i) { return _this.legend[d.id].color; });
        if (!this.config.animation) {
            this._path.attr('d', function (d, i) { return arc(d.y, i); });
        }
        else {
            this._path.transition()
                .delay(function (d, i) { return i * 100; })
                .duration(200)
                // .attrTween('d', arcTween);
                .attrTween('d', function (d, i) {
                var interpolate = d3.interpolate(0, d.y);
                return function (t) { return arc(interpolate(t), i); };
            });
        }
        _super.prototype._initMouseEvents.call(this, this._path);
    };
    KdPieChart.prototype._drawGauge = function (_params) {
        // let percent = 100.00;
        var percent = Math.floor(Math.random() * 100);
        var endAngle = this.chartType[1] === 'full' ? Math.PI * 2 : Math.PI;
        var outerRadius = _params.height / 3;
        var innerRadius = (outerRadius / 3) * 2;
        var fontSize = innerRadius * 0.8;
        var arc = d3.arc()
            .innerRadius(innerRadius)
            .outerRadius(outerRadius)
            .startAngle(0)
            .endAngle(endAngle);
        var arcLine = d3.arc()
            .innerRadius(innerRadius)
            .outerRadius(outerRadius)
            .startAngle(0);
        this._path = this.graph.append('path')
            .attr('d', arc)
            .attr('transform', 'rotate(-90)')
            .attr('stroke-width', 1)
            .attr('stroke', '#666666')
            .style('fill', '#FFFFFF');
        this._pointer = this.graph.append('path')
            // let pathForeground = this.graph.append('path')
            .datum({ endAngle: 0 })
            .attr('d', arcLine)
            .attr('transform', 'rotate(-90)');
        this._percentageText = this.graph.append('text')
            .datum(0)
            .text(function (d) {
            return d;
        })
            .attr('class', 'kdx-charts-middleText')
            .attr('text-anchor', 'middle')
            .attr('dy', this.chartType[1] === 'full' ? fontSize * 0.45 : 0)
            .style('fill', d3.rgb('#000000'))
            .style('font-size', fontSize + 'px');
        if (!this.config.animation) {
            this._pointer
                .attr('d', function (d) { return arcLine(d); })
                .style('fill', d3.rgb('#FF0000'));
            return;
        }
        var arcTween = function (transition, newValue, test) {
            transition.attrTween('d', function (d) {
                var interpolate = d3.interpolate(d.endAngle, ((endAngle)) * (newValue / 100));
                var interpolateCount = d3.interpolate(0, newValue);
                return function (t) {
                    d.endAngle = interpolate(t);
                    test._percentageText.text(Math.floor(interpolateCount(t)) + '%');
                    return arcLine(d);
                };
            });
        };
        this._pointer.transition()
            .duration(750)
            .ease(d3.easeCubicIn)
            .call(arcTween, percent, this)
            .style('fill', d3.rgb('#FF0000'));
    };
    KdPieChart.prototype._setDataLabel = function (_params) {
        var _this = this;
        if (!this.config.chart.labels.enabled)
            return;
        if (this.chartCategory !== 'pie')
            return;
        if (this._posArray.length === 0)
            return;
        var line = Array.from(document.querySelectorAll('#' + this.config.id + '.kdx-charts .kdx-charts-lines'));
        line.forEach(function (e) { return e.parentNode.removeChild(e); });
        var key = function (d) { return d.data.y; };
        function midAngle(_d) {
            return _d.startAngle + (_d.endAngle - _d.startAngle) / 2;
        }
        var height = this.svgContainer.node().getBoundingClientRect().height;
        var width = this.svgContainer.node().getBoundingClientRect().width;
        height = (this.chartType[1] && this.chartType[1] === 'half') ? ((height / 4) * 3) - 8 : height / 2 - 8;
        for (var i = 0; i < this._path._groups[0].length; i++) {
            if (this._posArray[i] && this._posArray[i].id !== undefined) {
                var posPointer = document.querySelector('#' + this.config.id + ' #' + this._posArray[i].id).getAttribute('pos');
                if (this._posArray.length !== 0 && document.querySelector('#' + this.config.id + ' #' + this._posArray[i].id) !== null && posPointer !== null) {
                    var yData = {
                        'id': this._posArray[i].id,
                        'value': this._posArray[i].value
                    };
                    var xvalue = parseInt(posPointer.split(',')[0]) + width / 2;
                    var yvalue = parseInt(posPointer.split(',')[1]) + height;
                    var tempCondition = parseInt(posPointer.split(',')[0]);
                    var rtlCondition = this.isRtl === false ? tempCondition < 0 : tempCondition > 0;
                    var checkFlexEndStyle = rtlCondition ? 'flex-end' : 'flex-start';
                    var dataLabelClass = '#' + this.config.id + ' .kdx-charts-data-label.x-' + this._posArray[i].x + '.y-' + yData.id;
                    if (document.querySelector(dataLabelClass) == null) {
                        _super.prototype.setLabel.call(this, yData, this._posArray[i].x, xvalue, yvalue).style('visibility', 'visible').style('width', '0px').style('justify-content', checkFlexEndStyle);
                    }
                }
            }
        }
        this._polyline = this.graph.append('g')
            .attr('class', 'kdx-charts-lines')
            .selectAll('polyline')
            .data(_params.pie(this.pieData), key)
            .enter()
            .append('polyline')
            .style('stroke', function (d, i) {
            return _this.legend[d.data.id].color;
        }).attr('points', function (d) {
            return getPos(d, _this.chartType[1]);
        }).style('fill', 'none');
        // if (!this.config.animation) {
        //     this._polyline.attr('points', (d) => {
        //         return getPos(d, this.chartType[1]);
        //     });
        //     return;
        // }
        // this._polyline.transition().duration(1000)
        //     .attrTween('points', (d) => {
        //         this._current = this._current || d;
        //         let interpolate = d3.interpolate(this._current, d);
        //         this._current = interpolate(0);
        //         return (t) => {
        //             let d2 = interpolate(t);
        //             return getPos(d2, this.chartType[1]);
        //         };
        //     });
        function getPos(_d2, _chartType) {
            var pos = _params.outerarc.centroid(_d2);
            if (_chartType && _chartType === 'half') {
                pos[0] = _params.radius * 0.95 * (midAngle(_d2) < _params.dataLabelCheck ? -1 : 1);
            }
            else {
                pos[0] = _params.radius * 0.95 * (midAngle(_d2) < _params.dataLabelCheck ? 1 : -1);
            }
            return [_params.arc.centroid(_d2), _params.outerarc.centroid(_d2), pos];
        }
    };
    KdPieChart.prototype._getInnerRadius = function (_index, _numArcs, _arcWidth) {
        return arcMinRadius + (_numArcs - (_index + 1)) * (_arcWidth + arcPadding);
    };
    KdPieChart.prototype._getOuterRadius = function (_index, _numArcs, _arcWidth) {
        return this._getInnerRadius(_index, _numArcs, _arcWidth) + _arcWidth;
    };
    KdPieChart.prototype._rad2deg = function (_angle) {
        return _angle * 180 / PI;
    };
    KdPieChart.prototype._pathAnim = function (_path, dir, _innerRadius, _outerRadius) {
        switch (dir) {
            case false:
                _path.transition()
                    .duration(500)
                    // .ease('bounce')
                    .attr('d', d3.arc()
                    .innerRadius(_innerRadius)
                    .outerRadius(_outerRadius)).attr('stroke', 'none');
                break;
            case true:
                _path.transition()
                    .attr('d', d3.arc()
                    .innerRadius(_innerRadius)
                    .outerRadius(_outerRadius * 1.1)).attr('stroke', 'white').attr('stroke-width', 2);
                break;
        }
    };
    KdPieChart.ctorParameters = function () { return [
        { type: KdChartsSvc },
        { type: KdDomElemSvc }
    ]; };
    __decorate([
        Input(),
        __metadata("design:type", Object)
    ], KdPieChart.prototype, "data", void 0);
    __decorate([
        Input('config'),
        __metadata("design:type", Object)
    ], KdPieChart.prototype, "pieConfig", void 0);
    __decorate([
        Input(),
        __metadata("design:type", Object)
    ], KdPieChart.prototype, "legend", void 0);
    __decorate([
        Input(),
        __metadata("design:type", Object)
    ], KdPieChart.prototype, "api", void 0);
    __decorate([
        Input(),
        __metadata("design:type", Number)
    ], KdPieChart.prototype, "seriesThreshold", void 0);
    __decorate([
        Output(),
        __metadata("design:type", EventEmitter)
    ], KdPieChart.prototype, "outputLegend", void 0);
    __decorate([
        Output(),
        __metadata("design:type", EventEmitter)
    ], KdPieChart.prototype, "outputData", void 0);
    KdPieChart = __decorate([
        Component({
            selector: 'kd-pie-chart',
            template: '',
            encapsulation: ViewEncapsulation.None,
            providers: [KdChartsSvc, KdDomElemSvc],
            host: {
                'class': 'kdx-pie-chart',
            }
        }),
        __metadata("design:paramtypes", [KdChartsSvc, KdDomElemSvc])
    ], KdPieChart);
    return KdPieChart;
}(KdChartBaseClass));
export { KdPieChart };
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoia2QtYW5ndWxhci1waWUtY2hhcnQuanMiLCJzb3VyY2VSb290Ijoibmc6Ly9vcGVuZW1pcy1zdHlsZWd1aWRlLWxpYi8iLCJzb3VyY2VzIjpbImtkLWNvbXBvbmVudHMva2QtYW5ndWxhci1jaGFydHMva2QtYW5ndWxhci1waWUtY2hhcnQva2QtYW5ndWxhci1waWUtY2hhcnQudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IjtBQUFBLE9BQU8sRUFDSCxTQUFTLEVBQ1QsaUJBQWlCLEVBQ2pCLEtBQUssRUFDTCxNQUFNLEVBQ04sWUFBWSxFQUtmLE1BQU0sZUFBZSxDQUFDO0FBQ3ZCLE9BQU8sRUFBRSxnQkFBZ0IsRUFBRSxNQUFNLGdDQUFnQyxDQUFDO0FBQ2xFLE9BQU8sRUFBRSxXQUFXLEVBQUUsTUFBTSwwQkFBMEIsQ0FBQztBQUN2RCxPQUFPLEVBQUUsWUFBWSxFQUFFLE1BQU0sdUJBQXVCLENBQUM7QUFFckQsT0FBTyxLQUFLLEVBQUUsTUFBTSxJQUFJLENBQUM7QUFFekIsSUFBTSxFQUFFLEdBQUcsSUFBSSxDQUFDLEVBQUUsRUFDZCxZQUFZLEdBQUcsRUFBRSxFQUNqQixVQUFVLEdBQUcsRUFBRSxFQUNmLFlBQVksR0FBRyxDQUFDLENBQUMsRUFDakIsUUFBUSxHQUFHLEVBQUUsQ0FBQztBQVlsQjtJQUFnQyw4QkFBZ0I7SUFzQjVDLG9CQUFtQixTQUFzQixFQUFTLE9BQXFCO1FBQXZFLFlBQ0ksa0JBQU0sU0FBUyxFQUFFLE9BQU8sQ0FBQyxTQUM1QjtRQUZrQixlQUFTLEdBQVQsU0FBUyxDQUFhO1FBQVMsYUFBTyxHQUFQLE9BQU8sQ0FBYztRQXJCaEUsYUFBTyxHQUFlLEVBQUUsQ0FBQztRQVV4QixlQUFTLEdBQUcsRUFBRSxDQUFDO1FBUWIsa0JBQVksR0FBaUQsSUFBSSxZQUFZLENBQUMsSUFBSSxDQUFDLENBQUM7UUFDcEYsZ0JBQVUsR0FBc0IsSUFBSSxZQUFZLENBQUMsSUFBSSxDQUFDLENBQUM7O0lBSWpFLENBQUM7SUFFRCw2QkFBUSxHQUFSO1FBQUEsaUJBOEJDO1FBN0JHLElBQUksQ0FBQyxNQUFNLEdBQUcsTUFBTSxDQUFDLE1BQU0sQ0FBQyxFQUFFLEVBQUUsSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDO1FBQ2hELElBQUksQ0FBQyxRQUFRLEVBQUUsQ0FBQztRQUNoQixpQkFBTSxZQUFZLFlBQUMsY0FBTSxPQUFBLEtBQUksQ0FBQyxTQUFTLEVBQUUsRUFBaEIsQ0FBZ0IsQ0FBQyxDQUFDO1FBRTNDLElBQUksQ0FBQyxHQUFHLENBQUMsV0FBVyxHQUFHLFVBQUMsS0FBVSxFQUFFLFVBQWdCO1lBQ2hELEtBQUksQ0FBQyxPQUFPLEdBQUcsRUFBRSxDQUFDO1lBQ2xCLElBQUksS0FBSSxDQUFDLGtCQUFrQjtnQkFBRSxLQUFJLENBQUMsa0JBQWtCLENBQUMsU0FBUyxDQUFDLEdBQUcsQ0FBQyxDQUFDLE1BQU0sRUFBRSxDQUFDO1lBQzdFLHNDQUFzQztZQUN0QyxLQUFJLENBQUMsSUFBSSxHQUFHLEtBQUssQ0FBQztZQUNsQixJQUFJLFVBQVUsRUFBRTtnQkFDWixxQkFBcUI7Z0JBQ3JCLEtBQUksQ0FBQyxPQUFPLEdBQUcsS0FBSSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUM7Z0JBQzlCLDhHQUE4RztnQkFDOUcsa0RBQWtEO2dCQUNsRCw0Q0FBNEM7Z0JBQzVDLElBQUk7Z0JBQ0oseUNBQXlDO2dCQUV6QyxLQUFJLENBQUMsWUFBWSxFQUFFLENBQUM7YUFFdkI7aUJBQU07Z0JBQ0gsMkRBQTJEO2dCQUMzRCxLQUFJLENBQUMsUUFBUSxFQUFFLENBQUM7Z0JBQ2hCLEtBQUksQ0FBQyxTQUFTLEVBQUUsQ0FBQzthQUNwQjtRQUNMLENBQUMsQ0FBQztRQUNGLElBQUksQ0FBQyxHQUFHLENBQUMsTUFBTSxHQUFHO1lBQ2QsS0FBSSxDQUFDLFlBQVksRUFBRSxDQUFDO1FBQ3hCLENBQUMsQ0FBQztJQUNOLENBQUM7SUFFRCxnQ0FBVyxHQUFYLFVBQVksY0FBNkI7UUFDckMsSUFBSSxjQUFjLENBQUMsY0FBYyxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsY0FBYyxDQUFDLE1BQU0sQ0FBQyxDQUFDLFdBQVcsRUFBRTtZQUM5RSxJQUFJLENBQUMsSUFBSSxHQUFHLGNBQWMsQ0FBQyxJQUFJLENBQUMsWUFBWSxDQUFDO1lBQzdDLElBQUksQ0FBQyxZQUFZLENBQUMsTUFBTSxDQUFDLENBQUM7U0FDN0I7UUFDRCxJQUFJLGNBQWMsQ0FBQyxjQUFjLENBQUMsV0FBVyxDQUFDLElBQUksQ0FBQyxjQUFjLENBQUMsV0FBVyxDQUFDLENBQUMsV0FBVyxFQUFFO1lBQ3hGLElBQUksQ0FBQyxTQUFTLEdBQUcsY0FBYyxDQUFDLFNBQVMsQ0FBQyxZQUFZLENBQUM7WUFDdkQsSUFBSSxDQUFDLFlBQVksQ0FBQyxRQUFRLENBQUMsQ0FBQztTQUMvQjtJQUNMLENBQUM7SUFFRCxnQ0FBVyxHQUFYO1FBQ0ksSUFBSSxDQUFDLFdBQVcsRUFBRSxDQUFDO0lBQ3ZCLENBQUM7SUFFTyxpQ0FBWSxHQUFwQixVQUFxQixRQUE0QjtRQUFqRCxpQkFZQztRQVhHLElBQUksQ0FBQyxXQUFXLEVBQUUsQ0FBQztRQUVuQixJQUFJLFFBQVEsS0FBSyxNQUFNLEVBQUU7WUFDckIsSUFBSSxDQUFDLE9BQU8sR0FBRyxFQUFFLENBQUM7WUFDbEIsSUFBSSxDQUFDLFFBQVEsRUFBRSxDQUFDO1NBQ25CO2FBQU07WUFDSCxJQUFJLENBQUMsU0FBUyxDQUFDLFlBQVksQ0FBQyxHQUFHLElBQUksQ0FBQyxNQUFNLENBQUMsWUFBWSxDQUFDLENBQUM7WUFDekQsSUFBSSxDQUFDLE1BQU0sR0FBRyxNQUFNLENBQUMsTUFBTSxDQUFDLEVBQUUsRUFBRSxJQUFJLENBQUMsU0FBUyxDQUFDLENBQUM7U0FDbkQ7UUFFRCxpQkFBTSxZQUFZLFlBQUMsY0FBTSxPQUFBLEtBQUksQ0FBQyxTQUFTLEVBQUUsRUFBaEIsQ0FBZ0IsQ0FBQyxDQUFDO0lBQy9DLENBQUM7SUFFTyw4QkFBUyxHQUFqQjtRQUNJLGlCQUFNLE1BQU0sV0FBRSxDQUFDO1FBQ2YsaUJBQU0sZUFBZSxZQUFDLEdBQUcsQ0FBQyxDQUFDO1FBQzNCLGlCQUFNLGVBQWUsWUFBQyxHQUFHLENBQUMsQ0FBQztRQUUzQixJQUFJLENBQUMsU0FBUyxHQUFHLElBQUksQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FBQztRQUM3QyxJQUFJLENBQUMsYUFBYSxHQUFHLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDO1FBQ3BDLG9DQUFvQztRQUNwQyxJQUFJLE1BQU0sR0FBRyxJQUFJLENBQUMsWUFBWSxDQUFDLElBQUksRUFBRSxDQUFDLHFCQUFxQixFQUFFLENBQUMsTUFBTSxDQUFDO1FBQ3JFLElBQUksS0FBSyxHQUFHLElBQUksQ0FBQyxZQUFZLENBQUMsSUFBSSxFQUFFLENBQUMscUJBQXFCLEVBQUUsQ0FBQyxLQUFLLENBQUM7UUFDbkUsSUFBSSxDQUFDLEtBQUssR0FBRyxLQUFLLENBQUM7UUFDbkIsSUFBSSxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsV0FBVyxFQUFFLFlBQVksR0FBRyxDQUFDLEtBQUssR0FBRyxDQUFDLENBQUMsR0FBRyxHQUFHLEdBQUcsQ0FBQyxNQUFNLEdBQUcsQ0FBQyxDQUFDLEdBQUcsR0FBRyxDQUFDLENBQUM7UUFFcEYsOElBQThJO1FBQzlJLHNCQUFzQjtRQUN0QixxQkFBcUI7UUFDckIsS0FBSztRQUNMLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxLQUFLLENBQUMsS0FBSyxFQUFFLENBQUMsQ0FBQyxDQUFDO1FBQ3hDLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxLQUFLLENBQUMsTUFBTSxFQUFFLENBQUMsQ0FBQyxDQUFDO1FBRXpDLElBQUksSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsS0FBSyxRQUFRLEVBQUU7WUFDaEMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxFQUFFLE1BQU0sRUFBRSxNQUFNLEVBQUUsQ0FBQyxDQUFDO1NBQ3hDO2FBQU0sSUFBSSxJQUFJLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxLQUFLLE9BQU8sRUFBRTtZQUN0QyxJQUFJLENBQUMsVUFBVSxDQUFDLEVBQUUsTUFBTSxFQUFFLE1BQU0sRUFBRSxDQUFDLENBQUM7U0FDdkM7YUFBTTtZQUNILElBQUksQ0FBQyxhQUFhLENBQUMsRUFBRSxNQUFNLEVBQUUsTUFBTSxFQUFFLEtBQUssRUFBRSxLQUFLLEVBQUUsQ0FBQyxDQUFDO1NBQ3hEO0lBQ0wsQ0FBQztJQUVEOzs7Ozs7O09BT0c7SUFDSyw2QkFBUSxHQUFoQjtRQUNJLElBQUksQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLFdBQVcsRUFBRTtZQUMxQixJQUFJLElBQUksQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLEVBQUU7Z0JBQ3RCLElBQUksQ0FBQyxPQUFPLEdBQUcsSUFBSSxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUM7Z0JBQ2pDLGtEQUFrRDtnQkFDbEQsSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLEdBQUcsSUFBSSxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUM7YUFDdEM7U0FDSjthQUFNO1lBQ0gsc0RBQXNEO1lBQ3RELElBQUksQ0FBQyxPQUFPLEdBQUcsSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUM7U0FDakM7SUFDTCxDQUFDO0lBRU8sZ0NBQVcsR0FBbkI7UUFDSSxJQUFJLE9BQU8sSUFBSSxDQUFDLEtBQUssS0FBSyxXQUFXO1lBQUUsSUFBSSxDQUFDLEtBQUssQ0FBQyxNQUFNLEVBQUUsQ0FBQztRQUMzRCxJQUFJLE9BQU8sSUFBSSxDQUFDLFdBQVcsS0FBSyxXQUFXO1lBQUUsSUFBSSxDQUFDLFdBQVcsQ0FBQyxNQUFNLEVBQUUsQ0FBQztRQUN2RSxJQUFJLE9BQU8sSUFBSSxDQUFDLFVBQVUsS0FBSyxXQUFXO1lBQUUsSUFBSSxDQUFDLFVBQVUsQ0FBQyxNQUFNLEVBQUUsQ0FBQztRQUNyRSxJQUFJLE9BQU8sSUFBSSxDQUFDLEtBQUssS0FBSyxXQUFXO1lBQUUsSUFBSSxDQUFDLEtBQUssQ0FBQyxNQUFNLEVBQUUsQ0FBQztRQUMzRCxJQUFJLE9BQU8sSUFBSSxDQUFDLFNBQVMsS0FBSyxXQUFXO1lBQUUsSUFBSSxDQUFDLFNBQVMsQ0FBQyxNQUFNLEVBQUUsQ0FBQztRQUNuRSxJQUFJLE9BQU8sSUFBSSxDQUFDLFFBQVEsS0FBSyxXQUFXO1lBQUUsSUFBSSxDQUFDLFFBQVEsQ0FBQyxNQUFNLEVBQUUsQ0FBQztRQUNqRSxJQUFJLE9BQU8sSUFBSSxDQUFDLGVBQWUsS0FBSyxXQUFXO1lBQUUsSUFBSSxDQUFDLGVBQWUsQ0FBQyxNQUFNLEVBQUUsQ0FBQztRQUMvRSxJQUFJLElBQUksQ0FBQyxrQkFBa0I7WUFBRSxJQUFJLENBQUMsa0JBQWtCLENBQUMsU0FBUyxDQUFDLEdBQUcsQ0FBQyxDQUFDLE1BQU0sRUFBRSxDQUFDO1FBQzdFLElBQUksQ0FBQyxTQUFTLEdBQUcsRUFBRSxDQUFDO1FBQ3BCLGFBQWEsQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLENBQUM7UUFDOUIsaUJBQU0sV0FBVyxXQUFFLENBQUM7SUFDeEIsQ0FBQztJQUVPLGtDQUFhLEdBQXJCLFVBQXNCLE9BQTBDO1FBQWhFLGlCQXdHQztRQXZHRyxJQUFJLE1BQU0sR0FBRyxJQUFJLENBQUMsR0FBRyxDQUFDLE9BQU8sQ0FBQyxLQUFLLEVBQUUsT0FBTyxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsQ0FBQztRQUN6RCxJQUFJLElBQUksQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLElBQUksSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsS0FBSyxNQUFNLEVBQUU7WUFDbkQsTUFBTSxHQUFHLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxPQUFPLENBQUMsS0FBSyxFQUFFLE9BQU8sQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUM7WUFDM0QsSUFBSSxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsV0FBVyxFQUFFLFlBQVksR0FBRyxDQUFDLE9BQU8sQ0FBQyxLQUFLLEdBQUcsQ0FBQyxDQUFDLEdBQUcsR0FBRyxHQUFHLENBQUMsQ0FBQyxPQUFPLENBQUMsTUFBTSxHQUFHLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxHQUFHLEdBQUcsQ0FBQyxDQUFDO1NBQzdHO1FBQ0QsSUFBSSxXQUFXLEdBQUcsSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsS0FBSyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLFdBQVcsQ0FBQyxHQUFHLENBQUMsV0FBVyxHQUFHLEdBQUcsQ0FBQyxHQUFHLE1BQU0sR0FBRyxHQUFHLENBQUM7UUFDbkgsSUFBSSxHQUFHLEdBQUcsRUFBRSxDQUFDLEdBQUcsRUFBRSxDQUFDLFdBQVcsQ0FBQyxXQUFXLENBQUMsQ0FBQyxXQUFXLENBQUMsTUFBTSxHQUFHLEdBQUcsQ0FBQyxDQUFDO1FBQ3RFLElBQUksUUFBUSxHQUFHLEVBQUUsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxXQUFXLENBQUMsTUFBTSxHQUFHLEdBQUcsQ0FBQyxDQUFDLFdBQVcsQ0FBQyxNQUFNLEdBQUcsR0FBRyxDQUFDLENBQUM7UUFDNUUsbUVBQW1FO1FBQ25FLElBQUksR0FBRyxHQUFHLEVBQUUsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUMsS0FBSyxDQUFDLFVBQUMsQ0FBQyxJQUFPLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO1FBQzVELElBQUksY0FBYyxHQUFHLElBQUksQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLEtBQUssTUFBTSxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7UUFDaEUsR0FBRyxHQUFHLElBQUksQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLEtBQUssTUFBTSxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsRUFBRSxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsVUFBVSxDQUFDLENBQUMsRUFBRSxHQUFHLENBQUMsSUFBSSxDQUFDLEVBQUUsR0FBRyxHQUFHLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxFQUFFLEdBQUcsQ0FBQyxJQUFJLENBQUMsRUFBRSxHQUFHLEdBQUcsQ0FBQyxDQUFDLENBQUM7UUFFcEosSUFBSSxDQUFDLEtBQUssR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDLFNBQVMsQ0FBQyxNQUFNLENBQUM7YUFDcEMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLENBQUM7YUFDdkIsS0FBSyxFQUFFO2FBQ1AsTUFBTSxDQUFDLE1BQU0sQ0FBQzthQUNkLElBQUksQ0FBQyxZQUFZLEVBQUUsVUFBQyxDQUFDLElBQUssT0FBQSxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsRUFBUixDQUFRLENBQUM7YUFDbkMsSUFBSSxDQUFDLGtCQUFrQixFQUFFLFVBQUMsQ0FBQyxJQUFLLE9BQUEsS0FBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxDQUFDLElBQUksRUFBM0IsQ0FBMkIsQ0FBQzthQUM1RCxJQUFJLENBQUMsT0FBTyxFQUFFLFVBQUMsQ0FBQztZQUNiLEtBQUksQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDLEVBQUUsR0FBRyxFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsS0FBSyxFQUFFLE9BQU8sRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsRUFBRSxJQUFJLEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxLQUFLLEVBQUUsQ0FBQyxDQUFDO1lBQ2xGLE9BQU8sSUFBSSxHQUFHLENBQUMsQ0FBQyxJQUFJLENBQUMsS0FBSyxHQUFHLEtBQUssR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQztZQUNsRCxvRUFBb0U7UUFDeEUsQ0FBQyxDQUFDO2FBQ0QsSUFBSSxDQUFDLElBQUksRUFBRSxVQUFDLENBQUM7WUFDVixPQUFPLENBQUMsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDO1lBQ3BCLHNDQUFzQztRQUMxQyxDQUFDLENBQUM7YUFDRCxJQUFJLENBQUMsTUFBTSxFQUFFLFVBQUMsQ0FBQyxFQUFFLENBQUM7WUFDZixPQUFPLEtBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxpQ0FBaUM7UUFDMUUsQ0FBQyxDQUFDO1lBQ0Ysa0JBQWtCO2FBQ2pCLEtBQUssQ0FBQyxRQUFRLEVBQUUsSUFBSSxDQUFDLE1BQU0sQ0FBQyxXQUFXLENBQUMsR0FBRyxDQUFDLFdBQVcsQ0FBQzthQUN4RCxLQUFLLENBQUMsY0FBYyxFQUFFLElBQUksQ0FBQyxNQUFNLENBQUMsV0FBVyxDQUFDLEdBQUcsQ0FBQyxXQUFXLElBQUksQ0FBQyxDQUFDLENBQUM7UUFFekUsSUFBSSxXQUFXLEdBQUc7WUFDZCxLQUFLLEVBQUUsR0FBRztZQUNWLEtBQUssRUFBRSxHQUFHO1lBQ1YsVUFBVSxFQUFFLFFBQVE7WUFDcEIsUUFBUSxFQUFFLE1BQU07WUFDaEIsZ0JBQWdCLEVBQUUsY0FBYztTQUVuQyxDQUFDO1FBRUYsSUFBSSxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsU0FBUyxFQUFFO1lBQ3hCLElBQUksQ0FBQyxLQUFLO2lCQUNMLElBQUksQ0FBQyxHQUFHLEVBQUUsVUFBQSxDQUFDLElBQUksT0FBQSxHQUFHLENBQUMsQ0FBQyxDQUFDLEVBQU4sQ0FBTSxDQUFDO2lCQUN0QixJQUFJLENBQUMsS0FBSyxFQUFFLFVBQUEsQ0FBQyxJQUFJLE9BQUEsTUFBTSxDQUFDLENBQUMsRUFBRSxLQUFJLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQTVCLENBQTRCLENBQUMsQ0FBQztZQUVwRCxJQUFJLENBQUMsYUFBYSxDQUFDLFdBQVcsQ0FBQyxDQUFDO1NBRW5DO2FBQU07WUFDSCxJQUFJLENBQUMsS0FBSyxDQUFDLFVBQVUsRUFBRTtpQkFDbEIsS0FBSyxDQUFDLFVBQUMsQ0FBQyxFQUFFLENBQUM7Z0JBQ1IsT0FBTyxDQUFDLEdBQUcsRUFBRSxDQUFDO1lBQ2xCLENBQUMsQ0FBQztpQkFDRCxTQUFTLENBQUMsR0FBRyxFQUFFLFVBQUMsQ0FBQztnQkFDZCxJQUFJLENBQUMsR0FBRyxFQUFFLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQyxVQUFVLEVBQUUsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDO2dCQUNqRCxPQUFPLFVBQUMsQ0FBQztvQkFDTCxDQUFDLENBQUMsUUFBUSxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztvQkFDbEIsT0FBTyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUM7Z0JBQ2xCLENBQUMsQ0FBQztZQUNOLENBQUMsQ0FBQztpQkFDRCxTQUFTLENBQUMsS0FBSyxFQUFFLFVBQUMsQ0FBQztnQkFDaEIsSUFBSSxPQUFPLENBQUM7Z0JBQ1osT0FBTyxHQUFHLE9BQU8sSUFBSSxDQUFDLENBQUM7Z0JBQ3ZCLElBQUksV0FBVyxHQUFHLEVBQUUsQ0FBQyxXQUFXLENBQUMsT0FBTyxFQUFFLENBQUMsQ0FBQyxDQUFDO2dCQUM3QyxPQUFPLEdBQUcsV0FBVyxDQUFDLENBQUMsQ0FBQyxDQUFDO2dCQUN6QixPQUFPLFVBQUMsQ0FBQztvQkFDTCxJQUFJLEVBQUUsR0FBRyxXQUFXLENBQUMsQ0FBQyxDQUFDLENBQUM7b0JBQ3hCLE9BQU8sTUFBTSxDQUFDLEVBQUUsRUFBRSxLQUFJLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7Z0JBQ3pDLENBQUMsQ0FBQztZQUNOLENBQUMsQ0FBQztpQkFDRCxFQUFFLENBQUMsS0FBSyxFQUFFLFVBQUMsQ0FBQyxFQUFFLENBQUM7Z0JBQ1osSUFBSSxDQUFDLEtBQUssQ0FBQyxLQUFJLENBQUMsT0FBTyxDQUFDLE1BQU0sR0FBRyxDQUFDLENBQUMsRUFBRTtvQkFDakMsVUFBVSxDQUFDO3dCQUNQLEtBQUksQ0FBQyxhQUFhLENBQUMsV0FBVyxDQUFDLENBQUM7b0JBQ3BDLENBQUMsQ0FBQyxDQUFDO2lCQUNOO1lBQ0wsQ0FBQyxDQUFDLENBQUM7U0FDVjtRQUVELElBQUksQ0FBQyxLQUFLLENBQUMsSUFBSSxFQUFFLENBQUMsTUFBTSxFQUFFLENBQUM7UUFFM0IsU0FBUyxNQUFNLENBQUMsR0FBRyxFQUFFLFVBQVU7WUFDM0IsSUFBSSxHQUFHLEdBQUcsUUFBUSxDQUFDLFFBQVEsQ0FBQyxHQUFHLENBQUMsQ0FBQztZQUNqQyxJQUFJLFVBQVUsSUFBSSxVQUFVLEtBQUssTUFBTSxFQUFFO2dCQUNyQyxHQUFHLENBQUMsQ0FBQyxDQUFDLEdBQUcsTUFBTSxHQUFHLENBQUMsUUFBUSxDQUFDLEdBQUcsQ0FBQyxHQUFHLGNBQWMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO2FBQy9EO2lCQUFNO2dCQUNILEdBQUcsQ0FBQyxDQUFDLENBQUMsR0FBRyxNQUFNLEdBQUcsQ0FBQyxRQUFRLENBQUMsR0FBRyxDQUFDLEdBQUcsY0FBYyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7YUFDL0Q7WUFDRCxPQUFPLEdBQUcsQ0FBQztRQUNmLENBQUM7UUFFRCxTQUFTLFFBQVEsQ0FBQyxFQUFFO1lBQ2hCLE9BQU8sRUFBRSxDQUFDLFVBQVUsR0FBRyxDQUFDLEVBQUUsQ0FBQyxRQUFRLEdBQUcsRUFBRSxDQUFDLFVBQVUsQ0FBQyxHQUFHLENBQUMsQ0FBQztRQUM3RCxDQUFDO1FBQ0QsSUFBSSxXQUFXLEdBQUc7WUFDZCxhQUFhLEVBQUUsV0FBVztZQUMxQixhQUFhLEVBQUUsTUFBTSxHQUFHLEdBQUc7WUFDM0IsVUFBVSxFQUFFLElBQUksQ0FBQyxTQUFTO1NBQzdCLENBQUM7UUFDRixpQkFBTSxnQkFBZ0IsWUFBQyxJQUFJLENBQUMsS0FBSyxFQUFFLFdBQVcsQ0FBQyxDQUFDO0lBQ3BELENBQUM7SUFFTyxnQ0FBVyxHQUFuQixVQUFvQixPQUEyQztRQUEvRCxpQkEwRUM7UUF6RUcsMkhBQTJIO1FBQzNILElBQUksV0FBVyxHQUFHLE9BQU8sQ0FBQyxNQUFNLEdBQUcsQ0FBQyxHQUFHLEVBQUUsQ0FBQztRQUMxQyxJQUFJLEtBQUssR0FBRyxFQUFFLENBQUMsV0FBVyxFQUFFO2FBQ3ZCLE1BQU0sQ0FBQyxDQUFDLENBQUMsRUFBRSxFQUFFLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxPQUFPLEVBQUUsVUFBQSxDQUFDLElBQUksT0FBQSxDQUFDLENBQUMsQ0FBQyxFQUFILENBQUcsQ0FBQyxHQUFHLEdBQUcsQ0FBQyxDQUFDO2FBQ2pELEtBQUssQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEdBQUcsRUFBRSxDQUFDLENBQUMsQ0FBQztRQUN4QixJQUFJLEtBQUssR0FBRyxLQUFLLENBQUMsS0FBSyxDQUFDLFFBQVEsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQztRQUMvQyxJQUFJLElBQUksR0FBRyxJQUFJLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxVQUFDLENBQUMsRUFBRSxDQUFDLElBQUssT0FBQSxDQUFDLENBQUMsQ0FBQyxFQUFILENBQUcsQ0FBQyxDQUFDO1FBQzNDLGlCQUFpQjtRQUNqQixJQUFNLE9BQU8sR0FBRyxJQUFJLENBQUMsTUFBTSxDQUFDO1FBQzVCLElBQU0sUUFBUSxHQUFHLENBQUMsV0FBVyxHQUFHLFlBQVksR0FBRyxPQUFPLEdBQUcsVUFBVSxDQUFDLEdBQUcsT0FBTyxDQUFDO1FBRS9FLElBQUksR0FBRyxHQUFHLEVBQUUsQ0FBQyxHQUFHLEVBQUU7YUFDYixXQUFXLENBQUMsVUFBQyxDQUFDLEVBQUUsQ0FBQyxJQUFLLE9BQUEsS0FBSSxDQUFDLGVBQWUsQ0FBQyxDQUFDLEVBQUUsT0FBTyxFQUFFLFFBQVEsQ0FBQyxFQUExQyxDQUEwQyxDQUFDO2FBQ2pFLFdBQVcsQ0FBQyxVQUFDLENBQUMsRUFBRSxDQUFDLElBQUssT0FBQSxLQUFJLENBQUMsZUFBZSxDQUFDLENBQUMsRUFBRSxPQUFPLEVBQUUsUUFBUSxDQUFDLEVBQTFDLENBQTBDLENBQUM7YUFDakUsVUFBVSxDQUFDLENBQUMsQ0FBQzthQUNiLFFBQVEsQ0FBQyxVQUFDLENBQUMsRUFBRSxDQUFDLElBQUssT0FBQSxLQUFLLENBQUMsQ0FBQyxDQUFDLEVBQVIsQ0FBUSxDQUFDLENBQUM7UUFFbEMsSUFBSSxDQUFDLFdBQVcsR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUM7YUFDcEMsSUFBSSxDQUFDLE9BQU8sRUFBRSxxQ0FBcUMsQ0FBQzthQUNwRCxTQUFTLENBQUMsR0FBRyxDQUFDO2FBQ2QsSUFBSSxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUM7YUFDbEIsS0FBSyxFQUFFLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDO1FBRXpCLElBQUksQ0FBQyxXQUFXLENBQUMsTUFBTSxDQUFDLFFBQVEsQ0FBQzthQUM1QixJQUFJLENBQUMsR0FBRyxFQUFFLFVBQUMsQ0FBQyxFQUFFLENBQUMsSUFBSyxPQUFBLEtBQUksQ0FBQyxlQUFlLENBQUMsQ0FBQyxFQUFFLE9BQU8sRUFBRSxRQUFRLENBQUMsR0FBRyxVQUFVLEVBQXZELENBQXVELENBQUMsQ0FBQztRQUVsRixJQUFJLENBQUMsV0FBVyxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUM7YUFDMUIsSUFBSSxDQUFDLEdBQUcsRUFBRSxZQUFZLENBQUM7YUFDdkIsSUFBSSxDQUFDLEdBQUcsRUFBRSxVQUFDLENBQUMsRUFBRSxDQUFDLElBQUssT0FBQSxDQUFDLEtBQUksQ0FBQyxlQUFlLENBQUMsQ0FBQyxFQUFFLE9BQU8sRUFBRSxRQUFRLENBQUMsR0FBRyxVQUFVLEVBQXhELENBQXdELENBQUM7YUFDN0UsS0FBSyxDQUFDLFdBQVcsRUFBRSxNQUFNLENBQUM7YUFDMUIsSUFBSSxDQUFDLFVBQUEsQ0FBQyxJQUFJLE9BQUEsQ0FBQyxDQUFDLENBQUMsRUFBSCxDQUFHLENBQUMsQ0FBQztRQUVwQixJQUFJLENBQUMsVUFBVSxHQUFHLElBQUksQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQzthQUNuQyxJQUFJLENBQUMsT0FBTyxFQUFFLHFDQUFxQyxDQUFDO2FBQ3BELFNBQVMsQ0FBQyxHQUFHLENBQUM7YUFDZCxJQUFJLENBQUMsS0FBSyxDQUFDO2FBQ1gsS0FBSyxFQUFFLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQzthQUNuQixJQUFJLENBQUMsV0FBVyxFQUFFLFVBQUEsQ0FBQyxJQUFJLE9BQUEsU0FBUyxHQUFHLENBQUMsS0FBSSxDQUFDLFFBQVEsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxFQUFFLENBQUMsR0FBRyxHQUFHLEVBQWhELENBQWdELENBQUMsQ0FBQztRQUU5RSxJQUFJLENBQUMsVUFBVSxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUM7YUFDekIsSUFBSSxDQUFDLElBQUksRUFBRSxXQUFXLENBQUMsQ0FBQztRQUU3QixJQUFJLENBQUMsVUFBVSxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUM7YUFDekIsSUFBSSxDQUFDLEdBQUcsRUFBRSxXQUFXLEdBQUcsRUFBRSxDQUFDO2FBQzNCLEtBQUssQ0FBQyxhQUFhLEVBQUUsVUFBQSxDQUFDLElBQUksT0FBQSxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsSUFBSSxFQUFFLElBQUksS0FBSyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsR0FBRyxFQUFFLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLEVBQXBELENBQW9ELENBQUM7YUFDL0UsS0FBSyxDQUFDLFdBQVcsRUFBRSxNQUFNLENBQUM7YUFDMUIsSUFBSSxDQUFDLFdBQVcsRUFBRSxVQUFBLENBQUMsSUFBSSxPQUFBLFNBQVMsR0FBRyxDQUFDLEVBQUUsR0FBRyxLQUFJLENBQUMsUUFBUSxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsR0FBRyxHQUFHLENBQUMsV0FBVyxHQUFHLEVBQUUsQ0FBQyxHQUFHLEtBQUssRUFBN0UsQ0FBNkUsQ0FBQzthQUNyRyxJQUFJLENBQUMsVUFBQSxDQUFDLElBQUksT0FBQSxDQUFDLEVBQUQsQ0FBQyxDQUFDLENBQUM7UUFFbEIsWUFBWTtRQUNaLElBQUksQ0FBQyxLQUFLLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDO2FBQzlCLFNBQVMsQ0FBQyxNQUFNLENBQUM7YUFDakIsSUFBSSxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUM7YUFDbEIsS0FBSyxFQUFFLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQzthQUN0QixJQUFJLENBQUMsT0FBTyxFQUFFLFVBQUMsQ0FBQztZQUNiLE9BQU8sSUFBSSxHQUFHLENBQUMsQ0FBQyxLQUFLLEdBQUcsS0FBSyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUM7UUFDeEMsQ0FBQyxDQUFDO2FBQ0QsS0FBSyxDQUFDLE1BQU0sRUFBRSxVQUFDLENBQUMsRUFBRSxDQUFDLElBQUssT0FBQSxLQUFJLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxLQUFLLEVBQXZCLENBQXVCLENBQUMsQ0FBQztRQUV0RCxJQUFJLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxTQUFTLEVBQUU7WUFDeEIsSUFBSSxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsR0FBRyxFQUFFLFVBQUMsQ0FBQyxFQUFFLENBQUMsSUFBSyxPQUFBLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxFQUFYLENBQVcsQ0FBQyxDQUFDO1NBQy9DO2FBQU07WUFDSCxJQUFJLENBQUMsS0FBSyxDQUFDLFVBQVUsRUFBRTtpQkFDbEIsS0FBSyxDQUFDLFVBQUMsQ0FBQyxFQUFFLENBQUMsSUFBSyxPQUFBLENBQUMsR0FBRyxHQUFHLEVBQVAsQ0FBTyxDQUFDO2lCQUN4QixRQUFRLENBQUMsR0FBRyxDQUFDO2dCQUNkLDZCQUE2QjtpQkFDNUIsU0FBUyxDQUFDLEdBQUcsRUFBRSxVQUFDLENBQUMsRUFBRSxDQUFDO2dCQUNqQixJQUFJLFdBQVcsR0FBRyxFQUFFLENBQUMsV0FBVyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7Z0JBQ3pDLE9BQU8sVUFBQSxDQUFDLElBQUksT0FBQSxHQUFHLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxFQUF0QixDQUFzQixDQUFDO1lBQ3ZDLENBQUMsQ0FBQyxDQUFDO1NBQ1Y7UUFFRCxpQkFBTSxnQkFBZ0IsWUFBQyxJQUFJLENBQUMsS0FBSyxDQUFDLENBQUM7SUFDdkMsQ0FBQztJQUVPLCtCQUFVLEdBQWxCLFVBQW1CLE9BQTJCO1FBQzFDLHdCQUF3QjtRQUN4QixJQUFJLE9BQU8sR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxNQUFNLEVBQUUsR0FBRyxHQUFHLENBQUMsQ0FBQztRQUM5QyxJQUFJLFFBQVEsR0FBRyxJQUFJLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxLQUFLLE1BQU0sQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLEVBQUUsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUM7UUFDcEUsSUFBSSxXQUFXLEdBQUcsT0FBTyxDQUFDLE1BQU0sR0FBRyxDQUFDLENBQUM7UUFDckMsSUFBSSxXQUFXLEdBQUcsQ0FBQyxXQUFXLEdBQUcsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDO1FBQ3hDLElBQUksUUFBUSxHQUFHLFdBQVcsR0FBRyxHQUFHLENBQUM7UUFFakMsSUFBSSxHQUFHLEdBQUcsRUFBRSxDQUFDLEdBQUcsRUFBRTthQUNiLFdBQVcsQ0FBQyxXQUFXLENBQUM7YUFDeEIsV0FBVyxDQUFDLFdBQVcsQ0FBQzthQUN4QixVQUFVLENBQUMsQ0FBQyxDQUFDO2FBQ2IsUUFBUSxDQUFDLFFBQVEsQ0FBQyxDQUFDO1FBRXhCLElBQUksT0FBTyxHQUFHLEVBQUUsQ0FBQyxHQUFHLEVBQUU7YUFDakIsV0FBVyxDQUFDLFdBQVcsQ0FBQzthQUN4QixXQUFXLENBQUMsV0FBVyxDQUFDO2FBQ3hCLFVBQVUsQ0FBQyxDQUFDLENBQUMsQ0FBQztRQUVuQixJQUFJLENBQUMsS0FBSyxHQUFHLElBQUksQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQzthQUNqQyxJQUFJLENBQUMsR0FBRyxFQUFFLEdBQUcsQ0FBQzthQUNkLElBQUksQ0FBQyxXQUFXLEVBQUUsYUFBYSxDQUFDO2FBQ2hDLElBQUksQ0FBQyxjQUFjLEVBQUUsQ0FBQyxDQUFDO2FBQ3ZCLElBQUksQ0FBQyxRQUFRLEVBQUUsU0FBUyxDQUFDO2FBQ3pCLEtBQUssQ0FBQyxNQUFNLEVBQUUsU0FBUyxDQUFDLENBQUM7UUFHOUIsSUFBSSxDQUFDLFFBQVEsR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUM7WUFDckMsaURBQWlEO2FBQ2hELEtBQUssQ0FBQyxFQUFFLFFBQVEsRUFBRSxDQUFDLEVBQUUsQ0FBQzthQUN0QixJQUFJLENBQUMsR0FBRyxFQUFFLE9BQU8sQ0FBQzthQUNsQixJQUFJLENBQUMsV0FBVyxFQUFFLGFBQWEsQ0FBQyxDQUFDO1FBR3RDLElBQUksQ0FBQyxlQUFlLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDO2FBQzNDLEtBQUssQ0FBQyxDQUFDLENBQUM7YUFDUixJQUFJLENBQUMsVUFBUyxDQUFDO1lBQ1osT0FBTyxDQUFDLENBQUM7UUFDYixDQUFDLENBQUM7YUFDRCxJQUFJLENBQUMsT0FBTyxFQUFFLHVCQUF1QixDQUFDO2FBQ3RDLElBQUksQ0FBQyxhQUFhLEVBQUUsUUFBUSxDQUFDO2FBQzdCLElBQUksQ0FBQyxJQUFJLEVBQUUsSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsS0FBSyxNQUFNLENBQUMsQ0FBQyxDQUFDLFFBQVEsR0FBRyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQzthQUM5RCxLQUFLLENBQUMsTUFBTSxFQUFFLEVBQUUsQ0FBQyxHQUFHLENBQUMsU0FBUyxDQUFDLENBQUM7YUFDaEMsS0FBSyxDQUFDLFdBQVcsRUFBRSxRQUFRLEdBQUcsSUFBSSxDQUFDLENBQUM7UUFFekMsSUFBSSxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsU0FBUyxFQUFFO1lBQ3hCLElBQUksQ0FBQyxRQUFRO2lCQUNSLElBQUksQ0FBQyxHQUFHLEVBQUUsVUFBQSxDQUFDLElBQUksT0FBQSxPQUFPLENBQUMsQ0FBQyxDQUFDLEVBQVYsQ0FBVSxDQUFDO2lCQUMxQixLQUFLLENBQUMsTUFBTSxFQUFFLEVBQUUsQ0FBQyxHQUFHLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQztZQUN0QyxPQUFPO1NBQ1Y7UUFFRCxJQUFJLFFBQVEsR0FBRyxVQUFTLFVBQVUsRUFBRSxRQUFRLEVBQUUsSUFBSTtZQUM5QyxVQUFVLENBQUMsU0FBUyxDQUFDLEdBQUcsRUFBRSxVQUFDLENBQUM7Z0JBQ3hCLElBQUksV0FBVyxHQUFHLEVBQUUsQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDLFFBQVEsRUFBRSxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsR0FBRyxDQUFDLFFBQVEsR0FBRyxHQUFHLENBQUMsQ0FBQyxDQUFDO2dCQUM5RSxJQUFJLGdCQUFnQixHQUFHLEVBQUUsQ0FBQyxXQUFXLENBQUMsQ0FBQyxFQUFFLFFBQVEsQ0FBQyxDQUFDO2dCQUVuRCxPQUFPLFVBQUMsQ0FBQztvQkFDTCxDQUFDLENBQUMsUUFBUSxHQUFHLFdBQVcsQ0FBQyxDQUFDLENBQUMsQ0FBQztvQkFDNUIsSUFBSSxDQUFDLGVBQWUsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLEdBQUcsQ0FBQyxDQUFDO29CQUNqRSxPQUFPLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQztnQkFDdEIsQ0FBQyxDQUFDO1lBQ04sQ0FBQyxDQUFDLENBQUM7UUFDUCxDQUFDLENBQUM7UUFFRixJQUFJLENBQUMsUUFBUSxDQUFDLFVBQVUsRUFBRTthQUNyQixRQUFRLENBQUMsR0FBRyxDQUFDO2FBQ2IsSUFBSSxDQUFDLEVBQUUsQ0FBQyxXQUFXLENBQUM7YUFDcEIsSUFBSSxDQUFDLFFBQVEsRUFBRSxPQUFPLEVBQUUsSUFBSSxDQUFDO2FBQzdCLEtBQUssQ0FBQyxNQUFNLEVBQUUsRUFBRSxDQUFDLEdBQUcsQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDO0lBQzFDLENBQUM7SUFFTyxrQ0FBYSxHQUFyQixVQUFzQixPQUFZO1FBQWxDLGlCQTRFQztRQTNFRyxJQUFJLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLE9BQU87WUFBRSxPQUFPO1FBQzlDLElBQUksSUFBSSxDQUFDLGFBQWEsS0FBSyxLQUFLO1lBQUUsT0FBTztRQUN6QyxJQUFJLElBQUksQ0FBQyxTQUFTLENBQUMsTUFBTSxLQUFLLENBQUM7WUFBRSxPQUFPO1FBQ3hDLElBQUksSUFBSSxHQUFHLEtBQUssQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLGdCQUFnQixDQUFDLEdBQUcsR0FBRyxJQUFJLENBQUMsTUFBTSxDQUFDLEVBQUUsR0FBRywrQkFBK0IsQ0FBQyxDQUFDLENBQUM7UUFDekcsSUFBSSxDQUFDLE9BQU8sQ0FBQyxVQUFBLENBQUMsSUFBSSxPQUFBLENBQUMsQ0FBQyxVQUFVLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQyxFQUEzQixDQUEyQixDQUFDLENBQUM7UUFFL0MsSUFBSSxHQUFHLEdBQUcsVUFBQyxDQUFDLElBQU8sT0FBTyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztRQUV0QyxTQUFTLFFBQVEsQ0FBQyxFQUFFO1lBQ2hCLE9BQU8sRUFBRSxDQUFDLFVBQVUsR0FBRyxDQUFDLEVBQUUsQ0FBQyxRQUFRLEdBQUcsRUFBRSxDQUFDLFVBQVUsQ0FBQyxHQUFHLENBQUMsQ0FBQztRQUM3RCxDQUFDO1FBRUQsSUFBSSxNQUFNLEdBQUcsSUFBSSxDQUFDLFlBQVksQ0FBQyxJQUFJLEVBQUUsQ0FBQyxxQkFBcUIsRUFBRSxDQUFDLE1BQU0sQ0FBQztRQUNyRSxJQUFJLEtBQUssR0FBRyxJQUFJLENBQUMsWUFBWSxDQUFDLElBQUksRUFBRSxDQUFDLHFCQUFxQixFQUFFLENBQUMsS0FBSyxDQUFDO1FBQ25FLE1BQU0sR0FBRyxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLElBQUksSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsS0FBSyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sR0FBRyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sR0FBRyxDQUFDLEdBQUcsQ0FBQyxDQUFDO1FBQ3ZHLEtBQUssSUFBSSxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLEVBQUUsQ0FBQyxFQUFFLEVBQUU7WUFDbkQsSUFBSSxJQUFJLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxJQUFJLElBQUksQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxLQUFLLFNBQVMsRUFBRTtnQkFDekQsSUFBSSxVQUFVLEdBQUcsUUFBUSxDQUFDLGFBQWEsQ0FBQyxHQUFHLEdBQUcsSUFBSSxDQUFDLE1BQU0sQ0FBQyxFQUFFLEdBQUcsSUFBSSxHQUFHLElBQUksQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsWUFBWSxDQUFDLEtBQUssQ0FBQyxDQUFDO2dCQUNoSCxJQUFJLElBQUksQ0FBQyxTQUFTLENBQUMsTUFBTSxLQUFLLENBQUMsSUFBSSxRQUFRLENBQUMsYUFBYSxDQUFDLEdBQUcsR0FBRyxJQUFJLENBQUMsTUFBTSxDQUFDLEVBQUUsR0FBRyxJQUFJLEdBQUcsSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsS0FBSyxJQUFJLElBQUksVUFBVSxLQUFLLElBQUksRUFBRTtvQkFDM0ksSUFBSSxLQUFLLEdBQUc7d0JBQ1IsSUFBSSxFQUFFLElBQUksQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRTt3QkFDMUIsT0FBTyxFQUFFLElBQUksQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSztxQkFDbkMsQ0FBQztvQkFDRixJQUFJLE1BQU0sR0FBVyxRQUFRLENBQUMsVUFBVSxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLEtBQUssR0FBRyxDQUFDLENBQUM7b0JBQ3BFLElBQUksTUFBTSxHQUFXLFFBQVEsQ0FBQyxVQUFVLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsTUFBTSxDQUFDO29CQUNqRSxJQUFJLGFBQWEsR0FBVyxRQUFRLENBQUMsVUFBVSxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO29CQUMvRCxJQUFJLFlBQVksR0FBWSxJQUFJLENBQUMsS0FBSyxLQUFLLEtBQUssQ0FBQyxDQUFDLENBQUMsYUFBYSxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsYUFBYSxHQUFHLENBQUMsQ0FBQztvQkFDekYsSUFBSSxpQkFBaUIsR0FBVyxZQUFZLENBQUMsQ0FBQyxDQUFDLFVBQVUsQ0FBQyxDQUFDLENBQUMsWUFBWSxDQUFDO29CQUN6RSxJQUFJLGNBQWMsR0FBRyxHQUFHLEdBQUcsSUFBSSxDQUFDLE1BQU0sQ0FBQyxFQUFFLEdBQUcsNEJBQTRCLEdBQUcsSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsS0FBSyxHQUFHLEtBQUssQ0FBQyxFQUFFLENBQUM7b0JBQ2xILElBQUksUUFBUSxDQUFDLGFBQWEsQ0FBQyxjQUFjLENBQUMsSUFBSSxJQUFJLEVBQUU7d0JBQ2hELGlCQUFNLFFBQVEsWUFBQyxLQUFLLEVBQUUsSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsTUFBTSxFQUFFLE1BQU0sQ0FBQyxDQUFDLEtBQUssQ0FBQyxZQUFZLEVBQUUsU0FBUyxDQUFDLENBQUMsS0FBSyxDQUFDLE9BQU8sRUFBRSxLQUFLLENBQUMsQ0FBQyxLQUFLLENBQUMsaUJBQWlCLEVBQUUsaUJBQWlCLENBQUMsQ0FBQztxQkFDL0o7aUJBQ0o7YUFDSjtTQUNKO1FBRUQsSUFBSSxDQUFDLFNBQVMsR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUM7YUFDbEMsSUFBSSxDQUFDLE9BQU8sRUFBRSxrQkFBa0IsQ0FBQzthQUNqQyxTQUFTLENBQUMsVUFBVSxDQUFDO2FBQ3JCLElBQUksQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsRUFBRSxHQUFHLENBQUM7YUFDcEMsS0FBSyxFQUFFO2FBQ1AsTUFBTSxDQUFDLFVBQVUsQ0FBQzthQUNsQixLQUFLLENBQUMsUUFBUSxFQUFFLFVBQUMsQ0FBQyxFQUFFLENBQUM7WUFDbEIsT0FBTyxLQUFJLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDLENBQUMsS0FBSyxDQUFDO1FBQ3hDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxRQUFRLEVBQUUsVUFBQyxDQUFDO1lBQ2hCLE9BQU8sTUFBTSxDQUFDLENBQUMsRUFBRSxLQUFJLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7UUFDeEMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLE1BQU0sRUFBRSxNQUFNLENBQUMsQ0FBQztRQUU3QixnQ0FBZ0M7UUFDaEMsNkNBQTZDO1FBQzdDLCtDQUErQztRQUMvQyxVQUFVO1FBQ1YsY0FBYztRQUNkLElBQUk7UUFFSiw2Q0FBNkM7UUFDN0Msb0NBQW9DO1FBQ3BDLDhDQUE4QztRQUM5Qyw4REFBOEQ7UUFDOUQsMENBQTBDO1FBQzFDLDBCQUEwQjtRQUMxQix1Q0FBdUM7UUFDdkMsb0RBQW9EO1FBQ3BELGFBQWE7UUFDYixVQUFVO1FBRVYsU0FBUyxNQUFNLENBQUMsR0FBRyxFQUFFLFVBQVU7WUFDM0IsSUFBSSxHQUFHLEdBQUcsT0FBTyxDQUFDLFFBQVEsQ0FBQyxRQUFRLENBQUMsR0FBRyxDQUFDLENBQUM7WUFDekMsSUFBSSxVQUFVLElBQUksVUFBVSxLQUFLLE1BQU0sRUFBRTtnQkFDckMsR0FBRyxDQUFDLENBQUMsQ0FBQyxHQUFHLE9BQU8sQ0FBQyxNQUFNLEdBQUcsSUFBSSxHQUFHLENBQUMsUUFBUSxDQUFDLEdBQUcsQ0FBQyxHQUFHLE9BQU8sQ0FBQyxjQUFjLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQzthQUN0RjtpQkFBTTtnQkFDSCxHQUFHLENBQUMsQ0FBQyxDQUFDLEdBQUcsT0FBTyxDQUFDLE1BQU0sR0FBRyxJQUFJLEdBQUcsQ0FBQyxRQUFRLENBQUMsR0FBRyxDQUFDLEdBQUcsT0FBTyxDQUFDLGNBQWMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO2FBQ3RGO1lBQ0QsT0FBTyxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsUUFBUSxDQUFDLEdBQUcsQ0FBQyxFQUFFLE9BQU8sQ0FBQyxRQUFRLENBQUMsUUFBUSxDQUFDLEdBQUcsQ0FBQyxFQUFFLEdBQUcsQ0FBQyxDQUFDO1FBQzVFLENBQUM7SUFDTCxDQUFDO0lBR08sb0NBQWUsR0FBdkIsVUFBd0IsTUFBYyxFQUFFLFFBQWdCLEVBQUUsU0FBaUI7UUFDdkUsT0FBTyxZQUFZLEdBQUcsQ0FBQyxRQUFRLEdBQUcsQ0FBQyxNQUFNLEdBQUcsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLFNBQVMsR0FBRyxVQUFVLENBQUMsQ0FBQztJQUMvRSxDQUFDO0lBRU8sb0NBQWUsR0FBdkIsVUFBd0IsTUFBYyxFQUFFLFFBQWdCLEVBQUUsU0FBaUI7UUFDdkUsT0FBTyxJQUFJLENBQUMsZUFBZSxDQUFDLE1BQU0sRUFBRSxRQUFRLEVBQUUsU0FBUyxDQUFDLEdBQUcsU0FBUyxDQUFDO0lBQ3pFLENBQUM7SUFFTyw2QkFBUSxHQUFoQixVQUFpQixNQUFjO1FBQzNCLE9BQU8sTUFBTSxHQUFHLEdBQUcsR0FBRyxFQUFFLENBQUM7SUFDN0IsQ0FBQztJQUVPLDhCQUFTLEdBQWpCLFVBQWtCLEtBQVUsRUFBRSxHQUFRLEVBQUUsWUFBaUIsRUFBRSxZQUFpQjtRQUN4RSxRQUFRLEdBQUcsRUFBRTtZQUNULEtBQUssS0FBSztnQkFDTixLQUFLLENBQUMsVUFBVSxFQUFFO3FCQUNiLFFBQVEsQ0FBQyxHQUFHLENBQUM7b0JBQ2Qsa0JBQWtCO3FCQUNqQixJQUFJLENBQUMsR0FBRyxFQUFFLEVBQUUsQ0FBQyxHQUFHLEVBQUU7cUJBQ2QsV0FBVyxDQUFDLFlBQVksQ0FBQztxQkFDekIsV0FBVyxDQUFDLFlBQVksQ0FBQyxDQUM3QixDQUFDLElBQUksQ0FBQyxRQUFRLEVBQUUsTUFBTSxDQUFDLENBQUM7Z0JBQzdCLE1BQU07WUFFVixLQUFLLElBQUk7Z0JBQ0wsS0FBSyxDQUFDLFVBQVUsRUFBRTtxQkFDYixJQUFJLENBQUMsR0FBRyxFQUFFLEVBQUUsQ0FBQyxHQUFHLEVBQUU7cUJBQ2QsV0FBVyxDQUFDLFlBQVksQ0FBQztxQkFDekIsV0FBVyxDQUFDLFlBQVksR0FBRyxHQUFHLENBQUMsQ0FDbkMsQ0FBQyxJQUFJLENBQUMsUUFBUSxFQUFFLE9BQU8sQ0FBQyxDQUFDLElBQUksQ0FBQyxjQUFjLEVBQUUsQ0FBQyxDQUFDLENBQUM7Z0JBQ3RELE1BQU07U0FDYjtJQUNMLENBQUM7O2dCQTllNkIsV0FBVztnQkFBa0IsWUFBWTs7SUFSOUQ7UUFBUixLQUFLLEVBQUU7OzRDQUFXO0lBQ0Y7UUFBaEIsS0FBSyxDQUFDLFFBQVEsQ0FBQzs7aURBQXlCO0lBQ2hDO1FBQVIsS0FBSyxFQUFFOzs4Q0FBd0M7SUFDdkM7UUFBUixLQUFLLEVBQUU7OzJDQUFVO0lBQ1Q7UUFBUixLQUFLLEVBQUU7O3VEQUF5QjtJQUN2QjtRQUFULE1BQU0sRUFBRTtrQ0FBZSxZQUFZO29EQUEwRDtJQUNwRjtRQUFULE1BQU0sRUFBRTtrQ0FBYSxZQUFZO2tEQUErQjtJQXBCeEQsVUFBVTtRQVZ0QixTQUFTLENBQUM7WUFDUCxRQUFRLEVBQUUsY0FBYztZQUN4QixRQUFRLEVBQUUsRUFBRTtZQUNaLGFBQWEsRUFBRSxpQkFBaUIsQ0FBQyxJQUFJO1lBQ3JDLFNBQVMsRUFBRSxDQUFDLFdBQVcsRUFBRSxZQUFZLENBQUM7WUFDdEMsSUFBSSxFQUFFO2dCQUNGLE9BQU8sRUFBRSxlQUFlO2FBQzNCO1NBQ0osQ0FBQzt5Q0F3QmdDLFdBQVcsRUFBa0IsWUFBWTtPQXRCOUQsVUFBVSxDQXFnQnRCO0lBQUQsaUJBQUM7Q0FBQSxBQXJnQkQsQ0FBZ0MsZ0JBQWdCLEdBcWdCL0M7U0FyZ0JZLFVBQVUiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQge1xyXG4gICAgQ29tcG9uZW50LFxyXG4gICAgVmlld0VuY2Fwc3VsYXRpb24sXHJcbiAgICBJbnB1dCxcclxuICAgIE91dHB1dCxcclxuICAgIEV2ZW50RW1pdHRlcixcclxuICAgIE9uSW5pdCxcclxuICAgIE9uQ2hhbmdlcyxcclxuICAgIFNpbXBsZUNoYW5nZXMsXHJcbiAgICBPbkRlc3Ryb3lcclxufSBmcm9tICdAYW5ndWxhci9jb3JlJztcclxuaW1wb3J0IHsgS2RDaGFydEJhc2VDbGFzcyB9IGZyb20gJy4uL2tkLWFuZ3VsYXItY2hhcnQtYmFzZS1jbGFzcyc7XHJcbmltcG9ydCB7IEtkQ2hhcnRzU3ZjIH0gZnJvbSAnLi4va2QtYW5ndWxhci1jaGFydHMtc3ZjJztcclxuaW1wb3J0IHsgS2REb21FbGVtU3ZjIH0gZnJvbSAnLi4vLi4va2QtY29tbW9uL2luZGV4JztcclxuaW1wb3J0IHsgSUxlZ2VuZERhdGEsIElDaGFydENvbmZpZyB9IGZyb20gJy4uL2tkLWFuZ3VsYXItY2hhcnRzLWludGVyZmFjZSc7XHJcbmltcG9ydCAqIGFzIGQzIGZyb20gJ2QzJztcclxuXHJcbmNvbnN0IFBJID0gTWF0aC5QSSxcclxuICAgIGFyY01pblJhZGl1cyA9IDEwLFxyXG4gICAgYXJjUGFkZGluZyA9IDEwLFxyXG4gICAgbGFiZWxQYWRkaW5nID0gLTUsXHJcbiAgICBudW1UaWNrcyA9IDEwO1xyXG5cclxuQENvbXBvbmVudCh7XHJcbiAgICBzZWxlY3RvcjogJ2tkLXBpZS1jaGFydCcsXHJcbiAgICB0ZW1wbGF0ZTogJycsXHJcbiAgICBlbmNhcHN1bGF0aW9uOiBWaWV3RW5jYXBzdWxhdGlvbi5Ob25lLFxyXG4gICAgcHJvdmlkZXJzOiBbS2RDaGFydHNTdmMsIEtkRG9tRWxlbVN2Y10sXHJcbiAgICBob3N0OiB7XHJcbiAgICAgICAgJ2NsYXNzJzogJ2tkeC1waWUtY2hhcnQnLFxyXG4gICAgfVxyXG59KVxyXG5cclxuZXhwb3J0IGNsYXNzIEtkUGllQ2hhcnQgZXh0ZW5kcyBLZENoYXJ0QmFzZUNsYXNzIGltcGxlbWVudHMgT25Jbml0LCBPbkNoYW5nZXMsIE9uRGVzdHJveSB7XHJcbiAgICBwdWJsaWMgcGllRGF0YTogQXJyYXk8YW55PiA9IFtdO1xyXG4gICAgcHVibGljIGxheW91dDtcclxuICAgIHByaXZhdGUgX3BhdGg7XHJcbiAgICBwcml2YXRlIF9yYWRpYWxBeGlzO1xyXG4gICAgcHJpdmF0ZSBfYXhpYWxBeGlzO1xyXG4gICAgcHJpdmF0ZSBfdGV4dDtcclxuICAgIHByaXZhdGUgX3BvbHlsaW5lO1xyXG4gICAgcHJpdmF0ZSBfcG9pbnRlcjtcclxuICAgIHByaXZhdGUgX2ludGVydmFsO1xyXG4gICAgcHJpdmF0ZSBfcGVyY2VudGFnZVRleHQ7XHJcbiAgICBwcml2YXRlIF9wb3NBcnJheSA9IFtdO1xyXG5cclxuXHJcbiAgICBASW5wdXQoKSBkYXRhOiBhbnk7XHJcbiAgICBASW5wdXQoJ2NvbmZpZycpIHBpZUNvbmZpZzogSUNoYXJ0Q29uZmlnO1xyXG4gICAgQElucHV0KCkgbGVnZW5kOiB7IFtrZXk6IHN0cmluZ106IElMZWdlbmREYXRhIH07XHJcbiAgICBASW5wdXQoKSBhcGk6IGFueTtcclxuICAgIEBJbnB1dCgpIHNlcmllc1RocmVzaG9sZDogbnVtYmVyO1xyXG4gICAgQE91dHB1dCgpIG91dHB1dExlZ2VuZDogRXZlbnRFbWl0dGVyPHsgW2tleTogc3RyaW5nXTogSUxlZ2VuZERhdGEgfT4gPSBuZXcgRXZlbnRFbWl0dGVyKHRydWUpO1xyXG4gICAgQE91dHB1dCgpIG91dHB1dERhdGE6IEV2ZW50RW1pdHRlcjxhbnk+ID0gbmV3IEV2ZW50RW1pdHRlcih0cnVlKTtcclxuXHJcbiAgICBjb25zdHJ1Y3RvcihwdWJsaWMgX2NoYXJ0U3ZjOiBLZENoYXJ0c1N2YywgcHVibGljIF9kb21TdmM6IEtkRG9tRWxlbVN2Yykge1xyXG4gICAgICAgIHN1cGVyKF9jaGFydFN2YywgX2RvbVN2Yyk7XHJcbiAgICB9XHJcblxyXG4gICAgbmdPbkluaXQoKTogdm9pZCB7XHJcbiAgICAgICAgdGhpcy5jb25maWcgPSBPYmplY3QuYXNzaWduKHt9LCB0aGlzLnBpZUNvbmZpZyk7XHJcbiAgICAgICAgdGhpcy5fc2V0RGF0YSgpO1xyXG4gICAgICAgIHN1cGVyLmNoYXJ0VGltZW91dCgoKSA9PiB0aGlzLl9zZXRDaGFydCgpKTtcclxuXHJcbiAgICAgICAgdGhpcy5hcGkubGVnZW5kQ2xpY2sgPSAoX2RhdGE6IGFueSwgbGVnZW5kRGF0YT86IGFueSkgPT4ge1xyXG4gICAgICAgICAgICB0aGlzLnBpZURhdGEgPSBbXTtcclxuICAgICAgICAgICAgaWYgKHRoaXMuZGF0YUxhYmVsQ29udGFpbmVyKSB0aGlzLmRhdGFMYWJlbENvbnRhaW5lci5zZWxlY3RBbGwoJyonKS5yZW1vdmUoKTtcclxuICAgICAgICAgICAgLy8gaWYgKF9jb25maWcpIHRoaXMuY29uZmlnID0gX2NvbmZpZztcclxuICAgICAgICAgICAgdGhpcy5kYXRhID0gX2RhdGE7XHJcbiAgICAgICAgICAgIGlmIChsZWdlbmREYXRhKSB7XHJcbiAgICAgICAgICAgICAgICAvLyBsZXQgbmV3Q29sb3IgPSBbXTtcclxuICAgICAgICAgICAgICAgIHRoaXMucGllRGF0YSA9IHRoaXMuZGF0YS5kYXRhO1xyXG4gICAgICAgICAgICAgICAgLy8gdGhpcy5waWVEYXRhID0gT2JqZWN0LmtleXMoX2NvbmZpZy5sZWdlbmREYXRhKS5tYXAoa2V5ID0+IF9jb25maWcubGVnZW5kRGF0YVtrZXldKS5tYXAoKHZhbHVlKSA9PiAodmFsdWUpKTtcclxuICAgICAgICAgICAgICAgIC8vIGZvciAobGV0IGkgPSAwOyBpIDwgdGhpcy5waWVEYXRhLmxlbmd0aDsgaSsrKSB7XHJcbiAgICAgICAgICAgICAgICAvLyAgICAgbmV3Q29sb3IucHVzaCh0aGlzLnBpZURhdGFbaV0uY29sb3IpO1xyXG4gICAgICAgICAgICAgICAgLy8gfVxyXG4gICAgICAgICAgICAgICAgLy8gdGhpcy5waWVDb25maWdbJ3BpZUNvbG9yJ10gPSBuZXdDb2xvcjtcclxuXHJcbiAgICAgICAgICAgICAgICB0aGlzLl9yZWRyYXdDaGFydCgpO1xyXG5cclxuICAgICAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgICAgIC8vIGZhaWwtc2FmZSBpbiBjYXNlIGRhdGEgbWFzc2FnZSBoYXZlbid0IGNyZWF0ZSBsZWdlbmREYXRhXHJcbiAgICAgICAgICAgICAgICB0aGlzLl9zZXREYXRhKCk7XHJcbiAgICAgICAgICAgICAgICB0aGlzLl9zZXRDaGFydCgpO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfTtcclxuICAgICAgICB0aGlzLmFwaS5yZWRyYXcgPSAoKSA9PiB7XHJcbiAgICAgICAgICAgIHRoaXMuX3JlZHJhd0NoYXJ0KCk7XHJcbiAgICAgICAgfTtcclxuICAgIH1cclxuXHJcbiAgICBuZ09uQ2hhbmdlcyhfc2ltcGxlQ2hhbmdlczogU2ltcGxlQ2hhbmdlcyk6IHZvaWQge1xyXG4gICAgICAgIGlmIChfc2ltcGxlQ2hhbmdlcy5oYXNPd25Qcm9wZXJ0eSgnZGF0YScpICYmICFfc2ltcGxlQ2hhbmdlc1snZGF0YSddLmZpcnN0Q2hhbmdlKSB7XHJcbiAgICAgICAgICAgIHRoaXMuZGF0YSA9IF9zaW1wbGVDaGFuZ2VzLmRhdGEuY3VycmVudFZhbHVlO1xyXG4gICAgICAgICAgICB0aGlzLl9yZWRyYXdDaGFydCgnZGF0YScpO1xyXG4gICAgICAgIH1cclxuICAgICAgICBpZiAoX3NpbXBsZUNoYW5nZXMuaGFzT3duUHJvcGVydHkoJ3BpZUNvbmZpZycpICYmICFfc2ltcGxlQ2hhbmdlc1sncGllQ29uZmlnJ10uZmlyc3RDaGFuZ2UpIHtcclxuICAgICAgICAgICAgdGhpcy5waWVDb25maWcgPSBfc2ltcGxlQ2hhbmdlcy5waWVDb25maWcuY3VycmVudFZhbHVlO1xyXG4gICAgICAgICAgICB0aGlzLl9yZWRyYXdDaGFydCgnY29uZmlnJyk7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIG5nT25EZXN0cm95KCk6IHZvaWQge1xyXG4gICAgICAgIHRoaXMuX3Jlc2V0Q2hhcnQoKTtcclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF9yZWRyYXdDaGFydChfY2hhbmdlcz86ICdkYXRhJyB8ICdjb25maWcnKSB7XHJcbiAgICAgICAgdGhpcy5fcmVzZXRDaGFydCgpO1xyXG5cclxuICAgICAgICBpZiAoX2NoYW5nZXMgPT09ICdkYXRhJykge1xyXG4gICAgICAgICAgICB0aGlzLnBpZURhdGEgPSBbXTtcclxuICAgICAgICAgICAgdGhpcy5fc2V0RGF0YSgpO1xyXG4gICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgIHRoaXMucGllQ29uZmlnWydsZWdlbmREYXRhJ10gPSB0aGlzLmNvbmZpZ1snbGVnZW5kRGF0YSddO1xyXG4gICAgICAgICAgICB0aGlzLmNvbmZpZyA9IE9iamVjdC5hc3NpZ24oe30sIHRoaXMucGllQ29uZmlnKTtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIHN1cGVyLmNoYXJ0VGltZW91dCgoKSA9PiB0aGlzLl9zZXRDaGFydCgpKTtcclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF9zZXRDaGFydCgpOiB2b2lkIHtcclxuICAgICAgICBzdXBlci5zZXRTdmcoKTtcclxuICAgICAgICBzdXBlci5zZXRTdmdEaW1lbnNpb24oJ3gnKTtcclxuICAgICAgICBzdXBlci5zZXRTdmdEaW1lbnNpb24oJ3knKTtcclxuXHJcbiAgICAgICAgdGhpcy5jaGFydFR5cGUgPSB0aGlzLmRhdGEubGF5b3V0LnNwbGl0KCctJyk7XHJcbiAgICAgICAgdGhpcy5jaGFydENhdGVnb3J5ID0gdGhpcy5kYXRhLnR5cGU7XHJcbiAgICAgICAgLy8gbW92aW5nIHBpZSBjaGFydCB0byBjZW50ZXIgb2Ygc3ZnXHJcbiAgICAgICAgbGV0IGhlaWdodCA9IHRoaXMuc3ZnQ29udGFpbmVyLm5vZGUoKS5nZXRCb3VuZGluZ0NsaWVudFJlY3QoKS5oZWlnaHQ7XHJcbiAgICAgICAgbGV0IHdpZHRoID0gdGhpcy5zdmdDb250YWluZXIubm9kZSgpLmdldEJvdW5kaW5nQ2xpZW50UmVjdCgpLndpZHRoO1xyXG4gICAgICAgIHRoaXMud2lkdGggPSB3aWR0aDtcclxuICAgICAgICB0aGlzLmdyYXBoLmF0dHIoJ3RyYW5zZm9ybScsICd0cmFuc2xhdGUoJyArICh3aWR0aCAvIDIpICsgJywnICsgKGhlaWdodCAvIDIpICsgJyknKTtcclxuXHJcbiAgICAgICAgLy8gbGV0IGNvbG9yID0gdGhpcy5waWVDb25maWdbJ3BpZUNvbG9yJ10gPyBkMy5zY2FsZU9yZGluYWwoKS5yYW5nZSh0aGlzLnBpZUNvbmZpZ1sncGllQ29sb3InXSkgOiBkMy5zY2FsZU9yZGluYWwoKS5yYW5nZSh0aGlzLmNvbmZpZy5jb2xvcnMpO1xyXG4gICAgICAgIC8vIGxldCBjaGFydFBhcmFtcyA9IHtcclxuICAgICAgICAvLyAgICAgJ2NvbG9yJzogY29sb3JcclxuICAgICAgICAvLyB9O1xyXG4gICAgICAgIHRoaXMuZGF0YUxhYmVsQ29udGFpbmVyLnN0eWxlKCd0b3AnLCAwKTtcclxuICAgICAgICB0aGlzLmRhdGFMYWJlbENvbnRhaW5lci5zdHlsZSgnbGVmdCcsIDApO1xyXG5cclxuICAgICAgICBpZiAodGhpcy5jaGFydFR5cGVbMF0gPT09ICdyYWRpYWwnKSB7XHJcbiAgICAgICAgICAgIHRoaXMuX2RyYXdSYWRpYWwoeyBoZWlnaHQ6IGhlaWdodCB9KTtcclxuICAgICAgICB9IGVsc2UgaWYgKHRoaXMuY2hhcnRUeXBlWzBdID09PSAnZ2F1Z2UnKSB7XHJcbiAgICAgICAgICAgIHRoaXMuX2RyYXdHYXVnZSh7IGhlaWdodDogaGVpZ2h0IH0pO1xyXG4gICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgIHRoaXMuX2RyYXdQaWVEb251dCh7IGhlaWdodDogaGVpZ2h0LCB3aWR0aDogd2lkdGggfSk7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIC8qKlxyXG4gICAgICogd2hlbiByZWNlaXZpbmcgZGF0YSBhbmQgbGVnZW5kLCB0aGUgc3RydWN0dXJlIGlzIGN1c3RvbWlzZSB0byBmb3IgbGluZS9hcmVhIGFuZCBiYXIuIHBpZSBuZWVkcyB0byByZWNhbGN1bGF0ZSB0aGUgbGVnZW5kXHJcbiAgICAgKiBfc2V0RGF0YSBnZW5lcmF0ZSBwaWVEYXRhIGFuZCBuZXcgbGVnZW5kIGZyb20gdGhlIHByZXZpb3VzIGxlZ2VuZFxyXG4gICAgICpcclxuICAgICAqIE5vdGU6IHRoaXMucGllRGF0YSBpcyB1c2VkIGZvciByZW5kZXJpbmcuXHJcbiAgICAgKiBOb3RlMjogZGF0YS5waWVEYXRhIGl0IHdpbGwgbm90IGJlIGNoYW5nZWQgb25MZWdlbmRDbGlja1xyXG4gICAgICogKG9uTGVnZW5kQ2xpY2sgYWZmZWN0cyBkYXRhLmRhdGEgd2hpY2ggaXMgc3RvcmVkIGludG8gdGhpcy5waWVEYXRhIHZpYSBhcGkpXHJcbiAgICAgKi9cclxuICAgIHByaXZhdGUgX3NldERhdGEoKTogdm9pZCB7XHJcbiAgICAgICAgaWYgKCF0aGlzLmNvbmZpZy5za2lwTWFzc2FnZSkge1xyXG4gICAgICAgICAgICBpZiAodGhpcy5kYXRhWydwaWVkYXRhJ10pIHtcclxuICAgICAgICAgICAgICAgIHRoaXMucGllRGF0YSA9IHRoaXMuZGF0YS5waWVkYXRhO1xyXG4gICAgICAgICAgICAgICAgLy8gc2F2aW5nIG1hc3NhZ2VkIHBpZWRhdGEgdG8gdGhpcy5kYXRhIGZvciBleHBvcnRcclxuICAgICAgICAgICAgICAgIHRoaXMuZGF0YS5kYXRhID0gdGhpcy5kYXRhLnBpZWRhdGE7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICAvLyB3aGVuIHNraXAgbWFzc2FnZSwgbm8gZ2VuZXJhdGlvbiBvZiBwaWVEYXRhIG5lZWRlZC5cclxuICAgICAgICAgICAgdGhpcy5waWVEYXRhID0gdGhpcy5kYXRhLmRhdGE7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX3Jlc2V0Q2hhcnQoKTogdm9pZCB7XHJcbiAgICAgICAgaWYgKHR5cGVvZiB0aGlzLl9wYXRoICE9PSAndW5kZWZpbmVkJykgdGhpcy5fcGF0aC5yZW1vdmUoKTtcclxuICAgICAgICBpZiAodHlwZW9mIHRoaXMuX3JhZGlhbEF4aXMgIT09ICd1bmRlZmluZWQnKSB0aGlzLl9yYWRpYWxBeGlzLnJlbW92ZSgpO1xyXG4gICAgICAgIGlmICh0eXBlb2YgdGhpcy5fYXhpYWxBeGlzICE9PSAndW5kZWZpbmVkJykgdGhpcy5fYXhpYWxBeGlzLnJlbW92ZSgpO1xyXG4gICAgICAgIGlmICh0eXBlb2YgdGhpcy5fdGV4dCAhPT0gJ3VuZGVmaW5lZCcpIHRoaXMuX3RleHQucmVtb3ZlKCk7XHJcbiAgICAgICAgaWYgKHR5cGVvZiB0aGlzLl9wb2x5bGluZSAhPT0gJ3VuZGVmaW5lZCcpIHRoaXMuX3BvbHlsaW5lLnJlbW92ZSgpO1xyXG4gICAgICAgIGlmICh0eXBlb2YgdGhpcy5fcG9pbnRlciAhPT0gJ3VuZGVmaW5lZCcpIHRoaXMuX3BvaW50ZXIucmVtb3ZlKCk7XHJcbiAgICAgICAgaWYgKHR5cGVvZiB0aGlzLl9wZXJjZW50YWdlVGV4dCAhPT0gJ3VuZGVmaW5lZCcpIHRoaXMuX3BlcmNlbnRhZ2VUZXh0LnJlbW92ZSgpO1xyXG4gICAgICAgIGlmICh0aGlzLmRhdGFMYWJlbENvbnRhaW5lcikgdGhpcy5kYXRhTGFiZWxDb250YWluZXIuc2VsZWN0QWxsKCcqJykucmVtb3ZlKCk7XHJcbiAgICAgICAgdGhpcy5fcG9zQXJyYXkgPSBbXTtcclxuICAgICAgICBjbGVhckludGVydmFsKHRoaXMuX2ludGVydmFsKTtcclxuICAgICAgICBzdXBlci5yZW1vdmVDaGFydCgpO1xyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX2RyYXdQaWVEb251dChfcGFyYW1zOiB7IHdpZHRoOiBudW1iZXIsIGhlaWdodDogbnVtYmVyIH0pOiB2b2lkIHtcclxuICAgICAgICBsZXQgcmFkaXVzID0gTWF0aC5taW4oX3BhcmFtcy53aWR0aCwgX3BhcmFtcy5oZWlnaHQpIC8gMjtcclxuICAgICAgICBpZiAodGhpcy5jaGFydFR5cGVbMV0gJiYgdGhpcy5jaGFydFR5cGVbMV0gPT09ICdoYWxmJykge1xyXG4gICAgICAgICAgICByYWRpdXMgPSAoTWF0aC5taW4oX3BhcmFtcy53aWR0aCwgX3BhcmFtcy5oZWlnaHQpIC8gNSkgKiAzO1xyXG4gICAgICAgICAgICB0aGlzLmdyYXBoLmF0dHIoJ3RyYW5zZm9ybScsICd0cmFuc2xhdGUoJyArIChfcGFyYW1zLndpZHRoIC8gMikgKyAnLCcgKyAoKF9wYXJhbXMuaGVpZ2h0IC8gNCkgKiAzKSArICcpJyk7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGxldCBpbm5lclJhZGl1cyA9IHRoaXMuY2hhcnRUeXBlWzBdID09PSAncGllJyA/IDAgOiAodGhpcy5jb25maWcucGxvdE9wdGlvbnMucGllLmlubmVyUmFkaXVzIC8gMTAwKSAqIHJhZGl1cyAqIDAuODtcclxuICAgICAgICBsZXQgYXJjID0gZDMuYXJjKCkuaW5uZXJSYWRpdXMoaW5uZXJSYWRpdXMpLm91dGVyUmFkaXVzKHJhZGl1cyAqIDAuOCk7XHJcbiAgICAgICAgbGV0IG91dGVyYXJjID0gZDMuYXJjKCkuaW5uZXJSYWRpdXMocmFkaXVzICogMC45KS5vdXRlclJhZGl1cyhyYWRpdXMgKiAwLjkpO1xyXG4gICAgICAgIC8vIGxldCBhcmMgPSBkMy5hcmMoKS5pbm5lclJhZGl1cyhpbm5lclJhZGl1cykub3V0ZXJSYWRpdXMocmFkaXVzKTtcclxuICAgICAgICBsZXQgcGllID0gZDMucGllKCkuc29ydChudWxsKS52YWx1ZSgoZCkgPT4geyByZXR1cm4gZC55OyB9KTtcclxuICAgICAgICBsZXQgZGF0YUxhYmVsQ2hlY2sgPSB0aGlzLmNoYXJ0VHlwZVsxXSA9PT0gJ2Z1bGwnID8gTWF0aC5QSSA6IDA7XHJcbiAgICAgICAgcGllID0gdGhpcy5jaGFydFR5cGVbMV0gPT09ICdmdWxsJyA/IHBpZS5zdGFydEFuZ2xlKDApLmVuZEFuZ2xlKE1hdGguUEkgKiAyKSA6IHBpZS5zdGFydEFuZ2xlKC05MCAqIChNYXRoLlBJIC8gMTgwKSkuZW5kQW5nbGUoOTAgKiAoTWF0aC5QSSAvIDE4MCkpO1xyXG5cclxuICAgICAgICB0aGlzLl9wYXRoID0gdGhpcy5ncmFwaC5zZWxlY3RBbGwoJ3BhdGgnKVxyXG4gICAgICAgICAgICAuZGF0YShwaWUodGhpcy5waWVEYXRhKSlcclxuICAgICAgICAgICAgLmVudGVyKClcclxuICAgICAgICAgICAgLmFwcGVuZCgncGF0aCcpXHJcbiAgICAgICAgICAgIC5hdHRyKCdhcmlhLXZhbHVlJywgKGQpID0+IGQuZGF0YS55KVxyXG4gICAgICAgICAgICAuYXR0cignYXJpYS1zZXJpZXMtbmFtZScsIChkKSA9PiB0aGlzLmxlZ2VuZFtkLmRhdGEuaWRdLm5hbWUpXHJcbiAgICAgICAgICAgIC5hdHRyKCdjbGFzcycsIChkKSA9PiB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLl9wb3NBcnJheS5wdXNoKHsgJ3gnOiBkLmRhdGEuaW5kZXgsICd2YWx1ZSc6IGQuZGF0YS55LCAnaWQnOiBkLmRhdGEuaW5kZXggfSk7XHJcbiAgICAgICAgICAgICAgICByZXR1cm4gJ3gtJyArIGQuZGF0YS5pbmRleCArICcgeS0nICsgZC5kYXRhLmluZGV4O1xyXG4gICAgICAgICAgICAgICAgLy8gcmV0dXJuICd4LScgKyAoZC5kYXRhLnhCYXNlKS5yZXBsYWNlKC8gL2csJycpICsgJyB5LScgKyBzZXJpZXNJZDtcclxuICAgICAgICAgICAgfSlcclxuICAgICAgICAgICAgLmF0dHIoJ2lkJywgKGQpID0+IHtcclxuICAgICAgICAgICAgICAgIHJldHVybiBkLmRhdGEuaW5kZXg7XHJcbiAgICAgICAgICAgICAgICAvLyByZXR1cm4gKGQuZGF0YS54KS5yZXBsYWNlKC8gL2csJycpO1xyXG4gICAgICAgICAgICB9KVxyXG4gICAgICAgICAgICAuYXR0cignZmlsbCcsIChkLCBpKSA9PiB7XHJcbiAgICAgICAgICAgICAgICByZXR1cm4gdGhpcy5sZWdlbmRbZC5kYXRhLmlkXS5jb2xvcjsgLy8gY29sb3Igc2hvdWxkIGZvbGxvdyBsZWdlbmREYXRhXHJcbiAgICAgICAgICAgIH0pXHJcbiAgICAgICAgICAgIC8vIC5hdHRyKCdkJywgYXJjKVxyXG4gICAgICAgICAgICAuc3R5bGUoJ3N0cm9rZScsIHRoaXMuY29uZmlnLnBsb3RPcHRpb25zLnBpZS5ib3JkZXJDb2xvcilcclxuICAgICAgICAgICAgLnN0eWxlKCdzdHJva2Utd2lkdGgnLCB0aGlzLmNvbmZpZy5wbG90T3B0aW9ucy5waWUuYm9yZGVyV2lkdGggfHwgMCk7XHJcblxyXG4gICAgICAgIGxldCBsYWJlbFBhcmFtcyA9IHtcclxuICAgICAgICAgICAgJ3BpZSc6IHBpZSxcclxuICAgICAgICAgICAgJ2FyYyc6IGFyYyxcclxuICAgICAgICAgICAgJ291dGVyYXJjJzogb3V0ZXJhcmMsXHJcbiAgICAgICAgICAgICdyYWRpdXMnOiByYWRpdXMsXHJcbiAgICAgICAgICAgICdkYXRhTGFiZWxDaGVjayc6IGRhdGFMYWJlbENoZWNrLFxyXG4gICAgICAgICAgICAvLyAnY29sb3InOiBfcGFyYW1zLmNvbG9yXHJcbiAgICAgICAgfTtcclxuXHJcbiAgICAgICAgaWYgKCF0aGlzLmNvbmZpZy5hbmltYXRpb24pIHtcclxuICAgICAgICAgICAgdGhpcy5fcGF0aFxyXG4gICAgICAgICAgICAgICAgLmF0dHIoJ2QnLCBkID0+IGFyYyhkKSlcclxuICAgICAgICAgICAgICAgIC5hdHRyKCdwb3MnLCBkID0+IGdldFBvcyhkLCB0aGlzLmNoYXJ0VHlwZVsxXSkpO1xyXG5cclxuICAgICAgICAgICAgdGhpcy5fc2V0RGF0YUxhYmVsKGxhYmVsUGFyYW1zKTtcclxuXHJcbiAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgdGhpcy5fcGF0aC50cmFuc2l0aW9uKClcclxuICAgICAgICAgICAgICAgIC5kZWxheSgoZCwgaSkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBpICogMjA7XHJcbiAgICAgICAgICAgICAgICB9KVxyXG4gICAgICAgICAgICAgICAgLmF0dHJUd2VlbignZCcsIChkKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgbGV0IGkgPSBkMy5pbnRlcnBvbGF0ZShkLnN0YXJ0QW5nbGUsIGQuZW5kQW5nbGUpO1xyXG4gICAgICAgICAgICAgICAgICAgIHJldHVybiAodCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBkLmVuZEFuZ2xlID0gaSh0KTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIGFyYyhkKTtcclxuICAgICAgICAgICAgICAgICAgICB9O1xyXG4gICAgICAgICAgICAgICAgfSlcclxuICAgICAgICAgICAgICAgIC5hdHRyVHdlZW4oJ3BvcycsIChkKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgbGV0IGN1cnJlbnQ7XHJcbiAgICAgICAgICAgICAgICAgICAgY3VycmVudCA9IGN1cnJlbnQgfHwgZDtcclxuICAgICAgICAgICAgICAgICAgICBsZXQgaW50ZXJwb2xhdGUgPSBkMy5pbnRlcnBvbGF0ZShjdXJyZW50LCBkKTtcclxuICAgICAgICAgICAgICAgICAgICBjdXJyZW50ID0gaW50ZXJwb2xhdGUoMCk7XHJcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuICh0KSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGxldCBkMiA9IGludGVycG9sYXRlKHQpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gZ2V0UG9zKGQyLCB0aGlzLmNoYXJ0VHlwZVsxXSk7XHJcbiAgICAgICAgICAgICAgICAgICAgfTtcclxuICAgICAgICAgICAgICAgIH0pXHJcbiAgICAgICAgICAgICAgICAub24oJ2VuZCcsIChkLCBpKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKGkgPT09ICh0aGlzLnBpZURhdGEubGVuZ3RoIC0gMSkpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgc2V0VGltZW91dCgoKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0aGlzLl9zZXREYXRhTGFiZWwobGFiZWxQYXJhbXMpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIHRoaXMuX3BhdGguZXhpdCgpLnJlbW92ZSgpO1xyXG5cclxuICAgICAgICBmdW5jdGlvbiBnZXRQb3MoX2QyLCBfY2hhcnRUeXBlKSB7XHJcbiAgICAgICAgICAgIGxldCBwb3MgPSBvdXRlcmFyYy5jZW50cm9pZChfZDIpO1xyXG4gICAgICAgICAgICBpZiAoX2NoYXJ0VHlwZSAmJiBfY2hhcnRUeXBlID09PSAnaGFsZicpIHtcclxuICAgICAgICAgICAgICAgIHBvc1swXSA9IHJhZGl1cyAqIChtaWRBbmdsZShfZDIpIDwgZGF0YUxhYmVsQ2hlY2sgPyAtMSA6IDEpO1xyXG4gICAgICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgcG9zWzBdID0gcmFkaXVzICogKG1pZEFuZ2xlKF9kMikgPCBkYXRhTGFiZWxDaGVjayA/IDEgOiAtMSk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgcmV0dXJuIHBvcztcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIGZ1bmN0aW9uIG1pZEFuZ2xlKF9kKSB7XHJcbiAgICAgICAgICAgIHJldHVybiBfZC5zdGFydEFuZ2xlICsgKF9kLmVuZEFuZ2xlIC0gX2Quc3RhcnRBbmdsZSkgLyAyO1xyXG4gICAgICAgIH1cclxuICAgICAgICBsZXQgZXZlbnRzUGFyYW0gPSB7XHJcbiAgICAgICAgICAgICdpbm5lclJhZGl1cyc6IGlubmVyUmFkaXVzLFxyXG4gICAgICAgICAgICAnb3V0ZXJSYWRpdXMnOiByYWRpdXMgKiAwLjgsXHJcbiAgICAgICAgICAgICdwYXRoQW5pbSc6IHRoaXMuX3BhdGhBbmltLFxyXG4gICAgICAgIH07XHJcbiAgICAgICAgc3VwZXIuX2luaXRNb3VzZUV2ZW50cyh0aGlzLl9wYXRoLCBldmVudHNQYXJhbSk7XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfZHJhd1JhZGlhbChfcGFyYW1zOiB7IHdpZHRoPzogbnVtYmVyLCBoZWlnaHQ6IG51bWJlciB9KTogdm9pZCB7XHJcbiAgICAgICAgLy8gbGV0IGhlaWdodCA9IGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3IoJyMnICsgdGhpcy5jb25maWcuaWQgKyAnLmtkeC1jaGFydHMgLnN2Zy1jb250YWluZXInKS5nZXRCb3VuZGluZ0NsaWVudFJlY3QoKS5oZWlnaHQ7XHJcbiAgICAgICAgbGV0IGNoYXJ0UmFkaXVzID0gX3BhcmFtcy5oZWlnaHQgLyAyIC0gNDA7XHJcbiAgICAgICAgbGV0IHNjYWxlID0gZDMuc2NhbGVMaW5lYXIoKVxyXG4gICAgICAgICAgICAuZG9tYWluKFswLCBkMy5tYXgodGhpcy5waWVEYXRhLCBkID0+IGQueSkgKiAxLjFdKVxyXG4gICAgICAgICAgICAucmFuZ2UoWzAsIDIgKiBQSV0pO1xyXG4gICAgICAgIGxldCB0aWNrcyA9IHNjYWxlLnRpY2tzKG51bVRpY2tzKS5zbGljZSgwLCAtMSk7XHJcbiAgICAgICAgbGV0IGtleXMgPSB0aGlzLnBpZURhdGEubWFwKChkLCBpKSA9PiBkLngpO1xyXG4gICAgICAgIC8vIG51bWJlciBvZiBhcmNzXHJcbiAgICAgICAgY29uc3QgbnVtQXJjcyA9IGtleXMubGVuZ3RoO1xyXG4gICAgICAgIGNvbnN0IGFyY1dpZHRoID0gKGNoYXJ0UmFkaXVzIC0gYXJjTWluUmFkaXVzIC0gbnVtQXJjcyAqIGFyY1BhZGRpbmcpIC8gbnVtQXJjcztcclxuXHJcbiAgICAgICAgbGV0IGFyYyA9IGQzLmFyYygpXHJcbiAgICAgICAgICAgIC5pbm5lclJhZGl1cygoZCwgaSkgPT4gdGhpcy5fZ2V0SW5uZXJSYWRpdXMoaSwgbnVtQXJjcywgYXJjV2lkdGgpKVxyXG4gICAgICAgICAgICAub3V0ZXJSYWRpdXMoKGQsIGkpID0+IHRoaXMuX2dldE91dGVyUmFkaXVzKGksIG51bUFyY3MsIGFyY1dpZHRoKSlcclxuICAgICAgICAgICAgLnN0YXJ0QW5nbGUoMClcclxuICAgICAgICAgICAgLmVuZEFuZ2xlKChkLCBpKSA9PiBzY2FsZShkKSk7XHJcblxyXG4gICAgICAgIHRoaXMuX3JhZGlhbEF4aXMgPSB0aGlzLmdyYXBoLmFwcGVuZCgnZycpXHJcbiAgICAgICAgICAgIC5hdHRyKCdjbGFzcycsICdrZHgtY2hhcnRzLXIga2R4LWNoYXJ0cy1heGlzLXJhZGlhbCcpXHJcbiAgICAgICAgICAgIC5zZWxlY3RBbGwoJ2cnKVxyXG4gICAgICAgICAgICAuZGF0YSh0aGlzLnBpZURhdGEpXHJcbiAgICAgICAgICAgIC5lbnRlcigpLmFwcGVuZCgnZycpO1xyXG5cclxuICAgICAgICB0aGlzLl9yYWRpYWxBeGlzLmFwcGVuZCgnY2lyY2xlJylcclxuICAgICAgICAgICAgLmF0dHIoJ3InLCAoZCwgaSkgPT4gdGhpcy5fZ2V0T3V0ZXJSYWRpdXMoaSwgbnVtQXJjcywgYXJjV2lkdGgpICsgYXJjUGFkZGluZyk7XHJcblxyXG4gICAgICAgIHRoaXMuX3JhZGlhbEF4aXMuYXBwZW5kKCd0ZXh0JylcclxuICAgICAgICAgICAgLmF0dHIoJ3gnLCBsYWJlbFBhZGRpbmcpXHJcbiAgICAgICAgICAgIC5hdHRyKCd5JywgKGQsIGkpID0+IC10aGlzLl9nZXRPdXRlclJhZGl1cyhpLCBudW1BcmNzLCBhcmNXaWR0aCkgKyBhcmNQYWRkaW5nKVxyXG4gICAgICAgICAgICAuc3R5bGUoJ2ZvbnQtc2l6ZScsICcxMHB4JylcclxuICAgICAgICAgICAgLnRleHQoZCA9PiBkLngpO1xyXG5cclxuICAgICAgICB0aGlzLl9heGlhbEF4aXMgPSB0aGlzLmdyYXBoLmFwcGVuZCgnZycpXHJcbiAgICAgICAgICAgIC5hdHRyKCdjbGFzcycsICdrZHgtY2hhcnRzLWEga2R4LWNoYXJ0cy1heGlzLXJhZGlhbCcpXHJcbiAgICAgICAgICAgIC5zZWxlY3RBbGwoJ2cnKVxyXG4gICAgICAgICAgICAuZGF0YSh0aWNrcylcclxuICAgICAgICAgICAgLmVudGVyKCkuYXBwZW5kKCdnJylcclxuICAgICAgICAgICAgLmF0dHIoJ3RyYW5zZm9ybScsIGQgPT4gJ3JvdGF0ZSgnICsgKHRoaXMuX3JhZDJkZWcoc2NhbGUoZCkpIC0gOTApICsgJyknKTtcclxuXHJcbiAgICAgICAgdGhpcy5fYXhpYWxBeGlzLmFwcGVuZCgnbGluZScpXHJcbiAgICAgICAgICAgIC5hdHRyKCd4MicsIGNoYXJ0UmFkaXVzKTtcclxuXHJcbiAgICAgICAgdGhpcy5fYXhpYWxBeGlzLmFwcGVuZCgndGV4dCcpXHJcbiAgICAgICAgICAgIC5hdHRyKCd4JywgY2hhcnRSYWRpdXMgKyAxMClcclxuICAgICAgICAgICAgLnN0eWxlKCd0ZXh0LWFuY2hvcicsIGQgPT4gKHNjYWxlKGQpID49IFBJICYmIHNjYWxlKGQpIDwgMiAqIFBJID8gJ2VuZCcgOiBudWxsKSlcclxuICAgICAgICAgICAgLnN0eWxlKCdmb250LXNpemUnLCAnMTBweCcpXHJcbiAgICAgICAgICAgIC5hdHRyKCd0cmFuc2Zvcm0nLCBkID0+ICdyb3RhdGUoJyArICg5MCAtIHRoaXMuX3JhZDJkZWcoc2NhbGUoZCkpKSArICcsJyArIChjaGFydFJhZGl1cyArIDEwKSArICcsMCknKVxyXG4gICAgICAgICAgICAudGV4dChkID0+IGQpO1xyXG5cclxuICAgICAgICAvLyBkYXRhIGFyY3NcclxuICAgICAgICB0aGlzLl9wYXRoID0gdGhpcy5ncmFwaC5hcHBlbmQoJ2cnKVxyXG4gICAgICAgICAgICAuc2VsZWN0QWxsKCdwYXRoJylcclxuICAgICAgICAgICAgLmRhdGEodGhpcy5waWVEYXRhKVxyXG4gICAgICAgICAgICAuZW50ZXIoKS5hcHBlbmQoJ3BhdGgnKVxyXG4gICAgICAgICAgICAuYXR0cignY2xhc3MnLCAoZCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgcmV0dXJuICd4LScgKyBkLnhCYXNlICsgJyB5LScgKyBkLng7XHJcbiAgICAgICAgICAgIH0pXHJcbiAgICAgICAgICAgIC5zdHlsZSgnZmlsbCcsIChkLCBpKSA9PiB0aGlzLmxlZ2VuZFtkLmlkXS5jb2xvcik7XHJcblxyXG4gICAgICAgIGlmICghdGhpcy5jb25maWcuYW5pbWF0aW9uKSB7XHJcbiAgICAgICAgICAgIHRoaXMuX3BhdGguYXR0cignZCcsIChkLCBpKSA9PiBhcmMoZC55LCBpKSk7XHJcbiAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgdGhpcy5fcGF0aC50cmFuc2l0aW9uKClcclxuICAgICAgICAgICAgICAgIC5kZWxheSgoZCwgaSkgPT4gaSAqIDEwMClcclxuICAgICAgICAgICAgICAgIC5kdXJhdGlvbigyMDApXHJcbiAgICAgICAgICAgICAgICAvLyAuYXR0clR3ZWVuKCdkJywgYXJjVHdlZW4pO1xyXG4gICAgICAgICAgICAgICAgLmF0dHJUd2VlbignZCcsIChkLCBpKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgbGV0IGludGVycG9sYXRlID0gZDMuaW50ZXJwb2xhdGUoMCwgZC55KTtcclxuICAgICAgICAgICAgICAgICAgICByZXR1cm4gdCA9PiBhcmMoaW50ZXJwb2xhdGUodCksIGkpO1xyXG4gICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICBzdXBlci5faW5pdE1vdXNlRXZlbnRzKHRoaXMuX3BhdGgpO1xyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX2RyYXdHYXVnZShfcGFyYW1zOiB7IGhlaWdodDogbnVtYmVyIH0pOiB2b2lkIHtcclxuICAgICAgICAvLyBsZXQgcGVyY2VudCA9IDEwMC4wMDtcclxuICAgICAgICBsZXQgcGVyY2VudCA9IE1hdGguZmxvb3IoTWF0aC5yYW5kb20oKSAqIDEwMCk7XHJcbiAgICAgICAgbGV0IGVuZEFuZ2xlID0gdGhpcy5jaGFydFR5cGVbMV0gPT09ICdmdWxsJyA/IE1hdGguUEkgKiAyIDogTWF0aC5QSTtcclxuICAgICAgICBsZXQgb3V0ZXJSYWRpdXMgPSBfcGFyYW1zLmhlaWdodCAvIDM7XHJcbiAgICAgICAgbGV0IGlubmVyUmFkaXVzID0gKG91dGVyUmFkaXVzIC8gMykgKiAyO1xyXG4gICAgICAgIGxldCBmb250U2l6ZSA9IGlubmVyUmFkaXVzICogMC44O1xyXG5cclxuICAgICAgICBsZXQgYXJjID0gZDMuYXJjKClcclxuICAgICAgICAgICAgLmlubmVyUmFkaXVzKGlubmVyUmFkaXVzKVxyXG4gICAgICAgICAgICAub3V0ZXJSYWRpdXMob3V0ZXJSYWRpdXMpXHJcbiAgICAgICAgICAgIC5zdGFydEFuZ2xlKDApXHJcbiAgICAgICAgICAgIC5lbmRBbmdsZShlbmRBbmdsZSk7XHJcblxyXG4gICAgICAgIGxldCBhcmNMaW5lID0gZDMuYXJjKClcclxuICAgICAgICAgICAgLmlubmVyUmFkaXVzKGlubmVyUmFkaXVzKVxyXG4gICAgICAgICAgICAub3V0ZXJSYWRpdXMob3V0ZXJSYWRpdXMpXHJcbiAgICAgICAgICAgIC5zdGFydEFuZ2xlKDApO1xyXG5cclxuICAgICAgICB0aGlzLl9wYXRoID0gdGhpcy5ncmFwaC5hcHBlbmQoJ3BhdGgnKVxyXG4gICAgICAgICAgICAuYXR0cignZCcsIGFyYylcclxuICAgICAgICAgICAgLmF0dHIoJ3RyYW5zZm9ybScsICdyb3RhdGUoLTkwKScpXHJcbiAgICAgICAgICAgIC5hdHRyKCdzdHJva2Utd2lkdGgnLCAxKVxyXG4gICAgICAgICAgICAuYXR0cignc3Ryb2tlJywgJyM2NjY2NjYnKVxyXG4gICAgICAgICAgICAuc3R5bGUoJ2ZpbGwnLCAnI0ZGRkZGRicpO1xyXG5cclxuXHJcbiAgICAgICAgdGhpcy5fcG9pbnRlciA9IHRoaXMuZ3JhcGguYXBwZW5kKCdwYXRoJylcclxuICAgICAgICAgICAgLy8gbGV0IHBhdGhGb3JlZ3JvdW5kID0gdGhpcy5ncmFwaC5hcHBlbmQoJ3BhdGgnKVxyXG4gICAgICAgICAgICAuZGF0dW0oeyBlbmRBbmdsZTogMCB9KVxyXG4gICAgICAgICAgICAuYXR0cignZCcsIGFyY0xpbmUpXHJcbiAgICAgICAgICAgIC5hdHRyKCd0cmFuc2Zvcm0nLCAncm90YXRlKC05MCknKTtcclxuXHJcblxyXG4gICAgICAgIHRoaXMuX3BlcmNlbnRhZ2VUZXh0ID0gdGhpcy5ncmFwaC5hcHBlbmQoJ3RleHQnKVxyXG4gICAgICAgICAgICAuZGF0dW0oMClcclxuICAgICAgICAgICAgLnRleHQoZnVuY3Rpb24oZCkge1xyXG4gICAgICAgICAgICAgICAgcmV0dXJuIGQ7XHJcbiAgICAgICAgICAgIH0pXHJcbiAgICAgICAgICAgIC5hdHRyKCdjbGFzcycsICdrZHgtY2hhcnRzLW1pZGRsZVRleHQnKVxyXG4gICAgICAgICAgICAuYXR0cigndGV4dC1hbmNob3InLCAnbWlkZGxlJylcclxuICAgICAgICAgICAgLmF0dHIoJ2R5JywgdGhpcy5jaGFydFR5cGVbMV0gPT09ICdmdWxsJyA/IGZvbnRTaXplICogMC40NSA6IDApXHJcbiAgICAgICAgICAgIC5zdHlsZSgnZmlsbCcsIGQzLnJnYignIzAwMDAwMCcpKVxyXG4gICAgICAgICAgICAuc3R5bGUoJ2ZvbnQtc2l6ZScsIGZvbnRTaXplICsgJ3B4Jyk7XHJcblxyXG4gICAgICAgIGlmICghdGhpcy5jb25maWcuYW5pbWF0aW9uKSB7XHJcbiAgICAgICAgICAgIHRoaXMuX3BvaW50ZXJcclxuICAgICAgICAgICAgICAgIC5hdHRyKCdkJywgZCA9PiBhcmNMaW5lKGQpKVxyXG4gICAgICAgICAgICAgICAgLnN0eWxlKCdmaWxsJywgZDMucmdiKCcjRkYwMDAwJykpO1xyXG4gICAgICAgICAgICByZXR1cm47XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICBsZXQgYXJjVHdlZW4gPSBmdW5jdGlvbih0cmFuc2l0aW9uLCBuZXdWYWx1ZSwgdGVzdCkge1xyXG4gICAgICAgICAgICB0cmFuc2l0aW9uLmF0dHJUd2VlbignZCcsIChkKSA9PiB7XHJcbiAgICAgICAgICAgICAgICBsZXQgaW50ZXJwb2xhdGUgPSBkMy5pbnRlcnBvbGF0ZShkLmVuZEFuZ2xlLCAoKGVuZEFuZ2xlKSkgKiAobmV3VmFsdWUgLyAxMDApKTtcclxuICAgICAgICAgICAgICAgIGxldCBpbnRlcnBvbGF0ZUNvdW50ID0gZDMuaW50ZXJwb2xhdGUoMCwgbmV3VmFsdWUpO1xyXG5cclxuICAgICAgICAgICAgICAgIHJldHVybiAodCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgIGQuZW5kQW5nbGUgPSBpbnRlcnBvbGF0ZSh0KTtcclxuICAgICAgICAgICAgICAgICAgICB0ZXN0Ll9wZXJjZW50YWdlVGV4dC50ZXh0KE1hdGguZmxvb3IoaW50ZXJwb2xhdGVDb3VudCh0KSkgKyAnJScpO1xyXG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBhcmNMaW5lKGQpO1xyXG4gICAgICAgICAgICAgICAgfTtcclxuICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgfTtcclxuXHJcbiAgICAgICAgdGhpcy5fcG9pbnRlci50cmFuc2l0aW9uKClcclxuICAgICAgICAgICAgLmR1cmF0aW9uKDc1MClcclxuICAgICAgICAgICAgLmVhc2UoZDMuZWFzZUN1YmljSW4pXHJcbiAgICAgICAgICAgIC5jYWxsKGFyY1R3ZWVuLCBwZXJjZW50LCB0aGlzKVxyXG4gICAgICAgICAgICAuc3R5bGUoJ2ZpbGwnLCBkMy5yZ2IoJyNGRjAwMDAnKSk7XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfc2V0RGF0YUxhYmVsKF9wYXJhbXM6IGFueSk6IHZvaWQge1xyXG4gICAgICAgIGlmICghdGhpcy5jb25maWcuY2hhcnQubGFiZWxzLmVuYWJsZWQpIHJldHVybjtcclxuICAgICAgICBpZiAodGhpcy5jaGFydENhdGVnb3J5ICE9PSAncGllJykgcmV0dXJuO1xyXG4gICAgICAgIGlmICh0aGlzLl9wb3NBcnJheS5sZW5ndGggPT09IDApIHJldHVybjtcclxuICAgICAgICBsZXQgbGluZSA9IEFycmF5LmZyb20oZG9jdW1lbnQucXVlcnlTZWxlY3RvckFsbCgnIycgKyB0aGlzLmNvbmZpZy5pZCArICcua2R4LWNoYXJ0cyAua2R4LWNoYXJ0cy1saW5lcycpKTtcclxuICAgICAgICBsaW5lLmZvckVhY2goZSA9PiBlLnBhcmVudE5vZGUucmVtb3ZlQ2hpbGQoZSkpO1xyXG5cclxuICAgICAgICBsZXQga2V5ID0gKGQpID0+IHsgcmV0dXJuIGQuZGF0YS55OyB9O1xyXG5cclxuICAgICAgICBmdW5jdGlvbiBtaWRBbmdsZShfZCkge1xyXG4gICAgICAgICAgICByZXR1cm4gX2Quc3RhcnRBbmdsZSArIChfZC5lbmRBbmdsZSAtIF9kLnN0YXJ0QW5nbGUpIC8gMjtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIGxldCBoZWlnaHQgPSB0aGlzLnN2Z0NvbnRhaW5lci5ub2RlKCkuZ2V0Qm91bmRpbmdDbGllbnRSZWN0KCkuaGVpZ2h0O1xyXG4gICAgICAgIGxldCB3aWR0aCA9IHRoaXMuc3ZnQ29udGFpbmVyLm5vZGUoKS5nZXRCb3VuZGluZ0NsaWVudFJlY3QoKS53aWR0aDtcclxuICAgICAgICBoZWlnaHQgPSAodGhpcy5jaGFydFR5cGVbMV0gJiYgdGhpcy5jaGFydFR5cGVbMV0gPT09ICdoYWxmJykgPyAoKGhlaWdodCAvIDQpICogMykgLSA4IDogaGVpZ2h0IC8gMiAtIDg7XHJcbiAgICAgICAgZm9yIChsZXQgaSA9IDA7IGkgPCB0aGlzLl9wYXRoLl9ncm91cHNbMF0ubGVuZ3RoOyBpKyspIHtcclxuICAgICAgICAgICAgaWYgKHRoaXMuX3Bvc0FycmF5W2ldICYmIHRoaXMuX3Bvc0FycmF5W2ldLmlkICE9PSB1bmRlZmluZWQpIHtcclxuICAgICAgICAgICAgICAgIGxldCBwb3NQb2ludGVyID0gZG9jdW1lbnQucXVlcnlTZWxlY3RvcignIycgKyB0aGlzLmNvbmZpZy5pZCArICcgIycgKyB0aGlzLl9wb3NBcnJheVtpXS5pZCkuZ2V0QXR0cmlidXRlKCdwb3MnKTtcclxuICAgICAgICAgICAgICAgIGlmICh0aGlzLl9wb3NBcnJheS5sZW5ndGggIT09IDAgJiYgZG9jdW1lbnQucXVlcnlTZWxlY3RvcignIycgKyB0aGlzLmNvbmZpZy5pZCArICcgIycgKyB0aGlzLl9wb3NBcnJheVtpXS5pZCkgIT09IG51bGwgJiYgcG9zUG9pbnRlciAhPT0gbnVsbCkge1xyXG4gICAgICAgICAgICAgICAgICAgIGxldCB5RGF0YSA9IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgJ2lkJzogdGhpcy5fcG9zQXJyYXlbaV0uaWQsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICd2YWx1ZSc6IHRoaXMuX3Bvc0FycmF5W2ldLnZhbHVlXHJcbiAgICAgICAgICAgICAgICAgICAgfTtcclxuICAgICAgICAgICAgICAgICAgICBsZXQgeHZhbHVlOiBudW1iZXIgPSBwYXJzZUludChwb3NQb2ludGVyLnNwbGl0KCcsJylbMF0pICsgd2lkdGggLyAyO1xyXG4gICAgICAgICAgICAgICAgICAgIGxldCB5dmFsdWU6IG51bWJlciA9IHBhcnNlSW50KHBvc1BvaW50ZXIuc3BsaXQoJywnKVsxXSkgKyBoZWlnaHQ7XHJcbiAgICAgICAgICAgICAgICAgICAgbGV0IHRlbXBDb25kaXRpb246IG51bWJlciA9IHBhcnNlSW50KHBvc1BvaW50ZXIuc3BsaXQoJywnKVswXSk7XHJcbiAgICAgICAgICAgICAgICAgICAgbGV0IHJ0bENvbmRpdGlvbjogYm9vbGVhbiA9IHRoaXMuaXNSdGwgPT09IGZhbHNlID8gdGVtcENvbmRpdGlvbiA8IDAgOiB0ZW1wQ29uZGl0aW9uID4gMDtcclxuICAgICAgICAgICAgICAgICAgICBsZXQgY2hlY2tGbGV4RW5kU3R5bGU6IHN0cmluZyA9IHJ0bENvbmRpdGlvbiA/ICdmbGV4LWVuZCcgOiAnZmxleC1zdGFydCc7XHJcbiAgICAgICAgICAgICAgICAgICAgbGV0IGRhdGFMYWJlbENsYXNzID0gJyMnICsgdGhpcy5jb25maWcuaWQgKyAnIC5rZHgtY2hhcnRzLWRhdGEtbGFiZWwueC0nICsgdGhpcy5fcG9zQXJyYXlbaV0ueCArICcueS0nICsgeURhdGEuaWQ7XHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3IoZGF0YUxhYmVsQ2xhc3MpID09IG51bGwpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgc3VwZXIuc2V0TGFiZWwoeURhdGEsIHRoaXMuX3Bvc0FycmF5W2ldLngsIHh2YWx1ZSwgeXZhbHVlKS5zdHlsZSgndmlzaWJpbGl0eScsICd2aXNpYmxlJykuc3R5bGUoJ3dpZHRoJywgJzBweCcpLnN0eWxlKCdqdXN0aWZ5LWNvbnRlbnQnLCBjaGVja0ZsZXhFbmRTdHlsZSk7XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICB0aGlzLl9wb2x5bGluZSA9IHRoaXMuZ3JhcGguYXBwZW5kKCdnJylcclxuICAgICAgICAgICAgLmF0dHIoJ2NsYXNzJywgJ2tkeC1jaGFydHMtbGluZXMnKVxyXG4gICAgICAgICAgICAuc2VsZWN0QWxsKCdwb2x5bGluZScpXHJcbiAgICAgICAgICAgIC5kYXRhKF9wYXJhbXMucGllKHRoaXMucGllRGF0YSksIGtleSlcclxuICAgICAgICAgICAgLmVudGVyKClcclxuICAgICAgICAgICAgLmFwcGVuZCgncG9seWxpbmUnKVxyXG4gICAgICAgICAgICAuc3R5bGUoJ3N0cm9rZScsIChkLCBpKSA9PiB7XHJcbiAgICAgICAgICAgICAgICByZXR1cm4gdGhpcy5sZWdlbmRbZC5kYXRhLmlkXS5jb2xvcjtcclxuICAgICAgICAgICAgfSkuYXR0cigncG9pbnRzJywgKGQpID0+IHtcclxuICAgICAgICAgICAgICAgIHJldHVybiBnZXRQb3MoZCwgdGhpcy5jaGFydFR5cGVbMV0pO1xyXG4gICAgICAgICAgICB9KS5zdHlsZSgnZmlsbCcsICdub25lJyk7XHJcblxyXG4gICAgICAgIC8vIGlmICghdGhpcy5jb25maWcuYW5pbWF0aW9uKSB7XHJcbiAgICAgICAgLy8gICAgIHRoaXMuX3BvbHlsaW5lLmF0dHIoJ3BvaW50cycsIChkKSA9PiB7XHJcbiAgICAgICAgLy8gICAgICAgICByZXR1cm4gZ2V0UG9zKGQsIHRoaXMuY2hhcnRUeXBlWzFdKTtcclxuICAgICAgICAvLyAgICAgfSk7XHJcbiAgICAgICAgLy8gICAgIHJldHVybjtcclxuICAgICAgICAvLyB9XHJcblxyXG4gICAgICAgIC8vIHRoaXMuX3BvbHlsaW5lLnRyYW5zaXRpb24oKS5kdXJhdGlvbigxMDAwKVxyXG4gICAgICAgIC8vICAgICAuYXR0clR3ZWVuKCdwb2ludHMnLCAoZCkgPT4ge1xyXG4gICAgICAgIC8vICAgICAgICAgdGhpcy5fY3VycmVudCA9IHRoaXMuX2N1cnJlbnQgfHwgZDtcclxuICAgICAgICAvLyAgICAgICAgIGxldCBpbnRlcnBvbGF0ZSA9IGQzLmludGVycG9sYXRlKHRoaXMuX2N1cnJlbnQsIGQpO1xyXG4gICAgICAgIC8vICAgICAgICAgdGhpcy5fY3VycmVudCA9IGludGVycG9sYXRlKDApO1xyXG4gICAgICAgIC8vICAgICAgICAgcmV0dXJuICh0KSA9PiB7XHJcbiAgICAgICAgLy8gICAgICAgICAgICAgbGV0IGQyID0gaW50ZXJwb2xhdGUodCk7XHJcbiAgICAgICAgLy8gICAgICAgICAgICAgcmV0dXJuIGdldFBvcyhkMiwgdGhpcy5jaGFydFR5cGVbMV0pO1xyXG4gICAgICAgIC8vICAgICAgICAgfTtcclxuICAgICAgICAvLyAgICAgfSk7XHJcblxyXG4gICAgICAgIGZ1bmN0aW9uIGdldFBvcyhfZDIsIF9jaGFydFR5cGUpIHtcclxuICAgICAgICAgICAgbGV0IHBvcyA9IF9wYXJhbXMub3V0ZXJhcmMuY2VudHJvaWQoX2QyKTtcclxuICAgICAgICAgICAgaWYgKF9jaGFydFR5cGUgJiYgX2NoYXJ0VHlwZSA9PT0gJ2hhbGYnKSB7XHJcbiAgICAgICAgICAgICAgICBwb3NbMF0gPSBfcGFyYW1zLnJhZGl1cyAqIDAuOTUgKiAobWlkQW5nbGUoX2QyKSA8IF9wYXJhbXMuZGF0YUxhYmVsQ2hlY2sgPyAtMSA6IDEpO1xyXG4gICAgICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgcG9zWzBdID0gX3BhcmFtcy5yYWRpdXMgKiAwLjk1ICogKG1pZEFuZ2xlKF9kMikgPCBfcGFyYW1zLmRhdGFMYWJlbENoZWNrID8gMSA6IC0xKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICByZXR1cm4gW19wYXJhbXMuYXJjLmNlbnRyb2lkKF9kMiksIF9wYXJhbXMub3V0ZXJhcmMuY2VudHJvaWQoX2QyKSwgcG9zXTtcclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG5cclxuICAgIHByaXZhdGUgX2dldElubmVyUmFkaXVzKF9pbmRleDogbnVtYmVyLCBfbnVtQXJjczogbnVtYmVyLCBfYXJjV2lkdGg6IG51bWJlcik6IG51bWJlciB7XHJcbiAgICAgICAgcmV0dXJuIGFyY01pblJhZGl1cyArIChfbnVtQXJjcyAtIChfaW5kZXggKyAxKSkgKiAoX2FyY1dpZHRoICsgYXJjUGFkZGluZyk7XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfZ2V0T3V0ZXJSYWRpdXMoX2luZGV4OiBudW1iZXIsIF9udW1BcmNzOiBudW1iZXIsIF9hcmNXaWR0aDogbnVtYmVyKTogbnVtYmVyIHtcclxuICAgICAgICByZXR1cm4gdGhpcy5fZ2V0SW5uZXJSYWRpdXMoX2luZGV4LCBfbnVtQXJjcywgX2FyY1dpZHRoKSArIF9hcmNXaWR0aDtcclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF9yYWQyZGVnKF9hbmdsZTogbnVtYmVyKTogbnVtYmVyIHtcclxuICAgICAgICByZXR1cm4gX2FuZ2xlICogMTgwIC8gUEk7XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfcGF0aEFuaW0oX3BhdGg6IGFueSwgZGlyOiBhbnksIF9pbm5lclJhZGl1czogYW55LCBfb3V0ZXJSYWRpdXM6IGFueSk6IHZvaWQge1xyXG4gICAgICAgIHN3aXRjaCAoZGlyKSB7XHJcbiAgICAgICAgICAgIGNhc2UgZmFsc2U6XHJcbiAgICAgICAgICAgICAgICBfcGF0aC50cmFuc2l0aW9uKClcclxuICAgICAgICAgICAgICAgICAgICAuZHVyYXRpb24oNTAwKVxyXG4gICAgICAgICAgICAgICAgICAgIC8vIC5lYXNlKCdib3VuY2UnKVxyXG4gICAgICAgICAgICAgICAgICAgIC5hdHRyKCdkJywgZDMuYXJjKClcclxuICAgICAgICAgICAgICAgICAgICAgICAgLmlubmVyUmFkaXVzKF9pbm5lclJhZGl1cylcclxuICAgICAgICAgICAgICAgICAgICAgICAgLm91dGVyUmFkaXVzKF9vdXRlclJhZGl1cylcclxuICAgICAgICAgICAgICAgICAgICApLmF0dHIoJ3N0cm9rZScsICdub25lJyk7XHJcbiAgICAgICAgICAgICAgICBicmVhaztcclxuXHJcbiAgICAgICAgICAgIGNhc2UgdHJ1ZTpcclxuICAgICAgICAgICAgICAgIF9wYXRoLnRyYW5zaXRpb24oKVxyXG4gICAgICAgICAgICAgICAgICAgIC5hdHRyKCdkJywgZDMuYXJjKClcclxuICAgICAgICAgICAgICAgICAgICAgICAgLmlubmVyUmFkaXVzKF9pbm5lclJhZGl1cylcclxuICAgICAgICAgICAgICAgICAgICAgICAgLm91dGVyUmFkaXVzKF9vdXRlclJhZGl1cyAqIDEuMSlcclxuICAgICAgICAgICAgICAgICAgICApLmF0dHIoJ3N0cm9rZScsICd3aGl0ZScpLmF0dHIoJ3N0cm9rZS13aWR0aCcsIDIpO1xyXG4gICAgICAgICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG59XHJcbiJdfQ==