import { GRID_DASH_ARRAY } from '../kd-angular-charts-config';
var KdChartsGridSvc = /** @class */ (function () {
    function KdChartsGridSvc(_config) {
        this._dashArray = GRID_DASH_ARRAY;
        this._isInvert = false;
        this._graphDimension = { width: 0, height: 0 };
        this._config = _config;
    }
    Object.defineProperty(KdChartsGridSvc.prototype, "config", {
        set: function (_config) { this._config = _config; },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(KdChartsGridSvc.prototype, "isInvert", {
        set: function (_isInvert) { this._isInvert = _isInvert; },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(KdChartsGridSvc.prototype, "graphDimension", {
        set: function (_graphDimension) { this._graphDimension = _graphDimension; },
        enumerable: true,
        configurable: true
    });
    /**
     * wrapper function around d3.scale so that grid will be drawn in center of paddingInner
     * when scaleBand, this.x gives the start(left corner) of the band (rect). need to recalculate the correct position
     * only scaleBand have _scale.step()
     * param {any} _scale [this.x from base class]
     */
    KdChartsGridSvc.prototype.xAxisGridScale = function (_scale) {
        return function (d) {
            if (!d)
                return 0;
            var result = _scale(d);
            if (_scale.hasOwnProperty('step'))
                result += _scale.step() * (1 - _scale.paddingInner() * 0.5);
            return result;
        };
    };
    KdChartsGridSvc.prototype.haveGrid = function (_config, _dir, _type) {
        return _config[_dir] && _config[_dir][_type + 'Width'] !== 0;
    };
    KdChartsGridSvc.prototype.drawGridLine = function (_container, _data, _dir, _type, _scale) {
        if (!this._config[_dir][_type + 'Width'])
            return;
        var data = _data || [];
        if (this._checkGridLineOverlap(data.slice(1, 3), _dir, _type, _scale))
            return;
        var gridLineGroupContainer = _container.append('g').attr('class', _dir + '-' + _type + '-grid');
        var gridLineGroups = gridLineGroupContainer.selectAll('line').data(data).enter().append('line');
        var coordDir = _dir === 'xAxis' ? 'vertical' : 'horizontal';
        this._setGridLinesConfig(gridLineGroups, this._config[_dir], _type);
        if (this._isInvert)
            coordDir = _dir === 'xAxis' ? 'horizontal' : 'vertical';
        this._setGridLineCoordinate(gridLineGroups, _scale, coordDir);
    };
    KdChartsGridSvc.prototype._checkGridLineOverlap = function (_data, _dir, _type, _scale) {
        if (_data.length === 0)
            return true;
        if (_data.length === 1)
            return false;
        return Math.abs(_scale(_data[0]) - _scale(_data[1])) < this._config[_dir][_type + 'Width'] + 3;
    };
    KdChartsGridSvc.prototype._setGridLinesConfig = function (_gridLineSelection, _axisConfig, _type) {
        _gridLineSelection
            .attr('stroke', _axisConfig[_type + 'Color'])
            .attr('stroke-width', _axisConfig[_type + 'Width'])
            .attr('stroke-dasharray', this._dashArray[_axisConfig[_type + 'DashStyle']]);
    };
    /**
     * sets the x1,x2,y1,y2 of the svg:line
     * param {[type]}        _container [any]
     * param {any}           _scale     [this.y or xAxisGridScale]
     * param {'vertical' | 'horizontal'} _dir
     */
    KdChartsGridSvc.prototype._setGridLineCoordinate = function (_container, _scale, _dir) {
        var attributes = _dir === 'horizontal' ? ['x1', 'x2', 'y1', 'y2'] : ['y1', 'y2', 'x1', 'x2'];
        var end = _dir === 'horizontal' ? this._graphDimension.width : this._graphDimension.height;
        var values = [0, end];
        attributes.forEach(function (attr, index) {
            var value = index === 2 || index === 3 ? function (d) { return _scale(d) + 0.5; } : values[index];
            _container.attr(attr, value);
        });
    };
    return KdChartsGridSvc;
}());
export { KdChartsGridSvc };
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoia2QtYW5ndWxhci1jaGFydHMtZ3JpZC1zdmMuanMiLCJzb3VyY2VSb290Ijoibmc6Ly9vcGVuZW1pcy1zdHlsZWd1aWRlLWxpYi8iLCJzb3VyY2VzIjpbImtkLWNvbXBvbmVudHMva2QtYW5ndWxhci1jaGFydHMvaGVscGVyLXN2Yy9rZC1hbmd1bGFyLWNoYXJ0cy1ncmlkLXN2Yy50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFDQSxPQUFPLEVBQUUsZUFBZSxFQUFFLE1BQU0sNkJBQTZCLENBQUM7QUFFOUQ7SUFPSSx5QkFBWSxPQUFxQjtRQUx6QixlQUFVLEdBQWdDLGVBQWUsQ0FBQztRQUUxRCxjQUFTLEdBQVksS0FBSyxDQUFDO1FBQzNCLG9CQUFlLEdBQXNDLEVBQUUsS0FBSyxFQUFFLENBQUMsRUFBRSxNQUFNLEVBQUUsQ0FBQyxFQUFFLENBQUM7UUFHakYsSUFBSSxDQUFDLE9BQU8sR0FBRyxPQUFPLENBQUM7SUFDM0IsQ0FBQztJQUVELHNCQUFJLG1DQUFNO2FBQVYsVUFBVyxPQUFxQixJQUFJLElBQUksQ0FBQyxPQUFPLEdBQUcsT0FBTyxDQUFDLENBQUMsQ0FBQzs7O09BQUE7SUFDN0Qsc0JBQUkscUNBQVE7YUFBWixVQUFhLFNBQWtCLElBQUksSUFBSSxDQUFDLFNBQVMsR0FBRyxTQUFTLENBQUMsQ0FBQyxDQUFDOzs7T0FBQTtJQUNoRSxzQkFBSSwyQ0FBYzthQUFsQixVQUFtQixlQUFrRCxJQUFJLElBQUksQ0FBQyxlQUFlLEdBQUcsZUFBZSxDQUFDLENBQUMsQ0FBQzs7O09BQUE7SUFFbEg7Ozs7O09BS0c7SUFDSSx3Q0FBYyxHQUFyQixVQUFzQixNQUFXO1FBQzdCLE9BQU8sVUFBQyxDQUFDO1lBQ0wsSUFBSSxDQUFDLENBQUM7Z0JBQUUsT0FBTyxDQUFDLENBQUM7WUFDakIsSUFBSSxNQUFNLEdBQUcsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDO1lBQ3ZCLElBQUksTUFBTSxDQUFDLGNBQWMsQ0FBQyxNQUFNLENBQUM7Z0JBQUUsTUFBTSxJQUFJLE1BQU0sQ0FBQyxJQUFJLEVBQUUsR0FBRyxDQUFDLENBQUMsR0FBRyxNQUFNLENBQUMsWUFBWSxFQUFFLEdBQUcsR0FBRyxDQUFDLENBQUM7WUFDL0YsT0FBTyxNQUFNLENBQUM7UUFDbEIsQ0FBQyxDQUFDO0lBQ04sQ0FBQztJQUVNLGtDQUFRLEdBQWYsVUFBZ0IsT0FBcUIsRUFBRSxJQUF1QixFQUFFLEtBQW1DO1FBQy9GLE9BQU8sT0FBTyxDQUFDLElBQUksQ0FBQyxJQUFJLE9BQU8sQ0FBQyxJQUFJLENBQUMsQ0FBQyxLQUFLLEdBQUcsT0FBTyxDQUFDLEtBQUssQ0FBQyxDQUFDO0lBQ2pFLENBQUM7SUFFTSxzQ0FBWSxHQUFuQixVQUFvQixVQUFVLEVBQUUsS0FBNkIsRUFBRSxJQUF1QixFQUFFLEtBQW1DLEVBQUUsTUFBVztRQUNwSSxJQUFJLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsQ0FBQyxLQUFLLEdBQUcsT0FBTyxDQUFDO1lBQUUsT0FBTztRQUVqRCxJQUFJLElBQUksR0FBRyxLQUFLLElBQUksRUFBRSxDQUFDO1FBQ3ZCLElBQUksSUFBSSxDQUFDLHFCQUFxQixDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxFQUFFLElBQUksRUFBRSxLQUFLLEVBQUUsTUFBTSxDQUFDO1lBQUUsT0FBTztRQUU5RSxJQUFJLHNCQUFzQixHQUFRLFVBQVUsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDLE9BQU8sRUFBRSxJQUFJLEdBQUcsR0FBRyxHQUFHLEtBQUssR0FBRyxPQUFPLENBQUMsQ0FBQztRQUNyRyxJQUFJLGNBQWMsR0FBUSxzQkFBc0IsQ0FBQyxTQUFTLENBQUMsTUFBTSxDQUFDLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDLEtBQUssRUFBRSxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsQ0FBQztRQUNyRyxJQUFJLFFBQVEsR0FBOEIsSUFBSSxLQUFLLE9BQU8sQ0FBQyxDQUFDLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQyxZQUFZLENBQUM7UUFFdkYsSUFBSSxDQUFDLG1CQUFtQixDQUFDLGNBQWMsRUFBRSxJQUFJLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxFQUFFLEtBQUssQ0FBQyxDQUFDO1FBRXBFLElBQUksSUFBSSxDQUFDLFNBQVM7WUFBRSxRQUFRLEdBQUcsSUFBSSxLQUFLLE9BQU8sQ0FBQyxDQUFDLENBQUMsWUFBWSxDQUFDLENBQUMsQ0FBQyxVQUFVLENBQUM7UUFFNUUsSUFBSSxDQUFDLHNCQUFzQixDQUFDLGNBQWMsRUFBRSxNQUFNLEVBQUUsUUFBUSxDQUFDLENBQUM7SUFDbEUsQ0FBQztJQUVPLCtDQUFxQixHQUE3QixVQUE4QixLQUE2QixFQUFFLElBQXVCLEVBQUUsS0FBbUMsRUFBRSxNQUFXO1FBQ2xJLElBQUksS0FBSyxDQUFDLE1BQU0sS0FBSyxDQUFDO1lBQUUsT0FBTyxJQUFJLENBQUM7UUFDcEMsSUFBSSxLQUFLLENBQUMsTUFBTSxLQUFLLENBQUM7WUFBRSxPQUFPLEtBQUssQ0FBQztRQUNyQyxPQUFPLElBQUksQ0FBQyxHQUFHLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLE1BQU0sQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLElBQUksQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLENBQUMsS0FBSyxHQUFHLE9BQU8sQ0FBQyxHQUFHLENBQUMsQ0FBQztJQUNuRyxDQUFDO0lBRU8sNkNBQW1CLEdBQTNCLFVBQTRCLGtCQUF1QixFQUFFLFdBQWdCLEVBQUUsS0FBbUM7UUFDdEcsa0JBQWtCO2FBQ2IsSUFBSSxDQUFDLFFBQVEsRUFBRSxXQUFXLENBQUMsS0FBSyxHQUFHLE9BQU8sQ0FBQyxDQUFDO2FBQzVDLElBQUksQ0FBQyxjQUFjLEVBQUUsV0FBVyxDQUFDLEtBQUssR0FBRyxPQUFPLENBQUMsQ0FBQzthQUNsRCxJQUFJLENBQUMsa0JBQWtCLEVBQUUsSUFBSSxDQUFDLFVBQVUsQ0FBQyxXQUFXLENBQUMsS0FBSyxHQUFHLFdBQVcsQ0FBQyxDQUFDLENBQUMsQ0FBQztJQUNyRixDQUFDO0lBRUQ7Ozs7O09BS0c7SUFDSyxnREFBc0IsR0FBOUIsVUFBK0IsVUFBVSxFQUFFLE1BQVcsRUFBRSxJQUErQjtRQUNuRixJQUFJLFVBQVUsR0FBYSxJQUFJLEtBQUssWUFBWSxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksRUFBRSxJQUFJLEVBQUUsSUFBSSxFQUFFLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksRUFBRSxJQUFJLEVBQUUsSUFBSSxFQUFFLElBQUksQ0FBQyxDQUFDO1FBQ3ZHLElBQUksR0FBRyxHQUFXLElBQUksS0FBSyxZQUFZLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxlQUFlLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsZUFBZSxDQUFDLE1BQU0sQ0FBQztRQUNuRyxJQUFJLE1BQU0sR0FBYSxDQUFDLENBQUMsRUFBRSxHQUFHLENBQUMsQ0FBQztRQUNoQyxVQUFVLENBQUMsT0FBTyxDQUFDLFVBQUMsSUFBSSxFQUFFLEtBQUs7WUFDM0IsSUFBSSxLQUFLLEdBQUcsS0FBSyxLQUFLLENBQUMsSUFBSSxLQUFLLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxVQUFDLENBQUMsSUFBTyxPQUFPLE1BQU0sQ0FBQyxDQUFDLENBQUMsR0FBRyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsQ0FBQztZQUM1RixVQUFVLENBQUMsSUFBSSxDQUFDLElBQUksRUFBRSxLQUFLLENBQUMsQ0FBQztRQUNqQyxDQUFDLENBQUMsQ0FBQztJQUNQLENBQUM7SUFFTCxzQkFBQztBQUFELENBQUMsQUFoRkQsSUFnRkMiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBJQ2hhcnRDb25maWcgfSBmcm9tICcuLi9rZC1hbmd1bGFyLWNoYXJ0cy1pbnRlcmZhY2UnO1xyXG5pbXBvcnQgeyBHUklEX0RBU0hfQVJSQVkgfSBmcm9tICcuLi9rZC1hbmd1bGFyLWNoYXJ0cy1jb25maWcnO1xyXG5cclxuZXhwb3J0IGNsYXNzIEtkQ2hhcnRzR3JpZFN2YyB7XHJcblxyXG4gICAgcHJpdmF0ZSBfZGFzaEFycmF5OiB7IFtrZXk6IHN0cmluZ106IG51bWJlcltdIH0gPSBHUklEX0RBU0hfQVJSQVk7XHJcbiAgICBwcml2YXRlIF9jb25maWc6IElDaGFydENvbmZpZztcclxuICAgIHByaXZhdGUgX2lzSW52ZXJ0OiBib29sZWFuID0gZmFsc2U7XHJcbiAgICBwcml2YXRlIF9ncmFwaERpbWVuc2lvbjogeyB3aWR0aDogbnVtYmVyLCBoZWlnaHQ6IG51bWJlciB9ID0geyB3aWR0aDogMCwgaGVpZ2h0OiAwIH07XHJcblxyXG4gICAgY29uc3RydWN0b3IoX2NvbmZpZzogSUNoYXJ0Q29uZmlnKSB7XHJcbiAgICAgICAgdGhpcy5fY29uZmlnID0gX2NvbmZpZztcclxuICAgIH1cclxuXHJcbiAgICBzZXQgY29uZmlnKF9jb25maWc6IElDaGFydENvbmZpZykgeyB0aGlzLl9jb25maWcgPSBfY29uZmlnOyB9XHJcbiAgICBzZXQgaXNJbnZlcnQoX2lzSW52ZXJ0OiBib29sZWFuKSB7IHRoaXMuX2lzSW52ZXJ0ID0gX2lzSW52ZXJ0OyB9XHJcbiAgICBzZXQgZ3JhcGhEaW1lbnNpb24oX2dyYXBoRGltZW5zaW9uOiB7IHdpZHRoOiBudW1iZXIsIGhlaWdodDogbnVtYmVyIH0pIHsgdGhpcy5fZ3JhcGhEaW1lbnNpb24gPSBfZ3JhcGhEaW1lbnNpb247IH1cclxuXHJcbiAgICAvKipcclxuICAgICAqIHdyYXBwZXIgZnVuY3Rpb24gYXJvdW5kIGQzLnNjYWxlIHNvIHRoYXQgZ3JpZCB3aWxsIGJlIGRyYXduIGluIGNlbnRlciBvZiBwYWRkaW5nSW5uZXJcclxuICAgICAqIHdoZW4gc2NhbGVCYW5kLCB0aGlzLnggZ2l2ZXMgdGhlIHN0YXJ0KGxlZnQgY29ybmVyKSBvZiB0aGUgYmFuZCAocmVjdCkuIG5lZWQgdG8gcmVjYWxjdWxhdGUgdGhlIGNvcnJlY3QgcG9zaXRpb25cclxuICAgICAqIG9ubHkgc2NhbGVCYW5kIGhhdmUgX3NjYWxlLnN0ZXAoKVxyXG4gICAgICogcGFyYW0ge2FueX0gX3NjYWxlIFt0aGlzLnggZnJvbSBiYXNlIGNsYXNzXVxyXG4gICAgICovXHJcbiAgICBwdWJsaWMgeEF4aXNHcmlkU2NhbGUoX3NjYWxlOiBhbnkpOiBGdW5jdGlvbiB7XHJcbiAgICAgICAgcmV0dXJuIChkKSA9PiB7XHJcbiAgICAgICAgICAgIGlmICghZCkgcmV0dXJuIDA7XHJcbiAgICAgICAgICAgIGxldCByZXN1bHQgPSBfc2NhbGUoZCk7XHJcbiAgICAgICAgICAgIGlmIChfc2NhbGUuaGFzT3duUHJvcGVydHkoJ3N0ZXAnKSkgcmVzdWx0ICs9IF9zY2FsZS5zdGVwKCkgKiAoMSAtIF9zY2FsZS5wYWRkaW5nSW5uZXIoKSAqIDAuNSk7XHJcbiAgICAgICAgICAgIHJldHVybiByZXN1bHQ7XHJcbiAgICAgICAgfTtcclxuICAgIH1cclxuXHJcbiAgICBwdWJsaWMgaGF2ZUdyaWQoX2NvbmZpZzogSUNoYXJ0Q29uZmlnLCBfZGlyOiAneUF4aXMnIHwgJ3hBeGlzJywgX3R5cGU6ICdncmlkTGluZScgfCAnbWlub3JHcmlkTGluZScpOiBib29sZWFuIHtcclxuICAgICAgICByZXR1cm4gX2NvbmZpZ1tfZGlyXSAmJiBfY29uZmlnW19kaXJdW190eXBlICsgJ1dpZHRoJ10gIT09IDA7XHJcbiAgICB9XHJcblxyXG4gICAgcHVibGljIGRyYXdHcmlkTGluZShfY29udGFpbmVyLCBfZGF0YTogQXJyYXk8bnVtYmVyIHwgc3RyaW5nPiwgX2RpcjogJ3lBeGlzJyB8ICd4QXhpcycsIF90eXBlOiAnZ3JpZExpbmUnIHwgJ21pbm9yR3JpZExpbmUnLCBfc2NhbGU6IGFueSk6IHZvaWQge1xyXG4gICAgICAgIGlmICghdGhpcy5fY29uZmlnW19kaXJdW190eXBlICsgJ1dpZHRoJ10pIHJldHVybjtcclxuXHJcbiAgICAgICAgbGV0IGRhdGEgPSBfZGF0YSB8fCBbXTtcclxuICAgICAgICBpZiAodGhpcy5fY2hlY2tHcmlkTGluZU92ZXJsYXAoZGF0YS5zbGljZSgxLCAzKSwgX2RpciwgX3R5cGUsIF9zY2FsZSkpIHJldHVybjtcclxuXHJcbiAgICAgICAgbGV0IGdyaWRMaW5lR3JvdXBDb250YWluZXI6IGFueSA9IF9jb250YWluZXIuYXBwZW5kKCdnJykuYXR0cignY2xhc3MnLCBfZGlyICsgJy0nICsgX3R5cGUgKyAnLWdyaWQnKTtcclxuICAgICAgICBsZXQgZ3JpZExpbmVHcm91cHM6IGFueSA9IGdyaWRMaW5lR3JvdXBDb250YWluZXIuc2VsZWN0QWxsKCdsaW5lJykuZGF0YShkYXRhKS5lbnRlcigpLmFwcGVuZCgnbGluZScpO1xyXG4gICAgICAgIGxldCBjb29yZERpcjogJ3ZlcnRpY2FsJyB8ICdob3Jpem9udGFsJyA9IF9kaXIgPT09ICd4QXhpcycgPyAndmVydGljYWwnIDogJ2hvcml6b250YWwnO1xyXG5cclxuICAgICAgICB0aGlzLl9zZXRHcmlkTGluZXNDb25maWcoZ3JpZExpbmVHcm91cHMsIHRoaXMuX2NvbmZpZ1tfZGlyXSwgX3R5cGUpO1xyXG5cclxuICAgICAgICBpZiAodGhpcy5faXNJbnZlcnQpIGNvb3JkRGlyID0gX2RpciA9PT0gJ3hBeGlzJyA/ICdob3Jpem9udGFsJyA6ICd2ZXJ0aWNhbCc7XHJcblxyXG4gICAgICAgIHRoaXMuX3NldEdyaWRMaW5lQ29vcmRpbmF0ZShncmlkTGluZUdyb3VwcywgX3NjYWxlLCBjb29yZERpcik7XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfY2hlY2tHcmlkTGluZU92ZXJsYXAoX2RhdGE6IEFycmF5PG51bWJlciB8IHN0cmluZz4sIF9kaXI6ICd4QXhpcycgfCAneUF4aXMnLCBfdHlwZTogJ2dyaWRMaW5lJyB8ICdtaW5vckdyaWRMaW5lJywgX3NjYWxlOiBhbnkpOiBib29sZWFuIHtcclxuICAgICAgICBpZiAoX2RhdGEubGVuZ3RoID09PSAwKSByZXR1cm4gdHJ1ZTtcclxuICAgICAgICBpZiAoX2RhdGEubGVuZ3RoID09PSAxKSByZXR1cm4gZmFsc2U7XHJcbiAgICAgICAgcmV0dXJuIE1hdGguYWJzKF9zY2FsZShfZGF0YVswXSkgLSBfc2NhbGUoX2RhdGFbMV0pKSA8IHRoaXMuX2NvbmZpZ1tfZGlyXVtfdHlwZSArICdXaWR0aCddICsgMztcclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF9zZXRHcmlkTGluZXNDb25maWcoX2dyaWRMaW5lU2VsZWN0aW9uOiBhbnksIF9heGlzQ29uZmlnOiBhbnksIF90eXBlOiAnZ3JpZExpbmUnIHwgJ21pbm9yR3JpZExpbmUnKTogdm9pZCB7XHJcbiAgICAgICAgX2dyaWRMaW5lU2VsZWN0aW9uXHJcbiAgICAgICAgICAgIC5hdHRyKCdzdHJva2UnLCBfYXhpc0NvbmZpZ1tfdHlwZSArICdDb2xvciddKVxyXG4gICAgICAgICAgICAuYXR0cignc3Ryb2tlLXdpZHRoJywgX2F4aXNDb25maWdbX3R5cGUgKyAnV2lkdGgnXSlcclxuICAgICAgICAgICAgLmF0dHIoJ3N0cm9rZS1kYXNoYXJyYXknLCB0aGlzLl9kYXNoQXJyYXlbX2F4aXNDb25maWdbX3R5cGUgKyAnRGFzaFN0eWxlJ11dKTtcclxuICAgIH1cclxuXHJcbiAgICAvKipcclxuICAgICAqIHNldHMgdGhlIHgxLHgyLHkxLHkyIG9mIHRoZSBzdmc6bGluZVxyXG4gICAgICogcGFyYW0ge1t0eXBlXX0gICAgICAgIF9jb250YWluZXIgW2FueV1cclxuICAgICAqIHBhcmFtIHthbnl9ICAgICAgICAgICBfc2NhbGUgICAgIFt0aGlzLnkgb3IgeEF4aXNHcmlkU2NhbGVdXHJcbiAgICAgKiBwYXJhbSB7J3ZlcnRpY2FsJyB8ICdob3Jpem9udGFsJ30gX2RpclxyXG4gICAgICovXHJcbiAgICBwcml2YXRlIF9zZXRHcmlkTGluZUNvb3JkaW5hdGUoX2NvbnRhaW5lciwgX3NjYWxlOiBhbnksIF9kaXI6ICd2ZXJ0aWNhbCcgfCAnaG9yaXpvbnRhbCcpOiB2b2lkIHtcclxuICAgICAgICBsZXQgYXR0cmlidXRlczogc3RyaW5nW10gPSBfZGlyID09PSAnaG9yaXpvbnRhbCcgPyBbJ3gxJywgJ3gyJywgJ3kxJywgJ3kyJ10gOiBbJ3kxJywgJ3kyJywgJ3gxJywgJ3gyJ107XHJcbiAgICAgICAgbGV0IGVuZDogbnVtYmVyID0gX2RpciA9PT0gJ2hvcml6b250YWwnID8gdGhpcy5fZ3JhcGhEaW1lbnNpb24ud2lkdGggOiB0aGlzLl9ncmFwaERpbWVuc2lvbi5oZWlnaHQ7XHJcbiAgICAgICAgbGV0IHZhbHVlczogbnVtYmVyW10gPSBbMCwgZW5kXTtcclxuICAgICAgICBhdHRyaWJ1dGVzLmZvckVhY2goKGF0dHIsIGluZGV4KSA9PiB7XHJcbiAgICAgICAgICAgIGxldCB2YWx1ZSA9IGluZGV4ID09PSAyIHx8IGluZGV4ID09PSAzID8gKGQpID0+IHsgcmV0dXJuIF9zY2FsZShkKSArIDAuNTsgfSA6IHZhbHVlc1tpbmRleF07XHJcbiAgICAgICAgICAgIF9jb250YWluZXIuYXR0cihhdHRyLCB2YWx1ZSk7XHJcbiAgICAgICAgfSk7XHJcbiAgICB9XHJcblxyXG59XHJcbiJdfQ==