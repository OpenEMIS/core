import { __decorate, __extends, __metadata } from "tslib";
import { Component, ViewEncapsulation, Input } from '@angular/core';
import { KdChartBaseClass } from '../kd-angular-chart-base-class';
import { KdChartsSvc } from '../kd-angular-charts-svc';
import { KdDomElemSvc } from '../../kd-common/index';
import { KdBarChartSvc } from './kd-angular-bar-chart-svc';
var KdBarChart = /** @class */ (function (_super) {
    __extends(KdBarChart, _super);
    function KdBarChart(_chartSvc, _domSvc, _barSvc) {
        var _this = _super.call(this, _chartSvc, _domSvc) || this;
        _this._chartSvc = _chartSvc;
        _this._domSvc = _domSvc;
        _this._barSvc = _barSvc;
        _this._isStartAtSum = false;
        return _this;
    }
    KdBarChart.prototype.ngOnInit = function () {
        var _this = this;
        this._redrawChart(true, { data: this.allData, config: this.barConfig });
        this.api.legendClick = function (_data) {
            _this._redrawChart(false, { data: _data });
        };
        this.api.redraw = function () {
            clearTimeout(_this._resizeTimeout);
            _this._resizeTimeout = setTimeout(function () {
                _this._redrawChart(false, {});
            });
        };
    };
    KdBarChart.prototype.ngOnChanges = function (_simpleChanges) {
        if (_simpleChanges.hasOwnProperty('allData') && !_simpleChanges['allData'].firstChange) {
            this._redrawChart(false, { data: _simpleChanges.allData.currentValue });
        }
        if (_simpleChanges.hasOwnProperty('barConfig') && !_simpleChanges['barConfig'].firstChange) {
            this._redrawChart(false, { config: _simpleChanges.barConfig.currentValue });
        }
    };
    KdBarChart.prototype.ngOnDestroy = function () {
        this._resetChart();
    };
    KdBarChart.prototype._redrawChart = function (isFirstChange, _changes) {
        var _this = this;
        if (_changes === void 0) { _changes = {}; }
        if (!isFirstChange) {
            this._resetChart();
        }
        this.legendData = Object.assign({}, this.legend);
        if (_changes.hasOwnProperty('data'))
            this._setData(_changes.data);
        if (_changes.hasOwnProperty('config'))
            this._setConfig(_changes.config);
        _super.prototype.chartTimeout.call(this, function () { return _this._setChart(); });
    };
    KdBarChart.prototype._setData = function (_data) {
        this.data = Object.assign([], _data.data);
        // saving original data somewhere before trimming this.data. when no trimming, then this.data will just be initData
        this.initData = JSON.parse(JSON.stringify(this.data));
        this.chartCategory = 'bar';
        this.chartType = _data.layout.split('-');
        this._chartSvc.isInvert = this.chartType[0] === 'bar';
        this.bar.isInvert = this.chartType[0] === 'bar';
        this._chartSvc.isNegativeStack = this.chartType[1] === 'stack' && this.chartType[2] === 'negative';
        // range and negative flag calculated by kdChart, used in domain, recalculated when change graph type and legend
        this.dataRange = _data.range;
        this.haveNegative = _data.haveNegative;
        this._barSvc.originalDataRange = _data.range;
    };
    KdBarChart.prototype._setConfig = function (_config) {
        this.config = Object.assign({}, _config);
    };
    KdBarChart.prototype._setChart = function () {
        if (this.chartType[1] === '100' && this.haveNegative)
            return;
        if (this._chartSvc.isNegativeStack)
            this.negativeStackSymmetryLogic();
        _super.prototype.setSvg.call(this);
        _super.prototype.setDomain.call(this, 'band');
        this._drawChart();
    };
    KdBarChart.prototype._resetChart = function () {
        _super.prototype.removeChart.call(this);
        if (this._barGraph) {
            this._barGraph.remove();
            this._barGraph = null;
        }
    };
    KdBarChart.prototype._drawChartContainer = function () {
        this._barGraph = this.graph.append('g').attr('class', 'bar-graph-container');
        this._barGraph.attr('clip-path', 'url(#kd-charts-clip-path-' + this.config.id + ')');
    };
    KdBarChart.prototype._drawChart = function () {
        var _this = this;
        if (!this._barGraph)
            this._drawChartContainer();
        this._isStartAtSum = this.bar.isInvert === this._chartSvc.isYReversed;
        var rectPosInfo = this._getRectPosInfo();
        this.data.forEach(function (d, i) {
            var groups = _this._setRectGroup(d, i, d.y, _this._barGraph, rectPosInfo);
            _super.prototype._initMouseEvents.call(_this, groups.rectGroup, { data: d, index: i });
            if (_this.config.chart.labels.enabled) {
                _this._setBarChartLabel(d, i, groups);
                if (_this.config.animation) {
                    groups.rectGroupTransite.on('end', function (yData, yIndex) {
                        // when the last rect transite ends
                        if ((yData.xIndex === _this.data.length - 1)
                            && (yIndex === _this.data[_this.data.length - 1].y.length - 1)) {
                            _this._displayAllLabel();
                        }
                    });
                }
                else {
                    _this._displayAllLabel();
                }
            }
        });
    };
    KdBarChart.prototype._setRectGroup = function (_d, _xIndex, _yDataArr, _container, _rectPosInfo) {
        var _this = this;
        var rectGroup = _container.selectAll('rectGroup')
            .data(_yDataArr, function (d) { d['xIndex'] = _xIndex; return d; })
            .enter()
            .append('rect');
        var offset = 0, rectGroupTransite, xPosArr = [], yPosArr = [], widthArr = [], heightArr = [];
        rectGroup
            .attr('class', function (yData) { return 'bar x-' + _xIndex + ' y-' + yData.id; })
            .attr('fill', function (yData, yIndex) { return _this.legend.hasOwnProperty(yData.id) ? _this.legend[yData.id].color || '' : ''; })
            .attr('aria-x-value', _d.x.value)
            .attr('aria-y-value', function (yData) { return yData.sum; });
        if (this.chartType[0] === 'column') {
            rectGroup
                .attr('width', pushAndReturn(widthArr, _rectPosInfo.width))
                .attr('x', function (yData, yIndex) {
                if (_this.chartType[1] === 'cluster')
                    offset = _rectPosInfo.width * yIndex + _rectPosInfo.padding * yIndex;
                return pushAndReturn(xPosArr, _this.x(_d.x.value) + offset);
            });
            if (!this.config.animation) {
                rectGroup
                    .attr('y', function (yData) { return pushAndReturn(yPosArr, _this._getVal('y', yData)); })
                    .attr('height', function (yData) { return pushAndReturn(heightArr, _this._getVal('height', yData)); });
            }
            else {
                rectGroup
                    .attr('y', this.y(0))
                    .attr('height', 0);
                rectGroupTransite = rectGroup.transition().duration(this.lengthOfTransition)
                    .attr('y', function (yData) { return pushAndReturn(yPosArr, _this._getVal('y', yData)); })
                    .attr('height', function (yData) { return pushAndReturn(heightArr, _this._getVal('height', yData)); });
            }
        }
        else {
            rectGroup
                .attr('height', pushAndReturn(heightArr, _rectPosInfo.width))
                .attr('y', function (yData, yIndex) {
                if (_this.chartType[1] === 'cluster')
                    offset = _rectPosInfo.width * yIndex + _rectPosInfo.padding * yIndex;
                return pushAndReturn(yPosArr, _this.x(_d.x.value) + offset);
            });
            if (!this.config.animation) {
                rectGroup
                    .attr('x', function (yData) { return pushAndReturn(xPosArr, _this._getVal('x', yData)); })
                    .attr('width', function (yData) { return pushAndReturn(widthArr, _this._getVal('width', yData)); });
            }
            else {
                rectGroup
                    .attr('x', this.y(0))
                    .attr('width', 0);
                rectGroupTransite = rectGroup.transition().duration(this.lengthOfTransition)
                    .attr('x', function (yData) { return pushAndReturn(xPosArr, _this._getVal('x', yData)); })
                    .attr('width', function (yData) { return pushAndReturn(widthArr, _this._getVal('width', yData)); });
            }
        }
        return {
            rectGroup: rectGroup,
            rectGroupTransite: rectGroupTransite,
            xPosArr: xPosArr,
            yPosArr: yPosArr,
            widthArr: widthArr,
            heightArr: heightArr
        };
        function pushAndReturn(target, value) {
            target.push(value);
            return value;
        }
    };
    KdBarChart.prototype._getVal = function (_type, _yData) {
        var value = this.chartType[1] === '100' ? _yData.renderVal : _yData.value;
        var offset = value ? 1 : 0;
        if (_type === 'x' || _type === 'y') {
            return this._isStartAtSum ? this.y(negativeRecal(_yData.sum, value)) : this.y(negativeRecal(_yData.sum, value) - Math.abs(value));
        }
        if (_type === 'height')
            return Math.abs(this.y(negativeRecal(_yData.sum, value) - value) - this.y(negativeRecal(_yData.sum, value))) + offset;
        if (_type === 'width')
            return Math.abs(this.y(negativeRecal(_yData.sum, value)) - this.y(negativeRecal(_yData.sum, value) - value)) + offset;
        // rendering rect for negative uses values lesser by one index. eg: first value = -2, sum = -2, renders 0.... second value = -4, sum = -6, renders -2
        function negativeRecal(_sum, _value) {
            return Math.sign(_sum) < 0 ? _sum - _value : _sum;
        }
    };
    KdBarChart.prototype._setBarChartLabel = function (_d, _xIndex, _group) {
        for (var yIndex = 0; yIndex < _d.y.length; ++yIndex) {
            if (_d.y[yIndex].value === null)
                continue;
            var yData = Object.assign({}, _d.y[yIndex]), dimensions = {
                yPos: _group.yPosArr[yIndex],
                xPos: _group.xPosArr[yIndex],
                height: this.chartType[0] === 'column' ? _group.heightArr[yIndex] : _group.heightArr[0],
                width: this.chartType[0] === 'column' ? _group.widthArr[0] : _group.widthArr[yIndex]
            };
            if (!this.config.chart.labels.inside) {
                if (this.chartType[0] === 'column') {
                    if ((yData.value < 0 && !this._chartSvc.isYReversed) || (yData.value > 0 && this._chartSvc.isYReversed)) {
                        dimensions.yPos += _group.heightArr[yIndex];
                    }
                    // when rtl, div starts at top right of rect
                    if (this.isRtl)
                        dimensions.xPos += _group.widthArr[0];
                }
                else {
                    if ((yData.value > 0 && !this._chartSvc.isYReversed) || (yData.value < 0 && this._chartSvc.isYReversed)) {
                        dimensions.xPos += _group.widthArr[yIndex];
                    }
                }
            }
            else {
                if (this.isRtl) {
                    // when rtl,
                    // for Column, div starts at top right of rect
                    // for Bar, div start at end of rect and take the width of bars
                    var index = this.chartType[0] === 'column' ? 0 : yIndex;
                    dimensions.xPos += _group.widthArr[index];
                }
            }
            if (this._chartSvc.isNegativeStack)
                yData.value = this._chartSvc.checkAndReturnLabelsPositive(yData.value);
            var labelContainer = _super.prototype.setLabel.call(this, yData, _xIndex, dimensions.xPos, dimensions.yPos);
            // value here is rawValue (negativeStackBar may have changed yData.value)
            this._setLabelStyle(labelContainer, _d.y[yIndex].value, dimensions);
        }
    };
    // for column, width is constant, height is vary
    // for bar, height is constant, width is vary
    KdBarChart.prototype._setLabelStyle = function (_labelContainer, _value, _dimensions) {
        var labelText = _labelContainer.select('.kdx-charts-data-label-text');
        var verticalAlign = this.config.chart.labels.verticalAlign;
        var inside = this.config.chart.labels.inside;
        var sign = Math.sign(_value);
        if (!verticalAlign)
            verticalAlign = this.chartType[0] === 'column' ? 'top' : 'middle';
        this._barSvc.setLabelContainerWidthOrHeight(_labelContainer, this.chartType[0], inside, _dimensions);
        // if label is higher than bar's/column's height
        var isLabelHigherThanRect = this._chartSvc._getLabelTextHeight() > _dimensions.height;
        if (isLabelHigherThanRect) {
            if (this.chartType[0] === 'bar') {
                verticalAlign = 'middle';
            }
            else if (inside) {
                // if column and inside, to make sure label will not hit into axis,
                // if axis is at bottom of chart, set to flex-end so that text will be placed above
                // if axis is at top of chart, set to flex-start so that text will be placed below
                verticalAlign = this._chartSvc.isYReversed ? 'top' : 'bottom';
            }
        }
        if (!inside) {
            if (this.chartType[0] === 'bar') {
                this._barSvc._setLabelTextPosHorizontal(labelText, this._chartSvc.isYReversed, { xPos: _dimensions.xPos, chartWidth: this.width, valueSign: sign });
            }
            else {
                var params = { valueSign: sign };
                var yPos = _dimensions.yPos; // used for boundary checking.
                if (isLabelHigherThanRect && this.chartType[1] === 'cluster') {
                    params['dimensions'] = _dimensions;
                    var needOffset = this._chartSvc.needOffsetForColumn(verticalAlign, params);
                    if (needOffset)
                        yPos += needOffset * _dimensions.height;
                }
                _super.prototype.setLabelTextPosition.call(this, labelText, yPos, params);
            }
        }
        this._barSvc.setVerticalAlignCSS(_labelContainer, verticalAlign);
    };
    KdBarChart.prototype._displayAllLabel = function () {
        this.dataLabelContainer
            .selectAll('.kdx-charts-data-label')
            .style('visibility', 'visible');
    };
    KdBarChart.prototype._getRectPosInfo = function () {
        if (this.chartType[1] === 'cluster') {
            // the amount of yData for each x value will always be the same (if we don't remove null values)
            // hence this calculation only needs to run once
            var yArrLength = this.data[0] && this.data[0].y ? this.data[0].y.length : 0;
            return this._barSvc.getRectWidth(this.x.bandwidth(), this.bar.clusterPaddingPercent, yArrLength);
        }
        return {
            width: this.x.bandwidth(),
            padding: 0
        };
    };
    KdBarChart.prototype.negativeStackSymmetryLogic = function () {
        var result = this._barSvc.applySymmetricAxis(this.dataRange, this.config.plotOptions, this.config.yAxis);
        if (result.hasOwnProperty('dataRange'))
            this.dataRange = result.dataRange;
        if (result.hasOwnProperty('yAxis')) {
            this.config.yAxis = Object.assign({}, this.config.yAxis, result.yAxis);
        }
    };
    KdBarChart.ctorParameters = function () { return [
        { type: KdChartsSvc },
        { type: KdDomElemSvc },
        { type: KdBarChartSvc }
    ]; };
    __decorate([
        Input('data'),
        __metadata("design:type", Object)
    ], KdBarChart.prototype, "allData", void 0);
    __decorate([
        Input('config'),
        __metadata("design:type", Object)
    ], KdBarChart.prototype, "barConfig", void 0);
    __decorate([
        Input(),
        __metadata("design:type", Object)
    ], KdBarChart.prototype, "legend", void 0);
    __decorate([
        Input(),
        __metadata("design:type", Object)
    ], KdBarChart.prototype, "api", void 0);
    KdBarChart = __decorate([
        Component({
            selector: 'kd-bar-chart',
            template: "\n        <div *ngIf=\"chartType[1] === '100' && haveNegative\" class=\"kdx-charts-error-msg\">\n            {{errorMsg}}\n        </div>\n    ",
            encapsulation: ViewEncapsulation.None,
            providers: [KdChartsSvc, KdDomElemSvc, KdBarChartSvc],
            host: {
                'class': 'kdx-bar-chart',
            }
        }),
        __metadata("design:paramtypes", [KdChartsSvc,
            KdDomElemSvc,
            KdBarChartSvc])
    ], KdBarChart);
    return KdBarChart;
}(KdChartBaseClass));
export { KdBarChart };
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoia2QtYW5ndWxhci1iYXItY2hhcnQuanMiLCJzb3VyY2VSb290Ijoibmc6Ly9vcGVuZW1pcy1zdHlsZWd1aWRlLWxpYi8iLCJzb3VyY2VzIjpbImtkLWNvbXBvbmVudHMva2QtYW5ndWxhci1jaGFydHMva2QtYW5ndWxhci1iYXItY2hhcnQva2QtYW5ndWxhci1iYXItY2hhcnQudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IjtBQUFBLE9BQU8sRUFDSCxTQUFTLEVBQ1QsaUJBQWlCLEVBQ2pCLEtBQUssRUFLUixNQUFNLGVBQWUsQ0FBQztBQUN2QixPQUFPLEVBQUUsZ0JBQWdCLEVBQUUsTUFBTSxnQ0FBZ0MsQ0FBQztBQUNsRSxPQUFPLEVBQUUsV0FBVyxFQUFFLE1BQU0sMEJBQTBCLENBQUM7QUFHdkQsT0FBTyxFQUFFLFlBQVksRUFBRSxNQUFNLHVCQUF1QixDQUFDO0FBQ3JELE9BQU8sRUFBRSxhQUFhLEVBQUUsTUFBTSw0QkFBNEIsQ0FBQztBQWdCM0Q7SUFBZ0MsOEJBQWdCO0lBVzVDLG9CQUNXLFNBQXNCLEVBQ3RCLE9BQXFCLEVBQ3JCLE9BQXNCO1FBSGpDLFlBS0ksa0JBQU0sU0FBUyxFQUFFLE9BQU8sQ0FBQyxTQUM1QjtRQUxVLGVBQVMsR0FBVCxTQUFTLENBQWE7UUFDdEIsYUFBTyxHQUFQLE9BQU8sQ0FBYztRQUNyQixhQUFPLEdBQVAsT0FBTyxDQUFlO1FBVnpCLG1CQUFhLEdBQVksS0FBSyxDQUFDOztJQWF2QyxDQUFDO0lBRUQsNkJBQVEsR0FBUjtRQUFBLGlCQVdDO1FBVkcsSUFBSSxDQUFDLFlBQVksQ0FBQyxJQUFJLEVBQUUsRUFBRSxJQUFJLEVBQUUsSUFBSSxDQUFDLE9BQU8sRUFBRSxNQUFNLEVBQUUsSUFBSSxDQUFDLFNBQVMsRUFBRSxDQUFDLENBQUM7UUFDeEUsSUFBSSxDQUFDLEdBQUcsQ0FBQyxXQUFXLEdBQUcsVUFBQyxLQUFVO1lBQzlCLEtBQUksQ0FBQyxZQUFZLENBQUMsS0FBSyxFQUFFLEVBQUUsSUFBSSxFQUFFLEtBQUssRUFBRSxDQUFDLENBQUM7UUFDOUMsQ0FBQyxDQUFDO1FBQ0YsSUFBSSxDQUFDLEdBQUcsQ0FBQyxNQUFNLEdBQUc7WUFDZCxZQUFZLENBQUMsS0FBSSxDQUFDLGNBQWMsQ0FBQyxDQUFDO1lBQ2xDLEtBQUksQ0FBQyxjQUFjLEdBQUcsVUFBVSxDQUFDO2dCQUM3QixLQUFJLENBQUMsWUFBWSxDQUFDLEtBQUssRUFBRSxFQUFFLENBQUMsQ0FBQztZQUNqQyxDQUFDLENBQUMsQ0FBQztRQUNQLENBQUMsQ0FBQztJQUNOLENBQUM7SUFFRCxnQ0FBVyxHQUFYLFVBQVksY0FBNkI7UUFDckMsSUFBSSxjQUFjLENBQUMsY0FBYyxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsY0FBYyxDQUFDLFNBQVMsQ0FBQyxDQUFDLFdBQVcsRUFBRTtZQUNwRixJQUFJLENBQUMsWUFBWSxDQUFDLEtBQUssRUFBRSxFQUFFLElBQUksRUFBRSxjQUFjLENBQUMsT0FBTyxDQUFDLFlBQVksRUFBRSxDQUFDLENBQUM7U0FDM0U7UUFDRCxJQUFJLGNBQWMsQ0FBQyxjQUFjLENBQUMsV0FBVyxDQUFDLElBQUksQ0FBQyxjQUFjLENBQUMsV0FBVyxDQUFDLENBQUMsV0FBVyxFQUFFO1lBQ3hGLElBQUksQ0FBQyxZQUFZLENBQUMsS0FBSyxFQUFFLEVBQUUsTUFBTSxFQUFFLGNBQWMsQ0FBQyxTQUFTLENBQUMsWUFBWSxFQUFFLENBQUMsQ0FBQztTQUMvRTtJQUNMLENBQUM7SUFFRCxnQ0FBVyxHQUFYO1FBQ0ksSUFBSSxDQUFDLFdBQVcsRUFBRSxDQUFDO0lBQ3ZCLENBQUM7SUFFTyxpQ0FBWSxHQUFwQixVQUFxQixhQUFzQixFQUFFLFFBQXdEO1FBQXJHLGlCQVFDO1FBUjRDLHlCQUFBLEVBQUEsYUFBd0Q7UUFDakcsSUFBSSxDQUFDLGFBQWEsRUFBRTtZQUNoQixJQUFJLENBQUMsV0FBVyxFQUFFLENBQUM7U0FDdEI7UUFDRCxJQUFJLENBQUMsVUFBVSxHQUFHLE1BQU0sQ0FBQyxNQUFNLENBQUMsRUFBRSxFQUFFLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQztRQUNqRCxJQUFJLFFBQVEsQ0FBQyxjQUFjLENBQUMsTUFBTSxDQUFDO1lBQUUsSUFBSSxDQUFDLFFBQVEsQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLENBQUM7UUFDbEUsSUFBSSxRQUFRLENBQUMsY0FBYyxDQUFDLFFBQVEsQ0FBQztZQUFFLElBQUksQ0FBQyxVQUFVLENBQUMsUUFBUSxDQUFDLE1BQU0sQ0FBQyxDQUFDO1FBQ3hFLGlCQUFNLFlBQVksWUFBQyxjQUFNLE9BQUEsS0FBSSxDQUFDLFNBQVMsRUFBRSxFQUFoQixDQUFnQixDQUFDLENBQUM7SUFDL0MsQ0FBQztJQUVPLDZCQUFRLEdBQWhCLFVBQWlCLEtBQWM7UUFDM0IsSUFBSSxDQUFDLElBQUksR0FBRyxNQUFNLENBQUMsTUFBTSxDQUFDLEVBQUUsRUFBRSxLQUFLLENBQUMsSUFBSSxDQUFDLENBQUM7UUFDMUMsbUhBQW1IO1FBQ25ILElBQUksQ0FBQyxRQUFRLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDO1FBRXRELElBQUksQ0FBQyxhQUFhLEdBQUcsS0FBSyxDQUFDO1FBQzNCLElBQUksQ0FBQyxTQUFTLEdBQUcsS0FBSyxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLENBQUM7UUFDekMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxRQUFRLEdBQUcsSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsS0FBSyxLQUFLLENBQUM7UUFDdEQsSUFBSSxDQUFDLEdBQUcsQ0FBQyxRQUFRLEdBQUcsSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsS0FBSyxLQUFLLENBQUM7UUFDaEQsSUFBSSxDQUFDLFNBQVMsQ0FBQyxlQUFlLEdBQUcsSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsS0FBSyxPQUFPLElBQUksSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsS0FBSyxVQUFVLENBQUM7UUFFbkcsZ0hBQWdIO1FBQ2hILElBQUksQ0FBQyxTQUFTLEdBQUcsS0FBSyxDQUFDLEtBQUssQ0FBQztRQUM3QixJQUFJLENBQUMsWUFBWSxHQUFHLEtBQUssQ0FBQyxZQUFZLENBQUM7UUFDdkMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxpQkFBaUIsR0FBRyxLQUFLLENBQUMsS0FBSyxDQUFDO0lBQ2pELENBQUM7SUFFTywrQkFBVSxHQUFsQixVQUFtQixPQUFxQjtRQUNwQyxJQUFJLENBQUMsTUFBTSxHQUFHLE1BQU0sQ0FBQyxNQUFNLENBQUMsRUFBRSxFQUFFLE9BQU8sQ0FBQyxDQUFDO0lBQzdDLENBQUM7SUFFTyw4QkFBUyxHQUFqQjtRQUNJLElBQUksSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsS0FBSyxLQUFLLElBQUksSUFBSSxDQUFDLFlBQVk7WUFBRSxPQUFPO1FBQzdELElBQUksSUFBSSxDQUFDLFNBQVMsQ0FBQyxlQUFlO1lBQUUsSUFBSSxDQUFDLDBCQUEwQixFQUFFLENBQUM7UUFDdEUsaUJBQU0sTUFBTSxXQUFFLENBQUM7UUFDZixpQkFBTSxTQUFTLFlBQUMsTUFBTSxDQUFDLENBQUM7UUFDeEIsSUFBSSxDQUFDLFVBQVUsRUFBRSxDQUFDO0lBQ3RCLENBQUM7SUFFTyxnQ0FBVyxHQUFuQjtRQUNJLGlCQUFNLFdBQVcsV0FBRSxDQUFDO1FBQ3BCLElBQUksSUFBSSxDQUFDLFNBQVMsRUFBRTtZQUNoQixJQUFJLENBQUMsU0FBUyxDQUFDLE1BQU0sRUFBRSxDQUFDO1lBQ3hCLElBQUksQ0FBQyxTQUFTLEdBQUcsSUFBSSxDQUFDO1NBQ3pCO0lBQ0wsQ0FBQztJQUVPLHdDQUFtQixHQUEzQjtRQUNJLElBQUksQ0FBQyxTQUFTLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDLE9BQU8sRUFBRSxxQkFBcUIsQ0FBQyxDQUFDO1FBQzdFLElBQUksQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDLFdBQVcsRUFBRSwyQkFBMkIsR0FBRyxJQUFJLENBQUMsTUFBTSxDQUFDLEVBQUUsR0FBRyxHQUFHLENBQUMsQ0FBQztJQUN6RixDQUFDO0lBRU8sK0JBQVUsR0FBbEI7UUFBQSxpQkE2QkM7UUE1QkcsSUFBSSxDQUFDLElBQUksQ0FBQyxTQUFTO1lBQUUsSUFBSSxDQUFDLG1CQUFtQixFQUFFLENBQUM7UUFFaEQsSUFBSSxDQUFDLGFBQWEsR0FBRyxJQUFJLENBQUMsR0FBRyxDQUFDLFFBQVEsS0FBSyxJQUFJLENBQUMsU0FBUyxDQUFDLFdBQVcsQ0FBQztRQUV0RSxJQUFJLFdBQVcsR0FBdUMsSUFBSSxDQUFDLGVBQWUsRUFBRSxDQUFDO1FBRTdFLElBQUksQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLFVBQUMsQ0FBYyxFQUFFLENBQVM7WUFDeEMsSUFBSSxNQUFNLEdBQWUsS0FBSSxDQUFDLGFBQWEsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLEVBQUUsS0FBSSxDQUFDLFNBQVMsRUFBRSxXQUFXLENBQUMsQ0FBQztZQUVwRixpQkFBTSxnQkFBZ0IsYUFBQyxNQUFNLENBQUMsU0FBUyxFQUFFLEVBQUUsSUFBSSxFQUFFLENBQUMsRUFBRSxLQUFLLEVBQUUsQ0FBQyxFQUFFLENBQUMsQ0FBQztZQUVoRSxJQUFJLEtBQUksQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxPQUFPLEVBQUU7Z0JBQ2xDLEtBQUksQ0FBQyxpQkFBaUIsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLE1BQU0sQ0FBQyxDQUFDO2dCQUVyQyxJQUFJLEtBQUksQ0FBQyxNQUFNLENBQUMsU0FBUyxFQUFFO29CQUN2QixNQUFNLENBQUMsaUJBQWlCLENBQUMsRUFBRSxDQUFDLEtBQUssRUFBRSxVQUFDLEtBQUssRUFBRSxNQUFNO3dCQUM3QyxtQ0FBbUM7d0JBQ25DLElBQUksQ0FBQyxLQUFLLENBQUMsTUFBTSxLQUFLLEtBQUksQ0FBQyxJQUFJLENBQUMsTUFBTSxHQUFHLENBQUMsQ0FBQzsrQkFDcEMsQ0FBQyxNQUFNLEtBQUssS0FBSSxDQUFDLElBQUksQ0FBQyxLQUFJLENBQUMsSUFBSSxDQUFDLE1BQU0sR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxHQUFHLENBQUMsQ0FBQyxFQUFFOzRCQUM5RCxLQUFJLENBQUMsZ0JBQWdCLEVBQUUsQ0FBQzt5QkFDM0I7b0JBQ0wsQ0FBQyxDQUFDLENBQUM7aUJBQ047cUJBQU07b0JBQ0gsS0FBSSxDQUFDLGdCQUFnQixFQUFFLENBQUM7aUJBQzNCO2FBRUo7UUFDTCxDQUFDLENBQUMsQ0FBQztJQUNQLENBQUM7SUFFTyxrQ0FBYSxHQUFyQixVQUFzQixFQUFlLEVBQUUsT0FBZSxFQUFFLFNBQTBCLEVBQUUsVUFBZSxFQUFFLFlBQTBCO1FBQS9ILGlCQXdFQztRQXZFRyxJQUFJLFNBQVMsR0FBRyxVQUFVLENBQUMsU0FBUyxDQUFDLFdBQVcsQ0FBQzthQUM1QyxJQUFJLENBQUMsU0FBUyxFQUFFLFVBQUMsQ0FBQyxJQUFPLENBQUMsQ0FBQyxRQUFRLENBQUMsR0FBRyxPQUFPLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQzthQUM1RCxLQUFLLEVBQUU7YUFDUCxNQUFNLENBQUMsTUFBTSxDQUFDLENBQUM7UUFDcEIsSUFBSSxNQUFNLEdBQUcsQ0FBQyxFQUFFLGlCQUFzQixFQUFFLE9BQU8sR0FBa0IsRUFBRSxFQUFFLE9BQU8sR0FBa0IsRUFBRSxFQUFFLFFBQVEsR0FBa0IsRUFBRSxFQUFFLFNBQVMsR0FBa0IsRUFBRSxDQUFDO1FBRTlKLFNBQVM7YUFDSixJQUFJLENBQUMsT0FBTyxFQUFFLFVBQUMsS0FBSyxJQUFLLE9BQUEsUUFBUSxHQUFHLE9BQU8sR0FBRyxLQUFLLEdBQUcsS0FBSyxDQUFDLEVBQUUsRUFBckMsQ0FBcUMsQ0FBQzthQUMvRCxJQUFJLENBQUMsTUFBTSxFQUFFLFVBQUMsS0FBSyxFQUFFLE1BQU0sSUFBSyxPQUFBLEtBQUksQ0FBQyxNQUFNLENBQUMsY0FBYyxDQUFDLEtBQUssQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSSxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsRUFBRSxDQUFDLENBQUMsS0FBSyxJQUFJLEVBQUUsQ0FBQyxDQUFDLENBQUMsRUFBRSxFQUE3RSxDQUE2RSxDQUFDO2FBQzlHLElBQUksQ0FBQyxjQUFjLEVBQUUsRUFBRSxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUM7YUFDaEMsSUFBSSxDQUFDLGNBQWMsRUFBRSxVQUFDLEtBQUssSUFBSyxPQUFBLEtBQUssQ0FBQyxHQUFHLEVBQVQsQ0FBUyxDQUFDLENBQUM7UUFFaEQsSUFBSSxJQUFJLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxLQUFLLFFBQVEsRUFBRTtZQUNoQyxTQUFTO2lCQUNKLElBQUksQ0FBQyxPQUFPLEVBQUUsYUFBYSxDQUFDLFFBQVEsRUFBRSxZQUFZLENBQUMsS0FBSyxDQUFDLENBQUM7aUJBQzFELElBQUksQ0FBQyxHQUFHLEVBQUUsVUFBQyxLQUFLLEVBQUUsTUFBTTtnQkFDckIsSUFBSSxLQUFJLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxLQUFLLFNBQVM7b0JBQUUsTUFBTSxHQUFHLFlBQVksQ0FBQyxLQUFLLEdBQUcsTUFBTSxHQUFHLFlBQVksQ0FBQyxPQUFPLEdBQUcsTUFBTSxDQUFDO2dCQUMxRyxPQUFPLGFBQWEsQ0FBQyxPQUFPLEVBQUUsS0FBSSxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxHQUFHLE1BQU0sQ0FBQyxDQUFDO1lBQy9ELENBQUMsQ0FBQyxDQUFDO1lBRVAsSUFBSSxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsU0FBUyxFQUFFO2dCQUN4QixTQUFTO3FCQUNKLElBQUksQ0FBQyxHQUFHLEVBQUUsVUFBQyxLQUFLLElBQUssT0FBQSxhQUFhLENBQUMsT0FBTyxFQUFFLEtBQUksQ0FBQyxPQUFPLENBQUMsR0FBRyxFQUFFLEtBQUssQ0FBQyxDQUFDLEVBQWhELENBQWdELENBQUM7cUJBQ3RFLElBQUksQ0FBQyxRQUFRLEVBQUUsVUFBQyxLQUFLLElBQUssT0FBQSxhQUFhLENBQUMsU0FBUyxFQUFFLEtBQUksQ0FBQyxPQUFPLENBQUMsUUFBUSxFQUFFLEtBQUssQ0FBQyxDQUFDLEVBQXZELENBQXVELENBQUMsQ0FBQzthQUMzRjtpQkFBTTtnQkFDSCxTQUFTO3FCQUNKLElBQUksQ0FBQyxHQUFHLEVBQUUsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztxQkFDcEIsSUFBSSxDQUFDLFFBQVEsRUFBRSxDQUFDLENBQUMsQ0FBQztnQkFFdkIsaUJBQWlCLEdBQUcsU0FBUyxDQUFDLFVBQVUsRUFBRSxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsa0JBQWtCLENBQUM7cUJBQ3ZFLElBQUksQ0FBQyxHQUFHLEVBQUUsVUFBQyxLQUFLLElBQUssT0FBQSxhQUFhLENBQUMsT0FBTyxFQUFFLEtBQUksQ0FBQyxPQUFPLENBQUMsR0FBRyxFQUFFLEtBQUssQ0FBQyxDQUFDLEVBQWhELENBQWdELENBQUM7cUJBQ3RFLElBQUksQ0FBQyxRQUFRLEVBQUUsVUFBQyxLQUFLLElBQUssT0FBQSxhQUFhLENBQUMsU0FBUyxFQUFFLEtBQUksQ0FBQyxPQUFPLENBQUMsUUFBUSxFQUFFLEtBQUssQ0FBQyxDQUFDLEVBQXZELENBQXVELENBQUMsQ0FBQzthQUMzRjtTQUVKO2FBQU07WUFDSCxTQUFTO2lCQUNKLElBQUksQ0FBQyxRQUFRLEVBQUUsYUFBYSxDQUFDLFNBQVMsRUFBRSxZQUFZLENBQUMsS0FBSyxDQUFDLENBQUM7aUJBQzVELElBQUksQ0FBQyxHQUFHLEVBQUUsVUFBQyxLQUFLLEVBQUUsTUFBTTtnQkFDckIsSUFBSSxLQUFJLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxLQUFLLFNBQVM7b0JBQUUsTUFBTSxHQUFHLFlBQVksQ0FBQyxLQUFLLEdBQUcsTUFBTSxHQUFHLFlBQVksQ0FBQyxPQUFPLEdBQUcsTUFBTSxDQUFDO2dCQUMxRyxPQUFPLGFBQWEsQ0FBQyxPQUFPLEVBQUUsS0FBSSxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxHQUFHLE1BQU0sQ0FBQyxDQUFDO1lBQy9ELENBQUMsQ0FBQyxDQUFDO1lBRVAsSUFBSSxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsU0FBUyxFQUFFO2dCQUN4QixTQUFTO3FCQUNKLElBQUksQ0FBQyxHQUFHLEVBQUUsVUFBQyxLQUFLLElBQUssT0FBQSxhQUFhLENBQUMsT0FBTyxFQUFFLEtBQUksQ0FBQyxPQUFPLENBQUMsR0FBRyxFQUFFLEtBQUssQ0FBQyxDQUFDLEVBQWhELENBQWdELENBQUM7cUJBQ3RFLElBQUksQ0FBQyxPQUFPLEVBQUUsVUFBQyxLQUFLLElBQUssT0FBQSxhQUFhLENBQUMsUUFBUSxFQUFFLEtBQUksQ0FBQyxPQUFPLENBQUMsT0FBTyxFQUFFLEtBQUssQ0FBQyxDQUFDLEVBQXJELENBQXFELENBQUMsQ0FBQzthQUN4RjtpQkFBTTtnQkFDSCxTQUFTO3FCQUNKLElBQUksQ0FBQyxHQUFHLEVBQUUsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztxQkFDcEIsSUFBSSxDQUFDLE9BQU8sRUFBRSxDQUFDLENBQUMsQ0FBQztnQkFFdEIsaUJBQWlCLEdBQUcsU0FBUyxDQUFDLFVBQVUsRUFBRSxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsa0JBQWtCLENBQUM7cUJBQ3ZFLElBQUksQ0FBQyxHQUFHLEVBQUUsVUFBQyxLQUFLLElBQUssT0FBQSxhQUFhLENBQUMsT0FBTyxFQUFFLEtBQUksQ0FBQyxPQUFPLENBQUMsR0FBRyxFQUFFLEtBQUssQ0FBQyxDQUFDLEVBQWhELENBQWdELENBQUM7cUJBQ3RFLElBQUksQ0FBQyxPQUFPLEVBQUUsVUFBQyxLQUFLLElBQUssT0FBQSxhQUFhLENBQUMsUUFBUSxFQUFFLEtBQUksQ0FBQyxPQUFPLENBQUMsT0FBTyxFQUFFLEtBQUssQ0FBQyxDQUFDLEVBQXJELENBQXFELENBQUMsQ0FBQzthQUN4RjtTQUVKO1FBRUQsT0FBTztZQUNILFNBQVMsRUFBRSxTQUFTO1lBQ3BCLGlCQUFpQixFQUFFLGlCQUFpQjtZQUNwQyxPQUFPLEVBQUUsT0FBTztZQUNoQixPQUFPLEVBQUUsT0FBTztZQUNoQixRQUFRLEVBQUUsUUFBUTtZQUNsQixTQUFTLEVBQUUsU0FBUztTQUN2QixDQUFDO1FBRUYsU0FBUyxhQUFhLENBQUMsTUFBcUIsRUFBRSxLQUFhO1lBQ3ZELE1BQU0sQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLENBQUM7WUFDbkIsT0FBTyxLQUFLLENBQUM7UUFDakIsQ0FBQztJQUNMLENBQUM7SUFFTyw0QkFBTyxHQUFmLFVBQWdCLEtBQXFDLEVBQUUsTUFBZ0I7UUFDbkUsSUFBSSxLQUFLLEdBQUcsSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsS0FBSyxLQUFLLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUM7UUFDMUUsSUFBSSxNQUFNLEdBQVcsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztRQUVuQyxJQUFJLEtBQUssS0FBSyxHQUFHLElBQUksS0FBSyxLQUFLLEdBQUcsRUFBRTtZQUNoQyxPQUFPLElBQUksQ0FBQyxhQUFhLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsYUFBYSxDQUFDLE1BQU0sQ0FBQyxHQUFHLEVBQUUsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxhQUFhLENBQUMsTUFBTSxDQUFDLEdBQUcsRUFBRSxLQUFLLENBQUMsR0FBRyxJQUFJLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUM7U0FDckk7UUFDRCxJQUFJLEtBQUssS0FBSyxRQUFRO1lBQUUsT0FBTyxJQUFJLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsYUFBYSxDQUFDLE1BQU0sQ0FBQyxHQUFHLEVBQUUsS0FBSyxDQUFDLEdBQUcsS0FBSyxDQUFDLEdBQUcsSUFBSSxDQUFDLENBQUMsQ0FBQyxhQUFhLENBQUMsTUFBTSxDQUFDLEdBQUcsRUFBRSxLQUFLLENBQUMsQ0FBQyxDQUFDLEdBQUcsTUFBTSxDQUFDO1FBQzlJLElBQUksS0FBSyxLQUFLLE9BQU87WUFBRSxPQUFPLElBQUksQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxhQUFhLENBQUMsTUFBTSxDQUFDLEdBQUcsRUFBRSxLQUFLLENBQUMsQ0FBQyxHQUFHLElBQUksQ0FBQyxDQUFDLENBQUMsYUFBYSxDQUFDLE1BQU0sQ0FBQyxHQUFHLEVBQUUsS0FBSyxDQUFDLEdBQUcsS0FBSyxDQUFDLENBQUMsR0FBRyxNQUFNLENBQUM7UUFFN0kscUpBQXFKO1FBQ3JKLFNBQVMsYUFBYSxDQUFDLElBQVksRUFBRSxNQUFjO1lBQy9DLE9BQU8sSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksR0FBRyxNQUFNLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQztRQUN0RCxDQUFDO0lBQ0wsQ0FBQztJQUVPLHNDQUFpQixHQUF6QixVQUEwQixFQUFlLEVBQUUsT0FBZSxFQUFFLE1BQWtCO1FBQzFFLEtBQUssSUFBSSxNQUFNLEdBQUcsQ0FBQyxFQUFFLE1BQU0sR0FBRyxFQUFFLENBQUMsQ0FBQyxDQUFDLE1BQU0sRUFBRSxFQUFFLE1BQU0sRUFBRTtZQUNqRCxJQUFJLEVBQUUsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsS0FBSyxLQUFLLElBQUk7Z0JBQUUsU0FBUztZQUUxQyxJQUFJLEtBQUssR0FBYSxNQUFNLENBQUMsTUFBTSxDQUFDLEVBQUUsRUFBRSxFQUFFLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLEVBQ2pELFVBQVUsR0FBdUI7Z0JBQzdCLElBQUksRUFBRSxNQUFNLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQztnQkFDNUIsSUFBSSxFQUFFLE1BQU0sQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDO2dCQUM1QixNQUFNLEVBQUUsSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsS0FBSyxRQUFRLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxTQUFTLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDO2dCQUN2RixLQUFLLEVBQUUsSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsS0FBSyxRQUFRLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxRQUFRLENBQUMsTUFBTSxDQUFDO2FBQ3ZGLENBQUM7WUFFTixJQUFJLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLE1BQU0sRUFBRTtnQkFDbEMsSUFBSSxJQUFJLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxLQUFLLFFBQVEsRUFBRTtvQkFDaEMsSUFBSSxDQUFDLEtBQUssQ0FBQyxLQUFLLEdBQUcsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxXQUFXLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxLQUFLLEdBQUcsQ0FBQyxJQUFJLElBQUksQ0FBQyxTQUFTLENBQUMsV0FBVyxDQUFDLEVBQUU7d0JBQ3JHLFVBQVUsQ0FBQyxJQUFJLElBQUksTUFBTSxDQUFDLFNBQVMsQ0FBQyxNQUFNLENBQUMsQ0FBQztxQkFDL0M7b0JBQ0QsNENBQTRDO29CQUM1QyxJQUFJLElBQUksQ0FBQyxLQUFLO3dCQUFFLFVBQVUsQ0FBQyxJQUFJLElBQUksTUFBTSxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQztpQkFDekQ7cUJBQU07b0JBQ0gsSUFBSSxDQUFDLEtBQUssQ0FBQyxLQUFLLEdBQUcsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxXQUFXLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxLQUFLLEdBQUcsQ0FBQyxJQUFJLElBQUksQ0FBQyxTQUFTLENBQUMsV0FBVyxDQUFDLEVBQUU7d0JBQ3JHLFVBQVUsQ0FBQyxJQUFJLElBQUksTUFBTSxDQUFDLFFBQVEsQ0FBQyxNQUFNLENBQUMsQ0FBQztxQkFDOUM7aUJBQ0o7YUFDSjtpQkFBTTtnQkFDSCxJQUFJLElBQUksQ0FBQyxLQUFLLEVBQUU7b0JBQ1osWUFBWTtvQkFDWiw4Q0FBOEM7b0JBQzlDLCtEQUErRDtvQkFDL0QsSUFBSSxLQUFLLEdBQUcsSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsS0FBSyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDO29CQUN4RCxVQUFVLENBQUMsSUFBSSxJQUFJLE1BQU0sQ0FBQyxRQUFRLENBQUMsS0FBSyxDQUFDLENBQUM7aUJBQzdDO2FBQ0o7WUFDRCxJQUFJLElBQUksQ0FBQyxTQUFTLENBQUMsZUFBZTtnQkFBRSxLQUFLLENBQUMsS0FBSyxHQUFHLElBQUksQ0FBQyxTQUFTLENBQUMsNEJBQTRCLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxDQUFDO1lBRTNHLElBQUksY0FBYyxHQUFRLGlCQUFNLFFBQVEsWUFBQyxLQUFLLEVBQUUsT0FBTyxFQUFFLFVBQVUsQ0FBQyxJQUFJLEVBQUUsVUFBVSxDQUFDLElBQUksQ0FBQyxDQUFDO1lBRTNGLHlFQUF5RTtZQUN6RSxJQUFJLENBQUMsY0FBYyxDQUFDLGNBQWMsRUFBRSxFQUFFLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLEtBQUssRUFBRSxVQUFVLENBQUMsQ0FBQztTQUN2RTtJQUNMLENBQUM7SUFFRCxnREFBZ0Q7SUFDaEQsNkNBQTZDO0lBQ3JDLG1DQUFjLEdBQXRCLFVBQXVCLGVBQWUsRUFBRSxNQUFjLEVBQUUsV0FBK0I7UUFDbkYsSUFBSSxTQUFTLEdBQVEsZUFBZSxDQUFDLE1BQU0sQ0FBQyw2QkFBNkIsQ0FBQyxDQUFDO1FBQzNFLElBQUksYUFBYSxHQUFHLElBQUksQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxhQUFhLENBQUM7UUFDM0QsSUFBSSxNQUFNLEdBQVksSUFBSSxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQztRQUN0RCxJQUFJLElBQUksR0FBVyxJQUFJLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDO1FBQ3JDLElBQUksQ0FBQyxhQUFhO1lBQUUsYUFBYSxHQUFHLElBQUksQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLEtBQUssUUFBUSxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQztRQUV0RixJQUFJLENBQUMsT0FBTyxDQUFDLDhCQUE4QixDQUFDLGVBQWUsRUFBRSxJQUFJLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxFQUFFLE1BQU0sRUFBRSxXQUFXLENBQUMsQ0FBQztRQUVyRyxnREFBZ0Q7UUFDaEQsSUFBSSxxQkFBcUIsR0FBRyxJQUFJLENBQUMsU0FBUyxDQUFDLG1CQUFtQixFQUFFLEdBQUcsV0FBVyxDQUFDLE1BQU0sQ0FBQztRQUN0RixJQUFJLHFCQUFxQixFQUFFO1lBQ3ZCLElBQUksSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsS0FBSyxLQUFLLEVBQUU7Z0JBQzdCLGFBQWEsR0FBRyxRQUFRLENBQUM7YUFDNUI7aUJBQU0sSUFBSSxNQUFNLEVBQUU7Z0JBQ2YsbUVBQW1FO2dCQUNuRSxtRkFBbUY7Z0JBQ25GLGtGQUFrRjtnQkFDbEYsYUFBYSxHQUFHLElBQUksQ0FBQyxTQUFTLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQzthQUNqRTtTQUNKO1FBRUQsSUFBSSxDQUFDLE1BQU0sRUFBRTtZQUNULElBQUksSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsS0FBSyxLQUFLLEVBQUU7Z0JBQzdCLElBQUksQ0FBQyxPQUFPLENBQUMsMEJBQTBCLENBQ25DLFNBQVMsRUFDVCxJQUFJLENBQUMsU0FBUyxDQUFDLFdBQVcsRUFDMUIsRUFBRSxJQUFJLEVBQUUsV0FBVyxDQUFDLElBQUksRUFBRSxVQUFVLEVBQUUsSUFBSSxDQUFDLEtBQUssRUFBRSxTQUFTLEVBQUUsSUFBSSxFQUFFLENBQ3RFLENBQUM7YUFDTDtpQkFBTTtnQkFDSCxJQUFJLE1BQU0sR0FBRyxFQUFFLFNBQVMsRUFBRSxJQUFJLEVBQUUsQ0FBQztnQkFDakMsSUFBSSxJQUFJLEdBQUcsV0FBVyxDQUFDLElBQUksQ0FBQyxDQUFDLDhCQUE4QjtnQkFDM0QsSUFBSSxxQkFBcUIsSUFBSSxJQUFJLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxLQUFLLFNBQVMsRUFBRTtvQkFDMUQsTUFBTSxDQUFDLFlBQVksQ0FBQyxHQUFHLFdBQVcsQ0FBQztvQkFDbkMsSUFBSSxVQUFVLEdBQVEsSUFBSSxDQUFDLFNBQVMsQ0FBQyxtQkFBbUIsQ0FBQyxhQUFhLEVBQUUsTUFBTSxDQUFDLENBQUM7b0JBQ2hGLElBQUksVUFBVTt3QkFBRSxJQUFJLElBQUksVUFBVSxHQUFHLFdBQVcsQ0FBQyxNQUFNLENBQUM7aUJBQzNEO2dCQUNELGlCQUFNLG9CQUFvQixZQUFDLFNBQVMsRUFBRSxJQUFJLEVBQUUsTUFBTSxDQUFDLENBQUM7YUFDdkQ7U0FDSjtRQUdELElBQUksQ0FBQyxPQUFPLENBQUMsbUJBQW1CLENBQUMsZUFBZSxFQUFFLGFBQWEsQ0FBQyxDQUFDO0lBQ3JFLENBQUM7SUFFTyxxQ0FBZ0IsR0FBeEI7UUFDSSxJQUFJLENBQUMsa0JBQWtCO2FBQ2xCLFNBQVMsQ0FBQyx3QkFBd0IsQ0FBQzthQUNuQyxLQUFLLENBQUMsWUFBWSxFQUFFLFNBQVMsQ0FBQyxDQUFDO0lBQ3hDLENBQUM7SUFFTyxvQ0FBZSxHQUF2QjtRQUNJLElBQUksSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsS0FBSyxTQUFTLEVBQUU7WUFDakMsZ0dBQWdHO1lBQ2hHLGdEQUFnRDtZQUNoRCxJQUFJLFVBQVUsR0FBRyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxJQUFJLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztZQUM1RSxPQUFPLElBQUksQ0FBQyxPQUFPLENBQUMsWUFBWSxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsU0FBUyxFQUFFLEVBQUUsSUFBSSxDQUFDLEdBQUcsQ0FBQyxxQkFBcUIsRUFBRSxVQUFVLENBQUMsQ0FBQztTQUNwRztRQUNELE9BQU87WUFDSCxLQUFLLEVBQUUsSUFBSSxDQUFDLENBQUMsQ0FBQyxTQUFTLEVBQUU7WUFDekIsT0FBTyxFQUFFLENBQUM7U0FDYixDQUFDO0lBQ04sQ0FBQztJQUVPLCtDQUEwQixHQUFsQztRQUNJLElBQUksTUFBTSxHQUE4QixJQUFJLENBQUMsT0FBTyxDQUFDLGtCQUFrQixDQUFDLElBQUksQ0FBQyxTQUFTLEVBQUUsSUFBSSxDQUFDLE1BQU0sQ0FBQyxXQUFXLEVBQUUsSUFBSSxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsQ0FBQztRQUNwSSxJQUFJLE1BQU0sQ0FBQyxjQUFjLENBQUMsV0FBVyxDQUFDO1lBQUUsSUFBSSxDQUFDLFNBQVMsR0FBRyxNQUFNLENBQUMsU0FBUyxDQUFDO1FBQzFFLElBQUksTUFBTSxDQUFDLGNBQWMsQ0FBQyxPQUFPLENBQUMsRUFBRTtZQUNoQyxJQUFJLENBQUMsTUFBTSxDQUFDLEtBQUssR0FBRyxNQUFNLENBQUMsTUFBTSxDQUFDLEVBQUUsRUFBRSxJQUFJLENBQUMsTUFBTSxDQUFDLEtBQUssRUFBRSxNQUFNLENBQUMsS0FBSyxDQUFDLENBQUM7U0FDMUU7SUFDTCxDQUFDOztnQkFoVXFCLFdBQVc7Z0JBQ2IsWUFBWTtnQkFDWixhQUFhOztJQVJsQjtRQUFkLEtBQUssQ0FBQyxNQUFNLENBQUM7OytDQUFrQjtJQUNmO1FBQWhCLEtBQUssQ0FBQyxRQUFRLENBQUM7O2lEQUF5QjtJQUNoQztRQUFSLEtBQUssRUFBRTs7OENBQXdDO0lBQ3ZDO1FBQVIsS0FBSyxFQUFFOzsyQ0FBVTtJQVRULFVBQVU7UUFkdEIsU0FBUyxDQUFDO1lBQ1AsUUFBUSxFQUFFLGNBQWM7WUFDeEIsUUFBUSxFQUFFLGlKQUlUO1lBQ0QsYUFBYSxFQUFFLGlCQUFpQixDQUFDLElBQUk7WUFDckMsU0FBUyxFQUFFLENBQUMsV0FBVyxFQUFFLFlBQVksRUFBRSxhQUFhLENBQUM7WUFDckQsSUFBSSxFQUFFO2dCQUNGLE9BQU8sRUFBRSxlQUFlO2FBQzNCO1NBQ0osQ0FBQzt5Q0Fjd0IsV0FBVztZQUNiLFlBQVk7WUFDWixhQUFhO09BZHhCLFVBQVUsQ0E2VXRCO0lBQUQsaUJBQUM7Q0FBQSxBQTdVRCxDQUFnQyxnQkFBZ0IsR0E2VS9DO1NBN1VZLFVBQVUiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQge1xyXG4gICAgQ29tcG9uZW50LFxyXG4gICAgVmlld0VuY2Fwc3VsYXRpb24sXHJcbiAgICBJbnB1dCxcclxuICAgIE9uSW5pdCxcclxuICAgIE9uQ2hhbmdlcyxcclxuICAgIFNpbXBsZUNoYW5nZXMsXHJcbiAgICBPbkRlc3Ryb3lcclxufSBmcm9tICdAYW5ndWxhci9jb3JlJztcclxuaW1wb3J0IHsgS2RDaGFydEJhc2VDbGFzcyB9IGZyb20gJy4uL2tkLWFuZ3VsYXItY2hhcnQtYmFzZS1jbGFzcyc7XHJcbmltcG9ydCB7IEtkQ2hhcnRzU3ZjIH0gZnJvbSAnLi4va2QtYW5ndWxhci1jaGFydHMtc3ZjJztcclxuaW1wb3J0IHsgSUQzRGF0YSwgSUNoYXJ0Q29uZmlnLCBJRDNEYXRhRGF0YSwgSUQzWURhdGEsIElMZWdlbmREYXRhIH0gZnJvbSAnLi4va2QtYW5ndWxhci1jaGFydHMtaW50ZXJmYWNlJztcclxuaW1wb3J0IHsgSVJlY3RQb3NJbmZvLCBJUmVjdEdyb3VwLCBJQmFyUmVjdERpbWVuc2lvbnMsIElOZWdhdGl2ZVN0YWNrTG9naWNSZXR1cm4gfSBmcm9tICcuL2tkLWFuZ3VsYXItYmFyLWNoYXJ0LWludGVyZmFjZSc7XHJcbmltcG9ydCB7IEtkRG9tRWxlbVN2YyB9IGZyb20gJy4uLy4uL2tkLWNvbW1vbi9pbmRleCc7XHJcbmltcG9ydCB7IEtkQmFyQ2hhcnRTdmMgfSBmcm9tICcuL2tkLWFuZ3VsYXItYmFyLWNoYXJ0LXN2Yyc7XHJcblxyXG5AQ29tcG9uZW50KHtcclxuICAgIHNlbGVjdG9yOiAna2QtYmFyLWNoYXJ0JyxcclxuICAgIHRlbXBsYXRlOiBgXHJcbiAgICAgICAgPGRpdiAqbmdJZj1cImNoYXJ0VHlwZVsxXSA9PT0gJzEwMCcgJiYgaGF2ZU5lZ2F0aXZlXCIgY2xhc3M9XCJrZHgtY2hhcnRzLWVycm9yLW1zZ1wiPlxyXG4gICAgICAgICAgICB7e2Vycm9yTXNnfX1cclxuICAgICAgICA8L2Rpdj5cclxuICAgIGAsXHJcbiAgICBlbmNhcHN1bGF0aW9uOiBWaWV3RW5jYXBzdWxhdGlvbi5Ob25lLFxyXG4gICAgcHJvdmlkZXJzOiBbS2RDaGFydHNTdmMsIEtkRG9tRWxlbVN2YywgS2RCYXJDaGFydFN2Y10sXHJcbiAgICBob3N0OiB7XHJcbiAgICAgICAgJ2NsYXNzJzogJ2tkeC1iYXItY2hhcnQnLFxyXG4gICAgfVxyXG59KVxyXG5cclxuZXhwb3J0IGNsYXNzIEtkQmFyQ2hhcnQgZXh0ZW5kcyBLZENoYXJ0QmFzZUNsYXNzIGltcGxlbWVudHMgT25Jbml0LCBPbkNoYW5nZXMsIE9uRGVzdHJveSB7XHJcblxyXG4gICAgcHJpdmF0ZSBfYmFyR3JhcGg6IGFueTtcclxuICAgIHByaXZhdGUgX3Jlc2l6ZVRpbWVvdXQ6IGFueTtcclxuICAgIHByaXZhdGUgX2lzU3RhcnRBdFN1bTogYm9vbGVhbiA9IGZhbHNlO1xyXG5cclxuICAgIEBJbnB1dCgnZGF0YScpIGFsbERhdGE6IElEM0RhdGE7XHJcbiAgICBASW5wdXQoJ2NvbmZpZycpIGJhckNvbmZpZzogSUNoYXJ0Q29uZmlnO1xyXG4gICAgQElucHV0KCkgbGVnZW5kOiB7IFtrZXk6IHN0cmluZ106IElMZWdlbmREYXRhIH07XHJcbiAgICBASW5wdXQoKSBhcGk6IGFueTtcclxuXHJcbiAgICBjb25zdHJ1Y3RvcihcclxuICAgICAgICBwdWJsaWMgX2NoYXJ0U3ZjOiBLZENoYXJ0c1N2YyxcclxuICAgICAgICBwdWJsaWMgX2RvbVN2YzogS2REb21FbGVtU3ZjLFxyXG4gICAgICAgIHB1YmxpYyBfYmFyU3ZjOiBLZEJhckNoYXJ0U3ZjXHJcbiAgICApIHtcclxuICAgICAgICBzdXBlcihfY2hhcnRTdmMsIF9kb21TdmMpO1xyXG4gICAgfVxyXG5cclxuICAgIG5nT25Jbml0KCk6IHZvaWQge1xyXG4gICAgICAgIHRoaXMuX3JlZHJhd0NoYXJ0KHRydWUsIHsgZGF0YTogdGhpcy5hbGxEYXRhLCBjb25maWc6IHRoaXMuYmFyQ29uZmlnIH0pO1xyXG4gICAgICAgIHRoaXMuYXBpLmxlZ2VuZENsaWNrID0gKF9kYXRhOiBhbnkpID0+IHtcclxuICAgICAgICAgICAgdGhpcy5fcmVkcmF3Q2hhcnQoZmFsc2UsIHsgZGF0YTogX2RhdGEgfSk7XHJcbiAgICAgICAgfTtcclxuICAgICAgICB0aGlzLmFwaS5yZWRyYXcgPSAoKSA9PiB7XHJcbiAgICAgICAgICAgIGNsZWFyVGltZW91dCh0aGlzLl9yZXNpemVUaW1lb3V0KTtcclxuICAgICAgICAgICAgdGhpcy5fcmVzaXplVGltZW91dCA9IHNldFRpbWVvdXQoKCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5fcmVkcmF3Q2hhcnQoZmFsc2UsIHt9KTtcclxuICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgfTtcclxuICAgIH1cclxuXHJcbiAgICBuZ09uQ2hhbmdlcyhfc2ltcGxlQ2hhbmdlczogU2ltcGxlQ2hhbmdlcyk6IHZvaWQge1xyXG4gICAgICAgIGlmIChfc2ltcGxlQ2hhbmdlcy5oYXNPd25Qcm9wZXJ0eSgnYWxsRGF0YScpICYmICFfc2ltcGxlQ2hhbmdlc1snYWxsRGF0YSddLmZpcnN0Q2hhbmdlKSB7XHJcbiAgICAgICAgICAgIHRoaXMuX3JlZHJhd0NoYXJ0KGZhbHNlLCB7IGRhdGE6IF9zaW1wbGVDaGFuZ2VzLmFsbERhdGEuY3VycmVudFZhbHVlIH0pO1xyXG4gICAgICAgIH1cclxuICAgICAgICBpZiAoX3NpbXBsZUNoYW5nZXMuaGFzT3duUHJvcGVydHkoJ2JhckNvbmZpZycpICYmICFfc2ltcGxlQ2hhbmdlc1snYmFyQ29uZmlnJ10uZmlyc3RDaGFuZ2UpIHtcclxuICAgICAgICAgICAgdGhpcy5fcmVkcmF3Q2hhcnQoZmFsc2UsIHsgY29uZmlnOiBfc2ltcGxlQ2hhbmdlcy5iYXJDb25maWcuY3VycmVudFZhbHVlIH0pO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICBuZ09uRGVzdHJveSgpOiB2b2lkIHtcclxuICAgICAgICB0aGlzLl9yZXNldENoYXJ0KCk7XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfcmVkcmF3Q2hhcnQoaXNGaXJzdENoYW5nZTogYm9vbGVhbiwgX2NoYW5nZXM6IHsgZGF0YT86IElEM0RhdGEsIGNvbmZpZz86IElDaGFydENvbmZpZyB9ID0ge30pIHtcclxuICAgICAgICBpZiAoIWlzRmlyc3RDaGFuZ2UpIHtcclxuICAgICAgICAgICAgdGhpcy5fcmVzZXRDaGFydCgpO1xyXG4gICAgICAgIH1cclxuICAgICAgICB0aGlzLmxlZ2VuZERhdGEgPSBPYmplY3QuYXNzaWduKHt9LCB0aGlzLmxlZ2VuZCk7XHJcbiAgICAgICAgaWYgKF9jaGFuZ2VzLmhhc093blByb3BlcnR5KCdkYXRhJykpIHRoaXMuX3NldERhdGEoX2NoYW5nZXMuZGF0YSk7XHJcbiAgICAgICAgaWYgKF9jaGFuZ2VzLmhhc093blByb3BlcnR5KCdjb25maWcnKSkgdGhpcy5fc2V0Q29uZmlnKF9jaGFuZ2VzLmNvbmZpZyk7XHJcbiAgICAgICAgc3VwZXIuY2hhcnRUaW1lb3V0KCgpID0+IHRoaXMuX3NldENoYXJ0KCkpO1xyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX3NldERhdGEoX2RhdGE6IElEM0RhdGEpOiB2b2lkIHtcclxuICAgICAgICB0aGlzLmRhdGEgPSBPYmplY3QuYXNzaWduKFtdLCBfZGF0YS5kYXRhKTtcclxuICAgICAgICAvLyBzYXZpbmcgb3JpZ2luYWwgZGF0YSBzb21ld2hlcmUgYmVmb3JlIHRyaW1taW5nIHRoaXMuZGF0YS4gd2hlbiBubyB0cmltbWluZywgdGhlbiB0aGlzLmRhdGEgd2lsbCBqdXN0IGJlIGluaXREYXRhXHJcbiAgICAgICAgdGhpcy5pbml0RGF0YSA9IEpTT04ucGFyc2UoSlNPTi5zdHJpbmdpZnkodGhpcy5kYXRhKSk7XHJcblxyXG4gICAgICAgIHRoaXMuY2hhcnRDYXRlZ29yeSA9ICdiYXInO1xyXG4gICAgICAgIHRoaXMuY2hhcnRUeXBlID0gX2RhdGEubGF5b3V0LnNwbGl0KCctJyk7XHJcbiAgICAgICAgdGhpcy5fY2hhcnRTdmMuaXNJbnZlcnQgPSB0aGlzLmNoYXJ0VHlwZVswXSA9PT0gJ2Jhcic7XHJcbiAgICAgICAgdGhpcy5iYXIuaXNJbnZlcnQgPSB0aGlzLmNoYXJ0VHlwZVswXSA9PT0gJ2Jhcic7XHJcbiAgICAgICAgdGhpcy5fY2hhcnRTdmMuaXNOZWdhdGl2ZVN0YWNrID0gdGhpcy5jaGFydFR5cGVbMV0gPT09ICdzdGFjaycgJiYgdGhpcy5jaGFydFR5cGVbMl0gPT09ICduZWdhdGl2ZSc7XHJcblxyXG4gICAgICAgIC8vIHJhbmdlIGFuZCBuZWdhdGl2ZSBmbGFnIGNhbGN1bGF0ZWQgYnkga2RDaGFydCwgdXNlZCBpbiBkb21haW4sIHJlY2FsY3VsYXRlZCB3aGVuIGNoYW5nZSBncmFwaCB0eXBlIGFuZCBsZWdlbmRcclxuICAgICAgICB0aGlzLmRhdGFSYW5nZSA9IF9kYXRhLnJhbmdlO1xyXG4gICAgICAgIHRoaXMuaGF2ZU5lZ2F0aXZlID0gX2RhdGEuaGF2ZU5lZ2F0aXZlO1xyXG4gICAgICAgIHRoaXMuX2JhclN2Yy5vcmlnaW5hbERhdGFSYW5nZSA9IF9kYXRhLnJhbmdlO1xyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX3NldENvbmZpZyhfY29uZmlnOiBJQ2hhcnRDb25maWcpOiB2b2lkIHtcclxuICAgICAgICB0aGlzLmNvbmZpZyA9IE9iamVjdC5hc3NpZ24oe30sIF9jb25maWcpO1xyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX3NldENoYXJ0KCk6IHZvaWQge1xyXG4gICAgICAgIGlmICh0aGlzLmNoYXJ0VHlwZVsxXSA9PT0gJzEwMCcgJiYgdGhpcy5oYXZlTmVnYXRpdmUpIHJldHVybjtcclxuICAgICAgICBpZiAodGhpcy5fY2hhcnRTdmMuaXNOZWdhdGl2ZVN0YWNrKSB0aGlzLm5lZ2F0aXZlU3RhY2tTeW1tZXRyeUxvZ2ljKCk7XHJcbiAgICAgICAgc3VwZXIuc2V0U3ZnKCk7XHJcbiAgICAgICAgc3VwZXIuc2V0RG9tYWluKCdiYW5kJyk7XHJcbiAgICAgICAgdGhpcy5fZHJhd0NoYXJ0KCk7XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfcmVzZXRDaGFydCgpOiB2b2lkIHtcclxuICAgICAgICBzdXBlci5yZW1vdmVDaGFydCgpO1xyXG4gICAgICAgIGlmICh0aGlzLl9iYXJHcmFwaCkge1xyXG4gICAgICAgICAgICB0aGlzLl9iYXJHcmFwaC5yZW1vdmUoKTtcclxuICAgICAgICAgICAgdGhpcy5fYmFyR3JhcGggPSBudWxsO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF9kcmF3Q2hhcnRDb250YWluZXIoKTogdm9pZCB7XHJcbiAgICAgICAgdGhpcy5fYmFyR3JhcGggPSB0aGlzLmdyYXBoLmFwcGVuZCgnZycpLmF0dHIoJ2NsYXNzJywgJ2Jhci1ncmFwaC1jb250YWluZXInKTtcclxuICAgICAgICB0aGlzLl9iYXJHcmFwaC5hdHRyKCdjbGlwLXBhdGgnLCAndXJsKCNrZC1jaGFydHMtY2xpcC1wYXRoLScgKyB0aGlzLmNvbmZpZy5pZCArICcpJyk7XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfZHJhd0NoYXJ0KCk6IHZvaWQge1xyXG4gICAgICAgIGlmICghdGhpcy5fYmFyR3JhcGgpIHRoaXMuX2RyYXdDaGFydENvbnRhaW5lcigpO1xyXG5cclxuICAgICAgICB0aGlzLl9pc1N0YXJ0QXRTdW0gPSB0aGlzLmJhci5pc0ludmVydCA9PT0gdGhpcy5fY2hhcnRTdmMuaXNZUmV2ZXJzZWQ7XHJcblxyXG4gICAgICAgIGxldCByZWN0UG9zSW5mbzogeyB3aWR0aDogbnVtYmVyLCBwYWRkaW5nOiBudW1iZXIgfSA9IHRoaXMuX2dldFJlY3RQb3NJbmZvKCk7XHJcblxyXG4gICAgICAgIHRoaXMuZGF0YS5mb3JFYWNoKChkOiBJRDNEYXRhRGF0YSwgaTogbnVtYmVyKSA9PiB7XHJcbiAgICAgICAgICAgIGxldCBncm91cHM6IElSZWN0R3JvdXAgPSB0aGlzLl9zZXRSZWN0R3JvdXAoZCwgaSwgZC55LCB0aGlzLl9iYXJHcmFwaCwgcmVjdFBvc0luZm8pO1xyXG5cclxuICAgICAgICAgICAgc3VwZXIuX2luaXRNb3VzZUV2ZW50cyhncm91cHMucmVjdEdyb3VwLCB7IGRhdGE6IGQsIGluZGV4OiBpIH0pO1xyXG5cclxuICAgICAgICAgICAgaWYgKHRoaXMuY29uZmlnLmNoYXJ0LmxhYmVscy5lbmFibGVkKSB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLl9zZXRCYXJDaGFydExhYmVsKGQsIGksIGdyb3Vwcyk7XHJcblxyXG4gICAgICAgICAgICAgICAgaWYgKHRoaXMuY29uZmlnLmFuaW1hdGlvbikge1xyXG4gICAgICAgICAgICAgICAgICAgIGdyb3Vwcy5yZWN0R3JvdXBUcmFuc2l0ZS5vbignZW5kJywgKHlEYXRhLCB5SW5kZXgpID0+IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgLy8gd2hlbiB0aGUgbGFzdCByZWN0IHRyYW5zaXRlIGVuZHNcclxuICAgICAgICAgICAgICAgICAgICAgICAgaWYgKCh5RGF0YS54SW5kZXggPT09IHRoaXMuZGF0YS5sZW5ndGggLSAxKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgJiYgKHlJbmRleCA9PT0gdGhpcy5kYXRhW3RoaXMuZGF0YS5sZW5ndGggLSAxXS55Lmxlbmd0aCAtIDEpKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0aGlzLl9kaXNwbGF5QWxsTGFiZWwoKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLl9kaXNwbGF5QWxsTGFiZWwoKTtcclxuICAgICAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9KTtcclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF9zZXRSZWN0R3JvdXAoX2Q6IElEM0RhdGFEYXRhLCBfeEluZGV4OiBudW1iZXIsIF95RGF0YUFycjogQXJyYXk8SUQzWURhdGE+LCBfY29udGFpbmVyOiBhbnksIF9yZWN0UG9zSW5mbzogSVJlY3RQb3NJbmZvKTogSVJlY3RHcm91cCB7XHJcbiAgICAgICAgbGV0IHJlY3RHcm91cCA9IF9jb250YWluZXIuc2VsZWN0QWxsKCdyZWN0R3JvdXAnKVxyXG4gICAgICAgICAgICAuZGF0YShfeURhdGFBcnIsIChkKSA9PiB7IGRbJ3hJbmRleCddID0gX3hJbmRleDsgcmV0dXJuIGQ7IH0pXHJcbiAgICAgICAgICAgIC5lbnRlcigpXHJcbiAgICAgICAgICAgIC5hcHBlbmQoJ3JlY3QnKTtcclxuICAgICAgICBsZXQgb2Zmc2V0ID0gMCwgcmVjdEdyb3VwVHJhbnNpdGU6IGFueSwgeFBvc0FycjogQXJyYXk8bnVtYmVyPiA9IFtdLCB5UG9zQXJyOiBBcnJheTxudW1iZXI+ID0gW10sIHdpZHRoQXJyOiBBcnJheTxudW1iZXI+ID0gW10sIGhlaWdodEFycjogQXJyYXk8bnVtYmVyPiA9IFtdO1xyXG5cclxuICAgICAgICByZWN0R3JvdXBcclxuICAgICAgICAgICAgLmF0dHIoJ2NsYXNzJywgKHlEYXRhKSA9PiAnYmFyIHgtJyArIF94SW5kZXggKyAnIHktJyArIHlEYXRhLmlkKVxyXG4gICAgICAgICAgICAuYXR0cignZmlsbCcsICh5RGF0YSwgeUluZGV4KSA9PiB0aGlzLmxlZ2VuZC5oYXNPd25Qcm9wZXJ0eSh5RGF0YS5pZCkgPyB0aGlzLmxlZ2VuZFt5RGF0YS5pZF0uY29sb3IgfHwgJycgOiAnJylcclxuICAgICAgICAgICAgLmF0dHIoJ2FyaWEteC12YWx1ZScsIF9kLngudmFsdWUpXHJcbiAgICAgICAgICAgIC5hdHRyKCdhcmlhLXktdmFsdWUnLCAoeURhdGEpID0+IHlEYXRhLnN1bSk7XHJcblxyXG4gICAgICAgIGlmICh0aGlzLmNoYXJ0VHlwZVswXSA9PT0gJ2NvbHVtbicpIHtcclxuICAgICAgICAgICAgcmVjdEdyb3VwXHJcbiAgICAgICAgICAgICAgICAuYXR0cignd2lkdGgnLCBwdXNoQW5kUmV0dXJuKHdpZHRoQXJyLCBfcmVjdFBvc0luZm8ud2lkdGgpKVxyXG4gICAgICAgICAgICAgICAgLmF0dHIoJ3gnLCAoeURhdGEsIHlJbmRleCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgIGlmICh0aGlzLmNoYXJ0VHlwZVsxXSA9PT0gJ2NsdXN0ZXInKSBvZmZzZXQgPSBfcmVjdFBvc0luZm8ud2lkdGggKiB5SW5kZXggKyBfcmVjdFBvc0luZm8ucGFkZGluZyAqIHlJbmRleDtcclxuICAgICAgICAgICAgICAgICAgICByZXR1cm4gcHVzaEFuZFJldHVybih4UG9zQXJyLCB0aGlzLngoX2QueC52YWx1ZSkgKyBvZmZzZXQpO1xyXG4gICAgICAgICAgICAgICAgfSk7XHJcblxyXG4gICAgICAgICAgICBpZiAoIXRoaXMuY29uZmlnLmFuaW1hdGlvbikge1xyXG4gICAgICAgICAgICAgICAgcmVjdEdyb3VwXHJcbiAgICAgICAgICAgICAgICAgICAgLmF0dHIoJ3knLCAoeURhdGEpID0+IHB1c2hBbmRSZXR1cm4oeVBvc0FyciwgdGhpcy5fZ2V0VmFsKCd5JywgeURhdGEpKSlcclxuICAgICAgICAgICAgICAgICAgICAuYXR0cignaGVpZ2h0JywgKHlEYXRhKSA9PiBwdXNoQW5kUmV0dXJuKGhlaWdodEFyciwgdGhpcy5fZ2V0VmFsKCdoZWlnaHQnLCB5RGF0YSkpKTtcclxuICAgICAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgICAgIHJlY3RHcm91cFxyXG4gICAgICAgICAgICAgICAgICAgIC5hdHRyKCd5JywgdGhpcy55KDApKVxyXG4gICAgICAgICAgICAgICAgICAgIC5hdHRyKCdoZWlnaHQnLCAwKTtcclxuXHJcbiAgICAgICAgICAgICAgICByZWN0R3JvdXBUcmFuc2l0ZSA9IHJlY3RHcm91cC50cmFuc2l0aW9uKCkuZHVyYXRpb24odGhpcy5sZW5ndGhPZlRyYW5zaXRpb24pXHJcbiAgICAgICAgICAgICAgICAgICAgLmF0dHIoJ3knLCAoeURhdGEpID0+IHB1c2hBbmRSZXR1cm4oeVBvc0FyciwgdGhpcy5fZ2V0VmFsKCd5JywgeURhdGEpKSlcclxuICAgICAgICAgICAgICAgICAgICAuYXR0cignaGVpZ2h0JywgKHlEYXRhKSA9PiBwdXNoQW5kUmV0dXJuKGhlaWdodEFyciwgdGhpcy5fZ2V0VmFsKCdoZWlnaHQnLCB5RGF0YSkpKTtcclxuICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICByZWN0R3JvdXBcclxuICAgICAgICAgICAgICAgIC5hdHRyKCdoZWlnaHQnLCBwdXNoQW5kUmV0dXJuKGhlaWdodEFyciwgX3JlY3RQb3NJbmZvLndpZHRoKSlcclxuICAgICAgICAgICAgICAgIC5hdHRyKCd5JywgKHlEYXRhLCB5SW5kZXgpID0+IHtcclxuICAgICAgICAgICAgICAgICAgICBpZiAodGhpcy5jaGFydFR5cGVbMV0gPT09ICdjbHVzdGVyJykgb2Zmc2V0ID0gX3JlY3RQb3NJbmZvLndpZHRoICogeUluZGV4ICsgX3JlY3RQb3NJbmZvLnBhZGRpbmcgKiB5SW5kZXg7XHJcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIHB1c2hBbmRSZXR1cm4oeVBvc0FyciwgdGhpcy54KF9kLngudmFsdWUpICsgb2Zmc2V0KTtcclxuICAgICAgICAgICAgICAgIH0pO1xyXG5cclxuICAgICAgICAgICAgaWYgKCF0aGlzLmNvbmZpZy5hbmltYXRpb24pIHtcclxuICAgICAgICAgICAgICAgIHJlY3RHcm91cFxyXG4gICAgICAgICAgICAgICAgICAgIC5hdHRyKCd4JywgKHlEYXRhKSA9PiBwdXNoQW5kUmV0dXJuKHhQb3NBcnIsIHRoaXMuX2dldFZhbCgneCcsIHlEYXRhKSkpXHJcbiAgICAgICAgICAgICAgICAgICAgLmF0dHIoJ3dpZHRoJywgKHlEYXRhKSA9PiBwdXNoQW5kUmV0dXJuKHdpZHRoQXJyLCB0aGlzLl9nZXRWYWwoJ3dpZHRoJywgeURhdGEpKSk7XHJcbiAgICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgICAgICByZWN0R3JvdXBcclxuICAgICAgICAgICAgICAgICAgICAuYXR0cigneCcsIHRoaXMueSgwKSlcclxuICAgICAgICAgICAgICAgICAgICAuYXR0cignd2lkdGgnLCAwKTtcclxuXHJcbiAgICAgICAgICAgICAgICByZWN0R3JvdXBUcmFuc2l0ZSA9IHJlY3RHcm91cC50cmFuc2l0aW9uKCkuZHVyYXRpb24odGhpcy5sZW5ndGhPZlRyYW5zaXRpb24pXHJcbiAgICAgICAgICAgICAgICAgICAgLmF0dHIoJ3gnLCAoeURhdGEpID0+IHB1c2hBbmRSZXR1cm4oeFBvc0FyciwgdGhpcy5fZ2V0VmFsKCd4JywgeURhdGEpKSlcclxuICAgICAgICAgICAgICAgICAgICAuYXR0cignd2lkdGgnLCAoeURhdGEpID0+IHB1c2hBbmRSZXR1cm4od2lkdGhBcnIsIHRoaXMuX2dldFZhbCgnd2lkdGgnLCB5RGF0YSkpKTtcclxuICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIHJldHVybiB7XHJcbiAgICAgICAgICAgIHJlY3RHcm91cDogcmVjdEdyb3VwLFxyXG4gICAgICAgICAgICByZWN0R3JvdXBUcmFuc2l0ZTogcmVjdEdyb3VwVHJhbnNpdGUsXHJcbiAgICAgICAgICAgIHhQb3NBcnI6IHhQb3NBcnIsXHJcbiAgICAgICAgICAgIHlQb3NBcnI6IHlQb3NBcnIsXHJcbiAgICAgICAgICAgIHdpZHRoQXJyOiB3aWR0aEFycixcclxuICAgICAgICAgICAgaGVpZ2h0QXJyOiBoZWlnaHRBcnJcclxuICAgICAgICB9O1xyXG5cclxuICAgICAgICBmdW5jdGlvbiBwdXNoQW5kUmV0dXJuKHRhcmdldDogQXJyYXk8bnVtYmVyPiwgdmFsdWU6IG51bWJlcik6IG51bWJlciB7XHJcbiAgICAgICAgICAgIHRhcmdldC5wdXNoKHZhbHVlKTtcclxuICAgICAgICAgICAgcmV0dXJuIHZhbHVlO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF9nZXRWYWwoX3R5cGU6ICd4JyB8ICd5JyB8ICdoZWlnaHQnIHwgJ3dpZHRoJywgX3lEYXRhOiBJRDNZRGF0YSk6IG51bWJlciB7XHJcbiAgICAgICAgbGV0IHZhbHVlID0gdGhpcy5jaGFydFR5cGVbMV0gPT09ICcxMDAnID8gX3lEYXRhLnJlbmRlclZhbCA6IF95RGF0YS52YWx1ZTtcclxuICAgICAgICBsZXQgb2Zmc2V0OiBudW1iZXIgPSB2YWx1ZSA/IDEgOiAwO1xyXG5cclxuICAgICAgICBpZiAoX3R5cGUgPT09ICd4JyB8fCBfdHlwZSA9PT0gJ3knKSB7XHJcbiAgICAgICAgICAgIHJldHVybiB0aGlzLl9pc1N0YXJ0QXRTdW0gPyB0aGlzLnkobmVnYXRpdmVSZWNhbChfeURhdGEuc3VtLCB2YWx1ZSkpIDogdGhpcy55KG5lZ2F0aXZlUmVjYWwoX3lEYXRhLnN1bSwgdmFsdWUpIC0gTWF0aC5hYnModmFsdWUpKTtcclxuICAgICAgICB9XHJcbiAgICAgICAgaWYgKF90eXBlID09PSAnaGVpZ2h0JykgcmV0dXJuIE1hdGguYWJzKHRoaXMueShuZWdhdGl2ZVJlY2FsKF95RGF0YS5zdW0sIHZhbHVlKSAtIHZhbHVlKSAtIHRoaXMueShuZWdhdGl2ZVJlY2FsKF95RGF0YS5zdW0sIHZhbHVlKSkpICsgb2Zmc2V0O1xyXG4gICAgICAgIGlmIChfdHlwZSA9PT0gJ3dpZHRoJykgcmV0dXJuIE1hdGguYWJzKHRoaXMueShuZWdhdGl2ZVJlY2FsKF95RGF0YS5zdW0sIHZhbHVlKSkgLSB0aGlzLnkobmVnYXRpdmVSZWNhbChfeURhdGEuc3VtLCB2YWx1ZSkgLSB2YWx1ZSkpICsgb2Zmc2V0O1xyXG5cclxuICAgICAgICAvLyByZW5kZXJpbmcgcmVjdCBmb3IgbmVnYXRpdmUgdXNlcyB2YWx1ZXMgbGVzc2VyIGJ5IG9uZSBpbmRleC4gZWc6IGZpcnN0IHZhbHVlID0gLTIsIHN1bSA9IC0yLCByZW5kZXJzIDAuLi4uIHNlY29uZCB2YWx1ZSA9IC00LCBzdW0gPSAtNiwgcmVuZGVycyAtMlxyXG4gICAgICAgIGZ1bmN0aW9uIG5lZ2F0aXZlUmVjYWwoX3N1bTogbnVtYmVyLCBfdmFsdWU6IG51bWJlcik6IG51bWJlciB7XHJcbiAgICAgICAgICAgIHJldHVybiBNYXRoLnNpZ24oX3N1bSkgPCAwID8gX3N1bSAtIF92YWx1ZSA6IF9zdW07XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX3NldEJhckNoYXJ0TGFiZWwoX2Q6IElEM0RhdGFEYXRhLCBfeEluZGV4OiBudW1iZXIsIF9ncm91cDogSVJlY3RHcm91cCk6IHZvaWQge1xyXG4gICAgICAgIGZvciAobGV0IHlJbmRleCA9IDA7IHlJbmRleCA8IF9kLnkubGVuZ3RoOyArK3lJbmRleCkge1xyXG4gICAgICAgICAgICBpZiAoX2QueVt5SW5kZXhdLnZhbHVlID09PSBudWxsKSBjb250aW51ZTtcclxuXHJcbiAgICAgICAgICAgIGxldCB5RGF0YTogSUQzWURhdGEgPSBPYmplY3QuYXNzaWduKHt9LCBfZC55W3lJbmRleF0pLFxyXG4gICAgICAgICAgICAgICAgZGltZW5zaW9uczogSUJhclJlY3REaW1lbnNpb25zID0ge1xyXG4gICAgICAgICAgICAgICAgICAgIHlQb3M6IF9ncm91cC55UG9zQXJyW3lJbmRleF0sXHJcbiAgICAgICAgICAgICAgICAgICAgeFBvczogX2dyb3VwLnhQb3NBcnJbeUluZGV4XSxcclxuICAgICAgICAgICAgICAgICAgICBoZWlnaHQ6IHRoaXMuY2hhcnRUeXBlWzBdID09PSAnY29sdW1uJyA/IF9ncm91cC5oZWlnaHRBcnJbeUluZGV4XSA6IF9ncm91cC5oZWlnaHRBcnJbMF0sXHJcbiAgICAgICAgICAgICAgICAgICAgd2lkdGg6IHRoaXMuY2hhcnRUeXBlWzBdID09PSAnY29sdW1uJyA/IF9ncm91cC53aWR0aEFyclswXSA6IF9ncm91cC53aWR0aEFyclt5SW5kZXhdXHJcbiAgICAgICAgICAgICAgICB9O1xyXG5cclxuICAgICAgICAgICAgaWYgKCF0aGlzLmNvbmZpZy5jaGFydC5sYWJlbHMuaW5zaWRlKSB7XHJcbiAgICAgICAgICAgICAgICBpZiAodGhpcy5jaGFydFR5cGVbMF0gPT09ICdjb2x1bW4nKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKCh5RGF0YS52YWx1ZSA8IDAgJiYgIXRoaXMuX2NoYXJ0U3ZjLmlzWVJldmVyc2VkKSB8fCAoeURhdGEudmFsdWUgPiAwICYmIHRoaXMuX2NoYXJ0U3ZjLmlzWVJldmVyc2VkKSkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBkaW1lbnNpb25zLnlQb3MgKz0gX2dyb3VwLmhlaWdodEFyclt5SW5kZXhdO1xyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAvLyB3aGVuIHJ0bCwgZGl2IHN0YXJ0cyBhdCB0b3AgcmlnaHQgb2YgcmVjdFxyXG4gICAgICAgICAgICAgICAgICAgIGlmICh0aGlzLmlzUnRsKSBkaW1lbnNpb25zLnhQb3MgKz0gX2dyb3VwLndpZHRoQXJyWzBdO1xyXG4gICAgICAgICAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgICAgICAgICBpZiAoKHlEYXRhLnZhbHVlID4gMCAmJiAhdGhpcy5fY2hhcnRTdmMuaXNZUmV2ZXJzZWQpIHx8ICh5RGF0YS52YWx1ZSA8IDAgJiYgdGhpcy5fY2hhcnRTdmMuaXNZUmV2ZXJzZWQpKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGRpbWVuc2lvbnMueFBvcyArPSBfZ3JvdXAud2lkdGhBcnJbeUluZGV4XTtcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgICAgICBpZiAodGhpcy5pc1J0bCkge1xyXG4gICAgICAgICAgICAgICAgICAgIC8vIHdoZW4gcnRsLFxyXG4gICAgICAgICAgICAgICAgICAgIC8vIGZvciBDb2x1bW4sIGRpdiBzdGFydHMgYXQgdG9wIHJpZ2h0IG9mIHJlY3RcclxuICAgICAgICAgICAgICAgICAgICAvLyBmb3IgQmFyLCBkaXYgc3RhcnQgYXQgZW5kIG9mIHJlY3QgYW5kIHRha2UgdGhlIHdpZHRoIG9mIGJhcnNcclxuICAgICAgICAgICAgICAgICAgICBsZXQgaW5kZXggPSB0aGlzLmNoYXJ0VHlwZVswXSA9PT0gJ2NvbHVtbicgPyAwIDogeUluZGV4O1xyXG4gICAgICAgICAgICAgICAgICAgIGRpbWVuc2lvbnMueFBvcyArPSBfZ3JvdXAud2lkdGhBcnJbaW5kZXhdO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIGlmICh0aGlzLl9jaGFydFN2Yy5pc05lZ2F0aXZlU3RhY2spIHlEYXRhLnZhbHVlID0gdGhpcy5fY2hhcnRTdmMuY2hlY2tBbmRSZXR1cm5MYWJlbHNQb3NpdGl2ZSh5RGF0YS52YWx1ZSk7XHJcblxyXG4gICAgICAgICAgICBsZXQgbGFiZWxDb250YWluZXI6IGFueSA9IHN1cGVyLnNldExhYmVsKHlEYXRhLCBfeEluZGV4LCBkaW1lbnNpb25zLnhQb3MsIGRpbWVuc2lvbnMueVBvcyk7XHJcblxyXG4gICAgICAgICAgICAvLyB2YWx1ZSBoZXJlIGlzIHJhd1ZhbHVlIChuZWdhdGl2ZVN0YWNrQmFyIG1heSBoYXZlIGNoYW5nZWQgeURhdGEudmFsdWUpXHJcbiAgICAgICAgICAgIHRoaXMuX3NldExhYmVsU3R5bGUobGFiZWxDb250YWluZXIsIF9kLnlbeUluZGV4XS52YWx1ZSwgZGltZW5zaW9ucyk7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIC8vIGZvciBjb2x1bW4sIHdpZHRoIGlzIGNvbnN0YW50LCBoZWlnaHQgaXMgdmFyeVxyXG4gICAgLy8gZm9yIGJhciwgaGVpZ2h0IGlzIGNvbnN0YW50LCB3aWR0aCBpcyB2YXJ5XHJcbiAgICBwcml2YXRlIF9zZXRMYWJlbFN0eWxlKF9sYWJlbENvbnRhaW5lciwgX3ZhbHVlOiBudW1iZXIsIF9kaW1lbnNpb25zOiBJQmFyUmVjdERpbWVuc2lvbnMpOiB2b2lkIHtcclxuICAgICAgICBsZXQgbGFiZWxUZXh0OiBhbnkgPSBfbGFiZWxDb250YWluZXIuc2VsZWN0KCcua2R4LWNoYXJ0cy1kYXRhLWxhYmVsLXRleHQnKTtcclxuICAgICAgICBsZXQgdmVydGljYWxBbGlnbiA9IHRoaXMuY29uZmlnLmNoYXJ0LmxhYmVscy52ZXJ0aWNhbEFsaWduO1xyXG4gICAgICAgIGxldCBpbnNpZGU6IGJvb2xlYW4gPSB0aGlzLmNvbmZpZy5jaGFydC5sYWJlbHMuaW5zaWRlO1xyXG4gICAgICAgIGxldCBzaWduOiBudW1iZXIgPSBNYXRoLnNpZ24oX3ZhbHVlKTtcclxuICAgICAgICBpZiAoIXZlcnRpY2FsQWxpZ24pIHZlcnRpY2FsQWxpZ24gPSB0aGlzLmNoYXJ0VHlwZVswXSA9PT0gJ2NvbHVtbicgPyAndG9wJyA6ICdtaWRkbGUnO1xyXG5cclxuICAgICAgICB0aGlzLl9iYXJTdmMuc2V0TGFiZWxDb250YWluZXJXaWR0aE9ySGVpZ2h0KF9sYWJlbENvbnRhaW5lciwgdGhpcy5jaGFydFR5cGVbMF0sIGluc2lkZSwgX2RpbWVuc2lvbnMpO1xyXG5cclxuICAgICAgICAvLyBpZiBsYWJlbCBpcyBoaWdoZXIgdGhhbiBiYXIncy9jb2x1bW4ncyBoZWlnaHRcclxuICAgICAgICBsZXQgaXNMYWJlbEhpZ2hlclRoYW5SZWN0ID0gdGhpcy5fY2hhcnRTdmMuX2dldExhYmVsVGV4dEhlaWdodCgpID4gX2RpbWVuc2lvbnMuaGVpZ2h0O1xyXG4gICAgICAgIGlmIChpc0xhYmVsSGlnaGVyVGhhblJlY3QpIHtcclxuICAgICAgICAgICAgaWYgKHRoaXMuY2hhcnRUeXBlWzBdID09PSAnYmFyJykge1xyXG4gICAgICAgICAgICAgICAgdmVydGljYWxBbGlnbiA9ICdtaWRkbGUnO1xyXG4gICAgICAgICAgICB9IGVsc2UgaWYgKGluc2lkZSkge1xyXG4gICAgICAgICAgICAgICAgLy8gaWYgY29sdW1uIGFuZCBpbnNpZGUsIHRvIG1ha2Ugc3VyZSBsYWJlbCB3aWxsIG5vdCBoaXQgaW50byBheGlzLFxyXG4gICAgICAgICAgICAgICAgLy8gaWYgYXhpcyBpcyBhdCBib3R0b20gb2YgY2hhcnQsIHNldCB0byBmbGV4LWVuZCBzbyB0aGF0IHRleHQgd2lsbCBiZSBwbGFjZWQgYWJvdmVcclxuICAgICAgICAgICAgICAgIC8vIGlmIGF4aXMgaXMgYXQgdG9wIG9mIGNoYXJ0LCBzZXQgdG8gZmxleC1zdGFydCBzbyB0aGF0IHRleHQgd2lsbCBiZSBwbGFjZWQgYmVsb3dcclxuICAgICAgICAgICAgICAgIHZlcnRpY2FsQWxpZ24gPSB0aGlzLl9jaGFydFN2Yy5pc1lSZXZlcnNlZCA/ICd0b3AnIDogJ2JvdHRvbSc7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIGlmICghaW5zaWRlKSB7XHJcbiAgICAgICAgICAgIGlmICh0aGlzLmNoYXJ0VHlwZVswXSA9PT0gJ2JhcicpIHtcclxuICAgICAgICAgICAgICAgIHRoaXMuX2JhclN2Yy5fc2V0TGFiZWxUZXh0UG9zSG9yaXpvbnRhbChcclxuICAgICAgICAgICAgICAgICAgICBsYWJlbFRleHQsXHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5fY2hhcnRTdmMuaXNZUmV2ZXJzZWQsXHJcbiAgICAgICAgICAgICAgICAgICAgeyB4UG9zOiBfZGltZW5zaW9ucy54UG9zLCBjaGFydFdpZHRoOiB0aGlzLndpZHRoLCB2YWx1ZVNpZ246IHNpZ24gfVxyXG4gICAgICAgICAgICAgICAgKTtcclxuICAgICAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgICAgIGxldCBwYXJhbXMgPSB7IHZhbHVlU2lnbjogc2lnbiB9O1xyXG4gICAgICAgICAgICAgICAgbGV0IHlQb3MgPSBfZGltZW5zaW9ucy55UG9zOyAvLyB1c2VkIGZvciBib3VuZGFyeSBjaGVja2luZy5cclxuICAgICAgICAgICAgICAgIGlmIChpc0xhYmVsSGlnaGVyVGhhblJlY3QgJiYgdGhpcy5jaGFydFR5cGVbMV0gPT09ICdjbHVzdGVyJykge1xyXG4gICAgICAgICAgICAgICAgICAgIHBhcmFtc1snZGltZW5zaW9ucyddID0gX2RpbWVuc2lvbnM7XHJcbiAgICAgICAgICAgICAgICAgICAgbGV0IG5lZWRPZmZzZXQ6IGFueSA9IHRoaXMuX2NoYXJ0U3ZjLm5lZWRPZmZzZXRGb3JDb2x1bW4odmVydGljYWxBbGlnbiwgcGFyYW1zKTtcclxuICAgICAgICAgICAgICAgICAgICBpZiAobmVlZE9mZnNldCkgeVBvcyArPSBuZWVkT2Zmc2V0ICogX2RpbWVuc2lvbnMuaGVpZ2h0O1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgc3VwZXIuc2V0TGFiZWxUZXh0UG9zaXRpb24obGFiZWxUZXh0LCB5UG9zLCBwYXJhbXMpO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG5cclxuXHJcbiAgICAgICAgdGhpcy5fYmFyU3ZjLnNldFZlcnRpY2FsQWxpZ25DU1MoX2xhYmVsQ29udGFpbmVyLCB2ZXJ0aWNhbEFsaWduKTtcclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF9kaXNwbGF5QWxsTGFiZWwoKTogdm9pZCB7XHJcbiAgICAgICAgdGhpcy5kYXRhTGFiZWxDb250YWluZXJcclxuICAgICAgICAgICAgLnNlbGVjdEFsbCgnLmtkeC1jaGFydHMtZGF0YS1sYWJlbCcpXHJcbiAgICAgICAgICAgIC5zdHlsZSgndmlzaWJpbGl0eScsICd2aXNpYmxlJyk7XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfZ2V0UmVjdFBvc0luZm8oKTogSVJlY3RQb3NJbmZvIHtcclxuICAgICAgICBpZiAodGhpcy5jaGFydFR5cGVbMV0gPT09ICdjbHVzdGVyJykge1xyXG4gICAgICAgICAgICAvLyB0aGUgYW1vdW50IG9mIHlEYXRhIGZvciBlYWNoIHggdmFsdWUgd2lsbCBhbHdheXMgYmUgdGhlIHNhbWUgKGlmIHdlIGRvbid0IHJlbW92ZSBudWxsIHZhbHVlcylcclxuICAgICAgICAgICAgLy8gaGVuY2UgdGhpcyBjYWxjdWxhdGlvbiBvbmx5IG5lZWRzIHRvIHJ1biBvbmNlXHJcbiAgICAgICAgICAgIGxldCB5QXJyTGVuZ3RoID0gdGhpcy5kYXRhWzBdICYmIHRoaXMuZGF0YVswXS55ID8gdGhpcy5kYXRhWzBdLnkubGVuZ3RoIDogMDtcclxuICAgICAgICAgICAgcmV0dXJuIHRoaXMuX2JhclN2Yy5nZXRSZWN0V2lkdGgodGhpcy54LmJhbmR3aWR0aCgpLCB0aGlzLmJhci5jbHVzdGVyUGFkZGluZ1BlcmNlbnQsIHlBcnJMZW5ndGgpO1xyXG4gICAgICAgIH1cclxuICAgICAgICByZXR1cm4ge1xyXG4gICAgICAgICAgICB3aWR0aDogdGhpcy54LmJhbmR3aWR0aCgpLFxyXG4gICAgICAgICAgICBwYWRkaW5nOiAwXHJcbiAgICAgICAgfTtcclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIG5lZ2F0aXZlU3RhY2tTeW1tZXRyeUxvZ2ljKCk6IHZvaWQge1xyXG4gICAgICAgIGxldCByZXN1bHQ6IElOZWdhdGl2ZVN0YWNrTG9naWNSZXR1cm4gPSB0aGlzLl9iYXJTdmMuYXBwbHlTeW1tZXRyaWNBeGlzKHRoaXMuZGF0YVJhbmdlLCB0aGlzLmNvbmZpZy5wbG90T3B0aW9ucywgdGhpcy5jb25maWcueUF4aXMpO1xyXG4gICAgICAgIGlmIChyZXN1bHQuaGFzT3duUHJvcGVydHkoJ2RhdGFSYW5nZScpKSB0aGlzLmRhdGFSYW5nZSA9IHJlc3VsdC5kYXRhUmFuZ2U7XHJcbiAgICAgICAgaWYgKHJlc3VsdC5oYXNPd25Qcm9wZXJ0eSgneUF4aXMnKSkge1xyXG4gICAgICAgICAgICB0aGlzLmNvbmZpZy55QXhpcyA9IE9iamVjdC5hc3NpZ24oe30sIHRoaXMuY29uZmlnLnlBeGlzLCByZXN1bHQueUF4aXMpO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxufVxyXG4iXX0=