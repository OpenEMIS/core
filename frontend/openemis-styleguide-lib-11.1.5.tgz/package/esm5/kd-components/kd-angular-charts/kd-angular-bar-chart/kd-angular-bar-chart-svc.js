import { __decorate } from "tslib";
import { Injectable } from '@angular/core';
var KdBarChartSvc = /** @class */ (function () {
    function KdBarChartSvc() {
        this._allowedPaddingValue = 5;
        this._verticalAlignStore = {
            'top': 'flex-start',
            'bottom': 'flex-end',
            'middle': 'center'
        };
    }
    Object.defineProperty(KdBarChartSvc.prototype, "originalDataRange", {
        set: function (_originalDataRange) { this._originalDataRange = _originalDataRange; },
        enumerable: true,
        configurable: true
    });
    // ================================= Negative Stack Symmetry only ==================================
    KdBarChartSvc.prototype.applySymmetricAxis = function (_dataRange, _plotOptions, _yAxisConfig) {
        if (this._isSymmetric(_plotOptions)) {
            var absMax = this._getAbsoluteValue(_yAxisConfig.maxValue, this._originalDataRange.max);
            var absMin = this._getAbsoluteValue(_yAxisConfig.minValue, this._originalDataRange.min);
            return this._setDataRangeToSymmetric({ max: absMax, min: absMin }, _yAxisConfig);
        }
        else {
            return {
                dataRange: this._isValueExist(this._originalDataRange) ? this._originalDataRange : _dataRange
            };
        }
    };
    KdBarChartSvc.prototype._getAbsoluteValue = function (_userValue, _dataValue) {
        var valueToUse = this._isValueExist(_userValue) ? _userValue : _dataValue;
        return Math.abs(valueToUse);
    };
    // for negative stack bar/column, make chart symmetrical about 0
    KdBarChartSvc.prototype._setDataRangeToSymmetric = function (_dataRange, _yAxisConfig) {
        var result = {
            dataRange: Object.assign({}, _dataRange),
            yAxis: {}
        };
        var largestValue = Math.max(Math.abs(result.dataRange.min), Math.abs(result.dataRange.max));
        result.dataRange['min'] = largestValue * -1;
        result.dataRange['max'] = largestValue;
        result.yAxis['minValue'] = largestValue * -1;
        result.yAxis['maxValue'] = largestValue;
        if (_dataRange.max > _dataRange.min) {
            result.yAxis['autoRoundToMin'] = _yAxisConfig.autoRoundToMax;
        }
        else {
            result.yAxis['autoRoundToMax'] = _yAxisConfig.autoRoundToMin;
        }
        return result;
    };
    KdBarChartSvc.prototype._isSymmetric = function (_plotOptions) {
        var isSymmetric = false;
        if (_plotOptions && _plotOptions.bar && typeof _plotOptions.bar.isSymmetric !== 'undefined') {
            isSymmetric = _plotOptions.bar.isSymmetric;
        }
        return isSymmetric;
    };
    // ================================== Label For Bar/Column =========================================
    // type: 'column' | 'bar'
    KdBarChartSvc.prototype.setLabelContainerWidthOrHeight = function (_container, _type, _inside, _dimensions) {
        if (_type === 'column') {
            _container.style('width', _dimensions.width + 'px');
            if (_inside)
                _container.style('height', _dimensions.height + 'px');
        }
        else {
            _container.style('height', _dimensions.height + 'px');
            if (_inside)
                _container.style('width', _dimensions.width + 'px');
        }
        _container.style('justify-content', 'center');
    };
    KdBarChartSvc.prototype._setLabelTextPosHorizontal = function (_labelText, _isYReversed, _params) {
        var haveTransform = _isYReversed !== (document.dir === 'rtl');
        var sign = document.dir === 'rtl' ? '' : '-';
        if (_params.valueSign < 0)
            haveTransform = !haveTransform;
        if (this._isLabelOutside(_labelText, _isYReversed, _params))
            haveTransform = !haveTransform;
        if (haveTransform) {
            _labelText.style('transform', 'translateX(calc(' + sign + '100%))');
        }
    };
    KdBarChartSvc.prototype._isLabelOutside = function (_labelText, _isYReversed, _params) {
        var posDataLabelStarts = _isYReversed ? _params.chartWidth - _params.xPos : _params.xPos;
        var labelDimension = _labelText.node().getBoundingClientRect();
        if (_params.valueSign < 0) {
            return posDataLabelStarts - labelDimension.width < 0;
        }
        else {
            return posDataLabelStarts + labelDimension.width > _params.chartWidth;
        }
    };
    /**
     * used for labels.inside is true. which will change the height of the label div containers
     * then vertically align using flex and align-items
     * param {[type]}                         _labels [Element]
     * param {'top' | 'middle' | 'bottom'}    _verticalAlign
     */
    KdBarChartSvc.prototype.setVerticalAlignCSS = function (_labels, _verticalAlign) {
        var key = _verticalAlign || 'middle';
        var value = this._verticalAlignStore[key];
        _labels.style('align-items', value);
    };
    // ================================= Rect calculation ==================================================
    /**
     * calculates the width of each rect and padding(only applicable to bar-cluster) between each rect in a cluster.
     * param {number} _totalWidth
     * param {number} _paddingPercent percentage of totalWidth allowed for total sum of all padding
     * param {number} _noOfRect
     */
    KdBarChartSvc.prototype.getRectWidth = function (_totalWidth, _paddingPercent, _noOfRect) {
        // calculated each bar's padding by dividing a percentage of the totalWidth
        var eachPaddingWidth = _totalWidth * _paddingPercent / (_noOfRect - 1);
        // each padding should not exceed this._allowedPaddingValue
        var paddingValue = Math.min(this._allowedPaddingValue, eachPaddingWidth);
        return {
            width: (_totalWidth - paddingValue * (_noOfRect - 1)) / _noOfRect,
            padding: paddingValue
        };
    };
    // ================================= General ==================================================
    KdBarChartSvc.prototype._isValueExist = function (_value) {
        return _value !== null && _value !== undefined;
    };
    KdBarChartSvc = __decorate([
        Injectable()
    ], KdBarChartSvc);
    return KdBarChartSvc;
}());
export { KdBarChartSvc };
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoia2QtYW5ndWxhci1iYXItY2hhcnQtc3ZjLmpzIiwic291cmNlUm9vdCI6Im5nOi8vb3BlbmVtaXMtc3R5bGVndWlkZS1saWIvIiwic291cmNlcyI6WyJrZC1jb21wb25lbnRzL2tkLWFuZ3VsYXItY2hhcnRzL2tkLWFuZ3VsYXItYmFyLWNoYXJ0L2tkLWFuZ3VsYXItYmFyLWNoYXJ0LXN2Yy50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiO0FBQUEsT0FBTyxFQUFFLFVBQVUsRUFBRSxNQUFNLGVBQWUsQ0FBQztBQWUzQztJQUFBO1FBRVkseUJBQW9CLEdBQVcsQ0FBQyxDQUFDO1FBR2pDLHdCQUFtQixHQUF3QjtZQUMvQyxLQUFLLEVBQUUsWUFBWTtZQUNuQixRQUFRLEVBQUUsVUFBVTtZQUNwQixRQUFRLEVBQUUsUUFBUTtTQUNyQixDQUFDO0lBNEhOLENBQUM7SUExSEcsc0JBQUksNENBQWlCO2FBQXJCLFVBQXNCLGtCQUFrQixJQUFJLElBQUksQ0FBQyxrQkFBa0IsR0FBRyxrQkFBa0IsQ0FBQyxDQUFDLENBQUM7OztPQUFBO0lBRTNGLG9HQUFvRztJQUU3RiwwQ0FBa0IsR0FBekIsVUFBMEIsVUFBd0IsRUFBRSxZQUEwQixFQUFFLFlBQTBCO1FBQ3RHLElBQUksSUFBSSxDQUFDLFlBQVksQ0FBQyxZQUFZLENBQUMsRUFBRTtZQUNqQyxJQUFJLE1BQU0sR0FBVyxJQUFJLENBQUMsaUJBQWlCLENBQUMsWUFBWSxDQUFDLFFBQVEsRUFBRSxJQUFJLENBQUMsa0JBQWtCLENBQUMsR0FBRyxDQUFDLENBQUM7WUFDaEcsSUFBSSxNQUFNLEdBQVcsSUFBSSxDQUFDLGlCQUFpQixDQUFDLFlBQVksQ0FBQyxRQUFRLEVBQUUsSUFBSSxDQUFDLGtCQUFrQixDQUFDLEdBQUcsQ0FBQyxDQUFDO1lBQ2hHLE9BQU8sSUFBSSxDQUFDLHdCQUF3QixDQUFDLEVBQUUsR0FBRyxFQUFFLE1BQU0sRUFBRSxHQUFHLEVBQUUsTUFBTSxFQUFFLEVBQUUsWUFBWSxDQUFDLENBQUM7U0FDcEY7YUFBTTtZQUNILE9BQU87Z0JBQ0gsU0FBUyxFQUFFLElBQUksQ0FBQyxhQUFhLENBQUMsSUFBSSxDQUFDLGtCQUFrQixDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxDQUFDLENBQUMsVUFBVTthQUNoRyxDQUFDO1NBQ0w7SUFDTCxDQUFDO0lBRU8seUNBQWlCLEdBQXpCLFVBQTBCLFVBQXlCLEVBQUUsVUFBa0I7UUFDbkUsSUFBSSxVQUFVLEdBQVcsSUFBSSxDQUFDLGFBQWEsQ0FBQyxVQUFVLENBQUMsQ0FBQyxDQUFDLENBQUMsVUFBVSxDQUFBLENBQUMsQ0FBQyxVQUFVLENBQUM7UUFDakYsT0FBTyxJQUFJLENBQUMsR0FBRyxDQUFDLFVBQVUsQ0FBQyxDQUFDO0lBQ2hDLENBQUM7SUFFRCxnRUFBZ0U7SUFDeEQsZ0RBQXdCLEdBQWhDLFVBQWlDLFVBQXdCLEVBQUUsWUFBMEI7UUFDakYsSUFBSSxNQUFNLEdBQThCO1lBQ3BDLFNBQVMsRUFBRSxNQUFNLENBQUMsTUFBTSxDQUFDLEVBQUUsRUFBRSxVQUFVLENBQUM7WUFDeEMsS0FBSyxFQUFFLEVBQUU7U0FDWixDQUFDO1FBRUYsSUFBSSxZQUFZLEdBQVcsSUFBSSxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLE1BQU0sQ0FBQyxTQUFTLENBQUMsR0FBRyxDQUFDLEVBQUUsSUFBSSxDQUFDLEdBQUcsQ0FBQyxNQUFNLENBQUMsU0FBUyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUM7UUFDcEcsTUFBTSxDQUFDLFNBQVMsQ0FBQyxLQUFLLENBQUMsR0FBRyxZQUFZLEdBQUcsQ0FBQyxDQUFDLENBQUM7UUFDNUMsTUFBTSxDQUFDLFNBQVMsQ0FBQyxLQUFLLENBQUMsR0FBRyxZQUFZLENBQUM7UUFFdkMsTUFBTSxDQUFDLEtBQUssQ0FBQyxVQUFVLENBQUMsR0FBRyxZQUFZLEdBQUcsQ0FBQyxDQUFDLENBQUM7UUFDN0MsTUFBTSxDQUFDLEtBQUssQ0FBQyxVQUFVLENBQUMsR0FBRyxZQUFZLENBQUM7UUFFeEMsSUFBSSxVQUFVLENBQUMsR0FBRyxHQUFHLFVBQVUsQ0FBQyxHQUFHLEVBQUU7WUFDakMsTUFBTSxDQUFDLEtBQUssQ0FBQyxnQkFBZ0IsQ0FBQyxHQUFHLFlBQVksQ0FBQyxjQUFjLENBQUM7U0FDaEU7YUFBTTtZQUNILE1BQU0sQ0FBQyxLQUFLLENBQUMsZ0JBQWdCLENBQUMsR0FBRyxZQUFZLENBQUMsY0FBYyxDQUFDO1NBQ2hFO1FBRUQsT0FBTyxNQUFNLENBQUM7SUFDbEIsQ0FBQztJQUVPLG9DQUFZLEdBQXBCLFVBQXFCLFlBQTBCO1FBQzNDLElBQUksV0FBVyxHQUFZLEtBQUssQ0FBQztRQUNqQyxJQUFJLFlBQVksSUFBSSxZQUFZLENBQUMsR0FBRyxJQUFJLE9BQU8sWUFBWSxDQUFDLEdBQUcsQ0FBQyxXQUFXLEtBQUssV0FBVyxFQUFFO1lBQ3pGLFdBQVcsR0FBRyxZQUFZLENBQUMsR0FBRyxDQUFDLFdBQVcsQ0FBQztTQUM5QztRQUNELE9BQU8sV0FBVyxDQUFDO0lBQ3ZCLENBQUM7SUFFRCxvR0FBb0c7SUFFcEcseUJBQXlCO0lBQ2xCLHNEQUE4QixHQUFyQyxVQUFzQyxVQUFVLEVBQUUsS0FBYSxFQUFFLE9BQWdCLEVBQUUsV0FBK0I7UUFDOUcsSUFBSSxLQUFLLEtBQUssUUFBUSxFQUFFO1lBQ3BCLFVBQVUsQ0FBQyxLQUFLLENBQUMsT0FBTyxFQUFFLFdBQVcsQ0FBQyxLQUFLLEdBQUcsSUFBSSxDQUFDLENBQUM7WUFDcEQsSUFBSSxPQUFPO2dCQUFFLFVBQVUsQ0FBQyxLQUFLLENBQUMsUUFBUSxFQUFFLFdBQVcsQ0FBQyxNQUFNLEdBQUcsSUFBSSxDQUFDLENBQUM7U0FDdEU7YUFBTTtZQUNILFVBQVUsQ0FBQyxLQUFLLENBQUMsUUFBUSxFQUFFLFdBQVcsQ0FBQyxNQUFNLEdBQUcsSUFBSSxDQUFDLENBQUM7WUFDdEQsSUFBSSxPQUFPO2dCQUFFLFVBQVUsQ0FBQyxLQUFLLENBQUMsT0FBTyxFQUFFLFdBQVcsQ0FBQyxLQUFLLEdBQUcsSUFBSSxDQUFDLENBQUM7U0FDcEU7UUFFRCxVQUFVLENBQUMsS0FBSyxDQUFDLGlCQUFpQixFQUFFLFFBQVEsQ0FBQyxDQUFDO0lBQ2xELENBQUM7SUFFTSxrREFBMEIsR0FBakMsVUFBa0MsVUFBVSxFQUFFLFlBQXFCLEVBQUUsT0FBc0M7UUFDdkcsSUFBSSxhQUFhLEdBQVksWUFBWSxLQUFLLENBQUMsUUFBUSxDQUFDLEdBQUcsS0FBSyxLQUFLLENBQUMsQ0FBQztRQUN2RSxJQUFJLElBQUksR0FBVyxRQUFRLENBQUMsR0FBRyxLQUFLLEtBQUssQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUM7UUFDckQsSUFBSSxPQUFPLENBQUMsU0FBUyxHQUFHLENBQUM7WUFBRSxhQUFhLEdBQUcsQ0FBQyxhQUFhLENBQUM7UUFDMUQsSUFBSSxJQUFJLENBQUMsZUFBZSxDQUFDLFVBQVUsRUFBRSxZQUFZLEVBQUUsT0FBTyxDQUFDO1lBQUUsYUFBYSxHQUFHLENBQUMsYUFBYSxDQUFDO1FBQzVGLElBQUksYUFBYSxFQUFFO1lBQ2YsVUFBVSxDQUFDLEtBQUssQ0FBQyxXQUFXLEVBQUUsa0JBQWtCLEdBQUcsSUFBSSxHQUFHLFFBQVEsQ0FBQyxDQUFDO1NBQ3ZFO0lBQ0wsQ0FBQztJQUVPLHVDQUFlLEdBQXZCLFVBQXdCLFVBQVUsRUFBRSxZQUFxQixFQUFFLE9BQXNDO1FBQzdGLElBQUksa0JBQWtCLEdBQVcsWUFBWSxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsVUFBVSxHQUFHLE9BQU8sQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUM7UUFDakcsSUFBSSxjQUFjLEdBQVEsVUFBVSxDQUFDLElBQUksRUFBRSxDQUFDLHFCQUFxQixFQUFFLENBQUM7UUFDcEUsSUFBSSxPQUFPLENBQUMsU0FBUyxHQUFHLENBQUMsRUFBRTtZQUN2QixPQUFPLGtCQUFrQixHQUFHLGNBQWMsQ0FBQyxLQUFLLEdBQUcsQ0FBQyxDQUFDO1NBQ3hEO2FBQU07WUFDSCxPQUFPLGtCQUFrQixHQUFHLGNBQWMsQ0FBQyxLQUFLLEdBQUcsT0FBTyxDQUFDLFVBQVUsQ0FBQztTQUN6RTtJQUNMLENBQUM7SUFFRDs7Ozs7T0FLRztJQUNJLDJDQUFtQixHQUExQixVQUEyQixPQUFPLEVBQUUsY0FBMkM7UUFDM0UsSUFBSSxHQUFHLEdBQUcsY0FBYyxJQUFJLFFBQVEsQ0FBQztRQUNyQyxJQUFJLEtBQUssR0FBRyxJQUFJLENBQUMsbUJBQW1CLENBQUMsR0FBRyxDQUFDLENBQUM7UUFDMUMsT0FBTyxDQUFDLEtBQUssQ0FBQyxhQUFhLEVBQUUsS0FBSyxDQUFDLENBQUM7SUFDeEMsQ0FBQztJQUVELHdHQUF3RztJQUV4Rzs7Ozs7T0FLRztJQUNJLG9DQUFZLEdBQW5CLFVBQW9CLFdBQW1CLEVBQUUsZUFBdUIsRUFBRSxTQUFpQjtRQUMvRSwyRUFBMkU7UUFDM0UsSUFBSSxnQkFBZ0IsR0FBRyxXQUFXLEdBQUcsZUFBZSxHQUFHLENBQUMsU0FBUyxHQUFHLENBQUMsQ0FBQyxDQUFDO1FBQ3ZFLDJEQUEyRDtRQUMzRCxJQUFJLFlBQVksR0FBRyxJQUFJLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxvQkFBb0IsRUFBRSxnQkFBZ0IsQ0FBQyxDQUFDO1FBQ3pFLE9BQU87WUFDSCxLQUFLLEVBQUUsQ0FBQyxXQUFXLEdBQUcsWUFBWSxHQUFHLENBQUMsU0FBUyxHQUFHLENBQUMsQ0FBQyxDQUFDLEdBQUcsU0FBUztZQUNqRSxPQUFPLEVBQUUsWUFBWTtTQUN4QixDQUFDO0lBQ04sQ0FBQztJQUVELCtGQUErRjtJQUN2RixxQ0FBYSxHQUFyQixVQUFzQixNQUFXO1FBQzdCLE9BQU8sTUFBTSxLQUFLLElBQUksSUFBSSxNQUFNLEtBQUssU0FBUyxDQUFDO0lBQ25ELENBQUM7SUFwSVEsYUFBYTtRQUR6QixVQUFVLEVBQUU7T0FDQSxhQUFhLENBcUl6QjtJQUFELG9CQUFDO0NBQUEsQUFySUQsSUFxSUM7U0FySVksYUFBYSIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IEluamVjdGFibGUgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcclxuaW1wb3J0IHtcclxuICAgIElQbG90T3B0aW9ucyxcclxuICAgIElEM0RhdGFSYW5nZSxcclxuICAgIElZQXhpc0NvbmZpZyxcclxuICAgIElZQXhpc0JvdW5kYXJ5Q29uZmlnXHJcbn0gZnJvbSAnLi4va2QtYW5ndWxhci1jaGFydHMtaW50ZXJmYWNlJztcclxuaW1wb3J0IHtcclxuICAgIElWZXJ0aWNhbEFsaWduU3RvcmUsXHJcbiAgICBJQmFyUmVjdERpbWVuc2lvbnMsXHJcbiAgICBJTGFiZWxUZXh0UG9zSG9yaXpvbnRhbFBhcmFtcyxcclxuICAgIElOZWdhdGl2ZVN0YWNrTG9naWNSZXR1cm5cclxufSBmcm9tICcuL2tkLWFuZ3VsYXItYmFyLWNoYXJ0LWludGVyZmFjZSc7XHJcblxyXG5ASW5qZWN0YWJsZSgpXHJcbmV4cG9ydCBjbGFzcyBLZEJhckNoYXJ0U3ZjIHtcclxuXHJcbiAgICBwcml2YXRlIF9hbGxvd2VkUGFkZGluZ1ZhbHVlOiBudW1iZXIgPSA1O1xyXG4gICAgcHJpdmF0ZSBfb3JpZ2luYWxEYXRhUmFuZ2U6IElEM0RhdGFSYW5nZTtcclxuXHJcbiAgICBwcml2YXRlIF92ZXJ0aWNhbEFsaWduU3RvcmU6IElWZXJ0aWNhbEFsaWduU3RvcmUgPSB7XHJcbiAgICAgICAgJ3RvcCc6ICdmbGV4LXN0YXJ0JyxcclxuICAgICAgICAnYm90dG9tJzogJ2ZsZXgtZW5kJyxcclxuICAgICAgICAnbWlkZGxlJzogJ2NlbnRlcidcclxuICAgIH07XHJcblxyXG4gICAgc2V0IG9yaWdpbmFsRGF0YVJhbmdlKF9vcmlnaW5hbERhdGFSYW5nZSkgeyB0aGlzLl9vcmlnaW5hbERhdGFSYW5nZSA9IF9vcmlnaW5hbERhdGFSYW5nZTsgfVxyXG5cclxuICAgIC8vID09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PSBOZWdhdGl2ZSBTdGFjayBTeW1tZXRyeSBvbmx5ID09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT1cclxuXHJcbiAgICBwdWJsaWMgYXBwbHlTeW1tZXRyaWNBeGlzKF9kYXRhUmFuZ2U6IElEM0RhdGFSYW5nZSwgX3Bsb3RPcHRpb25zOiBJUGxvdE9wdGlvbnMsIF95QXhpc0NvbmZpZzogSVlBeGlzQ29uZmlnKTogSU5lZ2F0aXZlU3RhY2tMb2dpY1JldHVybiB7XHJcbiAgICAgICAgaWYgKHRoaXMuX2lzU3ltbWV0cmljKF9wbG90T3B0aW9ucykpIHtcclxuICAgICAgICAgICAgbGV0IGFic01heDogbnVtYmVyID0gdGhpcy5fZ2V0QWJzb2x1dGVWYWx1ZShfeUF4aXNDb25maWcubWF4VmFsdWUsIHRoaXMuX29yaWdpbmFsRGF0YVJhbmdlLm1heCk7XHJcbiAgICAgICAgICAgIGxldCBhYnNNaW46IG51bWJlciA9IHRoaXMuX2dldEFic29sdXRlVmFsdWUoX3lBeGlzQ29uZmlnLm1pblZhbHVlLCB0aGlzLl9vcmlnaW5hbERhdGFSYW5nZS5taW4pO1xyXG4gICAgICAgICAgICByZXR1cm4gdGhpcy5fc2V0RGF0YVJhbmdlVG9TeW1tZXRyaWMoeyBtYXg6IGFic01heCwgbWluOiBhYnNNaW4gfSwgX3lBeGlzQ29uZmlnKTtcclxuICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICByZXR1cm4ge1xyXG4gICAgICAgICAgICAgICAgZGF0YVJhbmdlOiB0aGlzLl9pc1ZhbHVlRXhpc3QodGhpcy5fb3JpZ2luYWxEYXRhUmFuZ2UpID8gdGhpcy5fb3JpZ2luYWxEYXRhUmFuZ2UgOiBfZGF0YVJhbmdlXHJcbiAgICAgICAgICAgIH07XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX2dldEFic29sdXRlVmFsdWUoX3VzZXJWYWx1ZTogbnVtYmVyIHwgbnVsbCwgX2RhdGFWYWx1ZTogbnVtYmVyKTogbnVtYmVyIHtcclxuICAgICAgICBsZXQgdmFsdWVUb1VzZTogbnVtYmVyID0gdGhpcy5faXNWYWx1ZUV4aXN0KF91c2VyVmFsdWUpID8gX3VzZXJWYWx1ZTogX2RhdGFWYWx1ZTtcclxuICAgICAgICByZXR1cm4gTWF0aC5hYnModmFsdWVUb1VzZSk7XHJcbiAgICB9XHJcblxyXG4gICAgLy8gZm9yIG5lZ2F0aXZlIHN0YWNrIGJhci9jb2x1bW4sIG1ha2UgY2hhcnQgc3ltbWV0cmljYWwgYWJvdXQgMFxyXG4gICAgcHJpdmF0ZSBfc2V0RGF0YVJhbmdlVG9TeW1tZXRyaWMoX2RhdGFSYW5nZTogSUQzRGF0YVJhbmdlLCBfeUF4aXNDb25maWc6IElZQXhpc0NvbmZpZyk6IElOZWdhdGl2ZVN0YWNrTG9naWNSZXR1cm4ge1xyXG4gICAgICAgIGxldCByZXN1bHQ6IElOZWdhdGl2ZVN0YWNrTG9naWNSZXR1cm4gPSB7XHJcbiAgICAgICAgICAgIGRhdGFSYW5nZTogT2JqZWN0LmFzc2lnbih7fSwgX2RhdGFSYW5nZSksXHJcbiAgICAgICAgICAgIHlBeGlzOiB7fVxyXG4gICAgICAgIH07XHJcblxyXG4gICAgICAgIGxldCBsYXJnZXN0VmFsdWU6IG51bWJlciA9IE1hdGgubWF4KE1hdGguYWJzKHJlc3VsdC5kYXRhUmFuZ2UubWluKSwgTWF0aC5hYnMocmVzdWx0LmRhdGFSYW5nZS5tYXgpKTtcclxuICAgICAgICByZXN1bHQuZGF0YVJhbmdlWydtaW4nXSA9IGxhcmdlc3RWYWx1ZSAqIC0xO1xyXG4gICAgICAgIHJlc3VsdC5kYXRhUmFuZ2VbJ21heCddID0gbGFyZ2VzdFZhbHVlO1xyXG5cclxuICAgICAgICByZXN1bHQueUF4aXNbJ21pblZhbHVlJ10gPSBsYXJnZXN0VmFsdWUgKiAtMTtcclxuICAgICAgICByZXN1bHQueUF4aXNbJ21heFZhbHVlJ10gPSBsYXJnZXN0VmFsdWU7XHJcblxyXG4gICAgICAgIGlmIChfZGF0YVJhbmdlLm1heCA+IF9kYXRhUmFuZ2UubWluKSB7XHJcbiAgICAgICAgICAgIHJlc3VsdC55QXhpc1snYXV0b1JvdW5kVG9NaW4nXSA9IF95QXhpc0NvbmZpZy5hdXRvUm91bmRUb01heDtcclxuICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICByZXN1bHQueUF4aXNbJ2F1dG9Sb3VuZFRvTWF4J10gPSBfeUF4aXNDb25maWcuYXV0b1JvdW5kVG9NaW47XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICByZXR1cm4gcmVzdWx0O1xyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX2lzU3ltbWV0cmljKF9wbG90T3B0aW9uczogSVBsb3RPcHRpb25zKTogYm9vbGVhbiB7XHJcbiAgICAgICAgbGV0IGlzU3ltbWV0cmljOiBib29sZWFuID0gZmFsc2U7XHJcbiAgICAgICAgaWYgKF9wbG90T3B0aW9ucyAmJiBfcGxvdE9wdGlvbnMuYmFyICYmIHR5cGVvZiBfcGxvdE9wdGlvbnMuYmFyLmlzU3ltbWV0cmljICE9PSAndW5kZWZpbmVkJykge1xyXG4gICAgICAgICAgICBpc1N5bW1ldHJpYyA9IF9wbG90T3B0aW9ucy5iYXIuaXNTeW1tZXRyaWM7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIHJldHVybiBpc1N5bW1ldHJpYztcclxuICAgIH1cclxuXHJcbiAgICAvLyA9PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09IExhYmVsIEZvciBCYXIvQ29sdW1uID09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09XHJcblxyXG4gICAgLy8gdHlwZTogJ2NvbHVtbicgfCAnYmFyJ1xyXG4gICAgcHVibGljIHNldExhYmVsQ29udGFpbmVyV2lkdGhPckhlaWdodChfY29udGFpbmVyLCBfdHlwZTogc3RyaW5nLCBfaW5zaWRlOiBib29sZWFuLCBfZGltZW5zaW9uczogSUJhclJlY3REaW1lbnNpb25zKTogdm9pZCB7XHJcbiAgICAgICAgaWYgKF90eXBlID09PSAnY29sdW1uJykge1xyXG4gICAgICAgICAgICBfY29udGFpbmVyLnN0eWxlKCd3aWR0aCcsIF9kaW1lbnNpb25zLndpZHRoICsgJ3B4Jyk7XHJcbiAgICAgICAgICAgIGlmIChfaW5zaWRlKSBfY29udGFpbmVyLnN0eWxlKCdoZWlnaHQnLCBfZGltZW5zaW9ucy5oZWlnaHQgKyAncHgnKTtcclxuICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICBfY29udGFpbmVyLnN0eWxlKCdoZWlnaHQnLCBfZGltZW5zaW9ucy5oZWlnaHQgKyAncHgnKTtcclxuICAgICAgICAgICAgaWYgKF9pbnNpZGUpIF9jb250YWluZXIuc3R5bGUoJ3dpZHRoJywgX2RpbWVuc2lvbnMud2lkdGggKyAncHgnKTtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIF9jb250YWluZXIuc3R5bGUoJ2p1c3RpZnktY29udGVudCcsICdjZW50ZXInKTtcclxuICAgIH1cclxuXHJcbiAgICBwdWJsaWMgX3NldExhYmVsVGV4dFBvc0hvcml6b250YWwoX2xhYmVsVGV4dCwgX2lzWVJldmVyc2VkOiBib29sZWFuLCBfcGFyYW1zOiBJTGFiZWxUZXh0UG9zSG9yaXpvbnRhbFBhcmFtcyk6IHZvaWQge1xyXG4gICAgICAgIGxldCBoYXZlVHJhbnNmb3JtOiBib29sZWFuID0gX2lzWVJldmVyc2VkICE9PSAoZG9jdW1lbnQuZGlyID09PSAncnRsJyk7XHJcbiAgICAgICAgbGV0IHNpZ246IHN0cmluZyA9IGRvY3VtZW50LmRpciA9PT0gJ3J0bCcgPyAnJyA6ICctJztcclxuICAgICAgICBpZiAoX3BhcmFtcy52YWx1ZVNpZ24gPCAwKSBoYXZlVHJhbnNmb3JtID0gIWhhdmVUcmFuc2Zvcm07XHJcbiAgICAgICAgaWYgKHRoaXMuX2lzTGFiZWxPdXRzaWRlKF9sYWJlbFRleHQsIF9pc1lSZXZlcnNlZCwgX3BhcmFtcykpIGhhdmVUcmFuc2Zvcm0gPSAhaGF2ZVRyYW5zZm9ybTtcclxuICAgICAgICBpZiAoaGF2ZVRyYW5zZm9ybSkge1xyXG4gICAgICAgICAgICBfbGFiZWxUZXh0LnN0eWxlKCd0cmFuc2Zvcm0nLCAndHJhbnNsYXRlWChjYWxjKCcgKyBzaWduICsgJzEwMCUpKScpO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF9pc0xhYmVsT3V0c2lkZShfbGFiZWxUZXh0LCBfaXNZUmV2ZXJzZWQ6IGJvb2xlYW4sIF9wYXJhbXM6IElMYWJlbFRleHRQb3NIb3Jpem9udGFsUGFyYW1zKTogYm9vbGVhbiB7XHJcbiAgICAgICAgbGV0IHBvc0RhdGFMYWJlbFN0YXJ0czogbnVtYmVyID0gX2lzWVJldmVyc2VkID8gX3BhcmFtcy5jaGFydFdpZHRoIC0gX3BhcmFtcy54UG9zIDogX3BhcmFtcy54UG9zO1xyXG4gICAgICAgIGxldCBsYWJlbERpbWVuc2lvbjogYW55ID0gX2xhYmVsVGV4dC5ub2RlKCkuZ2V0Qm91bmRpbmdDbGllbnRSZWN0KCk7XHJcbiAgICAgICAgaWYgKF9wYXJhbXMudmFsdWVTaWduIDwgMCkge1xyXG4gICAgICAgICAgICByZXR1cm4gcG9zRGF0YUxhYmVsU3RhcnRzIC0gbGFiZWxEaW1lbnNpb24ud2lkdGggPCAwO1xyXG4gICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgIHJldHVybiBwb3NEYXRhTGFiZWxTdGFydHMgKyBsYWJlbERpbWVuc2lvbi53aWR0aCA+IF9wYXJhbXMuY2hhcnRXaWR0aDtcclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgLyoqXHJcbiAgICAgKiB1c2VkIGZvciBsYWJlbHMuaW5zaWRlIGlzIHRydWUuIHdoaWNoIHdpbGwgY2hhbmdlIHRoZSBoZWlnaHQgb2YgdGhlIGxhYmVsIGRpdiBjb250YWluZXJzXHJcbiAgICAgKiB0aGVuIHZlcnRpY2FsbHkgYWxpZ24gdXNpbmcgZmxleCBhbmQgYWxpZ24taXRlbXNcclxuICAgICAqIHBhcmFtIHtbdHlwZV19ICAgICAgICAgICAgICAgICAgICAgICAgIF9sYWJlbHMgW0VsZW1lbnRdXHJcbiAgICAgKiBwYXJhbSB7J3RvcCcgfCAnbWlkZGxlJyB8ICdib3R0b20nfSAgICBfdmVydGljYWxBbGlnblxyXG4gICAgICovXHJcbiAgICBwdWJsaWMgc2V0VmVydGljYWxBbGlnbkNTUyhfbGFiZWxzLCBfdmVydGljYWxBbGlnbjogJ3RvcCcgfCAnbWlkZGxlJyB8ICdib3R0b20nKTogdm9pZCB7XHJcbiAgICAgICAgbGV0IGtleSA9IF92ZXJ0aWNhbEFsaWduIHx8ICdtaWRkbGUnO1xyXG4gICAgICAgIGxldCB2YWx1ZSA9IHRoaXMuX3ZlcnRpY2FsQWxpZ25TdG9yZVtrZXldO1xyXG4gICAgICAgIF9sYWJlbHMuc3R5bGUoJ2FsaWduLWl0ZW1zJywgdmFsdWUpO1xyXG4gICAgfVxyXG5cclxuICAgIC8vID09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PSBSZWN0IGNhbGN1bGF0aW9uID09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09XHJcblxyXG4gICAgLyoqXHJcbiAgICAgKiBjYWxjdWxhdGVzIHRoZSB3aWR0aCBvZiBlYWNoIHJlY3QgYW5kIHBhZGRpbmcob25seSBhcHBsaWNhYmxlIHRvIGJhci1jbHVzdGVyKSBiZXR3ZWVuIGVhY2ggcmVjdCBpbiBhIGNsdXN0ZXIuXHJcbiAgICAgKiBwYXJhbSB7bnVtYmVyfSBfdG90YWxXaWR0aFxyXG4gICAgICogcGFyYW0ge251bWJlcn0gX3BhZGRpbmdQZXJjZW50IHBlcmNlbnRhZ2Ugb2YgdG90YWxXaWR0aCBhbGxvd2VkIGZvciB0b3RhbCBzdW0gb2YgYWxsIHBhZGRpbmdcclxuICAgICAqIHBhcmFtIHtudW1iZXJ9IF9ub09mUmVjdFxyXG4gICAgICovXHJcbiAgICBwdWJsaWMgZ2V0UmVjdFdpZHRoKF90b3RhbFdpZHRoOiBudW1iZXIsIF9wYWRkaW5nUGVyY2VudDogbnVtYmVyLCBfbm9PZlJlY3Q6IG51bWJlcik6IHsgd2lkdGg6IG51bWJlciwgcGFkZGluZzogbnVtYmVyIH0ge1xyXG4gICAgICAgIC8vIGNhbGN1bGF0ZWQgZWFjaCBiYXIncyBwYWRkaW5nIGJ5IGRpdmlkaW5nIGEgcGVyY2VudGFnZSBvZiB0aGUgdG90YWxXaWR0aFxyXG4gICAgICAgIGxldCBlYWNoUGFkZGluZ1dpZHRoID0gX3RvdGFsV2lkdGggKiBfcGFkZGluZ1BlcmNlbnQgLyAoX25vT2ZSZWN0IC0gMSk7XHJcbiAgICAgICAgLy8gZWFjaCBwYWRkaW5nIHNob3VsZCBub3QgZXhjZWVkIHRoaXMuX2FsbG93ZWRQYWRkaW5nVmFsdWVcclxuICAgICAgICBsZXQgcGFkZGluZ1ZhbHVlID0gTWF0aC5taW4odGhpcy5fYWxsb3dlZFBhZGRpbmdWYWx1ZSwgZWFjaFBhZGRpbmdXaWR0aCk7XHJcbiAgICAgICAgcmV0dXJuIHtcclxuICAgICAgICAgICAgd2lkdGg6IChfdG90YWxXaWR0aCAtIHBhZGRpbmdWYWx1ZSAqIChfbm9PZlJlY3QgLSAxKSkgLyBfbm9PZlJlY3QsXHJcbiAgICAgICAgICAgIHBhZGRpbmc6IHBhZGRpbmdWYWx1ZVxyXG4gICAgICAgIH07XHJcbiAgICB9XHJcblxyXG4gICAgLy8gPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09IEdlbmVyYWwgPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT1cclxuICAgIHByaXZhdGUgX2lzVmFsdWVFeGlzdChfdmFsdWU6IGFueSk6IGJvb2xlYW4ge1xyXG4gICAgICAgIHJldHVybiBfdmFsdWUgIT09IG51bGwgJiYgX3ZhbHVlICE9PSB1bmRlZmluZWQ7XHJcbiAgICB9XHJcbn1cclxuIl19