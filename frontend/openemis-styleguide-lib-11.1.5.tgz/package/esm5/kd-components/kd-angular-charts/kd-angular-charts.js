import { __decorate, __metadata } from "tslib";
import { Component, ViewEncapsulation, Input, Output, EventEmitter, OnInit, OnChanges, SimpleChanges, ElementRef, OnDestroy } from '@angular/core';
import { DomSanitizer } from '@angular/platform-browser';
import { KdSplitterEvent } from '../kd-angular-splitter/index';
import { KdConvertionSvc, KdDomElemSvc, KdDataSvc } from '../kd-common/index';
import { KdChartsSvc } from './kd-angular-charts-svc';
import { DEFAULT_CONFIG } from './kd-angular-charts-config';
var KdCharts = /** @class */ (function () {
    function KdCharts(_sanitizer, _elementRef, _chartSvc, 
    // public _kdSplitterEvent: KdSplitterEvent,
    _convertionSvc, _dataSvc) {
        this._sanitizer = _sanitizer;
        this._elementRef = _elementRef;
        this._chartSvc = _chartSvc;
        this._convertionSvc = _convertionSvc;
        this._dataSvc = _dataSvc;
        this.isLayerLoading = true;
        this.smallLoaderValue = null;
        this.pieData = [];
        this.pieColor = [];
        this.backgroundColor = '#FFFFFF';
        this.checkMapScale = false;
        this.isAxisChart = false;
        this.isNegativeStack = false;
        this.chartType = [''];
        this.rotateTitleX = false;
        this.rotateTitleY = false;
        this.chartHide = false;
        this.haveAxisPadding = false;
        this.haveAxisSpecialPadding = false;
        this.xAxisOpposite = false;
        this.havekdChartNoBorderClass = false;
        this.htmlClassObj = {
            'chartsWrapper': '',
            'legendContainer': ''
        };
        this.api = {};
        this.icons = {};
        this.markersLegend = [];
        this.shapes = {
            triangle: 'M 4 0 L 4 0 L 0 8 L 8 8 z',
            triangleR: 'M 0 0 L 8 0 L 4 8 L 4 8 z',
            diamond: 'M 4 0 L 8 4 L 4 8 L 0 4 z',
            circle: 'M 4 0 A 4 4 0 1 0 4 8 A 4 4 0 1 0 4 0 Z',
            square: 'M 0 0 L 8 0 L 8 8 L 0 8 z'
        };
        this.legendInactive = [];
        this._colorListPosition = 0;
        this._pieDoneFlag = false;
        this.seriesThreshold = 1000;
        this.outputLegendData = new EventEmitter();
        this.outputData = new EventEmitter();
        this.outputArea = new EventEmitter();
        // this._splitterSubscriptionArr = this._initSplitterSubscriptions(_kdSplitterEvent);
    }
    KdCharts.prototype.ngOnInit = function () {
        // console.log('kd-chart init');
        this._setConfig(this.chartConfig, true);
        if (!this.chartData || !this.chartConfig)
            return;
        this._setData(this.chartData);
        this.initApi();
        // this._resizeListener = () => this._onResize();
        // this._initListener();
        // console.log('kd-chart data ', this.chartData);
        // console.log('kd-chart config ', this.chartConfig);
    };
    KdCharts.prototype.ngOnChanges = function (_simpleChanges) {
        if (_simpleChanges.hasOwnProperty('chartConfig') && !_simpleChanges['chartConfig'].firstChange) {
            if (_simpleChanges['chartConfig'].currentValue === this.config)
                return;
            this._setConfig(_simpleChanges.chartConfig.currentValue);
        }
        if (_simpleChanges.hasOwnProperty('chartData') && !_simpleChanges['chartData'].firstChange) {
            if (_simpleChanges['chartData'].currentValue === this.data)
                return;
            this._setData(Object.assign({}, _simpleChanges.chartData.currentValue));
        }
    };
    KdCharts.prototype.ngOnDestroy = function () {
        if (!this.chartData || !this.chartConfig)
            return;
        // this._unsubscribe(this._splitterSubscriptionArr);
        // this._removeListener();
    };
    /**
     * For EXPORT. export skips data massage and generateLegendData, hence need to setLegendData separately
     * (accurate as of v3.7.0) as legendData is for internal use, we do not put in Input. this function is accessed via ViewChild from KdVisualization
     * param {ILegendData }} _legendData
     */
    KdCharts.prototype.setLegendData = function (_legendData) {
        this.legendData = Object.assign({}, _legendData);
    };
    /**
     * initiate api from outside kd charts component
     */
    KdCharts.prototype.initApi = function () {
        var _this = this;
        if (typeof this.chartApi === 'undefined')
            return;
        this.chartApi.changeSeriesColor = function (legendId, color, index) {
            if (typeof index === 'number')
                _this._setDataColorShape(index, color);
            _this.legendData[legendId].color = color;
            _this._updateLegendIconWithIndex(legendId, index);
            _this.api.redraw();
        };
        this.chartApi.redraw = function () { return _this.api.redraw(); };
        // this.chartApi.enableListener = (_haveListener: boolean) => {
        //     if (_haveListener) {
        //         this._initListener();
        //         if (this._splitterSubscriptionArr.length === 0) {
        //             this._splitterSubscriptionArr = this._initSplitterSubscriptions(this._kdSplitterEvent);
        //         }
        //     } else {
        //         this._removeListener();
        //         this._unsubscribe(this._splitterSubscriptionArr);
        //         this._splitterSubscriptionArr = [];
        //     }
        // };
    };
    // ================================= Listener ==================================
    // private _initListener() {
    //     window.addEventListener('resize', this._resizeListener);
    // }
    // private _removeListener() {
    //     window.removeEventListener('resize', this._resizeListener);
    // }
    // private _onResize(): void {
    //     clearTimeout(this._resizeTimeout);
    //     this._resizeTimeout = setTimeout(() => {
    //         this.api.redraw();
    //     }, 500);
    // }
    // ================================= Splitter Subscription ==================================
    // private _initSplitterSubscriptions(_splitterEvent): Subscription[] {
    //     if (!_splitterEvent) return;
    //     let subscriptionArr: Subscription[] = [];
    //     let toggleMenuSub = _splitterEvent.onToggleMenu().subscribe((): void => {
    //         timer(500).subscribe((): void => {
    //             this.api.redraw();
    //         });
    //     });
    //     let toggleSubPane = _splitterEvent.onToggleSubPane().subscribe((): void => {
    //         timer(500).subscribe((): void => {
    //             this.api.redraw();
    //         });
    //     });
    //     let dragMenuSub = _splitterEvent.onDrag()
    //         .pipe(
    //             debounceTime(100)
    //         )
    //         .subscribe((): void => {
    //             this.api.redraw();
    //         });
    //     subscriptionArr.push(toggleMenuSub);
    //     subscriptionArr.push(toggleSubPane);
    //     subscriptionArr.push(dragMenuSub);
    //     return subscriptionArr;
    // }
    // private _unsubscribe(_subscriptionArr: Subscription[] = []): void {
    //     if (_subscriptionArr.length === 0) return;
    //     _subscriptionArr.forEach(subscription => {
    //         if (subscription) subscription.unsubscribe();
    //     });
    // }
    // ================================= Config and Data ==================================
    KdCharts.prototype._setConfig = function (_config, _isFirstChange) {
        // storing config in this component
        this.config = JSON.parse(JSON.stringify(DEFAULT_CONFIG));
        this._dataSvc.deepCombineObject(this.config, _config || {});
        // set config is called twice, to improve performance, only call the following once (after data massage)
        if (_isFirstChange)
            return;
        this.setChartStyle(_config);
        this.checkMapScale = false;
        this._setClassNames();
        this._populateLegendIcon();
        this._setLabelStyle();
        // storing config into chart service
        this._chartSvc.config = _config;
    };
    KdCharts.prototype.setChartStyle = function (_config) {
        this.havekdChartNoBorderClass = !_config.chart.mainArea.style["borderWidth"];
        if (_config.chart.mainArea.style["borderWidth"] && _config.chart.mainArea.style["borderWidth"] === '0px') {
            this.havekdChartNoBorderClass = true;
        }
    };
    /* To be revisit. Hot fix for downgrade component as ngclass value doesn't change.*/
    KdCharts.prototype._setClassNames = function () {
        // htmlClassObj is a workaround for downgrade method
        this.htmlClassObj['chartsWrapper'] = '';
        this.htmlClassObj['legendContainer'] = '';
        if (typeof this.config.legend.float !== undefined && this.config.legend.float) {
            this.htmlClassObj.chartsWrapper += 'legend-float ';
            this.htmlClassObj.legendContainer += 'legend-float ';
        }
        if (typeof this.config.legend.verticalAlign !== undefined) {
            this.htmlClassObj.chartsWrapper += this.config.legend.verticalAlign + ' ';
            this.htmlClassObj.legendContainer += this.config.legend.verticalAlign + ' ';
        }
        if (typeof this.config.legend.align !== undefined) {
            this.htmlClassObj.chartsWrapper += this.config.legend.align + ' ';
            this.htmlClassObj.legendContainer += this.config.legend.align + ' ';
        }
        if (this.chartCategory === 'pie' || this.chartCategory === 'map')
            return;
        this.xAxisOpposite = this.config.xAxis.opposite;
        // setting class name for vertical axis title to rotate
        this.rotateTitleX = this.chartType[0] === 'bar' && this._chartSvc.checkRotateTitleEnabled(this.chartType, this.config);
        this.rotateTitleY = this.chartType[0] !== 'bar' && this._chartSvc.checkRotateTitleEnabled(this.chartType, this.config);
        // this flag is for all axisCharts except for bar. Bar do not need paddin
        this.haveAxisPadding = this.chartType[0] !== 'bar';
        this.haveAxisSpecialPadding = this.chartType[this.chartType.length - 1] === 'type2';
        this.isNegativeStack = (this.chartCategory === 'bar' || this.chartCategory === 'column') && this.chartType[1] === 'stack' && this.chartType[2] === 'negative';
    };
    KdCharts.prototype._updateLegendIconWithIndex = function (_legendId, _index) {
        var legendId = _legendId, legendConfig;
        // if legendId is given, we should follow legendId
        if (!legendId) {
            // if no legendId, follow _index
            if (_index === null || _index === undefined)
                return;
            legendId = this.legendList[_index];
        }
        legendConfig = this.legendData[legendId];
        this._updateLegendIcon(legendId, legendConfig);
    };
    KdCharts.prototype._populateLegendIcon = function (index) {
        if (!this.legendData)
            return;
        this.legendList = Object.keys(this.legendData);
        for (var i = 0; i < this.legendList.length; i++) {
            var legendId = this.legendList[i];
            var legendConfig = this.legendData[legendId];
            // let eachSvg = this.renderer.createElement('svg');
            // this.renderer.setAttribute(eachSvg, 'fill', this.config.legendData[legendId].color);
            // this.renderer.setAttribute(eachSvg, 'width', 8);
            // this.renderer.setAttribute(eachSvg, 'height', 8);
            // let eachSvgPath = this.renderer.createElement('path');
            // this.renderer.setAttribute(eachSvgPath, 'd', this.config.legendData[legendId].shape);
            // this.renderer.appendChild(eachSvg, eachSvgPath);
            // let xml = new XMLSerializer().serializeToString(eachSvg);ARI
            // let data = "data:image/svg+xml;base64," + btoa(xml);
            // this.icons[legendId] = this._sanitizer.bypassSecurityTrustResourceUrl('data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" fill="' + legendConfig.color + '" width="8" height="8"><path d="' + this.shapes[legendConfig.shape] + '"/></svg>');
            // this.icons[legendId] = this._sanitizer.bypassSecurityTrustResourceUrl(data);
            // legend is set based on whether there is deactive
            this._updateLegendIcon(legendId, legendConfig);
        }
    };
    KdCharts.prototype._setLabelStyle = function () {
        if (this.config.chart.labels.enabled) {
            var labelStyle = this._chartSvc.getStyle(this.config.chart.labels.style);
            this._applyLabelStyle(labelStyle, ' span', true);
        }
    };
    KdCharts.prototype._setData = function (_data) {
        this.legendInactive = [];
        this.markersLegend = [];
        this._setChartType(_data);
        if (this.config.skipMassage) {
            this.data = _data;
            this._setConfig(this.config);
            return;
        }
        if (this.chartCategory === 'pie' || this.chartCategory === 'map') {
            if (this.chartCategory === 'pie')
                this._dataMassageForPie(_data);
            else if (this.chartCategory === 'map')
                this._dataMassageForMap(_data);
            // else if (this.chartCategory === 'map') this.data = _data;
            this._setConfig(this.config);
        }
        else
            this._dataMassage(_data);
        // emit data to kd-visualization to prepare for export
        this.outputData.emit(this.data);
        // emit current config to kd-visualization to prepare for export
        this.outputLegendData.emit(this.legendData);
    };
    KdCharts.prototype._setChartType = function (_data) {
        var dataToUse = _data;
        if (!this.config.skipMassage || (_data.chart && _data.chart.type == 'map')) {
            dataToUse = _data.chart;
        }
        this.chartCategory = dataToUse.type;
        this.chartType = dataToUse.layout.split('-');
        this.isAxisChart = dataToUse.type !== 'pie' && dataToUse.type !== 'map';
    };
    KdCharts.prototype._setDataColorShape = function (_index, _color) {
        if (_index < 0) {
            return;
        }
        // let changeSeries: boolean = this.config.chart.hasOwnProperty('persistentSeriesChange') ? this.config.chart.persistentSeriesChange : true;
        var legendIds = Object.keys(this.legendData);
        if (this.chartCategory != 'map') {
            for (var xIndex = this.data.data.length - 1; xIndex >= 0; xIndex--) {
                for (var yIndex = this.data.data[xIndex].y.length - 1; yIndex >= 0; yIndex--) {
                    if (this.data.data[xIndex].y[yIndex].id === legendIds[_index]) {
                        this._changeSeries(xIndex, yIndex, 'color');
                        this._changeSeries(xIndex, yIndex, 'shape');
                    }
                }
            }
        }
    };
    KdCharts.prototype._changeSeries = function (_xIndex, _yIndex, _element) {
        var legendId = this.data.data[_xIndex].y[_yIndex].id;
        var output = this.legendData[legendId][_element];
        if (_element === 'shape') {
            output = this.shapes[output];
        }
        if (this._isChangeSeries(_xIndex, _yIndex, _element)) {
            this.data.data[_xIndex].y[_yIndex][_element] = output;
        }
    };
    KdCharts.prototype._isChangeSeries = function (_xIndex, _yIndex, _element) {
        var changeSeries = this.config.chart.hasOwnProperty('persistentSeriesChange') ? this.config.chart.persistentSeriesChange : true;
        if (changeSeries) {
            return true;
        }
        else {
            if (this.chartData.series[_yIndex].data[_xIndex].hasOwnProperty(_element)) {
                if (this.chartData.series[_yIndex].data[_xIndex][_element] !== null || this.chartData.series[_yIndex].data[_xIndex][_element].length > 0) {
                    return false;
                }
            }
        }
        return true;
    };
    KdCharts.prototype.onLegendClick = function (_id) {
        var legendConfig = this.legendData[_id];
        legendConfig.deactive = !legendConfig.deactive || false;
        this._updateLegendItem(_id, legendConfig);
        if (legendConfig.deactive) {
            this.legendInactive.push(_id);
        }
        else {
            var idIndex = this.legendInactive.indexOf(_id);
            if (idIndex !== -1) {
                this.legendInactive.splice(idIndex, 1);
            }
        }
        if (this.chartCategory != 'map') {
            var legendData = this.updateConfig();
            var data = this.updateData(legendData);
            this.api.legendClick(data, legendData);
            this._toggleDataLabel(_id, legendConfig.deactive);
            // update data to kd-visualization to prepare for exporting
            this.outputData.emit(data);
        }
        else {
            this.api.legendClick(_id, legendConfig.deactive);
        }
    };
    KdCharts.prototype.onClusterClick = function (_id) {
        var legendItemMarker = this._elementRef.nativeElement.querySelector('#kdli-' + _id.id + ' .awesome-marker');
        var legendItemLabel = this._elementRef.nativeElement.querySelector('#kdli-' + _id.id + ' .kdx-legend-label');
        this.api.clusterClick(_id, { 'legendItemMarker': legendItemMarker, 'legendItemLabel': legendItemLabel });
    };
    KdCharts.prototype.getOutputLegend = function (_legendData) {
        if (this.chartCategory == 'map' && Object.keys(_legendData).length == 0) {
            this.checkMapScale = true;
        }
        else {
            this.legendData = _legendData;
            this.checkMapScale = false;
            this._pieDoneFlag = true;
            this.outputLegendData.emit(this.legendData);
            this._populateLegendIcon(undefined);
        }
    };
    KdCharts.prototype.getOutputData = function (_data) {
        // this.outputData.emit(_data);
        this.outputArea.emit(_data);
    };
    KdCharts.prototype.getReady = function (_value) {
        this.isLayerLoading = _value;
    };
    KdCharts.prototype._updateLegendItem = function (_id, _legendConfig) {
        this._updateLegendIcon(_id, _legendConfig);
        var textColor = (_legendConfig.deactive) ? this.config.legend.item.inactiveColor || '#CCCCCC' : this.config.legend.item.style.color || this.config.legend.item.activeColor || '#000000';
        this._elementRef.nativeElement.querySelector('#kdli-' + _id).style.color = textColor;
    };
    KdCharts.prototype._updateLegendIcon = function (_id, _legendConfig) {
        var iconColor = (_legendConfig.deactive) ? this.config.legend.item.inactiveColor || '#CCCCCC' : _legendConfig.color || '#000000';
        var rgbColor = this._convertionSvc.colorToRgb(iconColor);
        this.icons[_id] = this._sanitizer.bypassSecurityTrustResourceUrl('data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" fill="' + rgbColor + '" width="8" height="8"><path d="' + this.shapes[_legendConfig.shape] + '"/></svg>');
    };
    KdCharts.prototype._toggleDataLabel = function (id, deactive) {
        var displayState = (deactive) ? 'none' : 'flex';
        this._applyLabelStyle(displayState, '.y-' + id);
        if (!deactive)
            this._applyLabelStyle('display:' + displayState, '.y-' + id + ' span', true);
    };
    KdCharts.prototype._applyLabelStyle = function (_style, target, isRepositioning) {
        target = target || '';
        var allLabel = this._elementRef.nativeElement.querySelectorAll('#' + this.config.id + ' .kdx-charts-data-label' + target);
        for (var i in allLabel) {
            if (allLabel[i].style) {
                if (isRepositioning) {
                    var labelWidth = allLabel[i].offsetWidth;
                    var labelCenter = (labelWidth - labelWidth / allLabel[i].innerText.toString().length) / 2;
                    var shiftPosition = 0 - labelCenter;
                    _style += 'left:' + shiftPosition + 'px;';
                    allLabel[i].style = _style;
                }
                else {
                    allLabel[i].style.display = _style;
                }
            }
        }
    };
    KdCharts.prototype.updateConfig = function () {
        var legendData = Object.assign({}, this.legendData);
        var legendInactive = this.legendInactive;
        legendData = Object.keys(legendData)
            .filter(function (key) { return !legendInactive.includes(key); })
            .reduce(function (obj, key) {
            obj[key] = legendData[key];
            return obj;
        }, {});
        return legendData;
    };
    KdCharts.prototype.updateData = function (_legendData) {
        var thisData = JSON.parse(JSON.stringify(this.data));
        var legendInactive = this.legendInactive;
        if (this.chartCategory === 'pie') {
            var legendData_1 = _legendData;
            // piedata uses legendData instead of data
            thisData.data = Object.keys(legendData_1).map(function (key) { return legendData_1[key]; }).filter(function (value) { return value.y && value.y > 0; });
            return thisData;
        }
        else if (this.chartType[1] === '100' && this.chartType[0] === 'area') {
            for (var i = thisData.data.length - 1; i >= 0; i--) {
                var newYArr = thisData.data[i].y.filter(function (d) { return !legendInactive.includes(d.id); });
                thisData.data[i] = Object.assign({}, thisData.data[i], { y: newYArr });
            }
        }
        var originalData = JSON.parse(JSON.stringify(thisData));
        var allSumArrMax = [0];
        var allSumArrMin = [0];
        var haveNegative = false;
        for (var i = 0; i < originalData.data.length; i++) {
            var totalSum = 1;
            if (this.chartType[1] === '100') {
                totalSum = thisData.data[i].y.reduce(function (acc, curr, yIndex) {
                    if (legendInactive.includes(curr.id))
                        return acc;
                    return acc + curr.value;
                }, 0);
            }
            var newYArr = [];
            var sumArr = [];
            var sum = 0;
            var sumNegative = 0;
            for (var yIndex = 0; yIndex < originalData.data[i].y.length; yIndex++) {
                var currY = Object.assign({}, originalData.data[i].y[yIndex]);
                if (legendInactive.includes(currY.id))
                    continue;
                var currentVal = currY.value === null ? 0 : currY.value;
                var currSign = Math.sign(currentVal);
                if (currSign < 0 && !haveNegative) {
                    haveNegative = true;
                    if (this.chartType[1] === '100') {
                        this.chartHide = true;
                        break;
                    }
                }
                if (this.chartType[1] !== '100' && this.chartType[1] === 'stack') {
                    if (currSign >= 0) {
                        sum = (currentVal === null) ? sum : sum + currentVal;
                    }
                    else {
                        sumNegative = (currentVal === null) ? sumNegative : sumNegative + currentVal;
                    }
                }
                else if (this.chartType[1] === '100') {
                    if (currentVal !== null && totalSum !== 0) {
                        currentVal = currentVal / totalSum * 100;
                        sum = sum + currentVal;
                    }
                    else {
                        sum = sum;
                    }
                }
                else {
                    if (currSign >= 0) {
                        sum = (currentVal === null) ? 0 : currentVal;
                    }
                    else {
                        sumNegative = (currentVal === null) ? 0 : currentVal;
                    }
                }
                currY.sum = currentVal >= 0 ? sum : sumNegative;
                // value is used to display data-label and tooltip, renderVal is the acutal percentage to pass to d3 for rendering
                if (this.chartType[1] === '100')
                    currY['renderVal'] = currentVal;
                sumArr.push(Math.sign(currentVal) < 0 ? sumNegative : sum);
                newYArr.push(currY);
            }
            allSumArrMax.push(this._chartSvc.getD3MaxOrMin(sumArr, 'max'));
            allSumArrMin.push(this._chartSvc.getD3MaxOrMin(sumArr, 'min'));
            thisData.data[i] = Object.assign({}, originalData.data[i], { y: newYArr });
        }
        thisData['range'] = {
            max: this._chartSvc.getD3MaxOrMin(allSumArrMax, 'max'),
            min: this._chartSvc.getD3MaxOrMin(allSumArrMin, 'min')
        };
        thisData['haveNegative'] = haveNegative;
        return thisData;
    };
    KdCharts.prototype._generateLegendData = function (_data, maxSeriesLength) {
        // empty out variables before regenerating
        this.legendData = {};
        // this.legendList = null;
        var legendIdSearch = {};
        var legendId, legendDataObj;
        var legendData = {};
        for (var i = 0; i < maxSeriesLength; i++) {
            legendId = (_data.series[i] && _data.series[i].length > 0) ? _data.series[i].id : 'id' + i;
            legendDataObj = {
                'name': _data.series[i].name,
                'id': legendId,
                'color': _data.series[i].color || this._getDefaultConfig('color', i),
                'shape': _data.series[i].shape || this._getDefaultConfig('shape', i)
            };
            if (this.chartCategory === 'line' || this.chartCategory === 'spline' || this.chartCategory === 'area' || this.chartCategory === 'dot') {
                legendDataObj['dotEnabled'] = (typeof _data.series[i].dotEnabled !== 'undefined') ? _data.series[i].dotEnabled : true;
                legendDataObj['dotBorderWidth'] = (typeof _data.series[i].dotBorderWidth !== 'undefined') ? _data.series[i].dotBorderWidth : 0;
                legendDataObj['dotBorderColor'] = (typeof _data.series[i].dotBorderColor !== 'undefined') ? _data.series[i].dotBorderColor : '#FFFFFF';
                if (this.chartCategory !== 'dot')
                    legendDataObj['lineStyle'] = (typeof _data.series[i].lineStyle !== 'undefined') ? _data.series[i].lineStyle : 'solid';
            }
            legendData[legendId] = legendDataObj;
            legendIdSearch[i] = legendId;
        }
        this.legendData = legendData;
        return legendIdSearch;
    };
    KdCharts.prototype._dataMassage = function (_data) {
        var seriesLength = this._chartSvc.getD3MaxOrMin([_data.series.length, this.seriesThreshold], 'min');
        var chartDataObj, chartDataSeriesObj;
        var chartData = {
            'type': _data.chart['type'] ? _data.chart['type'] : null,
            'layout': _data.chart['layout'] ? _data.chart['layout'] : null,
            'config': this.config.plotOptions && this.config.plotOptions.hasOwnProperty(_data.chart['type']) ? this.config.plotOptions[_data.chart['type']] : {},
            'data': []
        };
        if (!this.config.hasOwnProperty('id')) {
            this.config['id'] = _data.chart['type'] ? _data.chart['type'] + '-1' : 'Default-1';
        }
        var categories = this._chartSvc.getLimitedCategories(_data.xAxis.categories, this.xThreshold);
        var legendIdSearch = this._generateLegendData(_data, seriesLength);
        var totalSumArr = this._getTotalSum(_data, seriesLength);
        var allSumArrMax = [0];
        var allSumArrMin = [0];
        var haveNegative = false;
        for (var i = 0; i < categories.length; i++) {
            chartDataObj = {
                'x': {
                    value: i.toString(),
                    label: categories[i]
                },
                'y': [],
            };
            var sumArr = [];
            var sum = 0;
            var sumNegative = 0;
            var forLoopInfo = this._chartSvc.getForLoopInfo(this._chartSvc.getForLoopSequence(this.chartType), seriesLength);
            // for (let j: number = 0; j < seriesLength; j++) {
            for (var j = forLoopInfo.start; forLoopInfo.check(j, forLoopInfo.end); j = forLoopInfo.iterate(j)) {
                if (typeof _data.series[j].data[i] === 'undefined')
                    continue;
                var currentVal = _data.series[j].data[i].value;
                var currSign = Math.sign(currentVal);
                if (typeof currentVal === 'undefined')
                    continue;
                if (currSign < 0 && !haveNegative) {
                    haveNegative = true;
                    if (this.chartType[1] === '100')
                        break;
                }
                if (this.chartType[1] !== '100' && this.chartType[1] === 'stack') {
                    if (currSign >= 0) {
                        sum = (currentVal === null) ? sum : sum + currentVal;
                    }
                    else {
                        sumNegative = (currentVal === null) ? sumNegative : sumNegative + currentVal;
                    }
                }
                else if (this.chartType[1] === '100') {
                    if (currentVal !== null && totalSumArr[i] !== 0) {
                        currentVal = currentVal / totalSumArr[i] * 100;
                    }
                    else {
                        currentVal = 0;
                    }
                    sum = sum + currentVal;
                }
                else {
                    if (currSign >= 0) {
                        sum = (currentVal === null) ? 0 : currentVal;
                    }
                    else {
                        sumNegative = (currentVal === null) ? 0 : currentVal;
                    }
                }
                chartDataSeriesObj = {
                    'sum': currentVal >= 0 ? sum : sumNegative,
                    'value': _data.series[j].data[i].value,
                    'color': this._getConfig('color', j, _data.series[j].data[i]),
                    'shape': this.shapes[this._getConfig('shape', j, _data.series[j].data[i])],
                    'id': legendIdSearch[j]
                };
                // value is used to display data-label and tooltip, renderVal is the acutal percentage to pass to d3 for rendering
                if (this.chartType[1] === '100')
                    chartDataSeriesObj['renderVal'] = currentVal;
                sumArr.push(Math.sign(currentVal) < 0 ? sumNegative : sum);
                chartDataObj.y.push(chartDataSeriesObj);
            }
            allSumArrMax.push(this._chartSvc.getD3MaxOrMin(sumArr, 'max'));
            allSumArrMin.push(this._chartSvc.getD3MaxOrMin(sumArr, 'min'));
            chartData.data.push(chartDataObj);
        }
        if (_data.chart.type !== 'pie') {
            chartData['range'] = {
                max: this._chartSvc.getD3MaxOrMin(allSumArrMax, 'max'),
                min: this._chartSvc.getD3MaxOrMin(allSumArrMin, 'min')
            };
            chartData['haveNegative'] = haveNegative;
        }
        this.data = chartData;
        this.chartHide = this.chartType[1] === '100' && haveNegative;
        this._setConfig(this.config);
    };
    KdCharts.prototype._dataMassageForPie = function (_data) {
        if (_data !== undefined && _data !== null) {
            var chartData = {
                'type': _data.chart['type'] ? _data.chart['type'] : null,
                'layout': _data.chart['layout'] ? _data.chart['layout'] : null,
                'config': this.config.plotOptions && this.config.plotOptions.hasOwnProperty(_data.chart['type']) ? this.config.plotOptions[_data.chart['type']] : {},
                'data': []
            };
            var returnParams = this._chartSvc.singlePieDataMassage(this.legendData, _data, this.config, this.seriesThreshold);
            chartData['piedata'] = returnParams.pieData;
            this.data = chartData;
            this.config['pieColor'] = returnParams.pieColor;
            this.legendData = returnParams.legendData;
            // this.outputData.emit(this.data);
        }
    };
    KdCharts.prototype._dataMassageForMap = function (_data) {
        this.data = _data;
        this._setLegendForMap();
    };
    KdCharts.prototype._setLegendForMap = function () {
        var seriesData;
        if (this.data['mapSeriesData'] && this.config.skipMassage) {
            seriesData = JSON.parse(JSON.stringify(this.data['mapSeriesData']));
        }
        else {
            seriesData = JSON.parse(JSON.stringify(this.data['series']));
            for (var i = 0; i < seriesData.length; i++) {
                seriesData[i]['deactive'] = false;
            }
        }
        this.checkMapScale = false;
        if (!this.config.skipMassage) {
            if (this.config.colorAxis != undefined) {
                if (this.config.colorAxis.dataClasses && this.config.colorAxis.dataClasses.length != 0) {
                    this.legendData = this._chartSvc.setSingleLegendLevels(this.config.colorAxis.dataClasses, this.config.legend.valueDecimals, this.config.legend.valueSuffix);
                }
                else {
                    this.checkMapScale = true;
                }
            }
            else {
                this.legendData = this._chartSvc.setMapLegendData(this.legendData, seriesData, this.config);
            }
        }
        else {
            // output legend only for exporting
            if (this.config.colorAxis != undefined) {
                if (this.config.colorAxis.dataClasses && this.config.colorAxis.dataClasses.length != 0) {
                    this.legendData = this._chartSvc.setMapLegendData(this.legendData, seriesData, this.config);
                }
                else {
                    this.checkMapScale = true;
                }
            }
            else {
                this.legendData = this._chartSvc.setMapLegendData(this.legendData, seriesData, this.config);
            }
        }
    };
    KdCharts.prototype._getTotalSum = function (_data, seriesLength) {
        if (this.chartType[1] === '100') {
            return this._chartSvc.getTotalSumArrFromSeries(_data.series, _data.xAxis.categories, seriesLength);
        }
    };
    KdCharts.prototype._getConfig = function (_element, _seriesIndex, _data) {
        if (!this._chartSvc.isExist(_data))
            return;
        if (_data.hasOwnProperty(_element) && _data[_element] !== undefined) {
            return _data[_element];
        }
        var config = this._getLegendConfig(_element, _seriesIndex);
        return config;
    };
    KdCharts.prototype._getLegendConfig = function (_element, _seriesIndex) {
        if (_element === 'shape' &&
            (this.chartData.chart.type === 'pie' || this.chartData.chart.type === 'bar')) {
            return 'circle';
        }
        var defaultConfig = this._getDefaultConfig(_element, _seriesIndex);
        var config;
        if (this.chartCategory == 'pie') {
            config = defaultConfig;
        }
        else {
            config = this.chartData.series[_seriesIndex][_element] || defaultConfig;
        }
        return config;
    };
    KdCharts.prototype._getDefaultConfig = function (_element, _seriesIndex) {
        if (_element === 'shape')
            return 'circle';
        if (_seriesIndex || _seriesIndex === 0) {
            return this.config.colors[_seriesIndex];
        }
        else {
            this._colorListPosition++;
            return this.config.colors[this._colorListPosition - 1];
        }
    };
    KdCharts.prototype.getOutputMarker = function (_data) {
        this.markersLegend = _data;
    };
    KdCharts.ctorParameters = function () { return [
        { type: DomSanitizer },
        { type: ElementRef },
        { type: KdChartsSvc },
        { type: KdConvertionSvc },
        { type: KdDataSvc }
    ]; };
    __decorate([
        Input('data'),
        __metadata("design:type", Object)
    ], KdCharts.prototype, "chartData", void 0);
    __decorate([
        Input('config'),
        __metadata("design:type", Object)
    ], KdCharts.prototype, "chartConfig", void 0);
    __decorate([
        Input('api'),
        __metadata("design:type", Object)
    ], KdCharts.prototype, "chartApi", void 0);
    __decorate([
        Input(),
        __metadata("design:type", Number)
    ], KdCharts.prototype, "xThreshold", void 0);
    __decorate([
        Input(),
        __metadata("design:type", Number)
    ], KdCharts.prototype, "seriesThreshold", void 0);
    __decorate([
        Output(),
        __metadata("design:type", EventEmitter)
    ], KdCharts.prototype, "outputLegendData", void 0);
    __decorate([
        Output(),
        __metadata("design:type", EventEmitter)
    ], KdCharts.prototype, "outputData", void 0);
    __decorate([
        Output(),
        __metadata("design:type", EventEmitter)
    ], KdCharts.prototype, "outputArea", void 0);
    KdCharts = __decorate([
        Component({
            selector: 'kd-charts',
            template: "<!-- <div class=\"kdx-charts-wrapper {{config.legend.verticalAlign}} {{config.legend.align}}\" [ngClass]=\"{'legend-float': config.legend.float}\"> -->\r\n\r\n<div class=\"kdx-charts-wrapper {{htmlClassObj.chartsWrapper}}\">\r\n    <div class=\"kdx-charts-main\">\r\n        <div class=\"kdx-header-container\" *ngIf=\"(config.title && config.title.enabled && config.title.text && config.title.text !== '') || (config.subtitle.enabled && config.subtitle.text && config.subtitle.text !== '')\">\r\n            <div *ngIf=\"config.title.enabled && config.title.text && config.title.text !== ''\" class=\"kdx-chart-title  {{config.title.align}}\" [ngStyle]=\"config.title.style\">\r\n                {{config.title.text}}\r\n            </div>\r\n            <div *ngIf=\"config.subtitle && config.subtitle.enabled && config.subtitle.text && config.subtitle.text !== ''\" class=\"kdx-chart-subtitle {{config.subtitle.align}}\" [ngStyle]=\"config.subtitle.style\">\r\n                {{config.subtitle.text}}\r\n            </div>\r\n        </div>\r\n\r\n        <div class=\"kdx-charts-dummy kdx-charts-invisible-axis-label\" [ngClass]=\"{'kdx-charts-child-padding-both': haveAxisPadding, 'kdx-charts-child-special-padding': haveAxisSpecialPadding, 'kdx-charts-axis-x-opposite': xAxisOpposite}\" [ngStyle]=\"config.xAxis.labels.style\"></div>\r\n        <div class=\"kdx-chart-container\" [ngStyle]=\"config.chart.plotArea.style\">\r\n            <div class=\"kdx-charts-axis-title kdx-charts-axis-title-x\" *ngIf=\"config.xAxis && config.xAxis.enabled && !chartHide && isAxisChart && config.xAxis.title.text !== ''\" [ngStyle]=\"config.xAxis.title.style\">\r\n                <div class=\"kdx-charts-axis-title-text\">{{config.xAxis.title.text}}</div>\r\n            </div>\r\n            <div class=\"kdx-charts-axis-label-container\" *ngIf=\"config.xAxis.enabled && config.xAxis.labels && config.xAxis.labels.enabled && !chartHide && isAxisChart\" [ngClass]=\"{'kdx-charts-child-padding-both': haveAxisPadding, 'kdx-charts-child-special-padding': haveAxisSpecialPadding, 'kdx-charts-axis-x-opposite': xAxisOpposite}\" [ngStyle]=\"config.xAxis.labels.style\">\r\n            </div>\r\n            <div *ngIf=\"config.chart.labels\" class=\"kdx-charts-data-label-container\" [ngStyle]=\"{'z-index': config.chart.labels.enabled ? 1 : -1}\"></div>\r\n            <div class=\"kdx-charts-svg-wrapper\">\r\n                <div id=\"{{config.id}}Leaflet\" class=\"kdx-charts-svg-container\">\r\n                    <svg width=\"0px\" height=\"0px\"></svg>\r\n                </div>\r\n                <div class=\"kdx-charts-axis-title kdx-charts-axis-title-y\" *ngIf=\"config.yAxis && config.yAxis.enabled && !chartHide && isAxisChart && config.yAxis.title && config.yAxis.title.text !== ''\" [ngStyle]=\"config.yAxis.title.style\">\r\n                    <div class=\"kdx-charts-axis-title-text\">{{config.yAxis.title.text}}</div>\r\n                </div>\r\n                <ng-container *ngIf=\"data\" [ngSwitch]=\"chartCategory\">\r\n                    <kd-bar-chart *ngSwitchCase=\"'bar'\" [data]=\"data\" [config]=\"config\" [api]=\"api\" [legend]=\"legendData\"></kd-bar-chart>\r\n                    <kd-bar-chart *ngSwitchCase=\"'column'\" [data]=\"data\" [config]=\"config\" [api]=\"api\" [legend]=\"legendData\"></kd-bar-chart>\r\n                    <kd-pie-chart *ngSwitchCase=\"'pie'\" [data]=\"data\" [config]=\"config\" [api]=\"api\" [legend]=\"legendData\" [seriesThreshold]=\"seriesThreshold\" (outputLegend)=\"getOutputLegend($event)\" (outputData)=\"getOutputData($event)\"></kd-pie-chart>\r\n                    <kd-line-chart *ngSwitchCase=\"'line'\" [data]=\"data\" [config]=\"config\" [api]=\"api\" [legend]=\"legendData\"></kd-line-chart>\r\n                    <kd-line-chart *ngSwitchCase=\"'dot'\" [data]=\"data\" [config]=\"config\" [api]=\"api\" [legend]=\"legendData\"></kd-line-chart>\r\n                    <kd-line-chart *ngSwitchCase=\"'spline'\" [data]=\"data\" [config]=\"config\" [api]=\"api\" [legend]=\"legendData\"></kd-line-chart>\r\n                    <kd-line-chart *ngSwitchCase=\"'area'\" [data]=\"data\" [config]=\"config\" [api]=\"api\" [legend]=\"legendData\"></kd-line-chart>\r\n                    <kd-map-chart *ngSwitchCase=\"'map'\" [data]=\"data\" [config]=\"config\" [api]=\"api\" [legend]=\"legendData\" (outputLegend)=\"getOutputLegend($event)\" (outputData)=\"getOutputData($event)\" (outputMarker)=\"getOutputMarker($event)\" (outputReady)=\"getReady($event)\"></kd-map-chart>\r\n                </ng-container>\r\n            </div>\r\n            <div class=\"kdx-charts-axis-label-container kdx-charts-double-axis-x\" *ngIf=\"config.xAxis.enabled && config.xAxis.labels && config.xAxis.labels.enabled && !chartHide && isAxisChart && isNegativeStack\" [ngClass]=\"{'kdx-charts-child-padding-both': haveAxisPadding, 'kdx-charts-child-special-padding': haveAxisSpecialPadding, 'kdx-charts-axis-x-opposite': !xAxisOpposite}\" [ngStyle]=\"config.xAxis.labels.style\">\r\n            </div>\r\n            <div class=\"kdx-charts-axis-title kdx-charts-axis-title-x kdx-charts-double-axis-x\" *ngIf=\"config.xAxis && config.xAxis.enabled && !chartHide && isAxisChart && config.xAxis.title.text !== '' && isNegativeStack\" [ngStyle]=\"config.xAxis.title.style\">\r\n                <div class=\"kdx-charts-axis-title-text\">{{config.xAxis.title.text}}</div>\r\n            </div>\r\n        </div>\r\n    </div>\r\n\r\n    <!-- <div *ngIf=\"config.legend.enabled && !chartHide\" [ngClass]=\"{'legend-float': config.legend.float}\" class=\"kdx-legend-container {{config.legend.verticalAlign}} {{config.legend.align}}\"> -->\r\n\r\n    <div class=\"kdx-legend-main-container {{htmlClassObj.chartsWrapper}}\" [ngClass]=\"{clusterChartMap: markersLegend.length > 0}\">\r\n        <div class=\"kdx-legend-container\" *ngIf=\"config.legend.enabled && !chartHide && markersLegend.length > 0\" [ngStyle]=\"{'flex': markersLegend.length > 0 ? '0 1 50%' : null}\">\r\n            <div class=\"kdx-legends\" [ngStyle]=\"config.clusterLegend.style\">\r\n                <div class=\"kdx-legend-title-container  {{config.clusterLegend.title.align}}\" *ngIf=\"config.clusterLegend.title && config.clusterLegend.title.text\" [ngStyle]=\"config.clusterLegend.title.style\">\r\n                    <div class=\"kdx-legend-title\">{{config.clusterLegend.title.text}}</div>\r\n                </div>\r\n                <div class=\"kdx-legend\">\r\n                    <div class=\"kdx-legend-item\" id=\"kdli-{{legendItem.id}}\" *ngFor=\"let legendItem of markersLegend\" (click)=\"onClusterClick(legendItem)\">\r\n                        <div class=\"kdx-legend-marker\" [innerHTML]=\"legendItem.icon.outerHTML\" ></div>\r\n                        <div class=\"kdx-legend-label\" [ngStyle]=\"config.clusterLegend.item.style\">\r\n                            <div class=\"kdx-label-text\">{{legendItem.label}}</div>\r\n                        </div>\r\n                    </div>\r\n                </div>\r\n            </div>\r\n        </div>\r\n        <div *ngIf=\"config.legend.enabled && !chartHide && !(chartCategory === 'map' && chartType[1] === 'cluster')\" class=\"kdx-legend-container\">\r\n            <div class=\"kdx-legends\" [ngStyle]=\"config.legend.style\">\r\n                <div *ngIf=\"config.legend.title && config.legend.title.text\" class=\"kdx-legend-title-container {{config.legend.title.align}}\" [ngStyle]=\"config.legend.title.style\">\r\n                    <div class=\"kdx-legend-title\">{{config.legend.title.text}}</div>\r\n                </div>\r\n                <div class=\"kdx-legend legend-scroll {{config.legend.layout}}\" *ngIf=\"legendList && !checkMapScale\" [ngClass]=\"{'legend-scroll': !config.legend.enableScroll}\">\r\n                    <div class=\"kdx-legend-item\" id=\"kdli-{{legendId}}\" [ngStyle]=\"{'color': config.legend.item.activeColor}\" *ngFor=\"let legendId of legendList\" (click)=\"onLegendClick(legendId)\">\r\n                        <div class=\"kdx-legend-marker\">\r\n                            <img id=\"legend-icon-{{legendId}}\" [src]=\"icons[legendId]\" />\r\n                        </div>\r\n                        <div class=\"kdx-legend-label\" [ngStyle]=\"config.legend.item.style\">\r\n                            <div class=\"kdx-label-text\" *ngIf=\"legendData[legendId]\" [ngClass]=\"{'kdx-label-lightgray': legendData[legendId].deactive}\" >{{legendData[legendId].name}}</div>\r\n                        </div>\r\n                    </div>\r\n                </div>\r\n              <!--   <div class=\"kdx-legend\"> [ngClass]=\"{'kdx-legend-main-container': markersLegend.length > 0}\"\r\n                    <div class=\"kdx-legend-item\" id=\"kdli-{{legendItem.id}}\" *ngFor=\"let legendItem of markersLegend\" (click)=\"onClusterClick(legendItem)\">\r\n                        <div class=\"kdx-legend-marker\" [innerHTML]=\"legendItem.icon.outerHTML\" ></div>\r\n                        <div class=\"kdx-legend-label\"><div class=\"kdx-label-text\">{{legendItem.label}}</div></div>\r\n                    </div>\r\n                </div> -->\r\n                <div class=\"kdx-legend legend-scroll {{config.legend.layout}}\" *ngIf=\"checkMapScale\">\r\n                    <div class=\"kdx-map-scale-wrapper\">\r\n                        <i class=\"fa fa-caret-down kdx-map-scale-triangle\"></i>\r\n                        <div class=\"kdx-map-scale-container\">\r\n                            <div id=\"mapScale\" class=\"kdx-map-scale\"></div>\r\n                            <div class=\"kdx-map-scale-text-container\"></div>\r\n                        </div>\r\n                    </div>\r\n                </div>\r\n            </div>\r\n        </div>\r\n    </div>\r\n</div>\r\n<div *ngIf=\"config.footer && config.footer.enabled\" class=\"kdx-charts-footer\" [ngClass]=\"{clusterChartMapFooter: markersLegend.length > 0}\">\r\n    <div *ngIf=\"config.footer.bottomLabel && config.footer.bottomLabel.enabled && config.footer.bottomLabel.text && config.footer.bottomLabel.text !== ''\" class=\"kdx-charts-bottom-label {{config.footer.bottomLabel.align}}\" [ngStyle]=\"config.footer.bottomLabel.style\">\r\n        {{config.footer.bottomLabel.text}}\r\n    </div>\r\n    <div *ngIf=\"config.footer.footNote && config.footer.footNote.enabled && config.footer.footNote.text && config.footer.footNote.text !== ''\" class=\"kdx-charts-foot-note {{config.footer.footNote.align}}\" [ngStyle]=\"config.footer.footNote.style\">\r\n        {{config.footer.footNote.text}}\r\n    </div>\r\n</div>\r\n<kd-progressloader *ngIf=\"((chartCategory === 'map' && chartType[1] === 'full') || (chartCategory === 'map' && chartType[1] === 'cluster')) && isLayerLoading\" configtype=\"small-spinner\" [configvalue]=\"smallLoaderValue\"></kd-progressloader>",
            encapsulation: ViewEncapsulation.None,
            providers: [KdChartsSvc, KdSplitterEvent, KdConvertionSvc, KdDomElemSvc, KdDataSvc],
            host: {
                'class': 'kdx-charts',
                '[attr.id]': 'config.id',
                '[class.kdx-charts-axis-invert]': 'chartType[0] === "bar"',
                '[class.kdx-charts-rotate-title-x]': 'rotateTitleX',
                '[class.kdx-charts-rotate-title-y]': 'rotateTitleY',
                '[class.kdx-charts-yAxis-opposite]': 'config.yAxis.opposite',
                '[class.kdx-charts-xAxis-opposite]': 'config.xAxis.opposite',
                '[class.kdx-charts-no-border]': 'havekdChartNoBorderClass',
                '[style.background-color]': 'config.chart.mainArea.style["backgroundColor"]',
                '[style.border-color]': 'config.chart.mainArea.style["borderColor"]',
                '[style.border-width]': 'config.chart.mainArea.style["borderWidth"]',
                '[style.border-radius]': 'config.chart.mainArea.style["borderRadius"]',
                '[style.border-style]': 'config.chart.mainArea.style["borderStyle"]',
                '[style.font-family]': 'config.chart.style.fontFamily',
                '[style.opacity]': 'config.chart.mainArea.style.opacity',
            }
        }),
        __metadata("design:paramtypes", [DomSanitizer,
            ElementRef,
            KdChartsSvc,
            KdConvertionSvc,
            KdDataSvc])
    ], KdCharts);
    return KdCharts;
}());
export { KdCharts };
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoia2QtYW5ndWxhci1jaGFydHMuanMiLCJzb3VyY2VSb290Ijoibmc6Ly9vcGVuZW1pcy1zdHlsZWd1aWRlLWxpYi8iLCJzb3VyY2VzIjpbImtkLWNvbXBvbmVudHMva2QtYW5ndWxhci1jaGFydHMva2QtYW5ndWxhci1jaGFydHMudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IjtBQUFBLE9BQU8sRUFDSCxTQUFTLEVBQ1QsaUJBQWlCLEVBQ2pCLEtBQUssRUFDTCxNQUFNLEVBQ04sWUFBWSxFQUNaLE1BQU0sRUFDTixTQUFTLEVBQ1QsYUFBYSxFQUNiLFVBQVUsRUFDVixTQUFTLEVBQ1osTUFBTSxlQUFlLENBQUM7QUFDdkIsT0FBTyxFQUFFLFlBQVksRUFBRSxNQUFNLDJCQUEyQixDQUFDO0FBR3pELE9BQU8sRUFBRSxlQUFlLEVBQUUsTUFBTSw4QkFBOEIsQ0FBQztBQUMvRCxPQUFPLEVBQUUsZUFBZSxFQUFFLFlBQVksRUFBRSxTQUFTLEVBQUUsTUFBTSxvQkFBb0IsQ0FBQztBQUM5RSxPQUFPLEVBQUUsV0FBVyxFQUFFLE1BQU0seUJBQXlCLENBQUM7QUFDdEQsT0FBTyxFQUFFLGNBQWMsRUFBRSxNQUFNLDRCQUE0QixDQUFDO0FBc0M1RDtJQTZESSxrQkFDWSxVQUF3QixFQUN4QixXQUF1QixFQUN2QixTQUFzQjtJQUM5Qiw0Q0FBNEM7SUFDckMsY0FBK0IsRUFDL0IsUUFBbUI7UUFMbEIsZUFBVSxHQUFWLFVBQVUsQ0FBYztRQUN4QixnQkFBVyxHQUFYLFdBQVcsQ0FBWTtRQUN2QixjQUFTLEdBQVQsU0FBUyxDQUFhO1FBRXZCLG1CQUFjLEdBQWQsY0FBYyxDQUFpQjtRQUMvQixhQUFRLEdBQVIsUUFBUSxDQUFXO1FBbEV2QixtQkFBYyxHQUFZLElBQUksQ0FBQztRQUMvQixxQkFBZ0IsR0FBUSxJQUFJLENBQUM7UUFDN0IsWUFBTyxHQUFlLEVBQUUsQ0FBQztRQUN6QixhQUFRLEdBQWUsRUFBRSxDQUFDO1FBQzFCLG9CQUFlLEdBQVcsU0FBUyxDQUFDO1FBSXBDLGtCQUFhLEdBQVksS0FBSyxDQUFDO1FBRS9CLGdCQUFXLEdBQVksS0FBSyxDQUFDO1FBQzdCLG9CQUFlLEdBQVksS0FBSyxDQUFDO1FBQ2pDLGNBQVMsR0FBa0IsQ0FBQyxFQUFFLENBQUMsQ0FBQztRQUNoQyxpQkFBWSxHQUFZLEtBQUssQ0FBQztRQUM5QixpQkFBWSxHQUFZLEtBQUssQ0FBQztRQUM5QixjQUFTLEdBQVksS0FBSyxDQUFDO1FBQzNCLG9CQUFlLEdBQVksS0FBSyxDQUFDO1FBQ2pDLDJCQUFzQixHQUFZLEtBQUssQ0FBQztRQUN4QyxrQkFBYSxHQUFZLEtBQUssQ0FBQztRQUMvQiw2QkFBd0IsR0FBWSxLQUFLLENBQUM7UUFFMUMsaUJBQVksR0FBUTtZQUN2QixlQUFlLEVBQUUsRUFBRTtZQUNuQixpQkFBaUIsRUFBRSxFQUFFO1NBQ3hCLENBQUM7UUFFSyxRQUFHLEdBQXNCLEVBQUUsQ0FBQztRQUU1QixVQUFLLEdBQVcsRUFBRSxDQUFDO1FBR25CLGtCQUFhLEdBQWUsRUFBRSxDQUFDO1FBRTlCLFdBQU0sR0FBVztZQUNyQixRQUFRLEVBQUUsMkJBQTJCO1lBQ3JDLFNBQVMsRUFBRSwyQkFBMkI7WUFDdEMsT0FBTyxFQUFFLDJCQUEyQjtZQUNwQyxNQUFNLEVBQUUseUNBQXlDO1lBQ2pELE1BQU0sRUFBRSwyQkFBMkI7U0FDdEMsQ0FBQztRQUVNLG1CQUFjLEdBQWtCLEVBQUUsQ0FBQztRQUNuQyx1QkFBa0IsR0FBVyxDQUFDLENBQUM7UUFPL0IsaUJBQVksR0FBWSxLQUFLLENBQUM7UUFNN0Isb0JBQWUsR0FBVyxJQUFJLENBQUM7UUFDOUIscUJBQWdCLEdBQWlELElBQUksWUFBWSxFQUFFLENBQUM7UUFDcEYsZUFBVSxHQUEwQixJQUFJLFlBQVksRUFBRSxDQUFDO1FBQ3ZELGVBQVUsR0FBMEIsSUFBSSxZQUFZLEVBQUUsQ0FBQztRQVU3RCxxRkFBcUY7SUFDekYsQ0FBQztJQUVELDJCQUFRLEdBQVI7UUFDSSxnQ0FBZ0M7UUFDaEMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxJQUFJLENBQUMsV0FBVyxFQUFFLElBQUksQ0FBQyxDQUFDO1FBQ3hDLElBQUksQ0FBQyxJQUFJLENBQUMsU0FBUyxJQUFJLENBQUMsSUFBSSxDQUFDLFdBQVc7WUFBRSxPQUFPO1FBQ2pELElBQUksQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDO1FBQzlCLElBQUksQ0FBQyxPQUFPLEVBQUUsQ0FBQztRQUNmLGlEQUFpRDtRQUNqRCx3QkFBd0I7UUFDeEIsaURBQWlEO1FBQ2pELHFEQUFxRDtJQUN6RCxDQUFDO0lBRUQsOEJBQVcsR0FBWCxVQUFZLGNBQTZCO1FBQ3JDLElBQUksY0FBYyxDQUFDLGNBQWMsQ0FBQyxhQUFhLENBQUMsSUFBSSxDQUFDLGNBQWMsQ0FBQyxhQUFhLENBQUMsQ0FBQyxXQUFXLEVBQUU7WUFDNUYsSUFBSSxjQUFjLENBQUMsYUFBYSxDQUFDLENBQUMsWUFBWSxLQUFLLElBQUksQ0FBQyxNQUFNO2dCQUFFLE9BQU87WUFDdkUsSUFBSSxDQUFDLFVBQVUsQ0FBQyxjQUFjLENBQUMsV0FBVyxDQUFDLFlBQVksQ0FBQyxDQUFDO1NBQzVEO1FBQ0QsSUFBSSxjQUFjLENBQUMsY0FBYyxDQUFDLFdBQVcsQ0FBQyxJQUFJLENBQUMsY0FBYyxDQUFDLFdBQVcsQ0FBQyxDQUFDLFdBQVcsRUFBRTtZQUN4RixJQUFJLGNBQWMsQ0FBQyxXQUFXLENBQUMsQ0FBQyxZQUFZLEtBQUssSUFBSSxDQUFDLElBQUk7Z0JBQUUsT0FBTztZQUNuRSxJQUFJLENBQUMsUUFBUSxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsRUFBRSxFQUFFLGNBQWMsQ0FBQyxTQUFTLENBQUMsWUFBWSxDQUFDLENBQUMsQ0FBQztTQUMzRTtJQUNMLENBQUM7SUFFRCw4QkFBVyxHQUFYO1FBQ0ksSUFBSSxDQUFDLElBQUksQ0FBQyxTQUFTLElBQUksQ0FBQyxJQUFJLENBQUMsV0FBVztZQUFFLE9BQU87UUFDakQsb0RBQW9EO1FBQ3BELDBCQUEwQjtJQUM5QixDQUFDO0lBRUQ7Ozs7T0FJRztJQUNJLGdDQUFhLEdBQXBCLFVBQXFCLFdBQTJDO1FBQzVELElBQUksQ0FBQyxVQUFVLEdBQUcsTUFBTSxDQUFDLE1BQU0sQ0FBQyxFQUFFLEVBQUUsV0FBVyxDQUFDLENBQUM7SUFDckQsQ0FBQztJQUVEOztPQUVHO0lBQ0ssMEJBQU8sR0FBZjtRQUFBLGlCQXdCQztRQXZCRyxJQUFJLE9BQU8sSUFBSSxDQUFDLFFBQVEsS0FBSyxXQUFXO1lBQUUsT0FBTztRQUVqRCxJQUFJLENBQUMsUUFBUSxDQUFDLGlCQUFpQixHQUFHLFVBQUMsUUFBZ0IsRUFBRSxLQUFhLEVBQUUsS0FBYztZQUM5RSxJQUFJLE9BQU8sS0FBSyxLQUFLLFFBQVE7Z0JBQUUsS0FBSSxDQUFDLGtCQUFrQixDQUFDLEtBQUssRUFBRSxLQUFLLENBQUMsQ0FBQztZQUNyRSxLQUFJLENBQUMsVUFBVSxDQUFDLFFBQVEsQ0FBQyxDQUFDLEtBQUssR0FBRyxLQUFLLENBQUM7WUFDeEMsS0FBSSxDQUFDLDBCQUEwQixDQUFDLFFBQVEsRUFBRSxLQUFLLENBQUMsQ0FBQztZQUNqRCxLQUFJLENBQUMsR0FBRyxDQUFDLE1BQU0sRUFBRSxDQUFDO1FBQ3RCLENBQUMsQ0FBQztRQUVGLElBQUksQ0FBQyxRQUFRLENBQUMsTUFBTSxHQUFHLGNBQU0sT0FBQSxLQUFJLENBQUMsR0FBRyxDQUFDLE1BQU0sRUFBRSxFQUFqQixDQUFpQixDQUFDO1FBRS9DLCtEQUErRDtRQUMvRCwyQkFBMkI7UUFDM0IsZ0NBQWdDO1FBQ2hDLDREQUE0RDtRQUM1RCxzR0FBc0c7UUFDdEcsWUFBWTtRQUNaLGVBQWU7UUFDZixrQ0FBa0M7UUFDbEMsNERBQTREO1FBQzVELDhDQUE4QztRQUM5QyxRQUFRO1FBQ1IsS0FBSztJQUNULENBQUM7SUFFRCxnRkFBZ0Y7SUFFaEYsNEJBQTRCO0lBQzVCLCtEQUErRDtJQUMvRCxJQUFJO0lBRUosOEJBQThCO0lBQzlCLGtFQUFrRTtJQUNsRSxJQUFJO0lBRUosOEJBQThCO0lBQzlCLHlDQUF5QztJQUN6QywrQ0FBK0M7SUFDL0MsNkJBQTZCO0lBQzdCLGVBQWU7SUFDZixJQUFJO0lBRUosNkZBQTZGO0lBRTdGLHVFQUF1RTtJQUN2RSxtQ0FBbUM7SUFFbkMsZ0RBQWdEO0lBRWhELGdGQUFnRjtJQUNoRiw2Q0FBNkM7SUFDN0MsaUNBQWlDO0lBQ2pDLGNBQWM7SUFDZCxVQUFVO0lBQ1YsbUZBQW1GO0lBQ25GLDZDQUE2QztJQUM3QyxpQ0FBaUM7SUFDakMsY0FBYztJQUNkLFVBQVU7SUFDVixnREFBZ0Q7SUFDaEQsaUJBQWlCO0lBQ2pCLGdDQUFnQztJQUNoQyxZQUFZO0lBQ1osbUNBQW1DO0lBQ25DLGlDQUFpQztJQUNqQyxjQUFjO0lBRWQsMkNBQTJDO0lBQzNDLDJDQUEyQztJQUMzQyx5Q0FBeUM7SUFFekMsOEJBQThCO0lBQzlCLElBQUk7SUFFSixzRUFBc0U7SUFDdEUsaURBQWlEO0lBQ2pELGlEQUFpRDtJQUNqRCx3REFBd0Q7SUFDeEQsVUFBVTtJQUNWLElBQUk7SUFFSix1RkFBdUY7SUFFL0UsNkJBQVUsR0FBbEIsVUFBbUIsT0FBcUIsRUFBRSxjQUF3QjtRQUM5RCxtQ0FBbUM7UUFDbkMsSUFBSSxDQUFDLE1BQU0sR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsY0FBYyxDQUFDLENBQUMsQ0FBQztRQUN6RCxJQUFJLENBQUMsUUFBUSxDQUFDLGlCQUFpQixDQUFDLElBQUksQ0FBQyxNQUFNLEVBQUUsT0FBTyxJQUFJLEVBQUUsQ0FBQyxDQUFDO1FBRTVELHdHQUF3RztRQUN4RyxJQUFJLGNBQWM7WUFBRSxPQUFPO1FBRTNCLElBQUksQ0FBQyxhQUFhLENBQUMsT0FBTyxDQUFDLENBQUM7UUFFNUIsSUFBSSxDQUFDLGFBQWEsR0FBRyxLQUFLLENBQUM7UUFFM0IsSUFBSSxDQUFDLGNBQWMsRUFBRSxDQUFDO1FBRXRCLElBQUksQ0FBQyxtQkFBbUIsRUFBRSxDQUFDO1FBRTNCLElBQUksQ0FBQyxjQUFjLEVBQUUsQ0FBQztRQUd0QixvQ0FBb0M7UUFDcEMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxNQUFNLEdBQUcsT0FBTyxDQUFDO0lBQ3BDLENBQUM7SUFFTSxnQ0FBYSxHQUFwQixVQUFxQixPQUFxQjtRQUN0QyxJQUFJLENBQUMsd0JBQXdCLEdBQUcsQ0FBQyxPQUFPLENBQUMsS0FBSyxDQUFDLFFBQVEsQ0FBQyxLQUFLLENBQUMsYUFBYSxDQUFDLENBQUM7UUFDN0UsSUFBSSxPQUFPLENBQUMsS0FBSyxDQUFDLFFBQVEsQ0FBQyxLQUFLLENBQUMsYUFBYSxDQUFDLElBQUksT0FBTyxDQUFDLEtBQUssQ0FBQyxRQUFRLENBQUMsS0FBSyxDQUFDLGFBQWEsQ0FBQyxLQUFLLEtBQUssRUFBRTtZQUN0RyxJQUFJLENBQUMsd0JBQXdCLEdBQUcsSUFBSSxDQUFDO1NBQ3hDO0lBQ0wsQ0FBQztJQUVELG9GQUFvRjtJQUM1RSxpQ0FBYyxHQUF0QjtRQUVJLG9EQUFvRDtRQUNwRCxJQUFJLENBQUMsWUFBWSxDQUFDLGVBQWUsQ0FBQyxHQUFHLEVBQUUsQ0FBQztRQUN4QyxJQUFJLENBQUMsWUFBWSxDQUFDLGlCQUFpQixDQUFDLEdBQUcsRUFBRSxDQUFDO1FBRTFDLElBQUksT0FBTyxJQUFJLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxLQUFLLEtBQUssU0FBUyxJQUFJLElBQUksQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLEtBQUssRUFBRTtZQUMzRSxJQUFJLENBQUMsWUFBWSxDQUFDLGFBQWEsSUFBSSxlQUFlLENBQUM7WUFDbkQsSUFBSSxDQUFDLFlBQVksQ0FBQyxlQUFlLElBQUksZUFBZSxDQUFDO1NBQ3hEO1FBRUQsSUFBSSxPQUFPLElBQUksQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLGFBQWEsS0FBSyxTQUFTLEVBQUU7WUFDdkQsSUFBSSxDQUFDLFlBQVksQ0FBQyxhQUFhLElBQUksSUFBSSxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsYUFBYSxHQUFHLEdBQUcsQ0FBQztZQUMxRSxJQUFJLENBQUMsWUFBWSxDQUFDLGVBQWUsSUFBSSxJQUFJLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxhQUFhLEdBQUcsR0FBRyxDQUFDO1NBQy9FO1FBRUQsSUFBSSxPQUFPLElBQUksQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLEtBQUssS0FBSyxTQUFTLEVBQUU7WUFDL0MsSUFBSSxDQUFDLFlBQVksQ0FBQyxhQUFhLElBQUksSUFBSSxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsS0FBSyxHQUFHLEdBQUcsQ0FBQztZQUNsRSxJQUFJLENBQUMsWUFBWSxDQUFDLGVBQWUsSUFBSSxJQUFJLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxLQUFLLEdBQUcsR0FBRyxDQUFDO1NBQ3ZFO1FBRUQsSUFBSSxJQUFJLENBQUMsYUFBYSxLQUFLLEtBQUssSUFBSSxJQUFJLENBQUMsYUFBYSxLQUFLLEtBQUs7WUFBRSxPQUFPO1FBQ3pFLElBQUksQ0FBQyxhQUFhLEdBQUcsSUFBSSxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsUUFBUSxDQUFDO1FBRWhELHVEQUF1RDtRQUN2RCxJQUFJLENBQUMsWUFBWSxHQUFHLElBQUksQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLEtBQUssS0FBSyxJQUFJLElBQUksQ0FBQyxTQUFTLENBQUMsdUJBQXVCLENBQUMsSUFBSSxDQUFDLFNBQVMsRUFBRSxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUM7UUFDdkgsSUFBSSxDQUFDLFlBQVksR0FBRyxJQUFJLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxLQUFLLEtBQUssSUFBSSxJQUFJLENBQUMsU0FBUyxDQUFDLHVCQUF1QixDQUFDLElBQUksQ0FBQyxTQUFTLEVBQUUsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDO1FBRXZILHlFQUF5RTtRQUN6RSxJQUFJLENBQUMsZUFBZSxHQUFHLElBQUksQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLEtBQUssS0FBSyxDQUFDO1FBQ25ELElBQUksQ0FBQyxzQkFBc0IsR0FBRyxJQUFJLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsTUFBTSxHQUFHLENBQUMsQ0FBQyxLQUFLLE9BQU8sQ0FBQztRQUNwRixJQUFJLENBQUMsZUFBZSxHQUFHLENBQUMsSUFBSSxDQUFDLGFBQWEsS0FBSyxLQUFLLElBQUksSUFBSSxDQUFDLGFBQWEsS0FBSyxRQUFRLENBQUUsSUFBSSxJQUFJLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxLQUFLLE9BQU8sSUFBSSxJQUFJLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxLQUFLLFVBQVUsQ0FBQztJQUNuSyxDQUFDO0lBRU8sNkNBQTBCLEdBQWxDLFVBQW1DLFNBQVMsRUFBRSxNQUFlO1FBQ3pELElBQUksUUFBUSxHQUFXLFNBQVMsRUFBRSxZQUF5QixDQUFDO1FBQzVELGtEQUFrRDtRQUNsRCxJQUFJLENBQUMsUUFBUSxFQUFFO1lBQ1gsZ0NBQWdDO1lBQ2hDLElBQUksTUFBTSxLQUFLLElBQUksSUFBSSxNQUFNLEtBQUssU0FBUztnQkFBRSxPQUFPO1lBQ3BELFFBQVEsR0FBRyxJQUFJLENBQUMsVUFBVSxDQUFDLE1BQU0sQ0FBQyxDQUFDO1NBQ3RDO1FBQ0QsWUFBWSxHQUFHLElBQUksQ0FBQyxVQUFVLENBQUMsUUFBUSxDQUFDLENBQUM7UUFDekMsSUFBSSxDQUFDLGlCQUFpQixDQUFDLFFBQVEsRUFBRSxZQUFZLENBQUMsQ0FBQztJQUNuRCxDQUFDO0lBR08sc0NBQW1CLEdBQTNCLFVBQTRCLEtBQWM7UUFDdEMsSUFBSSxDQUFDLElBQUksQ0FBQyxVQUFVO1lBQUUsT0FBTztRQUU3QixJQUFJLENBQUMsVUFBVSxHQUFHLE1BQU0sQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxDQUFDO1FBRS9DLEtBQUssSUFBSSxDQUFDLEdBQVcsQ0FBQyxFQUFFLENBQUMsR0FBRyxJQUFJLENBQUMsVUFBVSxDQUFDLE1BQU0sRUFBRSxDQUFDLEVBQUUsRUFBRTtZQUNyRCxJQUFJLFFBQVEsR0FBVyxJQUFJLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQyxDQUFDO1lBQzFDLElBQUksWUFBWSxHQUFnQixJQUFJLENBQUMsVUFBVSxDQUFDLFFBQVEsQ0FBQyxDQUFDO1lBRTFELG9EQUFvRDtZQUNwRCx1RkFBdUY7WUFDdkYsbURBQW1EO1lBQ25ELG9EQUFvRDtZQUNwRCx5REFBeUQ7WUFDekQsd0ZBQXdGO1lBQ3hGLG1EQUFtRDtZQUVuRCwrREFBK0Q7WUFDL0QsdURBQXVEO1lBRXZELDZQQUE2UDtZQUM3UCwrRUFBK0U7WUFFL0UsbURBQW1EO1lBQ25ELElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxRQUFRLEVBQUUsWUFBWSxDQUFDLENBQUM7U0FDbEQ7SUFDTCxDQUFDO0lBRU8saUNBQWMsR0FBdEI7UUFDSSxJQUFJLElBQUksQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxPQUFPLEVBQUU7WUFDbEMsSUFBSSxVQUFVLEdBQVcsSUFBSSxDQUFDLFNBQVMsQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxDQUFDO1lBRWpGLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxVQUFVLEVBQUUsT0FBTyxFQUFFLElBQUksQ0FBQyxDQUFDO1NBQ3BEO0lBQ0wsQ0FBQztJQUVPLDJCQUFRLEdBQWhCLFVBQWlCLEtBQVU7UUFDdkIsSUFBSSxDQUFDLGNBQWMsR0FBRyxFQUFFLENBQUM7UUFDekIsSUFBSSxDQUFDLGFBQWEsR0FBRyxFQUFFLENBQUM7UUFDeEIsSUFBSSxDQUFDLGFBQWEsQ0FBQyxLQUFLLENBQUMsQ0FBQztRQUUxQixJQUFJLElBQUksQ0FBQyxNQUFNLENBQUMsV0FBVyxFQUFFO1lBQ3pCLElBQUksQ0FBQyxJQUFJLEdBQUcsS0FBSyxDQUFDO1lBQ2xCLElBQUksQ0FBQyxVQUFVLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDO1lBQzdCLE9BQU87U0FDVjtRQUVELElBQUksSUFBSSxDQUFDLGFBQWEsS0FBSyxLQUFLLElBQUksSUFBSSxDQUFDLGFBQWEsS0FBSyxLQUFLLEVBQUU7WUFDOUQsSUFBSSxJQUFJLENBQUMsYUFBYSxLQUFLLEtBQUs7Z0JBQUUsSUFBSSxDQUFDLGtCQUFrQixDQUFDLEtBQUssQ0FBQyxDQUFDO2lCQUM1RCxJQUFJLElBQUksQ0FBQyxhQUFhLEtBQUssS0FBSztnQkFBRSxJQUFJLENBQUMsa0JBQWtCLENBQUMsS0FBSyxDQUFDLENBQUM7WUFDdEUsNERBQTREO1lBQzVELElBQUksQ0FBQyxVQUFVLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDO1NBQ2hDOztZQUFNLElBQUksQ0FBQyxZQUFZLENBQUMsS0FBSyxDQUFDLENBQUM7UUFFaEMsc0RBQXNEO1FBQ3RELElBQUksQ0FBQyxVQUFVLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQztRQUVoQyxnRUFBZ0U7UUFDaEUsSUFBSSxDQUFDLGdCQUFnQixDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLENBQUM7SUFDaEQsQ0FBQztJQUVPLGdDQUFhLEdBQXJCLFVBQXNCLEtBQUs7UUFDdkIsSUFBSSxTQUFTLEdBQVEsS0FBSyxDQUFDO1FBQzNCLElBQUksQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLFdBQVcsSUFBSSxDQUFDLEtBQUssQ0FBQyxLQUFLLElBQUksS0FBSyxDQUFDLEtBQUssQ0FBQyxJQUFJLElBQUksS0FBSyxDQUFDLEVBQUU7WUFDeEUsU0FBUyxHQUFHLEtBQUssQ0FBQyxLQUFLLENBQUM7U0FDM0I7UUFDRCxJQUFJLENBQUMsYUFBYSxHQUFHLFNBQVMsQ0FBQyxJQUFJLENBQUM7UUFDcEMsSUFBSSxDQUFDLFNBQVMsR0FBRyxTQUFTLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FBQztRQUM3QyxJQUFJLENBQUMsV0FBVyxHQUFHLFNBQVMsQ0FBQyxJQUFJLEtBQUssS0FBSyxJQUFJLFNBQVMsQ0FBQyxJQUFJLEtBQUssS0FBSyxDQUFDO0lBQzVFLENBQUM7SUFFTyxxQ0FBa0IsR0FBMUIsVUFBMkIsTUFBYyxFQUFFLE1BQWM7UUFDckQsSUFBSSxNQUFNLEdBQUcsQ0FBQyxFQUFFO1lBQUUsT0FBTztTQUFFO1FBQzNCLDRJQUE0STtRQUM1SSxJQUFJLFNBQVMsR0FBa0IsTUFBTSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLENBQUM7UUFDNUQsSUFBSSxJQUFJLENBQUMsYUFBYSxJQUFJLEtBQUssRUFBRTtZQUM3QixLQUFLLElBQUksTUFBTSxHQUFXLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLE1BQU0sR0FBRyxDQUFDLEVBQUUsTUFBTSxJQUFJLENBQUMsRUFBRSxNQUFNLEVBQUUsRUFBRTtnQkFDeEUsS0FBSyxJQUFJLE1BQU0sR0FBVyxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxHQUFHLENBQUMsRUFBRSxNQUFNLElBQUksQ0FBQyxFQUFFLE1BQU0sRUFBRSxFQUFFO29CQUNsRixJQUFJLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxFQUFFLEtBQUssU0FBUyxDQUFDLE1BQU0sQ0FBQyxFQUFFO3dCQUMzRCxJQUFJLENBQUMsYUFBYSxDQUFDLE1BQU0sRUFBRSxNQUFNLEVBQUUsT0FBTyxDQUFDLENBQUM7d0JBQzVDLElBQUksQ0FBQyxhQUFhLENBQUMsTUFBTSxFQUFFLE1BQU0sRUFBRSxPQUFPLENBQUMsQ0FBQztxQkFDL0M7aUJBQ0o7YUFDSjtTQUNKO0lBQ0wsQ0FBQztJQUVPLGdDQUFhLEdBQXJCLFVBQXNCLE9BQWUsRUFBRSxPQUFlLEVBQUUsUUFBMkI7UUFDL0UsSUFBSSxRQUFRLEdBQVcsSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLEVBQUUsQ0FBQztRQUM3RCxJQUFJLE1BQU0sR0FBUSxJQUFJLENBQUMsVUFBVSxDQUFDLFFBQVEsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDO1FBQ3RELElBQUksUUFBUSxLQUFLLE9BQU8sRUFBRTtZQUN0QixNQUFNLEdBQUcsSUFBSSxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsQ0FBQztTQUNoQztRQUNELElBQUksSUFBSSxDQUFDLGVBQWUsQ0FBQyxPQUFPLEVBQUUsT0FBTyxFQUFFLFFBQVEsQ0FBQyxFQUFFO1lBQ2xELElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxRQUFRLENBQUMsR0FBRyxNQUFNLENBQUM7U0FDekQ7SUFDTCxDQUFDO0lBRU8sa0NBQWUsR0FBdkIsVUFBd0IsT0FBZSxFQUFFLE9BQWUsRUFBRSxRQUEyQjtRQUNqRixJQUFJLFlBQVksR0FBWSxJQUFJLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxjQUFjLENBQUMsd0JBQXdCLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsc0JBQXNCLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQztRQUN6SSxJQUFJLFlBQVksRUFBRTtZQUNkLE9BQU8sSUFBSSxDQUFDO1NBQ2Y7YUFBTTtZQUNILElBQUksSUFBSSxDQUFDLFNBQVMsQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxDQUFDLGNBQWMsQ0FBQyxRQUFRLENBQUMsRUFBRTtnQkFDdkUsSUFBSSxJQUFJLENBQUMsU0FBUyxDQUFDLE1BQU0sQ0FBQyxPQUFPLENBQUMsQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLENBQUMsUUFBUSxDQUFDLEtBQUssSUFBSSxJQUFJLElBQUksQ0FBQyxTQUFTLENBQUMsTUFBTSxDQUFDLE9BQU8sQ0FBQyxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxNQUFNLEdBQUcsQ0FBQyxFQUFFO29CQUN0SSxPQUFPLEtBQUssQ0FBQztpQkFDaEI7YUFDSjtTQUNKO1FBQ0QsT0FBTyxJQUFJLENBQUM7SUFDaEIsQ0FBQztJQUVNLGdDQUFhLEdBQXBCLFVBQXFCLEdBQVc7UUFDNUIsSUFBSSxZQUFZLEdBQWdCLElBQUksQ0FBQyxVQUFVLENBQUMsR0FBRyxDQUFDLENBQUM7UUFFckQsWUFBWSxDQUFDLFFBQVEsR0FBRyxDQUFDLFlBQVksQ0FBQyxRQUFRLElBQUksS0FBSyxDQUFDO1FBRXhELElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxHQUFHLEVBQUUsWUFBWSxDQUFDLENBQUM7UUFFMUMsSUFBSSxZQUFZLENBQUMsUUFBUSxFQUFFO1lBQ3ZCLElBQUksQ0FBQyxjQUFjLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFDO1NBQ2pDO2FBQU07WUFDSCxJQUFJLE9BQU8sR0FBVyxJQUFJLENBQUMsY0FBYyxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsQ0FBQztZQUN2RCxJQUFJLE9BQU8sS0FBSyxDQUFDLENBQUMsRUFBRTtnQkFDaEIsSUFBSSxDQUFDLGNBQWMsQ0FBQyxNQUFNLENBQUMsT0FBTyxFQUFFLENBQUMsQ0FBQyxDQUFDO2FBQzFDO1NBQ0o7UUFFRCxJQUFJLElBQUksQ0FBQyxhQUFhLElBQUksS0FBSyxFQUFFO1lBQzdCLElBQUksVUFBVSxHQUFtQyxJQUFJLENBQUMsWUFBWSxFQUFFLENBQUM7WUFDckUsSUFBSSxJQUFJLEdBQVksSUFBSSxDQUFDLFVBQVUsQ0FBQyxVQUFVLENBQUMsQ0FBQztZQUVoRCxJQUFJLENBQUMsR0FBRyxDQUFDLFdBQVcsQ0FBQyxJQUFJLEVBQUUsVUFBVSxDQUFDLENBQUM7WUFDdkMsSUFBSSxDQUFDLGdCQUFnQixDQUFDLEdBQUcsRUFBRSxZQUFZLENBQUMsUUFBUSxDQUFDLENBQUM7WUFDbEQsMkRBQTJEO1lBQzNELElBQUksQ0FBQyxVQUFVLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDO1NBQzlCO2FBQU07WUFDSCxJQUFJLENBQUMsR0FBRyxDQUFDLFdBQVcsQ0FBQyxHQUFHLEVBQUUsWUFBWSxDQUFDLFFBQVEsQ0FBQyxDQUFDO1NBQ3BEO0lBRUwsQ0FBQztJQUVNLGlDQUFjLEdBQXJCLFVBQXNCLEdBQVE7UUFDMUIsSUFBSSxnQkFBZ0IsR0FBZ0IsSUFBSSxDQUFDLFdBQVcsQ0FBQyxhQUFhLENBQUMsYUFBYSxDQUFDLFFBQVEsR0FBRyxHQUFHLENBQUMsRUFBRSxHQUFHLGtCQUFrQixDQUFDLENBQUM7UUFDekgsSUFBSSxlQUFlLEdBQWdCLElBQUksQ0FBQyxXQUFXLENBQUMsYUFBYSxDQUFDLGFBQWEsQ0FBQyxRQUFRLEdBQUcsR0FBRyxDQUFDLEVBQUUsR0FBRyxvQkFBb0IsQ0FBQyxDQUFDO1FBRTFILElBQUksQ0FBQyxHQUFHLENBQUMsWUFBWSxDQUFDLEdBQUcsRUFBRSxFQUFDLGtCQUFrQixFQUFFLGdCQUFnQixFQUFFLGlCQUFpQixFQUFFLGVBQWUsRUFBQyxDQUFDLENBQUM7SUFDM0csQ0FBQztJQUVNLGtDQUFlLEdBQXRCLFVBQXVCLFdBQTJDO1FBQzlELElBQUksSUFBSSxDQUFDLGFBQWEsSUFBSSxLQUFLLElBQUksTUFBTSxDQUFDLElBQUksQ0FBQyxXQUFXLENBQUMsQ0FBQyxNQUFNLElBQUksQ0FBQyxFQUFFO1lBQ3JFLElBQUksQ0FBQyxhQUFhLEdBQUcsSUFBSSxDQUFDO1NBQzdCO2FBQU07WUFDSCxJQUFJLENBQUMsVUFBVSxHQUFHLFdBQVcsQ0FBQztZQUM5QixJQUFJLENBQUMsYUFBYSxHQUFHLEtBQUssQ0FBQztZQUMzQixJQUFJLENBQUMsWUFBWSxHQUFHLElBQUksQ0FBQztZQUN6QixJQUFJLENBQUMsZ0JBQWdCLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsQ0FBQztZQUM1QyxJQUFJLENBQUMsbUJBQW1CLENBQUMsU0FBUyxDQUFDLENBQUM7U0FDdkM7SUFDTCxDQUFDO0lBRU0sZ0NBQWEsR0FBcEIsVUFBcUIsS0FBVTtRQUMzQiwrQkFBK0I7UUFDL0IsSUFBSSxDQUFDLFVBQVUsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLENBQUM7SUFDaEMsQ0FBQztJQUVNLDJCQUFRLEdBQWYsVUFBZ0IsTUFBZTtRQUMzQixJQUFJLENBQUMsY0FBYyxHQUFHLE1BQU0sQ0FBQztJQUNqQyxDQUFDO0lBRU8sb0NBQWlCLEdBQXpCLFVBQTBCLEdBQUcsRUFBRSxhQUFhO1FBQ3hDLElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxHQUFHLEVBQUUsYUFBYSxDQUFDLENBQUM7UUFDM0MsSUFBSSxTQUFTLEdBQVcsQ0FBQyxhQUFhLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxhQUFhLElBQUksU0FBUyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLEtBQUssSUFBSSxJQUFJLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsV0FBVyxJQUFJLFNBQVMsQ0FBQztRQUNoTSxJQUFJLENBQUMsV0FBVyxDQUFDLGFBQWEsQ0FBQyxhQUFhLENBQUMsUUFBUSxHQUFHLEdBQUcsQ0FBQyxDQUFDLEtBQUssQ0FBQyxLQUFLLEdBQUcsU0FBUyxDQUFDO0lBQ3pGLENBQUM7SUFFTyxvQ0FBaUIsR0FBekIsVUFBMEIsR0FBRyxFQUFFLGFBQWE7UUFDeEMsSUFBSSxTQUFTLEdBQVcsQ0FBQyxhQUFhLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxhQUFhLElBQUksU0FBUyxDQUFDLENBQUMsQ0FBQyxhQUFhLENBQUMsS0FBSyxJQUFJLFNBQVMsQ0FBQztRQUN6SSxJQUFJLFFBQVEsR0FBVyxJQUFJLENBQUMsY0FBYyxDQUFDLFVBQVUsQ0FBQyxTQUFTLENBQUMsQ0FBQztRQUNqRSxJQUFJLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxHQUFHLElBQUksQ0FBQyxVQUFVLENBQUMsOEJBQThCLENBQUMsd0VBQXdFLEdBQUcsUUFBUSxHQUFHLGtDQUFrQyxHQUFHLElBQUksQ0FBQyxNQUFNLENBQUMsYUFBYSxDQUFDLEtBQUssQ0FBQyxHQUFHLFdBQVcsQ0FBQyxDQUFDO0lBQ2hQLENBQUM7SUFFTyxtQ0FBZ0IsR0FBeEIsVUFBeUIsRUFBVSxFQUFFLFFBQWlCO1FBQ2xELElBQUksWUFBWSxHQUFXLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDO1FBQ3hELElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxZQUFZLEVBQUUsS0FBSyxHQUFHLEVBQUUsQ0FBQyxDQUFDO1FBQ2hELElBQUksQ0FBQyxRQUFRO1lBQUUsSUFBSSxDQUFDLGdCQUFnQixDQUFDLFVBQVUsR0FBRyxZQUFZLEVBQUUsS0FBSyxHQUFHLEVBQUUsR0FBRyxPQUFPLEVBQUUsSUFBSSxDQUFDLENBQUM7SUFDaEcsQ0FBQztJQUVPLG1DQUFnQixHQUF4QixVQUF5QixNQUFjLEVBQUUsTUFBYyxFQUFFLGVBQXlCO1FBQzlFLE1BQU0sR0FBRyxNQUFNLElBQUksRUFBRSxDQUFDO1FBQ3RCLElBQUksUUFBUSxHQUFnQixJQUFJLENBQUMsV0FBVyxDQUFDLGFBQWEsQ0FBQyxnQkFBZ0IsQ0FBQyxHQUFHLEdBQUcsSUFBSSxDQUFDLE1BQU0sQ0FBQyxFQUFFLEdBQUcseUJBQXlCLEdBQUcsTUFBTSxDQUFDLENBQUM7UUFDdkksS0FBSyxJQUFJLENBQUMsSUFBSSxRQUFRLEVBQUU7WUFDcEIsSUFBSSxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxFQUFFO2dCQUVuQixJQUFJLGVBQWUsRUFBRTtvQkFDakIsSUFBSSxVQUFVLEdBQVcsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLFdBQVcsQ0FBQztvQkFDakQsSUFBSSxXQUFXLEdBQVcsQ0FBQyxVQUFVLEdBQUcsVUFBVSxHQUFHLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUMsUUFBUSxFQUFFLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDO29CQUNsRyxJQUFJLGFBQWEsR0FBVyxDQUFDLEdBQUcsV0FBVyxDQUFDO29CQUU1QyxNQUFNLElBQUksT0FBTyxHQUFHLGFBQWEsR0FBRyxLQUFLLENBQUM7b0JBQzFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLEdBQUcsTUFBTSxDQUFDO2lCQUM5QjtxQkFBTTtvQkFDSCxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLE9BQU8sR0FBRyxNQUFNLENBQUM7aUJBQ3RDO2FBQ0o7U0FDSjtJQUNMLENBQUM7SUFFTywrQkFBWSxHQUFwQjtRQUNJLElBQUksVUFBVSxHQUFtQyxNQUFNLENBQUMsTUFBTSxDQUFDLEVBQUUsRUFBRSxJQUFJLENBQUMsVUFBVSxDQUFDLENBQUM7UUFDcEYsSUFBSSxjQUFjLEdBQWtCLElBQUksQ0FBQyxjQUFjLENBQUM7UUFDeEQsVUFBVSxHQUFHLE1BQU0sQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDO2FBQy9CLE1BQU0sQ0FBQyxVQUFBLEdBQUcsSUFBSSxPQUFBLENBQUMsY0FBYyxDQUFDLFFBQVEsQ0FBQyxHQUFHLENBQUMsRUFBN0IsQ0FBNkIsQ0FBQzthQUM1QyxNQUFNLENBQUMsVUFBQyxHQUFHLEVBQUUsR0FBRztZQUNiLEdBQUcsQ0FBQyxHQUFHLENBQUMsR0FBRyxVQUFVLENBQUMsR0FBRyxDQUFDLENBQUM7WUFDM0IsT0FBTyxHQUFHLENBQUM7UUFDZixDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUM7UUFDWCxPQUFPLFVBQVUsQ0FBQztJQUN0QixDQUFDO0lBRU8sNkJBQVUsR0FBbEIsVUFBbUIsV0FBNEM7UUFDM0QsSUFBSSxRQUFRLEdBQVksSUFBSSxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDO1FBQzlELElBQUksY0FBYyxHQUFrQixJQUFJLENBQUMsY0FBYyxDQUFDO1FBRXhELElBQUksSUFBSSxDQUFDLGFBQWEsS0FBSyxLQUFLLEVBQUU7WUFDOUIsSUFBSSxZQUFVLEdBQVEsV0FBVyxDQUFDO1lBQ2xDLDBDQUEwQztZQUMxQyxRQUFRLENBQUMsSUFBSSxHQUFHLE1BQU0sQ0FBQyxJQUFJLENBQUMsWUFBVSxDQUFDLENBQUMsR0FBRyxDQUFDLFVBQUEsR0FBRyxJQUFJLE9BQUEsWUFBVSxDQUFDLEdBQUcsQ0FBQyxFQUFmLENBQWUsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxVQUFDLEtBQUssSUFBSyxPQUFBLEtBQUssQ0FBQyxDQUFDLElBQUksS0FBSyxDQUFDLENBQUMsR0FBRyxDQUFDLEVBQXRCLENBQXNCLENBQUMsQ0FBQztZQUM5RyxPQUFPLFFBQVEsQ0FBQztTQUNuQjthQUFNLElBQUksSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsS0FBSyxLQUFLLElBQUksSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsS0FBSyxNQUFNLEVBQUU7WUFDcEUsS0FBSyxJQUFJLENBQUMsR0FBVyxRQUFRLENBQUMsSUFBSSxDQUFDLE1BQU0sR0FBRyxDQUFDLEVBQUUsQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRTtnQkFDeEQsSUFBSSxPQUFPLEdBQW9CLFFBQVEsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxVQUFBLENBQUMsSUFBSSxPQUFBLENBQUMsY0FBYyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQTlCLENBQThCLENBQUMsQ0FBQztnQkFDOUYsUUFBUSxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsR0FBRyxNQUFNLENBQUMsTUFBTSxDQUFDLEVBQUUsRUFBRSxRQUFRLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxFQUFFLE9BQU8sRUFBRSxDQUFDLENBQUM7YUFDMUU7U0FDSjtRQUVELElBQUksWUFBWSxHQUFZLElBQUksQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDO1FBRWpFLElBQUksWUFBWSxHQUFrQixDQUFDLENBQUMsQ0FBQyxDQUFDO1FBQ3RDLElBQUksWUFBWSxHQUFrQixDQUFDLENBQUMsQ0FBQyxDQUFDO1FBQ3RDLElBQUksWUFBWSxHQUFZLEtBQUssQ0FBQztRQUVsQyxLQUFLLElBQUksQ0FBQyxHQUFXLENBQUMsRUFBRSxDQUFDLEdBQUcsWUFBWSxDQUFDLElBQUksQ0FBQyxNQUFNLEVBQUUsQ0FBQyxFQUFFLEVBQUU7WUFDdkQsSUFBSSxRQUFRLEdBQVcsQ0FBQyxDQUFDO1lBQ3pCLElBQUksSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsS0FBSyxLQUFLLEVBQUU7Z0JBQzdCLFFBQVEsR0FBRyxRQUFRLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsVUFBQyxHQUFHLEVBQUUsSUFBSSxFQUFFLE1BQU07b0JBQ25ELElBQUksY0FBYyxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDO3dCQUFFLE9BQU8sR0FBRyxDQUFDO29CQUNqRCxPQUFPLEdBQUcsR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDO2dCQUM1QixDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUM7YUFDVDtZQUVELElBQUksT0FBTyxHQUFlLEVBQUUsQ0FBQztZQUM3QixJQUFJLE1BQU0sR0FBa0IsRUFBRSxDQUFDO1lBQy9CLElBQUksR0FBRyxHQUFXLENBQUMsQ0FBQztZQUNwQixJQUFJLFdBQVcsR0FBVyxDQUFDLENBQUM7WUFFNUIsS0FBSyxJQUFJLE1BQU0sR0FBVyxDQUFDLEVBQUUsTUFBTSxHQUFHLFlBQVksQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sRUFBRSxNQUFNLEVBQUUsRUFBRTtnQkFDM0UsSUFBSSxLQUFLLEdBQWEsTUFBTSxDQUFDLE1BQU0sQ0FBQyxFQUFFLEVBQUUsWUFBWSxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQztnQkFDeEUsSUFBSSxjQUFjLENBQUMsUUFBUSxDQUFDLEtBQUssQ0FBQyxFQUFFLENBQUM7b0JBQUUsU0FBUztnQkFDaEQsSUFBSSxVQUFVLEdBQVcsS0FBSyxDQUFDLEtBQUssS0FBSyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQztnQkFDaEUsSUFBSSxRQUFRLEdBQVcsSUFBSSxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsQ0FBQztnQkFFN0MsSUFBSSxRQUFRLEdBQUcsQ0FBQyxJQUFJLENBQUMsWUFBWSxFQUFFO29CQUMvQixZQUFZLEdBQUcsSUFBSSxDQUFDO29CQUNwQixJQUFJLElBQUksQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLEtBQUssS0FBSyxFQUFFO3dCQUM3QixJQUFJLENBQUMsU0FBUyxHQUFHLElBQUksQ0FBQzt3QkFDdEIsTUFBTTtxQkFDVDtpQkFDSjtnQkFFRCxJQUFJLElBQUksQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLEtBQUssS0FBSyxJQUFJLElBQUksQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLEtBQUssT0FBTyxFQUFFO29CQUM5RCxJQUFJLFFBQVEsSUFBSSxDQUFDLEVBQUU7d0JBQ2YsR0FBRyxHQUFHLENBQUMsVUFBVSxLQUFLLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLEdBQUcsR0FBRyxVQUFVLENBQUM7cUJBQ3hEO3lCQUFNO3dCQUNILFdBQVcsR0FBRyxDQUFDLFVBQVUsS0FBSyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQyxXQUFXLEdBQUcsVUFBVSxDQUFDO3FCQUNoRjtpQkFDSjtxQkFBTSxJQUFJLElBQUksQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLEtBQUssS0FBSyxFQUFFO29CQUNwQyxJQUFJLFVBQVUsS0FBSyxJQUFJLElBQUksUUFBUSxLQUFLLENBQUMsRUFBRTt3QkFDdkMsVUFBVSxHQUFHLFVBQVUsR0FBRyxRQUFRLEdBQUcsR0FBRyxDQUFDO3dCQUN6QyxHQUFHLEdBQUcsR0FBRyxHQUFHLFVBQVUsQ0FBQztxQkFDMUI7eUJBQU07d0JBQ0gsR0FBRyxHQUFHLEdBQUcsQ0FBQztxQkFDYjtpQkFDSjtxQkFBTTtvQkFDSCxJQUFJLFFBQVEsSUFBSSxDQUFDLEVBQUU7d0JBQ2YsR0FBRyxHQUFHLENBQUMsVUFBVSxLQUFLLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFVBQVUsQ0FBQztxQkFDaEQ7eUJBQU07d0JBQ0gsV0FBVyxHQUFHLENBQUMsVUFBVSxLQUFLLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFVBQVUsQ0FBQztxQkFDeEQ7aUJBQ0o7Z0JBQ0QsS0FBSyxDQUFDLEdBQUcsR0FBRyxVQUFVLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLFdBQVcsQ0FBQztnQkFFaEQsa0hBQWtIO2dCQUNsSCxJQUFJLElBQUksQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLEtBQUssS0FBSztvQkFBRSxLQUFLLENBQUMsV0FBVyxDQUFDLEdBQUcsVUFBVSxDQUFDO2dCQUVqRSxNQUFNLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDO2dCQUMzRCxPQUFPLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFDO2FBQ3ZCO1lBQ0QsWUFBWSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLGFBQWEsQ0FBQyxNQUFNLEVBQUUsS0FBSyxDQUFDLENBQUMsQ0FBQztZQUMvRCxZQUFZLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsYUFBYSxDQUFDLE1BQU0sRUFBRSxLQUFLLENBQUMsQ0FBQyxDQUFDO1lBQy9ELFFBQVEsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLEdBQUcsTUFBTSxDQUFDLE1BQU0sQ0FBQyxFQUFFLEVBQUUsWUFBWSxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsRUFBRSxFQUFFLENBQUMsRUFBRSxPQUFPLEVBQUUsQ0FBQyxDQUFDO1NBQzlFO1FBRUQsUUFBUSxDQUFDLE9BQU8sQ0FBQyxHQUFHO1lBQ2hCLEdBQUcsRUFBRSxJQUFJLENBQUMsU0FBUyxDQUFDLGFBQWEsQ0FBQyxZQUFZLEVBQUUsS0FBSyxDQUFDO1lBQ3RELEdBQUcsRUFBRSxJQUFJLENBQUMsU0FBUyxDQUFDLGFBQWEsQ0FBQyxZQUFZLEVBQUUsS0FBSyxDQUFDO1NBQ3pELENBQUM7UUFDRixRQUFRLENBQUMsY0FBYyxDQUFDLEdBQUcsWUFBWSxDQUFDO1FBRXhDLE9BQU8sUUFBUSxDQUFDO0lBQ3BCLENBQUM7SUFFTyxzQ0FBbUIsR0FBM0IsVUFBNEIsS0FBaUIsRUFBRSxlQUF1QjtRQUNsRSwwQ0FBMEM7UUFDMUMsSUFBSSxDQUFDLFVBQVUsR0FBRyxFQUFFLENBQUM7UUFDckIsMEJBQTBCO1FBRTFCLElBQUksY0FBYyxHQUFXLEVBQUUsQ0FBQztRQUNoQyxJQUFJLFFBQWdCLEVBQUUsYUFBMEIsQ0FBQztRQUNqRCxJQUFJLFVBQVUsR0FBbUMsRUFBRSxDQUFDO1FBQ3BELEtBQUssSUFBSSxDQUFDLEdBQVcsQ0FBQyxFQUFFLENBQUMsR0FBRyxlQUFlLEVBQUUsQ0FBQyxFQUFFLEVBQUU7WUFDOUMsUUFBUSxHQUFHLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsSUFBSSxLQUFLLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLElBQUksR0FBRyxDQUFDLENBQUM7WUFDM0YsYUFBYSxHQUFHO2dCQUNaLE1BQU0sRUFBRSxLQUFLLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUk7Z0JBQzVCLElBQUksRUFBRSxRQUFRO2dCQUNkLE9BQU8sRUFBRSxLQUFLLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssSUFBSSxJQUFJLENBQUMsaUJBQWlCLENBQUMsT0FBTyxFQUFFLENBQUMsQ0FBQztnQkFDcEUsT0FBTyxFQUFFLEtBQUssQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxJQUFJLElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxPQUFPLEVBQUUsQ0FBQyxDQUFDO2FBQ3ZFLENBQUM7WUFDRixJQUFJLElBQUksQ0FBQyxhQUFhLEtBQUssTUFBTSxJQUFJLElBQUksQ0FBQyxhQUFhLEtBQUssUUFBUSxJQUFJLElBQUksQ0FBQyxhQUFhLEtBQUssTUFBTSxJQUFJLElBQUksQ0FBQyxhQUFhLEtBQUssS0FBSyxFQUFFO2dCQUNuSSxhQUFhLENBQUMsWUFBWSxDQUFDLEdBQUcsQ0FBQyxPQUFPLEtBQUssQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsVUFBVSxLQUFLLFdBQVcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLFVBQVUsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDO2dCQUN0SCxhQUFhLENBQUMsZ0JBQWdCLENBQUMsR0FBRyxDQUFDLE9BQU8sS0FBSyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxjQUFjLEtBQUssV0FBVyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsY0FBYyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7Z0JBQy9ILGFBQWEsQ0FBQyxnQkFBZ0IsQ0FBQyxHQUFHLENBQUMsT0FBTyxLQUFLLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLGNBQWMsS0FBSyxXQUFXLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxjQUFjLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQztnQkFDdkksSUFBSSxJQUFJLENBQUMsYUFBYSxLQUFLLEtBQUs7b0JBQUUsYUFBYSxDQUFDLFdBQVcsQ0FBQyxHQUFHLENBQUMsT0FBTyxLQUFLLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLFNBQVMsS0FBSyxXQUFXLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQzthQUMzSjtZQUNELFVBQVUsQ0FBQyxRQUFRLENBQUMsR0FBRyxhQUFhLENBQUM7WUFDckMsY0FBYyxDQUFDLENBQUMsQ0FBQyxHQUFHLFFBQVEsQ0FBQztTQUNoQztRQUNELElBQUksQ0FBQyxVQUFVLEdBQUcsVUFBVSxDQUFDO1FBQzdCLE9BQU8sY0FBYyxDQUFDO0lBQzFCLENBQUM7SUFFTywrQkFBWSxHQUFwQixVQUFxQixLQUFpQjtRQUNsQyxJQUFJLFlBQVksR0FBVyxJQUFJLENBQUMsU0FBUyxDQUFDLGFBQWEsQ0FBQyxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsTUFBTSxFQUFFLElBQUksQ0FBQyxlQUFlLENBQUMsRUFBRSxLQUFLLENBQUMsQ0FBQztRQUM1RyxJQUFJLFlBQXlCLEVBQUUsa0JBQTRCLENBQUM7UUFDNUQsSUFBSSxTQUFTLEdBQVk7WUFDckIsTUFBTSxFQUFFLEtBQUssQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUk7WUFDeEQsUUFBUSxFQUFFLEtBQUssQ0FBQyxLQUFLLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUk7WUFDOUQsUUFBUSxFQUFFLElBQUksQ0FBQyxNQUFNLENBQUMsV0FBVyxJQUFJLElBQUksQ0FBQyxNQUFNLENBQUMsV0FBVyxDQUFDLGNBQWMsQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsV0FBVyxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRTtZQUNwSixNQUFNLEVBQUUsRUFBRTtTQUNiLENBQUM7UUFDRixJQUFJLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxjQUFjLENBQUMsSUFBSSxDQUFDLEVBQUU7WUFDbkMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsR0FBRyxLQUFLLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxHQUFHLElBQUksQ0FBQyxDQUFDLENBQUMsV0FBVyxDQUFDO1NBQ3RGO1FBRUQsSUFBSSxVQUFVLEdBQWtCLElBQUksQ0FBQyxTQUFTLENBQUMsb0JBQW9CLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxVQUFVLEVBQUUsSUFBSSxDQUFDLFVBQVUsQ0FBQyxDQUFDO1FBRTdHLElBQUksY0FBYyxHQUFXLElBQUksQ0FBQyxtQkFBbUIsQ0FBQyxLQUFLLEVBQUUsWUFBWSxDQUFDLENBQUM7UUFFM0UsSUFBSSxXQUFXLEdBQTJCLElBQUksQ0FBQyxZQUFZLENBQUMsS0FBSyxFQUFFLFlBQVksQ0FBQyxDQUFDO1FBQ2pGLElBQUksWUFBWSxHQUFrQixDQUFDLENBQUMsQ0FBQyxDQUFDO1FBQ3RDLElBQUksWUFBWSxHQUFrQixDQUFDLENBQUMsQ0FBQyxDQUFDO1FBQ3RDLElBQUksWUFBWSxHQUFZLEtBQUssQ0FBQztRQUVsQyxLQUFLLElBQUksQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLEdBQUcsVUFBVSxDQUFDLE1BQU0sRUFBRSxDQUFDLEVBQUUsRUFBRTtZQUN4QyxZQUFZLEdBQUc7Z0JBQ1gsR0FBRyxFQUFFO29CQUNELEtBQUssRUFBRSxDQUFDLENBQUMsUUFBUSxFQUFFO29CQUNuQixLQUFLLEVBQUUsVUFBVSxDQUFDLENBQUMsQ0FBQztpQkFDdkI7Z0JBQ0QsR0FBRyxFQUFFLEVBQUU7YUFFVixDQUFDO1lBRUYsSUFBSSxNQUFNLEdBQWtCLEVBQUUsQ0FBQztZQUMvQixJQUFJLEdBQUcsR0FBVyxDQUFDLENBQUM7WUFDcEIsSUFBSSxXQUFXLEdBQVcsQ0FBQyxDQUFDO1lBRTVCLElBQUksV0FBVyxHQUFpQixJQUFJLENBQUMsU0FBUyxDQUFDLGNBQWMsQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLGtCQUFrQixDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsRUFBRSxZQUFZLENBQUMsQ0FBQztZQUUvSCxtREFBbUQ7WUFDbkQsS0FBSyxJQUFJLENBQUMsR0FBVyxXQUFXLENBQUMsS0FBSyxFQUFFLFdBQVcsQ0FBQyxLQUFLLENBQUMsQ0FBQyxFQUFFLFdBQVcsQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLEdBQUcsV0FBVyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsRUFBRTtnQkFDdkcsSUFBSSxPQUFPLEtBQUssQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxLQUFLLFdBQVc7b0JBQUUsU0FBUztnQkFFN0QsSUFBSSxVQUFVLEdBQWtCLEtBQUssQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQztnQkFDOUQsSUFBSSxRQUFRLEdBQVcsSUFBSSxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsQ0FBQztnQkFFN0MsSUFBSSxPQUFPLFVBQVUsS0FBSyxXQUFXO29CQUFFLFNBQVM7Z0JBRWhELElBQUksUUFBUSxHQUFHLENBQUMsSUFBSSxDQUFDLFlBQVksRUFBRTtvQkFDL0IsWUFBWSxHQUFHLElBQUksQ0FBQztvQkFDcEIsSUFBSSxJQUFJLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxLQUFLLEtBQUs7d0JBQUUsTUFBTTtpQkFDMUM7Z0JBRUQsSUFBSSxJQUFJLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxLQUFLLEtBQUssSUFBSSxJQUFJLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxLQUFLLE9BQU8sRUFBRTtvQkFDOUQsSUFBSSxRQUFRLElBQUksQ0FBQyxFQUFFO3dCQUNmLEdBQUcsR0FBRyxDQUFDLFVBQVUsS0FBSyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxHQUFHLEdBQUcsVUFBVSxDQUFDO3FCQUN4RDt5QkFBTTt3QkFDSCxXQUFXLEdBQUcsQ0FBQyxVQUFVLEtBQUssSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUMsV0FBVyxHQUFHLFVBQVUsQ0FBQztxQkFDaEY7aUJBQ0o7cUJBQU0sSUFBSSxJQUFJLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxLQUFLLEtBQUssRUFBRTtvQkFDcEMsSUFBSSxVQUFVLEtBQUssSUFBSSxJQUFJLFdBQVcsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLEVBQUU7d0JBQzdDLFVBQVUsR0FBRyxVQUFVLEdBQUcsV0FBVyxDQUFDLENBQUMsQ0FBQyxHQUFHLEdBQUcsQ0FBQztxQkFDbEQ7eUJBQU07d0JBQ0gsVUFBVSxHQUFHLENBQUMsQ0FBQztxQkFDbEI7b0JBQ0QsR0FBRyxHQUFHLEdBQUcsR0FBRyxVQUFVLENBQUM7aUJBQzFCO3FCQUFNO29CQUNILElBQUksUUFBUSxJQUFJLENBQUMsRUFBRTt3QkFDZixHQUFHLEdBQUcsQ0FBQyxVQUFVLEtBQUssSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsVUFBVSxDQUFDO3FCQUNoRDt5QkFBTTt3QkFDSCxXQUFXLEdBQUcsQ0FBQyxVQUFVLEtBQUssSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsVUFBVSxDQUFDO3FCQUN4RDtpQkFDSjtnQkFFRCxrQkFBa0IsR0FBRztvQkFDakIsS0FBSyxFQUFFLFVBQVUsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsV0FBVztvQkFDMUMsT0FBTyxFQUFFLEtBQUssQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUs7b0JBQ3RDLE9BQU8sRUFBRSxJQUFJLENBQUMsVUFBVSxDQUFDLE9BQU8sRUFBRSxDQUFDLEVBQUUsS0FBSyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUM7b0JBQzdELE9BQU8sRUFBRSxJQUFJLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsT0FBTyxFQUFFLENBQUMsRUFBRSxLQUFLLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO29CQUMxRSxJQUFJLEVBQUUsY0FBYyxDQUFDLENBQUMsQ0FBQztpQkFDMUIsQ0FBQztnQkFFRixrSEFBa0g7Z0JBQ2xILElBQUksSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsS0FBSyxLQUFLO29CQUFFLGtCQUFrQixDQUFDLFdBQVcsQ0FBQyxHQUFHLFVBQVUsQ0FBQztnQkFFOUUsTUFBTSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQztnQkFDM0QsWUFBWSxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsa0JBQWtCLENBQUMsQ0FBQzthQUMzQztZQUVELFlBQVksQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxhQUFhLENBQUMsTUFBTSxFQUFFLEtBQUssQ0FBQyxDQUFDLENBQUM7WUFDL0QsWUFBWSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLGFBQWEsQ0FBQyxNQUFNLEVBQUUsS0FBSyxDQUFDLENBQUMsQ0FBQztZQUUvRCxTQUFTLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxZQUFZLENBQUMsQ0FBQztTQUNyQztRQUVELElBQUksS0FBSyxDQUFDLEtBQUssQ0FBQyxJQUFJLEtBQUssS0FBSyxFQUFFO1lBQzVCLFNBQVMsQ0FBQyxPQUFPLENBQUMsR0FBRztnQkFDakIsR0FBRyxFQUFFLElBQUksQ0FBQyxTQUFTLENBQUMsYUFBYSxDQUFDLFlBQVksRUFBRSxLQUFLLENBQUM7Z0JBQ3RELEdBQUcsRUFBRSxJQUFJLENBQUMsU0FBUyxDQUFDLGFBQWEsQ0FBQyxZQUFZLEVBQUUsS0FBSyxDQUFDO2FBQ3pELENBQUM7WUFDRixTQUFTLENBQUMsY0FBYyxDQUFDLEdBQUcsWUFBWSxDQUFDO1NBQzVDO1FBRUQsSUFBSSxDQUFDLElBQUksR0FBRyxTQUFTLENBQUM7UUFDdEIsSUFBSSxDQUFDLFNBQVMsR0FBRyxJQUFJLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxLQUFLLEtBQUssSUFBSSxZQUFZLENBQUM7UUFDN0QsSUFBSSxDQUFDLFVBQVUsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUM7SUFDakMsQ0FBQztJQUVPLHFDQUFrQixHQUExQixVQUEyQixLQUFLO1FBQzVCLElBQUksS0FBSyxLQUFLLFNBQVMsSUFBSSxLQUFLLEtBQUssSUFBSSxFQUFFO1lBQ3ZDLElBQUksU0FBUyxHQUFZO2dCQUNyQixNQUFNLEVBQUUsS0FBSyxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSTtnQkFDeEQsUUFBUSxFQUFFLEtBQUssQ0FBQyxLQUFLLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUk7Z0JBQzlELFFBQVEsRUFBRSxJQUFJLENBQUMsTUFBTSxDQUFDLFdBQVcsSUFBSSxJQUFJLENBQUMsTUFBTSxDQUFDLFdBQVcsQ0FBQyxjQUFjLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLFdBQVcsQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUU7Z0JBQ3BKLE1BQU0sRUFBRSxFQUFFO2FBQ2IsQ0FBQztZQUNGLElBQUksWUFBWSxHQUFHLElBQUksQ0FBQyxTQUFTLENBQUMsb0JBQW9CLENBQUMsSUFBSSxDQUFDLFVBQVUsRUFBRSxLQUFLLEVBQUUsSUFBSSxDQUFDLE1BQU0sRUFBRSxJQUFJLENBQUMsZUFBZSxDQUFDLENBQUM7WUFDbEgsU0FBUyxDQUFDLFNBQVMsQ0FBQyxHQUFHLFlBQVksQ0FBQyxPQUFPLENBQUM7WUFDNUMsSUFBSSxDQUFDLElBQUksR0FBRyxTQUFTLENBQUM7WUFDdEIsSUFBSSxDQUFDLE1BQU0sQ0FBQyxVQUFVLENBQUMsR0FBRyxZQUFZLENBQUMsUUFBUSxDQUFDO1lBQ2hELElBQUksQ0FBQyxVQUFVLEdBQUcsWUFBWSxDQUFDLFVBQVUsQ0FBQztZQUMxQyxtQ0FBbUM7U0FDdEM7SUFDTCxDQUFDO0lBRU8scUNBQWtCLEdBQTFCLFVBQTJCLEtBQUs7UUFDNUIsSUFBSSxDQUFDLElBQUksR0FBRyxLQUFLLENBQUM7UUFDbEIsSUFBSSxDQUFDLGdCQUFnQixFQUFFLENBQUM7SUFDNUIsQ0FBQztJQUVPLG1DQUFnQixHQUF4QjtRQUNJLElBQUksVUFBZSxDQUFDO1FBQ3BCLElBQUksSUFBSSxDQUFDLElBQUksQ0FBQyxlQUFlLENBQUMsSUFBSSxJQUFJLENBQUMsTUFBTSxDQUFDLFdBQVcsRUFBRTtZQUN2RCxVQUFVLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsZUFBZSxDQUFDLENBQUMsQ0FBQyxDQUFDO1NBQ3ZFO2FBQU07WUFDSCxVQUFVLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDO1lBQzdELEtBQUssSUFBSSxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsR0FBRyxVQUFVLENBQUMsTUFBTSxFQUFFLENBQUMsRUFBRSxFQUFFO2dCQUN4QyxVQUFVLENBQUMsQ0FBQyxDQUFDLENBQUMsVUFBVSxDQUFDLEdBQUcsS0FBSyxDQUFDO2FBQ3JDO1NBQ0o7UUFDRCxJQUFJLENBQUMsYUFBYSxHQUFHLEtBQUssQ0FBQztRQUMzQixJQUFJLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxXQUFXLEVBQUU7WUFDMUIsSUFBSSxJQUFJLENBQUMsTUFBTSxDQUFDLFNBQVMsSUFBSSxTQUFTLEVBQUU7Z0JBQ3BDLElBQUksSUFBSSxDQUFDLE1BQU0sQ0FBQyxTQUFTLENBQUMsV0FBVyxJQUFJLElBQUksQ0FBQyxNQUFNLENBQUMsU0FBUyxDQUFDLFdBQVcsQ0FBQyxNQUFNLElBQUksQ0FBQyxFQUFFO29CQUNwRixJQUFJLENBQUMsVUFBVSxHQUFHLElBQUksQ0FBQyxTQUFTLENBQUMscUJBQXFCLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxTQUFTLENBQUMsV0FBVyxFQUFFLElBQUksQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLGFBQWEsRUFBRSxJQUFJLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxXQUFXLENBQUMsQ0FBQztpQkFDL0o7cUJBQU07b0JBQ0gsSUFBSSxDQUFDLGFBQWEsR0FBRyxJQUFJLENBQUM7aUJBQzdCO2FBQ0o7aUJBQU07Z0JBQ0gsSUFBSSxDQUFDLFVBQVUsR0FBRyxJQUFJLENBQUMsU0FBUyxDQUFDLGdCQUFnQixDQUFDLElBQUksQ0FBQyxVQUFVLEVBQUUsVUFBVSxFQUFFLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQzthQUMvRjtTQUNKO2FBQU07WUFDSCxtQ0FBbUM7WUFDbkMsSUFBSSxJQUFJLENBQUMsTUFBTSxDQUFDLFNBQVMsSUFBSSxTQUFTLEVBQUU7Z0JBQ3BDLElBQUksSUFBSSxDQUFDLE1BQU0sQ0FBQyxTQUFTLENBQUMsV0FBVyxJQUFJLElBQUksQ0FBQyxNQUFNLENBQUMsU0FBUyxDQUFDLFdBQVcsQ0FBQyxNQUFNLElBQUksQ0FBQyxFQUFFO29CQUNwRixJQUFJLENBQUMsVUFBVSxHQUFHLElBQUksQ0FBQyxTQUFTLENBQUMsZ0JBQWdCLENBQUMsSUFBSSxDQUFDLFVBQVUsRUFBRSxVQUFVLEVBQUUsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDO2lCQUMvRjtxQkFBTTtvQkFDSCxJQUFJLENBQUMsYUFBYSxHQUFHLElBQUksQ0FBQztpQkFDN0I7YUFDSjtpQkFBTTtnQkFDSCxJQUFJLENBQUMsVUFBVSxHQUFHLElBQUksQ0FBQyxTQUFTLENBQUMsZ0JBQWdCLENBQUMsSUFBSSxDQUFDLFVBQVUsRUFBRSxVQUFVLEVBQUUsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDO2FBQy9GO1NBQ0o7SUFDTCxDQUFDO0lBRU8sK0JBQVksR0FBcEIsVUFBcUIsS0FBaUIsRUFBRSxZQUFvQjtRQUN4RCxJQUFJLElBQUksQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLEtBQUssS0FBSyxFQUFFO1lBQzdCLE9BQU8sSUFBSSxDQUFDLFNBQVMsQ0FBQyx3QkFBd0IsQ0FBQyxLQUFLLENBQUMsTUFBTSxFQUFFLEtBQUssQ0FBQyxLQUFLLENBQUMsVUFBVSxFQUFFLFlBQVksQ0FBQyxDQUFDO1NBQ3RHO0lBQ0wsQ0FBQztJQUVPLDZCQUFVLEdBQWxCLFVBQW1CLFFBQWEsRUFBRSxZQUFvQixFQUFFLEtBQWtCO1FBRXRFLElBQUksQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLE9BQU8sQ0FBQyxLQUFLLENBQUM7WUFBRSxPQUFPO1FBRTNDLElBQUksS0FBSyxDQUFDLGNBQWMsQ0FBQyxRQUFRLENBQUMsSUFBSSxLQUFLLENBQUMsUUFBUSxDQUFDLEtBQUssU0FBUyxFQUFFO1lBQ2pFLE9BQU8sS0FBSyxDQUFDLFFBQVEsQ0FBQyxDQUFDO1NBQzFCO1FBRUQsSUFBSSxNQUFNLEdBQVcsSUFBSSxDQUFDLGdCQUFnQixDQUFDLFFBQVEsRUFBRSxZQUFZLENBQUMsQ0FBQztRQUNuRSxPQUFPLE1BQU0sQ0FBQztJQUNsQixDQUFDO0lBRU8sbUNBQWdCLEdBQXhCLFVBQXlCLFFBQWEsRUFBRSxZQUFvQjtRQUN4RCxJQUFJLFFBQVEsS0FBSyxPQUFPO1lBQ3BCLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxLQUFLLENBQUMsSUFBSSxLQUFLLEtBQUssSUFBSSxJQUFJLENBQUMsU0FBUyxDQUFDLEtBQUssQ0FBQyxJQUFJLEtBQUssS0FBSyxDQUFDLEVBQUU7WUFDOUUsT0FBTyxRQUFRLENBQUM7U0FDbkI7UUFFRCxJQUFJLGFBQWEsR0FBVyxJQUFJLENBQUMsaUJBQWlCLENBQUMsUUFBUSxFQUFFLFlBQVksQ0FBQyxDQUFDO1FBQzNFLElBQUksTUFBYyxDQUFDO1FBQ25CLElBQUksSUFBSSxDQUFDLGFBQWEsSUFBSSxLQUFLLEVBQUU7WUFDN0IsTUFBTSxHQUFHLGFBQWEsQ0FBQztTQUMxQjthQUFNO1lBQ0gsTUFBTSxHQUFHLElBQUksQ0FBQyxTQUFTLENBQUMsTUFBTSxDQUFDLFlBQVksQ0FBQyxDQUFDLFFBQVEsQ0FBQyxJQUFJLGFBQWEsQ0FBQztTQUMzRTtRQUNELE9BQU8sTUFBTSxDQUFDO0lBQ2xCLENBQUM7SUFFTSxvQ0FBaUIsR0FBeEIsVUFBeUIsUUFBYSxFQUFFLFlBQXFCO1FBQ3pELElBQUksUUFBUSxLQUFLLE9BQU87WUFBRSxPQUFPLFFBQVEsQ0FBQztRQUUxQyxJQUFJLFlBQVksSUFBSSxZQUFZLEtBQUssQ0FBQyxFQUFFO1lBQ3BDLE9BQU8sSUFBSSxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsWUFBWSxDQUFDLENBQUM7U0FDM0M7YUFBTTtZQUNILElBQUksQ0FBQyxrQkFBa0IsRUFBRSxDQUFDO1lBQzFCLE9BQU8sSUFBSSxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLGtCQUFrQixHQUFHLENBQUMsQ0FBQyxDQUFDO1NBQzFEO0lBQ0wsQ0FBQztJQUVNLGtDQUFlLEdBQXRCLFVBQXVCLEtBQVU7UUFDN0IsSUFBSSxDQUFDLGFBQWEsR0FBRyxLQUFLLENBQUM7SUFDL0IsQ0FBQzs7Z0JBN3ZCdUIsWUFBWTtnQkFDWCxVQUFVO2dCQUNaLFdBQVc7Z0JBRVAsZUFBZTtnQkFDckIsU0FBUzs7SUFmZjtRQUFkLEtBQUssQ0FBQyxNQUFNLENBQUM7OytDQUF1QjtJQUNwQjtRQUFoQixLQUFLLENBQUMsUUFBUSxDQUFDOztpREFBMkI7SUFDN0I7UUFBYixLQUFLLENBQUMsS0FBSyxDQUFDOzs4Q0FBcUI7SUFDekI7UUFBUixLQUFLLEVBQUU7O2dEQUFvQjtJQUNuQjtRQUFSLEtBQUssRUFBRTs7cURBQWdDO0lBQzlCO1FBQVQsTUFBTSxFQUFFO2tDQUFtQixZQUFZO3NEQUFzRDtJQUNwRjtRQUFULE1BQU0sRUFBRTtrQ0FBYSxZQUFZO2dEQUErQjtJQUN2RDtRQUFULE1BQU0sRUFBRTtrQ0FBYSxZQUFZO2dEQUErQjtJQTNEeEQsUUFBUTtRQXhCcEIsU0FBUyxDQUFDO1lBQ1AsUUFBUSxFQUFFLFdBQVc7WUFDckIsb29WQUF1QztZQUN2QyxhQUFhLEVBQUUsaUJBQWlCLENBQUMsSUFBSTtZQUNyQyxTQUFTLEVBQUUsQ0FBQyxXQUFXLEVBQUUsZUFBZSxFQUFFLGVBQWUsRUFBRSxZQUFZLEVBQUUsU0FBUyxDQUFDO1lBQ25GLElBQUksRUFBRTtnQkFDRixPQUFPLEVBQUUsWUFBWTtnQkFDckIsV0FBVyxFQUFFLFdBQVc7Z0JBQ3hCLGdDQUFnQyxFQUFFLHdCQUF3QjtnQkFDMUQsbUNBQW1DLEVBQUUsY0FBYztnQkFDbkQsbUNBQW1DLEVBQUUsY0FBYztnQkFDbkQsbUNBQW1DLEVBQUUsdUJBQXVCO2dCQUM1RCxtQ0FBbUMsRUFBRSx1QkFBdUI7Z0JBQzVELDhCQUE4QixFQUFFLDBCQUEwQjtnQkFDMUQsMEJBQTBCLEVBQUUsZ0RBQWdEO2dCQUM1RSxzQkFBc0IsRUFBRSw0Q0FBNEM7Z0JBQ3BFLHNCQUFzQixFQUFFLDRDQUE0QztnQkFDcEUsdUJBQXVCLEVBQUUsNkNBQTZDO2dCQUN0RSxzQkFBc0IsRUFBRSw0Q0FBNEM7Z0JBQ3BFLHFCQUFxQixFQUFFLCtCQUErQjtnQkFDdEQsaUJBQWlCLEVBQUUscUNBQXFDO2FBQzNEO1NBQ0osQ0FBQzt5Q0FnRTBCLFlBQVk7WUFDWCxVQUFVO1lBQ1osV0FBVztZQUVQLGVBQWU7WUFDckIsU0FBUztPQW5FckIsUUFBUSxDQTR6QnBCO0lBQUQsZUFBQztDQUFBLEFBNXpCRCxJQTR6QkM7U0E1ekJZLFFBQVEiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQge1xyXG4gICAgQ29tcG9uZW50LFxyXG4gICAgVmlld0VuY2Fwc3VsYXRpb24sXHJcbiAgICBJbnB1dCxcclxuICAgIE91dHB1dCxcclxuICAgIEV2ZW50RW1pdHRlcixcclxuICAgIE9uSW5pdCxcclxuICAgIE9uQ2hhbmdlcyxcclxuICAgIFNpbXBsZUNoYW5nZXMsXHJcbiAgICBFbGVtZW50UmVmLFxyXG4gICAgT25EZXN0cm95XHJcbn0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XHJcbmltcG9ydCB7IERvbVNhbml0aXplciB9IGZyb20gJ0Bhbmd1bGFyL3BsYXRmb3JtLWJyb3dzZXInO1xyXG5pbXBvcnQgeyBTdWJzY3JpcHRpb24sICB0aW1lciB9IGZyb20gJ3J4anMnO1xyXG5pbXBvcnQgeyBkZWJvdW5jZVRpbWUgfSBmcm9tICdyeGpzL29wZXJhdG9ycyc7XHJcbmltcG9ydCB7IEtkU3BsaXR0ZXJFdmVudCB9IGZyb20gJy4uL2tkLWFuZ3VsYXItc3BsaXR0ZXIvaW5kZXgnO1xyXG5pbXBvcnQgeyBLZENvbnZlcnRpb25TdmMsIEtkRG9tRWxlbVN2YywgS2REYXRhU3ZjIH0gZnJvbSAnLi4va2QtY29tbW9uL2luZGV4JztcclxuaW1wb3J0IHsgS2RDaGFydHNTdmMgfSBmcm9tICcuL2tkLWFuZ3VsYXItY2hhcnRzLXN2Yyc7XHJcbmltcG9ydCB7IERFRkFVTFRfQ09ORklHIH0gZnJvbSAnLi9rZC1hbmd1bGFyLWNoYXJ0cy1jb25maWcnO1xyXG5pbXBvcnQge1xyXG4gICAgSUNoYXJ0RGF0YSxcclxuICAgIElDaGFydENvbmZpZyxcclxuICAgIElTZXJpZXNEYXRhLFxyXG4gICAgSUxlZ2VuZERhdGEsXHJcbiAgICBJRDNEYXRhLFxyXG4gICAgSUQzWURhdGEsXHJcbiAgICBJRDNEYXRhRGF0YSxcclxuICAgIElDaGFydEFwaSxcclxuICAgIElDaGFydEludGVybmFsQXBpLFxyXG4gICAgSUZvckxvb3BJbmZvXHJcbn0gZnJvbSAnLi9rZC1hbmd1bGFyLWNoYXJ0cy1pbnRlcmZhY2UnO1xyXG5cclxuQENvbXBvbmVudCh7XHJcbiAgICBzZWxlY3RvcjogJ2tkLWNoYXJ0cycsXHJcbiAgICB0ZW1wbGF0ZVVybDogJy4va2QtYW5ndWxhci1jaGFydHMuaHRtbCcsXHJcbiAgICBlbmNhcHN1bGF0aW9uOiBWaWV3RW5jYXBzdWxhdGlvbi5Ob25lLFxyXG4gICAgcHJvdmlkZXJzOiBbS2RDaGFydHNTdmMsIEtkU3BsaXR0ZXJFdmVudCwgS2RDb252ZXJ0aW9uU3ZjLCBLZERvbUVsZW1TdmMsIEtkRGF0YVN2Y10sXHJcbiAgICBob3N0OiB7XHJcbiAgICAgICAgJ2NsYXNzJzogJ2tkeC1jaGFydHMnLFxyXG4gICAgICAgICdbYXR0ci5pZF0nOiAnY29uZmlnLmlkJyxcclxuICAgICAgICAnW2NsYXNzLmtkeC1jaGFydHMtYXhpcy1pbnZlcnRdJzogJ2NoYXJ0VHlwZVswXSA9PT0gXCJiYXJcIicsXHJcbiAgICAgICAgJ1tjbGFzcy5rZHgtY2hhcnRzLXJvdGF0ZS10aXRsZS14XSc6ICdyb3RhdGVUaXRsZVgnLFxyXG4gICAgICAgICdbY2xhc3Mua2R4LWNoYXJ0cy1yb3RhdGUtdGl0bGUteV0nOiAncm90YXRlVGl0bGVZJyxcclxuICAgICAgICAnW2NsYXNzLmtkeC1jaGFydHMteUF4aXMtb3Bwb3NpdGVdJzogJ2NvbmZpZy55QXhpcy5vcHBvc2l0ZScsXHJcbiAgICAgICAgJ1tjbGFzcy5rZHgtY2hhcnRzLXhBeGlzLW9wcG9zaXRlXSc6ICdjb25maWcueEF4aXMub3Bwb3NpdGUnLFxyXG4gICAgICAgICdbY2xhc3Mua2R4LWNoYXJ0cy1uby1ib3JkZXJdJzogJ2hhdmVrZENoYXJ0Tm9Cb3JkZXJDbGFzcycsXHJcbiAgICAgICAgJ1tzdHlsZS5iYWNrZ3JvdW5kLWNvbG9yXSc6ICdjb25maWcuY2hhcnQubWFpbkFyZWEuc3R5bGVbXCJiYWNrZ3JvdW5kQ29sb3JcIl0nLFxyXG4gICAgICAgICdbc3R5bGUuYm9yZGVyLWNvbG9yXSc6ICdjb25maWcuY2hhcnQubWFpbkFyZWEuc3R5bGVbXCJib3JkZXJDb2xvclwiXScsXHJcbiAgICAgICAgJ1tzdHlsZS5ib3JkZXItd2lkdGhdJzogJ2NvbmZpZy5jaGFydC5tYWluQXJlYS5zdHlsZVtcImJvcmRlcldpZHRoXCJdJyxcclxuICAgICAgICAnW3N0eWxlLmJvcmRlci1yYWRpdXNdJzogJ2NvbmZpZy5jaGFydC5tYWluQXJlYS5zdHlsZVtcImJvcmRlclJhZGl1c1wiXScsXHJcbiAgICAgICAgJ1tzdHlsZS5ib3JkZXItc3R5bGVdJzogJ2NvbmZpZy5jaGFydC5tYWluQXJlYS5zdHlsZVtcImJvcmRlclN0eWxlXCJdJyxcclxuICAgICAgICAnW3N0eWxlLmZvbnQtZmFtaWx5XSc6ICdjb25maWcuY2hhcnQuc3R5bGUuZm9udEZhbWlseScsXHJcbiAgICAgICAgJ1tzdHlsZS5vcGFjaXR5XSc6ICdjb25maWcuY2hhcnQubWFpbkFyZWEuc3R5bGUub3BhY2l0eScsXHJcbiAgICB9XHJcbn0pXHJcblxyXG5leHBvcnQgY2xhc3MgS2RDaGFydHMgaW1wbGVtZW50cyBPbkluaXQsIE9uQ2hhbmdlcywgT25EZXN0cm95IHtcclxuICAgIHB1YmxpYyBpc0xheWVyTG9hZGluZzogYm9vbGVhbiA9IHRydWU7XHJcbiAgICBwdWJsaWMgc21hbGxMb2FkZXJWYWx1ZTogYW55ID0gbnVsbDtcclxuICAgIHB1YmxpYyBwaWVEYXRhOiBBcnJheTxhbnk+ID0gW107XHJcbiAgICBwdWJsaWMgcGllQ29sb3I6IEFycmF5PGFueT4gPSBbXTtcclxuICAgIHB1YmxpYyBiYWNrZ3JvdW5kQ29sb3I6IHN0cmluZyA9ICcjRkZGRkZGJztcclxuICAgIHB1YmxpYyBjb25maWc6IElDaGFydENvbmZpZztcclxuICAgIHB1YmxpYyBkYXRhOiBJRDNEYXRhO1xyXG4gICAgcHVibGljIGxlZ2VuZExpc3Q6IEFycmF5PHN0cmluZz47XHJcbiAgICBwdWJsaWMgY2hlY2tNYXBTY2FsZTogYm9vbGVhbiA9IGZhbHNlO1xyXG4gICAgcHVibGljIGNoYXJ0Q2F0ZWdvcnk6ICdwaWUnIHwgJ2JhcicgfCAnY29sdW1uJyB8ICdsaW5lJyB8ICdhcmVhJyB8ICdkb3QnIHwgJ3NwbGluZScgfCAnbWFwJztcclxuICAgIHB1YmxpYyBpc0F4aXNDaGFydDogYm9vbGVhbiA9IGZhbHNlO1xyXG4gICAgcHVibGljIGlzTmVnYXRpdmVTdGFjazogYm9vbGVhbiA9IGZhbHNlO1xyXG4gICAgcHVibGljIGNoYXJ0VHlwZTogQXJyYXk8c3RyaW5nPiA9IFsnJ107XHJcbiAgICBwdWJsaWMgcm90YXRlVGl0bGVYOiBib29sZWFuID0gZmFsc2U7XHJcbiAgICBwdWJsaWMgcm90YXRlVGl0bGVZOiBib29sZWFuID0gZmFsc2U7XHJcbiAgICBwdWJsaWMgY2hhcnRIaWRlOiBib29sZWFuID0gZmFsc2U7XHJcbiAgICBwdWJsaWMgaGF2ZUF4aXNQYWRkaW5nOiBib29sZWFuID0gZmFsc2U7XHJcbiAgICBwdWJsaWMgaGF2ZUF4aXNTcGVjaWFsUGFkZGluZzogYm9vbGVhbiA9IGZhbHNlO1xyXG4gICAgcHVibGljIHhBeGlzT3Bwb3NpdGU6IGJvb2xlYW4gPSBmYWxzZTtcclxuICAgIHB1YmxpYyBoYXZla2RDaGFydE5vQm9yZGVyQ2xhc3M6IGJvb2xlYW4gPSBmYWxzZTtcclxuXHJcbiAgICBwdWJsaWMgaHRtbENsYXNzT2JqOiBhbnkgPSB7XHJcbiAgICAgICAgJ2NoYXJ0c1dyYXBwZXInOiAnJyxcclxuICAgICAgICAnbGVnZW5kQ29udGFpbmVyJzogJydcclxuICAgIH07XHJcblxyXG4gICAgcHVibGljIGFwaTogSUNoYXJ0SW50ZXJuYWxBcGkgPSB7fTtcclxuXHJcbiAgICBwdWJsaWMgaWNvbnM6IG9iamVjdCA9IHt9O1xyXG5cclxuICAgIHB1YmxpYyBsZWdlbmREYXRhOiB7IFtrZXk6IHN0cmluZ106IElMZWdlbmREYXRhIH07XHJcbiAgICBwdWJsaWMgbWFya2Vyc0xlZ2VuZDogQXJyYXk8YW55PiA9IFtdO1xyXG5cclxuICAgIHByaXZhdGUgc2hhcGVzOiBvYmplY3QgPSB7XHJcbiAgICAgICAgdHJpYW5nbGU6ICdNIDQgMCBMIDQgMCBMIDAgOCBMIDggOCB6JyxcclxuICAgICAgICB0cmlhbmdsZVI6ICdNIDAgMCBMIDggMCBMIDQgOCBMIDQgOCB6JyxcclxuICAgICAgICBkaWFtb25kOiAnTSA0IDAgTCA4IDQgTCA0IDggTCAwIDQgeicsXHJcbiAgICAgICAgY2lyY2xlOiAnTSA0IDAgQSA0IDQgMCAxIDAgNCA4IEEgNCA0IDAgMSAwIDQgMCBaJyxcclxuICAgICAgICBzcXVhcmU6ICdNIDAgMCBMIDggMCBMIDggOCBMIDAgOCB6J1xyXG4gICAgfTtcclxuXHJcbiAgICBwcml2YXRlIGxlZ2VuZEluYWN0aXZlOiBBcnJheTxzdHJpbmc+ID0gW107XHJcbiAgICBwcml2YXRlIF9jb2xvckxpc3RQb3NpdGlvbjogbnVtYmVyID0gMDtcclxuXHJcbiAgICBwcml2YXRlIF9yZXNpemVUaW1lb3V0OiBhbnk7XHJcblxyXG4gICAgLy8gcHJpdmF0ZSBfc3BsaXR0ZXJTdWJzY3JpcHRpb25BcnI6IFN1YnNjcmlwdGlvbltdID0gW107XHJcblxyXG4gICAgcHJpdmF0ZSBfcmVzaXplTGlzdGVuZXI6IGFueTtcclxuICAgIHByaXZhdGUgX3BpZURvbmVGbGFnOiBib29sZWFuID0gZmFsc2U7XHJcblxyXG4gICAgQElucHV0KCdkYXRhJykgY2hhcnREYXRhOiBJQ2hhcnREYXRhO1xyXG4gICAgQElucHV0KCdjb25maWcnKSBjaGFydENvbmZpZzogSUNoYXJ0Q29uZmlnO1xyXG4gICAgQElucHV0KCdhcGknKSBjaGFydEFwaTogSUNoYXJ0QXBpO1xyXG4gICAgQElucHV0KCkgeFRocmVzaG9sZDogbnVtYmVyO1xyXG4gICAgQElucHV0KCkgc2VyaWVzVGhyZXNob2xkOiBudW1iZXIgPSAxMDAwO1xyXG4gICAgQE91dHB1dCgpIG91dHB1dExlZ2VuZERhdGE6IEV2ZW50RW1pdHRlcjx7IFtrZXk6IHN0cmluZ106IElMZWdlbmREYXRhIH0+ID0gbmV3IEV2ZW50RW1pdHRlcigpO1xyXG4gICAgQE91dHB1dCgpIG91dHB1dERhdGE6IEV2ZW50RW1pdHRlcjxJRDNEYXRhPiA9IG5ldyBFdmVudEVtaXR0ZXIoKTtcclxuICAgIEBPdXRwdXQoKSBvdXRwdXRBcmVhOiBFdmVudEVtaXR0ZXI8SUQzRGF0YT4gPSBuZXcgRXZlbnRFbWl0dGVyKCk7XHJcblxyXG4gICAgY29uc3RydWN0b3IoXHJcbiAgICAgICAgcHJpdmF0ZSBfc2FuaXRpemVyOiBEb21TYW5pdGl6ZXIsXHJcbiAgICAgICAgcHJpdmF0ZSBfZWxlbWVudFJlZjogRWxlbWVudFJlZixcclxuICAgICAgICBwcml2YXRlIF9jaGFydFN2YzogS2RDaGFydHNTdmMsXHJcbiAgICAgICAgLy8gcHVibGljIF9rZFNwbGl0dGVyRXZlbnQ6IEtkU3BsaXR0ZXJFdmVudCxcclxuICAgICAgICBwdWJsaWMgX2NvbnZlcnRpb25TdmM6IEtkQ29udmVydGlvblN2YyxcclxuICAgICAgICBwdWJsaWMgX2RhdGFTdmM6IEtkRGF0YVN2Y1xyXG4gICAgKSB7XHJcbiAgICAgICAgLy8gdGhpcy5fc3BsaXR0ZXJTdWJzY3JpcHRpb25BcnIgPSB0aGlzLl9pbml0U3BsaXR0ZXJTdWJzY3JpcHRpb25zKF9rZFNwbGl0dGVyRXZlbnQpO1xyXG4gICAgfVxyXG5cclxuICAgIG5nT25Jbml0KCk6IHZvaWQge1xyXG4gICAgICAgIC8vIGNvbnNvbGUubG9nKCdrZC1jaGFydCBpbml0Jyk7XHJcbiAgICAgICAgdGhpcy5fc2V0Q29uZmlnKHRoaXMuY2hhcnRDb25maWcsIHRydWUpO1xyXG4gICAgICAgIGlmICghdGhpcy5jaGFydERhdGEgfHwgIXRoaXMuY2hhcnRDb25maWcpIHJldHVybjtcclxuICAgICAgICB0aGlzLl9zZXREYXRhKHRoaXMuY2hhcnREYXRhKTtcclxuICAgICAgICB0aGlzLmluaXRBcGkoKTtcclxuICAgICAgICAvLyB0aGlzLl9yZXNpemVMaXN0ZW5lciA9ICgpID0+IHRoaXMuX29uUmVzaXplKCk7XHJcbiAgICAgICAgLy8gdGhpcy5faW5pdExpc3RlbmVyKCk7XHJcbiAgICAgICAgLy8gY29uc29sZS5sb2coJ2tkLWNoYXJ0IGRhdGEgJywgdGhpcy5jaGFydERhdGEpO1xyXG4gICAgICAgIC8vIGNvbnNvbGUubG9nKCdrZC1jaGFydCBjb25maWcgJywgdGhpcy5jaGFydENvbmZpZyk7XHJcbiAgICB9XHJcblxyXG4gICAgbmdPbkNoYW5nZXMoX3NpbXBsZUNoYW5nZXM6IFNpbXBsZUNoYW5nZXMpOiB2b2lkIHtcclxuICAgICAgICBpZiAoX3NpbXBsZUNoYW5nZXMuaGFzT3duUHJvcGVydHkoJ2NoYXJ0Q29uZmlnJykgJiYgIV9zaW1wbGVDaGFuZ2VzWydjaGFydENvbmZpZyddLmZpcnN0Q2hhbmdlKSB7XHJcbiAgICAgICAgICAgIGlmIChfc2ltcGxlQ2hhbmdlc1snY2hhcnRDb25maWcnXS5jdXJyZW50VmFsdWUgPT09IHRoaXMuY29uZmlnKSByZXR1cm47XHJcbiAgICAgICAgICAgIHRoaXMuX3NldENvbmZpZyhfc2ltcGxlQ2hhbmdlcy5jaGFydENvbmZpZy5jdXJyZW50VmFsdWUpO1xyXG4gICAgICAgIH1cclxuICAgICAgICBpZiAoX3NpbXBsZUNoYW5nZXMuaGFzT3duUHJvcGVydHkoJ2NoYXJ0RGF0YScpICYmICFfc2ltcGxlQ2hhbmdlc1snY2hhcnREYXRhJ10uZmlyc3RDaGFuZ2UpIHtcclxuICAgICAgICAgICAgaWYgKF9zaW1wbGVDaGFuZ2VzWydjaGFydERhdGEnXS5jdXJyZW50VmFsdWUgPT09IHRoaXMuZGF0YSkgcmV0dXJuO1xyXG4gICAgICAgICAgICB0aGlzLl9zZXREYXRhKE9iamVjdC5hc3NpZ24oe30sIF9zaW1wbGVDaGFuZ2VzLmNoYXJ0RGF0YS5jdXJyZW50VmFsdWUpKTtcclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgbmdPbkRlc3Ryb3koKTogdm9pZCB7XHJcbiAgICAgICAgaWYgKCF0aGlzLmNoYXJ0RGF0YSB8fCAhdGhpcy5jaGFydENvbmZpZykgcmV0dXJuO1xyXG4gICAgICAgIC8vIHRoaXMuX3Vuc3Vic2NyaWJlKHRoaXMuX3NwbGl0dGVyU3Vic2NyaXB0aW9uQXJyKTtcclxuICAgICAgICAvLyB0aGlzLl9yZW1vdmVMaXN0ZW5lcigpO1xyXG4gICAgfVxyXG5cclxuICAgIC8qKlxyXG4gICAgICogRm9yIEVYUE9SVC4gZXhwb3J0IHNraXBzIGRhdGEgbWFzc2FnZSBhbmQgZ2VuZXJhdGVMZWdlbmREYXRhLCBoZW5jZSBuZWVkIHRvIHNldExlZ2VuZERhdGEgc2VwYXJhdGVseVxyXG4gICAgICogKGFjY3VyYXRlIGFzIG9mIHYzLjcuMCkgYXMgbGVnZW5kRGF0YSBpcyBmb3IgaW50ZXJuYWwgdXNlLCB3ZSBkbyBub3QgcHV0IGluIElucHV0LiB0aGlzIGZ1bmN0aW9uIGlzIGFjY2Vzc2VkIHZpYSBWaWV3Q2hpbGQgZnJvbSBLZFZpc3VhbGl6YXRpb25cclxuICAgICAqIHBhcmFtIHtJTGVnZW5kRGF0YSB9fSBfbGVnZW5kRGF0YVxyXG4gICAgICovXHJcbiAgICBwdWJsaWMgc2V0TGVnZW5kRGF0YShfbGVnZW5kRGF0YTogeyBba2V5OiBzdHJpbmddOiBJTGVnZW5kRGF0YSB9KSB7XHJcbiAgICAgICAgdGhpcy5sZWdlbmREYXRhID0gT2JqZWN0LmFzc2lnbih7fSwgX2xlZ2VuZERhdGEpO1xyXG4gICAgfVxyXG5cclxuICAgIC8qKlxyXG4gICAgICogaW5pdGlhdGUgYXBpIGZyb20gb3V0c2lkZSBrZCBjaGFydHMgY29tcG9uZW50XHJcbiAgICAgKi9cclxuICAgIHByaXZhdGUgaW5pdEFwaSgpOiB2b2lkIHtcclxuICAgICAgICBpZiAodHlwZW9mIHRoaXMuY2hhcnRBcGkgPT09ICd1bmRlZmluZWQnKSByZXR1cm47XHJcblxyXG4gICAgICAgIHRoaXMuY2hhcnRBcGkuY2hhbmdlU2VyaWVzQ29sb3IgPSAobGVnZW5kSWQ6IHN0cmluZywgY29sb3I6IHN0cmluZywgaW5kZXg/OiBudW1iZXIpID0+IHtcclxuICAgICAgICAgICAgaWYgKHR5cGVvZiBpbmRleCA9PT0gJ251bWJlcicpIHRoaXMuX3NldERhdGFDb2xvclNoYXBlKGluZGV4LCBjb2xvcik7XHJcbiAgICAgICAgICAgIHRoaXMubGVnZW5kRGF0YVtsZWdlbmRJZF0uY29sb3IgPSBjb2xvcjtcclxuICAgICAgICAgICAgdGhpcy5fdXBkYXRlTGVnZW5kSWNvbldpdGhJbmRleChsZWdlbmRJZCwgaW5kZXgpO1xyXG4gICAgICAgICAgICB0aGlzLmFwaS5yZWRyYXcoKTtcclxuICAgICAgICB9O1xyXG5cclxuICAgICAgICB0aGlzLmNoYXJ0QXBpLnJlZHJhdyA9ICgpID0+IHRoaXMuYXBpLnJlZHJhdygpO1xyXG5cclxuICAgICAgICAvLyB0aGlzLmNoYXJ0QXBpLmVuYWJsZUxpc3RlbmVyID0gKF9oYXZlTGlzdGVuZXI6IGJvb2xlYW4pID0+IHtcclxuICAgICAgICAvLyAgICAgaWYgKF9oYXZlTGlzdGVuZXIpIHtcclxuICAgICAgICAvLyAgICAgICAgIHRoaXMuX2luaXRMaXN0ZW5lcigpO1xyXG4gICAgICAgIC8vICAgICAgICAgaWYgKHRoaXMuX3NwbGl0dGVyU3Vic2NyaXB0aW9uQXJyLmxlbmd0aCA9PT0gMCkge1xyXG4gICAgICAgIC8vICAgICAgICAgICAgIHRoaXMuX3NwbGl0dGVyU3Vic2NyaXB0aW9uQXJyID0gdGhpcy5faW5pdFNwbGl0dGVyU3Vic2NyaXB0aW9ucyh0aGlzLl9rZFNwbGl0dGVyRXZlbnQpO1xyXG4gICAgICAgIC8vICAgICAgICAgfVxyXG4gICAgICAgIC8vICAgICB9IGVsc2Uge1xyXG4gICAgICAgIC8vICAgICAgICAgdGhpcy5fcmVtb3ZlTGlzdGVuZXIoKTtcclxuICAgICAgICAvLyAgICAgICAgIHRoaXMuX3Vuc3Vic2NyaWJlKHRoaXMuX3NwbGl0dGVyU3Vic2NyaXB0aW9uQXJyKTtcclxuICAgICAgICAvLyAgICAgICAgIHRoaXMuX3NwbGl0dGVyU3Vic2NyaXB0aW9uQXJyID0gW107XHJcbiAgICAgICAgLy8gICAgIH1cclxuICAgICAgICAvLyB9O1xyXG4gICAgfVxyXG5cclxuICAgIC8vID09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PSBMaXN0ZW5lciA9PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09XHJcblxyXG4gICAgLy8gcHJpdmF0ZSBfaW5pdExpc3RlbmVyKCkge1xyXG4gICAgLy8gICAgIHdpbmRvdy5hZGRFdmVudExpc3RlbmVyKCdyZXNpemUnLCB0aGlzLl9yZXNpemVMaXN0ZW5lcik7XHJcbiAgICAvLyB9XHJcblxyXG4gICAgLy8gcHJpdmF0ZSBfcmVtb3ZlTGlzdGVuZXIoKSB7XHJcbiAgICAvLyAgICAgd2luZG93LnJlbW92ZUV2ZW50TGlzdGVuZXIoJ3Jlc2l6ZScsIHRoaXMuX3Jlc2l6ZUxpc3RlbmVyKTtcclxuICAgIC8vIH1cclxuXHJcbiAgICAvLyBwcml2YXRlIF9vblJlc2l6ZSgpOiB2b2lkIHtcclxuICAgIC8vICAgICBjbGVhclRpbWVvdXQodGhpcy5fcmVzaXplVGltZW91dCk7XHJcbiAgICAvLyAgICAgdGhpcy5fcmVzaXplVGltZW91dCA9IHNldFRpbWVvdXQoKCkgPT4ge1xyXG4gICAgLy8gICAgICAgICB0aGlzLmFwaS5yZWRyYXcoKTtcclxuICAgIC8vICAgICB9LCA1MDApO1xyXG4gICAgLy8gfVxyXG5cclxuICAgIC8vID09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PSBTcGxpdHRlciBTdWJzY3JpcHRpb24gPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PVxyXG5cclxuICAgIC8vIHByaXZhdGUgX2luaXRTcGxpdHRlclN1YnNjcmlwdGlvbnMoX3NwbGl0dGVyRXZlbnQpOiBTdWJzY3JpcHRpb25bXSB7XHJcbiAgICAvLyAgICAgaWYgKCFfc3BsaXR0ZXJFdmVudCkgcmV0dXJuO1xyXG5cclxuICAgIC8vICAgICBsZXQgc3Vic2NyaXB0aW9uQXJyOiBTdWJzY3JpcHRpb25bXSA9IFtdO1xyXG5cclxuICAgIC8vICAgICBsZXQgdG9nZ2xlTWVudVN1YiA9IF9zcGxpdHRlckV2ZW50Lm9uVG9nZ2xlTWVudSgpLnN1YnNjcmliZSgoKTogdm9pZCA9PiB7XHJcbiAgICAvLyAgICAgICAgIHRpbWVyKDUwMCkuc3Vic2NyaWJlKCgpOiB2b2lkID0+IHtcclxuICAgIC8vICAgICAgICAgICAgIHRoaXMuYXBpLnJlZHJhdygpO1xyXG4gICAgLy8gICAgICAgICB9KTtcclxuICAgIC8vICAgICB9KTtcclxuICAgIC8vICAgICBsZXQgdG9nZ2xlU3ViUGFuZSA9IF9zcGxpdHRlckV2ZW50Lm9uVG9nZ2xlU3ViUGFuZSgpLnN1YnNjcmliZSgoKTogdm9pZCA9PiB7XHJcbiAgICAvLyAgICAgICAgIHRpbWVyKDUwMCkuc3Vic2NyaWJlKCgpOiB2b2lkID0+IHtcclxuICAgIC8vICAgICAgICAgICAgIHRoaXMuYXBpLnJlZHJhdygpO1xyXG4gICAgLy8gICAgICAgICB9KTtcclxuICAgIC8vICAgICB9KTtcclxuICAgIC8vICAgICBsZXQgZHJhZ01lbnVTdWIgPSBfc3BsaXR0ZXJFdmVudC5vbkRyYWcoKVxyXG4gICAgLy8gICAgICAgICAucGlwZShcclxuICAgIC8vICAgICAgICAgICAgIGRlYm91bmNlVGltZSgxMDApXHJcbiAgICAvLyAgICAgICAgIClcclxuICAgIC8vICAgICAgICAgLnN1YnNjcmliZSgoKTogdm9pZCA9PiB7XHJcbiAgICAvLyAgICAgICAgICAgICB0aGlzLmFwaS5yZWRyYXcoKTtcclxuICAgIC8vICAgICAgICAgfSk7XHJcblxyXG4gICAgLy8gICAgIHN1YnNjcmlwdGlvbkFyci5wdXNoKHRvZ2dsZU1lbnVTdWIpO1xyXG4gICAgLy8gICAgIHN1YnNjcmlwdGlvbkFyci5wdXNoKHRvZ2dsZVN1YlBhbmUpO1xyXG4gICAgLy8gICAgIHN1YnNjcmlwdGlvbkFyci5wdXNoKGRyYWdNZW51U3ViKTtcclxuXHJcbiAgICAvLyAgICAgcmV0dXJuIHN1YnNjcmlwdGlvbkFycjtcclxuICAgIC8vIH1cclxuXHJcbiAgICAvLyBwcml2YXRlIF91bnN1YnNjcmliZShfc3Vic2NyaXB0aW9uQXJyOiBTdWJzY3JpcHRpb25bXSA9IFtdKTogdm9pZCB7XHJcbiAgICAvLyAgICAgaWYgKF9zdWJzY3JpcHRpb25BcnIubGVuZ3RoID09PSAwKSByZXR1cm47XHJcbiAgICAvLyAgICAgX3N1YnNjcmlwdGlvbkFyci5mb3JFYWNoKHN1YnNjcmlwdGlvbiA9PiB7XHJcbiAgICAvLyAgICAgICAgIGlmIChzdWJzY3JpcHRpb24pIHN1YnNjcmlwdGlvbi51bnN1YnNjcmliZSgpO1xyXG4gICAgLy8gICAgIH0pO1xyXG4gICAgLy8gfVxyXG5cclxuICAgIC8vID09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PSBDb25maWcgYW5kIERhdGEgPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PVxyXG5cclxuICAgIHByaXZhdGUgX3NldENvbmZpZyhfY29uZmlnOiBJQ2hhcnRDb25maWcsIF9pc0ZpcnN0Q2hhbmdlPzogYm9vbGVhbik6IHZvaWQge1xyXG4gICAgICAgIC8vIHN0b3JpbmcgY29uZmlnIGluIHRoaXMgY29tcG9uZW50XHJcbiAgICAgICAgdGhpcy5jb25maWcgPSBKU09OLnBhcnNlKEpTT04uc3RyaW5naWZ5KERFRkFVTFRfQ09ORklHKSk7XHJcbiAgICAgICAgdGhpcy5fZGF0YVN2Yy5kZWVwQ29tYmluZU9iamVjdCh0aGlzLmNvbmZpZywgX2NvbmZpZyB8fCB7fSk7XHJcblxyXG4gICAgICAgIC8vIHNldCBjb25maWcgaXMgY2FsbGVkIHR3aWNlLCB0byBpbXByb3ZlIHBlcmZvcm1hbmNlLCBvbmx5IGNhbGwgdGhlIGZvbGxvd2luZyBvbmNlIChhZnRlciBkYXRhIG1hc3NhZ2UpXHJcbiAgICAgICAgaWYgKF9pc0ZpcnN0Q2hhbmdlKSByZXR1cm47XHJcblxyXG4gICAgICAgIHRoaXMuc2V0Q2hhcnRTdHlsZShfY29uZmlnKTtcclxuICAgICAgICBcclxuICAgICAgICB0aGlzLmNoZWNrTWFwU2NhbGUgPSBmYWxzZTtcclxuXHJcbiAgICAgICAgdGhpcy5fc2V0Q2xhc3NOYW1lcygpO1xyXG5cclxuICAgICAgICB0aGlzLl9wb3B1bGF0ZUxlZ2VuZEljb24oKTtcclxuXHJcbiAgICAgICAgdGhpcy5fc2V0TGFiZWxTdHlsZSgpO1xyXG5cclxuXHJcbiAgICAgICAgLy8gc3RvcmluZyBjb25maWcgaW50byBjaGFydCBzZXJ2aWNlXHJcbiAgICAgICAgdGhpcy5fY2hhcnRTdmMuY29uZmlnID0gX2NvbmZpZztcclxuICAgIH1cclxuXHJcbiAgICBwdWJsaWMgc2V0Q2hhcnRTdHlsZShfY29uZmlnOiBJQ2hhcnRDb25maWcpOiB2b2lkIHtcclxuICAgICAgICB0aGlzLmhhdmVrZENoYXJ0Tm9Cb3JkZXJDbGFzcyA9ICFfY29uZmlnLmNoYXJ0Lm1haW5BcmVhLnN0eWxlW1wiYm9yZGVyV2lkdGhcIl07XHJcbiAgICAgICAgaWYgKF9jb25maWcuY2hhcnQubWFpbkFyZWEuc3R5bGVbXCJib3JkZXJXaWR0aFwiXSAmJiBfY29uZmlnLmNoYXJ0Lm1haW5BcmVhLnN0eWxlW1wiYm9yZGVyV2lkdGhcIl0gPT09ICcwcHgnKSB7XHJcbiAgICAgICAgICAgIHRoaXMuaGF2ZWtkQ2hhcnROb0JvcmRlckNsYXNzID0gdHJ1ZTtcclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgLyogVG8gYmUgcmV2aXNpdC4gSG90IGZpeCBmb3IgZG93bmdyYWRlIGNvbXBvbmVudCBhcyBuZ2NsYXNzIHZhbHVlIGRvZXNuJ3QgY2hhbmdlLiovXHJcbiAgICBwcml2YXRlIF9zZXRDbGFzc05hbWVzKCkge1xyXG5cclxuICAgICAgICAvLyBodG1sQ2xhc3NPYmogaXMgYSB3b3JrYXJvdW5kIGZvciBkb3duZ3JhZGUgbWV0aG9kXHJcbiAgICAgICAgdGhpcy5odG1sQ2xhc3NPYmpbJ2NoYXJ0c1dyYXBwZXInXSA9ICcnO1xyXG4gICAgICAgIHRoaXMuaHRtbENsYXNzT2JqWydsZWdlbmRDb250YWluZXInXSA9ICcnO1xyXG4gICAgICAgIFxyXG4gICAgICAgIGlmICh0eXBlb2YgdGhpcy5jb25maWcubGVnZW5kLmZsb2F0ICE9PSB1bmRlZmluZWQgJiYgdGhpcy5jb25maWcubGVnZW5kLmZsb2F0KSB7XHJcbiAgICAgICAgICAgIHRoaXMuaHRtbENsYXNzT2JqLmNoYXJ0c1dyYXBwZXIgKz0gJ2xlZ2VuZC1mbG9hdCAnO1xyXG4gICAgICAgICAgICB0aGlzLmh0bWxDbGFzc09iai5sZWdlbmRDb250YWluZXIgKz0gJ2xlZ2VuZC1mbG9hdCAnO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgaWYgKHR5cGVvZiB0aGlzLmNvbmZpZy5sZWdlbmQudmVydGljYWxBbGlnbiAhPT0gdW5kZWZpbmVkKSB7XHJcbiAgICAgICAgICAgIHRoaXMuaHRtbENsYXNzT2JqLmNoYXJ0c1dyYXBwZXIgKz0gdGhpcy5jb25maWcubGVnZW5kLnZlcnRpY2FsQWxpZ24gKyAnICc7XHJcbiAgICAgICAgICAgIHRoaXMuaHRtbENsYXNzT2JqLmxlZ2VuZENvbnRhaW5lciArPSB0aGlzLmNvbmZpZy5sZWdlbmQudmVydGljYWxBbGlnbiArICcgJztcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIGlmICh0eXBlb2YgdGhpcy5jb25maWcubGVnZW5kLmFsaWduICE9PSB1bmRlZmluZWQpIHtcclxuICAgICAgICAgICAgdGhpcy5odG1sQ2xhc3NPYmouY2hhcnRzV3JhcHBlciArPSB0aGlzLmNvbmZpZy5sZWdlbmQuYWxpZ24gKyAnICc7XHJcbiAgICAgICAgICAgIHRoaXMuaHRtbENsYXNzT2JqLmxlZ2VuZENvbnRhaW5lciArPSB0aGlzLmNvbmZpZy5sZWdlbmQuYWxpZ24gKyAnICc7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICBpZiAodGhpcy5jaGFydENhdGVnb3J5ID09PSAncGllJyB8fCB0aGlzLmNoYXJ0Q2F0ZWdvcnkgPT09ICdtYXAnKSByZXR1cm47XHJcbiAgICAgICAgdGhpcy54QXhpc09wcG9zaXRlID0gdGhpcy5jb25maWcueEF4aXMub3Bwb3NpdGU7XHJcblxyXG4gICAgICAgIC8vIHNldHRpbmcgY2xhc3MgbmFtZSBmb3IgdmVydGljYWwgYXhpcyB0aXRsZSB0byByb3RhdGVcclxuICAgICAgICB0aGlzLnJvdGF0ZVRpdGxlWCA9IHRoaXMuY2hhcnRUeXBlWzBdID09PSAnYmFyJyAmJiB0aGlzLl9jaGFydFN2Yy5jaGVja1JvdGF0ZVRpdGxlRW5hYmxlZCh0aGlzLmNoYXJ0VHlwZSwgdGhpcy5jb25maWcpO1xyXG4gICAgICAgIHRoaXMucm90YXRlVGl0bGVZID0gdGhpcy5jaGFydFR5cGVbMF0gIT09ICdiYXInICYmIHRoaXMuX2NoYXJ0U3ZjLmNoZWNrUm90YXRlVGl0bGVFbmFibGVkKHRoaXMuY2hhcnRUeXBlLCB0aGlzLmNvbmZpZyk7XHJcblxyXG4gICAgICAgIC8vIHRoaXMgZmxhZyBpcyBmb3IgYWxsIGF4aXNDaGFydHMgZXhjZXB0IGZvciBiYXIuIEJhciBkbyBub3QgbmVlZCBwYWRkaW5cclxuICAgICAgICB0aGlzLmhhdmVBeGlzUGFkZGluZyA9IHRoaXMuY2hhcnRUeXBlWzBdICE9PSAnYmFyJztcclxuICAgICAgICB0aGlzLmhhdmVBeGlzU3BlY2lhbFBhZGRpbmcgPSB0aGlzLmNoYXJ0VHlwZVt0aGlzLmNoYXJ0VHlwZS5sZW5ndGggLSAxXSA9PT0gJ3R5cGUyJztcclxuICAgICAgICB0aGlzLmlzTmVnYXRpdmVTdGFjayA9ICh0aGlzLmNoYXJ0Q2F0ZWdvcnkgPT09ICdiYXInIHx8IHRoaXMuY2hhcnRDYXRlZ29yeSA9PT0gJ2NvbHVtbicgKSAmJiB0aGlzLmNoYXJ0VHlwZVsxXSA9PT0gJ3N0YWNrJyAmJiB0aGlzLmNoYXJ0VHlwZVsyXSA9PT0gJ25lZ2F0aXZlJztcclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF91cGRhdGVMZWdlbmRJY29uV2l0aEluZGV4KF9sZWdlbmRJZCwgX2luZGV4PzogbnVtYmVyKSB7XHJcbiAgICAgICAgbGV0IGxlZ2VuZElkOiBzdHJpbmcgPSBfbGVnZW5kSWQsIGxlZ2VuZENvbmZpZzogSUxlZ2VuZERhdGE7XHJcbiAgICAgICAgLy8gaWYgbGVnZW5kSWQgaXMgZ2l2ZW4sIHdlIHNob3VsZCBmb2xsb3cgbGVnZW5kSWRcclxuICAgICAgICBpZiAoIWxlZ2VuZElkKSB7XHJcbiAgICAgICAgICAgIC8vIGlmIG5vIGxlZ2VuZElkLCBmb2xsb3cgX2luZGV4XHJcbiAgICAgICAgICAgIGlmIChfaW5kZXggPT09IG51bGwgfHwgX2luZGV4ID09PSB1bmRlZmluZWQpIHJldHVybjtcclxuICAgICAgICAgICAgbGVnZW5kSWQgPSB0aGlzLmxlZ2VuZExpc3RbX2luZGV4XTtcclxuICAgICAgICB9XHJcbiAgICAgICAgbGVnZW5kQ29uZmlnID0gdGhpcy5sZWdlbmREYXRhW2xlZ2VuZElkXTtcclxuICAgICAgICB0aGlzLl91cGRhdGVMZWdlbmRJY29uKGxlZ2VuZElkLCBsZWdlbmRDb25maWcpO1xyXG4gICAgfVxyXG5cclxuXHJcbiAgICBwcml2YXRlIF9wb3B1bGF0ZUxlZ2VuZEljb24oaW5kZXg/OiBudW1iZXIpOiB2b2lkIHtcclxuICAgICAgICBpZiAoIXRoaXMubGVnZW5kRGF0YSkgcmV0dXJuO1xyXG5cclxuICAgICAgICB0aGlzLmxlZ2VuZExpc3QgPSBPYmplY3Qua2V5cyh0aGlzLmxlZ2VuZERhdGEpO1xyXG5cclxuICAgICAgICBmb3IgKGxldCBpOiBudW1iZXIgPSAwOyBpIDwgdGhpcy5sZWdlbmRMaXN0Lmxlbmd0aDsgaSsrKSB7XHJcbiAgICAgICAgICAgIGxldCBsZWdlbmRJZDogc3RyaW5nID0gdGhpcy5sZWdlbmRMaXN0W2ldO1xyXG4gICAgICAgICAgICBsZXQgbGVnZW5kQ29uZmlnOiBJTGVnZW5kRGF0YSA9IHRoaXMubGVnZW5kRGF0YVtsZWdlbmRJZF07XHJcblxyXG4gICAgICAgICAgICAvLyBsZXQgZWFjaFN2ZyA9IHRoaXMucmVuZGVyZXIuY3JlYXRlRWxlbWVudCgnc3ZnJyk7XHJcbiAgICAgICAgICAgIC8vIHRoaXMucmVuZGVyZXIuc2V0QXR0cmlidXRlKGVhY2hTdmcsICdmaWxsJywgdGhpcy5jb25maWcubGVnZW5kRGF0YVtsZWdlbmRJZF0uY29sb3IpO1xyXG4gICAgICAgICAgICAvLyB0aGlzLnJlbmRlcmVyLnNldEF0dHJpYnV0ZShlYWNoU3ZnLCAnd2lkdGgnLCA4KTtcclxuICAgICAgICAgICAgLy8gdGhpcy5yZW5kZXJlci5zZXRBdHRyaWJ1dGUoZWFjaFN2ZywgJ2hlaWdodCcsIDgpO1xyXG4gICAgICAgICAgICAvLyBsZXQgZWFjaFN2Z1BhdGggPSB0aGlzLnJlbmRlcmVyLmNyZWF0ZUVsZW1lbnQoJ3BhdGgnKTtcclxuICAgICAgICAgICAgLy8gdGhpcy5yZW5kZXJlci5zZXRBdHRyaWJ1dGUoZWFjaFN2Z1BhdGgsICdkJywgdGhpcy5jb25maWcubGVnZW5kRGF0YVtsZWdlbmRJZF0uc2hhcGUpO1xyXG4gICAgICAgICAgICAvLyB0aGlzLnJlbmRlcmVyLmFwcGVuZENoaWxkKGVhY2hTdmcsIGVhY2hTdmdQYXRoKTtcclxuXHJcbiAgICAgICAgICAgIC8vIGxldCB4bWwgPSBuZXcgWE1MU2VyaWFsaXplcigpLnNlcmlhbGl6ZVRvU3RyaW5nKGVhY2hTdmcpO0FSSVxyXG4gICAgICAgICAgICAvLyBsZXQgZGF0YSA9IFwiZGF0YTppbWFnZS9zdmcreG1sO2Jhc2U2NCxcIiArIGJ0b2EoeG1sKTtcclxuXHJcbiAgICAgICAgICAgIC8vIHRoaXMuaWNvbnNbbGVnZW5kSWRdID0gdGhpcy5fc2FuaXRpemVyLmJ5cGFzc1NlY3VyaXR5VHJ1c3RSZXNvdXJjZVVybCgnZGF0YTppbWFnZS9zdmcreG1sO3V0ZjgsPHN2ZyB4bWxucz1cImh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnXCIgZmlsbD1cIicgKyBsZWdlbmRDb25maWcuY29sb3IgKyAnXCIgd2lkdGg9XCI4XCIgaGVpZ2h0PVwiOFwiPjxwYXRoIGQ9XCInICsgdGhpcy5zaGFwZXNbbGVnZW5kQ29uZmlnLnNoYXBlXSArICdcIi8+PC9zdmc+Jyk7XHJcbiAgICAgICAgICAgIC8vIHRoaXMuaWNvbnNbbGVnZW5kSWRdID0gdGhpcy5fc2FuaXRpemVyLmJ5cGFzc1NlY3VyaXR5VHJ1c3RSZXNvdXJjZVVybChkYXRhKTtcclxuXHJcbiAgICAgICAgICAgIC8vIGxlZ2VuZCBpcyBzZXQgYmFzZWQgb24gd2hldGhlciB0aGVyZSBpcyBkZWFjdGl2ZVxyXG4gICAgICAgICAgICB0aGlzLl91cGRhdGVMZWdlbmRJY29uKGxlZ2VuZElkLCBsZWdlbmRDb25maWcpO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF9zZXRMYWJlbFN0eWxlKCk6IHZvaWQge1xyXG4gICAgICAgIGlmICh0aGlzLmNvbmZpZy5jaGFydC5sYWJlbHMuZW5hYmxlZCkge1xyXG4gICAgICAgICAgICBsZXQgbGFiZWxTdHlsZTogc3RyaW5nID0gdGhpcy5fY2hhcnRTdmMuZ2V0U3R5bGUodGhpcy5jb25maWcuY2hhcnQubGFiZWxzLnN0eWxlKTtcclxuXHJcbiAgICAgICAgICAgIHRoaXMuX2FwcGx5TGFiZWxTdHlsZShsYWJlbFN0eWxlLCAnIHNwYW4nLCB0cnVlKTtcclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfc2V0RGF0YShfZGF0YTogYW55KTogdm9pZCB7XHJcbiAgICAgICAgdGhpcy5sZWdlbmRJbmFjdGl2ZSA9IFtdO1xyXG4gICAgICAgIHRoaXMubWFya2Vyc0xlZ2VuZCA9IFtdOyAgICAgICAgXHJcbiAgICAgICAgdGhpcy5fc2V0Q2hhcnRUeXBlKF9kYXRhKTtcclxuXHJcbiAgICAgICAgaWYgKHRoaXMuY29uZmlnLnNraXBNYXNzYWdlKSB7XHJcbiAgICAgICAgICAgIHRoaXMuZGF0YSA9IF9kYXRhO1xyXG4gICAgICAgICAgICB0aGlzLl9zZXRDb25maWcodGhpcy5jb25maWcpO1xyXG4gICAgICAgICAgICByZXR1cm47XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICBpZiAodGhpcy5jaGFydENhdGVnb3J5ID09PSAncGllJyB8fCB0aGlzLmNoYXJ0Q2F0ZWdvcnkgPT09ICdtYXAnKSB7XHJcbiAgICAgICAgICAgIGlmICh0aGlzLmNoYXJ0Q2F0ZWdvcnkgPT09ICdwaWUnKSB0aGlzLl9kYXRhTWFzc2FnZUZvclBpZShfZGF0YSk7XHJcbiAgICAgICAgICAgIGVsc2UgaWYgKHRoaXMuY2hhcnRDYXRlZ29yeSA9PT0gJ21hcCcpIHRoaXMuX2RhdGFNYXNzYWdlRm9yTWFwKF9kYXRhKTtcclxuICAgICAgICAgICAgLy8gZWxzZSBpZiAodGhpcy5jaGFydENhdGVnb3J5ID09PSAnbWFwJykgdGhpcy5kYXRhID0gX2RhdGE7XHJcbiAgICAgICAgICAgIHRoaXMuX3NldENvbmZpZyh0aGlzLmNvbmZpZyk7XHJcbiAgICAgICAgfSBlbHNlIHRoaXMuX2RhdGFNYXNzYWdlKF9kYXRhKTtcclxuXHJcbiAgICAgICAgLy8gZW1pdCBkYXRhIHRvIGtkLXZpc3VhbGl6YXRpb24gdG8gcHJlcGFyZSBmb3IgZXhwb3J0XHJcbiAgICAgICAgdGhpcy5vdXRwdXREYXRhLmVtaXQodGhpcy5kYXRhKTtcclxuXHJcbiAgICAgICAgLy8gZW1pdCBjdXJyZW50IGNvbmZpZyB0byBrZC12aXN1YWxpemF0aW9uIHRvIHByZXBhcmUgZm9yIGV4cG9ydFxyXG4gICAgICAgIHRoaXMub3V0cHV0TGVnZW5kRGF0YS5lbWl0KHRoaXMubGVnZW5kRGF0YSk7XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfc2V0Q2hhcnRUeXBlKF9kYXRhKSB7XHJcbiAgICAgICAgbGV0IGRhdGFUb1VzZTogYW55ID0gX2RhdGE7XHJcbiAgICAgICAgaWYgKCF0aGlzLmNvbmZpZy5za2lwTWFzc2FnZSB8fCAoX2RhdGEuY2hhcnQgJiYgX2RhdGEuY2hhcnQudHlwZSA9PSAnbWFwJykpIHtcclxuICAgICAgICAgICAgZGF0YVRvVXNlID0gX2RhdGEuY2hhcnQ7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIHRoaXMuY2hhcnRDYXRlZ29yeSA9IGRhdGFUb1VzZS50eXBlO1xyXG4gICAgICAgIHRoaXMuY2hhcnRUeXBlID0gZGF0YVRvVXNlLmxheW91dC5zcGxpdCgnLScpO1xyXG4gICAgICAgIHRoaXMuaXNBeGlzQ2hhcnQgPSBkYXRhVG9Vc2UudHlwZSAhPT0gJ3BpZScgJiYgZGF0YVRvVXNlLnR5cGUgIT09ICdtYXAnO1xyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX3NldERhdGFDb2xvclNoYXBlKF9pbmRleDogbnVtYmVyLCBfY29sb3I6IHN0cmluZyk6IHZvaWQge1xyXG4gICAgICAgIGlmIChfaW5kZXggPCAwKSB7IHJldHVybjsgfVxyXG4gICAgICAgIC8vIGxldCBjaGFuZ2VTZXJpZXM6IGJvb2xlYW4gPSB0aGlzLmNvbmZpZy5jaGFydC5oYXNPd25Qcm9wZXJ0eSgncGVyc2lzdGVudFNlcmllc0NoYW5nZScpID8gdGhpcy5jb25maWcuY2hhcnQucGVyc2lzdGVudFNlcmllc0NoYW5nZSA6IHRydWU7XHJcbiAgICAgICAgbGV0IGxlZ2VuZElkczogQXJyYXk8c3RyaW5nPiA9IE9iamVjdC5rZXlzKHRoaXMubGVnZW5kRGF0YSk7XHJcbiAgICAgICAgaWYgKHRoaXMuY2hhcnRDYXRlZ29yeSAhPSAnbWFwJykge1xyXG4gICAgICAgICAgICBmb3IgKGxldCB4SW5kZXg6IG51bWJlciA9IHRoaXMuZGF0YS5kYXRhLmxlbmd0aCAtIDE7IHhJbmRleCA+PSAwOyB4SW5kZXgtLSkge1xyXG4gICAgICAgICAgICAgICAgZm9yIChsZXQgeUluZGV4OiBudW1iZXIgPSB0aGlzLmRhdGEuZGF0YVt4SW5kZXhdLnkubGVuZ3RoIC0gMTsgeUluZGV4ID49IDA7IHlJbmRleC0tKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKHRoaXMuZGF0YS5kYXRhW3hJbmRleF0ueVt5SW5kZXhdLmlkID09PSBsZWdlbmRJZHNbX2luZGV4XSkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLl9jaGFuZ2VTZXJpZXMoeEluZGV4LCB5SW5kZXgsICdjb2xvcicpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLl9jaGFuZ2VTZXJpZXMoeEluZGV4LCB5SW5kZXgsICdzaGFwZScpO1xyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF9jaGFuZ2VTZXJpZXMoX3hJbmRleDogbnVtYmVyLCBfeUluZGV4OiBudW1iZXIsIF9lbGVtZW50OiAnY29sb3InIHwgJ3NoYXBlJyk6IHZvaWQge1xyXG4gICAgICAgIGxldCBsZWdlbmRJZDogc3RyaW5nID0gdGhpcy5kYXRhLmRhdGFbX3hJbmRleF0ueVtfeUluZGV4XS5pZDtcclxuICAgICAgICBsZXQgb3V0cHV0OiBhbnkgPSB0aGlzLmxlZ2VuZERhdGFbbGVnZW5kSWRdW19lbGVtZW50XTtcclxuICAgICAgICBpZiAoX2VsZW1lbnQgPT09ICdzaGFwZScpIHtcclxuICAgICAgICAgICAgb3V0cHV0ID0gdGhpcy5zaGFwZXNbb3V0cHV0XTtcclxuICAgICAgICB9XHJcbiAgICAgICAgaWYgKHRoaXMuX2lzQ2hhbmdlU2VyaWVzKF94SW5kZXgsIF95SW5kZXgsIF9lbGVtZW50KSkge1xyXG4gICAgICAgICAgICB0aGlzLmRhdGEuZGF0YVtfeEluZGV4XS55W195SW5kZXhdW19lbGVtZW50XSA9IG91dHB1dDtcclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfaXNDaGFuZ2VTZXJpZXMoX3hJbmRleDogbnVtYmVyLCBfeUluZGV4OiBudW1iZXIsIF9lbGVtZW50OiAnY29sb3InIHwgJ3NoYXBlJyk6IGJvb2xlYW4ge1xyXG4gICAgICAgIGxldCBjaGFuZ2VTZXJpZXM6IGJvb2xlYW4gPSB0aGlzLmNvbmZpZy5jaGFydC5oYXNPd25Qcm9wZXJ0eSgncGVyc2lzdGVudFNlcmllc0NoYW5nZScpID8gdGhpcy5jb25maWcuY2hhcnQucGVyc2lzdGVudFNlcmllc0NoYW5nZSA6IHRydWU7XHJcbiAgICAgICAgaWYgKGNoYW5nZVNlcmllcykge1xyXG4gICAgICAgICAgICByZXR1cm4gdHJ1ZTtcclxuICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICBpZiAodGhpcy5jaGFydERhdGEuc2VyaWVzW195SW5kZXhdLmRhdGFbX3hJbmRleF0uaGFzT3duUHJvcGVydHkoX2VsZW1lbnQpKSB7XHJcbiAgICAgICAgICAgICAgICBpZiAodGhpcy5jaGFydERhdGEuc2VyaWVzW195SW5kZXhdLmRhdGFbX3hJbmRleF1bX2VsZW1lbnRdICE9PSBudWxsIHx8IHRoaXMuY2hhcnREYXRhLnNlcmllc1tfeUluZGV4XS5kYXRhW194SW5kZXhdW19lbGVtZW50XS5sZW5ndGggPiAwKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIGZhbHNlO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgICAgIHJldHVybiB0cnVlO1xyXG4gICAgfVxyXG5cclxuICAgIHB1YmxpYyBvbkxlZ2VuZENsaWNrKF9pZDogc3RyaW5nKTogdm9pZCB7XHJcbiAgICAgICAgbGV0IGxlZ2VuZENvbmZpZzogSUxlZ2VuZERhdGEgPSB0aGlzLmxlZ2VuZERhdGFbX2lkXTtcclxuXHJcbiAgICAgICAgbGVnZW5kQ29uZmlnLmRlYWN0aXZlID0gIWxlZ2VuZENvbmZpZy5kZWFjdGl2ZSB8fCBmYWxzZTtcclxuXHJcbiAgICAgICAgdGhpcy5fdXBkYXRlTGVnZW5kSXRlbShfaWQsIGxlZ2VuZENvbmZpZyk7XHJcblxyXG4gICAgICAgIGlmIChsZWdlbmRDb25maWcuZGVhY3RpdmUpIHtcclxuICAgICAgICAgICAgdGhpcy5sZWdlbmRJbmFjdGl2ZS5wdXNoKF9pZCk7XHJcbiAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgbGV0IGlkSW5kZXg6IG51bWJlciA9IHRoaXMubGVnZW5kSW5hY3RpdmUuaW5kZXhPZihfaWQpO1xyXG4gICAgICAgICAgICBpZiAoaWRJbmRleCAhPT0gLTEpIHtcclxuICAgICAgICAgICAgICAgIHRoaXMubGVnZW5kSW5hY3RpdmUuc3BsaWNlKGlkSW5kZXgsIDEpO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICBpZiAodGhpcy5jaGFydENhdGVnb3J5ICE9ICdtYXAnKSB7XHJcbiAgICAgICAgICAgIGxldCBsZWdlbmREYXRhOiB7IFtrZXk6IHN0cmluZ106IElMZWdlbmREYXRhIH0gPSB0aGlzLnVwZGF0ZUNvbmZpZygpO1xyXG4gICAgICAgICAgICBsZXQgZGF0YTogSUQzRGF0YSA9IHRoaXMudXBkYXRlRGF0YShsZWdlbmREYXRhKTtcclxuXHJcbiAgICAgICAgICAgIHRoaXMuYXBpLmxlZ2VuZENsaWNrKGRhdGEsIGxlZ2VuZERhdGEpO1xyXG4gICAgICAgICAgICB0aGlzLl90b2dnbGVEYXRhTGFiZWwoX2lkLCBsZWdlbmRDb25maWcuZGVhY3RpdmUpO1xyXG4gICAgICAgICAgICAvLyB1cGRhdGUgZGF0YSB0byBrZC12aXN1YWxpemF0aW9uIHRvIHByZXBhcmUgZm9yIGV4cG9ydGluZ1xyXG4gICAgICAgICAgICB0aGlzLm91dHB1dERhdGEuZW1pdChkYXRhKTtcclxuICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICB0aGlzLmFwaS5sZWdlbmRDbGljayhfaWQsIGxlZ2VuZENvbmZpZy5kZWFjdGl2ZSk7XHJcbiAgICAgICAgfVxyXG5cclxuICAgIH1cclxuXHJcbiAgICBwdWJsaWMgb25DbHVzdGVyQ2xpY2soX2lkOiBhbnkpOiB2b2lkIHtcclxuICAgICAgICBsZXQgbGVnZW5kSXRlbU1hcmtlcjogSFRNTEVsZW1lbnQgPSB0aGlzLl9lbGVtZW50UmVmLm5hdGl2ZUVsZW1lbnQucXVlcnlTZWxlY3RvcignI2tkbGktJyArIF9pZC5pZCArICcgLmF3ZXNvbWUtbWFya2VyJyk7XHJcbiAgICAgICAgbGV0IGxlZ2VuZEl0ZW1MYWJlbDogSFRNTEVsZW1lbnQgPSB0aGlzLl9lbGVtZW50UmVmLm5hdGl2ZUVsZW1lbnQucXVlcnlTZWxlY3RvcignI2tkbGktJyArIF9pZC5pZCArICcgLmtkeC1sZWdlbmQtbGFiZWwnKTtcclxuXHJcbiAgICAgICAgdGhpcy5hcGkuY2x1c3RlckNsaWNrKF9pZCwgeydsZWdlbmRJdGVtTWFya2VyJzogbGVnZW5kSXRlbU1hcmtlciwgJ2xlZ2VuZEl0ZW1MYWJlbCc6IGxlZ2VuZEl0ZW1MYWJlbH0pO1xyXG4gICAgfVxyXG5cclxuICAgIHB1YmxpYyBnZXRPdXRwdXRMZWdlbmQoX2xlZ2VuZERhdGE6IHsgW2tleTogc3RyaW5nXTogSUxlZ2VuZERhdGEgfSk6IHZvaWQge1xyXG4gICAgICAgIGlmICh0aGlzLmNoYXJ0Q2F0ZWdvcnkgPT0gJ21hcCcgJiYgT2JqZWN0LmtleXMoX2xlZ2VuZERhdGEpLmxlbmd0aCA9PSAwKSB7XHJcbiAgICAgICAgICAgIHRoaXMuY2hlY2tNYXBTY2FsZSA9IHRydWU7XHJcbiAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgdGhpcy5sZWdlbmREYXRhID0gX2xlZ2VuZERhdGE7XHJcbiAgICAgICAgICAgIHRoaXMuY2hlY2tNYXBTY2FsZSA9IGZhbHNlO1xyXG4gICAgICAgICAgICB0aGlzLl9waWVEb25lRmxhZyA9IHRydWU7XHJcbiAgICAgICAgICAgIHRoaXMub3V0cHV0TGVnZW5kRGF0YS5lbWl0KHRoaXMubGVnZW5kRGF0YSk7XHJcbiAgICAgICAgICAgIHRoaXMuX3BvcHVsYXRlTGVnZW5kSWNvbih1bmRlZmluZWQpO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICBwdWJsaWMgZ2V0T3V0cHV0RGF0YShfZGF0YTogYW55KTogdm9pZCB7XHJcbiAgICAgICAgLy8gdGhpcy5vdXRwdXREYXRhLmVtaXQoX2RhdGEpO1xyXG4gICAgICAgIHRoaXMub3V0cHV0QXJlYS5lbWl0KF9kYXRhKTtcclxuICAgIH1cclxuXHJcbiAgICBwdWJsaWMgZ2V0UmVhZHkoX3ZhbHVlOiBib29sZWFuKSA6IHZvaWQge1xyXG4gICAgICAgIHRoaXMuaXNMYXllckxvYWRpbmcgPSBfdmFsdWU7XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfdXBkYXRlTGVnZW5kSXRlbShfaWQsIF9sZWdlbmRDb25maWcpOiB2b2lkIHtcclxuICAgICAgICB0aGlzLl91cGRhdGVMZWdlbmRJY29uKF9pZCwgX2xlZ2VuZENvbmZpZyk7XHJcbiAgICAgICAgbGV0IHRleHRDb2xvcjogc3RyaW5nID0gKF9sZWdlbmRDb25maWcuZGVhY3RpdmUpID8gdGhpcy5jb25maWcubGVnZW5kLml0ZW0uaW5hY3RpdmVDb2xvciB8fCAnI0NDQ0NDQycgOiB0aGlzLmNvbmZpZy5sZWdlbmQuaXRlbS5zdHlsZS5jb2xvciB8fCB0aGlzLmNvbmZpZy5sZWdlbmQuaXRlbS5hY3RpdmVDb2xvciB8fCAnIzAwMDAwMCc7XHJcbiAgICAgICAgdGhpcy5fZWxlbWVudFJlZi5uYXRpdmVFbGVtZW50LnF1ZXJ5U2VsZWN0b3IoJyNrZGxpLScgKyBfaWQpLnN0eWxlLmNvbG9yID0gdGV4dENvbG9yO1xyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX3VwZGF0ZUxlZ2VuZEljb24oX2lkLCBfbGVnZW5kQ29uZmlnKTogdm9pZCB7XHJcbiAgICAgICAgbGV0IGljb25Db2xvcjogc3RyaW5nID0gKF9sZWdlbmRDb25maWcuZGVhY3RpdmUpID8gdGhpcy5jb25maWcubGVnZW5kLml0ZW0uaW5hY3RpdmVDb2xvciB8fCAnI0NDQ0NDQycgOiBfbGVnZW5kQ29uZmlnLmNvbG9yIHx8ICcjMDAwMDAwJztcclxuICAgICAgICBsZXQgcmdiQ29sb3I6IHN0cmluZyA9IHRoaXMuX2NvbnZlcnRpb25TdmMuY29sb3JUb1JnYihpY29uQ29sb3IpO1xyXG4gICAgICAgIHRoaXMuaWNvbnNbX2lkXSA9IHRoaXMuX3Nhbml0aXplci5ieXBhc3NTZWN1cml0eVRydXN0UmVzb3VyY2VVcmwoJ2RhdGE6aW1hZ2Uvc3ZnK3htbDt1dGY4LDxzdmcgeG1sbnM9XCJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2Z1wiIGZpbGw9XCInICsgcmdiQ29sb3IgKyAnXCIgd2lkdGg9XCI4XCIgaGVpZ2h0PVwiOFwiPjxwYXRoIGQ9XCInICsgdGhpcy5zaGFwZXNbX2xlZ2VuZENvbmZpZy5zaGFwZV0gKyAnXCIvPjwvc3ZnPicpO1xyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX3RvZ2dsZURhdGFMYWJlbChpZDogc3RyaW5nLCBkZWFjdGl2ZTogYm9vbGVhbik6IHZvaWQge1xyXG4gICAgICAgIGxldCBkaXNwbGF5U3RhdGU6IHN0cmluZyA9IChkZWFjdGl2ZSkgPyAnbm9uZScgOiAnZmxleCc7XHJcbiAgICAgICAgdGhpcy5fYXBwbHlMYWJlbFN0eWxlKGRpc3BsYXlTdGF0ZSwgJy55LScgKyBpZCk7XHJcbiAgICAgICAgaWYgKCFkZWFjdGl2ZSkgdGhpcy5fYXBwbHlMYWJlbFN0eWxlKCdkaXNwbGF5OicgKyBkaXNwbGF5U3RhdGUsICcueS0nICsgaWQgKyAnIHNwYW4nLCB0cnVlKTtcclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF9hcHBseUxhYmVsU3R5bGUoX3N0eWxlOiBzdHJpbmcsIHRhcmdldDogc3RyaW5nLCBpc1JlcG9zaXRpb25pbmc/OiBib29sZWFuKTogdm9pZCB7XHJcbiAgICAgICAgdGFyZ2V0ID0gdGFyZ2V0IHx8ICcnO1xyXG4gICAgICAgIGxldCBhbGxMYWJlbDogSFRNTEVsZW1lbnQgPSB0aGlzLl9lbGVtZW50UmVmLm5hdGl2ZUVsZW1lbnQucXVlcnlTZWxlY3RvckFsbCgnIycgKyB0aGlzLmNvbmZpZy5pZCArICcgLmtkeC1jaGFydHMtZGF0YS1sYWJlbCcgKyB0YXJnZXQpO1xyXG4gICAgICAgIGZvciAobGV0IGkgaW4gYWxsTGFiZWwpIHtcclxuICAgICAgICAgICAgaWYgKGFsbExhYmVsW2ldLnN0eWxlKSB7XHJcblxyXG4gICAgICAgICAgICAgICAgaWYgKGlzUmVwb3NpdGlvbmluZykge1xyXG4gICAgICAgICAgICAgICAgICAgIGxldCBsYWJlbFdpZHRoOiBudW1iZXIgPSBhbGxMYWJlbFtpXS5vZmZzZXRXaWR0aDtcclxuICAgICAgICAgICAgICAgICAgICBsZXQgbGFiZWxDZW50ZXI6IG51bWJlciA9IChsYWJlbFdpZHRoIC0gbGFiZWxXaWR0aCAvIGFsbExhYmVsW2ldLmlubmVyVGV4dC50b1N0cmluZygpLmxlbmd0aCkgLyAyO1xyXG4gICAgICAgICAgICAgICAgICAgIGxldCBzaGlmdFBvc2l0aW9uOiBudW1iZXIgPSAwIC0gbGFiZWxDZW50ZXI7XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIF9zdHlsZSArPSAnbGVmdDonICsgc2hpZnRQb3NpdGlvbiArICdweDsnO1xyXG4gICAgICAgICAgICAgICAgICAgIGFsbExhYmVsW2ldLnN0eWxlID0gX3N0eWxlO1xyXG4gICAgICAgICAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgICAgICAgICBhbGxMYWJlbFtpXS5zdHlsZS5kaXNwbGF5ID0gX3N0eWxlO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgdXBkYXRlQ29uZmlnKCk6IHsgW2tleTogc3RyaW5nXTogSUxlZ2VuZERhdGEgfSB7XHJcbiAgICAgICAgbGV0IGxlZ2VuZERhdGE6IHsgW2tleTogc3RyaW5nXTogSUxlZ2VuZERhdGEgfSA9IE9iamVjdC5hc3NpZ24oe30sIHRoaXMubGVnZW5kRGF0YSk7XHJcbiAgICAgICAgbGV0IGxlZ2VuZEluYWN0aXZlOiBBcnJheTxzdHJpbmc+ID0gdGhpcy5sZWdlbmRJbmFjdGl2ZTtcclxuICAgICAgICBsZWdlbmREYXRhID0gT2JqZWN0LmtleXMobGVnZW5kRGF0YSlcclxuICAgICAgICAgICAgLmZpbHRlcihrZXkgPT4gIWxlZ2VuZEluYWN0aXZlLmluY2x1ZGVzKGtleSkpXHJcbiAgICAgICAgICAgIC5yZWR1Y2UoKG9iaiwga2V5KSA9PiB7XHJcbiAgICAgICAgICAgICAgICBvYmpba2V5XSA9IGxlZ2VuZERhdGFba2V5XTtcclxuICAgICAgICAgICAgICAgIHJldHVybiBvYmo7XHJcbiAgICAgICAgICAgIH0sIHt9KTtcclxuICAgICAgICByZXR1cm4gbGVnZW5kRGF0YTtcclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIHVwZGF0ZURhdGEoX2xlZ2VuZERhdGE/OiB7IFtrZXk6IHN0cmluZ106IElMZWdlbmREYXRhIH0pOiBJRDNEYXRhIHtcclxuICAgICAgICBsZXQgdGhpc0RhdGE6IElEM0RhdGEgPSBKU09OLnBhcnNlKEpTT04uc3RyaW5naWZ5KHRoaXMuZGF0YSkpO1xyXG4gICAgICAgIGxldCBsZWdlbmRJbmFjdGl2ZTogQXJyYXk8c3RyaW5nPiA9IHRoaXMubGVnZW5kSW5hY3RpdmU7XHJcblxyXG4gICAgICAgIGlmICh0aGlzLmNoYXJ0Q2F0ZWdvcnkgPT09ICdwaWUnKSB7XHJcbiAgICAgICAgICAgIGxldCBsZWdlbmREYXRhOiBhbnkgPSBfbGVnZW5kRGF0YTtcclxuICAgICAgICAgICAgLy8gcGllZGF0YSB1c2VzIGxlZ2VuZERhdGEgaW5zdGVhZCBvZiBkYXRhXHJcbiAgICAgICAgICAgIHRoaXNEYXRhLmRhdGEgPSBPYmplY3Qua2V5cyhsZWdlbmREYXRhKS5tYXAoa2V5ID0+IGxlZ2VuZERhdGFba2V5XSkuZmlsdGVyKCh2YWx1ZSkgPT4gdmFsdWUueSAmJiB2YWx1ZS55ID4gMCk7XHJcbiAgICAgICAgICAgIHJldHVybiB0aGlzRGF0YTtcclxuICAgICAgICB9IGVsc2UgaWYgKHRoaXMuY2hhcnRUeXBlWzFdID09PSAnMTAwJyAmJiB0aGlzLmNoYXJ0VHlwZVswXSA9PT0gJ2FyZWEnKSB7XHJcbiAgICAgICAgICAgIGZvciAobGV0IGk6IG51bWJlciA9IHRoaXNEYXRhLmRhdGEubGVuZ3RoIC0gMTsgaSA+PSAwOyBpLS0pIHtcclxuICAgICAgICAgICAgICAgIGxldCBuZXdZQXJyOiBBcnJheTxJRDNZRGF0YT4gPSB0aGlzRGF0YS5kYXRhW2ldLnkuZmlsdGVyKGQgPT4gIWxlZ2VuZEluYWN0aXZlLmluY2x1ZGVzKGQuaWQpKTtcclxuICAgICAgICAgICAgICAgIHRoaXNEYXRhLmRhdGFbaV0gPSBPYmplY3QuYXNzaWduKHt9LCB0aGlzRGF0YS5kYXRhW2ldLCB7IHk6IG5ld1lBcnIgfSk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIGxldCBvcmlnaW5hbERhdGE6IElEM0RhdGEgPSBKU09OLnBhcnNlKEpTT04uc3RyaW5naWZ5KHRoaXNEYXRhKSk7XHJcblxyXG4gICAgICAgIGxldCBhbGxTdW1BcnJNYXg6IEFycmF5PG51bWJlcj4gPSBbMF07XHJcbiAgICAgICAgbGV0IGFsbFN1bUFyck1pbjogQXJyYXk8bnVtYmVyPiA9IFswXTtcclxuICAgICAgICBsZXQgaGF2ZU5lZ2F0aXZlOiBib29sZWFuID0gZmFsc2U7XHJcblxyXG4gICAgICAgIGZvciAobGV0IGk6IG51bWJlciA9IDA7IGkgPCBvcmlnaW5hbERhdGEuZGF0YS5sZW5ndGg7IGkrKykge1xyXG4gICAgICAgICAgICBsZXQgdG90YWxTdW06IG51bWJlciA9IDE7XHJcbiAgICAgICAgICAgIGlmICh0aGlzLmNoYXJ0VHlwZVsxXSA9PT0gJzEwMCcpIHtcclxuICAgICAgICAgICAgICAgIHRvdGFsU3VtID0gdGhpc0RhdGEuZGF0YVtpXS55LnJlZHVjZSgoYWNjLCBjdXJyLCB5SW5kZXgpID0+IHtcclxuICAgICAgICAgICAgICAgICAgICBpZiAobGVnZW5kSW5hY3RpdmUuaW5jbHVkZXMoY3Vyci5pZCkpIHJldHVybiBhY2M7XHJcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIGFjYyArIGN1cnIudmFsdWU7XHJcbiAgICAgICAgICAgICAgICB9LCAwKTtcclxuICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgbGV0IG5ld1lBcnI6IEFycmF5PGFueT4gPSBbXTtcclxuICAgICAgICAgICAgbGV0IHN1bUFycjogQXJyYXk8bnVtYmVyPiA9IFtdO1xyXG4gICAgICAgICAgICBsZXQgc3VtOiBudW1iZXIgPSAwO1xyXG4gICAgICAgICAgICBsZXQgc3VtTmVnYXRpdmU6IG51bWJlciA9IDA7XHJcblxyXG4gICAgICAgICAgICBmb3IgKGxldCB5SW5kZXg6IG51bWJlciA9IDA7IHlJbmRleCA8IG9yaWdpbmFsRGF0YS5kYXRhW2ldLnkubGVuZ3RoOyB5SW5kZXgrKykge1xyXG4gICAgICAgICAgICAgICAgbGV0IGN1cnJZOiBJRDNZRGF0YSA9IE9iamVjdC5hc3NpZ24oe30sIG9yaWdpbmFsRGF0YS5kYXRhW2ldLnlbeUluZGV4XSk7XHJcbiAgICAgICAgICAgICAgICBpZiAobGVnZW5kSW5hY3RpdmUuaW5jbHVkZXMoY3VyclkuaWQpKSBjb250aW51ZTtcclxuICAgICAgICAgICAgICAgIGxldCBjdXJyZW50VmFsOiBudW1iZXIgPSBjdXJyWS52YWx1ZSA9PT0gbnVsbCA/IDAgOiBjdXJyWS52YWx1ZTtcclxuICAgICAgICAgICAgICAgIGxldCBjdXJyU2lnbjogbnVtYmVyID0gTWF0aC5zaWduKGN1cnJlbnRWYWwpO1xyXG5cclxuICAgICAgICAgICAgICAgIGlmIChjdXJyU2lnbiA8IDAgJiYgIWhhdmVOZWdhdGl2ZSkge1xyXG4gICAgICAgICAgICAgICAgICAgIGhhdmVOZWdhdGl2ZSA9IHRydWU7XHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKHRoaXMuY2hhcnRUeXBlWzFdID09PSAnMTAwJykge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLmNoYXJ0SGlkZSA9IHRydWU7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgICAgICBpZiAodGhpcy5jaGFydFR5cGVbMV0gIT09ICcxMDAnICYmIHRoaXMuY2hhcnRUeXBlWzFdID09PSAnc3RhY2snKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKGN1cnJTaWduID49IDApIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgc3VtID0gKGN1cnJlbnRWYWwgPT09IG51bGwpID8gc3VtIDogc3VtICsgY3VycmVudFZhbDtcclxuICAgICAgICAgICAgICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBzdW1OZWdhdGl2ZSA9IChjdXJyZW50VmFsID09PSBudWxsKSA/IHN1bU5lZ2F0aXZlIDogc3VtTmVnYXRpdmUgKyBjdXJyZW50VmFsO1xyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIH0gZWxzZSBpZiAodGhpcy5jaGFydFR5cGVbMV0gPT09ICcxMDAnKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKGN1cnJlbnRWYWwgIT09IG51bGwgJiYgdG90YWxTdW0gIT09IDApIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgY3VycmVudFZhbCA9IGN1cnJlbnRWYWwgLyB0b3RhbFN1bSAqIDEwMDtcclxuICAgICAgICAgICAgICAgICAgICAgICAgc3VtID0gc3VtICsgY3VycmVudFZhbDtcclxuICAgICAgICAgICAgICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBzdW0gPSBzdW07XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgICAgICAgICBpZiAoY3VyclNpZ24gPj0gMCkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBzdW0gPSAoY3VycmVudFZhbCA9PT0gbnVsbCkgPyAwIDogY3VycmVudFZhbDtcclxuICAgICAgICAgICAgICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBzdW1OZWdhdGl2ZSA9IChjdXJyZW50VmFsID09PSBudWxsKSA/IDAgOiBjdXJyZW50VmFsO1xyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIGN1cnJZLnN1bSA9IGN1cnJlbnRWYWwgPj0gMCA/IHN1bSA6IHN1bU5lZ2F0aXZlO1xyXG5cclxuICAgICAgICAgICAgICAgIC8vIHZhbHVlIGlzIHVzZWQgdG8gZGlzcGxheSBkYXRhLWxhYmVsIGFuZCB0b29sdGlwLCByZW5kZXJWYWwgaXMgdGhlIGFjdXRhbCBwZXJjZW50YWdlIHRvIHBhc3MgdG8gZDMgZm9yIHJlbmRlcmluZ1xyXG4gICAgICAgICAgICAgICAgaWYgKHRoaXMuY2hhcnRUeXBlWzFdID09PSAnMTAwJykgY3VycllbJ3JlbmRlclZhbCddID0gY3VycmVudFZhbDtcclxuXHJcbiAgICAgICAgICAgICAgICBzdW1BcnIucHVzaChNYXRoLnNpZ24oY3VycmVudFZhbCkgPCAwID8gc3VtTmVnYXRpdmUgOiBzdW0pO1xyXG4gICAgICAgICAgICAgICAgbmV3WUFyci5wdXNoKGN1cnJZKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBhbGxTdW1BcnJNYXgucHVzaCh0aGlzLl9jaGFydFN2Yy5nZXREM01heE9yTWluKHN1bUFyciwgJ21heCcpKTtcclxuICAgICAgICAgICAgYWxsU3VtQXJyTWluLnB1c2godGhpcy5fY2hhcnRTdmMuZ2V0RDNNYXhPck1pbihzdW1BcnIsICdtaW4nKSk7XHJcbiAgICAgICAgICAgIHRoaXNEYXRhLmRhdGFbaV0gPSBPYmplY3QuYXNzaWduKHt9LCBvcmlnaW5hbERhdGEuZGF0YVtpXSwgeyB5OiBuZXdZQXJyIH0pO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgdGhpc0RhdGFbJ3JhbmdlJ10gPSB7XHJcbiAgICAgICAgICAgIG1heDogdGhpcy5fY2hhcnRTdmMuZ2V0RDNNYXhPck1pbihhbGxTdW1BcnJNYXgsICdtYXgnKSxcclxuICAgICAgICAgICAgbWluOiB0aGlzLl9jaGFydFN2Yy5nZXREM01heE9yTWluKGFsbFN1bUFyck1pbiwgJ21pbicpXHJcbiAgICAgICAgfTtcclxuICAgICAgICB0aGlzRGF0YVsnaGF2ZU5lZ2F0aXZlJ10gPSBoYXZlTmVnYXRpdmU7XHJcblxyXG4gICAgICAgIHJldHVybiB0aGlzRGF0YTtcclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF9nZW5lcmF0ZUxlZ2VuZERhdGEoX2RhdGE6IElDaGFydERhdGEsIG1heFNlcmllc0xlbmd0aDogbnVtYmVyKTogb2JqZWN0IHtcclxuICAgICAgICAvLyBlbXB0eSBvdXQgdmFyaWFibGVzIGJlZm9yZSByZWdlbmVyYXRpbmdcclxuICAgICAgICB0aGlzLmxlZ2VuZERhdGEgPSB7fTtcclxuICAgICAgICAvLyB0aGlzLmxlZ2VuZExpc3QgPSBudWxsO1xyXG5cclxuICAgICAgICBsZXQgbGVnZW5kSWRTZWFyY2g6IG9iamVjdCA9IHt9O1xyXG4gICAgICAgIGxldCBsZWdlbmRJZDogc3RyaW5nLCBsZWdlbmREYXRhT2JqOiBJTGVnZW5kRGF0YTtcclxuICAgICAgICBsZXQgbGVnZW5kRGF0YTogeyBba2V5OiBzdHJpbmddOiBJTGVnZW5kRGF0YSB9ID0ge307XHJcbiAgICAgICAgZm9yIChsZXQgaTogbnVtYmVyID0gMDsgaSA8IG1heFNlcmllc0xlbmd0aDsgaSsrKSB7XHJcbiAgICAgICAgICAgIGxlZ2VuZElkID0gKF9kYXRhLnNlcmllc1tpXSAmJiBfZGF0YS5zZXJpZXNbaV0ubGVuZ3RoID4gMCkgPyBfZGF0YS5zZXJpZXNbaV0uaWQgOiAnaWQnICsgaTtcclxuICAgICAgICAgICAgbGVnZW5kRGF0YU9iaiA9IHtcclxuICAgICAgICAgICAgICAgICduYW1lJzogX2RhdGEuc2VyaWVzW2ldLm5hbWUsXHJcbiAgICAgICAgICAgICAgICAnaWQnOiBsZWdlbmRJZCxcclxuICAgICAgICAgICAgICAgICdjb2xvcic6IF9kYXRhLnNlcmllc1tpXS5jb2xvciB8fCB0aGlzLl9nZXREZWZhdWx0Q29uZmlnKCdjb2xvcicsIGkpLFxyXG4gICAgICAgICAgICAgICAgJ3NoYXBlJzogX2RhdGEuc2VyaWVzW2ldLnNoYXBlIHx8IHRoaXMuX2dldERlZmF1bHRDb25maWcoJ3NoYXBlJywgaSlcclxuICAgICAgICAgICAgfTtcclxuICAgICAgICAgICAgaWYgKHRoaXMuY2hhcnRDYXRlZ29yeSA9PT0gJ2xpbmUnIHx8IHRoaXMuY2hhcnRDYXRlZ29yeSA9PT0gJ3NwbGluZScgfHwgdGhpcy5jaGFydENhdGVnb3J5ID09PSAnYXJlYScgfHwgdGhpcy5jaGFydENhdGVnb3J5ID09PSAnZG90Jykge1xyXG4gICAgICAgICAgICAgICAgbGVnZW5kRGF0YU9ialsnZG90RW5hYmxlZCddID0gKHR5cGVvZiBfZGF0YS5zZXJpZXNbaV0uZG90RW5hYmxlZCAhPT0gJ3VuZGVmaW5lZCcpID8gX2RhdGEuc2VyaWVzW2ldLmRvdEVuYWJsZWQgOiB0cnVlO1xyXG4gICAgICAgICAgICAgICAgbGVnZW5kRGF0YU9ialsnZG90Qm9yZGVyV2lkdGgnXSA9ICh0eXBlb2YgX2RhdGEuc2VyaWVzW2ldLmRvdEJvcmRlcldpZHRoICE9PSAndW5kZWZpbmVkJykgPyBfZGF0YS5zZXJpZXNbaV0uZG90Qm9yZGVyV2lkdGggOiAwO1xyXG4gICAgICAgICAgICAgICAgbGVnZW5kRGF0YU9ialsnZG90Qm9yZGVyQ29sb3InXSA9ICh0eXBlb2YgX2RhdGEuc2VyaWVzW2ldLmRvdEJvcmRlckNvbG9yICE9PSAndW5kZWZpbmVkJykgPyBfZGF0YS5zZXJpZXNbaV0uZG90Qm9yZGVyQ29sb3IgOiAnI0ZGRkZGRic7XHJcbiAgICAgICAgICAgICAgICBpZiAodGhpcy5jaGFydENhdGVnb3J5ICE9PSAnZG90JykgbGVnZW5kRGF0YU9ialsnbGluZVN0eWxlJ10gPSAodHlwZW9mIF9kYXRhLnNlcmllc1tpXS5saW5lU3R5bGUgIT09ICd1bmRlZmluZWQnKSA/IF9kYXRhLnNlcmllc1tpXS5saW5lU3R5bGUgOiAnc29saWQnO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIGxlZ2VuZERhdGFbbGVnZW5kSWRdID0gbGVnZW5kRGF0YU9iajtcclxuICAgICAgICAgICAgbGVnZW5kSWRTZWFyY2hbaV0gPSBsZWdlbmRJZDtcclxuICAgICAgICB9XHJcbiAgICAgICAgdGhpcy5sZWdlbmREYXRhID0gbGVnZW5kRGF0YTtcclxuICAgICAgICByZXR1cm4gbGVnZW5kSWRTZWFyY2g7XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfZGF0YU1hc3NhZ2UoX2RhdGE6IElDaGFydERhdGEpOiB2b2lkIHtcclxuICAgICAgICBsZXQgc2VyaWVzTGVuZ3RoOiBudW1iZXIgPSB0aGlzLl9jaGFydFN2Yy5nZXREM01heE9yTWluKFtfZGF0YS5zZXJpZXMubGVuZ3RoLCB0aGlzLnNlcmllc1RocmVzaG9sZF0sICdtaW4nKTtcclxuICAgICAgICBsZXQgY2hhcnREYXRhT2JqOiBJRDNEYXRhRGF0YSwgY2hhcnREYXRhU2VyaWVzT2JqOiBJRDNZRGF0YTtcclxuICAgICAgICBsZXQgY2hhcnREYXRhOiBJRDNEYXRhID0ge1xyXG4gICAgICAgICAgICAndHlwZSc6IF9kYXRhLmNoYXJ0Wyd0eXBlJ10gPyBfZGF0YS5jaGFydFsndHlwZSddIDogbnVsbCxcclxuICAgICAgICAgICAgJ2xheW91dCc6IF9kYXRhLmNoYXJ0WydsYXlvdXQnXSA/IF9kYXRhLmNoYXJ0WydsYXlvdXQnXSA6IG51bGwsXHJcbiAgICAgICAgICAgICdjb25maWcnOiB0aGlzLmNvbmZpZy5wbG90T3B0aW9ucyAmJiB0aGlzLmNvbmZpZy5wbG90T3B0aW9ucy5oYXNPd25Qcm9wZXJ0eShfZGF0YS5jaGFydFsndHlwZSddKSA/IHRoaXMuY29uZmlnLnBsb3RPcHRpb25zW19kYXRhLmNoYXJ0Wyd0eXBlJ11dIDoge30sXHJcbiAgICAgICAgICAgICdkYXRhJzogW11cclxuICAgICAgICB9O1xyXG4gICAgICAgIGlmICghdGhpcy5jb25maWcuaGFzT3duUHJvcGVydHkoJ2lkJykpIHtcclxuICAgICAgICAgICAgdGhpcy5jb25maWdbJ2lkJ10gPSBfZGF0YS5jaGFydFsndHlwZSddID8gX2RhdGEuY2hhcnRbJ3R5cGUnXSArICctMScgOiAnRGVmYXVsdC0xJztcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIGxldCBjYXRlZ29yaWVzOiBBcnJheTxzdHJpbmc+ID0gdGhpcy5fY2hhcnRTdmMuZ2V0TGltaXRlZENhdGVnb3JpZXMoX2RhdGEueEF4aXMuY2F0ZWdvcmllcywgdGhpcy54VGhyZXNob2xkKTtcclxuXHJcbiAgICAgICAgbGV0IGxlZ2VuZElkU2VhcmNoOiBvYmplY3QgPSB0aGlzLl9nZW5lcmF0ZUxlZ2VuZERhdGEoX2RhdGEsIHNlcmllc0xlbmd0aCk7XHJcblxyXG4gICAgICAgIGxldCB0b3RhbFN1bUFycjogQXJyYXk8bnVtYmVyPiB8IG9iamVjdCA9IHRoaXMuX2dldFRvdGFsU3VtKF9kYXRhLCBzZXJpZXNMZW5ndGgpO1xyXG4gICAgICAgIGxldCBhbGxTdW1BcnJNYXg6IEFycmF5PG51bWJlcj4gPSBbMF07XHJcbiAgICAgICAgbGV0IGFsbFN1bUFyck1pbjogQXJyYXk8bnVtYmVyPiA9IFswXTtcclxuICAgICAgICBsZXQgaGF2ZU5lZ2F0aXZlOiBib29sZWFuID0gZmFsc2U7XHJcblxyXG4gICAgICAgIGZvciAobGV0IGkgPSAwOyBpIDwgY2F0ZWdvcmllcy5sZW5ndGg7IGkrKykge1xyXG4gICAgICAgICAgICBjaGFydERhdGFPYmogPSB7XHJcbiAgICAgICAgICAgICAgICAneCc6IHtcclxuICAgICAgICAgICAgICAgICAgICB2YWx1ZTogaS50b1N0cmluZygpLFxyXG4gICAgICAgICAgICAgICAgICAgIGxhYmVsOiBjYXRlZ29yaWVzW2ldXHJcbiAgICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgICAgJ3knOiBbXSxcclxuICAgICAgICAgICAgICAgIC8vICd6JzogJ1NpbmdhcG9yZSdcclxuICAgICAgICAgICAgfTtcclxuXHJcbiAgICAgICAgICAgIGxldCBzdW1BcnI6IEFycmF5PG51bWJlcj4gPSBbXTtcclxuICAgICAgICAgICAgbGV0IHN1bTogbnVtYmVyID0gMDtcclxuICAgICAgICAgICAgbGV0IHN1bU5lZ2F0aXZlOiBudW1iZXIgPSAwO1xyXG5cclxuICAgICAgICAgICAgbGV0IGZvckxvb3BJbmZvOiBJRm9yTG9vcEluZm8gPSB0aGlzLl9jaGFydFN2Yy5nZXRGb3JMb29wSW5mbyh0aGlzLl9jaGFydFN2Yy5nZXRGb3JMb29wU2VxdWVuY2UodGhpcy5jaGFydFR5cGUpLCBzZXJpZXNMZW5ndGgpO1xyXG5cclxuICAgICAgICAgICAgLy8gZm9yIChsZXQgajogbnVtYmVyID0gMDsgaiA8IHNlcmllc0xlbmd0aDsgaisrKSB7XHJcbiAgICAgICAgICAgIGZvciAobGV0IGo6IG51bWJlciA9IGZvckxvb3BJbmZvLnN0YXJ0OyBmb3JMb29wSW5mby5jaGVjayhqLCBmb3JMb29wSW5mby5lbmQpOyBqID0gZm9yTG9vcEluZm8uaXRlcmF0ZShqKSkge1xyXG4gICAgICAgICAgICAgICAgaWYgKHR5cGVvZiBfZGF0YS5zZXJpZXNbal0uZGF0YVtpXSA9PT0gJ3VuZGVmaW5lZCcpIGNvbnRpbnVlO1xyXG5cclxuICAgICAgICAgICAgICAgIGxldCBjdXJyZW50VmFsOiBudW1iZXIgfCBudWxsID0gX2RhdGEuc2VyaWVzW2pdLmRhdGFbaV0udmFsdWU7XHJcbiAgICAgICAgICAgICAgICBsZXQgY3VyclNpZ246IG51bWJlciA9IE1hdGguc2lnbihjdXJyZW50VmFsKTtcclxuXHJcbiAgICAgICAgICAgICAgICBpZiAodHlwZW9mIGN1cnJlbnRWYWwgPT09ICd1bmRlZmluZWQnKSBjb250aW51ZTtcclxuXHJcbiAgICAgICAgICAgICAgICBpZiAoY3VyclNpZ24gPCAwICYmICFoYXZlTmVnYXRpdmUpIHtcclxuICAgICAgICAgICAgICAgICAgICBoYXZlTmVnYXRpdmUgPSB0cnVlO1xyXG4gICAgICAgICAgICAgICAgICAgIGlmICh0aGlzLmNoYXJ0VHlwZVsxXSA9PT0gJzEwMCcpIGJyZWFrO1xyXG4gICAgICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgICAgIGlmICh0aGlzLmNoYXJ0VHlwZVsxXSAhPT0gJzEwMCcgJiYgdGhpcy5jaGFydFR5cGVbMV0gPT09ICdzdGFjaycpIHtcclxuICAgICAgICAgICAgICAgICAgICBpZiAoY3VyclNpZ24gPj0gMCkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBzdW0gPSAoY3VycmVudFZhbCA9PT0gbnVsbCkgPyBzdW0gOiBzdW0gKyBjdXJyZW50VmFsO1xyXG4gICAgICAgICAgICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHN1bU5lZ2F0aXZlID0gKGN1cnJlbnRWYWwgPT09IG51bGwpID8gc3VtTmVnYXRpdmUgOiBzdW1OZWdhdGl2ZSArIGN1cnJlbnRWYWw7XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgfSBlbHNlIGlmICh0aGlzLmNoYXJ0VHlwZVsxXSA9PT0gJzEwMCcpIHtcclxuICAgICAgICAgICAgICAgICAgICBpZiAoY3VycmVudFZhbCAhPT0gbnVsbCAmJiB0b3RhbFN1bUFycltpXSAhPT0gMCkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBjdXJyZW50VmFsID0gY3VycmVudFZhbCAvIHRvdGFsU3VtQXJyW2ldICogMTAwO1xyXG4gICAgICAgICAgICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGN1cnJlbnRWYWwgPSAwO1xyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICBzdW0gPSBzdW0gKyBjdXJyZW50VmFsO1xyXG4gICAgICAgICAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgICAgICAgICBpZiAoY3VyclNpZ24gPj0gMCkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBzdW0gPSAoY3VycmVudFZhbCA9PT0gbnVsbCkgPyAwIDogY3VycmVudFZhbDtcclxuICAgICAgICAgICAgICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBzdW1OZWdhdGl2ZSA9IChjdXJyZW50VmFsID09PSBudWxsKSA/IDAgOiBjdXJyZW50VmFsO1xyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgICAgICBjaGFydERhdGFTZXJpZXNPYmogPSB7XHJcbiAgICAgICAgICAgICAgICAgICAgJ3N1bSc6IGN1cnJlbnRWYWwgPj0gMCA/IHN1bSA6IHN1bU5lZ2F0aXZlLFxyXG4gICAgICAgICAgICAgICAgICAgICd2YWx1ZSc6IF9kYXRhLnNlcmllc1tqXS5kYXRhW2ldLnZhbHVlLFxyXG4gICAgICAgICAgICAgICAgICAgICdjb2xvcic6IHRoaXMuX2dldENvbmZpZygnY29sb3InLCBqLCBfZGF0YS5zZXJpZXNbal0uZGF0YVtpXSksXHJcbiAgICAgICAgICAgICAgICAgICAgJ3NoYXBlJzogdGhpcy5zaGFwZXNbdGhpcy5fZ2V0Q29uZmlnKCdzaGFwZScsIGosIF9kYXRhLnNlcmllc1tqXS5kYXRhW2ldKV0sXHJcbiAgICAgICAgICAgICAgICAgICAgJ2lkJzogbGVnZW5kSWRTZWFyY2hbal1cclxuICAgICAgICAgICAgICAgIH07XHJcblxyXG4gICAgICAgICAgICAgICAgLy8gdmFsdWUgaXMgdXNlZCB0byBkaXNwbGF5IGRhdGEtbGFiZWwgYW5kIHRvb2x0aXAsIHJlbmRlclZhbCBpcyB0aGUgYWN1dGFsIHBlcmNlbnRhZ2UgdG8gcGFzcyB0byBkMyBmb3IgcmVuZGVyaW5nXHJcbiAgICAgICAgICAgICAgICBpZiAodGhpcy5jaGFydFR5cGVbMV0gPT09ICcxMDAnKSBjaGFydERhdGFTZXJpZXNPYmpbJ3JlbmRlclZhbCddID0gY3VycmVudFZhbDtcclxuXHJcbiAgICAgICAgICAgICAgICBzdW1BcnIucHVzaChNYXRoLnNpZ24oY3VycmVudFZhbCkgPCAwID8gc3VtTmVnYXRpdmUgOiBzdW0pO1xyXG4gICAgICAgICAgICAgICAgY2hhcnREYXRhT2JqLnkucHVzaChjaGFydERhdGFTZXJpZXNPYmopO1xyXG4gICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICBhbGxTdW1BcnJNYXgucHVzaCh0aGlzLl9jaGFydFN2Yy5nZXREM01heE9yTWluKHN1bUFyciwgJ21heCcpKTtcclxuICAgICAgICAgICAgYWxsU3VtQXJyTWluLnB1c2godGhpcy5fY2hhcnRTdmMuZ2V0RDNNYXhPck1pbihzdW1BcnIsICdtaW4nKSk7XHJcblxyXG4gICAgICAgICAgICBjaGFydERhdGEuZGF0YS5wdXNoKGNoYXJ0RGF0YU9iaik7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICBpZiAoX2RhdGEuY2hhcnQudHlwZSAhPT0gJ3BpZScpIHtcclxuICAgICAgICAgICAgY2hhcnREYXRhWydyYW5nZSddID0ge1xyXG4gICAgICAgICAgICAgICAgbWF4OiB0aGlzLl9jaGFydFN2Yy5nZXREM01heE9yTWluKGFsbFN1bUFyck1heCwgJ21heCcpLFxyXG4gICAgICAgICAgICAgICAgbWluOiB0aGlzLl9jaGFydFN2Yy5nZXREM01heE9yTWluKGFsbFN1bUFyck1pbiwgJ21pbicpXHJcbiAgICAgICAgICAgIH07XHJcbiAgICAgICAgICAgIGNoYXJ0RGF0YVsnaGF2ZU5lZ2F0aXZlJ10gPSBoYXZlTmVnYXRpdmU7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICB0aGlzLmRhdGEgPSBjaGFydERhdGE7XHJcbiAgICAgICAgdGhpcy5jaGFydEhpZGUgPSB0aGlzLmNoYXJ0VHlwZVsxXSA9PT0gJzEwMCcgJiYgaGF2ZU5lZ2F0aXZlO1xyXG4gICAgICAgIHRoaXMuX3NldENvbmZpZyh0aGlzLmNvbmZpZyk7XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfZGF0YU1hc3NhZ2VGb3JQaWUoX2RhdGEpIHtcclxuICAgICAgICBpZiAoX2RhdGEgIT09IHVuZGVmaW5lZCAmJiBfZGF0YSAhPT0gbnVsbCkge1xyXG4gICAgICAgICAgICBsZXQgY2hhcnREYXRhOiBJRDNEYXRhID0ge1xyXG4gICAgICAgICAgICAgICAgJ3R5cGUnOiBfZGF0YS5jaGFydFsndHlwZSddID8gX2RhdGEuY2hhcnRbJ3R5cGUnXSA6IG51bGwsXHJcbiAgICAgICAgICAgICAgICAnbGF5b3V0JzogX2RhdGEuY2hhcnRbJ2xheW91dCddID8gX2RhdGEuY2hhcnRbJ2xheW91dCddIDogbnVsbCxcclxuICAgICAgICAgICAgICAgICdjb25maWcnOiB0aGlzLmNvbmZpZy5wbG90T3B0aW9ucyAmJiB0aGlzLmNvbmZpZy5wbG90T3B0aW9ucy5oYXNPd25Qcm9wZXJ0eShfZGF0YS5jaGFydFsndHlwZSddKSA/IHRoaXMuY29uZmlnLnBsb3RPcHRpb25zW19kYXRhLmNoYXJ0Wyd0eXBlJ11dIDoge30sXHJcbiAgICAgICAgICAgICAgICAnZGF0YSc6IFtdXHJcbiAgICAgICAgICAgIH07XHJcbiAgICAgICAgICAgIGxldCByZXR1cm5QYXJhbXMgPSB0aGlzLl9jaGFydFN2Yy5zaW5nbGVQaWVEYXRhTWFzc2FnZSh0aGlzLmxlZ2VuZERhdGEsIF9kYXRhLCB0aGlzLmNvbmZpZywgdGhpcy5zZXJpZXNUaHJlc2hvbGQpO1xyXG4gICAgICAgICAgICBjaGFydERhdGFbJ3BpZWRhdGEnXSA9IHJldHVyblBhcmFtcy5waWVEYXRhO1xyXG4gICAgICAgICAgICB0aGlzLmRhdGEgPSBjaGFydERhdGE7XHJcbiAgICAgICAgICAgIHRoaXMuY29uZmlnWydwaWVDb2xvciddID0gcmV0dXJuUGFyYW1zLnBpZUNvbG9yO1xyXG4gICAgICAgICAgICB0aGlzLmxlZ2VuZERhdGEgPSByZXR1cm5QYXJhbXMubGVnZW5kRGF0YTtcclxuICAgICAgICAgICAgLy8gdGhpcy5vdXRwdXREYXRhLmVtaXQodGhpcy5kYXRhKTtcclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfZGF0YU1hc3NhZ2VGb3JNYXAoX2RhdGEpOiB2b2lkIHtcclxuICAgICAgICB0aGlzLmRhdGEgPSBfZGF0YTtcclxuICAgICAgICB0aGlzLl9zZXRMZWdlbmRGb3JNYXAoKTtcclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF9zZXRMZWdlbmRGb3JNYXAoKTogdm9pZCB7XHJcbiAgICAgICAgbGV0IHNlcmllc0RhdGE6IGFueTtcclxuICAgICAgICBpZiAodGhpcy5kYXRhWydtYXBTZXJpZXNEYXRhJ10gJiYgdGhpcy5jb25maWcuc2tpcE1hc3NhZ2UpIHtcclxuICAgICAgICAgICAgc2VyaWVzRGF0YSA9IEpTT04ucGFyc2UoSlNPTi5zdHJpbmdpZnkodGhpcy5kYXRhWydtYXBTZXJpZXNEYXRhJ10pKTtcclxuICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICBzZXJpZXNEYXRhID0gSlNPTi5wYXJzZShKU09OLnN0cmluZ2lmeSh0aGlzLmRhdGFbJ3NlcmllcyddKSk7XHJcbiAgICAgICAgICAgIGZvciAobGV0IGkgPSAwOyBpIDwgc2VyaWVzRGF0YS5sZW5ndGg7IGkrKykge1xyXG4gICAgICAgICAgICAgICAgc2VyaWVzRGF0YVtpXVsnZGVhY3RpdmUnXSA9IGZhbHNlO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgICAgIHRoaXMuY2hlY2tNYXBTY2FsZSA9IGZhbHNlO1xyXG4gICAgICAgIGlmICghdGhpcy5jb25maWcuc2tpcE1hc3NhZ2UpIHtcclxuICAgICAgICAgICAgaWYgKHRoaXMuY29uZmlnLmNvbG9yQXhpcyAhPSB1bmRlZmluZWQpIHtcclxuICAgICAgICAgICAgICAgIGlmICh0aGlzLmNvbmZpZy5jb2xvckF4aXMuZGF0YUNsYXNzZXMgJiYgdGhpcy5jb25maWcuY29sb3JBeGlzLmRhdGFDbGFzc2VzLmxlbmd0aCAhPSAwKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5sZWdlbmREYXRhID0gdGhpcy5fY2hhcnRTdmMuc2V0U2luZ2xlTGVnZW5kTGV2ZWxzKHRoaXMuY29uZmlnLmNvbG9yQXhpcy5kYXRhQ2xhc3NlcywgdGhpcy5jb25maWcubGVnZW5kLnZhbHVlRGVjaW1hbHMsIHRoaXMuY29uZmlnLmxlZ2VuZC52YWx1ZVN1ZmZpeCk7XHJcbiAgICAgICAgICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuY2hlY2tNYXBTY2FsZSA9IHRydWU7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLmxlZ2VuZERhdGEgPSB0aGlzLl9jaGFydFN2Yy5zZXRNYXBMZWdlbmREYXRhKHRoaXMubGVnZW5kRGF0YSwgc2VyaWVzRGF0YSwgdGhpcy5jb25maWcpO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgLy8gb3V0cHV0IGxlZ2VuZCBvbmx5IGZvciBleHBvcnRpbmdcclxuICAgICAgICAgICAgaWYgKHRoaXMuY29uZmlnLmNvbG9yQXhpcyAhPSB1bmRlZmluZWQpIHtcclxuICAgICAgICAgICAgICAgIGlmICh0aGlzLmNvbmZpZy5jb2xvckF4aXMuZGF0YUNsYXNzZXMgJiYgdGhpcy5jb25maWcuY29sb3JBeGlzLmRhdGFDbGFzc2VzLmxlbmd0aCAhPSAwKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5sZWdlbmREYXRhID0gdGhpcy5fY2hhcnRTdmMuc2V0TWFwTGVnZW5kRGF0YSh0aGlzLmxlZ2VuZERhdGEsIHNlcmllc0RhdGEsIHRoaXMuY29uZmlnKTtcclxuICAgICAgICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5jaGVja01hcFNjYWxlID0gdHJ1ZTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgICAgIHRoaXMubGVnZW5kRGF0YSA9IHRoaXMuX2NoYXJ0U3ZjLnNldE1hcExlZ2VuZERhdGEodGhpcy5sZWdlbmREYXRhLCBzZXJpZXNEYXRhLCB0aGlzLmNvbmZpZyk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfZ2V0VG90YWxTdW0oX2RhdGE6IElDaGFydERhdGEsIHNlcmllc0xlbmd0aDogbnVtYmVyKTogQXJyYXk8bnVtYmVyPiB8IG9iamVjdCB7XHJcbiAgICAgICAgaWYgKHRoaXMuY2hhcnRUeXBlWzFdID09PSAnMTAwJykge1xyXG4gICAgICAgICAgICByZXR1cm4gdGhpcy5fY2hhcnRTdmMuZ2V0VG90YWxTdW1BcnJGcm9tU2VyaWVzKF9kYXRhLnNlcmllcywgX2RhdGEueEF4aXMuY2F0ZWdvcmllcywgc2VyaWVzTGVuZ3RoKTtcclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfZ2V0Q29uZmlnKF9lbGVtZW50OiBhbnksIF9zZXJpZXNJbmRleDogbnVtYmVyLCBfZGF0YTogSVNlcmllc0RhdGEpOiBzdHJpbmcge1xyXG5cclxuICAgICAgICBpZiAoIXRoaXMuX2NoYXJ0U3ZjLmlzRXhpc3QoX2RhdGEpKSByZXR1cm47XHJcblxyXG4gICAgICAgIGlmIChfZGF0YS5oYXNPd25Qcm9wZXJ0eShfZWxlbWVudCkgJiYgX2RhdGFbX2VsZW1lbnRdICE9PSB1bmRlZmluZWQpIHtcclxuICAgICAgICAgICAgcmV0dXJuIF9kYXRhW19lbGVtZW50XTtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIGxldCBjb25maWc6IHN0cmluZyA9IHRoaXMuX2dldExlZ2VuZENvbmZpZyhfZWxlbWVudCwgX3Nlcmllc0luZGV4KTtcclxuICAgICAgICByZXR1cm4gY29uZmlnO1xyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX2dldExlZ2VuZENvbmZpZyhfZWxlbWVudDogYW55LCBfc2VyaWVzSW5kZXg6IG51bWJlcik6IHN0cmluZyB7XHJcbiAgICAgICAgaWYgKF9lbGVtZW50ID09PSAnc2hhcGUnICYmXHJcbiAgICAgICAgICAgICh0aGlzLmNoYXJ0RGF0YS5jaGFydC50eXBlID09PSAncGllJyB8fCB0aGlzLmNoYXJ0RGF0YS5jaGFydC50eXBlID09PSAnYmFyJykpIHtcclxuICAgICAgICAgICAgcmV0dXJuICdjaXJjbGUnO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgbGV0IGRlZmF1bHRDb25maWc6IHN0cmluZyA9IHRoaXMuX2dldERlZmF1bHRDb25maWcoX2VsZW1lbnQsIF9zZXJpZXNJbmRleCk7XHJcbiAgICAgICAgbGV0IGNvbmZpZzogc3RyaW5nO1xyXG4gICAgICAgIGlmICh0aGlzLmNoYXJ0Q2F0ZWdvcnkgPT0gJ3BpZScpIHtcclxuICAgICAgICAgICAgY29uZmlnID0gZGVmYXVsdENvbmZpZztcclxuICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICBjb25maWcgPSB0aGlzLmNoYXJ0RGF0YS5zZXJpZXNbX3Nlcmllc0luZGV4XVtfZWxlbWVudF0gfHwgZGVmYXVsdENvbmZpZztcclxuICAgICAgICB9XHJcbiAgICAgICAgcmV0dXJuIGNvbmZpZztcclxuICAgIH1cclxuXHJcbiAgICBwdWJsaWMgX2dldERlZmF1bHRDb25maWcoX2VsZW1lbnQ6IGFueSwgX3Nlcmllc0luZGV4PzogbnVtYmVyKTogc3RyaW5nIHtcclxuICAgICAgICBpZiAoX2VsZW1lbnQgPT09ICdzaGFwZScpIHJldHVybiAnY2lyY2xlJztcclxuXHJcbiAgICAgICAgaWYgKF9zZXJpZXNJbmRleCB8fCBfc2VyaWVzSW5kZXggPT09IDApIHtcclxuICAgICAgICAgICAgcmV0dXJuIHRoaXMuY29uZmlnLmNvbG9yc1tfc2VyaWVzSW5kZXhdO1xyXG4gICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgIHRoaXMuX2NvbG9yTGlzdFBvc2l0aW9uKys7XHJcbiAgICAgICAgICAgIHJldHVybiB0aGlzLmNvbmZpZy5jb2xvcnNbdGhpcy5fY29sb3JMaXN0UG9zaXRpb24gLSAxXTtcclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgcHVibGljIGdldE91dHB1dE1hcmtlcihfZGF0YTogYW55KTogdm9pZCB7XHJcbiAgICAgICAgdGhpcy5tYXJrZXJzTGVnZW5kID0gX2RhdGE7XHJcbiAgICB9XHJcbn1cclxuIl19