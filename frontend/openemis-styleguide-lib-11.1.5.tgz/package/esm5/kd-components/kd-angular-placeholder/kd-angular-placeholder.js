import { __decorate, __metadata } from "tslib";
import { Component, ViewEncapsulation, HostBinding, Input } from '@angular/core';
// import { Http, Response } from '@angular/http';
import { HttpErrorResponse, HttpClient, HttpResponse } from '@angular/common/http';
import { map } from 'rxjs/operators';
import { KdModalEvent } from '../kd-angular-modal/kd-modal-event';
var KdPlaceholder = /** @class */ (function () {
    function KdPlaceholder(_http, _modalEvent) {
        this._http = _http;
        this._modalEvent = _modalEvent;
        this.imageSrc = '';
        this.modalConfig = {
            title: '',
            button: [],
            id: ''
        };
        this.fontSize = 80;
        this.placeholder = 'placeholder-wrapper';
    }
    KdPlaceholder.prototype.ngOnInit = function () {
        // console.log('-- KdPlaceholder OnInit --');
        this._processImageConfig();
        if (typeof this.src !== 'undefined') {
            this.imageSrc = this.src;
        }
        if (typeof this.value !== 'undefined' && (typeof this.src === 'undefined' || this.src === '')) {
            this._processImageValue();
        }
    };
    KdPlaceholder.prototype.ngOnChanges = function (_simpleChanges) {
        // console.log('-- KdPlaceholder OnChanges -- ', _simpleChanges);
        if (_simpleChanges.hasOwnProperty('config') && !_simpleChanges['config'].firstChange) {
            this._processImageConfig();
        }
        if (_simpleChanges.hasOwnProperty('src') && !_simpleChanges['src'].firstChange) {
            this.imageSrc = this.src;
        }
        if (_simpleChanges.hasOwnProperty('value') && !_simpleChanges['value'].firstChange) {
            this._processImageValue();
        }
    };
    KdPlaceholder.prototype.ngOnDestroy = function () {
        this._unsubscribeHttp();
    };
    KdPlaceholder.prototype.imgClick = function (_event) {
        if (!this.config.isExpandable)
            return;
        this._modalEvent.toggleOpen(this.config.id);
    };
    /******************* Process config ***********************/
    KdPlaceholder.prototype._processImageConfig = function () {
        var defaultConfig = {
            width: 150,
            height: 150,
            icon: 'kd-openemis',
            isExpandable: false,
            borderType: 'box',
            id: Date.now().toString()
        };
        this.config = Object.assign({}, defaultConfig, this.config);
        this.modalConfig.id = this.config.id;
        // Font size checking standardize as width of image / 2 + 5
        this.fontSize = this.config.width / 2 + 5;
    };
    KdPlaceholder.prototype._processImageTitle = function () {
        var modalTitle = (typeof this.value.filename !== 'undefined') ? this.value.filename : '';
        this.modalConfig.title = modalTitle;
    };
    KdPlaceholder.prototype._processImageValue = function () {
        var _this = this;
        this._processImageTitle();
        if (typeof this.value.src !== 'undefined') {
            this.imageSrc = this.value.src;
        }
        else if (typeof this.value.data !== 'undefined' && typeof this.value.extension !== 'undefined') {
            this.imageSrc = this._convertDataExtensionToSrc();
        }
        else if (typeof this.value.link !== 'undefined') {
            this._unsubscribeHttp();
            this._httpSubscription = this._convertLinkToSrc().subscribe(function (_response) {
                _this.imageSrc = _response;
            }, function (_error) {
                console.error('KdPlaceholder error - Error retrieving data for image.', _error);
            });
        }
        else {
            this.imageSrc = '';
        }
    };
    /******************** Convert data ************************/
    KdPlaceholder.prototype._convertDataExtensionToSrc = function () {
        var dataPrefix = 'data:image/' + this.value.extension + ';base64,';
        return dataPrefix + this.value.data;
    };
    KdPlaceholder.prototype._convertLinkToSrc = function () {
        var _this = this;
        return this._http.get(this.value.link.url)
            .pipe(map(function (_response) {
            var response = {};
            try {
                // let tempRes: any = _response.json();
                var imageKey = (typeof _this.value.link.key !== 'undefined') ? _this.value.link.key : 'image';
                if (_response.hasOwnProperty(imageKey)) {
                    response = _response[imageKey];
                }
            }
            catch (err) {
                console.error('KdPlaceholder error - Error in retrieving image src from url. ', err);
            }
            return response;
        }));
    };
    /******************** Convert data ************************/
    KdPlaceholder.prototype._unsubscribeHttp = function () {
        if (typeof this._httpSubscription !== 'undefined') {
            this._httpSubscription.unsubscribe();
        }
    };
    KdPlaceholder.ctorParameters = function () { return [
        { type: HttpClient },
        { type: KdModalEvent }
    ]; };
    __decorate([
        Input(),
        __metadata("design:type", Object)
    ], KdPlaceholder.prototype, "config", void 0);
    __decorate([
        Input(),
        __metadata("design:type", Object)
    ], KdPlaceholder.prototype, "value", void 0);
    __decorate([
        Input(),
        __metadata("design:type", String)
    ], KdPlaceholder.prototype, "src", void 0);
    __decorate([
        HostBinding('class'),
        __metadata("design:type", Object)
    ], KdPlaceholder.prototype, "placeholder", void 0);
    KdPlaceholder = __decorate([
        Component({
            selector: 'kd-placeholder',
            template: "\n        <kd-modal *ngIf='true' [config]='modalConfig'>\n            <img [src]='imageSrc' [style.width]='\"100%\"' [style.height]='\"100%\"'/>\n        </kd-modal>\n        <div\n            [ngClass]='{\"image-border\": (config.borderType == \"box\"), \"image-border-round\": (config.borderType == \"circle\")}'\n            [style.width.px]='config.width'\n            [style.height.px]='config.height'\n        >\n            <img\n                *ngIf='imageSrc'\n                [src]='imageSrc'\n                (click)='imgClick($event)'\n            />\n            <i\n                *ngIf='!imageSrc'\n                [ngClass]='config.icon'\n                [style.fontSize.px]='fontSize'\n            ></i>\n        </div>\n    ",
            encapsulation: ViewEncapsulation.None,
            providers: [KdModalEvent]
        }),
        __metadata("design:paramtypes", [HttpClient,
            KdModalEvent])
    ], KdPlaceholder);
    return KdPlaceholder;
}());
export { KdPlaceholder };
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoia2QtYW5ndWxhci1wbGFjZWhvbGRlci5qcyIsInNvdXJjZVJvb3QiOiJuZzovL29wZW5lbWlzLXN0eWxlZ3VpZGUtbGliLyIsInNvdXJjZXMiOlsia2QtY29tcG9uZW50cy9rZC1hbmd1bGFyLXBsYWNlaG9sZGVyL2tkLWFuZ3VsYXItcGxhY2Vob2xkZXIudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IjtBQUFBLE9BQU8sRUFDSCxTQUFTLEVBS1QsaUJBQWlCLEVBQ2pCLFdBQVcsRUFDWCxLQUFLLEVBQ1IsTUFBTSxlQUFlLENBQUM7QUFDdkIsa0RBQWtEO0FBQ2xELE9BQU8sRUFBRSxpQkFBaUIsRUFBRSxVQUFVLEVBQUUsWUFBWSxFQUFFLE1BQU0sc0JBQXNCLENBQUM7QUFFbkYsT0FBTyxFQUFFLEdBQUcsRUFBRSxNQUFNLGdCQUFnQixDQUFDO0FBQ3JDLE9BQU8sRUFBRSxZQUFZLEVBQUUsTUFBTSxvQ0FBb0MsQ0FBQztBQThCbEU7SUFnQkksdUJBQ1ksS0FBaUIsRUFDakIsV0FBeUI7UUFEekIsVUFBSyxHQUFMLEtBQUssQ0FBWTtRQUNqQixnQkFBVyxHQUFYLFdBQVcsQ0FBYztRQWpCOUIsYUFBUSxHQUFXLEVBQUUsQ0FBQztRQUN0QixnQkFBVyxHQUFvRDtZQUNsRSxLQUFLLEVBQUUsRUFBRTtZQUNULE1BQU0sRUFBRSxFQUFFO1lBQ1YsRUFBRSxFQUFFLEVBQUU7U0FDVCxDQUFDO1FBQ0ssYUFBUSxHQUFXLEVBQUUsQ0FBQztRQU9QLGdCQUFXLEdBQUcscUJBQXFCLENBQUM7SUFLdEQsQ0FBQztJQUdMLGdDQUFRLEdBQVI7UUFDSSw2Q0FBNkM7UUFFN0MsSUFBSSxDQUFDLG1CQUFtQixFQUFFLENBQUM7UUFFM0IsSUFBSSxPQUFPLElBQUksQ0FBQyxHQUFHLEtBQUssV0FBVyxFQUFFO1lBQ2pDLElBQUksQ0FBQyxRQUFRLEdBQUcsSUFBSSxDQUFDLEdBQUcsQ0FBQztTQUM1QjtRQUVELElBQUksT0FBTyxJQUFJLENBQUMsS0FBSyxLQUFLLFdBQVcsSUFBSSxDQUFDLE9BQU8sSUFBSSxDQUFDLEdBQUcsS0FBSyxXQUFXLElBQUksSUFBSSxDQUFDLEdBQUcsS0FBSyxFQUFFLENBQUMsRUFBRTtZQUMzRixJQUFJLENBQUMsa0JBQWtCLEVBQUUsQ0FBQztTQUM3QjtJQUNMLENBQUM7SUFFRCxtQ0FBVyxHQUFYLFVBQVksY0FBNkI7UUFDckMsaUVBQWlFO1FBRWpFLElBQUksY0FBYyxDQUFDLGNBQWMsQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLGNBQWMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxXQUFXLEVBQUU7WUFDbEYsSUFBSSxDQUFDLG1CQUFtQixFQUFFLENBQUM7U0FDOUI7UUFFRCxJQUFJLGNBQWMsQ0FBQyxjQUFjLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxjQUFjLENBQUMsS0FBSyxDQUFDLENBQUMsV0FBVyxFQUFFO1lBQzVFLElBQUksQ0FBQyxRQUFRLEdBQUcsSUFBSSxDQUFDLEdBQUcsQ0FBQztTQUM1QjtRQUVELElBQUksY0FBYyxDQUFDLGNBQWMsQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLGNBQWMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxXQUFXLEVBQUU7WUFDaEYsSUFBSSxDQUFDLGtCQUFrQixFQUFFLENBQUM7U0FDN0I7SUFDTCxDQUFDO0lBRUQsbUNBQVcsR0FBWDtRQUNJLElBQUksQ0FBQyxnQkFBZ0IsRUFBRSxDQUFDO0lBQzVCLENBQUM7SUFFTSxnQ0FBUSxHQUFmLFVBQWdCLE1BQWE7UUFDekIsSUFBSSxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsWUFBWTtZQUFFLE9BQU87UUFFdEMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxVQUFVLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxFQUFFLENBQUMsQ0FBQztJQUNoRCxDQUFDO0lBRUQsNERBQTREO0lBQ3BELDJDQUFtQixHQUEzQjtRQUNJLElBQUksYUFBYSxHQUF1QjtZQUNwQyxLQUFLLEVBQUUsR0FBRztZQUNWLE1BQU0sRUFBRSxHQUFHO1lBQ1gsSUFBSSxFQUFFLGFBQWE7WUFDbkIsWUFBWSxFQUFFLEtBQUs7WUFDbkIsVUFBVSxFQUFFLEtBQUs7WUFDakIsRUFBRSxFQUFFLElBQUksQ0FBQyxHQUFHLEVBQUUsQ0FBQyxRQUFRLEVBQUU7U0FDNUIsQ0FBQztRQUVGLElBQUksQ0FBQyxNQUFNLEdBQUcsTUFBTSxDQUFDLE1BQU0sQ0FBQyxFQUFFLEVBQUUsYUFBYSxFQUFFLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQztRQUM1RCxJQUFJLENBQUMsV0FBVyxDQUFDLEVBQUUsR0FBRyxJQUFJLENBQUMsTUFBTSxDQUFDLEVBQUUsQ0FBQztRQUNyQywyREFBMkQ7UUFDM0QsSUFBSSxDQUFDLFFBQVEsR0FBRyxJQUFJLENBQUMsTUFBTSxDQUFDLEtBQUssR0FBRyxDQUFDLEdBQUcsQ0FBQyxDQUFDO0lBQzlDLENBQUM7SUFFTywwQ0FBa0IsR0FBMUI7UUFDSSxJQUFJLFVBQVUsR0FBVyxDQUFDLE9BQU8sSUFBSSxDQUFDLEtBQUssQ0FBQyxRQUFRLEtBQUssV0FBVyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUM7UUFDakcsSUFBSSxDQUFDLFdBQVcsQ0FBQyxLQUFLLEdBQUcsVUFBVSxDQUFDO0lBQ3hDLENBQUM7SUFFTywwQ0FBa0IsR0FBMUI7UUFBQSxpQkF5QkM7UUF4QkcsSUFBSSxDQUFDLGtCQUFrQixFQUFFLENBQUM7UUFFMUIsSUFBSSxPQUFPLElBQUksQ0FBQyxLQUFLLENBQUMsR0FBRyxLQUFLLFdBQVcsRUFBRTtZQUN2QyxJQUFJLENBQUMsUUFBUSxHQUFHLElBQUksQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDO1NBQ2xDO2FBQ0ksSUFBSSxPQUFPLElBQUksQ0FBQyxLQUFLLENBQUMsSUFBSSxLQUFLLFdBQVcsSUFBSSxPQUFPLElBQUksQ0FBQyxLQUFLLENBQUMsU0FBUyxLQUFLLFdBQVcsRUFBRTtZQUM1RixJQUFJLENBQUMsUUFBUSxHQUFHLElBQUksQ0FBQywwQkFBMEIsRUFBRSxDQUFDO1NBQ3JEO2FBQ0ksSUFBSSxPQUFPLElBQUksQ0FBQyxLQUFLLENBQUMsSUFBSSxLQUFLLFdBQVcsRUFBRTtZQUM3QyxJQUFJLENBQUMsZ0JBQWdCLEVBQUUsQ0FBQztZQUV4QixJQUFJLENBQUMsaUJBQWlCLEdBQUcsSUFBSSxDQUFDLGlCQUFpQixFQUFFLENBQUMsU0FBUyxDQUN2RCxVQUFDLFNBQWM7Z0JBQ1gsS0FBSSxDQUFDLFFBQVEsR0FBRyxTQUFTLENBQUM7WUFDOUIsQ0FBQyxFQUNELFVBQUMsTUFBeUI7Z0JBQ3RCLE9BQU8sQ0FBQyxLQUFLLENBQUMsd0RBQXdELEVBQUUsTUFBTSxDQUFDLENBQUM7WUFDcEYsQ0FBQyxDQUNKLENBQUM7U0FDTDthQUNJO1lBQ0QsSUFBSSxDQUFDLFFBQVEsR0FBRyxFQUFFLENBQUM7U0FDdEI7SUFFTCxDQUFDO0lBRUQsNERBQTREO0lBQ3BELGtEQUEwQixHQUFsQztRQUNJLElBQUksVUFBVSxHQUFXLGFBQWEsR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDLFNBQVMsR0FBRyxVQUFVLENBQUM7UUFDM0UsT0FBTyxVQUFVLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUM7SUFDeEMsQ0FBQztJQUVPLHlDQUFpQixHQUF6QjtRQUFBLGlCQW1CQztRQWxCRyxPQUFPLElBQUksQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQzthQUNyQyxJQUFJLENBQ0QsR0FBRyxDQUFDLFVBQUMsU0FBNEI7WUFDN0IsSUFBSSxRQUFRLEdBQVEsRUFBRSxDQUFDO1lBRXZCLElBQUk7Z0JBQ0EsdUNBQXVDO2dCQUN2QyxJQUFJLFFBQVEsR0FBVyxDQUFDLE9BQU8sS0FBSSxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsR0FBRyxLQUFLLFdBQVcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFJLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQztnQkFDcEcsSUFBSSxTQUFTLENBQUMsY0FBYyxDQUFDLFFBQVEsQ0FBQyxFQUFFO29CQUNwQyxRQUFRLEdBQUcsU0FBUyxDQUFDLFFBQVEsQ0FBQyxDQUFDO2lCQUNsQzthQUNKO1lBQUMsT0FBTyxHQUFHLEVBQUU7Z0JBQ1YsT0FBTyxDQUFDLEtBQUssQ0FBQyxnRUFBZ0UsRUFBRSxHQUFHLENBQUMsQ0FBQzthQUN4RjtZQUVELE9BQU8sUUFBUSxDQUFDO1FBQ3BCLENBQUMsQ0FBQyxDQUNMLENBQUM7SUFDVixDQUFDO0lBRUQsNERBQTREO0lBQ3BELHdDQUFnQixHQUF4QjtRQUNJLElBQUksT0FBTyxJQUFJLENBQUMsaUJBQWlCLEtBQUssV0FBVyxFQUFFO1lBQy9DLElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxXQUFXLEVBQUUsQ0FBQztTQUN4QztJQUNMLENBQUM7O2dCQTlIa0IsVUFBVTtnQkFDSixZQUFZOztJQVA1QjtRQUFSLEtBQUssRUFBRTs7aURBQTRCO0lBQzNCO1FBQVIsS0FBSyxFQUFFOztnREFBMEI7SUFDekI7UUFBUixLQUFLLEVBQUU7OzhDQUFhO0lBQ0M7UUFBckIsV0FBVyxDQUFDLE9BQU8sQ0FBQzs7c0RBQXFDO0lBZGpELGFBQWE7UUEzQnpCLFNBQVMsQ0FBQztZQUNQLFFBQVEsRUFBRSxnQkFBZ0I7WUFDMUIsUUFBUSxFQUFFLDB1QkFvQlQ7WUFDRCxhQUFhLEVBQUUsaUJBQWlCLENBQUMsSUFBSTtZQUNyQyxTQUFTLEVBQUUsQ0FBQyxZQUFZLENBQUM7U0FDNUIsQ0FBQzt5Q0FtQnFCLFVBQVU7WUFDSixZQUFZO09BbEI1QixhQUFhLENBZ0p6QjtJQUFELG9CQUFDO0NBQUEsQUFoSkQsSUFnSkM7U0FoSlksYUFBYSIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7XHJcbiAgICBDb21wb25lbnQsXHJcbiAgICBPbkluaXQsXHJcbiAgICBPbkNoYW5nZXMsXHJcbiAgICBPbkRlc3Ryb3ksXHJcbiAgICBTaW1wbGVDaGFuZ2VzLFxyXG4gICAgVmlld0VuY2Fwc3VsYXRpb24sXHJcbiAgICBIb3N0QmluZGluZyxcclxuICAgIElucHV0XHJcbn0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XHJcbi8vIGltcG9ydCB7IEh0dHAsIFJlc3BvbnNlIH0gZnJvbSAnQGFuZ3VsYXIvaHR0cCc7XHJcbmltcG9ydCB7IEh0dHBFcnJvclJlc3BvbnNlLCBIdHRwQ2xpZW50LCBIdHRwUmVzcG9uc2UgfSBmcm9tICdAYW5ndWxhci9jb21tb24vaHR0cCc7XHJcbmltcG9ydCB7IE9ic2VydmFibGUgLCAgU3Vic2NyaXB0aW9uIH0gZnJvbSAncnhqcyc7XHJcbmltcG9ydCB7IG1hcCB9IGZyb20gJ3J4anMvb3BlcmF0b3JzJztcclxuaW1wb3J0IHsgS2RNb2RhbEV2ZW50IH0gZnJvbSAnLi4va2QtYW5ndWxhci1tb2RhbC9rZC1tb2RhbC1ldmVudCc7XHJcbmltcG9ydCB7SVBsYWNlaG9sZGVyQ29uZmlnLCBJUGxhY2Vob2xkZXJMaW5rLCBJUGxhY2Vob2xkZXJWYWx1ZSB9IGZyb20gJy4va2QtYW5ndWxhci1wbGFjZWhvbGRlci1pbnRlcmZhY2UnO1xyXG5cclxuQENvbXBvbmVudCh7XHJcbiAgICBzZWxlY3RvcjogJ2tkLXBsYWNlaG9sZGVyJyxcclxuICAgIHRlbXBsYXRlOiBgXHJcbiAgICAgICAgPGtkLW1vZGFsICpuZ0lmPSd0cnVlJyBbY29uZmlnXT0nbW9kYWxDb25maWcnPlxyXG4gICAgICAgICAgICA8aW1nIFtzcmNdPSdpbWFnZVNyYycgW3N0eWxlLndpZHRoXT0nXCIxMDAlXCInIFtzdHlsZS5oZWlnaHRdPSdcIjEwMCVcIicvPlxyXG4gICAgICAgIDwva2QtbW9kYWw+XHJcbiAgICAgICAgPGRpdlxyXG4gICAgICAgICAgICBbbmdDbGFzc109J3tcImltYWdlLWJvcmRlclwiOiAoY29uZmlnLmJvcmRlclR5cGUgPT0gXCJib3hcIiksIFwiaW1hZ2UtYm9yZGVyLXJvdW5kXCI6IChjb25maWcuYm9yZGVyVHlwZSA9PSBcImNpcmNsZVwiKX0nXHJcbiAgICAgICAgICAgIFtzdHlsZS53aWR0aC5weF09J2NvbmZpZy53aWR0aCdcclxuICAgICAgICAgICAgW3N0eWxlLmhlaWdodC5weF09J2NvbmZpZy5oZWlnaHQnXHJcbiAgICAgICAgPlxyXG4gICAgICAgICAgICA8aW1nXHJcbiAgICAgICAgICAgICAgICAqbmdJZj0naW1hZ2VTcmMnXHJcbiAgICAgICAgICAgICAgICBbc3JjXT0naW1hZ2VTcmMnXHJcbiAgICAgICAgICAgICAgICAoY2xpY2spPSdpbWdDbGljaygkZXZlbnQpJ1xyXG4gICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICA8aVxyXG4gICAgICAgICAgICAgICAgKm5nSWY9JyFpbWFnZVNyYydcclxuICAgICAgICAgICAgICAgIFtuZ0NsYXNzXT0nY29uZmlnLmljb24nXHJcbiAgICAgICAgICAgICAgICBbc3R5bGUuZm9udFNpemUucHhdPSdmb250U2l6ZSdcclxuICAgICAgICAgICAgPjwvaT5cclxuICAgICAgICA8L2Rpdj5cclxuICAgIGAsXHJcbiAgICBlbmNhcHN1bGF0aW9uOiBWaWV3RW5jYXBzdWxhdGlvbi5Ob25lLFxyXG4gICAgcHJvdmlkZXJzOiBbS2RNb2RhbEV2ZW50XVxyXG59KVxyXG5cclxuZXhwb3J0IGNsYXNzIEtkUGxhY2Vob2xkZXIgaW1wbGVtZW50cyBPbkluaXQsIE9uQ2hhbmdlcywgT25EZXN0cm95IHtcclxuICAgIHB1YmxpYyBpbWFnZVNyYzogc3RyaW5nID0gJyc7XHJcbiAgICBwdWJsaWMgbW9kYWxDb25maWc6IHt0aXRsZTogc3RyaW5nLCBidXR0b246IEFycmF5PGFueT4sIGlkOiBzdHJpbmd9ID0ge1xyXG4gICAgICAgIHRpdGxlOiAnJyxcclxuICAgICAgICBidXR0b246IFtdLFxyXG4gICAgICAgIGlkOiAnJ1xyXG4gICAgfTtcclxuICAgIHB1YmxpYyBmb250U2l6ZTogbnVtYmVyID0gODA7XHJcblxyXG4gICAgcHJpdmF0ZSBfaHR0cFN1YnNjcmlwdGlvbjogU3Vic2NyaXB0aW9uO1xyXG5cclxuICAgIEBJbnB1dCgpIGNvbmZpZzogSVBsYWNlaG9sZGVyQ29uZmlnO1xyXG4gICAgQElucHV0KCkgdmFsdWU6IElQbGFjZWhvbGRlclZhbHVlO1xyXG4gICAgQElucHV0KCkgc3JjOiBzdHJpbmc7XHJcbiAgICBASG9zdEJpbmRpbmcoJ2NsYXNzJykgcGxhY2Vob2xkZXIgPSAncGxhY2Vob2xkZXItd3JhcHBlcic7XHJcblxyXG4gICAgY29uc3RydWN0b3IoXHJcbiAgICAgICAgcHJpdmF0ZSBfaHR0cDogSHR0cENsaWVudCxcclxuICAgICAgICBwcml2YXRlIF9tb2RhbEV2ZW50OiBLZE1vZGFsRXZlbnRcclxuICAgICkgeyB9XHJcblxyXG5cclxuICAgIG5nT25Jbml0KCk6IHZvaWQge1xyXG4gICAgICAgIC8vIGNvbnNvbGUubG9nKCctLSBLZFBsYWNlaG9sZGVyIE9uSW5pdCAtLScpO1xyXG5cclxuICAgICAgICB0aGlzLl9wcm9jZXNzSW1hZ2VDb25maWcoKTtcclxuXHJcbiAgICAgICAgaWYgKHR5cGVvZiB0aGlzLnNyYyAhPT0gJ3VuZGVmaW5lZCcpIHtcclxuICAgICAgICAgICAgdGhpcy5pbWFnZVNyYyA9IHRoaXMuc3JjO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgaWYgKHR5cGVvZiB0aGlzLnZhbHVlICE9PSAndW5kZWZpbmVkJyAmJiAodHlwZW9mIHRoaXMuc3JjID09PSAndW5kZWZpbmVkJyB8fCB0aGlzLnNyYyA9PT0gJycpKSB7XHJcbiAgICAgICAgICAgIHRoaXMuX3Byb2Nlc3NJbWFnZVZhbHVlKCk7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIG5nT25DaGFuZ2VzKF9zaW1wbGVDaGFuZ2VzOiBTaW1wbGVDaGFuZ2VzKTogdm9pZCB7XHJcbiAgICAgICAgLy8gY29uc29sZS5sb2coJy0tIEtkUGxhY2Vob2xkZXIgT25DaGFuZ2VzIC0tICcsIF9zaW1wbGVDaGFuZ2VzKTtcclxuXHJcbiAgICAgICAgaWYgKF9zaW1wbGVDaGFuZ2VzLmhhc093blByb3BlcnR5KCdjb25maWcnKSAmJiAhX3NpbXBsZUNoYW5nZXNbJ2NvbmZpZyddLmZpcnN0Q2hhbmdlKSB7XHJcbiAgICAgICAgICAgIHRoaXMuX3Byb2Nlc3NJbWFnZUNvbmZpZygpO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgaWYgKF9zaW1wbGVDaGFuZ2VzLmhhc093blByb3BlcnR5KCdzcmMnKSAmJiAhX3NpbXBsZUNoYW5nZXNbJ3NyYyddLmZpcnN0Q2hhbmdlKSB7XHJcbiAgICAgICAgICAgIHRoaXMuaW1hZ2VTcmMgPSB0aGlzLnNyYztcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIGlmIChfc2ltcGxlQ2hhbmdlcy5oYXNPd25Qcm9wZXJ0eSgndmFsdWUnKSAmJiAhX3NpbXBsZUNoYW5nZXNbJ3ZhbHVlJ10uZmlyc3RDaGFuZ2UpIHtcclxuICAgICAgICAgICAgdGhpcy5fcHJvY2Vzc0ltYWdlVmFsdWUoKTtcclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgbmdPbkRlc3Ryb3koKTogdm9pZCB7XHJcbiAgICAgICAgdGhpcy5fdW5zdWJzY3JpYmVIdHRwKCk7XHJcbiAgICB9XHJcblxyXG4gICAgcHVibGljIGltZ0NsaWNrKF9ldmVudDogRXZlbnQpOiB2b2lkIHtcclxuICAgICAgICBpZiAoIXRoaXMuY29uZmlnLmlzRXhwYW5kYWJsZSkgcmV0dXJuO1xyXG5cclxuICAgICAgICB0aGlzLl9tb2RhbEV2ZW50LnRvZ2dsZU9wZW4odGhpcy5jb25maWcuaWQpO1xyXG4gICAgfVxyXG5cclxuICAgIC8qKioqKioqKioqKioqKioqKioqIFByb2Nlc3MgY29uZmlnICoqKioqKioqKioqKioqKioqKioqKioqL1xyXG4gICAgcHJpdmF0ZSBfcHJvY2Vzc0ltYWdlQ29uZmlnKCk6IHZvaWQge1xyXG4gICAgICAgIGxldCBkZWZhdWx0Q29uZmlnOiBJUGxhY2Vob2xkZXJDb25maWcgPSB7XHJcbiAgICAgICAgICAgIHdpZHRoOiAxNTAsXHJcbiAgICAgICAgICAgIGhlaWdodDogMTUwLFxyXG4gICAgICAgICAgICBpY29uOiAna2Qtb3BlbmVtaXMnLFxyXG4gICAgICAgICAgICBpc0V4cGFuZGFibGU6IGZhbHNlLFxyXG4gICAgICAgICAgICBib3JkZXJUeXBlOiAnYm94JyxcclxuICAgICAgICAgICAgaWQ6IERhdGUubm93KCkudG9TdHJpbmcoKVxyXG4gICAgICAgIH07XHJcblxyXG4gICAgICAgIHRoaXMuY29uZmlnID0gT2JqZWN0LmFzc2lnbih7fSwgZGVmYXVsdENvbmZpZywgdGhpcy5jb25maWcpO1xyXG4gICAgICAgIHRoaXMubW9kYWxDb25maWcuaWQgPSB0aGlzLmNvbmZpZy5pZDtcclxuICAgICAgICAvLyBGb250IHNpemUgY2hlY2tpbmcgc3RhbmRhcmRpemUgYXMgd2lkdGggb2YgaW1hZ2UgLyAyICsgNVxyXG4gICAgICAgIHRoaXMuZm9udFNpemUgPSB0aGlzLmNvbmZpZy53aWR0aCAvIDIgKyA1O1xyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX3Byb2Nlc3NJbWFnZVRpdGxlKCk6IHZvaWQge1xyXG4gICAgICAgIGxldCBtb2RhbFRpdGxlOiBzdHJpbmcgPSAodHlwZW9mIHRoaXMudmFsdWUuZmlsZW5hbWUgIT09ICd1bmRlZmluZWQnKSA/IHRoaXMudmFsdWUuZmlsZW5hbWUgOiAnJztcclxuICAgICAgICB0aGlzLm1vZGFsQ29uZmlnLnRpdGxlID0gbW9kYWxUaXRsZTtcclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF9wcm9jZXNzSW1hZ2VWYWx1ZSgpOiB2b2lkIHtcclxuICAgICAgICB0aGlzLl9wcm9jZXNzSW1hZ2VUaXRsZSgpO1xyXG5cclxuICAgICAgICBpZiAodHlwZW9mIHRoaXMudmFsdWUuc3JjICE9PSAndW5kZWZpbmVkJykge1xyXG4gICAgICAgICAgICB0aGlzLmltYWdlU3JjID0gdGhpcy52YWx1ZS5zcmM7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGVsc2UgaWYgKHR5cGVvZiB0aGlzLnZhbHVlLmRhdGEgIT09ICd1bmRlZmluZWQnICYmIHR5cGVvZiB0aGlzLnZhbHVlLmV4dGVuc2lvbiAhPT0gJ3VuZGVmaW5lZCcpIHtcclxuICAgICAgICAgICAgdGhpcy5pbWFnZVNyYyA9IHRoaXMuX2NvbnZlcnREYXRhRXh0ZW5zaW9uVG9TcmMoKTtcclxuICAgICAgICB9XHJcbiAgICAgICAgZWxzZSBpZiAodHlwZW9mIHRoaXMudmFsdWUubGluayAhPT0gJ3VuZGVmaW5lZCcpIHtcclxuICAgICAgICAgICAgdGhpcy5fdW5zdWJzY3JpYmVIdHRwKCk7XHJcblxyXG4gICAgICAgICAgICB0aGlzLl9odHRwU3Vic2NyaXB0aW9uID0gdGhpcy5fY29udmVydExpbmtUb1NyYygpLnN1YnNjcmliZShcclxuICAgICAgICAgICAgICAgIChfcmVzcG9uc2U6IGFueSk6IHZvaWQgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuaW1hZ2VTcmMgPSBfcmVzcG9uc2U7XHJcbiAgICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgICAgKF9lcnJvcjogSHR0cEVycm9yUmVzcG9uc2UpOiB2b2lkID0+IHtcclxuICAgICAgICAgICAgICAgICAgICBjb25zb2xlLmVycm9yKCdLZFBsYWNlaG9sZGVyIGVycm9yIC0gRXJyb3IgcmV0cmlldmluZyBkYXRhIGZvciBpbWFnZS4nLCBfZXJyb3IpO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICApO1xyXG4gICAgICAgIH1cclxuICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgdGhpcy5pbWFnZVNyYyA9ICcnO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICB9XHJcblxyXG4gICAgLyoqKioqKioqKioqKioqKioqKioqIENvbnZlcnQgZGF0YSAqKioqKioqKioqKioqKioqKioqKioqKiovXHJcbiAgICBwcml2YXRlIF9jb252ZXJ0RGF0YUV4dGVuc2lvblRvU3JjKCk6IHN0cmluZyB7XHJcbiAgICAgICAgbGV0IGRhdGFQcmVmaXg6IHN0cmluZyA9ICdkYXRhOmltYWdlLycgKyB0aGlzLnZhbHVlLmV4dGVuc2lvbiArICc7YmFzZTY0LCc7XHJcbiAgICAgICAgcmV0dXJuIGRhdGFQcmVmaXggKyB0aGlzLnZhbHVlLmRhdGE7XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfY29udmVydExpbmtUb1NyYygpOiBPYnNlcnZhYmxlPEh0dHBSZXNwb25zZTxhbnk+PiB7XHJcbiAgICAgICAgcmV0dXJuIHRoaXMuX2h0dHAuZ2V0KHRoaXMudmFsdWUubGluay51cmwpXHJcbiAgICAgICAgICAgIC5waXBlKFxyXG4gICAgICAgICAgICAgICAgbWFwKChfcmVzcG9uc2U6IEh0dHBSZXNwb25zZTxhbnk+KTogYW55ID0+IHtcclxuICAgICAgICAgICAgICAgICAgICBsZXQgcmVzcG9uc2U6IGFueSA9IHt9O1xyXG5cclxuICAgICAgICAgICAgICAgICAgICB0cnkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAvLyBsZXQgdGVtcFJlczogYW55ID0gX3Jlc3BvbnNlLmpzb24oKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgbGV0IGltYWdlS2V5OiBzdHJpbmcgPSAodHlwZW9mIHRoaXMudmFsdWUubGluay5rZXkgIT09ICd1bmRlZmluZWQnKSA/IHRoaXMudmFsdWUubGluay5rZXkgOiAnaW1hZ2UnO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAoX3Jlc3BvbnNlLmhhc093blByb3BlcnR5KGltYWdlS2V5KSkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcmVzcG9uc2UgPSBfcmVzcG9uc2VbaW1hZ2VLZXldO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgfSBjYXRjaCAoZXJyKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbnNvbGUuZXJyb3IoJ0tkUGxhY2Vob2xkZXIgZXJyb3IgLSBFcnJvciBpbiByZXRyaWV2aW5nIGltYWdlIHNyYyBmcm9tIHVybC4gJywgZXJyKTtcclxuICAgICAgICAgICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIHJldHVybiByZXNwb25zZTtcclxuICAgICAgICAgICAgICAgIH0pXHJcbiAgICAgICAgICAgICk7XHJcbiAgICB9XHJcblxyXG4gICAgLyoqKioqKioqKioqKioqKioqKioqIENvbnZlcnQgZGF0YSAqKioqKioqKioqKioqKioqKioqKioqKiovXHJcbiAgICBwcml2YXRlIF91bnN1YnNjcmliZUh0dHAoKTogdm9pZCB7XHJcbiAgICAgICAgaWYgKHR5cGVvZiB0aGlzLl9odHRwU3Vic2NyaXB0aW9uICE9PSAndW5kZWZpbmVkJykge1xyXG4gICAgICAgICAgICB0aGlzLl9odHRwU3Vic2NyaXB0aW9uLnVuc3Vic2NyaWJlKCk7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG59XHJcbiJdfQ==