import { __decorate, __metadata } from "tslib";
import { Component, Input, Output, ViewContainerRef, ElementRef, OnInit, AfterViewInit, EventEmitter, HostListener, Renderer2 } from '@angular/core';
import { timer } from 'rxjs';
import { Router, NavigationEnd } from '@angular/router';
import { KdDomElemSvc } from '../kd-common/index';
var KdFooter = /** @class */ (function () {
    function KdFooter(_vcr, _router, _renderer, _domSvc) {
        this._vcr = _vcr;
        this._router = _router;
        this._renderer = _renderer;
        this._domSvc = _domSvc;
        this._currentYear = new Date().getFullYear();
        this.checkFloat = new EventEmitter();
        this._el = this._vcr.element;
    }
    KdFooter.prototype.onResize = function (event) {
        this.onMobileView();
    };
    KdFooter.prototype.ngOnInit = function () {
        this._float = (typeof this.enableFloat !== 'undefined' && this.enableFloat === 'false') ? false : true;
        this._setVersioning();
    };
    KdFooter.prototype.ngAfterViewInit = function () {
        var _this = this;
        this._router.events.subscribe(function (event) {
            if (event instanceof NavigationEnd) {
                timer(200).subscribe(function () {
                    _this.onMobileView();
                });
            }
        });
    };
    KdFooter.prototype.onMobileView = function () {
        // let windowSize: number = window.innerWidth;
        var contentArea = this._el.nativeElement.previousElementSibling;
        var contentHeight = contentArea.getBoundingClientRect().height;
        var spliterWrapper = document.querySelector('kd-splitter.main');
        // console.log(spliterWrapper);
        if (spliterWrapper === null)
            return false;
        // let contentWrapperHeight = this._el.nativeElement.parentElement.parentElement.getBoundingClientRect().height;
        // let kdPaneHeight = this._el.nativeElement.parentElement.parentElement.parentElement.parentElement.getBoundingClientRect().height;
        var kdPaneHeight = spliterWrapper.querySelector('.pane-2').getBoundingClientRect().height;
        // let wrapperElement = this._el.nativeElement.parentElement.parentElement.parentElement;
        var wrapperElement = spliterWrapper.querySelector('.main-wrapper');
        // let contentWrapperHeight: number = spliterWrapper.querySelector('.content-wrapper').getBoundingClientRect().height;
        // console.log(spliterWrapper.querySelector('.pane-2'));
        // console.log(this._el.nativeElement.parentElement.parentElement.parentElement);
        // console.log('Content Height,' + contentHeight);
        // console.log('contentWrapperHeight,' + contentWrapperHeight);
        // console.log(this._el.nativeElement.parentElement.parentElement);
        if (contentArea !== undefined) {
            if (this._domSvc.isMobile()) {
                if (contentHeight < kdPaneHeight) {
                    this.checkFloat.emit('absolute');
                    this._renderer.setStyle(this._el.nativeElement, 'position', 'absolute');
                    // this._renderer.setElementStyle(wrapperElement, 'height', '100%');
                    // this._renderer.setElementClass(this._el.nativeElement.parentElement.parentElement.parentElement, 'has-footer', true);
                    // this._renderer.setElementStyle(wrapperElement, 'height', '100%');
                    // this._renderer.setElementClass(this._el.nativeElement.parentElement.parentElement.parentElement, 'has-footer', true);
                    this._renderer.addClass(wrapperElement, 'has-footer');
                }
                else {
                    if (this._float) {
                        this.checkFloat.emit('float');
                        this._renderer.setStyle(this._el.nativeElement, 'position', 'relative');
                        // this._renderer.setElementStyle(wrapperElement, 'height', 'auto');
                        // this._renderer.setElementClass(this._el.nativeElement.parentElement.parentElement.parentElement, 'has-footer', false);
                        // this._renderer.setElementStyle(wrapperElement, 'height', 'auto');
                        // this._renderer.setElementClass(this._el.nativeElement.parentElement.parentElement.parentElement, 'has-footer', false);
                        this._renderer.removeClass(wrapperElement, 'has-footer');
                    }
                }
            }
            else {
                this.checkFloat.emit('fixed');
                this._renderer.setStyle(this._el.nativeElement, 'position', 'fixed');
                // this._renderer.setElementClass(this._el.nativeElement.parentElement.parentElement.parentElement, 'has-footer', true);
                // this._renderer.setElementClass(this._el.nativeElement.parentElement.parentElement.parentElement, 'has-footer', true);
                this._renderer.addClass(wrapperElement, 'has-footer');
            }
        }
        return true;
    };
    KdFooter.prototype._setVersioning = function () {
        try {
            // console.log('in try');
            this._latestVersion = app_version;
        }
        catch (err) {
            // console.log(err);
            this._latestVersion = (typeof this.version !== 'undefined') ? this.version : '1.0.0';
        }
    };
    KdFooter.ctorParameters = function () { return [
        { type: ViewContainerRef },
        { type: Router },
        { type: Renderer2 },
        { type: KdDomElemSvc }
    ]; };
    __decorate([
        Input(),
        __metadata("design:type", String)
    ], KdFooter.prototype, "version", void 0);
    __decorate([
        Input(),
        __metadata("design:type", Boolean)
    ], KdFooter.prototype, "enableCustom", void 0);
    __decorate([
        Input(),
        __metadata("design:type", String)
    ], KdFooter.prototype, "customMessage", void 0);
    __decorate([
        Input(),
        __metadata("design:type", String)
    ], KdFooter.prototype, "enableFloat", void 0);
    __decorate([
        Output(),
        __metadata("design:type", Object)
    ], KdFooter.prototype, "checkFloat", void 0);
    __decorate([
        HostListener('window:resize', ['$event']),
        __metadata("design:type", Function),
        __metadata("design:paramtypes", [Object]),
        __metadata("design:returntype", void 0)
    ], KdFooter.prototype, "onResize", null);
    KdFooter = __decorate([
        Component({
            selector: 'kd-footer',
            template: "\n        <footer>\n            <p *ngIf=\"!enableCustom\">Copyright \u00A9 {{_currentYear}} OpenEMIS. All rights reserved. | Version {{_latestVersion}}</p>\n            <p *ngIf=\"enableCustom\">{{customMessage}} | Version {{_latestVersion}}</p>\n        </footer>\n    ",
            providers: [KdDomElemSvc],
            host: { 'class': 'kdx-footer' }
        }),
        __metadata("design:paramtypes", [ViewContainerRef,
            Router,
            Renderer2,
            KdDomElemSvc])
    ], KdFooter);
    return KdFooter;
}());
export { KdFooter };
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoia2QtYW5ndWxhci1mb290ZXIuanMiLCJzb3VyY2VSb290Ijoibmc6Ly9vcGVuZW1pcy1zdHlsZWd1aWRlLWxpYi8iLCJzb3VyY2VzIjpbImtkLWNvbXBvbmVudHMva2QtYW5ndWxhci1mb290ZXIva2QtYW5ndWxhci1mb290ZXIudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IjtBQUFBLE9BQU8sRUFBRSxTQUFTLEVBQUUsS0FBSyxFQUFFLE1BQU0sRUFBRSxnQkFBZ0IsRUFBRSxVQUFVLEVBQUUsTUFBTSxFQUFFLGFBQWEsRUFBRSxZQUFZLEVBQUUsWUFBWSxFQUFFLFNBQVMsRUFBRSxNQUFNLGVBQWUsQ0FBQztBQUNySixPQUFPLEVBQUUsS0FBSyxFQUFFLE1BQU0sTUFBTSxDQUFDO0FBQzdCLE9BQU8sRUFBRSxNQUFNLEVBQUUsYUFBYSxFQUFFLE1BQU0saUJBQWlCLENBQUM7QUFDeEQsT0FBTyxFQUFFLFlBQVksRUFBRSxNQUFNLG9CQUFvQixDQUFDO0FBZ0JsRDtJQWFJLGtCQUNZLElBQXNCLEVBQ3RCLE9BQWUsRUFDZixTQUFvQixFQUNwQixPQUFxQjtRQUhyQixTQUFJLEdBQUosSUFBSSxDQUFrQjtRQUN0QixZQUFPLEdBQVAsT0FBTyxDQUFRO1FBQ2YsY0FBUyxHQUFULFNBQVMsQ0FBVztRQUNwQixZQUFPLEdBQVAsT0FBTyxDQUFjO1FBaEIxQixpQkFBWSxHQUFXLElBQUksSUFBSSxFQUFFLENBQUMsV0FBVyxFQUFFLENBQUM7UUFVN0MsZUFBVSxHQUFHLElBQUksWUFBWSxFQUFFLENBQUM7UUFPdEMsSUFBSSxDQUFDLEdBQUcsR0FBRyxJQUFJLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQztJQUNqQyxDQUFDO0lBR0QsMkJBQVEsR0FBUixVQUFTLEtBQVU7UUFDZixJQUFJLENBQUMsWUFBWSxFQUFFLENBQUM7SUFDeEIsQ0FBQztJQUVELDJCQUFRLEdBQVI7UUFDSSxJQUFJLENBQUMsTUFBTSxHQUFHLENBQUMsT0FBTyxJQUFJLENBQUMsV0FBVyxLQUFLLFdBQVcsSUFBSSxJQUFJLENBQUMsV0FBVyxLQUFLLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQztRQUN2RyxJQUFJLENBQUMsY0FBYyxFQUFFLENBQUM7SUFDMUIsQ0FBQztJQUVELGtDQUFlLEdBQWY7UUFBQSxpQkFRQztRQVBHLElBQUksQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLFNBQVMsQ0FBQyxVQUFBLEtBQUs7WUFDL0IsSUFBSSxLQUFLLFlBQVksYUFBYSxFQUFFO2dCQUNoQyxLQUFLLENBQUMsR0FBRyxDQUFDLENBQUMsU0FBUyxDQUFDO29CQUNqQixLQUFJLENBQUMsWUFBWSxFQUFFLENBQUM7Z0JBQ3hCLENBQUMsQ0FBQyxDQUFDO2FBQ047UUFDTCxDQUFDLENBQUMsQ0FBQztJQUNQLENBQUM7SUFFRCwrQkFBWSxHQUFaO1FBQ0ksOENBQThDO1FBQzlDLElBQUksV0FBVyxHQUFZLElBQUksQ0FBQyxHQUFHLENBQUMsYUFBYSxDQUFDLHNCQUFzQixDQUFDO1FBQ3pFLElBQUksYUFBYSxHQUFXLFdBQVcsQ0FBQyxxQkFBcUIsRUFBRSxDQUFDLE1BQU0sQ0FBQztRQUN2RSxJQUFJLGNBQWMsR0FBWSxRQUFRLENBQUMsYUFBYSxDQUFDLGtCQUFrQixDQUFDLENBQUM7UUFDekUsK0JBQStCO1FBQy9CLElBQUksY0FBYyxLQUFLLElBQUk7WUFBRSxPQUFPLEtBQUssQ0FBQztRQUMxQyxnSEFBZ0g7UUFDaEgsb0lBQW9JO1FBQ3BJLElBQUksWUFBWSxHQUFXLGNBQWMsQ0FBQyxhQUFhLENBQUMsU0FBUyxDQUFDLENBQUMscUJBQXFCLEVBQUUsQ0FBQyxNQUFNLENBQUM7UUFDbEcseUZBQXlGO1FBQ3pGLElBQUksY0FBYyxHQUFZLGNBQWMsQ0FBQyxhQUFhLENBQUMsZUFBZSxDQUFDLENBQUM7UUFDNUUsc0hBQXNIO1FBQ3RILHdEQUF3RDtRQUN4RCxpRkFBaUY7UUFDakYsa0RBQWtEO1FBQ2xELCtEQUErRDtRQUMvRCxtRUFBbUU7UUFDbkUsSUFBSSxXQUFXLEtBQUssU0FBUyxFQUFFO1lBQzNCLElBQUksSUFBSSxDQUFDLE9BQU8sQ0FBQyxRQUFRLEVBQUUsRUFBRTtnQkFDekIsSUFBSSxhQUFhLEdBQUcsWUFBWSxFQUFFO29CQUM5QixJQUFJLENBQUMsVUFBVSxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsQ0FBQztvQkFFakMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxhQUFhLEVBQUUsVUFBVSxFQUFFLFVBQVUsQ0FBQyxDQUFDO29CQUN4RSxvRUFBb0U7b0JBQ3BFLHdIQUF3SDtvQkFDeEgsb0VBQW9FO29CQUN4Rix3SEFBd0g7b0JBQ3hILElBQUksQ0FBQyxTQUFTLENBQUMsUUFBUSxDQUFDLGNBQWMsRUFBRSxZQUFZLENBQUMsQ0FBQztpQkFDckM7cUJBQU07b0JBQ0gsSUFBSSxJQUFJLENBQUMsTUFBTSxFQUFFO3dCQUNiLElBQUksQ0FBQyxVQUFVLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxDQUFDO3dCQUU5QixJQUFJLENBQUMsU0FBUyxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLGFBQWEsRUFBRSxVQUFVLEVBQUUsVUFBVSxDQUFDLENBQUM7d0JBQ3hFLG9FQUFvRTt3QkFDcEUseUhBQXlIO3dCQUN6SCxvRUFBb0U7d0JBQzVGLHlIQUF5SDt3QkFDekgsSUFBSSxDQUFDLFNBQVMsQ0FBQyxXQUFXLENBQUMsY0FBYyxFQUFFLFlBQVksQ0FBQyxDQUFDO3FCQUNwQztpQkFDSjthQUNKO2lCQUFNO2dCQUNILElBQUksQ0FBQyxVQUFVLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxDQUFDO2dCQUU5QixJQUFJLENBQUMsU0FBUyxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLGFBQWEsRUFBRSxVQUFVLEVBQUUsT0FBTyxDQUFDLENBQUM7Z0JBQ3JFLHdIQUF3SDtnQkFDeEgsd0hBQXdIO2dCQUN4SSxJQUFJLENBQUMsU0FBUyxDQUFDLFFBQVEsQ0FBQyxjQUFjLEVBQUUsWUFBWSxDQUFDLENBQUM7YUFFekM7U0FDSjtRQUVELE9BQU8sSUFBSSxDQUFDO0lBQ2hCLENBQUM7SUFFTyxpQ0FBYyxHQUF0QjtRQUNJLElBQUk7WUFDQSx5QkFBeUI7WUFDekIsSUFBSSxDQUFDLGNBQWMsR0FBRyxXQUFXLENBQUM7U0FFckM7UUFBQyxPQUFPLEdBQUcsRUFBRTtZQUNWLG9CQUFvQjtZQUNwQixJQUFJLENBQUMsY0FBYyxHQUFHLENBQUMsT0FBTyxJQUFJLENBQUMsT0FBTyxLQUFLLFdBQVcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUM7U0FDeEY7SUFDTCxDQUFDOztnQkEzRmlCLGdCQUFnQjtnQkFDYixNQUFNO2dCQUNKLFNBQVM7Z0JBQ1gsWUFBWTs7SUFWeEI7UUFBUixLQUFLLEVBQUU7OzZDQUFpQjtJQUNoQjtRQUFSLEtBQUssRUFBRTs7a0RBQXVCO0lBQ3RCO1FBQVIsS0FBSyxFQUFFOzttREFBdUI7SUFDdEI7UUFBUixLQUFLLEVBQUU7O2lEQUFxQjtJQUNuQjtRQUFULE1BQU0sRUFBRTs7Z0RBQWlDO0lBVzFDO1FBREMsWUFBWSxDQUFDLGVBQWUsRUFBRSxDQUFDLFFBQVEsQ0FBQyxDQUFDOzs7OzRDQUd6QztJQXhCUSxRQUFRO1FBWnBCLFNBQVMsQ0FBQztZQUNQLFFBQVEsRUFBRSxXQUFXO1lBQ3JCLFFBQVEsRUFBRSxpUkFLVDtZQUNELFNBQVMsRUFBRSxDQUFDLFlBQVksQ0FBQztZQUN6QixJQUFJLEVBQUcsRUFBRSxPQUFPLEVBQUcsWUFBWSxFQUFFO1NBQ3BDLENBQUM7eUNBZ0JvQixnQkFBZ0I7WUFDYixNQUFNO1lBQ0osU0FBUztZQUNYLFlBQVk7T0FqQnhCLFFBQVEsQ0EwR3BCO0lBQUQsZUFBQztDQUFBLEFBMUdELElBMEdDO1NBMUdZLFFBQVEiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBDb21wb25lbnQsIElucHV0LCBPdXRwdXQsIFZpZXdDb250YWluZXJSZWYsIEVsZW1lbnRSZWYsIE9uSW5pdCwgQWZ0ZXJWaWV3SW5pdCwgRXZlbnRFbWl0dGVyLCBIb3N0TGlzdGVuZXIsIFJlbmRlcmVyMiB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xyXG5pbXBvcnQgeyB0aW1lciB9IGZyb20gJ3J4anMnO1xyXG5pbXBvcnQgeyBSb3V0ZXIsIE5hdmlnYXRpb25FbmQgfSBmcm9tICdAYW5ndWxhci9yb3V0ZXInO1xyXG5pbXBvcnQgeyBLZERvbUVsZW1TdmMgfSBmcm9tICcuLi9rZC1jb21tb24vaW5kZXgnO1xyXG5cclxuZGVjbGFyZSBsZXQgYXBwX3ZlcnNpb246IHN0cmluZztcclxuXHJcbkBDb21wb25lbnQoe1xyXG4gICAgc2VsZWN0b3I6ICdrZC1mb290ZXInLFxyXG4gICAgdGVtcGxhdGU6IGBcclxuICAgICAgICA8Zm9vdGVyPlxyXG4gICAgICAgICAgICA8cCAqbmdJZj1cIiFlbmFibGVDdXN0b21cIj5Db3B5cmlnaHQgwqkge3tfY3VycmVudFllYXJ9fSBPcGVuRU1JUy4gQWxsIHJpZ2h0cyByZXNlcnZlZC4gfCBWZXJzaW9uIHt7X2xhdGVzdFZlcnNpb259fTwvcD5cclxuICAgICAgICAgICAgPHAgKm5nSWY9XCJlbmFibGVDdXN0b21cIj57e2N1c3RvbU1lc3NhZ2V9fSB8IFZlcnNpb24ge3tfbGF0ZXN0VmVyc2lvbn19PC9wPlxyXG4gICAgICAgIDwvZm9vdGVyPlxyXG4gICAgYCxcclxuICAgIHByb3ZpZGVyczogW0tkRG9tRWxlbVN2Y10sXHJcbiAgICBob3N0IDogeyAnY2xhc3MnIDogJ2tkeC1mb290ZXInIH1cclxufSlcclxuXHJcbmV4cG9ydCBjbGFzcyBLZEZvb3RlciBpbXBsZW1lbnRzIE9uSW5pdCwgQWZ0ZXJWaWV3SW5pdCB7XHJcbiAgICBwdWJsaWMgX2N1cnJlbnRZZWFyOiBudW1iZXIgPSBuZXcgRGF0ZSgpLmdldEZ1bGxZZWFyKCk7XHJcbiAgICBwdWJsaWMgX2xhdGVzdFZlcnNpb246IHN0cmluZztcclxuXHJcbiAgICBwcml2YXRlIF9lbDogRWxlbWVudFJlZjtcclxuICAgIHByaXZhdGUgX2Zsb2F0OiBib29sZWFuO1xyXG5cclxuICAgIEBJbnB1dCgpIHZlcnNpb246IHN0cmluZztcclxuICAgIEBJbnB1dCgpIGVuYWJsZUN1c3RvbTogYm9vbGVhbjtcclxuICAgIEBJbnB1dCgpIGN1c3RvbU1lc3NhZ2U6IHN0cmluZztcclxuICAgIEBJbnB1dCgpIGVuYWJsZUZsb2F0OiBzdHJpbmc7XHJcbiAgICBAT3V0cHV0KCkgY2hlY2tGbG9hdCA9IG5ldyBFdmVudEVtaXR0ZXIoKTtcclxuXHJcbiAgICBjb25zdHJ1Y3RvcihcclxuICAgICAgICBwcml2YXRlIF92Y3I6IFZpZXdDb250YWluZXJSZWYsXHJcbiAgICAgICAgcHJpdmF0ZSBfcm91dGVyOiBSb3V0ZXIsXHJcbiAgICAgICAgcHJpdmF0ZSBfcmVuZGVyZXI6IFJlbmRlcmVyMixcclxuICAgICAgICBwcml2YXRlIF9kb21TdmM6IEtkRG9tRWxlbVN2Yykge1xyXG4gICAgICAgIHRoaXMuX2VsID0gdGhpcy5fdmNyLmVsZW1lbnQ7XHJcbiAgICB9XHJcblxyXG4gICAgQEhvc3RMaXN0ZW5lcignd2luZG93OnJlc2l6ZScsIFsnJGV2ZW50J10pXHJcbiAgICBvblJlc2l6ZShldmVudDogYW55KSB7XHJcbiAgICAgICAgdGhpcy5vbk1vYmlsZVZpZXcoKTtcclxuICAgIH1cclxuXHJcbiAgICBuZ09uSW5pdCgpOiB2b2lkIHtcclxuICAgICAgICB0aGlzLl9mbG9hdCA9ICh0eXBlb2YgdGhpcy5lbmFibGVGbG9hdCAhPT0gJ3VuZGVmaW5lZCcgJiYgdGhpcy5lbmFibGVGbG9hdCA9PT0gJ2ZhbHNlJykgPyBmYWxzZSA6IHRydWU7XHJcbiAgICAgICAgdGhpcy5fc2V0VmVyc2lvbmluZygpO1xyXG4gICAgfVxyXG5cclxuICAgIG5nQWZ0ZXJWaWV3SW5pdCgpOiB2b2lkIHtcclxuICAgICAgICB0aGlzLl9yb3V0ZXIuZXZlbnRzLnN1YnNjcmliZShldmVudCA9PiB7XHJcbiAgICAgICAgICAgIGlmIChldmVudCBpbnN0YW5jZW9mIE5hdmlnYXRpb25FbmQpIHtcclxuICAgICAgICAgICAgICAgIHRpbWVyKDIwMCkuc3Vic2NyaWJlKCgpOiB2b2lkID0+IHtcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLm9uTW9iaWxlVmlldygpO1xyXG4gICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9KTtcclxuICAgIH1cclxuXHJcbiAgICBvbk1vYmlsZVZpZXcoKTogYm9vbGVhbiB7XHJcbiAgICAgICAgLy8gbGV0IHdpbmRvd1NpemU6IG51bWJlciA9IHdpbmRvdy5pbm5lcldpZHRoO1xyXG4gICAgICAgIGxldCBjb250ZW50QXJlYTogRWxlbWVudCA9IHRoaXMuX2VsLm5hdGl2ZUVsZW1lbnQucHJldmlvdXNFbGVtZW50U2libGluZztcclxuICAgICAgICBsZXQgY29udGVudEhlaWdodDogbnVtYmVyID0gY29udGVudEFyZWEuZ2V0Qm91bmRpbmdDbGllbnRSZWN0KCkuaGVpZ2h0O1xyXG4gICAgICAgIGxldCBzcGxpdGVyV3JhcHBlcjogRWxlbWVudCA9IGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3IoJ2tkLXNwbGl0dGVyLm1haW4nKTtcclxuICAgICAgICAvLyBjb25zb2xlLmxvZyhzcGxpdGVyV3JhcHBlcik7XHJcbiAgICAgICAgaWYgKHNwbGl0ZXJXcmFwcGVyID09PSBudWxsKSByZXR1cm4gZmFsc2U7XHJcbiAgICAgICAgLy8gbGV0IGNvbnRlbnRXcmFwcGVySGVpZ2h0ID0gdGhpcy5fZWwubmF0aXZlRWxlbWVudC5wYXJlbnRFbGVtZW50LnBhcmVudEVsZW1lbnQuZ2V0Qm91bmRpbmdDbGllbnRSZWN0KCkuaGVpZ2h0O1xyXG4gICAgICAgIC8vIGxldCBrZFBhbmVIZWlnaHQgPSB0aGlzLl9lbC5uYXRpdmVFbGVtZW50LnBhcmVudEVsZW1lbnQucGFyZW50RWxlbWVudC5wYXJlbnRFbGVtZW50LnBhcmVudEVsZW1lbnQuZ2V0Qm91bmRpbmdDbGllbnRSZWN0KCkuaGVpZ2h0O1xyXG4gICAgICAgIGxldCBrZFBhbmVIZWlnaHQ6IG51bWJlciA9IHNwbGl0ZXJXcmFwcGVyLnF1ZXJ5U2VsZWN0b3IoJy5wYW5lLTInKS5nZXRCb3VuZGluZ0NsaWVudFJlY3QoKS5oZWlnaHQ7XHJcbiAgICAgICAgLy8gbGV0IHdyYXBwZXJFbGVtZW50ID0gdGhpcy5fZWwubmF0aXZlRWxlbWVudC5wYXJlbnRFbGVtZW50LnBhcmVudEVsZW1lbnQucGFyZW50RWxlbWVudDtcclxuICAgICAgICBsZXQgd3JhcHBlckVsZW1lbnQ6IEVsZW1lbnQgPSBzcGxpdGVyV3JhcHBlci5xdWVyeVNlbGVjdG9yKCcubWFpbi13cmFwcGVyJyk7XHJcbiAgICAgICAgLy8gbGV0IGNvbnRlbnRXcmFwcGVySGVpZ2h0OiBudW1iZXIgPSBzcGxpdGVyV3JhcHBlci5xdWVyeVNlbGVjdG9yKCcuY29udGVudC13cmFwcGVyJykuZ2V0Qm91bmRpbmdDbGllbnRSZWN0KCkuaGVpZ2h0O1xyXG4gICAgICAgIC8vIGNvbnNvbGUubG9nKHNwbGl0ZXJXcmFwcGVyLnF1ZXJ5U2VsZWN0b3IoJy5wYW5lLTInKSk7XHJcbiAgICAgICAgLy8gY29uc29sZS5sb2codGhpcy5fZWwubmF0aXZlRWxlbWVudC5wYXJlbnRFbGVtZW50LnBhcmVudEVsZW1lbnQucGFyZW50RWxlbWVudCk7XHJcbiAgICAgICAgLy8gY29uc29sZS5sb2coJ0NvbnRlbnQgSGVpZ2h0LCcgKyBjb250ZW50SGVpZ2h0KTtcclxuICAgICAgICAvLyBjb25zb2xlLmxvZygnY29udGVudFdyYXBwZXJIZWlnaHQsJyArIGNvbnRlbnRXcmFwcGVySGVpZ2h0KTtcclxuICAgICAgICAvLyBjb25zb2xlLmxvZyh0aGlzLl9lbC5uYXRpdmVFbGVtZW50LnBhcmVudEVsZW1lbnQucGFyZW50RWxlbWVudCk7XHJcbiAgICAgICAgaWYgKGNvbnRlbnRBcmVhICE9PSB1bmRlZmluZWQpIHtcclxuICAgICAgICAgICAgaWYgKHRoaXMuX2RvbVN2Yy5pc01vYmlsZSgpKSB7XHJcbiAgICAgICAgICAgICAgICBpZiAoY29udGVudEhlaWdodCA8IGtkUGFuZUhlaWdodCkge1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuY2hlY2tGbG9hdC5lbWl0KCdhYnNvbHV0ZScpO1xyXG5cclxuICAgICAgICAgICAgICAgICAgICB0aGlzLl9yZW5kZXJlci5zZXRTdHlsZSh0aGlzLl9lbC5uYXRpdmVFbGVtZW50LCAncG9zaXRpb24nLCAnYWJzb2x1dGUnKTtcclxuICAgICAgICAgICAgICAgICAgICAvLyB0aGlzLl9yZW5kZXJlci5zZXRFbGVtZW50U3R5bGUod3JhcHBlckVsZW1lbnQsICdoZWlnaHQnLCAnMTAwJScpO1xyXG4gICAgICAgICAgICAgICAgICAgIC8vIHRoaXMuX3JlbmRlcmVyLnNldEVsZW1lbnRDbGFzcyh0aGlzLl9lbC5uYXRpdmVFbGVtZW50LnBhcmVudEVsZW1lbnQucGFyZW50RWxlbWVudC5wYXJlbnRFbGVtZW50LCAnaGFzLWZvb3RlcicsIHRydWUpO1xyXG4gICAgICAgICAgICAgICAgICAgIC8vIHRoaXMuX3JlbmRlcmVyLnNldEVsZW1lbnRTdHlsZSh3cmFwcGVyRWxlbWVudCwgJ2hlaWdodCcsICcxMDAlJyk7XHJcbi8vIHRoaXMuX3JlbmRlcmVyLnNldEVsZW1lbnRDbGFzcyh0aGlzLl9lbC5uYXRpdmVFbGVtZW50LnBhcmVudEVsZW1lbnQucGFyZW50RWxlbWVudC5wYXJlbnRFbGVtZW50LCAnaGFzLWZvb3RlcicsIHRydWUpO1xyXG50aGlzLl9yZW5kZXJlci5hZGRDbGFzcyh3cmFwcGVyRWxlbWVudCwgJ2hhcy1mb290ZXInKTtcclxuICAgICAgICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKHRoaXMuX2Zsb2F0KSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuY2hlY2tGbG9hdC5lbWl0KCdmbG9hdCcpO1xyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5fcmVuZGVyZXIuc2V0U3R5bGUodGhpcy5fZWwubmF0aXZlRWxlbWVudCwgJ3Bvc2l0aW9uJywgJ3JlbGF0aXZlJyk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC8vIHRoaXMuX3JlbmRlcmVyLnNldEVsZW1lbnRTdHlsZSh3cmFwcGVyRWxlbWVudCwgJ2hlaWdodCcsICdhdXRvJyk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC8vIHRoaXMuX3JlbmRlcmVyLnNldEVsZW1lbnRDbGFzcyh0aGlzLl9lbC5uYXRpdmVFbGVtZW50LnBhcmVudEVsZW1lbnQucGFyZW50RWxlbWVudC5wYXJlbnRFbGVtZW50LCAnaGFzLWZvb3RlcicsIGZhbHNlKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgLy8gdGhpcy5fcmVuZGVyZXIuc2V0RWxlbWVudFN0eWxlKHdyYXBwZXJFbGVtZW50LCAnaGVpZ2h0JywgJ2F1dG8nKTtcclxuLy8gdGhpcy5fcmVuZGVyZXIuc2V0RWxlbWVudENsYXNzKHRoaXMuX2VsLm5hdGl2ZUVsZW1lbnQucGFyZW50RWxlbWVudC5wYXJlbnRFbGVtZW50LnBhcmVudEVsZW1lbnQsICdoYXMtZm9vdGVyJywgZmFsc2UpO1xyXG50aGlzLl9yZW5kZXJlci5yZW1vdmVDbGFzcyh3cmFwcGVyRWxlbWVudCwgJ2hhcy1mb290ZXInKTtcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLmNoZWNrRmxvYXQuZW1pdCgnZml4ZWQnKTtcclxuXHJcbiAgICAgICAgICAgICAgICB0aGlzLl9yZW5kZXJlci5zZXRTdHlsZSh0aGlzLl9lbC5uYXRpdmVFbGVtZW50LCAncG9zaXRpb24nLCAnZml4ZWQnKTtcclxuICAgICAgICAgICAgICAgIC8vIHRoaXMuX3JlbmRlcmVyLnNldEVsZW1lbnRDbGFzcyh0aGlzLl9lbC5uYXRpdmVFbGVtZW50LnBhcmVudEVsZW1lbnQucGFyZW50RWxlbWVudC5wYXJlbnRFbGVtZW50LCAnaGFzLWZvb3RlcicsIHRydWUpO1xyXG4gICAgICAgICAgICAgICAgLy8gdGhpcy5fcmVuZGVyZXIuc2V0RWxlbWVudENsYXNzKHRoaXMuX2VsLm5hdGl2ZUVsZW1lbnQucGFyZW50RWxlbWVudC5wYXJlbnRFbGVtZW50LnBhcmVudEVsZW1lbnQsICdoYXMtZm9vdGVyJywgdHJ1ZSk7XHJcbnRoaXMuX3JlbmRlcmVyLmFkZENsYXNzKHdyYXBwZXJFbGVtZW50LCAnaGFzLWZvb3RlcicpO1xyXG5cclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgcmV0dXJuIHRydWU7XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfc2V0VmVyc2lvbmluZygpOiB2b2lkIHtcclxuICAgICAgICB0cnkge1xyXG4gICAgICAgICAgICAvLyBjb25zb2xlLmxvZygnaW4gdHJ5Jyk7XHJcbiAgICAgICAgICAgIHRoaXMuX2xhdGVzdFZlcnNpb24gPSBhcHBfdmVyc2lvbjtcclxuXHJcbiAgICAgICAgfSBjYXRjaCAoZXJyKSB7XHJcbiAgICAgICAgICAgIC8vIGNvbnNvbGUubG9nKGVycik7XHJcbiAgICAgICAgICAgIHRoaXMuX2xhdGVzdFZlcnNpb24gPSAodHlwZW9mIHRoaXMudmVyc2lvbiAhPT0gJ3VuZGVmaW5lZCcpID8gdGhpcy52ZXJzaW9uIDogJzEuMC4wJztcclxuICAgICAgICB9XHJcbiAgICB9XHJcbn1cclxuIl19