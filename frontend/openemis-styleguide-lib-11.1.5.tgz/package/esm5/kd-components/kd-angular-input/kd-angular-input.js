import { __decorate, __metadata } from "tslib";
import { Component, Input, Output, EventEmitter, OnInit, AfterViewInit, OnDestroy, ChangeDetectorRef } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { timer } from 'rxjs';
import { KdTableSelectionUpdateEvent, KdTableInputUpdateEvent, KdTableButtonEvent } from '../kd-angular-table/index';
import { KdTableEvent } from '../kd-angular-table/kd-angular-table-event';
import { KdDomElemSvc } from '../kd-common/index';
var KdInput = /** @class */ (function () {
    function KdInput(_domSvc, _cdf, _tableEvent) {
        this._domSvc = _domSvc;
        this._cdf = _cdf;
        this._tableEvent = _tableEvent;
        this._toEmit = false;
        this._subscriptionObj = {};
        this.changeDetectFromQuestion = new EventEmitter();
        this.changeDetectFromGrid = new EventEmitter();
        // @Output() gridCellValueChanged: EventEmitter<{formKey: string, params: KdTableDynamicFormUpdateEvent}> = new EventEmitter();
        // @ViewChild(KdAgGrid) agGridComponent: KdAgGrid;
        this.gridCellValueChanged = new EventEmitter();
        this.gridButtonClicked = new EventEmitter();
    }
    KdInput.prototype.ngOnInit = function () {
        var _this = this;
        this._tooltipPlacement = this._domSvc.getDocumentDirection(true) === 'left' ? 'right' : 'left';
        if (this.question.getProperty('controlType') === 'table') {
            var tableConfigId = this.question.getProperty('config').id;
            var tableApi_1 = this.question.getProperty('api');
            this._subscriptionObj.tableEvents = this._tableEvent.onKdTableEventList(tableConfigId).subscribe(function (_events) {
                if (_events instanceof KdTableSelectionUpdateEvent) {
                    // console.log('>>> KdInput - KdTableSelectionUpdateEvent', _events);
                    // Skip a tick to prevent Expression change error
                    timer().subscribe(function () {
                        _this.valueUpdate(_events.selectedNodes);
                    });
                }
                else if (_events instanceof KdTableInputUpdateEvent) {
                    // console.log('>>> KdInput - KdTableDynamicFormUpdateEvent', _events);
                    // Skip a tick to prevent Expression change error
                    timer().subscribe(function () {
                        _this.valueUpdate(tableApi_1.general.getCurrentRows());
                        /// To only emits the cell event if a input triggers the emit
                        if (typeof _events.question !== 'undefined') {
                            _this.emitCellUpdate(_events);
                        }
                    });
                }
                else if (_events instanceof KdTableButtonEvent) {
                    // console.log('>>> KdInput - KdTableDynamicFormUpdateEvent', _events);
                    timer().subscribe(function () {
                        _this.emitGridButtonClicked(_events);
                    });
                }
            });
        }
    };
    KdInput.prototype.ngAfterViewInit = function () {
        var _this = this;
        // ensure first onchange run do not emit out data
        timer(10).subscribe(function () {
            _this._toEmit = true;
        });
    };
    KdInput.prototype.ngOnDestroy = function () {
        for (var item in this._subscriptionObj) {
            if (typeof this._subscriptionObj[item] !== 'undefined') {
                this._subscriptionObj[item].unsubscribe();
            }
        }
    };
    KdInput.prototype.changeDetect = function () {
        if (this._toEmit)
            this.changeDetectFromQuestion.emit(this.question);
    };
    KdInput.prototype.valueUpdate = function (data) {
        var _this = this;
        if (!this._toEmit) {
            this._cdf.detach();
            this.question.setProperty('value', data);
            this._cdf.detectChanges();
            this._cdf.reattach();
        }
        else {
            timer().subscribe(function () {
                _this.question.setProperty('value', data);
            });
        }
    };
    KdInput.prototype.agCellValueUpdate = function (_cellObject) {
        _cellObject.gridId = this.question.getProperty('key');
        this.changeDetectFromGrid.emit(_cellObject);
    };
    KdInput.prototype.getCheckboxArray = function (event, itemVal) {
        var newObject = Object.assign({}, this.question.getProperty('value'));
        if (newObject.hasOwnProperty(itemVal) && newObject[itemVal]) {
            delete newObject[itemVal];
        }
        else
            newObject[itemVal] = true;
        this.question.setProperty('value', newObject);
        // this.question.value = newObject;
    };
    KdInput.prototype.resetHeight = function () {
        if (this.question.getProperty('controlType') === 'table') {
            var tableApi = this.question.getProperty('api');
            if (typeof tableApi !== 'undefined') {
                tableApi.general.resetRowHeight();
            }
        }
    };
    /************************** Table controlType **************************/
    //// Table controlType
    KdInput.prototype.setTableCellQuestionProperty = function (_formParams) {
        var tableApi = this.question.getProperty('api');
        if (typeof tableApi !== 'undefined') {
            tableApi.dynamicForm.setProperty(_formParams);
        }
    };
    KdInput.prototype.setTableCellData = function (_cellParams) {
        var tableApi = this.question.getProperty('api');
        if (typeof tableApi !== 'undefined') {
            tableApi.general.updateCell(_cellParams);
        }
    };
    KdInput.prototype.emitCellUpdate = function (_params) {
        var emitParams = {
            formKey: this.question.getProperty('key'),
            params: _params
        };
        this.gridCellValueChanged.emit(emitParams);
    };
    KdInput.prototype.emitGridButtonClicked = function (_params) {
        var emitParams = {
            formKey: this.question.getProperty('key'),
            params: _params
        };
        this.gridButtonClicked.emit(emitParams);
    };
    KdInput.ctorParameters = function () { return [
        { type: KdDomElemSvc },
        { type: ChangeDetectorRef },
        { type: KdTableEvent }
    ]; };
    __decorate([
        Input(),
        __metadata("design:type", Object)
    ], KdInput.prototype, "question", void 0);
    __decorate([
        Input(),
        __metadata("design:type", FormGroup)
    ], KdInput.prototype, "form", void 0);
    __decorate([
        Input(),
        __metadata("design:type", Boolean)
    ], KdInput.prototype, "horizontal", void 0);
    __decorate([
        Output(),
        __metadata("design:type", EventEmitter)
    ], KdInput.prototype, "changeDetectFromQuestion", void 0);
    __decorate([
        Output(),
        __metadata("design:type", EventEmitter)
    ], KdInput.prototype, "changeDetectFromGrid", void 0);
    __decorate([
        Output(),
        __metadata("design:type", EventEmitter)
    ], KdInput.prototype, "gridCellValueChanged", void 0);
    __decorate([
        Output(),
        __metadata("design:type", EventEmitter)
    ], KdInput.prototype, "gridButtonClicked", void 0);
    KdInput = __decorate([
        Component({
            selector: 'kd-input',
            template: "<div [formGroup]=\"form\">\r\n    <!-- <div *ngIf=\"question.visible\" [ngSwitch]=\"question.controlType\" class=\"input string control-group\" [class.required]=\"question.required\"> -->\r\n    <div *ngIf=\"question.visible\" [ngSwitch]=\"question.controlType\" class=\"input control-group\" [class.required]=\"question.required\">\r\n    <!-- <div *ngIf=\"question.visible\" [ngSwitch]=\"question.controlType\" class=\"input form-group\" [class.required]=\"question.required\"> -->\r\n            <label [attr.for]=\"question.key\" class=\"form-label\" *ngIf=\"question.controlType!='hidden' && question.controlType!='section' && !horizontal\">{{question.label}}</label>\r\n\r\n            <!-- Section Header -->\r\n            <h6 *ngSwitchCase=\"'section'\" >{{question.label}}</h6>\r\n\r\n            <!-- Symbol --> \r\n            <div *ngSwitchCase=\"'symbol'\" class=\"form-symbol\">\r\n                <i [ngClass]=\"question.value\"></i>\r\n            </div>\r\n\r\n            <!-- Integer -->\r\n            <input *ngSwitchCase=\"'integer'\" [formControlName]=\"question.key\" [(ngModel)]=\"question.value\" [id]=\"question.key\" type=\"number\" [attr.min]=\"question.min\" [attr.max]=\"question.max\" [attr.disabled]=\"question.disabled ? question.disabled : null\" [attr.readonly]=\"question.readonly ? question.readonly : null\" (ngModelChange)=\"changeDetect()\">\r\n\r\n            <!-- Decimal -->\r\n            <input *ngSwitchCase=\"'decimal'\" [formControlName]=\"question.key\" [(ngModel)]=\"question.value\" [id]=\"question.key\" type=\"number\" [attr.step]=\"question.float\" [attr.max]=\"question.max\" [attr.min]=\"question.min\" [attr.disabled]=\"question.disabled ? question.disabled : null\" [attr.readonly]=\"question.readonly ? question.readonly : null\" (ngModelChange)=\"changeDetect()\">\r\n\r\n            <!-- Password -->\r\n            <input *ngSwitchCase=\"'password'\" [id]=\"question.key\" [value]=\"\" placeholder=\"{{question.password}}\" type=\"password\" [formControlName]=\"question.key\" [attr.disabled]=\"question.disabled ? question.disabled : null\" [attr.readonly]=\"question.readonly ? question.readonly : null\" (ngModelChange)=\"changeDetect()\">\r\n\r\n            <!-- Textarea -->\r\n            <textarea *ngSwitchCase=\"'textarea'\" [id]=\"question.key\" [formControlName]=\"question.key\" [attr.disabled]=\"question.disabled ? question.disabled : null\" [attr.readonly]=\"question.readonly ? question.readonly : null\" [(ngModel)]=\"question.value\" (ngModelChange)=\"changeDetect()\" ></textarea>\r\n\r\n            <!-- Hidden -->\r\n            <input *ngSwitchCase=\"'hidden'\" [id]=\"question.key\" type=\"hidden\" [formControlName]=\"question.key\">\r\n\r\n            <!-- Disabled -->\r\n            <!-- <input *ngSwitchCase=\"'disabled'\" [attr.disabled]=\"question.disabled ? question.disabled : null\" [id]=\"question.key\" [formControlName]=\"question.key\"> -->\r\n\r\n            <!-- Read Only -->\r\n            <!-- <input *ngSwitchCase=\"'readonly'\" [attr.readonly]=\"question.readonly ? question.readonly : null\" [id]=\"question.key\" [formControlName]=\"question.key\"> -->\r\n\r\n            <!-- Dropdown -->\r\n            <div *ngSwitchCase=\"'dropdown'\" class=\"kdx-input-select-wrapper\">\r\n                <select [id]=\"question.key\" tabindex=\"4\" [class.form-error]=\"question.errors\" [formControlName]=\"question.key\" [attr.disabled]=\"(question.disabled || question.readonly)? true : null\" [(ngModel)]=\"question.value\" (ngModelChange)=\"changeDetect()\">\r\n                    <option *ngFor=\"let opt of question.options\" [value]=\"opt.key\">{{opt.value}}</option>\r\n                </select>\r\n            </div>\r\n\r\n            <!-- Radio -->\r\n            <div *ngSwitchCase=\"'radio'\" class=\"input-selection-inline\">\r\n                <input *ngFor=\"let item of question.list\" [kd-checkbox-radio]=\"item.title\" type=\"radio\" [value]=\"item.value\" [formControlName]=\"question.key\" (ngModelChange)=\"changeDetect()\" [checked]=\"question.value == item.value\" [attr.disabled]=\"(question.disabled)? true : null\">\r\n            </div>\r\n\r\n            <!-- Checkbox -->\r\n            <div *ngSwitchCase=\"'checkbox'\" class=\"input-selection-inline\">\r\n                <input *ngFor=\"let item of question.list\" [kd-checkbox-radio]=\"item.title\" type=\"checkbox\" [value]=\"item.value\" (change)=\"getCheckboxArray($event, item.value)\" [checked]=\"question.value[item.value]\" [attr.disabled]=\"(question.disabled)? true : null\">\r\n                <input [id]=\"question.key\" [formControlName]=\"question.key\" [(ngModel)]=\"question.value\" type=\"hidden\" (ngModelChange)=\"changeDetect()\">\r\n            </div>\r\n\r\n            <!-- Text / Autocomplete / Multiselect -->\r\n            <kd-text-input [id]=\"question.key\" *ngSwitchCase=\"'text'\" [config]=\"question\" [value]=\"question.value\" [options]=\"question.options\" [disabled]=\"question.disabled\" [readonly]=\"question.readonly\" [maxLength]=\"question.maxLength\" (updatedValue)=\"valueUpdate($event)\">\r\n                <input [formControlName]=\"question.key\" [(ngModel)]=\"question.value\" type=\"hidden\" (ngModelChange)=\"changeDetect()\">\r\n            </kd-text-input>\r\n\r\n            <!-- Date -->\r\n            <kd-datepicker [id]=\"question.key\" *ngSwitchCase=\"'date'\" [config]=\"question.config\" [inputVal]=\"question.value\" [minDate]=\"question.minDate\" [maxDate]=\"question.maxDate\" (dateConfig)=\"valueUpdate($event)\">\r\n                <input [formControlName]=\"question.key\" [(ngModel)]=\"question.value\" type=\"hidden\" (ngModelChange)=\"changeDetect()\">\r\n            </kd-datepicker>\r\n\r\n            <!-- Time -->\r\n            <kd-timepicker [id]=\"question.key\" *ngSwitchCase=\"'time'\" [config]=\"question.config\" [inputVal]=\"question.value\" (timeConfig)=\"valueUpdate($event)\">\r\n                <input [formControlName]=\"question.key\" [(ngModel)]=\"question.value\" type=\"hidden\" (ngModelChange)=\"changeDetect()\">\r\n            </kd-timepicker>\r\n\r\n            <!-- Tree Dropdown -->\r\n            <div *ngSwitchCase=\"'tree'\" class=\"kdx-input-select-wrapper\">\r\n                <kd-tree-dropdown class=\"kdx-tree-dropdown\" [id]=\"question.key\" [config]=\"question.config\" (eventSelectedNodes)=\"valueUpdate($event)\" [api]=\"question.api\"></kd-tree-dropdown>\r\n                <input [formControlName]=\"question.key\" [(ngModel)]=\"question.value\" type=\"hidden\" (ngModelChange)=\"changeDetect()\">\r\n            </div>\r\n\r\n            <!-- Slider -->\r\n            <kd-slider class=\"kdx-form-slider\" *ngSwitchCase=\"'slider'\" [id]=\"question.key\" [config]=\"question.config\" [value]=\"question.value\" [api]=\"question.api\" (result)=\"valueUpdate($event)\">\r\n                <input [formControlName]=\"question.key\" [(ngModel)]=\"question.value\" type=\"hidden\" (ngModelChange)=\"changeDetect()\">\r\n            </kd-slider>\r\n\r\n            <!-- File Input -->\r\n            <kd-fileinput class=\"kdx-fileinput\" [id]=\"question.key\" *ngSwitchCase=\"'file-input'\" [config]=\"question.config\" [value]=\"question.value\" (result)=\"valueUpdate($event)\">\r\n                <input [formControlName]=\"question.key\" [(ngModel)]=\"question.value\" type=\"hidden\" (ngModelChange)=\"changeDetect()\">\r\n            </kd-fileinput>\r\n         \r\n            <!-- Multiselect Table -->\r\n            <div *ngSwitchCase=\"'multi-table'\" class=\"kdx-input-table-wrapper\">\r\n                <kd-multiselect-table [id]=\"question.key\" [config]=\"question.config\" [masterData]=\"question.masterData\" [slaveData]=\"question.slaveData\" (topBottomData)=\"valueUpdate($event)\"></kd-multiselect-table>\r\n                <input [formControlName]=\"question.key\" [(ngModel)]=\"question.value\" type=\"hidden\" (ngModelChange)=\"changeDetect()\">\r\n            </div>\r\n\r\n            <!-- Table -->\r\n            <div *ngSwitchCase=\"'table'\" class=\"kdx-input-table-wrapper\" [id]=\"question.key\">\r\n                <kd-table [row]=\"question.row\" [column]=\"question.column\" [config]=\"question.config\" [api]=\"question.api\"></kd-table>\r\n                <input [formControlName]=\"question.key\" [(ngModel)]=\"question.value\" type=\"hidden\" (ngModelChange)=\"changeDetect()\">\r\n            </div>\r\n\r\n            <kd-button-group *ngSwitchCase=\"'button-group'\" [name]=\"question.key\" [config]=\"question.config\" [type]=\"question.type\" [data]=\"question.list\" [value]=\"question.value\" [disabled]=\"question.disabled\" (updatedValue)=\"valueUpdate($event)\">\r\n                <input [formControlName]=\"question.key\" [(ngModel)]=\"question.value\" type=\"hidden\" (ngModelChange)=\"changeDetect()\">\r\n            </kd-button-group>\r\n\r\n            <!-- Error Message -->\r\n            <kd-tooltip *ngIf=\"question.errors && question.errors.length > 0\" [config]=\"{ type: 'error', placement: _tooltipPlacement, description: question.errors }\">    \r\n                 <!-- <div *ngIf=\"question.errors\" class=\"error-wrapper\">\r\n                    <div class=\"error-message\" *ngFor=\"let error of question.errors\">\r\n                        {{error.value}}\r\n                    </div>\r\n                </div> -->\r\n            </kd-tooltip>\r\n\r\n<!--             <kd-tooltip  [config]=\"{ type: 'error', placement: 'left', description: 'This is a form error', appendToBody: true}\"></kd-tooltip> -->\r\n    </div>\r\n</div>",
            providers: [KdDomElemSvc, KdTableEvent],
            host: { 'class': 'kdx kdx-input' }
        }),
        __metadata("design:paramtypes", [KdDomElemSvc,
            ChangeDetectorRef,
            KdTableEvent])
    ], KdInput);
    return KdInput;
}());
export { KdInput };
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoia2QtYW5ndWxhci1pbnB1dC5qcyIsInNvdXJjZVJvb3QiOiJuZzovL29wZW5lbWlzLXN0eWxlZ3VpZGUtbGliLyIsInNvdXJjZXMiOlsia2QtY29tcG9uZW50cy9rZC1hbmd1bGFyLWlucHV0L2tkLWFuZ3VsYXItaW5wdXQudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IjtBQUFBLE9BQU8sRUFDSCxTQUFTLEVBQ1QsS0FBSyxFQUNMLE1BQU0sRUFDTixZQUFZLEVBQ1osTUFBTSxFQUNOLGFBQWEsRUFDYixTQUFTLEVBQ1QsaUJBQWlCLEVBQ3BCLE1BQU0sZUFBZSxDQUFDO0FBQ3ZCLE9BQU8sRUFBRSxTQUFTLEVBQUUsTUFBTSxnQkFBZ0IsQ0FBQztBQUMzQyxPQUFPLEVBQUUsS0FBSyxFQUFrQixNQUFNLE1BQU0sQ0FBQztBQUM3QyxPQUFPLEVBQ0gsMkJBQTJCLEVBQzNCLHVCQUF1QixFQUN2QixrQkFBa0IsRUFJckIsTUFBTSwyQkFBMkIsQ0FBQztBQUNuQyxPQUFPLEVBQUUsWUFBWSxFQUFFLE1BQU0sNENBQTRDLENBQUM7QUFDMUUsT0FBTyxFQUFFLFlBQVksRUFBRSxNQUFNLG9CQUFvQixDQUFDO0FBU2xEO0lBa0JJLGlCQUNZLE9BQXFCLEVBQ3JCLElBQXVCLEVBQ3ZCLFdBQXlCO1FBRnpCLFlBQU8sR0FBUCxPQUFPLENBQWM7UUFDckIsU0FBSSxHQUFKLElBQUksQ0FBbUI7UUFDdkIsZ0JBQVcsR0FBWCxXQUFXLENBQWM7UUFuQjdCLFlBQU8sR0FBWSxLQUFLLENBQUM7UUFDekIscUJBQWdCLEdBQWtDLEVBQUUsQ0FBQztRQU1uRCw2QkFBd0IsR0FBc0IsSUFBSSxZQUFZLEVBQUUsQ0FBQztRQUNqRSx5QkFBb0IsR0FBc0IsSUFBSSxZQUFZLEVBQUUsQ0FBQztRQUV2RSwrSEFBK0g7UUFDL0gsa0RBQWtEO1FBRXhDLHlCQUFvQixHQUFxRSxJQUFJLFlBQVksRUFBRSxDQUFDO1FBQzVHLHNCQUFpQixHQUFnRSxJQUFJLFlBQVksRUFBRSxDQUFDO0lBTTFHLENBQUM7SUFFTCwwQkFBUSxHQUFSO1FBQUEsaUJBc0NDO1FBckNHLElBQUksQ0FBQyxpQkFBaUIsR0FBRyxJQUFJLENBQUMsT0FBTyxDQUFDLG9CQUFvQixDQUFDLElBQUksQ0FBQyxLQUFLLE1BQU0sQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUM7UUFDL0YsSUFBSSxJQUFJLENBQUMsUUFBUSxDQUFDLFdBQVcsQ0FBQyxhQUFhLENBQUMsS0FBSyxPQUFPLEVBQUU7WUFDdEQsSUFBSSxhQUFhLEdBQVcsSUFBSSxDQUFDLFFBQVEsQ0FBQyxXQUFXLENBQUMsUUFBUSxDQUFDLENBQUMsRUFBRSxDQUFDO1lBQ25FLElBQUksVUFBUSxHQUFjLElBQUksQ0FBQyxRQUFRLENBQUMsV0FBVyxDQUFDLEtBQUssQ0FBQyxDQUFDO1lBRTNELElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxXQUFXLEdBQUcsSUFBSSxDQUFDLFdBQVcsQ0FBQyxrQkFBa0IsQ0FBQyxhQUFhLENBQUMsQ0FBQyxTQUFTLENBQUMsVUFBQyxPQUFZO2dCQUMxRyxJQUFJLE9BQU8sWUFBWSwyQkFBMkIsRUFBRTtvQkFDaEQscUVBQXFFO29CQUVyRSxpREFBaUQ7b0JBQ2pELEtBQUssRUFBRSxDQUFDLFNBQVMsQ0FBQzt3QkFDZCxLQUFJLENBQUMsV0FBVyxDQUFDLE9BQU8sQ0FBQyxhQUFhLENBQUMsQ0FBQztvQkFDNUMsQ0FBQyxDQUFDLENBQUM7aUJBQ047cUJBRUksSUFBSSxPQUFPLFlBQVksdUJBQXVCLEVBQUU7b0JBQ2pELHVFQUF1RTtvQkFFdkUsaURBQWlEO29CQUNqRCxLQUFLLEVBQUUsQ0FBQyxTQUFTLENBQUM7d0JBQ2QsS0FBSSxDQUFDLFdBQVcsQ0FBQyxVQUFRLENBQUMsT0FBTyxDQUFDLGNBQWMsRUFBRSxDQUFDLENBQUM7d0JBRXBELDZEQUE2RDt3QkFDN0QsSUFBSSxPQUFPLE9BQU8sQ0FBQyxRQUFRLEtBQUssV0FBVyxFQUFFOzRCQUN6QyxLQUFJLENBQUMsY0FBYyxDQUFDLE9BQU8sQ0FBQyxDQUFDO3lCQUNoQztvQkFDTCxDQUFDLENBQUMsQ0FBQztpQkFDTjtxQkFFSSxJQUFJLE9BQU8sWUFBWSxrQkFBa0IsRUFBRTtvQkFDNUMsdUVBQXVFO29CQUN2RSxLQUFLLEVBQUUsQ0FBQyxTQUFTLENBQUM7d0JBQ2QsS0FBSSxDQUFDLHFCQUFxQixDQUFDLE9BQU8sQ0FBQyxDQUFDO29CQUN4QyxDQUFDLENBQUMsQ0FBQztpQkFDTjtZQUNMLENBQUMsQ0FBQyxDQUFDO1NBQ047SUFDTCxDQUFDO0lBRUQsaUNBQWUsR0FBZjtRQUFBLGlCQUtDO1FBSkcsaURBQWlEO1FBQ2pELEtBQUssQ0FBQyxFQUFFLENBQUMsQ0FBQyxTQUFTLENBQUM7WUFDaEIsS0FBSSxDQUFDLE9BQU8sR0FBRyxJQUFJLENBQUM7UUFDeEIsQ0FBQyxDQUFDLENBQUM7SUFDUCxDQUFDO0lBRUQsNkJBQVcsR0FBWDtRQUNJLEtBQUssSUFBSSxJQUFJLElBQUksSUFBSSxDQUFDLGdCQUFnQixFQUFFO1lBQ3BDLElBQUksT0FBTyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsSUFBSSxDQUFDLEtBQUssV0FBVyxFQUFFO2dCQUNwRCxJQUFJLENBQUMsZ0JBQWdCLENBQUMsSUFBSSxDQUFDLENBQUMsV0FBVyxFQUFFLENBQUM7YUFDN0M7U0FDSjtJQUNMLENBQUM7SUFFRCw4QkFBWSxHQUFaO1FBQ0ksSUFBSSxJQUFJLENBQUMsT0FBTztZQUFFLElBQUksQ0FBQyx3QkFBd0IsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxDQUFDO0lBQ3hFLENBQUM7SUFFRCw2QkFBVyxHQUFYLFVBQVksSUFBUztRQUFyQixpQkFZQztRQVhHLElBQUksQ0FBQyxJQUFJLENBQUMsT0FBTyxFQUFFO1lBQ2YsSUFBSSxDQUFDLElBQUksQ0FBQyxNQUFNLEVBQUUsQ0FBQztZQUNuQixJQUFJLENBQUMsUUFBUSxDQUFDLFdBQVcsQ0FBQyxPQUFPLEVBQUUsSUFBSSxDQUFDLENBQUM7WUFDekMsSUFBSSxDQUFDLElBQUksQ0FBQyxhQUFhLEVBQUUsQ0FBQztZQUMxQixJQUFJLENBQUMsSUFBSSxDQUFDLFFBQVEsRUFBRSxDQUFDO1NBQ3hCO2FBQ0k7WUFDRCxLQUFLLEVBQUUsQ0FBQyxTQUFTLENBQUM7Z0JBQ2QsS0FBSSxDQUFDLFFBQVEsQ0FBQyxXQUFXLENBQUMsT0FBTyxFQUFFLElBQUksQ0FBQyxDQUFDO1lBQzdDLENBQUMsQ0FBQyxDQUFDO1NBQ047SUFDTCxDQUFDO0lBRUQsbUNBQWlCLEdBQWpCLFVBQWtCLFdBQWdCO1FBQzlCLFdBQVcsQ0FBQyxNQUFNLEdBQUcsSUFBSSxDQUFDLFFBQVEsQ0FBQyxXQUFXLENBQUMsS0FBSyxDQUFDLENBQUM7UUFDdEQsSUFBSSxDQUFDLG9CQUFvQixDQUFDLElBQUksQ0FBQyxXQUFXLENBQUMsQ0FBQztJQUVoRCxDQUFDO0lBRUQsa0NBQWdCLEdBQWhCLFVBQWlCLEtBQVUsRUFBRSxPQUFZO1FBQ3JDLElBQUksU0FBUyxHQUFRLE1BQU0sQ0FBQyxNQUFNLENBQUMsRUFBRSxFQUFFLElBQUksQ0FBQyxRQUFRLENBQUMsV0FBVyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUM7UUFDM0UsSUFBSSxTQUFTLENBQUMsY0FBYyxDQUFDLE9BQU8sQ0FBQyxJQUFJLFNBQVMsQ0FBQyxPQUFPLENBQUMsRUFBRTtZQUN6RCxPQUFPLFNBQVMsQ0FBQyxPQUFPLENBQUMsQ0FBQztTQUM3Qjs7WUFDSSxTQUFTLENBQUMsT0FBTyxDQUFDLEdBQUcsSUFBSSxDQUFDO1FBQy9CLElBQUksQ0FBQyxRQUFRLENBQUMsV0FBVyxDQUFDLE9BQU8sRUFBRSxTQUFTLENBQUMsQ0FBQztRQUM5QyxtQ0FBbUM7SUFDdkMsQ0FBQztJQUVNLDZCQUFXLEdBQWxCO1FBQ0ksSUFBSSxJQUFJLENBQUMsUUFBUSxDQUFDLFdBQVcsQ0FBQyxhQUFhLENBQUMsS0FBSyxPQUFPLEVBQUU7WUFDdEQsSUFBSSxRQUFRLEdBQWMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxXQUFXLENBQUMsS0FBSyxDQUFDLENBQUM7WUFDM0QsSUFBSSxPQUFPLFFBQVEsS0FBSyxXQUFXLEVBQUU7Z0JBQ2pDLFFBQVEsQ0FBQyxPQUFPLENBQUMsY0FBYyxFQUFFLENBQUM7YUFDckM7U0FDSjtJQUNMLENBQUM7SUFFRCx5RUFBeUU7SUFDekUsc0JBQXNCO0lBQ2YsOENBQTRCLEdBQW5DLFVBQW9DLFdBQW1DO1FBQ25FLElBQUksUUFBUSxHQUFjLElBQUksQ0FBQyxRQUFRLENBQUMsV0FBVyxDQUFDLEtBQUssQ0FBQyxDQUFDO1FBQzNELElBQUksT0FBTyxRQUFRLEtBQUssV0FBVyxFQUFFO1lBQ2pDLFFBQVEsQ0FBQyxXQUFXLENBQUMsV0FBVyxDQUFDLFdBQVcsQ0FBQyxDQUFDO1NBQ2pEO0lBQ0wsQ0FBQztJQUVNLGtDQUFnQixHQUF2QixVQUF3QixXQUE2QjtRQUNqRCxJQUFJLFFBQVEsR0FBYyxJQUFJLENBQUMsUUFBUSxDQUFDLFdBQVcsQ0FBQyxLQUFLLENBQUMsQ0FBQztRQUMzRCxJQUFJLE9BQU8sUUFBUSxLQUFLLFdBQVcsRUFBRTtZQUNqQyxRQUFRLENBQUMsT0FBTyxDQUFDLFVBQVUsQ0FBQyxXQUFXLENBQUMsQ0FBQztTQUM1QztJQUNMLENBQUM7SUFFTSxnQ0FBYyxHQUFyQixVQUFzQixPQUFnQztRQUNsRCxJQUFJLFVBQVUsR0FBdUQ7WUFDakUsT0FBTyxFQUFFLElBQUksQ0FBQyxRQUFRLENBQUMsV0FBVyxDQUFDLEtBQUssQ0FBQztZQUN6QyxNQUFNLEVBQUUsT0FBTztTQUNsQixDQUFDO1FBQ0YsSUFBSSxDQUFDLG9CQUFvQixDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsQ0FBQztJQUMvQyxDQUFDO0lBRU0sdUNBQXFCLEdBQTVCLFVBQTZCLE9BQTJCO1FBQ3BELElBQUksVUFBVSxHQUFrRDtZQUM1RCxPQUFPLEVBQUUsSUFBSSxDQUFDLFFBQVEsQ0FBQyxXQUFXLENBQUMsS0FBSyxDQUFDO1lBQ3pDLE1BQU0sRUFBRSxPQUFPO1NBQ2xCLENBQUM7UUFDRixJQUFJLENBQUMsaUJBQWlCLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxDQUFDO0lBQzVDLENBQUM7O2dCQXJJb0IsWUFBWTtnQkFDZixpQkFBaUI7Z0JBQ1YsWUFBWTs7SUFmNUI7UUFBUixLQUFLLEVBQUU7OzZDQUFlO0lBQ2Q7UUFBUixLQUFLLEVBQUU7a0NBQU8sU0FBUzt5Q0FBQztJQUNoQjtRQUFSLEtBQUssRUFBRTs7K0NBQXFCO0lBQ25CO1FBQVQsTUFBTSxFQUFFO2tDQUEyQixZQUFZOzZEQUEyQjtJQUNqRTtRQUFULE1BQU0sRUFBRTtrQ0FBdUIsWUFBWTt5REFBMkI7SUFLN0Q7UUFBVCxNQUFNLEVBQUU7a0NBQXVCLFlBQVk7eURBQTBFO0lBQzVHO1FBQVQsTUFBTSxFQUFFO2tDQUFvQixZQUFZO3NEQUFxRTtJQWhCckcsT0FBTztRQVBuQixTQUFTLENBQUM7WUFDUCxRQUFRLEVBQUUsVUFBVTtZQUNwQixvNFNBQXNDO1lBQ3RDLFNBQVMsRUFBRSxDQUFDLFlBQVksRUFBRSxZQUFZLENBQUM7WUFDdkMsSUFBSSxFQUFHLEVBQUUsT0FBTyxFQUFHLGVBQWUsRUFBRTtTQUN2QyxDQUFDO3lDQXFCdUIsWUFBWTtZQUNmLGlCQUFpQjtZQUNWLFlBQVk7T0FyQjVCLE9BQU8sQ0F5Sm5CO0lBQUQsY0FBQztDQUFBLEFBekpELElBeUpDO1NBekpZLE9BQU8iLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQge1xyXG4gICAgQ29tcG9uZW50LFxyXG4gICAgSW5wdXQsXHJcbiAgICBPdXRwdXQsXHJcbiAgICBFdmVudEVtaXR0ZXIsXHJcbiAgICBPbkluaXQsXHJcbiAgICBBZnRlclZpZXdJbml0LFxyXG4gICAgT25EZXN0cm95LFxyXG4gICAgQ2hhbmdlRGV0ZWN0b3JSZWZcclxufSBmcm9tICdAYW5ndWxhci9jb3JlJztcclxuaW1wb3J0IHsgRm9ybUdyb3VwIH0gZnJvbSAnQGFuZ3VsYXIvZm9ybXMnO1xyXG5pbXBvcnQgeyB0aW1lciAsICBTdWJzY3JpcHRpb24gfSBmcm9tICdyeGpzJztcclxuaW1wb3J0IHtcclxuICAgIEtkVGFibGVTZWxlY3Rpb25VcGRhdGVFdmVudCxcclxuICAgIEtkVGFibGVJbnB1dFVwZGF0ZUV2ZW50LFxyXG4gICAgS2RUYWJsZUJ1dHRvbkV2ZW50LFxyXG4gICAgSVRhYmxlRm9ybVVwZGF0ZVBhcmFtcyxcclxuICAgIElUYWJsZUNlbGxQYXJhbXMsXHJcbiAgICBJVGFibGVBcGlcclxufSBmcm9tICcuLi9rZC1hbmd1bGFyLXRhYmxlL2luZGV4JztcclxuaW1wb3J0IHsgS2RUYWJsZUV2ZW50IH0gZnJvbSAnLi4va2QtYW5ndWxhci10YWJsZS9rZC1hbmd1bGFyLXRhYmxlLWV2ZW50JztcclxuaW1wb3J0IHsgS2REb21FbGVtU3ZjIH0gZnJvbSAnLi4va2QtY29tbW9uL2luZGV4JztcclxuXHJcbkBDb21wb25lbnQoe1xyXG4gICAgc2VsZWN0b3I6ICdrZC1pbnB1dCcsXHJcbiAgICB0ZW1wbGF0ZVVybDogJy4va2QtYW5ndWxhci1pbnB1dC5odG1sJyxcclxuICAgIHByb3ZpZGVyczogW0tkRG9tRWxlbVN2YywgS2RUYWJsZUV2ZW50XSxcclxuICAgIGhvc3QgOiB7ICdjbGFzcycgOiAna2R4IGtkeC1pbnB1dCcgfVxyXG59KVxyXG5cclxuZXhwb3J0IGNsYXNzIEtkSW5wdXQgaW1wbGVtZW50cyBPbkluaXQsIEFmdGVyVmlld0luaXQsIE9uRGVzdHJveSB7XHJcbiAgICBwdWJsaWMgX3Rvb2x0aXBQbGFjZW1lbnQ6IHN0cmluZztcclxuICAgIHByaXZhdGUgX3RvRW1pdDogYm9vbGVhbiA9IGZhbHNlO1xyXG4gICAgcHJpdmF0ZSBfc3Vic2NyaXB0aW9uT2JqOiB7W2tleTogc3RyaW5nXTogU3Vic2NyaXB0aW9ufSA9IHt9O1xyXG5cclxuICAgIC8vIEBJbnB1dCgpIHF1ZXN0aW9uOiBJbnB1dEJhc2U8YW55PjtcclxuICAgIEBJbnB1dCgpIHF1ZXN0aW9uOiBhbnk7XHJcbiAgICBASW5wdXQoKSBmb3JtOiBGb3JtR3JvdXA7XHJcbiAgICBASW5wdXQoKSBob3Jpem9udGFsOiBib29sZWFuO1xyXG4gICAgQE91dHB1dCgpIGNoYW5nZURldGVjdEZyb21RdWVzdGlvbjogRXZlbnRFbWl0dGVyPGFueT4gPSBuZXcgRXZlbnRFbWl0dGVyKCk7XHJcbiAgICBAT3V0cHV0KCkgY2hhbmdlRGV0ZWN0RnJvbUdyaWQ6IEV2ZW50RW1pdHRlcjxhbnk+ID0gbmV3IEV2ZW50RW1pdHRlcigpO1xyXG5cclxuICAgIC8vIEBPdXRwdXQoKSBncmlkQ2VsbFZhbHVlQ2hhbmdlZDogRXZlbnRFbWl0dGVyPHtmb3JtS2V5OiBzdHJpbmcsIHBhcmFtczogS2RUYWJsZUR5bmFtaWNGb3JtVXBkYXRlRXZlbnR9PiA9IG5ldyBFdmVudEVtaXR0ZXIoKTtcclxuICAgIC8vIEBWaWV3Q2hpbGQoS2RBZ0dyaWQpIGFnR3JpZENvbXBvbmVudDogS2RBZ0dyaWQ7XHJcblxyXG4gICAgQE91dHB1dCgpIGdyaWRDZWxsVmFsdWVDaGFuZ2VkOiBFdmVudEVtaXR0ZXI8e2Zvcm1LZXk6IHN0cmluZywgcGFyYW1zOiBLZFRhYmxlSW5wdXRVcGRhdGVFdmVudH0+ID0gbmV3IEV2ZW50RW1pdHRlcigpO1xyXG4gICAgQE91dHB1dCgpIGdyaWRCdXR0b25DbGlja2VkOiBFdmVudEVtaXR0ZXI8e2Zvcm1LZXk6IHN0cmluZywgcGFyYW1zOiBLZFRhYmxlQnV0dG9uRXZlbnR9PiA9IG5ldyBFdmVudEVtaXR0ZXIoKTtcclxuXHJcbiAgICBjb25zdHJ1Y3RvcihcclxuICAgICAgICBwcml2YXRlIF9kb21TdmM6IEtkRG9tRWxlbVN2YyxcclxuICAgICAgICBwcml2YXRlIF9jZGY6IENoYW5nZURldGVjdG9yUmVmLFxyXG4gICAgICAgIHByaXZhdGUgX3RhYmxlRXZlbnQ6IEtkVGFibGVFdmVudFxyXG4gICAgKSB7IH1cclxuXHJcbiAgICBuZ09uSW5pdCgpOiB2b2lkIHtcclxuICAgICAgICB0aGlzLl90b29sdGlwUGxhY2VtZW50ID0gdGhpcy5fZG9tU3ZjLmdldERvY3VtZW50RGlyZWN0aW9uKHRydWUpID09PSAnbGVmdCcgPyAncmlnaHQnIDogJ2xlZnQnO1xyXG4gICAgICAgIGlmICh0aGlzLnF1ZXN0aW9uLmdldFByb3BlcnR5KCdjb250cm9sVHlwZScpID09PSAndGFibGUnKSB7XHJcbiAgICAgICAgICAgIGxldCB0YWJsZUNvbmZpZ0lkOiBzdHJpbmcgPSB0aGlzLnF1ZXN0aW9uLmdldFByb3BlcnR5KCdjb25maWcnKS5pZDtcclxuICAgICAgICAgICAgbGV0IHRhYmxlQXBpOiBJVGFibGVBcGkgPSB0aGlzLnF1ZXN0aW9uLmdldFByb3BlcnR5KCdhcGknKTtcclxuXHJcbiAgICAgICAgICAgIHRoaXMuX3N1YnNjcmlwdGlvbk9iai50YWJsZUV2ZW50cyA9IHRoaXMuX3RhYmxlRXZlbnQub25LZFRhYmxlRXZlbnRMaXN0KHRhYmxlQ29uZmlnSWQpLnN1YnNjcmliZSgoX2V2ZW50czogYW55KTogdm9pZCA9PiB7XHJcbiAgICAgICAgICAgICAgICBpZiAoX2V2ZW50cyBpbnN0YW5jZW9mIEtkVGFibGVTZWxlY3Rpb25VcGRhdGVFdmVudCkge1xyXG4gICAgICAgICAgICAgICAgICAgIC8vIGNvbnNvbGUubG9nKCc+Pj4gS2RJbnB1dCAtIEtkVGFibGVTZWxlY3Rpb25VcGRhdGVFdmVudCcsIF9ldmVudHMpO1xyXG5cclxuICAgICAgICAgICAgICAgICAgICAvLyBTa2lwIGEgdGljayB0byBwcmV2ZW50IEV4cHJlc3Npb24gY2hhbmdlIGVycm9yXHJcbiAgICAgICAgICAgICAgICAgICAgdGltZXIoKS5zdWJzY3JpYmUoKCk6IHZvaWQgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLnZhbHVlVXBkYXRlKF9ldmVudHMuc2VsZWN0ZWROb2Rlcyk7XHJcbiAgICAgICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICAgICAgZWxzZSBpZiAoX2V2ZW50cyBpbnN0YW5jZW9mIEtkVGFibGVJbnB1dFVwZGF0ZUV2ZW50KSB7XHJcbiAgICAgICAgICAgICAgICAgICAgLy8gY29uc29sZS5sb2coJz4+PiBLZElucHV0IC0gS2RUYWJsZUR5bmFtaWNGb3JtVXBkYXRlRXZlbnQnLCBfZXZlbnRzKTtcclxuXHJcbiAgICAgICAgICAgICAgICAgICAgLy8gU2tpcCBhIHRpY2sgdG8gcHJldmVudCBFeHByZXNzaW9uIGNoYW5nZSBlcnJvclxyXG4gICAgICAgICAgICAgICAgICAgIHRpbWVyKCkuc3Vic2NyaWJlKCgpOiB2b2lkID0+IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy52YWx1ZVVwZGF0ZSh0YWJsZUFwaS5nZW5lcmFsLmdldEN1cnJlbnRSb3dzKCkpO1xyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgLy8vIFRvIG9ubHkgZW1pdHMgdGhlIGNlbGwgZXZlbnQgaWYgYSBpbnB1dCB0cmlnZ2VycyB0aGUgZW1pdFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAodHlwZW9mIF9ldmVudHMucXVlc3Rpb24gIT09ICd1bmRlZmluZWQnKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0aGlzLmVtaXRDZWxsVXBkYXRlKF9ldmVudHMpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICAgICAgZWxzZSBpZiAoX2V2ZW50cyBpbnN0YW5jZW9mIEtkVGFibGVCdXR0b25FdmVudCkge1xyXG4gICAgICAgICAgICAgICAgICAgIC8vIGNvbnNvbGUubG9nKCc+Pj4gS2RJbnB1dCAtIEtkVGFibGVEeW5hbWljRm9ybVVwZGF0ZUV2ZW50JywgX2V2ZW50cyk7XHJcbiAgICAgICAgICAgICAgICAgICAgdGltZXIoKS5zdWJzY3JpYmUoKCk6IHZvaWQgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLmVtaXRHcmlkQnV0dG9uQ2xpY2tlZChfZXZlbnRzKTtcclxuICAgICAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIG5nQWZ0ZXJWaWV3SW5pdCgpOiB2b2lkIHtcclxuICAgICAgICAvLyBlbnN1cmUgZmlyc3Qgb25jaGFuZ2UgcnVuIGRvIG5vdCBlbWl0IG91dCBkYXRhXHJcbiAgICAgICAgdGltZXIoMTApLnN1YnNjcmliZSgoKTogdm9pZCA9PiB7XHJcbiAgICAgICAgICAgIHRoaXMuX3RvRW1pdCA9IHRydWU7XHJcbiAgICAgICAgfSk7XHJcbiAgICB9XHJcblxyXG4gICAgbmdPbkRlc3Ryb3koKSB7XHJcbiAgICAgICAgZm9yIChsZXQgaXRlbSBpbiB0aGlzLl9zdWJzY3JpcHRpb25PYmopIHtcclxuICAgICAgICAgICAgaWYgKHR5cGVvZiB0aGlzLl9zdWJzY3JpcHRpb25PYmpbaXRlbV0gIT09ICd1bmRlZmluZWQnKSB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLl9zdWJzY3JpcHRpb25PYmpbaXRlbV0udW5zdWJzY3JpYmUoKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICBjaGFuZ2VEZXRlY3QoKTogdm9pZCB7XHJcbiAgICAgICAgaWYgKHRoaXMuX3RvRW1pdCkgdGhpcy5jaGFuZ2VEZXRlY3RGcm9tUXVlc3Rpb24uZW1pdCh0aGlzLnF1ZXN0aW9uKTtcclxuICAgIH1cclxuXHJcbiAgICB2YWx1ZVVwZGF0ZShkYXRhOiBhbnkpOiB2b2lkIHtcclxuICAgICAgICBpZiAoIXRoaXMuX3RvRW1pdCkge1xyXG4gICAgICAgICAgICB0aGlzLl9jZGYuZGV0YWNoKCk7XHJcbiAgICAgICAgICAgIHRoaXMucXVlc3Rpb24uc2V0UHJvcGVydHkoJ3ZhbHVlJywgZGF0YSk7XHJcbiAgICAgICAgICAgIHRoaXMuX2NkZi5kZXRlY3RDaGFuZ2VzKCk7XHJcbiAgICAgICAgICAgIHRoaXMuX2NkZi5yZWF0dGFjaCgpO1xyXG4gICAgICAgIH1cclxuICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgdGltZXIoKS5zdWJzY3JpYmUoKCk6IHZvaWQgPT4ge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5xdWVzdGlvbi5zZXRQcm9wZXJ0eSgndmFsdWUnLCBkYXRhKTtcclxuICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIGFnQ2VsbFZhbHVlVXBkYXRlKF9jZWxsT2JqZWN0OiBhbnkpOiB2b2lkIHtcclxuICAgICAgICBfY2VsbE9iamVjdC5ncmlkSWQgPSB0aGlzLnF1ZXN0aW9uLmdldFByb3BlcnR5KCdrZXknKTtcclxuICAgICAgICB0aGlzLmNoYW5nZURldGVjdEZyb21HcmlkLmVtaXQoX2NlbGxPYmplY3QpO1xyXG5cclxuICAgIH1cclxuXHJcbiAgICBnZXRDaGVja2JveEFycmF5KGV2ZW50OiBhbnksIGl0ZW1WYWw6IGFueSk6IHZvaWQge1xyXG4gICAgICAgIGxldCBuZXdPYmplY3Q6IGFueSA9IE9iamVjdC5hc3NpZ24oe30sIHRoaXMucXVlc3Rpb24uZ2V0UHJvcGVydHkoJ3ZhbHVlJykpO1xyXG4gICAgICAgIGlmIChuZXdPYmplY3QuaGFzT3duUHJvcGVydHkoaXRlbVZhbCkgJiYgbmV3T2JqZWN0W2l0ZW1WYWxdKSB7XHJcbiAgICAgICAgICAgIGRlbGV0ZSBuZXdPYmplY3RbaXRlbVZhbF07XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGVsc2UgbmV3T2JqZWN0W2l0ZW1WYWxdID0gdHJ1ZTtcclxuICAgICAgICB0aGlzLnF1ZXN0aW9uLnNldFByb3BlcnR5KCd2YWx1ZScsIG5ld09iamVjdCk7XHJcbiAgICAgICAgLy8gdGhpcy5xdWVzdGlvbi52YWx1ZSA9IG5ld09iamVjdDtcclxuICAgIH1cclxuXHJcbiAgICBwdWJsaWMgcmVzZXRIZWlnaHQoKTogdm9pZCB7XHJcbiAgICAgICAgaWYgKHRoaXMucXVlc3Rpb24uZ2V0UHJvcGVydHkoJ2NvbnRyb2xUeXBlJykgPT09ICd0YWJsZScpIHtcclxuICAgICAgICAgICAgbGV0IHRhYmxlQXBpOiBJVGFibGVBcGkgPSB0aGlzLnF1ZXN0aW9uLmdldFByb3BlcnR5KCdhcGknKTtcclxuICAgICAgICAgICAgaWYgKHR5cGVvZiB0YWJsZUFwaSAhPT0gJ3VuZGVmaW5lZCcpIHtcclxuICAgICAgICAgICAgICAgIHRhYmxlQXBpLmdlbmVyYWwucmVzZXRSb3dIZWlnaHQoKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICAvKioqKioqKioqKioqKioqKioqKioqKioqKiogVGFibGUgY29udHJvbFR5cGUgKioqKioqKioqKioqKioqKioqKioqKioqKiovXHJcbiAgICAvLy8vIFRhYmxlIGNvbnRyb2xUeXBlXHJcbiAgICBwdWJsaWMgc2V0VGFibGVDZWxsUXVlc3Rpb25Qcm9wZXJ0eShfZm9ybVBhcmFtczogSVRhYmxlRm9ybVVwZGF0ZVBhcmFtcyk6IHZvaWQge1xyXG4gICAgICAgIGxldCB0YWJsZUFwaTogSVRhYmxlQXBpID0gdGhpcy5xdWVzdGlvbi5nZXRQcm9wZXJ0eSgnYXBpJyk7XHJcbiAgICAgICAgaWYgKHR5cGVvZiB0YWJsZUFwaSAhPT0gJ3VuZGVmaW5lZCcpIHtcclxuICAgICAgICAgICAgdGFibGVBcGkuZHluYW1pY0Zvcm0uc2V0UHJvcGVydHkoX2Zvcm1QYXJhbXMpO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICBwdWJsaWMgc2V0VGFibGVDZWxsRGF0YShfY2VsbFBhcmFtczogSVRhYmxlQ2VsbFBhcmFtcyk6IHZvaWQge1xyXG4gICAgICAgIGxldCB0YWJsZUFwaTogSVRhYmxlQXBpID0gdGhpcy5xdWVzdGlvbi5nZXRQcm9wZXJ0eSgnYXBpJyk7XHJcbiAgICAgICAgaWYgKHR5cGVvZiB0YWJsZUFwaSAhPT0gJ3VuZGVmaW5lZCcpIHtcclxuICAgICAgICAgICAgdGFibGVBcGkuZ2VuZXJhbC51cGRhdGVDZWxsKF9jZWxsUGFyYW1zKTtcclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgcHVibGljIGVtaXRDZWxsVXBkYXRlKF9wYXJhbXM6IEtkVGFibGVJbnB1dFVwZGF0ZUV2ZW50KTogdm9pZCB7XHJcbiAgICAgICAgbGV0IGVtaXRQYXJhbXM6IHtmb3JtS2V5OiBzdHJpbmcsIHBhcmFtczogS2RUYWJsZUlucHV0VXBkYXRlRXZlbnR9ID0ge1xyXG4gICAgICAgICAgICBmb3JtS2V5OiB0aGlzLnF1ZXN0aW9uLmdldFByb3BlcnR5KCdrZXknKSxcclxuICAgICAgICAgICAgcGFyYW1zOiBfcGFyYW1zXHJcbiAgICAgICAgfTtcclxuICAgICAgICB0aGlzLmdyaWRDZWxsVmFsdWVDaGFuZ2VkLmVtaXQoZW1pdFBhcmFtcyk7XHJcbiAgICB9XHJcblxyXG4gICAgcHVibGljIGVtaXRHcmlkQnV0dG9uQ2xpY2tlZChfcGFyYW1zOiBLZFRhYmxlQnV0dG9uRXZlbnQpOiB2b2lkIHtcclxuICAgICAgICBsZXQgZW1pdFBhcmFtczoge2Zvcm1LZXk6IHN0cmluZywgcGFyYW1zOiBLZFRhYmxlQnV0dG9uRXZlbnR9ID0ge1xyXG4gICAgICAgICAgICBmb3JtS2V5OiB0aGlzLnF1ZXN0aW9uLmdldFByb3BlcnR5KCdrZXknKSxcclxuICAgICAgICAgICAgcGFyYW1zOiBfcGFyYW1zXHJcbiAgICAgICAgfTtcclxuICAgICAgICB0aGlzLmdyaWRCdXR0b25DbGlja2VkLmVtaXQoZW1pdFBhcmFtcyk7XHJcbiAgICB9XHJcbn1cclxuIl19