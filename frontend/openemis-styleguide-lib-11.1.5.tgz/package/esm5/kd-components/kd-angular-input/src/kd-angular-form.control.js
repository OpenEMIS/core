import { __decorate, __metadata } from "tslib";
import { Injectable } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
var KdInputControlService = /** @class */ (function () {
    function KdInputControlService() {
    }
    KdInputControlService.prototype.toFormGroup = function (inputs) {
        var group = {};
        for (var i = 0; i < inputs.length; i++) {
            var validatorArr = [];
            // Grace -- 7 Nov 2017 --
            // testing generate validator function by passing validation logic as string but load speed will become very slow
            // if(inputs[i].getProperty('required')){
            //     validatorArr.push(this._generalValidatorFnGenerator({
            //         target: 'control.value',
            //         compare: '',
            //         logic: 'return a !== b? false: true'
            //     }, 'this field cannot be empty' ))
            // }
            if (inputs[i].getProperty('controlType') === 'file-input') {
                var config = inputs[i].getProperty('config');
                validatorArr.push(this._fileSizeValidator(config.maxFileSize, config.errorMessage));
            }
            // if (inputs[i].getProperty('required')) {
            //     validatorArr.push(this._requiredValidator('This field should not be empty'));
            // }
            group[inputs[i].getProperty('key')] = new FormControl(inputs[i].getProperty('value') || '', Validators.compose(validatorArr));
        }
        return new FormGroup(group);
    };
    KdInputControlService.prototype.emptyFormGroup = function () {
        return new FormGroup({});
    };
    KdInputControlService.prototype._fileSizeValidator = function (maxFileSize, errorMessage) {
        return function (control) {
            var _a;
            var sizeExceed = false;
            if (typeof control !== 'undefined' &&
                typeof control.value !== 'undefined' &&
                typeof control.value.size !== 'undefined') {
                sizeExceed = control.value.size > maxFileSize;
            }
            return sizeExceed ? (_a = {}, _a[new Date().toISOString()] = errorMessage, _a) : null;
        };
    };
    KdInputControlService = __decorate([
        Injectable(),
        __metadata("design:paramtypes", [])
    ], KdInputControlService);
    return KdInputControlService;
}());
export { KdInputControlService };
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoia2QtYW5ndWxhci1mb3JtLmNvbnRyb2wuanMiLCJzb3VyY2VSb290Ijoibmc6Ly9vcGVuZW1pcy1zdHlsZWd1aWRlLWxpYi8iLCJzb3VyY2VzIjpbImtkLWNvbXBvbmVudHMva2QtYW5ndWxhci1pbnB1dC9zcmMva2QtYW5ndWxhci1mb3JtLmNvbnRyb2wudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IjtBQUFBLE9BQU8sRUFBRSxVQUFVLEVBQUUsTUFBTSxlQUFlLENBQUM7QUFDM0MsT0FBTyxFQUFFLFdBQVcsRUFBRSxTQUFTLEVBQUUsVUFBVSxFQUFnQyxNQUFNLGdCQUFnQixDQUFDO0FBS2xHO0lBQ0k7SUFBZ0IsQ0FBQztJQUVqQiwyQ0FBVyxHQUFYLFVBQVksTUFBd0I7UUFDaEMsSUFBSSxLQUFLLEdBQVEsRUFBRSxDQUFDO1FBRXBCLEtBQUssSUFBSSxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsR0FBRyxNQUFNLENBQUMsTUFBTSxFQUFFLENBQUMsRUFBRSxFQUFFO1lBQ3BDLElBQUksWUFBWSxHQUF1QixFQUFFLENBQUM7WUFHMUMseUJBQXlCO1lBQ3pCLGlIQUFpSDtZQUNqSCx5Q0FBeUM7WUFDekMsNERBQTREO1lBQzVELG1DQUFtQztZQUNuQyx1QkFBdUI7WUFDdkIsK0NBQStDO1lBQy9DLHlDQUF5QztZQUN6QyxJQUFJO1lBRUosSUFBSSxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsV0FBVyxDQUFDLGFBQWEsQ0FBQyxLQUFLLFlBQVksRUFBRTtnQkFDdkQsSUFBTSxNQUFNLEdBQUcsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLFdBQVcsQ0FBQyxRQUFRLENBQUMsQ0FBQztnQkFDL0MsWUFBWSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsa0JBQWtCLENBQUMsTUFBTSxDQUFDLFdBQVcsRUFBRSxNQUFNLENBQUMsWUFBWSxDQUFDLENBQUMsQ0FBQzthQUN2RjtZQUVELDJDQUEyQztZQUMzQyxvRkFBb0Y7WUFDcEYsSUFBSTtZQUVKLEtBQUssQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsV0FBVyxDQUFDLEtBQUssQ0FBQyxDQUFDLEdBQUcsSUFBSSxXQUFXLENBQ2pELE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxXQUFXLENBQUMsT0FBTyxDQUFDLElBQUksRUFBRSxFQUNwQyxVQUFVLENBQUMsT0FBTyxDQUFDLFlBQVksQ0FBQyxDQUNuQyxDQUFDO1NBQ0w7UUFDRCxPQUFPLElBQUksU0FBUyxDQUFDLEtBQUssQ0FBQyxDQUFDO0lBQ2hDLENBQUM7SUFFRCw4Q0FBYyxHQUFkO1FBQ0ksT0FBTyxJQUFJLFNBQVMsQ0FBQyxFQUFFLENBQUMsQ0FBQztJQUM3QixDQUFDO0lBRU8sa0RBQWtCLEdBQTFCLFVBQTJCLFdBQW1CLEVBQUUsWUFBb0I7UUFDaEUsT0FBTyxVQUFDLE9BQXdCOztZQUM1QixJQUFJLFVBQVUsR0FBWSxLQUFLLENBQUM7WUFFaEMsSUFBSSxPQUFPLE9BQU8sS0FBSyxXQUFXO2dCQUM5QixPQUFPLE9BQU8sQ0FBQyxLQUFLLEtBQUssV0FBVztnQkFDcEMsT0FBTyxPQUFPLENBQUMsS0FBSyxDQUFDLElBQUksS0FBSyxXQUFXLEVBQUU7Z0JBQ3ZDLFVBQVUsR0FBRyxPQUFPLENBQUMsS0FBSyxDQUFDLElBQUksR0FBRyxXQUFXLENBQUM7YUFDckQ7WUFDRCxPQUFPLFVBQVUsQ0FBQyxDQUFDLFdBQUcsR0FBQyxJQUFJLElBQUksRUFBRSxDQUFDLFdBQVcsRUFBRSxJQUFHLFlBQVksTUFBRyxDQUFDLENBQUMsSUFBSSxDQUFDO1FBQzVFLENBQUMsQ0FBQztJQUNOLENBQUM7SUFwRFEscUJBQXFCO1FBRGpDLFVBQVUsRUFBRTs7T0FDQSxxQkFBcUIsQ0F1RWpDO0lBQUQsNEJBQUM7Q0FBQSxBQXZFRCxJQXVFQztTQXZFWSxxQkFBcUIiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBJbmplY3RhYmxlIH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XHJcbmltcG9ydCB7IEZvcm1Db250cm9sLCBGb3JtR3JvdXAsIFZhbGlkYXRvcnMsIFZhbGlkYXRvckZuLCBBYnN0cmFjdENvbnRyb2wgfSBmcm9tICdAYW5ndWxhci9mb3Jtcyc7XHJcblxyXG5pbXBvcnQgeyBJbnB1dEJhc2UgfSBmcm9tICcuL2tkLWlucHV0LWJhc2UnO1xyXG5cclxuQEluamVjdGFibGUoKVxyXG5leHBvcnQgY2xhc3MgS2RJbnB1dENvbnRyb2xTZXJ2aWNlIHtcclxuICAgIGNvbnN0cnVjdG9yKCkgeyB9XHJcblxyXG4gICAgdG9Gb3JtR3JvdXAoaW5wdXRzOiBJbnB1dEJhc2U8YW55PltdKTogRm9ybUdyb3VwIHtcclxuICAgICAgICBsZXQgZ3JvdXA6IGFueSA9IHt9O1xyXG5cclxuICAgICAgICBmb3IgKGxldCBpID0gMDsgaSA8IGlucHV0cy5sZW5ndGg7IGkrKykge1xyXG4gICAgICAgICAgICBsZXQgdmFsaWRhdG9yQXJyOiBBcnJheTxWYWxpZGF0b3JGbj4gPSBbXTtcclxuXHJcblxyXG4gICAgICAgICAgICAvLyBHcmFjZSAtLSA3IE5vdiAyMDE3IC0tXHJcbiAgICAgICAgICAgIC8vIHRlc3RpbmcgZ2VuZXJhdGUgdmFsaWRhdG9yIGZ1bmN0aW9uIGJ5IHBhc3NpbmcgdmFsaWRhdGlvbiBsb2dpYyBhcyBzdHJpbmcgYnV0IGxvYWQgc3BlZWQgd2lsbCBiZWNvbWUgdmVyeSBzbG93XHJcbiAgICAgICAgICAgIC8vIGlmKGlucHV0c1tpXS5nZXRQcm9wZXJ0eSgncmVxdWlyZWQnKSl7XHJcbiAgICAgICAgICAgIC8vICAgICB2YWxpZGF0b3JBcnIucHVzaCh0aGlzLl9nZW5lcmFsVmFsaWRhdG9yRm5HZW5lcmF0b3Ioe1xyXG4gICAgICAgICAgICAvLyAgICAgICAgIHRhcmdldDogJ2NvbnRyb2wudmFsdWUnLFxyXG4gICAgICAgICAgICAvLyAgICAgICAgIGNvbXBhcmU6ICcnLFxyXG4gICAgICAgICAgICAvLyAgICAgICAgIGxvZ2ljOiAncmV0dXJuIGEgIT09IGI/IGZhbHNlOiB0cnVlJ1xyXG4gICAgICAgICAgICAvLyAgICAgfSwgJ3RoaXMgZmllbGQgY2Fubm90IGJlIGVtcHR5JyApKVxyXG4gICAgICAgICAgICAvLyB9XHJcblxyXG4gICAgICAgICAgICBpZiAoaW5wdXRzW2ldLmdldFByb3BlcnR5KCdjb250cm9sVHlwZScpID09PSAnZmlsZS1pbnB1dCcpIHtcclxuICAgICAgICAgICAgICAgIGNvbnN0IGNvbmZpZyA9IGlucHV0c1tpXS5nZXRQcm9wZXJ0eSgnY29uZmlnJyk7XHJcbiAgICAgICAgICAgICAgICB2YWxpZGF0b3JBcnIucHVzaCh0aGlzLl9maWxlU2l6ZVZhbGlkYXRvcihjb25maWcubWF4RmlsZVNpemUsIGNvbmZpZy5lcnJvck1lc3NhZ2UpKTtcclxuICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgLy8gaWYgKGlucHV0c1tpXS5nZXRQcm9wZXJ0eSgncmVxdWlyZWQnKSkge1xyXG4gICAgICAgICAgICAvLyAgICAgdmFsaWRhdG9yQXJyLnB1c2godGhpcy5fcmVxdWlyZWRWYWxpZGF0b3IoJ1RoaXMgZmllbGQgc2hvdWxkIG5vdCBiZSBlbXB0eScpKTtcclxuICAgICAgICAgICAgLy8gfVxyXG5cclxuICAgICAgICAgICAgZ3JvdXBbaW5wdXRzW2ldLmdldFByb3BlcnR5KCdrZXknKV0gPSBuZXcgRm9ybUNvbnRyb2woXHJcbiAgICAgICAgICAgICAgICBpbnB1dHNbaV0uZ2V0UHJvcGVydHkoJ3ZhbHVlJykgfHwgJycsXHJcbiAgICAgICAgICAgICAgICBWYWxpZGF0b3JzLmNvbXBvc2UodmFsaWRhdG9yQXJyKVxyXG4gICAgICAgICAgICApO1xyXG4gICAgICAgIH1cclxuICAgICAgICByZXR1cm4gbmV3IEZvcm1Hcm91cChncm91cCk7XHJcbiAgICB9XHJcblxyXG4gICAgZW1wdHlGb3JtR3JvdXAoKTogRm9ybUdyb3VwIHtcclxuICAgICAgICByZXR1cm4gbmV3IEZvcm1Hcm91cCh7fSk7XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfZmlsZVNpemVWYWxpZGF0b3IobWF4RmlsZVNpemU6IG51bWJlciwgZXJyb3JNZXNzYWdlOiBzdHJpbmcpOiBWYWxpZGF0b3JGbiB7XHJcbiAgICAgICAgcmV0dXJuIChjb250cm9sOiBBYnN0cmFjdENvbnRyb2wpOiB7IFtrZXk6IHN0cmluZ106IGFueSB9ID0+IHtcclxuICAgICAgICAgICAgbGV0IHNpemVFeGNlZWQ6IGJvb2xlYW4gPSBmYWxzZTtcclxuXHJcbiAgICAgICAgICAgIGlmICh0eXBlb2YgY29udHJvbCAhPT0gJ3VuZGVmaW5lZCcgJiZcclxuICAgICAgICAgICAgICAgIHR5cGVvZiBjb250cm9sLnZhbHVlICE9PSAndW5kZWZpbmVkJyAmJlxyXG4gICAgICAgICAgICAgICAgdHlwZW9mIGNvbnRyb2wudmFsdWUuc2l6ZSAhPT0gJ3VuZGVmaW5lZCcpIHtcclxuICAgICAgICAgICAgICAgICAgICBzaXplRXhjZWVkID0gY29udHJvbC52YWx1ZS5zaXplID4gbWF4RmlsZVNpemU7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgcmV0dXJuIHNpemVFeGNlZWQgPyB7IFtuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCldOiBlcnJvck1lc3NhZ2UgfSA6IG51bGw7XHJcbiAgICAgICAgfTtcclxuICAgIH1cclxuXHJcbiAgICAvLyBwcml2YXRlIF9yZXF1aXJlZFZhbGlkYXRvcihlcnJvck1lc3NhZ2U6IHN0cmluZyk6IFZhbGlkYXRvckZuIHtcclxuICAgIC8vICAgICByZXR1cm4gKGNvbnRyb2w6IEFic3RyYWN0Q29udHJvbCk6IHtba2V5OiBzdHJpbmddOiBhbnl9ID0+IHtcclxuICAgIC8vICAgICAgICAgaWYgKHR5cGVvZiBjb250cm9sLnZhbHVlICE9PSAndW5kZWZpbmVkJykge1xyXG4gICAgLy8gICAgICAgICAgICAgY29uc3QgZXJyb3I6IGJvb2xlYW4gPSBjb250cm9sLnZhbHVlID09PSAnJyA/IHRydWUgOiBmYWxzZTtcclxuICAgIC8vICAgICAgICAgICAgIHJldHVybiBlcnJvciA/IHtbbmV3IERhdGUoKS50b0lTT1N0cmluZyAoKV06IGVycm9yTWVzc2FnZX0gOiBudWxsO1xyXG4gICAgLy8gICAgICAgICB9XHJcbiAgICAvLyAgICAgfTtcclxuICAgIC8vIH1cclxuXHJcbiAgICAvLyBHcmFjZSAtLSA3IE5vdiAyMDE3IC0tIGdlbmVyYWwgdmFsaWRhdG9yIGZ1bmN0aW9uIGdlbmVyYXRvclxyXG4gICAgLy8gcHJpdmF0ZSBfZ2VuZXJhbFZhbGlkYXRvckZuR2VuZXJhdG9yKGxvZ2ljVG9UZXN0Om9iamVjdCwgZXJyb3JNZXNzYWdlOiBzdHJpbmcpOlZhbGlkYXRvckZuIHtcclxuICAgIC8vICAgICByZXR1cm4gKGNvbnRyb2w6IEFic3RyYWN0Q29udHJvbCk6IHtba2V5OiBzdHJpbmddOiBhbnl9ID0+IHtcclxuICAgIC8vICAgICBsZXQgbG9naWNGdW5jdGlvbiA9IG5ldyBGdW5jdGlvbignYScsJ2InLCBsb2dpY1RvVGVzdC5sb2dpYylcclxuICAgIC8vICAgICBsZXQgZXJyb3IgPSBsb2dpY0Z1bmN0aW9uKGV2YWwobG9naWNUb1Rlc3QudGFyZ2V0KSxsb2dpY1RvVGVzdC5jb21wYXJlKTtcclxuICAgIC8vICAgICByZXR1cm4gZXJyb3IgPyB7IFtuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nICgpXSA6IGVycm9yTWVzc2FnZX0gOiBudWxsO1xyXG4gICAgLy8gICB9O1xyXG4gICAgLy8gfVxyXG59XHJcbiJdfQ==