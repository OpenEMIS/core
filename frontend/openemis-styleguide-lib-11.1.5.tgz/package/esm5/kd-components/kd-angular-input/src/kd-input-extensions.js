import { __extends } from "tslib";
import { InputBase } from './kd-input-base';
var KdInputSection = /** @class */ (function (_super) {
    __extends(KdInputSection, _super);
    function KdInputSection() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    return KdInputSection;
}(InputBase));
export { KdInputSection };
var KdInputText = /** @class */ (function (_super) {
    __extends(KdInputText, _super);
    function KdInputText(options) {
        if (options === void 0) { options = {}; }
        var _this = _super.call(this, options) || this;
        _this.type = options['type'] || 'text';
        switch (_this.type) {
            case 'autocomplete':
                _this.autocomplete = options['autocomplete'] || false;
                _this.placeholder = options['placeholder'] || '';
                _this.clickToggleDropdown = options['clickToggleDropdown'] || false;
                _this.options = options['options'] || undefined;
                _this.dropdownCallback = options['dropdownCallback'] || undefined;
                _this.lengthToSearch = options['lengthToSearch'] || null;
                _this.onEnter = options['onEnter'] || false;
                break;
            case 'multiselect':
                _this.multiselect = options['multiselect'] || false;
                _this.placeholder = options['placeholder'] || '';
                _this.clickToggleDropdown = options['clickToggleDropdown'] || false;
                _this.options = options['options'] || undefined;
                _this.dropdownCallback = options['dropdownCallback'] || undefined;
                _this.lengthToSearch = options['lengthToSearch'] || null;
                _this.onEnter = options['onEnter'] || false;
                break;
            default:
                _this.value = options['value'] || '';
                _this.placeholder = options['placeholder'] || '';
                _this.maxLength = options['maxlength'] || 250;
                break;
        }
        return _this;
    }
    return KdInputText;
}(InputBase));
export { KdInputText };
var KdInputInteger = /** @class */ (function (_super) {
    __extends(KdInputInteger, _super);
    function KdInputInteger(options) {
        if (options === void 0) { options = {}; }
        var _this = _super.call(this, options) || this;
        _this.min = options['min'] || undefined;
        _this.max = options['max'] || undefined;
        return _this;
    }
    return KdInputInteger;
}(InputBase));
export { KdInputInteger };
var KdInputFloat = /** @class */ (function (_super) {
    __extends(KdInputFloat, _super);
    function KdInputFloat(options) {
        if (options === void 0) { options = {}; }
        var _this = _super.call(this, options) || this;
        _this.max = options['max'] || 1;
        _this.float = options['float'] || 0.01;
        _this.min = options['min'] || 0;
        return _this;
    }
    return KdInputFloat;
}(InputBase));
export { KdInputFloat };
var KdInputDate = /** @class */ (function (_super) {
    __extends(KdInputDate, _super);
    function KdInputDate(options) {
        if (options === void 0) { options = {}; }
        var _this = _super.call(this, options) || this;
        var tempConfig = {
            firstDayOfWeek: 1,
            // minDate: {
            //     year: 2000,
            //              month: 0,
            //              day: 5
            //       },
            // maxDate: {
            //     year: 2016,
            //     month: 12,
            //     day: 20
            // },
            showNavigation: true,
            showWeekNumbers: false,
            showWeekdays: false
        };
        _this.config = options['config'] || tempConfig;
        _this.minDate = options['minDate'] || undefined;
        _this.maxDate = options['maxDate'] || undefined;
        return _this;
    }
    return KdInputDate;
}(InputBase));
export { KdInputDate };
var KdInputTime = /** @class */ (function (_super) {
    __extends(KdInputTime, _super);
    function KdInputTime(options) {
        if (options === void 0) { options = {}; }
        var _this = _super.call(this, options) || this;
        var tempConfig = {
            disabled: false,
            meridian: true,
            readonlyInputs: false,
            seconds: false,
            spinners: true
        };
        _this.config = options['config'] || tempConfig;
        return _this;
    }
    return KdInputTime;
}(InputBase));
export { KdInputTime };
var KdInputPassword = /** @class */ (function (_super) {
    __extends(KdInputPassword, _super);
    function KdInputPassword(options) {
        if (options === void 0) { options = {}; }
        var _this = _super.call(this, options) || this;
        _this.password = '';
        if (typeof options['value'] !== 'undefined')
            _this.password = '***********';
        else
            _this.password = '';
        return _this;
    }
    return KdInputPassword;
}(InputBase));
export { KdInputPassword };
var KdInputTextarea = /** @class */ (function (_super) {
    __extends(KdInputTextarea, _super);
    function KdInputTextarea(options) {
        if (options === void 0) { options = {}; }
        var _this = _super.call(this, options) || this;
        _this.disabled = options['disabled'] || false;
        return _this;
    }
    return KdInputTextarea;
}(InputBase));
export { KdInputTextarea };
var KdInputHidden = /** @class */ (function (_super) {
    __extends(KdInputHidden, _super);
    function KdInputHidden(options) {
        if (options === void 0) { options = {}; }
        return _super.call(this, options) || this;
    }
    return KdInputHidden;
}(InputBase));
export { KdInputHidden };
// export class KdInputDisabled extends InputBase<string> {
//   // private disabled: boolean = true;
//   constructor(options: {} = {}) {
//     super(options);
//   }
// }
// export class KdInputReadOnly extends InputBase<string> {
//   // private readOnly: boolean = true;
//   constructor(options: {} = {}) {
//     super(options);
//   }
// }
var KdInputFileinput = /** @class */ (function (_super) {
    __extends(KdInputFileinput, _super);
    function KdInputFileinput(options) {
        if (options === void 0) { options = {}; }
        var _this = _super.call(this, options) || this;
        // let tempImgConfig: any = {
        //     type: 'student',
        //     isExpandable: false
        // }
        _this.config = options['config'];
        _this.config.maxFileSize = _this.config.maxFileSize ? _this.config.maxFileSize : 1000000;
        _this.config.errorMessage = _this.config.errorMessage ? _this.config.errorMessage : 'File size should not exceed 1MB';
        return _this;
        // this.leftToolbar = options['leftToolbar'] || false;
        // this.leftButton =
        // this.preview = options['preview'] || false;
        // this.fileType = options['fileType'] || '';
        // this.imageConfig = options['imageConfig'] || tempImgConfig;
        // this.infoText = options['infoText'] || [];
    }
    return KdInputFileinput;
}(InputBase));
export { KdInputFileinput };
var KdInputDropdown = /** @class */ (function (_super) {
    __extends(KdInputDropdown, _super);
    function KdInputDropdown(options) {
        if (options === void 0) { options = {}; }
        var _this = _super.call(this, options) || this;
        _this.options = [];
        _this.options = options['options'] || [];
        _this.events = options['events'] || false;
        if (typeof _this.value === 'undefined' && typeof _this.options !== 'undefined' && _this.options.length > 0) {
            _this.value = _this.options[0].key;
            for (var i = 0; i < _this.options.length; i++) {
                if (_this.options[i].key === '') {
                    _this.value = '';
                    break;
                }
            }
        }
        else
            _this.value = options['value'];
        return _this;
    }
    KdInputDropdown.prototype.setOptions = function (options) {
        this.value = '';
        this.options = options;
    };
    KdInputDropdown.prototype.getOptions = function () { return this.options; };
    return KdInputDropdown;
}(InputBase));
export { KdInputDropdown };
var KdInputRadio = /** @class */ (function (_super) {
    __extends(KdInputRadio, _super);
    function KdInputRadio(options) {
        if (options === void 0) { options = {}; }
        var _this = _super.call(this, options) || this;
        _this.list = [];
        _this.list = options['list'] || [];
        return _this;
    }
    return KdInputRadio;
}(InputBase));
export { KdInputRadio };
var KdInputCheckbox = /** @class */ (function (_super) {
    __extends(KdInputCheckbox, _super);
    function KdInputCheckbox(options) {
        if (options === void 0) { options = {}; }
        var _this = _super.call(this, options) || this;
        _this.list = [];
        _this.list = options['list'] || [];
        _this.value = (typeof _this.value !== 'undefined') ? _this.value : {};
        // checking whether the value contain any other redundent key value pair
        for (var item in _this.value) {
            if (!_this.value[item])
                delete _this.value[item];
            else {
                var toDelete = true;
                for (var i = 0; i < _this.list.length; i++) {
                    if (item === _this.list[i].value)
                        toDelete = false;
                }
                if (toDelete)
                    delete _this.value[item];
            }
        }
        return _this;
    }
    return KdInputCheckbox;
}(InputBase));
export { KdInputCheckbox };
var KdInputTreeDropdown = /** @class */ (function (_super) {
    __extends(KdInputTreeDropdown, _super);
    function KdInputTreeDropdown(options) {
        if (options === void 0) { options = {}; }
        var _this = _super.call(this, options) || this;
        _this.config = options['config'] || {};
        _this.api = options['api'] || {};
        return _this;
    }
    return KdInputTreeDropdown;
}(InputBase));
export { KdInputTreeDropdown };
var KdInputSlider = /** @class */ (function (_super) {
    __extends(KdInputSlider, _super);
    function KdInputSlider(options) {
        if (options === void 0) { options = {}; }
        var _this = _super.call(this, options) || this;
        _this.config = options['config'] || {};
        _this.api = options['api'] || {};
        return _this;
    }
    return KdInputSlider;
}(InputBase));
export { KdInputSlider };
var KdInputMultiSelectTable = /** @class */ (function (_super) {
    __extends(KdInputMultiSelectTable, _super);
    function KdInputMultiSelectTable(options) {
        if (options === void 0) { options = {}; }
        var _this = _super.call(this, options) || this;
        _this.config = options['config'] || {};
        _this.masterData = options['masterData'] || [];
        _this.slaveData = options['slaveData'] || [];
        return _this;
    }
    return KdInputMultiSelectTable;
}(InputBase));
export { KdInputMultiSelectTable };
var KdInputTable = /** @class */ (function (_super) {
    __extends(KdInputTable, _super);
    function KdInputTable(options) {
        if (options === void 0) { options = {}; }
        var _this = _super.call(this, options) || this;
        _this.config = options['config'];
        _this.row = options['row'];
        _this.column = options['column'];
        _this.api = options['api'] || {};
        return _this;
    }
    return KdInputTable;
}(InputBase));
export { KdInputTable };
var KdInputSymbol = /** @class */ (function (_super) {
    __extends(KdInputSymbol, _super);
    function KdInputSymbol() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    return KdInputSymbol;
}(InputBase));
export { KdInputSymbol };
var KdInputButtonGroup = /** @class */ (function (_super) {
    __extends(KdInputButtonGroup, _super);
    function KdInputButtonGroup(options) {
        if (options === void 0) { options = {}; }
        var _this = _super.call(this, options) || this;
        _this.list = [];
        _this.config = options['config'] || {};
        _this.list = options['list'] || [];
        if (_this.config.type === 'checkbox') {
            // checking whether the value contain any other redundent key value pair
            _this.value = (typeof _this.value !== 'undefined') ? _this.value : {};
            for (var item in _this.value) {
                if (!_this.value[item])
                    delete _this.value[item];
                else {
                    var toDelete = true;
                    for (var i = 0; i < _this.list.length; i++) {
                        if (item === _this.list[i].value)
                            toDelete = false;
                    }
                    if (toDelete)
                        delete _this.value[item];
                }
            }
        }
        return _this;
    }
    return KdInputButtonGroup;
}(InputBase));
export { KdInputButtonGroup };
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoia2QtaW5wdXQtZXh0ZW5zaW9ucy5qcyIsInNvdXJjZVJvb3QiOiJuZzovL29wZW5lbWlzLXN0eWxlZ3VpZGUtbGliLyIsInNvdXJjZXMiOlsia2QtY29tcG9uZW50cy9rZC1hbmd1bGFyLWlucHV0L3NyYy9rZC1pbnB1dC1leHRlbnNpb25zLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7QUFBQSxPQUFPLEVBQUUsU0FBUyxFQUFFLE1BQU0saUJBQWlCLENBQUM7QUFHNUM7SUFBb0Msa0NBQWlCO0lBQXJEOztJQUNBLENBQUM7SUFBRCxxQkFBQztBQUFELENBQUMsQUFERCxDQUFvQyxTQUFTLEdBQzVDOztBQUVEO0lBQWlDLCtCQUFpQjtJQVk5QyxxQkFBWSxPQUFnQjtRQUFoQix3QkFBQSxFQUFBLFlBQWdCO1FBQTVCLFlBQ0ksa0JBQU0sT0FBTyxDQUFDLFNBMkJqQjtRQTFCRyxLQUFJLENBQUMsSUFBSSxHQUFHLE9BQU8sQ0FBQyxNQUFNLENBQUMsSUFBSSxNQUFNLENBQUM7UUFDdEMsUUFBUSxLQUFJLENBQUMsSUFBSSxFQUFFO1lBQ2YsS0FBSyxjQUFjO2dCQUNmLEtBQUksQ0FBQyxZQUFZLEdBQUcsT0FBTyxDQUFDLGNBQWMsQ0FBQyxJQUFJLEtBQUssQ0FBQztnQkFDckQsS0FBSSxDQUFDLFdBQVcsR0FBRyxPQUFPLENBQUMsYUFBYSxDQUFDLElBQUksRUFBRSxDQUFDO2dCQUNoRCxLQUFJLENBQUMsbUJBQW1CLEdBQUcsT0FBTyxDQUFDLHFCQUFxQixDQUFDLElBQUksS0FBSyxDQUFDO2dCQUNuRSxLQUFJLENBQUMsT0FBTyxHQUFHLE9BQU8sQ0FBQyxTQUFTLENBQUMsSUFBSSxTQUFTLENBQUM7Z0JBQy9DLEtBQUksQ0FBQyxnQkFBZ0IsR0FBRyxPQUFPLENBQUMsa0JBQWtCLENBQUMsSUFBSSxTQUFTLENBQUM7Z0JBQ2pFLEtBQUksQ0FBQyxjQUFjLEdBQUcsT0FBTyxDQUFDLGdCQUFnQixDQUFDLElBQUksSUFBSSxDQUFDO2dCQUN4RCxLQUFJLENBQUMsT0FBTyxHQUFHLE9BQU8sQ0FBQyxTQUFTLENBQUMsSUFBSSxLQUFLLENBQUM7Z0JBQzNDLE1BQU07WUFDVixLQUFLLGFBQWE7Z0JBQ2QsS0FBSSxDQUFDLFdBQVcsR0FBRyxPQUFPLENBQUMsYUFBYSxDQUFDLElBQUksS0FBSyxDQUFDO2dCQUNuRCxLQUFJLENBQUMsV0FBVyxHQUFHLE9BQU8sQ0FBQyxhQUFhLENBQUMsSUFBSSxFQUFFLENBQUM7Z0JBQ2hELEtBQUksQ0FBQyxtQkFBbUIsR0FBRyxPQUFPLENBQUMscUJBQXFCLENBQUMsSUFBSSxLQUFLLENBQUM7Z0JBQ25FLEtBQUksQ0FBQyxPQUFPLEdBQUcsT0FBTyxDQUFDLFNBQVMsQ0FBQyxJQUFJLFNBQVMsQ0FBQztnQkFDL0MsS0FBSSxDQUFDLGdCQUFnQixHQUFHLE9BQU8sQ0FBQyxrQkFBa0IsQ0FBQyxJQUFJLFNBQVMsQ0FBQztnQkFDakUsS0FBSSxDQUFDLGNBQWMsR0FBRyxPQUFPLENBQUMsZ0JBQWdCLENBQUMsSUFBSSxJQUFJLENBQUM7Z0JBQ3hELEtBQUksQ0FBQyxPQUFPLEdBQUcsT0FBTyxDQUFDLFNBQVMsQ0FBQyxJQUFJLEtBQUssQ0FBQztnQkFDM0MsTUFBTTtZQUNWO2dCQUNJLEtBQUksQ0FBQyxLQUFLLEdBQUcsT0FBTyxDQUFDLE9BQU8sQ0FBQyxJQUFJLEVBQUUsQ0FBQztnQkFDcEMsS0FBSSxDQUFDLFdBQVcsR0FBRyxPQUFPLENBQUMsYUFBYSxDQUFDLElBQUksRUFBRSxDQUFDO2dCQUNoRCxLQUFJLENBQUMsU0FBUyxHQUFHLE9BQU8sQ0FBQyxXQUFXLENBQUMsSUFBSSxHQUFHLENBQUM7Z0JBQzdDLE1BQU07U0FDYjs7SUFDTCxDQUFDO0lBQ0wsa0JBQUM7QUFBRCxDQUFDLEFBekNELENBQWlDLFNBQVMsR0F5Q3pDOztBQUVEO0lBQW9DLGtDQUFpQjtJQUlqRCx3QkFBWSxPQUFnQjtRQUFoQix3QkFBQSxFQUFBLFlBQWdCO1FBQTVCLFlBQ0ksa0JBQU0sT0FBTyxDQUFDLFNBR2pCO1FBRkcsS0FBSSxDQUFDLEdBQUcsR0FBRyxPQUFPLENBQUMsS0FBSyxDQUFDLElBQUksU0FBUyxDQUFDO1FBQ3ZDLEtBQUksQ0FBQyxHQUFHLEdBQUcsT0FBTyxDQUFDLEtBQUssQ0FBQyxJQUFJLFNBQVMsQ0FBQzs7SUFDM0MsQ0FBQztJQUNMLHFCQUFDO0FBQUQsQ0FBQyxBQVRELENBQW9DLFNBQVMsR0FTNUM7O0FBRUQ7SUFBa0MsZ0NBQWlCO0lBSy9DLHNCQUFZLE9BQWdCO1FBQWhCLHdCQUFBLEVBQUEsWUFBZ0I7UUFBNUIsWUFDSSxrQkFBTSxPQUFPLENBQUMsU0FJakI7UUFIRyxLQUFJLENBQUMsR0FBRyxHQUFHLE9BQU8sQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLENBQUM7UUFDL0IsS0FBSSxDQUFDLEtBQUssR0FBRyxPQUFPLENBQUMsT0FBTyxDQUFDLElBQUksSUFBSSxDQUFDO1FBQ3RDLEtBQUksQ0FBQyxHQUFHLEdBQUcsT0FBTyxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsQ0FBQzs7SUFDbkMsQ0FBQztJQUNMLG1CQUFDO0FBQUQsQ0FBQyxBQVhELENBQWtDLFNBQVMsR0FXMUM7O0FBRUQ7SUFBaUMsK0JBQWlCO0lBSTlDLHFCQUFZLE9BQWdCO1FBQWhCLHdCQUFBLEVBQUEsWUFBZ0I7UUFBNUIsWUFDSSxrQkFBTSxPQUFPLENBQUMsU0FvQmpCO1FBbkJHLElBQUksVUFBVSxHQUFRO1lBQ2xCLGNBQWMsRUFBRSxDQUFDO1lBQ2pCLGFBQWE7WUFDYixrQkFBa0I7WUFDbEIseUJBQXlCO1lBQ3pCLHNCQUFzQjtZQUN0QixXQUFXO1lBQ1gsYUFBYTtZQUNiLGtCQUFrQjtZQUNsQixpQkFBaUI7WUFDakIsY0FBYztZQUNkLEtBQUs7WUFDTCxjQUFjLEVBQUUsSUFBSTtZQUNwQixlQUFlLEVBQUUsS0FBSztZQUN0QixZQUFZLEVBQUUsS0FBSztTQUN0QixDQUFDO1FBQ0YsS0FBSSxDQUFDLE1BQU0sR0FBRyxPQUFPLENBQUMsUUFBUSxDQUFDLElBQUksVUFBVSxDQUFDO1FBQzlDLEtBQUksQ0FBQyxPQUFPLEdBQUcsT0FBTyxDQUFDLFNBQVMsQ0FBQyxJQUFJLFNBQVMsQ0FBQztRQUMvQyxLQUFJLENBQUMsT0FBTyxHQUFHLE9BQU8sQ0FBQyxTQUFTLENBQUMsSUFBSSxTQUFTLENBQUM7O0lBQ25ELENBQUM7SUFDTCxrQkFBQztBQUFELENBQUMsQUExQkQsQ0FBaUMsU0FBUyxHQTBCekM7O0FBRUQ7SUFBaUMsK0JBQWlCO0lBRTlDLHFCQUFZLE9BQWdCO1FBQWhCLHdCQUFBLEVBQUEsWUFBZ0I7UUFBNUIsWUFDSSxrQkFBTSxPQUFPLENBQUMsU0FTakI7UUFSRyxJQUFJLFVBQVUsR0FBUTtZQUNsQixRQUFRLEVBQUUsS0FBSztZQUNmLFFBQVEsRUFBRSxJQUFJO1lBQ2QsY0FBYyxFQUFFLEtBQUs7WUFDckIsT0FBTyxFQUFFLEtBQUs7WUFDZCxRQUFRLEVBQUUsSUFBSTtTQUNqQixDQUFDO1FBQ0YsS0FBSSxDQUFDLE1BQU0sR0FBRyxPQUFPLENBQUMsUUFBUSxDQUFDLElBQUksVUFBVSxDQUFDOztJQUNsRCxDQUFDO0lBQ0wsa0JBQUM7QUFBRCxDQUFDLEFBYkQsQ0FBaUMsU0FBUyxHQWF6Qzs7QUFFRDtJQUFxQyxtQ0FBaUI7SUFFbEQseUJBQVksT0FBZ0I7UUFBaEIsd0JBQUEsRUFBQSxZQUFnQjtRQUE1QixZQUNJLGtCQUFNLE9BQU8sQ0FBQyxTQUdqQjtRQUxPLGNBQVEsR0FBVyxFQUFFLENBQUM7UUFHMUIsSUFBSSxPQUFPLE9BQU8sQ0FBQyxPQUFPLENBQUMsS0FBSyxXQUFXO1lBQUUsS0FBSSxDQUFDLFFBQVEsR0FBRyxhQUFhLENBQUM7O1lBQ3RFLEtBQUksQ0FBQyxRQUFRLEdBQUcsRUFBRSxDQUFDOztJQUM1QixDQUFDO0lBQ0wsc0JBQUM7QUFBRCxDQUFDLEFBUEQsQ0FBcUMsU0FBUyxHQU83Qzs7QUFFRDtJQUFxQyxtQ0FBaUI7SUFDbEQseUJBQVksT0FBZ0I7UUFBaEIsd0JBQUEsRUFBQSxZQUFnQjtRQUE1QixZQUNJLGtCQUFNLE9BQU8sQ0FBQyxTQUVqQjtRQURHLEtBQUksQ0FBQyxRQUFRLEdBQUcsT0FBTyxDQUFDLFVBQVUsQ0FBQyxJQUFJLEtBQUssQ0FBQzs7SUFDakQsQ0FBQztJQUNMLHNCQUFDO0FBQUQsQ0FBQyxBQUxELENBQXFDLFNBQVMsR0FLN0M7O0FBRUQ7SUFBbUMsaUNBQWlCO0lBQ2hELHVCQUFZLE9BQWdCO1FBQWhCLHdCQUFBLEVBQUEsWUFBZ0I7ZUFDeEIsa0JBQU0sT0FBTyxDQUFDO0lBQ2xCLENBQUM7SUFDTCxvQkFBQztBQUFELENBQUMsQUFKRCxDQUFtQyxTQUFTLEdBSTNDOztBQUVELDJEQUEyRDtBQUMzRCx5Q0FBeUM7QUFDekMsb0NBQW9DO0FBQ3BDLHNCQUFzQjtBQUN0QixNQUFNO0FBQ04sSUFBSTtBQUVKLDJEQUEyRDtBQUMzRCx5Q0FBeUM7QUFDekMsb0NBQW9DO0FBQ3BDLHNCQUFzQjtBQUN0QixNQUFNO0FBQ04sSUFBSTtBQUVKO0lBQXNDLG9DQUFpQjtJQVluRCwwQkFBWSxPQUFnQjtRQUFoQix3QkFBQSxFQUFBLFlBQWdCO1FBQTVCLFlBQ0ksa0JBQU0sT0FBTyxDQUFDLFNBY2pCO1FBYkcsNkJBQTZCO1FBQzdCLHVCQUF1QjtRQUN2QiwwQkFBMEI7UUFDMUIsSUFBSTtRQUNKLEtBQUksQ0FBQyxNQUFNLEdBQUcsT0FBTyxDQUFDLFFBQVEsQ0FBQyxDQUFDO1FBQ2hDLEtBQUksQ0FBQyxNQUFNLENBQUMsV0FBVyxHQUFHLEtBQUksQ0FBQyxNQUFNLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQyxLQUFJLENBQUMsTUFBTSxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDO1FBQ3RGLEtBQUksQ0FBQyxNQUFNLENBQUMsWUFBWSxHQUFHLEtBQUksQ0FBQyxNQUFNLENBQUMsWUFBWSxDQUFDLENBQUMsQ0FBQyxLQUFJLENBQUMsTUFBTSxDQUFDLFlBQVksQ0FBQyxDQUFDLENBQUMsaUNBQWlDLENBQUM7O1FBQ25ILHNEQUFzRDtRQUN0RCxvQkFBb0I7UUFDcEIsOENBQThDO1FBQzlDLDZDQUE2QztRQUM3Qyw4REFBOEQ7UUFDOUQsNkNBQTZDO0lBQ2pELENBQUM7SUFDTCx1QkFBQztBQUFELENBQUMsQUE1QkQsQ0FBc0MsU0FBUyxHQTRCOUM7O0FBRUQ7SUFBcUMsbUNBQWlCO0lBSWxELHlCQUFZLE9BQWdCO1FBQWhCLHdCQUFBLEVBQUEsWUFBZ0I7UUFBNUIsWUFDSSxrQkFBTSxPQUFPLENBQUMsU0FlakI7UUFuQk8sYUFBTyxHQUFxQyxFQUFFLENBQUM7UUFLbkQsS0FBSSxDQUFDLE9BQU8sR0FBRyxPQUFPLENBQUMsU0FBUyxDQUFDLElBQUksRUFBRSxDQUFDO1FBQ3hDLEtBQUksQ0FBQyxNQUFNLEdBQUcsT0FBTyxDQUFDLFFBQVEsQ0FBQyxJQUFJLEtBQUssQ0FBQztRQUd6QyxJQUFJLE9BQU8sS0FBSSxDQUFDLEtBQUssS0FBSyxXQUFXLElBQUksT0FBTyxLQUFJLENBQUMsT0FBTyxLQUFLLFdBQVcsSUFBSSxLQUFJLENBQUMsT0FBTyxDQUFDLE1BQU0sR0FBRyxDQUFDLEVBQUU7WUFDckcsS0FBSSxDQUFDLEtBQUssR0FBRyxLQUFJLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQztZQUNqQyxLQUFLLElBQUksQ0FBQyxHQUFXLENBQUMsRUFBRSxDQUFDLEdBQUcsS0FBSSxDQUFDLE9BQU8sQ0FBQyxNQUFNLEVBQUUsQ0FBQyxFQUFFLEVBQUU7Z0JBQ2xELElBQUksS0FBSSxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLEtBQUssRUFBRSxFQUFFO29CQUM1QixLQUFJLENBQUMsS0FBSyxHQUFHLEVBQUUsQ0FBQztvQkFDaEIsTUFBTTtpQkFDVDthQUNKO1NBQ0o7O1lBQ0ksS0FBSSxDQUFDLEtBQUssR0FBRyxPQUFPLENBQUMsT0FBTyxDQUFDLENBQUM7O0lBQ3ZDLENBQUM7SUFDTSxvQ0FBVSxHQUFqQixVQUFrQixPQUF5QztRQUN2RCxJQUFJLENBQUMsS0FBSyxHQUFHLEVBQUUsQ0FBQztRQUNoQixJQUFJLENBQUMsT0FBTyxHQUFHLE9BQU8sQ0FBQztJQUMzQixDQUFDO0lBQ00sb0NBQVUsR0FBakIsY0FBd0QsT0FBTyxJQUFJLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQztJQUNsRixzQkFBQztBQUFELENBQUMsQUExQkQsQ0FBcUMsU0FBUyxHQTBCN0M7O0FBRUQ7SUFBa0MsZ0NBQWlCO0lBRS9DLHNCQUFZLE9BQWdCO1FBQWhCLHdCQUFBLEVBQUEsWUFBZ0I7UUFBNUIsWUFDSSxrQkFBTSxPQUFPLENBQUMsU0FFakI7UUFKTyxVQUFJLEdBQW9ELEVBQUUsQ0FBQztRQUcvRCxLQUFJLENBQUMsSUFBSSxHQUFHLE9BQU8sQ0FBQyxNQUFNLENBQUMsSUFBSSxFQUFFLENBQUM7O0lBQ3RDLENBQUM7SUFDTCxtQkFBQztBQUFELENBQUMsQUFORCxDQUFrQyxTQUFTLEdBTTFDOztBQUVEO0lBQXFDLG1DQUFjO0lBRS9DLHlCQUFZLE9BQWdCO1FBQWhCLHdCQUFBLEVBQUEsWUFBZ0I7UUFBNUIsWUFDSSxrQkFBTSxPQUFPLENBQUMsU0FlakI7UUFqQk8sVUFBSSxHQUF3RCxFQUFFLENBQUM7UUFHbkUsS0FBSSxDQUFDLElBQUksR0FBRyxPQUFPLENBQUMsTUFBTSxDQUFDLElBQUksRUFBRSxDQUFDO1FBQ2xDLEtBQUksQ0FBQyxLQUFLLEdBQUcsQ0FBQyxPQUFPLEtBQUksQ0FBQyxLQUFLLEtBQUssV0FBVyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQztRQUVuRSx3RUFBd0U7UUFDeEUsS0FBSyxJQUFJLElBQUksSUFBSSxLQUFJLENBQUMsS0FBSyxFQUFFO1lBQ3pCLElBQUksQ0FBQyxLQUFJLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQztnQkFBRSxPQUFPLEtBQUksQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLENBQUM7aUJBQzFDO2dCQUNELElBQUksUUFBUSxHQUFZLElBQUksQ0FBQztnQkFDN0IsS0FBSyxJQUFJLENBQUMsR0FBVyxDQUFDLEVBQUUsQ0FBQyxHQUFHLEtBQUksQ0FBQyxJQUFJLENBQUMsTUFBTSxFQUFFLENBQUMsRUFBRSxFQUFFO29CQUMvQyxJQUFJLElBQUksS0FBSyxLQUFJLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUs7d0JBQUUsUUFBUSxHQUFHLEtBQUssQ0FBQztpQkFDckQ7Z0JBQ0QsSUFBSSxRQUFRO29CQUFFLE9BQU8sS0FBSSxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsQ0FBQzthQUN6QztTQUNKOztJQUNMLENBQUM7SUFDTCxzQkFBQztBQUFELENBQUMsQUFuQkQsQ0FBcUMsU0FBUyxHQW1CN0M7O0FBRUQ7SUFBeUMsdUNBQWlCO0lBR3RELDZCQUFZLE9BQWdCO1FBQWhCLHdCQUFBLEVBQUEsWUFBZ0I7UUFBNUIsWUFDSSxrQkFBTSxPQUFPLENBQUMsU0FHakI7UUFGRyxLQUFJLENBQUMsTUFBTSxHQUFHLE9BQU8sQ0FBQyxRQUFRLENBQUMsSUFBSSxFQUFFLENBQUM7UUFDdEMsS0FBSSxDQUFDLEdBQUcsR0FBRyxPQUFPLENBQUMsS0FBSyxDQUFDLElBQUksRUFBRSxDQUFDOztJQUNwQyxDQUFDO0lBQ0wsMEJBQUM7QUFBRCxDQUFDLEFBUkQsQ0FBeUMsU0FBUyxHQVFqRDs7QUFFRDtJQUFtQyxpQ0FBaUI7SUFHaEQsdUJBQVksT0FBZ0I7UUFBaEIsd0JBQUEsRUFBQSxZQUFnQjtRQUE1QixZQUNJLGtCQUFNLE9BQU8sQ0FBQyxTQUdqQjtRQUZHLEtBQUksQ0FBQyxNQUFNLEdBQUcsT0FBTyxDQUFDLFFBQVEsQ0FBQyxJQUFJLEVBQUUsQ0FBQztRQUN0QyxLQUFJLENBQUMsR0FBRyxHQUFHLE9BQU8sQ0FBQyxLQUFLLENBQUMsSUFBSSxFQUFFLENBQUM7O0lBQ3BDLENBQUM7SUFDTCxvQkFBQztBQUFELENBQUMsQUFSRCxDQUFtQyxTQUFTLEdBUTNDOztBQUVEO0lBQTZDLDJDQUFpQjtJQUkxRCxpQ0FBWSxPQUFnQjtRQUFoQix3QkFBQSxFQUFBLFlBQWdCO1FBQTVCLFlBQ0ksa0JBQU0sT0FBTyxDQUFDLFNBSWpCO1FBSEcsS0FBSSxDQUFDLE1BQU0sR0FBRyxPQUFPLENBQUMsUUFBUSxDQUFDLElBQUksRUFBRSxDQUFDO1FBQ3RDLEtBQUksQ0FBQyxVQUFVLEdBQUcsT0FBTyxDQUFDLFlBQVksQ0FBQyxJQUFJLEVBQUUsQ0FBQztRQUM5QyxLQUFJLENBQUMsU0FBUyxHQUFHLE9BQU8sQ0FBQyxXQUFXLENBQUMsSUFBSSxFQUFFLENBQUM7O0lBQ2hELENBQUM7SUFDTCw4QkFBQztBQUFELENBQUMsQUFWRCxDQUE2QyxTQUFTLEdBVXJEOztBQUVEO0lBQWtDLGdDQUFpQjtJQU0vQyxzQkFBWSxPQUFnQjtRQUFoQix3QkFBQSxFQUFBLFlBQWdCO1FBQTVCLFlBQ0ksa0JBQU0sT0FBTyxDQUFDLFNBS2pCO1FBSkcsS0FBSSxDQUFDLE1BQU0sR0FBRyxPQUFPLENBQUMsUUFBUSxDQUFDLENBQUM7UUFDaEMsS0FBSSxDQUFDLEdBQUcsR0FBRyxPQUFPLENBQUMsS0FBSyxDQUFDLENBQUM7UUFDMUIsS0FBSSxDQUFDLE1BQU0sR0FBRyxPQUFPLENBQUMsUUFBUSxDQUFDLENBQUM7UUFDaEMsS0FBSSxDQUFDLEdBQUcsR0FBRyxPQUFPLENBQUMsS0FBSyxDQUFDLElBQUksRUFBRSxDQUFDOztJQUNwQyxDQUFDO0lBQ0wsbUJBQUM7QUFBRCxDQUFDLEFBYkQsQ0FBa0MsU0FBUyxHQWExQzs7QUFFRDtJQUFtQyxpQ0FBaUI7SUFBcEQ7O0lBQ0EsQ0FBQztJQUFELG9CQUFDO0FBQUQsQ0FBQyxBQURELENBQW1DLFNBQVMsR0FDM0M7O0FBRUQ7SUFBd0Msc0NBQWM7SUFJbEQsNEJBQVksT0FBZ0I7UUFBaEIsd0JBQUEsRUFBQSxZQUFnQjtRQUE1QixZQUNJLGtCQUFNLE9BQU8sQ0FBQyxTQWtCakI7UUFyQk8sVUFBSSxHQUFxQyxFQUFFLENBQUM7UUFJaEQsS0FBSSxDQUFDLE1BQU0sR0FBRyxPQUFPLENBQUMsUUFBUSxDQUFDLElBQUksRUFBRSxDQUFDO1FBQ3RDLEtBQUksQ0FBQyxJQUFJLEdBQUcsT0FBTyxDQUFDLE1BQU0sQ0FBQyxJQUFJLEVBQUUsQ0FBQztRQUVsQyxJQUFJLEtBQUksQ0FBQyxNQUFNLENBQUMsSUFBSSxLQUFLLFVBQVUsRUFBRTtZQUNqQyx3RUFBd0U7WUFDeEUsS0FBSSxDQUFDLEtBQUssR0FBRyxDQUFDLE9BQU8sS0FBSSxDQUFDLEtBQUssS0FBSyxXQUFXLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSSxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDO1lBQ25FLEtBQUssSUFBSSxJQUFJLElBQUksS0FBSSxDQUFDLEtBQUssRUFBRTtnQkFDekIsSUFBSSxDQUFDLEtBQUksQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDO29CQUFFLE9BQU8sS0FBSSxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsQ0FBQztxQkFDMUM7b0JBQ0QsSUFBSSxRQUFRLEdBQVksSUFBSSxDQUFDO29CQUM3QixLQUFLLElBQUksQ0FBQyxHQUFXLENBQUMsRUFBRSxDQUFDLEdBQUcsS0FBSSxDQUFDLElBQUksQ0FBQyxNQUFNLEVBQUUsQ0FBQyxFQUFFLEVBQUU7d0JBQy9DLElBQUksSUFBSSxLQUFLLEtBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSzs0QkFBRSxRQUFRLEdBQUcsS0FBSyxDQUFDO3FCQUNyRDtvQkFDRCxJQUFJLFFBQVE7d0JBQUUsT0FBTyxLQUFJLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxDQUFDO2lCQUN6QzthQUNKO1NBQ0o7O0lBQ0wsQ0FBQztJQUNMLHlCQUFDO0FBQUQsQ0FBQyxBQXhCRCxDQUF3QyxTQUFTLEdBd0JoRCIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IElucHV0QmFzZSB9IGZyb20gJy4va2QtaW5wdXQtYmFzZSc7XHJcbmltcG9ydCB7IElUcmVlQXBpIH0gZnJvbSAnLi4vLi4va2QtYW5ndWxhci10cmVlZHJvcGRvd24vaW5kZXgnO1xyXG5cclxuZXhwb3J0IGNsYXNzIEtkSW5wdXRTZWN0aW9uIGV4dGVuZHMgSW5wdXRCYXNlPHN0cmluZz4ge1xyXG59XHJcblxyXG5leHBvcnQgY2xhc3MgS2RJbnB1dFRleHQgZXh0ZW5kcyBJbnB1dEJhc2U8c3RyaW5nPiB7XHJcbiAgICBwcml2YXRlIG11bHRpc2VsZWN0OiBib29sZWFuO1xyXG4gICAgcHJpdmF0ZSBhdXRvY29tcGxldGU6IGJvb2xlYW47XHJcbiAgICBwcml2YXRlIHBsYWNlaG9sZGVyOiBzdHJpbmc7XHJcbiAgICBwcml2YXRlIGNsaWNrVG9nZ2xlRHJvcGRvd246IGJvb2xlYW47XHJcbiAgICBwcml2YXRlIG9wdGlvbnM6IEFycmF5PGFueT47XHJcbiAgICBwcml2YXRlIGRyb3Bkb3duQ2FsbGJhY2s6IEZ1bmN0aW9uO1xyXG4gICAgcHJpdmF0ZSBsZW5ndGhUb1NlYXJjaDogbnVtYmVyO1xyXG4gICAgcHJpdmF0ZSB0eXBlOiBzdHJpbmc7XHJcbiAgICBwcml2YXRlIG9uRW50ZXI6IGJvb2xlYW47XHJcbiAgICBwcml2YXRlIG1heExlbmd0aDogbnVtYmVyO1xyXG5cclxuICAgIGNvbnN0cnVjdG9yKG9wdGlvbnM6IHt9ID0ge30pIHtcclxuICAgICAgICBzdXBlcihvcHRpb25zKTtcclxuICAgICAgICB0aGlzLnR5cGUgPSBvcHRpb25zWyd0eXBlJ10gfHwgJ3RleHQnO1xyXG4gICAgICAgIHN3aXRjaCAodGhpcy50eXBlKSB7XHJcbiAgICAgICAgICAgIGNhc2UgJ2F1dG9jb21wbGV0ZSc6XHJcbiAgICAgICAgICAgICAgICB0aGlzLmF1dG9jb21wbGV0ZSA9IG9wdGlvbnNbJ2F1dG9jb21wbGV0ZSddIHx8IGZhbHNlO1xyXG4gICAgICAgICAgICAgICAgdGhpcy5wbGFjZWhvbGRlciA9IG9wdGlvbnNbJ3BsYWNlaG9sZGVyJ10gfHwgJyc7XHJcbiAgICAgICAgICAgICAgICB0aGlzLmNsaWNrVG9nZ2xlRHJvcGRvd24gPSBvcHRpb25zWydjbGlja1RvZ2dsZURyb3Bkb3duJ10gfHwgZmFsc2U7XHJcbiAgICAgICAgICAgICAgICB0aGlzLm9wdGlvbnMgPSBvcHRpb25zWydvcHRpb25zJ10gfHwgdW5kZWZpbmVkO1xyXG4gICAgICAgICAgICAgICAgdGhpcy5kcm9wZG93bkNhbGxiYWNrID0gb3B0aW9uc1snZHJvcGRvd25DYWxsYmFjayddIHx8IHVuZGVmaW5lZDtcclxuICAgICAgICAgICAgICAgIHRoaXMubGVuZ3RoVG9TZWFyY2ggPSBvcHRpb25zWydsZW5ndGhUb1NlYXJjaCddIHx8IG51bGw7XHJcbiAgICAgICAgICAgICAgICB0aGlzLm9uRW50ZXIgPSBvcHRpb25zWydvbkVudGVyJ10gfHwgZmFsc2U7XHJcbiAgICAgICAgICAgICAgICBicmVhaztcclxuICAgICAgICAgICAgY2FzZSAnbXVsdGlzZWxlY3QnOlxyXG4gICAgICAgICAgICAgICAgdGhpcy5tdWx0aXNlbGVjdCA9IG9wdGlvbnNbJ211bHRpc2VsZWN0J10gfHwgZmFsc2U7XHJcbiAgICAgICAgICAgICAgICB0aGlzLnBsYWNlaG9sZGVyID0gb3B0aW9uc1sncGxhY2Vob2xkZXInXSB8fCAnJztcclxuICAgICAgICAgICAgICAgIHRoaXMuY2xpY2tUb2dnbGVEcm9wZG93biA9IG9wdGlvbnNbJ2NsaWNrVG9nZ2xlRHJvcGRvd24nXSB8fCBmYWxzZTtcclxuICAgICAgICAgICAgICAgIHRoaXMub3B0aW9ucyA9IG9wdGlvbnNbJ29wdGlvbnMnXSB8fCB1bmRlZmluZWQ7XHJcbiAgICAgICAgICAgICAgICB0aGlzLmRyb3Bkb3duQ2FsbGJhY2sgPSBvcHRpb25zWydkcm9wZG93bkNhbGxiYWNrJ10gfHwgdW5kZWZpbmVkO1xyXG4gICAgICAgICAgICAgICAgdGhpcy5sZW5ndGhUb1NlYXJjaCA9IG9wdGlvbnNbJ2xlbmd0aFRvU2VhcmNoJ10gfHwgbnVsbDtcclxuICAgICAgICAgICAgICAgIHRoaXMub25FbnRlciA9IG9wdGlvbnNbJ29uRW50ZXInXSB8fCBmYWxzZTtcclxuICAgICAgICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgICAgICBkZWZhdWx0OlxyXG4gICAgICAgICAgICAgICAgdGhpcy52YWx1ZSA9IG9wdGlvbnNbJ3ZhbHVlJ10gfHwgJyc7XHJcbiAgICAgICAgICAgICAgICB0aGlzLnBsYWNlaG9sZGVyID0gb3B0aW9uc1sncGxhY2Vob2xkZXInXSB8fCAnJztcclxuICAgICAgICAgICAgICAgIHRoaXMubWF4TGVuZ3RoID0gb3B0aW9uc1snbWF4bGVuZ3RoJ10gfHwgMjUwO1xyXG4gICAgICAgICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG59XHJcblxyXG5leHBvcnQgY2xhc3MgS2RJbnB1dEludGVnZXIgZXh0ZW5kcyBJbnB1dEJhc2U8bnVtYmVyPiB7XHJcbiAgICBwcml2YXRlIG1pbjogbnVtYmVyO1xyXG4gICAgcHJpdmF0ZSBtYXg6IG51bWJlcjtcclxuXHJcbiAgICBjb25zdHJ1Y3RvcihvcHRpb25zOiB7fSA9IHt9KSB7XHJcbiAgICAgICAgc3VwZXIob3B0aW9ucyk7XHJcbiAgICAgICAgdGhpcy5taW4gPSBvcHRpb25zWydtaW4nXSB8fCB1bmRlZmluZWQ7XHJcbiAgICAgICAgdGhpcy5tYXggPSBvcHRpb25zWydtYXgnXSB8fCB1bmRlZmluZWQ7XHJcbiAgICB9XHJcbn1cclxuXHJcbmV4cG9ydCBjbGFzcyBLZElucHV0RmxvYXQgZXh0ZW5kcyBJbnB1dEJhc2U8c3RyaW5nPiB7XHJcbiAgICBwcml2YXRlIGZsb2F0OiBudW1iZXI7XHJcbiAgICBwcml2YXRlIG1heDogbnVtYmVyO1xyXG4gICAgcHJpdmF0ZSBtaW46IG51bWJlcjtcclxuXHJcbiAgICBjb25zdHJ1Y3RvcihvcHRpb25zOiB7fSA9IHt9KSB7XHJcbiAgICAgICAgc3VwZXIob3B0aW9ucyk7XHJcbiAgICAgICAgdGhpcy5tYXggPSBvcHRpb25zWydtYXgnXSB8fCAxO1xyXG4gICAgICAgIHRoaXMuZmxvYXQgPSBvcHRpb25zWydmbG9hdCddIHx8IDAuMDE7XHJcbiAgICAgICAgdGhpcy5taW4gPSBvcHRpb25zWydtaW4nXSB8fCAwO1xyXG4gICAgfVxyXG59XHJcblxyXG5leHBvcnQgY2xhc3MgS2RJbnB1dERhdGUgZXh0ZW5kcyBJbnB1dEJhc2U8c3RyaW5nPiB7XHJcbiAgICBwcml2YXRlIGNvbmZpZzogYW55O1xyXG4gICAgcHJpdmF0ZSBtaW5EYXRlOiBhbnk7XHJcbiAgICBwcml2YXRlIG1heERhdGU6IGFueTtcclxuICAgIGNvbnN0cnVjdG9yKG9wdGlvbnM6IHt9ID0ge30pIHtcclxuICAgICAgICBzdXBlcihvcHRpb25zKTtcclxuICAgICAgICBsZXQgdGVtcENvbmZpZzogYW55ID0ge1xyXG4gICAgICAgICAgICBmaXJzdERheU9mV2VlazogMSxcclxuICAgICAgICAgICAgLy8gbWluRGF0ZToge1xyXG4gICAgICAgICAgICAvLyAgICAgeWVhcjogMjAwMCxcclxuICAgICAgICAgICAgLy8gICAgICAgICAgICAgIG1vbnRoOiAwLFxyXG4gICAgICAgICAgICAvLyAgICAgICAgICAgICAgZGF5OiA1XHJcbiAgICAgICAgICAgIC8vICAgICAgIH0sXHJcbiAgICAgICAgICAgIC8vIG1heERhdGU6IHtcclxuICAgICAgICAgICAgLy8gICAgIHllYXI6IDIwMTYsXHJcbiAgICAgICAgICAgIC8vICAgICBtb250aDogMTIsXHJcbiAgICAgICAgICAgIC8vICAgICBkYXk6IDIwXHJcbiAgICAgICAgICAgIC8vIH0sXHJcbiAgICAgICAgICAgIHNob3dOYXZpZ2F0aW9uOiB0cnVlLFxyXG4gICAgICAgICAgICBzaG93V2Vla051bWJlcnM6IGZhbHNlLFxyXG4gICAgICAgICAgICBzaG93V2Vla2RheXM6IGZhbHNlXHJcbiAgICAgICAgfTtcclxuICAgICAgICB0aGlzLmNvbmZpZyA9IG9wdGlvbnNbJ2NvbmZpZyddIHx8IHRlbXBDb25maWc7XHJcbiAgICAgICAgdGhpcy5taW5EYXRlID0gb3B0aW9uc1snbWluRGF0ZSddIHx8IHVuZGVmaW5lZDtcclxuICAgICAgICB0aGlzLm1heERhdGUgPSBvcHRpb25zWydtYXhEYXRlJ10gfHwgdW5kZWZpbmVkO1xyXG4gICAgfVxyXG59XHJcblxyXG5leHBvcnQgY2xhc3MgS2RJbnB1dFRpbWUgZXh0ZW5kcyBJbnB1dEJhc2U8c3RyaW5nPiB7XHJcbiAgICBwcml2YXRlIGNvbmZpZzogYW55O1xyXG4gICAgY29uc3RydWN0b3Iob3B0aW9uczoge30gPSB7fSkge1xyXG4gICAgICAgIHN1cGVyKG9wdGlvbnMpO1xyXG4gICAgICAgIGxldCB0ZW1wQ29uZmlnOiBhbnkgPSB7XHJcbiAgICAgICAgICAgIGRpc2FibGVkOiBmYWxzZSxcclxuICAgICAgICAgICAgbWVyaWRpYW46IHRydWUsXHJcbiAgICAgICAgICAgIHJlYWRvbmx5SW5wdXRzOiBmYWxzZSxcclxuICAgICAgICAgICAgc2Vjb25kczogZmFsc2UsXHJcbiAgICAgICAgICAgIHNwaW5uZXJzOiB0cnVlXHJcbiAgICAgICAgfTtcclxuICAgICAgICB0aGlzLmNvbmZpZyA9IG9wdGlvbnNbJ2NvbmZpZyddIHx8IHRlbXBDb25maWc7XHJcbiAgICB9XHJcbn1cclxuXHJcbmV4cG9ydCBjbGFzcyBLZElucHV0UGFzc3dvcmQgZXh0ZW5kcyBJbnB1dEJhc2U8c3RyaW5nPiB7XHJcbiAgICBwcml2YXRlIHBhc3N3b3JkOiBzdHJpbmcgPSAnJztcclxuICAgIGNvbnN0cnVjdG9yKG9wdGlvbnM6IHt9ID0ge30pIHtcclxuICAgICAgICBzdXBlcihvcHRpb25zKTtcclxuICAgICAgICBpZiAodHlwZW9mIG9wdGlvbnNbJ3ZhbHVlJ10gIT09ICd1bmRlZmluZWQnKSB0aGlzLnBhc3N3b3JkID0gJyoqKioqKioqKioqJztcclxuICAgICAgICBlbHNlIHRoaXMucGFzc3dvcmQgPSAnJztcclxuICAgIH1cclxufVxyXG5cclxuZXhwb3J0IGNsYXNzIEtkSW5wdXRUZXh0YXJlYSBleHRlbmRzIElucHV0QmFzZTxzdHJpbmc+IHtcclxuICAgIGNvbnN0cnVjdG9yKG9wdGlvbnM6IHt9ID0ge30pIHtcclxuICAgICAgICBzdXBlcihvcHRpb25zKTtcclxuICAgICAgICB0aGlzLmRpc2FibGVkID0gb3B0aW9uc1snZGlzYWJsZWQnXSB8fCBmYWxzZTtcclxuICAgIH1cclxufVxyXG5cclxuZXhwb3J0IGNsYXNzIEtkSW5wdXRIaWRkZW4gZXh0ZW5kcyBJbnB1dEJhc2U8c3RyaW5nPiB7XHJcbiAgICBjb25zdHJ1Y3RvcihvcHRpb25zOiB7fSA9IHt9KSB7XHJcbiAgICAgICAgc3VwZXIob3B0aW9ucyk7XHJcbiAgICB9XHJcbn1cclxuXHJcbi8vIGV4cG9ydCBjbGFzcyBLZElucHV0RGlzYWJsZWQgZXh0ZW5kcyBJbnB1dEJhc2U8c3RyaW5nPiB7XHJcbi8vICAgLy8gcHJpdmF0ZSBkaXNhYmxlZDogYm9vbGVhbiA9IHRydWU7XHJcbi8vICAgY29uc3RydWN0b3Iob3B0aW9uczoge30gPSB7fSkge1xyXG4vLyAgICAgc3VwZXIob3B0aW9ucyk7XHJcbi8vICAgfVxyXG4vLyB9XHJcblxyXG4vLyBleHBvcnQgY2xhc3MgS2RJbnB1dFJlYWRPbmx5IGV4dGVuZHMgSW5wdXRCYXNlPHN0cmluZz4ge1xyXG4vLyAgIC8vIHByaXZhdGUgcmVhZE9ubHk6IGJvb2xlYW4gPSB0cnVlO1xyXG4vLyAgIGNvbnN0cnVjdG9yKG9wdGlvbnM6IHt9ID0ge30pIHtcclxuLy8gICAgIHN1cGVyKG9wdGlvbnMpO1xyXG4vLyAgIH1cclxuLy8gfVxyXG5cclxuZXhwb3J0IGNsYXNzIEtkSW5wdXRGaWxlaW5wdXQgZXh0ZW5kcyBJbnB1dEJhc2U8c3RyaW5nPiB7XHJcbiAgICBwcml2YXRlIGNvbmZpZzoge1xyXG4gICAgICAgIHByZXZpZXc6IGJvb2xlYW4sXHJcbiAgICAgICAgbGVmdFRvb2xiYXI6IGJvb2xlYW4sXHJcbiAgICAgICAgbGVmdEJ1dHRvbjogQXJyYXk8YW55PixcclxuICAgICAgICBmaWxlVHlwZTogc3RyaW5nLFxyXG4gICAgICAgIGltYWdlQ29uZmlnOiBhbnksXHJcbiAgICAgICAgaW5mb1RleHQ6IEFycmF5PGFueT4sXHJcbiAgICAgICAgbWF4RmlsZVNpemU6IG51bWJlcixcclxuICAgICAgICBlcnJvck1lc3NhZ2U6IHN0cmluZ1xyXG4gICAgfTtcclxuXHJcbiAgICBjb25zdHJ1Y3RvcihvcHRpb25zOiB7fSA9IHt9KSB7XHJcbiAgICAgICAgc3VwZXIob3B0aW9ucyk7XHJcbiAgICAgICAgLy8gbGV0IHRlbXBJbWdDb25maWc6IGFueSA9IHtcclxuICAgICAgICAvLyAgICAgdHlwZTogJ3N0dWRlbnQnLFxyXG4gICAgICAgIC8vICAgICBpc0V4cGFuZGFibGU6IGZhbHNlXHJcbiAgICAgICAgLy8gfVxyXG4gICAgICAgIHRoaXMuY29uZmlnID0gb3B0aW9uc1snY29uZmlnJ107XHJcbiAgICAgICAgdGhpcy5jb25maWcubWF4RmlsZVNpemUgPSB0aGlzLmNvbmZpZy5tYXhGaWxlU2l6ZSA/IHRoaXMuY29uZmlnLm1heEZpbGVTaXplIDogMTAwMDAwMDtcclxuICAgICAgICB0aGlzLmNvbmZpZy5lcnJvck1lc3NhZ2UgPSB0aGlzLmNvbmZpZy5lcnJvck1lc3NhZ2UgPyB0aGlzLmNvbmZpZy5lcnJvck1lc3NhZ2UgOiAnRmlsZSBzaXplIHNob3VsZCBub3QgZXhjZWVkIDFNQic7XHJcbiAgICAgICAgLy8gdGhpcy5sZWZ0VG9vbGJhciA9IG9wdGlvbnNbJ2xlZnRUb29sYmFyJ10gfHwgZmFsc2U7XHJcbiAgICAgICAgLy8gdGhpcy5sZWZ0QnV0dG9uID1cclxuICAgICAgICAvLyB0aGlzLnByZXZpZXcgPSBvcHRpb25zWydwcmV2aWV3J10gfHwgZmFsc2U7XHJcbiAgICAgICAgLy8gdGhpcy5maWxlVHlwZSA9IG9wdGlvbnNbJ2ZpbGVUeXBlJ10gfHwgJyc7XHJcbiAgICAgICAgLy8gdGhpcy5pbWFnZUNvbmZpZyA9IG9wdGlvbnNbJ2ltYWdlQ29uZmlnJ10gfHwgdGVtcEltZ0NvbmZpZztcclxuICAgICAgICAvLyB0aGlzLmluZm9UZXh0ID0gb3B0aW9uc1snaW5mb1RleHQnXSB8fCBbXTtcclxuICAgIH1cclxufVxyXG5cclxuZXhwb3J0IGNsYXNzIEtkSW5wdXREcm9wZG93biBleHRlbmRzIElucHV0QmFzZTxzdHJpbmc+IHtcclxuICAgIHByaXZhdGUgb3B0aW9uczogeyBrZXk6IHN0cmluZywgdmFsdWU6IHN0cmluZyB9W10gPSBbXTtcclxuICAgIHByaXZhdGUgZXZlbnRzOiBib29sZWFuO1xyXG5cclxuICAgIGNvbnN0cnVjdG9yKG9wdGlvbnM6IHt9ID0ge30pIHtcclxuICAgICAgICBzdXBlcihvcHRpb25zKTtcclxuICAgICAgICB0aGlzLm9wdGlvbnMgPSBvcHRpb25zWydvcHRpb25zJ10gfHwgW107XHJcbiAgICAgICAgdGhpcy5ldmVudHMgPSBvcHRpb25zWydldmVudHMnXSB8fCBmYWxzZTtcclxuXHJcblxyXG4gICAgICAgIGlmICh0eXBlb2YgdGhpcy52YWx1ZSA9PT0gJ3VuZGVmaW5lZCcgJiYgdHlwZW9mIHRoaXMub3B0aW9ucyAhPT0gJ3VuZGVmaW5lZCcgJiYgdGhpcy5vcHRpb25zLmxlbmd0aCA+IDApIHtcclxuICAgICAgICAgICAgdGhpcy52YWx1ZSA9IHRoaXMub3B0aW9uc1swXS5rZXk7XHJcbiAgICAgICAgICAgIGZvciAobGV0IGk6IG51bWJlciA9IDA7IGkgPCB0aGlzLm9wdGlvbnMubGVuZ3RoOyBpKyspIHtcclxuICAgICAgICAgICAgICAgIGlmICh0aGlzLm9wdGlvbnNbaV0ua2V5ID09PSAnJykge1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMudmFsdWUgPSAnJztcclxuICAgICAgICAgICAgICAgICAgICBicmVhaztcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgICAgICBlbHNlIHRoaXMudmFsdWUgPSBvcHRpb25zWyd2YWx1ZSddO1xyXG4gICAgfVxyXG4gICAgcHVibGljIHNldE9wdGlvbnMob3B0aW9uczogeyBrZXk6IHN0cmluZywgdmFsdWU6IHN0cmluZyB9W10pIHtcclxuICAgICAgICB0aGlzLnZhbHVlID0gJyc7XHJcbiAgICAgICAgdGhpcy5vcHRpb25zID0gb3B0aW9ucztcclxuICAgIH1cclxuICAgIHB1YmxpYyBnZXRPcHRpb25zKCk6IHsga2V5OiBzdHJpbmcsIHZhbHVlOiBzdHJpbmcgfVtdIHsgcmV0dXJuIHRoaXMub3B0aW9uczsgfVxyXG59XHJcblxyXG5leHBvcnQgY2xhc3MgS2RJbnB1dFJhZGlvIGV4dGVuZHMgSW5wdXRCYXNlPHN0cmluZz4ge1xyXG4gICAgcHJpdmF0ZSBsaXN0OiB7IGtleTogc3RyaW5nLCB2YWx1ZTogc3RyaW5nLCB0aXRsZTogc3RyaW5nIH1bXSA9IFtdO1xyXG4gICAgY29uc3RydWN0b3Iob3B0aW9uczoge30gPSB7fSkge1xyXG4gICAgICAgIHN1cGVyKG9wdGlvbnMpO1xyXG4gICAgICAgIHRoaXMubGlzdCA9IG9wdGlvbnNbJ2xpc3QnXSB8fCBbXTtcclxuICAgIH1cclxufVxyXG5cclxuZXhwb3J0IGNsYXNzIEtkSW5wdXRDaGVja2JveCBleHRlbmRzIElucHV0QmFzZTxhbnk+IHtcclxuICAgIHByaXZhdGUgbGlzdDogeyAvKmtleTogc3RyaW5nLCovIHZhbHVlOiBzdHJpbmcsIHRpdGxlOiBzdHJpbmcgfVtdID0gW107XHJcbiAgICBjb25zdHJ1Y3RvcihvcHRpb25zOiB7fSA9IHt9KSB7XHJcbiAgICAgICAgc3VwZXIob3B0aW9ucyk7XHJcbiAgICAgICAgdGhpcy5saXN0ID0gb3B0aW9uc1snbGlzdCddIHx8IFtdO1xyXG4gICAgICAgIHRoaXMudmFsdWUgPSAodHlwZW9mIHRoaXMudmFsdWUgIT09ICd1bmRlZmluZWQnKSA/IHRoaXMudmFsdWUgOiB7fTtcclxuXHJcbiAgICAgICAgLy8gY2hlY2tpbmcgd2hldGhlciB0aGUgdmFsdWUgY29udGFpbiBhbnkgb3RoZXIgcmVkdW5kZW50IGtleSB2YWx1ZSBwYWlyXHJcbiAgICAgICAgZm9yIChsZXQgaXRlbSBpbiB0aGlzLnZhbHVlKSB7XHJcbiAgICAgICAgICAgIGlmICghdGhpcy52YWx1ZVtpdGVtXSkgZGVsZXRlIHRoaXMudmFsdWVbaXRlbV07XHJcbiAgICAgICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgbGV0IHRvRGVsZXRlOiBib29sZWFuID0gdHJ1ZTtcclxuICAgICAgICAgICAgICAgIGZvciAobGV0IGk6IG51bWJlciA9IDA7IGkgPCB0aGlzLmxpc3QubGVuZ3RoOyBpKyspIHtcclxuICAgICAgICAgICAgICAgICAgICBpZiAoaXRlbSA9PT0gdGhpcy5saXN0W2ldLnZhbHVlKSB0b0RlbGV0ZSA9IGZhbHNlO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgaWYgKHRvRGVsZXRlKSBkZWxldGUgdGhpcy52YWx1ZVtpdGVtXTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgIH1cclxufVxyXG5cclxuZXhwb3J0IGNsYXNzIEtkSW5wdXRUcmVlRHJvcGRvd24gZXh0ZW5kcyBJbnB1dEJhc2U8c3RyaW5nPiB7XHJcbiAgICBwcml2YXRlIGNvbmZpZzogYW55O1xyXG4gICAgcHJpdmF0ZSBhcGk6IElUcmVlQXBpO1xyXG4gICAgY29uc3RydWN0b3Iob3B0aW9uczoge30gPSB7fSkge1xyXG4gICAgICAgIHN1cGVyKG9wdGlvbnMpO1xyXG4gICAgICAgIHRoaXMuY29uZmlnID0gb3B0aW9uc1snY29uZmlnJ10gfHwge307XHJcbiAgICAgICAgdGhpcy5hcGkgPSBvcHRpb25zWydhcGknXSB8fCB7fTtcclxuICAgIH1cclxufVxyXG5cclxuZXhwb3J0IGNsYXNzIEtkSW5wdXRTbGlkZXIgZXh0ZW5kcyBJbnB1dEJhc2U8c3RyaW5nPiB7XHJcbiAgICBwcml2YXRlIGNvbmZpZzogYW55O1xyXG4gICAgcHJpdmF0ZSBhcGk6IGFueTtcclxuICAgIGNvbnN0cnVjdG9yKG9wdGlvbnM6IHt9ID0ge30pIHtcclxuICAgICAgICBzdXBlcihvcHRpb25zKTtcclxuICAgICAgICB0aGlzLmNvbmZpZyA9IG9wdGlvbnNbJ2NvbmZpZyddIHx8IHt9O1xyXG4gICAgICAgIHRoaXMuYXBpID0gb3B0aW9uc1snYXBpJ10gfHwge307XHJcbiAgICB9XHJcbn1cclxuXHJcbmV4cG9ydCBjbGFzcyBLZElucHV0TXVsdGlTZWxlY3RUYWJsZSBleHRlbmRzIElucHV0QmFzZTxzdHJpbmc+IHtcclxuICAgIHByaXZhdGUgY29uZmlnOiBhbnk7XHJcbiAgICBwcml2YXRlIG1hc3RlckRhdGE6IEFycmF5PGFueT47XHJcbiAgICBwcml2YXRlIHNsYXZlRGF0YTogQXJyYXk8YW55PjtcclxuICAgIGNvbnN0cnVjdG9yKG9wdGlvbnM6IHt9ID0ge30pIHtcclxuICAgICAgICBzdXBlcihvcHRpb25zKTtcclxuICAgICAgICB0aGlzLmNvbmZpZyA9IG9wdGlvbnNbJ2NvbmZpZyddIHx8IHt9O1xyXG4gICAgICAgIHRoaXMubWFzdGVyRGF0YSA9IG9wdGlvbnNbJ21hc3RlckRhdGEnXSB8fCBbXTtcclxuICAgICAgICB0aGlzLnNsYXZlRGF0YSA9IG9wdGlvbnNbJ3NsYXZlRGF0YSddIHx8IFtdO1xyXG4gICAgfVxyXG59XHJcblxyXG5leHBvcnQgY2xhc3MgS2RJbnB1dFRhYmxlIGV4dGVuZHMgSW5wdXRCYXNlPHN0cmluZz4ge1xyXG4gICAgcHJpdmF0ZSByb3c6IEFycmF5PGFueT47XHJcbiAgICBwcml2YXRlIGNvbHVtbjogQXJyYXk8YW55PjtcclxuICAgIHByaXZhdGUgY29uZmlnOiBhbnk7XHJcbiAgICBwcml2YXRlIGFwaTogYW55O1xyXG5cclxuICAgIGNvbnN0cnVjdG9yKG9wdGlvbnM6IHt9ID0ge30pIHtcclxuICAgICAgICBzdXBlcihvcHRpb25zKTtcclxuICAgICAgICB0aGlzLmNvbmZpZyA9IG9wdGlvbnNbJ2NvbmZpZyddO1xyXG4gICAgICAgIHRoaXMucm93ID0gb3B0aW9uc1sncm93J107XHJcbiAgICAgICAgdGhpcy5jb2x1bW4gPSBvcHRpb25zWydjb2x1bW4nXTtcclxuICAgICAgICB0aGlzLmFwaSA9IG9wdGlvbnNbJ2FwaSddIHx8IHt9O1xyXG4gICAgfVxyXG59XHJcblxyXG5leHBvcnQgY2xhc3MgS2RJbnB1dFN5bWJvbCBleHRlbmRzIElucHV0QmFzZTxzdHJpbmc+IHtcclxufVxyXG5cclxuZXhwb3J0IGNsYXNzIEtkSW5wdXRCdXR0b25Hcm91cCBleHRlbmRzIElucHV0QmFzZTxhbnk+IHtcclxuICAgIHByaXZhdGUgY29uZmlnOiBhbnk7XHJcbiAgICBwcml2YXRlIGxpc3Q6IHsga2V5OiBzdHJpbmcsIHZhbHVlOiBzdHJpbmcgfVtdID0gW107XHJcblxyXG4gICAgY29uc3RydWN0b3Iob3B0aW9uczoge30gPSB7fSkge1xyXG4gICAgICAgIHN1cGVyKG9wdGlvbnMpO1xyXG4gICAgICAgIHRoaXMuY29uZmlnID0gb3B0aW9uc1snY29uZmlnJ10gfHwge307XHJcbiAgICAgICAgdGhpcy5saXN0ID0gb3B0aW9uc1snbGlzdCddIHx8IFtdO1xyXG5cclxuICAgICAgICBpZiAodGhpcy5jb25maWcudHlwZSA9PT0gJ2NoZWNrYm94Jykge1xyXG4gICAgICAgICAgICAvLyBjaGVja2luZyB3aGV0aGVyIHRoZSB2YWx1ZSBjb250YWluIGFueSBvdGhlciByZWR1bmRlbnQga2V5IHZhbHVlIHBhaXJcclxuICAgICAgICAgICAgdGhpcy52YWx1ZSA9ICh0eXBlb2YgdGhpcy52YWx1ZSAhPT0gJ3VuZGVmaW5lZCcpID8gdGhpcy52YWx1ZSA6IHt9O1xyXG4gICAgICAgICAgICBmb3IgKGxldCBpdGVtIGluIHRoaXMudmFsdWUpIHtcclxuICAgICAgICAgICAgICAgIGlmICghdGhpcy52YWx1ZVtpdGVtXSkgZGVsZXRlIHRoaXMudmFsdWVbaXRlbV07XHJcbiAgICAgICAgICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgICAgICAgICBsZXQgdG9EZWxldGU6IGJvb2xlYW4gPSB0cnVlO1xyXG4gICAgICAgICAgICAgICAgICAgIGZvciAobGV0IGk6IG51bWJlciA9IDA7IGkgPCB0aGlzLmxpc3QubGVuZ3RoOyBpKyspIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgaWYgKGl0ZW0gPT09IHRoaXMubGlzdFtpXS52YWx1ZSkgdG9EZWxldGUgPSBmYWxzZTtcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKHRvRGVsZXRlKSBkZWxldGUgdGhpcy52YWx1ZVtpdGVtXTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgIH1cclxufVxyXG4iXX0=