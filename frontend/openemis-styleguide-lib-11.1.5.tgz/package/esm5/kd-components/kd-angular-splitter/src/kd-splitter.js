import { __decorate, __metadata } from "tslib";
import { Component, Input, OnInit, HostListener, ViewEncapsulation, ViewContainerRef, AfterViewInit, ElementRef, Renderer2 } from '@angular/core';
import { Router, NavigationEnd } from '@angular/router';
import { timer } from 'rxjs';
import { KdConvertionSvc, KdDomElemSvc } from '../../kd-common/index';
import { KdSplitterSvc } from './kd-splitter-svc';
import { KdSplitterEvent } from './kd-splitter-event';
var KdSplitter = /** @class */ (function () {
    function KdSplitter(_vcr, _renderer, _splitterSvc, _convertionSvc, _domElemSvc, _splitterEvent, _router) {
        this._vcr = _vcr;
        this._renderer = _renderer;
        this._splitterSvc = _splitterSvc;
        this._convertionSvc = _convertionSvc;
        this._domElemSvc = _domElemSvc;
        this._splitterEvent = _splitterEvent;
        this._router = _router;
        this._isDrag = false;
        this._disableDrag = false;
        this._panesDefaultConfig = {};
        this._panes = [];
        // private _localStorage: number;
        this._isMainPaneCollapse = false;
        this._splitterLevel = '';
        this._enableFloatBtn = false;
        this._enableSubPaneCollapse = false;
        this._prevIsMobile = false;
        this._isSubPaneOpen = false;
        this._sessionPrefix = '';
        this._sessionName = 'splitter';
        this._isFirstSwitchViewPort = true;
        this._prevWidthState = 0;
        this._isMenuOpen = false;
        this.el = this._vcr.element;
    }
    KdSplitter.prototype.onMousemove = function (event) {
        // this.mousemove.emit(event);
        this._onDrag(event);
    };
    KdSplitter.prototype.onMouseup = function (event) {
        // this.mouseup.emit(event);
        this._isDrag = false;
    };
    KdSplitter.prototype.onResize = function (event) {
        // console.log('resize');
        this._onResize(event);
    };
    KdSplitter.prototype.ngOnInit = function () {
        this._prevIsMobile = this._domElemSvc.isMobile();
        this._enableFloatBtn = this._convertionSvc.strToBool(this.floatbtn);
        this._enableSubPaneCollapse = this._convertionSvc.strToBool(this.collapsible);
        // this._panesDefaultConfig = this._splitterSvc.initPanesDefaultConfig(this._panes);
        // console.log(this._panesDefaultConfig);
    };
    KdSplitter.prototype.ngAfterViewInit = function () {
        var _this = this;
        this._panesDefaultConfig = this._splitterSvc.initPanesDefaultConfig(this._panes);
        this._disableDrag = this._splitterSvc.toDisableDrag();
        if (this._splitterSvc.isSubPane(this.el.nativeElement)) {
            // console.log('this is the sub pane');
            this._splitterLevel = 'sub';
            var leftPane = this._panes[0].element.nativeElement;
            this._prevWidthState = leftPane.getBoundingClientRect().width;
        }
        else {
            // console.log('this is the main pane');
            this._splitterLevel = 'main';
            this._registerMenuBroadcast();
            this._setTint(false);
        }
        // this._splitterEvent.onDrag()
        // .subscribe(_type => {
        //     console.log(_type);
        // });
        // isSubSplitter/
        this._sessionPrefix = this._convertionSvc.camelCase(this._domElemSvc.getDocumentTheme(), '-') + '_splitter_' + this._splitterLevel;
        this._setDefaultPaneSize();
        this._setupSplitterHandler();
        this._toggleCollapseSubPane();
        this._isFirstSwitchViewPort = false;
        this._router.events.subscribe(function (event) {
            if (event instanceof NavigationEnd) {
                // console.log(event.url);
                for (var key in _this._panes) {
                    if (_this._panes.hasOwnProperty(key)) {
                        var pane = _this._panes[key];
                        pane.element.nativeElement.scrollTop = 0;
                    }
                }
            }
        });
    };
    KdSplitter.prototype.addGroup = function (pane) {
        this._panes.push(pane);
        return this._panes.length;
    };
    KdSplitter.prototype.paneOnChange = function (_type) {
        this._panesDefaultConfig = this._splitterSvc.initPanesDefaultConfig(this._panes);
        if (_type === 'size') {
            // changing element width before animation of panes start
            this._setDefaultPaneSize(false);
            var boundingRect = this.el.nativeElement.getBoundingClientRect();
            if (boundingRect) {
                // affects animation of left pane. 
                this._prevWidthState = this._panesDefaultConfig.Pane1.size * boundingRect.width;
            }
        }
    };
    KdSplitter.prototype._registerMenuBroadcast = function () {
        var _this = this;
        this._splitterEvent.on()
            .subscribe(function (respone) {
            // console.log(respone);
            var direction = _this._domElemSvc.getDocumentDirection(true);
            var oppDirection = direction === 'left' ? 'right' : 'left';
            var className = 'push-content-' + oppDirection;
            var isMobile = _this._domElemSvc.isMobile();
            var count = 0;
            for (var key in _this._panes) {
                if (_this._panes.hasOwnProperty(key)) {
                    var pane = _this._panes[key];
                    _this._domElemSvc.setElementClass(pane.element.nativeElement, 'animation', isMobile);
                    if (count !== 0) {
                        if (!isMobile) {
                            _this._domElemSvc.removeClass(pane.element.nativeElement, className);
                        }
                        else {
                            _this._isMenuOpen = !_this._isMenuOpen;
                            if (_this._splitterLevel === 'main') {
                                // console.log('append class ' + className + ' into main pane');
                                _this._domElemSvc.setElementClass(pane.element.nativeElement, className, _this._isMenuOpen);
                                _this._setTint(_this._isMenuOpen);
                            }
                        }
                    }
                    else {
                        if (isMobile && _this._splitterLevel === 'sub') {
                            // console.log('sub main');
                        }
                    }
                    count++;
                }
            }
        });
    };
    KdSplitter.prototype._setupSplitterHandler = function () {
        var _this = this;
        for (var i = 1; i < this._panes.length; i++) {
            var count = i + 1;
            var className = 'sh-' + count;
            var newEl = this._domElemSvc.createElement(this._panes[i].element.nativeElement, 'splitter-handler ' + className);
            this._domElemSvc.setElementClass(newEl, 'disabled', this._disableDrag);
            // setup OnMouseDownEvent
            // setup OnMouseDownEvent
            this._renderer.listen(newEl, 'mousedown', function (event) {
                _this._selectedElem = event.target.parentElement;
                _this._selectedPrevSiblingElem = _this._selectedElem.previousElementSibling;
                _this._isDrag = true;
            });
            if (this._splitterLevel === 'main') {
                this._setupCollapseButton(this._panes[i], count);
            }
        }
    };
    KdSplitter.prototype._setupCollapseButton = function (_pane, _count) {
        var _this = this;
        var className = 'mb-' + _count;
        var newBtn = this._domElemSvc.createElement(_pane.element.nativeElement, 'menu-btn ' + className);
        // Setup icon
        this._domElemSvc.createElement(newBtn, 'fa', 'i');
        this._setCollapseIcon(this._isMainPaneCollapse);
        // setup OnMouseDownEvent
        // setup OnMouseDownEvent
        this._renderer.listen(newBtn, 'click', function (event) {
            // console.log(event);
            _this._isDrag = false;
            _this._toggleCollapseMenu(_pane);
        });
    };
    KdSplitter.prototype._setDefaultPaneSize = function (_useLocalStorage) {
        if (_useLocalStorage === void 0) { _useLocalStorage = true; }
        var count = 0;
        var offsetX = 0;
        var direction = this._domElemSvc.getDocumentDirection(true);
        var oppDirection = direction === 'left' ? 'right' : 'left';
        var mobileConfig = this._splitterSvc.getMobileConfig(this._splitterLevel, direction);
        var isMobile = this._domElemSvc.isMobile();
        var localStorage = JSON.parse(window.sessionStorage.getItem(this._sessionPrefix + this._sessionName));
        // console.log(localStorage);
        // console.log('sessionStorge = '+window.sessionStorage.getItem(this._sessionPrefix+this._sessionName));
        for (var key in this._panesDefaultConfig) {
            if (this._panesDefaultConfig.hasOwnProperty(key)) {
                var pane = this._panes[count];
                var paneConfig = {
                    width: (this._panesDefaultConfig[key].size > 100) ? 100 : this._panesDefaultConfig[key].size,
                };
                paneConfig[direction] = offsetX;
                if (isMobile) {
                    paneConfig = Object.assign({}, paneConfig, mobileConfig[key]);
                    this._isMenuOpen = false;
                    if (count === 0) {
                        // console.log('show button');
                        this._setupFloatMenuBtn(pane, count);
                    }
                    // console.log("this is mobile view");
                }
                else {
                    if (localStorage !== null && _useLocalStorage) {
                        var tempName = 'Pane' + (count + 1);
                        paneConfig = Object.assign({}, paneConfig, localStorage[tempName]);
                    }
                    // console.log(paneConfig);
                    this._removeFloatMenuBtn();
                    this._domElemSvc.removeClass(pane.element.nativeElement, 'push-content-' + oppDirection);
                    if (this._splitterLevel === 'sub' && count === 1 && this._isFirstSwitchViewPort) {
                        var isSubPaneShow = (this._panesDefaultConfig[key].show !== undefined) ? this._panesDefaultConfig[key].show : true;
                        this._processToggleCollapseSubPane(isSubPaneShow, false);
                    }
                }
                for (var cKey in paneConfig) {
                    if (paneConfig.hasOwnProperty(cKey)) {
                        this._domElemSvc.setElementStyle(pane.element.nativeElement, cKey, paneConfig[cKey] + '%');
                    }
                }
                count++;
                offsetX += paneConfig.width;
            }
        }
    };
    KdSplitter.prototype._updateSplitPaneSize = function (_posX, _boundSize) {
        if (this._domElemSvc.isMobile())
            return;
        if (!this._isDrag)
            return;
        var direction = this._domElemSvc.getDocumentDirection(true);
        var dimention = (this.orientation === 'vertical') ? 'height' : 'width';
        var selectedElemBounds = this._selectedElem.getBoundingClientRect();
        var selectedPrevElemBounds = this._selectedPrevSiblingElem.getBoundingClientRect();
        selectedElemBounds = (this.orientation === 'vertical') ? selectedElemBounds.height : selectedElemBounds.width;
        selectedPrevElemBounds = (this.orientation === 'vertical') ? selectedPrevElemBounds.height : selectedPrevElemBounds.width;
        var total2ElemSize = Math.round(this._convertionSvc.convertPxToPercent(selectedPrevElemBounds + selectedElemBounds, _boundSize));
        var moveX = this._splitterSvc.validatePercentValue(_posX);
        total2ElemSize = this._splitterSvc.validatePercentValue(total2ElemSize);
        var selectedPrevPaneKey = this._convertionSvc.camelCase(this._selectedPrevSiblingElem.classList[1], '-');
        moveX = this._splitterSvc.validatePaneSize(this._panesDefaultConfig, selectedPrevPaneKey, moveX);
        var curPane = total2ElemSize - moveX;
        var splitterFinalConfig = {
            Pane1: {},
            Pane2: {}
        };
        splitterFinalConfig['Pane1'][dimention] = moveX;
        splitterFinalConfig['Pane2'][direction] = moveX;
        splitterFinalConfig['Pane2'][dimention] = curPane;
        window.sessionStorage.setItem(this._sessionPrefix + this._sessionName, JSON.stringify(splitterFinalConfig));
        this._domElemSvc.setElementStyle(this._selectedPrevSiblingElem, dimention, moveX + '%');
        this._domElemSvc.setElementStyle(this._selectedElem, direction, moveX + '%');
        this._domElemSvc.setElementStyle(this._selectedElem, dimention, curPane + '%');
    };
    KdSplitter.prototype._toggleCollapseMenu = function (_pane) {
        var direction = this._domElemSvc.getDocumentDirection(true);
        this._isMainPaneCollapse = !this._isMainPaneCollapse;
        this._domElemSvc.addClass(_pane.element.nativeElement, 'animation');
        this._domElemSvc.setElementClass(_pane.element.nativeElement, 'push-content-' + direction, this._isMainPaneCollapse);
        this._setCollapseIcon(this._isMainPaneCollapse);
        this._splitterEvent.toggleMenu();
    };
    KdSplitter.prototype._removeFloatMenuBtn = function () {
        this._domElemSvc.removeElementByClass('.fm-btn', this.el.nativeElement);
    };
    KdSplitter.prototype._setupFloatMenuBtn = function (_pane, _count) {
        var _this = this;
        var isMobile = this._domElemSvc.isMobile();
        var floatBtn = this.el.nativeElement.querySelector('.fm-btn');
        if (isMobile && this._splitterLevel === 'sub' && floatBtn === null && this._enableFloatBtn) {
            // console.log('sub main');
            // let classNames: string = 'fmb-' + _count;
            var className = 'fm-btn';
            var newBtn = this._domElemSvc.createElement(this.el.nativeElement, 'btn btn-float-bottom-right btn-circle btn-color ' + className);
            // //Setup icon
            HTMLElement = this._domElemSvc.createElement(newBtn, 'fa', 'i');
            this._setFloatIcon(this._isSubPaneOpen);
            // //setup OnMouseDownEvent
            // //setup OnMouseDownEvent
            this._renderer.listen(newBtn, 'click', function (event) {
                _this._isSubPaneOpen = !_this._isSubPaneOpen;
                _this._splitterEvent.toggleSubPane(_this._isSubPaneOpen);
            });
        }
    };
    KdSplitter.prototype._toggleCollapseSubPane = function () {
        var _this = this;
        if (this._splitterLevel === 'sub') {
            this._splitterEvent.onToggleSubPane()
                .subscribe(function (isSubPaneOpen) {
                _this._processToggleCollapseSubPane(isSubPaneOpen);
            });
        }
    };
    KdSplitter.prototype._processToggleCollapseSubPane = function (isSubPaneOpen, _animate) {
        var _this = this;
        // console.log('in this function?')
        _animate = (typeof _animate === 'undefined') ? true : _animate;
        var rightPane = this._panes[1].element.nativeElement;
        var leftPane = this._panes[0].element.nativeElement;
        var isMobile = this._domElemSvc.isMobile();
        var isSameState = (this._isSubPaneOpen === isSubPaneOpen) ? true : false;
        this._isSubPaneOpen = isSubPaneOpen;
        if (_animate) {
            this._domElemSvc.addClass(rightPane, 'animation');
            this._domElemSvc.addClass(leftPane, 'animation');
        }
        if (isMobile || this._enableSubPaneCollapse) {
            // console.log('am i in?');
            var animateDirection = (isMobile) ? 'in' : 'out';
            var direction = this._domElemSvc.getDocumentDirection(true);
            var oppDirection = (direction === 'left') ? 'right' : 'left';
            var addClass = (isMobile) ? isSubPaneOpen : !isSubPaneOpen;
            var widthConfig = [{}];
            if (addClass) {
                this._prevWidthState = leftPane.getBoundingClientRect().width;
                widthConfig = [
                    { 'width': this._prevWidthState + 'px' },
                    { 'width': '100%' }
                ];
            }
            else {
                widthConfig = [
                    { 'width': '100%' },
                    { 'width': this._prevWidthState + 'px' }
                ];
            }
            this._setFloatIcon(isSubPaneOpen);
            this._domElemSvc.setElementClass(leftPane, 'full-width', addClass);
            this._domElemSvc.setElementClass(rightPane, 'push-subcontent-' + oppDirection + '-' + animateDirection, addClass);
            if (_animate && !isSameState) {
                this._domElemSvc.invokeElementMethod(leftPane, 'animate', [widthConfig, 500]);
                timer(500).subscribe(function () {
                    // need fixing in the future. this event is being triggered twice. another time is in kd-example
                    _this._splitterEvent.toggleSubPane(isSubPaneOpen);
                    // this._splitterEvent.toggleAnimationSubPaneEnd(isSubPaneOpen);
                });
            }
        }
    };
    KdSplitter.prototype._setFloatIcon = function (_isOpen) {
        var btnIcon = this.el.nativeElement.querySelector('.fm-btn i');
        if (this._splitterLevel === 'sub' && btnIcon !== null) {
            this._domElemSvc.setElementClass(btnIcon, 'kd-lists', !_isOpen);
            this._domElemSvc.setElementClass(btnIcon, 'kd-close-round', _isOpen);
        }
    };
    KdSplitter.prototype._setCollapseIcon = function (_isOpen) {
        var direction = this._domElemSvc.getDocumentDirection(true);
        var oppDirection = (direction === 'left') ? 'right' : 'left';
        var btnIcon = this.el.nativeElement.querySelector('.menu-btn i');
        if (this._splitterLevel === 'main' && btnIcon !== null) {
            this._domElemSvc.setElementClass(btnIcon, 'fa-angle-' + direction, !_isOpen);
            this._domElemSvc.setElementClass(btnIcon, 'fa-angle-' + oppDirection, _isOpen);
        }
    };
    KdSplitter.prototype._setTint = function (_add) {
        var _this = this;
        var isMobile = this._domElemSvc.isMobile();
        var overlayDiv = this._panes[1].element.nativeElement.querySelector('.content-overlay');
        if (overlayDiv === null) {
            overlayDiv = this._domElemSvc.createElement(this._panes[1].element.nativeElement, 'content-overlay');
            this._renderer.listen(overlayDiv, 'click', function (event) {
                _this._splitterEvent.fire();
            });
        }
        if (isMobile) {
            this._domElemSvc.setElementClass(overlayDiv, 'show', _add);
            if (this._splitterLevel === 'main') {
                var contentArea = this._panes[1].element.nativeElement.querySelector('.main-wrapper');
                // console.log(contentArea);
                if (contentArea) {
                    var contentAreaHeight = contentArea.getBoundingClientRect().height;
                    var paneHeight = this._panes[1].element.nativeElement.getBoundingClientRect().height;
                    // console.log(paneHeight);
                    // console.log(contentAreaHeight);
                    if (contentAreaHeight > paneHeight) {
                        this._domElemSvc.setElementStyle(overlayDiv, 'bottom', 'auto');
                        this._domElemSvc.setElementStyle(overlayDiv, 'height', contentAreaHeight + 'px');
                    }
                }
                this._domElemSvc.setElementClass(this._panes[1].element.nativeElement, 'no-overflow', _add);
            }
        }
    };
    KdSplitter.prototype._onDrag = function (event) {
        if (this._disableDrag)
            return;
        if (!this._isDrag)
            return;
        var direction = this._domElemSvc.getDocumentDirection(true);
        // let selectedPaneBounds: any = this._selectedElem.getBoundingClientRect();
        var splitterBounds = this.el.nativeElement.getBoundingClientRect();
        var moveX = Math.abs(event.clientX - splitterBounds[direction]);
        // console.log(moveX);
        // let newWidth: number = selectedPaneBounds.width - moveX;
        // console.log(newWidth);
        var newSize = this._convertionSvc.convertPxToPercent(moveX, splitterBounds.width);
        // console.log('newSize = '+newSize);
        this._domElemSvc.removeClass(this._selectedElem, 'animation');
        this._updateSplitPaneSize(newSize, splitterBounds.width);
        this._splitterEvent.drag(this._splitterLevel);
    };
    KdSplitter.prototype._onResize = function (event) {
        var isMobile = this._domElemSvc.isMobile();
        if (isMobile !== this._prevIsMobile) {
            this._isFirstSwitchViewPort = true;
            this._prevIsMobile = isMobile;
            this._isSubPaneOpen = false;
        }
        this._setDefaultPaneSize();
        this._isFirstSwitchViewPort = false;
    };
    KdSplitter.ctorParameters = function () { return [
        { type: ViewContainerRef },
        { type: Renderer2 },
        { type: KdSplitterSvc },
        { type: KdConvertionSvc },
        { type: KdDomElemSvc },
        { type: KdSplitterEvent },
        { type: Router }
    ]; };
    __decorate([
        Input(),
        __metadata("design:type", String)
    ], KdSplitter.prototype, "orientation", void 0);
    __decorate([
        Input(),
        __metadata("design:type", String)
    ], KdSplitter.prototype, "floatbtn", void 0);
    __decorate([
        Input(),
        __metadata("design:type", String)
    ], KdSplitter.prototype, "collapsible", void 0);
    __decorate([
        HostListener('document:mousemove', ['$event']),
        __metadata("design:type", Function),
        __metadata("design:paramtypes", [Object]),
        __metadata("design:returntype", void 0)
    ], KdSplitter.prototype, "onMousemove", null);
    __decorate([
        HostListener('document:mouseup', ['$event']),
        __metadata("design:type", Function),
        __metadata("design:paramtypes", [Object]),
        __metadata("design:returntype", void 0)
    ], KdSplitter.prototype, "onMouseup", null);
    __decorate([
        HostListener('window:resize', ['$event']),
        __metadata("design:type", Function),
        __metadata("design:paramtypes", [Object]),
        __metadata("design:returntype", void 0)
    ], KdSplitter.prototype, "onResize", null);
    KdSplitter = __decorate([
        Component({
            selector: 'kd-splitter',
            template: "<div class='split-container {{orientation}}'><ng-content></ng-content></div>",
            encapsulation: ViewEncapsulation.None,
            providers: [KdSplitterSvc, KdSplitterEvent, KdConvertionSvc, KdDomElemSvc],
            host: { 'class': 'kdx-split-panes' }
        }),
        __metadata("design:paramtypes", [ViewContainerRef,
            Renderer2,
            KdSplitterSvc,
            KdConvertionSvc,
            KdDomElemSvc,
            KdSplitterEvent,
            Router])
    ], KdSplitter);
    return KdSplitter;
}());
export { KdSplitter };
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoia2Qtc3BsaXR0ZXIuanMiLCJzb3VyY2VSb290Ijoibmc6Ly9vcGVuZW1pcy1zdHlsZWd1aWRlLWxpYi8iLCJzb3VyY2VzIjpbImtkLWNvbXBvbmVudHMva2QtYW5ndWxhci1zcGxpdHRlci9zcmMva2Qtc3BsaXR0ZXIudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IjtBQUFBLE9BQU8sRUFBRSxTQUFTLEVBQUUsS0FBSyxFQUFFLE1BQU0sRUFBRSxZQUFZLEVBQUUsaUJBQWlCLEVBQUUsZ0JBQWdCLEVBQUUsYUFBYSxFQUFFLFVBQVUsRUFBRSxTQUFTLEVBQUUsTUFBTSxlQUFlLENBQUM7QUFDbEosT0FBTyxFQUFFLE1BQU0sRUFBRSxhQUFhLEVBQUUsTUFBTSxpQkFBaUIsQ0FBQztBQUN4RCxPQUFPLEVBQUUsS0FBSyxFQUFFLE1BQU0sTUFBTSxDQUFDO0FBRTdCLE9BQU8sRUFBRSxlQUFlLEVBQUUsWUFBWSxFQUFFLE1BQU0sdUJBQXVCLENBQUM7QUFDdEUsT0FBTyxFQUFFLGFBQWEsRUFBRSxNQUFNLG1CQUFtQixDQUFDO0FBQ2xELE9BQU8sRUFBRSxlQUFlLEVBQUUsTUFBTSxxQkFBcUIsQ0FBQztBQVV0RDtJQTBCSSxvQkFDWSxJQUFzQixFQUN0QixTQUFvQixFQUNwQixZQUEyQixFQUMzQixjQUErQixFQUMvQixXQUF5QixFQUN6QixjQUErQixFQUMvQixPQUFlO1FBTmYsU0FBSSxHQUFKLElBQUksQ0FBa0I7UUFDdEIsY0FBUyxHQUFULFNBQVMsQ0FBVztRQUNwQixpQkFBWSxHQUFaLFlBQVksQ0FBZTtRQUMzQixtQkFBYyxHQUFkLGNBQWMsQ0FBaUI7UUFDL0IsZ0JBQVcsR0FBWCxXQUFXLENBQWM7UUFDekIsbUJBQWMsR0FBZCxjQUFjLENBQWlCO1FBQy9CLFlBQU8sR0FBUCxPQUFPLENBQVE7UUE5Qm5CLFlBQU8sR0FBWSxLQUFLLENBQUM7UUFDekIsaUJBQVksR0FBWSxLQUFLLENBQUM7UUFDOUIsd0JBQW1CLEdBQVEsRUFBRSxDQUFDO1FBQzlCLFdBQU0sR0FBa0IsRUFBRSxDQUFDO1FBR25DLGlDQUFpQztRQUN6Qix3QkFBbUIsR0FBWSxLQUFLLENBQUM7UUFDckMsbUJBQWMsR0FBVyxFQUFFLENBQUM7UUFDNUIsb0JBQWUsR0FBWSxLQUFLLENBQUM7UUFDakMsMkJBQXNCLEdBQVksS0FBSyxDQUFDO1FBQ3hDLGtCQUFhLEdBQVksS0FBSyxDQUFDO1FBQy9CLG1CQUFjLEdBQVksS0FBSyxDQUFDO1FBQ2hDLG1CQUFjLEdBQVcsRUFBRSxDQUFDO1FBQzVCLGlCQUFZLEdBQVcsVUFBVSxDQUFDO1FBQ2xDLDJCQUFzQixHQUFZLElBQUksQ0FBQztRQUN2QyxvQkFBZSxHQUFXLENBQUMsQ0FBQztRQUM1QixnQkFBVyxHQUFZLEtBQUssQ0FBQztRQWVqQyxJQUFJLENBQUMsRUFBRSxHQUFHLElBQUksQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDO0lBQ2hDLENBQUM7SUFHRCxnQ0FBVyxHQUFYLFVBQVksS0FBVTtRQUNsQiw4QkFBOEI7UUFDOUIsSUFBSSxDQUFDLE9BQU8sQ0FBQyxLQUFLLENBQUMsQ0FBQztJQUV4QixDQUFDO0lBR0QsOEJBQVMsR0FBVCxVQUFVLEtBQVU7UUFDaEIsNEJBQTRCO1FBQzVCLElBQUksQ0FBQyxPQUFPLEdBQUcsS0FBSyxDQUFDO0lBQ3pCLENBQUM7SUFHRCw2QkFBUSxHQUFSLFVBQVMsS0FBVTtRQUNmLHlCQUF5QjtRQUN6QixJQUFJLENBQUMsU0FBUyxDQUFDLEtBQUssQ0FBQyxDQUFDO0lBQzFCLENBQUM7SUFFRCw2QkFBUSxHQUFSO1FBQ0ksSUFBSSxDQUFDLGFBQWEsR0FBRyxJQUFJLENBQUMsV0FBVyxDQUFDLFFBQVEsRUFBRSxDQUFDO1FBQ2pELElBQUksQ0FBQyxlQUFlLEdBQUcsSUFBSSxDQUFDLGNBQWMsQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxDQUFDO1FBQ3BFLElBQUksQ0FBQyxzQkFBc0IsR0FBRyxJQUFJLENBQUMsY0FBYyxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFDLENBQUM7UUFDOUUsb0ZBQW9GO1FBQ3BGLHlDQUF5QztJQUM3QyxDQUFDO0lBRUQsb0NBQWUsR0FBZjtRQUFBLGlCQXlDQztRQXhDRyxJQUFJLENBQUMsbUJBQW1CLEdBQUcsSUFBSSxDQUFDLFlBQVksQ0FBQyxzQkFBc0IsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUM7UUFDakYsSUFBSSxDQUFDLFlBQVksR0FBRyxJQUFJLENBQUMsWUFBWSxDQUFDLGFBQWEsRUFBRSxDQUFDO1FBRXRELElBQUksSUFBSSxDQUFDLFlBQVksQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxhQUFhLENBQUMsRUFBRTtZQUNwRCx1Q0FBdUM7WUFDdkMsSUFBSSxDQUFDLGNBQWMsR0FBRyxLQUFLLENBQUM7WUFDNUIsSUFBSSxRQUFRLEdBQWdCLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLGFBQWEsQ0FBQztZQUNqRSxJQUFJLENBQUMsZUFBZSxHQUFHLFFBQVEsQ0FBQyxxQkFBcUIsRUFBRSxDQUFDLEtBQUssQ0FBQztTQUNqRTthQUNJO1lBQ0Qsd0NBQXdDO1lBQ3hDLElBQUksQ0FBQyxjQUFjLEdBQUcsTUFBTSxDQUFDO1lBRTdCLElBQUksQ0FBQyxzQkFBc0IsRUFBRSxDQUFDO1lBQzlCLElBQUksQ0FBQyxRQUFRLENBQUMsS0FBSyxDQUFDLENBQUM7U0FDeEI7UUFDRCwrQkFBK0I7UUFDL0Isd0JBQXdCO1FBQ3hCLDBCQUEwQjtRQUMxQixNQUFNO1FBQ04saUJBQWlCO1FBQ2pCLElBQUksQ0FBQyxjQUFjLEdBQUcsSUFBSSxDQUFDLGNBQWMsQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxnQkFBZ0IsRUFBRSxFQUFFLEdBQUcsQ0FBQyxHQUFHLFlBQVksR0FBRyxJQUFJLENBQUMsY0FBYyxDQUFDO1FBRW5JLElBQUksQ0FBQyxtQkFBbUIsRUFBRSxDQUFDO1FBQzNCLElBQUksQ0FBQyxxQkFBcUIsRUFBRSxDQUFDO1FBQzdCLElBQUksQ0FBQyxzQkFBc0IsRUFBRSxDQUFDO1FBRTlCLElBQUksQ0FBQyxzQkFBc0IsR0FBRyxLQUFLLENBQUM7UUFFcEMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsU0FBUyxDQUFDLFVBQUEsS0FBSztZQUMvQixJQUFJLEtBQUssWUFBWSxhQUFhLEVBQUU7Z0JBQ2hDLDBCQUEwQjtnQkFDMUIsS0FBSyxJQUFJLEdBQUcsSUFBSSxLQUFJLENBQUMsTUFBTSxFQUFFO29CQUN6QixJQUFJLEtBQUksQ0FBQyxNQUFNLENBQUMsY0FBYyxDQUFDLEdBQUcsQ0FBQyxFQUFFO3dCQUNqQyxJQUFJLElBQUksR0FBVyxLQUFJLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDO3dCQUNwQyxJQUFJLENBQUMsT0FBTyxDQUFDLGFBQWEsQ0FBQyxTQUFTLEdBQUcsQ0FBQyxDQUFDO3FCQUM1QztpQkFDSjthQUNKO1FBQ0wsQ0FBQyxDQUFDLENBQUM7SUFDUCxDQUFDO0lBRUQsNkJBQVEsR0FBUixVQUFTLElBQVk7UUFDakIsSUFBSSxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUM7UUFDdkIsT0FBTyxJQUFJLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQztJQUM5QixDQUFDO0lBRUQsaUNBQVksR0FBWixVQUFhLEtBQWE7UUFDdEIsSUFBSSxDQUFDLG1CQUFtQixHQUFHLElBQUksQ0FBQyxZQUFZLENBQUMsc0JBQXNCLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDO1FBQ2pGLElBQUksS0FBSyxLQUFLLE1BQU0sRUFBRTtZQUNsQix5REFBeUQ7WUFDekQsSUFBSSxDQUFDLG1CQUFtQixDQUFDLEtBQUssQ0FBQyxDQUFDO1lBQ2hDLElBQUksWUFBWSxHQUFHLElBQUksQ0FBQyxFQUFFLENBQUMsYUFBYSxDQUFDLHFCQUFxQixFQUFFLENBQUM7WUFDakUsSUFBSSxZQUFZLEVBQUU7Z0JBQ2QsbUNBQW1DO2dCQUNuQyxJQUFJLENBQUMsZUFBZSxHQUFHLElBQUksQ0FBQyxtQkFBbUIsQ0FBQyxLQUFLLENBQUMsSUFBSSxHQUFHLFlBQVksQ0FBQyxLQUFLLENBQUM7YUFDbkY7U0FDSjtJQUNMLENBQUM7SUFFTywyQ0FBc0IsR0FBOUI7UUFBQSxpQkFxQ0M7UUFwQ0csSUFBSSxDQUFDLGNBQWMsQ0FBQyxFQUFFLEVBQUU7YUFDbkIsU0FBUyxDQUFDLFVBQUEsT0FBTztZQUNkLHdCQUF3QjtZQUN4QixJQUFJLFNBQVMsR0FBVyxLQUFJLENBQUMsV0FBVyxDQUFDLG9CQUFvQixDQUFDLElBQUksQ0FBQyxDQUFDO1lBQ3BFLElBQUksWUFBWSxHQUFXLFNBQVMsS0FBSyxNQUFNLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDO1lBQ25FLElBQUksU0FBUyxHQUFXLGVBQWUsR0FBRyxZQUFZLENBQUM7WUFDdkQsSUFBSSxRQUFRLEdBQVksS0FBSSxDQUFDLFdBQVcsQ0FBQyxRQUFRLEVBQUUsQ0FBQztZQUNwRCxJQUFJLEtBQUssR0FBVyxDQUFDLENBQUM7WUFFdEIsS0FBSyxJQUFJLEdBQUcsSUFBSSxLQUFJLENBQUMsTUFBTSxFQUFFO2dCQUN6QixJQUFJLEtBQUksQ0FBQyxNQUFNLENBQUMsY0FBYyxDQUFDLEdBQUcsQ0FBQyxFQUFFO29CQUNqQyxJQUFJLElBQUksR0FBVyxLQUFJLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDO29CQUNwQyxLQUFJLENBQUMsV0FBVyxDQUFDLGVBQWUsQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLGFBQWEsRUFBRSxXQUFXLEVBQUUsUUFBUSxDQUFDLENBQUM7b0JBRXBGLElBQUksS0FBSyxLQUFLLENBQUMsRUFBRTt3QkFDYixJQUFJLENBQUMsUUFBUSxFQUFFOzRCQUNYLEtBQUksQ0FBQyxXQUFXLENBQUMsV0FBVyxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsYUFBYSxFQUFFLFNBQVMsQ0FBQyxDQUFDO3lCQUN2RTs2QkFDSTs0QkFDRCxLQUFJLENBQUMsV0FBVyxHQUFHLENBQUMsS0FBSSxDQUFDLFdBQVcsQ0FBQzs0QkFDckMsSUFBSSxLQUFJLENBQUMsY0FBYyxLQUFLLE1BQU0sRUFBRTtnQ0FDaEMsZ0VBQWdFO2dDQUNoRSxLQUFJLENBQUMsV0FBVyxDQUFDLGVBQWUsQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLGFBQWEsRUFBRSxTQUFTLEVBQUUsS0FBSSxDQUFDLFdBQVcsQ0FBQyxDQUFDO2dDQUMxRixLQUFJLENBQUMsUUFBUSxDQUFDLEtBQUksQ0FBQyxXQUFXLENBQUMsQ0FBQzs2QkFDbkM7eUJBQ0o7cUJBQ0o7eUJBQ0k7d0JBQ0QsSUFBSSxRQUFRLElBQUksS0FBSSxDQUFDLGNBQWMsS0FBSyxLQUFLLEVBQUU7NEJBQzNDLDJCQUEyQjt5QkFDOUI7cUJBQ0o7b0JBQ0QsS0FBSyxFQUFFLENBQUM7aUJBQ1g7YUFDSjtRQUNMLENBQUMsQ0FBQyxDQUFDO0lBQ1gsQ0FBQztJQUVPLDBDQUFxQixHQUE3QjtRQUFBLGlCQW9CQztRQW5CRyxLQUFLLElBQUksQ0FBQyxHQUFXLENBQUMsRUFBRSxDQUFDLEdBQUcsSUFBSSxDQUFDLE1BQU0sQ0FBQyxNQUFNLEVBQUUsQ0FBQyxFQUFFLEVBQUU7WUFDakQsSUFBSSxLQUFLLEdBQVcsQ0FBQyxHQUFHLENBQUMsQ0FBQztZQUMxQixJQUFJLFNBQVMsR0FBVyxLQUFLLEdBQUcsS0FBSyxDQUFDO1lBRXRDLElBQUksS0FBSyxHQUFnQixJQUFJLENBQUMsV0FBVyxDQUFDLGFBQWEsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxhQUFhLEVBQUUsbUJBQW1CLEdBQUcsU0FBUyxDQUFDLENBQUM7WUFDL0gsSUFBSSxDQUFDLFdBQVcsQ0FBQyxlQUFlLENBQUMsS0FBSyxFQUFFLFVBQVUsRUFBRSxJQUFJLENBQUMsWUFBWSxDQUFDLENBQUM7WUFFdkUseUJBQXlCO1lBQ3pCLHlCQUF5QjtZQUNyQyxJQUFJLENBQUMsU0FBUyxDQUFDLE1BQU0sQ0FBQyxLQUFLLEVBQUUsV0FBVyxFQUFFLFVBQUMsS0FBVTtnQkFDakQsS0FBSSxDQUFDLGFBQWEsR0FBRyxLQUFLLENBQUMsTUFBTSxDQUFDLGFBQWEsQ0FBQztnQkFDaEQsS0FBSSxDQUFDLHdCQUF3QixHQUFHLEtBQUksQ0FBQyxhQUFhLENBQUMsc0JBQXNCLENBQUM7Z0JBQzFFLEtBQUksQ0FBQyxPQUFPLEdBQUcsSUFBSSxDQUFDO1lBQ3hCLENBQUMsQ0FBQyxDQUFDO1lBRVMsSUFBSSxJQUFJLENBQUMsY0FBYyxLQUFLLE1BQU0sRUFBRTtnQkFDaEMsSUFBSSxDQUFDLG9CQUFvQixDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLEVBQUUsS0FBSyxDQUFDLENBQUM7YUFDcEQ7U0FDSjtJQUNMLENBQUM7SUFFTyx5Q0FBb0IsR0FBNUIsVUFBNkIsS0FBYSxFQUFFLE1BQWM7UUFBMUQsaUJBY0M7UUFiRyxJQUFJLFNBQVMsR0FBVyxLQUFLLEdBQUcsTUFBTSxDQUFDO1FBQ3ZDLElBQUksTUFBTSxHQUFnQixJQUFJLENBQUMsV0FBVyxDQUFDLGFBQWEsQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLGFBQWEsRUFBRSxXQUFXLEdBQUcsU0FBUyxDQUFDLENBQUM7UUFFL0csYUFBYTtRQUNiLElBQUksQ0FBQyxXQUFXLENBQUMsYUFBYSxDQUFDLE1BQU0sRUFBRSxJQUFJLEVBQUUsR0FBRyxDQUFDLENBQUM7UUFDbEQsSUFBSSxDQUFDLGdCQUFnQixDQUFDLElBQUksQ0FBQyxtQkFBbUIsQ0FBQyxDQUFDO1FBQ2hELHlCQUF5QjtRQUN6Qix5QkFBeUI7UUFDakMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxNQUFNLENBQUMsTUFBTSxFQUFFLE9BQU8sRUFBRSxVQUFDLEtBQVU7WUFDOUMsc0JBQXNCO1lBQ3RCLEtBQUksQ0FBQyxPQUFPLEdBQUcsS0FBSyxDQUFDO1lBQ3JCLEtBQUksQ0FBQyxtQkFBbUIsQ0FBQyxLQUFLLENBQUMsQ0FBQztRQUNwQyxDQUFDLENBQUMsQ0FBQztJQUNDLENBQUM7SUFFTyx3Q0FBbUIsR0FBM0IsVUFBNEIsZ0JBQWdDO1FBQWhDLGlDQUFBLEVBQUEsdUJBQWdDO1FBQ3hELElBQUksS0FBSyxHQUFXLENBQUMsQ0FBQztRQUN0QixJQUFJLE9BQU8sR0FBVyxDQUFDLENBQUM7UUFDeEIsSUFBSSxTQUFTLEdBQVcsSUFBSSxDQUFDLFdBQVcsQ0FBQyxvQkFBb0IsQ0FBQyxJQUFJLENBQUMsQ0FBQztRQUNwRSxJQUFJLFlBQVksR0FBVyxTQUFTLEtBQUssTUFBTSxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQztRQUNuRSxJQUFJLFlBQVksR0FBUSxJQUFJLENBQUMsWUFBWSxDQUFDLGVBQWUsQ0FBQyxJQUFJLENBQUMsY0FBYyxFQUFFLFNBQVMsQ0FBQyxDQUFDO1FBQzFGLElBQUksUUFBUSxHQUFZLElBQUksQ0FBQyxXQUFXLENBQUMsUUFBUSxFQUFFLENBQUM7UUFDcEQsSUFBSSxZQUFZLEdBQVEsSUFBSSxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsY0FBYyxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsY0FBYyxHQUFHLElBQUksQ0FBQyxZQUFZLENBQUMsQ0FBQyxDQUFDO1FBQzNHLDZCQUE2QjtRQUM3Qix3R0FBd0c7UUFDeEcsS0FBSyxJQUFJLEdBQUcsSUFBSSxJQUFJLENBQUMsbUJBQW1CLEVBQUU7WUFDdEMsSUFBSSxJQUFJLENBQUMsbUJBQW1CLENBQUMsY0FBYyxDQUFDLEdBQUcsQ0FBQyxFQUFFO2dCQUM5QyxJQUFJLElBQUksR0FBVyxJQUFJLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxDQUFDO2dCQUN0QyxJQUFJLFVBQVUsR0FBUTtvQkFDbEIsS0FBSyxFQUFFLENBQUMsSUFBSSxDQUFDLG1CQUFtQixDQUFDLEdBQUcsQ0FBQyxDQUFDLElBQUksR0FBRyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsbUJBQW1CLENBQUMsR0FBRyxDQUFDLENBQUMsSUFBSTtpQkFDL0YsQ0FBQztnQkFDRixVQUFVLENBQUMsU0FBUyxDQUFDLEdBQUcsT0FBTyxDQUFDO2dCQUVoQyxJQUFJLFFBQVEsRUFBRTtvQkFDVixVQUFVLEdBQUcsTUFBTSxDQUFDLE1BQU0sQ0FBQyxFQUFFLEVBQUUsVUFBVSxFQUFFLFlBQVksQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDO29CQUM5RCxJQUFJLENBQUMsV0FBVyxHQUFHLEtBQUssQ0FBQztvQkFDekIsSUFBSSxLQUFLLEtBQUssQ0FBQyxFQUFFO3dCQUNiLDhCQUE4Qjt3QkFDOUIsSUFBSSxDQUFDLGtCQUFrQixDQUFDLElBQUksRUFBRSxLQUFLLENBQUMsQ0FBQztxQkFDeEM7b0JBQ0Qsc0NBQXNDO2lCQUN6QztxQkFDSTtvQkFDRCxJQUFJLFlBQVksS0FBSyxJQUFJLElBQUksZ0JBQWdCLEVBQUU7d0JBQzNDLElBQUksUUFBUSxHQUFXLE1BQU0sR0FBRyxDQUFDLEtBQUssR0FBRyxDQUFDLENBQUMsQ0FBQzt3QkFDNUMsVUFBVSxHQUFHLE1BQU0sQ0FBQyxNQUFNLENBQUMsRUFBRSxFQUFFLFVBQVUsRUFBRSxZQUFZLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQztxQkFDdEU7b0JBQ0QsMkJBQTJCO29CQUMzQixJQUFJLENBQUMsbUJBQW1CLEVBQUUsQ0FBQztvQkFFM0IsSUFBSSxDQUFDLFdBQVcsQ0FBQyxXQUFXLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxhQUFhLEVBQUUsZUFBZSxHQUFHLFlBQVksQ0FBQyxDQUFDO29CQUV6RixJQUFJLElBQUksQ0FBQyxjQUFjLEtBQUssS0FBSyxJQUFJLEtBQUssS0FBSyxDQUFDLElBQUksSUFBSSxDQUFDLHNCQUFzQixFQUFFO3dCQUM3RSxJQUFJLGFBQWEsR0FBWSxDQUFDLElBQUksQ0FBQyxtQkFBbUIsQ0FBQyxHQUFHLENBQUMsQ0FBQyxJQUFJLEtBQUssU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxtQkFBbUIsQ0FBQyxHQUFHLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQzt3QkFDNUgsSUFBSSxDQUFDLDZCQUE2QixDQUFDLGFBQWEsRUFBRSxLQUFLLENBQUMsQ0FBQztxQkFDNUQ7aUJBQ0o7Z0JBRUQsS0FBSyxJQUFJLElBQUksSUFBSSxVQUFVLEVBQUU7b0JBQ3pCLElBQUksVUFBVSxDQUFDLGNBQWMsQ0FBQyxJQUFJLENBQUMsRUFBRTt3QkFDakMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxlQUFlLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxhQUFhLEVBQUUsSUFBSSxFQUFFLFVBQVUsQ0FBQyxJQUFJLENBQUMsR0FBRyxHQUFHLENBQUMsQ0FBQztxQkFDOUY7aUJBQ0o7Z0JBQ0QsS0FBSyxFQUFFLENBQUM7Z0JBQ1IsT0FBTyxJQUFJLFVBQVUsQ0FBQyxLQUFLLENBQUM7YUFDL0I7U0FDSjtJQUNMLENBQUM7SUFFTyx5Q0FBb0IsR0FBNUIsVUFBNkIsS0FBYSxFQUFFLFVBQWtCO1FBQzFELElBQUksSUFBSSxDQUFDLFdBQVcsQ0FBQyxRQUFRLEVBQUU7WUFBRSxPQUFPO1FBQ3hDLElBQUksQ0FBQyxJQUFJLENBQUMsT0FBTztZQUFFLE9BQU87UUFFMUIsSUFBSSxTQUFTLEdBQVcsSUFBSSxDQUFDLFdBQVcsQ0FBQyxvQkFBb0IsQ0FBQyxJQUFJLENBQUMsQ0FBQztRQUNwRSxJQUFJLFNBQVMsR0FBVyxDQUFDLElBQUksQ0FBQyxXQUFXLEtBQUssVUFBVSxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDO1FBQy9FLElBQUksa0JBQWtCLEdBQVEsSUFBSSxDQUFDLGFBQWEsQ0FBQyxxQkFBcUIsRUFBRSxDQUFDO1FBQ3pFLElBQUksc0JBQXNCLEdBQVEsSUFBSSxDQUFDLHdCQUF3QixDQUFDLHFCQUFxQixFQUFFLENBQUM7UUFFeEYsa0JBQWtCLEdBQUcsQ0FBQyxJQUFJLENBQUMsV0FBVyxLQUFLLFVBQVUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxrQkFBa0IsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLGtCQUFrQixDQUFDLEtBQUssQ0FBQztRQUM5RyxzQkFBc0IsR0FBRyxDQUFDLElBQUksQ0FBQyxXQUFXLEtBQUssVUFBVSxDQUFDLENBQUMsQ0FBQyxDQUFDLHNCQUFzQixDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsc0JBQXNCLENBQUMsS0FBSyxDQUFDO1FBRTFILElBQUksY0FBYyxHQUFXLElBQUksQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLGNBQWMsQ0FBQyxrQkFBa0IsQ0FBQyxzQkFBc0IsR0FBRyxrQkFBa0IsRUFBRSxVQUFVLENBQUMsQ0FBQyxDQUFDO1FBRXpJLElBQUksS0FBSyxHQUFXLElBQUksQ0FBQyxZQUFZLENBQUMsb0JBQW9CLENBQUMsS0FBSyxDQUFDLENBQUM7UUFDbEUsY0FBYyxHQUFHLElBQUksQ0FBQyxZQUFZLENBQUMsb0JBQW9CLENBQUMsY0FBYyxDQUFDLENBQUM7UUFFeEUsSUFBSSxtQkFBbUIsR0FBVyxJQUFJLENBQUMsY0FBYyxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsd0JBQXdCLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxFQUFFLEdBQUcsQ0FBQyxDQUFDO1FBQ2pILEtBQUssR0FBRyxJQUFJLENBQUMsWUFBWSxDQUFDLGdCQUFnQixDQUFDLElBQUksQ0FBQyxtQkFBbUIsRUFBRSxtQkFBbUIsRUFBRSxLQUFLLENBQUMsQ0FBQztRQUVqRyxJQUFJLE9BQU8sR0FBVyxjQUFjLEdBQUcsS0FBSyxDQUFDO1FBRTdDLElBQUksbUJBQW1CLEdBQVE7WUFDM0IsS0FBSyxFQUFFLEVBQUU7WUFDVCxLQUFLLEVBQUUsRUFBRTtTQUNaLENBQUM7UUFDRixtQkFBbUIsQ0FBQyxPQUFPLENBQUMsQ0FBQyxTQUFTLENBQUMsR0FBRyxLQUFLLENBQUM7UUFDaEQsbUJBQW1CLENBQUMsT0FBTyxDQUFDLENBQUMsU0FBUyxDQUFDLEdBQUcsS0FBSyxDQUFDO1FBQ2hELG1CQUFtQixDQUFDLE9BQU8sQ0FBQyxDQUFDLFNBQVMsQ0FBQyxHQUFHLE9BQU8sQ0FBQztRQUNsRCxNQUFNLENBQUMsY0FBYyxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsY0FBYyxHQUFHLElBQUksQ0FBQyxZQUFZLEVBQUUsSUFBSSxDQUFDLFNBQVMsQ0FBQyxtQkFBbUIsQ0FBQyxDQUFDLENBQUM7UUFFNUcsSUFBSSxDQUFDLFdBQVcsQ0FBQyxlQUFlLENBQUMsSUFBSSxDQUFDLHdCQUF3QixFQUFFLFNBQVMsRUFBRSxLQUFLLEdBQUcsR0FBRyxDQUFDLENBQUM7UUFDeEYsSUFBSSxDQUFDLFdBQVcsQ0FBQyxlQUFlLENBQUMsSUFBSSxDQUFDLGFBQWEsRUFBRSxTQUFTLEVBQUUsS0FBSyxHQUFHLEdBQUcsQ0FBQyxDQUFDO1FBQzdFLElBQUksQ0FBQyxXQUFXLENBQUMsZUFBZSxDQUFDLElBQUksQ0FBQyxhQUFhLEVBQUUsU0FBUyxFQUFFLE9BQU8sR0FBRyxHQUFHLENBQUMsQ0FBQztJQUVuRixDQUFDO0lBRU8sd0NBQW1CLEdBQTNCLFVBQTRCLEtBQWE7UUFDckMsSUFBSSxTQUFTLEdBQVcsSUFBSSxDQUFDLFdBQVcsQ0FBQyxvQkFBb0IsQ0FBQyxJQUFJLENBQUMsQ0FBQztRQUNwRSxJQUFJLENBQUMsbUJBQW1CLEdBQUcsQ0FBQyxJQUFJLENBQUMsbUJBQW1CLENBQUM7UUFFckQsSUFBSSxDQUFDLFdBQVcsQ0FBQyxRQUFRLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxhQUFhLEVBQUUsV0FBVyxDQUFDLENBQUM7UUFDcEUsSUFBSSxDQUFDLFdBQVcsQ0FBQyxlQUFlLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxhQUFhLEVBQUUsZUFBZSxHQUFHLFNBQVMsRUFBRSxJQUFJLENBQUMsbUJBQW1CLENBQUMsQ0FBQztRQUNySCxJQUFJLENBQUMsZ0JBQWdCLENBQUMsSUFBSSxDQUFDLG1CQUFtQixDQUFDLENBQUM7UUFDaEQsSUFBSSxDQUFDLGNBQWMsQ0FBQyxVQUFVLEVBQUUsQ0FBQztJQUNyQyxDQUFDO0lBRU8sd0NBQW1CLEdBQTNCO1FBQ0ksSUFBSSxDQUFDLFdBQVcsQ0FBQyxvQkFBb0IsQ0FBQyxTQUFTLEVBQUUsSUFBSSxDQUFDLEVBQUUsQ0FBQyxhQUFhLENBQUMsQ0FBQztJQUM1RSxDQUFDO0lBRU8sdUNBQWtCLEdBQTFCLFVBQTJCLEtBQWEsRUFBRSxNQUFjO1FBQXhELGlCQXFCQztRQXBCRyxJQUFJLFFBQVEsR0FBWSxJQUFJLENBQUMsV0FBVyxDQUFDLFFBQVEsRUFBRSxDQUFDO1FBQ3BELElBQUksUUFBUSxHQUFnQixJQUFJLENBQUMsRUFBRSxDQUFDLGFBQWEsQ0FBQyxhQUFhLENBQUMsU0FBUyxDQUFDLENBQUM7UUFDM0UsSUFBSSxRQUFRLElBQUksSUFBSSxDQUFDLGNBQWMsS0FBSyxLQUFLLElBQUksUUFBUSxLQUFLLElBQUksSUFBSSxJQUFJLENBQUMsZUFBZSxFQUFFO1lBQ3hGLDJCQUEyQjtZQUMzQiw0Q0FBNEM7WUFDNUMsSUFBSSxTQUFTLEdBQVcsUUFBUSxDQUFDO1lBRWpDLElBQUksTUFBTSxHQUFnQixJQUFJLENBQUMsV0FBVyxDQUFDLGFBQWEsQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDLGFBQWEsRUFBRSxrREFBa0QsR0FBRyxTQUFTLENBQUMsQ0FBQztZQUVoSixlQUFlO1lBQ2YsV0FBVyxHQUFHLElBQUksQ0FBQyxXQUFXLENBQUMsYUFBYSxDQUFDLE1BQU0sRUFBRSxJQUFJLEVBQUUsR0FBRyxDQUFDLENBQUM7WUFDaEUsSUFBSSxDQUFDLGFBQWEsQ0FBQyxJQUFJLENBQUMsY0FBYyxDQUFDLENBQUM7WUFFeEMsMkJBQTJCO1lBQzNCLDJCQUEyQjtZQUN2QyxJQUFJLENBQUMsU0FBUyxDQUFDLE1BQU0sQ0FBQyxNQUFNLEVBQUUsT0FBTyxFQUFFLFVBQUMsS0FBVTtnQkFDOUMsS0FBSSxDQUFDLGNBQWMsR0FBRyxDQUFDLEtBQUksQ0FBQyxjQUFjLENBQUM7Z0JBQzNDLEtBQUksQ0FBQyxjQUFjLENBQUMsYUFBYSxDQUFDLEtBQUksQ0FBQyxjQUFjLENBQUMsQ0FBQztZQUMzRCxDQUFDLENBQUMsQ0FBQztTQUNNO0lBQ0wsQ0FBQztJQUVPLDJDQUFzQixHQUE5QjtRQUFBLGlCQU9DO1FBTkcsSUFBSSxJQUFJLENBQUMsY0FBYyxLQUFLLEtBQUssRUFBRTtZQUMvQixJQUFJLENBQUMsY0FBYyxDQUFDLGVBQWUsRUFBRTtpQkFDaEMsU0FBUyxDQUFDLFVBQUEsYUFBYTtnQkFDcEIsS0FBSSxDQUFDLDZCQUE2QixDQUFDLGFBQWEsQ0FBQyxDQUFDO1lBQ3RELENBQUMsQ0FBQyxDQUFDO1NBQ1Y7SUFDTCxDQUFDO0lBRU8sa0RBQTZCLEdBQXJDLFVBQXNDLGFBQXNCLEVBQUUsUUFBa0I7UUFBaEYsaUJBb0RDO1FBbkRHLG1DQUFtQztRQUNuQyxRQUFRLEdBQUcsQ0FBQyxPQUFPLFFBQVEsS0FBSyxXQUFXLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUM7UUFDL0QsSUFBSSxTQUFTLEdBQWdCLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLGFBQWEsQ0FBQztRQUNsRSxJQUFJLFFBQVEsR0FBZ0IsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsYUFBYSxDQUFDO1FBQ2pFLElBQUksUUFBUSxHQUFZLElBQUksQ0FBQyxXQUFXLENBQUMsUUFBUSxFQUFFLENBQUM7UUFDcEQsSUFBSSxXQUFXLEdBQVksQ0FBQyxJQUFJLENBQUMsY0FBYyxLQUFLLGFBQWEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQztRQUNsRixJQUFJLENBQUMsY0FBYyxHQUFHLGFBQWEsQ0FBQztRQUNwQyxJQUFJLFFBQVEsRUFBRTtZQUNWLElBQUksQ0FBQyxXQUFXLENBQUMsUUFBUSxDQUFDLFNBQVMsRUFBRSxXQUFXLENBQUMsQ0FBQztZQUNsRCxJQUFJLENBQUMsV0FBVyxDQUFDLFFBQVEsQ0FBQyxRQUFRLEVBQUUsV0FBVyxDQUFDLENBQUM7U0FDcEQ7UUFFRCxJQUFJLFFBQVEsSUFBSSxJQUFJLENBQUMsc0JBQXNCLEVBQUU7WUFDekMsMkJBQTJCO1lBQzNCLElBQUksZ0JBQWdCLEdBQVcsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUM7WUFDekQsSUFBSSxTQUFTLEdBQVcsSUFBSSxDQUFDLFdBQVcsQ0FBQyxvQkFBb0IsQ0FBQyxJQUFJLENBQUMsQ0FBQztZQUNwRSxJQUFJLFlBQVksR0FBVyxDQUFDLFNBQVMsS0FBSyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUM7WUFDckUsSUFBSSxRQUFRLEdBQVksQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsYUFBYSxDQUFDLENBQUMsQ0FBQyxDQUFDLGFBQWEsQ0FBQztZQUVwRSxJQUFJLFdBQVcsR0FBZSxDQUFDLEVBQUUsQ0FBQyxDQUFDO1lBQ25DLElBQUksUUFBUSxFQUFFO2dCQUNWLElBQUksQ0FBQyxlQUFlLEdBQUcsUUFBUSxDQUFDLHFCQUFxQixFQUFFLENBQUMsS0FBSyxDQUFDO2dCQUM5RCxXQUFXLEdBQUc7b0JBQ1YsRUFBRSxPQUFPLEVBQUUsSUFBSSxDQUFDLGVBQWUsR0FBRyxJQUFJLEVBQUU7b0JBQ3hDLEVBQUUsT0FBTyxFQUFFLE1BQU0sRUFBRTtpQkFDdEIsQ0FBQzthQUNMO2lCQUNJO2dCQUNELFdBQVcsR0FBRztvQkFDVixFQUFFLE9BQU8sRUFBRSxNQUFNLEVBQUU7b0JBQ25CLEVBQUUsT0FBTyxFQUFFLElBQUksQ0FBQyxlQUFlLEdBQUcsSUFBSSxFQUFFO2lCQUMzQyxDQUFDO2FBQ0w7WUFDRCxJQUFJLENBQUMsYUFBYSxDQUFDLGFBQWEsQ0FBQyxDQUFDO1lBQ2xDLElBQUksQ0FBQyxXQUFXLENBQUMsZUFBZSxDQUFDLFFBQVEsRUFBRSxZQUFZLEVBQUUsUUFBUSxDQUFDLENBQUM7WUFDbkUsSUFBSSxDQUFDLFdBQVcsQ0FBQyxlQUFlLENBQUMsU0FBUyxFQUFFLGtCQUFrQixHQUFHLFlBQVksR0FBRyxHQUFHLEdBQUcsZ0JBQWdCLEVBQUUsUUFBUSxDQUFDLENBQUM7WUFFbEgsSUFBSSxRQUFRLElBQUksQ0FBQyxXQUFXLEVBQUU7Z0JBQzFCLElBQUksQ0FBQyxXQUFXLENBQUMsbUJBQW1CLENBQ2hDLFFBQVEsRUFDUixTQUFTLEVBQ1QsQ0FBQyxXQUFXLEVBQUUsR0FBRyxDQUFDLENBQ3JCLENBQUM7Z0JBRUYsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDLFNBQVMsQ0FBQztvQkFDakIsZ0dBQWdHO29CQUNoRyxLQUFJLENBQUMsY0FBYyxDQUFDLGFBQWEsQ0FBQyxhQUFhLENBQUMsQ0FBQztvQkFDakQsZ0VBQWdFO2dCQUNwRSxDQUFDLENBQUMsQ0FBQzthQUNOO1NBQ0o7SUFDTCxDQUFDO0lBRU8sa0NBQWEsR0FBckIsVUFBc0IsT0FBZ0I7UUFDbEMsSUFBSSxPQUFPLEdBQWdCLElBQUksQ0FBQyxFQUFFLENBQUMsYUFBYSxDQUFDLGFBQWEsQ0FBQyxXQUFXLENBQUMsQ0FBQztRQUM1RSxJQUFJLElBQUksQ0FBQyxjQUFjLEtBQUssS0FBSyxJQUFJLE9BQU8sS0FBSyxJQUFJLEVBQUU7WUFDbkQsSUFBSSxDQUFDLFdBQVcsQ0FBQyxlQUFlLENBQUMsT0FBTyxFQUFFLFVBQVUsRUFBRSxDQUFDLE9BQU8sQ0FBQyxDQUFDO1lBQ2hFLElBQUksQ0FBQyxXQUFXLENBQUMsZUFBZSxDQUFDLE9BQU8sRUFBRSxnQkFBZ0IsRUFBRSxPQUFPLENBQUMsQ0FBQztTQUN4RTtJQUNMLENBQUM7SUFFTyxxQ0FBZ0IsR0FBeEIsVUFBeUIsT0FBZ0I7UUFDckMsSUFBSSxTQUFTLEdBQVcsSUFBSSxDQUFDLFdBQVcsQ0FBQyxvQkFBb0IsQ0FBQyxJQUFJLENBQUMsQ0FBQztRQUNwRSxJQUFJLFlBQVksR0FBVyxDQUFDLFNBQVMsS0FBSyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUM7UUFDckUsSUFBSSxPQUFPLEdBQWdCLElBQUksQ0FBQyxFQUFFLENBQUMsYUFBYSxDQUFDLGFBQWEsQ0FBQyxhQUFhLENBQUMsQ0FBQztRQUU5RSxJQUFJLElBQUksQ0FBQyxjQUFjLEtBQUssTUFBTSxJQUFJLE9BQU8sS0FBSyxJQUFJLEVBQUU7WUFDcEQsSUFBSSxDQUFDLFdBQVcsQ0FBQyxlQUFlLENBQUMsT0FBTyxFQUFFLFdBQVcsR0FBRyxTQUFTLEVBQUUsQ0FBQyxPQUFPLENBQUMsQ0FBQztZQUM3RSxJQUFJLENBQUMsV0FBVyxDQUFDLGVBQWUsQ0FBQyxPQUFPLEVBQUUsV0FBVyxHQUFHLFlBQVksRUFBRSxPQUFPLENBQUMsQ0FBQztTQUNsRjtJQUNMLENBQUM7SUFFTyw2QkFBUSxHQUFoQixVQUFpQixJQUFhO1FBQTlCLGlCQTZCQztRQTVCRyxJQUFJLFFBQVEsR0FBWSxJQUFJLENBQUMsV0FBVyxDQUFDLFFBQVEsRUFBRSxDQUFDO1FBQ3BELElBQUksVUFBVSxHQUFnQixJQUFJLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxhQUFhLENBQUMsYUFBYSxDQUFDLGtCQUFrQixDQUFDLENBQUM7UUFDckcsSUFBSSxVQUFVLEtBQUssSUFBSSxFQUFFO1lBQ3JCLFVBQVUsR0FBRyxJQUFJLENBQUMsV0FBVyxDQUFDLGFBQWEsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxhQUFhLEVBQUUsaUJBQWlCLENBQUMsQ0FBQztZQUVyRyxJQUFJLENBQUMsU0FBUyxDQUFDLE1BQU0sQ0FBQyxVQUFVLEVBQUUsT0FBTyxFQUFFLFVBQUMsS0FBVTtnQkFDOUQsS0FBSSxDQUFDLGNBQWMsQ0FBQyxJQUFJLEVBQUUsQ0FBQztZQUMvQixDQUFDLENBQUMsQ0FBQztTQUNNO1FBRUQsSUFBSSxRQUFRLEVBQUU7WUFDVixJQUFJLENBQUMsV0FBVyxDQUFDLGVBQWUsQ0FBQyxVQUFVLEVBQUUsTUFBTSxFQUFFLElBQUksQ0FBQyxDQUFDO1lBQzNELElBQUksSUFBSSxDQUFDLGNBQWMsS0FBSyxNQUFNLEVBQUU7Z0JBQ2hDLElBQUksV0FBVyxHQUFHLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLGFBQWEsQ0FBQyxhQUFhLENBQUMsZUFBZSxDQUFDLENBQUM7Z0JBQ3RGLDRCQUE0QjtnQkFDNUIsSUFBSSxXQUFXLEVBQUU7b0JBQ2IsSUFBSSxpQkFBaUIsR0FBRyxXQUFXLENBQUMscUJBQXFCLEVBQUUsQ0FBQyxNQUFNLENBQUM7b0JBQ25FLElBQUksVUFBVSxHQUFXLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLGFBQWEsQ0FBQyxxQkFBcUIsRUFBRSxDQUFDLE1BQU0sQ0FBQztvQkFDN0YsMkJBQTJCO29CQUMzQixrQ0FBa0M7b0JBQ2xDLElBQUksaUJBQWlCLEdBQUcsVUFBVSxFQUFFO3dCQUNoQyxJQUFJLENBQUMsV0FBVyxDQUFDLGVBQWUsQ0FBQyxVQUFVLEVBQUUsUUFBUSxFQUFFLE1BQU0sQ0FBQyxDQUFDO3dCQUMvRCxJQUFJLENBQUMsV0FBVyxDQUFDLGVBQWUsQ0FBQyxVQUFVLEVBQUUsUUFBUSxFQUFFLGlCQUFpQixHQUFHLElBQUksQ0FBQyxDQUFDO3FCQUNwRjtpQkFDSjtnQkFDRCxJQUFJLENBQUMsV0FBVyxDQUFDLGVBQWUsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxhQUFhLEVBQUUsYUFBYSxFQUFFLElBQUksQ0FBQyxDQUFDO2FBQy9GO1NBQ0o7SUFDTCxDQUFDO0lBRU8sNEJBQU8sR0FBZixVQUFnQixLQUFVO1FBQ3RCLElBQUksSUFBSSxDQUFDLFlBQVk7WUFBRSxPQUFPO1FBQzlCLElBQUksQ0FBQyxJQUFJLENBQUMsT0FBTztZQUFFLE9BQU87UUFFMUIsSUFBSSxTQUFTLEdBQVcsSUFBSSxDQUFDLFdBQVcsQ0FBQyxvQkFBb0IsQ0FBQyxJQUFJLENBQUMsQ0FBQztRQUNwRSw0RUFBNEU7UUFDNUUsSUFBSSxjQUFjLEdBQVEsSUFBSSxDQUFDLEVBQUUsQ0FBQyxhQUFhLENBQUMscUJBQXFCLEVBQUUsQ0FBQztRQUV4RSxJQUFJLEtBQUssR0FBRyxJQUFJLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxPQUFPLEdBQUcsY0FBYyxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUM7UUFDaEUsc0JBQXNCO1FBQ3RCLDJEQUEyRDtRQUMzRCx5QkFBeUI7UUFDekIsSUFBSSxPQUFPLEdBQUcsSUFBSSxDQUFDLGNBQWMsQ0FBQyxrQkFBa0IsQ0FBQyxLQUFLLEVBQUUsY0FBYyxDQUFDLEtBQUssQ0FBQyxDQUFDO1FBQ2xGLHFDQUFxQztRQUVyQyxJQUFJLENBQUMsV0FBVyxDQUFDLFdBQVcsQ0FBQyxJQUFJLENBQUMsYUFBYSxFQUFFLFdBQVcsQ0FBQyxDQUFDO1FBQzlELElBQUksQ0FBQyxvQkFBb0IsQ0FBQyxPQUFPLEVBQUUsY0FBYyxDQUFDLEtBQUssQ0FBQyxDQUFDO1FBQ3pELElBQUksQ0FBQyxjQUFjLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxjQUFjLENBQUMsQ0FBQztJQUNsRCxDQUFDO0lBRU8sOEJBQVMsR0FBakIsVUFBa0IsS0FBVTtRQUN4QixJQUFJLFFBQVEsR0FBWSxJQUFJLENBQUMsV0FBVyxDQUFDLFFBQVEsRUFBRSxDQUFDO1FBQ3BELElBQUksUUFBUSxLQUFLLElBQUksQ0FBQyxhQUFhLEVBQUU7WUFDakMsSUFBSSxDQUFDLHNCQUFzQixHQUFHLElBQUksQ0FBQztZQUNuQyxJQUFJLENBQUMsYUFBYSxHQUFHLFFBQVEsQ0FBQztZQUM5QixJQUFJLENBQUMsY0FBYyxHQUFHLEtBQUssQ0FBQztTQUMvQjtRQUNELElBQUksQ0FBQyxtQkFBbUIsRUFBRSxDQUFDO1FBQzNCLElBQUksQ0FBQyxzQkFBc0IsR0FBRyxLQUFLLENBQUM7SUFDeEMsQ0FBQzs7Z0JBOWJpQixnQkFBZ0I7Z0JBQ1gsU0FBUztnQkFDTixhQUFhO2dCQUNYLGVBQWU7Z0JBQ2xCLFlBQVk7Z0JBQ1QsZUFBZTtnQkFDdEIsTUFBTTs7SUFYbEI7UUFBUixLQUFLLEVBQUU7O21EQUFxQjtJQUNwQjtRQUFSLEtBQUssRUFBRTs7Z0RBQWtCO0lBQ2pCO1FBQVIsS0FBSyxFQUFFOzttREFBcUI7SUFlN0I7UUFEQyxZQUFZLENBQUMsb0JBQW9CLEVBQUUsQ0FBQyxRQUFRLENBQUMsQ0FBQzs7OztpREFLOUM7SUFHRDtRQURDLFlBQVksQ0FBQyxrQkFBa0IsRUFBRSxDQUFDLFFBQVEsQ0FBQyxDQUFDOzs7OytDQUk1QztJQUdEO1FBREMsWUFBWSxDQUFDLGVBQWUsRUFBRSxDQUFDLFFBQVEsQ0FBQyxDQUFDOzs7OzhDQUl6QztJQXZEUSxVQUFVO1FBUnRCLFNBQVMsQ0FBQztZQUNQLFFBQVEsRUFBRSxhQUFhO1lBQ3ZCLFFBQVEsRUFBRSw4RUFBOEU7WUFDeEYsYUFBYSxFQUFFLGlCQUFpQixDQUFDLElBQUk7WUFDckMsU0FBUyxFQUFFLENBQUMsYUFBYSxFQUFFLGVBQWUsRUFBRSxlQUFlLEVBQUUsWUFBWSxDQUFDO1lBQzFFLElBQUksRUFBRSxFQUFFLE9BQU8sRUFBRSxpQkFBaUIsRUFBRTtTQUN2QyxDQUFDO3lDQTZCb0IsZ0JBQWdCO1lBQ1gsU0FBUztZQUNOLGFBQWE7WUFDWCxlQUFlO1lBQ2xCLFlBQVk7WUFDVCxlQUFlO1lBQ3RCLE1BQU07T0FqQ2xCLFVBQVUsQ0EwZHRCO0lBQUQsaUJBQUM7Q0FBQSxBQTFkRCxJQTBkQztTQTFkWSxVQUFVIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgQ29tcG9uZW50LCBJbnB1dCwgT25Jbml0LCBIb3N0TGlzdGVuZXIsIFZpZXdFbmNhcHN1bGF0aW9uLCBWaWV3Q29udGFpbmVyUmVmLCBBZnRlclZpZXdJbml0LCBFbGVtZW50UmVmLCBSZW5kZXJlcjIgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcclxuaW1wb3J0IHsgUm91dGVyLCBOYXZpZ2F0aW9uRW5kIH0gZnJvbSAnQGFuZ3VsYXIvcm91dGVyJztcclxuaW1wb3J0IHsgdGltZXIgfSBmcm9tICdyeGpzJztcclxuaW1wb3J0IHsgS2RQYW5lIH0gZnJvbSAnLi9rZC1wYW5lJztcclxuaW1wb3J0IHsgS2RDb252ZXJ0aW9uU3ZjLCBLZERvbUVsZW1TdmMgfSBmcm9tICcuLi8uLi9rZC1jb21tb24vaW5kZXgnO1xyXG5pbXBvcnQgeyBLZFNwbGl0dGVyU3ZjIH0gZnJvbSAnLi9rZC1zcGxpdHRlci1zdmMnO1xyXG5pbXBvcnQgeyBLZFNwbGl0dGVyRXZlbnQgfSBmcm9tICcuL2tkLXNwbGl0dGVyLWV2ZW50JztcclxuXHJcbkBDb21wb25lbnQoe1xyXG4gICAgc2VsZWN0b3I6ICdrZC1zcGxpdHRlcicsXHJcbiAgICB0ZW1wbGF0ZTogYDxkaXYgY2xhc3M9J3NwbGl0LWNvbnRhaW5lciB7e29yaWVudGF0aW9ufX0nPjxuZy1jb250ZW50PjwvbmctY29udGVudD48L2Rpdj5gLFxyXG4gICAgZW5jYXBzdWxhdGlvbjogVmlld0VuY2Fwc3VsYXRpb24uTm9uZSxcclxuICAgIHByb3ZpZGVyczogW0tkU3BsaXR0ZXJTdmMsIEtkU3BsaXR0ZXJFdmVudCwgS2RDb252ZXJ0aW9uU3ZjLCBLZERvbUVsZW1TdmNdLFxyXG4gICAgaG9zdDogeyAnY2xhc3MnOiAna2R4LXNwbGl0LXBhbmVzJyB9XHJcbn0pXHJcblxyXG5leHBvcnQgY2xhc3MgS2RTcGxpdHRlciBpbXBsZW1lbnRzIE9uSW5pdCwgQWZ0ZXJWaWV3SW5pdCB7XHJcblxyXG4gICAgcHJpdmF0ZSBlbDogRWxlbWVudFJlZjtcclxuICAgIHByaXZhdGUgX2lzRHJhZzogYm9vbGVhbiA9IGZhbHNlO1xyXG4gICAgcHJpdmF0ZSBfZGlzYWJsZURyYWc6IGJvb2xlYW4gPSBmYWxzZTtcclxuICAgIHByaXZhdGUgX3BhbmVzRGVmYXVsdENvbmZpZzogYW55ID0ge307XHJcbiAgICBwcml2YXRlIF9wYW5lczogQXJyYXk8S2RQYW5lPiA9IFtdO1xyXG4gICAgcHJpdmF0ZSBfc2VsZWN0ZWRFbGVtOiBFbGVtZW50O1xyXG4gICAgcHJpdmF0ZSBfc2VsZWN0ZWRQcmV2U2libGluZ0VsZW06IEVsZW1lbnQ7XHJcbiAgICAvLyBwcml2YXRlIF9sb2NhbFN0b3JhZ2U6IG51bWJlcjtcclxuICAgIHByaXZhdGUgX2lzTWFpblBhbmVDb2xsYXBzZTogYm9vbGVhbiA9IGZhbHNlO1xyXG4gICAgcHJpdmF0ZSBfc3BsaXR0ZXJMZXZlbDogc3RyaW5nID0gJyc7XHJcbiAgICBwcml2YXRlIF9lbmFibGVGbG9hdEJ0bjogYm9vbGVhbiA9IGZhbHNlO1xyXG4gICAgcHJpdmF0ZSBfZW5hYmxlU3ViUGFuZUNvbGxhcHNlOiBib29sZWFuID0gZmFsc2U7XHJcbiAgICBwcml2YXRlIF9wcmV2SXNNb2JpbGU6IGJvb2xlYW4gPSBmYWxzZTtcclxuICAgIHByaXZhdGUgX2lzU3ViUGFuZU9wZW46IGJvb2xlYW4gPSBmYWxzZTtcclxuICAgIHByaXZhdGUgX3Nlc3Npb25QcmVmaXg6IHN0cmluZyA9ICcnO1xyXG4gICAgcHJpdmF0ZSBfc2Vzc2lvbk5hbWU6IHN0cmluZyA9ICdzcGxpdHRlcic7XHJcbiAgICBwcml2YXRlIF9pc0ZpcnN0U3dpdGNoVmlld1BvcnQ6IGJvb2xlYW4gPSB0cnVlO1xyXG4gICAgcHJpdmF0ZSBfcHJldldpZHRoU3RhdGU6IG51bWJlciA9IDA7XHJcbiAgICBwcml2YXRlIF9pc01lbnVPcGVuOiBib29sZWFuID0gZmFsc2U7XHJcblxyXG4gICAgQElucHV0KCkgb3JpZW50YXRpb246IHN0cmluZztcclxuICAgIEBJbnB1dCgpIGZsb2F0YnRuOiBzdHJpbmc7XHJcbiAgICBASW5wdXQoKSBjb2xsYXBzaWJsZTogc3RyaW5nO1xyXG5cclxuICAgIGNvbnN0cnVjdG9yKFxyXG4gICAgICAgIHByaXZhdGUgX3ZjcjogVmlld0NvbnRhaW5lclJlZixcclxuICAgICAgICBwcml2YXRlIF9yZW5kZXJlcjogUmVuZGVyZXIyLFxyXG4gICAgICAgIHByaXZhdGUgX3NwbGl0dGVyU3ZjOiBLZFNwbGl0dGVyU3ZjLFxyXG4gICAgICAgIHByaXZhdGUgX2NvbnZlcnRpb25TdmM6IEtkQ29udmVydGlvblN2YyxcclxuICAgICAgICBwcml2YXRlIF9kb21FbGVtU3ZjOiBLZERvbUVsZW1TdmMsXHJcbiAgICAgICAgcHJpdmF0ZSBfc3BsaXR0ZXJFdmVudDogS2RTcGxpdHRlckV2ZW50LFxyXG4gICAgICAgIHByaXZhdGUgX3JvdXRlcjogUm91dGVyXHJcbiAgICApIHtcclxuICAgICAgICB0aGlzLmVsID0gdGhpcy5fdmNyLmVsZW1lbnQ7XHJcbiAgICB9XHJcblxyXG4gICAgQEhvc3RMaXN0ZW5lcignZG9jdW1lbnQ6bW91c2Vtb3ZlJywgWyckZXZlbnQnXSlcclxuICAgIG9uTW91c2Vtb3ZlKGV2ZW50OiBhbnkpOiB2b2lkIHtcclxuICAgICAgICAvLyB0aGlzLm1vdXNlbW92ZS5lbWl0KGV2ZW50KTtcclxuICAgICAgICB0aGlzLl9vbkRyYWcoZXZlbnQpO1xyXG5cclxuICAgIH1cclxuXHJcbiAgICBASG9zdExpc3RlbmVyKCdkb2N1bWVudDptb3VzZXVwJywgWyckZXZlbnQnXSlcclxuICAgIG9uTW91c2V1cChldmVudDogYW55KTogdm9pZCB7XHJcbiAgICAgICAgLy8gdGhpcy5tb3VzZXVwLmVtaXQoZXZlbnQpO1xyXG4gICAgICAgIHRoaXMuX2lzRHJhZyA9IGZhbHNlO1xyXG4gICAgfVxyXG5cclxuICAgIEBIb3N0TGlzdGVuZXIoJ3dpbmRvdzpyZXNpemUnLCBbJyRldmVudCddKVxyXG4gICAgb25SZXNpemUoZXZlbnQ6IGFueSk6IHZvaWQge1xyXG4gICAgICAgIC8vIGNvbnNvbGUubG9nKCdyZXNpemUnKTtcclxuICAgICAgICB0aGlzLl9vblJlc2l6ZShldmVudCk7XHJcbiAgICB9XHJcblxyXG4gICAgbmdPbkluaXQoKTogdm9pZCB7XHJcbiAgICAgICAgdGhpcy5fcHJldklzTW9iaWxlID0gdGhpcy5fZG9tRWxlbVN2Yy5pc01vYmlsZSgpO1xyXG4gICAgICAgIHRoaXMuX2VuYWJsZUZsb2F0QnRuID0gdGhpcy5fY29udmVydGlvblN2Yy5zdHJUb0Jvb2wodGhpcy5mbG9hdGJ0bik7XHJcbiAgICAgICAgdGhpcy5fZW5hYmxlU3ViUGFuZUNvbGxhcHNlID0gdGhpcy5fY29udmVydGlvblN2Yy5zdHJUb0Jvb2wodGhpcy5jb2xsYXBzaWJsZSk7XHJcbiAgICAgICAgLy8gdGhpcy5fcGFuZXNEZWZhdWx0Q29uZmlnID0gdGhpcy5fc3BsaXR0ZXJTdmMuaW5pdFBhbmVzRGVmYXVsdENvbmZpZyh0aGlzLl9wYW5lcyk7XHJcbiAgICAgICAgLy8gY29uc29sZS5sb2codGhpcy5fcGFuZXNEZWZhdWx0Q29uZmlnKTtcclxuICAgIH1cclxuXHJcbiAgICBuZ0FmdGVyVmlld0luaXQoKTogdm9pZCB7XHJcbiAgICAgICAgdGhpcy5fcGFuZXNEZWZhdWx0Q29uZmlnID0gdGhpcy5fc3BsaXR0ZXJTdmMuaW5pdFBhbmVzRGVmYXVsdENvbmZpZyh0aGlzLl9wYW5lcyk7XHJcbiAgICAgICAgdGhpcy5fZGlzYWJsZURyYWcgPSB0aGlzLl9zcGxpdHRlclN2Yy50b0Rpc2FibGVEcmFnKCk7XHJcblxyXG4gICAgICAgIGlmICh0aGlzLl9zcGxpdHRlclN2Yy5pc1N1YlBhbmUodGhpcy5lbC5uYXRpdmVFbGVtZW50KSkge1xyXG4gICAgICAgICAgICAvLyBjb25zb2xlLmxvZygndGhpcyBpcyB0aGUgc3ViIHBhbmUnKTtcclxuICAgICAgICAgICAgdGhpcy5fc3BsaXR0ZXJMZXZlbCA9ICdzdWInO1xyXG4gICAgICAgICAgICBsZXQgbGVmdFBhbmU6IEhUTUxFbGVtZW50ID0gdGhpcy5fcGFuZXNbMF0uZWxlbWVudC5uYXRpdmVFbGVtZW50O1xyXG4gICAgICAgICAgICB0aGlzLl9wcmV2V2lkdGhTdGF0ZSA9IGxlZnRQYW5lLmdldEJvdW5kaW5nQ2xpZW50UmVjdCgpLndpZHRoO1xyXG4gICAgICAgIH1cclxuICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgLy8gY29uc29sZS5sb2coJ3RoaXMgaXMgdGhlIG1haW4gcGFuZScpO1xyXG4gICAgICAgICAgICB0aGlzLl9zcGxpdHRlckxldmVsID0gJ21haW4nO1xyXG5cclxuICAgICAgICAgICAgdGhpcy5fcmVnaXN0ZXJNZW51QnJvYWRjYXN0KCk7XHJcbiAgICAgICAgICAgIHRoaXMuX3NldFRpbnQoZmFsc2UpO1xyXG4gICAgICAgIH1cclxuICAgICAgICAvLyB0aGlzLl9zcGxpdHRlckV2ZW50Lm9uRHJhZygpXHJcbiAgICAgICAgLy8gLnN1YnNjcmliZShfdHlwZSA9PiB7XHJcbiAgICAgICAgLy8gICAgIGNvbnNvbGUubG9nKF90eXBlKTtcclxuICAgICAgICAvLyB9KTtcclxuICAgICAgICAvLyBpc1N1YlNwbGl0dGVyL1xyXG4gICAgICAgIHRoaXMuX3Nlc3Npb25QcmVmaXggPSB0aGlzLl9jb252ZXJ0aW9uU3ZjLmNhbWVsQ2FzZSh0aGlzLl9kb21FbGVtU3ZjLmdldERvY3VtZW50VGhlbWUoKSwgJy0nKSArICdfc3BsaXR0ZXJfJyArIHRoaXMuX3NwbGl0dGVyTGV2ZWw7XHJcblxyXG4gICAgICAgIHRoaXMuX3NldERlZmF1bHRQYW5lU2l6ZSgpO1xyXG4gICAgICAgIHRoaXMuX3NldHVwU3BsaXR0ZXJIYW5kbGVyKCk7XHJcbiAgICAgICAgdGhpcy5fdG9nZ2xlQ29sbGFwc2VTdWJQYW5lKCk7XHJcblxyXG4gICAgICAgIHRoaXMuX2lzRmlyc3RTd2l0Y2hWaWV3UG9ydCA9IGZhbHNlO1xyXG5cclxuICAgICAgICB0aGlzLl9yb3V0ZXIuZXZlbnRzLnN1YnNjcmliZShldmVudCA9PiB7XHJcbiAgICAgICAgICAgIGlmIChldmVudCBpbnN0YW5jZW9mIE5hdmlnYXRpb25FbmQpIHtcclxuICAgICAgICAgICAgICAgIC8vIGNvbnNvbGUubG9nKGV2ZW50LnVybCk7XHJcbiAgICAgICAgICAgICAgICBmb3IgKGxldCBrZXkgaW4gdGhpcy5fcGFuZXMpIHtcclxuICAgICAgICAgICAgICAgICAgICBpZiAodGhpcy5fcGFuZXMuaGFzT3duUHJvcGVydHkoa2V5KSkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBsZXQgcGFuZTogS2RQYW5lID0gdGhpcy5fcGFuZXNba2V5XTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgcGFuZS5lbGVtZW50Lm5hdGl2ZUVsZW1lbnQuc2Nyb2xsVG9wID0gMDtcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9KTtcclxuICAgIH1cclxuXHJcbiAgICBhZGRHcm91cChwYW5lOiBLZFBhbmUpOiBudW1iZXIge1xyXG4gICAgICAgIHRoaXMuX3BhbmVzLnB1c2gocGFuZSk7XHJcbiAgICAgICAgcmV0dXJuIHRoaXMuX3BhbmVzLmxlbmd0aDtcclxuICAgIH1cclxuXHJcbiAgICBwYW5lT25DaGFuZ2UoX3R5cGU6IHN0cmluZyk6IHZvaWQge1xyXG4gICAgICAgIHRoaXMuX3BhbmVzRGVmYXVsdENvbmZpZyA9IHRoaXMuX3NwbGl0dGVyU3ZjLmluaXRQYW5lc0RlZmF1bHRDb25maWcodGhpcy5fcGFuZXMpO1xyXG4gICAgICAgIGlmIChfdHlwZSA9PT0gJ3NpemUnKSB7XHJcbiAgICAgICAgICAgIC8vIGNoYW5naW5nIGVsZW1lbnQgd2lkdGggYmVmb3JlIGFuaW1hdGlvbiBvZiBwYW5lcyBzdGFydFxyXG4gICAgICAgICAgICB0aGlzLl9zZXREZWZhdWx0UGFuZVNpemUoZmFsc2UpO1xyXG4gICAgICAgICAgICBsZXQgYm91bmRpbmdSZWN0ID0gdGhpcy5lbC5uYXRpdmVFbGVtZW50LmdldEJvdW5kaW5nQ2xpZW50UmVjdCgpO1xyXG4gICAgICAgICAgICBpZiAoYm91bmRpbmdSZWN0KSB7XHJcbiAgICAgICAgICAgICAgICAvLyBhZmZlY3RzIGFuaW1hdGlvbiBvZiBsZWZ0IHBhbmUuIFxyXG4gICAgICAgICAgICAgICAgdGhpcy5fcHJldldpZHRoU3RhdGUgPSB0aGlzLl9wYW5lc0RlZmF1bHRDb25maWcuUGFuZTEuc2l6ZSAqIGJvdW5kaW5nUmVjdC53aWR0aDtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF9yZWdpc3Rlck1lbnVCcm9hZGNhc3QoKSB7XHJcbiAgICAgICAgdGhpcy5fc3BsaXR0ZXJFdmVudC5vbigpXHJcbiAgICAgICAgICAgIC5zdWJzY3JpYmUocmVzcG9uZSA9PiB7XHJcbiAgICAgICAgICAgICAgICAvLyBjb25zb2xlLmxvZyhyZXNwb25lKTtcclxuICAgICAgICAgICAgICAgIGxldCBkaXJlY3Rpb246IHN0cmluZyA9IHRoaXMuX2RvbUVsZW1TdmMuZ2V0RG9jdW1lbnREaXJlY3Rpb24odHJ1ZSk7XHJcbiAgICAgICAgICAgICAgICBsZXQgb3BwRGlyZWN0aW9uOiBzdHJpbmcgPSBkaXJlY3Rpb24gPT09ICdsZWZ0JyA/ICdyaWdodCcgOiAnbGVmdCc7XHJcbiAgICAgICAgICAgICAgICBsZXQgY2xhc3NOYW1lOiBzdHJpbmcgPSAncHVzaC1jb250ZW50LScgKyBvcHBEaXJlY3Rpb247XHJcbiAgICAgICAgICAgICAgICBsZXQgaXNNb2JpbGU6IGJvb2xlYW4gPSB0aGlzLl9kb21FbGVtU3ZjLmlzTW9iaWxlKCk7XHJcbiAgICAgICAgICAgICAgICBsZXQgY291bnQ6IG51bWJlciA9IDA7XHJcblxyXG4gICAgICAgICAgICAgICAgZm9yIChsZXQga2V5IGluIHRoaXMuX3BhbmVzKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKHRoaXMuX3BhbmVzLmhhc093blByb3BlcnR5KGtleSkpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgbGV0IHBhbmU6IEtkUGFuZSA9IHRoaXMuX3BhbmVzW2tleV07XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuX2RvbUVsZW1TdmMuc2V0RWxlbWVudENsYXNzKHBhbmUuZWxlbWVudC5uYXRpdmVFbGVtZW50LCAnYW5pbWF0aW9uJywgaXNNb2JpbGUpO1xyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgaWYgKGNvdW50ICE9PSAwKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAoIWlzTW9iaWxlKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5fZG9tRWxlbVN2Yy5yZW1vdmVDbGFzcyhwYW5lLmVsZW1lbnQubmF0aXZlRWxlbWVudCwgY2xhc3NOYW1lKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuX2lzTWVudU9wZW4gPSAhdGhpcy5faXNNZW51T3BlbjtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAodGhpcy5fc3BsaXR0ZXJMZXZlbCA9PT0gJ21haW4nKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIGNvbnNvbGUubG9nKCdhcHBlbmQgY2xhc3MgJyArIGNsYXNzTmFtZSArICcgaW50byBtYWluIHBhbmUnKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5fZG9tRWxlbVN2Yy5zZXRFbGVtZW50Q2xhc3MocGFuZS5lbGVtZW50Lm5hdGl2ZUVsZW1lbnQsIGNsYXNzTmFtZSwgdGhpcy5faXNNZW51T3Blbik7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuX3NldFRpbnQodGhpcy5faXNNZW51T3Blbik7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKGlzTW9iaWxlICYmIHRoaXMuX3NwbGl0dGVyTGV2ZWwgPT09ICdzdWInKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gY29uc29sZS5sb2coJ3N1YiBtYWluJyk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgY291bnQrKztcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH0pO1xyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX3NldHVwU3BsaXR0ZXJIYW5kbGVyKCk6IHZvaWQge1xyXG4gICAgICAgIGZvciAobGV0IGk6IG51bWJlciA9IDE7IGkgPCB0aGlzLl9wYW5lcy5sZW5ndGg7IGkrKykge1xyXG4gICAgICAgICAgICBsZXQgY291bnQ6IG51bWJlciA9IGkgKyAxO1xyXG4gICAgICAgICAgICBsZXQgY2xhc3NOYW1lOiBzdHJpbmcgPSAnc2gtJyArIGNvdW50O1xyXG5cclxuICAgICAgICAgICAgbGV0IG5ld0VsOiBIVE1MRWxlbWVudCA9IHRoaXMuX2RvbUVsZW1TdmMuY3JlYXRlRWxlbWVudCh0aGlzLl9wYW5lc1tpXS5lbGVtZW50Lm5hdGl2ZUVsZW1lbnQsICdzcGxpdHRlci1oYW5kbGVyICcgKyBjbGFzc05hbWUpO1xyXG4gICAgICAgICAgICB0aGlzLl9kb21FbGVtU3ZjLnNldEVsZW1lbnRDbGFzcyhuZXdFbCwgJ2Rpc2FibGVkJywgdGhpcy5fZGlzYWJsZURyYWcpO1xyXG5cclxuICAgICAgICAgICAgLy8gc2V0dXAgT25Nb3VzZURvd25FdmVudFxyXG4gICAgICAgICAgICAvLyBzZXR1cCBPbk1vdXNlRG93bkV2ZW50XHJcbnRoaXMuX3JlbmRlcmVyLmxpc3RlbihuZXdFbCwgJ21vdXNlZG93bicsIChldmVudDogYW55KTogdm9pZCA9PiB7XHJcbiAgICB0aGlzLl9zZWxlY3RlZEVsZW0gPSBldmVudC50YXJnZXQucGFyZW50RWxlbWVudDtcclxuICAgIHRoaXMuX3NlbGVjdGVkUHJldlNpYmxpbmdFbGVtID0gdGhpcy5fc2VsZWN0ZWRFbGVtLnByZXZpb3VzRWxlbWVudFNpYmxpbmc7XHJcbiAgICB0aGlzLl9pc0RyYWcgPSB0cnVlO1xyXG59KTtcclxuXHJcbiAgICAgICAgICAgIGlmICh0aGlzLl9zcGxpdHRlckxldmVsID09PSAnbWFpbicpIHtcclxuICAgICAgICAgICAgICAgIHRoaXMuX3NldHVwQ29sbGFwc2VCdXR0b24odGhpcy5fcGFuZXNbaV0sIGNvdW50KTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF9zZXR1cENvbGxhcHNlQnV0dG9uKF9wYW5lOiBLZFBhbmUsIF9jb3VudDogbnVtYmVyKTogdm9pZCB7XHJcbiAgICAgICAgbGV0IGNsYXNzTmFtZTogc3RyaW5nID0gJ21iLScgKyBfY291bnQ7XHJcbiAgICAgICAgbGV0IG5ld0J0bjogSFRNTEVsZW1lbnQgPSB0aGlzLl9kb21FbGVtU3ZjLmNyZWF0ZUVsZW1lbnQoX3BhbmUuZWxlbWVudC5uYXRpdmVFbGVtZW50LCAnbWVudS1idG4gJyArIGNsYXNzTmFtZSk7XHJcblxyXG4gICAgICAgIC8vIFNldHVwIGljb25cclxuICAgICAgICB0aGlzLl9kb21FbGVtU3ZjLmNyZWF0ZUVsZW1lbnQobmV3QnRuLCAnZmEnLCAnaScpO1xyXG4gICAgICAgIHRoaXMuX3NldENvbGxhcHNlSWNvbih0aGlzLl9pc01haW5QYW5lQ29sbGFwc2UpO1xyXG4gICAgICAgIC8vIHNldHVwIE9uTW91c2VEb3duRXZlbnRcclxuICAgICAgICAvLyBzZXR1cCBPbk1vdXNlRG93bkV2ZW50XHJcbnRoaXMuX3JlbmRlcmVyLmxpc3RlbihuZXdCdG4sICdjbGljaycsIChldmVudDogYW55KTogdm9pZCA9PiB7XHJcbiAgICAvLyBjb25zb2xlLmxvZyhldmVudCk7XHJcbiAgICB0aGlzLl9pc0RyYWcgPSBmYWxzZTtcclxuICAgIHRoaXMuX3RvZ2dsZUNvbGxhcHNlTWVudShfcGFuZSk7XHJcbn0pO1xyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX3NldERlZmF1bHRQYW5lU2l6ZShfdXNlTG9jYWxTdG9yYWdlOiBib29sZWFuID0gdHJ1ZSk6IHZvaWQge1xyXG4gICAgICAgIGxldCBjb3VudDogbnVtYmVyID0gMDtcclxuICAgICAgICBsZXQgb2Zmc2V0WDogbnVtYmVyID0gMDtcclxuICAgICAgICBsZXQgZGlyZWN0aW9uOiBzdHJpbmcgPSB0aGlzLl9kb21FbGVtU3ZjLmdldERvY3VtZW50RGlyZWN0aW9uKHRydWUpO1xyXG4gICAgICAgIGxldCBvcHBEaXJlY3Rpb246IHN0cmluZyA9IGRpcmVjdGlvbiA9PT0gJ2xlZnQnID8gJ3JpZ2h0JyA6ICdsZWZ0JztcclxuICAgICAgICBsZXQgbW9iaWxlQ29uZmlnOiBhbnkgPSB0aGlzLl9zcGxpdHRlclN2Yy5nZXRNb2JpbGVDb25maWcodGhpcy5fc3BsaXR0ZXJMZXZlbCwgZGlyZWN0aW9uKTtcclxuICAgICAgICBsZXQgaXNNb2JpbGU6IGJvb2xlYW4gPSB0aGlzLl9kb21FbGVtU3ZjLmlzTW9iaWxlKCk7XHJcbiAgICAgICAgbGV0IGxvY2FsU3RvcmFnZTogYW55ID0gSlNPTi5wYXJzZSh3aW5kb3cuc2Vzc2lvblN0b3JhZ2UuZ2V0SXRlbSh0aGlzLl9zZXNzaW9uUHJlZml4ICsgdGhpcy5fc2Vzc2lvbk5hbWUpKTtcclxuICAgICAgICAvLyBjb25zb2xlLmxvZyhsb2NhbFN0b3JhZ2UpO1xyXG4gICAgICAgIC8vIGNvbnNvbGUubG9nKCdzZXNzaW9uU3RvcmdlID0gJyt3aW5kb3cuc2Vzc2lvblN0b3JhZ2UuZ2V0SXRlbSh0aGlzLl9zZXNzaW9uUHJlZml4K3RoaXMuX3Nlc3Npb25OYW1lKSk7XHJcbiAgICAgICAgZm9yIChsZXQga2V5IGluIHRoaXMuX3BhbmVzRGVmYXVsdENvbmZpZykge1xyXG4gICAgICAgICAgICBpZiAodGhpcy5fcGFuZXNEZWZhdWx0Q29uZmlnLmhhc093blByb3BlcnR5KGtleSkpIHtcclxuICAgICAgICAgICAgICAgIGxldCBwYW5lOiBLZFBhbmUgPSB0aGlzLl9wYW5lc1tjb3VudF07XHJcbiAgICAgICAgICAgICAgICBsZXQgcGFuZUNvbmZpZzogYW55ID0ge1xyXG4gICAgICAgICAgICAgICAgICAgIHdpZHRoOiAodGhpcy5fcGFuZXNEZWZhdWx0Q29uZmlnW2tleV0uc2l6ZSA+IDEwMCkgPyAxMDAgOiB0aGlzLl9wYW5lc0RlZmF1bHRDb25maWdba2V5XS5zaXplLFxyXG4gICAgICAgICAgICAgICAgfTtcclxuICAgICAgICAgICAgICAgIHBhbmVDb25maWdbZGlyZWN0aW9uXSA9IG9mZnNldFg7XHJcblxyXG4gICAgICAgICAgICAgICAgaWYgKGlzTW9iaWxlKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgcGFuZUNvbmZpZyA9IE9iamVjdC5hc3NpZ24oe30sIHBhbmVDb25maWcsIG1vYmlsZUNvbmZpZ1trZXldKTtcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLl9pc01lbnVPcGVuID0gZmFsc2U7XHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKGNvdW50ID09PSAwKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC8vIGNvbnNvbGUubG9nKCdzaG93IGJ1dHRvbicpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLl9zZXR1cEZsb2F0TWVudUJ0bihwYW5lLCBjb3VudCk7XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIC8vIGNvbnNvbGUubG9nKFwidGhpcyBpcyBtb2JpbGUgdmlld1wiKTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgICAgIGlmIChsb2NhbFN0b3JhZ2UgIT09IG51bGwgJiYgX3VzZUxvY2FsU3RvcmFnZSkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBsZXQgdGVtcE5hbWU6IHN0cmluZyA9ICdQYW5lJyArIChjb3VudCArIDEpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBwYW5lQ29uZmlnID0gT2JqZWN0LmFzc2lnbih7fSwgcGFuZUNvbmZpZywgbG9jYWxTdG9yYWdlW3RlbXBOYW1lXSk7XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIC8vIGNvbnNvbGUubG9nKHBhbmVDb25maWcpO1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuX3JlbW92ZUZsb2F0TWVudUJ0bigpO1xyXG5cclxuICAgICAgICAgICAgICAgICAgICB0aGlzLl9kb21FbGVtU3ZjLnJlbW92ZUNsYXNzKHBhbmUuZWxlbWVudC5uYXRpdmVFbGVtZW50LCAncHVzaC1jb250ZW50LScgKyBvcHBEaXJlY3Rpb24pO1xyXG5cclxuICAgICAgICAgICAgICAgICAgICBpZiAodGhpcy5fc3BsaXR0ZXJMZXZlbCA9PT0gJ3N1YicgJiYgY291bnQgPT09IDEgJiYgdGhpcy5faXNGaXJzdFN3aXRjaFZpZXdQb3J0KSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGxldCBpc1N1YlBhbmVTaG93OiBib29sZWFuID0gKHRoaXMuX3BhbmVzRGVmYXVsdENvbmZpZ1trZXldLnNob3cgIT09IHVuZGVmaW5lZCkgPyB0aGlzLl9wYW5lc0RlZmF1bHRDb25maWdba2V5XS5zaG93IDogdHJ1ZTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5fcHJvY2Vzc1RvZ2dsZUNvbGxhcHNlU3ViUGFuZShpc1N1YlBhbmVTaG93LCBmYWxzZSk7XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgICAgIGZvciAobGV0IGNLZXkgaW4gcGFuZUNvbmZpZykge1xyXG4gICAgICAgICAgICAgICAgICAgIGlmIChwYW5lQ29uZmlnLmhhc093blByb3BlcnR5KGNLZXkpKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuX2RvbUVsZW1TdmMuc2V0RWxlbWVudFN0eWxlKHBhbmUuZWxlbWVudC5uYXRpdmVFbGVtZW50LCBjS2V5LCBwYW5lQ29uZmlnW2NLZXldICsgJyUnKTtcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICBjb3VudCsrO1xyXG4gICAgICAgICAgICAgICAgb2Zmc2V0WCArPSBwYW5lQ29uZmlnLndpZHRoO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX3VwZGF0ZVNwbGl0UGFuZVNpemUoX3Bvc1g6IG51bWJlciwgX2JvdW5kU2l6ZTogbnVtYmVyKSB7XHJcbiAgICAgICAgaWYgKHRoaXMuX2RvbUVsZW1TdmMuaXNNb2JpbGUoKSkgcmV0dXJuO1xyXG4gICAgICAgIGlmICghdGhpcy5faXNEcmFnKSByZXR1cm47XHJcblxyXG4gICAgICAgIGxldCBkaXJlY3Rpb246IHN0cmluZyA9IHRoaXMuX2RvbUVsZW1TdmMuZ2V0RG9jdW1lbnREaXJlY3Rpb24odHJ1ZSk7XHJcbiAgICAgICAgbGV0IGRpbWVudGlvbjogc3RyaW5nID0gKHRoaXMub3JpZW50YXRpb24gPT09ICd2ZXJ0aWNhbCcpID8gJ2hlaWdodCcgOiAnd2lkdGgnO1xyXG4gICAgICAgIGxldCBzZWxlY3RlZEVsZW1Cb3VuZHM6IGFueSA9IHRoaXMuX3NlbGVjdGVkRWxlbS5nZXRCb3VuZGluZ0NsaWVudFJlY3QoKTtcclxuICAgICAgICBsZXQgc2VsZWN0ZWRQcmV2RWxlbUJvdW5kczogYW55ID0gdGhpcy5fc2VsZWN0ZWRQcmV2U2libGluZ0VsZW0uZ2V0Qm91bmRpbmdDbGllbnRSZWN0KCk7XHJcblxyXG4gICAgICAgIHNlbGVjdGVkRWxlbUJvdW5kcyA9ICh0aGlzLm9yaWVudGF0aW9uID09PSAndmVydGljYWwnKSA/IHNlbGVjdGVkRWxlbUJvdW5kcy5oZWlnaHQgOiBzZWxlY3RlZEVsZW1Cb3VuZHMud2lkdGg7XHJcbiAgICAgICAgc2VsZWN0ZWRQcmV2RWxlbUJvdW5kcyA9ICh0aGlzLm9yaWVudGF0aW9uID09PSAndmVydGljYWwnKSA/IHNlbGVjdGVkUHJldkVsZW1Cb3VuZHMuaGVpZ2h0IDogc2VsZWN0ZWRQcmV2RWxlbUJvdW5kcy53aWR0aDtcclxuXHJcbiAgICAgICAgbGV0IHRvdGFsMkVsZW1TaXplOiBudW1iZXIgPSBNYXRoLnJvdW5kKHRoaXMuX2NvbnZlcnRpb25TdmMuY29udmVydFB4VG9QZXJjZW50KHNlbGVjdGVkUHJldkVsZW1Cb3VuZHMgKyBzZWxlY3RlZEVsZW1Cb3VuZHMsIF9ib3VuZFNpemUpKTtcclxuXHJcbiAgICAgICAgbGV0IG1vdmVYOiBudW1iZXIgPSB0aGlzLl9zcGxpdHRlclN2Yy52YWxpZGF0ZVBlcmNlbnRWYWx1ZShfcG9zWCk7XHJcbiAgICAgICAgdG90YWwyRWxlbVNpemUgPSB0aGlzLl9zcGxpdHRlclN2Yy52YWxpZGF0ZVBlcmNlbnRWYWx1ZSh0b3RhbDJFbGVtU2l6ZSk7XHJcblxyXG4gICAgICAgIGxldCBzZWxlY3RlZFByZXZQYW5lS2V5OiBzdHJpbmcgPSB0aGlzLl9jb252ZXJ0aW9uU3ZjLmNhbWVsQ2FzZSh0aGlzLl9zZWxlY3RlZFByZXZTaWJsaW5nRWxlbS5jbGFzc0xpc3RbMV0sICctJyk7XHJcbiAgICAgICAgbW92ZVggPSB0aGlzLl9zcGxpdHRlclN2Yy52YWxpZGF0ZVBhbmVTaXplKHRoaXMuX3BhbmVzRGVmYXVsdENvbmZpZywgc2VsZWN0ZWRQcmV2UGFuZUtleSwgbW92ZVgpO1xyXG5cclxuICAgICAgICBsZXQgY3VyUGFuZTogbnVtYmVyID0gdG90YWwyRWxlbVNpemUgLSBtb3ZlWDtcclxuXHJcbiAgICAgICAgbGV0IHNwbGl0dGVyRmluYWxDb25maWc6IGFueSA9IHtcclxuICAgICAgICAgICAgUGFuZTE6IHt9LFxyXG4gICAgICAgICAgICBQYW5lMjoge31cclxuICAgICAgICB9O1xyXG4gICAgICAgIHNwbGl0dGVyRmluYWxDb25maWdbJ1BhbmUxJ11bZGltZW50aW9uXSA9IG1vdmVYO1xyXG4gICAgICAgIHNwbGl0dGVyRmluYWxDb25maWdbJ1BhbmUyJ11bZGlyZWN0aW9uXSA9IG1vdmVYO1xyXG4gICAgICAgIHNwbGl0dGVyRmluYWxDb25maWdbJ1BhbmUyJ11bZGltZW50aW9uXSA9IGN1clBhbmU7XHJcbiAgICAgICAgd2luZG93LnNlc3Npb25TdG9yYWdlLnNldEl0ZW0odGhpcy5fc2Vzc2lvblByZWZpeCArIHRoaXMuX3Nlc3Npb25OYW1lLCBKU09OLnN0cmluZ2lmeShzcGxpdHRlckZpbmFsQ29uZmlnKSk7XHJcblxyXG4gICAgICAgIHRoaXMuX2RvbUVsZW1TdmMuc2V0RWxlbWVudFN0eWxlKHRoaXMuX3NlbGVjdGVkUHJldlNpYmxpbmdFbGVtLCBkaW1lbnRpb24sIG1vdmVYICsgJyUnKTtcclxuICAgICAgICB0aGlzLl9kb21FbGVtU3ZjLnNldEVsZW1lbnRTdHlsZSh0aGlzLl9zZWxlY3RlZEVsZW0sIGRpcmVjdGlvbiwgbW92ZVggKyAnJScpO1xyXG4gICAgICAgIHRoaXMuX2RvbUVsZW1TdmMuc2V0RWxlbWVudFN0eWxlKHRoaXMuX3NlbGVjdGVkRWxlbSwgZGltZW50aW9uLCBjdXJQYW5lICsgJyUnKTtcclxuXHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfdG9nZ2xlQ29sbGFwc2VNZW51KF9wYW5lOiBLZFBhbmUpIHtcclxuICAgICAgICBsZXQgZGlyZWN0aW9uOiBzdHJpbmcgPSB0aGlzLl9kb21FbGVtU3ZjLmdldERvY3VtZW50RGlyZWN0aW9uKHRydWUpO1xyXG4gICAgICAgIHRoaXMuX2lzTWFpblBhbmVDb2xsYXBzZSA9ICF0aGlzLl9pc01haW5QYW5lQ29sbGFwc2U7XHJcblxyXG4gICAgICAgIHRoaXMuX2RvbUVsZW1TdmMuYWRkQ2xhc3MoX3BhbmUuZWxlbWVudC5uYXRpdmVFbGVtZW50LCAnYW5pbWF0aW9uJyk7XHJcbiAgICAgICAgdGhpcy5fZG9tRWxlbVN2Yy5zZXRFbGVtZW50Q2xhc3MoX3BhbmUuZWxlbWVudC5uYXRpdmVFbGVtZW50LCAncHVzaC1jb250ZW50LScgKyBkaXJlY3Rpb24sIHRoaXMuX2lzTWFpblBhbmVDb2xsYXBzZSk7XHJcbiAgICAgICAgdGhpcy5fc2V0Q29sbGFwc2VJY29uKHRoaXMuX2lzTWFpblBhbmVDb2xsYXBzZSk7XHJcbiAgICAgICAgdGhpcy5fc3BsaXR0ZXJFdmVudC50b2dnbGVNZW51KCk7XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfcmVtb3ZlRmxvYXRNZW51QnRuKCk6IHZvaWQge1xyXG4gICAgICAgIHRoaXMuX2RvbUVsZW1TdmMucmVtb3ZlRWxlbWVudEJ5Q2xhc3MoJy5mbS1idG4nLCB0aGlzLmVsLm5hdGl2ZUVsZW1lbnQpO1xyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX3NldHVwRmxvYXRNZW51QnRuKF9wYW5lOiBLZFBhbmUsIF9jb3VudDogbnVtYmVyKTogdm9pZCB7XHJcbiAgICAgICAgbGV0IGlzTW9iaWxlOiBib29sZWFuID0gdGhpcy5fZG9tRWxlbVN2Yy5pc01vYmlsZSgpO1xyXG4gICAgICAgIGxldCBmbG9hdEJ0bjogSFRNTEVsZW1lbnQgPSB0aGlzLmVsLm5hdGl2ZUVsZW1lbnQucXVlcnlTZWxlY3RvcignLmZtLWJ0bicpO1xyXG4gICAgICAgIGlmIChpc01vYmlsZSAmJiB0aGlzLl9zcGxpdHRlckxldmVsID09PSAnc3ViJyAmJiBmbG9hdEJ0biA9PT0gbnVsbCAmJiB0aGlzLl9lbmFibGVGbG9hdEJ0bikge1xyXG4gICAgICAgICAgICAvLyBjb25zb2xlLmxvZygnc3ViIG1haW4nKTtcclxuICAgICAgICAgICAgLy8gbGV0IGNsYXNzTmFtZXM6IHN0cmluZyA9ICdmbWItJyArIF9jb3VudDtcclxuICAgICAgICAgICAgbGV0IGNsYXNzTmFtZTogc3RyaW5nID0gJ2ZtLWJ0bic7XHJcblxyXG4gICAgICAgICAgICBsZXQgbmV3QnRuOiBIVE1MRWxlbWVudCA9IHRoaXMuX2RvbUVsZW1TdmMuY3JlYXRlRWxlbWVudCh0aGlzLmVsLm5hdGl2ZUVsZW1lbnQsICdidG4gYnRuLWZsb2F0LWJvdHRvbS1yaWdodCBidG4tY2lyY2xlIGJ0bi1jb2xvciAnICsgY2xhc3NOYW1lKTtcclxuXHJcbiAgICAgICAgICAgIC8vIC8vU2V0dXAgaWNvblxyXG4gICAgICAgICAgICBIVE1MRWxlbWVudCA9IHRoaXMuX2RvbUVsZW1TdmMuY3JlYXRlRWxlbWVudChuZXdCdG4sICdmYScsICdpJyk7XHJcbiAgICAgICAgICAgIHRoaXMuX3NldEZsb2F0SWNvbih0aGlzLl9pc1N1YlBhbmVPcGVuKTtcclxuXHJcbiAgICAgICAgICAgIC8vIC8vc2V0dXAgT25Nb3VzZURvd25FdmVudFxyXG4gICAgICAgICAgICAvLyAvL3NldHVwIE9uTW91c2VEb3duRXZlbnRcclxudGhpcy5fcmVuZGVyZXIubGlzdGVuKG5ld0J0biwgJ2NsaWNrJywgKGV2ZW50OiBhbnkpOiB2b2lkID0+IHtcclxuICAgIHRoaXMuX2lzU3ViUGFuZU9wZW4gPSAhdGhpcy5faXNTdWJQYW5lT3BlbjtcclxuICAgIHRoaXMuX3NwbGl0dGVyRXZlbnQudG9nZ2xlU3ViUGFuZSh0aGlzLl9pc1N1YlBhbmVPcGVuKTtcclxufSk7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX3RvZ2dsZUNvbGxhcHNlU3ViUGFuZSgpIHtcclxuICAgICAgICBpZiAodGhpcy5fc3BsaXR0ZXJMZXZlbCA9PT0gJ3N1YicpIHtcclxuICAgICAgICAgICAgdGhpcy5fc3BsaXR0ZXJFdmVudC5vblRvZ2dsZVN1YlBhbmUoKVxyXG4gICAgICAgICAgICAgICAgLnN1YnNjcmliZShpc1N1YlBhbmVPcGVuID0+IHtcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLl9wcm9jZXNzVG9nZ2xlQ29sbGFwc2VTdWJQYW5lKGlzU3ViUGFuZU9wZW4pO1xyXG4gICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX3Byb2Nlc3NUb2dnbGVDb2xsYXBzZVN1YlBhbmUoaXNTdWJQYW5lT3BlbjogYm9vbGVhbiwgX2FuaW1hdGU/OiBib29sZWFuKSB7XHJcbiAgICAgICAgLy8gY29uc29sZS5sb2coJ2luIHRoaXMgZnVuY3Rpb24/JylcclxuICAgICAgICBfYW5pbWF0ZSA9ICh0eXBlb2YgX2FuaW1hdGUgPT09ICd1bmRlZmluZWQnKSA/IHRydWUgOiBfYW5pbWF0ZTtcclxuICAgICAgICBsZXQgcmlnaHRQYW5lOiBIVE1MRWxlbWVudCA9IHRoaXMuX3BhbmVzWzFdLmVsZW1lbnQubmF0aXZlRWxlbWVudDtcclxuICAgICAgICBsZXQgbGVmdFBhbmU6IEhUTUxFbGVtZW50ID0gdGhpcy5fcGFuZXNbMF0uZWxlbWVudC5uYXRpdmVFbGVtZW50O1xyXG4gICAgICAgIGxldCBpc01vYmlsZTogYm9vbGVhbiA9IHRoaXMuX2RvbUVsZW1TdmMuaXNNb2JpbGUoKTtcclxuICAgICAgICBsZXQgaXNTYW1lU3RhdGU6IGJvb2xlYW4gPSAodGhpcy5faXNTdWJQYW5lT3BlbiA9PT0gaXNTdWJQYW5lT3BlbikgPyB0cnVlIDogZmFsc2U7XHJcbiAgICAgICAgdGhpcy5faXNTdWJQYW5lT3BlbiA9IGlzU3ViUGFuZU9wZW47XHJcbiAgICAgICAgaWYgKF9hbmltYXRlKSB7XHJcbiAgICAgICAgICAgIHRoaXMuX2RvbUVsZW1TdmMuYWRkQ2xhc3MocmlnaHRQYW5lLCAnYW5pbWF0aW9uJyk7XHJcbiAgICAgICAgICAgIHRoaXMuX2RvbUVsZW1TdmMuYWRkQ2xhc3MobGVmdFBhbmUsICdhbmltYXRpb24nKTtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIGlmIChpc01vYmlsZSB8fCB0aGlzLl9lbmFibGVTdWJQYW5lQ29sbGFwc2UpIHtcclxuICAgICAgICAgICAgLy8gY29uc29sZS5sb2coJ2FtIGkgaW4/Jyk7XHJcbiAgICAgICAgICAgIGxldCBhbmltYXRlRGlyZWN0aW9uOiBzdHJpbmcgPSAoaXNNb2JpbGUpID8gJ2luJyA6ICdvdXQnO1xyXG4gICAgICAgICAgICBsZXQgZGlyZWN0aW9uOiBzdHJpbmcgPSB0aGlzLl9kb21FbGVtU3ZjLmdldERvY3VtZW50RGlyZWN0aW9uKHRydWUpO1xyXG4gICAgICAgICAgICBsZXQgb3BwRGlyZWN0aW9uOiBzdHJpbmcgPSAoZGlyZWN0aW9uID09PSAnbGVmdCcpID8gJ3JpZ2h0JyA6ICdsZWZ0JztcclxuICAgICAgICAgICAgbGV0IGFkZENsYXNzOiBib29sZWFuID0gKGlzTW9iaWxlKSA/IGlzU3ViUGFuZU9wZW4gOiAhaXNTdWJQYW5lT3BlbjtcclxuXHJcbiAgICAgICAgICAgIGxldCB3aWR0aENvbmZpZzogQXJyYXk8YW55PiA9IFt7fV07XHJcbiAgICAgICAgICAgIGlmIChhZGRDbGFzcykge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5fcHJldldpZHRoU3RhdGUgPSBsZWZ0UGFuZS5nZXRCb3VuZGluZ0NsaWVudFJlY3QoKS53aWR0aDtcclxuICAgICAgICAgICAgICAgIHdpZHRoQ29uZmlnID0gW1xyXG4gICAgICAgICAgICAgICAgICAgIHsgJ3dpZHRoJzogdGhpcy5fcHJldldpZHRoU3RhdGUgKyAncHgnIH0sXHJcbiAgICAgICAgICAgICAgICAgICAgeyAnd2lkdGgnOiAnMTAwJScgfVxyXG4gICAgICAgICAgICAgICAgXTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgICAgIHdpZHRoQ29uZmlnID0gW1xyXG4gICAgICAgICAgICAgICAgICAgIHsgJ3dpZHRoJzogJzEwMCUnIH0sXHJcbiAgICAgICAgICAgICAgICAgICAgeyAnd2lkdGgnOiB0aGlzLl9wcmV2V2lkdGhTdGF0ZSArICdweCcgfVxyXG4gICAgICAgICAgICAgICAgXTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB0aGlzLl9zZXRGbG9hdEljb24oaXNTdWJQYW5lT3Blbik7XHJcbiAgICAgICAgICAgIHRoaXMuX2RvbUVsZW1TdmMuc2V0RWxlbWVudENsYXNzKGxlZnRQYW5lLCAnZnVsbC13aWR0aCcsIGFkZENsYXNzKTtcclxuICAgICAgICAgICAgdGhpcy5fZG9tRWxlbVN2Yy5zZXRFbGVtZW50Q2xhc3MocmlnaHRQYW5lLCAncHVzaC1zdWJjb250ZW50LScgKyBvcHBEaXJlY3Rpb24gKyAnLScgKyBhbmltYXRlRGlyZWN0aW9uLCBhZGRDbGFzcyk7XHJcblxyXG4gICAgICAgICAgICBpZiAoX2FuaW1hdGUgJiYgIWlzU2FtZVN0YXRlKSB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLl9kb21FbGVtU3ZjLmludm9rZUVsZW1lbnRNZXRob2QoXHJcbiAgICAgICAgICAgICAgICAgICAgbGVmdFBhbmUsXHJcbiAgICAgICAgICAgICAgICAgICAgJ2FuaW1hdGUnLFxyXG4gICAgICAgICAgICAgICAgICAgIFt3aWR0aENvbmZpZywgNTAwXVxyXG4gICAgICAgICAgICAgICAgKTtcclxuXHJcbiAgICAgICAgICAgICAgICB0aW1lcig1MDApLnN1YnNjcmliZSgoKTogdm9pZCA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgLy8gbmVlZCBmaXhpbmcgaW4gdGhlIGZ1dHVyZS4gdGhpcyBldmVudCBpcyBiZWluZyB0cmlnZ2VyZWQgdHdpY2UuIGFub3RoZXIgdGltZSBpcyBpbiBrZC1leGFtcGxlXHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5fc3BsaXR0ZXJFdmVudC50b2dnbGVTdWJQYW5lKGlzU3ViUGFuZU9wZW4pO1xyXG4gICAgICAgICAgICAgICAgICAgIC8vIHRoaXMuX3NwbGl0dGVyRXZlbnQudG9nZ2xlQW5pbWF0aW9uU3ViUGFuZUVuZChpc1N1YlBhbmVPcGVuKTtcclxuICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX3NldEZsb2F0SWNvbihfaXNPcGVuOiBib29sZWFuKSB7XHJcbiAgICAgICAgbGV0IGJ0bkljb246IEhUTUxFbGVtZW50ID0gdGhpcy5lbC5uYXRpdmVFbGVtZW50LnF1ZXJ5U2VsZWN0b3IoJy5mbS1idG4gaScpO1xyXG4gICAgICAgIGlmICh0aGlzLl9zcGxpdHRlckxldmVsID09PSAnc3ViJyAmJiBidG5JY29uICE9PSBudWxsKSB7XHJcbiAgICAgICAgICAgIHRoaXMuX2RvbUVsZW1TdmMuc2V0RWxlbWVudENsYXNzKGJ0bkljb24sICdrZC1saXN0cycsICFfaXNPcGVuKTtcclxuICAgICAgICAgICAgdGhpcy5fZG9tRWxlbVN2Yy5zZXRFbGVtZW50Q2xhc3MoYnRuSWNvbiwgJ2tkLWNsb3NlLXJvdW5kJywgX2lzT3Blbik7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX3NldENvbGxhcHNlSWNvbihfaXNPcGVuOiBib29sZWFuKSB7XHJcbiAgICAgICAgbGV0IGRpcmVjdGlvbjogc3RyaW5nID0gdGhpcy5fZG9tRWxlbVN2Yy5nZXREb2N1bWVudERpcmVjdGlvbih0cnVlKTtcclxuICAgICAgICBsZXQgb3BwRGlyZWN0aW9uOiBzdHJpbmcgPSAoZGlyZWN0aW9uID09PSAnbGVmdCcpID8gJ3JpZ2h0JyA6ICdsZWZ0JztcclxuICAgICAgICBsZXQgYnRuSWNvbjogSFRNTEVsZW1lbnQgPSB0aGlzLmVsLm5hdGl2ZUVsZW1lbnQucXVlcnlTZWxlY3RvcignLm1lbnUtYnRuIGknKTtcclxuXHJcbiAgICAgICAgaWYgKHRoaXMuX3NwbGl0dGVyTGV2ZWwgPT09ICdtYWluJyAmJiBidG5JY29uICE9PSBudWxsKSB7XHJcbiAgICAgICAgICAgIHRoaXMuX2RvbUVsZW1TdmMuc2V0RWxlbWVudENsYXNzKGJ0bkljb24sICdmYS1hbmdsZS0nICsgZGlyZWN0aW9uLCAhX2lzT3Blbik7XHJcbiAgICAgICAgICAgIHRoaXMuX2RvbUVsZW1TdmMuc2V0RWxlbWVudENsYXNzKGJ0bkljb24sICdmYS1hbmdsZS0nICsgb3BwRGlyZWN0aW9uLCBfaXNPcGVuKTtcclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfc2V0VGludChfYWRkOiBib29sZWFuKSB7XHJcbiAgICAgICAgbGV0IGlzTW9iaWxlOiBib29sZWFuID0gdGhpcy5fZG9tRWxlbVN2Yy5pc01vYmlsZSgpO1xyXG4gICAgICAgIGxldCBvdmVybGF5RGl2OiBIVE1MRWxlbWVudCA9IHRoaXMuX3BhbmVzWzFdLmVsZW1lbnQubmF0aXZlRWxlbWVudC5xdWVyeVNlbGVjdG9yKCcuY29udGVudC1vdmVybGF5Jyk7XHJcbiAgICAgICAgaWYgKG92ZXJsYXlEaXYgPT09IG51bGwpIHtcclxuICAgICAgICAgICAgb3ZlcmxheURpdiA9IHRoaXMuX2RvbUVsZW1TdmMuY3JlYXRlRWxlbWVudCh0aGlzLl9wYW5lc1sxXS5lbGVtZW50Lm5hdGl2ZUVsZW1lbnQsICdjb250ZW50LW92ZXJsYXknKTtcclxuXHJcbiAgICAgICAgICAgIHRoaXMuX3JlbmRlcmVyLmxpc3RlbihvdmVybGF5RGl2LCAnY2xpY2snLCAoZXZlbnQ6IGFueSk6IHZvaWQgPT4ge1xyXG4gICAgdGhpcy5fc3BsaXR0ZXJFdmVudC5maXJlKCk7XHJcbn0pO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgaWYgKGlzTW9iaWxlKSB7XHJcbiAgICAgICAgICAgIHRoaXMuX2RvbUVsZW1TdmMuc2V0RWxlbWVudENsYXNzKG92ZXJsYXlEaXYsICdzaG93JywgX2FkZCk7XHJcbiAgICAgICAgICAgIGlmICh0aGlzLl9zcGxpdHRlckxldmVsID09PSAnbWFpbicpIHtcclxuICAgICAgICAgICAgICAgIGxldCBjb250ZW50QXJlYSA9IHRoaXMuX3BhbmVzWzFdLmVsZW1lbnQubmF0aXZlRWxlbWVudC5xdWVyeVNlbGVjdG9yKCcubWFpbi13cmFwcGVyJyk7XHJcbiAgICAgICAgICAgICAgICAvLyBjb25zb2xlLmxvZyhjb250ZW50QXJlYSk7XHJcbiAgICAgICAgICAgICAgICBpZiAoY29udGVudEFyZWEpIHtcclxuICAgICAgICAgICAgICAgICAgICBsZXQgY29udGVudEFyZWFIZWlnaHQgPSBjb250ZW50QXJlYS5nZXRCb3VuZGluZ0NsaWVudFJlY3QoKS5oZWlnaHQ7XHJcbiAgICAgICAgICAgICAgICAgICAgbGV0IHBhbmVIZWlnaHQ6IG51bWJlciA9IHRoaXMuX3BhbmVzWzFdLmVsZW1lbnQubmF0aXZlRWxlbWVudC5nZXRCb3VuZGluZ0NsaWVudFJlY3QoKS5oZWlnaHQ7XHJcbiAgICAgICAgICAgICAgICAgICAgLy8gY29uc29sZS5sb2cocGFuZUhlaWdodCk7XHJcbiAgICAgICAgICAgICAgICAgICAgLy8gY29uc29sZS5sb2coY29udGVudEFyZWFIZWlnaHQpO1xyXG4gICAgICAgICAgICAgICAgICAgIGlmIChjb250ZW50QXJlYUhlaWdodCA+IHBhbmVIZWlnaHQpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5fZG9tRWxlbVN2Yy5zZXRFbGVtZW50U3R5bGUob3ZlcmxheURpdiwgJ2JvdHRvbScsICdhdXRvJyk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuX2RvbUVsZW1TdmMuc2V0RWxlbWVudFN0eWxlKG92ZXJsYXlEaXYsICdoZWlnaHQnLCBjb250ZW50QXJlYUhlaWdodCArICdweCcpO1xyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIHRoaXMuX2RvbUVsZW1TdmMuc2V0RWxlbWVudENsYXNzKHRoaXMuX3BhbmVzWzFdLmVsZW1lbnQubmF0aXZlRWxlbWVudCwgJ25vLW92ZXJmbG93JywgX2FkZCk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfb25EcmFnKGV2ZW50OiBhbnkpOiB2b2lkIHtcclxuICAgICAgICBpZiAodGhpcy5fZGlzYWJsZURyYWcpIHJldHVybjtcclxuICAgICAgICBpZiAoIXRoaXMuX2lzRHJhZykgcmV0dXJuO1xyXG5cclxuICAgICAgICBsZXQgZGlyZWN0aW9uOiBzdHJpbmcgPSB0aGlzLl9kb21FbGVtU3ZjLmdldERvY3VtZW50RGlyZWN0aW9uKHRydWUpO1xyXG4gICAgICAgIC8vIGxldCBzZWxlY3RlZFBhbmVCb3VuZHM6IGFueSA9IHRoaXMuX3NlbGVjdGVkRWxlbS5nZXRCb3VuZGluZ0NsaWVudFJlY3QoKTtcclxuICAgICAgICBsZXQgc3BsaXR0ZXJCb3VuZHM6IGFueSA9IHRoaXMuZWwubmF0aXZlRWxlbWVudC5nZXRCb3VuZGluZ0NsaWVudFJlY3QoKTtcclxuXHJcbiAgICAgICAgbGV0IG1vdmVYID0gTWF0aC5hYnMoZXZlbnQuY2xpZW50WCAtIHNwbGl0dGVyQm91bmRzW2RpcmVjdGlvbl0pO1xyXG4gICAgICAgIC8vIGNvbnNvbGUubG9nKG1vdmVYKTtcclxuICAgICAgICAvLyBsZXQgbmV3V2lkdGg6IG51bWJlciA9IHNlbGVjdGVkUGFuZUJvdW5kcy53aWR0aCAtIG1vdmVYO1xyXG4gICAgICAgIC8vIGNvbnNvbGUubG9nKG5ld1dpZHRoKTtcclxuICAgICAgICBsZXQgbmV3U2l6ZSA9IHRoaXMuX2NvbnZlcnRpb25TdmMuY29udmVydFB4VG9QZXJjZW50KG1vdmVYLCBzcGxpdHRlckJvdW5kcy53aWR0aCk7XHJcbiAgICAgICAgLy8gY29uc29sZS5sb2coJ25ld1NpemUgPSAnK25ld1NpemUpO1xyXG5cclxuICAgICAgICB0aGlzLl9kb21FbGVtU3ZjLnJlbW92ZUNsYXNzKHRoaXMuX3NlbGVjdGVkRWxlbSwgJ2FuaW1hdGlvbicpO1xyXG4gICAgICAgIHRoaXMuX3VwZGF0ZVNwbGl0UGFuZVNpemUobmV3U2l6ZSwgc3BsaXR0ZXJCb3VuZHMud2lkdGgpO1xyXG4gICAgICAgIHRoaXMuX3NwbGl0dGVyRXZlbnQuZHJhZyh0aGlzLl9zcGxpdHRlckxldmVsKTtcclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF9vblJlc2l6ZShldmVudDogYW55KTogdm9pZCB7XHJcbiAgICAgICAgbGV0IGlzTW9iaWxlOiBib29sZWFuID0gdGhpcy5fZG9tRWxlbVN2Yy5pc01vYmlsZSgpO1xyXG4gICAgICAgIGlmIChpc01vYmlsZSAhPT0gdGhpcy5fcHJldklzTW9iaWxlKSB7XHJcbiAgICAgICAgICAgIHRoaXMuX2lzRmlyc3RTd2l0Y2hWaWV3UG9ydCA9IHRydWU7XHJcbiAgICAgICAgICAgIHRoaXMuX3ByZXZJc01vYmlsZSA9IGlzTW9iaWxlO1xyXG4gICAgICAgICAgICB0aGlzLl9pc1N1YlBhbmVPcGVuID0gZmFsc2U7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIHRoaXMuX3NldERlZmF1bHRQYW5lU2l6ZSgpO1xyXG4gICAgICAgIHRoaXMuX2lzRmlyc3RTd2l0Y2hWaWV3UG9ydCA9IGZhbHNlO1xyXG4gICAgfVxyXG59XHJcbiJdfQ==