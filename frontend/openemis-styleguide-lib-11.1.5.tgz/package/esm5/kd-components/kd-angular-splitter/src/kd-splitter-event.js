import { __decorate, __metadata } from "tslib";
import { Injectable } from '@angular/core';
import { KdBroadcaster } from '../../kd-common/index';
import * as i0 from "@angular/core";
import * as i1 from "../../kd-common/kd-broadcaster-svc";
var KdSplitterEvent = /** @class */ (function () {
    function KdSplitterEvent(broadcaster) {
        this.broadcaster = broadcaster;
    }
    KdSplitterEvent.prototype.fire = function (data) {
        this.broadcaster.broadcast('KdSplitterEvent_SideMenu', data);
    };
    KdSplitterEvent.prototype.on = function () {
        return this.broadcaster.on('KdSplitterEvent_SideMenu');
    };
    KdSplitterEvent.prototype.drag = function (data) {
        this.broadcaster.broadcast('KdSplitterEvent_Drag', data);
    };
    KdSplitterEvent.prototype.onDrag = function () {
        return this.broadcaster.on('KdSplitterEvent_Drag');
    };
    KdSplitterEvent.prototype.toggleMenu = function (data) {
        this.broadcaster.broadcast('KdSplitterEvent_ToggleMenu', data);
    };
    KdSplitterEvent.prototype.onToggleMenu = function () {
        return this.broadcaster.on('KdSplitterEvent_ToggleMenu');
    };
    KdSplitterEvent.prototype.toggleSubPane = function (data) {
        this.broadcaster.broadcast('KdSplitterEvent_ToggleSubPane', data);
    };
    KdSplitterEvent.prototype.onToggleSubPane = function () {
        return this.broadcaster.on('KdSplitterEvent_ToggleSubPane');
    };
    KdSplitterEvent.prototype.toggleAnimationSubPaneEnd = function (data) {
        this.broadcaster.broadcast('KdSplitterEvent_AnimationSubPaneEnd', data);
    };
    KdSplitterEvent.prototype.onToggleAnimationSubPaneEnd = function () {
        return this.broadcaster.on('KdSplitterEvent_AnimationSubPaneEnd');
    };
    KdSplitterEvent.ctorParameters = function () { return [
        { type: KdBroadcaster }
    ]; };
    KdSplitterEvent.ɵprov = i0.ɵɵdefineInjectable({ factory: function KdSplitterEvent_Factory() { return new KdSplitterEvent(i0.ɵɵinject(i1.KdBroadcaster)); }, token: KdSplitterEvent, providedIn: "root" });
    KdSplitterEvent = __decorate([
        Injectable({
            providedIn: 'root'
        }),
        __metadata("design:paramtypes", [KdBroadcaster])
    ], KdSplitterEvent);
    return KdSplitterEvent;
}());
export { KdSplitterEvent };
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoia2Qtc3BsaXR0ZXItZXZlbnQuanMiLCJzb3VyY2VSb290Ijoibmc6Ly9vcGVuZW1pcy1zdHlsZWd1aWRlLWxpYi8iLCJzb3VyY2VzIjpbImtkLWNvbXBvbmVudHMva2QtYW5ndWxhci1zcGxpdHRlci9zcmMva2Qtc3BsaXR0ZXItZXZlbnQudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IjtBQUFBLE9BQU8sRUFBRSxVQUFVLEVBQUUsTUFBTSxlQUFlLENBQUM7QUFFM0MsT0FBTyxFQUFFLGFBQWEsRUFBRSxNQUFNLHVCQUF1QixDQUFDOzs7QUFLdEQ7SUFDSSx5QkFBb0IsV0FBMEI7UUFBMUIsZ0JBQVcsR0FBWCxXQUFXLENBQWU7SUFBSSxDQUFDO0lBRW5ELDhCQUFJLEdBQUosVUFBSyxJQUFhO1FBQ2QsSUFBSSxDQUFDLFdBQVcsQ0FBQyxTQUFTLENBQUMsMEJBQTBCLEVBQUUsSUFBSSxDQUFDLENBQUM7SUFDakUsQ0FBQztJQUVELDRCQUFFLEdBQUY7UUFDSSxPQUFPLElBQUksQ0FBQyxXQUFXLENBQUMsRUFBRSxDQUFTLDBCQUEwQixDQUFDLENBQUM7SUFDbkUsQ0FBQztJQUVELDhCQUFJLEdBQUosVUFBSyxJQUFZO1FBQ2IsSUFBSSxDQUFDLFdBQVcsQ0FBQyxTQUFTLENBQUMsc0JBQXNCLEVBQUUsSUFBSSxDQUFDLENBQUM7SUFDN0QsQ0FBQztJQUVELGdDQUFNLEdBQU47UUFDSSxPQUFPLElBQUksQ0FBQyxXQUFXLENBQUMsRUFBRSxDQUFTLHNCQUFzQixDQUFDLENBQUM7SUFDL0QsQ0FBQztJQUVELG9DQUFVLEdBQVYsVUFBVyxJQUFVO1FBQ2pCLElBQUksQ0FBQyxXQUFXLENBQUMsU0FBUyxDQUFDLDRCQUE0QixFQUFFLElBQUksQ0FBQyxDQUFDO0lBQ25FLENBQUM7SUFFRCxzQ0FBWSxHQUFaO1FBQ0ksT0FBTyxJQUFJLENBQUMsV0FBVyxDQUFDLEVBQUUsQ0FBTSw0QkFBNEIsQ0FBQyxDQUFDO0lBQ2xFLENBQUM7SUFFRCx1Q0FBYSxHQUFiLFVBQWMsSUFBYTtRQUN2QixJQUFJLENBQUMsV0FBVyxDQUFDLFNBQVMsQ0FBQywrQkFBK0IsRUFBRSxJQUFJLENBQUMsQ0FBQztJQUN0RSxDQUFDO0lBRUQseUNBQWUsR0FBZjtRQUNJLE9BQU8sSUFBSSxDQUFDLFdBQVcsQ0FBQyxFQUFFLENBQVUsK0JBQStCLENBQUMsQ0FBQztJQUN6RSxDQUFDO0lBRUQsbURBQXlCLEdBQXpCLFVBQTBCLElBQWM7UUFDcEMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxTQUFTLENBQUMscUNBQXFDLEVBQUUsSUFBSSxDQUFDLENBQUM7SUFDNUUsQ0FBQztJQUVELHFEQUEyQixHQUEzQjtRQUNJLE9BQU8sSUFBSSxDQUFDLFdBQVcsQ0FBQyxFQUFFLENBQVUscUNBQXFDLENBQUMsQ0FBQztJQUMvRSxDQUFDOztnQkF4Q2dDLGFBQWE7OztJQURyQyxlQUFlO1FBSDNCLFVBQVUsQ0FBQztZQUNSLFVBQVUsRUFBRSxNQUFNO1NBQ3JCLENBQUM7eUNBRW1DLGFBQWE7T0FEckMsZUFBZSxDQTBDM0I7MEJBakREO0NBaURDLEFBMUNELElBMENDO1NBMUNZLGVBQWUiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBJbmplY3RhYmxlIH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XHJcbmltcG9ydCB7IE9ic2VydmFibGUgfSBmcm9tICdyeGpzJztcclxuaW1wb3J0IHsgS2RCcm9hZGNhc3RlciB9IGZyb20gJy4uLy4uL2tkLWNvbW1vbi9pbmRleCc7XHJcblxyXG5ASW5qZWN0YWJsZSh7XHJcbiAgICBwcm92aWRlZEluOiAncm9vdCdcclxufSlcclxuZXhwb3J0IGNsYXNzIEtkU3BsaXR0ZXJFdmVudCB7XHJcbiAgICBjb25zdHJ1Y3Rvcihwcml2YXRlIGJyb2FkY2FzdGVyOiBLZEJyb2FkY2FzdGVyKSB7IH1cclxuXHJcbiAgICBmaXJlKGRhdGE/OiBzdHJpbmcpOiB2b2lkIHtcclxuICAgICAgICB0aGlzLmJyb2FkY2FzdGVyLmJyb2FkY2FzdCgnS2RTcGxpdHRlckV2ZW50X1NpZGVNZW51JywgZGF0YSk7XHJcbiAgICB9XHJcblxyXG4gICAgb24oKTogT2JzZXJ2YWJsZTxzdHJpbmc+IHtcclxuICAgICAgICByZXR1cm4gdGhpcy5icm9hZGNhc3Rlci5vbjxzdHJpbmc+KCdLZFNwbGl0dGVyRXZlbnRfU2lkZU1lbnUnKTtcclxuICAgIH1cclxuXHJcbiAgICBkcmFnKGRhdGE6IHN0cmluZyk6IHZvaWQge1xyXG4gICAgICAgIHRoaXMuYnJvYWRjYXN0ZXIuYnJvYWRjYXN0KCdLZFNwbGl0dGVyRXZlbnRfRHJhZycsIGRhdGEpO1xyXG4gICAgfVxyXG5cclxuICAgIG9uRHJhZygpOiBPYnNlcnZhYmxlPHN0cmluZz4ge1xyXG4gICAgICAgIHJldHVybiB0aGlzLmJyb2FkY2FzdGVyLm9uPHN0cmluZz4oJ0tkU3BsaXR0ZXJFdmVudF9EcmFnJyk7XHJcbiAgICB9XHJcblxyXG4gICAgdG9nZ2xlTWVudShkYXRhPzogYW55KTogdm9pZCB7XHJcbiAgICAgICAgdGhpcy5icm9hZGNhc3Rlci5icm9hZGNhc3QoJ0tkU3BsaXR0ZXJFdmVudF9Ub2dnbGVNZW51JywgZGF0YSk7XHJcbiAgICB9XHJcblxyXG4gICAgb25Ub2dnbGVNZW51KCk6IE9ic2VydmFibGU8YW55PiB7XHJcbiAgICAgICAgcmV0dXJuIHRoaXMuYnJvYWRjYXN0ZXIub248YW55PignS2RTcGxpdHRlckV2ZW50X1RvZ2dsZU1lbnUnKTtcclxuICAgIH1cclxuXHJcbiAgICB0b2dnbGVTdWJQYW5lKGRhdGE6IGJvb2xlYW4pOiB2b2lkIHtcclxuICAgICAgICB0aGlzLmJyb2FkY2FzdGVyLmJyb2FkY2FzdCgnS2RTcGxpdHRlckV2ZW50X1RvZ2dsZVN1YlBhbmUnLCBkYXRhKTtcclxuICAgIH1cclxuXHJcbiAgICBvblRvZ2dsZVN1YlBhbmUoKTogT2JzZXJ2YWJsZTxib29sZWFuPiB7XHJcbiAgICAgICAgcmV0dXJuIHRoaXMuYnJvYWRjYXN0ZXIub248Ym9vbGVhbj4oJ0tkU3BsaXR0ZXJFdmVudF9Ub2dnbGVTdWJQYW5lJyk7XHJcbiAgICB9XHJcblxyXG4gICAgdG9nZ2xlQW5pbWF0aW9uU3ViUGFuZUVuZChkYXRhPzogYm9vbGVhbik6IHZvaWQge1xyXG4gICAgICAgIHRoaXMuYnJvYWRjYXN0ZXIuYnJvYWRjYXN0KCdLZFNwbGl0dGVyRXZlbnRfQW5pbWF0aW9uU3ViUGFuZUVuZCcsIGRhdGEpO1xyXG4gICAgfVxyXG5cclxuICAgIG9uVG9nZ2xlQW5pbWF0aW9uU3ViUGFuZUVuZCgpOiBPYnNlcnZhYmxlPGJvb2xlYW4+IHtcclxuICAgICAgICByZXR1cm4gdGhpcy5icm9hZGNhc3Rlci5vbjxib29sZWFuPignS2RTcGxpdHRlckV2ZW50X0FuaW1hdGlvblN1YlBhbmVFbmQnKTtcclxuICAgIH1cclxufVxyXG4iXX0=