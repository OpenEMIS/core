import { __decorate, __metadata } from "tslib";
import { Injectable } from '@angular/core';
import { KdConvertionSvc } from '../../kd-common/index';
var KdSplitterSvc = /** @class */ (function () {
    function KdSplitterSvc(_convertionSvc) {
        this._convertionSvc = _convertionSvc;
        this._panesDefaultConfig = {};
    }
    KdSplitterSvc.prototype.initPanesDefaultConfig = function (panes) {
        var _this = this;
        var paneSizeArr = {};
        var size = 100;
        var max = 100;
        var min = 100;
        var defaultAttrKey = ['max', 'min', 'size', 'show'];
        var isMaster = false;
        panes.forEach(function (item) {
            var classes = item.classes.split(' ');
            var paneKey = _this._convertionSvc.camelCase(classes[1], '-');
            _this._panesDefaultConfig[paneKey] = {};
            defaultAttrKey.forEach(function (key) {
                var value = _this._setDefaultItemData(paneKey, key, item[key]);
                _this._panesDefaultConfig[paneKey]['master'] = isMaster;
                // console.log(value);
                if (paneSizeArr[key] === undefined)
                    paneSizeArr[key] = {};
                if (value === undefined) {
                    // console.log('value undefined');
                    paneSizeArr[key][paneKey] = 0;
                }
                else {
                    if (key === 'size')
                        size -= value;
                    if (key === 'max')
                        max -= value;
                    if (key === 'min')
                        min -= value;
                }
            });
            isMaster = !isMaster;
        });
        if (paneSizeArr.size !== undefined) {
            this._setPaneValue(size, paneSizeArr, 'size');
            this._setPaneValue(max, paneSizeArr, 'min');
            this._setPaneValue(min, paneSizeArr, 'max');
        }
        else {
            // if (size > 0)
            //     console.warn('remaining size = ' + size);
        }
        return this._panesDefaultConfig;
    };
    KdSplitterSvc.prototype.validatePaneSize = function (_panesConfig, _key, _value) {
        var value = _value;
        // console.log('validatePaneSize = ' + value);
        // console.log(_panesConfig[_key]);
        // console.log(_panesConfig[_key].min);
        // console.log(_panesConfig[_key].max);
        if (value > _panesConfig[_key].max) {
            value = _panesConfig[_key].max;
        }
        else if (value < _panesConfig[_key].min) {
            value = _panesConfig[_key].min;
        }
        return value;
    };
    KdSplitterSvc.prototype.toDisableDrag = function () {
        return (this._panesDefaultConfig.Pane1.max === this._panesDefaultConfig.Pane1.min) ? true : false;
    };
    KdSplitterSvc.prototype.validatePercentValue = function (_value, _min, _max) {
        var value = _value;
        // console.log('value ='+ value);
        _min = (typeof _min === 'undefined') ? 0 : _min;
        _max = (typeof _max === 'undefined') ? 100 : _max;
        if (value > _max)
            value = 100;
        else if (value < _min)
            value = 0;
        return value;
    };
    KdSplitterSvc.prototype.getMobileConfig = function (_level, _dir) {
        var mobileConfig = {
            Pane1: {
                width: 100,
            },
            Pane2: {
                width: 100,
            }
        };
        if (_level === 'main') {
            mobileConfig.Pane1.width = (window.innerWidth < 480) ? 80 : 40;
            mobileConfig['Pane1'][_dir] = 0;
            mobileConfig['Pane2'][_dir] = 0;
        }
        else {
            mobileConfig['Pane1'][_dir] = 0;
            mobileConfig['Pane2'][_dir] = 100;
        }
        return mobileConfig;
    };
    KdSplitterSvc.prototype.isSubPane = function (_elem) {
        var parentElem = _elem.parentElement;
        var isElemFound = false;
        var endOfLoop = false;
        while (endOfLoop === false) {
            if (typeof parentElem.classList !== undefined && typeof parentElem.tagName !== undefined) {
                if (parentElem.tagName !== 'BODY') {
                    if (parentElem.classList.length === 0) {
                        parentElem = parentElem.parentElement;
                    }
                    else {
                        for (var i = 0; i < parentElem.classList.length; i++) {
                            if (parentElem.classList[i] === 'kdx-split-panes') {
                                isElemFound = true;
                                endOfLoop = true;
                                break;
                            }
                        }
                        if (!isElemFound) {
                            parentElem = parentElem.parentElement;
                        }
                    }
                }
                else {
                    endOfLoop = true;
                }
            }
            else {
                parentElem = parentElem.parentElement;
            }
        }
        return isElemFound;
    };
    KdSplitterSvc.prototype._setPaneValue = function (_globalValue, dataArr, _type) {
        var assignValue = _globalValue;
        // console.log('assignValue = ' + assignValue);
        // console.log('_type = ' + _type);
        // console.log(dataArr);
        var keys = Object.keys(dataArr[_type]);
        if (keys.length > 1)
            assignValue = assignValue / keys.length;
        for (var key in dataArr[_type]) {
            if (dataArr[_type].hasOwnProperty(key)) {
                this._panesDefaultConfig[key][_type] = assignValue;
            }
        }
    };
    KdSplitterSvc.prototype._setDefaultItemData = function (_paneKey, _key, _value) {
        // console.log(_paneKey, _key, _value);
        var itemValue = undefined;
        if (_value !== undefined) {
            itemValue = this._convertionSvc.convertStrToPercent(_value);
            this._panesDefaultConfig[_paneKey][_key] = itemValue;
        }
        return itemValue;
    };
    KdSplitterSvc.ctorParameters = function () { return [
        { type: KdConvertionSvc }
    ]; };
    KdSplitterSvc = __decorate([
        Injectable(),
        __metadata("design:paramtypes", [KdConvertionSvc])
    ], KdSplitterSvc);
    return KdSplitterSvc;
}());
export { KdSplitterSvc };
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoia2Qtc3BsaXR0ZXItc3ZjLmpzIiwic291cmNlUm9vdCI6Im5nOi8vb3BlbmVtaXMtc3R5bGVndWlkZS1saWIvIiwic291cmNlcyI6WyJrZC1jb21wb25lbnRzL2tkLWFuZ3VsYXItc3BsaXR0ZXIvc3JjL2tkLXNwbGl0dGVyLXN2Yy50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiO0FBQUEsT0FBTyxFQUFFLFVBQVUsRUFBRSxNQUFNLGVBQWUsQ0FBQztBQUUzQyxPQUFPLEVBQUUsZUFBZSxFQUFFLE1BQU0sdUJBQXVCLENBQUM7QUFHeEQ7SUFHSSx1QkFBb0IsY0FBK0I7UUFBL0IsbUJBQWMsR0FBZCxjQUFjLENBQWlCO1FBRjNDLHdCQUFtQixHQUFRLEVBQUUsQ0FBQztJQUVpQixDQUFDO0lBRXhELDhDQUFzQixHQUF0QixVQUF1QixLQUFvQjtRQUEzQyxpQkE0Q0M7UUEzQ0csSUFBSSxXQUFXLEdBQVEsRUFBRSxDQUFDO1FBQzFCLElBQUksSUFBSSxHQUFXLEdBQUcsQ0FBQztRQUN2QixJQUFJLEdBQUcsR0FBVyxHQUFHLENBQUM7UUFDdEIsSUFBSSxHQUFHLEdBQVcsR0FBRyxDQUFDO1FBQ3RCLElBQUksY0FBYyxHQUFlLENBQUMsS0FBSyxFQUFFLEtBQUssRUFBRSxNQUFNLEVBQUUsTUFBTSxDQUFDLENBQUM7UUFDaEUsSUFBSSxRQUFRLEdBQVksS0FBSyxDQUFDO1FBRTlCLEtBQUssQ0FBQyxPQUFPLENBQUMsVUFBQyxJQUFJO1lBQ2YsSUFBSSxPQUFPLEdBQWUsSUFBSSxDQUFDLE9BQU8sQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLENBQUM7WUFDbEQsSUFBSSxPQUFPLEdBQUcsS0FBSSxDQUFDLGNBQWMsQ0FBQyxTQUFTLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxFQUFFLEdBQUcsQ0FBQyxDQUFDO1lBRTdELEtBQUksQ0FBQyxtQkFBbUIsQ0FBQyxPQUFPLENBQUMsR0FBRyxFQUFFLENBQUM7WUFDdkMsY0FBYyxDQUFDLE9BQU8sQ0FBQyxVQUFDLEdBQUc7Z0JBQ3ZCLElBQUksS0FBSyxHQUFHLEtBQUksQ0FBQyxtQkFBbUIsQ0FBQyxPQUFPLEVBQUUsR0FBRyxFQUFFLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDO2dCQUM5RCxLQUFJLENBQUMsbUJBQW1CLENBQUMsT0FBTyxDQUFDLENBQUMsUUFBUSxDQUFDLEdBQUcsUUFBUSxDQUFDO2dCQUN2RCxzQkFBc0I7Z0JBQ3RCLElBQUksV0FBVyxDQUFDLEdBQUcsQ0FBQyxLQUFLLFNBQVM7b0JBQUUsV0FBVyxDQUFDLEdBQUcsQ0FBQyxHQUFHLEVBQUUsQ0FBQztnQkFFMUQsSUFBSSxLQUFLLEtBQUssU0FBUyxFQUFFO29CQUNyQixrQ0FBa0M7b0JBQ2xDLFdBQVcsQ0FBQyxHQUFHLENBQUMsQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLENBQUM7aUJBQ2pDO3FCQUNJO29CQUNELElBQUksR0FBRyxLQUFLLE1BQU07d0JBQUUsSUFBSSxJQUFJLEtBQUssQ0FBQztvQkFDbEMsSUFBSSxHQUFHLEtBQUssS0FBSzt3QkFBRSxHQUFHLElBQUksS0FBSyxDQUFDO29CQUNoQyxJQUFJLEdBQUcsS0FBSyxLQUFLO3dCQUFFLEdBQUcsSUFBSSxLQUFLLENBQUM7aUJBQ25DO1lBQ0wsQ0FBQyxDQUFDLENBQUM7WUFFSCxRQUFRLEdBQUcsQ0FBQyxRQUFRLENBQUM7UUFDekIsQ0FBQyxDQUFDLENBQUM7UUFFSCxJQUFJLFdBQVcsQ0FBQyxJQUFJLEtBQUssU0FBUyxFQUFFO1lBQ2hDLElBQUksQ0FBQyxhQUFhLENBQUMsSUFBSSxFQUFFLFdBQVcsRUFBRSxNQUFNLENBQUMsQ0FBQztZQUM5QyxJQUFJLENBQUMsYUFBYSxDQUFDLEdBQUcsRUFBRSxXQUFXLEVBQUUsS0FBSyxDQUFDLENBQUM7WUFDNUMsSUFBSSxDQUFDLGFBQWEsQ0FBQyxHQUFHLEVBQUUsV0FBVyxFQUFFLEtBQUssQ0FBQyxDQUFDO1NBQy9DO2FBQ0k7WUFDRCxnQkFBZ0I7WUFDaEIsZ0RBQWdEO1NBQ25EO1FBRUQsT0FBTyxJQUFJLENBQUMsbUJBQW1CLENBQUM7SUFDcEMsQ0FBQztJQUdELHdDQUFnQixHQUFoQixVQUFpQixZQUFpQixFQUFFLElBQVksRUFBRSxNQUFjO1FBQzVELElBQUksS0FBSyxHQUFRLE1BQU0sQ0FBQztRQUN4Qiw4Q0FBOEM7UUFDOUMsbUNBQW1DO1FBQ25DLHVDQUF1QztRQUN2Qyx1Q0FBdUM7UUFDdkMsSUFBSSxLQUFLLEdBQUcsWUFBWSxDQUFDLElBQUksQ0FBQyxDQUFDLEdBQUcsRUFBRTtZQUNoQyxLQUFLLEdBQUcsWUFBWSxDQUFDLElBQUksQ0FBQyxDQUFDLEdBQUcsQ0FBQztTQUNsQzthQUNJLElBQUksS0FBSyxHQUFHLFlBQVksQ0FBQyxJQUFJLENBQUMsQ0FBQyxHQUFHLEVBQUU7WUFDckMsS0FBSyxHQUFHLFlBQVksQ0FBQyxJQUFJLENBQUMsQ0FBQyxHQUFHLENBQUM7U0FDbEM7UUFFRCxPQUFPLEtBQUssQ0FBQztJQUNqQixDQUFDO0lBRUQscUNBQWEsR0FBYjtRQUNJLE9BQU8sQ0FBQyxJQUFJLENBQUMsbUJBQW1CLENBQUMsS0FBSyxDQUFDLEdBQUcsS0FBSyxJQUFJLENBQUMsbUJBQW1CLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQztJQUN0RyxDQUFDO0lBRUQsNENBQW9CLEdBQXBCLFVBQXFCLE1BQWMsRUFBRSxJQUFhLEVBQUUsSUFBYTtRQUM3RCxJQUFJLEtBQUssR0FBVyxNQUFNLENBQUM7UUFDM0IsaUNBQWlDO1FBQ2pDLElBQUksR0FBRyxDQUFDLE9BQU8sSUFBSSxLQUFLLFdBQVcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQztRQUNoRCxJQUFJLEdBQUcsQ0FBQyxPQUFPLElBQUksS0FBSyxXQUFXLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUM7UUFFbEQsSUFBSSxLQUFLLEdBQUcsSUFBSTtZQUFFLEtBQUssR0FBRyxHQUFHLENBQUM7YUFDekIsSUFBSSxLQUFLLEdBQUcsSUFBSTtZQUFFLEtBQUssR0FBRyxDQUFDLENBQUM7UUFDakMsT0FBTyxLQUFLLENBQUM7SUFDakIsQ0FBQztJQUVELHVDQUFlLEdBQWYsVUFBZ0IsTUFBYyxFQUFFLElBQVk7UUFDeEMsSUFBSSxZQUFZLEdBQVE7WUFDcEIsS0FBSyxFQUFFO2dCQUNILEtBQUssRUFBRSxHQUFHO2FBRWI7WUFDRCxLQUFLLEVBQUU7Z0JBQ0gsS0FBSyxFQUFFLEdBQUc7YUFDYjtTQUNKLENBQUM7UUFDRixJQUFJLE1BQU0sS0FBSyxNQUFNLEVBQUU7WUFDbkIsWUFBWSxDQUFDLEtBQUssQ0FBQyxLQUFLLEdBQUcsQ0FBQyxNQUFNLENBQUMsVUFBVSxHQUFHLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQztZQUMvRCxZQUFZLENBQUMsT0FBTyxDQUFDLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFDO1lBQ2hDLFlBQVksQ0FBQyxPQUFPLENBQUMsQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUM7U0FDbkM7YUFDSTtZQUNELFlBQVksQ0FBQyxPQUFPLENBQUMsQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUM7WUFDaEMsWUFBWSxDQUFDLE9BQU8sQ0FBQyxDQUFDLElBQUksQ0FBQyxHQUFHLEdBQUcsQ0FBQztTQUNyQztRQUNELE9BQU8sWUFBWSxDQUFDO0lBQ3hCLENBQUM7SUFFTSxpQ0FBUyxHQUFoQixVQUFpQixLQUFrQjtRQUMvQixJQUFJLFVBQVUsR0FBZ0IsS0FBSyxDQUFDLGFBQWEsQ0FBQztRQUNsRCxJQUFJLFdBQVcsR0FBWSxLQUFLLENBQUM7UUFDakMsSUFBSSxTQUFTLEdBQVksS0FBSyxDQUFDO1FBRS9CLE9BQU8sU0FBUyxLQUFLLEtBQUssRUFBRTtZQUN4QixJQUFJLE9BQU8sVUFBVSxDQUFDLFNBQVMsS0FBSyxTQUFTLElBQUksT0FBTyxVQUFVLENBQUMsT0FBTyxLQUFLLFNBQVMsRUFBRTtnQkFDdEYsSUFBSSxVQUFVLENBQUMsT0FBTyxLQUFLLE1BQU0sRUFBRTtvQkFDL0IsSUFBSSxVQUFVLENBQUMsU0FBUyxDQUFDLE1BQU0sS0FBSyxDQUFDLEVBQUU7d0JBQ25DLFVBQVUsR0FBRyxVQUFVLENBQUMsYUFBYSxDQUFDO3FCQUN6Qzt5QkFDSTt3QkFDRCxLQUFLLElBQUksQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLEdBQUcsVUFBVSxDQUFDLFNBQVMsQ0FBQyxNQUFNLEVBQUUsQ0FBQyxFQUFFLEVBQUU7NEJBQ2xELElBQUksVUFBVSxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsS0FBSyxpQkFBaUIsRUFBRTtnQ0FDL0MsV0FBVyxHQUFHLElBQUksQ0FBQztnQ0FDbkIsU0FBUyxHQUFHLElBQUksQ0FBQztnQ0FDakIsTUFBTTs2QkFDVDt5QkFDSjt3QkFFRCxJQUFJLENBQUMsV0FBVyxFQUFFOzRCQUNkLFVBQVUsR0FBRyxVQUFVLENBQUMsYUFBYSxDQUFDO3lCQUN6QztxQkFDSjtpQkFDSjtxQkFDSTtvQkFDRCxTQUFTLEdBQUcsSUFBSSxDQUFDO2lCQUNwQjthQUNKO2lCQUNJO2dCQUNELFVBQVUsR0FBRyxVQUFVLENBQUMsYUFBYSxDQUFDO2FBQ3pDO1NBQ0o7UUFFRCxPQUFPLFdBQVcsQ0FBQztJQUN2QixDQUFDO0lBRU8scUNBQWEsR0FBckIsVUFBc0IsWUFBb0IsRUFBRSxPQUFtQixFQUFFLEtBQWE7UUFDMUUsSUFBSSxXQUFXLEdBQVcsWUFBWSxDQUFDO1FBQ3ZDLCtDQUErQztRQUMvQyxtQ0FBbUM7UUFDbkMsd0JBQXdCO1FBQ3hCLElBQUksSUFBSSxHQUFrQixNQUFNLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDO1FBQ3RELElBQUksSUFBSSxDQUFDLE1BQU0sR0FBRyxDQUFDO1lBQUUsV0FBVyxHQUFHLFdBQVcsR0FBRyxJQUFJLENBQUMsTUFBTSxDQUFDO1FBQzdELEtBQUssSUFBSSxHQUFHLElBQUksT0FBTyxDQUFDLEtBQUssQ0FBQyxFQUFFO1lBQzVCLElBQUksT0FBTyxDQUFDLEtBQUssQ0FBQyxDQUFDLGNBQWMsQ0FBQyxHQUFHLENBQUMsRUFBRTtnQkFDcEMsSUFBSSxDQUFDLG1CQUFtQixDQUFDLEdBQUcsQ0FBQyxDQUFDLEtBQUssQ0FBQyxHQUFHLFdBQVcsQ0FBQzthQUN0RDtTQUNKO0lBQ0wsQ0FBQztJQUVPLDJDQUFtQixHQUEzQixVQUE0QixRQUFnQixFQUFFLElBQVksRUFBRSxNQUFjO1FBQ3RFLHVDQUF1QztRQUN2QyxJQUFJLFNBQVMsR0FBRyxTQUFTLENBQUM7UUFDMUIsSUFBSSxNQUFNLEtBQUssU0FBUyxFQUFFO1lBQ3RCLFNBQVMsR0FBRyxJQUFJLENBQUMsY0FBYyxDQUFDLG1CQUFtQixDQUFDLE1BQU0sQ0FBQyxDQUFDO1lBQzVELElBQUksQ0FBQyxtQkFBbUIsQ0FBQyxRQUFRLENBQUMsQ0FBQyxJQUFJLENBQUMsR0FBRyxTQUFTLENBQUM7U0FDeEQ7UUFFRCxPQUFPLFNBQVMsQ0FBQztJQUNyQixDQUFDOztnQkFsS21DLGVBQWU7O0lBSDFDLGFBQWE7UUFEekIsVUFBVSxFQUFFO3lDQUkyQixlQUFlO09BSDFDLGFBQWEsQ0FzS3pCO0lBQUQsb0JBQUM7Q0FBQSxBQXRLRCxJQXNLQztTQXRLWSxhQUFhIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgSW5qZWN0YWJsZSB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xyXG5pbXBvcnQgeyBLZFBhbmUgfSBmcm9tICcuL2tkLXBhbmUnO1xyXG5pbXBvcnQgeyBLZENvbnZlcnRpb25TdmMgfSBmcm9tICcuLi8uLi9rZC1jb21tb24vaW5kZXgnO1xyXG5cclxuQEluamVjdGFibGUoKVxyXG5leHBvcnQgY2xhc3MgS2RTcGxpdHRlclN2YyB7XHJcbiAgICBwcml2YXRlIF9wYW5lc0RlZmF1bHRDb25maWc6IGFueSA9IHt9O1xyXG5cclxuICAgIGNvbnN0cnVjdG9yKHByaXZhdGUgX2NvbnZlcnRpb25TdmM6IEtkQ29udmVydGlvblN2YykgeyB9XHJcblxyXG4gICAgaW5pdFBhbmVzRGVmYXVsdENvbmZpZyhwYW5lczogQXJyYXk8S2RQYW5lPik6IGFueSB7XHJcbiAgICAgICAgbGV0IHBhbmVTaXplQXJyOiBhbnkgPSB7fTtcclxuICAgICAgICBsZXQgc2l6ZTogbnVtYmVyID0gMTAwO1xyXG4gICAgICAgIGxldCBtYXg6IG51bWJlciA9IDEwMDtcclxuICAgICAgICBsZXQgbWluOiBudW1iZXIgPSAxMDA7XHJcbiAgICAgICAgbGV0IGRlZmF1bHRBdHRyS2V5OiBBcnJheTxhbnk+ID0gWydtYXgnLCAnbWluJywgJ3NpemUnLCAnc2hvdyddO1xyXG4gICAgICAgIGxldCBpc01hc3RlcjogYm9vbGVhbiA9IGZhbHNlO1xyXG5cclxuICAgICAgICBwYW5lcy5mb3JFYWNoKChpdGVtKTogdm9pZCA9PiB7XHJcbiAgICAgICAgICAgIGxldCBjbGFzc2VzOiBBcnJheTxhbnk+ID0gaXRlbS5jbGFzc2VzLnNwbGl0KCcgJyk7XHJcbiAgICAgICAgICAgIGxldCBwYW5lS2V5ID0gdGhpcy5fY29udmVydGlvblN2Yy5jYW1lbENhc2UoY2xhc3Nlc1sxXSwgJy0nKTtcclxuXHJcbiAgICAgICAgICAgIHRoaXMuX3BhbmVzRGVmYXVsdENvbmZpZ1twYW5lS2V5XSA9IHt9O1xyXG4gICAgICAgICAgICBkZWZhdWx0QXR0cktleS5mb3JFYWNoKChrZXkpOiB2b2lkID0+IHtcclxuICAgICAgICAgICAgICAgIGxldCB2YWx1ZSA9IHRoaXMuX3NldERlZmF1bHRJdGVtRGF0YShwYW5lS2V5LCBrZXksIGl0ZW1ba2V5XSk7XHJcbiAgICAgICAgICAgICAgICB0aGlzLl9wYW5lc0RlZmF1bHRDb25maWdbcGFuZUtleV1bJ21hc3RlciddID0gaXNNYXN0ZXI7XHJcbiAgICAgICAgICAgICAgICAvLyBjb25zb2xlLmxvZyh2YWx1ZSk7XHJcbiAgICAgICAgICAgICAgICBpZiAocGFuZVNpemVBcnJba2V5XSA9PT0gdW5kZWZpbmVkKSBwYW5lU2l6ZUFycltrZXldID0ge307XHJcblxyXG4gICAgICAgICAgICAgICAgaWYgKHZhbHVlID09PSB1bmRlZmluZWQpIHtcclxuICAgICAgICAgICAgICAgICAgICAvLyBjb25zb2xlLmxvZygndmFsdWUgdW5kZWZpbmVkJyk7XHJcbiAgICAgICAgICAgICAgICAgICAgcGFuZVNpemVBcnJba2V5XVtwYW5lS2V5XSA9IDA7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgICAgICAgICBpZiAoa2V5ID09PSAnc2l6ZScpIHNpemUgLT0gdmFsdWU7XHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKGtleSA9PT0gJ21heCcpIG1heCAtPSB2YWx1ZTtcclxuICAgICAgICAgICAgICAgICAgICBpZiAoa2V5ID09PSAnbWluJykgbWluIC09IHZhbHVlO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9KTtcclxuXHJcbiAgICAgICAgICAgIGlzTWFzdGVyID0gIWlzTWFzdGVyO1xyXG4gICAgICAgIH0pO1xyXG5cclxuICAgICAgICBpZiAocGFuZVNpemVBcnIuc2l6ZSAhPT0gdW5kZWZpbmVkKSB7XHJcbiAgICAgICAgICAgIHRoaXMuX3NldFBhbmVWYWx1ZShzaXplLCBwYW5lU2l6ZUFyciwgJ3NpemUnKTtcclxuICAgICAgICAgICAgdGhpcy5fc2V0UGFuZVZhbHVlKG1heCwgcGFuZVNpemVBcnIsICdtaW4nKTtcclxuICAgICAgICAgICAgdGhpcy5fc2V0UGFuZVZhbHVlKG1pbiwgcGFuZVNpemVBcnIsICdtYXgnKTtcclxuICAgICAgICB9XHJcbiAgICAgICAgZWxzZSB7XHJcbiAgICAgICAgICAgIC8vIGlmIChzaXplID4gMClcclxuICAgICAgICAgICAgLy8gICAgIGNvbnNvbGUud2FybigncmVtYWluaW5nIHNpemUgPSAnICsgc2l6ZSk7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICByZXR1cm4gdGhpcy5fcGFuZXNEZWZhdWx0Q29uZmlnO1xyXG4gICAgfVxyXG5cclxuXHJcbiAgICB2YWxpZGF0ZVBhbmVTaXplKF9wYW5lc0NvbmZpZzogYW55LCBfa2V5OiBzdHJpbmcsIF92YWx1ZTogbnVtYmVyKTogbnVtYmVyIHtcclxuICAgICAgICBsZXQgdmFsdWU6IGFueSA9IF92YWx1ZTtcclxuICAgICAgICAvLyBjb25zb2xlLmxvZygndmFsaWRhdGVQYW5lU2l6ZSA9ICcgKyB2YWx1ZSk7XHJcbiAgICAgICAgLy8gY29uc29sZS5sb2coX3BhbmVzQ29uZmlnW19rZXldKTtcclxuICAgICAgICAvLyBjb25zb2xlLmxvZyhfcGFuZXNDb25maWdbX2tleV0ubWluKTtcclxuICAgICAgICAvLyBjb25zb2xlLmxvZyhfcGFuZXNDb25maWdbX2tleV0ubWF4KTtcclxuICAgICAgICBpZiAodmFsdWUgPiBfcGFuZXNDb25maWdbX2tleV0ubWF4KSB7XHJcbiAgICAgICAgICAgIHZhbHVlID0gX3BhbmVzQ29uZmlnW19rZXldLm1heDtcclxuICAgICAgICB9XHJcbiAgICAgICAgZWxzZSBpZiAodmFsdWUgPCBfcGFuZXNDb25maWdbX2tleV0ubWluKSB7XHJcbiAgICAgICAgICAgIHZhbHVlID0gX3BhbmVzQ29uZmlnW19rZXldLm1pbjtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIHJldHVybiB2YWx1ZTtcclxuICAgIH1cclxuXHJcbiAgICB0b0Rpc2FibGVEcmFnKCk6IGJvb2xlYW4ge1xyXG4gICAgICAgIHJldHVybiAodGhpcy5fcGFuZXNEZWZhdWx0Q29uZmlnLlBhbmUxLm1heCA9PT0gdGhpcy5fcGFuZXNEZWZhdWx0Q29uZmlnLlBhbmUxLm1pbikgPyB0cnVlIDogZmFsc2U7XHJcbiAgICB9XHJcblxyXG4gICAgdmFsaWRhdGVQZXJjZW50VmFsdWUoX3ZhbHVlOiBudW1iZXIsIF9taW4/OiBudW1iZXIsIF9tYXg/OiBudW1iZXIpOiBudW1iZXIge1xyXG4gICAgICAgIGxldCB2YWx1ZTogbnVtYmVyID0gX3ZhbHVlO1xyXG4gICAgICAgIC8vIGNvbnNvbGUubG9nKCd2YWx1ZSA9JysgdmFsdWUpO1xyXG4gICAgICAgIF9taW4gPSAodHlwZW9mIF9taW4gPT09ICd1bmRlZmluZWQnKSA/IDAgOiBfbWluO1xyXG4gICAgICAgIF9tYXggPSAodHlwZW9mIF9tYXggPT09ICd1bmRlZmluZWQnKSA/IDEwMCA6IF9tYXg7XHJcblxyXG4gICAgICAgIGlmICh2YWx1ZSA+IF9tYXgpIHZhbHVlID0gMTAwO1xyXG4gICAgICAgIGVsc2UgaWYgKHZhbHVlIDwgX21pbikgdmFsdWUgPSAwO1xyXG4gICAgICAgIHJldHVybiB2YWx1ZTtcclxuICAgIH1cclxuXHJcbiAgICBnZXRNb2JpbGVDb25maWcoX2xldmVsOiBzdHJpbmcsIF9kaXI6IHN0cmluZyk6IGFueSB7XHJcbiAgICAgICAgbGV0IG1vYmlsZUNvbmZpZzogYW55ID0ge1xyXG4gICAgICAgICAgICBQYW5lMToge1xyXG4gICAgICAgICAgICAgICAgd2lkdGg6IDEwMCxcclxuXHJcbiAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgIFBhbmUyOiB7XHJcbiAgICAgICAgICAgICAgICB3aWR0aDogMTAwLFxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfTtcclxuICAgICAgICBpZiAoX2xldmVsID09PSAnbWFpbicpIHtcclxuICAgICAgICAgICAgbW9iaWxlQ29uZmlnLlBhbmUxLndpZHRoID0gKHdpbmRvdy5pbm5lcldpZHRoIDwgNDgwKSA/IDgwIDogNDA7XHJcbiAgICAgICAgICAgIG1vYmlsZUNvbmZpZ1snUGFuZTEnXVtfZGlyXSA9IDA7XHJcbiAgICAgICAgICAgIG1vYmlsZUNvbmZpZ1snUGFuZTInXVtfZGlyXSA9IDA7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICBtb2JpbGVDb25maWdbJ1BhbmUxJ11bX2Rpcl0gPSAwO1xyXG4gICAgICAgICAgICBtb2JpbGVDb25maWdbJ1BhbmUyJ11bX2Rpcl0gPSAxMDA7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIHJldHVybiBtb2JpbGVDb25maWc7XHJcbiAgICB9XHJcblxyXG4gICAgcHVibGljIGlzU3ViUGFuZShfZWxlbTogSFRNTEVsZW1lbnQpOiBib29sZWFuIHtcclxuICAgICAgICBsZXQgcGFyZW50RWxlbTogSFRNTEVsZW1lbnQgPSBfZWxlbS5wYXJlbnRFbGVtZW50O1xyXG4gICAgICAgIGxldCBpc0VsZW1Gb3VuZDogYm9vbGVhbiA9IGZhbHNlO1xyXG4gICAgICAgIGxldCBlbmRPZkxvb3A6IGJvb2xlYW4gPSBmYWxzZTtcclxuXHJcbiAgICAgICAgd2hpbGUgKGVuZE9mTG9vcCA9PT0gZmFsc2UpIHtcclxuICAgICAgICAgICAgaWYgKHR5cGVvZiBwYXJlbnRFbGVtLmNsYXNzTGlzdCAhPT0gdW5kZWZpbmVkICYmIHR5cGVvZiBwYXJlbnRFbGVtLnRhZ05hbWUgIT09IHVuZGVmaW5lZCkge1xyXG4gICAgICAgICAgICAgICAgaWYgKHBhcmVudEVsZW0udGFnTmFtZSAhPT0gJ0JPRFknKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKHBhcmVudEVsZW0uY2xhc3NMaXN0Lmxlbmd0aCA9PT0gMCkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBwYXJlbnRFbGVtID0gcGFyZW50RWxlbS5wYXJlbnRFbGVtZW50O1xyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgZm9yIChsZXQgaSA9IDA7IGkgPCBwYXJlbnRFbGVtLmNsYXNzTGlzdC5sZW5ndGg7IGkrKykge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKHBhcmVudEVsZW0uY2xhc3NMaXN0W2ldID09PSAna2R4LXNwbGl0LXBhbmVzJykge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlzRWxlbUZvdW5kID0gdHJ1ZTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBlbmRPZkxvb3AgPSB0cnVlO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAoIWlzRWxlbUZvdW5kKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBwYXJlbnRFbGVtID0gcGFyZW50RWxlbS5wYXJlbnRFbGVtZW50O1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgZWxzZSB7XHJcbiAgICAgICAgICAgICAgICAgICAgZW5kT2ZMb29wID0gdHJ1ZTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgICAgIHBhcmVudEVsZW0gPSBwYXJlbnRFbGVtLnBhcmVudEVsZW1lbnQ7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIHJldHVybiBpc0VsZW1Gb3VuZDtcclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF9zZXRQYW5lVmFsdWUoX2dsb2JhbFZhbHVlOiBudW1iZXIsIGRhdGFBcnI6IEFycmF5PGFueT4sIF90eXBlOiBzdHJpbmcpIHtcclxuICAgICAgICBsZXQgYXNzaWduVmFsdWU6IG51bWJlciA9IF9nbG9iYWxWYWx1ZTtcclxuICAgICAgICAvLyBjb25zb2xlLmxvZygnYXNzaWduVmFsdWUgPSAnICsgYXNzaWduVmFsdWUpO1xyXG4gICAgICAgIC8vIGNvbnNvbGUubG9nKCdfdHlwZSA9ICcgKyBfdHlwZSk7XHJcbiAgICAgICAgLy8gY29uc29sZS5sb2coZGF0YUFycik7XHJcbiAgICAgICAgbGV0IGtleXM6IEFycmF5PHN0cmluZz4gPSBPYmplY3Qua2V5cyhkYXRhQXJyW190eXBlXSk7XHJcbiAgICAgICAgaWYgKGtleXMubGVuZ3RoID4gMSkgYXNzaWduVmFsdWUgPSBhc3NpZ25WYWx1ZSAvIGtleXMubGVuZ3RoO1xyXG4gICAgICAgIGZvciAobGV0IGtleSBpbiBkYXRhQXJyW190eXBlXSkge1xyXG4gICAgICAgICAgICBpZiAoZGF0YUFycltfdHlwZV0uaGFzT3duUHJvcGVydHkoa2V5KSkge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5fcGFuZXNEZWZhdWx0Q29uZmlnW2tleV1bX3R5cGVdID0gYXNzaWduVmFsdWU7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfc2V0RGVmYXVsdEl0ZW1EYXRhKF9wYW5lS2V5OiBzdHJpbmcsIF9rZXk6IHN0cmluZywgX3ZhbHVlOiBzdHJpbmcpOiBudW1iZXIge1xyXG4gICAgICAgIC8vIGNvbnNvbGUubG9nKF9wYW5lS2V5LCBfa2V5LCBfdmFsdWUpO1xyXG4gICAgICAgIGxldCBpdGVtVmFsdWUgPSB1bmRlZmluZWQ7XHJcbiAgICAgICAgaWYgKF92YWx1ZSAhPT0gdW5kZWZpbmVkKSB7XHJcbiAgICAgICAgICAgIGl0ZW1WYWx1ZSA9IHRoaXMuX2NvbnZlcnRpb25TdmMuY29udmVydFN0clRvUGVyY2VudChfdmFsdWUpO1xyXG4gICAgICAgICAgICB0aGlzLl9wYW5lc0RlZmF1bHRDb25maWdbX3BhbmVLZXldW19rZXldID0gaXRlbVZhbHVlO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgcmV0dXJuIGl0ZW1WYWx1ZTtcclxuICAgIH1cclxufVxyXG4iXX0=