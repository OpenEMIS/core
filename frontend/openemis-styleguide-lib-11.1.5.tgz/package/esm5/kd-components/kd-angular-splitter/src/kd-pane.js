import { __decorate, __metadata } from "tslib";
import { Component, HostBinding, ViewContainerRef, ElementRef, 
// ContentChildren,
// QueryList,
AfterViewInit, OnChanges, SimpleChanges, Input } from '@angular/core';
import { KdSplitter } from './kd-splitter';
var KdPane = /** @class */ (function () {
    function KdPane(splitterContainer, _vcr) {
        var _this = this;
        this.splitterContainer = splitterContainer;
        this._vcr = _vcr;
        // @Input() size: String;
        this.classes = 'pane';
        this.index = this.splitterContainer.addGroup(this);
        this.classes += ' pane-' + this.index;
        this.element = this._vcr.element;
        var elemAttr = this._vcr.element.nativeElement.attributes;
        var elemAttrKeys = Object.keys(this._vcr.element.nativeElement.attributes);
        // console.log(elemAttr);
        // for(let i: number = 0; i < elemAttr.length; i++){
        //     console.log(elemAttr[i]);
        // }
        elemAttrKeys.forEach(function (key) {
            _this[elemAttr[key].name] = elemAttr[key].value;
            if (_this.index < 1 && key === 'hidden') {
                delete _this[elemAttr[key].name];
            }
        });
    }
    KdPane.prototype.ngOnChanges = function (_simpleChanges) {
        if (_simpleChanges.hasOwnProperty('size') && !_simpleChanges['size'].firstChange) {
            this.splitterContainer.paneOnChange('size');
        }
        if (_simpleChanges.hasOwnProperty('max') && !_simpleChanges['max'].firstChange) {
            this.splitterContainer.paneOnChange('max');
        }
        if (_simpleChanges.hasOwnProperty('min') && !_simpleChanges['min'].firstChange) {
            this.splitterContainer.paneOnChange('min');
        }
    };
    KdPane.prototype.ngAfterViewInit = function () {
        // console.log('on after view init');
        //        console.log(this.childrenSplitter);
    };
    KdPane.ctorParameters = function () { return [
        { type: KdSplitter },
        { type: ViewContainerRef }
    ]; };
    __decorate([
        HostBinding('class'),
        __metadata("design:type", Object)
    ], KdPane.prototype, "classes", void 0);
    __decorate([
        Input(),
        __metadata("design:type", String)
    ], KdPane.prototype, "size", void 0);
    __decorate([
        Input(),
        __metadata("design:type", String)
    ], KdPane.prototype, "max", void 0);
    __decorate([
        Input(),
        __metadata("design:type", String)
    ], KdPane.prototype, "min", void 0);
    __decorate([
        Input(),
        __metadata("design:type", String)
    ], KdPane.prototype, "show", void 0);
    KdPane = __decorate([
        Component({
            selector: 'kd-pane',
            // template: `<div *ngIf='index > 1' class='splitter-handler sh-{{index}}'></div>
            //           <ng-content></ng-content>`,
            template: "<ng-content></ng-content>"
        }),
        __metadata("design:paramtypes", [KdSplitter, ViewContainerRef])
    ], KdPane);
    return KdPane;
}());
export { KdPane };
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoia2QtcGFuZS5qcyIsInNvdXJjZVJvb3QiOiJuZzovL29wZW5lbWlzLXN0eWxlZ3VpZGUtbGliLyIsInNvdXJjZXMiOlsia2QtY29tcG9uZW50cy9rZC1hbmd1bGFyLXNwbGl0dGVyL3NyYy9rZC1wYW5lLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7QUFBQSxPQUFPLEVBQ0gsU0FBUyxFQUNULFdBQVcsRUFDWCxnQkFBZ0IsRUFDaEIsVUFBVTtBQUNWLG1CQUFtQjtBQUNuQixhQUFhO0FBQ2IsYUFBYSxFQUNiLFNBQVMsRUFDVCxhQUFhLEVBQ2IsS0FBSyxFQUNSLE1BQU0sZUFBZSxDQUFDO0FBRXZCLE9BQU8sRUFBRSxVQUFVLEVBQUUsTUFBTSxlQUFlLENBQUM7QUFVM0M7SUFlSSxnQkFBb0IsaUJBQTZCLEVBQVUsSUFBc0I7UUFBakYsaUJBa0JDO1FBbEJtQixzQkFBaUIsR0FBakIsaUJBQWlCLENBQVk7UUFBVSxTQUFJLEdBQUosSUFBSSxDQUFrQjtRQWRqRix5QkFBeUI7UUFDSCxZQUFPLEdBQUcsTUFBTSxDQUFDO1FBY25DLElBQUksQ0FBQyxLQUFLLEdBQUcsSUFBSSxDQUFDLGlCQUFpQixDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsQ0FBQztRQUNuRCxJQUFJLENBQUMsT0FBTyxJQUFJLFFBQVEsR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDO1FBQ3RDLElBQUksQ0FBQyxPQUFPLEdBQUcsSUFBSSxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUM7UUFFakMsSUFBSSxRQUFRLEdBQUcsSUFBSSxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsYUFBYSxDQUFDLFVBQVUsQ0FBQztRQUMxRCxJQUFJLFlBQVksR0FBRyxNQUFNLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLGFBQWEsQ0FBQyxVQUFVLENBQUMsQ0FBQztRQUMzRSx5QkFBeUI7UUFDekIsb0RBQW9EO1FBQ3BELGdDQUFnQztRQUNoQyxJQUFJO1FBRUosWUFBWSxDQUFDLE9BQU8sQ0FBQyxVQUFDLEdBQVE7WUFDMUIsS0FBSSxDQUFDLFFBQVEsQ0FBQyxHQUFHLENBQUMsQ0FBQyxJQUFJLENBQUMsR0FBRyxRQUFRLENBQUMsR0FBRyxDQUFDLENBQUMsS0FBSyxDQUFDO1lBQy9DLElBQUksS0FBSSxDQUFDLEtBQUssR0FBRyxDQUFDLElBQUksR0FBRyxLQUFLLFFBQVEsRUFBRTtnQkFDcEMsT0FBTyxLQUFJLENBQUMsUUFBUSxDQUFDLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDO2FBQ25DO1FBQ0wsQ0FBQyxDQUFDLENBQUM7SUFDUCxDQUFDO0lBRUQsNEJBQVcsR0FBWCxVQUFZLGNBQTZCO1FBQ3JDLElBQUksY0FBYyxDQUFDLGNBQWMsQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLGNBQWMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxXQUFXLEVBQUU7WUFDOUUsSUFBSSxDQUFDLGlCQUFpQixDQUFDLFlBQVksQ0FBQyxNQUFNLENBQUMsQ0FBQztTQUMvQztRQUNELElBQUksY0FBYyxDQUFDLGNBQWMsQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLGNBQWMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxXQUFXLEVBQUU7WUFDNUUsSUFBSSxDQUFDLGlCQUFpQixDQUFDLFlBQVksQ0FBQyxLQUFLLENBQUMsQ0FBQztTQUM5QztRQUNELElBQUksY0FBYyxDQUFDLGNBQWMsQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLGNBQWMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxXQUFXLEVBQUU7WUFDNUUsSUFBSSxDQUFDLGlCQUFpQixDQUFDLFlBQVksQ0FBQyxLQUFLLENBQUMsQ0FBQztTQUM5QztJQUNMLENBQUM7SUFFRCxnQ0FBZSxHQUFmO1FBQ0kscUNBQXFDO1FBQ3JDLDZDQUE2QztJQUVqRCxDQUFDOztnQkFwQ3NDLFVBQVU7Z0JBQWdCLGdCQUFnQjs7SUFiM0Q7UUFBckIsV0FBVyxDQUFDLE9BQU8sQ0FBQzs7MkNBQWtCO0lBSTlCO1FBQVIsS0FBSyxFQUFFOzt3Q0FBYztJQUNiO1FBQVIsS0FBSyxFQUFFOzt1Q0FBYTtJQUNaO1FBQVIsS0FBSyxFQUFFOzt1Q0FBYTtJQUNaO1FBQVIsS0FBSyxFQUFFOzt3Q0FBYztJQVRiLE1BQU07UUFQbEIsU0FBUyxDQUFDO1lBQ1AsUUFBUSxFQUFFLFNBQVM7WUFDbkIsaUZBQWlGO1lBQ2pGLHdDQUF3QztZQUN4QyxRQUFRLEVBQUUsMkJBQTJCO1NBQ3hDLENBQUM7eUNBaUJ5QyxVQUFVLEVBQWdCLGdCQUFnQjtPQWZ4RSxNQUFNLENBb0RsQjtJQUFELGFBQUM7Q0FBQSxBQXBERCxJQW9EQztTQXBEWSxNQUFNIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHtcclxuICAgIENvbXBvbmVudCxcclxuICAgIEhvc3RCaW5kaW5nLFxyXG4gICAgVmlld0NvbnRhaW5lclJlZixcclxuICAgIEVsZW1lbnRSZWYsXHJcbiAgICAvLyBDb250ZW50Q2hpbGRyZW4sXHJcbiAgICAvLyBRdWVyeUxpc3QsXHJcbiAgICBBZnRlclZpZXdJbml0LFxyXG4gICAgT25DaGFuZ2VzLFxyXG4gICAgU2ltcGxlQ2hhbmdlcyxcclxuICAgIElucHV0XHJcbn0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XHJcblxyXG5pbXBvcnQgeyBLZFNwbGl0dGVyIH0gZnJvbSAnLi9rZC1zcGxpdHRlcic7XHJcblxyXG5cclxuQENvbXBvbmVudCh7XHJcbiAgICBzZWxlY3RvcjogJ2tkLXBhbmUnLFxyXG4gICAgLy8gdGVtcGxhdGU6IGA8ZGl2ICpuZ0lmPSdpbmRleCA+IDEnIGNsYXNzPSdzcGxpdHRlci1oYW5kbGVyIHNoLXt7aW5kZXh9fSc+PC9kaXY+XHJcbiAgICAvLyAgICAgICAgICAgPG5nLWNvbnRlbnQ+PC9uZy1jb250ZW50PmAsXHJcbiAgICB0ZW1wbGF0ZTogYDxuZy1jb250ZW50PjwvbmctY29udGVudD5gLFxyXG59KVxyXG5cclxuZXhwb3J0IGNsYXNzIEtkUGFuZSBpbXBsZW1lbnRzIE9uQ2hhbmdlcywgQWZ0ZXJWaWV3SW5pdCB7XHJcbiAgICAvLyBASW5wdXQoKSBzaXplOiBTdHJpbmc7XHJcbiAgICBASG9zdEJpbmRpbmcoJ2NsYXNzJykgY2xhc3NlcyA9ICdwYW5lJztcclxuICAgIC8vIEBDb250ZW50Q2hpbGRyZW4oS2RTcGxpdHRlcikgY2hpbGRyZW5TcGxpdHRlcjogUXVlcnlMaXN0PEtkU3BsaXR0ZXI+O1xyXG5cclxuICAgIGluZGV4OiBudW1iZXI7XHJcbiAgICBASW5wdXQoKSBzaXplOiBzdHJpbmc7XHJcbiAgICBASW5wdXQoKSBtYXg6IHN0cmluZztcclxuICAgIEBJbnB1dCgpIG1pbjogc3RyaW5nO1xyXG4gICAgQElucHV0KCkgc2hvdzogc3RyaW5nO1xyXG4gICAgLy8gICAgIHNpemU6IHN0cmluZztcclxuICAgIC8vIG1heDogc3RyaW5nO1xyXG4gICAgLy8gbWluOiBzdHJpbmc7XHJcbiAgICBoaWRkZW46IGJvb2xlYW47XHJcbiAgICBlbGVtZW50OiBFbGVtZW50UmVmO1xyXG4gICAgY29uc3RydWN0b3IocHJpdmF0ZSBzcGxpdHRlckNvbnRhaW5lcjogS2RTcGxpdHRlciwgcHJpdmF0ZSBfdmNyOiBWaWV3Q29udGFpbmVyUmVmKSB7XHJcbiAgICAgICAgdGhpcy5pbmRleCA9IHRoaXMuc3BsaXR0ZXJDb250YWluZXIuYWRkR3JvdXAodGhpcyk7XHJcbiAgICAgICAgdGhpcy5jbGFzc2VzICs9ICcgcGFuZS0nICsgdGhpcy5pbmRleDtcclxuICAgICAgICB0aGlzLmVsZW1lbnQgPSB0aGlzLl92Y3IuZWxlbWVudDtcclxuXHJcbiAgICAgICAgbGV0IGVsZW1BdHRyID0gdGhpcy5fdmNyLmVsZW1lbnQubmF0aXZlRWxlbWVudC5hdHRyaWJ1dGVzO1xyXG4gICAgICAgIGxldCBlbGVtQXR0cktleXMgPSBPYmplY3Qua2V5cyh0aGlzLl92Y3IuZWxlbWVudC5uYXRpdmVFbGVtZW50LmF0dHJpYnV0ZXMpO1xyXG4gICAgICAgIC8vIGNvbnNvbGUubG9nKGVsZW1BdHRyKTtcclxuICAgICAgICAvLyBmb3IobGV0IGk6IG51bWJlciA9IDA7IGkgPCBlbGVtQXR0ci5sZW5ndGg7IGkrKyl7XHJcbiAgICAgICAgLy8gICAgIGNvbnNvbGUubG9nKGVsZW1BdHRyW2ldKTtcclxuICAgICAgICAvLyB9XHJcblxyXG4gICAgICAgIGVsZW1BdHRyS2V5cy5mb3JFYWNoKChrZXk6IGFueSk6IHZvaWQgPT4ge1xyXG4gICAgICAgICAgICB0aGlzW2VsZW1BdHRyW2tleV0ubmFtZV0gPSBlbGVtQXR0cltrZXldLnZhbHVlO1xyXG4gICAgICAgICAgICBpZiAodGhpcy5pbmRleCA8IDEgJiYga2V5ID09PSAnaGlkZGVuJykge1xyXG4gICAgICAgICAgICAgICAgZGVsZXRlIHRoaXNbZWxlbUF0dHJba2V5XS5uYW1lXTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH0pO1xyXG4gICAgfVxyXG5cclxuICAgIG5nT25DaGFuZ2VzKF9zaW1wbGVDaGFuZ2VzOiBTaW1wbGVDaGFuZ2VzKSB7XHJcbiAgICAgICAgaWYgKF9zaW1wbGVDaGFuZ2VzLmhhc093blByb3BlcnR5KCdzaXplJykgJiYgIV9zaW1wbGVDaGFuZ2VzWydzaXplJ10uZmlyc3RDaGFuZ2UpIHtcclxuICAgICAgICAgICAgdGhpcy5zcGxpdHRlckNvbnRhaW5lci5wYW5lT25DaGFuZ2UoJ3NpemUnKTtcclxuICAgICAgICB9XHJcbiAgICAgICAgaWYgKF9zaW1wbGVDaGFuZ2VzLmhhc093blByb3BlcnR5KCdtYXgnKSAmJiAhX3NpbXBsZUNoYW5nZXNbJ21heCddLmZpcnN0Q2hhbmdlKSB7XHJcbiAgICAgICAgICAgIHRoaXMuc3BsaXR0ZXJDb250YWluZXIucGFuZU9uQ2hhbmdlKCdtYXgnKTtcclxuICAgICAgICB9XHJcbiAgICAgICAgaWYgKF9zaW1wbGVDaGFuZ2VzLmhhc093blByb3BlcnR5KCdtaW4nKSAmJiAhX3NpbXBsZUNoYW5nZXNbJ21pbiddLmZpcnN0Q2hhbmdlKSB7XHJcbiAgICAgICAgICAgIHRoaXMuc3BsaXR0ZXJDb250YWluZXIucGFuZU9uQ2hhbmdlKCdtaW4nKTtcclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgbmdBZnRlclZpZXdJbml0KCk6IHZvaWQge1xyXG4gICAgICAgIC8vIGNvbnNvbGUubG9nKCdvbiBhZnRlciB2aWV3IGluaXQnKTtcclxuICAgICAgICAvLyAgICAgICAgY29uc29sZS5sb2codGhpcy5jaGlsZHJlblNwbGl0dGVyKTtcclxuXHJcbiAgICB9XHJcbn1cclxuIl19