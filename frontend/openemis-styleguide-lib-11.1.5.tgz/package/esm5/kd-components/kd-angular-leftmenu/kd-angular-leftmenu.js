import { __decorate, __metadata } from "tslib";
import { Component, Input, OnInit, AfterViewInit, ViewEncapsulation, ViewContainerRef, ChangeDetectorRef, SimpleChanges, Renderer2 } from '@angular/core';
import { timer } from 'rxjs';
import { Router, NavigationEnd } from '@angular/router';
import { KdDomElemSvc } from '../kd-common/index';
import { KdLeftmenuSvc } from './kd-angular-leftmenu-svc';
var KdLeftMenu = /** @class */ (function () {
    function KdLeftMenu(_renderer, _vcr, _leftmenuSvc, _router, _cdf, _domSvc) {
        var _this = this;
        this._renderer = _renderer;
        this._vcr = _vcr;
        this._leftmenuSvc = _leftmenuSvc;
        this._router = _router;
        this._cdf = _cdf;
        this._domSvc = _domSvc;
        this.list = [];
        this._previousId = [];
        this._previousItem = {};
        this._activeIdFound = false;
        this._firstRouteCheck = true;
        this._currentRoute = '';
        this._routerSub = _router.events.subscribe(function (event) {
            if (event instanceof NavigationEnd) {
                _this._currentRoute = event.urlAfterRedirects;
                if (!_this._firstRouteCheck) {
                    _this._setInitOpen(event.urlAfterRedirects);
                    // close the previous item if current clicked path do not much any path in the sidemenu
                    if (!_this._activeIdFound && typeof _this._previousItem.nav_id !== 'undefined') {
                        var close_1 = _this._leftmenuSvc.getId(_this._previousItem);
                        _this._leftmenuSvc.toggleState(close_1, 'close', _this.list);
                        _this._previousId = [];
                        _this._previousItem = {};
                    }
                }
            }
        });
    }
    KdLeftMenu.prototype.ngOnInit = function () {
        this._initApi();
    };
    KdLeftMenu.prototype.ngOnChanges = function (_simpleChanges) {
        var _this = this;
        if (_simpleChanges.hasOwnProperty('sideConfig')) {
            this.list = this._leftmenuSvc.setIsOpen(this.sideConfig);
            if (_simpleChanges.sideConfig.isFirstChange) {
                this._setAlpha(true);
                timer(500).subscribe(function () {
                    _this._setInitOpen(_this._router.url);
                    _this._setAlpha(false);
                    _this._firstRouteCheck = false;
                });
            }
        }
    };
    KdLeftMenu.prototype.ngAfterViewInit = function () { };
    KdLeftMenu.prototype.ngOnDestroy = function () {
        if (typeof this._routerSub !== 'undefined') {
            this._routerSub.unsubscribe();
        }
    };
    KdLeftMenu.prototype.clickToggle = function (item) {
        this._checkToggle(item);
        if (typeof item.list === 'undefined') {
            this._checkPathAndNavigate(item);
        }
        // triggers click event when api is initialised
        if (this.api)
            this._leftmenuSvc.menuItemClicked(item);
    };
    KdLeftMenu.prototype.getPaddingSize = function (_itemId) {
        var size = 10;
        var navLevels = _itemId.split('-');
        if (navLevels.length > 2) {
            size += (17 * (navLevels.length - 2));
        }
        // console.log(_itemId);
        if (this._domSvc.getDocumentDirection().toLowerCase() === 'ltr')
            return '10px 25px 10px ' + size + 'px';
        else
            return '10px ' + size + 'px 10px 25px';
    };
    KdLeftMenu.prototype.getItemOrder = function (_item) {
        return (typeof _item.order === 'undefined') ? 1 : _item.order;
    };
    KdLeftMenu.prototype._checkPathAndNavigate = function (item) {
        if (typeof item.path !== 'undefined') {
            this._router.navigate([item.path]);
        }
        else {
            this._router.navigate(['/']);
        }
    };
    KdLeftMenu.prototype._setAlpha = function (bool) {
        var ulList = this._vcr.element.nativeElement.querySelector('ul.nav.root-nav');
        bool ? this._renderer.addClass(ulList, 'alpha-0') : this._renderer.removeClass(ulList, 'alpha-0');
    };
    KdLeftMenu.prototype._setInitOpen = function (rawUrl) {
        this._activeIdFound = false;
        var url = rawUrl.split('/');
        var testUrl = [];
        var joinUrl = '';
        for (var i = url.length - 1; i >= 0; i--) {
            testUrl = [];
            //  console.log('----> round ' + i);
            for (var j = 0; j <= i; j++) {
                testUrl.push(url[j]);
            }
            joinUrl = testUrl.join('/').substring(1);
            if (this._activeIdFound === false) {
                // this._cdf.detach();
                this._checkPath(joinUrl, this.list);
                this._cdf.detectChanges();
                // this._cdf.reattach();
            }
        }
    };
    KdLeftMenu.prototype._checkPath = function (url, itemList) {
        var resultPath = '';
        for (var i = 0; i < itemList.length; i++) {
            if (typeof itemList[i].list !== 'undefined') {
                this._checkPath(url, itemList[i].list);
            }
            resultPath = (typeof itemList[i].basePath !== 'undefined' && itemList[i].basePath[0] === '/') ? itemList[i].basePath.substring(1) : itemList[i].basePath;
            if (resultPath === url) {
                this._itemSelected(itemList[i]);
                this._activeIdFound = true;
                break;
            }
        }
    };
    KdLeftMenu.prototype._itemSelected = function (item) {
        this._checkToggle(item);
        this._previousItem.isSelected = false;
        this._previousItem = item;
        item.isSelected = true;
    };
    KdLeftMenu.prototype._checkToggle = function (item) {
        var currentId = this._leftmenuSvc.getId(item);
        // if user clicked the same, toggle state
        if (this._leftmenuSvc.isArrayEqual(currentId, this._previousId) && item.hasOwnProperty('isOpen')) {
            this._leftmenuSvc.toggleState(currentId, 'toggle', this.list);
        }
        // if user clicked on something more on the surface, check
        else if (this._previousId.length > currentId.length) {
            //  this._closeDifferent(currentId, this._previousId);
            this._leftmenuSvc.closeDifferent(currentId, this._previousId, this.list);
        }
        // if user clicked on something deeper, close previous and open current
        else {
            //  if (item.hasOwnProperty('isOpen')) {
            if (this._previousId.length > 0) {
                this._leftmenuSvc.toggleState(this._previousId, 'close', this.list);
            }
            //  }
            this._leftmenuSvc.toggleState(currentId, 'open', this.list);
        }
        this._previousId = currentId;
    };
    KdLeftMenu.prototype._initApi = function () {
        var _this = this;
        if (!this.api)
            return;
        this.api.onMenuItemClicked = this._leftmenuSvc.onMenuItemClicked();
        this.api.updateMenuList = function (_nav_id, _list) {
            var navPos = _this._leftmenuSvc.getId(_nav_id);
            var selectedItem = {};
            if (navPos.length > 0) {
                selectedItem = _this.list[navPos[0]];
                for (var i = 1; i < navPos.length; i++) {
                    selectedItem = selectedItem.list[navPos[i]];
                }
                if (typeof _list !== 'undefined') {
                    selectedItem['list'] = _list;
                    _this.list = _this._leftmenuSvc.setIsOpen(_this.list);
                    _this._setInitOpen(_this._currentRoute);
                }
            }
        };
    };
    KdLeftMenu.ctorParameters = function () { return [
        { type: Renderer2 },
        { type: ViewContainerRef },
        { type: KdLeftmenuSvc },
        { type: Router },
        { type: ChangeDetectorRef },
        { type: KdDomElemSvc }
    ]; };
    __decorate([
        Input('config'),
        __metadata("design:type", Array)
    ], KdLeftMenu.prototype, "sideConfig", void 0);
    __decorate([
        Input(),
        __metadata("design:type", Object)
    ], KdLeftMenu.prototype, "api", void 0);
    KdLeftMenu = __decorate([
        Component({
            selector: 'kd-leftmenu',
            template: "<div class=\"kdx-left-menu\">\r\n    <div class=\"panel-group\">\r\n        <ul class=\"nav root-nav\">\r\n            <ng-template #recursiveList let-list>\r\n                <li *ngFor=\"let item of list\" [style.order]=\"getItemOrder(item)\">\r\n                    <a [ngClass]=\"{'selected': item.isSelected, 'accordion-toggle': item.list, 'expand': item.isOpen}\" \r\n                    [hidden]=\"item.selected\" \r\n                    [attr.id]=\"item.nav_id\" \r\n                    (click)=\"clickToggle(item)\" \r\n                    [style.padding]=\"getPaddingSize(item.nav_id)\">\r\n                        <i *ngIf=\"item.icon\" class=\"{{item.icon}}\"></i><span>{{item.header}}</span>\r\n                    </a>\r\n                    <ul *ngIf=\"item.list\" class=\"nav\" [ngClass]=\"{'toggle': item.isOpen, 'untoggle': !item.isOpen}\">\r\n                        <ng-container *ngTemplateOutlet=\"recursiveList; context:{ $implicit: item.list }\"></ng-container>\r\n                    </ul>\r\n                </li>\r\n            </ng-template>\r\n            <ng-container *ngTemplateOutlet=\"recursiveList; context:{ $implicit: list }\"></ng-container>\r\n        </ul>\r\n    </div>\r\n</div>\r\n",
            encapsulation: ViewEncapsulation.None,
            providers: [KdLeftmenuSvc, KdDomElemSvc],
            styles: ["\n        .alpha-0{\n            opacity: 0;\n        }\n    "]
        }),
        __metadata("design:paramtypes", [Renderer2,
            ViewContainerRef,
            KdLeftmenuSvc,
            Router,
            ChangeDetectorRef,
            KdDomElemSvc])
    ], KdLeftMenu);
    return KdLeftMenu;
}());
export { KdLeftMenu };
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoia2QtYW5ndWxhci1sZWZ0bWVudS5qcyIsInNvdXJjZVJvb3QiOiJuZzovL29wZW5lbWlzLXN0eWxlZ3VpZGUtbGliLyIsInNvdXJjZXMiOlsia2QtY29tcG9uZW50cy9rZC1hbmd1bGFyLWxlZnRtZW51L2tkLWFuZ3VsYXItbGVmdG1lbnUudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IjtBQUFBLE9BQU8sRUFBRSxTQUFTLEVBQUUsS0FBSyxFQUFFLE1BQU0sRUFBRSxhQUFhLEVBQUUsaUJBQWlCLEVBQUUsZ0JBQWdCLEVBQUUsaUJBQWlCLEVBQUUsYUFBYSxFQUFFLFNBQVMsRUFBRSxNQUFNLGVBQWUsQ0FBQztBQUMxSixPQUFPLEVBQUUsS0FBSyxFQUFnQixNQUFNLE1BQU0sQ0FBQztBQUMzQyxPQUFPLEVBQUUsTUFBTSxFQUFFLGFBQWEsRUFBRSxNQUFNLGlCQUFpQixDQUFDO0FBQ3hELE9BQU8sRUFBRSxZQUFZLEVBQUUsTUFBTSxvQkFBb0IsQ0FBQztBQUNsRCxPQUFPLEVBQUUsYUFBYSxFQUFFLE1BQU0sMkJBQTJCLENBQUM7QUFjMUQ7SUFZSSxvQkFDWSxTQUFvQixFQUNwQixJQUFzQixFQUN0QixZQUEyQixFQUMzQixPQUFlLEVBQ2YsSUFBdUIsRUFDdkIsT0FBcUI7UUFOakMsaUJBdUJDO1FBdEJXLGNBQVMsR0FBVCxTQUFTLENBQVc7UUFDcEIsU0FBSSxHQUFKLElBQUksQ0FBa0I7UUFDdEIsaUJBQVksR0FBWixZQUFZLENBQWU7UUFDM0IsWUFBTyxHQUFQLE9BQU8sQ0FBUTtRQUNmLFNBQUksR0FBSixJQUFJLENBQW1CO1FBQ3ZCLFlBQU8sR0FBUCxPQUFPLENBQWM7UUFqQjFCLFNBQUksR0FBZSxFQUFFLENBQUM7UUFDckIsZ0JBQVcsR0FBa0IsRUFBRSxDQUFDO1FBQ2hDLGtCQUFhLEdBQVEsRUFBRSxDQUFDO1FBQ3hCLG1CQUFjLEdBQVksS0FBSyxDQUFDO1FBQ2hDLHFCQUFnQixHQUFZLElBQUksQ0FBQztRQUVqQyxrQkFBYSxHQUFXLEVBQUUsQ0FBQztRQWEvQixJQUFJLENBQUMsVUFBVSxHQUFHLE9BQU8sQ0FBQyxNQUFNLENBQUMsU0FBUyxDQUFDLFVBQUEsS0FBSztZQUM1QyxJQUFJLEtBQUssWUFBWSxhQUFhLEVBQUU7Z0JBQ2hDLEtBQUksQ0FBQyxhQUFhLEdBQUcsS0FBSyxDQUFDLGlCQUFpQixDQUFDO2dCQUM3QyxJQUFJLENBQUMsS0FBSSxDQUFDLGdCQUFnQixFQUFFO29CQUN4QixLQUFJLENBQUMsWUFBWSxDQUFDLEtBQUssQ0FBQyxpQkFBaUIsQ0FBQyxDQUFDO29CQUMzQyx1RkFBdUY7b0JBQ3ZGLElBQUksQ0FBQyxLQUFJLENBQUMsY0FBYyxJQUFJLE9BQU8sS0FBSSxDQUFDLGFBQWEsQ0FBQyxNQUFNLEtBQUssV0FBVyxFQUFFO3dCQUMxRSxJQUFJLE9BQUssR0FBZSxLQUFJLENBQUMsWUFBWSxDQUFDLEtBQUssQ0FBQyxLQUFJLENBQUMsYUFBYSxDQUFDLENBQUM7d0JBQ3BFLEtBQUksQ0FBQyxZQUFZLENBQUMsV0FBVyxDQUFDLE9BQUssRUFBRSxPQUFPLEVBQUUsS0FBSSxDQUFDLElBQUksQ0FBQyxDQUFDO3dCQUN6RCxLQUFJLENBQUMsV0FBVyxHQUFHLEVBQUUsQ0FBQzt3QkFDdEIsS0FBSSxDQUFDLGFBQWEsR0FBRyxFQUFFLENBQUM7cUJBQzNCO2lCQUNKO2FBQ0o7UUFDTCxDQUFDLENBQUMsQ0FBQztJQUNQLENBQUM7SUFFRCw2QkFBUSxHQUFSO1FBQ0ksSUFBSSxDQUFDLFFBQVEsRUFBRSxDQUFDO0lBQ3BCLENBQUM7SUFFRCxnQ0FBVyxHQUFYLFVBQVksY0FBNkI7UUFBekMsaUJBY0M7UUFiRyxJQUFJLGNBQWMsQ0FBQyxjQUFjLENBQUMsWUFBWSxDQUFDLEVBQUU7WUFDN0MsSUFBSSxDQUFDLElBQUksR0FBRyxJQUFJLENBQUMsWUFBWSxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLENBQUM7WUFFekQsSUFBSSxjQUFjLENBQUMsVUFBVSxDQUFDLGFBQWEsRUFBRTtnQkFDekMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsQ0FBQztnQkFFckIsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDLFNBQVMsQ0FBQztvQkFDakIsS0FBSSxDQUFDLFlBQVksQ0FBQyxLQUFJLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxDQUFDO29CQUNwQyxLQUFJLENBQUMsU0FBUyxDQUFDLEtBQUssQ0FBQyxDQUFDO29CQUN0QixLQUFJLENBQUMsZ0JBQWdCLEdBQUcsS0FBSyxDQUFDO2dCQUNsQyxDQUFDLENBQUMsQ0FBQzthQUNOO1NBQ0o7SUFDTCxDQUFDO0lBRUQsb0NBQWUsR0FBZixjQUEwQixDQUFDO0lBRTNCLGdDQUFXLEdBQVg7UUFDSSxJQUFJLE9BQU8sSUFBSSxDQUFDLFVBQVUsS0FBSyxXQUFXLEVBQUU7WUFDeEMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxXQUFXLEVBQUUsQ0FBQztTQUNqQztJQUNMLENBQUM7SUFFTSxnQ0FBVyxHQUFsQixVQUFtQixJQUFTO1FBQ3hCLElBQUksQ0FBQyxZQUFZLENBQUMsSUFBSSxDQUFDLENBQUM7UUFFeEIsSUFBSSxPQUFPLElBQUksQ0FBQyxJQUFJLEtBQUssV0FBVyxFQUFFO1lBQ2xDLElBQUksQ0FBQyxxQkFBcUIsQ0FBQyxJQUFJLENBQUMsQ0FBQztTQUNwQztRQUVELCtDQUErQztRQUMvQyxJQUFJLElBQUksQ0FBQyxHQUFHO1lBQUUsSUFBSSxDQUFDLFlBQVksQ0FBQyxlQUFlLENBQUMsSUFBSSxDQUFDLENBQUM7SUFDMUQsQ0FBQztJQUVNLG1DQUFjLEdBQXJCLFVBQXNCLE9BQWU7UUFDakMsSUFBSSxJQUFJLEdBQVcsRUFBRSxDQUFDO1FBQ3RCLElBQUksU0FBUyxHQUFrQixPQUFPLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDO1FBRWxELElBQUksU0FBUyxDQUFDLE1BQU0sR0FBRyxDQUFDLEVBQUU7WUFDdEIsSUFBSSxJQUFJLENBQUMsRUFBRSxHQUFHLENBQUMsU0FBUyxDQUFDLE1BQU0sR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDO1NBQ3pDO1FBQ0Qsd0JBQXdCO1FBQ3hCLElBQUksSUFBSSxDQUFDLE9BQU8sQ0FBQyxvQkFBb0IsRUFBRSxDQUFDLFdBQVcsRUFBRSxLQUFLLEtBQUs7WUFBRSxPQUFPLGlCQUFpQixHQUFHLElBQUksR0FBRyxJQUFJLENBQUM7O1lBQ25HLE9BQU8sT0FBTyxHQUFHLElBQUksR0FBRyxjQUFjLENBQUM7SUFDaEQsQ0FBQztJQUVNLGlDQUFZLEdBQW5CLFVBQW9CLEtBQVU7UUFDMUIsT0FBTyxDQUFDLE9BQU8sS0FBSyxDQUFDLEtBQUssS0FBSyxXQUFXLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDO0lBQ2xFLENBQUM7SUFFTywwQ0FBcUIsR0FBN0IsVUFBOEIsSUFBUztRQUNuQyxJQUFJLE9BQU8sSUFBSSxDQUFDLElBQUksS0FBSyxXQUFXLEVBQUU7WUFDbEMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxRQUFRLENBQUMsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQztTQUN0QzthQUNJO1lBQ0QsSUFBSSxDQUFDLE9BQU8sQ0FBQyxRQUFRLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDO1NBQ2hDO0lBQ0wsQ0FBQztJQUVPLDhCQUFTLEdBQWpCLFVBQWtCLElBQWE7UUFDM0IsSUFBSSxNQUFNLEdBQUcsSUFBSSxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsYUFBYSxDQUFDLGFBQWEsQ0FBQyxpQkFBaUIsQ0FBQyxDQUFDO1FBQzlFLElBQUksQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxRQUFRLENBQUMsTUFBTSxFQUFFLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLFdBQVcsQ0FBQyxNQUFNLEVBQUUsU0FBUyxDQUFDLENBQUM7SUFDdEcsQ0FBQztJQUVPLGlDQUFZLEdBQXBCLFVBQXFCLE1BQWM7UUFDL0IsSUFBSSxDQUFDLGNBQWMsR0FBRyxLQUFLLENBQUM7UUFDNUIsSUFBSSxHQUFHLEdBQWUsTUFBTSxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FBQztRQUN4QyxJQUFJLE9BQU8sR0FBZSxFQUFFLENBQUM7UUFDN0IsSUFBSSxPQUFPLEdBQVcsRUFBRSxDQUFDO1FBRXpCLEtBQUssSUFBSSxDQUFDLEdBQVcsR0FBRyxDQUFDLE1BQU0sR0FBRyxDQUFDLEVBQUUsQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRTtZQUM5QyxPQUFPLEdBQUcsRUFBRSxDQUFDO1lBQ2Isb0NBQW9DO1lBQ3BDLEtBQUssSUFBSSxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxFQUFFLEVBQUU7Z0JBQ3pCLE9BQU8sQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7YUFDeEI7WUFFRCxPQUFPLEdBQUcsT0FBTyxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUM7WUFDekMsSUFBSSxJQUFJLENBQUMsY0FBYyxLQUFLLEtBQUssRUFBRTtnQkFDL0Isc0JBQXNCO2dCQUN0QixJQUFJLENBQUMsVUFBVSxDQUFDLE9BQU8sRUFBRSxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUM7Z0JBQ3BDLElBQUksQ0FBQyxJQUFJLENBQUMsYUFBYSxFQUFFLENBQUM7Z0JBQzFCLHdCQUF3QjthQUMzQjtTQUNKO0lBQ0wsQ0FBQztJQUVPLCtCQUFVLEdBQWxCLFVBQW1CLEdBQVcsRUFBRSxRQUFvQjtRQUNoRCxJQUFJLFVBQVUsR0FBVyxFQUFFLENBQUM7UUFFNUIsS0FBSyxJQUFJLENBQUMsR0FBVyxDQUFDLEVBQUUsQ0FBQyxHQUFHLFFBQVEsQ0FBQyxNQUFNLEVBQUUsQ0FBQyxFQUFFLEVBQUU7WUFDOUMsSUFBSSxPQUFPLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLEtBQUssV0FBVyxFQUFFO2dCQUN6QyxJQUFJLENBQUMsVUFBVSxDQUFDLEdBQUcsRUFBRSxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUM7YUFDMUM7WUFFRCxVQUFVLEdBQUcsQ0FBQyxPQUFPLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLEtBQUssV0FBVyxJQUFJLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLEtBQUssR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDO1lBRXpKLElBQUksVUFBVSxLQUFLLEdBQUcsRUFBRTtnQkFDcEIsSUFBSSxDQUFDLGFBQWEsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztnQkFDaEMsSUFBSSxDQUFDLGNBQWMsR0FBRyxJQUFJLENBQUM7Z0JBQzNCLE1BQU07YUFDVDtTQUNKO0lBQ0wsQ0FBQztJQUVPLGtDQUFhLEdBQXJCLFVBQXNCLElBQVM7UUFDM0IsSUFBSSxDQUFDLFlBQVksQ0FBQyxJQUFJLENBQUMsQ0FBQztRQUN4QixJQUFJLENBQUMsYUFBYSxDQUFDLFVBQVUsR0FBRyxLQUFLLENBQUM7UUFDdEMsSUFBSSxDQUFDLGFBQWEsR0FBRyxJQUFJLENBQUM7UUFDMUIsSUFBSSxDQUFDLFVBQVUsR0FBRyxJQUFJLENBQUM7SUFDM0IsQ0FBQztJQUVPLGlDQUFZLEdBQXBCLFVBQXFCLElBQVM7UUFDMUIsSUFBSSxTQUFTLEdBQUcsSUFBSSxDQUFDLFlBQVksQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLENBQUM7UUFFOUMseUNBQXlDO1FBQ3pDLElBQUksSUFBSSxDQUFDLFlBQVksQ0FBQyxZQUFZLENBQUMsU0FBUyxFQUFFLElBQUksQ0FBQyxXQUFXLENBQUMsSUFBSSxJQUFJLENBQUMsY0FBYyxDQUFDLFFBQVEsQ0FBQyxFQUFFO1lBQzlGLElBQUksQ0FBQyxZQUFZLENBQUMsV0FBVyxDQUFDLFNBQVMsRUFBRSxRQUFRLEVBQUUsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDO1NBQ2pFO1FBRUQsMERBQTBEO2FBQ3JELElBQUksSUFBSSxDQUFDLFdBQVcsQ0FBQyxNQUFNLEdBQUcsU0FBUyxDQUFDLE1BQU0sRUFBRTtZQUNqRCxzREFBc0Q7WUFDdEQsSUFBSSxDQUFDLFlBQVksQ0FBQyxjQUFjLENBQUMsU0FBUyxFQUFFLElBQUksQ0FBQyxXQUFXLEVBQUUsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDO1NBQzVFO1FBRUQsdUVBQXVFO2FBQ2xFO1lBQ0Qsd0NBQXdDO1lBQ3hDLElBQUksSUFBSSxDQUFDLFdBQVcsQ0FBQyxNQUFNLEdBQUcsQ0FBQyxFQUFFO2dCQUM3QixJQUFJLENBQUMsWUFBWSxDQUFDLFdBQVcsQ0FBQyxJQUFJLENBQUMsV0FBVyxFQUFFLE9BQU8sRUFBRSxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUM7YUFDdkU7WUFDRCxLQUFLO1lBQ0wsSUFBSSxDQUFDLFlBQVksQ0FBQyxXQUFXLENBQUMsU0FBUyxFQUFFLE1BQU0sRUFBRSxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUM7U0FDL0Q7UUFDRCxJQUFJLENBQUMsV0FBVyxHQUFHLFNBQVMsQ0FBQztJQUNqQyxDQUFDO0lBRU8sNkJBQVEsR0FBaEI7UUFBQSxpQkFxQkM7UUFwQkcsSUFBSSxDQUFDLElBQUksQ0FBQyxHQUFHO1lBQUUsT0FBTztRQUV0QixJQUFJLENBQUMsR0FBRyxDQUFDLGlCQUFpQixHQUFHLElBQUksQ0FBQyxZQUFZLENBQUMsaUJBQWlCLEVBQUUsQ0FBQztRQUVuRSxJQUFJLENBQUMsR0FBRyxDQUFDLGNBQWMsR0FBRyxVQUFDLE9BQWUsRUFBRSxLQUFrQjtZQUMxRCxJQUFJLE1BQU0sR0FBa0IsS0FBSSxDQUFDLFlBQVksQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLENBQUM7WUFDN0QsSUFBSSxZQUFZLEdBQVEsRUFBRSxDQUFDO1lBQzNCLElBQUksTUFBTSxDQUFDLE1BQU0sR0FBRyxDQUFDLEVBQUU7Z0JBQ25CLFlBQVksR0FBRyxLQUFJLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO2dCQUNwQyxLQUFLLElBQUksQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLEdBQUcsTUFBTSxDQUFDLE1BQU0sRUFBRSxDQUFDLEVBQUUsRUFBRTtvQkFDcEMsWUFBWSxHQUFHLFlBQVksQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7aUJBQy9DO2dCQUVELElBQUksT0FBTyxLQUFLLEtBQUssV0FBVyxFQUFFO29CQUM5QixZQUFZLENBQUMsTUFBTSxDQUFDLEdBQUcsS0FBSyxDQUFDO29CQUM3QixLQUFJLENBQUMsSUFBSSxHQUFHLEtBQUksQ0FBQyxZQUFZLENBQUMsU0FBUyxDQUFDLEtBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQztvQkFDbkQsS0FBSSxDQUFDLFlBQVksQ0FBQyxLQUFJLENBQUMsYUFBYSxDQUFDLENBQUM7aUJBQ3pDO2FBQ0o7UUFDTCxDQUFDLENBQUM7SUFDTixDQUFDOztnQkE1THNCLFNBQVM7Z0JBQ2QsZ0JBQWdCO2dCQUNSLGFBQWE7Z0JBQ2xCLE1BQU07Z0JBQ1QsaUJBQWlCO2dCQUNkLFlBQVk7O0lBVGhCO1FBQWhCLEtBQUssQ0FBQyxRQUFRLENBQUM7a0NBQWEsS0FBSztrREFBTTtJQUMvQjtRQUFSLEtBQUssRUFBRTs7MkNBQVU7SUFWVCxVQUFVO1FBWnRCLFNBQVMsQ0FBQztZQUNQLFFBQVEsRUFBRSxhQUFhO1lBQ3ZCLG90Q0FBeUM7WUFNekMsYUFBYSxFQUFFLGlCQUFpQixDQUFDLElBQUk7WUFDckMsU0FBUyxFQUFFLENBQUMsYUFBYSxFQUFFLFlBQVksQ0FBQztxQkFOL0IsK0RBSVI7U0FHSixDQUFDO3lDQWV5QixTQUFTO1lBQ2QsZ0JBQWdCO1lBQ1IsYUFBYTtZQUNsQixNQUFNO1lBQ1QsaUJBQWlCO1lBQ2QsWUFBWTtPQWxCeEIsVUFBVSxDQTBNdEI7SUFBRCxpQkFBQztDQUFBLEFBMU1ELElBME1DO1NBMU1ZLFVBQVUiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBDb21wb25lbnQsIElucHV0LCBPbkluaXQsIEFmdGVyVmlld0luaXQsIFZpZXdFbmNhcHN1bGF0aW9uLCBWaWV3Q29udGFpbmVyUmVmLCBDaGFuZ2VEZXRlY3RvclJlZiwgU2ltcGxlQ2hhbmdlcywgUmVuZGVyZXIyIH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XHJcbmltcG9ydCB7IHRpbWVyLCBTdWJzY3JpcHRpb24gfSBmcm9tICdyeGpzJztcclxuaW1wb3J0IHsgUm91dGVyLCBOYXZpZ2F0aW9uRW5kIH0gZnJvbSAnQGFuZ3VsYXIvcm91dGVyJztcclxuaW1wb3J0IHsgS2REb21FbGVtU3ZjIH0gZnJvbSAnLi4va2QtY29tbW9uL2luZGV4JztcclxuaW1wb3J0IHsgS2RMZWZ0bWVudVN2YyB9IGZyb20gJy4va2QtYW5ndWxhci1sZWZ0bWVudS1zdmMnO1xyXG5cclxuQENvbXBvbmVudCh7XHJcbiAgICBzZWxlY3RvcjogJ2tkLWxlZnRtZW51JyxcclxuICAgIHRlbXBsYXRlVXJsOiAnLi9rZC1hbmd1bGFyLWxlZnRtZW51Lmh0bWwnLFxyXG4gICAgc3R5bGVzOiBbYFxyXG4gICAgICAgIC5hbHBoYS0we1xyXG4gICAgICAgICAgICBvcGFjaXR5OiAwO1xyXG4gICAgICAgIH1cclxuICAgIGBdLFxyXG4gICAgZW5jYXBzdWxhdGlvbjogVmlld0VuY2Fwc3VsYXRpb24uTm9uZSxcclxuICAgIHByb3ZpZGVyczogW0tkTGVmdG1lbnVTdmMsIEtkRG9tRWxlbVN2Y11cclxufSlcclxuXHJcbmV4cG9ydCBjbGFzcyBLZExlZnRNZW51IGltcGxlbWVudHMgT25Jbml0LCBBZnRlclZpZXdJbml0IHtcclxuICAgIHB1YmxpYyBsaXN0OiBBcnJheTxhbnk+ID0gW107XHJcbiAgICBwcml2YXRlIF9wcmV2aW91c0lkOiBBcnJheTxudW1iZXI+ID0gW107XHJcbiAgICBwcml2YXRlIF9wcmV2aW91c0l0ZW06IGFueSA9IHt9O1xyXG4gICAgcHJpdmF0ZSBfYWN0aXZlSWRGb3VuZDogYm9vbGVhbiA9IGZhbHNlO1xyXG4gICAgcHJpdmF0ZSBfZmlyc3RSb3V0ZUNoZWNrOiBib29sZWFuID0gdHJ1ZTtcclxuICAgIHByaXZhdGUgX3JvdXRlclN1YjogU3Vic2NyaXB0aW9uO1xyXG4gICAgcHJpdmF0ZSBfY3VycmVudFJvdXRlOiBzdHJpbmcgPSAnJztcclxuXHJcbiAgICBASW5wdXQoJ2NvbmZpZycpIHNpZGVDb25maWc6IEFycmF5PGFueT47XHJcbiAgICBASW5wdXQoKSBhcGk6IGFueTtcclxuXHJcbiAgICBjb25zdHJ1Y3RvcihcclxuICAgICAgICBwcml2YXRlIF9yZW5kZXJlcjogUmVuZGVyZXIyLFxyXG4gICAgICAgIHByaXZhdGUgX3ZjcjogVmlld0NvbnRhaW5lclJlZixcclxuICAgICAgICBwcml2YXRlIF9sZWZ0bWVudVN2YzogS2RMZWZ0bWVudVN2YyxcclxuICAgICAgICBwcml2YXRlIF9yb3V0ZXI6IFJvdXRlcixcclxuICAgICAgICBwcml2YXRlIF9jZGY6IENoYW5nZURldGVjdG9yUmVmLFxyXG4gICAgICAgIHByaXZhdGUgX2RvbVN2YzogS2REb21FbGVtU3ZjXHJcbiAgICApIHtcclxuICAgICAgICB0aGlzLl9yb3V0ZXJTdWIgPSBfcm91dGVyLmV2ZW50cy5zdWJzY3JpYmUoZXZlbnQgPT4ge1xyXG4gICAgICAgICAgICBpZiAoZXZlbnQgaW5zdGFuY2VvZiBOYXZpZ2F0aW9uRW5kKSB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLl9jdXJyZW50Um91dGUgPSBldmVudC51cmxBZnRlclJlZGlyZWN0cztcclxuICAgICAgICAgICAgICAgIGlmICghdGhpcy5fZmlyc3RSb3V0ZUNoZWNrKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5fc2V0SW5pdE9wZW4oZXZlbnQudXJsQWZ0ZXJSZWRpcmVjdHMpO1xyXG4gICAgICAgICAgICAgICAgICAgIC8vIGNsb3NlIHRoZSBwcmV2aW91cyBpdGVtIGlmIGN1cnJlbnQgY2xpY2tlZCBwYXRoIGRvIG5vdCBtdWNoIGFueSBwYXRoIGluIHRoZSBzaWRlbWVudVxyXG4gICAgICAgICAgICAgICAgICAgIGlmICghdGhpcy5fYWN0aXZlSWRGb3VuZCAmJiB0eXBlb2YgdGhpcy5fcHJldmlvdXNJdGVtLm5hdl9pZCAhPT0gJ3VuZGVmaW5lZCcpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgbGV0IGNsb3NlOiBBcnJheTxhbnk+ID0gdGhpcy5fbGVmdG1lbnVTdmMuZ2V0SWQodGhpcy5fcHJldmlvdXNJdGVtKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5fbGVmdG1lbnVTdmMudG9nZ2xlU3RhdGUoY2xvc2UsICdjbG9zZScsIHRoaXMubGlzdCk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuX3ByZXZpb3VzSWQgPSBbXTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5fcHJldmlvdXNJdGVtID0ge307XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfSk7XHJcbiAgICB9XHJcblxyXG4gICAgbmdPbkluaXQoKTogdm9pZCB7XHJcbiAgICAgICAgdGhpcy5faW5pdEFwaSgpO1xyXG4gICAgfVxyXG5cclxuICAgIG5nT25DaGFuZ2VzKF9zaW1wbGVDaGFuZ2VzOiBTaW1wbGVDaGFuZ2VzKTogdm9pZCB7XHJcbiAgICAgICAgaWYgKF9zaW1wbGVDaGFuZ2VzLmhhc093blByb3BlcnR5KCdzaWRlQ29uZmlnJykpIHtcclxuICAgICAgICAgICAgdGhpcy5saXN0ID0gdGhpcy5fbGVmdG1lbnVTdmMuc2V0SXNPcGVuKHRoaXMuc2lkZUNvbmZpZyk7XHJcblxyXG4gICAgICAgICAgICBpZiAoX3NpbXBsZUNoYW5nZXMuc2lkZUNvbmZpZy5pc0ZpcnN0Q2hhbmdlKSB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLl9zZXRBbHBoYSh0cnVlKTtcclxuXHJcbiAgICAgICAgICAgICAgICB0aW1lcig1MDApLnN1YnNjcmliZSgoKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5fc2V0SW5pdE9wZW4odGhpcy5fcm91dGVyLnVybCk7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5fc2V0QWxwaGEoZmFsc2UpO1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuX2ZpcnN0Um91dGVDaGVjayA9IGZhbHNlO1xyXG4gICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgbmdBZnRlclZpZXdJbml0KCk6IHZvaWQgeyB9XHJcblxyXG4gICAgbmdPbkRlc3Ryb3koKTogdm9pZCB7XHJcbiAgICAgICAgaWYgKHR5cGVvZiB0aGlzLl9yb3V0ZXJTdWIgIT09ICd1bmRlZmluZWQnKSB7XHJcbiAgICAgICAgICAgIHRoaXMuX3JvdXRlclN1Yi51bnN1YnNjcmliZSgpO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICBwdWJsaWMgY2xpY2tUb2dnbGUoaXRlbTogYW55KTogdm9pZCB7XHJcbiAgICAgICAgdGhpcy5fY2hlY2tUb2dnbGUoaXRlbSk7XHJcblxyXG4gICAgICAgIGlmICh0eXBlb2YgaXRlbS5saXN0ID09PSAndW5kZWZpbmVkJykge1xyXG4gICAgICAgICAgICB0aGlzLl9jaGVja1BhdGhBbmROYXZpZ2F0ZShpdGVtKTtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIC8vIHRyaWdnZXJzIGNsaWNrIGV2ZW50IHdoZW4gYXBpIGlzIGluaXRpYWxpc2VkXHJcbiAgICAgICAgaWYgKHRoaXMuYXBpKSB0aGlzLl9sZWZ0bWVudVN2Yy5tZW51SXRlbUNsaWNrZWQoaXRlbSk7XHJcbiAgICB9XHJcblxyXG4gICAgcHVibGljIGdldFBhZGRpbmdTaXplKF9pdGVtSWQ6IHN0cmluZyk6IHN0cmluZyB7XHJcbiAgICAgICAgbGV0IHNpemU6IG51bWJlciA9IDEwO1xyXG4gICAgICAgIGxldCBuYXZMZXZlbHM6IEFycmF5PHN0cmluZz4gPSBfaXRlbUlkLnNwbGl0KCctJyk7XHJcblxyXG4gICAgICAgIGlmIChuYXZMZXZlbHMubGVuZ3RoID4gMikge1xyXG4gICAgICAgICAgICBzaXplICs9ICgxNyAqIChuYXZMZXZlbHMubGVuZ3RoIC0gMikpO1xyXG4gICAgICAgIH1cclxuICAgICAgICAvLyBjb25zb2xlLmxvZyhfaXRlbUlkKTtcclxuICAgICAgICBpZiAodGhpcy5fZG9tU3ZjLmdldERvY3VtZW50RGlyZWN0aW9uKCkudG9Mb3dlckNhc2UoKSA9PT0gJ2x0cicpIHJldHVybiAnMTBweCAyNXB4IDEwcHggJyArIHNpemUgKyAncHgnO1xyXG4gICAgICAgIGVsc2UgcmV0dXJuICcxMHB4ICcgKyBzaXplICsgJ3B4IDEwcHggMjVweCc7XHJcbiAgICB9XHJcblxyXG4gICAgcHVibGljIGdldEl0ZW1PcmRlcihfaXRlbTogYW55KTogbnVtYmVyIHtcclxuICAgICAgICByZXR1cm4gKHR5cGVvZiBfaXRlbS5vcmRlciA9PT0gJ3VuZGVmaW5lZCcpID8gMSA6IF9pdGVtLm9yZGVyO1xyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX2NoZWNrUGF0aEFuZE5hdmlnYXRlKGl0ZW06IGFueSk6IHZvaWQge1xyXG4gICAgICAgIGlmICh0eXBlb2YgaXRlbS5wYXRoICE9PSAndW5kZWZpbmVkJykge1xyXG4gICAgICAgICAgICB0aGlzLl9yb3V0ZXIubmF2aWdhdGUoW2l0ZW0ucGF0aF0pO1xyXG4gICAgICAgIH1cclxuICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgdGhpcy5fcm91dGVyLm5hdmlnYXRlKFsnLyddKTtcclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfc2V0QWxwaGEoYm9vbDogYm9vbGVhbik6IHZvaWQge1xyXG4gICAgICAgIGxldCB1bExpc3QgPSB0aGlzLl92Y3IuZWxlbWVudC5uYXRpdmVFbGVtZW50LnF1ZXJ5U2VsZWN0b3IoJ3VsLm5hdi5yb290LW5hdicpO1xyXG4gICAgICAgIGJvb2wgPyB0aGlzLl9yZW5kZXJlci5hZGRDbGFzcyh1bExpc3QsICdhbHBoYS0wJykgOiB0aGlzLl9yZW5kZXJlci5yZW1vdmVDbGFzcyh1bExpc3QsICdhbHBoYS0wJyk7XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfc2V0SW5pdE9wZW4ocmF3VXJsOiBzdHJpbmcpOiB2b2lkIHtcclxuICAgICAgICB0aGlzLl9hY3RpdmVJZEZvdW5kID0gZmFsc2U7XHJcbiAgICAgICAgbGV0IHVybDogQXJyYXk8YW55PiA9IHJhd1VybC5zcGxpdCgnLycpO1xyXG4gICAgICAgIGxldCB0ZXN0VXJsOiBBcnJheTxhbnk+ID0gW107XHJcbiAgICAgICAgbGV0IGpvaW5Vcmw6IHN0cmluZyA9ICcnO1xyXG5cclxuICAgICAgICBmb3IgKGxldCBpOiBudW1iZXIgPSB1cmwubGVuZ3RoIC0gMTsgaSA+PSAwOyBpLS0pIHtcclxuICAgICAgICAgICAgdGVzdFVybCA9IFtdO1xyXG4gICAgICAgICAgICAvLyAgY29uc29sZS5sb2coJy0tLS0+IHJvdW5kICcgKyBpKTtcclxuICAgICAgICAgICAgZm9yIChsZXQgaiA9IDA7IGogPD0gaTsgaisrKSB7XHJcbiAgICAgICAgICAgICAgICB0ZXN0VXJsLnB1c2godXJsW2pdKTtcclxuICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgam9pblVybCA9IHRlc3RVcmwuam9pbignLycpLnN1YnN0cmluZygxKTtcclxuICAgICAgICAgICAgaWYgKHRoaXMuX2FjdGl2ZUlkRm91bmQgPT09IGZhbHNlKSB7XHJcbiAgICAgICAgICAgICAgICAvLyB0aGlzLl9jZGYuZGV0YWNoKCk7XHJcbiAgICAgICAgICAgICAgICB0aGlzLl9jaGVja1BhdGgoam9pblVybCwgdGhpcy5saXN0KTtcclxuICAgICAgICAgICAgICAgIHRoaXMuX2NkZi5kZXRlY3RDaGFuZ2VzKCk7XHJcbiAgICAgICAgICAgICAgICAvLyB0aGlzLl9jZGYucmVhdHRhY2goKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF9jaGVja1BhdGgodXJsOiBzdHJpbmcsIGl0ZW1MaXN0OiBBcnJheTxhbnk+KTogdm9pZCB7XHJcbiAgICAgICAgbGV0IHJlc3VsdFBhdGg6IHN0cmluZyA9ICcnO1xyXG5cclxuICAgICAgICBmb3IgKGxldCBpOiBudW1iZXIgPSAwOyBpIDwgaXRlbUxpc3QubGVuZ3RoOyBpKyspIHtcclxuICAgICAgICAgICAgaWYgKHR5cGVvZiBpdGVtTGlzdFtpXS5saXN0ICE9PSAndW5kZWZpbmVkJykge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5fY2hlY2tQYXRoKHVybCwgaXRlbUxpc3RbaV0ubGlzdCk7XHJcbiAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgIHJlc3VsdFBhdGggPSAodHlwZW9mIGl0ZW1MaXN0W2ldLmJhc2VQYXRoICE9PSAndW5kZWZpbmVkJyAmJiBpdGVtTGlzdFtpXS5iYXNlUGF0aFswXSA9PT0gJy8nKSA/IGl0ZW1MaXN0W2ldLmJhc2VQYXRoLnN1YnN0cmluZygxKSA6IGl0ZW1MaXN0W2ldLmJhc2VQYXRoO1xyXG5cclxuICAgICAgICAgICAgaWYgKHJlc3VsdFBhdGggPT09IHVybCkge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5faXRlbVNlbGVjdGVkKGl0ZW1MaXN0W2ldKTtcclxuICAgICAgICAgICAgICAgIHRoaXMuX2FjdGl2ZUlkRm91bmQgPSB0cnVlO1xyXG4gICAgICAgICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfaXRlbVNlbGVjdGVkKGl0ZW06IGFueSk6IHZvaWQge1xyXG4gICAgICAgIHRoaXMuX2NoZWNrVG9nZ2xlKGl0ZW0pO1xyXG4gICAgICAgIHRoaXMuX3ByZXZpb3VzSXRlbS5pc1NlbGVjdGVkID0gZmFsc2U7XHJcbiAgICAgICAgdGhpcy5fcHJldmlvdXNJdGVtID0gaXRlbTtcclxuICAgICAgICBpdGVtLmlzU2VsZWN0ZWQgPSB0cnVlO1xyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX2NoZWNrVG9nZ2xlKGl0ZW06IGFueSk6IHZvaWQge1xyXG4gICAgICAgIGxldCBjdXJyZW50SWQgPSB0aGlzLl9sZWZ0bWVudVN2Yy5nZXRJZChpdGVtKTtcclxuXHJcbiAgICAgICAgLy8gaWYgdXNlciBjbGlja2VkIHRoZSBzYW1lLCB0b2dnbGUgc3RhdGVcclxuICAgICAgICBpZiAodGhpcy5fbGVmdG1lbnVTdmMuaXNBcnJheUVxdWFsKGN1cnJlbnRJZCwgdGhpcy5fcHJldmlvdXNJZCkgJiYgaXRlbS5oYXNPd25Qcm9wZXJ0eSgnaXNPcGVuJykpIHtcclxuICAgICAgICAgICAgdGhpcy5fbGVmdG1lbnVTdmMudG9nZ2xlU3RhdGUoY3VycmVudElkLCAndG9nZ2xlJywgdGhpcy5saXN0KTtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIC8vIGlmIHVzZXIgY2xpY2tlZCBvbiBzb21ldGhpbmcgbW9yZSBvbiB0aGUgc3VyZmFjZSwgY2hlY2tcclxuICAgICAgICBlbHNlIGlmICh0aGlzLl9wcmV2aW91c0lkLmxlbmd0aCA+IGN1cnJlbnRJZC5sZW5ndGgpIHtcclxuICAgICAgICAgICAgLy8gIHRoaXMuX2Nsb3NlRGlmZmVyZW50KGN1cnJlbnRJZCwgdGhpcy5fcHJldmlvdXNJZCk7XHJcbiAgICAgICAgICAgIHRoaXMuX2xlZnRtZW51U3ZjLmNsb3NlRGlmZmVyZW50KGN1cnJlbnRJZCwgdGhpcy5fcHJldmlvdXNJZCwgdGhpcy5saXN0KTtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIC8vIGlmIHVzZXIgY2xpY2tlZCBvbiBzb21ldGhpbmcgZGVlcGVyLCBjbG9zZSBwcmV2aW91cyBhbmQgb3BlbiBjdXJyZW50XHJcbiAgICAgICAgZWxzZSB7XHJcbiAgICAgICAgICAgIC8vICBpZiAoaXRlbS5oYXNPd25Qcm9wZXJ0eSgnaXNPcGVuJykpIHtcclxuICAgICAgICAgICAgaWYgKHRoaXMuX3ByZXZpb3VzSWQubGVuZ3RoID4gMCkge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5fbGVmdG1lbnVTdmMudG9nZ2xlU3RhdGUodGhpcy5fcHJldmlvdXNJZCwgJ2Nsb3NlJywgdGhpcy5saXN0KTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAvLyAgfVxyXG4gICAgICAgICAgICB0aGlzLl9sZWZ0bWVudVN2Yy50b2dnbGVTdGF0ZShjdXJyZW50SWQsICdvcGVuJywgdGhpcy5saXN0KTtcclxuICAgICAgICB9XHJcbiAgICAgICAgdGhpcy5fcHJldmlvdXNJZCA9IGN1cnJlbnRJZDtcclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF9pbml0QXBpKCk6IHZvaWQge1xyXG4gICAgICAgIGlmICghdGhpcy5hcGkpIHJldHVybjtcclxuXHJcbiAgICAgICAgdGhpcy5hcGkub25NZW51SXRlbUNsaWNrZWQgPSB0aGlzLl9sZWZ0bWVudVN2Yy5vbk1lbnVJdGVtQ2xpY2tlZCgpO1xyXG5cclxuICAgICAgICB0aGlzLmFwaS51cGRhdGVNZW51TGlzdCA9IChfbmF2X2lkOiBzdHJpbmcsIF9saXN0PzogQXJyYXk8YW55PikgPT4ge1xyXG4gICAgICAgICAgICBsZXQgbmF2UG9zOiBBcnJheTxudW1iZXI+ID0gdGhpcy5fbGVmdG1lbnVTdmMuZ2V0SWQoX25hdl9pZCk7XHJcbiAgICAgICAgICAgIGxldCBzZWxlY3RlZEl0ZW06IGFueSA9IHt9O1xyXG4gICAgICAgICAgICBpZiAobmF2UG9zLmxlbmd0aCA+IDApIHtcclxuICAgICAgICAgICAgICAgIHNlbGVjdGVkSXRlbSA9IHRoaXMubGlzdFtuYXZQb3NbMF1dO1xyXG4gICAgICAgICAgICAgICAgZm9yIChsZXQgaSA9IDE7IGkgPCBuYXZQb3MubGVuZ3RoOyBpKyspIHtcclxuICAgICAgICAgICAgICAgICAgICBzZWxlY3RlZEl0ZW0gPSBzZWxlY3RlZEl0ZW0ubGlzdFtuYXZQb3NbaV1dO1xyXG4gICAgICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgICAgIGlmICh0eXBlb2YgX2xpc3QgIT09ICd1bmRlZmluZWQnKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgc2VsZWN0ZWRJdGVtWydsaXN0J10gPSBfbGlzdDtcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLmxpc3QgPSB0aGlzLl9sZWZ0bWVudVN2Yy5zZXRJc09wZW4odGhpcy5saXN0KTtcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLl9zZXRJbml0T3Blbih0aGlzLl9jdXJyZW50Um91dGUpO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfTtcclxuICAgIH1cclxufVxyXG4iXX0=