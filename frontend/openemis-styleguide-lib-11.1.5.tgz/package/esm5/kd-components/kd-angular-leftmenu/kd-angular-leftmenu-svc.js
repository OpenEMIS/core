import { __decorate, __metadata } from "tslib";
import { Injectable } from '@angular/core';
import { KdBroadcaster } from '../kd-common/index';
var KdLeftmenuSvc = /** @class */ (function () {
    function KdLeftmenuSvc(broadcaster) {
        this.broadcaster = broadcaster;
    }
    // set isOpen property to objects with list (lv1, lv2, lv3) - nested navs
    KdLeftmenuSvc.prototype.setIsOpen = function (_sideConfig) {
        if (typeof _sideConfig === 'undefined')
            return [];
        var updateResult = _sideConfig.slice();
        this._processNavItem(updateResult);
        return updateResult;
    };
    KdLeftmenuSvc.prototype.isArrayEqual = function (currentItem, previousItem) {
        if (currentItem.length !== previousItem.length) {
            return false;
        }
        for (var i = 0; i < currentItem.length; i++) {
            if (currentItem[i] !== previousItem[i]) {
                return false;
            }
        }
        return true;
    };
    KdLeftmenuSvc.prototype.getId = function (item) {
        var nav_id = (typeof item === 'string') ? item : item.nav_id;
        var currentId = nav_id.split('-');
        currentId.splice(0, 1);
        for (var i = 0; i < currentId.length; i++) {
            currentId[i] = +currentId[i];
        }
        return currentId;
    };
    KdLeftmenuSvc.prototype.closeDifferent = function (currentItem, previousItem, _navItems) {
        var currentNode = {};
        var previousCurrentNode = {};
        var previousNode;
        var diffBranch = false;
        for (var i = 0; i < previousItem.length; i++) {
            if (i === 0) {
                previousCurrentNode = _navItems[previousItem[i]];
                currentNode = _navItems[currentItem[i]];
            }
            else {
                previousCurrentNode = previousCurrentNode.list[previousItem[i]];
                if (typeof currentItem[i] !== 'undefined') {
                    currentNode = currentNode.list[currentItem[i]];
                }
                else {
                    currentNode = undefined;
                }
            }
            /**********set the previous node to true only when there is next node*******************
            e.g.
              previous node open -    0 0 0          previous node open -  0 0 0
              current node open  -    0              current node open  -  0 0
              current node should be closed          current node at index 0 is open, index 1 is closed
            *********************************************************************************/
            if (previousCurrentNode.hasOwnProperty('isOpen')) {
                if (typeof previousNode !== 'undefined' && typeof currentItem[i] !== 'undefined') {
                    previousNode.isOpen = true;
                }
                if (currentItem[i] === previousItem[i] && diffBranch === false) {
                    previousNode = previousCurrentNode;
                    previousCurrentNode.isOpen = false;
                }
                else {
                    diffBranch = true;
                    previousCurrentNode.isOpen = false;
                    if (typeof currentNode !== 'undefined') {
                        if (typeof currentNode.isOpen !== 'undefined')
                            currentNode.isOpen = true;
                        else
                            currentNode.isSelected = true;
                    }
                }
            }
        }
    };
    KdLeftmenuSvc.prototype.toggleState = function (currentId, state, _navItems) {
        var currentNode = {};
        for (var i = 0; i < currentId.length; i++) {
            currentNode = (i === 0) ? _navItems[currentId[i]] : currentNode.list[currentId[i]];
            if (typeof currentNode.isOpen !== 'undefined') {
                if (state === 'open') {
                    currentNode.isOpen = true;
                }
                else if (state === 'close') {
                    currentNode.isOpen = false;
                }
                else if (state === 'toggle' && i === currentId.length - 1) {
                    currentNode.isOpen = !currentNode.isOpen;
                }
            }
            else if (typeof currentNode.isSelected !== 'undefined' && i === currentId.length - 1) {
                currentNode.isSelected = false;
            }
        }
    };
    KdLeftmenuSvc.prototype._processNavItem = function (_navItems, _prefix) {
        for (var i = 0; i < _navItems.length; i++) {
            var itemId = this._idFormatter(i, _prefix);
            _navItems[i]['nav_id'] = itemId;
            this._checkNavItem(_navItems[i], itemId);
        }
    };
    KdLeftmenuSvc.prototype._checkNavItem = function (_item, _prefix) {
        if (typeof _item.list !== 'undefined') {
            _item.isOpen = false;
            this._processNavItem(_item.list, _prefix);
        }
        else {
            _item.isSelected = false;
            if (typeof _item.basePath === 'undefined') {
                _item.basePath = _item.path;
            }
        }
    };
    KdLeftmenuSvc.prototype._idFormatter = function (_number, _prefix) {
        var prefix = (typeof _prefix === 'undefined') ? 'nav' : _prefix;
        var formatString = prefix;
        formatString += '-' + _number.toString();
        return formatString;
    };
    /* For API Usage  */
    KdLeftmenuSvc.prototype.onMenuItemClicked = function () {
        return this.broadcaster.on('KdGridsterEvent_onRemoved');
    };
    KdLeftmenuSvc.prototype.menuItemClicked = function (_item) {
        this.broadcaster.broadcast('KdGridsterEvent_onRemoved');
    };
    KdLeftmenuSvc.ctorParameters = function () { return [
        { type: KdBroadcaster }
    ]; };
    KdLeftmenuSvc = __decorate([
        Injectable(),
        __metadata("design:paramtypes", [KdBroadcaster])
    ], KdLeftmenuSvc);
    return KdLeftmenuSvc;
}());
export { KdLeftmenuSvc };
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoia2QtYW5ndWxhci1sZWZ0bWVudS1zdmMuanMiLCJzb3VyY2VSb290Ijoibmc6Ly9vcGVuZW1pcy1zdHlsZWd1aWRlLWxpYi8iLCJzb3VyY2VzIjpbImtkLWNvbXBvbmVudHMva2QtYW5ndWxhci1sZWZ0bWVudS9rZC1hbmd1bGFyLWxlZnRtZW51LXN2Yy50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiO0FBQUEsT0FBTyxFQUFFLFVBQVUsRUFBRSxNQUFNLGVBQWUsQ0FBQztBQUMzQyxPQUFPLEVBQUUsYUFBYSxFQUFFLE1BQU0sb0JBQW9CLENBQUM7QUFJbkQ7SUFDSSx1QkFBb0IsV0FBMEI7UUFBMUIsZ0JBQVcsR0FBWCxXQUFXLENBQWU7SUFBSSxDQUFDO0lBRW5ELHlFQUF5RTtJQUNsRSxpQ0FBUyxHQUFoQixVQUFpQixXQUF1QjtRQUNwQyxJQUFJLE9BQU8sV0FBVyxLQUFLLFdBQVc7WUFBRSxPQUFPLEVBQUUsQ0FBQztRQUVsRCxJQUFJLFlBQVksR0FBZSxXQUFXLENBQUMsS0FBSyxFQUFFLENBQUM7UUFDbkQsSUFBSSxDQUFDLGVBQWUsQ0FBQyxZQUFZLENBQUMsQ0FBQztRQUVuQyxPQUFPLFlBQVksQ0FBQztJQUN4QixDQUFDO0lBRU0sb0NBQVksR0FBbkIsVUFBb0IsV0FBMEIsRUFBRSxZQUEyQjtRQUN2RSxJQUFJLFdBQVcsQ0FBQyxNQUFNLEtBQUssWUFBWSxDQUFDLE1BQU0sRUFBRTtZQUM1QyxPQUFPLEtBQUssQ0FBQztTQUNoQjtRQUNELEtBQUssSUFBSSxDQUFDLEdBQVcsQ0FBQyxFQUFFLENBQUMsR0FBRyxXQUFXLENBQUMsTUFBTSxFQUFFLENBQUMsRUFBRSxFQUFFO1lBQ2pELElBQUksV0FBVyxDQUFDLENBQUMsQ0FBQyxLQUFLLFlBQVksQ0FBQyxDQUFDLENBQUMsRUFBRTtnQkFDcEMsT0FBTyxLQUFLLENBQUM7YUFDaEI7U0FDSjtRQUNELE9BQU8sSUFBSSxDQUFDO0lBQ2hCLENBQUM7SUFHTSw2QkFBSyxHQUFaLFVBQWEsSUFBa0I7UUFDM0IsSUFBSSxNQUFNLEdBQVcsQ0FBQyxPQUFPLElBQUksS0FBSyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDO1FBQ3JFLElBQUksU0FBUyxHQUFlLE1BQU0sQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLENBQUM7UUFDOUMsU0FBUyxDQUFDLE1BQU0sQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUM7UUFFdkIsS0FBSyxJQUFJLENBQUMsR0FBVyxDQUFDLEVBQUUsQ0FBQyxHQUFHLFNBQVMsQ0FBQyxNQUFNLEVBQUUsQ0FBQyxFQUFFLEVBQUU7WUFDL0MsU0FBUyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDO1NBQ2hDO1FBQ0QsT0FBTyxTQUFTLENBQUM7SUFDckIsQ0FBQztJQUVNLHNDQUFjLEdBQXJCLFVBQXNCLFdBQTBCLEVBQUUsWUFBMkIsRUFBRSxTQUFxQjtRQUNoRyxJQUFJLFdBQVcsR0FBUSxFQUFFLENBQUM7UUFDMUIsSUFBSSxtQkFBbUIsR0FBUSxFQUFFLENBQUM7UUFDbEMsSUFBSSxZQUFpQixDQUFDO1FBQ3RCLElBQUksVUFBVSxHQUFZLEtBQUssQ0FBQztRQUVoQyxLQUFLLElBQUksQ0FBQyxHQUFXLENBQUMsRUFBRSxDQUFDLEdBQUcsWUFBWSxDQUFDLE1BQU0sRUFBRSxDQUFDLEVBQUUsRUFBRTtZQUNsRCxJQUFJLENBQUMsS0FBSyxDQUFDLEVBQUU7Z0JBQ1QsbUJBQW1CLEdBQUcsU0FBUyxDQUFDLFlBQVksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO2dCQUNqRCxXQUFXLEdBQUcsU0FBUyxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO2FBQzNDO2lCQUNJO2dCQUNELG1CQUFtQixHQUFHLG1CQUFtQixDQUFDLElBQUksQ0FBQyxZQUFZLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztnQkFDaEUsSUFBSSxPQUFPLFdBQVcsQ0FBQyxDQUFDLENBQUMsS0FBSyxXQUFXLEVBQUU7b0JBQ3ZDLFdBQVcsR0FBRyxXQUFXLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO2lCQUNsRDtxQkFDSTtvQkFDRCxXQUFXLEdBQUcsU0FBUyxDQUFDO2lCQUMzQjthQUNKO1lBRUQ7Ozs7OzhGQUtrRjtZQUdsRixJQUFJLG1CQUFtQixDQUFDLGNBQWMsQ0FBQyxRQUFRLENBQUMsRUFBRTtnQkFDOUMsSUFBSSxPQUFPLFlBQVksS0FBSyxXQUFXLElBQUksT0FBTyxXQUFXLENBQUMsQ0FBQyxDQUFDLEtBQUssV0FBVyxFQUFFO29CQUM5RSxZQUFZLENBQUMsTUFBTSxHQUFHLElBQUksQ0FBQztpQkFDOUI7Z0JBRUQsSUFBSSxXQUFXLENBQUMsQ0FBQyxDQUFDLEtBQUssWUFBWSxDQUFDLENBQUMsQ0FBQyxJQUFJLFVBQVUsS0FBSyxLQUFLLEVBQUU7b0JBQzVELFlBQVksR0FBRyxtQkFBbUIsQ0FBQztvQkFDbkMsbUJBQW1CLENBQUMsTUFBTSxHQUFHLEtBQUssQ0FBQztpQkFDdEM7cUJBQ0k7b0JBQ0QsVUFBVSxHQUFHLElBQUksQ0FBQztvQkFDbEIsbUJBQW1CLENBQUMsTUFBTSxHQUFHLEtBQUssQ0FBQztvQkFDbkMsSUFBSSxPQUFPLFdBQVcsS0FBSyxXQUFXLEVBQUU7d0JBQ3BDLElBQUksT0FBTyxXQUFXLENBQUMsTUFBTSxLQUFLLFdBQVc7NEJBQUUsV0FBVyxDQUFDLE1BQU0sR0FBRyxJQUFJLENBQUM7OzRCQUNwRSxXQUFXLENBQUMsVUFBVSxHQUFHLElBQUksQ0FBQztxQkFDdEM7aUJBQ0o7YUFDSjtTQUNKO0lBQ0wsQ0FBQztJQUVNLG1DQUFXLEdBQWxCLFVBQW1CLFNBQXFCLEVBQUUsS0FBYSxFQUFFLFNBQXFCO1FBQzFFLElBQUksV0FBVyxHQUFRLEVBQUUsQ0FBQztRQUMxQixLQUFLLElBQUksQ0FBQyxHQUFXLENBQUMsRUFBRSxDQUFDLEdBQUcsU0FBUyxDQUFDLE1BQU0sRUFBRSxDQUFDLEVBQUUsRUFBRTtZQUUvQyxXQUFXLEdBQUcsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsV0FBVyxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztZQUduRixJQUFJLE9BQU8sV0FBVyxDQUFDLE1BQU0sS0FBSyxXQUFXLEVBQUU7Z0JBQzNDLElBQUksS0FBSyxLQUFLLE1BQU0sRUFBRTtvQkFDbEIsV0FBVyxDQUFDLE1BQU0sR0FBRyxJQUFJLENBQUM7aUJBQzdCO3FCQUVJLElBQUksS0FBSyxLQUFLLE9BQU8sRUFBRTtvQkFDeEIsV0FBVyxDQUFDLE1BQU0sR0FBRyxLQUFLLENBQUM7aUJBQzlCO3FCQUVJLElBQUksS0FBSyxLQUFLLFFBQVEsSUFBSSxDQUFDLEtBQUssU0FBUyxDQUFDLE1BQU0sR0FBRyxDQUFDLEVBQUU7b0JBQ3ZELFdBQVcsQ0FBQyxNQUFNLEdBQUcsQ0FBQyxXQUFXLENBQUMsTUFBTSxDQUFDO2lCQUM1QzthQUNKO2lCQUNJLElBQUksT0FBTyxXQUFXLENBQUMsVUFBVSxLQUFLLFdBQVcsSUFBSSxDQUFDLEtBQUssU0FBUyxDQUFDLE1BQU0sR0FBRyxDQUFDLEVBQUU7Z0JBQ2xGLFdBQVcsQ0FBQyxVQUFVLEdBQUcsS0FBSyxDQUFDO2FBQ2xDO1NBQ0o7SUFDTCxDQUFDO0lBR08sdUNBQWUsR0FBdkIsVUFBd0IsU0FBcUIsRUFBRSxPQUFnQjtRQUMzRCxLQUFLLElBQUksQ0FBQyxHQUFXLENBQUMsRUFBRSxDQUFDLEdBQUcsU0FBUyxDQUFDLE1BQU0sRUFBRSxDQUFDLEVBQUUsRUFBRTtZQUMvQyxJQUFJLE1BQU0sR0FBVyxJQUFJLENBQUMsWUFBWSxDQUFDLENBQUMsRUFBRSxPQUFPLENBQUMsQ0FBQztZQUNuRCxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLEdBQUcsTUFBTSxDQUFDO1lBQ2hDLElBQUksQ0FBQyxhQUFhLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxFQUFFLE1BQU0sQ0FBQyxDQUFDO1NBQzVDO0lBQ0wsQ0FBQztJQUVPLHFDQUFhLEdBQXJCLFVBQXNCLEtBQVUsRUFBRSxPQUFnQjtRQUM5QyxJQUFJLE9BQU8sS0FBSyxDQUFDLElBQUksS0FBSyxXQUFXLEVBQUU7WUFDbkMsS0FBSyxDQUFDLE1BQU0sR0FBRyxLQUFLLENBQUM7WUFDckIsSUFBSSxDQUFDLGVBQWUsQ0FBQyxLQUFLLENBQUMsSUFBSSxFQUFFLE9BQU8sQ0FBQyxDQUFDO1NBQzdDO2FBQ0k7WUFDRCxLQUFLLENBQUMsVUFBVSxHQUFHLEtBQUssQ0FBQztZQUN6QixJQUFJLE9BQU8sS0FBSyxDQUFDLFFBQVEsS0FBSyxXQUFXLEVBQUU7Z0JBQ3ZDLEtBQUssQ0FBQyxRQUFRLEdBQUcsS0FBSyxDQUFDLElBQUksQ0FBQzthQUMvQjtTQUNKO0lBQ0wsQ0FBQztJQUVPLG9DQUFZLEdBQXBCLFVBQXFCLE9BQWUsRUFBRSxPQUFnQjtRQUNsRCxJQUFJLE1BQU0sR0FBVyxDQUFDLE9BQU8sT0FBTyxLQUFLLFdBQVcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQztRQUN4RSxJQUFJLFlBQVksR0FBRyxNQUFNLENBQUM7UUFDMUIsWUFBWSxJQUFJLEdBQUcsR0FBRyxPQUFPLENBQUMsUUFBUSxFQUFFLENBQUM7UUFDekMsT0FBTyxZQUFZLENBQUM7SUFDeEIsQ0FBQztJQUdELG9CQUFvQjtJQUViLHlDQUFpQixHQUF4QjtRQUNJLE9BQU8sSUFBSSxDQUFDLFdBQVcsQ0FBQyxFQUFFLENBQU0sMkJBQTJCLENBQUMsQ0FBQztJQUNqRSxDQUFDO0lBRU0sdUNBQWUsR0FBdEIsVUFBdUIsS0FBVTtRQUM3QixJQUFJLENBQUMsV0FBVyxDQUFDLFNBQVMsQ0FBQywyQkFBMkIsQ0FBQyxDQUFDO0lBQzVELENBQUM7O2dCQXRKZ0MsYUFBYTs7SUFEckMsYUFBYTtRQUR6QixVQUFVLEVBQUU7eUNBRXdCLGFBQWE7T0FEckMsYUFBYSxDQXdKekI7SUFBRCxvQkFBQztDQUFBLEFBeEpELElBd0pDO1NBeEpZLGFBQWEiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBJbmplY3RhYmxlIH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XHJcbmltcG9ydCB7IEtkQnJvYWRjYXN0ZXIgfSBmcm9tICcuLi9rZC1jb21tb24vaW5kZXgnO1xyXG5pbXBvcnQgeyBPYnNlcnZhYmxlIH0gZnJvbSAncnhqcyc7XHJcblxyXG5ASW5qZWN0YWJsZSgpXHJcbmV4cG9ydCBjbGFzcyBLZExlZnRtZW51U3ZjIHtcclxuICAgIGNvbnN0cnVjdG9yKHByaXZhdGUgYnJvYWRjYXN0ZXI6IEtkQnJvYWRjYXN0ZXIpIHsgfVxyXG5cclxuICAgIC8vIHNldCBpc09wZW4gcHJvcGVydHkgdG8gb2JqZWN0cyB3aXRoIGxpc3QgKGx2MSwgbHYyLCBsdjMpIC0gbmVzdGVkIG5hdnNcclxuICAgIHB1YmxpYyBzZXRJc09wZW4oX3NpZGVDb25maWc6IEFycmF5PGFueT4pOiBBcnJheTxhbnk+IHtcclxuICAgICAgICBpZiAodHlwZW9mIF9zaWRlQ29uZmlnID09PSAndW5kZWZpbmVkJykgcmV0dXJuIFtdO1xyXG5cclxuICAgICAgICBsZXQgdXBkYXRlUmVzdWx0OiBBcnJheTxhbnk+ID0gX3NpZGVDb25maWcuc2xpY2UoKTtcclxuICAgICAgICB0aGlzLl9wcm9jZXNzTmF2SXRlbSh1cGRhdGVSZXN1bHQpO1xyXG5cclxuICAgICAgICByZXR1cm4gdXBkYXRlUmVzdWx0O1xyXG4gICAgfVxyXG5cclxuICAgIHB1YmxpYyBpc0FycmF5RXF1YWwoY3VycmVudEl0ZW06IEFycmF5PG51bWJlcj4sIHByZXZpb3VzSXRlbTogQXJyYXk8bnVtYmVyPik6IGJvb2xlYW4ge1xyXG4gICAgICAgIGlmIChjdXJyZW50SXRlbS5sZW5ndGggIT09IHByZXZpb3VzSXRlbS5sZW5ndGgpIHtcclxuICAgICAgICAgICAgcmV0dXJuIGZhbHNlO1xyXG4gICAgICAgIH1cclxuICAgICAgICBmb3IgKGxldCBpOiBudW1iZXIgPSAwOyBpIDwgY3VycmVudEl0ZW0ubGVuZ3RoOyBpKyspIHtcclxuICAgICAgICAgICAgaWYgKGN1cnJlbnRJdGVtW2ldICE9PSBwcmV2aW91c0l0ZW1baV0pIHtcclxuICAgICAgICAgICAgICAgIHJldHVybiBmYWxzZTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgICAgICByZXR1cm4gdHJ1ZTtcclxuICAgIH1cclxuXHJcblxyXG4gICAgcHVibGljIGdldElkKGl0ZW06IGFueSB8IHN0cmluZyk6IEFycmF5PG51bWJlcj4ge1xyXG4gICAgICAgIGxldCBuYXZfaWQ6IHN0cmluZyA9ICh0eXBlb2YgaXRlbSA9PT0gJ3N0cmluZycpID8gaXRlbSA6IGl0ZW0ubmF2X2lkO1xyXG4gICAgICAgIGxldCBjdXJyZW50SWQ6IEFycmF5PGFueT4gPSBuYXZfaWQuc3BsaXQoJy0nKTtcclxuICAgICAgICBjdXJyZW50SWQuc3BsaWNlKDAsIDEpO1xyXG5cclxuICAgICAgICBmb3IgKGxldCBpOiBudW1iZXIgPSAwOyBpIDwgY3VycmVudElkLmxlbmd0aDsgaSsrKSB7XHJcbiAgICAgICAgICAgIGN1cnJlbnRJZFtpXSA9ICtjdXJyZW50SWRbaV07XHJcbiAgICAgICAgfVxyXG4gICAgICAgIHJldHVybiBjdXJyZW50SWQ7XHJcbiAgICB9XHJcblxyXG4gICAgcHVibGljIGNsb3NlRGlmZmVyZW50KGN1cnJlbnRJdGVtOiBBcnJheTxudW1iZXI+LCBwcmV2aW91c0l0ZW06IEFycmF5PG51bWJlcj4sIF9uYXZJdGVtczogQXJyYXk8YW55Pik6IHZvaWQge1xyXG4gICAgICAgIGxldCBjdXJyZW50Tm9kZTogYW55ID0ge307XHJcbiAgICAgICAgbGV0IHByZXZpb3VzQ3VycmVudE5vZGU6IGFueSA9IHt9O1xyXG4gICAgICAgIGxldCBwcmV2aW91c05vZGU6IGFueTtcclxuICAgICAgICBsZXQgZGlmZkJyYW5jaDogYm9vbGVhbiA9IGZhbHNlO1xyXG5cclxuICAgICAgICBmb3IgKGxldCBpOiBudW1iZXIgPSAwOyBpIDwgcHJldmlvdXNJdGVtLmxlbmd0aDsgaSsrKSB7XHJcbiAgICAgICAgICAgIGlmIChpID09PSAwKSB7XHJcbiAgICAgICAgICAgICAgICBwcmV2aW91c0N1cnJlbnROb2RlID0gX25hdkl0ZW1zW3ByZXZpb3VzSXRlbVtpXV07XHJcbiAgICAgICAgICAgICAgICBjdXJyZW50Tm9kZSA9IF9uYXZJdGVtc1tjdXJyZW50SXRlbVtpXV07XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgZWxzZSB7XHJcbiAgICAgICAgICAgICAgICBwcmV2aW91c0N1cnJlbnROb2RlID0gcHJldmlvdXNDdXJyZW50Tm9kZS5saXN0W3ByZXZpb3VzSXRlbVtpXV07XHJcbiAgICAgICAgICAgICAgICBpZiAodHlwZW9mIGN1cnJlbnRJdGVtW2ldICE9PSAndW5kZWZpbmVkJykge1xyXG4gICAgICAgICAgICAgICAgICAgIGN1cnJlbnROb2RlID0gY3VycmVudE5vZGUubGlzdFtjdXJyZW50SXRlbVtpXV07XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgICAgICAgICBjdXJyZW50Tm9kZSA9IHVuZGVmaW5lZDtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgLyoqKioqKioqKipzZXQgdGhlIHByZXZpb3VzIG5vZGUgdG8gdHJ1ZSBvbmx5IHdoZW4gdGhlcmUgaXMgbmV4dCBub2RlKioqKioqKioqKioqKioqKioqKlxyXG4gICAgICAgICAgICBlLmcuXHJcbiAgICAgICAgICAgICAgcHJldmlvdXMgbm9kZSBvcGVuIC0gICAgMCAwIDAgICAgICAgICAgcHJldmlvdXMgbm9kZSBvcGVuIC0gIDAgMCAwXHJcbiAgICAgICAgICAgICAgY3VycmVudCBub2RlIG9wZW4gIC0gICAgMCAgICAgICAgICAgICAgY3VycmVudCBub2RlIG9wZW4gIC0gIDAgMFxyXG4gICAgICAgICAgICAgIGN1cnJlbnQgbm9kZSBzaG91bGQgYmUgY2xvc2VkICAgICAgICAgIGN1cnJlbnQgbm9kZSBhdCBpbmRleCAwIGlzIG9wZW4sIGluZGV4IDEgaXMgY2xvc2VkXHJcbiAgICAgICAgICAgICoqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKi9cclxuXHJcblxyXG4gICAgICAgICAgICBpZiAocHJldmlvdXNDdXJyZW50Tm9kZS5oYXNPd25Qcm9wZXJ0eSgnaXNPcGVuJykpIHtcclxuICAgICAgICAgICAgICAgIGlmICh0eXBlb2YgcHJldmlvdXNOb2RlICE9PSAndW5kZWZpbmVkJyAmJiB0eXBlb2YgY3VycmVudEl0ZW1baV0gIT09ICd1bmRlZmluZWQnKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgcHJldmlvdXNOb2RlLmlzT3BlbiA9IHRydWU7XHJcbiAgICAgICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICAgICAgaWYgKGN1cnJlbnRJdGVtW2ldID09PSBwcmV2aW91c0l0ZW1baV0gJiYgZGlmZkJyYW5jaCA9PT0gZmFsc2UpIHtcclxuICAgICAgICAgICAgICAgICAgICBwcmV2aW91c05vZGUgPSBwcmV2aW91c0N1cnJlbnROb2RlO1xyXG4gICAgICAgICAgICAgICAgICAgIHByZXZpb3VzQ3VycmVudE5vZGUuaXNPcGVuID0gZmFsc2U7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgICAgICAgICBkaWZmQnJhbmNoID0gdHJ1ZTtcclxuICAgICAgICAgICAgICAgICAgICBwcmV2aW91c0N1cnJlbnROb2RlLmlzT3BlbiA9IGZhbHNlO1xyXG4gICAgICAgICAgICAgICAgICAgIGlmICh0eXBlb2YgY3VycmVudE5vZGUgIT09ICd1bmRlZmluZWQnKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGlmICh0eXBlb2YgY3VycmVudE5vZGUuaXNPcGVuICE9PSAndW5kZWZpbmVkJykgY3VycmVudE5vZGUuaXNPcGVuID0gdHJ1ZTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgZWxzZSBjdXJyZW50Tm9kZS5pc1NlbGVjdGVkID0gdHJ1ZTtcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgcHVibGljIHRvZ2dsZVN0YXRlKGN1cnJlbnRJZDogQXJyYXk8YW55Piwgc3RhdGU6IHN0cmluZywgX25hdkl0ZW1zOiBBcnJheTxhbnk+KTogdm9pZCB7XHJcbiAgICAgICAgbGV0IGN1cnJlbnROb2RlOiBhbnkgPSB7fTtcclxuICAgICAgICBmb3IgKGxldCBpOiBudW1iZXIgPSAwOyBpIDwgY3VycmVudElkLmxlbmd0aDsgaSsrKSB7XHJcblxyXG4gICAgICAgICAgICBjdXJyZW50Tm9kZSA9IChpID09PSAwKSA/IF9uYXZJdGVtc1tjdXJyZW50SWRbaV1dIDogY3VycmVudE5vZGUubGlzdFtjdXJyZW50SWRbaV1dO1xyXG5cclxuXHJcbiAgICAgICAgICAgIGlmICh0eXBlb2YgY3VycmVudE5vZGUuaXNPcGVuICE9PSAndW5kZWZpbmVkJykge1xyXG4gICAgICAgICAgICAgICAgaWYgKHN0YXRlID09PSAnb3BlbicpIHtcclxuICAgICAgICAgICAgICAgICAgICBjdXJyZW50Tm9kZS5pc09wZW4gPSB0cnVlO1xyXG4gICAgICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgICAgIGVsc2UgaWYgKHN0YXRlID09PSAnY2xvc2UnKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgY3VycmVudE5vZGUuaXNPcGVuID0gZmFsc2U7XHJcbiAgICAgICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICAgICAgZWxzZSBpZiAoc3RhdGUgPT09ICd0b2dnbGUnICYmIGkgPT09IGN1cnJlbnRJZC5sZW5ndGggLSAxKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgY3VycmVudE5vZGUuaXNPcGVuID0gIWN1cnJlbnROb2RlLmlzT3BlbjtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBlbHNlIGlmICh0eXBlb2YgY3VycmVudE5vZGUuaXNTZWxlY3RlZCAhPT0gJ3VuZGVmaW5lZCcgJiYgaSA9PT0gY3VycmVudElkLmxlbmd0aCAtIDEpIHtcclxuICAgICAgICAgICAgICAgIGN1cnJlbnROb2RlLmlzU2VsZWN0ZWQgPSBmYWxzZTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcblxyXG4gICAgcHJpdmF0ZSBfcHJvY2Vzc05hdkl0ZW0oX25hdkl0ZW1zOiBBcnJheTxhbnk+LCBfcHJlZml4Pzogc3RyaW5nKTogdm9pZCB7XHJcbiAgICAgICAgZm9yIChsZXQgaTogbnVtYmVyID0gMDsgaSA8IF9uYXZJdGVtcy5sZW5ndGg7IGkrKykge1xyXG4gICAgICAgICAgICBsZXQgaXRlbUlkOiBzdHJpbmcgPSB0aGlzLl9pZEZvcm1hdHRlcihpLCBfcHJlZml4KTtcclxuICAgICAgICAgICAgX25hdkl0ZW1zW2ldWyduYXZfaWQnXSA9IGl0ZW1JZDtcclxuICAgICAgICAgICAgdGhpcy5fY2hlY2tOYXZJdGVtKF9uYXZJdGVtc1tpXSwgaXRlbUlkKTtcclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfY2hlY2tOYXZJdGVtKF9pdGVtOiBhbnksIF9wcmVmaXg/OiBzdHJpbmcpOiB2b2lkIHtcclxuICAgICAgICBpZiAodHlwZW9mIF9pdGVtLmxpc3QgIT09ICd1bmRlZmluZWQnKSB7XHJcbiAgICAgICAgICAgIF9pdGVtLmlzT3BlbiA9IGZhbHNlO1xyXG4gICAgICAgICAgICB0aGlzLl9wcm9jZXNzTmF2SXRlbShfaXRlbS5saXN0LCBfcHJlZml4KTtcclxuICAgICAgICB9XHJcbiAgICAgICAgZWxzZSB7XHJcbiAgICAgICAgICAgIF9pdGVtLmlzU2VsZWN0ZWQgPSBmYWxzZTtcclxuICAgICAgICAgICAgaWYgKHR5cGVvZiBfaXRlbS5iYXNlUGF0aCA9PT0gJ3VuZGVmaW5lZCcpIHtcclxuICAgICAgICAgICAgICAgIF9pdGVtLmJhc2VQYXRoID0gX2l0ZW0ucGF0aDtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF9pZEZvcm1hdHRlcihfbnVtYmVyOiBudW1iZXIsIF9wcmVmaXg/OiBzdHJpbmcpOiBzdHJpbmcge1xyXG4gICAgICAgIGxldCBwcmVmaXg6IHN0cmluZyA9ICh0eXBlb2YgX3ByZWZpeCA9PT0gJ3VuZGVmaW5lZCcpID8gJ25hdicgOiBfcHJlZml4O1xyXG4gICAgICAgIGxldCBmb3JtYXRTdHJpbmcgPSBwcmVmaXg7XHJcbiAgICAgICAgZm9ybWF0U3RyaW5nICs9ICctJyArIF9udW1iZXIudG9TdHJpbmcoKTtcclxuICAgICAgICByZXR1cm4gZm9ybWF0U3RyaW5nO1xyXG4gICAgfVxyXG5cclxuXHJcbiAgICAvKiBGb3IgQVBJIFVzYWdlICAqL1xyXG5cclxuICAgIHB1YmxpYyBvbk1lbnVJdGVtQ2xpY2tlZCgpOiBPYnNlcnZhYmxlPGFueT4ge1xyXG4gICAgICAgIHJldHVybiB0aGlzLmJyb2FkY2FzdGVyLm9uPGFueT4oJ0tkR3JpZHN0ZXJFdmVudF9vblJlbW92ZWQnKTtcclxuICAgIH1cclxuXHJcbiAgICBwdWJsaWMgbWVudUl0ZW1DbGlja2VkKF9pdGVtOiBhbnkpOiB2b2lkIHtcclxuICAgICAgICB0aGlzLmJyb2FkY2FzdGVyLmJyb2FkY2FzdCgnS2RHcmlkc3RlckV2ZW50X29uUmVtb3ZlZCcpO1xyXG4gICAgfVxyXG59XHJcbiJdfQ==