import { __decorate, __metadata } from "tslib";
import { Directive, OnInit, Input, ViewContainerRef, } from '@angular/core';
var KdCheckboxRadio = /** @class */ (function () {
    function KdCheckboxRadio(_vcr) {
        this._vcr = _vcr;
    }
    KdCheckboxRadio.prototype.ngOnInit = function () {
        var currentEle = this._vcr.element.nativeElement;
        var warpper = document.createElement('div');
        warpper.className = 'selection-wrapper';
        currentEle.parentNode.insertBefore(warpper, currentEle);
        warpper.appendChild(currentEle);
        var label = document.createElement('label');
        if (typeof this.inputText !== 'undefined' && this.inputText !== '') {
            label.innerHTML = this.inputText;
        }
        warpper.appendChild(label);
    };
    KdCheckboxRadio.ctorParameters = function () { return [
        { type: ViewContainerRef }
    ]; };
    __decorate([
        Input('kd-checkbox-radio'),
        __metadata("design:type", String)
    ], KdCheckboxRadio.prototype, "inputText", void 0);
    KdCheckboxRadio = __decorate([
        Directive({
            selector: '[kd-checkbox-radio]'
        }),
        __metadata("design:paramtypes", [ViewContainerRef])
    ], KdCheckboxRadio);
    return KdCheckboxRadio;
}());
export { KdCheckboxRadio };
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoia2QtYW5ndWxhci1jaGVja2JveC1yYWRpby5qcyIsInNvdXJjZVJvb3QiOiJuZzovL29wZW5lbWlzLXN0eWxlZ3VpZGUtbGliLyIsInNvdXJjZXMiOlsia2QtY29tcG9uZW50cy9rZC1hbmd1bGFyLWNoZWNrYm94LXJhZGlvL2tkLWFuZ3VsYXItY2hlY2tib3gtcmFkaW8udHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IjtBQUFBLE9BQU8sRUFDSCxTQUFTLEVBQ1QsTUFBTSxFQUNOLEtBQUssRUFDTCxnQkFBZ0IsR0FDbkIsTUFBTSxlQUFlLENBQUM7QUFNdkI7SUFHSSx5QkFBb0IsSUFBc0I7UUFBdEIsU0FBSSxHQUFKLElBQUksQ0FBa0I7SUFBSSxDQUFDO0lBRS9DLGtDQUFRLEdBQVI7UUFDSSxJQUFJLFVBQVUsR0FBRyxJQUFJLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxhQUFhLENBQUM7UUFDakQsSUFBSSxPQUFPLEdBQUcsUUFBUSxDQUFDLGFBQWEsQ0FBQyxLQUFLLENBQUMsQ0FBQztRQUM1QyxPQUFPLENBQUMsU0FBUyxHQUFHLG1CQUFtQixDQUFDO1FBQ3hDLFVBQVUsQ0FBQyxVQUFVLENBQUMsWUFBWSxDQUFDLE9BQU8sRUFBRSxVQUFVLENBQUMsQ0FBQztRQUN4RCxPQUFPLENBQUMsV0FBVyxDQUFDLFVBQVUsQ0FBQyxDQUFDO1FBQ2hDLElBQUksS0FBSyxHQUFHLFFBQVEsQ0FBQyxhQUFhLENBQUMsT0FBTyxDQUFDLENBQUM7UUFDNUMsSUFBSSxPQUFPLElBQUksQ0FBQyxTQUFTLEtBQUssV0FBVyxJQUFJLElBQUksQ0FBQyxTQUFTLEtBQUssRUFBRSxFQUFFO1lBQ2hFLEtBQUssQ0FBQyxTQUFTLEdBQUcsSUFBSSxDQUFDLFNBQVMsQ0FBQztTQUNwQztRQUNELE9BQU8sQ0FBQyxXQUFXLENBQUMsS0FBSyxDQUFDLENBQUM7SUFDL0IsQ0FBQzs7Z0JBYnlCLGdCQUFnQjs7SUFGZDtRQUEzQixLQUFLLENBQUMsbUJBQW1CLENBQUM7O3NEQUFtQjtJQURyQyxlQUFlO1FBSjNCLFNBQVMsQ0FBQztZQUNQLFFBQVEsRUFBRSxxQkFBcUI7U0FDbEMsQ0FBQzt5Q0FLNEIsZ0JBQWdCO09BSGpDLGVBQWUsQ0FpQjNCO0lBQUQsc0JBQUM7Q0FBQSxBQWpCRCxJQWlCQztTQWpCWSxlQUFlIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHtcclxuICAgIERpcmVjdGl2ZSxcclxuICAgIE9uSW5pdCxcclxuICAgIElucHV0LFxyXG4gICAgVmlld0NvbnRhaW5lclJlZixcclxufSBmcm9tICdAYW5ndWxhci9jb3JlJztcclxuXHJcbkBEaXJlY3RpdmUoe1xyXG4gICAgc2VsZWN0b3I6ICdba2QtY2hlY2tib3gtcmFkaW9dJ1xyXG59KVxyXG5cclxuZXhwb3J0IGNsYXNzIEtkQ2hlY2tib3hSYWRpbyBpbXBsZW1lbnRzIE9uSW5pdCB7XHJcbiAgICBASW5wdXQoJ2tkLWNoZWNrYm94LXJhZGlvJykgaW5wdXRUZXh0OiBzdHJpbmc7XHJcblxyXG4gICAgY29uc3RydWN0b3IocHJpdmF0ZSBfdmNyOiBWaWV3Q29udGFpbmVyUmVmKSB7IH1cclxuXHJcbiAgICBuZ09uSW5pdCgpOiB2b2lkIHtcclxuICAgICAgICBsZXQgY3VycmVudEVsZSA9IHRoaXMuX3Zjci5lbGVtZW50Lm5hdGl2ZUVsZW1lbnQ7XHJcbiAgICAgICAgbGV0IHdhcnBwZXIgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdkaXYnKTtcclxuICAgICAgICB3YXJwcGVyLmNsYXNzTmFtZSA9ICdzZWxlY3Rpb24td3JhcHBlcic7XHJcbiAgICAgICAgY3VycmVudEVsZS5wYXJlbnROb2RlLmluc2VydEJlZm9yZSh3YXJwcGVyLCBjdXJyZW50RWxlKTtcclxuICAgICAgICB3YXJwcGVyLmFwcGVuZENoaWxkKGN1cnJlbnRFbGUpO1xyXG4gICAgICAgIGxldCBsYWJlbCA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2xhYmVsJyk7XHJcbiAgICAgICAgaWYgKHR5cGVvZiB0aGlzLmlucHV0VGV4dCAhPT0gJ3VuZGVmaW5lZCcgJiYgdGhpcy5pbnB1dFRleHQgIT09ICcnKSB7XHJcbiAgICAgICAgICAgIGxhYmVsLmlubmVySFRNTCA9IHRoaXMuaW5wdXRUZXh0O1xyXG4gICAgICAgIH1cclxuICAgICAgICB3YXJwcGVyLmFwcGVuZENoaWxkKGxhYmVsKTtcclxuICAgIH1cclxufVxyXG4iXX0=