import { __decorate, __metadata } from "tslib";
import { Component, ViewEncapsulation, ViewChild, Input, OnInit, OnChanges, SimpleChanges, AfterViewInit, OnDestroy, ElementRef, Renderer2, HostListener, } from '@angular/core';
import { UIChart } from 'primeng/chart';
import { KdMiniDashboardSvc } from './kd-angular-mini-dashboard-svc';
import { KdSplitterEvent } from '../kd-angular-splitter/index';
var KdMiniDashboardChart = /** @class */ (function () {
    function KdMiniDashboardChart(_kdMiniDashboardSvc, _elementRef, _renderer, _kdSplitterEvent) {
        var _this = this;
        this._kdMiniDashboardSvc = _kdMiniDashboardSvc;
        this._elementRef = _elementRef;
        this._renderer = _renderer;
        this.threeItemLegend = false;
        this.placement = 'bottom-left';
        this._isWidthChanged = { legend: false, canvas: false };
        this._isFirstLoad = true;
        this._pChartsFunction = _kdMiniDashboardSvc.pcharts(_elementRef, _renderer);
        _kdSplitterEvent.onDrag().subscribe(function (_type) {
            _this._pChartsFunction.setTooltipPlacementFlag(true);
        });
        _kdSplitterEvent.onToggleMenu().subscribe(function (_type) {
            _this._pChartsFunction.setTooltipPlacementFlag(true);
        });
    }
    KdMiniDashboardChart.prototype.onResize = function (event) {
        this._pChartsFunction.setTooltipPlacementFlag(true);
        this._pChartsFunction.processTooltipToCanvasSize(this._canvas, this.chart);
        if (this.itemLength === 3) {
            this._resizeLegend();
            this._resizeCanvas();
        }
    };
    KdMiniDashboardChart.prototype.ngOnInit = function () {
        this._isFirstLoad = false;
        this._tooltipElement = this.tooltip._elementRef.nativeElement;
        this._chartLegendElement = this.chartLegend.nativeElement;
    };
    KdMiniDashboardChart.prototype.ngOnChanges = function (_simpleChanges) {
        if (_simpleChanges.hasOwnProperty('itemLength') && _simpleChanges.itemLength.currentValue === 3) {
            this._resizeLegend();
        }
        if (!this._isFirstLoad && this.itemLength === 3)
            this._resizeCanvas();
        if (_simpleChanges.hasOwnProperty('direction') && this.direction === 'right')
            this.placement = 'bottom-right';
    };
    KdMiniDashboardChart.prototype.ngAfterViewInit = function () {
        this._canvas = this.chart.getCanvas();
        this._pChartElement = this._elementRef.nativeElement.querySelector('.kdx-mini-dashboard .kdx-mini-dashboard-chart p-chart');
        if (this.itemLength === 3)
            this._resizeCanvas();
        this._setLegend();
        this._pChartsFunction.processTooltipToCanvasSize(this._canvas, this.chart);
    };
    KdMiniDashboardChart.prototype.ngOnDestroy = function () {
        this._kdMiniDashboardSvc.removeChildren(this._chartLegendElement);
    };
    KdMiniDashboardChart.prototype._setLegend = function () {
        if (!this.isLegendDisplayed)
            return;
        this._chartLegendElement.innerHTML = this.chart.chart.generateLegend() || '';
        this._setLegendLabelElement();
        this._pChartsFunction.attachLegendListener(this._legendLabelElement, { uiChart: this.chart, legendElement: this._chartLegendElement }, { method: this.tooltip, element: this._tooltipElement }, this.direction);
    };
    KdMiniDashboardChart.prototype._setLegendLabelElement = function () {
        this._legendLabelElement = this._elementRef.nativeElement.querySelectorAll('.kdx-mini-dashboard .kdx-elem-item .chart-legend ul li .chart-legend-label');
    };
    KdMiniDashboardChart.prototype._resizeLegend = function () {
        if (480 < window.innerWidth && window.innerWidth < 650) {
            if (this._isWidthChanged.legend === false) {
                this.threeItemLegend = true;
                this._isWidthChanged.legend = true;
            }
        }
        else {
            if (this._isWidthChanged.legend === true) {
                this.threeItemLegend = false;
                this._isWidthChanged.legend = false;
            }
        }
    };
    KdMiniDashboardChart.prototype._resizeCanvas = function () {
        if (480 < window.innerWidth && window.innerWidth < 650) {
            if (this._isWidthChanged.canvas === false) {
                this._pChartsFunction.setCanvasStyle('80', this._canvas);
                this._isWidthChanged.canvas = true;
                this._renderer.setStyle(this._pChartElement, 'width', '80px');
                this._renderer.setStyle(this._pChartElement, 'height', '80px');
            }
        }
        else if (window.innerWidth > 650 || window.innerWidth === 650) {
            if (this._isWidthChanged.canvas === true) {
                this._pChartsFunction.setCanvasStyle('100', this._canvas);
                this._isWidthChanged.canvas = false;
                this._renderer.setStyle(this._pChartElement, 'width', '100px');
                this._renderer.setStyle(this._pChartElement, 'height', '100px');
            }
        }
    };
    KdMiniDashboardChart.ctorParameters = function () { return [
        { type: KdMiniDashboardSvc },
        { type: ElementRef },
        { type: Renderer2 },
        { type: KdSplitterEvent }
    ]; };
    __decorate([
        Input(),
        __metadata("design:type", Object)
    ], KdMiniDashboardChart.prototype, "data", void 0);
    __decorate([
        Input(),
        __metadata("design:type", Object)
    ], KdMiniDashboardChart.prototype, "options", void 0);
    __decorate([
        Input(),
        __metadata("design:type", Boolean)
    ], KdMiniDashboardChart.prototype, "isLegendDisplayed", void 0);
    __decorate([
        Input(),
        __metadata("design:type", Number)
    ], KdMiniDashboardChart.prototype, "itemLength", void 0);
    __decorate([
        Input(),
        __metadata("design:type", String)
    ], KdMiniDashboardChart.prototype, "direction", void 0);
    __decorate([
        ViewChild(UIChart, { static: true }),
        __metadata("design:type", UIChart)
    ], KdMiniDashboardChart.prototype, "chart", void 0);
    __decorate([
        ViewChild('t', { static: true }),
        __metadata("design:type", Object)
    ], KdMiniDashboardChart.prototype, "tooltip", void 0);
    __decorate([
        ViewChild('chartLegend', { static: true }),
        __metadata("design:type", Object)
    ], KdMiniDashboardChart.prototype, "chartLegend", void 0);
    __decorate([
        HostListener('window:resize', ['$event']),
        __metadata("design:type", Function),
        __metadata("design:paramtypes", [Object]),
        __metadata("design:returntype", void 0)
    ], KdMiniDashboardChart.prototype, "onResize", null);
    KdMiniDashboardChart = __decorate([
        Component({
            selector: 'kd-mini-dashboard-chart',
            template: "\n        <div class=\"kdx-elem-item\">\n            <p-chart class=\"chart-main\" type=\"doughnut\" [data]=\"data\" [options]=\"options\" ></p-chart>\n            <div class=\"chart-legend\"\n                 #chartLegend\n                 [attr.kd-mini-dashboard-chart-index]=\"data.chartIndex\"\n                 [ngClass]=\"{'three-item-chart-legend' : threeItemLegend }\">\n            </div>\n            <div class=\"kdx-mini-dashboard-tooltip\" [placement]=\"placement\" ngbTooltip=\"\" triggers=\"manual\" #t=\"ngbTooltip\"></div>\n        </div>",
            encapsulation: ViewEncapsulation.None,
            providers: [KdMiniDashboardSvc],
            host: { class: 'kdx-mini-dashboard-chart' }
        }),
        __metadata("design:paramtypes", [KdMiniDashboardSvc,
            ElementRef,
            Renderer2,
            KdSplitterEvent])
    ], KdMiniDashboardChart);
    return KdMiniDashboardChart;
}());
export { KdMiniDashboardChart };
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoia2QtYW5ndWxhci1taW5pLWRhc2hib2FyZC1jaGFydC5qcyIsInNvdXJjZVJvb3QiOiJuZzovL29wZW5lbWlzLXN0eWxlZ3VpZGUtbGliLyIsInNvdXJjZXMiOlsia2QtY29tcG9uZW50cy9rZC1hbmd1bGFyLW1pbmktZGFzaGJvYXJkL2tkLWFuZ3VsYXItbWluaS1kYXNoYm9hcmQtY2hhcnQudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IjtBQUFBLE9BQU8sRUFDSCxTQUFTLEVBQ1QsaUJBQWlCLEVBQ2pCLFNBQVMsRUFDVCxLQUFLLEVBQ0wsTUFBTSxFQUNOLFNBQVMsRUFDVCxhQUFhLEVBQ2IsYUFBYSxFQUNiLFNBQVMsRUFDVCxVQUFVLEVBQ1YsU0FBUyxFQUNULFlBQVksR0FDZixNQUFNLGVBQWUsQ0FBQztBQUN2QixPQUFPLEVBQUUsT0FBTyxFQUFFLE1BQU0sZUFBZSxDQUFDO0FBRXhDLE9BQU8sRUFBRSxrQkFBa0IsRUFBRSxNQUFNLGlDQUFpQyxDQUFDO0FBQ3JFLE9BQU8sRUFBRSxlQUFlLEVBQUUsTUFBTSw4QkFBOEIsQ0FBQztBQW1CL0Q7SUF1QkksOEJBQ1ksbUJBQXVDLEVBQ3ZDLFdBQXVCLEVBQ3ZCLFNBQW9CLEVBQzVCLGdCQUFpQztRQUpyQyxpQkFhQztRQVpXLHdCQUFtQixHQUFuQixtQkFBbUIsQ0FBb0I7UUFDdkMsZ0JBQVcsR0FBWCxXQUFXLENBQVk7UUFDdkIsY0FBUyxHQUFULFNBQVMsQ0FBVztRQXpCekIsb0JBQWUsR0FBWSxLQUFLLENBQUM7UUFDakMsY0FBUyxHQUFXLGFBQWEsQ0FBQztRQU9qQyxvQkFBZSxHQUF5QyxFQUFFLE1BQU0sRUFBRSxLQUFLLEVBQUUsTUFBTSxFQUFFLEtBQUssRUFBRSxDQUFDO1FBQ3pGLGlCQUFZLEdBQVksSUFBSSxDQUFDO1FBbUJqQyxJQUFJLENBQUMsZ0JBQWdCLEdBQUcsbUJBQW1CLENBQUMsT0FBTyxDQUFDLFdBQVcsRUFBRSxTQUFTLENBQUMsQ0FBQztRQUM1RSxnQkFBZ0IsQ0FBQyxNQUFNLEVBQUUsQ0FBQyxTQUFTLENBQUMsVUFBQSxLQUFLO1lBQ3JDLEtBQUksQ0FBQyxnQkFBZ0IsQ0FBQyx1QkFBdUIsQ0FBQyxJQUFJLENBQUMsQ0FBQztRQUN4RCxDQUFDLENBQUMsQ0FBQztRQUNILGdCQUFnQixDQUFDLFlBQVksRUFBRSxDQUFDLFNBQVMsQ0FBQyxVQUFBLEtBQUs7WUFDM0MsS0FBSSxDQUFDLGdCQUFnQixDQUFDLHVCQUF1QixDQUFDLElBQUksQ0FBQyxDQUFDO1FBQ3hELENBQUMsQ0FBQyxDQUFDO0lBQ1AsQ0FBQztJQUdELHVDQUFRLEdBQVIsVUFBUyxLQUFVO1FBQ2YsSUFBSSxDQUFDLGdCQUFnQixDQUFDLHVCQUF1QixDQUFDLElBQUksQ0FBQyxDQUFDO1FBQ3BELElBQUksQ0FBQyxnQkFBZ0IsQ0FBQywwQkFBMEIsQ0FBQyxJQUFJLENBQUMsT0FBTyxFQUFFLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQztRQUMzRSxJQUFJLElBQUksQ0FBQyxVQUFVLEtBQUssQ0FBQyxFQUFFO1lBQ3ZCLElBQUksQ0FBQyxhQUFhLEVBQUUsQ0FBQztZQUNyQixJQUFJLENBQUMsYUFBYSxFQUFFLENBQUM7U0FDeEI7SUFDTCxDQUFDO0lBRUQsdUNBQVEsR0FBUjtRQUNJLElBQUksQ0FBQyxZQUFZLEdBQUcsS0FBSyxDQUFDO1FBQzFCLElBQUksQ0FBQyxlQUFlLEdBQUcsSUFBSSxDQUFDLE9BQU8sQ0FBQyxXQUFXLENBQUMsYUFBYSxDQUFDO1FBQzlELElBQUksQ0FBQyxtQkFBbUIsR0FBRyxJQUFJLENBQUMsV0FBVyxDQUFDLGFBQWEsQ0FBQztJQUM5RCxDQUFDO0lBRUQsMENBQVcsR0FBWCxVQUFZLGNBQTZCO1FBQ3JDLElBQUksY0FBYyxDQUFDLGNBQWMsQ0FBQyxZQUFZLENBQUMsSUFBSSxjQUFjLENBQUMsVUFBVSxDQUFDLFlBQVksS0FBSyxDQUFDLEVBQUU7WUFDN0YsSUFBSSxDQUFDLGFBQWEsRUFBRSxDQUFDO1NBQ3hCO1FBQ0QsSUFBSSxDQUFDLElBQUksQ0FBQyxZQUFZLElBQUksSUFBSSxDQUFDLFVBQVUsS0FBSyxDQUFDO1lBQUUsSUFBSSxDQUFDLGFBQWEsRUFBRSxDQUFDO1FBQ3RFLElBQUksY0FBYyxDQUFDLGNBQWMsQ0FBQyxXQUFXLENBQUMsSUFBSSxJQUFJLENBQUMsU0FBUyxLQUFLLE9BQU87WUFBRSxJQUFJLENBQUMsU0FBUyxHQUFHLGNBQWMsQ0FBQztJQUNsSCxDQUFDO0lBRUQsOENBQWUsR0FBZjtRQUNJLElBQUksQ0FBQyxPQUFPLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQyxTQUFTLEVBQUUsQ0FBQztRQUN0QyxJQUFJLENBQUMsY0FBYyxHQUFHLElBQUksQ0FBQyxXQUFXLENBQUMsYUFBYSxDQUFDLGFBQWEsQ0FBQyx1REFBdUQsQ0FBQyxDQUFDO1FBQzVILElBQUksSUFBSSxDQUFDLFVBQVUsS0FBSyxDQUFDO1lBQUUsSUFBSSxDQUFDLGFBQWEsRUFBRSxDQUFDO1FBQ2hELElBQUksQ0FBQyxVQUFVLEVBQUUsQ0FBQztRQUNsQixJQUFJLENBQUMsZ0JBQWdCLENBQUMsMEJBQTBCLENBQUMsSUFBSSxDQUFDLE9BQU8sRUFBRSxJQUFJLENBQUMsS0FBSyxDQUFDLENBQUM7SUFDL0UsQ0FBQztJQUVELDBDQUFXLEdBQVg7UUFDSSxJQUFJLENBQUMsbUJBQW1CLENBQUMsY0FBYyxDQUFDLElBQUksQ0FBQyxtQkFBbUIsQ0FBQyxDQUFDO0lBQ3RFLENBQUM7SUFFTyx5Q0FBVSxHQUFsQjtRQUNJLElBQUksQ0FBQyxJQUFJLENBQUMsaUJBQWlCO1lBQUUsT0FBTztRQUNwQyxJQUFJLENBQUMsbUJBQW1CLENBQUMsU0FBUyxHQUFHLElBQUksQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLGNBQWMsRUFBRSxJQUFJLEVBQUUsQ0FBQztRQUM3RSxJQUFJLENBQUMsc0JBQXNCLEVBQUUsQ0FBQztRQUM5QixJQUFJLENBQUMsZ0JBQWdCLENBQUMsb0JBQW9CLENBQ3RDLElBQUksQ0FBQyxtQkFBbUIsRUFDeEIsRUFBRSxPQUFPLEVBQUUsSUFBSSxDQUFDLEtBQUssRUFBRSxhQUFhLEVBQUUsSUFBSSxDQUFDLG1CQUFtQixFQUFFLEVBQ2hFLEVBQUUsTUFBTSxFQUFFLElBQUksQ0FBQyxPQUFPLEVBQUUsT0FBTyxFQUFFLElBQUksQ0FBQyxlQUFlLEVBQUUsRUFDdkQsSUFBSSxDQUFDLFNBQVMsQ0FDakIsQ0FBQztJQUNOLENBQUM7SUFFTyxxREFBc0IsR0FBOUI7UUFDSSxJQUFJLENBQUMsbUJBQW1CLEdBQUcsSUFBSSxDQUFDLFdBQVcsQ0FBQyxhQUFhLENBQUMsZ0JBQWdCLENBQUMsNEVBQTRFLENBQUMsQ0FBQztJQUM3SixDQUFDO0lBRU8sNENBQWEsR0FBckI7UUFDSSxJQUFJLEdBQUcsR0FBRyxNQUFNLENBQUMsVUFBVSxJQUFJLE1BQU0sQ0FBQyxVQUFVLEdBQUcsR0FBRyxFQUFFO1lBQ3BELElBQUksSUFBSSxDQUFDLGVBQWUsQ0FBQyxNQUFNLEtBQUssS0FBSyxFQUFFO2dCQUN2QyxJQUFJLENBQUMsZUFBZSxHQUFHLElBQUksQ0FBQztnQkFDNUIsSUFBSSxDQUFDLGVBQWUsQ0FBQyxNQUFNLEdBQUcsSUFBSSxDQUFDO2FBQ3RDO1NBQ0o7YUFBTTtZQUNILElBQUksSUFBSSxDQUFDLGVBQWUsQ0FBQyxNQUFNLEtBQUssSUFBSSxFQUFFO2dCQUN0QyxJQUFJLENBQUMsZUFBZSxHQUFHLEtBQUssQ0FBQztnQkFDN0IsSUFBSSxDQUFDLGVBQWUsQ0FBQyxNQUFNLEdBQUcsS0FBSyxDQUFDO2FBQ3ZDO1NBQ0o7SUFDTCxDQUFDO0lBRU8sNENBQWEsR0FBckI7UUFDSSxJQUFJLEdBQUcsR0FBRyxNQUFNLENBQUMsVUFBVSxJQUFJLE1BQU0sQ0FBQyxVQUFVLEdBQUcsR0FBRyxFQUFFO1lBQ3BELElBQUksSUFBSSxDQUFDLGVBQWUsQ0FBQyxNQUFNLEtBQUssS0FBSyxFQUFFO2dCQUN2QyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsY0FBYyxDQUFDLElBQUksRUFBRSxJQUFJLENBQUMsT0FBTyxDQUFDLENBQUM7Z0JBQ3pELElBQUksQ0FBQyxlQUFlLENBQUMsTUFBTSxHQUFHLElBQUksQ0FBQztnQkFDbkMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLGNBQWMsRUFBRSxPQUFPLEVBQUUsTUFBTSxDQUFDLENBQUM7Z0JBQzlELElBQUksQ0FBQyxTQUFTLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxjQUFjLEVBQUUsUUFBUSxFQUFFLE1BQU0sQ0FBQyxDQUFDO2FBQ2xFO1NBQ0o7YUFBTSxJQUFJLE1BQU0sQ0FBQyxVQUFVLEdBQUcsR0FBRyxJQUFJLE1BQU0sQ0FBQyxVQUFVLEtBQUssR0FBRyxFQUFFO1lBQzdELElBQUksSUFBSSxDQUFDLGVBQWUsQ0FBQyxNQUFNLEtBQUssSUFBSSxFQUFFO2dCQUN0QyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsY0FBYyxDQUFDLEtBQUssRUFBRSxJQUFJLENBQUMsT0FBTyxDQUFDLENBQUM7Z0JBQzFELElBQUksQ0FBQyxlQUFlLENBQUMsTUFBTSxHQUFHLEtBQUssQ0FBQztnQkFDcEMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLGNBQWMsRUFBRSxPQUFPLEVBQUUsT0FBTyxDQUFDLENBQUM7Z0JBQy9ELElBQUksQ0FBQyxTQUFTLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxjQUFjLEVBQUUsUUFBUSxFQUFFLE9BQU8sQ0FBQyxDQUFDO2FBQ25FO1NBQ0o7SUFDTCxDQUFDOztnQkFoR2dDLGtCQUFrQjtnQkFDMUIsVUFBVTtnQkFDWixTQUFTO2dCQUNWLGVBQWU7O0lBZDVCO1FBQVIsS0FBSyxFQUFFOztzREFBVztJQUNWO1FBQVIsS0FBSyxFQUFFOzt5REFBYztJQUNiO1FBQVIsS0FBSyxFQUFFOzttRUFBNEI7SUFDM0I7UUFBUixLQUFLLEVBQUU7OzREQUFvQjtJQUNuQjtRQUFSLEtBQUssRUFBRTs7MkRBQW1CO0lBRVc7UUFBckMsU0FBUyxDQUFDLE9BQU8sRUFBRSxFQUFFLE1BQU0sRUFBRSxJQUFJLEVBQUUsQ0FBQztrQ0FBUSxPQUFPO3VEQUFDO0lBQ25CO1FBQWpDLFNBQVMsQ0FBQyxHQUFHLEVBQUUsRUFBRSxNQUFNLEVBQUUsSUFBSSxFQUFFLENBQUM7O3lEQUFjO0lBQ0g7UUFBM0MsU0FBUyxDQUFDLGFBQWEsRUFBRSxFQUFFLE1BQU0sRUFBRSxJQUFJLEVBQUUsQ0FBQzs7NkRBQWtCO0lBa0I3RDtRQURDLFlBQVksQ0FBQyxlQUFlLEVBQUUsQ0FBQyxRQUFRLENBQUMsQ0FBQzs7Ozt3REFRekM7SUE5Q1Esb0JBQW9CO1FBakJoQyxTQUFTLENBQUM7WUFDUCxRQUFRLEVBQUUseUJBQXlCO1lBQ25DLFFBQVEsRUFBRSw2aUJBU0M7WUFDWCxhQUFhLEVBQUUsaUJBQWlCLENBQUMsSUFBSTtZQUNyQyxTQUFTLEVBQUUsQ0FBQyxrQkFBa0IsQ0FBQztZQUMvQixJQUFJLEVBQUUsRUFBRSxLQUFLLEVBQUUsMEJBQTBCLEVBQUM7U0FDN0MsQ0FBQzt5Q0EwQm1DLGtCQUFrQjtZQUMxQixVQUFVO1lBQ1osU0FBUztZQUNWLGVBQWU7T0EzQjVCLG9CQUFvQixDQXlIaEM7SUFBRCwyQkFBQztDQUFBLEFBekhELElBeUhDO1NBekhZLG9CQUFvQiIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7XHJcbiAgICBDb21wb25lbnQsXHJcbiAgICBWaWV3RW5jYXBzdWxhdGlvbixcclxuICAgIFZpZXdDaGlsZCxcclxuICAgIElucHV0LFxyXG4gICAgT25Jbml0LFxyXG4gICAgT25DaGFuZ2VzLFxyXG4gICAgU2ltcGxlQ2hhbmdlcyxcclxuICAgIEFmdGVyVmlld0luaXQsXHJcbiAgICBPbkRlc3Ryb3ksXHJcbiAgICBFbGVtZW50UmVmLFxyXG4gICAgUmVuZGVyZXIyLFxyXG4gICAgSG9zdExpc3RlbmVyLFxyXG59IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xyXG5pbXBvcnQgeyBVSUNoYXJ0IH0gZnJvbSAncHJpbWVuZy9jaGFydCc7XHJcbmltcG9ydCAqIGFzIHR5cGVzIGZyb20gJy4va2QtYW5ndWxhci1taW5pLWRhc2hib2FyZC1pbnRlcmZhY2UnO1xyXG5pbXBvcnQgeyBLZE1pbmlEYXNoYm9hcmRTdmMgfSBmcm9tICcuL2tkLWFuZ3VsYXItbWluaS1kYXNoYm9hcmQtc3ZjJztcclxuaW1wb3J0IHsgS2RTcGxpdHRlckV2ZW50IH0gZnJvbSAnLi4va2QtYW5ndWxhci1zcGxpdHRlci9pbmRleCc7XHJcblxyXG5AQ29tcG9uZW50KHtcclxuICAgIHNlbGVjdG9yOiAna2QtbWluaS1kYXNoYm9hcmQtY2hhcnQnLFxyXG4gICAgdGVtcGxhdGU6IGBcclxuICAgICAgICA8ZGl2IGNsYXNzPVwia2R4LWVsZW0taXRlbVwiPlxyXG4gICAgICAgICAgICA8cC1jaGFydCBjbGFzcz1cImNoYXJ0LW1haW5cIiB0eXBlPVwiZG91Z2hudXRcIiBbZGF0YV09XCJkYXRhXCIgW29wdGlvbnNdPVwib3B0aW9uc1wiID48L3AtY2hhcnQ+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJjaGFydC1sZWdlbmRcIlxyXG4gICAgICAgICAgICAgICAgICNjaGFydExlZ2VuZFxyXG4gICAgICAgICAgICAgICAgIFthdHRyLmtkLW1pbmktZGFzaGJvYXJkLWNoYXJ0LWluZGV4XT1cImRhdGEuY2hhcnRJbmRleFwiXHJcbiAgICAgICAgICAgICAgICAgW25nQ2xhc3NdPVwieyd0aHJlZS1pdGVtLWNoYXJ0LWxlZ2VuZCcgOiB0aHJlZUl0ZW1MZWdlbmQgfVwiPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPGRpdiBjbGFzcz1cImtkeC1taW5pLWRhc2hib2FyZC10b29sdGlwXCIgW3BsYWNlbWVudF09XCJwbGFjZW1lbnRcIiBuZ2JUb29sdGlwPVwiXCIgdHJpZ2dlcnM9XCJtYW51YWxcIiAjdD1cIm5nYlRvb2x0aXBcIj48L2Rpdj5cclxuICAgICAgICA8L2Rpdj5gLFxyXG4gICAgZW5jYXBzdWxhdGlvbjogVmlld0VuY2Fwc3VsYXRpb24uTm9uZSxcclxuICAgIHByb3ZpZGVyczogW0tkTWluaURhc2hib2FyZFN2Y10sXHJcbiAgICBob3N0OiB7IGNsYXNzOiAna2R4LW1pbmktZGFzaGJvYXJkLWNoYXJ0J31cclxufSlcclxuXHJcbmV4cG9ydCBjbGFzcyBLZE1pbmlEYXNoYm9hcmRDaGFydCBpbXBsZW1lbnRzIE9uSW5pdCwgT25DaGFuZ2VzLCBBZnRlclZpZXdJbml0LCBPbkRlc3Ryb3kge1xyXG4gICAgcHVibGljIHRocmVlSXRlbUxlZ2VuZDogYm9vbGVhbiA9IGZhbHNlO1xyXG4gICAgcHVibGljIHBsYWNlbWVudDogc3RyaW5nID0gJ2JvdHRvbS1sZWZ0JztcclxuXHJcbiAgICBwcml2YXRlIF9jYW52YXM6IEVsZW1lbnQ7XHJcbiAgICBwcml2YXRlIF9jaGFydExlZ2VuZEVsZW1lbnQ6IEVsZW1lbnQ7XHJcbiAgICBwcml2YXRlIF9sZWdlbmRMYWJlbEVsZW1lbnQ6IEVsZW1lbnQ7XHJcbiAgICBwcml2YXRlIF90b29sdGlwRWxlbWVudDogRWxlbWVudDtcclxuICAgIHByaXZhdGUgX3BDaGFydHNGdW5jdGlvbjogdHlwZXMuSUNoYXJ0RnVuY3Rpb25zO1xyXG4gICAgcHJpdmF0ZSBfaXNXaWR0aENoYW5nZWQ6IHsgbGVnZW5kOiBib29sZWFuLCBjYW52YXM6IGJvb2xlYW4gfSA9IHsgbGVnZW5kOiBmYWxzZSwgY2FudmFzOiBmYWxzZSB9O1xyXG4gICAgcHJpdmF0ZSBfaXNGaXJzdExvYWQ6IGJvb2xlYW4gPSB0cnVlO1xyXG4gICAgcHJpdmF0ZSBfcENoYXJ0RWxlbWVudDogYW55O1xyXG5cclxuICAgIEBJbnB1dCgpIGRhdGE6IGFueTtcclxuICAgIEBJbnB1dCgpIG9wdGlvbnM6IGFueTtcclxuICAgIEBJbnB1dCgpIGlzTGVnZW5kRGlzcGxheWVkOiBib29sZWFuO1xyXG4gICAgQElucHV0KCkgaXRlbUxlbmd0aDogbnVtYmVyO1xyXG4gICAgQElucHV0KCkgZGlyZWN0aW9uOiBzdHJpbmc7XHJcblxyXG4gICAgQFZpZXdDaGlsZChVSUNoYXJ0LCB7IHN0YXRpYzogdHJ1ZSB9KSBjaGFydDogVUlDaGFydDtcclxuICAgIEBWaWV3Q2hpbGQoJ3QnLCB7IHN0YXRpYzogdHJ1ZSB9KSB0b29sdGlwOiBhbnk7XHJcbiAgICBAVmlld0NoaWxkKCdjaGFydExlZ2VuZCcsIHsgc3RhdGljOiB0cnVlIH0pIGNoYXJ0TGVnZW5kOiBhbnk7XHJcblxyXG4gICAgY29uc3RydWN0b3IoXHJcbiAgICAgICAgcHJpdmF0ZSBfa2RNaW5pRGFzaGJvYXJkU3ZjOiBLZE1pbmlEYXNoYm9hcmRTdmMsXHJcbiAgICAgICAgcHJpdmF0ZSBfZWxlbWVudFJlZjogRWxlbWVudFJlZixcclxuICAgICAgICBwcml2YXRlIF9yZW5kZXJlcjogUmVuZGVyZXIyLFxyXG4gICAgICAgIF9rZFNwbGl0dGVyRXZlbnQ6IEtkU3BsaXR0ZXJFdmVudFxyXG4gICAgKSB7XHJcbiAgICAgICAgdGhpcy5fcENoYXJ0c0Z1bmN0aW9uID0gX2tkTWluaURhc2hib2FyZFN2Yy5wY2hhcnRzKF9lbGVtZW50UmVmLCBfcmVuZGVyZXIpO1xyXG4gICAgICAgIF9rZFNwbGl0dGVyRXZlbnQub25EcmFnKCkuc3Vic2NyaWJlKF90eXBlID0+IHtcclxuICAgICAgICAgICAgdGhpcy5fcENoYXJ0c0Z1bmN0aW9uLnNldFRvb2x0aXBQbGFjZW1lbnRGbGFnKHRydWUpO1xyXG4gICAgICAgIH0pO1xyXG4gICAgICAgIF9rZFNwbGl0dGVyRXZlbnQub25Ub2dnbGVNZW51KCkuc3Vic2NyaWJlKF90eXBlID0+IHtcclxuICAgICAgICAgICAgdGhpcy5fcENoYXJ0c0Z1bmN0aW9uLnNldFRvb2x0aXBQbGFjZW1lbnRGbGFnKHRydWUpO1xyXG4gICAgICAgIH0pO1xyXG4gICAgfVxyXG5cclxuICAgIEBIb3N0TGlzdGVuZXIoJ3dpbmRvdzpyZXNpemUnLCBbJyRldmVudCddKVxyXG4gICAgb25SZXNpemUoZXZlbnQ6IGFueSk6IHZvaWQge1xyXG4gICAgICAgIHRoaXMuX3BDaGFydHNGdW5jdGlvbi5zZXRUb29sdGlwUGxhY2VtZW50RmxhZyh0cnVlKTtcclxuICAgICAgICB0aGlzLl9wQ2hhcnRzRnVuY3Rpb24ucHJvY2Vzc1Rvb2x0aXBUb0NhbnZhc1NpemUodGhpcy5fY2FudmFzLCB0aGlzLmNoYXJ0KTtcclxuICAgICAgICBpZiAodGhpcy5pdGVtTGVuZ3RoID09PSAzKSB7XHJcbiAgICAgICAgICAgIHRoaXMuX3Jlc2l6ZUxlZ2VuZCgpO1xyXG4gICAgICAgICAgICB0aGlzLl9yZXNpemVDYW52YXMoKTtcclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgbmdPbkluaXQoKTogdm9pZCB7XHJcbiAgICAgICAgdGhpcy5faXNGaXJzdExvYWQgPSBmYWxzZTtcclxuICAgICAgICB0aGlzLl90b29sdGlwRWxlbWVudCA9IHRoaXMudG9vbHRpcC5fZWxlbWVudFJlZi5uYXRpdmVFbGVtZW50O1xyXG4gICAgICAgIHRoaXMuX2NoYXJ0TGVnZW5kRWxlbWVudCA9IHRoaXMuY2hhcnRMZWdlbmQubmF0aXZlRWxlbWVudDtcclxuICAgIH1cclxuXHJcbiAgICBuZ09uQ2hhbmdlcyhfc2ltcGxlQ2hhbmdlczogU2ltcGxlQ2hhbmdlcyk6IHZvaWQge1xyXG4gICAgICAgIGlmIChfc2ltcGxlQ2hhbmdlcy5oYXNPd25Qcm9wZXJ0eSgnaXRlbUxlbmd0aCcpICYmIF9zaW1wbGVDaGFuZ2VzLml0ZW1MZW5ndGguY3VycmVudFZhbHVlID09PSAzKSB7XHJcbiAgICAgICAgICAgIHRoaXMuX3Jlc2l6ZUxlZ2VuZCgpO1xyXG4gICAgICAgIH1cclxuICAgICAgICBpZiAoIXRoaXMuX2lzRmlyc3RMb2FkICYmIHRoaXMuaXRlbUxlbmd0aCA9PT0gMykgdGhpcy5fcmVzaXplQ2FudmFzKCk7XHJcbiAgICAgICAgaWYgKF9zaW1wbGVDaGFuZ2VzLmhhc093blByb3BlcnR5KCdkaXJlY3Rpb24nKSAmJiB0aGlzLmRpcmVjdGlvbiA9PT0gJ3JpZ2h0JykgdGhpcy5wbGFjZW1lbnQgPSAnYm90dG9tLXJpZ2h0JztcclxuICAgIH1cclxuXHJcbiAgICBuZ0FmdGVyVmlld0luaXQoKTogdm9pZCB7XHJcbiAgICAgICAgdGhpcy5fY2FudmFzID0gdGhpcy5jaGFydC5nZXRDYW52YXMoKTtcclxuICAgICAgICB0aGlzLl9wQ2hhcnRFbGVtZW50ID0gdGhpcy5fZWxlbWVudFJlZi5uYXRpdmVFbGVtZW50LnF1ZXJ5U2VsZWN0b3IoJy5rZHgtbWluaS1kYXNoYm9hcmQgLmtkeC1taW5pLWRhc2hib2FyZC1jaGFydCBwLWNoYXJ0Jyk7XHJcbiAgICAgICAgaWYgKHRoaXMuaXRlbUxlbmd0aCA9PT0gMykgdGhpcy5fcmVzaXplQ2FudmFzKCk7XHJcbiAgICAgICAgdGhpcy5fc2V0TGVnZW5kKCk7XHJcbiAgICAgICAgdGhpcy5fcENoYXJ0c0Z1bmN0aW9uLnByb2Nlc3NUb29sdGlwVG9DYW52YXNTaXplKHRoaXMuX2NhbnZhcywgdGhpcy5jaGFydCk7XHJcbiAgICB9XHJcblxyXG4gICAgbmdPbkRlc3Ryb3koKTogdm9pZCB7XHJcbiAgICAgICAgdGhpcy5fa2RNaW5pRGFzaGJvYXJkU3ZjLnJlbW92ZUNoaWxkcmVuKHRoaXMuX2NoYXJ0TGVnZW5kRWxlbWVudCk7XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfc2V0TGVnZW5kKCk6IHZvaWQge1xyXG4gICAgICAgIGlmICghdGhpcy5pc0xlZ2VuZERpc3BsYXllZCkgcmV0dXJuO1xyXG4gICAgICAgIHRoaXMuX2NoYXJ0TGVnZW5kRWxlbWVudC5pbm5lckhUTUwgPSB0aGlzLmNoYXJ0LmNoYXJ0LmdlbmVyYXRlTGVnZW5kKCkgfHwgJyc7XHJcbiAgICAgICAgdGhpcy5fc2V0TGVnZW5kTGFiZWxFbGVtZW50KCk7XHJcbiAgICAgICAgdGhpcy5fcENoYXJ0c0Z1bmN0aW9uLmF0dGFjaExlZ2VuZExpc3RlbmVyKFxyXG4gICAgICAgICAgICB0aGlzLl9sZWdlbmRMYWJlbEVsZW1lbnQsXHJcbiAgICAgICAgICAgIHsgdWlDaGFydDogdGhpcy5jaGFydCwgbGVnZW5kRWxlbWVudDogdGhpcy5fY2hhcnRMZWdlbmRFbGVtZW50IH0sXHJcbiAgICAgICAgICAgIHsgbWV0aG9kOiB0aGlzLnRvb2x0aXAsIGVsZW1lbnQ6IHRoaXMuX3Rvb2x0aXBFbGVtZW50IH0sXHJcbiAgICAgICAgICAgIHRoaXMuZGlyZWN0aW9uXHJcbiAgICAgICAgKTtcclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF9zZXRMZWdlbmRMYWJlbEVsZW1lbnQoKTogdm9pZCB7XHJcbiAgICAgICAgdGhpcy5fbGVnZW5kTGFiZWxFbGVtZW50ID0gdGhpcy5fZWxlbWVudFJlZi5uYXRpdmVFbGVtZW50LnF1ZXJ5U2VsZWN0b3JBbGwoJy5rZHgtbWluaS1kYXNoYm9hcmQgLmtkeC1lbGVtLWl0ZW0gLmNoYXJ0LWxlZ2VuZCB1bCBsaSAuY2hhcnQtbGVnZW5kLWxhYmVsJyk7XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfcmVzaXplTGVnZW5kKCk6IHZvaWQge1xyXG4gICAgICAgIGlmICg0ODAgPCB3aW5kb3cuaW5uZXJXaWR0aCAmJiB3aW5kb3cuaW5uZXJXaWR0aCA8IDY1MCkge1xyXG4gICAgICAgICAgICBpZiAodGhpcy5faXNXaWR0aENoYW5nZWQubGVnZW5kID09PSBmYWxzZSkge1xyXG4gICAgICAgICAgICAgICAgdGhpcy50aHJlZUl0ZW1MZWdlbmQgPSB0cnVlO1xyXG4gICAgICAgICAgICAgICAgdGhpcy5faXNXaWR0aENoYW5nZWQubGVnZW5kID0gdHJ1ZTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgIGlmICh0aGlzLl9pc1dpZHRoQ2hhbmdlZC5sZWdlbmQgPT09IHRydWUpIHtcclxuICAgICAgICAgICAgICAgIHRoaXMudGhyZWVJdGVtTGVnZW5kID0gZmFsc2U7XHJcbiAgICAgICAgICAgICAgICB0aGlzLl9pc1dpZHRoQ2hhbmdlZC5sZWdlbmQgPSBmYWxzZTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF9yZXNpemVDYW52YXMoKTogdm9pZCB7XHJcbiAgICAgICAgaWYgKDQ4MCA8IHdpbmRvdy5pbm5lcldpZHRoICYmIHdpbmRvdy5pbm5lcldpZHRoIDwgNjUwKSB7XHJcbiAgICAgICAgICAgIGlmICh0aGlzLl9pc1dpZHRoQ2hhbmdlZC5jYW52YXMgPT09IGZhbHNlKSB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLl9wQ2hhcnRzRnVuY3Rpb24uc2V0Q2FudmFzU3R5bGUoJzgwJywgdGhpcy5fY2FudmFzKTtcclxuICAgICAgICAgICAgICAgIHRoaXMuX2lzV2lkdGhDaGFuZ2VkLmNhbnZhcyA9IHRydWU7XHJcbiAgICAgICAgICAgICAgICB0aGlzLl9yZW5kZXJlci5zZXRTdHlsZSh0aGlzLl9wQ2hhcnRFbGVtZW50LCAnd2lkdGgnLCAnODBweCcpO1xyXG4gICAgICAgICAgICAgICAgdGhpcy5fcmVuZGVyZXIuc2V0U3R5bGUodGhpcy5fcENoYXJ0RWxlbWVudCwgJ2hlaWdodCcsICc4MHB4Jyk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9IGVsc2UgaWYgKHdpbmRvdy5pbm5lcldpZHRoID4gNjUwIHx8IHdpbmRvdy5pbm5lcldpZHRoID09PSA2NTApIHtcclxuICAgICAgICAgICAgaWYgKHRoaXMuX2lzV2lkdGhDaGFuZ2VkLmNhbnZhcyA9PT0gdHJ1ZSkge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5fcENoYXJ0c0Z1bmN0aW9uLnNldENhbnZhc1N0eWxlKCcxMDAnLCB0aGlzLl9jYW52YXMpO1xyXG4gICAgICAgICAgICAgICAgdGhpcy5faXNXaWR0aENoYW5nZWQuY2FudmFzID0gZmFsc2U7XHJcbiAgICAgICAgICAgICAgICB0aGlzLl9yZW5kZXJlci5zZXRTdHlsZSh0aGlzLl9wQ2hhcnRFbGVtZW50LCAnd2lkdGgnLCAnMTAwcHgnKTtcclxuICAgICAgICAgICAgICAgIHRoaXMuX3JlbmRlcmVyLnNldFN0eWxlKHRoaXMuX3BDaGFydEVsZW1lbnQsICdoZWlnaHQnLCAnMTAwcHgnKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgIH1cclxufVxyXG4iXX0=