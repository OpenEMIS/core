import { __decorate, __metadata } from "tslib";
import { Component, ViewEncapsulation, Input, OnInit, OnChanges, SimpleChanges, ElementRef, Renderer2, } from '@angular/core';
import { KdDomElemSvc, KdDataSvc } from '../kd-common/index';
import * as types from './kd-angular-mini-dashboard-interface';
import { KdMiniDashboardSvc } from './kd-angular-mini-dashboard-svc';
var KdMiniDashboard = /** @class */ (function () {
    function KdMiniDashboard(_kdDomElemSvc, _elementRef, _renderer, _kdMiniDashboardSvc) {
        this._kdMiniDashboardSvc = _kdMiniDashboardSvc;
        this.isOpen = true;
        this.isThreeItem = false;
        this.updatedConfig = {};
        this.direction = 'left';
        this._defaultConfig = {
            closeButtonDisabled: false,
            reopen: true,
        };
        this._item = [];
        this._firstLoad = true;
        this._isWidthChanged = { rowContainer: false };
        this._pChartsFunction = _kdMiniDashboardSvc.pcharts(_elementRef, _renderer);
        this.direction = _kdDomElemSvc.getDocumentDirection(true);
    }
    KdMiniDashboard.prototype.ngOnInit = function () {
        this.updatedConfig = Object.assign(this._defaultConfig, this.config);
        this._firstLoad = false;
    };
    KdMiniDashboard.prototype.ngOnChanges = function (_simpleChanges) {
        if (_simpleChanges.hasOwnProperty('input'))
            this._item = this._setData(_simpleChanges.input.currentValue);
        if (this._item.length === 3) {
            this._setRowContainerWidthWhenThreeItems();
            this.isThreeItem = true;
        }
        else {
            this.isThreeItem = false;
        }
        if (!this._firstLoad) {
            if (_simpleChanges.hasOwnProperty('config'))
                this.updatedConfig = Object.assign(this.config, _simpleChanges.config.currentValue);
        }
    };
    KdMiniDashboard.prototype.miniDashboardSwitch = function () {
        this.isOpen = this.isOpen ? false : true;
    };
    KdMiniDashboard.prototype._setData = function (_item) {
        var processedData = [];
        var noOfLoop = Math.min(_item.length, 4);
        for (var i = 0; i < noOfLoop; i++) {
            if (_item[i].type === 'chart' && _item[i].value) {
                if (!Array.isArray(_item[i].value)) {
                    console.error('value of type: chart must be array');
                    continue;
                }
                var chart = this._pChartsFunction.setChart(_item[i].value, _item[i].config, _item[i].label);
                var final = Object.assign({}, { type: 'chart', isLegendDisplayed: _item[i].config.legend.display }, chart);
                processedData.push(final);
            }
            else if (_item[i].type === 'text') {
                if (typeof _item[i].value !== 'string' && typeof _item[i].value !== 'number') {
                    console.error('value of type: text must be string or number');
                    continue;
                }
                var final = Object.assign({}, _item[i], { value: this._kdMiniDashboardSvc.addThousandSeparator(_item[i].value) });
                processedData.push(final);
            }
        }
        this.itemLength = noOfLoop;
        return processedData;
    };
    KdMiniDashboard.prototype._setRowContainerWidthWhenThreeItems = function () {
        if (480 < window.innerWidth) {
            if (this._isWidthChanged.rowContainer === false) {
                this.isThreeItem = true;
                this._isWidthChanged.rowContainer = true;
            }
        }
        else {
            if (this._isWidthChanged.rowContainer === true) {
                this.isThreeItem = false;
                this._isWidthChanged.rowContainer = false;
            }
        }
    };
    KdMiniDashboard.ctorParameters = function () { return [
        { type: KdDomElemSvc },
        { type: ElementRef },
        { type: Renderer2 },
        { type: KdMiniDashboardSvc }
    ]; };
    __decorate([
        Input(),
        __metadata("design:type", Object)
    ], KdMiniDashboard.prototype, "config", void 0);
    __decorate([
        Input(),
        __metadata("design:type", Array)
    ], KdMiniDashboard.prototype, "input", void 0);
    KdMiniDashboard = __decorate([
        Component({
            selector: 'kd-mini-dashboard',
            template: "<div *ngIf=\"isOpen\" class=\"kdx-mini-dashboard\" #test>\r\n    <div class=\"kdx-row-container\" *ngFor=\"let item of _item; let i = index \" [ngClass]=\"{'three-item' : isThreeItem }\">\r\n        <ng-container [ngSwitch]=\"item.type\">\r\n            <div class=\"kdx-elem-item chart\" *ngSwitchCase=\"'text'\">\r\n                <div class=\"kdx-item-icon\" *ngIf=\"item.icon\">\r\n                    <i class=\"{{item.icon}}\"></i>\r\n                </div>\r\n                <div class=\"kdx-item-content\">\r\n                    <div class=\"kdx-mini-dashboard-ellipsis item-label\">{{ item.label }}</div>\r\n                    <div class=\"kdx-mini-dashboard-ellipsis item-value\">{{ item.value || \"nil\" }}</div>\r\n                </div>\r\n            </div>\r\n            <kd-mini-dashboard-chart \r\n                *ngSwitchCase=\"'chart'\"\r\n                [data]=\"item.data\" \r\n                [options]=\"item.options\" \r\n                [isLegendDisplayed]=\"item.isLegendDisplayed\" \r\n                [itemLength]=\"itemLength\"\r\n                [direction]=\"direction\"\r\n                class=\"kdx-mini-dashboard-chart\"\r\n                >\r\n            </kd-mini-dashboard-chart>\r\n        </ng-container>\r\n    </div>\r\n    <div class=\"kdx-mini-dashboard-button \" *ngIf=\"!updatedConfig.closeButtonDisabled\">\r\n        <button type=\"button\" class=\"kdx-close-mini-dashboard\" (click)=\"miniDashboardSwitch()\"> <i class=\"fa fa-times\"></i> </button>\r\n    </div>\r\n                     \r\n</div>\r\n<button class=\"btn btn-text\" *ngIf=\"!isOpen && updatedConfig.reopen\" (click)=\"miniDashboardSwitch()\"> Open Mini Dashboard</button>\r\n",
            encapsulation: ViewEncapsulation.None,
            providers: [KdMiniDashboardSvc, KdDomElemSvc, KdDataSvc]
        }),
        __metadata("design:paramtypes", [KdDomElemSvc,
            ElementRef,
            Renderer2,
            KdMiniDashboardSvc])
    ], KdMiniDashboard);
    return KdMiniDashboard;
}());
export { KdMiniDashboard };
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoia2QtYW5ndWxhci1taW5pLWRhc2hib2FyZC5qcyIsInNvdXJjZVJvb3QiOiJuZzovL29wZW5lbWlzLXN0eWxlZ3VpZGUtbGliLyIsInNvdXJjZXMiOlsia2QtY29tcG9uZW50cy9rZC1hbmd1bGFyLW1pbmktZGFzaGJvYXJkL2tkLWFuZ3VsYXItbWluaS1kYXNoYm9hcmQudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IjtBQUFBLE9BQU8sRUFDSCxTQUFTLEVBQ1QsaUJBQWlCLEVBQ2pCLEtBQUssRUFDTCxNQUFNLEVBQ04sU0FBUyxFQUNULGFBQWEsRUFDYixVQUFVLEVBQ1YsU0FBUyxHQUNaLE1BQU0sZUFBZSxDQUFDO0FBQ3ZCLE9BQU8sRUFBRSxZQUFZLEVBQUUsU0FBUyxFQUFFLE1BQU0sb0JBQW9CLENBQUM7QUFDN0QsT0FBTyxLQUFLLEtBQUssTUFBTSx1Q0FBdUMsQ0FBQztBQUMvRCxPQUFPLEVBQUUsa0JBQWtCLEVBQUUsTUFBTSxpQ0FBaUMsQ0FBQztBQVNyRTtJQW1CSSx5QkFDSSxhQUEyQixFQUMzQixXQUF1QixFQUN2QixTQUFvQixFQUNaLG1CQUF1QztRQUF2Qyx3QkFBbUIsR0FBbkIsbUJBQW1CLENBQW9CO1FBdEI1QyxXQUFNLEdBQVksSUFBSSxDQUFDO1FBQ3ZCLGdCQUFXLEdBQVksS0FBSyxDQUFDO1FBQzdCLGtCQUFhLEdBQStCLEVBQUUsQ0FBQztRQUMvQyxjQUFTLEdBQVcsTUFBTSxDQUFDO1FBRzFCLG1CQUFjLEdBQStCO1lBQ2pELG1CQUFtQixFQUFFLEtBQUs7WUFDMUIsTUFBTSxFQUFFLElBQUk7U0FDZixDQUFDO1FBQ0ssVUFBSyxHQUFRLEVBQUUsQ0FBQztRQUNmLGVBQVUsR0FBWSxJQUFJLENBQUM7UUFFM0Isb0JBQWUsR0FBOEIsRUFBRSxZQUFZLEVBQUUsS0FBSyxFQUFFLENBQUM7UUFXekUsSUFBSSxDQUFDLGdCQUFnQixHQUFHLG1CQUFtQixDQUFDLE9BQU8sQ0FBQyxXQUFXLEVBQUUsU0FBUyxDQUFDLENBQUM7UUFDNUUsSUFBSSxDQUFDLFNBQVMsR0FBRyxhQUFhLENBQUMsb0JBQW9CLENBQUMsSUFBSSxDQUFDLENBQUM7SUFDOUQsQ0FBQztJQUVELGtDQUFRLEdBQVI7UUFDSSxJQUFJLENBQUMsYUFBYSxHQUFHLE1BQU0sQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLGNBQWMsRUFBRSxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUM7UUFDckUsSUFBSSxDQUFDLFVBQVUsR0FBRyxLQUFLLENBQUM7SUFDNUIsQ0FBQztJQUVELHFDQUFXLEdBQVgsVUFBWSxjQUE2QjtRQUNyQyxJQUFJLGNBQWMsQ0FBQyxjQUFjLENBQUMsT0FBTyxDQUFDO1lBQUUsSUFBSSxDQUFDLEtBQUssR0FBRyxJQUFJLENBQUMsUUFBUSxDQUFDLGNBQWMsQ0FBQyxLQUFLLENBQUMsWUFBWSxDQUFDLENBQUM7UUFDMUcsSUFBSSxJQUFJLENBQUMsS0FBSyxDQUFDLE1BQU0sS0FBSyxDQUFDLEVBQUU7WUFDekIsSUFBSSxDQUFDLG1DQUFtQyxFQUFFLENBQUM7WUFDM0MsSUFBSSxDQUFDLFdBQVcsR0FBRyxJQUFJLENBQUM7U0FDM0I7YUFBTTtZQUFFLElBQUksQ0FBQyxXQUFXLEdBQUcsS0FBSyxDQUFDO1NBQUU7UUFFcEMsSUFBSSxDQUFDLElBQUksQ0FBQyxVQUFVLEVBQUU7WUFDbEIsSUFBSSxjQUFjLENBQUMsY0FBYyxDQUFDLFFBQVEsQ0FBQztnQkFBRSxJQUFJLENBQUMsYUFBYSxHQUFHLE1BQU0sQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLE1BQU0sRUFBRSxjQUFjLENBQUMsTUFBTSxDQUFDLFlBQVksQ0FBQyxDQUFDO1NBQ3BJO0lBQ0wsQ0FBQztJQUVNLDZDQUFtQixHQUExQjtRQUNJLElBQUksQ0FBQyxNQUFNLEdBQUcsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUM7SUFDN0MsQ0FBQztJQUVPLGtDQUFRLEdBQWhCLFVBQWlCLEtBQXNDO1FBQ25ELElBQUksYUFBYSxHQUFvQyxFQUFFLENBQUM7UUFDeEQsSUFBSSxRQUFRLEdBQVcsSUFBSSxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsTUFBTSxFQUFFLENBQUMsQ0FBQyxDQUFDO1FBRWpELEtBQUssSUFBSSxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsR0FBRyxRQUFRLEVBQUUsQ0FBQyxFQUFFLEVBQUU7WUFDL0IsSUFBSSxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxLQUFLLE9BQU8sSUFBSSxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxFQUFFO2dCQUM3QyxJQUFJLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLEVBQUU7b0JBQ2hDLE9BQU8sQ0FBQyxLQUFLLENBQUMsb0NBQW9DLENBQUMsQ0FBQztvQkFDcEQsU0FBUztpQkFDWjtnQkFFRCxJQUFJLEtBQUssR0FBRyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsUUFBUSxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLEVBQUUsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sRUFBRSxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUM7Z0JBQzVGLElBQUksS0FBSyxHQUFHLE1BQU0sQ0FBQyxNQUFNLENBQUMsRUFBRSxFQUFFLEVBQUUsSUFBSSxFQUFFLE9BQU8sRUFBRSxpQkFBaUIsRUFBRSxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxPQUFPLEVBQUUsRUFBRSxLQUFLLENBQUMsQ0FBQztnQkFDM0csYUFBYSxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQzthQUM3QjtpQkFDSSxJQUFJLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLEtBQUssTUFBTSxFQUFFO2dCQUMvQixJQUFJLE9BQU8sS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssS0FBSyxRQUFRLElBQUksT0FBTyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxLQUFLLFFBQVEsRUFBRTtvQkFDMUUsT0FBTyxDQUFDLEtBQUssQ0FBQyw4Q0FBOEMsQ0FBQyxDQUFDO29CQUM5RCxTQUFTO2lCQUNaO2dCQUNELElBQUksS0FBSyxHQUFHLE1BQU0sQ0FBQyxNQUFNLENBQUMsRUFBRSxFQUFFLEtBQUssQ0FBQyxDQUFDLENBQUMsRUFBRSxFQUFFLEtBQUssRUFBRSxJQUFJLENBQUMsbUJBQW1CLENBQUMsb0JBQW9CLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxFQUFFLENBQUMsQ0FBQztnQkFDbEgsYUFBYSxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQzthQUM3QjtTQUNKO1FBQ0QsSUFBSSxDQUFDLFVBQVUsR0FBRyxRQUFRLENBQUM7UUFDM0IsT0FBTyxhQUFhLENBQUM7SUFDekIsQ0FBQztJQUVPLDZEQUFtQyxHQUEzQztRQUNJLElBQUksR0FBRyxHQUFHLE1BQU0sQ0FBQyxVQUFVLEVBQUU7WUFDekIsSUFBSSxJQUFJLENBQUMsZUFBZSxDQUFDLFlBQVksS0FBSyxLQUFLLEVBQUU7Z0JBQzdDLElBQUksQ0FBQyxXQUFXLEdBQUcsSUFBSSxDQUFDO2dCQUN4QixJQUFJLENBQUMsZUFBZSxDQUFDLFlBQVksR0FBRyxJQUFJLENBQUM7YUFDNUM7U0FDSjthQUFNO1lBQ0gsSUFBSSxJQUFJLENBQUMsZUFBZSxDQUFDLFlBQVksS0FBSyxJQUFJLEVBQUU7Z0JBQzVDLElBQUksQ0FBQyxXQUFXLEdBQUcsS0FBSyxDQUFDO2dCQUN6QixJQUFJLENBQUMsZUFBZSxDQUFDLFlBQVksR0FBRyxLQUFLLENBQUM7YUFDN0M7U0FDSjtJQUNMLENBQUM7O2dCQXRFa0IsWUFBWTtnQkFDZCxVQUFVO2dCQUNaLFNBQVM7Z0JBQ1Msa0JBQWtCOztJQVAxQztRQUFSLEtBQUssRUFBRTs7bURBQW9DO0lBQ25DO1FBQVIsS0FBSyxFQUFFO2tDQUFRLEtBQUs7a0RBQTJCO0lBakJ2QyxlQUFlO1FBUDNCLFNBQVMsQ0FBQztZQUNQLFFBQVEsRUFBRSxtQkFBbUI7WUFDN0IsK3FEQUErQztZQUMvQyxhQUFhLEVBQUUsaUJBQWlCLENBQUMsSUFBSTtZQUNyQyxTQUFTLEVBQUUsQ0FBQyxrQkFBa0IsRUFBRSxZQUFZLEVBQUUsU0FBUyxDQUFDO1NBQzNELENBQUM7eUNBc0JxQixZQUFZO1lBQ2QsVUFBVTtZQUNaLFNBQVM7WUFDUyxrQkFBa0I7T0F2QjFDLGVBQWUsQ0EyRjNCO0lBQUQsc0JBQUM7Q0FBQSxBQTNGRCxJQTJGQztTQTNGWSxlQUFlIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHtcclxuICAgIENvbXBvbmVudCxcclxuICAgIFZpZXdFbmNhcHN1bGF0aW9uLFxyXG4gICAgSW5wdXQsXHJcbiAgICBPbkluaXQsXHJcbiAgICBPbkNoYW5nZXMsXHJcbiAgICBTaW1wbGVDaGFuZ2VzLFxyXG4gICAgRWxlbWVudFJlZixcclxuICAgIFJlbmRlcmVyMixcclxufSBmcm9tICdAYW5ndWxhci9jb3JlJztcclxuaW1wb3J0IHsgS2REb21FbGVtU3ZjLCBLZERhdGFTdmMgfSBmcm9tICcuLi9rZC1jb21tb24vaW5kZXgnO1xyXG5pbXBvcnQgKiBhcyB0eXBlcyBmcm9tICcuL2tkLWFuZ3VsYXItbWluaS1kYXNoYm9hcmQtaW50ZXJmYWNlJztcclxuaW1wb3J0IHsgS2RNaW5pRGFzaGJvYXJkU3ZjIH0gZnJvbSAnLi9rZC1hbmd1bGFyLW1pbmktZGFzaGJvYXJkLXN2Yyc7XHJcblxyXG5AQ29tcG9uZW50KHtcclxuICAgIHNlbGVjdG9yOiAna2QtbWluaS1kYXNoYm9hcmQnLFxyXG4gICAgdGVtcGxhdGVVcmw6ICcuL2tkLWFuZ3VsYXItbWluaS1kYXNoYm9hcmQuaHRtbCcsXHJcbiAgICBlbmNhcHN1bGF0aW9uOiBWaWV3RW5jYXBzdWxhdGlvbi5Ob25lLFxyXG4gICAgcHJvdmlkZXJzOiBbS2RNaW5pRGFzaGJvYXJkU3ZjLCBLZERvbUVsZW1TdmMsIEtkRGF0YVN2Y10sXHJcbn0pXHJcblxyXG5leHBvcnQgY2xhc3MgS2RNaW5pRGFzaGJvYXJkIGltcGxlbWVudHMgT25Jbml0LCBPbkNoYW5nZXMge1xyXG4gICAgcHVibGljIGlzT3BlbjogYm9vbGVhbiA9IHRydWU7XHJcbiAgICBwdWJsaWMgaXNUaHJlZUl0ZW06IGJvb2xlYW4gPSBmYWxzZTtcclxuICAgIHB1YmxpYyB1cGRhdGVkQ29uZmlnOiB0eXBlcy5JTWluaURhc2hib2FyZENvbmZpZyA9IHt9O1xyXG4gICAgcHVibGljIGRpcmVjdGlvbjogc3RyaW5nID0gJ2xlZnQnO1xyXG4gICAgcHVibGljIGl0ZW1MZW5ndGg6IG51bWJlcjtcclxuXHJcbiAgICBwcml2YXRlIF9kZWZhdWx0Q29uZmlnOiB0eXBlcy5JTWluaURhc2hib2FyZENvbmZpZyA9IHtcclxuICAgICAgICBjbG9zZUJ1dHRvbkRpc2FibGVkOiBmYWxzZSxcclxuICAgICAgICByZW9wZW46IHRydWUsXHJcbiAgICB9O1xyXG4gICAgcHVibGljIF9pdGVtOiBhbnkgPSBbXTtcclxuICAgIHByaXZhdGUgX2ZpcnN0TG9hZDogYm9vbGVhbiA9IHRydWU7XHJcbiAgICBwcml2YXRlIF9wQ2hhcnRzRnVuY3Rpb246IHR5cGVzLklDaGFydEZ1bmN0aW9ucztcclxuICAgIHByaXZhdGUgX2lzV2lkdGhDaGFuZ2VkOiB7IHJvd0NvbnRhaW5lcjogYm9vbGVhbiB9ID0geyByb3dDb250YWluZXI6IGZhbHNlIH07XHJcblxyXG4gICAgQElucHV0KCkgY29uZmlnOiB0eXBlcy5JTWluaURhc2hib2FyZENvbmZpZztcclxuICAgIEBJbnB1dCgpIGlucHV0OiBBcnJheTx0eXBlcy5JTWluaURhc2hib2FyZEl0ZW0+O1xyXG5cclxuICAgIGNvbnN0cnVjdG9yKFxyXG4gICAgICAgIF9rZERvbUVsZW1TdmM6IEtkRG9tRWxlbVN2YyxcclxuICAgICAgICBfZWxlbWVudFJlZjogRWxlbWVudFJlZixcclxuICAgICAgICBfcmVuZGVyZXI6IFJlbmRlcmVyMixcclxuICAgICAgICBwcml2YXRlIF9rZE1pbmlEYXNoYm9hcmRTdmM6IEtkTWluaURhc2hib2FyZFN2YyxcclxuICAgICkge1xyXG4gICAgICAgIHRoaXMuX3BDaGFydHNGdW5jdGlvbiA9IF9rZE1pbmlEYXNoYm9hcmRTdmMucGNoYXJ0cyhfZWxlbWVudFJlZiwgX3JlbmRlcmVyKTtcclxuICAgICAgICB0aGlzLmRpcmVjdGlvbiA9IF9rZERvbUVsZW1TdmMuZ2V0RG9jdW1lbnREaXJlY3Rpb24odHJ1ZSk7XHJcbiAgICB9XHJcblxyXG4gICAgbmdPbkluaXQoKTogdm9pZCB7XHJcbiAgICAgICAgdGhpcy51cGRhdGVkQ29uZmlnID0gT2JqZWN0LmFzc2lnbih0aGlzLl9kZWZhdWx0Q29uZmlnLCB0aGlzLmNvbmZpZyk7XHJcbiAgICAgICAgdGhpcy5fZmlyc3RMb2FkID0gZmFsc2U7XHJcbiAgICB9XHJcblxyXG4gICAgbmdPbkNoYW5nZXMoX3NpbXBsZUNoYW5nZXM6IFNpbXBsZUNoYW5nZXMpOiB2b2lkIHtcclxuICAgICAgICBpZiAoX3NpbXBsZUNoYW5nZXMuaGFzT3duUHJvcGVydHkoJ2lucHV0JykpIHRoaXMuX2l0ZW0gPSB0aGlzLl9zZXREYXRhKF9zaW1wbGVDaGFuZ2VzLmlucHV0LmN1cnJlbnRWYWx1ZSk7XHJcbiAgICAgICAgaWYgKHRoaXMuX2l0ZW0ubGVuZ3RoID09PSAzKSB7XHJcbiAgICAgICAgICAgIHRoaXMuX3NldFJvd0NvbnRhaW5lcldpZHRoV2hlblRocmVlSXRlbXMoKTtcclxuICAgICAgICAgICAgdGhpcy5pc1RocmVlSXRlbSA9IHRydWU7XHJcbiAgICAgICAgfSBlbHNlIHsgdGhpcy5pc1RocmVlSXRlbSA9IGZhbHNlOyB9XHJcblxyXG4gICAgICAgIGlmICghdGhpcy5fZmlyc3RMb2FkKSB7XHJcbiAgICAgICAgICAgIGlmIChfc2ltcGxlQ2hhbmdlcy5oYXNPd25Qcm9wZXJ0eSgnY29uZmlnJykpIHRoaXMudXBkYXRlZENvbmZpZyA9IE9iamVjdC5hc3NpZ24odGhpcy5jb25maWcsIF9zaW1wbGVDaGFuZ2VzLmNvbmZpZy5jdXJyZW50VmFsdWUpO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICBwdWJsaWMgbWluaURhc2hib2FyZFN3aXRjaCgpOiB2b2lkIHtcclxuICAgICAgICB0aGlzLmlzT3BlbiA9IHRoaXMuaXNPcGVuID8gZmFsc2UgOiB0cnVlO1xyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX3NldERhdGEoX2l0ZW06IEFycmF5PHR5cGVzLklNaW5pRGFzaGJvYXJkSXRlbT4pOiBBcnJheTx0eXBlcy5JTWluaURhc2hib2FyZEl0ZW0+IHtcclxuICAgICAgICBsZXQgcHJvY2Vzc2VkRGF0YTogQXJyYXk8dHlwZXMuSU1pbmlEYXNoYm9hcmRJdGVtPiA9IFtdO1xyXG4gICAgICAgIGxldCBub09mTG9vcDogbnVtYmVyID0gTWF0aC5taW4oX2l0ZW0ubGVuZ3RoLCA0KTtcclxuXHJcbiAgICAgICAgZm9yIChsZXQgaSA9IDA7IGkgPCBub09mTG9vcDsgaSsrKSB7XHJcbiAgICAgICAgICAgIGlmIChfaXRlbVtpXS50eXBlID09PSAnY2hhcnQnICYmIF9pdGVtW2ldLnZhbHVlKSB7XHJcbiAgICAgICAgICAgICAgICBpZiAoIUFycmF5LmlzQXJyYXkoX2l0ZW1baV0udmFsdWUpKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgY29uc29sZS5lcnJvcigndmFsdWUgb2YgdHlwZTogY2hhcnQgbXVzdCBiZSBhcnJheScpO1xyXG4gICAgICAgICAgICAgICAgICAgIGNvbnRpbnVlO1xyXG4gICAgICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgICAgIGxldCBjaGFydCA9IHRoaXMuX3BDaGFydHNGdW5jdGlvbi5zZXRDaGFydChfaXRlbVtpXS52YWx1ZSwgX2l0ZW1baV0uY29uZmlnLCBfaXRlbVtpXS5sYWJlbCk7XHJcbiAgICAgICAgICAgICAgICBsZXQgZmluYWwgPSBPYmplY3QuYXNzaWduKHt9LCB7IHR5cGU6ICdjaGFydCcsIGlzTGVnZW5kRGlzcGxheWVkOiBfaXRlbVtpXS5jb25maWcubGVnZW5kLmRpc3BsYXkgfSwgY2hhcnQpO1xyXG4gICAgICAgICAgICAgICAgcHJvY2Vzc2VkRGF0YS5wdXNoKGZpbmFsKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBlbHNlIGlmIChfaXRlbVtpXS50eXBlID09PSAndGV4dCcpIHtcclxuICAgICAgICAgICAgICAgIGlmICh0eXBlb2YgX2l0ZW1baV0udmFsdWUgIT09ICdzdHJpbmcnICYmIHR5cGVvZiBfaXRlbVtpXS52YWx1ZSAhPT0gJ251bWJlcicpIHtcclxuICAgICAgICAgICAgICAgICAgICBjb25zb2xlLmVycm9yKCd2YWx1ZSBvZiB0eXBlOiB0ZXh0IG11c3QgYmUgc3RyaW5nIG9yIG51bWJlcicpO1xyXG4gICAgICAgICAgICAgICAgICAgIGNvbnRpbnVlO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgbGV0IGZpbmFsID0gT2JqZWN0LmFzc2lnbih7fSwgX2l0ZW1baV0sIHsgdmFsdWU6IHRoaXMuX2tkTWluaURhc2hib2FyZFN2Yy5hZGRUaG91c2FuZFNlcGFyYXRvcihfaXRlbVtpXS52YWx1ZSkgfSk7XHJcbiAgICAgICAgICAgICAgICBwcm9jZXNzZWREYXRhLnB1c2goZmluYWwpO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgICAgIHRoaXMuaXRlbUxlbmd0aCA9IG5vT2ZMb29wO1xyXG4gICAgICAgIHJldHVybiBwcm9jZXNzZWREYXRhO1xyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX3NldFJvd0NvbnRhaW5lcldpZHRoV2hlblRocmVlSXRlbXMoKTogdm9pZCB7XHJcbiAgICAgICAgaWYgKDQ4MCA8IHdpbmRvdy5pbm5lcldpZHRoKSB7XHJcbiAgICAgICAgICAgIGlmICh0aGlzLl9pc1dpZHRoQ2hhbmdlZC5yb3dDb250YWluZXIgPT09IGZhbHNlKSB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLmlzVGhyZWVJdGVtID0gdHJ1ZTtcclxuICAgICAgICAgICAgICAgIHRoaXMuX2lzV2lkdGhDaGFuZ2VkLnJvd0NvbnRhaW5lciA9IHRydWU7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICBpZiAodGhpcy5faXNXaWR0aENoYW5nZWQucm93Q29udGFpbmVyID09PSB0cnVlKSB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLmlzVGhyZWVJdGVtID0gZmFsc2U7XHJcbiAgICAgICAgICAgICAgICB0aGlzLl9pc1dpZHRoQ2hhbmdlZC5yb3dDb250YWluZXIgPSBmYWxzZTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgIH1cclxufVxyXG4iXX0=