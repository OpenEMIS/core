import { __decorate, __metadata } from "tslib";
import { Component, ViewEncapsulation, Input, Output, EventEmitter } from '@angular/core';
var KdDatepicker = /** @class */ (function () {
    function KdDatepicker() {
        this._defaultConfig = {
            firstDayOfWeek: 7
        };
        this._emitVal = {};
        this.dateConfig = new EventEmitter();
    }
    KdDatepicker.prototype.ngOnInit = function () {
        this._updatedConfig = Object.assign(this._defaultConfig, this.config);
        this._assignSetting(this.inputVal, 'value');
        this._assignSetting(this.minDate, 'minDate');
        this._assignSetting(this.maxDate, 'maxDate');
        this._popupPlacement = document.dir === 'rtl' ? 'bottom-left' : 'bottom-right';
    };
    KdDatepicker.prototype.ngOnChanges = function (_simpleChanges) {
        if (_simpleChanges.hasOwnProperty('inputVal') && !_simpleChanges['inputVal'].firstChange) {
            this._assignSetting(_simpleChanges['inputVal'].currentValue, 'value');
        }
        if (_simpleChanges.hasOwnProperty('minDate') && !_simpleChanges['minDate'].firstChange) {
            this._assignSetting(_simpleChanges['minDate'].currentValue, 'minDate');
        }
        if (_simpleChanges.hasOwnProperty('maxDate') && !_simpleChanges['maxDate'].firstChange) {
            this._assignSetting(_simpleChanges['maxDate'].currentValue, 'maxDate');
        }
    };
    KdDatepicker.prototype.emitValue = function () {
        var newModel = Object.assign({}, this._model);
        this._emitVal = {};
        this._emitVal.text = this._formatDate(newModel);
        this._emitVal.obj = newModel;
        this.dateConfig.emit(this._emitVal);
    };
    KdDatepicker.prototype._assignSetting = function (_value, _model) {
        var updateValue = this._getNgbDateStruct(_value);
        if (typeof updateValue !== 'undefined' && _model === 'value') {
            this._model = Object.assign({}, updateValue);
            this.emitValue();
        }
        else if (_model === 'minDate') {
            this._minDate = Object.assign({}, updateValue);
        }
        else if (_model === 'maxDate') {
            this._maxDate = Object.assign({}, updateValue);
        }
    };
    KdDatepicker.prototype._getNgbDateStruct = function (_value) {
        if (typeof _value !== 'undefined' && _value !== '' && _value !== null) {
            if (_value instanceof Object && _value.hasOwnProperty('month') && _value.hasOwnProperty('year') && _value.hasOwnProperty('day'))
                return _value;
            else if (typeof _value === 'string')
                return this._parseDate(_value);
        }
        return undefined;
    };
    // to be removed and use native api
    KdDatepicker.prototype._parseDate = function (_textDate) {
        var splitDate = _textDate.split('-');
        var updateDate = {
            year: parseInt(splitDate[0]),
            month: parseInt(splitDate[1]),
            day: parseInt(splitDate[2])
        };
        return updateDate;
    };
    KdDatepicker.prototype._formatDate = function (_objDate) {
        var date = 'undefined-undefined-undefined';
        if (_objDate !== null)
            date = _objDate.year + '-' + _objDate.month + '-' + _objDate.day;
        return date;
    };
    __decorate([
        Input(),
        __metadata("design:type", Object)
    ], KdDatepicker.prototype, "inputVal", void 0);
    __decorate([
        Input(),
        __metadata("design:type", Object)
    ], KdDatepicker.prototype, "config", void 0);
    __decorate([
        Input(),
        __metadata("design:type", Object)
    ], KdDatepicker.prototype, "minDate", void 0);
    __decorate([
        Input(),
        __metadata("design:type", Object)
    ], KdDatepicker.prototype, "maxDate", void 0);
    __decorate([
        Output(),
        __metadata("design:type", EventEmitter)
    ], KdDatepicker.prototype, "dateConfig", void 0);
    KdDatepicker = __decorate([
        Component({
            selector: 'kd-datepicker',
            template: "<div class=\"kdx-datepicker-wrapper\">\r\n\t<input class=\"kdx-datepicker-input\" \r\n\t\t\tplaceholder=\"yyyy-mm-dd\" \r\n\t\t\tngbDatepicker #d=\"ngbDatepicker\" \r\n\t\t\tnavigation= \"select\"\r\n\t\t\tcontainer=\"body\"\r\n\t\t\tplacement=\"{{_popupPlacement}}\"\r\n\t\t\t[minDate]=\"_minDate\"\r\n\t\t\t[maxDate]=\"_maxDate\"\r\n\t\t\t[firstDayOfWeek]=\"_updatedConfig.firstDayOfWeek\"\r\n\t\t\t[(ngModel)]=\"_model\" \r\n\t\t\t(ngModelChange)=\"emitValue()\"/>\r\n\t<ng-content></ng-content>\r\n\t<button class=\"btn btn-icon btn-input\" (click)=\"d.toggle()\" type=\"button\">\r\n\t\t<i class=\"fa fa-calendar fa-lg\" aria-hidden=\"true\"></i>\r\n\t</button>\r\n</div>",
            encapsulation: ViewEncapsulation.None,
            host: { 'class': 'kdx kdx-datepicker' }
        })
    ], KdDatepicker);
    return KdDatepicker;
}());
export { KdDatepicker };
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoia2QtYW5ndWxhci1kYXRlcGlja2VyLmpzIiwic291cmNlUm9vdCI6Im5nOi8vb3BlbmVtaXMtc3R5bGVndWlkZS1saWIvIiwic291cmNlcyI6WyJrZC1jb21wb25lbnRzL2tkLWFuZ3VsYXItZGF0ZXBpY2tlci9rZC1hbmd1bGFyLWRhdGVwaWNrZXIudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IjtBQUFBLE9BQU8sRUFDSCxTQUFTLEVBQ1QsaUJBQWlCLEVBQ2pCLEtBQUssRUFJTCxNQUFNLEVBQ04sWUFBWSxFQUNmLE1BQU0sZUFBZSxDQUFDO0FBVXZCO0lBQUE7UUFPWSxtQkFBYyxHQUFRO1lBQzFCLGNBQWMsRUFBRSxDQUFDO1NBQ3BCLENBQUM7UUFDTSxhQUFRLEdBQVEsRUFBRSxDQUFDO1FBTWpCLGVBQVUsR0FBc0IsSUFBSSxZQUFZLEVBQUUsQ0FBQztJQXFFakUsQ0FBQztJQW5FRywrQkFBUSxHQUFSO1FBQ0ksSUFBSSxDQUFDLGNBQWMsR0FBRyxNQUFNLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxjQUFjLEVBQUUsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDO1FBQ3RFLElBQUksQ0FBQyxjQUFjLENBQUMsSUFBSSxDQUFDLFFBQVEsRUFBRSxPQUFPLENBQUMsQ0FBQztRQUM1QyxJQUFJLENBQUMsY0FBYyxDQUFDLElBQUksQ0FBQyxPQUFPLEVBQUUsU0FBUyxDQUFDLENBQUM7UUFDN0MsSUFBSSxDQUFDLGNBQWMsQ0FBQyxJQUFJLENBQUMsT0FBTyxFQUFFLFNBQVMsQ0FBQyxDQUFDO1FBRTdDLElBQUksQ0FBQyxlQUFlLEdBQUcsUUFBUSxDQUFDLEdBQUcsS0FBSyxLQUFLLENBQUMsQ0FBQyxDQUFDLGFBQWEsQ0FBQyxDQUFDLENBQUMsY0FBYyxDQUFDO0lBQ25GLENBQUM7SUFFRCxrQ0FBVyxHQUFYLFVBQVksY0FBNkI7UUFDckMsSUFBSSxjQUFjLENBQUMsY0FBYyxDQUFDLFVBQVUsQ0FBQyxJQUFJLENBQUMsY0FBYyxDQUFDLFVBQVUsQ0FBQyxDQUFDLFdBQVcsRUFBRTtZQUN0RixJQUFJLENBQUMsY0FBYyxDQUFDLGNBQWMsQ0FBQyxVQUFVLENBQUMsQ0FBQyxZQUFZLEVBQUUsT0FBTyxDQUFDLENBQUM7U0FDekU7UUFDRCxJQUFJLGNBQWMsQ0FBQyxjQUFjLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQyxjQUFjLENBQUMsU0FBUyxDQUFDLENBQUMsV0FBVyxFQUFFO1lBQ3BGLElBQUksQ0FBQyxjQUFjLENBQUMsY0FBYyxDQUFDLFNBQVMsQ0FBQyxDQUFDLFlBQVksRUFBRSxTQUFTLENBQUMsQ0FBQztTQUMxRTtRQUNELElBQUksY0FBYyxDQUFDLGNBQWMsQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDLGNBQWMsQ0FBQyxTQUFTLENBQUMsQ0FBQyxXQUFXLEVBQUU7WUFDcEYsSUFBSSxDQUFDLGNBQWMsQ0FBQyxjQUFjLENBQUMsU0FBUyxDQUFDLENBQUMsWUFBWSxFQUFFLFNBQVMsQ0FBQyxDQUFDO1NBQzFFO0lBQ0wsQ0FBQztJQUVNLGdDQUFTLEdBQWhCO1FBQ0ksSUFBSSxRQUFRLEdBQVEsTUFBTSxDQUFDLE1BQU0sQ0FBQyxFQUFFLEVBQUUsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDO1FBQ25ELElBQUksQ0FBQyxRQUFRLEdBQUcsRUFBRSxDQUFDO1FBQ25CLElBQUksQ0FBQyxRQUFRLENBQUMsSUFBSSxHQUFHLElBQUksQ0FBQyxXQUFXLENBQUMsUUFBUSxDQUFDLENBQUM7UUFDaEQsSUFBSSxDQUFDLFFBQVEsQ0FBQyxHQUFHLEdBQUcsUUFBUSxDQUFDO1FBQzdCLElBQUksQ0FBQyxVQUFVLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsQ0FBQztJQUN4QyxDQUFDO0lBRU8scUNBQWMsR0FBdEIsVUFBdUIsTUFBVyxFQUFFLE1BQWM7UUFDOUMsSUFBSSxXQUFXLEdBQVEsSUFBSSxDQUFDLGlCQUFpQixDQUFDLE1BQU0sQ0FBQyxDQUFDO1FBQ3RELElBQUksT0FBTyxXQUFXLEtBQUssV0FBVyxJQUFJLE1BQU0sS0FBSyxPQUFPLEVBQUU7WUFDMUQsSUFBSSxDQUFDLE1BQU0sR0FBRyxNQUFNLENBQUMsTUFBTSxDQUFDLEVBQUUsRUFBRSxXQUFXLENBQUMsQ0FBQztZQUM3QyxJQUFJLENBQUMsU0FBUyxFQUFFLENBQUM7U0FDcEI7YUFDSSxJQUFJLE1BQU0sS0FBSyxTQUFTLEVBQUU7WUFDM0IsSUFBSSxDQUFDLFFBQVEsR0FBRyxNQUFNLENBQUMsTUFBTSxDQUFDLEVBQUUsRUFBRSxXQUFXLENBQUMsQ0FBQztTQUNsRDthQUNJLElBQUksTUFBTSxLQUFLLFNBQVMsRUFBRTtZQUMzQixJQUFJLENBQUMsUUFBUSxHQUFHLE1BQU0sQ0FBQyxNQUFNLENBQUMsRUFBRSxFQUFFLFdBQVcsQ0FBQyxDQUFDO1NBQ2xEO0lBQ0wsQ0FBQztJQUVPLHdDQUFpQixHQUF6QixVQUEwQixNQUFXO1FBQ2pDLElBQUksT0FBTyxNQUFNLEtBQUssV0FBVyxJQUFJLE1BQU0sS0FBSyxFQUFFLElBQUksTUFBTSxLQUFLLElBQUksRUFBRTtZQUNuRSxJQUFJLE1BQU0sWUFBWSxNQUFNLElBQUksTUFBTSxDQUFDLGNBQWMsQ0FBQyxPQUFPLENBQUMsSUFBSSxNQUFNLENBQUMsY0FBYyxDQUFDLE1BQU0sQ0FBQyxJQUFJLE1BQU0sQ0FBQyxjQUFjLENBQUMsS0FBSyxDQUFDO2dCQUFFLE9BQU8sTUFBTSxDQUFDO2lCQUMxSSxJQUFJLE9BQU8sTUFBTSxLQUFLLFFBQVE7Z0JBQUUsT0FBTyxJQUFJLENBQUMsVUFBVSxDQUFDLE1BQU0sQ0FBQyxDQUFDO1NBQ3ZFO1FBQ0QsT0FBTyxTQUFTLENBQUM7SUFDckIsQ0FBQztJQUVELG1DQUFtQztJQUMzQixpQ0FBVSxHQUFsQixVQUFtQixTQUFpQjtRQUNoQyxJQUFJLFNBQVMsR0FBZSxTQUFTLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDO1FBQ2pELElBQUksVUFBVSxHQUFRO1lBQ2xCLElBQUksRUFBRSxRQUFRLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDO1lBQzVCLEtBQUssRUFBRSxRQUFRLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDO1lBQzdCLEdBQUcsRUFBRSxRQUFRLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDO1NBQzlCLENBQUM7UUFDRixPQUFPLFVBQVUsQ0FBQztJQUN0QixDQUFDO0lBRU8sa0NBQVcsR0FBbkIsVUFBb0IsUUFBYTtRQUM3QixJQUFJLElBQUksR0FBVywrQkFBK0IsQ0FBQztRQUNuRCxJQUFJLFFBQVEsS0FBSyxJQUFJO1lBQUUsSUFBSSxHQUFHLFFBQVEsQ0FBQyxJQUFJLEdBQUcsR0FBRyxHQUFHLFFBQVEsQ0FBQyxLQUFLLEdBQUcsR0FBRyxHQUFHLFFBQVEsQ0FBQyxHQUFHLENBQUM7UUFDeEYsT0FBTyxJQUFJLENBQUM7SUFDaEIsQ0FBQztJQXhFUTtRQUFSLEtBQUssRUFBRTs7a0RBQWU7SUFDZDtRQUFSLEtBQUssRUFBRTs7Z0RBQWE7SUFDWjtRQUFSLEtBQUssRUFBRTs7aURBQWM7SUFDYjtRQUFSLEtBQUssRUFBRTs7aURBQWM7SUFDWjtRQUFULE1BQU0sRUFBRTtrQ0FBYSxZQUFZO29EQUEyQjtJQWhCcEQsWUFBWTtRQVB4QixTQUFTLENBQUM7WUFDUCxRQUFRLEVBQUUsZUFBZTtZQUN6QixnckJBQTJDO1lBQzNDLGFBQWEsRUFBRSxpQkFBaUIsQ0FBQyxJQUFJO1lBQ3JDLElBQUksRUFBRyxFQUFFLE9BQU8sRUFBRyxvQkFBb0IsRUFBRTtTQUM1QyxDQUFDO09BRVcsWUFBWSxDQXFGeEI7SUFBRCxtQkFBQztDQUFBLEFBckZELElBcUZDO1NBckZZLFlBQVkiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQge1xyXG4gICAgQ29tcG9uZW50LFxyXG4gICAgVmlld0VuY2Fwc3VsYXRpb24sXHJcbiAgICBJbnB1dCxcclxuICAgIE9uSW5pdCxcclxuICAgIE9uQ2hhbmdlcyxcclxuICAgIFNpbXBsZUNoYW5nZXMsXHJcbiAgICBPdXRwdXQsXHJcbiAgICBFdmVudEVtaXR0ZXJcclxufSBmcm9tICdAYW5ndWxhci9jb3JlJztcclxuaW1wb3J0IHsgTmdiRGF0ZVN0cnVjdCB9IGZyb20gJ0BuZy1ib290c3RyYXAvbmctYm9vdHN0cmFwJztcclxuXHJcbkBDb21wb25lbnQoe1xyXG4gICAgc2VsZWN0b3I6ICdrZC1kYXRlcGlja2VyJyxcclxuICAgIHRlbXBsYXRlVXJsOiAnLi9rZC1hbmd1bGFyLWRhdGVwaWNrZXIuaHRtbCcsXHJcbiAgICBlbmNhcHN1bGF0aW9uOiBWaWV3RW5jYXBzdWxhdGlvbi5Ob25lLFxyXG4gICAgaG9zdCA6IHsgJ2NsYXNzJyA6ICdrZHgga2R4LWRhdGVwaWNrZXInIH1cclxufSlcclxuXHJcbmV4cG9ydCBjbGFzcyBLZERhdGVwaWNrZXIgaW1wbGVtZW50cyBPbkluaXQsIE9uQ2hhbmdlcyB7XHJcbiAgICBwdWJsaWMgX3VwZGF0ZWRDb25maWc6IGFueTtcclxuICAgIHB1YmxpYyBfbWluRGF0ZTogTmdiRGF0ZVN0cnVjdDtcclxuICAgIHB1YmxpYyBfbWF4RGF0ZTogTmdiRGF0ZVN0cnVjdDtcclxuICAgIHB1YmxpYyBfbW9kZWw6IGFueTtcclxuICAgIHB1YmxpYyBfcG9wdXBQbGFjZW1lbnQ6IHN0cmluZztcclxuXHJcbiAgICBwcml2YXRlIF9kZWZhdWx0Q29uZmlnOiBhbnkgPSB7XHJcbiAgICAgICAgZmlyc3REYXlPZldlZWs6IDdcclxuICAgIH07XHJcbiAgICBwcml2YXRlIF9lbWl0VmFsOiBhbnkgPSB7fTtcclxuXHJcbiAgICBASW5wdXQoKSBpbnB1dFZhbDogYW55O1xyXG4gICAgQElucHV0KCkgY29uZmlnOiBhbnk7XHJcbiAgICBASW5wdXQoKSBtaW5EYXRlOiBhbnk7XHJcbiAgICBASW5wdXQoKSBtYXhEYXRlOiBhbnk7XHJcbiAgICBAT3V0cHV0KCkgZGF0ZUNvbmZpZzogRXZlbnRFbWl0dGVyPGFueT4gPSBuZXcgRXZlbnRFbWl0dGVyKCk7XHJcblxyXG4gICAgbmdPbkluaXQoKTogdm9pZCB7XHJcbiAgICAgICAgdGhpcy5fdXBkYXRlZENvbmZpZyA9IE9iamVjdC5hc3NpZ24odGhpcy5fZGVmYXVsdENvbmZpZywgdGhpcy5jb25maWcpO1xyXG4gICAgICAgIHRoaXMuX2Fzc2lnblNldHRpbmcodGhpcy5pbnB1dFZhbCwgJ3ZhbHVlJyk7XHJcbiAgICAgICAgdGhpcy5fYXNzaWduU2V0dGluZyh0aGlzLm1pbkRhdGUsICdtaW5EYXRlJyk7XHJcbiAgICAgICAgdGhpcy5fYXNzaWduU2V0dGluZyh0aGlzLm1heERhdGUsICdtYXhEYXRlJyk7XHJcblxyXG4gICAgICAgIHRoaXMuX3BvcHVwUGxhY2VtZW50ID0gZG9jdW1lbnQuZGlyID09PSAncnRsJyA/ICdib3R0b20tbGVmdCcgOiAnYm90dG9tLXJpZ2h0JztcclxuICAgIH1cclxuXHJcbiAgICBuZ09uQ2hhbmdlcyhfc2ltcGxlQ2hhbmdlczogU2ltcGxlQ2hhbmdlcykge1xyXG4gICAgICAgIGlmIChfc2ltcGxlQ2hhbmdlcy5oYXNPd25Qcm9wZXJ0eSgnaW5wdXRWYWwnKSAmJiAhX3NpbXBsZUNoYW5nZXNbJ2lucHV0VmFsJ10uZmlyc3RDaGFuZ2UpIHtcclxuICAgICAgICAgICAgdGhpcy5fYXNzaWduU2V0dGluZyhfc2ltcGxlQ2hhbmdlc1snaW5wdXRWYWwnXS5jdXJyZW50VmFsdWUsICd2YWx1ZScpO1xyXG4gICAgICAgIH1cclxuICAgICAgICBpZiAoX3NpbXBsZUNoYW5nZXMuaGFzT3duUHJvcGVydHkoJ21pbkRhdGUnKSAmJiAhX3NpbXBsZUNoYW5nZXNbJ21pbkRhdGUnXS5maXJzdENoYW5nZSkge1xyXG4gICAgICAgICAgICB0aGlzLl9hc3NpZ25TZXR0aW5nKF9zaW1wbGVDaGFuZ2VzWydtaW5EYXRlJ10uY3VycmVudFZhbHVlLCAnbWluRGF0ZScpO1xyXG4gICAgICAgIH1cclxuICAgICAgICBpZiAoX3NpbXBsZUNoYW5nZXMuaGFzT3duUHJvcGVydHkoJ21heERhdGUnKSAmJiAhX3NpbXBsZUNoYW5nZXNbJ21heERhdGUnXS5maXJzdENoYW5nZSkge1xyXG4gICAgICAgICAgICB0aGlzLl9hc3NpZ25TZXR0aW5nKF9zaW1wbGVDaGFuZ2VzWydtYXhEYXRlJ10uY3VycmVudFZhbHVlLCAnbWF4RGF0ZScpO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICBwdWJsaWMgZW1pdFZhbHVlKCk6IHZvaWQge1xyXG4gICAgICAgIGxldCBuZXdNb2RlbDogYW55ID0gT2JqZWN0LmFzc2lnbih7fSwgdGhpcy5fbW9kZWwpO1xyXG4gICAgICAgIHRoaXMuX2VtaXRWYWwgPSB7fTtcclxuICAgICAgICB0aGlzLl9lbWl0VmFsLnRleHQgPSB0aGlzLl9mb3JtYXREYXRlKG5ld01vZGVsKTtcclxuICAgICAgICB0aGlzLl9lbWl0VmFsLm9iaiA9IG5ld01vZGVsO1xyXG4gICAgICAgIHRoaXMuZGF0ZUNvbmZpZy5lbWl0KHRoaXMuX2VtaXRWYWwpO1xyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX2Fzc2lnblNldHRpbmcoX3ZhbHVlOiBhbnksIF9tb2RlbDogc3RyaW5nKTogdm9pZCB7XHJcbiAgICAgICAgbGV0IHVwZGF0ZVZhbHVlOiBhbnkgPSB0aGlzLl9nZXROZ2JEYXRlU3RydWN0KF92YWx1ZSk7XHJcbiAgICAgICAgaWYgKHR5cGVvZiB1cGRhdGVWYWx1ZSAhPT0gJ3VuZGVmaW5lZCcgJiYgX21vZGVsID09PSAndmFsdWUnKSB7XHJcbiAgICAgICAgICAgIHRoaXMuX21vZGVsID0gT2JqZWN0LmFzc2lnbih7fSwgdXBkYXRlVmFsdWUpO1xyXG4gICAgICAgICAgICB0aGlzLmVtaXRWYWx1ZSgpO1xyXG4gICAgICAgIH1cclxuICAgICAgICBlbHNlIGlmIChfbW9kZWwgPT09ICdtaW5EYXRlJykge1xyXG4gICAgICAgICAgICB0aGlzLl9taW5EYXRlID0gT2JqZWN0LmFzc2lnbih7fSwgdXBkYXRlVmFsdWUpO1xyXG4gICAgICAgIH1cclxuICAgICAgICBlbHNlIGlmIChfbW9kZWwgPT09ICdtYXhEYXRlJykge1xyXG4gICAgICAgICAgICB0aGlzLl9tYXhEYXRlID0gT2JqZWN0LmFzc2lnbih7fSwgdXBkYXRlVmFsdWUpO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF9nZXROZ2JEYXRlU3RydWN0KF92YWx1ZTogYW55KTogYW55IHtcclxuICAgICAgICBpZiAodHlwZW9mIF92YWx1ZSAhPT0gJ3VuZGVmaW5lZCcgJiYgX3ZhbHVlICE9PSAnJyAmJiBfdmFsdWUgIT09IG51bGwpIHtcclxuICAgICAgICAgICAgaWYgKF92YWx1ZSBpbnN0YW5jZW9mIE9iamVjdCAmJiBfdmFsdWUuaGFzT3duUHJvcGVydHkoJ21vbnRoJykgJiYgX3ZhbHVlLmhhc093blByb3BlcnR5KCd5ZWFyJykgJiYgX3ZhbHVlLmhhc093blByb3BlcnR5KCdkYXknKSkgcmV0dXJuIF92YWx1ZTtcclxuICAgICAgICAgICAgZWxzZSBpZiAodHlwZW9mIF92YWx1ZSA9PT0gJ3N0cmluZycpIHJldHVybiB0aGlzLl9wYXJzZURhdGUoX3ZhbHVlKTtcclxuICAgICAgICB9XHJcbiAgICAgICAgcmV0dXJuIHVuZGVmaW5lZDtcclxuICAgIH1cclxuXHJcbiAgICAvLyB0byBiZSByZW1vdmVkIGFuZCB1c2UgbmF0aXZlIGFwaVxyXG4gICAgcHJpdmF0ZSBfcGFyc2VEYXRlKF90ZXh0RGF0ZTogc3RyaW5nKTogYW55IHtcclxuICAgICAgICBsZXQgc3BsaXREYXRlOiBBcnJheTxhbnk+ID0gX3RleHREYXRlLnNwbGl0KCctJyk7XHJcbiAgICAgICAgbGV0IHVwZGF0ZURhdGU6IGFueSA9IHtcclxuICAgICAgICAgICAgeWVhcjogcGFyc2VJbnQoc3BsaXREYXRlWzBdKSxcclxuICAgICAgICAgICAgbW9udGg6IHBhcnNlSW50KHNwbGl0RGF0ZVsxXSksXHJcbiAgICAgICAgICAgIGRheTogcGFyc2VJbnQoc3BsaXREYXRlWzJdKVxyXG4gICAgICAgIH07XHJcbiAgICAgICAgcmV0dXJuIHVwZGF0ZURhdGU7XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfZm9ybWF0RGF0ZShfb2JqRGF0ZTogYW55KTogc3RyaW5nIHtcclxuICAgICAgICBsZXQgZGF0ZTogc3RyaW5nID0gJ3VuZGVmaW5lZC11bmRlZmluZWQtdW5kZWZpbmVkJztcclxuICAgICAgICBpZiAoX29iakRhdGUgIT09IG51bGwpIGRhdGUgPSBfb2JqRGF0ZS55ZWFyICsgJy0nICsgX29iakRhdGUubW9udGggKyAnLScgKyBfb2JqRGF0ZS5kYXk7XHJcbiAgICAgICAgcmV0dXJuIGRhdGU7XHJcbiAgICB9XHJcbn1cclxuIl19