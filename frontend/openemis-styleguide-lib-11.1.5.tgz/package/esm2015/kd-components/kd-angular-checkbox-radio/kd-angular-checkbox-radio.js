import { Directive, Input, ViewContainerRef, } from '@angular/core';
export class KdCheckboxRadio {
    constructor(_vcr) {
        this._vcr = _vcr;
    }
    ngOnInit() {
        let currentEle = this._vcr.element.nativeElement;
        let warpper = document.createElement('div');
        warpper.className = 'selection-wrapper';
        currentEle.parentNode.insertBefore(warpper, currentEle);
        warpper.appendChild(currentEle);
        let label = document.createElement('label');
        if (typeof this.inputText !== 'undefined' && this.inputText !== '') {
            label.innerHTML = this.inputText;
        }
        warpper.appendChild(label);
    }
}
KdCheckboxRadio.decorators = [
    { type: Directive, args: [{
                selector: '[kd-checkbox-radio]'
            },] }
];
KdCheckboxRadio.ctorParameters = () => [
    { type: ViewContainerRef }
];
KdCheckboxRadio.propDecorators = {
    inputText: [{ type: Input, args: ['kd-checkbox-radio',] }]
};
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoia2QtYW5ndWxhci1jaGVja2JveC1yYWRpby5qcyIsInNvdXJjZVJvb3QiOiJDOi94YW1wcC9odGRvY3MvU3R5bGVndWlkZS9pb3N0Zy1vcGVuZW1pcy1zdHlsZWd1aWRlL3Byb2plY3RzL29wZW5lbWlzLXN0eWxlZ3VpZGUtbGliL3NyYy8iLCJzb3VyY2VzIjpbImtkLWNvbXBvbmVudHMva2QtYW5ndWxhci1jaGVja2JveC1yYWRpby9rZC1hbmd1bGFyLWNoZWNrYm94LXJhZGlvLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBLE9BQU8sRUFDSCxTQUFTLEVBRVQsS0FBSyxFQUNMLGdCQUFnQixHQUNuQixNQUFNLGVBQWUsQ0FBQztBQU12QixNQUFNLE9BQU8sZUFBZTtJQUd4QixZQUFvQixJQUFzQjtRQUF0QixTQUFJLEdBQUosSUFBSSxDQUFrQjtJQUFJLENBQUM7SUFFL0MsUUFBUTtRQUNKLElBQUksVUFBVSxHQUFHLElBQUksQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLGFBQWEsQ0FBQztRQUNqRCxJQUFJLE9BQU8sR0FBRyxRQUFRLENBQUMsYUFBYSxDQUFDLEtBQUssQ0FBQyxDQUFDO1FBQzVDLE9BQU8sQ0FBQyxTQUFTLEdBQUcsbUJBQW1CLENBQUM7UUFDeEMsVUFBVSxDQUFDLFVBQVUsQ0FBQyxZQUFZLENBQUMsT0FBTyxFQUFFLFVBQVUsQ0FBQyxDQUFDO1FBQ3hELE9BQU8sQ0FBQyxXQUFXLENBQUMsVUFBVSxDQUFDLENBQUM7UUFDaEMsSUFBSSxLQUFLLEdBQUcsUUFBUSxDQUFDLGFBQWEsQ0FBQyxPQUFPLENBQUMsQ0FBQztRQUM1QyxJQUFJLE9BQU8sSUFBSSxDQUFDLFNBQVMsS0FBSyxXQUFXLElBQUksSUFBSSxDQUFDLFNBQVMsS0FBSyxFQUFFLEVBQUU7WUFDaEUsS0FBSyxDQUFDLFNBQVMsR0FBRyxJQUFJLENBQUMsU0FBUyxDQUFDO1NBQ3BDO1FBQ0QsT0FBTyxDQUFDLFdBQVcsQ0FBQyxLQUFLLENBQUMsQ0FBQztJQUMvQixDQUFDOzs7WUFwQkosU0FBUyxTQUFDO2dCQUNQLFFBQVEsRUFBRSxxQkFBcUI7YUFDbEM7OztZQUxHLGdCQUFnQjs7O3dCQVFmLEtBQUssU0FBQyxtQkFBbUIiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQge1xyXG4gICAgRGlyZWN0aXZlLFxyXG4gICAgT25Jbml0LFxyXG4gICAgSW5wdXQsXHJcbiAgICBWaWV3Q29udGFpbmVyUmVmLFxyXG59IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xyXG5cclxuQERpcmVjdGl2ZSh7XHJcbiAgICBzZWxlY3RvcjogJ1trZC1jaGVja2JveC1yYWRpb10nXHJcbn0pXHJcblxyXG5leHBvcnQgY2xhc3MgS2RDaGVja2JveFJhZGlvIGltcGxlbWVudHMgT25Jbml0IHtcclxuICAgIEBJbnB1dCgna2QtY2hlY2tib3gtcmFkaW8nKSBpbnB1dFRleHQ6IHN0cmluZztcclxuXHJcbiAgICBjb25zdHJ1Y3Rvcihwcml2YXRlIF92Y3I6IFZpZXdDb250YWluZXJSZWYpIHsgfVxyXG5cclxuICAgIG5nT25Jbml0KCk6IHZvaWQge1xyXG4gICAgICAgIGxldCBjdXJyZW50RWxlID0gdGhpcy5fdmNyLmVsZW1lbnQubmF0aXZlRWxlbWVudDtcclxuICAgICAgICBsZXQgd2FycHBlciA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2RpdicpO1xyXG4gICAgICAgIHdhcnBwZXIuY2xhc3NOYW1lID0gJ3NlbGVjdGlvbi13cmFwcGVyJztcclxuICAgICAgICBjdXJyZW50RWxlLnBhcmVudE5vZGUuaW5zZXJ0QmVmb3JlKHdhcnBwZXIsIGN1cnJlbnRFbGUpO1xyXG4gICAgICAgIHdhcnBwZXIuYXBwZW5kQ2hpbGQoY3VycmVudEVsZSk7XHJcbiAgICAgICAgbGV0IGxhYmVsID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnbGFiZWwnKTtcclxuICAgICAgICBpZiAodHlwZW9mIHRoaXMuaW5wdXRUZXh0ICE9PSAndW5kZWZpbmVkJyAmJiB0aGlzLmlucHV0VGV4dCAhPT0gJycpIHtcclxuICAgICAgICAgICAgbGFiZWwuaW5uZXJIVE1MID0gdGhpcy5pbnB1dFRleHQ7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIHdhcnBwZXIuYXBwZW5kQ2hpbGQobGFiZWwpO1xyXG4gICAgfVxyXG59XHJcbiJdfQ==