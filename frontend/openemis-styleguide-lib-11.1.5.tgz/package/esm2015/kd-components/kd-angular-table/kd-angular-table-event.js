import { Injectable } from '@angular/core';
import { KdBroadcaster } from '../kd-common/index';
import * as i0 from "@angular/core";
import * as i1 from "../kd-common/kd-broadcaster-svc";
export class KdTableEvent {
    constructor(_broadcaster) {
        this._broadcaster = _broadcaster;
    }
    /// For any component using KdTable to capture all the informations KdTable emits
    onKdTableEventList(_gridId) {
        return this._broadcaster.on(_gridId + 'KdTableEvent');
    }
}
KdTableEvent.ɵprov = i0.ɵɵdefineInjectable({ factory: function KdTableEvent_Factory() { return new KdTableEvent(i0.ɵɵinject(i1.KdBroadcaster)); }, token: KdTableEvent, providedIn: "root" });
KdTableEvent.decorators = [
    { type: Injectable, args: [{
                providedIn: 'root'
            },] }
];
KdTableEvent.ctorParameters = () => [
    { type: KdBroadcaster }
];
export class KdIntTableEvent {
    constructor(_broadcaster) {
        this._broadcaster = _broadcaster;
    }
    /// Broadcast any events for components using KdTable
    kdTableEventList(_gridId, _event) {
        this._broadcaster.broadcast(_gridId + 'KdTableEvent', _event);
    }
    /// Used on kd-table-action.ts - For delete node params to update the row data accordingly
    updateEmitRowNodes(_gridId, _action, _rowData) {
        let data = {
            action: _action,
            rowData: _rowData
        };
        this._broadcaster.broadcast(_gridId + 'KdTableRowUpdated', data);
    }
    /// Used on kd-angular-table.ts - For update the delete node params in kd-table-action.ts
    onUpdateEmitRowNodes(_gridId) {
        return this._broadcaster.on(_gridId + 'KdTableRowUpdated');
    }
    /// Used on kd-table-checkbox-radio.ts - Checkbox / radio emit change event
    selectionChanged(_gridId, _data) {
        this._broadcaster.broadcast(_gridId + 'KdTableUpdateNodes', _data);
    }
    /// Used on kd-table-checkbox-radio.ts - To recheck the select all checkbox
    onSelectionChanged(_gridId) {
        return this._broadcaster.on(_gridId + 'KdTableUpdateNodes');
    }
    /// Used on kd-angular-table.ts - Emit on row data / model changed
    modelChanged(_gridId, _data) {
        this._broadcaster.broadcast(_gridId + 'KdModelUpdated', _data);
    }
    /// Used on kd-table-checkbox-radio.ts - To recheck the select all checkbox
    onModelChanged(_gridId) {
        return this._broadcaster.on(_gridId + 'KdModelUpdated');
    }
    /// Used on kd-table-input.ts - For emitting any form changes to output to dynamicForm
    inputChanged(_gridId, _data) {
        this._broadcaster.broadcast(_gridId + 'KdTableInputChanged', _data);
    }
    /// Used on kd-angular-table.ts - Capture the change params and emit to anyone using the output
    onInputChanged(_gridId) {
        return this._broadcaster.on(_gridId + 'KdTableInputChanged');
    }
}
KdIntTableEvent.decorators = [
    { type: Injectable }
];
KdIntTableEvent.ctorParameters = () => [
    { type: KdBroadcaster }
];
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoia2QtYW5ndWxhci10YWJsZS1ldmVudC5qcyIsInNvdXJjZVJvb3QiOiJDOi94YW1wcC9odGRvY3MvU3R5bGVndWlkZS9pb3N0Zy1vcGVuZW1pcy1zdHlsZWd1aWRlL3Byb2plY3RzL29wZW5lbWlzLXN0eWxlZ3VpZGUtbGliL3NyYy8iLCJzb3VyY2VzIjpbImtkLWNvbXBvbmVudHMva2QtYW5ndWxhci10YWJsZS9rZC1hbmd1bGFyLXRhYmxlLWV2ZW50LnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBLE9BQU8sRUFBRSxVQUFVLEVBQUUsTUFBTSxlQUFlLENBQUM7QUFFM0MsT0FBTyxFQUFFLGFBQWEsRUFBRSxNQUFNLG9CQUFvQixDQUFDOzs7QUFNbkQsTUFBTSxPQUFPLFlBQVk7SUFDckIsWUFDWSxZQUEyQjtRQUEzQixpQkFBWSxHQUFaLFlBQVksQ0FBZTtJQUNuQyxDQUFDO0lBRUwsaUZBQWlGO0lBQzFFLGtCQUFrQixDQUFDLE9BQWU7UUFDckMsT0FBTyxJQUFJLENBQUMsWUFBWSxDQUFDLEVBQUUsQ0FBTSxPQUFPLEdBQUcsY0FBYyxDQUFDLENBQUM7SUFDL0QsQ0FBQzs7OztZQVhKLFVBQVUsU0FBQztnQkFDUixVQUFVLEVBQUUsTUFBTTthQUNyQjs7O1lBTFEsYUFBYTs7QUFrQnRCLE1BQU0sT0FBTyxlQUFlO0lBQ3hCLFlBQ1ksWUFBMkI7UUFBM0IsaUJBQVksR0FBWixZQUFZLENBQWU7SUFDbkMsQ0FBQztJQUVMLHFEQUFxRDtJQUM5QyxnQkFBZ0IsQ0FBQyxPQUFlLEVBQUUsTUFBWTtRQUNqRCxJQUFJLENBQUMsWUFBWSxDQUFDLFNBQVMsQ0FBQyxPQUFPLEdBQUcsY0FBYyxFQUFFLE1BQU0sQ0FBQyxDQUFDO0lBQ2xFLENBQUM7SUFFRCwwRkFBMEY7SUFDbkYsa0JBQWtCLENBQUMsT0FBZSxFQUFFLE9BQWUsRUFBRSxRQUFhO1FBQ3JFLElBQUksSUFBSSxHQUFxQztZQUN6QyxNQUFNLEVBQUUsT0FBTztZQUNmLE9BQU8sRUFBRSxRQUFRO1NBQ3BCLENBQUM7UUFDRixJQUFJLENBQUMsWUFBWSxDQUFDLFNBQVMsQ0FBQyxPQUFPLEdBQUcsbUJBQW1CLEVBQUUsSUFBSSxDQUFDLENBQUM7SUFDckUsQ0FBQztJQUVELHlGQUF5RjtJQUNsRixvQkFBb0IsQ0FBQyxPQUFlO1FBQ3ZDLE9BQU8sSUFBSSxDQUFDLFlBQVksQ0FBQyxFQUFFLENBQU0sT0FBTyxHQUFHLG1CQUFtQixDQUFDLENBQUM7SUFDcEUsQ0FBQztJQUVELDJFQUEyRTtJQUNwRSxnQkFBZ0IsQ0FBQyxPQUFlLEVBQUUsS0FBVztRQUNoRCxJQUFJLENBQUMsWUFBWSxDQUFDLFNBQVMsQ0FBQyxPQUFPLEdBQUcsb0JBQW9CLEVBQUUsS0FBSyxDQUFDLENBQUM7SUFDdkUsQ0FBQztJQUVELDJFQUEyRTtJQUNwRSxrQkFBa0IsQ0FBQyxPQUFlO1FBQ3JDLE9BQU8sSUFBSSxDQUFDLFlBQVksQ0FBQyxFQUFFLENBQU0sT0FBTyxHQUFHLG9CQUFvQixDQUFDLENBQUM7SUFDckUsQ0FBQztJQUVELGtFQUFrRTtJQUMzRCxZQUFZLENBQUMsT0FBZSxFQUFFLEtBQVc7UUFDNUMsSUFBSSxDQUFDLFlBQVksQ0FBQyxTQUFTLENBQUMsT0FBTyxHQUFHLGdCQUFnQixFQUFFLEtBQUssQ0FBQyxDQUFDO0lBQ25FLENBQUM7SUFFRCwyRUFBMkU7SUFDcEUsY0FBYyxDQUFDLE9BQWU7UUFDakMsT0FBTyxJQUFJLENBQUMsWUFBWSxDQUFDLEVBQUUsQ0FBTSxPQUFPLEdBQUcsZ0JBQWdCLENBQUMsQ0FBQztJQUNqRSxDQUFDO0lBRUQsc0ZBQXNGO0lBQy9FLFlBQVksQ0FBQyxPQUFlLEVBQUUsS0FBd0I7UUFDekQsSUFBSSxDQUFDLFlBQVksQ0FBQyxTQUFTLENBQUMsT0FBTyxHQUFHLHFCQUFxQixFQUFFLEtBQUssQ0FBQyxDQUFDO0lBQ3hFLENBQUM7SUFFRCwrRkFBK0Y7SUFDeEYsY0FBYyxDQUFDLE9BQWU7UUFDakMsT0FBTyxJQUFJLENBQUMsWUFBWSxDQUFDLEVBQUUsQ0FBbUIsT0FBTyxHQUFHLHFCQUFxQixDQUFDLENBQUM7SUFDbkYsQ0FBQzs7O1lBckRKLFVBQVU7OztZQWpCRixhQUFhIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgSW5qZWN0YWJsZSB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xyXG5pbXBvcnQgeyBPYnNlcnZhYmxlIH0gZnJvbSAncnhqcyc7XHJcbmltcG9ydCB7IEtkQnJvYWRjYXN0ZXIgfSBmcm9tICcuLi9rZC1jb21tb24vaW5kZXgnO1xyXG5pbXBvcnQgeyBJVGFibGVGb3JtUGFyYW1zIH0gZnJvbSAnLi9rZC1hbmd1bGFyLXRhYmxlLWludGVyZmFjZSc7XHJcblxyXG5ASW5qZWN0YWJsZSh7XHJcbiAgICBwcm92aWRlZEluOiAncm9vdCdcclxufSlcclxuZXhwb3J0IGNsYXNzIEtkVGFibGVFdmVudCB7XHJcbiAgICBjb25zdHJ1Y3RvcihcclxuICAgICAgICBwcml2YXRlIF9icm9hZGNhc3RlcjogS2RCcm9hZGNhc3RlclxyXG4gICAgKSB7IH1cclxuXHJcbiAgICAvLy8gRm9yIGFueSBjb21wb25lbnQgdXNpbmcgS2RUYWJsZSB0byBjYXB0dXJlIGFsbCB0aGUgaW5mb3JtYXRpb25zIEtkVGFibGUgZW1pdHNcclxuICAgIHB1YmxpYyBvbktkVGFibGVFdmVudExpc3QoX2dyaWRJZDogc3RyaW5nKTogT2JzZXJ2YWJsZTxhbnk+IHtcclxuICAgICAgICByZXR1cm4gdGhpcy5fYnJvYWRjYXN0ZXIub248YW55PihfZ3JpZElkICsgJ0tkVGFibGVFdmVudCcpO1xyXG4gICAgfVxyXG59XHJcblxyXG5ASW5qZWN0YWJsZSgpXHJcbmV4cG9ydCBjbGFzcyBLZEludFRhYmxlRXZlbnQge1xyXG4gICAgY29uc3RydWN0b3IoXHJcbiAgICAgICAgcHJpdmF0ZSBfYnJvYWRjYXN0ZXI6IEtkQnJvYWRjYXN0ZXJcclxuICAgICkgeyB9XHJcblxyXG4gICAgLy8vIEJyb2FkY2FzdCBhbnkgZXZlbnRzIGZvciBjb21wb25lbnRzIHVzaW5nIEtkVGFibGVcclxuICAgIHB1YmxpYyBrZFRhYmxlRXZlbnRMaXN0KF9ncmlkSWQ6IHN0cmluZywgX2V2ZW50PzogYW55KTogdm9pZCB7XHJcbiAgICAgICAgdGhpcy5fYnJvYWRjYXN0ZXIuYnJvYWRjYXN0KF9ncmlkSWQgKyAnS2RUYWJsZUV2ZW50JywgX2V2ZW50KTtcclxuICAgIH1cclxuXHJcbiAgICAvLy8gVXNlZCBvbiBrZC10YWJsZS1hY3Rpb24udHMgLSBGb3IgZGVsZXRlIG5vZGUgcGFyYW1zIHRvIHVwZGF0ZSB0aGUgcm93IGRhdGEgYWNjb3JkaW5nbHlcclxuICAgIHB1YmxpYyB1cGRhdGVFbWl0Um93Tm9kZXMoX2dyaWRJZDogc3RyaW5nLCBfYWN0aW9uOiBzdHJpbmcsIF9yb3dEYXRhOiBhbnkpOiB2b2lkIHtcclxuICAgICAgICBsZXQgZGF0YTogeyBhY3Rpb246IHN0cmluZywgcm93RGF0YTogYW55IH0gPSB7XHJcbiAgICAgICAgICAgIGFjdGlvbjogX2FjdGlvbixcclxuICAgICAgICAgICAgcm93RGF0YTogX3Jvd0RhdGFcclxuICAgICAgICB9O1xyXG4gICAgICAgIHRoaXMuX2Jyb2FkY2FzdGVyLmJyb2FkY2FzdChfZ3JpZElkICsgJ0tkVGFibGVSb3dVcGRhdGVkJywgZGF0YSk7XHJcbiAgICB9XHJcblxyXG4gICAgLy8vIFVzZWQgb24ga2QtYW5ndWxhci10YWJsZS50cyAtIEZvciB1cGRhdGUgdGhlIGRlbGV0ZSBub2RlIHBhcmFtcyBpbiBrZC10YWJsZS1hY3Rpb24udHNcclxuICAgIHB1YmxpYyBvblVwZGF0ZUVtaXRSb3dOb2RlcyhfZ3JpZElkOiBzdHJpbmcpOiBPYnNlcnZhYmxlPGFueT4ge1xyXG4gICAgICAgIHJldHVybiB0aGlzLl9icm9hZGNhc3Rlci5vbjxhbnk+KF9ncmlkSWQgKyAnS2RUYWJsZVJvd1VwZGF0ZWQnKTtcclxuICAgIH1cclxuXHJcbiAgICAvLy8gVXNlZCBvbiBrZC10YWJsZS1jaGVja2JveC1yYWRpby50cyAtIENoZWNrYm94IC8gcmFkaW8gZW1pdCBjaGFuZ2UgZXZlbnRcclxuICAgIHB1YmxpYyBzZWxlY3Rpb25DaGFuZ2VkKF9ncmlkSWQ6IHN0cmluZywgX2RhdGE/OiBhbnkpOiB2b2lkIHtcclxuICAgICAgICB0aGlzLl9icm9hZGNhc3Rlci5icm9hZGNhc3QoX2dyaWRJZCArICdLZFRhYmxlVXBkYXRlTm9kZXMnLCBfZGF0YSk7XHJcbiAgICB9XHJcblxyXG4gICAgLy8vIFVzZWQgb24ga2QtdGFibGUtY2hlY2tib3gtcmFkaW8udHMgLSBUbyByZWNoZWNrIHRoZSBzZWxlY3QgYWxsIGNoZWNrYm94XHJcbiAgICBwdWJsaWMgb25TZWxlY3Rpb25DaGFuZ2VkKF9ncmlkSWQ6IHN0cmluZyk6IE9ic2VydmFibGU8YW55PiB7XHJcbiAgICAgICAgcmV0dXJuIHRoaXMuX2Jyb2FkY2FzdGVyLm9uPGFueT4oX2dyaWRJZCArICdLZFRhYmxlVXBkYXRlTm9kZXMnKTtcclxuICAgIH1cclxuXHJcbiAgICAvLy8gVXNlZCBvbiBrZC1hbmd1bGFyLXRhYmxlLnRzIC0gRW1pdCBvbiByb3cgZGF0YSAvIG1vZGVsIGNoYW5nZWRcclxuICAgIHB1YmxpYyBtb2RlbENoYW5nZWQoX2dyaWRJZDogc3RyaW5nLCBfZGF0YT86IGFueSk6IHZvaWQge1xyXG4gICAgICAgIHRoaXMuX2Jyb2FkY2FzdGVyLmJyb2FkY2FzdChfZ3JpZElkICsgJ0tkTW9kZWxVcGRhdGVkJywgX2RhdGEpO1xyXG4gICAgfVxyXG5cclxuICAgIC8vLyBVc2VkIG9uIGtkLXRhYmxlLWNoZWNrYm94LXJhZGlvLnRzIC0gVG8gcmVjaGVjayB0aGUgc2VsZWN0IGFsbCBjaGVja2JveFxyXG4gICAgcHVibGljIG9uTW9kZWxDaGFuZ2VkKF9ncmlkSWQ6IHN0cmluZyk6IE9ic2VydmFibGU8YW55PiB7XHJcbiAgICAgICAgcmV0dXJuIHRoaXMuX2Jyb2FkY2FzdGVyLm9uPGFueT4oX2dyaWRJZCArICdLZE1vZGVsVXBkYXRlZCcpO1xyXG4gICAgfVxyXG5cclxuICAgIC8vLyBVc2VkIG9uIGtkLXRhYmxlLWlucHV0LnRzIC0gRm9yIGVtaXR0aW5nIGFueSBmb3JtIGNoYW5nZXMgdG8gb3V0cHV0IHRvIGR5bmFtaWNGb3JtXHJcbiAgICBwdWJsaWMgaW5wdXRDaGFuZ2VkKF9ncmlkSWQ6IHN0cmluZywgX2RhdGE/OiBJVGFibGVGb3JtUGFyYW1zKTogdm9pZCB7XHJcbiAgICAgICAgdGhpcy5fYnJvYWRjYXN0ZXIuYnJvYWRjYXN0KF9ncmlkSWQgKyAnS2RUYWJsZUlucHV0Q2hhbmdlZCcsIF9kYXRhKTtcclxuICAgIH1cclxuXHJcbiAgICAvLy8gVXNlZCBvbiBrZC1hbmd1bGFyLXRhYmxlLnRzIC0gQ2FwdHVyZSB0aGUgY2hhbmdlIHBhcmFtcyBhbmQgZW1pdCB0byBhbnlvbmUgdXNpbmcgdGhlIG91dHB1dFxyXG4gICAgcHVibGljIG9uSW5wdXRDaGFuZ2VkKF9ncmlkSWQ6IHN0cmluZyk6IE9ic2VydmFibGU8SVRhYmxlRm9ybVBhcmFtcz4ge1xyXG4gICAgICAgIHJldHVybiB0aGlzLl9icm9hZGNhc3Rlci5vbjxJVGFibGVGb3JtUGFyYW1zPihfZ3JpZElkICsgJ0tkVGFibGVJbnB1dENoYW5nZWQnKTtcclxuICAgIH1cclxufVxyXG4iXX0=