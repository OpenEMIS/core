import { Component, ViewEncapsulation, Input, HostBinding, HostListener, ViewContainerRef, EventEmitter, Output } from '@angular/core';
import { Router } from '@angular/router';
import { Observable, timer } from 'rxjs';
import 'ag-grid-enterprise';
import * as XLSX from 'xlsx';
import { saveAs } from 'file-saver';
import { KdTableDatasourceEvent, KdTableSelectionUpdateEvent, KdTableInputUpdateEvent, KdTableButtonEvent } from './kd-angular-table-interface';
import { KdIntTableEvent } from './kd-angular-table-event';
import { KdTableNormalSvc } from './table-services/kd-table-normal-svc';
import { KdTableEnterpriseSvc } from './table-services/kd-table-enterprise-svc';
// import { KdSplitterEvent } from '../';
import { KdDomElemSvc, AG_GRID_KEY } from '../kd-common/index';
import { LicenseManager } from "ag-grid-enterprise";
/**
 * -- Documentation for kd-angular-table.ts (kd-table)
 *
 * - HostListener
 *     - onResize
 *
 * - Life cycles:
 *     - ngOnInit
 *     - ngOnChanges
 *     - ngOnDestroy

 * - ag-Grid events function:
 *     - onGridReady
 *     - onModelUpdated
 *     - onRowClicked
 *
 * - kd-table button function:
 *     - onButtonClicekd
 *
 * - Private functions:
 *     - Display / DOM functions:
 *         - _resizeColumn
 *         - _showLoadingOverlay
 *         - _updateParentNodeCSS
 *         - _setHeight
 *         - _setMobileHeight (flatten table)
 *         - _setWebHeighr (user configuration)
 *         - _isClickValid (click configuration)
 *
 *     - Grid Cycles:
 *         - _gridInitCycle
 *         - _gridReadyCycle
 *         - _gridReadyEnterpriseCycle
 *         - _gridReadyDOMCycle
 *         - _gridSelectionCycle
 *         - _gridSetRowCycle
 *         - _gridClickNavigateCycle
 *
 *     - Column / Row / Config generations/processing:
 *         - _setGridOptions
 *         - _setColumnDef
 *         - _setRowData
 *
 *     - Event functions:
 *         - _processEventParams<T>
 *         - _broadcastEventParams
 *         - _broadcastModelChanged
 *         - _setupSubscriptionEvents
 *
 *     - Selection functions:
 *         - _updateSelectionNodes
 *         - _processInitialSelection
 *
 *     - Input functions:
 *         - _processInputChanged
 *         - _emitInputUpdateEvent
 *         - _deleteNodeFromRowData
 *
 *     - Datasource functions:
 *         - _clearDatasource
 *         - _generateEnterpriseDatasource
 *         - _generateDatasourceRows
 *
 *     - API generations:
 *         - _initITableApi (TODO: update api setting all to table service)
 *
 *     - Misc functions:
 *         - _initGridService
 *         - _updateGridConfig
 */
export class KdTable {
    constructor(_vcr, _router, _domSvc, 
    // private _splitterEvent: KdSplitterEvent,
    _tableIntEvent) {
        this._vcr = _vcr;
        this._router = _router;
        this._domSvc = _domSvc;
        this._tableIntEvent = _tableIntEvent;
        this.gridId = '';
        this.displayLoading = true;
        this._enterprise = require('ag-grid-enterprise');
        this._subscriptionObj = {};
        this._currentState = {
            columnState: [],
            pivotMode: false,
            groupState: []
        };
        this._isChangingState = false;
        this._pivotElement = {
            'pivot': null,
            'column-drop': null
        };
        this._suppressMovableColumns = true;
        this._direction = 'ltr';
        // @Input() context: Context;
        // @Input() gridOption: GridOptions;
        this.onExportPossible = new EventEmitter();
        this._classKdxTable = true;
        LicenseManager.setLicenseKey(AG_GRID_KEY.value);
    }
    onResize(_event) {
        this._setHeight();
    }
    /************************* Life cycles functions *****************************/
    ngOnInit() {
        // console.log("-- Grid state: Init --", this.row, this.column, this.config, this.api);
        this._showLoadingOverlay(true);
        this._gridInitCycle();
    }
    ngOnChanges(_simpleChanges) {
        this._showLoadingOverlay(true);
        console.log("-- Grid state: Change -- ", _simpleChanges);
        if (typeof _simpleChanges.column !== 'undefined' &&
            !_simpleChanges.column.firstChange) {
            this._setColumnDef(_simpleChanges.column.currentValue);
            this._showLoadingOverlay(false);
        }
        if (typeof _simpleChanges.row !== 'undefined' &&
            !_simpleChanges.row.firstChange) {
            this._setRowData(_simpleChanges.row.currentValue);
            this._showLoadingOverlay(false);
        }
        if (typeof _simpleChanges.config !== 'undefined') {
            this._showLoadingOverlay(false);
            this.updateStyle(_simpleChanges.config.currentValue);
            timer(100).subscribe(() => {
                this._configurePivotDisplay();
                if (typeof this.config.suppressMovableColumns !== 'undefined') {
                    if (this.config.suppressMovableColumns !== this._suppressMovableColumns)
                        this._enableColumnMovable(this.config.suppressMovableColumns);
                }
                else {
                    this.config.suppressMovableColumns = this._suppressMovableColumns;
                }
            });
        }
    }
    ngOnDestroy() {
        // console.log("-- Grid state: Destroying --");
        for (let item in this._subscriptionObj) {
            if (typeof this._subscriptionObj[item] !== 'undefined') {
                this._subscriptionObj[item].unsubscribe();
            }
        }
    }
    setAttendance(displayEditTable, _config) {
        // let allColumns = this.gridOptions.columnApi.getAllColumns()
        // allColumns.forEach((column, index) => {
        //     let currentColumnDef = column.getColDef()
        //     console.log(`column ${index+1}`, currentColumnDef)
        // })
        if (displayEditTable) {
            this.gridOptions.context.mode = 'edit';
            _config.context.mode = 'edit';
            _config.rowContentHeight = 120;
        }
        else {
            this.gridOptions.context.mode = 'view';
            _config.context.mode = 'view';
        }
        let _columns = this.gridOptions.columnApi.getAllDisplayedColumns();
        // let colDef = _columns[2].getColDef()
        // console.log(colDef);
        // colDef.cellRendererParams = '<p>Hello</p>'
        // let newData = []
        // newData.push(colDef)
        this.gridOptions.columnApi.setValueColumns(_columns);
    }
    setAttendanceStaff(displayEditTable) {
        if (displayEditTable) {
            this.gridOptions.context.action = 'edit';
        }
        else {
            this.gridOptions.context.action = 'view';
        }
        let _columns = this.gridOptions.columnApi.getAllDisplayedColumns();
        this.gridOptions.columnApi.setValueColumns(_columns);
    }
    setStudentMeal(displayEditTable) {
        if (displayEditTable) {
            this.gridOptions.context.mode = 'edit';
        }
        else {
            this.gridOptions.context.mode = 'view';
        }
        let _columns = this.gridOptions.columnApi.getAllDisplayedColumns();
        this.gridOptions.columnApi.setValueColumns(_columns);
    }
    /******************************* Grid events *********************************/
    onGridReady(_params) {
        // console.log('-- Grid state: Ready --', this.gridOptions);
        this._gridReadyCycle();
    }
    onModelUpdated(_event) {
        /// For select all checkbox checking on change pagination/update row data
        if (this._tableService.hasSelectionAll(this.config)) {
            this._broadcastModelChangedEvent();
        }
        if (this._isMobileView) {
            let gridElement = document.querySelector('#' + this.gridId + '.stg-theme');
            if (gridElement !== null) {
                this._setMobileHeight(gridElement);
            }
        }
    }
    onRowClicked(_params) {
        // console.log("-- Grid state: Row clicked --", _params);
        if (this._isClickValid(_params.event) && typeof this.config.click !== 'undefined') {
            switch (this.config.click.type) {
                case 'selection':
                    this._gridSelectionCycle(_params.node);
                    break;
                case 'router':
                    this._gridClickNavigateCycle(_params.node);
                    break;
                default:
                    break;
            }
            if (typeof this.config.click.callback !== 'undefined') {
                this.config.click.callback();
            }
        }
    }
    /***************************** Button functions ******************************/
    onButtonClicked(_button) {
        let buttonEvent = new KdTableButtonEvent(_button);
        this._processEventParams('button', buttonEvent);
    }
    /**************************** Private functions ******************************/
    ////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// Grid cycles
    ////////////////////////////////////////////////////////////////////////////////////////////////////////
    _gridInitCycle() {
        if (typeof this.config !== 'undefined') {
            this._initGridService(this.config.loadType);
            this._updateGridConfig(this.config);
            this._setGridOptions(this.config);
            this._setupSubscriptionEvents();
        }
        if (typeof this.column !== 'undefined') {
            this._setColumnDef(this.column);
        }
        if (typeof this.row !== 'undefined') {
            this._setRowData(this.row);
        }
    }
    _gridReadyCycle() {
        this._initITableApi();
        if (this._tableService.isEnterpriseModel(this.config.loadType)) {
            this._gridReadyEnterpriseCycle();
        }
        this._gridReadyDOMCycle();
    }
    _gridReadyEnterpriseCycle() {
        this._clearDatasource();
        this._generateEnterpriseDatasource();
    }
    _gridReadyDOMCycle() {
        this._updateParentNodeCSS();
        this._setHeight();
        this._resizeColumn();
    }
    _gridSelectionCycle(_rowNode) {
        if (typeof this.config.selection === 'undefined') {
            console.error('KdTable error: User have set click type to be selection but no selection is defined. Do you mean click type to router?');
        }
        else if (this.config.selection.type === 'single') {
            if (this.config.selection.value.indexOf(_rowNode.id) < 0) {
                this.gridOptions.api.deselectAll();
                _rowNode.selectThisNode(true);
                this.config.selection.value.splice(0, this.config.selection.value.length);
                this.config.selection.value.push(_rowNode.data.id);
                this._broadcastModelChangedEvent();
                this._updateSelectionNodes(_rowNode);
            }
        }
        else {
            let selection = !_rowNode.isSelected();
            _rowNode.selectThisNode(selection);
            this._broadcastModelChangedEvent();
            if (selection) {
                this.config.selection.value.push(_rowNode.data.id);
            }
            else {
                this.config.selection.value.splice(this.config.selection.value.indexOf(_rowNode.data.id), 1);
            }
            this._updateSelectionNodes(_rowNode);
        }
    }
    _gridSetRowCycle() {
        if (typeof this.config.selection !== 'undefined' && typeof this.config.selection.type !== 'undefined') {
            this._processInitialSelection();
        }
        else if (this._tableService.hasInputType(this.column, 'input')) {
            this._emitInputUpdateEvent();
        }
    }
    _gridClickNavigateCycle(_rowNode) {
        if (typeof this.config.click.pathMap !== 'undefined') {
            if (typeof this.config.action !== 'undefined' &&
                typeof this.config.action.list !== 'undefined') {
                let routerPath = '';
                for (let i = 0; i < this.config.action.list.length; ++i) {
                    let actionItem = this.config.action.list[i];
                    if (actionItem.type.toLowerCase() === this.config.click.pathMap.toLowerCase()) {
                        routerPath = this._tableService.getRouterPlaceholderPath(_rowNode, actionItem.path);
                        break;
                    }
                }
                if (routerPath !== '') {
                    this._router.navigate([routerPath]);
                }
                else {
                    console.warn('KdTable warning: Table router pathMap not found. pathMap set to:', this.config.click.pathMap);
                }
            }
            else {
                console.error('KdTable error: Table click event set to router pathMap but no action list is defined. Do you mean path property instead of pathMap property?');
            }
        }
        else if (typeof this.config.click.path !== 'undefined') {
            this._router.navigate([this.config.click.path]);
        }
        else {
            console.error('KdTable error: Table click event type set at router but no path / pathMap is provided. Do you mean click type selection / none?');
        }
    }
    ////////////////////////////////////////////////////////////////////////////////////////////////////////
    // Display / DOM function
    ////////////////////////////////////////////////////////////////////////////////////////////////////////
    _showLoadingOverlay(_toggle) {
        this.displayLoading = _toggle;
    }
    _updateParentNodeCSS() {
        this._vcr.element.nativeElement.parentNode.className += ' has-aggrid';
        if (this._direction === 'rtl')
            document.querySelector('body').style.cssText += '--kdtable-header-text-align: right;';
    }
    _setHeight() {
        let domEleQuery = '#' + this.gridId + '.stg-theme';
        let gridElement = this._vcr.element.nativeElement.querySelector(domEleQuery);
        if (gridElement !== null) {
            let windowsWidth = document.body.clientWidth;
            if (windowsWidth <= 1024) {
                if (typeof this._isMobileView === 'undefined' || !this._isMobileView) {
                    this._showLoadingOverlay(true);
                    this._isMobileView = true;
                    this._setMobileHeight(gridElement);
                }
            }
            else if (windowsWidth > 1024) {
                if (typeof this._isMobileView === 'undefined' || this._isMobileView) {
                    this._showLoadingOverlay(true);
                    this._isMobileView = false;
                    this._setWebGridHeight(gridElement, this.config.gridHeight);
                }
                else {
                    this.gridOptions.api.sizeColumnsToFit();
                }
            }
        }
    }
    /**
     * add border bottom dynamically so that when the row is lesser than body-container, there wont be any hanging border bottom
     * when the row is more than container, there will be a border-bottom
     */
    _setTableBorderBottom() {
        let containerEleQuery = ' .ag-body-container';
        let containerEle = this._vcr.element.nativeElement.querySelector(containerEleQuery);
        if (containerEle === null)
            return;
        let viewportEleQuery = ' .ag-body-viewport';
        let viewportEle = this._vcr.element.nativeElement.querySelector(viewportEleQuery);
        if (containerEle.clientHeight > viewportEle.clientHeight &&
            viewportEle.className &&
            viewportEle.className.indexOf('has-border-bottom') === -1) {
            viewportEle.className += ' has-border-bottom';
        }
        else if (containerEle.clientHeight < viewportEle.clientHeight) {
            viewportEle.className = viewportEle.className.replace(/has-border-bottom/gi, '');
        }
    }
    _setMobileHeight(_gridElement) {
        let newHeight = 0;
        if (this.config.loadType !== 'infinite') {
            let agHeaderEle = this._vcr.element.nativeElement.querySelector('.ag-header');
            let agBodyEle = this._vcr.element.nativeElement.querySelector('.ag-body-container');
            let agPagePanelEle = this._vcr.element.nativeElement.querySelector('div[ref="south"]');
            newHeight = 25;
            if (agHeaderEle !== null) {
                newHeight += agHeaderEle.clientHeight;
            }
            if (agBodyEle !== null) {
                newHeight += agBodyEle.clientHeight;
            }
            if (agPagePanelEle !== null) {
                newHeight += agPagePanelEle.clientHeight;
            }
        }
        else {
            newHeight = 400;
        }
        this._domSvc.setElementStyle(_gridElement, 'height', newHeight + 'px');
        timer(10).subscribe(() => {
            this.gridOptions.api.sizeColumnsToFit();
            this._showLoadingOverlay(false);
        });
    }
    /**
     * [_setWebGridHeight number for pixel or string "auto"]
     *  _configHeight [description]
     */
    _setWebGridHeight(_gridElement, _configHeight) {
        if (typeof _configHeight === 'number') {
            let gridHeight = 600;
            if (typeof _configHeight !== 'undefined') {
                gridHeight = _configHeight;
            }
            this._domSvc.setElementStyle(_gridElement, 'height', gridHeight + 'px');
        }
        else if (_configHeight === 'auto') {
            this.displayFull = true;
        }
        // else if (_configHeight === 'rowHeight') {
        //     this.gridOptions.domLayout = 'autoHeight';
        //     delete this.gridOptions.rowHeight;
        //     delete this.gridOptions.getRowHeight;
        // }
        timer().subscribe(() => {
            this.gridOptions.api.sizeColumnsToFit();
            this._showLoadingOverlay(false);
        });
    }
    _isClickValid(_event) {
        let targetElement = _event.target;
        let invalidList = ['action-btn', 'checkbox-radio-input', 'fa-chevron-down'];
        for (let i = 0; i < invalidList.length; i++) {
            if (targetElement.classList.contains(invalidList[i])) {
                return false;
            }
        }
        return true;
    }
    _resizeColumn(_isResizeToContent = false) {
        if (this._tableService.isApiReady(this.gridOptions)) {
            timer(10).subscribe(() => {
                (_isResizeToContent) ? this._resizeColumnToContent() : this.gridOptions.api.sizeColumnsToFit();
                this.onExportPossible.emit(true);
                this._showLoadingOverlay(false);
            });
        }
    }
    /**
     * resize column to colDef width
     */
    _resizeColumnToContent() {
        let allColumnIds = [];
        this.gridOptions.columnApi.getAllDisplayedColumns().forEach((column) => {
            allColumnIds.push(column.getColId());
        });
        this.gridOptions.columnApi.autoSizeColumns(allColumnIds);
    }
    /**
     * populate dynamic styling value
     * param {ITableConfig} _config: tableConfig
     */
    updateStyle(_config) {
        if (!_config || !_config.config) {
            document.querySelector('body').style.cssText = '';
            return;
        }
        let config = _config.config;
        let bodyCss = '';
        bodyCss += this._updateHeaderStyle(config);
        if (config.body) {
            if (config.body.alternateRow === true) {
                if (config.body.odd && config.body.odd.backgroundColor) {
                    bodyCss += '--kdtable-row-odd-background: ' + config.body.odd.backgroundColor + ';';
                }
                if (config.body.even && config.body.even.backgroundColor) {
                    bodyCss += '--kdtable-row-even-background: ' + config.body.even.backgroundColor + ';';
                }
            }
            if (config.body.style) {
                if (config.body.style.borderWidth) {
                    bodyCss += '--kdtable-body-border-width: ' + config.body.style.borderWidth + ';';
                    bodyCss += '--kdtable-header-border-width: ' + config.body.style.borderWidth + ';';
                }
                if (config.body.style.borderColor) {
                    bodyCss += '--kdtable-body-border-color: ' + config.body.style.borderColor + ';';
                    bodyCss += '--kdtable-header-border-color: ' + config.body.style.borderColor + ';';
                }
                if (config.body.style.borderStyle) {
                    bodyCss += '--kdtable-body-border-style: ' + config.body.style.borderStyle + ';';
                    bodyCss += '--kdtable-header-border-style: ' + config.body.style.borderStyle + ';';
                }
            }
        }
        document.querySelector('body').style.cssText = bodyCss;
    }
    _updateHeaderStyle(_config) {
        if (!_config.header || !_config.header.style)
            return '';
        let bodyCss = '';
        let styleNames = [
            'backgroundColor',
            'textAlign',
            'verticalAlign',
            'color',
            'fontFamily',
            'fontSize',
            'fontWeight',
            'fontStyle',
            'textDecoration',
            // 'borderWidth',
            // 'borderColor',
            // 'borderStyle',
            'opacity'
        ];
        for (let i = 0; i < styleNames.length; ++i) {
            let styleName = styleNames[i];
            let value = _config.header.style[styleName];
            if (styleName === 'verticalAlign')
                value = this._getAlignItem(value);
            styleName = (styleName === 'backgroundColor') ? 'background' : styleName.replace(/([a-z])([A-Z])/g, '$1-$2').toLowerCase();
            if (typeof value !== 'undefined') {
                if (styleName === 'borderWidth' &&
                    (typeof value !== 'string' || value.indexOf('px') === -1))
                    value += 'px';
                bodyCss += '--kdtable-header-' + styleName + ': ' + value + ';';
            }
        }
        return bodyCss;
    }
    /**
     * convert text align into flex-box item align
     * param {string} _verticalAlign: text verticalAlign
     */
    _getAlignItem(_verticalAlign) {
        if (_verticalAlign === 'baseline' || _verticalAlign === 'bottom') {
            return 'flex-end';
        }
        else if (_verticalAlign === 'top') {
            return 'flex-start';
        }
        else { // including invalid input
            if (_verticalAlign !== 'middle' && _verticalAlign !== undefined) {
                console.warn('ERROR: the vertical align value of ' + _verticalAlign + ' is not yet recognised by KdTable. Please only use either top, center or bottom');
            }
            return 'center';
        }
    }
    // private _refreshTable(_tableCellParams?: ITableCellParams): void {
    //     if (this._tableService && this._tableService.isApiReady && this._tableService.isApiReady(this.gridOptions)) {
    //         let toUpdateNode: Array<RowNode> = [];
    //         let allColumnIds: Array<string> = [];
    //         if (!_tableCellParams) {
    //             this.gridOptions.columnApi.getAllDisplayedColumns().forEach((column) => {
    //                 allColumnIds.push(column.getColId());
    //             });
    //         }
    //         this.gridOptions.api.forEachNode((_rowNode: RowNode): void => {
    //             if (_tableCellParams && typeof _rowNode.id !== 'undefined' && _rowNode.id === _tableCellParams.rowId) {
    //                 _rowNode.data[_tableCellParams.colId] = _tableCellParams.data;
    //                 toUpdateNode.push(_rowNode);
    //             } else {
    //                 toUpdateNode.push(_rowNode);
    //             }
    //         });
    //         let refreshParams: { rowNodes: Array<RowNode>, columns: Array<any> } = {
    //             rowNodes: toUpdateNode,
    //             columns: (_tableCellParams) ? [_tableCellParams.colId] : allColumnIds
    //         };
    //         this.gridOptions.api.refreshCells(refreshParams);
    //     }
    // }
    ////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// Pivot Function
    ////////////////////////////////////////////////////////////////////////////////////////////////////////
    _isToolpanelTypeChanged() {
        let isTypeChanged = true;
        if (this._previousToolpanelType) {
            if (typeExist(this.config)) {
                isTypeChanged = this._previousToolpanelType !== this.config.pivot.toolpanel.type;
            }
        }
        else {
            if (typeExist(this.config)) {
                this._previousToolpanelType = this.config.pivot.toolpanel.type;
            }
        }
        return isTypeChanged;
        function typeExist(_config) {
            return _config && _config.pivot && _config.pivot.toolpanel && _config.pivot.toolpanel.type;
        }
    }
    _configurePivotDisplay() {
        let isStateChanged = true;
        if (this.config && this.config.pivot && this.config.pivot.state && this.config.pivot.state.columnState) {
            isStateChanged = this.config.pivot.state.columnState.length !== this._currentState.columnState.length;
        }
        if (this.config.loadType !== 'normal' || (this._isToolpanelTypeChanged() === false && isStateChanged === false))
            return;
        let showToolPanel = false;
        let showPivotMode = false;
        if (this.config.pivot && this.config.pivot.toolpanel) {
            showToolPanel = this.config.pivot.toolpanel.type !== 'none';
            showPivotMode = this.config.pivot.toolpanel.type === 'pivot';
        }
        this._showToolPanel(showToolPanel);
        this._showPivotMode(showPivotMode);
    }
    /**
     * resize column to fit table container if the width of the content column is smaller than container
     */
    _pivotResize() {
        let container = this._vcr.element.nativeElement.querySelector('.ag-header-container');
        let header = this._vcr.element.nativeElement.querySelector('.ag-header-container .ag-header-row');
        this._resizeColumn(header.getBoundingClientRect().width > container.getBoundingClientRect().width);
    }
    _resetPivotColumn() {
        this.gridOptions.columnApi.setRowGroupColumns([]);
        this.gridOptions.columnApi.setPivotColumns([]);
        this.gridOptions.columnApi.setValueColumns([]);
        this.gridOptions.columnApi.setSecondaryColumns([]);
    }
    /**
     * pass state to application.
     * (if setState was triggered before), wait until setState has done processing
     * return {ITablePivotState} [description]
     */
    _getPivotState() {
        // if state is changing, wait until state has been updated then get the most updated state
        let getState = () => {
            this._currentState.columnState = this.gridOptions.columnApi.getColumnState();
            this._currentState.pivotMode = this.gridOptions.columnApi.isPivotMode();
            this._currentState.groupState = this.gridOptions.columnApi.getColumnGroupState();
            return this._currentState;
        };
        let check = () => {
            return this._isChangingState === false;
        };
        return this.wait(check, getState);
    }
    /**
     * replace current state if a state is given, expandGroup base on config
     * should wait until column is present.
     * param {ITablePivotState} _state
     */
    _setPivotState(_state) {
        if (typeof (_state) === 'undefined' || !_state.hasOwnProperty('columnState'))
            return;
        let setState = () => {
            this._isChangingState = true;
            if (_state.columnState.length === 0) {
                this._isChangingState = false;
                this._pivotResize();
                return;
            }
            this._currentState = Object.assign(this._currentState, _state);
            this.gridOptions.columnApi.setColumnState(_state.columnState);
            this.gridOptions.columnApi.setPivotMode(_state.pivotMode || false);
            this.gridOptions.columnApi.setColumnGroupState(_state.groupState || []);
            this._isChangingState = false;
            timer(100).subscribe(() => {
                this._setPivotColumns();
                this._expandGroup();
            });
        };
        let check = () => {
            return this.column && this.column.length > 0;
        };
        this.wait(check, setState);
    }
    /**
     * wait for something to finish then do something, breaks at 100th to prevent infinite loop
     * param {ITablePivotState} _state
     * return {any}
     */
    wait(_check, _do, _limitCounter = 0) {
        if ((_check() && this._tableService.isApiReady(this.gridOptions)) || _limitCounter === 100) {
            if (_limitCounter === 100)
                console.log('Timeout: check fails. running', _do);
            return _do();
        }
        else {
            timer(10).subscribe(() => {
                _limitCounter++;
                this.wait(_check, _do, _limitCounter);
            });
        }
    }
    _isPivotElmExist(_pivotElement) {
        return (typeof _pivotElement['pivot'] !== 'undefined' &&
            _pivotElement['pivot'] !== null &&
            typeof _pivotElement['column-drop'] !== 'undefined' &&
            _pivotElement['column-drop'] !== null);
    }
    /**
     * show pivot mode checkbox and label.
     * when pivot mode is hidden, all pivot data has to be reset.
     * param {boolean = true} _show: true to show, false to hide
     */
    _showPivotMode(_show = true) {
        let setPivotMode = () => {
            if (_show === true) {
                this._pivotElement['pivot'].className = this._pivotElement['pivot'].className.replace(/ hidden/gi, '');
                for (let i = 0; i < this._pivotElement['column-drop'].length; ++i) {
                    this._pivotElement['column-drop'][i].className = this._pivotElement['column-drop'][i].className.replace(/ hidden/gi, '');
                }
                this._setPivotState(this.config.pivot && this.config.pivot.state ? this.config.pivot.state : {});
                return;
            }
            if (this._pivotElement['pivot'] &&
                this._pivotElement['pivot'].className &&
                this._pivotElement['pivot'].className.indexOf('hidden') === -1) {
                this._pivotElement['pivot'].className += ' hidden';
                for (let j = 0; j < this._pivotElement['column-drop'].length; ++j) {
                    this._pivotElement['column-drop'][j].className += ' hidden';
                }
            }
            this._enabledPivotMode(false);
            this._setPivotState({
                'columnState': [],
                'pivotMode': false,
                'groupState': []
            });
            this._resetPivotColumn();
        };
        let check = () => {
            // if (this.config.pivot.toolpanel.type === 'none' || !this.config.pivot || !this.config.pivot.toolpanel) return true;
            if (this.config.pivot &&
                this.config.pivot.toolpanel &&
                this.config.pivot.toolpanel.type &&
                this.config.pivot.toolpanel.type !== 'none') {
                let isPivotElmExist = this._isPivotElmExist(this._pivotElement);
                if (isPivotElmExist === true)
                    return isPivotElmExist;
                let domEleQuery = '#' + this.gridId + '.stg-theme .ag-side-bar';
                this._pivotElement['pivot'] = this._vcr.element.nativeElement.querySelector(domEleQuery + ' .ag-pivot-mode-panel');
                this._pivotElement['column-drop'] = this._vcr.element.nativeElement.querySelectorAll(domEleQuery + ' .ag-column-drop');
                return this._isPivotElmExist(this._pivotElement);
            }
            else {
                return true;
            }
        };
        this.wait(check, setPivotMode);
    }
    /**
     * hide and show toolpanel (pivot mode panel)
     * param {boolean} _show: true to show, false to hide
     */
    _showToolPanel(_show) {
        if (this._tableService.isApiReady(this.gridOptions)) {
            timer(10).subscribe(() => {
                this.gridOptions.api.showToolPanel(_show);
            });
        }
    }
    /**
     * expand row group base on the status that passed in
     * param {boolean} _expand: true to expand, false to collapse
     */
    _expandGroup(_expand) {
        if (typeof _expand === 'undefined') {
            _expand = false;
            if (this.config.pivot && this.config.pivot.state && this.config.pivot.state.expandGroup) {
                _expand = this.config.pivot.state.expandGroup;
            }
        }
        if (this._tableService.isApiReady(this.gridOptions)) {
            timer(10).subscribe(() => {
                (_expand) ? this.gridOptions.api.expandAll() : this.gridOptions.api.collapseAll();
                this._pivotResize();
            });
        }
    }
    /**
     * turn on and off pivot mode
     * If on, 'Column Label' will appear
     * If on, tick column name on toolpanel will assign column to 'Row Group' / 'Values' depends on colDef
     * If off, tick column name on toolpanel will trigger column hide and show
     * param {boolean = false} _enabled: true to check, false to uncheck
     */
    _enabledPivotMode(_enabled = false) {
        this.gridOptions.columnApi.setPivotMode(_enabled);
    }
    // TODO: to be revisit
    /**
     * suppressMovableColumns on pivotColumns and rowGroupColumns
     * columns on pivot mode does not listen to colDef.suppressMovableColumns = true
     * hence we need to access their private variable lockPosition and lockPinned to suppress the column movement
     * param {any} _columns [either passed in from gridEvent: column or will getAllDisplayedColumns]
     */
    _setPivotColumns(_columns) {
        let isPinned = false;
        if (!_columns)
            _columns = this.gridOptions.columnApi.getAllDisplayedColumns();
        _columns.forEach((column) => {
            this._setColumn(column);
            let columnDef = column.getColDef();
            if (columnDef.pivotValueColumn) {
                this._setColumn(columnDef.pivotValueColumn);
            }
            else {
                if (column.parent) {
                    isPinned = true;
                    this._setColumn(column.parent, false);
                    column.parent.pinned = 'left';
                    column.pinned = 'left';
                    columnDef.pinned = 'left';
                }
            }
        });
        if (isPinned)
            this._resizeColumn(true);
    }
    _setColumn(_column, _isSetColDef = true) {
        if (_isSetColDef) {
            let columnDef = _column.getColDef();
            columnDef.suppressMovable = this._suppressMovableColumns;
            columnDef.lockPosition = this._suppressMovableColumns;
            columnDef.lockPinned = this._suppressMovableColumns;
        }
        if (_column.setMoving) {
            _column.setMoving(!this._suppressMovableColumns);
        }
        else {
            _column.moving = !this._suppressMovableColumns;
        }
        _column.lockPosition = this._suppressMovableColumns;
        _column.lockPinned = this._suppressMovableColumns;
    }
    // TODO: to be revisit
    ////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// Column/Row/Configuration Generation
    ////////////////////////////////////////////////////////////////////////////////////////////////////////
    _setGridOptions(_tableConfig) {
        if (_tableConfig.hasOwnProperty('suppressMovableColumns'))
            this._suppressMovableColumns = _tableConfig.suppressMovableColumns;
        this._direction = this._domSvc.getDocumentDirection();
        this.gridOptions = this._tableService.generateGridOptions(_tableConfig, this._direction);
        this.gridOptions.context['gridId'] = this.gridId;
        this.gridOptions.suppressMovableColumns = false;
        this.gridOptions.onColumnRowGroupChanged = (params) => {
            this._setPivotColumns(params.columns);
            this._expandGroup();
        };
        this._tableService.setGridOptions(this.gridOptions);
    }
    _setColumnDef(_colDefConfig) {
        this._tableService.setColumnDef(_colDefConfig, this.config, this._suppressMovableColumns);
        this._resizeColumn();
    }
    _enableColumnMovable(_enabled = true) {
        if (this._tableService.isApiReady(this.gridOptions)) {
            this._suppressMovableColumns = _enabled;
            this._setColumnDef(this.column);
            if (this.config.loadType === 'normal' && this.config.pivot.toolpanel.type === 'pivot') {
                this._setPivotState(this._currentState);
            }
            this._pivotResize();
        }
    }
    _setRowData(_rowData, _setToGridOptions = true) {
        // this._tableService.updateRowDataWithColumnConfig(_rowData, this.column, this.gridId);
        this._tableService.updateRowDataWithColumn(_rowData, this.column, this.gridId, this.gridOptions);
        if (_setToGridOptions) {
            this._tableService.setRowData(_rowData);
        }
        if (this._tableService.isEnterpriseModel(this.config.loadType) && this._tableService.isApiReady(this.gridOptions)) {
            this._gridReadyEnterpriseCycle();
        }
        timer().subscribe(() => {
            this._gridSetRowCycle();
            this._setTableBorderBottom();
        });
    }
    ////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// Events - Subscriber / On functions
    ////////////////////////////////////////////////////////////////////////////////////////////////////////
    _processEventParams(_fromEvent, _additionalParams) {
        switch (_fromEvent) {
            case 'datasource':
            case 'selection':
            case 'input':
            case 'button':
                this._broadcastEventParams(_additionalParams);
                break;
            default:
                console.error('KdTable warning: No such event found for: ', _fromEvent);
        }
    }
    _broadcastEventParams(_params) {
        this._tableIntEvent.kdTableEventList(this.config.id, _params);
    }
    _broadcastModelChangedEvent() {
        this._tableIntEvent.modelChanged(this.config.id);
    }
    _setupSubscriptionEvents() {
        this._subscriptionObj.selectNodesSub = this._tableIntEvent.onSelectionChanged(this.config.id).subscribe((_rowNode) => {
            this._updateSelectionNodes(_rowNode);
        });
        this._subscriptionObj.gridQuestionSub = this._tableIntEvent.onInputChanged(this.config.id).subscribe((_formParams) => {
            this._processInputChanged(_formParams);
        });
        this._subscriptionObj.updateEmitRow = this._tableIntEvent.onUpdateEmitRowNodes(this.config.id).subscribe((_data) => {
            if (_data.action === 'delete') {
                let rowKey = (typeof this.config.rowIdKey !== 'undefined') ? this.config.rowIdKey : 'id';
                this._deleteNodeFromRowData([_data.rowData[rowKey]]);
                this._emitInputUpdateEvent();
            }
        });
    }
    ////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// Selection - Checkbox / Radio functions
    ////////////////////////////////////////////////////////////////////////////////////////////////////////
    _updateSelectionNodes(_rowNode, _isInitial) {
        let triggerNode = (typeof _isInitial !== 'undefined' && _isInitial) ? 'initial' : 'all';
        if (typeof _rowNode !== 'undefined') {
            triggerNode = _rowNode.data.id;
        }
        let selectionParams = new KdTableSelectionUpdateEvent();
        selectionParams.triggerNode = triggerNode;
        selectionParams.selectedNodes = this._tableService.updateSelectionValues(this.gridOptions.rowData, this.config.selection.value, this.config.selection.returnKey, this.config.loadType);
        // selectionParams.selection = (_rowNode.isSelected()) ? 'selected' : 'unselected';
        this._processEventParams('selection', selectionParams);
    }
    _processInitialSelection() {
        this._updateSelectionNodes(undefined, true);
    }
    ////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// Input functions
    ////////////////////////////////////////////////////////////////////////////////////////////////////////
    _processInputChanged(_formParams) {
        let inputParams = new KdTableInputUpdateEvent();
        inputParams.colId = _formParams.colId;
        inputParams.rowId = _formParams.rowId;
        inputParams.questionKey = _formParams.questionKey;
        inputParams.question = _formParams.question;
        inputParams.value = _formParams.data;
        this._processEventParams('input', inputParams);
    }
    _emitInputUpdateEvent() {
        let inputParams = new KdTableInputUpdateEvent();
        this._processEventParams('input', inputParams);
    }
    _deleteNodeFromRowData(_dataList) {
        let rowIdKey = (typeof this.config.rowIdKey !== 'undefined') ? this.config.rowIdKey : 'id';
        for (let i = 0; i < _dataList.length; ++i) {
            for (let j = 0; j < this.row.length; ++j) {
                if (_dataList[i].toString() === this.row[j][rowIdKey].toString()) {
                    this.row.splice(j, 1);
                    break;
                }
            }
        }
    }
    ////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// Enterprise datasource functions
    ////////////////////////////////////////////////////////////////////////////////////////////////////////
    _clearDatasource() {
        if (this._tableService.isApiReady(this.gridOptions)) {
            this.gridOptions.api.setEnterpriseDatasource(null);
            this.gridOptions.api.setFilterModel(null);
            this.gridOptions.api.setSortModel(null);
            if (typeof this._subscriptionObj.datasourceSub !== 'undefined') {
                this._subscriptionObj.datasourceSub.unsubscribe();
            }
        }
    }
    _generateEnterpriseDatasource() {
        let datasource = {
            getRows: (_params) => {
                this._showLoadingOverlay(true);
                if (typeof this._subscriptionObj.datasourceSub !== 'undefined') {
                    this._subscriptionObj.datasourceSub.unsubscribe();
                }
                this._subscriptionObj.datasourceSub = this._generateDatasourceRows(_params).subscribe((_response) => {
                    _params.successCallback(_response.rows, _response.total);
                    this._showLoadingOverlay(false);
                });
            }
        };
        this.gridOptions.api.setEnterpriseDatasource(datasource);
    }
    _generateDatasourceRows(_datasourceParams) {
        return new Observable((_observer) => {
            switch (this.config.loadType) {
                case 'infinite':
                case 'oneshot':
                    this._tableService.generateDatasourceRows(_datasourceParams.request, this.gridOptions.rowData.slice()).subscribe((_response) => {
                        _observer.next(_response);
                        _observer.complete();
                    });
                    break;
                case 'server':
                    let serverParams = new KdTableDatasourceEvent(_datasourceParams.request, _observer);
                    this._processEventParams('datasource', serverParams);
                    break;
                default:
                    console.error('KdTable warning: No such loadType find for: ', this.config.loadType);
                    _observer.complete();
            }
        });
    }
    ////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// API functions
    ////////////////////////////////////////////////////////////////////////////////////////////////////////
    _initITableApi() {
        if (typeof this.api !== 'undefined') {
            let apiParams = {
                // gridOptions: this.gridOptions,
                event: this._tableIntEvent,
                id: this.config.id,
                rows: this.row,
                columns: this.column
            };
            this._tableService.generatedApiFunctions(this.api, apiParams);
            /// Temp fix to access loading variable //
            /********* General API **********/
            this.api.general.showLoading = (_toggle) => {
                this.displayLoading = _toggle;
            };
            this.api.general.updateCell = (_tableCellParams) => {
                let toUpdateNode = [];
                this.gridOptions.api.forEachNode((_rowNode) => {
                    if (typeof _rowNode.id !== 'undefined' && _rowNode.id === _tableCellParams.rowId) {
                        _rowNode.data[_tableCellParams.colId] = _tableCellParams.data;
                        toUpdateNode.push(_rowNode);
                    }
                });
                let refreshParams = {
                    rowNodes: toUpdateNode,
                    columns: [_tableCellParams.colId]
                };
                this.gridOptions.api.refreshCells(refreshParams);
            };
            this.api.general.searchRow = (_searchText) => {
                if (this.config.loadType === 'normal') {
                    this.gridOptions.api.setQuickFilter(_searchText);
                }
                else {
                    console.warn('KdTable warning: Quick filtering of data is not supported for oneshot/server/infinite loadType.');
                }
            };
            this.api.general.addRows = (_rows, _scrollToVisible = false) => {
                /*
                    ag-Grid did not export RowDataTransaction interface. Interface as:
                        {
                            add: [],
                            remove: [],
                            update: []
                        }
                 */
                if (typeof this.config.loadType === 'undefined' || this.config.loadType === 'normal') {
                    let rowKey = (typeof this.config.rowIdKey !== 'undefined') ? this.config.rowIdKey : 'id';
                    for (let i = 0; i < _rows.length; ++i) {
                        this.row.push(_rows[i]);
                    }
                    this._setRowData(this.row, false);
                    this.gridOptions.api.updateRowData({ add: _rows.slice() });
                    if (_scrollToVisible) {
                        this.gridOptions.api.ensureIndexVisible(this.gridOptions.api.getRowNode(_rows[0][rowKey].toString()).rowIndex);
                    }
                }
                else {
                    console.warn('KdTable warning: API function: addRows() can only be used for normal loadType.');
                }
            };
            this.api.general.deleteRows = (_id) => {
                if (typeof this.config.loadType === 'undefined' || this.config.loadType === 'normal') {
                    let deleteIdList = [];
                    if (typeof _id === 'string' || typeof _id === 'number') {
                        deleteIdList.push(_id.toString());
                    }
                    else {
                        for (let i = 0; i < _id.length; ++i) {
                            deleteIdList.push(_id.toString());
                        }
                    }
                    this._deleteNodeFromRowData(deleteIdList);
                    let key = typeof this.config.rowIdKey === 'undefined' ? 'id' : this.config.rowIdKey;
                    let deleteRows = [];
                    for (let i = 0; i < deleteIdList.length; ++i) {
                        deleteRows.push({ [key]: deleteIdList[i] });
                    }
                    /*
                        ag-Grid did not export RowDataTransaction interface. Interface as:
                            {
                                add: [],
                                remove: [],
                                update: []
                            }
                     */
                    let transactionObj = {
                        remove: deleteRows
                    };
                    this.gridOptions.api.updateRowData(transactionObj);
                    this._emitInputUpdateEvent();
                }
                else {
                    console.warn('KdTable warning: API function: addRows() can only be used for normal loadType.');
                }
            };
            this.api.general.setButtonDisabled = (_buttonType, _toDisabled) => {
                for (let i = 0; i < this.config.button.length; ++i) {
                    if (this.config.button[i].type === _buttonType) {
                        this.config.button[i].disabled = _toDisabled;
                    }
                }
            };
            this.api.general.exportToExcel = (_params) => {
                let defaultParams = {
                    fileName: 'file',
                    allColumns: true,
                    suppressTextAsCDATA: true,
                };
                // xlsx only allow sheet name to be 31 characters long;
                if (_params.hasOwnProperty('sheetName'))
                    _params.sheetName = _params.sheetName.slice(0, 31);
                let params = Object.assign({}, defaultParams, _params);
                let content = this.gridOptions.api.getDataAsExcel(params);
                let workbook = XLSX.read(content, { type: 'binary' });
                let xlsxContent = XLSX.write(workbook, { bookType: 'xlsx', type: 'base64' });
                let blobObject = this._tableService.b64toBlob(xlsxContent, 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
                saveAs(blobObject, params.fileName + '.xlsx');
            };
            this.api.general.resizeColumn = (_isResizeToContent = false) => {
                this._resizeColumn(_isResizeToContent);
            };
            this.api.general.enableColumnMovable = (_enabled) => {
                this._enableColumnMovable(_enabled);
            };
            /********* Pivot API **********/
            if (typeof (this.api.pivot) === 'undefined')
                this.api.pivot = {};
            this.api.pivot.autoResize = () => {
                this._pivotResize();
            };
            this.api.pivot.showToolPanel = (_show) => {
                this._showToolPanel(_show);
            };
            this.api.pivot.expandGroup = (_expand) => {
                this._expandGroup(_expand);
            };
            this.api.pivot.getPivotState = () => {
                return this._getPivotState();
            };
            this.api.pivot.setPivotState = (_state) => {
                this._setColumnDef(this.column);
                this._setPivotState(_state);
            };
            this.api.pivot.enabledPivotMode = (_enabled) => {
                this._enabledPivotMode(_enabled);
            };
            this.api.pivot.showPivotMode = (_show) => {
                this._showPivotMode(_show);
            };
            /********* Input API **********/
            this.api.dynamicForm.clearAllError = () => {
                let tableContext = this.gridOptions.context[this._tableService.getTableContextKey()];
                for (let item in tableContext) {
                    if (tableContext.hasOwnProperty(item)) {
                        let contextItem = tableContext[item];
                        for (let question in contextItem) {
                            if (contextItem.hasOwnProperty(question)) {
                                if (typeof contextItem[question].errors === 'undefined') {
                                    contextItem[question].errors = [];
                                }
                                contextItem[question].errors.length = 0;
                            }
                        }
                    }
                }
            };
        }
        else {
            console.warn('KdTable warning: No api property / undefined api property is passed in.');
        }
    }
    ////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// Misc functions
    ////////////////////////////////////////////////////////////////////////////////////////////////////////
    _initGridService(_loadType) {
        if (typeof _loadType === 'undefined' || _loadType === 'normal') {
            this._tableService = new KdTableNormalSvc();
        }
        else {
            this._tableService = new KdTableEnterpriseSvc();
        }
    }
    _updateGridConfig(_gridConfig) {
        this.gridId = this._tableService.getGridId(_gridConfig);
        this._tableService.updateGridButtons(_gridConfig);
        this._tableService.updateSelectDefaultValue(_gridConfig);
    }
}
KdTable.decorators = [
    { type: Component, args: [{
                selector: 'kd-table',
                template: "<div class=\"kdx kdx-ag-grid-wrapper\">\r\n    <kd-progressloader *ngIf=\"displayLoading\" configtype=\"small-spinner\" [configvalue]=\"null\"></kd-progressloader>\r\n    <div *ngIf=\"config.button.length > 0\" class=\"gird-btn-wrapper\">\r\n        <button *ngFor=\"let item of config.button\" class=\"btn btn-icon\" type='button' [disabled]=\"item.disabled\" (click)=\"onButtonClicked(item)\">\r\n            <i [ngClass]=\"item.icon\"></i>\r\n            <span>{{item.label}}</span>\r\n        </button>\r\n    </div>\r\n    <ag-grid-angular\r\n    \t#agGrid\r\n    \tid=\"{{gridId}}\"\r\n    \tclass=\"stg-theme\"\r\n    \t[ngClass]=\"{'ag-row-clickable': config.click}\"\r\n        [gridOptions]=\"gridOptions\"\r\n        [rowDragManaged]=\"true\"\r\n        (gridReady)=\"onGridReady($event)\"\r\n        (modelUpdated)=\"onModelUpdated($event)\"\r\n        (rowClicked)=\"onRowClicked($event)\"\r\n    ></ag-grid-angular>\r\n</div>",
                encapsulation: ViewEncapsulation.None,
                providers: [KdDomElemSvc, KdIntTableEvent, KdTableNormalSvc, KdTableEnterpriseSvc],
                host: { 'class': 'kdx-table' }
            },] }
];
KdTable.ctorParameters = () => [
    { type: ViewContainerRef },
    { type: Router },
    { type: KdDomElemSvc },
    { type: KdIntTableEvent }
];
KdTable.propDecorators = {
    row: [{ type: Input }],
    column: [{ type: Input }],
    config: [{ type: Input }],
    api: [{ type: Input }],
    onExportPossible: [{ type: Output }],
    displayFull: [{ type: HostBinding, args: ['class.full-grid',] }],
    _classKdxTable: [{ type: HostBinding, args: ['class.kdx-table',] }],
    onResize: [{ type: HostListener, args: ['window:resize', ['$event'],] }]
};
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoia2QtYW5ndWxhci10YWJsZS5qcyIsInNvdXJjZVJvb3QiOiJDOi94YW1wcC9odGRvY3MvU3R5bGVndWlkZS9pb3N0Zy1vcGVuZW1pcy1zdHlsZWd1aWRlL3Byb2plY3RzL29wZW5lbWlzLXN0eWxlZ3VpZGUtbGliL3NyYy8iLCJzb3VyY2VzIjpbImtkLWNvbXBvbmVudHMva2QtYW5ndWxhci10YWJsZS9rZC1hbmd1bGFyLXRhYmxlLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBLE9BQU8sRUFDSCxTQUFTLEVBS1QsaUJBQWlCLEVBQ2pCLEtBQUssRUFDTCxXQUFXLEVBQ1gsWUFBWSxFQUNaLGdCQUFnQixFQUNoQixZQUFZLEVBQ1osTUFBTSxFQUNULE1BQU0sZUFBZSxDQUFDO0FBQ3ZCLE9BQU8sRUFBRSxNQUFNLEVBQUUsTUFBTSxpQkFBaUIsQ0FBQztBQUN6QyxPQUFPLEVBQUUsVUFBVSxFQUFFLEtBQUssRUFBNEIsTUFBTSxNQUFNLENBQUM7QUFrQm5FLE9BQU8sb0JBQW9CLENBQUM7QUFDNUIsT0FBTyxLQUFLLElBQUksTUFBTSxNQUFNLENBQUM7QUFDN0IsT0FBTyxFQUFFLE1BQU0sRUFBRSxNQUFNLFlBQVksQ0FBQztBQUVwQyxPQUFPLEVBV0gsc0JBQXNCLEVBQ3RCLDJCQUEyQixFQUMzQix1QkFBdUIsRUFDdkIsa0JBQWtCLEVBQ3JCLE1BQU0sOEJBQThCLENBQUM7QUFFdEMsT0FBTyxFQUFFLGVBQWUsRUFBRSxNQUFNLDBCQUEwQixDQUFDO0FBQzNELE9BQU8sRUFBRSxnQkFBZ0IsRUFBRSxNQUFNLHNDQUFzQyxDQUFDO0FBQ3hFLE9BQU8sRUFBRSxvQkFBb0IsRUFBRSxNQUFNLDBDQUEwQyxDQUFDO0FBQ2hGLHlDQUF5QztBQUN6QyxPQUFPLEVBQUUsWUFBWSxFQUFFLFdBQVcsRUFBRSxNQUFNLG9CQUFvQixDQUFDO0FBQy9ELE9BQU8sRUFBQyxjQUFjLEVBQUMsTUFBTSxvQkFBb0IsQ0FBQztBQUlsRDs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0dBcUVHO0FBWUgsTUFBTSxPQUFPLE9BQU87SUFxQ2hCLFlBQ1ksSUFBc0IsRUFDdEIsT0FBZSxFQUNmLE9BQXFCO0lBQzdCLDJDQUEyQztJQUNuQyxjQUErQjtRQUovQixTQUFJLEdBQUosSUFBSSxDQUFrQjtRQUN0QixZQUFPLEdBQVAsT0FBTyxDQUFRO1FBQ2YsWUFBTyxHQUFQLE9BQU8sQ0FBYztRQUVyQixtQkFBYyxHQUFkLGNBQWMsQ0FBaUI7UUF6Q3BDLFdBQU0sR0FBVyxFQUFFLENBQUM7UUFHcEIsbUJBQWMsR0FBWSxJQUFJLENBQUM7UUFFOUIsZ0JBQVcsR0FBRyxPQUFPLENBQUMsb0JBQW9CLENBQUMsQ0FBQztRQUc1QyxxQkFBZ0IsR0FBb0MsRUFBRSxDQUFDO1FBRXZELGtCQUFhLEdBQXFCO1lBQ3RDLFdBQVcsRUFBRSxFQUFFO1lBQ2YsU0FBUyxFQUFFLEtBQUs7WUFDaEIsVUFBVSxFQUFFLEVBQUU7U0FDakIsQ0FBQztRQUNNLHFCQUFnQixHQUFZLEtBQUssQ0FBQztRQUNsQyxrQkFBYSxHQUEyQjtZQUM1QyxPQUFPLEVBQUUsSUFBSTtZQUNiLGFBQWEsRUFBRSxJQUFJO1NBQ3RCLENBQUM7UUFFTSw0QkFBdUIsR0FBWSxJQUFJLENBQUM7UUFFeEMsZUFBVSxHQUFrQixLQUFLLENBQUM7UUFNMUMsNkJBQTZCO1FBQzdCLG9DQUFvQztRQUMxQixxQkFBZ0IsR0FBMEIsSUFBSSxZQUFZLEVBQUUsQ0FBQztRQUV2QyxtQkFBYyxHQUFZLElBQUksQ0FBQztRQVUzRCxjQUFjLENBQUMsYUFBYSxDQUFDLFdBQVcsQ0FBQyxLQUFLLENBQUMsQ0FBQztJQUNwRCxDQUFDO0lBR0QsUUFBUSxDQUFDLE1BQWE7UUFDbEIsSUFBSSxDQUFDLFVBQVUsRUFBRSxDQUFDO0lBQ3RCLENBQUM7SUFFRCwrRUFBK0U7SUFDL0UsUUFBUTtRQUNKLHVGQUF1RjtRQUN2RixJQUFJLENBQUMsbUJBQW1CLENBQUMsSUFBSSxDQUFDLENBQUM7UUFDL0IsSUFBSSxDQUFDLGNBQWMsRUFBRSxDQUFDO0lBQzFCLENBQUM7SUFFRCxXQUFXLENBQUMsY0FBNkI7UUFDckMsSUFBSSxDQUFDLG1CQUFtQixDQUFDLElBQUksQ0FBQyxDQUFDO1FBQy9CLE9BQU8sQ0FBQyxHQUFHLENBQUMsMkJBQTJCLEVBQUUsY0FBYyxDQUFDLENBQUM7UUFFekQsSUFBSSxPQUFPLGNBQWMsQ0FBQyxNQUFNLEtBQUssV0FBVztZQUM1QyxDQUFDLGNBQWMsQ0FBQyxNQUFNLENBQUMsV0FBVyxFQUNwQztZQUNFLElBQUksQ0FBQyxhQUFhLENBQUMsY0FBYyxDQUFDLE1BQU0sQ0FBQyxZQUFZLENBQUMsQ0FBQztZQUN2RCxJQUFJLENBQUMsbUJBQW1CLENBQUMsS0FBSyxDQUFDLENBQUM7U0FDbkM7UUFFRCxJQUFJLE9BQU8sY0FBYyxDQUFDLEdBQUcsS0FBSyxXQUFXO1lBQ3pDLENBQUMsY0FBYyxDQUFDLEdBQUcsQ0FBQyxXQUFXLEVBQ2pDO1lBQ0UsSUFBSSxDQUFDLFdBQVcsQ0FBQyxjQUFjLENBQUMsR0FBRyxDQUFDLFlBQVksQ0FBQyxDQUFDO1lBQ2xELElBQUksQ0FBQyxtQkFBbUIsQ0FBQyxLQUFLLENBQUMsQ0FBQztTQUNuQztRQUVELElBQUksT0FBTyxjQUFjLENBQUMsTUFBTSxLQUFLLFdBQVcsRUFBRTtZQUM5QyxJQUFJLENBQUMsbUJBQW1CLENBQUMsS0FBSyxDQUFDLENBQUM7WUFDaEMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxjQUFjLENBQUMsTUFBTSxDQUFDLFlBQVksQ0FBQyxDQUFDO1lBRXJELEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FBQyxTQUFTLENBQUMsR0FBUyxFQUFFO2dCQUM1QixJQUFJLENBQUMsc0JBQXNCLEVBQUUsQ0FBQztnQkFFOUIsSUFBSSxPQUFPLElBQUksQ0FBQyxNQUFNLENBQUMsc0JBQXNCLEtBQUssV0FBVyxFQUMzRDtvQkFDRSxJQUFJLElBQUksQ0FBQyxNQUFNLENBQUMsc0JBQXNCLEtBQUssSUFBSSxDQUFDLHVCQUF1Qjt3QkFDbkUsSUFBSSxDQUFDLG9CQUFvQixDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsc0JBQXNCLENBQUMsQ0FBQztpQkFDckU7cUJBQU07b0JBQ0gsSUFBSSxDQUFDLE1BQU0sQ0FBQyxzQkFBc0IsR0FBRyxJQUFJLENBQUMsdUJBQXVCLENBQUM7aUJBQ3JFO1lBQ0wsQ0FBQyxDQUFDLENBQUM7U0FDTjtJQUNMLENBQUM7SUFFRCxXQUFXO1FBQ1AsK0NBQStDO1FBQy9DLEtBQUssSUFBSSxJQUFJLElBQUksSUFBSSxDQUFDLGdCQUFnQixFQUFFO1lBQ3BDLElBQUksT0FBTyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsSUFBSSxDQUFDLEtBQUssV0FBVyxFQUFFO2dCQUNwRCxJQUFJLENBQUMsZ0JBQWdCLENBQUMsSUFBSSxDQUFDLENBQUMsV0FBVyxFQUFFLENBQUM7YUFDN0M7U0FDSjtJQUNMLENBQUM7SUFFRCxhQUFhLENBQUMsZ0JBQWdCLEVBQUUsT0FBcUI7UUFDakQsOERBQThEO1FBRTlELDBDQUEwQztRQUMxQyxnREFBZ0Q7UUFDaEQseURBQXlEO1FBQ3pELEtBQUs7UUFDTCxJQUFJLGdCQUFnQixFQUFFO1lBQ2xCLElBQUksQ0FBQyxXQUFXLENBQUMsT0FBTyxDQUFDLElBQUksR0FBRyxNQUFNLENBQUE7WUFDdEMsT0FBTyxDQUFDLE9BQU8sQ0FBQyxJQUFJLEdBQUcsTUFBTSxDQUFDO1lBQzlCLE9BQU8sQ0FBQyxnQkFBZ0IsR0FBRyxHQUFHLENBQUE7U0FDakM7YUFBTTtZQUNILElBQUksQ0FBQyxXQUFXLENBQUMsT0FBTyxDQUFDLElBQUksR0FBRyxNQUFNLENBQUE7WUFDdEMsT0FBTyxDQUFDLE9BQU8sQ0FBQyxJQUFJLEdBQUcsTUFBTSxDQUFDO1NBQ2pDO1FBRUQsSUFBSSxRQUFRLEdBQUcsSUFBSSxDQUFDLFdBQVcsQ0FBQyxTQUFTLENBQUMsc0JBQXNCLEVBQUUsQ0FBQztRQUNuRSx1Q0FBdUM7UUFDdkMsdUJBQXVCO1FBQ3ZCLDZDQUE2QztRQUM3QyxtQkFBbUI7UUFDbkIsdUJBQXVCO1FBQ3ZCLElBQUksQ0FBQyxXQUFXLENBQUMsU0FBUyxDQUFDLGVBQWUsQ0FBQyxRQUFRLENBQUMsQ0FBQTtJQUN4RCxDQUFDO0lBRUQsa0JBQWtCLENBQUMsZ0JBQWdCO1FBQy9CLElBQUksZ0JBQWdCLEVBQUU7WUFDbEIsSUFBSSxDQUFDLFdBQVcsQ0FBQyxPQUFPLENBQUMsTUFBTSxHQUFHLE1BQU0sQ0FBQztTQUM1QzthQUFLO1lBQ0YsSUFBSSxDQUFDLFdBQVcsQ0FBQyxPQUFPLENBQUMsTUFBTSxHQUFHLE1BQU0sQ0FBQztTQUM1QztRQUNELElBQUksUUFBUSxHQUFHLElBQUksQ0FBQyxXQUFXLENBQUMsU0FBUyxDQUFDLHNCQUFzQixFQUFFLENBQUM7UUFDbkUsSUFBSSxDQUFDLFdBQVcsQ0FBQyxTQUFTLENBQUMsZUFBZSxDQUFDLFFBQVEsQ0FBQyxDQUFBO0lBQ3hELENBQUM7SUFFRCxjQUFjLENBQUMsZ0JBQWdCO1FBQzNCLElBQUksZ0JBQWdCLEVBQUU7WUFDbEIsSUFBSSxDQUFDLFdBQVcsQ0FBQyxPQUFPLENBQUMsSUFBSSxHQUFHLE1BQU0sQ0FBQztTQUMxQzthQUFLO1lBQ0YsSUFBSSxDQUFDLFdBQVcsQ0FBQyxPQUFPLENBQUMsSUFBSSxHQUFHLE1BQU0sQ0FBQztTQUMxQztRQUNELElBQUksUUFBUSxHQUFHLElBQUksQ0FBQyxXQUFXLENBQUMsU0FBUyxDQUFDLHNCQUFzQixFQUFFLENBQUM7UUFDbkUsSUFBSSxDQUFDLFdBQVcsQ0FBQyxTQUFTLENBQUMsZUFBZSxDQUFDLFFBQVEsQ0FBQyxDQUFBO0lBQ3hELENBQUM7SUFFRCwrRUFBK0U7SUFDeEUsV0FBVyxDQUFDLE9BQVk7UUFDM0IsNERBQTREO1FBQzVELElBQUksQ0FBQyxlQUFlLEVBQUUsQ0FBQztJQUczQixDQUFDO0lBRU0sY0FBYyxDQUFDLE1BQXlCO1FBQzNDLHlFQUF5RTtRQUN6RSxJQUFJLElBQUksQ0FBQyxhQUFhLENBQUMsZUFBZSxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsRUFBRTtZQUNqRCxJQUFJLENBQUMsMkJBQTJCLEVBQUUsQ0FBQztTQUN0QztRQUVELElBQUksSUFBSSxDQUFDLGFBQWEsRUFBRTtZQUNwQixJQUFJLFdBQVcsR0FBWSxRQUFRLENBQUMsYUFBYSxDQUFDLEdBQUcsR0FBRyxJQUFJLENBQUMsTUFBTSxHQUFHLFlBQVksQ0FBQyxDQUFDO1lBRXBGLElBQUksV0FBVyxLQUFLLElBQUksRUFBRTtnQkFDdEIsSUFBSSxDQUFDLGdCQUFnQixDQUFDLFdBQVcsQ0FBQyxDQUFDO2FBQ3RDO1NBQ0o7SUFDTCxDQUFDO0lBRU0sWUFBWSxDQUFDLE9BQWlCO1FBQ2pDLHlEQUF5RDtRQUN6RCxJQUFJLElBQUksQ0FBQyxhQUFhLENBQUMsT0FBTyxDQUFDLEtBQUssQ0FBQyxJQUFJLE9BQU8sSUFBSSxDQUFDLE1BQU0sQ0FBQyxLQUFLLEtBQUssV0FBVyxFQUFFO1lBQy9FLFFBQVEsSUFBSSxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsSUFBSSxFQUFFO2dCQUM1QixLQUFLLFdBQVc7b0JBQ1osSUFBSSxDQUFDLG1CQUFtQixDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsQ0FBQztvQkFDdkMsTUFBTTtnQkFDVixLQUFLLFFBQVE7b0JBQ1QsSUFBSSxDQUFDLHVCQUF1QixDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsQ0FBQztvQkFDM0MsTUFBTTtnQkFDVjtvQkFDSSxNQUFNO2FBQ2I7WUFFRCxJQUFJLE9BQU8sSUFBSSxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsUUFBUSxLQUFLLFdBQVcsRUFBRTtnQkFDbkQsSUFBSSxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsUUFBUSxFQUFFLENBQUM7YUFDaEM7U0FDSjtJQUNMLENBQUM7SUFFRCwrRUFBK0U7SUFDeEUsZUFBZSxDQUFDLE9BQXFCO1FBQ3hDLElBQUksV0FBVyxHQUF1QixJQUFJLGtCQUFrQixDQUFDLE9BQU8sQ0FBQyxDQUFDO1FBQ3RFLElBQUksQ0FBQyxtQkFBbUIsQ0FBcUIsUUFBUSxFQUFFLFdBQVcsQ0FBQyxDQUFDO0lBQ3hFLENBQUM7SUFFRCwrRUFBK0U7SUFDL0Usd0dBQXdHO0lBQ3hHLGVBQWU7SUFDZix3R0FBd0c7SUFDaEcsY0FBYztRQUNsQixJQUFJLE9BQU8sSUFBSSxDQUFDLE1BQU0sS0FBSyxXQUFXLEVBQUU7WUFDcEMsSUFBSSxDQUFDLGdCQUFnQixDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsUUFBUSxDQUFDLENBQUM7WUFDNUMsSUFBSSxDQUFDLGlCQUFpQixDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQztZQUNwQyxJQUFJLENBQUMsZUFBZSxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQztZQUNsQyxJQUFJLENBQUMsd0JBQXdCLEVBQUUsQ0FBQztTQUNuQztRQUVELElBQUksT0FBTyxJQUFJLENBQUMsTUFBTSxLQUFLLFdBQVcsRUFBRTtZQUNwQyxJQUFJLENBQUMsYUFBYSxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQztTQUNuQztRQUVELElBQUksT0FBTyxJQUFJLENBQUMsR0FBRyxLQUFLLFdBQVcsRUFBRTtZQUNqQyxJQUFJLENBQUMsV0FBVyxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQztTQUM5QjtJQUNMLENBQUM7SUFFTyxlQUFlO1FBQ25CLElBQUksQ0FBQyxjQUFjLEVBQUUsQ0FBQztRQUV0QixJQUFJLElBQUksQ0FBQyxhQUFhLENBQUMsaUJBQWlCLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxRQUFRLENBQUMsRUFBRTtZQUM1RCxJQUFJLENBQUMseUJBQXlCLEVBQUUsQ0FBQztTQUNwQztRQUVELElBQUksQ0FBQyxrQkFBa0IsRUFBRSxDQUFDO0lBQzlCLENBQUM7SUFFTyx5QkFBeUI7UUFDN0IsSUFBSSxDQUFDLGdCQUFnQixFQUFFLENBQUM7UUFDeEIsSUFBSSxDQUFDLDZCQUE2QixFQUFFLENBQUM7SUFDekMsQ0FBQztJQUVPLGtCQUFrQjtRQUN0QixJQUFJLENBQUMsb0JBQW9CLEVBQUUsQ0FBQztRQUM1QixJQUFJLENBQUMsVUFBVSxFQUFFLENBQUM7UUFDbEIsSUFBSSxDQUFDLGFBQWEsRUFBRSxDQUFDO0lBQ3pCLENBQUM7SUFFTyxtQkFBbUIsQ0FBQyxRQUFpQjtRQUN6QyxJQUFJLE9BQU8sSUFBSSxDQUFDLE1BQU0sQ0FBQyxTQUFTLEtBQUssV0FBVyxFQUFFO1lBQzlDLE9BQU8sQ0FBQyxLQUFLLENBQUMsd0hBQXdILENBQUMsQ0FBQztTQUMzSTthQUNJLElBQUksSUFBSSxDQUFDLE1BQU0sQ0FBQyxTQUFTLENBQUMsSUFBSSxLQUFLLFFBQVEsRUFBRTtZQUM5QyxJQUFJLElBQUksQ0FBQyxNQUFNLENBQUMsU0FBUyxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsUUFBUSxDQUFDLEVBQUUsQ0FBQyxHQUFHLENBQUMsRUFBRTtnQkFDdEQsSUFBSSxDQUFDLFdBQVcsQ0FBQyxHQUFHLENBQUMsV0FBVyxFQUFFLENBQUM7Z0JBQ25DLFFBQVEsQ0FBQyxjQUFjLENBQUMsSUFBSSxDQUFDLENBQUM7Z0JBRTlCLElBQUksQ0FBQyxNQUFNLENBQUMsU0FBUyxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsQ0FBQyxFQUFFLElBQUksQ0FBQyxNQUFNLENBQUMsU0FBUyxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsQ0FBQztnQkFDMUUsSUFBSSxDQUFDLE1BQU0sQ0FBQyxTQUFTLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxDQUFDO2dCQUVuRCxJQUFJLENBQUMsMkJBQTJCLEVBQUUsQ0FBQztnQkFDbkMsSUFBSSxDQUFDLHFCQUFxQixDQUFDLFFBQVEsQ0FBQyxDQUFDO2FBQ3hDO1NBQ0o7YUFDSTtZQUNELElBQUksU0FBUyxHQUFZLENBQUMsUUFBUSxDQUFDLFVBQVUsRUFBRSxDQUFDO1lBQ2hELFFBQVEsQ0FBQyxjQUFjLENBQUMsU0FBUyxDQUFDLENBQUM7WUFFbkMsSUFBSSxDQUFDLDJCQUEyQixFQUFFLENBQUM7WUFFbkMsSUFBSSxTQUFTLEVBQUU7Z0JBQ1gsSUFBSSxDQUFDLE1BQU0sQ0FBQyxTQUFTLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxDQUFDO2FBQ3REO2lCQUNJO2dCQUNELElBQUksQ0FBQyxNQUFNLENBQUMsU0FBUyxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxTQUFTLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDO2FBQ2hHO1lBRUQsSUFBSSxDQUFDLHFCQUFxQixDQUFDLFFBQVEsQ0FBQyxDQUFDO1NBQ3hDO0lBQ0wsQ0FBQztJQUVPLGdCQUFnQjtRQUNwQixJQUFJLE9BQU8sSUFBSSxDQUFDLE1BQU0sQ0FBQyxTQUFTLEtBQUssV0FBVyxJQUFJLE9BQU8sSUFBSSxDQUFDLE1BQU0sQ0FBQyxTQUFTLENBQUMsSUFBSSxLQUFLLFdBQVcsRUFBRTtZQUNuRyxJQUFJLENBQUMsd0JBQXdCLEVBQUUsQ0FBQztTQUNuQzthQUVJLElBQUksSUFBSSxDQUFDLGFBQWEsQ0FBQyxZQUFZLENBQUMsSUFBSSxDQUFDLE1BQU0sRUFBRSxPQUFPLENBQUMsRUFBRTtZQUM1RCxJQUFJLENBQUMscUJBQXFCLEVBQUUsQ0FBQztTQUNoQztJQUNMLENBQUM7SUFFTyx1QkFBdUIsQ0FBQyxRQUFpQjtRQUM3QyxJQUFJLE9BQU8sSUFBSSxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsT0FBTyxLQUFLLFdBQVcsRUFBRTtZQUNsRCxJQUFJLE9BQU8sSUFBSSxDQUFDLE1BQU0sQ0FBQyxNQUFNLEtBQUssV0FBVztnQkFDekMsT0FBTyxJQUFJLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxJQUFJLEtBQUssV0FBVyxFQUFFO2dCQUNoRCxJQUFJLFVBQVUsR0FBVyxFQUFFLENBQUM7Z0JBRTVCLEtBQUssSUFBSSxDQUFDLEdBQVcsQ0FBQyxFQUFFLENBQUMsR0FBRyxJQUFJLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsTUFBTSxFQUFFLEVBQUUsQ0FBQyxFQUFFO29CQUM3RCxJQUFJLFVBQVUsR0FBeUIsSUFBSSxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDO29CQUVsRSxJQUFJLFVBQVUsQ0FBQyxJQUFJLENBQUMsV0FBVyxFQUFFLEtBQUssSUFBSSxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLFdBQVcsRUFBRSxFQUFFO3dCQUMzRSxVQUFVLEdBQUcsSUFBSSxDQUFDLGFBQWEsQ0FBQyx3QkFBd0IsQ0FBQyxRQUFRLEVBQUUsVUFBVSxDQUFDLElBQUksQ0FBQyxDQUFDO3dCQUNwRixNQUFNO3FCQUNUO2lCQUNKO2dCQUVELElBQUksVUFBVSxLQUFLLEVBQUUsRUFBRTtvQkFDbkIsSUFBSSxDQUFDLE9BQU8sQ0FBQyxRQUFRLENBQUMsQ0FBQyxVQUFVLENBQUMsQ0FBQyxDQUFDO2lCQUN2QztxQkFDSTtvQkFDRCxPQUFPLENBQUMsSUFBSSxDQUFDLGtFQUFrRSxFQUFFLElBQUksQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxDQUFDO2lCQUMvRzthQUNKO2lCQUNJO2dCQUNELE9BQU8sQ0FBQyxLQUFLLENBQUMsOElBQThJLENBQUMsQ0FBQzthQUNqSztTQUVKO2FBQ0ksSUFBSSxPQUFPLElBQUksQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLElBQUksS0FBSyxXQUFXLEVBQUU7WUFDcEQsSUFBSSxDQUFDLE9BQU8sQ0FBQyxRQUFRLENBQUMsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDO1NBQ25EO2FBQ0k7WUFDRCxPQUFPLENBQUMsS0FBSyxDQUFDLGlJQUFpSSxDQUFDLENBQUM7U0FDcEo7SUFDTCxDQUFDO0lBRUQsd0dBQXdHO0lBQ3hHLHlCQUF5QjtJQUN6Qix3R0FBd0c7SUFFaEcsbUJBQW1CLENBQUMsT0FBZ0I7UUFDeEMsSUFBSSxDQUFDLGNBQWMsR0FBRyxPQUFPLENBQUM7SUFDbEMsQ0FBQztJQUVPLG9CQUFvQjtRQUN4QixJQUFJLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxhQUFhLENBQUMsVUFBVSxDQUFDLFNBQVMsSUFBSSxhQUFhLENBQUM7UUFDdEUsSUFBSSxJQUFJLENBQUMsVUFBVSxLQUFLLEtBQUs7WUFBRSxRQUFRLENBQUMsYUFBYSxDQUFDLE1BQU0sQ0FBQyxDQUFDLEtBQUssQ0FBQyxPQUFPLElBQUkscUNBQXFDLENBQUM7SUFDekgsQ0FBQztJQUVPLFVBQVU7UUFDZCxJQUFJLFdBQVcsR0FBVyxHQUFHLEdBQUcsSUFBSSxDQUFDLE1BQU0sR0FBRyxZQUFZLENBQUM7UUFDM0QsSUFBSSxXQUFXLEdBQVksSUFBSSxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsYUFBYSxDQUFDLGFBQWEsQ0FBQyxXQUFXLENBQUMsQ0FBQztRQUV0RixJQUFJLFdBQVcsS0FBSyxJQUFJLEVBQUU7WUFDdEIsSUFBSSxZQUFZLEdBQVcsUUFBUSxDQUFDLElBQUksQ0FBQyxXQUFXLENBQUM7WUFFckQsSUFBSSxZQUFZLElBQUksSUFBSSxFQUFFO2dCQUN0QixJQUFJLE9BQU8sSUFBSSxDQUFDLGFBQWEsS0FBSyxXQUFXLElBQUksQ0FBQyxJQUFJLENBQUMsYUFBYSxFQUFFO29CQUNsRSxJQUFJLENBQUMsbUJBQW1CLENBQUMsSUFBSSxDQUFDLENBQUM7b0JBQy9CLElBQUksQ0FBQyxhQUFhLEdBQUcsSUFBSSxDQUFDO29CQUMxQixJQUFJLENBQUMsZ0JBQWdCLENBQUMsV0FBVyxDQUFDLENBQUM7aUJBQ3RDO2FBQ0o7aUJBQ0ksSUFBSSxZQUFZLEdBQUcsSUFBSSxFQUFFO2dCQUMxQixJQUFJLE9BQU8sSUFBSSxDQUFDLGFBQWEsS0FBSyxXQUFXLElBQUksSUFBSSxDQUFDLGFBQWEsRUFBRTtvQkFDakUsSUFBSSxDQUFDLG1CQUFtQixDQUFDLElBQUksQ0FBQyxDQUFDO29CQUMvQixJQUFJLENBQUMsYUFBYSxHQUFHLEtBQUssQ0FBQztvQkFDM0IsSUFBSSxDQUFDLGlCQUFpQixDQUFDLFdBQVcsRUFBRSxJQUFJLENBQUMsTUFBTSxDQUFDLFVBQVUsQ0FBQyxDQUFDO2lCQUMvRDtxQkFDSTtvQkFDRCxJQUFJLENBQUMsV0FBVyxDQUFDLEdBQUcsQ0FBQyxnQkFBZ0IsRUFBRSxDQUFDO2lCQUMzQzthQUNKO1NBQ0o7SUFDTCxDQUFDO0lBRUQ7OztPQUdHO0lBQ0sscUJBQXFCO1FBQ3pCLElBQUksaUJBQWlCLEdBQVcscUJBQXFCLENBQUM7UUFDdEQsSUFBSSxZQUFZLEdBQVksSUFBSSxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsYUFBYSxDQUFDLGFBQWEsQ0FBQyxpQkFBaUIsQ0FBQyxDQUFDO1FBQzdGLElBQUksWUFBWSxLQUFLLElBQUk7WUFBRSxPQUFPO1FBRWxDLElBQUksZ0JBQWdCLEdBQVcsb0JBQW9CLENBQUM7UUFDcEQsSUFBSSxXQUFXLEdBQVksSUFBSSxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsYUFBYSxDQUFDLGFBQWEsQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDO1FBRTNGLElBQUksWUFBWSxDQUFDLFlBQVksR0FBRyxXQUFXLENBQUMsWUFBWTtZQUNwRCxXQUFXLENBQUMsU0FBUztZQUNyQixXQUFXLENBQUMsU0FBUyxDQUFDLE9BQU8sQ0FBQyxtQkFBbUIsQ0FBQyxLQUFLLENBQUMsQ0FBQyxFQUMzRDtZQUNFLFdBQVcsQ0FBQyxTQUFTLElBQUksb0JBQW9CLENBQUM7U0FDakQ7YUFBTSxJQUFJLFlBQVksQ0FBQyxZQUFZLEdBQUcsV0FBVyxDQUFDLFlBQVksRUFBRTtZQUM3RCxXQUFXLENBQUMsU0FBUyxHQUFHLFdBQVcsQ0FBQyxTQUFTLENBQUMsT0FBTyxDQUFDLHFCQUFxQixFQUFFLEVBQUUsQ0FBQyxDQUFDO1NBQ3BGO0lBQ0wsQ0FBQztJQUVPLGdCQUFnQixDQUFDLFlBQXFCO1FBQzFDLElBQUksU0FBUyxHQUFXLENBQUMsQ0FBQztRQUUxQixJQUFJLElBQUksQ0FBQyxNQUFNLENBQUMsUUFBUSxLQUFLLFVBQVUsRUFBRTtZQUNyQyxJQUFJLFdBQVcsR0FBWSxJQUFJLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxhQUFhLENBQUMsYUFBYSxDQUFDLFlBQVksQ0FBQyxDQUFDO1lBQ3ZGLElBQUksU0FBUyxHQUFZLElBQUksQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLGFBQWEsQ0FBQyxhQUFhLENBQUMsb0JBQW9CLENBQUMsQ0FBQztZQUM3RixJQUFJLGNBQWMsR0FBWSxJQUFJLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxhQUFhLENBQUMsYUFBYSxDQUFDLGtCQUFrQixDQUFDLENBQUM7WUFDaEcsU0FBUyxHQUFHLEVBQUUsQ0FBQztZQUVmLElBQUksV0FBVyxLQUFLLElBQUksRUFBRTtnQkFDdEIsU0FBUyxJQUFJLFdBQVcsQ0FBQyxZQUFZLENBQUM7YUFDekM7WUFFRCxJQUFJLFNBQVMsS0FBSyxJQUFJLEVBQUU7Z0JBQ3BCLFNBQVMsSUFBSSxTQUFTLENBQUMsWUFBWSxDQUFDO2FBQ3ZDO1lBRUQsSUFBSSxjQUFjLEtBQUssSUFBSSxFQUFFO2dCQUN6QixTQUFTLElBQUksY0FBYyxDQUFDLFlBQVksQ0FBQzthQUM1QztTQUNKO2FBQ0k7WUFDRCxTQUFTLEdBQUcsR0FBRyxDQUFDO1NBQ25CO1FBR0QsSUFBSSxDQUFDLE9BQU8sQ0FBQyxlQUFlLENBQUMsWUFBWSxFQUFFLFFBQVEsRUFBRSxTQUFTLEdBQUcsSUFBSSxDQUFDLENBQUM7UUFFdkUsS0FBSyxDQUFDLEVBQUUsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxHQUFTLEVBQUU7WUFDM0IsSUFBSSxDQUFDLFdBQVcsQ0FBQyxHQUFHLENBQUMsZ0JBQWdCLEVBQUUsQ0FBQztZQUN4QyxJQUFJLENBQUMsbUJBQW1CLENBQUMsS0FBSyxDQUFDLENBQUM7UUFDcEMsQ0FBQyxDQUFDLENBQUM7SUFDUCxDQUFDO0lBRUQ7OztPQUdHO0lBQ0ssaUJBQWlCLENBQUMsWUFBcUIsRUFBRSxhQUE4QjtRQUMzRSxJQUFJLE9BQU8sYUFBYSxLQUFLLFFBQVEsRUFBRTtZQUNuQyxJQUFJLFVBQVUsR0FBVyxHQUFHLENBQUM7WUFFN0IsSUFBSSxPQUFPLGFBQWEsS0FBSyxXQUFXLEVBQUU7Z0JBQ3RDLFVBQVUsR0FBRyxhQUFhLENBQUM7YUFDOUI7WUFFRCxJQUFJLENBQUMsT0FBTyxDQUFDLGVBQWUsQ0FBQyxZQUFZLEVBQUUsUUFBUSxFQUFFLFVBQVUsR0FBRyxJQUFJLENBQUMsQ0FBQztTQUMzRTthQUNJLElBQUksYUFBYSxLQUFLLE1BQU0sRUFBRTtZQUMvQixJQUFJLENBQUMsV0FBVyxHQUFHLElBQUksQ0FBQztTQUMzQjtRQUNELDRDQUE0QztRQUM1QyxpREFBaUQ7UUFDakQseUNBQXlDO1FBQ3pDLDRDQUE0QztRQUM1QyxJQUFJO1FBRUosS0FBSyxFQUFFLENBQUMsU0FBUyxDQUFDLEdBQVMsRUFBRTtZQUN6QixJQUFJLENBQUMsV0FBVyxDQUFDLEdBQUcsQ0FBQyxnQkFBZ0IsRUFBRSxDQUFDO1lBQ3hDLElBQUksQ0FBQyxtQkFBbUIsQ0FBQyxLQUFLLENBQUMsQ0FBQztRQUNwQyxDQUFDLENBQUMsQ0FBQztJQUNQLENBQUM7SUFFTyxhQUFhLENBQUMsTUFBYTtRQUMvQixJQUFJLGFBQWEsR0FBNkIsTUFBTSxDQUFDLE1BQU0sQ0FBQztRQUM1RCxJQUFJLFdBQVcsR0FBa0IsQ0FBQyxZQUFZLEVBQUUsc0JBQXNCLEVBQUUsaUJBQWlCLENBQUMsQ0FBQztRQUUzRixLQUFLLElBQUksQ0FBQyxHQUFXLENBQUMsRUFBRSxDQUFDLEdBQUcsV0FBVyxDQUFDLE1BQU0sRUFBRSxDQUFDLEVBQUUsRUFBRTtZQUNqRCxJQUFJLGFBQWEsQ0FBQyxTQUFTLENBQUMsUUFBUSxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFO2dCQUNsRCxPQUFPLEtBQUssQ0FBQzthQUNoQjtTQUNKO1FBRUQsT0FBTyxJQUFJLENBQUM7SUFDaEIsQ0FBQztJQUVPLGFBQWEsQ0FBQyxxQkFBOEIsS0FBSztRQUNyRCxJQUFJLElBQUksQ0FBQyxhQUFhLENBQUMsVUFBVSxDQUFDLElBQUksQ0FBQyxXQUFXLENBQUMsRUFBRTtZQUNqRCxLQUFLLENBQUMsRUFBRSxDQUFDLENBQUMsU0FBUyxDQUFDLEdBQVMsRUFBRTtnQkFDM0IsQ0FBQyxrQkFBa0IsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsc0JBQXNCLEVBQUUsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxHQUFHLENBQUMsZ0JBQWdCLEVBQUUsQ0FBQztnQkFDL0YsSUFBSSxDQUFDLGdCQUFnQixDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQztnQkFDakMsSUFBSSxDQUFDLG1CQUFtQixDQUFDLEtBQUssQ0FBQyxDQUFDO1lBQ3BDLENBQUMsQ0FBQyxDQUFDO1NBQ047SUFDTCxDQUFDO0lBRUQ7O09BRUc7SUFDSyxzQkFBc0I7UUFDMUIsSUFBSSxZQUFZLEdBQWtCLEVBQUUsQ0FBQztRQUNyQyxJQUFJLENBQUMsV0FBVyxDQUFDLFNBQVMsQ0FBQyxzQkFBc0IsRUFBRSxDQUFDLE9BQU8sQ0FBQyxDQUFDLE1BQWMsRUFBRSxFQUFFO1lBQzNFLFlBQVksQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLFFBQVEsRUFBRSxDQUFDLENBQUM7UUFDekMsQ0FBQyxDQUFDLENBQUM7UUFDSCxJQUFJLENBQUMsV0FBVyxDQUFDLFNBQVMsQ0FBQyxlQUFlLENBQUMsWUFBWSxDQUFDLENBQUM7SUFDN0QsQ0FBQztJQUVEOzs7T0FHRztJQUNJLFdBQVcsQ0FBQyxPQUFxQjtRQUNwQyxJQUFJLENBQUMsT0FBTyxJQUFJLENBQUMsT0FBTyxDQUFDLE1BQU0sRUFBRTtZQUM3QixRQUFRLENBQUMsYUFBYSxDQUFDLE1BQU0sQ0FBQyxDQUFDLEtBQUssQ0FBQyxPQUFPLEdBQUcsRUFBRSxDQUFDO1lBQ2xELE9BQU87U0FDVjtRQUNELElBQUksTUFBTSxHQUFtQixPQUFPLENBQUMsTUFBTSxDQUFDO1FBRTVDLElBQUksT0FBTyxHQUFXLEVBQUUsQ0FBQztRQUV6QixPQUFPLElBQUksSUFBSSxDQUFDLGtCQUFrQixDQUFDLE1BQU0sQ0FBQyxDQUFDO1FBRTNDLElBQUksTUFBTSxDQUFDLElBQUksRUFBRTtZQUNiLElBQUksTUFBTSxDQUFDLElBQUksQ0FBQyxZQUFZLEtBQUssSUFBSSxFQUFFO2dCQUNuQyxJQUFJLE1BQU0sQ0FBQyxJQUFJLENBQUMsR0FBRyxJQUFJLE1BQU0sQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLGVBQWUsRUFBRTtvQkFDcEQsT0FBTyxJQUFJLGdDQUFnQyxHQUFHLE1BQU0sQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLGVBQWUsR0FBRyxHQUFHLENBQUM7aUJBQ3ZGO2dCQUNELElBQUksTUFBTSxDQUFDLElBQUksQ0FBQyxJQUFJLElBQUksTUFBTSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsZUFBZSxFQUFFO29CQUN0RCxPQUFPLElBQUksaUNBQWlDLEdBQUcsTUFBTSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsZUFBZSxHQUFHLEdBQUcsQ0FBQztpQkFDekY7YUFDSjtZQUNELElBQUksTUFBTSxDQUFDLElBQUksQ0FBQyxLQUFLLEVBQUU7Z0JBQ25CLElBQUksTUFBTSxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsV0FBVyxFQUFFO29CQUMvQixPQUFPLElBQUksK0JBQStCLEdBQUcsTUFBTSxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsV0FBVyxHQUFHLEdBQUcsQ0FBQztvQkFDakYsT0FBTyxJQUFJLGlDQUFpQyxHQUFHLE1BQU0sQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLFdBQVcsR0FBRyxHQUFHLENBQUM7aUJBQ3RGO2dCQUNELElBQUksTUFBTSxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsV0FBVyxFQUFFO29CQUMvQixPQUFPLElBQUksK0JBQStCLEdBQUcsTUFBTSxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsV0FBVyxHQUFHLEdBQUcsQ0FBQztvQkFDakYsT0FBTyxJQUFJLGlDQUFpQyxHQUFHLE1BQU0sQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLFdBQVcsR0FBRyxHQUFHLENBQUM7aUJBQ3RGO2dCQUNELElBQUksTUFBTSxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsV0FBVyxFQUFFO29CQUMvQixPQUFPLElBQUksK0JBQStCLEdBQUcsTUFBTSxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsV0FBVyxHQUFHLEdBQUcsQ0FBQztvQkFDakYsT0FBTyxJQUFJLGlDQUFpQyxHQUFHLE1BQU0sQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLFdBQVcsR0FBRyxHQUFHLENBQUM7aUJBQ3RGO2FBQ0o7U0FDSjtRQUVELFFBQVEsQ0FBQyxhQUFhLENBQUMsTUFBTSxDQUFDLENBQUMsS0FBSyxDQUFDLE9BQU8sR0FBRyxPQUFPLENBQUM7SUFDM0QsQ0FBQztJQUVPLGtCQUFrQixDQUFDLE9BQXVCO1FBQzlDLElBQUksQ0FBQyxPQUFPLENBQUMsTUFBTSxJQUFJLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxLQUFLO1lBQUUsT0FBTyxFQUFFLENBQUM7UUFFeEQsSUFBSSxPQUFPLEdBQVcsRUFBRSxDQUFDO1FBQ3pCLElBQUksVUFBVSxHQUFrQjtZQUM1QixpQkFBaUI7WUFDakIsV0FBVztZQUNYLGVBQWU7WUFDZixPQUFPO1lBQ1AsWUFBWTtZQUNaLFVBQVU7WUFDVixZQUFZO1lBQ1osV0FBVztZQUNYLGdCQUFnQjtZQUNoQixpQkFBaUI7WUFDakIsaUJBQWlCO1lBQ2pCLGlCQUFpQjtZQUNqQixTQUFTO1NBQ1osQ0FBQztRQUNGLEtBQUssSUFBSSxDQUFDLEdBQVcsQ0FBQyxFQUFFLENBQUMsR0FBRyxVQUFVLENBQUMsTUFBTSxFQUFFLEVBQUUsQ0FBQyxFQUFFO1lBQ2hELElBQUksU0FBUyxHQUFXLFVBQVUsQ0FBQyxDQUFDLENBQUMsQ0FBQztZQUN0QyxJQUFJLEtBQUssR0FBVyxPQUFPLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxTQUFTLENBQUMsQ0FBQztZQUNwRCxJQUFJLFNBQVMsS0FBSyxlQUFlO2dCQUFFLEtBQUssR0FBRyxJQUFJLENBQUMsYUFBYSxDQUFDLEtBQUssQ0FBQyxDQUFDO1lBQ3JFLFNBQVMsR0FBRyxDQUFDLFNBQVMsS0FBSyxpQkFBaUIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxZQUFZLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxPQUFPLENBQUMsaUJBQWlCLEVBQUUsT0FBTyxDQUFDLENBQUMsV0FBVyxFQUFFLENBQUM7WUFDM0gsSUFBSSxPQUFPLEtBQUssS0FBSyxXQUFXLEVBQUU7Z0JBQzlCLElBQUksU0FBUyxLQUFLLGFBQWE7b0JBQzNCLENBQUMsT0FBTyxLQUFLLEtBQUssUUFBUSxJQUFJLEtBQUssQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUM7b0JBQzNELEtBQUssSUFBSSxJQUFJLENBQUM7Z0JBQ2hCLE9BQU8sSUFBSSxtQkFBbUIsR0FBRyxTQUFTLEdBQUcsSUFBSSxHQUFHLEtBQUssR0FBRyxHQUFHLENBQUM7YUFDbkU7U0FDSjtRQUNELE9BQU8sT0FBTyxDQUFDO0lBQ25CLENBQUM7SUFFRDs7O09BR0c7SUFDSyxhQUFhLENBQUMsY0FBc0I7UUFDeEMsSUFBSSxjQUFjLEtBQUssVUFBVSxJQUFJLGNBQWMsS0FBSyxRQUFRLEVBQUU7WUFDOUQsT0FBTyxVQUFVLENBQUM7U0FDckI7YUFBTSxJQUFJLGNBQWMsS0FBSyxLQUFLLEVBQUU7WUFDakMsT0FBTyxZQUFZLENBQUM7U0FDdkI7YUFBTSxFQUFFLDBCQUEwQjtZQUMvQixJQUFJLGNBQWMsS0FBSyxRQUFRLElBQUksY0FBYyxLQUFLLFNBQVMsRUFBRTtnQkFDN0QsT0FBTyxDQUFDLElBQUksQ0FBQyxxQ0FBcUMsR0FBRyxjQUFjLEdBQUcsaUZBQWlGLENBQUMsQ0FBQzthQUM1SjtZQUNELE9BQU8sUUFBUSxDQUFDO1NBQ25CO0lBQ0wsQ0FBQztJQUVELHFFQUFxRTtJQUNyRSxvSEFBb0g7SUFDcEgsaURBQWlEO0lBQ2pELGdEQUFnRDtJQUVoRCxtQ0FBbUM7SUFDbkMsd0ZBQXdGO0lBQ3hGLHdEQUF3RDtJQUN4RCxrQkFBa0I7SUFDbEIsWUFBWTtJQUVaLDBFQUEwRTtJQUMxRSxzSEFBc0g7SUFDdEgsaUZBQWlGO0lBQ2pGLCtDQUErQztJQUMvQyx1QkFBdUI7SUFDdkIsK0NBQStDO0lBQy9DLGdCQUFnQjtJQUNoQixjQUFjO0lBRWQsbUZBQW1GO0lBQ25GLHNDQUFzQztJQUN0QyxvRkFBb0Y7SUFDcEYsYUFBYTtJQUViLDREQUE0RDtJQUM1RCxRQUFRO0lBQ1IsSUFBSTtJQUVKLHdHQUF3RztJQUN4RyxrQkFBa0I7SUFDbEIsd0dBQXdHO0lBQ2hHLHVCQUF1QjtRQUMzQixJQUFJLGFBQWEsR0FBWSxJQUFJLENBQUM7UUFDbEMsSUFBSSxJQUFJLENBQUMsc0JBQXNCLEVBQUU7WUFDN0IsSUFBSSxTQUFTLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxFQUFFO2dCQUN4QixhQUFhLEdBQUcsSUFBSSxDQUFDLHNCQUFzQixLQUFLLElBQUksQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUM7YUFDcEY7U0FDSjthQUFNO1lBQ0gsSUFBSSxTQUFTLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxFQUFFO2dCQUN4QixJQUFJLENBQUMsc0JBQXNCLEdBQUcsSUFBSSxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQzthQUNsRTtTQUNKO1FBQ0QsT0FBTyxhQUFhLENBQUM7UUFFckIsU0FBUyxTQUFTLENBQUMsT0FBTztZQUN0QixPQUFPLE9BQU8sSUFBSSxPQUFPLENBQUMsS0FBSyxJQUFJLE9BQU8sQ0FBQyxLQUFLLENBQUMsU0FBUyxJQUFJLE9BQU8sQ0FBQyxLQUFLLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQTtRQUM5RixDQUFDO0lBQ0wsQ0FBQztJQUVPLHNCQUFzQjtRQUMxQixJQUFJLGNBQWMsR0FBWSxJQUFJLENBQUM7UUFDbkMsSUFBSSxJQUFJLENBQUMsTUFBTSxJQUFJLElBQUksQ0FBQyxNQUFNLENBQUMsS0FBSyxJQUFJLElBQUksQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLEtBQUssSUFBSSxJQUFJLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsV0FBVyxFQUFFO1lBQ3BHLGNBQWMsR0FBRyxJQUFJLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsV0FBVyxDQUFDLE1BQU0sS0FBSyxJQUFJLENBQUMsYUFBYSxDQUFDLFdBQVcsQ0FBQyxNQUFNLENBQUM7U0FDekc7UUFDRCxJQUFJLElBQUksQ0FBQyxNQUFNLENBQUMsUUFBUSxLQUFLLFFBQVEsSUFBSSxDQUFDLElBQUksQ0FBQyx1QkFBdUIsRUFBRSxLQUFLLEtBQUssSUFBSSxjQUFjLEtBQUssS0FBSyxDQUFDO1lBQUUsT0FBTztRQUV4SCxJQUFJLGFBQWEsR0FBWSxLQUFLLENBQUM7UUFDbkMsSUFBSSxhQUFhLEdBQVksS0FBSyxDQUFDO1FBQ25DLElBQUksSUFBSSxDQUFDLE1BQU0sQ0FBQyxLQUFLLElBQUksSUFBSSxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsU0FBUyxFQUFFO1lBQ2xELGFBQWEsR0FBRyxJQUFJLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxTQUFTLENBQUMsSUFBSSxLQUFLLE1BQU0sQ0FBQztZQUM1RCxhQUFhLEdBQUcsSUFBSSxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsU0FBUyxDQUFDLElBQUksS0FBSyxPQUFPLENBQUM7U0FDaEU7UUFDRCxJQUFJLENBQUMsY0FBYyxDQUFDLGFBQWEsQ0FBQyxDQUFDO1FBQ25DLElBQUksQ0FBQyxjQUFjLENBQUMsYUFBYSxDQUFDLENBQUM7SUFDdkMsQ0FBQztJQUVEOztPQUVHO0lBQ0ssWUFBWTtRQUNoQixJQUFJLFNBQVMsR0FBWSxJQUFJLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxhQUFhLENBQUMsYUFBYSxDQUFDLHNCQUFzQixDQUFDLENBQUM7UUFDL0YsSUFBSSxNQUFNLEdBQVksSUFBSSxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsYUFBYSxDQUFDLGFBQWEsQ0FBQyxxQ0FBcUMsQ0FBQyxDQUFDO1FBRTNHLElBQUksQ0FBQyxhQUFhLENBQUMsTUFBTSxDQUFDLHFCQUFxQixFQUFFLENBQUMsS0FBSyxHQUFHLFNBQVMsQ0FBQyxxQkFBcUIsRUFBRSxDQUFDLEtBQUssQ0FBQyxDQUFDO0lBQ3ZHLENBQUM7SUFFTyxpQkFBaUI7UUFDckIsSUFBSSxDQUFDLFdBQVcsQ0FBQyxTQUFTLENBQUMsa0JBQWtCLENBQUMsRUFBRSxDQUFDLENBQUM7UUFDbEQsSUFBSSxDQUFDLFdBQVcsQ0FBQyxTQUFTLENBQUMsZUFBZSxDQUFDLEVBQUUsQ0FBQyxDQUFDO1FBQy9DLElBQUksQ0FBQyxXQUFXLENBQUMsU0FBUyxDQUFDLGVBQWUsQ0FBQyxFQUFFLENBQUMsQ0FBQztRQUMvQyxJQUFJLENBQUMsV0FBVyxDQUFDLFNBQVMsQ0FBQyxtQkFBbUIsQ0FBQyxFQUFFLENBQUMsQ0FBQztJQUN2RCxDQUFDO0lBRUQ7Ozs7T0FJRztJQUNLLGNBQWM7UUFDbEIsMEZBQTBGO1FBQzFGLElBQUksUUFBUSxHQUFHLEdBQVEsRUFBRTtZQUNyQixJQUFJLENBQUMsYUFBYSxDQUFDLFdBQVcsR0FBRyxJQUFJLENBQUMsV0FBVyxDQUFDLFNBQVMsQ0FBQyxjQUFjLEVBQUUsQ0FBQztZQUM3RSxJQUFJLENBQUMsYUFBYSxDQUFDLFNBQVMsR0FBRyxJQUFJLENBQUMsV0FBVyxDQUFDLFNBQVMsQ0FBQyxXQUFXLEVBQUUsQ0FBQztZQUN4RSxJQUFJLENBQUMsYUFBYSxDQUFDLFVBQVUsR0FBRyxJQUFJLENBQUMsV0FBVyxDQUFDLFNBQVMsQ0FBQyxtQkFBbUIsRUFBRSxDQUFDO1lBQ2pGLE9BQU8sSUFBSSxDQUFDLGFBQWEsQ0FBQztRQUM5QixDQUFDLENBQUM7UUFDRixJQUFJLEtBQUssR0FBRyxHQUFZLEVBQUU7WUFDdEIsT0FBTyxJQUFJLENBQUMsZ0JBQWdCLEtBQUssS0FBSyxDQUFDO1FBQzNDLENBQUMsQ0FBQztRQUNGLE9BQU8sSUFBSSxDQUFDLElBQUksQ0FBQyxLQUFLLEVBQUUsUUFBUSxDQUFDLENBQUM7SUFDdEMsQ0FBQztJQUVEOzs7O09BSUc7SUFDSyxjQUFjLENBQUMsTUFBd0I7UUFDM0MsSUFBSSxPQUFPLENBQUMsTUFBTSxDQUFDLEtBQUssV0FBVyxJQUFJLENBQUMsTUFBTSxDQUFDLGNBQWMsQ0FBQyxhQUFhLENBQUM7WUFBRSxPQUFPO1FBRXJGLElBQUksUUFBUSxHQUFHLEdBQVMsRUFBRTtZQUN0QixJQUFJLENBQUMsZ0JBQWdCLEdBQUcsSUFBSSxDQUFDO1lBQzdCLElBQUksTUFBTSxDQUFDLFdBQVcsQ0FBQyxNQUFNLEtBQUssQ0FBQyxFQUFFO2dCQUNqQyxJQUFJLENBQUMsZ0JBQWdCLEdBQUcsS0FBSyxDQUFDO2dCQUM5QixJQUFJLENBQUMsWUFBWSxFQUFFLENBQUM7Z0JBQ3BCLE9BQU87YUFDVjtZQUNELElBQUksQ0FBQyxhQUFhLEdBQUcsTUFBTSxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsYUFBYSxFQUFFLE1BQU0sQ0FBQyxDQUFDO1lBQy9ELElBQUksQ0FBQyxXQUFXLENBQUMsU0FBUyxDQUFDLGNBQWMsQ0FBQyxNQUFNLENBQUMsV0FBVyxDQUFDLENBQUM7WUFDOUQsSUFBSSxDQUFDLFdBQVcsQ0FBQyxTQUFTLENBQUMsWUFBWSxDQUFDLE1BQU0sQ0FBQyxTQUFTLElBQUksS0FBSyxDQUFDLENBQUM7WUFDbkUsSUFBSSxDQUFDLFdBQVcsQ0FBQyxTQUFTLENBQUMsbUJBQW1CLENBQUMsTUFBTSxDQUFDLFVBQVUsSUFBSSxFQUFFLENBQUMsQ0FBQztZQUN4RSxJQUFJLENBQUMsZ0JBQWdCLEdBQUcsS0FBSyxDQUFDO1lBRTlCLEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FBQyxTQUFTLENBQUMsR0FBUyxFQUFFO2dCQUM1QixJQUFJLENBQUMsZ0JBQWdCLEVBQUUsQ0FBQztnQkFDeEIsSUFBSSxDQUFDLFlBQVksRUFBRSxDQUFDO1lBQ3hCLENBQUMsQ0FBQyxDQUFDO1FBQ1AsQ0FBQyxDQUFDO1FBQ0YsSUFBSSxLQUFLLEdBQUcsR0FBWSxFQUFFO1lBQ3RCLE9BQU8sSUFBSSxDQUFDLE1BQU0sSUFBSSxJQUFJLENBQUMsTUFBTSxDQUFDLE1BQU0sR0FBRyxDQUFDLENBQUM7UUFDakQsQ0FBQyxDQUFDO1FBQ0YsSUFBSSxDQUFDLElBQUksQ0FBQyxLQUFLLEVBQUUsUUFBUSxDQUFDLENBQUM7SUFDL0IsQ0FBQztJQUVEOzs7O09BSUc7SUFDSyxJQUFJLENBQUMsTUFBZ0IsRUFBRSxHQUFhLEVBQUUsYUFBYSxHQUFHLENBQUM7UUFDM0QsSUFBSSxDQUFDLE1BQU0sRUFBRSxJQUFJLElBQUksQ0FBQyxhQUFhLENBQUMsVUFBVSxDQUFDLElBQUksQ0FBQyxXQUFXLENBQUMsQ0FBQyxJQUFJLGFBQWEsS0FBSyxHQUFHLEVBQUU7WUFDeEYsSUFBSSxhQUFhLEtBQUssR0FBRztnQkFBRSxPQUFPLENBQUMsR0FBRyxDQUFDLCtCQUErQixFQUFFLEdBQUcsQ0FBQyxDQUFDO1lBQzdFLE9BQU8sR0FBRyxFQUFFLENBQUM7U0FDaEI7YUFBTTtZQUNILEtBQUssQ0FBQyxFQUFFLENBQUMsQ0FBQyxTQUFTLENBQUMsR0FBUyxFQUFFO2dCQUMzQixhQUFhLEVBQUUsQ0FBQztnQkFDaEIsSUFBSSxDQUFDLElBQUksQ0FBQyxNQUFNLEVBQUUsR0FBRyxFQUFFLGFBQWEsQ0FBQyxDQUFDO1lBQzFDLENBQUMsQ0FBQyxDQUFDO1NBQ047SUFDTCxDQUFDO0lBRU8sZ0JBQWdCLENBQUMsYUFBYTtRQUNsQyxPQUFPLENBQ0gsT0FBTyxhQUFhLENBQUMsT0FBTyxDQUFDLEtBQUssV0FBVztZQUM3QyxhQUFhLENBQUMsT0FBTyxDQUFDLEtBQUssSUFBSTtZQUMvQixPQUFPLGFBQWEsQ0FBQyxhQUFhLENBQUMsS0FBSyxXQUFXO1lBQ25ELGFBQWEsQ0FBQyxhQUFhLENBQUMsS0FBSyxJQUFJLENBQ3hDLENBQUM7SUFDTixDQUFDO0lBRUQ7Ozs7T0FJRztJQUNLLGNBQWMsQ0FBQyxRQUFpQixJQUFJO1FBQ3hDLElBQUksWUFBWSxHQUFHLEdBQVMsRUFBRTtZQUMxQixJQUFJLEtBQUssS0FBSyxJQUFJLEVBQUU7Z0JBQ2hCLElBQUksQ0FBQyxhQUFhLENBQUMsT0FBTyxDQUFDLENBQUMsU0FBUyxHQUFHLElBQUksQ0FBQyxhQUFhLENBQUMsT0FBTyxDQUFDLENBQUMsU0FBUyxDQUFDLE9BQU8sQ0FBQyxXQUFXLEVBQUUsRUFBRSxDQUFDLENBQUM7Z0JBQ3ZHLEtBQUssSUFBSSxDQUFDLEdBQVcsQ0FBQyxFQUFFLENBQUMsR0FBRyxJQUFJLENBQUMsYUFBYSxDQUFDLGFBQWEsQ0FBQyxDQUFDLE1BQU0sRUFBRSxFQUFFLENBQUMsRUFBRTtvQkFDdkUsSUFBSSxDQUFDLGFBQWEsQ0FBQyxhQUFhLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxTQUFTLEdBQUcsSUFBSSxDQUFDLGFBQWEsQ0FBQyxhQUFhLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUMsT0FBTyxDQUFDLFdBQVcsRUFBRSxFQUFFLENBQUMsQ0FBQztpQkFDNUg7Z0JBQ0QsSUFBSSxDQUFDLGNBQWMsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLEtBQUssSUFBSSxJQUFJLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUM7Z0JBQ2pHLE9BQU87YUFDVjtZQUVELElBQUksSUFBSSxDQUFDLGFBQWEsQ0FBQyxPQUFPLENBQUM7Z0JBQzNCLElBQUksQ0FBQyxhQUFhLENBQUMsT0FBTyxDQUFDLENBQUMsU0FBUztnQkFDckMsSUFBSSxDQUFDLGFBQWEsQ0FBQyxPQUFPLENBQUMsQ0FBQyxTQUFTLENBQUMsT0FBTyxDQUFDLFFBQVEsQ0FBQyxLQUFLLENBQUMsQ0FBQyxFQUNoRTtnQkFDRSxJQUFJLENBQUMsYUFBYSxDQUFDLE9BQU8sQ0FBQyxDQUFDLFNBQVMsSUFBSSxTQUFTLENBQUM7Z0JBQ25ELEtBQUssSUFBSSxDQUFDLEdBQVcsQ0FBQyxFQUFFLENBQUMsR0FBRyxJQUFJLENBQUMsYUFBYSxDQUFDLGFBQWEsQ0FBQyxDQUFDLE1BQU0sRUFBRSxFQUFFLENBQUMsRUFBRTtvQkFDdkUsSUFBSSxDQUFDLGFBQWEsQ0FBQyxhQUFhLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxTQUFTLElBQUksU0FBUyxDQUFDO2lCQUMvRDthQUNKO1lBQ0QsSUFBSSxDQUFDLGlCQUFpQixDQUFDLEtBQUssQ0FBQyxDQUFDO1lBRTlCLElBQUksQ0FBQyxjQUFjLENBQUM7Z0JBQ2hCLGFBQWEsRUFBRSxFQUFFO2dCQUNqQixXQUFXLEVBQUUsS0FBSztnQkFDbEIsWUFBWSxFQUFFLEVBQUU7YUFDbkIsQ0FBQyxDQUFDO1lBQ0gsSUFBSSxDQUFDLGlCQUFpQixFQUFFLENBQUM7UUFDN0IsQ0FBQyxDQUFDO1FBQ0YsSUFBSSxLQUFLLEdBQUcsR0FBWSxFQUFFO1lBQ3RCLHNIQUFzSDtZQUN0SCxJQUFJLElBQUksQ0FBQyxNQUFNLENBQUMsS0FBSztnQkFDakIsSUFBSSxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsU0FBUztnQkFDM0IsSUFBSSxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsU0FBUyxDQUFDLElBQUk7Z0JBQ2hDLElBQUksQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLFNBQVMsQ0FBQyxJQUFJLEtBQUssTUFBTSxFQUM3QztnQkFDRSxJQUFJLGVBQWUsR0FBWSxJQUFJLENBQUMsZ0JBQWdCLENBQUMsSUFBSSxDQUFDLGFBQWEsQ0FBQyxDQUFDO2dCQUN6RSxJQUFJLGVBQWUsS0FBSyxJQUFJO29CQUFFLE9BQU8sZUFBZSxDQUFDO2dCQUVyRCxJQUFJLFdBQVcsR0FBVyxHQUFHLEdBQUcsSUFBSSxDQUFDLE1BQU0sR0FBRyx5QkFBeUIsQ0FBQztnQkFDeEUsSUFBSSxDQUFDLGFBQWEsQ0FBQyxPQUFPLENBQUMsR0FBRyxJQUFJLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxhQUFhLENBQUMsYUFBYSxDQUFDLFdBQVcsR0FBRyx1QkFBdUIsQ0FBQyxDQUFDO2dCQUNuSCxJQUFJLENBQUMsYUFBYSxDQUFDLGFBQWEsQ0FBQyxHQUFHLElBQUksQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLGFBQWEsQ0FBQyxnQkFBZ0IsQ0FBQyxXQUFXLEdBQUcsa0JBQWtCLENBQUMsQ0FBQztnQkFDdkgsT0FBTyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsSUFBSSxDQUFDLGFBQWEsQ0FBQyxDQUFDO2FBQ3BEO2lCQUFNO2dCQUNILE9BQU8sSUFBSSxDQUFDO2FBQ2Y7UUFDTCxDQUFDLENBQUM7UUFDRixJQUFJLENBQUMsSUFBSSxDQUFDLEtBQUssRUFBRSxZQUFZLENBQUMsQ0FBQztJQUNuQyxDQUFDO0lBR0Q7OztPQUdHO0lBQ0ssY0FBYyxDQUFDLEtBQWM7UUFDakMsSUFBSSxJQUFJLENBQUMsYUFBYSxDQUFDLFVBQVUsQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFDLEVBQUU7WUFDakQsS0FBSyxDQUFDLEVBQUUsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxHQUFTLEVBQUU7Z0JBQzNCLElBQUksQ0FBQyxXQUFXLENBQUMsR0FBRyxDQUFDLGFBQWEsQ0FBQyxLQUFLLENBQUMsQ0FBQztZQUM5QyxDQUFDLENBQUMsQ0FBQztTQUNOO0lBQ0wsQ0FBQztJQUVEOzs7T0FHRztJQUNLLFlBQVksQ0FBQyxPQUFpQjtRQUNsQyxJQUFJLE9BQU8sT0FBTyxLQUFLLFdBQVcsRUFBRTtZQUNoQyxPQUFPLEdBQUcsS0FBSyxDQUFDO1lBQ2hCLElBQUksSUFBSSxDQUFDLE1BQU0sQ0FBQyxLQUFLLElBQUksSUFBSSxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsS0FBSyxJQUFJLElBQUksQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxXQUFXLEVBQUU7Z0JBQ3JGLE9BQU8sR0FBRyxJQUFJLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsV0FBVyxDQUFDO2FBQ2pEO1NBQ0o7UUFDRCxJQUFJLElBQUksQ0FBQyxhQUFhLENBQUMsVUFBVSxDQUFDLElBQUksQ0FBQyxXQUFXLENBQUMsRUFBRTtZQUNqRCxLQUFLLENBQUMsRUFBRSxDQUFDLENBQUMsU0FBUyxDQUFDLEdBQVMsRUFBRTtnQkFDM0IsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxHQUFHLENBQUMsU0FBUyxFQUFFLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxXQUFXLENBQUMsR0FBRyxDQUFDLFdBQVcsRUFBRSxDQUFDO2dCQUNsRixJQUFJLENBQUMsWUFBWSxFQUFFLENBQUM7WUFDeEIsQ0FBQyxDQUFDLENBQUM7U0FDTjtJQUNMLENBQUM7SUFFRDs7Ozs7O09BTUc7SUFDSyxpQkFBaUIsQ0FBQyxXQUFvQixLQUFLO1FBQy9DLElBQUksQ0FBQyxXQUFXLENBQUMsU0FBUyxDQUFDLFlBQVksQ0FBQyxRQUFRLENBQUMsQ0FBQztJQUN0RCxDQUFDO0lBRUQsc0JBQXNCO0lBQ3RCOzs7OztPQUtHO0lBQ0ssZ0JBQWdCLENBQUMsUUFBYztRQUNuQyxJQUFJLFFBQVEsR0FBWSxLQUFLLENBQUM7UUFDOUIsSUFBSSxDQUFDLFFBQVE7WUFBRSxRQUFRLEdBQUcsSUFBSSxDQUFDLFdBQVcsQ0FBQyxTQUFTLENBQUMsc0JBQXNCLEVBQUUsQ0FBQztRQUM5RSxRQUFRLENBQUMsT0FBTyxDQUFDLENBQUMsTUFBVyxFQUFFLEVBQUU7WUFDN0IsSUFBSSxDQUFDLFVBQVUsQ0FBQyxNQUFNLENBQUMsQ0FBQztZQUN4QixJQUFJLFNBQVMsR0FBRyxNQUFNLENBQUMsU0FBUyxFQUFFLENBQUM7WUFDbkMsSUFBSSxTQUFTLENBQUMsZ0JBQWdCLEVBQUU7Z0JBQzVCLElBQUksQ0FBQyxVQUFVLENBQUMsU0FBUyxDQUFDLGdCQUFnQixDQUFDLENBQUE7YUFDOUM7aUJBQU07Z0JBQ0gsSUFBSSxNQUFNLENBQUMsTUFBTSxFQUFFO29CQUNmLFFBQVEsR0FBRyxJQUFJLENBQUM7b0JBQ2hCLElBQUksQ0FBQyxVQUFVLENBQUMsTUFBTSxDQUFDLE1BQU0sRUFBRSxLQUFLLENBQUMsQ0FBQztvQkFDdEMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxNQUFNLEdBQUcsTUFBTSxDQUFDO29CQUM5QixNQUFNLENBQUMsTUFBTSxHQUFHLE1BQU0sQ0FBQztvQkFDdkIsU0FBUyxDQUFDLE1BQU0sR0FBRyxNQUFNLENBQUM7aUJBQzdCO2FBQ0o7UUFDTCxDQUFDLENBQUMsQ0FBQztRQUNILElBQUksUUFBUTtZQUFFLElBQUksQ0FBQyxhQUFhLENBQUMsSUFBSSxDQUFDLENBQUM7SUFDM0MsQ0FBQztJQUVPLFVBQVUsQ0FBQyxPQUFZLEVBQUUsZUFBd0IsSUFBSTtRQUN6RCxJQUFJLFlBQVksRUFBRTtZQUNkLElBQUksU0FBUyxHQUFHLE9BQU8sQ0FBQyxTQUFTLEVBQUUsQ0FBQztZQUNwQyxTQUFTLENBQUMsZUFBZSxHQUFHLElBQUksQ0FBQyx1QkFBdUIsQ0FBQztZQUN6RCxTQUFTLENBQUMsWUFBWSxHQUFHLElBQUksQ0FBQyx1QkFBdUIsQ0FBQztZQUN0RCxTQUFTLENBQUMsVUFBVSxHQUFHLElBQUksQ0FBQyx1QkFBdUIsQ0FBQztTQUN2RDtRQUNELElBQUksT0FBTyxDQUFDLFNBQVMsRUFBRTtZQUNuQixPQUFPLENBQUMsU0FBUyxDQUFDLENBQUMsSUFBSSxDQUFDLHVCQUF1QixDQUFDLENBQUM7U0FDcEQ7YUFBTTtZQUNILE9BQU8sQ0FBQyxNQUFNLEdBQUcsQ0FBQyxJQUFJLENBQUMsdUJBQXVCLENBQUM7U0FDbEQ7UUFDRCxPQUFPLENBQUMsWUFBWSxHQUFHLElBQUksQ0FBQyx1QkFBdUIsQ0FBQztRQUNwRCxPQUFPLENBQUMsVUFBVSxHQUFHLElBQUksQ0FBQyx1QkFBdUIsQ0FBQztJQUN0RCxDQUFDO0lBQ0Qsc0JBQXNCO0lBRXRCLHdHQUF3RztJQUN4Ryx1Q0FBdUM7SUFDdkMsd0dBQXdHO0lBQ2hHLGVBQWUsQ0FBQyxZQUEwQjtRQUM5QyxJQUFJLFlBQVksQ0FBQyxjQUFjLENBQUMsd0JBQXdCLENBQUM7WUFBRSxJQUFJLENBQUMsdUJBQXVCLEdBQUcsWUFBWSxDQUFDLHNCQUFzQixDQUFDO1FBQzlILElBQUksQ0FBQyxVQUFVLEdBQWtCLElBQUksQ0FBQyxPQUFPLENBQUMsb0JBQW9CLEVBQUUsQ0FBQztRQUVyRSxJQUFJLENBQUMsV0FBVyxHQUFHLElBQUksQ0FBQyxhQUFhLENBQUMsbUJBQW1CLENBQUMsWUFBWSxFQUFFLElBQUksQ0FBQyxVQUFVLENBQUMsQ0FBQztRQUN6RixJQUFJLENBQUMsV0FBVyxDQUFDLE9BQU8sQ0FBQyxRQUFRLENBQUMsR0FBRyxJQUFJLENBQUMsTUFBTSxDQUFDO1FBQ2pELElBQUksQ0FBQyxXQUFXLENBQUMsc0JBQXNCLEdBQUcsS0FBSyxDQUFDO1FBQ2hELElBQUksQ0FBQyxXQUFXLENBQUMsdUJBQXVCLEdBQUcsQ0FBQyxNQUFXLEVBQVEsRUFBRTtZQUM3RCxJQUFJLENBQUMsZ0JBQWdCLENBQUMsTUFBTSxDQUFDLE9BQU8sQ0FBQyxDQUFDO1lBQ3RDLElBQUksQ0FBQyxZQUFZLEVBQUUsQ0FBQztRQUN4QixDQUFDLENBQUE7UUFDRCxJQUFJLENBQUMsYUFBYSxDQUFDLGNBQWMsQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFDLENBQUM7SUFDeEQsQ0FBQztJQUVPLGFBQWEsQ0FBQyxhQUFrQztRQUNwRCxJQUFJLENBQUMsYUFBYSxDQUFDLFlBQVksQ0FBQyxhQUFhLEVBQUUsSUFBSSxDQUFDLE1BQU0sRUFBRSxJQUFJLENBQUMsdUJBQXVCLENBQUMsQ0FBQztRQUMxRixJQUFJLENBQUMsYUFBYSxFQUFFLENBQUM7SUFDekIsQ0FBQztJQUVPLG9CQUFvQixDQUFDLFdBQW9CLElBQUk7UUFDakQsSUFBSSxJQUFJLENBQUMsYUFBYSxDQUFDLFVBQVUsQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFDLEVBQUU7WUFDakQsSUFBSSxDQUFDLHVCQUF1QixHQUFHLFFBQVEsQ0FBQztZQUV4QyxJQUFJLENBQUMsYUFBYSxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQztZQUNoQyxJQUFJLElBQUksQ0FBQyxNQUFNLENBQUMsUUFBUSxLQUFLLFFBQVEsSUFBSSxJQUFJLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxTQUFTLENBQUMsSUFBSSxLQUFLLE9BQU8sRUFBRTtnQkFDbkYsSUFBSSxDQUFDLGNBQWMsQ0FBQyxJQUFJLENBQUMsYUFBYSxDQUFDLENBQUM7YUFDM0M7WUFFRCxJQUFJLENBQUMsWUFBWSxFQUFFLENBQUM7U0FDdkI7SUFDTCxDQUFDO0lBRU8sV0FBVyxDQUFDLFFBQW9CLEVBQUUsb0JBQTZCLElBQUk7UUFDdkUsd0ZBQXdGO1FBQ3hGLElBQUksQ0FBQyxhQUFhLENBQUMsdUJBQXVCLENBQUMsUUFBUSxFQUFFLElBQUksQ0FBQyxNQUFNLEVBQUUsSUFBSSxDQUFDLE1BQU0sRUFBRSxJQUFJLENBQUMsV0FBVyxDQUFDLENBQUM7UUFFakcsSUFBSSxpQkFBaUIsRUFBRTtZQUNuQixJQUFJLENBQUMsYUFBYSxDQUFDLFVBQVUsQ0FBQyxRQUFRLENBQUMsQ0FBQztTQUMzQztRQUVELElBQUksSUFBSSxDQUFDLGFBQWEsQ0FBQyxpQkFBaUIsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLFFBQVEsQ0FBQyxJQUFJLElBQUksQ0FBQyxhQUFhLENBQUMsVUFBVSxDQUFDLElBQUksQ0FBQyxXQUFXLENBQUMsRUFBRTtZQUMvRyxJQUFJLENBQUMseUJBQXlCLEVBQUUsQ0FBQztTQUNwQztRQUVELEtBQUssRUFBRSxDQUFDLFNBQVMsQ0FBQyxHQUFTLEVBQUU7WUFDekIsSUFBSSxDQUFDLGdCQUFnQixFQUFFLENBQUM7WUFDeEIsSUFBSSxDQUFDLHFCQUFxQixFQUFFLENBQUM7UUFDakMsQ0FBQyxDQUFDLENBQUM7SUFDUCxDQUFDO0lBRUQsd0dBQXdHO0lBQ3hHLHNDQUFzQztJQUN0Qyx3R0FBd0c7SUFDaEcsbUJBQW1CLENBQUksVUFBa0IsRUFBRSxpQkFBb0I7UUFDbkUsUUFBUSxVQUFVLEVBQUU7WUFDaEIsS0FBSyxZQUFZLENBQUM7WUFDbEIsS0FBSyxXQUFXLENBQUM7WUFDakIsS0FBSyxPQUFPLENBQUM7WUFDYixLQUFLLFFBQVE7Z0JBQ1QsSUFBSSxDQUFDLHFCQUFxQixDQUFJLGlCQUFpQixDQUFDLENBQUM7Z0JBQ2pELE1BQU07WUFDVjtnQkFDSSxPQUFPLENBQUMsS0FBSyxDQUFDLDRDQUE0QyxFQUFFLFVBQVUsQ0FBQyxDQUFDO1NBQy9FO0lBQ0wsQ0FBQztJQUVPLHFCQUFxQixDQUFJLE9BQVU7UUFDdkMsSUFBSSxDQUFDLGNBQWMsQ0FBQyxnQkFBZ0IsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLEVBQUUsRUFBRSxPQUFPLENBQUMsQ0FBQztJQUNsRSxDQUFDO0lBRU8sMkJBQTJCO1FBQy9CLElBQUksQ0FBQyxjQUFjLENBQUMsWUFBWSxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsRUFBRSxDQUFDLENBQUM7SUFDckQsQ0FBQztJQUVPLHdCQUF3QjtRQUM1QixJQUFJLENBQUMsZ0JBQWdCLENBQUMsY0FBYyxHQUFHLElBQUksQ0FBQyxjQUFjLENBQUMsa0JBQWtCLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxFQUFFLENBQUMsQ0FBQyxTQUFTLENBQUMsQ0FBQyxRQUFpQixFQUFRLEVBQUU7WUFDaEksSUFBSSxDQUFDLHFCQUFxQixDQUFDLFFBQVEsQ0FBQyxDQUFDO1FBQ3pDLENBQUMsQ0FBQyxDQUFDO1FBRUgsSUFBSSxDQUFDLGdCQUFnQixDQUFDLGVBQWUsR0FBRyxJQUFJLENBQUMsY0FBYyxDQUFDLGNBQWMsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLEVBQUUsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxDQUFDLFdBQWlDLEVBQVEsRUFBRTtZQUM3SSxJQUFJLENBQUMsb0JBQW9CLENBQUMsV0FBVyxDQUFDLENBQUM7UUFDM0MsQ0FBQyxDQUFDLENBQUM7UUFFSCxJQUFJLENBQUMsZ0JBQWdCLENBQUMsYUFBYSxHQUFHLElBQUksQ0FBQyxjQUFjLENBQUMsb0JBQW9CLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxFQUFFLENBQUMsQ0FBQyxTQUFTLENBQUMsQ0FBQyxLQUF1QyxFQUFRLEVBQUU7WUFDdkosSUFBSSxLQUFLLENBQUMsTUFBTSxLQUFLLFFBQVEsRUFBRTtnQkFDM0IsSUFBSSxNQUFNLEdBQVcsQ0FBQyxPQUFPLElBQUksQ0FBQyxNQUFNLENBQUMsUUFBUSxLQUFLLFdBQVcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDO2dCQUNqRyxJQUFJLENBQUMsc0JBQXNCLENBQUMsQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQztnQkFDckQsSUFBSSxDQUFDLHFCQUFxQixFQUFFLENBQUM7YUFDaEM7UUFDTCxDQUFDLENBQUMsQ0FBQztJQUNQLENBQUM7SUFFRCx3R0FBd0c7SUFDeEcsMENBQTBDO0lBQzFDLHdHQUF3RztJQUNoRyxxQkFBcUIsQ0FBQyxRQUFpQixFQUFFLFVBQW9CO1FBQ2pFLElBQUksV0FBVyxHQUFXLENBQUMsT0FBTyxVQUFVLEtBQUssV0FBVyxJQUFJLFVBQVUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQztRQUNoRyxJQUFJLE9BQU8sUUFBUSxLQUFLLFdBQVcsRUFBRTtZQUNqQyxXQUFXLEdBQUcsUUFBUSxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUM7U0FDbEM7UUFFRCxJQUFJLGVBQWUsR0FBZ0MsSUFBSSwyQkFBMkIsRUFBRSxDQUFDO1FBRXJGLGVBQWUsQ0FBQyxXQUFXLEdBQUcsV0FBVyxDQUFDO1FBQzFDLGVBQWUsQ0FBQyxhQUFhLEdBQUcsSUFBSSxDQUFDLGFBQWEsQ0FBQyxxQkFBcUIsQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFDLE9BQU8sRUFBRSxJQUFJLENBQUMsTUFBTSxDQUFDLFNBQVMsQ0FBQyxLQUFLLEVBQUUsSUFBSSxDQUFDLE1BQU0sQ0FBQyxTQUFTLENBQUMsU0FBUyxFQUFFLElBQUksQ0FBQyxNQUFNLENBQUMsUUFBUSxDQUFDLENBQUM7UUFDdkwsbUZBQW1GO1FBRW5GLElBQUksQ0FBQyxtQkFBbUIsQ0FBOEIsV0FBVyxFQUFFLGVBQWUsQ0FBQyxDQUFDO0lBQ3hGLENBQUM7SUFFTyx3QkFBd0I7UUFDNUIsSUFBSSxDQUFDLHFCQUFxQixDQUFDLFNBQVMsRUFBRSxJQUFJLENBQUMsQ0FBQztJQUNoRCxDQUFDO0lBRUQsd0dBQXdHO0lBQ3hHLG1CQUFtQjtJQUNuQix3R0FBd0c7SUFDaEcsb0JBQW9CLENBQUMsV0FBaUM7UUFDMUQsSUFBSSxXQUFXLEdBQTRCLElBQUksdUJBQXVCLEVBQUUsQ0FBQztRQUV6RSxXQUFXLENBQUMsS0FBSyxHQUFHLFdBQVcsQ0FBQyxLQUFLLENBQUM7UUFDdEMsV0FBVyxDQUFDLEtBQUssR0FBRyxXQUFXLENBQUMsS0FBSyxDQUFDO1FBQ3RDLFdBQVcsQ0FBQyxXQUFXLEdBQUcsV0FBVyxDQUFDLFdBQVcsQ0FBQztRQUNsRCxXQUFXLENBQUMsUUFBUSxHQUFHLFdBQVcsQ0FBQyxRQUFRLENBQUM7UUFDNUMsV0FBVyxDQUFDLEtBQUssR0FBRyxXQUFXLENBQUMsSUFBSSxDQUFDO1FBRXJDLElBQUksQ0FBQyxtQkFBbUIsQ0FBMEIsT0FBTyxFQUFFLFdBQVcsQ0FBQyxDQUFDO0lBQzVFLENBQUM7SUFFTyxxQkFBcUI7UUFDekIsSUFBSSxXQUFXLEdBQTRCLElBQUksdUJBQXVCLEVBQUUsQ0FBQztRQUN6RSxJQUFJLENBQUMsbUJBQW1CLENBQTBCLE9BQU8sRUFBRSxXQUFXLENBQUMsQ0FBQztJQUM1RSxDQUFDO0lBRU8sc0JBQXNCLENBQUMsU0FBd0I7UUFDbkQsSUFBSSxRQUFRLEdBQVcsQ0FBQyxPQUFPLElBQUksQ0FBQyxNQUFNLENBQUMsUUFBUSxLQUFLLFdBQVcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDO1FBRW5HLEtBQUssSUFBSSxDQUFDLEdBQVcsQ0FBQyxFQUFFLENBQUMsR0FBRyxTQUFTLENBQUMsTUFBTSxFQUFFLEVBQUUsQ0FBQyxFQUFFO1lBQy9DLEtBQUssSUFBSSxDQUFDLEdBQVcsQ0FBQyxFQUFFLENBQUMsR0FBRyxJQUFJLENBQUMsR0FBRyxDQUFDLE1BQU0sRUFBRSxFQUFFLENBQUMsRUFBRTtnQkFDOUMsSUFBSSxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxFQUFFLEtBQUssSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxRQUFRLEVBQUUsRUFBRTtvQkFDOUQsSUFBSSxDQUFDLEdBQUcsQ0FBQyxNQUFNLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDO29CQUN0QixNQUFNO2lCQUNUO2FBQ0o7U0FDSjtJQUNMLENBQUM7SUFFRCx3R0FBd0c7SUFDeEcsbUNBQW1DO0lBQ25DLHdHQUF3RztJQUNoRyxnQkFBZ0I7UUFDcEIsSUFBSSxJQUFJLENBQUMsYUFBYSxDQUFDLFVBQVUsQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFDLEVBQUU7WUFDakQsSUFBSSxDQUFDLFdBQVcsQ0FBQyxHQUFHLENBQUMsdUJBQXVCLENBQUMsSUFBSSxDQUFDLENBQUM7WUFDbkQsSUFBSSxDQUFDLFdBQVcsQ0FBQyxHQUFHLENBQUMsY0FBYyxDQUFDLElBQUksQ0FBQyxDQUFDO1lBQzFDLElBQUksQ0FBQyxXQUFXLENBQUMsR0FBRyxDQUFDLFlBQVksQ0FBQyxJQUFJLENBQUMsQ0FBQztZQUV4QyxJQUFJLE9BQU8sSUFBSSxDQUFDLGdCQUFnQixDQUFDLGFBQWEsS0FBSyxXQUFXLEVBQUU7Z0JBQzVELElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxhQUFhLENBQUMsV0FBVyxFQUFFLENBQUM7YUFDckQ7U0FDSjtJQUNMLENBQUM7SUFFTyw2QkFBNkI7UUFDakMsSUFBSSxVQUFVLEdBQTBCO1lBQ3BDLE9BQU8sRUFBRSxDQUFDLE9BQWlDLEVBQVEsRUFBRTtnQkFDakQsSUFBSSxDQUFDLG1CQUFtQixDQUFDLElBQUksQ0FBQyxDQUFDO2dCQUUvQixJQUFJLE9BQU8sSUFBSSxDQUFDLGdCQUFnQixDQUFDLGFBQWEsS0FBSyxXQUFXLEVBQUU7b0JBQzVELElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxhQUFhLENBQUMsV0FBVyxFQUFFLENBQUM7aUJBQ3JEO2dCQUNELElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxhQUFhLEdBQUcsSUFBSSxDQUFDLHVCQUF1QixDQUFDLE9BQU8sQ0FBQyxDQUFDLFNBQVMsQ0FBQyxDQUFDLFNBQWlDLEVBQVEsRUFBRTtvQkFDOUgsT0FBTyxDQUFDLGVBQWUsQ0FBQyxTQUFTLENBQUMsSUFBSSxFQUFFLFNBQVMsQ0FBQyxLQUFLLENBQUMsQ0FBQztvQkFDekQsSUFBSSxDQUFDLG1CQUFtQixDQUFDLEtBQUssQ0FBQyxDQUFDO2dCQUNwQyxDQUFDLENBQUMsQ0FBQztZQUNQLENBQUM7U0FDSixDQUFDO1FBRUYsSUFBSSxDQUFDLFdBQVcsQ0FBQyxHQUFHLENBQUMsdUJBQXVCLENBQUMsVUFBVSxDQUFDLENBQUM7SUFDN0QsQ0FBQztJQUVPLHVCQUF1QixDQUFDLGlCQUEyQztRQUN2RSxPQUFPLElBQUksVUFBVSxDQUF5QixDQUFDLFNBQTZDLEVBQVEsRUFBRTtZQUNsRyxRQUFRLElBQUksQ0FBQyxNQUFNLENBQUMsUUFBUSxFQUFFO2dCQUMxQixLQUFLLFVBQVUsQ0FBQztnQkFDaEIsS0FBSyxTQUFTO29CQUNhLElBQUksQ0FBQyxhQUFjLENBQUMsc0JBQXNCLENBQUMsaUJBQWlCLENBQUMsT0FBTyxFQUFFLElBQUksQ0FBQyxXQUFXLENBQUMsT0FBTyxDQUFDLEtBQUssRUFBRSxDQUFDLENBQUMsU0FBUyxDQUFDLENBQUMsU0FBaUMsRUFBUSxFQUFFO3dCQUNqTCxTQUFTLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDO3dCQUMxQixTQUFTLENBQUMsUUFBUSxFQUFFLENBQUM7b0JBQ3pCLENBQUMsQ0FBQyxDQUFDO29CQUVILE1BQU07Z0JBQ1YsS0FBSyxRQUFRO29CQUNULElBQUksWUFBWSxHQUEyQixJQUFJLHNCQUFzQixDQUFDLGlCQUFpQixDQUFDLE9BQU8sRUFBRSxTQUFTLENBQUMsQ0FBQztvQkFDNUcsSUFBSSxDQUFDLG1CQUFtQixDQUF5QixZQUFZLEVBQUUsWUFBWSxDQUFDLENBQUM7b0JBRTdFLE1BQU07Z0JBQ1Y7b0JBQ0ksT0FBTyxDQUFDLEtBQUssQ0FBQyw4Q0FBOEMsRUFBRSxJQUFJLENBQUMsTUFBTSxDQUFDLFFBQVEsQ0FBQyxDQUFDO29CQUNwRixTQUFTLENBQUMsUUFBUSxFQUFFLENBQUM7YUFDNUI7UUFDTCxDQUFDLENBQUMsQ0FBQztJQUNQLENBQUM7SUFFRCx3R0FBd0c7SUFDeEcsaUJBQWlCO0lBQ2pCLHdHQUF3RztJQUNoRyxjQUFjO1FBQ2xCLElBQUksT0FBTyxJQUFJLENBQUMsR0FBRyxLQUFLLFdBQVcsRUFBRTtZQUNqQyxJQUFJLFNBQVMsR0FBUTtnQkFDakIsaUNBQWlDO2dCQUNqQyxLQUFLLEVBQUUsSUFBSSxDQUFDLGNBQWM7Z0JBQzFCLEVBQUUsRUFBRSxJQUFJLENBQUMsTUFBTSxDQUFDLEVBQUU7Z0JBQ2xCLElBQUksRUFBRSxJQUFJLENBQUMsR0FBRztnQkFDZCxPQUFPLEVBQUUsSUFBSSxDQUFDLE1BQU07YUFDdkIsQ0FBQztZQUVGLElBQUksQ0FBQyxhQUFhLENBQUMscUJBQXFCLENBQUMsSUFBSSxDQUFDLEdBQUcsRUFBRSxTQUFTLENBQUMsQ0FBQztZQUU5RCwwQ0FBMEM7WUFDMUMsa0NBQWtDO1lBQ2xDLElBQUksQ0FBQyxHQUFHLENBQUMsT0FBTyxDQUFDLFdBQVcsR0FBRyxDQUFDLE9BQWdCLEVBQVEsRUFBRTtnQkFDdEQsSUFBSSxDQUFDLGNBQWMsR0FBRyxPQUFPLENBQUM7WUFDbEMsQ0FBQyxDQUFDO1lBRUYsSUFBSSxDQUFDLEdBQUcsQ0FBQyxPQUFPLENBQUMsVUFBVSxHQUFHLENBQUMsZ0JBQWtDLEVBQVEsRUFBRTtnQkFDdkUsSUFBSSxZQUFZLEdBQW1CLEVBQUUsQ0FBQztnQkFFdEMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxHQUFHLENBQUMsV0FBVyxDQUFDLENBQUMsUUFBaUIsRUFBUSxFQUFFO29CQUN6RCxJQUFJLE9BQU8sUUFBUSxDQUFDLEVBQUUsS0FBSyxXQUFXLElBQUksUUFBUSxDQUFDLEVBQUUsS0FBSyxnQkFBZ0IsQ0FBQyxLQUFLLEVBQUU7d0JBQzlFLFFBQVEsQ0FBQyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsS0FBSyxDQUFDLEdBQUcsZ0JBQWdCLENBQUMsSUFBSSxDQUFDO3dCQUM5RCxZQUFZLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxDQUFDO3FCQUMvQjtnQkFDTCxDQUFDLENBQUMsQ0FBQztnQkFFSCxJQUFJLGFBQWEsR0FBc0Q7b0JBQ25FLFFBQVEsRUFBRSxZQUFZO29CQUN0QixPQUFPLEVBQUUsQ0FBQyxnQkFBZ0IsQ0FBQyxLQUFLLENBQUM7aUJBQ3BDLENBQUM7Z0JBRUYsSUFBSSxDQUFDLFdBQVcsQ0FBQyxHQUFHLENBQUMsWUFBWSxDQUFDLGFBQWEsQ0FBQyxDQUFDO1lBQ3JELENBQUMsQ0FBQztZQUVGLElBQUksQ0FBQyxHQUFHLENBQUMsT0FBTyxDQUFDLFNBQVMsR0FBRyxDQUFDLFdBQW1CLEVBQVEsRUFBRTtnQkFDdkQsSUFBSSxJQUFJLENBQUMsTUFBTSxDQUFDLFFBQVEsS0FBSyxRQUFRLEVBQUU7b0JBQ25DLElBQUksQ0FBQyxXQUFXLENBQUMsR0FBRyxDQUFDLGNBQWMsQ0FBQyxXQUFXLENBQUMsQ0FBQztpQkFDcEQ7cUJBQ0k7b0JBQ0QsT0FBTyxDQUFDLElBQUksQ0FBQyxpR0FBaUcsQ0FBQyxDQUFDO2lCQUNuSDtZQUNMLENBQUMsQ0FBQztZQUVGLElBQUksQ0FBQyxHQUFHLENBQUMsT0FBTyxDQUFDLE9BQU8sR0FBRyxDQUFDLEtBQWlCLEVBQUUsbUJBQTRCLEtBQUssRUFBUSxFQUFFO2dCQUN0Rjs7Ozs7OzttQkFPRztnQkFDSCxJQUFJLE9BQU8sSUFBSSxDQUFDLE1BQU0sQ0FBQyxRQUFRLEtBQUssV0FBVyxJQUFJLElBQUksQ0FBQyxNQUFNLENBQUMsUUFBUSxLQUFLLFFBQVEsRUFBRTtvQkFDbEYsSUFBSSxNQUFNLEdBQVcsQ0FBQyxPQUFPLElBQUksQ0FBQyxNQUFNLENBQUMsUUFBUSxLQUFLLFdBQVcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDO29CQUVqRyxLQUFLLElBQUksQ0FBQyxHQUFXLENBQUMsRUFBRSxDQUFDLEdBQUcsS0FBSyxDQUFDLE1BQU0sRUFBRSxFQUFFLENBQUMsRUFBRTt3QkFDM0MsSUFBSSxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7cUJBQzNCO29CQUVELElBQUksQ0FBQyxXQUFXLENBQUMsSUFBSSxDQUFDLEdBQUcsRUFBRSxLQUFLLENBQUMsQ0FBQztvQkFDbEMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxHQUFHLENBQUMsYUFBYSxDQUFDLEVBQUUsR0FBRyxFQUFFLEtBQUssQ0FBQyxLQUFLLEVBQUUsRUFBRSxDQUFDLENBQUM7b0JBRTNELElBQUksZ0JBQWdCLEVBQUU7d0JBQ2xCLElBQUksQ0FBQyxXQUFXLENBQUMsR0FBRyxDQUFDLGtCQUFrQixDQUFDLElBQUksQ0FBQyxXQUFXLENBQUMsR0FBRyxDQUFDLFVBQVUsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsUUFBUSxFQUFFLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQztxQkFDbEg7aUJBQ0o7cUJBQ0k7b0JBQ0QsT0FBTyxDQUFDLElBQUksQ0FBQyxnRkFBZ0YsQ0FBQyxDQUFDO2lCQUNsRztZQUNMLENBQUMsQ0FBQztZQUVGLElBQUksQ0FBQyxHQUFHLENBQUMsT0FBTyxDQUFDLFVBQVUsR0FBRyxDQUFDLEdBQTZDLEVBQVEsRUFBRTtnQkFDbEYsSUFBSSxPQUFPLElBQUksQ0FBQyxNQUFNLENBQUMsUUFBUSxLQUFLLFdBQVcsSUFBSSxJQUFJLENBQUMsTUFBTSxDQUFDLFFBQVEsS0FBSyxRQUFRLEVBQUU7b0JBQ2xGLElBQUksWUFBWSxHQUFrQixFQUFFLENBQUM7b0JBRXJDLElBQUksT0FBTyxHQUFHLEtBQUssUUFBUSxJQUFJLE9BQU8sR0FBRyxLQUFLLFFBQVEsRUFBRTt3QkFDcEQsWUFBWSxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsUUFBUSxFQUFFLENBQUMsQ0FBQztxQkFDckM7eUJBQ0k7d0JBQ0QsS0FBSyxJQUFJLENBQUMsR0FBVyxDQUFDLEVBQUUsQ0FBQyxHQUFHLEdBQUcsQ0FBQyxNQUFNLEVBQUUsRUFBRSxDQUFDLEVBQUU7NEJBQ3pDLFlBQVksQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLFFBQVEsRUFBRSxDQUFDLENBQUM7eUJBQ3JDO3FCQUNKO29CQUVELElBQUksQ0FBQyxzQkFBc0IsQ0FBQyxZQUFZLENBQUMsQ0FBQztvQkFFMUMsSUFBSSxHQUFHLEdBQVcsT0FBTyxJQUFJLENBQUMsTUFBTSxDQUFDLFFBQVEsS0FBSyxXQUFXLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxRQUFRLENBQUM7b0JBQzVGLElBQUksVUFBVSxHQUFlLEVBQUUsQ0FBQztvQkFFaEMsS0FBSyxJQUFJLENBQUMsR0FBVyxDQUFDLEVBQUUsQ0FBQyxHQUFHLFlBQVksQ0FBQyxNQUFNLEVBQUUsRUFBRSxDQUFDLEVBQUU7d0JBQ2xELFVBQVUsQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDLEdBQUcsQ0FBQyxFQUFFLFlBQVksQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUM7cUJBQy9DO29CQUVEOzs7Ozs7O3VCQU9HO29CQUVILElBQUksY0FBYyxHQUFtRTt3QkFDakYsTUFBTSxFQUFFLFVBQVU7cUJBQ3JCLENBQUM7b0JBRUYsSUFBSSxDQUFDLFdBQVcsQ0FBQyxHQUFHLENBQUMsYUFBYSxDQUFDLGNBQWMsQ0FBQyxDQUFDO29CQUNuRCxJQUFJLENBQUMscUJBQXFCLEVBQUUsQ0FBQztpQkFDaEM7cUJBQ0k7b0JBQ0QsT0FBTyxDQUFDLElBQUksQ0FBQyxnRkFBZ0YsQ0FBQyxDQUFDO2lCQUNsRztZQUNMLENBQUMsQ0FBQztZQUVGLElBQUksQ0FBQyxHQUFHLENBQUMsT0FBTyxDQUFDLGlCQUFpQixHQUFHLENBQUMsV0FBbUIsRUFBRSxXQUFvQixFQUFFLEVBQUU7Z0JBQy9FLEtBQUssSUFBSSxDQUFDLEdBQVcsQ0FBQyxFQUFFLENBQUMsR0FBRyxJQUFJLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxNQUFNLEVBQUUsRUFBRSxDQUFDLEVBQUU7b0JBQ3hELElBQUksSUFBSSxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxLQUFLLFdBQVcsRUFBRTt3QkFDNUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxHQUFHLFdBQVcsQ0FBQztxQkFDaEQ7aUJBQ0o7WUFDTCxDQUFDLENBQUM7WUFFRixJQUFJLENBQUMsR0FBRyxDQUFDLE9BQU8sQ0FBQyxhQUFhLEdBQUcsQ0FBQyxPQUEwQixFQUFRLEVBQUU7Z0JBQ2xFLElBQUksYUFBYSxHQUFzQjtvQkFDbkMsUUFBUSxFQUFFLE1BQU07b0JBQ2hCLFVBQVUsRUFBRSxJQUFJO29CQUNoQixtQkFBbUIsRUFBRSxJQUFJO2lCQUM1QixDQUFDO2dCQUNGLHVEQUF1RDtnQkFDdkQsSUFBSSxPQUFPLENBQUMsY0FBYyxDQUFDLFdBQVcsQ0FBQztvQkFBRSxPQUFPLENBQUMsU0FBUyxHQUFHLE9BQU8sQ0FBQyxTQUFTLENBQUMsS0FBSyxDQUFDLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQztnQkFDNUYsSUFBSSxNQUFNLEdBQXNCLE1BQU0sQ0FBQyxNQUFNLENBQUMsRUFBRSxFQUFFLGFBQWEsRUFBRSxPQUFPLENBQUMsQ0FBQztnQkFDMUUsSUFBSSxPQUFPLEdBQVEsSUFBSSxDQUFDLFdBQVcsQ0FBQyxHQUFHLENBQUMsY0FBYyxDQUFDLE1BQU0sQ0FBQyxDQUFDO2dCQUMvRCxJQUFJLFFBQVEsR0FBUSxJQUFJLENBQUMsSUFBSSxDQUFDLE9BQU8sRUFBRSxFQUFFLElBQUksRUFBRSxRQUFRLEVBQUUsQ0FBQyxDQUFDO2dCQUMzRCxJQUFJLFdBQVcsR0FBUSxJQUFJLENBQUMsS0FBSyxDQUFDLFFBQVEsRUFBRSxFQUFFLFFBQVEsRUFBRSxNQUFNLEVBQUUsSUFBSSxFQUFFLFFBQVEsRUFBRSxDQUFDLENBQUM7Z0JBQ2xGLElBQUksVUFBVSxHQUFTLElBQUksQ0FBQyxhQUFhLENBQUMsU0FBUyxDQUFDLFdBQVcsRUFBRSxtRUFBbUUsQ0FBQyxDQUFDO2dCQUN0SSxNQUFNLENBQUMsVUFBVSxFQUFFLE1BQU0sQ0FBQyxRQUFRLEdBQUcsT0FBTyxDQUFDLENBQUM7WUFDbEQsQ0FBQyxDQUFDO1lBRUYsSUFBSSxDQUFDLEdBQUcsQ0FBQyxPQUFPLENBQUMsWUFBWSxHQUFHLENBQUMscUJBQThCLEtBQUssRUFBUSxFQUFFO2dCQUMxRSxJQUFJLENBQUMsYUFBYSxDQUFDLGtCQUFrQixDQUFDLENBQUM7WUFDM0MsQ0FBQyxDQUFDO1lBRUYsSUFBSSxDQUFDLEdBQUcsQ0FBQyxPQUFPLENBQUMsbUJBQW1CLEdBQUcsQ0FBQyxRQUFpQixFQUFRLEVBQUU7Z0JBQy9ELElBQUksQ0FBQyxvQkFBb0IsQ0FBQyxRQUFRLENBQUMsQ0FBQztZQUN4QyxDQUFDLENBQUM7WUFFRixnQ0FBZ0M7WUFDaEMsSUFBSSxPQUFPLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsS0FBSyxXQUFXO2dCQUFFLElBQUksQ0FBQyxHQUFHLENBQUMsS0FBSyxHQUFHLEVBQUUsQ0FBQztZQUNqRSxJQUFJLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxVQUFVLEdBQUcsR0FBUyxFQUFFO2dCQUNuQyxJQUFJLENBQUMsWUFBWSxFQUFFLENBQUM7WUFDeEIsQ0FBQyxDQUFDO1lBRUYsSUFBSSxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsYUFBYSxHQUFHLENBQUMsS0FBYyxFQUFRLEVBQUU7Z0JBQ3BELElBQUksQ0FBQyxjQUFjLENBQUMsS0FBSyxDQUFDLENBQUM7WUFDL0IsQ0FBQyxDQUFDO1lBRUYsSUFBSSxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsV0FBVyxHQUFHLENBQUMsT0FBZ0IsRUFBUSxFQUFFO2dCQUNwRCxJQUFJLENBQUMsWUFBWSxDQUFDLE9BQU8sQ0FBQyxDQUFDO1lBQy9CLENBQUMsQ0FBQztZQUVGLElBQUksQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLGFBQWEsR0FBRyxHQUFxQixFQUFFO2dCQUNsRCxPQUFPLElBQUksQ0FBQyxjQUFjLEVBQUUsQ0FBQztZQUNqQyxDQUFDLENBQUM7WUFFRixJQUFJLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxhQUFhLEdBQUcsQ0FBQyxNQUF3QixFQUFRLEVBQUU7Z0JBQzlELElBQUksQ0FBQyxhQUFhLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDO2dCQUNoQyxJQUFJLENBQUMsY0FBYyxDQUFDLE1BQU0sQ0FBQyxDQUFDO1lBQ2hDLENBQUMsQ0FBQztZQUVGLElBQUksQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLGdCQUFnQixHQUFHLENBQUMsUUFBaUIsRUFBUSxFQUFFO2dCQUMxRCxJQUFJLENBQUMsaUJBQWlCLENBQUMsUUFBUSxDQUFDLENBQUM7WUFDckMsQ0FBQyxDQUFDO1lBRUYsSUFBSSxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsYUFBYSxHQUFHLENBQUMsS0FBYyxFQUFRLEVBQUU7Z0JBQ3BELElBQUksQ0FBQyxjQUFjLENBQUMsS0FBSyxDQUFDLENBQUM7WUFDL0IsQ0FBQyxDQUFDO1lBRUYsZ0NBQWdDO1lBQ2hDLElBQUksQ0FBQyxHQUFHLENBQUMsV0FBVyxDQUFDLGFBQWEsR0FBRyxHQUFTLEVBQUU7Z0JBQzVDLElBQUksWUFBWSxHQUEyQixJQUFJLENBQUMsV0FBVyxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsYUFBYSxDQUFDLGtCQUFrQixFQUFFLENBQUMsQ0FBQztnQkFFN0csS0FBSyxJQUFJLElBQUksSUFBSSxZQUFZLEVBQUU7b0JBQzNCLElBQUksWUFBWSxDQUFDLGNBQWMsQ0FBQyxJQUFJLENBQUMsRUFBRTt3QkFDbkMsSUFBSSxXQUFXLEdBQVEsWUFBWSxDQUFDLElBQUksQ0FBQyxDQUFDO3dCQUUxQyxLQUFLLElBQUksUUFBUSxJQUFJLFdBQVcsRUFBRTs0QkFDOUIsSUFBSSxXQUFXLENBQUMsY0FBYyxDQUFDLFFBQVEsQ0FBQyxFQUFFO2dDQUN0QyxJQUFJLE9BQU8sV0FBVyxDQUFDLFFBQVEsQ0FBQyxDQUFDLE1BQU0sS0FBSyxXQUFXLEVBQUU7b0NBQ3JELFdBQVcsQ0FBQyxRQUFRLENBQUMsQ0FBQyxNQUFNLEdBQUcsRUFBRSxDQUFDO2lDQUNyQztnQ0FFRCxXQUFXLENBQUMsUUFBUSxDQUFDLENBQUMsTUFBTSxDQUFDLE1BQU0sR0FBRyxDQUFDLENBQUM7NkJBQzNDO3lCQUNKO3FCQUNKO2lCQUNKO1lBQ0wsQ0FBQyxDQUFDO1NBQ0w7YUFDSTtZQUNELE9BQU8sQ0FBQyxJQUFJLENBQUMseUVBQXlFLENBQUMsQ0FBQztTQUMzRjtJQUNMLENBQUM7SUFFRCx3R0FBd0c7SUFDeEcsa0JBQWtCO0lBQ2xCLHdHQUF3RztJQUNoRyxnQkFBZ0IsQ0FBQyxTQUFpQjtRQUN0QyxJQUFJLE9BQU8sU0FBUyxLQUFLLFdBQVcsSUFBSSxTQUFTLEtBQUssUUFBUSxFQUFFO1lBQzVELElBQUksQ0FBQyxhQUFhLEdBQUcsSUFBSSxnQkFBZ0IsRUFBRSxDQUFDO1NBQy9DO2FBQ0k7WUFDRCxJQUFJLENBQUMsYUFBYSxHQUFHLElBQUksb0JBQW9CLEVBQUUsQ0FBQztTQUNuRDtJQUNMLENBQUM7SUFFTyxpQkFBaUIsQ0FBQyxXQUF5QjtRQUMvQyxJQUFJLENBQUMsTUFBTSxHQUFHLElBQUksQ0FBQyxhQUFhLENBQUMsU0FBUyxDQUFDLFdBQVcsQ0FBQyxDQUFDO1FBRXhELElBQUksQ0FBQyxhQUFhLENBQUMsaUJBQWlCLENBQUMsV0FBVyxDQUFDLENBQUM7UUFDbEQsSUFBSSxDQUFDLGFBQWEsQ0FBQyx3QkFBd0IsQ0FBQyxXQUFXLENBQUMsQ0FBQztJQUM3RCxDQUFDOzs7WUFseUNKLFNBQVMsU0FBQztnQkFDUCxRQUFRLEVBQUUsVUFBVTtnQkFDcEIsdTdCQUFzQztnQkFDdEMsYUFBYSxFQUFFLGlCQUFpQixDQUFDLElBQUk7Z0JBQ3JDLFNBQVMsRUFBRSxDQUFDLFlBQVksRUFBRSxlQUFlLEVBQUUsZ0JBQWdCLEVBQUUsb0JBQW9CLENBQUM7Z0JBQ2xGLElBQUksRUFBRSxFQUFFLE9BQU8sRUFBRSxXQUFXLEVBQUU7YUFDakM7OztZQXBJRyxnQkFBZ0I7WUFJWCxNQUFNO1lBNENOLFlBQVk7WUFKWixlQUFlOzs7a0JBb0huQixLQUFLO3FCQUNMLEtBQUs7cUJBQ0wsS0FBSztrQkFDTCxLQUFLOytCQUdMLE1BQU07MEJBQ04sV0FBVyxTQUFDLGlCQUFpQjs2QkFDN0IsV0FBVyxTQUFDLGlCQUFpQjt1QkFhN0IsWUFBWSxTQUFDLGVBQWUsRUFBRSxDQUFDLFFBQVEsQ0FBQyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7XHJcbiAgICBDb21wb25lbnQsXHJcbiAgICBPbkluaXQsXHJcbiAgICBPbkNoYW5nZXMsXHJcbiAgICBPbkRlc3Ryb3ksXHJcbiAgICBTaW1wbGVDaGFuZ2VzLFxyXG4gICAgVmlld0VuY2Fwc3VsYXRpb24sXHJcbiAgICBJbnB1dCxcclxuICAgIEhvc3RCaW5kaW5nLFxyXG4gICAgSG9zdExpc3RlbmVyLFxyXG4gICAgVmlld0NvbnRhaW5lclJlZixcclxuICAgIEV2ZW50RW1pdHRlcixcclxuICAgIE91dHB1dFxyXG59IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xyXG5pbXBvcnQgeyBSb3V0ZXIgfSBmcm9tICdAYW5ndWxhci9yb3V0ZXInO1xyXG5pbXBvcnQgeyBPYnNlcnZhYmxlLCB0aW1lciwgU3Vic2NyaXB0aW9uLCBTdWJzY3JpYmVyIH0gZnJvbSAncnhqcyc7XHJcbmltcG9ydCB7XHJcbiAgICBHcmlkT3B0aW9ucyxcclxuICAgIFJvd05vZGUsXHJcbiAgICBSb3dFdmVudCxcclxuICAgIE1vZGVsVXBkYXRlZEV2ZW50LFxyXG4gICAgRXhjZWxFeHBvcnRQYXJhbXMsXHJcbiAgICBDb2x1bW4sXHJcbiAgICBHcmlkQXBpLFxyXG4gICAgQ29udGV4dCxcclxuICAgIC8vIENvbERlZixcclxuICAgIC8vIElFbnRlcnByaXNlRGF0YXNvdXJjZSxcclxuICAgIC8vIElFbnRlcnByaXNlR2V0Um93c1BhcmFtcyxcclxufSBmcm9tICdhZy1ncmlkLWNvbW11bml0eSc7XHJcbmltcG9ydCB7XHJcbiAgICAgICAgIElFbnRlcnByaXNlRGF0YXNvdXJjZSxcclxuICAgICAgICAgSUVudGVycHJpc2VHZXRSb3dzUGFyYW1zLFxyXG4gICAgfSBmcm9tICcuL2VudGVycHJpc2UtZGF0YXNvdXJjZSc7IFxyXG5pbXBvcnQgJ2FnLWdyaWQtZW50ZXJwcmlzZSc7XHJcbmltcG9ydCAqIGFzIFhMU1ggZnJvbSAneGxzeCc7XHJcbmltcG9ydCB7IHNhdmVBcyB9IGZyb20gJ2ZpbGUtc2F2ZXInO1xyXG5cclxuaW1wb3J0IHtcclxuICAgIElUYWJsZUNvbHVtbixcclxuICAgIElUYWJsZUNvbmZpZyxcclxuICAgIElTdHlsaW5nQ29uZmlnLFxyXG4gICAgSVRhYmxlUGl2b3RTdGF0ZSxcclxuICAgIElUYWJsZUJ1dHRvbixcclxuICAgIElUYWJsZUNlbGxQYXJhbXMsXHJcbiAgICBJVGFibGVGb3JtRW1pdFBhcmFtcyxcclxuICAgIElUYWJsZURhdGFzb3VyY2VQYXJhbXMsXHJcbiAgICBJVGFibGVBcGksXHJcbiAgICBJVGFibGVEcm9wZG93bkFjdGlvbixcclxuICAgIEtkVGFibGVEYXRhc291cmNlRXZlbnQsXHJcbiAgICBLZFRhYmxlU2VsZWN0aW9uVXBkYXRlRXZlbnQsXHJcbiAgICBLZFRhYmxlSW5wdXRVcGRhdGVFdmVudCxcclxuICAgIEtkVGFibGVCdXR0b25FdmVudFxyXG59IGZyb20gJy4va2QtYW5ndWxhci10YWJsZS1pbnRlcmZhY2UnO1xyXG5cclxuaW1wb3J0IHsgS2RJbnRUYWJsZUV2ZW50IH0gZnJvbSAnLi9rZC1hbmd1bGFyLXRhYmxlLWV2ZW50JztcclxuaW1wb3J0IHsgS2RUYWJsZU5vcm1hbFN2YyB9IGZyb20gJy4vdGFibGUtc2VydmljZXMva2QtdGFibGUtbm9ybWFsLXN2Yyc7XHJcbmltcG9ydCB7IEtkVGFibGVFbnRlcnByaXNlU3ZjIH0gZnJvbSAnLi90YWJsZS1zZXJ2aWNlcy9rZC10YWJsZS1lbnRlcnByaXNlLXN2Yyc7XHJcbi8vIGltcG9ydCB7IEtkU3BsaXR0ZXJFdmVudCB9IGZyb20gJy4uLyc7XHJcbmltcG9ydCB7IEtkRG9tRWxlbVN2YywgQUdfR1JJRF9LRVkgfSBmcm9tICcuLi9rZC1jb21tb24vaW5kZXgnO1xyXG5pbXBvcnQge0xpY2Vuc2VNYW5hZ2VyfSBmcm9tIFwiYWctZ3JpZC1lbnRlcnByaXNlXCI7XHJcblxyXG5kZWNsYXJlIHZhciByZXF1aXJlOiBhbnk7XHJcblxyXG4vKipcclxuICogLS0gRG9jdW1lbnRhdGlvbiBmb3Iga2QtYW5ndWxhci10YWJsZS50cyAoa2QtdGFibGUpXHJcbiAqXHJcbiAqIC0gSG9zdExpc3RlbmVyXHJcbiAqICAgICAtIG9uUmVzaXplXHJcbiAqXHJcbiAqIC0gTGlmZSBjeWNsZXM6XHJcbiAqICAgICAtIG5nT25Jbml0XHJcbiAqICAgICAtIG5nT25DaGFuZ2VzXHJcbiAqICAgICAtIG5nT25EZXN0cm95XHJcblxyXG4gKiAtIGFnLUdyaWQgZXZlbnRzIGZ1bmN0aW9uOlxyXG4gKiAgICAgLSBvbkdyaWRSZWFkeVxyXG4gKiAgICAgLSBvbk1vZGVsVXBkYXRlZFxyXG4gKiAgICAgLSBvblJvd0NsaWNrZWRcclxuICpcclxuICogLSBrZC10YWJsZSBidXR0b24gZnVuY3Rpb246XHJcbiAqICAgICAtIG9uQnV0dG9uQ2xpY2VrZFxyXG4gKlxyXG4gKiAtIFByaXZhdGUgZnVuY3Rpb25zOlxyXG4gKiAgICAgLSBEaXNwbGF5IC8gRE9NIGZ1bmN0aW9uczpcclxuICogICAgICAgICAtIF9yZXNpemVDb2x1bW5cclxuICogICAgICAgICAtIF9zaG93TG9hZGluZ092ZXJsYXlcclxuICogICAgICAgICAtIF91cGRhdGVQYXJlbnROb2RlQ1NTXHJcbiAqICAgICAgICAgLSBfc2V0SGVpZ2h0XHJcbiAqICAgICAgICAgLSBfc2V0TW9iaWxlSGVpZ2h0IChmbGF0dGVuIHRhYmxlKVxyXG4gKiAgICAgICAgIC0gX3NldFdlYkhlaWdociAodXNlciBjb25maWd1cmF0aW9uKVxyXG4gKiAgICAgICAgIC0gX2lzQ2xpY2tWYWxpZCAoY2xpY2sgY29uZmlndXJhdGlvbilcclxuICpcclxuICogICAgIC0gR3JpZCBDeWNsZXM6XHJcbiAqICAgICAgICAgLSBfZ3JpZEluaXRDeWNsZVxyXG4gKiAgICAgICAgIC0gX2dyaWRSZWFkeUN5Y2xlXHJcbiAqICAgICAgICAgLSBfZ3JpZFJlYWR5RW50ZXJwcmlzZUN5Y2xlXHJcbiAqICAgICAgICAgLSBfZ3JpZFJlYWR5RE9NQ3ljbGVcclxuICogICAgICAgICAtIF9ncmlkU2VsZWN0aW9uQ3ljbGVcclxuICogICAgICAgICAtIF9ncmlkU2V0Um93Q3ljbGVcclxuICogICAgICAgICAtIF9ncmlkQ2xpY2tOYXZpZ2F0ZUN5Y2xlXHJcbiAqXHJcbiAqICAgICAtIENvbHVtbiAvIFJvdyAvIENvbmZpZyBnZW5lcmF0aW9ucy9wcm9jZXNzaW5nOlxyXG4gKiAgICAgICAgIC0gX3NldEdyaWRPcHRpb25zXHJcbiAqICAgICAgICAgLSBfc2V0Q29sdW1uRGVmXHJcbiAqICAgICAgICAgLSBfc2V0Um93RGF0YVxyXG4gKlxyXG4gKiAgICAgLSBFdmVudCBmdW5jdGlvbnM6XHJcbiAqICAgICAgICAgLSBfcHJvY2Vzc0V2ZW50UGFyYW1zPFQ+XHJcbiAqICAgICAgICAgLSBfYnJvYWRjYXN0RXZlbnRQYXJhbXNcclxuICogICAgICAgICAtIF9icm9hZGNhc3RNb2RlbENoYW5nZWRcclxuICogICAgICAgICAtIF9zZXR1cFN1YnNjcmlwdGlvbkV2ZW50c1xyXG4gKlxyXG4gKiAgICAgLSBTZWxlY3Rpb24gZnVuY3Rpb25zOlxyXG4gKiAgICAgICAgIC0gX3VwZGF0ZVNlbGVjdGlvbk5vZGVzXHJcbiAqICAgICAgICAgLSBfcHJvY2Vzc0luaXRpYWxTZWxlY3Rpb25cclxuICpcclxuICogICAgIC0gSW5wdXQgZnVuY3Rpb25zOlxyXG4gKiAgICAgICAgIC0gX3Byb2Nlc3NJbnB1dENoYW5nZWRcclxuICogICAgICAgICAtIF9lbWl0SW5wdXRVcGRhdGVFdmVudFxyXG4gKiAgICAgICAgIC0gX2RlbGV0ZU5vZGVGcm9tUm93RGF0YVxyXG4gKlxyXG4gKiAgICAgLSBEYXRhc291cmNlIGZ1bmN0aW9uczpcclxuICogICAgICAgICAtIF9jbGVhckRhdGFzb3VyY2VcclxuICogICAgICAgICAtIF9nZW5lcmF0ZUVudGVycHJpc2VEYXRhc291cmNlXHJcbiAqICAgICAgICAgLSBfZ2VuZXJhdGVEYXRhc291cmNlUm93c1xyXG4gKlxyXG4gKiAgICAgLSBBUEkgZ2VuZXJhdGlvbnM6XHJcbiAqICAgICAgICAgLSBfaW5pdElUYWJsZUFwaSAoVE9ETzogdXBkYXRlIGFwaSBzZXR0aW5nIGFsbCB0byB0YWJsZSBzZXJ2aWNlKVxyXG4gKlxyXG4gKiAgICAgLSBNaXNjIGZ1bmN0aW9uczpcclxuICogICAgICAgICAtIF9pbml0R3JpZFNlcnZpY2VcclxuICogICAgICAgICAtIF91cGRhdGVHcmlkQ29uZmlnXHJcbiAqL1xyXG5cclxuXHJcblxyXG5AQ29tcG9uZW50KHtcclxuICAgIHNlbGVjdG9yOiAna2QtdGFibGUnLFxyXG4gICAgdGVtcGxhdGVVcmw6ICcuL2tkLWFuZ3VsYXItdGFibGUuaHRtbCcsXHJcbiAgICBlbmNhcHN1bGF0aW9uOiBWaWV3RW5jYXBzdWxhdGlvbi5Ob25lLFxyXG4gICAgcHJvdmlkZXJzOiBbS2REb21FbGVtU3ZjLCBLZEludFRhYmxlRXZlbnQsIEtkVGFibGVOb3JtYWxTdmMsIEtkVGFibGVFbnRlcnByaXNlU3ZjXSxcclxuICAgIGhvc3Q6IHsgJ2NsYXNzJzogJ2tkeC10YWJsZScgfVxyXG59KVxyXG5cclxuZXhwb3J0IGNsYXNzIEtkVGFibGUgaW1wbGVtZW50cyBPbkluaXQsIE9uQ2hhbmdlcywgT25EZXN0cm95IHtcclxuICAgIHB1YmxpYyBncmlkSWQ6IHN0cmluZyA9ICcnO1xyXG4gICAgcHVibGljIGdyaWRPcHRpb25zOiBHcmlkT3B0aW9ucztcclxuICAgIHB1YmxpYyBncmlkQXBpOiBHcmlkQXBpOyBcclxuICAgIHB1YmxpYyBkaXNwbGF5TG9hZGluZzogYm9vbGVhbiA9IHRydWU7XHJcblxyXG4gICAgcHJpdmF0ZSBfZW50ZXJwcmlzZSA9IHJlcXVpcmUoJ2FnLWdyaWQtZW50ZXJwcmlzZScpO1xyXG4gICAgcHJpdmF0ZSBfaXNNb2JpbGVWaWV3OiBib29sZWFuO1xyXG4gICAgcHJpdmF0ZSBfdGFibGVTZXJ2aWNlOiBLZFRhYmxlTm9ybWFsU3ZjIHwgS2RUYWJsZUVudGVycHJpc2VTdmM7XHJcbiAgICBwcml2YXRlIF9zdWJzY3JpcHRpb25PYmo6IHsgW2tleTogc3RyaW5nXTogU3Vic2NyaXB0aW9uIH0gPSB7fTtcclxuXHJcbiAgICBwcml2YXRlIF9jdXJyZW50U3RhdGU6IElUYWJsZVBpdm90U3RhdGUgPSB7XHJcbiAgICAgICAgY29sdW1uU3RhdGU6IFtdLFxyXG4gICAgICAgIHBpdm90TW9kZTogZmFsc2UsXHJcbiAgICAgICAgZ3JvdXBTdGF0ZTogW11cclxuICAgIH07XHJcbiAgICBwcml2YXRlIF9pc0NoYW5naW5nU3RhdGU6IGJvb2xlYW4gPSBmYWxzZTtcclxuICAgIHByaXZhdGUgX3Bpdm90RWxlbWVudDogeyBba2V5OiBzdHJpbmddOiBhbnkgfSA9IHtcclxuICAgICAgICAncGl2b3QnOiBudWxsLFxyXG4gICAgICAgICdjb2x1bW4tZHJvcCc6IG51bGxcclxuICAgIH07XHJcbiAgICBwcml2YXRlIF9wcmV2aW91c1Rvb2xwYW5lbFR5cGU6ICdub25lJyB8ICdjb2x1bW5zJyB8ICdwaXZvdCc7XHJcbiAgICBwcml2YXRlIF9zdXBwcmVzc01vdmFibGVDb2x1bW5zOiBib29sZWFuID0gdHJ1ZTtcclxuXHJcbiAgICBwcml2YXRlIF9kaXJlY3Rpb246ICdsdHInIHwgJ3J0bCcgPSAnbHRyJztcclxuXHJcbiAgICBASW5wdXQoKSByb3c6IEFycmF5PGFueT47XHJcbiAgICBASW5wdXQoKSBjb2x1bW46IEFycmF5PElUYWJsZUNvbHVtbj47XHJcbiAgICBASW5wdXQoKSBjb25maWc6IElUYWJsZUNvbmZpZztcclxuICAgIEBJbnB1dCgpIGFwaTogSVRhYmxlQXBpO1xyXG4gICAgLy8gQElucHV0KCkgY29udGV4dDogQ29udGV4dDtcclxuICAgIC8vIEBJbnB1dCgpIGdyaWRPcHRpb246IEdyaWRPcHRpb25zO1xyXG4gICAgQE91dHB1dCgpIG9uRXhwb3J0UG9zc2libGU6IEV2ZW50RW1pdHRlcjxib29sZWFuPiA9IG5ldyBFdmVudEVtaXR0ZXIoKTtcclxuICAgIEBIb3N0QmluZGluZygnY2xhc3MuZnVsbC1ncmlkJykgZGlzcGxheUZ1bGw6IGJvb2xlYW47XHJcbiAgICBASG9zdEJpbmRpbmcoJ2NsYXNzLmtkeC10YWJsZScpIF9jbGFzc0tkeFRhYmxlOiBib29sZWFuID0gdHJ1ZTtcclxuICAgIFxyXG4gICAgcHVibGljIGRlZmF1bHRDb2xEZWY6YW55O1xyXG4gICAgY29uc3RydWN0b3IoXHJcbiAgICAgICAgcHJpdmF0ZSBfdmNyOiBWaWV3Q29udGFpbmVyUmVmLFxyXG4gICAgICAgIHByaXZhdGUgX3JvdXRlcjogUm91dGVyLFxyXG4gICAgICAgIHByaXZhdGUgX2RvbVN2YzogS2REb21FbGVtU3ZjLFxyXG4gICAgICAgIC8vIHByaXZhdGUgX3NwbGl0dGVyRXZlbnQ6IEtkU3BsaXR0ZXJFdmVudCxcclxuICAgICAgICBwcml2YXRlIF90YWJsZUludEV2ZW50OiBLZEludFRhYmxlRXZlbnQsXHJcbiAgICApIHtcclxuICAgICAgICBMaWNlbnNlTWFuYWdlci5zZXRMaWNlbnNlS2V5KEFHX0dSSURfS0VZLnZhbHVlKTtcclxuICAgIH1cclxuXHJcbiAgICBASG9zdExpc3RlbmVyKCd3aW5kb3c6cmVzaXplJywgWyckZXZlbnQnXSlcclxuICAgIG9uUmVzaXplKF9ldmVudDogRXZlbnQpOiB2b2lkIHtcclxuICAgICAgICB0aGlzLl9zZXRIZWlnaHQoKTtcclxuICAgIH1cclxuXHJcbiAgICAvKioqKioqKioqKioqKioqKioqKioqKioqKiBMaWZlIGN5Y2xlcyBmdW5jdGlvbnMgKioqKioqKioqKioqKioqKioqKioqKioqKioqKiovXHJcbiAgICBuZ09uSW5pdCgpOiB2b2lkIHtcclxuICAgICAgICAvLyBjb25zb2xlLmxvZyhcIi0tIEdyaWQgc3RhdGU6IEluaXQgLS1cIiwgdGhpcy5yb3csIHRoaXMuY29sdW1uLCB0aGlzLmNvbmZpZywgdGhpcy5hcGkpO1xyXG4gICAgICAgIHRoaXMuX3Nob3dMb2FkaW5nT3ZlcmxheSh0cnVlKTtcclxuICAgICAgICB0aGlzLl9ncmlkSW5pdEN5Y2xlKCk7XHJcbiAgICB9XHJcblxyXG4gICAgbmdPbkNoYW5nZXMoX3NpbXBsZUNoYW5nZXM6IFNpbXBsZUNoYW5nZXMpOiB2b2lkIHtcclxuICAgICAgICB0aGlzLl9zaG93TG9hZGluZ092ZXJsYXkodHJ1ZSk7XHJcbiAgICAgICAgY29uc29sZS5sb2coXCItLSBHcmlkIHN0YXRlOiBDaGFuZ2UgLS0gXCIsIF9zaW1wbGVDaGFuZ2VzKTtcclxuXHJcbiAgICAgICAgaWYgKHR5cGVvZiBfc2ltcGxlQ2hhbmdlcy5jb2x1bW4gIT09ICd1bmRlZmluZWQnICYmXHJcbiAgICAgICAgICAgICFfc2ltcGxlQ2hhbmdlcy5jb2x1bW4uZmlyc3RDaGFuZ2VcclxuICAgICAgICApIHtcclxuICAgICAgICAgICAgdGhpcy5fc2V0Q29sdW1uRGVmKF9zaW1wbGVDaGFuZ2VzLmNvbHVtbi5jdXJyZW50VmFsdWUpO1xyXG4gICAgICAgICAgICB0aGlzLl9zaG93TG9hZGluZ092ZXJsYXkoZmFsc2UpO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgaWYgKHR5cGVvZiBfc2ltcGxlQ2hhbmdlcy5yb3cgIT09ICd1bmRlZmluZWQnICYmXHJcbiAgICAgICAgICAgICFfc2ltcGxlQ2hhbmdlcy5yb3cuZmlyc3RDaGFuZ2VcclxuICAgICAgICApIHtcclxuICAgICAgICAgICAgdGhpcy5fc2V0Um93RGF0YShfc2ltcGxlQ2hhbmdlcy5yb3cuY3VycmVudFZhbHVlKTtcclxuICAgICAgICAgICAgdGhpcy5fc2hvd0xvYWRpbmdPdmVybGF5KGZhbHNlKTtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIGlmICh0eXBlb2YgX3NpbXBsZUNoYW5nZXMuY29uZmlnICE9PSAndW5kZWZpbmVkJykge1xyXG4gICAgICAgICAgICB0aGlzLl9zaG93TG9hZGluZ092ZXJsYXkoZmFsc2UpO1xyXG4gICAgICAgICAgICB0aGlzLnVwZGF0ZVN0eWxlKF9zaW1wbGVDaGFuZ2VzLmNvbmZpZy5jdXJyZW50VmFsdWUpO1xyXG5cclxuICAgICAgICAgICAgdGltZXIoMTAwKS5zdWJzY3JpYmUoKCk6IHZvaWQgPT4ge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5fY29uZmlndXJlUGl2b3REaXNwbGF5KCk7XHJcblxyXG4gICAgICAgICAgICAgICAgaWYgKHR5cGVvZiB0aGlzLmNvbmZpZy5zdXBwcmVzc01vdmFibGVDb2x1bW5zICE9PSAndW5kZWZpbmVkJ1xyXG4gICAgICAgICAgICAgICAgKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKHRoaXMuY29uZmlnLnN1cHByZXNzTW92YWJsZUNvbHVtbnMgIT09IHRoaXMuX3N1cHByZXNzTW92YWJsZUNvbHVtbnMpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuX2VuYWJsZUNvbHVtbk1vdmFibGUodGhpcy5jb25maWcuc3VwcHJlc3NNb3ZhYmxlQ29sdW1ucyk7XHJcbiAgICAgICAgICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuY29uZmlnLnN1cHByZXNzTW92YWJsZUNvbHVtbnMgPSB0aGlzLl9zdXBwcmVzc01vdmFibGVDb2x1bW5zO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9KTtcclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgbmdPbkRlc3Ryb3koKTogdm9pZCB7XHJcbiAgICAgICAgLy8gY29uc29sZS5sb2coXCItLSBHcmlkIHN0YXRlOiBEZXN0cm95aW5nIC0tXCIpO1xyXG4gICAgICAgIGZvciAobGV0IGl0ZW0gaW4gdGhpcy5fc3Vic2NyaXB0aW9uT2JqKSB7XHJcbiAgICAgICAgICAgIGlmICh0eXBlb2YgdGhpcy5fc3Vic2NyaXB0aW9uT2JqW2l0ZW1dICE9PSAndW5kZWZpbmVkJykge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5fc3Vic2NyaXB0aW9uT2JqW2l0ZW1dLnVuc3Vic2NyaWJlKCk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgc2V0QXR0ZW5kYW5jZShkaXNwbGF5RWRpdFRhYmxlLCBfY29uZmlnOiBJVGFibGVDb25maWcpe1xyXG4gICAgICAgIC8vIGxldCBhbGxDb2x1bW5zID0gdGhpcy5ncmlkT3B0aW9ucy5jb2x1bW5BcGkuZ2V0QWxsQ29sdW1ucygpXHJcblxyXG4gICAgICAgIC8vIGFsbENvbHVtbnMuZm9yRWFjaCgoY29sdW1uLCBpbmRleCkgPT4ge1xyXG4gICAgICAgIC8vICAgICBsZXQgY3VycmVudENvbHVtbkRlZiA9IGNvbHVtbi5nZXRDb2xEZWYoKVxyXG4gICAgICAgIC8vICAgICBjb25zb2xlLmxvZyhgY29sdW1uICR7aW5kZXgrMX1gLCBjdXJyZW50Q29sdW1uRGVmKVxyXG4gICAgICAgIC8vIH0pXHJcbiAgICAgICAgaWYgKGRpc3BsYXlFZGl0VGFibGUpIHtcclxuICAgICAgICAgICAgdGhpcy5ncmlkT3B0aW9ucy5jb250ZXh0Lm1vZGUgPSAnZWRpdCdcclxuICAgICAgICAgICAgX2NvbmZpZy5jb250ZXh0Lm1vZGUgPSAnZWRpdCc7XHJcbiAgICAgICAgICAgIF9jb25maWcucm93Q29udGVudEhlaWdodCA9IDEyMFxyXG4gICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgIHRoaXMuZ3JpZE9wdGlvbnMuY29udGV4dC5tb2RlID0gJ3ZpZXcnXHJcbiAgICAgICAgICAgIF9jb25maWcuY29udGV4dC5tb2RlID0gJ3ZpZXcnO1xyXG4gICAgICAgIH1cclxuICAgICAgICBcclxuICAgICAgICBsZXQgX2NvbHVtbnMgPSB0aGlzLmdyaWRPcHRpb25zLmNvbHVtbkFwaS5nZXRBbGxEaXNwbGF5ZWRDb2x1bW5zKCk7XHJcbiAgICAgICAgLy8gbGV0IGNvbERlZiA9IF9jb2x1bW5zWzJdLmdldENvbERlZigpXHJcbiAgICAgICAgLy8gY29uc29sZS5sb2coY29sRGVmKTtcclxuICAgICAgICAvLyBjb2xEZWYuY2VsbFJlbmRlcmVyUGFyYW1zID0gJzxwPkhlbGxvPC9wPidcclxuICAgICAgICAvLyBsZXQgbmV3RGF0YSA9IFtdXHJcbiAgICAgICAgLy8gbmV3RGF0YS5wdXNoKGNvbERlZilcclxuICAgICAgICB0aGlzLmdyaWRPcHRpb25zLmNvbHVtbkFwaS5zZXRWYWx1ZUNvbHVtbnMoX2NvbHVtbnMpXHJcbiAgICB9XHJcblxyXG4gICAgc2V0QXR0ZW5kYW5jZVN0YWZmKGRpc3BsYXlFZGl0VGFibGUpe1xyXG4gICAgICAgIGlmIChkaXNwbGF5RWRpdFRhYmxlKSB7XHJcbiAgICAgICAgICAgIHRoaXMuZ3JpZE9wdGlvbnMuY29udGV4dC5hY3Rpb24gPSAnZWRpdCc7XHJcbiAgICAgICAgfWVsc2Uge1xyXG4gICAgICAgICAgICB0aGlzLmdyaWRPcHRpb25zLmNvbnRleHQuYWN0aW9uID0gJ3ZpZXcnO1xyXG4gICAgICAgIH1cclxuICAgICAgICBsZXQgX2NvbHVtbnMgPSB0aGlzLmdyaWRPcHRpb25zLmNvbHVtbkFwaS5nZXRBbGxEaXNwbGF5ZWRDb2x1bW5zKCk7XHJcbiAgICAgICAgdGhpcy5ncmlkT3B0aW9ucy5jb2x1bW5BcGkuc2V0VmFsdWVDb2x1bW5zKF9jb2x1bW5zKVxyXG4gICAgfVxyXG5cclxuICAgIHNldFN0dWRlbnRNZWFsKGRpc3BsYXlFZGl0VGFibGUpe1xyXG4gICAgICAgIGlmIChkaXNwbGF5RWRpdFRhYmxlKSB7XHJcbiAgICAgICAgICAgIHRoaXMuZ3JpZE9wdGlvbnMuY29udGV4dC5tb2RlID0gJ2VkaXQnO1xyXG4gICAgICAgIH1lbHNlIHtcclxuICAgICAgICAgICAgdGhpcy5ncmlkT3B0aW9ucy5jb250ZXh0Lm1vZGUgPSAndmlldyc7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGxldCBfY29sdW1ucyA9IHRoaXMuZ3JpZE9wdGlvbnMuY29sdW1uQXBpLmdldEFsbERpc3BsYXllZENvbHVtbnMoKTtcclxuICAgICAgICB0aGlzLmdyaWRPcHRpb25zLmNvbHVtbkFwaS5zZXRWYWx1ZUNvbHVtbnMoX2NvbHVtbnMpXHJcbiAgICB9XHJcblxyXG4gICAgLyoqKioqKioqKioqKioqKioqKioqKioqKioqKioqKiogR3JpZCBldmVudHMgKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqL1xyXG4gICAgcHVibGljIG9uR3JpZFJlYWR5KF9wYXJhbXM6IGFueSk6IHZvaWQge1xyXG4gICAgICAgIC8vIGNvbnNvbGUubG9nKCctLSBHcmlkIHN0YXRlOiBSZWFkeSAtLScsIHRoaXMuZ3JpZE9wdGlvbnMpO1xyXG4gICAgICAgIHRoaXMuX2dyaWRSZWFkeUN5Y2xlKCk7XHJcblxyXG4gICAgICAgIFxyXG4gICAgfVxyXG5cclxuICAgIHB1YmxpYyBvbk1vZGVsVXBkYXRlZChfZXZlbnQ6IE1vZGVsVXBkYXRlZEV2ZW50KTogdm9pZCB7XHJcbiAgICAgICAgLy8vIEZvciBzZWxlY3QgYWxsIGNoZWNrYm94IGNoZWNraW5nIG9uIGNoYW5nZSBwYWdpbmF0aW9uL3VwZGF0ZSByb3cgZGF0YVxyXG4gICAgICAgIGlmICh0aGlzLl90YWJsZVNlcnZpY2UuaGFzU2VsZWN0aW9uQWxsKHRoaXMuY29uZmlnKSkge1xyXG4gICAgICAgICAgICB0aGlzLl9icm9hZGNhc3RNb2RlbENoYW5nZWRFdmVudCgpO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgaWYgKHRoaXMuX2lzTW9iaWxlVmlldykge1xyXG4gICAgICAgICAgICBsZXQgZ3JpZEVsZW1lbnQ6IEVsZW1lbnQgPSBkb2N1bWVudC5xdWVyeVNlbGVjdG9yKCcjJyArIHRoaXMuZ3JpZElkICsgJy5zdGctdGhlbWUnKTtcclxuXHJcbiAgICAgICAgICAgIGlmIChncmlkRWxlbWVudCAhPT0gbnVsbCkge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5fc2V0TW9iaWxlSGVpZ2h0KGdyaWRFbGVtZW50KTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICBwdWJsaWMgb25Sb3dDbGlja2VkKF9wYXJhbXM6IFJvd0V2ZW50KTogdm9pZCB7XHJcbiAgICAgICAgLy8gY29uc29sZS5sb2coXCItLSBHcmlkIHN0YXRlOiBSb3cgY2xpY2tlZCAtLVwiLCBfcGFyYW1zKTtcclxuICAgICAgICBpZiAodGhpcy5faXNDbGlja1ZhbGlkKF9wYXJhbXMuZXZlbnQpICYmIHR5cGVvZiB0aGlzLmNvbmZpZy5jbGljayAhPT0gJ3VuZGVmaW5lZCcpIHtcclxuICAgICAgICAgICAgc3dpdGNoICh0aGlzLmNvbmZpZy5jbGljay50eXBlKSB7XHJcbiAgICAgICAgICAgICAgICBjYXNlICdzZWxlY3Rpb24nOlxyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuX2dyaWRTZWxlY3Rpb25DeWNsZShfcGFyYW1zLm5vZGUpO1xyXG4gICAgICAgICAgICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgICAgICAgICAgY2FzZSAncm91dGVyJzpcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLl9ncmlkQ2xpY2tOYXZpZ2F0ZUN5Y2xlKF9wYXJhbXMubm9kZSk7XHJcbiAgICAgICAgICAgICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgICAgICAgICBkZWZhdWx0OlxyXG4gICAgICAgICAgICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICBpZiAodHlwZW9mIHRoaXMuY29uZmlnLmNsaWNrLmNhbGxiYWNrICE9PSAndW5kZWZpbmVkJykge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5jb25maWcuY2xpY2suY2FsbGJhY2soKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICAvKioqKioqKioqKioqKioqKioqKioqKioqKioqKiogQnV0dG9uIGZ1bmN0aW9ucyAqKioqKioqKioqKioqKioqKioqKioqKioqKioqKiovXHJcbiAgICBwdWJsaWMgb25CdXR0b25DbGlja2VkKF9idXR0b246IElUYWJsZUJ1dHRvbik6IHZvaWQge1xyXG4gICAgICAgIGxldCBidXR0b25FdmVudDogS2RUYWJsZUJ1dHRvbkV2ZW50ID0gbmV3IEtkVGFibGVCdXR0b25FdmVudChfYnV0dG9uKTtcclxuICAgICAgICB0aGlzLl9wcm9jZXNzRXZlbnRQYXJhbXM8S2RUYWJsZUJ1dHRvbkV2ZW50PignYnV0dG9uJywgYnV0dG9uRXZlbnQpO1xyXG4gICAgfVxyXG5cclxuICAgIC8qKioqKioqKioqKioqKioqKioqKioqKioqKioqIFByaXZhdGUgZnVuY3Rpb25zICoqKioqKioqKioqKioqKioqKioqKioqKioqKioqKi9cclxuICAgIC8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vXHJcbiAgICAvLy8gR3JpZCBjeWNsZXNcclxuICAgIC8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vXHJcbiAgICBwcml2YXRlIF9ncmlkSW5pdEN5Y2xlKCk6IHZvaWQge1xyXG4gICAgICAgIGlmICh0eXBlb2YgdGhpcy5jb25maWcgIT09ICd1bmRlZmluZWQnKSB7XHJcbiAgICAgICAgICAgIHRoaXMuX2luaXRHcmlkU2VydmljZSh0aGlzLmNvbmZpZy5sb2FkVHlwZSk7XHJcbiAgICAgICAgICAgIHRoaXMuX3VwZGF0ZUdyaWRDb25maWcodGhpcy5jb25maWcpO1xyXG4gICAgICAgICAgICB0aGlzLl9zZXRHcmlkT3B0aW9ucyh0aGlzLmNvbmZpZyk7XHJcbiAgICAgICAgICAgIHRoaXMuX3NldHVwU3Vic2NyaXB0aW9uRXZlbnRzKCk7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICBpZiAodHlwZW9mIHRoaXMuY29sdW1uICE9PSAndW5kZWZpbmVkJykge1xyXG4gICAgICAgICAgICB0aGlzLl9zZXRDb2x1bW5EZWYodGhpcy5jb2x1bW4pO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgaWYgKHR5cGVvZiB0aGlzLnJvdyAhPT0gJ3VuZGVmaW5lZCcpIHtcclxuICAgICAgICAgICAgdGhpcy5fc2V0Um93RGF0YSh0aGlzLnJvdyk7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX2dyaWRSZWFkeUN5Y2xlKCk6IHZvaWQge1xyXG4gICAgICAgIHRoaXMuX2luaXRJVGFibGVBcGkoKTtcclxuXHJcbiAgICAgICAgaWYgKHRoaXMuX3RhYmxlU2VydmljZS5pc0VudGVycHJpc2VNb2RlbCh0aGlzLmNvbmZpZy5sb2FkVHlwZSkpIHtcclxuICAgICAgICAgICAgdGhpcy5fZ3JpZFJlYWR5RW50ZXJwcmlzZUN5Y2xlKCk7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICB0aGlzLl9ncmlkUmVhZHlET01DeWNsZSgpO1xyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX2dyaWRSZWFkeUVudGVycHJpc2VDeWNsZSgpOiB2b2lkIHtcclxuICAgICAgICB0aGlzLl9jbGVhckRhdGFzb3VyY2UoKTtcclxuICAgICAgICB0aGlzLl9nZW5lcmF0ZUVudGVycHJpc2VEYXRhc291cmNlKCk7XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfZ3JpZFJlYWR5RE9NQ3ljbGUoKTogdm9pZCB7XHJcbiAgICAgICAgdGhpcy5fdXBkYXRlUGFyZW50Tm9kZUNTUygpO1xyXG4gICAgICAgIHRoaXMuX3NldEhlaWdodCgpO1xyXG4gICAgICAgIHRoaXMuX3Jlc2l6ZUNvbHVtbigpO1xyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX2dyaWRTZWxlY3Rpb25DeWNsZShfcm93Tm9kZTogUm93Tm9kZSk6IHZvaWQge1xyXG4gICAgICAgIGlmICh0eXBlb2YgdGhpcy5jb25maWcuc2VsZWN0aW9uID09PSAndW5kZWZpbmVkJykge1xyXG4gICAgICAgICAgICBjb25zb2xlLmVycm9yKCdLZFRhYmxlIGVycm9yOiBVc2VyIGhhdmUgc2V0IGNsaWNrIHR5cGUgdG8gYmUgc2VsZWN0aW9uIGJ1dCBubyBzZWxlY3Rpb24gaXMgZGVmaW5lZC4gRG8geW91IG1lYW4gY2xpY2sgdHlwZSB0byByb3V0ZXI/Jyk7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGVsc2UgaWYgKHRoaXMuY29uZmlnLnNlbGVjdGlvbi50eXBlID09PSAnc2luZ2xlJykge1xyXG4gICAgICAgICAgICBpZiAodGhpcy5jb25maWcuc2VsZWN0aW9uLnZhbHVlLmluZGV4T2YoX3Jvd05vZGUuaWQpIDwgMCkge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5ncmlkT3B0aW9ucy5hcGkuZGVzZWxlY3RBbGwoKTtcclxuICAgICAgICAgICAgICAgIF9yb3dOb2RlLnNlbGVjdFRoaXNOb2RlKHRydWUpO1xyXG5cclxuICAgICAgICAgICAgICAgIHRoaXMuY29uZmlnLnNlbGVjdGlvbi52YWx1ZS5zcGxpY2UoMCwgdGhpcy5jb25maWcuc2VsZWN0aW9uLnZhbHVlLmxlbmd0aCk7XHJcbiAgICAgICAgICAgICAgICB0aGlzLmNvbmZpZy5zZWxlY3Rpb24udmFsdWUucHVzaChfcm93Tm9kZS5kYXRhLmlkKTtcclxuXHJcbiAgICAgICAgICAgICAgICB0aGlzLl9icm9hZGNhc3RNb2RlbENoYW5nZWRFdmVudCgpO1xyXG4gICAgICAgICAgICAgICAgdGhpcy5fdXBkYXRlU2VsZWN0aW9uTm9kZXMoX3Jvd05vZGUpO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICBsZXQgc2VsZWN0aW9uOiBib29sZWFuID0gIV9yb3dOb2RlLmlzU2VsZWN0ZWQoKTtcclxuICAgICAgICAgICAgX3Jvd05vZGUuc2VsZWN0VGhpc05vZGUoc2VsZWN0aW9uKTtcclxuXHJcbiAgICAgICAgICAgIHRoaXMuX2Jyb2FkY2FzdE1vZGVsQ2hhbmdlZEV2ZW50KCk7XHJcblxyXG4gICAgICAgICAgICBpZiAoc2VsZWN0aW9uKSB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLmNvbmZpZy5zZWxlY3Rpb24udmFsdWUucHVzaChfcm93Tm9kZS5kYXRhLmlkKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgICAgIHRoaXMuY29uZmlnLnNlbGVjdGlvbi52YWx1ZS5zcGxpY2UodGhpcy5jb25maWcuc2VsZWN0aW9uLnZhbHVlLmluZGV4T2YoX3Jvd05vZGUuZGF0YS5pZCksIDEpO1xyXG4gICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICB0aGlzLl91cGRhdGVTZWxlY3Rpb25Ob2Rlcyhfcm93Tm9kZSk7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX2dyaWRTZXRSb3dDeWNsZSgpOiB2b2lkIHtcclxuICAgICAgICBpZiAodHlwZW9mIHRoaXMuY29uZmlnLnNlbGVjdGlvbiAhPT0gJ3VuZGVmaW5lZCcgJiYgdHlwZW9mIHRoaXMuY29uZmlnLnNlbGVjdGlvbi50eXBlICE9PSAndW5kZWZpbmVkJykge1xyXG4gICAgICAgICAgICB0aGlzLl9wcm9jZXNzSW5pdGlhbFNlbGVjdGlvbigpO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgZWxzZSBpZiAodGhpcy5fdGFibGVTZXJ2aWNlLmhhc0lucHV0VHlwZSh0aGlzLmNvbHVtbiwgJ2lucHV0JykpIHtcclxuICAgICAgICAgICAgdGhpcy5fZW1pdElucHV0VXBkYXRlRXZlbnQoKTtcclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfZ3JpZENsaWNrTmF2aWdhdGVDeWNsZShfcm93Tm9kZTogUm93Tm9kZSk6IHZvaWQge1xyXG4gICAgICAgIGlmICh0eXBlb2YgdGhpcy5jb25maWcuY2xpY2sucGF0aE1hcCAhPT0gJ3VuZGVmaW5lZCcpIHtcclxuICAgICAgICAgICAgaWYgKHR5cGVvZiB0aGlzLmNvbmZpZy5hY3Rpb24gIT09ICd1bmRlZmluZWQnICYmXHJcbiAgICAgICAgICAgICAgICB0eXBlb2YgdGhpcy5jb25maWcuYWN0aW9uLmxpc3QgIT09ICd1bmRlZmluZWQnKSB7XHJcbiAgICAgICAgICAgICAgICBsZXQgcm91dGVyUGF0aDogc3RyaW5nID0gJyc7XHJcblxyXG4gICAgICAgICAgICAgICAgZm9yIChsZXQgaTogbnVtYmVyID0gMDsgaSA8IHRoaXMuY29uZmlnLmFjdGlvbi5saXN0Lmxlbmd0aDsgKytpKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgbGV0IGFjdGlvbkl0ZW06IElUYWJsZURyb3Bkb3duQWN0aW9uID0gdGhpcy5jb25maWcuYWN0aW9uLmxpc3RbaV07XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIGlmIChhY3Rpb25JdGVtLnR5cGUudG9Mb3dlckNhc2UoKSA9PT0gdGhpcy5jb25maWcuY2xpY2sucGF0aE1hcC50b0xvd2VyQ2FzZSgpKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHJvdXRlclBhdGggPSB0aGlzLl90YWJsZVNlcnZpY2UuZ2V0Um91dGVyUGxhY2Vob2xkZXJQYXRoKF9yb3dOb2RlLCBhY3Rpb25JdGVtLnBhdGgpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBicmVhaztcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICAgICAgaWYgKHJvdXRlclBhdGggIT09ICcnKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5fcm91dGVyLm5hdmlnYXRlKFtyb3V0ZXJQYXRoXSk7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgICAgICAgICBjb25zb2xlLndhcm4oJ0tkVGFibGUgd2FybmluZzogVGFibGUgcm91dGVyIHBhdGhNYXAgbm90IGZvdW5kLiBwYXRoTWFwIHNldCB0bzonLCB0aGlzLmNvbmZpZy5jbGljay5wYXRoTWFwKTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgICAgIGNvbnNvbGUuZXJyb3IoJ0tkVGFibGUgZXJyb3I6IFRhYmxlIGNsaWNrIGV2ZW50IHNldCB0byByb3V0ZXIgcGF0aE1hcCBidXQgbm8gYWN0aW9uIGxpc3QgaXMgZGVmaW5lZC4gRG8geW91IG1lYW4gcGF0aCBwcm9wZXJ0eSBpbnN0ZWFkIG9mIHBhdGhNYXAgcHJvcGVydHk/Jyk7XHJcbiAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgfVxyXG4gICAgICAgIGVsc2UgaWYgKHR5cGVvZiB0aGlzLmNvbmZpZy5jbGljay5wYXRoICE9PSAndW5kZWZpbmVkJykge1xyXG4gICAgICAgICAgICB0aGlzLl9yb3V0ZXIubmF2aWdhdGUoW3RoaXMuY29uZmlnLmNsaWNrLnBhdGhdKTtcclxuICAgICAgICB9XHJcbiAgICAgICAgZWxzZSB7XHJcbiAgICAgICAgICAgIGNvbnNvbGUuZXJyb3IoJ0tkVGFibGUgZXJyb3I6IFRhYmxlIGNsaWNrIGV2ZW50IHR5cGUgc2V0IGF0IHJvdXRlciBidXQgbm8gcGF0aCAvIHBhdGhNYXAgaXMgcHJvdmlkZWQuIERvIHlvdSBtZWFuIGNsaWNrIHR5cGUgc2VsZWN0aW9uIC8gbm9uZT8nKTtcclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy9cclxuICAgIC8vIERpc3BsYXkgLyBET00gZnVuY3Rpb25cclxuICAgIC8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vXHJcblxyXG4gICAgcHJpdmF0ZSBfc2hvd0xvYWRpbmdPdmVybGF5KF90b2dnbGU6IGJvb2xlYW4pOiB2b2lkIHtcclxuICAgICAgICB0aGlzLmRpc3BsYXlMb2FkaW5nID0gX3RvZ2dsZTtcclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF91cGRhdGVQYXJlbnROb2RlQ1NTKCk6IHZvaWQge1xyXG4gICAgICAgIHRoaXMuX3Zjci5lbGVtZW50Lm5hdGl2ZUVsZW1lbnQucGFyZW50Tm9kZS5jbGFzc05hbWUgKz0gJyBoYXMtYWdncmlkJztcclxuICAgICAgICBpZiAodGhpcy5fZGlyZWN0aW9uID09PSAncnRsJykgZG9jdW1lbnQucXVlcnlTZWxlY3RvcignYm9keScpLnN0eWxlLmNzc1RleHQgKz0gJy0ta2R0YWJsZS1oZWFkZXItdGV4dC1hbGlnbjogcmlnaHQ7JztcclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF9zZXRIZWlnaHQoKTogdm9pZCB7XHJcbiAgICAgICAgbGV0IGRvbUVsZVF1ZXJ5OiBzdHJpbmcgPSAnIycgKyB0aGlzLmdyaWRJZCArICcuc3RnLXRoZW1lJztcclxuICAgICAgICBsZXQgZ3JpZEVsZW1lbnQ6IEVsZW1lbnQgPSB0aGlzLl92Y3IuZWxlbWVudC5uYXRpdmVFbGVtZW50LnF1ZXJ5U2VsZWN0b3IoZG9tRWxlUXVlcnkpO1xyXG5cclxuICAgICAgICBpZiAoZ3JpZEVsZW1lbnQgIT09IG51bGwpIHtcclxuICAgICAgICAgICAgbGV0IHdpbmRvd3NXaWR0aDogbnVtYmVyID0gZG9jdW1lbnQuYm9keS5jbGllbnRXaWR0aDtcclxuXHJcbiAgICAgICAgICAgIGlmICh3aW5kb3dzV2lkdGggPD0gMTAyNCkge1xyXG4gICAgICAgICAgICAgICAgaWYgKHR5cGVvZiB0aGlzLl9pc01vYmlsZVZpZXcgPT09ICd1bmRlZmluZWQnIHx8ICF0aGlzLl9pc01vYmlsZVZpZXcpIHtcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLl9zaG93TG9hZGluZ092ZXJsYXkodHJ1ZSk7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5faXNNb2JpbGVWaWV3ID0gdHJ1ZTtcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLl9zZXRNb2JpbGVIZWlnaHQoZ3JpZEVsZW1lbnQpO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIGVsc2UgaWYgKHdpbmRvd3NXaWR0aCA+IDEwMjQpIHtcclxuICAgICAgICAgICAgICAgIGlmICh0eXBlb2YgdGhpcy5faXNNb2JpbGVWaWV3ID09PSAndW5kZWZpbmVkJyB8fCB0aGlzLl9pc01vYmlsZVZpZXcpIHtcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLl9zaG93TG9hZGluZ092ZXJsYXkodHJ1ZSk7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5faXNNb2JpbGVWaWV3ID0gZmFsc2U7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5fc2V0V2ViR3JpZEhlaWdodChncmlkRWxlbWVudCwgdGhpcy5jb25maWcuZ3JpZEhlaWdodCk7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLmdyaWRPcHRpb25zLmFwaS5zaXplQ29sdW1uc1RvRml0KCk7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgLyoqXHJcbiAgICAgKiBhZGQgYm9yZGVyIGJvdHRvbSBkeW5hbWljYWxseSBzbyB0aGF0IHdoZW4gdGhlIHJvdyBpcyBsZXNzZXIgdGhhbiBib2R5LWNvbnRhaW5lciwgdGhlcmUgd29udCBiZSBhbnkgaGFuZ2luZyBib3JkZXIgYm90dG9tXHJcbiAgICAgKiB3aGVuIHRoZSByb3cgaXMgbW9yZSB0aGFuIGNvbnRhaW5lciwgdGhlcmUgd2lsbCBiZSBhIGJvcmRlci1ib3R0b21cclxuICAgICAqL1xyXG4gICAgcHJpdmF0ZSBfc2V0VGFibGVCb3JkZXJCb3R0b20oKTogdm9pZCB7XHJcbiAgICAgICAgbGV0IGNvbnRhaW5lckVsZVF1ZXJ5OiBzdHJpbmcgPSAnIC5hZy1ib2R5LWNvbnRhaW5lcic7XHJcbiAgICAgICAgbGV0IGNvbnRhaW5lckVsZTogRWxlbWVudCA9IHRoaXMuX3Zjci5lbGVtZW50Lm5hdGl2ZUVsZW1lbnQucXVlcnlTZWxlY3Rvcihjb250YWluZXJFbGVRdWVyeSk7XHJcbiAgICAgICAgaWYgKGNvbnRhaW5lckVsZSA9PT0gbnVsbCkgcmV0dXJuO1xyXG5cclxuICAgICAgICBsZXQgdmlld3BvcnRFbGVRdWVyeTogc3RyaW5nID0gJyAuYWctYm9keS12aWV3cG9ydCc7XHJcbiAgICAgICAgbGV0IHZpZXdwb3J0RWxlOiBFbGVtZW50ID0gdGhpcy5fdmNyLmVsZW1lbnQubmF0aXZlRWxlbWVudC5xdWVyeVNlbGVjdG9yKHZpZXdwb3J0RWxlUXVlcnkpO1xyXG5cclxuICAgICAgICBpZiAoY29udGFpbmVyRWxlLmNsaWVudEhlaWdodCA+IHZpZXdwb3J0RWxlLmNsaWVudEhlaWdodCAmJlxyXG4gICAgICAgICAgICB2aWV3cG9ydEVsZS5jbGFzc05hbWUgJiZcclxuICAgICAgICAgICAgdmlld3BvcnRFbGUuY2xhc3NOYW1lLmluZGV4T2YoJ2hhcy1ib3JkZXItYm90dG9tJykgPT09IC0xXHJcbiAgICAgICAgKSB7XHJcbiAgICAgICAgICAgIHZpZXdwb3J0RWxlLmNsYXNzTmFtZSArPSAnIGhhcy1ib3JkZXItYm90dG9tJztcclxuICAgICAgICB9IGVsc2UgaWYgKGNvbnRhaW5lckVsZS5jbGllbnRIZWlnaHQgPCB2aWV3cG9ydEVsZS5jbGllbnRIZWlnaHQpIHtcclxuICAgICAgICAgICAgdmlld3BvcnRFbGUuY2xhc3NOYW1lID0gdmlld3BvcnRFbGUuY2xhc3NOYW1lLnJlcGxhY2UoL2hhcy1ib3JkZXItYm90dG9tL2dpLCAnJyk7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX3NldE1vYmlsZUhlaWdodChfZ3JpZEVsZW1lbnQ6IEVsZW1lbnQpOiB2b2lkIHtcclxuICAgICAgICBsZXQgbmV3SGVpZ2h0OiBudW1iZXIgPSAwO1xyXG5cclxuICAgICAgICBpZiAodGhpcy5jb25maWcubG9hZFR5cGUgIT09ICdpbmZpbml0ZScpIHtcclxuICAgICAgICAgICAgbGV0IGFnSGVhZGVyRWxlOiBFbGVtZW50ID0gdGhpcy5fdmNyLmVsZW1lbnQubmF0aXZlRWxlbWVudC5xdWVyeVNlbGVjdG9yKCcuYWctaGVhZGVyJyk7XHJcbiAgICAgICAgICAgIGxldCBhZ0JvZHlFbGU6IEVsZW1lbnQgPSB0aGlzLl92Y3IuZWxlbWVudC5uYXRpdmVFbGVtZW50LnF1ZXJ5U2VsZWN0b3IoJy5hZy1ib2R5LWNvbnRhaW5lcicpO1xyXG4gICAgICAgICAgICBsZXQgYWdQYWdlUGFuZWxFbGU6IEVsZW1lbnQgPSB0aGlzLl92Y3IuZWxlbWVudC5uYXRpdmVFbGVtZW50LnF1ZXJ5U2VsZWN0b3IoJ2RpdltyZWY9XCJzb3V0aFwiXScpO1xyXG4gICAgICAgICAgICBuZXdIZWlnaHQgPSAyNTtcclxuXHJcbiAgICAgICAgICAgIGlmIChhZ0hlYWRlckVsZSAhPT0gbnVsbCkge1xyXG4gICAgICAgICAgICAgICAgbmV3SGVpZ2h0ICs9IGFnSGVhZGVyRWxlLmNsaWVudEhlaWdodDtcclxuICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgaWYgKGFnQm9keUVsZSAhPT0gbnVsbCkge1xyXG4gICAgICAgICAgICAgICAgbmV3SGVpZ2h0ICs9IGFnQm9keUVsZS5jbGllbnRIZWlnaHQ7XHJcbiAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgIGlmIChhZ1BhZ2VQYW5lbEVsZSAhPT0gbnVsbCkge1xyXG4gICAgICAgICAgICAgICAgbmV3SGVpZ2h0ICs9IGFnUGFnZVBhbmVsRWxlLmNsaWVudEhlaWdodDtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgbmV3SGVpZ2h0ID0gNDAwO1xyXG4gICAgICAgIH1cclxuXHJcblxyXG4gICAgICAgIHRoaXMuX2RvbVN2Yy5zZXRFbGVtZW50U3R5bGUoX2dyaWRFbGVtZW50LCAnaGVpZ2h0JywgbmV3SGVpZ2h0ICsgJ3B4Jyk7XHJcblxyXG4gICAgICAgIHRpbWVyKDEwKS5zdWJzY3JpYmUoKCk6IHZvaWQgPT4ge1xyXG4gICAgICAgICAgICB0aGlzLmdyaWRPcHRpb25zLmFwaS5zaXplQ29sdW1uc1RvRml0KCk7XHJcbiAgICAgICAgICAgIHRoaXMuX3Nob3dMb2FkaW5nT3ZlcmxheShmYWxzZSk7XHJcbiAgICAgICAgfSk7XHJcbiAgICB9XHJcblxyXG4gICAgLyoqXHJcbiAgICAgKiBbX3NldFdlYkdyaWRIZWlnaHQgbnVtYmVyIGZvciBwaXhlbCBvciBzdHJpbmcgXCJhdXRvXCJdXHJcbiAgICAgKiAgX2NvbmZpZ0hlaWdodCBbZGVzY3JpcHRpb25dXHJcbiAgICAgKi9cclxuICAgIHByaXZhdGUgX3NldFdlYkdyaWRIZWlnaHQoX2dyaWRFbGVtZW50OiBFbGVtZW50LCBfY29uZmlnSGVpZ2h0OiBudW1iZXIgfCBzdHJpbmcpOiB2b2lkIHtcclxuICAgICAgICBpZiAodHlwZW9mIF9jb25maWdIZWlnaHQgPT09ICdudW1iZXInKSB7XHJcbiAgICAgICAgICAgIGxldCBncmlkSGVpZ2h0OiBudW1iZXIgPSA2MDA7XHJcblxyXG4gICAgICAgICAgICBpZiAodHlwZW9mIF9jb25maWdIZWlnaHQgIT09ICd1bmRlZmluZWQnKSB7XHJcbiAgICAgICAgICAgICAgICBncmlkSGVpZ2h0ID0gX2NvbmZpZ0hlaWdodDtcclxuICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgdGhpcy5fZG9tU3ZjLnNldEVsZW1lbnRTdHlsZShfZ3JpZEVsZW1lbnQsICdoZWlnaHQnLCBncmlkSGVpZ2h0ICsgJ3B4Jyk7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGVsc2UgaWYgKF9jb25maWdIZWlnaHQgPT09ICdhdXRvJykge1xyXG4gICAgICAgICAgICB0aGlzLmRpc3BsYXlGdWxsID0gdHJ1ZTtcclxuICAgICAgICB9XHJcbiAgICAgICAgLy8gZWxzZSBpZiAoX2NvbmZpZ0hlaWdodCA9PT0gJ3Jvd0hlaWdodCcpIHtcclxuICAgICAgICAvLyAgICAgdGhpcy5ncmlkT3B0aW9ucy5kb21MYXlvdXQgPSAnYXV0b0hlaWdodCc7XHJcbiAgICAgICAgLy8gICAgIGRlbGV0ZSB0aGlzLmdyaWRPcHRpb25zLnJvd0hlaWdodDtcclxuICAgICAgICAvLyAgICAgZGVsZXRlIHRoaXMuZ3JpZE9wdGlvbnMuZ2V0Um93SGVpZ2h0O1xyXG4gICAgICAgIC8vIH1cclxuXHJcbiAgICAgICAgdGltZXIoKS5zdWJzY3JpYmUoKCk6IHZvaWQgPT4ge1xyXG4gICAgICAgICAgICB0aGlzLmdyaWRPcHRpb25zLmFwaS5zaXplQ29sdW1uc1RvRml0KCk7XHJcbiAgICAgICAgICAgIHRoaXMuX3Nob3dMb2FkaW5nT3ZlcmxheShmYWxzZSk7XHJcbiAgICAgICAgfSk7XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfaXNDbGlja1ZhbGlkKF9ldmVudDogRXZlbnQpOiBib29sZWFuIHtcclxuICAgICAgICBsZXQgdGFyZ2V0RWxlbWVudDogSFRNTEVsZW1lbnQgPSA8SFRNTEVsZW1lbnQ+X2V2ZW50LnRhcmdldDtcclxuICAgICAgICBsZXQgaW52YWxpZExpc3Q6IEFycmF5PHN0cmluZz4gPSBbJ2FjdGlvbi1idG4nLCAnY2hlY2tib3gtcmFkaW8taW5wdXQnLCAnZmEtY2hldnJvbi1kb3duJ107XHJcblxyXG4gICAgICAgIGZvciAobGV0IGk6IG51bWJlciA9IDA7IGkgPCBpbnZhbGlkTGlzdC5sZW5ndGg7IGkrKykge1xyXG4gICAgICAgICAgICBpZiAodGFyZ2V0RWxlbWVudC5jbGFzc0xpc3QuY29udGFpbnMoaW52YWxpZExpc3RbaV0pKSB7XHJcbiAgICAgICAgICAgICAgICByZXR1cm4gZmFsc2U7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIHJldHVybiB0cnVlO1xyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX3Jlc2l6ZUNvbHVtbihfaXNSZXNpemVUb0NvbnRlbnQ6IGJvb2xlYW4gPSBmYWxzZSk6IHZvaWQge1xyXG4gICAgICAgIGlmICh0aGlzLl90YWJsZVNlcnZpY2UuaXNBcGlSZWFkeSh0aGlzLmdyaWRPcHRpb25zKSkge1xyXG4gICAgICAgICAgICB0aW1lcigxMCkuc3Vic2NyaWJlKCgpOiB2b2lkID0+IHtcclxuICAgICAgICAgICAgICAgIChfaXNSZXNpemVUb0NvbnRlbnQpID8gdGhpcy5fcmVzaXplQ29sdW1uVG9Db250ZW50KCkgOiB0aGlzLmdyaWRPcHRpb25zLmFwaS5zaXplQ29sdW1uc1RvRml0KCk7XHJcbiAgICAgICAgICAgICAgICB0aGlzLm9uRXhwb3J0UG9zc2libGUuZW1pdCh0cnVlKTtcclxuICAgICAgICAgICAgICAgIHRoaXMuX3Nob3dMb2FkaW5nT3ZlcmxheShmYWxzZSk7XHJcbiAgICAgICAgICAgIH0pO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICAvKipcclxuICAgICAqIHJlc2l6ZSBjb2x1bW4gdG8gY29sRGVmIHdpZHRoXHJcbiAgICAgKi9cclxuICAgIHByaXZhdGUgX3Jlc2l6ZUNvbHVtblRvQ29udGVudCgpOiB2b2lkIHtcclxuICAgICAgICBsZXQgYWxsQ29sdW1uSWRzOiBBcnJheTxzdHJpbmc+ID0gW107XHJcbiAgICAgICAgdGhpcy5ncmlkT3B0aW9ucy5jb2x1bW5BcGkuZ2V0QWxsRGlzcGxheWVkQ29sdW1ucygpLmZvckVhY2goKGNvbHVtbjogQ29sdW1uKSA9PiB7XHJcbiAgICAgICAgICAgIGFsbENvbHVtbklkcy5wdXNoKGNvbHVtbi5nZXRDb2xJZCgpKTtcclxuICAgICAgICB9KTtcclxuICAgICAgICB0aGlzLmdyaWRPcHRpb25zLmNvbHVtbkFwaS5hdXRvU2l6ZUNvbHVtbnMoYWxsQ29sdW1uSWRzKTtcclxuICAgIH1cclxuXHJcbiAgICAvKipcclxuICAgICAqIHBvcHVsYXRlIGR5bmFtaWMgc3R5bGluZyB2YWx1ZVxyXG4gICAgICogcGFyYW0ge0lUYWJsZUNvbmZpZ30gX2NvbmZpZzogdGFibGVDb25maWdcclxuICAgICAqL1xyXG4gICAgcHVibGljIHVwZGF0ZVN0eWxlKF9jb25maWc6IElUYWJsZUNvbmZpZyk6IHZvaWQge1xyXG4gICAgICAgIGlmICghX2NvbmZpZyB8fCAhX2NvbmZpZy5jb25maWcpIHtcclxuICAgICAgICAgICAgZG9jdW1lbnQucXVlcnlTZWxlY3RvcignYm9keScpLnN0eWxlLmNzc1RleHQgPSAnJztcclxuICAgICAgICAgICAgcmV0dXJuO1xyXG4gICAgICAgIH1cclxuICAgICAgICBsZXQgY29uZmlnOiBJU3R5bGluZ0NvbmZpZyA9IF9jb25maWcuY29uZmlnO1xyXG5cclxuICAgICAgICBsZXQgYm9keUNzczogc3RyaW5nID0gJyc7XHJcblxyXG4gICAgICAgIGJvZHlDc3MgKz0gdGhpcy5fdXBkYXRlSGVhZGVyU3R5bGUoY29uZmlnKTtcclxuXHJcbiAgICAgICAgaWYgKGNvbmZpZy5ib2R5KSB7XHJcbiAgICAgICAgICAgIGlmIChjb25maWcuYm9keS5hbHRlcm5hdGVSb3cgPT09IHRydWUpIHtcclxuICAgICAgICAgICAgICAgIGlmIChjb25maWcuYm9keS5vZGQgJiYgY29uZmlnLmJvZHkub2RkLmJhY2tncm91bmRDb2xvcikge1xyXG4gICAgICAgICAgICAgICAgICAgIGJvZHlDc3MgKz0gJy0ta2R0YWJsZS1yb3ctb2RkLWJhY2tncm91bmQ6ICcgKyBjb25maWcuYm9keS5vZGQuYmFja2dyb3VuZENvbG9yICsgJzsnO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgaWYgKGNvbmZpZy5ib2R5LmV2ZW4gJiYgY29uZmlnLmJvZHkuZXZlbi5iYWNrZ3JvdW5kQ29sb3IpIHtcclxuICAgICAgICAgICAgICAgICAgICBib2R5Q3NzICs9ICctLWtkdGFibGUtcm93LWV2ZW4tYmFja2dyb3VuZDogJyArIGNvbmZpZy5ib2R5LmV2ZW4uYmFja2dyb3VuZENvbG9yICsgJzsnO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIGlmIChjb25maWcuYm9keS5zdHlsZSkge1xyXG4gICAgICAgICAgICAgICAgaWYgKGNvbmZpZy5ib2R5LnN0eWxlLmJvcmRlcldpZHRoKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgYm9keUNzcyArPSAnLS1rZHRhYmxlLWJvZHktYm9yZGVyLXdpZHRoOiAnICsgY29uZmlnLmJvZHkuc3R5bGUuYm9yZGVyV2lkdGggKyAnOyc7XHJcbiAgICAgICAgICAgICAgICAgICAgYm9keUNzcyArPSAnLS1rZHRhYmxlLWhlYWRlci1ib3JkZXItd2lkdGg6ICcgKyBjb25maWcuYm9keS5zdHlsZS5ib3JkZXJXaWR0aCArICc7JztcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIGlmIChjb25maWcuYm9keS5zdHlsZS5ib3JkZXJDb2xvcikge1xyXG4gICAgICAgICAgICAgICAgICAgIGJvZHlDc3MgKz0gJy0ta2R0YWJsZS1ib2R5LWJvcmRlci1jb2xvcjogJyArIGNvbmZpZy5ib2R5LnN0eWxlLmJvcmRlckNvbG9yICsgJzsnO1xyXG4gICAgICAgICAgICAgICAgICAgIGJvZHlDc3MgKz0gJy0ta2R0YWJsZS1oZWFkZXItYm9yZGVyLWNvbG9yOiAnICsgY29uZmlnLmJvZHkuc3R5bGUuYm9yZGVyQ29sb3IgKyAnOyc7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICBpZiAoY29uZmlnLmJvZHkuc3R5bGUuYm9yZGVyU3R5bGUpIHtcclxuICAgICAgICAgICAgICAgICAgICBib2R5Q3NzICs9ICctLWtkdGFibGUtYm9keS1ib3JkZXItc3R5bGU6ICcgKyBjb25maWcuYm9keS5zdHlsZS5ib3JkZXJTdHlsZSArICc7JztcclxuICAgICAgICAgICAgICAgICAgICBib2R5Q3NzICs9ICctLWtkdGFibGUtaGVhZGVyLWJvcmRlci1zdHlsZTogJyArIGNvbmZpZy5ib2R5LnN0eWxlLmJvcmRlclN0eWxlICsgJzsnO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICBkb2N1bWVudC5xdWVyeVNlbGVjdG9yKCdib2R5Jykuc3R5bGUuY3NzVGV4dCA9IGJvZHlDc3M7XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfdXBkYXRlSGVhZGVyU3R5bGUoX2NvbmZpZzogSVN0eWxpbmdDb25maWcpOiBzdHJpbmcge1xyXG4gICAgICAgIGlmICghX2NvbmZpZy5oZWFkZXIgfHwgIV9jb25maWcuaGVhZGVyLnN0eWxlKSByZXR1cm4gJyc7XHJcblxyXG4gICAgICAgIGxldCBib2R5Q3NzOiBzdHJpbmcgPSAnJztcclxuICAgICAgICBsZXQgc3R5bGVOYW1lczogQXJyYXk8c3RyaW5nPiA9IFtcclxuICAgICAgICAgICAgJ2JhY2tncm91bmRDb2xvcicsXHJcbiAgICAgICAgICAgICd0ZXh0QWxpZ24nLFxyXG4gICAgICAgICAgICAndmVydGljYWxBbGlnbicsXHJcbiAgICAgICAgICAgICdjb2xvcicsXHJcbiAgICAgICAgICAgICdmb250RmFtaWx5JyxcclxuICAgICAgICAgICAgJ2ZvbnRTaXplJyxcclxuICAgICAgICAgICAgJ2ZvbnRXZWlnaHQnLFxyXG4gICAgICAgICAgICAnZm9udFN0eWxlJyxcclxuICAgICAgICAgICAgJ3RleHREZWNvcmF0aW9uJyxcclxuICAgICAgICAgICAgLy8gJ2JvcmRlcldpZHRoJyxcclxuICAgICAgICAgICAgLy8gJ2JvcmRlckNvbG9yJyxcclxuICAgICAgICAgICAgLy8gJ2JvcmRlclN0eWxlJyxcclxuICAgICAgICAgICAgJ29wYWNpdHknXHJcbiAgICAgICAgXTtcclxuICAgICAgICBmb3IgKGxldCBpOiBudW1iZXIgPSAwOyBpIDwgc3R5bGVOYW1lcy5sZW5ndGg7ICsraSkge1xyXG4gICAgICAgICAgICBsZXQgc3R5bGVOYW1lOiBzdHJpbmcgPSBzdHlsZU5hbWVzW2ldO1xyXG4gICAgICAgICAgICBsZXQgdmFsdWU6IHN0cmluZyA9IF9jb25maWcuaGVhZGVyLnN0eWxlW3N0eWxlTmFtZV07XHJcbiAgICAgICAgICAgIGlmIChzdHlsZU5hbWUgPT09ICd2ZXJ0aWNhbEFsaWduJykgdmFsdWUgPSB0aGlzLl9nZXRBbGlnbkl0ZW0odmFsdWUpO1xyXG4gICAgICAgICAgICBzdHlsZU5hbWUgPSAoc3R5bGVOYW1lID09PSAnYmFja2dyb3VuZENvbG9yJykgPyAnYmFja2dyb3VuZCcgOiBzdHlsZU5hbWUucmVwbGFjZSgvKFthLXpdKShbQS1aXSkvZywgJyQxLSQyJykudG9Mb3dlckNhc2UoKTtcclxuICAgICAgICAgICAgaWYgKHR5cGVvZiB2YWx1ZSAhPT0gJ3VuZGVmaW5lZCcpIHtcclxuICAgICAgICAgICAgICAgIGlmIChzdHlsZU5hbWUgPT09ICdib3JkZXJXaWR0aCcgJiZcclxuICAgICAgICAgICAgICAgICAgICAodHlwZW9mIHZhbHVlICE9PSAnc3RyaW5nJyB8fCB2YWx1ZS5pbmRleE9mKCdweCcpID09PSAtMSlcclxuICAgICAgICAgICAgICAgICkgdmFsdWUgKz0gJ3B4JztcclxuICAgICAgICAgICAgICAgIGJvZHlDc3MgKz0gJy0ta2R0YWJsZS1oZWFkZXItJyArIHN0eWxlTmFtZSArICc6ICcgKyB2YWx1ZSArICc7JztcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgICAgICByZXR1cm4gYm9keUNzcztcclxuICAgIH1cclxuXHJcbiAgICAvKipcclxuICAgICAqIGNvbnZlcnQgdGV4dCBhbGlnbiBpbnRvIGZsZXgtYm94IGl0ZW0gYWxpZ25cclxuICAgICAqIHBhcmFtIHtzdHJpbmd9IF92ZXJ0aWNhbEFsaWduOiB0ZXh0IHZlcnRpY2FsQWxpZ25cclxuICAgICAqL1xyXG4gICAgcHJpdmF0ZSBfZ2V0QWxpZ25JdGVtKF92ZXJ0aWNhbEFsaWduOiBzdHJpbmcpOiBzdHJpbmcge1xyXG4gICAgICAgIGlmIChfdmVydGljYWxBbGlnbiA9PT0gJ2Jhc2VsaW5lJyB8fCBfdmVydGljYWxBbGlnbiA9PT0gJ2JvdHRvbScpIHtcclxuICAgICAgICAgICAgcmV0dXJuICdmbGV4LWVuZCc7XHJcbiAgICAgICAgfSBlbHNlIGlmIChfdmVydGljYWxBbGlnbiA9PT0gJ3RvcCcpIHtcclxuICAgICAgICAgICAgcmV0dXJuICdmbGV4LXN0YXJ0JztcclxuICAgICAgICB9IGVsc2UgeyAvLyBpbmNsdWRpbmcgaW52YWxpZCBpbnB1dFxyXG4gICAgICAgICAgICBpZiAoX3ZlcnRpY2FsQWxpZ24gIT09ICdtaWRkbGUnICYmIF92ZXJ0aWNhbEFsaWduICE9PSB1bmRlZmluZWQpIHtcclxuICAgICAgICAgICAgICAgIGNvbnNvbGUud2FybignRVJST1I6IHRoZSB2ZXJ0aWNhbCBhbGlnbiB2YWx1ZSBvZiAnICsgX3ZlcnRpY2FsQWxpZ24gKyAnIGlzIG5vdCB5ZXQgcmVjb2duaXNlZCBieSBLZFRhYmxlLiBQbGVhc2Ugb25seSB1c2UgZWl0aGVyIHRvcCwgY2VudGVyIG9yIGJvdHRvbScpO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIHJldHVybiAnY2VudGVyJztcclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgLy8gcHJpdmF0ZSBfcmVmcmVzaFRhYmxlKF90YWJsZUNlbGxQYXJhbXM/OiBJVGFibGVDZWxsUGFyYW1zKTogdm9pZCB7XHJcbiAgICAvLyAgICAgaWYgKHRoaXMuX3RhYmxlU2VydmljZSAmJiB0aGlzLl90YWJsZVNlcnZpY2UuaXNBcGlSZWFkeSAmJiB0aGlzLl90YWJsZVNlcnZpY2UuaXNBcGlSZWFkeSh0aGlzLmdyaWRPcHRpb25zKSkge1xyXG4gICAgLy8gICAgICAgICBsZXQgdG9VcGRhdGVOb2RlOiBBcnJheTxSb3dOb2RlPiA9IFtdO1xyXG4gICAgLy8gICAgICAgICBsZXQgYWxsQ29sdW1uSWRzOiBBcnJheTxzdHJpbmc+ID0gW107XHJcblxyXG4gICAgLy8gICAgICAgICBpZiAoIV90YWJsZUNlbGxQYXJhbXMpIHtcclxuICAgIC8vICAgICAgICAgICAgIHRoaXMuZ3JpZE9wdGlvbnMuY29sdW1uQXBpLmdldEFsbERpc3BsYXllZENvbHVtbnMoKS5mb3JFYWNoKChjb2x1bW4pID0+IHtcclxuICAgIC8vICAgICAgICAgICAgICAgICBhbGxDb2x1bW5JZHMucHVzaChjb2x1bW4uZ2V0Q29sSWQoKSk7XHJcbiAgICAvLyAgICAgICAgICAgICB9KTtcclxuICAgIC8vICAgICAgICAgfVxyXG5cclxuICAgIC8vICAgICAgICAgdGhpcy5ncmlkT3B0aW9ucy5hcGkuZm9yRWFjaE5vZGUoKF9yb3dOb2RlOiBSb3dOb2RlKTogdm9pZCA9PiB7XHJcbiAgICAvLyAgICAgICAgICAgICBpZiAoX3RhYmxlQ2VsbFBhcmFtcyAmJiB0eXBlb2YgX3Jvd05vZGUuaWQgIT09ICd1bmRlZmluZWQnICYmIF9yb3dOb2RlLmlkID09PSBfdGFibGVDZWxsUGFyYW1zLnJvd0lkKSB7XHJcbiAgICAvLyAgICAgICAgICAgICAgICAgX3Jvd05vZGUuZGF0YVtfdGFibGVDZWxsUGFyYW1zLmNvbElkXSA9IF90YWJsZUNlbGxQYXJhbXMuZGF0YTtcclxuICAgIC8vICAgICAgICAgICAgICAgICB0b1VwZGF0ZU5vZGUucHVzaChfcm93Tm9kZSk7XHJcbiAgICAvLyAgICAgICAgICAgICB9IGVsc2Uge1xyXG4gICAgLy8gICAgICAgICAgICAgICAgIHRvVXBkYXRlTm9kZS5wdXNoKF9yb3dOb2RlKTtcclxuICAgIC8vICAgICAgICAgICAgIH1cclxuICAgIC8vICAgICAgICAgfSk7XHJcblxyXG4gICAgLy8gICAgICAgICBsZXQgcmVmcmVzaFBhcmFtczogeyByb3dOb2RlczogQXJyYXk8Um93Tm9kZT4sIGNvbHVtbnM6IEFycmF5PGFueT4gfSA9IHtcclxuICAgIC8vICAgICAgICAgICAgIHJvd05vZGVzOiB0b1VwZGF0ZU5vZGUsXHJcbiAgICAvLyAgICAgICAgICAgICBjb2x1bW5zOiAoX3RhYmxlQ2VsbFBhcmFtcykgPyBbX3RhYmxlQ2VsbFBhcmFtcy5jb2xJZF0gOiBhbGxDb2x1bW5JZHNcclxuICAgIC8vICAgICAgICAgfTtcclxuXHJcbiAgICAvLyAgICAgICAgIHRoaXMuZ3JpZE9wdGlvbnMuYXBpLnJlZnJlc2hDZWxscyhyZWZyZXNoUGFyYW1zKTtcclxuICAgIC8vICAgICB9XHJcbiAgICAvLyB9XHJcblxyXG4gICAgLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy9cclxuICAgIC8vLyBQaXZvdCBGdW5jdGlvblxyXG4gICAgLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy9cclxuICAgIHByaXZhdGUgX2lzVG9vbHBhbmVsVHlwZUNoYW5nZWQoKTogYm9vbGVhbiB7XHJcbiAgICAgICAgbGV0IGlzVHlwZUNoYW5nZWQ6IGJvb2xlYW4gPSB0cnVlO1xyXG4gICAgICAgIGlmICh0aGlzLl9wcmV2aW91c1Rvb2xwYW5lbFR5cGUpIHtcclxuICAgICAgICAgICAgaWYgKHR5cGVFeGlzdCh0aGlzLmNvbmZpZykpIHtcclxuICAgICAgICAgICAgICAgIGlzVHlwZUNoYW5nZWQgPSB0aGlzLl9wcmV2aW91c1Rvb2xwYW5lbFR5cGUgIT09IHRoaXMuY29uZmlnLnBpdm90LnRvb2xwYW5lbC50eXBlO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgaWYgKHR5cGVFeGlzdCh0aGlzLmNvbmZpZykpIHtcclxuICAgICAgICAgICAgICAgIHRoaXMuX3ByZXZpb3VzVG9vbHBhbmVsVHlwZSA9IHRoaXMuY29uZmlnLnBpdm90LnRvb2xwYW5lbC50eXBlO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgICAgIHJldHVybiBpc1R5cGVDaGFuZ2VkO1xyXG5cclxuICAgICAgICBmdW5jdGlvbiB0eXBlRXhpc3QoX2NvbmZpZykge1xyXG4gICAgICAgICAgICByZXR1cm4gX2NvbmZpZyAmJiBfY29uZmlnLnBpdm90ICYmIF9jb25maWcucGl2b3QudG9vbHBhbmVsICYmIF9jb25maWcucGl2b3QudG9vbHBhbmVsLnR5cGVcclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfY29uZmlndXJlUGl2b3REaXNwbGF5KCk6IHZvaWQge1xyXG4gICAgICAgIGxldCBpc1N0YXRlQ2hhbmdlZDogYm9vbGVhbiA9IHRydWU7XHJcbiAgICAgICAgaWYgKHRoaXMuY29uZmlnICYmIHRoaXMuY29uZmlnLnBpdm90ICYmIHRoaXMuY29uZmlnLnBpdm90LnN0YXRlICYmIHRoaXMuY29uZmlnLnBpdm90LnN0YXRlLmNvbHVtblN0YXRlKSB7XHJcbiAgICAgICAgICAgIGlzU3RhdGVDaGFuZ2VkID0gdGhpcy5jb25maWcucGl2b3Quc3RhdGUuY29sdW1uU3RhdGUubGVuZ3RoICE9PSB0aGlzLl9jdXJyZW50U3RhdGUuY29sdW1uU3RhdGUubGVuZ3RoO1xyXG4gICAgICAgIH1cclxuICAgICAgICBpZiAodGhpcy5jb25maWcubG9hZFR5cGUgIT09ICdub3JtYWwnIHx8ICh0aGlzLl9pc1Rvb2xwYW5lbFR5cGVDaGFuZ2VkKCkgPT09IGZhbHNlICYmIGlzU3RhdGVDaGFuZ2VkID09PSBmYWxzZSkpIHJldHVybjtcclxuXHJcbiAgICAgICAgbGV0IHNob3dUb29sUGFuZWw6IGJvb2xlYW4gPSBmYWxzZTtcclxuICAgICAgICBsZXQgc2hvd1Bpdm90TW9kZTogYm9vbGVhbiA9IGZhbHNlO1xyXG4gICAgICAgIGlmICh0aGlzLmNvbmZpZy5waXZvdCAmJiB0aGlzLmNvbmZpZy5waXZvdC50b29scGFuZWwpIHtcclxuICAgICAgICAgICAgc2hvd1Rvb2xQYW5lbCA9IHRoaXMuY29uZmlnLnBpdm90LnRvb2xwYW5lbC50eXBlICE9PSAnbm9uZSc7XHJcbiAgICAgICAgICAgIHNob3dQaXZvdE1vZGUgPSB0aGlzLmNvbmZpZy5waXZvdC50b29scGFuZWwudHlwZSA9PT0gJ3Bpdm90JztcclxuICAgICAgICB9XHJcbiAgICAgICAgdGhpcy5fc2hvd1Rvb2xQYW5lbChzaG93VG9vbFBhbmVsKTtcclxuICAgICAgICB0aGlzLl9zaG93UGl2b3RNb2RlKHNob3dQaXZvdE1vZGUpO1xyXG4gICAgfVxyXG5cclxuICAgIC8qKlxyXG4gICAgICogcmVzaXplIGNvbHVtbiB0byBmaXQgdGFibGUgY29udGFpbmVyIGlmIHRoZSB3aWR0aCBvZiB0aGUgY29udGVudCBjb2x1bW4gaXMgc21hbGxlciB0aGFuIGNvbnRhaW5lclxyXG4gICAgICovXHJcbiAgICBwcml2YXRlIF9waXZvdFJlc2l6ZSgpOiB2b2lkIHtcclxuICAgICAgICBsZXQgY29udGFpbmVyOiBFbGVtZW50ID0gdGhpcy5fdmNyLmVsZW1lbnQubmF0aXZlRWxlbWVudC5xdWVyeVNlbGVjdG9yKCcuYWctaGVhZGVyLWNvbnRhaW5lcicpO1xyXG4gICAgICAgIGxldCBoZWFkZXI6IEVsZW1lbnQgPSB0aGlzLl92Y3IuZWxlbWVudC5uYXRpdmVFbGVtZW50LnF1ZXJ5U2VsZWN0b3IoJy5hZy1oZWFkZXItY29udGFpbmVyIC5hZy1oZWFkZXItcm93Jyk7XHJcblxyXG4gICAgICAgIHRoaXMuX3Jlc2l6ZUNvbHVtbihoZWFkZXIuZ2V0Qm91bmRpbmdDbGllbnRSZWN0KCkud2lkdGggPiBjb250YWluZXIuZ2V0Qm91bmRpbmdDbGllbnRSZWN0KCkud2lkdGgpO1xyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX3Jlc2V0UGl2b3RDb2x1bW4oKTogdm9pZCB7XHJcbiAgICAgICAgdGhpcy5ncmlkT3B0aW9ucy5jb2x1bW5BcGkuc2V0Um93R3JvdXBDb2x1bW5zKFtdKTtcclxuICAgICAgICB0aGlzLmdyaWRPcHRpb25zLmNvbHVtbkFwaS5zZXRQaXZvdENvbHVtbnMoW10pO1xyXG4gICAgICAgIHRoaXMuZ3JpZE9wdGlvbnMuY29sdW1uQXBpLnNldFZhbHVlQ29sdW1ucyhbXSk7XHJcbiAgICAgICAgdGhpcy5ncmlkT3B0aW9ucy5jb2x1bW5BcGkuc2V0U2Vjb25kYXJ5Q29sdW1ucyhbXSk7XHJcbiAgICB9XHJcblxyXG4gICAgLyoqXHJcbiAgICAgKiBwYXNzIHN0YXRlIHRvIGFwcGxpY2F0aW9uLlxyXG4gICAgICogKGlmIHNldFN0YXRlIHdhcyB0cmlnZ2VyZWQgYmVmb3JlKSwgd2FpdCB1bnRpbCBzZXRTdGF0ZSBoYXMgZG9uZSBwcm9jZXNzaW5nXHJcbiAgICAgKiByZXR1cm4ge0lUYWJsZVBpdm90U3RhdGV9IFtkZXNjcmlwdGlvbl1cclxuICAgICAqL1xyXG4gICAgcHJpdmF0ZSBfZ2V0UGl2b3RTdGF0ZSgpOiBJVGFibGVQaXZvdFN0YXRlIHtcclxuICAgICAgICAvLyBpZiBzdGF0ZSBpcyBjaGFuZ2luZywgd2FpdCB1bnRpbCBzdGF0ZSBoYXMgYmVlbiB1cGRhdGVkIHRoZW4gZ2V0IHRoZSBtb3N0IHVwZGF0ZWQgc3RhdGVcclxuICAgICAgICBsZXQgZ2V0U3RhdGUgPSAoKTogYW55ID0+IHtcclxuICAgICAgICAgICAgdGhpcy5fY3VycmVudFN0YXRlLmNvbHVtblN0YXRlID0gdGhpcy5ncmlkT3B0aW9ucy5jb2x1bW5BcGkuZ2V0Q29sdW1uU3RhdGUoKTtcclxuICAgICAgICAgICAgdGhpcy5fY3VycmVudFN0YXRlLnBpdm90TW9kZSA9IHRoaXMuZ3JpZE9wdGlvbnMuY29sdW1uQXBpLmlzUGl2b3RNb2RlKCk7XHJcbiAgICAgICAgICAgIHRoaXMuX2N1cnJlbnRTdGF0ZS5ncm91cFN0YXRlID0gdGhpcy5ncmlkT3B0aW9ucy5jb2x1bW5BcGkuZ2V0Q29sdW1uR3JvdXBTdGF0ZSgpO1xyXG4gICAgICAgICAgICByZXR1cm4gdGhpcy5fY3VycmVudFN0YXRlO1xyXG4gICAgICAgIH07XHJcbiAgICAgICAgbGV0IGNoZWNrID0gKCk6IGJvb2xlYW4gPT4ge1xyXG4gICAgICAgICAgICByZXR1cm4gdGhpcy5faXNDaGFuZ2luZ1N0YXRlID09PSBmYWxzZTtcclxuICAgICAgICB9O1xyXG4gICAgICAgIHJldHVybiB0aGlzLndhaXQoY2hlY2ssIGdldFN0YXRlKTtcclxuICAgIH1cclxuXHJcbiAgICAvKipcclxuICAgICAqIHJlcGxhY2UgY3VycmVudCBzdGF0ZSBpZiBhIHN0YXRlIGlzIGdpdmVuLCBleHBhbmRHcm91cCBiYXNlIG9uIGNvbmZpZ1xyXG4gICAgICogc2hvdWxkIHdhaXQgdW50aWwgY29sdW1uIGlzIHByZXNlbnQuXHJcbiAgICAgKiBwYXJhbSB7SVRhYmxlUGl2b3RTdGF0ZX0gX3N0YXRlXHJcbiAgICAgKi9cclxuICAgIHByaXZhdGUgX3NldFBpdm90U3RhdGUoX3N0YXRlOiBJVGFibGVQaXZvdFN0YXRlKTogdm9pZCB7XHJcbiAgICAgICAgaWYgKHR5cGVvZiAoX3N0YXRlKSA9PT0gJ3VuZGVmaW5lZCcgfHwgIV9zdGF0ZS5oYXNPd25Qcm9wZXJ0eSgnY29sdW1uU3RhdGUnKSkgcmV0dXJuO1xyXG5cclxuICAgICAgICBsZXQgc2V0U3RhdGUgPSAoKTogdm9pZCA9PiB7XHJcbiAgICAgICAgICAgIHRoaXMuX2lzQ2hhbmdpbmdTdGF0ZSA9IHRydWU7XHJcbiAgICAgICAgICAgIGlmIChfc3RhdGUuY29sdW1uU3RhdGUubGVuZ3RoID09PSAwKSB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLl9pc0NoYW5naW5nU3RhdGUgPSBmYWxzZTtcclxuICAgICAgICAgICAgICAgIHRoaXMuX3Bpdm90UmVzaXplKCk7XHJcbiAgICAgICAgICAgICAgICByZXR1cm47XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgdGhpcy5fY3VycmVudFN0YXRlID0gT2JqZWN0LmFzc2lnbih0aGlzLl9jdXJyZW50U3RhdGUsIF9zdGF0ZSk7XHJcbiAgICAgICAgICAgIHRoaXMuZ3JpZE9wdGlvbnMuY29sdW1uQXBpLnNldENvbHVtblN0YXRlKF9zdGF0ZS5jb2x1bW5TdGF0ZSk7XHJcbiAgICAgICAgICAgIHRoaXMuZ3JpZE9wdGlvbnMuY29sdW1uQXBpLnNldFBpdm90TW9kZShfc3RhdGUucGl2b3RNb2RlIHx8IGZhbHNlKTtcclxuICAgICAgICAgICAgdGhpcy5ncmlkT3B0aW9ucy5jb2x1bW5BcGkuc2V0Q29sdW1uR3JvdXBTdGF0ZShfc3RhdGUuZ3JvdXBTdGF0ZSB8fCBbXSk7XHJcbiAgICAgICAgICAgIHRoaXMuX2lzQ2hhbmdpbmdTdGF0ZSA9IGZhbHNlO1xyXG5cclxuICAgICAgICAgICAgdGltZXIoMTAwKS5zdWJzY3JpYmUoKCk6IHZvaWQgPT4ge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5fc2V0UGl2b3RDb2x1bW5zKCk7XHJcbiAgICAgICAgICAgICAgICB0aGlzLl9leHBhbmRHcm91cCgpO1xyXG4gICAgICAgICAgICB9KTtcclxuICAgICAgICB9O1xyXG4gICAgICAgIGxldCBjaGVjayA9ICgpOiBib29sZWFuID0+IHtcclxuICAgICAgICAgICAgcmV0dXJuIHRoaXMuY29sdW1uICYmIHRoaXMuY29sdW1uLmxlbmd0aCA+IDA7XHJcbiAgICAgICAgfTtcclxuICAgICAgICB0aGlzLndhaXQoY2hlY2ssIHNldFN0YXRlKTtcclxuICAgIH1cclxuXHJcbiAgICAvKipcclxuICAgICAqIHdhaXQgZm9yIHNvbWV0aGluZyB0byBmaW5pc2ggdGhlbiBkbyBzb21ldGhpbmcsIGJyZWFrcyBhdCAxMDB0aCB0byBwcmV2ZW50IGluZmluaXRlIGxvb3BcclxuICAgICAqIHBhcmFtIHtJVGFibGVQaXZvdFN0YXRlfSBfc3RhdGVcclxuICAgICAqIHJldHVybiB7YW55fVxyXG4gICAgICovXHJcbiAgICBwcml2YXRlIHdhaXQoX2NoZWNrOiBGdW5jdGlvbiwgX2RvOiBGdW5jdGlvbiwgX2xpbWl0Q291bnRlciA9IDApOiBhbnkge1xyXG4gICAgICAgIGlmICgoX2NoZWNrKCkgJiYgdGhpcy5fdGFibGVTZXJ2aWNlLmlzQXBpUmVhZHkodGhpcy5ncmlkT3B0aW9ucykpIHx8IF9saW1pdENvdW50ZXIgPT09IDEwMCkge1xyXG4gICAgICAgICAgICBpZiAoX2xpbWl0Q291bnRlciA9PT0gMTAwKSBjb25zb2xlLmxvZygnVGltZW91dDogY2hlY2sgZmFpbHMuIHJ1bm5pbmcnLCBfZG8pO1xyXG4gICAgICAgICAgICByZXR1cm4gX2RvKCk7XHJcbiAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgdGltZXIoMTApLnN1YnNjcmliZSgoKTogdm9pZCA9PiB7XHJcbiAgICAgICAgICAgICAgICBfbGltaXRDb3VudGVyKys7XHJcbiAgICAgICAgICAgICAgICB0aGlzLndhaXQoX2NoZWNrLCBfZG8sIF9saW1pdENvdW50ZXIpO1xyXG4gICAgICAgICAgICB9KTtcclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfaXNQaXZvdEVsbUV4aXN0KF9waXZvdEVsZW1lbnQpOiBib29sZWFuIHsgXHJcbiAgICAgICAgcmV0dXJuIChcclxuICAgICAgICAgICAgdHlwZW9mIF9waXZvdEVsZW1lbnRbJ3Bpdm90J10gIT09ICd1bmRlZmluZWQnICYmXHJcbiAgICAgICAgICAgIF9waXZvdEVsZW1lbnRbJ3Bpdm90J10gIT09IG51bGwgJiZcclxuICAgICAgICAgICAgdHlwZW9mIF9waXZvdEVsZW1lbnRbJ2NvbHVtbi1kcm9wJ10gIT09ICd1bmRlZmluZWQnICYmXHJcbiAgICAgICAgICAgIF9waXZvdEVsZW1lbnRbJ2NvbHVtbi1kcm9wJ10gIT09IG51bGxcclxuICAgICAgICApO1xyXG4gICAgfVxyXG5cclxuICAgIC8qKlxyXG4gICAgICogc2hvdyBwaXZvdCBtb2RlIGNoZWNrYm94IGFuZCBsYWJlbC5cclxuICAgICAqIHdoZW4gcGl2b3QgbW9kZSBpcyBoaWRkZW4sIGFsbCBwaXZvdCBkYXRhIGhhcyB0byBiZSByZXNldC5cclxuICAgICAqIHBhcmFtIHtib29sZWFuID0gdHJ1ZX0gX3Nob3c6IHRydWUgdG8gc2hvdywgZmFsc2UgdG8gaGlkZVxyXG4gICAgICovXHJcbiAgICBwcml2YXRlIF9zaG93UGl2b3RNb2RlKF9zaG93OiBib29sZWFuID0gdHJ1ZSk6IHZvaWQge1xyXG4gICAgICAgIGxldCBzZXRQaXZvdE1vZGUgPSAoKTogdm9pZCA9PiB7XHJcbiAgICAgICAgICAgIGlmIChfc2hvdyA9PT0gdHJ1ZSkge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5fcGl2b3RFbGVtZW50WydwaXZvdCddLmNsYXNzTmFtZSA9IHRoaXMuX3Bpdm90RWxlbWVudFsncGl2b3QnXS5jbGFzc05hbWUucmVwbGFjZSgvIGhpZGRlbi9naSwgJycpO1xyXG4gICAgICAgICAgICAgICAgZm9yIChsZXQgaTogbnVtYmVyID0gMDsgaSA8IHRoaXMuX3Bpdm90RWxlbWVudFsnY29sdW1uLWRyb3AnXS5sZW5ndGg7ICsraSkge1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuX3Bpdm90RWxlbWVudFsnY29sdW1uLWRyb3AnXVtpXS5jbGFzc05hbWUgPSB0aGlzLl9waXZvdEVsZW1lbnRbJ2NvbHVtbi1kcm9wJ11baV0uY2xhc3NOYW1lLnJlcGxhY2UoLyBoaWRkZW4vZ2ksICcnKTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIHRoaXMuX3NldFBpdm90U3RhdGUodGhpcy5jb25maWcucGl2b3QgJiYgdGhpcy5jb25maWcucGl2b3Quc3RhdGUgPyB0aGlzLmNvbmZpZy5waXZvdC5zdGF0ZSA6IHt9KTtcclxuICAgICAgICAgICAgICAgIHJldHVybjtcclxuICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgaWYgKHRoaXMuX3Bpdm90RWxlbWVudFsncGl2b3QnXSAmJlxyXG4gICAgICAgICAgICAgICAgdGhpcy5fcGl2b3RFbGVtZW50WydwaXZvdCddLmNsYXNzTmFtZSAmJlxyXG4gICAgICAgICAgICAgICAgdGhpcy5fcGl2b3RFbGVtZW50WydwaXZvdCddLmNsYXNzTmFtZS5pbmRleE9mKCdoaWRkZW4nKSA9PT0gLTFcclxuICAgICAgICAgICAgKSB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLl9waXZvdEVsZW1lbnRbJ3Bpdm90J10uY2xhc3NOYW1lICs9ICcgaGlkZGVuJztcclxuICAgICAgICAgICAgICAgIGZvciAobGV0IGo6IG51bWJlciA9IDA7IGogPCB0aGlzLl9waXZvdEVsZW1lbnRbJ2NvbHVtbi1kcm9wJ10ubGVuZ3RoOyArK2opIHtcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLl9waXZvdEVsZW1lbnRbJ2NvbHVtbi1kcm9wJ11bal0uY2xhc3NOYW1lICs9ICcgaGlkZGVuJztcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB0aGlzLl9lbmFibGVkUGl2b3RNb2RlKGZhbHNlKTtcclxuXHJcbiAgICAgICAgICAgIHRoaXMuX3NldFBpdm90U3RhdGUoe1xyXG4gICAgICAgICAgICAgICAgJ2NvbHVtblN0YXRlJzogW10sXHJcbiAgICAgICAgICAgICAgICAncGl2b3RNb2RlJzogZmFsc2UsXHJcbiAgICAgICAgICAgICAgICAnZ3JvdXBTdGF0ZSc6IFtdXHJcbiAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICB0aGlzLl9yZXNldFBpdm90Q29sdW1uKCk7XHJcbiAgICAgICAgfTtcclxuICAgICAgICBsZXQgY2hlY2sgPSAoKTogYm9vbGVhbiA9PiB7XHJcbiAgICAgICAgICAgIC8vIGlmICh0aGlzLmNvbmZpZy5waXZvdC50b29scGFuZWwudHlwZSA9PT0gJ25vbmUnIHx8ICF0aGlzLmNvbmZpZy5waXZvdCB8fCAhdGhpcy5jb25maWcucGl2b3QudG9vbHBhbmVsKSByZXR1cm4gdHJ1ZTtcclxuICAgICAgICAgICAgaWYgKHRoaXMuY29uZmlnLnBpdm90ICYmXHJcbiAgICAgICAgICAgICAgICB0aGlzLmNvbmZpZy5waXZvdC50b29scGFuZWwgJiZcclxuICAgICAgICAgICAgICAgIHRoaXMuY29uZmlnLnBpdm90LnRvb2xwYW5lbC50eXBlICYmXHJcbiAgICAgICAgICAgICAgICB0aGlzLmNvbmZpZy5waXZvdC50b29scGFuZWwudHlwZSAhPT0gJ25vbmUnXHJcbiAgICAgICAgICAgICkge1xyXG4gICAgICAgICAgICAgICAgbGV0IGlzUGl2b3RFbG1FeGlzdDogYm9vbGVhbiA9IHRoaXMuX2lzUGl2b3RFbG1FeGlzdCh0aGlzLl9waXZvdEVsZW1lbnQpO1xyXG4gICAgICAgICAgICAgICAgaWYgKGlzUGl2b3RFbG1FeGlzdCA9PT0gdHJ1ZSkgcmV0dXJuIGlzUGl2b3RFbG1FeGlzdDtcclxuXHJcbiAgICAgICAgICAgICAgICBsZXQgZG9tRWxlUXVlcnk6IHN0cmluZyA9ICcjJyArIHRoaXMuZ3JpZElkICsgJy5zdGctdGhlbWUgLmFnLXNpZGUtYmFyJztcclxuICAgICAgICAgICAgICAgIHRoaXMuX3Bpdm90RWxlbWVudFsncGl2b3QnXSA9IHRoaXMuX3Zjci5lbGVtZW50Lm5hdGl2ZUVsZW1lbnQucXVlcnlTZWxlY3Rvcihkb21FbGVRdWVyeSArICcgLmFnLXBpdm90LW1vZGUtcGFuZWwnKTtcclxuICAgICAgICAgICAgICAgIHRoaXMuX3Bpdm90RWxlbWVudFsnY29sdW1uLWRyb3AnXSA9IHRoaXMuX3Zjci5lbGVtZW50Lm5hdGl2ZUVsZW1lbnQucXVlcnlTZWxlY3RvckFsbChkb21FbGVRdWVyeSArICcgLmFnLWNvbHVtbi1kcm9wJyk7XHJcbiAgICAgICAgICAgICAgICByZXR1cm4gdGhpcy5faXNQaXZvdEVsbUV4aXN0KHRoaXMuX3Bpdm90RWxlbWVudCk7XHJcbiAgICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgICAgICByZXR1cm4gdHJ1ZTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH07XHJcbiAgICAgICAgdGhpcy53YWl0KGNoZWNrLCBzZXRQaXZvdE1vZGUpO1xyXG4gICAgfVxyXG5cclxuXHJcbiAgICAvKipcclxuICAgICAqIGhpZGUgYW5kIHNob3cgdG9vbHBhbmVsIChwaXZvdCBtb2RlIHBhbmVsKVxyXG4gICAgICogcGFyYW0ge2Jvb2xlYW59IF9zaG93OiB0cnVlIHRvIHNob3csIGZhbHNlIHRvIGhpZGVcclxuICAgICAqL1xyXG4gICAgcHJpdmF0ZSBfc2hvd1Rvb2xQYW5lbChfc2hvdzogYm9vbGVhbik6IHZvaWQge1xyXG4gICAgICAgIGlmICh0aGlzLl90YWJsZVNlcnZpY2UuaXNBcGlSZWFkeSh0aGlzLmdyaWRPcHRpb25zKSkge1xyXG4gICAgICAgICAgICB0aW1lcigxMCkuc3Vic2NyaWJlKCgpOiB2b2lkID0+IHtcclxuICAgICAgICAgICAgICAgIHRoaXMuZ3JpZE9wdGlvbnMuYXBpLnNob3dUb29sUGFuZWwoX3Nob3cpO1xyXG4gICAgICAgICAgICB9KTtcclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgLyoqXHJcbiAgICAgKiBleHBhbmQgcm93IGdyb3VwIGJhc2Ugb24gdGhlIHN0YXR1cyB0aGF0IHBhc3NlZCBpblxyXG4gICAgICogcGFyYW0ge2Jvb2xlYW59IF9leHBhbmQ6IHRydWUgdG8gZXhwYW5kLCBmYWxzZSB0byBjb2xsYXBzZVxyXG4gICAgICovXHJcbiAgICBwcml2YXRlIF9leHBhbmRHcm91cChfZXhwYW5kPzogYm9vbGVhbik6IHZvaWQge1xyXG4gICAgICAgIGlmICh0eXBlb2YgX2V4cGFuZCA9PT0gJ3VuZGVmaW5lZCcpIHtcclxuICAgICAgICAgICAgX2V4cGFuZCA9IGZhbHNlO1xyXG4gICAgICAgICAgICBpZiAodGhpcy5jb25maWcucGl2b3QgJiYgdGhpcy5jb25maWcucGl2b3Quc3RhdGUgJiYgdGhpcy5jb25maWcucGl2b3Quc3RhdGUuZXhwYW5kR3JvdXApIHtcclxuICAgICAgICAgICAgICAgIF9leHBhbmQgPSB0aGlzLmNvbmZpZy5waXZvdC5zdGF0ZS5leHBhbmRHcm91cDtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgICAgICBpZiAodGhpcy5fdGFibGVTZXJ2aWNlLmlzQXBpUmVhZHkodGhpcy5ncmlkT3B0aW9ucykpIHtcclxuICAgICAgICAgICAgdGltZXIoMTApLnN1YnNjcmliZSgoKTogdm9pZCA9PiB7XHJcbiAgICAgICAgICAgICAgICAoX2V4cGFuZCkgPyB0aGlzLmdyaWRPcHRpb25zLmFwaS5leHBhbmRBbGwoKSA6IHRoaXMuZ3JpZE9wdGlvbnMuYXBpLmNvbGxhcHNlQWxsKCk7XHJcbiAgICAgICAgICAgICAgICB0aGlzLl9waXZvdFJlc2l6ZSgpO1xyXG4gICAgICAgICAgICB9KTtcclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgLyoqXHJcbiAgICAgKiB0dXJuIG9uIGFuZCBvZmYgcGl2b3QgbW9kZVxyXG4gICAgICogSWYgb24sICdDb2x1bW4gTGFiZWwnIHdpbGwgYXBwZWFyXHJcbiAgICAgKiBJZiBvbiwgdGljayBjb2x1bW4gbmFtZSBvbiB0b29scGFuZWwgd2lsbCBhc3NpZ24gY29sdW1uIHRvICdSb3cgR3JvdXAnIC8gJ1ZhbHVlcycgZGVwZW5kcyBvbiBjb2xEZWZcclxuICAgICAqIElmIG9mZiwgdGljayBjb2x1bW4gbmFtZSBvbiB0b29scGFuZWwgd2lsbCB0cmlnZ2VyIGNvbHVtbiBoaWRlIGFuZCBzaG93XHJcbiAgICAgKiBwYXJhbSB7Ym9vbGVhbiA9IGZhbHNlfSBfZW5hYmxlZDogdHJ1ZSB0byBjaGVjaywgZmFsc2UgdG8gdW5jaGVja1xyXG4gICAgICovXHJcbiAgICBwcml2YXRlIF9lbmFibGVkUGl2b3RNb2RlKF9lbmFibGVkOiBib29sZWFuID0gZmFsc2UpOiB2b2lkIHtcclxuICAgICAgICB0aGlzLmdyaWRPcHRpb25zLmNvbHVtbkFwaS5zZXRQaXZvdE1vZGUoX2VuYWJsZWQpO1xyXG4gICAgfVxyXG5cclxuICAgIC8vIFRPRE86IHRvIGJlIHJldmlzaXRcclxuICAgIC8qKlxyXG4gICAgICogc3VwcHJlc3NNb3ZhYmxlQ29sdW1ucyBvbiBwaXZvdENvbHVtbnMgYW5kIHJvd0dyb3VwQ29sdW1uc1xyXG4gICAgICogY29sdW1ucyBvbiBwaXZvdCBtb2RlIGRvZXMgbm90IGxpc3RlbiB0byBjb2xEZWYuc3VwcHJlc3NNb3ZhYmxlQ29sdW1ucyA9IHRydWVcclxuICAgICAqIGhlbmNlIHdlIG5lZWQgdG8gYWNjZXNzIHRoZWlyIHByaXZhdGUgdmFyaWFibGUgbG9ja1Bvc2l0aW9uIGFuZCBsb2NrUGlubmVkIHRvIHN1cHByZXNzIHRoZSBjb2x1bW4gbW92ZW1lbnRcclxuICAgICAqIHBhcmFtIHthbnl9IF9jb2x1bW5zIFtlaXRoZXIgcGFzc2VkIGluIGZyb20gZ3JpZEV2ZW50OiBjb2x1bW4gb3Igd2lsbCBnZXRBbGxEaXNwbGF5ZWRDb2x1bW5zXVxyXG4gICAgICovXHJcbiAgICBwcml2YXRlIF9zZXRQaXZvdENvbHVtbnMoX2NvbHVtbnM/OiBhbnkpOiB2b2lkIHtcclxuICAgICAgICBsZXQgaXNQaW5uZWQ6IGJvb2xlYW4gPSBmYWxzZTtcclxuICAgICAgICBpZiAoIV9jb2x1bW5zKSBfY29sdW1ucyA9IHRoaXMuZ3JpZE9wdGlvbnMuY29sdW1uQXBpLmdldEFsbERpc3BsYXllZENvbHVtbnMoKTtcclxuICAgICAgICBfY29sdW1ucy5mb3JFYWNoKChjb2x1bW46IGFueSkgPT4ge1xyXG4gICAgICAgICAgICB0aGlzLl9zZXRDb2x1bW4oY29sdW1uKTtcclxuICAgICAgICAgICAgbGV0IGNvbHVtbkRlZiA9IGNvbHVtbi5nZXRDb2xEZWYoKTtcclxuICAgICAgICAgICAgaWYgKGNvbHVtbkRlZi5waXZvdFZhbHVlQ29sdW1uKSB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLl9zZXRDb2x1bW4oY29sdW1uRGVmLnBpdm90VmFsdWVDb2x1bW4pXHJcbiAgICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgICAgICBpZiAoY29sdW1uLnBhcmVudCkge1xyXG4gICAgICAgICAgICAgICAgICAgIGlzUGlubmVkID0gdHJ1ZTtcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLl9zZXRDb2x1bW4oY29sdW1uLnBhcmVudCwgZmFsc2UpO1xyXG4gICAgICAgICAgICAgICAgICAgIGNvbHVtbi5wYXJlbnQucGlubmVkID0gJ2xlZnQnO1xyXG4gICAgICAgICAgICAgICAgICAgIGNvbHVtbi5waW5uZWQgPSAnbGVmdCc7XHJcbiAgICAgICAgICAgICAgICAgICAgY29sdW1uRGVmLnBpbm5lZCA9ICdsZWZ0JztcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH0pO1xyXG4gICAgICAgIGlmIChpc1Bpbm5lZCkgdGhpcy5fcmVzaXplQ29sdW1uKHRydWUpO1xyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX3NldENvbHVtbihfY29sdW1uOiBhbnksIF9pc1NldENvbERlZjogYm9vbGVhbiA9IHRydWUpOiB2b2lkIHtcclxuICAgICAgICBpZiAoX2lzU2V0Q29sRGVmKSB7XHJcbiAgICAgICAgICAgIGxldCBjb2x1bW5EZWYgPSBfY29sdW1uLmdldENvbERlZigpO1xyXG4gICAgICAgICAgICBjb2x1bW5EZWYuc3VwcHJlc3NNb3ZhYmxlID0gdGhpcy5fc3VwcHJlc3NNb3ZhYmxlQ29sdW1ucztcclxuICAgICAgICAgICAgY29sdW1uRGVmLmxvY2tQb3NpdGlvbiA9IHRoaXMuX3N1cHByZXNzTW92YWJsZUNvbHVtbnM7XHJcbiAgICAgICAgICAgIGNvbHVtbkRlZi5sb2NrUGlubmVkID0gdGhpcy5fc3VwcHJlc3NNb3ZhYmxlQ29sdW1ucztcclxuICAgICAgICB9XHJcbiAgICAgICAgaWYgKF9jb2x1bW4uc2V0TW92aW5nKSB7XHJcbiAgICAgICAgICAgIF9jb2x1bW4uc2V0TW92aW5nKCF0aGlzLl9zdXBwcmVzc01vdmFibGVDb2x1bW5zKTtcclxuICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICBfY29sdW1uLm1vdmluZyA9ICF0aGlzLl9zdXBwcmVzc01vdmFibGVDb2x1bW5zO1xyXG4gICAgICAgIH1cclxuICAgICAgICBfY29sdW1uLmxvY2tQb3NpdGlvbiA9IHRoaXMuX3N1cHByZXNzTW92YWJsZUNvbHVtbnM7XHJcbiAgICAgICAgX2NvbHVtbi5sb2NrUGlubmVkID0gdGhpcy5fc3VwcHJlc3NNb3ZhYmxlQ29sdW1ucztcclxuICAgIH1cclxuICAgIC8vIFRPRE86IHRvIGJlIHJldmlzaXRcclxuXHJcbiAgICAvLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vL1xyXG4gICAgLy8vIENvbHVtbi9Sb3cvQ29uZmlndXJhdGlvbiBHZW5lcmF0aW9uXHJcbiAgICAvLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vL1xyXG4gICAgcHJpdmF0ZSBfc2V0R3JpZE9wdGlvbnMoX3RhYmxlQ29uZmlnOiBJVGFibGVDb25maWcpOiB2b2lkIHtcclxuICAgICAgICBpZiAoX3RhYmxlQ29uZmlnLmhhc093blByb3BlcnR5KCdzdXBwcmVzc01vdmFibGVDb2x1bW5zJykpIHRoaXMuX3N1cHByZXNzTW92YWJsZUNvbHVtbnMgPSBfdGFibGVDb25maWcuc3VwcHJlc3NNb3ZhYmxlQ29sdW1ucztcclxuICAgICAgICB0aGlzLl9kaXJlY3Rpb24gPSA8J3J0bCcgfCAnbHRyJz50aGlzLl9kb21TdmMuZ2V0RG9jdW1lbnREaXJlY3Rpb24oKTtcclxuICAgICAgICBcclxuICAgICAgICB0aGlzLmdyaWRPcHRpb25zID0gdGhpcy5fdGFibGVTZXJ2aWNlLmdlbmVyYXRlR3JpZE9wdGlvbnMoX3RhYmxlQ29uZmlnLCB0aGlzLl9kaXJlY3Rpb24pO1xyXG4gICAgICAgIHRoaXMuZ3JpZE9wdGlvbnMuY29udGV4dFsnZ3JpZElkJ10gPSB0aGlzLmdyaWRJZDtcclxuICAgICAgICB0aGlzLmdyaWRPcHRpb25zLnN1cHByZXNzTW92YWJsZUNvbHVtbnMgPSBmYWxzZTtcclxuICAgICAgICB0aGlzLmdyaWRPcHRpb25zLm9uQ29sdW1uUm93R3JvdXBDaGFuZ2VkID0gKHBhcmFtczogYW55KTogdm9pZCA9PiB7XHJcbiAgICAgICAgICAgIHRoaXMuX3NldFBpdm90Q29sdW1ucyhwYXJhbXMuY29sdW1ucyk7XHJcbiAgICAgICAgICAgIHRoaXMuX2V4cGFuZEdyb3VwKCk7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIHRoaXMuX3RhYmxlU2VydmljZS5zZXRHcmlkT3B0aW9ucyh0aGlzLmdyaWRPcHRpb25zKTtcclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF9zZXRDb2x1bW5EZWYoX2NvbERlZkNvbmZpZzogQXJyYXk8SVRhYmxlQ29sdW1uPik6IHZvaWQge1xyXG4gICAgICAgIHRoaXMuX3RhYmxlU2VydmljZS5zZXRDb2x1bW5EZWYoX2NvbERlZkNvbmZpZywgdGhpcy5jb25maWcsIHRoaXMuX3N1cHByZXNzTW92YWJsZUNvbHVtbnMpO1xyXG4gICAgICAgIHRoaXMuX3Jlc2l6ZUNvbHVtbigpO1xyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX2VuYWJsZUNvbHVtbk1vdmFibGUoX2VuYWJsZWQ6IGJvb2xlYW4gPSB0cnVlKTogdm9pZCB7XHJcbiAgICAgICAgaWYgKHRoaXMuX3RhYmxlU2VydmljZS5pc0FwaVJlYWR5KHRoaXMuZ3JpZE9wdGlvbnMpKSB7XHJcbiAgICAgICAgICAgIHRoaXMuX3N1cHByZXNzTW92YWJsZUNvbHVtbnMgPSBfZW5hYmxlZDtcclxuXHJcbiAgICAgICAgICAgIHRoaXMuX3NldENvbHVtbkRlZih0aGlzLmNvbHVtbik7XHJcbiAgICAgICAgICAgIGlmICh0aGlzLmNvbmZpZy5sb2FkVHlwZSA9PT0gJ25vcm1hbCcgJiYgdGhpcy5jb25maWcucGl2b3QudG9vbHBhbmVsLnR5cGUgPT09ICdwaXZvdCcpIHtcclxuICAgICAgICAgICAgICAgIHRoaXMuX3NldFBpdm90U3RhdGUodGhpcy5fY3VycmVudFN0YXRlKTtcclxuICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgdGhpcy5fcGl2b3RSZXNpemUoKTtcclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfc2V0Um93RGF0YShfcm93RGF0YTogQXJyYXk8YW55PiwgX3NldFRvR3JpZE9wdGlvbnM6IGJvb2xlYW4gPSB0cnVlKTogdm9pZCB7XHJcbiAgICAgICAgLy8gdGhpcy5fdGFibGVTZXJ2aWNlLnVwZGF0ZVJvd0RhdGFXaXRoQ29sdW1uQ29uZmlnKF9yb3dEYXRhLCB0aGlzLmNvbHVtbiwgdGhpcy5ncmlkSWQpO1xyXG4gICAgICAgIHRoaXMuX3RhYmxlU2VydmljZS51cGRhdGVSb3dEYXRhV2l0aENvbHVtbihfcm93RGF0YSwgdGhpcy5jb2x1bW4sIHRoaXMuZ3JpZElkLCB0aGlzLmdyaWRPcHRpb25zKTtcclxuXHJcbiAgICAgICAgaWYgKF9zZXRUb0dyaWRPcHRpb25zKSB7XHJcbiAgICAgICAgICAgIHRoaXMuX3RhYmxlU2VydmljZS5zZXRSb3dEYXRhKF9yb3dEYXRhKTtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIGlmICh0aGlzLl90YWJsZVNlcnZpY2UuaXNFbnRlcnByaXNlTW9kZWwodGhpcy5jb25maWcubG9hZFR5cGUpICYmIHRoaXMuX3RhYmxlU2VydmljZS5pc0FwaVJlYWR5KHRoaXMuZ3JpZE9wdGlvbnMpKSB7XHJcbiAgICAgICAgICAgIHRoaXMuX2dyaWRSZWFkeUVudGVycHJpc2VDeWNsZSgpO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgdGltZXIoKS5zdWJzY3JpYmUoKCk6IHZvaWQgPT4ge1xyXG4gICAgICAgICAgICB0aGlzLl9ncmlkU2V0Um93Q3ljbGUoKTtcclxuICAgICAgICAgICAgdGhpcy5fc2V0VGFibGVCb3JkZXJCb3R0b20oKTtcclxuICAgICAgICB9KTtcclxuICAgIH1cclxuXHJcbiAgICAvLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vL1xyXG4gICAgLy8vIEV2ZW50cyAtIFN1YnNjcmliZXIgLyBPbiBmdW5jdGlvbnNcclxuICAgIC8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vXHJcbiAgICBwcml2YXRlIF9wcm9jZXNzRXZlbnRQYXJhbXM8VD4oX2Zyb21FdmVudDogc3RyaW5nLCBfYWRkaXRpb25hbFBhcmFtczogVCk6IHZvaWQge1xyXG4gICAgICAgIHN3aXRjaCAoX2Zyb21FdmVudCkge1xyXG4gICAgICAgICAgICBjYXNlICdkYXRhc291cmNlJzpcclxuICAgICAgICAgICAgY2FzZSAnc2VsZWN0aW9uJzpcclxuICAgICAgICAgICAgY2FzZSAnaW5wdXQnOlxyXG4gICAgICAgICAgICBjYXNlICdidXR0b24nOlxyXG4gICAgICAgICAgICAgICAgdGhpcy5fYnJvYWRjYXN0RXZlbnRQYXJhbXM8VD4oX2FkZGl0aW9uYWxQYXJhbXMpO1xyXG4gICAgICAgICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgICAgIGRlZmF1bHQ6XHJcbiAgICAgICAgICAgICAgICBjb25zb2xlLmVycm9yKCdLZFRhYmxlIHdhcm5pbmc6IE5vIHN1Y2ggZXZlbnQgZm91bmQgZm9yOiAnLCBfZnJvbUV2ZW50KTtcclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfYnJvYWRjYXN0RXZlbnRQYXJhbXM8VD4oX3BhcmFtczogVCk6IHZvaWQge1xyXG4gICAgICAgIHRoaXMuX3RhYmxlSW50RXZlbnQua2RUYWJsZUV2ZW50TGlzdCh0aGlzLmNvbmZpZy5pZCwgX3BhcmFtcyk7XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfYnJvYWRjYXN0TW9kZWxDaGFuZ2VkRXZlbnQoKTogdm9pZCB7XHJcbiAgICAgICAgdGhpcy5fdGFibGVJbnRFdmVudC5tb2RlbENoYW5nZWQodGhpcy5jb25maWcuaWQpO1xyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX3NldHVwU3Vic2NyaXB0aW9uRXZlbnRzKCkge1xyXG4gICAgICAgIHRoaXMuX3N1YnNjcmlwdGlvbk9iai5zZWxlY3ROb2Rlc1N1YiA9IHRoaXMuX3RhYmxlSW50RXZlbnQub25TZWxlY3Rpb25DaGFuZ2VkKHRoaXMuY29uZmlnLmlkKS5zdWJzY3JpYmUoKF9yb3dOb2RlOiBSb3dOb2RlKTogdm9pZCA9PiB7XHJcbiAgICAgICAgICAgIHRoaXMuX3VwZGF0ZVNlbGVjdGlvbk5vZGVzKF9yb3dOb2RlKTtcclxuICAgICAgICB9KTtcclxuXHJcbiAgICAgICAgdGhpcy5fc3Vic2NyaXB0aW9uT2JqLmdyaWRRdWVzdGlvblN1YiA9IHRoaXMuX3RhYmxlSW50RXZlbnQub25JbnB1dENoYW5nZWQodGhpcy5jb25maWcuaWQpLnN1YnNjcmliZSgoX2Zvcm1QYXJhbXM6IElUYWJsZUZvcm1FbWl0UGFyYW1zKTogdm9pZCA9PiB7XHJcbiAgICAgICAgICAgIHRoaXMuX3Byb2Nlc3NJbnB1dENoYW5nZWQoX2Zvcm1QYXJhbXMpO1xyXG4gICAgICAgIH0pO1xyXG5cclxuICAgICAgICB0aGlzLl9zdWJzY3JpcHRpb25PYmoudXBkYXRlRW1pdFJvdyA9IHRoaXMuX3RhYmxlSW50RXZlbnQub25VcGRhdGVFbWl0Um93Tm9kZXModGhpcy5jb25maWcuaWQpLnN1YnNjcmliZSgoX2RhdGE6IHsgYWN0aW9uOiBzdHJpbmcsIHJvd0RhdGE6IGFueSB9KTogdm9pZCA9PiB7XHJcbiAgICAgICAgICAgIGlmIChfZGF0YS5hY3Rpb24gPT09ICdkZWxldGUnKSB7XHJcbiAgICAgICAgICAgICAgICBsZXQgcm93S2V5OiBzdHJpbmcgPSAodHlwZW9mIHRoaXMuY29uZmlnLnJvd0lkS2V5ICE9PSAndW5kZWZpbmVkJykgPyB0aGlzLmNvbmZpZy5yb3dJZEtleSA6ICdpZCc7XHJcbiAgICAgICAgICAgICAgICB0aGlzLl9kZWxldGVOb2RlRnJvbVJvd0RhdGEoW19kYXRhLnJvd0RhdGFbcm93S2V5XV0pO1xyXG4gICAgICAgICAgICAgICAgdGhpcy5fZW1pdElucHV0VXBkYXRlRXZlbnQoKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH0pO1xyXG4gICAgfVxyXG5cclxuICAgIC8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vXHJcbiAgICAvLy8gU2VsZWN0aW9uIC0gQ2hlY2tib3ggLyBSYWRpbyBmdW5jdGlvbnNcclxuICAgIC8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vXHJcbiAgICBwcml2YXRlIF91cGRhdGVTZWxlY3Rpb25Ob2Rlcyhfcm93Tm9kZTogUm93Tm9kZSwgX2lzSW5pdGlhbD86IGJvb2xlYW4pOiB2b2lkIHtcclxuICAgICAgICBsZXQgdHJpZ2dlck5vZGU6IHN0cmluZyA9ICh0eXBlb2YgX2lzSW5pdGlhbCAhPT0gJ3VuZGVmaW5lZCcgJiYgX2lzSW5pdGlhbCkgPyAnaW5pdGlhbCcgOiAnYWxsJztcclxuICAgICAgICBpZiAodHlwZW9mIF9yb3dOb2RlICE9PSAndW5kZWZpbmVkJykge1xyXG4gICAgICAgICAgICB0cmlnZ2VyTm9kZSA9IF9yb3dOb2RlLmRhdGEuaWQ7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICBsZXQgc2VsZWN0aW9uUGFyYW1zOiBLZFRhYmxlU2VsZWN0aW9uVXBkYXRlRXZlbnQgPSBuZXcgS2RUYWJsZVNlbGVjdGlvblVwZGF0ZUV2ZW50KCk7XHJcblxyXG4gICAgICAgIHNlbGVjdGlvblBhcmFtcy50cmlnZ2VyTm9kZSA9IHRyaWdnZXJOb2RlO1xyXG4gICAgICAgIHNlbGVjdGlvblBhcmFtcy5zZWxlY3RlZE5vZGVzID0gdGhpcy5fdGFibGVTZXJ2aWNlLnVwZGF0ZVNlbGVjdGlvblZhbHVlcyh0aGlzLmdyaWRPcHRpb25zLnJvd0RhdGEsIHRoaXMuY29uZmlnLnNlbGVjdGlvbi52YWx1ZSwgdGhpcy5jb25maWcuc2VsZWN0aW9uLnJldHVybktleSwgdGhpcy5jb25maWcubG9hZFR5cGUpO1xyXG4gICAgICAgIC8vIHNlbGVjdGlvblBhcmFtcy5zZWxlY3Rpb24gPSAoX3Jvd05vZGUuaXNTZWxlY3RlZCgpKSA/ICdzZWxlY3RlZCcgOiAndW5zZWxlY3RlZCc7XHJcblxyXG4gICAgICAgIHRoaXMuX3Byb2Nlc3NFdmVudFBhcmFtczxLZFRhYmxlU2VsZWN0aW9uVXBkYXRlRXZlbnQ+KCdzZWxlY3Rpb24nLCBzZWxlY3Rpb25QYXJhbXMpO1xyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX3Byb2Nlc3NJbml0aWFsU2VsZWN0aW9uKCk6IHZvaWQge1xyXG4gICAgICAgIHRoaXMuX3VwZGF0ZVNlbGVjdGlvbk5vZGVzKHVuZGVmaW5lZCwgdHJ1ZSk7XHJcbiAgICB9XHJcblxyXG4gICAgLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy9cclxuICAgIC8vLyBJbnB1dCBmdW5jdGlvbnNcclxuICAgIC8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vXHJcbiAgICBwcml2YXRlIF9wcm9jZXNzSW5wdXRDaGFuZ2VkKF9mb3JtUGFyYW1zOiBJVGFibGVGb3JtRW1pdFBhcmFtcyk6IHZvaWQge1xyXG4gICAgICAgIGxldCBpbnB1dFBhcmFtczogS2RUYWJsZUlucHV0VXBkYXRlRXZlbnQgPSBuZXcgS2RUYWJsZUlucHV0VXBkYXRlRXZlbnQoKTtcclxuXHJcbiAgICAgICAgaW5wdXRQYXJhbXMuY29sSWQgPSBfZm9ybVBhcmFtcy5jb2xJZDtcclxuICAgICAgICBpbnB1dFBhcmFtcy5yb3dJZCA9IF9mb3JtUGFyYW1zLnJvd0lkO1xyXG4gICAgICAgIGlucHV0UGFyYW1zLnF1ZXN0aW9uS2V5ID0gX2Zvcm1QYXJhbXMucXVlc3Rpb25LZXk7XHJcbiAgICAgICAgaW5wdXRQYXJhbXMucXVlc3Rpb24gPSBfZm9ybVBhcmFtcy5xdWVzdGlvbjtcclxuICAgICAgICBpbnB1dFBhcmFtcy52YWx1ZSA9IF9mb3JtUGFyYW1zLmRhdGE7XHJcblxyXG4gICAgICAgIHRoaXMuX3Byb2Nlc3NFdmVudFBhcmFtczxLZFRhYmxlSW5wdXRVcGRhdGVFdmVudD4oJ2lucHV0JywgaW5wdXRQYXJhbXMpO1xyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX2VtaXRJbnB1dFVwZGF0ZUV2ZW50KCk6IHZvaWQge1xyXG4gICAgICAgIGxldCBpbnB1dFBhcmFtczogS2RUYWJsZUlucHV0VXBkYXRlRXZlbnQgPSBuZXcgS2RUYWJsZUlucHV0VXBkYXRlRXZlbnQoKTtcclxuICAgICAgICB0aGlzLl9wcm9jZXNzRXZlbnRQYXJhbXM8S2RUYWJsZUlucHV0VXBkYXRlRXZlbnQ+KCdpbnB1dCcsIGlucHV0UGFyYW1zKTtcclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF9kZWxldGVOb2RlRnJvbVJvd0RhdGEoX2RhdGFMaXN0OiBBcnJheTxzdHJpbmc+KTogdm9pZCB7XHJcbiAgICAgICAgbGV0IHJvd0lkS2V5OiBzdHJpbmcgPSAodHlwZW9mIHRoaXMuY29uZmlnLnJvd0lkS2V5ICE9PSAndW5kZWZpbmVkJykgPyB0aGlzLmNvbmZpZy5yb3dJZEtleSA6ICdpZCc7XHJcblxyXG4gICAgICAgIGZvciAobGV0IGk6IG51bWJlciA9IDA7IGkgPCBfZGF0YUxpc3QubGVuZ3RoOyArK2kpIHtcclxuICAgICAgICAgICAgZm9yIChsZXQgajogbnVtYmVyID0gMDsgaiA8IHRoaXMucm93Lmxlbmd0aDsgKytqKSB7XHJcbiAgICAgICAgICAgICAgICBpZiAoX2RhdGFMaXN0W2ldLnRvU3RyaW5nKCkgPT09IHRoaXMucm93W2pdW3Jvd0lkS2V5XS50b1N0cmluZygpKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5yb3cuc3BsaWNlKGosIDEpO1xyXG4gICAgICAgICAgICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIC8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vXHJcbiAgICAvLy8gRW50ZXJwcmlzZSBkYXRhc291cmNlIGZ1bmN0aW9uc1xyXG4gICAgLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy9cclxuICAgIHByaXZhdGUgX2NsZWFyRGF0YXNvdXJjZSgpOiB2b2lkIHtcclxuICAgICAgICBpZiAodGhpcy5fdGFibGVTZXJ2aWNlLmlzQXBpUmVhZHkodGhpcy5ncmlkT3B0aW9ucykpIHtcclxuICAgICAgICAgICAgdGhpcy5ncmlkT3B0aW9ucy5hcGkuc2V0RW50ZXJwcmlzZURhdGFzb3VyY2UobnVsbCk7XHJcbiAgICAgICAgICAgIHRoaXMuZ3JpZE9wdGlvbnMuYXBpLnNldEZpbHRlck1vZGVsKG51bGwpO1xyXG4gICAgICAgICAgICB0aGlzLmdyaWRPcHRpb25zLmFwaS5zZXRTb3J0TW9kZWwobnVsbCk7XHJcblxyXG4gICAgICAgICAgICBpZiAodHlwZW9mIHRoaXMuX3N1YnNjcmlwdGlvbk9iai5kYXRhc291cmNlU3ViICE9PSAndW5kZWZpbmVkJykge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5fc3Vic2NyaXB0aW9uT2JqLmRhdGFzb3VyY2VTdWIudW5zdWJzY3JpYmUoKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF9nZW5lcmF0ZUVudGVycHJpc2VEYXRhc291cmNlKCk6IHZvaWQge1xyXG4gICAgICAgIGxldCBkYXRhc291cmNlOiBJRW50ZXJwcmlzZURhdGFzb3VyY2UgPSB7XHJcbiAgICAgICAgICAgIGdldFJvd3M6IChfcGFyYW1zOiBJRW50ZXJwcmlzZUdldFJvd3NQYXJhbXMpOiB2b2lkID0+IHtcclxuICAgICAgICAgICAgICAgIHRoaXMuX3Nob3dMb2FkaW5nT3ZlcmxheSh0cnVlKTtcclxuXHJcbiAgICAgICAgICAgICAgICBpZiAodHlwZW9mIHRoaXMuX3N1YnNjcmlwdGlvbk9iai5kYXRhc291cmNlU3ViICE9PSAndW5kZWZpbmVkJykge1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuX3N1YnNjcmlwdGlvbk9iai5kYXRhc291cmNlU3ViLnVuc3Vic2NyaWJlKCk7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICB0aGlzLl9zdWJzY3JpcHRpb25PYmouZGF0YXNvdXJjZVN1YiA9IHRoaXMuX2dlbmVyYXRlRGF0YXNvdXJjZVJvd3MoX3BhcmFtcykuc3Vic2NyaWJlKChfcmVzcG9uc2U6IElUYWJsZURhdGFzb3VyY2VQYXJhbXMpOiB2b2lkID0+IHtcclxuICAgICAgICAgICAgICAgICAgICBfcGFyYW1zLnN1Y2Nlc3NDYWxsYmFjayhfcmVzcG9uc2Uucm93cywgX3Jlc3BvbnNlLnRvdGFsKTtcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLl9zaG93TG9hZGluZ092ZXJsYXkoZmFsc2UpO1xyXG4gICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9O1xyXG5cclxuICAgICAgICB0aGlzLmdyaWRPcHRpb25zLmFwaS5zZXRFbnRlcnByaXNlRGF0YXNvdXJjZShkYXRhc291cmNlKTtcclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF9nZW5lcmF0ZURhdGFzb3VyY2VSb3dzKF9kYXRhc291cmNlUGFyYW1zOiBJRW50ZXJwcmlzZUdldFJvd3NQYXJhbXMpOiBPYnNlcnZhYmxlPElUYWJsZURhdGFzb3VyY2VQYXJhbXM+IHtcclxuICAgICAgICByZXR1cm4gbmV3IE9ic2VydmFibGU8SVRhYmxlRGF0YXNvdXJjZVBhcmFtcz4oKF9vYnNlcnZlcjogU3Vic2NyaWJlcjxJVGFibGVEYXRhc291cmNlUGFyYW1zPik6IHZvaWQgPT4ge1xyXG4gICAgICAgICAgICBzd2l0Y2ggKHRoaXMuY29uZmlnLmxvYWRUeXBlKSB7XHJcbiAgICAgICAgICAgICAgICBjYXNlICdpbmZpbml0ZSc6XHJcbiAgICAgICAgICAgICAgICBjYXNlICdvbmVzaG90JzpcclxuICAgICAgICAgICAgICAgICAgICAoPEtkVGFibGVFbnRlcnByaXNlU3ZjPnRoaXMuX3RhYmxlU2VydmljZSkuZ2VuZXJhdGVEYXRhc291cmNlUm93cyhfZGF0YXNvdXJjZVBhcmFtcy5yZXF1ZXN0LCB0aGlzLmdyaWRPcHRpb25zLnJvd0RhdGEuc2xpY2UoKSkuc3Vic2NyaWJlKChfcmVzcG9uc2U6IElUYWJsZURhdGFzb3VyY2VQYXJhbXMpOiB2b2lkID0+IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgX29ic2VydmVyLm5leHQoX3Jlc3BvbnNlKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgX29ic2VydmVyLmNvbXBsZXRlKCk7XHJcbiAgICAgICAgICAgICAgICAgICAgfSk7XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgICAgICAgICAgY2FzZSAnc2VydmVyJzpcclxuICAgICAgICAgICAgICAgICAgICBsZXQgc2VydmVyUGFyYW1zOiBLZFRhYmxlRGF0YXNvdXJjZUV2ZW50ID0gbmV3IEtkVGFibGVEYXRhc291cmNlRXZlbnQoX2RhdGFzb3VyY2VQYXJhbXMucmVxdWVzdCwgX29ic2VydmVyKTtcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLl9wcm9jZXNzRXZlbnRQYXJhbXM8S2RUYWJsZURhdGFzb3VyY2VFdmVudD4oJ2RhdGFzb3VyY2UnLCBzZXJ2ZXJQYXJhbXMpO1xyXG5cclxuICAgICAgICAgICAgICAgICAgICBicmVhaztcclxuICAgICAgICAgICAgICAgIGRlZmF1bHQ6XHJcbiAgICAgICAgICAgICAgICAgICAgY29uc29sZS5lcnJvcignS2RUYWJsZSB3YXJuaW5nOiBObyBzdWNoIGxvYWRUeXBlIGZpbmQgZm9yOiAnLCB0aGlzLmNvbmZpZy5sb2FkVHlwZSk7XHJcbiAgICAgICAgICAgICAgICAgICAgX29ic2VydmVyLmNvbXBsZXRlKCk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9KTtcclxuICAgIH1cclxuXHJcbiAgICAvLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vL1xyXG4gICAgLy8vIEFQSSBmdW5jdGlvbnNcclxuICAgIC8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vXHJcbiAgICBwcml2YXRlIF9pbml0SVRhYmxlQXBpKCk6IHZvaWQge1xyXG4gICAgICAgIGlmICh0eXBlb2YgdGhpcy5hcGkgIT09ICd1bmRlZmluZWQnKSB7XHJcbiAgICAgICAgICAgIGxldCBhcGlQYXJhbXM6IGFueSA9IHtcclxuICAgICAgICAgICAgICAgIC8vIGdyaWRPcHRpb25zOiB0aGlzLmdyaWRPcHRpb25zLFxyXG4gICAgICAgICAgICAgICAgZXZlbnQ6IHRoaXMuX3RhYmxlSW50RXZlbnQsXHJcbiAgICAgICAgICAgICAgICBpZDogdGhpcy5jb25maWcuaWQsXHJcbiAgICAgICAgICAgICAgICByb3dzOiB0aGlzLnJvdyxcclxuICAgICAgICAgICAgICAgIGNvbHVtbnM6IHRoaXMuY29sdW1uXHJcbiAgICAgICAgICAgIH07XHJcblxyXG4gICAgICAgICAgICB0aGlzLl90YWJsZVNlcnZpY2UuZ2VuZXJhdGVkQXBpRnVuY3Rpb25zKHRoaXMuYXBpLCBhcGlQYXJhbXMpO1xyXG5cclxuICAgICAgICAgICAgLy8vIFRlbXAgZml4IHRvIGFjY2VzcyBsb2FkaW5nIHZhcmlhYmxlIC8vXHJcbiAgICAgICAgICAgIC8qKioqKioqKiogR2VuZXJhbCBBUEkgKioqKioqKioqKi9cclxuICAgICAgICAgICAgdGhpcy5hcGkuZ2VuZXJhbC5zaG93TG9hZGluZyA9IChfdG9nZ2xlOiBib29sZWFuKTogdm9pZCA9PiB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLmRpc3BsYXlMb2FkaW5nID0gX3RvZ2dsZTtcclxuICAgICAgICAgICAgfTtcclxuXHJcbiAgICAgICAgICAgIHRoaXMuYXBpLmdlbmVyYWwudXBkYXRlQ2VsbCA9IChfdGFibGVDZWxsUGFyYW1zOiBJVGFibGVDZWxsUGFyYW1zKTogdm9pZCA9PiB7XHJcbiAgICAgICAgICAgICAgICBsZXQgdG9VcGRhdGVOb2RlOiBBcnJheTxSb3dOb2RlPiA9IFtdO1xyXG5cclxuICAgICAgICAgICAgICAgIHRoaXMuZ3JpZE9wdGlvbnMuYXBpLmZvckVhY2hOb2RlKChfcm93Tm9kZTogUm93Tm9kZSk6IHZvaWQgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgIGlmICh0eXBlb2YgX3Jvd05vZGUuaWQgIT09ICd1bmRlZmluZWQnICYmIF9yb3dOb2RlLmlkID09PSBfdGFibGVDZWxsUGFyYW1zLnJvd0lkKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIF9yb3dOb2RlLmRhdGFbX3RhYmxlQ2VsbFBhcmFtcy5jb2xJZF0gPSBfdGFibGVDZWxsUGFyYW1zLmRhdGE7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHRvVXBkYXRlTm9kZS5wdXNoKF9yb3dOb2RlKTtcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICB9KTtcclxuXHJcbiAgICAgICAgICAgICAgICBsZXQgcmVmcmVzaFBhcmFtczogeyByb3dOb2RlczogQXJyYXk8Um93Tm9kZT4sIGNvbHVtbnM6IEFycmF5PGFueT4gfSA9IHtcclxuICAgICAgICAgICAgICAgICAgICByb3dOb2RlczogdG9VcGRhdGVOb2RlLFxyXG4gICAgICAgICAgICAgICAgICAgIGNvbHVtbnM6IFtfdGFibGVDZWxsUGFyYW1zLmNvbElkXVxyXG4gICAgICAgICAgICAgICAgfTtcclxuXHJcbiAgICAgICAgICAgICAgICB0aGlzLmdyaWRPcHRpb25zLmFwaS5yZWZyZXNoQ2VsbHMocmVmcmVzaFBhcmFtcyk7XHJcbiAgICAgICAgICAgIH07XHJcblxyXG4gICAgICAgICAgICB0aGlzLmFwaS5nZW5lcmFsLnNlYXJjaFJvdyA9IChfc2VhcmNoVGV4dDogc3RyaW5nKTogdm9pZCA9PiB7XHJcbiAgICAgICAgICAgICAgICBpZiAodGhpcy5jb25maWcubG9hZFR5cGUgPT09ICdub3JtYWwnKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5ncmlkT3B0aW9ucy5hcGkuc2V0UXVpY2tGaWx0ZXIoX3NlYXJjaFRleHQpO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgZWxzZSB7XHJcbiAgICAgICAgICAgICAgICAgICAgY29uc29sZS53YXJuKCdLZFRhYmxlIHdhcm5pbmc6IFF1aWNrIGZpbHRlcmluZyBvZiBkYXRhIGlzIG5vdCBzdXBwb3J0ZWQgZm9yIG9uZXNob3Qvc2VydmVyL2luZmluaXRlIGxvYWRUeXBlLicpO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9O1xyXG5cclxuICAgICAgICAgICAgdGhpcy5hcGkuZ2VuZXJhbC5hZGRSb3dzID0gKF9yb3dzOiBBcnJheTxhbnk+LCBfc2Nyb2xsVG9WaXNpYmxlOiBib29sZWFuID0gZmFsc2UpOiB2b2lkID0+IHtcclxuICAgICAgICAgICAgICAgIC8qXHJcbiAgICAgICAgICAgICAgICAgICAgYWctR3JpZCBkaWQgbm90IGV4cG9ydCBSb3dEYXRhVHJhbnNhY3Rpb24gaW50ZXJmYWNlLiBJbnRlcmZhY2UgYXM6XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGFkZDogW10sXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICByZW1vdmU6IFtdLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdXBkYXRlOiBbXVxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgKi9cclxuICAgICAgICAgICAgICAgIGlmICh0eXBlb2YgdGhpcy5jb25maWcubG9hZFR5cGUgPT09ICd1bmRlZmluZWQnIHx8IHRoaXMuY29uZmlnLmxvYWRUeXBlID09PSAnbm9ybWFsJykge1xyXG4gICAgICAgICAgICAgICAgICAgIGxldCByb3dLZXk6IHN0cmluZyA9ICh0eXBlb2YgdGhpcy5jb25maWcucm93SWRLZXkgIT09ICd1bmRlZmluZWQnKSA/IHRoaXMuY29uZmlnLnJvd0lkS2V5IDogJ2lkJztcclxuXHJcbiAgICAgICAgICAgICAgICAgICAgZm9yIChsZXQgaTogbnVtYmVyID0gMDsgaSA8IF9yb3dzLmxlbmd0aDsgKytpKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMucm93LnB1c2goX3Jvd3NbaV0pO1xyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5fc2V0Um93RGF0YSh0aGlzLnJvdywgZmFsc2UpO1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuZ3JpZE9wdGlvbnMuYXBpLnVwZGF0ZVJvd0RhdGEoeyBhZGQ6IF9yb3dzLnNsaWNlKCkgfSk7XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIGlmIChfc2Nyb2xsVG9WaXNpYmxlKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuZ3JpZE9wdGlvbnMuYXBpLmVuc3VyZUluZGV4VmlzaWJsZSh0aGlzLmdyaWRPcHRpb25zLmFwaS5nZXRSb3dOb2RlKF9yb3dzWzBdW3Jvd0tleV0udG9TdHJpbmcoKSkucm93SW5kZXgpO1xyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgICAgIGNvbnNvbGUud2FybignS2RUYWJsZSB3YXJuaW5nOiBBUEkgZnVuY3Rpb246IGFkZFJvd3MoKSBjYW4gb25seSBiZSB1c2VkIGZvciBub3JtYWwgbG9hZFR5cGUuJyk7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH07XHJcblxyXG4gICAgICAgICAgICB0aGlzLmFwaS5nZW5lcmFsLmRlbGV0ZVJvd3MgPSAoX2lkOiBBcnJheTxzdHJpbmcgfCBudW1iZXI+IHwgc3RyaW5nIHwgbnVtYmVyKTogdm9pZCA9PiB7XHJcbiAgICAgICAgICAgICAgICBpZiAodHlwZW9mIHRoaXMuY29uZmlnLmxvYWRUeXBlID09PSAndW5kZWZpbmVkJyB8fCB0aGlzLmNvbmZpZy5sb2FkVHlwZSA9PT0gJ25vcm1hbCcpIHtcclxuICAgICAgICAgICAgICAgICAgICBsZXQgZGVsZXRlSWRMaXN0OiBBcnJheTxzdHJpbmc+ID0gW107XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIGlmICh0eXBlb2YgX2lkID09PSAnc3RyaW5nJyB8fCB0eXBlb2YgX2lkID09PSAnbnVtYmVyJykge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBkZWxldGVJZExpc3QucHVzaChfaWQudG9TdHJpbmcoKSk7XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBmb3IgKGxldCBpOiBudW1iZXIgPSAwOyBpIDwgX2lkLmxlbmd0aDsgKytpKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBkZWxldGVJZExpc3QucHVzaChfaWQudG9TdHJpbmcoKSk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuX2RlbGV0ZU5vZGVGcm9tUm93RGF0YShkZWxldGVJZExpc3QpO1xyXG5cclxuICAgICAgICAgICAgICAgICAgICBsZXQga2V5OiBzdHJpbmcgPSB0eXBlb2YgdGhpcy5jb25maWcucm93SWRLZXkgPT09ICd1bmRlZmluZWQnID8gJ2lkJyA6IHRoaXMuY29uZmlnLnJvd0lkS2V5O1xyXG4gICAgICAgICAgICAgICAgICAgIGxldCBkZWxldGVSb3dzOiBBcnJheTxhbnk+ID0gW107XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIGZvciAobGV0IGk6IG51bWJlciA9IDA7IGkgPCBkZWxldGVJZExpc3QubGVuZ3RoOyArK2kpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgZGVsZXRlUm93cy5wdXNoKHsgW2tleV06IGRlbGV0ZUlkTGlzdFtpXSB9KTtcclxuICAgICAgICAgICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIC8qXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGFnLUdyaWQgZGlkIG5vdCBleHBvcnQgUm93RGF0YVRyYW5zYWN0aW9uIGludGVyZmFjZS4gSW50ZXJmYWNlIGFzOlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGFkZDogW10sXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcmVtb3ZlOiBbXSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB1cGRhdGU6IFtdXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICovXHJcblxyXG4gICAgICAgICAgICAgICAgICAgIGxldCB0cmFuc2FjdGlvbk9iajogeyBhZGQ/OiBBcnJheTxhbnk+LCByZW1vdmU/OiBBcnJheTxhbnk+LCB1cGRhdGU/OiBBcnJheTxhbnk+IH0gPSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHJlbW92ZTogZGVsZXRlUm93c1xyXG4gICAgICAgICAgICAgICAgICAgIH07XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuZ3JpZE9wdGlvbnMuYXBpLnVwZGF0ZVJvd0RhdGEodHJhbnNhY3Rpb25PYmopO1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuX2VtaXRJbnB1dFVwZGF0ZUV2ZW50KCk7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgICAgICAgICBjb25zb2xlLndhcm4oJ0tkVGFibGUgd2FybmluZzogQVBJIGZ1bmN0aW9uOiBhZGRSb3dzKCkgY2FuIG9ubHkgYmUgdXNlZCBmb3Igbm9ybWFsIGxvYWRUeXBlLicpO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9O1xyXG5cclxuICAgICAgICAgICAgdGhpcy5hcGkuZ2VuZXJhbC5zZXRCdXR0b25EaXNhYmxlZCA9IChfYnV0dG9uVHlwZTogc3RyaW5nLCBfdG9EaXNhYmxlZDogYm9vbGVhbikgPT4ge1xyXG4gICAgICAgICAgICAgICAgZm9yIChsZXQgaTogbnVtYmVyID0gMDsgaSA8IHRoaXMuY29uZmlnLmJ1dHRvbi5sZW5ndGg7ICsraSkge1xyXG4gICAgICAgICAgICAgICAgICAgIGlmICh0aGlzLmNvbmZpZy5idXR0b25baV0udHlwZSA9PT0gX2J1dHRvblR5cGUpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5jb25maWcuYnV0dG9uW2ldLmRpc2FibGVkID0gX3RvRGlzYWJsZWQ7XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9O1xyXG5cclxuICAgICAgICAgICAgdGhpcy5hcGkuZ2VuZXJhbC5leHBvcnRUb0V4Y2VsID0gKF9wYXJhbXM6IEV4Y2VsRXhwb3J0UGFyYW1zKTogdm9pZCA9PiB7XHJcbiAgICAgICAgICAgICAgICBsZXQgZGVmYXVsdFBhcmFtczogRXhjZWxFeHBvcnRQYXJhbXMgPSB7XHJcbiAgICAgICAgICAgICAgICAgICAgZmlsZU5hbWU6ICdmaWxlJyxcclxuICAgICAgICAgICAgICAgICAgICBhbGxDb2x1bW5zOiB0cnVlLFxyXG4gICAgICAgICAgICAgICAgICAgIHN1cHByZXNzVGV4dEFzQ0RBVEE6IHRydWUsXHJcbiAgICAgICAgICAgICAgICB9O1xyXG4gICAgICAgICAgICAgICAgLy8geGxzeCBvbmx5IGFsbG93IHNoZWV0IG5hbWUgdG8gYmUgMzEgY2hhcmFjdGVycyBsb25nO1xyXG4gICAgICAgICAgICAgICAgaWYgKF9wYXJhbXMuaGFzT3duUHJvcGVydHkoJ3NoZWV0TmFtZScpKSBfcGFyYW1zLnNoZWV0TmFtZSA9IF9wYXJhbXMuc2hlZXROYW1lLnNsaWNlKDAsIDMxKTtcclxuICAgICAgICAgICAgICAgIGxldCBwYXJhbXM6IEV4Y2VsRXhwb3J0UGFyYW1zID0gT2JqZWN0LmFzc2lnbih7fSwgZGVmYXVsdFBhcmFtcywgX3BhcmFtcyk7XHJcbiAgICAgICAgICAgICAgICBsZXQgY29udGVudDogYW55ID0gdGhpcy5ncmlkT3B0aW9ucy5hcGkuZ2V0RGF0YUFzRXhjZWwocGFyYW1zKTtcclxuICAgICAgICAgICAgICAgIGxldCB3b3JrYm9vazogYW55ID0gWExTWC5yZWFkKGNvbnRlbnQsIHsgdHlwZTogJ2JpbmFyeScgfSk7XHJcbiAgICAgICAgICAgICAgICBsZXQgeGxzeENvbnRlbnQ6IGFueSA9IFhMU1gud3JpdGUod29ya2Jvb2ssIHsgYm9va1R5cGU6ICd4bHN4JywgdHlwZTogJ2Jhc2U2NCcgfSk7XHJcbiAgICAgICAgICAgICAgICBsZXQgYmxvYk9iamVjdDogQmxvYiA9IHRoaXMuX3RhYmxlU2VydmljZS5iNjR0b0Jsb2IoeGxzeENvbnRlbnQsICdhcHBsaWNhdGlvbi92bmQub3BlbnhtbGZvcm1hdHMtb2ZmaWNlZG9jdW1lbnQuc3ByZWFkc2hlZXRtbC5zaGVldCcpO1xyXG4gICAgICAgICAgICAgICAgc2F2ZUFzKGJsb2JPYmplY3QsIHBhcmFtcy5maWxlTmFtZSArICcueGxzeCcpO1xyXG4gICAgICAgICAgICB9O1xyXG5cclxuICAgICAgICAgICAgdGhpcy5hcGkuZ2VuZXJhbC5yZXNpemVDb2x1bW4gPSAoX2lzUmVzaXplVG9Db250ZW50OiBib29sZWFuID0gZmFsc2UpOiB2b2lkID0+IHtcclxuICAgICAgICAgICAgICAgIHRoaXMuX3Jlc2l6ZUNvbHVtbihfaXNSZXNpemVUb0NvbnRlbnQpO1xyXG4gICAgICAgICAgICB9O1xyXG5cclxuICAgICAgICAgICAgdGhpcy5hcGkuZ2VuZXJhbC5lbmFibGVDb2x1bW5Nb3ZhYmxlID0gKF9lbmFibGVkOiBib29sZWFuKTogdm9pZCA9PiB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLl9lbmFibGVDb2x1bW5Nb3ZhYmxlKF9lbmFibGVkKTtcclxuICAgICAgICAgICAgfTtcclxuXHJcbiAgICAgICAgICAgIC8qKioqKioqKiogUGl2b3QgQVBJICoqKioqKioqKiovXHJcbiAgICAgICAgICAgIGlmICh0eXBlb2YgKHRoaXMuYXBpLnBpdm90KSA9PT0gJ3VuZGVmaW5lZCcpIHRoaXMuYXBpLnBpdm90ID0ge307XHJcbiAgICAgICAgICAgIHRoaXMuYXBpLnBpdm90LmF1dG9SZXNpemUgPSAoKTogdm9pZCA9PiB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLl9waXZvdFJlc2l6ZSgpO1xyXG4gICAgICAgICAgICB9O1xyXG5cclxuICAgICAgICAgICAgdGhpcy5hcGkucGl2b3Quc2hvd1Rvb2xQYW5lbCA9IChfc2hvdzogYm9vbGVhbik6IHZvaWQgPT4ge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5fc2hvd1Rvb2xQYW5lbChfc2hvdyk7XHJcbiAgICAgICAgICAgIH07XHJcblxyXG4gICAgICAgICAgICB0aGlzLmFwaS5waXZvdC5leHBhbmRHcm91cCA9IChfZXhwYW5kOiBib29sZWFuKTogdm9pZCA9PiB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLl9leHBhbmRHcm91cChfZXhwYW5kKTtcclxuICAgICAgICAgICAgfTtcclxuXHJcbiAgICAgICAgICAgIHRoaXMuYXBpLnBpdm90LmdldFBpdm90U3RhdGUgPSAoKTogSVRhYmxlUGl2b3RTdGF0ZSA9PiB7XHJcbiAgICAgICAgICAgICAgICByZXR1cm4gdGhpcy5fZ2V0UGl2b3RTdGF0ZSgpO1xyXG4gICAgICAgICAgICB9O1xyXG5cclxuICAgICAgICAgICAgdGhpcy5hcGkucGl2b3Quc2V0UGl2b3RTdGF0ZSA9IChfc3RhdGU6IElUYWJsZVBpdm90U3RhdGUpOiB2b2lkID0+IHtcclxuICAgICAgICAgICAgICAgIHRoaXMuX3NldENvbHVtbkRlZih0aGlzLmNvbHVtbik7XHJcbiAgICAgICAgICAgICAgICB0aGlzLl9zZXRQaXZvdFN0YXRlKF9zdGF0ZSk7XHJcbiAgICAgICAgICAgIH07XHJcblxyXG4gICAgICAgICAgICB0aGlzLmFwaS5waXZvdC5lbmFibGVkUGl2b3RNb2RlID0gKF9lbmFibGVkOiBib29sZWFuKTogdm9pZCA9PiB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLl9lbmFibGVkUGl2b3RNb2RlKF9lbmFibGVkKTtcclxuICAgICAgICAgICAgfTtcclxuXHJcbiAgICAgICAgICAgIHRoaXMuYXBpLnBpdm90LnNob3dQaXZvdE1vZGUgPSAoX3Nob3c6IGJvb2xlYW4pOiB2b2lkID0+IHtcclxuICAgICAgICAgICAgICAgIHRoaXMuX3Nob3dQaXZvdE1vZGUoX3Nob3cpO1xyXG4gICAgICAgICAgICB9O1xyXG5cclxuICAgICAgICAgICAgLyoqKioqKioqKiBJbnB1dCBBUEkgKioqKioqKioqKi9cclxuICAgICAgICAgICAgdGhpcy5hcGkuZHluYW1pY0Zvcm0uY2xlYXJBbGxFcnJvciA9ICgpOiB2b2lkID0+IHtcclxuICAgICAgICAgICAgICAgIGxldCB0YWJsZUNvbnRleHQ6IHsgW2tleTogc3RyaW5nXTogYW55IH0gPSB0aGlzLmdyaWRPcHRpb25zLmNvbnRleHRbdGhpcy5fdGFibGVTZXJ2aWNlLmdldFRhYmxlQ29udGV4dEtleSgpXTtcclxuXHJcbiAgICAgICAgICAgICAgICBmb3IgKGxldCBpdGVtIGluIHRhYmxlQ29udGV4dCkge1xyXG4gICAgICAgICAgICAgICAgICAgIGlmICh0YWJsZUNvbnRleHQuaGFzT3duUHJvcGVydHkoaXRlbSkpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgbGV0IGNvbnRleHRJdGVtOiBhbnkgPSB0YWJsZUNvbnRleHRbaXRlbV07XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICBmb3IgKGxldCBxdWVzdGlvbiBpbiBjb250ZXh0SXRlbSkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKGNvbnRleHRJdGVtLmhhc093blByb3BlcnR5KHF1ZXN0aW9uKSkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmICh0eXBlb2YgY29udGV4dEl0ZW1bcXVlc3Rpb25dLmVycm9ycyA9PT0gJ3VuZGVmaW5lZCcpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29udGV4dEl0ZW1bcXVlc3Rpb25dLmVycm9ycyA9IFtdO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29udGV4dEl0ZW1bcXVlc3Rpb25dLmVycm9ycy5sZW5ndGggPSAwO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9O1xyXG4gICAgICAgIH1cclxuICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgY29uc29sZS53YXJuKCdLZFRhYmxlIHdhcm5pbmc6IE5vIGFwaSBwcm9wZXJ0eSAvIHVuZGVmaW5lZCBhcGkgcHJvcGVydHkgaXMgcGFzc2VkIGluLicpO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICAvLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vL1xyXG4gICAgLy8vIE1pc2MgZnVuY3Rpb25zXHJcbiAgICAvLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vL1xyXG4gICAgcHJpdmF0ZSBfaW5pdEdyaWRTZXJ2aWNlKF9sb2FkVHlwZTogc3RyaW5nKTogdm9pZCB7XHJcbiAgICAgICAgaWYgKHR5cGVvZiBfbG9hZFR5cGUgPT09ICd1bmRlZmluZWQnIHx8IF9sb2FkVHlwZSA9PT0gJ25vcm1hbCcpIHtcclxuICAgICAgICAgICAgdGhpcy5fdGFibGVTZXJ2aWNlID0gbmV3IEtkVGFibGVOb3JtYWxTdmMoKTtcclxuICAgICAgICB9XHJcbiAgICAgICAgZWxzZSB7XHJcbiAgICAgICAgICAgIHRoaXMuX3RhYmxlU2VydmljZSA9IG5ldyBLZFRhYmxlRW50ZXJwcmlzZVN2YygpO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF91cGRhdGVHcmlkQ29uZmlnKF9ncmlkQ29uZmlnOiBJVGFibGVDb25maWcpOiB2b2lkIHtcclxuICAgICAgICB0aGlzLmdyaWRJZCA9IHRoaXMuX3RhYmxlU2VydmljZS5nZXRHcmlkSWQoX2dyaWRDb25maWcpO1xyXG5cclxuICAgICAgICB0aGlzLl90YWJsZVNlcnZpY2UudXBkYXRlR3JpZEJ1dHRvbnMoX2dyaWRDb25maWcpO1xyXG4gICAgICAgIHRoaXMuX3RhYmxlU2VydmljZS51cGRhdGVTZWxlY3REZWZhdWx0VmFsdWUoX2dyaWRDb25maWcpO1xyXG4gICAgfVxyXG59XHJcbiJdfQ==