import { Component } from '@angular/core';
import { KdIntTableEvent } from '../kd-angular-table-event';
export class KdTableInput {
    constructor(_kdIntTableEvent) {
        this._kdIntTableEvent = _kdIntTableEvent;
        this.inputData = [];
        this._subscriptionObj = {};
        this._firstRun = true;
        this.DELIMITER = '~';
    }
    /********************* Component Life cycles functions *************************/
    agInit(_params) {
        // console.log('_params here - ', _params);
        this._params = _params;
        this._cellNode = _params.node;
        this._gridApi = _params.api;
        this._gridInputContext = _params.context[this._params.params.contextKey];
        this._contextKey = this._generateContextKey(this._params.params.gridId, this._params.colDef.colId, this._cellNode.id);
        this._updateTooltipDirection();
        this._processInputData(this._gridInputContext[this._contextKey]);
    }
    ngAfterViewInit() {
        this._firstRun = false;
    }
    refresh() {
        return false;
    }
    ngOnDestroy() {
        for (let item in this._subscriptionObj) {
            if (this._subscriptionObj.hasOwnProperty(item)) {
                this._subscriptionObj[item].unsubscribe();
            }
        }
    }
    /*********************** Component template functions **************************/
    valueUpdate(_question, _value) {
        if (this._firstRun)
            return;
        if (typeof _value !== 'undefined') {
            _question.value = _value;
        }
        this._updateContextValue(_question);
        this._updateCellNodeValue(_question);
        let broadcastParams = {
            colId: this._params.colDef.colId,
            rowId: this._cellNode.id,
            questionKey: _question.key,
            question: _question,
            data: _question.value
        };
        this._broadcastQuestionChange(broadcastParams);
    }
    /************************* Input question functions ****************************/
    _processInputData(_data) {
        for (let item in _data) {
            if (_data.hasOwnProperty(item)) {
                this.inputData.push(_data[item]);
            }
        }
    }
    _updateCellNodeValue(_question) {
        this._cellNode.data[this._params.colDef.colId][_question.key] = _question.value;
    }
    _updateContextValue(_question) {
        this._gridInputContext[this._contextKey][_question.key]['value'] = _question.value;
    }
    /*********************** Private broadcast functions ***************************/
    _broadcastQuestionChange(_broadcastParams) {
        this._kdIntTableEvent.inputChanged(this._params.params.gridId, _broadcastParams);
    }
    /***************************** Misc functions **********************************/
    _generateContextKey(_gridId, _colId, _rowId) {
        return _gridId + this.DELIMITER + _colId + this.DELIMITER + _rowId;
    }
    _updateTooltipDirection() {
        let htmlEle = document.querySelector('html');
        if (htmlEle !== null && htmlEle['dir'] !== '' && htmlEle['dir'] === 'rtl') {
            this.tooltipDirection = 'left';
        }
        else {
            this.tooltipDirection = 'right';
        }
    }
}
KdTableInput.decorators = [
    { type: Component, args: [{
                selector: 'kd-table-input',
                template: `
        <ng-template ngFor let-item [ngForOf]='inputData'>
            <div *ngIf='item.visible' class='kdx table-input-wrapper'>
                <div [ngSwitch]='item.controlType'>

                    <input *ngSwitchCase="'text'"
                        type='text'
                        [id]='item.key'
                        [placeholder]='item.placeholder ? item.placeholder : ""'
                        [(ngModel)]='item.value'
                        (ngModelChange)='valueUpdate(item)'
                    />

                    <input *ngSwitchCase="'number'"
                        type='number'
                        [id]='item.key'
                        [min]='item.min'
                        [max]='item.max'
                        [step]='item.step'
                        [placeholder]='item.placeholder ? item.placeholder : ""'
                        [(ngModel)]='item.value'
                        (ngModelChange)='valueUpdate(item)'
                    />

                    <textarea *ngSwitchCase="'textarea'"
                        [id]='item.key'
                        [placeholder]='item.placeholder ? item.placeholder : ""'
                        [(ngModel)]='item.value'
                        (ngModelChange)='valueUpdate(item)'
                    ></textarea>

                    <div *ngSwitchCase="'dropdown'" class='kdx-input-select-wrapper'>
                        <select
                            [id]='item.key'
                            [(ngModel)]='item.value'
                            (ngModelChange)='valueUpdate(item)'
                        >
                            <option *ngFor='let option of item.options' [value]='option.key'>
                                {{option.value}}
                            </option>
                        </select>
                    </div>

                    <kd-datepicker *ngSwitchCase="'date'"
                        [id]="item.key"
                        [config]='item.config'
                        [inputVal]='item.value'
                        [minDate]='item.minDate'
                        [maxDate]='item.maxDate'
                        (dateConfig)='valueUpdate(item, $event)'
                    ></kd-datepicker>

                    <kd-timepicker *ngSwitchCase="'time'"
                        [id]='item.key'
                        [config]='item.config'
                        [inputVal]='item.value'
                        (timeConfig)='valueUpdate(item, $event)'
                    ></kd-timepicker>

                    <kd-slider *ngSwitchCase="'slider'"
                        [id]='item.key'
                        [config]='item.config'
                        [value]='item.value'
                        [api]='item.api'
                        (result)='valueUpdate(item, $event)'
                    ></kd-slider>

                </div>

                <kd-tooltip
                    *ngIf='item.errors && item.errors.length > 0'
                    [config]="{ type: 'error', placement: tooltipDirection, description: item.errors }"
                ></kd-tooltip>
            </div>
        </ng-template>
    `,
                host: { 'class': 'kdx-table-input' }
            },] }
];
KdTableInput.ctorParameters = () => [
    { type: KdIntTableEvent }
];
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoia2QtdGFibGUtaW5wdXQuanMiLCJzb3VyY2VSb290IjoiQzoveGFtcHAvaHRkb2NzL1N0eWxlZ3VpZGUvaW9zdGctb3BlbmVtaXMtc3R5bGVndWlkZS9wcm9qZWN0cy9vcGVuZW1pcy1zdHlsZWd1aWRlLWxpYi9zcmMvIiwic291cmNlcyI6WyJrZC1jb21wb25lbnRzL2tkLWFuZ3VsYXItdGFibGUvdGFibGUtY29tcG9uZW50cy9rZC10YWJsZS1pbnB1dC50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQSxPQUFPLEVBQUUsU0FBUyxFQUE0QixNQUFNLGVBQWUsQ0FBQztBQUlwRSxPQUFPLEVBQUUsZUFBZSxFQUFFLE1BQU0sMkJBQTJCLENBQUM7QUFzRzVELE1BQU0sT0FBTyxZQUFZO0lBY3JCLFlBQ1ksZ0JBQWlDO1FBQWpDLHFCQUFnQixHQUFoQixnQkFBZ0IsQ0FBaUI7UUFkdEMsY0FBUyxHQUF1QixFQUFFLENBQUM7UUFRbEMscUJBQWdCLEdBQWtDLEVBQUUsQ0FBQztRQUNyRCxjQUFTLEdBQVksSUFBSSxDQUFDO1FBRXpCLGNBQVMsR0FBVyxHQUFHLENBQUM7SUFJOUIsQ0FBQztJQUVKLGlGQUFpRjtJQUMxRSxNQUFNLENBQUMsT0FBNEI7UUFDdEMsMkNBQTJDO1FBQzNDLElBQUksQ0FBQyxPQUFPLEdBQUcsT0FBTyxDQUFDO1FBQ3ZCLElBQUksQ0FBQyxTQUFTLEdBQUcsT0FBTyxDQUFDLElBQUksQ0FBQztRQUM5QixJQUFJLENBQUMsUUFBUSxHQUFHLE9BQU8sQ0FBQyxHQUFHLENBQUM7UUFDNUIsSUFBSSxDQUFDLGlCQUFpQixHQUFHLE9BQU8sQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsVUFBVSxDQUFDLENBQUM7UUFDekUsSUFBSSxDQUFDLFdBQVcsR0FBRyxJQUFJLENBQUMsbUJBQW1CLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsTUFBTSxFQUFFLElBQUksQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLEtBQUssRUFBRSxJQUFJLENBQUMsU0FBUyxDQUFDLEVBQUUsQ0FBQyxDQUFDO1FBRXRILElBQUksQ0FBQyx1QkFBdUIsRUFBRSxDQUFDO1FBQy9CLElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxJQUFJLENBQUMsaUJBQWlCLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUM7SUFDckUsQ0FBQztJQUVNLGVBQWU7UUFDbEIsSUFBSSxDQUFDLFNBQVMsR0FBRyxLQUFLLENBQUM7SUFDM0IsQ0FBQztJQUVNLE9BQU87UUFDVixPQUFPLEtBQUssQ0FBQztJQUNqQixDQUFDO0lBRU0sV0FBVztRQUNkLEtBQUssSUFBSSxJQUFJLElBQUksSUFBSSxDQUFDLGdCQUFnQixFQUFFO1lBQ3BDLElBQUksSUFBSSxDQUFDLGdCQUFnQixDQUFDLGNBQWMsQ0FBQyxJQUFJLENBQUMsRUFBRTtnQkFDNUMsSUFBSSxDQUFDLGdCQUFnQixDQUFDLElBQUksQ0FBQyxDQUFDLFdBQVcsRUFBRSxDQUFDO2FBQzdDO1NBQ0o7SUFDTCxDQUFDO0lBRUQsaUZBQWlGO0lBQzFFLFdBQVcsQ0FBQyxTQUF3QixFQUFFLE1BQVk7UUFDckQsSUFBSSxJQUFJLENBQUMsU0FBUztZQUFFLE9BQU87UUFFM0IsSUFBSSxPQUFPLE1BQU0sS0FBSyxXQUFXLEVBQUU7WUFDL0IsU0FBUyxDQUFDLEtBQUssR0FBRyxNQUFNLENBQUM7U0FDNUI7UUFFRCxJQUFJLENBQUMsbUJBQW1CLENBQUMsU0FBUyxDQUFDLENBQUM7UUFDcEMsSUFBSSxDQUFDLG9CQUFvQixDQUFDLFNBQVMsQ0FBQyxDQUFDO1FBRXJDLElBQUksZUFBZSxHQUF5QjtZQUN4QyxLQUFLLEVBQUUsSUFBSSxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsS0FBSztZQUNoQyxLQUFLLEVBQUUsSUFBSSxDQUFDLFNBQVMsQ0FBQyxFQUFFO1lBQ3hCLFdBQVcsRUFBRSxTQUFTLENBQUMsR0FBRztZQUMxQixRQUFRLEVBQUUsU0FBUztZQUNuQixJQUFJLEVBQUUsU0FBUyxDQUFDLEtBQUs7U0FDeEIsQ0FBQztRQUVGLElBQUksQ0FBQyx3QkFBd0IsQ0FBQyxlQUFlLENBQUMsQ0FBQztJQUNuRCxDQUFDO0lBRUQsaUZBQWlGO0lBQ3pFLGlCQUFpQixDQUFDLEtBQW1DO1FBQ3pELEtBQUssSUFBSSxJQUFJLElBQUksS0FBSyxFQUFFO1lBQ3BCLElBQUksS0FBSyxDQUFDLGNBQWMsQ0FBQyxJQUFJLENBQUMsRUFBRTtnQkFDNUIsSUFBSSxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUM7YUFDcEM7U0FDSjtJQUNMLENBQUM7SUFFTyxvQkFBb0IsQ0FBQyxTQUF3QjtRQUNqRCxJQUFJLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsQ0FBQyxTQUFTLENBQUMsR0FBRyxDQUFDLEdBQUcsU0FBUyxDQUFDLEtBQUssQ0FBQztJQUNwRixDQUFDO0lBRU8sbUJBQW1CLENBQUMsU0FBd0I7UUFDaEQsSUFBSSxDQUFDLGlCQUFpQixDQUFDLElBQUksQ0FBQyxXQUFXLENBQUMsQ0FBQyxTQUFTLENBQUMsR0FBRyxDQUFDLENBQUMsT0FBTyxDQUFDLEdBQUcsU0FBUyxDQUFDLEtBQUssQ0FBQztJQUN2RixDQUFDO0lBRUQsaUZBQWlGO0lBQ3pFLHdCQUF3QixDQUFDLGdCQUFzQztRQUNuRSxJQUFJLENBQUMsZ0JBQWdCLENBQUMsWUFBWSxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLE1BQU0sRUFBRSxnQkFBZ0IsQ0FBQyxDQUFDO0lBQ3JGLENBQUM7SUFFRCxpRkFBaUY7SUFDekUsbUJBQW1CLENBQUMsT0FBZSxFQUFFLE1BQWMsRUFBRSxNQUFjO1FBQ3ZFLE9BQU8sT0FBTyxHQUFHLElBQUksQ0FBQyxTQUFTLEdBQUcsTUFBTSxHQUFHLElBQUksQ0FBQyxTQUFTLEdBQUcsTUFBTSxDQUFDO0lBQ3ZFLENBQUM7SUFFTyx1QkFBdUI7UUFDM0IsSUFBSSxPQUFPLEdBQVksUUFBUSxDQUFDLGFBQWEsQ0FBQyxNQUFNLENBQUMsQ0FBQztRQUV0RCxJQUFJLE9BQU8sS0FBSyxJQUFJLElBQUksT0FBTyxDQUFDLEtBQUssQ0FBQyxLQUFLLEVBQUUsSUFBSSxPQUFPLENBQUMsS0FBSyxDQUFDLEtBQUssS0FBSyxFQUFFO1lBQ3ZFLElBQUksQ0FBQyxnQkFBZ0IsR0FBSSxNQUFNLENBQUM7U0FDbkM7YUFDSTtZQUNELElBQUksQ0FBQyxnQkFBZ0IsR0FBSSxPQUFPLENBQUM7U0FDcEM7SUFDTCxDQUFDOzs7WUExTEosU0FBUyxTQUFDO2dCQUNQLFFBQVEsRUFBRSxnQkFBZ0I7Z0JBQzFCLFFBQVEsRUFBRTs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0tBMkVUO2dCQUNELElBQUksRUFBRyxFQUFFLE9BQU8sRUFBRyxpQkFBaUIsRUFBRTthQUN6Qzs7O1lBcEdRLGVBQWUiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBDb21wb25lbnQsIEFmdGVyVmlld0luaXQsIE9uRGVzdHJveSB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xyXG5pbXBvcnQgeyBTdWJzY3JpcHRpb24gfSBmcm9tICdyeGpzJztcclxuaW1wb3J0IHsgUm93Tm9kZSwgR3JpZEFwaSwgSUNlbGxSZW5kZXJlclBhcmFtcyB9IGZyb20gJ2FnLWdyaWQtY29tbXVuaXR5JztcclxuaW1wb3J0IHsgSUNlbGxSZW5kZXJlckFuZ3VsYXJDb21wIH0gZnJvbSAnYWctZ3JpZC1hbmd1bGFyJztcclxuaW1wb3J0IHsgS2RJbnRUYWJsZUV2ZW50IH0gZnJvbSAnLi4va2QtYW5ndWxhci10YWJsZS1ldmVudCc7XHJcbmltcG9ydCB7IElUYWJsZUlucHV0LCBJVGFibGVGb3JtRW1pdFBhcmFtcyB9IGZyb20gJy4uL2luZGV4JztcclxuXHJcbmV4cG9ydCBpbnRlcmZhY2UgSUtkVGFibGVJbnB1dFBhcmFtcyBleHRlbmRzIElDZWxsUmVuZGVyZXJQYXJhbXMge1xyXG4gICAgcGFyYW1zPzoge1xyXG4gICAgICAgIGdyaWRJZD86IHN0cmluZyxcclxuICAgICAgICBjb250ZXh0S2V5Pzogc3RyaW5nLFxyXG4gICAgICAgIGlucHV0Q29uZmlnPzoge1xyXG4gICAgICAgICAgICBkYXRhPzogQXJyYXk8YW55PiB8IGFueVxyXG4gICAgICAgIH1cclxuICAgIH07XHJcbn1cclxuXHJcbmV4cG9ydCBpbnRlcmZhY2UgSUtkVGFibGVJbnB1dCB7XHJcbiAgICBba2V5OiBzdHJpbmddOiBhbnk7XHJcbiAgICBjb250cm9sVHlwZTogc3RyaW5nO1xyXG4gICAgdmFsdWU6IGFueTtcclxuICAgIGtleTogc3RyaW5nO1xyXG4gICAgdmlzaWJsZTogYm9vbGVhbjtcclxufVxyXG5cclxuQENvbXBvbmVudCh7XHJcbiAgICBzZWxlY3RvcjogJ2tkLXRhYmxlLWlucHV0JyxcclxuICAgIHRlbXBsYXRlOiBgXHJcbiAgICAgICAgPG5nLXRlbXBsYXRlIG5nRm9yIGxldC1pdGVtIFtuZ0Zvck9mXT0naW5wdXREYXRhJz5cclxuICAgICAgICAgICAgPGRpdiAqbmdJZj0naXRlbS52aXNpYmxlJyBjbGFzcz0na2R4IHRhYmxlLWlucHV0LXdyYXBwZXInPlxyXG4gICAgICAgICAgICAgICAgPGRpdiBbbmdTd2l0Y2hdPSdpdGVtLmNvbnRyb2xUeXBlJz5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgPGlucHV0ICpuZ1N3aXRjaENhc2U9XCIndGV4dCdcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB0eXBlPSd0ZXh0J1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBbaWRdPSdpdGVtLmtleSdcclxuICAgICAgICAgICAgICAgICAgICAgICAgW3BsYWNlaG9sZGVyXT0naXRlbS5wbGFjZWhvbGRlciA/IGl0ZW0ucGxhY2Vob2xkZXIgOiBcIlwiJ1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBbKG5nTW9kZWwpXT0naXRlbS52YWx1ZSdcclxuICAgICAgICAgICAgICAgICAgICAgICAgKG5nTW9kZWxDaGFuZ2UpPSd2YWx1ZVVwZGF0ZShpdGVtKSdcclxuICAgICAgICAgICAgICAgICAgICAvPlxyXG5cclxuICAgICAgICAgICAgICAgICAgICA8aW5wdXQgKm5nU3dpdGNoQ2FzZT1cIidudW1iZXInXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT0nbnVtYmVyJ1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBbaWRdPSdpdGVtLmtleSdcclxuICAgICAgICAgICAgICAgICAgICAgICAgW21pbl09J2l0ZW0ubWluJ1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBbbWF4XT0naXRlbS5tYXgnXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIFtzdGVwXT0naXRlbS5zdGVwJ1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBbcGxhY2Vob2xkZXJdPSdpdGVtLnBsYWNlaG9sZGVyID8gaXRlbS5wbGFjZWhvbGRlciA6IFwiXCInXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIFsobmdNb2RlbCldPSdpdGVtLnZhbHVlJ1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAobmdNb2RlbENoYW5nZSk9J3ZhbHVlVXBkYXRlKGl0ZW0pJ1xyXG4gICAgICAgICAgICAgICAgICAgIC8+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIDx0ZXh0YXJlYSAqbmdTd2l0Y2hDYXNlPVwiJ3RleHRhcmVhJ1wiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIFtpZF09J2l0ZW0ua2V5J1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBbcGxhY2Vob2xkZXJdPSdpdGVtLnBsYWNlaG9sZGVyID8gaXRlbS5wbGFjZWhvbGRlciA6IFwiXCInXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIFsobmdNb2RlbCldPSdpdGVtLnZhbHVlJ1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAobmdNb2RlbENoYW5nZSk9J3ZhbHVlVXBkYXRlKGl0ZW0pJ1xyXG4gICAgICAgICAgICAgICAgICAgID48L3RleHRhcmVhPlxyXG5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2ICpuZ1N3aXRjaENhc2U9XCInZHJvcGRvd24nXCIgY2xhc3M9J2tkeC1pbnB1dC1zZWxlY3Qtd3JhcHBlcic+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxzZWxlY3RcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIFtpZF09J2l0ZW0ua2V5J1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgWyhuZ01vZGVsKV09J2l0ZW0udmFsdWUnXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAobmdNb2RlbENoYW5nZSk9J3ZhbHVlVXBkYXRlKGl0ZW0pJ1xyXG4gICAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8b3B0aW9uICpuZ0Zvcj0nbGV0IG9wdGlvbiBvZiBpdGVtLm9wdGlvbnMnIFt2YWx1ZV09J29wdGlvbi5rZXknPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHt7b3B0aW9uLnZhbHVlfX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvb3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L3NlbGVjdD5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgPGtkLWRhdGVwaWNrZXIgKm5nU3dpdGNoQ2FzZT1cIidkYXRlJ1wiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIFtpZF09XCJpdGVtLmtleVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIFtjb25maWddPSdpdGVtLmNvbmZpZydcclxuICAgICAgICAgICAgICAgICAgICAgICAgW2lucHV0VmFsXT0naXRlbS52YWx1ZSdcclxuICAgICAgICAgICAgICAgICAgICAgICAgW21pbkRhdGVdPSdpdGVtLm1pbkRhdGUnXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIFttYXhEYXRlXT0naXRlbS5tYXhEYXRlJ1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAoZGF0ZUNvbmZpZyk9J3ZhbHVlVXBkYXRlKGl0ZW0sICRldmVudCknXHJcbiAgICAgICAgICAgICAgICAgICAgPjwva2QtZGF0ZXBpY2tlcj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgPGtkLXRpbWVwaWNrZXIgKm5nU3dpdGNoQ2FzZT1cIid0aW1lJ1wiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIFtpZF09J2l0ZW0ua2V5J1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBbY29uZmlnXT0naXRlbS5jb25maWcnXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIFtpbnB1dFZhbF09J2l0ZW0udmFsdWUnXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICh0aW1lQ29uZmlnKT0ndmFsdWVVcGRhdGUoaXRlbSwgJGV2ZW50KSdcclxuICAgICAgICAgICAgICAgICAgICA+PC9rZC10aW1lcGlja2VyPlxyXG5cclxuICAgICAgICAgICAgICAgICAgICA8a2Qtc2xpZGVyICpuZ1N3aXRjaENhc2U9XCInc2xpZGVyJ1wiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIFtpZF09J2l0ZW0ua2V5J1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBbY29uZmlnXT0naXRlbS5jb25maWcnXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIFt2YWx1ZV09J2l0ZW0udmFsdWUnXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIFthcGldPSdpdGVtLmFwaSdcclxuICAgICAgICAgICAgICAgICAgICAgICAgKHJlc3VsdCk9J3ZhbHVlVXBkYXRlKGl0ZW0sICRldmVudCknXHJcbiAgICAgICAgICAgICAgICAgICAgPjwva2Qtc2xpZGVyPlxyXG5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgIDxrZC10b29sdGlwXHJcbiAgICAgICAgICAgICAgICAgICAgKm5nSWY9J2l0ZW0uZXJyb3JzICYmIGl0ZW0uZXJyb3JzLmxlbmd0aCA+IDAnXHJcbiAgICAgICAgICAgICAgICAgICAgW2NvbmZpZ109XCJ7IHR5cGU6ICdlcnJvcicsIHBsYWNlbWVudDogdG9vbHRpcERpcmVjdGlvbiwgZGVzY3JpcHRpb246IGl0ZW0uZXJyb3JzIH1cIlxyXG4gICAgICAgICAgICAgICAgPjwva2QtdG9vbHRpcD5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPC9uZy10ZW1wbGF0ZT5cclxuICAgIGAsXHJcbiAgICBob3N0IDogeyAnY2xhc3MnIDogJ2tkeC10YWJsZS1pbnB1dCcgfVxyXG59KVxyXG5cclxuZXhwb3J0IGNsYXNzIEtkVGFibGVJbnB1dCBpbXBsZW1lbnRzIElDZWxsUmVuZGVyZXJBbmd1bGFyQ29tcCwgQWZ0ZXJWaWV3SW5pdCwgT25EZXN0cm95IHtcclxuICAgIHB1YmxpYyBpbnB1dERhdGE6IEFycmF5PElUYWJsZUlucHV0PiA9IFtdO1xyXG4gICAgcHVibGljIHRvb2x0aXBEaXJlY3Rpb246ICdsZWZ0JyB8ICdyaWdodCc7XHJcblxyXG4gICAgcHJpdmF0ZSBfcGFyYW1zOiBJS2RUYWJsZUlucHV0UGFyYW1zO1xyXG4gICAgcHJpdmF0ZSBfY2VsbE5vZGU6IFJvd05vZGU7XHJcbiAgICBwcml2YXRlIF9ncmlkQXBpOiBHcmlkQXBpO1xyXG4gICAgcHJpdmF0ZSBfZ3JpZElucHV0Q29udGV4dDogYW55O1xyXG4gICAgcHJpdmF0ZSBfY29udGV4dEtleTogc3RyaW5nO1xyXG4gICAgcHJpdmF0ZSBfc3Vic2NyaXB0aW9uT2JqOiB7W2tleTogc3RyaW5nXTogU3Vic2NyaXB0aW9ufSA9IHt9O1xyXG4gICAgcHJpdmF0ZSBfZmlyc3RSdW46IGJvb2xlYW4gPSB0cnVlO1xyXG5cclxuICAgIHJlYWRvbmx5IERFTElNSVRFUjogc3RyaW5nID0gJ34nO1xyXG5cclxuICAgIGNvbnN0cnVjdG9yKFxyXG4gICAgICAgIHByaXZhdGUgX2tkSW50VGFibGVFdmVudDogS2RJbnRUYWJsZUV2ZW50XHJcbiAgICApIHt9XHJcblxyXG4gICAgLyoqKioqKioqKioqKioqKioqKioqKiBDb21wb25lbnQgTGlmZSBjeWNsZXMgZnVuY3Rpb25zICoqKioqKioqKioqKioqKioqKioqKioqKiovXHJcbiAgICBwdWJsaWMgYWdJbml0KF9wYXJhbXM6IElLZFRhYmxlSW5wdXRQYXJhbXMpOiB2b2lkIHtcclxuICAgICAgICAvLyBjb25zb2xlLmxvZygnX3BhcmFtcyBoZXJlIC0gJywgX3BhcmFtcyk7XHJcbiAgICAgICAgdGhpcy5fcGFyYW1zID0gX3BhcmFtcztcclxuICAgICAgICB0aGlzLl9jZWxsTm9kZSA9IF9wYXJhbXMubm9kZTtcclxuICAgICAgICB0aGlzLl9ncmlkQXBpID0gX3BhcmFtcy5hcGk7XHJcbiAgICAgICAgdGhpcy5fZ3JpZElucHV0Q29udGV4dCA9IF9wYXJhbXMuY29udGV4dFt0aGlzLl9wYXJhbXMucGFyYW1zLmNvbnRleHRLZXldO1xyXG4gICAgICAgIHRoaXMuX2NvbnRleHRLZXkgPSB0aGlzLl9nZW5lcmF0ZUNvbnRleHRLZXkodGhpcy5fcGFyYW1zLnBhcmFtcy5ncmlkSWQsIHRoaXMuX3BhcmFtcy5jb2xEZWYuY29sSWQsIHRoaXMuX2NlbGxOb2RlLmlkKTtcclxuXHJcbiAgICAgICAgdGhpcy5fdXBkYXRlVG9vbHRpcERpcmVjdGlvbigpO1xyXG4gICAgICAgIHRoaXMuX3Byb2Nlc3NJbnB1dERhdGEodGhpcy5fZ3JpZElucHV0Q29udGV4dFt0aGlzLl9jb250ZXh0S2V5XSk7XHJcbiAgICB9XHJcblxyXG4gICAgcHVibGljIG5nQWZ0ZXJWaWV3SW5pdCgpOiB2b2lkIHtcclxuICAgICAgICB0aGlzLl9maXJzdFJ1biA9IGZhbHNlO1xyXG4gICAgfVxyXG5cclxuICAgIHB1YmxpYyByZWZyZXNoKCk6IGJvb2xlYW4ge1xyXG4gICAgICAgIHJldHVybiBmYWxzZTtcclxuICAgIH1cclxuXHJcbiAgICBwdWJsaWMgbmdPbkRlc3Ryb3koKTogdm9pZCB7XHJcbiAgICAgICAgZm9yIChsZXQgaXRlbSBpbiB0aGlzLl9zdWJzY3JpcHRpb25PYmopIHtcclxuICAgICAgICAgICAgaWYgKHRoaXMuX3N1YnNjcmlwdGlvbk9iai5oYXNPd25Qcm9wZXJ0eShpdGVtKSkge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5fc3Vic2NyaXB0aW9uT2JqW2l0ZW1dLnVuc3Vic2NyaWJlKCk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgLyoqKioqKioqKioqKioqKioqKioqKioqIENvbXBvbmVudCB0ZW1wbGF0ZSBmdW5jdGlvbnMgKioqKioqKioqKioqKioqKioqKioqKioqKiovXHJcbiAgICBwdWJsaWMgdmFsdWVVcGRhdGUoX3F1ZXN0aW9uOiBJS2RUYWJsZUlucHV0LCBfdmFsdWU/OiBhbnkpOiB2b2lkIHtcclxuICAgICAgICBpZiAodGhpcy5fZmlyc3RSdW4pIHJldHVybjtcclxuXHJcbiAgICAgICAgaWYgKHR5cGVvZiBfdmFsdWUgIT09ICd1bmRlZmluZWQnKSB7XHJcbiAgICAgICAgICAgIF9xdWVzdGlvbi52YWx1ZSA9IF92YWx1ZTtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIHRoaXMuX3VwZGF0ZUNvbnRleHRWYWx1ZShfcXVlc3Rpb24pO1xyXG4gICAgICAgIHRoaXMuX3VwZGF0ZUNlbGxOb2RlVmFsdWUoX3F1ZXN0aW9uKTtcclxuXHJcbiAgICAgICAgbGV0IGJyb2FkY2FzdFBhcmFtczogSVRhYmxlRm9ybUVtaXRQYXJhbXMgPSB7XHJcbiAgICAgICAgICAgIGNvbElkOiB0aGlzLl9wYXJhbXMuY29sRGVmLmNvbElkLFxyXG4gICAgICAgICAgICByb3dJZDogdGhpcy5fY2VsbE5vZGUuaWQsXHJcbiAgICAgICAgICAgIHF1ZXN0aW9uS2V5OiBfcXVlc3Rpb24ua2V5LFxyXG4gICAgICAgICAgICBxdWVzdGlvbjogX3F1ZXN0aW9uLFxyXG4gICAgICAgICAgICBkYXRhOiBfcXVlc3Rpb24udmFsdWVcclxuICAgICAgICB9O1xyXG5cclxuICAgICAgICB0aGlzLl9icm9hZGNhc3RRdWVzdGlvbkNoYW5nZShicm9hZGNhc3RQYXJhbXMpO1xyXG4gICAgfVxyXG5cclxuICAgIC8qKioqKioqKioqKioqKioqKioqKioqKioqIElucHV0IHF1ZXN0aW9uIGZ1bmN0aW9ucyAqKioqKioqKioqKioqKioqKioqKioqKioqKioqL1xyXG4gICAgcHJpdmF0ZSBfcHJvY2Vzc0lucHV0RGF0YShfZGF0YToge1trZXk6IHN0cmluZ106IElUYWJsZUlucHV0fSk6IHZvaWQge1xyXG4gICAgICAgIGZvciAobGV0IGl0ZW0gaW4gX2RhdGEpIHtcclxuICAgICAgICAgICAgaWYgKF9kYXRhLmhhc093blByb3BlcnR5KGl0ZW0pKSB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLmlucHV0RGF0YS5wdXNoKF9kYXRhW2l0ZW1dKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF91cGRhdGVDZWxsTm9kZVZhbHVlKF9xdWVzdGlvbjogSUtkVGFibGVJbnB1dCk6IHZvaWQge1xyXG4gICAgICAgIHRoaXMuX2NlbGxOb2RlLmRhdGFbdGhpcy5fcGFyYW1zLmNvbERlZi5jb2xJZF1bX3F1ZXN0aW9uLmtleV0gPSBfcXVlc3Rpb24udmFsdWU7XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfdXBkYXRlQ29udGV4dFZhbHVlKF9xdWVzdGlvbjogSUtkVGFibGVJbnB1dCk6IHZvaWQge1xyXG4gICAgICAgIHRoaXMuX2dyaWRJbnB1dENvbnRleHRbdGhpcy5fY29udGV4dEtleV1bX3F1ZXN0aW9uLmtleV1bJ3ZhbHVlJ10gPSBfcXVlc3Rpb24udmFsdWU7XHJcbiAgICB9XHJcblxyXG4gICAgLyoqKioqKioqKioqKioqKioqKioqKioqIFByaXZhdGUgYnJvYWRjYXN0IGZ1bmN0aW9ucyAqKioqKioqKioqKioqKioqKioqKioqKioqKiovXHJcbiAgICBwcml2YXRlIF9icm9hZGNhc3RRdWVzdGlvbkNoYW5nZShfYnJvYWRjYXN0UGFyYW1zOiBJVGFibGVGb3JtRW1pdFBhcmFtcyk6IHZvaWQge1xyXG4gICAgICAgIHRoaXMuX2tkSW50VGFibGVFdmVudC5pbnB1dENoYW5nZWQodGhpcy5fcGFyYW1zLnBhcmFtcy5ncmlkSWQsIF9icm9hZGNhc3RQYXJhbXMpO1xyXG4gICAgfVxyXG5cclxuICAgIC8qKioqKioqKioqKioqKioqKioqKioqKioqKioqKiBNaXNjIGZ1bmN0aW9ucyAqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqL1xyXG4gICAgcHJpdmF0ZSBfZ2VuZXJhdGVDb250ZXh0S2V5KF9ncmlkSWQ6IHN0cmluZywgX2NvbElkOiBzdHJpbmcsIF9yb3dJZDogc3RyaW5nKTogc3RyaW5nIHtcclxuICAgICAgICByZXR1cm4gX2dyaWRJZCArIHRoaXMuREVMSU1JVEVSICsgX2NvbElkICsgdGhpcy5ERUxJTUlURVIgKyBfcm93SWQ7XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfdXBkYXRlVG9vbHRpcERpcmVjdGlvbigpOiB2b2lkIHtcclxuICAgICAgICBsZXQgaHRtbEVsZTogRWxlbWVudCA9IGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3IoJ2h0bWwnKTtcclxuXHJcbiAgICAgICAgaWYgKGh0bWxFbGUgIT09IG51bGwgJiYgaHRtbEVsZVsnZGlyJ10gIT09ICcnICYmIGh0bWxFbGVbJ2RpciddID09PSAncnRsJykge1xyXG4gICAgICAgICAgICB0aGlzLnRvb2x0aXBEaXJlY3Rpb24gPSAgJ2xlZnQnO1xyXG4gICAgICAgIH1cclxuICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgdGhpcy50b29sdGlwRGlyZWN0aW9uID0gICdyaWdodCc7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG59XHJcbiJdfQ==