import { Component } from '@angular/core';
export class KdTableImage {
    constructor() {
        this.config = {};
        this.value = {};
    }
    agInit(_params) {
        // console.log('_params', _params);
        this._params = _params;
        this.config = this._params.params.imageConfig;
        this.value = this._params.value;
    }
    refresh() {
        return false;
    }
}
KdTableImage.decorators = [
    { type: Component, args: [{
                selector: 'kd-table-image',
                template: `
        <kd-placeholder [config]='config' [value]='value'></kd-placeholder>
    `
            },] }
];
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoia2QtdGFibGUtaW1hZ2UuanMiLCJzb3VyY2VSb290IjoiQzoveGFtcHAvaHRkb2NzL1N0eWxlZ3VpZGUvaW9zdGctb3BlbmVtaXMtc3R5bGVndWlkZS9wcm9qZWN0cy9vcGVuZW1pcy1zdHlsZWd1aWRlLWxpYi9zcmMvIiwic291cmNlcyI6WyJrZC1jb21wb25lbnRzL2tkLWFuZ3VsYXItdGFibGUvdGFibGUtY29tcG9uZW50cy9rZC10YWJsZS1pbWFnZS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQSxPQUFPLEVBQUUsU0FBUyxFQUFFLE1BQU0sZUFBZSxDQUFDO0FBdUIxQyxNQUFNLE9BQU8sWUFBWTtJQVB6QjtRQVFXLFdBQU0sR0FBUSxFQUFFLENBQUM7UUFDakIsVUFBSyxHQUFRLEVBQUUsQ0FBQztJQWEzQixDQUFDO0lBVlUsTUFBTSxDQUFDLE9BQTRCO1FBQ3RDLG1DQUFtQztRQUNuQyxJQUFJLENBQUMsT0FBTyxHQUFHLE9BQU8sQ0FBQztRQUN2QixJQUFJLENBQUMsTUFBTSxHQUFHLElBQUksQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLFdBQVcsQ0FBQztRQUM5QyxJQUFJLENBQUMsS0FBSyxHQUFHLElBQUksQ0FBQyxPQUFPLENBQUMsS0FBSyxDQUFDO0lBQ3BDLENBQUM7SUFFTSxPQUFPO1FBQ1YsT0FBTyxLQUFLLENBQUM7SUFDakIsQ0FBQzs7O1lBckJKLFNBQVMsU0FBQztnQkFDUCxRQUFRLEVBQUUsZ0JBQWdCO2dCQUMxQixRQUFRLEVBQUU7O0tBRVQ7YUFDSiIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IENvbXBvbmVudCB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xyXG5pbXBvcnQgeyBJQ2VsbFJlbmRlcmVyUGFyYW1zIH0gZnJvbSAnYWctZ3JpZC1jb21tdW5pdHknO1xyXG5pbXBvcnQgeyBJQ2VsbFJlbmRlcmVyQW5ndWxhckNvbXAgfSBmcm9tICdhZy1ncmlkLWFuZ3VsYXInO1xyXG5cclxuZXhwb3J0IGludGVyZmFjZSBJS2RUYWJsZUltYWdlUGFyYW1zIGV4dGVuZHMgSUNlbGxSZW5kZXJlclBhcmFtcyB7XHJcbiAgICBwYXJhbXM/OiB7XHJcbiAgICAgICAgaW1hZ2VDb25maWc/OiB7XHJcbiAgICAgICAgICAgIGJvcmRlclR5cGU/OiBzdHJpbmcsXHJcbiAgICAgICAgICAgIGhlaWdodD86IG51bWJlcixcclxuICAgICAgICAgICAgd2lkdGg/OiBudW1iZXIsXHJcbiAgICAgICAgICAgIGlzRXhwZW5kYWJsZT86IGJvb2xlYW4sXHJcbiAgICAgICAgICAgIGljb24/OiBzdHJpbmdcclxuICAgICAgICB9O1xyXG4gICAgfTtcclxufVxyXG5cclxuQENvbXBvbmVudCh7XHJcbiAgICBzZWxlY3RvcjogJ2tkLXRhYmxlLWltYWdlJyxcclxuICAgIHRlbXBsYXRlOiBgXHJcbiAgICAgICAgPGtkLXBsYWNlaG9sZGVyIFtjb25maWddPSdjb25maWcnIFt2YWx1ZV09J3ZhbHVlJz48L2tkLXBsYWNlaG9sZGVyPlxyXG4gICAgYFxyXG59KVxyXG5cclxuZXhwb3J0IGNsYXNzIEtkVGFibGVJbWFnZSBpbXBsZW1lbnRzIElDZWxsUmVuZGVyZXJBbmd1bGFyQ29tcCB7XHJcbiAgICBwdWJsaWMgY29uZmlnOiBhbnkgPSB7fTtcclxuICAgIHB1YmxpYyB2YWx1ZTogYW55ID0ge307XHJcbiAgICBwcml2YXRlIF9wYXJhbXM6IElLZFRhYmxlSW1hZ2VQYXJhbXM7XHJcblxyXG4gICAgcHVibGljIGFnSW5pdChfcGFyYW1zOiBJS2RUYWJsZUltYWdlUGFyYW1zKTogdm9pZCB7XHJcbiAgICAgICAgLy8gY29uc29sZS5sb2coJ19wYXJhbXMnLCBfcGFyYW1zKTtcclxuICAgICAgICB0aGlzLl9wYXJhbXMgPSBfcGFyYW1zO1xyXG4gICAgICAgIHRoaXMuY29uZmlnID0gdGhpcy5fcGFyYW1zLnBhcmFtcy5pbWFnZUNvbmZpZztcclxuICAgICAgICB0aGlzLnZhbHVlID0gdGhpcy5fcGFyYW1zLnZhbHVlO1xyXG4gICAgfVxyXG5cclxuICAgIHB1YmxpYyByZWZyZXNoKCk6IGJvb2xlYW4ge1xyXG4gICAgICAgIHJldHVybiBmYWxzZTtcclxuICAgIH1cclxufVxyXG4iXX0=