import { Component } from '@angular/core';
import { KdIntTableEvent } from '../kd-angular-table-event';
export class KdTableCheckboxRadio {
    constructor(_kdIntTableEvent) {
        this._kdIntTableEvent = _kdIntTableEvent;
        this._inputType = 'checkbox';
        this._isHeader = false;
        this._selectAll = false;
        this._paramsDefault = [];
        this._paramGridId = 'kd-table-grid';
        this._subscriptionObj = {};
    }
    /********************* Component Life cycles functions *************************/
    agInit(_params) {
        // console.log("-- Grid state: Checkbox/Radio agInit --", _params);
        this._params = _params;
        this._paramsApi = this._params.api;
        this._paramGridId = this._params.params.gridId;
        this._isHeader = typeof this._params.rowIndex === 'undefined';
        this._getDefaultSelection();
        this._updateInputType();
        if (!this._isHeader) {
            this._paramNode = this._params.node;
            this._updateInitialSelection();
        }
        this._setupSubscriptionEvents();
    }
    refresh(_params) {
        return false;
    }
    ngOnDestroy() {
        for (let item in this._subscriptionObj) {
            if (this._subscriptionObj.hasOwnProperty(item)) {
                this._subscriptionObj[item].unsubscribe();
            }
        }
    }
    _updateCheckbox(_event) {
        // console.log("-- Grid state: Checkbox/Radio checked --")
        let inputTarget = event.target;
        this._updateSelection(inputTarget.checked);
    }
    /**************************** Private functions ********************************/
    ///////////////////////////////////////////////////////////////////////////////////////////////
    /// Update functions
    ///////////////////////////////////////////////////////////////////////////////////////////////
    _updateSelection(_isChecked) {
        if (this._isHeader) {
            this._selectAll = _isChecked;
            this._updateAllCheckbox();
        }
        else {
            if (this._inputType === 'checkbox') {
                this._paramNode.selectThisNode(_isChecked);
                this._updateDefaultValue(this._paramNode.id, _isChecked);
            }
            else {
                this._paramsApi.deselectAll();
                this._paramNode.selectThisNode(true);
                this._updateDefaultValue(this._paramNode.id, true, true);
            }
        }
        this._emitSelectionChanged();
    }
    ///////////////////////////////////////////////////////////////////////////////////////////////
    /// Checkbox / Checkbox all functions
    ///////////////////////////////////////////////////////////////////////////////////////////////
    // private _updateAllCheckbox(): void {
    //     let currentModel = this._getCurrentRowModel();
    //     if (currentModel !== null) {
    //         currentModel.forEachNode((_rowNode: RowNode): void => {
    //             _rowNode.selectThisNode(this._selectAll);
    //             this._updateDefaultValue(_rowNode.data.id, this._selectAll);
    //         });
    //     }
    // }
    // Select is working properly 
    _updateAllCheckbox() {
        let currentModel = this._getCurrentRowModel();
        if (currentModel !== null) {
            if (currentModel && currentModel.rowsToDisplay && currentModel.rowsToDisplay.length) {
                currentModel.rowsToDisplay.forEach((_rowNode) => {
                    _rowNode.selectThisNode(this._selectAll);
                    this._updateDefaultValue(_rowNode.id, this._selectAll);
                });
            }
            else {
                currentModel.forEachNode((_rowNode) => {
                    _rowNode.selectThisNode(this._selectAll);
                    this._updateDefaultValue(_rowNode.data.id, this._selectAll);
                });
            }
        }
    }
    _checkSelectAll() {
        let currentModel = this._getCurrentRowModel();
        let selectAll = true;
        if (currentModel !== null) {
            if (currentModel.getRowCount() === 0) {
                selectAll = false;
            }
            else {
                currentModel.forEachNode((_rowNode) => {
                    if (selectAll && !_rowNode.isSelected()) {
                        selectAll = false;
                    }
                });
            }
        }
        this._selectAll = selectAll;
    }
    ///////////////////////////////////////////////////////////////////////////////////////////////
    /// Default value functions
    ///////////////////////////////////////////////////////////////////////////////////////////////
    _updateInitialSelection() {
        let isSelected = false;
        if (typeof this._paramsDefault !== 'undefined') {
            for (let i = 0; i < this._paramsDefault.length; ++i) {
                if (this._paramsDefault[i].toString() === this._paramNode.id) {
                    isSelected = true;
                    break;
                }
            }
        }
        this._paramNode.selectThisNode(isSelected);
    }
    _getDefaultSelection() {
        if (typeof this._params.params !== 'undefined' &&
            typeof this._params.params.default !== 'undefined') {
            this._paramsDefault = this._params.params.default;
        }
    }
    _updateDefaultValue(_id, _isSelected, _toEmptyDefault) {
        if (_toEmptyDefault) {
            this._paramsDefault.splice(0, this._paramsDefault.length);
        }
        if (_isSelected && this._paramsDefault.indexOf(_id) < 0) {
            this._paramsDefault.push(_id);
        }
        else if (!_isSelected && this._paramsDefault.indexOf(_id) > -1) {
            this._paramsDefault.splice(this._paramsDefault.indexOf(_id), 1);
        }
        this._sortDefaultValue();
    }
    ///////////////////////////////////////////////////////////////////////////////////////////////
    /// Events - Subscriber / On functions
    ///////////////////////////////////////////////////////////////////////////////////////////////
    _emitSelectionChanged() {
        this._kdIntTableEvent.selectionChanged(this._paramGridId, this._paramNode);
    }
    _setupSubscriptionEvents() {
        if (this._isHeader) {
            this._subscriptionObj.headerCheckboxSub = this._kdIntTableEvent.onModelChanged(this._paramGridId).subscribe(() => {
                this._checkSelectAll();
            });
            this._subscriptionObj.selectedChangeSub = this._kdIntTableEvent.onSelectionChanged(this._paramGridId).subscribe(() => {
                this._checkSelectAll();
            });
        }
    }
    ///////////////////////////////////////////////////////////////////////////////////////////////
    /// Misc functions
    ///////////////////////////////////////////////////////////////////////////////////////////////
    _updateInputType() {
        if (typeof this._params.params !== 'undefined') {
            this._inputType = this._params.params.inputType;
        }
        else {
            this._inputType = 'checkbox';
        }
    }
    _getCurrentRowModel() {
        if (typeof this._paramsApi !== 'undefined') {
            return this._paramsApi.getModel();
        }
        return null;
    }
    _sortDefaultValue() {
        this._paramsDefault.sort((_a, _b) => {
            if (_a > _b)
                return 1;
            else if (_a < _b)
                return -1;
            return 0;
        });
    }
}
KdTableCheckboxRadio.decorators = [
    { type: Component, args: [{
                selector: 'ag-checkbox-radio',
                template: `
        <div class="selection-wrapper">
            <input *ngIf="_isHeader" class="checkbox-radio-input"
                type="checkbox"
                [checked]="_selectAll"
                (change)="_updateCheckbox($event)"
            />

            <input *ngIf="!_isHeader" class="checkbox-radio-input"
                [type]="_inputType"
                [attr.name]="_inputType"
                [checked]="(_paramNode) ? _paramNode.isSelected() : false"
                (change)="_updateCheckbox($event)"
            />
            <label></label>
        </div>
    `,
                host: { class: 'kdx-ag-checkbox-radio' }
            },] }
];
KdTableCheckboxRadio.ctorParameters = () => [
    { type: KdIntTableEvent }
];
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoia2QtdGFibGUtY2hlY2tib3gtcmFkaW8uanMiLCJzb3VyY2VSb290IjoiQzoveGFtcHAvaHRkb2NzL1N0eWxlZ3VpZGUvaW9zdGctb3BlbmVtaXMtc3R5bGVndWlkZS9wcm9qZWN0cy9vcGVuZW1pcy1zdHlsZWd1aWRlLWxpYi9zcmMvIiwic291cmNlcyI6WyJrZC1jb21wb25lbnRzL2tkLWFuZ3VsYXItdGFibGUvdGFibGUtY29tcG9uZW50cy9rZC10YWJsZS1jaGVja2JveC1yYWRpby50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQSxPQUFPLEVBQUUsU0FBUyxFQUFhLE1BQU0sZUFBZSxDQUFDO0FBV3JELE9BQU8sRUFBRSxlQUFlLEVBQUUsTUFBTSwyQkFBMkIsQ0FBQztBQWdDNUQsTUFBTSxPQUFPLG9CQUFvQjtJQVk3QixZQUNZLGdCQUFpQztRQUFqQyxxQkFBZ0IsR0FBaEIsZ0JBQWdCLENBQWlCO1FBWnRDLGVBQVUsR0FBVyxVQUFVLENBQUM7UUFDaEMsY0FBUyxHQUFZLEtBQUssQ0FBQztRQUUzQixlQUFVLEdBQVksS0FBSyxDQUFDO1FBSTNCLG1CQUFjLEdBQTJCLEVBQUUsQ0FBQztRQUM1QyxpQkFBWSxHQUFXLGVBQWUsQ0FBQztRQUN2QyxxQkFBZ0IsR0FBa0MsRUFBRSxDQUFDO0lBSXpELENBQUM7SUFFTCxpRkFBaUY7SUFDakYsTUFBTSxDQUFDLE9BQVk7UUFDZixtRUFBbUU7UUFDbkUsSUFBSSxDQUFDLE9BQU8sR0FBRyxPQUFPLENBQUM7UUFDdkIsSUFBSSxDQUFDLFVBQVUsR0FBRyxJQUFJLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQztRQUNuQyxJQUFJLENBQUMsWUFBWSxHQUFHLElBQUksQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQztRQUMvQyxJQUFJLENBQUMsU0FBUyxHQUFHLE9BQU8sSUFBSSxDQUFDLE9BQU8sQ0FBQyxRQUFRLEtBQUssV0FBVyxDQUFDO1FBRTlELElBQUksQ0FBQyxvQkFBb0IsRUFBRSxDQUFDO1FBQzVCLElBQUksQ0FBQyxnQkFBZ0IsRUFBRSxDQUFDO1FBRXhCLElBQUksQ0FBQyxJQUFJLENBQUMsU0FBUyxFQUFFO1lBQ2pCLElBQUksQ0FBQyxVQUFVLEdBQUcsSUFBSSxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUM7WUFDcEMsSUFBSSxDQUFDLHVCQUF1QixFQUFFLENBQUM7U0FDbEM7UUFFRCxJQUFJLENBQUMsd0JBQXdCLEVBQUUsQ0FBQztJQUNwQyxDQUFDO0lBRUQsT0FBTyxDQUFDLE9BQVk7UUFDaEIsT0FBTyxLQUFLLENBQUM7SUFDakIsQ0FBQztJQUVELFdBQVc7UUFDUCxLQUFLLElBQUksSUFBSSxJQUFJLElBQUksQ0FBQyxnQkFBZ0IsRUFBRTtZQUNwQyxJQUFJLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxjQUFjLENBQUMsSUFBSSxDQUFDLEVBQUU7Z0JBQzVDLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxJQUFJLENBQUMsQ0FBQyxXQUFXLEVBQUUsQ0FBQzthQUM3QztTQUNKO0lBQ0wsQ0FBQztJQUVNLGVBQWUsQ0FBQyxNQUFXO1FBQzlCLDBEQUEwRDtRQUMxRCxJQUFJLFdBQVcsR0FBdUMsS0FBSyxDQUFDLE1BQU0sQ0FBQztRQUNuRSxJQUFJLENBQUMsZ0JBQWdCLENBQUMsV0FBVyxDQUFDLE9BQU8sQ0FBQyxDQUFDO0lBQy9DLENBQUM7SUFFRCxpRkFBaUY7SUFDakYsK0ZBQStGO0lBQy9GLG9CQUFvQjtJQUNwQiwrRkFBK0Y7SUFDdkYsZ0JBQWdCLENBQUMsVUFBbUI7UUFDeEMsSUFBSSxJQUFJLENBQUMsU0FBUyxFQUFFO1lBQ2hCLElBQUksQ0FBQyxVQUFVLEdBQUcsVUFBVSxDQUFDO1lBQzdCLElBQUksQ0FBQyxrQkFBa0IsRUFBRSxDQUFDO1NBRTdCO2FBQ0k7WUFDRCxJQUFJLElBQUksQ0FBQyxVQUFVLEtBQUssVUFBVSxFQUFFO2dCQUNoQyxJQUFJLENBQUMsVUFBVSxDQUFDLGNBQWMsQ0FBQyxVQUFVLENBQUMsQ0FBQztnQkFDM0MsSUFBSSxDQUFDLG1CQUFtQixDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsRUFBRSxFQUFFLFVBQVUsQ0FBQyxDQUFDO2FBQzVEO2lCQUNJO2dCQUNELElBQUksQ0FBQyxVQUFVLENBQUMsV0FBVyxFQUFFLENBQUM7Z0JBQzlCLElBQUksQ0FBQyxVQUFVLENBQUMsY0FBYyxDQUFDLElBQUksQ0FBQyxDQUFDO2dCQUNyQyxJQUFJLENBQUMsbUJBQW1CLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxFQUFFLEVBQUUsSUFBSSxFQUFFLElBQUksQ0FBQyxDQUFDO2FBQzVEO1NBQ0o7UUFFRCxJQUFJLENBQUMscUJBQXFCLEVBQUUsQ0FBQztJQUNqQyxDQUFDO0lBRUQsK0ZBQStGO0lBQy9GLHFDQUFxQztJQUNyQywrRkFBK0Y7SUFDL0YsdUNBQXVDO0lBQ3ZDLHFEQUFxRDtJQUVyRCxtQ0FBbUM7SUFDbkMsa0VBQWtFO0lBQ2xFLHdEQUF3RDtJQUN4RCwyRUFBMkU7SUFDM0UsY0FBYztJQUNkLFFBQVE7SUFDUixJQUFJO0lBRUosOEJBQThCO0lBQ3RCLGtCQUFrQjtRQUN0QixJQUFJLFlBQVksR0FBUSxJQUFJLENBQUMsbUJBQW1CLEVBQUUsQ0FBQztRQUNuRCxJQUFJLFlBQVksS0FBSyxJQUFJLEVBQUU7WUFDdkIsSUFBRyxZQUFZLElBQUksWUFBWSxDQUFDLGFBQWEsSUFBSSxZQUFZLENBQUMsYUFBYSxDQUFDLE1BQU0sRUFDbEY7Z0JBQ0ksWUFBWSxDQUFDLGFBQWEsQ0FBQyxPQUFPLENBQUMsQ0FBQyxRQUFRLEVBQUMsRUFBRTtvQkFDM0MsUUFBUSxDQUFDLGNBQWMsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLENBQUM7b0JBQ3pDLElBQUksQ0FBQyxtQkFBbUIsQ0FBQyxRQUFRLENBQUMsRUFBRSxFQUFFLElBQUksQ0FBQyxVQUFVLENBQUMsQ0FBQztnQkFDM0QsQ0FBQyxDQUFDLENBQUE7YUFDTDtpQkFBSTtnQkFDRCxZQUFZLENBQUMsV0FBVyxDQUFDLENBQUMsUUFBaUIsRUFBUSxFQUFFO29CQUNyRCxRQUFRLENBQUMsY0FBYyxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsQ0FBQztvQkFDekMsSUFBSSxDQUFDLG1CQUFtQixDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsRUFBRSxFQUFFLElBQUksQ0FBQyxVQUFVLENBQUMsQ0FBQztnQkFDaEUsQ0FBQyxDQUFDLENBQUM7YUFDRjtTQUVKO0lBQ0wsQ0FBQztJQUVPLGVBQWU7UUFDbkIsSUFBSSxZQUFZLEdBQUcsSUFBSSxDQUFDLG1CQUFtQixFQUFFLENBQUM7UUFDOUMsSUFBSSxTQUFTLEdBQVksSUFBSSxDQUFDO1FBQzlCLElBQUksWUFBWSxLQUFLLElBQUksRUFBRTtZQUN2QixJQUFJLFlBQVksQ0FBQyxXQUFXLEVBQUUsS0FBSyxDQUFDLEVBQUU7Z0JBQ2xDLFNBQVMsR0FBRyxLQUFLLENBQUM7YUFDckI7aUJBQ0k7Z0JBQ0QsWUFBWSxDQUFDLFdBQVcsQ0FBQyxDQUFDLFFBQWlCLEVBQVEsRUFBRTtvQkFDakQsSUFBSSxTQUFTLElBQUksQ0FBQyxRQUFRLENBQUMsVUFBVSxFQUFFLEVBQUU7d0JBQ3JDLFNBQVMsR0FBRyxLQUFLLENBQUM7cUJBQ3JCO2dCQUNMLENBQUMsQ0FBQyxDQUFDO2FBQ047U0FDSjtRQUNELElBQUksQ0FBQyxVQUFVLEdBQUcsU0FBUyxDQUFDO0lBQ2hDLENBQUM7SUFDRCwrRkFBK0Y7SUFDL0YsMkJBQTJCO0lBQzNCLCtGQUErRjtJQUN2Rix1QkFBdUI7UUFDM0IsSUFBSSxVQUFVLEdBQVksS0FBSyxDQUFDO1FBRWhDLElBQUksT0FBTyxJQUFJLENBQUMsY0FBYyxLQUFLLFdBQVcsRUFBRTtZQUM1QyxLQUFLLElBQUksQ0FBQyxHQUFXLENBQUMsRUFBRSxDQUFDLEdBQUcsSUFBSSxDQUFDLGNBQWMsQ0FBQyxNQUFNLEVBQUUsRUFBRSxDQUFDLEVBQUU7Z0JBQ3pELElBQUksSUFBSSxDQUFDLGNBQWMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLEVBQUUsS0FBSyxJQUFJLENBQUMsVUFBVSxDQUFDLEVBQUUsRUFBRTtvQkFDMUQsVUFBVSxHQUFHLElBQUksQ0FBQztvQkFDbEIsTUFBTTtpQkFDVDthQUNKO1NBQ0o7UUFFRCxJQUFJLENBQUMsVUFBVSxDQUFDLGNBQWMsQ0FBQyxVQUFVLENBQUMsQ0FBQztJQUMvQyxDQUFDO0lBRU8sb0JBQW9CO1FBQ3hCLElBQUksT0FBTyxJQUFJLENBQUMsT0FBTyxDQUFDLE1BQU0sS0FBSyxXQUFXO1lBQzFDLE9BQU8sSUFBSSxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsT0FBTyxLQUFLLFdBQVcsRUFBRTtZQUNoRCxJQUFJLENBQUMsY0FBYyxHQUFHLElBQUksQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLE9BQU8sQ0FBQztTQUN6RDtJQUNMLENBQUM7SUFFTyxtQkFBbUIsQ0FBQyxHQUFvQixFQUFFLFdBQW9CLEVBQUUsZUFBeUI7UUFDN0YsSUFBSSxlQUFlLEVBQUU7WUFDakIsSUFBSSxDQUFDLGNBQWMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxFQUFFLElBQUksQ0FBQyxjQUFjLENBQUMsTUFBTSxDQUFDLENBQUM7U0FDN0Q7UUFFRCxJQUFJLFdBQVcsSUFBSSxJQUFJLENBQUMsY0FBYyxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDLEVBQUU7WUFDckQsSUFBSSxDQUFDLGNBQWMsQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUM7U0FDakM7YUFDSSxJQUFJLENBQUMsV0FBVyxJQUFJLElBQUksQ0FBQyxjQUFjLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUMsQ0FBQyxFQUFFO1lBQzVELElBQUksQ0FBQyxjQUFjLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxjQUFjLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDO1NBQ25FO1FBQ0QsSUFBSSxDQUFDLGlCQUFpQixFQUFFLENBQUM7SUFDN0IsQ0FBQztJQUVELCtGQUErRjtJQUMvRixzQ0FBc0M7SUFDdEMsK0ZBQStGO0lBQ3ZGLHFCQUFxQjtRQUN6QixJQUFJLENBQUMsZ0JBQWdCLENBQUMsZ0JBQWdCLENBQUMsSUFBSSxDQUFDLFlBQVksRUFBRSxJQUFJLENBQUMsVUFBVSxDQUFDLENBQUM7SUFDL0UsQ0FBQztJQUVPLHdCQUF3QjtRQUM1QixJQUFJLElBQUksQ0FBQyxTQUFTLEVBQUU7WUFDaEIsSUFBSSxDQUFDLGdCQUFnQixDQUFDLGlCQUFpQixHQUFHLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxjQUFjLENBQUMsSUFBSSxDQUFDLFlBQVksQ0FBQyxDQUFDLFNBQVMsQ0FBQyxHQUFTLEVBQUU7Z0JBQ25ILElBQUksQ0FBQyxlQUFlLEVBQUUsQ0FBQztZQUMzQixDQUFDLENBQUMsQ0FBQztZQUVILElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxpQkFBaUIsR0FBRyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsa0JBQWtCLENBQUMsSUFBSSxDQUFDLFlBQVksQ0FBQyxDQUFDLFNBQVMsQ0FBQyxHQUFTLEVBQUU7Z0JBQ3ZILElBQUksQ0FBQyxlQUFlLEVBQUUsQ0FBQztZQUMzQixDQUFDLENBQUMsQ0FBQztTQUNOO0lBQ0wsQ0FBQztJQUVELCtGQUErRjtJQUMvRixrQkFBa0I7SUFDbEIsK0ZBQStGO0lBQ3ZGLGdCQUFnQjtRQUNwQixJQUFJLE9BQU8sSUFBSSxDQUFDLE9BQU8sQ0FBQyxNQUFNLEtBQUssV0FBVyxFQUFFO1lBQzVDLElBQUksQ0FBQyxVQUFVLEdBQUcsSUFBSSxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsU0FBUyxDQUFDO1NBQ25EO2FBQ0k7WUFDRCxJQUFJLENBQUMsVUFBVSxHQUFHLFVBQVUsQ0FBQztTQUNoQztJQUNMLENBQUM7SUFFTyxtQkFBbUI7UUFDdkIsSUFBSSxPQUFPLElBQUksQ0FBQyxVQUFVLEtBQUssV0FBVyxFQUFFO1lBQ3hDLE9BQU8sSUFBSSxDQUFDLFVBQVUsQ0FBQyxRQUFRLEVBQUUsQ0FBQztTQUNyQztRQUNELE9BQU8sSUFBSSxDQUFDO0lBQ2hCLENBQUM7SUFFTyxpQkFBaUI7UUFDckIsSUFBSSxDQUFDLGNBQWMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxFQUFPLEVBQUUsRUFBTyxFQUFVLEVBQUU7WUFDbEQsSUFBSSxFQUFFLEdBQUcsRUFBRTtnQkFBRSxPQUFPLENBQUMsQ0FBQztpQkFDakIsSUFBSSxFQUFFLEdBQUcsRUFBRTtnQkFBRSxPQUFPLENBQUMsQ0FBQyxDQUFDO1lBQzVCLE9BQU8sQ0FBQyxDQUFDO1FBQ2IsQ0FBQyxDQUFDLENBQUM7SUFDUCxDQUFDOzs7WUExT0osU0FBUyxTQUFDO2dCQUNQLFFBQVEsRUFBRSxtQkFBbUI7Z0JBQzdCLFFBQVEsRUFBRTs7Ozs7Ozs7Ozs7Ozs7OztLQWdCVDtnQkFDRCxJQUFJLEVBQUUsRUFBRSxLQUFLLEVBQUcsdUJBQXVCLEVBQUU7YUFDNUM7OztZQTlCUSxlQUFlIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgQ29tcG9uZW50LCBPbkRlc3Ryb3kgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcclxuaW1wb3J0IHsgU3Vic2NyaXB0aW9uIH0gZnJvbSAncnhqcyc7XHJcbmltcG9ydCB7IEFnUmVuZGVyZXJDb21wb25lbnQgfSBmcm9tICdhZy1ncmlkLWFuZ3VsYXInO1xyXG5pbXBvcnQge1xyXG4gICAgUm93Tm9kZSxcclxuICAgIEdyaWRBcGksXHJcbiAgICAvLyBJRW50ZXJwcmlzZVJvd01vZGVsLFxyXG4gICAgSUNlbGxSZW5kZXJlclBhcmFtc1xyXG59IGZyb20gJ2FnLWdyaWQtY29tbXVuaXR5JztcclxuXHJcblxyXG5pbXBvcnQgeyBLZEludFRhYmxlRXZlbnQgfSBmcm9tICcuLi9rZC1hbmd1bGFyLXRhYmxlLWV2ZW50JztcclxuXHJcbmludGVyZmFjZSBJS2RUYWJsZVNlbGVjdGlvblBhcmFtcyBleHRlbmRzIElDZWxsUmVuZGVyZXJQYXJhbXMge1xyXG4gICAgcGFyYW1zOiB7XHJcbiAgICAgICAgaW5wdXRUeXBlPzogJ3JhZGlvJyB8ICdjaGVja2JveCcsXHJcbiAgICAgICAgZGVmYXVsdD86IEFycmF5PGFueT4sXHJcbiAgICAgICAgZ3JpZElkPzogc3RyaW5nXHJcbiAgICB9O1xyXG59XHJcblxyXG5AQ29tcG9uZW50KHtcclxuICAgIHNlbGVjdG9yOiAnYWctY2hlY2tib3gtcmFkaW8nLFxyXG4gICAgdGVtcGxhdGU6IGBcclxuICAgICAgICA8ZGl2IGNsYXNzPVwic2VsZWN0aW9uLXdyYXBwZXJcIj5cclxuICAgICAgICAgICAgPGlucHV0ICpuZ0lmPVwiX2lzSGVhZGVyXCIgY2xhc3M9XCJjaGVja2JveC1yYWRpby1pbnB1dFwiXHJcbiAgICAgICAgICAgICAgICB0eXBlPVwiY2hlY2tib3hcIlxyXG4gICAgICAgICAgICAgICAgW2NoZWNrZWRdPVwiX3NlbGVjdEFsbFwiXHJcbiAgICAgICAgICAgICAgICAoY2hhbmdlKT1cIl91cGRhdGVDaGVja2JveCgkZXZlbnQpXCJcclxuICAgICAgICAgICAgLz5cclxuXHJcbiAgICAgICAgICAgIDxpbnB1dCAqbmdJZj1cIiFfaXNIZWFkZXJcIiBjbGFzcz1cImNoZWNrYm94LXJhZGlvLWlucHV0XCJcclxuICAgICAgICAgICAgICAgIFt0eXBlXT1cIl9pbnB1dFR5cGVcIlxyXG4gICAgICAgICAgICAgICAgW2F0dHIubmFtZV09XCJfaW5wdXRUeXBlXCJcclxuICAgICAgICAgICAgICAgIFtjaGVja2VkXT1cIihfcGFyYW1Ob2RlKSA/IF9wYXJhbU5vZGUuaXNTZWxlY3RlZCgpIDogZmFsc2VcIlxyXG4gICAgICAgICAgICAgICAgKGNoYW5nZSk9XCJfdXBkYXRlQ2hlY2tib3goJGV2ZW50KVwiXHJcbiAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgIDxsYWJlbD48L2xhYmVsPlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgYCxcclxuICAgIGhvc3Q6IHsgY2xhc3MgOiAna2R4LWFnLWNoZWNrYm94LXJhZGlvJyB9XHJcbn0pXHJcblxyXG5leHBvcnQgY2xhc3MgS2RUYWJsZUNoZWNrYm94UmFkaW8gaW1wbGVtZW50cyBBZ1JlbmRlcmVyQ29tcG9uZW50LCBPbkRlc3Ryb3kge1xyXG4gICAgcHVibGljIF9pbnB1dFR5cGU6IHN0cmluZyA9ICdjaGVja2JveCc7XHJcbiAgICBwdWJsaWMgX2lzSGVhZGVyOiBib29sZWFuID0gZmFsc2U7XHJcbiAgICBwdWJsaWMgX3BhcmFtTm9kZTogUm93Tm9kZTtcclxuICAgIHB1YmxpYyBfc2VsZWN0QWxsOiBib29sZWFuID0gZmFsc2U7XHJcblxyXG4gICAgcHJpdmF0ZSBfcGFyYW1zOiBJS2RUYWJsZVNlbGVjdGlvblBhcmFtcztcclxuICAgIHByaXZhdGUgX3BhcmFtc0FwaTogR3JpZEFwaTtcclxuICAgIHByaXZhdGUgX3BhcmFtc0RlZmF1bHQ6IEFycmF5PHN0cmluZyB8IG51bWJlcj4gPSBbXTtcclxuICAgIHByaXZhdGUgX3BhcmFtR3JpZElkOiBzdHJpbmcgPSAna2QtdGFibGUtZ3JpZCc7XHJcbiAgICBwcml2YXRlIF9zdWJzY3JpcHRpb25PYmo6IHtba2V5OiBzdHJpbmddOiBTdWJzY3JpcHRpb259ID0ge307XHJcblxyXG4gICAgY29uc3RydWN0b3IoXHJcbiAgICAgICAgcHJpdmF0ZSBfa2RJbnRUYWJsZUV2ZW50OiBLZEludFRhYmxlRXZlbnRcclxuICAgICkgeyB9XHJcblxyXG4gICAgLyoqKioqKioqKioqKioqKioqKioqKiBDb21wb25lbnQgTGlmZSBjeWNsZXMgZnVuY3Rpb25zICoqKioqKioqKioqKioqKioqKioqKioqKiovXHJcbiAgICBhZ0luaXQoX3BhcmFtczogYW55KTogdm9pZCB7XHJcbiAgICAgICAgLy8gY29uc29sZS5sb2coXCItLSBHcmlkIHN0YXRlOiBDaGVja2JveC9SYWRpbyBhZ0luaXQgLS1cIiwgX3BhcmFtcyk7XHJcbiAgICAgICAgdGhpcy5fcGFyYW1zID0gX3BhcmFtcztcclxuICAgICAgICB0aGlzLl9wYXJhbXNBcGkgPSB0aGlzLl9wYXJhbXMuYXBpO1xyXG4gICAgICAgIHRoaXMuX3BhcmFtR3JpZElkID0gdGhpcy5fcGFyYW1zLnBhcmFtcy5ncmlkSWQ7XHJcbiAgICAgICAgdGhpcy5faXNIZWFkZXIgPSB0eXBlb2YgdGhpcy5fcGFyYW1zLnJvd0luZGV4ID09PSAndW5kZWZpbmVkJztcclxuXHJcbiAgICAgICAgdGhpcy5fZ2V0RGVmYXVsdFNlbGVjdGlvbigpO1xyXG4gICAgICAgIHRoaXMuX3VwZGF0ZUlucHV0VHlwZSgpO1xyXG5cclxuICAgICAgICBpZiAoIXRoaXMuX2lzSGVhZGVyKSB7XHJcbiAgICAgICAgICAgIHRoaXMuX3BhcmFtTm9kZSA9IHRoaXMuX3BhcmFtcy5ub2RlO1xyXG4gICAgICAgICAgICB0aGlzLl91cGRhdGVJbml0aWFsU2VsZWN0aW9uKCk7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICB0aGlzLl9zZXR1cFN1YnNjcmlwdGlvbkV2ZW50cygpO1xyXG4gICAgfVxyXG5cclxuICAgIHJlZnJlc2goX3BhcmFtczogYW55KTogYm9vbGVhbiB7XHJcbiAgICAgICAgcmV0dXJuIGZhbHNlO1xyXG4gICAgfVxyXG5cclxuICAgIG5nT25EZXN0cm95KCk6IHZvaWQge1xyXG4gICAgICAgIGZvciAobGV0IGl0ZW0gaW4gdGhpcy5fc3Vic2NyaXB0aW9uT2JqKSB7XHJcbiAgICAgICAgICAgIGlmICh0aGlzLl9zdWJzY3JpcHRpb25PYmouaGFzT3duUHJvcGVydHkoaXRlbSkpIHtcclxuICAgICAgICAgICAgICAgIHRoaXMuX3N1YnNjcmlwdGlvbk9ialtpdGVtXS51bnN1YnNjcmliZSgpO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIHB1YmxpYyBfdXBkYXRlQ2hlY2tib3goX2V2ZW50OiBhbnkpOiB2b2lkIHtcclxuICAgICAgICAvLyBjb25zb2xlLmxvZyhcIi0tIEdyaWQgc3RhdGU6IENoZWNrYm94L1JhZGlvIGNoZWNrZWQgLS1cIilcclxuICAgICAgICBsZXQgaW5wdXRUYXJnZXQ6IEhUTUxJbnB1dEVsZW1lbnQgPSA8SFRNTElucHV0RWxlbWVudD5ldmVudC50YXJnZXQ7XHJcbiAgICAgICAgdGhpcy5fdXBkYXRlU2VsZWN0aW9uKGlucHV0VGFyZ2V0LmNoZWNrZWQpO1xyXG4gICAgfVxyXG5cclxuICAgIC8qKioqKioqKioqKioqKioqKioqKioqKioqKioqIFByaXZhdGUgZnVuY3Rpb25zICoqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqL1xyXG4gICAgLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy9cclxuICAgIC8vLyBVcGRhdGUgZnVuY3Rpb25zXHJcbiAgICAvLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vL1xyXG4gICAgcHJpdmF0ZSBfdXBkYXRlU2VsZWN0aW9uKF9pc0NoZWNrZWQ6IGJvb2xlYW4pOiB2b2lkIHtcclxuICAgICAgICBpZiAodGhpcy5faXNIZWFkZXIpIHtcclxuICAgICAgICAgICAgdGhpcy5fc2VsZWN0QWxsID0gX2lzQ2hlY2tlZDtcclxuICAgICAgICAgICAgdGhpcy5fdXBkYXRlQWxsQ2hlY2tib3goKTtcclxuXHJcbiAgICAgICAgfVxyXG4gICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICBpZiAodGhpcy5faW5wdXRUeXBlID09PSAnY2hlY2tib3gnKSB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLl9wYXJhbU5vZGUuc2VsZWN0VGhpc05vZGUoX2lzQ2hlY2tlZCk7XHJcbiAgICAgICAgICAgICAgICB0aGlzLl91cGRhdGVEZWZhdWx0VmFsdWUodGhpcy5fcGFyYW1Ob2RlLmlkLCBfaXNDaGVja2VkKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgICAgIHRoaXMuX3BhcmFtc0FwaS5kZXNlbGVjdEFsbCgpO1xyXG4gICAgICAgICAgICAgICAgdGhpcy5fcGFyYW1Ob2RlLnNlbGVjdFRoaXNOb2RlKHRydWUpO1xyXG4gICAgICAgICAgICAgICAgdGhpcy5fdXBkYXRlRGVmYXVsdFZhbHVlKHRoaXMuX3BhcmFtTm9kZS5pZCwgdHJ1ZSwgdHJ1ZSk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIHRoaXMuX2VtaXRTZWxlY3Rpb25DaGFuZ2VkKCk7XHJcbiAgICB9XHJcblxyXG4gICAgLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy9cclxuICAgIC8vLyBDaGVja2JveCAvIENoZWNrYm94IGFsbCBmdW5jdGlvbnNcclxuICAgIC8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vXHJcbiAgICAvLyBwcml2YXRlIF91cGRhdGVBbGxDaGVja2JveCgpOiB2b2lkIHtcclxuICAgIC8vICAgICBsZXQgY3VycmVudE1vZGVsID0gdGhpcy5fZ2V0Q3VycmVudFJvd01vZGVsKCk7XHJcblxyXG4gICAgLy8gICAgIGlmIChjdXJyZW50TW9kZWwgIT09IG51bGwpIHtcclxuICAgIC8vICAgICAgICAgY3VycmVudE1vZGVsLmZvckVhY2hOb2RlKChfcm93Tm9kZTogUm93Tm9kZSk6IHZvaWQgPT4ge1xyXG4gICAgLy8gICAgICAgICAgICAgX3Jvd05vZGUuc2VsZWN0VGhpc05vZGUodGhpcy5fc2VsZWN0QWxsKTtcclxuICAgIC8vICAgICAgICAgICAgIHRoaXMuX3VwZGF0ZURlZmF1bHRWYWx1ZShfcm93Tm9kZS5kYXRhLmlkLCB0aGlzLl9zZWxlY3RBbGwpO1xyXG4gICAgLy8gICAgICAgICB9KTtcclxuICAgIC8vICAgICB9XHJcbiAgICAvLyB9XHJcblxyXG4gICAgLy8gU2VsZWN0IGlzIHdvcmtpbmcgcHJvcGVybHkgXHJcbiAgICBwcml2YXRlIF91cGRhdGVBbGxDaGVja2JveCgpOiB2b2lkIHtcclxuICAgICAgICBsZXQgY3VycmVudE1vZGVsOiBhbnkgPSB0aGlzLl9nZXRDdXJyZW50Um93TW9kZWwoKTtcclxuICAgICAgICBpZiAoY3VycmVudE1vZGVsICE9PSBudWxsKSB7XHJcbiAgICAgICAgICAgIGlmKGN1cnJlbnRNb2RlbCAmJiBjdXJyZW50TW9kZWwucm93c1RvRGlzcGxheSAmJiBjdXJyZW50TW9kZWwucm93c1RvRGlzcGxheS5sZW5ndGgpXHJcbiAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICAgIGN1cnJlbnRNb2RlbC5yb3dzVG9EaXNwbGF5LmZvckVhY2goKF9yb3dOb2RlKT0+e1xyXG4gICAgICAgICAgICAgICAgICAgIF9yb3dOb2RlLnNlbGVjdFRoaXNOb2RlKHRoaXMuX3NlbGVjdEFsbCk7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5fdXBkYXRlRGVmYXVsdFZhbHVlKF9yb3dOb2RlLmlkLCB0aGlzLl9zZWxlY3RBbGwpO1xyXG4gICAgICAgICAgICAgICAgfSkgXHJcbiAgICAgICAgICAgIH1lbHNle1xyXG4gICAgICAgICAgICAgICAgY3VycmVudE1vZGVsLmZvckVhY2hOb2RlKChfcm93Tm9kZTogUm93Tm9kZSk6IHZvaWQgPT4ge1xyXG4gICAgICAgICAgICAgICAgX3Jvd05vZGUuc2VsZWN0VGhpc05vZGUodGhpcy5fc2VsZWN0QWxsKTtcclxuICAgICAgICAgICAgICAgIHRoaXMuX3VwZGF0ZURlZmF1bHRWYWx1ZShfcm93Tm9kZS5kYXRhLmlkLCB0aGlzLl9zZWxlY3RBbGwpO1xyXG4gICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgIFxyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF9jaGVja1NlbGVjdEFsbCgpOiB2b2lkIHtcclxuICAgICAgICBsZXQgY3VycmVudE1vZGVsID0gdGhpcy5fZ2V0Q3VycmVudFJvd01vZGVsKCk7XHJcbiAgICAgICAgbGV0IHNlbGVjdEFsbDogYm9vbGVhbiA9IHRydWU7XHJcbiAgICAgICAgaWYgKGN1cnJlbnRNb2RlbCAhPT0gbnVsbCkge1xyXG4gICAgICAgICAgICBpZiAoY3VycmVudE1vZGVsLmdldFJvd0NvdW50KCkgPT09IDApIHtcclxuICAgICAgICAgICAgICAgIHNlbGVjdEFsbCA9IGZhbHNlO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgY3VycmVudE1vZGVsLmZvckVhY2hOb2RlKChfcm93Tm9kZTogUm93Tm9kZSk6IHZvaWQgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgIGlmIChzZWxlY3RBbGwgJiYgIV9yb3dOb2RlLmlzU2VsZWN0ZWQoKSkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBzZWxlY3RBbGwgPSBmYWxzZTtcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgICAgICB0aGlzLl9zZWxlY3RBbGwgPSBzZWxlY3RBbGw7XHJcbiAgICB9XHJcbiAgICAvLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vL1xyXG4gICAgLy8vIERlZmF1bHQgdmFsdWUgZnVuY3Rpb25zXHJcbiAgICAvLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vL1xyXG4gICAgcHJpdmF0ZSBfdXBkYXRlSW5pdGlhbFNlbGVjdGlvbigpOiB2b2lkIHtcclxuICAgICAgICBsZXQgaXNTZWxlY3RlZDogYm9vbGVhbiA9IGZhbHNlO1xyXG5cclxuICAgICAgICBpZiAodHlwZW9mIHRoaXMuX3BhcmFtc0RlZmF1bHQgIT09ICd1bmRlZmluZWQnKSB7XHJcbiAgICAgICAgICAgIGZvciAobGV0IGk6IG51bWJlciA9IDA7IGkgPCB0aGlzLl9wYXJhbXNEZWZhdWx0Lmxlbmd0aDsgKytpKSB7XHJcbiAgICAgICAgICAgICAgICBpZiAodGhpcy5fcGFyYW1zRGVmYXVsdFtpXS50b1N0cmluZygpID09PSB0aGlzLl9wYXJhbU5vZGUuaWQpIHtcclxuICAgICAgICAgICAgICAgICAgICBpc1NlbGVjdGVkID0gdHJ1ZTtcclxuICAgICAgICAgICAgICAgICAgICBicmVhaztcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgdGhpcy5fcGFyYW1Ob2RlLnNlbGVjdFRoaXNOb2RlKGlzU2VsZWN0ZWQpO1xyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX2dldERlZmF1bHRTZWxlY3Rpb24oKTogdm9pZCB7XHJcbiAgICAgICAgaWYgKHR5cGVvZiB0aGlzLl9wYXJhbXMucGFyYW1zICE9PSAndW5kZWZpbmVkJyAmJlxyXG4gICAgICAgICAgICB0eXBlb2YgdGhpcy5fcGFyYW1zLnBhcmFtcy5kZWZhdWx0ICE9PSAndW5kZWZpbmVkJykge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5fcGFyYW1zRGVmYXVsdCA9IHRoaXMuX3BhcmFtcy5wYXJhbXMuZGVmYXVsdDtcclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfdXBkYXRlRGVmYXVsdFZhbHVlKF9pZDogbnVtYmVyIHwgc3RyaW5nLCBfaXNTZWxlY3RlZDogYm9vbGVhbiwgX3RvRW1wdHlEZWZhdWx0PzogYm9vbGVhbik6IHZvaWQge1xyXG4gICAgICAgIGlmIChfdG9FbXB0eURlZmF1bHQpIHtcclxuICAgICAgICAgICAgdGhpcy5fcGFyYW1zRGVmYXVsdC5zcGxpY2UoMCwgdGhpcy5fcGFyYW1zRGVmYXVsdC5sZW5ndGgpO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgaWYgKF9pc1NlbGVjdGVkICYmIHRoaXMuX3BhcmFtc0RlZmF1bHQuaW5kZXhPZihfaWQpIDwgMCkge1xyXG4gICAgICAgICAgICB0aGlzLl9wYXJhbXNEZWZhdWx0LnB1c2goX2lkKTtcclxuICAgICAgICB9XHJcbiAgICAgICAgZWxzZSBpZiAoIV9pc1NlbGVjdGVkICYmIHRoaXMuX3BhcmFtc0RlZmF1bHQuaW5kZXhPZihfaWQpID4gLTEpIHtcclxuICAgICAgICAgICAgdGhpcy5fcGFyYW1zRGVmYXVsdC5zcGxpY2UodGhpcy5fcGFyYW1zRGVmYXVsdC5pbmRleE9mKF9pZCksIDEpO1xyXG4gICAgICAgIH1cclxuICAgICAgICB0aGlzLl9zb3J0RGVmYXVsdFZhbHVlKCk7XHJcbiAgICB9XHJcblxyXG4gICAgLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy9cclxuICAgIC8vLyBFdmVudHMgLSBTdWJzY3JpYmVyIC8gT24gZnVuY3Rpb25zXHJcbiAgICAvLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vL1xyXG4gICAgcHJpdmF0ZSBfZW1pdFNlbGVjdGlvbkNoYW5nZWQoKTogdm9pZCB7XHJcbiAgICAgICAgdGhpcy5fa2RJbnRUYWJsZUV2ZW50LnNlbGVjdGlvbkNoYW5nZWQodGhpcy5fcGFyYW1HcmlkSWQsIHRoaXMuX3BhcmFtTm9kZSk7XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfc2V0dXBTdWJzY3JpcHRpb25FdmVudHMoKTogdm9pZCB7XHJcbiAgICAgICAgaWYgKHRoaXMuX2lzSGVhZGVyKSB7XHJcbiAgICAgICAgICAgIHRoaXMuX3N1YnNjcmlwdGlvbk9iai5oZWFkZXJDaGVja2JveFN1YiA9IHRoaXMuX2tkSW50VGFibGVFdmVudC5vbk1vZGVsQ2hhbmdlZCh0aGlzLl9wYXJhbUdyaWRJZCkuc3Vic2NyaWJlKCgpOiB2b2lkID0+IHtcclxuICAgICAgICAgICAgICAgIHRoaXMuX2NoZWNrU2VsZWN0QWxsKCk7XHJcbiAgICAgICAgICAgIH0pO1xyXG5cclxuICAgICAgICAgICAgdGhpcy5fc3Vic2NyaXB0aW9uT2JqLnNlbGVjdGVkQ2hhbmdlU3ViID0gdGhpcy5fa2RJbnRUYWJsZUV2ZW50Lm9uU2VsZWN0aW9uQ2hhbmdlZCh0aGlzLl9wYXJhbUdyaWRJZCkuc3Vic2NyaWJlKCgpOiB2b2lkID0+IHtcclxuICAgICAgICAgICAgICAgIHRoaXMuX2NoZWNrU2VsZWN0QWxsKCk7XHJcbiAgICAgICAgICAgIH0pO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICAvLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vL1xyXG4gICAgLy8vIE1pc2MgZnVuY3Rpb25zXHJcbiAgICAvLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vL1xyXG4gICAgcHJpdmF0ZSBfdXBkYXRlSW5wdXRUeXBlKCk6IHZvaWQge1xyXG4gICAgICAgIGlmICh0eXBlb2YgdGhpcy5fcGFyYW1zLnBhcmFtcyAhPT0gJ3VuZGVmaW5lZCcpIHtcclxuICAgICAgICAgICAgdGhpcy5faW5wdXRUeXBlID0gdGhpcy5fcGFyYW1zLnBhcmFtcy5pbnB1dFR5cGU7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICB0aGlzLl9pbnB1dFR5cGUgPSAnY2hlY2tib3gnO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF9nZXRDdXJyZW50Um93TW9kZWwoKSB7XHJcbiAgICAgICAgaWYgKHR5cGVvZiB0aGlzLl9wYXJhbXNBcGkgIT09ICd1bmRlZmluZWQnKSB7XHJcbiAgICAgICAgICAgIHJldHVybiB0aGlzLl9wYXJhbXNBcGkuZ2V0TW9kZWwoKTtcclxuICAgICAgICB9XHJcbiAgICAgICAgcmV0dXJuIG51bGw7XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfc29ydERlZmF1bHRWYWx1ZSgpOiB2b2lkIHtcclxuICAgICAgICB0aGlzLl9wYXJhbXNEZWZhdWx0LnNvcnQoKF9hOiBhbnksIF9iOiBhbnkpOiBudW1iZXIgPT4ge1xyXG4gICAgICAgICAgICBpZiAoX2EgPiBfYikgcmV0dXJuIDE7XHJcbiAgICAgICAgICAgIGVsc2UgaWYgKF9hIDwgX2IpIHJldHVybiAtMTtcclxuICAgICAgICAgICAgcmV0dXJuIDA7XHJcbiAgICAgICAgfSk7XHJcbiAgICB9XHJcbn1cclxuIl19