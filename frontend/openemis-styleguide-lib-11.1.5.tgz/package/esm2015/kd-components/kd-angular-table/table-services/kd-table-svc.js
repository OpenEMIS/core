import { Injectable } from '@angular/core';
import { KdTableAction } from '../table-components/kd-table-action';
import { KdTableCheckboxRadio } from '../table-components/kd-table-checkbox-radio';
import { KdTableInput } from '../table-components/kd-table-input';
import { KdTableImage } from '../table-components/kd-table-image';
import { KdDataSvc } from '../../kd-common/index';
/**
 * -- Documentation for kd-table-svc.ts
 *
 * - Public functions (Usable by both extended services):
 *     - Checking functions
 *         - isApiReady
 *         - hasSelectionAll
 *         - hasInputType
 *         - isInputType
 *         - isEnterpriseModel
 *     - Update functions
 *         - updateSelectDefaultValue
 *         - updateSelectionValues
 *         - updateGridButtons
 *         - updateRowDataWithColumn (Generations of input context in gridOptions.context if input exist)
 *         - generatedApiFunctions (Generation of APIs)
 *     - Misc function
 *         - getGridId
 *         - getImageSizeBy
 *         - getTableContextKey
 *         - getRouterPlaceholderPath (For pathMap of click type router)
 *         - b64toBlob
 *
 * - Protected function:
 *     - Grid Options function
 *         - getDefaultGridOptions
 *     - Column definition functions
 *         - generateColumnDefinitions
 *         - isColDefOfType
 *     - API generation function
 *     - Misc functions
 *         - generateGridId
 *         - generateContextKey
 *         - getImageSizeBy
 *
 * - Private functions:
 *     - Column definition functions
 *         - _generateColDefsFromColConfig (ColDef generation based on column config - checks normal columns, input column and image columns)
 *         - _generateColDefsFromConfig (ColDef generation based on grid config - checks action column and selection column)
 *         - _generateActionColDef (Action)
 *         - _generateCheckboxRadioColDef (Selection)
 *         - _generateImageColDef (Image)
 *         - _generateInputColDef (Input)
 *     - API generation functions
 *         - _generateInputApi (api.dynamicForms)
 *         - _generateGeneralApi (api.general)
 *     - Table input functions
 *         - _generateTableInputContext (Loop all columns and rows and each of the question to generate the context for input columns)
 *     - Selection functions
 *         - _convertDataValueToObject (set to object if config consist of return keys)
 *         - _appendDataValueKey
 *     - Misc functions
 *         - _updateFilterColDef
 *         - _getDefaultColumnConfig
 */
export class KdTableSvcBase {
    constructor() {
        /******************************** Variables *********************************/
        this.ROW_HEIGHT = 150;
        this.CONTEXT_DELIMITER = '~';
        this.TABLE_INPUT_CONTEXT_KEY = 'tableInputContext';
        this.DEFAULT_PAGESIZE = 25;
        this.IMAGE_PADDING = 20;
        this.DEFAULT_GRIDID = 'kd-table-grid';
        this.GIRD_PARAMS_KEY = {
            input: 'inputConfig',
            image: 'imageConfig'
        };
        this.dataSvc = new KdDataSvc();
        this.rowKey = 'id';
        /************************* End of private functions **************************/
    }
    /*************** Public functions (shared for both services) ****************/
    ////////////////////////////////////////////////////////
    /// Checking functions
    ////////////////////////////////////////////////////////
    isApiReady(_gridOptions) {
        if (typeof _gridOptions !== 'undefined' &&
            _gridOptions !== null &&
            typeof _gridOptions.api !== 'undefined') {
            return true;
        }
        return false;
    }
    hasSelectionAll(_gridConfig) {
        if (typeof _gridConfig !== 'undefined' &&
            typeof _gridConfig.selection !== 'undefined' &&
            typeof _gridConfig.selection.type !== 'undefined' &&
            _gridConfig.selection.type === 'all' &&
            _gridConfig.loadType !== 'infinite') {
            return true;
        }
        return false;
    }
    hasInputType(_tableColumn, _type) {
        if (typeof _tableColumn !== 'undefined') {
            for (let i = 0; i < _tableColumn.length; ++i) {
                if (this.isInputType(_tableColumn[i], _type)) {
                    return true;
                }
            }
        }
        return false;
    }
    isInputType(_column, _type) {
        return (typeof _column.type !== 'undefined' && _column.type === _type);
    }
    isEnterpriseModel(_loadType) {
        return (_loadType === 'oneshot' || _loadType === 'infinite' || _loadType === 'server');
    }
    ////////////////////////////////////////////////////////
    /// Selection functions
    ////////////////////////////////////////////////////////
    updateSelectDefaultValue(_gridConfig) {
        if (typeof _gridConfig.selection !== 'undefined') {
            if (typeof _gridConfig.selection.value === 'undefined') {
                _gridConfig.selection.value = [];
            }
            else if (_gridConfig.selection.type === 'single' && _gridConfig.selection.value.length > 1) {
                console.warn('KdTable warning: Single selection type contains more than 1 default values.');
                _gridConfig.selection.value = _gridConfig.selection.value.slice(0, 1);
            }
        }
    }
    /**
     * [updateSelectionValues() - Returns the selected nodes based on the returnKey specify.
     *  If is not specify, array of ids will be return on selection.
     *  Only works for normal, infinite and oneshot loadType.
     *     - Not specify - Return [ 1, 2, 3 ];
     *     - Specify     - Return [ {id: 1, grade: "1" }, {id: 2, grade: "1"}, {id: 3, grade: "2"}]
     * ]
     * _rowData       : [Current provided rowData]
     * _selectedIds   : [Current selected rowData ids]
     * _returnKey     : [List of property keys to return with id]
     * [Generated selection by returnKey]
     */
    updateSelectionValues(_rowData, _selectedIds, _returnKey, _loadType) {
        if (typeof _returnKey === 'undefined' ||
            _returnKey === null ||
            _returnKey.length === 0) {
            return _selectedIds;
        }
        let generatedSelection = [];
        for (let i = 0; i < _rowData.length; i++) {
            let dataItem = _rowData[i];
            let oneItem = {};
            if (_selectedIds.indexOf(dataItem[this.rowKey]) > -1) {
                oneItem[this.rowKey] = dataItem[this.rowKey];
                for (let j = 0; j < _returnKey.length; j++) {
                    if (dataItem.hasOwnProperty(_returnKey[j])) {
                        oneItem[_returnKey[j]] = dataItem[_returnKey[j]];
                    }
                    else if (_returnKey[j].indexOf('.') > 0) {
                        let returnVal = this.dataSvc.getDataValue(dataItem, _returnKey[j]);
                        if (returnVal !== null) {
                            let newItem = Object.assign({}, oneItem);
                            oneItem = this._convertDataValueToObject(newItem, _returnKey[j], returnVal);
                        }
                    }
                }
                generatedSelection.push(oneItem);
            }
        }
        return generatedSelection;
    }
    ////////////////////////////////////////////////////////
    /// Grid Button functions
    ////////////////////////////////////////////////////////
    updateGridButtons(_gridConfig) {
        if (typeof _gridConfig.button === 'undefined') {
            _gridConfig.button = [];
        }
        else if (_gridConfig.button.length > 4) {
            console.warn('KdTable warning: Max 4 buttons for table. Slicing to 4.');
            _gridConfig.button = _gridConfig.button.slice(0, 4);
        }
    }
    ////////////////////////////////////////////////////////
    /// Table Input functions
    ////////////////////////////////////////////////////////
    updateRowDataWithColumn(_rowData, _columnConfig, _gridId, _gridOptions) {
        if (this.hasInputType(_columnConfig, 'input')) {
            if (typeof _gridOptions.context[this.TABLE_INPUT_CONTEXT_KEY] === 'undefined') {
                _gridOptions.context[this.TABLE_INPUT_CONTEXT_KEY] = {};
            }
            let inputContext = this._generateTableInputContext(_columnConfig, _rowData, _gridId);
            _gridOptions.context[this.TABLE_INPUT_CONTEXT_KEY] = Object.assign(_gridOptions.context[this.TABLE_INPUT_CONTEXT_KEY], inputContext);
        }
    }
    ////////////////////////////////////////////////////////
    /// API Generation function
    ////////////////////////////////////////////////////////
    generatedApiFunctions(_gridApi, _apiParams) {
        _gridApi.dynamicForm = this._generateInputApi(_apiParams.id, _apiParams.event);
        _gridApi.general = this._generateGeneralApi(_apiParams.rows);
    }
    ////////////////////////////////////////////////////////
    /// Misc function
    ////////////////////////////////////////////////////////
    getGridId(_gridConfig) {
        if (typeof _gridConfig.id === 'undefined') {
            _gridConfig.id = this.DEFAULT_GRIDID;
        }
        return _gridConfig.id;
    }
    getImageSizeBy(_tableColumn, _dimension) {
        // Default placeholder width 150 + 20 gap
        let width = 150 + this.IMAGE_PADDING;
        if (typeof _tableColumn.config !== 'undefined' &&
            typeof _tableColumn.config.image !== 'undefined' &&
            typeof _tableColumn.config.image[_dimension] !== 'undefined') {
            width = _tableColumn.config.image[_dimension] + this.IMAGE_PADDING;
        }
        return width;
    }
    getTableContextKey() {
        return this.TABLE_INPUT_CONTEXT_KEY;
    }
    getRouterPlaceholderPath(_rowNode, _path) {
        return this.dataSvc.getPlaceholder(_rowNode.data, _path);
    }
    b64toBlob(b64Data, contentType) {
        let sliceSize = 512;
        let byteCharacters = atob(b64Data);
        let byteArrays = [];
        for (let offset = 0; offset < byteCharacters.length; offset += sliceSize) {
            let slice = byteCharacters.slice(offset, offset + sliceSize);
            let byteNumbers = new Array(slice.length);
            for (let i = 0; i < slice.length; i++) {
                byteNumbers[i] = slice.charCodeAt(i);
            }
            let byteArray = new Uint8Array(byteNumbers);
            byteArrays.push(byteArray);
        }
        let blob = new Blob(byteArrays, { type: contentType });
        return blob;
    }
    /********** End of public functions / Start of protected functions **********/
    ////////////////////////////////////////////////////////
    /// Grid Options functions
    ////////////////////////////////////////////////////////
    getDefaultGridOptions(_direction, _rowHeight) {
        this.direction = _direction;
        return {
            rowData: [],
            columnDefs: [],
            enableRtl: _direction === 'rtl',
            headerHeight: 38,
            rowHeight: (typeof _rowHeight !== 'undefined') ? _rowHeight + 20 : this.ROW_HEIGHT,
            // suppressMovableColumns: true,
            suppressDragLeaveHidesColumns: true,
            enableColResize: true,
            suppressContextMenu: true,
            suppressMenuHide: true,
            ensureDomOrder: true,
            suppressPropertyNamesCheck: true,
            // suppressColumnVirtualisation: true,
            animateRows: false,
            rowBuffer: 5,
            getRowNodeId: (_data) => {
                let id = _data.id;
                if (typeof _data.id === 'number') {
                    id = id.toString();
                }
                return id;
            },
            unSortIcon: true,
            icons: {
                filter: '<i class="fa fa-filter"/>',
                sortAscending: '<i class="fa fa-caret-down"/>',
                sortDescending: '<i class="fa fa-caret-up"/>',
                sortUnSort: '<i class="fa fa-sort"/>',
                // groupExpanded: '<i class="fa fa-minus-circle"/>',
                // groupContracted: '<i class="fa fa-plus-circle"/>',
                groupExpanded: '<i class="fa fa-angle-down"/>',
                groupContracted: '<i class="fa fa-angle-right"/>',
                menu: '<i class="fa fa-bars"/>'
            },
            autoGroupColumnDef: {
                icons: {
                    menu: '<i class="fa fa-bar" style="display:none"/>',
                }
            },
            context: {},
            overlayNoRowsTemplate: '<span class="ag-custom-overlay"><i class="fa fa-info-circle fa-lg margin-right10"></i>No record found</span>'
        };
    }
    ////////////////////////////////////////////////////////
    /// Column Definition functions
    ////////////////////////////////////////////////////////
    generateColumnDefinitions(_columnConfig, _gridConfig, _suppressMovableColumns = true) {
        let columnDef = this._generateColDefsFromColConfig(_columnConfig, _gridConfig, _suppressMovableColumns);
        let columnObjects = this._generateColDefsFromConfig(_gridConfig);
        if (columnObjects.hasOwnProperty('action')) {
            columnDef.push(columnObjects.action);
        }
        if (columnObjects.hasOwnProperty('selection')) {
            columnDef.unshift(columnObjects.selection);
        }
        return columnDef;
    }
    isColDefOfType(_colDef, _type) {
        if (typeof _colDef.cellRendererParams !== 'undefined' &&
            typeof _colDef.cellRendererParams.params !== 'undefined' &&
            typeof _colDef.cellRendererParams.params[_type] !== 'undefined') {
            return true;
        }
        return false;
    }
    ////////////////////////////////////////////////////////
    /// Misc function
    ////////////////////////////////////////////////////////
    generateContextKey(_gridId, _columnId, _rowId) {
        return _gridId + this.CONTEXT_DELIMITER + _columnId + this.CONTEXT_DELIMITER + _rowId;
    }
    /********** End of protected functions / Start of private functions **********/
    ////////////////////////////////////////////////////////
    /// ColDef - Column definition functions
    ////////////////////////////////////////////////////////
    _generateColDefsFromColConfig(_columnConfig, _gridConfig, _suppressMovableColumns = true) {
        let columnDef = [];
        for (let i = 0; i < _columnConfig.length; i++) {
            let column = {};
            if (typeof _columnConfig[i] !== 'undefined') {
                let tempColumn = Object.assign(this._getDefaultColumnConfig(), _columnConfig[i]);
                tempColumn.suppressMovable = _suppressMovableColumns;
                switch (tempColumn.type) {
                    case 'input':
                        column = this._generateInputColDef(tempColumn, _gridConfig.id);
                        break;
                    case 'image':
                        column = this._generateImageColDef(tempColumn);
                        break;
                    default:
                        // TEMP fix for pivot
                        // value assignment instead of object direct assignment so to allow application to pass in other coldef
                        column = tempColumn;
                        column.headerName = tempColumn.headerName;
                        column.colId = tempColumn.field;
                        column.field = tempColumn.field;
                        column.cellClass = 'normal-cell ' + tempColumn.class;
                        column.hide = !tempColumn.visible;
                        column.suppressMenu = !tempColumn.filterable;
                        column.suppressSorting = !tempColumn.sortable;
                        column.minWidth = 100;
                        column.suppressMovable = tempColumn.suppressMovable;
                }
                if (tempColumn.filterable) {
                    this._updateFilterColDef(column, tempColumn.filterValue);
                }
            }
            columnDef.push(column);
        }
        return columnDef;
    }
    _generateColDefsFromConfig(_config) {
        let colDefObject = {};
        if (typeof _config !== 'undefined' &&
            typeof _config.action !== 'undefined' &&
            _config.action.enabled) {
            colDefObject.action = this._generateActionColDef(_config.id, _config.action.list, _config.action.name);
        }
        if (typeof _config !== 'undefined' &&
            typeof _config.selection !== 'undefined' &&
            typeof _config.selection.type !== 'undefined') {
            colDefObject.selection = this._generateCheckboxRadioColDef(_config.selection, _config.id);
        }
        return colDefObject;
    }
    ////////////////////////////////////////////////////////
    /// ColDef - Action dropdown functions
    ////////////////////////////////////////////////////////
    _generateActionColDef(_id, _list, _name) {
        return {
            headerName: (typeof _name !== 'undefined') ? _name : 'Action',
            suppressSorting: true,
            suppressFilter: true,
            suppressSizeToFit: true,
            suppressResize: true,
            suppressMenu: true,
            width: 120,
            minWidth: 120,
            maxWidth: 120,
            cellClass: 'dropdown-action',
            colId: 'ag-action',
            cellRendererFramework: KdTableAction,
            cellRendererParams: {
                params: _list,
                gridId: _id
            },
            suppressMovable: true
        };
    }
    ////////////////////////////////////////////////////////
    /// ColDef - Checkbox / Radio functions
    ////////////////////////////////////////////////////////
    _generateCheckboxRadioColDef(_selectionObj, _gridId) {
        /// Have to set the type any as setting as ColDef will has issues
        /// on headerComponentFramework type is wrongly used.
        let checkboxRadioDirection = this.direction === 'ltr' ? 'left' : 'right';
        let tempColDef = {
            suppressSorting: true,
            suppressFilter: true,
            suppressSizeToFit: true,
            suppressMenu: true,
            suppressResize: true,
            width: 50,
            minWidth: 50,
            maxWidth: 50,
            cellClass: 'ag-default ag-checkbox-radio',
            pinned: checkboxRadioDirection,
            colId: (_selectionObj.type === 'single') ? 'radio' : 'checkbox',
            cellRendererFramework: KdTableCheckboxRadio,
            cellRendererParams: {
                params: {
                    inputType: (_selectionObj.type === 'single') ? 'radio' : 'checkbox',
                    default: _selectionObj.value,
                    gridId: _gridId
                }
            },
            suppressMovable: true
        };
        if (_selectionObj.type === 'all') {
            tempColDef.headerComponentFramework = KdTableCheckboxRadio;
            tempColDef.headerComponentParams = {
                params: {
                    default: _selectionObj.value,
                    gridId: _gridId
                }
            };
        }
        return tempColDef;
    }
    ////////////////////////////////////////////////////////
    /// ColDef - Table Image functions
    ////////////////////////////////////////////////////////
    _generateImageColDef(_tempColumn) {
        let width = this.getImageSizeBy(_tempColumn, 'width');
        return {
            headerName: _tempColumn.headerName,
            field: _tempColumn.field,
            colId: _tempColumn.field,
            suppressSorting: true,
            suppressFilter: true,
            suppressMenu: true,
            suppressResize: true,
            hide: !_tempColumn.visible,
            minWidth: width,
            maxWidth: width,
            cellClass: _tempColumn.class,
            cellRendererFramework: KdTableImage,
            cellRendererParams: {
                params: {
                    [this.GIRD_PARAMS_KEY.image]: _tempColumn.config.image,
                }
            },
            suppressMovable: _tempColumn.suppressMovable
        };
    }
    ////////////////////////////////////////////////////////
    /// ColDef - Table Input functions
    ////////////////////////////////////////////////////////
    _generateInputColDef(_tempColumn, _gridId) {
        return {
            headerName: _tempColumn.headerName,
            field: _tempColumn.field,
            suppressSorting: true,
            suppressFilter: true,
            suppressMenu: true,
            minWidth: 250,
            hide: !_tempColumn.visible,
            cellClass: _tempColumn.class,
            colId: _tempColumn.field,
            cellRendererFramework: KdTableInput,
            cellRendererParams: {
                params: {
                    [this.GIRD_PARAMS_KEY.input]: _tempColumn.config,
                    gridId: _gridId,
                    contextKey: this.TABLE_INPUT_CONTEXT_KEY
                }
            },
            suppressMovable: _tempColumn.suppressMovable
        };
    }
    ////////////////////////////////////////////////////////
    /// API generation functions
    ////////////////////////////////////////////////////////
    _generateInputApi(_gridId, _kdTableIntEvent) {
        return {
            getProperty: (_tableParams) => {
                let eventString = this.generateContextKey(_gridId, _tableParams.colId, _tableParams.rowId);
                return this.gridOptions.context.tableIndexContext[eventString][_tableParams.questionKey][_tableParams.property];
            },
            setProperty: (_tableParams) => {
                let eventString = this.generateContextKey(_gridId, _tableParams.colId, _tableParams.rowId);
                if (typeof this.gridOptions.context.tableInputContext[eventString] !== 'undefined') {
                    this.gridOptions.context.tableInputContext[eventString][_tableParams.questionKey][_tableParams.property] = _tableParams.data;
                }
                let rowNode = this.gridOptions.api.getRowNode(_tableParams.rowId.toString());
                if (_tableParams.property === 'visible') {
                    rowNode.setRowHeight(undefined);
                    /// Issues - Calling this api onRowHeightChanged causing the current input cell to lose focus
                    this.gridOptions.api.onRowHeightChanged();
                }
                if (_tableParams.property === 'value') {
                    rowNode.data[_tableParams.colId][_tableParams.questionKey] = _tableParams.data;
                }
            }
        };
    }
    _generateGeneralApi(_row) {
        return {
            getCurrentRows: () => {
                return _row.slice();
            },
            resetRowHeight: () => {
                this.gridOptions.api.resetRowHeights();
            },
            setColumnVisible: (_colId, _visible) => {
                this.gridOptions.columnApi.setColumnVisible(_colId, _visible);
            }
        };
    }
    ////////////////////////////////////////////////////////
    /// Table Input functions
    ////////////////////////////////////////////////////////
    /**
     * [_generateTableInputContext
     *     Generate the input configurations and values to the context of the gridOptions.
     *     All input configurations will be stored in tableInputContext (gridOptions.context.tableInputContext)
     *     Structure is as follows:
     *         delimiter: ~
     *         contextKey: [gridId][delimiter][columnId][delimiter][rowId]
     *             (e.g. tableForm~inputColumn~1)
     *         question: {
     *             questionKey: question configurations,
     *             questionKey: question configurations
     *         }
     *             (e.g. {
     *                 inputKey: {
     *                     controlType: 'text',
     *                     key: 'inputKey',
     *                     visible: true,
     *                     disabled: false,
     *                     value: 'Text'
     *                 },
     *                 dropdownKey: {
     *                     controlType: 'dropdown',
     *                     key: 'dropdownKey',
     *                     visible: true,
     *                     value: '1',
     *                     options: [
     *                         {
     *                             key: '',
     *                             value: '-- Please select --'
     *                         },
     *                         {
     *                             key: '1',
     *                             value: 'Female'
     *                         },
     *                         {
     *                             key: '2',
     *                             value: 'Male'
     *                         }
     *                     ]
     *                 }
     *             })
     *
     *
     *         context.tableInputContext[contextKey] = question
     * ]
     * _column    : [Column configurations]
     * _row       : [Row data]
     * _gridId    : [Grid ID]
     */
    _generateTableInputContext(_column, _row, _gridId) {
        let tableInputContext = {};
        for (let i = 0; i < _column.length; ++i) {
            if (this.isInputType(_column[i], 'input')) {
                let currentColumn = _column[i];
                let currentColumnId = currentColumn.field;
                for (let j = 0; j < _row.length; ++j) {
                    if (typeof _row[j][this.rowKey] !== 'undefined') {
                        let contextObject = {};
                        // console.log('-------------------------------------------');
                        // console.log('currentColumn - ', currentColumn);
                        // console.log('currentColumnId - ', currentColumnId);
                        // console.log('_row[j] - ', _row[j]);
                        // Set the row data with the column key if is not defined
                        if (typeof _row[j][currentColumnId] === 'undefined') {
                            _row[j][currentColumnId] = {};
                        }
                        // Set the input to the contextObject
                        if (typeof currentColumn.config !== 'undefined' && typeof currentColumn.config.input !== 'undefined') {
                            let processInputData = (currentColumn.config.input instanceof Array) ? currentColumn.config.input : [currentColumn.config.input];
                            let rowColumnData = _row[j][currentColumnId];
                            for (let k = 0; k < processInputData.length; ++k) {
                                // Set the row data input key value if no input key of the column is defined
                                if (typeof rowColumnData[processInputData[k].key] === 'undefined') {
                                    rowColumnData[processInputData[k].key] = '';
                                }
                                contextObject[processInputData[k].key] = Object.assign({}, processInputData[k]);
                                contextObject[processInputData[k].key].value = rowColumnData[processInputData[k].key];
                            }
                        }
                        else {
                            console.error('KdTable error - Column specify as input but no config passed in. No input will be generated.');
                        }
                        let contextKey = this.generateContextKey(_gridId, currentColumnId, _row[j][this.rowKey]);
                        tableInputContext[contextKey] = Object.assign({}, contextObject);
                    }
                    else {
                        console.error('KdTable error - Row passed in with no rowKey (' + this.rowKey + '). Input cell component requires rowKey to generate.');
                    }
                }
            }
        }
        return tableInputContext;
    }
    ////////////////////////////////////////////////////////
    /// Selection function - Return value functions
    ////////////////////////////////////////////////////////
    /**
     * [_convertDataValueToObject - Convert return from dot separated to object value. Example:
     *     - From: "instutition_id.instutition_name": "Anderson Primary School";
     *     - To  : instutition_id: {
     *                 instutition_name:"Anderson Primary School"
     *             };
     * ]
     * _currentItem    : [Current selection key]
     * _objKey         : [Dot separated object keys]
     * _value          : [Data value for the object]
     *
     */
    _convertDataValueToObject(_currentItem, _objKey, _value, _separator = '.') {
        let objectKeyArr = _objKey.split(_separator);
        return this._appendDataValueKey(objectKeyArr, _currentItem, _value);
    }
    _appendDataValueKey(_key, _currentObj, _value) {
        if (_key.length > 0) {
            let currentKey = _key[0];
            if (typeof _currentObj[currentKey] === 'undefined') {
                _currentObj[currentKey] = {};
            }
            _key.shift();
            _currentObj[currentKey] = this._appendDataValueKey(_key, _currentObj[currentKey], _value);
        }
        else {
            _currentObj = _value;
        }
        return _currentObj;
    }
    ////////////////////////////////////////////////////////
    /// Misc functions
    ////////////////////////////////////////////////////////
    _updateFilterColDef(_colDef, _filterVal) {
        _colDef.menuTabs = ['filterMenuTab'];
        _colDef.filter = 'agSetColumnFilter';
        _colDef.filterParams = {
            newRowsAction: 'keep',
            cellHeight: 30,
            selectAllOnMiniFilter: true
        };
        if (typeof _filterVal !== 'undefined') {
            _colDef.filterParams.values = _filterVal;
        }
    }
    _getDefaultColumnConfig() {
        return {
            sortable: false,
            filterable: false,
            visible: true,
        };
    }
}
KdTableSvcBase.decorators = [
    { type: Injectable }
];
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoia2QtdGFibGUtc3ZjLmpzIiwic291cmNlUm9vdCI6IkM6L3hhbXBwL2h0ZG9jcy9TdHlsZWd1aWRlL2lvc3RnLW9wZW5lbWlzLXN0eWxlZ3VpZGUvcHJvamVjdHMvb3BlbmVtaXMtc3R5bGVndWlkZS1saWIvc3JjLyIsInNvdXJjZXMiOlsia2QtY29tcG9uZW50cy9rZC1hbmd1bGFyLXRhYmxlL3RhYmxlLXNlcnZpY2VzL2tkLXRhYmxlLXN2Yy50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQSxPQUFPLEVBQUUsVUFBVSxFQUFFLE1BQU0sZUFBZSxDQUFDO0FBbUIzQyxPQUFPLEVBQUUsYUFBYSxFQUFFLE1BQU0scUNBQXFDLENBQUM7QUFDcEUsT0FBTyxFQUFFLG9CQUFvQixFQUFFLE1BQU0sNkNBQTZDLENBQUM7QUFDbkYsT0FBTyxFQUFFLFlBQVksRUFBRSxNQUFNLG9DQUFvQyxDQUFDO0FBQ2xFLE9BQU8sRUFBRSxZQUFZLEVBQUUsTUFBTSxvQ0FBb0MsQ0FBQztBQUlsRSxPQUFPLEVBQUUsU0FBUyxFQUFFLE1BQU0sdUJBQXVCLENBQUM7QUFFbEQ7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztHQXNERztBQUdILE1BQU0sT0FBZ0IsY0FBYztJQURwQztRQUVJLDhFQUE4RTtRQUNyRSxlQUFVLEdBQVcsR0FBRyxDQUFDO1FBQ3pCLHNCQUFpQixHQUFXLEdBQUcsQ0FBQztRQUNoQyw0QkFBdUIsR0FBVyxtQkFBbUIsQ0FBQztRQUN0RCxxQkFBZ0IsR0FBVyxFQUFFLENBQUM7UUFDOUIsa0JBQWEsR0FBVyxFQUFFLENBQUM7UUFDM0IsbUJBQWMsR0FBVyxlQUFlLENBQUM7UUFDekMsb0JBQWUsR0FBOEI7WUFDbEQsS0FBSyxFQUFFLGFBQWE7WUFDcEIsS0FBSyxFQUFFLGFBQWE7U0FDdkIsQ0FBQztRQUVRLFlBQU8sR0FBYyxJQUFJLFNBQVMsRUFBRSxDQUFDO1FBR3JDLFdBQU0sR0FBVyxJQUFJLENBQUM7UUErckJoQywrRUFBK0U7SUFDbkYsQ0FBQztJQTlyQkcsOEVBQThFO0lBQzlFLHdEQUF3RDtJQUN4RCxzQkFBc0I7SUFDdEIsd0RBQXdEO0lBQ2pELFVBQVUsQ0FBQyxZQUF5QjtRQUN2QyxJQUFJLE9BQU8sWUFBWSxLQUFLLFdBQVc7WUFDbkMsWUFBWSxLQUFLLElBQUk7WUFDckIsT0FBTyxZQUFZLENBQUMsR0FBRyxLQUFLLFdBQVcsRUFBRTtZQUN6QyxPQUFPLElBQUksQ0FBQztTQUNmO1FBQ0QsT0FBTyxLQUFLLENBQUM7SUFDakIsQ0FBQztJQUVNLGVBQWUsQ0FBQyxXQUF5QjtRQUM1QyxJQUFJLE9BQU8sV0FBVyxLQUFLLFdBQVc7WUFDbEMsT0FBTyxXQUFXLENBQUMsU0FBUyxLQUFLLFdBQVc7WUFDNUMsT0FBTyxXQUFXLENBQUMsU0FBUyxDQUFDLElBQUksS0FBSyxXQUFXO1lBQ2pELFdBQVcsQ0FBQyxTQUFTLENBQUMsSUFBSSxLQUFLLEtBQUs7WUFDcEMsV0FBVyxDQUFDLFFBQVEsS0FBSyxVQUFVLEVBQUU7WUFDckMsT0FBTyxJQUFJLENBQUM7U0FDZjtRQUVELE9BQU8sS0FBSyxDQUFDO0lBQ2pCLENBQUM7SUFFTSxZQUFZLENBQUMsWUFBaUMsRUFBRSxLQUFhO1FBQ2hFLElBQUksT0FBTyxZQUFZLEtBQUssV0FBVyxFQUFFO1lBQ3JDLEtBQUssSUFBSSxDQUFDLEdBQVcsQ0FBQyxFQUFFLENBQUMsR0FBRyxZQUFZLENBQUMsTUFBTSxFQUFFLEVBQUUsQ0FBQyxFQUFFO2dCQUNsRCxJQUFJLElBQUksQ0FBQyxXQUFXLENBQUMsWUFBWSxDQUFDLENBQUMsQ0FBQyxFQUFFLEtBQUssQ0FBQyxFQUFFO29CQUMxQyxPQUFPLElBQUksQ0FBQztpQkFDZjthQUNKO1NBQ0o7UUFFRCxPQUFPLEtBQUssQ0FBQztJQUNqQixDQUFDO0lBRU0sV0FBVyxDQUFDLE9BQXFCLEVBQUUsS0FBYTtRQUNuRCxPQUFPLENBQUMsT0FBTyxPQUFPLENBQUMsSUFBSSxLQUFLLFdBQVcsSUFBSSxPQUFPLENBQUMsSUFBSSxLQUFLLEtBQUssQ0FBQyxDQUFDO0lBQzNFLENBQUM7SUFFTSxpQkFBaUIsQ0FBQyxTQUFpQjtRQUN0QyxPQUFPLENBQUMsU0FBUyxLQUFLLFNBQVMsSUFBSSxTQUFTLEtBQUssVUFBVSxJQUFJLFNBQVMsS0FBSyxRQUFRLENBQUMsQ0FBQztJQUMzRixDQUFDO0lBRUQsd0RBQXdEO0lBQ3hELHVCQUF1QjtJQUN2Qix3REFBd0Q7SUFDakQsd0JBQXdCLENBQUMsV0FBeUI7UUFDckQsSUFBSSxPQUFPLFdBQVcsQ0FBQyxTQUFTLEtBQUssV0FBVyxFQUFFO1lBQzlDLElBQUksT0FBTyxXQUFXLENBQUMsU0FBUyxDQUFDLEtBQUssS0FBSyxXQUFXLEVBQUU7Z0JBQ3BELFdBQVcsQ0FBQyxTQUFTLENBQUMsS0FBSyxHQUFHLEVBQUUsQ0FBQzthQUNwQztpQkFDSSxJQUFJLFdBQVcsQ0FBQyxTQUFTLENBQUMsSUFBSSxLQUFLLFFBQVEsSUFBSSxXQUFXLENBQUMsU0FBUyxDQUFDLEtBQUssQ0FBQyxNQUFNLEdBQUcsQ0FBQyxFQUFFO2dCQUN4RixPQUFPLENBQUMsSUFBSSxDQUFDLDZFQUE2RSxDQUFDLENBQUM7Z0JBQzVGLFdBQVcsQ0FBQyxTQUFTLENBQUMsS0FBSyxHQUFHLFdBQVcsQ0FBQyxTQUFTLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUM7YUFDekU7U0FDSjtJQUNMLENBQUM7SUFFRDs7Ozs7Ozs7Ozs7T0FXRztJQUNJLHFCQUFxQixDQUFDLFFBQW9CLEVBQUUsWUFBb0MsRUFBRSxVQUF5QixFQUFFLFNBQWtCO1FBQ2xJLElBQUksT0FBTyxVQUFVLEtBQUssV0FBVztZQUNqQyxVQUFVLEtBQUssSUFBSTtZQUNuQixVQUFVLENBQUMsTUFBTSxLQUFLLENBQUMsRUFBRTtZQUN6QixPQUFPLFlBQVksQ0FBQztTQUN2QjtRQUVELElBQUksa0JBQWtCLEdBQWUsRUFBRSxDQUFDO1FBRXhDLEtBQUssSUFBSSxDQUFDLEdBQVcsQ0FBQyxFQUFFLENBQUMsR0FBRyxRQUFRLENBQUMsTUFBTSxFQUFFLENBQUMsRUFBRSxFQUFFO1lBQzlDLElBQUksUUFBUSxHQUFRLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQztZQUNoQyxJQUFJLE9BQU8sR0FBUSxFQUFFLENBQUM7WUFFdEIsSUFBSSxZQUFZLENBQUMsT0FBTyxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsRUFBRTtnQkFDbEQsT0FBTyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsR0FBRyxRQUFRLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDO2dCQUU3QyxLQUFLLElBQUksQ0FBQyxHQUFXLENBQUMsRUFBRSxDQUFDLEdBQUcsVUFBVSxDQUFDLE1BQU0sRUFBRSxDQUFDLEVBQUUsRUFBRTtvQkFDaEQsSUFBSSxRQUFRLENBQUMsY0FBYyxDQUFDLFVBQVUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFO3dCQUN4QyxPQUFPLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsUUFBUSxDQUFDLFVBQVUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO3FCQUNwRDt5QkFDSSxJQUFJLFVBQVUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxFQUFFO3dCQUNyQyxJQUFJLFNBQVMsR0FBUSxJQUFJLENBQUMsT0FBTyxDQUFDLFlBQVksQ0FBQyxRQUFRLEVBQUUsVUFBVSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7d0JBRXhFLElBQUksU0FBUyxLQUFLLElBQUksRUFBRTs0QkFDcEIsSUFBSSxPQUFPLEdBQWMsTUFBTyxDQUFDLE1BQU0sQ0FBQyxFQUFFLEVBQUUsT0FBTyxDQUFDLENBQUM7NEJBQ3JELE9BQU8sR0FBRyxJQUFJLENBQUMseUJBQXlCLENBQUMsT0FBTyxFQUFFLFVBQVUsQ0FBQyxDQUFDLENBQUMsRUFBRSxTQUFTLENBQUMsQ0FBQzt5QkFDL0U7cUJBQ0o7aUJBQ0o7Z0JBRUQsa0JBQWtCLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxDQUFDO2FBQ3BDO1NBQ0o7UUFFRCxPQUFPLGtCQUFrQixDQUFDO0lBQzlCLENBQUM7SUFFRCx3REFBd0Q7SUFDeEQseUJBQXlCO0lBQ3pCLHdEQUF3RDtJQUNqRCxpQkFBaUIsQ0FBQyxXQUF5QjtRQUM5QyxJQUFJLE9BQU8sV0FBVyxDQUFDLE1BQU0sS0FBSyxXQUFXLEVBQUU7WUFDM0MsV0FBVyxDQUFDLE1BQU0sR0FBRyxFQUFFLENBQUM7U0FDM0I7YUFDSSxJQUFJLFdBQVcsQ0FBQyxNQUFNLENBQUMsTUFBTSxHQUFHLENBQUMsRUFBRTtZQUNwQyxPQUFPLENBQUMsSUFBSSxDQUFDLHlEQUF5RCxDQUFDLENBQUM7WUFDeEUsV0FBVyxDQUFDLE1BQU0sR0FBRyxXQUFXLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUM7U0FDdkQ7SUFDTCxDQUFDO0lBRUQsd0RBQXdEO0lBQ3hELHlCQUF5QjtJQUN6Qix3REFBd0Q7SUFDakQsdUJBQXVCLENBQUMsUUFBb0IsRUFBRSxhQUFrQyxFQUFFLE9BQWUsRUFBRSxZQUF5QjtRQUMvSCxJQUFJLElBQUksQ0FBQyxZQUFZLENBQUMsYUFBYSxFQUFFLE9BQU8sQ0FBQyxFQUFFO1lBQzNDLElBQUksT0FBTyxZQUFZLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyx1QkFBdUIsQ0FBQyxLQUFLLFdBQVcsRUFBRTtnQkFDM0UsWUFBWSxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsdUJBQXVCLENBQUMsR0FBRyxFQUFFLENBQUM7YUFDM0Q7WUFFRCxJQUFJLFlBQVksR0FBUSxJQUFJLENBQUMsMEJBQTBCLENBQUMsYUFBYSxFQUFFLFFBQVEsRUFBRSxPQUFPLENBQUMsQ0FBQztZQUMxRixZQUFZLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyx1QkFBdUIsQ0FBQyxHQUFTLE1BQU8sQ0FBQyxNQUFNLENBQUMsWUFBWSxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsdUJBQXVCLENBQUMsRUFBRSxZQUFZLENBQUMsQ0FBQztTQUMvSTtJQUNMLENBQUM7SUFFRCx3REFBd0Q7SUFDeEQsMkJBQTJCO0lBQzNCLHdEQUF3RDtJQUNqRCxxQkFBcUIsQ0FBQyxRQUFtQixFQUFFLFVBQWU7UUFDN0QsUUFBUSxDQUFDLFdBQVcsR0FBRyxJQUFJLENBQUMsaUJBQWlCLENBQUMsVUFBVSxDQUFDLEVBQUUsRUFBRSxVQUFVLENBQUMsS0FBSyxDQUFDLENBQUM7UUFDL0UsUUFBUSxDQUFDLE9BQU8sR0FBRyxJQUFJLENBQUMsbUJBQW1CLENBQUMsVUFBVSxDQUFDLElBQUksQ0FBQyxDQUFDO0lBQ2pFLENBQUM7SUFFRCx3REFBd0Q7SUFDeEQsaUJBQWlCO0lBQ2pCLHdEQUF3RDtJQUNqRCxTQUFTLENBQUMsV0FBeUI7UUFDdEMsSUFBSSxPQUFPLFdBQVcsQ0FBQyxFQUFFLEtBQUssV0FBVyxFQUFFO1lBQ3ZDLFdBQVcsQ0FBQyxFQUFFLEdBQUcsSUFBSSxDQUFDLGNBQWMsQ0FBQztTQUN4QztRQUVELE9BQU8sV0FBVyxDQUFDLEVBQUUsQ0FBQztJQUMxQixDQUFDO0lBRU0sY0FBYyxDQUFDLFlBQTBCLEVBQUUsVUFBOEI7UUFDNUUseUNBQXlDO1FBQ3pDLElBQUksS0FBSyxHQUFXLEdBQUcsR0FBRyxJQUFJLENBQUMsYUFBYSxDQUFDO1FBRTdDLElBQUksT0FBTyxZQUFZLENBQUMsTUFBTSxLQUFLLFdBQVc7WUFDMUMsT0FBTyxZQUFZLENBQUMsTUFBTSxDQUFDLEtBQUssS0FBSyxXQUFXO1lBQ2hELE9BQU8sWUFBWSxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsVUFBVSxDQUFDLEtBQUssV0FBVyxFQUFFO1lBQzlELEtBQUssR0FBRyxZQUFZLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxVQUFVLENBQUMsR0FBRyxJQUFJLENBQUMsYUFBYSxDQUFDO1NBQ3RFO1FBRUQsT0FBTyxLQUFLLENBQUM7SUFDakIsQ0FBQztJQUVNLGtCQUFrQjtRQUNyQixPQUFPLElBQUksQ0FBQyx1QkFBdUIsQ0FBQztJQUN4QyxDQUFDO0lBRU0sd0JBQXdCLENBQUMsUUFBaUIsRUFBRSxLQUFhO1FBQzVELE9BQU8sSUFBSSxDQUFDLE9BQU8sQ0FBQyxjQUFjLENBQUMsUUFBUSxDQUFDLElBQUksRUFBRSxLQUFLLENBQUMsQ0FBQztJQUM3RCxDQUFDO0lBRU0sU0FBUyxDQUFDLE9BQVksRUFBRSxXQUFtQjtRQUM5QyxJQUFJLFNBQVMsR0FBVyxHQUFHLENBQUM7UUFFNUIsSUFBSSxjQUFjLEdBQVEsSUFBSSxDQUFDLE9BQU8sQ0FBQyxDQUFDO1FBQ3hDLElBQUksVUFBVSxHQUFVLEVBQUUsQ0FBQztRQUUzQixLQUFLLElBQUksTUFBTSxHQUFHLENBQUMsRUFBRSxNQUFNLEdBQUcsY0FBYyxDQUFDLE1BQU0sRUFBRSxNQUFNLElBQUksU0FBUyxFQUFFO1lBQ3RFLElBQUksS0FBSyxHQUFRLGNBQWMsQ0FBQyxLQUFLLENBQUMsTUFBTSxFQUFFLE1BQU0sR0FBRyxTQUFTLENBQUMsQ0FBQztZQUVsRSxJQUFJLFdBQVcsR0FBVSxJQUFJLEtBQUssQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLENBQUM7WUFDakQsS0FBSyxJQUFJLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxHQUFHLEtBQUssQ0FBQyxNQUFNLEVBQUUsQ0FBQyxFQUFFLEVBQUU7Z0JBQ25DLFdBQVcsQ0FBQyxDQUFDLENBQUMsR0FBRyxLQUFLLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQyxDQUFDO2FBQ3hDO1lBRUQsSUFBSSxTQUFTLEdBQWUsSUFBSSxVQUFVLENBQUMsV0FBVyxDQUFDLENBQUM7WUFFeEQsVUFBVSxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsQ0FBQztTQUM5QjtRQUVELElBQUksSUFBSSxHQUFTLElBQUksSUFBSSxDQUFDLFVBQVUsRUFBRSxFQUFFLElBQUksRUFBRSxXQUFXLEVBQUUsQ0FBQyxDQUFDO1FBQzdELE9BQU8sSUFBSSxDQUFDO0lBQ2hCLENBQUM7SUFFRCw4RUFBOEU7SUFDOUUsd0RBQXdEO0lBQ3hELDBCQUEwQjtJQUMxQix3REFBd0Q7SUFDOUMscUJBQXFCLENBQUMsVUFBeUIsRUFBRSxVQUFrQjtRQUN6RSxJQUFJLENBQUMsU0FBUyxHQUFHLFVBQVUsQ0FBQztRQUU1QixPQUFPO1lBQ0gsT0FBTyxFQUFFLEVBQUU7WUFDWCxVQUFVLEVBQUUsRUFBRTtZQUNkLFNBQVMsRUFBRSxVQUFVLEtBQUssS0FBSztZQUUvQixZQUFZLEVBQUUsRUFBRTtZQUNoQixTQUFTLEVBQUUsQ0FBQyxPQUFPLFVBQVUsS0FBSyxXQUFXLENBQUMsQ0FBQyxDQUFDLENBQUMsVUFBVSxHQUFHLEVBQUUsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLFVBQVU7WUFFbEYsZ0NBQWdDO1lBQ2hDLDZCQUE2QixFQUFFLElBQUk7WUFDbkMsZUFBZSxFQUFFLElBQUk7WUFFckIsbUJBQW1CLEVBQUUsSUFBSTtZQUN6QixnQkFBZ0IsRUFBRSxJQUFJO1lBQ3RCLGNBQWMsRUFBRSxJQUFJO1lBRXBCLDBCQUEwQixFQUFFLElBQUk7WUFFaEMsc0NBQXNDO1lBRXRDLFdBQVcsRUFBRSxLQUFLO1lBQ2xCLFNBQVMsRUFBRSxDQUFDO1lBRVosWUFBWSxFQUFFLENBQUMsS0FBVSxFQUFVLEVBQUU7Z0JBQ2pDLElBQUksRUFBRSxHQUFXLEtBQUssQ0FBQyxFQUFFLENBQUM7Z0JBRTFCLElBQUksT0FBTyxLQUFLLENBQUMsRUFBRSxLQUFLLFFBQVEsRUFBRTtvQkFDOUIsRUFBRSxHQUFHLEVBQUUsQ0FBQyxRQUFRLEVBQUUsQ0FBQztpQkFDdEI7Z0JBRUQsT0FBTyxFQUFFLENBQUM7WUFDZCxDQUFDO1lBRUQsVUFBVSxFQUFFLElBQUk7WUFDaEIsS0FBSyxFQUFFO2dCQUNILE1BQU0sRUFBRSwyQkFBMkI7Z0JBQ25DLGFBQWEsRUFBRSwrQkFBK0I7Z0JBQzlDLGNBQWMsRUFBRSw2QkFBNkI7Z0JBQzdDLFVBQVUsRUFBRSx5QkFBeUI7Z0JBQ3JDLG9EQUFvRDtnQkFDcEQscURBQXFEO2dCQUNyRCxhQUFhLEVBQUUsK0JBQStCO2dCQUM5QyxlQUFlLEVBQUUsZ0NBQWdDO2dCQUVqRCxJQUFJLEVBQUUseUJBQXlCO2FBQ2xDO1lBQ0Qsa0JBQWtCLEVBQUU7Z0JBQ2hCLEtBQUssRUFBRTtvQkFDSCxJQUFJLEVBQUUsNkNBQTZDO2lCQUN0RDthQUNKO1lBQ0QsT0FBTyxFQUFFLEVBQUU7WUFDWCxxQkFBcUIsRUFBRSw4R0FBOEc7U0FDeEksQ0FBQztJQUNOLENBQUM7SUFFRCx3REFBd0Q7SUFDeEQsK0JBQStCO0lBQy9CLHdEQUF3RDtJQUM5Qyx5QkFBeUIsQ0FBQyxhQUFrQyxFQUFFLFdBQXlCLEVBQUUsMEJBQWtDLElBQUk7UUFDckksSUFBSSxTQUFTLEdBQWtCLElBQUksQ0FBQyw2QkFBNkIsQ0FBQyxhQUFhLEVBQUUsV0FBVyxFQUFFLHVCQUF1QixDQUFDLENBQUM7UUFDdkgsSUFBSSxhQUFhLEdBQThCLElBQUksQ0FBQywwQkFBMEIsQ0FBQyxXQUFXLENBQUMsQ0FBQztRQUU1RixJQUFJLGFBQWEsQ0FBQyxjQUFjLENBQUMsUUFBUSxDQUFDLEVBQUU7WUFDeEMsU0FBUyxDQUFDLElBQUksQ0FBQyxhQUFhLENBQUMsTUFBTSxDQUFDLENBQUM7U0FDeEM7UUFFRCxJQUFJLGFBQWEsQ0FBQyxjQUFjLENBQUMsV0FBVyxDQUFDLEVBQUU7WUFDM0MsU0FBUyxDQUFDLE9BQU8sQ0FBQyxhQUFhLENBQUMsU0FBUyxDQUFDLENBQUM7U0FDOUM7UUFFRCxPQUFPLFNBQVMsQ0FBQztJQUNyQixDQUFDO0lBRVMsY0FBYyxDQUFDLE9BQWUsRUFBRSxLQUFhO1FBQ25ELElBQUksT0FBTyxPQUFPLENBQUMsa0JBQWtCLEtBQUssV0FBVztZQUNqRCxPQUFPLE9BQU8sQ0FBQyxrQkFBa0IsQ0FBQyxNQUFNLEtBQUssV0FBVztZQUN4RCxPQUFPLE9BQU8sQ0FBQyxrQkFBa0IsQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLEtBQUssV0FBVyxFQUFFO1lBQ2pFLE9BQU8sSUFBSSxDQUFDO1NBQ2Y7UUFFRCxPQUFPLEtBQUssQ0FBQztJQUNqQixDQUFDO0lBRUQsd0RBQXdEO0lBQ3hELGlCQUFpQjtJQUNqQix3REFBd0Q7SUFDOUMsa0JBQWtCLENBQUMsT0FBZSxFQUFFLFNBQWlCLEVBQUUsTUFBdUI7UUFDcEYsT0FBTyxPQUFPLEdBQUcsSUFBSSxDQUFDLGlCQUFpQixHQUFHLFNBQVMsR0FBRyxJQUFJLENBQUMsaUJBQWlCLEdBQUcsTUFBTSxDQUFDO0lBQzFGLENBQUM7SUFFRCwrRUFBK0U7SUFDL0Usd0RBQXdEO0lBQ3hELHdDQUF3QztJQUN4Qyx3REFBd0Q7SUFDaEQsNkJBQTZCLENBQUMsYUFBa0MsRUFBRSxXQUF5QixFQUFFLDBCQUFtQyxJQUFJO1FBQ3hJLElBQUksU0FBUyxHQUFrQixFQUFFLENBQUM7UUFFbEMsS0FBSyxJQUFJLENBQUMsR0FBVyxDQUFDLEVBQUUsQ0FBQyxHQUFHLGFBQWEsQ0FBQyxNQUFNLEVBQUUsQ0FBQyxFQUFFLEVBQUU7WUFDbkQsSUFBSSxNQUFNLEdBQVcsRUFBRSxDQUFDO1lBRXhCLElBQUksT0FBTyxhQUFhLENBQUMsQ0FBQyxDQUFDLEtBQUssV0FBVyxFQUFFO2dCQUN6QyxJQUFJLFVBQVUsR0FBdUIsTUFBTyxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsdUJBQXVCLEVBQUUsRUFBRSxhQUFhLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztnQkFDdEcsVUFBVSxDQUFDLGVBQWUsR0FBRyx1QkFBdUIsQ0FBQztnQkFFckQsUUFBUSxVQUFVLENBQUMsSUFBSSxFQUFFO29CQUNyQixLQUFLLE9BQU87d0JBQ1IsTUFBTSxHQUFHLElBQUksQ0FBQyxvQkFBb0IsQ0FBQyxVQUFVLEVBQUUsV0FBVyxDQUFDLEVBQUUsQ0FBQyxDQUFDO3dCQUMvRCxNQUFNO29CQUNWLEtBQUssT0FBTzt3QkFDUixNQUFNLEdBQUcsSUFBSSxDQUFDLG9CQUFvQixDQUFDLFVBQVUsQ0FBQyxDQUFDO3dCQUMvQyxNQUFNO29CQUNWO3dCQUNJLHFCQUFxQjt3QkFDckIsdUdBQXVHO3dCQUN2RyxNQUFNLEdBQUcsVUFBVSxDQUFDO3dCQUNwQixNQUFNLENBQUMsVUFBVSxHQUFHLFVBQVUsQ0FBQyxVQUFVLENBQUM7d0JBQzFDLE1BQU0sQ0FBQyxLQUFLLEdBQUcsVUFBVSxDQUFDLEtBQUssQ0FBQzt3QkFDaEMsTUFBTSxDQUFDLEtBQUssR0FBRyxVQUFVLENBQUMsS0FBSyxDQUFDO3dCQUNoQyxNQUFNLENBQUMsU0FBUyxHQUFHLGNBQWMsR0FBRyxVQUFVLENBQUMsS0FBSyxDQUFDO3dCQUNyRCxNQUFNLENBQUMsSUFBSSxHQUFHLENBQUMsVUFBVSxDQUFDLE9BQU8sQ0FBQzt3QkFDbEMsTUFBTSxDQUFDLFlBQVksR0FBRyxDQUFDLFVBQVUsQ0FBQyxVQUFVLENBQUM7d0JBQzdDLE1BQU0sQ0FBQyxlQUFlLEdBQUcsQ0FBQyxVQUFVLENBQUMsUUFBUSxDQUFDO3dCQUM5QyxNQUFNLENBQUMsUUFBUSxHQUFHLEdBQUcsQ0FBQzt3QkFDdEIsTUFBTSxDQUFDLGVBQWUsR0FBRyxVQUFVLENBQUMsZUFBZSxDQUFDO2lCQUMzRDtnQkFFRCxJQUFJLFVBQVUsQ0FBQyxVQUFVLEVBQUU7b0JBQ3ZCLElBQUksQ0FBQyxtQkFBbUIsQ0FBQyxNQUFNLEVBQUUsVUFBVSxDQUFDLFdBQVcsQ0FBQyxDQUFDO2lCQUM1RDthQUNKO1lBQ0QsU0FBUyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQztTQUMxQjtRQUVELE9BQU8sU0FBUyxDQUFDO0lBQ3JCLENBQUM7SUFFTywwQkFBMEIsQ0FBQyxPQUFxQjtRQUNwRCxJQUFJLFlBQVksR0FBOEIsRUFBRSxDQUFDO1FBRWpELElBQUksT0FBTyxPQUFPLEtBQUssV0FBVztZQUM5QixPQUFPLE9BQU8sQ0FBQyxNQUFNLEtBQUssV0FBVztZQUNyQyxPQUFPLENBQUMsTUFBTSxDQUFDLE9BQU8sRUFBRTtZQUN4QixZQUFZLENBQUMsTUFBTSxHQUFHLElBQUksQ0FBQyxxQkFBcUIsQ0FBQyxPQUFPLENBQUMsRUFBRSxFQUFFLE9BQU8sQ0FBQyxNQUFNLENBQUMsSUFBSSxFQUFFLE9BQU8sQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLENBQUM7U0FDMUc7UUFFRCxJQUFJLE9BQU8sT0FBTyxLQUFLLFdBQVc7WUFDOUIsT0FBTyxPQUFPLENBQUMsU0FBUyxLQUFLLFdBQVc7WUFDeEMsT0FBTyxPQUFPLENBQUMsU0FBUyxDQUFDLElBQUksS0FBSyxXQUFXLEVBQUU7WUFDL0MsWUFBWSxDQUFDLFNBQVMsR0FBRyxJQUFJLENBQUMsNEJBQTRCLENBQUMsT0FBTyxDQUFDLFNBQVMsRUFBRSxPQUFPLENBQUMsRUFBRSxDQUFDLENBQUM7U0FDN0Y7UUFFRCxPQUFPLFlBQVksQ0FBQztJQUN4QixDQUFDO0lBRUQsd0RBQXdEO0lBQ3hELHNDQUFzQztJQUN0Qyx3REFBd0Q7SUFDaEQscUJBQXFCLENBQUMsR0FBVyxFQUFFLEtBQWtDLEVBQUUsS0FBYztRQUN6RixPQUFPO1lBQ0gsVUFBVSxFQUFFLENBQUMsT0FBTyxLQUFLLEtBQUssV0FBVyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsUUFBUTtZQUM3RCxlQUFlLEVBQUUsSUFBSTtZQUNyQixjQUFjLEVBQUUsSUFBSTtZQUNwQixpQkFBaUIsRUFBRSxJQUFJO1lBQ3ZCLGNBQWMsRUFBRSxJQUFJO1lBQ3BCLFlBQVksRUFBRSxJQUFJO1lBQ2xCLEtBQUssRUFBRSxHQUFHO1lBQ1YsUUFBUSxFQUFFLEdBQUc7WUFDYixRQUFRLEVBQUUsR0FBRztZQUNiLFNBQVMsRUFBRSxpQkFBaUI7WUFDNUIsS0FBSyxFQUFFLFdBQVc7WUFDbEIscUJBQXFCLEVBQUUsYUFBYTtZQUNwQyxrQkFBa0IsRUFBRTtnQkFDaEIsTUFBTSxFQUFFLEtBQUs7Z0JBQ2IsTUFBTSxFQUFFLEdBQUc7YUFDZDtZQUNELGVBQWUsRUFBRSxJQUFJO1NBQ3hCLENBQUM7SUFDTixDQUFDO0lBRUQsd0RBQXdEO0lBQ3hELHVDQUF1QztJQUN2Qyx3REFBd0Q7SUFDaEQsNEJBQTRCLENBQUMsYUFBa0IsRUFBRSxPQUFlO1FBQ3BFLGlFQUFpRTtRQUNqRSxxREFBcUQ7UUFFckQsSUFBSSxzQkFBc0IsR0FBVyxJQUFJLENBQUMsU0FBUyxLQUFLLEtBQUssQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUM7UUFFakYsSUFBSSxVQUFVLEdBQVE7WUFDbEIsZUFBZSxFQUFFLElBQUk7WUFDckIsY0FBYyxFQUFFLElBQUk7WUFDcEIsaUJBQWlCLEVBQUUsSUFBSTtZQUN2QixZQUFZLEVBQUUsSUFBSTtZQUNsQixjQUFjLEVBQUUsSUFBSTtZQUNwQixLQUFLLEVBQUUsRUFBRTtZQUNULFFBQVEsRUFBRSxFQUFFO1lBQ1osUUFBUSxFQUFFLEVBQUU7WUFDWixTQUFTLEVBQUUsOEJBQThCO1lBQ3pDLE1BQU0sRUFBRSxzQkFBc0I7WUFDOUIsS0FBSyxFQUFFLENBQUMsYUFBYSxDQUFDLElBQUksS0FBSyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxVQUFVO1lBQy9ELHFCQUFxQixFQUFFLG9CQUFvQjtZQUMzQyxrQkFBa0IsRUFBRTtnQkFDaEIsTUFBTSxFQUFFO29CQUNKLFNBQVMsRUFBRSxDQUFDLGFBQWEsQ0FBQyxJQUFJLEtBQUssUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsVUFBVTtvQkFDbkUsT0FBTyxFQUFFLGFBQWEsQ0FBQyxLQUFLO29CQUM1QixNQUFNLEVBQUUsT0FBTztpQkFDbEI7YUFDSjtZQUNELGVBQWUsRUFBRSxJQUFJO1NBQ3hCLENBQUM7UUFFRixJQUFJLGFBQWEsQ0FBQyxJQUFJLEtBQUssS0FBSyxFQUFFO1lBQzlCLFVBQVUsQ0FBQyx3QkFBd0IsR0FBRyxvQkFBb0IsQ0FBQztZQUMzRCxVQUFVLENBQUMscUJBQXFCLEdBQUc7Z0JBQy9CLE1BQU0sRUFBRTtvQkFDSixPQUFPLEVBQUUsYUFBYSxDQUFDLEtBQUs7b0JBQzVCLE1BQU0sRUFBRSxPQUFPO2lCQUNsQjthQUNKLENBQUM7U0FDTDtRQUVELE9BQU8sVUFBVSxDQUFDO0lBQ3RCLENBQUM7SUFFRCx3REFBd0Q7SUFDeEQsa0NBQWtDO0lBQ2xDLHdEQUF3RDtJQUNoRCxvQkFBb0IsQ0FBQyxXQUF5QjtRQUNsRCxJQUFJLEtBQUssR0FBVyxJQUFJLENBQUMsY0FBYyxDQUFDLFdBQVcsRUFBRSxPQUFPLENBQUMsQ0FBQztRQUU5RCxPQUFPO1lBQ0gsVUFBVSxFQUFFLFdBQVcsQ0FBQyxVQUFVO1lBQ2xDLEtBQUssRUFBRSxXQUFXLENBQUMsS0FBSztZQUN4QixLQUFLLEVBQUUsV0FBVyxDQUFDLEtBQUs7WUFDeEIsZUFBZSxFQUFFLElBQUk7WUFDckIsY0FBYyxFQUFFLElBQUk7WUFDcEIsWUFBWSxFQUFFLElBQUk7WUFDbEIsY0FBYyxFQUFFLElBQUk7WUFDcEIsSUFBSSxFQUFFLENBQUMsV0FBVyxDQUFDLE9BQU87WUFDMUIsUUFBUSxFQUFFLEtBQUs7WUFDZixRQUFRLEVBQUUsS0FBSztZQUNmLFNBQVMsRUFBRSxXQUFXLENBQUMsS0FBSztZQUM1QixxQkFBcUIsRUFBRSxZQUFZO1lBQ25DLGtCQUFrQixFQUFFO2dCQUNoQixNQUFNLEVBQUU7b0JBQ0osQ0FBQyxJQUFJLENBQUMsZUFBZSxDQUFDLEtBQUssQ0FBQyxFQUFFLFdBQVcsQ0FBQyxNQUFNLENBQUMsS0FBSztpQkFDekQ7YUFDSjtZQUNELGVBQWUsRUFBRSxXQUFXLENBQUMsZUFBZTtTQUMvQyxDQUFDO0lBQ04sQ0FBQztJQUVELHdEQUF3RDtJQUN4RCxrQ0FBa0M7SUFDbEMsd0RBQXdEO0lBQ2hELG9CQUFvQixDQUFDLFdBQXlCLEVBQUUsT0FBZTtRQUNuRSxPQUFPO1lBQ0gsVUFBVSxFQUFFLFdBQVcsQ0FBQyxVQUFVO1lBQ2xDLEtBQUssRUFBRSxXQUFXLENBQUMsS0FBSztZQUN4QixlQUFlLEVBQUUsSUFBSTtZQUNyQixjQUFjLEVBQUUsSUFBSTtZQUNwQixZQUFZLEVBQUUsSUFBSTtZQUNsQixRQUFRLEVBQUUsR0FBRztZQUNiLElBQUksRUFBRSxDQUFDLFdBQVcsQ0FBQyxPQUFPO1lBQzFCLFNBQVMsRUFBRSxXQUFXLENBQUMsS0FBSztZQUM1QixLQUFLLEVBQUUsV0FBVyxDQUFDLEtBQUs7WUFDeEIscUJBQXFCLEVBQUUsWUFBWTtZQUNuQyxrQkFBa0IsRUFBRTtnQkFDaEIsTUFBTSxFQUFFO29CQUNKLENBQUMsSUFBSSxDQUFDLGVBQWUsQ0FBQyxLQUFLLENBQUMsRUFBRSxXQUFXLENBQUMsTUFBTTtvQkFDaEQsTUFBTSxFQUFFLE9BQU87b0JBQ2YsVUFBVSxFQUFFLElBQUksQ0FBQyx1QkFBdUI7aUJBQzNDO2FBQ0o7WUFDRCxlQUFlLEVBQUUsV0FBVyxDQUFDLGVBQWU7U0FDL0MsQ0FBQztJQUNOLENBQUM7SUFFRCx3REFBd0Q7SUFDeEQsNEJBQTRCO0lBQzVCLHdEQUF3RDtJQUNoRCxpQkFBaUIsQ0FBQyxPQUFlLEVBQUUsZ0JBQWlDO1FBQ3hFLE9BQU87WUFDSCxXQUFXLEVBQUUsQ0FBQyxZQUFvQyxFQUFPLEVBQUU7Z0JBQ3ZELElBQUksV0FBVyxHQUFHLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxPQUFPLEVBQUUsWUFBWSxDQUFDLEtBQUssRUFBRSxZQUFZLENBQUMsS0FBSyxDQUFDLENBQUM7Z0JBQzNGLE9BQU8sSUFBSSxDQUFDLFdBQVcsQ0FBQyxPQUFPLENBQUMsaUJBQWlCLENBQUMsV0FBVyxDQUFDLENBQUMsWUFBWSxDQUFDLFdBQVcsQ0FBQyxDQUFDLFlBQVksQ0FBQyxRQUFRLENBQUMsQ0FBQztZQUNwSCxDQUFDO1lBQ0QsV0FBVyxFQUFFLENBQUMsWUFBb0MsRUFBUSxFQUFFO2dCQUN4RCxJQUFJLFdBQVcsR0FBRyxJQUFJLENBQUMsa0JBQWtCLENBQUMsT0FBTyxFQUFFLFlBQVksQ0FBQyxLQUFLLEVBQUUsWUFBWSxDQUFDLEtBQUssQ0FBQyxDQUFDO2dCQUUzRixJQUFJLE9BQU8sSUFBSSxDQUFDLFdBQVcsQ0FBQyxPQUFPLENBQUMsaUJBQWlCLENBQUMsV0FBVyxDQUFDLEtBQUssV0FBVyxFQUFFO29CQUNoRixJQUFJLENBQUMsV0FBVyxDQUFDLE9BQU8sQ0FBQyxpQkFBaUIsQ0FBQyxXQUFXLENBQUMsQ0FBQyxZQUFZLENBQUMsV0FBVyxDQUFDLENBQUMsWUFBWSxDQUFDLFFBQVEsQ0FBQyxHQUFHLFlBQVksQ0FBQyxJQUFJLENBQUM7aUJBQ2hJO2dCQUVELElBQUksT0FBTyxHQUFZLElBQUksQ0FBQyxXQUFXLENBQUMsR0FBRyxDQUFDLFVBQVUsQ0FBQyxZQUFZLENBQUMsS0FBSyxDQUFDLFFBQVEsRUFBRSxDQUFDLENBQUM7Z0JBRXRGLElBQUksWUFBWSxDQUFDLFFBQVEsS0FBSyxTQUFTLEVBQUU7b0JBQ3JDLE9BQU8sQ0FBQyxZQUFZLENBQUMsU0FBUyxDQUFDLENBQUM7b0JBQ2hDLDZGQUE2RjtvQkFDN0YsSUFBSSxDQUFDLFdBQVcsQ0FBQyxHQUFHLENBQUMsa0JBQWtCLEVBQUUsQ0FBQztpQkFDN0M7Z0JBRUQsSUFBSSxZQUFZLENBQUMsUUFBUSxLQUFLLE9BQU8sRUFBRTtvQkFDbkMsT0FBTyxDQUFDLElBQUksQ0FBQyxZQUFZLENBQUMsS0FBSyxDQUFDLENBQUMsWUFBWSxDQUFDLFdBQVcsQ0FBQyxHQUFHLFlBQVksQ0FBQyxJQUFJLENBQUM7aUJBQ2xGO1lBQ0wsQ0FBQztTQUNKLENBQUM7SUFDTixDQUFDO0lBRU8sbUJBQW1CLENBQUMsSUFBZ0I7UUFDeEMsT0FBTztZQUNILGNBQWMsRUFBRSxHQUFlLEVBQUU7Z0JBQzdCLE9BQU8sSUFBSSxDQUFDLEtBQUssRUFBRSxDQUFDO1lBQ3hCLENBQUM7WUFFRCxjQUFjLEVBQUUsR0FBUyxFQUFFO2dCQUN2QixJQUFJLENBQUMsV0FBVyxDQUFDLEdBQUcsQ0FBQyxlQUFlLEVBQUUsQ0FBQztZQUMzQyxDQUFDO1lBRUQsZ0JBQWdCLEVBQUUsQ0FBQyxNQUFjLEVBQUUsUUFBaUIsRUFBUSxFQUFFO2dCQUMxRCxJQUFJLENBQUMsV0FBVyxDQUFDLFNBQVMsQ0FBQyxnQkFBZ0IsQ0FBQyxNQUFNLEVBQUUsUUFBUSxDQUFDLENBQUM7WUFDbEUsQ0FBQztTQUNKLENBQUM7SUFDTixDQUFDO0lBRUQsd0RBQXdEO0lBQ3hELHlCQUF5QjtJQUN6Qix3REFBd0Q7SUFDeEQ7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztPQWdERztJQUNLLDBCQUEwQixDQUFDLE9BQTRCLEVBQUUsSUFBZ0IsRUFBRSxPQUFlO1FBQzlGLElBQUksaUJBQWlCLEdBQVEsRUFBRSxDQUFDO1FBRWhDLEtBQUssSUFBSSxDQUFDLEdBQVcsQ0FBQyxFQUFFLENBQUMsR0FBRyxPQUFPLENBQUMsTUFBTSxFQUFFLEVBQUUsQ0FBQyxFQUFFO1lBQzdDLElBQUksSUFBSSxDQUFDLFdBQVcsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLEVBQUUsT0FBTyxDQUFDLEVBQUU7Z0JBQ3ZDLElBQUksYUFBYSxHQUFpQixPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUM7Z0JBQzdDLElBQUksZUFBZSxHQUFXLGFBQWEsQ0FBQyxLQUFLLENBQUM7Z0JBRWxELEtBQUssSUFBSSxDQUFDLEdBQVcsQ0FBQyxFQUFFLENBQUMsR0FBRyxJQUFJLENBQUMsTUFBTSxFQUFFLEVBQUUsQ0FBQyxFQUFFO29CQUMxQyxJQUFJLE9BQU8sSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsS0FBSyxXQUFXLEVBQUU7d0JBQzdDLElBQUksYUFBYSxHQUFRLEVBQUUsQ0FBQzt3QkFFNUIsOERBQThEO3dCQUM5RCxrREFBa0Q7d0JBQ2xELHNEQUFzRDt3QkFDdEQsc0NBQXNDO3dCQUV0Qyx5REFBeUQ7d0JBQ3pELElBQUksT0FBTyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsZUFBZSxDQUFDLEtBQUssV0FBVyxFQUFFOzRCQUNqRCxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsZUFBZSxDQUFDLEdBQUcsRUFBRSxDQUFDO3lCQUNqQzt3QkFFRCxxQ0FBcUM7d0JBQ3JDLElBQUksT0FBTyxhQUFhLENBQUMsTUFBTSxLQUFLLFdBQVcsSUFBSSxPQUFPLGFBQWEsQ0FBQyxNQUFNLENBQUMsS0FBSyxLQUFLLFdBQVcsRUFBRTs0QkFDbEcsSUFBSSxnQkFBZ0IsR0FBMkIsQ0FBQyxhQUFhLENBQUMsTUFBTSxDQUFDLEtBQUssWUFBWSxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsYUFBYSxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsYUFBYSxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsQ0FBQzs0QkFDekosSUFBSSxhQUFhLEdBQVEsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLGVBQWUsQ0FBQyxDQUFDOzRCQUVsRCxLQUFLLElBQUksQ0FBQyxHQUFXLENBQUMsRUFBRSxDQUFDLEdBQUcsZ0JBQWdCLENBQUMsTUFBTSxFQUFFLEVBQUUsQ0FBQyxFQUFFO2dDQUN0RCw0RUFBNEU7Z0NBQzVFLElBQUksT0FBTyxhQUFhLENBQUMsZ0JBQWdCLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLEtBQUssV0FBVyxFQUFFO29DQUMvRCxhQUFhLENBQUMsZ0JBQWdCLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLEdBQUcsRUFBRSxDQUFDO2lDQUMvQztnQ0FFRCxhQUFhLENBQUMsZ0JBQWdCLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLEdBQVMsTUFBTyxDQUFDLE1BQU0sQ0FBQyxFQUFFLEVBQUUsZ0JBQWdCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztnQ0FDdkYsYUFBYSxDQUFDLGdCQUFnQixDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLEtBQUssR0FBRyxhQUFhLENBQUMsZ0JBQWdCLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUM7NkJBQ3pGO3lCQUNKOzZCQUNJOzRCQUNELE9BQU8sQ0FBQyxLQUFLLENBQUMsOEZBQThGLENBQUMsQ0FBQzt5QkFDakg7d0JBRUQsSUFBSSxVQUFVLEdBQVcsSUFBSSxDQUFDLGtCQUFrQixDQUFDLE9BQU8sRUFBRSxlQUFlLEVBQUUsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDO3dCQUNqRyxpQkFBaUIsQ0FBQyxVQUFVLENBQUMsR0FBUyxNQUFPLENBQUMsTUFBTSxDQUFDLEVBQUUsRUFBRSxhQUFhLENBQUMsQ0FBQztxQkFDM0U7eUJBQ0k7d0JBQ0QsT0FBTyxDQUFDLEtBQUssQ0FBQyxnREFBZ0QsR0FBRyxJQUFJLENBQUMsTUFBTSxHQUFHLHNEQUFzRCxDQUFDLENBQUM7cUJBQzFJO2lCQUNKO2FBQ0o7U0FDSjtRQUVELE9BQU8saUJBQWlCLENBQUM7SUFDN0IsQ0FBQztJQUVELHdEQUF3RDtJQUN4RCwrQ0FBK0M7SUFDL0Msd0RBQXdEO0lBQ3hEOzs7Ozs7Ozs7OztPQVdHO0lBQ0sseUJBQXlCLENBQUMsWUFBaUIsRUFBRSxPQUFlLEVBQUUsTUFBVyxFQUFFLGFBQXFCLEdBQUc7UUFDdkcsSUFBSSxZQUFZLEdBQWtCLE9BQU8sQ0FBQyxLQUFLLENBQUMsVUFBVSxDQUFDLENBQUM7UUFDNUQsT0FBTyxJQUFJLENBQUMsbUJBQW1CLENBQUMsWUFBWSxFQUFFLFlBQVksRUFBRSxNQUFNLENBQUMsQ0FBQztJQUN4RSxDQUFDO0lBRU8sbUJBQW1CLENBQUMsSUFBbUIsRUFBRSxXQUFnQixFQUFFLE1BQVc7UUFDMUUsSUFBSSxJQUFJLENBQUMsTUFBTSxHQUFHLENBQUMsRUFBRTtZQUNqQixJQUFJLFVBQVUsR0FBVyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUM7WUFFakMsSUFBSSxPQUFPLFdBQVcsQ0FBQyxVQUFVLENBQUMsS0FBSyxXQUFXLEVBQUU7Z0JBQ2hELFdBQVcsQ0FBQyxVQUFVLENBQUMsR0FBRyxFQUFFLENBQUM7YUFDaEM7WUFFRCxJQUFJLENBQUMsS0FBSyxFQUFFLENBQUM7WUFDYixXQUFXLENBQUMsVUFBVSxDQUFDLEdBQUcsSUFBSSxDQUFDLG1CQUFtQixDQUFDLElBQUksRUFBRSxXQUFXLENBQUMsVUFBVSxDQUFDLEVBQUUsTUFBTSxDQUFDLENBQUM7U0FDN0Y7YUFDSTtZQUNELFdBQVcsR0FBRyxNQUFNLENBQUM7U0FDeEI7UUFFRCxPQUFPLFdBQVcsQ0FBQztJQUN2QixDQUFDO0lBRUQsd0RBQXdEO0lBQ3hELGtCQUFrQjtJQUNsQix3REFBd0Q7SUFDaEQsbUJBQW1CLENBQUMsT0FBZSxFQUFFLFVBQTBCO1FBQ25FLE9BQU8sQ0FBQyxRQUFRLEdBQUcsQ0FBQyxlQUFlLENBQUMsQ0FBQztRQUNyQyxPQUFPLENBQUMsTUFBTSxHQUFHLG1CQUFtQixDQUFDO1FBQ3JDLE9BQU8sQ0FBQyxZQUFZLEdBQUc7WUFDbkIsYUFBYSxFQUFFLE1BQU07WUFDckIsVUFBVSxFQUFFLEVBQUU7WUFDZCxxQkFBcUIsRUFBRSxJQUFJO1NBQzlCLENBQUM7UUFFRixJQUFJLE9BQU8sVUFBVSxLQUFLLFdBQVcsRUFBRTtZQUNuQyxPQUFPLENBQUMsWUFBWSxDQUFDLE1BQU0sR0FBRyxVQUFVLENBQUM7U0FDNUM7SUFDTCxDQUFDO0lBRU8sdUJBQXVCO1FBQzNCLE9BQU87WUFDSCxRQUFRLEVBQUUsS0FBSztZQUNmLFVBQVUsRUFBRSxLQUFLO1lBQ2pCLE9BQU8sRUFBRSxJQUFJO1NBQ2hCLENBQUM7SUFDTixDQUFDOzs7WUE5c0JKLFVBQVUiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBJbmplY3RhYmxlIH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XHJcbmltcG9ydCB7XHJcbiAgICBHcmlkT3B0aW9ucyxcclxuICAgIENvbERlZixcclxuICAgIFJvd05vZGVcclxufSBmcm9tICdhZy1ncmlkLWNvbW11bml0eSc7XHJcblxyXG5pbXBvcnQge1xyXG4gICAgSVRhYmxlQ29sdW1uLFxyXG4gICAgSVRhYmxlQ29uZmlnLFxyXG4gICAgSVRhYmxlRm9ybUlucHV0LFxyXG4gICAgSVRhYmxlQXBpLFxyXG4gICAgSVRhYmxlRHluYW1pY0Zvcm1BcGksXHJcbiAgICBJVGFibGVHZW5lcmFsQXBpLFxyXG5cclxuICAgIElUYWJsZURyb3Bkb3duQWN0aW9uLFxyXG4gICAgSVRhYmxlRm9ybVVwZGF0ZVBhcmFtc1xyXG59IGZyb20gJy4uL2tkLWFuZ3VsYXItdGFibGUtaW50ZXJmYWNlJztcclxuXHJcbmltcG9ydCB7IEtkVGFibGVBY3Rpb24gfSBmcm9tICcuLi90YWJsZS1jb21wb25lbnRzL2tkLXRhYmxlLWFjdGlvbic7XHJcbmltcG9ydCB7IEtkVGFibGVDaGVja2JveFJhZGlvIH0gZnJvbSAnLi4vdGFibGUtY29tcG9uZW50cy9rZC10YWJsZS1jaGVja2JveC1yYWRpbyc7XHJcbmltcG9ydCB7IEtkVGFibGVJbnB1dCB9IGZyb20gJy4uL3RhYmxlLWNvbXBvbmVudHMva2QtdGFibGUtaW5wdXQnO1xyXG5pbXBvcnQgeyBLZFRhYmxlSW1hZ2UgfSBmcm9tICcuLi90YWJsZS1jb21wb25lbnRzL2tkLXRhYmxlLWltYWdlJztcclxuXHJcblxyXG5pbXBvcnQgeyBLZEludFRhYmxlRXZlbnQgfSBmcm9tICcuLi9rZC1hbmd1bGFyLXRhYmxlLWV2ZW50JztcclxuaW1wb3J0IHsgS2REYXRhU3ZjIH0gZnJvbSAnLi4vLi4va2QtY29tbW9uL2luZGV4JztcclxuXHJcbi8qKlxyXG4gKiAtLSBEb2N1bWVudGF0aW9uIGZvciBrZC10YWJsZS1zdmMudHNcclxuICpcclxuICogLSBQdWJsaWMgZnVuY3Rpb25zIChVc2FibGUgYnkgYm90aCBleHRlbmRlZCBzZXJ2aWNlcyk6XHJcbiAqICAgICAtIENoZWNraW5nIGZ1bmN0aW9uc1xyXG4gKiAgICAgICAgIC0gaXNBcGlSZWFkeVxyXG4gKiAgICAgICAgIC0gaGFzU2VsZWN0aW9uQWxsXHJcbiAqICAgICAgICAgLSBoYXNJbnB1dFR5cGVcclxuICogICAgICAgICAtIGlzSW5wdXRUeXBlXHJcbiAqICAgICAgICAgLSBpc0VudGVycHJpc2VNb2RlbFxyXG4gKiAgICAgLSBVcGRhdGUgZnVuY3Rpb25zXHJcbiAqICAgICAgICAgLSB1cGRhdGVTZWxlY3REZWZhdWx0VmFsdWVcclxuICogICAgICAgICAtIHVwZGF0ZVNlbGVjdGlvblZhbHVlc1xyXG4gKiAgICAgICAgIC0gdXBkYXRlR3JpZEJ1dHRvbnNcclxuICogICAgICAgICAtIHVwZGF0ZVJvd0RhdGFXaXRoQ29sdW1uIChHZW5lcmF0aW9ucyBvZiBpbnB1dCBjb250ZXh0IGluIGdyaWRPcHRpb25zLmNvbnRleHQgaWYgaW5wdXQgZXhpc3QpXHJcbiAqICAgICAgICAgLSBnZW5lcmF0ZWRBcGlGdW5jdGlvbnMgKEdlbmVyYXRpb24gb2YgQVBJcylcclxuICogICAgIC0gTWlzYyBmdW5jdGlvblxyXG4gKiAgICAgICAgIC0gZ2V0R3JpZElkXHJcbiAqICAgICAgICAgLSBnZXRJbWFnZVNpemVCeVxyXG4gKiAgICAgICAgIC0gZ2V0VGFibGVDb250ZXh0S2V5XHJcbiAqICAgICAgICAgLSBnZXRSb3V0ZXJQbGFjZWhvbGRlclBhdGggKEZvciBwYXRoTWFwIG9mIGNsaWNrIHR5cGUgcm91dGVyKVxyXG4gKiAgICAgICAgIC0gYjY0dG9CbG9iXHJcbiAqXHJcbiAqIC0gUHJvdGVjdGVkIGZ1bmN0aW9uOlxyXG4gKiAgICAgLSBHcmlkIE9wdGlvbnMgZnVuY3Rpb25cclxuICogICAgICAgICAtIGdldERlZmF1bHRHcmlkT3B0aW9uc1xyXG4gKiAgICAgLSBDb2x1bW4gZGVmaW5pdGlvbiBmdW5jdGlvbnNcclxuICogICAgICAgICAtIGdlbmVyYXRlQ29sdW1uRGVmaW5pdGlvbnNcclxuICogICAgICAgICAtIGlzQ29sRGVmT2ZUeXBlXHJcbiAqICAgICAtIEFQSSBnZW5lcmF0aW9uIGZ1bmN0aW9uXHJcbiAqICAgICAtIE1pc2MgZnVuY3Rpb25zXHJcbiAqICAgICAgICAgLSBnZW5lcmF0ZUdyaWRJZFxyXG4gKiAgICAgICAgIC0gZ2VuZXJhdGVDb250ZXh0S2V5XHJcbiAqICAgICAgICAgLSBnZXRJbWFnZVNpemVCeVxyXG4gKlxyXG4gKiAtIFByaXZhdGUgZnVuY3Rpb25zOlxyXG4gKiAgICAgLSBDb2x1bW4gZGVmaW5pdGlvbiBmdW5jdGlvbnNcclxuICogICAgICAgICAtIF9nZW5lcmF0ZUNvbERlZnNGcm9tQ29sQ29uZmlnIChDb2xEZWYgZ2VuZXJhdGlvbiBiYXNlZCBvbiBjb2x1bW4gY29uZmlnIC0gY2hlY2tzIG5vcm1hbCBjb2x1bW5zLCBpbnB1dCBjb2x1bW4gYW5kIGltYWdlIGNvbHVtbnMpXHJcbiAqICAgICAgICAgLSBfZ2VuZXJhdGVDb2xEZWZzRnJvbUNvbmZpZyAoQ29sRGVmIGdlbmVyYXRpb24gYmFzZWQgb24gZ3JpZCBjb25maWcgLSBjaGVja3MgYWN0aW9uIGNvbHVtbiBhbmQgc2VsZWN0aW9uIGNvbHVtbilcclxuICogICAgICAgICAtIF9nZW5lcmF0ZUFjdGlvbkNvbERlZiAoQWN0aW9uKVxyXG4gKiAgICAgICAgIC0gX2dlbmVyYXRlQ2hlY2tib3hSYWRpb0NvbERlZiAoU2VsZWN0aW9uKVxyXG4gKiAgICAgICAgIC0gX2dlbmVyYXRlSW1hZ2VDb2xEZWYgKEltYWdlKVxyXG4gKiAgICAgICAgIC0gX2dlbmVyYXRlSW5wdXRDb2xEZWYgKElucHV0KVxyXG4gKiAgICAgLSBBUEkgZ2VuZXJhdGlvbiBmdW5jdGlvbnNcclxuICogICAgICAgICAtIF9nZW5lcmF0ZUlucHV0QXBpIChhcGkuZHluYW1pY0Zvcm1zKVxyXG4gKiAgICAgICAgIC0gX2dlbmVyYXRlR2VuZXJhbEFwaSAoYXBpLmdlbmVyYWwpXHJcbiAqICAgICAtIFRhYmxlIGlucHV0IGZ1bmN0aW9uc1xyXG4gKiAgICAgICAgIC0gX2dlbmVyYXRlVGFibGVJbnB1dENvbnRleHQgKExvb3AgYWxsIGNvbHVtbnMgYW5kIHJvd3MgYW5kIGVhY2ggb2YgdGhlIHF1ZXN0aW9uIHRvIGdlbmVyYXRlIHRoZSBjb250ZXh0IGZvciBpbnB1dCBjb2x1bW5zKVxyXG4gKiAgICAgLSBTZWxlY3Rpb24gZnVuY3Rpb25zXHJcbiAqICAgICAgICAgLSBfY29udmVydERhdGFWYWx1ZVRvT2JqZWN0IChzZXQgdG8gb2JqZWN0IGlmIGNvbmZpZyBjb25zaXN0IG9mIHJldHVybiBrZXlzKVxyXG4gKiAgICAgICAgIC0gX2FwcGVuZERhdGFWYWx1ZUtleVxyXG4gKiAgICAgLSBNaXNjIGZ1bmN0aW9uc1xyXG4gKiAgICAgICAgIC0gX3VwZGF0ZUZpbHRlckNvbERlZlxyXG4gKiAgICAgICAgIC0gX2dldERlZmF1bHRDb2x1bW5Db25maWdcclxuICovXHJcblxyXG5ASW5qZWN0YWJsZSgpXHJcbmV4cG9ydCBhYnN0cmFjdCBjbGFzcyBLZFRhYmxlU3ZjQmFzZSB7XHJcbiAgICAvKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKiogVmFyaWFibGVzICoqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKi9cclxuICAgIHJlYWRvbmx5IFJPV19IRUlHSFQ6IG51bWJlciA9IDE1MDtcclxuICAgIHJlYWRvbmx5IENPTlRFWFRfREVMSU1JVEVSOiBzdHJpbmcgPSAnfic7XHJcbiAgICByZWFkb25seSBUQUJMRV9JTlBVVF9DT05URVhUX0tFWTogc3RyaW5nID0gJ3RhYmxlSW5wdXRDb250ZXh0JztcclxuICAgIHJlYWRvbmx5IERFRkFVTFRfUEFHRVNJWkU6IG51bWJlciA9IDI1O1xyXG4gICAgcmVhZG9ubHkgSU1BR0VfUEFERElORzogbnVtYmVyID0gMjA7XHJcbiAgICByZWFkb25seSBERUZBVUxUX0dSSURJRDogc3RyaW5nID0gJ2tkLXRhYmxlLWdyaWQnO1xyXG4gICAgcmVhZG9ubHkgR0lSRF9QQVJBTVNfS0VZOiB7IFtrZXk6IHN0cmluZ106IHN0cmluZyB9ID0ge1xyXG4gICAgICAgIGlucHV0OiAnaW5wdXRDb25maWcnLFxyXG4gICAgICAgIGltYWdlOiAnaW1hZ2VDb25maWcnXHJcbiAgICB9O1xyXG5cclxuICAgIHByb3RlY3RlZCBkYXRhU3ZjOiBLZERhdGFTdmMgPSBuZXcgS2REYXRhU3ZjKCk7XHJcbiAgICBwcm90ZWN0ZWQgZ3JpZE9wdGlvbnM6IEdyaWRPcHRpb25zO1xyXG4gICAgcHJvdGVjdGVkIGRpcmVjdGlvbjogJ2x0cicgfCAncnRsJztcclxuICAgIHByb3RlY3RlZCByb3dLZXk6IHN0cmluZyA9ICdpZCc7XHJcblxyXG4gICAgLyoqKioqKioqKioqKioqKiBQdWJsaWMgZnVuY3Rpb25zIChzaGFyZWQgZm9yIGJvdGggc2VydmljZXMpICoqKioqKioqKioqKioqKiovXHJcbiAgICAvLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vL1xyXG4gICAgLy8vIENoZWNraW5nIGZ1bmN0aW9uc1xyXG4gICAgLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy9cclxuICAgIHB1YmxpYyBpc0FwaVJlYWR5KF9ncmlkT3B0aW9uczogR3JpZE9wdGlvbnMpOiBib29sZWFuIHtcclxuICAgICAgICBpZiAodHlwZW9mIF9ncmlkT3B0aW9ucyAhPT0gJ3VuZGVmaW5lZCcgJiZcclxuICAgICAgICAgICAgX2dyaWRPcHRpb25zICE9PSBudWxsICYmXHJcbiAgICAgICAgICAgIHR5cGVvZiBfZ3JpZE9wdGlvbnMuYXBpICE9PSAndW5kZWZpbmVkJykge1xyXG4gICAgICAgICAgICByZXR1cm4gdHJ1ZTtcclxuICAgICAgICB9XHJcbiAgICAgICAgcmV0dXJuIGZhbHNlO1xyXG4gICAgfVxyXG5cclxuICAgIHB1YmxpYyBoYXNTZWxlY3Rpb25BbGwoX2dyaWRDb25maWc6IElUYWJsZUNvbmZpZyk6IGJvb2xlYW4ge1xyXG4gICAgICAgIGlmICh0eXBlb2YgX2dyaWRDb25maWcgIT09ICd1bmRlZmluZWQnICYmXHJcbiAgICAgICAgICAgIHR5cGVvZiBfZ3JpZENvbmZpZy5zZWxlY3Rpb24gIT09ICd1bmRlZmluZWQnICYmXHJcbiAgICAgICAgICAgIHR5cGVvZiBfZ3JpZENvbmZpZy5zZWxlY3Rpb24udHlwZSAhPT0gJ3VuZGVmaW5lZCcgJiZcclxuICAgICAgICAgICAgX2dyaWRDb25maWcuc2VsZWN0aW9uLnR5cGUgPT09ICdhbGwnICYmXHJcbiAgICAgICAgICAgIF9ncmlkQ29uZmlnLmxvYWRUeXBlICE9PSAnaW5maW5pdGUnKSB7XHJcbiAgICAgICAgICAgIHJldHVybiB0cnVlO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgcmV0dXJuIGZhbHNlO1xyXG4gICAgfVxyXG5cclxuICAgIHB1YmxpYyBoYXNJbnB1dFR5cGUoX3RhYmxlQ29sdW1uOiBBcnJheTxJVGFibGVDb2x1bW4+LCBfdHlwZTogc3RyaW5nKTogYm9vbGVhbiB7XHJcbiAgICAgICAgaWYgKHR5cGVvZiBfdGFibGVDb2x1bW4gIT09ICd1bmRlZmluZWQnKSB7XHJcbiAgICAgICAgICAgIGZvciAobGV0IGk6IG51bWJlciA9IDA7IGkgPCBfdGFibGVDb2x1bW4ubGVuZ3RoOyArK2kpIHtcclxuICAgICAgICAgICAgICAgIGlmICh0aGlzLmlzSW5wdXRUeXBlKF90YWJsZUNvbHVtbltpXSwgX3R5cGUpKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIHRydWU7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIHJldHVybiBmYWxzZTtcclxuICAgIH1cclxuXHJcbiAgICBwdWJsaWMgaXNJbnB1dFR5cGUoX2NvbHVtbjogSVRhYmxlQ29sdW1uLCBfdHlwZTogc3RyaW5nKTogYm9vbGVhbiB7XHJcbiAgICAgICAgcmV0dXJuICh0eXBlb2YgX2NvbHVtbi50eXBlICE9PSAndW5kZWZpbmVkJyAmJiBfY29sdW1uLnR5cGUgPT09IF90eXBlKTtcclxuICAgIH1cclxuXHJcbiAgICBwdWJsaWMgaXNFbnRlcnByaXNlTW9kZWwoX2xvYWRUeXBlOiBzdHJpbmcpOiBib29sZWFuIHtcclxuICAgICAgICByZXR1cm4gKF9sb2FkVHlwZSA9PT0gJ29uZXNob3QnIHx8IF9sb2FkVHlwZSA9PT0gJ2luZmluaXRlJyB8fCBfbG9hZFR5cGUgPT09ICdzZXJ2ZXInKTtcclxuICAgIH1cclxuXHJcbiAgICAvLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vL1xyXG4gICAgLy8vIFNlbGVjdGlvbiBmdW5jdGlvbnNcclxuICAgIC8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vXHJcbiAgICBwdWJsaWMgdXBkYXRlU2VsZWN0RGVmYXVsdFZhbHVlKF9ncmlkQ29uZmlnOiBJVGFibGVDb25maWcpOiB2b2lkIHtcclxuICAgICAgICBpZiAodHlwZW9mIF9ncmlkQ29uZmlnLnNlbGVjdGlvbiAhPT0gJ3VuZGVmaW5lZCcpIHtcclxuICAgICAgICAgICAgaWYgKHR5cGVvZiBfZ3JpZENvbmZpZy5zZWxlY3Rpb24udmFsdWUgPT09ICd1bmRlZmluZWQnKSB7XHJcbiAgICAgICAgICAgICAgICBfZ3JpZENvbmZpZy5zZWxlY3Rpb24udmFsdWUgPSBbXTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBlbHNlIGlmIChfZ3JpZENvbmZpZy5zZWxlY3Rpb24udHlwZSA9PT0gJ3NpbmdsZScgJiYgX2dyaWRDb25maWcuc2VsZWN0aW9uLnZhbHVlLmxlbmd0aCA+IDEpIHtcclxuICAgICAgICAgICAgICAgIGNvbnNvbGUud2FybignS2RUYWJsZSB3YXJuaW5nOiBTaW5nbGUgc2VsZWN0aW9uIHR5cGUgY29udGFpbnMgbW9yZSB0aGFuIDEgZGVmYXVsdCB2YWx1ZXMuJyk7XHJcbiAgICAgICAgICAgICAgICBfZ3JpZENvbmZpZy5zZWxlY3Rpb24udmFsdWUgPSBfZ3JpZENvbmZpZy5zZWxlY3Rpb24udmFsdWUuc2xpY2UoMCwgMSk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgLyoqXHJcbiAgICAgKiBbdXBkYXRlU2VsZWN0aW9uVmFsdWVzKCkgLSBSZXR1cm5zIHRoZSBzZWxlY3RlZCBub2RlcyBiYXNlZCBvbiB0aGUgcmV0dXJuS2V5IHNwZWNpZnkuXHJcbiAgICAgKiAgSWYgaXMgbm90IHNwZWNpZnksIGFycmF5IG9mIGlkcyB3aWxsIGJlIHJldHVybiBvbiBzZWxlY3Rpb24uXHJcbiAgICAgKiAgT25seSB3b3JrcyBmb3Igbm9ybWFsLCBpbmZpbml0ZSBhbmQgb25lc2hvdCBsb2FkVHlwZS5cclxuICAgICAqICAgICAtIE5vdCBzcGVjaWZ5IC0gUmV0dXJuIFsgMSwgMiwgMyBdO1xyXG4gICAgICogICAgIC0gU3BlY2lmeSAgICAgLSBSZXR1cm4gWyB7aWQ6IDEsIGdyYWRlOiBcIjFcIiB9LCB7aWQ6IDIsIGdyYWRlOiBcIjFcIn0sIHtpZDogMywgZ3JhZGU6IFwiMlwifV1cclxuICAgICAqIF1cclxuICAgICAqIF9yb3dEYXRhICAgICAgIDogW0N1cnJlbnQgcHJvdmlkZWQgcm93RGF0YV1cclxuICAgICAqIF9zZWxlY3RlZElkcyAgIDogW0N1cnJlbnQgc2VsZWN0ZWQgcm93RGF0YSBpZHNdXHJcbiAgICAgKiBfcmV0dXJuS2V5ICAgICA6IFtMaXN0IG9mIHByb3BlcnR5IGtleXMgdG8gcmV0dXJuIHdpdGggaWRdXHJcbiAgICAgKiBbR2VuZXJhdGVkIHNlbGVjdGlvbiBieSByZXR1cm5LZXldXHJcbiAgICAgKi9cclxuICAgIHB1YmxpYyB1cGRhdGVTZWxlY3Rpb25WYWx1ZXMoX3Jvd0RhdGE6IEFycmF5PGFueT4sIF9zZWxlY3RlZElkczogQXJyYXk8c3RyaW5nIHwgbnVtYmVyPiwgX3JldHVybktleTogQXJyYXk8c3RyaW5nPiwgX2xvYWRUeXBlPzogc3RyaW5nKTogQXJyYXk8YW55PiB7XHJcbiAgICAgICAgaWYgKHR5cGVvZiBfcmV0dXJuS2V5ID09PSAndW5kZWZpbmVkJyB8fFxyXG4gICAgICAgICAgICBfcmV0dXJuS2V5ID09PSBudWxsIHx8XHJcbiAgICAgICAgICAgIF9yZXR1cm5LZXkubGVuZ3RoID09PSAwKSB7XHJcbiAgICAgICAgICAgIHJldHVybiBfc2VsZWN0ZWRJZHM7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICBsZXQgZ2VuZXJhdGVkU2VsZWN0aW9uOiBBcnJheTxhbnk+ID0gW107XHJcblxyXG4gICAgICAgIGZvciAobGV0IGk6IG51bWJlciA9IDA7IGkgPCBfcm93RGF0YS5sZW5ndGg7IGkrKykge1xyXG4gICAgICAgICAgICBsZXQgZGF0YUl0ZW06IGFueSA9IF9yb3dEYXRhW2ldO1xyXG4gICAgICAgICAgICBsZXQgb25lSXRlbTogYW55ID0ge307XHJcblxyXG4gICAgICAgICAgICBpZiAoX3NlbGVjdGVkSWRzLmluZGV4T2YoZGF0YUl0ZW1bdGhpcy5yb3dLZXldKSA+IC0xKSB7XHJcbiAgICAgICAgICAgICAgICBvbmVJdGVtW3RoaXMucm93S2V5XSA9IGRhdGFJdGVtW3RoaXMucm93S2V5XTtcclxuXHJcbiAgICAgICAgICAgICAgICBmb3IgKGxldCBqOiBudW1iZXIgPSAwOyBqIDwgX3JldHVybktleS5sZW5ndGg7IGorKykge1xyXG4gICAgICAgICAgICAgICAgICAgIGlmIChkYXRhSXRlbS5oYXNPd25Qcm9wZXJ0eShfcmV0dXJuS2V5W2pdKSkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBvbmVJdGVtW19yZXR1cm5LZXlbal1dID0gZGF0YUl0ZW1bX3JldHVybktleVtqXV07XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIGVsc2UgaWYgKF9yZXR1cm5LZXlbal0uaW5kZXhPZignLicpID4gMCkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBsZXQgcmV0dXJuVmFsOiBhbnkgPSB0aGlzLmRhdGFTdmMuZ2V0RGF0YVZhbHVlKGRhdGFJdGVtLCBfcmV0dXJuS2V5W2pdKTtcclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGlmIChyZXR1cm5WYWwgIT09IG51bGwpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxldCBuZXdJdGVtOiBhbnkgPSAoPGFueT5PYmplY3QpLmFzc2lnbih7fSwgb25lSXRlbSk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbmVJdGVtID0gdGhpcy5fY29udmVydERhdGFWYWx1ZVRvT2JqZWN0KG5ld0l0ZW0sIF9yZXR1cm5LZXlbal0sIHJldHVyblZhbCk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICAgICAgZ2VuZXJhdGVkU2VsZWN0aW9uLnB1c2gob25lSXRlbSk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIHJldHVybiBnZW5lcmF0ZWRTZWxlY3Rpb247XHJcbiAgICB9XHJcblxyXG4gICAgLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy9cclxuICAgIC8vLyBHcmlkIEJ1dHRvbiBmdW5jdGlvbnNcclxuICAgIC8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vXHJcbiAgICBwdWJsaWMgdXBkYXRlR3JpZEJ1dHRvbnMoX2dyaWRDb25maWc6IElUYWJsZUNvbmZpZyk6IHZvaWQge1xyXG4gICAgICAgIGlmICh0eXBlb2YgX2dyaWRDb25maWcuYnV0dG9uID09PSAndW5kZWZpbmVkJykge1xyXG4gICAgICAgICAgICBfZ3JpZENvbmZpZy5idXR0b24gPSBbXTtcclxuICAgICAgICB9XHJcbiAgICAgICAgZWxzZSBpZiAoX2dyaWRDb25maWcuYnV0dG9uLmxlbmd0aCA+IDQpIHtcclxuICAgICAgICAgICAgY29uc29sZS53YXJuKCdLZFRhYmxlIHdhcm5pbmc6IE1heCA0IGJ1dHRvbnMgZm9yIHRhYmxlLiBTbGljaW5nIHRvIDQuJyk7XHJcbiAgICAgICAgICAgIF9ncmlkQ29uZmlnLmJ1dHRvbiA9IF9ncmlkQ29uZmlnLmJ1dHRvbi5zbGljZSgwLCA0KTtcclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy9cclxuICAgIC8vLyBUYWJsZSBJbnB1dCBmdW5jdGlvbnNcclxuICAgIC8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vXHJcbiAgICBwdWJsaWMgdXBkYXRlUm93RGF0YVdpdGhDb2x1bW4oX3Jvd0RhdGE6IEFycmF5PGFueT4sIF9jb2x1bW5Db25maWc6IEFycmF5PElUYWJsZUNvbHVtbj4sIF9ncmlkSWQ6IHN0cmluZywgX2dyaWRPcHRpb25zOiBHcmlkT3B0aW9ucyk6IHZvaWQge1xyXG4gICAgICAgIGlmICh0aGlzLmhhc0lucHV0VHlwZShfY29sdW1uQ29uZmlnLCAnaW5wdXQnKSkge1xyXG4gICAgICAgICAgICBpZiAodHlwZW9mIF9ncmlkT3B0aW9ucy5jb250ZXh0W3RoaXMuVEFCTEVfSU5QVVRfQ09OVEVYVF9LRVldID09PSAndW5kZWZpbmVkJykge1xyXG4gICAgICAgICAgICAgICAgX2dyaWRPcHRpb25zLmNvbnRleHRbdGhpcy5UQUJMRV9JTlBVVF9DT05URVhUX0tFWV0gPSB7fTtcclxuICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgbGV0IGlucHV0Q29udGV4dDogYW55ID0gdGhpcy5fZ2VuZXJhdGVUYWJsZUlucHV0Q29udGV4dChfY29sdW1uQ29uZmlnLCBfcm93RGF0YSwgX2dyaWRJZCk7XHJcbiAgICAgICAgICAgIF9ncmlkT3B0aW9ucy5jb250ZXh0W3RoaXMuVEFCTEVfSU5QVVRfQ09OVEVYVF9LRVldID0gKDxhbnk+T2JqZWN0KS5hc3NpZ24oX2dyaWRPcHRpb25zLmNvbnRleHRbdGhpcy5UQUJMRV9JTlBVVF9DT05URVhUX0tFWV0sIGlucHV0Q29udGV4dCk7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIC8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vXHJcbiAgICAvLy8gQVBJIEdlbmVyYXRpb24gZnVuY3Rpb25cclxuICAgIC8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vXHJcbiAgICBwdWJsaWMgZ2VuZXJhdGVkQXBpRnVuY3Rpb25zKF9ncmlkQXBpOiBJVGFibGVBcGksIF9hcGlQYXJhbXM6IGFueSk6IHZvaWQge1xyXG4gICAgICAgIF9ncmlkQXBpLmR5bmFtaWNGb3JtID0gdGhpcy5fZ2VuZXJhdGVJbnB1dEFwaShfYXBpUGFyYW1zLmlkLCBfYXBpUGFyYW1zLmV2ZW50KTtcclxuICAgICAgICBfZ3JpZEFwaS5nZW5lcmFsID0gdGhpcy5fZ2VuZXJhdGVHZW5lcmFsQXBpKF9hcGlQYXJhbXMucm93cyk7XHJcbiAgICB9XHJcblxyXG4gICAgLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy9cclxuICAgIC8vLyBNaXNjIGZ1bmN0aW9uXHJcbiAgICAvLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vL1xyXG4gICAgcHVibGljIGdldEdyaWRJZChfZ3JpZENvbmZpZzogSVRhYmxlQ29uZmlnKTogc3RyaW5nIHtcclxuICAgICAgICBpZiAodHlwZW9mIF9ncmlkQ29uZmlnLmlkID09PSAndW5kZWZpbmVkJykge1xyXG4gICAgICAgICAgICBfZ3JpZENvbmZpZy5pZCA9IHRoaXMuREVGQVVMVF9HUklESUQ7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICByZXR1cm4gX2dyaWRDb25maWcuaWQ7XHJcbiAgICB9XHJcblxyXG4gICAgcHVibGljIGdldEltYWdlU2l6ZUJ5KF90YWJsZUNvbHVtbjogSVRhYmxlQ29sdW1uLCBfZGltZW5zaW9uOiAnd2lkdGgnIHwgJ2hlaWdodCcpOiBudW1iZXIge1xyXG4gICAgICAgIC8vIERlZmF1bHQgcGxhY2Vob2xkZXIgd2lkdGggMTUwICsgMjAgZ2FwXHJcbiAgICAgICAgbGV0IHdpZHRoOiBudW1iZXIgPSAxNTAgKyB0aGlzLklNQUdFX1BBRERJTkc7XHJcblxyXG4gICAgICAgIGlmICh0eXBlb2YgX3RhYmxlQ29sdW1uLmNvbmZpZyAhPT0gJ3VuZGVmaW5lZCcgJiZcclxuICAgICAgICAgICAgdHlwZW9mIF90YWJsZUNvbHVtbi5jb25maWcuaW1hZ2UgIT09ICd1bmRlZmluZWQnICYmXHJcbiAgICAgICAgICAgIHR5cGVvZiBfdGFibGVDb2x1bW4uY29uZmlnLmltYWdlW19kaW1lbnNpb25dICE9PSAndW5kZWZpbmVkJykge1xyXG4gICAgICAgICAgICB3aWR0aCA9IF90YWJsZUNvbHVtbi5jb25maWcuaW1hZ2VbX2RpbWVuc2lvbl0gKyB0aGlzLklNQUdFX1BBRERJTkc7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICByZXR1cm4gd2lkdGg7XHJcbiAgICB9XHJcblxyXG4gICAgcHVibGljIGdldFRhYmxlQ29udGV4dEtleSgpOiBzdHJpbmcge1xyXG4gICAgICAgIHJldHVybiB0aGlzLlRBQkxFX0lOUFVUX0NPTlRFWFRfS0VZO1xyXG4gICAgfVxyXG5cclxuICAgIHB1YmxpYyBnZXRSb3V0ZXJQbGFjZWhvbGRlclBhdGgoX3Jvd05vZGU6IFJvd05vZGUsIF9wYXRoOiBzdHJpbmcpOiBzdHJpbmcge1xyXG4gICAgICAgIHJldHVybiB0aGlzLmRhdGFTdmMuZ2V0UGxhY2Vob2xkZXIoX3Jvd05vZGUuZGF0YSwgX3BhdGgpO1xyXG4gICAgfVxyXG5cclxuICAgIHB1YmxpYyBiNjR0b0Jsb2IoYjY0RGF0YTogYW55LCBjb250ZW50VHlwZTogc3RyaW5nKTogQmxvYiB7XHJcbiAgICAgICAgbGV0IHNsaWNlU2l6ZTogbnVtYmVyID0gNTEyO1xyXG5cclxuICAgICAgICBsZXQgYnl0ZUNoYXJhY3RlcnM6IGFueSA9IGF0b2IoYjY0RGF0YSk7XHJcbiAgICAgICAgbGV0IGJ5dGVBcnJheXM6IGFueVtdID0gW107XHJcblxyXG4gICAgICAgIGZvciAobGV0IG9mZnNldCA9IDA7IG9mZnNldCA8IGJ5dGVDaGFyYWN0ZXJzLmxlbmd0aDsgb2Zmc2V0ICs9IHNsaWNlU2l6ZSkge1xyXG4gICAgICAgICAgICBsZXQgc2xpY2U6IGFueSA9IGJ5dGVDaGFyYWN0ZXJzLnNsaWNlKG9mZnNldCwgb2Zmc2V0ICsgc2xpY2VTaXplKTtcclxuXHJcbiAgICAgICAgICAgIGxldCBieXRlTnVtYmVyczogYW55W10gPSBuZXcgQXJyYXkoc2xpY2UubGVuZ3RoKTtcclxuICAgICAgICAgICAgZm9yIChsZXQgaSA9IDA7IGkgPCBzbGljZS5sZW5ndGg7IGkrKykge1xyXG4gICAgICAgICAgICAgICAgYnl0ZU51bWJlcnNbaV0gPSBzbGljZS5jaGFyQ29kZUF0KGkpO1xyXG4gICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICBsZXQgYnl0ZUFycmF5OiBVaW50OEFycmF5ID0gbmV3IFVpbnQ4QXJyYXkoYnl0ZU51bWJlcnMpO1xyXG5cclxuICAgICAgICAgICAgYnl0ZUFycmF5cy5wdXNoKGJ5dGVBcnJheSk7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICBsZXQgYmxvYjogQmxvYiA9IG5ldyBCbG9iKGJ5dGVBcnJheXMsIHsgdHlwZTogY29udGVudFR5cGUgfSk7XHJcbiAgICAgICAgcmV0dXJuIGJsb2I7XHJcbiAgICB9XHJcblxyXG4gICAgLyoqKioqKioqKiogRW5kIG9mIHB1YmxpYyBmdW5jdGlvbnMgLyBTdGFydCBvZiBwcm90ZWN0ZWQgZnVuY3Rpb25zICoqKioqKioqKiovXHJcbiAgICAvLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vL1xyXG4gICAgLy8vIEdyaWQgT3B0aW9ucyBmdW5jdGlvbnNcclxuICAgIC8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vXHJcbiAgICBwcm90ZWN0ZWQgZ2V0RGVmYXVsdEdyaWRPcHRpb25zKF9kaXJlY3Rpb246ICdsdHInIHwgJ3J0bCcsIF9yb3dIZWlnaHQ6IG51bWJlcik6IEdyaWRPcHRpb25zIHtcclxuICAgICAgICB0aGlzLmRpcmVjdGlvbiA9IF9kaXJlY3Rpb247XHJcblxyXG4gICAgICAgIHJldHVybiB7XHJcbiAgICAgICAgICAgIHJvd0RhdGE6IFtdLFxyXG4gICAgICAgICAgICBjb2x1bW5EZWZzOiBbXSxcclxuICAgICAgICAgICAgZW5hYmxlUnRsOiBfZGlyZWN0aW9uID09PSAncnRsJyxcclxuXHJcbiAgICAgICAgICAgIGhlYWRlckhlaWdodDogMzgsXHJcbiAgICAgICAgICAgIHJvd0hlaWdodDogKHR5cGVvZiBfcm93SGVpZ2h0ICE9PSAndW5kZWZpbmVkJykgPyBfcm93SGVpZ2h0ICsgMjAgOiB0aGlzLlJPV19IRUlHSFQsXHJcblxyXG4gICAgICAgICAgICAvLyBzdXBwcmVzc01vdmFibGVDb2x1bW5zOiB0cnVlLFxyXG4gICAgICAgICAgICBzdXBwcmVzc0RyYWdMZWF2ZUhpZGVzQ29sdW1uczogdHJ1ZSxcclxuICAgICAgICAgICAgZW5hYmxlQ29sUmVzaXplOiB0cnVlLFxyXG5cclxuICAgICAgICAgICAgc3VwcHJlc3NDb250ZXh0TWVudTogdHJ1ZSxcclxuICAgICAgICAgICAgc3VwcHJlc3NNZW51SGlkZTogdHJ1ZSxcclxuICAgICAgICAgICAgZW5zdXJlRG9tT3JkZXI6IHRydWUsXHJcblxyXG4gICAgICAgICAgICBzdXBwcmVzc1Byb3BlcnR5TmFtZXNDaGVjazogdHJ1ZSxcclxuXHJcbiAgICAgICAgICAgIC8vIHN1cHByZXNzQ29sdW1uVmlydHVhbGlzYXRpb246IHRydWUsXHJcblxyXG4gICAgICAgICAgICBhbmltYXRlUm93czogZmFsc2UsXHJcbiAgICAgICAgICAgIHJvd0J1ZmZlcjogNSxcclxuXHJcbiAgICAgICAgICAgIGdldFJvd05vZGVJZDogKF9kYXRhOiBhbnkpOiBzdHJpbmcgPT4ge1xyXG4gICAgICAgICAgICAgICAgbGV0IGlkOiBzdHJpbmcgPSBfZGF0YS5pZDtcclxuXHJcbiAgICAgICAgICAgICAgICBpZiAodHlwZW9mIF9kYXRhLmlkID09PSAnbnVtYmVyJykge1xyXG4gICAgICAgICAgICAgICAgICAgIGlkID0gaWQudG9TdHJpbmcoKTtcclxuICAgICAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgICAgICByZXR1cm4gaWQ7XHJcbiAgICAgICAgICAgIH0sXHJcblxyXG4gICAgICAgICAgICB1blNvcnRJY29uOiB0cnVlLFxyXG4gICAgICAgICAgICBpY29uczoge1xyXG4gICAgICAgICAgICAgICAgZmlsdGVyOiAnPGkgY2xhc3M9XCJmYSBmYS1maWx0ZXJcIi8+JyxcclxuICAgICAgICAgICAgICAgIHNvcnRBc2NlbmRpbmc6ICc8aSBjbGFzcz1cImZhIGZhLWNhcmV0LWRvd25cIi8+JyxcclxuICAgICAgICAgICAgICAgIHNvcnREZXNjZW5kaW5nOiAnPGkgY2xhc3M9XCJmYSBmYS1jYXJldC11cFwiLz4nLFxyXG4gICAgICAgICAgICAgICAgc29ydFVuU29ydDogJzxpIGNsYXNzPVwiZmEgZmEtc29ydFwiLz4nLFxyXG4gICAgICAgICAgICAgICAgLy8gZ3JvdXBFeHBhbmRlZDogJzxpIGNsYXNzPVwiZmEgZmEtbWludXMtY2lyY2xlXCIvPicsXHJcbiAgICAgICAgICAgICAgICAvLyBncm91cENvbnRyYWN0ZWQ6ICc8aSBjbGFzcz1cImZhIGZhLXBsdXMtY2lyY2xlXCIvPicsXHJcbiAgICAgICAgICAgICAgICBncm91cEV4cGFuZGVkOiAnPGkgY2xhc3M9XCJmYSBmYS1hbmdsZS1kb3duXCIvPicsXHJcbiAgICAgICAgICAgICAgICBncm91cENvbnRyYWN0ZWQ6ICc8aSBjbGFzcz1cImZhIGZhLWFuZ2xlLXJpZ2h0XCIvPicsXHJcblxyXG4gICAgICAgICAgICAgICAgbWVudTogJzxpIGNsYXNzPVwiZmEgZmEtYmFyc1wiLz4nXHJcbiAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgIGF1dG9Hcm91cENvbHVtbkRlZjoge1xyXG4gICAgICAgICAgICAgICAgaWNvbnM6IHtcclxuICAgICAgICAgICAgICAgICAgICBtZW51OiAnPGkgY2xhc3M9XCJmYSBmYS1iYXJcIiBzdHlsZT1cImRpc3BsYXk6bm9uZVwiLz4nLFxyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICBjb250ZXh0OiB7fSxcclxuICAgICAgICAgICAgb3ZlcmxheU5vUm93c1RlbXBsYXRlOiAnPHNwYW4gY2xhc3M9XCJhZy1jdXN0b20tb3ZlcmxheVwiPjxpIGNsYXNzPVwiZmEgZmEtaW5mby1jaXJjbGUgZmEtbGcgbWFyZ2luLXJpZ2h0MTBcIj48L2k+Tm8gcmVjb3JkIGZvdW5kPC9zcGFuPidcclxuICAgICAgICB9O1xyXG4gICAgfVxyXG5cclxuICAgIC8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vXHJcbiAgICAvLy8gQ29sdW1uIERlZmluaXRpb24gZnVuY3Rpb25zXHJcbiAgICAvLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vL1xyXG4gICAgcHJvdGVjdGVkIGdlbmVyYXRlQ29sdW1uRGVmaW5pdGlvbnMoX2NvbHVtbkNvbmZpZzogQXJyYXk8SVRhYmxlQ29sdW1uPiwgX2dyaWRDb25maWc6IElUYWJsZUNvbmZpZywgX3N1cHByZXNzTW92YWJsZUNvbHVtbnM6IGJvb2xlYW49IHRydWUpOiBBcnJheTxDb2xEZWY+IHtcclxuICAgICAgICBsZXQgY29sdW1uRGVmOiBBcnJheTxDb2xEZWY+ID0gdGhpcy5fZ2VuZXJhdGVDb2xEZWZzRnJvbUNvbENvbmZpZyhfY29sdW1uQ29uZmlnLCBfZ3JpZENvbmZpZywgX3N1cHByZXNzTW92YWJsZUNvbHVtbnMpO1xyXG4gICAgICAgIGxldCBjb2x1bW5PYmplY3RzOiB7IFtrZXk6IHN0cmluZ106IENvbERlZiB9ID0gdGhpcy5fZ2VuZXJhdGVDb2xEZWZzRnJvbUNvbmZpZyhfZ3JpZENvbmZpZyk7XHJcblxyXG4gICAgICAgIGlmIChjb2x1bW5PYmplY3RzLmhhc093blByb3BlcnR5KCdhY3Rpb24nKSkge1xyXG4gICAgICAgICAgICBjb2x1bW5EZWYucHVzaChjb2x1bW5PYmplY3RzLmFjdGlvbik7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICBpZiAoY29sdW1uT2JqZWN0cy5oYXNPd25Qcm9wZXJ0eSgnc2VsZWN0aW9uJykpIHtcclxuICAgICAgICAgICAgY29sdW1uRGVmLnVuc2hpZnQoY29sdW1uT2JqZWN0cy5zZWxlY3Rpb24pO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgcmV0dXJuIGNvbHVtbkRlZjtcclxuICAgIH1cclxuXHJcbiAgICBwcm90ZWN0ZWQgaXNDb2xEZWZPZlR5cGUoX2NvbERlZjogQ29sRGVmLCBfdHlwZTogc3RyaW5nKTogYm9vbGVhbiB7XHJcbiAgICAgICAgaWYgKHR5cGVvZiBfY29sRGVmLmNlbGxSZW5kZXJlclBhcmFtcyAhPT0gJ3VuZGVmaW5lZCcgJiZcclxuICAgICAgICAgICAgdHlwZW9mIF9jb2xEZWYuY2VsbFJlbmRlcmVyUGFyYW1zLnBhcmFtcyAhPT0gJ3VuZGVmaW5lZCcgJiZcclxuICAgICAgICAgICAgdHlwZW9mIF9jb2xEZWYuY2VsbFJlbmRlcmVyUGFyYW1zLnBhcmFtc1tfdHlwZV0gIT09ICd1bmRlZmluZWQnKSB7XHJcbiAgICAgICAgICAgIHJldHVybiB0cnVlO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgcmV0dXJuIGZhbHNlO1xyXG4gICAgfVxyXG5cclxuICAgIC8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vXHJcbiAgICAvLy8gTWlzYyBmdW5jdGlvblxyXG4gICAgLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy9cclxuICAgIHByb3RlY3RlZCBnZW5lcmF0ZUNvbnRleHRLZXkoX2dyaWRJZDogc3RyaW5nLCBfY29sdW1uSWQ6IHN0cmluZywgX3Jvd0lkOiBzdHJpbmcgfCBudW1iZXIpOiBzdHJpbmcge1xyXG4gICAgICAgIHJldHVybiBfZ3JpZElkICsgdGhpcy5DT05URVhUX0RFTElNSVRFUiArIF9jb2x1bW5JZCArIHRoaXMuQ09OVEVYVF9ERUxJTUlURVIgKyBfcm93SWQ7XHJcbiAgICB9XHJcblxyXG4gICAgLyoqKioqKioqKiogRW5kIG9mIHByb3RlY3RlZCBmdW5jdGlvbnMgLyBTdGFydCBvZiBwcml2YXRlIGZ1bmN0aW9ucyAqKioqKioqKioqL1xyXG4gICAgLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy9cclxuICAgIC8vLyBDb2xEZWYgLSBDb2x1bW4gZGVmaW5pdGlvbiBmdW5jdGlvbnNcclxuICAgIC8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vXHJcbiAgICBwcml2YXRlIF9nZW5lcmF0ZUNvbERlZnNGcm9tQ29sQ29uZmlnKF9jb2x1bW5Db25maWc6IEFycmF5PElUYWJsZUNvbHVtbj4sIF9ncmlkQ29uZmlnOiBJVGFibGVDb25maWcsIF9zdXBwcmVzc01vdmFibGVDb2x1bW5zOiBib29sZWFuID0gdHJ1ZSk6IEFycmF5PENvbERlZj4ge1xyXG4gICAgICAgIGxldCBjb2x1bW5EZWY6IEFycmF5PENvbERlZj4gPSBbXTtcclxuXHJcbiAgICAgICAgZm9yIChsZXQgaTogbnVtYmVyID0gMDsgaSA8IF9jb2x1bW5Db25maWcubGVuZ3RoOyBpKyspIHtcclxuICAgICAgICAgICAgbGV0IGNvbHVtbjogQ29sRGVmID0ge307XHJcblxyXG4gICAgICAgICAgICBpZiAodHlwZW9mIF9jb2x1bW5Db25maWdbaV0gIT09ICd1bmRlZmluZWQnKSB7XHJcbiAgICAgICAgICAgICAgICBsZXQgdGVtcENvbHVtbjogSVRhYmxlQ29sdW1uID0gKDxhbnk+T2JqZWN0KS5hc3NpZ24odGhpcy5fZ2V0RGVmYXVsdENvbHVtbkNvbmZpZygpLCBfY29sdW1uQ29uZmlnW2ldKTtcclxuICAgICAgICAgICAgICAgIHRlbXBDb2x1bW4uc3VwcHJlc3NNb3ZhYmxlID0gX3N1cHByZXNzTW92YWJsZUNvbHVtbnM7XHJcblxyXG4gICAgICAgICAgICAgICAgc3dpdGNoICh0ZW1wQ29sdW1uLnR5cGUpIHtcclxuICAgICAgICAgICAgICAgICAgICBjYXNlICdpbnB1dCc6XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbHVtbiA9IHRoaXMuX2dlbmVyYXRlSW5wdXRDb2xEZWYodGVtcENvbHVtbiwgX2dyaWRDb25maWcuaWQpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBicmVhaztcclxuICAgICAgICAgICAgICAgICAgICBjYXNlICdpbWFnZSc6XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbHVtbiA9IHRoaXMuX2dlbmVyYXRlSW1hZ2VDb2xEZWYodGVtcENvbHVtbik7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgICAgICAgICAgICAgIGRlZmF1bHQ6XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC8vIFRFTVAgZml4IGZvciBwaXZvdFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAvLyB2YWx1ZSBhc3NpZ25tZW50IGluc3RlYWQgb2Ygb2JqZWN0IGRpcmVjdCBhc3NpZ25tZW50IHNvIHRvIGFsbG93IGFwcGxpY2F0aW9uIHRvIHBhc3MgaW4gb3RoZXIgY29sZGVmXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbHVtbiA9IHRlbXBDb2x1bW47XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbHVtbi5oZWFkZXJOYW1lID0gdGVtcENvbHVtbi5oZWFkZXJOYW1lO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBjb2x1bW4uY29sSWQgPSB0ZW1wQ29sdW1uLmZpZWxkO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBjb2x1bW4uZmllbGQgPSB0ZW1wQ29sdW1uLmZpZWxkO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBjb2x1bW4uY2VsbENsYXNzID0gJ25vcm1hbC1jZWxsICcgKyB0ZW1wQ29sdW1uLmNsYXNzO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBjb2x1bW4uaGlkZSA9ICF0ZW1wQ29sdW1uLnZpc2libGU7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbHVtbi5zdXBwcmVzc01lbnUgPSAhdGVtcENvbHVtbi5maWx0ZXJhYmxlO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBjb2x1bW4uc3VwcHJlc3NTb3J0aW5nID0gIXRlbXBDb2x1bW4uc29ydGFibGU7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbHVtbi5taW5XaWR0aCA9IDEwMDtcclxuICAgICAgICAgICAgICAgICAgICAgICAgY29sdW1uLnN1cHByZXNzTW92YWJsZSA9IHRlbXBDb2x1bW4uc3VwcHJlc3NNb3ZhYmxlO1xyXG4gICAgICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgICAgIGlmICh0ZW1wQ29sdW1uLmZpbHRlcmFibGUpIHtcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLl91cGRhdGVGaWx0ZXJDb2xEZWYoY29sdW1uLCB0ZW1wQ29sdW1uLmZpbHRlclZhbHVlKTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBjb2x1bW5EZWYucHVzaChjb2x1bW4pO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgcmV0dXJuIGNvbHVtbkRlZjtcclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF9nZW5lcmF0ZUNvbERlZnNGcm9tQ29uZmlnKF9jb25maWc6IElUYWJsZUNvbmZpZyk6IHsgW2tleTogc3RyaW5nXTogQ29sRGVmIH0ge1xyXG4gICAgICAgIGxldCBjb2xEZWZPYmplY3Q6IHsgW2tleTogc3RyaW5nXTogQ29sRGVmIH0gPSB7fTtcclxuXHJcbiAgICAgICAgaWYgKHR5cGVvZiBfY29uZmlnICE9PSAndW5kZWZpbmVkJyAmJlxyXG4gICAgICAgICAgICB0eXBlb2YgX2NvbmZpZy5hY3Rpb24gIT09ICd1bmRlZmluZWQnICYmXHJcbiAgICAgICAgICAgIF9jb25maWcuYWN0aW9uLmVuYWJsZWQpIHtcclxuICAgICAgICAgICAgY29sRGVmT2JqZWN0LmFjdGlvbiA9IHRoaXMuX2dlbmVyYXRlQWN0aW9uQ29sRGVmKF9jb25maWcuaWQsIF9jb25maWcuYWN0aW9uLmxpc3QsIF9jb25maWcuYWN0aW9uLm5hbWUpO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgaWYgKHR5cGVvZiBfY29uZmlnICE9PSAndW5kZWZpbmVkJyAmJlxyXG4gICAgICAgICAgICB0eXBlb2YgX2NvbmZpZy5zZWxlY3Rpb24gIT09ICd1bmRlZmluZWQnICYmXHJcbiAgICAgICAgICAgIHR5cGVvZiBfY29uZmlnLnNlbGVjdGlvbi50eXBlICE9PSAndW5kZWZpbmVkJykge1xyXG4gICAgICAgICAgICBjb2xEZWZPYmplY3Quc2VsZWN0aW9uID0gdGhpcy5fZ2VuZXJhdGVDaGVja2JveFJhZGlvQ29sRGVmKF9jb25maWcuc2VsZWN0aW9uLCBfY29uZmlnLmlkKTtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIHJldHVybiBjb2xEZWZPYmplY3Q7XHJcbiAgICB9XHJcblxyXG4gICAgLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy9cclxuICAgIC8vLyBDb2xEZWYgLSBBY3Rpb24gZHJvcGRvd24gZnVuY3Rpb25zXHJcbiAgICAvLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vL1xyXG4gICAgcHJpdmF0ZSBfZ2VuZXJhdGVBY3Rpb25Db2xEZWYoX2lkOiBzdHJpbmcsIF9saXN0OiBBcnJheTxJVGFibGVEcm9wZG93bkFjdGlvbj4sIF9uYW1lPzogc3RyaW5nKTogQ29sRGVmIHtcclxuICAgICAgICByZXR1cm4ge1xyXG4gICAgICAgICAgICBoZWFkZXJOYW1lOiAodHlwZW9mIF9uYW1lICE9PSAndW5kZWZpbmVkJykgPyBfbmFtZSA6ICdBY3Rpb24nLFxyXG4gICAgICAgICAgICBzdXBwcmVzc1NvcnRpbmc6IHRydWUsXHJcbiAgICAgICAgICAgIHN1cHByZXNzRmlsdGVyOiB0cnVlLFxyXG4gICAgICAgICAgICBzdXBwcmVzc1NpemVUb0ZpdDogdHJ1ZSxcclxuICAgICAgICAgICAgc3VwcHJlc3NSZXNpemU6IHRydWUsXHJcbiAgICAgICAgICAgIHN1cHByZXNzTWVudTogdHJ1ZSxcclxuICAgICAgICAgICAgd2lkdGg6IDEyMCxcclxuICAgICAgICAgICAgbWluV2lkdGg6IDEyMCxcclxuICAgICAgICAgICAgbWF4V2lkdGg6IDEyMCxcclxuICAgICAgICAgICAgY2VsbENsYXNzOiAnZHJvcGRvd24tYWN0aW9uJyxcclxuICAgICAgICAgICAgY29sSWQ6ICdhZy1hY3Rpb24nLFxyXG4gICAgICAgICAgICBjZWxsUmVuZGVyZXJGcmFtZXdvcms6IEtkVGFibGVBY3Rpb24sXHJcbiAgICAgICAgICAgIGNlbGxSZW5kZXJlclBhcmFtczoge1xyXG4gICAgICAgICAgICAgICAgcGFyYW1zOiBfbGlzdCxcclxuICAgICAgICAgICAgICAgIGdyaWRJZDogX2lkXHJcbiAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgIHN1cHByZXNzTW92YWJsZTogdHJ1ZVxyXG4gICAgICAgIH07IFxyXG4gICAgfVxyXG5cclxuICAgIC8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vXHJcbiAgICAvLy8gQ29sRGVmIC0gQ2hlY2tib3ggLyBSYWRpbyBmdW5jdGlvbnNcclxuICAgIC8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vXHJcbiAgICBwcml2YXRlIF9nZW5lcmF0ZUNoZWNrYm94UmFkaW9Db2xEZWYoX3NlbGVjdGlvbk9iajogYW55LCBfZ3JpZElkOiBzdHJpbmcpOiBDb2xEZWYge1xyXG4gICAgICAgIC8vLyBIYXZlIHRvIHNldCB0aGUgdHlwZSBhbnkgYXMgc2V0dGluZyBhcyBDb2xEZWYgd2lsbCBoYXMgaXNzdWVzXHJcbiAgICAgICAgLy8vIG9uIGhlYWRlckNvbXBvbmVudEZyYW1ld29yayB0eXBlIGlzIHdyb25nbHkgdXNlZC5cclxuXHJcbiAgICAgICAgbGV0IGNoZWNrYm94UmFkaW9EaXJlY3Rpb246IHN0cmluZyA9IHRoaXMuZGlyZWN0aW9uID09PSAnbHRyJyA/ICdsZWZ0JyA6ICdyaWdodCc7XHJcblxyXG4gICAgICAgIGxldCB0ZW1wQ29sRGVmOiBhbnkgPSB7XHJcbiAgICAgICAgICAgIHN1cHByZXNzU29ydGluZzogdHJ1ZSxcclxuICAgICAgICAgICAgc3VwcHJlc3NGaWx0ZXI6IHRydWUsXHJcbiAgICAgICAgICAgIHN1cHByZXNzU2l6ZVRvRml0OiB0cnVlLFxyXG4gICAgICAgICAgICBzdXBwcmVzc01lbnU6IHRydWUsXHJcbiAgICAgICAgICAgIHN1cHByZXNzUmVzaXplOiB0cnVlLFxyXG4gICAgICAgICAgICB3aWR0aDogNTAsXHJcbiAgICAgICAgICAgIG1pbldpZHRoOiA1MCxcclxuICAgICAgICAgICAgbWF4V2lkdGg6IDUwLFxyXG4gICAgICAgICAgICBjZWxsQ2xhc3M6ICdhZy1kZWZhdWx0IGFnLWNoZWNrYm94LXJhZGlvJyxcclxuICAgICAgICAgICAgcGlubmVkOiBjaGVja2JveFJhZGlvRGlyZWN0aW9uLFxyXG4gICAgICAgICAgICBjb2xJZDogKF9zZWxlY3Rpb25PYmoudHlwZSA9PT0gJ3NpbmdsZScpID8gJ3JhZGlvJyA6ICdjaGVja2JveCcsXHJcbiAgICAgICAgICAgIGNlbGxSZW5kZXJlckZyYW1ld29yazogS2RUYWJsZUNoZWNrYm94UmFkaW8sXHJcbiAgICAgICAgICAgIGNlbGxSZW5kZXJlclBhcmFtczoge1xyXG4gICAgICAgICAgICAgICAgcGFyYW1zOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgaW5wdXRUeXBlOiAoX3NlbGVjdGlvbk9iai50eXBlID09PSAnc2luZ2xlJykgPyAncmFkaW8nIDogJ2NoZWNrYm94JyxcclxuICAgICAgICAgICAgICAgICAgICBkZWZhdWx0OiBfc2VsZWN0aW9uT2JqLnZhbHVlLFxyXG4gICAgICAgICAgICAgICAgICAgIGdyaWRJZDogX2dyaWRJZFxyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICBzdXBwcmVzc01vdmFibGU6IHRydWVcclxuICAgICAgICB9O1xyXG5cclxuICAgICAgICBpZiAoX3NlbGVjdGlvbk9iai50eXBlID09PSAnYWxsJykge1xyXG4gICAgICAgICAgICB0ZW1wQ29sRGVmLmhlYWRlckNvbXBvbmVudEZyYW1ld29yayA9IEtkVGFibGVDaGVja2JveFJhZGlvO1xyXG4gICAgICAgICAgICB0ZW1wQ29sRGVmLmhlYWRlckNvbXBvbmVudFBhcmFtcyA9IHtcclxuICAgICAgICAgICAgICAgIHBhcmFtczoge1xyXG4gICAgICAgICAgICAgICAgICAgIGRlZmF1bHQ6IF9zZWxlY3Rpb25PYmoudmFsdWUsXHJcbiAgICAgICAgICAgICAgICAgICAgZ3JpZElkOiBfZ3JpZElkXHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH07XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICByZXR1cm4gdGVtcENvbERlZjtcclxuICAgIH1cclxuXHJcbiAgICAvLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vL1xyXG4gICAgLy8vIENvbERlZiAtIFRhYmxlIEltYWdlIGZ1bmN0aW9uc1xyXG4gICAgLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy9cclxuICAgIHByaXZhdGUgX2dlbmVyYXRlSW1hZ2VDb2xEZWYoX3RlbXBDb2x1bW46IElUYWJsZUNvbHVtbik6IENvbERlZiB7XHJcbiAgICAgICAgbGV0IHdpZHRoOiBudW1iZXIgPSB0aGlzLmdldEltYWdlU2l6ZUJ5KF90ZW1wQ29sdW1uLCAnd2lkdGgnKTtcclxuXHJcbiAgICAgICAgcmV0dXJuIHtcclxuICAgICAgICAgICAgaGVhZGVyTmFtZTogX3RlbXBDb2x1bW4uaGVhZGVyTmFtZSxcclxuICAgICAgICAgICAgZmllbGQ6IF90ZW1wQ29sdW1uLmZpZWxkLFxyXG4gICAgICAgICAgICBjb2xJZDogX3RlbXBDb2x1bW4uZmllbGQsXHJcbiAgICAgICAgICAgIHN1cHByZXNzU29ydGluZzogdHJ1ZSxcclxuICAgICAgICAgICAgc3VwcHJlc3NGaWx0ZXI6IHRydWUsXHJcbiAgICAgICAgICAgIHN1cHByZXNzTWVudTogdHJ1ZSxcclxuICAgICAgICAgICAgc3VwcHJlc3NSZXNpemU6IHRydWUsXHJcbiAgICAgICAgICAgIGhpZGU6ICFfdGVtcENvbHVtbi52aXNpYmxlLFxyXG4gICAgICAgICAgICBtaW5XaWR0aDogd2lkdGgsXHJcbiAgICAgICAgICAgIG1heFdpZHRoOiB3aWR0aCxcclxuICAgICAgICAgICAgY2VsbENsYXNzOiBfdGVtcENvbHVtbi5jbGFzcyxcclxuICAgICAgICAgICAgY2VsbFJlbmRlcmVyRnJhbWV3b3JrOiBLZFRhYmxlSW1hZ2UsXHJcbiAgICAgICAgICAgIGNlbGxSZW5kZXJlclBhcmFtczoge1xyXG4gICAgICAgICAgICAgICAgcGFyYW1zOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgW3RoaXMuR0lSRF9QQVJBTVNfS0VZLmltYWdlXTogX3RlbXBDb2x1bW4uY29uZmlnLmltYWdlLFxyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICBzdXBwcmVzc01vdmFibGU6IF90ZW1wQ29sdW1uLnN1cHByZXNzTW92YWJsZVxyXG4gICAgICAgIH07XHJcbiAgICB9XHJcblxyXG4gICAgLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy9cclxuICAgIC8vLyBDb2xEZWYgLSBUYWJsZSBJbnB1dCBmdW5jdGlvbnNcclxuICAgIC8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vXHJcbiAgICBwcml2YXRlIF9nZW5lcmF0ZUlucHV0Q29sRGVmKF90ZW1wQ29sdW1uOiBJVGFibGVDb2x1bW4sIF9ncmlkSWQ6IHN0cmluZyk6IENvbERlZiB7XHJcbiAgICAgICAgcmV0dXJuIHtcclxuICAgICAgICAgICAgaGVhZGVyTmFtZTogX3RlbXBDb2x1bW4uaGVhZGVyTmFtZSxcclxuICAgICAgICAgICAgZmllbGQ6IF90ZW1wQ29sdW1uLmZpZWxkLFxyXG4gICAgICAgICAgICBzdXBwcmVzc1NvcnRpbmc6IHRydWUsXHJcbiAgICAgICAgICAgIHN1cHByZXNzRmlsdGVyOiB0cnVlLFxyXG4gICAgICAgICAgICBzdXBwcmVzc01lbnU6IHRydWUsXHJcbiAgICAgICAgICAgIG1pbldpZHRoOiAyNTAsXHJcbiAgICAgICAgICAgIGhpZGU6ICFfdGVtcENvbHVtbi52aXNpYmxlLFxyXG4gICAgICAgICAgICBjZWxsQ2xhc3M6IF90ZW1wQ29sdW1uLmNsYXNzLFxyXG4gICAgICAgICAgICBjb2xJZDogX3RlbXBDb2x1bW4uZmllbGQsXHJcbiAgICAgICAgICAgIGNlbGxSZW5kZXJlckZyYW1ld29yazogS2RUYWJsZUlucHV0LFxyXG4gICAgICAgICAgICBjZWxsUmVuZGVyZXJQYXJhbXM6IHtcclxuICAgICAgICAgICAgICAgIHBhcmFtczoge1xyXG4gICAgICAgICAgICAgICAgICAgIFt0aGlzLkdJUkRfUEFSQU1TX0tFWS5pbnB1dF06IF90ZW1wQ29sdW1uLmNvbmZpZyxcclxuICAgICAgICAgICAgICAgICAgICBncmlkSWQ6IF9ncmlkSWQsXHJcbiAgICAgICAgICAgICAgICAgICAgY29udGV4dEtleTogdGhpcy5UQUJMRV9JTlBVVF9DT05URVhUX0tFWVxyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICBzdXBwcmVzc01vdmFibGU6IF90ZW1wQ29sdW1uLnN1cHByZXNzTW92YWJsZVxyXG4gICAgICAgIH07XHJcbiAgICB9XHJcblxyXG4gICAgLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy9cclxuICAgIC8vLyBBUEkgZ2VuZXJhdGlvbiBmdW5jdGlvbnNcclxuICAgIC8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vXHJcbiAgICBwcml2YXRlIF9nZW5lcmF0ZUlucHV0QXBpKF9ncmlkSWQ6IHN0cmluZywgX2tkVGFibGVJbnRFdmVudDogS2RJbnRUYWJsZUV2ZW50KTogSVRhYmxlRHluYW1pY0Zvcm1BcGkge1xyXG4gICAgICAgIHJldHVybiB7XHJcbiAgICAgICAgICAgIGdldFByb3BlcnR5OiAoX3RhYmxlUGFyYW1zOiBJVGFibGVGb3JtVXBkYXRlUGFyYW1zKTogYW55ID0+IHtcclxuICAgICAgICAgICAgICAgIGxldCBldmVudFN0cmluZyA9IHRoaXMuZ2VuZXJhdGVDb250ZXh0S2V5KF9ncmlkSWQsIF90YWJsZVBhcmFtcy5jb2xJZCwgX3RhYmxlUGFyYW1zLnJvd0lkKTtcclxuICAgICAgICAgICAgICAgIHJldHVybiB0aGlzLmdyaWRPcHRpb25zLmNvbnRleHQudGFibGVJbmRleENvbnRleHRbZXZlbnRTdHJpbmddW190YWJsZVBhcmFtcy5xdWVzdGlvbktleV1bX3RhYmxlUGFyYW1zLnByb3BlcnR5XTtcclxuICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgc2V0UHJvcGVydHk6IChfdGFibGVQYXJhbXM6IElUYWJsZUZvcm1VcGRhdGVQYXJhbXMpOiB2b2lkID0+IHtcclxuICAgICAgICAgICAgICAgIGxldCBldmVudFN0cmluZyA9IHRoaXMuZ2VuZXJhdGVDb250ZXh0S2V5KF9ncmlkSWQsIF90YWJsZVBhcmFtcy5jb2xJZCwgX3RhYmxlUGFyYW1zLnJvd0lkKTtcclxuXHJcbiAgICAgICAgICAgICAgICBpZiAodHlwZW9mIHRoaXMuZ3JpZE9wdGlvbnMuY29udGV4dC50YWJsZUlucHV0Q29udGV4dFtldmVudFN0cmluZ10gIT09ICd1bmRlZmluZWQnKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5ncmlkT3B0aW9ucy5jb250ZXh0LnRhYmxlSW5wdXRDb250ZXh0W2V2ZW50U3RyaW5nXVtfdGFibGVQYXJhbXMucXVlc3Rpb25LZXldW190YWJsZVBhcmFtcy5wcm9wZXJ0eV0gPSBfdGFibGVQYXJhbXMuZGF0YTtcclxuICAgICAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgICAgICBsZXQgcm93Tm9kZTogUm93Tm9kZSA9IHRoaXMuZ3JpZE9wdGlvbnMuYXBpLmdldFJvd05vZGUoX3RhYmxlUGFyYW1zLnJvd0lkLnRvU3RyaW5nKCkpO1xyXG5cclxuICAgICAgICAgICAgICAgIGlmIChfdGFibGVQYXJhbXMucHJvcGVydHkgPT09ICd2aXNpYmxlJykge1xyXG4gICAgICAgICAgICAgICAgICAgIHJvd05vZGUuc2V0Um93SGVpZ2h0KHVuZGVmaW5lZCk7XHJcbiAgICAgICAgICAgICAgICAgICAgLy8vIElzc3VlcyAtIENhbGxpbmcgdGhpcyBhcGkgb25Sb3dIZWlnaHRDaGFuZ2VkIGNhdXNpbmcgdGhlIGN1cnJlbnQgaW5wdXQgY2VsbCB0byBsb3NlIGZvY3VzXHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5ncmlkT3B0aW9ucy5hcGkub25Sb3dIZWlnaHRDaGFuZ2VkKCk7XHJcbiAgICAgICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICAgICAgaWYgKF90YWJsZVBhcmFtcy5wcm9wZXJ0eSA9PT0gJ3ZhbHVlJykge1xyXG4gICAgICAgICAgICAgICAgICAgIHJvd05vZGUuZGF0YVtfdGFibGVQYXJhbXMuY29sSWRdW190YWJsZVBhcmFtcy5xdWVzdGlvbktleV0gPSBfdGFibGVQYXJhbXMuZGF0YTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH07XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfZ2VuZXJhdGVHZW5lcmFsQXBpKF9yb3c6IEFycmF5PGFueT4pOiBJVGFibGVHZW5lcmFsQXBpIHtcclxuICAgICAgICByZXR1cm4ge1xyXG4gICAgICAgICAgICBnZXRDdXJyZW50Um93czogKCk6IEFycmF5PGFueT4gPT4ge1xyXG4gICAgICAgICAgICAgICAgcmV0dXJuIF9yb3cuc2xpY2UoKTtcclxuICAgICAgICAgICAgfSxcclxuXHJcbiAgICAgICAgICAgIHJlc2V0Um93SGVpZ2h0OiAoKTogdm9pZCA9PiB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLmdyaWRPcHRpb25zLmFwaS5yZXNldFJvd0hlaWdodHMoKTtcclxuICAgICAgICAgICAgfSxcclxuXHJcbiAgICAgICAgICAgIHNldENvbHVtblZpc2libGU6IChfY29sSWQ6IHN0cmluZywgX3Zpc2libGU6IGJvb2xlYW4pOiB2b2lkID0+IHtcclxuICAgICAgICAgICAgICAgIHRoaXMuZ3JpZE9wdGlvbnMuY29sdW1uQXBpLnNldENvbHVtblZpc2libGUoX2NvbElkLCBfdmlzaWJsZSk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9O1xyXG4gICAgfVxyXG5cclxuICAgIC8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vXHJcbiAgICAvLy8gVGFibGUgSW5wdXQgZnVuY3Rpb25zXHJcbiAgICAvLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vL1xyXG4gICAgLyoqXHJcbiAgICAgKiBbX2dlbmVyYXRlVGFibGVJbnB1dENvbnRleHRcclxuICAgICAqICAgICBHZW5lcmF0ZSB0aGUgaW5wdXQgY29uZmlndXJhdGlvbnMgYW5kIHZhbHVlcyB0byB0aGUgY29udGV4dCBvZiB0aGUgZ3JpZE9wdGlvbnMuXHJcbiAgICAgKiAgICAgQWxsIGlucHV0IGNvbmZpZ3VyYXRpb25zIHdpbGwgYmUgc3RvcmVkIGluIHRhYmxlSW5wdXRDb250ZXh0IChncmlkT3B0aW9ucy5jb250ZXh0LnRhYmxlSW5wdXRDb250ZXh0KVxyXG4gICAgICogICAgIFN0cnVjdHVyZSBpcyBhcyBmb2xsb3dzOlxyXG4gICAgICogICAgICAgICBkZWxpbWl0ZXI6IH5cclxuICAgICAqICAgICAgICAgY29udGV4dEtleTogW2dyaWRJZF1bZGVsaW1pdGVyXVtjb2x1bW5JZF1bZGVsaW1pdGVyXVtyb3dJZF1cclxuICAgICAqICAgICAgICAgICAgIChlLmcuIHRhYmxlRm9ybX5pbnB1dENvbHVtbn4xKVxyXG4gICAgICogICAgICAgICBxdWVzdGlvbjoge1xyXG4gICAgICogICAgICAgICAgICAgcXVlc3Rpb25LZXk6IHF1ZXN0aW9uIGNvbmZpZ3VyYXRpb25zLFxyXG4gICAgICogICAgICAgICAgICAgcXVlc3Rpb25LZXk6IHF1ZXN0aW9uIGNvbmZpZ3VyYXRpb25zXHJcbiAgICAgKiAgICAgICAgIH1cclxuICAgICAqICAgICAgICAgICAgIChlLmcuIHtcclxuICAgICAqICAgICAgICAgICAgICAgICBpbnB1dEtleToge1xyXG4gICAgICogICAgICAgICAgICAgICAgICAgICBjb250cm9sVHlwZTogJ3RleHQnLFxyXG4gICAgICogICAgICAgICAgICAgICAgICAgICBrZXk6ICdpbnB1dEtleScsXHJcbiAgICAgKiAgICAgICAgICAgICAgICAgICAgIHZpc2libGU6IHRydWUsXHJcbiAgICAgKiAgICAgICAgICAgICAgICAgICAgIGRpc2FibGVkOiBmYWxzZSxcclxuICAgICAqICAgICAgICAgICAgICAgICAgICAgdmFsdWU6ICdUZXh0J1xyXG4gICAgICogICAgICAgICAgICAgICAgIH0sXHJcbiAgICAgKiAgICAgICAgICAgICAgICAgZHJvcGRvd25LZXk6IHtcclxuICAgICAqICAgICAgICAgICAgICAgICAgICAgY29udHJvbFR5cGU6ICdkcm9wZG93bicsXHJcbiAgICAgKiAgICAgICAgICAgICAgICAgICAgIGtleTogJ2Ryb3Bkb3duS2V5JyxcclxuICAgICAqICAgICAgICAgICAgICAgICAgICAgdmlzaWJsZTogdHJ1ZSxcclxuICAgICAqICAgICAgICAgICAgICAgICAgICAgdmFsdWU6ICcxJyxcclxuICAgICAqICAgICAgICAgICAgICAgICAgICAgb3B0aW9uczogW1xyXG4gICAgICogICAgICAgICAgICAgICAgICAgICAgICAge1xyXG4gICAgICogICAgICAgICAgICAgICAgICAgICAgICAgICAgIGtleTogJycsXHJcbiAgICAgKiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU6ICctLSBQbGVhc2Ugc2VsZWN0IC0tJ1xyXG4gICAgICogICAgICAgICAgICAgICAgICAgICAgICAgfSxcclxuICAgICAqICAgICAgICAgICAgICAgICAgICAgICAgIHtcclxuICAgICAqICAgICAgICAgICAgICAgICAgICAgICAgICAgICBrZXk6ICcxJyxcclxuICAgICAqICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZTogJ0ZlbWFsZSdcclxuICAgICAqICAgICAgICAgICAgICAgICAgICAgICAgIH0sXHJcbiAgICAgKiAgICAgICAgICAgICAgICAgICAgICAgICB7XHJcbiAgICAgKiAgICAgICAgICAgICAgICAgICAgICAgICAgICAga2V5OiAnMicsXHJcbiAgICAgKiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU6ICdNYWxlJ1xyXG4gICAgICogICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICogICAgICAgICAgICAgICAgICAgICBdXHJcbiAgICAgKiAgICAgICAgICAgICAgICAgfVxyXG4gICAgICogICAgICAgICAgICAgfSlcclxuICAgICAqXHJcbiAgICAgKlxyXG4gICAgICogICAgICAgICBjb250ZXh0LnRhYmxlSW5wdXRDb250ZXh0W2NvbnRleHRLZXldID0gcXVlc3Rpb25cclxuICAgICAqIF1cclxuICAgICAqIF9jb2x1bW4gICAgOiBbQ29sdW1uIGNvbmZpZ3VyYXRpb25zXVxyXG4gICAgICogX3JvdyAgICAgICA6IFtSb3cgZGF0YV1cclxuICAgICAqIF9ncmlkSWQgICAgOiBbR3JpZCBJRF1cclxuICAgICAqL1xyXG4gICAgcHJpdmF0ZSBfZ2VuZXJhdGVUYWJsZUlucHV0Q29udGV4dChfY29sdW1uOiBBcnJheTxJVGFibGVDb2x1bW4+LCBfcm93OiBBcnJheTxhbnk+LCBfZ3JpZElkOiBzdHJpbmcpOiB7IFtrZXk6IHN0cmluZ106IGFueSB9IHtcclxuICAgICAgICBsZXQgdGFibGVJbnB1dENvbnRleHQ6IGFueSA9IHt9O1xyXG5cclxuICAgICAgICBmb3IgKGxldCBpOiBudW1iZXIgPSAwOyBpIDwgX2NvbHVtbi5sZW5ndGg7ICsraSkge1xyXG4gICAgICAgICAgICBpZiAodGhpcy5pc0lucHV0VHlwZShfY29sdW1uW2ldLCAnaW5wdXQnKSkge1xyXG4gICAgICAgICAgICAgICAgbGV0IGN1cnJlbnRDb2x1bW46IElUYWJsZUNvbHVtbiA9IF9jb2x1bW5baV07XHJcbiAgICAgICAgICAgICAgICBsZXQgY3VycmVudENvbHVtbklkOiBzdHJpbmcgPSBjdXJyZW50Q29sdW1uLmZpZWxkO1xyXG5cclxuICAgICAgICAgICAgICAgIGZvciAobGV0IGo6IG51bWJlciA9IDA7IGogPCBfcm93Lmxlbmd0aDsgKytqKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKHR5cGVvZiBfcm93W2pdW3RoaXMucm93S2V5XSAhPT0gJ3VuZGVmaW5lZCcpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgbGV0IGNvbnRleHRPYmplY3Q6IGFueSA9IHt9O1xyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgLy8gY29uc29sZS5sb2coJy0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0nKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgLy8gY29uc29sZS5sb2coJ2N1cnJlbnRDb2x1bW4gLSAnLCBjdXJyZW50Q29sdW1uKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgLy8gY29uc29sZS5sb2coJ2N1cnJlbnRDb2x1bW5JZCAtICcsIGN1cnJlbnRDb2x1bW5JZCk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC8vIGNvbnNvbGUubG9nKCdfcm93W2pdIC0gJywgX3Jvd1tqXSk7XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAvLyBTZXQgdGhlIHJvdyBkYXRhIHdpdGggdGhlIGNvbHVtbiBrZXkgaWYgaXMgbm90IGRlZmluZWRcclxuICAgICAgICAgICAgICAgICAgICAgICAgaWYgKHR5cGVvZiBfcm93W2pdW2N1cnJlbnRDb2x1bW5JZF0gPT09ICd1bmRlZmluZWQnKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBfcm93W2pdW2N1cnJlbnRDb2x1bW5JZF0gPSB7fTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgLy8gU2V0IHRoZSBpbnB1dCB0byB0aGUgY29udGV4dE9iamVjdFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAodHlwZW9mIGN1cnJlbnRDb2x1bW4uY29uZmlnICE9PSAndW5kZWZpbmVkJyAmJiB0eXBlb2YgY3VycmVudENvbHVtbi5jb25maWcuaW5wdXQgIT09ICd1bmRlZmluZWQnKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBsZXQgcHJvY2Vzc0lucHV0RGF0YTogQXJyYXk8SVRhYmxlRm9ybUlucHV0PiA9IChjdXJyZW50Q29sdW1uLmNvbmZpZy5pbnB1dCBpbnN0YW5jZW9mIEFycmF5KSA/IGN1cnJlbnRDb2x1bW4uY29uZmlnLmlucHV0IDogW2N1cnJlbnRDb2x1bW4uY29uZmlnLmlucHV0XTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxldCByb3dDb2x1bW5EYXRhOiBhbnkgPSBfcm93W2pdW2N1cnJlbnRDb2x1bW5JZF07XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgZm9yIChsZXQgazogbnVtYmVyID0gMDsgayA8IHByb2Nlc3NJbnB1dERhdGEubGVuZ3RoOyArK2spIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyBTZXQgdGhlIHJvdyBkYXRhIGlucHV0IGtleSB2YWx1ZSBpZiBubyBpbnB1dCBrZXkgb2YgdGhlIGNvbHVtbiBpcyBkZWZpbmVkXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKHR5cGVvZiByb3dDb2x1bW5EYXRhW3Byb2Nlc3NJbnB1dERhdGFba10ua2V5XSA9PT0gJ3VuZGVmaW5lZCcpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcm93Q29sdW1uRGF0YVtwcm9jZXNzSW5wdXREYXRhW2tdLmtleV0gPSAnJztcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnRleHRPYmplY3RbcHJvY2Vzc0lucHV0RGF0YVtrXS5rZXldID0gKDxhbnk+T2JqZWN0KS5hc3NpZ24oe30sIHByb2Nlc3NJbnB1dERhdGFba10pO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnRleHRPYmplY3RbcHJvY2Vzc0lucHV0RGF0YVtrXS5rZXldLnZhbHVlID0gcm93Q29sdW1uRGF0YVtwcm9jZXNzSW5wdXREYXRhW2tdLmtleV07XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgZWxzZSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb25zb2xlLmVycm9yKCdLZFRhYmxlIGVycm9yIC0gQ29sdW1uIHNwZWNpZnkgYXMgaW5wdXQgYnV0IG5vIGNvbmZpZyBwYXNzZWQgaW4uIE5vIGlucHV0IHdpbGwgYmUgZ2VuZXJhdGVkLicpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICBsZXQgY29udGV4dEtleTogc3RyaW5nID0gdGhpcy5nZW5lcmF0ZUNvbnRleHRLZXkoX2dyaWRJZCwgY3VycmVudENvbHVtbklkLCBfcm93W2pdW3RoaXMucm93S2V5XSk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHRhYmxlSW5wdXRDb250ZXh0W2NvbnRleHRLZXldID0gKDxhbnk+T2JqZWN0KS5hc3NpZ24oe30sIGNvbnRleHRPYmplY3QpO1xyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgY29uc29sZS5lcnJvcignS2RUYWJsZSBlcnJvciAtIFJvdyBwYXNzZWQgaW4gd2l0aCBubyByb3dLZXkgKCcgKyB0aGlzLnJvd0tleSArICcpLiBJbnB1dCBjZWxsIGNvbXBvbmVudCByZXF1aXJlcyByb3dLZXkgdG8gZ2VuZXJhdGUuJyk7XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICByZXR1cm4gdGFibGVJbnB1dENvbnRleHQ7XHJcbiAgICB9XHJcblxyXG4gICAgLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy9cclxuICAgIC8vLyBTZWxlY3Rpb24gZnVuY3Rpb24gLSBSZXR1cm4gdmFsdWUgZnVuY3Rpb25zXHJcbiAgICAvLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vL1xyXG4gICAgLyoqXHJcbiAgICAgKiBbX2NvbnZlcnREYXRhVmFsdWVUb09iamVjdCAtIENvbnZlcnQgcmV0dXJuIGZyb20gZG90IHNlcGFyYXRlZCB0byBvYmplY3QgdmFsdWUuIEV4YW1wbGU6XHJcbiAgICAgKiAgICAgLSBGcm9tOiBcImluc3R1dGl0aW9uX2lkLmluc3R1dGl0aW9uX25hbWVcIjogXCJBbmRlcnNvbiBQcmltYXJ5IFNjaG9vbFwiO1xyXG4gICAgICogICAgIC0gVG8gIDogaW5zdHV0aXRpb25faWQ6IHtcclxuICAgICAqICAgICAgICAgICAgICAgICBpbnN0dXRpdGlvbl9uYW1lOlwiQW5kZXJzb24gUHJpbWFyeSBTY2hvb2xcIlxyXG4gICAgICogICAgICAgICAgICAgfTtcclxuICAgICAqIF1cclxuICAgICAqIF9jdXJyZW50SXRlbSAgICA6IFtDdXJyZW50IHNlbGVjdGlvbiBrZXldXHJcbiAgICAgKiBfb2JqS2V5ICAgICAgICAgOiBbRG90IHNlcGFyYXRlZCBvYmplY3Qga2V5c11cclxuICAgICAqIF92YWx1ZSAgICAgICAgICA6IFtEYXRhIHZhbHVlIGZvciB0aGUgb2JqZWN0XVxyXG4gICAgICpcclxuICAgICAqL1xyXG4gICAgcHJpdmF0ZSBfY29udmVydERhdGFWYWx1ZVRvT2JqZWN0KF9jdXJyZW50SXRlbTogYW55LCBfb2JqS2V5OiBzdHJpbmcsIF92YWx1ZTogYW55LCBfc2VwYXJhdG9yOiBzdHJpbmcgPSAnLicpOiBhbnkge1xyXG4gICAgICAgIGxldCBvYmplY3RLZXlBcnI6IEFycmF5PHN0cmluZz4gPSBfb2JqS2V5LnNwbGl0KF9zZXBhcmF0b3IpO1xyXG4gICAgICAgIHJldHVybiB0aGlzLl9hcHBlbmREYXRhVmFsdWVLZXkob2JqZWN0S2V5QXJyLCBfY3VycmVudEl0ZW0sIF92YWx1ZSk7XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfYXBwZW5kRGF0YVZhbHVlS2V5KF9rZXk6IEFycmF5PHN0cmluZz4sIF9jdXJyZW50T2JqOiBhbnksIF92YWx1ZTogYW55KTogYW55IHtcclxuICAgICAgICBpZiAoX2tleS5sZW5ndGggPiAwKSB7XHJcbiAgICAgICAgICAgIGxldCBjdXJyZW50S2V5OiBzdHJpbmcgPSBfa2V5WzBdO1xyXG5cclxuICAgICAgICAgICAgaWYgKHR5cGVvZiBfY3VycmVudE9ialtjdXJyZW50S2V5XSA9PT0gJ3VuZGVmaW5lZCcpIHtcclxuICAgICAgICAgICAgICAgIF9jdXJyZW50T2JqW2N1cnJlbnRLZXldID0ge307XHJcbiAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgIF9rZXkuc2hpZnQoKTtcclxuICAgICAgICAgICAgX2N1cnJlbnRPYmpbY3VycmVudEtleV0gPSB0aGlzLl9hcHBlbmREYXRhVmFsdWVLZXkoX2tleSwgX2N1cnJlbnRPYmpbY3VycmVudEtleV0sIF92YWx1ZSk7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICBfY3VycmVudE9iaiA9IF92YWx1ZTtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIHJldHVybiBfY3VycmVudE9iajtcclxuICAgIH1cclxuXHJcbiAgICAvLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vL1xyXG4gICAgLy8vIE1pc2MgZnVuY3Rpb25zXHJcbiAgICAvLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vL1xyXG4gICAgcHJpdmF0ZSBfdXBkYXRlRmlsdGVyQ29sRGVmKF9jb2xEZWY6IENvbERlZiwgX2ZpbHRlclZhbD86IEFycmF5PHN0cmluZz4pOiB2b2lkIHtcclxuICAgICAgICBfY29sRGVmLm1lbnVUYWJzID0gWydmaWx0ZXJNZW51VGFiJ107XHJcbiAgICAgICAgX2NvbERlZi5maWx0ZXIgPSAnYWdTZXRDb2x1bW5GaWx0ZXInO1xyXG4gICAgICAgIF9jb2xEZWYuZmlsdGVyUGFyYW1zID0ge1xyXG4gICAgICAgICAgICBuZXdSb3dzQWN0aW9uOiAna2VlcCcsXHJcbiAgICAgICAgICAgIGNlbGxIZWlnaHQ6IDMwLFxyXG4gICAgICAgICAgICBzZWxlY3RBbGxPbk1pbmlGaWx0ZXI6IHRydWVcclxuICAgICAgICB9O1xyXG5cclxuICAgICAgICBpZiAodHlwZW9mIF9maWx0ZXJWYWwgIT09ICd1bmRlZmluZWQnKSB7XHJcbiAgICAgICAgICAgIF9jb2xEZWYuZmlsdGVyUGFyYW1zLnZhbHVlcyA9IF9maWx0ZXJWYWw7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX2dldERlZmF1bHRDb2x1bW5Db25maWcoKTogSVRhYmxlQ29sdW1uIHtcclxuICAgICAgICByZXR1cm4ge1xyXG4gICAgICAgICAgICBzb3J0YWJsZTogZmFsc2UsXHJcbiAgICAgICAgICAgIGZpbHRlcmFibGU6IGZhbHNlLFxyXG4gICAgICAgICAgICB2aXNpYmxlOiB0cnVlLFxyXG4gICAgICAgIH07XHJcbiAgICB9XHJcblxyXG4gICAgLyoqKioqKioqKioqKioqKioqKioqKioqKiogRW5kIG9mIHByaXZhdGUgZnVuY3Rpb25zICoqKioqKioqKioqKioqKioqKioqKioqKioqL1xyXG59XHJcbiJdfQ==