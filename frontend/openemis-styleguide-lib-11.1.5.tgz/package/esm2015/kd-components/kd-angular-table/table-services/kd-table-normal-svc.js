import { Injectable } from '@angular/core';
import { KdTableSvcBase } from './kd-table-svc';
/**
 * -- Documentation for kd-table-normal-svc.ts --
 *
 * Public function:
 *     - Grid Options function
 *         - generateGridOptions (GridOption generation with gridConfig)
 *         - setGridOptions
 *     - Column definition functions
 *         - setColumnDef (Column Definitions based on columnConfig and gridConfig)
 *         - generateColumnDefinitions
 *     - Row data functions
 *         - setRowData (Set the rowData to the grid)
 *
 * Private functions:
 *     - Grid Options function
 *         - _generateConfigOptions (additional GridOption from table config)
 *     - Row height functions
 *         - _getRowHeight
 *         - _calculateRowHeight
 *         - _getQuestionHeight
 */
export class KdTableNormalSvc extends KdTableSvcBase {
    constructor() {
        super(...arguments);
        this._movableColumn = false;
        /************************* End of private functions **************************/
    }
    /***************************** Public functions ******************************/
    ////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// Grid options functions
    ////////////////////////////////////////////////////////////////////////////////////////////////////////
    generateGridOptions(_gridConfig, _direction) {
        let tempGridOptions = super.getDefaultGridOptions(_direction, _gridConfig.rowContentHeight);
        delete tempGridOptions.rowHeight;
        let configOptions = this._generateConfigOptions(_gridConfig);
        Object.assign(tempGridOptions, configOptions);
        return tempGridOptions;
    }
    setGridOptions(_gridOptions) {
        this.gridOptions = _gridOptions;
    }
    ////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// Column definition functions
    ////////////////////////////////////////////////////////////////////////////////////////////////////////
    setColumnDef(_colDefConfig, _gridConfig, _suppressMovableColumns = true) {
        let updatedColumn = this.generateColumnDefinitions(_colDefConfig, _gridConfig, _suppressMovableColumns);
        this.gridOptions.columnDefs = updatedColumn;
        if (super.isApiReady(this.gridOptions)) {
            this.gridOptions.api.setColumnDefs(updatedColumn);
        }
    }
    generateColumnDefinitions(_colDefConfig, _gridConfig, _suppressMovableColumns = true) {
        return super.generateColumnDefinitions(_colDefConfig, _gridConfig, _suppressMovableColumns);
    }
    ////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// Row Data functions
    ////////////////////////////////////////////////////////////////////////////////////////////////////////
    setRowData(_rowData) {
        this.gridOptions.rowData = _rowData;
        if (super.isApiReady(this.gridOptions)) {
            this.gridOptions.api.setRowData(_rowData);
        }
    }
    /************ End of public functions / Start of private functions ***********/
    ////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// Grid options functions
    ////////////////////////////////////////////////////////////////////////////////////////////////////////
    _generateConfigOptions(_config) {
        let sidebarValue = false;
        if ('pivot' in _config) {
            sidebarValue = _config.pivot.state.pivotMode;
        }
        let configOptions = {
            rowModelType: 'clientSide',
            enableSorting: true,
            enableFilter: true,
            getRowHeight: (_params) => {
                return this._getRowHeight(_params);
            },
            sideBar: sidebarValue,
            context: _config.context
        };
        if (typeof _config.rowIdKey !== 'undefined') {
            this.rowKey = _config.rowIdKey;
            configOptions.getRowNodeId = (_data) => {
                if (_data.hasOwnProperty(_config.rowIdKey)) {
                    let id = _data[_config.rowIdKey];
                    if (typeof _data[_config.rowIdKey] === 'number') {
                        id = id.toString();
                    }
                    return id;
                }
                else if (_data.hasOwnProperty('data')) {
                    let id = _data.data[_config.rowIdKey];
                    if (typeof _data.data[_config.rowIdKey] === 'number') {
                        id = id.toString();
                    }
                    return id;
                }
                return '';
            };
        }
        return configOptions;
    }
    ////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// Row Height functions
    ////////////////////////////////////////////////////////////////////////////////////////////////////////
    _getRowHeight(_params) {
        let maxHeight = this.ROW_HEIGHT;
        let allColumns = _params.node.columnApi.getAllColumns();
        let columnHeight = 0;
        for (let i = 0; i < allColumns.length; ++i) {
            columnHeight = this.ROW_HEIGHT;
            if (super.isColDefOfType(allColumns[i].getColDef(), this.GIRD_PARAMS_KEY.input)) {
                let contextKey = super.generateContextKey(_params.context.gridId, allColumns[i].getColDef().colId, _params.node.id);
                if (_params.context[this.TABLE_INPUT_CONTEXT_KEY].hasOwnProperty(contextKey)) {
                    columnHeight = this._calculateRowHeight(_params.context[this.TABLE_INPUT_CONTEXT_KEY][contextKey]);
                }
            }
            if (super.isColDefOfType(allColumns[i].getColDef(), this.GIRD_PARAMS_KEY.image)) {
                const defaultColHeight = 150;
                if (typeof allColumns[i].getColDef().cellRendererParams.params.imageConfig.height !== 'undefined') {
                    columnHeight = allColumns[i].getColDef().cellRendererParams.params.imageConfig.height + this.IMAGE_PADDING;
                }
                else {
                    columnHeight = defaultColHeight + this.IMAGE_PADDING;
                }
            }
            if (columnHeight > maxHeight) {
                maxHeight = columnHeight;
            }
        }
        return maxHeight;
    }
    _calculateRowHeight(_contextData) {
        let height = 0;
        for (let item in _contextData) {
            if (_contextData.hasOwnProperty(item)) {
                height += this._getQuestionHeight(_contextData[item]);
            }
        }
        return height;
    }
    _getQuestionHeight(_tableDataItem) {
        let height = 0;
        if (_tableDataItem.visible) {
            height += 50;
        }
        if (_tableDataItem.visible && _tableDataItem.controlType === 'textarea') {
            height += 70;
        }
        return height;
    }
}
KdTableNormalSvc.decorators = [
    { type: Injectable }
];
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoia2QtdGFibGUtbm9ybWFsLXN2Yy5qcyIsInNvdXJjZVJvb3QiOiJDOi94YW1wcC9odGRvY3MvU3R5bGVndWlkZS9pb3N0Zy1vcGVuZW1pcy1zdHlsZWd1aWRlL3Byb2plY3RzL29wZW5lbWlzLXN0eWxlZ3VpZGUtbGliL3NyYy8iLCJzb3VyY2VzIjpbImtkLWNvbXBvbmVudHMva2QtYW5ndWxhci10YWJsZS90YWJsZS1zZXJ2aWNlcy9rZC10YWJsZS1ub3JtYWwtc3ZjLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBLE9BQU8sRUFBRSxVQUFVLEVBQUUsTUFBTSxlQUFlLENBQUM7QUFZM0MsT0FBTyxFQUFFLGNBQWMsRUFBRSxNQUFNLGdCQUFnQixDQUFDO0FBRWhEOzs7Ozs7Ozs7Ozs7Ozs7Ozs7OztHQW9CRztBQUdILE1BQU0sT0FBTyxnQkFBaUIsU0FBUSxjQUFjO0lBRHBEOztRQUVZLG1CQUFjLEdBQVksS0FBSyxDQUFDO1FBZ0t4QywrRUFBK0U7SUFDbkYsQ0FBQztJQWhLRywrRUFBK0U7SUFDL0Usd0dBQXdHO0lBQ3hHLDBCQUEwQjtJQUMxQix3R0FBd0c7SUFDakcsbUJBQW1CLENBQUMsV0FBeUIsRUFBRSxVQUF5QjtRQUMzRSxJQUFJLGVBQWUsR0FBZ0IsS0FBSyxDQUFDLHFCQUFxQixDQUFDLFVBQVUsRUFBRSxXQUFXLENBQUMsZ0JBQWdCLENBQUMsQ0FBQztRQUV6RyxPQUFPLGVBQWUsQ0FBQyxTQUFTLENBQUM7UUFDakMsSUFBSSxhQUFhLEdBQWdCLElBQUksQ0FBQyxzQkFBc0IsQ0FBQyxXQUFXLENBQUMsQ0FBQztRQUVwRSxNQUFPLENBQUMsTUFBTSxDQUFDLGVBQWUsRUFBRSxhQUFhLENBQUMsQ0FBQztRQUVyRCxPQUFPLGVBQWUsQ0FBQztJQUMzQixDQUFDO0lBRU0sY0FBYyxDQUFDLFlBQXlCO1FBQzNDLElBQUksQ0FBQyxXQUFXLEdBQUcsWUFBWSxDQUFDO0lBQ3BDLENBQUM7SUFFRCx3R0FBd0c7SUFDeEcsK0JBQStCO0lBQy9CLHdHQUF3RztJQUNqRyxZQUFZLENBQUMsYUFBa0MsRUFBRSxXQUF5QixFQUFFLDBCQUFtQyxJQUFJO1FBQ3RILElBQUksYUFBYSxHQUFrQixJQUFJLENBQUMseUJBQXlCLENBQUMsYUFBYSxFQUFFLFdBQVcsRUFBRSx1QkFBdUIsQ0FBQyxDQUFDO1FBRXZILElBQUksQ0FBQyxXQUFXLENBQUMsVUFBVSxHQUFHLGFBQWEsQ0FBQztRQUU1QyxJQUFJLEtBQUssQ0FBQyxVQUFVLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxFQUFFO1lBQ3BDLElBQUksQ0FBQyxXQUFXLENBQUMsR0FBRyxDQUFDLGFBQWEsQ0FBQyxhQUFhLENBQUMsQ0FBQztTQUNyRDtJQUNMLENBQUM7SUFFTSx5QkFBeUIsQ0FBQyxhQUFrQyxFQUFFLFdBQXlCLEVBQUUsMEJBQW1DLElBQUk7UUFDbkksT0FBTyxLQUFLLENBQUMseUJBQXlCLENBQUMsYUFBYSxFQUFFLFdBQVcsRUFBRSx1QkFBdUIsQ0FBQyxDQUFDO0lBQ2hHLENBQUM7SUFFRCx3R0FBd0c7SUFDeEcsc0JBQXNCO0lBQ3RCLHdHQUF3RztJQUNqRyxVQUFVLENBQUMsUUFBb0I7UUFDbEMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxPQUFPLEdBQUcsUUFBUSxDQUFDO1FBQ3BDLElBQUksS0FBSyxDQUFDLFVBQVUsQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFDLEVBQUU7WUFDcEMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxHQUFHLENBQUMsVUFBVSxDQUFDLFFBQVEsQ0FBQyxDQUFDO1NBQzdDO0lBQ0wsQ0FBQztJQUVELCtFQUErRTtJQUMvRSx3R0FBd0c7SUFDeEcsMEJBQTBCO0lBQzFCLHdHQUF3RztJQUNoRyxzQkFBc0IsQ0FBQyxPQUFxQjtRQUNoRCxJQUFJLFlBQVksR0FBRyxLQUFLLENBQUM7UUFDekIsSUFBRyxPQUFPLElBQUksT0FBTyxFQUFFO1lBQ25CLFlBQVksR0FBRyxPQUFPLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxTQUFTLENBQUM7U0FDaEQ7UUFDRCxJQUFJLGFBQWEsR0FBZ0I7WUFDN0IsWUFBWSxFQUFFLFlBQVk7WUFDMUIsYUFBYSxFQUFFLElBQUk7WUFDbkIsWUFBWSxFQUFFLElBQUk7WUFDbEIsWUFBWSxFQUFFLENBQUMsT0FBWSxFQUFVLEVBQUU7Z0JBQ25DLE9BQU8sSUFBSSxDQUFDLGFBQWEsQ0FBQyxPQUFPLENBQUMsQ0FBQztZQUN2QyxDQUFDO1lBQ0QsT0FBTyxFQUFHLFlBQVk7WUFDdEIsT0FBTyxFQUFFLE9BQU8sQ0FBQyxPQUFPO1NBQzNCLENBQUM7UUFFRixJQUFJLE9BQU8sT0FBTyxDQUFDLFFBQVEsS0FBSyxXQUFXLEVBQUU7WUFDekMsSUFBSSxDQUFDLE1BQU0sR0FBRyxPQUFPLENBQUMsUUFBUSxDQUFDO1lBRS9CLGFBQWEsQ0FBQyxZQUFZLEdBQUcsQ0FBQyxLQUFVLEVBQVUsRUFBRTtnQkFDaEQsSUFBSSxLQUFLLENBQUMsY0FBYyxDQUFDLE9BQU8sQ0FBQyxRQUFRLENBQUMsRUFBRTtvQkFDeEMsSUFBSSxFQUFFLEdBQVcsS0FBSyxDQUFDLE9BQU8sQ0FBQyxRQUFRLENBQUMsQ0FBQztvQkFFekMsSUFBSSxPQUFPLEtBQUssQ0FBQyxPQUFPLENBQUMsUUFBUSxDQUFDLEtBQUssUUFBUSxFQUFFO3dCQUM3QyxFQUFFLEdBQUcsRUFBRSxDQUFDLFFBQVEsRUFBRSxDQUFDO3FCQUN0QjtvQkFFRCxPQUFPLEVBQUUsQ0FBQztpQkFDYjtxQkFBSyxJQUFHLEtBQUssQ0FBQyxjQUFjLENBQUMsTUFBTSxDQUFDLEVBQUM7b0JBQ2xDLElBQUksRUFBRSxHQUFXLEtBQUssQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLFFBQVEsQ0FBQyxDQUFDO29CQUU5QyxJQUFJLE9BQU8sS0FBSyxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsUUFBUSxDQUFDLEtBQUssUUFBUSxFQUFFO3dCQUNsRCxFQUFFLEdBQUcsRUFBRSxDQUFDLFFBQVEsRUFBRSxDQUFDO3FCQUN0QjtvQkFFRCxPQUFPLEVBQUUsQ0FBQztpQkFDYjtnQkFFRCxPQUFPLEVBQUUsQ0FBQztZQUNkLENBQUMsQ0FBQztTQUNMO1FBRUQsT0FBTyxhQUFhLENBQUM7SUFDekIsQ0FBQztJQUVELHdHQUF3RztJQUN4Ryx3QkFBd0I7SUFDeEIsd0dBQXdHO0lBQ2hHLGFBQWEsQ0FBQyxPQUErRDtRQUNqRixJQUFJLFNBQVMsR0FBVyxJQUFJLENBQUMsVUFBVSxDQUFDO1FBQ3hDLElBQUksVUFBVSxHQUF3QixPQUFPLENBQUMsSUFBSyxDQUFDLFNBQVMsQ0FBQyxhQUFhLEVBQUUsQ0FBQztRQUM5RSxJQUFJLFlBQVksR0FBVyxDQUFDLENBQUM7UUFFN0IsS0FBSyxJQUFJLENBQUMsR0FBVyxDQUFDLEVBQUUsQ0FBQyxHQUFHLFVBQVUsQ0FBQyxNQUFNLEVBQUUsRUFBRSxDQUFDLEVBQUU7WUFDaEQsWUFBWSxHQUFHLElBQUksQ0FBQyxVQUFVLENBQUM7WUFFL0IsSUFBSSxLQUFLLENBQUMsY0FBYyxDQUFDLFVBQVUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxTQUFTLEVBQUUsRUFBRSxJQUFJLENBQUMsZUFBZSxDQUFDLEtBQUssQ0FBQyxFQUFFO2dCQUM3RSxJQUFJLFVBQVUsR0FBVyxLQUFLLENBQUMsa0JBQWtCLENBQUMsT0FBTyxDQUFDLE9BQU8sQ0FBQyxNQUFNLEVBQUUsVUFBVSxDQUFDLENBQUMsQ0FBQyxDQUFDLFNBQVMsRUFBRSxDQUFDLEtBQUssRUFBRSxPQUFPLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxDQUFDO2dCQUU1SCxJQUFJLE9BQU8sQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLHVCQUF1QixDQUFDLENBQUMsY0FBYyxDQUFDLFVBQVUsQ0FBQyxFQUFFO29CQUMxRSxZQUFZLEdBQUcsSUFBSSxDQUFDLG1CQUFtQixDQUFDLE9BQU8sQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLHVCQUF1QixDQUFDLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQztpQkFDdEc7YUFDSjtZQUVELElBQUksS0FBSyxDQUFDLGNBQWMsQ0FBQyxVQUFVLENBQUMsQ0FBQyxDQUFDLENBQUMsU0FBUyxFQUFFLEVBQUUsSUFBSSxDQUFDLGVBQWUsQ0FBQyxLQUFLLENBQUMsRUFBRTtnQkFDN0UsTUFBTSxnQkFBZ0IsR0FBVyxHQUFHLENBQUM7Z0JBRXJDLElBQUksT0FBTyxVQUFVLENBQUMsQ0FBQyxDQUFDLENBQUMsU0FBUyxFQUFFLENBQUMsa0JBQWtCLENBQUMsTUFBTSxDQUFDLFdBQVcsQ0FBQyxNQUFNLEtBQUssV0FBVyxFQUFFO29CQUMvRixZQUFZLEdBQUcsVUFBVSxDQUFDLENBQUMsQ0FBQyxDQUFDLFNBQVMsRUFBRSxDQUFDLGtCQUFrQixDQUFDLE1BQU0sQ0FBQyxXQUFXLENBQUMsTUFBTSxHQUFHLElBQUksQ0FBQyxhQUFhLENBQUM7aUJBQzlHO3FCQUNJO29CQUNELFlBQVksR0FBRyxnQkFBZ0IsR0FBRyxJQUFJLENBQUMsYUFBYSxDQUFDO2lCQUN4RDthQUNKO1lBRUQsSUFBSSxZQUFZLEdBQUcsU0FBUyxFQUFFO2dCQUMxQixTQUFTLEdBQUcsWUFBWSxDQUFDO2FBQzVCO1NBQ0o7UUFFRCxPQUFPLFNBQVMsQ0FBQztJQUNyQixDQUFDO0lBRU8sbUJBQW1CLENBQUMsWUFBaUI7UUFDekMsSUFBSSxNQUFNLEdBQVcsQ0FBQyxDQUFDO1FBRXZCLEtBQUssSUFBSSxJQUFJLElBQUksWUFBWSxFQUFFO1lBQzNCLElBQUksWUFBWSxDQUFDLGNBQWMsQ0FBQyxJQUFJLENBQUMsRUFBRTtnQkFDbkMsTUFBTSxJQUFJLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxZQUFZLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQzthQUN6RDtTQUNKO1FBRUQsT0FBTyxNQUFNLENBQUM7SUFDbEIsQ0FBQztJQUVPLGtCQUFrQixDQUFDLGNBQW1CO1FBQzFDLElBQUksTUFBTSxHQUFXLENBQUMsQ0FBQztRQUV2QixJQUFJLGNBQWMsQ0FBQyxPQUFPLEVBQUU7WUFDeEIsTUFBTSxJQUFJLEVBQUUsQ0FBQztTQUNoQjtRQUVELElBQUksY0FBYyxDQUFDLE9BQU8sSUFBSSxjQUFjLENBQUMsV0FBVyxLQUFLLFVBQVUsRUFBRTtZQUNyRSxNQUFNLElBQUksRUFBRSxDQUFDO1NBQ2hCO1FBRUQsT0FBTyxNQUFNLENBQUM7SUFDbEIsQ0FBQzs7O1lBaEtKLFVBQVUiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBJbmplY3RhYmxlIH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XHJcbmltcG9ydCB7XHJcbiAgICBHcmlkT3B0aW9ucyxcclxuICAgIENvbERlZixcclxuICAgIENvbHVtbixcclxuICAgIFJvd05vZGUsXHJcbiAgICBHcmlkQXBpXHJcbn0gZnJvbSAnYWctZ3JpZC1jb21tdW5pdHknO1xyXG5pbXBvcnQge1xyXG4gICAgSVRhYmxlQ29sdW1uLFxyXG4gICAgSVRhYmxlQ29uZmlnXHJcbn0gZnJvbSAnLi4va2QtYW5ndWxhci10YWJsZS1pbnRlcmZhY2UnO1xyXG5pbXBvcnQgeyBLZFRhYmxlU3ZjQmFzZSB9IGZyb20gJy4va2QtdGFibGUtc3ZjJztcclxuXHJcbi8qKlxyXG4gKiAtLSBEb2N1bWVudGF0aW9uIGZvciBrZC10YWJsZS1ub3JtYWwtc3ZjLnRzIC0tXHJcbiAqXHJcbiAqIFB1YmxpYyBmdW5jdGlvbjpcclxuICogICAgIC0gR3JpZCBPcHRpb25zIGZ1bmN0aW9uXHJcbiAqICAgICAgICAgLSBnZW5lcmF0ZUdyaWRPcHRpb25zIChHcmlkT3B0aW9uIGdlbmVyYXRpb24gd2l0aCBncmlkQ29uZmlnKVxyXG4gKiAgICAgICAgIC0gc2V0R3JpZE9wdGlvbnNcclxuICogICAgIC0gQ29sdW1uIGRlZmluaXRpb24gZnVuY3Rpb25zXHJcbiAqICAgICAgICAgLSBzZXRDb2x1bW5EZWYgKENvbHVtbiBEZWZpbml0aW9ucyBiYXNlZCBvbiBjb2x1bW5Db25maWcgYW5kIGdyaWRDb25maWcpXHJcbiAqICAgICAgICAgLSBnZW5lcmF0ZUNvbHVtbkRlZmluaXRpb25zXHJcbiAqICAgICAtIFJvdyBkYXRhIGZ1bmN0aW9uc1xyXG4gKiAgICAgICAgIC0gc2V0Um93RGF0YSAoU2V0IHRoZSByb3dEYXRhIHRvIHRoZSBncmlkKVxyXG4gKlxyXG4gKiBQcml2YXRlIGZ1bmN0aW9uczpcclxuICogICAgIC0gR3JpZCBPcHRpb25zIGZ1bmN0aW9uXHJcbiAqICAgICAgICAgLSBfZ2VuZXJhdGVDb25maWdPcHRpb25zIChhZGRpdGlvbmFsIEdyaWRPcHRpb24gZnJvbSB0YWJsZSBjb25maWcpXHJcbiAqICAgICAtIFJvdyBoZWlnaHQgZnVuY3Rpb25zXHJcbiAqICAgICAgICAgLSBfZ2V0Um93SGVpZ2h0XHJcbiAqICAgICAgICAgLSBfY2FsY3VsYXRlUm93SGVpZ2h0XHJcbiAqICAgICAgICAgLSBfZ2V0UXVlc3Rpb25IZWlnaHRcclxuICovXHJcblxyXG5ASW5qZWN0YWJsZSgpXHJcbmV4cG9ydCBjbGFzcyBLZFRhYmxlTm9ybWFsU3ZjIGV4dGVuZHMgS2RUYWJsZVN2Y0Jhc2Uge1xyXG4gICAgcHJpdmF0ZSBfbW92YWJsZUNvbHVtbjogYm9vbGVhbiA9IGZhbHNlO1xyXG4gICAgLyoqKioqKioqKioqKioqKioqKioqKioqKioqKioqIFB1YmxpYyBmdW5jdGlvbnMgKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqL1xyXG4gICAgLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy9cclxuICAgIC8vLyBHcmlkIG9wdGlvbnMgZnVuY3Rpb25zXHJcbiAgICAvLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vL1xyXG4gICAgcHVibGljIGdlbmVyYXRlR3JpZE9wdGlvbnMoX2dyaWRDb25maWc6IElUYWJsZUNvbmZpZywgX2RpcmVjdGlvbjogJ2x0cicgfCAncnRsJyk6IEdyaWRPcHRpb25zIHtcclxuICAgICAgICBsZXQgdGVtcEdyaWRPcHRpb25zOiBHcmlkT3B0aW9ucyA9IHN1cGVyLmdldERlZmF1bHRHcmlkT3B0aW9ucyhfZGlyZWN0aW9uLCBfZ3JpZENvbmZpZy5yb3dDb250ZW50SGVpZ2h0KTtcclxuXHJcbiAgICAgICAgZGVsZXRlIHRlbXBHcmlkT3B0aW9ucy5yb3dIZWlnaHQ7XHJcbiAgICAgICAgbGV0IGNvbmZpZ09wdGlvbnM6IEdyaWRPcHRpb25zID0gdGhpcy5fZ2VuZXJhdGVDb25maWdPcHRpb25zKF9ncmlkQ29uZmlnKTtcclxuXHJcbiAgICAgICAgKDxhbnk+T2JqZWN0KS5hc3NpZ24odGVtcEdyaWRPcHRpb25zLCBjb25maWdPcHRpb25zKTtcclxuXHJcbiAgICAgICAgcmV0dXJuIHRlbXBHcmlkT3B0aW9ucztcclxuICAgIH1cclxuXHJcbiAgICBwdWJsaWMgc2V0R3JpZE9wdGlvbnMoX2dyaWRPcHRpb25zOiBHcmlkT3B0aW9ucyk6IHZvaWQge1xyXG4gICAgICAgIHRoaXMuZ3JpZE9wdGlvbnMgPSBfZ3JpZE9wdGlvbnM7XHJcbiAgICB9XHJcblxyXG4gICAgLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy9cclxuICAgIC8vLyBDb2x1bW4gZGVmaW5pdGlvbiBmdW5jdGlvbnNcclxuICAgIC8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vXHJcbiAgICBwdWJsaWMgc2V0Q29sdW1uRGVmKF9jb2xEZWZDb25maWc6IEFycmF5PElUYWJsZUNvbHVtbj4sIF9ncmlkQ29uZmlnOiBJVGFibGVDb25maWcsIF9zdXBwcmVzc01vdmFibGVDb2x1bW5zOiBib29sZWFuID0gdHJ1ZSk6IHZvaWQge1xyXG4gICAgICAgIGxldCB1cGRhdGVkQ29sdW1uOiBBcnJheTxDb2xEZWY+ID0gdGhpcy5nZW5lcmF0ZUNvbHVtbkRlZmluaXRpb25zKF9jb2xEZWZDb25maWcsIF9ncmlkQ29uZmlnLCBfc3VwcHJlc3NNb3ZhYmxlQ29sdW1ucyk7XHJcblxyXG4gICAgICAgIHRoaXMuZ3JpZE9wdGlvbnMuY29sdW1uRGVmcyA9IHVwZGF0ZWRDb2x1bW47XHJcblxyXG4gICAgICAgIGlmIChzdXBlci5pc0FwaVJlYWR5KHRoaXMuZ3JpZE9wdGlvbnMpKSB7XHJcbiAgICAgICAgICAgIHRoaXMuZ3JpZE9wdGlvbnMuYXBpLnNldENvbHVtbkRlZnModXBkYXRlZENvbHVtbik7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIHB1YmxpYyBnZW5lcmF0ZUNvbHVtbkRlZmluaXRpb25zKF9jb2xEZWZDb25maWc6IEFycmF5PElUYWJsZUNvbHVtbj4sIF9ncmlkQ29uZmlnOiBJVGFibGVDb25maWcsIF9zdXBwcmVzc01vdmFibGVDb2x1bW5zOiBib29sZWFuID0gdHJ1ZSk6IEFycmF5PENvbERlZj4ge1xyXG4gICAgICAgIHJldHVybiBzdXBlci5nZW5lcmF0ZUNvbHVtbkRlZmluaXRpb25zKF9jb2xEZWZDb25maWcsIF9ncmlkQ29uZmlnLCBfc3VwcHJlc3NNb3ZhYmxlQ29sdW1ucyk7XHJcbiAgICB9XHJcblxyXG4gICAgLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy9cclxuICAgIC8vLyBSb3cgRGF0YSBmdW5jdGlvbnNcclxuICAgIC8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vXHJcbiAgICBwdWJsaWMgc2V0Um93RGF0YShfcm93RGF0YTogQXJyYXk8YW55Pik6IHZvaWQge1xyXG4gICAgICAgIHRoaXMuZ3JpZE9wdGlvbnMucm93RGF0YSA9IF9yb3dEYXRhO1xyXG4gICAgICAgIGlmIChzdXBlci5pc0FwaVJlYWR5KHRoaXMuZ3JpZE9wdGlvbnMpKSB7XHJcbiAgICAgICAgICAgIHRoaXMuZ3JpZE9wdGlvbnMuYXBpLnNldFJvd0RhdGEoX3Jvd0RhdGEpO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICAvKioqKioqKioqKioqIEVuZCBvZiBwdWJsaWMgZnVuY3Rpb25zIC8gU3RhcnQgb2YgcHJpdmF0ZSBmdW5jdGlvbnMgKioqKioqKioqKiovXHJcbiAgICAvLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vL1xyXG4gICAgLy8vIEdyaWQgb3B0aW9ucyBmdW5jdGlvbnNcclxuICAgIC8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vXHJcbiAgICBwcml2YXRlIF9nZW5lcmF0ZUNvbmZpZ09wdGlvbnMoX2NvbmZpZzogSVRhYmxlQ29uZmlnKTogR3JpZE9wdGlvbnMge1xyXG4gICAgICAgIGxldCBzaWRlYmFyVmFsdWUgPSBmYWxzZTtcclxuICAgICAgICBpZigncGl2b3QnIGluIF9jb25maWcpIHtcclxuICAgICAgICAgICAgc2lkZWJhclZhbHVlID0gX2NvbmZpZy5waXZvdC5zdGF0ZS5waXZvdE1vZGU7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGxldCBjb25maWdPcHRpb25zOiBHcmlkT3B0aW9ucyA9IHtcclxuICAgICAgICAgICAgcm93TW9kZWxUeXBlOiAnY2xpZW50U2lkZScsXHJcbiAgICAgICAgICAgIGVuYWJsZVNvcnRpbmc6IHRydWUsXHJcbiAgICAgICAgICAgIGVuYWJsZUZpbHRlcjogdHJ1ZSxcclxuICAgICAgICAgICAgZ2V0Um93SGVpZ2h0OiAoX3BhcmFtczogYW55KTogbnVtYmVyID0+IHtcclxuICAgICAgICAgICAgICAgIHJldHVybiB0aGlzLl9nZXRSb3dIZWlnaHQoX3BhcmFtcyk7XHJcbiAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgIHNpZGVCYXIgOiBzaWRlYmFyVmFsdWUsXHJcbiAgICAgICAgICAgIGNvbnRleHQ6IF9jb25maWcuY29udGV4dFxyXG4gICAgICAgIH07XHJcblxyXG4gICAgICAgIGlmICh0eXBlb2YgX2NvbmZpZy5yb3dJZEtleSAhPT0gJ3VuZGVmaW5lZCcpIHtcclxuICAgICAgICAgICAgdGhpcy5yb3dLZXkgPSBfY29uZmlnLnJvd0lkS2V5O1xyXG5cclxuICAgICAgICAgICAgY29uZmlnT3B0aW9ucy5nZXRSb3dOb2RlSWQgPSAoX2RhdGE6IGFueSk6IHN0cmluZyA9PiB7XHJcbiAgICAgICAgICAgICAgICBpZiAoX2RhdGEuaGFzT3duUHJvcGVydHkoX2NvbmZpZy5yb3dJZEtleSkpIHtcclxuICAgICAgICAgICAgICAgICAgICBsZXQgaWQ6IHN0cmluZyA9IF9kYXRhW19jb25maWcucm93SWRLZXldO1xyXG5cclxuICAgICAgICAgICAgICAgICAgICBpZiAodHlwZW9mIF9kYXRhW19jb25maWcucm93SWRLZXldID09PSAnbnVtYmVyJykge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBpZCA9IGlkLnRvU3RyaW5nKCk7XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgICAgICAgICByZXR1cm4gaWQ7XHJcbiAgICAgICAgICAgICAgICB9ZWxzZSBpZihfZGF0YS5oYXNPd25Qcm9wZXJ0eSgnZGF0YScpKXtcclxuICAgICAgICAgICAgICAgICAgICBsZXQgaWQ6IHN0cmluZyA9IF9kYXRhLmRhdGFbX2NvbmZpZy5yb3dJZEtleV07XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIGlmICh0eXBlb2YgX2RhdGEuZGF0YVtfY29uZmlnLnJvd0lkS2V5XSA9PT0gJ251bWJlcicpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgaWQgPSBpZC50b1N0cmluZygpO1xyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIGlkO1xyXG4gICAgICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgICAgIHJldHVybiAnJztcclxuICAgICAgICAgICAgfTtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIHJldHVybiBjb25maWdPcHRpb25zO1xyXG4gICAgfVxyXG5cclxuICAgIC8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vXHJcbiAgICAvLy8gUm93IEhlaWdodCBmdW5jdGlvbnNcclxuICAgIC8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vXHJcbiAgICBwcml2YXRlIF9nZXRSb3dIZWlnaHQoX3BhcmFtczoge25vZGU6IFJvd05vZGUsIGRhdGE6IGFueSwgYXBpOiBHcmlkQXBpLCBjb250ZXh0OiBhbnl9KTogbnVtYmVyIHtcclxuICAgICAgICBsZXQgbWF4SGVpZ2h0OiBudW1iZXIgPSB0aGlzLlJPV19IRUlHSFQ7XHJcbiAgICAgICAgbGV0IGFsbENvbHVtbnM6IEFycmF5PENvbHVtbj4gPSAoPGFueT5fcGFyYW1zLm5vZGUpLmNvbHVtbkFwaS5nZXRBbGxDb2x1bW5zKCk7XHJcbiAgICAgICAgbGV0IGNvbHVtbkhlaWdodDogbnVtYmVyID0gMDtcclxuXHJcbiAgICAgICAgZm9yIChsZXQgaTogbnVtYmVyID0gMDsgaSA8IGFsbENvbHVtbnMubGVuZ3RoOyArK2kpIHtcclxuICAgICAgICAgICAgY29sdW1uSGVpZ2h0ID0gdGhpcy5ST1dfSEVJR0hUO1xyXG5cclxuICAgICAgICAgICAgaWYgKHN1cGVyLmlzQ29sRGVmT2ZUeXBlKGFsbENvbHVtbnNbaV0uZ2V0Q29sRGVmKCksIHRoaXMuR0lSRF9QQVJBTVNfS0VZLmlucHV0KSkge1xyXG4gICAgICAgICAgICAgICAgbGV0IGNvbnRleHRLZXk6IHN0cmluZyA9IHN1cGVyLmdlbmVyYXRlQ29udGV4dEtleShfcGFyYW1zLmNvbnRleHQuZ3JpZElkLCBhbGxDb2x1bW5zW2ldLmdldENvbERlZigpLmNvbElkLCBfcGFyYW1zLm5vZGUuaWQpO1xyXG5cclxuICAgICAgICAgICAgICAgIGlmIChfcGFyYW1zLmNvbnRleHRbdGhpcy5UQUJMRV9JTlBVVF9DT05URVhUX0tFWV0uaGFzT3duUHJvcGVydHkoY29udGV4dEtleSkpIHtcclxuICAgICAgICAgICAgICAgICAgICBjb2x1bW5IZWlnaHQgPSB0aGlzLl9jYWxjdWxhdGVSb3dIZWlnaHQoX3BhcmFtcy5jb250ZXh0W3RoaXMuVEFCTEVfSU5QVVRfQ09OVEVYVF9LRVldW2NvbnRleHRLZXldKTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgaWYgKHN1cGVyLmlzQ29sRGVmT2ZUeXBlKGFsbENvbHVtbnNbaV0uZ2V0Q29sRGVmKCksIHRoaXMuR0lSRF9QQVJBTVNfS0VZLmltYWdlKSkge1xyXG4gICAgICAgICAgICAgICAgY29uc3QgZGVmYXVsdENvbEhlaWdodDogbnVtYmVyID0gMTUwO1xyXG5cclxuICAgICAgICAgICAgICAgIGlmICh0eXBlb2YgYWxsQ29sdW1uc1tpXS5nZXRDb2xEZWYoKS5jZWxsUmVuZGVyZXJQYXJhbXMucGFyYW1zLmltYWdlQ29uZmlnLmhlaWdodCAhPT0gJ3VuZGVmaW5lZCcpIHtcclxuICAgICAgICAgICAgICAgICAgICBjb2x1bW5IZWlnaHQgPSBhbGxDb2x1bW5zW2ldLmdldENvbERlZigpLmNlbGxSZW5kZXJlclBhcmFtcy5wYXJhbXMuaW1hZ2VDb25maWcuaGVpZ2h0ICsgdGhpcy5JTUFHRV9QQURESU5HO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgZWxzZSB7XHJcbiAgICAgICAgICAgICAgICAgICAgY29sdW1uSGVpZ2h0ID0gZGVmYXVsdENvbEhlaWdodCArIHRoaXMuSU1BR0VfUEFERElORztcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgaWYgKGNvbHVtbkhlaWdodCA+IG1heEhlaWdodCkge1xyXG4gICAgICAgICAgICAgICAgbWF4SGVpZ2h0ID0gY29sdW1uSGVpZ2h0O1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICByZXR1cm4gbWF4SGVpZ2h0O1xyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX2NhbGN1bGF0ZVJvd0hlaWdodChfY29udGV4dERhdGE6IGFueSk6IG51bWJlciB7XHJcbiAgICAgICAgbGV0IGhlaWdodDogbnVtYmVyID0gMDtcclxuXHJcbiAgICAgICAgZm9yIChsZXQgaXRlbSBpbiBfY29udGV4dERhdGEpIHtcclxuICAgICAgICAgICAgaWYgKF9jb250ZXh0RGF0YS5oYXNPd25Qcm9wZXJ0eShpdGVtKSkge1xyXG4gICAgICAgICAgICAgICAgaGVpZ2h0ICs9IHRoaXMuX2dldFF1ZXN0aW9uSGVpZ2h0KF9jb250ZXh0RGF0YVtpdGVtXSk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIHJldHVybiBoZWlnaHQ7XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfZ2V0UXVlc3Rpb25IZWlnaHQoX3RhYmxlRGF0YUl0ZW06IGFueSk6IG51bWJlciB7XHJcbiAgICAgICAgbGV0IGhlaWdodDogbnVtYmVyID0gMDtcclxuXHJcbiAgICAgICAgaWYgKF90YWJsZURhdGFJdGVtLnZpc2libGUpIHtcclxuICAgICAgICAgICAgaGVpZ2h0ICs9IDUwO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgaWYgKF90YWJsZURhdGFJdGVtLnZpc2libGUgJiYgX3RhYmxlRGF0YUl0ZW0uY29udHJvbFR5cGUgPT09ICd0ZXh0YXJlYScpIHtcclxuICAgICAgICAgICAgaGVpZ2h0ICs9IDcwO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgcmV0dXJuIGhlaWdodDtcclxuICAgIH1cclxuXHJcbiAgICAvKioqKioqKioqKioqKioqKioqKioqKioqKiBFbmQgb2YgcHJpdmF0ZSBmdW5jdGlvbnMgKioqKioqKioqKioqKioqKioqKioqKioqKiovXHJcbn1cclxuIl19