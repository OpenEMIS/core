import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { KdTableSvcBase } from './kd-table-svc';
/**
 * -- Documentation for kd-table-enterprise-svc.ts --
 *
 * Public function:
 *     - Grid Options function
 *         - generateGridOptions (GridOption generation with gridConfig)
 *         - setGridOptions
 *     - Column definition functions
 *         - setColumnDef (Column Definitions based on columnConfig and gridConfig)
 *         - generateColumnDefinitions
 *     - Row data functions
 *         - setRowData (Set the rowData to the grid)
 *     - Datasource function
 *         - generateDatasourceRows (manual sorting / filtering of the datasource - For oneshot and infinite loadType)
 *
 * Public functions (from parent) - Overrides:
 *     - updateSelectionValues
 *
 * Private functions:
 *     - Grid Options function
 *         - _generateConfigOptions (additional GridOption from table config)
 *     - Column definition functions
 *         - _checkCheckboxSelectionType (Checking for selection type all - Infinite loadType not able to load)
 *         - _updateColDefConfig  (NOTE: Removing input columns here)
 *         - _checkColDefFilterableVal
 *     - Datasource function
 *         - _datasourceSortRow
 *         - _datasourceRowSortFormula
 *         - _datasourceFilterRow
 *     - Misc functions
 *         - _retrievePagesize
 */
export class KdTableEnterpriseSvc extends KdTableSvcBase {
    /***************************** Public functions ******************************/
    ////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// Grid options functions
    ////////////////////////////////////////////////////////////////////////////////////////////////////////
    generateGridOptions(_gridConfig, _direction) {
        let tempGridOptions = super.getDefaultGridOptions(_direction, _gridConfig.rowContentHeight);
        let configOptions = this._generateConfigOptions(_gridConfig);
        Object.assign(tempGridOptions, configOptions);
        return tempGridOptions;
    }
    setGridOptions(_gridOptions) {
        this.gridOptions = _gridOptions;
    }
    ////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// Column definitions functions
    ////////////////////////////////////////////////////////////////////////////////////////////////////////
    setColumnDef(_colDefConfig, _gridConfig, _suppressMovableColumns = true) {
        let updatedColumn = this.generateColumnDefinitions(_colDefConfig, _gridConfig, _suppressMovableColumns);
        this.gridOptions.columnDefs = updatedColumn;
        if (super.isApiReady(this.gridOptions)) {
            this.gridOptions.api.setColumnDefs(updatedColumn);
        }
        // if (super.hasInputType(_colDefConfig, 'image')) {
        //     this._updateRowHeightForImg(_colDefConfig);
        // }
    }
    generateColumnDefinitions(_colDefConfig, _gridConfig, _suppressMovableColumns = true) {
        let updatedColDefConfig = this._updateColDefConfig(_colDefConfig);
        let generatedColDef = super.generateColumnDefinitions(updatedColDefConfig, _gridConfig, _suppressMovableColumns);
        this._checkCheckboxSelectionType(_gridConfig, generatedColDef);
        return generatedColDef;
    }
    ////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// Row Data functions
    ////////////////////////////////////////////////////////////////////////////////////////////////////////
    setRowData(_rowData) {
        this.gridOptions.rowData = _rowData;
    }
    ////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// Datasource functions
    ////////////////////////////////////////////////////////////////////////////////////////////////////////
    generateDatasourceRows(_datasourceRequest, _rowData) {
        return new Observable((_observer) => {
            // console.log('-- Grid state: generate Datasource rows --', _datasourceRequest);
            let tempRowModel = this._datasourceFilterRow(_datasourceRequest.filterModel, _rowData);
            this._datasourceSortRow(_datasourceRequest.sortModel, tempRowModel);
            let requestObj = {
                rows: tempRowModel.slice(_datasourceRequest.startRow, _datasourceRequest.endRow),
                total: tempRowModel.length
            };
            _observer.next(requestObj);
            _observer.complete();
        });
    }
    /************************ Public functions from parent ***********************/
    ////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// Overrides
    ////////////////////////////////////////////////////////////////////////////////////////////////////////
    updateSelectionValues(_rowData, _selectedId, _returnKey, _loadType) {
        if (_loadType === 'server' && typeof _returnKey !== 'undefined' && _returnKey.length > 0) {
            console.warn('KdTable warning: Selection value not able to return as objects specify in the returnKey property as there might have unknown data values for server loadType.');
            return _selectedId;
        }
        return super.updateSelectionValues(_rowData, _selectedId, _returnKey);
    }
    /************ End of public functions / Start of private functions ***********/
    ////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// Grid options functions
    ////////////////////////////////////////////////////////////////////////////////////////////////////////
    _generateConfigOptions(_config) {
        let pagesize = this._retrievePagesize(_config.paginationConfig);
        let configOptions = {
            rowModelType: 'enterprise',
            enableServerSideFilter: true,
            enableServerSideSorting: true,
            maxConcurrentDatasourceRequests: 2,
            cacheOverflowSize: 1,
            rowGroupPanelShow: 'never',
            toolPanelSuppressPivotMode: true,
            toolPanelSuppressValues: true,
            cacheBlockSize: pagesize
        };
        if (typeof _config.rowIdKey !== 'undefined') {
            this.rowKey = _config.rowIdKey;
            configOptions.getRowNodeId = (_data) => {
                if (_data.hasOwnProperty(_config.rowIdKey)) {
                    let id = _data[_config.rowIdKey];
                    if (typeof _data[_config.rowIdKey] === 'number') {
                        id = id.toString();
                    }
                    return id;
                }
                return '';
            };
        }
        if (typeof _config !== 'undefined' && typeof _config.loadType !== 'undefined') {
            if (_config.loadType !== 'infinite') {
                configOptions.pagination = true;
                configOptions.maxBlocksInCache = 0;
                configOptions.paginationPageSize = pagesize;
            }
            else {
                // Auto height takes a lot of height, will cause infinite retrieving issue
                configOptions.maxBlocksInCache = 5;
            }
            if (_config.loadType == 'normal') {
                configOptions.sideBar = true;
            }
            else {
                configOptions.sideBar = false;
            }
        }
        return configOptions;
    }
    ////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// Column definitions functions
    ////////////////////////////////////////////////////////////////////////////////////////////////////////
    _checkCheckboxSelectionType(_gridConfig, _colDefs) {
        if (typeof _gridConfig.selection !== 'undefined' &&
            typeof _gridConfig.selection.type !== 'undefined' &&
            typeof _gridConfig.loadType !== 'undefined' &&
            _gridConfig.selection.type === 'all' &&
            _gridConfig.loadType === 'infinite') {
            console.warn('KdTable warning: Infinite loadType not able to support all selectionType.');
            delete _colDefs[0].headerComponentFramework;
        }
    }
    _updateColDefConfig(_colDefConfig) {
        let updatedColDefConfig = [];
        for (let i = 0; i < _colDefConfig.length; i++) {
            if (super.isInputType(_colDefConfig[i], 'input')) {
                console.error('KdTable error: input column type is only valid for normal loadType table. Removing columns with input type.');
            }
            else {
                this._checkColDefFilterableVal(_colDefConfig[i]);
                updatedColDefConfig.push(_colDefConfig[i]);
            }
        }
        return updatedColDefConfig;
    }
    _checkColDefFilterableVal(_colDefItem) {
        if (typeof _colDefItem.filterable !== 'undefined' && _colDefItem.filterable &&
            (typeof _colDefItem.filterValue === 'undefined' || _colDefItem.filterValue === null || _colDefItem.filterValue.length === 0)) {
            console.error('KdTable error: Filter value for ' + _colDefItem.field + ' field is empty. Using filter for loadType oneshot/infinite/server requires to provide filterValue. Suppressing filtering menu.');
            _colDefItem.filterable = false;
        }
    }
    // private _updateRowHeightForImg(_colDefConfig: Array<ITableColumn>): void {
    //     let maxHeight: number = 50;
    //     for (let i: number = 0; i < _colDefConfig.length; ++i) {
    //         if (super.isInputType(_colDefConfig[i], 'image')) {
    //             let tempHeight: number = super.getImageSizeBy(_colDefConfig[i], 'height');
    //             if (tempHeight > maxHeight) {
    //                 maxHeight = tempHeight;
    //             }
    //         }
    //     }
    //     console.log('row height max: ', maxHeight);
    //     this.gridOptions.rowHeight = maxHeight;
    // }
    ////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// Datasource sort / filter functions
    ////////////////////////////////////////////////////////////////////////////////////////////////////////
    _datasourceSortRow(_sortModel, _rowData) {
        if (_sortModel.length > 0) {
            let sortOptions = _sortModel[0];
            let returnCondition = (sortOptions.sort === 'asc') ? 1 : -1;
            _rowData.sort((_a, _b) => {
                return this._datasourceRowSortFormula(_a, _b, sortOptions.colId, returnCondition);
            });
        }
    }
    _datasourceRowSortFormula(_a, _b, _dotDisplayFrom, _returnVal) {
        if (typeof _a !== 'undefined' && typeof _b !== 'undefined') {
            let aVal = this.dataSvc.getDataValue(_a, _dotDisplayFrom);
            let bVal = this.dataSvc.getDataValue(_b, _dotDisplayFrom);
            if (aVal > bVal)
                return _returnVal;
            else if (aVal < bVal)
                return -(_returnVal);
            return 0;
        }
        return 0;
    }
    _datasourceFilterRow(_filterModel, _rowData) {
        let tempRowModel = [];
        if (Object.keys(_filterModel).length > 0) {
            for (let item in _filterModel) {
                if (_filterModel.hasOwnProperty(item)) {
                    let dataKey = item;
                    let filterModelItem = _filterModel[item].values;
                    if (filterModelItem.length > 0) {
                        for (let i = 0; i < _rowData.length; i++) {
                            let rowItem = _rowData[i];
                            if (rowItem.hasOwnProperty(dataKey) && filterModelItem.indexOf(rowItem[dataKey]) > -1) {
                                tempRowModel.push(rowItem);
                            }
                        }
                    }
                    else {
                        tempRowModel = [];
                        break;
                    }
                }
            }
        }
        else {
            tempRowModel = _rowData.slice();
        }
        return tempRowModel;
    }
    ////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// Misc functions
    ////////////////////////////////////////////////////////////////////////////////////////////////////////
    _retrievePagesize(_paginationConfig) {
        if (typeof _paginationConfig !== 'undefined' &&
            typeof _paginationConfig.pagesize !== 'undefined') {
            return _paginationConfig.pagesize;
        }
        _paginationConfig.pagesize = this.DEFAULT_PAGESIZE;
        return this.DEFAULT_PAGESIZE;
    }
}
KdTableEnterpriseSvc.decorators = [
    { type: Injectable }
];
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoia2QtdGFibGUtZW50ZXJwcmlzZS1zdmMuanMiLCJzb3VyY2VSb290IjoiQzoveGFtcHAvaHRkb2NzL1N0eWxlZ3VpZGUvaW9zdGctb3BlbmVtaXMtc3R5bGVndWlkZS9wcm9qZWN0cy9vcGVuZW1pcy1zdHlsZWd1aWRlLWxpYi9zcmMvIiwic291cmNlcyI6WyJrZC1jb21wb25lbnRzL2tkLWFuZ3VsYXItdGFibGUvdGFibGUtc2VydmljZXMva2QtdGFibGUtZW50ZXJwcmlzZS1zdmMudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsT0FBTyxFQUFFLFVBQVUsRUFBRSxNQUFNLGVBQWUsQ0FBQztBQUMzQyxPQUFPLEVBQUUsVUFBVSxFQUFnQixNQUFNLE1BQU0sQ0FBQztBQWNoRCxPQUFPLEVBQUUsY0FBYyxFQUFFLE1BQU0sZ0JBQWdCLENBQUM7QUFFaEQ7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7R0ErQkc7QUFHSCxNQUFNLE9BQU8sb0JBQXFCLFNBQVEsY0FBYztJQUNwRCwrRUFBK0U7SUFDL0Usd0dBQXdHO0lBQ3hHLDBCQUEwQjtJQUMxQix3R0FBd0c7SUFDakcsbUJBQW1CLENBQUMsV0FBeUIsRUFBRSxVQUF5QjtRQUMzRSxJQUFJLGVBQWUsR0FBZ0IsS0FBSyxDQUFDLHFCQUFxQixDQUFDLFVBQVUsRUFBRSxXQUFXLENBQUMsZ0JBQWdCLENBQUMsQ0FBQztRQUN6RyxJQUFJLGFBQWEsR0FBZ0IsSUFBSSxDQUFDLHNCQUFzQixDQUFDLFdBQVcsQ0FBQyxDQUFDO1FBRXBFLE1BQU8sQ0FBQyxNQUFNLENBQUMsZUFBZSxFQUFFLGFBQWEsQ0FBQyxDQUFDO1FBRXJELE9BQU8sZUFBZSxDQUFDO0lBQzNCLENBQUM7SUFFTSxjQUFjLENBQUMsWUFBeUI7UUFDM0MsSUFBSSxDQUFDLFdBQVcsR0FBRyxZQUFZLENBQUM7SUFDcEMsQ0FBQztJQUVELHdHQUF3RztJQUN4RyxnQ0FBZ0M7SUFDaEMsd0dBQXdHO0lBQ2pHLFlBQVksQ0FBQyxhQUFrQyxFQUFFLFdBQXlCLEVBQUUsMEJBQW1DLElBQUk7UUFDdEgsSUFBSSxhQUFhLEdBQWtCLElBQUksQ0FBQyx5QkFBeUIsQ0FBQyxhQUFhLEVBQUUsV0FBVyxFQUFFLHVCQUF1QixDQUFDLENBQUM7UUFFdkgsSUFBSSxDQUFDLFdBQVcsQ0FBQyxVQUFVLEdBQUcsYUFBYSxDQUFDO1FBQzVDLElBQUksS0FBSyxDQUFDLFVBQVUsQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFDLEVBQUU7WUFDcEMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxHQUFHLENBQUMsYUFBYSxDQUFDLGFBQWEsQ0FBQyxDQUFDO1NBQ3JEO1FBRUQsb0RBQW9EO1FBQ3BELGtEQUFrRDtRQUNsRCxJQUFJO0lBQ1IsQ0FBQztJQUVNLHlCQUF5QixDQUFDLGFBQWtDLEVBQUUsV0FBeUIsRUFBRSwwQkFBbUMsSUFBSTtRQUNuSSxJQUFJLG1CQUFtQixHQUF3QixJQUFJLENBQUMsbUJBQW1CLENBQUMsYUFBYSxDQUFDLENBQUM7UUFFdkYsSUFBSSxlQUFlLEdBQWtCLEtBQUssQ0FBQyx5QkFBeUIsQ0FBQyxtQkFBbUIsRUFBRSxXQUFXLEVBQUUsdUJBQXVCLENBQUMsQ0FBQztRQUNoSSxJQUFJLENBQUMsMkJBQTJCLENBQUMsV0FBVyxFQUFFLGVBQWUsQ0FBQyxDQUFDO1FBRS9ELE9BQVEsZUFBZSxDQUFDO0lBQzVCLENBQUM7SUFFRCx3R0FBd0c7SUFDeEcsc0JBQXNCO0lBQ3RCLHdHQUF3RztJQUNqRyxVQUFVLENBQUMsUUFBb0I7UUFDbEMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxPQUFPLEdBQUcsUUFBUSxDQUFDO0lBQ3hDLENBQUM7SUFFRCx3R0FBd0c7SUFDeEcsd0JBQXdCO0lBQ3hCLHdHQUF3RztJQUNqRyxzQkFBc0IsQ0FBQyxrQkFBNkMsRUFBRSxRQUFvQjtRQUM3RixPQUFPLElBQUksVUFBVSxDQUFNLENBQUMsU0FBMEIsRUFBUSxFQUFFO1lBQzVELGlGQUFpRjtZQUVqRixJQUFJLFlBQVksR0FBZSxJQUFJLENBQUMsb0JBQW9CLENBQUMsa0JBQWtCLENBQUMsV0FBVyxFQUFFLFFBQVEsQ0FBQyxDQUFDO1lBQ25HLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxrQkFBa0IsQ0FBQyxTQUFTLEVBQUUsWUFBWSxDQUFDLENBQUM7WUFFcEUsSUFBSSxVQUFVLEdBQXNDO2dCQUNoRCxJQUFJLEVBQUUsWUFBWSxDQUFDLEtBQUssQ0FBQyxrQkFBa0IsQ0FBQyxRQUFRLEVBQUUsa0JBQWtCLENBQUMsTUFBTSxDQUFDO2dCQUNoRixLQUFLLEVBQUUsWUFBWSxDQUFDLE1BQU07YUFDN0IsQ0FBQztZQUVGLFNBQVMsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLENBQUM7WUFDM0IsU0FBUyxDQUFDLFFBQVEsRUFBRSxDQUFDO1FBQ3pCLENBQUMsQ0FBQyxDQUFDO0lBQ1AsQ0FBQztJQUVELCtFQUErRTtJQUMvRSx3R0FBd0c7SUFDeEcsYUFBYTtJQUNiLHdHQUF3RztJQUNqRyxxQkFBcUIsQ0FBQyxRQUFvQixFQUFFLFdBQW1DLEVBQUUsVUFBeUIsRUFBRSxTQUFpQjtRQUNoSSxJQUFJLFNBQVMsS0FBSyxRQUFRLElBQUksT0FBTyxVQUFVLEtBQUssV0FBVyxJQUFJLFVBQVUsQ0FBQyxNQUFNLEdBQUcsQ0FBQyxFQUFFO1lBQ3RGLE9BQU8sQ0FBQyxJQUFJLENBQUMsK0pBQStKLENBQUMsQ0FBQztZQUM5SyxPQUFPLFdBQVcsQ0FBQztTQUN0QjtRQUNELE9BQU8sS0FBSyxDQUFDLHFCQUFxQixDQUFDLFFBQVEsRUFBRSxXQUFXLEVBQUUsVUFBVSxDQUFDLENBQUM7SUFDMUUsQ0FBQztJQUVELCtFQUErRTtJQUMvRSx3R0FBd0c7SUFDeEcsMEJBQTBCO0lBQzFCLHdHQUF3RztJQUNoRyxzQkFBc0IsQ0FBQyxPQUFxQjtRQUNoRCxJQUFJLFFBQVEsR0FBVyxJQUFJLENBQUMsaUJBQWlCLENBQUMsT0FBTyxDQUFDLGdCQUFnQixDQUFDLENBQUM7UUFFeEUsSUFBSSxhQUFhLEdBQWdCO1lBQzdCLFlBQVksRUFBRSxZQUFZO1lBQzFCLHNCQUFzQixFQUFFLElBQUk7WUFDNUIsdUJBQXVCLEVBQUUsSUFBSTtZQUU3QiwrQkFBK0IsRUFBRSxDQUFDO1lBQ2xDLGlCQUFpQixFQUFFLENBQUM7WUFFcEIsaUJBQWlCLEVBQUUsT0FBTztZQUMxQiwwQkFBMEIsRUFBRSxJQUFJO1lBQ2hDLHVCQUF1QixFQUFFLElBQUk7WUFFN0IsY0FBYyxFQUFFLFFBQVE7U0FDM0IsQ0FBQztRQUVGLElBQUksT0FBTyxPQUFPLENBQUMsUUFBUSxLQUFLLFdBQVcsRUFBRTtZQUN6QyxJQUFJLENBQUMsTUFBTSxHQUFHLE9BQU8sQ0FBQyxRQUFRLENBQUM7WUFFL0IsYUFBYSxDQUFDLFlBQVksR0FBRyxDQUFDLEtBQVUsRUFBVSxFQUFFO2dCQUNoRCxJQUFJLEtBQUssQ0FBQyxjQUFjLENBQUMsT0FBTyxDQUFDLFFBQVEsQ0FBQyxFQUFFO29CQUN4QyxJQUFJLEVBQUUsR0FBVyxLQUFLLENBQUMsT0FBTyxDQUFDLFFBQVEsQ0FBQyxDQUFDO29CQUV6QyxJQUFJLE9BQU8sS0FBSyxDQUFDLE9BQU8sQ0FBQyxRQUFRLENBQUMsS0FBSyxRQUFRLEVBQUU7d0JBQzdDLEVBQUUsR0FBRyxFQUFFLENBQUMsUUFBUSxFQUFFLENBQUM7cUJBQ3RCO29CQUVELE9BQU8sRUFBRSxDQUFDO2lCQUNiO2dCQUVELE9BQU8sRUFBRSxDQUFDO1lBQ2QsQ0FBQyxDQUFDO1NBQ0w7UUFFRCxJQUFJLE9BQU8sT0FBTyxLQUFLLFdBQVcsSUFBSSxPQUFPLE9BQU8sQ0FBQyxRQUFRLEtBQUssV0FBVyxFQUFFO1lBQzNFLElBQUksT0FBTyxDQUFDLFFBQVEsS0FBSyxVQUFVLEVBQUU7Z0JBQ2pDLGFBQWEsQ0FBQyxVQUFVLEdBQUcsSUFBSSxDQUFDO2dCQUNoQyxhQUFhLENBQUMsZ0JBQWdCLEdBQUcsQ0FBQyxDQUFDO2dCQUVuQyxhQUFhLENBQUMsa0JBQWtCLEdBQUcsUUFBUSxDQUFDO2FBQy9DO2lCQUNJO2dCQUNELDBFQUEwRTtnQkFDMUUsYUFBYSxDQUFDLGdCQUFnQixHQUFHLENBQUMsQ0FBQzthQUN0QztZQUNELElBQUksT0FBTyxDQUFDLFFBQVEsSUFBSSxRQUFRLEVBQUU7Z0JBQzlCLGFBQWEsQ0FBQyxPQUFPLEdBQUksSUFBSSxDQUFDO2FBQ2pDO2lCQUFNO2dCQUNILGFBQWEsQ0FBQyxPQUFPLEdBQUksS0FBSyxDQUFDO2FBQ2xDO1NBQ0o7UUFFRCxPQUFPLGFBQWEsQ0FBQztJQUN6QixDQUFDO0lBRUQsd0dBQXdHO0lBQ3hHLGdDQUFnQztJQUNoQyx3R0FBd0c7SUFDaEcsMkJBQTJCLENBQUMsV0FBeUIsRUFBRSxRQUF1QjtRQUNsRixJQUFJLE9BQU8sV0FBVyxDQUFDLFNBQVMsS0FBSyxXQUFXO1lBQzVDLE9BQU8sV0FBVyxDQUFDLFNBQVMsQ0FBQyxJQUFJLEtBQUssV0FBVztZQUNqRCxPQUFPLFdBQVcsQ0FBQyxRQUFRLEtBQUssV0FBVztZQUMzQyxXQUFXLENBQUMsU0FBUyxDQUFDLElBQUksS0FBSyxLQUFLO1lBQ3BDLFdBQVcsQ0FBQyxRQUFRLEtBQUssVUFBVSxFQUFFO1lBQ2pDLE9BQU8sQ0FBQyxJQUFJLENBQUMsMkVBQTJFLENBQUMsQ0FBQztZQUMxRixPQUFPLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyx3QkFBd0IsQ0FBQztTQUNuRDtJQUNMLENBQUM7SUFFTyxtQkFBbUIsQ0FBQyxhQUFrQztRQUMxRCxJQUFJLG1CQUFtQixHQUF3QixFQUFFLENBQUM7UUFFbEQsS0FBSyxJQUFJLENBQUMsR0FBVyxDQUFDLEVBQUUsQ0FBQyxHQUFHLGFBQWEsQ0FBQyxNQUFNLEVBQUUsQ0FBQyxFQUFFLEVBQUU7WUFDbkQsSUFBSSxLQUFLLENBQUMsV0FBVyxDQUFDLGFBQWEsQ0FBQyxDQUFDLENBQUMsRUFBRSxPQUFPLENBQUMsRUFBRTtnQkFDOUMsT0FBTyxDQUFDLEtBQUssQ0FBQyw2R0FBNkcsQ0FBQyxDQUFDO2FBQ2hJO2lCQUNJO2dCQUNELElBQUksQ0FBQyx5QkFBeUIsQ0FBQyxhQUFhLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztnQkFDakQsbUJBQW1CLENBQUMsSUFBSSxDQUFDLGFBQWEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO2FBQzlDO1NBQ0o7UUFFRCxPQUFPLG1CQUFtQixDQUFDO0lBQy9CLENBQUM7SUFFTyx5QkFBeUIsQ0FBQyxXQUF5QjtRQUN2RCxJQUFJLE9BQU8sV0FBVyxDQUFDLFVBQVUsS0FBSyxXQUFXLElBQUksV0FBVyxDQUFDLFVBQVU7WUFDdkUsQ0FBQyxPQUFPLFdBQVcsQ0FBQyxXQUFXLEtBQUssV0FBVyxJQUFJLFdBQVcsQ0FBQyxXQUFXLEtBQUssSUFBSSxJQUFJLFdBQVcsQ0FBQyxXQUFXLENBQUMsTUFBTSxLQUFLLENBQUMsQ0FBRSxFQUFFO1lBQzNILE9BQU8sQ0FBQyxLQUFLLENBQUMsa0NBQWtDLEdBQUcsV0FBVyxDQUFDLEtBQUssR0FBRyxpSUFBaUksQ0FBQyxDQUFDO1lBQzFNLFdBQVcsQ0FBQyxVQUFVLEdBQUcsS0FBSyxDQUFDO1NBQ3RDO0lBQ0wsQ0FBQztJQUVELDZFQUE2RTtJQUM3RSxrQ0FBa0M7SUFDbEMsK0RBQStEO0lBQy9ELDhEQUE4RDtJQUM5RCx5RkFBeUY7SUFFekYsNENBQTRDO0lBQzVDLDBDQUEwQztJQUMxQyxnQkFBZ0I7SUFDaEIsWUFBWTtJQUNaLFFBQVE7SUFDUixrREFBa0Q7SUFDbEQsOENBQThDO0lBQzlDLElBQUk7SUFFSix3R0FBd0c7SUFDeEcsc0NBQXNDO0lBQ3RDLHdHQUF3RztJQUNoRyxrQkFBa0IsQ0FBQyxVQUF3RCxFQUFFLFFBQW9CO1FBQ3JHLElBQUksVUFBVSxDQUFDLE1BQU0sR0FBRyxDQUFDLEVBQUU7WUFDdkIsSUFBSSxXQUFXLEdBQTBDLFVBQVUsQ0FBQyxDQUFDLENBQUMsQ0FBQztZQUN2RSxJQUFJLGVBQWUsR0FBVyxDQUFDLFdBQVcsQ0FBQyxJQUFJLEtBQUssS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7WUFFcEUsUUFBUSxDQUFDLElBQUksQ0FBQyxDQUFDLEVBQU8sRUFBRSxFQUFPLEVBQVUsRUFBRTtnQkFDdkMsT0FBTyxJQUFJLENBQUMseUJBQXlCLENBQUMsRUFBRSxFQUFFLEVBQUUsRUFBRSxXQUFXLENBQUMsS0FBSyxFQUFFLGVBQWUsQ0FBQyxDQUFDO1lBQ3RGLENBQUMsQ0FBQyxDQUFDO1NBQ047SUFDTCxDQUFDO0lBRU8seUJBQXlCLENBQUMsRUFBTyxFQUFFLEVBQU8sRUFBRSxlQUF1QixFQUFFLFVBQWtCO1FBQzNGLElBQUksT0FBTyxFQUFFLEtBQUssV0FBVyxJQUFJLE9BQU8sRUFBRSxLQUFLLFdBQVcsRUFBRTtZQUN4RCxJQUFJLElBQUksR0FBUSxJQUFJLENBQUMsT0FBTyxDQUFDLFlBQVksQ0FBQyxFQUFFLEVBQUUsZUFBZSxDQUFDLENBQUM7WUFDL0QsSUFBSSxJQUFJLEdBQVEsSUFBSSxDQUFDLE9BQU8sQ0FBQyxZQUFZLENBQUMsRUFBRSxFQUFFLGVBQWUsQ0FBQyxDQUFDO1lBRS9ELElBQUksSUFBSSxHQUFHLElBQUk7Z0JBQUUsT0FBTyxVQUFVLENBQUM7aUJBQzlCLElBQUksSUFBSSxHQUFHLElBQUk7Z0JBQUUsT0FBTyxDQUFDLENBQUMsVUFBVSxDQUFDLENBQUM7WUFDM0MsT0FBTyxDQUFDLENBQUM7U0FDWjtRQUNELE9BQU8sQ0FBQyxDQUFDO0lBQ2IsQ0FBQztJQUVPLG9CQUFvQixDQUFDLFlBQWlCLEVBQUUsUUFBb0I7UUFDaEUsSUFBSSxZQUFZLEdBQWUsRUFBRSxDQUFDO1FBRWxDLElBQUksTUFBTSxDQUFDLElBQUksQ0FBQyxZQUFZLENBQUMsQ0FBQyxNQUFNLEdBQUcsQ0FBQyxFQUFFO1lBQ3RDLEtBQUssSUFBSSxJQUFJLElBQUksWUFBWSxFQUFFO2dCQUMzQixJQUFJLFlBQVksQ0FBQyxjQUFjLENBQUMsSUFBSSxDQUFDLEVBQUU7b0JBQ25DLElBQUksT0FBTyxHQUFXLElBQUksQ0FBQztvQkFDM0IsSUFBSSxlQUFlLEdBQTJCLFlBQVksQ0FBQyxJQUFJLENBQUMsQ0FBQyxNQUFNLENBQUM7b0JBRXhFLElBQUksZUFBZSxDQUFDLE1BQU0sR0FBRyxDQUFDLEVBQUU7d0JBQzVCLEtBQUssSUFBSSxDQUFDLEdBQVcsQ0FBQyxFQUFFLENBQUMsR0FBRyxRQUFRLENBQUMsTUFBTSxFQUFFLENBQUMsRUFBRSxFQUFFOzRCQUM5QyxJQUFJLE9BQU8sR0FBUSxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUM7NEJBRS9CLElBQUksT0FBTyxDQUFDLGNBQWMsQ0FBQyxPQUFPLENBQUMsSUFBSSxlQUFlLENBQUMsT0FBTyxDQUFDLE9BQU8sQ0FBQyxPQUFPLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxFQUFFO2dDQUNuRixZQUFZLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxDQUFDOzZCQUM5Qjt5QkFDSjtxQkFDSjt5QkFDSTt3QkFDRCxZQUFZLEdBQUcsRUFBRSxDQUFDO3dCQUNsQixNQUFNO3FCQUNUO2lCQUNKO2FBQ0o7U0FDSjthQUNJO1lBQ0QsWUFBWSxHQUFHLFFBQVEsQ0FBQyxLQUFLLEVBQUUsQ0FBQztTQUNuQztRQUVELE9BQU8sWUFBWSxDQUFDO0lBQ3hCLENBQUM7SUFFRCx3R0FBd0c7SUFDeEcsa0JBQWtCO0lBQ2xCLHdHQUF3RztJQUNoRyxpQkFBaUIsQ0FBQyxpQkFBc0I7UUFDNUMsSUFBSSxPQUFPLGlCQUFpQixLQUFLLFdBQVc7WUFDeEMsT0FBTyxpQkFBaUIsQ0FBQyxRQUFRLEtBQUssV0FBVyxFQUFFO1lBQy9DLE9BQU8saUJBQWlCLENBQUMsUUFBUSxDQUFDO1NBQ3pDO1FBQ0QsaUJBQWlCLENBQUMsUUFBUSxHQUFHLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQztRQUNuRCxPQUFPLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQztJQUNqQyxDQUFDOzs7WUF6UUosVUFBVSIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IEluamVjdGFibGUgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcclxuaW1wb3J0IHsgT2JzZXJ2YWJsZSAsICBTdWJzY3JpYmVyIH0gZnJvbSAncnhqcyc7XHJcbmltcG9ydCB7XHJcbiAgICBHcmlkT3B0aW9ucyxcclxuICAgIENvbERlZixcclxuICAgIC8vIElFbnRlcnByaXNlR2V0Um93c1JlcXVlc3RcclxufSBmcm9tICdhZy1ncmlkLWNvbW11bml0eSc7XHJcblxyXG5pbXBvcnQge1xyXG4gICAgIElFbnRlcnByaXNlR2V0Um93c1JlcXVlc3RcclxufSBmcm9tICcuLi9lbnRlcnByaXNlLWRhdGFzb3VyY2UnO1xyXG5pbXBvcnQge1xyXG4gICAgSVRhYmxlQ29sdW1uLFxyXG4gICAgSVRhYmxlQ29uZmlnXHJcbn0gZnJvbSAnLi4va2QtYW5ndWxhci10YWJsZS1pbnRlcmZhY2UnO1xyXG5pbXBvcnQgeyBLZFRhYmxlU3ZjQmFzZSB9IGZyb20gJy4va2QtdGFibGUtc3ZjJztcclxuXHJcbi8qKlxyXG4gKiAtLSBEb2N1bWVudGF0aW9uIGZvciBrZC10YWJsZS1lbnRlcnByaXNlLXN2Yy50cyAtLVxyXG4gKlxyXG4gKiBQdWJsaWMgZnVuY3Rpb246XHJcbiAqICAgICAtIEdyaWQgT3B0aW9ucyBmdW5jdGlvblxyXG4gKiAgICAgICAgIC0gZ2VuZXJhdGVHcmlkT3B0aW9ucyAoR3JpZE9wdGlvbiBnZW5lcmF0aW9uIHdpdGggZ3JpZENvbmZpZylcclxuICogICAgICAgICAtIHNldEdyaWRPcHRpb25zXHJcbiAqICAgICAtIENvbHVtbiBkZWZpbml0aW9uIGZ1bmN0aW9uc1xyXG4gKiAgICAgICAgIC0gc2V0Q29sdW1uRGVmIChDb2x1bW4gRGVmaW5pdGlvbnMgYmFzZWQgb24gY29sdW1uQ29uZmlnIGFuZCBncmlkQ29uZmlnKVxyXG4gKiAgICAgICAgIC0gZ2VuZXJhdGVDb2x1bW5EZWZpbml0aW9uc1xyXG4gKiAgICAgLSBSb3cgZGF0YSBmdW5jdGlvbnNcclxuICogICAgICAgICAtIHNldFJvd0RhdGEgKFNldCB0aGUgcm93RGF0YSB0byB0aGUgZ3JpZClcclxuICogICAgIC0gRGF0YXNvdXJjZSBmdW5jdGlvblxyXG4gKiAgICAgICAgIC0gZ2VuZXJhdGVEYXRhc291cmNlUm93cyAobWFudWFsIHNvcnRpbmcgLyBmaWx0ZXJpbmcgb2YgdGhlIGRhdGFzb3VyY2UgLSBGb3Igb25lc2hvdCBhbmQgaW5maW5pdGUgbG9hZFR5cGUpXHJcbiAqXHJcbiAqIFB1YmxpYyBmdW5jdGlvbnMgKGZyb20gcGFyZW50KSAtIE92ZXJyaWRlczpcclxuICogICAgIC0gdXBkYXRlU2VsZWN0aW9uVmFsdWVzXHJcbiAqXHJcbiAqIFByaXZhdGUgZnVuY3Rpb25zOlxyXG4gKiAgICAgLSBHcmlkIE9wdGlvbnMgZnVuY3Rpb25cclxuICogICAgICAgICAtIF9nZW5lcmF0ZUNvbmZpZ09wdGlvbnMgKGFkZGl0aW9uYWwgR3JpZE9wdGlvbiBmcm9tIHRhYmxlIGNvbmZpZylcclxuICogICAgIC0gQ29sdW1uIGRlZmluaXRpb24gZnVuY3Rpb25zXHJcbiAqICAgICAgICAgLSBfY2hlY2tDaGVja2JveFNlbGVjdGlvblR5cGUgKENoZWNraW5nIGZvciBzZWxlY3Rpb24gdHlwZSBhbGwgLSBJbmZpbml0ZSBsb2FkVHlwZSBub3QgYWJsZSB0byBsb2FkKVxyXG4gKiAgICAgICAgIC0gX3VwZGF0ZUNvbERlZkNvbmZpZyAgKE5PVEU6IFJlbW92aW5nIGlucHV0IGNvbHVtbnMgaGVyZSlcclxuICogICAgICAgICAtIF9jaGVja0NvbERlZkZpbHRlcmFibGVWYWxcclxuICogICAgIC0gRGF0YXNvdXJjZSBmdW5jdGlvblxyXG4gKiAgICAgICAgIC0gX2RhdGFzb3VyY2VTb3J0Um93XHJcbiAqICAgICAgICAgLSBfZGF0YXNvdXJjZVJvd1NvcnRGb3JtdWxhXHJcbiAqICAgICAgICAgLSBfZGF0YXNvdXJjZUZpbHRlclJvd1xyXG4gKiAgICAgLSBNaXNjIGZ1bmN0aW9uc1xyXG4gKiAgICAgICAgIC0gX3JldHJpZXZlUGFnZXNpemVcclxuICovXHJcblxyXG5ASW5qZWN0YWJsZSgpXHJcbmV4cG9ydCBjbGFzcyBLZFRhYmxlRW50ZXJwcmlzZVN2YyBleHRlbmRzIEtkVGFibGVTdmNCYXNlIHtcclxuICAgIC8qKioqKioqKioqKioqKioqKioqKioqKioqKioqKiBQdWJsaWMgZnVuY3Rpb25zICoqKioqKioqKioqKioqKioqKioqKioqKioqKioqKi9cclxuICAgIC8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vXHJcbiAgICAvLy8gR3JpZCBvcHRpb25zIGZ1bmN0aW9uc1xyXG4gICAgLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy9cclxuICAgIHB1YmxpYyBnZW5lcmF0ZUdyaWRPcHRpb25zKF9ncmlkQ29uZmlnOiBJVGFibGVDb25maWcsIF9kaXJlY3Rpb246ICdsdHInIHwgJ3J0bCcpOiBHcmlkT3B0aW9ucyB7XHJcbiAgICAgICAgbGV0IHRlbXBHcmlkT3B0aW9uczogR3JpZE9wdGlvbnMgPSBzdXBlci5nZXREZWZhdWx0R3JpZE9wdGlvbnMoX2RpcmVjdGlvbiwgX2dyaWRDb25maWcucm93Q29udGVudEhlaWdodCk7XHJcbiAgICAgICAgbGV0IGNvbmZpZ09wdGlvbnM6IEdyaWRPcHRpb25zID0gdGhpcy5fZ2VuZXJhdGVDb25maWdPcHRpb25zKF9ncmlkQ29uZmlnKTtcclxuXHJcbiAgICAgICAgKDxhbnk+T2JqZWN0KS5hc3NpZ24odGVtcEdyaWRPcHRpb25zLCBjb25maWdPcHRpb25zKTtcclxuXHJcbiAgICAgICAgcmV0dXJuIHRlbXBHcmlkT3B0aW9ucztcclxuICAgIH1cclxuXHJcbiAgICBwdWJsaWMgc2V0R3JpZE9wdGlvbnMoX2dyaWRPcHRpb25zOiBHcmlkT3B0aW9ucyk6IHZvaWQge1xyXG4gICAgICAgIHRoaXMuZ3JpZE9wdGlvbnMgPSBfZ3JpZE9wdGlvbnM7XHJcbiAgICB9XHJcblxyXG4gICAgLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy9cclxuICAgIC8vLyBDb2x1bW4gZGVmaW5pdGlvbnMgZnVuY3Rpb25zXHJcbiAgICAvLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vL1xyXG4gICAgcHVibGljIHNldENvbHVtbkRlZihfY29sRGVmQ29uZmlnOiBBcnJheTxJVGFibGVDb2x1bW4+LCBfZ3JpZENvbmZpZzogSVRhYmxlQ29uZmlnLCBfc3VwcHJlc3NNb3ZhYmxlQ29sdW1uczogYm9vbGVhbiA9IHRydWUpOiB2b2lkIHtcclxuICAgICAgICBsZXQgdXBkYXRlZENvbHVtbjogQXJyYXk8Q29sRGVmPiA9IHRoaXMuZ2VuZXJhdGVDb2x1bW5EZWZpbml0aW9ucyhfY29sRGVmQ29uZmlnLCBfZ3JpZENvbmZpZywgX3N1cHByZXNzTW92YWJsZUNvbHVtbnMpO1xyXG5cclxuICAgICAgICB0aGlzLmdyaWRPcHRpb25zLmNvbHVtbkRlZnMgPSB1cGRhdGVkQ29sdW1uO1xyXG4gICAgICAgIGlmIChzdXBlci5pc0FwaVJlYWR5KHRoaXMuZ3JpZE9wdGlvbnMpKSB7XHJcbiAgICAgICAgICAgIHRoaXMuZ3JpZE9wdGlvbnMuYXBpLnNldENvbHVtbkRlZnModXBkYXRlZENvbHVtbik7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICAvLyBpZiAoc3VwZXIuaGFzSW5wdXRUeXBlKF9jb2xEZWZDb25maWcsICdpbWFnZScpKSB7XHJcbiAgICAgICAgLy8gICAgIHRoaXMuX3VwZGF0ZVJvd0hlaWdodEZvckltZyhfY29sRGVmQ29uZmlnKTtcclxuICAgICAgICAvLyB9XHJcbiAgICB9XHJcblxyXG4gICAgcHVibGljIGdlbmVyYXRlQ29sdW1uRGVmaW5pdGlvbnMoX2NvbERlZkNvbmZpZzogQXJyYXk8SVRhYmxlQ29sdW1uPiwgX2dyaWRDb25maWc6IElUYWJsZUNvbmZpZywgX3N1cHByZXNzTW92YWJsZUNvbHVtbnM6IGJvb2xlYW4gPSB0cnVlKTogQXJyYXk8Q29sRGVmPiB7XHJcbiAgICAgICAgbGV0IHVwZGF0ZWRDb2xEZWZDb25maWc6IEFycmF5PElUYWJsZUNvbHVtbj4gPSB0aGlzLl91cGRhdGVDb2xEZWZDb25maWcoX2NvbERlZkNvbmZpZyk7XHJcblxyXG4gICAgICAgIGxldCBnZW5lcmF0ZWRDb2xEZWY6IEFycmF5PENvbERlZj4gPSBzdXBlci5nZW5lcmF0ZUNvbHVtbkRlZmluaXRpb25zKHVwZGF0ZWRDb2xEZWZDb25maWcsIF9ncmlkQ29uZmlnLCBfc3VwcHJlc3NNb3ZhYmxlQ29sdW1ucyk7XHJcbiAgICAgICAgdGhpcy5fY2hlY2tDaGVja2JveFNlbGVjdGlvblR5cGUoX2dyaWRDb25maWcsIGdlbmVyYXRlZENvbERlZik7XHJcblxyXG4gICAgICAgIHJldHVybiAgZ2VuZXJhdGVkQ29sRGVmO1xyXG4gICAgfVxyXG5cclxuICAgIC8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vXHJcbiAgICAvLy8gUm93IERhdGEgZnVuY3Rpb25zXHJcbiAgICAvLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vL1xyXG4gICAgcHVibGljIHNldFJvd0RhdGEoX3Jvd0RhdGE6IEFycmF5PGFueT4pOiB2b2lkIHtcclxuICAgICAgICB0aGlzLmdyaWRPcHRpb25zLnJvd0RhdGEgPSBfcm93RGF0YTtcclxuICAgIH1cclxuXHJcbiAgICAvLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vL1xyXG4gICAgLy8vIERhdGFzb3VyY2UgZnVuY3Rpb25zXHJcbiAgICAvLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vL1xyXG4gICAgcHVibGljIGdlbmVyYXRlRGF0YXNvdXJjZVJvd3MoX2RhdGFzb3VyY2VSZXF1ZXN0OiBJRW50ZXJwcmlzZUdldFJvd3NSZXF1ZXN0LCBfcm93RGF0YTogQXJyYXk8YW55Pik6IE9ic2VydmFibGU8YW55PiB7XHJcbiAgICAgICAgcmV0dXJuIG5ldyBPYnNlcnZhYmxlPGFueT4oKF9vYnNlcnZlcjogU3Vic2NyaWJlcjxhbnk+KTogdm9pZCA9PiB7XHJcbiAgICAgICAgICAgIC8vIGNvbnNvbGUubG9nKCctLSBHcmlkIHN0YXRlOiBnZW5lcmF0ZSBEYXRhc291cmNlIHJvd3MgLS0nLCBfZGF0YXNvdXJjZVJlcXVlc3QpO1xyXG5cclxuICAgICAgICAgICAgbGV0IHRlbXBSb3dNb2RlbDogQXJyYXk8YW55PiA9IHRoaXMuX2RhdGFzb3VyY2VGaWx0ZXJSb3coX2RhdGFzb3VyY2VSZXF1ZXN0LmZpbHRlck1vZGVsLCBfcm93RGF0YSk7XHJcbiAgICAgICAgICAgIHRoaXMuX2RhdGFzb3VyY2VTb3J0Um93KF9kYXRhc291cmNlUmVxdWVzdC5zb3J0TW9kZWwsIHRlbXBSb3dNb2RlbCk7XHJcblxyXG4gICAgICAgICAgICBsZXQgcmVxdWVzdE9iajoge3Jvd3M6IEFycmF5PGFueT4sIHRvdGFsOiBudW1iZXJ9ID0ge1xyXG4gICAgICAgICAgICAgICAgcm93czogdGVtcFJvd01vZGVsLnNsaWNlKF9kYXRhc291cmNlUmVxdWVzdC5zdGFydFJvdywgX2RhdGFzb3VyY2VSZXF1ZXN0LmVuZFJvdyksXHJcbiAgICAgICAgICAgICAgICB0b3RhbDogdGVtcFJvd01vZGVsLmxlbmd0aFxyXG4gICAgICAgICAgICB9O1xyXG5cclxuICAgICAgICAgICAgX29ic2VydmVyLm5leHQocmVxdWVzdE9iaik7XHJcbiAgICAgICAgICAgIF9vYnNlcnZlci5jb21wbGV0ZSgpO1xyXG4gICAgICAgIH0pO1xyXG4gICAgfVxyXG5cclxuICAgIC8qKioqKioqKioqKioqKioqKioqKioqKiogUHVibGljIGZ1bmN0aW9ucyBmcm9tIHBhcmVudCAqKioqKioqKioqKioqKioqKioqKioqKi9cclxuICAgIC8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vXHJcbiAgICAvLy8gT3ZlcnJpZGVzXHJcbiAgICAvLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vL1xyXG4gICAgcHVibGljIHVwZGF0ZVNlbGVjdGlvblZhbHVlcyhfcm93RGF0YTogQXJyYXk8YW55PiwgX3NlbGVjdGVkSWQ6IEFycmF5PHN0cmluZyB8IG51bWJlcj4sIF9yZXR1cm5LZXk6IEFycmF5PHN0cmluZz4sIF9sb2FkVHlwZTogc3RyaW5nKTogQXJyYXk8YW55PiB7XHJcbiAgICAgICAgaWYgKF9sb2FkVHlwZSA9PT0gJ3NlcnZlcicgJiYgdHlwZW9mIF9yZXR1cm5LZXkgIT09ICd1bmRlZmluZWQnICYmIF9yZXR1cm5LZXkubGVuZ3RoID4gMCkge1xyXG4gICAgICAgICAgICBjb25zb2xlLndhcm4oJ0tkVGFibGUgd2FybmluZzogU2VsZWN0aW9uIHZhbHVlIG5vdCBhYmxlIHRvIHJldHVybiBhcyBvYmplY3RzIHNwZWNpZnkgaW4gdGhlIHJldHVybktleSBwcm9wZXJ0eSBhcyB0aGVyZSBtaWdodCBoYXZlIHVua25vd24gZGF0YSB2YWx1ZXMgZm9yIHNlcnZlciBsb2FkVHlwZS4nKTtcclxuICAgICAgICAgICAgcmV0dXJuIF9zZWxlY3RlZElkO1xyXG4gICAgICAgIH1cclxuICAgICAgICByZXR1cm4gc3VwZXIudXBkYXRlU2VsZWN0aW9uVmFsdWVzKF9yb3dEYXRhLCBfc2VsZWN0ZWRJZCwgX3JldHVybktleSk7XHJcbiAgICB9XHJcblxyXG4gICAgLyoqKioqKioqKioqKiBFbmQgb2YgcHVibGljIGZ1bmN0aW9ucyAvIFN0YXJ0IG9mIHByaXZhdGUgZnVuY3Rpb25zICoqKioqKioqKioqL1xyXG4gICAgLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy9cclxuICAgIC8vLyBHcmlkIG9wdGlvbnMgZnVuY3Rpb25zXHJcbiAgICAvLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vL1xyXG4gICAgcHJpdmF0ZSBfZ2VuZXJhdGVDb25maWdPcHRpb25zKF9jb25maWc6IElUYWJsZUNvbmZpZyk6IEdyaWRPcHRpb25zIHtcclxuICAgICAgICBsZXQgcGFnZXNpemU6IG51bWJlciA9IHRoaXMuX3JldHJpZXZlUGFnZXNpemUoX2NvbmZpZy5wYWdpbmF0aW9uQ29uZmlnKTtcclxuXHJcbiAgICAgICAgbGV0IGNvbmZpZ09wdGlvbnM6IEdyaWRPcHRpb25zID0ge1xyXG4gICAgICAgICAgICByb3dNb2RlbFR5cGU6ICdlbnRlcnByaXNlJyxcclxuICAgICAgICAgICAgZW5hYmxlU2VydmVyU2lkZUZpbHRlcjogdHJ1ZSxcclxuICAgICAgICAgICAgZW5hYmxlU2VydmVyU2lkZVNvcnRpbmc6IHRydWUsXHJcblxyXG4gICAgICAgICAgICBtYXhDb25jdXJyZW50RGF0YXNvdXJjZVJlcXVlc3RzOiAyLFxyXG4gICAgICAgICAgICBjYWNoZU92ZXJmbG93U2l6ZTogMSxcclxuXHJcbiAgICAgICAgICAgIHJvd0dyb3VwUGFuZWxTaG93OiAnbmV2ZXInLFxyXG4gICAgICAgICAgICB0b29sUGFuZWxTdXBwcmVzc1Bpdm90TW9kZTogdHJ1ZSxcclxuICAgICAgICAgICAgdG9vbFBhbmVsU3VwcHJlc3NWYWx1ZXM6IHRydWUsXHJcblxyXG4gICAgICAgICAgICBjYWNoZUJsb2NrU2l6ZTogcGFnZXNpemVcclxuICAgICAgICB9O1xyXG5cclxuICAgICAgICBpZiAodHlwZW9mIF9jb25maWcucm93SWRLZXkgIT09ICd1bmRlZmluZWQnKSB7XHJcbiAgICAgICAgICAgIHRoaXMucm93S2V5ID0gX2NvbmZpZy5yb3dJZEtleTtcclxuXHJcbiAgICAgICAgICAgIGNvbmZpZ09wdGlvbnMuZ2V0Um93Tm9kZUlkID0gKF9kYXRhOiBhbnkpOiBzdHJpbmcgPT4ge1xyXG4gICAgICAgICAgICAgICAgaWYgKF9kYXRhLmhhc093blByb3BlcnR5KF9jb25maWcucm93SWRLZXkpKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgbGV0IGlkOiBzdHJpbmcgPSBfZGF0YVtfY29uZmlnLnJvd0lkS2V5XTtcclxuXHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKHR5cGVvZiBfZGF0YVtfY29uZmlnLnJvd0lkS2V5XSA9PT0gJ251bWJlcicpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgaWQgPSBpZC50b1N0cmluZygpO1xyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIGlkO1xyXG4gICAgICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgICAgIHJldHVybiAnJztcclxuICAgICAgICAgICAgfTtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIGlmICh0eXBlb2YgX2NvbmZpZyAhPT0gJ3VuZGVmaW5lZCcgJiYgdHlwZW9mIF9jb25maWcubG9hZFR5cGUgIT09ICd1bmRlZmluZWQnKSB7XHJcbiAgICAgICAgICAgIGlmIChfY29uZmlnLmxvYWRUeXBlICE9PSAnaW5maW5pdGUnKSB7XHJcbiAgICAgICAgICAgICAgICBjb25maWdPcHRpb25zLnBhZ2luYXRpb24gPSB0cnVlO1xyXG4gICAgICAgICAgICAgICAgY29uZmlnT3B0aW9ucy5tYXhCbG9ja3NJbkNhY2hlID0gMDtcclxuXHJcbiAgICAgICAgICAgICAgICBjb25maWdPcHRpb25zLnBhZ2luYXRpb25QYWdlU2l6ZSA9IHBhZ2VzaXplO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgLy8gQXV0byBoZWlnaHQgdGFrZXMgYSBsb3Qgb2YgaGVpZ2h0LCB3aWxsIGNhdXNlIGluZmluaXRlIHJldHJpZXZpbmcgaXNzdWVcclxuICAgICAgICAgICAgICAgIGNvbmZpZ09wdGlvbnMubWF4QmxvY2tzSW5DYWNoZSA9IDU7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgaWYgKF9jb25maWcubG9hZFR5cGUgPT0gJ25vcm1hbCcpIHtcclxuICAgICAgICAgICAgICAgIGNvbmZpZ09wdGlvbnMuc2lkZUJhciA9ICB0cnVlO1xyXG4gICAgICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgY29uZmlnT3B0aW9ucy5zaWRlQmFyID0gIGZhbHNlO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICByZXR1cm4gY29uZmlnT3B0aW9ucztcclxuICAgIH1cclxuXHJcbiAgICAvLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vL1xyXG4gICAgLy8vIENvbHVtbiBkZWZpbml0aW9ucyBmdW5jdGlvbnNcclxuICAgIC8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vXHJcbiAgICBwcml2YXRlIF9jaGVja0NoZWNrYm94U2VsZWN0aW9uVHlwZShfZ3JpZENvbmZpZzogSVRhYmxlQ29uZmlnLCBfY29sRGVmczogQXJyYXk8Q29sRGVmPik6IHZvaWQge1xyXG4gICAgICAgIGlmICh0eXBlb2YgX2dyaWRDb25maWcuc2VsZWN0aW9uICE9PSAndW5kZWZpbmVkJyAmJlxyXG4gICAgICAgICAgICB0eXBlb2YgX2dyaWRDb25maWcuc2VsZWN0aW9uLnR5cGUgIT09ICd1bmRlZmluZWQnICYmXHJcbiAgICAgICAgICAgIHR5cGVvZiBfZ3JpZENvbmZpZy5sb2FkVHlwZSAhPT0gJ3VuZGVmaW5lZCcgJiZcclxuICAgICAgICAgICAgX2dyaWRDb25maWcuc2VsZWN0aW9uLnR5cGUgPT09ICdhbGwnICYmXHJcbiAgICAgICAgICAgIF9ncmlkQ29uZmlnLmxvYWRUeXBlID09PSAnaW5maW5pdGUnKSB7XHJcbiAgICAgICAgICAgICAgICBjb25zb2xlLndhcm4oJ0tkVGFibGUgd2FybmluZzogSW5maW5pdGUgbG9hZFR5cGUgbm90IGFibGUgdG8gc3VwcG9ydCBhbGwgc2VsZWN0aW9uVHlwZS4nKTtcclxuICAgICAgICAgICAgICAgIGRlbGV0ZSBfY29sRGVmc1swXS5oZWFkZXJDb21wb25lbnRGcmFtZXdvcms7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX3VwZGF0ZUNvbERlZkNvbmZpZyhfY29sRGVmQ29uZmlnOiBBcnJheTxJVGFibGVDb2x1bW4+KTogQXJyYXk8SVRhYmxlQ29sdW1uPiB7XHJcbiAgICAgICAgbGV0IHVwZGF0ZWRDb2xEZWZDb25maWc6IEFycmF5PElUYWJsZUNvbHVtbj4gPSBbXTtcclxuXHJcbiAgICAgICAgZm9yIChsZXQgaTogbnVtYmVyID0gMDsgaSA8IF9jb2xEZWZDb25maWcubGVuZ3RoOyBpKyspIHtcclxuICAgICAgICAgICAgaWYgKHN1cGVyLmlzSW5wdXRUeXBlKF9jb2xEZWZDb25maWdbaV0sICdpbnB1dCcpKSB7XHJcbiAgICAgICAgICAgICAgICBjb25zb2xlLmVycm9yKCdLZFRhYmxlIGVycm9yOiBpbnB1dCBjb2x1bW4gdHlwZSBpcyBvbmx5IHZhbGlkIGZvciBub3JtYWwgbG9hZFR5cGUgdGFibGUuIFJlbW92aW5nIGNvbHVtbnMgd2l0aCBpbnB1dCB0eXBlLicpO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5fY2hlY2tDb2xEZWZGaWx0ZXJhYmxlVmFsKF9jb2xEZWZDb25maWdbaV0pO1xyXG4gICAgICAgICAgICAgICAgdXBkYXRlZENvbERlZkNvbmZpZy5wdXNoKF9jb2xEZWZDb25maWdbaV0pO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICByZXR1cm4gdXBkYXRlZENvbERlZkNvbmZpZztcclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF9jaGVja0NvbERlZkZpbHRlcmFibGVWYWwoX2NvbERlZkl0ZW06IElUYWJsZUNvbHVtbik6IHZvaWQge1xyXG4gICAgICAgIGlmICh0eXBlb2YgX2NvbERlZkl0ZW0uZmlsdGVyYWJsZSAhPT0gJ3VuZGVmaW5lZCcgJiYgX2NvbERlZkl0ZW0uZmlsdGVyYWJsZSAmJlxyXG4gICAgICAgICAgICAodHlwZW9mIF9jb2xEZWZJdGVtLmZpbHRlclZhbHVlID09PSAndW5kZWZpbmVkJyB8fCBfY29sRGVmSXRlbS5maWx0ZXJWYWx1ZSA9PT0gbnVsbCB8fCBfY29sRGVmSXRlbS5maWx0ZXJWYWx1ZS5sZW5ndGggPT09IDAgKSkge1xyXG4gICAgICAgICAgICAgICAgY29uc29sZS5lcnJvcignS2RUYWJsZSBlcnJvcjogRmlsdGVyIHZhbHVlIGZvciAnICsgX2NvbERlZkl0ZW0uZmllbGQgKyAnIGZpZWxkIGlzIGVtcHR5LiBVc2luZyBmaWx0ZXIgZm9yIGxvYWRUeXBlIG9uZXNob3QvaW5maW5pdGUvc2VydmVyIHJlcXVpcmVzIHRvIHByb3ZpZGUgZmlsdGVyVmFsdWUuIFN1cHByZXNzaW5nIGZpbHRlcmluZyBtZW51LicpO1xyXG4gICAgICAgICAgICAgICAgX2NvbERlZkl0ZW0uZmlsdGVyYWJsZSA9IGZhbHNlO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICAvLyBwcml2YXRlIF91cGRhdGVSb3dIZWlnaHRGb3JJbWcoX2NvbERlZkNvbmZpZzogQXJyYXk8SVRhYmxlQ29sdW1uPik6IHZvaWQge1xyXG4gICAgLy8gICAgIGxldCBtYXhIZWlnaHQ6IG51bWJlciA9IDUwO1xyXG4gICAgLy8gICAgIGZvciAobGV0IGk6IG51bWJlciA9IDA7IGkgPCBfY29sRGVmQ29uZmlnLmxlbmd0aDsgKytpKSB7XHJcbiAgICAvLyAgICAgICAgIGlmIChzdXBlci5pc0lucHV0VHlwZShfY29sRGVmQ29uZmlnW2ldLCAnaW1hZ2UnKSkge1xyXG4gICAgLy8gICAgICAgICAgICAgbGV0IHRlbXBIZWlnaHQ6IG51bWJlciA9IHN1cGVyLmdldEltYWdlU2l6ZUJ5KF9jb2xEZWZDb25maWdbaV0sICdoZWlnaHQnKTtcclxuXHJcbiAgICAvLyAgICAgICAgICAgICBpZiAodGVtcEhlaWdodCA+IG1heEhlaWdodCkge1xyXG4gICAgLy8gICAgICAgICAgICAgICAgIG1heEhlaWdodCA9IHRlbXBIZWlnaHQ7XHJcbiAgICAvLyAgICAgICAgICAgICB9XHJcbiAgICAvLyAgICAgICAgIH1cclxuICAgIC8vICAgICB9XHJcbiAgICAvLyAgICAgY29uc29sZS5sb2coJ3JvdyBoZWlnaHQgbWF4OiAnLCBtYXhIZWlnaHQpO1xyXG4gICAgLy8gICAgIHRoaXMuZ3JpZE9wdGlvbnMucm93SGVpZ2h0ID0gbWF4SGVpZ2h0O1xyXG4gICAgLy8gfVxyXG5cclxuICAgIC8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vXHJcbiAgICAvLy8gRGF0YXNvdXJjZSBzb3J0IC8gZmlsdGVyIGZ1bmN0aW9uc1xyXG4gICAgLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy9cclxuICAgIHByaXZhdGUgX2RhdGFzb3VyY2VTb3J0Um93KF9zb3J0TW9kZWw6IEFycmF5PHtjb2xJZDogc3RyaW5nLCBzb3J0OiAnYXNjJyB8ICdkZXNjJ30+LCBfcm93RGF0YTogQXJyYXk8YW55Pik6IHZvaWQge1xyXG4gICAgICAgIGlmIChfc29ydE1vZGVsLmxlbmd0aCA+IDApIHtcclxuICAgICAgICAgICAgbGV0IHNvcnRPcHRpb25zOiB7Y29sSWQ6IHN0cmluZywgc29ydDogJ2FzYycgfCAnZGVzYyd9ID0gX3NvcnRNb2RlbFswXTtcclxuICAgICAgICAgICAgbGV0IHJldHVybkNvbmRpdGlvbjogbnVtYmVyID0gKHNvcnRPcHRpb25zLnNvcnQgPT09ICdhc2MnKSA/IDEgOiAtMTtcclxuXHJcbiAgICAgICAgICAgIF9yb3dEYXRhLnNvcnQoKF9hOiBhbnksIF9iOiBhbnkpOiBudW1iZXIgPT4ge1xyXG4gICAgICAgICAgICAgICAgcmV0dXJuIHRoaXMuX2RhdGFzb3VyY2VSb3dTb3J0Rm9ybXVsYShfYSwgX2IsIHNvcnRPcHRpb25zLmNvbElkLCByZXR1cm5Db25kaXRpb24pO1xyXG4gICAgICAgICAgICB9KTtcclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfZGF0YXNvdXJjZVJvd1NvcnRGb3JtdWxhKF9hOiBhbnksIF9iOiBhbnksIF9kb3REaXNwbGF5RnJvbTogc3RyaW5nLCBfcmV0dXJuVmFsOiBudW1iZXIpOiBudW1iZXIge1xyXG4gICAgICAgIGlmICh0eXBlb2YgX2EgIT09ICd1bmRlZmluZWQnICYmIHR5cGVvZiBfYiAhPT0gJ3VuZGVmaW5lZCcpIHtcclxuICAgICAgICAgICAgbGV0IGFWYWw6IGFueSA9IHRoaXMuZGF0YVN2Yy5nZXREYXRhVmFsdWUoX2EsIF9kb3REaXNwbGF5RnJvbSk7XHJcbiAgICAgICAgICAgIGxldCBiVmFsOiBhbnkgPSB0aGlzLmRhdGFTdmMuZ2V0RGF0YVZhbHVlKF9iLCBfZG90RGlzcGxheUZyb20pO1xyXG5cclxuICAgICAgICAgICAgaWYgKGFWYWwgPiBiVmFsKSByZXR1cm4gX3JldHVyblZhbDtcclxuICAgICAgICAgICAgZWxzZSBpZiAoYVZhbCA8IGJWYWwpIHJldHVybiAtKF9yZXR1cm5WYWwpO1xyXG4gICAgICAgICAgICByZXR1cm4gMDtcclxuICAgICAgICB9XHJcbiAgICAgICAgcmV0dXJuIDA7XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfZGF0YXNvdXJjZUZpbHRlclJvdyhfZmlsdGVyTW9kZWw6IGFueSwgX3Jvd0RhdGE6IEFycmF5PGFueT4pOiBBcnJheTxhbnk+IHtcclxuICAgICAgICBsZXQgdGVtcFJvd01vZGVsOiBBcnJheTxhbnk+ID0gW107XHJcblxyXG4gICAgICAgIGlmIChPYmplY3Qua2V5cyhfZmlsdGVyTW9kZWwpLmxlbmd0aCA+IDApIHtcclxuICAgICAgICAgICAgZm9yIChsZXQgaXRlbSBpbiBfZmlsdGVyTW9kZWwpIHtcclxuICAgICAgICAgICAgICAgIGlmIChfZmlsdGVyTW9kZWwuaGFzT3duUHJvcGVydHkoaXRlbSkpIHtcclxuICAgICAgICAgICAgICAgICAgICBsZXQgZGF0YUtleTogc3RyaW5nID0gaXRlbTtcclxuICAgICAgICAgICAgICAgICAgICBsZXQgZmlsdGVyTW9kZWxJdGVtOiBBcnJheTxzdHJpbmcgfCBudW1iZXI+ID0gX2ZpbHRlck1vZGVsW2l0ZW1dLnZhbHVlcztcclxuXHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKGZpbHRlck1vZGVsSXRlbS5sZW5ndGggPiAwKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGZvciAobGV0IGk6IG51bWJlciA9IDA7IGkgPCBfcm93RGF0YS5sZW5ndGg7IGkrKykge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgbGV0IHJvd0l0ZW06IGFueSA9IF9yb3dEYXRhW2ldO1xyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmIChyb3dJdGVtLmhhc093blByb3BlcnR5KGRhdGFLZXkpICYmIGZpbHRlck1vZGVsSXRlbS5pbmRleE9mKHJvd0l0ZW1bZGF0YUtleV0pID4gLTEpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0ZW1wUm93TW9kZWwucHVzaChyb3dJdGVtKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgdGVtcFJvd01vZGVsID0gW107XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgdGVtcFJvd01vZGVsID0gX3Jvd0RhdGEuc2xpY2UoKTtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIHJldHVybiB0ZW1wUm93TW9kZWw7XHJcbiAgICB9XHJcblxyXG4gICAgLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy9cclxuICAgIC8vLyBNaXNjIGZ1bmN0aW9uc1xyXG4gICAgLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy9cclxuICAgIHByaXZhdGUgX3JldHJpZXZlUGFnZXNpemUoX3BhZ2luYXRpb25Db25maWc6IGFueSk6IG51bWJlciB7XHJcbiAgICAgICAgaWYgKHR5cGVvZiBfcGFnaW5hdGlvbkNvbmZpZyAhPT0gJ3VuZGVmaW5lZCcgJiZcclxuICAgICAgICAgICAgdHlwZW9mIF9wYWdpbmF0aW9uQ29uZmlnLnBhZ2VzaXplICE9PSAndW5kZWZpbmVkJykge1xyXG4gICAgICAgICAgICAgICAgcmV0dXJuIF9wYWdpbmF0aW9uQ29uZmlnLnBhZ2VzaXplO1xyXG4gICAgICAgIH1cclxuICAgICAgICBfcGFnaW5hdGlvbkNvbmZpZy5wYWdlc2l6ZSA9IHRoaXMuREVGQVVMVF9QQUdFU0laRTtcclxuICAgICAgICByZXR1cm4gdGhpcy5ERUZBVUxUX1BBR0VTSVpFO1xyXG4gICAgfVxyXG5cclxuICAgIC8qKioqKioqKioqKioqKioqKioqKioqKioqIEVuZCBvZiBwcml2YXRlIGZ1bmN0aW9ucyAqKioqKioqKioqKioqKioqKioqKioqKioqKi9cclxufVxyXG4iXX0=