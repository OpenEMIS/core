import { Component, ViewEncapsulation, Input } from '@angular/core';
import * as d3 from 'd3';
import { KdChartBaseClass } from '../kd-angular-chart-base-class';
import { KdChartsSvc } from '../kd-angular-charts-svc';
import { KdDomElemSvc } from '../../kd-common/index';
export class KdLineChart extends KdChartBaseClass {
    constructor(_chartSvc, _domSvc) {
        super(_chartSvc, _domSvc);
        this._chartSvc = _chartSvc;
        this._domSvc = _domSvc;
        this._seriesList = [];
        // Dot Setting
        this._hoverBackground = 'M 10, 10 m -10, 0 a 10,10 0 1,0 20,0 a 10,10 0 1,0 -20,0';
        this._shapes = {
            'M 4 0 L 4 0 L 0 8 L 8 8 z': 'M 6 0 L 6 0 L 0 12 L 12 12 z',
            'M 0 0 L 8 0 L 4 8 L 4 8 z': 'M 0 0 L 12 0 L 6 12 L 6 12 z',
            'M 4 0 L 8 4 L 4 8 L 0 4 z': 'M 6 0 L 12 6 L 6 12 L 0 6 z',
            'M 4 0 A 4 4 0 1 0 4 8 A 4 4 0 1 0 4 0 Z': 'M 6 0 A 6 6 0 1 0 6 12 A 6 6 0 1 0 6 0 Z',
            'M 0 0 L 8 0 L 8 8 L 0 8 z': 'M 0 0 L 12 0 L 12 12 L 0 12 z'
        };
        this._dotData = {};
        this._biggestDotSize = 12;
        this._defaultDotPos = { x: -999, y: -999 };
        this._lineStyle = {
            solid: 'none',
            shortDash: '6,2',
            shortDot: '2,2',
            shortDashDot: '6,2,2,2',
            shortDashDotDot: '6,2,2,2,2,2',
            dot: '2,6',
            dash: '8,6',
            longDash: '16,6',
            dashDot: '8,6,2,6',
            longDashDot: '16,6,2,6',
            longDashDotDot: '16,6,2,6,2,6'
        };
    }
    ngOnInit() {
        this.api.legendClick = (_data) => {
            this._redrawChart(false, _data);
        };
        this.api.redraw = () => {
            clearTimeout(this._resizeTimeout);
            this._resizeTimeout = setTimeout(() => {
                this._redrawChart(false);
            });
        };
    }
    ngOnChanges(_changes) {
        if (_changes.hasOwnProperty('data')) {
            this._redrawChart(_changes.data.isFirstChange(), _changes.data.currentValue);
        }
        if (_changes.hasOwnProperty('config') && !_changes.config.isFirstChange()) {
            this._redrawChart(_changes.config.isFirstChange());
        }
    }
    ngOnDestroy() { this.removeLineChart(); }
    _redrawChart(_isFirstChange, _data) {
        if (!_isFirstChange) {
            this.lineChart = d3.select('#line-' + this.config.id);
            this.removeLineChart();
        }
        if (_data)
            this._setData(_data);
        super.chartTimeout(() => this._setChart());
    }
    _setData(_data) {
        this.chartType = _data.layout.split('-');
        this.chartCategory = 'line';
        this.dataRange = _data.range;
        this.haveNegative = _data.haveNegative;
        this.data = Object.assign([], _data.data);
        this.initData = JSON.parse(JSON.stringify(this.data));
        this._seriesList = Object.keys(this.legendData).filter(key => !this.legendData[key].deactive);
        if (this.chartType[1] === 'stack' || this.chartType[1] === '100') {
            this._seriesList = this._seriesList.reverse();
        }
    }
    removeLineChart() {
        super.removeChart();
        if (this.lineChart) {
            this.lineChart.remove();
            this.lineChart = null;
        }
    }
    _setChart() {
        if (this.chartType[1] === '100' && this.haveNegative)
            return;
        super.setSvg();
        this._setAxisDomain();
        this._createHoverDot();
        this._createChart();
        this._drawChart(this.data);
    }
    _setAxisDomain() {
        if (this.chartType[this.chartType.length - 1] === 'type1') {
            super.setDomain('band');
        }
        else {
            super.setDomain('string');
        }
    }
    _createChart() {
        if (!this.lineChart) {
            this.lineChart = this.graph.append('g')
                .attr('class', 'kdx-charts-line-chart')
                .attr('id', 'line-' + this.config.id);
        }
        if (this.config.animation)
            this._setChartAnimation();
    }
    _createSeriesContainer() {
        let lineSvg = this.lineChart.selectAll('.kdx-chart-wrapper')
            .data(this._seriesList, function (d) { return d; });
        // key function for object consistency so d3 does not remove base on index
        lineSvg.exit().remove();
        let seriesContainer;
        if (this.chartType[1] !== 'stack' && this.chartType[1] !== '100') {
            seriesContainer = lineSvg.enter()
                .append('g')
                .attr('class', (d, i) => 'kdx-charts-series-container' + ' y-' + this._seriesList[i]);
        }
        else {
            seriesContainer = lineSvg.enter();
        }
        let lineContainer = seriesContainer.append('g')
            .attr('class', (d, i) => 'kdx-charts-line-container' + ' y-' + this._seriesList[i])
            .attr('clip-path', 'url(#kd-charts-clip-path-' + this.config.id + ')');
        let dotContainer = seriesContainer.append('g')
            .attr('class', (d, i) => 'kdx-charts-dot-container' + ' y-' + this._seriesList[i])
            .attr('id', (d, i) => 'kdx-charts-dot-container' + '_y-' + this._seriesList[i].replace(/\s/g, ''));
        return { lineContainer: lineContainer, dotContainer: dotContainer };
    }
    _createHoverDot() {
        d3.select('#' + this.config.id + '.kdx-charts .kdx-charts-hover-dot').remove();
        this.graph
            .append('path')
            .attr('class', 'kdx-charts-hover-dot')
            .attr('d', this._hoverBackground)
            .attr('transform', super.transformPosition(this._defaultDotPos.x, this._defaultDotPos.y, true));
    }
    _drawChart(_data) {
        // super.removeChart();
        // this._setAxisDomain();
        let seriesContainer = this._createSeriesContainer();
        this._drawPath(_data, seriesContainer.lineContainer);
        this._addDot(_data, seriesContainer.dotContainer);
        for (let xIndex = 0; xIndex < _data.length; xIndex++) {
            this._setLabelAnimation(xIndex, _data[xIndex]);
        }
    }
    // Line & Area
    _drawPath(_chartData, _lineSvg) {
        let data = _chartData;
        if (this.chartType[1] === 'stack')
            data = this._dataMassage(_chartData);
        if (this.chartType[0] !== 'dot') {
            if (this.chartType[0] === 'area') {
                _lineSvg.append('path')
                    .attr('d', (d, i) => this._setPathValue(i, data))
                    .attr('class', (d, i) => 'kdx-charts-line-area y-' + d)
                    .attr('fill', (d, i) => this.legendData[d].color)
                    .attr('fill-opacity', 0.75);
            }
            _lineSvg.append('path')
                .attr('d', (d, i) => {
                if (this.chartType[0] === 'area') {
                    return this._setPathValue(i, data, true);
                }
                return this._setPathValue(i, data);
            })
                .attr('class', (d, i) => 'kdx-charts-line-path y-' + d)
                .attr('stroke', (d, i) => this.legendData[d].color)
                .attr('stroke-dasharray', (d, i) => this._lineStyle[this.legendData[d].lineStyle])
                .style('fill', 'none');
        }
    }
    /**
     * [return path data value. depends on chart type, this function will return line or area path data
     *
     * for _chartData, we need unique data type to return because we are doing a different way of stack area.
     * natural way of line chart is 1 line, 1 series.
     * what we are doing is cut the line/split the stack area into 2 to cater for null value.
     * the data structure that we have coupled strictly to 1 x axis/category match with 1 y data value.
     * for splitting of stack area, we will need 1 x category match with 2 y data value.
     *
     * ]
     * param  {number}                                        _yIndex          [series index as line is drawn per series]
     * param  {Array<ID3DataData> | Array<Array<IDataValue>>} _chartData       [either line data or area data]
     * param  {boolean}                                       _byPassAreaCheck [skip chart type check and draw line. useful for area to draw area and line]
     * return {string}                                                         [return path data value]
     */
    _setPathValue(_yIndex, _chartData, _byPassAreaCheck) {
        _byPassAreaCheck = _byPassAreaCheck || false;
        let chartValue = { x: null, y: null, valid: false }, curveShape = (this.chartType[0] === 'spline' || this.chartType[this.chartType.length - 2] === 'spline') ? d3.curveCardinal : d3.curveLinear, chart = (this.chartType[0] !== 'area' || _byPassAreaCheck) ? d3.line() : d3.area(), data;
        data = (this._isUsingChartData(_chartData)) ? _chartData : _chartData[_yIndex];
        let valueLine = chart.curve(curveShape);
        chart.defined((item, xIndex) => {
            chartValue = this._validateChartValue(data[xIndex], _yIndex);
            return chartValue.valid;
        });
        chart.x(() => this.rangeList[chartValue.x.value]);
        if (this.chartType[0] !== 'area' || _byPassAreaCheck) {
            chart.y(() => this.y(chartValue.y));
        }
        else {
            chart.y1(() => this.y(chartValue.y))
                .y0((item) => (this.chartType[1] === '100' || this.chartType[1] === 'stack') ? this.y(chartValue.y0) : this.y(0));
        }
        return valueLine(data);
    }
    _isUsingChartData(_arrayObject) {
        return this.chartType[1] !== 'stack';
    }
    _isIDataValue(_object) {
        return this.chartType[1] === 'stack';
    }
    _validateChartValue(_item, _yIndex) {
        if (this._isIDataValue(_item)) { // stack
            return _item;
        }
        let yValue = _item.y[_yIndex].sum;
        let valid = true;
        let y0 = 0;
        if (this.chartType[1] === '100') {
            y0 = _item.y[_yIndex].sum - _item.y[_yIndex].renderVal;
        }
        else {
            valid = super.isDataExist(_item, _yIndex);
        }
        return { x: _item.x, y: yValue, y0: y0, valid: valid };
    }
    // Dot
    _addDot(_data, _dotContainer) {
        for (let xIndex = 0; xIndex < _data.length; xIndex++) {
            let item = _data[xIndex];
            if (this.chartType[1] !== 'stack' && !Array.isArray(item.y) ||
                (Array.isArray(item.y) && item.y.length <= 0))
                continue;
            let dataPoint = _dotContainer.append('path')
                .attr('class', (d, i) => this._populateDotData(item, i, xIndex))
                .attr('d', (d, i) => this._getDotId(xIndex, i, item, 'shape'))
                .attr('fill', (d, i) => this._getDotId(xIndex, i, item, 'colour'))
                .attr('stroke', (d, i) => this._getDotId(xIndex, i, item, 'borderColor'))
                .attr('stroke-width', (d, i) => this._getDotId(xIndex, i, item, 'borderWidth'))
                .attr('transform', (d, i) => this._getDotId(xIndex, i, item, 'position'))
                .style('display', 'block');
            let dotHoverFunc = this.triggerHoverFunction(this);
            super._initMouseEvents(dataPoint, { data: item, xIndex: xIndex, dotHover: dotHoverFunc });
        }
    }
    _getDotId(_xIndex, _yIndex, _data, _element) {
        if (!(super.isDataExist(_data, _yIndex) && this.legendData[_data.y[_yIndex].id].dotEnabled))
            return '';
        let id = super.getDotId(_xIndex, _data.y[_yIndex].id).replace(/\s/g, '');
        let value = '';
        if (_element === 'position') {
            let x = (this._dotData[id] && typeof this._dotData[id].x !== 'undefined') ? this._dotData[id].x : this._defaultDotPos.x;
            let y = (this._dotData[id] && typeof this._dotData[id].y !== 'undefined') ? this._dotData[id].y : this._defaultDotPos.y;
            value = super.transformPosition(x, y, true);
        }
        else {
            value = (this._dotData[id] && this._dotData[id][_element]) ? this._dotData[id][_element].toString() : '';
        }
        return value;
    }
    _populateDotData(_data, _yIndex, _xIndex) {
        if (!super.isDataExist(_data, _yIndex))
            return '';
        let id = super.getDotId(_xIndex, _data.y[_yIndex].id).replace(/\s/g, '');
        let colour = _data.y[_yIndex].color;
        let shape = _data.y[_yIndex].shape;
        let position = this._getDotPosition(_data.x.value, _xIndex, _data.y[_yIndex].sum);
        let borderColor = this.legendData[_data.y[_yIndex].id].dotBorderColor;
        let borderWidth = this.legendData[_data.y[_yIndex].id].dotBorderWidth;
        this._setLabel(_data.y[_yIndex], _xIndex, position.x, borderWidth);
        if (_data.y[_yIndex].value === this.domainMin || _data.y[_yIndex].value === this.domainMax) {
            let currentDotSize = 12 + borderWidth;
            if (this._biggestDotSize < currentDotSize)
                this._biggestDotSize = currentDotSize;
        }
        if ((this.config.yAxis.minValue !== null &&
            _data.y[_yIndex].value < this.config.yAxis.minValue) ||
            (this.config.yAxis.maxValue !== null &&
                _data.y[_yIndex].value > this.config.yAxis.maxValue)) {
            delete this._dotData[id];
            return id;
        }
        this._dotData[id] = {
            colour: colour,
            shape: shape,
            x: position.x,
            y: position.y,
            borderColor: borderColor,
            borderWidth: borderWidth
        };
        return id;
    }
    _getDotPosition(_xValue, _xIndex, _yValue) {
        let xPos = 0;
        let yPos = 0;
        xPos = (this.rangeList[_xValue] - 4);
        yPos = (this.y(_yValue) - 4);
        return { x: xPos, y: yPos };
    }
    // hover function
    triggerHoverFunction(_kdLineChart) {
        return function (dotId, isHovering) {
            isHovering = isHovering || false;
            _kdLineChart.dotHover(_kdLineChart, dotId, isHovering);
        };
    }
    dotHover(_kdLineChart, _dotId, _isHovering) {
        _dotId = _dotId.replace(/\s/g, '');
        if (!this._dotData.hasOwnProperty(_dotId) || !this._dotData[_dotId].shape)
            return;
        let shape = (_isHovering) ? this._shapes[this._dotData[_dotId].shape] : this._dotData[_dotId].shape;
        let position = this._dotHoverPosition(_dotId, _isHovering, false);
        let borderWidth = this._dotData[_dotId].borderWidth;
        if (borderWidth === 0 && _isHovering)
            borderWidth = 1;
        this._setHoverBackground(_dotId, _isHovering);
        d3.select('#' + this.config.id + '.kdx-charts .' + _dotId)
            .attr('d', shape)
            .attr('transform', super.transformPosition(position.x, position.y, true))
            .attr('stroke-width', borderWidth);
    }
    _setHoverBackground(_dotId, _isHovering) {
        let colour = this._dotData[_dotId].colour;
        let position = _isHovering ? this._dotHoverPosition(_dotId, _isHovering, true) : this._defaultDotPos;
        d3.select('#' + this.config.id + '.kdx-charts .kdx-charts-hover-dot')
            // .style('display', display)
            .attr('fill', colour)
            .attr('transform', this.transformPosition(position.x, position.y, true))
            .attr('stroke-width', 1)
            .attr('stroke', colour);
    }
    _dotHoverPosition(_dotId, _isHovering, _isBackground) {
        let xPos = this._dotData[_dotId].x;
        let yPos = this._dotData[_dotId].y;
        if (!_isHovering)
            return { x: xPos, y: yPos };
        if (_isBackground) {
            xPos -= 6;
            yPos -= 6;
        }
        else {
            xPos -= 2;
            yPos -= 2;
        }
        return { x: xPos, y: yPos };
    }
    // label
    _setLabel(_yData, _xIndex, _xPosition, _dotWidth) {
        if (!this.config.chart.labels.enabled)
            return;
        _xPosition -= _dotWidth / 2;
        let label = super.setLabel(_yData, _xIndex, _xPosition, this.y(_yData.sum));
        // label.style('display', 'flex');
        let spanElm = label.select('.kdx-charts-data-label-text');
        let dataLabelLength = this._getLabelTextLength(_yData);
        let dotSize = 10 + _dotWidth; // add 10px for spacing between dot and label
        super.setLabelTextPosition(spanElm, this.y(_yData.sum), { dotSize: dotSize, labelLength: dataLabelLength });
        // shift text to the horizontally center to the dot
        // if (this._chartSvc.isExist(_yData) && dataLabelLength > 1) {
        //     let shiftPosition: number = this._getCenterPosition(dataLabelLength, spanElm);
        //     spanElm.style('left', shiftPosition + 'px').style('display', 'none');
        // }
    }
    _getLabelTextLength(_yData) {
        let dataLabel = this.config.chart.labels.format.replace('{value}', this._chartSvc.getD3Format(_yData.value));
        return dataLabel.toString().length;
    }
    // private _getCenterPosition(_dataLabelLength: number, _spanElm: any) {
    //     let labelElm: any = _spanElm.node().getBoundingClientRect();
    //     let labelWidth: number = labelElm.width;
    //     let labelCenter: number = (labelWidth - labelWidth / _dataLabelLength) / 2;
    //     let shiftPosition: number = 0 - labelCenter;
    //     if (document.dir === 'rtl') return labelCenter;
    //     return shiftPosition;
    // }
    // animation
    _setChartAnimation() {
        let halfDot = this._biggestDotSize / 2;
        let offsetStart = 0 - halfDot;
        let clip = this.lineChart.append('clipPath')
            .attr('id', 'line-clip' + this.config.id);
        let clipRect = clip.append('rect')
            .attr('fill', 'white')
            .attr('x', offsetStart)
            .attr('y', offsetStart)
            .attr('fill', 'none')
            .attr('width', 0)
            .attr('height', this.height + this._biggestDotSize);
        this.lineChart.attr('clip-path', 'url(#line-clip' + this.config.id + ')');
        let transitionFunc = d3.transition()
            .duration(this.lengthOfTransition)
            .ease(d3.easeLinear);
        clipRect.transition(transitionFunc)
            .attr('width', this.width + this._biggestDotSize);
    }
    _setLabelAnimation(_xIndex, _data) {
        if (this.config.chart !== undefined && this.config.chart.labels !== undefined) {
            if (!this.config.chart.labels.enabled)
                return;
            let labelDelay = 1.5;
            let animationDelay = _xIndex * this.lengthOfTransition / _data.y.length * labelDelay;
            let transitionTime = this.config.animation ? this.lengthOfTransition : 0;
            animationDelay = this.config.animation ? animationDelay : 0;
            d3.selectAll('#' + this.config.id + '.kdx-charts .kdx-charts-data-label.x-' + _xIndex)
                .transition() // Transition from old to new
                .duration(transitionTime) // Length of animation
                .delay(animationDelay)
                .on('start', function (d, i) {
                d3.select(this) // 'this' means the current element
                    .style('visibility', 'visible');
                // .style('display', 'block');
            });
        }
    }
    // Stack Area recalculate
    /**
     * for area stack (not the 100% stack. 100% data massage is the same as bar which
     * the data masssage is done in kd charts).
     *
     * this cannot be done through kd chart data massage because the dot position has to
     * be on the correct sum (same as bar). we will take bar after massage value for dot
     * and remassage for line area.
     *
     * this data massage is catering unique line behaviour when handling null value.
     *
     * line behaviour on null: when a null appear, the line for previous and after current
     * x axis will not be drawn. causing the previous and after x axis to be intepreted as 0
     *
     * as the whole area of this current x axis will be 0 for current series, any series after
     * has to be brought down.
     *
     * we need unique data type to return because we are doing a different way of stack area.
     * natural way of line chart is 1 line, 1 series.
     * what we are doing is cut the line/split the stack area into 2 to cater for null value.
     * the data structure that we have coupled strictly to 1 x axis/category match with 1 y data value.
     * for splitting of stack area, we will need 1 x category match with 2 y data value.
     *
     * param  {Array<ID3DataData>} data after massage data
     * return {Array}                   return as {x, y, y0, valid} as d3 required.
     */
    _dataMassage(_data) {
        // console.log(_data);
        let dataArr = [];
        let adjustPosition = {};
        for (let i = 0; i < this._seriesList.length; ++i) {
            let dataDetails = [];
            let x = null;
            let y = 0;
            let y0 = 0;
            let valid = true;
            for (let xIndex = 0; xIndex < _data.length; ++xIndex) {
                let xValue = _data[xIndex].x.value;
                for (let yIndex = 0; yIndex < _data[xIndex].y.length; ++yIndex) {
                    let id = _data[xIndex].y[yIndex].id;
                    x = xValue;
                    valid = _data[xIndex].y[yIndex].value !== null ? true : false;
                    if (this.chartType[1] === 'stack' && id === this._seriesList[i]) {
                        let nullValue = this._getNullHeightValue(_data, xIndex, yIndex);
                        let adjustValue = (typeof adjustPosition[xIndex] === 'undefined') ? 0 : adjustPosition[xIndex];
                        adjustPosition[xIndex] = adjustValue - nullValue;
                        let adjust = adjustPosition[xIndex] || 0;
                        let currentValue = _data[xIndex].y[yIndex].value;
                        y = _data[xIndex].y[yIndex].sum + adjust;
                        y0 = y - currentValue;
                        dataDetails.push({ x: { value: x, label: x }, y: y, y0: y0, id: id, valid: valid });
                        let splitPathData = this._getSplitPathData(_data, xIndex, yIndex, adjustPosition);
                        if (splitPathData.valid === true) {
                            dataDetails.push({ x: splitPathData.x, y: splitPathData.y, y0: splitPathData.y0, id: id, valid: false });
                            dataDetails.push({ x: splitPathData.x, y: splitPathData.y, y0: splitPathData.y0, id: id, valid: true });
                        }
                        break;
                    }
                }
            }
            dataArr.push(dataDetails);
        }
        // console.log(dataArr);
        return dataArr;
    }
    /**
     * if the previous series is null, area height calculation start from the series that exist.
     * param  {Array<ID3DataData>} data   [data after massage]
     * param  {number}             xIndex [index of data]
     * param  {number}             yIndex [index of series]
     * param  {number}             adjust [how much point to be bring down (previous)]
     * return {number}                    [return accumulate adjustment point]
     */
    _getNullHeightValue(_data, _xIndex, _yIndex) {
        let currentVal = _data[_xIndex].y[_yIndex].value;
        let isDisappearing = false;
        let isSeriesNull = this._chartSvc.isSeriesNull(_data, _xIndex, _yIndex);
        let isPrevNull = isSeriesNull['isPrevNull'];
        let isSidesNull = isSeriesNull['isNextNull'] && (_xIndex < 1 || isPrevNull);
        if (_xIndex > 0) {
            let checkSeries = this._chartSvc.isSeriesNull(_data, (_xIndex - 1), _yIndex);
            isDisappearing = checkSeries['isDisappearing'];
        }
        if (currentVal === null || isSidesNull || isPrevNull || isDisappearing) {
            return currentVal;
        }
        return 0;
    }
    /**
     * check if the series appearing or disappearing, adjust the position of the line area (stage up/down)
     *
     * appearing is referring to: there is a null on previous x axis but not null on current and after
     *
     * disappering is referring to: there is a value on previous and current x axis but null after
     *
     * param  {Array<ID3DataData>} data   [data after massage]
     * param  {number}             xIndex [index of data]
     * param  {number}             yIndex [index of series]
     * param  {object}             adjust [height to pull down series (if previous series has null) or bring up]
     * return {IDataValue}                [d3 draw path data structure: {x, y, y0, valid}]
     */
    _getSplitPathData(_data, _xIndex, _yIndex, _adjust) {
        let currentValue = _data[_xIndex].y[_yIndex].value;
        let split = false;
        let y = _data[_xIndex].y[_yIndex].sum + (_adjust[_xIndex] || 0);
        let x = _data[_xIndex].x.value;
        let y0 = 0 - currentValue;
        if (currentValue === null) {
            return { x: { value: x, label: x }, y: y, y0: y0, valid: split };
        }
        let isDisappearing = _xIndex > 0 && _xIndex < _data.length - 1 &&
            _data[_xIndex + 1].y[_yIndex].value === null &&
            currentValue !== null && _data[_xIndex - 1].y[_yIndex].value !== null;
        let isReappearing = _xIndex > 0 && _xIndex < _data.length - 1 &&
            _data[_xIndex - 1].y[_yIndex].value === null &&
            currentValue !== null && _data[_xIndex + 1].y[_yIndex].value !== null;
        if (isReappearing) {
            _adjust['adjust' + _xIndex] = (_adjust['adjust' + _xIndex] || 0) + currentValue;
        }
        if (isDisappearing) {
            _adjust['adjust' + _xIndex] = (_adjust['adjust' + _xIndex] || 0) - currentValue;
        }
        if (currentValue !== null && _adjust['adjust' + _xIndex]) {
            y = y + _adjust['adjust' + _xIndex];
            y0 = y0 + y;
            split = true;
        }
        return { x: { value: x, label: x }, y: y, y0: y0, valid: split };
    }
}
KdLineChart.decorators = [
    { type: Component, args: [{
                selector: 'kd-line-chart',
                template: `
        <div *ngIf="chartType[1] === '100' && haveNegative" class="kdx-charts-error-msg">
            {{errorMsg}}
        </div>
    `,
                encapsulation: ViewEncapsulation.None,
                providers: [KdChartsSvc, KdDomElemSvc]
            },] }
];
KdLineChart.ctorParameters = () => [
    { type: KdChartsSvc },
    { type: KdDomElemSvc }
];
KdLineChart.propDecorators = {
    data: [{ type: Input }],
    config: [{ type: Input }],
    legendData: [{ type: Input, args: ['legend',] }],
    api: [{ type: Input }]
};
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoia2QtYW5ndWxhci1saW5lLWNoYXJ0LmpzIiwic291cmNlUm9vdCI6IkM6L3hhbXBwL2h0ZG9jcy9TdHlsZWd1aWRlL2lvc3RnLW9wZW5lbWlzLXN0eWxlZ3VpZGUvcHJvamVjdHMvb3BlbmVtaXMtc3R5bGVndWlkZS1saWIvc3JjLyIsInNvdXJjZXMiOlsia2QtY29tcG9uZW50cy9rZC1hbmd1bGFyLWNoYXJ0cy9rZC1hbmd1bGFyLWxpbmUtY2hhcnQva2QtYW5ndWxhci1saW5lLWNoYXJ0LnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBLE9BQU8sRUFDSCxTQUFTLEVBQ1QsaUJBQWlCLEVBS2pCLEtBQUssRUFDUixNQUFNLGVBQWUsQ0FBQztBQUN2QixPQUFPLEtBQUssRUFBRSxNQUFNLElBQUksQ0FBQztBQUN6QixPQUFPLEVBQUUsZ0JBQWdCLEVBQUUsTUFBTSxnQ0FBZ0MsQ0FBQztBQUNsRSxPQUFPLEVBQUUsV0FBVyxFQUFFLE1BQU0sMEJBQTBCLENBQUM7QUFTdkQsT0FBTyxFQUFFLFlBQVksRUFBRSxNQUFNLHVCQUF1QixDQUFDO0FBK0NyRCxNQUFNLE9BQU8sV0FBWSxTQUFRLGdCQUFnQjtJQTRDN0MsWUFBbUIsU0FBc0IsRUFBUyxPQUFxQjtRQUNuRSxLQUFLLENBQUMsU0FBUyxFQUFFLE9BQU8sQ0FBQyxDQUFDO1FBRFgsY0FBUyxHQUFULFNBQVMsQ0FBYTtRQUFTLFlBQU8sR0FBUCxPQUFPLENBQWM7UUF4Qy9ELGdCQUFXLEdBQWtCLEVBQUUsQ0FBQztRQUl4QyxjQUFjO1FBQ04scUJBQWdCLEdBQVcsMERBQTBELENBQUM7UUFFdEYsWUFBTyxHQUFXO1lBQ3RCLDJCQUEyQixFQUFFLDhCQUE4QjtZQUMzRCwyQkFBMkIsRUFBRSw4QkFBOEI7WUFDM0QsMkJBQTJCLEVBQUUsNkJBQTZCO1lBQzFELHlDQUF5QyxFQUFFLDBDQUEwQztZQUNyRiwyQkFBMkIsRUFBRSwrQkFBK0I7U0FDL0QsQ0FBQztRQUVNLGFBQVEsR0FBUyxFQUFFLENBQUM7UUFFcEIsb0JBQWUsR0FBVyxFQUFFLENBQUM7UUFFN0IsbUJBQWMsR0FBYyxFQUFDLENBQUMsRUFBRSxDQUFDLEdBQUcsRUFBRSxDQUFDLEVBQUUsQ0FBQyxHQUFHLEVBQUMsQ0FBQztRQUUvQyxlQUFVLEdBQVc7WUFDekIsS0FBSyxFQUFFLE1BQU07WUFDYixTQUFTLEVBQUUsS0FBSztZQUNoQixRQUFRLEVBQUUsS0FBSztZQUNmLFlBQVksRUFBRSxTQUFTO1lBQ3ZCLGVBQWUsRUFBRSxhQUFhO1lBQzlCLEdBQUcsRUFBRSxLQUFLO1lBQ1YsSUFBSSxFQUFFLEtBQUs7WUFDWCxRQUFRLEVBQUUsTUFBTTtZQUNoQixPQUFPLEVBQUUsU0FBUztZQUNsQixXQUFXLEVBQUUsVUFBVTtZQUN2QixjQUFjLEVBQUUsY0FBYztTQUNqQyxDQUFDO0lBU0YsQ0FBQztJQUVELFFBQVE7UUFFSixJQUFJLENBQUMsR0FBRyxDQUFDLFdBQVcsR0FBRyxDQUFDLEtBQWMsRUFBRSxFQUFFO1lBQ3RDLElBQUksQ0FBQyxZQUFZLENBQUMsS0FBSyxFQUFFLEtBQUssQ0FBQyxDQUFDO1FBQ3BDLENBQUMsQ0FBQztRQUNGLElBQUksQ0FBQyxHQUFHLENBQUMsTUFBTSxHQUFHLEdBQUcsRUFBRTtZQUNuQixZQUFZLENBQUMsSUFBSSxDQUFDLGNBQWMsQ0FBQyxDQUFDO1lBQ2xDLElBQUksQ0FBQyxjQUFjLEdBQUcsVUFBVSxDQUFDLEdBQUcsRUFBRTtnQkFDbEMsSUFBSSxDQUFDLFlBQVksQ0FBQyxLQUFLLENBQUMsQ0FBQztZQUM3QixDQUFDLENBQUMsQ0FBQztRQUNQLENBQUMsQ0FBQztJQUNOLENBQUM7SUFFRCxXQUFXLENBQUMsUUFBdUI7UUFDL0IsSUFBSSxRQUFRLENBQUMsY0FBYyxDQUFDLE1BQU0sQ0FBQyxFQUFFO1lBQ2pDLElBQUksQ0FBQyxZQUFZLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxhQUFhLEVBQUUsRUFBRSxRQUFRLENBQUMsSUFBSSxDQUFDLFlBQVksQ0FBQyxDQUFDO1NBQ2hGO1FBRUQsSUFBSSxRQUFRLENBQUMsY0FBYyxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLE1BQU0sQ0FBQyxhQUFhLEVBQUUsRUFBRTtZQUN2RSxJQUFJLENBQUMsWUFBWSxDQUFDLFFBQVEsQ0FBQyxNQUFNLENBQUMsYUFBYSxFQUFFLENBQUMsQ0FBQztTQUN0RDtJQUNMLENBQUM7SUFFRCxXQUFXLEtBQVcsSUFBSSxDQUFDLGVBQWUsRUFBRSxDQUFDLENBQUMsQ0FBQztJQUV2QyxZQUFZLENBQUMsY0FBdUIsRUFBRSxLQUFlO1FBQ3pELElBQUksQ0FBQyxjQUFjLEVBQUU7WUFDakIsSUFBSSxDQUFDLFNBQVMsR0FBRyxFQUFFLENBQUMsTUFBTSxDQUFDLFFBQVEsR0FBRyxJQUFJLENBQUMsTUFBTSxDQUFDLEVBQUUsQ0FBQyxDQUFDO1lBQ3RELElBQUksQ0FBQyxlQUFlLEVBQUUsQ0FBQztTQUMxQjtRQUNELElBQUksS0FBSztZQUFFLElBQUksQ0FBQyxRQUFRLENBQUMsS0FBSyxDQUFDLENBQUM7UUFDaEMsS0FBSyxDQUFDLFlBQVksQ0FBQyxHQUFHLEVBQUUsQ0FBQyxJQUFJLENBQUMsU0FBUyxFQUFFLENBQUMsQ0FBQztJQUMvQyxDQUFDO0lBRU8sUUFBUSxDQUFDLEtBQWM7UUFDM0IsSUFBSSxDQUFDLFNBQVMsR0FBRyxLQUFLLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FBQztRQUN6QyxJQUFJLENBQUMsYUFBYSxHQUFHLE1BQU0sQ0FBQztRQUM1QixJQUFJLENBQUMsU0FBUyxHQUFHLEtBQUssQ0FBQyxLQUFLLENBQUM7UUFDN0IsSUFBSSxDQUFDLFlBQVksR0FBRyxLQUFLLENBQUMsWUFBWSxDQUFDO1FBRXZDLElBQUksQ0FBQyxJQUFJLEdBQUcsTUFBTSxDQUFDLE1BQU0sQ0FBQyxFQUFFLEVBQUUsS0FBSyxDQUFDLElBQUksQ0FBQyxDQUFDO1FBQzFDLElBQUksQ0FBQyxRQUFRLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDO1FBRXRELElBQUksQ0FBQyxXQUFXLEdBQUcsTUFBTSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLEdBQUcsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDO1FBRTlGLElBQUksSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsS0FBSyxPQUFPLElBQUksSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsS0FBSyxLQUFLLEVBQUU7WUFDOUQsSUFBSSxDQUFDLFdBQVcsR0FBRyxJQUFJLENBQUMsV0FBVyxDQUFDLE9BQU8sRUFBRSxDQUFDO1NBQ2pEO0lBQ0wsQ0FBQztJQUVPLGVBQWU7UUFDbkIsS0FBSyxDQUFDLFdBQVcsRUFBRSxDQUFDO1FBQ3BCLElBQUksSUFBSSxDQUFDLFNBQVMsRUFBRTtZQUNoQixJQUFJLENBQUMsU0FBUyxDQUFDLE1BQU0sRUFBRSxDQUFDO1lBQ3hCLElBQUksQ0FBQyxTQUFTLEdBQUcsSUFBSSxDQUFDO1NBQ3pCO0lBQ0wsQ0FBQztJQUVPLFNBQVM7UUFDYixJQUFJLElBQUksQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLEtBQUssS0FBSyxJQUFJLElBQUksQ0FBQyxZQUFZO1lBQUUsT0FBTztRQUM3RCxLQUFLLENBQUMsTUFBTSxFQUFFLENBQUM7UUFFZixJQUFJLENBQUMsY0FBYyxFQUFFLENBQUM7UUFFdEIsSUFBSSxDQUFDLGVBQWUsRUFBRSxDQUFDO1FBRXZCLElBQUksQ0FBQyxZQUFZLEVBQUUsQ0FBQztRQUVwQixJQUFJLENBQUMsVUFBVSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQztJQUMvQixDQUFDO0lBRU8sY0FBYztRQUVsQixJQUFJLElBQUksQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxNQUFNLEdBQUcsQ0FBQyxDQUFDLEtBQUssT0FBTyxFQUFFO1lBQ3ZELEtBQUssQ0FBQyxTQUFTLENBQUMsTUFBTSxDQUFDLENBQUM7U0FDM0I7YUFBTTtZQUNILEtBQUssQ0FBQyxTQUFTLENBQUMsUUFBUSxDQUFDLENBQUM7U0FDN0I7SUFDTCxDQUFDO0lBRU8sWUFBWTtRQUNoQixJQUFJLENBQUMsSUFBSSxDQUFDLFNBQVMsRUFBRTtZQUNqQixJQUFJLENBQUMsU0FBUyxHQUFHLElBQUksQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQztpQkFDbEMsSUFBSSxDQUFDLE9BQU8sRUFBRSx1QkFBdUIsQ0FBQztpQkFDdEMsSUFBSSxDQUFDLElBQUksRUFBRSxPQUFPLEdBQUcsSUFBSSxDQUFDLE1BQU0sQ0FBQyxFQUFFLENBQUMsQ0FBQztTQUM3QztRQUVELElBQUksSUFBSSxDQUFDLE1BQU0sQ0FBQyxTQUFTO1lBQUUsSUFBSSxDQUFDLGtCQUFrQixFQUFFLENBQUM7SUFDekQsQ0FBQztJQUVPLHNCQUFzQjtRQUMxQixJQUFJLE9BQU8sR0FBUSxJQUFJLENBQUMsU0FBUyxDQUFDLFNBQVMsQ0FBQyxvQkFBb0IsQ0FBQzthQUM1RCxJQUFJLENBQUMsSUFBSSxDQUFDLFdBQVcsRUFBRSxVQUFTLENBQUMsSUFBSSxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO1FBQ3ZELDBFQUEwRTtRQUUxRSxPQUFPLENBQUMsSUFBSSxFQUFFLENBQUMsTUFBTSxFQUFFLENBQUM7UUFFeEIsSUFBSSxlQUFvQixDQUFDO1FBRXpCLElBQUksSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsS0FBSyxPQUFPLElBQUksSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsS0FBSyxLQUFLLEVBQUU7WUFDOUQsZUFBZSxHQUFHLE9BQU8sQ0FBQyxLQUFLLEVBQUU7aUJBQzVCLE1BQU0sQ0FBQyxHQUFHLENBQUM7aUJBQ1gsSUFBSSxDQUFDLE9BQU8sRUFBRSxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRSxDQUFDLDZCQUE2QixHQUFHLEtBQUssR0FBRyxJQUFJLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7U0FDN0Y7YUFBTTtZQUNILGVBQWUsR0FBRyxPQUFPLENBQUMsS0FBSyxFQUFFLENBQUM7U0FDckM7UUFFRCxJQUFJLGFBQWEsR0FBUSxlQUFlLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQzthQUMvQyxJQUFJLENBQUMsT0FBTyxFQUFFLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFLENBQUMsMkJBQTJCLEdBQUcsS0FBSyxHQUFHLElBQUksQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDLENBQUM7YUFDbEYsSUFBSSxDQUFDLFdBQVcsRUFBRSwyQkFBMkIsR0FBRyxJQUFJLENBQUMsTUFBTSxDQUFDLEVBQUUsR0FBRyxHQUFHLENBQUMsQ0FBQztRQUUzRSxJQUFJLFlBQVksR0FBUSxlQUFlLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQzthQUM5QyxJQUFJLENBQUMsT0FBTyxFQUFFLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFLENBQUMsMEJBQTBCLEdBQUcsS0FBSyxHQUFHLElBQUksQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDLENBQUM7YUFDakYsSUFBSSxDQUFDLElBQUksRUFBRSxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRSxDQUFDLDBCQUEwQixHQUFHLEtBQUssR0FBRyxJQUFJLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxLQUFLLEVBQUUsRUFBRSxDQUFDLENBQUMsQ0FBQztRQUV2RyxPQUFPLEVBQUUsYUFBYSxFQUFFLGFBQWEsRUFBRSxZQUFZLEVBQUUsWUFBWSxFQUFFLENBQUM7SUFDeEUsQ0FBQztJQUVPLGVBQWU7UUFDbkIsRUFBRSxDQUFDLE1BQU0sQ0FBQyxHQUFHLEdBQUcsSUFBSSxDQUFDLE1BQU0sQ0FBQyxFQUFFLEdBQUcsbUNBQW1DLENBQUMsQ0FBQyxNQUFNLEVBQUUsQ0FBQztRQUUvRSxJQUFJLENBQUMsS0FBSzthQUNMLE1BQU0sQ0FBQyxNQUFNLENBQUM7YUFDZCxJQUFJLENBQUMsT0FBTyxFQUFFLHNCQUFzQixDQUFDO2FBQ3JDLElBQUksQ0FBQyxHQUFHLEVBQUUsSUFBSSxDQUFDLGdCQUFnQixDQUFDO2FBQ2hDLElBQUksQ0FBQyxXQUFXLEVBQUUsS0FBSyxDQUFDLGlCQUFpQixDQUFDLElBQUksQ0FBQyxjQUFjLENBQUMsQ0FBQyxFQUFFLElBQUksQ0FBQyxjQUFjLENBQUMsQ0FBQyxFQUFFLElBQUksQ0FBQyxDQUFDLENBQUM7SUFDeEcsQ0FBQztJQUVPLFVBQVUsQ0FBQyxLQUF5QjtRQUN4Qyx1QkFBdUI7UUFDdkIseUJBQXlCO1FBRXpCLElBQUksZUFBZSxHQUFRLElBQUksQ0FBQyxzQkFBc0IsRUFBRSxDQUFDO1FBRXpELElBQUksQ0FBQyxTQUFTLENBQUMsS0FBSyxFQUFFLGVBQWUsQ0FBQyxhQUFhLENBQUMsQ0FBQztRQUVyRCxJQUFJLENBQUMsT0FBTyxDQUFDLEtBQUssRUFBRSxlQUFlLENBQUMsWUFBWSxDQUFDLENBQUM7UUFFbEQsS0FBSyxJQUFJLE1BQU0sR0FBVyxDQUFDLEVBQUUsTUFBTSxHQUFHLEtBQUssQ0FBQyxNQUFNLEVBQUUsTUFBTSxFQUFFLEVBQUU7WUFDMUQsSUFBSSxDQUFDLGtCQUFrQixDQUFDLE1BQU0sRUFBRSxLQUFLLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQztTQUNsRDtJQUNMLENBQUM7SUFFRCxjQUFjO0lBQ04sU0FBUyxDQUFDLFVBQThCLEVBQUUsUUFBYTtRQUUzRCxJQUFJLElBQUksR0FBa0QsVUFBVSxDQUFDO1FBRXJFLElBQUksSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsS0FBSyxPQUFPO1lBQUUsSUFBSSxHQUFHLElBQUksQ0FBQyxZQUFZLENBQUMsVUFBVSxDQUFDLENBQUM7UUFFeEUsSUFBSSxJQUFJLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxLQUFLLEtBQUssRUFBRTtZQUU3QixJQUFJLElBQUksQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLEtBQUssTUFBTSxFQUFFO2dCQUM5QixRQUFRLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQztxQkFDbEIsSUFBSSxDQUFDLEdBQUcsRUFBRSxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRSxDQUFDLElBQUksQ0FBQyxhQUFhLENBQUMsQ0FBQyxFQUFFLElBQUksQ0FBQyxDQUFDO3FCQUNoRCxJQUFJLENBQUMsT0FBTyxFQUFFLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFLENBQUMseUJBQXlCLEdBQUcsQ0FBQyxDQUFDO3FCQUN0RCxJQUFJLENBQUMsTUFBTSxFQUFFLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUM7cUJBQ2hELElBQUksQ0FBQyxjQUFjLEVBQUUsSUFBSSxDQUFDLENBQUM7YUFDbkM7WUFFRCxRQUFRLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQztpQkFDbEIsSUFBSSxDQUFDLEdBQUcsRUFBRSxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRTtnQkFDaEIsSUFBSSxJQUFJLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxLQUFLLE1BQU0sRUFBRTtvQkFDOUIsT0FBTyxJQUFJLENBQUMsYUFBYSxDQUFDLENBQUMsRUFBRSxJQUFJLEVBQUUsSUFBSSxDQUFDLENBQUM7aUJBQzVDO2dCQUNELE9BQU8sSUFBSSxDQUFDLGFBQWEsQ0FBQyxDQUFDLEVBQUUsSUFBSSxDQUFDLENBQUM7WUFDdkMsQ0FBQyxDQUFDO2lCQUNELElBQUksQ0FBQyxPQUFPLEVBQUUsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLEVBQUUsQ0FBQyx5QkFBeUIsR0FBRyxDQUFDLENBQUM7aUJBQ3RELElBQUksQ0FBQyxRQUFRLEVBQUUsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQztpQkFDbEQsSUFBSSxDQUFDLGtCQUFrQixFQUFFLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxDQUFDO2lCQUNqRixLQUFLLENBQUMsTUFBTSxFQUFFLE1BQU0sQ0FBQyxDQUFDO1NBQzlCO0lBQ0wsQ0FBQztJQUVEOzs7Ozs7Ozs7Ozs7OztPQWNHO0lBQ0ssYUFBYSxDQUFDLE9BQWUsRUFBRSxVQUF5RCxFQUFFLGdCQUEwQjtRQUN4SCxnQkFBZ0IsR0FBRyxnQkFBZ0IsSUFBSSxLQUFLLENBQUM7UUFFN0MsSUFBSSxVQUFVLEdBQWUsRUFBRSxDQUFDLEVBQUUsSUFBSSxFQUFFLENBQUMsRUFBRSxJQUFJLEVBQUUsS0FBSyxFQUFFLEtBQUssRUFBRSxFQUMzRCxVQUFVLEdBQVEsQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxLQUFLLFFBQVEsSUFBSSxJQUFJLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsTUFBTSxHQUFHLENBQUMsQ0FBQyxLQUFLLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsYUFBYSxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsV0FBVyxFQUNoSixLQUFLLEdBQVEsQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxLQUFLLE1BQU0sSUFBSSxnQkFBZ0IsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsSUFBSSxFQUFFLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxJQUFJLEVBQUUsRUFDdkYsSUFBNEMsQ0FBQztRQUVqRCxJQUFJLEdBQUcsQ0FBQyxJQUFJLENBQUMsaUJBQWlCLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQyxVQUFVLENBQUMsT0FBTyxDQUFDLENBQUM7UUFFL0UsSUFBSSxTQUFTLEdBQWEsS0FBSyxDQUFDLEtBQUssQ0FBQyxVQUFVLENBQUMsQ0FBQztRQUVsRCxLQUFLLENBQUMsT0FBTyxDQUFDLENBQUMsSUFBOEIsRUFBRSxNQUFjLEVBQUUsRUFBRTtZQUM3RCxVQUFVLEdBQUcsSUFBSSxDQUFDLG1CQUFtQixDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsRUFBRSxPQUFPLENBQUMsQ0FBQztZQUM3RCxPQUFPLFVBQVUsQ0FBQyxLQUFLLENBQUM7UUFDNUIsQ0FBQyxDQUFDLENBQUM7UUFFSCxLQUFLLENBQUMsQ0FBQyxDQUFDLEdBQUcsRUFBRSxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDO1FBRWxELElBQUksSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsS0FBSyxNQUFNLElBQUksZ0JBQWdCLEVBQUU7WUFDbEQsS0FBSyxDQUFDLENBQUMsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLFVBQVUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO1NBQ3ZDO2FBQU07WUFDSCxLQUFLLENBQUMsRUFBRSxDQUFDLEdBQUcsRUFBRSxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQyxDQUFDO2lCQUMvQixFQUFFLENBQUMsQ0FBQyxJQUFJLEVBQUUsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsS0FBSyxLQUFLLElBQUksSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsS0FBSyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxVQUFVLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztTQUN6SDtRQUVELE9BQU8sU0FBUyxDQUFDLElBQUksQ0FBQyxDQUFDO0lBQzNCLENBQUM7SUFFTyxpQkFBaUIsQ0FBQyxZQUFpQjtRQUN2QyxPQUFPLElBQUksQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLEtBQUssT0FBTyxDQUFDO0lBQ3pDLENBQUM7SUFFTyxhQUFhLENBQUMsT0FBaUM7UUFDbkQsT0FBTyxJQUFJLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxLQUFLLE9BQU8sQ0FBQztJQUN6QyxDQUFDO0lBRU8sbUJBQW1CLENBQUMsS0FBK0IsRUFBRSxPQUFlO1FBQ3hFLElBQUksSUFBSSxDQUFDLGFBQWEsQ0FBQyxLQUFLLENBQUMsRUFBRSxFQUFFLFFBQVE7WUFDckMsT0FBTyxLQUFLLENBQUM7U0FDaEI7UUFFRCxJQUFJLE1BQU0sR0FBVyxLQUFLLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLEdBQUcsQ0FBQztRQUMxQyxJQUFJLEtBQUssR0FBWSxJQUFJLENBQUM7UUFDMUIsSUFBSSxFQUFFLEdBQVcsQ0FBQyxDQUFDO1FBRW5CLElBQUksSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsS0FBSyxLQUFLLEVBQUU7WUFDN0IsRUFBRSxHQUFHLEtBQUssQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsR0FBRyxHQUFHLEtBQUssQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsU0FBUyxDQUFDO1NBQzFEO2FBQU07WUFDSCxLQUFLLEdBQUcsS0FBSyxDQUFDLFdBQVcsQ0FBQyxLQUFLLEVBQUUsT0FBTyxDQUFDLENBQUM7U0FDN0M7UUFDRCxPQUFPLEVBQUUsQ0FBQyxFQUFFLEtBQUssQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLE1BQU0sRUFBRSxFQUFFLEVBQUUsRUFBRSxFQUFFLEtBQUssRUFBRSxLQUFLLEVBQUUsQ0FBQztJQUMzRCxDQUFDO0lBRUQsTUFBTTtJQUNFLE9BQU8sQ0FBQyxLQUF5QixFQUFFLGFBQWtCO1FBQ3pELEtBQUssSUFBSSxNQUFNLEdBQVcsQ0FBQyxFQUFFLE1BQU0sR0FBRyxLQUFLLENBQUMsTUFBTSxFQUFFLE1BQU0sRUFBRSxFQUFFO1lBQzFELElBQUksSUFBSSxHQUFnQixLQUFLLENBQUMsTUFBTSxDQUFDLENBQUM7WUFFdEMsSUFBSSxJQUFJLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxLQUFLLE9BQU8sSUFBSSxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQztnQkFDdkQsQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsSUFBSSxJQUFJLENBQUMsQ0FBQyxDQUFDLE1BQU0sSUFBSSxDQUFDLENBQUM7Z0JBQUUsU0FBUztZQUU1RCxJQUFJLFNBQVMsR0FBUSxhQUFhLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQztpQkFDNUMsSUFBSSxDQUFDLE9BQU8sRUFBRSxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRSxDQUFDLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxJQUFJLEVBQUUsQ0FBQyxFQUFFLE1BQU0sQ0FBQyxDQUFDO2lCQUMvRCxJQUFJLENBQUMsR0FBRyxFQUFFLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxNQUFNLEVBQUUsQ0FBQyxFQUFFLElBQUksRUFBRSxPQUFPLENBQUMsQ0FBQztpQkFDN0QsSUFBSSxDQUFDLE1BQU0sRUFBRSxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRSxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsTUFBTSxFQUFFLENBQUMsRUFBRSxJQUFJLEVBQUUsUUFBUSxDQUFDLENBQUM7aUJBQ2pFLElBQUksQ0FBQyxRQUFRLEVBQUUsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLE1BQU0sRUFBRSxDQUFDLEVBQUUsSUFBSSxFQUFFLGFBQWEsQ0FBQyxDQUFDO2lCQUN4RSxJQUFJLENBQUMsY0FBYyxFQUFFLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxNQUFNLEVBQUUsQ0FBQyxFQUFFLElBQUksRUFBRSxhQUFhLENBQUMsQ0FBQztpQkFDOUUsSUFBSSxDQUFDLFdBQVcsRUFBRSxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRSxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsTUFBTSxFQUFFLENBQUMsRUFBRSxJQUFJLEVBQUUsVUFBVSxDQUFDLENBQUM7aUJBQ3hFLEtBQUssQ0FBQyxTQUFTLEVBQUUsT0FBTyxDQUFDLENBQUM7WUFFL0IsSUFBSSxZQUFZLEdBQWEsSUFBSSxDQUFDLG9CQUFvQixDQUFDLElBQUksQ0FBQyxDQUFDO1lBRTdELEtBQUssQ0FBQyxnQkFBZ0IsQ0FBQyxTQUFTLEVBQUUsRUFBRSxJQUFJLEVBQUUsSUFBSSxFQUFFLE1BQU0sRUFBRSxNQUFNLEVBQUUsUUFBUSxFQUFFLFlBQVksRUFBRSxDQUFDLENBQUM7U0FDN0Y7SUFDTCxDQUFDO0lBRU8sU0FBUyxDQUFDLE9BQWUsRUFBRSxPQUFlLEVBQUUsS0FBa0IsRUFBRSxRQUF5RTtRQUM3SSxJQUFJLENBQUMsQ0FBQyxLQUFLLENBQUMsV0FBVyxDQUFDLEtBQUssRUFBRSxPQUFPLENBQUMsSUFBSSxJQUFJLENBQUMsVUFBVSxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsVUFBVSxDQUFDO1lBQUUsT0FBTyxFQUFFLENBQUM7UUFDdkcsSUFBSSxFQUFFLEdBQUcsS0FBSyxDQUFDLFFBQVEsQ0FBQyxPQUFPLEVBQUUsS0FBSyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxPQUFPLENBQUMsS0FBSyxFQUFFLEVBQUUsQ0FBQyxDQUFDO1FBQ3pFLElBQUksS0FBSyxHQUFvQixFQUFFLENBQUM7UUFDaEMsSUFBSSxRQUFRLEtBQUssVUFBVSxFQUFFO1lBQ3pCLElBQUksQ0FBQyxHQUFXLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxFQUFFLENBQUMsSUFBSSxPQUFPLElBQUksQ0FBQyxRQUFRLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxLQUFLLFdBQVcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLGNBQWMsQ0FBQyxDQUFDLENBQUM7WUFDaEksSUFBSSxDQUFDLEdBQVcsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLEVBQUUsQ0FBQyxJQUFJLE9BQU8sSUFBSSxDQUFDLFFBQVEsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLEtBQUssV0FBVyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsY0FBYyxDQUFDLENBQUMsQ0FBQztZQUNoSSxLQUFLLEdBQUcsS0FBSyxDQUFDLGlCQUFpQixDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsSUFBSSxDQUFDLENBQUM7U0FDL0M7YUFBTTtZQUNILEtBQUssR0FBRyxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsRUFBRSxDQUFDLElBQUksSUFBSSxDQUFDLFFBQVEsQ0FBQyxFQUFFLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLEVBQUUsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLFFBQVEsRUFBRSxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUM7U0FDNUc7UUFDRCxPQUFPLEtBQUssQ0FBQztJQUNqQixDQUFDO0lBRU8sZ0JBQWdCLENBQUMsS0FBa0IsRUFBRSxPQUFlLEVBQUUsT0FBZTtRQUN6RSxJQUFJLENBQUMsS0FBSyxDQUFDLFdBQVcsQ0FBQyxLQUFLLEVBQUUsT0FBTyxDQUFDO1lBQUUsT0FBTyxFQUFFLENBQUM7UUFDbEQsSUFBSSxFQUFFLEdBQVcsS0FBSyxDQUFDLFFBQVEsQ0FBQyxPQUFPLEVBQUUsS0FBSyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxPQUFPLENBQUMsS0FBSyxFQUFFLEVBQUUsQ0FBQyxDQUFDO1FBQ2pGLElBQUksTUFBTSxHQUFXLEtBQUssQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsS0FBSyxDQUFDO1FBQzVDLElBQUksS0FBSyxHQUFXLEtBQUssQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsS0FBSyxDQUFDO1FBQzNDLElBQUksUUFBUSxHQUFjLElBQUksQ0FBQyxlQUFlLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxLQUFLLEVBQUUsT0FBTyxFQUFFLEtBQUssQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUM7UUFDN0YsSUFBSSxXQUFXLEdBQVcsSUFBSSxDQUFDLFVBQVUsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLGNBQWMsQ0FBQztRQUM5RSxJQUFJLFdBQVcsR0FBVyxJQUFJLENBQUMsVUFBVSxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsY0FBYyxDQUFDO1FBRTlFLElBQUksQ0FBQyxTQUFTLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsRUFBRSxPQUFPLEVBQUUsUUFBUSxDQUFDLENBQUMsRUFBRSxXQUFXLENBQUMsQ0FBQztRQUVuRSxJQUFJLEtBQUssQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsS0FBSyxLQUFLLElBQUksQ0FBQyxTQUFTLElBQUksS0FBSyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxLQUFLLEtBQUssSUFBSSxDQUFDLFNBQVMsRUFBRTtZQUN4RixJQUFJLGNBQWMsR0FBRyxFQUFFLEdBQUcsV0FBVyxDQUFDO1lBRXRDLElBQUksSUFBSSxDQUFDLGVBQWUsR0FBRyxjQUFjO2dCQUFFLElBQUksQ0FBQyxlQUFlLEdBQUcsY0FBYyxDQUFDO1NBQ3BGO1FBRUQsSUFBSSxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLFFBQVEsS0FBSyxJQUFJO1lBQ3BDLEtBQUssQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsS0FBSyxHQUFHLElBQUksQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLFFBQVEsQ0FBQztZQUNwRCxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLFFBQVEsS0FBSyxJQUFJO2dCQUNwQyxLQUFLLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLEtBQUssR0FBRyxJQUFJLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxRQUFRLENBQUMsRUFBRTtZQUN0RCxPQUFPLElBQUksQ0FBQyxRQUFRLENBQUMsRUFBRSxDQUFDLENBQUM7WUFDekIsT0FBTyxFQUFFLENBQUM7U0FDYjtRQUVELElBQUksQ0FBQyxRQUFRLENBQUMsRUFBRSxDQUFDLEdBQUc7WUFDaEIsTUFBTSxFQUFFLE1BQU07WUFDZCxLQUFLLEVBQUUsS0FBSztZQUNaLENBQUMsRUFBRSxRQUFRLENBQUMsQ0FBQztZQUNiLENBQUMsRUFBRSxRQUFRLENBQUMsQ0FBQztZQUNiLFdBQVcsRUFBRSxXQUFXO1lBQ3hCLFdBQVcsRUFBRSxXQUFXO1NBQzNCLENBQUM7UUFFRixPQUFPLEVBQUUsQ0FBQztJQUNkLENBQUM7SUFFTyxlQUFlLENBQUMsT0FBZSxFQUFFLE9BQWUsRUFBRSxPQUFlO1FBQ3JFLElBQUksSUFBSSxHQUFXLENBQUMsQ0FBQztRQUNyQixJQUFJLElBQUksR0FBVyxDQUFDLENBQUM7UUFFckIsSUFBSSxHQUFHLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQztRQUNyQyxJQUFJLEdBQUcsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDO1FBRTdCLE9BQU8sRUFBRSxDQUFDLEVBQUUsSUFBSSxFQUFFLENBQUMsRUFBRSxJQUFJLEVBQUUsQ0FBQztJQUNoQyxDQUFDO0lBRUQsaUJBQWlCO0lBQ1Qsb0JBQW9CLENBQUMsWUFBeUI7UUFDbEQsT0FBTyxVQUFTLEtBQWEsRUFBRSxVQUFvQjtZQUMvQyxVQUFVLEdBQUcsVUFBVSxJQUFJLEtBQUssQ0FBQztZQUNqQyxZQUFZLENBQUMsUUFBUSxDQUFDLFlBQVksRUFBRSxLQUFLLEVBQUUsVUFBVSxDQUFDLENBQUM7UUFDM0QsQ0FBQyxDQUFDO0lBQ04sQ0FBQztJQUVPLFFBQVEsQ0FBQyxZQUF5QixFQUFFLE1BQWMsRUFBRSxXQUFvQjtRQUM1RSxNQUFNLEdBQUcsTUFBTSxDQUFDLE9BQU8sQ0FBQyxLQUFLLEVBQUUsRUFBRSxDQUFDLENBQUM7UUFDbkMsSUFBRyxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsY0FBYyxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxNQUFNLENBQUMsQ0FBQyxLQUFLO1lBQUUsT0FBTztRQUNqRixJQUFJLEtBQUssR0FBVyxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsTUFBTSxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsTUFBTSxDQUFDLENBQUMsS0FBSyxDQUFDO1FBQzVHLElBQUksUUFBUSxHQUFjLElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxNQUFNLEVBQUUsV0FBVyxFQUFFLEtBQUssQ0FBQyxDQUFDO1FBQzdFLElBQUksV0FBVyxHQUFXLElBQUksQ0FBQyxRQUFRLENBQUMsTUFBTSxDQUFDLENBQUMsV0FBVyxDQUFDO1FBRTVELElBQUksV0FBVyxLQUFLLENBQUMsSUFBSSxXQUFXO1lBQUUsV0FBVyxHQUFHLENBQUMsQ0FBQztRQUV0RCxJQUFJLENBQUMsbUJBQW1CLENBQUMsTUFBTSxFQUFFLFdBQVcsQ0FBQyxDQUFDO1FBQzlDLEVBQUUsQ0FBQyxNQUFNLENBQUMsR0FBRyxHQUFHLElBQUksQ0FBQyxNQUFNLENBQUMsRUFBRSxHQUFHLGVBQWUsR0FBRyxNQUFNLENBQUM7YUFDckQsSUFBSSxDQUFDLEdBQUcsRUFBRSxLQUFLLENBQUM7YUFDaEIsSUFBSSxDQUFDLFdBQVcsRUFBRSxLQUFLLENBQUMsaUJBQWlCLENBQUMsUUFBUSxDQUFDLENBQUMsRUFBRSxRQUFRLENBQUMsQ0FBQyxFQUFFLElBQUksQ0FBQyxDQUFDO2FBQ3hFLElBQUksQ0FBQyxjQUFjLEVBQUUsV0FBVyxDQUFDLENBQUM7SUFDM0MsQ0FBQztJQUVPLG1CQUFtQixDQUFDLE1BQWMsRUFBRSxXQUFvQjtRQUM1RCxJQUFJLE1BQU0sR0FBVyxJQUFJLENBQUMsUUFBUSxDQUFDLE1BQU0sQ0FBQyxDQUFDLE1BQU0sQ0FBQztRQUVsRCxJQUFJLFFBQVEsR0FBYyxXQUFXLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxNQUFNLEVBQUUsV0FBVyxFQUFFLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsY0FBYyxDQUFDO1FBRWhILEVBQUUsQ0FBQyxNQUFNLENBQUMsR0FBRyxHQUFHLElBQUksQ0FBQyxNQUFNLENBQUMsRUFBRSxHQUFHLG1DQUFtQyxDQUFDO1lBQ2pFLDZCQUE2QjthQUM1QixJQUFJLENBQUMsTUFBTSxFQUFFLE1BQU0sQ0FBQzthQUNwQixJQUFJLENBQUMsV0FBVyxFQUFFLElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxRQUFRLENBQUMsQ0FBQyxFQUFFLFFBQVEsQ0FBQyxDQUFDLEVBQUUsSUFBSSxDQUFDLENBQUM7YUFDdkUsSUFBSSxDQUFDLGNBQWMsRUFBRSxDQUFDLENBQUM7YUFDdkIsSUFBSSxDQUFDLFFBQVEsRUFBRSxNQUFNLENBQUMsQ0FBQztJQUNoQyxDQUFDO0lBRU8saUJBQWlCLENBQUMsTUFBYyxFQUFFLFdBQW9CLEVBQUUsYUFBc0I7UUFDbEYsSUFBSSxJQUFJLEdBQVcsSUFBSSxDQUFDLFFBQVEsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUM7UUFDM0MsSUFBSSxJQUFJLEdBQVcsSUFBSSxDQUFDLFFBQVEsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUM7UUFFM0MsSUFBSSxDQUFDLFdBQVc7WUFBRSxPQUFPLEVBQUUsQ0FBQyxFQUFFLElBQUksRUFBRSxDQUFDLEVBQUUsSUFBSSxFQUFFLENBQUM7UUFFOUMsSUFBSSxhQUFhLEVBQUU7WUFDZixJQUFJLElBQUksQ0FBQyxDQUFDO1lBQ1YsSUFBSSxJQUFJLENBQUMsQ0FBQztTQUNiO2FBQU07WUFDSCxJQUFJLElBQUksQ0FBQyxDQUFDO1lBQ1YsSUFBSSxJQUFJLENBQUMsQ0FBQztTQUNiO1FBRUQsT0FBTyxFQUFFLENBQUMsRUFBRSxJQUFJLEVBQUUsQ0FBQyxFQUFFLElBQUksRUFBRSxDQUFDO0lBQ2hDLENBQUM7SUFFRCxRQUFRO0lBQ0EsU0FBUyxDQUFDLE1BQWdCLEVBQUUsT0FBZSxFQUFFLFVBQWtCLEVBQUUsU0FBaUI7UUFDdEYsSUFBSSxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxPQUFPO1lBQUUsT0FBTztRQUU5QyxVQUFVLElBQUksU0FBUyxHQUFHLENBQUMsQ0FBQztRQUU1QixJQUFJLEtBQUssR0FBUSxLQUFLLENBQUMsUUFBUSxDQUFDLE1BQU0sRUFBRSxPQUFPLEVBQUUsVUFBVSxFQUFFLElBQUksQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUM7UUFDakYsa0NBQWtDO1FBRWxDLElBQUksT0FBTyxHQUFRLEtBQUssQ0FBQyxNQUFNLENBQUMsNkJBQTZCLENBQUMsQ0FBQztRQUUvRCxJQUFJLGVBQWUsR0FBVyxJQUFJLENBQUMsbUJBQW1CLENBQUMsTUFBTSxDQUFDLENBQUM7UUFFL0QsSUFBSSxPQUFPLEdBQUcsRUFBRSxHQUFHLFNBQVMsQ0FBQyxDQUFDLDZDQUE2QztRQUMzRSxLQUFLLENBQUMsb0JBQW9CLENBQUMsT0FBTyxFQUFFLElBQUksQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxFQUFFLEVBQUUsT0FBTyxFQUFFLE9BQU8sRUFBRSxXQUFXLEVBQUUsZUFBZSxFQUFFLENBQUMsQ0FBQztRQUU1RyxtREFBbUQ7UUFDbkQsK0RBQStEO1FBQy9ELHFGQUFxRjtRQUNyRiw0RUFBNEU7UUFDNUUsSUFBSTtJQUNSLENBQUM7SUFFTyxtQkFBbUIsQ0FBQyxNQUFnQjtRQUN4QyxJQUFJLFNBQVMsR0FBRyxJQUFJLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLE9BQU8sQ0FBQyxTQUFTLEVBQUUsSUFBSSxDQUFDLFNBQVMsQ0FBQyxXQUFXLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUM7UUFFN0csT0FBTyxTQUFTLENBQUMsUUFBUSxFQUFFLENBQUMsTUFBTSxDQUFDO0lBQ3ZDLENBQUM7SUFFRCx3RUFBd0U7SUFFeEUsbUVBQW1FO0lBRW5FLCtDQUErQztJQUMvQyxrRkFBa0Y7SUFDbEYsbURBQW1EO0lBRW5ELHNEQUFzRDtJQUV0RCw0QkFBNEI7SUFDNUIsSUFBSTtJQUVKLFlBQVk7SUFDSixrQkFBa0I7UUFFdEIsSUFBSSxPQUFPLEdBQVcsSUFBSSxDQUFDLGVBQWUsR0FBRyxDQUFDLENBQUM7UUFDL0MsSUFBSSxXQUFXLEdBQVcsQ0FBQyxHQUFHLE9BQU8sQ0FBQztRQUV0QyxJQUFJLElBQUksR0FBUSxJQUFJLENBQUMsU0FBUyxDQUFDLE1BQU0sQ0FBQyxVQUFVLENBQUM7YUFDNUMsSUFBSSxDQUFDLElBQUksRUFBRSxXQUFXLEdBQUcsSUFBSSxDQUFDLE1BQU0sQ0FBQyxFQUFFLENBQUMsQ0FBQztRQUM5QyxJQUFJLFFBQVEsR0FBUSxJQUFJLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQzthQUNsQyxJQUFJLENBQUMsTUFBTSxFQUFFLE9BQU8sQ0FBQzthQUNyQixJQUFJLENBQUMsR0FBRyxFQUFFLFdBQVcsQ0FBQzthQUN0QixJQUFJLENBQUMsR0FBRyxFQUFFLFdBQVcsQ0FBQzthQUN0QixJQUFJLENBQUMsTUFBTSxFQUFFLE1BQU0sQ0FBQzthQUNwQixJQUFJLENBQUMsT0FBTyxFQUFFLENBQUMsQ0FBQzthQUNoQixJQUFJLENBQUMsUUFBUSxFQUFFLElBQUksQ0FBQyxNQUFNLEdBQUcsSUFBSSxDQUFDLGVBQWUsQ0FBQyxDQUFDO1FBRXhELElBQUksQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDLFdBQVcsRUFBRSxnQkFBZ0IsR0FBRyxJQUFJLENBQUMsTUFBTSxDQUFDLEVBQUUsR0FBRyxHQUFHLENBQUMsQ0FBQztRQUUxRSxJQUFJLGNBQWMsR0FBYSxFQUFFLENBQUMsVUFBVSxFQUFFO2FBQ3pDLFFBQVEsQ0FBQyxJQUFJLENBQUMsa0JBQWtCLENBQUM7YUFDakMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxVQUFVLENBQUMsQ0FBQztRQUV6QixRQUFRLENBQUMsVUFBVSxDQUFDLGNBQWMsQ0FBQzthQUM5QixJQUFJLENBQUMsT0FBTyxFQUFFLElBQUksQ0FBQyxLQUFLLEdBQUcsSUFBSSxDQUFDLGVBQWUsQ0FBQyxDQUFDO0lBQzFELENBQUM7SUFFTyxrQkFBa0IsQ0FBQyxPQUFlLEVBQUUsS0FBa0I7UUFDMUQsSUFBSSxJQUFJLENBQUMsTUFBTSxDQUFDLEtBQUssS0FBSyxTQUFTLElBQUksSUFBSSxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsTUFBTSxLQUFLLFNBQVMsRUFBRTtZQUMzRSxJQUFJLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLE9BQU87Z0JBQUUsT0FBTztZQUM5QyxJQUFJLFVBQVUsR0FBVyxHQUFHLENBQUM7WUFDN0IsSUFBSSxjQUFjLEdBQVcsT0FBTyxHQUFHLElBQUksQ0FBQyxrQkFBa0IsR0FBRyxLQUFLLENBQUMsQ0FBQyxDQUFDLE1BQU0sR0FBRyxVQUFVLENBQUM7WUFDN0YsSUFBSSxjQUFjLEdBQVcsSUFBSSxDQUFDLE1BQU0sQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO1lBQ2pGLGNBQWMsR0FBRyxJQUFJLENBQUMsTUFBTSxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsY0FBYyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7WUFFNUQsRUFBRSxDQUFDLFNBQVMsQ0FBQyxHQUFHLEdBQUcsSUFBSSxDQUFDLE1BQU0sQ0FBQyxFQUFFLEdBQUcsdUNBQXVDLEdBQUcsT0FBTyxDQUFDO2lCQUNqRixVQUFVLEVBQUUsQ0FBRSw2QkFBNkI7aUJBQzNDLFFBQVEsQ0FBQyxjQUFjLENBQUMsQ0FBRSxzQkFBc0I7aUJBQ2hELEtBQUssQ0FBQyxjQUFjLENBQUM7aUJBQ3JCLEVBQUUsQ0FBQyxPQUFPLEVBQUUsVUFBUyxDQUFDLEVBQUUsQ0FBQztnQkFDdEIsRUFBRSxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsQ0FBRSxtQ0FBbUM7cUJBQy9DLEtBQUssQ0FBQyxZQUFZLEVBQUUsU0FBUyxDQUFDLENBQUM7Z0JBQ3BDLDhCQUE4QjtZQUNsQyxDQUFDLENBQUMsQ0FBQztTQUNWO0lBQ0wsQ0FBQztJQUVELHlCQUF5QjtJQUV6Qjs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O09Bd0JHO0lBQ0ssWUFBWSxDQUFDLEtBQXlCO1FBQzFDLHNCQUFzQjtRQUN0QixJQUFJLE9BQU8sR0FBNkIsRUFBRSxDQUFDO1FBQzNDLElBQUksY0FBYyxHQUFZLEVBQUUsQ0FBQztRQUVqQyxLQUFLLElBQUksQ0FBQyxHQUFXLENBQUMsRUFBRSxDQUFDLEdBQUcsSUFBSSxDQUFDLFdBQVcsQ0FBQyxNQUFNLEVBQUUsRUFBRSxDQUFDLEVBQUU7WUFFdEQsSUFBSSxXQUFXLEdBQXNCLEVBQUUsQ0FBQztZQUV4QyxJQUFJLENBQUMsR0FBVyxJQUFJLENBQUM7WUFDckIsSUFBSSxDQUFDLEdBQVcsQ0FBQyxDQUFDO1lBQ2xCLElBQUksRUFBRSxHQUFXLENBQUMsQ0FBQztZQUNuQixJQUFJLEtBQUssR0FBWSxJQUFJLENBQUM7WUFFMUIsS0FBSyxJQUFJLE1BQU0sR0FBVyxDQUFDLEVBQUUsTUFBTSxHQUFHLEtBQUssQ0FBQyxNQUFNLEVBQUUsRUFBRSxNQUFNLEVBQUU7Z0JBQzFELElBQUksTUFBTSxHQUFXLEtBQUssQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDO2dCQUUzQyxLQUFLLElBQUksTUFBTSxHQUFXLENBQUMsRUFBRSxNQUFNLEdBQUcsS0FBSyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLEVBQUUsRUFBRSxNQUFNLEVBQUU7b0JBQ3BFLElBQUksRUFBRSxHQUFXLEtBQUssQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsRUFBRSxDQUFDO29CQUM1QyxDQUFDLEdBQUcsTUFBTSxDQUFDO29CQUVYLEtBQUssR0FBRyxLQUFLLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLEtBQUssS0FBSyxJQUFJLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDO29CQUU5RCxJQUFJLElBQUksQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLEtBQUssT0FBTyxJQUFJLEVBQUUsS0FBSyxJQUFJLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQyxFQUFFO3dCQUU3RCxJQUFJLFNBQVMsR0FBVyxJQUFJLENBQUMsbUJBQW1CLENBQUMsS0FBSyxFQUFFLE1BQU0sRUFBRSxNQUFNLENBQUMsQ0FBQzt3QkFDeEUsSUFBSSxXQUFXLEdBQUcsQ0FBQyxPQUFPLGNBQWMsQ0FBQyxNQUFNLENBQUMsS0FBSyxXQUFXLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxjQUFjLENBQUMsTUFBTSxDQUFDLENBQUM7d0JBQy9GLGNBQWMsQ0FBQyxNQUFNLENBQUMsR0FBRyxXQUFXLEdBQUcsU0FBUyxDQUFDO3dCQUVqRCxJQUFJLE1BQU0sR0FBVyxjQUFjLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxDQUFDO3dCQUNqRCxJQUFJLFlBQVksR0FBVyxLQUFLLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLEtBQUssQ0FBQzt3QkFFekQsQ0FBQyxHQUFHLEtBQUssQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsR0FBRyxHQUFHLE1BQU0sQ0FBQzt3QkFDekMsRUFBRSxHQUFHLENBQUMsR0FBRyxZQUFZLENBQUM7d0JBRXRCLFdBQVcsQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRSxLQUFLLEVBQUUsQ0FBQyxFQUFFLEtBQUssRUFBRSxDQUFDLEVBQUUsRUFBRSxDQUFDLEVBQUUsQ0FBQyxFQUFFLEVBQUUsRUFBRSxFQUFFLEVBQUUsRUFBRSxFQUFFLEVBQUUsRUFBRSxLQUFLLEVBQUUsS0FBSyxFQUFFLENBQUMsQ0FBQzt3QkFFcEYsSUFBSSxhQUFhLEdBQWUsSUFBSSxDQUFDLGlCQUFpQixDQUFDLEtBQUssRUFBRSxNQUFNLEVBQUUsTUFBTSxFQUFFLGNBQWMsQ0FBQyxDQUFDO3dCQUU5RixJQUFJLGFBQWEsQ0FBQyxLQUFLLEtBQUssSUFBSSxFQUFFOzRCQUM5QixXQUFXLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxFQUFFLGFBQWEsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLGFBQWEsQ0FBQyxDQUFDLEVBQUUsRUFBRSxFQUFFLGFBQWEsQ0FBQyxFQUFFLEVBQUUsRUFBRSxFQUFFLEVBQUUsRUFBRSxLQUFLLEVBQUUsS0FBSyxFQUFFLENBQUMsQ0FBQzs0QkFDekcsV0FBVyxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsRUFBRSxhQUFhLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxhQUFhLENBQUMsQ0FBQyxFQUFFLEVBQUUsRUFBRSxhQUFhLENBQUMsRUFBRSxFQUFFLEVBQUUsRUFBRSxFQUFFLEVBQUUsS0FBSyxFQUFFLElBQUksRUFBRSxDQUFDLENBQUM7eUJBQzNHO3dCQUVELE1BQU07cUJBQ1Q7aUJBQ0o7YUFDSjtZQUNELE9BQU8sQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFDLENBQUM7U0FDN0I7UUFDRCx3QkFBd0I7UUFDeEIsT0FBTyxPQUFPLENBQUM7SUFDbkIsQ0FBQztJQUVEOzs7Ozs7O09BT0c7SUFDSyxtQkFBbUIsQ0FBQyxLQUF5QixFQUFFLE9BQWUsRUFBRSxPQUFlO1FBQ25GLElBQUksVUFBVSxHQUFXLEtBQUssQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsS0FBSyxDQUFDO1FBRXpELElBQUksY0FBYyxHQUFZLEtBQUssQ0FBQztRQUVwQyxJQUFJLFlBQVksR0FBVyxJQUFJLENBQUMsU0FBUyxDQUFDLFlBQVksQ0FBQyxLQUFLLEVBQUUsT0FBTyxFQUFFLE9BQU8sQ0FBQyxDQUFDO1FBQ2hGLElBQUksVUFBVSxHQUFZLFlBQVksQ0FBQyxZQUFZLENBQUMsQ0FBQztRQUNyRCxJQUFJLFdBQVcsR0FBWSxZQUFZLENBQUMsWUFBWSxDQUFDLElBQUksQ0FBQyxPQUFPLEdBQUcsQ0FBQyxJQUFJLFVBQVUsQ0FBQyxDQUFDO1FBQ3JGLElBQUksT0FBTyxHQUFHLENBQUMsRUFBRTtZQUNiLElBQUksV0FBVyxHQUFXLElBQUksQ0FBQyxTQUFTLENBQUMsWUFBWSxDQUFDLEtBQUssRUFBRSxDQUFDLE9BQU8sR0FBRyxDQUFDLENBQUMsRUFBRSxPQUFPLENBQUMsQ0FBQztZQUNyRixjQUFjLEdBQUcsV0FBVyxDQUFDLGdCQUFnQixDQUFDLENBQUM7U0FDbEQ7UUFFRCxJQUFJLFVBQVUsS0FBSyxJQUFJLElBQUksV0FBVyxJQUFJLFVBQVUsSUFBSSxjQUFjLEVBQUU7WUFDcEUsT0FBTyxVQUFVLENBQUM7U0FDckI7UUFDRCxPQUFPLENBQUMsQ0FBQztJQUNiLENBQUM7SUFFRDs7Ozs7Ozs7Ozs7O09BWUc7SUFDSyxpQkFBaUIsQ0FBQyxLQUF5QixFQUFFLE9BQWUsRUFBRSxPQUFlLEVBQUUsT0FBZ0I7UUFFbkcsSUFBSSxZQUFZLEdBQVcsS0FBSyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxLQUFLLENBQUM7UUFFM0QsSUFBSSxLQUFLLEdBQVksS0FBSyxDQUFDO1FBQzNCLElBQUksQ0FBQyxHQUFXLEtBQUssQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsR0FBRyxHQUFHLENBQUMsT0FBTyxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDO1FBQ3hFLElBQUksQ0FBQyxHQUFXLEtBQUssQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDO1FBQ3ZDLElBQUksRUFBRSxHQUFXLENBQUMsR0FBRyxZQUFZLENBQUM7UUFFbEMsSUFBSSxZQUFZLEtBQUssSUFBSSxFQUFFO1lBQ3ZCLE9BQU8sRUFBRSxDQUFDLEVBQUUsRUFBRSxLQUFLLEVBQUUsQ0FBQyxFQUFFLEtBQUssRUFBRSxDQUFDLEVBQUUsRUFBRSxDQUFDLEVBQUUsQ0FBQyxFQUFFLEVBQUUsRUFBRSxFQUFFLEVBQUUsS0FBSyxFQUFFLEtBQUssRUFBRSxDQUFDO1NBQ3BFO1FBRUQsSUFBSSxjQUFjLEdBQUcsT0FBTyxHQUFHLENBQUMsSUFBSSxPQUFPLEdBQUcsS0FBSyxDQUFDLE1BQU0sR0FBRyxDQUFDO1lBQzFELEtBQUssQ0FBQyxPQUFPLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLEtBQUssS0FBSyxJQUFJO1lBQzVDLFlBQVksS0FBSyxJQUFJLElBQUksS0FBSyxDQUFDLE9BQU8sR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsS0FBSyxLQUFLLElBQUksQ0FBQztRQUUxRSxJQUFJLGFBQWEsR0FBRyxPQUFPLEdBQUcsQ0FBQyxJQUFJLE9BQU8sR0FBRyxLQUFLLENBQUMsTUFBTSxHQUFHLENBQUM7WUFDekQsS0FBSyxDQUFDLE9BQU8sR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsS0FBSyxLQUFLLElBQUk7WUFDNUMsWUFBWSxLQUFLLElBQUksSUFBSSxLQUFLLENBQUMsT0FBTyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxLQUFLLEtBQUssSUFBSSxDQUFDO1FBRTFFLElBQUksYUFBYSxFQUFFO1lBQ2YsT0FBTyxDQUFDLFFBQVEsR0FBRyxPQUFPLENBQUMsR0FBRyxDQUFDLE9BQU8sQ0FBQyxRQUFRLEdBQUcsT0FBTyxDQUFDLElBQUksQ0FBQyxDQUFDLEdBQUcsWUFBWSxDQUFDO1NBQ25GO1FBRUQsSUFBSSxjQUFjLEVBQUU7WUFDaEIsT0FBTyxDQUFDLFFBQVEsR0FBRyxPQUFPLENBQUMsR0FBRyxDQUFDLE9BQU8sQ0FBQyxRQUFRLEdBQUcsT0FBTyxDQUFDLElBQUksQ0FBQyxDQUFDLEdBQUcsWUFBWSxDQUFDO1NBQ25GO1FBRUQsSUFBSSxZQUFZLEtBQUssSUFBSSxJQUFJLE9BQU8sQ0FBQyxRQUFRLEdBQUcsT0FBTyxDQUFDLEVBQUU7WUFDdEQsQ0FBQyxHQUFHLENBQUMsR0FBRyxPQUFPLENBQUMsUUFBUSxHQUFHLE9BQU8sQ0FBQyxDQUFDO1lBQ3BDLEVBQUUsR0FBRyxFQUFFLEdBQUcsQ0FBQyxDQUFDO1lBQ1osS0FBSyxHQUFHLElBQUksQ0FBQztTQUNoQjtRQUVELE9BQU8sRUFBRSxDQUFDLEVBQUUsRUFBRSxLQUFLLEVBQUUsQ0FBQyxFQUFFLEtBQUssRUFBRSxDQUFDLEVBQUUsRUFBRSxDQUFDLEVBQUUsQ0FBQyxFQUFFLEVBQUUsRUFBRSxFQUFFLEVBQUUsS0FBSyxFQUFFLEtBQUssRUFBRSxDQUFDO0lBQ3JFLENBQUM7OztZQTdxQkosU0FBUyxTQUFDO2dCQUNQLFFBQVEsRUFBRSxlQUFlO2dCQUN6QixRQUFRLEVBQUU7Ozs7S0FJVDtnQkFDRCxhQUFhLEVBQUUsaUJBQWlCLENBQUMsSUFBSTtnQkFDckMsU0FBUyxFQUFFLENBQUMsV0FBVyxFQUFFLFlBQVksQ0FBQzthQUN6Qzs7O1lBdERRLFdBQVc7WUFTWCxZQUFZOzs7bUJBc0ZoQixLQUFLO3FCQUNMLEtBQUs7eUJBQ0wsS0FBSyxTQUFDLFFBQVE7a0JBQ2QsS0FBSyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7XHJcbiAgICBDb21wb25lbnQsXHJcbiAgICBWaWV3RW5jYXBzdWxhdGlvbixcclxuICAgIE9uSW5pdCxcclxuICAgIE9uQ2hhbmdlcyxcclxuICAgIFNpbXBsZUNoYW5nZXMsXHJcbiAgICBPbkRlc3Ryb3ksXHJcbiAgICBJbnB1dFxyXG59IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xyXG5pbXBvcnQgKiBhcyBkMyBmcm9tICdkMyc7XHJcbmltcG9ydCB7IEtkQ2hhcnRCYXNlQ2xhc3MgfSBmcm9tICcuLi9rZC1hbmd1bGFyLWNoYXJ0LWJhc2UtY2xhc3MnO1xyXG5pbXBvcnQgeyBLZENoYXJ0c1N2YyB9IGZyb20gJy4uL2tkLWFuZ3VsYXItY2hhcnRzLXN2Yyc7XHJcbmltcG9ydCB7XHJcbiAgICBJQ2hhcnRDb25maWcsXHJcbiAgICBJRDNEYXRhLFxyXG4gICAgSUQzRGF0YURhdGEsXHJcbiAgICBJRDNZRGF0YSxcclxuICAgIElMZWdlbmREYXRhLFxyXG4gICAgSUNoYXJ0SW50ZXJuYWxBcGlcclxufSBmcm9tICcuLi9rZC1hbmd1bGFyLWNoYXJ0cy1pbnRlcmZhY2UnO1xyXG5pbXBvcnQgeyBLZERvbUVsZW1TdmMgfSBmcm9tICcuLi8uLi9rZC1jb21tb24vaW5kZXgnO1xyXG5cclxuaW50ZXJmYWNlIElEYXRhVmFsdWUge1xyXG4gICAgeDoge1xyXG4gICAgICAgIHZhbHVlOiBzdHJpbmcgfCBudW1iZXI7XHJcbiAgICAgICAgbGFiZWw6IHN0cmluZyB8IG51bWJlcjtcclxuICAgIH07XHJcbiAgICB5OiBudW1iZXI7XHJcbiAgICB2YWxpZD86IGJvb2xlYW47XHJcbiAgICB5MD86IG51bWJlcjtcclxuICAgIGFkanVzdD86IG9iamVjdDtcclxuICAgIGlkPzogc3RyaW5nO1xyXG59XHJcblxyXG5pbnRlcmZhY2UgSUFkanVzdCB7XHJcbiAgICBba2V5OiBudW1iZXJdOiBudW1iZXI7XHJcbn1cclxuXHJcbmludGVyZmFjZSBJRG90RGF0YSB7XHJcbiAgICBjb2xvdXI/OiBzdHJpbmc7XHJcbiAgICBzaGFwZT86IHN0cmluZztcclxuICAgIHg/OiBudW1iZXI7XHJcbiAgICB5PzogbnVtYmVyO1xyXG4gICAgYm9yZGVyQ29sb3I/OiBzdHJpbmc7XHJcbiAgICBib3JkZXJXaWR0aD86IG51bWJlcjtcclxufVxyXG5cclxuaW50ZXJmYWNlIElEb3Qge1xyXG4gICAgW2tleTogc3RyaW5nXTogSURvdERhdGE7XHJcbn1cclxuXHJcbmludGVyZmFjZSBJUG9zaXRpb24ge1xyXG4gICAgeDogbnVtYmVyO1xyXG4gICAgeTogbnVtYmVyO1xyXG59XHJcblxyXG5AQ29tcG9uZW50KHtcclxuICAgIHNlbGVjdG9yOiAna2QtbGluZS1jaGFydCcsXHJcbiAgICB0ZW1wbGF0ZTogYFxyXG4gICAgICAgIDxkaXYgKm5nSWY9XCJjaGFydFR5cGVbMV0gPT09ICcxMDAnICYmIGhhdmVOZWdhdGl2ZVwiIGNsYXNzPVwia2R4LWNoYXJ0cy1lcnJvci1tc2dcIj5cclxuICAgICAgICAgICAge3tlcnJvck1zZ319XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICBgLFxyXG4gICAgZW5jYXBzdWxhdGlvbjogVmlld0VuY2Fwc3VsYXRpb24uTm9uZSxcclxuICAgIHByb3ZpZGVyczogW0tkQ2hhcnRzU3ZjLCBLZERvbUVsZW1TdmNdXHJcbn0pXHJcblxyXG5leHBvcnQgY2xhc3MgS2RMaW5lQ2hhcnQgZXh0ZW5kcyBLZENoYXJ0QmFzZUNsYXNzIGltcGxlbWVudHMgT25Jbml0LCBPbkNoYW5nZXMsIE9uRGVzdHJveSB7XHJcblxyXG4gICAgcHJpdmF0ZSBsaW5lQ2hhcnQ6IGFueTtcclxuXHJcbiAgICBwcml2YXRlIF9zZXJpZXNMaXN0OiBBcnJheTxzdHJpbmc+ID0gW107XHJcblxyXG4gICAgcHJpdmF0ZSBfcmVzaXplVGltZW91dDogbnVtYmVyO1xyXG5cclxuICAgIC8vIERvdCBTZXR0aW5nXHJcbiAgICBwcml2YXRlIF9ob3ZlckJhY2tncm91bmQ6IHN0cmluZyA9ICdNIDEwLCAxMCBtIC0xMCwgMCBhIDEwLDEwIDAgMSwwIDIwLDAgYSAxMCwxMCAwIDEsMCAtMjAsMCc7XHJcblxyXG4gICAgcHJpdmF0ZSBfc2hhcGVzOiBvYmplY3QgPSB7XHJcbiAgICAgICAgJ00gNCAwIEwgNCAwIEwgMCA4IEwgOCA4IHonOiAnTSA2IDAgTCA2IDAgTCAwIDEyIEwgMTIgMTIgeicsXHJcbiAgICAgICAgJ00gMCAwIEwgOCAwIEwgNCA4IEwgNCA4IHonOiAnTSAwIDAgTCAxMiAwIEwgNiAxMiBMIDYgMTIgeicsXHJcbiAgICAgICAgJ00gNCAwIEwgOCA0IEwgNCA4IEwgMCA0IHonOiAnTSA2IDAgTCAxMiA2IEwgNiAxMiBMIDAgNiB6JyxcclxuICAgICAgICAnTSA0IDAgQSA0IDQgMCAxIDAgNCA4IEEgNCA0IDAgMSAwIDQgMCBaJzogJ00gNiAwIEEgNiA2IDAgMSAwIDYgMTIgQSA2IDYgMCAxIDAgNiAwIFonLFxyXG4gICAgICAgICdNIDAgMCBMIDggMCBMIDggOCBMIDAgOCB6JzogJ00gMCAwIEwgMTIgMCBMIDEyIDEyIEwgMCAxMiB6J1xyXG4gICAgfTtcclxuXHJcbiAgICBwcml2YXRlIF9kb3REYXRhOiBJRG90ID0ge307XHJcblxyXG4gICAgcHJpdmF0ZSBfYmlnZ2VzdERvdFNpemU6IG51bWJlciA9IDEyO1xyXG5cclxuICAgIHByaXZhdGUgX2RlZmF1bHREb3RQb3M6IElQb3NpdGlvbiA9IHt4OiAtOTk5LCB5OiAtOTk5fTtcclxuXHJcbiAgICBwcml2YXRlIF9saW5lU3R5bGU6IG9iamVjdCA9IHtcclxuICAgICAgICBzb2xpZDogJ25vbmUnLFxyXG4gICAgICAgIHNob3J0RGFzaDogJzYsMicsXHJcbiAgICAgICAgc2hvcnREb3Q6ICcyLDInLFxyXG4gICAgICAgIHNob3J0RGFzaERvdDogJzYsMiwyLDInLFxyXG4gICAgICAgIHNob3J0RGFzaERvdERvdDogJzYsMiwyLDIsMiwyJyxcclxuICAgICAgICBkb3Q6ICcyLDYnLFxyXG4gICAgICAgIGRhc2g6ICc4LDYnLFxyXG4gICAgICAgIGxvbmdEYXNoOiAnMTYsNicsXHJcbiAgICAgICAgZGFzaERvdDogJzgsNiwyLDYnLFxyXG4gICAgICAgIGxvbmdEYXNoRG90OiAnMTYsNiwyLDYnLFxyXG4gICAgICAgIGxvbmdEYXNoRG90RG90OiAnMTYsNiwyLDYsMiw2J1xyXG4gICAgfTtcclxuXHJcbiAgICBASW5wdXQoKSBkYXRhOiBBcnJheTxJRDNEYXRhRGF0YT47XHJcbiAgICBASW5wdXQoKSBjb25maWc6IElDaGFydENvbmZpZztcclxuICAgIEBJbnB1dCgnbGVnZW5kJykgbGVnZW5kRGF0YTogeyBba2V5OiBzdHJpbmddOiBJTGVnZW5kRGF0YSB9O1xyXG4gICAgQElucHV0KCkgYXBpOiBJQ2hhcnRJbnRlcm5hbEFwaTtcclxuXHJcbiAgICBjb25zdHJ1Y3RvcihwdWJsaWMgX2NoYXJ0U3ZjOiBLZENoYXJ0c1N2YywgcHVibGljIF9kb21TdmM6IEtkRG9tRWxlbVN2Yykge1xyXG4gICAgICAgIHN1cGVyKF9jaGFydFN2YywgX2RvbVN2Yyk7XHJcbiAgICB9XHJcblxyXG4gICAgbmdPbkluaXQoKTogdm9pZCB7XHJcblxyXG4gICAgICAgIHRoaXMuYXBpLmxlZ2VuZENsaWNrID0gKF9kYXRhOiBJRDNEYXRhKSA9PiB7XHJcbiAgICAgICAgICAgIHRoaXMuX3JlZHJhd0NoYXJ0KGZhbHNlLCBfZGF0YSk7XHJcbiAgICAgICAgfTtcclxuICAgICAgICB0aGlzLmFwaS5yZWRyYXcgPSAoKSA9PiB7XHJcbiAgICAgICAgICAgIGNsZWFyVGltZW91dCh0aGlzLl9yZXNpemVUaW1lb3V0KTtcclxuICAgICAgICAgICAgdGhpcy5fcmVzaXplVGltZW91dCA9IHNldFRpbWVvdXQoKCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5fcmVkcmF3Q2hhcnQoZmFsc2UpO1xyXG4gICAgICAgICAgICB9KTtcclxuICAgICAgICB9O1xyXG4gICAgfVxyXG5cclxuICAgIG5nT25DaGFuZ2VzKF9jaGFuZ2VzOiBTaW1wbGVDaGFuZ2VzKTogdm9pZCB7XHJcbiAgICAgICAgaWYgKF9jaGFuZ2VzLmhhc093blByb3BlcnR5KCdkYXRhJykpIHtcclxuICAgICAgICAgICAgdGhpcy5fcmVkcmF3Q2hhcnQoX2NoYW5nZXMuZGF0YS5pc0ZpcnN0Q2hhbmdlKCksIF9jaGFuZ2VzLmRhdGEuY3VycmVudFZhbHVlKTtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIGlmIChfY2hhbmdlcy5oYXNPd25Qcm9wZXJ0eSgnY29uZmlnJykgJiYgIV9jaGFuZ2VzLmNvbmZpZy5pc0ZpcnN0Q2hhbmdlKCkpIHtcclxuICAgICAgICAgICAgdGhpcy5fcmVkcmF3Q2hhcnQoX2NoYW5nZXMuY29uZmlnLmlzRmlyc3RDaGFuZ2UoKSk7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIG5nT25EZXN0cm95KCk6IHZvaWQgeyB0aGlzLnJlbW92ZUxpbmVDaGFydCgpOyB9XHJcblxyXG4gICAgcHJpdmF0ZSBfcmVkcmF3Q2hhcnQoX2lzRmlyc3RDaGFuZ2U6IGJvb2xlYW4sIF9kYXRhPzogSUQzRGF0YSkge1xyXG4gICAgICAgIGlmICghX2lzRmlyc3RDaGFuZ2UpIHtcclxuICAgICAgICAgICAgdGhpcy5saW5lQ2hhcnQgPSBkMy5zZWxlY3QoJyNsaW5lLScgKyB0aGlzLmNvbmZpZy5pZCk7XHJcbiAgICAgICAgICAgIHRoaXMucmVtb3ZlTGluZUNoYXJ0KCk7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGlmIChfZGF0YSkgdGhpcy5fc2V0RGF0YShfZGF0YSk7XHJcbiAgICAgICAgc3VwZXIuY2hhcnRUaW1lb3V0KCgpID0+IHRoaXMuX3NldENoYXJ0KCkpO1xyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX3NldERhdGEoX2RhdGE6IElEM0RhdGEpOiB2b2lkIHtcclxuICAgICAgICB0aGlzLmNoYXJ0VHlwZSA9IF9kYXRhLmxheW91dC5zcGxpdCgnLScpO1xyXG4gICAgICAgIHRoaXMuY2hhcnRDYXRlZ29yeSA9ICdsaW5lJztcclxuICAgICAgICB0aGlzLmRhdGFSYW5nZSA9IF9kYXRhLnJhbmdlO1xyXG4gICAgICAgIHRoaXMuaGF2ZU5lZ2F0aXZlID0gX2RhdGEuaGF2ZU5lZ2F0aXZlO1xyXG5cclxuICAgICAgICB0aGlzLmRhdGEgPSBPYmplY3QuYXNzaWduKFtdLCBfZGF0YS5kYXRhKTtcclxuICAgICAgICB0aGlzLmluaXREYXRhID0gSlNPTi5wYXJzZShKU09OLnN0cmluZ2lmeSh0aGlzLmRhdGEpKTtcclxuXHJcbiAgICAgICAgdGhpcy5fc2VyaWVzTGlzdCA9IE9iamVjdC5rZXlzKHRoaXMubGVnZW5kRGF0YSkuZmlsdGVyKGtleSA9PiAhdGhpcy5sZWdlbmREYXRhW2tleV0uZGVhY3RpdmUpO1xyXG5cclxuICAgICAgICBpZiAodGhpcy5jaGFydFR5cGVbMV0gPT09ICdzdGFjaycgfHwgdGhpcy5jaGFydFR5cGVbMV0gPT09ICcxMDAnKSB7XHJcbiAgICAgICAgICAgIHRoaXMuX3Nlcmllc0xpc3QgPSB0aGlzLl9zZXJpZXNMaXN0LnJldmVyc2UoKTtcclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSByZW1vdmVMaW5lQ2hhcnQoKTogdm9pZCB7XHJcbiAgICAgICAgc3VwZXIucmVtb3ZlQ2hhcnQoKTtcclxuICAgICAgICBpZiAodGhpcy5saW5lQ2hhcnQpIHtcclxuICAgICAgICAgICAgdGhpcy5saW5lQ2hhcnQucmVtb3ZlKCk7XHJcbiAgICAgICAgICAgIHRoaXMubGluZUNoYXJ0ID0gbnVsbDtcclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfc2V0Q2hhcnQoKTogdm9pZCB7XHJcbiAgICAgICAgaWYgKHRoaXMuY2hhcnRUeXBlWzFdID09PSAnMTAwJyAmJiB0aGlzLmhhdmVOZWdhdGl2ZSkgcmV0dXJuO1xyXG4gICAgICAgIHN1cGVyLnNldFN2ZygpO1xyXG5cclxuICAgICAgICB0aGlzLl9zZXRBeGlzRG9tYWluKCk7XHJcblxyXG4gICAgICAgIHRoaXMuX2NyZWF0ZUhvdmVyRG90KCk7XHJcblxyXG4gICAgICAgIHRoaXMuX2NyZWF0ZUNoYXJ0KCk7XHJcblxyXG4gICAgICAgIHRoaXMuX2RyYXdDaGFydCh0aGlzLmRhdGEpO1xyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX3NldEF4aXNEb21haW4oKTogdm9pZCB7XHJcblxyXG4gICAgICAgIGlmICh0aGlzLmNoYXJ0VHlwZVt0aGlzLmNoYXJ0VHlwZS5sZW5ndGggLSAxXSA9PT0gJ3R5cGUxJykge1xyXG4gICAgICAgICAgICBzdXBlci5zZXREb21haW4oJ2JhbmQnKTtcclxuICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICBzdXBlci5zZXREb21haW4oJ3N0cmluZycpO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF9jcmVhdGVDaGFydCgpOiB2b2lkIHtcclxuICAgICAgICBpZiAoIXRoaXMubGluZUNoYXJ0KSB7XHJcbiAgICAgICAgICAgIHRoaXMubGluZUNoYXJ0ID0gdGhpcy5ncmFwaC5hcHBlbmQoJ2cnKVxyXG4gICAgICAgICAgICAgICAgLmF0dHIoJ2NsYXNzJywgJ2tkeC1jaGFydHMtbGluZS1jaGFydCcpXHJcbiAgICAgICAgICAgICAgICAuYXR0cignaWQnLCAnbGluZS0nICsgdGhpcy5jb25maWcuaWQpO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgaWYgKHRoaXMuY29uZmlnLmFuaW1hdGlvbikgdGhpcy5fc2V0Q2hhcnRBbmltYXRpb24oKTtcclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF9jcmVhdGVTZXJpZXNDb250YWluZXIoKTogeyBsaW5lQ29udGFpbmVyOiBhbnksIGRvdENvbnRhaW5lcjogYW55IH0ge1xyXG4gICAgICAgIGxldCBsaW5lU3ZnOiBhbnkgPSB0aGlzLmxpbmVDaGFydC5zZWxlY3RBbGwoJy5rZHgtY2hhcnQtd3JhcHBlcicpXHJcbiAgICAgICAgICAgIC5kYXRhKHRoaXMuX3Nlcmllc0xpc3QsIGZ1bmN0aW9uKGQpIHsgcmV0dXJuIGQ7IH0pO1xyXG4gICAgICAgIC8vIGtleSBmdW5jdGlvbiBmb3Igb2JqZWN0IGNvbnNpc3RlbmN5IHNvIGQzIGRvZXMgbm90IHJlbW92ZSBiYXNlIG9uIGluZGV4XHJcblxyXG4gICAgICAgIGxpbmVTdmcuZXhpdCgpLnJlbW92ZSgpO1xyXG5cclxuICAgICAgICBsZXQgc2VyaWVzQ29udGFpbmVyOiBhbnk7XHJcblxyXG4gICAgICAgIGlmICh0aGlzLmNoYXJ0VHlwZVsxXSAhPT0gJ3N0YWNrJyAmJiB0aGlzLmNoYXJ0VHlwZVsxXSAhPT0gJzEwMCcpIHtcclxuICAgICAgICAgICAgc2VyaWVzQ29udGFpbmVyID0gbGluZVN2Zy5lbnRlcigpXHJcbiAgICAgICAgICAgICAgICAuYXBwZW5kKCdnJylcclxuICAgICAgICAgICAgICAgIC5hdHRyKCdjbGFzcycsIChkLCBpKSA9PiAna2R4LWNoYXJ0cy1zZXJpZXMtY29udGFpbmVyJyArICcgeS0nICsgdGhpcy5fc2VyaWVzTGlzdFtpXSk7XHJcbiAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgc2VyaWVzQ29udGFpbmVyID0gbGluZVN2Zy5lbnRlcigpO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgbGV0IGxpbmVDb250YWluZXI6IGFueSA9IHNlcmllc0NvbnRhaW5lci5hcHBlbmQoJ2cnKVxyXG4gICAgICAgICAgICAuYXR0cignY2xhc3MnLCAoZCwgaSkgPT4gJ2tkeC1jaGFydHMtbGluZS1jb250YWluZXInICsgJyB5LScgKyB0aGlzLl9zZXJpZXNMaXN0W2ldKVxyXG4gICAgICAgICAgICAuYXR0cignY2xpcC1wYXRoJywgJ3VybCgja2QtY2hhcnRzLWNsaXAtcGF0aC0nICsgdGhpcy5jb25maWcuaWQgKyAnKScpO1xyXG5cclxuICAgICAgICBsZXQgZG90Q29udGFpbmVyOiBhbnkgPSBzZXJpZXNDb250YWluZXIuYXBwZW5kKCdnJylcclxuICAgICAgICAgICAgLmF0dHIoJ2NsYXNzJywgKGQsIGkpID0+ICdrZHgtY2hhcnRzLWRvdC1jb250YWluZXInICsgJyB5LScgKyB0aGlzLl9zZXJpZXNMaXN0W2ldKVxyXG4gICAgICAgICAgICAuYXR0cignaWQnLCAoZCwgaSkgPT4gJ2tkeC1jaGFydHMtZG90LWNvbnRhaW5lcicgKyAnX3ktJyArIHRoaXMuX3Nlcmllc0xpc3RbaV0ucmVwbGFjZSgvXFxzL2csICcnKSk7XHJcblxyXG4gICAgICAgIHJldHVybiB7IGxpbmVDb250YWluZXI6IGxpbmVDb250YWluZXIsIGRvdENvbnRhaW5lcjogZG90Q29udGFpbmVyIH07XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfY3JlYXRlSG92ZXJEb3QoKTogdm9pZCB7XHJcbiAgICAgICAgZDMuc2VsZWN0KCcjJyArIHRoaXMuY29uZmlnLmlkICsgJy5rZHgtY2hhcnRzIC5rZHgtY2hhcnRzLWhvdmVyLWRvdCcpLnJlbW92ZSgpO1xyXG5cclxuICAgICAgICB0aGlzLmdyYXBoXHJcbiAgICAgICAgICAgIC5hcHBlbmQoJ3BhdGgnKVxyXG4gICAgICAgICAgICAuYXR0cignY2xhc3MnLCAna2R4LWNoYXJ0cy1ob3Zlci1kb3QnKVxyXG4gICAgICAgICAgICAuYXR0cignZCcsIHRoaXMuX2hvdmVyQmFja2dyb3VuZClcclxuICAgICAgICAgICAgLmF0dHIoJ3RyYW5zZm9ybScsIHN1cGVyLnRyYW5zZm9ybVBvc2l0aW9uKHRoaXMuX2RlZmF1bHREb3RQb3MueCwgdGhpcy5fZGVmYXVsdERvdFBvcy55LCB0cnVlKSk7XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfZHJhd0NoYXJ0KF9kYXRhOiBBcnJheTxJRDNEYXRhRGF0YT4pOiB2b2lkIHtcclxuICAgICAgICAvLyBzdXBlci5yZW1vdmVDaGFydCgpO1xyXG4gICAgICAgIC8vIHRoaXMuX3NldEF4aXNEb21haW4oKTtcclxuXHJcbiAgICAgICAgbGV0IHNlcmllc0NvbnRhaW5lcjogYW55ID0gdGhpcy5fY3JlYXRlU2VyaWVzQ29udGFpbmVyKCk7XHJcblxyXG4gICAgICAgIHRoaXMuX2RyYXdQYXRoKF9kYXRhLCBzZXJpZXNDb250YWluZXIubGluZUNvbnRhaW5lcik7XHJcblxyXG4gICAgICAgIHRoaXMuX2FkZERvdChfZGF0YSwgc2VyaWVzQ29udGFpbmVyLmRvdENvbnRhaW5lcik7XHJcblxyXG4gICAgICAgIGZvciAobGV0IHhJbmRleDogbnVtYmVyID0gMDsgeEluZGV4IDwgX2RhdGEubGVuZ3RoOyB4SW5kZXgrKykge1xyXG4gICAgICAgICAgICB0aGlzLl9zZXRMYWJlbEFuaW1hdGlvbih4SW5kZXgsIF9kYXRhW3hJbmRleF0pO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICAvLyBMaW5lICYgQXJlYVxyXG4gICAgcHJpdmF0ZSBfZHJhd1BhdGgoX2NoYXJ0RGF0YTogQXJyYXk8SUQzRGF0YURhdGE+LCBfbGluZVN2ZzogYW55KTogdm9pZCB7XHJcblxyXG4gICAgICAgIGxldCBkYXRhOiBBcnJheTxJRDNEYXRhRGF0YT4gfCBBcnJheTxBcnJheTxJRGF0YVZhbHVlPj4gPSBfY2hhcnREYXRhO1xyXG5cclxuICAgICAgICBpZiAodGhpcy5jaGFydFR5cGVbMV0gPT09ICdzdGFjaycpIGRhdGEgPSB0aGlzLl9kYXRhTWFzc2FnZShfY2hhcnREYXRhKTtcclxuXHJcbiAgICAgICAgaWYgKHRoaXMuY2hhcnRUeXBlWzBdICE9PSAnZG90Jykge1xyXG5cclxuICAgICAgICAgICAgaWYgKHRoaXMuY2hhcnRUeXBlWzBdID09PSAnYXJlYScpIHtcclxuICAgICAgICAgICAgICAgIF9saW5lU3ZnLmFwcGVuZCgncGF0aCcpXHJcbiAgICAgICAgICAgICAgICAgICAgLmF0dHIoJ2QnLCAoZCwgaSkgPT4gdGhpcy5fc2V0UGF0aFZhbHVlKGksIGRhdGEpKVxyXG4gICAgICAgICAgICAgICAgICAgIC5hdHRyKCdjbGFzcycsIChkLCBpKSA9PiAna2R4LWNoYXJ0cy1saW5lLWFyZWEgeS0nICsgZClcclxuICAgICAgICAgICAgICAgICAgICAuYXR0cignZmlsbCcsIChkLCBpKSA9PiB0aGlzLmxlZ2VuZERhdGFbZF0uY29sb3IpXHJcbiAgICAgICAgICAgICAgICAgICAgLmF0dHIoJ2ZpbGwtb3BhY2l0eScsIDAuNzUpO1xyXG4gICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICBfbGluZVN2Zy5hcHBlbmQoJ3BhdGgnKVxyXG4gICAgICAgICAgICAgICAgLmF0dHIoJ2QnLCAoZCwgaSkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgIGlmICh0aGlzLmNoYXJ0VHlwZVswXSA9PT0gJ2FyZWEnKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiB0aGlzLl9zZXRQYXRoVmFsdWUoaSwgZGF0YSwgdHJ1ZSk7XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIHJldHVybiB0aGlzLl9zZXRQYXRoVmFsdWUoaSwgZGF0YSk7XHJcbiAgICAgICAgICAgICAgICB9KVxyXG4gICAgICAgICAgICAgICAgLmF0dHIoJ2NsYXNzJywgKGQsIGkpID0+ICdrZHgtY2hhcnRzLWxpbmUtcGF0aCB5LScgKyBkKVxyXG4gICAgICAgICAgICAgICAgLmF0dHIoJ3N0cm9rZScsIChkLCBpKSA9PiB0aGlzLmxlZ2VuZERhdGFbZF0uY29sb3IpXHJcbiAgICAgICAgICAgICAgICAuYXR0cignc3Ryb2tlLWRhc2hhcnJheScsIChkLCBpKSA9PiB0aGlzLl9saW5lU3R5bGVbdGhpcy5sZWdlbmREYXRhW2RdLmxpbmVTdHlsZV0pXHJcbiAgICAgICAgICAgICAgICAuc3R5bGUoJ2ZpbGwnLCAnbm9uZScpO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICAvKipcclxuICAgICAqIFtyZXR1cm4gcGF0aCBkYXRhIHZhbHVlLiBkZXBlbmRzIG9uIGNoYXJ0IHR5cGUsIHRoaXMgZnVuY3Rpb24gd2lsbCByZXR1cm4gbGluZSBvciBhcmVhIHBhdGggZGF0YVxyXG4gICAgICpcclxuICAgICAqIGZvciBfY2hhcnREYXRhLCB3ZSBuZWVkIHVuaXF1ZSBkYXRhIHR5cGUgdG8gcmV0dXJuIGJlY2F1c2Ugd2UgYXJlIGRvaW5nIGEgZGlmZmVyZW50IHdheSBvZiBzdGFjayBhcmVhLlxyXG4gICAgICogbmF0dXJhbCB3YXkgb2YgbGluZSBjaGFydCBpcyAxIGxpbmUsIDEgc2VyaWVzLlxyXG4gICAgICogd2hhdCB3ZSBhcmUgZG9pbmcgaXMgY3V0IHRoZSBsaW5lL3NwbGl0IHRoZSBzdGFjayBhcmVhIGludG8gMiB0byBjYXRlciBmb3IgbnVsbCB2YWx1ZS5cclxuICAgICAqIHRoZSBkYXRhIHN0cnVjdHVyZSB0aGF0IHdlIGhhdmUgY291cGxlZCBzdHJpY3RseSB0byAxIHggYXhpcy9jYXRlZ29yeSBtYXRjaCB3aXRoIDEgeSBkYXRhIHZhbHVlLlxyXG4gICAgICogZm9yIHNwbGl0dGluZyBvZiBzdGFjayBhcmVhLCB3ZSB3aWxsIG5lZWQgMSB4IGNhdGVnb3J5IG1hdGNoIHdpdGggMiB5IGRhdGEgdmFsdWUuXHJcbiAgICAgKlxyXG4gICAgICogXVxyXG4gICAgICogcGFyYW0gIHtudW1iZXJ9ICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIF95SW5kZXggICAgICAgICAgW3NlcmllcyBpbmRleCBhcyBsaW5lIGlzIGRyYXduIHBlciBzZXJpZXNdXHJcbiAgICAgKiBwYXJhbSAge0FycmF5PElEM0RhdGFEYXRhPiB8IEFycmF5PEFycmF5PElEYXRhVmFsdWU+Pn0gX2NoYXJ0RGF0YSAgICAgICBbZWl0aGVyIGxpbmUgZGF0YSBvciBhcmVhIGRhdGFdXHJcbiAgICAgKiBwYXJhbSAge2Jvb2xlYW59ICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgX2J5UGFzc0FyZWFDaGVjayBbc2tpcCBjaGFydCB0eXBlIGNoZWNrIGFuZCBkcmF3IGxpbmUuIHVzZWZ1bCBmb3IgYXJlYSB0byBkcmF3IGFyZWEgYW5kIGxpbmVdXHJcbiAgICAgKiByZXR1cm4ge3N0cmluZ30gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBbcmV0dXJuIHBhdGggZGF0YSB2YWx1ZV1cclxuICAgICAqL1xyXG4gICAgcHJpdmF0ZSBfc2V0UGF0aFZhbHVlKF95SW5kZXg6IG51bWJlciwgX2NoYXJ0RGF0YTogQXJyYXk8SUQzRGF0YURhdGE+IHwgQXJyYXk8QXJyYXk8SURhdGFWYWx1ZT4+LCBfYnlQYXNzQXJlYUNoZWNrPzogYm9vbGVhbik6IHN0cmluZyB7XHJcbiAgICAgICAgX2J5UGFzc0FyZWFDaGVjayA9IF9ieVBhc3NBcmVhQ2hlY2sgfHwgZmFsc2U7XHJcblxyXG4gICAgICAgIGxldCBjaGFydFZhbHVlOiBJRGF0YVZhbHVlID0geyB4OiBudWxsLCB5OiBudWxsLCB2YWxpZDogZmFsc2UgfSxcclxuICAgICAgICAgICAgY3VydmVTaGFwZTogYW55ID0gKHRoaXMuY2hhcnRUeXBlWzBdID09PSAnc3BsaW5lJyB8fCB0aGlzLmNoYXJ0VHlwZVt0aGlzLmNoYXJ0VHlwZS5sZW5ndGggLSAyXSA9PT0gJ3NwbGluZScpID8gZDMuY3VydmVDYXJkaW5hbCA6IGQzLmN1cnZlTGluZWFyLFxyXG4gICAgICAgICAgICBjaGFydDogYW55ID0gKHRoaXMuY2hhcnRUeXBlWzBdICE9PSAnYXJlYScgfHwgX2J5UGFzc0FyZWFDaGVjaykgPyBkMy5saW5lKCkgOiBkMy5hcmVhKCksXHJcbiAgICAgICAgICAgIGRhdGE6IEFycmF5PElEM0RhdGFEYXRhPiB8IEFycmF5PElEYXRhVmFsdWU+O1xyXG5cclxuICAgICAgICBkYXRhID0gKHRoaXMuX2lzVXNpbmdDaGFydERhdGEoX2NoYXJ0RGF0YSkpID8gX2NoYXJ0RGF0YSA6IF9jaGFydERhdGFbX3lJbmRleF07XHJcblxyXG4gICAgICAgIGxldCB2YWx1ZUxpbmU6IEZ1bmN0aW9uID0gY2hhcnQuY3VydmUoY3VydmVTaGFwZSk7XHJcblxyXG4gICAgICAgIGNoYXJ0LmRlZmluZWQoKGl0ZW06IElEM0RhdGFEYXRhIHwgSURhdGFWYWx1ZSwgeEluZGV4OiBudW1iZXIpID0+IHtcclxuICAgICAgICAgICAgY2hhcnRWYWx1ZSA9IHRoaXMuX3ZhbGlkYXRlQ2hhcnRWYWx1ZShkYXRhW3hJbmRleF0sIF95SW5kZXgpO1xyXG4gICAgICAgICAgICByZXR1cm4gY2hhcnRWYWx1ZS52YWxpZDtcclxuICAgICAgICB9KTtcclxuXHJcbiAgICAgICAgY2hhcnQueCgoKSA9PiB0aGlzLnJhbmdlTGlzdFtjaGFydFZhbHVlLngudmFsdWVdKTtcclxuXHJcbiAgICAgICAgaWYgKHRoaXMuY2hhcnRUeXBlWzBdICE9PSAnYXJlYScgfHwgX2J5UGFzc0FyZWFDaGVjaykge1xyXG4gICAgICAgICAgICBjaGFydC55KCgpID0+IHRoaXMueShjaGFydFZhbHVlLnkpKTtcclxuICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICBjaGFydC55MSgoKSA9PiB0aGlzLnkoY2hhcnRWYWx1ZS55KSlcclxuICAgICAgICAgICAgICAgIC55MCgoaXRlbSkgPT4gKHRoaXMuY2hhcnRUeXBlWzFdID09PSAnMTAwJyB8fCB0aGlzLmNoYXJ0VHlwZVsxXSA9PT0gJ3N0YWNrJykgPyB0aGlzLnkoY2hhcnRWYWx1ZS55MCkgOiB0aGlzLnkoMCkpO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgcmV0dXJuIHZhbHVlTGluZShkYXRhKTtcclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF9pc1VzaW5nQ2hhcnREYXRhKF9hcnJheU9iamVjdDogYW55KTogX2FycmF5T2JqZWN0IGlzIEFycmF5PElEM0RhdGFEYXRhPiB7XHJcbiAgICAgICAgcmV0dXJuIHRoaXMuY2hhcnRUeXBlWzFdICE9PSAnc3RhY2snO1xyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX2lzSURhdGFWYWx1ZShfb2JqZWN0OiBJRDNEYXRhRGF0YSB8IElEYXRhVmFsdWUpOiBfb2JqZWN0IGlzIElEYXRhVmFsdWUge1xyXG4gICAgICAgIHJldHVybiB0aGlzLmNoYXJ0VHlwZVsxXSA9PT0gJ3N0YWNrJztcclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF92YWxpZGF0ZUNoYXJ0VmFsdWUoX2l0ZW06IElEM0RhdGFEYXRhIHwgSURhdGFWYWx1ZSwgX3lJbmRleDogbnVtYmVyKTogSURhdGFWYWx1ZSB7XHJcbiAgICAgICAgaWYgKHRoaXMuX2lzSURhdGFWYWx1ZShfaXRlbSkpIHsgLy8gc3RhY2tcclxuICAgICAgICAgICAgcmV0dXJuIF9pdGVtO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgbGV0IHlWYWx1ZTogbnVtYmVyID0gX2l0ZW0ueVtfeUluZGV4XS5zdW07XHJcbiAgICAgICAgbGV0IHZhbGlkOiBib29sZWFuID0gdHJ1ZTtcclxuICAgICAgICBsZXQgeTA6IG51bWJlciA9IDA7XHJcblxyXG4gICAgICAgIGlmICh0aGlzLmNoYXJ0VHlwZVsxXSA9PT0gJzEwMCcpIHtcclxuICAgICAgICAgICAgeTAgPSBfaXRlbS55W195SW5kZXhdLnN1bSAtIF9pdGVtLnlbX3lJbmRleF0ucmVuZGVyVmFsO1xyXG4gICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgIHZhbGlkID0gc3VwZXIuaXNEYXRhRXhpc3QoX2l0ZW0sIF95SW5kZXgpO1xyXG4gICAgICAgIH1cclxuICAgICAgICByZXR1cm4geyB4OiBfaXRlbS54LCB5OiB5VmFsdWUsIHkwOiB5MCwgdmFsaWQ6IHZhbGlkIH07XHJcbiAgICB9XHJcblxyXG4gICAgLy8gRG90XHJcbiAgICBwcml2YXRlIF9hZGREb3QoX2RhdGE6IEFycmF5PElEM0RhdGFEYXRhPiwgX2RvdENvbnRhaW5lcjogYW55KTogdm9pZCB7XHJcbiAgICAgICAgZm9yIChsZXQgeEluZGV4OiBudW1iZXIgPSAwOyB4SW5kZXggPCBfZGF0YS5sZW5ndGg7IHhJbmRleCsrKSB7XHJcbiAgICAgICAgICAgIGxldCBpdGVtOiBJRDNEYXRhRGF0YSA9IF9kYXRhW3hJbmRleF07XHJcblxyXG4gICAgICAgICAgICBpZiAodGhpcy5jaGFydFR5cGVbMV0gIT09ICdzdGFjaycgJiYgIUFycmF5LmlzQXJyYXkoaXRlbS55KSB8fFxyXG4gICAgICAgICAgICAgICAgKEFycmF5LmlzQXJyYXkoaXRlbS55KSAmJiBpdGVtLnkubGVuZ3RoIDw9IDApKSBjb250aW51ZTtcclxuXHJcbiAgICAgICAgICAgIGxldCBkYXRhUG9pbnQ6IGFueSA9IF9kb3RDb250YWluZXIuYXBwZW5kKCdwYXRoJylcclxuICAgICAgICAgICAgICAgIC5hdHRyKCdjbGFzcycsIChkLCBpKSA9PiB0aGlzLl9wb3B1bGF0ZURvdERhdGEoaXRlbSwgaSwgeEluZGV4KSlcclxuICAgICAgICAgICAgICAgIC5hdHRyKCdkJywgKGQsIGkpID0+IHRoaXMuX2dldERvdElkKHhJbmRleCwgaSwgaXRlbSwgJ3NoYXBlJykpXHJcbiAgICAgICAgICAgICAgICAuYXR0cignZmlsbCcsIChkLCBpKSA9PiB0aGlzLl9nZXREb3RJZCh4SW5kZXgsIGksIGl0ZW0sICdjb2xvdXInKSlcclxuICAgICAgICAgICAgICAgIC5hdHRyKCdzdHJva2UnLCAoZCwgaSkgPT4gdGhpcy5fZ2V0RG90SWQoeEluZGV4LCBpLCBpdGVtLCAnYm9yZGVyQ29sb3InKSlcclxuICAgICAgICAgICAgICAgIC5hdHRyKCdzdHJva2Utd2lkdGgnLCAoZCwgaSkgPT4gdGhpcy5fZ2V0RG90SWQoeEluZGV4LCBpLCBpdGVtLCAnYm9yZGVyV2lkdGgnKSlcclxuICAgICAgICAgICAgICAgIC5hdHRyKCd0cmFuc2Zvcm0nLCAoZCwgaSkgPT4gdGhpcy5fZ2V0RG90SWQoeEluZGV4LCBpLCBpdGVtLCAncG9zaXRpb24nKSlcclxuICAgICAgICAgICAgICAgIC5zdHlsZSgnZGlzcGxheScsICdibG9jaycpO1xyXG5cclxuICAgICAgICAgICAgbGV0IGRvdEhvdmVyRnVuYzogRnVuY3Rpb24gPSB0aGlzLnRyaWdnZXJIb3ZlckZ1bmN0aW9uKHRoaXMpO1xyXG5cclxuICAgICAgICAgICAgc3VwZXIuX2luaXRNb3VzZUV2ZW50cyhkYXRhUG9pbnQsIHsgZGF0YTogaXRlbSwgeEluZGV4OiB4SW5kZXgsIGRvdEhvdmVyOiBkb3RIb3ZlckZ1bmMgfSk7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX2dldERvdElkKF94SW5kZXg6IG51bWJlciwgX3lJbmRleDogbnVtYmVyLCBfZGF0YTogSUQzRGF0YURhdGEsIF9lbGVtZW50OiAnc2hhcGUnIHwgJ2NvbG91cicgfCAnYm9yZGVyQ29sb3InIHwgJ2JvcmRlcldpZHRoJyB8ICdwb3NpdGlvbicpIHtcclxuICAgICAgICBpZiAoIShzdXBlci5pc0RhdGFFeGlzdChfZGF0YSwgX3lJbmRleCkgJiYgdGhpcy5sZWdlbmREYXRhW19kYXRhLnlbX3lJbmRleF0uaWRdLmRvdEVuYWJsZWQpKSByZXR1cm4gJyc7XHJcbiAgICAgICAgbGV0IGlkID0gc3VwZXIuZ2V0RG90SWQoX3hJbmRleCwgX2RhdGEueVtfeUluZGV4XS5pZCkucmVwbGFjZSgvXFxzL2csICcnKTtcclxuICAgICAgICBsZXQgdmFsdWU6IHN0cmluZyB8IG51bWJlciA9ICcnO1xyXG4gICAgICAgIGlmIChfZWxlbWVudCA9PT0gJ3Bvc2l0aW9uJykge1xyXG4gICAgICAgICAgICBsZXQgeDogbnVtYmVyID0gKHRoaXMuX2RvdERhdGFbaWRdICYmIHR5cGVvZiB0aGlzLl9kb3REYXRhW2lkXS54ICE9PSAndW5kZWZpbmVkJykgPyB0aGlzLl9kb3REYXRhW2lkXS54IDogdGhpcy5fZGVmYXVsdERvdFBvcy54O1xyXG4gICAgICAgICAgICBsZXQgeTogbnVtYmVyID0gKHRoaXMuX2RvdERhdGFbaWRdICYmIHR5cGVvZiB0aGlzLl9kb3REYXRhW2lkXS55ICE9PSAndW5kZWZpbmVkJykgPyB0aGlzLl9kb3REYXRhW2lkXS55IDogdGhpcy5fZGVmYXVsdERvdFBvcy55O1xyXG4gICAgICAgICAgICB2YWx1ZSA9IHN1cGVyLnRyYW5zZm9ybVBvc2l0aW9uKHgsIHksIHRydWUpO1xyXG4gICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgIHZhbHVlID0gKHRoaXMuX2RvdERhdGFbaWRdICYmIHRoaXMuX2RvdERhdGFbaWRdW19lbGVtZW50XSkgPyB0aGlzLl9kb3REYXRhW2lkXVtfZWxlbWVudF0udG9TdHJpbmcoKSA6ICcnO1xyXG4gICAgICAgIH1cclxuICAgICAgICByZXR1cm4gdmFsdWU7XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfcG9wdWxhdGVEb3REYXRhKF9kYXRhOiBJRDNEYXRhRGF0YSwgX3lJbmRleDogbnVtYmVyLCBfeEluZGV4OiBudW1iZXIpOiBzdHJpbmcge1xyXG4gICAgICAgIGlmICghc3VwZXIuaXNEYXRhRXhpc3QoX2RhdGEsIF95SW5kZXgpKSByZXR1cm4gJyc7XHJcbiAgICAgICAgbGV0IGlkOiBzdHJpbmcgPSBzdXBlci5nZXREb3RJZChfeEluZGV4LCBfZGF0YS55W195SW5kZXhdLmlkKS5yZXBsYWNlKC9cXHMvZywgJycpO1xyXG4gICAgICAgIGxldCBjb2xvdXI6IHN0cmluZyA9IF9kYXRhLnlbX3lJbmRleF0uY29sb3I7XHJcbiAgICAgICAgbGV0IHNoYXBlOiBzdHJpbmcgPSBfZGF0YS55W195SW5kZXhdLnNoYXBlO1xyXG4gICAgICAgIGxldCBwb3NpdGlvbjogSVBvc2l0aW9uID0gdGhpcy5fZ2V0RG90UG9zaXRpb24oX2RhdGEueC52YWx1ZSwgX3hJbmRleCwgX2RhdGEueVtfeUluZGV4XS5zdW0pO1xyXG4gICAgICAgIGxldCBib3JkZXJDb2xvcjogc3RyaW5nID0gdGhpcy5sZWdlbmREYXRhW19kYXRhLnlbX3lJbmRleF0uaWRdLmRvdEJvcmRlckNvbG9yO1xyXG4gICAgICAgIGxldCBib3JkZXJXaWR0aDogbnVtYmVyID0gdGhpcy5sZWdlbmREYXRhW19kYXRhLnlbX3lJbmRleF0uaWRdLmRvdEJvcmRlcldpZHRoO1xyXG5cclxuICAgICAgICB0aGlzLl9zZXRMYWJlbChfZGF0YS55W195SW5kZXhdLCBfeEluZGV4LCBwb3NpdGlvbi54LCBib3JkZXJXaWR0aCk7XHJcblxyXG4gICAgICAgIGlmIChfZGF0YS55W195SW5kZXhdLnZhbHVlID09PSB0aGlzLmRvbWFpbk1pbiB8fCBfZGF0YS55W195SW5kZXhdLnZhbHVlID09PSB0aGlzLmRvbWFpbk1heCkge1xyXG4gICAgICAgICAgICBsZXQgY3VycmVudERvdFNpemUgPSAxMiArIGJvcmRlcldpZHRoO1xyXG5cclxuICAgICAgICAgICAgaWYgKHRoaXMuX2JpZ2dlc3REb3RTaXplIDwgY3VycmVudERvdFNpemUpIHRoaXMuX2JpZ2dlc3REb3RTaXplID0gY3VycmVudERvdFNpemU7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICBpZiAoKHRoaXMuY29uZmlnLnlBeGlzLm1pblZhbHVlICE9PSBudWxsICYmXHJcbiAgICAgICAgICAgIF9kYXRhLnlbX3lJbmRleF0udmFsdWUgPCB0aGlzLmNvbmZpZy55QXhpcy5taW5WYWx1ZSkgfHxcclxuICAgICAgICAgICAgKHRoaXMuY29uZmlnLnlBeGlzLm1heFZhbHVlICE9PSBudWxsICYmXHJcbiAgICAgICAgICAgIF9kYXRhLnlbX3lJbmRleF0udmFsdWUgPiB0aGlzLmNvbmZpZy55QXhpcy5tYXhWYWx1ZSkpIHtcclxuICAgICAgICAgICAgZGVsZXRlIHRoaXMuX2RvdERhdGFbaWRdO1xyXG4gICAgICAgICAgICByZXR1cm4gaWQ7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICB0aGlzLl9kb3REYXRhW2lkXSA9IHtcclxuICAgICAgICAgICAgY29sb3VyOiBjb2xvdXIsXHJcbiAgICAgICAgICAgIHNoYXBlOiBzaGFwZSxcclxuICAgICAgICAgICAgeDogcG9zaXRpb24ueCxcclxuICAgICAgICAgICAgeTogcG9zaXRpb24ueSxcclxuICAgICAgICAgICAgYm9yZGVyQ29sb3I6IGJvcmRlckNvbG9yLFxyXG4gICAgICAgICAgICBib3JkZXJXaWR0aDogYm9yZGVyV2lkdGhcclxuICAgICAgICB9O1xyXG5cclxuICAgICAgICByZXR1cm4gaWQ7XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfZ2V0RG90UG9zaXRpb24oX3hWYWx1ZTogc3RyaW5nLCBfeEluZGV4OiBudW1iZXIsIF95VmFsdWU6IG51bWJlcik6IElQb3NpdGlvbiB7XHJcbiAgICAgICAgbGV0IHhQb3M6IG51bWJlciA9IDA7XHJcbiAgICAgICAgbGV0IHlQb3M6IG51bWJlciA9IDA7XHJcblxyXG4gICAgICAgIHhQb3MgPSAodGhpcy5yYW5nZUxpc3RbX3hWYWx1ZV0gLSA0KTtcclxuICAgICAgICB5UG9zID0gKHRoaXMueShfeVZhbHVlKSAtIDQpO1xyXG5cclxuICAgICAgICByZXR1cm4geyB4OiB4UG9zLCB5OiB5UG9zIH07XHJcbiAgICB9XHJcblxyXG4gICAgLy8gaG92ZXIgZnVuY3Rpb25cclxuICAgIHByaXZhdGUgdHJpZ2dlckhvdmVyRnVuY3Rpb24oX2tkTGluZUNoYXJ0OiBLZExpbmVDaGFydCk6IEZ1bmN0aW9uIHtcclxuICAgICAgICByZXR1cm4gZnVuY3Rpb24oZG90SWQ6IHN0cmluZywgaXNIb3ZlcmluZz86IGJvb2xlYW4pOiB2b2lkIHtcclxuICAgICAgICAgICAgaXNIb3ZlcmluZyA9IGlzSG92ZXJpbmcgfHwgZmFsc2U7XHJcbiAgICAgICAgICAgIF9rZExpbmVDaGFydC5kb3RIb3Zlcihfa2RMaW5lQ2hhcnQsIGRvdElkLCBpc0hvdmVyaW5nKTtcclxuICAgICAgICB9O1xyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgZG90SG92ZXIoX2tkTGluZUNoYXJ0OiBLZExpbmVDaGFydCwgX2RvdElkOiBzdHJpbmcsIF9pc0hvdmVyaW5nOiBib29sZWFuKTogdm9pZCB7XHJcbiAgICAgICAgX2RvdElkID0gX2RvdElkLnJlcGxhY2UoL1xccy9nLCAnJyk7XHJcbiAgICAgICAgaWYoIXRoaXMuX2RvdERhdGEuaGFzT3duUHJvcGVydHkoX2RvdElkKSB8fCAhdGhpcy5fZG90RGF0YVtfZG90SWRdLnNoYXBlKSByZXR1cm47XHJcbiAgICAgICAgbGV0IHNoYXBlOiBzdHJpbmcgPSAoX2lzSG92ZXJpbmcpID8gdGhpcy5fc2hhcGVzW3RoaXMuX2RvdERhdGFbX2RvdElkXS5zaGFwZV0gOiB0aGlzLl9kb3REYXRhW19kb3RJZF0uc2hhcGU7XHJcbiAgICAgICAgbGV0IHBvc2l0aW9uOiBJUG9zaXRpb24gPSB0aGlzLl9kb3RIb3ZlclBvc2l0aW9uKF9kb3RJZCwgX2lzSG92ZXJpbmcsIGZhbHNlKTtcclxuICAgICAgICBsZXQgYm9yZGVyV2lkdGg6IG51bWJlciA9IHRoaXMuX2RvdERhdGFbX2RvdElkXS5ib3JkZXJXaWR0aDtcclxuXHJcbiAgICAgICAgaWYgKGJvcmRlcldpZHRoID09PSAwICYmIF9pc0hvdmVyaW5nKSBib3JkZXJXaWR0aCA9IDE7XHJcblxyXG4gICAgICAgIHRoaXMuX3NldEhvdmVyQmFja2dyb3VuZChfZG90SWQsIF9pc0hvdmVyaW5nKTtcclxuICAgICAgICBkMy5zZWxlY3QoJyMnICsgdGhpcy5jb25maWcuaWQgKyAnLmtkeC1jaGFydHMgLicgKyBfZG90SWQpXHJcbiAgICAgICAgICAgIC5hdHRyKCdkJywgc2hhcGUpXHJcbiAgICAgICAgICAgIC5hdHRyKCd0cmFuc2Zvcm0nLCBzdXBlci50cmFuc2Zvcm1Qb3NpdGlvbihwb3NpdGlvbi54LCBwb3NpdGlvbi55LCB0cnVlKSlcclxuICAgICAgICAgICAgLmF0dHIoJ3N0cm9rZS13aWR0aCcsIGJvcmRlcldpZHRoKTtcclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF9zZXRIb3ZlckJhY2tncm91bmQoX2RvdElkOiBzdHJpbmcsIF9pc0hvdmVyaW5nOiBib29sZWFuKTogdm9pZCB7XHJcbiAgICAgICAgbGV0IGNvbG91cjogc3RyaW5nID0gdGhpcy5fZG90RGF0YVtfZG90SWRdLmNvbG91cjtcclxuXHJcbiAgICAgICAgbGV0IHBvc2l0aW9uOiBJUG9zaXRpb24gPSBfaXNIb3ZlcmluZyA/IHRoaXMuX2RvdEhvdmVyUG9zaXRpb24oX2RvdElkLCBfaXNIb3ZlcmluZywgdHJ1ZSkgOiB0aGlzLl9kZWZhdWx0RG90UG9zO1xyXG5cclxuICAgICAgICBkMy5zZWxlY3QoJyMnICsgdGhpcy5jb25maWcuaWQgKyAnLmtkeC1jaGFydHMgLmtkeC1jaGFydHMtaG92ZXItZG90JylcclxuICAgICAgICAgICAgLy8gLnN0eWxlKCdkaXNwbGF5JywgZGlzcGxheSlcclxuICAgICAgICAgICAgLmF0dHIoJ2ZpbGwnLCBjb2xvdXIpXHJcbiAgICAgICAgICAgIC5hdHRyKCd0cmFuc2Zvcm0nLCB0aGlzLnRyYW5zZm9ybVBvc2l0aW9uKHBvc2l0aW9uLngsIHBvc2l0aW9uLnksIHRydWUpKVxyXG4gICAgICAgICAgICAuYXR0cignc3Ryb2tlLXdpZHRoJywgMSlcclxuICAgICAgICAgICAgLmF0dHIoJ3N0cm9rZScsIGNvbG91cik7XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfZG90SG92ZXJQb3NpdGlvbihfZG90SWQ6IHN0cmluZywgX2lzSG92ZXJpbmc6IGJvb2xlYW4sIF9pc0JhY2tncm91bmQ6IGJvb2xlYW4pOiBJUG9zaXRpb24ge1xyXG4gICAgICAgIGxldCB4UG9zOiBudW1iZXIgPSB0aGlzLl9kb3REYXRhW19kb3RJZF0ueDtcclxuICAgICAgICBsZXQgeVBvczogbnVtYmVyID0gdGhpcy5fZG90RGF0YVtfZG90SWRdLnk7XHJcblxyXG4gICAgICAgIGlmICghX2lzSG92ZXJpbmcpIHJldHVybiB7IHg6IHhQb3MsIHk6IHlQb3MgfTtcclxuXHJcbiAgICAgICAgaWYgKF9pc0JhY2tncm91bmQpIHtcclxuICAgICAgICAgICAgeFBvcyAtPSA2O1xyXG4gICAgICAgICAgICB5UG9zIC09IDY7XHJcbiAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgeFBvcyAtPSAyO1xyXG4gICAgICAgICAgICB5UG9zIC09IDI7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICByZXR1cm4geyB4OiB4UG9zLCB5OiB5UG9zIH07XHJcbiAgICB9XHJcblxyXG4gICAgLy8gbGFiZWxcclxuICAgIHByaXZhdGUgX3NldExhYmVsKF95RGF0YTogSUQzWURhdGEsIF94SW5kZXg6IG51bWJlciwgX3hQb3NpdGlvbjogbnVtYmVyLCBfZG90V2lkdGg6IG51bWJlcik6IHZvaWQge1xyXG4gICAgICAgIGlmICghdGhpcy5jb25maWcuY2hhcnQubGFiZWxzLmVuYWJsZWQpIHJldHVybjtcclxuXHJcbiAgICAgICAgX3hQb3NpdGlvbiAtPSBfZG90V2lkdGggLyAyO1xyXG5cclxuICAgICAgICBsZXQgbGFiZWw6IGFueSA9IHN1cGVyLnNldExhYmVsKF95RGF0YSwgX3hJbmRleCwgX3hQb3NpdGlvbiwgdGhpcy55KF95RGF0YS5zdW0pKTtcclxuICAgICAgICAvLyBsYWJlbC5zdHlsZSgnZGlzcGxheScsICdmbGV4Jyk7XHJcblxyXG4gICAgICAgIGxldCBzcGFuRWxtOiBhbnkgPSBsYWJlbC5zZWxlY3QoJy5rZHgtY2hhcnRzLWRhdGEtbGFiZWwtdGV4dCcpO1xyXG5cclxuICAgICAgICBsZXQgZGF0YUxhYmVsTGVuZ3RoOiBudW1iZXIgPSB0aGlzLl9nZXRMYWJlbFRleHRMZW5ndGgoX3lEYXRhKTtcclxuXHJcbiAgICAgICAgbGV0IGRvdFNpemUgPSAxMCArIF9kb3RXaWR0aDsgLy8gYWRkIDEwcHggZm9yIHNwYWNpbmcgYmV0d2VlbiBkb3QgYW5kIGxhYmVsXHJcbiAgICAgICAgc3VwZXIuc2V0TGFiZWxUZXh0UG9zaXRpb24oc3BhbkVsbSwgdGhpcy55KF95RGF0YS5zdW0pLCB7IGRvdFNpemU6IGRvdFNpemUsIGxhYmVsTGVuZ3RoOiBkYXRhTGFiZWxMZW5ndGggfSk7XHJcblxyXG4gICAgICAgIC8vIHNoaWZ0IHRleHQgdG8gdGhlIGhvcml6b250YWxseSBjZW50ZXIgdG8gdGhlIGRvdFxyXG4gICAgICAgIC8vIGlmICh0aGlzLl9jaGFydFN2Yy5pc0V4aXN0KF95RGF0YSkgJiYgZGF0YUxhYmVsTGVuZ3RoID4gMSkge1xyXG4gICAgICAgIC8vICAgICBsZXQgc2hpZnRQb3NpdGlvbjogbnVtYmVyID0gdGhpcy5fZ2V0Q2VudGVyUG9zaXRpb24oZGF0YUxhYmVsTGVuZ3RoLCBzcGFuRWxtKTtcclxuICAgICAgICAvLyAgICAgc3BhbkVsbS5zdHlsZSgnbGVmdCcsIHNoaWZ0UG9zaXRpb24gKyAncHgnKS5zdHlsZSgnZGlzcGxheScsICdub25lJyk7XHJcbiAgICAgICAgLy8gfVxyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX2dldExhYmVsVGV4dExlbmd0aChfeURhdGE6IElEM1lEYXRhKTogbnVtYmVyIHtcclxuICAgICAgICBsZXQgZGF0YUxhYmVsID0gdGhpcy5jb25maWcuY2hhcnQubGFiZWxzLmZvcm1hdC5yZXBsYWNlKCd7dmFsdWV9JywgdGhpcy5fY2hhcnRTdmMuZ2V0RDNGb3JtYXQoX3lEYXRhLnZhbHVlKSk7XHJcblxyXG4gICAgICAgIHJldHVybiBkYXRhTGFiZWwudG9TdHJpbmcoKS5sZW5ndGg7XHJcbiAgICB9XHJcblxyXG4gICAgLy8gcHJpdmF0ZSBfZ2V0Q2VudGVyUG9zaXRpb24oX2RhdGFMYWJlbExlbmd0aDogbnVtYmVyLCBfc3BhbkVsbTogYW55KSB7XHJcblxyXG4gICAgLy8gICAgIGxldCBsYWJlbEVsbTogYW55ID0gX3NwYW5FbG0ubm9kZSgpLmdldEJvdW5kaW5nQ2xpZW50UmVjdCgpO1xyXG5cclxuICAgIC8vICAgICBsZXQgbGFiZWxXaWR0aDogbnVtYmVyID0gbGFiZWxFbG0ud2lkdGg7XHJcbiAgICAvLyAgICAgbGV0IGxhYmVsQ2VudGVyOiBudW1iZXIgPSAobGFiZWxXaWR0aCAtIGxhYmVsV2lkdGggLyBfZGF0YUxhYmVsTGVuZ3RoKSAvIDI7XHJcbiAgICAvLyAgICAgbGV0IHNoaWZ0UG9zaXRpb246IG51bWJlciA9IDAgLSBsYWJlbENlbnRlcjtcclxuXHJcbiAgICAvLyAgICAgaWYgKGRvY3VtZW50LmRpciA9PT0gJ3J0bCcpIHJldHVybiBsYWJlbENlbnRlcjtcclxuXHJcbiAgICAvLyAgICAgcmV0dXJuIHNoaWZ0UG9zaXRpb247XHJcbiAgICAvLyB9XHJcblxyXG4gICAgLy8gYW5pbWF0aW9uXHJcbiAgICBwcml2YXRlIF9zZXRDaGFydEFuaW1hdGlvbigpOiB2b2lkIHtcclxuXHJcbiAgICAgICAgbGV0IGhhbGZEb3Q6IG51bWJlciA9IHRoaXMuX2JpZ2dlc3REb3RTaXplIC8gMjtcclxuICAgICAgICBsZXQgb2Zmc2V0U3RhcnQ6IG51bWJlciA9IDAgLSBoYWxmRG90O1xyXG5cclxuICAgICAgICBsZXQgY2xpcDogYW55ID0gdGhpcy5saW5lQ2hhcnQuYXBwZW5kKCdjbGlwUGF0aCcpXHJcbiAgICAgICAgICAgIC5hdHRyKCdpZCcsICdsaW5lLWNsaXAnICsgdGhpcy5jb25maWcuaWQpO1xyXG4gICAgICAgIGxldCBjbGlwUmVjdDogYW55ID0gY2xpcC5hcHBlbmQoJ3JlY3QnKVxyXG4gICAgICAgICAgICAuYXR0cignZmlsbCcsICd3aGl0ZScpXHJcbiAgICAgICAgICAgIC5hdHRyKCd4Jywgb2Zmc2V0U3RhcnQpXHJcbiAgICAgICAgICAgIC5hdHRyKCd5Jywgb2Zmc2V0U3RhcnQpXHJcbiAgICAgICAgICAgIC5hdHRyKCdmaWxsJywgJ25vbmUnKVxyXG4gICAgICAgICAgICAuYXR0cignd2lkdGgnLCAwKVxyXG4gICAgICAgICAgICAuYXR0cignaGVpZ2h0JywgdGhpcy5oZWlnaHQgKyB0aGlzLl9iaWdnZXN0RG90U2l6ZSk7XHJcblxyXG4gICAgICAgIHRoaXMubGluZUNoYXJ0LmF0dHIoJ2NsaXAtcGF0aCcsICd1cmwoI2xpbmUtY2xpcCcgKyB0aGlzLmNvbmZpZy5pZCArICcpJyk7XHJcblxyXG4gICAgICAgIGxldCB0cmFuc2l0aW9uRnVuYzogRnVuY3Rpb24gPSBkMy50cmFuc2l0aW9uKClcclxuICAgICAgICAgICAgLmR1cmF0aW9uKHRoaXMubGVuZ3RoT2ZUcmFuc2l0aW9uKVxyXG4gICAgICAgICAgICAuZWFzZShkMy5lYXNlTGluZWFyKTtcclxuXHJcbiAgICAgICAgY2xpcFJlY3QudHJhbnNpdGlvbih0cmFuc2l0aW9uRnVuYylcclxuICAgICAgICAgICAgLmF0dHIoJ3dpZHRoJywgdGhpcy53aWR0aCArIHRoaXMuX2JpZ2dlc3REb3RTaXplKTtcclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF9zZXRMYWJlbEFuaW1hdGlvbihfeEluZGV4OiBudW1iZXIsIF9kYXRhOiBJRDNEYXRhRGF0YSk6IHZvaWQge1xyXG4gICAgICAgIGlmICh0aGlzLmNvbmZpZy5jaGFydCAhPT0gdW5kZWZpbmVkICYmIHRoaXMuY29uZmlnLmNoYXJ0LmxhYmVscyAhPT0gdW5kZWZpbmVkKSB7XHJcbiAgICAgICAgICAgIGlmICghdGhpcy5jb25maWcuY2hhcnQubGFiZWxzLmVuYWJsZWQpIHJldHVybjtcclxuICAgICAgICAgICAgbGV0IGxhYmVsRGVsYXk6IG51bWJlciA9IDEuNTtcclxuICAgICAgICAgICAgbGV0IGFuaW1hdGlvbkRlbGF5OiBudW1iZXIgPSBfeEluZGV4ICogdGhpcy5sZW5ndGhPZlRyYW5zaXRpb24gLyBfZGF0YS55Lmxlbmd0aCAqIGxhYmVsRGVsYXk7XHJcbiAgICAgICAgICAgIGxldCB0cmFuc2l0aW9uVGltZTogbnVtYmVyID0gdGhpcy5jb25maWcuYW5pbWF0aW9uID8gdGhpcy5sZW5ndGhPZlRyYW5zaXRpb24gOiAwO1xyXG4gICAgICAgICAgICBhbmltYXRpb25EZWxheSA9IHRoaXMuY29uZmlnLmFuaW1hdGlvbiA/IGFuaW1hdGlvbkRlbGF5IDogMDtcclxuXHJcbiAgICAgICAgICAgIGQzLnNlbGVjdEFsbCgnIycgKyB0aGlzLmNvbmZpZy5pZCArICcua2R4LWNoYXJ0cyAua2R4LWNoYXJ0cy1kYXRhLWxhYmVsLngtJyArIF94SW5kZXgpXHJcbiAgICAgICAgICAgICAgICAudHJhbnNpdGlvbigpICAvLyBUcmFuc2l0aW9uIGZyb20gb2xkIHRvIG5ld1xyXG4gICAgICAgICAgICAgICAgLmR1cmF0aW9uKHRyYW5zaXRpb25UaW1lKSAgLy8gTGVuZ3RoIG9mIGFuaW1hdGlvblxyXG4gICAgICAgICAgICAgICAgLmRlbGF5KGFuaW1hdGlvbkRlbGF5KVxyXG4gICAgICAgICAgICAgICAgLm9uKCdzdGFydCcsIGZ1bmN0aW9uKGQsIGkpIHsgIC8vIFN0YXJ0IGFuaW1hdGlvblxyXG4gICAgICAgICAgICAgICAgICAgIGQzLnNlbGVjdCh0aGlzKSAgLy8gJ3RoaXMnIG1lYW5zIHRoZSBjdXJyZW50IGVsZW1lbnRcclxuICAgICAgICAgICAgICAgICAgICAgICAgLnN0eWxlKCd2aXNpYmlsaXR5JywgJ3Zpc2libGUnKTtcclxuICAgICAgICAgICAgICAgICAgICAvLyAuc3R5bGUoJ2Rpc3BsYXknLCAnYmxvY2snKTtcclxuICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICAvLyBTdGFjayBBcmVhIHJlY2FsY3VsYXRlXHJcblxyXG4gICAgLyoqXHJcbiAgICAgKiBmb3IgYXJlYSBzdGFjayAobm90IHRoZSAxMDAlIHN0YWNrLiAxMDAlIGRhdGEgbWFzc2FnZSBpcyB0aGUgc2FtZSBhcyBiYXIgd2hpY2hcclxuICAgICAqIHRoZSBkYXRhIG1hc3NzYWdlIGlzIGRvbmUgaW4ga2QgY2hhcnRzKS5cclxuICAgICAqXHJcbiAgICAgKiB0aGlzIGNhbm5vdCBiZSBkb25lIHRocm91Z2gga2QgY2hhcnQgZGF0YSBtYXNzYWdlIGJlY2F1c2UgdGhlIGRvdCBwb3NpdGlvbiBoYXMgdG9cclxuICAgICAqIGJlIG9uIHRoZSBjb3JyZWN0IHN1bSAoc2FtZSBhcyBiYXIpLiB3ZSB3aWxsIHRha2UgYmFyIGFmdGVyIG1hc3NhZ2UgdmFsdWUgZm9yIGRvdFxyXG4gICAgICogYW5kIHJlbWFzc2FnZSBmb3IgbGluZSBhcmVhLlxyXG4gICAgICpcclxuICAgICAqIHRoaXMgZGF0YSBtYXNzYWdlIGlzIGNhdGVyaW5nIHVuaXF1ZSBsaW5lIGJlaGF2aW91ciB3aGVuIGhhbmRsaW5nIG51bGwgdmFsdWUuXHJcbiAgICAgKlxyXG4gICAgICogbGluZSBiZWhhdmlvdXIgb24gbnVsbDogd2hlbiBhIG51bGwgYXBwZWFyLCB0aGUgbGluZSBmb3IgcHJldmlvdXMgYW5kIGFmdGVyIGN1cnJlbnRcclxuICAgICAqIHggYXhpcyB3aWxsIG5vdCBiZSBkcmF3bi4gY2F1c2luZyB0aGUgcHJldmlvdXMgYW5kIGFmdGVyIHggYXhpcyB0byBiZSBpbnRlcHJldGVkIGFzIDBcclxuICAgICAqXHJcbiAgICAgKiBhcyB0aGUgd2hvbGUgYXJlYSBvZiB0aGlzIGN1cnJlbnQgeCBheGlzIHdpbGwgYmUgMCBmb3IgY3VycmVudCBzZXJpZXMsIGFueSBzZXJpZXMgYWZ0ZXJcclxuICAgICAqIGhhcyB0byBiZSBicm91Z2h0IGRvd24uXHJcbiAgICAgKlxyXG4gICAgICogd2UgbmVlZCB1bmlxdWUgZGF0YSB0eXBlIHRvIHJldHVybiBiZWNhdXNlIHdlIGFyZSBkb2luZyBhIGRpZmZlcmVudCB3YXkgb2Ygc3RhY2sgYXJlYS5cclxuICAgICAqIG5hdHVyYWwgd2F5IG9mIGxpbmUgY2hhcnQgaXMgMSBsaW5lLCAxIHNlcmllcy5cclxuICAgICAqIHdoYXQgd2UgYXJlIGRvaW5nIGlzIGN1dCB0aGUgbGluZS9zcGxpdCB0aGUgc3RhY2sgYXJlYSBpbnRvIDIgdG8gY2F0ZXIgZm9yIG51bGwgdmFsdWUuXHJcbiAgICAgKiB0aGUgZGF0YSBzdHJ1Y3R1cmUgdGhhdCB3ZSBoYXZlIGNvdXBsZWQgc3RyaWN0bHkgdG8gMSB4IGF4aXMvY2F0ZWdvcnkgbWF0Y2ggd2l0aCAxIHkgZGF0YSB2YWx1ZS5cclxuICAgICAqIGZvciBzcGxpdHRpbmcgb2Ygc3RhY2sgYXJlYSwgd2Ugd2lsbCBuZWVkIDEgeCBjYXRlZ29yeSBtYXRjaCB3aXRoIDIgeSBkYXRhIHZhbHVlLlxyXG4gICAgICpcclxuICAgICAqIHBhcmFtICB7QXJyYXk8SUQzRGF0YURhdGE+fSBkYXRhIGFmdGVyIG1hc3NhZ2UgZGF0YVxyXG4gICAgICogcmV0dXJuIHtBcnJheX0gICAgICAgICAgICAgICAgICAgcmV0dXJuIGFzIHt4LCB5LCB5MCwgdmFsaWR9IGFzIGQzIHJlcXVpcmVkLlxyXG4gICAgICovXHJcbiAgICBwcml2YXRlIF9kYXRhTWFzc2FnZShfZGF0YTogQXJyYXk8SUQzRGF0YURhdGE+KTogQXJyYXk8QXJyYXk8SURhdGFWYWx1ZT4+IHtcclxuICAgICAgICAvLyBjb25zb2xlLmxvZyhfZGF0YSk7XHJcbiAgICAgICAgbGV0IGRhdGFBcnI6IEFycmF5PEFycmF5PElEYXRhVmFsdWU+PiA9IFtdO1xyXG4gICAgICAgIGxldCBhZGp1c3RQb3NpdGlvbjogSUFkanVzdCA9IHt9O1xyXG5cclxuICAgICAgICBmb3IgKGxldCBpOiBudW1iZXIgPSAwOyBpIDwgdGhpcy5fc2VyaWVzTGlzdC5sZW5ndGg7ICsraSkge1xyXG5cclxuICAgICAgICAgICAgbGV0IGRhdGFEZXRhaWxzOiBBcnJheTxJRGF0YVZhbHVlPiA9IFtdO1xyXG5cclxuICAgICAgICAgICAgbGV0IHg6IHN0cmluZyA9IG51bGw7XHJcbiAgICAgICAgICAgIGxldCB5OiBudW1iZXIgPSAwO1xyXG4gICAgICAgICAgICBsZXQgeTA6IG51bWJlciA9IDA7XHJcbiAgICAgICAgICAgIGxldCB2YWxpZDogYm9vbGVhbiA9IHRydWU7XHJcblxyXG4gICAgICAgICAgICBmb3IgKGxldCB4SW5kZXg6IG51bWJlciA9IDA7IHhJbmRleCA8IF9kYXRhLmxlbmd0aDsgKyt4SW5kZXgpIHtcclxuICAgICAgICAgICAgICAgIGxldCB4VmFsdWU6IHN0cmluZyA9IF9kYXRhW3hJbmRleF0ueC52YWx1ZTtcclxuXHJcbiAgICAgICAgICAgICAgICBmb3IgKGxldCB5SW5kZXg6IG51bWJlciA9IDA7IHlJbmRleCA8IF9kYXRhW3hJbmRleF0ueS5sZW5ndGg7ICsreUluZGV4KSB7XHJcbiAgICAgICAgICAgICAgICAgICAgbGV0IGlkOiBzdHJpbmcgPSBfZGF0YVt4SW5kZXhdLnlbeUluZGV4XS5pZDtcclxuICAgICAgICAgICAgICAgICAgICB4ID0geFZhbHVlO1xyXG5cclxuICAgICAgICAgICAgICAgICAgICB2YWxpZCA9IF9kYXRhW3hJbmRleF0ueVt5SW5kZXhdLnZhbHVlICE9PSBudWxsID8gdHJ1ZSA6IGZhbHNlO1xyXG5cclxuICAgICAgICAgICAgICAgICAgICBpZiAodGhpcy5jaGFydFR5cGVbMV0gPT09ICdzdGFjaycgJiYgaWQgPT09IHRoaXMuX3Nlcmllc0xpc3RbaV0pIHtcclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGxldCBudWxsVmFsdWU6IG51bWJlciA9IHRoaXMuX2dldE51bGxIZWlnaHRWYWx1ZShfZGF0YSwgeEluZGV4LCB5SW5kZXgpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBsZXQgYWRqdXN0VmFsdWUgPSAodHlwZW9mIGFkanVzdFBvc2l0aW9uW3hJbmRleF0gPT09ICd1bmRlZmluZWQnKSA/IDAgOiBhZGp1c3RQb3NpdGlvblt4SW5kZXhdO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBhZGp1c3RQb3NpdGlvblt4SW5kZXhdID0gYWRqdXN0VmFsdWUgLSBudWxsVmFsdWU7XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICBsZXQgYWRqdXN0OiBudW1iZXIgPSBhZGp1c3RQb3NpdGlvblt4SW5kZXhdIHx8IDA7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGxldCBjdXJyZW50VmFsdWU6IG51bWJlciA9IF9kYXRhW3hJbmRleF0ueVt5SW5kZXhdLnZhbHVlO1xyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgeSA9IF9kYXRhW3hJbmRleF0ueVt5SW5kZXhdLnN1bSArIGFkanVzdDtcclxuICAgICAgICAgICAgICAgICAgICAgICAgeTAgPSB5IC0gY3VycmVudFZhbHVlO1xyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgZGF0YURldGFpbHMucHVzaCh7IHg6IHsgdmFsdWU6IHgsIGxhYmVsOiB4IH0sIHk6IHksIHkwOiB5MCwgaWQ6IGlkLCB2YWxpZDogdmFsaWQgfSk7XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICBsZXQgc3BsaXRQYXRoRGF0YTogSURhdGFWYWx1ZSA9IHRoaXMuX2dldFNwbGl0UGF0aERhdGEoX2RhdGEsIHhJbmRleCwgeUluZGV4LCBhZGp1c3RQb3NpdGlvbik7XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAoc3BsaXRQYXRoRGF0YS52YWxpZCA9PT0gdHJ1ZSkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgZGF0YURldGFpbHMucHVzaCh7IHg6IHNwbGl0UGF0aERhdGEueCwgeTogc3BsaXRQYXRoRGF0YS55LCB5MDogc3BsaXRQYXRoRGF0YS55MCwgaWQ6IGlkLCB2YWxpZDogZmFsc2UgfSk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBkYXRhRGV0YWlscy5wdXNoKHsgeDogc3BsaXRQYXRoRGF0YS54LCB5OiBzcGxpdFBhdGhEYXRhLnksIHkwOiBzcGxpdFBhdGhEYXRhLnkwLCBpZDogaWQsIHZhbGlkOiB0cnVlIH0pO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICBicmVhaztcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgZGF0YUFyci5wdXNoKGRhdGFEZXRhaWxzKTtcclxuICAgICAgICB9XHJcbiAgICAgICAgLy8gY29uc29sZS5sb2coZGF0YUFycik7XHJcbiAgICAgICAgcmV0dXJuIGRhdGFBcnI7XHJcbiAgICB9XHJcblxyXG4gICAgLyoqXHJcbiAgICAgKiBpZiB0aGUgcHJldmlvdXMgc2VyaWVzIGlzIG51bGwsIGFyZWEgaGVpZ2h0IGNhbGN1bGF0aW9uIHN0YXJ0IGZyb20gdGhlIHNlcmllcyB0aGF0IGV4aXN0LlxyXG4gICAgICogcGFyYW0gIHtBcnJheTxJRDNEYXRhRGF0YT59IGRhdGEgICBbZGF0YSBhZnRlciBtYXNzYWdlXVxyXG4gICAgICogcGFyYW0gIHtudW1iZXJ9ICAgICAgICAgICAgIHhJbmRleCBbaW5kZXggb2YgZGF0YV1cclxuICAgICAqIHBhcmFtICB7bnVtYmVyfSAgICAgICAgICAgICB5SW5kZXggW2luZGV4IG9mIHNlcmllc11cclxuICAgICAqIHBhcmFtICB7bnVtYmVyfSAgICAgICAgICAgICBhZGp1c3QgW2hvdyBtdWNoIHBvaW50IHRvIGJlIGJyaW5nIGRvd24gKHByZXZpb3VzKV1cclxuICAgICAqIHJldHVybiB7bnVtYmVyfSAgICAgICAgICAgICAgICAgICAgW3JldHVybiBhY2N1bXVsYXRlIGFkanVzdG1lbnQgcG9pbnRdXHJcbiAgICAgKi9cclxuICAgIHByaXZhdGUgX2dldE51bGxIZWlnaHRWYWx1ZShfZGF0YTogQXJyYXk8SUQzRGF0YURhdGE+LCBfeEluZGV4OiBudW1iZXIsIF95SW5kZXg6IG51bWJlcik6IG51bWJlciB7XHJcbiAgICAgICAgbGV0IGN1cnJlbnRWYWw6IG51bWJlciA9IF9kYXRhW194SW5kZXhdLnlbX3lJbmRleF0udmFsdWU7XHJcblxyXG4gICAgICAgIGxldCBpc0Rpc2FwcGVhcmluZzogYm9vbGVhbiA9IGZhbHNlO1xyXG5cclxuICAgICAgICBsZXQgaXNTZXJpZXNOdWxsOiBvYmplY3QgPSB0aGlzLl9jaGFydFN2Yy5pc1Nlcmllc051bGwoX2RhdGEsIF94SW5kZXgsIF95SW5kZXgpO1xyXG4gICAgICAgIGxldCBpc1ByZXZOdWxsOiBib29sZWFuID0gaXNTZXJpZXNOdWxsWydpc1ByZXZOdWxsJ107XHJcbiAgICAgICAgbGV0IGlzU2lkZXNOdWxsOiBib29sZWFuID0gaXNTZXJpZXNOdWxsWydpc05leHROdWxsJ10gJiYgKF94SW5kZXggPCAxIHx8IGlzUHJldk51bGwpO1xyXG4gICAgICAgIGlmIChfeEluZGV4ID4gMCkge1xyXG4gICAgICAgICAgICBsZXQgY2hlY2tTZXJpZXM6IG9iamVjdCA9IHRoaXMuX2NoYXJ0U3ZjLmlzU2VyaWVzTnVsbChfZGF0YSwgKF94SW5kZXggLSAxKSwgX3lJbmRleCk7XHJcbiAgICAgICAgICAgIGlzRGlzYXBwZWFyaW5nID0gY2hlY2tTZXJpZXNbJ2lzRGlzYXBwZWFyaW5nJ107XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICBpZiAoY3VycmVudFZhbCA9PT0gbnVsbCB8fCBpc1NpZGVzTnVsbCB8fCBpc1ByZXZOdWxsIHx8IGlzRGlzYXBwZWFyaW5nKSB7XHJcbiAgICAgICAgICAgIHJldHVybiBjdXJyZW50VmFsO1xyXG4gICAgICAgIH1cclxuICAgICAgICByZXR1cm4gMDtcclxuICAgIH1cclxuXHJcbiAgICAvKipcclxuICAgICAqIGNoZWNrIGlmIHRoZSBzZXJpZXMgYXBwZWFyaW5nIG9yIGRpc2FwcGVhcmluZywgYWRqdXN0IHRoZSBwb3NpdGlvbiBvZiB0aGUgbGluZSBhcmVhIChzdGFnZSB1cC9kb3duKVxyXG4gICAgICpcclxuICAgICAqIGFwcGVhcmluZyBpcyByZWZlcnJpbmcgdG86IHRoZXJlIGlzIGEgbnVsbCBvbiBwcmV2aW91cyB4IGF4aXMgYnV0IG5vdCBudWxsIG9uIGN1cnJlbnQgYW5kIGFmdGVyXHJcbiAgICAgKlxyXG4gICAgICogZGlzYXBwZXJpbmcgaXMgcmVmZXJyaW5nIHRvOiB0aGVyZSBpcyBhIHZhbHVlIG9uIHByZXZpb3VzIGFuZCBjdXJyZW50IHggYXhpcyBidXQgbnVsbCBhZnRlclxyXG4gICAgICpcclxuICAgICAqIHBhcmFtICB7QXJyYXk8SUQzRGF0YURhdGE+fSBkYXRhICAgW2RhdGEgYWZ0ZXIgbWFzc2FnZV1cclxuICAgICAqIHBhcmFtICB7bnVtYmVyfSAgICAgICAgICAgICB4SW5kZXggW2luZGV4IG9mIGRhdGFdXHJcbiAgICAgKiBwYXJhbSAge251bWJlcn0gICAgICAgICAgICAgeUluZGV4IFtpbmRleCBvZiBzZXJpZXNdXHJcbiAgICAgKiBwYXJhbSAge29iamVjdH0gICAgICAgICAgICAgYWRqdXN0IFtoZWlnaHQgdG8gcHVsbCBkb3duIHNlcmllcyAoaWYgcHJldmlvdXMgc2VyaWVzIGhhcyBudWxsKSBvciBicmluZyB1cF1cclxuICAgICAqIHJldHVybiB7SURhdGFWYWx1ZX0gICAgICAgICAgICAgICAgW2QzIGRyYXcgcGF0aCBkYXRhIHN0cnVjdHVyZToge3gsIHksIHkwLCB2YWxpZH1dXHJcbiAgICAgKi9cclxuICAgIHByaXZhdGUgX2dldFNwbGl0UGF0aERhdGEoX2RhdGE6IEFycmF5PElEM0RhdGFEYXRhPiwgX3hJbmRleDogbnVtYmVyLCBfeUluZGV4OiBudW1iZXIsIF9hZGp1c3Q6IElBZGp1c3QpOiBJRGF0YVZhbHVlIHtcclxuXHJcbiAgICAgICAgbGV0IGN1cnJlbnRWYWx1ZTogbnVtYmVyID0gX2RhdGFbX3hJbmRleF0ueVtfeUluZGV4XS52YWx1ZTtcclxuXHJcbiAgICAgICAgbGV0IHNwbGl0OiBib29sZWFuID0gZmFsc2U7XHJcbiAgICAgICAgbGV0IHk6IG51bWJlciA9IF9kYXRhW194SW5kZXhdLnlbX3lJbmRleF0uc3VtICsgKF9hZGp1c3RbX3hJbmRleF0gfHwgMCk7XHJcbiAgICAgICAgbGV0IHg6IHN0cmluZyA9IF9kYXRhW194SW5kZXhdLngudmFsdWU7XHJcbiAgICAgICAgbGV0IHkwOiBudW1iZXIgPSAwIC0gY3VycmVudFZhbHVlO1xyXG5cclxuICAgICAgICBpZiAoY3VycmVudFZhbHVlID09PSBudWxsKSB7XHJcbiAgICAgICAgICAgIHJldHVybiB7IHg6IHsgdmFsdWU6IHgsIGxhYmVsOiB4IH0sIHk6IHksIHkwOiB5MCwgdmFsaWQ6IHNwbGl0IH07XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICBsZXQgaXNEaXNhcHBlYXJpbmcgPSBfeEluZGV4ID4gMCAmJiBfeEluZGV4IDwgX2RhdGEubGVuZ3RoIC0gMSAmJlxyXG4gICAgICAgICAgICBfZGF0YVtfeEluZGV4ICsgMV0ueVtfeUluZGV4XS52YWx1ZSA9PT0gbnVsbCAmJlxyXG4gICAgICAgICAgICBjdXJyZW50VmFsdWUgIT09IG51bGwgJiYgX2RhdGFbX3hJbmRleCAtIDFdLnlbX3lJbmRleF0udmFsdWUgIT09IG51bGw7XHJcblxyXG4gICAgICAgIGxldCBpc1JlYXBwZWFyaW5nID0gX3hJbmRleCA+IDAgJiYgX3hJbmRleCA8IF9kYXRhLmxlbmd0aCAtIDEgJiZcclxuICAgICAgICAgICAgX2RhdGFbX3hJbmRleCAtIDFdLnlbX3lJbmRleF0udmFsdWUgPT09IG51bGwgJiZcclxuICAgICAgICAgICAgY3VycmVudFZhbHVlICE9PSBudWxsICYmIF9kYXRhW194SW5kZXggKyAxXS55W195SW5kZXhdLnZhbHVlICE9PSBudWxsO1xyXG5cclxuICAgICAgICBpZiAoaXNSZWFwcGVhcmluZykge1xyXG4gICAgICAgICAgICBfYWRqdXN0WydhZGp1c3QnICsgX3hJbmRleF0gPSAoX2FkanVzdFsnYWRqdXN0JyArIF94SW5kZXhdIHx8IDApICsgY3VycmVudFZhbHVlO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgaWYgKGlzRGlzYXBwZWFyaW5nKSB7XHJcbiAgICAgICAgICAgIF9hZGp1c3RbJ2FkanVzdCcgKyBfeEluZGV4XSA9IChfYWRqdXN0WydhZGp1c3QnICsgX3hJbmRleF0gfHwgMCkgLSBjdXJyZW50VmFsdWU7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICBpZiAoY3VycmVudFZhbHVlICE9PSBudWxsICYmIF9hZGp1c3RbJ2FkanVzdCcgKyBfeEluZGV4XSkge1xyXG4gICAgICAgICAgICB5ID0geSArIF9hZGp1c3RbJ2FkanVzdCcgKyBfeEluZGV4XTtcclxuICAgICAgICAgICAgeTAgPSB5MCArIHk7XHJcbiAgICAgICAgICAgIHNwbGl0ID0gdHJ1ZTtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIHJldHVybiB7IHg6IHsgdmFsdWU6IHgsIGxhYmVsOiB4IH0sIHk6IHksIHkwOiB5MCwgdmFsaWQ6IHNwbGl0IH07XHJcbiAgICB9XHJcbn1cclxuIl19