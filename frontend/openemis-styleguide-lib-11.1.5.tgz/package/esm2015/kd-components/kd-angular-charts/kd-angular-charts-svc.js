import { Injectable } from '@angular/core';
import { KdDomElemSvc } from '../kd-common/index';
import * as d3 from 'd3';
import * as helper from './helper-svc/index';
export class KdChartsSvc {
    constructor(_domSvc) {
        this._domSvc = _domSvc;
        this._isInvert = false;
        this._isRotate = false;
        this._isRtl = false;
        this._defaultSvgMargin = {
            top: 20,
            x: 9,
            y: 12,
            oppVert: 20
        };
        this._svgMargin = {
            top: 0,
            right: 0,
            bottom: 0,
            left: 0
        };
        this._yAxisLabelWidth = {
            axisMax: 0,
            axisMin: 0
        };
        this._minXSpacing = 50;
        this._axisD3Format = '';
        this._isXReversed = false;
        this._isYReversed = false;
        this.dataLabelPushDownRange = 0;
        this._isNegativeStack = false;
        this.gridSvc = new helper.KdChartsGridSvc(this._config);
        this.tooltipSvc = new helper.KdChartsTooltipSvc();
    }
    set config(_config) {
        this._config = _config;
        this.gridSvc.config = _config;
    }
    get config() { return this._config; }
    set svg(_svg) { this._svg = _svg; }
    set svgRect(_svgRect) { this._svgRect = _svgRect; }
    set chartType(_chartType) { this._chartType = _chartType; }
    set chartCategory(_chartCategory) { this._chartCategory = _chartCategory; }
    set isInvert(_isInvert) {
        this._isInvert = _isInvert;
        this.gridSvc.isInvert = _isInvert;
    }
    set svgParentRect(_svgParentRect) { this._svgParentRect = _svgParentRect; }
    set isRotate(_isRotate) { this._isRotate = _isRotate; }
    get isRotate() { return this._isRotate; }
    set labelLength(_labelLength) { this._labelLength = _labelLength; }
    get labelLength() { return this._labelLength; }
    get svgMargin() { return this._svgMargin; }
    set xScaleType(_xScaleType) { this._xScaleType = _xScaleType; }
    get xScaleType() { return this._xScaleType; }
    get xSpacing() { return this._xSpacing; }
    get axisD3Format() { return this._axisD3Format; }
    get yAxisLabelWidth() { return this._yAxisLabelWidth; }
    set isRtl(_isRtl) { this._isRtl = _isRtl; }
    set isXReversed(_isXReversed) {
        if (!this._isInvert) {
            this._isXReversed = _isXReversed !== this._isRtl;
        }
        else {
            this._isXReversed = _isXReversed;
        }
    }
    get isXReversed() { return this._isXReversed; }
    set isYReversed(_isYReversed) {
        if (this._isInvert) {
            this._isYReversed = _isYReversed !== this._isRtl;
        }
        else {
            this._isYReversed = _isYReversed;
        }
    }
    get isYReversed() { return this._isYReversed; }
    set isNegativeStack(_isNegativeStack) { this._isNegativeStack = _isNegativeStack; }
    get isNegativeStack() { return this._isNegativeStack; }
    // ================================= Vertical Axis ==================================
    /**
     * for rotating vertical axis. if axis is enabled, appends class-name 'rotate-title' to kd charts.
     * param  {Array<string>} _type   chart type: if horizontal bar, use xAxis's(the vertical axis) config
     * param  {any}           _config
     * return {boolean}
     */
    checkRotateTitleEnabled(_type, _config) {
        let axisConfig = _type[0] === 'bar' ? _config.xAxis : _config.yAxis;
        return axisConfig.enabled && axisConfig.title.text !== '';
    }
    setVertAxisAndChartMargin(_id) {
        let chartContainer = document.querySelector('#' + _id + '.kdx-charts .kdx-chart-container');
        let axisConfig = this._isInvert ? this._config.xAxis : this._config.yAxis;
        // setting css for vertical axis
        if (axisConfig.enabled && axisConfig.title.text !== '') {
            let currAxisTitleClass = this._isInvert ? '.kdx-charts-axis-title-x' : '.kdx-charts-axis-title-y';
            this._currVertAxisTitle = document.querySelector('#' + _id + '.kdx-charts ' + currAxisTitleClass + '.kdx-charts-axis-title');
        }
        else {
            this._currVertAxisTitle = null;
        }
        this.setChartContainerMargin(chartContainer);
    }
    repositionVerticalAxisTitle() {
        if (!this.isValueExist(this._currVertAxisTitle))
            return;
        let axisTitleClass = this._isInvert ? '.kdx-charts-axis-title-x' : '.kdx-charts-axis-title-y';
        let axisTitleTextArr = document.querySelectorAll('#' + this._config.id + '.kdx-charts ' + axisTitleClass + ' .kdx-charts-axis-title-text');
        axisTitleTextArr.forEach(axisTitleText => {
            axisTitleText.style.top = this._currVertAxisTitle.getBoundingClientRect().height / 2 + axisTitleText.getBoundingClientRect().height / 2 + 'px';
            axisTitleText.style.visibility = 'unset';
        });
    }
    // ================================= Y Axis Label ==================================
    setMaxAndMin(_yAxisConfig, _dataRange) {
        let maxValue = this.isValueExist(_yAxisConfig.maxValue) ? _yAxisConfig.maxValue : _dataRange.max;
        let minValue = this.isValueExist(_yAxisConfig.minValue) ? _yAxisConfig.minValue : _dataRange.min;
        // ensure that min value will not exceed max, vice verse
        maxValue = Math.max(maxValue, minValue);
        minValue = Math.min(maxValue, minValue);
        let interval = d3.max([_yAxisConfig.tickInterval, _yAxisConfig.minorTickInterval]);
        if (!interval || interval <= 0)
            interval = 1;
        // to prevent tick calculation causing stop-script, only allow at most around 1000 ticks (excluding first tick)
        let smallestPossibleInterval = (maxValue - minValue) / 1000;
        if (smallestPossibleInterval > interval) {
            interval = this.isInterger(interval) ? Math.floor(smallestPossibleInterval) : smallestPossibleInterval;
        }
        return {
            maxValue: maxValue,
            minValue: minValue,
            interval: interval
        };
    }
    setAxisD3Format(_interval) {
        let decimalPlace = this.findDecimalPlace(_interval);
        this._axisD3Format = this.getD3Format(_interval, decimalPlace);
    }
    getYAxisLabelText(_yAxisConfig, _value) {
        return this.getLabelText(_yAxisConfig.labels.format, _value, false, this._axisD3Format);
    }
    /**
     * Y axis label dummy. appends text element to svg and returns the width of label
     * param  {number |      string}      _value: label's value
     * param  {string}                    _class: class name for dummy
     * return {number}                    returns actual rendered width of label
     */
    setDummyAxisLabel(_value, _class) {
        // if (!this._config.yAxis.enabled) return 0;
        let yAxisConfig = this._config.yAxis;
        // if axis is enabled, draw axisMax string and axisMin string to compute this.width/height
        let textSelection = this._svg.selectAll('.dummy-' + _class);
        let text = this.getYAxisLabelText(yAxisConfig, _value);
        // element should only be appended once
        if (textSelection.empty())
            textSelection = this._svg.append('text');
        this.setSvgAttribute(textSelection, Object.assign({}, yAxisConfig.labels.style, { class: 'kdx-charts-dummy dummy-' + _class, opacity: 0 }));
        textSelection.text(text);
        return textSelection.node().getBBox().width;
    }
    /**
     * chart width and height have to be calculated based on how long y axis labels are (eg: a lot of space allocated for 1,000,000 as compared to 10)
     * returns this.width or this.height depending on _axis given
     * param  {'x'|'y'}         _axis
     * param  { axisMax: number, axisMin: number } _axisVal
     * return {number}
     */
    getSvgOffset(_axis, _axisVal) {
        let axisOpposite = _axis === 'x' ? this._config.yAxis.opposite : this._config.xAxis.opposite;
        let opposite = axisOpposite !== this._isRtl;
        let yAxisLabelsNotVisible = !this._config.yAxis.enabled || !this._config.yAxis.labels.enabled;
        if (_axis === 'x')
            this._yAxisLabelWidth = this.getYAxisMaxAndMinLabelWidth(_axisVal);
        let internalYAxisLabelWidth = this._yAxisLabelWidth;
        if (yAxisLabelsNotVisible)
            internalYAxisLabelWidth = { axisMax: 0, axisMin: 0 };
        if (!this._isInvert) {
            if (_axis === 'x') {
                let start = opposite ? 'right' : 'left';
                let end = opposite ? 'left' : 'right';
                this._svgMargin[start] = this._defaultSvgMargin.y + Math.max(internalYAxisLabelWidth.axisMax, internalYAxisLabelWidth.axisMin);
                this._svgMargin[end] = this._defaultSvgMargin.oppVert;
                return this._svgRect.width - this._svgMargin[start] - this._svgMargin[end];
            }
            else {
                let start = axisOpposite ? 'bottom' : 'top';
                let end = axisOpposite ? 'top' : 'bottom';
                let labelFontSize = yAxisLabelsNotVisible ? 0 : this.replaceStringWithNumber(this._config.yAxis.labels.style.fontSize);
                this._svgMargin[end] = Math.max(this._defaultSvgMargin.x, 0.5 * labelFontSize);
                this._svgMargin[start] = this.isNegativeStack ? this._svgMargin[end] : this._defaultSvgMargin.top;
                return this._svgRect.height - this._svgMargin[start] - this._svgMargin[end];
            }
        }
        else {
            if (_axis === 'x') {
                let start = axisOpposite ? 'bottom' : 'top';
                let end = axisOpposite ? 'top' : 'bottom';
                let labelFontSize = yAxisLabelsNotVisible ? 0 : this.replaceStringWithNumber(this._config.yAxis.labels.style.fontSize);
                this._svgMargin[start] = this._defaultSvgMargin.top;
                this._svgMargin[end] = this._defaultSvgMargin.y + labelFontSize;
                return this._svgRect.height - this._svgMargin[start] - this._svgMargin[end];
            }
            else {
                let start = opposite ? 'right' : 'left';
                let end = opposite ? 'left' : 'right';
                let startLabelWidth = opposite === this.isYReversed ? internalYAxisLabelWidth.axisMin : internalYAxisLabelWidth.axisMax;
                let endLabelWidth = opposite === this.isYReversed ? internalYAxisLabelWidth.axisMax : internalYAxisLabelWidth.axisMin;
                this._svgMargin[start] = Math.max(this._defaultSvgMargin.x, startLabelWidth / 2);
                this._svgMargin[end] = this.isNegativeStack ? Math.max(this._defaultSvgMargin.x, endLabelWidth / 2) : endLabelWidth / 2 + this._defaultSvgMargin.oppVert;
                return this._svgRect.width - this._svgMargin[start] - this._svgMargin[end];
            }
        }
    }
    /**
     * round axisMax/Min value to interval (eg: Max value is 10 but interval is 3, so max value will be rounded to either 9 or 12)
     * _isAutoRoundToNextInterval is enabled, round to 12
     * _isAutoRoundToNextInterval is disabled, round to 9
     *
     * param  {number}  _value
     * param  {number}  _interval
     * param  {boolean} _isAutoRoundToNextInterval
     * param  {'up' | 'down'}      _roundDir
     * return {number}
     */
    setAxisRoundValue(_value, _interval, _isAutoRoundToNextInterval, _roundDir) {
        // if value is 0, don't round
        if (_value === 0)
            return _value;
        let decimalPlaces = Math.max(this.findDecimalPlace(_value), this.findDecimalPlace(_interval));
        if (decimalPlaces !== 0) {
            // if _value or _interval have decimal, convert them to whole numbers
            _value = _value * Math.pow(10, decimalPlaces);
            _interval = _interval * Math.pow(10, decimalPlaces);
        }
        let sign = Math.sign(_value);
        let newValue = _value - _value % _interval;
        if (_roundDir === 'up') {
            if (sign < 0) {
                if (!_isAutoRoundToNextInterval)
                    newValue = newValue - _interval;
            }
            else {
                if (_isAutoRoundToNextInterval)
                    newValue = newValue + _interval;
            }
        }
        else {
            if (sign < 0) {
                if (_isAutoRoundToNextInterval)
                    newValue = newValue - _interval;
            }
            else {
                if (!_isAutoRoundToNextInterval)
                    newValue = newValue + _interval;
            }
        }
        if (decimalPlaces !== 0)
            newValue = newValue / Math.pow(10, decimalPlaces);
        return newValue;
    }
    getTickValues(_min, _max, _interval) {
        if (!_interval || typeof _min === 'undefined' || typeof _max === 'undefined')
            return [];
        _max = this._getUpperBoundForTickValues(_max, _interval);
        return d3.range(_min, _max, _interval);
    }
    /**
     * set Y axis Label Config
     * param {any}        _axis is Element/d3-selection
     * param {'xAxis' | 'yAxis'}     _direction
     */
    setAxisLabelConfig(_axis, _direction) {
        let axisDir = _direction + 'Axis';
        if (!this._config[axisDir])
            return;
        let axisConfig = this._config[axisDir];
        _axis.selectAll('path')
            .attr('stroke-width', axisConfig.lineWidth)
            .attr('stroke', axisConfig.lineColor);
        _axis.selectAll('line')
            .attr('stroke-width', axisConfig.lineWidth)
            .attr('stroke', axisConfig.lineColor);
        if (_direction === 'x' || !axisConfig.enabled || !this._config[axisDir].labels.enabled) {
            this.setSvgAttribute(_axis.selectAll('text'), { display: 'none' });
        }
        else {
            this.setSvgAttribute(_axis.selectAll('text'), axisConfig.labels.style);
            this.setSvgAttribute(_axis.selectAll('text'), { class: 'kdx-charts-display-number-inside-svg kdx-charts-display-number' });
        }
    }
    getYAxisMaxAndMinLabelWidth(_axisVal) {
        let widthObj = { axisMax: 0, axisMin: 0 };
        // if (this._config.yAxis.labels.enabled) {
        widthObj.axisMax = this.setDummyAxisLabel(_axisVal.axisMax, 'axisMax');
        widthObj.axisMin = this.setDummyAxisLabel(_axisVal.axisMin, 'axisMin');
        // }
        return widthObj;
    }
    _getUpperBoundForTickValues(_max, _interval) {
        let decimalPlaces = Math.max(this.findDecimalPlace(_max), this.findDecimalPlace(_interval));
        _max = _max * Math.pow(10, decimalPlaces);
        _interval = _interval * Math.pow(10, decimalPlaces);
        return (_max + _interval) / Math.pow(10, decimalPlaces);
    }
    // ================================= X Axis Label ==================================
    /**
     * set axis Label Container (currently only used for X axis)
     * param  {number} _xSpacing
     * param  {string} _extraClassName [same level as .kdx-charts-axis-label-container. Additional className in case of doubleAxis]
     * return {any}
     */
    setAxisLabelContainer(_extraClassName = '') {
        this._axisLabelContainer = d3.select('#' + this._config.id + '.kdx-charts .kdx-charts-axis-label-container' + _extraClassName);
        if (!this.isValueExist(this._axisLabelContainer.node()))
            return;
        return this._axisLabelContainer;
    }
    /**** Axis Label Dummy *******/
    setAxisLabelDummy(_id, _xSpacing, _longestText) {
        this._setAxisLabelDummyElement(_id);
        this.setAxisLabelDummyText(_longestText);
        this.isRotate = this._checkRotate(this._isInvert, _xSpacing, this._minXSpacing);
        this._setAxisLabelDummyStyle(_xSpacing);
    }
    setAxisLabelDummyText(_longestText) {
        if (!this._axisLabelDummy)
            return;
        _longestText = this.getLabelFormatReplace(this.config.xAxis.labels.format, _longestText);
        this._setAxisLabelDummyHtml(_longestText);
    }
    getAxisLabelDummyRect() {
        if (!this._axisLabelDummy)
            return 0;
        return this._axisLabelDummy.getBoundingClientRect();
    }
    _setAxisLabelDummyElement(_id) {
        if (typeof this._axisLabelDummy === 'undefined') {
            this._axisLabelDummy = document.querySelector('#' + _id + '.kdx-charts .kdx-charts-invisible-axis-label');
        }
    }
    _setAxisLabelDummyHtml(_text) {
        if (!this._axisLabelDummy)
            return;
        this._axisLabelDummy.innerHTML = _text;
    }
    _setAxisLabelDummyStyle(_xSpacing) {
        if (!this._isInvert && !this.isRotate) {
            this._axisLabelDummy.style.maxWidth = _xSpacing + 'px';
        }
    }
    /**** Others *******/
    _checkRotate(_isInvert, _xSpacing, _minXSpacing) {
        // if each bar/xSpacing has at least 50 px, do not rotate, let the label word-wrap
        if (_xSpacing >= _minXSpacing || _isInvert)
            return false;
        // rotate only if xSpacing < 50px AND the actual text(with paddding) length > each bar/xSpacing
        return this.getAxisLabelDummyRect().width > _xSpacing;
    }
    _setAxisLabelLength() {
        let longestLength = this.getAxisLabelDummyRect().width || 0, svgParentRect = this._svgParentRect, svgLength = (this._isInvert ? svgParentRect.width : svgParentRect.height) || 0, labelLength = Math.min(longestLength, 0.3 * svgLength);
        this._labelLength = labelLength;
    }
    _getAxisMargin(_isInvert, _isRotate) {
        let axisMargin = { top: 0, left: 0, right: 0 };
        let opposite = this._config.yAxis.opposite || false;
        if (!_isInvert) {
            let titleWidth = 0;
            let side = this._isRtl ? 'right' : 'left';
            let sign = this._isRtl ? -1 : 1;
            opposite = opposite !== this._isRtl;
            if (!opposite && this.isValueExist(this._currVertAxisTitle)) {
                titleWidth = this._currVertAxisTitle.getBoundingClientRect().width;
            }
            axisMargin[side] = sign * (this._svgMargin.left + titleWidth);
        }
        else {
            axisMargin.top = this._svgMargin.top;
            if (opposite)
                axisMargin.top += this._getHorizTitleHeight();
            axisMargin.right = 2;
        }
        return axisMargin;
    }
    setAxisLabelContainerStyle(_container) {
        let styleType = this._isInvert ? 'width' : 'height';
        let styleVal = this.labelLength;
        if (!this._isInvert && !this.isRotate) {
            styleVal = this.getAxisLabelDummyRect().height;
        }
        _container.style(styleType, styleVal + 'px');
        if (!this._isInvert)
            _container.style('width', '100%');
        this._axisLabelDummy.style.maxWidth = '100%';
        let margin = this._getAxisMargin(this._isInvert, this.isRotate);
        _container
            .style('margin-top', margin.top + 'px')
            .style('margin-right', margin.right + 'px')
            .style('margin-left', margin.left + 'px');
        this._axisLabelContainerMarginLeft = margin.left;
    }
    /**
     * set X axis Label Position
     * param {any}     _labelContainer
     * param {number}  _tickPos
     * param {IAxisLabelBooleanChecks} _booleanChecks
     */
    setAxisLabelPosition(_labelContainer, _tickPos, _booleanChecks) {
        if (this._isInvert || _booleanChecks.isRotate || (_booleanChecks.isLast && this._xScaleType === 'string')) {
            this._domSvc.addClass(_labelContainer.node(), 'ellipsis');
        }
        // when rotating, there shouldn't be any padding(.kdx-charts-child-padding-both) or 'special' padding (.kdx-charts-child-special-padding)
        // must execute before offset position
        if (_booleanChecks.isRotate)
            _labelContainer.style('padding', 0);
        let labelRect = _labelContainer.node().getBoundingClientRect(), offset = !this._isInvert && !_booleanChecks.isRotate ? labelRect.width / 2 : labelRect.height / 2, offSetSign = _booleanChecks.isRotate && _booleanChecks.opposite ? -1 : 1, position = _tickPos - offset * offSetSign;
        // for horizontal bar
        if (this._isInvert) {
            let horizDir = this._isRtl !== _booleanChecks.opposite ? 'left' : 'right';
            _labelContainer
                .style('top', position + 'px')
                .style(horizDir, 0 + 'px');
            return;
        }
        let vertDir = _booleanChecks.opposite ? 'bottom' : 'top';
        // for all other axis charts
        if (_booleanChecks.isRotate) {
            let vertDist = _booleanChecks.isRotate && !_booleanChecks.opposite ? labelRect.width : 0;
            _labelContainer
                .style(vertDir, vertDist + 'px')
                .style('transform', 'rotate(-90deg)');
        }
        else {
            if (this._xScaleType === 'string') {
                // when position is negative and it's absolute value is more than the margin of axisLabelContainer
                if (position + this._axisLabelContainerMarginLeft < 0) {
                    let diff = Math.abs(position) - this._axisLabelContainerMarginLeft;
                    _labelContainer.style('max-width', (labelRect.width - 2 * diff) + 'px');
                    position = -1 * this._axisLabelContainerMarginLeft;
                }
                if (_booleanChecks.isLast)
                    _labelContainer.style('max-width', (labelRect.width / 2 + this._svgMargin.right) + 'px');
            }
            _labelContainer.style(vertDir, 0 + 'px');
        }
        _labelContainer.style('left', position + 'px');
    }
    // ================================= Data Labels ==================================
    /**
     * data labels have to be repositioned according to title and axis Labels's width and position
     * param {any} _dataLabelContainer d3-selection
     * param {any} _axisLabelContainer d3-selection
     */
    repositionDataLabel(_dataLabelContainer, _axisLabelContainer) {
        let axisLabelContainerRect = this.isValueExist(_axisLabelContainer) ? _axisLabelContainer.node().getBoundingClientRect() : { width: 0, height: 0 };
        let left = this._calculateDataLabelLeft(axisLabelContainerRect.width);
        let top = this._calculateDataLabelTop(axisLabelContainerRect.height);
        _dataLabelContainer
            .style('left', left + 'px')
            .style('top', top + 'px');
    }
    _calculateDataLabelLeft(_labelWidth) {
        let opposite = this._isInvert ? this._config.xAxis.opposite : this._config.yAxis.opposite;
        let chartMarginLeft = this._config.chart.margin.left;
        // when vertical axis on right (only one axis), left side have no axis
        // NOTE: do not run this step when column/bar-stack-negative, since both left and right side have vertical axis
        if (opposite !== this._isRtl && !this.isNegativeStack) {
            return this._svgMargin.left + this.replaceStringWithNumber(chartMarginLeft);
        }
        // when vertical axis on left
        let titleWidth = this.isValueExist(this._currVertAxisTitle) ? this._currVertAxisTitle.getBoundingClientRect().width : 0;
        let left = this.replaceStringWithNumber(chartMarginLeft);
        left += this._isInvert ? titleWidth + _labelWidth + this._svgMargin.left + 2 : titleWidth + this._svgMargin.left;
        return left;
    }
    _calculateDataLabelTop(_labelHeight) {
        let opposite = this._isInvert ? this._config.yAxis.opposite : this._config.xAxis.opposite;
        // when horizontal axis is at bottom
        // NOTE: do not run this step when column/bar-stack-negative, since both above and below have horizontal axis
        if (!opposite && !this.isNegativeStack) {
            return this._svgMargin.top + this.replaceStringWithNumber(this._config.chart.margin.top);
        }
        // when horizontal axis on top
        let horizTitleHeight = this._getHorizTitleHeight();
        let top = this.replaceStringWithNumber(this._config.chart.margin.top);
        top += this._isInvert ? horizTitleHeight + this._svgMargin.top : horizTitleHeight + this._svgMargin.top + _labelHeight;
        return top;
    }
    _getHorizTitleHeight() {
        let className = '#' + this._config.id + '.kdx-charts .kdx-charts-axis-title';
        className += this._isInvert ? '-y' : '-x';
        let horizTitleElement = document.querySelector(className);
        return this.isValueExist(horizTitleElement) ? horizTitleElement.getBoundingClientRect().height : 0;
    }
    /****Vertical Align*****/
    _getLabelTextHeight() {
        let labelStyle = this._config.chart.labels.style;
        let fontSize = this.replaceStringWithNumber(labelStyle.fontSize);
        let borderWidth = this.replaceStringWithNumber(labelStyle.borderWidth);
        return fontSize * 1.3 + borderWidth * 2;
    }
    _checkBoundary(_type, _yPosition, _chartHeight, _dotSize = 0) {
        let textSize = this._getLabelTextHeight() + _dotSize / 2;
        if (_type === 'max') {
            return _yPosition - textSize < this.dataLabelPushDownRange;
        }
        else {
            return _yPosition + textSize > _chartHeight - this.dataLabelPushDownRange;
        }
    }
    needOffsetForColumn(_verticalAlign, _params = {}) {
        if (!_params.dimensions)
            return false;
        if (_params.valueSign < 0) {
            if (_verticalAlign === 'top')
                return -1; // needs offset, returning true condition
        }
        else {
            if (_verticalAlign === 'bottom')
                return 1; // needs offset, returning true condition
        }
        return false;
    }
    // NOTE: data label vertical align is not defined in default config (as of v3.7.0 becos behaviour changes with different chart types)
    getDefaultVerticalAlign(_config, _params) {
        if (_config.chart.labels.verticalAlign)
            return _config.chart.labels.verticalAlign;
        let defaultValue = 'top';
        // for column, negative values need to be placed on bottom
        if (_params.valueSign < 0)
            defaultValue = 'bottom';
        return defaultValue;
    }
    // ================================= General ==================================
    /**
     * in arabic, numbers are in ltr mode (eg: negative sign is typed first)
     * Hence wrapping a div around number (only) with className '.kdx-charts-display-number' to force direction: ltr
     * param  {number} _number
     * return {string}
     */
    wrapNumberInInlineDiv(_number) {
        return '<div class="kdx-charts-display-number" style="display: inline-block;" dir="ltr">' + _number + '</div>';
    }
    replaceStringWithNumber(_value) {
        if (typeof _value === 'number')
            return _value;
        return parseFloat(_value.replace(/[^0-9.]/g, ''));
    }
    getForLoopSequence(_chartType) {
        return _chartType[0] !== 'bar' && (_chartType[1] === 'stack' || _chartType[1] === '100') ? 'descending' : 'ascending';
    }
    getForLoopInfo(_type, arrLength) {
        return {
            start: _type === 'ascending' ? 0 : arrLength - 1,
            end: _type === 'ascending' ? arrLength : -1,
            check: _type === 'ascending' ? (i, end) => i < end : (i, end) => i > end,
            iterate: _type === 'ascending' ? (i) => i + 1 : (i) => i - 1,
        };
    }
    getXInfo(_data, _config) {
        let xInfo = {
            value: [],
            longestText: ''
        };
        let longestTextWidth = 0;
        let showValueInLabel = _config.xAxis.labels.format.indexOf('{value}') > -1 && _config.xAxis.enabled && _config.xAxis.labels.enabled;
        if (showValueInLabel)
            this._setAxisLabelDummyElement(_config.id);
        _data.forEach(d => {
            xInfo.value.push(d.x.value);
            // if no value needs to be showed in label, then no need check longest text
            if (showValueInLabel) {
                this._setAxisLabelDummyHtml(d.x.label);
                let currentWidth = this.getAxisLabelDummyRect().width;
                if (currentWidth > longestTextWidth) {
                    longestTextWidth = currentWidth;
                    xInfo.longestText = d.x.label;
                }
            }
        });
        return xInfo;
    }
    checkAndReturnLabelsPositive(_value) {
        if (this.isNegativeStack) {
            let plotOptions = this.config.plotOptions;
            if (plotOptions && plotOptions.bar && typeof plotOptions.bar.allLabelsPositive !== 'undefined') {
                return this.config.plotOptions.bar.allLabelsPositive ? Math.abs(_value) : _value;
            }
            return Math.abs(_value);
        }
        return _value;
    }
    findDecimalPlace(_number) {
        if (parseInt(_number.toString()) === _number)
            return 0;
        let result = 0;
        let stringForm = Math.abs(_number).toString();
        let splitByDot = stringForm.split('.');
        if (stringForm.indexOf('e') < 0) {
            result = splitByDot[1].length;
        }
        else {
            result = parseInt(stringForm.split('e-')[1]);
            if (typeof splitByDot[1] !== 'undefined')
                result += splitByDot[1].length;
        }
        return result;
    }
    getLabelText(_format, _value, _isHTML = true, _d3Format) {
        let d3Format = typeof _d3Format === 'undefined' ? this.getD3Format(_value) : _d3Format;
        let text = this.changeValueToD3Format(_value, d3Format);
        if (_isHTML)
            text = this.wrapNumberInInlineDiv(text);
        return this.getLabelFormatReplace(_format, text);
    }
    getLabelFormatReplace(_format, _text) {
        return _format.replace(/{value}/g, _text);
    }
    isInterger(_value) {
        return typeof _value === 'number' && (_value % 1) === 0;
    }
    getD3Format(_value, _toDecimalPlace) {
        if (typeof _value === 'string')
            return '';
        if (Math.abs(_value) > 10000000)
            return '.2e';
        if (this.isInterger(_value)) {
            return ',';
        }
        else {
            // is decimal
            if (Math.abs(_value) < 0.00000001)
                return '.2e';
            if (typeof _toDecimalPlace !== 'undefined' && _toDecimalPlace !== 0) {
                // if precision is given
                return '.' + _toDecimalPlace.toString() + 'f';
            }
        }
        return '';
    }
    changeValueToD3Format(_value, _format) {
        if (typeof _value === 'string')
            return _value;
        return d3.format(_format)(_value);
    }
    getLongerNumber(_num1, _num2) {
        return _num1.toString().length > _num2.toString().length ? _num1 : _num2;
    }
    setChartContainerMargin(_chartContainer) {
        let margin = this._config.chart.margin;
        _chartContainer.style.padding = margin.top + ' ' + margin.right + ' ' + margin.bottom + ' ' + margin.left;
    }
    transformGraphContainer(_container) {
        _container.attr('transform', 'translate(' + this._svgMargin.left + ',' + this._svgMargin.top + ')');
    }
    setSvgAttribute(_element, _config) {
        for (let key in _config) {
            if (!this.isValueExist(_config[key]))
                continue;
            let attributeStr = key === 'color' ? 'fill' : key.replace(/([a-zA-Z])(?=[A-Z])/g, '$1-').toLowerCase();
            _element.attr(attributeStr, _config[key]);
        }
    }
    isExist(_yElem) {
        return (typeof _yElem !== 'undefined' && _yElem !== null && _yElem.value !== null);
    }
    isValueExist(_val) {
        return (typeof _val !== 'undefined' && _val !== null && _val !== '');
    }
    getD3MaxOrMin(_arr, _type) {
        if (_type === 'max')
            return d3.max(_arr);
        if (_type === 'min')
            return d3.min(_arr);
    }
    getAxisTransformPos(_axis, _opposite, _transformPos) {
        if (this._isInvert) {
            if (_axis === 'x') {
                if (_opposite)
                    return _transformPos.right;
                return _transformPos.left;
            }
            if (_axis === 'y') {
                if (_opposite)
                    return _transformPos.top;
                return _transformPos.bottom;
            }
        }
        else {
            if (_axis === 'x') {
                if (_opposite)
                    return _transformPos.top;
                return _transformPos.bottom;
            }
            if (_axis === 'y') {
                if (_opposite)
                    return _transformPos.right;
                return _transformPos.left;
            }
        }
    }
    getLimitedCategories(_initCategories, _xThreshold) {
        if (!_initCategories)
            return [];
        return _xThreshold && _initCategories.length > _xThreshold ? _initCategories.slice(0, _xThreshold) : _initCategories;
    }
    /**
     * return config into css string so can be added into element
     * param  {object}  defaultConfig config
     * param  {boolean} isForTooltip  if tooltip, compare default config with config pass from user
     * return {string}                css styling
     */
    getStyle(defaultConfig, isForTooltip) {
        let config = {};
        if (isForTooltip) {
            config = this._config.tooltip.style;
        }
        let styling = '';
        if (defaultConfig) {
            for (let defaultKey of Object.keys(defaultConfig)) {
                styling += defaultKey.replace(/([a-zA-Z])(?=[A-Z])/g, '$1-').toLowerCase();
                styling += ':';
                styling += (config && config.hasOwnProperty(defaultKey)) ? config[defaultKey] : defaultConfig[defaultKey];
                styling += ';';
            }
        }
        return styling;
    }
    // ================================= Line only ==================================
    /**
     * check if line missing
     * param {[type]} _data        data
     * param {[type]} _dataIndex   xIndex
     * param {[type]} _seriesIndex yIndex / yValueIndex
     */
    isSeriesNull(_data, _dataIndex, _seriesIndex) {
        let currentVal = 0;
        let dataLength = 0;
        let isIChartData = this._isChartData;
        if (isIChartData(_data)) {
            currentVal = _data.series[_seriesIndex].data[_dataIndex].value;
            dataLength = _data.xAxis.categories.length;
        }
        else {
            currentVal = _data[_dataIndex].y[_seriesIndex].value;
            dataLength = _data.length;
        }
        function getValue(when, isNull) {
            let index = 0;
            if (when === 'prev') {
                if (_dataIndex > 0) {
                    index = _dataIndex - 1;
                }
                else {
                    return false;
                }
            }
            else {
                if (_dataIndex < dataLength - 1) {
                    index = _dataIndex + 1;
                }
                else {
                    return false;
                }
            }
            let value = (isIChartData(_data) ? _data.series[_seriesIndex].data[index].value : _data[index].y[_seriesIndex].value);
            if (isNull) {
                return value === null;
            }
            return value !== null;
        }
        let isPrevNull = getValue('prev', true);
        let isPrevNotNull = getValue('prev', false);
        let isNextNull = getValue('next', true);
        let isNextNotNull = getValue('next', false);
        let isAppearing = isNextNotNull && currentVal !== null && isPrevNull;
        let isDisappearing = isNextNull && currentVal !== null && isPrevNotNull;
        return {
            isPrevNull: isPrevNull,
            isPrevNotNull: isPrevNotNull,
            isNextNull: isNextNull,
            isNextNotNull: isNextNotNull,
            isAppearing: isAppearing,
            isDisappearing: isDisappearing
        };
    }
    _isChartData(object) {
        return 'series' in object;
    }
    // ================================= Kd Chart only ==================================
    /**
     * required for percentage calculation of 100 stack. returns a array of total sum of data value of each categories.
     * param  {Array<ISeries>} _seriesArr
     * param  {Array<string>}  _categories
     * return {Array<number>}
     */
    getTotalSumArrFromSeries(_seriesArr, _categories, seriesLength) {
        let sumArr = [];
        for (let i = 0; i < _categories.length; ++i) {
            let sum = 0;
            for (let j = 0; j < seriesLength; ++j) {
                if (typeof _seriesArr[j].data[i] === 'undefined')
                    continue;
                let currentVal = _seriesArr[j].data[i].value;
                if (typeof currentVal === 'undefined')
                    continue;
                sum = (currentVal === null) ? sum : sum + currentVal;
            }
            sumArr.push(sum);
        }
        return sumArr;
    }
    // ================================= Pie only ==================================
    /**
     * check if line missing
     * param {[key: string]: ILegendData} _legendData pie chart legend data
     * param {any} _data pie chart data
     * param {IChartConfig} _config pie chart legend config
     */
    setPieData(_legendData, _data, _config, _seriesThreshold) {
        let pieData = [];
        let pieColor = [];
        let legendId;
        let pieDataArrayLength = 0;
        let configDataArray = Object.keys(_legendData).map(key => _legendData[key]);
        _legendData = {};
        for (let i = 0; i < _data.data.length; i++) {
            for (let j = 0; j < _data.data[i].y.length; j++) {
                for (let k = 0; k < configDataArray.length; k++) {
                    if (_data.data[i].y[j]['id'] === configDataArray[k].id) {
                        if (typeof _data.series[0].data[i].y !== 'undefined') {
                            if ((_seriesThreshold !== undefined && _seriesThreshold !== null && pieDataArrayLength < _seriesThreshold) || _seriesThreshold === undefined || _seriesThreshold === null) {
                                let colorPointer = _data.data[i].y[j]['color'];
                                let colorValue = (colorPointer && colorPointer != null && colorPointer != null) ? colorPointer : this.getDefaultConfig('color', pieDataArrayLength, _config);
                                legendId = 'id' + pieDataArrayLength;
                                _legendData[legendId] = {
                                    'name': _data.data[i].x + ' ' + configDataArray[k].name,
                                    'id': legendId,
                                    'shape': 'circle',
                                    'x': _data.data[i].x + ' ' + configDataArray[k].name,
                                    'y': _data.data[i].y[j]['value'],
                                    'xBase': _data.data[i].x,
                                    'index': 'pie' + pieDataArrayLength,
                                    'color': colorValue,
                                    'seriesIndex': j,
                                    'dataIndex': i
                                };
                                pieColor.push(colorValue);
                                pieData.push({
                                    'id': legendId,
                                    'x': _data.data[i].x + ' ' + configDataArray[k].name,
                                    'y': _data.data[i].y[j]['value'],
                                    'xBase': _data.data[i].x,
                                    'index': 'pie' + pieDataArrayLength,
                                    'color': colorValue,
                                    'seriesIndex': j,
                                    'dataIndex': i
                                });
                                pieDataArrayLength++;
                                break;
                            }
                        }
                    }
                }
            }
        }
        let returnParams = {
            'pieData': pieData,
            'pieColor': pieColor,
            'legendData': _legendData
        };
        return returnParams;
    }
    singlePieDataMassage(_legendData, _data, _config, _seriesThreshold) {
        let pieData = [];
        let pieColor = [];
        let legendId;
        let pieDataArrayLength = 0;
        _legendData = {};
        if (_data.series && _data.series[0] && _data.series[0].data) {
            for (let i = 0; i < _data.series[0].data.length; i++) {
                if (typeof _data.series[0].data[i].y !== 'undefined') {
                    if ((_seriesThreshold != undefined && _seriesThreshold != null && pieDataArrayLength < _seriesThreshold) || _seriesThreshold == undefined || _seriesThreshold == null) {
                        let colorPointer = _data.series[0].data[i]['color'];
                        let colorValue = (colorPointer && colorPointer != null && colorPointer != null) ? colorPointer : this.getDefaultConfig('color', pieDataArrayLength, _config);
                        legendId = 'id' + pieDataArrayLength;
                        _legendData[legendId] = {
                            'name': _data.series[0].data[i].name.replace(/¬/g, ' '),
                            'id': legendId,
                            'shape': 'circle',
                            'x': _data.series[0].data[i].name,
                            'y': _data.series[0].data[i].y,
                            'xBase': _data.series[0].data[i].name,
                            'index': 'pie' + pieDataArrayLength,
                            'color': colorValue,
                        };
                        pieColor.push(colorValue);
                        if (_data.series[0].data[i].y && _data.series[0].data[i].y > 0) {
                            pieData.push({
                                'id': legendId,
                                'x': _data.series[0].data[i].name,
                                'y': _data.series[0].data[i].y,
                                'xBase': _data.series[0].data[i].name,
                                'index': 'pie' + pieDataArrayLength,
                                'color': colorValue,
                            });
                        }
                        pieDataArrayLength++;
                    }
                }
            }
        }
        let returnParams = {
            'pieData': pieData,
            'pieColor': pieColor,
            'legendData': _legendData
        };
        return returnParams;
    }
    setMapLegendData(_legendData, _data, _config) {
        let legendId;
        _legendData = {};
        for (let i = 0; i < _data.length; i++) {
            if (_data[i].name != undefined) {
                let colorPointer = _data[i].color;
                legendId = 'id' + i;
                _legendData[legendId] = {
                    'name': _data[i].name,
                    'id': legendId,
                    'shape': 'circle',
                    'x': _data[i].name,
                    'y': _data[i].data[0].value,
                    'xBase': _data[i].name,
                    'color': (colorPointer && colorPointer != null && colorPointer != undefined) ? colorPointer : this.getDefaultConfig('color', i, _config),
                    'mapSeriesId': _data[i].id,
                    'deactive': _data[i].deactive
                };
            }
        }
        return _legendData;
    }
    getDefaultConfig(_element, _seriesIndex, _config) {
        if (_element === 'shape')
            return 'circle';
        if (_seriesIndex || _seriesIndex === 0) {
            return _config.colors[_seriesIndex % _config.colors.length];
        }
    }
    setSingleLegendLevels(_dataClasses, _decimalPrecison, _valueSuffix, _originalLegend) {
        let _legendData = {};
        for (let i = 0; i < _dataClasses.length; i++) {
            let legendId = 'id' + i;
            _legendData[legendId] = {
                'name': _dataClasses[i].from.toFixed(_decimalPrecison) + _valueSuffix + ' - ' + _dataClasses[i].to.toFixed(_decimalPrecison) + _valueSuffix,
                'id': legendId,
                'shape': 'circle',
                'color': _dataClasses[i].color,
                'deactive': _originalLegend && _originalLegend[legendId] ? _originalLegend[legendId].deactive : false
            };
        }
        return _legendData;
    }
}
KdChartsSvc.decorators = [
    { type: Injectable }
];
KdChartsSvc.ctorParameters = () => [
    { type: KdDomElemSvc }
];
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoia2QtYW5ndWxhci1jaGFydHMtc3ZjLmpzIiwic291cmNlUm9vdCI6IkM6L3hhbXBwL2h0ZG9jcy9TdHlsZWd1aWRlL2lvc3RnLW9wZW5lbWlzLXN0eWxlZ3VpZGUvcHJvamVjdHMvb3BlbmVtaXMtc3R5bGVndWlkZS1saWIvc3JjLyIsInNvdXJjZXMiOlsia2QtY29tcG9uZW50cy9rZC1hbmd1bGFyLWNoYXJ0cy9rZC1hbmd1bGFyLWNoYXJ0cy1zdmMudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsT0FBTyxFQUFFLFVBQVUsRUFBRSxNQUFNLGVBQWUsQ0FBQztBQUMzQyxPQUFPLEVBQUUsWUFBWSxFQUFFLE1BQU0sb0JBQW9CLENBQUM7QUFDbEQsT0FBTyxLQUFLLEVBQUUsTUFBTSxJQUFJLENBQUM7QUFDekIsT0FBTyxLQUFLLE1BQU0sTUFBTSxvQkFBb0IsQ0FBQztBQW9CN0MsTUFBTSxPQUFPLFdBQVc7SUE0Q3BCLFlBQW9CLE9BQXFCO1FBQXJCLFlBQU8sR0FBUCxPQUFPLENBQWM7UUF0Q2pDLGNBQVMsR0FBWSxLQUFLLENBQUM7UUFHM0IsY0FBUyxHQUFZLEtBQUssQ0FBQztRQUczQixXQUFNLEdBQVksS0FBSyxDQUFDO1FBQ3hCLHNCQUFpQixHQUE0RDtZQUNqRixHQUFHLEVBQUUsRUFBRTtZQUNQLENBQUMsRUFBRSxDQUFDO1lBQ0osQ0FBQyxFQUFFLEVBQUU7WUFDTCxPQUFPLEVBQUUsRUFBRTtTQUNkLENBQUM7UUFDTSxlQUFVLEdBQWtFO1lBQ2hGLEdBQUcsRUFBRSxDQUFDO1lBQ04sS0FBSyxFQUFFLENBQUM7WUFDUixNQUFNLEVBQUUsQ0FBQztZQUNULElBQUksRUFBRSxDQUFDO1NBQ1YsQ0FBQztRQUNNLHFCQUFnQixHQUFxQjtZQUN6QyxPQUFPLEVBQUUsQ0FBQztZQUNWLE9BQU8sRUFBRSxDQUFDO1NBQ2IsQ0FBQztRQUlNLGlCQUFZLEdBQVcsRUFBRSxDQUFDO1FBRzFCLGtCQUFhLEdBQVcsRUFBRSxDQUFDO1FBQzNCLGlCQUFZLEdBQVksS0FBSyxDQUFDO1FBQzlCLGlCQUFZLEdBQVksS0FBSyxDQUFDO1FBQzlCLDJCQUFzQixHQUFXLENBQUMsQ0FBQztRQUNuQyxxQkFBZ0IsR0FBWSxLQUFLLENBQUM7UUFNdEMsSUFBSSxDQUFDLE9BQU8sR0FBRyxJQUFJLE1BQU0sQ0FBQyxlQUFlLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxDQUFDO1FBQ3hELElBQUksQ0FBQyxVQUFVLEdBQUcsSUFBSSxNQUFNLENBQUMsa0JBQWtCLEVBQUUsQ0FBQztJQUN0RCxDQUFDO0lBRUQsSUFBSSxNQUFNLENBQUMsT0FBTztRQUNkLElBQUksQ0FBQyxPQUFPLEdBQUcsT0FBTyxDQUFDO1FBQ3ZCLElBQUksQ0FBQyxPQUFPLENBQUMsTUFBTSxHQUFHLE9BQU8sQ0FBQztJQUNsQyxDQUFDO0lBQ0QsSUFBSSxNQUFNLEtBQW1CLE9BQU8sSUFBSSxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUM7SUFFbkQsSUFBSSxHQUFHLENBQUMsSUFBSSxJQUFJLElBQUksQ0FBQyxJQUFJLEdBQUcsSUFBSSxDQUFDLENBQUMsQ0FBQztJQUVuQyxJQUFJLE9BQU8sQ0FBQyxRQUFRLElBQUksSUFBSSxDQUFDLFFBQVEsR0FBRyxRQUFRLENBQUMsQ0FBQyxDQUFDO0lBRW5ELElBQUksU0FBUyxDQUFDLFVBQVUsSUFBSSxJQUFJLENBQUMsVUFBVSxHQUFHLFVBQVUsQ0FBQyxDQUFDLENBQUM7SUFDM0QsSUFBSSxhQUFhLENBQUMsY0FBYyxJQUFJLElBQUksQ0FBQyxjQUFjLEdBQUcsY0FBYyxDQUFDLENBQUMsQ0FBQztJQUUzRSxJQUFJLFFBQVEsQ0FBQyxTQUFTO1FBQ2xCLElBQUksQ0FBQyxTQUFTLEdBQUcsU0FBUyxDQUFDO1FBQzNCLElBQUksQ0FBQyxPQUFPLENBQUMsUUFBUSxHQUFHLFNBQVMsQ0FBQztJQUN0QyxDQUFDO0lBRUQsSUFBSSxhQUFhLENBQUMsY0FBYyxJQUFJLElBQUksQ0FBQyxjQUFjLEdBQUcsY0FBYyxDQUFDLENBQUMsQ0FBQztJQUUzRSxJQUFJLFFBQVEsQ0FBQyxTQUFTLElBQUksSUFBSSxDQUFDLFNBQVMsR0FBRyxTQUFTLENBQUMsQ0FBQyxDQUFDO0lBQ3ZELElBQUksUUFBUSxLQUFjLE9BQU8sSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUM7SUFFbEQsSUFBSSxXQUFXLENBQUMsWUFBWSxJQUFJLElBQUksQ0FBQyxZQUFZLEdBQUcsWUFBWSxDQUFDLENBQUMsQ0FBQztJQUNuRSxJQUFJLFdBQVcsS0FBYSxPQUFPLElBQUksQ0FBQyxZQUFZLENBQUMsQ0FBQyxDQUFDO0lBRXZELElBQUksU0FBUyxLQUFLLE9BQU8sSUFBSSxDQUFDLFVBQVUsQ0FBQyxDQUFDLENBQUM7SUFFM0MsSUFBSSxVQUFVLENBQUMsV0FBVyxJQUFJLElBQUksQ0FBQyxXQUFXLEdBQUcsV0FBVyxDQUFDLENBQUMsQ0FBQztJQUMvRCxJQUFJLFVBQVUsS0FBSyxPQUFPLElBQUksQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDO0lBRTdDLElBQUksUUFBUSxLQUFLLE9BQU8sSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUM7SUFFekMsSUFBSSxZQUFZLEtBQUssT0FBTyxJQUFJLENBQUMsYUFBYSxDQUFDLENBQUMsQ0FBQztJQUVqRCxJQUFJLGVBQWUsS0FBSyxPQUFPLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDLENBQUM7SUFFdkQsSUFBSSxLQUFLLENBQUMsTUFBTSxJQUFJLElBQUksQ0FBQyxNQUFNLEdBQUcsTUFBTSxDQUFDLENBQUMsQ0FBQztJQUUzQyxJQUFJLFdBQVcsQ0FBQyxZQUFZO1FBQ3hCLElBQUksQ0FBQyxJQUFJLENBQUMsU0FBUyxFQUFFO1lBQ2pCLElBQUksQ0FBQyxZQUFZLEdBQUcsWUFBWSxLQUFLLElBQUksQ0FBQyxNQUFNLENBQUM7U0FDcEQ7YUFBTTtZQUNILElBQUksQ0FBQyxZQUFZLEdBQUcsWUFBWSxDQUFDO1NBQ3BDO0lBQ0wsQ0FBQztJQUNELElBQUksV0FBVyxLQUFLLE9BQU8sSUFBSSxDQUFDLFlBQVksQ0FBQyxDQUFDLENBQUM7SUFFL0MsSUFBSSxXQUFXLENBQUMsWUFBWTtRQUN4QixJQUFJLElBQUksQ0FBQyxTQUFTLEVBQUU7WUFDaEIsSUFBSSxDQUFDLFlBQVksR0FBRyxZQUFZLEtBQUssSUFBSSxDQUFDLE1BQU0sQ0FBQztTQUNwRDthQUFNO1lBQ0gsSUFBSSxDQUFDLFlBQVksR0FBRyxZQUFZLENBQUM7U0FDcEM7SUFDTCxDQUFDO0lBQ0QsSUFBSSxXQUFXLEtBQUssT0FBTyxJQUFJLENBQUMsWUFBWSxDQUFDLENBQUMsQ0FBQztJQUUvQyxJQUFJLGVBQWUsQ0FBQyxnQkFBeUIsSUFBSSxJQUFJLENBQUMsZ0JBQWdCLEdBQUcsZ0JBQWdCLENBQUMsQ0FBQyxDQUFDO0lBQzVGLElBQUksZUFBZSxLQUFjLE9BQU8sSUFBSSxDQUFDLGdCQUFnQixDQUFDLENBQUMsQ0FBQztJQUVoRSxxRkFBcUY7SUFFckY7Ozs7O09BS0c7SUFDSSx1QkFBdUIsQ0FBQyxLQUFvQixFQUFFLE9BQVk7UUFDN0QsSUFBSSxVQUFVLEdBQVEsS0FBSyxDQUFDLENBQUMsQ0FBQyxLQUFLLEtBQUssQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLEtBQUssQ0FBQztRQUN6RSxPQUFPLFVBQVUsQ0FBQyxPQUFPLElBQUksVUFBVSxDQUFDLEtBQUssQ0FBQyxJQUFJLEtBQUssRUFBRSxDQUFDO0lBQzlELENBQUM7SUFFTSx5QkFBeUIsQ0FBQyxHQUFXO1FBQ3hDLElBQUksY0FBYyxHQUFZLFFBQVEsQ0FBQyxhQUFhLENBQUMsR0FBRyxHQUFHLEdBQUcsR0FBRyxrQ0FBa0MsQ0FBQyxDQUFDO1FBQ3JHLElBQUksVUFBVSxHQUFRLElBQUksQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLEtBQUssQ0FBQztRQUUvRSxnQ0FBZ0M7UUFDaEMsSUFBSSxVQUFVLENBQUMsT0FBTyxJQUFJLFVBQVUsQ0FBQyxLQUFLLENBQUMsSUFBSSxLQUFLLEVBQUUsRUFBRTtZQUNwRCxJQUFJLGtCQUFrQixHQUFXLElBQUksQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLDBCQUEwQixDQUFDLENBQUMsQ0FBQywwQkFBMEIsQ0FBQztZQUMxRyxJQUFJLENBQUMsa0JBQWtCLEdBQUcsUUFBUSxDQUFDLGFBQWEsQ0FBQyxHQUFHLEdBQUcsR0FBRyxHQUFHLGNBQWMsR0FBRyxrQkFBa0IsR0FBRyx3QkFBd0IsQ0FBQyxDQUFDO1NBQ2hJO2FBQU07WUFDSCxJQUFJLENBQUMsa0JBQWtCLEdBQUcsSUFBSSxDQUFDO1NBQ2xDO1FBRUQsSUFBSSxDQUFDLHVCQUF1QixDQUFDLGNBQWMsQ0FBQyxDQUFDO0lBQ2pELENBQUM7SUFFTSwyQkFBMkI7UUFDOUIsSUFBSSxDQUFDLElBQUksQ0FBQyxZQUFZLENBQUMsSUFBSSxDQUFDLGtCQUFrQixDQUFDO1lBQUUsT0FBTztRQUV4RCxJQUFJLGNBQWMsR0FBVyxJQUFJLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQywwQkFBMEIsQ0FBQyxDQUFDLENBQUMsMEJBQTBCLENBQUM7UUFDdEcsSUFBSSxnQkFBZ0IsR0FBUSxRQUFRLENBQUMsZ0JBQWdCLENBQUMsR0FBRyxHQUFHLElBQUksQ0FBQyxPQUFPLENBQUMsRUFBRSxHQUFHLGNBQWMsR0FBRyxjQUFjLEdBQUcsOEJBQThCLENBQUMsQ0FBQztRQUNoSixnQkFBZ0IsQ0FBQyxPQUFPLENBQUMsYUFBYSxDQUFDLEVBQUU7WUFDckMsYUFBYSxDQUFDLEtBQUssQ0FBQyxHQUFHLEdBQUcsSUFBSSxDQUFDLGtCQUFrQixDQUFDLHFCQUFxQixFQUFFLENBQUMsTUFBTSxHQUFHLENBQUMsR0FBRyxhQUFhLENBQUMscUJBQXFCLEVBQUUsQ0FBQyxNQUFNLEdBQUcsQ0FBQyxHQUFHLElBQUksQ0FBQztZQUMvSSxhQUFhLENBQUMsS0FBSyxDQUFDLFVBQVUsR0FBRyxPQUFPLENBQUM7UUFDN0MsQ0FBQyxDQUFDLENBQUM7SUFDUCxDQUFDO0lBRUQsb0ZBQW9GO0lBRTdFLFlBQVksQ0FBQyxZQUEwQixFQUFFLFVBQXdCO1FBQ3BFLElBQUksUUFBUSxHQUFXLElBQUksQ0FBQyxZQUFZLENBQUMsWUFBWSxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxZQUFZLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxVQUFVLENBQUMsR0FBRyxDQUFDO1FBQ3pHLElBQUksUUFBUSxHQUFXLElBQUksQ0FBQyxZQUFZLENBQUMsWUFBWSxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxZQUFZLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxVQUFVLENBQUMsR0FBRyxDQUFDO1FBRXpHLHdEQUF3RDtRQUN4RCxRQUFRLEdBQUcsSUFBSSxDQUFDLEdBQUcsQ0FBQyxRQUFRLEVBQUUsUUFBUSxDQUFDLENBQUM7UUFDeEMsUUFBUSxHQUFHLElBQUksQ0FBQyxHQUFHLENBQUMsUUFBUSxFQUFFLFFBQVEsQ0FBQyxDQUFDO1FBRXhDLElBQUksUUFBUSxHQUFXLEVBQUUsQ0FBQyxHQUFHLENBQUMsQ0FBQyxZQUFZLENBQUMsWUFBWSxFQUFFLFlBQVksQ0FBQyxpQkFBaUIsQ0FBQyxDQUFDLENBQUM7UUFFM0YsSUFBSSxDQUFDLFFBQVEsSUFBSSxRQUFRLElBQUksQ0FBQztZQUFFLFFBQVEsR0FBRyxDQUFDLENBQUM7UUFFN0MsK0dBQStHO1FBQy9HLElBQUksd0JBQXdCLEdBQVcsQ0FBQyxRQUFRLEdBQUcsUUFBUSxDQUFDLEdBQUcsSUFBSSxDQUFDO1FBQ3BFLElBQUksd0JBQXdCLEdBQUcsUUFBUSxFQUFFO1lBQ3JDLFFBQVEsR0FBRyxJQUFJLENBQUMsVUFBVSxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLHdCQUF3QixDQUFDLENBQUMsQ0FBQyxDQUFDLHdCQUF3QixDQUFDO1NBQzFHO1FBRUQsT0FBTztZQUNILFFBQVEsRUFBRSxRQUFRO1lBQ2xCLFFBQVEsRUFBRSxRQUFRO1lBQ2xCLFFBQVEsRUFBRSxRQUFRO1NBQ3JCLENBQUM7SUFDTixDQUFDO0lBRU0sZUFBZSxDQUFDLFNBQWlCO1FBQ3BDLElBQUksWUFBWSxHQUFXLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxTQUFTLENBQUMsQ0FBQztRQUM1RCxJQUFJLENBQUMsYUFBYSxHQUFHLElBQUksQ0FBQyxXQUFXLENBQUMsU0FBUyxFQUFFLFlBQVksQ0FBQyxDQUFDO0lBQ25FLENBQUM7SUFFTSxpQkFBaUIsQ0FBQyxZQUEwQixFQUFFLE1BQWM7UUFDL0QsT0FBTyxJQUFJLENBQUMsWUFBWSxDQUFDLFlBQVksQ0FBQyxNQUFNLENBQUMsTUFBTSxFQUFFLE1BQU0sRUFBRSxLQUFLLEVBQUUsSUFBSSxDQUFDLGFBQWEsQ0FBQyxDQUFDO0lBQzVGLENBQUM7SUFFRDs7Ozs7T0FLRztJQUNJLGlCQUFpQixDQUFDLE1BQWMsRUFBRSxNQUFjO1FBQ25ELDZDQUE2QztRQUU3QyxJQUFJLFdBQVcsR0FBaUIsSUFBSSxDQUFDLE9BQU8sQ0FBQyxLQUFLLENBQUM7UUFFbkQsMEZBQTBGO1FBQzFGLElBQUksYUFBYSxHQUFRLElBQUksQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLFNBQVMsR0FBRyxNQUFNLENBQUMsQ0FBQztRQUNqRSxJQUFJLElBQUksR0FBVyxJQUFJLENBQUMsaUJBQWlCLENBQUMsV0FBVyxFQUFFLE1BQU0sQ0FBQyxDQUFDO1FBRS9ELHVDQUF1QztRQUN2QyxJQUFJLGFBQWEsQ0FBQyxLQUFLLEVBQUU7WUFBRSxhQUFhLEdBQUcsSUFBSSxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLENBQUM7UUFFcEUsSUFBSSxDQUFDLGVBQWUsQ0FBQyxhQUFhLEVBQUUsTUFBTSxDQUFDLE1BQU0sQ0FBQyxFQUFFLEVBQUUsV0FBVyxDQUFDLE1BQU0sQ0FBQyxLQUFLLEVBQUUsRUFBRSxLQUFLLEVBQUUseUJBQXlCLEdBQUcsTUFBTSxFQUFFLE9BQU8sRUFBRSxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUM7UUFFNUksYUFBYSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQztRQUV6QixPQUFPLGFBQWEsQ0FBQyxJQUFJLEVBQUUsQ0FBQyxPQUFPLEVBQUUsQ0FBQyxLQUFLLENBQUM7SUFDaEQsQ0FBQztJQUVEOzs7Ozs7T0FNRztJQUNJLFlBQVksQ0FBQyxLQUFnQixFQUFFLFFBQTBCO1FBQzVELElBQUksWUFBWSxHQUFZLEtBQUssS0FBSyxHQUFHLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsS0FBSyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxLQUFLLENBQUMsUUFBUSxDQUFDO1FBQ3RHLElBQUksUUFBUSxHQUFZLFlBQVksS0FBSyxJQUFJLENBQUMsTUFBTSxDQUFDO1FBQ3JELElBQUkscUJBQXFCLEdBQVksQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLEtBQUssQ0FBQyxPQUFPLElBQUksQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDO1FBRXZHLElBQUksS0FBSyxLQUFLLEdBQUc7WUFBRSxJQUFJLENBQUMsZ0JBQWdCLEdBQUcsSUFBSSxDQUFDLDJCQUEyQixDQUFDLFFBQVEsQ0FBQyxDQUFDO1FBRXRGLElBQUksdUJBQXVCLEdBQXlDLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQztRQUMxRixJQUFJLHFCQUFxQjtZQUFFLHVCQUF1QixHQUFHLEVBQUUsT0FBTyxFQUFFLENBQUMsRUFBRSxPQUFPLEVBQUUsQ0FBQyxFQUFFLENBQUM7UUFFaEYsSUFBSSxDQUFDLElBQUksQ0FBQyxTQUFTLEVBQUU7WUFDakIsSUFBSSxLQUFLLEtBQUssR0FBRyxFQUFFO2dCQUNmLElBQUksS0FBSyxHQUFxQixRQUFRLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDO2dCQUMxRCxJQUFJLEdBQUcsR0FBcUIsUUFBUSxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQztnQkFDeEQsSUFBSSxDQUFDLFVBQVUsQ0FBQyxLQUFLLENBQUMsR0FBRyxJQUFJLENBQUMsaUJBQWlCLENBQUMsQ0FBQyxHQUFHLElBQUksQ0FBQyxHQUFHLENBQUMsdUJBQXVCLENBQUMsT0FBTyxFQUFFLHVCQUF1QixDQUFDLE9BQU8sQ0FBQyxDQUFDO2dCQUMvSCxJQUFJLENBQUMsVUFBVSxDQUFDLEdBQUcsQ0FBQyxHQUFHLElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxPQUFPLENBQUM7Z0JBQ3RELE9BQU8sSUFBSSxDQUFDLFFBQVEsQ0FBQyxLQUFLLEdBQUcsSUFBSSxDQUFDLFVBQVUsQ0FBQyxLQUFLLENBQUMsR0FBRyxJQUFJLENBQUMsVUFBVSxDQUFDLEdBQUcsQ0FBQyxDQUFDO2FBQzlFO2lCQUFNO2dCQUNILElBQUksS0FBSyxHQUFxQixZQUFZLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDO2dCQUM5RCxJQUFJLEdBQUcsR0FBcUIsWUFBWSxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQztnQkFDNUQsSUFBSSxhQUFhLEdBQVcscUJBQXFCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLHVCQUF1QixDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsUUFBUSxDQUFDLENBQUM7Z0JBQy9ILElBQUksQ0FBQyxVQUFVLENBQUMsR0FBRyxDQUFDLEdBQUcsSUFBSSxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsaUJBQWlCLENBQUMsQ0FBQyxFQUFFLEdBQUcsR0FBRyxhQUFhLENBQUMsQ0FBQztnQkFDL0UsSUFBSSxDQUFDLFVBQVUsQ0FBQyxLQUFLLENBQUMsR0FBRyxJQUFJLENBQUMsZUFBZSxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsaUJBQWlCLENBQUMsR0FBRyxDQUFDO2dCQUNsRyxPQUFPLElBQUksQ0FBQyxRQUFRLENBQUMsTUFBTSxHQUFHLElBQUksQ0FBQyxVQUFVLENBQUMsS0FBSyxDQUFDLEdBQUcsSUFBSSxDQUFDLFVBQVUsQ0FBQyxHQUFHLENBQUMsQ0FBQzthQUMvRTtTQUNKO2FBQU07WUFDSCxJQUFJLEtBQUssS0FBSyxHQUFHLEVBQUU7Z0JBQ2YsSUFBSSxLQUFLLEdBQXFCLFlBQVksQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUM7Z0JBQzlELElBQUksR0FBRyxHQUFxQixZQUFZLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDO2dCQUM1RCxJQUFJLGFBQWEsR0FBVyxxQkFBcUIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsdUJBQXVCLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxRQUFRLENBQUMsQ0FBQztnQkFDL0gsSUFBSSxDQUFDLFVBQVUsQ0FBQyxLQUFLLENBQUMsR0FBRyxJQUFJLENBQUMsaUJBQWlCLENBQUMsR0FBRyxDQUFDO2dCQUNwRCxJQUFJLENBQUMsVUFBVSxDQUFDLEdBQUcsQ0FBQyxHQUFHLElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxDQUFDLEdBQUcsYUFBYSxDQUFDO2dCQUNoRSxPQUFPLElBQUksQ0FBQyxRQUFRLENBQUMsTUFBTSxHQUFHLElBQUksQ0FBQyxVQUFVLENBQUMsS0FBSyxDQUFDLEdBQUcsSUFBSSxDQUFDLFVBQVUsQ0FBQyxHQUFHLENBQUMsQ0FBQzthQUMvRTtpQkFBTTtnQkFDSCxJQUFJLEtBQUssR0FBcUIsUUFBUSxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQztnQkFDMUQsSUFBSSxHQUFHLEdBQXFCLFFBQVEsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUM7Z0JBQ3hELElBQUksZUFBZSxHQUFXLFFBQVEsS0FBSyxJQUFJLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQyx1QkFBdUIsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLHVCQUF1QixDQUFDLE9BQU8sQ0FBQztnQkFDaEksSUFBSSxhQUFhLEdBQVcsUUFBUSxLQUFLLElBQUksQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDLHVCQUF1QixDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsdUJBQXVCLENBQUMsT0FBTyxDQUFDO2dCQUM5SCxJQUFJLENBQUMsVUFBVSxDQUFDLEtBQUssQ0FBQyxHQUFHLElBQUksQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLGlCQUFpQixDQUFDLENBQUMsRUFBRSxlQUFlLEdBQUcsQ0FBQyxDQUFDLENBQUM7Z0JBQ2pGLElBQUksQ0FBQyxVQUFVLENBQUMsR0FBRyxDQUFDLEdBQUcsSUFBSSxDQUFDLGVBQWUsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsaUJBQWlCLENBQUMsQ0FBQyxFQUFFLGFBQWEsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsYUFBYSxHQUFHLENBQUMsR0FBRyxJQUFJLENBQUMsaUJBQWlCLENBQUMsT0FBTyxDQUFDO2dCQUN6SixPQUFPLElBQUksQ0FBQyxRQUFRLENBQUMsS0FBSyxHQUFHLElBQUksQ0FBQyxVQUFVLENBQUMsS0FBSyxDQUFDLEdBQUcsSUFBSSxDQUFDLFVBQVUsQ0FBQyxHQUFHLENBQUMsQ0FBQzthQUM5RTtTQUNKO0lBQ0wsQ0FBQztJQUVEOzs7Ozs7Ozs7O09BVUc7SUFDSSxpQkFBaUIsQ0FBQyxNQUFjLEVBQUUsU0FBaUIsRUFBRSwwQkFBbUMsRUFBRSxTQUF3QjtRQUNySCw2QkFBNkI7UUFDN0IsSUFBSSxNQUFNLEtBQUssQ0FBQztZQUFFLE9BQU8sTUFBTSxDQUFDO1FBRWhDLElBQUksYUFBYSxHQUFXLElBQUksQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLGdCQUFnQixDQUFDLE1BQU0sQ0FBQyxFQUFFLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDO1FBRXRHLElBQUksYUFBYSxLQUFLLENBQUMsRUFBRTtZQUNyQixxRUFBcUU7WUFDckUsTUFBTSxHQUFHLE1BQU0sR0FBRyxJQUFJLENBQUMsR0FBRyxDQUFDLEVBQUUsRUFBRSxhQUFhLENBQUMsQ0FBQztZQUM5QyxTQUFTLEdBQUcsU0FBUyxHQUFHLElBQUksQ0FBQyxHQUFHLENBQUMsRUFBRSxFQUFFLGFBQWEsQ0FBQyxDQUFDO1NBQ3ZEO1FBRUQsSUFBSSxJQUFJLEdBQVcsSUFBSSxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQztRQUNyQyxJQUFJLFFBQVEsR0FBVyxNQUFNLEdBQUcsTUFBTSxHQUFHLFNBQVMsQ0FBQztRQUVuRCxJQUFJLFNBQVMsS0FBSyxJQUFJLEVBQUU7WUFDcEIsSUFBSSxJQUFJLEdBQUcsQ0FBQyxFQUFFO2dCQUNWLElBQUksQ0FBQywwQkFBMEI7b0JBQUUsUUFBUSxHQUFHLFFBQVEsR0FBRyxTQUFTLENBQUM7YUFDcEU7aUJBQU07Z0JBQ0gsSUFBSSwwQkFBMEI7b0JBQUUsUUFBUSxHQUFHLFFBQVEsR0FBRyxTQUFTLENBQUM7YUFDbkU7U0FDSjthQUFNO1lBQ0gsSUFBSSxJQUFJLEdBQUcsQ0FBQyxFQUFFO2dCQUNWLElBQUksMEJBQTBCO29CQUFFLFFBQVEsR0FBRyxRQUFRLEdBQUcsU0FBUyxDQUFDO2FBQ25FO2lCQUFNO2dCQUNILElBQUksQ0FBQywwQkFBMEI7b0JBQUUsUUFBUSxHQUFHLFFBQVEsR0FBRyxTQUFTLENBQUM7YUFDcEU7U0FDSjtRQUVELElBQUksYUFBYSxLQUFLLENBQUM7WUFBRSxRQUFRLEdBQUcsUUFBUSxHQUFHLElBQUksQ0FBQyxHQUFHLENBQUMsRUFBRSxFQUFFLGFBQWEsQ0FBQyxDQUFDO1FBRTNFLE9BQU8sUUFBUSxDQUFDO0lBQ3BCLENBQUM7SUFFTSxhQUFhLENBQUMsSUFBWSxFQUFFLElBQVksRUFBRSxTQUFpQjtRQUM5RCxJQUFJLENBQUMsU0FBUyxJQUFJLE9BQU8sSUFBSSxLQUFLLFdBQVcsSUFBSSxPQUFPLElBQUksS0FBSyxXQUFXO1lBQUUsT0FBTyxFQUFFLENBQUM7UUFFeEYsSUFBSSxHQUFHLElBQUksQ0FBQywyQkFBMkIsQ0FBQyxJQUFJLEVBQUUsU0FBUyxDQUFDLENBQUM7UUFFekQsT0FBTyxFQUFFLENBQUMsS0FBSyxDQUFDLElBQUksRUFBRSxJQUFJLEVBQUUsU0FBUyxDQUFDLENBQUM7SUFDM0MsQ0FBQztJQUVEOzs7O09BSUc7SUFDSSxrQkFBa0IsQ0FBQyxLQUFVLEVBQUUsVUFBcUI7UUFDdkQsSUFBSSxPQUFPLEdBQVcsVUFBVSxHQUFHLE1BQU0sQ0FBQztRQUMxQyxJQUFJLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxPQUFPLENBQUM7WUFBRSxPQUFPO1FBQ25DLElBQUksVUFBVSxHQUFHLElBQUksQ0FBQyxPQUFPLENBQUMsT0FBTyxDQUFDLENBQUM7UUFFdkMsS0FBSyxDQUFDLFNBQVMsQ0FBQyxNQUFNLENBQUM7YUFDbEIsSUFBSSxDQUFDLGNBQWMsRUFBRSxVQUFVLENBQUMsU0FBUyxDQUFDO2FBQzFDLElBQUksQ0FBQyxRQUFRLEVBQUUsVUFBVSxDQUFDLFNBQVMsQ0FBQyxDQUFDO1FBRTFDLEtBQUssQ0FBQyxTQUFTLENBQUMsTUFBTSxDQUFDO2FBQ2xCLElBQUksQ0FBQyxjQUFjLEVBQUUsVUFBVSxDQUFDLFNBQVMsQ0FBQzthQUMxQyxJQUFJLENBQUMsUUFBUSxFQUFFLFVBQVUsQ0FBQyxTQUFTLENBQUMsQ0FBQztRQUUxQyxJQUFJLFVBQVUsS0FBSyxHQUFHLElBQUksQ0FBQyxVQUFVLENBQUMsT0FBTyxJQUFJLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxPQUFPLENBQUMsQ0FBQyxNQUFNLENBQUMsT0FBTyxFQUFFO1lBQ3BGLElBQUksQ0FBQyxlQUFlLENBQUMsS0FBSyxDQUFDLFNBQVMsQ0FBQyxNQUFNLENBQUMsRUFBRSxFQUFFLE9BQU8sRUFBRSxNQUFNLEVBQUUsQ0FBQyxDQUFDO1NBQ3RFO2FBQU07WUFDSCxJQUFJLENBQUMsZUFBZSxDQUFDLEtBQUssQ0FBQyxTQUFTLENBQUMsTUFBTSxDQUFDLEVBQUUsVUFBVSxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsQ0FBQztZQUN2RSxJQUFJLENBQUMsZUFBZSxDQUFDLEtBQUssQ0FBQyxTQUFTLENBQUMsTUFBTSxDQUFDLEVBQUUsRUFBRSxLQUFLLEVBQUUsZ0VBQWdFLEVBQUUsQ0FBQyxDQUFDO1NBQzlIO0lBQ0wsQ0FBQztJQUVNLDJCQUEyQixDQUFDLFFBQTBCO1FBQ3pELElBQUksUUFBUSxHQUFxQixFQUFFLE9BQU8sRUFBRSxDQUFDLEVBQUUsT0FBTyxFQUFFLENBQUMsRUFBRSxDQUFDO1FBRTVELDJDQUEyQztRQUMzQyxRQUFRLENBQUMsT0FBTyxHQUFHLElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxRQUFRLENBQUMsT0FBTyxFQUFFLFNBQVMsQ0FBQyxDQUFDO1FBQ3ZFLFFBQVEsQ0FBQyxPQUFPLEdBQUcsSUFBSSxDQUFDLGlCQUFpQixDQUFDLFFBQVEsQ0FBQyxPQUFPLEVBQUUsU0FBUyxDQUFDLENBQUM7UUFDdkUsSUFBSTtRQUVKLE9BQU8sUUFBUSxDQUFDO0lBQ3BCLENBQUM7SUFFTywyQkFBMkIsQ0FBQyxJQUFZLEVBQUUsU0FBaUI7UUFDL0QsSUFBSSxhQUFhLEdBQVcsSUFBSSxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsSUFBSSxDQUFDLEVBQUUsSUFBSSxDQUFDLGdCQUFnQixDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUM7UUFFcEcsSUFBSSxHQUFHLElBQUksR0FBRyxJQUFJLENBQUMsR0FBRyxDQUFDLEVBQUUsRUFBRSxhQUFhLENBQUMsQ0FBQztRQUMxQyxTQUFTLEdBQUcsU0FBUyxHQUFHLElBQUksQ0FBQyxHQUFHLENBQUMsRUFBRSxFQUFFLGFBQWEsQ0FBQyxDQUFDO1FBRXBELE9BQU8sQ0FBQyxJQUFJLEdBQUcsU0FBUyxDQUFDLEdBQUcsSUFBSSxDQUFDLEdBQUcsQ0FBQyxFQUFFLEVBQUUsYUFBYSxDQUFDLENBQUM7SUFDNUQsQ0FBQztJQUVELG9GQUFvRjtJQUVwRjs7Ozs7T0FLRztJQUNJLHFCQUFxQixDQUFDLGtCQUEwQixFQUFFO1FBQ3JELElBQUksQ0FBQyxtQkFBbUIsR0FBRyxFQUFFLENBQUMsTUFBTSxDQUFDLEdBQUcsR0FBRyxJQUFJLENBQUMsT0FBTyxDQUFDLEVBQUUsR0FBRyw4Q0FBOEMsR0FBRyxlQUFlLENBQUMsQ0FBQztRQUMvSCxJQUFJLENBQUMsSUFBSSxDQUFDLFlBQVksQ0FBQyxJQUFJLENBQUMsbUJBQW1CLENBQUMsSUFBSSxFQUFFLENBQUM7WUFBRSxPQUFPO1FBRWhFLE9BQU8sSUFBSSxDQUFDLG1CQUFtQixDQUFDO0lBQ3BDLENBQUM7SUFFRCwrQkFBK0I7SUFFeEIsaUJBQWlCLENBQUMsR0FBVyxFQUFFLFNBQWlCLEVBQUUsWUFBb0I7UUFDekUsSUFBSSxDQUFDLHlCQUF5QixDQUFDLEdBQUcsQ0FBQyxDQUFDO1FBQ3BDLElBQUksQ0FBQyxxQkFBcUIsQ0FBQyxZQUFZLENBQUMsQ0FBQztRQUN6QyxJQUFJLENBQUMsUUFBUSxHQUFHLElBQUksQ0FBQyxZQUFZLENBQUMsSUFBSSxDQUFDLFNBQVMsRUFBRSxTQUFTLEVBQUUsSUFBSSxDQUFDLFlBQVksQ0FBQyxDQUFDO1FBQ2hGLElBQUksQ0FBQyx1QkFBdUIsQ0FBQyxTQUFTLENBQUMsQ0FBQztJQUM1QyxDQUFDO0lBRU0scUJBQXFCLENBQUMsWUFBb0I7UUFDN0MsSUFBSSxDQUFDLElBQUksQ0FBQyxlQUFlO1lBQUUsT0FBTztRQUNsQyxZQUFZLEdBQUcsSUFBSSxDQUFDLHFCQUFxQixDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxNQUFNLEVBQUUsWUFBWSxDQUFDLENBQUM7UUFDekYsSUFBSSxDQUFDLHNCQUFzQixDQUFDLFlBQVksQ0FBQyxDQUFDO0lBQzlDLENBQUM7SUFFTSxxQkFBcUI7UUFDeEIsSUFBSSxDQUFDLElBQUksQ0FBQyxlQUFlO1lBQUUsT0FBTyxDQUFDLENBQUM7UUFDcEMsT0FBTyxJQUFJLENBQUMsZUFBZSxDQUFDLHFCQUFxQixFQUFFLENBQUM7SUFDeEQsQ0FBQztJQUVPLHlCQUF5QixDQUFDLEdBQVc7UUFDekMsSUFBSSxPQUFPLElBQUksQ0FBQyxlQUFlLEtBQUssV0FBVyxFQUFFO1lBQzdDLElBQUksQ0FBQyxlQUFlLEdBQUcsUUFBUSxDQUFDLGFBQWEsQ0FBQyxHQUFHLEdBQUcsR0FBRyxHQUFHLDhDQUE4QyxDQUFDLENBQUM7U0FDN0c7SUFDTCxDQUFDO0lBRU8sc0JBQXNCLENBQUMsS0FBYTtRQUN4QyxJQUFJLENBQUMsSUFBSSxDQUFDLGVBQWU7WUFBRSxPQUFPO1FBQ2xDLElBQUksQ0FBQyxlQUFlLENBQUMsU0FBUyxHQUFHLEtBQUssQ0FBQztJQUMzQyxDQUFDO0lBRU8sdUJBQXVCLENBQUMsU0FBaUI7UUFDN0MsSUFBSSxDQUFDLElBQUksQ0FBQyxTQUFTLElBQUksQ0FBQyxJQUFJLENBQUMsUUFBUSxFQUFFO1lBQ25DLElBQUksQ0FBQyxlQUFlLENBQUMsS0FBSyxDQUFDLFFBQVEsR0FBRyxTQUFTLEdBQUcsSUFBSSxDQUFDO1NBQzFEO0lBQ0wsQ0FBQztJQUVELHFCQUFxQjtJQUViLFlBQVksQ0FBQyxTQUFrQixFQUFFLFNBQWlCLEVBQUUsWUFBb0I7UUFDNUUsa0ZBQWtGO1FBQ2xGLElBQUksU0FBUyxJQUFJLFlBQVksSUFBSSxTQUFTO1lBQUUsT0FBTyxLQUFLLENBQUM7UUFDekQsK0ZBQStGO1FBQy9GLE9BQU8sSUFBSSxDQUFDLHFCQUFxQixFQUFFLENBQUMsS0FBSyxHQUFHLFNBQVMsQ0FBQztJQUMxRCxDQUFDO0lBRU0sbUJBQW1CO1FBQ3RCLElBQUksYUFBYSxHQUFXLElBQUksQ0FBQyxxQkFBcUIsRUFBRSxDQUFDLEtBQUssSUFBSSxDQUFDLEVBQy9ELGFBQWEsR0FBUSxJQUFJLENBQUMsY0FBYyxFQUN4QyxTQUFTLEdBQVcsQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxhQUFhLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxhQUFhLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxFQUN0RixXQUFXLEdBQVcsSUFBSSxDQUFDLEdBQUcsQ0FBQyxhQUFhLEVBQUUsR0FBRyxHQUFHLFNBQVMsQ0FBQyxDQUFDO1FBRW5FLElBQUksQ0FBQyxZQUFZLEdBQUcsV0FBVyxDQUFDO0lBQ3BDLENBQUM7SUFFTyxjQUFjLENBQUMsU0FBa0IsRUFBRSxTQUFrQjtRQUN6RCxJQUFJLFVBQVUsR0FBa0QsRUFBRSxHQUFHLEVBQUUsQ0FBQyxFQUFFLElBQUksRUFBRSxDQUFDLEVBQUUsS0FBSyxFQUFFLENBQUMsRUFBRSxDQUFDO1FBQzlGLElBQUksUUFBUSxHQUFZLElBQUksQ0FBQyxPQUFPLENBQUMsS0FBSyxDQUFDLFFBQVEsSUFBSSxLQUFLLENBQUM7UUFFN0QsSUFBSSxDQUFDLFNBQVMsRUFBRTtZQUNaLElBQUksVUFBVSxHQUFXLENBQUMsQ0FBQztZQUMzQixJQUFJLElBQUksR0FBcUIsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUM7WUFDNUQsSUFBSSxJQUFJLEdBQVcsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztZQUN4QyxRQUFRLEdBQUcsUUFBUSxLQUFLLElBQUksQ0FBQyxNQUFNLENBQUM7WUFFcEMsSUFBSSxDQUFDLFFBQVEsSUFBSSxJQUFJLENBQUMsWUFBWSxDQUFDLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxFQUFFO2dCQUN6RCxVQUFVLEdBQUcsSUFBSSxDQUFDLGtCQUFrQixDQUFDLHFCQUFxQixFQUFFLENBQUMsS0FBSyxDQUFDO2FBQ3RFO1lBRUQsVUFBVSxDQUFDLElBQUksQ0FBQyxHQUFHLElBQUksR0FBRyxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsSUFBSSxHQUFHLFVBQVUsQ0FBQyxDQUFDO1NBQ2pFO2FBQU07WUFDSCxVQUFVLENBQUMsR0FBRyxHQUFHLElBQUksQ0FBQyxVQUFVLENBQUMsR0FBRyxDQUFDO1lBQ3JDLElBQUksUUFBUTtnQkFBRSxVQUFVLENBQUMsR0FBRyxJQUFJLElBQUksQ0FBQyxvQkFBb0IsRUFBRSxDQUFDO1lBRTVELFVBQVUsQ0FBQyxLQUFLLEdBQUcsQ0FBQyxDQUFDO1NBQ3hCO1FBQ0QsT0FBTyxVQUFVLENBQUM7SUFDdEIsQ0FBQztJQUVNLDBCQUEwQixDQUFDLFVBQWU7UUFDN0MsSUFBSSxTQUFTLEdBQXVCLElBQUksQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDO1FBQ3hFLElBQUksUUFBUSxHQUFXLElBQUksQ0FBQyxXQUFXLENBQUM7UUFFeEMsSUFBSSxDQUFDLElBQUksQ0FBQyxTQUFTLElBQUksQ0FBQyxJQUFJLENBQUMsUUFBUSxFQUFFO1lBQ25DLFFBQVEsR0FBRyxJQUFJLENBQUMscUJBQXFCLEVBQUUsQ0FBQyxNQUFNLENBQUM7U0FDbEQ7UUFFRCxVQUFVLENBQUMsS0FBSyxDQUFDLFNBQVMsRUFBRSxRQUFRLEdBQUcsSUFBSSxDQUFDLENBQUM7UUFDN0MsSUFBSSxDQUFDLElBQUksQ0FBQyxTQUFTO1lBQUUsVUFBVSxDQUFDLEtBQUssQ0FBQyxPQUFPLEVBQUUsTUFBTSxDQUFDLENBQUM7UUFFdkQsSUFBSSxDQUFDLGVBQWUsQ0FBQyxLQUFLLENBQUMsUUFBUSxHQUFHLE1BQU0sQ0FBQztRQUc3QyxJQUFJLE1BQU0sR0FBa0QsSUFBSSxDQUFDLGNBQWMsQ0FBQyxJQUFJLENBQUMsU0FBUyxFQUFFLElBQUksQ0FBQyxRQUFRLENBQUMsQ0FBQztRQUUvRyxVQUFVO2FBQ0wsS0FBSyxDQUFDLFlBQVksRUFBRSxNQUFNLENBQUMsR0FBRyxHQUFHLElBQUksQ0FBQzthQUN0QyxLQUFLLENBQUMsY0FBYyxFQUFFLE1BQU0sQ0FBQyxLQUFLLEdBQUcsSUFBSSxDQUFDO2FBQzFDLEtBQUssQ0FBQyxhQUFhLEVBQUUsTUFBTSxDQUFDLElBQUksR0FBRyxJQUFJLENBQUMsQ0FBQztRQUU5QyxJQUFJLENBQUMsNkJBQTZCLEdBQUcsTUFBTSxDQUFDLElBQUksQ0FBQztJQUNyRCxDQUFDO0lBRUQ7Ozs7O09BS0c7SUFDSSxvQkFBb0IsQ0FBQyxlQUFvQixFQUFFLFFBQWdCLEVBQUUsY0FBdUM7UUFDdkcsSUFBSSxJQUFJLENBQUMsU0FBUyxJQUFJLGNBQWMsQ0FBQyxRQUFRLElBQUksQ0FBQyxjQUFjLENBQUMsTUFBTSxJQUFJLElBQUksQ0FBQyxXQUFXLEtBQUssUUFBUSxDQUFDLEVBQUU7WUFDdkcsSUFBSSxDQUFDLE9BQU8sQ0FBQyxRQUFRLENBQUMsZUFBZSxDQUFDLElBQUksRUFBRSxFQUFFLFVBQVUsQ0FBQyxDQUFDO1NBQzdEO1FBRUQseUlBQXlJO1FBQ3pJLHNDQUFzQztRQUN0QyxJQUFJLGNBQWMsQ0FBQyxRQUFRO1lBQUUsZUFBZSxDQUFDLEtBQUssQ0FBQyxTQUFTLEVBQUUsQ0FBQyxDQUFDLENBQUM7UUFFakUsSUFBSSxTQUFTLEdBQVEsZUFBZSxDQUFDLElBQUksRUFBRSxDQUFDLHFCQUFxQixFQUFFLEVBQy9ELE1BQU0sR0FBVyxDQUFDLElBQUksQ0FBQyxTQUFTLElBQUksQ0FBQyxjQUFjLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUMsS0FBSyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDLE1BQU0sR0FBRyxDQUFDLEVBQ3pHLFVBQVUsR0FBVyxjQUFjLENBQUMsUUFBUSxJQUFJLGNBQWMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQ2hGLFFBQVEsR0FBVyxRQUFRLEdBQUcsTUFBTSxHQUFHLFVBQVUsQ0FBQztRQUV0RCxxQkFBcUI7UUFDckIsSUFBSSxJQUFJLENBQUMsU0FBUyxFQUFFO1lBQ2hCLElBQUksUUFBUSxHQUFXLElBQUksQ0FBQyxNQUFNLEtBQUssY0FBYyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUM7WUFDbEYsZUFBZTtpQkFDVixLQUFLLENBQUMsS0FBSyxFQUFFLFFBQVEsR0FBRyxJQUFJLENBQUM7aUJBQzdCLEtBQUssQ0FBQyxRQUFRLEVBQUUsQ0FBQyxHQUFHLElBQUksQ0FBQyxDQUFDO1lBQy9CLE9BQU87U0FDVjtRQUVELElBQUksT0FBTyxHQUFXLGNBQWMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDO1FBRWpFLDRCQUE0QjtRQUM1QixJQUFJLGNBQWMsQ0FBQyxRQUFRLEVBQUU7WUFDekIsSUFBSSxRQUFRLEdBQVcsY0FBYyxDQUFDLFFBQVEsSUFBSSxDQUFDLGNBQWMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztZQUVqRyxlQUFlO2lCQUNWLEtBQUssQ0FBQyxPQUFPLEVBQUUsUUFBUSxHQUFHLElBQUksQ0FBQztpQkFDL0IsS0FBSyxDQUFDLFdBQVcsRUFBRSxnQkFBZ0IsQ0FBQyxDQUFDO1NBRTdDO2FBQU07WUFDSCxJQUFJLElBQUksQ0FBQyxXQUFXLEtBQUssUUFBUSxFQUFFO2dCQUMvQixrR0FBa0c7Z0JBQ2xHLElBQUksUUFBUSxHQUFHLElBQUksQ0FBQyw2QkFBNkIsR0FBRyxDQUFDLEVBQUU7b0JBQ25ELElBQUksSUFBSSxHQUFXLElBQUksQ0FBQyxHQUFHLENBQUMsUUFBUSxDQUFDLEdBQUcsSUFBSSxDQUFDLDZCQUE2QixDQUFDO29CQUMzRSxlQUFlLENBQUMsS0FBSyxDQUFDLFdBQVcsRUFBRSxDQUFDLFNBQVMsQ0FBQyxLQUFLLEdBQUcsQ0FBQyxHQUFHLElBQUksQ0FBQyxHQUFHLElBQUksQ0FBQyxDQUFDO29CQUN4RSxRQUFRLEdBQUcsQ0FBQyxDQUFDLEdBQUcsSUFBSSxDQUFDLDZCQUE2QixDQUFDO2lCQUN0RDtnQkFDRCxJQUFJLGNBQWMsQ0FBQyxNQUFNO29CQUFFLGVBQWUsQ0FBQyxLQUFLLENBQUMsV0FBVyxFQUFFLENBQUMsU0FBUyxDQUFDLEtBQUssR0FBRyxDQUFDLEdBQUcsSUFBSSxDQUFDLFVBQVUsQ0FBQyxLQUFLLENBQUMsR0FBRyxJQUFJLENBQUMsQ0FBQzthQUN2SDtZQUVELGVBQWUsQ0FBQyxLQUFLLENBQUMsT0FBTyxFQUFFLENBQUMsR0FBRyxJQUFJLENBQUMsQ0FBQztTQUM1QztRQUVELGVBQWUsQ0FBQyxLQUFLLENBQUMsTUFBTSxFQUFFLFFBQVEsR0FBRyxJQUFJLENBQUMsQ0FBQztJQUNuRCxDQUFDO0lBRUQsbUZBQW1GO0lBRW5GOzs7O09BSUc7SUFDSSxtQkFBbUIsQ0FBQyxtQkFBd0IsRUFBRSxtQkFBeUI7UUFDMUUsSUFBSSxzQkFBc0IsR0FBRyxJQUFJLENBQUMsWUFBWSxDQUFDLG1CQUFtQixDQUFDLENBQUMsQ0FBQyxDQUFDLG1CQUFtQixDQUFDLElBQUksRUFBRSxDQUFDLHFCQUFxQixFQUFFLENBQUMsQ0FBQyxDQUFDLEVBQUUsS0FBSyxFQUFFLENBQUMsRUFBRSxNQUFNLEVBQUUsQ0FBQyxFQUFFLENBQUM7UUFFbkosSUFBSSxJQUFJLEdBQVcsSUFBSSxDQUFDLHVCQUF1QixDQUFDLHNCQUFzQixDQUFDLEtBQUssQ0FBQyxDQUFDO1FBQzlFLElBQUksR0FBRyxHQUFXLElBQUksQ0FBQyxzQkFBc0IsQ0FBQyxzQkFBc0IsQ0FBQyxNQUFNLENBQUMsQ0FBQztRQUU3RSxtQkFBbUI7YUFDZCxLQUFLLENBQUMsTUFBTSxFQUFFLElBQUksR0FBRyxJQUFJLENBQUM7YUFDMUIsS0FBSyxDQUFDLEtBQUssRUFBRSxHQUFHLEdBQUcsSUFBSSxDQUFDLENBQUM7SUFDbEMsQ0FBQztJQUVPLHVCQUF1QixDQUFDLFdBQVc7UUFDdkMsSUFBSSxRQUFRLEdBQVksSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxLQUFLLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLEtBQUssQ0FBQyxRQUFRLENBQUM7UUFDbkcsSUFBSSxlQUFlLEdBQVcsSUFBSSxDQUFDLE9BQU8sQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQztRQUU3RCxzRUFBc0U7UUFDdEUsK0dBQStHO1FBQy9HLElBQUksUUFBUSxLQUFLLElBQUksQ0FBQyxNQUFNLElBQUksQ0FBQyxJQUFJLENBQUMsZUFBZSxFQUFFO1lBQ25ELE9BQU8sSUFBSSxDQUFDLFVBQVUsQ0FBQyxJQUFJLEdBQUcsSUFBSSxDQUFDLHVCQUF1QixDQUFDLGVBQWUsQ0FBQyxDQUFDO1NBQy9FO1FBRUQsNkJBQTZCO1FBQzdCLElBQUksVUFBVSxHQUFXLElBQUksQ0FBQyxZQUFZLENBQUMsSUFBSSxDQUFDLGtCQUFrQixDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxxQkFBcUIsRUFBRSxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO1FBQ2hJLElBQUksSUFBSSxHQUFXLElBQUksQ0FBQyx1QkFBdUIsQ0FBQyxlQUFlLENBQUMsQ0FBQztRQUVqRSxJQUFJLElBQUksSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsVUFBVSxHQUFHLFdBQVcsR0FBRyxJQUFJLENBQUMsVUFBVSxDQUFDLElBQUksR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLFVBQVUsR0FBRyxJQUFJLENBQUMsVUFBVSxDQUFDLElBQUksQ0FBQztRQUVqSCxPQUFPLElBQUksQ0FBQztJQUNoQixDQUFDO0lBRU8sc0JBQXNCLENBQUMsWUFBWTtRQUN2QyxJQUFJLFFBQVEsR0FBWSxJQUFJLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLEtBQUssQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsS0FBSyxDQUFDLFFBQVEsQ0FBQztRQUVuRyxvQ0FBb0M7UUFDcEMsNkdBQTZHO1FBQzdHLElBQUksQ0FBQyxRQUFRLElBQUksQ0FBQyxJQUFJLENBQUMsZUFBZSxFQUFFO1lBQ3BDLE9BQU8sSUFBSSxDQUFDLFVBQVUsQ0FBQyxHQUFHLEdBQUcsSUFBSSxDQUFDLHVCQUF1QixDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsQ0FBQztTQUM1RjtRQUVELDhCQUE4QjtRQUM5QixJQUFJLGdCQUFnQixHQUFXLElBQUksQ0FBQyxvQkFBb0IsRUFBRSxDQUFDO1FBQzNELElBQUksR0FBRyxHQUFXLElBQUksQ0FBQyx1QkFBdUIsQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLENBQUM7UUFFOUUsR0FBRyxJQUFJLElBQUksQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLGdCQUFnQixHQUFHLElBQUksQ0FBQyxVQUFVLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxnQkFBZ0IsR0FBRyxJQUFJLENBQUMsVUFBVSxDQUFDLEdBQUcsR0FBRyxZQUFZLENBQUM7UUFFdkgsT0FBTyxHQUFHLENBQUM7SUFDZixDQUFDO0lBRU8sb0JBQW9CO1FBQ3hCLElBQUksU0FBUyxHQUFXLEdBQUcsR0FBRyxJQUFJLENBQUMsT0FBTyxDQUFDLEVBQUUsR0FBRyxvQ0FBb0MsQ0FBQztRQUNyRixTQUFTLElBQUksSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUM7UUFDMUMsSUFBSSxpQkFBaUIsR0FBRyxRQUFRLENBQUMsYUFBYSxDQUFDLFNBQVMsQ0FBQyxDQUFDO1FBRTFELE9BQU8sSUFBSSxDQUFDLFlBQVksQ0FBQyxpQkFBaUIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxpQkFBaUIsQ0FBQyxxQkFBcUIsRUFBRSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0lBQ3ZHLENBQUM7SUFFRCx5QkFBeUI7SUFFbEIsbUJBQW1CO1FBQ3RCLElBQUksVUFBVSxHQUE4QixJQUFJLENBQUMsT0FBTyxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDO1FBQzVFLElBQUksUUFBUSxHQUFXLElBQUksQ0FBQyx1QkFBdUIsQ0FBQyxVQUFVLENBQUMsUUFBUSxDQUFDLENBQUM7UUFDekUsSUFBSSxXQUFXLEdBQVcsSUFBSSxDQUFDLHVCQUF1QixDQUFDLFVBQVUsQ0FBQyxXQUFXLENBQUMsQ0FBQztRQUMvRSxPQUFPLFFBQVEsR0FBRyxHQUFHLEdBQUcsV0FBVyxHQUFHLENBQUMsQ0FBQztJQUM1QyxDQUFDO0lBRU0sY0FBYyxDQUFDLEtBQVUsRUFBRSxVQUFrQixFQUFFLFlBQW9CLEVBQUUsV0FBbUIsQ0FBQztRQUM1RixJQUFJLFFBQVEsR0FBVyxJQUFJLENBQUMsbUJBQW1CLEVBQUUsR0FBRyxRQUFRLEdBQUcsQ0FBQyxDQUFDO1FBRWpFLElBQUksS0FBSyxLQUFLLEtBQUssRUFBRTtZQUNqQixPQUFPLFVBQVUsR0FBRyxRQUFRLEdBQUcsSUFBSSxDQUFDLHNCQUFzQixDQUFDO1NBQzlEO2FBQU07WUFDSCxPQUFPLFVBQVUsR0FBRyxRQUFRLEdBQUcsWUFBWSxHQUFHLElBQUksQ0FBQyxzQkFBc0IsQ0FBQztTQUM3RTtJQUNMLENBQUM7SUFFTSxtQkFBbUIsQ0FBQyxjQUEyQyxFQUFFLFVBQWtDLEVBQUU7UUFDeEcsSUFBSSxDQUFDLE9BQU8sQ0FBQyxVQUFVO1lBQUUsT0FBTyxLQUFLLENBQUM7UUFDdEMsSUFBSSxPQUFPLENBQUMsU0FBUyxHQUFHLENBQUMsRUFBRTtZQUN2QixJQUFJLGNBQWMsS0FBSyxLQUFLO2dCQUFFLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyx5Q0FBeUM7U0FDckY7YUFBTTtZQUNILElBQUksY0FBYyxLQUFLLFFBQVE7Z0JBQUUsT0FBTyxDQUFDLENBQUMsQ0FBQyx5Q0FBeUM7U0FDdkY7UUFDRCxPQUFPLEtBQUssQ0FBQztJQUNqQixDQUFDO0lBRUQscUlBQXFJO0lBQzlILHVCQUF1QixDQUFDLE9BQU8sRUFBRSxPQUFPO1FBQzNDLElBQUksT0FBTyxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsYUFBYTtZQUFFLE9BQU8sT0FBTyxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsYUFBYSxDQUFDO1FBQ2xGLElBQUksWUFBWSxHQUFnQyxLQUFLLENBQUM7UUFDdEQsMERBQTBEO1FBQzFELElBQUksT0FBTyxDQUFDLFNBQVMsR0FBRyxDQUFDO1lBQUUsWUFBWSxHQUFHLFFBQVEsQ0FBQztRQUNuRCxPQUFPLFlBQVksQ0FBQztJQUN4QixDQUFDO0lBRUQsK0VBQStFO0lBRS9FOzs7OztPQUtHO0lBQ0kscUJBQXFCLENBQUMsT0FBd0I7UUFDakQsT0FBTyxrRkFBa0YsR0FBRyxPQUFPLEdBQUcsUUFBUSxDQUFDO0lBQ25ILENBQUM7SUFFTSx1QkFBdUIsQ0FBQyxNQUF1QjtRQUNsRCxJQUFJLE9BQU8sTUFBTSxLQUFLLFFBQVE7WUFBRSxPQUFPLE1BQU0sQ0FBQztRQUM5QyxPQUFPLFVBQVUsQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDLFVBQVUsRUFBRSxFQUFFLENBQUMsQ0FBQyxDQUFDO0lBQ3RELENBQUM7SUFFTSxrQkFBa0IsQ0FBQyxVQUFvQjtRQUMxQyxPQUFPLFVBQVUsQ0FBQyxDQUFDLENBQUMsS0FBSyxLQUFLLElBQUksQ0FBQyxVQUFVLENBQUMsQ0FBQyxDQUFDLEtBQUssT0FBTyxJQUFJLFVBQVUsQ0FBQyxDQUFDLENBQUMsS0FBSyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsWUFBWSxDQUFDLENBQUMsQ0FBQyxXQUFXLENBQUM7SUFDMUgsQ0FBQztJQUVNLGNBQWMsQ0FBQyxLQUFpQyxFQUFFLFNBQWlCO1FBQ3RFLE9BQU87WUFDSCxLQUFLLEVBQUUsS0FBSyxLQUFLLFdBQVcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxTQUFTLEdBQUcsQ0FBQztZQUNoRCxHQUFHLEVBQUUsS0FBSyxLQUFLLFdBQVcsQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7WUFDM0MsS0FBSyxFQUFFLEtBQUssS0FBSyxXQUFXLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLEdBQUcsRUFBRSxFQUFFLENBQUMsQ0FBQyxHQUFHLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsR0FBRyxFQUFFLEVBQUUsQ0FBQyxDQUFDLEdBQUcsR0FBRztZQUN4RSxPQUFPLEVBQUUsS0FBSyxLQUFLLFdBQVcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDLEdBQUcsQ0FBQztTQUMvRCxDQUFDO0lBQ04sQ0FBQztJQUVNLFFBQVEsQ0FBQyxLQUF5QixFQUFFLE9BQXFCO1FBQzVELElBQUksS0FBSyxHQUFXO1lBQ2hCLEtBQUssRUFBRSxFQUFFO1lBQ1QsV0FBVyxFQUFFLEVBQUU7U0FDbEIsQ0FBQztRQUNGLElBQUksZ0JBQWdCLEdBQVcsQ0FBQyxDQUFDO1FBQ2pDLElBQUksZ0JBQWdCLEdBQVksT0FBTyxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLE9BQU8sQ0FBQyxTQUFTLENBQUMsR0FBRyxDQUFDLENBQUMsSUFBSSxPQUFPLENBQUMsS0FBSyxDQUFDLE9BQU8sSUFBSSxPQUFPLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxPQUFPLENBQUM7UUFDN0ksSUFBSSxnQkFBZ0I7WUFBRSxJQUFJLENBQUMseUJBQXlCLENBQUMsT0FBTyxDQUFDLEVBQUUsQ0FBQyxDQUFDO1FBRWpFLEtBQUssQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLEVBQUU7WUFDZCxLQUFLLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDO1lBRTVCLDJFQUEyRTtZQUMzRSxJQUFJLGdCQUFnQixFQUFFO2dCQUNsQixJQUFJLENBQUMsc0JBQXNCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQztnQkFDdkMsSUFBSSxZQUFZLEdBQVcsSUFBSSxDQUFDLHFCQUFxQixFQUFFLENBQUMsS0FBSyxDQUFDO2dCQUM5RCxJQUFJLFlBQVksR0FBRyxnQkFBZ0IsRUFBRTtvQkFDakMsZ0JBQWdCLEdBQUcsWUFBWSxDQUFDO29CQUNoQyxLQUFLLENBQUMsV0FBVyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDO2lCQUNqQzthQUNKO1FBQ0wsQ0FBQyxDQUFDLENBQUM7UUFFSCxPQUFPLEtBQUssQ0FBQztJQUNqQixDQUFDO0lBRU0sNEJBQTRCLENBQUMsTUFBYztRQUM5QyxJQUFJLElBQUksQ0FBQyxlQUFlLEVBQUU7WUFDdEIsSUFBSSxXQUFXLEdBQWlCLElBQUksQ0FBQyxNQUFNLENBQUMsV0FBVyxDQUFDO1lBQ3hELElBQUksV0FBVyxJQUFJLFdBQVcsQ0FBQyxHQUFHLElBQUksT0FBTyxXQUFXLENBQUMsR0FBRyxDQUFDLGlCQUFpQixLQUFLLFdBQVcsRUFBRTtnQkFDNUYsT0FBTyxJQUFJLENBQUMsTUFBTSxDQUFDLFdBQVcsQ0FBQyxHQUFHLENBQUMsaUJBQWlCLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQzthQUNwRjtZQUNELE9BQU8sSUFBSSxDQUFDLEdBQUcsQ0FBQyxNQUFNLENBQUMsQ0FBQztTQUMzQjtRQUNELE9BQU8sTUFBTSxDQUFDO0lBQ2xCLENBQUM7SUFFTSxnQkFBZ0IsQ0FBQyxPQUFlO1FBQ25DLElBQUksUUFBUSxDQUFDLE9BQU8sQ0FBQyxRQUFRLEVBQUUsQ0FBQyxLQUFLLE9BQU87WUFBRSxPQUFPLENBQUMsQ0FBQztRQUN2RCxJQUFJLE1BQU0sR0FBVyxDQUFDLENBQUM7UUFDdkIsSUFBSSxVQUFVLEdBQVcsSUFBSSxDQUFDLEdBQUcsQ0FBQyxPQUFPLENBQUMsQ0FBQyxRQUFRLEVBQUUsQ0FBQztRQUN0RCxJQUFJLFVBQVUsR0FBa0IsVUFBVSxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FBQztRQUV0RCxJQUFJLFVBQVUsQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxFQUFFO1lBQzdCLE1BQU0sR0FBRyxVQUFVLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDO1NBQ2pDO2FBQU07WUFDSCxNQUFNLEdBQUcsUUFBUSxDQUFDLFVBQVUsQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztZQUM3QyxJQUFJLE9BQU8sVUFBVSxDQUFDLENBQUMsQ0FBQyxLQUFLLFdBQVc7Z0JBQUUsTUFBTSxJQUFJLFVBQVUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUM7U0FDNUU7UUFFRCxPQUFPLE1BQU0sQ0FBQztJQUNsQixDQUFDO0lBRU0sWUFBWSxDQUFDLE9BQWUsRUFBRSxNQUF1QixFQUFFLFVBQW1CLElBQUksRUFBRSxTQUFrQjtRQUNyRyxJQUFJLFFBQVEsR0FBVyxPQUFPLFNBQVMsS0FBSyxXQUFXLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxXQUFXLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQztRQUMvRixJQUFJLElBQUksR0FBVyxJQUFJLENBQUMscUJBQXFCLENBQUMsTUFBTSxFQUFFLFFBQVEsQ0FBQyxDQUFDO1FBRWhFLElBQUksT0FBTztZQUFFLElBQUksR0FBRyxJQUFJLENBQUMscUJBQXFCLENBQUMsSUFBSSxDQUFDLENBQUM7UUFFckQsT0FBTyxJQUFJLENBQUMscUJBQXFCLENBQUMsT0FBTyxFQUFFLElBQUksQ0FBQyxDQUFDO0lBQ3JELENBQUM7SUFFTSxxQkFBcUIsQ0FBQyxPQUFlLEVBQUUsS0FBYTtRQUN2RCxPQUFPLE9BQU8sQ0FBQyxPQUFPLENBQUMsVUFBVSxFQUFFLEtBQUssQ0FBQyxDQUFDO0lBQzlDLENBQUM7SUFFTSxVQUFVLENBQUMsTUFBdUI7UUFDckMsT0FBTyxPQUFPLE1BQU0sS0FBSyxRQUFRLElBQUksQ0FBQyxNQUFNLEdBQUcsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDO0lBQzVELENBQUM7SUFFTSxXQUFXLENBQUMsTUFBdUIsRUFBRSxlQUF3QjtRQUNoRSxJQUFJLE9BQU8sTUFBTSxLQUFLLFFBQVE7WUFBRSxPQUFPLEVBQUUsQ0FBQztRQUUxQyxJQUFJLElBQUksQ0FBQyxHQUFHLENBQUMsTUFBTSxDQUFDLEdBQUcsUUFBUTtZQUFFLE9BQU8sS0FBSyxDQUFDO1FBRTlDLElBQUksSUFBSSxDQUFDLFVBQVUsQ0FBQyxNQUFNLENBQUMsRUFBRTtZQUN6QixPQUFPLEdBQUcsQ0FBQztTQUNkO2FBQU07WUFDSCxhQUFhO1lBQ2IsSUFBSSxJQUFJLENBQUMsR0FBRyxDQUFDLE1BQU0sQ0FBQyxHQUFHLFVBQVU7Z0JBQUUsT0FBTyxLQUFLLENBQUM7WUFFaEQsSUFBSSxPQUFPLGVBQWUsS0FBSyxXQUFXLElBQUksZUFBZSxLQUFLLENBQUMsRUFBRTtnQkFDakUsd0JBQXdCO2dCQUN4QixPQUFPLEdBQUcsR0FBRyxlQUFlLENBQUMsUUFBUSxFQUFFLEdBQUcsR0FBRyxDQUFDO2FBQ2pEO1NBQ0o7UUFFRCxPQUFPLEVBQUUsQ0FBQztJQUNkLENBQUM7SUFFTSxxQkFBcUIsQ0FBQyxNQUF1QixFQUFFLE9BQWU7UUFDakUsSUFBSSxPQUFPLE1BQU0sS0FBSyxRQUFRO1lBQUUsT0FBTyxNQUFNLENBQUM7UUFDOUMsT0FBTyxFQUFFLENBQUMsTUFBTSxDQUFDLE9BQU8sQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDO0lBQ3RDLENBQUM7SUFFTSxlQUFlLENBQUMsS0FBYSxFQUFFLEtBQWE7UUFDL0MsT0FBTyxLQUFLLENBQUMsUUFBUSxFQUFFLENBQUMsTUFBTSxHQUFHLEtBQUssQ0FBQyxRQUFRLEVBQUUsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDO0lBQzdFLENBQUM7SUFFTSx1QkFBdUIsQ0FBQyxlQUFvQjtRQUMvQyxJQUFJLE1BQU0sR0FBaUIsSUFBSSxDQUFDLE9BQU8sQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDO1FBQ3JELGVBQWUsQ0FBQyxLQUFLLENBQUMsT0FBTyxHQUFHLE1BQU0sQ0FBQyxHQUFHLEdBQUcsR0FBRyxHQUFHLE1BQU0sQ0FBQyxLQUFLLEdBQUcsR0FBRyxHQUFHLE1BQU0sQ0FBQyxNQUFNLEdBQUcsR0FBRyxHQUFHLE1BQU0sQ0FBQyxJQUFJLENBQUM7SUFDOUcsQ0FBQztJQUVNLHVCQUF1QixDQUFDLFVBQWU7UUFDMUMsVUFBVSxDQUFDLElBQUksQ0FBQyxXQUFXLEVBQUUsWUFBWSxHQUFHLElBQUksQ0FBQyxVQUFVLENBQUMsSUFBSSxHQUFHLEdBQUcsR0FBRyxJQUFJLENBQUMsVUFBVSxDQUFDLEdBQUcsR0FBRyxHQUFHLENBQUMsQ0FBQztJQUN4RyxDQUFDO0lBRU0sZUFBZSxDQUFDLFFBQWEsRUFBRSxPQUEyQztRQUM3RSxLQUFLLElBQUksR0FBRyxJQUFJLE9BQU8sRUFBRTtZQUNyQixJQUFJLENBQUMsSUFBSSxDQUFDLFlBQVksQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLENBQUM7Z0JBQUUsU0FBUztZQUMvQyxJQUFJLFlBQVksR0FBVyxHQUFHLEtBQUssT0FBTyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxPQUFPLENBQUMsc0JBQXNCLEVBQUUsS0FBSyxDQUFDLENBQUMsV0FBVyxFQUFFLENBQUM7WUFDL0csUUFBUSxDQUFDLElBQUksQ0FBQyxZQUFZLEVBQUUsT0FBTyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUM7U0FDN0M7SUFDTCxDQUFDO0lBRU0sT0FBTyxDQUFDLE1BQVc7UUFDdEIsT0FBTyxDQUFDLE9BQU8sTUFBTSxLQUFLLFdBQVcsSUFBSSxNQUFNLEtBQUssSUFBSSxJQUFJLE1BQU0sQ0FBQyxLQUFLLEtBQUssSUFBSSxDQUFDLENBQUM7SUFDdkYsQ0FBQztJQUVNLFlBQVksQ0FBQyxJQUFTO1FBQ3pCLE9BQU8sQ0FBQyxPQUFPLElBQUksS0FBSyxXQUFXLElBQUksSUFBSSxLQUFLLElBQUksSUFBSSxJQUFJLEtBQUssRUFBRSxDQUFDLENBQUM7SUFDekUsQ0FBQztJQUVNLGFBQWEsQ0FBQyxJQUFtQixFQUFFLEtBQW9CO1FBQzFELElBQUksS0FBSyxLQUFLLEtBQUs7WUFBRSxPQUFPLEVBQUUsQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLENBQUM7UUFDekMsSUFBSSxLQUFLLEtBQUssS0FBSztZQUFFLE9BQU8sRUFBRSxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsQ0FBQztJQUM3QyxDQUFDO0lBRU0sbUJBQW1CLENBQUMsS0FBZ0IsRUFBRSxTQUFrQixFQUFFLGFBQWdDO1FBQzdGLElBQUksSUFBSSxDQUFDLFNBQVMsRUFBRTtZQUNoQixJQUFJLEtBQUssS0FBSyxHQUFHLEVBQUU7Z0JBQ2YsSUFBSSxTQUFTO29CQUFFLE9BQU8sYUFBYSxDQUFDLEtBQUssQ0FBQztnQkFDMUMsT0FBTyxhQUFhLENBQUMsSUFBSSxDQUFDO2FBQzdCO1lBQ0QsSUFBSSxLQUFLLEtBQUssR0FBRyxFQUFFO2dCQUNmLElBQUksU0FBUztvQkFBRSxPQUFPLGFBQWEsQ0FBQyxHQUFHLENBQUM7Z0JBQ3hDLE9BQU8sYUFBYSxDQUFDLE1BQU0sQ0FBQzthQUMvQjtTQUNKO2FBQU07WUFDSCxJQUFJLEtBQUssS0FBSyxHQUFHLEVBQUU7Z0JBQ2YsSUFBSSxTQUFTO29CQUFFLE9BQU8sYUFBYSxDQUFDLEdBQUcsQ0FBQztnQkFDeEMsT0FBTyxhQUFhLENBQUMsTUFBTSxDQUFDO2FBQy9CO1lBQ0QsSUFBSSxLQUFLLEtBQUssR0FBRyxFQUFFO2dCQUNmLElBQUksU0FBUztvQkFBRSxPQUFPLGFBQWEsQ0FBQyxLQUFLLENBQUM7Z0JBQzFDLE9BQU8sYUFBYSxDQUFDLElBQUksQ0FBQzthQUM3QjtTQUNKO0lBQ0wsQ0FBQztJQUVNLG9CQUFvQixDQUFDLGVBQThCLEVBQUUsV0FBbUI7UUFDM0UsSUFBSSxDQUFDLGVBQWU7WUFBRSxPQUFPLEVBQUUsQ0FBQztRQUNoQyxPQUFPLFdBQVcsSUFBSSxlQUFlLENBQUMsTUFBTSxHQUFHLFdBQVcsQ0FBQyxDQUFDLENBQUMsZUFBZSxDQUFDLEtBQUssQ0FBQyxDQUFDLEVBQUUsV0FBVyxDQUFDLENBQUMsQ0FBQyxDQUFDLGVBQWUsQ0FBQztJQUN6SCxDQUFDO0lBRUQ7Ozs7O09BS0c7SUFDSSxRQUFRLENBQUMsYUFBcUIsRUFBRSxZQUFzQjtRQUN6RCxJQUFJLE1BQU0sR0FBVyxFQUFFLENBQUM7UUFDeEIsSUFBSSxZQUFZLEVBQUU7WUFDZCxNQUFNLEdBQUcsSUFBSSxDQUFDLE9BQU8sQ0FBQyxPQUFPLENBQUMsS0FBSyxDQUFDO1NBQ3ZDO1FBQ0QsSUFBSSxPQUFPLEdBQVcsRUFBRSxDQUFDO1FBRXpCLElBQUksYUFBYSxFQUFFO1lBQ2YsS0FBSyxJQUFJLFVBQVUsSUFBSSxNQUFNLENBQUMsSUFBSSxDQUFDLGFBQWEsQ0FBQyxFQUFFO2dCQUMvQyxPQUFPLElBQUksVUFBVSxDQUFDLE9BQU8sQ0FBQyxzQkFBc0IsRUFBRSxLQUFLLENBQUMsQ0FBQyxXQUFXLEVBQUUsQ0FBQztnQkFDM0UsT0FBTyxJQUFJLEdBQUcsQ0FBQztnQkFDZixPQUFPLElBQUksQ0FBQyxNQUFNLElBQUksTUFBTSxDQUFDLGNBQWMsQ0FBQyxVQUFVLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQyxDQUFDLGFBQWEsQ0FBQyxVQUFVLENBQUMsQ0FBQztnQkFDMUcsT0FBTyxJQUFJLEdBQUcsQ0FBQzthQUNsQjtTQUNKO1FBQ0QsT0FBTyxPQUFPLENBQUM7SUFDbkIsQ0FBQztJQUVELGlGQUFpRjtJQUVqRjs7Ozs7T0FLRztJQUNJLFlBQVksQ0FBQyxLQUFzQyxFQUFFLFVBQWtCLEVBQUUsWUFBb0I7UUFTaEcsSUFBSSxVQUFVLEdBQVcsQ0FBQyxDQUFDO1FBQzNCLElBQUksVUFBVSxHQUFXLENBQUMsQ0FBQztRQUMzQixJQUFJLFlBQVksR0FBRyxJQUFJLENBQUMsWUFBWSxDQUFDO1FBRXJDLElBQUksWUFBWSxDQUFDLEtBQUssQ0FBQyxFQUFFO1lBQ3JCLFVBQVUsR0FBRyxLQUFLLENBQUMsTUFBTSxDQUFDLFlBQVksQ0FBQyxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsQ0FBQyxLQUFLLENBQUM7WUFDL0QsVUFBVSxHQUFHLEtBQUssQ0FBQyxLQUFLLENBQUMsVUFBVSxDQUFDLE1BQU0sQ0FBQztTQUM5QzthQUFNO1lBQ0gsVUFBVSxHQUFHLEtBQUssQ0FBQyxVQUFVLENBQUMsQ0FBQyxDQUFDLENBQUMsWUFBWSxDQUFDLENBQUMsS0FBSyxDQUFDO1lBQ3JELFVBQVUsR0FBRyxLQUFLLENBQUMsTUFBTSxDQUFDO1NBQzdCO1FBRUQsU0FBUyxRQUFRLENBQUMsSUFBWSxFQUFFLE1BQWU7WUFDM0MsSUFBSSxLQUFLLEdBQVcsQ0FBQyxDQUFDO1lBQ3RCLElBQUksSUFBSSxLQUFLLE1BQU0sRUFBRTtnQkFDakIsSUFBSSxVQUFVLEdBQUcsQ0FBQyxFQUFFO29CQUNoQixLQUFLLEdBQUcsVUFBVSxHQUFHLENBQUMsQ0FBQztpQkFDMUI7cUJBQU07b0JBQ0gsT0FBTyxLQUFLLENBQUM7aUJBQ2hCO2FBQ0o7aUJBQU07Z0JBQ0gsSUFBSSxVQUFVLEdBQUcsVUFBVSxHQUFHLENBQUMsRUFBRTtvQkFDN0IsS0FBSyxHQUFHLFVBQVUsR0FBRyxDQUFDLENBQUM7aUJBQzFCO3FCQUFNO29CQUNILE9BQU8sS0FBSyxDQUFDO2lCQUNoQjthQUNKO1lBRUQsSUFBSSxLQUFLLEdBQVcsQ0FBQyxZQUFZLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsWUFBWSxDQUFDLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxZQUFZLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQztZQUU5SCxJQUFJLE1BQU0sRUFBRTtnQkFDUixPQUFPLEtBQUssS0FBSyxJQUFJLENBQUM7YUFDekI7WUFDRCxPQUFPLEtBQUssS0FBSyxJQUFJLENBQUM7UUFDMUIsQ0FBQztRQUVELElBQUksVUFBVSxHQUFZLFFBQVEsQ0FBQyxNQUFNLEVBQUUsSUFBSSxDQUFDLENBQUM7UUFDakQsSUFBSSxhQUFhLEdBQVksUUFBUSxDQUFDLE1BQU0sRUFBRSxLQUFLLENBQUMsQ0FBQztRQUNyRCxJQUFJLFVBQVUsR0FBWSxRQUFRLENBQUMsTUFBTSxFQUFFLElBQUksQ0FBQyxDQUFDO1FBQ2pELElBQUksYUFBYSxHQUFZLFFBQVEsQ0FBQyxNQUFNLEVBQUUsS0FBSyxDQUFDLENBQUM7UUFFckQsSUFBSSxXQUFXLEdBQVksYUFBYSxJQUFJLFVBQVUsS0FBSyxJQUFJLElBQUksVUFBVSxDQUFDO1FBRTlFLElBQUksY0FBYyxHQUFZLFVBQVUsSUFBSSxVQUFVLEtBQUssSUFBSSxJQUFJLGFBQWEsQ0FBQztRQUVqRixPQUFPO1lBQ0gsVUFBVSxFQUFFLFVBQVU7WUFDdEIsYUFBYSxFQUFFLGFBQWE7WUFDNUIsVUFBVSxFQUFFLFVBQVU7WUFDdEIsYUFBYSxFQUFFLGFBQWE7WUFDNUIsV0FBVyxFQUFFLFdBQVc7WUFDeEIsY0FBYyxFQUFFLGNBQWM7U0FDakMsQ0FBQztJQUNOLENBQUM7SUFFTSxZQUFZLENBQUMsTUFBVztRQUMzQixPQUFPLFFBQVEsSUFBSSxNQUFNLENBQUM7SUFDOUIsQ0FBQztJQUVELHFGQUFxRjtJQUVyRjs7Ozs7T0FLRztJQUNJLHdCQUF3QixDQUFDLFVBQTBCLEVBQUUsV0FBMEIsRUFBRSxZQUFvQjtRQUN4RyxJQUFJLE1BQU0sR0FBa0IsRUFBRSxDQUFDO1FBQy9CLEtBQUssSUFBSSxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsR0FBRyxXQUFXLENBQUMsTUFBTSxFQUFFLEVBQUUsQ0FBQyxFQUFFO1lBQ3pDLElBQUksR0FBRyxHQUFXLENBQUMsQ0FBQztZQUNwQixLQUFLLElBQUksQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLEdBQUcsWUFBWSxFQUFFLEVBQUUsQ0FBQyxFQUFFO2dCQUNuQyxJQUFJLE9BQU8sVUFBVSxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsS0FBSyxXQUFXO29CQUFFLFNBQVM7Z0JBQzNELElBQUksVUFBVSxHQUFrQixVQUFVLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQztnQkFDNUQsSUFBSSxPQUFPLFVBQVUsS0FBSyxXQUFXO29CQUFFLFNBQVM7Z0JBQ2hELEdBQUcsR0FBRyxDQUFDLFVBQVUsS0FBSyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxHQUFHLEdBQUcsVUFBVSxDQUFDO2FBQ3hEO1lBQ0QsTUFBTSxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQztTQUNwQjtRQUNELE9BQU8sTUFBTSxDQUFDO0lBQ2xCLENBQUM7SUFFRCxnRkFBZ0Y7SUFDaEY7Ozs7O09BS0c7SUFDSSxVQUFVLENBQUMsV0FBMkMsRUFBRSxLQUFVLEVBQUUsT0FBcUIsRUFBRSxnQkFBd0I7UUFLdEgsSUFBSSxPQUFPLEdBQWUsRUFBRSxDQUFDO1FBQzdCLElBQUksUUFBUSxHQUFrQixFQUFFLENBQUM7UUFDakMsSUFBSSxRQUFnQixDQUFDO1FBQ3JCLElBQUksa0JBQWtCLEdBQVcsQ0FBQyxDQUFDO1FBQ25DLElBQUksZUFBZSxHQUF1QixNQUFNLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLFdBQVcsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDO1FBQ2hHLFdBQVcsR0FBRyxFQUFFLENBQUM7UUFDakIsS0FBSyxJQUFJLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxHQUFHLEtBQUssQ0FBQyxJQUFJLENBQUMsTUFBTSxFQUFFLENBQUMsRUFBRSxFQUFFO1lBQ3hDLEtBQUssSUFBSSxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsR0FBRyxLQUFLLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLEVBQUUsQ0FBQyxFQUFFLEVBQUU7Z0JBQzdDLEtBQUssSUFBSSxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsR0FBRyxlQUFlLENBQUMsTUFBTSxFQUFFLENBQUMsRUFBRSxFQUFFO29CQUM3QyxJQUFJLEtBQUssQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxLQUFLLGVBQWUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLEVBQUU7d0JBQ3BELElBQUksT0FBTyxLQUFLLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssV0FBVyxFQUFFOzRCQUNsRCxJQUFJLENBQUMsZ0JBQWdCLEtBQUssU0FBUyxJQUFJLGdCQUFnQixLQUFLLElBQUksSUFBSSxrQkFBa0IsR0FBRyxnQkFBZ0IsQ0FBQyxJQUFJLGdCQUFnQixLQUFLLFNBQVMsSUFBSSxnQkFBZ0IsS0FBSyxJQUFJLEVBQUU7Z0NBQ3ZLLElBQUksWUFBWSxHQUFHLEtBQUssQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDO2dDQUMvQyxJQUFJLFVBQVUsR0FBRyxDQUFDLFlBQVksSUFBSSxZQUFZLElBQUksSUFBSSxJQUFJLFlBQVksSUFBSSxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsWUFBWSxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsT0FBTyxFQUFFLGtCQUFrQixFQUFFLE9BQU8sQ0FBQyxDQUFDO2dDQUM3SixRQUFRLEdBQUcsSUFBSSxHQUFHLGtCQUFrQixDQUFDO2dDQUNyQyxXQUFXLENBQUMsUUFBUSxDQUFDLEdBQUc7b0NBQ3BCLE1BQU0sRUFBRSxLQUFLLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxHQUFHLEdBQUcsZUFBZSxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUk7b0NBQ3ZELElBQUksRUFBRSxRQUFRO29DQUNkLE9BQU8sRUFBRSxRQUFRO29DQUNqQixHQUFHLEVBQUUsS0FBSyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsR0FBRyxHQUFHLGVBQWUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJO29DQUNwRCxHQUFHLEVBQUUsS0FBSyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDO29DQUNoQyxPQUFPLEVBQUUsS0FBSyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO29DQUN4QixPQUFPLEVBQUUsS0FBSyxHQUFHLGtCQUFrQjtvQ0FDbkMsT0FBTyxFQUFFLFVBQVU7b0NBQ25CLGFBQWEsRUFBRSxDQUFDO29DQUNoQixXQUFXLEVBQUUsQ0FBQztpQ0FDakIsQ0FBQztnQ0FDRixRQUFRLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxDQUFDO2dDQUMxQixPQUFPLENBQUMsSUFBSSxDQUFDO29DQUNULElBQUksRUFBRSxRQUFRO29DQUNkLEdBQUcsRUFBRSxLQUFLLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxHQUFHLEdBQUcsZUFBZSxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUk7b0NBQ3BELEdBQUcsRUFBRSxLQUFLLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUM7b0NBQ2hDLE9BQU8sRUFBRSxLQUFLLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7b0NBQ3hCLE9BQU8sRUFBRSxLQUFLLEdBQUcsa0JBQWtCO29DQUNuQyxPQUFPLEVBQUUsVUFBVTtvQ0FDbkIsYUFBYSxFQUFFLENBQUM7b0NBQ2hCLFdBQVcsRUFBRSxDQUFDO2lDQUNqQixDQUFDLENBQUM7Z0NBQ0gsa0JBQWtCLEVBQUUsQ0FBQztnQ0FDckIsTUFBTTs2QkFDVDt5QkFDSjtxQkFDSjtpQkFDSjthQUNKO1NBQ0o7UUFDRCxJQUFJLFlBQVksR0FBRztZQUNmLFNBQVMsRUFBRSxPQUFPO1lBQ2xCLFVBQVUsRUFBRSxRQUFRO1lBQ3BCLFlBQVksRUFBRSxXQUFXO1NBQzVCLENBQUM7UUFDRixPQUFPLFlBQVksQ0FBQztJQUN4QixDQUFDO0lBRU0sb0JBQW9CLENBQUMsV0FBMkMsRUFBRSxLQUFVLEVBQUUsT0FBcUIsRUFBRSxnQkFBd0I7UUFDaEksSUFBSSxPQUFPLEdBQWUsRUFBRSxDQUFDO1FBQzdCLElBQUksUUFBUSxHQUFrQixFQUFFLENBQUM7UUFDakMsSUFBSSxRQUFnQixDQUFDO1FBQ3JCLElBQUksa0JBQWtCLEdBQVcsQ0FBQyxDQUFDO1FBQ25DLFdBQVcsR0FBRyxFQUFFLENBQUM7UUFDakIsSUFBSSxLQUFLLENBQUMsTUFBTSxJQUFJLEtBQUssQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLElBQUksS0FBSyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLEVBQUU7WUFDekQsS0FBSyxJQUFJLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxHQUFHLEtBQUssQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLE1BQU0sRUFBRSxDQUFDLEVBQUUsRUFBRTtnQkFDbEQsSUFBSSxPQUFPLEtBQUssQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxXQUFXLEVBQUU7b0JBQ2xELElBQUksQ0FBQyxnQkFBZ0IsSUFBSSxTQUFTLElBQUksZ0JBQWdCLElBQUksSUFBSSxJQUFJLGtCQUFrQixHQUFHLGdCQUFnQixDQUFDLElBQUksZ0JBQWdCLElBQUksU0FBUyxJQUFJLGdCQUFnQixJQUFJLElBQUksRUFBRTt3QkFDbkssSUFBSSxZQUFZLEdBQUcsS0FBSyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUM7d0JBQ3BELElBQUksVUFBVSxHQUFHLENBQUMsWUFBWSxJQUFJLFlBQVksSUFBSSxJQUFJLElBQUksWUFBWSxJQUFJLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxZQUFZLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxPQUFPLEVBQUUsa0JBQWtCLEVBQUUsT0FBTyxDQUFDLENBQUM7d0JBQzdKLFFBQVEsR0FBRyxJQUFJLEdBQUcsa0JBQWtCLENBQUM7d0JBQ3JDLFdBQVcsQ0FBQyxRQUFRLENBQUMsR0FBRzs0QkFDcEIsTUFBTSxFQUFFLEtBQUssQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsSUFBSSxFQUFFLEdBQUcsQ0FBQzs0QkFDdkQsSUFBSSxFQUFFLFFBQVE7NEJBQ2QsT0FBTyxFQUFFLFFBQVE7NEJBQ2pCLEdBQUcsRUFBRSxLQUFLLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJOzRCQUNqQyxHQUFHLEVBQUUsS0FBSyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQzs0QkFDOUIsT0FBTyxFQUFFLEtBQUssQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUk7NEJBQ3JDLE9BQU8sRUFBRSxLQUFLLEdBQUcsa0JBQWtCOzRCQUNuQyxPQUFPLEVBQUUsVUFBVTt5QkFDdEIsQ0FBQzt3QkFDRixRQUFRLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxDQUFDO3dCQUMxQixJQUFJLEtBQUssQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxLQUFLLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxFQUFFOzRCQUM1RCxPQUFPLENBQUMsSUFBSSxDQUFDO2dDQUNULElBQUksRUFBRSxRQUFRO2dDQUNkLEdBQUcsRUFBRSxLQUFLLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJO2dDQUNqQyxHQUFHLEVBQUUsS0FBSyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztnQ0FDOUIsT0FBTyxFQUFFLEtBQUssQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUk7Z0NBQ3JDLE9BQU8sRUFBRSxLQUFLLEdBQUcsa0JBQWtCO2dDQUNuQyxPQUFPLEVBQUUsVUFBVTs2QkFDdEIsQ0FBQyxDQUFDO3lCQUNOO3dCQUVELGtCQUFrQixFQUFFLENBQUM7cUJBQ3hCO2lCQUNKO2FBQ0o7U0FDSjtRQUNELElBQUksWUFBWSxHQUFHO1lBQ2YsU0FBUyxFQUFFLE9BQU87WUFDbEIsVUFBVSxFQUFFLFFBQVE7WUFDcEIsWUFBWSxFQUFFLFdBQVc7U0FDNUIsQ0FBQztRQUNGLE9BQU8sWUFBWSxDQUFDO0lBQ3hCLENBQUM7SUFFTSxnQkFBZ0IsQ0FBQyxXQUEyQyxFQUFFLEtBQVUsRUFBRSxPQUFxQjtRQUNsRyxJQUFJLFFBQWdCLENBQUM7UUFDckIsV0FBVyxHQUFHLEVBQUUsQ0FBQztRQUNqQixLQUFLLElBQUksQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLEdBQUcsS0FBSyxDQUFDLE1BQU0sRUFBRSxDQUFDLEVBQUUsRUFBRTtZQUNuQyxJQUFJLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLElBQUksU0FBUyxFQUFFO2dCQUM1QixJQUFJLFlBQVksR0FBRyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDO2dCQUNsQyxRQUFRLEdBQUcsSUFBSSxHQUFHLENBQUMsQ0FBQztnQkFDcEIsV0FBVyxDQUFDLFFBQVEsQ0FBQyxHQUFHO29CQUNwQixNQUFNLEVBQUUsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUk7b0JBQ3JCLElBQUksRUFBRSxRQUFRO29CQUNkLE9BQU8sRUFBRSxRQUFRO29CQUNqQixHQUFHLEVBQUUsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUk7b0JBQ2xCLEdBQUcsRUFBRSxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUs7b0JBQzNCLE9BQU8sRUFBRSxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSTtvQkFDdEIsT0FBTyxFQUFFLENBQUMsWUFBWSxJQUFJLFlBQVksSUFBSSxJQUFJLElBQUksWUFBWSxJQUFJLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxZQUFZLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxPQUFPLEVBQUUsQ0FBQyxFQUFFLE9BQU8sQ0FBQztvQkFDeEksYUFBYSxFQUFFLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFO29CQUMxQixVQUFVLEVBQUUsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVE7aUJBQ2hDLENBQUM7YUFDTDtTQUNKO1FBQ0QsT0FBTyxXQUFXLENBQUM7SUFDdkIsQ0FBQztJQUVNLGdCQUFnQixDQUFDLFFBQWEsRUFBRSxZQUFvQixFQUFFLE9BQXFCO1FBQzlFLElBQUksUUFBUSxLQUFLLE9BQU87WUFBRSxPQUFPLFFBQVEsQ0FBQztRQUUxQyxJQUFJLFlBQVksSUFBSSxZQUFZLEtBQUssQ0FBQyxFQUFFO1lBQ3BDLE9BQU8sT0FBTyxDQUFDLE1BQU0sQ0FBQyxZQUFZLEdBQUcsT0FBTyxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsQ0FBQztTQUMvRDtJQUNMLENBQUM7SUFFTSxxQkFBcUIsQ0FBQyxZQUF3QixFQUFFLGdCQUF3QixFQUFFLFlBQW9CLEVBQUUsZUFBZ0Q7UUFDbkosSUFBSSxXQUFXLEdBQW1DLEVBQUUsQ0FBQztRQUNyRCxLQUFLLElBQUksQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLEdBQUcsWUFBWSxDQUFDLE1BQU0sRUFBRSxDQUFDLEVBQUUsRUFBRTtZQUMxQyxJQUFJLFFBQVEsR0FBVyxJQUFJLEdBQUcsQ0FBQyxDQUFDO1lBQ2hDLFdBQVcsQ0FBQyxRQUFRLENBQUMsR0FBRztnQkFDcEIsTUFBTSxFQUFFLFlBQVksQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLGdCQUFnQixDQUFDLEdBQUcsWUFBWSxHQUFHLEtBQUssR0FBRyxZQUFZLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLE9BQU8sQ0FBQyxnQkFBZ0IsQ0FBQyxHQUFHLFlBQVk7Z0JBQzNJLElBQUksRUFBRSxRQUFRO2dCQUNkLE9BQU8sRUFBRSxRQUFRO2dCQUNqQixPQUFPLEVBQUUsWUFBWSxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUs7Z0JBQzlCLFVBQVUsRUFBRSxlQUFlLElBQUksZUFBZSxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxlQUFlLENBQUMsUUFBUSxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxLQUFLO2FBQ3hHLENBQUM7U0FFTDtRQUNELE9BQU8sV0FBVyxDQUFDO0lBQ3ZCLENBQUM7OztZQWhsQ0osVUFBVTs7O1lBckJGLFlBQVkiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBJbmplY3RhYmxlIH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XHJcbmltcG9ydCB7IEtkRG9tRWxlbVN2YyB9IGZyb20gJy4uL2tkLWNvbW1vbi9pbmRleCc7XHJcbmltcG9ydCAqIGFzIGQzIGZyb20gJ2QzJztcclxuaW1wb3J0ICogYXMgaGVscGVyIGZyb20gJy4vaGVscGVyLXN2Yy9pbmRleCc7XHJcbmltcG9ydCB7XHJcbiAgICBJU2VyaWVzLFxyXG4gICAgSUNoYXJ0Q29uZmlnLFxyXG4gICAgSUNoYXJ0TWFyZ2luLFxyXG4gICAgSVlBeGlzQ29uZmlnLFxyXG4gICAgSUNoYXJ0RGF0YSxcclxuICAgIElEM0RhdGFEYXRhLFxyXG4gICAgSU1heE1pbkludGVydmFsLFxyXG4gICAgSUQzRGF0YVJhbmdlLFxyXG4gICAgSUxlZ2VuZERhdGEsXHJcbiAgICBJRm9yTG9vcEluZm8sXHJcbiAgICBJQXhpc0xhYmVsQm9vbGVhbkNoZWNrcyxcclxuICAgIElQbG90T3B0aW9ucyxcclxuICAgIElBeGlzVHJhbnNmb3JtUG9zLFxyXG4gICAgSVhJbmZvLFxyXG4gICAgSVlBeGlzTGFiZWxSYW5nZVxyXG59IGZyb20gJy4va2QtYW5ndWxhci1jaGFydHMtaW50ZXJmYWNlJztcclxuXHJcbkBJbmplY3RhYmxlKClcclxuZXhwb3J0IGNsYXNzIEtkQ2hhcnRzU3ZjIHtcclxuXHJcbiAgICBwcml2YXRlIF9jb25maWc6IElDaGFydENvbmZpZztcclxuICAgIHByaXZhdGUgX3N2ZzogYW55O1xyXG4gICAgcHJpdmF0ZSBfc3ZnUmVjdDogYW55O1xyXG4gICAgcHJpdmF0ZSBfc3ZnUGFyZW50UmVjdDogYW55O1xyXG4gICAgcHJpdmF0ZSBfaXNJbnZlcnQ6IGJvb2xlYW4gPSBmYWxzZTtcclxuICAgIHByaXZhdGUgX2NoYXJ0VHlwZTogQXJyYXk8c3RyaW5nPjtcclxuICAgIHByaXZhdGUgX2NoYXJ0Q2F0ZWdvcnk6ICdwaWUnIHwgJ2JhcicgfCAnY29sdW1uJyB8ICdsaW5lJyB8ICdhcmVhJyB8ICdkb3QnIHwgJ3NwbGluZScgfCAnbWFwJztcclxuICAgIHByaXZhdGUgX2lzUm90YXRlOiBib29sZWFuID0gZmFsc2U7XHJcbiAgICBwcml2YXRlIF9sYWJlbExlbmd0aDogbnVtYmVyO1xyXG4gICAgcHJpdmF0ZSBfY3VyclZlcnRBeGlzVGl0bGU6IEVsZW1lbnQ7XHJcbiAgICBwcml2YXRlIF9pc1J0bDogYm9vbGVhbiA9IGZhbHNlO1xyXG4gICAgcHJpdmF0ZSBfZGVmYXVsdFN2Z01hcmdpbjogeyB0b3A6IG51bWJlcjsgeDogbnVtYmVyOyB5OiBudW1iZXI7IG9wcFZlcnQ6IG51bWJlcjsgfSA9IHtcclxuICAgICAgICB0b3A6IDIwLFxyXG4gICAgICAgIHg6IDksXHJcbiAgICAgICAgeTogMTIsXHJcbiAgICAgICAgb3BwVmVydDogMjBcclxuICAgIH07XHJcbiAgICBwcml2YXRlIF9zdmdNYXJnaW46IHsgdG9wOiBudW1iZXI7IHJpZ2h0OiBudW1iZXI7IGJvdHRvbTogbnVtYmVyOyBsZWZ0OiBudW1iZXI7IH0gPSB7XHJcbiAgICAgICAgdG9wOiAwLFxyXG4gICAgICAgIHJpZ2h0OiAwLFxyXG4gICAgICAgIGJvdHRvbTogMCxcclxuICAgICAgICBsZWZ0OiAwXHJcbiAgICB9O1xyXG4gICAgcHJpdmF0ZSBfeUF4aXNMYWJlbFdpZHRoOiBJWUF4aXNMYWJlbFJhbmdlID0ge1xyXG4gICAgICAgIGF4aXNNYXg6IDAsXHJcbiAgICAgICAgYXhpc01pbjogMFxyXG4gICAgfTtcclxuICAgIHByaXZhdGUgX2F4aXNMYWJlbENvbnRhaW5lcjogYW55O1xyXG4gICAgcHJpdmF0ZSBfYXhpc0xhYmVsRHVtbXk6IGFueTtcclxuICAgIHByaXZhdGUgX2F4aXNMYWJlbENvbnRhaW5lck1hcmdpbkxlZnQ6IG51bWJlcjtcclxuICAgIHByaXZhdGUgX21pblhTcGFjaW5nOiBudW1iZXIgPSA1MDtcclxuICAgIHByaXZhdGUgX3hTcGFjaW5nOiBudW1iZXI7XHJcbiAgICBwcml2YXRlIF94U2NhbGVUeXBlOiAnc3RyaW5nJyB8ICdiYW5kJztcclxuICAgIHByaXZhdGUgX2F4aXNEM0Zvcm1hdDogc3RyaW5nID0gJyc7XHJcbiAgICBwcml2YXRlIF9pc1hSZXZlcnNlZDogYm9vbGVhbiA9IGZhbHNlO1xyXG4gICAgcHJpdmF0ZSBfaXNZUmV2ZXJzZWQ6IGJvb2xlYW4gPSBmYWxzZTtcclxuICAgIHByaXZhdGUgZGF0YUxhYmVsUHVzaERvd25SYW5nZTogbnVtYmVyID0gMDtcclxuICAgIHByaXZhdGUgX2lzTmVnYXRpdmVTdGFjazogYm9vbGVhbiA9IGZhbHNlO1xyXG5cclxuICAgIHB1YmxpYyBncmlkU3ZjOiBoZWxwZXIuS2RDaGFydHNHcmlkU3ZjO1xyXG4gICAgcHVibGljIHRvb2x0aXBTdmM6IGhlbHBlci5LZENoYXJ0c1Rvb2x0aXBTdmM7XHJcblxyXG4gICAgY29uc3RydWN0b3IocHJpdmF0ZSBfZG9tU3ZjOiBLZERvbUVsZW1TdmMpIHtcclxuICAgICAgICB0aGlzLmdyaWRTdmMgPSBuZXcgaGVscGVyLktkQ2hhcnRzR3JpZFN2Yyh0aGlzLl9jb25maWcpO1xyXG4gICAgICAgIHRoaXMudG9vbHRpcFN2YyA9IG5ldyBoZWxwZXIuS2RDaGFydHNUb29sdGlwU3ZjKCk7XHJcbiAgICB9XHJcblxyXG4gICAgc2V0IGNvbmZpZyhfY29uZmlnKSB7XHJcbiAgICAgICAgdGhpcy5fY29uZmlnID0gX2NvbmZpZztcclxuICAgICAgICB0aGlzLmdyaWRTdmMuY29uZmlnID0gX2NvbmZpZztcclxuICAgIH1cclxuICAgIGdldCBjb25maWcoKTogSUNoYXJ0Q29uZmlnIHsgcmV0dXJuIHRoaXMuX2NvbmZpZzsgfVxyXG5cclxuICAgIHNldCBzdmcoX3N2ZykgeyB0aGlzLl9zdmcgPSBfc3ZnOyB9XHJcblxyXG4gICAgc2V0IHN2Z1JlY3QoX3N2Z1JlY3QpIHsgdGhpcy5fc3ZnUmVjdCA9IF9zdmdSZWN0OyB9XHJcblxyXG4gICAgc2V0IGNoYXJ0VHlwZShfY2hhcnRUeXBlKSB7IHRoaXMuX2NoYXJ0VHlwZSA9IF9jaGFydFR5cGU7IH1cclxuICAgIHNldCBjaGFydENhdGVnb3J5KF9jaGFydENhdGVnb3J5KSB7IHRoaXMuX2NoYXJ0Q2F0ZWdvcnkgPSBfY2hhcnRDYXRlZ29yeTsgfVxyXG5cclxuICAgIHNldCBpc0ludmVydChfaXNJbnZlcnQpIHtcclxuICAgICAgICB0aGlzLl9pc0ludmVydCA9IF9pc0ludmVydDtcclxuICAgICAgICB0aGlzLmdyaWRTdmMuaXNJbnZlcnQgPSBfaXNJbnZlcnQ7XHJcbiAgICB9XHJcblxyXG4gICAgc2V0IHN2Z1BhcmVudFJlY3QoX3N2Z1BhcmVudFJlY3QpIHsgdGhpcy5fc3ZnUGFyZW50UmVjdCA9IF9zdmdQYXJlbnRSZWN0OyB9XHJcblxyXG4gICAgc2V0IGlzUm90YXRlKF9pc1JvdGF0ZSkgeyB0aGlzLl9pc1JvdGF0ZSA9IF9pc1JvdGF0ZTsgfVxyXG4gICAgZ2V0IGlzUm90YXRlKCk6IGJvb2xlYW4geyByZXR1cm4gdGhpcy5faXNSb3RhdGU7IH1cclxuXHJcbiAgICBzZXQgbGFiZWxMZW5ndGgoX2xhYmVsTGVuZ3RoKSB7IHRoaXMuX2xhYmVsTGVuZ3RoID0gX2xhYmVsTGVuZ3RoOyB9XHJcbiAgICBnZXQgbGFiZWxMZW5ndGgoKTogbnVtYmVyIHsgcmV0dXJuIHRoaXMuX2xhYmVsTGVuZ3RoOyB9XHJcblxyXG4gICAgZ2V0IHN2Z01hcmdpbigpIHsgcmV0dXJuIHRoaXMuX3N2Z01hcmdpbjsgfVxyXG5cclxuICAgIHNldCB4U2NhbGVUeXBlKF94U2NhbGVUeXBlKSB7IHRoaXMuX3hTY2FsZVR5cGUgPSBfeFNjYWxlVHlwZTsgfVxyXG4gICAgZ2V0IHhTY2FsZVR5cGUoKSB7IHJldHVybiB0aGlzLl94U2NhbGVUeXBlOyB9XHJcblxyXG4gICAgZ2V0IHhTcGFjaW5nKCkgeyByZXR1cm4gdGhpcy5feFNwYWNpbmc7IH1cclxuXHJcbiAgICBnZXQgYXhpc0QzRm9ybWF0KCkgeyByZXR1cm4gdGhpcy5fYXhpc0QzRm9ybWF0OyB9XHJcblxyXG4gICAgZ2V0IHlBeGlzTGFiZWxXaWR0aCgpIHsgcmV0dXJuIHRoaXMuX3lBeGlzTGFiZWxXaWR0aDsgfVxyXG5cclxuICAgIHNldCBpc1J0bChfaXNSdGwpIHsgdGhpcy5faXNSdGwgPSBfaXNSdGw7IH1cclxuXHJcbiAgICBzZXQgaXNYUmV2ZXJzZWQoX2lzWFJldmVyc2VkKSB7XHJcbiAgICAgICAgaWYgKCF0aGlzLl9pc0ludmVydCkge1xyXG4gICAgICAgICAgICB0aGlzLl9pc1hSZXZlcnNlZCA9IF9pc1hSZXZlcnNlZCAhPT0gdGhpcy5faXNSdGw7XHJcbiAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgdGhpcy5faXNYUmV2ZXJzZWQgPSBfaXNYUmV2ZXJzZWQ7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG4gICAgZ2V0IGlzWFJldmVyc2VkKCkgeyByZXR1cm4gdGhpcy5faXNYUmV2ZXJzZWQ7IH1cclxuXHJcbiAgICBzZXQgaXNZUmV2ZXJzZWQoX2lzWVJldmVyc2VkKSB7XHJcbiAgICAgICAgaWYgKHRoaXMuX2lzSW52ZXJ0KSB7XHJcbiAgICAgICAgICAgIHRoaXMuX2lzWVJldmVyc2VkID0gX2lzWVJldmVyc2VkICE9PSB0aGlzLl9pc1J0bDtcclxuICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICB0aGlzLl9pc1lSZXZlcnNlZCA9IF9pc1lSZXZlcnNlZDtcclxuICAgICAgICB9XHJcbiAgICB9XHJcbiAgICBnZXQgaXNZUmV2ZXJzZWQoKSB7IHJldHVybiB0aGlzLl9pc1lSZXZlcnNlZDsgfVxyXG5cclxuICAgIHNldCBpc05lZ2F0aXZlU3RhY2soX2lzTmVnYXRpdmVTdGFjazogYm9vbGVhbikgeyB0aGlzLl9pc05lZ2F0aXZlU3RhY2sgPSBfaXNOZWdhdGl2ZVN0YWNrOyB9XHJcbiAgICBnZXQgaXNOZWdhdGl2ZVN0YWNrKCk6IGJvb2xlYW4geyByZXR1cm4gdGhpcy5faXNOZWdhdGl2ZVN0YWNrOyB9XHJcblxyXG4gICAgLy8gPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09IFZlcnRpY2FsIEF4aXMgPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PVxyXG5cclxuICAgIC8qKlxyXG4gICAgICogZm9yIHJvdGF0aW5nIHZlcnRpY2FsIGF4aXMuIGlmIGF4aXMgaXMgZW5hYmxlZCwgYXBwZW5kcyBjbGFzcy1uYW1lICdyb3RhdGUtdGl0bGUnIHRvIGtkIGNoYXJ0cy5cclxuICAgICAqIHBhcmFtICB7QXJyYXk8c3RyaW5nPn0gX3R5cGUgICBjaGFydCB0eXBlOiBpZiBob3Jpem9udGFsIGJhciwgdXNlIHhBeGlzJ3ModGhlIHZlcnRpY2FsIGF4aXMpIGNvbmZpZ1xyXG4gICAgICogcGFyYW0gIHthbnl9ICAgICAgICAgICBfY29uZmlnXHJcbiAgICAgKiByZXR1cm4ge2Jvb2xlYW59XHJcbiAgICAgKi9cclxuICAgIHB1YmxpYyBjaGVja1JvdGF0ZVRpdGxlRW5hYmxlZChfdHlwZTogQXJyYXk8c3RyaW5nPiwgX2NvbmZpZzogYW55KTogYm9vbGVhbiB7XHJcbiAgICAgICAgbGV0IGF4aXNDb25maWc6IGFueSA9IF90eXBlWzBdID09PSAnYmFyJyA/IF9jb25maWcueEF4aXMgOiBfY29uZmlnLnlBeGlzO1xyXG4gICAgICAgIHJldHVybiBheGlzQ29uZmlnLmVuYWJsZWQgJiYgYXhpc0NvbmZpZy50aXRsZS50ZXh0ICE9PSAnJztcclxuICAgIH1cclxuXHJcbiAgICBwdWJsaWMgc2V0VmVydEF4aXNBbmRDaGFydE1hcmdpbihfaWQ6IHN0cmluZyk6IHZvaWQge1xyXG4gICAgICAgIGxldCBjaGFydENvbnRhaW5lcjogRWxlbWVudCA9IGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3IoJyMnICsgX2lkICsgJy5rZHgtY2hhcnRzIC5rZHgtY2hhcnQtY29udGFpbmVyJyk7XHJcbiAgICAgICAgbGV0IGF4aXNDb25maWc6IGFueSA9IHRoaXMuX2lzSW52ZXJ0ID8gdGhpcy5fY29uZmlnLnhBeGlzIDogdGhpcy5fY29uZmlnLnlBeGlzO1xyXG5cclxuICAgICAgICAvLyBzZXR0aW5nIGNzcyBmb3IgdmVydGljYWwgYXhpc1xyXG4gICAgICAgIGlmIChheGlzQ29uZmlnLmVuYWJsZWQgJiYgYXhpc0NvbmZpZy50aXRsZS50ZXh0ICE9PSAnJykge1xyXG4gICAgICAgICAgICBsZXQgY3VyckF4aXNUaXRsZUNsYXNzOiBzdHJpbmcgPSB0aGlzLl9pc0ludmVydCA/ICcua2R4LWNoYXJ0cy1heGlzLXRpdGxlLXgnIDogJy5rZHgtY2hhcnRzLWF4aXMtdGl0bGUteSc7XHJcbiAgICAgICAgICAgIHRoaXMuX2N1cnJWZXJ0QXhpc1RpdGxlID0gZG9jdW1lbnQucXVlcnlTZWxlY3RvcignIycgKyBfaWQgKyAnLmtkeC1jaGFydHMgJyArIGN1cnJBeGlzVGl0bGVDbGFzcyArICcua2R4LWNoYXJ0cy1heGlzLXRpdGxlJyk7XHJcbiAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgdGhpcy5fY3VyclZlcnRBeGlzVGl0bGUgPSBudWxsO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgdGhpcy5zZXRDaGFydENvbnRhaW5lck1hcmdpbihjaGFydENvbnRhaW5lcik7XHJcbiAgICB9XHJcblxyXG4gICAgcHVibGljIHJlcG9zaXRpb25WZXJ0aWNhbEF4aXNUaXRsZSgpOiB2b2lkIHtcclxuICAgICAgICBpZiAoIXRoaXMuaXNWYWx1ZUV4aXN0KHRoaXMuX2N1cnJWZXJ0QXhpc1RpdGxlKSkgcmV0dXJuO1xyXG5cclxuICAgICAgICBsZXQgYXhpc1RpdGxlQ2xhc3M6IHN0cmluZyA9IHRoaXMuX2lzSW52ZXJ0ID8gJy5rZHgtY2hhcnRzLWF4aXMtdGl0bGUteCcgOiAnLmtkeC1jaGFydHMtYXhpcy10aXRsZS15JztcclxuICAgICAgICBsZXQgYXhpc1RpdGxlVGV4dEFycjogYW55ID0gZG9jdW1lbnQucXVlcnlTZWxlY3RvckFsbCgnIycgKyB0aGlzLl9jb25maWcuaWQgKyAnLmtkeC1jaGFydHMgJyArIGF4aXNUaXRsZUNsYXNzICsgJyAua2R4LWNoYXJ0cy1heGlzLXRpdGxlLXRleHQnKTtcclxuICAgICAgICBheGlzVGl0bGVUZXh0QXJyLmZvckVhY2goYXhpc1RpdGxlVGV4dCA9PiB7XHJcbiAgICAgICAgICAgIGF4aXNUaXRsZVRleHQuc3R5bGUudG9wID0gdGhpcy5fY3VyclZlcnRBeGlzVGl0bGUuZ2V0Qm91bmRpbmdDbGllbnRSZWN0KCkuaGVpZ2h0IC8gMiArIGF4aXNUaXRsZVRleHQuZ2V0Qm91bmRpbmdDbGllbnRSZWN0KCkuaGVpZ2h0IC8gMiArICdweCc7XHJcbiAgICAgICAgICAgIGF4aXNUaXRsZVRleHQuc3R5bGUudmlzaWJpbGl0eSA9ICd1bnNldCc7XHJcbiAgICAgICAgfSk7XHJcbiAgICB9XHJcblxyXG4gICAgLy8gPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09IFkgQXhpcyBMYWJlbCA9PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09XHJcblxyXG4gICAgcHVibGljIHNldE1heEFuZE1pbihfeUF4aXNDb25maWc6IElZQXhpc0NvbmZpZywgX2RhdGFSYW5nZTogSUQzRGF0YVJhbmdlKTogSU1heE1pbkludGVydmFsIHtcclxuICAgICAgICBsZXQgbWF4VmFsdWU6IG51bWJlciA9IHRoaXMuaXNWYWx1ZUV4aXN0KF95QXhpc0NvbmZpZy5tYXhWYWx1ZSkgPyBfeUF4aXNDb25maWcubWF4VmFsdWUgOiBfZGF0YVJhbmdlLm1heDtcclxuICAgICAgICBsZXQgbWluVmFsdWU6IG51bWJlciA9IHRoaXMuaXNWYWx1ZUV4aXN0KF95QXhpc0NvbmZpZy5taW5WYWx1ZSkgPyBfeUF4aXNDb25maWcubWluVmFsdWUgOiBfZGF0YVJhbmdlLm1pbjtcclxuXHJcbiAgICAgICAgLy8gZW5zdXJlIHRoYXQgbWluIHZhbHVlIHdpbGwgbm90IGV4Y2VlZCBtYXgsIHZpY2UgdmVyc2VcclxuICAgICAgICBtYXhWYWx1ZSA9IE1hdGgubWF4KG1heFZhbHVlLCBtaW5WYWx1ZSk7XHJcbiAgICAgICAgbWluVmFsdWUgPSBNYXRoLm1pbihtYXhWYWx1ZSwgbWluVmFsdWUpO1xyXG5cclxuICAgICAgICBsZXQgaW50ZXJ2YWw6IG51bWJlciA9IGQzLm1heChbX3lBeGlzQ29uZmlnLnRpY2tJbnRlcnZhbCwgX3lBeGlzQ29uZmlnLm1pbm9yVGlja0ludGVydmFsXSk7XHJcblxyXG4gICAgICAgIGlmICghaW50ZXJ2YWwgfHwgaW50ZXJ2YWwgPD0gMCkgaW50ZXJ2YWwgPSAxO1xyXG5cclxuICAgICAgICAvLyB0byBwcmV2ZW50IHRpY2sgY2FsY3VsYXRpb24gY2F1c2luZyBzdG9wLXNjcmlwdCwgb25seSBhbGxvdyBhdCBtb3N0IGFyb3VuZCAxMDAwIHRpY2tzIChleGNsdWRpbmcgZmlyc3QgdGljaylcclxuICAgICAgICBsZXQgc21hbGxlc3RQb3NzaWJsZUludGVydmFsOiBudW1iZXIgPSAobWF4VmFsdWUgLSBtaW5WYWx1ZSkgLyAxMDAwO1xyXG4gICAgICAgIGlmIChzbWFsbGVzdFBvc3NpYmxlSW50ZXJ2YWwgPiBpbnRlcnZhbCkge1xyXG4gICAgICAgICAgICBpbnRlcnZhbCA9IHRoaXMuaXNJbnRlcmdlcihpbnRlcnZhbCkgPyBNYXRoLmZsb29yKHNtYWxsZXN0UG9zc2libGVJbnRlcnZhbCkgOiBzbWFsbGVzdFBvc3NpYmxlSW50ZXJ2YWw7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICByZXR1cm4ge1xyXG4gICAgICAgICAgICBtYXhWYWx1ZTogbWF4VmFsdWUsXHJcbiAgICAgICAgICAgIG1pblZhbHVlOiBtaW5WYWx1ZSxcclxuICAgICAgICAgICAgaW50ZXJ2YWw6IGludGVydmFsXHJcbiAgICAgICAgfTtcclxuICAgIH1cclxuXHJcbiAgICBwdWJsaWMgc2V0QXhpc0QzRm9ybWF0KF9pbnRlcnZhbDogbnVtYmVyKTogdm9pZCB7XHJcbiAgICAgICAgbGV0IGRlY2ltYWxQbGFjZTogbnVtYmVyID0gdGhpcy5maW5kRGVjaW1hbFBsYWNlKF9pbnRlcnZhbCk7XHJcbiAgICAgICAgdGhpcy5fYXhpc0QzRm9ybWF0ID0gdGhpcy5nZXREM0Zvcm1hdChfaW50ZXJ2YWwsIGRlY2ltYWxQbGFjZSk7XHJcbiAgICB9XHJcblxyXG4gICAgcHVibGljIGdldFlBeGlzTGFiZWxUZXh0KF95QXhpc0NvbmZpZzogSVlBeGlzQ29uZmlnLCBfdmFsdWU6IG51bWJlcik6IHN0cmluZyB7XHJcbiAgICAgICAgcmV0dXJuIHRoaXMuZ2V0TGFiZWxUZXh0KF95QXhpc0NvbmZpZy5sYWJlbHMuZm9ybWF0LCBfdmFsdWUsIGZhbHNlLCB0aGlzLl9heGlzRDNGb3JtYXQpO1xyXG4gICAgfVxyXG5cclxuICAgIC8qKlxyXG4gICAgICogWSBheGlzIGxhYmVsIGR1bW15LiBhcHBlbmRzIHRleHQgZWxlbWVudCB0byBzdmcgYW5kIHJldHVybnMgdGhlIHdpZHRoIG9mIGxhYmVsXHJcbiAgICAgKiBwYXJhbSAge251bWJlciB8ICAgICAgc3RyaW5nfSAgICAgIF92YWx1ZTogbGFiZWwncyB2YWx1ZVxyXG4gICAgICogcGFyYW0gIHtzdHJpbmd9ICAgICAgICAgICAgICAgICAgICBfY2xhc3M6IGNsYXNzIG5hbWUgZm9yIGR1bW15XHJcbiAgICAgKiByZXR1cm4ge251bWJlcn0gICAgICAgICAgICAgICAgICAgIHJldHVybnMgYWN0dWFsIHJlbmRlcmVkIHdpZHRoIG9mIGxhYmVsXHJcbiAgICAgKi9cclxuICAgIHB1YmxpYyBzZXREdW1teUF4aXNMYWJlbChfdmFsdWU6IG51bWJlciwgX2NsYXNzOiBzdHJpbmcpOiBudW1iZXIge1xyXG4gICAgICAgIC8vIGlmICghdGhpcy5fY29uZmlnLnlBeGlzLmVuYWJsZWQpIHJldHVybiAwO1xyXG5cclxuICAgICAgICBsZXQgeUF4aXNDb25maWc6IElZQXhpc0NvbmZpZyA9IHRoaXMuX2NvbmZpZy55QXhpcztcclxuXHJcbiAgICAgICAgLy8gaWYgYXhpcyBpcyBlbmFibGVkLCBkcmF3IGF4aXNNYXggc3RyaW5nIGFuZCBheGlzTWluIHN0cmluZyB0byBjb21wdXRlIHRoaXMud2lkdGgvaGVpZ2h0XHJcbiAgICAgICAgbGV0IHRleHRTZWxlY3Rpb246IGFueSA9IHRoaXMuX3N2Zy5zZWxlY3RBbGwoJy5kdW1teS0nICsgX2NsYXNzKTtcclxuICAgICAgICBsZXQgdGV4dDogc3RyaW5nID0gdGhpcy5nZXRZQXhpc0xhYmVsVGV4dCh5QXhpc0NvbmZpZywgX3ZhbHVlKTtcclxuXHJcbiAgICAgICAgLy8gZWxlbWVudCBzaG91bGQgb25seSBiZSBhcHBlbmRlZCBvbmNlXHJcbiAgICAgICAgaWYgKHRleHRTZWxlY3Rpb24uZW1wdHkoKSkgdGV4dFNlbGVjdGlvbiA9IHRoaXMuX3N2Zy5hcHBlbmQoJ3RleHQnKTtcclxuXHJcbiAgICAgICAgdGhpcy5zZXRTdmdBdHRyaWJ1dGUodGV4dFNlbGVjdGlvbiwgT2JqZWN0LmFzc2lnbih7fSwgeUF4aXNDb25maWcubGFiZWxzLnN0eWxlLCB7IGNsYXNzOiAna2R4LWNoYXJ0cy1kdW1teSBkdW1teS0nICsgX2NsYXNzLCBvcGFjaXR5OiAwIH0pKTtcclxuXHJcbiAgICAgICAgdGV4dFNlbGVjdGlvbi50ZXh0KHRleHQpO1xyXG5cclxuICAgICAgICByZXR1cm4gdGV4dFNlbGVjdGlvbi5ub2RlKCkuZ2V0QkJveCgpLndpZHRoO1xyXG4gICAgfVxyXG5cclxuICAgIC8qKlxyXG4gICAgICogY2hhcnQgd2lkdGggYW5kIGhlaWdodCBoYXZlIHRvIGJlIGNhbGN1bGF0ZWQgYmFzZWQgb24gaG93IGxvbmcgeSBheGlzIGxhYmVscyBhcmUgKGVnOiBhIGxvdCBvZiBzcGFjZSBhbGxvY2F0ZWQgZm9yIDEsMDAwLDAwMCBhcyBjb21wYXJlZCB0byAxMClcclxuICAgICAqIHJldHVybnMgdGhpcy53aWR0aCBvciB0aGlzLmhlaWdodCBkZXBlbmRpbmcgb24gX2F4aXMgZ2l2ZW5cclxuICAgICAqIHBhcmFtICB7J3gnfCd5J30gICAgICAgICBfYXhpc1xyXG4gICAgICogcGFyYW0gIHsgYXhpc01heDogbnVtYmVyLCBheGlzTWluOiBudW1iZXIgfSBfYXhpc1ZhbFxyXG4gICAgICogcmV0dXJuIHtudW1iZXJ9XHJcbiAgICAgKi9cclxuICAgIHB1YmxpYyBnZXRTdmdPZmZzZXQoX2F4aXM6ICd4JyB8ICd5JywgX2F4aXNWYWw6IElZQXhpc0xhYmVsUmFuZ2UpOiBudW1iZXIge1xyXG4gICAgICAgIGxldCBheGlzT3Bwb3NpdGU6IGJvb2xlYW4gPSBfYXhpcyA9PT0gJ3gnID8gdGhpcy5fY29uZmlnLnlBeGlzLm9wcG9zaXRlIDogdGhpcy5fY29uZmlnLnhBeGlzLm9wcG9zaXRlO1xyXG4gICAgICAgIGxldCBvcHBvc2l0ZTogYm9vbGVhbiA9IGF4aXNPcHBvc2l0ZSAhPT0gdGhpcy5faXNSdGw7XHJcbiAgICAgICAgbGV0IHlBeGlzTGFiZWxzTm90VmlzaWJsZTogYm9vbGVhbiA9ICF0aGlzLl9jb25maWcueUF4aXMuZW5hYmxlZCB8fCAhdGhpcy5fY29uZmlnLnlBeGlzLmxhYmVscy5lbmFibGVkO1xyXG5cclxuICAgICAgICBpZiAoX2F4aXMgPT09ICd4JykgdGhpcy5feUF4aXNMYWJlbFdpZHRoID0gdGhpcy5nZXRZQXhpc01heEFuZE1pbkxhYmVsV2lkdGgoX2F4aXNWYWwpO1xyXG5cclxuICAgICAgICBsZXQgaW50ZXJuYWxZQXhpc0xhYmVsV2lkdGg6IHsgYXhpc01heDogbnVtYmVyLCBheGlzTWluOiBudW1iZXIgfSA9IHRoaXMuX3lBeGlzTGFiZWxXaWR0aDtcclxuICAgICAgICBpZiAoeUF4aXNMYWJlbHNOb3RWaXNpYmxlKSBpbnRlcm5hbFlBeGlzTGFiZWxXaWR0aCA9IHsgYXhpc01heDogMCwgYXhpc01pbjogMCB9O1xyXG5cclxuICAgICAgICBpZiAoIXRoaXMuX2lzSW52ZXJ0KSB7XHJcbiAgICAgICAgICAgIGlmIChfYXhpcyA9PT0gJ3gnKSB7XHJcbiAgICAgICAgICAgICAgICBsZXQgc3RhcnQ6ICdyaWdodCcgfCAnbGVmdCcgPSBvcHBvc2l0ZSA/ICdyaWdodCcgOiAnbGVmdCc7XHJcbiAgICAgICAgICAgICAgICBsZXQgZW5kOiAncmlnaHQnIHwgJ2xlZnQnID0gb3Bwb3NpdGUgPyAnbGVmdCcgOiAncmlnaHQnO1xyXG4gICAgICAgICAgICAgICAgdGhpcy5fc3ZnTWFyZ2luW3N0YXJ0XSA9IHRoaXMuX2RlZmF1bHRTdmdNYXJnaW4ueSArIE1hdGgubWF4KGludGVybmFsWUF4aXNMYWJlbFdpZHRoLmF4aXNNYXgsIGludGVybmFsWUF4aXNMYWJlbFdpZHRoLmF4aXNNaW4pO1xyXG4gICAgICAgICAgICAgICAgdGhpcy5fc3ZnTWFyZ2luW2VuZF0gPSB0aGlzLl9kZWZhdWx0U3ZnTWFyZ2luLm9wcFZlcnQ7XHJcbiAgICAgICAgICAgICAgICByZXR1cm4gdGhpcy5fc3ZnUmVjdC53aWR0aCAtIHRoaXMuX3N2Z01hcmdpbltzdGFydF0gLSB0aGlzLl9zdmdNYXJnaW5bZW5kXTtcclxuICAgICAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgICAgIGxldCBzdGFydDogJ3RvcCcgfCAnYm90dG9tJyA9IGF4aXNPcHBvc2l0ZSA/ICdib3R0b20nIDogJ3RvcCc7XHJcbiAgICAgICAgICAgICAgICBsZXQgZW5kOiAndG9wJyB8ICdib3R0b20nID0gYXhpc09wcG9zaXRlID8gJ3RvcCcgOiAnYm90dG9tJztcclxuICAgICAgICAgICAgICAgIGxldCBsYWJlbEZvbnRTaXplOiBudW1iZXIgPSB5QXhpc0xhYmVsc05vdFZpc2libGUgPyAwIDogdGhpcy5yZXBsYWNlU3RyaW5nV2l0aE51bWJlcih0aGlzLl9jb25maWcueUF4aXMubGFiZWxzLnN0eWxlLmZvbnRTaXplKTtcclxuICAgICAgICAgICAgICAgIHRoaXMuX3N2Z01hcmdpbltlbmRdID0gTWF0aC5tYXgodGhpcy5fZGVmYXVsdFN2Z01hcmdpbi54LCAwLjUgKiBsYWJlbEZvbnRTaXplKTtcclxuICAgICAgICAgICAgICAgIHRoaXMuX3N2Z01hcmdpbltzdGFydF0gPSB0aGlzLmlzTmVnYXRpdmVTdGFjayA/IHRoaXMuX3N2Z01hcmdpbltlbmRdIDogdGhpcy5fZGVmYXVsdFN2Z01hcmdpbi50b3A7XHJcbiAgICAgICAgICAgICAgICByZXR1cm4gdGhpcy5fc3ZnUmVjdC5oZWlnaHQgLSB0aGlzLl9zdmdNYXJnaW5bc3RhcnRdIC0gdGhpcy5fc3ZnTWFyZ2luW2VuZF07XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICBpZiAoX2F4aXMgPT09ICd4Jykge1xyXG4gICAgICAgICAgICAgICAgbGV0IHN0YXJ0OiAndG9wJyB8ICdib3R0b20nID0gYXhpc09wcG9zaXRlID8gJ2JvdHRvbScgOiAndG9wJztcclxuICAgICAgICAgICAgICAgIGxldCBlbmQ6ICd0b3AnIHwgJ2JvdHRvbScgPSBheGlzT3Bwb3NpdGUgPyAndG9wJyA6ICdib3R0b20nO1xyXG4gICAgICAgICAgICAgICAgbGV0IGxhYmVsRm9udFNpemU6IG51bWJlciA9IHlBeGlzTGFiZWxzTm90VmlzaWJsZSA/IDAgOiB0aGlzLnJlcGxhY2VTdHJpbmdXaXRoTnVtYmVyKHRoaXMuX2NvbmZpZy55QXhpcy5sYWJlbHMuc3R5bGUuZm9udFNpemUpO1xyXG4gICAgICAgICAgICAgICAgdGhpcy5fc3ZnTWFyZ2luW3N0YXJ0XSA9IHRoaXMuX2RlZmF1bHRTdmdNYXJnaW4udG9wO1xyXG4gICAgICAgICAgICAgICAgdGhpcy5fc3ZnTWFyZ2luW2VuZF0gPSB0aGlzLl9kZWZhdWx0U3ZnTWFyZ2luLnkgKyBsYWJlbEZvbnRTaXplO1xyXG4gICAgICAgICAgICAgICAgcmV0dXJuIHRoaXMuX3N2Z1JlY3QuaGVpZ2h0IC0gdGhpcy5fc3ZnTWFyZ2luW3N0YXJ0XSAtIHRoaXMuX3N2Z01hcmdpbltlbmRdO1xyXG4gICAgICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgbGV0IHN0YXJ0OiAncmlnaHQnIHwgJ2xlZnQnID0gb3Bwb3NpdGUgPyAncmlnaHQnIDogJ2xlZnQnO1xyXG4gICAgICAgICAgICAgICAgbGV0IGVuZDogJ3JpZ2h0JyB8ICdsZWZ0JyA9IG9wcG9zaXRlID8gJ2xlZnQnIDogJ3JpZ2h0JztcclxuICAgICAgICAgICAgICAgIGxldCBzdGFydExhYmVsV2lkdGg6IG51bWJlciA9IG9wcG9zaXRlID09PSB0aGlzLmlzWVJldmVyc2VkID8gaW50ZXJuYWxZQXhpc0xhYmVsV2lkdGguYXhpc01pbiA6IGludGVybmFsWUF4aXNMYWJlbFdpZHRoLmF4aXNNYXg7XHJcbiAgICAgICAgICAgICAgICBsZXQgZW5kTGFiZWxXaWR0aDogbnVtYmVyID0gb3Bwb3NpdGUgPT09IHRoaXMuaXNZUmV2ZXJzZWQgPyBpbnRlcm5hbFlBeGlzTGFiZWxXaWR0aC5heGlzTWF4IDogaW50ZXJuYWxZQXhpc0xhYmVsV2lkdGguYXhpc01pbjtcclxuICAgICAgICAgICAgICAgIHRoaXMuX3N2Z01hcmdpbltzdGFydF0gPSBNYXRoLm1heCh0aGlzLl9kZWZhdWx0U3ZnTWFyZ2luLngsIHN0YXJ0TGFiZWxXaWR0aCAvIDIpO1xyXG4gICAgICAgICAgICAgICAgdGhpcy5fc3ZnTWFyZ2luW2VuZF0gPSB0aGlzLmlzTmVnYXRpdmVTdGFjayA/IE1hdGgubWF4KHRoaXMuX2RlZmF1bHRTdmdNYXJnaW4ueCwgZW5kTGFiZWxXaWR0aCAvIDIpIDogZW5kTGFiZWxXaWR0aCAvIDIgKyB0aGlzLl9kZWZhdWx0U3ZnTWFyZ2luLm9wcFZlcnQ7XHJcbiAgICAgICAgICAgICAgICByZXR1cm4gdGhpcy5fc3ZnUmVjdC53aWR0aCAtIHRoaXMuX3N2Z01hcmdpbltzdGFydF0gLSB0aGlzLl9zdmdNYXJnaW5bZW5kXTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICAvKipcclxuICAgICAqIHJvdW5kIGF4aXNNYXgvTWluIHZhbHVlIHRvIGludGVydmFsIChlZzogTWF4IHZhbHVlIGlzIDEwIGJ1dCBpbnRlcnZhbCBpcyAzLCBzbyBtYXggdmFsdWUgd2lsbCBiZSByb3VuZGVkIHRvIGVpdGhlciA5IG9yIDEyKVxyXG4gICAgICogX2lzQXV0b1JvdW5kVG9OZXh0SW50ZXJ2YWwgaXMgZW5hYmxlZCwgcm91bmQgdG8gMTJcclxuICAgICAqIF9pc0F1dG9Sb3VuZFRvTmV4dEludGVydmFsIGlzIGRpc2FibGVkLCByb3VuZCB0byA5XHJcbiAgICAgKlxyXG4gICAgICogcGFyYW0gIHtudW1iZXJ9ICBfdmFsdWVcclxuICAgICAqIHBhcmFtICB7bnVtYmVyfSAgX2ludGVydmFsXHJcbiAgICAgKiBwYXJhbSAge2Jvb2xlYW59IF9pc0F1dG9Sb3VuZFRvTmV4dEludGVydmFsXHJcbiAgICAgKiBwYXJhbSAgeyd1cCcgfCAnZG93bid9ICAgICAgX3JvdW5kRGlyXHJcbiAgICAgKiByZXR1cm4ge251bWJlcn1cclxuICAgICAqL1xyXG4gICAgcHVibGljIHNldEF4aXNSb3VuZFZhbHVlKF92YWx1ZTogbnVtYmVyLCBfaW50ZXJ2YWw6IG51bWJlciwgX2lzQXV0b1JvdW5kVG9OZXh0SW50ZXJ2YWw6IGJvb2xlYW4sIF9yb3VuZERpcjogJ3VwJyB8ICdkb3duJyk6IG51bWJlciB7XHJcbiAgICAgICAgLy8gaWYgdmFsdWUgaXMgMCwgZG9uJ3Qgcm91bmRcclxuICAgICAgICBpZiAoX3ZhbHVlID09PSAwKSByZXR1cm4gX3ZhbHVlO1xyXG5cclxuICAgICAgICBsZXQgZGVjaW1hbFBsYWNlczogbnVtYmVyID0gTWF0aC5tYXgodGhpcy5maW5kRGVjaW1hbFBsYWNlKF92YWx1ZSksIHRoaXMuZmluZERlY2ltYWxQbGFjZShfaW50ZXJ2YWwpKTtcclxuXHJcbiAgICAgICAgaWYgKGRlY2ltYWxQbGFjZXMgIT09IDApIHtcclxuICAgICAgICAgICAgLy8gaWYgX3ZhbHVlIG9yIF9pbnRlcnZhbCBoYXZlIGRlY2ltYWwsIGNvbnZlcnQgdGhlbSB0byB3aG9sZSBudW1iZXJzXHJcbiAgICAgICAgICAgIF92YWx1ZSA9IF92YWx1ZSAqIE1hdGgucG93KDEwLCBkZWNpbWFsUGxhY2VzKTtcclxuICAgICAgICAgICAgX2ludGVydmFsID0gX2ludGVydmFsICogTWF0aC5wb3coMTAsIGRlY2ltYWxQbGFjZXMpO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgbGV0IHNpZ246IG51bWJlciA9IE1hdGguc2lnbihfdmFsdWUpO1xyXG4gICAgICAgIGxldCBuZXdWYWx1ZTogbnVtYmVyID0gX3ZhbHVlIC0gX3ZhbHVlICUgX2ludGVydmFsO1xyXG5cclxuICAgICAgICBpZiAoX3JvdW5kRGlyID09PSAndXAnKSB7XHJcbiAgICAgICAgICAgIGlmIChzaWduIDwgMCkge1xyXG4gICAgICAgICAgICAgICAgaWYgKCFfaXNBdXRvUm91bmRUb05leHRJbnRlcnZhbCkgbmV3VmFsdWUgPSBuZXdWYWx1ZSAtIF9pbnRlcnZhbDtcclxuICAgICAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgICAgIGlmIChfaXNBdXRvUm91bmRUb05leHRJbnRlcnZhbCkgbmV3VmFsdWUgPSBuZXdWYWx1ZSArIF9pbnRlcnZhbDtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgIGlmIChzaWduIDwgMCkge1xyXG4gICAgICAgICAgICAgICAgaWYgKF9pc0F1dG9Sb3VuZFRvTmV4dEludGVydmFsKSBuZXdWYWx1ZSA9IG5ld1ZhbHVlIC0gX2ludGVydmFsO1xyXG4gICAgICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgaWYgKCFfaXNBdXRvUm91bmRUb05leHRJbnRlcnZhbCkgbmV3VmFsdWUgPSBuZXdWYWx1ZSArIF9pbnRlcnZhbDtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgaWYgKGRlY2ltYWxQbGFjZXMgIT09IDApIG5ld1ZhbHVlID0gbmV3VmFsdWUgLyBNYXRoLnBvdygxMCwgZGVjaW1hbFBsYWNlcyk7XHJcblxyXG4gICAgICAgIHJldHVybiBuZXdWYWx1ZTtcclxuICAgIH1cclxuXHJcbiAgICBwdWJsaWMgZ2V0VGlja1ZhbHVlcyhfbWluOiBudW1iZXIsIF9tYXg6IG51bWJlciwgX2ludGVydmFsOiBudW1iZXIpOiBBcnJheTxudW1iZXI+IHtcclxuICAgICAgICBpZiAoIV9pbnRlcnZhbCB8fCB0eXBlb2YgX21pbiA9PT0gJ3VuZGVmaW5lZCcgfHwgdHlwZW9mIF9tYXggPT09ICd1bmRlZmluZWQnKSByZXR1cm4gW107XHJcblxyXG4gICAgICAgIF9tYXggPSB0aGlzLl9nZXRVcHBlckJvdW5kRm9yVGlja1ZhbHVlcyhfbWF4LCBfaW50ZXJ2YWwpO1xyXG5cclxuICAgICAgICByZXR1cm4gZDMucmFuZ2UoX21pbiwgX21heCwgX2ludGVydmFsKTtcclxuICAgIH1cclxuXHJcbiAgICAvKipcclxuICAgICAqIHNldCBZIGF4aXMgTGFiZWwgQ29uZmlnXHJcbiAgICAgKiBwYXJhbSB7YW55fSAgICAgICAgX2F4aXMgaXMgRWxlbWVudC9kMy1zZWxlY3Rpb25cclxuICAgICAqIHBhcmFtIHsneEF4aXMnIHwgJ3lBeGlzJ30gICAgIF9kaXJlY3Rpb25cclxuICAgICAqL1xyXG4gICAgcHVibGljIHNldEF4aXNMYWJlbENvbmZpZyhfYXhpczogYW55LCBfZGlyZWN0aW9uOiAneCcgfCAneScpOiB2b2lkIHtcclxuICAgICAgICBsZXQgYXhpc0Rpcjogc3RyaW5nID0gX2RpcmVjdGlvbiArICdBeGlzJztcclxuICAgICAgICBpZiAoIXRoaXMuX2NvbmZpZ1theGlzRGlyXSkgcmV0dXJuO1xyXG4gICAgICAgIGxldCBheGlzQ29uZmlnID0gdGhpcy5fY29uZmlnW2F4aXNEaXJdO1xyXG5cclxuICAgICAgICBfYXhpcy5zZWxlY3RBbGwoJ3BhdGgnKVxyXG4gICAgICAgICAgICAuYXR0cignc3Ryb2tlLXdpZHRoJywgYXhpc0NvbmZpZy5saW5lV2lkdGgpXHJcbiAgICAgICAgICAgIC5hdHRyKCdzdHJva2UnLCBheGlzQ29uZmlnLmxpbmVDb2xvcik7XHJcblxyXG4gICAgICAgIF9heGlzLnNlbGVjdEFsbCgnbGluZScpXHJcbiAgICAgICAgICAgIC5hdHRyKCdzdHJva2Utd2lkdGgnLCBheGlzQ29uZmlnLmxpbmVXaWR0aClcclxuICAgICAgICAgICAgLmF0dHIoJ3N0cm9rZScsIGF4aXNDb25maWcubGluZUNvbG9yKTtcclxuXHJcbiAgICAgICAgaWYgKF9kaXJlY3Rpb24gPT09ICd4JyB8fCAhYXhpc0NvbmZpZy5lbmFibGVkIHx8ICF0aGlzLl9jb25maWdbYXhpc0Rpcl0ubGFiZWxzLmVuYWJsZWQpIHtcclxuICAgICAgICAgICAgdGhpcy5zZXRTdmdBdHRyaWJ1dGUoX2F4aXMuc2VsZWN0QWxsKCd0ZXh0JyksIHsgZGlzcGxheTogJ25vbmUnIH0pO1xyXG4gICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgIHRoaXMuc2V0U3ZnQXR0cmlidXRlKF9heGlzLnNlbGVjdEFsbCgndGV4dCcpLCBheGlzQ29uZmlnLmxhYmVscy5zdHlsZSk7XHJcbiAgICAgICAgICAgIHRoaXMuc2V0U3ZnQXR0cmlidXRlKF9heGlzLnNlbGVjdEFsbCgndGV4dCcpLCB7IGNsYXNzOiAna2R4LWNoYXJ0cy1kaXNwbGF5LW51bWJlci1pbnNpZGUtc3ZnIGtkeC1jaGFydHMtZGlzcGxheS1udW1iZXInIH0pO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICBwdWJsaWMgZ2V0WUF4aXNNYXhBbmRNaW5MYWJlbFdpZHRoKF9heGlzVmFsOiBJWUF4aXNMYWJlbFJhbmdlKTogSVlBeGlzTGFiZWxSYW5nZSB7XHJcbiAgICAgICAgbGV0IHdpZHRoT2JqOiBJWUF4aXNMYWJlbFJhbmdlID0geyBheGlzTWF4OiAwLCBheGlzTWluOiAwIH07XHJcblxyXG4gICAgICAgIC8vIGlmICh0aGlzLl9jb25maWcueUF4aXMubGFiZWxzLmVuYWJsZWQpIHtcclxuICAgICAgICB3aWR0aE9iai5heGlzTWF4ID0gdGhpcy5zZXREdW1teUF4aXNMYWJlbChfYXhpc1ZhbC5heGlzTWF4LCAnYXhpc01heCcpO1xyXG4gICAgICAgIHdpZHRoT2JqLmF4aXNNaW4gPSB0aGlzLnNldER1bW15QXhpc0xhYmVsKF9heGlzVmFsLmF4aXNNaW4sICdheGlzTWluJyk7XHJcbiAgICAgICAgLy8gfVxyXG5cclxuICAgICAgICByZXR1cm4gd2lkdGhPYmo7XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfZ2V0VXBwZXJCb3VuZEZvclRpY2tWYWx1ZXMoX21heDogbnVtYmVyLCBfaW50ZXJ2YWw6IG51bWJlcik6IG51bWJlciB7XHJcbiAgICAgICAgbGV0IGRlY2ltYWxQbGFjZXM6IG51bWJlciA9IE1hdGgubWF4KHRoaXMuZmluZERlY2ltYWxQbGFjZShfbWF4KSwgdGhpcy5maW5kRGVjaW1hbFBsYWNlKF9pbnRlcnZhbCkpO1xyXG5cclxuICAgICAgICBfbWF4ID0gX21heCAqIE1hdGgucG93KDEwLCBkZWNpbWFsUGxhY2VzKTtcclxuICAgICAgICBfaW50ZXJ2YWwgPSBfaW50ZXJ2YWwgKiBNYXRoLnBvdygxMCwgZGVjaW1hbFBsYWNlcyk7XHJcblxyXG4gICAgICAgIHJldHVybiAoX21heCArIF9pbnRlcnZhbCkgLyBNYXRoLnBvdygxMCwgZGVjaW1hbFBsYWNlcyk7XHJcbiAgICB9XHJcblxyXG4gICAgLy8gPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09IFggQXhpcyBMYWJlbCA9PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09XHJcblxyXG4gICAgLyoqXHJcbiAgICAgKiBzZXQgYXhpcyBMYWJlbCBDb250YWluZXIgKGN1cnJlbnRseSBvbmx5IHVzZWQgZm9yIFggYXhpcylcclxuICAgICAqIHBhcmFtICB7bnVtYmVyfSBfeFNwYWNpbmdcclxuICAgICAqIHBhcmFtICB7c3RyaW5nfSBfZXh0cmFDbGFzc05hbWUgW3NhbWUgbGV2ZWwgYXMgLmtkeC1jaGFydHMtYXhpcy1sYWJlbC1jb250YWluZXIuIEFkZGl0aW9uYWwgY2xhc3NOYW1lIGluIGNhc2Ugb2YgZG91YmxlQXhpc11cclxuICAgICAqIHJldHVybiB7YW55fVxyXG4gICAgICovXHJcbiAgICBwdWJsaWMgc2V0QXhpc0xhYmVsQ29udGFpbmVyKF9leHRyYUNsYXNzTmFtZTogc3RyaW5nID0gJycpOiBhbnkge1xyXG4gICAgICAgIHRoaXMuX2F4aXNMYWJlbENvbnRhaW5lciA9IGQzLnNlbGVjdCgnIycgKyB0aGlzLl9jb25maWcuaWQgKyAnLmtkeC1jaGFydHMgLmtkeC1jaGFydHMtYXhpcy1sYWJlbC1jb250YWluZXInICsgX2V4dHJhQ2xhc3NOYW1lKTtcclxuICAgICAgICBpZiAoIXRoaXMuaXNWYWx1ZUV4aXN0KHRoaXMuX2F4aXNMYWJlbENvbnRhaW5lci5ub2RlKCkpKSByZXR1cm47XHJcblxyXG4gICAgICAgIHJldHVybiB0aGlzLl9heGlzTGFiZWxDb250YWluZXI7XHJcbiAgICB9XHJcblxyXG4gICAgLyoqKiogQXhpcyBMYWJlbCBEdW1teSAqKioqKioqL1xyXG5cclxuICAgIHB1YmxpYyBzZXRBeGlzTGFiZWxEdW1teShfaWQ6IHN0cmluZywgX3hTcGFjaW5nOiBudW1iZXIsIF9sb25nZXN0VGV4dDogc3RyaW5nKTogdm9pZCB7XHJcbiAgICAgICAgdGhpcy5fc2V0QXhpc0xhYmVsRHVtbXlFbGVtZW50KF9pZCk7XHJcbiAgICAgICAgdGhpcy5zZXRBeGlzTGFiZWxEdW1teVRleHQoX2xvbmdlc3RUZXh0KTtcclxuICAgICAgICB0aGlzLmlzUm90YXRlID0gdGhpcy5fY2hlY2tSb3RhdGUodGhpcy5faXNJbnZlcnQsIF94U3BhY2luZywgdGhpcy5fbWluWFNwYWNpbmcpO1xyXG4gICAgICAgIHRoaXMuX3NldEF4aXNMYWJlbER1bW15U3R5bGUoX3hTcGFjaW5nKTtcclxuICAgIH1cclxuXHJcbiAgICBwdWJsaWMgc2V0QXhpc0xhYmVsRHVtbXlUZXh0KF9sb25nZXN0VGV4dDogc3RyaW5nKTogdm9pZCB7XHJcbiAgICAgICAgaWYgKCF0aGlzLl9heGlzTGFiZWxEdW1teSkgcmV0dXJuO1xyXG4gICAgICAgIF9sb25nZXN0VGV4dCA9IHRoaXMuZ2V0TGFiZWxGb3JtYXRSZXBsYWNlKHRoaXMuY29uZmlnLnhBeGlzLmxhYmVscy5mb3JtYXQsIF9sb25nZXN0VGV4dCk7XHJcbiAgICAgICAgdGhpcy5fc2V0QXhpc0xhYmVsRHVtbXlIdG1sKF9sb25nZXN0VGV4dCk7XHJcbiAgICB9XHJcblxyXG4gICAgcHVibGljIGdldEF4aXNMYWJlbER1bW15UmVjdCgpOiBhbnkge1xyXG4gICAgICAgIGlmICghdGhpcy5fYXhpc0xhYmVsRHVtbXkpIHJldHVybiAwO1xyXG4gICAgICAgIHJldHVybiB0aGlzLl9heGlzTGFiZWxEdW1teS5nZXRCb3VuZGluZ0NsaWVudFJlY3QoKTtcclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF9zZXRBeGlzTGFiZWxEdW1teUVsZW1lbnQoX2lkOiBzdHJpbmcpOiB2b2lkIHtcclxuICAgICAgICBpZiAodHlwZW9mIHRoaXMuX2F4aXNMYWJlbER1bW15ID09PSAndW5kZWZpbmVkJykge1xyXG4gICAgICAgICAgICB0aGlzLl9heGlzTGFiZWxEdW1teSA9IGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3IoJyMnICsgX2lkICsgJy5rZHgtY2hhcnRzIC5rZHgtY2hhcnRzLWludmlzaWJsZS1heGlzLWxhYmVsJyk7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX3NldEF4aXNMYWJlbER1bW15SHRtbChfdGV4dDogc3RyaW5nKTogdm9pZCB7XHJcbiAgICAgICAgaWYgKCF0aGlzLl9heGlzTGFiZWxEdW1teSkgcmV0dXJuO1xyXG4gICAgICAgIHRoaXMuX2F4aXNMYWJlbER1bW15LmlubmVySFRNTCA9IF90ZXh0O1xyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX3NldEF4aXNMYWJlbER1bW15U3R5bGUoX3hTcGFjaW5nOiBudW1iZXIpOiB2b2lkIHtcclxuICAgICAgICBpZiAoIXRoaXMuX2lzSW52ZXJ0ICYmICF0aGlzLmlzUm90YXRlKSB7XHJcbiAgICAgICAgICAgIHRoaXMuX2F4aXNMYWJlbER1bW15LnN0eWxlLm1heFdpZHRoID0gX3hTcGFjaW5nICsgJ3B4JztcclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgLyoqKiogT3RoZXJzICoqKioqKiovXHJcblxyXG4gICAgcHJpdmF0ZSBfY2hlY2tSb3RhdGUoX2lzSW52ZXJ0OiBib29sZWFuLCBfeFNwYWNpbmc6IG51bWJlciwgX21pblhTcGFjaW5nOiBudW1iZXIpOiBib29sZWFuIHtcclxuICAgICAgICAvLyBpZiBlYWNoIGJhci94U3BhY2luZyBoYXMgYXQgbGVhc3QgNTAgcHgsIGRvIG5vdCByb3RhdGUsIGxldCB0aGUgbGFiZWwgd29yZC13cmFwXHJcbiAgICAgICAgaWYgKF94U3BhY2luZyA+PSBfbWluWFNwYWNpbmcgfHwgX2lzSW52ZXJ0KSByZXR1cm4gZmFsc2U7XHJcbiAgICAgICAgLy8gcm90YXRlIG9ubHkgaWYgeFNwYWNpbmcgPCA1MHB4IEFORCB0aGUgYWN0dWFsIHRleHQod2l0aCBwYWRkZGluZykgbGVuZ3RoID4gZWFjaCBiYXIveFNwYWNpbmdcclxuICAgICAgICByZXR1cm4gdGhpcy5nZXRBeGlzTGFiZWxEdW1teVJlY3QoKS53aWR0aCA+IF94U3BhY2luZztcclxuICAgIH1cclxuXHJcbiAgICBwdWJsaWMgX3NldEF4aXNMYWJlbExlbmd0aCgpOiB2b2lkIHtcclxuICAgICAgICBsZXQgbG9uZ2VzdExlbmd0aDogbnVtYmVyID0gdGhpcy5nZXRBeGlzTGFiZWxEdW1teVJlY3QoKS53aWR0aCB8fCAwLFxyXG4gICAgICAgICAgICBzdmdQYXJlbnRSZWN0OiBhbnkgPSB0aGlzLl9zdmdQYXJlbnRSZWN0LFxyXG4gICAgICAgICAgICBzdmdMZW5ndGg6IG51bWJlciA9ICh0aGlzLl9pc0ludmVydCA/IHN2Z1BhcmVudFJlY3Qud2lkdGggOiBzdmdQYXJlbnRSZWN0LmhlaWdodCkgfHwgMCxcclxuICAgICAgICAgICAgbGFiZWxMZW5ndGg6IG51bWJlciA9IE1hdGgubWluKGxvbmdlc3RMZW5ndGgsIDAuMyAqIHN2Z0xlbmd0aCk7XHJcblxyXG4gICAgICAgIHRoaXMuX2xhYmVsTGVuZ3RoID0gbGFiZWxMZW5ndGg7XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfZ2V0QXhpc01hcmdpbihfaXNJbnZlcnQ6IGJvb2xlYW4sIF9pc1JvdGF0ZTogYm9vbGVhbik6IHsgdG9wOiBudW1iZXI7IGxlZnQ6IG51bWJlcjsgcmlnaHQ6IG51bWJlcjsgfSB7XHJcbiAgICAgICAgbGV0IGF4aXNNYXJnaW46IHsgdG9wOiBudW1iZXI7IGxlZnQ6IG51bWJlcjsgcmlnaHQ6IG51bWJlcjsgfSA9IHsgdG9wOiAwLCBsZWZ0OiAwLCByaWdodDogMCB9O1xyXG4gICAgICAgIGxldCBvcHBvc2l0ZTogYm9vbGVhbiA9IHRoaXMuX2NvbmZpZy55QXhpcy5vcHBvc2l0ZSB8fCBmYWxzZTtcclxuXHJcbiAgICAgICAgaWYgKCFfaXNJbnZlcnQpIHtcclxuICAgICAgICAgICAgbGV0IHRpdGxlV2lkdGg6IG51bWJlciA9IDA7XHJcbiAgICAgICAgICAgIGxldCBzaWRlOiAncmlnaHQnIHwgJ2xlZnQnID0gdGhpcy5faXNSdGwgPyAncmlnaHQnIDogJ2xlZnQnO1xyXG4gICAgICAgICAgICBsZXQgc2lnbjogbnVtYmVyID0gdGhpcy5faXNSdGwgPyAtMSA6IDE7XHJcbiAgICAgICAgICAgIG9wcG9zaXRlID0gb3Bwb3NpdGUgIT09IHRoaXMuX2lzUnRsO1xyXG5cclxuICAgICAgICAgICAgaWYgKCFvcHBvc2l0ZSAmJiB0aGlzLmlzVmFsdWVFeGlzdCh0aGlzLl9jdXJyVmVydEF4aXNUaXRsZSkpIHtcclxuICAgICAgICAgICAgICAgIHRpdGxlV2lkdGggPSB0aGlzLl9jdXJyVmVydEF4aXNUaXRsZS5nZXRCb3VuZGluZ0NsaWVudFJlY3QoKS53aWR0aDtcclxuICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgYXhpc01hcmdpbltzaWRlXSA9IHNpZ24gKiAodGhpcy5fc3ZnTWFyZ2luLmxlZnQgKyB0aXRsZVdpZHRoKTtcclxuICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICBheGlzTWFyZ2luLnRvcCA9IHRoaXMuX3N2Z01hcmdpbi50b3A7XHJcbiAgICAgICAgICAgIGlmIChvcHBvc2l0ZSkgYXhpc01hcmdpbi50b3AgKz0gdGhpcy5fZ2V0SG9yaXpUaXRsZUhlaWdodCgpO1xyXG5cclxuICAgICAgICAgICAgYXhpc01hcmdpbi5yaWdodCA9IDI7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIHJldHVybiBheGlzTWFyZ2luO1xyXG4gICAgfVxyXG5cclxuICAgIHB1YmxpYyBzZXRBeGlzTGFiZWxDb250YWluZXJTdHlsZShfY29udGFpbmVyOiBhbnkpOiB2b2lkIHtcclxuICAgICAgICBsZXQgc3R5bGVUeXBlOiAnd2lkdGgnIHwgJ2hlaWdodCcgPSB0aGlzLl9pc0ludmVydCA/ICd3aWR0aCcgOiAnaGVpZ2h0JztcclxuICAgICAgICBsZXQgc3R5bGVWYWw6IG51bWJlciA9IHRoaXMubGFiZWxMZW5ndGg7XHJcblxyXG4gICAgICAgIGlmICghdGhpcy5faXNJbnZlcnQgJiYgIXRoaXMuaXNSb3RhdGUpIHtcclxuICAgICAgICAgICAgc3R5bGVWYWwgPSB0aGlzLmdldEF4aXNMYWJlbER1bW15UmVjdCgpLmhlaWdodDtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIF9jb250YWluZXIuc3R5bGUoc3R5bGVUeXBlLCBzdHlsZVZhbCArICdweCcpO1xyXG4gICAgICAgIGlmICghdGhpcy5faXNJbnZlcnQpIF9jb250YWluZXIuc3R5bGUoJ3dpZHRoJywgJzEwMCUnKTtcclxuXHJcbiAgICAgICAgdGhpcy5fYXhpc0xhYmVsRHVtbXkuc3R5bGUubWF4V2lkdGggPSAnMTAwJSc7XHJcblxyXG5cclxuICAgICAgICBsZXQgbWFyZ2luOiB7IHRvcDogbnVtYmVyOyBsZWZ0OiBudW1iZXI7IHJpZ2h0OiBudW1iZXI7IH0gPSB0aGlzLl9nZXRBeGlzTWFyZ2luKHRoaXMuX2lzSW52ZXJ0LCB0aGlzLmlzUm90YXRlKTtcclxuXHJcbiAgICAgICAgX2NvbnRhaW5lclxyXG4gICAgICAgICAgICAuc3R5bGUoJ21hcmdpbi10b3AnLCBtYXJnaW4udG9wICsgJ3B4JylcclxuICAgICAgICAgICAgLnN0eWxlKCdtYXJnaW4tcmlnaHQnLCBtYXJnaW4ucmlnaHQgKyAncHgnKVxyXG4gICAgICAgICAgICAuc3R5bGUoJ21hcmdpbi1sZWZ0JywgbWFyZ2luLmxlZnQgKyAncHgnKTtcclxuXHJcbiAgICAgICAgdGhpcy5fYXhpc0xhYmVsQ29udGFpbmVyTWFyZ2luTGVmdCA9IG1hcmdpbi5sZWZ0O1xyXG4gICAgfVxyXG5cclxuICAgIC8qKlxyXG4gICAgICogc2V0IFggYXhpcyBMYWJlbCBQb3NpdGlvblxyXG4gICAgICogcGFyYW0ge2FueX0gICAgIF9sYWJlbENvbnRhaW5lclxyXG4gICAgICogcGFyYW0ge251bWJlcn0gIF90aWNrUG9zXHJcbiAgICAgKiBwYXJhbSB7SUF4aXNMYWJlbEJvb2xlYW5DaGVja3N9IF9ib29sZWFuQ2hlY2tzXHJcbiAgICAgKi9cclxuICAgIHB1YmxpYyBzZXRBeGlzTGFiZWxQb3NpdGlvbihfbGFiZWxDb250YWluZXI6IGFueSwgX3RpY2tQb3M6IG51bWJlciwgX2Jvb2xlYW5DaGVja3M6IElBeGlzTGFiZWxCb29sZWFuQ2hlY2tzKTogdm9pZCB7XHJcbiAgICAgICAgaWYgKHRoaXMuX2lzSW52ZXJ0IHx8IF9ib29sZWFuQ2hlY2tzLmlzUm90YXRlIHx8IChfYm9vbGVhbkNoZWNrcy5pc0xhc3QgJiYgdGhpcy5feFNjYWxlVHlwZSA9PT0gJ3N0cmluZycpKSB7XHJcbiAgICAgICAgICAgIHRoaXMuX2RvbVN2Yy5hZGRDbGFzcyhfbGFiZWxDb250YWluZXIubm9kZSgpLCAnZWxsaXBzaXMnKTtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIC8vIHdoZW4gcm90YXRpbmcsIHRoZXJlIHNob3VsZG4ndCBiZSBhbnkgcGFkZGluZygua2R4LWNoYXJ0cy1jaGlsZC1wYWRkaW5nLWJvdGgpIG9yICdzcGVjaWFsJyBwYWRkaW5nICgua2R4LWNoYXJ0cy1jaGlsZC1zcGVjaWFsLXBhZGRpbmcpXHJcbiAgICAgICAgLy8gbXVzdCBleGVjdXRlIGJlZm9yZSBvZmZzZXQgcG9zaXRpb25cclxuICAgICAgICBpZiAoX2Jvb2xlYW5DaGVja3MuaXNSb3RhdGUpIF9sYWJlbENvbnRhaW5lci5zdHlsZSgncGFkZGluZycsIDApO1xyXG5cclxuICAgICAgICBsZXQgbGFiZWxSZWN0OiBhbnkgPSBfbGFiZWxDb250YWluZXIubm9kZSgpLmdldEJvdW5kaW5nQ2xpZW50UmVjdCgpLFxyXG4gICAgICAgICAgICBvZmZzZXQ6IG51bWJlciA9ICF0aGlzLl9pc0ludmVydCAmJiAhX2Jvb2xlYW5DaGVja3MuaXNSb3RhdGUgPyBsYWJlbFJlY3Qud2lkdGggLyAyIDogbGFiZWxSZWN0LmhlaWdodCAvIDIsXHJcbiAgICAgICAgICAgIG9mZlNldFNpZ246IG51bWJlciA9IF9ib29sZWFuQ2hlY2tzLmlzUm90YXRlICYmIF9ib29sZWFuQ2hlY2tzLm9wcG9zaXRlID8gLTEgOiAxLFxyXG4gICAgICAgICAgICBwb3NpdGlvbjogbnVtYmVyID0gX3RpY2tQb3MgLSBvZmZzZXQgKiBvZmZTZXRTaWduO1xyXG5cclxuICAgICAgICAvLyBmb3IgaG9yaXpvbnRhbCBiYXJcclxuICAgICAgICBpZiAodGhpcy5faXNJbnZlcnQpIHtcclxuICAgICAgICAgICAgbGV0IGhvcml6RGlyOiBzdHJpbmcgPSB0aGlzLl9pc1J0bCAhPT0gX2Jvb2xlYW5DaGVja3Mub3Bwb3NpdGUgPyAnbGVmdCcgOiAncmlnaHQnO1xyXG4gICAgICAgICAgICBfbGFiZWxDb250YWluZXJcclxuICAgICAgICAgICAgICAgIC5zdHlsZSgndG9wJywgcG9zaXRpb24gKyAncHgnKVxyXG4gICAgICAgICAgICAgICAgLnN0eWxlKGhvcml6RGlyLCAwICsgJ3B4Jyk7XHJcbiAgICAgICAgICAgIHJldHVybjtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIGxldCB2ZXJ0RGlyOiBzdHJpbmcgPSBfYm9vbGVhbkNoZWNrcy5vcHBvc2l0ZSA/ICdib3R0b20nIDogJ3RvcCc7XHJcblxyXG4gICAgICAgIC8vIGZvciBhbGwgb3RoZXIgYXhpcyBjaGFydHNcclxuICAgICAgICBpZiAoX2Jvb2xlYW5DaGVja3MuaXNSb3RhdGUpIHtcclxuICAgICAgICAgICAgbGV0IHZlcnREaXN0OiBudW1iZXIgPSBfYm9vbGVhbkNoZWNrcy5pc1JvdGF0ZSAmJiAhX2Jvb2xlYW5DaGVja3Mub3Bwb3NpdGUgPyBsYWJlbFJlY3Qud2lkdGggOiAwO1xyXG5cclxuICAgICAgICAgICAgX2xhYmVsQ29udGFpbmVyXHJcbiAgICAgICAgICAgICAgICAuc3R5bGUodmVydERpciwgdmVydERpc3QgKyAncHgnKVxyXG4gICAgICAgICAgICAgICAgLnN0eWxlKCd0cmFuc2Zvcm0nLCAncm90YXRlKC05MGRlZyknKTtcclxuXHJcbiAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgaWYgKHRoaXMuX3hTY2FsZVR5cGUgPT09ICdzdHJpbmcnKSB7XHJcbiAgICAgICAgICAgICAgICAvLyB3aGVuIHBvc2l0aW9uIGlzIG5lZ2F0aXZlIGFuZCBpdCdzIGFic29sdXRlIHZhbHVlIGlzIG1vcmUgdGhhbiB0aGUgbWFyZ2luIG9mIGF4aXNMYWJlbENvbnRhaW5lclxyXG4gICAgICAgICAgICAgICAgaWYgKHBvc2l0aW9uICsgdGhpcy5fYXhpc0xhYmVsQ29udGFpbmVyTWFyZ2luTGVmdCA8IDApIHtcclxuICAgICAgICAgICAgICAgICAgICBsZXQgZGlmZjogbnVtYmVyID0gTWF0aC5hYnMocG9zaXRpb24pIC0gdGhpcy5fYXhpc0xhYmVsQ29udGFpbmVyTWFyZ2luTGVmdDtcclxuICAgICAgICAgICAgICAgICAgICBfbGFiZWxDb250YWluZXIuc3R5bGUoJ21heC13aWR0aCcsIChsYWJlbFJlY3Qud2lkdGggLSAyICogZGlmZikgKyAncHgnKTtcclxuICAgICAgICAgICAgICAgICAgICBwb3NpdGlvbiA9IC0xICogdGhpcy5fYXhpc0xhYmVsQ29udGFpbmVyTWFyZ2luTGVmdDtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIGlmIChfYm9vbGVhbkNoZWNrcy5pc0xhc3QpIF9sYWJlbENvbnRhaW5lci5zdHlsZSgnbWF4LXdpZHRoJywgKGxhYmVsUmVjdC53aWR0aCAvIDIgKyB0aGlzLl9zdmdNYXJnaW4ucmlnaHQpICsgJ3B4Jyk7XHJcbiAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgIF9sYWJlbENvbnRhaW5lci5zdHlsZSh2ZXJ0RGlyLCAwICsgJ3B4Jyk7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICBfbGFiZWxDb250YWluZXIuc3R5bGUoJ2xlZnQnLCBwb3NpdGlvbiArICdweCcpO1xyXG4gICAgfVxyXG5cclxuICAgIC8vID09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PSBEYXRhIExhYmVscyA9PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09XHJcblxyXG4gICAgLyoqXHJcbiAgICAgKiBkYXRhIGxhYmVscyBoYXZlIHRvIGJlIHJlcG9zaXRpb25lZCBhY2NvcmRpbmcgdG8gdGl0bGUgYW5kIGF4aXMgTGFiZWxzJ3Mgd2lkdGggYW5kIHBvc2l0aW9uXHJcbiAgICAgKiBwYXJhbSB7YW55fSBfZGF0YUxhYmVsQ29udGFpbmVyIGQzLXNlbGVjdGlvblxyXG4gICAgICogcGFyYW0ge2FueX0gX2F4aXNMYWJlbENvbnRhaW5lciBkMy1zZWxlY3Rpb25cclxuICAgICAqL1xyXG4gICAgcHVibGljIHJlcG9zaXRpb25EYXRhTGFiZWwoX2RhdGFMYWJlbENvbnRhaW5lcjogYW55LCBfYXhpc0xhYmVsQ29udGFpbmVyPzogYW55KTogdm9pZCB7XHJcbiAgICAgICAgbGV0IGF4aXNMYWJlbENvbnRhaW5lclJlY3QgPSB0aGlzLmlzVmFsdWVFeGlzdChfYXhpc0xhYmVsQ29udGFpbmVyKSA/IF9heGlzTGFiZWxDb250YWluZXIubm9kZSgpLmdldEJvdW5kaW5nQ2xpZW50UmVjdCgpIDogeyB3aWR0aDogMCwgaGVpZ2h0OiAwIH07XHJcblxyXG4gICAgICAgIGxldCBsZWZ0OiBudW1iZXIgPSB0aGlzLl9jYWxjdWxhdGVEYXRhTGFiZWxMZWZ0KGF4aXNMYWJlbENvbnRhaW5lclJlY3Qud2lkdGgpO1xyXG4gICAgICAgIGxldCB0b3A6IG51bWJlciA9IHRoaXMuX2NhbGN1bGF0ZURhdGFMYWJlbFRvcChheGlzTGFiZWxDb250YWluZXJSZWN0LmhlaWdodCk7XHJcblxyXG4gICAgICAgIF9kYXRhTGFiZWxDb250YWluZXJcclxuICAgICAgICAgICAgLnN0eWxlKCdsZWZ0JywgbGVmdCArICdweCcpXHJcbiAgICAgICAgICAgIC5zdHlsZSgndG9wJywgdG9wICsgJ3B4Jyk7XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfY2FsY3VsYXRlRGF0YUxhYmVsTGVmdChfbGFiZWxXaWR0aCk6IG51bWJlciB7XHJcbiAgICAgICAgbGV0IG9wcG9zaXRlOiBib29sZWFuID0gdGhpcy5faXNJbnZlcnQgPyB0aGlzLl9jb25maWcueEF4aXMub3Bwb3NpdGUgOiB0aGlzLl9jb25maWcueUF4aXMub3Bwb3NpdGU7XHJcbiAgICAgICAgbGV0IGNoYXJ0TWFyZ2luTGVmdDogc3RyaW5nID0gdGhpcy5fY29uZmlnLmNoYXJ0Lm1hcmdpbi5sZWZ0O1xyXG5cclxuICAgICAgICAvLyB3aGVuIHZlcnRpY2FsIGF4aXMgb24gcmlnaHQgKG9ubHkgb25lIGF4aXMpLCBsZWZ0IHNpZGUgaGF2ZSBubyBheGlzXHJcbiAgICAgICAgLy8gTk9URTogZG8gbm90IHJ1biB0aGlzIHN0ZXAgd2hlbiBjb2x1bW4vYmFyLXN0YWNrLW5lZ2F0aXZlLCBzaW5jZSBib3RoIGxlZnQgYW5kIHJpZ2h0IHNpZGUgaGF2ZSB2ZXJ0aWNhbCBheGlzXHJcbiAgICAgICAgaWYgKG9wcG9zaXRlICE9PSB0aGlzLl9pc1J0bCAmJiAhdGhpcy5pc05lZ2F0aXZlU3RhY2spIHtcclxuICAgICAgICAgICAgcmV0dXJuIHRoaXMuX3N2Z01hcmdpbi5sZWZ0ICsgdGhpcy5yZXBsYWNlU3RyaW5nV2l0aE51bWJlcihjaGFydE1hcmdpbkxlZnQpO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgLy8gd2hlbiB2ZXJ0aWNhbCBheGlzIG9uIGxlZnRcclxuICAgICAgICBsZXQgdGl0bGVXaWR0aDogbnVtYmVyID0gdGhpcy5pc1ZhbHVlRXhpc3QodGhpcy5fY3VyclZlcnRBeGlzVGl0bGUpID8gdGhpcy5fY3VyclZlcnRBeGlzVGl0bGUuZ2V0Qm91bmRpbmdDbGllbnRSZWN0KCkud2lkdGggOiAwO1xyXG4gICAgICAgIGxldCBsZWZ0OiBudW1iZXIgPSB0aGlzLnJlcGxhY2VTdHJpbmdXaXRoTnVtYmVyKGNoYXJ0TWFyZ2luTGVmdCk7XHJcblxyXG4gICAgICAgIGxlZnQgKz0gdGhpcy5faXNJbnZlcnQgPyB0aXRsZVdpZHRoICsgX2xhYmVsV2lkdGggKyB0aGlzLl9zdmdNYXJnaW4ubGVmdCArIDIgOiB0aXRsZVdpZHRoICsgdGhpcy5fc3ZnTWFyZ2luLmxlZnQ7XHJcblxyXG4gICAgICAgIHJldHVybiBsZWZ0O1xyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX2NhbGN1bGF0ZURhdGFMYWJlbFRvcChfbGFiZWxIZWlnaHQpOiBudW1iZXIge1xyXG4gICAgICAgIGxldCBvcHBvc2l0ZTogYm9vbGVhbiA9IHRoaXMuX2lzSW52ZXJ0ID8gdGhpcy5fY29uZmlnLnlBeGlzLm9wcG9zaXRlIDogdGhpcy5fY29uZmlnLnhBeGlzLm9wcG9zaXRlO1xyXG5cclxuICAgICAgICAvLyB3aGVuIGhvcml6b250YWwgYXhpcyBpcyBhdCBib3R0b21cclxuICAgICAgICAvLyBOT1RFOiBkbyBub3QgcnVuIHRoaXMgc3RlcCB3aGVuIGNvbHVtbi9iYXItc3RhY2stbmVnYXRpdmUsIHNpbmNlIGJvdGggYWJvdmUgYW5kIGJlbG93IGhhdmUgaG9yaXpvbnRhbCBheGlzXHJcbiAgICAgICAgaWYgKCFvcHBvc2l0ZSAmJiAhdGhpcy5pc05lZ2F0aXZlU3RhY2spIHtcclxuICAgICAgICAgICAgcmV0dXJuIHRoaXMuX3N2Z01hcmdpbi50b3AgKyB0aGlzLnJlcGxhY2VTdHJpbmdXaXRoTnVtYmVyKHRoaXMuX2NvbmZpZy5jaGFydC5tYXJnaW4udG9wKTtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIC8vIHdoZW4gaG9yaXpvbnRhbCBheGlzIG9uIHRvcFxyXG4gICAgICAgIGxldCBob3JpelRpdGxlSGVpZ2h0OiBudW1iZXIgPSB0aGlzLl9nZXRIb3JpelRpdGxlSGVpZ2h0KCk7XHJcbiAgICAgICAgbGV0IHRvcDogbnVtYmVyID0gdGhpcy5yZXBsYWNlU3RyaW5nV2l0aE51bWJlcih0aGlzLl9jb25maWcuY2hhcnQubWFyZ2luLnRvcCk7XHJcblxyXG4gICAgICAgIHRvcCArPSB0aGlzLl9pc0ludmVydCA/IGhvcml6VGl0bGVIZWlnaHQgKyB0aGlzLl9zdmdNYXJnaW4udG9wIDogaG9yaXpUaXRsZUhlaWdodCArIHRoaXMuX3N2Z01hcmdpbi50b3AgKyBfbGFiZWxIZWlnaHQ7XHJcblxyXG4gICAgICAgIHJldHVybiB0b3A7XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfZ2V0SG9yaXpUaXRsZUhlaWdodCgpOiBudW1iZXIge1xyXG4gICAgICAgIGxldCBjbGFzc05hbWU6IHN0cmluZyA9ICcjJyArIHRoaXMuX2NvbmZpZy5pZCArICcua2R4LWNoYXJ0cyAua2R4LWNoYXJ0cy1heGlzLXRpdGxlJztcclxuICAgICAgICBjbGFzc05hbWUgKz0gdGhpcy5faXNJbnZlcnQgPyAnLXknIDogJy14JztcclxuICAgICAgICBsZXQgaG9yaXpUaXRsZUVsZW1lbnQgPSBkb2N1bWVudC5xdWVyeVNlbGVjdG9yKGNsYXNzTmFtZSk7XHJcblxyXG4gICAgICAgIHJldHVybiB0aGlzLmlzVmFsdWVFeGlzdChob3JpelRpdGxlRWxlbWVudCkgPyBob3JpelRpdGxlRWxlbWVudC5nZXRCb3VuZGluZ0NsaWVudFJlY3QoKS5oZWlnaHQgOiAwO1xyXG4gICAgfVxyXG5cclxuICAgIC8qKioqVmVydGljYWwgQWxpZ24qKioqKi9cclxuXHJcbiAgICBwdWJsaWMgX2dldExhYmVsVGV4dEhlaWdodCgpOiBudW1iZXIge1xyXG4gICAgICAgIGxldCBsYWJlbFN0eWxlOiB7IFtrZXk6IHN0cmluZ106IHN0cmluZyB9ID0gdGhpcy5fY29uZmlnLmNoYXJ0LmxhYmVscy5zdHlsZTtcclxuICAgICAgICBsZXQgZm9udFNpemU6IG51bWJlciA9IHRoaXMucmVwbGFjZVN0cmluZ1dpdGhOdW1iZXIobGFiZWxTdHlsZS5mb250U2l6ZSk7XHJcbiAgICAgICAgbGV0IGJvcmRlcldpZHRoOiBudW1iZXIgPSB0aGlzLnJlcGxhY2VTdHJpbmdXaXRoTnVtYmVyKGxhYmVsU3R5bGUuYm9yZGVyV2lkdGgpO1xyXG4gICAgICAgIHJldHVybiBmb250U2l6ZSAqIDEuMyArIGJvcmRlcldpZHRoICogMjtcclxuICAgIH1cclxuXHJcbiAgICBwdWJsaWMgX2NoZWNrQm91bmRhcnkoX3R5cGU6IGFueSwgX3lQb3NpdGlvbjogbnVtYmVyLCBfY2hhcnRIZWlnaHQ6IG51bWJlciwgX2RvdFNpemU6IG51bWJlciA9IDApOiBib29sZWFuIHtcclxuICAgICAgICBsZXQgdGV4dFNpemU6IG51bWJlciA9IHRoaXMuX2dldExhYmVsVGV4dEhlaWdodCgpICsgX2RvdFNpemUgLyAyO1xyXG5cclxuICAgICAgICBpZiAoX3R5cGUgPT09ICdtYXgnKSB7XHJcbiAgICAgICAgICAgIHJldHVybiBfeVBvc2l0aW9uIC0gdGV4dFNpemUgPCB0aGlzLmRhdGFMYWJlbFB1c2hEb3duUmFuZ2U7XHJcbiAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgcmV0dXJuIF95UG9zaXRpb24gKyB0ZXh0U2l6ZSA+IF9jaGFydEhlaWdodCAtIHRoaXMuZGF0YUxhYmVsUHVzaERvd25SYW5nZTtcclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgcHVibGljIG5lZWRPZmZzZXRGb3JDb2x1bW4oX3ZlcnRpY2FsQWxpZ246ICd0b3AnIHwgJ21pZGRsZScgfCAnYm90dG9tJywgX3BhcmFtczogeyBba2V5OiBzdHJpbmddOiBhbnkgfSA9IHt9KTogYm9vbGVhbiB8IG51bWJlciB7XHJcbiAgICAgICAgaWYgKCFfcGFyYW1zLmRpbWVuc2lvbnMpIHJldHVybiBmYWxzZTtcclxuICAgICAgICBpZiAoX3BhcmFtcy52YWx1ZVNpZ24gPCAwKSB7XHJcbiAgICAgICAgICAgIGlmIChfdmVydGljYWxBbGlnbiA9PT0gJ3RvcCcpIHJldHVybiAtMTsgLy8gbmVlZHMgb2Zmc2V0LCByZXR1cm5pbmcgdHJ1ZSBjb25kaXRpb25cclxuICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICBpZiAoX3ZlcnRpY2FsQWxpZ24gPT09ICdib3R0b20nKSByZXR1cm4gMTsgLy8gbmVlZHMgb2Zmc2V0LCByZXR1cm5pbmcgdHJ1ZSBjb25kaXRpb25cclxuICAgICAgICB9XHJcbiAgICAgICAgcmV0dXJuIGZhbHNlO1xyXG4gICAgfVxyXG5cclxuICAgIC8vIE5PVEU6IGRhdGEgbGFiZWwgdmVydGljYWwgYWxpZ24gaXMgbm90IGRlZmluZWQgaW4gZGVmYXVsdCBjb25maWcgKGFzIG9mIHYzLjcuMCBiZWNvcyBiZWhhdmlvdXIgY2hhbmdlcyB3aXRoIGRpZmZlcmVudCBjaGFydCB0eXBlcylcclxuICAgIHB1YmxpYyBnZXREZWZhdWx0VmVydGljYWxBbGlnbihfY29uZmlnLCBfcGFyYW1zKTogJ3RvcCcgfCAnbWlkZGxlJyB8ICdib3R0b20nIHtcclxuICAgICAgICBpZiAoX2NvbmZpZy5jaGFydC5sYWJlbHMudmVydGljYWxBbGlnbikgcmV0dXJuIF9jb25maWcuY2hhcnQubGFiZWxzLnZlcnRpY2FsQWxpZ247XHJcbiAgICAgICAgbGV0IGRlZmF1bHRWYWx1ZTogJ3RvcCcgfCAnbWlkZGxlJyB8ICdib3R0b20nID0gJ3RvcCc7XHJcbiAgICAgICAgLy8gZm9yIGNvbHVtbiwgbmVnYXRpdmUgdmFsdWVzIG5lZWQgdG8gYmUgcGxhY2VkIG9uIGJvdHRvbVxyXG4gICAgICAgIGlmIChfcGFyYW1zLnZhbHVlU2lnbiA8IDApIGRlZmF1bHRWYWx1ZSA9ICdib3R0b20nO1xyXG4gICAgICAgIHJldHVybiBkZWZhdWx0VmFsdWU7XHJcbiAgICB9XHJcblxyXG4gICAgLy8gPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09IEdlbmVyYWwgPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PVxyXG5cclxuICAgIC8qKlxyXG4gICAgICogaW4gYXJhYmljLCBudW1iZXJzIGFyZSBpbiBsdHIgbW9kZSAoZWc6IG5lZ2F0aXZlIHNpZ24gaXMgdHlwZWQgZmlyc3QpXHJcbiAgICAgKiBIZW5jZSB3cmFwcGluZyBhIGRpdiBhcm91bmQgbnVtYmVyIChvbmx5KSB3aXRoIGNsYXNzTmFtZSAnLmtkeC1jaGFydHMtZGlzcGxheS1udW1iZXInIHRvIGZvcmNlIGRpcmVjdGlvbjogbHRyXHJcbiAgICAgKiBwYXJhbSAge251bWJlcn0gX251bWJlclxyXG4gICAgICogcmV0dXJuIHtzdHJpbmd9XHJcbiAgICAgKi9cclxuICAgIHB1YmxpYyB3cmFwTnVtYmVySW5JbmxpbmVEaXYoX251bWJlcjogbnVtYmVyIHwgc3RyaW5nKTogc3RyaW5nIHtcclxuICAgICAgICByZXR1cm4gJzxkaXYgY2xhc3M9XCJrZHgtY2hhcnRzLWRpc3BsYXktbnVtYmVyXCIgc3R5bGU9XCJkaXNwbGF5OiBpbmxpbmUtYmxvY2s7XCIgZGlyPVwibHRyXCI+JyArIF9udW1iZXIgKyAnPC9kaXY+JztcclxuICAgIH1cclxuXHJcbiAgICBwdWJsaWMgcmVwbGFjZVN0cmluZ1dpdGhOdW1iZXIoX3ZhbHVlOiBzdHJpbmcgfCBudW1iZXIpOiBudW1iZXIge1xyXG4gICAgICAgIGlmICh0eXBlb2YgX3ZhbHVlID09PSAnbnVtYmVyJykgcmV0dXJuIF92YWx1ZTtcclxuICAgICAgICByZXR1cm4gcGFyc2VGbG9hdChfdmFsdWUucmVwbGFjZSgvW14wLTkuXS9nLCAnJykpO1xyXG4gICAgfVxyXG5cclxuICAgIHB1YmxpYyBnZXRGb3JMb29wU2VxdWVuY2UoX2NoYXJ0VHlwZTogc3RyaW5nW10pOiAnYXNjZW5kaW5nJyB8ICdkZXNjZW5kaW5nJyB7XHJcbiAgICAgICAgcmV0dXJuIF9jaGFydFR5cGVbMF0gIT09ICdiYXInICYmIChfY2hhcnRUeXBlWzFdID09PSAnc3RhY2snIHx8IF9jaGFydFR5cGVbMV0gPT09ICcxMDAnKSA/ICdkZXNjZW5kaW5nJyA6ICdhc2NlbmRpbmcnO1xyXG4gICAgfVxyXG5cclxuICAgIHB1YmxpYyBnZXRGb3JMb29wSW5mbyhfdHlwZTogJ2FzY2VuZGluZycgfCAnZGVzY2VuZGluZycsIGFyckxlbmd0aDogbnVtYmVyKTogSUZvckxvb3BJbmZvIHtcclxuICAgICAgICByZXR1cm4ge1xyXG4gICAgICAgICAgICBzdGFydDogX3R5cGUgPT09ICdhc2NlbmRpbmcnID8gMCA6IGFyckxlbmd0aCAtIDEsXHJcbiAgICAgICAgICAgIGVuZDogX3R5cGUgPT09ICdhc2NlbmRpbmcnID8gYXJyTGVuZ3RoIDogLTEsXHJcbiAgICAgICAgICAgIGNoZWNrOiBfdHlwZSA9PT0gJ2FzY2VuZGluZycgPyAoaSwgZW5kKSA9PiBpIDwgZW5kIDogKGksIGVuZCkgPT4gaSA+IGVuZCxcclxuICAgICAgICAgICAgaXRlcmF0ZTogX3R5cGUgPT09ICdhc2NlbmRpbmcnID8gKGkpID0+IGkgKyAxIDogKGkpID0+IGkgLSAxLFxyXG4gICAgICAgIH07XHJcbiAgICB9XHJcblxyXG4gICAgcHVibGljIGdldFhJbmZvKF9kYXRhOiBBcnJheTxJRDNEYXRhRGF0YT4sIF9jb25maWc6IElDaGFydENvbmZpZyk6IElYSW5mbyB7XHJcbiAgICAgICAgbGV0IHhJbmZvOiBJWEluZm8gPSB7XHJcbiAgICAgICAgICAgIHZhbHVlOiBbXSxcclxuICAgICAgICAgICAgbG9uZ2VzdFRleHQ6ICcnXHJcbiAgICAgICAgfTtcclxuICAgICAgICBsZXQgbG9uZ2VzdFRleHRXaWR0aDogbnVtYmVyID0gMDtcclxuICAgICAgICBsZXQgc2hvd1ZhbHVlSW5MYWJlbDogYm9vbGVhbiA9IF9jb25maWcueEF4aXMubGFiZWxzLmZvcm1hdC5pbmRleE9mKCd7dmFsdWV9JykgPiAtMSAmJiBfY29uZmlnLnhBeGlzLmVuYWJsZWQgJiYgX2NvbmZpZy54QXhpcy5sYWJlbHMuZW5hYmxlZDtcclxuICAgICAgICBpZiAoc2hvd1ZhbHVlSW5MYWJlbCkgdGhpcy5fc2V0QXhpc0xhYmVsRHVtbXlFbGVtZW50KF9jb25maWcuaWQpO1xyXG5cclxuICAgICAgICBfZGF0YS5mb3JFYWNoKGQgPT4ge1xyXG4gICAgICAgICAgICB4SW5mby52YWx1ZS5wdXNoKGQueC52YWx1ZSk7XHJcblxyXG4gICAgICAgICAgICAvLyBpZiBubyB2YWx1ZSBuZWVkcyB0byBiZSBzaG93ZWQgaW4gbGFiZWwsIHRoZW4gbm8gbmVlZCBjaGVjayBsb25nZXN0IHRleHRcclxuICAgICAgICAgICAgaWYgKHNob3dWYWx1ZUluTGFiZWwpIHtcclxuICAgICAgICAgICAgICAgIHRoaXMuX3NldEF4aXNMYWJlbER1bW15SHRtbChkLngubGFiZWwpO1xyXG4gICAgICAgICAgICAgICAgbGV0IGN1cnJlbnRXaWR0aDogbnVtYmVyID0gdGhpcy5nZXRBeGlzTGFiZWxEdW1teVJlY3QoKS53aWR0aDtcclxuICAgICAgICAgICAgICAgIGlmIChjdXJyZW50V2lkdGggPiBsb25nZXN0VGV4dFdpZHRoKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgbG9uZ2VzdFRleHRXaWR0aCA9IGN1cnJlbnRXaWR0aDtcclxuICAgICAgICAgICAgICAgICAgICB4SW5mby5sb25nZXN0VGV4dCA9IGQueC5sYWJlbDtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH0pO1xyXG5cclxuICAgICAgICByZXR1cm4geEluZm87XHJcbiAgICB9XHJcblxyXG4gICAgcHVibGljIGNoZWNrQW5kUmV0dXJuTGFiZWxzUG9zaXRpdmUoX3ZhbHVlOiBudW1iZXIpOiBudW1iZXIge1xyXG4gICAgICAgIGlmICh0aGlzLmlzTmVnYXRpdmVTdGFjaykge1xyXG4gICAgICAgICAgICBsZXQgcGxvdE9wdGlvbnM6IElQbG90T3B0aW9ucyA9IHRoaXMuY29uZmlnLnBsb3RPcHRpb25zO1xyXG4gICAgICAgICAgICBpZiAocGxvdE9wdGlvbnMgJiYgcGxvdE9wdGlvbnMuYmFyICYmIHR5cGVvZiBwbG90T3B0aW9ucy5iYXIuYWxsTGFiZWxzUG9zaXRpdmUgIT09ICd1bmRlZmluZWQnKSB7XHJcbiAgICAgICAgICAgICAgICByZXR1cm4gdGhpcy5jb25maWcucGxvdE9wdGlvbnMuYmFyLmFsbExhYmVsc1Bvc2l0aXZlID8gTWF0aC5hYnMoX3ZhbHVlKSA6IF92YWx1ZTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICByZXR1cm4gTWF0aC5hYnMoX3ZhbHVlKTtcclxuICAgICAgICB9XHJcbiAgICAgICAgcmV0dXJuIF92YWx1ZTtcclxuICAgIH1cclxuXHJcbiAgICBwdWJsaWMgZmluZERlY2ltYWxQbGFjZShfbnVtYmVyOiBudW1iZXIpOiBudW1iZXIge1xyXG4gICAgICAgIGlmIChwYXJzZUludChfbnVtYmVyLnRvU3RyaW5nKCkpID09PSBfbnVtYmVyKSByZXR1cm4gMDtcclxuICAgICAgICBsZXQgcmVzdWx0OiBudW1iZXIgPSAwO1xyXG4gICAgICAgIGxldCBzdHJpbmdGb3JtOiBzdHJpbmcgPSBNYXRoLmFicyhfbnVtYmVyKS50b1N0cmluZygpO1xyXG4gICAgICAgIGxldCBzcGxpdEJ5RG90OiBBcnJheTxzdHJpbmc+ID0gc3RyaW5nRm9ybS5zcGxpdCgnLicpO1xyXG5cclxuICAgICAgICBpZiAoc3RyaW5nRm9ybS5pbmRleE9mKCdlJykgPCAwKSB7XHJcbiAgICAgICAgICAgIHJlc3VsdCA9IHNwbGl0QnlEb3RbMV0ubGVuZ3RoO1xyXG4gICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgIHJlc3VsdCA9IHBhcnNlSW50KHN0cmluZ0Zvcm0uc3BsaXQoJ2UtJylbMV0pO1xyXG4gICAgICAgICAgICBpZiAodHlwZW9mIHNwbGl0QnlEb3RbMV0gIT09ICd1bmRlZmluZWQnKSByZXN1bHQgKz0gc3BsaXRCeURvdFsxXS5sZW5ndGg7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICByZXR1cm4gcmVzdWx0O1xyXG4gICAgfVxyXG5cclxuICAgIHB1YmxpYyBnZXRMYWJlbFRleHQoX2Zvcm1hdDogc3RyaW5nLCBfdmFsdWU6IG51bWJlciB8IHN0cmluZywgX2lzSFRNTDogYm9vbGVhbiA9IHRydWUsIF9kM0Zvcm1hdD86IHN0cmluZyk6IHN0cmluZyB7XHJcbiAgICAgICAgbGV0IGQzRm9ybWF0OiBzdHJpbmcgPSB0eXBlb2YgX2QzRm9ybWF0ID09PSAndW5kZWZpbmVkJyA/IHRoaXMuZ2V0RDNGb3JtYXQoX3ZhbHVlKSA6IF9kM0Zvcm1hdDtcclxuICAgICAgICBsZXQgdGV4dDogc3RyaW5nID0gdGhpcy5jaGFuZ2VWYWx1ZVRvRDNGb3JtYXQoX3ZhbHVlLCBkM0Zvcm1hdCk7XHJcblxyXG4gICAgICAgIGlmIChfaXNIVE1MKSB0ZXh0ID0gdGhpcy53cmFwTnVtYmVySW5JbmxpbmVEaXYodGV4dCk7XHJcblxyXG4gICAgICAgIHJldHVybiB0aGlzLmdldExhYmVsRm9ybWF0UmVwbGFjZShfZm9ybWF0LCB0ZXh0KTtcclxuICAgIH1cclxuXHJcbiAgICBwdWJsaWMgZ2V0TGFiZWxGb3JtYXRSZXBsYWNlKF9mb3JtYXQ6IHN0cmluZywgX3RleHQ6IHN0cmluZyk6IHN0cmluZyB7XHJcbiAgICAgICAgcmV0dXJuIF9mb3JtYXQucmVwbGFjZSgve3ZhbHVlfS9nLCBfdGV4dCk7XHJcbiAgICB9XHJcblxyXG4gICAgcHVibGljIGlzSW50ZXJnZXIoX3ZhbHVlOiBudW1iZXIgfCBzdHJpbmcpOiBib29sZWFuIHtcclxuICAgICAgICByZXR1cm4gdHlwZW9mIF92YWx1ZSA9PT0gJ251bWJlcicgJiYgKF92YWx1ZSAlIDEpID09PSAwO1xyXG4gICAgfVxyXG5cclxuICAgIHB1YmxpYyBnZXREM0Zvcm1hdChfdmFsdWU6IHN0cmluZyB8IG51bWJlciwgX3RvRGVjaW1hbFBsYWNlPzogbnVtYmVyKTogc3RyaW5nIHtcclxuICAgICAgICBpZiAodHlwZW9mIF92YWx1ZSA9PT0gJ3N0cmluZycpIHJldHVybiAnJztcclxuXHJcbiAgICAgICAgaWYgKE1hdGguYWJzKF92YWx1ZSkgPiAxMDAwMDAwMCkgcmV0dXJuICcuMmUnO1xyXG5cclxuICAgICAgICBpZiAodGhpcy5pc0ludGVyZ2VyKF92YWx1ZSkpIHtcclxuICAgICAgICAgICAgcmV0dXJuICcsJztcclxuICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICAvLyBpcyBkZWNpbWFsXHJcbiAgICAgICAgICAgIGlmIChNYXRoLmFicyhfdmFsdWUpIDwgMC4wMDAwMDAwMSkgcmV0dXJuICcuMmUnO1xyXG5cclxuICAgICAgICAgICAgaWYgKHR5cGVvZiBfdG9EZWNpbWFsUGxhY2UgIT09ICd1bmRlZmluZWQnICYmIF90b0RlY2ltYWxQbGFjZSAhPT0gMCkge1xyXG4gICAgICAgICAgICAgICAgLy8gaWYgcHJlY2lzaW9uIGlzIGdpdmVuXHJcbiAgICAgICAgICAgICAgICByZXR1cm4gJy4nICsgX3RvRGVjaW1hbFBsYWNlLnRvU3RyaW5nKCkgKyAnZic7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIHJldHVybiAnJztcclxuICAgIH1cclxuXHJcbiAgICBwdWJsaWMgY2hhbmdlVmFsdWVUb0QzRm9ybWF0KF92YWx1ZTogc3RyaW5nIHwgbnVtYmVyLCBfZm9ybWF0OiBzdHJpbmcpOiBzdHJpbmcge1xyXG4gICAgICAgIGlmICh0eXBlb2YgX3ZhbHVlID09PSAnc3RyaW5nJykgcmV0dXJuIF92YWx1ZTtcclxuICAgICAgICByZXR1cm4gZDMuZm9ybWF0KF9mb3JtYXQpKF92YWx1ZSk7XHJcbiAgICB9XHJcblxyXG4gICAgcHVibGljIGdldExvbmdlck51bWJlcihfbnVtMTogbnVtYmVyLCBfbnVtMjogbnVtYmVyKTogbnVtYmVyIHtcclxuICAgICAgICByZXR1cm4gX251bTEudG9TdHJpbmcoKS5sZW5ndGggPiBfbnVtMi50b1N0cmluZygpLmxlbmd0aCA/IF9udW0xIDogX251bTI7XHJcbiAgICB9XHJcblxyXG4gICAgcHVibGljIHNldENoYXJ0Q29udGFpbmVyTWFyZ2luKF9jaGFydENvbnRhaW5lcjogYW55KTogdm9pZCB7XHJcbiAgICAgICAgbGV0IG1hcmdpbjogSUNoYXJ0TWFyZ2luID0gdGhpcy5fY29uZmlnLmNoYXJ0Lm1hcmdpbjtcclxuICAgICAgICBfY2hhcnRDb250YWluZXIuc3R5bGUucGFkZGluZyA9IG1hcmdpbi50b3AgKyAnICcgKyBtYXJnaW4ucmlnaHQgKyAnICcgKyBtYXJnaW4uYm90dG9tICsgJyAnICsgbWFyZ2luLmxlZnQ7XHJcbiAgICB9XHJcblxyXG4gICAgcHVibGljIHRyYW5zZm9ybUdyYXBoQ29udGFpbmVyKF9jb250YWluZXI6IGFueSk6IHZvaWQge1xyXG4gICAgICAgIF9jb250YWluZXIuYXR0cigndHJhbnNmb3JtJywgJ3RyYW5zbGF0ZSgnICsgdGhpcy5fc3ZnTWFyZ2luLmxlZnQgKyAnLCcgKyB0aGlzLl9zdmdNYXJnaW4udG9wICsgJyknKTtcclxuICAgIH1cclxuXHJcbiAgICBwdWJsaWMgc2V0U3ZnQXR0cmlidXRlKF9lbGVtZW50OiBhbnksIF9jb25maWc6IHsgW2tleTogc3RyaW5nXTogc3RyaW5nIHwgbnVtYmVyIH0pOiB2b2lkIHtcclxuICAgICAgICBmb3IgKGxldCBrZXkgaW4gX2NvbmZpZykge1xyXG4gICAgICAgICAgICBpZiAoIXRoaXMuaXNWYWx1ZUV4aXN0KF9jb25maWdba2V5XSkpIGNvbnRpbnVlO1xyXG4gICAgICAgICAgICBsZXQgYXR0cmlidXRlU3RyOiBzdHJpbmcgPSBrZXkgPT09ICdjb2xvcicgPyAnZmlsbCcgOiBrZXkucmVwbGFjZSgvKFthLXpBLVpdKSg/PVtBLVpdKS9nLCAnJDEtJykudG9Mb3dlckNhc2UoKTtcclxuICAgICAgICAgICAgX2VsZW1lbnQuYXR0cihhdHRyaWJ1dGVTdHIsIF9jb25maWdba2V5XSk7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIHB1YmxpYyBpc0V4aXN0KF95RWxlbTogYW55KTogYm9vbGVhbiB7XHJcbiAgICAgICAgcmV0dXJuICh0eXBlb2YgX3lFbGVtICE9PSAndW5kZWZpbmVkJyAmJiBfeUVsZW0gIT09IG51bGwgJiYgX3lFbGVtLnZhbHVlICE9PSBudWxsKTtcclxuICAgIH1cclxuXHJcbiAgICBwdWJsaWMgaXNWYWx1ZUV4aXN0KF92YWw6IGFueSk6IGJvb2xlYW4ge1xyXG4gICAgICAgIHJldHVybiAodHlwZW9mIF92YWwgIT09ICd1bmRlZmluZWQnICYmIF92YWwgIT09IG51bGwgJiYgX3ZhbCAhPT0gJycpO1xyXG4gICAgfVxyXG5cclxuICAgIHB1YmxpYyBnZXREM01heE9yTWluKF9hcnI6IEFycmF5PG51bWJlcj4sIF90eXBlOiAnbWF4JyB8ICdtaW4nKTogbnVtYmVyIHtcclxuICAgICAgICBpZiAoX3R5cGUgPT09ICdtYXgnKSByZXR1cm4gZDMubWF4KF9hcnIpO1xyXG4gICAgICAgIGlmIChfdHlwZSA9PT0gJ21pbicpIHJldHVybiBkMy5taW4oX2Fycik7XHJcbiAgICB9XHJcblxyXG4gICAgcHVibGljIGdldEF4aXNUcmFuc2Zvcm1Qb3MoX2F4aXM6ICd4JyB8ICd5JywgX29wcG9zaXRlOiBib29sZWFuLCBfdHJhbnNmb3JtUG9zOiBJQXhpc1RyYW5zZm9ybVBvcyk6IHN0cmluZyB7XHJcbiAgICAgICAgaWYgKHRoaXMuX2lzSW52ZXJ0KSB7XHJcbiAgICAgICAgICAgIGlmIChfYXhpcyA9PT0gJ3gnKSB7XHJcbiAgICAgICAgICAgICAgICBpZiAoX29wcG9zaXRlKSByZXR1cm4gX3RyYW5zZm9ybVBvcy5yaWdodDtcclxuICAgICAgICAgICAgICAgIHJldHVybiBfdHJhbnNmb3JtUG9zLmxlZnQ7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgaWYgKF9heGlzID09PSAneScpIHtcclxuICAgICAgICAgICAgICAgIGlmIChfb3Bwb3NpdGUpIHJldHVybiBfdHJhbnNmb3JtUG9zLnRvcDtcclxuICAgICAgICAgICAgICAgIHJldHVybiBfdHJhbnNmb3JtUG9zLmJvdHRvbTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgIGlmIChfYXhpcyA9PT0gJ3gnKSB7XHJcbiAgICAgICAgICAgICAgICBpZiAoX29wcG9zaXRlKSByZXR1cm4gX3RyYW5zZm9ybVBvcy50b3A7XHJcbiAgICAgICAgICAgICAgICByZXR1cm4gX3RyYW5zZm9ybVBvcy5ib3R0b207XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgaWYgKF9heGlzID09PSAneScpIHtcclxuICAgICAgICAgICAgICAgIGlmIChfb3Bwb3NpdGUpIHJldHVybiBfdHJhbnNmb3JtUG9zLnJpZ2h0O1xyXG4gICAgICAgICAgICAgICAgcmV0dXJuIF90cmFuc2Zvcm1Qb3MubGVmdDtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICBwdWJsaWMgZ2V0TGltaXRlZENhdGVnb3JpZXMoX2luaXRDYXRlZ29yaWVzOiBBcnJheTxzdHJpbmc+LCBfeFRocmVzaG9sZDogbnVtYmVyKTogQXJyYXk8c3RyaW5nPiB7XHJcbiAgICAgICAgaWYgKCFfaW5pdENhdGVnb3JpZXMpIHJldHVybiBbXTtcclxuICAgICAgICByZXR1cm4gX3hUaHJlc2hvbGQgJiYgX2luaXRDYXRlZ29yaWVzLmxlbmd0aCA+IF94VGhyZXNob2xkID8gX2luaXRDYXRlZ29yaWVzLnNsaWNlKDAsIF94VGhyZXNob2xkKSA6IF9pbml0Q2F0ZWdvcmllcztcclxuICAgIH1cclxuXHJcbiAgICAvKipcclxuICAgICAqIHJldHVybiBjb25maWcgaW50byBjc3Mgc3RyaW5nIHNvIGNhbiBiZSBhZGRlZCBpbnRvIGVsZW1lbnRcclxuICAgICAqIHBhcmFtICB7b2JqZWN0fSAgZGVmYXVsdENvbmZpZyBjb25maWdcclxuICAgICAqIHBhcmFtICB7Ym9vbGVhbn0gaXNGb3JUb29sdGlwICBpZiB0b29sdGlwLCBjb21wYXJlIGRlZmF1bHQgY29uZmlnIHdpdGggY29uZmlnIHBhc3MgZnJvbSB1c2VyXHJcbiAgICAgKiByZXR1cm4ge3N0cmluZ30gICAgICAgICAgICAgICAgY3NzIHN0eWxpbmdcclxuICAgICAqL1xyXG4gICAgcHVibGljIGdldFN0eWxlKGRlZmF1bHRDb25maWc6IG9iamVjdCwgaXNGb3JUb29sdGlwPzogYm9vbGVhbik6IHN0cmluZyB7XHJcbiAgICAgICAgbGV0IGNvbmZpZzogb2JqZWN0ID0ge307XHJcbiAgICAgICAgaWYgKGlzRm9yVG9vbHRpcCkge1xyXG4gICAgICAgICAgICBjb25maWcgPSB0aGlzLl9jb25maWcudG9vbHRpcC5zdHlsZTtcclxuICAgICAgICB9XHJcbiAgICAgICAgbGV0IHN0eWxpbmc6IHN0cmluZyA9ICcnO1xyXG5cclxuICAgICAgICBpZiAoZGVmYXVsdENvbmZpZykge1xyXG4gICAgICAgICAgICBmb3IgKGxldCBkZWZhdWx0S2V5IG9mIE9iamVjdC5rZXlzKGRlZmF1bHRDb25maWcpKSB7XHJcbiAgICAgICAgICAgICAgICBzdHlsaW5nICs9IGRlZmF1bHRLZXkucmVwbGFjZSgvKFthLXpBLVpdKSg/PVtBLVpdKS9nLCAnJDEtJykudG9Mb3dlckNhc2UoKTtcclxuICAgICAgICAgICAgICAgIHN0eWxpbmcgKz0gJzonO1xyXG4gICAgICAgICAgICAgICAgc3R5bGluZyArPSAoY29uZmlnICYmIGNvbmZpZy5oYXNPd25Qcm9wZXJ0eShkZWZhdWx0S2V5KSkgPyBjb25maWdbZGVmYXVsdEtleV0gOiBkZWZhdWx0Q29uZmlnW2RlZmF1bHRLZXldO1xyXG4gICAgICAgICAgICAgICAgc3R5bGluZyArPSAnOyc7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICAgICAgcmV0dXJuIHN0eWxpbmc7XHJcbiAgICB9XHJcblxyXG4gICAgLy8gPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09IExpbmUgb25seSA9PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09XHJcblxyXG4gICAgLyoqXHJcbiAgICAgKiBjaGVjayBpZiBsaW5lIG1pc3NpbmdcclxuICAgICAqIHBhcmFtIHtbdHlwZV19IF9kYXRhICAgICAgICBkYXRhXHJcbiAgICAgKiBwYXJhbSB7W3R5cGVdfSBfZGF0YUluZGV4ICAgeEluZGV4XHJcbiAgICAgKiBwYXJhbSB7W3R5cGVdfSBfc2VyaWVzSW5kZXggeUluZGV4IC8geVZhbHVlSW5kZXhcclxuICAgICAqL1xyXG4gICAgcHVibGljIGlzU2VyaWVzTnVsbChfZGF0YTogSUNoYXJ0RGF0YSB8IEFycmF5PElEM0RhdGFEYXRhPiwgX2RhdGFJbmRleDogbnVtYmVyLCBfc2VyaWVzSW5kZXg6IG51bWJlcik6IHtcclxuICAgICAgICBpc1ByZXZOdWxsOiBib29sZWFuLFxyXG4gICAgICAgIGlzUHJldk5vdE51bGw6IGJvb2xlYW4sXHJcbiAgICAgICAgaXNOZXh0TnVsbDogYm9vbGVhbixcclxuICAgICAgICBpc05leHROb3ROdWxsOiBib29sZWFuLFxyXG4gICAgICAgIGlzQXBwZWFyaW5nOiBib29sZWFuLFxyXG4gICAgICAgIGlzRGlzYXBwZWFyaW5nOiBib29sZWFuXHJcbiAgICB9IHtcclxuXHJcbiAgICAgICAgbGV0IGN1cnJlbnRWYWw6IG51bWJlciA9IDA7XHJcbiAgICAgICAgbGV0IGRhdGFMZW5ndGg6IG51bWJlciA9IDA7XHJcbiAgICAgICAgbGV0IGlzSUNoYXJ0RGF0YSA9IHRoaXMuX2lzQ2hhcnREYXRhO1xyXG5cclxuICAgICAgICBpZiAoaXNJQ2hhcnREYXRhKF9kYXRhKSkge1xyXG4gICAgICAgICAgICBjdXJyZW50VmFsID0gX2RhdGEuc2VyaWVzW19zZXJpZXNJbmRleF0uZGF0YVtfZGF0YUluZGV4XS52YWx1ZTtcclxuICAgICAgICAgICAgZGF0YUxlbmd0aCA9IF9kYXRhLnhBeGlzLmNhdGVnb3JpZXMubGVuZ3RoO1xyXG4gICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgIGN1cnJlbnRWYWwgPSBfZGF0YVtfZGF0YUluZGV4XS55W19zZXJpZXNJbmRleF0udmFsdWU7XHJcbiAgICAgICAgICAgIGRhdGFMZW5ndGggPSBfZGF0YS5sZW5ndGg7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICBmdW5jdGlvbiBnZXRWYWx1ZSh3aGVuOiBzdHJpbmcsIGlzTnVsbDogYm9vbGVhbik6IGJvb2xlYW4ge1xyXG4gICAgICAgICAgICBsZXQgaW5kZXg6IG51bWJlciA9IDA7XHJcbiAgICAgICAgICAgIGlmICh3aGVuID09PSAncHJldicpIHtcclxuICAgICAgICAgICAgICAgIGlmIChfZGF0YUluZGV4ID4gMCkge1xyXG4gICAgICAgICAgICAgICAgICAgIGluZGV4ID0gX2RhdGFJbmRleCAtIDE7XHJcbiAgICAgICAgICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBmYWxzZTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgICAgIGlmIChfZGF0YUluZGV4IDwgZGF0YUxlbmd0aCAtIDEpIHtcclxuICAgICAgICAgICAgICAgICAgICBpbmRleCA9IF9kYXRhSW5kZXggKyAxO1xyXG4gICAgICAgICAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgICAgICAgICByZXR1cm4gZmFsc2U7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgIGxldCB2YWx1ZTogbnVtYmVyID0gKGlzSUNoYXJ0RGF0YShfZGF0YSkgPyBfZGF0YS5zZXJpZXNbX3Nlcmllc0luZGV4XS5kYXRhW2luZGV4XS52YWx1ZSA6IF9kYXRhW2luZGV4XS55W19zZXJpZXNJbmRleF0udmFsdWUpO1xyXG5cclxuICAgICAgICAgICAgaWYgKGlzTnVsbCkge1xyXG4gICAgICAgICAgICAgICAgcmV0dXJuIHZhbHVlID09PSBudWxsO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIHJldHVybiB2YWx1ZSAhPT0gbnVsbDtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIGxldCBpc1ByZXZOdWxsOiBib29sZWFuID0gZ2V0VmFsdWUoJ3ByZXYnLCB0cnVlKTtcclxuICAgICAgICBsZXQgaXNQcmV2Tm90TnVsbDogYm9vbGVhbiA9IGdldFZhbHVlKCdwcmV2JywgZmFsc2UpO1xyXG4gICAgICAgIGxldCBpc05leHROdWxsOiBib29sZWFuID0gZ2V0VmFsdWUoJ25leHQnLCB0cnVlKTtcclxuICAgICAgICBsZXQgaXNOZXh0Tm90TnVsbDogYm9vbGVhbiA9IGdldFZhbHVlKCduZXh0JywgZmFsc2UpO1xyXG5cclxuICAgICAgICBsZXQgaXNBcHBlYXJpbmc6IGJvb2xlYW4gPSBpc05leHROb3ROdWxsICYmIGN1cnJlbnRWYWwgIT09IG51bGwgJiYgaXNQcmV2TnVsbDtcclxuXHJcbiAgICAgICAgbGV0IGlzRGlzYXBwZWFyaW5nOiBib29sZWFuID0gaXNOZXh0TnVsbCAmJiBjdXJyZW50VmFsICE9PSBudWxsICYmIGlzUHJldk5vdE51bGw7XHJcblxyXG4gICAgICAgIHJldHVybiB7XHJcbiAgICAgICAgICAgIGlzUHJldk51bGw6IGlzUHJldk51bGwsXHJcbiAgICAgICAgICAgIGlzUHJldk5vdE51bGw6IGlzUHJldk5vdE51bGwsXHJcbiAgICAgICAgICAgIGlzTmV4dE51bGw6IGlzTmV4dE51bGwsXHJcbiAgICAgICAgICAgIGlzTmV4dE5vdE51bGw6IGlzTmV4dE5vdE51bGwsXHJcbiAgICAgICAgICAgIGlzQXBwZWFyaW5nOiBpc0FwcGVhcmluZyxcclxuICAgICAgICAgICAgaXNEaXNhcHBlYXJpbmc6IGlzRGlzYXBwZWFyaW5nXHJcbiAgICAgICAgfTtcclxuICAgIH1cclxuXHJcbiAgICBwdWJsaWMgX2lzQ2hhcnREYXRhKG9iamVjdDogYW55KTogb2JqZWN0IGlzIElDaGFydERhdGEge1xyXG4gICAgICAgIHJldHVybiAnc2VyaWVzJyBpbiBvYmplY3Q7XHJcbiAgICB9XHJcblxyXG4gICAgLy8gPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09IEtkIENoYXJ0IG9ubHkgPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PVxyXG5cclxuICAgIC8qKlxyXG4gICAgICogcmVxdWlyZWQgZm9yIHBlcmNlbnRhZ2UgY2FsY3VsYXRpb24gb2YgMTAwIHN0YWNrLiByZXR1cm5zIGEgYXJyYXkgb2YgdG90YWwgc3VtIG9mIGRhdGEgdmFsdWUgb2YgZWFjaCBjYXRlZ29yaWVzLlxyXG4gICAgICogcGFyYW0gIHtBcnJheTxJU2VyaWVzPn0gX3Nlcmllc0FyclxyXG4gICAgICogcGFyYW0gIHtBcnJheTxzdHJpbmc+fSAgX2NhdGVnb3JpZXNcclxuICAgICAqIHJldHVybiB7QXJyYXk8bnVtYmVyPn1cclxuICAgICAqL1xyXG4gICAgcHVibGljIGdldFRvdGFsU3VtQXJyRnJvbVNlcmllcyhfc2VyaWVzQXJyOiBBcnJheTxJU2VyaWVzPiwgX2NhdGVnb3JpZXM6IEFycmF5PHN0cmluZz4sIHNlcmllc0xlbmd0aDogbnVtYmVyKTogQXJyYXk8bnVtYmVyPiB7XHJcbiAgICAgICAgbGV0IHN1bUFycjogQXJyYXk8bnVtYmVyPiA9IFtdO1xyXG4gICAgICAgIGZvciAobGV0IGkgPSAwOyBpIDwgX2NhdGVnb3JpZXMubGVuZ3RoOyArK2kpIHtcclxuICAgICAgICAgICAgbGV0IHN1bTogbnVtYmVyID0gMDtcclxuICAgICAgICAgICAgZm9yIChsZXQgaiA9IDA7IGogPCBzZXJpZXNMZW5ndGg7ICsraikge1xyXG4gICAgICAgICAgICAgICAgaWYgKHR5cGVvZiBfc2VyaWVzQXJyW2pdLmRhdGFbaV0gPT09ICd1bmRlZmluZWQnKSBjb250aW51ZTtcclxuICAgICAgICAgICAgICAgIGxldCBjdXJyZW50VmFsOiBudW1iZXIgfCBudWxsID0gX3Nlcmllc0FycltqXS5kYXRhW2ldLnZhbHVlO1xyXG4gICAgICAgICAgICAgICAgaWYgKHR5cGVvZiBjdXJyZW50VmFsID09PSAndW5kZWZpbmVkJykgY29udGludWU7XHJcbiAgICAgICAgICAgICAgICBzdW0gPSAoY3VycmVudFZhbCA9PT0gbnVsbCkgPyBzdW0gOiBzdW0gKyBjdXJyZW50VmFsO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIHN1bUFyci5wdXNoKHN1bSk7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIHJldHVybiBzdW1BcnI7XHJcbiAgICB9XHJcblxyXG4gICAgLy8gPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09IFBpZSBvbmx5ID09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT1cclxuICAgIC8qKlxyXG4gICAgICogY2hlY2sgaWYgbGluZSBtaXNzaW5nXHJcbiAgICAgKiBwYXJhbSB7W2tleTogc3RyaW5nXTogSUxlZ2VuZERhdGF9IF9sZWdlbmREYXRhIHBpZSBjaGFydCBsZWdlbmQgZGF0YVxyXG4gICAgICogcGFyYW0ge2FueX0gX2RhdGEgcGllIGNoYXJ0IGRhdGFcclxuICAgICAqIHBhcmFtIHtJQ2hhcnRDb25maWd9IF9jb25maWcgcGllIGNoYXJ0IGxlZ2VuZCBjb25maWdcclxuICAgICAqL1xyXG4gICAgcHVibGljIHNldFBpZURhdGEoX2xlZ2VuZERhdGE6IHsgW2tleTogc3RyaW5nXTogSUxlZ2VuZERhdGEgfSwgX2RhdGE6IGFueSwgX2NvbmZpZzogSUNoYXJ0Q29uZmlnLCBfc2VyaWVzVGhyZXNob2xkOiBudW1iZXIpOiB7XHJcbiAgICAgICAgcGllRGF0YTogQXJyYXk8YW55PixcclxuICAgICAgICBwaWVDb2xvcjogQXJyYXk8c3RyaW5nPixcclxuICAgICAgICBsZWdlbmREYXRhOiB7IFtrZXk6IHN0cmluZ106IElMZWdlbmREYXRhIH0sXHJcbiAgICB9IHtcclxuICAgICAgICBsZXQgcGllRGF0YTogQXJyYXk8YW55PiA9IFtdO1xyXG4gICAgICAgIGxldCBwaWVDb2xvcjogQXJyYXk8c3RyaW5nPiA9IFtdO1xyXG4gICAgICAgIGxldCBsZWdlbmRJZDogc3RyaW5nO1xyXG4gICAgICAgIGxldCBwaWVEYXRhQXJyYXlMZW5ndGg6IG51bWJlciA9IDA7XHJcbiAgICAgICAgbGV0IGNvbmZpZ0RhdGFBcnJheTogQXJyYXk8SUxlZ2VuZERhdGE+ID0gT2JqZWN0LmtleXMoX2xlZ2VuZERhdGEpLm1hcChrZXkgPT4gX2xlZ2VuZERhdGFba2V5XSk7XHJcbiAgICAgICAgX2xlZ2VuZERhdGEgPSB7fTtcclxuICAgICAgICBmb3IgKGxldCBpID0gMDsgaSA8IF9kYXRhLmRhdGEubGVuZ3RoOyBpKyspIHtcclxuICAgICAgICAgICAgZm9yIChsZXQgaiA9IDA7IGogPCBfZGF0YS5kYXRhW2ldLnkubGVuZ3RoOyBqKyspIHtcclxuICAgICAgICAgICAgICAgIGZvciAobGV0IGsgPSAwOyBrIDwgY29uZmlnRGF0YUFycmF5Lmxlbmd0aDsgaysrKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKF9kYXRhLmRhdGFbaV0ueVtqXVsnaWQnXSA9PT0gY29uZmlnRGF0YUFycmF5W2tdLmlkKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGlmICh0eXBlb2YgX2RhdGEuc2VyaWVzWzBdLmRhdGFbaV0ueSAhPT0gJ3VuZGVmaW5lZCcpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmICgoX3Nlcmllc1RocmVzaG9sZCAhPT0gdW5kZWZpbmVkICYmIF9zZXJpZXNUaHJlc2hvbGQgIT09IG51bGwgJiYgcGllRGF0YUFycmF5TGVuZ3RoIDwgX3Nlcmllc1RocmVzaG9sZCkgfHwgX3Nlcmllc1RocmVzaG9sZCA9PT0gdW5kZWZpbmVkIHx8IF9zZXJpZXNUaHJlc2hvbGQgPT09IG51bGwpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBsZXQgY29sb3JQb2ludGVyID0gX2RhdGEuZGF0YVtpXS55W2pdWydjb2xvciddO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxldCBjb2xvclZhbHVlID0gKGNvbG9yUG9pbnRlciAmJiBjb2xvclBvaW50ZXIgIT0gbnVsbCAmJiBjb2xvclBvaW50ZXIgIT0gbnVsbCkgPyBjb2xvclBvaW50ZXIgOiB0aGlzLmdldERlZmF1bHRDb25maWcoJ2NvbG9yJywgcGllRGF0YUFycmF5TGVuZ3RoLCBfY29uZmlnKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBsZWdlbmRJZCA9ICdpZCcgKyBwaWVEYXRhQXJyYXlMZW5ndGg7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgX2xlZ2VuZERhdGFbbGVnZW5kSWRdID0ge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAnbmFtZSc6IF9kYXRhLmRhdGFbaV0ueCArICcgJyArIGNvbmZpZ0RhdGFBcnJheVtrXS5uYW1lLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAnaWQnOiBsZWdlbmRJZCxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgJ3NoYXBlJzogJ2NpcmNsZScsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICd4JzogX2RhdGEuZGF0YVtpXS54ICsgJyAnICsgY29uZmlnRGF0YUFycmF5W2tdLm5hbWUsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICd5JzogX2RhdGEuZGF0YVtpXS55W2pdWyd2YWx1ZSddLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAneEJhc2UnOiBfZGF0YS5kYXRhW2ldLngsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICdpbmRleCc6ICdwaWUnICsgcGllRGF0YUFycmF5TGVuZ3RoLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAnY29sb3InOiBjb2xvclZhbHVlLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAnc2VyaWVzSW5kZXgnOiBqLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAnZGF0YUluZGV4JzogaVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH07XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcGllQ29sb3IucHVzaChjb2xvclZhbHVlKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBwaWVEYXRhLnB1c2goe1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAnaWQnOiBsZWdlbmRJZCxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgJ3gnOiBfZGF0YS5kYXRhW2ldLnggKyAnICcgKyBjb25maWdEYXRhQXJyYXlba10ubmFtZSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgJ3knOiBfZGF0YS5kYXRhW2ldLnlbal1bJ3ZhbHVlJ10sXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICd4QmFzZSc6IF9kYXRhLmRhdGFbaV0ueCxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgJ2luZGV4JzogJ3BpZScgKyBwaWVEYXRhQXJyYXlMZW5ndGgsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICdjb2xvcic6IGNvbG9yVmFsdWUsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICdzZXJpZXNJbmRleCc6IGosXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICdkYXRhSW5kZXgnOiBpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcGllRGF0YUFycmF5TGVuZ3RoKys7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICAgICAgbGV0IHJldHVyblBhcmFtcyA9IHtcclxuICAgICAgICAgICAgJ3BpZURhdGEnOiBwaWVEYXRhLFxyXG4gICAgICAgICAgICAncGllQ29sb3InOiBwaWVDb2xvcixcclxuICAgICAgICAgICAgJ2xlZ2VuZERhdGEnOiBfbGVnZW5kRGF0YVxyXG4gICAgICAgIH07XHJcbiAgICAgICAgcmV0dXJuIHJldHVyblBhcmFtcztcclxuICAgIH1cclxuXHJcbiAgICBwdWJsaWMgc2luZ2xlUGllRGF0YU1hc3NhZ2UoX2xlZ2VuZERhdGE6IHsgW2tleTogc3RyaW5nXTogSUxlZ2VuZERhdGEgfSwgX2RhdGE6IGFueSwgX2NvbmZpZzogSUNoYXJ0Q29uZmlnLCBfc2VyaWVzVGhyZXNob2xkOiBudW1iZXIpIHtcclxuICAgICAgICBsZXQgcGllRGF0YTogQXJyYXk8YW55PiA9IFtdO1xyXG4gICAgICAgIGxldCBwaWVDb2xvcjogQXJyYXk8c3RyaW5nPiA9IFtdO1xyXG4gICAgICAgIGxldCBsZWdlbmRJZDogc3RyaW5nO1xyXG4gICAgICAgIGxldCBwaWVEYXRhQXJyYXlMZW5ndGg6IG51bWJlciA9IDA7XHJcbiAgICAgICAgX2xlZ2VuZERhdGEgPSB7fTtcclxuICAgICAgICBpZiAoX2RhdGEuc2VyaWVzICYmIF9kYXRhLnNlcmllc1swXSAmJiBfZGF0YS5zZXJpZXNbMF0uZGF0YSkge1xyXG4gICAgICAgICAgICBmb3IgKGxldCBpID0gMDsgaSA8IF9kYXRhLnNlcmllc1swXS5kYXRhLmxlbmd0aDsgaSsrKSB7XHJcbiAgICAgICAgICAgICAgICBpZiAodHlwZW9mIF9kYXRhLnNlcmllc1swXS5kYXRhW2ldLnkgIT09ICd1bmRlZmluZWQnKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKChfc2VyaWVzVGhyZXNob2xkICE9IHVuZGVmaW5lZCAmJiBfc2VyaWVzVGhyZXNob2xkICE9IG51bGwgJiYgcGllRGF0YUFycmF5TGVuZ3RoIDwgX3Nlcmllc1RocmVzaG9sZCkgfHwgX3Nlcmllc1RocmVzaG9sZCA9PSB1bmRlZmluZWQgfHwgX3Nlcmllc1RocmVzaG9sZCA9PSBudWxsKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGxldCBjb2xvclBvaW50ZXIgPSBfZGF0YS5zZXJpZXNbMF0uZGF0YVtpXVsnY29sb3InXTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgbGV0IGNvbG9yVmFsdWUgPSAoY29sb3JQb2ludGVyICYmIGNvbG9yUG9pbnRlciAhPSBudWxsICYmIGNvbG9yUG9pbnRlciAhPSBudWxsKSA/IGNvbG9yUG9pbnRlciA6IHRoaXMuZ2V0RGVmYXVsdENvbmZpZygnY29sb3InLCBwaWVEYXRhQXJyYXlMZW5ndGgsIF9jb25maWcpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBsZWdlbmRJZCA9ICdpZCcgKyBwaWVEYXRhQXJyYXlMZW5ndGg7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIF9sZWdlbmREYXRhW2xlZ2VuZElkXSA9IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICduYW1lJzogX2RhdGEuc2VyaWVzWzBdLmRhdGFbaV0ubmFtZS5yZXBsYWNlKC/CrC9nLCAnICcpLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgJ2lkJzogbGVnZW5kSWQsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAnc2hhcGUnOiAnY2lyY2xlJyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICd4JzogX2RhdGEuc2VyaWVzWzBdLmRhdGFbaV0ubmFtZSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICd5JzogX2RhdGEuc2VyaWVzWzBdLmRhdGFbaV0ueSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICd4QmFzZSc6IF9kYXRhLnNlcmllc1swXS5kYXRhW2ldLm5hbWUsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAnaW5kZXgnOiAncGllJyArIHBpZURhdGFBcnJheUxlbmd0aCxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICdjb2xvcic6IGNvbG9yVmFsdWUsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH07XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHBpZUNvbG9yLnB1c2goY29sb3JWYWx1ZSk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGlmIChfZGF0YS5zZXJpZXNbMF0uZGF0YVtpXS55ICYmIF9kYXRhLnNlcmllc1swXS5kYXRhW2ldLnkgPiAwKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBwaWVEYXRhLnB1c2goe1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICdpZCc6IGxlZ2VuZElkLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICd4JzogX2RhdGEuc2VyaWVzWzBdLmRhdGFbaV0ubmFtZSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAneSc6IF9kYXRhLnNlcmllc1swXS5kYXRhW2ldLnksXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgJ3hCYXNlJzogX2RhdGEuc2VyaWVzWzBdLmRhdGFbaV0ubmFtZSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAnaW5kZXgnOiAncGllJyArIHBpZURhdGFBcnJheUxlbmd0aCxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAnY29sb3InOiBjb2xvclZhbHVlLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHBpZURhdGFBcnJheUxlbmd0aCsrO1xyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgICAgICBsZXQgcmV0dXJuUGFyYW1zID0ge1xyXG4gICAgICAgICAgICAncGllRGF0YSc6IHBpZURhdGEsXHJcbiAgICAgICAgICAgICdwaWVDb2xvcic6IHBpZUNvbG9yLFxyXG4gICAgICAgICAgICAnbGVnZW5kRGF0YSc6IF9sZWdlbmREYXRhXHJcbiAgICAgICAgfTtcclxuICAgICAgICByZXR1cm4gcmV0dXJuUGFyYW1zO1xyXG4gICAgfVxyXG5cclxuICAgIHB1YmxpYyBzZXRNYXBMZWdlbmREYXRhKF9sZWdlbmREYXRhOiB7IFtrZXk6IHN0cmluZ106IElMZWdlbmREYXRhIH0sIF9kYXRhOiBhbnksIF9jb25maWc6IElDaGFydENvbmZpZykge1xyXG4gICAgICAgIGxldCBsZWdlbmRJZDogc3RyaW5nO1xyXG4gICAgICAgIF9sZWdlbmREYXRhID0ge307XHJcbiAgICAgICAgZm9yIChsZXQgaSA9IDA7IGkgPCBfZGF0YS5sZW5ndGg7IGkrKykge1xyXG4gICAgICAgICAgICBpZiAoX2RhdGFbaV0ubmFtZSAhPSB1bmRlZmluZWQpIHtcclxuICAgICAgICAgICAgICAgIGxldCBjb2xvclBvaW50ZXIgPSBfZGF0YVtpXS5jb2xvcjtcclxuICAgICAgICAgICAgICAgIGxlZ2VuZElkID0gJ2lkJyArIGk7XHJcbiAgICAgICAgICAgICAgICBfbGVnZW5kRGF0YVtsZWdlbmRJZF0gPSB7XHJcbiAgICAgICAgICAgICAgICAgICAgJ25hbWUnOiBfZGF0YVtpXS5uYW1lLFxyXG4gICAgICAgICAgICAgICAgICAgICdpZCc6IGxlZ2VuZElkLFxyXG4gICAgICAgICAgICAgICAgICAgICdzaGFwZSc6ICdjaXJjbGUnLFxyXG4gICAgICAgICAgICAgICAgICAgICd4JzogX2RhdGFbaV0ubmFtZSxcclxuICAgICAgICAgICAgICAgICAgICAneSc6IF9kYXRhW2ldLmRhdGFbMF0udmFsdWUsXHJcbiAgICAgICAgICAgICAgICAgICAgJ3hCYXNlJzogX2RhdGFbaV0ubmFtZSxcclxuICAgICAgICAgICAgICAgICAgICAnY29sb3InOiAoY29sb3JQb2ludGVyICYmIGNvbG9yUG9pbnRlciAhPSBudWxsICYmIGNvbG9yUG9pbnRlciAhPSB1bmRlZmluZWQpID8gY29sb3JQb2ludGVyIDogdGhpcy5nZXREZWZhdWx0Q29uZmlnKCdjb2xvcicsIGksIF9jb25maWcpLFxyXG4gICAgICAgICAgICAgICAgICAgICdtYXBTZXJpZXNJZCc6IF9kYXRhW2ldLmlkLFxyXG4gICAgICAgICAgICAgICAgICAgICdkZWFjdGl2ZSc6IF9kYXRhW2ldLmRlYWN0aXZlXHJcbiAgICAgICAgICAgICAgICB9O1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgICAgIHJldHVybiBfbGVnZW5kRGF0YTtcclxuICAgIH1cclxuXHJcbiAgICBwdWJsaWMgZ2V0RGVmYXVsdENvbmZpZyhfZWxlbWVudDogYW55LCBfc2VyaWVzSW5kZXg6IG51bWJlciwgX2NvbmZpZzogSUNoYXJ0Q29uZmlnKTogc3RyaW5nIHtcclxuICAgICAgICBpZiAoX2VsZW1lbnQgPT09ICdzaGFwZScpIHJldHVybiAnY2lyY2xlJztcclxuXHJcbiAgICAgICAgaWYgKF9zZXJpZXNJbmRleCB8fCBfc2VyaWVzSW5kZXggPT09IDApIHtcclxuICAgICAgICAgICAgcmV0dXJuIF9jb25maWcuY29sb3JzW19zZXJpZXNJbmRleCAlIF9jb25maWcuY29sb3JzLmxlbmd0aF07XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIHB1YmxpYyBzZXRTaW5nbGVMZWdlbmRMZXZlbHMoX2RhdGFDbGFzc2VzOiBBcnJheTxhbnk+LCBfZGVjaW1hbFByZWNpc29uOiBudW1iZXIsIF92YWx1ZVN1ZmZpeDogc3RyaW5nLCBfb3JpZ2luYWxMZWdlbmQ/OiB7IFtrZXk6IHN0cmluZ106IElMZWdlbmREYXRhIH0pOiB7IFtrZXk6IHN0cmluZ106IElMZWdlbmREYXRhIH0ge1xyXG4gICAgICAgIGxldCBfbGVnZW5kRGF0YTogeyBba2V5OiBzdHJpbmddOiBJTGVnZW5kRGF0YSB9ID0ge307XHJcbiAgICAgICAgZm9yIChsZXQgaSA9IDA7IGkgPCBfZGF0YUNsYXNzZXMubGVuZ3RoOyBpKyspIHtcclxuICAgICAgICAgICAgbGV0IGxlZ2VuZElkOiBzdHJpbmcgPSAnaWQnICsgaTtcclxuICAgICAgICAgICAgX2xlZ2VuZERhdGFbbGVnZW5kSWRdID0ge1xyXG4gICAgICAgICAgICAgICAgJ25hbWUnOiBfZGF0YUNsYXNzZXNbaV0uZnJvbS50b0ZpeGVkKF9kZWNpbWFsUHJlY2lzb24pICsgX3ZhbHVlU3VmZml4ICsgJyAtICcgKyBfZGF0YUNsYXNzZXNbaV0udG8udG9GaXhlZChfZGVjaW1hbFByZWNpc29uKSArIF92YWx1ZVN1ZmZpeCxcclxuICAgICAgICAgICAgICAgICdpZCc6IGxlZ2VuZElkLFxyXG4gICAgICAgICAgICAgICAgJ3NoYXBlJzogJ2NpcmNsZScsXHJcbiAgICAgICAgICAgICAgICAnY29sb3InOiBfZGF0YUNsYXNzZXNbaV0uY29sb3IsXHJcbiAgICAgICAgICAgICAgICAnZGVhY3RpdmUnOiBfb3JpZ2luYWxMZWdlbmQgJiYgX29yaWdpbmFsTGVnZW5kW2xlZ2VuZElkXSA/IF9vcmlnaW5hbExlZ2VuZFtsZWdlbmRJZF0uZGVhY3RpdmUgOiBmYWxzZVxyXG4gICAgICAgICAgICB9O1xyXG5cclxuICAgICAgICB9XHJcbiAgICAgICAgcmV0dXJuIF9sZWdlbmREYXRhO1xyXG4gICAgfVxyXG59XHJcbiJdfQ==