import * as d3 from 'd3';
import { LABEL_TEXT_VERTICAL_ALIGN_STORE, TOOLTIP_DEFAULT_STYLE } from './kd-angular-charts-config';
export class KdChartBaseClass {
    constructor(_chartSvc, _domSvc) {
        this._chartSvc = _chartSvc;
        this._domSvc = _domSvc;
        // Chart Setting
        this.isRtl = false;
        this.config = {};
        this.data = [];
        this.initData = [];
        this.xAxisArr = [];
        this.axisMin = 0;
        this.axisLabelContainerArr = [];
        this.haveNegative = false;
        /**
         * used only by bar.
         * barGroupPadding is used only for cluster --> the padding between each rect in a category
         * bandPadding is given to d3 --> the padding between each category
         * type {IBaseClassBarObj}
         */
        this.bar = {
            isInvert: false,
            clusterPaddingPercent: 0.1,
            bandPadding: 0.2,
        };
        this.lengthOfTransition = 1000;
        this.errorMsg = '100% stack does not support negative values.';
        this.isRtl = _domSvc.getDocumentDirection(true) === 'right';
    }
    // ================================= Chart ==================================
    setSvg() {
        this.svg = d3.select('#' + this.config.id + '.kdx-charts svg');
        if (!this.graph)
            this.graph = this.svg.append('g').attr('class', 'graph');
        // if (this.svg.select('.graph').empty()) this.graph = this.svg.append('g').attr('class', 'graph');
        this.svgParent = d3.select('#' + this.config.id + '.kdx-charts .kdx-chart-container');
        this.svgContainer = d3.select('#' + this.config.id + '.kdx-charts .kdx-charts-svg-container');
        this._setLabelContainer();
        this._setChartSvc();
        this.rangeList = {};
    }
    /**
     * set svg width and height. this function is becos of export feature, the export plugins requires svg width and height to be inline attributes with definite number
     * have to be called by all charts
     * param {'x' | 'y'} _axis
     */
    setSvgDimension(_axis) {
        let svgContainerRect = this.svgContainer.node().getBoundingClientRect();
        let type = _axis === 'x' ? (this.bar.isInvert ? 'height' : 'width') : (this.bar.isInvert ? 'width' : 'height');
        this.svg.attr(type, svgContainerRect[type]);
    }
    _clearSvgDimension() {
        if (!this.svg)
            return;
        this.svg
            .attr('width', 0)
            .attr('height', 0);
    }
    /**
     * set this.width and this.height for axis scales. only called by charts with axis
     * param {'x' |'y'}         _axis
     * param {boolean} _skipCal : skip getSvgOffset calculations
     */
    _setGraphDimension(_axis) {
        this.svgRect = this.svg.node().getBoundingClientRect();
        this._chartSvc.svgRect = this.svgRect;
        let type = _axis === 'x' ? (this.bar.isInvert ? 'height' : 'width') : (this.bar.isInvert ? 'width' : 'height');
        let value = this._chartSvc.getSvgOffset(_axis, { axisMax: this.axisMax, axisMin: this.axisMin });
        this[type] = value < 0 ? 0 : value;
    }
    /**
     * set Chart Service variables
     */
    _setChartSvc() {
        this._chartSvc.config = this.config;
        this._chartSvc.chartType = this.chartType;
        this._chartSvc.chartCategory = this.chartCategory;
        this._chartSvc.svgParentRect = this.svgParent.node().getBoundingClientRect();
        this._chartSvc.svg = this.svg;
        this._chartSvc.isRtl = this.isRtl;
        this._chartSvc.isXReversed = this.config.xAxis.reversed;
        this._chartSvc.isYReversed = this.config.yAxis.reversed;
    }
    _setLinearScale() {
        let rangeRoundVal = this._getRangeVal('y');
        this.y = d3.scaleLinear().rangeRound(rangeRoundVal);
    }
    _setBandScale() {
        let rangeVal = this._getRangeVal('x');
        this.x = d3.scaleBand().range(rangeVal);
        if (this.chartCategory === 'bar') {
            this.x.paddingInner(this.bar.bandPadding).paddingOuter(this.bar.bandPadding / 2);
        }
    }
    _getRangeVal(_axis) {
        let rangeVal;
        let reversed = _axis === 'x' ? 'isXReversed' : 'isYReversed';
        if (this.bar.isInvert) {
            rangeVal = _axis === 'x' ? [0, this.height] : [0, this.width];
        }
        else {
            rangeVal = _axis === 'x' ? [0, this.width] : [this.height, 0];
        }
        return this._chartSvc[reversed] ? rangeVal.reverse() : rangeVal;
    }
    _setRange(isBand) {
        let chartWidth = this.width;
        if (!isBand && this.data.length <= 0) {
            this.rangeList[0] = chartWidth;
            return [0, chartWidth];
        }
        let xPosition = 0;
        let rangeArray = [];
        let bandWidth = chartWidth / this.data.length;
        for (let i = 0; i < this.data.length; i++) {
            if (isBand) {
                xPosition = this._getCenterBandPosition(bandWidth, i);
            }
            else {
                xPosition = chartWidth / (this.data.length - 1) * i;
            }
            if (this._chartSvc.isXReversed)
                xPosition = chartWidth - xPosition;
            rangeArray.push(xPosition);
            this.rangeList[this.data[i].x.value] = xPosition;
        }
        return rangeArray;
    }
    _getCenterBandPosition(_bandWidth, _position) {
        return (_bandWidth / 2) + (_bandWidth * _position);
    }
    _setScaleByDirection(_axis, _xScaleType) {
        if (_axis === 'x') {
            if (_xScaleType !== 'string')
                this._setBandScale();
            if (this.chartCategory === 'line')
                this._setLineScaleX(_xScaleType);
        }
        else {
            this._setLinearScale();
        }
    }
    /**
     * (for line only)
     * happens at first load and on change and may happen if data is sliced during trimX()
     */
    _setLineScaleX(_xScaleType) {
        if (_xScaleType === 'string') {
            this.x = d3.scaleOrdinal().range(this._setRange(false));
        }
        else {
            this._setRange(true);
        }
    }
    // ================================= Domain ==================================
    setDomain(_xScaleType) {
        this._chartSvc.xScaleType = _xScaleType;
        this.svg.attr('visibility', 'hidden');
        // setting the class name of chart-wrapper (for flex-reverse)
        this._chartSvc.setVertAxisAndChartMargin(this.config.id);
        // everytime the graph resets, if trimming have occured before (ie: this.data and initData length differs), reset this.data so that the trimming calculation uses full dataset
        if (this.initData && this.data.length !== this.initData.length) {
            this.data = JSON.parse(JSON.stringify(this.initData));
            // this._chartSvc.setAxisLabelDummyText(this.categories, this.config.xAxis.labels.format);
        }
        // set this.width,height, scale, domain and tickValues
        this._setDomain(_xScaleType);
        this.svg.attr('visibility', 'visible');
        // set major and minor grid lines
        this._setGridLines();
        // set y and x axis lines
        this.setAxis();
        // transform graph according to width of vertical axis
        this._chartSvc.transformGraphContainer(this.graph);
        // reposition Data Label according to width of vertical axis
        if (this.config.chart.labels.enabled) {
            this.dataLabelContainer.style('width', this.width + 'px');
            this._chartSvc.repositionDataLabel(this.dataLabelContainer, this.axisLabelContainerArr[0]);
        }
        // reposition vertical axis
        this._chartSvc.repositionVerticalAxisTitle();
        // set clip path to this.width and this.height to make sure graph will not be drawn out of graphing region
        this._setClipPath();
    }
    _setDomain(_xScaleType) {
        // finding the max/min value and axisMax/axisMin
        let axisLabelConfig = this.config.yAxis;
        let result = this._chartSvc.setMaxAndMin(axisLabelConfig, this.dataRange);
        this._chartSvc.setAxisD3Format(result.interval);
        this._setAxisMaxAndMin(result.maxValue, result.minValue, result.interval);
        let xInfo = this._chartSvc.getXInfo(this.data, this.config);
        this._setWidthHeightScale('x', _xScaleType);
        this.x.domain(xInfo.value);
        this._setXAxisLabel(_xScaleType, xInfo.longestText);
        this._setWidthHeightScale('y', _xScaleType);
        let tickValueReturn = this._findIntervalForNoOverlap(result);
        if (tickValueReturn && tickValueReturn.needRedraw) {
            this._setWidthHeightScale('x', _xScaleType);
            this.x.domain(xInfo.value);
            this._setXAxisLabel(_xScaleType, xInfo.longestText);
            this._setWidthHeightScale('y', _xScaleType);
        }
        // only generate range arr when interval is stablized
        this.tickValues = this._chartSvc.getTickValues(this.axisMin, this.axisMax, tickValueReturn.interval);
        // set Y domain
        this.domainMax = axisLabelConfig.autoRoundToMax ? this.axisMax : result.maxValue;
        this.domainMin = axisLabelConfig.autoRoundToMin ? this.axisMin : result.minValue;
        this.y.domain([this.domainMin, this.domainMax]);
    }
    _setWidthHeightScale(_axis, _xScaleType) {
        this.setSvgDimension(_axis);
        this._setGraphDimension(_axis);
        this._setScaleByDirection(_axis, _xScaleType);
    }
    /**
     * set clip path to this.width and this.height to make sure graph will not be drawn out of graphing region
     */
    _setClipPath() {
        let clipPathRect = this.svg.selectAll('defs #kd-charts-clip-path-' + this.config.id + ' rect');
        if (clipPathRect.empty()) {
            clipPathRect = this.svg.insert('defs').append('clipPath').attr('id', 'kd-charts-clip-path-' + this.config.id).append('rect');
            clipPathRect
                .attr('x', 0)
                .attr('y', 0)
                .attr('fill', 'none');
        }
        clipPathRect
            .attr('width', this.width)
            .attr('height', this.height);
    }
    _setAxisMaxAndMin(_maxValue, _minValue, _interval) {
        let yAxisConfig = this.config.yAxis;
        this.axisMax = this._chartSvc.setAxisRoundValue(_maxValue, _interval, yAxisConfig.autoRoundToMax, 'up');
        this.axisMin = this._chartSvc.setAxisRoundValue(_minValue, _interval, yAxisConfig.autoRoundToMin, 'down');
    }
    /**
   * will return an object with following properties
   * needRedraw: to determine whether to redraw the axis (and reset the domain)
   * interval: pass out the lastest interval (that have no overlap) for performance reasons, so that the while loop will only run once on needRedraw
   */
    _findIntervalForNoOverlap(_initInfo) {
        let length = this.bar.isInvert ? this.width : this.height;
        if (length <= 0)
            return { needRedraw: false, interval: 0 };
        let tickLength;
        let initYAxisLabelWidth = Object.assign({}, this._chartSvc.yAxisLabelWidth);
        if (this.bar.isInvert) {
            // axisMax and axisMin is already appended as dummy to svg when calculating for this.width and this.height
            // we can direct access to the actual width instead of doing approximation calculation based on font-size (error as high as 1/2 of actual width)
            tickLength = Math.max(initYAxisLabelWidth.axisMax, initYAxisLabelWidth.axisMin);
        }
        else {
            tickLength = this._chartSvc.replaceStringWithNumber(this.config.yAxis.labels.style.fontSize);
        }
        let initInterval = _initInfo.interval;
        let interval = initInterval;
        let noOfTicks = Math.round((this.axisMax + interval - this.axisMin) / interval);
        if (length < tickLength || noOfTicks === 0)
            return { needRedraw: false, interval: 0 };
        let initLongerNum = this._chartSvc.getLongerNumber(this.axisMax, this.axisMin).toString().length;
        while ((length / noOfTicks) < tickLength && noOfTicks > 2) {
            interval = interval * 2;
            this._setAxisMaxAndMin(_initInfo.maxValue, _initInfo.minValue, interval);
            // when the interval changes, axisMax or axisMin does not change significantly (changes at most 1 digits place)
            // check that the current axisMax/Min is indeed longer than the initial axisMax/Min
            if (this.bar.isInvert && this._chartSvc.getLongerNumber(this.axisMax, this.axisMin).toString().length > initLongerNum) {
                tickLength = this._chartSvc.setDummyAxisLabel(this._chartSvc.getLongerNumber(this.axisMax, this.axisMin), 'axisMax');
            }
            noOfTicks = Math.round((this.axisMax + interval - this.axisMin) / interval);
        }
        // when overlap finishes, interval and axisMax/Min is changed compared to when getSvgOffset()
        // check that current interval results in same max label length, if not, redraw the axis and run getSvgOffset() again
        if (initInterval !== interval) {
            this._chartSvc.setAxisD3Format(interval);
            let newYAxisLabelWidth = this._chartSvc.getYAxisMaxAndMinLabelWidth({ axisMin: this.axisMin, axisMax: this.axisMax });
            if (newYAxisLabelWidth.axisMax !== initYAxisLabelWidth.axisMax || newYAxisLabelWidth.axisMin !== initYAxisLabelWidth.axisMin) {
                return { needRedraw: true, interval: interval };
            }
        }
        return { needRedraw: false, interval: interval };
    }
    // ================================= Grid Lines ==================================
    _setGridLines() {
        if (!this.gridLinesContainer)
            this.gridLinesContainer = this.graph.append('g').attr('class', 'kdx-charts-grid-line-container');
        this._chartSvc.gridSvc.graphDimension = { width: this.width, height: this.height };
        if (this._chartSvc.gridSvc.haveGrid(this.config, 'xAxis', 'gridLine'))
            this._setXAxisGrid();
        if (this._chartSvc.gridSvc.haveGrid(this.config, 'yAxis', 'minorGridLine'))
            this._setYAxisMinorGrid();
        if (this._chartSvc.gridSvc.haveGrid(this.config, 'yAxis', 'gridLine'))
            this._setYAxisGrid();
    }
    _setXAxisGrid() {
        // wrapper function around this.x so that grid will be drawn in center of paddingInner
        let scale = this._chartSvc.gridSvc.xAxisGridScale(this.x);
        // concat space to draw first grid line, Note: this.data may have been spliced by trimX
        let xData = [''].concat(this.data.map(data => data.x.value));
        // let xData: Array<string> = [''].concat(_categories);
        this._chartSvc.gridSvc.drawGridLine(this.gridLinesContainer, xData, 'xAxis', 'gridLine', scale);
    }
    // draw major grid line
    _setYAxisGrid() {
        this._chartSvc.gridSvc.drawGridLine(this.gridLinesContainer, this.tickValues, 'yAxis', 'gridLine', this.y);
    }
    _setYAxisMinorGrid() {
        let yAxisConfig = this.config.yAxis;
        if (yAxisConfig.minorTickInterval >= yAxisConfig.tickInterval || !yAxisConfig.minorTickInterval)
            return;
        let upperbound = this._chartSvc.setAxisRoundValue(this.domainMax, yAxisConfig.minorTickInterval, false, 'up');
        let lowerbound = this._chartSvc.setAxisRoundValue(this.domainMin, yAxisConfig.minorTickInterval, false, 'down');
        let minorTickValues = this._chartSvc.getTickValues(lowerbound, upperbound, yAxisConfig.minorTickInterval);
        this._chartSvc.gridSvc.drawGridLine(this.gridLinesContainer, minorTickValues, 'yAxis', 'minorGridLine', this.y);
    }
    // ================================= Axis ==================================
    setAxis() {
        let transformPos = {
            right: 'translate(' + this.width + ',0)',
            left: 'translate(0,0)',
            top: 'translate(0,0)',
            bottom: 'translate(0,' + this.height + ')'
        };
        let xAxisConfig = this.config.xAxis;
        let yAxisConfig = this.config.yAxis;
        let invert = this.bar.isInvert;
        let opposite = {
            x: invert ? xAxisConfig.opposite !== this.isRtl : xAxisConfig.opposite,
            y: invert ? yAxisConfig.opposite : yAxisConfig.opposite !== this.isRtl
        };
        let xAxis = this._getEachAxisFunc('x', opposite.x, invert);
        this.xAxisArr.push(xAxis);
        this.yAxis = this._getEachAxisFunc('y', opposite.y, invert);
        xAxis.attr('transform', this._chartSvc.getAxisTransformPos('x', opposite.x, transformPos));
        this.yAxis.attr('transform', this._chartSvc.getAxisTransformPos('y', opposite.y, transformPos));
        this._chartSvc.setAxisLabelConfig(xAxis, 'x');
        this._chartSvc.setAxisLabelConfig(this.yAxis, 'y');
        if (this._chartSvc.isNegativeStack) {
            let secondXAxis = this._getEachAxisFunc('x', !opposite.x, this.bar.isInvert);
            secondXAxis.attr('transform', this._chartSvc.getAxisTransformPos('x', !opposite.x, transformPos));
            this._chartSvc.setAxisLabelConfig(secondXAxis, 'x');
            this.xAxisArr.push(secondXAxis);
        }
    }
    _getEachAxisFunc(_axis, _opposite, _invert) {
        let axisFunc = getAxisFunc(_axis, this[_axis]);
        let axisClass = 'kdx-charts-axis axis-' + _axis;
        if ((_invert && _axis === 'x') || (!_invert && _axis === 'y')) {
            axisClass += ' kdx-charts-axis-vertical';
        }
        if (_opposite)
            axisClass += ' kdx-charts-axis-opposite';
        if (_axis === 'y') {
            axisFunc
                .tickValues(this.tickValues)
                .tickFormat((d) => {
                // note: only usecase is negative stack bar (in v3.7.0). will affect both yAxis label and tooltip and dataLabels
                let value = this._chartSvc.checkAndReturnLabelsPositive(d);
                return this._chartSvc.getYAxisLabelText(this.config.yAxis, value);
            });
        }
        let axisElem = this.graph.append('g').attr('class', axisClass).call(axisFunc);
        return axisElem;
        function getAxisFunc(_type, _scale) {
            if (_invert) {
                if (_type === 'x') {
                    if (_opposite)
                        return d3.axisRight(_scale);
                    return d3.axisLeft(_scale);
                }
                if (_type === 'y') {
                    if (_opposite)
                        return d3.axisTop(_scale);
                    return d3.axisBottom(_scale);
                }
            }
            else {
                if (_type === 'x') {
                    if (_opposite)
                        return d3.axisTop(_scale);
                    return d3.axisBottom(_scale);
                }
                if (_type === 'y') {
                    if (_opposite)
                        return d3.axisRight(_scale);
                    return d3.axisLeft(_scale);
                }
            }
        }
    }
    // ================================= Remove Chart ==================================
    chartTimeout(_callback) {
        // let delay = this.config.legend.enabled && this.chartCategory === 'pie'? 500 : 10;
        clearTimeout(this._setChartTimeout);
        this._setChartTimeout = setTimeout(() => {
            _callback();
        });
    }
    removeChart() {
        clearTimeout(this._setChartTimeout);
        this._removeElemInArrayForm('xAxisArr', (axis) => axis.remove());
        if (this.yAxis)
            this.yAxis.remove();
        if (this.dataLabelContainer)
            this.dataLabelContainer.selectAll('*').remove();
        this._removeElemInArrayForm('axisLabelContainerArr', (container) => container.selectAll('*').remove());
        if (this.gridLinesContainer)
            this.gridLinesContainer.selectAll('*').remove();
        this._clearSvgDimension();
    }
    _removeElemInArrayForm(_key, callback) {
        if (this[_key].length !== 0) {
            this[_key].forEach(element => callback(element));
            this[_key] = [];
        }
    }
    // ================================= Axis Label ==================================
    _setXAxisLabel(_xScaleType, _longestText) {
        if (!this.config.xAxis.enabled || !this.config.xAxis.labels.enabled)
            return;
        if (this.axisLabelContainerArr.length !== 0) {
            this._removeElemInArrayForm('axisLabelContainerArr', (container) => container.selectAll('*').remove());
        }
        let xSpacing = this._calculateXSpacing(_xScaleType);
        this._chartSvc.setAxisLabelDummy(this.config.id, xSpacing, _longestText);
        this._chartSvc._setAxisLabelLength();
        this._setAxisLabelContainer();
        if (this._chartSvc.labelLength !== 0)
            this._trimX(_xScaleType);
        this.axisLabelContainerArr.forEach((_axisLabelContainer, index) => {
            this._chartSvc.setAxisLabelContainerStyle(_axisLabelContainer);
            // if drawing 2nd axis, set to complement of opposite of 1st axis
            if (this._chartSvc.labelLength !== 0) {
                let opposite = index === 1 ? !this.config.xAxis.opposite : this.config.xAxis.opposite;
                this._drawAxisLabel(_axisLabelContainer, { labelHeight: this._chartSvc.labelLength, labelWidth: xSpacing }, { isRotate: this._chartSvc.isRotate, opposite: opposite });
            }
        });
    }
    _setAxisLabelContainer() {
        this.axisLabelContainerArr.push(this._chartSvc.setAxisLabelContainer());
        // render 2nd axis
        if (this._chartSvc.isNegativeStack) {
            this.axisLabelContainerArr.push(this._chartSvc.setAxisLabelContainer('.kdx-charts-double-axis-x'));
        }
    }
    _calculateXSpacing(_xScaleType) {
        return (_xScaleType === 'band') ? this.x.bandwidth() + this.x.paddingInner() * this.x.step() : this.width / (this.data.length - 1);
    }
    _trimX(_xScaleType) {
        let maxNoOfX = this._calculateMaxNoOfX(this._chartSvc.isRotate, _xScaleType);
        if (maxNoOfX === this.initData.length)
            return;
        // if the inital data cannot fit into maxSpace, slice and save to this.data
        this.data = this.initData.slice(0, maxNoOfX);
        let xInfo = this._chartSvc.getXInfo(this.data, this.config);
        // update domain with the updated this.data
        if (this.chartCategory === 'line')
            this._setLineScaleX(_xScaleType);
        this.x.domain(xInfo.value);
        // after trimming, the longest axis label may not be same. hence recalculate the axis label container height
        this._chartSvc.setAxisLabelDummyText(xInfo.longestText);
        this._chartSvc._setAxisLabelLength();
    }
    // this.data will be changed/trimed according to space given
    _calculateMaxNoOfX(_isRotate, _xScaleType) {
        if (!_isRotate && !this.bar.isInvert)
            return this.initData.length;
        let offset = this.chartCategory === 'bar' ? (this.x.paddingOuter()) * 2 : 0;
        let maxSpace = (this.bar.isInvert ? this.height : this.width) - offset;
        // note: when rotating or when chartType == 'bar', axisLAbelDummy will not text-wrap
        let eachItemSize = this._chartSvc.getAxisLabelDummyRect().height;
        let maxNoOfX = Math.floor(maxSpace / eachItemSize);
        if (_xScaleType === 'string')
            maxNoOfX += 1;
        return Math.min(this.initData.length, maxNoOfX);
    }
    _drawAxisLabel(_container, _labelDimenstion, _booleanChecks) {
        let firstTick = 0, xAxisLabelConfig = this.config.xAxis.labels;
        if (this.chartCategory === 'bar')
            firstTick = this.x.paddingOuter() * this.x.step() + this.x.bandwidth() / 2;
        this.data.forEach((d, xIndex) => {
            let labelContainer, tickPos;
            labelContainer = _container.append('div')
                .attr('class', 'kdx-charts-axis-label x-' + xIndex)
                .html(this._chartSvc.getLabelFormatReplace(xAxisLabelConfig.format, d.x.label));
            if (_booleanChecks.isRotate) {
                labelContainer.style('max-width', _labelDimenstion.labelHeight + 'px');
            }
            else {
                if (!this.bar.isInvert)
                    labelContainer.style('max-width', _labelDimenstion.labelWidth + 'px');
            }
            if (this.chartCategory === 'bar') {
                let orderFromLeft = this._chartSvc.isXReversed ? this.data.length - xIndex - 1 : xIndex;
                tickPos = firstTick + this.x.step() * orderFromLeft;
            }
            else {
                tickPos = this.rangeList[this.data[xIndex].x.value];
            }
            this._chartSvc.setAxisLabelPosition(labelContainer, tickPos, Object.assign(_booleanChecks, { isLast: xIndex === this.data.length - 1 }));
        });
    }
    // ================================= Capture Hover Event ==================================
    /**
     * _params can be ID3DataData or can contain callbacks
     * {
     *     ...
     *     callbacks: {
     *         'mouseover': Function,
     *         'mouseout': Function
     *     }
     * }
     */
    _initMouseEvents(_path, _params) {
        let mapCondition = (this.chartType[0] === 'map' && (this.chartType[1] === 'full' || this.chartType[1] === 'filter'));
        if (!this.config.tooltip.enabled)
            return;
        let tooltip;
        _path.on('mouseover', (d, index) => {
            let top = mapCondition ? parseInt(_params.fullGraph.node().style.top) + d3.event.layerY : d3.event.layerY;
            let left = mapCondition ? parseInt(_params.fullGraph.node().style.left) + d3.event.layerX : d3.event.layerX;
            let graphPointer = (mapCondition && _params.tooltipLayer) ? _params.tooltipLayer : this.svgParent;
            tooltip = graphPointer.select('.kdx-charts-tooltip');
            // if tooltip already exist (in case mouseout did not happen), don't append anymore.
            if (tooltip.empty()) {
                tooltip = graphPointer.append('div').attr('class', 'kdx-charts-tooltip');
                tooltip.append('div').attr('class', 'kdx-charts-tooltip-label');
                tooltip.append('div').attr('class', 'kdx-charts-tooltip-count');
            }
            let label;
            let count;
            // let config: IChartConfig = this._chartSvc.config;
            let value;
            if (this.chartType && (this.chartType[0] === 'pie' || this.chartType[0] === 'donut')) {
                label = d.data.x.replace(/¬/g, ' ');
                count = d.data.y;
                _params.pathAnim(d3.select(_path._groups[0][index]), true, _params.innerRadius, _params.outerRadius);
                d3.select(_path._groups[0][index]).style('opacity', '0.7');
            }
            else if (this.chartType && this.chartType[0] === 'radial') {
                label = d.x.replace(/¬/g, ' ');
                count = d.y;
                d3.select(_path._groups[0][index]).style('opacity', '0.7');
            }
            else if (this.chartCategory === 'bar') {
                label = _params.data.x.label;
                count = this._chartSvc.checkAndReturnLabelsPositive(d.value || 0);
                label = label.toString() + ' ' + this.legendData[d.id].name;
                d3.select(_path._groups[0][index]).style('opacity', '0.7');
            }
            else if (this.chartCategory === 'line') {
                label = _params.data.x.label;
                count = _params.data.y[index].value;
                label = label.toString() + ' ' + this.legendData[d].name;
            }
            else if (this.chartCategory === 'map') {
                for (let i = 0; i < _params.seriesData.length; i++) {
                    if (d.properties.ID_ == _params.seriesData[i].id) {
                        label = _params.seriesData[i].name;
                        count = _params.seriesName + ': ' + _params.seriesData[i].value;
                        value = _params.seriesData[i].value;
                        break;
                    }
                }
            }
            count = this._chartSvc.getLabelText(this.config.tooltip.format, count);
            tooltip.select('.kdx-charts-tooltip-label').html(label.toUpperCase());
            if (this.chartType[1] !== 'filter')
                tooltip.select('.kdx-charts-tooltip-count').html(count).style('font-weight', 'bold');
            tooltip.attr('style', this._chartSvc.getStyle(Object.assign({}, TOOLTIP_DEFAULT_STYLE), true));
            tooltip.style('display', 'block');
            tooltip.style('opacity', 2);
            tooltip.style('z-index', 403);
            if (this.chartCategory === 'line') {
                _params.dotHover(this.getDotId(_params.xIndex, d), true);
            }
            if (_params && _params.callbacks && _params.callbacks.mouseover)
                _params.callbacks.mouseover(value);
            // in case mousemove did not trigger, position tooltip once tooltip is created
            if (this.chartCategory !== 'map') {
                this._chartSvc.tooltipSvc.positionTooltip(tooltip, { top: d3.event.layerY, left: d3.event.layerX });
            }
            else {
                if (value || value === 0)
                    this._chartSvc.tooltipSvc.positionTooltip(tooltip, { top: top, left: left });
                else
                    tooltip.remove();
            }
        });
        _path.on('mousemove', (d) => {
            let top = mapCondition ? parseInt(_params.fullGraph.node().style.top) + d3.event.layerY : d3.event.layerY;
            let left = mapCondition ? parseInt(_params.fullGraph.node().style.left) + d3.event.layerX : d3.event.layerX;
            // position the tooltip to the cursor
            this._chartSvc.tooltipSvc.positionTooltip(tooltip, { top: top, left: left });
        });
        _path.on('mouseout', (d, index) => {
            if (this.chartType && (this.chartType[0] === 'pie' || this.chartType[0] === 'donut' || this.chartType[0] === 'radial' || this.chartCategory === 'bar')) {
                if (this.chartType[0] === 'pie' || this.chartType[0] === 'donut') {
                    let thisPath = d3.select(_path._groups[0][index]);
                    if (!thisPath.classed('clicked')) {
                        _params.pathAnim(thisPath, false, _params.innerRadius, _params.outerRadius);
                    }
                }
                d3.select(_path._groups[0][index]).style('opacity', '1');
            }
            // tooltip.style('display', 'none');
            // tooltip.style('opacity', 0);
            tooltip.remove();
            if (this.chartCategory === 'line') {
                _params.dotHover(this.getDotId(_params.xIndex, d));
            }
            if (_params && _params.callbacks && _params.callbacks.mouseout)
                _params.callbacks.mouseout();
        });
        _path.on('click', (d, index) => {
            if (this.chartType && (this.chartType[0] === 'pie' || this.chartType[0] === 'donut')) {
                let thisPath = d3.select(_path._groups[0][index]);
                let clicked = thisPath.classed('clicked');
                _params.pathAnim(thisPath, !clicked, _params.innerRadius, _params.outerRadius);
                thisPath.classed('clicked', !clicked);
            }
        });
    }
    // ================================= LABEL ==================================
    setLabel(_yData, _xData, _xPosition, _yPosition) {
        if (!this.config.chart.labels.enabled)
            return;
        let labelConfig = this.config.chart.labels;
        let labelContainer = this.dataLabelContainer.append('div')
            .attr('class', 'kdx-charts-data-label x-' + _xData + ' y-' + _yData.id);
        let labelText = this._chartSvc.getLabelText(labelConfig.format, _yData.value);
        labelContainer
            .append('div')
            .attr('class', 'kdx-charts-data-label-text')
            .html(labelText)
            .attr('style', this._chartSvc.getStyle(labelConfig.style));
        this._setLabelPosition(labelContainer, _yData.sum || _yData.value, _xPosition, _yPosition);
        return labelContainer;
    }
    transformPosition(x, y, isAttribute) {
        return 'translate(' + x + ((isAttribute) ? ',' : 'px,') + y + ((isAttribute) ? ')' : 'px)');
    }
    getDotId(xData, yId) {
        return 'kdx-charts-point-dot x-' + xData + ' y-' + yId;
    }
    isDataExist(_item, _yIndex) {
        return this._chartSvc.isExist(_item.y[_yIndex]);
    }
    _setLabelContainer() {
        this.dataLabelContainer = d3.select('#' + this.config.id + '.kdx-charts ' + '.kdx-charts-data-label-container');
    }
    /**
     * _params for bar: { valueSign: -1 or 0 or 1, dimensions: width, height, xPos, yPos}
     * _params for line: { dotSize: number, labelLength: number}
     */
    // affects all charts except pie, map, horizontal bar (which uses flex for vertical align, refer to kd-bar-chart)
    setLabelTextPosition(labelText, _yPosition, _params = {}) {
        let store = LABEL_TEXT_VERTICAL_ALIGN_STORE;
        let verticalAlign = this._chartSvc.getDefaultVerticalAlign(this.config, _params);
        let dotSize = _params.dotSize ? _params.dotSize : 0;
        let offset = dotSize / 2;
        if (verticalAlign === 'middle') {
            let checks = ['top', 'bottom'];
            checks.forEach(key => {
                if (this._chartSvc._checkBoundary(store[key].check, _yPosition, this.height, dotSize)) {
                    verticalAlign = store[key].changeTo;
                }
            });
        }
        else if (this._chartSvc._checkBoundary(store[verticalAlign].check, _yPosition, this.height, dotSize)) {
            verticalAlign = store[verticalAlign].changeTo;
        }
        let yPos = '';
        if (verticalAlign === 'middle') {
            yPos = store[verticalAlign].percent;
        }
        else {
            let sign = verticalAlign === 'top' ? ' - ' : ' + ';
            if (this.chartCategory === 'bar' && this._chartSvc.needOffsetForColumn(verticalAlign, _params))
                offset += _params.dimensions.height;
            yPos = 'calc(' + store[verticalAlign].percent + sign + offset.toString() + 'px)';
        }
        let xPos = (_params.labelLength && _params.labelLength > 1) ? 'calc(-50% + ' + dotSize / 2 + 'px)' : '0%';
        let translate = this.chartCategory === 'line' ? this.transformPosition(xPos, yPos, true) : 'translateY(' + yPos + ')';
        labelText.style('transform', translate);
    }
    _setLabelPosition(labelContainer, _yValue, _xPosition, _yPosition) {
        let defaultPosition = {
            x: ((this.bar.isInvert) ? this.height : 0),
            y: ((this.bar.isInvert) ? this.width : 0)
        };
        let x = (typeof _xPosition === 'number') ? _xPosition : defaultPosition.x;
        let y = (typeof _yPosition === 'number') ? _yPosition : defaultPosition.y;
        // if (_yPosition < this.dataLabelPushDownRange) {
        //     y = 5;
        // }
        if (this.isRtl)
            x = (this.width * -1) + x;
        if (_yValue && (_yValue > this.domainMax || _yValue < this.domainMin)) {
            labelContainer.style('display', 'none');
        }
        this._applyLabelPosition(labelContainer, x, y);
    }
    _applyLabelPosition(labelContainer, _xPosition, _yPosition) {
        let rotate = '';
        let labelStyle = this.config.chart.labels.style;
        // this.config.chart.labels.rotation cannot be '' or null or other non-value
        if (labelStyle.hasOwnProperty('rotation') && labelStyle.rotation) {
            rotate = ' rotate(' + labelStyle.rotation + 'deg)';
        }
        labelContainer
            .style('transform', this.transformPosition(_xPosition, _yPosition) + rotate);
        if (this.isRtl)
            labelContainer.style('text-align', 'right');
    }
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoia2QtYW5ndWxhci1jaGFydC1iYXNlLWNsYXNzLmpzIiwic291cmNlUm9vdCI6IkM6L3hhbXBwL2h0ZG9jcy9TdHlsZWd1aWRlL2lvc3RnLW9wZW5lbWlzLXN0eWxlZ3VpZGUvcHJvamVjdHMvb3BlbmVtaXMtc3R5bGVndWlkZS1saWIvc3JjLyIsInNvdXJjZXMiOlsia2QtY29tcG9uZW50cy9rZC1hbmd1bGFyLWNoYXJ0cy9rZC1hbmd1bGFyLWNoYXJ0LWJhc2UtY2xhc3MudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsT0FBTyxLQUFLLEVBQUUsTUFBTSxJQUFJLENBQUM7QUFtQnpCLE9BQU8sRUFBRSwrQkFBK0IsRUFBRSxxQkFBcUIsRUFBRSxNQUFNLDRCQUE0QixDQUFDO0FBR3BHLE1BQU0sT0FBTyxnQkFBZ0I7SUFnRXpCLFlBQW1CLFNBQXNCLEVBQVMsT0FBcUI7UUFBcEQsY0FBUyxHQUFULFNBQVMsQ0FBYTtRQUFTLFlBQU8sR0FBUCxPQUFPLENBQWM7UUE5RHZFLGdCQUFnQjtRQUNULFVBQUssR0FBWSxLQUFLLENBQUM7UUFDdkIsV0FBTSxHQUFpQixFQUFFLENBQUM7UUFDMUIsU0FBSSxHQUF1QixFQUFFLENBQUM7UUFDOUIsYUFBUSxHQUF1QixFQUFFLENBQUM7UUFvQmxDLGFBQVEsR0FBZSxFQUFFLENBQUM7UUFNMUIsWUFBTyxHQUFXLENBQUMsQ0FBQztRQUtwQiwwQkFBcUIsR0FBZSxFQUFFLENBQUM7UUFFdkMsaUJBQVksR0FBWSxLQUFLLENBQUM7UUFDckM7Ozs7O1dBS0c7UUFDSSxRQUFHLEdBQThFO1lBQ3BGLFFBQVEsRUFBRSxLQUFLO1lBQ2YscUJBQXFCLEVBQUUsR0FBRztZQUMxQixXQUFXLEVBQUUsR0FBRztTQUNuQixDQUFDO1FBR0ssdUJBQWtCLEdBQVcsSUFBSSxDQUFDO1FBT2xDLGFBQVEsR0FBVyw4Q0FBOEMsQ0FBQztRQUtyRSxJQUFJLENBQUMsS0FBSyxHQUFHLE9BQU8sQ0FBQyxvQkFBb0IsQ0FBQyxJQUFJLENBQUMsS0FBSyxPQUFPLENBQUM7SUFDaEUsQ0FBQztJQUVELDZFQUE2RTtJQUV0RSxNQUFNO1FBQ1QsSUFBSSxDQUFDLEdBQUcsR0FBRyxFQUFFLENBQUMsTUFBTSxDQUFDLEdBQUcsR0FBRyxJQUFJLENBQUMsTUFBTSxDQUFDLEVBQUUsR0FBRyxpQkFBaUIsQ0FBQyxDQUFDO1FBQy9ELElBQUksQ0FBQyxJQUFJLENBQUMsS0FBSztZQUFFLElBQUksQ0FBQyxLQUFLLEdBQUcsSUFBSSxDQUFDLEdBQUcsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDLE9BQU8sRUFBRSxPQUFPLENBQUMsQ0FBQztRQUMxRSxtR0FBbUc7UUFDbkcsSUFBSSxDQUFDLFNBQVMsR0FBRyxFQUFFLENBQUMsTUFBTSxDQUFDLEdBQUcsR0FBRyxJQUFJLENBQUMsTUFBTSxDQUFDLEVBQUUsR0FBRyxrQ0FBa0MsQ0FBQyxDQUFDO1FBQ3RGLElBQUksQ0FBQyxZQUFZLEdBQUcsRUFBRSxDQUFDLE1BQU0sQ0FBQyxHQUFHLEdBQUcsSUFBSSxDQUFDLE1BQU0sQ0FBQyxFQUFFLEdBQUcsdUNBQXVDLENBQUMsQ0FBQztRQUU5RixJQUFJLENBQUMsa0JBQWtCLEVBQUUsQ0FBQztRQUMxQixJQUFJLENBQUMsWUFBWSxFQUFFLENBQUM7UUFDcEIsSUFBSSxDQUFDLFNBQVMsR0FBRyxFQUFFLENBQUM7SUFDeEIsQ0FBQztJQUVEOzs7O09BSUc7SUFDSSxlQUFlLENBQUMsS0FBZ0I7UUFDbkMsSUFBSSxnQkFBZ0IsR0FBUSxJQUFJLENBQUMsWUFBWSxDQUFDLElBQUksRUFBRSxDQUFDLHFCQUFxQixFQUFFLENBQUM7UUFDN0UsSUFBSSxJQUFJLEdBQXVCLEtBQUssS0FBSyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUM7UUFFbkksSUFBSSxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsSUFBSSxFQUFFLGdCQUFnQixDQUFDLElBQUksQ0FBQyxDQUFDLENBQUM7SUFDaEQsQ0FBQztJQUVPLGtCQUFrQjtRQUN0QixJQUFJLENBQUMsSUFBSSxDQUFDLEdBQUc7WUFBRSxPQUFPO1FBQ3RCLElBQUksQ0FBQyxHQUFHO2FBQ0gsSUFBSSxDQUFDLE9BQU8sRUFBRSxDQUFDLENBQUM7YUFDaEIsSUFBSSxDQUFDLFFBQVEsRUFBRSxDQUFDLENBQUMsQ0FBQztJQUMzQixDQUFDO0lBRUQ7Ozs7T0FJRztJQUNLLGtCQUFrQixDQUFDLEtBQWdCO1FBQ3ZDLElBQUksQ0FBQyxPQUFPLEdBQUcsSUFBSSxDQUFDLEdBQUcsQ0FBQyxJQUFJLEVBQUUsQ0FBQyxxQkFBcUIsRUFBRSxDQUFDO1FBQ3ZELElBQUksQ0FBQyxTQUFTLENBQUMsT0FBTyxHQUFHLElBQUksQ0FBQyxPQUFPLENBQUM7UUFFdEMsSUFBSSxJQUFJLEdBQXVCLEtBQUssS0FBSyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUM7UUFFbkksSUFBSSxLQUFLLEdBQVcsSUFBSSxDQUFDLFNBQVMsQ0FBQyxZQUFZLENBQUMsS0FBSyxFQUFFLEVBQUUsT0FBTyxFQUFFLElBQUksQ0FBQyxPQUFPLEVBQUUsT0FBTyxFQUFFLElBQUksQ0FBQyxPQUFPLEVBQUUsQ0FBQyxDQUFDO1FBRXpHLElBQUksQ0FBQyxJQUFJLENBQUMsR0FBRyxLQUFLLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQztJQUN2QyxDQUFDO0lBRUQ7O09BRUc7SUFDSyxZQUFZO1FBQ2hCLElBQUksQ0FBQyxTQUFTLENBQUMsTUFBTSxHQUFHLElBQUksQ0FBQyxNQUFNLENBQUM7UUFDcEMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxTQUFTLEdBQUcsSUFBSSxDQUFDLFNBQVMsQ0FBQztRQUMxQyxJQUFJLENBQUMsU0FBUyxDQUFDLGFBQWEsR0FBRyxJQUFJLENBQUMsYUFBYSxDQUFDO1FBQ2xELElBQUksQ0FBQyxTQUFTLENBQUMsYUFBYSxHQUFHLElBQUksQ0FBQyxTQUFTLENBQUMsSUFBSSxFQUFFLENBQUMscUJBQXFCLEVBQUUsQ0FBQztRQUM3RSxJQUFJLENBQUMsU0FBUyxDQUFDLEdBQUcsR0FBRyxJQUFJLENBQUMsR0FBRyxDQUFDO1FBQzlCLElBQUksQ0FBQyxTQUFTLENBQUMsS0FBSyxHQUFHLElBQUksQ0FBQyxLQUFLLENBQUM7UUFDbEMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxXQUFXLEdBQUcsSUFBSSxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsUUFBUSxDQUFDO1FBQ3hELElBQUksQ0FBQyxTQUFTLENBQUMsV0FBVyxHQUFHLElBQUksQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLFFBQVEsQ0FBQztJQUM1RCxDQUFDO0lBRU8sZUFBZTtRQUNuQixJQUFJLGFBQWEsR0FBa0IsSUFBSSxDQUFDLFlBQVksQ0FBQyxHQUFHLENBQUMsQ0FBQztRQUMxRCxJQUFJLENBQUMsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxXQUFXLEVBQUUsQ0FBQyxVQUFVLENBQUMsYUFBYSxDQUFDLENBQUM7SUFDeEQsQ0FBQztJQUVPLGFBQWE7UUFDakIsSUFBSSxRQUFRLEdBQWtCLElBQUksQ0FBQyxZQUFZLENBQUMsR0FBRyxDQUFDLENBQUM7UUFFckQsSUFBSSxDQUFDLENBQUMsR0FBRyxFQUFFLENBQUMsU0FBUyxFQUFFLENBQUMsS0FBSyxDQUFDLFFBQVEsQ0FBQyxDQUFDO1FBRXhDLElBQUksSUFBSSxDQUFDLGFBQWEsS0FBSyxLQUFLLEVBQUU7WUFDOUIsSUFBSSxDQUFDLENBQUMsQ0FBQyxZQUFZLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxXQUFXLENBQUMsQ0FBQyxZQUFZLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxXQUFXLEdBQUcsQ0FBQyxDQUFDLENBQUM7U0FDcEY7SUFDTCxDQUFDO0lBRU8sWUFBWSxDQUFDLEtBQWdCO1FBQ2pDLElBQUksUUFBa0IsQ0FBQztRQUN2QixJQUFJLFFBQVEsR0FBa0MsS0FBSyxLQUFLLEdBQUcsQ0FBQyxDQUFDLENBQUMsYUFBYSxDQUFDLENBQUMsQ0FBQyxhQUFhLENBQUM7UUFFNUYsSUFBSSxJQUFJLENBQUMsR0FBRyxDQUFDLFFBQVEsRUFBRTtZQUNuQixRQUFRLEdBQUcsS0FBSyxLQUFLLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxJQUFJLENBQUMsS0FBSyxDQUFDLENBQUM7U0FDakU7YUFBTTtZQUNILFFBQVEsR0FBRyxLQUFLLEtBQUssR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxJQUFJLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLE1BQU0sRUFBRSxDQUFDLENBQUMsQ0FBQztTQUNqRTtRQUVELE9BQU8sSUFBSSxDQUFDLFNBQVMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLE9BQU8sRUFBRSxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUM7SUFDcEUsQ0FBQztJQUVPLFNBQVMsQ0FBQyxNQUFnQjtRQUM5QixJQUFJLFVBQVUsR0FBVyxJQUFJLENBQUMsS0FBSyxDQUFDO1FBRXBDLElBQUksQ0FBQyxNQUFNLElBQUksSUFBSSxDQUFDLElBQUksQ0FBQyxNQUFNLElBQUksQ0FBQyxFQUFFO1lBQ2xDLElBQUksQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLEdBQUcsVUFBVSxDQUFDO1lBQy9CLE9BQU8sQ0FBQyxDQUFDLEVBQUUsVUFBVSxDQUFDLENBQUM7U0FDMUI7UUFFRCxJQUFJLFNBQVMsR0FBVyxDQUFDLENBQUM7UUFDMUIsSUFBSSxVQUFVLEdBQWtCLEVBQUUsQ0FBQztRQUNuQyxJQUFJLFNBQVMsR0FBVyxVQUFVLEdBQUcsSUFBSSxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUM7UUFFdEQsS0FBSyxJQUFJLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxHQUFHLElBQUksQ0FBQyxJQUFJLENBQUMsTUFBTSxFQUFFLENBQUMsRUFBRSxFQUFFO1lBRXZDLElBQUksTUFBTSxFQUFFO2dCQUNSLFNBQVMsR0FBRyxJQUFJLENBQUMsc0JBQXNCLENBQUMsU0FBUyxFQUFFLENBQUMsQ0FBQyxDQUFDO2FBQ3pEO2lCQUFNO2dCQUNILFNBQVMsR0FBRyxVQUFVLEdBQUcsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLE1BQU0sR0FBRyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUM7YUFDdkQ7WUFFRCxJQUFJLElBQUksQ0FBQyxTQUFTLENBQUMsV0FBVztnQkFBRSxTQUFTLEdBQUcsVUFBVSxHQUFHLFNBQVMsQ0FBQztZQUVuRSxVQUFVLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDO1lBQzNCLElBQUksQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLEdBQUcsU0FBUyxDQUFDO1NBQ3BEO1FBRUQsT0FBTyxVQUFVLENBQUM7SUFDdEIsQ0FBQztJQUVPLHNCQUFzQixDQUFDLFVBQWtCLEVBQUUsU0FBaUI7UUFDaEUsT0FBTyxDQUFDLFVBQVUsR0FBRyxDQUFDLENBQUMsR0FBRyxDQUFDLFVBQVUsR0FBRyxTQUFTLENBQUMsQ0FBQztJQUN2RCxDQUFDO0lBRU8sb0JBQW9CLENBQUMsS0FBZ0IsRUFBRSxXQUErQjtRQUMxRSxJQUFJLEtBQUssS0FBSyxHQUFHLEVBQUU7WUFDZixJQUFJLFdBQVcsS0FBSyxRQUFRO2dCQUFFLElBQUksQ0FBQyxhQUFhLEVBQUUsQ0FBQztZQUNuRCxJQUFJLElBQUksQ0FBQyxhQUFhLEtBQUssTUFBTTtnQkFBRSxJQUFJLENBQUMsY0FBYyxDQUFDLFdBQVcsQ0FBQyxDQUFDO1NBQ3ZFO2FBQU07WUFDSCxJQUFJLENBQUMsZUFBZSxFQUFFLENBQUM7U0FDMUI7SUFDTCxDQUFDO0lBRUQ7OztPQUdHO0lBQ0ssY0FBYyxDQUFDLFdBQThCO1FBQ2pELElBQUksV0FBVyxLQUFLLFFBQVEsRUFBRTtZQUMxQixJQUFJLENBQUMsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxZQUFZLEVBQUUsQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDO1NBQzNEO2FBQU07WUFDSCxJQUFJLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQyxDQUFDO1NBQ3hCO0lBQ0wsQ0FBQztJQUVELDhFQUE4RTtJQUV2RSxTQUFTLENBQUMsV0FBOEI7UUFFM0MsSUFBSSxDQUFDLFNBQVMsQ0FBQyxVQUFVLEdBQUcsV0FBVyxDQUFDO1FBRXhDLElBQUksQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLFlBQVksRUFBRSxRQUFRLENBQUMsQ0FBQztRQUV0Qyw2REFBNkQ7UUFDN0QsSUFBSSxDQUFDLFNBQVMsQ0FBQyx5QkFBeUIsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLEVBQUUsQ0FBQyxDQUFDO1FBRXpELDhLQUE4SztRQUM5SyxJQUFJLElBQUksQ0FBQyxRQUFRLElBQUksSUFBSSxDQUFDLElBQUksQ0FBQyxNQUFNLEtBQUssSUFBSSxDQUFDLFFBQVEsQ0FBQyxNQUFNLEVBQUU7WUFDNUQsSUFBSSxDQUFDLElBQUksR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUM7WUFDdEQsMEZBQTBGO1NBQzdGO1FBRUQsc0RBQXNEO1FBQ3RELElBQUksQ0FBQyxVQUFVLENBQUMsV0FBVyxDQUFDLENBQUM7UUFFN0IsSUFBSSxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsWUFBWSxFQUFFLFNBQVMsQ0FBQyxDQUFDO1FBRXZDLGlDQUFpQztRQUNqQyxJQUFJLENBQUMsYUFBYSxFQUFFLENBQUM7UUFFckIseUJBQXlCO1FBQ3pCLElBQUksQ0FBQyxPQUFPLEVBQUUsQ0FBQztRQUVmLHNEQUFzRDtRQUN0RCxJQUFJLENBQUMsU0FBUyxDQUFDLHVCQUF1QixDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQztRQUVuRCw0REFBNEQ7UUFDNUQsSUFBSSxJQUFJLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsT0FBTyxFQUFFO1lBQ2xDLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxLQUFLLENBQUMsT0FBTyxFQUFFLElBQUksQ0FBQyxLQUFLLEdBQUcsSUFBSSxDQUFDLENBQUM7WUFDMUQsSUFBSSxDQUFDLFNBQVMsQ0FBQyxtQkFBbUIsQ0FBQyxJQUFJLENBQUMsa0JBQWtCLEVBQUUsSUFBSSxDQUFDLHFCQUFxQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7U0FDOUY7UUFFRCwyQkFBMkI7UUFDM0IsSUFBSSxDQUFDLFNBQVMsQ0FBQywyQkFBMkIsRUFBRSxDQUFDO1FBRTdDLDBHQUEwRztRQUMxRyxJQUFJLENBQUMsWUFBWSxFQUFFLENBQUM7SUFDeEIsQ0FBQztJQUVPLFVBQVUsQ0FBQyxXQUE4QjtRQUM3QyxnREFBZ0Q7UUFDaEQsSUFBSSxlQUFlLEdBQWlCLElBQUksQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDO1FBQ3RELElBQUksTUFBTSxHQUFvQixJQUFJLENBQUMsU0FBUyxDQUFDLFlBQVksQ0FBQyxlQUFlLEVBQUUsSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDO1FBQzNGLElBQUksQ0FBQyxTQUFTLENBQUMsZUFBZSxDQUFDLE1BQU0sQ0FBQyxRQUFRLENBQUMsQ0FBQztRQUVoRCxJQUFJLENBQUMsaUJBQWlCLENBQUMsTUFBTSxDQUFDLFFBQVEsRUFBRSxNQUFNLENBQUMsUUFBUSxFQUFFLE1BQU0sQ0FBQyxRQUFRLENBQUMsQ0FBQztRQUUxRSxJQUFJLEtBQUssR0FBVyxJQUFJLENBQUMsU0FBUyxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsSUFBSSxFQUFFLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQztRQUNwRSxJQUFJLENBQUMsb0JBQW9CLENBQUMsR0FBRyxFQUFFLFdBQVcsQ0FBQyxDQUFDO1FBQzVDLElBQUksQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsQ0FBQztRQUMzQixJQUFJLENBQUMsY0FBYyxDQUFDLFdBQVcsRUFBRSxLQUFLLENBQUMsV0FBVyxDQUFDLENBQUM7UUFFcEQsSUFBSSxDQUFDLG9CQUFvQixDQUFDLEdBQUcsRUFBRSxXQUFXLENBQUMsQ0FBQztRQUU1QyxJQUFJLGVBQWUsR0FBd0IsSUFBSSxDQUFDLHlCQUF5QixDQUFDLE1BQU0sQ0FBQyxDQUFDO1FBRWxGLElBQUksZUFBZSxJQUFJLGVBQWUsQ0FBQyxVQUFVLEVBQUU7WUFDL0MsSUFBSSxDQUFDLG9CQUFvQixDQUFDLEdBQUcsRUFBRSxXQUFXLENBQUMsQ0FBQztZQUM1QyxJQUFJLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLENBQUM7WUFDM0IsSUFBSSxDQUFDLGNBQWMsQ0FBQyxXQUFXLEVBQUUsS0FBSyxDQUFDLFdBQVcsQ0FBQyxDQUFDO1lBRXBELElBQUksQ0FBQyxvQkFBb0IsQ0FBQyxHQUFHLEVBQUUsV0FBVyxDQUFDLENBQUM7U0FDL0M7UUFFRCxxREFBcUQ7UUFDckQsSUFBSSxDQUFDLFVBQVUsR0FBRyxJQUFJLENBQUMsU0FBUyxDQUFDLGFBQWEsQ0FBQyxJQUFJLENBQUMsT0FBTyxFQUFFLElBQUksQ0FBQyxPQUFPLEVBQUUsZUFBZSxDQUFDLFFBQVEsQ0FBQyxDQUFDO1FBRXJHLGVBQWU7UUFDZixJQUFJLENBQUMsU0FBUyxHQUFHLGVBQWUsQ0FBQyxjQUFjLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxRQUFRLENBQUM7UUFDakYsSUFBSSxDQUFDLFNBQVMsR0FBRyxlQUFlLENBQUMsY0FBYyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsUUFBUSxDQUFDO1FBQ2pGLElBQUksQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsSUFBSSxDQUFDLFNBQVMsRUFBRSxJQUFJLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQztJQUNwRCxDQUFDO0lBR08sb0JBQW9CLENBQUMsS0FBZ0IsRUFBRSxXQUE4QjtRQUN6RSxJQUFJLENBQUMsZUFBZSxDQUFDLEtBQUssQ0FBQyxDQUFDO1FBQzVCLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxLQUFLLENBQUMsQ0FBQztRQUMvQixJQUFJLENBQUMsb0JBQW9CLENBQUMsS0FBSyxFQUFFLFdBQVcsQ0FBQyxDQUFDO0lBQ2xELENBQUM7SUFFRDs7T0FFRztJQUNLLFlBQVk7UUFDaEIsSUFBSSxZQUFZLEdBQVEsSUFBSSxDQUFDLEdBQUcsQ0FBQyxTQUFTLENBQUMsNEJBQTRCLEdBQUcsSUFBSSxDQUFDLE1BQU0sQ0FBQyxFQUFFLEdBQUcsT0FBTyxDQUFDLENBQUM7UUFDcEcsSUFBSSxZQUFZLENBQUMsS0FBSyxFQUFFLEVBQUU7WUFDdEIsWUFBWSxHQUFHLElBQUksQ0FBQyxHQUFHLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxDQUFDLE1BQU0sQ0FBQyxVQUFVLENBQUMsQ0FBQyxJQUFJLENBQUMsSUFBSSxFQUFFLHNCQUFzQixHQUFHLElBQUksQ0FBQyxNQUFNLENBQUMsRUFBRSxDQUFDLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxDQUFDO1lBQzdILFlBQVk7aUJBQ1AsSUFBSSxDQUFDLEdBQUcsRUFBRSxDQUFDLENBQUM7aUJBQ1osSUFBSSxDQUFDLEdBQUcsRUFBRSxDQUFDLENBQUM7aUJBQ1osSUFBSSxDQUFDLE1BQU0sRUFBRSxNQUFNLENBQUMsQ0FBQztTQUM3QjtRQUNELFlBQVk7YUFDUCxJQUFJLENBQUMsT0FBTyxFQUFFLElBQUksQ0FBQyxLQUFLLENBQUM7YUFDekIsSUFBSSxDQUFDLFFBQVEsRUFBRSxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUM7SUFDckMsQ0FBQztJQUVPLGlCQUFpQixDQUFDLFNBQWlCLEVBQUUsU0FBaUIsRUFBRSxTQUFpQjtRQUM3RSxJQUFJLFdBQVcsR0FBaUIsSUFBSSxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUM7UUFDbEQsSUFBSSxDQUFDLE9BQU8sR0FBRyxJQUFJLENBQUMsU0FBUyxDQUFDLGlCQUFpQixDQUFDLFNBQVMsRUFBRSxTQUFTLEVBQUUsV0FBVyxDQUFDLGNBQWMsRUFBRSxJQUFJLENBQUMsQ0FBQztRQUN4RyxJQUFJLENBQUMsT0FBTyxHQUFHLElBQUksQ0FBQyxTQUFTLENBQUMsaUJBQWlCLENBQUMsU0FBUyxFQUFFLFNBQVMsRUFBRSxXQUFXLENBQUMsY0FBYyxFQUFFLE1BQU0sQ0FBQyxDQUFDO0lBQzlHLENBQUM7SUFFRDs7OztLQUlDO0lBQ08seUJBQXlCLENBQUMsU0FBMEI7UUFDeEQsSUFBSSxNQUFNLEdBQVcsSUFBSSxDQUFDLEdBQUcsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUM7UUFDbEUsSUFBSSxNQUFNLElBQUksQ0FBQztZQUFFLE9BQU8sRUFBRSxVQUFVLEVBQUUsS0FBSyxFQUFFLFFBQVEsRUFBRSxDQUFDLEVBQUUsQ0FBQztRQUUzRCxJQUFJLFVBQWtCLENBQUM7UUFDdkIsSUFBSSxtQkFBbUIsR0FBcUIsTUFBTSxDQUFDLE1BQU0sQ0FBQyxFQUFFLEVBQUUsSUFBSSxDQUFDLFNBQVMsQ0FBQyxlQUFlLENBQUMsQ0FBQztRQUU5RixJQUFJLElBQUksQ0FBQyxHQUFHLENBQUMsUUFBUSxFQUFFO1lBQ25CLDBHQUEwRztZQUMxRyxnSkFBZ0o7WUFDaEosVUFBVSxHQUFHLElBQUksQ0FBQyxHQUFHLENBQUMsbUJBQW1CLENBQUMsT0FBTyxFQUFFLG1CQUFtQixDQUFDLE9BQU8sQ0FBQyxDQUFDO1NBQ25GO2FBQU07WUFDSCxVQUFVLEdBQUcsSUFBSSxDQUFDLFNBQVMsQ0FBQyx1QkFBdUIsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLFFBQVEsQ0FBQyxDQUFDO1NBQ2hHO1FBRUQsSUFBSSxZQUFZLEdBQVcsU0FBUyxDQUFDLFFBQVEsQ0FBQztRQUM5QyxJQUFJLFFBQVEsR0FBVyxZQUFZLENBQUM7UUFDcEMsSUFBSSxTQUFTLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFDLElBQUksQ0FBQyxPQUFPLEdBQUcsUUFBUSxHQUFHLElBQUksQ0FBQyxPQUFPLENBQUMsR0FBRyxRQUFRLENBQUMsQ0FBQztRQUVoRixJQUFJLE1BQU0sR0FBRyxVQUFVLElBQUksU0FBUyxLQUFLLENBQUM7WUFBRSxPQUFPLEVBQUUsVUFBVSxFQUFFLEtBQUssRUFBRSxRQUFRLEVBQUUsQ0FBQyxFQUFFLENBQUM7UUFFdEYsSUFBSSxhQUFhLEdBQVcsSUFBSSxDQUFDLFNBQVMsQ0FBQyxlQUFlLENBQUMsSUFBSSxDQUFDLE9BQU8sRUFBRSxJQUFJLENBQUMsT0FBTyxDQUFDLENBQUMsUUFBUSxFQUFFLENBQUMsTUFBTSxDQUFDO1FBRXpHLE9BQU8sQ0FBQyxNQUFNLEdBQUcsU0FBUyxDQUFDLEdBQUcsVUFBVSxJQUFJLFNBQVMsR0FBRyxDQUFDLEVBQUU7WUFDdkQsUUFBUSxHQUFHLFFBQVEsR0FBRyxDQUFDLENBQUM7WUFDeEIsSUFBSSxDQUFDLGlCQUFpQixDQUFDLFNBQVMsQ0FBQyxRQUFRLEVBQUUsU0FBUyxDQUFDLFFBQVEsRUFBRSxRQUFRLENBQUMsQ0FBQztZQUV6RSwrR0FBK0c7WUFDL0csbUZBQW1GO1lBQ25GLElBQUksSUFBSSxDQUFDLEdBQUcsQ0FBQyxRQUFRLElBQUksSUFBSSxDQUFDLFNBQVMsQ0FBQyxlQUFlLENBQUMsSUFBSSxDQUFDLE9BQU8sRUFBRSxJQUFJLENBQUMsT0FBTyxDQUFDLENBQUMsUUFBUSxFQUFFLENBQUMsTUFBTSxHQUFHLGFBQWEsRUFBRTtnQkFDbkgsVUFBVSxHQUFHLElBQUksQ0FBQyxTQUFTLENBQUMsaUJBQWlCLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxlQUFlLENBQUMsSUFBSSxDQUFDLE9BQU8sRUFBRSxJQUFJLENBQUMsT0FBTyxDQUFDLEVBQUUsU0FBUyxDQUFDLENBQUM7YUFDeEg7WUFFRCxTQUFTLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFDLElBQUksQ0FBQyxPQUFPLEdBQUcsUUFBUSxHQUFHLElBQUksQ0FBQyxPQUFPLENBQUMsR0FBRyxRQUFRLENBQUMsQ0FBQztTQUMvRTtRQUVELDZGQUE2RjtRQUM3RixxSEFBcUg7UUFDckgsSUFBSSxZQUFZLEtBQUssUUFBUSxFQUFFO1lBQzNCLElBQUksQ0FBQyxTQUFTLENBQUMsZUFBZSxDQUFDLFFBQVEsQ0FBQyxDQUFDO1lBQ3pDLElBQUksa0JBQWtCLEdBQXFCLElBQUksQ0FBQyxTQUFTLENBQUMsMkJBQTJCLENBQUMsRUFBRSxPQUFPLEVBQUUsSUFBSSxDQUFDLE9BQU8sRUFBRSxPQUFPLEVBQUUsSUFBSSxDQUFDLE9BQU8sRUFBRSxDQUFDLENBQUM7WUFDeEksSUFBSSxrQkFBa0IsQ0FBQyxPQUFPLEtBQUssbUJBQW1CLENBQUMsT0FBTyxJQUFJLGtCQUFrQixDQUFDLE9BQU8sS0FBSyxtQkFBbUIsQ0FBQyxPQUFPLEVBQUU7Z0JBQzFILE9BQU8sRUFBRSxVQUFVLEVBQUUsSUFBSSxFQUFFLFFBQVEsRUFBRSxRQUFRLEVBQUUsQ0FBQzthQUNuRDtTQUNKO1FBRUQsT0FBTyxFQUFFLFVBQVUsRUFBRSxLQUFLLEVBQUUsUUFBUSxFQUFFLFFBQVEsRUFBRSxDQUFDO0lBQ3JELENBQUM7SUFFRCxrRkFBa0Y7SUFFMUUsYUFBYTtRQUNqQixJQUFJLENBQUMsSUFBSSxDQUFDLGtCQUFrQjtZQUFFLElBQUksQ0FBQyxrQkFBa0IsR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsQ0FBQyxJQUFJLENBQUMsT0FBTyxFQUFFLGdDQUFnQyxDQUFDLENBQUM7UUFDL0gsSUFBSSxDQUFDLFNBQVMsQ0FBQyxPQUFPLENBQUMsY0FBYyxHQUFHLEVBQUUsS0FBSyxFQUFFLElBQUksQ0FBQyxLQUFLLEVBQUUsTUFBTSxFQUFFLElBQUksQ0FBQyxNQUFNLEVBQUUsQ0FBQztRQUNuRixJQUFJLElBQUksQ0FBQyxTQUFTLENBQUMsT0FBTyxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsTUFBTSxFQUFFLE9BQU8sRUFBRSxVQUFVLENBQUM7WUFBRSxJQUFJLENBQUMsYUFBYSxFQUFFLENBQUM7UUFDNUYsSUFBSSxJQUFJLENBQUMsU0FBUyxDQUFDLE9BQU8sQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLE1BQU0sRUFBRSxPQUFPLEVBQUUsZUFBZSxDQUFDO1lBQUUsSUFBSSxDQUFDLGtCQUFrQixFQUFFLENBQUM7UUFDdEcsSUFBSSxJQUFJLENBQUMsU0FBUyxDQUFDLE9BQU8sQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLE1BQU0sRUFBRSxPQUFPLEVBQUUsVUFBVSxDQUFDO1lBQUUsSUFBSSxDQUFDLGFBQWEsRUFBRSxDQUFDO0lBQ2hHLENBQUM7SUFFTyxhQUFhO1FBQ2pCLHNGQUFzRjtRQUN0RixJQUFJLEtBQUssR0FBRyxJQUFJLENBQUMsU0FBUyxDQUFDLE9BQU8sQ0FBQyxjQUFjLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDO1FBQzFELHVGQUF1RjtRQUN2RixJQUFJLEtBQUssR0FBa0IsQ0FBQyxFQUFFLENBQUMsQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUM7UUFDNUUsdURBQXVEO1FBQ3ZELElBQUksQ0FBQyxTQUFTLENBQUMsT0FBTyxDQUFDLFlBQVksQ0FBQyxJQUFJLENBQUMsa0JBQWtCLEVBQUUsS0FBSyxFQUFFLE9BQU8sRUFBRSxVQUFVLEVBQUUsS0FBSyxDQUFDLENBQUM7SUFDcEcsQ0FBQztJQUVELHVCQUF1QjtJQUNmLGFBQWE7UUFDakIsSUFBSSxDQUFDLFNBQVMsQ0FBQyxPQUFPLENBQUMsWUFBWSxDQUFDLElBQUksQ0FBQyxrQkFBa0IsRUFBRSxJQUFJLENBQUMsVUFBVSxFQUFFLE9BQU8sRUFBRSxVQUFVLEVBQUUsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDO0lBQy9HLENBQUM7SUFFTyxrQkFBa0I7UUFDdEIsSUFBSSxXQUFXLEdBQWlCLElBQUksQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDO1FBQ2xELElBQUksV0FBVyxDQUFDLGlCQUFpQixJQUFJLFdBQVcsQ0FBQyxZQUFZLElBQUksQ0FBQyxXQUFXLENBQUMsaUJBQWlCO1lBQUUsT0FBTztRQUV4RyxJQUFJLFVBQVUsR0FBVyxJQUFJLENBQUMsU0FBUyxDQUFDLGlCQUFpQixDQUFDLElBQUksQ0FBQyxTQUFTLEVBQUUsV0FBVyxDQUFDLGlCQUFpQixFQUFFLEtBQUssRUFBRSxJQUFJLENBQUMsQ0FBQztRQUN0SCxJQUFJLFVBQVUsR0FBVyxJQUFJLENBQUMsU0FBUyxDQUFDLGlCQUFpQixDQUFDLElBQUksQ0FBQyxTQUFTLEVBQUUsV0FBVyxDQUFDLGlCQUFpQixFQUFFLEtBQUssRUFBRSxNQUFNLENBQUMsQ0FBQztRQUN4SCxJQUFJLGVBQWUsR0FBa0IsSUFBSSxDQUFDLFNBQVMsQ0FBQyxhQUFhLENBQUMsVUFBVSxFQUFFLFVBQVUsRUFBRSxXQUFXLENBQUMsaUJBQWlCLENBQUMsQ0FBQztRQUV6SCxJQUFJLENBQUMsU0FBUyxDQUFDLE9BQU8sQ0FBQyxZQUFZLENBQUMsSUFBSSxDQUFDLGtCQUFrQixFQUFFLGVBQWUsRUFBRSxPQUFPLEVBQUUsZUFBZSxFQUFFLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQztJQUNwSCxDQUFDO0lBRUQsNEVBQTRFO0lBRXJFLE9BQU87UUFDVixJQUFJLFlBQVksR0FBc0I7WUFDbEMsS0FBSyxFQUFFLFlBQVksR0FBRyxJQUFJLENBQUMsS0FBSyxHQUFHLEtBQUs7WUFDeEMsSUFBSSxFQUFFLGdCQUFnQjtZQUN0QixHQUFHLEVBQUUsZ0JBQWdCO1lBQ3JCLE1BQU0sRUFBRSxjQUFjLEdBQUcsSUFBSSxDQUFDLE1BQU0sR0FBRyxHQUFHO1NBQzdDLENBQUM7UUFFRixJQUFJLFdBQVcsR0FBaUIsSUFBSSxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUM7UUFDbEQsSUFBSSxXQUFXLEdBQWlCLElBQUksQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDO1FBQ2xELElBQUksTUFBTSxHQUFZLElBQUksQ0FBQyxHQUFHLENBQUMsUUFBUSxDQUFDO1FBQ3hDLElBQUksUUFBUSxHQUErQjtZQUN2QyxDQUFDLEVBQUUsTUFBTSxDQUFDLENBQUMsQ0FBQyxXQUFXLENBQUMsUUFBUSxLQUFLLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLFdBQVcsQ0FBQyxRQUFRO1lBQ3RFLENBQUMsRUFBRSxNQUFNLENBQUMsQ0FBQyxDQUFDLFdBQVcsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLFdBQVcsQ0FBQyxRQUFRLEtBQUssSUFBSSxDQUFDLEtBQUs7U0FDekUsQ0FBQztRQUVGLElBQUksS0FBSyxHQUFHLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxHQUFHLEVBQUUsUUFBUSxDQUFDLENBQUMsRUFBRSxNQUFNLENBQUMsQ0FBQztRQUMzRCxJQUFJLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQztRQUMxQixJQUFJLENBQUMsS0FBSyxHQUFHLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxHQUFHLEVBQUUsUUFBUSxDQUFDLENBQUMsRUFBRSxNQUFNLENBQUMsQ0FBQztRQUU1RCxLQUFLLENBQUMsSUFBSSxDQUFDLFdBQVcsRUFBRSxJQUFJLENBQUMsU0FBUyxDQUFDLG1CQUFtQixDQUFDLEdBQUcsRUFBRSxRQUFRLENBQUMsQ0FBQyxFQUFFLFlBQVksQ0FBQyxDQUFDLENBQUM7UUFDM0YsSUFBSSxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsV0FBVyxFQUFFLElBQUksQ0FBQyxTQUFTLENBQUMsbUJBQW1CLENBQUMsR0FBRyxFQUFFLFFBQVEsQ0FBQyxDQUFDLEVBQUUsWUFBWSxDQUFDLENBQUMsQ0FBQztRQUVoRyxJQUFJLENBQUMsU0FBUyxDQUFDLGtCQUFrQixDQUFDLEtBQUssRUFBRSxHQUFHLENBQUMsQ0FBQztRQUM5QyxJQUFJLENBQUMsU0FBUyxDQUFDLGtCQUFrQixDQUFDLElBQUksQ0FBQyxLQUFLLEVBQUUsR0FBRyxDQUFDLENBQUM7UUFFbkQsSUFBSSxJQUFJLENBQUMsU0FBUyxDQUFDLGVBQWUsRUFBRTtZQUNoQyxJQUFJLFdBQVcsR0FBRyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsR0FBRyxFQUFFLENBQUMsUUFBUSxDQUFDLENBQUMsRUFBRSxJQUFJLENBQUMsR0FBRyxDQUFDLFFBQVEsQ0FBQyxDQUFDO1lBQzdFLFdBQVcsQ0FBQyxJQUFJLENBQUMsV0FBVyxFQUFFLElBQUksQ0FBQyxTQUFTLENBQUMsbUJBQW1CLENBQUMsR0FBRyxFQUFFLENBQUMsUUFBUSxDQUFDLENBQUMsRUFBRSxZQUFZLENBQUMsQ0FBQyxDQUFDO1lBQ2xHLElBQUksQ0FBQyxTQUFTLENBQUMsa0JBQWtCLENBQUMsV0FBVyxFQUFFLEdBQUcsQ0FBQyxDQUFDO1lBQ3BELElBQUksQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxDQUFDO1NBQ25DO0lBQ0wsQ0FBQztJQUVPLGdCQUFnQixDQUFDLEtBQWdCLEVBQUUsU0FBa0IsRUFBRSxPQUFnQjtRQUMzRSxJQUFJLFFBQVEsR0FBRyxXQUFXLENBQUMsS0FBSyxFQUFFLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDO1FBQy9DLElBQUksU0FBUyxHQUFXLHVCQUF1QixHQUFHLEtBQUssQ0FBQztRQUV4RCxJQUFJLENBQUMsT0FBTyxJQUFJLEtBQUssS0FBSyxHQUFHLENBQUMsSUFBSSxDQUFDLENBQUMsT0FBTyxJQUFJLEtBQUssS0FBSyxHQUFHLENBQUMsRUFBRTtZQUMzRCxTQUFTLElBQUksMkJBQTJCLENBQUM7U0FDNUM7UUFFRCxJQUFJLFNBQVM7WUFBRSxTQUFTLElBQUksMkJBQTJCLENBQUM7UUFFeEQsSUFBSSxLQUFLLEtBQUssR0FBRyxFQUFFO1lBQ2YsUUFBUTtpQkFDSCxVQUFVLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQztpQkFDM0IsVUFBVSxDQUFDLENBQUMsQ0FBQyxFQUFFLEVBQUU7Z0JBQ2QsZ0hBQWdIO2dCQUNoSCxJQUFJLEtBQUssR0FBRyxJQUFJLENBQUMsU0FBUyxDQUFDLDRCQUE0QixDQUFDLENBQUMsQ0FBQyxDQUFDO2dCQUMzRCxPQUFPLElBQUksQ0FBQyxTQUFTLENBQUMsaUJBQWlCLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxLQUFLLEVBQUUsS0FBSyxDQUFDLENBQUM7WUFDdEUsQ0FBQyxDQUFDLENBQUM7U0FDVjtRQUVELElBQUksUUFBUSxHQUFHLElBQUksQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQyxPQUFPLEVBQUUsU0FBUyxDQUFDLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxDQUFDO1FBRTlFLE9BQU8sUUFBUSxDQUFDO1FBRWhCLFNBQVMsV0FBVyxDQUFDLEtBQWdCLEVBQUUsTUFBTTtZQUN6QyxJQUFJLE9BQU8sRUFBRTtnQkFDVCxJQUFJLEtBQUssS0FBSyxHQUFHLEVBQUU7b0JBQ2YsSUFBSSxTQUFTO3dCQUFFLE9BQU8sRUFBRSxDQUFDLFNBQVMsQ0FBQyxNQUFNLENBQUMsQ0FBQztvQkFDM0MsT0FBTyxFQUFFLENBQUMsUUFBUSxDQUFDLE1BQU0sQ0FBQyxDQUFDO2lCQUM5QjtnQkFDRCxJQUFJLEtBQUssS0FBSyxHQUFHLEVBQUU7b0JBQ2YsSUFBSSxTQUFTO3dCQUFFLE9BQU8sRUFBRSxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsQ0FBQztvQkFDekMsT0FBTyxFQUFFLENBQUMsVUFBVSxDQUFDLE1BQU0sQ0FBQyxDQUFDO2lCQUNoQzthQUNKO2lCQUFNO2dCQUNILElBQUksS0FBSyxLQUFLLEdBQUcsRUFBRTtvQkFDZixJQUFJLFNBQVM7d0JBQUUsT0FBTyxFQUFFLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxDQUFDO29CQUN6QyxPQUFPLEVBQUUsQ0FBQyxVQUFVLENBQUMsTUFBTSxDQUFDLENBQUM7aUJBQ2hDO2dCQUNELElBQUksS0FBSyxLQUFLLEdBQUcsRUFBRTtvQkFDZixJQUFJLFNBQVM7d0JBQUUsT0FBTyxFQUFFLENBQUMsU0FBUyxDQUFDLE1BQU0sQ0FBQyxDQUFDO29CQUMzQyxPQUFPLEVBQUUsQ0FBQyxRQUFRLENBQUMsTUFBTSxDQUFDLENBQUM7aUJBQzlCO2FBQ0o7UUFDTCxDQUFDO0lBRUwsQ0FBQztJQUVELG9GQUFvRjtJQUU3RSxZQUFZLENBQUMsU0FBbUI7UUFDbkMsb0ZBQW9GO1FBQ3BGLFlBQVksQ0FBQyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsQ0FBQztRQUNwQyxJQUFJLENBQUMsZ0JBQWdCLEdBQUcsVUFBVSxDQUFDLEdBQVMsRUFBRTtZQUMxQyxTQUFTLEVBQUUsQ0FBQztRQUNoQixDQUFDLENBQUMsQ0FBQztJQUNQLENBQUM7SUFHTSxXQUFXO1FBQ2QsWUFBWSxDQUFDLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDO1FBQ3BDLElBQUksQ0FBQyxzQkFBc0IsQ0FBQyxVQUFVLEVBQUUsQ0FBQyxJQUFJLEVBQUUsRUFBRSxDQUFDLElBQUksQ0FBQyxNQUFNLEVBQUUsQ0FBQyxDQUFDO1FBQ2pFLElBQUksSUFBSSxDQUFDLEtBQUs7WUFBRSxJQUFJLENBQUMsS0FBSyxDQUFDLE1BQU0sRUFBRSxDQUFDO1FBQ3BDLElBQUksSUFBSSxDQUFDLGtCQUFrQjtZQUFFLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxTQUFTLENBQUMsR0FBRyxDQUFDLENBQUMsTUFBTSxFQUFFLENBQUM7UUFDN0UsSUFBSSxDQUFDLHNCQUFzQixDQUFDLHVCQUF1QixFQUFFLENBQUMsU0FBUyxFQUFFLEVBQUUsQ0FBQyxTQUFTLENBQUMsU0FBUyxDQUFDLEdBQUcsQ0FBQyxDQUFDLE1BQU0sRUFBRSxDQUFDLENBQUM7UUFDdkcsSUFBSSxJQUFJLENBQUMsa0JBQWtCO1lBQUUsSUFBSSxDQUFDLGtCQUFrQixDQUFDLFNBQVMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxNQUFNLEVBQUUsQ0FBQztRQUM3RSxJQUFJLENBQUMsa0JBQWtCLEVBQUUsQ0FBQztJQUM5QixDQUFDO0lBRU8sc0JBQXNCLENBQUMsSUFBWSxFQUFFLFFBQWtCO1FBQzNELElBQUksSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDLE1BQU0sS0FBSyxDQUFDLEVBQUU7WUFDekIsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDLE9BQU8sQ0FBQyxPQUFPLENBQUMsRUFBRSxDQUFDLFFBQVEsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDO1lBQ2pELElBQUksQ0FBQyxJQUFJLENBQUMsR0FBRyxFQUFFLENBQUM7U0FDbkI7SUFDTCxDQUFDO0lBRUQsa0ZBQWtGO0lBRTFFLGNBQWMsQ0FBQyxXQUE4QixFQUFFLFlBQW9CO1FBQ3ZFLElBQUksQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxPQUFPLElBQUksQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsT0FBTztZQUFFLE9BQU87UUFFNUUsSUFBSSxJQUFJLENBQUMscUJBQXFCLENBQUMsTUFBTSxLQUFLLENBQUMsRUFBRTtZQUN6QyxJQUFJLENBQUMsc0JBQXNCLENBQUMsdUJBQXVCLEVBQUUsQ0FBQyxTQUFTLEVBQUUsRUFBRSxDQUFDLFNBQVMsQ0FBQyxTQUFTLENBQUMsR0FBRyxDQUFDLENBQUMsTUFBTSxFQUFFLENBQUMsQ0FBQztTQUMxRztRQUVELElBQUksUUFBUSxHQUFXLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxXQUFXLENBQUMsQ0FBQztRQUU1RCxJQUFJLENBQUMsU0FBUyxDQUFDLGlCQUFpQixDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsRUFBRSxFQUFFLFFBQVEsRUFBRSxZQUFZLENBQUMsQ0FBQztRQUN6RSxJQUFJLENBQUMsU0FBUyxDQUFDLG1CQUFtQixFQUFFLENBQUM7UUFFckMsSUFBSSxDQUFDLHNCQUFzQixFQUFFLENBQUM7UUFFOUIsSUFBSSxJQUFJLENBQUMsU0FBUyxDQUFDLFdBQVcsS0FBSyxDQUFDO1lBQUUsSUFBSSxDQUFDLE1BQU0sQ0FBQyxXQUFXLENBQUMsQ0FBQztRQUUvRCxJQUFJLENBQUMscUJBQXFCLENBQUMsT0FBTyxDQUFDLENBQUMsbUJBQW1CLEVBQUUsS0FBSyxFQUFFLEVBQUU7WUFDOUQsSUFBSSxDQUFDLFNBQVMsQ0FBQywwQkFBMEIsQ0FBQyxtQkFBbUIsQ0FBQyxDQUFDO1lBQy9ELGlFQUFpRTtZQUNqRSxJQUFJLElBQUksQ0FBQyxTQUFTLENBQUMsV0FBVyxLQUFLLENBQUMsRUFBRTtnQkFDbEMsSUFBSSxRQUFRLEdBQUcsS0FBSyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLFFBQVEsQ0FBQztnQkFDdEYsSUFBSSxDQUFDLGNBQWMsQ0FDZixtQkFBbUIsRUFDbkIsRUFBRSxXQUFXLEVBQUUsSUFBSSxDQUFDLFNBQVMsQ0FBQyxXQUFXLEVBQUUsVUFBVSxFQUFFLFFBQVEsRUFBRSxFQUNqRSxFQUFFLFFBQVEsRUFBRSxJQUFJLENBQUMsU0FBUyxDQUFDLFFBQVEsRUFBRSxRQUFRLEVBQUUsUUFBUSxFQUFFLENBQzVELENBQUM7YUFDTDtRQUNMLENBQUMsQ0FBQyxDQUFDO0lBQ1AsQ0FBQztJQUVPLHNCQUFzQjtRQUMxQixJQUFJLENBQUMscUJBQXFCLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMscUJBQXFCLEVBQUUsQ0FBQyxDQUFDO1FBRXhFLGtCQUFrQjtRQUNsQixJQUFJLElBQUksQ0FBQyxTQUFTLENBQUMsZUFBZSxFQUFFO1lBQ2hDLElBQUksQ0FBQyxxQkFBcUIsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxxQkFBcUIsQ0FBQywyQkFBMkIsQ0FBQyxDQUFDLENBQUM7U0FDdEc7SUFDTCxDQUFDO0lBRU8sa0JBQWtCLENBQUMsV0FBOEI7UUFDckQsT0FBTyxDQUFDLFdBQVcsS0FBSyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxTQUFTLEVBQUUsR0FBRyxJQUFJLENBQUMsQ0FBQyxDQUFDLFlBQVksRUFBRSxHQUFHLElBQUksQ0FBQyxDQUFDLENBQUMsSUFBSSxFQUFFLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxLQUFLLEdBQUcsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLE1BQU0sR0FBRyxDQUFDLENBQUMsQ0FBQztJQUN2SSxDQUFDO0lBRU8sTUFBTSxDQUFDLFdBQThCO1FBQ3pDLElBQUksUUFBUSxHQUFXLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLFFBQVEsRUFBRSxXQUFXLENBQUMsQ0FBQztRQUVyRixJQUFJLFFBQVEsS0FBSyxJQUFJLENBQUMsUUFBUSxDQUFDLE1BQU07WUFBRSxPQUFPO1FBRTlDLDJFQUEyRTtRQUMzRSxJQUFJLENBQUMsSUFBSSxHQUFHLElBQUksQ0FBQyxRQUFRLENBQUMsS0FBSyxDQUFDLENBQUMsRUFBRSxRQUFRLENBQUMsQ0FBQztRQUM3QyxJQUFJLEtBQUssR0FBVyxJQUFJLENBQUMsU0FBUyxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsSUFBSSxFQUFFLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQztRQUVwRSwyQ0FBMkM7UUFDM0MsSUFBSSxJQUFJLENBQUMsYUFBYSxLQUFLLE1BQU07WUFBRSxJQUFJLENBQUMsY0FBYyxDQUFDLFdBQVcsQ0FBQyxDQUFDO1FBQ3BFLElBQUksQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsQ0FBQztRQUUzQiw0R0FBNEc7UUFDNUcsSUFBSSxDQUFDLFNBQVMsQ0FBQyxxQkFBcUIsQ0FBQyxLQUFLLENBQUMsV0FBVyxDQUFDLENBQUM7UUFDeEQsSUFBSSxDQUFDLFNBQVMsQ0FBQyxtQkFBbUIsRUFBRSxDQUFDO0lBQ3pDLENBQUM7SUFFRCw0REFBNEQ7SUFDcEQsa0JBQWtCLENBQUMsU0FBa0IsRUFBRSxXQUE4QjtRQUN6RSxJQUFJLENBQUMsU0FBUyxJQUFJLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxRQUFRO1lBQUUsT0FBTyxJQUFJLENBQUMsUUFBUSxDQUFDLE1BQU0sQ0FBQztRQUVsRSxJQUFJLE1BQU0sR0FBVyxJQUFJLENBQUMsYUFBYSxLQUFLLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLFlBQVksRUFBRSxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7UUFDcEYsSUFBSSxRQUFRLEdBQVcsQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxHQUFHLE1BQU0sQ0FBQztRQUMvRSxvRkFBb0Y7UUFDcEYsSUFBSSxZQUFZLEdBQVcsSUFBSSxDQUFDLFNBQVMsQ0FBQyxxQkFBcUIsRUFBRSxDQUFDLE1BQU0sQ0FBQztRQUN6RSxJQUFJLFFBQVEsR0FBVyxJQUFJLENBQUMsS0FBSyxDQUFDLFFBQVEsR0FBRyxZQUFZLENBQUMsQ0FBQztRQUUzRCxJQUFJLFdBQVcsS0FBSyxRQUFRO1lBQUUsUUFBUSxJQUFJLENBQUMsQ0FBQztRQUU1QyxPQUFPLElBQUksQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxNQUFNLEVBQUUsUUFBUSxDQUFDLENBQUM7SUFDcEQsQ0FBQztJQUVPLGNBQWMsQ0FBQyxVQUFlLEVBQUUsZ0JBQTZELEVBQUUsY0FBdUM7UUFDMUksSUFBSSxTQUFTLEdBQVcsQ0FBQyxFQUFFLGdCQUFnQixHQUFHLElBQUksQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQztRQUN2RSxJQUFJLElBQUksQ0FBQyxhQUFhLEtBQUssS0FBSztZQUFFLFNBQVMsR0FBRyxJQUFJLENBQUMsQ0FBQyxDQUFDLFlBQVksRUFBRSxHQUFHLElBQUksQ0FBQyxDQUFDLENBQUMsSUFBSSxFQUFFLEdBQUcsSUFBSSxDQUFDLENBQUMsQ0FBQyxTQUFTLEVBQUUsR0FBRyxDQUFDLENBQUM7UUFFN0csSUFBSSxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLEVBQUUsTUFBTSxFQUFFLEVBQUU7WUFDNUIsSUFBSSxjQUFtQixFQUFFLE9BQWUsQ0FBQztZQUN6QyxjQUFjLEdBQUcsVUFBVSxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUM7aUJBQ3BDLElBQUksQ0FBQyxPQUFPLEVBQUUsMEJBQTBCLEdBQUcsTUFBTSxDQUFDO2lCQUNsRCxJQUFJLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxxQkFBcUIsQ0FBQyxnQkFBZ0IsQ0FBQyxNQUFNLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDO1lBRXBGLElBQUksY0FBYyxDQUFDLFFBQVEsRUFBRTtnQkFDekIsY0FBYyxDQUFDLEtBQUssQ0FBQyxXQUFXLEVBQUUsZ0JBQWdCLENBQUMsV0FBVyxHQUFHLElBQUksQ0FBQyxDQUFDO2FBQzFFO2lCQUFNO2dCQUNILElBQUksQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLFFBQVE7b0JBQUUsY0FBYyxDQUFDLEtBQUssQ0FBQyxXQUFXLEVBQUUsZ0JBQWdCLENBQUMsVUFBVSxHQUFHLElBQUksQ0FBQyxDQUFDO2FBQ2pHO1lBRUQsSUFBSSxJQUFJLENBQUMsYUFBYSxLQUFLLEtBQUssRUFBRTtnQkFDOUIsSUFBSSxhQUFhLEdBQUcsSUFBSSxDQUFDLFNBQVMsQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsTUFBTSxHQUFHLE1BQU0sR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQztnQkFDeEYsT0FBTyxHQUFHLFNBQVMsR0FBRyxJQUFJLENBQUMsQ0FBQyxDQUFDLElBQUksRUFBRSxHQUFHLGFBQWEsQ0FBQzthQUN2RDtpQkFBTTtnQkFDSCxPQUFPLEdBQUcsSUFBSSxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQzthQUN2RDtZQUVELElBQUksQ0FBQyxTQUFTLENBQUMsb0JBQW9CLENBQUMsY0FBYyxFQUFFLE9BQU8sRUFBRSxNQUFNLENBQUMsTUFBTSxDQUFDLGNBQWMsRUFBRSxFQUFFLE1BQU0sRUFBRSxNQUFNLEtBQUssSUFBSSxDQUFDLElBQUksQ0FBQyxNQUFNLEdBQUcsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDO1FBQzdJLENBQUMsQ0FBQyxDQUFDO0lBQ1AsQ0FBQztJQUVELDJGQUEyRjtJQUUzRjs7Ozs7Ozs7O09BU0c7SUFFSSxnQkFBZ0IsQ0FBQyxLQUFVLEVBQUUsT0FBYTtRQUM5QyxJQUFJLFlBQVksR0FBWSxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLEtBQUssS0FBSyxJQUFJLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsS0FBSyxNQUFNLElBQUksSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsS0FBSyxRQUFRLENBQUMsQ0FBQyxDQUFDO1FBQzdILElBQUksQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLE9BQU8sQ0FBQyxPQUFPO1lBQUUsT0FBTztRQUV6QyxJQUFJLE9BQVksQ0FBQztRQUNqQixLQUFLLENBQUMsRUFBRSxDQUFDLFdBQVcsRUFBRSxDQUFDLENBQUMsRUFBRSxLQUFLLEVBQUUsRUFBRTtZQUMvQixJQUFJLEdBQUcsR0FBVyxZQUFZLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxPQUFPLENBQUMsU0FBUyxDQUFDLElBQUksRUFBRSxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsR0FBRyxFQUFFLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUM7WUFDbEgsSUFBSSxJQUFJLEdBQVcsWUFBWSxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsT0FBTyxDQUFDLFNBQVMsQ0FBQyxJQUFJLEVBQUUsQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLEdBQUcsRUFBRSxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDO1lBQ3BILElBQUksWUFBWSxHQUFRLENBQUMsWUFBWSxJQUFJLE9BQU8sQ0FBQyxZQUFZLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLFlBQVksQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQztZQUN2RyxPQUFPLEdBQUcsWUFBWSxDQUFDLE1BQU0sQ0FBQyxxQkFBcUIsQ0FBQyxDQUFDO1lBRXJELG9GQUFvRjtZQUNwRixJQUFJLE9BQU8sQ0FBQyxLQUFLLEVBQUUsRUFBRTtnQkFDakIsT0FBTyxHQUFHLFlBQVksQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLENBQUMsSUFBSSxDQUFDLE9BQU8sRUFBRSxvQkFBb0IsQ0FBQyxDQUFDO2dCQUN6RSxPQUFPLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxDQUFDLElBQUksQ0FBQyxPQUFPLEVBQUUsMEJBQTBCLENBQUMsQ0FBQztnQkFDaEUsT0FBTyxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsQ0FBQyxJQUFJLENBQUMsT0FBTyxFQUFFLDBCQUEwQixDQUFDLENBQUM7YUFDbkU7WUFFRCxJQUFJLEtBQWEsQ0FBQztZQUNsQixJQUFJLEtBQXNCLENBQUM7WUFDM0Isb0RBQW9EO1lBQ3BELElBQUksS0FBYSxDQUFDO1lBRWxCLElBQUksSUFBSSxDQUFDLFNBQVMsSUFBSSxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLEtBQUssS0FBSyxJQUFJLElBQUksQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLEtBQUssT0FBTyxDQUFDLEVBQUU7Z0JBQ2xGLEtBQUssR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsSUFBSSxFQUFFLEdBQUcsQ0FBQyxDQUFDO2dCQUNwQyxLQUFLLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUM7Z0JBQ2pCLE9BQU8sQ0FBQyxRQUFRLENBQUMsRUFBRSxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLEVBQUUsSUFBSSxFQUFFLE9BQU8sQ0FBQyxXQUFXLEVBQUUsT0FBTyxDQUFDLFdBQVcsQ0FBQyxDQUFDO2dCQUNyRyxFQUFFLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsU0FBUyxFQUFFLEtBQUssQ0FBQyxDQUFDO2FBQzlEO2lCQUFNLElBQUksSUFBSSxDQUFDLFNBQVMsSUFBSSxJQUFJLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxLQUFLLFFBQVEsRUFBRTtnQkFDekQsS0FBSyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLElBQUksRUFBRSxHQUFHLENBQUMsQ0FBQztnQkFDL0IsS0FBSyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUM7Z0JBQ1osRUFBRSxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLFNBQVMsRUFBRSxLQUFLLENBQUMsQ0FBQzthQUM5RDtpQkFBTSxJQUFJLElBQUksQ0FBQyxhQUFhLEtBQUssS0FBSyxFQUFFO2dCQUNyQyxLQUFLLEdBQUcsT0FBTyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDO2dCQUM3QixLQUFLLEdBQUcsSUFBSSxDQUFDLFNBQVMsQ0FBQyw0QkFBNEIsQ0FBQyxDQUFDLENBQUMsS0FBSyxJQUFJLENBQUMsQ0FBQyxDQUFDO2dCQUNsRSxLQUFLLEdBQUcsS0FBSyxDQUFDLFFBQVEsRUFBRSxHQUFHLEdBQUcsR0FBRyxJQUFJLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUM7Z0JBQzVELEVBQUUsQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxTQUFTLEVBQUUsS0FBSyxDQUFDLENBQUM7YUFDOUQ7aUJBQU0sSUFBSSxJQUFJLENBQUMsYUFBYSxLQUFLLE1BQU0sRUFBRTtnQkFDdEMsS0FBSyxHQUFHLE9BQU8sQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQztnQkFDN0IsS0FBSyxHQUFHLE9BQU8sQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLEtBQUssQ0FBQztnQkFDcEMsS0FBSyxHQUFHLEtBQUssQ0FBQyxRQUFRLEVBQUUsR0FBRyxHQUFHLEdBQUcsSUFBSSxDQUFDLFVBQVUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUM7YUFDNUQ7aUJBQU0sSUFBSSxJQUFJLENBQUMsYUFBYSxLQUFLLEtBQUssRUFBRTtnQkFDckMsS0FBSyxJQUFJLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxHQUFHLE9BQU8sQ0FBQyxVQUFVLENBQUMsTUFBTSxFQUFFLENBQUMsRUFBRSxFQUFFO29CQUNoRCxJQUFJLENBQUMsQ0FBQyxVQUFVLENBQUMsR0FBRyxJQUFJLE9BQU8sQ0FBQyxVQUFVLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxFQUFFO3dCQUM5QyxLQUFLLEdBQUcsT0FBTyxDQUFDLFVBQVUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUM7d0JBQ25DLEtBQUssR0FBRyxPQUFPLENBQUMsVUFBVSxHQUFHLElBQUksR0FBRyxPQUFPLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQzt3QkFDaEUsS0FBSyxHQUFHLE9BQU8sQ0FBQyxVQUFVLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDO3dCQUNwQyxNQUFNO3FCQUNUO2lCQUNKO2FBQ0o7WUFFRCxLQUFLLEdBQUcsSUFBSSxDQUFDLFNBQVMsQ0FBQyxZQUFZLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxPQUFPLENBQUMsTUFBTSxFQUFFLEtBQUssQ0FBQyxDQUFDO1lBQ3ZFLE9BQU8sQ0FBQyxNQUFNLENBQUMsMkJBQTJCLENBQUMsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLFdBQVcsRUFBRSxDQUFDLENBQUM7WUFDdEUsSUFBSSxJQUFJLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxLQUFLLFFBQVE7Z0JBQUUsT0FBTyxDQUFDLE1BQU0sQ0FBQywyQkFBMkIsQ0FBQyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQyxLQUFLLENBQUMsYUFBYSxFQUFFLE1BQU0sQ0FBQyxDQUFDO1lBRXpILE9BQU8sQ0FBQyxJQUFJLENBQUMsT0FBTyxFQUFFLElBQUksQ0FBQyxTQUFTLENBQUMsUUFBUSxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsRUFBRSxFQUFFLHFCQUFxQixDQUFDLEVBQUUsSUFBSSxDQUFDLENBQUMsQ0FBQztZQUMvRixPQUFPLENBQUMsS0FBSyxDQUFDLFNBQVMsRUFBRSxPQUFPLENBQUMsQ0FBQztZQUNsQyxPQUFPLENBQUMsS0FBSyxDQUFDLFNBQVMsRUFBRSxDQUFDLENBQUMsQ0FBQztZQUM1QixPQUFPLENBQUMsS0FBSyxDQUFDLFNBQVMsRUFBRSxHQUFHLENBQUMsQ0FBQztZQUU5QixJQUFJLElBQUksQ0FBQyxhQUFhLEtBQUssTUFBTSxFQUFFO2dCQUMvQixPQUFPLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsT0FBTyxDQUFDLE1BQU0sRUFBRSxDQUFDLENBQUMsRUFBRSxJQUFJLENBQUMsQ0FBQzthQUM1RDtZQUVELElBQUksT0FBTyxJQUFJLE9BQU8sQ0FBQyxTQUFTLElBQUksT0FBTyxDQUFDLFNBQVMsQ0FBQyxTQUFTO2dCQUFFLE9BQU8sQ0FBQyxTQUFTLENBQUMsU0FBUyxDQUFDLEtBQUssQ0FBQyxDQUFDO1lBRXBHLDhFQUE4RTtZQUM5RSxJQUFJLElBQUksQ0FBQyxhQUFhLEtBQUssS0FBSyxFQUFFO2dCQUM5QixJQUFJLENBQUMsU0FBUyxDQUFDLFVBQVUsQ0FBQyxlQUFlLENBQUMsT0FBTyxFQUFFLEVBQUUsR0FBRyxFQUFFLEVBQUUsQ0FBQyxLQUFLLENBQUMsTUFBTSxFQUFFLElBQUksRUFBRSxFQUFFLENBQUMsS0FBSyxDQUFDLE1BQU0sRUFBRSxDQUFDLENBQUM7YUFDdkc7aUJBQU07Z0JBQ0gsSUFBSSxLQUFLLElBQUksS0FBSyxLQUFLLENBQUM7b0JBQUUsSUFBSSxDQUFDLFNBQVMsQ0FBQyxVQUFVLENBQUMsZUFBZSxDQUFDLE9BQU8sRUFBRSxFQUFFLEdBQUcsRUFBRSxHQUFHLEVBQUUsSUFBSSxFQUFFLElBQUksRUFBRSxDQUFDLENBQUM7O29CQUNsRyxPQUFPLENBQUMsTUFBTSxFQUFFLENBQUM7YUFDekI7UUFDTCxDQUFDLENBQUMsQ0FBQztRQUVILEtBQUssQ0FBQyxFQUFFLENBQUMsV0FBVyxFQUFFLENBQUMsQ0FBQyxFQUFFLEVBQUU7WUFDeEIsSUFBSSxHQUFHLEdBQVcsWUFBWSxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsT0FBTyxDQUFDLFNBQVMsQ0FBQyxJQUFJLEVBQUUsQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLEdBQUcsRUFBRSxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDO1lBQ2xILElBQUksSUFBSSxHQUFXLFlBQVksQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLE9BQU8sQ0FBQyxTQUFTLENBQUMsSUFBSSxFQUFFLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxHQUFHLEVBQUUsQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQztZQUNwSCxxQ0FBcUM7WUFDckMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxVQUFVLENBQUMsZUFBZSxDQUFDLE9BQU8sRUFBRSxFQUFFLEdBQUcsRUFBRSxHQUFHLEVBQUUsSUFBSSxFQUFFLElBQUksRUFBRSxDQUFDLENBQUM7UUFDakYsQ0FBQyxDQUFDLENBQUM7UUFFSCxLQUFLLENBQUMsRUFBRSxDQUFDLFVBQVUsRUFBRSxDQUFDLENBQUMsRUFBRSxLQUFLLEVBQUUsRUFBRTtZQUM5QixJQUFJLElBQUksQ0FBQyxTQUFTLElBQUksQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxLQUFLLEtBQUssSUFBSSxJQUFJLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxLQUFLLE9BQU8sSUFBSSxJQUFJLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxLQUFLLFFBQVEsSUFBSSxJQUFJLENBQUMsYUFBYSxLQUFLLEtBQUssQ0FBQyxFQUFFO2dCQUNwSixJQUFJLElBQUksQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLEtBQUssS0FBSyxJQUFJLElBQUksQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLEtBQUssT0FBTyxFQUFFO29CQUM5RCxJQUFJLFFBQVEsR0FBUSxFQUFFLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQztvQkFDdkQsSUFBSSxDQUFDLFFBQVEsQ0FBQyxPQUFPLENBQUMsU0FBUyxDQUFDLEVBQUU7d0JBQzlCLE9BQU8sQ0FBQyxRQUFRLENBQUMsUUFBUSxFQUFFLEtBQUssRUFBRSxPQUFPLENBQUMsV0FBVyxFQUFFLE9BQU8sQ0FBQyxXQUFXLENBQUMsQ0FBQztxQkFDL0U7aUJBQ0o7Z0JBQ0QsRUFBRSxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLFNBQVMsRUFBRSxHQUFHLENBQUMsQ0FBQzthQUM1RDtZQUNELG9DQUFvQztZQUNwQywrQkFBK0I7WUFDL0IsT0FBTyxDQUFDLE1BQU0sRUFBRSxDQUFDO1lBRWpCLElBQUksSUFBSSxDQUFDLGFBQWEsS0FBSyxNQUFNLEVBQUU7Z0JBQy9CLE9BQU8sQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxPQUFPLENBQUMsTUFBTSxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUM7YUFDdEQ7WUFDRCxJQUFJLE9BQU8sSUFBSSxPQUFPLENBQUMsU0FBUyxJQUFJLE9BQU8sQ0FBQyxTQUFTLENBQUMsUUFBUTtnQkFBRSxPQUFPLENBQUMsU0FBUyxDQUFDLFFBQVEsRUFBRSxDQUFDO1FBQ2pHLENBQUMsQ0FBQyxDQUFDO1FBRUgsS0FBSyxDQUFDLEVBQUUsQ0FBQyxPQUFPLEVBQUUsQ0FBQyxDQUFDLEVBQUUsS0FBSyxFQUFFLEVBQUU7WUFDM0IsSUFBSSxJQUFJLENBQUMsU0FBUyxJQUFJLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsS0FBSyxLQUFLLElBQUksSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsS0FBSyxPQUFPLENBQUMsRUFBRTtnQkFDbEYsSUFBSSxRQUFRLEdBQVEsRUFBRSxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUM7Z0JBQ3ZELElBQUksT0FBTyxHQUFZLFFBQVEsQ0FBQyxPQUFPLENBQUMsU0FBUyxDQUFDLENBQUM7Z0JBQ25ELE9BQU8sQ0FBQyxRQUFRLENBQUMsUUFBUSxFQUFFLENBQUMsT0FBTyxFQUFFLE9BQU8sQ0FBQyxXQUFXLEVBQUUsT0FBTyxDQUFDLFdBQVcsQ0FBQyxDQUFDO2dCQUMvRSxRQUFRLENBQUMsT0FBTyxDQUFDLFNBQVMsRUFBRSxDQUFDLE9BQU8sQ0FBQyxDQUFDO2FBQ3pDO1FBQ0wsQ0FBQyxDQUFDLENBQUM7SUFDUCxDQUFDO0lBRUQsNkVBQTZFO0lBRXRFLFFBQVEsQ0FBQyxNQUFnQixFQUFFLE1BQXVCLEVBQUUsVUFBa0IsRUFBRSxVQUFrQjtRQUM3RixJQUFJLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLE9BQU87WUFBRSxPQUFPO1FBRTlDLElBQUksV0FBVyxHQUFlLElBQUksQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQztRQUV2RCxJQUFJLGNBQWMsR0FBUSxJQUFJLENBQUMsa0JBQWtCLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQzthQUMxRCxJQUFJLENBQUMsT0FBTyxFQUFFLDBCQUEwQixHQUFHLE1BQU0sR0FBRyxLQUFLLEdBQUcsTUFBTSxDQUFDLEVBQUUsQ0FBQyxDQUFDO1FBRTVFLElBQUksU0FBUyxHQUFXLElBQUksQ0FBQyxTQUFTLENBQUMsWUFBWSxDQUFDLFdBQVcsQ0FBQyxNQUFNLEVBQUUsTUFBTSxDQUFDLEtBQUssQ0FBQyxDQUFDO1FBRXRGLGNBQWM7YUFDVCxNQUFNLENBQUMsS0FBSyxDQUFDO2FBQ2IsSUFBSSxDQUFDLE9BQU8sRUFBRSw0QkFBNEIsQ0FBQzthQUMzQyxJQUFJLENBQUMsU0FBUyxDQUFDO2FBQ2YsSUFBSSxDQUFDLE9BQU8sRUFBRSxJQUFJLENBQUMsU0FBUyxDQUFDLFFBQVEsQ0FBQyxXQUFXLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQztRQUUvRCxJQUFJLENBQUMsaUJBQWlCLENBQUMsY0FBYyxFQUFFLE1BQU0sQ0FBQyxHQUFHLElBQUksTUFBTSxDQUFDLEtBQUssRUFBRSxVQUFVLEVBQUUsVUFBVSxDQUFDLENBQUM7UUFFM0YsT0FBTyxjQUFjLENBQUM7SUFDMUIsQ0FBQztJQUVNLGlCQUFpQixDQUFDLENBQWtCLEVBQUUsQ0FBa0IsRUFBRSxXQUFxQjtRQUNsRixPQUFPLFlBQVksR0FBRyxDQUFDLEdBQUcsQ0FBQyxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUM7SUFDaEcsQ0FBQztJQUVNLFFBQVEsQ0FBQyxLQUFzQixFQUFFLEdBQVc7UUFDL0MsT0FBTyx5QkFBeUIsR0FBRyxLQUFLLEdBQUcsS0FBSyxHQUFHLEdBQUcsQ0FBQztJQUMzRCxDQUFDO0lBRU0sV0FBVyxDQUFDLEtBQVUsRUFBRSxPQUFlO1FBQzFDLE9BQU8sSUFBSSxDQUFDLFNBQVMsQ0FBQyxPQUFPLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDO0lBQ3BELENBQUM7SUFFTyxrQkFBa0I7UUFDdEIsSUFBSSxDQUFDLGtCQUFrQixHQUFHLEVBQUUsQ0FBQyxNQUFNLENBQUMsR0FBRyxHQUFHLElBQUksQ0FBQyxNQUFNLENBQUMsRUFBRSxHQUFHLGNBQWMsR0FBRyxrQ0FBa0MsQ0FBQyxDQUFDO0lBQ3BILENBQUM7SUFFRDs7O09BR0c7SUFDSCxpSEFBaUg7SUFDMUcsb0JBQW9CLENBQUMsU0FBUyxFQUFFLFVBQWtCLEVBQUUsVUFBa0MsRUFBRTtRQUMzRixJQUFJLEtBQUssR0FBaUMsK0JBQStCLENBQUM7UUFDMUUsSUFBSSxhQUFhLEdBQWdDLElBQUksQ0FBQyxTQUFTLENBQUMsdUJBQXVCLENBQUMsSUFBSSxDQUFDLE1BQU0sRUFBRSxPQUFPLENBQUMsQ0FBQztRQUM5RyxJQUFJLE9BQU8sR0FBVyxPQUFPLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7UUFDNUQsSUFBSSxNQUFNLEdBQVcsT0FBTyxHQUFHLENBQUMsQ0FBQztRQUVqQyxJQUFJLGFBQWEsS0FBSyxRQUFRLEVBQUU7WUFDNUIsSUFBSSxNQUFNLEdBQUcsQ0FBQyxLQUFLLEVBQUUsUUFBUSxDQUFDLENBQUM7WUFDL0IsTUFBTSxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsRUFBRTtnQkFDakIsSUFBSSxJQUFJLENBQUMsU0FBUyxDQUFDLGNBQWMsQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLENBQUMsS0FBSyxFQUFFLFVBQVUsRUFBRSxJQUFJLENBQUMsTUFBTSxFQUFFLE9BQU8sQ0FBQyxFQUFFO29CQUNuRixhQUFhLEdBQUcsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDLFFBQVEsQ0FBQztpQkFDdkM7WUFDTCxDQUFDLENBQUMsQ0FBQztTQUNOO2FBQU0sSUFBSSxJQUFJLENBQUMsU0FBUyxDQUFDLGNBQWMsQ0FBQyxLQUFLLENBQUMsYUFBYSxDQUFDLENBQUMsS0FBSyxFQUFFLFVBQVUsRUFBRSxJQUFJLENBQUMsTUFBTSxFQUFFLE9BQU8sQ0FBQyxFQUFFO1lBQ3BHLGFBQWEsR0FBRyxLQUFLLENBQUMsYUFBYSxDQUFDLENBQUMsUUFBUSxDQUFDO1NBQ2pEO1FBRUQsSUFBSSxJQUFJLEdBQVcsRUFBRSxDQUFDO1FBQ3RCLElBQUksYUFBYSxLQUFLLFFBQVEsRUFBRTtZQUM1QixJQUFJLEdBQUcsS0FBSyxDQUFDLGFBQWEsQ0FBQyxDQUFDLE9BQU8sQ0FBQztTQUN2QzthQUFNO1lBQ0gsSUFBSSxJQUFJLEdBQVcsYUFBYSxLQUFLLEtBQUssQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUM7WUFDM0QsSUFBSSxJQUFJLENBQUMsYUFBYSxLQUFLLEtBQUssSUFBSSxJQUFJLENBQUMsU0FBUyxDQUFDLG1CQUFtQixDQUFDLGFBQWEsRUFBRSxPQUFPLENBQUM7Z0JBQUUsTUFBTSxJQUFJLE9BQU8sQ0FBQyxVQUFVLENBQUMsTUFBTSxDQUFDO1lBQ3BJLElBQUksR0FBRyxPQUFPLEdBQUcsS0FBSyxDQUFDLGFBQWEsQ0FBQyxDQUFDLE9BQU8sR0FBRyxJQUFJLEdBQUcsTUFBTSxDQUFDLFFBQVEsRUFBRSxHQUFHLEtBQUssQ0FBQztTQUNwRjtRQUVELElBQUksSUFBSSxHQUFXLENBQUMsT0FBTyxDQUFDLFdBQVcsSUFBSSxPQUFPLENBQUMsV0FBVyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxjQUFjLEdBQUcsT0FBTyxHQUFHLENBQUMsR0FBRyxLQUFLLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQztRQUVsSCxJQUFJLFNBQVMsR0FBVyxJQUFJLENBQUMsYUFBYSxLQUFLLE1BQU0sQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLGlCQUFpQixDQUFDLElBQUksRUFBRSxJQUFJLEVBQUUsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLGFBQWEsR0FBRyxJQUFJLEdBQUcsR0FBRyxDQUFDO1FBQzlILFNBQVMsQ0FBQyxLQUFLLENBQUMsV0FBVyxFQUFFLFNBQVMsQ0FBQyxDQUFDO0lBQzVDLENBQUM7SUFFTyxpQkFBaUIsQ0FBQyxjQUFtQixFQUFFLE9BQWUsRUFBRSxVQUFrQixFQUFFLFVBQWtCO1FBQ2xHLElBQUksZUFBZSxHQUE2QjtZQUM1QyxDQUFDLEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztZQUMxQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztTQUM1QyxDQUFDO1FBQ0YsSUFBSSxDQUFDLEdBQVcsQ0FBQyxPQUFPLFVBQVUsS0FBSyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQyxlQUFlLENBQUMsQ0FBQyxDQUFDO1FBQ2xGLElBQUksQ0FBQyxHQUFXLENBQUMsT0FBTyxVQUFVLEtBQUssUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLFVBQVUsQ0FBQyxDQUFDLENBQUMsZUFBZSxDQUFDLENBQUMsQ0FBQztRQUVsRixrREFBa0Q7UUFDbEQsYUFBYTtRQUNiLElBQUk7UUFFSixJQUFJLElBQUksQ0FBQyxLQUFLO1lBQUUsQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLEtBQUssR0FBRyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQztRQUUxQyxJQUFJLE9BQU8sSUFBSSxDQUFDLE9BQU8sR0FBRyxJQUFJLENBQUMsU0FBUyxJQUFJLE9BQU8sR0FBRyxJQUFJLENBQUMsU0FBUyxDQUFDLEVBQUU7WUFDbkUsY0FBYyxDQUFDLEtBQUssQ0FBQyxTQUFTLEVBQUUsTUFBTSxDQUFDLENBQUM7U0FDM0M7UUFFRCxJQUFJLENBQUMsbUJBQW1CLENBQUMsY0FBYyxFQUFFLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQztJQUNuRCxDQUFDO0lBRU8sbUJBQW1CLENBQUMsY0FBbUIsRUFBRSxVQUFrQixFQUFFLFVBQWtCO1FBQ25GLElBQUksTUFBTSxHQUFXLEVBQUUsQ0FBQztRQUN4QixJQUFJLFVBQVUsR0FBOEIsSUFBSSxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQztRQUUzRSw0RUFBNEU7UUFDNUUsSUFBSSxVQUFVLENBQUMsY0FBYyxDQUFDLFVBQVUsQ0FBQyxJQUFJLFVBQVUsQ0FBQyxRQUFRLEVBQUU7WUFDOUQsTUFBTSxHQUFHLFVBQVUsR0FBRyxVQUFVLENBQUMsUUFBUSxHQUFHLE1BQU0sQ0FBQztTQUN0RDtRQUVELGNBQWM7YUFDVCxLQUFLLENBQUMsV0FBVyxFQUFFLElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxVQUFVLEVBQUUsVUFBVSxDQUFDLEdBQUcsTUFBTSxDQUFDLENBQUM7UUFFakYsSUFBSSxJQUFJLENBQUMsS0FBSztZQUFFLGNBQWMsQ0FBQyxLQUFLLENBQUMsWUFBWSxFQUFFLE9BQU8sQ0FBQyxDQUFDO0lBQ2hFLENBQUM7Q0FDSiIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCAqIGFzIGQzIGZyb20gJ2QzJztcclxuaW1wb3J0IHsgS2RDaGFydHNTdmMgfSBmcm9tICcuL2tkLWFuZ3VsYXItY2hhcnRzLXN2Yyc7XHJcbmltcG9ydCB7XHJcbiAgICBJQ2hhcnRDb25maWcsXHJcbiAgICBJRDNEYXRhRGF0YSxcclxuICAgIElEM0RhdGFSYW5nZSxcclxuICAgIElEM1lEYXRhLFxyXG4gICAgSVlBeGlzQ29uZmlnLFxyXG4gICAgSVhBeGlzQ29uZmlnLFxyXG4gICAgSU1heE1pbkludGVydmFsLFxyXG4gICAgSUxlZ2VuZERhdGEsXHJcbiAgICBJRGF0YUxhYmVsLFxyXG4gICAgSUF4aXNMYWJlbEJvb2xlYW5DaGVja3MsXHJcbiAgICBJTGFiZWxUZXh0VmVydGljYWxBbGlnblN0b3JlLFxyXG4gICAgSVNldFRpY2tWYWx1ZVJldHVybixcclxuICAgIElBeGlzVHJhbnNmb3JtUG9zLFxyXG4gICAgSVhJbmZvLFxyXG4gICAgSVlBeGlzTGFiZWxSYW5nZVxyXG59IGZyb20gJy4va2QtYW5ndWxhci1jaGFydHMtaW50ZXJmYWNlJztcclxuaW1wb3J0IHsgTEFCRUxfVEVYVF9WRVJUSUNBTF9BTElHTl9TVE9SRSwgVE9PTFRJUF9ERUZBVUxUX1NUWUxFIH0gZnJvbSAnLi9rZC1hbmd1bGFyLWNoYXJ0cy1jb25maWcnO1xyXG5pbXBvcnQgeyBLZERvbUVsZW1TdmMgfSBmcm9tICcuLi9rZC1jb21tb24vaW5kZXgnO1xyXG5cclxuZXhwb3J0IGNsYXNzIEtkQ2hhcnRCYXNlQ2xhc3Mge1xyXG5cclxuICAgIC8vIENoYXJ0IFNldHRpbmdcclxuICAgIHB1YmxpYyBpc1J0bDogYm9vbGVhbiA9IGZhbHNlO1xyXG4gICAgcHVibGljIGNvbmZpZzogSUNoYXJ0Q29uZmlnID0ge307XHJcbiAgICBwdWJsaWMgZGF0YTogQXJyYXk8SUQzRGF0YURhdGE+ID0gW107XHJcbiAgICBwdWJsaWMgaW5pdERhdGE6IEFycmF5PElEM0RhdGFEYXRhPiA9IFtdO1xyXG4gICAgcHVibGljIGNoYXJ0VHlwZTogQXJyYXk8c3RyaW5nPjtcclxuICAgIHB1YmxpYyBjaGFydENhdGVnb3J5OiAncGllJyB8ICdiYXInIHwgJ2NvbHVtbicgfCAnbGluZScgfCAnYXJlYScgfCAnZG90JyB8ICdzcGxpbmUnIHwgJ21hcCc7XHJcbiAgICAvKipcclxuICAgICAqIG1heCBhbmQgbWluIHZhbHVlIG9mIGFjcm9zcyBhbGwgc2VyaWVzXHJcbiAgICAgKiB0eXBlIHtJRDNEYXRhUmFuZ2V9XHJcbiAgICAgKi9cclxuICAgIHB1YmxpYyBkYXRhUmFuZ2U6IElEM0RhdGFSYW5nZTtcclxuICAgIHB1YmxpYyBzdmc6IGFueTtcclxuICAgIC8vIHRoaXMgaXMgY2hhcnQtY29udGFpbmVyIChjbGFzc05hbWUpXHJcbiAgICBwdWJsaWMgc3ZnUGFyZW50OiBhbnk7XHJcbiAgICAvLyB0aGlzIGlzIHRoZSBpbW1lZGlhdGUgZGl2IHBhcmVudCBvZiBzdmdcclxuICAgIHB1YmxpYyBzdmdDb250YWluZXI6IGFueTtcclxuICAgIHB1YmxpYyBzdmdSZWN0OiBhbnk7XHJcbiAgICBwdWJsaWMgZ3JhcGg6IGFueTtcclxuICAgIHB1YmxpYyB3aWR0aDogbnVtYmVyO1xyXG4gICAgcHVibGljIGhlaWdodDogbnVtYmVyO1xyXG4gICAgLy8gZDMgc2NhbGVzLiBEZWZpbml0aW9uOiBnaXZlIGRvbWFpbiBhbmQgcmFuZ2UuIFVzYWdlOiB0aGlzLngodmFsdWUpIHdpbGwgb3V0cHV0IGEgdmFsdWUgaW4gdGhlIHJhbmdlXHJcbiAgICBwdWJsaWMgeDogYW55O1xyXG4gICAgcHVibGljIHk6IGFueTtcclxuICAgIHB1YmxpYyB4QXhpc0FycjogQXJyYXk8YW55PiA9IFtdO1xyXG4gICAgcHVibGljIHlBeGlzOiBhbnk7XHJcbiAgICBwdWJsaWMgeEF4aXNGdW5jOiBhbnk7XHJcbiAgICBwdWJsaWMgeUF4aXNGdW5jOiBhbnk7XHJcbiAgICAvLyBheGlzTWF4L01pbiBpcyB1c2VkIG9ubHkgd2hlbiBhdXRvUm91bmRUb01heCwgZXZlbnR1YWxseSBzdG9yZWQgaW50byBkb21haW5NYXgvTWluXHJcbiAgICBwdWJsaWMgYXhpc01heDogbnVtYmVyO1xyXG4gICAgcHVibGljIGF4aXNNaW46IG51bWJlciA9IDA7XHJcbiAgICAvLyBmaW5hbCBheGlzIHZhbHVlcyBwYXNzZWQgdG8gZDMuc2NhbGVcclxuICAgIHB1YmxpYyBkb21haW5NYXg6IG51bWJlcjtcclxuICAgIHB1YmxpYyBkb21haW5NaW46IG51bWJlcjtcclxuICAgIHB1YmxpYyBncmlkTGluZXNDb250YWluZXI6IGFueTtcclxuICAgIHB1YmxpYyBheGlzTGFiZWxDb250YWluZXJBcnI6IEFycmF5PGFueT4gPSBbXTtcclxuICAgIHB1YmxpYyB0aWNrVmFsdWVzOiBBcnJheTxudW1iZXI+O1xyXG4gICAgcHVibGljIGhhdmVOZWdhdGl2ZTogYm9vbGVhbiA9IGZhbHNlO1xyXG4gICAgLyoqXHJcbiAgICAgKiB1c2VkIG9ubHkgYnkgYmFyLlxyXG4gICAgICogYmFyR3JvdXBQYWRkaW5nIGlzIHVzZWQgb25seSBmb3IgY2x1c3RlciAtLT4gdGhlIHBhZGRpbmcgYmV0d2VlbiBlYWNoIHJlY3QgaW4gYSBjYXRlZ29yeVxyXG4gICAgICogYmFuZFBhZGRpbmcgaXMgZ2l2ZW4gdG8gZDMgLS0+IHRoZSBwYWRkaW5nIGJldHdlZW4gZWFjaCBjYXRlZ29yeVxyXG4gICAgICogdHlwZSB7SUJhc2VDbGFzc0Jhck9ian1cclxuICAgICAqL1xyXG4gICAgcHVibGljIGJhcjogeyBpc0ludmVydDogYm9vbGVhbjsgY2x1c3RlclBhZGRpbmdQZXJjZW50OiBudW1iZXI7IGJhbmRQYWRkaW5nOiBudW1iZXIgfSA9IHtcclxuICAgICAgICBpc0ludmVydDogZmFsc2UsXHJcbiAgICAgICAgY2x1c3RlclBhZGRpbmdQZXJjZW50OiAwLjEsXHJcbiAgICAgICAgYmFuZFBhZGRpbmc6IDAuMixcclxuICAgIH07XHJcblxyXG4gICAgcHVibGljIHJhbmdlTGlzdDogb2JqZWN0O1xyXG4gICAgcHVibGljIGxlbmd0aE9mVHJhbnNpdGlvbjogbnVtYmVyID0gMTAwMDtcclxuXHJcbiAgICAvLyBEYXRhIGxhYmVsIFNldHRpbmdcclxuICAgIHB1YmxpYyBkYXRhTGFiZWxDb250YWluZXI7XHJcblxyXG4gICAgcHVibGljIGxlZ2VuZERhdGE6IHsgW2tleTogc3RyaW5nXTogSUxlZ2VuZERhdGEgfTtcclxuXHJcbiAgICBwdWJsaWMgZXJyb3JNc2c6IHN0cmluZyA9ICcxMDAlIHN0YWNrIGRvZXMgbm90IHN1cHBvcnQgbmVnYXRpdmUgdmFsdWVzLic7XHJcblxyXG4gICAgcHJpdmF0ZSBfc2V0Q2hhcnRUaW1lb3V0OiBhbnk7XHJcblxyXG4gICAgY29uc3RydWN0b3IocHVibGljIF9jaGFydFN2YzogS2RDaGFydHNTdmMsIHB1YmxpYyBfZG9tU3ZjOiBLZERvbUVsZW1TdmMpIHtcclxuICAgICAgICB0aGlzLmlzUnRsID0gX2RvbVN2Yy5nZXREb2N1bWVudERpcmVjdGlvbih0cnVlKSA9PT0gJ3JpZ2h0JztcclxuICAgIH1cclxuXHJcbiAgICAvLyA9PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT0gQ2hhcnQgPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PVxyXG5cclxuICAgIHB1YmxpYyBzZXRTdmcoKTogdm9pZCB7XHJcbiAgICAgICAgdGhpcy5zdmcgPSBkMy5zZWxlY3QoJyMnICsgdGhpcy5jb25maWcuaWQgKyAnLmtkeC1jaGFydHMgc3ZnJyk7XHJcbiAgICAgICAgaWYgKCF0aGlzLmdyYXBoKSB0aGlzLmdyYXBoID0gdGhpcy5zdmcuYXBwZW5kKCdnJykuYXR0cignY2xhc3MnLCAnZ3JhcGgnKTtcclxuICAgICAgICAvLyBpZiAodGhpcy5zdmcuc2VsZWN0KCcuZ3JhcGgnKS5lbXB0eSgpKSB0aGlzLmdyYXBoID0gdGhpcy5zdmcuYXBwZW5kKCdnJykuYXR0cignY2xhc3MnLCAnZ3JhcGgnKTtcclxuICAgICAgICB0aGlzLnN2Z1BhcmVudCA9IGQzLnNlbGVjdCgnIycgKyB0aGlzLmNvbmZpZy5pZCArICcua2R4LWNoYXJ0cyAua2R4LWNoYXJ0LWNvbnRhaW5lcicpO1xyXG4gICAgICAgIHRoaXMuc3ZnQ29udGFpbmVyID0gZDMuc2VsZWN0KCcjJyArIHRoaXMuY29uZmlnLmlkICsgJy5rZHgtY2hhcnRzIC5rZHgtY2hhcnRzLXN2Zy1jb250YWluZXInKTtcclxuXHJcbiAgICAgICAgdGhpcy5fc2V0TGFiZWxDb250YWluZXIoKTtcclxuICAgICAgICB0aGlzLl9zZXRDaGFydFN2YygpO1xyXG4gICAgICAgIHRoaXMucmFuZ2VMaXN0ID0ge307XHJcbiAgICB9XHJcblxyXG4gICAgLyoqXHJcbiAgICAgKiBzZXQgc3ZnIHdpZHRoIGFuZCBoZWlnaHQuIHRoaXMgZnVuY3Rpb24gaXMgYmVjb3Mgb2YgZXhwb3J0IGZlYXR1cmUsIHRoZSBleHBvcnQgcGx1Z2lucyByZXF1aXJlcyBzdmcgd2lkdGggYW5kIGhlaWdodCB0byBiZSBpbmxpbmUgYXR0cmlidXRlcyB3aXRoIGRlZmluaXRlIG51bWJlclxyXG4gICAgICogaGF2ZSB0byBiZSBjYWxsZWQgYnkgYWxsIGNoYXJ0c1xyXG4gICAgICogcGFyYW0geyd4JyB8ICd5J30gX2F4aXNcclxuICAgICAqL1xyXG4gICAgcHVibGljIHNldFN2Z0RpbWVuc2lvbihfYXhpczogJ3gnIHwgJ3knKTogdm9pZCB7XHJcbiAgICAgICAgbGV0IHN2Z0NvbnRhaW5lclJlY3Q6IGFueSA9IHRoaXMuc3ZnQ29udGFpbmVyLm5vZGUoKS5nZXRCb3VuZGluZ0NsaWVudFJlY3QoKTtcclxuICAgICAgICBsZXQgdHlwZTogJ3dpZHRoJyB8ICdoZWlnaHQnID0gX2F4aXMgPT09ICd4JyA/ICh0aGlzLmJhci5pc0ludmVydCA/ICdoZWlnaHQnIDogJ3dpZHRoJykgOiAodGhpcy5iYXIuaXNJbnZlcnQgPyAnd2lkdGgnIDogJ2hlaWdodCcpO1xyXG5cclxuICAgICAgICB0aGlzLnN2Zy5hdHRyKHR5cGUsIHN2Z0NvbnRhaW5lclJlY3RbdHlwZV0pO1xyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX2NsZWFyU3ZnRGltZW5zaW9uKCk6IHZvaWQge1xyXG4gICAgICAgIGlmICghdGhpcy5zdmcpIHJldHVybjtcclxuICAgICAgICB0aGlzLnN2Z1xyXG4gICAgICAgICAgICAuYXR0cignd2lkdGgnLCAwKVxyXG4gICAgICAgICAgICAuYXR0cignaGVpZ2h0JywgMCk7XHJcbiAgICB9XHJcblxyXG4gICAgLyoqXHJcbiAgICAgKiBzZXQgdGhpcy53aWR0aCBhbmQgdGhpcy5oZWlnaHQgZm9yIGF4aXMgc2NhbGVzLiBvbmx5IGNhbGxlZCBieSBjaGFydHMgd2l0aCBheGlzXHJcbiAgICAgKiBwYXJhbSB7J3gnIHwneSd9ICAgICAgICAgX2F4aXNcclxuICAgICAqIHBhcmFtIHtib29sZWFufSBfc2tpcENhbCA6IHNraXAgZ2V0U3ZnT2Zmc2V0IGNhbGN1bGF0aW9uc1xyXG4gICAgICovXHJcbiAgICBwcml2YXRlIF9zZXRHcmFwaERpbWVuc2lvbihfYXhpczogJ3gnIHwgJ3knKTogdm9pZCB7XHJcbiAgICAgICAgdGhpcy5zdmdSZWN0ID0gdGhpcy5zdmcubm9kZSgpLmdldEJvdW5kaW5nQ2xpZW50UmVjdCgpO1xyXG4gICAgICAgIHRoaXMuX2NoYXJ0U3ZjLnN2Z1JlY3QgPSB0aGlzLnN2Z1JlY3Q7XHJcblxyXG4gICAgICAgIGxldCB0eXBlOiAnd2lkdGgnIHwgJ2hlaWdodCcgPSBfYXhpcyA9PT0gJ3gnID8gKHRoaXMuYmFyLmlzSW52ZXJ0ID8gJ2hlaWdodCcgOiAnd2lkdGgnKSA6ICh0aGlzLmJhci5pc0ludmVydCA/ICd3aWR0aCcgOiAnaGVpZ2h0Jyk7XHJcblxyXG4gICAgICAgIGxldCB2YWx1ZTogbnVtYmVyID0gdGhpcy5fY2hhcnRTdmMuZ2V0U3ZnT2Zmc2V0KF9heGlzLCB7IGF4aXNNYXg6IHRoaXMuYXhpc01heCwgYXhpc01pbjogdGhpcy5heGlzTWluIH0pO1xyXG5cclxuICAgICAgICB0aGlzW3R5cGVdID0gdmFsdWUgPCAwID8gMCA6IHZhbHVlO1xyXG4gICAgfVxyXG5cclxuICAgIC8qKlxyXG4gICAgICogc2V0IENoYXJ0IFNlcnZpY2UgdmFyaWFibGVzXHJcbiAgICAgKi9cclxuICAgIHByaXZhdGUgX3NldENoYXJ0U3ZjKCk6IHZvaWQge1xyXG4gICAgICAgIHRoaXMuX2NoYXJ0U3ZjLmNvbmZpZyA9IHRoaXMuY29uZmlnO1xyXG4gICAgICAgIHRoaXMuX2NoYXJ0U3ZjLmNoYXJ0VHlwZSA9IHRoaXMuY2hhcnRUeXBlO1xyXG4gICAgICAgIHRoaXMuX2NoYXJ0U3ZjLmNoYXJ0Q2F0ZWdvcnkgPSB0aGlzLmNoYXJ0Q2F0ZWdvcnk7XHJcbiAgICAgICAgdGhpcy5fY2hhcnRTdmMuc3ZnUGFyZW50UmVjdCA9IHRoaXMuc3ZnUGFyZW50Lm5vZGUoKS5nZXRCb3VuZGluZ0NsaWVudFJlY3QoKTtcclxuICAgICAgICB0aGlzLl9jaGFydFN2Yy5zdmcgPSB0aGlzLnN2ZztcclxuICAgICAgICB0aGlzLl9jaGFydFN2Yy5pc1J0bCA9IHRoaXMuaXNSdGw7XHJcbiAgICAgICAgdGhpcy5fY2hhcnRTdmMuaXNYUmV2ZXJzZWQgPSB0aGlzLmNvbmZpZy54QXhpcy5yZXZlcnNlZDtcclxuICAgICAgICB0aGlzLl9jaGFydFN2Yy5pc1lSZXZlcnNlZCA9IHRoaXMuY29uZmlnLnlBeGlzLnJldmVyc2VkO1xyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX3NldExpbmVhclNjYWxlKCk6IHZvaWQge1xyXG4gICAgICAgIGxldCByYW5nZVJvdW5kVmFsOiBBcnJheTxudW1iZXI+ID0gdGhpcy5fZ2V0UmFuZ2VWYWwoJ3knKTtcclxuICAgICAgICB0aGlzLnkgPSBkMy5zY2FsZUxpbmVhcigpLnJhbmdlUm91bmQocmFuZ2VSb3VuZFZhbCk7XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfc2V0QmFuZFNjYWxlKCk6IHZvaWQge1xyXG4gICAgICAgIGxldCByYW5nZVZhbDogQXJyYXk8bnVtYmVyPiA9IHRoaXMuX2dldFJhbmdlVmFsKCd4Jyk7XHJcblxyXG4gICAgICAgIHRoaXMueCA9IGQzLnNjYWxlQmFuZCgpLnJhbmdlKHJhbmdlVmFsKTtcclxuXHJcbiAgICAgICAgaWYgKHRoaXMuY2hhcnRDYXRlZ29yeSA9PT0gJ2JhcicpIHtcclxuICAgICAgICAgICAgdGhpcy54LnBhZGRpbmdJbm5lcih0aGlzLmJhci5iYW5kUGFkZGluZykucGFkZGluZ091dGVyKHRoaXMuYmFyLmJhbmRQYWRkaW5nIC8gMik7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX2dldFJhbmdlVmFsKF9heGlzOiAneCcgfCAneScpOiBudW1iZXJbXSB7XHJcbiAgICAgICAgbGV0IHJhbmdlVmFsOiBudW1iZXJbXTtcclxuICAgICAgICBsZXQgcmV2ZXJzZWQ6ICdpc1hSZXZlcnNlZCcgfCAnaXNZUmV2ZXJzZWQnID0gX2F4aXMgPT09ICd4JyA/ICdpc1hSZXZlcnNlZCcgOiAnaXNZUmV2ZXJzZWQnO1xyXG5cclxuICAgICAgICBpZiAodGhpcy5iYXIuaXNJbnZlcnQpIHtcclxuICAgICAgICAgICAgcmFuZ2VWYWwgPSBfYXhpcyA9PT0gJ3gnID8gWzAsIHRoaXMuaGVpZ2h0XSA6IFswLCB0aGlzLndpZHRoXTtcclxuICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICByYW5nZVZhbCA9IF9heGlzID09PSAneCcgPyBbMCwgdGhpcy53aWR0aF0gOiBbdGhpcy5oZWlnaHQsIDBdO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgcmV0dXJuIHRoaXMuX2NoYXJ0U3ZjW3JldmVyc2VkXSA/IHJhbmdlVmFsLnJldmVyc2UoKSA6IHJhbmdlVmFsO1xyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX3NldFJhbmdlKGlzQmFuZD86IGJvb2xlYW4pOiBBcnJheTxudW1iZXI+IHtcclxuICAgICAgICBsZXQgY2hhcnRXaWR0aDogbnVtYmVyID0gdGhpcy53aWR0aDtcclxuXHJcbiAgICAgICAgaWYgKCFpc0JhbmQgJiYgdGhpcy5kYXRhLmxlbmd0aCA8PSAwKSB7XHJcbiAgICAgICAgICAgIHRoaXMucmFuZ2VMaXN0WzBdID0gY2hhcnRXaWR0aDtcclxuICAgICAgICAgICAgcmV0dXJuIFswLCBjaGFydFdpZHRoXTtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIGxldCB4UG9zaXRpb246IG51bWJlciA9IDA7XHJcbiAgICAgICAgbGV0IHJhbmdlQXJyYXk6IEFycmF5PG51bWJlcj4gPSBbXTtcclxuICAgICAgICBsZXQgYmFuZFdpZHRoOiBudW1iZXIgPSBjaGFydFdpZHRoIC8gdGhpcy5kYXRhLmxlbmd0aDtcclxuXHJcbiAgICAgICAgZm9yIChsZXQgaSA9IDA7IGkgPCB0aGlzLmRhdGEubGVuZ3RoOyBpKyspIHtcclxuXHJcbiAgICAgICAgICAgIGlmIChpc0JhbmQpIHtcclxuICAgICAgICAgICAgICAgIHhQb3NpdGlvbiA9IHRoaXMuX2dldENlbnRlckJhbmRQb3NpdGlvbihiYW5kV2lkdGgsIGkpO1xyXG4gICAgICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgeFBvc2l0aW9uID0gY2hhcnRXaWR0aCAvICh0aGlzLmRhdGEubGVuZ3RoIC0gMSkgKiBpO1xyXG4gICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICBpZiAodGhpcy5fY2hhcnRTdmMuaXNYUmV2ZXJzZWQpIHhQb3NpdGlvbiA9IGNoYXJ0V2lkdGggLSB4UG9zaXRpb247XHJcblxyXG4gICAgICAgICAgICByYW5nZUFycmF5LnB1c2goeFBvc2l0aW9uKTtcclxuICAgICAgICAgICAgdGhpcy5yYW5nZUxpc3RbdGhpcy5kYXRhW2ldLngudmFsdWVdID0geFBvc2l0aW9uO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgcmV0dXJuIHJhbmdlQXJyYXk7XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfZ2V0Q2VudGVyQmFuZFBvc2l0aW9uKF9iYW5kV2lkdGg6IG51bWJlciwgX3Bvc2l0aW9uOiBudW1iZXIpOiBudW1iZXIge1xyXG4gICAgICAgIHJldHVybiAoX2JhbmRXaWR0aCAvIDIpICsgKF9iYW5kV2lkdGggKiBfcG9zaXRpb24pO1xyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX3NldFNjYWxlQnlEaXJlY3Rpb24oX2F4aXM6ICd4JyB8ICd5JywgX3hTY2FsZVR5cGU/OiAnYmFuZCcgfCAnc3RyaW5nJyk6IHZvaWQge1xyXG4gICAgICAgIGlmIChfYXhpcyA9PT0gJ3gnKSB7XHJcbiAgICAgICAgICAgIGlmIChfeFNjYWxlVHlwZSAhPT0gJ3N0cmluZycpIHRoaXMuX3NldEJhbmRTY2FsZSgpO1xyXG4gICAgICAgICAgICBpZiAodGhpcy5jaGFydENhdGVnb3J5ID09PSAnbGluZScpIHRoaXMuX3NldExpbmVTY2FsZVgoX3hTY2FsZVR5cGUpO1xyXG4gICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgIHRoaXMuX3NldExpbmVhclNjYWxlKCk7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIC8qKlxyXG4gICAgICogKGZvciBsaW5lIG9ubHkpXHJcbiAgICAgKiBoYXBwZW5zIGF0IGZpcnN0IGxvYWQgYW5kIG9uIGNoYW5nZSBhbmQgbWF5IGhhcHBlbiBpZiBkYXRhIGlzIHNsaWNlZCBkdXJpbmcgdHJpbVgoKVxyXG4gICAgICovXHJcbiAgICBwcml2YXRlIF9zZXRMaW5lU2NhbGVYKF94U2NhbGVUeXBlOiAnc3RyaW5nJyB8ICdiYW5kJyk6IHZvaWQge1xyXG4gICAgICAgIGlmIChfeFNjYWxlVHlwZSA9PT0gJ3N0cmluZycpIHtcclxuICAgICAgICAgICAgdGhpcy54ID0gZDMuc2NhbGVPcmRpbmFsKCkucmFuZ2UodGhpcy5fc2V0UmFuZ2UoZmFsc2UpKTtcclxuICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICB0aGlzLl9zZXRSYW5nZSh0cnVlKTtcclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgLy8gPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09IERvbWFpbiA9PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09XHJcblxyXG4gICAgcHVibGljIHNldERvbWFpbihfeFNjYWxlVHlwZTogJ3N0cmluZycgfCAnYmFuZCcpOiB2b2lkIHtcclxuXHJcbiAgICAgICAgdGhpcy5fY2hhcnRTdmMueFNjYWxlVHlwZSA9IF94U2NhbGVUeXBlO1xyXG5cclxuICAgICAgICB0aGlzLnN2Zy5hdHRyKCd2aXNpYmlsaXR5JywgJ2hpZGRlbicpO1xyXG5cclxuICAgICAgICAvLyBzZXR0aW5nIHRoZSBjbGFzcyBuYW1lIG9mIGNoYXJ0LXdyYXBwZXIgKGZvciBmbGV4LXJldmVyc2UpXHJcbiAgICAgICAgdGhpcy5fY2hhcnRTdmMuc2V0VmVydEF4aXNBbmRDaGFydE1hcmdpbih0aGlzLmNvbmZpZy5pZCk7XHJcblxyXG4gICAgICAgIC8vIGV2ZXJ5dGltZSB0aGUgZ3JhcGggcmVzZXRzLCBpZiB0cmltbWluZyBoYXZlIG9jY3VyZWQgYmVmb3JlIChpZTogdGhpcy5kYXRhIGFuZCBpbml0RGF0YSBsZW5ndGggZGlmZmVycyksIHJlc2V0IHRoaXMuZGF0YSBzbyB0aGF0IHRoZSB0cmltbWluZyBjYWxjdWxhdGlvbiB1c2VzIGZ1bGwgZGF0YXNldFxyXG4gICAgICAgIGlmICh0aGlzLmluaXREYXRhICYmIHRoaXMuZGF0YS5sZW5ndGggIT09IHRoaXMuaW5pdERhdGEubGVuZ3RoKSB7XHJcbiAgICAgICAgICAgIHRoaXMuZGF0YSA9IEpTT04ucGFyc2UoSlNPTi5zdHJpbmdpZnkodGhpcy5pbml0RGF0YSkpO1xyXG4gICAgICAgICAgICAvLyB0aGlzLl9jaGFydFN2Yy5zZXRBeGlzTGFiZWxEdW1teVRleHQodGhpcy5jYXRlZ29yaWVzLCB0aGlzLmNvbmZpZy54QXhpcy5sYWJlbHMuZm9ybWF0KTtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIC8vIHNldCB0aGlzLndpZHRoLGhlaWdodCwgc2NhbGUsIGRvbWFpbiBhbmQgdGlja1ZhbHVlc1xyXG4gICAgICAgIHRoaXMuX3NldERvbWFpbihfeFNjYWxlVHlwZSk7XHJcblxyXG4gICAgICAgIHRoaXMuc3ZnLmF0dHIoJ3Zpc2liaWxpdHknLCAndmlzaWJsZScpO1xyXG5cclxuICAgICAgICAvLyBzZXQgbWFqb3IgYW5kIG1pbm9yIGdyaWQgbGluZXNcclxuICAgICAgICB0aGlzLl9zZXRHcmlkTGluZXMoKTtcclxuXHJcbiAgICAgICAgLy8gc2V0IHkgYW5kIHggYXhpcyBsaW5lc1xyXG4gICAgICAgIHRoaXMuc2V0QXhpcygpO1xyXG5cclxuICAgICAgICAvLyB0cmFuc2Zvcm0gZ3JhcGggYWNjb3JkaW5nIHRvIHdpZHRoIG9mIHZlcnRpY2FsIGF4aXNcclxuICAgICAgICB0aGlzLl9jaGFydFN2Yy50cmFuc2Zvcm1HcmFwaENvbnRhaW5lcih0aGlzLmdyYXBoKTtcclxuXHJcbiAgICAgICAgLy8gcmVwb3NpdGlvbiBEYXRhIExhYmVsIGFjY29yZGluZyB0byB3aWR0aCBvZiB2ZXJ0aWNhbCBheGlzXHJcbiAgICAgICAgaWYgKHRoaXMuY29uZmlnLmNoYXJ0LmxhYmVscy5lbmFibGVkKSB7XHJcbiAgICAgICAgICAgIHRoaXMuZGF0YUxhYmVsQ29udGFpbmVyLnN0eWxlKCd3aWR0aCcsIHRoaXMud2lkdGggKyAncHgnKTtcclxuICAgICAgICAgICAgdGhpcy5fY2hhcnRTdmMucmVwb3NpdGlvbkRhdGFMYWJlbCh0aGlzLmRhdGFMYWJlbENvbnRhaW5lciwgdGhpcy5heGlzTGFiZWxDb250YWluZXJBcnJbMF0pO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgLy8gcmVwb3NpdGlvbiB2ZXJ0aWNhbCBheGlzXHJcbiAgICAgICAgdGhpcy5fY2hhcnRTdmMucmVwb3NpdGlvblZlcnRpY2FsQXhpc1RpdGxlKCk7XHJcblxyXG4gICAgICAgIC8vIHNldCBjbGlwIHBhdGggdG8gdGhpcy53aWR0aCBhbmQgdGhpcy5oZWlnaHQgdG8gbWFrZSBzdXJlIGdyYXBoIHdpbGwgbm90IGJlIGRyYXduIG91dCBvZiBncmFwaGluZyByZWdpb25cclxuICAgICAgICB0aGlzLl9zZXRDbGlwUGF0aCgpO1xyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX3NldERvbWFpbihfeFNjYWxlVHlwZTogJ3N0cmluZycgfCAnYmFuZCcpOiB2b2lkIHtcclxuICAgICAgICAvLyBmaW5kaW5nIHRoZSBtYXgvbWluIHZhbHVlIGFuZCBheGlzTWF4L2F4aXNNaW5cclxuICAgICAgICBsZXQgYXhpc0xhYmVsQ29uZmlnOiBJWUF4aXNDb25maWcgPSB0aGlzLmNvbmZpZy55QXhpcztcclxuICAgICAgICBsZXQgcmVzdWx0OiBJTWF4TWluSW50ZXJ2YWwgPSB0aGlzLl9jaGFydFN2Yy5zZXRNYXhBbmRNaW4oYXhpc0xhYmVsQ29uZmlnLCB0aGlzLmRhdGFSYW5nZSk7XHJcbiAgICAgICAgdGhpcy5fY2hhcnRTdmMuc2V0QXhpc0QzRm9ybWF0KHJlc3VsdC5pbnRlcnZhbCk7XHJcblxyXG4gICAgICAgIHRoaXMuX3NldEF4aXNNYXhBbmRNaW4ocmVzdWx0Lm1heFZhbHVlLCByZXN1bHQubWluVmFsdWUsIHJlc3VsdC5pbnRlcnZhbCk7XHJcblxyXG4gICAgICAgIGxldCB4SW5mbzogSVhJbmZvID0gdGhpcy5fY2hhcnRTdmMuZ2V0WEluZm8odGhpcy5kYXRhLCB0aGlzLmNvbmZpZyk7XHJcbiAgICAgICAgdGhpcy5fc2V0V2lkdGhIZWlnaHRTY2FsZSgneCcsIF94U2NhbGVUeXBlKTtcclxuICAgICAgICB0aGlzLnguZG9tYWluKHhJbmZvLnZhbHVlKTtcclxuICAgICAgICB0aGlzLl9zZXRYQXhpc0xhYmVsKF94U2NhbGVUeXBlLCB4SW5mby5sb25nZXN0VGV4dCk7XHJcblxyXG4gICAgICAgIHRoaXMuX3NldFdpZHRoSGVpZ2h0U2NhbGUoJ3knLCBfeFNjYWxlVHlwZSk7XHJcblxyXG4gICAgICAgIGxldCB0aWNrVmFsdWVSZXR1cm46IElTZXRUaWNrVmFsdWVSZXR1cm4gPSB0aGlzLl9maW5kSW50ZXJ2YWxGb3JOb092ZXJsYXAocmVzdWx0KTtcclxuXHJcbiAgICAgICAgaWYgKHRpY2tWYWx1ZVJldHVybiAmJiB0aWNrVmFsdWVSZXR1cm4ubmVlZFJlZHJhdykge1xyXG4gICAgICAgICAgICB0aGlzLl9zZXRXaWR0aEhlaWdodFNjYWxlKCd4JywgX3hTY2FsZVR5cGUpO1xyXG4gICAgICAgICAgICB0aGlzLnguZG9tYWluKHhJbmZvLnZhbHVlKTtcclxuICAgICAgICAgICAgdGhpcy5fc2V0WEF4aXNMYWJlbChfeFNjYWxlVHlwZSwgeEluZm8ubG9uZ2VzdFRleHQpO1xyXG5cclxuICAgICAgICAgICAgdGhpcy5fc2V0V2lkdGhIZWlnaHRTY2FsZSgneScsIF94U2NhbGVUeXBlKTtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIC8vIG9ubHkgZ2VuZXJhdGUgcmFuZ2UgYXJyIHdoZW4gaW50ZXJ2YWwgaXMgc3RhYmxpemVkXHJcbiAgICAgICAgdGhpcy50aWNrVmFsdWVzID0gdGhpcy5fY2hhcnRTdmMuZ2V0VGlja1ZhbHVlcyh0aGlzLmF4aXNNaW4sIHRoaXMuYXhpc01heCwgdGlja1ZhbHVlUmV0dXJuLmludGVydmFsKTtcclxuXHJcbiAgICAgICAgLy8gc2V0IFkgZG9tYWluXHJcbiAgICAgICAgdGhpcy5kb21haW5NYXggPSBheGlzTGFiZWxDb25maWcuYXV0b1JvdW5kVG9NYXggPyB0aGlzLmF4aXNNYXggOiByZXN1bHQubWF4VmFsdWU7XHJcbiAgICAgICAgdGhpcy5kb21haW5NaW4gPSBheGlzTGFiZWxDb25maWcuYXV0b1JvdW5kVG9NaW4gPyB0aGlzLmF4aXNNaW4gOiByZXN1bHQubWluVmFsdWU7XHJcbiAgICAgICAgdGhpcy55LmRvbWFpbihbdGhpcy5kb21haW5NaW4sIHRoaXMuZG9tYWluTWF4XSk7XHJcbiAgICB9XHJcblxyXG5cclxuICAgIHByaXZhdGUgX3NldFdpZHRoSGVpZ2h0U2NhbGUoX2F4aXM6ICd4JyB8ICd5JywgX3hTY2FsZVR5cGU6ICdzdHJpbmcnIHwgJ2JhbmQnKTogdm9pZCB7XHJcbiAgICAgICAgdGhpcy5zZXRTdmdEaW1lbnNpb24oX2F4aXMpO1xyXG4gICAgICAgIHRoaXMuX3NldEdyYXBoRGltZW5zaW9uKF9heGlzKTtcclxuICAgICAgICB0aGlzLl9zZXRTY2FsZUJ5RGlyZWN0aW9uKF9heGlzLCBfeFNjYWxlVHlwZSk7XHJcbiAgICB9XHJcblxyXG4gICAgLyoqXHJcbiAgICAgKiBzZXQgY2xpcCBwYXRoIHRvIHRoaXMud2lkdGggYW5kIHRoaXMuaGVpZ2h0IHRvIG1ha2Ugc3VyZSBncmFwaCB3aWxsIG5vdCBiZSBkcmF3biBvdXQgb2YgZ3JhcGhpbmcgcmVnaW9uXHJcbiAgICAgKi9cclxuICAgIHByaXZhdGUgX3NldENsaXBQYXRoKCk6IHZvaWQge1xyXG4gICAgICAgIGxldCBjbGlwUGF0aFJlY3Q6IGFueSA9IHRoaXMuc3ZnLnNlbGVjdEFsbCgnZGVmcyAja2QtY2hhcnRzLWNsaXAtcGF0aC0nICsgdGhpcy5jb25maWcuaWQgKyAnIHJlY3QnKTtcclxuICAgICAgICBpZiAoY2xpcFBhdGhSZWN0LmVtcHR5KCkpIHtcclxuICAgICAgICAgICAgY2xpcFBhdGhSZWN0ID0gdGhpcy5zdmcuaW5zZXJ0KCdkZWZzJykuYXBwZW5kKCdjbGlwUGF0aCcpLmF0dHIoJ2lkJywgJ2tkLWNoYXJ0cy1jbGlwLXBhdGgtJyArIHRoaXMuY29uZmlnLmlkKS5hcHBlbmQoJ3JlY3QnKTtcclxuICAgICAgICAgICAgY2xpcFBhdGhSZWN0XHJcbiAgICAgICAgICAgICAgICAuYXR0cigneCcsIDApXHJcbiAgICAgICAgICAgICAgICAuYXR0cigneScsIDApXHJcbiAgICAgICAgICAgICAgICAuYXR0cignZmlsbCcsICdub25lJyk7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGNsaXBQYXRoUmVjdFxyXG4gICAgICAgICAgICAuYXR0cignd2lkdGgnLCB0aGlzLndpZHRoKVxyXG4gICAgICAgICAgICAuYXR0cignaGVpZ2h0JywgdGhpcy5oZWlnaHQpO1xyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX3NldEF4aXNNYXhBbmRNaW4oX21heFZhbHVlOiBudW1iZXIsIF9taW5WYWx1ZTogbnVtYmVyLCBfaW50ZXJ2YWw6IG51bWJlcik6IHZvaWQge1xyXG4gICAgICAgIGxldCB5QXhpc0NvbmZpZzogSVlBeGlzQ29uZmlnID0gdGhpcy5jb25maWcueUF4aXM7XHJcbiAgICAgICAgdGhpcy5heGlzTWF4ID0gdGhpcy5fY2hhcnRTdmMuc2V0QXhpc1JvdW5kVmFsdWUoX21heFZhbHVlLCBfaW50ZXJ2YWwsIHlBeGlzQ29uZmlnLmF1dG9Sb3VuZFRvTWF4LCAndXAnKTtcclxuICAgICAgICB0aGlzLmF4aXNNaW4gPSB0aGlzLl9jaGFydFN2Yy5zZXRBeGlzUm91bmRWYWx1ZShfbWluVmFsdWUsIF9pbnRlcnZhbCwgeUF4aXNDb25maWcuYXV0b1JvdW5kVG9NaW4sICdkb3duJyk7XHJcbiAgICB9XHJcblxyXG4gICAgLyoqXHJcbiAgICogd2lsbCByZXR1cm4gYW4gb2JqZWN0IHdpdGggZm9sbG93aW5nIHByb3BlcnRpZXNcclxuICAgKiBuZWVkUmVkcmF3OiB0byBkZXRlcm1pbmUgd2hldGhlciB0byByZWRyYXcgdGhlIGF4aXMgKGFuZCByZXNldCB0aGUgZG9tYWluKVxyXG4gICAqIGludGVydmFsOiBwYXNzIG91dCB0aGUgbGFzdGVzdCBpbnRlcnZhbCAodGhhdCBoYXZlIG5vIG92ZXJsYXApIGZvciBwZXJmb3JtYW5jZSByZWFzb25zLCBzbyB0aGF0IHRoZSB3aGlsZSBsb29wIHdpbGwgb25seSBydW4gb25jZSBvbiBuZWVkUmVkcmF3XHJcbiAgICovXHJcbiAgICBwcml2YXRlIF9maW5kSW50ZXJ2YWxGb3JOb092ZXJsYXAoX2luaXRJbmZvOiBJTWF4TWluSW50ZXJ2YWwpOiBJU2V0VGlja1ZhbHVlUmV0dXJuIHtcclxuICAgICAgICBsZXQgbGVuZ3RoOiBudW1iZXIgPSB0aGlzLmJhci5pc0ludmVydCA/IHRoaXMud2lkdGggOiB0aGlzLmhlaWdodDtcclxuICAgICAgICBpZiAobGVuZ3RoIDw9IDApIHJldHVybiB7IG5lZWRSZWRyYXc6IGZhbHNlLCBpbnRlcnZhbDogMCB9O1xyXG5cclxuICAgICAgICBsZXQgdGlja0xlbmd0aDogbnVtYmVyO1xyXG4gICAgICAgIGxldCBpbml0WUF4aXNMYWJlbFdpZHRoOiBJWUF4aXNMYWJlbFJhbmdlID0gT2JqZWN0LmFzc2lnbih7fSwgdGhpcy5fY2hhcnRTdmMueUF4aXNMYWJlbFdpZHRoKTtcclxuXHJcbiAgICAgICAgaWYgKHRoaXMuYmFyLmlzSW52ZXJ0KSB7XHJcbiAgICAgICAgICAgIC8vIGF4aXNNYXggYW5kIGF4aXNNaW4gaXMgYWxyZWFkeSBhcHBlbmRlZCBhcyBkdW1teSB0byBzdmcgd2hlbiBjYWxjdWxhdGluZyBmb3IgdGhpcy53aWR0aCBhbmQgdGhpcy5oZWlnaHRcclxuICAgICAgICAgICAgLy8gd2UgY2FuIGRpcmVjdCBhY2Nlc3MgdG8gdGhlIGFjdHVhbCB3aWR0aCBpbnN0ZWFkIG9mIGRvaW5nIGFwcHJveGltYXRpb24gY2FsY3VsYXRpb24gYmFzZWQgb24gZm9udC1zaXplIChlcnJvciBhcyBoaWdoIGFzIDEvMiBvZiBhY3R1YWwgd2lkdGgpXHJcbiAgICAgICAgICAgIHRpY2tMZW5ndGggPSBNYXRoLm1heChpbml0WUF4aXNMYWJlbFdpZHRoLmF4aXNNYXgsIGluaXRZQXhpc0xhYmVsV2lkdGguYXhpc01pbik7XHJcbiAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgdGlja0xlbmd0aCA9IHRoaXMuX2NoYXJ0U3ZjLnJlcGxhY2VTdHJpbmdXaXRoTnVtYmVyKHRoaXMuY29uZmlnLnlBeGlzLmxhYmVscy5zdHlsZS5mb250U2l6ZSk7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICBsZXQgaW5pdEludGVydmFsOiBudW1iZXIgPSBfaW5pdEluZm8uaW50ZXJ2YWw7XHJcbiAgICAgICAgbGV0IGludGVydmFsOiBudW1iZXIgPSBpbml0SW50ZXJ2YWw7XHJcbiAgICAgICAgbGV0IG5vT2ZUaWNrcyA9IE1hdGgucm91bmQoKHRoaXMuYXhpc01heCArIGludGVydmFsIC0gdGhpcy5heGlzTWluKSAvIGludGVydmFsKTtcclxuXHJcbiAgICAgICAgaWYgKGxlbmd0aCA8IHRpY2tMZW5ndGggfHwgbm9PZlRpY2tzID09PSAwKSByZXR1cm4geyBuZWVkUmVkcmF3OiBmYWxzZSwgaW50ZXJ2YWw6IDAgfTtcclxuXHJcbiAgICAgICAgbGV0IGluaXRMb25nZXJOdW06IG51bWJlciA9IHRoaXMuX2NoYXJ0U3ZjLmdldExvbmdlck51bWJlcih0aGlzLmF4aXNNYXgsIHRoaXMuYXhpc01pbikudG9TdHJpbmcoKS5sZW5ndGg7XHJcblxyXG4gICAgICAgIHdoaWxlICgobGVuZ3RoIC8gbm9PZlRpY2tzKSA8IHRpY2tMZW5ndGggJiYgbm9PZlRpY2tzID4gMikge1xyXG4gICAgICAgICAgICBpbnRlcnZhbCA9IGludGVydmFsICogMjtcclxuICAgICAgICAgICAgdGhpcy5fc2V0QXhpc01heEFuZE1pbihfaW5pdEluZm8ubWF4VmFsdWUsIF9pbml0SW5mby5taW5WYWx1ZSwgaW50ZXJ2YWwpO1xyXG5cclxuICAgICAgICAgICAgLy8gd2hlbiB0aGUgaW50ZXJ2YWwgY2hhbmdlcywgYXhpc01heCBvciBheGlzTWluIGRvZXMgbm90IGNoYW5nZSBzaWduaWZpY2FudGx5IChjaGFuZ2VzIGF0IG1vc3QgMSBkaWdpdHMgcGxhY2UpXHJcbiAgICAgICAgICAgIC8vIGNoZWNrIHRoYXQgdGhlIGN1cnJlbnQgYXhpc01heC9NaW4gaXMgaW5kZWVkIGxvbmdlciB0aGFuIHRoZSBpbml0aWFsIGF4aXNNYXgvTWluXHJcbiAgICAgICAgICAgIGlmICh0aGlzLmJhci5pc0ludmVydCAmJiB0aGlzLl9jaGFydFN2Yy5nZXRMb25nZXJOdW1iZXIodGhpcy5heGlzTWF4LCB0aGlzLmF4aXNNaW4pLnRvU3RyaW5nKCkubGVuZ3RoID4gaW5pdExvbmdlck51bSkge1xyXG4gICAgICAgICAgICAgICAgdGlja0xlbmd0aCA9IHRoaXMuX2NoYXJ0U3ZjLnNldER1bW15QXhpc0xhYmVsKHRoaXMuX2NoYXJ0U3ZjLmdldExvbmdlck51bWJlcih0aGlzLmF4aXNNYXgsIHRoaXMuYXhpc01pbiksICdheGlzTWF4Jyk7XHJcbiAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgIG5vT2ZUaWNrcyA9IE1hdGgucm91bmQoKHRoaXMuYXhpc01heCArIGludGVydmFsIC0gdGhpcy5heGlzTWluKSAvIGludGVydmFsKTtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIC8vIHdoZW4gb3ZlcmxhcCBmaW5pc2hlcywgaW50ZXJ2YWwgYW5kIGF4aXNNYXgvTWluIGlzIGNoYW5nZWQgY29tcGFyZWQgdG8gd2hlbiBnZXRTdmdPZmZzZXQoKVxyXG4gICAgICAgIC8vIGNoZWNrIHRoYXQgY3VycmVudCBpbnRlcnZhbCByZXN1bHRzIGluIHNhbWUgbWF4IGxhYmVsIGxlbmd0aCwgaWYgbm90LCByZWRyYXcgdGhlIGF4aXMgYW5kIHJ1biBnZXRTdmdPZmZzZXQoKSBhZ2FpblxyXG4gICAgICAgIGlmIChpbml0SW50ZXJ2YWwgIT09IGludGVydmFsKSB7XHJcbiAgICAgICAgICAgIHRoaXMuX2NoYXJ0U3ZjLnNldEF4aXNEM0Zvcm1hdChpbnRlcnZhbCk7XHJcbiAgICAgICAgICAgIGxldCBuZXdZQXhpc0xhYmVsV2lkdGg6IElZQXhpc0xhYmVsUmFuZ2UgPSB0aGlzLl9jaGFydFN2Yy5nZXRZQXhpc01heEFuZE1pbkxhYmVsV2lkdGgoeyBheGlzTWluOiB0aGlzLmF4aXNNaW4sIGF4aXNNYXg6IHRoaXMuYXhpc01heCB9KTtcclxuICAgICAgICAgICAgaWYgKG5ld1lBeGlzTGFiZWxXaWR0aC5heGlzTWF4ICE9PSBpbml0WUF4aXNMYWJlbFdpZHRoLmF4aXNNYXggfHwgbmV3WUF4aXNMYWJlbFdpZHRoLmF4aXNNaW4gIT09IGluaXRZQXhpc0xhYmVsV2lkdGguYXhpc01pbikge1xyXG4gICAgICAgICAgICAgICAgcmV0dXJuIHsgbmVlZFJlZHJhdzogdHJ1ZSwgaW50ZXJ2YWw6IGludGVydmFsIH07XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIHJldHVybiB7IG5lZWRSZWRyYXc6IGZhbHNlLCBpbnRlcnZhbDogaW50ZXJ2YWwgfTtcclxuICAgIH1cclxuXHJcbiAgICAvLyA9PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT0gR3JpZCBMaW5lcyA9PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09XHJcblxyXG4gICAgcHJpdmF0ZSBfc2V0R3JpZExpbmVzKCk6IHZvaWQge1xyXG4gICAgICAgIGlmICghdGhpcy5ncmlkTGluZXNDb250YWluZXIpIHRoaXMuZ3JpZExpbmVzQ29udGFpbmVyID0gdGhpcy5ncmFwaC5hcHBlbmQoJ2cnKS5hdHRyKCdjbGFzcycsICdrZHgtY2hhcnRzLWdyaWQtbGluZS1jb250YWluZXInKTtcclxuICAgICAgICB0aGlzLl9jaGFydFN2Yy5ncmlkU3ZjLmdyYXBoRGltZW5zaW9uID0geyB3aWR0aDogdGhpcy53aWR0aCwgaGVpZ2h0OiB0aGlzLmhlaWdodCB9O1xyXG4gICAgICAgIGlmICh0aGlzLl9jaGFydFN2Yy5ncmlkU3ZjLmhhdmVHcmlkKHRoaXMuY29uZmlnLCAneEF4aXMnLCAnZ3JpZExpbmUnKSkgdGhpcy5fc2V0WEF4aXNHcmlkKCk7XHJcbiAgICAgICAgaWYgKHRoaXMuX2NoYXJ0U3ZjLmdyaWRTdmMuaGF2ZUdyaWQodGhpcy5jb25maWcsICd5QXhpcycsICdtaW5vckdyaWRMaW5lJykpIHRoaXMuX3NldFlBeGlzTWlub3JHcmlkKCk7XHJcbiAgICAgICAgaWYgKHRoaXMuX2NoYXJ0U3ZjLmdyaWRTdmMuaGF2ZUdyaWQodGhpcy5jb25maWcsICd5QXhpcycsICdncmlkTGluZScpKSB0aGlzLl9zZXRZQXhpc0dyaWQoKTtcclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF9zZXRYQXhpc0dyaWQoKSB7XHJcbiAgICAgICAgLy8gd3JhcHBlciBmdW5jdGlvbiBhcm91bmQgdGhpcy54IHNvIHRoYXQgZ3JpZCB3aWxsIGJlIGRyYXduIGluIGNlbnRlciBvZiBwYWRkaW5nSW5uZXJcclxuICAgICAgICBsZXQgc2NhbGUgPSB0aGlzLl9jaGFydFN2Yy5ncmlkU3ZjLnhBeGlzR3JpZFNjYWxlKHRoaXMueCk7XHJcbiAgICAgICAgLy8gY29uY2F0IHNwYWNlIHRvIGRyYXcgZmlyc3QgZ3JpZCBsaW5lLCBOb3RlOiB0aGlzLmRhdGEgbWF5IGhhdmUgYmVlbiBzcGxpY2VkIGJ5IHRyaW1YXHJcbiAgICAgICAgbGV0IHhEYXRhOiBBcnJheTxzdHJpbmc+ID0gWycnXS5jb25jYXQodGhpcy5kYXRhLm1hcChkYXRhID0+IGRhdGEueC52YWx1ZSkpO1xyXG4gICAgICAgIC8vIGxldCB4RGF0YTogQXJyYXk8c3RyaW5nPiA9IFsnJ10uY29uY2F0KF9jYXRlZ29yaWVzKTtcclxuICAgICAgICB0aGlzLl9jaGFydFN2Yy5ncmlkU3ZjLmRyYXdHcmlkTGluZSh0aGlzLmdyaWRMaW5lc0NvbnRhaW5lciwgeERhdGEsICd4QXhpcycsICdncmlkTGluZScsIHNjYWxlKTtcclxuICAgIH1cclxuXHJcbiAgICAvLyBkcmF3IG1ham9yIGdyaWQgbGluZVxyXG4gICAgcHJpdmF0ZSBfc2V0WUF4aXNHcmlkKCkge1xyXG4gICAgICAgIHRoaXMuX2NoYXJ0U3ZjLmdyaWRTdmMuZHJhd0dyaWRMaW5lKHRoaXMuZ3JpZExpbmVzQ29udGFpbmVyLCB0aGlzLnRpY2tWYWx1ZXMsICd5QXhpcycsICdncmlkTGluZScsIHRoaXMueSk7XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfc2V0WUF4aXNNaW5vckdyaWQoKSB7XHJcbiAgICAgICAgbGV0IHlBeGlzQ29uZmlnOiBJWUF4aXNDb25maWcgPSB0aGlzLmNvbmZpZy55QXhpcztcclxuICAgICAgICBpZiAoeUF4aXNDb25maWcubWlub3JUaWNrSW50ZXJ2YWwgPj0geUF4aXNDb25maWcudGlja0ludGVydmFsIHx8ICF5QXhpc0NvbmZpZy5taW5vclRpY2tJbnRlcnZhbCkgcmV0dXJuO1xyXG5cclxuICAgICAgICBsZXQgdXBwZXJib3VuZDogbnVtYmVyID0gdGhpcy5fY2hhcnRTdmMuc2V0QXhpc1JvdW5kVmFsdWUodGhpcy5kb21haW5NYXgsIHlBeGlzQ29uZmlnLm1pbm9yVGlja0ludGVydmFsLCBmYWxzZSwgJ3VwJyk7XHJcbiAgICAgICAgbGV0IGxvd2VyYm91bmQ6IG51bWJlciA9IHRoaXMuX2NoYXJ0U3ZjLnNldEF4aXNSb3VuZFZhbHVlKHRoaXMuZG9tYWluTWluLCB5QXhpc0NvbmZpZy5taW5vclRpY2tJbnRlcnZhbCwgZmFsc2UsICdkb3duJyk7XHJcbiAgICAgICAgbGV0IG1pbm9yVGlja1ZhbHVlczogQXJyYXk8bnVtYmVyPiA9IHRoaXMuX2NoYXJ0U3ZjLmdldFRpY2tWYWx1ZXMobG93ZXJib3VuZCwgdXBwZXJib3VuZCwgeUF4aXNDb25maWcubWlub3JUaWNrSW50ZXJ2YWwpO1xyXG5cclxuICAgICAgICB0aGlzLl9jaGFydFN2Yy5ncmlkU3ZjLmRyYXdHcmlkTGluZSh0aGlzLmdyaWRMaW5lc0NvbnRhaW5lciwgbWlub3JUaWNrVmFsdWVzLCAneUF4aXMnLCAnbWlub3JHcmlkTGluZScsIHRoaXMueSk7XHJcbiAgICB9XHJcblxyXG4gICAgLy8gPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09IEF4aXMgPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PVxyXG5cclxuICAgIHB1YmxpYyBzZXRBeGlzKCk6IHZvaWQge1xyXG4gICAgICAgIGxldCB0cmFuc2Zvcm1Qb3M6IElBeGlzVHJhbnNmb3JtUG9zID0ge1xyXG4gICAgICAgICAgICByaWdodDogJ3RyYW5zbGF0ZSgnICsgdGhpcy53aWR0aCArICcsMCknLFxyXG4gICAgICAgICAgICBsZWZ0OiAndHJhbnNsYXRlKDAsMCknLFxyXG4gICAgICAgICAgICB0b3A6ICd0cmFuc2xhdGUoMCwwKScsXHJcbiAgICAgICAgICAgIGJvdHRvbTogJ3RyYW5zbGF0ZSgwLCcgKyB0aGlzLmhlaWdodCArICcpJ1xyXG4gICAgICAgIH07XHJcblxyXG4gICAgICAgIGxldCB4QXhpc0NvbmZpZzogSVhBeGlzQ29uZmlnID0gdGhpcy5jb25maWcueEF4aXM7XHJcbiAgICAgICAgbGV0IHlBeGlzQ29uZmlnOiBJWUF4aXNDb25maWcgPSB0aGlzLmNvbmZpZy55QXhpcztcclxuICAgICAgICBsZXQgaW52ZXJ0OiBib29sZWFuID0gdGhpcy5iYXIuaXNJbnZlcnQ7XHJcbiAgICAgICAgbGV0IG9wcG9zaXRlOiB7IHg6IGJvb2xlYW4sIHk6IGJvb2xlYW4gfSA9IHtcclxuICAgICAgICAgICAgeDogaW52ZXJ0ID8geEF4aXNDb25maWcub3Bwb3NpdGUgIT09IHRoaXMuaXNSdGwgOiB4QXhpc0NvbmZpZy5vcHBvc2l0ZSxcclxuICAgICAgICAgICAgeTogaW52ZXJ0ID8geUF4aXNDb25maWcub3Bwb3NpdGUgOiB5QXhpc0NvbmZpZy5vcHBvc2l0ZSAhPT0gdGhpcy5pc1J0bFxyXG4gICAgICAgIH07XHJcblxyXG4gICAgICAgIGxldCB4QXhpcyA9IHRoaXMuX2dldEVhY2hBeGlzRnVuYygneCcsIG9wcG9zaXRlLngsIGludmVydCk7XHJcbiAgICAgICAgdGhpcy54QXhpc0Fyci5wdXNoKHhBeGlzKTtcclxuICAgICAgICB0aGlzLnlBeGlzID0gdGhpcy5fZ2V0RWFjaEF4aXNGdW5jKCd5Jywgb3Bwb3NpdGUueSwgaW52ZXJ0KTtcclxuXHJcbiAgICAgICAgeEF4aXMuYXR0cigndHJhbnNmb3JtJywgdGhpcy5fY2hhcnRTdmMuZ2V0QXhpc1RyYW5zZm9ybVBvcygneCcsIG9wcG9zaXRlLngsIHRyYW5zZm9ybVBvcykpO1xyXG4gICAgICAgIHRoaXMueUF4aXMuYXR0cigndHJhbnNmb3JtJywgdGhpcy5fY2hhcnRTdmMuZ2V0QXhpc1RyYW5zZm9ybVBvcygneScsIG9wcG9zaXRlLnksIHRyYW5zZm9ybVBvcykpO1xyXG5cclxuICAgICAgICB0aGlzLl9jaGFydFN2Yy5zZXRBeGlzTGFiZWxDb25maWcoeEF4aXMsICd4Jyk7XHJcbiAgICAgICAgdGhpcy5fY2hhcnRTdmMuc2V0QXhpc0xhYmVsQ29uZmlnKHRoaXMueUF4aXMsICd5Jyk7XHJcblxyXG4gICAgICAgIGlmICh0aGlzLl9jaGFydFN2Yy5pc05lZ2F0aXZlU3RhY2spIHtcclxuICAgICAgICAgICAgbGV0IHNlY29uZFhBeGlzID0gdGhpcy5fZ2V0RWFjaEF4aXNGdW5jKCd4JywgIW9wcG9zaXRlLngsIHRoaXMuYmFyLmlzSW52ZXJ0KTtcclxuICAgICAgICAgICAgc2Vjb25kWEF4aXMuYXR0cigndHJhbnNmb3JtJywgdGhpcy5fY2hhcnRTdmMuZ2V0QXhpc1RyYW5zZm9ybVBvcygneCcsICFvcHBvc2l0ZS54LCB0cmFuc2Zvcm1Qb3MpKTtcclxuICAgICAgICAgICAgdGhpcy5fY2hhcnRTdmMuc2V0QXhpc0xhYmVsQ29uZmlnKHNlY29uZFhBeGlzLCAneCcpO1xyXG4gICAgICAgICAgICB0aGlzLnhBeGlzQXJyLnB1c2goc2Vjb25kWEF4aXMpO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF9nZXRFYWNoQXhpc0Z1bmMoX2F4aXM6ICd4JyB8ICd5JywgX29wcG9zaXRlOiBib29sZWFuLCBfaW52ZXJ0OiBib29sZWFuKTogYW55IHtcclxuICAgICAgICBsZXQgYXhpc0Z1bmMgPSBnZXRBeGlzRnVuYyhfYXhpcywgdGhpc1tfYXhpc10pO1xyXG4gICAgICAgIGxldCBheGlzQ2xhc3M6IHN0cmluZyA9ICdrZHgtY2hhcnRzLWF4aXMgYXhpcy0nICsgX2F4aXM7XHJcblxyXG4gICAgICAgIGlmICgoX2ludmVydCAmJiBfYXhpcyA9PT0gJ3gnKSB8fCAoIV9pbnZlcnQgJiYgX2F4aXMgPT09ICd5JykpIHtcclxuICAgICAgICAgICAgYXhpc0NsYXNzICs9ICcga2R4LWNoYXJ0cy1heGlzLXZlcnRpY2FsJztcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIGlmIChfb3Bwb3NpdGUpIGF4aXNDbGFzcyArPSAnIGtkeC1jaGFydHMtYXhpcy1vcHBvc2l0ZSc7XHJcblxyXG4gICAgICAgIGlmIChfYXhpcyA9PT0gJ3knKSB7XHJcbiAgICAgICAgICAgIGF4aXNGdW5jXHJcbiAgICAgICAgICAgICAgICAudGlja1ZhbHVlcyh0aGlzLnRpY2tWYWx1ZXMpXHJcbiAgICAgICAgICAgICAgICAudGlja0Zvcm1hdCgoZCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgIC8vIG5vdGU6IG9ubHkgdXNlY2FzZSBpcyBuZWdhdGl2ZSBzdGFjayBiYXIgKGluIHYzLjcuMCkuIHdpbGwgYWZmZWN0IGJvdGggeUF4aXMgbGFiZWwgYW5kIHRvb2x0aXAgYW5kIGRhdGFMYWJlbHNcclxuICAgICAgICAgICAgICAgICAgICBsZXQgdmFsdWUgPSB0aGlzLl9jaGFydFN2Yy5jaGVja0FuZFJldHVybkxhYmVsc1Bvc2l0aXZlKGQpO1xyXG4gICAgICAgICAgICAgICAgICAgIHJldHVybiB0aGlzLl9jaGFydFN2Yy5nZXRZQXhpc0xhYmVsVGV4dCh0aGlzLmNvbmZpZy55QXhpcywgdmFsdWUpO1xyXG4gICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICBsZXQgYXhpc0VsZW0gPSB0aGlzLmdyYXBoLmFwcGVuZCgnZycpLmF0dHIoJ2NsYXNzJywgYXhpc0NsYXNzKS5jYWxsKGF4aXNGdW5jKTtcclxuXHJcbiAgICAgICAgcmV0dXJuIGF4aXNFbGVtO1xyXG5cclxuICAgICAgICBmdW5jdGlvbiBnZXRBeGlzRnVuYyhfdHlwZTogJ3gnIHwgJ3knLCBfc2NhbGUpOiBhbnkge1xyXG4gICAgICAgICAgICBpZiAoX2ludmVydCkge1xyXG4gICAgICAgICAgICAgICAgaWYgKF90eXBlID09PSAneCcpIHtcclxuICAgICAgICAgICAgICAgICAgICBpZiAoX29wcG9zaXRlKSByZXR1cm4gZDMuYXhpc1JpZ2h0KF9zY2FsZSk7XHJcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIGQzLmF4aXNMZWZ0KF9zY2FsZSk7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICBpZiAoX3R5cGUgPT09ICd5Jykge1xyXG4gICAgICAgICAgICAgICAgICAgIGlmIChfb3Bwb3NpdGUpIHJldHVybiBkMy5heGlzVG9wKF9zY2FsZSk7XHJcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIGQzLmF4aXNCb3R0b20oX3NjYWxlKTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgICAgIGlmIChfdHlwZSA9PT0gJ3gnKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKF9vcHBvc2l0ZSkgcmV0dXJuIGQzLmF4aXNUb3AoX3NjYWxlKTtcclxuICAgICAgICAgICAgICAgICAgICByZXR1cm4gZDMuYXhpc0JvdHRvbShfc2NhbGUpO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgaWYgKF90eXBlID09PSAneScpIHtcclxuICAgICAgICAgICAgICAgICAgICBpZiAoX29wcG9zaXRlKSByZXR1cm4gZDMuYXhpc1JpZ2h0KF9zY2FsZSk7XHJcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIGQzLmF4aXNMZWZ0KF9zY2FsZSk7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcblxyXG4gICAgfVxyXG5cclxuICAgIC8vID09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PSBSZW1vdmUgQ2hhcnQgPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PVxyXG5cclxuICAgIHB1YmxpYyBjaGFydFRpbWVvdXQoX2NhbGxiYWNrOiBGdW5jdGlvbik6IHZvaWQge1xyXG4gICAgICAgIC8vIGxldCBkZWxheSA9IHRoaXMuY29uZmlnLmxlZ2VuZC5lbmFibGVkICYmIHRoaXMuY2hhcnRDYXRlZ29yeSA9PT0gJ3BpZSc/IDUwMCA6IDEwO1xyXG4gICAgICAgIGNsZWFyVGltZW91dCh0aGlzLl9zZXRDaGFydFRpbWVvdXQpO1xyXG4gICAgICAgIHRoaXMuX3NldENoYXJ0VGltZW91dCA9IHNldFRpbWVvdXQoKCk6IHZvaWQgPT4ge1xyXG4gICAgICAgICAgICBfY2FsbGJhY2soKTtcclxuICAgICAgICB9KTtcclxuICAgIH1cclxuXHJcblxyXG4gICAgcHVibGljIHJlbW92ZUNoYXJ0KCk6IHZvaWQge1xyXG4gICAgICAgIGNsZWFyVGltZW91dCh0aGlzLl9zZXRDaGFydFRpbWVvdXQpO1xyXG4gICAgICAgIHRoaXMuX3JlbW92ZUVsZW1JbkFycmF5Rm9ybSgneEF4aXNBcnInLCAoYXhpcykgPT4gYXhpcy5yZW1vdmUoKSk7XHJcbiAgICAgICAgaWYgKHRoaXMueUF4aXMpIHRoaXMueUF4aXMucmVtb3ZlKCk7XHJcbiAgICAgICAgaWYgKHRoaXMuZGF0YUxhYmVsQ29udGFpbmVyKSB0aGlzLmRhdGFMYWJlbENvbnRhaW5lci5zZWxlY3RBbGwoJyonKS5yZW1vdmUoKTtcclxuICAgICAgICB0aGlzLl9yZW1vdmVFbGVtSW5BcnJheUZvcm0oJ2F4aXNMYWJlbENvbnRhaW5lckFycicsIChjb250YWluZXIpID0+IGNvbnRhaW5lci5zZWxlY3RBbGwoJyonKS5yZW1vdmUoKSk7XHJcbiAgICAgICAgaWYgKHRoaXMuZ3JpZExpbmVzQ29udGFpbmVyKSB0aGlzLmdyaWRMaW5lc0NvbnRhaW5lci5zZWxlY3RBbGwoJyonKS5yZW1vdmUoKTtcclxuICAgICAgICB0aGlzLl9jbGVhclN2Z0RpbWVuc2lvbigpO1xyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX3JlbW92ZUVsZW1JbkFycmF5Rm9ybShfa2V5OiBzdHJpbmcsIGNhbGxiYWNrOiBGdW5jdGlvbik6IHZvaWQge1xyXG4gICAgICAgIGlmICh0aGlzW19rZXldLmxlbmd0aCAhPT0gMCkge1xyXG4gICAgICAgICAgICB0aGlzW19rZXldLmZvckVhY2goZWxlbWVudCA9PiBjYWxsYmFjayhlbGVtZW50KSk7XHJcbiAgICAgICAgICAgIHRoaXNbX2tleV0gPSBbXTtcclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgLy8gPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09IEF4aXMgTGFiZWwgPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PVxyXG5cclxuICAgIHByaXZhdGUgX3NldFhBeGlzTGFiZWwoX3hTY2FsZVR5cGU6ICdzdHJpbmcnIHwgJ2JhbmQnLCBfbG9uZ2VzdFRleHQ6IHN0cmluZyk6IHZvaWQge1xyXG4gICAgICAgIGlmICghdGhpcy5jb25maWcueEF4aXMuZW5hYmxlZCB8fCAhdGhpcy5jb25maWcueEF4aXMubGFiZWxzLmVuYWJsZWQpIHJldHVybjtcclxuXHJcbiAgICAgICAgaWYgKHRoaXMuYXhpc0xhYmVsQ29udGFpbmVyQXJyLmxlbmd0aCAhPT0gMCkge1xyXG4gICAgICAgICAgICB0aGlzLl9yZW1vdmVFbGVtSW5BcnJheUZvcm0oJ2F4aXNMYWJlbENvbnRhaW5lckFycicsIChjb250YWluZXIpID0+IGNvbnRhaW5lci5zZWxlY3RBbGwoJyonKS5yZW1vdmUoKSk7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICBsZXQgeFNwYWNpbmc6IG51bWJlciA9IHRoaXMuX2NhbGN1bGF0ZVhTcGFjaW5nKF94U2NhbGVUeXBlKTtcclxuXHJcbiAgICAgICAgdGhpcy5fY2hhcnRTdmMuc2V0QXhpc0xhYmVsRHVtbXkodGhpcy5jb25maWcuaWQsIHhTcGFjaW5nLCBfbG9uZ2VzdFRleHQpO1xyXG4gICAgICAgIHRoaXMuX2NoYXJ0U3ZjLl9zZXRBeGlzTGFiZWxMZW5ndGgoKTtcclxuXHJcbiAgICAgICAgdGhpcy5fc2V0QXhpc0xhYmVsQ29udGFpbmVyKCk7XHJcblxyXG4gICAgICAgIGlmICh0aGlzLl9jaGFydFN2Yy5sYWJlbExlbmd0aCAhPT0gMCkgdGhpcy5fdHJpbVgoX3hTY2FsZVR5cGUpO1xyXG5cclxuICAgICAgICB0aGlzLmF4aXNMYWJlbENvbnRhaW5lckFyci5mb3JFYWNoKChfYXhpc0xhYmVsQ29udGFpbmVyLCBpbmRleCkgPT4ge1xyXG4gICAgICAgICAgICB0aGlzLl9jaGFydFN2Yy5zZXRBeGlzTGFiZWxDb250YWluZXJTdHlsZShfYXhpc0xhYmVsQ29udGFpbmVyKTtcclxuICAgICAgICAgICAgLy8gaWYgZHJhd2luZyAybmQgYXhpcywgc2V0IHRvIGNvbXBsZW1lbnQgb2Ygb3Bwb3NpdGUgb2YgMXN0IGF4aXNcclxuICAgICAgICAgICAgaWYgKHRoaXMuX2NoYXJ0U3ZjLmxhYmVsTGVuZ3RoICE9PSAwKSB7XHJcbiAgICAgICAgICAgICAgICBsZXQgb3Bwb3NpdGUgPSBpbmRleCA9PT0gMSA/ICF0aGlzLmNvbmZpZy54QXhpcy5vcHBvc2l0ZSA6IHRoaXMuY29uZmlnLnhBeGlzLm9wcG9zaXRlO1xyXG4gICAgICAgICAgICAgICAgdGhpcy5fZHJhd0F4aXNMYWJlbChcclxuICAgICAgICAgICAgICAgICAgICBfYXhpc0xhYmVsQ29udGFpbmVyLFxyXG4gICAgICAgICAgICAgICAgICAgIHsgbGFiZWxIZWlnaHQ6IHRoaXMuX2NoYXJ0U3ZjLmxhYmVsTGVuZ3RoLCBsYWJlbFdpZHRoOiB4U3BhY2luZyB9LFxyXG4gICAgICAgICAgICAgICAgICAgIHsgaXNSb3RhdGU6IHRoaXMuX2NoYXJ0U3ZjLmlzUm90YXRlLCBvcHBvc2l0ZTogb3Bwb3NpdGUgfVxyXG4gICAgICAgICAgICAgICAgKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH0pO1xyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX3NldEF4aXNMYWJlbENvbnRhaW5lcigpOiB2b2lkIHtcclxuICAgICAgICB0aGlzLmF4aXNMYWJlbENvbnRhaW5lckFyci5wdXNoKHRoaXMuX2NoYXJ0U3ZjLnNldEF4aXNMYWJlbENvbnRhaW5lcigpKTtcclxuXHJcbiAgICAgICAgLy8gcmVuZGVyIDJuZCBheGlzXHJcbiAgICAgICAgaWYgKHRoaXMuX2NoYXJ0U3ZjLmlzTmVnYXRpdmVTdGFjaykge1xyXG4gICAgICAgICAgICB0aGlzLmF4aXNMYWJlbENvbnRhaW5lckFyci5wdXNoKHRoaXMuX2NoYXJ0U3ZjLnNldEF4aXNMYWJlbENvbnRhaW5lcignLmtkeC1jaGFydHMtZG91YmxlLWF4aXMteCcpKTtcclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfY2FsY3VsYXRlWFNwYWNpbmcoX3hTY2FsZVR5cGU6ICdzdHJpbmcnIHwgJ2JhbmQnKTogbnVtYmVyIHtcclxuICAgICAgICByZXR1cm4gKF94U2NhbGVUeXBlID09PSAnYmFuZCcpID8gdGhpcy54LmJhbmR3aWR0aCgpICsgdGhpcy54LnBhZGRpbmdJbm5lcigpICogdGhpcy54LnN0ZXAoKSA6IHRoaXMud2lkdGggLyAodGhpcy5kYXRhLmxlbmd0aCAtIDEpO1xyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX3RyaW1YKF94U2NhbGVUeXBlOiAnc3RyaW5nJyB8ICdiYW5kJyk6IHZvaWQge1xyXG4gICAgICAgIGxldCBtYXhOb09mWDogbnVtYmVyID0gdGhpcy5fY2FsY3VsYXRlTWF4Tm9PZlgodGhpcy5fY2hhcnRTdmMuaXNSb3RhdGUsIF94U2NhbGVUeXBlKTtcclxuXHJcbiAgICAgICAgaWYgKG1heE5vT2ZYID09PSB0aGlzLmluaXREYXRhLmxlbmd0aCkgcmV0dXJuO1xyXG5cclxuICAgICAgICAvLyBpZiB0aGUgaW5pdGFsIGRhdGEgY2Fubm90IGZpdCBpbnRvIG1heFNwYWNlLCBzbGljZSBhbmQgc2F2ZSB0byB0aGlzLmRhdGFcclxuICAgICAgICB0aGlzLmRhdGEgPSB0aGlzLmluaXREYXRhLnNsaWNlKDAsIG1heE5vT2ZYKTtcclxuICAgICAgICBsZXQgeEluZm86IElYSW5mbyA9IHRoaXMuX2NoYXJ0U3ZjLmdldFhJbmZvKHRoaXMuZGF0YSwgdGhpcy5jb25maWcpO1xyXG5cclxuICAgICAgICAvLyB1cGRhdGUgZG9tYWluIHdpdGggdGhlIHVwZGF0ZWQgdGhpcy5kYXRhXHJcbiAgICAgICAgaWYgKHRoaXMuY2hhcnRDYXRlZ29yeSA9PT0gJ2xpbmUnKSB0aGlzLl9zZXRMaW5lU2NhbGVYKF94U2NhbGVUeXBlKTtcclxuICAgICAgICB0aGlzLnguZG9tYWluKHhJbmZvLnZhbHVlKTtcclxuXHJcbiAgICAgICAgLy8gYWZ0ZXIgdHJpbW1pbmcsIHRoZSBsb25nZXN0IGF4aXMgbGFiZWwgbWF5IG5vdCBiZSBzYW1lLiBoZW5jZSByZWNhbGN1bGF0ZSB0aGUgYXhpcyBsYWJlbCBjb250YWluZXIgaGVpZ2h0XHJcbiAgICAgICAgdGhpcy5fY2hhcnRTdmMuc2V0QXhpc0xhYmVsRHVtbXlUZXh0KHhJbmZvLmxvbmdlc3RUZXh0KTtcclxuICAgICAgICB0aGlzLl9jaGFydFN2Yy5fc2V0QXhpc0xhYmVsTGVuZ3RoKCk7XHJcbiAgICB9XHJcblxyXG4gICAgLy8gdGhpcy5kYXRhIHdpbGwgYmUgY2hhbmdlZC90cmltZWQgYWNjb3JkaW5nIHRvIHNwYWNlIGdpdmVuXHJcbiAgICBwcml2YXRlIF9jYWxjdWxhdGVNYXhOb09mWChfaXNSb3RhdGU6IGJvb2xlYW4sIF94U2NhbGVUeXBlOiAnc3RyaW5nJyB8ICdiYW5kJyk6IG51bWJlciB7XHJcbiAgICAgICAgaWYgKCFfaXNSb3RhdGUgJiYgIXRoaXMuYmFyLmlzSW52ZXJ0KSByZXR1cm4gdGhpcy5pbml0RGF0YS5sZW5ndGg7XHJcblxyXG4gICAgICAgIGxldCBvZmZzZXQ6IG51bWJlciA9IHRoaXMuY2hhcnRDYXRlZ29yeSA9PT0gJ2JhcicgPyAodGhpcy54LnBhZGRpbmdPdXRlcigpKSAqIDIgOiAwO1xyXG4gICAgICAgIGxldCBtYXhTcGFjZTogbnVtYmVyID0gKHRoaXMuYmFyLmlzSW52ZXJ0ID8gdGhpcy5oZWlnaHQgOiB0aGlzLndpZHRoKSAtIG9mZnNldDtcclxuICAgICAgICAvLyBub3RlOiB3aGVuIHJvdGF0aW5nIG9yIHdoZW4gY2hhcnRUeXBlID09ICdiYXInLCBheGlzTEFiZWxEdW1teSB3aWxsIG5vdCB0ZXh0LXdyYXBcclxuICAgICAgICBsZXQgZWFjaEl0ZW1TaXplOiBudW1iZXIgPSB0aGlzLl9jaGFydFN2Yy5nZXRBeGlzTGFiZWxEdW1teVJlY3QoKS5oZWlnaHQ7XHJcbiAgICAgICAgbGV0IG1heE5vT2ZYOiBudW1iZXIgPSBNYXRoLmZsb29yKG1heFNwYWNlIC8gZWFjaEl0ZW1TaXplKTtcclxuXHJcbiAgICAgICAgaWYgKF94U2NhbGVUeXBlID09PSAnc3RyaW5nJykgbWF4Tm9PZlggKz0gMTtcclxuXHJcbiAgICAgICAgcmV0dXJuIE1hdGgubWluKHRoaXMuaW5pdERhdGEubGVuZ3RoLCBtYXhOb09mWCk7XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfZHJhd0F4aXNMYWJlbChfY29udGFpbmVyOiBhbnksIF9sYWJlbERpbWVuc3Rpb246IHsgbGFiZWxIZWlnaHQ6IG51bWJlciwgbGFiZWxXaWR0aDogbnVtYmVyIH0sIF9ib29sZWFuQ2hlY2tzOiBJQXhpc0xhYmVsQm9vbGVhbkNoZWNrcyk6IHZvaWQge1xyXG4gICAgICAgIGxldCBmaXJzdFRpY2s6IG51bWJlciA9IDAsIHhBeGlzTGFiZWxDb25maWcgPSB0aGlzLmNvbmZpZy54QXhpcy5sYWJlbHM7XHJcbiAgICAgICAgaWYgKHRoaXMuY2hhcnRDYXRlZ29yeSA9PT0gJ2JhcicpIGZpcnN0VGljayA9IHRoaXMueC5wYWRkaW5nT3V0ZXIoKSAqIHRoaXMueC5zdGVwKCkgKyB0aGlzLnguYmFuZHdpZHRoKCkgLyAyO1xyXG5cclxuICAgICAgICB0aGlzLmRhdGEuZm9yRWFjaCgoZCwgeEluZGV4KSA9PiB7XHJcbiAgICAgICAgICAgIGxldCBsYWJlbENvbnRhaW5lcjogYW55LCB0aWNrUG9zOiBudW1iZXI7XHJcbiAgICAgICAgICAgIGxhYmVsQ29udGFpbmVyID0gX2NvbnRhaW5lci5hcHBlbmQoJ2RpdicpXHJcbiAgICAgICAgICAgICAgICAuYXR0cignY2xhc3MnLCAna2R4LWNoYXJ0cy1heGlzLWxhYmVsIHgtJyArIHhJbmRleClcclxuICAgICAgICAgICAgICAgIC5odG1sKHRoaXMuX2NoYXJ0U3ZjLmdldExhYmVsRm9ybWF0UmVwbGFjZSh4QXhpc0xhYmVsQ29uZmlnLmZvcm1hdCwgZC54LmxhYmVsKSk7XHJcblxyXG4gICAgICAgICAgICBpZiAoX2Jvb2xlYW5DaGVja3MuaXNSb3RhdGUpIHtcclxuICAgICAgICAgICAgICAgIGxhYmVsQ29udGFpbmVyLnN0eWxlKCdtYXgtd2lkdGgnLCBfbGFiZWxEaW1lbnN0aW9uLmxhYmVsSGVpZ2h0ICsgJ3B4Jyk7XHJcbiAgICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgICAgICBpZiAoIXRoaXMuYmFyLmlzSW52ZXJ0KSBsYWJlbENvbnRhaW5lci5zdHlsZSgnbWF4LXdpZHRoJywgX2xhYmVsRGltZW5zdGlvbi5sYWJlbFdpZHRoICsgJ3B4Jyk7XHJcbiAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgIGlmICh0aGlzLmNoYXJ0Q2F0ZWdvcnkgPT09ICdiYXInKSB7XHJcbiAgICAgICAgICAgICAgICBsZXQgb3JkZXJGcm9tTGVmdCA9IHRoaXMuX2NoYXJ0U3ZjLmlzWFJldmVyc2VkID8gdGhpcy5kYXRhLmxlbmd0aCAtIHhJbmRleCAtIDEgOiB4SW5kZXg7XHJcbiAgICAgICAgICAgICAgICB0aWNrUG9zID0gZmlyc3RUaWNrICsgdGhpcy54LnN0ZXAoKSAqIG9yZGVyRnJvbUxlZnQ7XHJcbiAgICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgICAgICB0aWNrUG9zID0gdGhpcy5yYW5nZUxpc3RbdGhpcy5kYXRhW3hJbmRleF0ueC52YWx1ZV07XHJcbiAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgIHRoaXMuX2NoYXJ0U3ZjLnNldEF4aXNMYWJlbFBvc2l0aW9uKGxhYmVsQ29udGFpbmVyLCB0aWNrUG9zLCBPYmplY3QuYXNzaWduKF9ib29sZWFuQ2hlY2tzLCB7IGlzTGFzdDogeEluZGV4ID09PSB0aGlzLmRhdGEubGVuZ3RoIC0gMSB9KSk7XHJcbiAgICAgICAgfSk7XHJcbiAgICB9XHJcblxyXG4gICAgLy8gPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09IENhcHR1cmUgSG92ZXIgRXZlbnQgPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PVxyXG5cclxuICAgIC8qKlxyXG4gICAgICogX3BhcmFtcyBjYW4gYmUgSUQzRGF0YURhdGEgb3IgY2FuIGNvbnRhaW4gY2FsbGJhY2tzXHJcbiAgICAgKiB7XHJcbiAgICAgKiAgICAgLi4uXHJcbiAgICAgKiAgICAgY2FsbGJhY2tzOiB7XHJcbiAgICAgKiAgICAgICAgICdtb3VzZW92ZXInOiBGdW5jdGlvbixcclxuICAgICAqICAgICAgICAgJ21vdXNlb3V0JzogRnVuY3Rpb25cclxuICAgICAqICAgICB9XHJcbiAgICAgKiB9XHJcbiAgICAgKi9cclxuXHJcbiAgICBwdWJsaWMgX2luaXRNb3VzZUV2ZW50cyhfcGF0aDogYW55LCBfcGFyYW1zPzogYW55KTogdm9pZCB7ICAgICAgIFxyXG4gICAgICAgbGV0IG1hcENvbmRpdGlvbjogYm9vbGVhbiA9ICh0aGlzLmNoYXJ0VHlwZVswXSA9PT0gJ21hcCcgJiYgKHRoaXMuY2hhcnRUeXBlWzFdID09PSAnZnVsbCcgfHwgdGhpcy5jaGFydFR5cGVbMV0gPT09ICdmaWx0ZXInKSk7XHJcbiAgICAgICAgaWYgKCF0aGlzLmNvbmZpZy50b29sdGlwLmVuYWJsZWQpIHJldHVybjtcclxuXHJcbiAgICAgICAgbGV0IHRvb2x0aXA6IGFueTtcclxuICAgICAgICBfcGF0aC5vbignbW91c2VvdmVyJywgKGQsIGluZGV4KSA9PiB7XHJcbiAgICAgICAgICAgIGxldCB0b3A6IG51bWJlciA9IG1hcENvbmRpdGlvbiA/IHBhcnNlSW50KF9wYXJhbXMuZnVsbEdyYXBoLm5vZGUoKS5zdHlsZS50b3ApICsgZDMuZXZlbnQubGF5ZXJZIDogZDMuZXZlbnQubGF5ZXJZO1xyXG4gICAgICAgICAgICBsZXQgbGVmdDogbnVtYmVyID0gbWFwQ29uZGl0aW9uID8gcGFyc2VJbnQoX3BhcmFtcy5mdWxsR3JhcGgubm9kZSgpLnN0eWxlLmxlZnQpICsgZDMuZXZlbnQubGF5ZXJYIDogZDMuZXZlbnQubGF5ZXJYO1xyXG4gICAgICAgICAgICBsZXQgZ3JhcGhQb2ludGVyOiBhbnkgPSAobWFwQ29uZGl0aW9uICYmIF9wYXJhbXMudG9vbHRpcExheWVyKSA/IF9wYXJhbXMudG9vbHRpcExheWVyIDogdGhpcy5zdmdQYXJlbnQ7XHJcbiAgICAgICAgICAgIHRvb2x0aXAgPSBncmFwaFBvaW50ZXIuc2VsZWN0KCcua2R4LWNoYXJ0cy10b29sdGlwJyk7XHJcblxyXG4gICAgICAgICAgICAvLyBpZiB0b29sdGlwIGFscmVhZHkgZXhpc3QgKGluIGNhc2UgbW91c2VvdXQgZGlkIG5vdCBoYXBwZW4pLCBkb24ndCBhcHBlbmQgYW55bW9yZS5cclxuICAgICAgICAgICAgaWYgKHRvb2x0aXAuZW1wdHkoKSkge1xyXG4gICAgICAgICAgICAgICAgdG9vbHRpcCA9IGdyYXBoUG9pbnRlci5hcHBlbmQoJ2RpdicpLmF0dHIoJ2NsYXNzJywgJ2tkeC1jaGFydHMtdG9vbHRpcCcpO1xyXG4gICAgICAgICAgICAgICAgdG9vbHRpcC5hcHBlbmQoJ2RpdicpLmF0dHIoJ2NsYXNzJywgJ2tkeC1jaGFydHMtdG9vbHRpcC1sYWJlbCcpO1xyXG4gICAgICAgICAgICAgICAgdG9vbHRpcC5hcHBlbmQoJ2RpdicpLmF0dHIoJ2NsYXNzJywgJ2tkeC1jaGFydHMtdG9vbHRpcC1jb3VudCcpO1xyXG4gICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICBsZXQgbGFiZWw6IHN0cmluZztcclxuICAgICAgICAgICAgbGV0IGNvdW50OiBudW1iZXIgfCBzdHJpbmc7XHJcbiAgICAgICAgICAgIC8vIGxldCBjb25maWc6IElDaGFydENvbmZpZyA9IHRoaXMuX2NoYXJ0U3ZjLmNvbmZpZztcclxuICAgICAgICAgICAgbGV0IHZhbHVlOiBudW1iZXI7XHJcblxyXG4gICAgICAgICAgICBpZiAodGhpcy5jaGFydFR5cGUgJiYgKHRoaXMuY2hhcnRUeXBlWzBdID09PSAncGllJyB8fCB0aGlzLmNoYXJ0VHlwZVswXSA9PT0gJ2RvbnV0JykpIHtcclxuICAgICAgICAgICAgICAgIGxhYmVsID0gZC5kYXRhLngucmVwbGFjZSgvwqwvZywgJyAnKTtcclxuICAgICAgICAgICAgICAgIGNvdW50ID0gZC5kYXRhLnk7XHJcbiAgICAgICAgICAgICAgICBfcGFyYW1zLnBhdGhBbmltKGQzLnNlbGVjdChfcGF0aC5fZ3JvdXBzWzBdW2luZGV4XSksIHRydWUsIF9wYXJhbXMuaW5uZXJSYWRpdXMsIF9wYXJhbXMub3V0ZXJSYWRpdXMpO1xyXG4gICAgICAgICAgICAgICAgZDMuc2VsZWN0KF9wYXRoLl9ncm91cHNbMF1baW5kZXhdKS5zdHlsZSgnb3BhY2l0eScsICcwLjcnKTtcclxuICAgICAgICAgICAgfSBlbHNlIGlmICh0aGlzLmNoYXJ0VHlwZSAmJiB0aGlzLmNoYXJ0VHlwZVswXSA9PT0gJ3JhZGlhbCcpIHtcclxuICAgICAgICAgICAgICAgIGxhYmVsID0gZC54LnJlcGxhY2UoL8KsL2csICcgJyk7XHJcbiAgICAgICAgICAgICAgICBjb3VudCA9IGQueTtcclxuICAgICAgICAgICAgICAgIGQzLnNlbGVjdChfcGF0aC5fZ3JvdXBzWzBdW2luZGV4XSkuc3R5bGUoJ29wYWNpdHknLCAnMC43Jyk7XHJcbiAgICAgICAgICAgIH0gZWxzZSBpZiAodGhpcy5jaGFydENhdGVnb3J5ID09PSAnYmFyJykge1xyXG4gICAgICAgICAgICAgICAgbGFiZWwgPSBfcGFyYW1zLmRhdGEueC5sYWJlbDtcclxuICAgICAgICAgICAgICAgIGNvdW50ID0gdGhpcy5fY2hhcnRTdmMuY2hlY2tBbmRSZXR1cm5MYWJlbHNQb3NpdGl2ZShkLnZhbHVlIHx8IDApO1xyXG4gICAgICAgICAgICAgICAgbGFiZWwgPSBsYWJlbC50b1N0cmluZygpICsgJyAnICsgdGhpcy5sZWdlbmREYXRhW2QuaWRdLm5hbWU7XHJcbiAgICAgICAgICAgICAgICBkMy5zZWxlY3QoX3BhdGguX2dyb3Vwc1swXVtpbmRleF0pLnN0eWxlKCdvcGFjaXR5JywgJzAuNycpO1xyXG4gICAgICAgICAgICB9IGVsc2UgaWYgKHRoaXMuY2hhcnRDYXRlZ29yeSA9PT0gJ2xpbmUnKSB7XHJcbiAgICAgICAgICAgICAgICBsYWJlbCA9IF9wYXJhbXMuZGF0YS54LmxhYmVsO1xyXG4gICAgICAgICAgICAgICAgY291bnQgPSBfcGFyYW1zLmRhdGEueVtpbmRleF0udmFsdWU7XHJcbiAgICAgICAgICAgICAgICBsYWJlbCA9IGxhYmVsLnRvU3RyaW5nKCkgKyAnICcgKyB0aGlzLmxlZ2VuZERhdGFbZF0ubmFtZTtcclxuICAgICAgICAgICAgfSBlbHNlIGlmICh0aGlzLmNoYXJ0Q2F0ZWdvcnkgPT09ICdtYXAnKSB7XHJcbiAgICAgICAgICAgICAgICBmb3IgKGxldCBpID0gMDsgaSA8IF9wYXJhbXMuc2VyaWVzRGF0YS5sZW5ndGg7IGkrKykge1xyXG4gICAgICAgICAgICAgICAgICAgIGlmIChkLnByb3BlcnRpZXMuSURfID09IF9wYXJhbXMuc2VyaWVzRGF0YVtpXS5pZCkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBsYWJlbCA9IF9wYXJhbXMuc2VyaWVzRGF0YVtpXS5uYW1lO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBjb3VudCA9IF9wYXJhbXMuc2VyaWVzTmFtZSArICc6ICcgKyBfcGFyYW1zLnNlcmllc0RhdGFbaV0udmFsdWU7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlID0gX3BhcmFtcy5zZXJpZXNEYXRhW2ldLnZhbHVlO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBicmVhaztcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgIGNvdW50ID0gdGhpcy5fY2hhcnRTdmMuZ2V0TGFiZWxUZXh0KHRoaXMuY29uZmlnLnRvb2x0aXAuZm9ybWF0LCBjb3VudCk7XHJcbiAgICAgICAgICAgIHRvb2x0aXAuc2VsZWN0KCcua2R4LWNoYXJ0cy10b29sdGlwLWxhYmVsJykuaHRtbChsYWJlbC50b1VwcGVyQ2FzZSgpKTtcclxuICAgICAgICAgICAgaWYgKHRoaXMuY2hhcnRUeXBlWzFdICE9PSAnZmlsdGVyJykgdG9vbHRpcC5zZWxlY3QoJy5rZHgtY2hhcnRzLXRvb2x0aXAtY291bnQnKS5odG1sKGNvdW50KS5zdHlsZSgnZm9udC13ZWlnaHQnLCAnYm9sZCcpO1xyXG5cclxuICAgICAgICAgICAgdG9vbHRpcC5hdHRyKCdzdHlsZScsIHRoaXMuX2NoYXJ0U3ZjLmdldFN0eWxlKE9iamVjdC5hc3NpZ24oe30sIFRPT0xUSVBfREVGQVVMVF9TVFlMRSksIHRydWUpKTtcclxuICAgICAgICAgICAgdG9vbHRpcC5zdHlsZSgnZGlzcGxheScsICdibG9jaycpO1xyXG4gICAgICAgICAgICB0b29sdGlwLnN0eWxlKCdvcGFjaXR5JywgMik7XHJcbiAgICAgICAgICAgIHRvb2x0aXAuc3R5bGUoJ3otaW5kZXgnLCA0MDMpO1xyXG5cclxuICAgICAgICAgICAgaWYgKHRoaXMuY2hhcnRDYXRlZ29yeSA9PT0gJ2xpbmUnKSB7XHJcbiAgICAgICAgICAgICAgICBfcGFyYW1zLmRvdEhvdmVyKHRoaXMuZ2V0RG90SWQoX3BhcmFtcy54SW5kZXgsIGQpLCB0cnVlKTtcclxuICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgaWYgKF9wYXJhbXMgJiYgX3BhcmFtcy5jYWxsYmFja3MgJiYgX3BhcmFtcy5jYWxsYmFja3MubW91c2VvdmVyKSBfcGFyYW1zLmNhbGxiYWNrcy5tb3VzZW92ZXIodmFsdWUpO1xyXG5cclxuICAgICAgICAgICAgLy8gaW4gY2FzZSBtb3VzZW1vdmUgZGlkIG5vdCB0cmlnZ2VyLCBwb3NpdGlvbiB0b29sdGlwIG9uY2UgdG9vbHRpcCBpcyBjcmVhdGVkXHJcbiAgICAgICAgICAgIGlmICh0aGlzLmNoYXJ0Q2F0ZWdvcnkgIT09ICdtYXAnKSB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLl9jaGFydFN2Yy50b29sdGlwU3ZjLnBvc2l0aW9uVG9vbHRpcCh0b29sdGlwLCB7IHRvcDogZDMuZXZlbnQubGF5ZXJZLCBsZWZ0OiBkMy5ldmVudC5sYXllclggfSk7XHJcbiAgICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgICAgICBpZiAodmFsdWUgfHwgdmFsdWUgPT09IDApIHRoaXMuX2NoYXJ0U3ZjLnRvb2x0aXBTdmMucG9zaXRpb25Ub29sdGlwKHRvb2x0aXAsIHsgdG9wOiB0b3AsIGxlZnQ6IGxlZnQgfSk7XHJcbiAgICAgICAgICAgICAgICBlbHNlIHRvb2x0aXAucmVtb3ZlKCk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9KTtcclxuXHJcbiAgICAgICAgX3BhdGgub24oJ21vdXNlbW92ZScsIChkKSA9PiB7XHJcbiAgICAgICAgICAgIGxldCB0b3A6IG51bWJlciA9IG1hcENvbmRpdGlvbiA/IHBhcnNlSW50KF9wYXJhbXMuZnVsbEdyYXBoLm5vZGUoKS5zdHlsZS50b3ApICsgZDMuZXZlbnQubGF5ZXJZIDogZDMuZXZlbnQubGF5ZXJZO1xyXG4gICAgICAgICAgICBsZXQgbGVmdDogbnVtYmVyID0gbWFwQ29uZGl0aW9uID8gcGFyc2VJbnQoX3BhcmFtcy5mdWxsR3JhcGgubm9kZSgpLnN0eWxlLmxlZnQpICsgZDMuZXZlbnQubGF5ZXJYIDogZDMuZXZlbnQubGF5ZXJYO1xyXG4gICAgICAgICAgICAvLyBwb3NpdGlvbiB0aGUgdG9vbHRpcCB0byB0aGUgY3Vyc29yXHJcbiAgICAgICAgICAgIHRoaXMuX2NoYXJ0U3ZjLnRvb2x0aXBTdmMucG9zaXRpb25Ub29sdGlwKHRvb2x0aXAsIHsgdG9wOiB0b3AsIGxlZnQ6IGxlZnQgfSk7XHJcbiAgICAgICAgfSk7XHJcblxyXG4gICAgICAgIF9wYXRoLm9uKCdtb3VzZW91dCcsIChkLCBpbmRleCkgPT4ge1xyXG4gICAgICAgICAgICBpZiAodGhpcy5jaGFydFR5cGUgJiYgKHRoaXMuY2hhcnRUeXBlWzBdID09PSAncGllJyB8fCB0aGlzLmNoYXJ0VHlwZVswXSA9PT0gJ2RvbnV0JyB8fCB0aGlzLmNoYXJ0VHlwZVswXSA9PT0gJ3JhZGlhbCcgfHwgdGhpcy5jaGFydENhdGVnb3J5ID09PSAnYmFyJykpIHtcclxuICAgICAgICAgICAgICAgIGlmICh0aGlzLmNoYXJ0VHlwZVswXSA9PT0gJ3BpZScgfHwgdGhpcy5jaGFydFR5cGVbMF0gPT09ICdkb251dCcpIHtcclxuICAgICAgICAgICAgICAgICAgICBsZXQgdGhpc1BhdGg6IGFueSA9IGQzLnNlbGVjdChfcGF0aC5fZ3JvdXBzWzBdW2luZGV4XSk7XHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKCF0aGlzUGF0aC5jbGFzc2VkKCdjbGlja2VkJykpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgX3BhcmFtcy5wYXRoQW5pbSh0aGlzUGF0aCwgZmFsc2UsIF9wYXJhbXMuaW5uZXJSYWRpdXMsIF9wYXJhbXMub3V0ZXJSYWRpdXMpO1xyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIGQzLnNlbGVjdChfcGF0aC5fZ3JvdXBzWzBdW2luZGV4XSkuc3R5bGUoJ29wYWNpdHknLCAnMScpO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIC8vIHRvb2x0aXAuc3R5bGUoJ2Rpc3BsYXknLCAnbm9uZScpO1xyXG4gICAgICAgICAgICAvLyB0b29sdGlwLnN0eWxlKCdvcGFjaXR5JywgMCk7XHJcbiAgICAgICAgICAgIHRvb2x0aXAucmVtb3ZlKCk7XHJcblxyXG4gICAgICAgICAgICBpZiAodGhpcy5jaGFydENhdGVnb3J5ID09PSAnbGluZScpIHtcclxuICAgICAgICAgICAgICAgIF9wYXJhbXMuZG90SG92ZXIodGhpcy5nZXREb3RJZChfcGFyYW1zLnhJbmRleCwgZCkpO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIGlmIChfcGFyYW1zICYmIF9wYXJhbXMuY2FsbGJhY2tzICYmIF9wYXJhbXMuY2FsbGJhY2tzLm1vdXNlb3V0KSBfcGFyYW1zLmNhbGxiYWNrcy5tb3VzZW91dCgpO1xyXG4gICAgICAgIH0pO1xyXG5cclxuICAgICAgICBfcGF0aC5vbignY2xpY2snLCAoZCwgaW5kZXgpID0+IHtcclxuICAgICAgICAgICAgaWYgKHRoaXMuY2hhcnRUeXBlICYmICh0aGlzLmNoYXJ0VHlwZVswXSA9PT0gJ3BpZScgfHwgdGhpcy5jaGFydFR5cGVbMF0gPT09ICdkb251dCcpKSB7XHJcbiAgICAgICAgICAgICAgICBsZXQgdGhpc1BhdGg6IGFueSA9IGQzLnNlbGVjdChfcGF0aC5fZ3JvdXBzWzBdW2luZGV4XSk7XHJcbiAgICAgICAgICAgICAgICBsZXQgY2xpY2tlZDogYm9vbGVhbiA9IHRoaXNQYXRoLmNsYXNzZWQoJ2NsaWNrZWQnKTtcclxuICAgICAgICAgICAgICAgIF9wYXJhbXMucGF0aEFuaW0odGhpc1BhdGgsICFjbGlja2VkLCBfcGFyYW1zLmlubmVyUmFkaXVzLCBfcGFyYW1zLm91dGVyUmFkaXVzKTtcclxuICAgICAgICAgICAgICAgIHRoaXNQYXRoLmNsYXNzZWQoJ2NsaWNrZWQnLCAhY2xpY2tlZCk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9KTtcclxuICAgIH1cclxuXHJcbiAgICAvLyA9PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT0gTEFCRUwgPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PVxyXG5cclxuICAgIHB1YmxpYyBzZXRMYWJlbChfeURhdGE6IElEM1lEYXRhLCBfeERhdGE6IHN0cmluZyB8IG51bWJlciwgX3hQb3NpdGlvbjogbnVtYmVyLCBfeVBvc2l0aW9uOiBudW1iZXIpOiBhbnkge1xyXG4gICAgICAgIGlmICghdGhpcy5jb25maWcuY2hhcnQubGFiZWxzLmVuYWJsZWQpIHJldHVybjtcclxuXHJcbiAgICAgICAgbGV0IGxhYmVsQ29uZmlnOiBJRGF0YUxhYmVsID0gdGhpcy5jb25maWcuY2hhcnQubGFiZWxzO1xyXG5cclxuICAgICAgICBsZXQgbGFiZWxDb250YWluZXI6IGFueSA9IHRoaXMuZGF0YUxhYmVsQ29udGFpbmVyLmFwcGVuZCgnZGl2JylcclxuICAgICAgICAgICAgLmF0dHIoJ2NsYXNzJywgJ2tkeC1jaGFydHMtZGF0YS1sYWJlbCB4LScgKyBfeERhdGEgKyAnIHktJyArIF95RGF0YS5pZCk7XHJcblxyXG4gICAgICAgIGxldCBsYWJlbFRleHQ6IHN0cmluZyA9IHRoaXMuX2NoYXJ0U3ZjLmdldExhYmVsVGV4dChsYWJlbENvbmZpZy5mb3JtYXQsIF95RGF0YS52YWx1ZSk7XHJcblxyXG4gICAgICAgIGxhYmVsQ29udGFpbmVyXHJcbiAgICAgICAgICAgIC5hcHBlbmQoJ2RpdicpXHJcbiAgICAgICAgICAgIC5hdHRyKCdjbGFzcycsICdrZHgtY2hhcnRzLWRhdGEtbGFiZWwtdGV4dCcpXHJcbiAgICAgICAgICAgIC5odG1sKGxhYmVsVGV4dClcclxuICAgICAgICAgICAgLmF0dHIoJ3N0eWxlJywgdGhpcy5fY2hhcnRTdmMuZ2V0U3R5bGUobGFiZWxDb25maWcuc3R5bGUpKTtcclxuXHJcbiAgICAgICAgdGhpcy5fc2V0TGFiZWxQb3NpdGlvbihsYWJlbENvbnRhaW5lciwgX3lEYXRhLnN1bSB8fCBfeURhdGEudmFsdWUsIF94UG9zaXRpb24sIF95UG9zaXRpb24pO1xyXG5cclxuICAgICAgICByZXR1cm4gbGFiZWxDb250YWluZXI7XHJcbiAgICB9XHJcblxyXG4gICAgcHVibGljIHRyYW5zZm9ybVBvc2l0aW9uKHg6IG51bWJlciB8IHN0cmluZywgeTogbnVtYmVyIHwgc3RyaW5nLCBpc0F0dHJpYnV0ZT86IGJvb2xlYW4pOiBzdHJpbmcge1xyXG4gICAgICAgIHJldHVybiAndHJhbnNsYXRlKCcgKyB4ICsgKChpc0F0dHJpYnV0ZSkgPyAnLCcgOiAncHgsJykgKyB5ICsgKChpc0F0dHJpYnV0ZSkgPyAnKScgOiAncHgpJyk7XHJcbiAgICB9XHJcblxyXG4gICAgcHVibGljIGdldERvdElkKHhEYXRhOiBzdHJpbmcgfCBudW1iZXIsIHlJZDogc3RyaW5nKTogc3RyaW5nIHtcclxuICAgICAgICByZXR1cm4gJ2tkeC1jaGFydHMtcG9pbnQtZG90IHgtJyArIHhEYXRhICsgJyB5LScgKyB5SWQ7XHJcbiAgICB9XHJcblxyXG4gICAgcHVibGljIGlzRGF0YUV4aXN0KF9pdGVtOiBhbnksIF95SW5kZXg6IG51bWJlcik6IGJvb2xlYW4ge1xyXG4gICAgICAgIHJldHVybiB0aGlzLl9jaGFydFN2Yy5pc0V4aXN0KF9pdGVtLnlbX3lJbmRleF0pO1xyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX3NldExhYmVsQ29udGFpbmVyKCk6IHZvaWQge1xyXG4gICAgICAgIHRoaXMuZGF0YUxhYmVsQ29udGFpbmVyID0gZDMuc2VsZWN0KCcjJyArIHRoaXMuY29uZmlnLmlkICsgJy5rZHgtY2hhcnRzICcgKyAnLmtkeC1jaGFydHMtZGF0YS1sYWJlbC1jb250YWluZXInKTtcclxuICAgIH1cclxuXHJcbiAgICAvKipcclxuICAgICAqIF9wYXJhbXMgZm9yIGJhcjogeyB2YWx1ZVNpZ246IC0xIG9yIDAgb3IgMSwgZGltZW5zaW9uczogd2lkdGgsIGhlaWdodCwgeFBvcywgeVBvc31cclxuICAgICAqIF9wYXJhbXMgZm9yIGxpbmU6IHsgZG90U2l6ZTogbnVtYmVyLCBsYWJlbExlbmd0aDogbnVtYmVyfVxyXG4gICAgICovXHJcbiAgICAvLyBhZmZlY3RzIGFsbCBjaGFydHMgZXhjZXB0IHBpZSwgbWFwLCBob3Jpem9udGFsIGJhciAod2hpY2ggdXNlcyBmbGV4IGZvciB2ZXJ0aWNhbCBhbGlnbiwgcmVmZXIgdG8ga2QtYmFyLWNoYXJ0KVxyXG4gICAgcHVibGljIHNldExhYmVsVGV4dFBvc2l0aW9uKGxhYmVsVGV4dCwgX3lQb3NpdGlvbjogbnVtYmVyLCBfcGFyYW1zOiB7IFtrZXk6IHN0cmluZ106IGFueSB9ID0ge30pOiB2b2lkIHtcclxuICAgICAgICBsZXQgc3RvcmU6IElMYWJlbFRleHRWZXJ0aWNhbEFsaWduU3RvcmUgPSBMQUJFTF9URVhUX1ZFUlRJQ0FMX0FMSUdOX1NUT1JFO1xyXG4gICAgICAgIGxldCB2ZXJ0aWNhbEFsaWduOiAndG9wJyB8ICdtaWRkbGUnIHwgJ2JvdHRvbScgPSB0aGlzLl9jaGFydFN2Yy5nZXREZWZhdWx0VmVydGljYWxBbGlnbih0aGlzLmNvbmZpZywgX3BhcmFtcyk7XHJcbiAgICAgICAgbGV0IGRvdFNpemU6IG51bWJlciA9IF9wYXJhbXMuZG90U2l6ZSA/IF9wYXJhbXMuZG90U2l6ZSA6IDA7XHJcbiAgICAgICAgbGV0IG9mZnNldDogbnVtYmVyID0gZG90U2l6ZSAvIDI7XHJcblxyXG4gICAgICAgIGlmICh2ZXJ0aWNhbEFsaWduID09PSAnbWlkZGxlJykge1xyXG4gICAgICAgICAgICBsZXQgY2hlY2tzID0gWyd0b3AnLCAnYm90dG9tJ107XHJcbiAgICAgICAgICAgIGNoZWNrcy5mb3JFYWNoKGtleSA9PiB7XHJcbiAgICAgICAgICAgICAgICBpZiAodGhpcy5fY2hhcnRTdmMuX2NoZWNrQm91bmRhcnkoc3RvcmVba2V5XS5jaGVjaywgX3lQb3NpdGlvbiwgdGhpcy5oZWlnaHQsIGRvdFNpemUpKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgdmVydGljYWxBbGlnbiA9IHN0b3JlW2tleV0uY2hhbmdlVG87XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH0pO1xyXG4gICAgICAgIH0gZWxzZSBpZiAodGhpcy5fY2hhcnRTdmMuX2NoZWNrQm91bmRhcnkoc3RvcmVbdmVydGljYWxBbGlnbl0uY2hlY2ssIF95UG9zaXRpb24sIHRoaXMuaGVpZ2h0LCBkb3RTaXplKSkge1xyXG4gICAgICAgICAgICB2ZXJ0aWNhbEFsaWduID0gc3RvcmVbdmVydGljYWxBbGlnbl0uY2hhbmdlVG87XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICBsZXQgeVBvczogc3RyaW5nID0gJyc7XHJcbiAgICAgICAgaWYgKHZlcnRpY2FsQWxpZ24gPT09ICdtaWRkbGUnKSB7XHJcbiAgICAgICAgICAgIHlQb3MgPSBzdG9yZVt2ZXJ0aWNhbEFsaWduXS5wZXJjZW50O1xyXG4gICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgIGxldCBzaWduOiBzdHJpbmcgPSB2ZXJ0aWNhbEFsaWduID09PSAndG9wJyA/ICcgLSAnIDogJyArICc7XHJcbiAgICAgICAgICAgIGlmICh0aGlzLmNoYXJ0Q2F0ZWdvcnkgPT09ICdiYXInICYmIHRoaXMuX2NoYXJ0U3ZjLm5lZWRPZmZzZXRGb3JDb2x1bW4odmVydGljYWxBbGlnbiwgX3BhcmFtcykpIG9mZnNldCArPSBfcGFyYW1zLmRpbWVuc2lvbnMuaGVpZ2h0O1xyXG4gICAgICAgICAgICB5UG9zID0gJ2NhbGMoJyArIHN0b3JlW3ZlcnRpY2FsQWxpZ25dLnBlcmNlbnQgKyBzaWduICsgb2Zmc2V0LnRvU3RyaW5nKCkgKyAncHgpJztcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIGxldCB4UG9zOiBzdHJpbmcgPSAoX3BhcmFtcy5sYWJlbExlbmd0aCAmJiBfcGFyYW1zLmxhYmVsTGVuZ3RoID4gMSkgPyAnY2FsYygtNTAlICsgJyArIGRvdFNpemUgLyAyICsgJ3B4KScgOiAnMCUnO1xyXG5cclxuICAgICAgICBsZXQgdHJhbnNsYXRlOiBzdHJpbmcgPSB0aGlzLmNoYXJ0Q2F0ZWdvcnkgPT09ICdsaW5lJyA/IHRoaXMudHJhbnNmb3JtUG9zaXRpb24oeFBvcywgeVBvcywgdHJ1ZSkgOiAndHJhbnNsYXRlWSgnICsgeVBvcyArICcpJztcclxuICAgICAgICBsYWJlbFRleHQuc3R5bGUoJ3RyYW5zZm9ybScsIHRyYW5zbGF0ZSk7XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfc2V0TGFiZWxQb3NpdGlvbihsYWJlbENvbnRhaW5lcjogYW55LCBfeVZhbHVlOiBudW1iZXIsIF94UG9zaXRpb246IG51bWJlciwgX3lQb3NpdGlvbjogbnVtYmVyKTogdm9pZCB7XHJcbiAgICAgICAgbGV0IGRlZmF1bHRQb3NpdGlvbjogeyB4OiBudW1iZXIsIHk6IG51bWJlciB9ID0ge1xyXG4gICAgICAgICAgICB4OiAoKHRoaXMuYmFyLmlzSW52ZXJ0KSA/IHRoaXMuaGVpZ2h0IDogMCksXHJcbiAgICAgICAgICAgIHk6ICgodGhpcy5iYXIuaXNJbnZlcnQpID8gdGhpcy53aWR0aCA6IDApXHJcbiAgICAgICAgfTtcclxuICAgICAgICBsZXQgeDogbnVtYmVyID0gKHR5cGVvZiBfeFBvc2l0aW9uID09PSAnbnVtYmVyJykgPyBfeFBvc2l0aW9uIDogZGVmYXVsdFBvc2l0aW9uLng7XHJcbiAgICAgICAgbGV0IHk6IG51bWJlciA9ICh0eXBlb2YgX3lQb3NpdGlvbiA9PT0gJ251bWJlcicpID8gX3lQb3NpdGlvbiA6IGRlZmF1bHRQb3NpdGlvbi55O1xyXG5cclxuICAgICAgICAvLyBpZiAoX3lQb3NpdGlvbiA8IHRoaXMuZGF0YUxhYmVsUHVzaERvd25SYW5nZSkge1xyXG4gICAgICAgIC8vICAgICB5ID0gNTtcclxuICAgICAgICAvLyB9XHJcblxyXG4gICAgICAgIGlmICh0aGlzLmlzUnRsKSB4ID0gKHRoaXMud2lkdGggKiAtMSkgKyB4O1xyXG5cclxuICAgICAgICBpZiAoX3lWYWx1ZSAmJiAoX3lWYWx1ZSA+IHRoaXMuZG9tYWluTWF4IHx8IF95VmFsdWUgPCB0aGlzLmRvbWFpbk1pbikpIHtcclxuICAgICAgICAgICAgbGFiZWxDb250YWluZXIuc3R5bGUoJ2Rpc3BsYXknLCAnbm9uZScpO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgdGhpcy5fYXBwbHlMYWJlbFBvc2l0aW9uKGxhYmVsQ29udGFpbmVyLCB4LCB5KTtcclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF9hcHBseUxhYmVsUG9zaXRpb24obGFiZWxDb250YWluZXI6IGFueSwgX3hQb3NpdGlvbjogbnVtYmVyLCBfeVBvc2l0aW9uOiBudW1iZXIpOiB2b2lkIHtcclxuICAgICAgICBsZXQgcm90YXRlOiBzdHJpbmcgPSAnJztcclxuICAgICAgICBsZXQgbGFiZWxTdHlsZTogeyBba2V5OiBzdHJpbmddOiBzdHJpbmcgfSA9IHRoaXMuY29uZmlnLmNoYXJ0LmxhYmVscy5zdHlsZTtcclxuXHJcbiAgICAgICAgLy8gdGhpcy5jb25maWcuY2hhcnQubGFiZWxzLnJvdGF0aW9uIGNhbm5vdCBiZSAnJyBvciBudWxsIG9yIG90aGVyIG5vbi12YWx1ZVxyXG4gICAgICAgIGlmIChsYWJlbFN0eWxlLmhhc093blByb3BlcnR5KCdyb3RhdGlvbicpICYmIGxhYmVsU3R5bGUucm90YXRpb24pIHtcclxuICAgICAgICAgICAgcm90YXRlID0gJyByb3RhdGUoJyArIGxhYmVsU3R5bGUucm90YXRpb24gKyAnZGVnKSc7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICBsYWJlbENvbnRhaW5lclxyXG4gICAgICAgICAgICAuc3R5bGUoJ3RyYW5zZm9ybScsIHRoaXMudHJhbnNmb3JtUG9zaXRpb24oX3hQb3NpdGlvbiwgX3lQb3NpdGlvbikgKyByb3RhdGUpO1xyXG5cclxuICAgICAgICBpZiAodGhpcy5pc1J0bCkgbGFiZWxDb250YWluZXIuc3R5bGUoJ3RleHQtYWxpZ24nLCAncmlnaHQnKTtcclxuICAgIH1cclxufVxyXG4iXX0=