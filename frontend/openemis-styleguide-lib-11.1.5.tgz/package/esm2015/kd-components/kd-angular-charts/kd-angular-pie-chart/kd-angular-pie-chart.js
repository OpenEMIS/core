import { Component, ViewEncapsulation, Input, Output, EventEmitter } from '@angular/core';
import { KdChartBaseClass } from '../kd-angular-chart-base-class';
import { KdChartsSvc } from '../kd-angular-charts-svc';
import { KdDomElemSvc } from '../../kd-common/index';
import * as d3 from 'd3';
const PI = Math.PI, arcMinRadius = 10, arcPadding = 10, labelPadding = -5, numTicks = 10;
export class KdPieChart extends KdChartBaseClass {
    constructor(_chartSvc, _domSvc) {
        super(_chartSvc, _domSvc);
        this._chartSvc = _chartSvc;
        this._domSvc = _domSvc;
        this.pieData = [];
        this._posArray = [];
        this.outputLegend = new EventEmitter(true);
        this.outputData = new EventEmitter(true);
    }
    ngOnInit() {
        this.config = Object.assign({}, this.pieConfig);
        this._setData();
        super.chartTimeout(() => this._setChart());
        this.api.legendClick = (_data, legendData) => {
            this.pieData = [];
            if (this.dataLabelContainer)
                this.dataLabelContainer.selectAll('*').remove();
            // if (_config) this.config = _config;
            this.data = _data;
            if (legendData) {
                // let newColor = [];
                this.pieData = this.data.data;
                // this.pieData = Object.keys(_config.legendData).map(key => _config.legendData[key]).map((value) => (value));
                // for (let i = 0; i < this.pieData.length; i++) {
                //     newColor.push(this.pieData[i].color);
                // }
                // this.pieConfig['pieColor'] = newColor;
                this._redrawChart();
            }
            else {
                // fail-safe in case data massage haven't create legendData
                this._setData();
                this._setChart();
            }
        };
        this.api.redraw = () => {
            this._redrawChart();
        };
    }
    ngOnChanges(_simpleChanges) {
        if (_simpleChanges.hasOwnProperty('data') && !_simpleChanges['data'].firstChange) {
            this.data = _simpleChanges.data.currentValue;
            this._redrawChart('data');
        }
        if (_simpleChanges.hasOwnProperty('pieConfig') && !_simpleChanges['pieConfig'].firstChange) {
            this.pieConfig = _simpleChanges.pieConfig.currentValue;
            this._redrawChart('config');
        }
    }
    ngOnDestroy() {
        this._resetChart();
    }
    _redrawChart(_changes) {
        this._resetChart();
        if (_changes === 'data') {
            this.pieData = [];
            this._setData();
        }
        else {
            this.pieConfig['legendData'] = this.config['legendData'];
            this.config = Object.assign({}, this.pieConfig);
        }
        super.chartTimeout(() => this._setChart());
    }
    _setChart() {
        super.setSvg();
        super.setSvgDimension('x');
        super.setSvgDimension('y');
        this.chartType = this.data.layout.split('-');
        this.chartCategory = this.data.type;
        // moving pie chart to center of svg
        let height = this.svgContainer.node().getBoundingClientRect().height;
        let width = this.svgContainer.node().getBoundingClientRect().width;
        this.width = width;
        this.graph.attr('transform', 'translate(' + (width / 2) + ',' + (height / 2) + ')');
        // let color = this.pieConfig['pieColor'] ? d3.scaleOrdinal().range(this.pieConfig['pieColor']) : d3.scaleOrdinal().range(this.config.colors);
        // let chartParams = {
        //     'color': color
        // };
        this.dataLabelContainer.style('top', 0);
        this.dataLabelContainer.style('left', 0);
        if (this.chartType[0] === 'radial') {
            this._drawRadial({ height: height });
        }
        else if (this.chartType[0] === 'gauge') {
            this._drawGauge({ height: height });
        }
        else {
            this._drawPieDonut({ height: height, width: width });
        }
    }
    /**
     * when receiving data and legend, the structure is customise to for line/area and bar. pie needs to recalculate the legend
     * _setData generate pieData and new legend from the previous legend
     *
     * Note: this.pieData is used for rendering.
     * Note2: data.pieData it will not be changed onLegendClick
     * (onLegendClick affects data.data which is stored into this.pieData via api)
     */
    _setData() {
        if (!this.config.skipMassage) {
            if (this.data['piedata']) {
                this.pieData = this.data.piedata;
                // saving massaged piedata to this.data for export
                this.data.data = this.data.piedata;
            }
        }
        else {
            // when skip massage, no generation of pieData needed.
            this.pieData = this.data.data;
        }
    }
    _resetChart() {
        if (typeof this._path !== 'undefined')
            this._path.remove();
        if (typeof this._radialAxis !== 'undefined')
            this._radialAxis.remove();
        if (typeof this._axialAxis !== 'undefined')
            this._axialAxis.remove();
        if (typeof this._text !== 'undefined')
            this._text.remove();
        if (typeof this._polyline !== 'undefined')
            this._polyline.remove();
        if (typeof this._pointer !== 'undefined')
            this._pointer.remove();
        if (typeof this._percentageText !== 'undefined')
            this._percentageText.remove();
        if (this.dataLabelContainer)
            this.dataLabelContainer.selectAll('*').remove();
        this._posArray = [];
        clearInterval(this._interval);
        super.removeChart();
    }
    _drawPieDonut(_params) {
        let radius = Math.min(_params.width, _params.height) / 2;
        if (this.chartType[1] && this.chartType[1] === 'half') {
            radius = (Math.min(_params.width, _params.height) / 5) * 3;
            this.graph.attr('transform', 'translate(' + (_params.width / 2) + ',' + ((_params.height / 4) * 3) + ')');
        }
        let innerRadius = this.chartType[0] === 'pie' ? 0 : (this.config.plotOptions.pie.innerRadius / 100) * radius * 0.8;
        let arc = d3.arc().innerRadius(innerRadius).outerRadius(radius * 0.8);
        let outerarc = d3.arc().innerRadius(radius * 0.9).outerRadius(radius * 0.9);
        // let arc = d3.arc().innerRadius(innerRadius).outerRadius(radius);
        let pie = d3.pie().sort(null).value((d) => { return d.y; });
        let dataLabelCheck = this.chartType[1] === 'full' ? Math.PI : 0;
        pie = this.chartType[1] === 'full' ? pie.startAngle(0).endAngle(Math.PI * 2) : pie.startAngle(-90 * (Math.PI / 180)).endAngle(90 * (Math.PI / 180));
        this._path = this.graph.selectAll('path')
            .data(pie(this.pieData))
            .enter()
            .append('path')
            .attr('aria-value', (d) => d.data.y)
            .attr('aria-series-name', (d) => this.legend[d.data.id].name)
            .attr('class', (d) => {
            this._posArray.push({ 'x': d.data.index, 'value': d.data.y, 'id': d.data.index });
            return 'x-' + d.data.index + ' y-' + d.data.index;
            // return 'x-' + (d.data.xBase).replace(/ /g,'') + ' y-' + seriesId;
        })
            .attr('id', (d) => {
            return d.data.index;
            // return (d.data.x).replace(/ /g,'');
        })
            .attr('fill', (d, i) => {
            return this.legend[d.data.id].color; // color should follow legendData
        })
            // .attr('d', arc)
            .style('stroke', this.config.plotOptions.pie.borderColor)
            .style('stroke-width', this.config.plotOptions.pie.borderWidth || 0);
        let labelParams = {
            'pie': pie,
            'arc': arc,
            'outerarc': outerarc,
            'radius': radius,
            'dataLabelCheck': dataLabelCheck,
        };
        if (!this.config.animation) {
            this._path
                .attr('d', d => arc(d))
                .attr('pos', d => getPos(d, this.chartType[1]));
            this._setDataLabel(labelParams);
        }
        else {
            this._path.transition()
                .delay((d, i) => {
                return i * 20;
            })
                .attrTween('d', (d) => {
                let i = d3.interpolate(d.startAngle, d.endAngle);
                return (t) => {
                    d.endAngle = i(t);
                    return arc(d);
                };
            })
                .attrTween('pos', (d) => {
                let current;
                current = current || d;
                let interpolate = d3.interpolate(current, d);
                current = interpolate(0);
                return (t) => {
                    let d2 = interpolate(t);
                    return getPos(d2, this.chartType[1]);
                };
            })
                .on('end', (d, i) => {
                if (i === (this.pieData.length - 1)) {
                    setTimeout(() => {
                        this._setDataLabel(labelParams);
                    });
                }
            });
        }
        this._path.exit().remove();
        function getPos(_d2, _chartType) {
            let pos = outerarc.centroid(_d2);
            if (_chartType && _chartType === 'half') {
                pos[0] = radius * (midAngle(_d2) < dataLabelCheck ? -1 : 1);
            }
            else {
                pos[0] = radius * (midAngle(_d2) < dataLabelCheck ? 1 : -1);
            }
            return pos;
        }
        function midAngle(_d) {
            return _d.startAngle + (_d.endAngle - _d.startAngle) / 2;
        }
        let eventsParam = {
            'innerRadius': innerRadius,
            'outerRadius': radius * 0.8,
            'pathAnim': this._pathAnim,
        };
        super._initMouseEvents(this._path, eventsParam);
    }
    _drawRadial(_params) {
        // let height = document.querySelector('#' + this.config.id + '.kdx-charts .svg-container').getBoundingClientRect().height;
        let chartRadius = _params.height / 2 - 40;
        let scale = d3.scaleLinear()
            .domain([0, d3.max(this.pieData, d => d.y) * 1.1])
            .range([0, 2 * PI]);
        let ticks = scale.ticks(numTicks).slice(0, -1);
        let keys = this.pieData.map((d, i) => d.x);
        // number of arcs
        const numArcs = keys.length;
        const arcWidth = (chartRadius - arcMinRadius - numArcs * arcPadding) / numArcs;
        let arc = d3.arc()
            .innerRadius((d, i) => this._getInnerRadius(i, numArcs, arcWidth))
            .outerRadius((d, i) => this._getOuterRadius(i, numArcs, arcWidth))
            .startAngle(0)
            .endAngle((d, i) => scale(d));
        this._radialAxis = this.graph.append('g')
            .attr('class', 'kdx-charts-r kdx-charts-axis-radial')
            .selectAll('g')
            .data(this.pieData)
            .enter().append('g');
        this._radialAxis.append('circle')
            .attr('r', (d, i) => this._getOuterRadius(i, numArcs, arcWidth) + arcPadding);
        this._radialAxis.append('text')
            .attr('x', labelPadding)
            .attr('y', (d, i) => -this._getOuterRadius(i, numArcs, arcWidth) + arcPadding)
            .style('font-size', '10px')
            .text(d => d.x);
        this._axialAxis = this.graph.append('g')
            .attr('class', 'kdx-charts-a kdx-charts-axis-radial')
            .selectAll('g')
            .data(ticks)
            .enter().append('g')
            .attr('transform', d => 'rotate(' + (this._rad2deg(scale(d)) - 90) + ')');
        this._axialAxis.append('line')
            .attr('x2', chartRadius);
        this._axialAxis.append('text')
            .attr('x', chartRadius + 10)
            .style('text-anchor', d => (scale(d) >= PI && scale(d) < 2 * PI ? 'end' : null))
            .style('font-size', '10px')
            .attr('transform', d => 'rotate(' + (90 - this._rad2deg(scale(d))) + ',' + (chartRadius + 10) + ',0)')
            .text(d => d);
        // data arcs
        this._path = this.graph.append('g')
            .selectAll('path')
            .data(this.pieData)
            .enter().append('path')
            .attr('class', (d) => {
            return 'x-' + d.xBase + ' y-' + d.x;
        })
            .style('fill', (d, i) => this.legend[d.id].color);
        if (!this.config.animation) {
            this._path.attr('d', (d, i) => arc(d.y, i));
        }
        else {
            this._path.transition()
                .delay((d, i) => i * 100)
                .duration(200)
                // .attrTween('d', arcTween);
                .attrTween('d', (d, i) => {
                let interpolate = d3.interpolate(0, d.y);
                return t => arc(interpolate(t), i);
            });
        }
        super._initMouseEvents(this._path);
    }
    _drawGauge(_params) {
        // let percent = 100.00;
        let percent = Math.floor(Math.random() * 100);
        let endAngle = this.chartType[1] === 'full' ? Math.PI * 2 : Math.PI;
        let outerRadius = _params.height / 3;
        let innerRadius = (outerRadius / 3) * 2;
        let fontSize = innerRadius * 0.8;
        let arc = d3.arc()
            .innerRadius(innerRadius)
            .outerRadius(outerRadius)
            .startAngle(0)
            .endAngle(endAngle);
        let arcLine = d3.arc()
            .innerRadius(innerRadius)
            .outerRadius(outerRadius)
            .startAngle(0);
        this._path = this.graph.append('path')
            .attr('d', arc)
            .attr('transform', 'rotate(-90)')
            .attr('stroke-width', 1)
            .attr('stroke', '#666666')
            .style('fill', '#FFFFFF');
        this._pointer = this.graph.append('path')
            // let pathForeground = this.graph.append('path')
            .datum({ endAngle: 0 })
            .attr('d', arcLine)
            .attr('transform', 'rotate(-90)');
        this._percentageText = this.graph.append('text')
            .datum(0)
            .text(function (d) {
            return d;
        })
            .attr('class', 'kdx-charts-middleText')
            .attr('text-anchor', 'middle')
            .attr('dy', this.chartType[1] === 'full' ? fontSize * 0.45 : 0)
            .style('fill', d3.rgb('#000000'))
            .style('font-size', fontSize + 'px');
        if (!this.config.animation) {
            this._pointer
                .attr('d', d => arcLine(d))
                .style('fill', d3.rgb('#FF0000'));
            return;
        }
        let arcTween = function (transition, newValue, test) {
            transition.attrTween('d', (d) => {
                let interpolate = d3.interpolate(d.endAngle, ((endAngle)) * (newValue / 100));
                let interpolateCount = d3.interpolate(0, newValue);
                return (t) => {
                    d.endAngle = interpolate(t);
                    test._percentageText.text(Math.floor(interpolateCount(t)) + '%');
                    return arcLine(d);
                };
            });
        };
        this._pointer.transition()
            .duration(750)
            .ease(d3.easeCubicIn)
            .call(arcTween, percent, this)
            .style('fill', d3.rgb('#FF0000'));
    }
    _setDataLabel(_params) {
        if (!this.config.chart.labels.enabled)
            return;
        if (this.chartCategory !== 'pie')
            return;
        if (this._posArray.length === 0)
            return;
        let line = Array.from(document.querySelectorAll('#' + this.config.id + '.kdx-charts .kdx-charts-lines'));
        line.forEach(e => e.parentNode.removeChild(e));
        let key = (d) => { return d.data.y; };
        function midAngle(_d) {
            return _d.startAngle + (_d.endAngle - _d.startAngle) / 2;
        }
        let height = this.svgContainer.node().getBoundingClientRect().height;
        let width = this.svgContainer.node().getBoundingClientRect().width;
        height = (this.chartType[1] && this.chartType[1] === 'half') ? ((height / 4) * 3) - 8 : height / 2 - 8;
        for (let i = 0; i < this._path._groups[0].length; i++) {
            if (this._posArray[i] && this._posArray[i].id !== undefined) {
                let posPointer = document.querySelector('#' + this.config.id + ' #' + this._posArray[i].id).getAttribute('pos');
                if (this._posArray.length !== 0 && document.querySelector('#' + this.config.id + ' #' + this._posArray[i].id) !== null && posPointer !== null) {
                    let yData = {
                        'id': this._posArray[i].id,
                        'value': this._posArray[i].value
                    };
                    let xvalue = parseInt(posPointer.split(',')[0]) + width / 2;
                    let yvalue = parseInt(posPointer.split(',')[1]) + height;
                    let tempCondition = parseInt(posPointer.split(',')[0]);
                    let rtlCondition = this.isRtl === false ? tempCondition < 0 : tempCondition > 0;
                    let checkFlexEndStyle = rtlCondition ? 'flex-end' : 'flex-start';
                    let dataLabelClass = '#' + this.config.id + ' .kdx-charts-data-label.x-' + this._posArray[i].x + '.y-' + yData.id;
                    if (document.querySelector(dataLabelClass) == null) {
                        super.setLabel(yData, this._posArray[i].x, xvalue, yvalue).style('visibility', 'visible').style('width', '0px').style('justify-content', checkFlexEndStyle);
                    }
                }
            }
        }
        this._polyline = this.graph.append('g')
            .attr('class', 'kdx-charts-lines')
            .selectAll('polyline')
            .data(_params.pie(this.pieData), key)
            .enter()
            .append('polyline')
            .style('stroke', (d, i) => {
            return this.legend[d.data.id].color;
        }).attr('points', (d) => {
            return getPos(d, this.chartType[1]);
        }).style('fill', 'none');
        // if (!this.config.animation) {
        //     this._polyline.attr('points', (d) => {
        //         return getPos(d, this.chartType[1]);
        //     });
        //     return;
        // }
        // this._polyline.transition().duration(1000)
        //     .attrTween('points', (d) => {
        //         this._current = this._current || d;
        //         let interpolate = d3.interpolate(this._current, d);
        //         this._current = interpolate(0);
        //         return (t) => {
        //             let d2 = interpolate(t);
        //             return getPos(d2, this.chartType[1]);
        //         };
        //     });
        function getPos(_d2, _chartType) {
            let pos = _params.outerarc.centroid(_d2);
            if (_chartType && _chartType === 'half') {
                pos[0] = _params.radius * 0.95 * (midAngle(_d2) < _params.dataLabelCheck ? -1 : 1);
            }
            else {
                pos[0] = _params.radius * 0.95 * (midAngle(_d2) < _params.dataLabelCheck ? 1 : -1);
            }
            return [_params.arc.centroid(_d2), _params.outerarc.centroid(_d2), pos];
        }
    }
    _getInnerRadius(_index, _numArcs, _arcWidth) {
        return arcMinRadius + (_numArcs - (_index + 1)) * (_arcWidth + arcPadding);
    }
    _getOuterRadius(_index, _numArcs, _arcWidth) {
        return this._getInnerRadius(_index, _numArcs, _arcWidth) + _arcWidth;
    }
    _rad2deg(_angle) {
        return _angle * 180 / PI;
    }
    _pathAnim(_path, dir, _innerRadius, _outerRadius) {
        switch (dir) {
            case false:
                _path.transition()
                    .duration(500)
                    // .ease('bounce')
                    .attr('d', d3.arc()
                    .innerRadius(_innerRadius)
                    .outerRadius(_outerRadius)).attr('stroke', 'none');
                break;
            case true:
                _path.transition()
                    .attr('d', d3.arc()
                    .innerRadius(_innerRadius)
                    .outerRadius(_outerRadius * 1.1)).attr('stroke', 'white').attr('stroke-width', 2);
                break;
        }
    }
}
KdPieChart.decorators = [
    { type: Component, args: [{
                selector: 'kd-pie-chart',
                template: '',
                encapsulation: ViewEncapsulation.None,
                providers: [KdChartsSvc, KdDomElemSvc],
                host: {
                    'class': 'kdx-pie-chart',
                }
            },] }
];
KdPieChart.ctorParameters = () => [
    { type: KdChartsSvc },
    { type: KdDomElemSvc }
];
KdPieChart.propDecorators = {
    data: [{ type: Input }],
    pieConfig: [{ type: Input, args: ['config',] }],
    legend: [{ type: Input }],
    api: [{ type: Input }],
    seriesThreshold: [{ type: Input }],
    outputLegend: [{ type: Output }],
    outputData: [{ type: Output }]
};
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoia2QtYW5ndWxhci1waWUtY2hhcnQuanMiLCJzb3VyY2VSb290IjoiQzoveGFtcHAvaHRkb2NzL1N0eWxlZ3VpZGUvaW9zdGctb3BlbmVtaXMtc3R5bGVndWlkZS9wcm9qZWN0cy9vcGVuZW1pcy1zdHlsZWd1aWRlLWxpYi9zcmMvIiwic291cmNlcyI6WyJrZC1jb21wb25lbnRzL2tkLWFuZ3VsYXItY2hhcnRzL2tkLWFuZ3VsYXItcGllLWNoYXJ0L2tkLWFuZ3VsYXItcGllLWNoYXJ0LnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBLE9BQU8sRUFDSCxTQUFTLEVBQ1QsaUJBQWlCLEVBQ2pCLEtBQUssRUFDTCxNQUFNLEVBQ04sWUFBWSxFQUtmLE1BQU0sZUFBZSxDQUFDO0FBQ3ZCLE9BQU8sRUFBRSxnQkFBZ0IsRUFBRSxNQUFNLGdDQUFnQyxDQUFDO0FBQ2xFLE9BQU8sRUFBRSxXQUFXLEVBQUUsTUFBTSwwQkFBMEIsQ0FBQztBQUN2RCxPQUFPLEVBQUUsWUFBWSxFQUFFLE1BQU0sdUJBQXVCLENBQUM7QUFFckQsT0FBTyxLQUFLLEVBQUUsTUFBTSxJQUFJLENBQUM7QUFFekIsTUFBTSxFQUFFLEdBQUcsSUFBSSxDQUFDLEVBQUUsRUFDZCxZQUFZLEdBQUcsRUFBRSxFQUNqQixVQUFVLEdBQUcsRUFBRSxFQUNmLFlBQVksR0FBRyxDQUFDLENBQUMsRUFDakIsUUFBUSxHQUFHLEVBQUUsQ0FBQztBQVlsQixNQUFNLE9BQU8sVUFBVyxTQUFRLGdCQUFnQjtJQXNCNUMsWUFBbUIsU0FBc0IsRUFBUyxPQUFxQjtRQUNuRSxLQUFLLENBQUMsU0FBUyxFQUFFLE9BQU8sQ0FBQyxDQUFDO1FBRFgsY0FBUyxHQUFULFNBQVMsQ0FBYTtRQUFTLFlBQU8sR0FBUCxPQUFPLENBQWM7UUFyQmhFLFlBQU8sR0FBZSxFQUFFLENBQUM7UUFVeEIsY0FBUyxHQUFHLEVBQUUsQ0FBQztRQVFiLGlCQUFZLEdBQWlELElBQUksWUFBWSxDQUFDLElBQUksQ0FBQyxDQUFDO1FBQ3BGLGVBQVUsR0FBc0IsSUFBSSxZQUFZLENBQUMsSUFBSSxDQUFDLENBQUM7SUFJakUsQ0FBQztJQUVELFFBQVE7UUFDSixJQUFJLENBQUMsTUFBTSxHQUFHLE1BQU0sQ0FBQyxNQUFNLENBQUMsRUFBRSxFQUFFLElBQUksQ0FBQyxTQUFTLENBQUMsQ0FBQztRQUNoRCxJQUFJLENBQUMsUUFBUSxFQUFFLENBQUM7UUFDaEIsS0FBSyxDQUFDLFlBQVksQ0FBQyxHQUFHLEVBQUUsQ0FBQyxJQUFJLENBQUMsU0FBUyxFQUFFLENBQUMsQ0FBQztRQUUzQyxJQUFJLENBQUMsR0FBRyxDQUFDLFdBQVcsR0FBRyxDQUFDLEtBQVUsRUFBRSxVQUFnQixFQUFFLEVBQUU7WUFDcEQsSUFBSSxDQUFDLE9BQU8sR0FBRyxFQUFFLENBQUM7WUFDbEIsSUFBSSxJQUFJLENBQUMsa0JBQWtCO2dCQUFFLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxTQUFTLENBQUMsR0FBRyxDQUFDLENBQUMsTUFBTSxFQUFFLENBQUM7WUFDN0Usc0NBQXNDO1lBQ3RDLElBQUksQ0FBQyxJQUFJLEdBQUcsS0FBSyxDQUFDO1lBQ2xCLElBQUksVUFBVSxFQUFFO2dCQUNaLHFCQUFxQjtnQkFDckIsSUFBSSxDQUFDLE9BQU8sR0FBRyxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQztnQkFDOUIsOEdBQThHO2dCQUM5RyxrREFBa0Q7Z0JBQ2xELDRDQUE0QztnQkFDNUMsSUFBSTtnQkFDSix5Q0FBeUM7Z0JBRXpDLElBQUksQ0FBQyxZQUFZLEVBQUUsQ0FBQzthQUV2QjtpQkFBTTtnQkFDSCwyREFBMkQ7Z0JBQzNELElBQUksQ0FBQyxRQUFRLEVBQUUsQ0FBQztnQkFDaEIsSUFBSSxDQUFDLFNBQVMsRUFBRSxDQUFDO2FBQ3BCO1FBQ0wsQ0FBQyxDQUFDO1FBQ0YsSUFBSSxDQUFDLEdBQUcsQ0FBQyxNQUFNLEdBQUcsR0FBRyxFQUFFO1lBQ25CLElBQUksQ0FBQyxZQUFZLEVBQUUsQ0FBQztRQUN4QixDQUFDLENBQUM7SUFDTixDQUFDO0lBRUQsV0FBVyxDQUFDLGNBQTZCO1FBQ3JDLElBQUksY0FBYyxDQUFDLGNBQWMsQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLGNBQWMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxXQUFXLEVBQUU7WUFDOUUsSUFBSSxDQUFDLElBQUksR0FBRyxjQUFjLENBQUMsSUFBSSxDQUFDLFlBQVksQ0FBQztZQUM3QyxJQUFJLENBQUMsWUFBWSxDQUFDLE1BQU0sQ0FBQyxDQUFDO1NBQzdCO1FBQ0QsSUFBSSxjQUFjLENBQUMsY0FBYyxDQUFDLFdBQVcsQ0FBQyxJQUFJLENBQUMsY0FBYyxDQUFDLFdBQVcsQ0FBQyxDQUFDLFdBQVcsRUFBRTtZQUN4RixJQUFJLENBQUMsU0FBUyxHQUFHLGNBQWMsQ0FBQyxTQUFTLENBQUMsWUFBWSxDQUFDO1lBQ3ZELElBQUksQ0FBQyxZQUFZLENBQUMsUUFBUSxDQUFDLENBQUM7U0FDL0I7SUFDTCxDQUFDO0lBRUQsV0FBVztRQUNQLElBQUksQ0FBQyxXQUFXLEVBQUUsQ0FBQztJQUN2QixDQUFDO0lBRU8sWUFBWSxDQUFDLFFBQTRCO1FBQzdDLElBQUksQ0FBQyxXQUFXLEVBQUUsQ0FBQztRQUVuQixJQUFJLFFBQVEsS0FBSyxNQUFNLEVBQUU7WUFDckIsSUFBSSxDQUFDLE9BQU8sR0FBRyxFQUFFLENBQUM7WUFDbEIsSUFBSSxDQUFDLFFBQVEsRUFBRSxDQUFDO1NBQ25CO2FBQU07WUFDSCxJQUFJLENBQUMsU0FBUyxDQUFDLFlBQVksQ0FBQyxHQUFHLElBQUksQ0FBQyxNQUFNLENBQUMsWUFBWSxDQUFDLENBQUM7WUFDekQsSUFBSSxDQUFDLE1BQU0sR0FBRyxNQUFNLENBQUMsTUFBTSxDQUFDLEVBQUUsRUFBRSxJQUFJLENBQUMsU0FBUyxDQUFDLENBQUM7U0FDbkQ7UUFFRCxLQUFLLENBQUMsWUFBWSxDQUFDLEdBQUcsRUFBRSxDQUFDLElBQUksQ0FBQyxTQUFTLEVBQUUsQ0FBQyxDQUFDO0lBQy9DLENBQUM7SUFFTyxTQUFTO1FBQ2IsS0FBSyxDQUFDLE1BQU0sRUFBRSxDQUFDO1FBQ2YsS0FBSyxDQUFDLGVBQWUsQ0FBQyxHQUFHLENBQUMsQ0FBQztRQUMzQixLQUFLLENBQUMsZUFBZSxDQUFDLEdBQUcsQ0FBQyxDQUFDO1FBRTNCLElBQUksQ0FBQyxTQUFTLEdBQUcsSUFBSSxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDO1FBQzdDLElBQUksQ0FBQyxhQUFhLEdBQUcsSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUM7UUFDcEMsb0NBQW9DO1FBQ3BDLElBQUksTUFBTSxHQUFHLElBQUksQ0FBQyxZQUFZLENBQUMsSUFBSSxFQUFFLENBQUMscUJBQXFCLEVBQUUsQ0FBQyxNQUFNLENBQUM7UUFDckUsSUFBSSxLQUFLLEdBQUcsSUFBSSxDQUFDLFlBQVksQ0FBQyxJQUFJLEVBQUUsQ0FBQyxxQkFBcUIsRUFBRSxDQUFDLEtBQUssQ0FBQztRQUNuRSxJQUFJLENBQUMsS0FBSyxHQUFHLEtBQUssQ0FBQztRQUNuQixJQUFJLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxXQUFXLEVBQUUsWUFBWSxHQUFHLENBQUMsS0FBSyxHQUFHLENBQUMsQ0FBQyxHQUFHLEdBQUcsR0FBRyxDQUFDLE1BQU0sR0FBRyxDQUFDLENBQUMsR0FBRyxHQUFHLENBQUMsQ0FBQztRQUVwRiw4SUFBOEk7UUFDOUksc0JBQXNCO1FBQ3RCLHFCQUFxQjtRQUNyQixLQUFLO1FBQ0wsSUFBSSxDQUFDLGtCQUFrQixDQUFDLEtBQUssQ0FBQyxLQUFLLEVBQUUsQ0FBQyxDQUFDLENBQUM7UUFDeEMsSUFBSSxDQUFDLGtCQUFrQixDQUFDLEtBQUssQ0FBQyxNQUFNLEVBQUUsQ0FBQyxDQUFDLENBQUM7UUFFekMsSUFBSSxJQUFJLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxLQUFLLFFBQVEsRUFBRTtZQUNoQyxJQUFJLENBQUMsV0FBVyxDQUFDLEVBQUUsTUFBTSxFQUFFLE1BQU0sRUFBRSxDQUFDLENBQUM7U0FDeEM7YUFBTSxJQUFJLElBQUksQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLEtBQUssT0FBTyxFQUFFO1lBQ3RDLElBQUksQ0FBQyxVQUFVLENBQUMsRUFBRSxNQUFNLEVBQUUsTUFBTSxFQUFFLENBQUMsQ0FBQztTQUN2QzthQUFNO1lBQ0gsSUFBSSxDQUFDLGFBQWEsQ0FBQyxFQUFFLE1BQU0sRUFBRSxNQUFNLEVBQUUsS0FBSyxFQUFFLEtBQUssRUFBRSxDQUFDLENBQUM7U0FDeEQ7SUFDTCxDQUFDO0lBRUQ7Ozs7Ozs7T0FPRztJQUNLLFFBQVE7UUFDWixJQUFJLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxXQUFXLEVBQUU7WUFDMUIsSUFBSSxJQUFJLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxFQUFFO2dCQUN0QixJQUFJLENBQUMsT0FBTyxHQUFHLElBQUksQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDO2dCQUNqQyxrREFBa0Q7Z0JBQ2xELElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxHQUFHLElBQUksQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDO2FBQ3RDO1NBQ0o7YUFBTTtZQUNILHNEQUFzRDtZQUN0RCxJQUFJLENBQUMsT0FBTyxHQUFHLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDO1NBQ2pDO0lBQ0wsQ0FBQztJQUVPLFdBQVc7UUFDZixJQUFJLE9BQU8sSUFBSSxDQUFDLEtBQUssS0FBSyxXQUFXO1lBQUUsSUFBSSxDQUFDLEtBQUssQ0FBQyxNQUFNLEVBQUUsQ0FBQztRQUMzRCxJQUFJLE9BQU8sSUFBSSxDQUFDLFdBQVcsS0FBSyxXQUFXO1lBQUUsSUFBSSxDQUFDLFdBQVcsQ0FBQyxNQUFNLEVBQUUsQ0FBQztRQUN2RSxJQUFJLE9BQU8sSUFBSSxDQUFDLFVBQVUsS0FBSyxXQUFXO1lBQUUsSUFBSSxDQUFDLFVBQVUsQ0FBQyxNQUFNLEVBQUUsQ0FBQztRQUNyRSxJQUFJLE9BQU8sSUFBSSxDQUFDLEtBQUssS0FBSyxXQUFXO1lBQUUsSUFBSSxDQUFDLEtBQUssQ0FBQyxNQUFNLEVBQUUsQ0FBQztRQUMzRCxJQUFJLE9BQU8sSUFBSSxDQUFDLFNBQVMsS0FBSyxXQUFXO1lBQUUsSUFBSSxDQUFDLFNBQVMsQ0FBQyxNQUFNLEVBQUUsQ0FBQztRQUNuRSxJQUFJLE9BQU8sSUFBSSxDQUFDLFFBQVEsS0FBSyxXQUFXO1lBQUUsSUFBSSxDQUFDLFFBQVEsQ0FBQyxNQUFNLEVBQUUsQ0FBQztRQUNqRSxJQUFJLE9BQU8sSUFBSSxDQUFDLGVBQWUsS0FBSyxXQUFXO1lBQUUsSUFBSSxDQUFDLGVBQWUsQ0FBQyxNQUFNLEVBQUUsQ0FBQztRQUMvRSxJQUFJLElBQUksQ0FBQyxrQkFBa0I7WUFBRSxJQUFJLENBQUMsa0JBQWtCLENBQUMsU0FBUyxDQUFDLEdBQUcsQ0FBQyxDQUFDLE1BQU0sRUFBRSxDQUFDO1FBQzdFLElBQUksQ0FBQyxTQUFTLEdBQUcsRUFBRSxDQUFDO1FBQ3BCLGFBQWEsQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLENBQUM7UUFDOUIsS0FBSyxDQUFDLFdBQVcsRUFBRSxDQUFDO0lBQ3hCLENBQUM7SUFFTyxhQUFhLENBQUMsT0FBMEM7UUFDNUQsSUFBSSxNQUFNLEdBQUcsSUFBSSxDQUFDLEdBQUcsQ0FBQyxPQUFPLENBQUMsS0FBSyxFQUFFLE9BQU8sQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLENBQUM7UUFDekQsSUFBSSxJQUFJLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxJQUFJLElBQUksQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLEtBQUssTUFBTSxFQUFFO1lBQ25ELE1BQU0sR0FBRyxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsT0FBTyxDQUFDLEtBQUssRUFBRSxPQUFPLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDO1lBQzNELElBQUksQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLFdBQVcsRUFBRSxZQUFZLEdBQUcsQ0FBQyxPQUFPLENBQUMsS0FBSyxHQUFHLENBQUMsQ0FBQyxHQUFHLEdBQUcsR0FBRyxDQUFDLENBQUMsT0FBTyxDQUFDLE1BQU0sR0FBRyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsR0FBRyxHQUFHLENBQUMsQ0FBQztTQUM3RztRQUNELElBQUksV0FBVyxHQUFHLElBQUksQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLEtBQUssS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxXQUFXLENBQUMsR0FBRyxDQUFDLFdBQVcsR0FBRyxHQUFHLENBQUMsR0FBRyxNQUFNLEdBQUcsR0FBRyxDQUFDO1FBQ25ILElBQUksR0FBRyxHQUFHLEVBQUUsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxXQUFXLENBQUMsV0FBVyxDQUFDLENBQUMsV0FBVyxDQUFDLE1BQU0sR0FBRyxHQUFHLENBQUMsQ0FBQztRQUN0RSxJQUFJLFFBQVEsR0FBRyxFQUFFLENBQUMsR0FBRyxFQUFFLENBQUMsV0FBVyxDQUFDLE1BQU0sR0FBRyxHQUFHLENBQUMsQ0FBQyxXQUFXLENBQUMsTUFBTSxHQUFHLEdBQUcsQ0FBQyxDQUFDO1FBQzVFLG1FQUFtRTtRQUNuRSxJQUFJLEdBQUcsR0FBRyxFQUFFLENBQUMsR0FBRyxFQUFFLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsRUFBRSxFQUFFLEdBQUcsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7UUFDNUQsSUFBSSxjQUFjLEdBQUcsSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsS0FBSyxNQUFNLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztRQUNoRSxHQUFHLEdBQUcsSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsS0FBSyxNQUFNLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxVQUFVLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxFQUFFLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxVQUFVLENBQUMsQ0FBQyxFQUFFLEdBQUcsQ0FBQyxJQUFJLENBQUMsRUFBRSxHQUFHLEdBQUcsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLEVBQUUsR0FBRyxDQUFDLElBQUksQ0FBQyxFQUFFLEdBQUcsR0FBRyxDQUFDLENBQUMsQ0FBQztRQUVwSixJQUFJLENBQUMsS0FBSyxHQUFHLElBQUksQ0FBQyxLQUFLLENBQUMsU0FBUyxDQUFDLE1BQU0sQ0FBQzthQUNwQyxJQUFJLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsQ0FBQzthQUN2QixLQUFLLEVBQUU7YUFDUCxNQUFNLENBQUMsTUFBTSxDQUFDO2FBQ2QsSUFBSSxDQUFDLFlBQVksRUFBRSxDQUFDLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUM7YUFDbkMsSUFBSSxDQUFDLGtCQUFrQixFQUFFLENBQUMsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDO2FBQzVELElBQUksQ0FBQyxPQUFPLEVBQUUsQ0FBQyxDQUFDLEVBQUUsRUFBRTtZQUNqQixJQUFJLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQyxFQUFFLEdBQUcsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLEtBQUssRUFBRSxPQUFPLEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLEVBQUUsSUFBSSxFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsS0FBSyxFQUFFLENBQUMsQ0FBQztZQUNsRixPQUFPLElBQUksR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDLEtBQUssR0FBRyxLQUFLLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUM7WUFDbEQsb0VBQW9FO1FBQ3hFLENBQUMsQ0FBQzthQUNELElBQUksQ0FBQyxJQUFJLEVBQUUsQ0FBQyxDQUFDLEVBQUUsRUFBRTtZQUNkLE9BQU8sQ0FBQyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUM7WUFDcEIsc0NBQXNDO1FBQzFDLENBQUMsQ0FBQzthQUNELElBQUksQ0FBQyxNQUFNLEVBQUUsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLEVBQUU7WUFDbkIsT0FBTyxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsaUNBQWlDO1FBQzFFLENBQUMsQ0FBQztZQUNGLGtCQUFrQjthQUNqQixLQUFLLENBQUMsUUFBUSxFQUFFLElBQUksQ0FBQyxNQUFNLENBQUMsV0FBVyxDQUFDLEdBQUcsQ0FBQyxXQUFXLENBQUM7YUFDeEQsS0FBSyxDQUFDLGNBQWMsRUFBRSxJQUFJLENBQUMsTUFBTSxDQUFDLFdBQVcsQ0FBQyxHQUFHLENBQUMsV0FBVyxJQUFJLENBQUMsQ0FBQyxDQUFDO1FBRXpFLElBQUksV0FBVyxHQUFHO1lBQ2QsS0FBSyxFQUFFLEdBQUc7WUFDVixLQUFLLEVBQUUsR0FBRztZQUNWLFVBQVUsRUFBRSxRQUFRO1lBQ3BCLFFBQVEsRUFBRSxNQUFNO1lBQ2hCLGdCQUFnQixFQUFFLGNBQWM7U0FFbkMsQ0FBQztRQUVGLElBQUksQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLFNBQVMsRUFBRTtZQUN4QixJQUFJLENBQUMsS0FBSztpQkFDTCxJQUFJLENBQUMsR0FBRyxFQUFFLENBQUMsQ0FBQyxFQUFFLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDO2lCQUN0QixJQUFJLENBQUMsS0FBSyxFQUFFLENBQUMsQ0FBQyxFQUFFLENBQUMsTUFBTSxDQUFDLENBQUMsRUFBRSxJQUFJLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztZQUVwRCxJQUFJLENBQUMsYUFBYSxDQUFDLFdBQVcsQ0FBQyxDQUFDO1NBRW5DO2FBQU07WUFDSCxJQUFJLENBQUMsS0FBSyxDQUFDLFVBQVUsRUFBRTtpQkFDbEIsS0FBSyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFO2dCQUNaLE9BQU8sQ0FBQyxHQUFHLEVBQUUsQ0FBQztZQUNsQixDQUFDLENBQUM7aUJBQ0QsU0FBUyxDQUFDLEdBQUcsRUFBRSxDQUFDLENBQUMsRUFBRSxFQUFFO2dCQUNsQixJQUFJLENBQUMsR0FBRyxFQUFFLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQyxVQUFVLEVBQUUsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDO2dCQUNqRCxPQUFPLENBQUMsQ0FBQyxFQUFFLEVBQUU7b0JBQ1QsQ0FBQyxDQUFDLFFBQVEsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7b0JBQ2xCLE9BQU8sR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDO2dCQUNsQixDQUFDLENBQUM7WUFDTixDQUFDLENBQUM7aUJBQ0QsU0FBUyxDQUFDLEtBQUssRUFBRSxDQUFDLENBQUMsRUFBRSxFQUFFO2dCQUNwQixJQUFJLE9BQU8sQ0FBQztnQkFDWixPQUFPLEdBQUcsT0FBTyxJQUFJLENBQUMsQ0FBQztnQkFDdkIsSUFBSSxXQUFXLEdBQUcsRUFBRSxDQUFDLFdBQVcsQ0FBQyxPQUFPLEVBQUUsQ0FBQyxDQUFDLENBQUM7Z0JBQzdDLE9BQU8sR0FBRyxXQUFXLENBQUMsQ0FBQyxDQUFDLENBQUM7Z0JBQ3pCLE9BQU8sQ0FBQyxDQUFDLEVBQUUsRUFBRTtvQkFDVCxJQUFJLEVBQUUsR0FBRyxXQUFXLENBQUMsQ0FBQyxDQUFDLENBQUM7b0JBQ3hCLE9BQU8sTUFBTSxDQUFDLEVBQUUsRUFBRSxJQUFJLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7Z0JBQ3pDLENBQUMsQ0FBQztZQUNOLENBQUMsQ0FBQztpQkFDRCxFQUFFLENBQUMsS0FBSyxFQUFFLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFO2dCQUNoQixJQUFJLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsTUFBTSxHQUFHLENBQUMsQ0FBQyxFQUFFO29CQUNqQyxVQUFVLENBQUMsR0FBRyxFQUFFO3dCQUNaLElBQUksQ0FBQyxhQUFhLENBQUMsV0FBVyxDQUFDLENBQUM7b0JBQ3BDLENBQUMsQ0FBQyxDQUFDO2lCQUNOO1lBQ0wsQ0FBQyxDQUFDLENBQUM7U0FDVjtRQUVELElBQUksQ0FBQyxLQUFLLENBQUMsSUFBSSxFQUFFLENBQUMsTUFBTSxFQUFFLENBQUM7UUFFM0IsU0FBUyxNQUFNLENBQUMsR0FBRyxFQUFFLFVBQVU7WUFDM0IsSUFBSSxHQUFHLEdBQUcsUUFBUSxDQUFDLFFBQVEsQ0FBQyxHQUFHLENBQUMsQ0FBQztZQUNqQyxJQUFJLFVBQVUsSUFBSSxVQUFVLEtBQUssTUFBTSxFQUFFO2dCQUNyQyxHQUFHLENBQUMsQ0FBQyxDQUFDLEdBQUcsTUFBTSxHQUFHLENBQUMsUUFBUSxDQUFDLEdBQUcsQ0FBQyxHQUFHLGNBQWMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO2FBQy9EO2lCQUFNO2dCQUNILEdBQUcsQ0FBQyxDQUFDLENBQUMsR0FBRyxNQUFNLEdBQUcsQ0FBQyxRQUFRLENBQUMsR0FBRyxDQUFDLEdBQUcsY0FBYyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7YUFDL0Q7WUFDRCxPQUFPLEdBQUcsQ0FBQztRQUNmLENBQUM7UUFFRCxTQUFTLFFBQVEsQ0FBQyxFQUFFO1lBQ2hCLE9BQU8sRUFBRSxDQUFDLFVBQVUsR0FBRyxDQUFDLEVBQUUsQ0FBQyxRQUFRLEdBQUcsRUFBRSxDQUFDLFVBQVUsQ0FBQyxHQUFHLENBQUMsQ0FBQztRQUM3RCxDQUFDO1FBQ0QsSUFBSSxXQUFXLEdBQUc7WUFDZCxhQUFhLEVBQUUsV0FBVztZQUMxQixhQUFhLEVBQUUsTUFBTSxHQUFHLEdBQUc7WUFDM0IsVUFBVSxFQUFFLElBQUksQ0FBQyxTQUFTO1NBQzdCLENBQUM7UUFDRixLQUFLLENBQUMsZ0JBQWdCLENBQUMsSUFBSSxDQUFDLEtBQUssRUFBRSxXQUFXLENBQUMsQ0FBQztJQUNwRCxDQUFDO0lBRU8sV0FBVyxDQUFDLE9BQTJDO1FBQzNELDJIQUEySDtRQUMzSCxJQUFJLFdBQVcsR0FBRyxPQUFPLENBQUMsTUFBTSxHQUFHLENBQUMsR0FBRyxFQUFFLENBQUM7UUFDMUMsSUFBSSxLQUFLLEdBQUcsRUFBRSxDQUFDLFdBQVcsRUFBRTthQUN2QixNQUFNLENBQUMsQ0FBQyxDQUFDLEVBQUUsRUFBRSxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsT0FBTyxFQUFFLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLEdBQUcsQ0FBQyxDQUFDO2FBQ2pELEtBQUssQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEdBQUcsRUFBRSxDQUFDLENBQUMsQ0FBQztRQUN4QixJQUFJLEtBQUssR0FBRyxLQUFLLENBQUMsS0FBSyxDQUFDLFFBQVEsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQztRQUMvQyxJQUFJLElBQUksR0FBRyxJQUFJLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztRQUMzQyxpQkFBaUI7UUFDakIsTUFBTSxPQUFPLEdBQUcsSUFBSSxDQUFDLE1BQU0sQ0FBQztRQUM1QixNQUFNLFFBQVEsR0FBRyxDQUFDLFdBQVcsR0FBRyxZQUFZLEdBQUcsT0FBTyxHQUFHLFVBQVUsQ0FBQyxHQUFHLE9BQU8sQ0FBQztRQUUvRSxJQUFJLEdBQUcsR0FBRyxFQUFFLENBQUMsR0FBRyxFQUFFO2FBQ2IsV0FBVyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFLENBQUMsSUFBSSxDQUFDLGVBQWUsQ0FBQyxDQUFDLEVBQUUsT0FBTyxFQUFFLFFBQVEsQ0FBQyxDQUFDO2FBQ2pFLFdBQVcsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRSxDQUFDLElBQUksQ0FBQyxlQUFlLENBQUMsQ0FBQyxFQUFFLE9BQU8sRUFBRSxRQUFRLENBQUMsQ0FBQzthQUNqRSxVQUFVLENBQUMsQ0FBQyxDQUFDO2FBQ2IsUUFBUSxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7UUFFbEMsSUFBSSxDQUFDLFdBQVcsR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUM7YUFDcEMsSUFBSSxDQUFDLE9BQU8sRUFBRSxxQ0FBcUMsQ0FBQzthQUNwRCxTQUFTLENBQUMsR0FBRyxDQUFDO2FBQ2QsSUFBSSxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUM7YUFDbEIsS0FBSyxFQUFFLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDO1FBRXpCLElBQUksQ0FBQyxXQUFXLENBQUMsTUFBTSxDQUFDLFFBQVEsQ0FBQzthQUM1QixJQUFJLENBQUMsR0FBRyxFQUFFLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFLENBQUMsSUFBSSxDQUFDLGVBQWUsQ0FBQyxDQUFDLEVBQUUsT0FBTyxFQUFFLFFBQVEsQ0FBQyxHQUFHLFVBQVUsQ0FBQyxDQUFDO1FBRWxGLElBQUksQ0FBQyxXQUFXLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQzthQUMxQixJQUFJLENBQUMsR0FBRyxFQUFFLFlBQVksQ0FBQzthQUN2QixJQUFJLENBQUMsR0FBRyxFQUFFLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsZUFBZSxDQUFDLENBQUMsRUFBRSxPQUFPLEVBQUUsUUFBUSxDQUFDLEdBQUcsVUFBVSxDQUFDO2FBQzdFLEtBQUssQ0FBQyxXQUFXLEVBQUUsTUFBTSxDQUFDO2FBQzFCLElBQUksQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztRQUVwQixJQUFJLENBQUMsVUFBVSxHQUFHLElBQUksQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQzthQUNuQyxJQUFJLENBQUMsT0FBTyxFQUFFLHFDQUFxQyxDQUFDO2FBQ3BELFNBQVMsQ0FBQyxHQUFHLENBQUM7YUFDZCxJQUFJLENBQUMsS0FBSyxDQUFDO2FBQ1gsS0FBSyxFQUFFLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQzthQUNuQixJQUFJLENBQUMsV0FBVyxFQUFFLENBQUMsQ0FBQyxFQUFFLENBQUMsU0FBUyxHQUFHLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxFQUFFLENBQUMsR0FBRyxHQUFHLENBQUMsQ0FBQztRQUU5RSxJQUFJLENBQUMsVUFBVSxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUM7YUFDekIsSUFBSSxDQUFDLElBQUksRUFBRSxXQUFXLENBQUMsQ0FBQztRQUU3QixJQUFJLENBQUMsVUFBVSxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUM7YUFDekIsSUFBSSxDQUFDLEdBQUcsRUFBRSxXQUFXLEdBQUcsRUFBRSxDQUFDO2FBQzNCLEtBQUssQ0FBQyxhQUFhLEVBQUUsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsSUFBSSxFQUFFLElBQUksS0FBSyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsR0FBRyxFQUFFLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUM7YUFDL0UsS0FBSyxDQUFDLFdBQVcsRUFBRSxNQUFNLENBQUM7YUFDMUIsSUFBSSxDQUFDLFdBQVcsRUFBRSxDQUFDLENBQUMsRUFBRSxDQUFDLFNBQVMsR0FBRyxDQUFDLEVBQUUsR0FBRyxJQUFJLENBQUMsUUFBUSxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsR0FBRyxHQUFHLENBQUMsV0FBVyxHQUFHLEVBQUUsQ0FBQyxHQUFHLEtBQUssQ0FBQzthQUNyRyxJQUFJLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQztRQUVsQixZQUFZO1FBQ1osSUFBSSxDQUFDLEtBQUssR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUM7YUFDOUIsU0FBUyxDQUFDLE1BQU0sQ0FBQzthQUNqQixJQUFJLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQzthQUNsQixLQUFLLEVBQUUsQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDO2FBQ3RCLElBQUksQ0FBQyxPQUFPLEVBQUUsQ0FBQyxDQUFDLEVBQUUsRUFBRTtZQUNqQixPQUFPLElBQUksR0FBRyxDQUFDLENBQUMsS0FBSyxHQUFHLEtBQUssR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDO1FBQ3hDLENBQUMsQ0FBQzthQUNELEtBQUssQ0FBQyxNQUFNLEVBQUUsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQztRQUV0RCxJQUFJLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxTQUFTLEVBQUU7WUFDeEIsSUFBSSxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsR0FBRyxFQUFFLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQztTQUMvQzthQUFNO1lBQ0gsSUFBSSxDQUFDLEtBQUssQ0FBQyxVQUFVLEVBQUU7aUJBQ2xCLEtBQUssQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUMsR0FBRyxHQUFHLENBQUM7aUJBQ3hCLFFBQVEsQ0FBQyxHQUFHLENBQUM7Z0JBQ2QsNkJBQTZCO2lCQUM1QixTQUFTLENBQUMsR0FBRyxFQUFFLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFO2dCQUNyQixJQUFJLFdBQVcsR0FBRyxFQUFFLENBQUMsV0FBVyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7Z0JBQ3pDLE9BQU8sQ0FBQyxDQUFDLEVBQUUsQ0FBQyxHQUFHLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDO1lBQ3ZDLENBQUMsQ0FBQyxDQUFDO1NBQ1Y7UUFFRCxLQUFLLENBQUMsZ0JBQWdCLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFDO0lBQ3ZDLENBQUM7SUFFTyxVQUFVLENBQUMsT0FBMkI7UUFDMUMsd0JBQXdCO1FBQ3hCLElBQUksT0FBTyxHQUFHLElBQUksQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLE1BQU0sRUFBRSxHQUFHLEdBQUcsQ0FBQyxDQUFDO1FBQzlDLElBQUksUUFBUSxHQUFHLElBQUksQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLEtBQUssTUFBTSxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsRUFBRSxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQztRQUNwRSxJQUFJLFdBQVcsR0FBRyxPQUFPLENBQUMsTUFBTSxHQUFHLENBQUMsQ0FBQztRQUNyQyxJQUFJLFdBQVcsR0FBRyxDQUFDLFdBQVcsR0FBRyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUM7UUFDeEMsSUFBSSxRQUFRLEdBQUcsV0FBVyxHQUFHLEdBQUcsQ0FBQztRQUVqQyxJQUFJLEdBQUcsR0FBRyxFQUFFLENBQUMsR0FBRyxFQUFFO2FBQ2IsV0FBVyxDQUFDLFdBQVcsQ0FBQzthQUN4QixXQUFXLENBQUMsV0FBVyxDQUFDO2FBQ3hCLFVBQVUsQ0FBQyxDQUFDLENBQUM7YUFDYixRQUFRLENBQUMsUUFBUSxDQUFDLENBQUM7UUFFeEIsSUFBSSxPQUFPLEdBQUcsRUFBRSxDQUFDLEdBQUcsRUFBRTthQUNqQixXQUFXLENBQUMsV0FBVyxDQUFDO2FBQ3hCLFdBQVcsQ0FBQyxXQUFXLENBQUM7YUFDeEIsVUFBVSxDQUFDLENBQUMsQ0FBQyxDQUFDO1FBRW5CLElBQUksQ0FBQyxLQUFLLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDO2FBQ2pDLElBQUksQ0FBQyxHQUFHLEVBQUUsR0FBRyxDQUFDO2FBQ2QsSUFBSSxDQUFDLFdBQVcsRUFBRSxhQUFhLENBQUM7YUFDaEMsSUFBSSxDQUFDLGNBQWMsRUFBRSxDQUFDLENBQUM7YUFDdkIsSUFBSSxDQUFDLFFBQVEsRUFBRSxTQUFTLENBQUM7YUFDekIsS0FBSyxDQUFDLE1BQU0sRUFBRSxTQUFTLENBQUMsQ0FBQztRQUc5QixJQUFJLENBQUMsUUFBUSxHQUFHLElBQUksQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQztZQUNyQyxpREFBaUQ7YUFDaEQsS0FBSyxDQUFDLEVBQUUsUUFBUSxFQUFFLENBQUMsRUFBRSxDQUFDO2FBQ3RCLElBQUksQ0FBQyxHQUFHLEVBQUUsT0FBTyxDQUFDO2FBQ2xCLElBQUksQ0FBQyxXQUFXLEVBQUUsYUFBYSxDQUFDLENBQUM7UUFHdEMsSUFBSSxDQUFDLGVBQWUsR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUM7YUFDM0MsS0FBSyxDQUFDLENBQUMsQ0FBQzthQUNSLElBQUksQ0FBQyxVQUFTLENBQUM7WUFDWixPQUFPLENBQUMsQ0FBQztRQUNiLENBQUMsQ0FBQzthQUNELElBQUksQ0FBQyxPQUFPLEVBQUUsdUJBQXVCLENBQUM7YUFDdEMsSUFBSSxDQUFDLGFBQWEsRUFBRSxRQUFRLENBQUM7YUFDN0IsSUFBSSxDQUFDLElBQUksRUFBRSxJQUFJLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxLQUFLLE1BQU0sQ0FBQyxDQUFDLENBQUMsUUFBUSxHQUFHLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO2FBQzlELEtBQUssQ0FBQyxNQUFNLEVBQUUsRUFBRSxDQUFDLEdBQUcsQ0FBQyxTQUFTLENBQUMsQ0FBQzthQUNoQyxLQUFLLENBQUMsV0FBVyxFQUFFLFFBQVEsR0FBRyxJQUFJLENBQUMsQ0FBQztRQUV6QyxJQUFJLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxTQUFTLEVBQUU7WUFDeEIsSUFBSSxDQUFDLFFBQVE7aUJBQ1IsSUFBSSxDQUFDLEdBQUcsRUFBRSxDQUFDLENBQUMsRUFBRSxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQztpQkFDMUIsS0FBSyxDQUFDLE1BQU0sRUFBRSxFQUFFLENBQUMsR0FBRyxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUM7WUFDdEMsT0FBTztTQUNWO1FBRUQsSUFBSSxRQUFRLEdBQUcsVUFBUyxVQUFVLEVBQUUsUUFBUSxFQUFFLElBQUk7WUFDOUMsVUFBVSxDQUFDLFNBQVMsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxDQUFDLEVBQUUsRUFBRTtnQkFDNUIsSUFBSSxXQUFXLEdBQUcsRUFBRSxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUMsUUFBUSxFQUFFLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxHQUFHLENBQUMsUUFBUSxHQUFHLEdBQUcsQ0FBQyxDQUFDLENBQUM7Z0JBQzlFLElBQUksZ0JBQWdCLEdBQUcsRUFBRSxDQUFDLFdBQVcsQ0FBQyxDQUFDLEVBQUUsUUFBUSxDQUFDLENBQUM7Z0JBRW5ELE9BQU8sQ0FBQyxDQUFDLEVBQUUsRUFBRTtvQkFDVCxDQUFDLENBQUMsUUFBUSxHQUFHLFdBQVcsQ0FBQyxDQUFDLENBQUMsQ0FBQztvQkFDNUIsSUFBSSxDQUFDLGVBQWUsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLEdBQUcsQ0FBQyxDQUFDO29CQUNqRSxPQUFPLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQztnQkFDdEIsQ0FBQyxDQUFDO1lBQ04sQ0FBQyxDQUFDLENBQUM7UUFDUCxDQUFDLENBQUM7UUFFRixJQUFJLENBQUMsUUFBUSxDQUFDLFVBQVUsRUFBRTthQUNyQixRQUFRLENBQUMsR0FBRyxDQUFDO2FBQ2IsSUFBSSxDQUFDLEVBQUUsQ0FBQyxXQUFXLENBQUM7YUFDcEIsSUFBSSxDQUFDLFFBQVEsRUFBRSxPQUFPLEVBQUUsSUFBSSxDQUFDO2FBQzdCLEtBQUssQ0FBQyxNQUFNLEVBQUUsRUFBRSxDQUFDLEdBQUcsQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDO0lBQzFDLENBQUM7SUFFTyxhQUFhLENBQUMsT0FBWTtRQUM5QixJQUFJLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLE9BQU87WUFBRSxPQUFPO1FBQzlDLElBQUksSUFBSSxDQUFDLGFBQWEsS0FBSyxLQUFLO1lBQUUsT0FBTztRQUN6QyxJQUFJLElBQUksQ0FBQyxTQUFTLENBQUMsTUFBTSxLQUFLLENBQUM7WUFBRSxPQUFPO1FBQ3hDLElBQUksSUFBSSxHQUFHLEtBQUssQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLGdCQUFnQixDQUFDLEdBQUcsR0FBRyxJQUFJLENBQUMsTUFBTSxDQUFDLEVBQUUsR0FBRywrQkFBK0IsQ0FBQyxDQUFDLENBQUM7UUFDekcsSUFBSSxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxVQUFVLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7UUFFL0MsSUFBSSxHQUFHLEdBQUcsQ0FBQyxDQUFDLEVBQUUsRUFBRSxHQUFHLE9BQU8sQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7UUFFdEMsU0FBUyxRQUFRLENBQUMsRUFBRTtZQUNoQixPQUFPLEVBQUUsQ0FBQyxVQUFVLEdBQUcsQ0FBQyxFQUFFLENBQUMsUUFBUSxHQUFHLEVBQUUsQ0FBQyxVQUFVLENBQUMsR0FBRyxDQUFDLENBQUM7UUFDN0QsQ0FBQztRQUVELElBQUksTUFBTSxHQUFHLElBQUksQ0FBQyxZQUFZLENBQUMsSUFBSSxFQUFFLENBQUMscUJBQXFCLEVBQUUsQ0FBQyxNQUFNLENBQUM7UUFDckUsSUFBSSxLQUFLLEdBQUcsSUFBSSxDQUFDLFlBQVksQ0FBQyxJQUFJLEVBQUUsQ0FBQyxxQkFBcUIsRUFBRSxDQUFDLEtBQUssQ0FBQztRQUNuRSxNQUFNLEdBQUcsQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxJQUFJLElBQUksQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLEtBQUssTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLEdBQUcsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLEdBQUcsQ0FBQyxHQUFHLENBQUMsQ0FBQztRQUN2RyxLQUFLLElBQUksQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxFQUFFLENBQUMsRUFBRSxFQUFFO1lBQ25ELElBQUksSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsSUFBSSxJQUFJLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsS0FBSyxTQUFTLEVBQUU7Z0JBQ3pELElBQUksVUFBVSxHQUFHLFFBQVEsQ0FBQyxhQUFhLENBQUMsR0FBRyxHQUFHLElBQUksQ0FBQyxNQUFNLENBQUMsRUFBRSxHQUFHLElBQUksR0FBRyxJQUFJLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLFlBQVksQ0FBQyxLQUFLLENBQUMsQ0FBQztnQkFDaEgsSUFBSSxJQUFJLENBQUMsU0FBUyxDQUFDLE1BQU0sS0FBSyxDQUFDLElBQUksUUFBUSxDQUFDLGFBQWEsQ0FBQyxHQUFHLEdBQUcsSUFBSSxDQUFDLE1BQU0sQ0FBQyxFQUFFLEdBQUcsSUFBSSxHQUFHLElBQUksQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEtBQUssSUFBSSxJQUFJLFVBQVUsS0FBSyxJQUFJLEVBQUU7b0JBQzNJLElBQUksS0FBSyxHQUFHO3dCQUNSLElBQUksRUFBRSxJQUFJLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUU7d0JBQzFCLE9BQU8sRUFBRSxJQUFJLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUs7cUJBQ25DLENBQUM7b0JBQ0YsSUFBSSxNQUFNLEdBQVcsUUFBUSxDQUFDLFVBQVUsQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxLQUFLLEdBQUcsQ0FBQyxDQUFDO29CQUNwRSxJQUFJLE1BQU0sR0FBVyxRQUFRLENBQUMsVUFBVSxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLE1BQU0sQ0FBQztvQkFDakUsSUFBSSxhQUFhLEdBQVcsUUFBUSxDQUFDLFVBQVUsQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztvQkFDL0QsSUFBSSxZQUFZLEdBQVksSUFBSSxDQUFDLEtBQUssS0FBSyxLQUFLLENBQUMsQ0FBQyxDQUFDLGFBQWEsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLGFBQWEsR0FBRyxDQUFDLENBQUM7b0JBQ3pGLElBQUksaUJBQWlCLEdBQVcsWUFBWSxDQUFDLENBQUMsQ0FBQyxVQUFVLENBQUMsQ0FBQyxDQUFDLFlBQVksQ0FBQztvQkFDekUsSUFBSSxjQUFjLEdBQUcsR0FBRyxHQUFHLElBQUksQ0FBQyxNQUFNLENBQUMsRUFBRSxHQUFHLDRCQUE0QixHQUFHLElBQUksQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLEtBQUssR0FBRyxLQUFLLENBQUMsRUFBRSxDQUFDO29CQUNsSCxJQUFJLFFBQVEsQ0FBQyxhQUFhLENBQUMsY0FBYyxDQUFDLElBQUksSUFBSSxFQUFFO3dCQUNoRCxLQUFLLENBQUMsUUFBUSxDQUFDLEtBQUssRUFBRSxJQUFJLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxNQUFNLEVBQUUsTUFBTSxDQUFDLENBQUMsS0FBSyxDQUFDLFlBQVksRUFBRSxTQUFTLENBQUMsQ0FBQyxLQUFLLENBQUMsT0FBTyxFQUFFLEtBQUssQ0FBQyxDQUFDLEtBQUssQ0FBQyxpQkFBaUIsRUFBRSxpQkFBaUIsQ0FBQyxDQUFDO3FCQUMvSjtpQkFDSjthQUNKO1NBQ0o7UUFFRCxJQUFJLENBQUMsU0FBUyxHQUFHLElBQUksQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQzthQUNsQyxJQUFJLENBQUMsT0FBTyxFQUFFLGtCQUFrQixDQUFDO2FBQ2pDLFNBQVMsQ0FBQyxVQUFVLENBQUM7YUFDckIsSUFBSSxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxFQUFFLEdBQUcsQ0FBQzthQUNwQyxLQUFLLEVBQUU7YUFDUCxNQUFNLENBQUMsVUFBVSxDQUFDO2FBQ2xCLEtBQUssQ0FBQyxRQUFRLEVBQUUsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLEVBQUU7WUFDdEIsT0FBTyxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDLENBQUMsS0FBSyxDQUFDO1FBQ3hDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxRQUFRLEVBQUUsQ0FBQyxDQUFDLEVBQUUsRUFBRTtZQUNwQixPQUFPLE1BQU0sQ0FBQyxDQUFDLEVBQUUsSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO1FBQ3hDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxNQUFNLEVBQUUsTUFBTSxDQUFDLENBQUM7UUFFN0IsZ0NBQWdDO1FBQ2hDLDZDQUE2QztRQUM3QywrQ0FBK0M7UUFDL0MsVUFBVTtRQUNWLGNBQWM7UUFDZCxJQUFJO1FBRUosNkNBQTZDO1FBQzdDLG9DQUFvQztRQUNwQyw4Q0FBOEM7UUFDOUMsOERBQThEO1FBQzlELDBDQUEwQztRQUMxQywwQkFBMEI7UUFDMUIsdUNBQXVDO1FBQ3ZDLG9EQUFvRDtRQUNwRCxhQUFhO1FBQ2IsVUFBVTtRQUVWLFNBQVMsTUFBTSxDQUFDLEdBQUcsRUFBRSxVQUFVO1lBQzNCLElBQUksR0FBRyxHQUFHLE9BQU8sQ0FBQyxRQUFRLENBQUMsUUFBUSxDQUFDLEdBQUcsQ0FBQyxDQUFDO1lBQ3pDLElBQUksVUFBVSxJQUFJLFVBQVUsS0FBSyxNQUFNLEVBQUU7Z0JBQ3JDLEdBQUcsQ0FBQyxDQUFDLENBQUMsR0FBRyxPQUFPLENBQUMsTUFBTSxHQUFHLElBQUksR0FBRyxDQUFDLFFBQVEsQ0FBQyxHQUFHLENBQUMsR0FBRyxPQUFPLENBQUMsY0FBYyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7YUFDdEY7aUJBQU07Z0JBQ0gsR0FBRyxDQUFDLENBQUMsQ0FBQyxHQUFHLE9BQU8sQ0FBQyxNQUFNLEdBQUcsSUFBSSxHQUFHLENBQUMsUUFBUSxDQUFDLEdBQUcsQ0FBQyxHQUFHLE9BQU8sQ0FBQyxjQUFjLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQzthQUN0RjtZQUNELE9BQU8sQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLFFBQVEsQ0FBQyxHQUFHLENBQUMsRUFBRSxPQUFPLENBQUMsUUFBUSxDQUFDLFFBQVEsQ0FBQyxHQUFHLENBQUMsRUFBRSxHQUFHLENBQUMsQ0FBQztRQUM1RSxDQUFDO0lBQ0wsQ0FBQztJQUdPLGVBQWUsQ0FBQyxNQUFjLEVBQUUsUUFBZ0IsRUFBRSxTQUFpQjtRQUN2RSxPQUFPLFlBQVksR0FBRyxDQUFDLFFBQVEsR0FBRyxDQUFDLE1BQU0sR0FBRyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsU0FBUyxHQUFHLFVBQVUsQ0FBQyxDQUFDO0lBQy9FLENBQUM7SUFFTyxlQUFlLENBQUMsTUFBYyxFQUFFLFFBQWdCLEVBQUUsU0FBaUI7UUFDdkUsT0FBTyxJQUFJLENBQUMsZUFBZSxDQUFDLE1BQU0sRUFBRSxRQUFRLEVBQUUsU0FBUyxDQUFDLEdBQUcsU0FBUyxDQUFDO0lBQ3pFLENBQUM7SUFFTyxRQUFRLENBQUMsTUFBYztRQUMzQixPQUFPLE1BQU0sR0FBRyxHQUFHLEdBQUcsRUFBRSxDQUFDO0lBQzdCLENBQUM7SUFFTyxTQUFTLENBQUMsS0FBVSxFQUFFLEdBQVEsRUFBRSxZQUFpQixFQUFFLFlBQWlCO1FBQ3hFLFFBQVEsR0FBRyxFQUFFO1lBQ1QsS0FBSyxLQUFLO2dCQUNOLEtBQUssQ0FBQyxVQUFVLEVBQUU7cUJBQ2IsUUFBUSxDQUFDLEdBQUcsQ0FBQztvQkFDZCxrQkFBa0I7cUJBQ2pCLElBQUksQ0FBQyxHQUFHLEVBQUUsRUFBRSxDQUFDLEdBQUcsRUFBRTtxQkFDZCxXQUFXLENBQUMsWUFBWSxDQUFDO3FCQUN6QixXQUFXLENBQUMsWUFBWSxDQUFDLENBQzdCLENBQUMsSUFBSSxDQUFDLFFBQVEsRUFBRSxNQUFNLENBQUMsQ0FBQztnQkFDN0IsTUFBTTtZQUVWLEtBQUssSUFBSTtnQkFDTCxLQUFLLENBQUMsVUFBVSxFQUFFO3FCQUNiLElBQUksQ0FBQyxHQUFHLEVBQUUsRUFBRSxDQUFDLEdBQUcsRUFBRTtxQkFDZCxXQUFXLENBQUMsWUFBWSxDQUFDO3FCQUN6QixXQUFXLENBQUMsWUFBWSxHQUFHLEdBQUcsQ0FBQyxDQUNuQyxDQUFDLElBQUksQ0FBQyxRQUFRLEVBQUUsT0FBTyxDQUFDLENBQUMsSUFBSSxDQUFDLGNBQWMsRUFBRSxDQUFDLENBQUMsQ0FBQztnQkFDdEQsTUFBTTtTQUNiO0lBQ0wsQ0FBQzs7O1lBOWdCSixTQUFTLFNBQUM7Z0JBQ1AsUUFBUSxFQUFFLGNBQWM7Z0JBQ3hCLFFBQVEsRUFBRSxFQUFFO2dCQUNaLGFBQWEsRUFBRSxpQkFBaUIsQ0FBQyxJQUFJO2dCQUNyQyxTQUFTLEVBQUUsQ0FBQyxXQUFXLEVBQUUsWUFBWSxDQUFDO2dCQUN0QyxJQUFJLEVBQUU7b0JBQ0YsT0FBTyxFQUFFLGVBQWU7aUJBQzNCO2FBQ0o7OztZQW5CUSxXQUFXO1lBQ1gsWUFBWTs7O21CQWtDaEIsS0FBSzt3QkFDTCxLQUFLLFNBQUMsUUFBUTtxQkFDZCxLQUFLO2tCQUNMLEtBQUs7OEJBQ0wsS0FBSzsyQkFDTCxNQUFNO3lCQUNOLE1BQU0iLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQge1xyXG4gICAgQ29tcG9uZW50LFxyXG4gICAgVmlld0VuY2Fwc3VsYXRpb24sXHJcbiAgICBJbnB1dCxcclxuICAgIE91dHB1dCxcclxuICAgIEV2ZW50RW1pdHRlcixcclxuICAgIE9uSW5pdCxcclxuICAgIE9uQ2hhbmdlcyxcclxuICAgIFNpbXBsZUNoYW5nZXMsXHJcbiAgICBPbkRlc3Ryb3lcclxufSBmcm9tICdAYW5ndWxhci9jb3JlJztcclxuaW1wb3J0IHsgS2RDaGFydEJhc2VDbGFzcyB9IGZyb20gJy4uL2tkLWFuZ3VsYXItY2hhcnQtYmFzZS1jbGFzcyc7XHJcbmltcG9ydCB7IEtkQ2hhcnRzU3ZjIH0gZnJvbSAnLi4va2QtYW5ndWxhci1jaGFydHMtc3ZjJztcclxuaW1wb3J0IHsgS2REb21FbGVtU3ZjIH0gZnJvbSAnLi4vLi4va2QtY29tbW9uL2luZGV4JztcclxuaW1wb3J0IHsgSUxlZ2VuZERhdGEsIElDaGFydENvbmZpZyB9IGZyb20gJy4uL2tkLWFuZ3VsYXItY2hhcnRzLWludGVyZmFjZSc7XHJcbmltcG9ydCAqIGFzIGQzIGZyb20gJ2QzJztcclxuXHJcbmNvbnN0IFBJID0gTWF0aC5QSSxcclxuICAgIGFyY01pblJhZGl1cyA9IDEwLFxyXG4gICAgYXJjUGFkZGluZyA9IDEwLFxyXG4gICAgbGFiZWxQYWRkaW5nID0gLTUsXHJcbiAgICBudW1UaWNrcyA9IDEwO1xyXG5cclxuQENvbXBvbmVudCh7XHJcbiAgICBzZWxlY3RvcjogJ2tkLXBpZS1jaGFydCcsXHJcbiAgICB0ZW1wbGF0ZTogJycsXHJcbiAgICBlbmNhcHN1bGF0aW9uOiBWaWV3RW5jYXBzdWxhdGlvbi5Ob25lLFxyXG4gICAgcHJvdmlkZXJzOiBbS2RDaGFydHNTdmMsIEtkRG9tRWxlbVN2Y10sXHJcbiAgICBob3N0OiB7XHJcbiAgICAgICAgJ2NsYXNzJzogJ2tkeC1waWUtY2hhcnQnLFxyXG4gICAgfVxyXG59KVxyXG5cclxuZXhwb3J0IGNsYXNzIEtkUGllQ2hhcnQgZXh0ZW5kcyBLZENoYXJ0QmFzZUNsYXNzIGltcGxlbWVudHMgT25Jbml0LCBPbkNoYW5nZXMsIE9uRGVzdHJveSB7XHJcbiAgICBwdWJsaWMgcGllRGF0YTogQXJyYXk8YW55PiA9IFtdO1xyXG4gICAgcHVibGljIGxheW91dDtcclxuICAgIHByaXZhdGUgX3BhdGg7XHJcbiAgICBwcml2YXRlIF9yYWRpYWxBeGlzO1xyXG4gICAgcHJpdmF0ZSBfYXhpYWxBeGlzO1xyXG4gICAgcHJpdmF0ZSBfdGV4dDtcclxuICAgIHByaXZhdGUgX3BvbHlsaW5lO1xyXG4gICAgcHJpdmF0ZSBfcG9pbnRlcjtcclxuICAgIHByaXZhdGUgX2ludGVydmFsO1xyXG4gICAgcHJpdmF0ZSBfcGVyY2VudGFnZVRleHQ7XHJcbiAgICBwcml2YXRlIF9wb3NBcnJheSA9IFtdO1xyXG5cclxuXHJcbiAgICBASW5wdXQoKSBkYXRhOiBhbnk7XHJcbiAgICBASW5wdXQoJ2NvbmZpZycpIHBpZUNvbmZpZzogSUNoYXJ0Q29uZmlnO1xyXG4gICAgQElucHV0KCkgbGVnZW5kOiB7IFtrZXk6IHN0cmluZ106IElMZWdlbmREYXRhIH07XHJcbiAgICBASW5wdXQoKSBhcGk6IGFueTtcclxuICAgIEBJbnB1dCgpIHNlcmllc1RocmVzaG9sZDogbnVtYmVyO1xyXG4gICAgQE91dHB1dCgpIG91dHB1dExlZ2VuZDogRXZlbnRFbWl0dGVyPHsgW2tleTogc3RyaW5nXTogSUxlZ2VuZERhdGEgfT4gPSBuZXcgRXZlbnRFbWl0dGVyKHRydWUpO1xyXG4gICAgQE91dHB1dCgpIG91dHB1dERhdGE6IEV2ZW50RW1pdHRlcjxhbnk+ID0gbmV3IEV2ZW50RW1pdHRlcih0cnVlKTtcclxuXHJcbiAgICBjb25zdHJ1Y3RvcihwdWJsaWMgX2NoYXJ0U3ZjOiBLZENoYXJ0c1N2YywgcHVibGljIF9kb21TdmM6IEtkRG9tRWxlbVN2Yykge1xyXG4gICAgICAgIHN1cGVyKF9jaGFydFN2YywgX2RvbVN2Yyk7XHJcbiAgICB9XHJcblxyXG4gICAgbmdPbkluaXQoKTogdm9pZCB7XHJcbiAgICAgICAgdGhpcy5jb25maWcgPSBPYmplY3QuYXNzaWduKHt9LCB0aGlzLnBpZUNvbmZpZyk7XHJcbiAgICAgICAgdGhpcy5fc2V0RGF0YSgpO1xyXG4gICAgICAgIHN1cGVyLmNoYXJ0VGltZW91dCgoKSA9PiB0aGlzLl9zZXRDaGFydCgpKTtcclxuXHJcbiAgICAgICAgdGhpcy5hcGkubGVnZW5kQ2xpY2sgPSAoX2RhdGE6IGFueSwgbGVnZW5kRGF0YT86IGFueSkgPT4ge1xyXG4gICAgICAgICAgICB0aGlzLnBpZURhdGEgPSBbXTtcclxuICAgICAgICAgICAgaWYgKHRoaXMuZGF0YUxhYmVsQ29udGFpbmVyKSB0aGlzLmRhdGFMYWJlbENvbnRhaW5lci5zZWxlY3RBbGwoJyonKS5yZW1vdmUoKTtcclxuICAgICAgICAgICAgLy8gaWYgKF9jb25maWcpIHRoaXMuY29uZmlnID0gX2NvbmZpZztcclxuICAgICAgICAgICAgdGhpcy5kYXRhID0gX2RhdGE7XHJcbiAgICAgICAgICAgIGlmIChsZWdlbmREYXRhKSB7XHJcbiAgICAgICAgICAgICAgICAvLyBsZXQgbmV3Q29sb3IgPSBbXTtcclxuICAgICAgICAgICAgICAgIHRoaXMucGllRGF0YSA9IHRoaXMuZGF0YS5kYXRhO1xyXG4gICAgICAgICAgICAgICAgLy8gdGhpcy5waWVEYXRhID0gT2JqZWN0LmtleXMoX2NvbmZpZy5sZWdlbmREYXRhKS5tYXAoa2V5ID0+IF9jb25maWcubGVnZW5kRGF0YVtrZXldKS5tYXAoKHZhbHVlKSA9PiAodmFsdWUpKTtcclxuICAgICAgICAgICAgICAgIC8vIGZvciAobGV0IGkgPSAwOyBpIDwgdGhpcy5waWVEYXRhLmxlbmd0aDsgaSsrKSB7XHJcbiAgICAgICAgICAgICAgICAvLyAgICAgbmV3Q29sb3IucHVzaCh0aGlzLnBpZURhdGFbaV0uY29sb3IpO1xyXG4gICAgICAgICAgICAgICAgLy8gfVxyXG4gICAgICAgICAgICAgICAgLy8gdGhpcy5waWVDb25maWdbJ3BpZUNvbG9yJ10gPSBuZXdDb2xvcjtcclxuXHJcbiAgICAgICAgICAgICAgICB0aGlzLl9yZWRyYXdDaGFydCgpO1xyXG5cclxuICAgICAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgICAgIC8vIGZhaWwtc2FmZSBpbiBjYXNlIGRhdGEgbWFzc2FnZSBoYXZlbid0IGNyZWF0ZSBsZWdlbmREYXRhXHJcbiAgICAgICAgICAgICAgICB0aGlzLl9zZXREYXRhKCk7XHJcbiAgICAgICAgICAgICAgICB0aGlzLl9zZXRDaGFydCgpO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfTtcclxuICAgICAgICB0aGlzLmFwaS5yZWRyYXcgPSAoKSA9PiB7XHJcbiAgICAgICAgICAgIHRoaXMuX3JlZHJhd0NoYXJ0KCk7XHJcbiAgICAgICAgfTtcclxuICAgIH1cclxuXHJcbiAgICBuZ09uQ2hhbmdlcyhfc2ltcGxlQ2hhbmdlczogU2ltcGxlQ2hhbmdlcyk6IHZvaWQge1xyXG4gICAgICAgIGlmIChfc2ltcGxlQ2hhbmdlcy5oYXNPd25Qcm9wZXJ0eSgnZGF0YScpICYmICFfc2ltcGxlQ2hhbmdlc1snZGF0YSddLmZpcnN0Q2hhbmdlKSB7XHJcbiAgICAgICAgICAgIHRoaXMuZGF0YSA9IF9zaW1wbGVDaGFuZ2VzLmRhdGEuY3VycmVudFZhbHVlO1xyXG4gICAgICAgICAgICB0aGlzLl9yZWRyYXdDaGFydCgnZGF0YScpO1xyXG4gICAgICAgIH1cclxuICAgICAgICBpZiAoX3NpbXBsZUNoYW5nZXMuaGFzT3duUHJvcGVydHkoJ3BpZUNvbmZpZycpICYmICFfc2ltcGxlQ2hhbmdlc1sncGllQ29uZmlnJ10uZmlyc3RDaGFuZ2UpIHtcclxuICAgICAgICAgICAgdGhpcy5waWVDb25maWcgPSBfc2ltcGxlQ2hhbmdlcy5waWVDb25maWcuY3VycmVudFZhbHVlO1xyXG4gICAgICAgICAgICB0aGlzLl9yZWRyYXdDaGFydCgnY29uZmlnJyk7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIG5nT25EZXN0cm95KCk6IHZvaWQge1xyXG4gICAgICAgIHRoaXMuX3Jlc2V0Q2hhcnQoKTtcclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF9yZWRyYXdDaGFydChfY2hhbmdlcz86ICdkYXRhJyB8ICdjb25maWcnKSB7XHJcbiAgICAgICAgdGhpcy5fcmVzZXRDaGFydCgpO1xyXG5cclxuICAgICAgICBpZiAoX2NoYW5nZXMgPT09ICdkYXRhJykge1xyXG4gICAgICAgICAgICB0aGlzLnBpZURhdGEgPSBbXTtcclxuICAgICAgICAgICAgdGhpcy5fc2V0RGF0YSgpO1xyXG4gICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgIHRoaXMucGllQ29uZmlnWydsZWdlbmREYXRhJ10gPSB0aGlzLmNvbmZpZ1snbGVnZW5kRGF0YSddO1xyXG4gICAgICAgICAgICB0aGlzLmNvbmZpZyA9IE9iamVjdC5hc3NpZ24oe30sIHRoaXMucGllQ29uZmlnKTtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIHN1cGVyLmNoYXJ0VGltZW91dCgoKSA9PiB0aGlzLl9zZXRDaGFydCgpKTtcclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF9zZXRDaGFydCgpOiB2b2lkIHtcclxuICAgICAgICBzdXBlci5zZXRTdmcoKTtcclxuICAgICAgICBzdXBlci5zZXRTdmdEaW1lbnNpb24oJ3gnKTtcclxuICAgICAgICBzdXBlci5zZXRTdmdEaW1lbnNpb24oJ3knKTtcclxuXHJcbiAgICAgICAgdGhpcy5jaGFydFR5cGUgPSB0aGlzLmRhdGEubGF5b3V0LnNwbGl0KCctJyk7XHJcbiAgICAgICAgdGhpcy5jaGFydENhdGVnb3J5ID0gdGhpcy5kYXRhLnR5cGU7XHJcbiAgICAgICAgLy8gbW92aW5nIHBpZSBjaGFydCB0byBjZW50ZXIgb2Ygc3ZnXHJcbiAgICAgICAgbGV0IGhlaWdodCA9IHRoaXMuc3ZnQ29udGFpbmVyLm5vZGUoKS5nZXRCb3VuZGluZ0NsaWVudFJlY3QoKS5oZWlnaHQ7XHJcbiAgICAgICAgbGV0IHdpZHRoID0gdGhpcy5zdmdDb250YWluZXIubm9kZSgpLmdldEJvdW5kaW5nQ2xpZW50UmVjdCgpLndpZHRoO1xyXG4gICAgICAgIHRoaXMud2lkdGggPSB3aWR0aDtcclxuICAgICAgICB0aGlzLmdyYXBoLmF0dHIoJ3RyYW5zZm9ybScsICd0cmFuc2xhdGUoJyArICh3aWR0aCAvIDIpICsgJywnICsgKGhlaWdodCAvIDIpICsgJyknKTtcclxuXHJcbiAgICAgICAgLy8gbGV0IGNvbG9yID0gdGhpcy5waWVDb25maWdbJ3BpZUNvbG9yJ10gPyBkMy5zY2FsZU9yZGluYWwoKS5yYW5nZSh0aGlzLnBpZUNvbmZpZ1sncGllQ29sb3InXSkgOiBkMy5zY2FsZU9yZGluYWwoKS5yYW5nZSh0aGlzLmNvbmZpZy5jb2xvcnMpO1xyXG4gICAgICAgIC8vIGxldCBjaGFydFBhcmFtcyA9IHtcclxuICAgICAgICAvLyAgICAgJ2NvbG9yJzogY29sb3JcclxuICAgICAgICAvLyB9O1xyXG4gICAgICAgIHRoaXMuZGF0YUxhYmVsQ29udGFpbmVyLnN0eWxlKCd0b3AnLCAwKTtcclxuICAgICAgICB0aGlzLmRhdGFMYWJlbENvbnRhaW5lci5zdHlsZSgnbGVmdCcsIDApO1xyXG5cclxuICAgICAgICBpZiAodGhpcy5jaGFydFR5cGVbMF0gPT09ICdyYWRpYWwnKSB7XHJcbiAgICAgICAgICAgIHRoaXMuX2RyYXdSYWRpYWwoeyBoZWlnaHQ6IGhlaWdodCB9KTtcclxuICAgICAgICB9IGVsc2UgaWYgKHRoaXMuY2hhcnRUeXBlWzBdID09PSAnZ2F1Z2UnKSB7XHJcbiAgICAgICAgICAgIHRoaXMuX2RyYXdHYXVnZSh7IGhlaWdodDogaGVpZ2h0IH0pO1xyXG4gICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgIHRoaXMuX2RyYXdQaWVEb251dCh7IGhlaWdodDogaGVpZ2h0LCB3aWR0aDogd2lkdGggfSk7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIC8qKlxyXG4gICAgICogd2hlbiByZWNlaXZpbmcgZGF0YSBhbmQgbGVnZW5kLCB0aGUgc3RydWN0dXJlIGlzIGN1c3RvbWlzZSB0byBmb3IgbGluZS9hcmVhIGFuZCBiYXIuIHBpZSBuZWVkcyB0byByZWNhbGN1bGF0ZSB0aGUgbGVnZW5kXHJcbiAgICAgKiBfc2V0RGF0YSBnZW5lcmF0ZSBwaWVEYXRhIGFuZCBuZXcgbGVnZW5kIGZyb20gdGhlIHByZXZpb3VzIGxlZ2VuZFxyXG4gICAgICpcclxuICAgICAqIE5vdGU6IHRoaXMucGllRGF0YSBpcyB1c2VkIGZvciByZW5kZXJpbmcuXHJcbiAgICAgKiBOb3RlMjogZGF0YS5waWVEYXRhIGl0IHdpbGwgbm90IGJlIGNoYW5nZWQgb25MZWdlbmRDbGlja1xyXG4gICAgICogKG9uTGVnZW5kQ2xpY2sgYWZmZWN0cyBkYXRhLmRhdGEgd2hpY2ggaXMgc3RvcmVkIGludG8gdGhpcy5waWVEYXRhIHZpYSBhcGkpXHJcbiAgICAgKi9cclxuICAgIHByaXZhdGUgX3NldERhdGEoKTogdm9pZCB7XHJcbiAgICAgICAgaWYgKCF0aGlzLmNvbmZpZy5za2lwTWFzc2FnZSkge1xyXG4gICAgICAgICAgICBpZiAodGhpcy5kYXRhWydwaWVkYXRhJ10pIHtcclxuICAgICAgICAgICAgICAgIHRoaXMucGllRGF0YSA9IHRoaXMuZGF0YS5waWVkYXRhO1xyXG4gICAgICAgICAgICAgICAgLy8gc2F2aW5nIG1hc3NhZ2VkIHBpZWRhdGEgdG8gdGhpcy5kYXRhIGZvciBleHBvcnRcclxuICAgICAgICAgICAgICAgIHRoaXMuZGF0YS5kYXRhID0gdGhpcy5kYXRhLnBpZWRhdGE7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICAvLyB3aGVuIHNraXAgbWFzc2FnZSwgbm8gZ2VuZXJhdGlvbiBvZiBwaWVEYXRhIG5lZWRlZC5cclxuICAgICAgICAgICAgdGhpcy5waWVEYXRhID0gdGhpcy5kYXRhLmRhdGE7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX3Jlc2V0Q2hhcnQoKTogdm9pZCB7XHJcbiAgICAgICAgaWYgKHR5cGVvZiB0aGlzLl9wYXRoICE9PSAndW5kZWZpbmVkJykgdGhpcy5fcGF0aC5yZW1vdmUoKTtcclxuICAgICAgICBpZiAodHlwZW9mIHRoaXMuX3JhZGlhbEF4aXMgIT09ICd1bmRlZmluZWQnKSB0aGlzLl9yYWRpYWxBeGlzLnJlbW92ZSgpO1xyXG4gICAgICAgIGlmICh0eXBlb2YgdGhpcy5fYXhpYWxBeGlzICE9PSAndW5kZWZpbmVkJykgdGhpcy5fYXhpYWxBeGlzLnJlbW92ZSgpO1xyXG4gICAgICAgIGlmICh0eXBlb2YgdGhpcy5fdGV4dCAhPT0gJ3VuZGVmaW5lZCcpIHRoaXMuX3RleHQucmVtb3ZlKCk7XHJcbiAgICAgICAgaWYgKHR5cGVvZiB0aGlzLl9wb2x5bGluZSAhPT0gJ3VuZGVmaW5lZCcpIHRoaXMuX3BvbHlsaW5lLnJlbW92ZSgpO1xyXG4gICAgICAgIGlmICh0eXBlb2YgdGhpcy5fcG9pbnRlciAhPT0gJ3VuZGVmaW5lZCcpIHRoaXMuX3BvaW50ZXIucmVtb3ZlKCk7XHJcbiAgICAgICAgaWYgKHR5cGVvZiB0aGlzLl9wZXJjZW50YWdlVGV4dCAhPT0gJ3VuZGVmaW5lZCcpIHRoaXMuX3BlcmNlbnRhZ2VUZXh0LnJlbW92ZSgpO1xyXG4gICAgICAgIGlmICh0aGlzLmRhdGFMYWJlbENvbnRhaW5lcikgdGhpcy5kYXRhTGFiZWxDb250YWluZXIuc2VsZWN0QWxsKCcqJykucmVtb3ZlKCk7XHJcbiAgICAgICAgdGhpcy5fcG9zQXJyYXkgPSBbXTtcclxuICAgICAgICBjbGVhckludGVydmFsKHRoaXMuX2ludGVydmFsKTtcclxuICAgICAgICBzdXBlci5yZW1vdmVDaGFydCgpO1xyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX2RyYXdQaWVEb251dChfcGFyYW1zOiB7IHdpZHRoOiBudW1iZXIsIGhlaWdodDogbnVtYmVyIH0pOiB2b2lkIHtcclxuICAgICAgICBsZXQgcmFkaXVzID0gTWF0aC5taW4oX3BhcmFtcy53aWR0aCwgX3BhcmFtcy5oZWlnaHQpIC8gMjtcclxuICAgICAgICBpZiAodGhpcy5jaGFydFR5cGVbMV0gJiYgdGhpcy5jaGFydFR5cGVbMV0gPT09ICdoYWxmJykge1xyXG4gICAgICAgICAgICByYWRpdXMgPSAoTWF0aC5taW4oX3BhcmFtcy53aWR0aCwgX3BhcmFtcy5oZWlnaHQpIC8gNSkgKiAzO1xyXG4gICAgICAgICAgICB0aGlzLmdyYXBoLmF0dHIoJ3RyYW5zZm9ybScsICd0cmFuc2xhdGUoJyArIChfcGFyYW1zLndpZHRoIC8gMikgKyAnLCcgKyAoKF9wYXJhbXMuaGVpZ2h0IC8gNCkgKiAzKSArICcpJyk7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGxldCBpbm5lclJhZGl1cyA9IHRoaXMuY2hhcnRUeXBlWzBdID09PSAncGllJyA/IDAgOiAodGhpcy5jb25maWcucGxvdE9wdGlvbnMucGllLmlubmVyUmFkaXVzIC8gMTAwKSAqIHJhZGl1cyAqIDAuODtcclxuICAgICAgICBsZXQgYXJjID0gZDMuYXJjKCkuaW5uZXJSYWRpdXMoaW5uZXJSYWRpdXMpLm91dGVyUmFkaXVzKHJhZGl1cyAqIDAuOCk7XHJcbiAgICAgICAgbGV0IG91dGVyYXJjID0gZDMuYXJjKCkuaW5uZXJSYWRpdXMocmFkaXVzICogMC45KS5vdXRlclJhZGl1cyhyYWRpdXMgKiAwLjkpO1xyXG4gICAgICAgIC8vIGxldCBhcmMgPSBkMy5hcmMoKS5pbm5lclJhZGl1cyhpbm5lclJhZGl1cykub3V0ZXJSYWRpdXMocmFkaXVzKTtcclxuICAgICAgICBsZXQgcGllID0gZDMucGllKCkuc29ydChudWxsKS52YWx1ZSgoZCkgPT4geyByZXR1cm4gZC55OyB9KTtcclxuICAgICAgICBsZXQgZGF0YUxhYmVsQ2hlY2sgPSB0aGlzLmNoYXJ0VHlwZVsxXSA9PT0gJ2Z1bGwnID8gTWF0aC5QSSA6IDA7XHJcbiAgICAgICAgcGllID0gdGhpcy5jaGFydFR5cGVbMV0gPT09ICdmdWxsJyA/IHBpZS5zdGFydEFuZ2xlKDApLmVuZEFuZ2xlKE1hdGguUEkgKiAyKSA6IHBpZS5zdGFydEFuZ2xlKC05MCAqIChNYXRoLlBJIC8gMTgwKSkuZW5kQW5nbGUoOTAgKiAoTWF0aC5QSSAvIDE4MCkpO1xyXG5cclxuICAgICAgICB0aGlzLl9wYXRoID0gdGhpcy5ncmFwaC5zZWxlY3RBbGwoJ3BhdGgnKVxyXG4gICAgICAgICAgICAuZGF0YShwaWUodGhpcy5waWVEYXRhKSlcclxuICAgICAgICAgICAgLmVudGVyKClcclxuICAgICAgICAgICAgLmFwcGVuZCgncGF0aCcpXHJcbiAgICAgICAgICAgIC5hdHRyKCdhcmlhLXZhbHVlJywgKGQpID0+IGQuZGF0YS55KVxyXG4gICAgICAgICAgICAuYXR0cignYXJpYS1zZXJpZXMtbmFtZScsIChkKSA9PiB0aGlzLmxlZ2VuZFtkLmRhdGEuaWRdLm5hbWUpXHJcbiAgICAgICAgICAgIC5hdHRyKCdjbGFzcycsIChkKSA9PiB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLl9wb3NBcnJheS5wdXNoKHsgJ3gnOiBkLmRhdGEuaW5kZXgsICd2YWx1ZSc6IGQuZGF0YS55LCAnaWQnOiBkLmRhdGEuaW5kZXggfSk7XHJcbiAgICAgICAgICAgICAgICByZXR1cm4gJ3gtJyArIGQuZGF0YS5pbmRleCArICcgeS0nICsgZC5kYXRhLmluZGV4O1xyXG4gICAgICAgICAgICAgICAgLy8gcmV0dXJuICd4LScgKyAoZC5kYXRhLnhCYXNlKS5yZXBsYWNlKC8gL2csJycpICsgJyB5LScgKyBzZXJpZXNJZDtcclxuICAgICAgICAgICAgfSlcclxuICAgICAgICAgICAgLmF0dHIoJ2lkJywgKGQpID0+IHtcclxuICAgICAgICAgICAgICAgIHJldHVybiBkLmRhdGEuaW5kZXg7XHJcbiAgICAgICAgICAgICAgICAvLyByZXR1cm4gKGQuZGF0YS54KS5yZXBsYWNlKC8gL2csJycpO1xyXG4gICAgICAgICAgICB9KVxyXG4gICAgICAgICAgICAuYXR0cignZmlsbCcsIChkLCBpKSA9PiB7XHJcbiAgICAgICAgICAgICAgICByZXR1cm4gdGhpcy5sZWdlbmRbZC5kYXRhLmlkXS5jb2xvcjsgLy8gY29sb3Igc2hvdWxkIGZvbGxvdyBsZWdlbmREYXRhXHJcbiAgICAgICAgICAgIH0pXHJcbiAgICAgICAgICAgIC8vIC5hdHRyKCdkJywgYXJjKVxyXG4gICAgICAgICAgICAuc3R5bGUoJ3N0cm9rZScsIHRoaXMuY29uZmlnLnBsb3RPcHRpb25zLnBpZS5ib3JkZXJDb2xvcilcclxuICAgICAgICAgICAgLnN0eWxlKCdzdHJva2Utd2lkdGgnLCB0aGlzLmNvbmZpZy5wbG90T3B0aW9ucy5waWUuYm9yZGVyV2lkdGggfHwgMCk7XHJcblxyXG4gICAgICAgIGxldCBsYWJlbFBhcmFtcyA9IHtcclxuICAgICAgICAgICAgJ3BpZSc6IHBpZSxcclxuICAgICAgICAgICAgJ2FyYyc6IGFyYyxcclxuICAgICAgICAgICAgJ291dGVyYXJjJzogb3V0ZXJhcmMsXHJcbiAgICAgICAgICAgICdyYWRpdXMnOiByYWRpdXMsXHJcbiAgICAgICAgICAgICdkYXRhTGFiZWxDaGVjayc6IGRhdGFMYWJlbENoZWNrLFxyXG4gICAgICAgICAgICAvLyAnY29sb3InOiBfcGFyYW1zLmNvbG9yXHJcbiAgICAgICAgfTtcclxuXHJcbiAgICAgICAgaWYgKCF0aGlzLmNvbmZpZy5hbmltYXRpb24pIHtcclxuICAgICAgICAgICAgdGhpcy5fcGF0aFxyXG4gICAgICAgICAgICAgICAgLmF0dHIoJ2QnLCBkID0+IGFyYyhkKSlcclxuICAgICAgICAgICAgICAgIC5hdHRyKCdwb3MnLCBkID0+IGdldFBvcyhkLCB0aGlzLmNoYXJ0VHlwZVsxXSkpO1xyXG5cclxuICAgICAgICAgICAgdGhpcy5fc2V0RGF0YUxhYmVsKGxhYmVsUGFyYW1zKTtcclxuXHJcbiAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgdGhpcy5fcGF0aC50cmFuc2l0aW9uKClcclxuICAgICAgICAgICAgICAgIC5kZWxheSgoZCwgaSkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBpICogMjA7XHJcbiAgICAgICAgICAgICAgICB9KVxyXG4gICAgICAgICAgICAgICAgLmF0dHJUd2VlbignZCcsIChkKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgbGV0IGkgPSBkMy5pbnRlcnBvbGF0ZShkLnN0YXJ0QW5nbGUsIGQuZW5kQW5nbGUpO1xyXG4gICAgICAgICAgICAgICAgICAgIHJldHVybiAodCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBkLmVuZEFuZ2xlID0gaSh0KTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIGFyYyhkKTtcclxuICAgICAgICAgICAgICAgICAgICB9O1xyXG4gICAgICAgICAgICAgICAgfSlcclxuICAgICAgICAgICAgICAgIC5hdHRyVHdlZW4oJ3BvcycsIChkKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgbGV0IGN1cnJlbnQ7XHJcbiAgICAgICAgICAgICAgICAgICAgY3VycmVudCA9IGN1cnJlbnQgfHwgZDtcclxuICAgICAgICAgICAgICAgICAgICBsZXQgaW50ZXJwb2xhdGUgPSBkMy5pbnRlcnBvbGF0ZShjdXJyZW50LCBkKTtcclxuICAgICAgICAgICAgICAgICAgICBjdXJyZW50ID0gaW50ZXJwb2xhdGUoMCk7XHJcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuICh0KSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGxldCBkMiA9IGludGVycG9sYXRlKHQpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gZ2V0UG9zKGQyLCB0aGlzLmNoYXJ0VHlwZVsxXSk7XHJcbiAgICAgICAgICAgICAgICAgICAgfTtcclxuICAgICAgICAgICAgICAgIH0pXHJcbiAgICAgICAgICAgICAgICAub24oJ2VuZCcsIChkLCBpKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKGkgPT09ICh0aGlzLnBpZURhdGEubGVuZ3RoIC0gMSkpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgc2V0VGltZW91dCgoKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0aGlzLl9zZXREYXRhTGFiZWwobGFiZWxQYXJhbXMpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIHRoaXMuX3BhdGguZXhpdCgpLnJlbW92ZSgpO1xyXG5cclxuICAgICAgICBmdW5jdGlvbiBnZXRQb3MoX2QyLCBfY2hhcnRUeXBlKSB7XHJcbiAgICAgICAgICAgIGxldCBwb3MgPSBvdXRlcmFyYy5jZW50cm9pZChfZDIpO1xyXG4gICAgICAgICAgICBpZiAoX2NoYXJ0VHlwZSAmJiBfY2hhcnRUeXBlID09PSAnaGFsZicpIHtcclxuICAgICAgICAgICAgICAgIHBvc1swXSA9IHJhZGl1cyAqIChtaWRBbmdsZShfZDIpIDwgZGF0YUxhYmVsQ2hlY2sgPyAtMSA6IDEpO1xyXG4gICAgICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgcG9zWzBdID0gcmFkaXVzICogKG1pZEFuZ2xlKF9kMikgPCBkYXRhTGFiZWxDaGVjayA/IDEgOiAtMSk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgcmV0dXJuIHBvcztcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIGZ1bmN0aW9uIG1pZEFuZ2xlKF9kKSB7XHJcbiAgICAgICAgICAgIHJldHVybiBfZC5zdGFydEFuZ2xlICsgKF9kLmVuZEFuZ2xlIC0gX2Quc3RhcnRBbmdsZSkgLyAyO1xyXG4gICAgICAgIH1cclxuICAgICAgICBsZXQgZXZlbnRzUGFyYW0gPSB7XHJcbiAgICAgICAgICAgICdpbm5lclJhZGl1cyc6IGlubmVyUmFkaXVzLFxyXG4gICAgICAgICAgICAnb3V0ZXJSYWRpdXMnOiByYWRpdXMgKiAwLjgsXHJcbiAgICAgICAgICAgICdwYXRoQW5pbSc6IHRoaXMuX3BhdGhBbmltLFxyXG4gICAgICAgIH07XHJcbiAgICAgICAgc3VwZXIuX2luaXRNb3VzZUV2ZW50cyh0aGlzLl9wYXRoLCBldmVudHNQYXJhbSk7XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfZHJhd1JhZGlhbChfcGFyYW1zOiB7IHdpZHRoPzogbnVtYmVyLCBoZWlnaHQ6IG51bWJlciB9KTogdm9pZCB7XHJcbiAgICAgICAgLy8gbGV0IGhlaWdodCA9IGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3IoJyMnICsgdGhpcy5jb25maWcuaWQgKyAnLmtkeC1jaGFydHMgLnN2Zy1jb250YWluZXInKS5nZXRCb3VuZGluZ0NsaWVudFJlY3QoKS5oZWlnaHQ7XHJcbiAgICAgICAgbGV0IGNoYXJ0UmFkaXVzID0gX3BhcmFtcy5oZWlnaHQgLyAyIC0gNDA7XHJcbiAgICAgICAgbGV0IHNjYWxlID0gZDMuc2NhbGVMaW5lYXIoKVxyXG4gICAgICAgICAgICAuZG9tYWluKFswLCBkMy5tYXgodGhpcy5waWVEYXRhLCBkID0+IGQueSkgKiAxLjFdKVxyXG4gICAgICAgICAgICAucmFuZ2UoWzAsIDIgKiBQSV0pO1xyXG4gICAgICAgIGxldCB0aWNrcyA9IHNjYWxlLnRpY2tzKG51bVRpY2tzKS5zbGljZSgwLCAtMSk7XHJcbiAgICAgICAgbGV0IGtleXMgPSB0aGlzLnBpZURhdGEubWFwKChkLCBpKSA9PiBkLngpO1xyXG4gICAgICAgIC8vIG51bWJlciBvZiBhcmNzXHJcbiAgICAgICAgY29uc3QgbnVtQXJjcyA9IGtleXMubGVuZ3RoO1xyXG4gICAgICAgIGNvbnN0IGFyY1dpZHRoID0gKGNoYXJ0UmFkaXVzIC0gYXJjTWluUmFkaXVzIC0gbnVtQXJjcyAqIGFyY1BhZGRpbmcpIC8gbnVtQXJjcztcclxuXHJcbiAgICAgICAgbGV0IGFyYyA9IGQzLmFyYygpXHJcbiAgICAgICAgICAgIC5pbm5lclJhZGl1cygoZCwgaSkgPT4gdGhpcy5fZ2V0SW5uZXJSYWRpdXMoaSwgbnVtQXJjcywgYXJjV2lkdGgpKVxyXG4gICAgICAgICAgICAub3V0ZXJSYWRpdXMoKGQsIGkpID0+IHRoaXMuX2dldE91dGVyUmFkaXVzKGksIG51bUFyY3MsIGFyY1dpZHRoKSlcclxuICAgICAgICAgICAgLnN0YXJ0QW5nbGUoMClcclxuICAgICAgICAgICAgLmVuZEFuZ2xlKChkLCBpKSA9PiBzY2FsZShkKSk7XHJcblxyXG4gICAgICAgIHRoaXMuX3JhZGlhbEF4aXMgPSB0aGlzLmdyYXBoLmFwcGVuZCgnZycpXHJcbiAgICAgICAgICAgIC5hdHRyKCdjbGFzcycsICdrZHgtY2hhcnRzLXIga2R4LWNoYXJ0cy1heGlzLXJhZGlhbCcpXHJcbiAgICAgICAgICAgIC5zZWxlY3RBbGwoJ2cnKVxyXG4gICAgICAgICAgICAuZGF0YSh0aGlzLnBpZURhdGEpXHJcbiAgICAgICAgICAgIC5lbnRlcigpLmFwcGVuZCgnZycpO1xyXG5cclxuICAgICAgICB0aGlzLl9yYWRpYWxBeGlzLmFwcGVuZCgnY2lyY2xlJylcclxuICAgICAgICAgICAgLmF0dHIoJ3InLCAoZCwgaSkgPT4gdGhpcy5fZ2V0T3V0ZXJSYWRpdXMoaSwgbnVtQXJjcywgYXJjV2lkdGgpICsgYXJjUGFkZGluZyk7XHJcblxyXG4gICAgICAgIHRoaXMuX3JhZGlhbEF4aXMuYXBwZW5kKCd0ZXh0JylcclxuICAgICAgICAgICAgLmF0dHIoJ3gnLCBsYWJlbFBhZGRpbmcpXHJcbiAgICAgICAgICAgIC5hdHRyKCd5JywgKGQsIGkpID0+IC10aGlzLl9nZXRPdXRlclJhZGl1cyhpLCBudW1BcmNzLCBhcmNXaWR0aCkgKyBhcmNQYWRkaW5nKVxyXG4gICAgICAgICAgICAuc3R5bGUoJ2ZvbnQtc2l6ZScsICcxMHB4JylcclxuICAgICAgICAgICAgLnRleHQoZCA9PiBkLngpO1xyXG5cclxuICAgICAgICB0aGlzLl9heGlhbEF4aXMgPSB0aGlzLmdyYXBoLmFwcGVuZCgnZycpXHJcbiAgICAgICAgICAgIC5hdHRyKCdjbGFzcycsICdrZHgtY2hhcnRzLWEga2R4LWNoYXJ0cy1heGlzLXJhZGlhbCcpXHJcbiAgICAgICAgICAgIC5zZWxlY3RBbGwoJ2cnKVxyXG4gICAgICAgICAgICAuZGF0YSh0aWNrcylcclxuICAgICAgICAgICAgLmVudGVyKCkuYXBwZW5kKCdnJylcclxuICAgICAgICAgICAgLmF0dHIoJ3RyYW5zZm9ybScsIGQgPT4gJ3JvdGF0ZSgnICsgKHRoaXMuX3JhZDJkZWcoc2NhbGUoZCkpIC0gOTApICsgJyknKTtcclxuXHJcbiAgICAgICAgdGhpcy5fYXhpYWxBeGlzLmFwcGVuZCgnbGluZScpXHJcbiAgICAgICAgICAgIC5hdHRyKCd4MicsIGNoYXJ0UmFkaXVzKTtcclxuXHJcbiAgICAgICAgdGhpcy5fYXhpYWxBeGlzLmFwcGVuZCgndGV4dCcpXHJcbiAgICAgICAgICAgIC5hdHRyKCd4JywgY2hhcnRSYWRpdXMgKyAxMClcclxuICAgICAgICAgICAgLnN0eWxlKCd0ZXh0LWFuY2hvcicsIGQgPT4gKHNjYWxlKGQpID49IFBJICYmIHNjYWxlKGQpIDwgMiAqIFBJID8gJ2VuZCcgOiBudWxsKSlcclxuICAgICAgICAgICAgLnN0eWxlKCdmb250LXNpemUnLCAnMTBweCcpXHJcbiAgICAgICAgICAgIC5hdHRyKCd0cmFuc2Zvcm0nLCBkID0+ICdyb3RhdGUoJyArICg5MCAtIHRoaXMuX3JhZDJkZWcoc2NhbGUoZCkpKSArICcsJyArIChjaGFydFJhZGl1cyArIDEwKSArICcsMCknKVxyXG4gICAgICAgICAgICAudGV4dChkID0+IGQpO1xyXG5cclxuICAgICAgICAvLyBkYXRhIGFyY3NcclxuICAgICAgICB0aGlzLl9wYXRoID0gdGhpcy5ncmFwaC5hcHBlbmQoJ2cnKVxyXG4gICAgICAgICAgICAuc2VsZWN0QWxsKCdwYXRoJylcclxuICAgICAgICAgICAgLmRhdGEodGhpcy5waWVEYXRhKVxyXG4gICAgICAgICAgICAuZW50ZXIoKS5hcHBlbmQoJ3BhdGgnKVxyXG4gICAgICAgICAgICAuYXR0cignY2xhc3MnLCAoZCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgcmV0dXJuICd4LScgKyBkLnhCYXNlICsgJyB5LScgKyBkLng7XHJcbiAgICAgICAgICAgIH0pXHJcbiAgICAgICAgICAgIC5zdHlsZSgnZmlsbCcsIChkLCBpKSA9PiB0aGlzLmxlZ2VuZFtkLmlkXS5jb2xvcik7XHJcblxyXG4gICAgICAgIGlmICghdGhpcy5jb25maWcuYW5pbWF0aW9uKSB7XHJcbiAgICAgICAgICAgIHRoaXMuX3BhdGguYXR0cignZCcsIChkLCBpKSA9PiBhcmMoZC55LCBpKSk7XHJcbiAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgdGhpcy5fcGF0aC50cmFuc2l0aW9uKClcclxuICAgICAgICAgICAgICAgIC5kZWxheSgoZCwgaSkgPT4gaSAqIDEwMClcclxuICAgICAgICAgICAgICAgIC5kdXJhdGlvbigyMDApXHJcbiAgICAgICAgICAgICAgICAvLyAuYXR0clR3ZWVuKCdkJywgYXJjVHdlZW4pO1xyXG4gICAgICAgICAgICAgICAgLmF0dHJUd2VlbignZCcsIChkLCBpKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgbGV0IGludGVycG9sYXRlID0gZDMuaW50ZXJwb2xhdGUoMCwgZC55KTtcclxuICAgICAgICAgICAgICAgICAgICByZXR1cm4gdCA9PiBhcmMoaW50ZXJwb2xhdGUodCksIGkpO1xyXG4gICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICBzdXBlci5faW5pdE1vdXNlRXZlbnRzKHRoaXMuX3BhdGgpO1xyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX2RyYXdHYXVnZShfcGFyYW1zOiB7IGhlaWdodDogbnVtYmVyIH0pOiB2b2lkIHtcclxuICAgICAgICAvLyBsZXQgcGVyY2VudCA9IDEwMC4wMDtcclxuICAgICAgICBsZXQgcGVyY2VudCA9IE1hdGguZmxvb3IoTWF0aC5yYW5kb20oKSAqIDEwMCk7XHJcbiAgICAgICAgbGV0IGVuZEFuZ2xlID0gdGhpcy5jaGFydFR5cGVbMV0gPT09ICdmdWxsJyA/IE1hdGguUEkgKiAyIDogTWF0aC5QSTtcclxuICAgICAgICBsZXQgb3V0ZXJSYWRpdXMgPSBfcGFyYW1zLmhlaWdodCAvIDM7XHJcbiAgICAgICAgbGV0IGlubmVyUmFkaXVzID0gKG91dGVyUmFkaXVzIC8gMykgKiAyO1xyXG4gICAgICAgIGxldCBmb250U2l6ZSA9IGlubmVyUmFkaXVzICogMC44O1xyXG5cclxuICAgICAgICBsZXQgYXJjID0gZDMuYXJjKClcclxuICAgICAgICAgICAgLmlubmVyUmFkaXVzKGlubmVyUmFkaXVzKVxyXG4gICAgICAgICAgICAub3V0ZXJSYWRpdXMob3V0ZXJSYWRpdXMpXHJcbiAgICAgICAgICAgIC5zdGFydEFuZ2xlKDApXHJcbiAgICAgICAgICAgIC5lbmRBbmdsZShlbmRBbmdsZSk7XHJcblxyXG4gICAgICAgIGxldCBhcmNMaW5lID0gZDMuYXJjKClcclxuICAgICAgICAgICAgLmlubmVyUmFkaXVzKGlubmVyUmFkaXVzKVxyXG4gICAgICAgICAgICAub3V0ZXJSYWRpdXMob3V0ZXJSYWRpdXMpXHJcbiAgICAgICAgICAgIC5zdGFydEFuZ2xlKDApO1xyXG5cclxuICAgICAgICB0aGlzLl9wYXRoID0gdGhpcy5ncmFwaC5hcHBlbmQoJ3BhdGgnKVxyXG4gICAgICAgICAgICAuYXR0cignZCcsIGFyYylcclxuICAgICAgICAgICAgLmF0dHIoJ3RyYW5zZm9ybScsICdyb3RhdGUoLTkwKScpXHJcbiAgICAgICAgICAgIC5hdHRyKCdzdHJva2Utd2lkdGgnLCAxKVxyXG4gICAgICAgICAgICAuYXR0cignc3Ryb2tlJywgJyM2NjY2NjYnKVxyXG4gICAgICAgICAgICAuc3R5bGUoJ2ZpbGwnLCAnI0ZGRkZGRicpO1xyXG5cclxuXHJcbiAgICAgICAgdGhpcy5fcG9pbnRlciA9IHRoaXMuZ3JhcGguYXBwZW5kKCdwYXRoJylcclxuICAgICAgICAgICAgLy8gbGV0IHBhdGhGb3JlZ3JvdW5kID0gdGhpcy5ncmFwaC5hcHBlbmQoJ3BhdGgnKVxyXG4gICAgICAgICAgICAuZGF0dW0oeyBlbmRBbmdsZTogMCB9KVxyXG4gICAgICAgICAgICAuYXR0cignZCcsIGFyY0xpbmUpXHJcbiAgICAgICAgICAgIC5hdHRyKCd0cmFuc2Zvcm0nLCAncm90YXRlKC05MCknKTtcclxuXHJcblxyXG4gICAgICAgIHRoaXMuX3BlcmNlbnRhZ2VUZXh0ID0gdGhpcy5ncmFwaC5hcHBlbmQoJ3RleHQnKVxyXG4gICAgICAgICAgICAuZGF0dW0oMClcclxuICAgICAgICAgICAgLnRleHQoZnVuY3Rpb24oZCkge1xyXG4gICAgICAgICAgICAgICAgcmV0dXJuIGQ7XHJcbiAgICAgICAgICAgIH0pXHJcbiAgICAgICAgICAgIC5hdHRyKCdjbGFzcycsICdrZHgtY2hhcnRzLW1pZGRsZVRleHQnKVxyXG4gICAgICAgICAgICAuYXR0cigndGV4dC1hbmNob3InLCAnbWlkZGxlJylcclxuICAgICAgICAgICAgLmF0dHIoJ2R5JywgdGhpcy5jaGFydFR5cGVbMV0gPT09ICdmdWxsJyA/IGZvbnRTaXplICogMC40NSA6IDApXHJcbiAgICAgICAgICAgIC5zdHlsZSgnZmlsbCcsIGQzLnJnYignIzAwMDAwMCcpKVxyXG4gICAgICAgICAgICAuc3R5bGUoJ2ZvbnQtc2l6ZScsIGZvbnRTaXplICsgJ3B4Jyk7XHJcblxyXG4gICAgICAgIGlmICghdGhpcy5jb25maWcuYW5pbWF0aW9uKSB7XHJcbiAgICAgICAgICAgIHRoaXMuX3BvaW50ZXJcclxuICAgICAgICAgICAgICAgIC5hdHRyKCdkJywgZCA9PiBhcmNMaW5lKGQpKVxyXG4gICAgICAgICAgICAgICAgLnN0eWxlKCdmaWxsJywgZDMucmdiKCcjRkYwMDAwJykpO1xyXG4gICAgICAgICAgICByZXR1cm47XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICBsZXQgYXJjVHdlZW4gPSBmdW5jdGlvbih0cmFuc2l0aW9uLCBuZXdWYWx1ZSwgdGVzdCkge1xyXG4gICAgICAgICAgICB0cmFuc2l0aW9uLmF0dHJUd2VlbignZCcsIChkKSA9PiB7XHJcbiAgICAgICAgICAgICAgICBsZXQgaW50ZXJwb2xhdGUgPSBkMy5pbnRlcnBvbGF0ZShkLmVuZEFuZ2xlLCAoKGVuZEFuZ2xlKSkgKiAobmV3VmFsdWUgLyAxMDApKTtcclxuICAgICAgICAgICAgICAgIGxldCBpbnRlcnBvbGF0ZUNvdW50ID0gZDMuaW50ZXJwb2xhdGUoMCwgbmV3VmFsdWUpO1xyXG5cclxuICAgICAgICAgICAgICAgIHJldHVybiAodCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgIGQuZW5kQW5nbGUgPSBpbnRlcnBvbGF0ZSh0KTtcclxuICAgICAgICAgICAgICAgICAgICB0ZXN0Ll9wZXJjZW50YWdlVGV4dC50ZXh0KE1hdGguZmxvb3IoaW50ZXJwb2xhdGVDb3VudCh0KSkgKyAnJScpO1xyXG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBhcmNMaW5lKGQpO1xyXG4gICAgICAgICAgICAgICAgfTtcclxuICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgfTtcclxuXHJcbiAgICAgICAgdGhpcy5fcG9pbnRlci50cmFuc2l0aW9uKClcclxuICAgICAgICAgICAgLmR1cmF0aW9uKDc1MClcclxuICAgICAgICAgICAgLmVhc2UoZDMuZWFzZUN1YmljSW4pXHJcbiAgICAgICAgICAgIC5jYWxsKGFyY1R3ZWVuLCBwZXJjZW50LCB0aGlzKVxyXG4gICAgICAgICAgICAuc3R5bGUoJ2ZpbGwnLCBkMy5yZ2IoJyNGRjAwMDAnKSk7XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfc2V0RGF0YUxhYmVsKF9wYXJhbXM6IGFueSk6IHZvaWQge1xyXG4gICAgICAgIGlmICghdGhpcy5jb25maWcuY2hhcnQubGFiZWxzLmVuYWJsZWQpIHJldHVybjtcclxuICAgICAgICBpZiAodGhpcy5jaGFydENhdGVnb3J5ICE9PSAncGllJykgcmV0dXJuO1xyXG4gICAgICAgIGlmICh0aGlzLl9wb3NBcnJheS5sZW5ndGggPT09IDApIHJldHVybjtcclxuICAgICAgICBsZXQgbGluZSA9IEFycmF5LmZyb20oZG9jdW1lbnQucXVlcnlTZWxlY3RvckFsbCgnIycgKyB0aGlzLmNvbmZpZy5pZCArICcua2R4LWNoYXJ0cyAua2R4LWNoYXJ0cy1saW5lcycpKTtcclxuICAgICAgICBsaW5lLmZvckVhY2goZSA9PiBlLnBhcmVudE5vZGUucmVtb3ZlQ2hpbGQoZSkpO1xyXG5cclxuICAgICAgICBsZXQga2V5ID0gKGQpID0+IHsgcmV0dXJuIGQuZGF0YS55OyB9O1xyXG5cclxuICAgICAgICBmdW5jdGlvbiBtaWRBbmdsZShfZCkge1xyXG4gICAgICAgICAgICByZXR1cm4gX2Quc3RhcnRBbmdsZSArIChfZC5lbmRBbmdsZSAtIF9kLnN0YXJ0QW5nbGUpIC8gMjtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIGxldCBoZWlnaHQgPSB0aGlzLnN2Z0NvbnRhaW5lci5ub2RlKCkuZ2V0Qm91bmRpbmdDbGllbnRSZWN0KCkuaGVpZ2h0O1xyXG4gICAgICAgIGxldCB3aWR0aCA9IHRoaXMuc3ZnQ29udGFpbmVyLm5vZGUoKS5nZXRCb3VuZGluZ0NsaWVudFJlY3QoKS53aWR0aDtcclxuICAgICAgICBoZWlnaHQgPSAodGhpcy5jaGFydFR5cGVbMV0gJiYgdGhpcy5jaGFydFR5cGVbMV0gPT09ICdoYWxmJykgPyAoKGhlaWdodCAvIDQpICogMykgLSA4IDogaGVpZ2h0IC8gMiAtIDg7XHJcbiAgICAgICAgZm9yIChsZXQgaSA9IDA7IGkgPCB0aGlzLl9wYXRoLl9ncm91cHNbMF0ubGVuZ3RoOyBpKyspIHtcclxuICAgICAgICAgICAgaWYgKHRoaXMuX3Bvc0FycmF5W2ldICYmIHRoaXMuX3Bvc0FycmF5W2ldLmlkICE9PSB1bmRlZmluZWQpIHtcclxuICAgICAgICAgICAgICAgIGxldCBwb3NQb2ludGVyID0gZG9jdW1lbnQucXVlcnlTZWxlY3RvcignIycgKyB0aGlzLmNvbmZpZy5pZCArICcgIycgKyB0aGlzLl9wb3NBcnJheVtpXS5pZCkuZ2V0QXR0cmlidXRlKCdwb3MnKTtcclxuICAgICAgICAgICAgICAgIGlmICh0aGlzLl9wb3NBcnJheS5sZW5ndGggIT09IDAgJiYgZG9jdW1lbnQucXVlcnlTZWxlY3RvcignIycgKyB0aGlzLmNvbmZpZy5pZCArICcgIycgKyB0aGlzLl9wb3NBcnJheVtpXS5pZCkgIT09IG51bGwgJiYgcG9zUG9pbnRlciAhPT0gbnVsbCkge1xyXG4gICAgICAgICAgICAgICAgICAgIGxldCB5RGF0YSA9IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgJ2lkJzogdGhpcy5fcG9zQXJyYXlbaV0uaWQsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICd2YWx1ZSc6IHRoaXMuX3Bvc0FycmF5W2ldLnZhbHVlXHJcbiAgICAgICAgICAgICAgICAgICAgfTtcclxuICAgICAgICAgICAgICAgICAgICBsZXQgeHZhbHVlOiBudW1iZXIgPSBwYXJzZUludChwb3NQb2ludGVyLnNwbGl0KCcsJylbMF0pICsgd2lkdGggLyAyO1xyXG4gICAgICAgICAgICAgICAgICAgIGxldCB5dmFsdWU6IG51bWJlciA9IHBhcnNlSW50KHBvc1BvaW50ZXIuc3BsaXQoJywnKVsxXSkgKyBoZWlnaHQ7XHJcbiAgICAgICAgICAgICAgICAgICAgbGV0IHRlbXBDb25kaXRpb246IG51bWJlciA9IHBhcnNlSW50KHBvc1BvaW50ZXIuc3BsaXQoJywnKVswXSk7XHJcbiAgICAgICAgICAgICAgICAgICAgbGV0IHJ0bENvbmRpdGlvbjogYm9vbGVhbiA9IHRoaXMuaXNSdGwgPT09IGZhbHNlID8gdGVtcENvbmRpdGlvbiA8IDAgOiB0ZW1wQ29uZGl0aW9uID4gMDtcclxuICAgICAgICAgICAgICAgICAgICBsZXQgY2hlY2tGbGV4RW5kU3R5bGU6IHN0cmluZyA9IHJ0bENvbmRpdGlvbiA/ICdmbGV4LWVuZCcgOiAnZmxleC1zdGFydCc7XHJcbiAgICAgICAgICAgICAgICAgICAgbGV0IGRhdGFMYWJlbENsYXNzID0gJyMnICsgdGhpcy5jb25maWcuaWQgKyAnIC5rZHgtY2hhcnRzLWRhdGEtbGFiZWwueC0nICsgdGhpcy5fcG9zQXJyYXlbaV0ueCArICcueS0nICsgeURhdGEuaWQ7XHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3IoZGF0YUxhYmVsQ2xhc3MpID09IG51bGwpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgc3VwZXIuc2V0TGFiZWwoeURhdGEsIHRoaXMuX3Bvc0FycmF5W2ldLngsIHh2YWx1ZSwgeXZhbHVlKS5zdHlsZSgndmlzaWJpbGl0eScsICd2aXNpYmxlJykuc3R5bGUoJ3dpZHRoJywgJzBweCcpLnN0eWxlKCdqdXN0aWZ5LWNvbnRlbnQnLCBjaGVja0ZsZXhFbmRTdHlsZSk7XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICB0aGlzLl9wb2x5bGluZSA9IHRoaXMuZ3JhcGguYXBwZW5kKCdnJylcclxuICAgICAgICAgICAgLmF0dHIoJ2NsYXNzJywgJ2tkeC1jaGFydHMtbGluZXMnKVxyXG4gICAgICAgICAgICAuc2VsZWN0QWxsKCdwb2x5bGluZScpXHJcbiAgICAgICAgICAgIC5kYXRhKF9wYXJhbXMucGllKHRoaXMucGllRGF0YSksIGtleSlcclxuICAgICAgICAgICAgLmVudGVyKClcclxuICAgICAgICAgICAgLmFwcGVuZCgncG9seWxpbmUnKVxyXG4gICAgICAgICAgICAuc3R5bGUoJ3N0cm9rZScsIChkLCBpKSA9PiB7XHJcbiAgICAgICAgICAgICAgICByZXR1cm4gdGhpcy5sZWdlbmRbZC5kYXRhLmlkXS5jb2xvcjtcclxuICAgICAgICAgICAgfSkuYXR0cigncG9pbnRzJywgKGQpID0+IHtcclxuICAgICAgICAgICAgICAgIHJldHVybiBnZXRQb3MoZCwgdGhpcy5jaGFydFR5cGVbMV0pO1xyXG4gICAgICAgICAgICB9KS5zdHlsZSgnZmlsbCcsICdub25lJyk7XHJcblxyXG4gICAgICAgIC8vIGlmICghdGhpcy5jb25maWcuYW5pbWF0aW9uKSB7XHJcbiAgICAgICAgLy8gICAgIHRoaXMuX3BvbHlsaW5lLmF0dHIoJ3BvaW50cycsIChkKSA9PiB7XHJcbiAgICAgICAgLy8gICAgICAgICByZXR1cm4gZ2V0UG9zKGQsIHRoaXMuY2hhcnRUeXBlWzFdKTtcclxuICAgICAgICAvLyAgICAgfSk7XHJcbiAgICAgICAgLy8gICAgIHJldHVybjtcclxuICAgICAgICAvLyB9XHJcblxyXG4gICAgICAgIC8vIHRoaXMuX3BvbHlsaW5lLnRyYW5zaXRpb24oKS5kdXJhdGlvbigxMDAwKVxyXG4gICAgICAgIC8vICAgICAuYXR0clR3ZWVuKCdwb2ludHMnLCAoZCkgPT4ge1xyXG4gICAgICAgIC8vICAgICAgICAgdGhpcy5fY3VycmVudCA9IHRoaXMuX2N1cnJlbnQgfHwgZDtcclxuICAgICAgICAvLyAgICAgICAgIGxldCBpbnRlcnBvbGF0ZSA9IGQzLmludGVycG9sYXRlKHRoaXMuX2N1cnJlbnQsIGQpO1xyXG4gICAgICAgIC8vICAgICAgICAgdGhpcy5fY3VycmVudCA9IGludGVycG9sYXRlKDApO1xyXG4gICAgICAgIC8vICAgICAgICAgcmV0dXJuICh0KSA9PiB7XHJcbiAgICAgICAgLy8gICAgICAgICAgICAgbGV0IGQyID0gaW50ZXJwb2xhdGUodCk7XHJcbiAgICAgICAgLy8gICAgICAgICAgICAgcmV0dXJuIGdldFBvcyhkMiwgdGhpcy5jaGFydFR5cGVbMV0pO1xyXG4gICAgICAgIC8vICAgICAgICAgfTtcclxuICAgICAgICAvLyAgICAgfSk7XHJcblxyXG4gICAgICAgIGZ1bmN0aW9uIGdldFBvcyhfZDIsIF9jaGFydFR5cGUpIHtcclxuICAgICAgICAgICAgbGV0IHBvcyA9IF9wYXJhbXMub3V0ZXJhcmMuY2VudHJvaWQoX2QyKTtcclxuICAgICAgICAgICAgaWYgKF9jaGFydFR5cGUgJiYgX2NoYXJ0VHlwZSA9PT0gJ2hhbGYnKSB7XHJcbiAgICAgICAgICAgICAgICBwb3NbMF0gPSBfcGFyYW1zLnJhZGl1cyAqIDAuOTUgKiAobWlkQW5nbGUoX2QyKSA8IF9wYXJhbXMuZGF0YUxhYmVsQ2hlY2sgPyAtMSA6IDEpO1xyXG4gICAgICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgcG9zWzBdID0gX3BhcmFtcy5yYWRpdXMgKiAwLjk1ICogKG1pZEFuZ2xlKF9kMikgPCBfcGFyYW1zLmRhdGFMYWJlbENoZWNrID8gMSA6IC0xKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICByZXR1cm4gW19wYXJhbXMuYXJjLmNlbnRyb2lkKF9kMiksIF9wYXJhbXMub3V0ZXJhcmMuY2VudHJvaWQoX2QyKSwgcG9zXTtcclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG5cclxuICAgIHByaXZhdGUgX2dldElubmVyUmFkaXVzKF9pbmRleDogbnVtYmVyLCBfbnVtQXJjczogbnVtYmVyLCBfYXJjV2lkdGg6IG51bWJlcik6IG51bWJlciB7XHJcbiAgICAgICAgcmV0dXJuIGFyY01pblJhZGl1cyArIChfbnVtQXJjcyAtIChfaW5kZXggKyAxKSkgKiAoX2FyY1dpZHRoICsgYXJjUGFkZGluZyk7XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfZ2V0T3V0ZXJSYWRpdXMoX2luZGV4OiBudW1iZXIsIF9udW1BcmNzOiBudW1iZXIsIF9hcmNXaWR0aDogbnVtYmVyKTogbnVtYmVyIHtcclxuICAgICAgICByZXR1cm4gdGhpcy5fZ2V0SW5uZXJSYWRpdXMoX2luZGV4LCBfbnVtQXJjcywgX2FyY1dpZHRoKSArIF9hcmNXaWR0aDtcclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF9yYWQyZGVnKF9hbmdsZTogbnVtYmVyKTogbnVtYmVyIHtcclxuICAgICAgICByZXR1cm4gX2FuZ2xlICogMTgwIC8gUEk7XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfcGF0aEFuaW0oX3BhdGg6IGFueSwgZGlyOiBhbnksIF9pbm5lclJhZGl1czogYW55LCBfb3V0ZXJSYWRpdXM6IGFueSk6IHZvaWQge1xyXG4gICAgICAgIHN3aXRjaCAoZGlyKSB7XHJcbiAgICAgICAgICAgIGNhc2UgZmFsc2U6XHJcbiAgICAgICAgICAgICAgICBfcGF0aC50cmFuc2l0aW9uKClcclxuICAgICAgICAgICAgICAgICAgICAuZHVyYXRpb24oNTAwKVxyXG4gICAgICAgICAgICAgICAgICAgIC8vIC5lYXNlKCdib3VuY2UnKVxyXG4gICAgICAgICAgICAgICAgICAgIC5hdHRyKCdkJywgZDMuYXJjKClcclxuICAgICAgICAgICAgICAgICAgICAgICAgLmlubmVyUmFkaXVzKF9pbm5lclJhZGl1cylcclxuICAgICAgICAgICAgICAgICAgICAgICAgLm91dGVyUmFkaXVzKF9vdXRlclJhZGl1cylcclxuICAgICAgICAgICAgICAgICAgICApLmF0dHIoJ3N0cm9rZScsICdub25lJyk7XHJcbiAgICAgICAgICAgICAgICBicmVhaztcclxuXHJcbiAgICAgICAgICAgIGNhc2UgdHJ1ZTpcclxuICAgICAgICAgICAgICAgIF9wYXRoLnRyYW5zaXRpb24oKVxyXG4gICAgICAgICAgICAgICAgICAgIC5hdHRyKCdkJywgZDMuYXJjKClcclxuICAgICAgICAgICAgICAgICAgICAgICAgLmlubmVyUmFkaXVzKF9pbm5lclJhZGl1cylcclxuICAgICAgICAgICAgICAgICAgICAgICAgLm91dGVyUmFkaXVzKF9vdXRlclJhZGl1cyAqIDEuMSlcclxuICAgICAgICAgICAgICAgICAgICApLmF0dHIoJ3N0cm9rZScsICd3aGl0ZScpLmF0dHIoJ3N0cm9rZS13aWR0aCcsIDIpO1xyXG4gICAgICAgICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG59XHJcbiJdfQ==