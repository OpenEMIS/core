import { Component, ViewEncapsulation, Input, Output, EventEmitter, ElementRef } from '@angular/core';
import { KdChartBaseClass } from '../kd-angular-chart-base-class';
import { KdChartsSvc } from '../kd-angular-charts-svc';
import { KdDomElemSvc } from '../../kd-common/index';
import { KdMapChartSvc } from './kd-angular-map-chart-svc';
import * as d3 from 'd3';
import * as L from 'leaflet';
import 'leaflet.markercluster';
import 'leaflet.awesome-markers/dist/leaflet.awesome-markers';
export class KdMapChart extends KdChartBaseClass {
    constructor(_elementRef, _chartSvc, _domSvc, _mapSvc) {
        super(_chartSvc, _domSvc);
        this._elementRef = _elementRef;
        this._chartSvc = _chartSvc;
        this._domSvc = _domSvc;
        this._mapSvc = _mapSvc;
        this._outputSeriesData = [];
        this._seriesData = [];
        this._emptySeries = false;
        this._singleLevelDimension = false;
        this._tileloadIndex = 0;
        this._isLayerError = false;
        this._layerReloadTimes = 0;
        this._isMapSelected = {};
        this.outputLegend = new EventEmitter(true);
        this.outputData = new EventEmitter(true);
        this.outputMarker = new EventEmitter(true);
        this.outputReady = new EventEmitter(true);
    }
    ngOnInit() {
        this.config = Object.assign({}, this.mapConfig);
        this.legendData = Object.assign({}, this.legend);
        this._setData();
        super.chartTimeout(() => this._setChart());
        this.api.redraw = () => {
            setTimeout(() => {
                this._overWriteSeries();
                this._resetChart();
                this._setChart();
                // if (!this.config.skipMassage) {
                //     this.legend = this._chartSvc.setMapLegendData(this.legend, this._seriesData, this.config);
                // }
                this._getLegendByType();
            });
        };
        this.api.legendClick = (_id, _legendActive) => {
            this.legend[_id].deactive = _legendActive;
            for (let i = 0; i < this._seriesData.length; i++) {
                if (this._seriesData[i].id && this._seriesData[i].id == this.legend[_id].mapSeriesId) {
                    this._seriesData[i].deactive = _legendActive;
                }
            }
            this.data['mapSeriesData'] = this._seriesData;
            if (this._singleLevelDimension == false)
                this._getNewSeries();
            this._resetChart();
            this._setChart();
        };
        this.api.clusterClick = (_id, _legendItem) => {
            let selectedMarkerGroup;
            selectedMarkerGroup = this._clusterData.clusterMarkers[_id.id];
            if (this._leafletMap.hasLayer(selectedMarkerGroup)) {
                this._leafletMap.removeLayer(selectedMarkerGroup);
                this._domSvc.addClass(_legendItem.legendItemMarker, 'awesome-marker-icon-lightgray');
                this._domSvc.addClass(_legendItem.legendItemLabel, 'kdx-label-lightgray');
            }
            else {
                this._leafletMap.addLayer(selectedMarkerGroup);
                this._domSvc.removeClass(_legendItem.legendItemMarker, 'awesome-marker-icon-lightgray');
                this._domSvc.removeClass(_legendItem.legendItemLabel, 'kdx-label-lightgray');
            }
        };
    }
    ngOnChanges(_simpleChanges) {
        if (_simpleChanges.hasOwnProperty('data') && !_simpleChanges['data'].firstChange) {
            this.data = _simpleChanges.data.currentValue;
            this._redrawChart('data');
        }
        if (_simpleChanges.hasOwnProperty('mapConfig') && !_simpleChanges['mapConfig'].firstChange) {
            if (this.mapConfig.plotOptions.map.zoom) {
                this._checkZoomConfig(this.mapConfig.plotOptions.map.zoom);
                if (this.mapConfig.plotOptions.map.zoom.value) {
                    if (typeof this._leafletMap !== 'undefined')
                        this._leafletMap.setZoom(this.mapConfig.plotOptions.map.zoom.value);
                }
                // need to check why legend keep gone
                // if (this.chartType[1] === 'full' || this.chartType[1] === 'cluster') this._setMarkers();
            }
            this.mapConfig = _simpleChanges.mapConfig.currentValue;
            this._redrawChart('config');
        }
    }
    ngAfterViewInit() {
        if (typeof this._leafletMap !== 'undefined')
            this._leafletMap.invalidateSize({});
    }
    ngOnDestroy() {
        this._resetChart();
    }
    _redrawChart(_changes) {
        this._resetChart();
        if (_changes === 'data') {
            this._seriesData = [];
        }
        else {
            this.config = Object.assign({}, this.mapConfig);
        }
        this.legendData = Object.assign({}, this.legend);
        this._setData();
        super.chartTimeout(() => this._setChart());
    }
    _setChart() {
        this.chartType = this.data.chart.layout.split('-');
        if (this._level !== undefined && this._level !== null) {
        }
        else if ((this.data['mapLevel'] && this.config.skipMassage) || (this.data['mapLevel'] && this._singleLevelDimension == true)) {
            // if ((this.data['mapLevel'] && this.config.skipMassage) || (this.data['mapLevel'] && this._singleLevelDimension == true)) {
            let tmpLevelArr = Object.keys(this.data.mapData);
            this._defaultLevel = tmpLevelArr.length > 0 ? tmpLevelArr[0] : this.data['mapLevel'];
            this._level = this.data['mapLevel'];
            // checking if map got area filter
        }
        else if (this.data.series[this.data.series.length - 1].data && this.data.series[this.data.series.length - 1].data.length == 1) {
            this._defaultLevel = this._mapSvc.getMapLevelWithAreaFilter(this.data.series[this.data.series.length - 1].data[0].ID_, this.data.mapData);
            this._level = this._defaultLevel;
        }
        else {
            let tmpLevelArr = Object.keys(this.data.mapData);
            this._defaultLevel = tmpLevelArr.length > 0 ? tmpLevelArr[0] : 'l_1';
            this._level = this._defaultLevel;
        }
        this._getColorPointer();
        // instead of legend, draw the map color scale. must be completed before svg dimension is fixed
        if (this.config.colorAxis != undefined && this.config.colorAxis.dataClasses == undefined) {
            this._drawMapScale();
        }
        super.setSvg();
        super.setSvgDimension('x');
        super.setSvgDimension('y');
        this._height = this.svgContainer.node().getBoundingClientRect().height;
        this._width = this.svgContainer.node().getBoundingClientRect().width;
        if (this.chartType[1] === 'polygon' || this.chartType[1] === 'thematic') {
            this._drawPolygonMap();
        }
        else if (this.chartType[1] === 'full' || this.chartType[1] === 'cluster' || this.chartType[1] === 'filter') {
            this._drawLeaftlet();
            setTimeout(() => {
                if (typeof this._leafletMap !== 'undefined')
                    this._leafletMap.invalidateSize({});
            });
            if (this.chartType[1] !== 'cluster')
                this._drawFullMap();
        }
        // console.log('data ', this.data)
        // console.log('config ', this.config)
    }
    _setData() {
        this.chartCategory = 'map';
        if (this.data['mapSeriesData'] && this.config.skipMassage) {
            // export mode
            this._seriesData = JSON.parse(JSON.stringify(this.data['mapSeriesData']));
            if (this.config.colorAxis != undefined) {
                // single dimension
                this._seriesPointer = this._mapSvc.getSeriesPointer(this._seriesData);
            }
            else {
                this._getNewSeries();
            }
        }
        else {
            this._seriesData = JSON.parse(JSON.stringify(this.data.series));
            for (let i = 0; i < this._seriesData.length; i++) {
                this._seriesData[i]['deactive'] = false;
            }
            if (this.config.colorAxis != undefined) {
                // single dimension
                this._seriesPointer = this._mapSvc.getSeriesPointer(this._seriesData);
            }
            else {
                // multi dimension
                if (this._seriesData && this._seriesData.length != 0) {
                    this._seriesPointer = this._seriesData[this._seriesData.length - 1];
                }
            }
            this._emptySeries = this._seriesPointer == undefined ? true : false;
        }
        // if (!this.config.skipMassage) {
        //     this.legend = this._chartSvc.setMapLegendData(this.legend, this._seriesData, this.config);
        // }
        this._getColorPointer();
        this._getLegendByType();
    }
    _resetChart() {
        if (typeof this._zoomBtns !== 'undefined') {
            this._zoomBtns.remove();
            this._zoomBtns = undefined;
        }
        if (this._leafletMap !== undefined && this._leafletMap !== null && !this.config.skipMassage) {
            this._leafletMap.remove();
            this._leafletMap = undefined;
            let leaftletId = '#' + this.config.id + 'Leaflet';
            document.querySelector(leaftletId).setAttribute('class', 'kdx-charts-svg-container');
        }
        if (typeof this._mapLayer !== 'undefined') {
            this._mapLayer.remove();
            this._mapLayer = undefined;
        }
        if (typeof this._fullGraph !== 'undefined') {
            this._fullGraph.remove();
            this._fullGraph = undefined;
        }
        if (typeof this._backBtn !== 'undefined') {
            this._backBtn.remove();
            this._backBtn = undefined;
        }
        this._level = undefined;
        this._outputSeriesData = [];
        this._isMapSelected = {};
        super.removeChart();
    }
    _drawLeaftlet() {
        if (this._leafletMap !== undefined && this._leafletMap !== null)
            this._leafletMap.remove();
        let zoomValue = 6;
        if (this.chartType[1] === 'filter' && this.data.position && this.data.position.zoom) {
            zoomValue = this.data.position.zoom;
        }
        else if (this.config.plotOptions.map.zoom && this.config.plotOptions.map.zoom.value) {
            zoomValue = this.config.plotOptions.map.zoom.value;
        }
        let leaftletId = this.config.id + 'Leaflet';
        this._leafletMap = L.map(leaftletId).setView([this.data.position.latitude, this.data.position.longitude], zoomValue);
        this._setLayer();
        this._removeDefaultAttribution('OpenEMIS');
        if (this.chartType[1] === 'full' || this.chartType[1] === 'cluster')
            this._setMarkers();
    }
    _drawFullMap() {
        this._outputSeriesData = [];
        if (typeof this._fullGraph === 'undefined')
            this._fullGraph = d3.select(this._leafletMap.getPanes().overlayPane).append("svg");
        // this._fullGraph = d3.select(this._leafletMap.getPanes().overlayPane).append("svg");
        this._mapLayer = this._fullGraph.append("g").attr("class", "leaflet-zoom-hide");
        let map = this._leafletMap;
        let svg = this._fullGraph;
        let currentChartId = this.config.id;
        let mapLayer = this._mapLayer;
        let width = this._width;
        let height = this._height;
        let transform = d3.geoTransform({
            point: function (x, y) {
                let point = map.latLngToLayerPoint(new L.LatLng(y, x));
                this.stream.point(point.x, point.y);
            }
        }), path = d3.geoPath().projection(transform);
        let valueKey, filterValueObj;
        if (this.chartType[1] === 'filter' && this.data.hasOwnProperty('value') && (this.data.value !== undefined || this.data.value !== null)) {
            valueKey = Object.keys(this.data.value)[0];
            filterValueObj = this.data.value[valueKey];
        }
        // this._mapLayer = this._path.append('g').classed('map-layer', true);
        // allow user to define or change the level of the map
        if (this.config.plotOptions.map.level && (this.config.plotOptions.map.level !== '' || this.config.plotOptions.map.level !== undefined || this.config.plotOptions.map.level !== null) && this._mapSvc.checkMapLevelExist(this.config.plotOptions.map.level, this.data.mapData)) {
            if ((this.chartType[1] === 'full' && this.config.plotOptions.map.mapFullChangeLevelDefault === true) || this.chartType[1] !== 'full') {
                this._level = this.config.plotOptions.map.level;
            }
            else {
                this._checkBackBtn();
            }
        }
        else {
            this._checkBackBtn();
        }
        let data = this.data.mapData.hasOwnProperty(this._level) ? this.data.mapData[this._level] : this.data.mapData;
        let projection = d3.geoMercator().fitSize([this._width, this._height - 50], data);
        // let path = d3.geoPath().projection(projection);
        let features = this.data.mapData.hasOwnProperty('features') ? this.data.mapData.features : this.data.mapData[this._level].features;
        let mapPath = this._mapLayer.selectAll('path')
            .data(features)
            .enter().append('path')
            // .attr('d', path)
            .attr('id', (d) => { return this._mapSvc.pathIdPrefix + d.properties.ID_; })
            .attr('class', (d) => {
            if (this._emptySeries == false && this._seriesPointer && this._seriesPointer.data != undefined) {
                let seriesValue = this._getSeriesValue(d.properties.ID_);
                this._outputSeriesData.push({ 'name': seriesValue.name, 'value': seriesValue.value, 'id': d.properties.ID_ });
                return 'id-' + seriesValue.id + ', name-' + seriesValue.name + ', drilldown-' + seriesValue.drilldown + ', value-' + seriesValue.value;
            }
        })
            .attr('vector-effect', 'non-scaling-stroke')
            .style('fill', (d) => {
            if (this.chartType[1] === 'filter' && this.data.hasOwnProperty('value') && (this.data.value !== undefined || this.data.value !== null)) {
                if (d.hasOwnProperty('properties') && d.properties.ID_ === filterValueObj.id && d.properties.NAME1_ === filterValueObj.name) {
                    this._isMapSelected = {};
                    this._isMapSelected[d.properties.ID_] = d.properties.ID_;
                    return this.config.plotOptions.map.states.select.color;
                }
                else {
                    return this._getMapFillColor(d);
                }
            }
            else {
                return this._getMapFillColor(d);
            }
        })
            .style('stroke-width', (d) => {
            if (this.chartType[1] === 'filter' && this.data.hasOwnProperty('value') && (this.data.value !== undefined || this.data.value !== null)) {
                if (d.hasOwnProperty('properties') && d.properties.ID_ === filterValueObj.id && d.properties.NAME1_ === filterValueObj.name) {
                    return this.config.plotOptions.map.filter.borderSelected ? this.config.plotOptions.map.filter.borderSelected : this.config.plotOptions.map.borderWidth;
                }
                else {
                    return (this.chartType[1] === 'filter' && this.config.plotOptions.map.filter.border) ? this.config.plotOptions.map.filter.border : this.config.plotOptions.map.borderWidth;
                }
            }
            else {
                return (this.chartType[1] === 'filter' && this.config.plotOptions.map.filter.border) ? this.config.plotOptions.map.filter.border : this.config.plotOptions.map.borderWidth;
            }
        })
            .style('stroke', this.config.plotOptions.map.borderColor)
            //due to leaflet blocking pointer events
            .style('pointer-events', 'visible')
            .style('opacity', 0.6);
        this._leafletMap.on("viewreset", reset);
        this._leafletMap.on("zoom", reset);
        let mapLevel = this.data.mapData[this._level];
        reset();
        let elements = Array.from(document.querySelectorAll('#' + this.config.id + '.kdx-charts svg .leaflet-zoom-hide'));
        elements.forEach((el) => {
            el.addEventListener('mouseover', (d) => {
                let targetElement = d.target;
                let targetGeojsonId = this._mapSvc.getTargetGeojsonId(targetElement);
                let currentSelection = this._mapSvc.getCurrentSelection(this.svgContainer, targetElement.getAttribute('id'));
                if (this._checkEmptyDataValue(targetGeojsonId)) {
                    if (this.chartType[1] !== 'filter' || (this.chartType[1] === 'filter' && !this._checkMapSelected(targetGeojsonId))) {
                        currentSelection.style('fill', this.config.plotOptions.map.states.hover.color);
                    }
                    if (this.chartType[1] === 'filter' && this.config.plotOptions.map.filter && this.config.plotOptions.map.filter.borderHover && !this._checkMapSelected(targetGeojsonId)) {
                        currentSelection.style('stroke-width', this.config.plotOptions.map.filter.borderHover);
                    }
                }
            });
            el.addEventListener('mouseout', (d) => {
                let targetElement = d.target;
                let targetGeojsonId = this._mapSvc.getTargetGeojsonId(targetElement);
                let currentSelection = this._mapSvc.getCurrentSelection(this.svgContainer, targetElement.getAttribute('id'));
                if (this._checkEmptyDataValue(targetGeojsonId)) {
                    if (this.chartType[1] !== 'filter' || (this.chartType[1] === 'filter' && !this._checkMapSelected(targetGeojsonId))) {
                        currentSelection.style('fill', (d2) => {
                            return this._getMapFillColor(d2);
                        });
                    }
                    if (this.chartType[1] === 'filter' && this.config.plotOptions.map.filter && this.config.plotOptions.map.filter.border && !this._checkMapSelected(targetElement.getAttribute('id'))) {
                        currentSelection.style('stroke-width', this.config.plotOptions.map.filter.border);
                    }
                }
            });
            el.addEventListener('click', (d) => {
                let targetElement = d.target;
                let targetGeojsonId = this._mapSvc.getTargetGeojsonId(targetElement);
                let currentSelection = this._mapSvc.getCurrentSelection(this.svgContainer, targetElement.getAttribute('id'));
                if ((this.chartType[1] === 'full' && this.config.plotOptions.map.mapFullChangeLevelDefault === true) || this.chartType[1] !== 'full') {
                    this.outputData.emit(currentSelection.attr('class'));
                    if (this.chartType[1] === 'filter') {
                        let setClickBorderCondition = (this.config.plotOptions.map.filter && this.config.plotOptions.map.filter.borderSelected && this.config.plotOptions.map.filter.borderSelected != undefined);
                        //change the color for the area selected
                        if (this.config.plotOptions.map.states && this.config.plotOptions.map.states.select && this.config.plotOptions.map.states.select.color && this.config.plotOptions.map.states.select.color !== '') {
                            if (Object.keys(this._isMapSelected).length !== 0) {
                                let previousAreaId = Object.keys(this._isMapSelected)[0];
                                d3.select('#' + this.config.id + '.kdx-charts svg .leaflet-zoom-hide').select('#' + this._mapSvc.pathIdPrefix + previousAreaId).style('fill', (d2) => {
                                    return this._getMapFillColor(d2);
                                });
                                if (setClickBorderCondition)
                                    d3.select('#' + this.config.id + '.kdx-charts svg .leaflet-zoom-hide').select('#' + this._mapSvc.pathIdPrefix + previousAreaId).style('stroke-width', this.config.plotOptions.map.filter.border);
                                this._isMapSelected = {};
                                if (previousAreaId !== targetGeojsonId) {
                                    this._isMapSelected[targetGeojsonId] = targetGeojsonId;
                                    currentSelection.style('fill', this.config.plotOptions.map.states.select.color);
                                    if (setClickBorderCondition)
                                        currentSelection.style('stroke-width', this.config.plotOptions.map.filter.borderSelected);
                                }
                            }
                            else {
                                this._isMapSelected = {};
                                this._isMapSelected[targetGeojsonId] = targetGeojsonId;
                                currentSelection.style('fill', this.config.plotOptions.map.states.select.color);
                                if (setClickBorderCondition)
                                    currentSelection.style('stroke-width', this.config.plotOptions.map.filter.borderSelected);
                            }
                        }
                    }
                }
                else {
                    if (this._checkEmptyDataValue(targetGeojsonId)) {
                        this._changeLevel(this._level, 'add');
                    }
                }
            });
        });
        // Reposition the SVG to cover the features.
        function reset() {
            let bounds = path.bounds(mapLevel), topLeft = bounds[0], bottomRight = bounds[1];
            // console.log('width ', JSON.parse(JSON.stringify(bottomRight[0] - topLeft[0])))
            svg.attr("width", bottomRight[0] - topLeft[0])
                .attr("height", bottomRight[1] - topLeft[1])
                .style("left", topLeft[0] + "px")
                .style("top", topLeft[1] + "px");
            if (!d3.select('#' + currentChartId + '.kdx-charts svg .leaflet-zoom-hide').select('#backBtn').empty()) {
                d3.select('#' + currentChartId + '.kdx-charts svg .leaflet-zoom-hide').select('#backBtn').attr('transform', function () {
                    return 'translate(' + (width - 100 - parseInt(topLeft[0])) + ',' + (height / 3 - parseInt(topLeft[1])) + ')';
                });
            }
            mapLayer.attr("transform", "translate(" + -topLeft[0] + "," + -topLeft[1] + ")");
            mapPath.attr("d", path);
        }
        let eventsParam = {
            'seriesData': this._outputSeriesData,
            'seriesName': this._seriesPointer.name,
            'tooltipLayer': d3.select(this._leafletMap.getPanes().overlayPane),
            'fullGraph': this._fullGraph
        };
        if (this.config.colorAxis != undefined && this.config.colorAxis.dataClasses == undefined) {
            eventsParam['callbacks'] = {
                'mouseover': (d) => this._setMapScaleTriangle(d),
                'mouseout': () => this._removeMapScaleTriangle()
            };
        }
        // add tooltop
        if (this._seriesPointer.data != undefined) {
            super._initMouseEvents(mapPath, eventsParam);
        }
    }
    _drawPolygonMap() {
        this._outputSeriesData = [];
        this._path = this.graph.attr('width', this._width).attr('height', this._height);
        this._mapLayer = this._path.append('g').classed('map-layer', true);
        if (this.config.mapNavigation && this.config.mapNavigation.enabled == true) {
            if (typeof this._zoomBtns === 'undefined')
                this._initZoomBtn();
        }
        // this._checkBackBtn();
        if (this.config.plotOptions.map.level && (this.config.plotOptions.map.level !== '' || this.config.plotOptions.map.level !== undefined || this.config.plotOptions.map.level !== null) && this._mapSvc.checkMapLevelExist(this.config.plotOptions.map.level, this.data.mapData)) {
            if (this.chartType[1] === 'thematic') {
                this._level = this.config.plotOptions.map.level;
            }
            else {
                this._checkBackBtn();
            }
        }
        else if (this.chartType[1] === 'polygon') {
            this._checkBackBtn();
        }
        let data = this.data.mapData.hasOwnProperty(this._level) ? this.data.mapData[this._level] : this.data.mapData;
        let projection = d3.geoMercator().fitSize([this._width, this._height - 50], data);
        let path = d3.geoPath().projection(projection);
        let features = this.data.mapData.hasOwnProperty('features') ? this.data.mapData.features : this.data.mapData[this._level].features;
        let mapPath = this._mapLayer.selectAll('path')
            .data(features)
            .enter().append('path')
            .attr('d', path)
            .attr('id', (d) => { return this._mapSvc.pathIdPrefix + d.properties.ID_; })
            .attr('class', (d) => {
            if (this._emptySeries == false && this._seriesPointer && this._seriesPointer.data != undefined) {
                let seriesValue = this._getSeriesValue(d.properties.ID_);
                this._outputSeriesData.push({ 'name': seriesValue.name, 'value': seriesValue.value, 'id': d.properties.ID_ });
                return 'id-' + seriesValue.id + ', name-' + seriesValue.name + ', drilldown-' + seriesValue.drilldown + ', value-' + seriesValue.value;
            }
        })
            .attr('vector-effect', 'non-scaling-stroke')
            .style('fill', (d) => {
            return this._getMapFillColor(d);
        })
            .style('stroke-width', this.config.plotOptions.map.borderWidth)
            .style('stroke', this.config.plotOptions.map.borderColor);
        // adding mouse events, hover color, change level
        if (this._emptySeries == false) {
            let elements = Array.from(document.querySelectorAll('#' + this.config.id + '.kdx-charts svg .map-layer'));
            elements.forEach((el) => {
                el.addEventListener('mouseover', (d) => {
                    let targetElement = d.target;
                    let targetElementId = targetElement.getAttribute('id').indexOf('id-') != -1 ? targetElement.getAttribute('id').split('id-')[1] : targetElement.getAttribute('id');
                    let currentSelection = this._mapSvc.getCurrentSelection(this.svgContainer, targetElement.getAttribute('id'), 'd3');
                    if (this._checkEmptyDataValue(targetElementId)) {
                        currentSelection.style('fill', this.config.plotOptions.map.states.hover.color);
                    }
                });
                el.addEventListener('mouseout', (d) => {
                    let targetElement = d.target;
                    let targetElementId = targetElement.getAttribute('id').indexOf('id-') != -1 ? targetElement.getAttribute('id').split('id-')[1] : targetElement.getAttribute('id');
                    let currentSelection = this._mapSvc.getCurrentSelection(this.svgContainer, targetElement.getAttribute('id'), 'd3');
                    if (this._checkEmptyDataValue(targetElementId)) {
                        currentSelection.style('fill', (d2) => {
                            return this._getMapFillColor(d2);
                        });
                    }
                });
                el.addEventListener('click', (d) => {
                    if (this.chartType[1] === 'polygon') {
                        let targetElement = d.target;
                        let targetGeojsonId = this._mapSvc.getTargetGeojsonId(targetElement);
                        if (this._checkEmptyDataValue(targetGeojsonId)) {
                            this._changeLevel(this._level, 'add');
                        }
                    }
                });
            });
            let eventsParam = {
                'seriesData': this._outputSeriesData,
                'seriesName': this._seriesPointer.name,
            };
            if (this.config.colorAxis != undefined && this.config.colorAxis.dataClasses == undefined) {
                eventsParam['callbacks'] = {
                    'mouseover': (d) => this._setMapScaleTriangle(d),
                    'mouseout': () => this._removeMapScaleTriangle()
                };
            }
            // add tooltop
            if (this._seriesPointer.data != undefined) {
                super._initMouseEvents(mapPath, eventsParam);
            }
        }
    }
    _getMapFillColor(_value) {
        if (this._seriesPointer == undefined || this._seriesPointer.data == undefined)
            return '#F2F2F2';
        let dataValue = this._getSeriesValue(_value.properties.ID_).value;
        if (this.chartType[1] === 'filter' && this.config.colorAxis && this.config.colorAxis.minColor) {
            return this.config.colorAxis.minColor;
        }
        if (dataValue == null || dataValue == '')
            return this.config.plotOptions.map.nullColor || 'rgb(0,0,0,0)';
        if (this.config.colorAxis != undefined && this.config.colorAxis.dataClasses == undefined) {
            return this._mapScaleColorScale(dataValue);
        }
        if (this._singleLevelDimension == true) {
            for (let i = 0; i < this.config.colorAxis.dataClasses.length; i++) {
                if (this._mapSvc.checkValueInBetween(Number(dataValue), this.config.colorAxis.dataClasses[i].from, this.config.colorAxis.dataClasses[i].to)) {
                    if (this.legend['id' + i] && this.legend['id' + i].deactive == true) {
                        return '#F2F2F2';
                    }
                    return this.config.colorAxis.dataClasses[i].color;
                }
                else if (i == this.config.colorAxis.dataClasses.length) {
                    return this.config.colorAxis.minColor;
                }
            }
        }
        if (this._emptySeries == false)
            return this._colorPointer.color;
        return '#F2F2F2';
    }
    _changeLevel(_level, _type) {
        let mapArr = Object.keys(this.data.mapData);
        let levelIndex = 0, newIndex;
        let newLevel;
        for (let i = 0; i < mapArr.length; i++) {
            if (mapArr[i] === _level)
                levelIndex = i;
        }
        if (_type === 'add') {
            if (levelIndex + 1 <= mapArr.length)
                newIndex = levelIndex + 1;
        }
        else {
            if (levelIndex - 1 >= 0)
                newIndex = levelIndex - 1;
        }
        if (newIndex !== undefined) {
            newLevel = mapArr[newIndex];
            if (this.data.mapData[newLevel] != undefined) {
                if (typeof this._mapLayer !== 'undefined') {
                    this._mapLayer.remove();
                }
                this._level = newLevel;
                this.data['mapLevel'] = this._level;
                if (this.config.colorAxis == undefined)
                    this._getDrillDownLegendForMultipleDimension();
                this._getColorPointer();
                if (this.chartType[1] === 'full') {
                    this._drawFullMap();
                }
                else
                    this._drawPolygonMap();
            }
        }
        // let op = _type == 'add' ? '+' : '-';
        // let operators = {
        //     '+': function(a, b) { return a + b; },
        //     '-': function(a, b) { return a - b; }
        // };
        // let newLevelPointer: string | string[] = _level.indexOf('_') != -1 ? _level.split('_') : _level;
        // let newLevel: string = _level.indexOf('_') != -1 ? newLevelPointer[0] + '_' + (operators[op](parseInt(newLevelPointer[1]), 1)) : (operators[op](parseInt(_level), 1)).toString();
    }
    _initZoomBtn() {
        // inserting the zoom buttons
        let zoomed = () => {
            const transform = d3.event.transform;
            this._mapLayer.attr('transform', 'translate(' + transform.x + ',' + transform.y + ') scale(' + transform.k + ')');
        };
        let zoom = d3.zoom().scaleExtent([1, 4]).on('zoom', zoomed);
        this._zoomBtns = this.graph.append('g').classed('zoom-layer', true);
        let zoomBtn = this._zoomBtns.selectAll('g')
            .data(['zoomIn', 'zoomOut'])
            .enter().append('g')
            .attr('id', function (d) { return d; })
            // .attr('transform', (d, i) => { return 'translate(10,' + ((this._height / 3) + (i * 28)) + ')'; })
            .attr('transform', (d, i) => { return 'translate(10,' + (10 + (i * 30)) + ')'; })
            .style('cursor', 'pointer')
            .on('click', (d, i) => { this._zoomClick(d, zoom); });
        zoomBtn.append('rect')
            .attr('width', '30px')
            .attr('height', '30px')
            .attr('rx', 1)
            .attr('ry', 1)
            .style('z-index', 1)
            .style('fill', '#fff')
            .style('stroke', '#ccc')
            .style('stroke-width', '2');
        zoomBtn.append('text')
            .attr('x', 14)
            .attr('y', 14)
            .attr('dy', '.35em')
            .attr('text-anchor', 'middle')
            .style('font-size', '22px')
            .style('font-weight', 'bold')
            .text(function (d, i) { return i == 0 ? '+' : '−'; });
        this._mapLayer.call(zoom);
    }
    _zoomClick(_zoomBtnId, _zoom) {
        let factor = _zoomBtnId == 'zoomIn' ? 1.2 : 0.8;
        _zoom.scaleBy(this._mapLayer, factor);
    }
    _initBackBtn() {
        // inserting the back button
        if (typeof this._backBtn !== 'undefined') {
            this._backBtn.remove();
            this._backBtn = undefined;
        }
        setTimeout(() => {
            if (this.chartType[1] !== 'full') {
                this._backBtn = this.graph.append('g').classed('btn-layer', true);
                let backBtnTranslatePosition = '';
                if (this.chartType[1] !== 'full') {
                    backBtnTranslatePosition = 'translate(' + (this._width - 100) + ',' + (this._height / 3) + ')';
                }
                else {
                    backBtnTranslatePosition = 'translate(' + (this._width - 100 - parseInt(this._fullGraph.node().style.left)) + ',' + (this._height / 3 - parseInt(this._fullGraph.node().style.top)) + ')';
                }
                let backBtn = this._backBtn.selectAll('g')
                    .data(['backBtn'])
                    .enter().append('g')
                    .attr('id', function (d) { return d; })
                    .attr('transform', (d, i) => { return backBtnTranslatePosition; })
                    .style('cursor', 'pointer')
                    .style('pointer-events', 'visible')
                    .on('click', (d) => { this._changeLevel(this._level, 'minus'); });
                backBtn.append('rect')
                    .attr('width', '56px')
                    .attr('height', '30px')
                    .style('fill', 'rgb(247, 247, 247)')
                    .style('stroke', 'rgb(204, 204, 204)')
                    .style('stroke-width', '1');
                backBtn.append('text')
                    .attr('x', 28)
                    .attr('y', 15)
                    .attr('dy', '.35em')
                    .attr('text-anchor', 'middle')
                    .style('font-size', '12px')
                    .style('font-weight', 'normal')
                    .text(function (d, i) { return this.isRtl ? 'Back ▷' : '◁ Back'; });
            }
            else {
                this._backBtn = this.svgContainer.append('div');
                this._backBtn.attr('class', 'kdx-map-chart-backbutton');
                this._backBtn.text(function (d, i) { return this.isRtl ? 'Back ▷' : '◁ Back'; });
                this._backBtn.on('click', (d) => { this._changeLevel(this._level, 'minus'); });
            }
        });
    }
    _checkBackBtn() {
        let checkDefaultLevel = this._checkDefaultLevel();
        if (checkDefaultLevel == true) {
            if (typeof this._backBtn === 'undefined')
                this._initBackBtn();
        }
        else {
            if (typeof this._backBtn !== 'undefined') {
                this._backBtn.remove();
                this._backBtn = undefined;
            }
        }
    }
    _checkDefaultLevel() {
        let checkDefault;
        let defaultLevel = this._defaultLevel.indexOf('_') != -1 ? this._defaultLevel.split('_')[1] : this._defaultLevel;
        if (this._level.indexOf('_') != -1) {
            checkDefault = parseInt(this._level.split('_')[1]) == defaultLevel ? false : true;
        }
        else {
            checkDefault = parseInt(this._level) == defaultLevel ? false : true;
        }
        return checkDefault;
    }
    _getSeriesValue(_seriesId) {
        let returnObj = {
            'id': '',
            'name': '',
            'drilldown': '',
            'value': ''
        };
        for (let i = 0; i < this._seriesPointer.data.length; i++) {
            if (this._seriesPointer.data[i].ID_ == _seriesId) {
                returnObj.id = this._seriesPointer.data[i].ID_;
                returnObj.name = this._seriesPointer.data[i].NAME1_;
                returnObj.drilldown = this._seriesPointer.data[i].drilldown;
                returnObj.value = this._seriesPointer.data[i].value;
                break;
            }
        }
        return returnObj;
    }
    _getNewSeries(_newLegend) {
        let legendPointer = _newLegend ? _newLegend : this.legend;
        let tempLegendArr = Object.keys(legendPointer).map(key => { return legendPointer[key]; });
        let newTempSeries = [];
        for (let i = 0; i < tempLegendArr.length; i++) {
            for (let j = 0; j < this._seriesData.length; j++) {
                if (tempLegendArr[i].deactive == false && this._seriesData[j].id == tempLegendArr[i].mapSeriesId) {
                    newTempSeries.push(this._seriesData[j]);
                    break;
                }
            }
        }
        this._emptySeries = newTempSeries.length != 0 ? false : true;
        if (newTempSeries.length != 0) {
            this._seriesPointer = newTempSeries[newTempSeries.length - 1];
        }
    }
    _getDrillDownLegendForMultipleDimension() {
        let tempLegend;
        if (this._checkDefaultLevel() == true) {
            tempLegend = this._chartSvc.setMapLegendData(this.legend, [this._seriesPointer], this.config);
        }
        else {
            tempLegend = this._chartSvc.setMapLegendData(this.legend, this._seriesData, this.config);
            this._getNewSeries(tempLegend);
        }
        this.outputLegend.emit(tempLegend);
    }
    _getColorPointer() {
        // let tempLegendArr = Object.keys(this.legend).map(item => this.legend[item]);
        let tempLegendArr = Object.keys(this.legendData).map(item => this.legendData[item]);
        if (this._seriesPointer != undefined) {
            for (let i = 0; i < tempLegendArr.length; i++) {
                if (this._seriesPointer.id == tempLegendArr[i].mapSeriesId) {
                    this._colorPointer = this.legendData[tempLegendArr[i].id];
                    // this._colorPointer = this.legend[tempLegendArr[i].id];
                    break;
                }
            }
        }
    }
    _overWriteSeries() {
        // change series color
        let tempLegendArr = Object.keys(this.legendData).map(item => this.legendData[item]);
        // let tempLegendArr = Object.keys(this.legend).map(item => this.legend[item]);
        for (let i = 0; i < tempLegendArr.length; i++) {
            for (let j = 0; j < this._seriesData.length; j++) {
                if (this._seriesData[j].id == tempLegendArr[i].mapSeriesId) {
                    this._seriesData[j].color = tempLegendArr[i].color;
                    break;
                }
            }
        }
    }
    _getLegendByType() {
        // check type of dimensions whether is single or multiple
        if (!this.config.skipMassage) {
            this._singleLevelDimension = false;
            if (this.config.colorAxis != undefined) {
                if (this.config.colorAxis.dataClasses && this.config.colorAxis.dataClasses.length !== 0) {
                    this._singleLevelDimension = true;
                    this.legend = this._chartSvc.setSingleLegendLevels(this.config.colorAxis.dataClasses, this.config.legend.valueDecimals, this.config.legend.valueSuffix, this.legend);
                    this.outputLegend.emit(this.legend);
                }
                else {
                    this.outputLegend.emit({});
                }
            }
            else {
                // multi dimension legend
                this.legend = this._chartSvc.setMapLegendData(this.legend, this._seriesData, this.config);
                this.outputLegend.emit(this.legend);
            }
        }
        else {
            // output legend only for exporting
            this._singleLevelDimension = false;
            if (this.config.colorAxis != undefined) {
                if (this.config.colorAxis.dataClasses && this.config.colorAxis.dataClasses.length !== 0) {
                    this._singleLevelDimension = true;
                    this.outputLegend.emit(this.legend);
                }
                else {
                    this.outputLegend.emit({});
                }
            }
            else {
                this.outputLegend.emit(this.legend);
            }
        }
    }
    _setMapScaleTriangle(_value) {
        let sign = this.isRtl ? -1 : 1;
        this._mapSvc.translateMapScaleTriangle(sign * this._mapSvc.valueScale(_value));
    }
    _removeMapScaleTriangle() {
        let triangleInitPoistion = this.isRtl ? 999 : -999;
        this._mapSvc.translateMapScaleTriangle(triangleInitPoistion);
    }
    _checkEmptyDataValue(_value) {
        if (this._seriesPointer.data == undefined) {
            return false;
        }
        else {
            let dataValue = this._getSeriesValue(_value).value;
            if (dataValue == undefined)
                return false;
            else if (dataValue != null && dataValue != '')
                return true;
            else
                return false;
        }
    }
    /**
     * drawing color scale of map
     */
    _drawMapScale() {
        // max and min colors
        let colorRange = [this.config.colorAxis.minColor, this.config.colorAxis.maxColor];
        // the actual length of bar in px. currently hardset to 200;
        let lengthRange = [0, 200];
        // array of tick intervals
        let tickArr = this._mapSvc.getLegendIntervals(this.config.colorAxis.min, this.config.colorAxis.max);
        let noOfInterval = tickArr.length - 1;
        let scaleDomain = [tickArr[0], tickArr[noOfInterval]];
        let arr = d3.range(noOfInterval);
        let linearGradientDirection = this.isRtl ? 'to left' : 'to right';
        // color scale according to tickArr, can be used to color the map. to use just call colorScale(value)
        this._mapScaleColorScale = this._mapSvc.setScale(scaleDomain, colorRange);
        // value scale according to tickArr, used to position triangle when hovered, save the valueScale in map service class
        this._mapSvc.valueScale = this._mapSvc.setScale(scaleDomain, lengthRange);
        let mapScaleWrapper = d3.select('#' + this.config.id + '.kdx-charts .kdx-map-scale-wrapper');
        let mapScale = mapScaleWrapper.select('#mapScale');
        mapScale.style('background', 'linear-gradient(' + linearGradientDirection + ',' + colorRange[0] + ',' + colorRange[1] + ')');
        this._mapSvc.mapScaleTriangle = mapScaleWrapper.select('.kdx-map-scale-triangle');
        mapScale.selectAll('.kdx-map-scale-rect')
            .data(arr)
            .enter().append('div')
            .attr('class', 'kdx-map-scale-rect')
            .attr('id', (d) => 'rect-' + d)
            .style('width', 100 / noOfInterval + '%');
        mapScaleWrapper.select('.kdx-map-scale-text-container')
            .selectAll('.kdx-map-scale-text')
            .data(tickArr)
            .enter().append('div')
            .attr('class', 'kdx-map-scale-text')
            .attr('id', (d) => 'text-' + d)
            .html(d => d);
    }
    _setMarkers() {
        if (this.chartType[1] === 'cluster')
            this.outputLegend.emit({});
        let clusterType = this.config.plotOptions.map.clusterType ? this.config.plotOptions.map.clusterType : 'cluster';
        this._clusterData = this._mapSvc.populateMarkers(this.data.pointData, this._leafletMap, clusterType);
        this.outputMarker.emit(this._clusterData.markersLegend);
        // this._isMarkerLoaded = true;
        // }
    }
    _setLayer() {
        if (this._layer)
            this._layer.remove();
        if (this.mapConfig.plotOptions.map.zoom)
            this._checkZoomConfig(this.mapConfig.plotOptions.map.zoom);
        this._layer = L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
            attribution: '&copy; <a href="http://www.openstreetmap.org/copyright">OpenStreetMap</a>',
            maxZoom: 18,
        }).addTo(this._leafletMap);
        this._attachTileListener();
    }
    _checkZoomConfig(_config) {
        if (typeof this._leafletMap !== 'undefined') {
            _config.isZoomButton ? this._leafletMap.addControl(this._leafletMap.zoomControl) : this._leafletMap.removeControl(this._leafletMap.zoomControl);
            _config.isScrollZoom ? this._leafletMap.scrollWheelZoom.enable() : this._leafletMap.scrollWheelZoom.disable();
            _config.isTouchZoom ? this._leafletMap.touchZoom.enable() : this._leafletMap.touchZoom.disable();
            _config.isDoubleClickZoom ? this._leafletMap.doubleClickZoom.enable() : this._leafletMap.doubleClickZoom.disable();
        }
    }
    _removeDefaultAttribution(_attribution) {
        let attributionElement = document.querySelector('.leaflet-control-attribution');
        if (attributionElement !== null) {
            let newAttributionElement = this._domSvc.createElement(attributionElement, 'custom-attribution');
            newAttributionElement.innerText = _attribution || 'OpenEMIS';
            attributionElement.replaceChild(newAttributionElement, attributionElement.firstChild);
        }
    }
    _attachTileListener() {
        /* Checks every tile. Only called when some tile load has failed. */
        this._layer.on('tileerror', (error) => {
            // only execute the following for the first tile error
            if (!this._isLayerError) {
                this._isLayerError = true;
                this._layerReloadTimes++;
                if (this._layerReloadTimes < 1 || this._layerReloadTimes === 1) {
                    this._setLayer();
                }
                if (this._layerReloadTimes > 5) {
                    // this.isMapShown = false;
                    // this.errorMessage = 'Max retry reached. Map cannot be loaded now. Please check your internet connection or try again later.';
                }
            }
        });
        /* Checks every tile. Only called when each tile load is successful. */
        this._layer.on('tileload', () => {
            this._tileloadIndex++;
            if (this._tileloadIndex === Object.keys(this._layer._tiles).length) {
                // only stop progress loader when last tile loaded successfully
                // this.isLayerLoading = false;
                // this._isTilesLoaded = true;
                this.outputReady.emit(false);
                // reset counters
                // this._layerReloadTimes = 0;
                this._tileloadIndex = 0;
            }
        });
    }
    _checkMapSelected(_areaId) {
        return this._isMapSelected.hasOwnProperty(_areaId);
    }
}
KdMapChart.decorators = [
    { type: Component, args: [{
                selector: 'kd-map-chart',
                template: `
        <div>
        </div>
    `,
                encapsulation: ViewEncapsulation.None,
                providers: [KdChartsSvc, KdDomElemSvc, KdMapChartSvc],
                host: {
                    'class': 'kdx-map-chart',
                }
            },] }
];
KdMapChart.ctorParameters = () => [
    { type: ElementRef },
    { type: KdChartsSvc },
    { type: KdDomElemSvc },
    { type: KdMapChartSvc }
];
KdMapChart.propDecorators = {
    data: [{ type: Input }],
    mapConfig: [{ type: Input, args: ['config',] }],
    legend: [{ type: Input }],
    api: [{ type: Input }],
    outputLegend: [{ type: Output }],
    outputData: [{ type: Output }],
    outputMarker: [{ type: Output }],
    outputReady: [{ type: Output }]
};
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoia2QtYW5ndWxhci1tYXAtY2hhcnQuanMiLCJzb3VyY2VSb290IjoiQzoveGFtcHAvaHRkb2NzL1N0eWxlZ3VpZGUvaW9zdGctb3BlbmVtaXMtc3R5bGVndWlkZS9wcm9qZWN0cy9vcGVuZW1pcy1zdHlsZWd1aWRlLWxpYi9zcmMvIiwic291cmNlcyI6WyJrZC1jb21wb25lbnRzL2tkLWFuZ3VsYXItY2hhcnRzL2tkLWFuZ3VsYXItbWFwLWNoYXJ0L2tkLWFuZ3VsYXItbWFwLWNoYXJ0LnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBLE9BQU8sRUFDSCxTQUFTLEVBQ1QsaUJBQWlCLEVBQ2pCLEtBQUssRUFDTCxNQUFNLEVBQ04sWUFBWSxFQUtaLFVBQVUsRUFFYixNQUFNLGVBQWUsQ0FBQztBQUN2QixPQUFPLEVBQUUsZ0JBQWdCLEVBQUUsTUFBTSxnQ0FBZ0MsQ0FBQztBQUNsRSxPQUFPLEVBQUUsV0FBVyxFQUFFLE1BQU0sMEJBQTBCLENBQUM7QUFDdkQsT0FBTyxFQUFFLFlBQVksRUFBRSxNQUFNLHVCQUF1QixDQUFDO0FBQ3JELE9BQU8sRUFBRSxhQUFhLEVBQUUsTUFBTSw0QkFBNEIsQ0FBQztBQUUzRCxPQUFPLEtBQUssRUFBRSxNQUFNLElBQUksQ0FBQztBQUN6QixPQUFPLEtBQUssQ0FBQyxNQUFNLFNBQVMsQ0FBQztBQUM3QixPQUFPLHVCQUF1QixDQUFDO0FBQy9CLE9BQU8sc0RBQXNELENBQUM7QUFnQjlELE1BQU0sT0FBTyxVQUFXLFNBQVEsZ0JBQWdCO0lBb0M1QyxZQUNZLFdBQXVCLEVBQ3hCLFNBQXNCLEVBQ3RCLE9BQXFCLEVBQ3BCLE9BQXNCO1FBRTlCLEtBQUssQ0FBQyxTQUFTLEVBQUUsT0FBTyxDQUFDLENBQUM7UUFMbEIsZ0JBQVcsR0FBWCxXQUFXLENBQVk7UUFDeEIsY0FBUyxHQUFULFNBQVMsQ0FBYTtRQUN0QixZQUFPLEdBQVAsT0FBTyxDQUFjO1FBQ3BCLFlBQU8sR0FBUCxPQUFPLENBQWU7UUF2QjFCLHNCQUFpQixHQUE2RCxFQUFFLENBQUM7UUFDakYsZ0JBQVcsR0FBZSxFQUFFLENBQUM7UUFDN0IsaUJBQVksR0FBWSxLQUFLLENBQUM7UUFDOUIsMEJBQXFCLEdBQVksS0FBSyxDQUFDO1FBQ3ZDLG1CQUFjLEdBQVcsQ0FBQyxDQUFDO1FBQzNCLGtCQUFhLEdBQVksS0FBSyxDQUFDO1FBQy9CLHNCQUFpQixHQUFXLENBQUMsQ0FBQztRQUM5QixtQkFBYyxHQUFRLEVBQUUsQ0FBQztRQU92QixpQkFBWSxHQUFpRCxJQUFJLFlBQVksQ0FBQyxJQUFJLENBQUMsQ0FBQztRQUNwRixlQUFVLEdBQXNCLElBQUksWUFBWSxDQUFDLElBQUksQ0FBQyxDQUFDO1FBQ3ZELGlCQUFZLEdBQXNCLElBQUksWUFBWSxDQUFDLElBQUksQ0FBQyxDQUFDO1FBQ3pELGdCQUFXLEdBQXNCLElBQUksWUFBWSxDQUFDLElBQUksQ0FBQyxDQUFDO0lBU2xFLENBQUM7SUFFRCxRQUFRO1FBQ0osSUFBSSxDQUFDLE1BQU0sR0FBRyxNQUFNLENBQUMsTUFBTSxDQUFDLEVBQUUsRUFBRSxJQUFJLENBQUMsU0FBUyxDQUFDLENBQUM7UUFDaEQsSUFBSSxDQUFDLFVBQVUsR0FBRyxNQUFNLENBQUMsTUFBTSxDQUFDLEVBQUUsRUFBRSxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUM7UUFDakQsSUFBSSxDQUFDLFFBQVEsRUFBRSxDQUFDO1FBQ2hCLEtBQUssQ0FBQyxZQUFZLENBQUMsR0FBRyxFQUFFLENBQUMsSUFBSSxDQUFDLFNBQVMsRUFBRSxDQUFDLENBQUM7UUFDM0MsSUFBSSxDQUFDLEdBQUcsQ0FBQyxNQUFNLEdBQUcsR0FBRyxFQUFFO1lBQ25CLFVBQVUsQ0FBQyxHQUFHLEVBQUU7Z0JBQ1osSUFBSSxDQUFDLGdCQUFnQixFQUFFLENBQUM7Z0JBQ3hCLElBQUksQ0FBQyxXQUFXLEVBQUUsQ0FBQztnQkFDbkIsSUFBSSxDQUFDLFNBQVMsRUFBRSxDQUFDO2dCQUNqQixrQ0FBa0M7Z0JBQ2xDLGlHQUFpRztnQkFDakcsSUFBSTtnQkFDSixJQUFJLENBQUMsZ0JBQWdCLEVBQUUsQ0FBQztZQUM1QixDQUFDLENBQUMsQ0FBQztRQUNQLENBQUMsQ0FBQztRQUNGLElBQUksQ0FBQyxHQUFHLENBQUMsV0FBVyxHQUFHLENBQUMsR0FBUSxFQUFFLGFBQWEsRUFBRSxFQUFFO1lBQy9DLElBQUksQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLENBQUMsUUFBUSxHQUFHLGFBQWEsQ0FBQztZQUMxQyxLQUFLLElBQUksQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLEdBQUcsSUFBSSxDQUFDLFdBQVcsQ0FBQyxNQUFNLEVBQUUsQ0FBQyxFQUFFLEVBQUU7Z0JBQzlDLElBQUksSUFBSSxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLElBQUksSUFBSSxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLElBQUksSUFBSSxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsQ0FBQyxXQUFXLEVBQUU7b0JBQ2xGLElBQUksQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxHQUFHLGFBQWEsQ0FBQztpQkFDaEQ7YUFDSjtZQUNELElBQUksQ0FBQyxJQUFJLENBQUMsZUFBZSxDQUFDLEdBQUcsSUFBSSxDQUFDLFdBQVcsQ0FBQztZQUM5QyxJQUFJLElBQUksQ0FBQyxxQkFBcUIsSUFBSSxLQUFLO2dCQUFFLElBQUksQ0FBQyxhQUFhLEVBQUUsQ0FBQztZQUM5RCxJQUFJLENBQUMsV0FBVyxFQUFFLENBQUM7WUFDbkIsSUFBSSxDQUFDLFNBQVMsRUFBRSxDQUFDO1FBQ3JCLENBQUMsQ0FBQztRQUNGLElBQUksQ0FBQyxHQUFHLENBQUMsWUFBWSxHQUFHLENBQUMsR0FBUSxFQUFFLFdBQWdGLEVBQUUsRUFBRTtZQUNuSCxJQUFJLG1CQUFvRCxDQUFDO1lBQ3pELG1CQUFtQixHQUFHLElBQUksQ0FBQyxZQUFZLENBQUMsY0FBYyxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsQ0FBQztZQUUvRCxJQUFJLElBQUksQ0FBQyxXQUFXLENBQUMsUUFBUSxDQUFDLG1CQUFtQixDQUFDLEVBQUU7Z0JBQ2hELElBQUksQ0FBQyxXQUFXLENBQUMsV0FBVyxDQUFDLG1CQUFtQixDQUFDLENBQUM7Z0JBQ2xELElBQUksQ0FBQyxPQUFPLENBQUMsUUFBUSxDQUFDLFdBQVcsQ0FBQyxnQkFBZ0IsRUFBRSwrQkFBK0IsQ0FBQyxDQUFDO2dCQUNyRixJQUFJLENBQUMsT0FBTyxDQUFDLFFBQVEsQ0FBQyxXQUFXLENBQUMsZUFBZSxFQUFFLHFCQUFxQixDQUFDLENBQUM7YUFDN0U7aUJBQ0k7Z0JBQ0QsSUFBSSxDQUFDLFdBQVcsQ0FBQyxRQUFRLENBQUMsbUJBQW1CLENBQUMsQ0FBQztnQkFDL0MsSUFBSSxDQUFDLE9BQU8sQ0FBQyxXQUFXLENBQUMsV0FBVyxDQUFDLGdCQUFnQixFQUFFLCtCQUErQixDQUFDLENBQUM7Z0JBQ3hGLElBQUksQ0FBQyxPQUFPLENBQUMsV0FBVyxDQUFDLFdBQVcsQ0FBQyxlQUFlLEVBQUUscUJBQXFCLENBQUMsQ0FBQzthQUNoRjtRQUNMLENBQUMsQ0FBQTtJQUNMLENBQUM7SUFFRCxXQUFXLENBQUMsY0FBNkI7UUFDckMsSUFBSSxjQUFjLENBQUMsY0FBYyxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsY0FBYyxDQUFDLE1BQU0sQ0FBQyxDQUFDLFdBQVcsRUFBRTtZQUM5RSxJQUFJLENBQUMsSUFBSSxHQUFHLGNBQWMsQ0FBQyxJQUFJLENBQUMsWUFBWSxDQUFDO1lBQzdDLElBQUksQ0FBQyxZQUFZLENBQUMsTUFBTSxDQUFDLENBQUM7U0FDN0I7UUFDRCxJQUFJLGNBQWMsQ0FBQyxjQUFjLENBQUMsV0FBVyxDQUFDLElBQUksQ0FBQyxjQUFjLENBQUMsV0FBVyxDQUFDLENBQUMsV0FBVyxFQUFFO1lBQ3hGLElBQUksSUFBSSxDQUFDLFNBQVMsQ0FBQyxXQUFXLENBQUMsR0FBRyxDQUFDLElBQUksRUFBRTtnQkFDckMsSUFBSSxDQUFDLGdCQUFnQixDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsV0FBVyxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsQ0FBQztnQkFDM0QsSUFBSSxJQUFJLENBQUMsU0FBUyxDQUFDLFdBQVcsQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLEtBQUssRUFBRTtvQkFDM0MsSUFBSSxPQUFPLElBQUksQ0FBQyxXQUFXLEtBQUssV0FBVzt3QkFBRSxJQUFJLENBQUMsV0FBVyxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLFdBQVcsQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFDO2lCQUNwSDtnQkFDRCxxQ0FBcUM7Z0JBQ3JDLDJGQUEyRjthQUM5RjtZQUNELElBQUksQ0FBQyxTQUFTLEdBQUcsY0FBYyxDQUFDLFNBQVMsQ0FBQyxZQUFZLENBQUM7WUFDdkQsSUFBSSxDQUFDLFlBQVksQ0FBQyxRQUFRLENBQUMsQ0FBQztTQUMvQjtJQUNMLENBQUM7SUFFRCxlQUFlO1FBQ1gsSUFBSSxPQUFPLElBQUksQ0FBQyxXQUFXLEtBQUssV0FBVztZQUFFLElBQUksQ0FBQyxXQUFXLENBQUMsY0FBYyxDQUFDLEVBQUUsQ0FBQyxDQUFDO0lBQ3JGLENBQUM7SUFFRCxXQUFXO1FBQ1AsSUFBSSxDQUFDLFdBQVcsRUFBRSxDQUFDO0lBQ3ZCLENBQUM7SUFFTyxZQUFZLENBQUMsUUFBNEI7UUFDN0MsSUFBSSxDQUFDLFdBQVcsRUFBRSxDQUFDO1FBRW5CLElBQUksUUFBUSxLQUFLLE1BQU0sRUFBRTtZQUNyQixJQUFJLENBQUMsV0FBVyxHQUFHLEVBQUUsQ0FBQztTQUN6QjthQUFNO1lBQ0gsSUFBSSxDQUFDLE1BQU0sR0FBRyxNQUFNLENBQUMsTUFBTSxDQUFDLEVBQUUsRUFBRSxJQUFJLENBQUMsU0FBUyxDQUFDLENBQUM7U0FDbkQ7UUFDRCxJQUFJLENBQUMsVUFBVSxHQUFHLE1BQU0sQ0FBQyxNQUFNLENBQUMsRUFBRSxFQUFFLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQztRQUVqRCxJQUFJLENBQUMsUUFBUSxFQUFFLENBQUM7UUFDaEIsS0FBSyxDQUFDLFlBQVksQ0FBQyxHQUFHLEVBQUUsQ0FBQyxJQUFJLENBQUMsU0FBUyxFQUFFLENBQUMsQ0FBQztJQUMvQyxDQUFDO0lBRU8sU0FBUztRQUNiLElBQUksQ0FBQyxTQUFTLEdBQUcsSUFBSSxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FBQztRQUNuRCxJQUFJLElBQUksQ0FBQyxNQUFNLEtBQUssU0FBUyxJQUFJLElBQUksQ0FBQyxNQUFNLEtBQUssSUFBSSxFQUFFO1NBQ3REO2FBQU0sSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLElBQUksSUFBSSxDQUFDLE1BQU0sQ0FBQyxXQUFXLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLElBQUksSUFBSSxDQUFDLHFCQUFxQixJQUFJLElBQUksQ0FBQyxFQUFFO1lBQzVILDZIQUE2SDtZQUM3SCxJQUFJLFdBQVcsR0FBa0IsTUFBTSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxDQUFDO1lBQ2hFLElBQUksQ0FBQyxhQUFhLEdBQUcsV0FBVyxDQUFDLE1BQU0sR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsQ0FBQztZQUNyRixJQUFJLENBQUMsTUFBTSxHQUFHLElBQUksQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLENBQUM7WUFDcEMsa0NBQWtDO1NBQ3JDO2FBQU0sSUFBSSxJQUFJLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxNQUFNLEdBQUcsQ0FBQyxDQUFDLENBQUMsSUFBSSxJQUFJLElBQUksQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLE1BQU0sR0FBRyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsTUFBTSxJQUFJLENBQUMsRUFBRTtZQUM3SCxJQUFJLENBQUMsYUFBYSxHQUFHLElBQUksQ0FBQyxPQUFPLENBQUMseUJBQXlCLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsTUFBTSxHQUFHLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLEVBQUUsSUFBSSxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsQ0FBQztZQUMxSSxJQUFJLENBQUMsTUFBTSxHQUFHLElBQUksQ0FBQyxhQUFhLENBQUM7U0FDcEM7YUFBTTtZQUNILElBQUksV0FBVyxHQUFrQixNQUFNLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLENBQUM7WUFDaEUsSUFBSSxDQUFDLGFBQWEsR0FBRyxXQUFXLENBQUMsTUFBTSxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUM7WUFDckUsSUFBSSxDQUFDLE1BQU0sR0FBRyxJQUFJLENBQUMsYUFBYSxDQUFDO1NBQ3BDO1FBQ0QsSUFBSSxDQUFDLGdCQUFnQixFQUFFLENBQUM7UUFFeEIsK0ZBQStGO1FBQy9GLElBQUksSUFBSSxDQUFDLE1BQU0sQ0FBQyxTQUFTLElBQUksU0FBUyxJQUFJLElBQUksQ0FBQyxNQUFNLENBQUMsU0FBUyxDQUFDLFdBQVcsSUFBSSxTQUFTLEVBQUU7WUFDdEYsSUFBSSxDQUFDLGFBQWEsRUFBRSxDQUFDO1NBQ3hCO1FBQ0QsS0FBSyxDQUFDLE1BQU0sRUFBRSxDQUFDO1FBQ2YsS0FBSyxDQUFDLGVBQWUsQ0FBQyxHQUFHLENBQUMsQ0FBQztRQUMzQixLQUFLLENBQUMsZUFBZSxDQUFDLEdBQUcsQ0FBQyxDQUFDO1FBRTNCLElBQUksQ0FBQyxPQUFPLEdBQUcsSUFBSSxDQUFDLFlBQVksQ0FBQyxJQUFJLEVBQUUsQ0FBQyxxQkFBcUIsRUFBRSxDQUFDLE1BQU0sQ0FBQztRQUN2RSxJQUFJLENBQUMsTUFBTSxHQUFHLElBQUksQ0FBQyxZQUFZLENBQUMsSUFBSSxFQUFFLENBQUMscUJBQXFCLEVBQUUsQ0FBQyxLQUFLLENBQUM7UUFFckUsSUFBSSxJQUFJLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxLQUFLLFNBQVMsSUFBSSxJQUFJLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxLQUFLLFVBQVUsRUFBRTtZQUNyRSxJQUFJLENBQUMsZUFBZSxFQUFFLENBQUM7U0FDMUI7YUFBTSxJQUFJLElBQUksQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLEtBQUssTUFBTSxJQUFJLElBQUksQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLEtBQUssU0FBUyxJQUFJLElBQUksQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLEtBQUssUUFBUSxFQUFFO1lBQzFHLElBQUksQ0FBQyxhQUFhLEVBQUUsQ0FBQztZQUNyQixVQUFVLENBQUMsR0FBRyxFQUFFO2dCQUNaLElBQUksT0FBTyxJQUFJLENBQUMsV0FBVyxLQUFLLFdBQVc7b0JBQUUsSUFBSSxDQUFDLFdBQVcsQ0FBQyxjQUFjLENBQUMsRUFBRSxDQUFDLENBQUM7WUFDckYsQ0FBQyxDQUFDLENBQUE7WUFDRixJQUFJLElBQUksQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLEtBQUssU0FBUztnQkFBRSxJQUFJLENBQUMsWUFBWSxFQUFFLENBQUM7U0FDNUQ7UUFDRCxrQ0FBa0M7UUFDbEMsc0NBQXNDO0lBQzFDLENBQUM7SUFFTyxRQUFRO1FBQ1osSUFBSSxDQUFDLGFBQWEsR0FBRyxLQUFLLENBQUM7UUFDM0IsSUFBSSxJQUFJLENBQUMsSUFBSSxDQUFDLGVBQWUsQ0FBQyxJQUFJLElBQUksQ0FBQyxNQUFNLENBQUMsV0FBVyxFQUFFO1lBQ3ZELGNBQWM7WUFDZCxJQUFJLENBQUMsV0FBVyxHQUFHLElBQUksQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLGVBQWUsQ0FBQyxDQUFDLENBQUMsQ0FBQztZQUMxRSxJQUFJLElBQUksQ0FBQyxNQUFNLENBQUMsU0FBUyxJQUFJLFNBQVMsRUFBRTtnQkFDcEMsbUJBQW1CO2dCQUNuQixJQUFJLENBQUMsY0FBYyxHQUFHLElBQUksQ0FBQyxPQUFPLENBQUMsZ0JBQWdCLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxDQUFDO2FBQ3pFO2lCQUNJO2dCQUNELElBQUksQ0FBQyxhQUFhLEVBQUUsQ0FBQzthQUN4QjtTQUNKO2FBQU07WUFDSCxJQUFJLENBQUMsV0FBVyxHQUFHLElBQUksQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUM7WUFDaEUsS0FBSyxJQUFJLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxHQUFHLElBQUksQ0FBQyxXQUFXLENBQUMsTUFBTSxFQUFFLENBQUMsRUFBRSxFQUFFO2dCQUM5QyxJQUFJLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQyxDQUFDLFVBQVUsQ0FBQyxHQUFHLEtBQUssQ0FBQzthQUMzQztZQUNELElBQUksSUFBSSxDQUFDLE1BQU0sQ0FBQyxTQUFTLElBQUksU0FBUyxFQUFFO2dCQUNwQyxtQkFBbUI7Z0JBQ25CLElBQUksQ0FBQyxjQUFjLEdBQUcsSUFBSSxDQUFDLE9BQU8sQ0FBQyxnQkFBZ0IsQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFDLENBQUM7YUFDekU7aUJBQU07Z0JBQ0gsa0JBQWtCO2dCQUNsQixJQUFJLElBQUksQ0FBQyxXQUFXLElBQUksSUFBSSxDQUFDLFdBQVcsQ0FBQyxNQUFNLElBQUksQ0FBQyxFQUFFO29CQUNsRCxJQUFJLENBQUMsY0FBYyxHQUFHLElBQUksQ0FBQyxXQUFXLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxNQUFNLEdBQUcsQ0FBQyxDQUFDLENBQUM7aUJBQ3ZFO2FBQ0o7WUFDRCxJQUFJLENBQUMsWUFBWSxHQUFHLElBQUksQ0FBQyxjQUFjLElBQUksU0FBUyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQztTQUN2RTtRQUVELGtDQUFrQztRQUNsQyxpR0FBaUc7UUFDakcsSUFBSTtRQUNKLElBQUksQ0FBQyxnQkFBZ0IsRUFBRSxDQUFDO1FBQ3hCLElBQUksQ0FBQyxnQkFBZ0IsRUFBRSxDQUFDO0lBQzVCLENBQUM7SUFFTyxXQUFXO1FBQ2YsSUFBSSxPQUFPLElBQUksQ0FBQyxTQUFTLEtBQUssV0FBVyxFQUFFO1lBQ3ZDLElBQUksQ0FBQyxTQUFTLENBQUMsTUFBTSxFQUFFLENBQUM7WUFDeEIsSUFBSSxDQUFDLFNBQVMsR0FBRyxTQUFTLENBQUM7U0FDOUI7UUFDRCxJQUFJLElBQUksQ0FBQyxXQUFXLEtBQUssU0FBUyxJQUFJLElBQUksQ0FBQyxXQUFXLEtBQUssSUFBSSxJQUFJLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxXQUFXLEVBQUU7WUFDekYsSUFBSSxDQUFDLFdBQVcsQ0FBQyxNQUFNLEVBQUUsQ0FBQztZQUMxQixJQUFJLENBQUMsV0FBVyxHQUFHLFNBQVMsQ0FBQztZQUM3QixJQUFJLFVBQVUsR0FBRyxHQUFHLEdBQUcsSUFBSSxDQUFDLE1BQU0sQ0FBQyxFQUFFLEdBQUcsU0FBUyxDQUFDO1lBQ2xELFFBQVEsQ0FBQyxhQUFhLENBQUMsVUFBVSxDQUFDLENBQUMsWUFBWSxDQUFDLE9BQU8sRUFBRSwwQkFBMEIsQ0FBQyxDQUFDO1NBQ3hGO1FBQ0QsSUFBSSxPQUFPLElBQUksQ0FBQyxTQUFTLEtBQUssV0FBVyxFQUFFO1lBQ3ZDLElBQUksQ0FBQyxTQUFTLENBQUMsTUFBTSxFQUFFLENBQUM7WUFDeEIsSUFBSSxDQUFDLFNBQVMsR0FBRyxTQUFTLENBQUM7U0FFOUI7UUFDRCxJQUFJLE9BQU8sSUFBSSxDQUFDLFVBQVUsS0FBSyxXQUFXLEVBQUU7WUFDeEMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxNQUFNLEVBQUUsQ0FBQztZQUN6QixJQUFJLENBQUMsVUFBVSxHQUFHLFNBQVMsQ0FBQztTQUMvQjtRQUNELElBQUksT0FBTyxJQUFJLENBQUMsUUFBUSxLQUFLLFdBQVcsRUFBRTtZQUN0QyxJQUFJLENBQUMsUUFBUSxDQUFDLE1BQU0sRUFBRSxDQUFDO1lBQ3ZCLElBQUksQ0FBQyxRQUFRLEdBQUcsU0FBUyxDQUFDO1NBQzdCO1FBQ0QsSUFBSSxDQUFDLE1BQU0sR0FBRyxTQUFTLENBQUM7UUFDeEIsSUFBSSxDQUFDLGlCQUFpQixHQUFHLEVBQUUsQ0FBQztRQUM1QixJQUFJLENBQUMsY0FBYyxHQUFHLEVBQUUsQ0FBQztRQUN6QixLQUFLLENBQUMsV0FBVyxFQUFFLENBQUM7SUFDeEIsQ0FBQztJQUVPLGFBQWE7UUFDakIsSUFBSSxJQUFJLENBQUMsV0FBVyxLQUFLLFNBQVMsSUFBSSxJQUFJLENBQUMsV0FBVyxLQUFLLElBQUk7WUFBRSxJQUFJLENBQUMsV0FBVyxDQUFDLE1BQU0sRUFBRSxDQUFDO1FBQzNGLElBQUksU0FBUyxHQUFXLENBQUMsQ0FBQztRQUMxQixJQUFJLElBQUksQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLEtBQUssUUFBUSxJQUFJLElBQUksQ0FBQyxJQUFJLENBQUMsUUFBUSxJQUFJLElBQUksQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLElBQUksRUFBRTtZQUNqRixTQUFTLEdBQUcsSUFBSSxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDO1NBQ3ZDO2FBQU0sSUFBSSxJQUFJLENBQUMsTUFBTSxDQUFDLFdBQVcsQ0FBQyxHQUFHLENBQUMsSUFBSSxJQUFJLElBQUksQ0FBQyxNQUFNLENBQUMsV0FBVyxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsS0FBSyxFQUFFO1lBQ25GLFNBQVMsR0FBRyxJQUFJLENBQUMsTUFBTSxDQUFDLFdBQVcsQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQztTQUN0RDtRQUNELElBQUksVUFBVSxHQUFHLElBQUksQ0FBQyxNQUFNLENBQUMsRUFBRSxHQUFHLFNBQVMsQ0FBQztRQUM1QyxJQUFJLENBQUMsV0FBVyxHQUFHLENBQUMsQ0FBQyxHQUFHLENBQUMsVUFBVSxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsUUFBUSxFQUFFLElBQUksQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLFNBQVMsQ0FBQyxFQUFFLFNBQVMsQ0FBQyxDQUFDO1FBQ3JILElBQUksQ0FBQyxTQUFTLEVBQUUsQ0FBQztRQUNqQixJQUFJLENBQUMseUJBQXlCLENBQUMsVUFBVSxDQUFDLENBQUM7UUFDM0MsSUFBSSxJQUFJLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxLQUFLLE1BQU0sSUFBSSxJQUFJLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxLQUFLLFNBQVM7WUFBRSxJQUFJLENBQUMsV0FBVyxFQUFFLENBQUM7SUFDNUYsQ0FBQztJQUVPLFlBQVk7UUFDaEIsSUFBSSxDQUFDLGlCQUFpQixHQUFHLEVBQUUsQ0FBQztRQUM1QixJQUFJLE9BQU8sSUFBSSxDQUFDLFVBQVUsS0FBSyxXQUFXO1lBQUUsSUFBSSxDQUFDLFVBQVUsR0FBRyxFQUFFLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxXQUFXLENBQUMsUUFBUSxFQUFFLENBQUMsV0FBVyxDQUFDLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxDQUFDO1FBQy9ILHNGQUFzRjtRQUV0RixJQUFJLENBQUMsU0FBUyxHQUFHLElBQUksQ0FBQyxVQUFVLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQyxPQUFPLEVBQUUsbUJBQW1CLENBQUMsQ0FBQztRQUNoRixJQUFJLEdBQUcsR0FBRyxJQUFJLENBQUMsV0FBVyxDQUFDO1FBQzNCLElBQUksR0FBRyxHQUFHLElBQUksQ0FBQyxVQUFVLENBQUM7UUFDMUIsSUFBSSxjQUFjLEdBQUcsSUFBSSxDQUFDLE1BQU0sQ0FBQyxFQUFFLENBQUM7UUFDcEMsSUFBSSxRQUFRLEdBQUcsSUFBSSxDQUFDLFNBQVMsQ0FBQztRQUM5QixJQUFJLEtBQUssR0FBRyxJQUFJLENBQUMsTUFBTSxDQUFDO1FBQ3hCLElBQUksTUFBTSxHQUFHLElBQUksQ0FBQyxPQUFPLENBQUM7UUFDMUIsSUFBSSxTQUFTLEdBQUcsRUFBRSxDQUFDLFlBQVksQ0FBQztZQUM1QixLQUFLLEVBQUUsVUFBUyxDQUFDLEVBQUUsQ0FBQztnQkFDaEIsSUFBSSxLQUFLLEdBQUcsR0FBRyxDQUFDLGtCQUFrQixDQUFDLElBQUksQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQztnQkFDdkQsSUFBSSxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLENBQUMsRUFBRSxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUM7WUFDeEMsQ0FBQztTQUNKLENBQUMsRUFDRSxJQUFJLEdBQUcsRUFBRSxDQUFDLE9BQU8sRUFBRSxDQUFDLFVBQVUsQ0FBQyxTQUFTLENBQUMsQ0FBQztRQUM5QyxJQUFJLFFBQVEsRUFBRSxjQUFtQixDQUFDO1FBQ2xDLElBQUksSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsS0FBSyxRQUFRLElBQUksSUFBSSxDQUFDLElBQUksQ0FBQyxjQUFjLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLEtBQUssS0FBSyxTQUFTLElBQUksSUFBSSxDQUFDLElBQUksQ0FBQyxLQUFLLEtBQUssSUFBSSxDQUFDLEVBQUU7WUFDcEksUUFBUSxHQUFHLE1BQU0sQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztZQUMzQyxjQUFjLEdBQUcsSUFBSSxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsUUFBUSxDQUFDLENBQUM7U0FDOUM7UUFDRCxzRUFBc0U7UUFDdEUsc0RBQXNEO1FBQ3RELElBQUksSUFBSSxDQUFDLE1BQU0sQ0FBQyxXQUFXLENBQUMsR0FBRyxDQUFDLEtBQUssSUFBSSxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsV0FBVyxDQUFDLEdBQUcsQ0FBQyxLQUFLLEtBQUssRUFBRSxJQUFJLElBQUksQ0FBQyxNQUFNLENBQUMsV0FBVyxDQUFDLEdBQUcsQ0FBQyxLQUFLLEtBQUssU0FBUyxJQUFJLElBQUksQ0FBQyxNQUFNLENBQUMsV0FBVyxDQUFDLEdBQUcsQ0FBQyxLQUFLLEtBQUssSUFBSSxDQUFDLElBQUksSUFBSSxDQUFDLE9BQU8sQ0FBQyxrQkFBa0IsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLFdBQVcsQ0FBQyxHQUFHLENBQUMsS0FBSyxFQUFFLElBQUksQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLEVBQUU7WUFDM1EsSUFBSSxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLEtBQUssTUFBTSxJQUFJLElBQUksQ0FBQyxNQUFNLENBQUMsV0FBVyxDQUFDLEdBQUcsQ0FBQyx5QkFBeUIsS0FBSyxJQUFJLENBQUMsSUFBSSxJQUFJLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxLQUFLLE1BQU0sRUFBRTtnQkFDbEksSUFBSSxDQUFDLE1BQU0sR0FBRyxJQUFJLENBQUMsTUFBTSxDQUFDLFdBQVcsQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDO2FBQ25EO2lCQUFNO2dCQUNILElBQUksQ0FBQyxhQUFhLEVBQUUsQ0FBQzthQUN4QjtTQUNKO2FBQU07WUFDSCxJQUFJLENBQUMsYUFBYSxFQUFFLENBQUM7U0FDeEI7UUFFRCxJQUFJLElBQUksR0FBRyxJQUFJLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxjQUFjLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDO1FBQzlHLElBQUksVUFBVSxHQUFHLEVBQUUsQ0FBQyxXQUFXLEVBQUUsQ0FBQyxPQUFPLENBQUMsQ0FBQyxJQUFJLENBQUMsTUFBTSxFQUFFLElBQUksQ0FBQyxPQUFPLEdBQUcsRUFBRSxDQUFDLEVBQUUsSUFBSSxDQUFDLENBQUM7UUFDbEYsa0RBQWtEO1FBQ2xELElBQUksUUFBUSxHQUFHLElBQUksQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLGNBQWMsQ0FBQyxVQUFVLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUMsUUFBUSxDQUFDO1FBRW5JLElBQUksT0FBTyxHQUFHLElBQUksQ0FBQyxTQUFTLENBQUMsU0FBUyxDQUFDLE1BQU0sQ0FBQzthQUN6QyxJQUFJLENBQUMsUUFBUSxDQUFDO2FBQ2QsS0FBSyxFQUFFLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQztZQUN2QixtQkFBbUI7YUFDbEIsSUFBSSxDQUFDLElBQUksRUFBRSxDQUFDLENBQUMsRUFBRSxFQUFFLEdBQUcsT0FBTyxJQUFJLENBQUMsT0FBTyxDQUFDLFlBQVksR0FBRyxDQUFDLENBQUMsVUFBVSxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQzthQUMzRSxJQUFJLENBQUMsT0FBTyxFQUFFLENBQUMsQ0FBQyxFQUFFLEVBQUU7WUFDakIsSUFBSSxJQUFJLENBQUMsWUFBWSxJQUFJLEtBQUssSUFBSSxJQUFJLENBQUMsY0FBYyxJQUFJLElBQUksQ0FBQyxjQUFjLENBQUMsSUFBSSxJQUFJLFNBQVMsRUFBRTtnQkFDNUYsSUFBSSxXQUFXLEdBQUcsSUFBSSxDQUFDLGVBQWUsQ0FBQyxDQUFDLENBQUMsVUFBVSxDQUFDLEdBQUcsQ0FBQyxDQUFDO2dCQUN6RCxJQUFJLENBQUMsaUJBQWlCLENBQUMsSUFBSSxDQUFDLEVBQUUsTUFBTSxFQUFFLFdBQVcsQ0FBQyxJQUFJLEVBQUUsT0FBTyxFQUFFLFdBQVcsQ0FBQyxLQUFLLEVBQUUsSUFBSSxFQUFFLENBQUMsQ0FBQyxVQUFVLENBQUMsR0FBRyxFQUFFLENBQUMsQ0FBQztnQkFDOUcsT0FBTyxLQUFLLEdBQUcsV0FBVyxDQUFDLEVBQUUsR0FBRyxTQUFTLEdBQUcsV0FBVyxDQUFDLElBQUksR0FBRyxjQUFjLEdBQUcsV0FBVyxDQUFDLFNBQVMsR0FBRyxVQUFVLEdBQUcsV0FBVyxDQUFDLEtBQUssQ0FBQzthQUMxSTtRQUNMLENBQUMsQ0FBQzthQUNELElBQUksQ0FBQyxlQUFlLEVBQUUsb0JBQW9CLENBQUM7YUFDM0MsS0FBSyxDQUFDLE1BQU0sRUFBRSxDQUFDLENBQUMsRUFBRSxFQUFFO1lBQ2pCLElBQUksSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsS0FBSyxRQUFRLElBQUksSUFBSSxDQUFDLElBQUksQ0FBQyxjQUFjLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLEtBQUssS0FBSyxTQUFTLElBQUksSUFBSSxDQUFDLElBQUksQ0FBQyxLQUFLLEtBQUssSUFBSSxDQUFDLEVBQUU7Z0JBQ3BJLElBQUksQ0FBQyxDQUFDLGNBQWMsQ0FBQyxZQUFZLENBQUMsSUFBSSxDQUFDLENBQUMsVUFBVSxDQUFDLEdBQUcsS0FBSyxjQUFjLENBQUMsRUFBRSxJQUFJLENBQUMsQ0FBQyxVQUFVLENBQUMsTUFBTSxLQUFLLGNBQWMsQ0FBQyxJQUFJLEVBQUU7b0JBQ3pILElBQUksQ0FBQyxjQUFjLEdBQUcsRUFBRSxDQUFDO29CQUN6QixJQUFJLENBQUMsY0FBYyxDQUFDLENBQUMsQ0FBQyxVQUFVLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxDQUFDLFVBQVUsQ0FBQyxHQUFHLENBQUM7b0JBQ3pELE9BQU8sSUFBSSxDQUFDLE1BQU0sQ0FBQyxXQUFXLENBQUMsR0FBRyxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDO2lCQUMxRDtxQkFBTTtvQkFDSCxPQUFPLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDLENBQUMsQ0FBQztpQkFDbkM7YUFDSjtpQkFBTTtnQkFDSCxPQUFPLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDLENBQUMsQ0FBQzthQUNuQztRQUNMLENBQUMsQ0FBQzthQUNELEtBQUssQ0FBQyxjQUFjLEVBQUUsQ0FBQyxDQUFDLEVBQUUsRUFBRTtZQUN6QixJQUFJLElBQUksQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLEtBQUssUUFBUSxJQUFJLElBQUksQ0FBQyxJQUFJLENBQUMsY0FBYyxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxLQUFLLEtBQUssU0FBUyxJQUFJLElBQUksQ0FBQyxJQUFJLENBQUMsS0FBSyxLQUFLLElBQUksQ0FBQyxFQUFFO2dCQUNwSSxJQUFJLENBQUMsQ0FBQyxjQUFjLENBQUMsWUFBWSxDQUFDLElBQUksQ0FBQyxDQUFDLFVBQVUsQ0FBQyxHQUFHLEtBQUssY0FBYyxDQUFDLEVBQUUsSUFBSSxDQUFDLENBQUMsVUFBVSxDQUFDLE1BQU0sS0FBSyxjQUFjLENBQUMsSUFBSSxFQUFFO29CQUN6SCxPQUFPLElBQUksQ0FBQyxNQUFNLENBQUMsV0FBVyxDQUFDLEdBQUcsQ0FBQyxNQUFNLENBQUMsY0FBYyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLFdBQVcsQ0FBQyxHQUFHLENBQUMsTUFBTSxDQUFDLGNBQWMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxXQUFXLENBQUMsR0FBRyxDQUFDLFdBQVcsQ0FBQztpQkFDMUo7cUJBQU07b0JBQ0gsT0FBTyxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLEtBQUssUUFBUSxJQUFJLElBQUksQ0FBQyxNQUFNLENBQUMsV0FBVyxDQUFDLEdBQUcsQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsV0FBVyxDQUFDLEdBQUcsQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLFdBQVcsQ0FBQyxHQUFHLENBQUMsV0FBVyxDQUFDO2lCQUM5SzthQUNKO2lCQUFNO2dCQUNILE9BQU8sQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxLQUFLLFFBQVEsSUFBSSxJQUFJLENBQUMsTUFBTSxDQUFDLFdBQVcsQ0FBQyxHQUFHLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLFdBQVcsQ0FBQyxHQUFHLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxXQUFXLENBQUMsR0FBRyxDQUFDLFdBQVcsQ0FBQzthQUM5SztRQUNMLENBQUMsQ0FBQzthQUNELEtBQUssQ0FBQyxRQUFRLEVBQUUsSUFBSSxDQUFDLE1BQU0sQ0FBQyxXQUFXLENBQUMsR0FBRyxDQUFDLFdBQVcsQ0FBQztZQUN6RCx3Q0FBd0M7YUFDdkMsS0FBSyxDQUFDLGdCQUFnQixFQUFFLFNBQVMsQ0FBQzthQUNsQyxLQUFLLENBQUMsU0FBUyxFQUFFLEdBQUcsQ0FBQyxDQUFDO1FBRTNCLElBQUksQ0FBQyxXQUFXLENBQUMsRUFBRSxDQUFDLFdBQVcsRUFBRSxLQUFLLENBQUMsQ0FBQztRQUN4QyxJQUFJLENBQUMsV0FBVyxDQUFDLEVBQUUsQ0FBQyxNQUFNLEVBQUUsS0FBSyxDQUFDLENBQUM7UUFFbkMsSUFBSSxRQUFRLEdBQUcsSUFBSSxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDO1FBQzlDLEtBQUssRUFBRSxDQUFDO1FBRVIsSUFBSSxRQUFRLEdBQUcsS0FBSyxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsZ0JBQWdCLENBQUMsR0FBRyxHQUFHLElBQUksQ0FBQyxNQUFNLENBQUMsRUFBRSxHQUFHLG9DQUFvQyxDQUFDLENBQUMsQ0FBQztRQUNsSCxRQUFRLENBQUMsT0FBTyxDQUFDLENBQUMsRUFBRSxFQUFFLEVBQUU7WUFDcEIsRUFBRSxDQUFDLGdCQUFnQixDQUFDLFdBQVcsRUFBRSxDQUFDLENBQUMsRUFBRSxFQUFFO2dCQUNuQyxJQUFJLGFBQWEsR0FBNkIsQ0FBQyxDQUFDLE1BQU0sQ0FBQztnQkFDdkQsSUFBSSxlQUFlLEdBQVcsSUFBSSxDQUFDLE9BQU8sQ0FBQyxrQkFBa0IsQ0FBQyxhQUFhLENBQUMsQ0FBQztnQkFDN0UsSUFBSSxnQkFBZ0IsR0FBRyxJQUFJLENBQUMsT0FBTyxDQUFDLG1CQUFtQixDQUFDLElBQUksQ0FBQyxZQUFZLEVBQUUsYUFBYSxDQUFDLFlBQVksQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDO2dCQUM3RyxJQUFJLElBQUksQ0FBQyxvQkFBb0IsQ0FBQyxlQUFlLENBQUMsRUFBRTtvQkFDNUMsSUFBSSxJQUFJLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxLQUFLLFFBQVEsSUFBSSxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLEtBQUssUUFBUSxJQUFJLENBQUMsSUFBSSxDQUFDLGlCQUFpQixDQUFDLGVBQWUsQ0FBQyxDQUFDLEVBQUU7d0JBQ2hILGdCQUFnQixDQUFDLEtBQUssQ0FBQyxNQUFNLEVBQUUsSUFBSSxDQUFDLE1BQU0sQ0FBQyxXQUFXLENBQUMsR0FBRyxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLENBQUM7cUJBQ2xGO29CQUNELElBQUksSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsS0FBSyxRQUFRLElBQUksSUFBSSxDQUFDLE1BQU0sQ0FBQyxXQUFXLENBQUMsR0FBRyxDQUFDLE1BQU0sSUFBSSxJQUFJLENBQUMsTUFBTSxDQUFDLFdBQVcsQ0FBQyxHQUFHLENBQUMsTUFBTSxDQUFDLFdBQVcsSUFBSSxDQUFDLElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxlQUFlLENBQUMsRUFBRTt3QkFDcEssZ0JBQWdCLENBQUMsS0FBSyxDQUFDLGNBQWMsRUFBRSxJQUFJLENBQUMsTUFBTSxDQUFDLFdBQVcsQ0FBQyxHQUFHLENBQUMsTUFBTSxDQUFDLFdBQVcsQ0FBQyxDQUFDO3FCQUMxRjtpQkFDSjtZQUNMLENBQUMsQ0FBQyxDQUFDO1lBQ0gsRUFBRSxDQUFDLGdCQUFnQixDQUFDLFVBQVUsRUFBRSxDQUFDLENBQUMsRUFBRSxFQUFFO2dCQUNsQyxJQUFJLGFBQWEsR0FBNkIsQ0FBQyxDQUFDLE1BQU0sQ0FBQztnQkFDdkQsSUFBSSxlQUFlLEdBQVcsSUFBSSxDQUFDLE9BQU8sQ0FBQyxrQkFBa0IsQ0FBQyxhQUFhLENBQUMsQ0FBQztnQkFDN0UsSUFBSSxnQkFBZ0IsR0FBRyxJQUFJLENBQUMsT0FBTyxDQUFDLG1CQUFtQixDQUFDLElBQUksQ0FBQyxZQUFZLEVBQUUsYUFBYSxDQUFDLFlBQVksQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDO2dCQUM3RyxJQUFJLElBQUksQ0FBQyxvQkFBb0IsQ0FBQyxlQUFlLENBQUMsRUFBRTtvQkFDNUMsSUFBSSxJQUFJLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxLQUFLLFFBQVEsSUFBSSxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLEtBQUssUUFBUSxJQUFJLENBQUMsSUFBSSxDQUFDLGlCQUFpQixDQUFDLGVBQWUsQ0FBQyxDQUFDLEVBQUU7d0JBQ2hILGdCQUFnQixDQUFDLEtBQUssQ0FBQyxNQUFNLEVBQUUsQ0FBQyxFQUFFLEVBQUUsRUFBRTs0QkFDbEMsT0FBTyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsRUFBRSxDQUFDLENBQUM7d0JBQ3JDLENBQUMsQ0FBQyxDQUFDO3FCQUNOO29CQUNELElBQUksSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsS0FBSyxRQUFRLElBQUksSUFBSSxDQUFDLE1BQU0sQ0FBQyxXQUFXLENBQUMsR0FBRyxDQUFDLE1BQU0sSUFBSSxJQUFJLENBQUMsTUFBTSxDQUFDLFdBQVcsQ0FBQyxHQUFHLENBQUMsTUFBTSxDQUFDLE1BQU0sSUFBSSxDQUFDLElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxhQUFhLENBQUMsWUFBWSxDQUFDLElBQUksQ0FBQyxDQUFDLEVBQUU7d0JBQ2hMLGdCQUFnQixDQUFDLEtBQUssQ0FBQyxjQUFjLEVBQUUsSUFBSSxDQUFDLE1BQU0sQ0FBQyxXQUFXLENBQUMsR0FBRyxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsQ0FBQztxQkFDckY7aUJBQ0o7WUFDTCxDQUFDLENBQUMsQ0FBQztZQUNILEVBQUUsQ0FBQyxnQkFBZ0IsQ0FBQyxPQUFPLEVBQUUsQ0FBQyxDQUFDLEVBQUUsRUFBRTtnQkFDL0IsSUFBSSxhQUFhLEdBQTZCLENBQUMsQ0FBQyxNQUFNLENBQUM7Z0JBQ3ZELElBQUksZUFBZSxHQUFXLElBQUksQ0FBQyxPQUFPLENBQUMsa0JBQWtCLENBQUMsYUFBYSxDQUFDLENBQUM7Z0JBQzdFLElBQUksZ0JBQWdCLEdBQUcsSUFBSSxDQUFDLE9BQU8sQ0FBQyxtQkFBbUIsQ0FBQyxJQUFJLENBQUMsWUFBWSxFQUFFLGFBQWEsQ0FBQyxZQUFZLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQztnQkFDN0csSUFBSSxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLEtBQUssTUFBTSxJQUFJLElBQUksQ0FBQyxNQUFNLENBQUMsV0FBVyxDQUFDLEdBQUcsQ0FBQyx5QkFBeUIsS0FBSyxJQUFJLENBQUMsSUFBSSxJQUFJLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxLQUFLLE1BQU0sRUFBRTtvQkFDbEksSUFBSSxDQUFDLFVBQVUsQ0FBQyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUM7b0JBQ3JELElBQUksSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsS0FBSyxRQUFRLEVBQUU7d0JBQ2hDLElBQUksdUJBQXVCLEdBQVksQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLFdBQVcsQ0FBQyxHQUFHLENBQUMsTUFBTSxJQUFJLElBQUksQ0FBQyxNQUFNLENBQUMsV0FBVyxDQUFDLEdBQUcsQ0FBQyxNQUFNLENBQUMsY0FBYyxJQUFJLElBQUksQ0FBQyxNQUFNLENBQUMsV0FBVyxDQUFDLEdBQUcsQ0FBQyxNQUFNLENBQUMsY0FBYyxJQUFJLFNBQVMsQ0FBQyxDQUFDO3dCQUNuTSx3Q0FBd0M7d0JBQ3hDLElBQUksSUFBSSxDQUFDLE1BQU0sQ0FBQyxXQUFXLENBQUMsR0FBRyxDQUFDLE1BQU0sSUFBSSxJQUFJLENBQUMsTUFBTSxDQUFDLFdBQVcsQ0FBQyxHQUFHLENBQUMsTUFBTSxDQUFDLE1BQU0sSUFBSSxJQUFJLENBQUMsTUFBTSxDQUFDLFdBQVcsQ0FBQyxHQUFHLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxLQUFLLElBQUksSUFBSSxDQUFDLE1BQU0sQ0FBQyxXQUFXLENBQUMsR0FBRyxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsS0FBSyxLQUFLLEVBQUUsRUFBRTs0QkFDOUwsSUFBSSxNQUFNLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxjQUFjLENBQUMsQ0FBQyxNQUFNLEtBQUssQ0FBQyxFQUFFO2dDQUMvQyxJQUFJLGNBQWMsR0FBRyxNQUFNLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxjQUFjLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztnQ0FDekQsRUFBRSxDQUFDLE1BQU0sQ0FBQyxHQUFHLEdBQUcsSUFBSSxDQUFDLE1BQU0sQ0FBQyxFQUFFLEdBQUcsb0NBQW9DLENBQUMsQ0FBQyxNQUFNLENBQUMsR0FBRyxHQUFHLElBQUksQ0FBQyxPQUFPLENBQUMsWUFBWSxHQUFHLGNBQWMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxNQUFNLEVBQUUsQ0FBQyxFQUFFLEVBQUUsRUFBRTtvQ0FDakosT0FBTyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsRUFBRSxDQUFDLENBQUM7Z0NBQ3JDLENBQUMsQ0FBQyxDQUFDO2dDQUNILElBQUksdUJBQXVCO29DQUFFLEVBQUUsQ0FBQyxNQUFNLENBQUMsR0FBRyxHQUFHLElBQUksQ0FBQyxNQUFNLENBQUMsRUFBRSxHQUFHLG9DQUFvQyxDQUFDLENBQUMsTUFBTSxDQUFDLEdBQUcsR0FBRyxJQUFJLENBQUMsT0FBTyxDQUFDLFlBQVksR0FBRyxjQUFjLENBQUMsQ0FBQyxLQUFLLENBQUMsY0FBYyxFQUFFLElBQUksQ0FBQyxNQUFNLENBQUMsV0FBVyxDQUFDLEdBQUcsQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLENBQUM7Z0NBQzlOLElBQUksQ0FBQyxjQUFjLEdBQUcsRUFBRSxDQUFDO2dDQUN6QixJQUFJLGNBQWMsS0FBSyxlQUFlLEVBQUU7b0NBQ3BDLElBQUksQ0FBQyxjQUFjLENBQUMsZUFBZSxDQUFDLEdBQUcsZUFBZSxDQUFDO29DQUN2RCxnQkFBZ0IsQ0FBQyxLQUFLLENBQUMsTUFBTSxFQUFFLElBQUksQ0FBQyxNQUFNLENBQUMsV0FBVyxDQUFDLEdBQUcsQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxDQUFDO29DQUNoRixJQUFJLHVCQUF1Qjt3Q0FBRSxnQkFBZ0IsQ0FBQyxLQUFLLENBQUMsY0FBYyxFQUFFLElBQUksQ0FBQyxNQUFNLENBQUMsV0FBVyxDQUFDLEdBQUcsQ0FBQyxNQUFNLENBQUMsY0FBYyxDQUFDLENBQUM7aUNBQzFIOzZCQUNKO2lDQUFNO2dDQUNILElBQUksQ0FBQyxjQUFjLEdBQUcsRUFBRSxDQUFDO2dDQUN6QixJQUFJLENBQUMsY0FBYyxDQUFDLGVBQWUsQ0FBQyxHQUFHLGVBQWUsQ0FBQztnQ0FDdkQsZ0JBQWdCLENBQUMsS0FBSyxDQUFDLE1BQU0sRUFBRSxJQUFJLENBQUMsTUFBTSxDQUFDLFdBQVcsQ0FBQyxHQUFHLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsQ0FBQztnQ0FDaEYsSUFBSSx1QkFBdUI7b0NBQUUsZ0JBQWdCLENBQUMsS0FBSyxDQUFDLGNBQWMsRUFBRSxJQUFJLENBQUMsTUFBTSxDQUFDLFdBQVcsQ0FBQyxHQUFHLENBQUMsTUFBTSxDQUFDLGNBQWMsQ0FBQyxDQUFDOzZCQUMxSDt5QkFDSjtxQkFDSjtpQkFDSjtxQkFBTTtvQkFDSCxJQUFJLElBQUksQ0FBQyxvQkFBb0IsQ0FBQyxlQUFlLENBQUMsRUFBRTt3QkFDNUMsSUFBSSxDQUFDLFlBQVksQ0FBQyxJQUFJLENBQUMsTUFBTSxFQUFFLEtBQUssQ0FBQyxDQUFDO3FCQUN6QztpQkFDSjtZQUNMLENBQUMsQ0FBQyxDQUFDO1FBQ1AsQ0FBQyxDQUFDLENBQUM7UUFDSCw0Q0FBNEM7UUFDNUMsU0FBUyxLQUFLO1lBQ1YsSUFBSSxNQUFNLEdBQUcsSUFBSSxDQUFDLE1BQU0sQ0FBQyxRQUFRLENBQUMsRUFDOUIsT0FBTyxHQUFHLE1BQU0sQ0FBQyxDQUFDLENBQUMsRUFDbkIsV0FBVyxHQUFHLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQztZQUM1QixpRkFBaUY7WUFDakYsR0FBRyxDQUFDLElBQUksQ0FBQyxPQUFPLEVBQUUsV0FBVyxDQUFDLENBQUMsQ0FBQyxHQUFHLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQztpQkFDekMsSUFBSSxDQUFDLFFBQVEsRUFBRSxXQUFXLENBQUMsQ0FBQyxDQUFDLEdBQUcsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDO2lCQUMzQyxLQUFLLENBQUMsTUFBTSxFQUFFLE9BQU8sQ0FBQyxDQUFDLENBQUMsR0FBRyxJQUFJLENBQUM7aUJBQ2hDLEtBQUssQ0FBQyxLQUFLLEVBQUUsT0FBTyxDQUFDLENBQUMsQ0FBQyxHQUFHLElBQUksQ0FBQyxDQUFDO1lBRXJDLElBQUksQ0FBQyxFQUFFLENBQUMsTUFBTSxDQUFDLEdBQUcsR0FBRyxjQUFjLEdBQUcsb0NBQW9DLENBQUMsQ0FBQyxNQUFNLENBQUMsVUFBVSxDQUFDLENBQUMsS0FBSyxFQUFFLEVBQUU7Z0JBQ3BHLEVBQUUsQ0FBQyxNQUFNLENBQUMsR0FBRyxHQUFHLGNBQWMsR0FBRyxvQ0FBb0MsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxVQUFVLENBQUMsQ0FBQyxJQUFJLENBQUMsV0FBVyxFQUFFO29CQUN4RyxPQUFPLFlBQVksR0FBRyxDQUFDLEtBQUssR0FBRyxHQUFHLEdBQUcsUUFBUSxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsR0FBRyxHQUFHLENBQUMsTUFBTSxHQUFHLENBQUMsR0FBRyxRQUFRLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxHQUFHLENBQUM7Z0JBQ2pILENBQUMsQ0FBQyxDQUFBO2FBQ0w7WUFDRCxRQUFRLENBQUMsSUFBSSxDQUFDLFdBQVcsRUFBRSxZQUFZLEdBQUcsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLEdBQUcsR0FBRyxHQUFHLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxHQUFHLEdBQUcsQ0FBQyxDQUFDO1lBQ2pGLE9BQU8sQ0FBQyxJQUFJLENBQUMsR0FBRyxFQUFFLElBQUksQ0FBQyxDQUFDO1FBQzVCLENBQUM7UUFFRCxJQUFJLFdBQVcsR0FBRztZQUNkLFlBQVksRUFBRSxJQUFJLENBQUMsaUJBQWlCO1lBQ3BDLFlBQVksRUFBRSxJQUFJLENBQUMsY0FBYyxDQUFDLElBQUk7WUFDdEMsY0FBYyxFQUFFLEVBQUUsQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxRQUFRLEVBQUUsQ0FBQyxXQUFXLENBQUM7WUFDbEUsV0FBVyxFQUFFLElBQUksQ0FBQyxVQUFVO1NBQy9CLENBQUM7UUFDRixJQUFJLElBQUksQ0FBQyxNQUFNLENBQUMsU0FBUyxJQUFJLFNBQVMsSUFBSSxJQUFJLENBQUMsTUFBTSxDQUFDLFNBQVMsQ0FBQyxXQUFXLElBQUksU0FBUyxFQUFFO1lBQ3RGLFdBQVcsQ0FBQyxXQUFXLENBQUMsR0FBRztnQkFDdkIsV0FBVyxFQUFFLENBQUMsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxJQUFJLENBQUMsb0JBQW9CLENBQUMsQ0FBQyxDQUFDO2dCQUNoRCxVQUFVLEVBQUUsR0FBRyxFQUFFLENBQUMsSUFBSSxDQUFDLHVCQUF1QixFQUFFO2FBQ25ELENBQUM7U0FDTDtRQUNELGNBQWM7UUFDZCxJQUFJLElBQUksQ0FBQyxjQUFjLENBQUMsSUFBSSxJQUFJLFNBQVMsRUFBRTtZQUN2QyxLQUFLLENBQUMsZ0JBQWdCLENBQUMsT0FBTyxFQUFFLFdBQVcsQ0FBQyxDQUFDO1NBQ2hEO0lBR0wsQ0FBQztJQUVPLGVBQWU7UUFDbkIsSUFBSSxDQUFDLGlCQUFpQixHQUFHLEVBQUUsQ0FBQztRQUM1QixJQUFJLENBQUMsS0FBSyxHQUFHLElBQUksQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLE9BQU8sRUFBRSxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUMsSUFBSSxDQUFDLFFBQVEsRUFBRSxJQUFJLENBQUMsT0FBTyxDQUFDLENBQUM7UUFFaEYsSUFBSSxDQUFDLFNBQVMsR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsQ0FBQyxPQUFPLENBQUMsV0FBVyxFQUFFLElBQUksQ0FBQyxDQUFDO1FBQ25FLElBQUksSUFBSSxDQUFDLE1BQU0sQ0FBQyxhQUFhLElBQUksSUFBSSxDQUFDLE1BQU0sQ0FBQyxhQUFhLENBQUMsT0FBTyxJQUFJLElBQUksRUFBRTtZQUN4RSxJQUFJLE9BQU8sSUFBSSxDQUFDLFNBQVMsS0FBSyxXQUFXO2dCQUFFLElBQUksQ0FBQyxZQUFZLEVBQUUsQ0FBQztTQUNsRTtRQUNELHdCQUF3QjtRQUN4QixJQUFJLElBQUksQ0FBQyxNQUFNLENBQUMsV0FBVyxDQUFDLEdBQUcsQ0FBQyxLQUFLLElBQUksQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLFdBQVcsQ0FBQyxHQUFHLENBQUMsS0FBSyxLQUFLLEVBQUUsSUFBSSxJQUFJLENBQUMsTUFBTSxDQUFDLFdBQVcsQ0FBQyxHQUFHLENBQUMsS0FBSyxLQUFLLFNBQVMsSUFBSSxJQUFJLENBQUMsTUFBTSxDQUFDLFdBQVcsQ0FBQyxHQUFHLENBQUMsS0FBSyxLQUFLLElBQUksQ0FBQyxJQUFJLElBQUksQ0FBQyxPQUFPLENBQUMsa0JBQWtCLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxXQUFXLENBQUMsR0FBRyxDQUFDLEtBQUssRUFBRSxJQUFJLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxFQUFFO1lBQzNRLElBQUksSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsS0FBSyxVQUFVLEVBQUU7Z0JBQ2xDLElBQUksQ0FBQyxNQUFNLEdBQUcsSUFBSSxDQUFDLE1BQU0sQ0FBQyxXQUFXLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQzthQUNuRDtpQkFBTTtnQkFDSCxJQUFJLENBQUMsYUFBYSxFQUFFLENBQUM7YUFDeEI7U0FDSjthQUFNLElBQUksSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsS0FBSyxTQUFTLEVBQUU7WUFDeEMsSUFBSSxDQUFDLGFBQWEsRUFBRSxDQUFDO1NBQ3hCO1FBQ0QsSUFBSSxJQUFJLEdBQUcsSUFBSSxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsY0FBYyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQztRQUM5RyxJQUFJLFVBQVUsR0FBRyxFQUFFLENBQUMsV0FBVyxFQUFFLENBQUMsT0FBTyxDQUFDLENBQUMsSUFBSSxDQUFDLE1BQU0sRUFBRSxJQUFJLENBQUMsT0FBTyxHQUFHLEVBQUUsQ0FBQyxFQUFFLElBQUksQ0FBQyxDQUFDO1FBQ2xGLElBQUksSUFBSSxHQUFHLEVBQUUsQ0FBQyxPQUFPLEVBQUUsQ0FBQyxVQUFVLENBQUMsVUFBVSxDQUFDLENBQUM7UUFDL0MsSUFBSSxRQUFRLEdBQUcsSUFBSSxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsY0FBYyxDQUFDLFVBQVUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQyxRQUFRLENBQUM7UUFDbkksSUFBSSxPQUFPLEdBQUcsSUFBSSxDQUFDLFNBQVMsQ0FBQyxTQUFTLENBQUMsTUFBTSxDQUFDO2FBQ3pDLElBQUksQ0FBQyxRQUFRLENBQUM7YUFDZCxLQUFLLEVBQUUsQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDO2FBQ3RCLElBQUksQ0FBQyxHQUFHLEVBQUUsSUFBSSxDQUFDO2FBQ2YsSUFBSSxDQUFDLElBQUksRUFBRSxDQUFDLENBQUMsRUFBRSxFQUFFLEdBQUcsT0FBTyxJQUFJLENBQUMsT0FBTyxDQUFDLFlBQVksR0FBRyxDQUFDLENBQUMsVUFBVSxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQzthQUMzRSxJQUFJLENBQUMsT0FBTyxFQUFFLENBQUMsQ0FBQyxFQUFFLEVBQUU7WUFDakIsSUFBSSxJQUFJLENBQUMsWUFBWSxJQUFJLEtBQUssSUFBSSxJQUFJLENBQUMsY0FBYyxJQUFJLElBQUksQ0FBQyxjQUFjLENBQUMsSUFBSSxJQUFJLFNBQVMsRUFBRTtnQkFDNUYsSUFBSSxXQUFXLEdBQUcsSUFBSSxDQUFDLGVBQWUsQ0FBQyxDQUFDLENBQUMsVUFBVSxDQUFDLEdBQUcsQ0FBQyxDQUFDO2dCQUN6RCxJQUFJLENBQUMsaUJBQWlCLENBQUMsSUFBSSxDQUFDLEVBQUUsTUFBTSxFQUFFLFdBQVcsQ0FBQyxJQUFJLEVBQUUsT0FBTyxFQUFFLFdBQVcsQ0FBQyxLQUFLLEVBQUUsSUFBSSxFQUFFLENBQUMsQ0FBQyxVQUFVLENBQUMsR0FBRyxFQUFFLENBQUMsQ0FBQztnQkFDOUcsT0FBTyxLQUFLLEdBQUcsV0FBVyxDQUFDLEVBQUUsR0FBRyxTQUFTLEdBQUcsV0FBVyxDQUFDLElBQUksR0FBRyxjQUFjLEdBQUcsV0FBVyxDQUFDLFNBQVMsR0FBRyxVQUFVLEdBQUcsV0FBVyxDQUFDLEtBQUssQ0FBQzthQUMxSTtRQUNMLENBQUMsQ0FBQzthQUNELElBQUksQ0FBQyxlQUFlLEVBQUUsb0JBQW9CLENBQUM7YUFDM0MsS0FBSyxDQUFDLE1BQU0sRUFBRSxDQUFDLENBQUMsRUFBRSxFQUFFO1lBQ2pCLE9BQU8sSUFBSSxDQUFDLGdCQUFnQixDQUFDLENBQUMsQ0FBQyxDQUFDO1FBQ3BDLENBQUMsQ0FBQzthQUNELEtBQUssQ0FBQyxjQUFjLEVBQUUsSUFBSSxDQUFDLE1BQU0sQ0FBQyxXQUFXLENBQUMsR0FBRyxDQUFDLFdBQVcsQ0FBQzthQUM5RCxLQUFLLENBQUMsUUFBUSxFQUFFLElBQUksQ0FBQyxNQUFNLENBQUMsV0FBVyxDQUFDLEdBQUcsQ0FBQyxXQUFXLENBQUMsQ0FBQztRQUU5RCxpREFBaUQ7UUFDakQsSUFBSSxJQUFJLENBQUMsWUFBWSxJQUFJLEtBQUssRUFBRTtZQUM1QixJQUFJLFFBQVEsR0FBRyxLQUFLLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxnQkFBZ0IsQ0FBQyxHQUFHLEdBQUcsSUFBSSxDQUFDLE1BQU0sQ0FBQyxFQUFFLEdBQUcsNEJBQTRCLENBQUMsQ0FBQyxDQUFDO1lBQzFHLFFBQVEsQ0FBQyxPQUFPLENBQUMsQ0FBQyxFQUFFLEVBQUUsRUFBRTtnQkFDcEIsRUFBRSxDQUFDLGdCQUFnQixDQUFDLFdBQVcsRUFBRSxDQUFDLENBQUMsRUFBRSxFQUFFO29CQUNuQyxJQUFJLGFBQWEsR0FBNkIsQ0FBQyxDQUFDLE1BQU0sQ0FBQztvQkFDdkQsSUFBSSxlQUFlLEdBQVcsYUFBYSxDQUFDLFlBQVksQ0FBQyxJQUFJLENBQUMsQ0FBQyxPQUFPLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLGFBQWEsQ0FBQyxZQUFZLENBQUMsSUFBSSxDQUFDLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxhQUFhLENBQUMsWUFBWSxDQUFDLElBQUksQ0FBQyxDQUFDO29CQUMxSyxJQUFJLGdCQUFnQixHQUFHLElBQUksQ0FBQyxPQUFPLENBQUMsbUJBQW1CLENBQUMsSUFBSSxDQUFDLFlBQVksRUFBRSxhQUFhLENBQUMsWUFBWSxDQUFDLElBQUksQ0FBQyxFQUFFLElBQUksQ0FBQyxDQUFDO29CQUNuSCxJQUFJLElBQUksQ0FBQyxvQkFBb0IsQ0FBQyxlQUFlLENBQUMsRUFBRTt3QkFDNUMsZ0JBQWdCLENBQUMsS0FBSyxDQUFDLE1BQU0sRUFBRSxJQUFJLENBQUMsTUFBTSxDQUFDLFdBQVcsQ0FBQyxHQUFHLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsQ0FBQztxQkFDbEY7Z0JBQ0wsQ0FBQyxDQUFDLENBQUM7Z0JBQ0gsRUFBRSxDQUFDLGdCQUFnQixDQUFDLFVBQVUsRUFBRSxDQUFDLENBQUMsRUFBRSxFQUFFO29CQUNsQyxJQUFJLGFBQWEsR0FBNkIsQ0FBQyxDQUFDLE1BQU0sQ0FBQztvQkFDdkQsSUFBSSxlQUFlLEdBQVcsYUFBYSxDQUFDLFlBQVksQ0FBQyxJQUFJLENBQUMsQ0FBQyxPQUFPLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLGFBQWEsQ0FBQyxZQUFZLENBQUMsSUFBSSxDQUFDLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxhQUFhLENBQUMsWUFBWSxDQUFDLElBQUksQ0FBQyxDQUFDO29CQUMxSyxJQUFJLGdCQUFnQixHQUFHLElBQUksQ0FBQyxPQUFPLENBQUMsbUJBQW1CLENBQUMsSUFBSSxDQUFDLFlBQVksRUFBRSxhQUFhLENBQUMsWUFBWSxDQUFDLElBQUksQ0FBQyxFQUFFLElBQUksQ0FBQyxDQUFDO29CQUNuSCxJQUFJLElBQUksQ0FBQyxvQkFBb0IsQ0FBQyxlQUFlLENBQUMsRUFBRTt3QkFDNUMsZ0JBQWdCLENBQUMsS0FBSyxDQUFDLE1BQU0sRUFBRSxDQUFDLEVBQUUsRUFBRSxFQUFFOzRCQUNsQyxPQUFPLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxFQUFFLENBQUMsQ0FBQzt3QkFDckMsQ0FBQyxDQUFDLENBQUM7cUJBQ047Z0JBQ0wsQ0FBQyxDQUFDLENBQUM7Z0JBQ0gsRUFBRSxDQUFDLGdCQUFnQixDQUFDLE9BQU8sRUFBRSxDQUFDLENBQUMsRUFBRSxFQUFFO29CQUMvQixJQUFJLElBQUksQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLEtBQUssU0FBUyxFQUFFO3dCQUNqQyxJQUFJLGFBQWEsR0FBNkIsQ0FBQyxDQUFDLE1BQU0sQ0FBQzt3QkFDdkQsSUFBSSxlQUFlLEdBQVcsSUFBSSxDQUFDLE9BQU8sQ0FBQyxrQkFBa0IsQ0FBQyxhQUFhLENBQUMsQ0FBQzt3QkFDN0UsSUFBSSxJQUFJLENBQUMsb0JBQW9CLENBQUMsZUFBZSxDQUFDLEVBQUU7NEJBQzVDLElBQUksQ0FBQyxZQUFZLENBQUMsSUFBSSxDQUFDLE1BQU0sRUFBRSxLQUFLLENBQUMsQ0FBQzt5QkFDekM7cUJBQ0o7Z0JBQ0wsQ0FBQyxDQUFDLENBQUM7WUFDUCxDQUFDLENBQUMsQ0FBQztZQUVILElBQUksV0FBVyxHQUFHO2dCQUNkLFlBQVksRUFBRSxJQUFJLENBQUMsaUJBQWlCO2dCQUNwQyxZQUFZLEVBQUUsSUFBSSxDQUFDLGNBQWMsQ0FBQyxJQUFJO2FBQ3pDLENBQUM7WUFDRixJQUFJLElBQUksQ0FBQyxNQUFNLENBQUMsU0FBUyxJQUFJLFNBQVMsSUFBSSxJQUFJLENBQUMsTUFBTSxDQUFDLFNBQVMsQ0FBQyxXQUFXLElBQUksU0FBUyxFQUFFO2dCQUN0RixXQUFXLENBQUMsV0FBVyxDQUFDLEdBQUc7b0JBQ3ZCLFdBQVcsRUFBRSxDQUFDLENBQUMsRUFBRSxFQUFFLENBQUMsSUFBSSxDQUFDLG9CQUFvQixDQUFDLENBQUMsQ0FBQztvQkFDaEQsVUFBVSxFQUFFLEdBQUcsRUFBRSxDQUFDLElBQUksQ0FBQyx1QkFBdUIsRUFBRTtpQkFDbkQsQ0FBQzthQUNMO1lBQ0QsY0FBYztZQUNkLElBQUksSUFBSSxDQUFDLGNBQWMsQ0FBQyxJQUFJLElBQUksU0FBUyxFQUFFO2dCQUN2QyxLQUFLLENBQUMsZ0JBQWdCLENBQUMsT0FBTyxFQUFFLFdBQVcsQ0FBQyxDQUFDO2FBQ2hEO1NBQ0o7SUFDTCxDQUFDO0lBRU8sZ0JBQWdCLENBQUMsTUFBVztRQUNoQyxJQUFJLElBQUksQ0FBQyxjQUFjLElBQUksU0FBUyxJQUFJLElBQUksQ0FBQyxjQUFjLENBQUMsSUFBSSxJQUFJLFNBQVM7WUFBRSxPQUFPLFNBQVMsQ0FBQztRQUVoRyxJQUFJLFNBQVMsR0FBRyxJQUFJLENBQUMsZUFBZSxDQUFDLE1BQU0sQ0FBQyxVQUFVLENBQUMsR0FBRyxDQUFDLENBQUMsS0FBSyxDQUFDO1FBRWxFLElBQUksSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsS0FBSyxRQUFRLElBQUksSUFBSSxDQUFDLE1BQU0sQ0FBQyxTQUFTLElBQUksSUFBSSxDQUFDLE1BQU0sQ0FBQyxTQUFTLENBQUMsUUFBUSxFQUFFO1lBQzNGLE9BQU8sSUFBSSxDQUFDLE1BQU0sQ0FBQyxTQUFTLENBQUMsUUFBUSxDQUFDO1NBQ3pDO1FBRUQsSUFBSSxTQUFTLElBQUksSUFBSSxJQUFJLFNBQVMsSUFBSSxFQUFFO1lBQUUsT0FBTyxJQUFJLENBQUMsTUFBTSxDQUFDLFdBQVcsQ0FBQyxHQUFHLENBQUMsU0FBUyxJQUFJLGNBQWMsQ0FBQztRQUV6RyxJQUFJLElBQUksQ0FBQyxNQUFNLENBQUMsU0FBUyxJQUFJLFNBQVMsSUFBSSxJQUFJLENBQUMsTUFBTSxDQUFDLFNBQVMsQ0FBQyxXQUFXLElBQUksU0FBUyxFQUFFO1lBQ3RGLE9BQU8sSUFBSSxDQUFDLG1CQUFtQixDQUFDLFNBQVMsQ0FBQyxDQUFDO1NBQzlDO1FBRUQsSUFBSSxJQUFJLENBQUMscUJBQXFCLElBQUksSUFBSSxFQUFFO1lBQ3BDLEtBQUssSUFBSSxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsR0FBRyxJQUFJLENBQUMsTUFBTSxDQUFDLFNBQVMsQ0FBQyxXQUFXLENBQUMsTUFBTSxFQUFFLENBQUMsRUFBRSxFQUFFO2dCQUMvRCxJQUFJLElBQUksQ0FBQyxPQUFPLENBQUMsbUJBQW1CLENBQUMsTUFBTSxDQUFDLFNBQVMsQ0FBQyxFQUFFLElBQUksQ0FBQyxNQUFNLENBQUMsU0FBUyxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLEVBQUUsSUFBSSxDQUFDLE1BQU0sQ0FBQyxTQUFTLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFO29CQUN6SSxJQUFJLElBQUksQ0FBQyxNQUFNLENBQUMsSUFBSSxHQUFHLENBQUMsQ0FBQyxJQUFJLElBQUksQ0FBQyxNQUFNLENBQUMsSUFBSSxHQUFHLENBQUMsQ0FBQyxDQUFDLFFBQVEsSUFBSSxJQUFJLEVBQUU7d0JBQ2pFLE9BQU8sU0FBUyxDQUFDO3FCQUNwQjtvQkFDRCxPQUFPLElBQUksQ0FBQyxNQUFNLENBQUMsU0FBUyxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUM7aUJBQ3JEO3FCQUFNLElBQUksQ0FBQyxJQUFJLElBQUksQ0FBQyxNQUFNLENBQUMsU0FBUyxDQUFDLFdBQVcsQ0FBQyxNQUFNLEVBQUU7b0JBQ3RELE9BQU8sSUFBSSxDQUFDLE1BQU0sQ0FBQyxTQUFTLENBQUMsUUFBUSxDQUFDO2lCQUN6QzthQUNKO1NBQ0o7UUFFRCxJQUFJLElBQUksQ0FBQyxZQUFZLElBQUksS0FBSztZQUFFLE9BQU8sSUFBSSxDQUFDLGFBQWEsQ0FBQyxLQUFLLENBQUM7UUFFaEUsT0FBTyxTQUFTLENBQUM7SUFDckIsQ0FBQztJQUVPLFlBQVksQ0FBQyxNQUFjLEVBQUUsS0FBYTtRQUM5QyxJQUFJLE1BQU0sR0FBRyxNQUFNLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLENBQUM7UUFDNUMsSUFBSSxVQUFVLEdBQVcsQ0FBQyxFQUFFLFFBQWdCLENBQUM7UUFDN0MsSUFBSSxRQUFnQixDQUFDO1FBQ3JCLEtBQUssSUFBSSxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsR0FBRyxNQUFNLENBQUMsTUFBTSxFQUFFLENBQUMsRUFBRSxFQUFFO1lBQ3BDLElBQUksTUFBTSxDQUFDLENBQUMsQ0FBQyxLQUFLLE1BQU07Z0JBQUUsVUFBVSxHQUFHLENBQUMsQ0FBQztTQUM1QztRQUNELElBQUksS0FBSyxLQUFLLEtBQUssRUFBRTtZQUNqQixJQUFJLFVBQVUsR0FBRyxDQUFDLElBQUksTUFBTSxDQUFDLE1BQU07Z0JBQUUsUUFBUSxHQUFHLFVBQVUsR0FBRyxDQUFDLENBQUM7U0FDbEU7YUFBTTtZQUNILElBQUksVUFBVSxHQUFHLENBQUMsSUFBSSxDQUFDO2dCQUFFLFFBQVEsR0FBRyxVQUFVLEdBQUcsQ0FBQyxDQUFDO1NBQ3REO1FBQ0QsSUFBSSxRQUFRLEtBQUssU0FBUyxFQUFFO1lBQ3hCLFFBQVEsR0FBRyxNQUFNLENBQUMsUUFBUSxDQUFDLENBQUM7WUFDNUIsSUFBSSxJQUFJLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxRQUFRLENBQUMsSUFBSSxTQUFTLEVBQUU7Z0JBQzFDLElBQUksT0FBTyxJQUFJLENBQUMsU0FBUyxLQUFLLFdBQVcsRUFBRTtvQkFBRSxJQUFJLENBQUMsU0FBUyxDQUFDLE1BQU0sRUFBRSxDQUFDO2lCQUFFO2dCQUN2RSxJQUFJLENBQUMsTUFBTSxHQUFHLFFBQVEsQ0FBQztnQkFDdkIsSUFBSSxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsR0FBRyxJQUFJLENBQUMsTUFBTSxDQUFDO2dCQUNwQyxJQUFJLElBQUksQ0FBQyxNQUFNLENBQUMsU0FBUyxJQUFJLFNBQVM7b0JBQUUsSUFBSSxDQUFDLHVDQUF1QyxFQUFFLENBQUM7Z0JBQ3ZGLElBQUksQ0FBQyxnQkFBZ0IsRUFBRSxDQUFDO2dCQUN4QixJQUFJLElBQUksQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLEtBQUssTUFBTSxFQUFFO29CQUM5QixJQUFJLENBQUMsWUFBWSxFQUFFLENBQUM7aUJBQ3ZCOztvQkFDSSxJQUFJLENBQUMsZUFBZSxFQUFFLENBQUM7YUFDL0I7U0FDSjtRQUNELHVDQUF1QztRQUN2QyxvQkFBb0I7UUFDcEIsNkNBQTZDO1FBQzdDLDRDQUE0QztRQUM1QyxLQUFLO1FBQ0wsbUdBQW1HO1FBQ25HLG9MQUFvTDtJQUV4TCxDQUFDO0lBRU8sWUFBWTtRQUNoQiw2QkFBNkI7UUFDN0IsSUFBSSxNQUFNLEdBQWEsR0FBRyxFQUFFO1lBQ3hCLE1BQU0sU0FBUyxHQUFHLEVBQUUsQ0FBQyxLQUFLLENBQUMsU0FBUyxDQUFDO1lBQ3JDLElBQUksQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDLFdBQVcsRUFBRSxZQUFZLEdBQUcsU0FBUyxDQUFDLENBQUMsR0FBRyxHQUFHLEdBQUcsU0FBUyxDQUFDLENBQUMsR0FBRyxVQUFVLEdBQUcsU0FBUyxDQUFDLENBQUMsR0FBRyxHQUFHLENBQUMsQ0FBQztRQUN0SCxDQUFDLENBQUM7UUFDRixJQUFJLElBQUksR0FBRyxFQUFFLENBQUMsSUFBSSxFQUFFLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLE1BQU0sRUFBRSxNQUFNLENBQUMsQ0FBQztRQUU1RCxJQUFJLENBQUMsU0FBUyxHQUFHLElBQUksQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxZQUFZLEVBQUUsSUFBSSxDQUFDLENBQUM7UUFDcEUsSUFBSSxPQUFPLEdBQUcsSUFBSSxDQUFDLFNBQVMsQ0FBQyxTQUFTLENBQUMsR0FBRyxDQUFDO2FBQ3RDLElBQUksQ0FBQyxDQUFDLFFBQVEsRUFBRSxTQUFTLENBQUMsQ0FBQzthQUMzQixLQUFLLEVBQUUsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDO2FBQ25CLElBQUksQ0FBQyxJQUFJLEVBQUUsVUFBUyxDQUFDLElBQUksT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7WUFDdEMsb0dBQW9HO2FBQ25HLElBQUksQ0FBQyxXQUFXLEVBQUUsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLEVBQUUsR0FBRyxPQUFPLGVBQWUsR0FBRyxDQUFDLEVBQUUsR0FBRyxDQUFDLENBQUMsR0FBRyxFQUFFLENBQUMsQ0FBQyxHQUFHLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQzthQUNoRixLQUFLLENBQUMsUUFBUSxFQUFFLFNBQVMsQ0FBQzthQUMxQixFQUFFLENBQUMsT0FBTyxFQUFFLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFLEdBQUcsSUFBSSxDQUFDLFVBQVUsQ0FBQyxDQUFDLEVBQUUsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztRQUMxRCxPQUFPLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQzthQUNqQixJQUFJLENBQUMsT0FBTyxFQUFFLE1BQU0sQ0FBQzthQUNyQixJQUFJLENBQUMsUUFBUSxFQUFFLE1BQU0sQ0FBQzthQUN0QixJQUFJLENBQUMsSUFBSSxFQUFFLENBQUMsQ0FBQzthQUNiLElBQUksQ0FBQyxJQUFJLEVBQUUsQ0FBQyxDQUFDO2FBQ2IsS0FBSyxDQUFDLFNBQVMsRUFBRSxDQUFDLENBQUM7YUFDbkIsS0FBSyxDQUFDLE1BQU0sRUFBRSxNQUFNLENBQUM7YUFDckIsS0FBSyxDQUFDLFFBQVEsRUFBRSxNQUFNLENBQUM7YUFDdkIsS0FBSyxDQUFDLGNBQWMsRUFBRSxHQUFHLENBQUMsQ0FBQztRQUNoQyxPQUFPLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQzthQUNqQixJQUFJLENBQUMsR0FBRyxFQUFFLEVBQUUsQ0FBQzthQUNiLElBQUksQ0FBQyxHQUFHLEVBQUUsRUFBRSxDQUFDO2FBQ2IsSUFBSSxDQUFDLElBQUksRUFBRSxPQUFPLENBQUM7YUFDbkIsSUFBSSxDQUFDLGFBQWEsRUFBRSxRQUFRLENBQUM7YUFDN0IsS0FBSyxDQUFDLFdBQVcsRUFBRSxNQUFNLENBQUM7YUFDMUIsS0FBSyxDQUFDLGFBQWEsRUFBRSxNQUFNLENBQUM7YUFDNUIsSUFBSSxDQUFDLFVBQVMsQ0FBQyxFQUFFLENBQUMsSUFBSSxPQUFPLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7UUFFekQsSUFBSSxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUM7SUFDOUIsQ0FBQztJQUVPLFVBQVUsQ0FBQyxVQUFrQixFQUFFLEtBQUs7UUFDeEMsSUFBSSxNQUFNLEdBQUcsVUFBVSxJQUFJLFFBQVEsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUM7UUFDaEQsS0FBSyxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsU0FBUyxFQUFFLE1BQU0sQ0FBQyxDQUFDO0lBQzFDLENBQUM7SUFFTyxZQUFZO1FBQ2hCLDRCQUE0QjtRQUM1QixJQUFJLE9BQU8sSUFBSSxDQUFDLFFBQVEsS0FBSyxXQUFXLEVBQUU7WUFDdEMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxNQUFNLEVBQUUsQ0FBQztZQUN2QixJQUFJLENBQUMsUUFBUSxHQUFHLFNBQVMsQ0FBQztTQUM3QjtRQUNELFVBQVUsQ0FBQyxHQUFHLEVBQUU7WUFDWixJQUFJLElBQUksQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLEtBQUssTUFBTSxFQUFFO2dCQUM5QixJQUFJLENBQUMsUUFBUSxHQUFHLElBQUksQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxXQUFXLEVBQUUsSUFBSSxDQUFDLENBQUM7Z0JBQ2xFLElBQUksd0JBQXdCLEdBQVcsRUFBRSxDQUFDO2dCQUMxQyxJQUFJLElBQUksQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLEtBQUssTUFBTSxFQUFFO29CQUM5Qix3QkFBd0IsR0FBRyxZQUFZLEdBQUcsQ0FBQyxJQUFJLENBQUMsTUFBTSxHQUFHLEdBQUcsQ0FBQyxHQUFHLEdBQUcsR0FBRyxDQUFDLElBQUksQ0FBQyxPQUFPLEdBQUcsQ0FBQyxDQUFDLEdBQUcsR0FBRyxDQUFDO2lCQUNsRztxQkFBTTtvQkFDSCx3QkFBd0IsR0FBRyxZQUFZLEdBQUcsQ0FBQyxJQUFJLENBQUMsTUFBTSxHQUFHLEdBQUcsR0FBRyxRQUFRLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxJQUFJLEVBQUUsQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLENBQUMsR0FBRyxHQUFHLEdBQUcsQ0FBQyxJQUFJLENBQUMsT0FBTyxHQUFHLENBQUMsR0FBRyxRQUFRLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxJQUFJLEVBQUUsQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLENBQUMsR0FBRyxHQUFHLENBQUM7aUJBQzdMO2dCQUNELElBQUksT0FBTyxHQUFHLElBQUksQ0FBQyxRQUFRLENBQUMsU0FBUyxDQUFDLEdBQUcsQ0FBQztxQkFDckMsSUFBSSxDQUFDLENBQUMsU0FBUyxDQUFDLENBQUM7cUJBQ2pCLEtBQUssRUFBRSxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUM7cUJBQ25CLElBQUksQ0FBQyxJQUFJLEVBQUUsVUFBUyxDQUFDLElBQUksT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7cUJBQ3JDLElBQUksQ0FBQyxXQUFXLEVBQUUsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLEVBQUUsR0FBRyxPQUFPLHdCQUF3QixDQUFDLENBQUMsQ0FBQyxDQUFDO3FCQUNqRSxLQUFLLENBQUMsUUFBUSxFQUFFLFNBQVMsQ0FBQztxQkFDMUIsS0FBSyxDQUFDLGdCQUFnQixFQUFFLFNBQVMsQ0FBQztxQkFDbEMsRUFBRSxDQUFDLE9BQU8sRUFBRSxDQUFDLENBQUMsRUFBRSxFQUFFLEdBQUcsSUFBSSxDQUFDLFlBQVksQ0FBQyxJQUFJLENBQUMsTUFBTSxFQUFFLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7Z0JBQ3RFLE9BQU8sQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDO3FCQUNqQixJQUFJLENBQUMsT0FBTyxFQUFFLE1BQU0sQ0FBQztxQkFDckIsSUFBSSxDQUFDLFFBQVEsRUFBRSxNQUFNLENBQUM7cUJBQ3RCLEtBQUssQ0FBQyxNQUFNLEVBQUUsb0JBQW9CLENBQUM7cUJBQ25DLEtBQUssQ0FBQyxRQUFRLEVBQUUsb0JBQW9CLENBQUM7cUJBQ3JDLEtBQUssQ0FBQyxjQUFjLEVBQUUsR0FBRyxDQUFDLENBQUM7Z0JBQ2hDLE9BQU8sQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDO3FCQUNqQixJQUFJLENBQUMsR0FBRyxFQUFFLEVBQUUsQ0FBQztxQkFDYixJQUFJLENBQUMsR0FBRyxFQUFFLEVBQUUsQ0FBQztxQkFDYixJQUFJLENBQUMsSUFBSSxFQUFFLE9BQU8sQ0FBQztxQkFDbkIsSUFBSSxDQUFDLGFBQWEsRUFBRSxRQUFRLENBQUM7cUJBQzdCLEtBQUssQ0FBQyxXQUFXLEVBQUUsTUFBTSxDQUFDO3FCQUMxQixLQUFLLENBQUMsYUFBYSxFQUFFLFFBQVEsQ0FBQztxQkFDOUIsSUFBSSxDQUFDLFVBQVMsQ0FBQyxFQUFFLENBQUMsSUFBSSxPQUFPLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7YUFDMUU7aUJBQU07Z0JBQ0gsSUFBSSxDQUFDLFFBQVEsR0FBRyxJQUFJLENBQUMsWUFBWSxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsQ0FBQTtnQkFDL0MsSUFBSSxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsT0FBTyxFQUFFLDBCQUEwQixDQUFDLENBQUE7Z0JBQ3ZELElBQUksQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLFVBQVMsQ0FBQyxFQUFFLENBQUMsSUFBSSxPQUFPLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUE7Z0JBQy9FLElBQUksQ0FBQyxRQUFRLENBQUMsRUFBRSxDQUFDLE9BQU8sRUFBRSxDQUFDLENBQUMsRUFBRSxFQUFFLEdBQUcsSUFBSSxDQUFDLFlBQVksQ0FBQyxJQUFJLENBQUMsTUFBTSxFQUFFLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7YUFDbEY7UUFDTCxDQUFDLENBQUMsQ0FBQTtJQUNOLENBQUM7SUFFTyxhQUFhO1FBQ2pCLElBQUksaUJBQWlCLEdBQUcsSUFBSSxDQUFDLGtCQUFrQixFQUFFLENBQUM7UUFDbEQsSUFBSSxpQkFBaUIsSUFBSSxJQUFJLEVBQUU7WUFDM0IsSUFBSSxPQUFPLElBQUksQ0FBQyxRQUFRLEtBQUssV0FBVztnQkFBRSxJQUFJLENBQUMsWUFBWSxFQUFFLENBQUM7U0FDakU7YUFDSTtZQUNELElBQUksT0FBTyxJQUFJLENBQUMsUUFBUSxLQUFLLFdBQVcsRUFBRTtnQkFDdEMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxNQUFNLEVBQUUsQ0FBQztnQkFDdkIsSUFBSSxDQUFDLFFBQVEsR0FBRyxTQUFTLENBQUM7YUFDN0I7U0FDSjtJQUNMLENBQUM7SUFFTyxrQkFBa0I7UUFDdEIsSUFBSSxZQUFxQixDQUFDO1FBQzFCLElBQUksWUFBWSxHQUFHLElBQUksQ0FBQyxhQUFhLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsYUFBYSxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLGFBQWEsQ0FBQztRQUNqSCxJQUFJLElBQUksQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsQ0FBQyxFQUFFO1lBQ2hDLFlBQVksR0FBRyxRQUFRLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxZQUFZLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDO1NBQ3JGO2FBQU07WUFDSCxZQUFZLEdBQUcsUUFBUSxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsSUFBSSxZQUFZLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDO1NBQ3ZFO1FBQ0QsT0FBTyxZQUFZLENBQUM7SUFDeEIsQ0FBQztJQUlPLGVBQWUsQ0FBQyxTQUFTO1FBQzdCLElBQUksU0FBUyxHQUFHO1lBQ1osSUFBSSxFQUFFLEVBQUU7WUFDUixNQUFNLEVBQUUsRUFBRTtZQUNWLFdBQVcsRUFBRSxFQUFFO1lBQ2YsT0FBTyxFQUFFLEVBQUU7U0FDZCxDQUFDO1FBQ0YsS0FBSyxJQUFJLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxHQUFHLElBQUksQ0FBQyxjQUFjLENBQUMsSUFBSSxDQUFDLE1BQU0sRUFBRSxDQUFDLEVBQUUsRUFBRTtZQUN0RCxJQUFJLElBQUksQ0FBQyxjQUFjLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsSUFBSSxTQUFTLEVBQUU7Z0JBQzlDLFNBQVMsQ0FBQyxFQUFFLEdBQUcsSUFBSSxDQUFDLGNBQWMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDO2dCQUMvQyxTQUFTLENBQUMsSUFBSSxHQUFHLElBQUksQ0FBQyxjQUFjLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQztnQkFDcEQsU0FBUyxDQUFDLFNBQVMsR0FBRyxJQUFJLENBQUMsY0FBYyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUM7Z0JBQzVELFNBQVMsQ0FBQyxLQUFLLEdBQUcsSUFBSSxDQUFDLGNBQWMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDO2dCQUNwRCxNQUFNO2FBQ1Q7U0FDSjtRQUNELE9BQU8sU0FBUyxDQUFDO0lBQ3JCLENBQUM7SUFFTyxhQUFhLENBQUMsVUFBZ0I7UUFDbEMsSUFBSSxhQUFhLEdBQUcsVUFBVSxDQUFDLENBQUMsQ0FBQyxVQUFVLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUM7UUFDMUQsSUFBSSxhQUFhLEdBQUcsTUFBTSxDQUFDLElBQUksQ0FBQyxhQUFhLENBQUMsQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDLEVBQUUsR0FBRyxPQUFPLGFBQWEsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO1FBQzFGLElBQUksYUFBYSxHQUFHLEVBQUUsQ0FBQztRQUN2QixLQUFLLElBQUksQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLEdBQUcsYUFBYSxDQUFDLE1BQU0sRUFBRSxDQUFDLEVBQUUsRUFBRTtZQUMzQyxLQUFLLElBQUksQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLEdBQUcsSUFBSSxDQUFDLFdBQVcsQ0FBQyxNQUFNLEVBQUUsQ0FBQyxFQUFFLEVBQUU7Z0JBQzlDLElBQUksYUFBYSxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsSUFBSSxLQUFLLElBQUksSUFBSSxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLElBQUksYUFBYSxDQUFDLENBQUMsQ0FBQyxDQUFDLFdBQVcsRUFBRTtvQkFDOUYsYUFBYSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7b0JBQ3hDLE1BQU07aUJBQ1Q7YUFDSjtTQUNKO1FBQ0QsSUFBSSxDQUFDLFlBQVksR0FBRyxhQUFhLENBQUMsTUFBTSxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUM7UUFDN0QsSUFBSSxhQUFhLENBQUMsTUFBTSxJQUFJLENBQUMsRUFBRTtZQUFFLElBQUksQ0FBQyxjQUFjLEdBQUcsYUFBYSxDQUFDLGFBQWEsQ0FBQyxNQUFNLEdBQUcsQ0FBQyxDQUFDLENBQUM7U0FBRTtJQUNyRyxDQUFDO0lBRU8sdUNBQXVDO1FBQzNDLElBQUksVUFBVSxDQUFDO1FBQ2YsSUFBSSxJQUFJLENBQUMsa0JBQWtCLEVBQUUsSUFBSSxJQUFJLEVBQUU7WUFDbkMsVUFBVSxHQUFHLElBQUksQ0FBQyxTQUFTLENBQUMsZ0JBQWdCLENBQUMsSUFBSSxDQUFDLE1BQU0sRUFBRSxDQUFDLElBQUksQ0FBQyxjQUFjLENBQUMsRUFBRSxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUM7U0FDakc7YUFBTTtZQUNILFVBQVUsR0FBRyxJQUFJLENBQUMsU0FBUyxDQUFDLGdCQUFnQixDQUFDLElBQUksQ0FBQyxNQUFNLEVBQUUsSUFBSSxDQUFDLFdBQVcsRUFBRSxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUM7WUFDekYsSUFBSSxDQUFDLGFBQWEsQ0FBQyxVQUFVLENBQUMsQ0FBQztTQUNsQztRQUNELElBQUksQ0FBQyxZQUFZLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxDQUFDO0lBQ3ZDLENBQUM7SUFFTyxnQkFBZ0I7UUFDcEIsK0VBQStFO1FBQy9FLElBQUksYUFBYSxHQUFHLE1BQU0sQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQztRQUNwRixJQUFJLElBQUksQ0FBQyxjQUFjLElBQUksU0FBUyxFQUFFO1lBQ2xDLEtBQUssSUFBSSxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsR0FBRyxhQUFhLENBQUMsTUFBTSxFQUFFLENBQUMsRUFBRSxFQUFFO2dCQUMzQyxJQUFJLElBQUksQ0FBQyxjQUFjLENBQUMsRUFBRSxJQUFJLGFBQWEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxXQUFXLEVBQUU7b0JBQ3hELElBQUksQ0FBQyxhQUFhLEdBQUcsSUFBSSxDQUFDLFVBQVUsQ0FBQyxhQUFhLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUM7b0JBQzFELHlEQUF5RDtvQkFDekQsTUFBTTtpQkFDVDthQUNKO1NBQ0o7SUFDTCxDQUFDO0lBRU8sZ0JBQWdCO1FBQ3BCLHNCQUFzQjtRQUN0QixJQUFJLGFBQWEsR0FBRyxNQUFNLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUM7UUFDcEYsK0VBQStFO1FBQy9FLEtBQUssSUFBSSxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsR0FBRyxhQUFhLENBQUMsTUFBTSxFQUFFLENBQUMsRUFBRSxFQUFFO1lBQzNDLEtBQUssSUFBSSxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsR0FBRyxJQUFJLENBQUMsV0FBVyxDQUFDLE1BQU0sRUFBRSxDQUFDLEVBQUUsRUFBRTtnQkFDOUMsSUFBSSxJQUFJLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsSUFBSSxhQUFhLENBQUMsQ0FBQyxDQUFDLENBQUMsV0FBVyxFQUFFO29CQUN4RCxJQUFJLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssR0FBRyxhQUFhLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDO29CQUNuRCxNQUFNO2lCQUNUO2FBQ0o7U0FDSjtJQUNMLENBQUM7SUFFTyxnQkFBZ0I7UUFDcEIseURBQXlEO1FBQ3pELElBQUksQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLFdBQVcsRUFBRTtZQUMxQixJQUFJLENBQUMscUJBQXFCLEdBQUcsS0FBSyxDQUFDO1lBQ25DLElBQUksSUFBSSxDQUFDLE1BQU0sQ0FBQyxTQUFTLElBQUksU0FBUyxFQUFFO2dCQUNwQyxJQUFJLElBQUksQ0FBQyxNQUFNLENBQUMsU0FBUyxDQUFDLFdBQVcsSUFBSSxJQUFJLENBQUMsTUFBTSxDQUFDLFNBQVMsQ0FBQyxXQUFXLENBQUMsTUFBTSxLQUFLLENBQUMsRUFBRTtvQkFDckYsSUFBSSxDQUFDLHFCQUFxQixHQUFHLElBQUksQ0FBQztvQkFDbEMsSUFBSSxDQUFDLE1BQU0sR0FBRyxJQUFJLENBQUMsU0FBUyxDQUFDLHFCQUFxQixDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsU0FBUyxDQUFDLFdBQVcsRUFBRSxJQUFJLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxhQUFhLEVBQUUsSUFBSSxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsV0FBVyxFQUFFLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQztvQkFDckssSUFBSSxDQUFDLFlBQVksQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDO2lCQUN2QztxQkFBTTtvQkFDSCxJQUFJLENBQUMsWUFBWSxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsQ0FBQztpQkFDOUI7YUFDSjtpQkFBTTtnQkFDSCx5QkFBeUI7Z0JBQ3pCLElBQUksQ0FBQyxNQUFNLEdBQUcsSUFBSSxDQUFDLFNBQVMsQ0FBQyxnQkFBZ0IsQ0FBQyxJQUFJLENBQUMsTUFBTSxFQUFFLElBQUksQ0FBQyxXQUFXLEVBQUUsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDO2dCQUMxRixJQUFJLENBQUMsWUFBWSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUM7YUFDdkM7U0FDSjthQUFNO1lBQ0gsbUNBQW1DO1lBQ25DLElBQUksQ0FBQyxxQkFBcUIsR0FBRyxLQUFLLENBQUM7WUFDbkMsSUFBSSxJQUFJLENBQUMsTUFBTSxDQUFDLFNBQVMsSUFBSSxTQUFTLEVBQUU7Z0JBQ3BDLElBQUksSUFBSSxDQUFDLE1BQU0sQ0FBQyxTQUFTLENBQUMsV0FBVyxJQUFJLElBQUksQ0FBQyxNQUFNLENBQUMsU0FBUyxDQUFDLFdBQVcsQ0FBQyxNQUFNLEtBQUssQ0FBQyxFQUFFO29CQUNyRixJQUFJLENBQUMscUJBQXFCLEdBQUcsSUFBSSxDQUFDO29CQUNsQyxJQUFJLENBQUMsWUFBWSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUM7aUJBQ3ZDO3FCQUFNO29CQUNILElBQUksQ0FBQyxZQUFZLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxDQUFDO2lCQUM5QjthQUNKO2lCQUFNO2dCQUNILElBQUksQ0FBQyxZQUFZLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQzthQUN2QztTQUNKO0lBQ0wsQ0FBQztJQUVPLG9CQUFvQixDQUFDLE1BQWM7UUFDdkMsSUFBSSxJQUFJLEdBQVcsSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztRQUN2QyxJQUFJLENBQUMsT0FBTyxDQUFDLHlCQUF5QixDQUFDLElBQUksR0FBRyxJQUFJLENBQUMsT0FBTyxDQUFDLFVBQVUsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDO0lBQ25GLENBQUM7SUFFTyx1QkFBdUI7UUFDM0IsSUFBSSxvQkFBb0IsR0FBVyxJQUFJLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDO1FBQzNELElBQUksQ0FBQyxPQUFPLENBQUMseUJBQXlCLENBQUMsb0JBQW9CLENBQUMsQ0FBQztJQUNqRSxDQUFDO0lBRU8sb0JBQW9CLENBQUMsTUFBVztRQUNwQyxJQUFJLElBQUksQ0FBQyxjQUFjLENBQUMsSUFBSSxJQUFJLFNBQVMsRUFBRTtZQUN2QyxPQUFPLEtBQUssQ0FBQztTQUNoQjthQUFNO1lBQ0gsSUFBSSxTQUFTLEdBQUcsSUFBSSxDQUFDLGVBQWUsQ0FBQyxNQUFNLENBQUMsQ0FBQyxLQUFLLENBQUM7WUFDbkQsSUFBSSxTQUFTLElBQUksU0FBUztnQkFBRSxPQUFPLEtBQUssQ0FBQztpQkFDcEMsSUFBSSxTQUFTLElBQUksSUFBSSxJQUFJLFNBQVMsSUFBSSxFQUFFO2dCQUFFLE9BQU8sSUFBSSxDQUFDOztnQkFDdEQsT0FBTyxLQUFLLENBQUM7U0FDckI7SUFDTCxDQUFDO0lBRUQ7O09BRUc7SUFDSyxhQUFhO1FBQ2pCLHFCQUFxQjtRQUNyQixJQUFJLFVBQVUsR0FBYSxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsU0FBUyxDQUFDLFFBQVEsRUFBRSxJQUFJLENBQUMsTUFBTSxDQUFDLFNBQVMsQ0FBQyxRQUFRLENBQUMsQ0FBQztRQUM1Riw0REFBNEQ7UUFDNUQsSUFBSSxXQUFXLEdBQWEsQ0FBQyxDQUFDLEVBQUUsR0FBRyxDQUFDLENBQUM7UUFDckMsMEJBQTBCO1FBQzFCLElBQUksT0FBTyxHQUFhLElBQUksQ0FBQyxPQUFPLENBQUMsa0JBQWtCLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxTQUFTLENBQUMsR0FBRyxFQUFFLElBQUksQ0FBQyxNQUFNLENBQUMsU0FBUyxDQUFDLEdBQUcsQ0FBQyxDQUFDO1FBQzlHLElBQUksWUFBWSxHQUFXLE9BQU8sQ0FBQyxNQUFNLEdBQUcsQ0FBQyxDQUFDO1FBQzlDLElBQUksV0FBVyxHQUFhLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxFQUFFLE9BQU8sQ0FBQyxZQUFZLENBQUMsQ0FBQyxDQUFDO1FBQ2hFLElBQUksR0FBRyxHQUFHLEVBQUUsQ0FBQyxLQUFLLENBQUMsWUFBWSxDQUFDLENBQUM7UUFDakMsSUFBSSx1QkFBdUIsR0FBMkIsSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxVQUFVLENBQUM7UUFFMUYscUdBQXFHO1FBQ3JHLElBQUksQ0FBQyxtQkFBbUIsR0FBRyxJQUFJLENBQUMsT0FBTyxDQUFDLFFBQVEsQ0FBQyxXQUFXLEVBQUUsVUFBVSxDQUFDLENBQUM7UUFDMUUscUhBQXFIO1FBQ3JILElBQUksQ0FBQyxPQUFPLENBQUMsVUFBVSxHQUFHLElBQUksQ0FBQyxPQUFPLENBQUMsUUFBUSxDQUFDLFdBQVcsRUFBRSxXQUFXLENBQUMsQ0FBQztRQUUxRSxJQUFJLGVBQWUsR0FBRyxFQUFFLENBQUMsTUFBTSxDQUFDLEdBQUcsR0FBRyxJQUFJLENBQUMsTUFBTSxDQUFDLEVBQUUsR0FBRyxvQ0FBb0MsQ0FBQyxDQUFDO1FBRTdGLElBQUksUUFBUSxHQUFHLGVBQWUsQ0FBQyxNQUFNLENBQUMsV0FBVyxDQUFDLENBQUM7UUFDbkQsUUFBUSxDQUFDLEtBQUssQ0FBQyxZQUFZLEVBQUUsa0JBQWtCLEdBQUcsdUJBQXVCLEdBQUcsR0FBRyxHQUFHLFVBQVUsQ0FBQyxDQUFDLENBQUMsR0FBRyxHQUFHLEdBQUcsVUFBVSxDQUFDLENBQUMsQ0FBQyxHQUFHLEdBQUcsQ0FBQyxDQUFDO1FBRTdILElBQUksQ0FBQyxPQUFPLENBQUMsZ0JBQWdCLEdBQUcsZUFBZSxDQUFDLE1BQU0sQ0FBQyx5QkFBeUIsQ0FBQyxDQUFDO1FBRWxGLFFBQVEsQ0FBQyxTQUFTLENBQUMscUJBQXFCLENBQUM7YUFDcEMsSUFBSSxDQUFDLEdBQUcsQ0FBQzthQUNULEtBQUssRUFBRSxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUM7YUFDckIsSUFBSSxDQUFDLE9BQU8sRUFBRSxvQkFBb0IsQ0FBQzthQUNuQyxJQUFJLENBQUMsSUFBSSxFQUFFLENBQUMsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxPQUFPLEdBQUcsQ0FBQyxDQUFDO2FBQzlCLEtBQUssQ0FBQyxPQUFPLEVBQUUsR0FBRyxHQUFHLFlBQVksR0FBRyxHQUFHLENBQUMsQ0FBQztRQUU5QyxlQUFlLENBQUMsTUFBTSxDQUFDLCtCQUErQixDQUFDO2FBQ2xELFNBQVMsQ0FBQyxxQkFBcUIsQ0FBQzthQUNoQyxJQUFJLENBQUMsT0FBTyxDQUFDO2FBQ2IsS0FBSyxFQUFFLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQzthQUNyQixJQUFJLENBQUMsT0FBTyxFQUFFLG9CQUFvQixDQUFDO2FBQ25DLElBQUksQ0FBQyxJQUFJLEVBQUUsQ0FBQyxDQUFDLEVBQUUsRUFBRSxDQUFDLE9BQU8sR0FBRyxDQUFDLENBQUM7YUFDOUIsSUFBSSxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUM7SUFDdEIsQ0FBQztJQUVPLFdBQVc7UUFDZixJQUFJLElBQUksQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLEtBQUssU0FBUztZQUFFLElBQUksQ0FBQyxZQUFZLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxDQUFDO1FBQ2hFLElBQUksV0FBVyxHQUFXLElBQUksQ0FBQyxNQUFNLENBQUMsV0FBVyxDQUFDLEdBQUcsQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsV0FBVyxDQUFDLEdBQUcsQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQztRQUN4SCxJQUFJLENBQUMsWUFBWSxHQUFHLElBQUksQ0FBQyxPQUFPLENBQUMsZUFBZSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsU0FBUyxFQUFFLElBQUksQ0FBQyxXQUFXLEVBQUUsV0FBVyxDQUFDLENBQUM7UUFDckcsSUFBSSxDQUFDLFlBQVksQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLFlBQVksQ0FBQyxhQUFhLENBQUMsQ0FBQztRQUN4RCwrQkFBK0I7UUFDL0IsSUFBSTtJQUNSLENBQUM7SUFFTyxTQUFTO1FBQ2IsSUFBSSxJQUFJLENBQUMsTUFBTTtZQUFFLElBQUksQ0FBQyxNQUFNLENBQUMsTUFBTSxFQUFFLENBQUM7UUFDdEMsSUFBSSxJQUFJLENBQUMsU0FBUyxDQUFDLFdBQVcsQ0FBQyxHQUFHLENBQUMsSUFBSTtZQUFFLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLFdBQVcsQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLENBQUM7UUFDcEcsSUFBSSxDQUFDLE1BQU0sR0FBRyxDQUFDLENBQUMsU0FBUyxDQUFDLG9EQUFvRCxFQUFFO1lBQzVFLFdBQVcsRUFBRSwyRUFBMkU7WUFDeEYsT0FBTyxFQUFFLEVBQUU7U0FDZCxDQUFDLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxXQUFXLENBQUMsQ0FBQztRQUMzQixJQUFJLENBQUMsbUJBQW1CLEVBQUUsQ0FBQztJQUMvQixDQUFDO0lBRU8sZ0JBQWdCLENBQUMsT0FBWTtRQUNqQyxJQUFJLE9BQU8sSUFBSSxDQUFDLFdBQVcsS0FBSyxXQUFXLEVBQUU7WUFDekMsT0FBTyxDQUFDLFlBQVksQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxVQUFVLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxhQUFhLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxXQUFXLENBQUMsQ0FBQztZQUNoSixPQUFPLENBQUMsWUFBWSxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFDLGVBQWUsQ0FBQyxNQUFNLEVBQUUsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxlQUFlLENBQUMsT0FBTyxFQUFFLENBQUM7WUFDOUcsT0FBTyxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxTQUFTLENBQUMsTUFBTSxFQUFFLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxXQUFXLENBQUMsU0FBUyxDQUFDLE9BQU8sRUFBRSxDQUFDO1lBQ2pHLE9BQU8sQ0FBQyxpQkFBaUIsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxlQUFlLENBQUMsTUFBTSxFQUFFLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxXQUFXLENBQUMsZUFBZSxDQUFDLE9BQU8sRUFBRSxDQUFDO1NBQ3RIO0lBQ0wsQ0FBQztJQUVPLHlCQUF5QixDQUFDLFlBQW9CO1FBQ2xELElBQUksa0JBQWtCLEdBQVksUUFBUSxDQUFDLGFBQWEsQ0FBQyw4QkFBOEIsQ0FBQyxDQUFDO1FBQ3pGLElBQUksa0JBQWtCLEtBQUssSUFBSSxFQUFFO1lBQzdCLElBQUkscUJBQXFCLEdBQWdCLElBQUksQ0FBQyxPQUFPLENBQUMsYUFBYSxDQUFDLGtCQUFrQixFQUFFLG9CQUFvQixDQUFDLENBQUM7WUFDOUcscUJBQXFCLENBQUMsU0FBUyxHQUFHLFlBQVksSUFBSSxVQUFVLENBQUM7WUFDN0Qsa0JBQWtCLENBQUMsWUFBWSxDQUFDLHFCQUFxQixFQUFFLGtCQUFrQixDQUFDLFVBQVUsQ0FBQyxDQUFDO1NBQ3pGO0lBQ0wsQ0FBQztJQUVPLG1CQUFtQjtRQUN2QixvRUFBb0U7UUFDcEUsSUFBSSxDQUFDLE1BQU0sQ0FBQyxFQUFFLENBQUMsV0FBVyxFQUFFLENBQUMsS0FBSyxFQUFRLEVBQUU7WUFDeEMsc0RBQXNEO1lBQ3RELElBQUksQ0FBQyxJQUFJLENBQUMsYUFBYSxFQUFFO2dCQUNyQixJQUFJLENBQUMsYUFBYSxHQUFHLElBQUksQ0FBQztnQkFDMUIsSUFBSSxDQUFDLGlCQUFpQixFQUFFLENBQUM7Z0JBQ3pCLElBQUksSUFBSSxDQUFDLGlCQUFpQixHQUFHLENBQUMsSUFBSSxJQUFJLENBQUMsaUJBQWlCLEtBQUssQ0FBQyxFQUFFO29CQUM1RCxJQUFJLENBQUMsU0FBUyxFQUFFLENBQUM7aUJBQ3BCO2dCQUNELElBQUksSUFBSSxDQUFDLGlCQUFpQixHQUFHLENBQUMsRUFBRTtvQkFDNUIsMkJBQTJCO29CQUMzQixnSUFBZ0k7aUJBQ25JO2FBQ0o7UUFDTCxDQUFDLENBQUMsQ0FBQztRQUVILHVFQUF1RTtRQUN2RSxJQUFJLENBQUMsTUFBTSxDQUFDLEVBQUUsQ0FBQyxVQUFVLEVBQUUsR0FBUyxFQUFFO1lBQ2xDLElBQUksQ0FBQyxjQUFjLEVBQUUsQ0FBQztZQUN0QixJQUFJLElBQUksQ0FBQyxjQUFjLEtBQUssTUFBTSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxDQUFDLE1BQU0sRUFBRTtnQkFDaEUsK0RBQStEO2dCQUMvRCwrQkFBK0I7Z0JBQy9CLDhCQUE4QjtnQkFDOUIsSUFBSSxDQUFDLFdBQVcsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLENBQUM7Z0JBRTdCLGlCQUFpQjtnQkFDakIsOEJBQThCO2dCQUM5QixJQUFJLENBQUMsY0FBYyxHQUFHLENBQUMsQ0FBQzthQUMzQjtRQUNMLENBQUMsQ0FBQyxDQUFDO0lBQ1AsQ0FBQztJQUVPLGlCQUFpQixDQUFDLE9BQWU7UUFDckMsT0FBTyxJQUFJLENBQUMsY0FBYyxDQUFDLGNBQWMsQ0FBQyxPQUFPLENBQUMsQ0FBQztJQUN2RCxDQUFDOzs7WUF2OUJKLFNBQVMsU0FBQztnQkFDUCxRQUFRLEVBQUUsY0FBYztnQkFDeEIsUUFBUSxFQUFFOzs7S0FHVDtnQkFDRCxhQUFhLEVBQUUsaUJBQWlCLENBQUMsSUFBSTtnQkFDckMsU0FBUyxFQUFFLENBQUMsV0FBVyxFQUFFLFlBQVksRUFBRSxhQUFhLENBQUM7Z0JBQ3JELElBQUksRUFBRTtvQkFDRixPQUFPLEVBQUUsZUFBZTtpQkFFM0I7YUFDSjs7O1lBekJHLFVBQVU7WUFJTCxXQUFXO1lBQ1gsWUFBWTtZQUNaLGFBQWE7OzttQkFnRGpCLEtBQUs7d0JBQ0wsS0FBSyxTQUFDLFFBQVE7cUJBQ2QsS0FBSztrQkFDTCxLQUFLOzJCQUNMLE1BQU07eUJBQ04sTUFBTTsyQkFDTixNQUFNOzBCQUNOLE1BQU0iLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQge1xyXG4gICAgQ29tcG9uZW50LFxyXG4gICAgVmlld0VuY2Fwc3VsYXRpb24sXHJcbiAgICBJbnB1dCxcclxuICAgIE91dHB1dCxcclxuICAgIEV2ZW50RW1pdHRlcixcclxuICAgIE9uSW5pdCxcclxuICAgIE9uQ2hhbmdlcyxcclxuICAgIFNpbXBsZUNoYW5nZXMsXHJcbiAgICBPbkRlc3Ryb3ksXHJcbiAgICBFbGVtZW50UmVmLFxyXG4gICAgQWZ0ZXJWaWV3SW5pdFxyXG59IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xyXG5pbXBvcnQgeyBLZENoYXJ0QmFzZUNsYXNzIH0gZnJvbSAnLi4va2QtYW5ndWxhci1jaGFydC1iYXNlLWNsYXNzJztcclxuaW1wb3J0IHsgS2RDaGFydHNTdmMgfSBmcm9tICcuLi9rZC1hbmd1bGFyLWNoYXJ0cy1zdmMnO1xyXG5pbXBvcnQgeyBLZERvbUVsZW1TdmMgfSBmcm9tICcuLi8uLi9rZC1jb21tb24vaW5kZXgnO1xyXG5pbXBvcnQgeyBLZE1hcENoYXJ0U3ZjIH0gZnJvbSAnLi9rZC1hbmd1bGFyLW1hcC1jaGFydC1zdmMnO1xyXG5pbXBvcnQgeyBJTGVnZW5kRGF0YSwgSUNoYXJ0Q29uZmlnIH0gZnJvbSAnLi4va2QtYW5ndWxhci1jaGFydHMtaW50ZXJmYWNlJztcclxuaW1wb3J0ICogYXMgZDMgZnJvbSAnZDMnO1xyXG5pbXBvcnQgKiBhcyBMIGZyb20gJ2xlYWZsZXQnO1xyXG5pbXBvcnQgJ2xlYWZsZXQubWFya2VyY2x1c3Rlcic7XHJcbmltcG9ydCAnbGVhZmxldC5hd2Vzb21lLW1hcmtlcnMvZGlzdC9sZWFmbGV0LmF3ZXNvbWUtbWFya2Vycyc7XHJcblxyXG5AQ29tcG9uZW50KHtcclxuICAgIHNlbGVjdG9yOiAna2QtbWFwLWNoYXJ0JyxcclxuICAgIHRlbXBsYXRlOiBgXHJcbiAgICAgICAgPGRpdj5cclxuICAgICAgICA8L2Rpdj5cclxuICAgIGAsXHJcbiAgICBlbmNhcHN1bGF0aW9uOiBWaWV3RW5jYXBzdWxhdGlvbi5Ob25lLFxyXG4gICAgcHJvdmlkZXJzOiBbS2RDaGFydHNTdmMsIEtkRG9tRWxlbVN2YywgS2RNYXBDaGFydFN2Y10sXHJcbiAgICBob3N0OiB7XHJcbiAgICAgICAgJ2NsYXNzJzogJ2tkeC1tYXAtY2hhcnQnLFxyXG4gICAgICAgIC8vICdbYXR0ci5pZF0nOiAnY29uZmlnLmlkJyxcclxuICAgIH1cclxufSlcclxuXHJcbmV4cG9ydCBjbGFzcyBLZE1hcENoYXJ0IGV4dGVuZHMgS2RDaGFydEJhc2VDbGFzcyBpbXBsZW1lbnRzIE9uSW5pdCwgT25DaGFuZ2VzLCBBZnRlclZpZXdJbml0LCBPbkRlc3Ryb3kge1xyXG4gICAgcHJpdmF0ZSBfZnVsbEdyYXBoOiBhbnk7XHJcbiAgICBwcml2YXRlIF9tYXBQYXRoOiBhbnk7XHJcbiAgICBwcml2YXRlIF9wYXRoOiBhbnk7XHJcbiAgICBwcml2YXRlIF96b29tQnRuczogYW55O1xyXG4gICAgcHJpdmF0ZSBfYmFja0J0bjogYW55O1xyXG4gICAgcHJpdmF0ZSBfbWFwTGF5ZXI6IGFueTtcclxuICAgIHByaXZhdGUgX2xldmVsOiBhbnk7XHJcbiAgICBwcml2YXRlIF9kZWZhdWx0TGV2ZWw6IGFueTtcclxuICAgIHByaXZhdGUgX2hlaWdodDogbnVtYmVyO1xyXG4gICAgcHJpdmF0ZSBfd2lkdGg6IG51bWJlcjtcclxuICAgIHByaXZhdGUgX2xlYWZsZXRNYXA6IEwuTWFwO1xyXG4gICAgcHJpdmF0ZSBfbGF5ZXI6IGFueTtcclxuICAgIHByaXZhdGUgX2NsdXN0ZXJEYXRhOiBhbnk7XHJcbiAgICBwcml2YXRlIF9zZXJpZXNQb2ludGVyOiBhbnk7XHJcbiAgICBwcml2YXRlIF9jb2xvclBvaW50ZXI6IGFueTtcclxuICAgIHByaXZhdGUgX21hcFNjYWxlQ29sb3JTY2FsZTogYW55O1xyXG4gICAgcHJpdmF0ZSBfb3V0cHV0U2VyaWVzRGF0YTogQXJyYXk8eyAnbmFtZSc6IHN0cmluZywgJ3ZhbHVlJzogc3RyaW5nLCAnaWQnOiBzdHJpbmcgfT4gPSBbXTtcclxuICAgIHByaXZhdGUgX3Nlcmllc0RhdGE6IEFycmF5PGFueT4gPSBbXTtcclxuICAgIHByaXZhdGUgX2VtcHR5U2VyaWVzOiBib29sZWFuID0gZmFsc2U7XHJcbiAgICBwcml2YXRlIF9zaW5nbGVMZXZlbERpbWVuc2lvbjogYm9vbGVhbiA9IGZhbHNlO1xyXG4gICAgcHJpdmF0ZSBfdGlsZWxvYWRJbmRleDogbnVtYmVyID0gMDtcclxuICAgIHByaXZhdGUgX2lzTGF5ZXJFcnJvcjogYm9vbGVhbiA9IGZhbHNlO1xyXG4gICAgcHJpdmF0ZSBfbGF5ZXJSZWxvYWRUaW1lczogbnVtYmVyID0gMDtcclxuICAgIHByaXZhdGUgX2lzTWFwU2VsZWN0ZWQ6IGFueSA9IHt9O1xyXG5cclxuXHJcbiAgICBASW5wdXQoKSBkYXRhOiBhbnk7XHJcbiAgICBASW5wdXQoJ2NvbmZpZycpIG1hcENvbmZpZzogSUNoYXJ0Q29uZmlnO1xyXG4gICAgQElucHV0KCkgbGVnZW5kOiB7IFtrZXk6IHN0cmluZ106IElMZWdlbmREYXRhIH07XHJcbiAgICBASW5wdXQoKSBhcGk6IGFueTtcclxuICAgIEBPdXRwdXQoKSBvdXRwdXRMZWdlbmQ6IEV2ZW50RW1pdHRlcjx7IFtrZXk6IHN0cmluZ106IElMZWdlbmREYXRhIH0+ID0gbmV3IEV2ZW50RW1pdHRlcih0cnVlKTtcclxuICAgIEBPdXRwdXQoKSBvdXRwdXREYXRhOiBFdmVudEVtaXR0ZXI8YW55PiA9IG5ldyBFdmVudEVtaXR0ZXIodHJ1ZSk7XHJcbiAgICBAT3V0cHV0KCkgb3V0cHV0TWFya2VyOiBFdmVudEVtaXR0ZXI8YW55PiA9IG5ldyBFdmVudEVtaXR0ZXIodHJ1ZSk7XHJcbiAgICBAT3V0cHV0KCkgb3V0cHV0UmVhZHk6IEV2ZW50RW1pdHRlcjxhbnk+ID0gbmV3IEV2ZW50RW1pdHRlcih0cnVlKTtcclxuXHJcbiAgICBjb25zdHJ1Y3RvcihcclxuICAgICAgICBwcml2YXRlIF9lbGVtZW50UmVmOiBFbGVtZW50UmVmLFxyXG4gICAgICAgIHB1YmxpYyBfY2hhcnRTdmM6IEtkQ2hhcnRzU3ZjLFxyXG4gICAgICAgIHB1YmxpYyBfZG9tU3ZjOiBLZERvbUVsZW1TdmMsXHJcbiAgICAgICAgcHJpdmF0ZSBfbWFwU3ZjOiBLZE1hcENoYXJ0U3ZjXHJcbiAgICApIHtcclxuICAgICAgICBzdXBlcihfY2hhcnRTdmMsIF9kb21TdmMpO1xyXG4gICAgfVxyXG5cclxuICAgIG5nT25Jbml0KCk6IHZvaWQge1xyXG4gICAgICAgIHRoaXMuY29uZmlnID0gT2JqZWN0LmFzc2lnbih7fSwgdGhpcy5tYXBDb25maWcpO1xyXG4gICAgICAgIHRoaXMubGVnZW5kRGF0YSA9IE9iamVjdC5hc3NpZ24oe30sIHRoaXMubGVnZW5kKTtcclxuICAgICAgICB0aGlzLl9zZXREYXRhKCk7XHJcbiAgICAgICAgc3VwZXIuY2hhcnRUaW1lb3V0KCgpID0+IHRoaXMuX3NldENoYXJ0KCkpO1xyXG4gICAgICAgIHRoaXMuYXBpLnJlZHJhdyA9ICgpID0+IHtcclxuICAgICAgICAgICAgc2V0VGltZW91dCgoKSA9PiB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLl9vdmVyV3JpdGVTZXJpZXMoKTtcclxuICAgICAgICAgICAgICAgIHRoaXMuX3Jlc2V0Q2hhcnQoKTtcclxuICAgICAgICAgICAgICAgIHRoaXMuX3NldENoYXJ0KCk7XHJcbiAgICAgICAgICAgICAgICAvLyBpZiAoIXRoaXMuY29uZmlnLnNraXBNYXNzYWdlKSB7XHJcbiAgICAgICAgICAgICAgICAvLyAgICAgdGhpcy5sZWdlbmQgPSB0aGlzLl9jaGFydFN2Yy5zZXRNYXBMZWdlbmREYXRhKHRoaXMubGVnZW5kLCB0aGlzLl9zZXJpZXNEYXRhLCB0aGlzLmNvbmZpZyk7XHJcbiAgICAgICAgICAgICAgICAvLyB9XHJcbiAgICAgICAgICAgICAgICB0aGlzLl9nZXRMZWdlbmRCeVR5cGUoKTtcclxuICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgfTtcclxuICAgICAgICB0aGlzLmFwaS5sZWdlbmRDbGljayA9IChfaWQ6IGFueSwgX2xlZ2VuZEFjdGl2ZSkgPT4ge1xyXG4gICAgICAgICAgICB0aGlzLmxlZ2VuZFtfaWRdLmRlYWN0aXZlID0gX2xlZ2VuZEFjdGl2ZTtcclxuICAgICAgICAgICAgZm9yIChsZXQgaSA9IDA7IGkgPCB0aGlzLl9zZXJpZXNEYXRhLmxlbmd0aDsgaSsrKSB7XHJcbiAgICAgICAgICAgICAgICBpZiAodGhpcy5fc2VyaWVzRGF0YVtpXS5pZCAmJiB0aGlzLl9zZXJpZXNEYXRhW2ldLmlkID09IHRoaXMubGVnZW5kW19pZF0ubWFwU2VyaWVzSWQpIHtcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLl9zZXJpZXNEYXRhW2ldLmRlYWN0aXZlID0gX2xlZ2VuZEFjdGl2ZTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB0aGlzLmRhdGFbJ21hcFNlcmllc0RhdGEnXSA9IHRoaXMuX3Nlcmllc0RhdGE7XHJcbiAgICAgICAgICAgIGlmICh0aGlzLl9zaW5nbGVMZXZlbERpbWVuc2lvbiA9PSBmYWxzZSkgdGhpcy5fZ2V0TmV3U2VyaWVzKCk7XHJcbiAgICAgICAgICAgIHRoaXMuX3Jlc2V0Q2hhcnQoKTtcclxuICAgICAgICAgICAgdGhpcy5fc2V0Q2hhcnQoKTtcclxuICAgICAgICB9O1xyXG4gICAgICAgIHRoaXMuYXBpLmNsdXN0ZXJDbGljayA9IChfaWQ6IGFueSwgX2xlZ2VuZEl0ZW06IHsgJ2xlZ2VuZEl0ZW1NYXJrZXInOiBIVE1MRWxlbWVudCwgJ2xlZ2VuZEl0ZW1MYWJlbCc6IEhUTUxFbGVtZW50IH0pID0+IHtcclxuICAgICAgICAgICAgbGV0IHNlbGVjdGVkTWFya2VyR3JvdXA6IEwuTWFya2VyQ2x1c3Rlckdyb3VwIHwgTC5tYXJrZXI7XHJcbiAgICAgICAgICAgIHNlbGVjdGVkTWFya2VyR3JvdXAgPSB0aGlzLl9jbHVzdGVyRGF0YS5jbHVzdGVyTWFya2Vyc1tfaWQuaWRdO1xyXG5cclxuICAgICAgICAgICAgaWYgKHRoaXMuX2xlYWZsZXRNYXAuaGFzTGF5ZXIoc2VsZWN0ZWRNYXJrZXJHcm91cCkpIHtcclxuICAgICAgICAgICAgICAgIHRoaXMuX2xlYWZsZXRNYXAucmVtb3ZlTGF5ZXIoc2VsZWN0ZWRNYXJrZXJHcm91cCk7XHJcbiAgICAgICAgICAgICAgICB0aGlzLl9kb21TdmMuYWRkQ2xhc3MoX2xlZ2VuZEl0ZW0ubGVnZW5kSXRlbU1hcmtlciwgJ2F3ZXNvbWUtbWFya2VyLWljb24tbGlnaHRncmF5Jyk7XHJcbiAgICAgICAgICAgICAgICB0aGlzLl9kb21TdmMuYWRkQ2xhc3MoX2xlZ2VuZEl0ZW0ubGVnZW5kSXRlbUxhYmVsLCAna2R4LWxhYmVsLWxpZ2h0Z3JheScpO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5fbGVhZmxldE1hcC5hZGRMYXllcihzZWxlY3RlZE1hcmtlckdyb3VwKTtcclxuICAgICAgICAgICAgICAgIHRoaXMuX2RvbVN2Yy5yZW1vdmVDbGFzcyhfbGVnZW5kSXRlbS5sZWdlbmRJdGVtTWFya2VyLCAnYXdlc29tZS1tYXJrZXItaWNvbi1saWdodGdyYXknKTtcclxuICAgICAgICAgICAgICAgIHRoaXMuX2RvbVN2Yy5yZW1vdmVDbGFzcyhfbGVnZW5kSXRlbS5sZWdlbmRJdGVtTGFiZWwsICdrZHgtbGFiZWwtbGlnaHRncmF5Jyk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgbmdPbkNoYW5nZXMoX3NpbXBsZUNoYW5nZXM6IFNpbXBsZUNoYW5nZXMpOiB2b2lkIHtcclxuICAgICAgICBpZiAoX3NpbXBsZUNoYW5nZXMuaGFzT3duUHJvcGVydHkoJ2RhdGEnKSAmJiAhX3NpbXBsZUNoYW5nZXNbJ2RhdGEnXS5maXJzdENoYW5nZSkge1xyXG4gICAgICAgICAgICB0aGlzLmRhdGEgPSBfc2ltcGxlQ2hhbmdlcy5kYXRhLmN1cnJlbnRWYWx1ZTtcclxuICAgICAgICAgICAgdGhpcy5fcmVkcmF3Q2hhcnQoJ2RhdGEnKTtcclxuICAgICAgICB9XHJcbiAgICAgICAgaWYgKF9zaW1wbGVDaGFuZ2VzLmhhc093blByb3BlcnR5KCdtYXBDb25maWcnKSAmJiAhX3NpbXBsZUNoYW5nZXNbJ21hcENvbmZpZyddLmZpcnN0Q2hhbmdlKSB7XHJcbiAgICAgICAgICAgIGlmICh0aGlzLm1hcENvbmZpZy5wbG90T3B0aW9ucy5tYXAuem9vbSkge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5fY2hlY2tab29tQ29uZmlnKHRoaXMubWFwQ29uZmlnLnBsb3RPcHRpb25zLm1hcC56b29tKTtcclxuICAgICAgICAgICAgICAgIGlmICh0aGlzLm1hcENvbmZpZy5wbG90T3B0aW9ucy5tYXAuem9vbS52YWx1ZSkge1xyXG4gICAgICAgICAgICAgICAgICAgIGlmICh0eXBlb2YgdGhpcy5fbGVhZmxldE1hcCAhPT0gJ3VuZGVmaW5lZCcpIHRoaXMuX2xlYWZsZXRNYXAuc2V0Wm9vbSh0aGlzLm1hcENvbmZpZy5wbG90T3B0aW9ucy5tYXAuem9vbS52YWx1ZSk7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAvLyBuZWVkIHRvIGNoZWNrIHdoeSBsZWdlbmQga2VlcCBnb25lXHJcbiAgICAgICAgICAgICAgICAvLyBpZiAodGhpcy5jaGFydFR5cGVbMV0gPT09ICdmdWxsJyB8fCB0aGlzLmNoYXJ0VHlwZVsxXSA9PT0gJ2NsdXN0ZXInKSB0aGlzLl9zZXRNYXJrZXJzKCk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgdGhpcy5tYXBDb25maWcgPSBfc2ltcGxlQ2hhbmdlcy5tYXBDb25maWcuY3VycmVudFZhbHVlO1xyXG4gICAgICAgICAgICB0aGlzLl9yZWRyYXdDaGFydCgnY29uZmlnJyk7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIG5nQWZ0ZXJWaWV3SW5pdCgpIHtcclxuICAgICAgICBpZiAodHlwZW9mIHRoaXMuX2xlYWZsZXRNYXAgIT09ICd1bmRlZmluZWQnKSB0aGlzLl9sZWFmbGV0TWFwLmludmFsaWRhdGVTaXplKHt9KTtcclxuICAgIH1cclxuXHJcbiAgICBuZ09uRGVzdHJveSgpOiB2b2lkIHtcclxuICAgICAgICB0aGlzLl9yZXNldENoYXJ0KCk7XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfcmVkcmF3Q2hhcnQoX2NoYW5nZXM/OiAnZGF0YScgfCAnY29uZmlnJykge1xyXG4gICAgICAgIHRoaXMuX3Jlc2V0Q2hhcnQoKTtcclxuXHJcbiAgICAgICAgaWYgKF9jaGFuZ2VzID09PSAnZGF0YScpIHtcclxuICAgICAgICAgICAgdGhpcy5fc2VyaWVzRGF0YSA9IFtdO1xyXG4gICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgIHRoaXMuY29uZmlnID0gT2JqZWN0LmFzc2lnbih7fSwgdGhpcy5tYXBDb25maWcpO1xyXG4gICAgICAgIH1cclxuICAgICAgICB0aGlzLmxlZ2VuZERhdGEgPSBPYmplY3QuYXNzaWduKHt9LCB0aGlzLmxlZ2VuZCk7XHJcblxyXG4gICAgICAgIHRoaXMuX3NldERhdGEoKTtcclxuICAgICAgICBzdXBlci5jaGFydFRpbWVvdXQoKCkgPT4gdGhpcy5fc2V0Q2hhcnQoKSk7XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfc2V0Q2hhcnQoKTogdm9pZCB7XHJcbiAgICAgICAgdGhpcy5jaGFydFR5cGUgPSB0aGlzLmRhdGEuY2hhcnQubGF5b3V0LnNwbGl0KCctJyk7XHJcbiAgICAgICAgaWYgKHRoaXMuX2xldmVsICE9PSB1bmRlZmluZWQgJiYgdGhpcy5fbGV2ZWwgIT09IG51bGwpIHtcclxuICAgICAgICB9IGVsc2UgaWYgKCh0aGlzLmRhdGFbJ21hcExldmVsJ10gJiYgdGhpcy5jb25maWcuc2tpcE1hc3NhZ2UpIHx8ICh0aGlzLmRhdGFbJ21hcExldmVsJ10gJiYgdGhpcy5fc2luZ2xlTGV2ZWxEaW1lbnNpb24gPT0gdHJ1ZSkpIHtcclxuICAgICAgICAgICAgLy8gaWYgKCh0aGlzLmRhdGFbJ21hcExldmVsJ10gJiYgdGhpcy5jb25maWcuc2tpcE1hc3NhZ2UpIHx8ICh0aGlzLmRhdGFbJ21hcExldmVsJ10gJiYgdGhpcy5fc2luZ2xlTGV2ZWxEaW1lbnNpb24gPT0gdHJ1ZSkpIHtcclxuICAgICAgICAgICAgbGV0IHRtcExldmVsQXJyOiBBcnJheTxzdHJpbmc+ID0gT2JqZWN0LmtleXModGhpcy5kYXRhLm1hcERhdGEpO1xyXG4gICAgICAgICAgICB0aGlzLl9kZWZhdWx0TGV2ZWwgPSB0bXBMZXZlbEFyci5sZW5ndGggPiAwID8gdG1wTGV2ZWxBcnJbMF0gOiB0aGlzLmRhdGFbJ21hcExldmVsJ107XHJcbiAgICAgICAgICAgIHRoaXMuX2xldmVsID0gdGhpcy5kYXRhWydtYXBMZXZlbCddO1xyXG4gICAgICAgICAgICAvLyBjaGVja2luZyBpZiBtYXAgZ290IGFyZWEgZmlsdGVyXHJcbiAgICAgICAgfSBlbHNlIGlmICh0aGlzLmRhdGEuc2VyaWVzW3RoaXMuZGF0YS5zZXJpZXMubGVuZ3RoIC0gMV0uZGF0YSAmJiB0aGlzLmRhdGEuc2VyaWVzW3RoaXMuZGF0YS5zZXJpZXMubGVuZ3RoIC0gMV0uZGF0YS5sZW5ndGggPT0gMSkge1xyXG4gICAgICAgICAgICB0aGlzLl9kZWZhdWx0TGV2ZWwgPSB0aGlzLl9tYXBTdmMuZ2V0TWFwTGV2ZWxXaXRoQXJlYUZpbHRlcih0aGlzLmRhdGEuc2VyaWVzW3RoaXMuZGF0YS5zZXJpZXMubGVuZ3RoIC0gMV0uZGF0YVswXS5JRF8sIHRoaXMuZGF0YS5tYXBEYXRhKTtcclxuICAgICAgICAgICAgdGhpcy5fbGV2ZWwgPSB0aGlzLl9kZWZhdWx0TGV2ZWw7XHJcbiAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgbGV0IHRtcExldmVsQXJyOiBBcnJheTxzdHJpbmc+ID0gT2JqZWN0LmtleXModGhpcy5kYXRhLm1hcERhdGEpO1xyXG4gICAgICAgICAgICB0aGlzLl9kZWZhdWx0TGV2ZWwgPSB0bXBMZXZlbEFyci5sZW5ndGggPiAwID8gdG1wTGV2ZWxBcnJbMF0gOiAnbF8xJztcclxuICAgICAgICAgICAgdGhpcy5fbGV2ZWwgPSB0aGlzLl9kZWZhdWx0TGV2ZWw7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIHRoaXMuX2dldENvbG9yUG9pbnRlcigpO1xyXG5cclxuICAgICAgICAvLyBpbnN0ZWFkIG9mIGxlZ2VuZCwgZHJhdyB0aGUgbWFwIGNvbG9yIHNjYWxlLiBtdXN0IGJlIGNvbXBsZXRlZCBiZWZvcmUgc3ZnIGRpbWVuc2lvbiBpcyBmaXhlZFxyXG4gICAgICAgIGlmICh0aGlzLmNvbmZpZy5jb2xvckF4aXMgIT0gdW5kZWZpbmVkICYmIHRoaXMuY29uZmlnLmNvbG9yQXhpcy5kYXRhQ2xhc3NlcyA9PSB1bmRlZmluZWQpIHtcclxuICAgICAgICAgICAgdGhpcy5fZHJhd01hcFNjYWxlKCk7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIHN1cGVyLnNldFN2ZygpO1xyXG4gICAgICAgIHN1cGVyLnNldFN2Z0RpbWVuc2lvbigneCcpO1xyXG4gICAgICAgIHN1cGVyLnNldFN2Z0RpbWVuc2lvbigneScpO1xyXG5cclxuICAgICAgICB0aGlzLl9oZWlnaHQgPSB0aGlzLnN2Z0NvbnRhaW5lci5ub2RlKCkuZ2V0Qm91bmRpbmdDbGllbnRSZWN0KCkuaGVpZ2h0O1xyXG4gICAgICAgIHRoaXMuX3dpZHRoID0gdGhpcy5zdmdDb250YWluZXIubm9kZSgpLmdldEJvdW5kaW5nQ2xpZW50UmVjdCgpLndpZHRoO1xyXG5cclxuICAgICAgICBpZiAodGhpcy5jaGFydFR5cGVbMV0gPT09ICdwb2x5Z29uJyB8fCB0aGlzLmNoYXJ0VHlwZVsxXSA9PT0gJ3RoZW1hdGljJykge1xyXG4gICAgICAgICAgICB0aGlzLl9kcmF3UG9seWdvbk1hcCgpO1xyXG4gICAgICAgIH0gZWxzZSBpZiAodGhpcy5jaGFydFR5cGVbMV0gPT09ICdmdWxsJyB8fCB0aGlzLmNoYXJ0VHlwZVsxXSA9PT0gJ2NsdXN0ZXInIHx8IHRoaXMuY2hhcnRUeXBlWzFdID09PSAnZmlsdGVyJykge1xyXG4gICAgICAgICAgICB0aGlzLl9kcmF3TGVhZnRsZXQoKTtcclxuICAgICAgICAgICAgc2V0VGltZW91dCgoKSA9PiB7XHJcbiAgICAgICAgICAgICAgICBpZiAodHlwZW9mIHRoaXMuX2xlYWZsZXRNYXAgIT09ICd1bmRlZmluZWQnKSB0aGlzLl9sZWFmbGV0TWFwLmludmFsaWRhdGVTaXplKHt9KTtcclxuICAgICAgICAgICAgfSlcclxuICAgICAgICAgICAgaWYgKHRoaXMuY2hhcnRUeXBlWzFdICE9PSAnY2x1c3RlcicpIHRoaXMuX2RyYXdGdWxsTWFwKCk7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIC8vIGNvbnNvbGUubG9nKCdkYXRhICcsIHRoaXMuZGF0YSlcclxuICAgICAgICAvLyBjb25zb2xlLmxvZygnY29uZmlnICcsIHRoaXMuY29uZmlnKVxyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX3NldERhdGEoKTogdm9pZCB7XHJcbiAgICAgICAgdGhpcy5jaGFydENhdGVnb3J5ID0gJ21hcCc7XHJcbiAgICAgICAgaWYgKHRoaXMuZGF0YVsnbWFwU2VyaWVzRGF0YSddICYmIHRoaXMuY29uZmlnLnNraXBNYXNzYWdlKSB7XHJcbiAgICAgICAgICAgIC8vIGV4cG9ydCBtb2RlXHJcbiAgICAgICAgICAgIHRoaXMuX3Nlcmllc0RhdGEgPSBKU09OLnBhcnNlKEpTT04uc3RyaW5naWZ5KHRoaXMuZGF0YVsnbWFwU2VyaWVzRGF0YSddKSk7XHJcbiAgICAgICAgICAgIGlmICh0aGlzLmNvbmZpZy5jb2xvckF4aXMgIT0gdW5kZWZpbmVkKSB7XHJcbiAgICAgICAgICAgICAgICAvLyBzaW5nbGUgZGltZW5zaW9uXHJcbiAgICAgICAgICAgICAgICB0aGlzLl9zZXJpZXNQb2ludGVyID0gdGhpcy5fbWFwU3ZjLmdldFNlcmllc1BvaW50ZXIodGhpcy5fc2VyaWVzRGF0YSk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgZWxzZSB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLl9nZXROZXdTZXJpZXMoKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgIHRoaXMuX3Nlcmllc0RhdGEgPSBKU09OLnBhcnNlKEpTT04uc3RyaW5naWZ5KHRoaXMuZGF0YS5zZXJpZXMpKTtcclxuICAgICAgICAgICAgZm9yIChsZXQgaSA9IDA7IGkgPCB0aGlzLl9zZXJpZXNEYXRhLmxlbmd0aDsgaSsrKSB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLl9zZXJpZXNEYXRhW2ldWydkZWFjdGl2ZSddID0gZmFsc2U7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgaWYgKHRoaXMuY29uZmlnLmNvbG9yQXhpcyAhPSB1bmRlZmluZWQpIHtcclxuICAgICAgICAgICAgICAgIC8vIHNpbmdsZSBkaW1lbnNpb25cclxuICAgICAgICAgICAgICAgIHRoaXMuX3Nlcmllc1BvaW50ZXIgPSB0aGlzLl9tYXBTdmMuZ2V0U2VyaWVzUG9pbnRlcih0aGlzLl9zZXJpZXNEYXRhKTtcclxuICAgICAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgICAgIC8vIG11bHRpIGRpbWVuc2lvblxyXG4gICAgICAgICAgICAgICAgaWYgKHRoaXMuX3Nlcmllc0RhdGEgJiYgdGhpcy5fc2VyaWVzRGF0YS5sZW5ndGggIT0gMCkge1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuX3Nlcmllc1BvaW50ZXIgPSB0aGlzLl9zZXJpZXNEYXRhW3RoaXMuX3Nlcmllc0RhdGEubGVuZ3RoIC0gMV07XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgdGhpcy5fZW1wdHlTZXJpZXMgPSB0aGlzLl9zZXJpZXNQb2ludGVyID09IHVuZGVmaW5lZCA/IHRydWUgOiBmYWxzZTtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIC8vIGlmICghdGhpcy5jb25maWcuc2tpcE1hc3NhZ2UpIHtcclxuICAgICAgICAvLyAgICAgdGhpcy5sZWdlbmQgPSB0aGlzLl9jaGFydFN2Yy5zZXRNYXBMZWdlbmREYXRhKHRoaXMubGVnZW5kLCB0aGlzLl9zZXJpZXNEYXRhLCB0aGlzLmNvbmZpZyk7XHJcbiAgICAgICAgLy8gfVxyXG4gICAgICAgIHRoaXMuX2dldENvbG9yUG9pbnRlcigpO1xyXG4gICAgICAgIHRoaXMuX2dldExlZ2VuZEJ5VHlwZSgpO1xyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX3Jlc2V0Q2hhcnQoKTogdm9pZCB7XHJcbiAgICAgICAgaWYgKHR5cGVvZiB0aGlzLl96b29tQnRucyAhPT0gJ3VuZGVmaW5lZCcpIHtcclxuICAgICAgICAgICAgdGhpcy5fem9vbUJ0bnMucmVtb3ZlKCk7XHJcbiAgICAgICAgICAgIHRoaXMuX3pvb21CdG5zID0gdW5kZWZpbmVkO1xyXG4gICAgICAgIH1cclxuICAgICAgICBpZiAodGhpcy5fbGVhZmxldE1hcCAhPT0gdW5kZWZpbmVkICYmIHRoaXMuX2xlYWZsZXRNYXAgIT09IG51bGwgJiYgIXRoaXMuY29uZmlnLnNraXBNYXNzYWdlKSB7XHJcbiAgICAgICAgICAgIHRoaXMuX2xlYWZsZXRNYXAucmVtb3ZlKCk7XHJcbiAgICAgICAgICAgIHRoaXMuX2xlYWZsZXRNYXAgPSB1bmRlZmluZWQ7XHJcbiAgICAgICAgICAgIGxldCBsZWFmdGxldElkID0gJyMnICsgdGhpcy5jb25maWcuaWQgKyAnTGVhZmxldCc7XHJcbiAgICAgICAgICAgIGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3IobGVhZnRsZXRJZCkuc2V0QXR0cmlidXRlKCdjbGFzcycsICdrZHgtY2hhcnRzLXN2Zy1jb250YWluZXInKTtcclxuICAgICAgICB9XHJcbiAgICAgICAgaWYgKHR5cGVvZiB0aGlzLl9tYXBMYXllciAhPT0gJ3VuZGVmaW5lZCcpIHtcclxuICAgICAgICAgICAgdGhpcy5fbWFwTGF5ZXIucmVtb3ZlKCk7XHJcbiAgICAgICAgICAgIHRoaXMuX21hcExheWVyID0gdW5kZWZpbmVkO1xyXG5cclxuICAgICAgICB9XHJcbiAgICAgICAgaWYgKHR5cGVvZiB0aGlzLl9mdWxsR3JhcGggIT09ICd1bmRlZmluZWQnKSB7XHJcbiAgICAgICAgICAgIHRoaXMuX2Z1bGxHcmFwaC5yZW1vdmUoKTtcclxuICAgICAgICAgICAgdGhpcy5fZnVsbEdyYXBoID0gdW5kZWZpbmVkO1xyXG4gICAgICAgIH1cclxuICAgICAgICBpZiAodHlwZW9mIHRoaXMuX2JhY2tCdG4gIT09ICd1bmRlZmluZWQnKSB7XHJcbiAgICAgICAgICAgIHRoaXMuX2JhY2tCdG4ucmVtb3ZlKCk7XHJcbiAgICAgICAgICAgIHRoaXMuX2JhY2tCdG4gPSB1bmRlZmluZWQ7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIHRoaXMuX2xldmVsID0gdW5kZWZpbmVkO1xyXG4gICAgICAgIHRoaXMuX291dHB1dFNlcmllc0RhdGEgPSBbXTtcclxuICAgICAgICB0aGlzLl9pc01hcFNlbGVjdGVkID0ge307XHJcbiAgICAgICAgc3VwZXIucmVtb3ZlQ2hhcnQoKTtcclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF9kcmF3TGVhZnRsZXQoKTogdm9pZCB7XHJcbiAgICAgICAgaWYgKHRoaXMuX2xlYWZsZXRNYXAgIT09IHVuZGVmaW5lZCAmJiB0aGlzLl9sZWFmbGV0TWFwICE9PSBudWxsKSB0aGlzLl9sZWFmbGV0TWFwLnJlbW92ZSgpO1xyXG4gICAgICAgIGxldCB6b29tVmFsdWU6IG51bWJlciA9IDY7XHJcbiAgICAgICAgaWYgKHRoaXMuY2hhcnRUeXBlWzFdID09PSAnZmlsdGVyJyAmJiB0aGlzLmRhdGEucG9zaXRpb24gJiYgdGhpcy5kYXRhLnBvc2l0aW9uLnpvb20pIHtcclxuICAgICAgICAgICAgem9vbVZhbHVlID0gdGhpcy5kYXRhLnBvc2l0aW9uLnpvb207XHJcbiAgICAgICAgfSBlbHNlIGlmICh0aGlzLmNvbmZpZy5wbG90T3B0aW9ucy5tYXAuem9vbSAmJiB0aGlzLmNvbmZpZy5wbG90T3B0aW9ucy5tYXAuem9vbS52YWx1ZSkge1xyXG4gICAgICAgICAgICB6b29tVmFsdWUgPSB0aGlzLmNvbmZpZy5wbG90T3B0aW9ucy5tYXAuem9vbS52YWx1ZTtcclxuICAgICAgICB9XHJcbiAgICAgICAgbGV0IGxlYWZ0bGV0SWQgPSB0aGlzLmNvbmZpZy5pZCArICdMZWFmbGV0JztcclxuICAgICAgICB0aGlzLl9sZWFmbGV0TWFwID0gTC5tYXAobGVhZnRsZXRJZCkuc2V0VmlldyhbdGhpcy5kYXRhLnBvc2l0aW9uLmxhdGl0dWRlLCB0aGlzLmRhdGEucG9zaXRpb24ubG9uZ2l0dWRlXSwgem9vbVZhbHVlKTtcclxuICAgICAgICB0aGlzLl9zZXRMYXllcigpO1xyXG4gICAgICAgIHRoaXMuX3JlbW92ZURlZmF1bHRBdHRyaWJ1dGlvbignT3BlbkVNSVMnKTtcclxuICAgICAgICBpZiAodGhpcy5jaGFydFR5cGVbMV0gPT09ICdmdWxsJyB8fCB0aGlzLmNoYXJ0VHlwZVsxXSA9PT0gJ2NsdXN0ZXInKSB0aGlzLl9zZXRNYXJrZXJzKCk7XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfZHJhd0Z1bGxNYXAoKTogdm9pZCB7XHJcbiAgICAgICAgdGhpcy5fb3V0cHV0U2VyaWVzRGF0YSA9IFtdO1xyXG4gICAgICAgIGlmICh0eXBlb2YgdGhpcy5fZnVsbEdyYXBoID09PSAndW5kZWZpbmVkJykgdGhpcy5fZnVsbEdyYXBoID0gZDMuc2VsZWN0KHRoaXMuX2xlYWZsZXRNYXAuZ2V0UGFuZXMoKS5vdmVybGF5UGFuZSkuYXBwZW5kKFwic3ZnXCIpO1xyXG4gICAgICAgIC8vIHRoaXMuX2Z1bGxHcmFwaCA9IGQzLnNlbGVjdCh0aGlzLl9sZWFmbGV0TWFwLmdldFBhbmVzKCkub3ZlcmxheVBhbmUpLmFwcGVuZChcInN2Z1wiKTtcclxuXHJcbiAgICAgICAgdGhpcy5fbWFwTGF5ZXIgPSB0aGlzLl9mdWxsR3JhcGguYXBwZW5kKFwiZ1wiKS5hdHRyKFwiY2xhc3NcIiwgXCJsZWFmbGV0LXpvb20taGlkZVwiKTtcclxuICAgICAgICBsZXQgbWFwID0gdGhpcy5fbGVhZmxldE1hcDtcclxuICAgICAgICBsZXQgc3ZnID0gdGhpcy5fZnVsbEdyYXBoO1xyXG4gICAgICAgIGxldCBjdXJyZW50Q2hhcnRJZCA9IHRoaXMuY29uZmlnLmlkO1xyXG4gICAgICAgIGxldCBtYXBMYXllciA9IHRoaXMuX21hcExheWVyO1xyXG4gICAgICAgIGxldCB3aWR0aCA9IHRoaXMuX3dpZHRoO1xyXG4gICAgICAgIGxldCBoZWlnaHQgPSB0aGlzLl9oZWlnaHQ7XHJcbiAgICAgICAgbGV0IHRyYW5zZm9ybSA9IGQzLmdlb1RyYW5zZm9ybSh7XHJcbiAgICAgICAgICAgIHBvaW50OiBmdW5jdGlvbih4LCB5KSB7XHJcbiAgICAgICAgICAgICAgICBsZXQgcG9pbnQgPSBtYXAubGF0TG5nVG9MYXllclBvaW50KG5ldyBMLkxhdExuZyh5LCB4KSk7XHJcbiAgICAgICAgICAgICAgICB0aGlzLnN0cmVhbS5wb2ludChwb2ludC54LCBwb2ludC55KTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH0pLFxyXG4gICAgICAgICAgICBwYXRoID0gZDMuZ2VvUGF0aCgpLnByb2plY3Rpb24odHJhbnNmb3JtKTtcclxuICAgICAgICBsZXQgdmFsdWVLZXksIGZpbHRlclZhbHVlT2JqOiBhbnk7XHJcbiAgICAgICAgaWYgKHRoaXMuY2hhcnRUeXBlWzFdID09PSAnZmlsdGVyJyAmJiB0aGlzLmRhdGEuaGFzT3duUHJvcGVydHkoJ3ZhbHVlJykgJiYgKHRoaXMuZGF0YS52YWx1ZSAhPT0gdW5kZWZpbmVkIHx8IHRoaXMuZGF0YS52YWx1ZSAhPT0gbnVsbCkpIHtcclxuICAgICAgICAgICAgdmFsdWVLZXkgPSBPYmplY3Qua2V5cyh0aGlzLmRhdGEudmFsdWUpWzBdO1xyXG4gICAgICAgICAgICBmaWx0ZXJWYWx1ZU9iaiA9IHRoaXMuZGF0YS52YWx1ZVt2YWx1ZUtleV07XHJcbiAgICAgICAgfVxyXG4gICAgICAgIC8vIHRoaXMuX21hcExheWVyID0gdGhpcy5fcGF0aC5hcHBlbmQoJ2cnKS5jbGFzc2VkKCdtYXAtbGF5ZXInLCB0cnVlKTtcclxuICAgICAgICAvLyBhbGxvdyB1c2VyIHRvIGRlZmluZSBvciBjaGFuZ2UgdGhlIGxldmVsIG9mIHRoZSBtYXBcclxuICAgICAgICBpZiAodGhpcy5jb25maWcucGxvdE9wdGlvbnMubWFwLmxldmVsICYmICh0aGlzLmNvbmZpZy5wbG90T3B0aW9ucy5tYXAubGV2ZWwgIT09ICcnIHx8IHRoaXMuY29uZmlnLnBsb3RPcHRpb25zLm1hcC5sZXZlbCAhPT0gdW5kZWZpbmVkIHx8IHRoaXMuY29uZmlnLnBsb3RPcHRpb25zLm1hcC5sZXZlbCAhPT0gbnVsbCkgJiYgdGhpcy5fbWFwU3ZjLmNoZWNrTWFwTGV2ZWxFeGlzdCh0aGlzLmNvbmZpZy5wbG90T3B0aW9ucy5tYXAubGV2ZWwsIHRoaXMuZGF0YS5tYXBEYXRhKSkge1xyXG4gICAgICAgICAgICBpZiAoKHRoaXMuY2hhcnRUeXBlWzFdID09PSAnZnVsbCcgJiYgdGhpcy5jb25maWcucGxvdE9wdGlvbnMubWFwLm1hcEZ1bGxDaGFuZ2VMZXZlbERlZmF1bHQgPT09IHRydWUpIHx8IHRoaXMuY2hhcnRUeXBlWzFdICE9PSAnZnVsbCcpIHtcclxuICAgICAgICAgICAgICAgIHRoaXMuX2xldmVsID0gdGhpcy5jb25maWcucGxvdE9wdGlvbnMubWFwLmxldmVsO1xyXG4gICAgICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5fY2hlY2tCYWNrQnRuKCk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICB0aGlzLl9jaGVja0JhY2tCdG4oKTtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIGxldCBkYXRhID0gdGhpcy5kYXRhLm1hcERhdGEuaGFzT3duUHJvcGVydHkodGhpcy5fbGV2ZWwpID8gdGhpcy5kYXRhLm1hcERhdGFbdGhpcy5fbGV2ZWxdIDogdGhpcy5kYXRhLm1hcERhdGE7XHJcbiAgICAgICAgbGV0IHByb2plY3Rpb24gPSBkMy5nZW9NZXJjYXRvcigpLmZpdFNpemUoW3RoaXMuX3dpZHRoLCB0aGlzLl9oZWlnaHQgLSA1MF0sIGRhdGEpO1xyXG4gICAgICAgIC8vIGxldCBwYXRoID0gZDMuZ2VvUGF0aCgpLnByb2plY3Rpb24ocHJvamVjdGlvbik7XHJcbiAgICAgICAgbGV0IGZlYXR1cmVzID0gdGhpcy5kYXRhLm1hcERhdGEuaGFzT3duUHJvcGVydHkoJ2ZlYXR1cmVzJykgPyB0aGlzLmRhdGEubWFwRGF0YS5mZWF0dXJlcyA6IHRoaXMuZGF0YS5tYXBEYXRhW3RoaXMuX2xldmVsXS5mZWF0dXJlcztcclxuXHJcbiAgICAgICAgbGV0IG1hcFBhdGggPSB0aGlzLl9tYXBMYXllci5zZWxlY3RBbGwoJ3BhdGgnKVxyXG4gICAgICAgICAgICAuZGF0YShmZWF0dXJlcylcclxuICAgICAgICAgICAgLmVudGVyKCkuYXBwZW5kKCdwYXRoJylcclxuICAgICAgICAgICAgLy8gLmF0dHIoJ2QnLCBwYXRoKVxyXG4gICAgICAgICAgICAuYXR0cignaWQnLCAoZCkgPT4geyByZXR1cm4gdGhpcy5fbWFwU3ZjLnBhdGhJZFByZWZpeCArIGQucHJvcGVydGllcy5JRF87IH0pXHJcbiAgICAgICAgICAgIC5hdHRyKCdjbGFzcycsIChkKSA9PiB7XHJcbiAgICAgICAgICAgICAgICBpZiAodGhpcy5fZW1wdHlTZXJpZXMgPT0gZmFsc2UgJiYgdGhpcy5fc2VyaWVzUG9pbnRlciAmJiB0aGlzLl9zZXJpZXNQb2ludGVyLmRhdGEgIT0gdW5kZWZpbmVkKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgbGV0IHNlcmllc1ZhbHVlID0gdGhpcy5fZ2V0U2VyaWVzVmFsdWUoZC5wcm9wZXJ0aWVzLklEXyk7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5fb3V0cHV0U2VyaWVzRGF0YS5wdXNoKHsgJ25hbWUnOiBzZXJpZXNWYWx1ZS5uYW1lLCAndmFsdWUnOiBzZXJpZXNWYWx1ZS52YWx1ZSwgJ2lkJzogZC5wcm9wZXJ0aWVzLklEXyB9KTtcclxuICAgICAgICAgICAgICAgICAgICByZXR1cm4gJ2lkLScgKyBzZXJpZXNWYWx1ZS5pZCArICcsIG5hbWUtJyArIHNlcmllc1ZhbHVlLm5hbWUgKyAnLCBkcmlsbGRvd24tJyArIHNlcmllc1ZhbHVlLmRyaWxsZG93biArICcsIHZhbHVlLScgKyBzZXJpZXNWYWx1ZS52YWx1ZTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfSlcclxuICAgICAgICAgICAgLmF0dHIoJ3ZlY3Rvci1lZmZlY3QnLCAnbm9uLXNjYWxpbmctc3Ryb2tlJylcclxuICAgICAgICAgICAgLnN0eWxlKCdmaWxsJywgKGQpID0+IHtcclxuICAgICAgICAgICAgICAgIGlmICh0aGlzLmNoYXJ0VHlwZVsxXSA9PT0gJ2ZpbHRlcicgJiYgdGhpcy5kYXRhLmhhc093blByb3BlcnR5KCd2YWx1ZScpICYmICh0aGlzLmRhdGEudmFsdWUgIT09IHVuZGVmaW5lZCB8fCB0aGlzLmRhdGEudmFsdWUgIT09IG51bGwpKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKGQuaGFzT3duUHJvcGVydHkoJ3Byb3BlcnRpZXMnKSAmJiBkLnByb3BlcnRpZXMuSURfID09PSBmaWx0ZXJWYWx1ZU9iai5pZCAmJiBkLnByb3BlcnRpZXMuTkFNRTFfID09PSBmaWx0ZXJWYWx1ZU9iai5uYW1lKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuX2lzTWFwU2VsZWN0ZWQgPSB7fTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5faXNNYXBTZWxlY3RlZFtkLnByb3BlcnRpZXMuSURfXSA9IGQucHJvcGVydGllcy5JRF87XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiB0aGlzLmNvbmZpZy5wbG90T3B0aW9ucy5tYXAuc3RhdGVzLnNlbGVjdC5jb2xvcjtcclxuICAgICAgICAgICAgICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gdGhpcy5fZ2V0TWFwRmlsbENvbG9yKGQpO1xyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIHRoaXMuX2dldE1hcEZpbGxDb2xvcihkKTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfSlcclxuICAgICAgICAgICAgLnN0eWxlKCdzdHJva2Utd2lkdGgnLCAoZCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgaWYgKHRoaXMuY2hhcnRUeXBlWzFdID09PSAnZmlsdGVyJyAmJiB0aGlzLmRhdGEuaGFzT3duUHJvcGVydHkoJ3ZhbHVlJykgJiYgKHRoaXMuZGF0YS52YWx1ZSAhPT0gdW5kZWZpbmVkIHx8IHRoaXMuZGF0YS52YWx1ZSAhPT0gbnVsbCkpIHtcclxuICAgICAgICAgICAgICAgICAgICBpZiAoZC5oYXNPd25Qcm9wZXJ0eSgncHJvcGVydGllcycpICYmIGQucHJvcGVydGllcy5JRF8gPT09IGZpbHRlclZhbHVlT2JqLmlkICYmIGQucHJvcGVydGllcy5OQU1FMV8gPT09IGZpbHRlclZhbHVlT2JqLm5hbWUpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIHRoaXMuY29uZmlnLnBsb3RPcHRpb25zLm1hcC5maWx0ZXIuYm9yZGVyU2VsZWN0ZWQgPyB0aGlzLmNvbmZpZy5wbG90T3B0aW9ucy5tYXAuZmlsdGVyLmJvcmRlclNlbGVjdGVkIDogdGhpcy5jb25maWcucGxvdE9wdGlvbnMubWFwLmJvcmRlcldpZHRoO1xyXG4gICAgICAgICAgICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiAodGhpcy5jaGFydFR5cGVbMV0gPT09ICdmaWx0ZXInICYmIHRoaXMuY29uZmlnLnBsb3RPcHRpb25zLm1hcC5maWx0ZXIuYm9yZGVyKSA/IHRoaXMuY29uZmlnLnBsb3RPcHRpb25zLm1hcC5maWx0ZXIuYm9yZGVyIDogdGhpcy5jb25maWcucGxvdE9wdGlvbnMubWFwLmJvcmRlcldpZHRoO1xyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuICh0aGlzLmNoYXJ0VHlwZVsxXSA9PT0gJ2ZpbHRlcicgJiYgdGhpcy5jb25maWcucGxvdE9wdGlvbnMubWFwLmZpbHRlci5ib3JkZXIpID8gdGhpcy5jb25maWcucGxvdE9wdGlvbnMubWFwLmZpbHRlci5ib3JkZXIgOiB0aGlzLmNvbmZpZy5wbG90T3B0aW9ucy5tYXAuYm9yZGVyV2lkdGg7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH0pXHJcbiAgICAgICAgICAgIC5zdHlsZSgnc3Ryb2tlJywgdGhpcy5jb25maWcucGxvdE9wdGlvbnMubWFwLmJvcmRlckNvbG9yKVxyXG4gICAgICAgICAgICAvL2R1ZSB0byBsZWFmbGV0IGJsb2NraW5nIHBvaW50ZXIgZXZlbnRzXHJcbiAgICAgICAgICAgIC5zdHlsZSgncG9pbnRlci1ldmVudHMnLCAndmlzaWJsZScpXHJcbiAgICAgICAgICAgIC5zdHlsZSgnb3BhY2l0eScsIDAuNik7XHJcblxyXG4gICAgICAgIHRoaXMuX2xlYWZsZXRNYXAub24oXCJ2aWV3cmVzZXRcIiwgcmVzZXQpO1xyXG4gICAgICAgIHRoaXMuX2xlYWZsZXRNYXAub24oXCJ6b29tXCIsIHJlc2V0KTtcclxuXHJcbiAgICAgICAgbGV0IG1hcExldmVsID0gdGhpcy5kYXRhLm1hcERhdGFbdGhpcy5fbGV2ZWxdO1xyXG4gICAgICAgIHJlc2V0KCk7XHJcblxyXG4gICAgICAgIGxldCBlbGVtZW50cyA9IEFycmF5LmZyb20oZG9jdW1lbnQucXVlcnlTZWxlY3RvckFsbCgnIycgKyB0aGlzLmNvbmZpZy5pZCArICcua2R4LWNoYXJ0cyBzdmcgLmxlYWZsZXQtem9vbS1oaWRlJykpO1xyXG4gICAgICAgIGVsZW1lbnRzLmZvckVhY2goKGVsKSA9PiB7XHJcbiAgICAgICAgICAgIGVsLmFkZEV2ZW50TGlzdGVuZXIoJ21vdXNlb3ZlcicsIChkKSA9PiB7XHJcbiAgICAgICAgICAgICAgICBsZXQgdGFyZ2V0RWxlbWVudDogSFRNTEVsZW1lbnQgPSA8SFRNTEVsZW1lbnQ+ZC50YXJnZXQ7XHJcbiAgICAgICAgICAgICAgICBsZXQgdGFyZ2V0R2VvanNvbklkOiBzdHJpbmcgPSB0aGlzLl9tYXBTdmMuZ2V0VGFyZ2V0R2VvanNvbklkKHRhcmdldEVsZW1lbnQpO1xyXG4gICAgICAgICAgICAgICAgbGV0IGN1cnJlbnRTZWxlY3Rpb24gPSB0aGlzLl9tYXBTdmMuZ2V0Q3VycmVudFNlbGVjdGlvbih0aGlzLnN2Z0NvbnRhaW5lciwgdGFyZ2V0RWxlbWVudC5nZXRBdHRyaWJ1dGUoJ2lkJykpO1xyXG4gICAgICAgICAgICAgICAgaWYgKHRoaXMuX2NoZWNrRW1wdHlEYXRhVmFsdWUodGFyZ2V0R2VvanNvbklkKSkge1xyXG4gICAgICAgICAgICAgICAgICAgIGlmICh0aGlzLmNoYXJ0VHlwZVsxXSAhPT0gJ2ZpbHRlcicgfHwgKHRoaXMuY2hhcnRUeXBlWzFdID09PSAnZmlsdGVyJyAmJiAhdGhpcy5fY2hlY2tNYXBTZWxlY3RlZCh0YXJnZXRHZW9qc29uSWQpKSkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBjdXJyZW50U2VsZWN0aW9uLnN0eWxlKCdmaWxsJywgdGhpcy5jb25maWcucGxvdE9wdGlvbnMubWFwLnN0YXRlcy5ob3Zlci5jb2xvcik7XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIGlmICh0aGlzLmNoYXJ0VHlwZVsxXSA9PT0gJ2ZpbHRlcicgJiYgdGhpcy5jb25maWcucGxvdE9wdGlvbnMubWFwLmZpbHRlciAmJiB0aGlzLmNvbmZpZy5wbG90T3B0aW9ucy5tYXAuZmlsdGVyLmJvcmRlckhvdmVyICYmICF0aGlzLl9jaGVja01hcFNlbGVjdGVkKHRhcmdldEdlb2pzb25JZCkpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgY3VycmVudFNlbGVjdGlvbi5zdHlsZSgnc3Ryb2tlLXdpZHRoJywgdGhpcy5jb25maWcucGxvdE9wdGlvbnMubWFwLmZpbHRlci5ib3JkZXJIb3Zlcik7XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgZWwuYWRkRXZlbnRMaXN0ZW5lcignbW91c2VvdXQnLCAoZCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgbGV0IHRhcmdldEVsZW1lbnQ6IEhUTUxFbGVtZW50ID0gPEhUTUxFbGVtZW50PmQudGFyZ2V0O1xyXG4gICAgICAgICAgICAgICAgbGV0IHRhcmdldEdlb2pzb25JZDogc3RyaW5nID0gdGhpcy5fbWFwU3ZjLmdldFRhcmdldEdlb2pzb25JZCh0YXJnZXRFbGVtZW50KTtcclxuICAgICAgICAgICAgICAgIGxldCBjdXJyZW50U2VsZWN0aW9uID0gdGhpcy5fbWFwU3ZjLmdldEN1cnJlbnRTZWxlY3Rpb24odGhpcy5zdmdDb250YWluZXIsIHRhcmdldEVsZW1lbnQuZ2V0QXR0cmlidXRlKCdpZCcpKTtcclxuICAgICAgICAgICAgICAgIGlmICh0aGlzLl9jaGVja0VtcHR5RGF0YVZhbHVlKHRhcmdldEdlb2pzb25JZCkpIHtcclxuICAgICAgICAgICAgICAgICAgICBpZiAodGhpcy5jaGFydFR5cGVbMV0gIT09ICdmaWx0ZXInIHx8ICh0aGlzLmNoYXJ0VHlwZVsxXSA9PT0gJ2ZpbHRlcicgJiYgIXRoaXMuX2NoZWNrTWFwU2VsZWN0ZWQodGFyZ2V0R2VvanNvbklkKSkpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgY3VycmVudFNlbGVjdGlvbi5zdHlsZSgnZmlsbCcsIChkMikgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIHRoaXMuX2dldE1hcEZpbGxDb2xvcihkMik7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICBpZiAodGhpcy5jaGFydFR5cGVbMV0gPT09ICdmaWx0ZXInICYmIHRoaXMuY29uZmlnLnBsb3RPcHRpb25zLm1hcC5maWx0ZXIgJiYgdGhpcy5jb25maWcucGxvdE9wdGlvbnMubWFwLmZpbHRlci5ib3JkZXIgJiYgIXRoaXMuX2NoZWNrTWFwU2VsZWN0ZWQodGFyZ2V0RWxlbWVudC5nZXRBdHRyaWJ1dGUoJ2lkJykpKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGN1cnJlbnRTZWxlY3Rpb24uc3R5bGUoJ3N0cm9rZS13aWR0aCcsIHRoaXMuY29uZmlnLnBsb3RPcHRpb25zLm1hcC5maWx0ZXIuYm9yZGVyKTtcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICBlbC5hZGRFdmVudExpc3RlbmVyKCdjbGljaycsIChkKSA9PiB7XHJcbiAgICAgICAgICAgICAgICBsZXQgdGFyZ2V0RWxlbWVudDogSFRNTEVsZW1lbnQgPSA8SFRNTEVsZW1lbnQ+ZC50YXJnZXQ7XHJcbiAgICAgICAgICAgICAgICBsZXQgdGFyZ2V0R2VvanNvbklkOiBzdHJpbmcgPSB0aGlzLl9tYXBTdmMuZ2V0VGFyZ2V0R2VvanNvbklkKHRhcmdldEVsZW1lbnQpO1xyXG4gICAgICAgICAgICAgICAgbGV0IGN1cnJlbnRTZWxlY3Rpb24gPSB0aGlzLl9tYXBTdmMuZ2V0Q3VycmVudFNlbGVjdGlvbih0aGlzLnN2Z0NvbnRhaW5lciwgdGFyZ2V0RWxlbWVudC5nZXRBdHRyaWJ1dGUoJ2lkJykpO1xyXG4gICAgICAgICAgICAgICAgaWYgKCh0aGlzLmNoYXJ0VHlwZVsxXSA9PT0gJ2Z1bGwnICYmIHRoaXMuY29uZmlnLnBsb3RPcHRpb25zLm1hcC5tYXBGdWxsQ2hhbmdlTGV2ZWxEZWZhdWx0ID09PSB0cnVlKSB8fCB0aGlzLmNoYXJ0VHlwZVsxXSAhPT0gJ2Z1bGwnKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5vdXRwdXREYXRhLmVtaXQoY3VycmVudFNlbGVjdGlvbi5hdHRyKCdjbGFzcycpKTtcclxuICAgICAgICAgICAgICAgICAgICBpZiAodGhpcy5jaGFydFR5cGVbMV0gPT09ICdmaWx0ZXInKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGxldCBzZXRDbGlja0JvcmRlckNvbmRpdGlvbjogYm9vbGVhbiA9ICh0aGlzLmNvbmZpZy5wbG90T3B0aW9ucy5tYXAuZmlsdGVyICYmIHRoaXMuY29uZmlnLnBsb3RPcHRpb25zLm1hcC5maWx0ZXIuYm9yZGVyU2VsZWN0ZWQgJiYgdGhpcy5jb25maWcucGxvdE9wdGlvbnMubWFwLmZpbHRlci5ib3JkZXJTZWxlY3RlZCAhPSB1bmRlZmluZWQpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAvL2NoYW5nZSB0aGUgY29sb3IgZm9yIHRoZSBhcmVhIHNlbGVjdGVkXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGlmICh0aGlzLmNvbmZpZy5wbG90T3B0aW9ucy5tYXAuc3RhdGVzICYmIHRoaXMuY29uZmlnLnBsb3RPcHRpb25zLm1hcC5zdGF0ZXMuc2VsZWN0ICYmIHRoaXMuY29uZmlnLnBsb3RPcHRpb25zLm1hcC5zdGF0ZXMuc2VsZWN0LmNvbG9yICYmIHRoaXMuY29uZmlnLnBsb3RPcHRpb25zLm1hcC5zdGF0ZXMuc2VsZWN0LmNvbG9yICE9PSAnJykge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKE9iamVjdC5rZXlzKHRoaXMuX2lzTWFwU2VsZWN0ZWQpLmxlbmd0aCAhPT0gMCkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxldCBwcmV2aW91c0FyZWFJZCA9IE9iamVjdC5rZXlzKHRoaXMuX2lzTWFwU2VsZWN0ZWQpWzBdO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGQzLnNlbGVjdCgnIycgKyB0aGlzLmNvbmZpZy5pZCArICcua2R4LWNoYXJ0cyBzdmcgLmxlYWZsZXQtem9vbS1oaWRlJykuc2VsZWN0KCcjJyArIHRoaXMuX21hcFN2Yy5wYXRoSWRQcmVmaXggKyBwcmV2aW91c0FyZWFJZCkuc3R5bGUoJ2ZpbGwnLCAoZDIpID0+IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIHRoaXMuX2dldE1hcEZpbGxDb2xvcihkMik7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKHNldENsaWNrQm9yZGVyQ29uZGl0aW9uKSBkMy5zZWxlY3QoJyMnICsgdGhpcy5jb25maWcuaWQgKyAnLmtkeC1jaGFydHMgc3ZnIC5sZWFmbGV0LXpvb20taGlkZScpLnNlbGVjdCgnIycgKyB0aGlzLl9tYXBTdmMucGF0aElkUHJlZml4ICsgcHJldmlvdXNBcmVhSWQpLnN0eWxlKCdzdHJva2Utd2lkdGgnLCB0aGlzLmNvbmZpZy5wbG90T3B0aW9ucy5tYXAuZmlsdGVyLmJvcmRlcik7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5faXNNYXBTZWxlY3RlZCA9IHt9O1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmIChwcmV2aW91c0FyZWFJZCAhPT0gdGFyZ2V0R2VvanNvbklkKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuX2lzTWFwU2VsZWN0ZWRbdGFyZ2V0R2VvanNvbklkXSA9IHRhcmdldEdlb2pzb25JZDtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY3VycmVudFNlbGVjdGlvbi5zdHlsZSgnZmlsbCcsIHRoaXMuY29uZmlnLnBsb3RPcHRpb25zLm1hcC5zdGF0ZXMuc2VsZWN0LmNvbG9yKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKHNldENsaWNrQm9yZGVyQ29uZGl0aW9uKSBjdXJyZW50U2VsZWN0aW9uLnN0eWxlKCdzdHJva2Utd2lkdGgnLCB0aGlzLmNvbmZpZy5wbG90T3B0aW9ucy5tYXAuZmlsdGVyLmJvcmRlclNlbGVjdGVkKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuX2lzTWFwU2VsZWN0ZWQgPSB7fTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0aGlzLl9pc01hcFNlbGVjdGVkW3RhcmdldEdlb2pzb25JZF0gPSB0YXJnZXRHZW9qc29uSWQ7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY3VycmVudFNlbGVjdGlvbi5zdHlsZSgnZmlsbCcsIHRoaXMuY29uZmlnLnBsb3RPcHRpb25zLm1hcC5zdGF0ZXMuc2VsZWN0LmNvbG9yKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAoc2V0Q2xpY2tCb3JkZXJDb25kaXRpb24pIGN1cnJlbnRTZWxlY3Rpb24uc3R5bGUoJ3N0cm9rZS13aWR0aCcsIHRoaXMuY29uZmlnLnBsb3RPcHRpb25zLm1hcC5maWx0ZXIuYm9yZGVyU2VsZWN0ZWQpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgICAgICAgICBpZiAodGhpcy5fY2hlY2tFbXB0eURhdGFWYWx1ZSh0YXJnZXRHZW9qc29uSWQpKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuX2NoYW5nZUxldmVsKHRoaXMuX2xldmVsLCAnYWRkJyk7XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9KTtcclxuICAgICAgICB9KTtcclxuICAgICAgICAvLyBSZXBvc2l0aW9uIHRoZSBTVkcgdG8gY292ZXIgdGhlIGZlYXR1cmVzLlxyXG4gICAgICAgIGZ1bmN0aW9uIHJlc2V0KCkge1xyXG4gICAgICAgICAgICBsZXQgYm91bmRzID0gcGF0aC5ib3VuZHMobWFwTGV2ZWwpLFxyXG4gICAgICAgICAgICAgICAgdG9wTGVmdCA9IGJvdW5kc1swXSxcclxuICAgICAgICAgICAgICAgIGJvdHRvbVJpZ2h0ID0gYm91bmRzWzFdO1xyXG4gICAgICAgICAgICAvLyBjb25zb2xlLmxvZygnd2lkdGggJywgSlNPTi5wYXJzZShKU09OLnN0cmluZ2lmeShib3R0b21SaWdodFswXSAtIHRvcExlZnRbMF0pKSlcclxuICAgICAgICAgICAgc3ZnLmF0dHIoXCJ3aWR0aFwiLCBib3R0b21SaWdodFswXSAtIHRvcExlZnRbMF0pXHJcbiAgICAgICAgICAgICAgICAuYXR0cihcImhlaWdodFwiLCBib3R0b21SaWdodFsxXSAtIHRvcExlZnRbMV0pXHJcbiAgICAgICAgICAgICAgICAuc3R5bGUoXCJsZWZ0XCIsIHRvcExlZnRbMF0gKyBcInB4XCIpXHJcbiAgICAgICAgICAgICAgICAuc3R5bGUoXCJ0b3BcIiwgdG9wTGVmdFsxXSArIFwicHhcIik7XHJcblxyXG4gICAgICAgICAgICBpZiAoIWQzLnNlbGVjdCgnIycgKyBjdXJyZW50Q2hhcnRJZCArICcua2R4LWNoYXJ0cyBzdmcgLmxlYWZsZXQtem9vbS1oaWRlJykuc2VsZWN0KCcjYmFja0J0bicpLmVtcHR5KCkpIHtcclxuICAgICAgICAgICAgICAgIGQzLnNlbGVjdCgnIycgKyBjdXJyZW50Q2hhcnRJZCArICcua2R4LWNoYXJ0cyBzdmcgLmxlYWZsZXQtem9vbS1oaWRlJykuc2VsZWN0KCcjYmFja0J0bicpLmF0dHIoJ3RyYW5zZm9ybScsIGZ1bmN0aW9uKCkge1xyXG4gICAgICAgICAgICAgICAgICAgIHJldHVybiAndHJhbnNsYXRlKCcgKyAod2lkdGggLSAxMDAgLSBwYXJzZUludCh0b3BMZWZ0WzBdKSkgKyAnLCcgKyAoaGVpZ2h0IC8gMyAtIHBhcnNlSW50KHRvcExlZnRbMV0pKSArICcpJztcclxuICAgICAgICAgICAgICAgIH0pXHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgbWFwTGF5ZXIuYXR0cihcInRyYW5zZm9ybVwiLCBcInRyYW5zbGF0ZShcIiArIC10b3BMZWZ0WzBdICsgXCIsXCIgKyAtdG9wTGVmdFsxXSArIFwiKVwiKTtcclxuICAgICAgICAgICAgbWFwUGF0aC5hdHRyKFwiZFwiLCBwYXRoKTtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIGxldCBldmVudHNQYXJhbSA9IHtcclxuICAgICAgICAgICAgJ3Nlcmllc0RhdGEnOiB0aGlzLl9vdXRwdXRTZXJpZXNEYXRhLFxyXG4gICAgICAgICAgICAnc2VyaWVzTmFtZSc6IHRoaXMuX3Nlcmllc1BvaW50ZXIubmFtZSxcclxuICAgICAgICAgICAgJ3Rvb2x0aXBMYXllcic6IGQzLnNlbGVjdCh0aGlzLl9sZWFmbGV0TWFwLmdldFBhbmVzKCkub3ZlcmxheVBhbmUpLFxyXG4gICAgICAgICAgICAnZnVsbEdyYXBoJzogdGhpcy5fZnVsbEdyYXBoXHJcbiAgICAgICAgfTtcclxuICAgICAgICBpZiAodGhpcy5jb25maWcuY29sb3JBeGlzICE9IHVuZGVmaW5lZCAmJiB0aGlzLmNvbmZpZy5jb2xvckF4aXMuZGF0YUNsYXNzZXMgPT0gdW5kZWZpbmVkKSB7XHJcbiAgICAgICAgICAgIGV2ZW50c1BhcmFtWydjYWxsYmFja3MnXSA9IHtcclxuICAgICAgICAgICAgICAgICdtb3VzZW92ZXInOiAoZCkgPT4gdGhpcy5fc2V0TWFwU2NhbGVUcmlhbmdsZShkKSxcclxuICAgICAgICAgICAgICAgICdtb3VzZW91dCc6ICgpID0+IHRoaXMuX3JlbW92ZU1hcFNjYWxlVHJpYW5nbGUoKVxyXG4gICAgICAgICAgICB9O1xyXG4gICAgICAgIH1cclxuICAgICAgICAvLyBhZGQgdG9vbHRvcFxyXG4gICAgICAgIGlmICh0aGlzLl9zZXJpZXNQb2ludGVyLmRhdGEgIT0gdW5kZWZpbmVkKSB7XHJcbiAgICAgICAgICAgIHN1cGVyLl9pbml0TW91c2VFdmVudHMobWFwUGF0aCwgZXZlbnRzUGFyYW0pO1xyXG4gICAgICAgIH1cclxuXHJcblxyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX2RyYXdQb2x5Z29uTWFwKCk6IHZvaWQge1xyXG4gICAgICAgIHRoaXMuX291dHB1dFNlcmllc0RhdGEgPSBbXTtcclxuICAgICAgICB0aGlzLl9wYXRoID0gdGhpcy5ncmFwaC5hdHRyKCd3aWR0aCcsIHRoaXMuX3dpZHRoKS5hdHRyKCdoZWlnaHQnLCB0aGlzLl9oZWlnaHQpO1xyXG5cclxuICAgICAgICB0aGlzLl9tYXBMYXllciA9IHRoaXMuX3BhdGguYXBwZW5kKCdnJykuY2xhc3NlZCgnbWFwLWxheWVyJywgdHJ1ZSk7XHJcbiAgICAgICAgaWYgKHRoaXMuY29uZmlnLm1hcE5hdmlnYXRpb24gJiYgdGhpcy5jb25maWcubWFwTmF2aWdhdGlvbi5lbmFibGVkID09IHRydWUpIHtcclxuICAgICAgICAgICAgaWYgKHR5cGVvZiB0aGlzLl96b29tQnRucyA9PT0gJ3VuZGVmaW5lZCcpIHRoaXMuX2luaXRab29tQnRuKCk7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIC8vIHRoaXMuX2NoZWNrQmFja0J0bigpO1xyXG4gICAgICAgIGlmICh0aGlzLmNvbmZpZy5wbG90T3B0aW9ucy5tYXAubGV2ZWwgJiYgKHRoaXMuY29uZmlnLnBsb3RPcHRpb25zLm1hcC5sZXZlbCAhPT0gJycgfHwgdGhpcy5jb25maWcucGxvdE9wdGlvbnMubWFwLmxldmVsICE9PSB1bmRlZmluZWQgfHwgdGhpcy5jb25maWcucGxvdE9wdGlvbnMubWFwLmxldmVsICE9PSBudWxsKSAmJiB0aGlzLl9tYXBTdmMuY2hlY2tNYXBMZXZlbEV4aXN0KHRoaXMuY29uZmlnLnBsb3RPcHRpb25zLm1hcC5sZXZlbCwgdGhpcy5kYXRhLm1hcERhdGEpKSB7XHJcbiAgICAgICAgICAgIGlmICh0aGlzLmNoYXJ0VHlwZVsxXSA9PT0gJ3RoZW1hdGljJykge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5fbGV2ZWwgPSB0aGlzLmNvbmZpZy5wbG90T3B0aW9ucy5tYXAubGV2ZWw7XHJcbiAgICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLl9jaGVja0JhY2tCdG4oKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH0gZWxzZSBpZiAodGhpcy5jaGFydFR5cGVbMV0gPT09ICdwb2x5Z29uJykge1xyXG4gICAgICAgICAgICB0aGlzLl9jaGVja0JhY2tCdG4oKTtcclxuICAgICAgICB9XHJcbiAgICAgICAgbGV0IGRhdGEgPSB0aGlzLmRhdGEubWFwRGF0YS5oYXNPd25Qcm9wZXJ0eSh0aGlzLl9sZXZlbCkgPyB0aGlzLmRhdGEubWFwRGF0YVt0aGlzLl9sZXZlbF0gOiB0aGlzLmRhdGEubWFwRGF0YTtcclxuICAgICAgICBsZXQgcHJvamVjdGlvbiA9IGQzLmdlb01lcmNhdG9yKCkuZml0U2l6ZShbdGhpcy5fd2lkdGgsIHRoaXMuX2hlaWdodCAtIDUwXSwgZGF0YSk7XHJcbiAgICAgICAgbGV0IHBhdGggPSBkMy5nZW9QYXRoKCkucHJvamVjdGlvbihwcm9qZWN0aW9uKTtcclxuICAgICAgICBsZXQgZmVhdHVyZXMgPSB0aGlzLmRhdGEubWFwRGF0YS5oYXNPd25Qcm9wZXJ0eSgnZmVhdHVyZXMnKSA/IHRoaXMuZGF0YS5tYXBEYXRhLmZlYXR1cmVzIDogdGhpcy5kYXRhLm1hcERhdGFbdGhpcy5fbGV2ZWxdLmZlYXR1cmVzO1xyXG4gICAgICAgIGxldCBtYXBQYXRoID0gdGhpcy5fbWFwTGF5ZXIuc2VsZWN0QWxsKCdwYXRoJylcclxuICAgICAgICAgICAgLmRhdGEoZmVhdHVyZXMpXHJcbiAgICAgICAgICAgIC5lbnRlcigpLmFwcGVuZCgncGF0aCcpXHJcbiAgICAgICAgICAgIC5hdHRyKCdkJywgcGF0aClcclxuICAgICAgICAgICAgLmF0dHIoJ2lkJywgKGQpID0+IHsgcmV0dXJuIHRoaXMuX21hcFN2Yy5wYXRoSWRQcmVmaXggKyBkLnByb3BlcnRpZXMuSURfOyB9KVxyXG4gICAgICAgICAgICAuYXR0cignY2xhc3MnLCAoZCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgaWYgKHRoaXMuX2VtcHR5U2VyaWVzID09IGZhbHNlICYmIHRoaXMuX3Nlcmllc1BvaW50ZXIgJiYgdGhpcy5fc2VyaWVzUG9pbnRlci5kYXRhICE9IHVuZGVmaW5lZCkge1xyXG4gICAgICAgICAgICAgICAgICAgIGxldCBzZXJpZXNWYWx1ZSA9IHRoaXMuX2dldFNlcmllc1ZhbHVlKGQucHJvcGVydGllcy5JRF8pO1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuX291dHB1dFNlcmllc0RhdGEucHVzaCh7ICduYW1lJzogc2VyaWVzVmFsdWUubmFtZSwgJ3ZhbHVlJzogc2VyaWVzVmFsdWUudmFsdWUsICdpZCc6IGQucHJvcGVydGllcy5JRF8gfSk7XHJcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuICdpZC0nICsgc2VyaWVzVmFsdWUuaWQgKyAnLCBuYW1lLScgKyBzZXJpZXNWYWx1ZS5uYW1lICsgJywgZHJpbGxkb3duLScgKyBzZXJpZXNWYWx1ZS5kcmlsbGRvd24gKyAnLCB2YWx1ZS0nICsgc2VyaWVzVmFsdWUudmFsdWU7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH0pXHJcbiAgICAgICAgICAgIC5hdHRyKCd2ZWN0b3ItZWZmZWN0JywgJ25vbi1zY2FsaW5nLXN0cm9rZScpXHJcbiAgICAgICAgICAgIC5zdHlsZSgnZmlsbCcsIChkKSA9PiB7XHJcbiAgICAgICAgICAgICAgICByZXR1cm4gdGhpcy5fZ2V0TWFwRmlsbENvbG9yKGQpO1xyXG4gICAgICAgICAgICB9KVxyXG4gICAgICAgICAgICAuc3R5bGUoJ3N0cm9rZS13aWR0aCcsIHRoaXMuY29uZmlnLnBsb3RPcHRpb25zLm1hcC5ib3JkZXJXaWR0aClcclxuICAgICAgICAgICAgLnN0eWxlKCdzdHJva2UnLCB0aGlzLmNvbmZpZy5wbG90T3B0aW9ucy5tYXAuYm9yZGVyQ29sb3IpO1xyXG5cclxuICAgICAgICAvLyBhZGRpbmcgbW91c2UgZXZlbnRzLCBob3ZlciBjb2xvciwgY2hhbmdlIGxldmVsXHJcbiAgICAgICAgaWYgKHRoaXMuX2VtcHR5U2VyaWVzID09IGZhbHNlKSB7XHJcbiAgICAgICAgICAgIGxldCBlbGVtZW50cyA9IEFycmF5LmZyb20oZG9jdW1lbnQucXVlcnlTZWxlY3RvckFsbCgnIycgKyB0aGlzLmNvbmZpZy5pZCArICcua2R4LWNoYXJ0cyBzdmcgLm1hcC1sYXllcicpKTtcclxuICAgICAgICAgICAgZWxlbWVudHMuZm9yRWFjaCgoZWwpID0+IHtcclxuICAgICAgICAgICAgICAgIGVsLmFkZEV2ZW50TGlzdGVuZXIoJ21vdXNlb3ZlcicsIChkKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgbGV0IHRhcmdldEVsZW1lbnQ6IEhUTUxFbGVtZW50ID0gPEhUTUxFbGVtZW50PmQudGFyZ2V0O1xyXG4gICAgICAgICAgICAgICAgICAgIGxldCB0YXJnZXRFbGVtZW50SWQ6IHN0cmluZyA9IHRhcmdldEVsZW1lbnQuZ2V0QXR0cmlidXRlKCdpZCcpLmluZGV4T2YoJ2lkLScpICE9IC0xID8gdGFyZ2V0RWxlbWVudC5nZXRBdHRyaWJ1dGUoJ2lkJykuc3BsaXQoJ2lkLScpWzFdIDogdGFyZ2V0RWxlbWVudC5nZXRBdHRyaWJ1dGUoJ2lkJyk7XHJcbiAgICAgICAgICAgICAgICAgICAgbGV0IGN1cnJlbnRTZWxlY3Rpb24gPSB0aGlzLl9tYXBTdmMuZ2V0Q3VycmVudFNlbGVjdGlvbih0aGlzLnN2Z0NvbnRhaW5lciwgdGFyZ2V0RWxlbWVudC5nZXRBdHRyaWJ1dGUoJ2lkJyksICdkMycpO1xyXG4gICAgICAgICAgICAgICAgICAgIGlmICh0aGlzLl9jaGVja0VtcHR5RGF0YVZhbHVlKHRhcmdldEVsZW1lbnRJZCkpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgY3VycmVudFNlbGVjdGlvbi5zdHlsZSgnZmlsbCcsIHRoaXMuY29uZmlnLnBsb3RPcHRpb25zLm1hcC5zdGF0ZXMuaG92ZXIuY29sb3IpO1xyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICAgICAgZWwuYWRkRXZlbnRMaXN0ZW5lcignbW91c2VvdXQnLCAoZCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgIGxldCB0YXJnZXRFbGVtZW50OiBIVE1MRWxlbWVudCA9IDxIVE1MRWxlbWVudD5kLnRhcmdldDtcclxuICAgICAgICAgICAgICAgICAgICBsZXQgdGFyZ2V0RWxlbWVudElkOiBzdHJpbmcgPSB0YXJnZXRFbGVtZW50LmdldEF0dHJpYnV0ZSgnaWQnKS5pbmRleE9mKCdpZC0nKSAhPSAtMSA/IHRhcmdldEVsZW1lbnQuZ2V0QXR0cmlidXRlKCdpZCcpLnNwbGl0KCdpZC0nKVsxXSA6IHRhcmdldEVsZW1lbnQuZ2V0QXR0cmlidXRlKCdpZCcpO1xyXG4gICAgICAgICAgICAgICAgICAgIGxldCBjdXJyZW50U2VsZWN0aW9uID0gdGhpcy5fbWFwU3ZjLmdldEN1cnJlbnRTZWxlY3Rpb24odGhpcy5zdmdDb250YWluZXIsIHRhcmdldEVsZW1lbnQuZ2V0QXR0cmlidXRlKCdpZCcpLCAnZDMnKTtcclxuICAgICAgICAgICAgICAgICAgICBpZiAodGhpcy5fY2hlY2tFbXB0eURhdGFWYWx1ZSh0YXJnZXRFbGVtZW50SWQpKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGN1cnJlbnRTZWxlY3Rpb24uc3R5bGUoJ2ZpbGwnLCAoZDIpID0+IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiB0aGlzLl9nZXRNYXBGaWxsQ29sb3IoZDIpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgICAgIGVsLmFkZEV2ZW50TGlzdGVuZXIoJ2NsaWNrJywgKGQpID0+IHtcclxuICAgICAgICAgICAgICAgICAgICBpZiAodGhpcy5jaGFydFR5cGVbMV0gPT09ICdwb2x5Z29uJykge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBsZXQgdGFyZ2V0RWxlbWVudDogSFRNTEVsZW1lbnQgPSA8SFRNTEVsZW1lbnQ+ZC50YXJnZXQ7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGxldCB0YXJnZXRHZW9qc29uSWQ6IHN0cmluZyA9IHRoaXMuX21hcFN2Yy5nZXRUYXJnZXRHZW9qc29uSWQodGFyZ2V0RWxlbWVudCk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGlmICh0aGlzLl9jaGVja0VtcHR5RGF0YVZhbHVlKHRhcmdldEdlb2pzb25JZCkpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuX2NoYW5nZUxldmVsKHRoaXMuX2xldmVsLCAnYWRkJyk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgfSk7XHJcblxyXG4gICAgICAgICAgICBsZXQgZXZlbnRzUGFyYW0gPSB7XHJcbiAgICAgICAgICAgICAgICAnc2VyaWVzRGF0YSc6IHRoaXMuX291dHB1dFNlcmllc0RhdGEsXHJcbiAgICAgICAgICAgICAgICAnc2VyaWVzTmFtZSc6IHRoaXMuX3Nlcmllc1BvaW50ZXIubmFtZSxcclxuICAgICAgICAgICAgfTtcclxuICAgICAgICAgICAgaWYgKHRoaXMuY29uZmlnLmNvbG9yQXhpcyAhPSB1bmRlZmluZWQgJiYgdGhpcy5jb25maWcuY29sb3JBeGlzLmRhdGFDbGFzc2VzID09IHVuZGVmaW5lZCkge1xyXG4gICAgICAgICAgICAgICAgZXZlbnRzUGFyYW1bJ2NhbGxiYWNrcyddID0ge1xyXG4gICAgICAgICAgICAgICAgICAgICdtb3VzZW92ZXInOiAoZCkgPT4gdGhpcy5fc2V0TWFwU2NhbGVUcmlhbmdsZShkKSxcclxuICAgICAgICAgICAgICAgICAgICAnbW91c2VvdXQnOiAoKSA9PiB0aGlzLl9yZW1vdmVNYXBTY2FsZVRyaWFuZ2xlKClcclxuICAgICAgICAgICAgICAgIH07XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgLy8gYWRkIHRvb2x0b3BcclxuICAgICAgICAgICAgaWYgKHRoaXMuX3Nlcmllc1BvaW50ZXIuZGF0YSAhPSB1bmRlZmluZWQpIHtcclxuICAgICAgICAgICAgICAgIHN1cGVyLl9pbml0TW91c2VFdmVudHMobWFwUGF0aCwgZXZlbnRzUGFyYW0pO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX2dldE1hcEZpbGxDb2xvcihfdmFsdWU6IGFueSk6IHN0cmluZyB7XHJcbiAgICAgICAgaWYgKHRoaXMuX3Nlcmllc1BvaW50ZXIgPT0gdW5kZWZpbmVkIHx8IHRoaXMuX3Nlcmllc1BvaW50ZXIuZGF0YSA9PSB1bmRlZmluZWQpIHJldHVybiAnI0YyRjJGMic7XHJcblxyXG4gICAgICAgIGxldCBkYXRhVmFsdWUgPSB0aGlzLl9nZXRTZXJpZXNWYWx1ZShfdmFsdWUucHJvcGVydGllcy5JRF8pLnZhbHVlO1xyXG5cclxuICAgICAgICBpZiAodGhpcy5jaGFydFR5cGVbMV0gPT09ICdmaWx0ZXInICYmIHRoaXMuY29uZmlnLmNvbG9yQXhpcyAmJiB0aGlzLmNvbmZpZy5jb2xvckF4aXMubWluQ29sb3IpIHtcclxuICAgICAgICAgICAgcmV0dXJuIHRoaXMuY29uZmlnLmNvbG9yQXhpcy5taW5Db2xvcjtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIGlmIChkYXRhVmFsdWUgPT0gbnVsbCB8fCBkYXRhVmFsdWUgPT0gJycpIHJldHVybiB0aGlzLmNvbmZpZy5wbG90T3B0aW9ucy5tYXAubnVsbENvbG9yIHx8ICdyZ2IoMCwwLDAsMCknO1xyXG5cclxuICAgICAgICBpZiAodGhpcy5jb25maWcuY29sb3JBeGlzICE9IHVuZGVmaW5lZCAmJiB0aGlzLmNvbmZpZy5jb2xvckF4aXMuZGF0YUNsYXNzZXMgPT0gdW5kZWZpbmVkKSB7XHJcbiAgICAgICAgICAgIHJldHVybiB0aGlzLl9tYXBTY2FsZUNvbG9yU2NhbGUoZGF0YVZhbHVlKTtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIGlmICh0aGlzLl9zaW5nbGVMZXZlbERpbWVuc2lvbiA9PSB0cnVlKSB7XHJcbiAgICAgICAgICAgIGZvciAobGV0IGkgPSAwOyBpIDwgdGhpcy5jb25maWcuY29sb3JBeGlzLmRhdGFDbGFzc2VzLmxlbmd0aDsgaSsrKSB7XHJcbiAgICAgICAgICAgICAgICBpZiAodGhpcy5fbWFwU3ZjLmNoZWNrVmFsdWVJbkJldHdlZW4oTnVtYmVyKGRhdGFWYWx1ZSksIHRoaXMuY29uZmlnLmNvbG9yQXhpcy5kYXRhQ2xhc3Nlc1tpXS5mcm9tLCB0aGlzLmNvbmZpZy5jb2xvckF4aXMuZGF0YUNsYXNzZXNbaV0udG8pKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKHRoaXMubGVnZW5kWydpZCcgKyBpXSAmJiB0aGlzLmxlZ2VuZFsnaWQnICsgaV0uZGVhY3RpdmUgPT0gdHJ1ZSkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gJyNGMkYyRjInO1xyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICByZXR1cm4gdGhpcy5jb25maWcuY29sb3JBeGlzLmRhdGFDbGFzc2VzW2ldLmNvbG9yO1xyXG4gICAgICAgICAgICAgICAgfSBlbHNlIGlmIChpID09IHRoaXMuY29uZmlnLmNvbG9yQXhpcy5kYXRhQ2xhc3Nlcy5sZW5ndGgpIHtcclxuICAgICAgICAgICAgICAgICAgICByZXR1cm4gdGhpcy5jb25maWcuY29sb3JBeGlzLm1pbkNvbG9yO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICBpZiAodGhpcy5fZW1wdHlTZXJpZXMgPT0gZmFsc2UpIHJldHVybiB0aGlzLl9jb2xvclBvaW50ZXIuY29sb3I7XHJcblxyXG4gICAgICAgIHJldHVybiAnI0YyRjJGMic7XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfY2hhbmdlTGV2ZWwoX2xldmVsOiBzdHJpbmcsIF90eXBlOiBzdHJpbmcpOiB2b2lkIHtcclxuICAgICAgICBsZXQgbWFwQXJyID0gT2JqZWN0LmtleXModGhpcy5kYXRhLm1hcERhdGEpO1xyXG4gICAgICAgIGxldCBsZXZlbEluZGV4OiBudW1iZXIgPSAwLCBuZXdJbmRleDogbnVtYmVyO1xyXG4gICAgICAgIGxldCBuZXdMZXZlbDogc3RyaW5nO1xyXG4gICAgICAgIGZvciAobGV0IGkgPSAwOyBpIDwgbWFwQXJyLmxlbmd0aDsgaSsrKSB7XHJcbiAgICAgICAgICAgIGlmIChtYXBBcnJbaV0gPT09IF9sZXZlbCkgbGV2ZWxJbmRleCA9IGk7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGlmIChfdHlwZSA9PT0gJ2FkZCcpIHtcclxuICAgICAgICAgICAgaWYgKGxldmVsSW5kZXggKyAxIDw9IG1hcEFyci5sZW5ndGgpIG5ld0luZGV4ID0gbGV2ZWxJbmRleCArIDE7XHJcbiAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgaWYgKGxldmVsSW5kZXggLSAxID49IDApIG5ld0luZGV4ID0gbGV2ZWxJbmRleCAtIDE7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGlmIChuZXdJbmRleCAhPT0gdW5kZWZpbmVkKSB7XHJcbiAgICAgICAgICAgIG5ld0xldmVsID0gbWFwQXJyW25ld0luZGV4XTtcclxuICAgICAgICAgICAgaWYgKHRoaXMuZGF0YS5tYXBEYXRhW25ld0xldmVsXSAhPSB1bmRlZmluZWQpIHtcclxuICAgICAgICAgICAgICAgIGlmICh0eXBlb2YgdGhpcy5fbWFwTGF5ZXIgIT09ICd1bmRlZmluZWQnKSB7IHRoaXMuX21hcExheWVyLnJlbW92ZSgpOyB9XHJcbiAgICAgICAgICAgICAgICB0aGlzLl9sZXZlbCA9IG5ld0xldmVsO1xyXG4gICAgICAgICAgICAgICAgdGhpcy5kYXRhWydtYXBMZXZlbCddID0gdGhpcy5fbGV2ZWw7XHJcbiAgICAgICAgICAgICAgICBpZiAodGhpcy5jb25maWcuY29sb3JBeGlzID09IHVuZGVmaW5lZCkgdGhpcy5fZ2V0RHJpbGxEb3duTGVnZW5kRm9yTXVsdGlwbGVEaW1lbnNpb24oKTtcclxuICAgICAgICAgICAgICAgIHRoaXMuX2dldENvbG9yUG9pbnRlcigpO1xyXG4gICAgICAgICAgICAgICAgaWYgKHRoaXMuY2hhcnRUeXBlWzFdID09PSAnZnVsbCcpIHtcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLl9kcmF3RnVsbE1hcCgpO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgZWxzZSB0aGlzLl9kcmF3UG9seWdvbk1hcCgpO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgICAgIC8vIGxldCBvcCA9IF90eXBlID09ICdhZGQnID8gJysnIDogJy0nO1xyXG4gICAgICAgIC8vIGxldCBvcGVyYXRvcnMgPSB7XHJcbiAgICAgICAgLy8gICAgICcrJzogZnVuY3Rpb24oYSwgYikgeyByZXR1cm4gYSArIGI7IH0sXHJcbiAgICAgICAgLy8gICAgICctJzogZnVuY3Rpb24oYSwgYikgeyByZXR1cm4gYSAtIGI7IH1cclxuICAgICAgICAvLyB9O1xyXG4gICAgICAgIC8vIGxldCBuZXdMZXZlbFBvaW50ZXI6IHN0cmluZyB8IHN0cmluZ1tdID0gX2xldmVsLmluZGV4T2YoJ18nKSAhPSAtMSA/IF9sZXZlbC5zcGxpdCgnXycpIDogX2xldmVsO1xyXG4gICAgICAgIC8vIGxldCBuZXdMZXZlbDogc3RyaW5nID0gX2xldmVsLmluZGV4T2YoJ18nKSAhPSAtMSA/IG5ld0xldmVsUG9pbnRlclswXSArICdfJyArIChvcGVyYXRvcnNbb3BdKHBhcnNlSW50KG5ld0xldmVsUG9pbnRlclsxXSksIDEpKSA6IChvcGVyYXRvcnNbb3BdKHBhcnNlSW50KF9sZXZlbCksIDEpKS50b1N0cmluZygpO1xyXG5cclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF9pbml0Wm9vbUJ0bigpOiB2b2lkIHtcclxuICAgICAgICAvLyBpbnNlcnRpbmcgdGhlIHpvb20gYnV0dG9uc1xyXG4gICAgICAgIGxldCB6b29tZWQ6IEZ1bmN0aW9uID0gKCkgPT4ge1xyXG4gICAgICAgICAgICBjb25zdCB0cmFuc2Zvcm0gPSBkMy5ldmVudC50cmFuc2Zvcm07XHJcbiAgICAgICAgICAgIHRoaXMuX21hcExheWVyLmF0dHIoJ3RyYW5zZm9ybScsICd0cmFuc2xhdGUoJyArIHRyYW5zZm9ybS54ICsgJywnICsgdHJhbnNmb3JtLnkgKyAnKSBzY2FsZSgnICsgdHJhbnNmb3JtLmsgKyAnKScpO1xyXG4gICAgICAgIH07XHJcbiAgICAgICAgbGV0IHpvb20gPSBkMy56b29tKCkuc2NhbGVFeHRlbnQoWzEsIDRdKS5vbignem9vbScsIHpvb21lZCk7XHJcblxyXG4gICAgICAgIHRoaXMuX3pvb21CdG5zID0gdGhpcy5ncmFwaC5hcHBlbmQoJ2cnKS5jbGFzc2VkKCd6b29tLWxheWVyJywgdHJ1ZSk7XHJcbiAgICAgICAgbGV0IHpvb21CdG4gPSB0aGlzLl96b29tQnRucy5zZWxlY3RBbGwoJ2cnKVxyXG4gICAgICAgICAgICAuZGF0YShbJ3pvb21JbicsICd6b29tT3V0J10pXHJcbiAgICAgICAgICAgIC5lbnRlcigpLmFwcGVuZCgnZycpXHJcbiAgICAgICAgICAgIC5hdHRyKCdpZCcsIGZ1bmN0aW9uKGQpIHsgcmV0dXJuIGQ7IH0pXHJcbiAgICAgICAgICAgIC8vIC5hdHRyKCd0cmFuc2Zvcm0nLCAoZCwgaSkgPT4geyByZXR1cm4gJ3RyYW5zbGF0ZSgxMCwnICsgKCh0aGlzLl9oZWlnaHQgLyAzKSArIChpICogMjgpKSArICcpJzsgfSlcclxuICAgICAgICAgICAgLmF0dHIoJ3RyYW5zZm9ybScsIChkLCBpKSA9PiB7IHJldHVybiAndHJhbnNsYXRlKDEwLCcgKyAoMTAgKyAoaSAqIDMwKSkgKyAnKSc7IH0pXHJcbiAgICAgICAgICAgIC5zdHlsZSgnY3Vyc29yJywgJ3BvaW50ZXInKVxyXG4gICAgICAgICAgICAub24oJ2NsaWNrJywgKGQsIGkpID0+IHsgdGhpcy5fem9vbUNsaWNrKGQsIHpvb20pOyB9KTtcclxuICAgICAgICB6b29tQnRuLmFwcGVuZCgncmVjdCcpXHJcbiAgICAgICAgICAgIC5hdHRyKCd3aWR0aCcsICczMHB4JylcclxuICAgICAgICAgICAgLmF0dHIoJ2hlaWdodCcsICczMHB4JylcclxuICAgICAgICAgICAgLmF0dHIoJ3J4JywgMSlcclxuICAgICAgICAgICAgLmF0dHIoJ3J5JywgMSlcclxuICAgICAgICAgICAgLnN0eWxlKCd6LWluZGV4JywgMSlcclxuICAgICAgICAgICAgLnN0eWxlKCdmaWxsJywgJyNmZmYnKVxyXG4gICAgICAgICAgICAuc3R5bGUoJ3N0cm9rZScsICcjY2NjJylcclxuICAgICAgICAgICAgLnN0eWxlKCdzdHJva2Utd2lkdGgnLCAnMicpO1xyXG4gICAgICAgIHpvb21CdG4uYXBwZW5kKCd0ZXh0JylcclxuICAgICAgICAgICAgLmF0dHIoJ3gnLCAxNClcclxuICAgICAgICAgICAgLmF0dHIoJ3knLCAxNClcclxuICAgICAgICAgICAgLmF0dHIoJ2R5JywgJy4zNWVtJylcclxuICAgICAgICAgICAgLmF0dHIoJ3RleHQtYW5jaG9yJywgJ21pZGRsZScpXHJcbiAgICAgICAgICAgIC5zdHlsZSgnZm9udC1zaXplJywgJzIycHgnKVxyXG4gICAgICAgICAgICAuc3R5bGUoJ2ZvbnQtd2VpZ2h0JywgJ2JvbGQnKVxyXG4gICAgICAgICAgICAudGV4dChmdW5jdGlvbihkLCBpKSB7IHJldHVybiBpID09IDAgPyAnKycgOiAn4oiSJzsgfSk7XHJcblxyXG4gICAgICAgIHRoaXMuX21hcExheWVyLmNhbGwoem9vbSk7XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfem9vbUNsaWNrKF96b29tQnRuSWQ6IHN0cmluZywgX3pvb20pOiB2b2lkIHtcclxuICAgICAgICBsZXQgZmFjdG9yID0gX3pvb21CdG5JZCA9PSAnem9vbUluJyA/IDEuMiA6IDAuODtcclxuICAgICAgICBfem9vbS5zY2FsZUJ5KHRoaXMuX21hcExheWVyLCBmYWN0b3IpO1xyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX2luaXRCYWNrQnRuKCk6IHZvaWQge1xyXG4gICAgICAgIC8vIGluc2VydGluZyB0aGUgYmFjayBidXR0b25cclxuICAgICAgICBpZiAodHlwZW9mIHRoaXMuX2JhY2tCdG4gIT09ICd1bmRlZmluZWQnKSB7XHJcbiAgICAgICAgICAgIHRoaXMuX2JhY2tCdG4ucmVtb3ZlKCk7XHJcbiAgICAgICAgICAgIHRoaXMuX2JhY2tCdG4gPSB1bmRlZmluZWQ7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIHNldFRpbWVvdXQoKCkgPT4ge1xyXG4gICAgICAgICAgICBpZiAodGhpcy5jaGFydFR5cGVbMV0gIT09ICdmdWxsJykge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5fYmFja0J0biA9IHRoaXMuZ3JhcGguYXBwZW5kKCdnJykuY2xhc3NlZCgnYnRuLWxheWVyJywgdHJ1ZSk7XHJcbiAgICAgICAgICAgICAgICBsZXQgYmFja0J0blRyYW5zbGF0ZVBvc2l0aW9uOiBzdHJpbmcgPSAnJztcclxuICAgICAgICAgICAgICAgIGlmICh0aGlzLmNoYXJ0VHlwZVsxXSAhPT0gJ2Z1bGwnKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgYmFja0J0blRyYW5zbGF0ZVBvc2l0aW9uID0gJ3RyYW5zbGF0ZSgnICsgKHRoaXMuX3dpZHRoIC0gMTAwKSArICcsJyArICh0aGlzLl9oZWlnaHQgLyAzKSArICcpJztcclxuICAgICAgICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgICAgICAgICAgYmFja0J0blRyYW5zbGF0ZVBvc2l0aW9uID0gJ3RyYW5zbGF0ZSgnICsgKHRoaXMuX3dpZHRoIC0gMTAwIC0gcGFyc2VJbnQodGhpcy5fZnVsbEdyYXBoLm5vZGUoKS5zdHlsZS5sZWZ0KSkgKyAnLCcgKyAodGhpcy5faGVpZ2h0IC8gMyAtIHBhcnNlSW50KHRoaXMuX2Z1bGxHcmFwaC5ub2RlKCkuc3R5bGUudG9wKSkgKyAnKSc7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICBsZXQgYmFja0J0biA9IHRoaXMuX2JhY2tCdG4uc2VsZWN0QWxsKCdnJylcclxuICAgICAgICAgICAgICAgICAgICAuZGF0YShbJ2JhY2tCdG4nXSlcclxuICAgICAgICAgICAgICAgICAgICAuZW50ZXIoKS5hcHBlbmQoJ2cnKVxyXG4gICAgICAgICAgICAgICAgICAgIC5hdHRyKCdpZCcsIGZ1bmN0aW9uKGQpIHsgcmV0dXJuIGQ7IH0pXHJcbiAgICAgICAgICAgICAgICAgICAgLmF0dHIoJ3RyYW5zZm9ybScsIChkLCBpKSA9PiB7IHJldHVybiBiYWNrQnRuVHJhbnNsYXRlUG9zaXRpb247IH0pXHJcbiAgICAgICAgICAgICAgICAgICAgLnN0eWxlKCdjdXJzb3InLCAncG9pbnRlcicpXHJcbiAgICAgICAgICAgICAgICAgICAgLnN0eWxlKCdwb2ludGVyLWV2ZW50cycsICd2aXNpYmxlJylcclxuICAgICAgICAgICAgICAgICAgICAub24oJ2NsaWNrJywgKGQpID0+IHsgdGhpcy5fY2hhbmdlTGV2ZWwodGhpcy5fbGV2ZWwsICdtaW51cycpOyB9KTtcclxuICAgICAgICAgICAgICAgIGJhY2tCdG4uYXBwZW5kKCdyZWN0JylcclxuICAgICAgICAgICAgICAgICAgICAuYXR0cignd2lkdGgnLCAnNTZweCcpXHJcbiAgICAgICAgICAgICAgICAgICAgLmF0dHIoJ2hlaWdodCcsICczMHB4JylcclxuICAgICAgICAgICAgICAgICAgICAuc3R5bGUoJ2ZpbGwnLCAncmdiKDI0NywgMjQ3LCAyNDcpJylcclxuICAgICAgICAgICAgICAgICAgICAuc3R5bGUoJ3N0cm9rZScsICdyZ2IoMjA0LCAyMDQsIDIwNCknKVxyXG4gICAgICAgICAgICAgICAgICAgIC5zdHlsZSgnc3Ryb2tlLXdpZHRoJywgJzEnKTtcclxuICAgICAgICAgICAgICAgIGJhY2tCdG4uYXBwZW5kKCd0ZXh0JylcclxuICAgICAgICAgICAgICAgICAgICAuYXR0cigneCcsIDI4KVxyXG4gICAgICAgICAgICAgICAgICAgIC5hdHRyKCd5JywgMTUpXHJcbiAgICAgICAgICAgICAgICAgICAgLmF0dHIoJ2R5JywgJy4zNWVtJylcclxuICAgICAgICAgICAgICAgICAgICAuYXR0cigndGV4dC1hbmNob3InLCAnbWlkZGxlJylcclxuICAgICAgICAgICAgICAgICAgICAuc3R5bGUoJ2ZvbnQtc2l6ZScsICcxMnB4JylcclxuICAgICAgICAgICAgICAgICAgICAuc3R5bGUoJ2ZvbnQtd2VpZ2h0JywgJ25vcm1hbCcpXHJcbiAgICAgICAgICAgICAgICAgICAgLnRleHQoZnVuY3Rpb24oZCwgaSkgeyByZXR1cm4gdGhpcy5pc1J0bCA/ICdCYWNrIOKWtycgOiAn4peBIEJhY2snOyB9KTtcclxuICAgICAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgICAgIHRoaXMuX2JhY2tCdG4gPSB0aGlzLnN2Z0NvbnRhaW5lci5hcHBlbmQoJ2RpdicpXHJcbiAgICAgICAgICAgICAgICB0aGlzLl9iYWNrQnRuLmF0dHIoJ2NsYXNzJywgJ2tkeC1tYXAtY2hhcnQtYmFja2J1dHRvbicpXHJcbiAgICAgICAgICAgICAgICB0aGlzLl9iYWNrQnRuLnRleHQoZnVuY3Rpb24oZCwgaSkgeyByZXR1cm4gdGhpcy5pc1J0bCA/ICdCYWNrIOKWtycgOiAn4peBIEJhY2snOyB9KVxyXG4gICAgICAgICAgICAgICAgdGhpcy5fYmFja0J0bi5vbignY2xpY2snLCAoZCkgPT4geyB0aGlzLl9jaGFuZ2VMZXZlbCh0aGlzLl9sZXZlbCwgJ21pbnVzJyk7IH0pO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfSlcclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF9jaGVja0JhY2tCdG4oKTogdm9pZCB7XHJcbiAgICAgICAgbGV0IGNoZWNrRGVmYXVsdExldmVsID0gdGhpcy5fY2hlY2tEZWZhdWx0TGV2ZWwoKTtcclxuICAgICAgICBpZiAoY2hlY2tEZWZhdWx0TGV2ZWwgPT0gdHJ1ZSkge1xyXG4gICAgICAgICAgICBpZiAodHlwZW9mIHRoaXMuX2JhY2tCdG4gPT09ICd1bmRlZmluZWQnKSB0aGlzLl9pbml0QmFja0J0bigpO1xyXG4gICAgICAgIH1cclxuICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgaWYgKHR5cGVvZiB0aGlzLl9iYWNrQnRuICE9PSAndW5kZWZpbmVkJykge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5fYmFja0J0bi5yZW1vdmUoKTtcclxuICAgICAgICAgICAgICAgIHRoaXMuX2JhY2tCdG4gPSB1bmRlZmluZWQ7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfY2hlY2tEZWZhdWx0TGV2ZWwoKTogYm9vbGVhbiB7XHJcbiAgICAgICAgbGV0IGNoZWNrRGVmYXVsdDogYm9vbGVhbjtcclxuICAgICAgICBsZXQgZGVmYXVsdExldmVsID0gdGhpcy5fZGVmYXVsdExldmVsLmluZGV4T2YoJ18nKSAhPSAtMSA/IHRoaXMuX2RlZmF1bHRMZXZlbC5zcGxpdCgnXycpWzFdIDogdGhpcy5fZGVmYXVsdExldmVsO1xyXG4gICAgICAgIGlmICh0aGlzLl9sZXZlbC5pbmRleE9mKCdfJykgIT0gLTEpIHtcclxuICAgICAgICAgICAgY2hlY2tEZWZhdWx0ID0gcGFyc2VJbnQodGhpcy5fbGV2ZWwuc3BsaXQoJ18nKVsxXSkgPT0gZGVmYXVsdExldmVsID8gZmFsc2UgOiB0cnVlO1xyXG4gICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgIGNoZWNrRGVmYXVsdCA9IHBhcnNlSW50KHRoaXMuX2xldmVsKSA9PSBkZWZhdWx0TGV2ZWwgPyBmYWxzZSA6IHRydWU7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIHJldHVybiBjaGVja0RlZmF1bHQ7XHJcbiAgICB9XHJcblxyXG5cclxuXHJcbiAgICBwcml2YXRlIF9nZXRTZXJpZXNWYWx1ZShfc2VyaWVzSWQpIHtcclxuICAgICAgICBsZXQgcmV0dXJuT2JqID0ge1xyXG4gICAgICAgICAgICAnaWQnOiAnJyxcclxuICAgICAgICAgICAgJ25hbWUnOiAnJyxcclxuICAgICAgICAgICAgJ2RyaWxsZG93bic6ICcnLFxyXG4gICAgICAgICAgICAndmFsdWUnOiAnJ1xyXG4gICAgICAgIH07XHJcbiAgICAgICAgZm9yIChsZXQgaSA9IDA7IGkgPCB0aGlzLl9zZXJpZXNQb2ludGVyLmRhdGEubGVuZ3RoOyBpKyspIHtcclxuICAgICAgICAgICAgaWYgKHRoaXMuX3Nlcmllc1BvaW50ZXIuZGF0YVtpXS5JRF8gPT0gX3Nlcmllc0lkKSB7XHJcbiAgICAgICAgICAgICAgICByZXR1cm5PYmouaWQgPSB0aGlzLl9zZXJpZXNQb2ludGVyLmRhdGFbaV0uSURfO1xyXG4gICAgICAgICAgICAgICAgcmV0dXJuT2JqLm5hbWUgPSB0aGlzLl9zZXJpZXNQb2ludGVyLmRhdGFbaV0uTkFNRTFfO1xyXG4gICAgICAgICAgICAgICAgcmV0dXJuT2JqLmRyaWxsZG93biA9IHRoaXMuX3Nlcmllc1BvaW50ZXIuZGF0YVtpXS5kcmlsbGRvd247XHJcbiAgICAgICAgICAgICAgICByZXR1cm5PYmoudmFsdWUgPSB0aGlzLl9zZXJpZXNQb2ludGVyLmRhdGFbaV0udmFsdWU7XHJcbiAgICAgICAgICAgICAgICBicmVhaztcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgICAgICByZXR1cm4gcmV0dXJuT2JqO1xyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX2dldE5ld1NlcmllcyhfbmV3TGVnZW5kPzogYW55KTogdm9pZCB7XHJcbiAgICAgICAgbGV0IGxlZ2VuZFBvaW50ZXIgPSBfbmV3TGVnZW5kID8gX25ld0xlZ2VuZCA6IHRoaXMubGVnZW5kO1xyXG4gICAgICAgIGxldCB0ZW1wTGVnZW5kQXJyID0gT2JqZWN0LmtleXMobGVnZW5kUG9pbnRlcikubWFwKGtleSA9PiB7IHJldHVybiBsZWdlbmRQb2ludGVyW2tleV07IH0pO1xyXG4gICAgICAgIGxldCBuZXdUZW1wU2VyaWVzID0gW107XHJcbiAgICAgICAgZm9yIChsZXQgaSA9IDA7IGkgPCB0ZW1wTGVnZW5kQXJyLmxlbmd0aDsgaSsrKSB7XHJcbiAgICAgICAgICAgIGZvciAobGV0IGogPSAwOyBqIDwgdGhpcy5fc2VyaWVzRGF0YS5sZW5ndGg7IGorKykge1xyXG4gICAgICAgICAgICAgICAgaWYgKHRlbXBMZWdlbmRBcnJbaV0uZGVhY3RpdmUgPT0gZmFsc2UgJiYgdGhpcy5fc2VyaWVzRGF0YVtqXS5pZCA9PSB0ZW1wTGVnZW5kQXJyW2ldLm1hcFNlcmllc0lkKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgbmV3VGVtcFNlcmllcy5wdXNoKHRoaXMuX3Nlcmllc0RhdGFbal0pO1xyXG4gICAgICAgICAgICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgICAgIHRoaXMuX2VtcHR5U2VyaWVzID0gbmV3VGVtcFNlcmllcy5sZW5ndGggIT0gMCA/IGZhbHNlIDogdHJ1ZTtcclxuICAgICAgICBpZiAobmV3VGVtcFNlcmllcy5sZW5ndGggIT0gMCkgeyB0aGlzLl9zZXJpZXNQb2ludGVyID0gbmV3VGVtcFNlcmllc1tuZXdUZW1wU2VyaWVzLmxlbmd0aCAtIDFdOyB9XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfZ2V0RHJpbGxEb3duTGVnZW5kRm9yTXVsdGlwbGVEaW1lbnNpb24oKTogdm9pZCB7XHJcbiAgICAgICAgbGV0IHRlbXBMZWdlbmQ7XHJcbiAgICAgICAgaWYgKHRoaXMuX2NoZWNrRGVmYXVsdExldmVsKCkgPT0gdHJ1ZSkge1xyXG4gICAgICAgICAgICB0ZW1wTGVnZW5kID0gdGhpcy5fY2hhcnRTdmMuc2V0TWFwTGVnZW5kRGF0YSh0aGlzLmxlZ2VuZCwgW3RoaXMuX3Nlcmllc1BvaW50ZXJdLCB0aGlzLmNvbmZpZyk7XHJcbiAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgdGVtcExlZ2VuZCA9IHRoaXMuX2NoYXJ0U3ZjLnNldE1hcExlZ2VuZERhdGEodGhpcy5sZWdlbmQsIHRoaXMuX3Nlcmllc0RhdGEsIHRoaXMuY29uZmlnKTtcclxuICAgICAgICAgICAgdGhpcy5fZ2V0TmV3U2VyaWVzKHRlbXBMZWdlbmQpO1xyXG4gICAgICAgIH1cclxuICAgICAgICB0aGlzLm91dHB1dExlZ2VuZC5lbWl0KHRlbXBMZWdlbmQpO1xyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX2dldENvbG9yUG9pbnRlcigpOiB2b2lkIHtcclxuICAgICAgICAvLyBsZXQgdGVtcExlZ2VuZEFyciA9IE9iamVjdC5rZXlzKHRoaXMubGVnZW5kKS5tYXAoaXRlbSA9PiB0aGlzLmxlZ2VuZFtpdGVtXSk7XHJcbiAgICAgICAgbGV0IHRlbXBMZWdlbmRBcnIgPSBPYmplY3Qua2V5cyh0aGlzLmxlZ2VuZERhdGEpLm1hcChpdGVtID0+IHRoaXMubGVnZW5kRGF0YVtpdGVtXSk7XHJcbiAgICAgICAgaWYgKHRoaXMuX3Nlcmllc1BvaW50ZXIgIT0gdW5kZWZpbmVkKSB7XHJcbiAgICAgICAgICAgIGZvciAobGV0IGkgPSAwOyBpIDwgdGVtcExlZ2VuZEFyci5sZW5ndGg7IGkrKykge1xyXG4gICAgICAgICAgICAgICAgaWYgKHRoaXMuX3Nlcmllc1BvaW50ZXIuaWQgPT0gdGVtcExlZ2VuZEFycltpXS5tYXBTZXJpZXNJZCkge1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuX2NvbG9yUG9pbnRlciA9IHRoaXMubGVnZW5kRGF0YVt0ZW1wTGVnZW5kQXJyW2ldLmlkXTtcclxuICAgICAgICAgICAgICAgICAgICAvLyB0aGlzLl9jb2xvclBvaW50ZXIgPSB0aGlzLmxlZ2VuZFt0ZW1wTGVnZW5kQXJyW2ldLmlkXTtcclxuICAgICAgICAgICAgICAgICAgICBicmVhaztcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF9vdmVyV3JpdGVTZXJpZXMoKTogdm9pZCB7XHJcbiAgICAgICAgLy8gY2hhbmdlIHNlcmllcyBjb2xvclxyXG4gICAgICAgIGxldCB0ZW1wTGVnZW5kQXJyID0gT2JqZWN0LmtleXModGhpcy5sZWdlbmREYXRhKS5tYXAoaXRlbSA9PiB0aGlzLmxlZ2VuZERhdGFbaXRlbV0pO1xyXG4gICAgICAgIC8vIGxldCB0ZW1wTGVnZW5kQXJyID0gT2JqZWN0LmtleXModGhpcy5sZWdlbmQpLm1hcChpdGVtID0+IHRoaXMubGVnZW5kW2l0ZW1dKTtcclxuICAgICAgICBmb3IgKGxldCBpID0gMDsgaSA8IHRlbXBMZWdlbmRBcnIubGVuZ3RoOyBpKyspIHtcclxuICAgICAgICAgICAgZm9yIChsZXQgaiA9IDA7IGogPCB0aGlzLl9zZXJpZXNEYXRhLmxlbmd0aDsgaisrKSB7XHJcbiAgICAgICAgICAgICAgICBpZiAodGhpcy5fc2VyaWVzRGF0YVtqXS5pZCA9PSB0ZW1wTGVnZW5kQXJyW2ldLm1hcFNlcmllc0lkKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5fc2VyaWVzRGF0YVtqXS5jb2xvciA9IHRlbXBMZWdlbmRBcnJbaV0uY29sb3I7XHJcbiAgICAgICAgICAgICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfZ2V0TGVnZW5kQnlUeXBlKCk6IHZvaWQge1xyXG4gICAgICAgIC8vIGNoZWNrIHR5cGUgb2YgZGltZW5zaW9ucyB3aGV0aGVyIGlzIHNpbmdsZSBvciBtdWx0aXBsZVxyXG4gICAgICAgIGlmICghdGhpcy5jb25maWcuc2tpcE1hc3NhZ2UpIHtcclxuICAgICAgICAgICAgdGhpcy5fc2luZ2xlTGV2ZWxEaW1lbnNpb24gPSBmYWxzZTtcclxuICAgICAgICAgICAgaWYgKHRoaXMuY29uZmlnLmNvbG9yQXhpcyAhPSB1bmRlZmluZWQpIHtcclxuICAgICAgICAgICAgICAgIGlmICh0aGlzLmNvbmZpZy5jb2xvckF4aXMuZGF0YUNsYXNzZXMgJiYgdGhpcy5jb25maWcuY29sb3JBeGlzLmRhdGFDbGFzc2VzLmxlbmd0aCAhPT0gMCkge1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuX3NpbmdsZUxldmVsRGltZW5zaW9uID0gdHJ1ZTtcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLmxlZ2VuZCA9IHRoaXMuX2NoYXJ0U3ZjLnNldFNpbmdsZUxlZ2VuZExldmVscyh0aGlzLmNvbmZpZy5jb2xvckF4aXMuZGF0YUNsYXNzZXMsIHRoaXMuY29uZmlnLmxlZ2VuZC52YWx1ZURlY2ltYWxzLCB0aGlzLmNvbmZpZy5sZWdlbmQudmFsdWVTdWZmaXgsIHRoaXMubGVnZW5kKTtcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLm91dHB1dExlZ2VuZC5lbWl0KHRoaXMubGVnZW5kKTtcclxuICAgICAgICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5vdXRwdXRMZWdlbmQuZW1pdCh7fSk7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgICAgICAvLyBtdWx0aSBkaW1lbnNpb24gbGVnZW5kXHJcbiAgICAgICAgICAgICAgICB0aGlzLmxlZ2VuZCA9IHRoaXMuX2NoYXJ0U3ZjLnNldE1hcExlZ2VuZERhdGEodGhpcy5sZWdlbmQsIHRoaXMuX3Nlcmllc0RhdGEsIHRoaXMuY29uZmlnKTtcclxuICAgICAgICAgICAgICAgIHRoaXMub3V0cHV0TGVnZW5kLmVtaXQodGhpcy5sZWdlbmQpO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgLy8gb3V0cHV0IGxlZ2VuZCBvbmx5IGZvciBleHBvcnRpbmdcclxuICAgICAgICAgICAgdGhpcy5fc2luZ2xlTGV2ZWxEaW1lbnNpb24gPSBmYWxzZTtcclxuICAgICAgICAgICAgaWYgKHRoaXMuY29uZmlnLmNvbG9yQXhpcyAhPSB1bmRlZmluZWQpIHtcclxuICAgICAgICAgICAgICAgIGlmICh0aGlzLmNvbmZpZy5jb2xvckF4aXMuZGF0YUNsYXNzZXMgJiYgdGhpcy5jb25maWcuY29sb3JBeGlzLmRhdGFDbGFzc2VzLmxlbmd0aCAhPT0gMCkge1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuX3NpbmdsZUxldmVsRGltZW5zaW9uID0gdHJ1ZTtcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLm91dHB1dExlZ2VuZC5lbWl0KHRoaXMubGVnZW5kKTtcclxuICAgICAgICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5vdXRwdXRMZWdlbmQuZW1pdCh7fSk7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLm91dHB1dExlZ2VuZC5lbWl0KHRoaXMubGVnZW5kKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF9zZXRNYXBTY2FsZVRyaWFuZ2xlKF92YWx1ZTogbnVtYmVyKTogdm9pZCB7XHJcbiAgICAgICAgbGV0IHNpZ246IG51bWJlciA9IHRoaXMuaXNSdGwgPyAtMSA6IDE7XHJcbiAgICAgICAgdGhpcy5fbWFwU3ZjLnRyYW5zbGF0ZU1hcFNjYWxlVHJpYW5nbGUoc2lnbiAqIHRoaXMuX21hcFN2Yy52YWx1ZVNjYWxlKF92YWx1ZSkpO1xyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX3JlbW92ZU1hcFNjYWxlVHJpYW5nbGUoKTogdm9pZCB7XHJcbiAgICAgICAgbGV0IHRyaWFuZ2xlSW5pdFBvaXN0aW9uOiBudW1iZXIgPSB0aGlzLmlzUnRsID8gOTk5IDogLTk5OTtcclxuICAgICAgICB0aGlzLl9tYXBTdmMudHJhbnNsYXRlTWFwU2NhbGVUcmlhbmdsZSh0cmlhbmdsZUluaXRQb2lzdGlvbik7XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfY2hlY2tFbXB0eURhdGFWYWx1ZShfdmFsdWU6IGFueSk6IGJvb2xlYW4ge1xyXG4gICAgICAgIGlmICh0aGlzLl9zZXJpZXNQb2ludGVyLmRhdGEgPT0gdW5kZWZpbmVkKSB7XHJcbiAgICAgICAgICAgIHJldHVybiBmYWxzZTtcclxuICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICBsZXQgZGF0YVZhbHVlID0gdGhpcy5fZ2V0U2VyaWVzVmFsdWUoX3ZhbHVlKS52YWx1ZTtcclxuICAgICAgICAgICAgaWYgKGRhdGFWYWx1ZSA9PSB1bmRlZmluZWQpIHJldHVybiBmYWxzZTtcclxuICAgICAgICAgICAgZWxzZSBpZiAoZGF0YVZhbHVlICE9IG51bGwgJiYgZGF0YVZhbHVlICE9ICcnKSByZXR1cm4gdHJ1ZTtcclxuICAgICAgICAgICAgZWxzZSByZXR1cm4gZmFsc2U7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIC8qKlxyXG4gICAgICogZHJhd2luZyBjb2xvciBzY2FsZSBvZiBtYXBcclxuICAgICAqL1xyXG4gICAgcHJpdmF0ZSBfZHJhd01hcFNjYWxlKCk6IHZvaWQge1xyXG4gICAgICAgIC8vIG1heCBhbmQgbWluIGNvbG9yc1xyXG4gICAgICAgIGxldCBjb2xvclJhbmdlOiBzdHJpbmdbXSA9IFt0aGlzLmNvbmZpZy5jb2xvckF4aXMubWluQ29sb3IsIHRoaXMuY29uZmlnLmNvbG9yQXhpcy5tYXhDb2xvcl07XHJcbiAgICAgICAgLy8gdGhlIGFjdHVhbCBsZW5ndGggb2YgYmFyIGluIHB4LiBjdXJyZW50bHkgaGFyZHNldCB0byAyMDA7XHJcbiAgICAgICAgbGV0IGxlbmd0aFJhbmdlOiBudW1iZXJbXSA9IFswLCAyMDBdO1xyXG4gICAgICAgIC8vIGFycmF5IG9mIHRpY2sgaW50ZXJ2YWxzXHJcbiAgICAgICAgbGV0IHRpY2tBcnI6IG51bWJlcltdID0gdGhpcy5fbWFwU3ZjLmdldExlZ2VuZEludGVydmFscyh0aGlzLmNvbmZpZy5jb2xvckF4aXMubWluLCB0aGlzLmNvbmZpZy5jb2xvckF4aXMubWF4KTtcclxuICAgICAgICBsZXQgbm9PZkludGVydmFsOiBudW1iZXIgPSB0aWNrQXJyLmxlbmd0aCAtIDE7XHJcbiAgICAgICAgbGV0IHNjYWxlRG9tYWluOiBudW1iZXJbXSA9IFt0aWNrQXJyWzBdLCB0aWNrQXJyW25vT2ZJbnRlcnZhbF1dO1xyXG4gICAgICAgIGxldCBhcnIgPSBkMy5yYW5nZShub09mSW50ZXJ2YWwpO1xyXG4gICAgICAgIGxldCBsaW5lYXJHcmFkaWVudERpcmVjdGlvbjogJ3RvIGxlZnQnIHwgJ3RvIHJpZ2h0JyA9IHRoaXMuaXNSdGwgPyAndG8gbGVmdCcgOiAndG8gcmlnaHQnO1xyXG5cclxuICAgICAgICAvLyBjb2xvciBzY2FsZSBhY2NvcmRpbmcgdG8gdGlja0FyciwgY2FuIGJlIHVzZWQgdG8gY29sb3IgdGhlIG1hcC4gdG8gdXNlIGp1c3QgY2FsbCBjb2xvclNjYWxlKHZhbHVlKVxyXG4gICAgICAgIHRoaXMuX21hcFNjYWxlQ29sb3JTY2FsZSA9IHRoaXMuX21hcFN2Yy5zZXRTY2FsZShzY2FsZURvbWFpbiwgY29sb3JSYW5nZSk7XHJcbiAgICAgICAgLy8gdmFsdWUgc2NhbGUgYWNjb3JkaW5nIHRvIHRpY2tBcnIsIHVzZWQgdG8gcG9zaXRpb24gdHJpYW5nbGUgd2hlbiBob3ZlcmVkLCBzYXZlIHRoZSB2YWx1ZVNjYWxlIGluIG1hcCBzZXJ2aWNlIGNsYXNzXHJcbiAgICAgICAgdGhpcy5fbWFwU3ZjLnZhbHVlU2NhbGUgPSB0aGlzLl9tYXBTdmMuc2V0U2NhbGUoc2NhbGVEb21haW4sIGxlbmd0aFJhbmdlKTtcclxuXHJcbiAgICAgICAgbGV0IG1hcFNjYWxlV3JhcHBlciA9IGQzLnNlbGVjdCgnIycgKyB0aGlzLmNvbmZpZy5pZCArICcua2R4LWNoYXJ0cyAua2R4LW1hcC1zY2FsZS13cmFwcGVyJyk7XHJcblxyXG4gICAgICAgIGxldCBtYXBTY2FsZSA9IG1hcFNjYWxlV3JhcHBlci5zZWxlY3QoJyNtYXBTY2FsZScpO1xyXG4gICAgICAgIG1hcFNjYWxlLnN0eWxlKCdiYWNrZ3JvdW5kJywgJ2xpbmVhci1ncmFkaWVudCgnICsgbGluZWFyR3JhZGllbnREaXJlY3Rpb24gKyAnLCcgKyBjb2xvclJhbmdlWzBdICsgJywnICsgY29sb3JSYW5nZVsxXSArICcpJyk7XHJcblxyXG4gICAgICAgIHRoaXMuX21hcFN2Yy5tYXBTY2FsZVRyaWFuZ2xlID0gbWFwU2NhbGVXcmFwcGVyLnNlbGVjdCgnLmtkeC1tYXAtc2NhbGUtdHJpYW5nbGUnKTtcclxuXHJcbiAgICAgICAgbWFwU2NhbGUuc2VsZWN0QWxsKCcua2R4LW1hcC1zY2FsZS1yZWN0JylcclxuICAgICAgICAgICAgLmRhdGEoYXJyKVxyXG4gICAgICAgICAgICAuZW50ZXIoKS5hcHBlbmQoJ2RpdicpXHJcbiAgICAgICAgICAgIC5hdHRyKCdjbGFzcycsICdrZHgtbWFwLXNjYWxlLXJlY3QnKVxyXG4gICAgICAgICAgICAuYXR0cignaWQnLCAoZCkgPT4gJ3JlY3QtJyArIGQpXHJcbiAgICAgICAgICAgIC5zdHlsZSgnd2lkdGgnLCAxMDAgLyBub09mSW50ZXJ2YWwgKyAnJScpO1xyXG5cclxuICAgICAgICBtYXBTY2FsZVdyYXBwZXIuc2VsZWN0KCcua2R4LW1hcC1zY2FsZS10ZXh0LWNvbnRhaW5lcicpXHJcbiAgICAgICAgICAgIC5zZWxlY3RBbGwoJy5rZHgtbWFwLXNjYWxlLXRleHQnKVxyXG4gICAgICAgICAgICAuZGF0YSh0aWNrQXJyKVxyXG4gICAgICAgICAgICAuZW50ZXIoKS5hcHBlbmQoJ2RpdicpXHJcbiAgICAgICAgICAgIC5hdHRyKCdjbGFzcycsICdrZHgtbWFwLXNjYWxlLXRleHQnKVxyXG4gICAgICAgICAgICAuYXR0cignaWQnLCAoZCkgPT4gJ3RleHQtJyArIGQpXHJcbiAgICAgICAgICAgIC5odG1sKGQgPT4gZCk7XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfc2V0TWFya2VycygpOiB2b2lkIHtcclxuICAgICAgICBpZiAodGhpcy5jaGFydFR5cGVbMV0gPT09ICdjbHVzdGVyJykgdGhpcy5vdXRwdXRMZWdlbmQuZW1pdCh7fSk7XHJcbiAgICAgICAgbGV0IGNsdXN0ZXJUeXBlOiBzdHJpbmcgPSB0aGlzLmNvbmZpZy5wbG90T3B0aW9ucy5tYXAuY2x1c3RlclR5cGUgPyB0aGlzLmNvbmZpZy5wbG90T3B0aW9ucy5tYXAuY2x1c3RlclR5cGUgOiAnY2x1c3Rlcic7XHJcbiAgICAgICAgdGhpcy5fY2x1c3RlckRhdGEgPSB0aGlzLl9tYXBTdmMucG9wdWxhdGVNYXJrZXJzKHRoaXMuZGF0YS5wb2ludERhdGEsIHRoaXMuX2xlYWZsZXRNYXAsIGNsdXN0ZXJUeXBlKTtcclxuICAgICAgICB0aGlzLm91dHB1dE1hcmtlci5lbWl0KHRoaXMuX2NsdXN0ZXJEYXRhLm1hcmtlcnNMZWdlbmQpO1xyXG4gICAgICAgIC8vIHRoaXMuX2lzTWFya2VyTG9hZGVkID0gdHJ1ZTtcclxuICAgICAgICAvLyB9XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfc2V0TGF5ZXIoKTogdm9pZCB7XHJcbiAgICAgICAgaWYgKHRoaXMuX2xheWVyKSB0aGlzLl9sYXllci5yZW1vdmUoKTtcclxuICAgICAgICBpZiAodGhpcy5tYXBDb25maWcucGxvdE9wdGlvbnMubWFwLnpvb20pIHRoaXMuX2NoZWNrWm9vbUNvbmZpZyh0aGlzLm1hcENvbmZpZy5wbG90T3B0aW9ucy5tYXAuem9vbSk7XHJcbiAgICAgICAgdGhpcy5fbGF5ZXIgPSBMLnRpbGVMYXllcignaHR0cHM6Ly97c30udGlsZS5vcGVuc3RyZWV0bWFwLm9yZy97en0ve3h9L3t5fS5wbmcnLCB7XHJcbiAgICAgICAgICAgIGF0dHJpYnV0aW9uOiAnJmNvcHk7IDxhIGhyZWY9XCJodHRwOi8vd3d3Lm9wZW5zdHJlZXRtYXAub3JnL2NvcHlyaWdodFwiPk9wZW5TdHJlZXRNYXA8L2E+JyxcclxuICAgICAgICAgICAgbWF4Wm9vbTogMTgsXHJcbiAgICAgICAgfSkuYWRkVG8odGhpcy5fbGVhZmxldE1hcCk7XHJcbiAgICAgICAgdGhpcy5fYXR0YWNoVGlsZUxpc3RlbmVyKCk7XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfY2hlY2tab29tQ29uZmlnKF9jb25maWc6IGFueSk6IHZvaWQge1xyXG4gICAgICAgIGlmICh0eXBlb2YgdGhpcy5fbGVhZmxldE1hcCAhPT0gJ3VuZGVmaW5lZCcpIHtcclxuICAgICAgICAgICAgX2NvbmZpZy5pc1pvb21CdXR0b24gPyB0aGlzLl9sZWFmbGV0TWFwLmFkZENvbnRyb2wodGhpcy5fbGVhZmxldE1hcC56b29tQ29udHJvbCkgOiB0aGlzLl9sZWFmbGV0TWFwLnJlbW92ZUNvbnRyb2wodGhpcy5fbGVhZmxldE1hcC56b29tQ29udHJvbCk7XHJcbiAgICAgICAgICAgIF9jb25maWcuaXNTY3JvbGxab29tID8gdGhpcy5fbGVhZmxldE1hcC5zY3JvbGxXaGVlbFpvb20uZW5hYmxlKCkgOiB0aGlzLl9sZWFmbGV0TWFwLnNjcm9sbFdoZWVsWm9vbS5kaXNhYmxlKCk7XHJcbiAgICAgICAgICAgIF9jb25maWcuaXNUb3VjaFpvb20gPyB0aGlzLl9sZWFmbGV0TWFwLnRvdWNoWm9vbS5lbmFibGUoKSA6IHRoaXMuX2xlYWZsZXRNYXAudG91Y2hab29tLmRpc2FibGUoKTtcclxuICAgICAgICAgICAgX2NvbmZpZy5pc0RvdWJsZUNsaWNrWm9vbSA/IHRoaXMuX2xlYWZsZXRNYXAuZG91YmxlQ2xpY2tab29tLmVuYWJsZSgpIDogdGhpcy5fbGVhZmxldE1hcC5kb3VibGVDbGlja1pvb20uZGlzYWJsZSgpO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF9yZW1vdmVEZWZhdWx0QXR0cmlidXRpb24oX2F0dHJpYnV0aW9uOiBzdHJpbmcpOiB2b2lkIHtcclxuICAgICAgICBsZXQgYXR0cmlidXRpb25FbGVtZW50OiBFbGVtZW50ID0gZG9jdW1lbnQucXVlcnlTZWxlY3RvcignLmxlYWZsZXQtY29udHJvbC1hdHRyaWJ1dGlvbicpO1xyXG4gICAgICAgIGlmIChhdHRyaWJ1dGlvbkVsZW1lbnQgIT09IG51bGwpIHtcclxuICAgICAgICAgICAgbGV0IG5ld0F0dHJpYnV0aW9uRWxlbWVudDogSFRNTEVsZW1lbnQgPSB0aGlzLl9kb21TdmMuY3JlYXRlRWxlbWVudChhdHRyaWJ1dGlvbkVsZW1lbnQsICdjdXN0b20tYXR0cmlidXRpb24nKTtcclxuICAgICAgICAgICAgbmV3QXR0cmlidXRpb25FbGVtZW50LmlubmVyVGV4dCA9IF9hdHRyaWJ1dGlvbiB8fCAnT3BlbkVNSVMnO1xyXG4gICAgICAgICAgICBhdHRyaWJ1dGlvbkVsZW1lbnQucmVwbGFjZUNoaWxkKG5ld0F0dHJpYnV0aW9uRWxlbWVudCwgYXR0cmlidXRpb25FbGVtZW50LmZpcnN0Q2hpbGQpO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF9hdHRhY2hUaWxlTGlzdGVuZXIoKTogdm9pZCB7XHJcbiAgICAgICAgLyogQ2hlY2tzIGV2ZXJ5IHRpbGUuIE9ubHkgY2FsbGVkIHdoZW4gc29tZSB0aWxlIGxvYWQgaGFzIGZhaWxlZC4gKi9cclxuICAgICAgICB0aGlzLl9sYXllci5vbigndGlsZWVycm9yJywgKGVycm9yKTogdm9pZCA9PiB7XHJcbiAgICAgICAgICAgIC8vIG9ubHkgZXhlY3V0ZSB0aGUgZm9sbG93aW5nIGZvciB0aGUgZmlyc3QgdGlsZSBlcnJvclxyXG4gICAgICAgICAgICBpZiAoIXRoaXMuX2lzTGF5ZXJFcnJvcikge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5faXNMYXllckVycm9yID0gdHJ1ZTtcclxuICAgICAgICAgICAgICAgIHRoaXMuX2xheWVyUmVsb2FkVGltZXMrKztcclxuICAgICAgICAgICAgICAgIGlmICh0aGlzLl9sYXllclJlbG9hZFRpbWVzIDwgMSB8fCB0aGlzLl9sYXllclJlbG9hZFRpbWVzID09PSAxKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5fc2V0TGF5ZXIoKTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIGlmICh0aGlzLl9sYXllclJlbG9hZFRpbWVzID4gNSkge1xyXG4gICAgICAgICAgICAgICAgICAgIC8vIHRoaXMuaXNNYXBTaG93biA9IGZhbHNlO1xyXG4gICAgICAgICAgICAgICAgICAgIC8vIHRoaXMuZXJyb3JNZXNzYWdlID0gJ01heCByZXRyeSByZWFjaGVkLiBNYXAgY2Fubm90IGJlIGxvYWRlZCBub3cuIFBsZWFzZSBjaGVjayB5b3VyIGludGVybmV0IGNvbm5lY3Rpb24gb3IgdHJ5IGFnYWluIGxhdGVyLic7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9KTtcclxuXHJcbiAgICAgICAgLyogQ2hlY2tzIGV2ZXJ5IHRpbGUuIE9ubHkgY2FsbGVkIHdoZW4gZWFjaCB0aWxlIGxvYWQgaXMgc3VjY2Vzc2Z1bC4gKi9cclxuICAgICAgICB0aGlzLl9sYXllci5vbigndGlsZWxvYWQnLCAoKTogdm9pZCA9PiB7XHJcbiAgICAgICAgICAgIHRoaXMuX3RpbGVsb2FkSW5kZXgrKztcclxuICAgICAgICAgICAgaWYgKHRoaXMuX3RpbGVsb2FkSW5kZXggPT09IE9iamVjdC5rZXlzKHRoaXMuX2xheWVyLl90aWxlcykubGVuZ3RoKSB7XHJcbiAgICAgICAgICAgICAgICAvLyBvbmx5IHN0b3AgcHJvZ3Jlc3MgbG9hZGVyIHdoZW4gbGFzdCB0aWxlIGxvYWRlZCBzdWNjZXNzZnVsbHlcclxuICAgICAgICAgICAgICAgIC8vIHRoaXMuaXNMYXllckxvYWRpbmcgPSBmYWxzZTtcclxuICAgICAgICAgICAgICAgIC8vIHRoaXMuX2lzVGlsZXNMb2FkZWQgPSB0cnVlO1xyXG4gICAgICAgICAgICAgICAgdGhpcy5vdXRwdXRSZWFkeS5lbWl0KGZhbHNlKTtcclxuXHJcbiAgICAgICAgICAgICAgICAvLyByZXNldCBjb3VudGVyc1xyXG4gICAgICAgICAgICAgICAgLy8gdGhpcy5fbGF5ZXJSZWxvYWRUaW1lcyA9IDA7XHJcbiAgICAgICAgICAgICAgICB0aGlzLl90aWxlbG9hZEluZGV4ID0gMDtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH0pO1xyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX2NoZWNrTWFwU2VsZWN0ZWQoX2FyZWFJZDogc3RyaW5nKSB7XHJcbiAgICAgICAgcmV0dXJuIHRoaXMuX2lzTWFwU2VsZWN0ZWQuaGFzT3duUHJvcGVydHkoX2FyZWFJZCk7XHJcbiAgICB9XHJcbn0iXX0=