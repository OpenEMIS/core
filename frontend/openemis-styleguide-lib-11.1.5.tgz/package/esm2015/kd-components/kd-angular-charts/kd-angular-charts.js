import { Component, ViewEncapsulation, Input, Output, EventEmitter, ElementRef } from '@angular/core';
import { DomSanitizer } from '@angular/platform-browser';
import { KdSplitterEvent } from '../kd-angular-splitter/index';
import { KdConvertionSvc, KdDomElemSvc, KdDataSvc } from '../kd-common/index';
import { KdChartsSvc } from './kd-angular-charts-svc';
import { DEFAULT_CONFIG } from './kd-angular-charts-config';
export class KdCharts {
    constructor(_sanitizer, _elementRef, _chartSvc, 
    // public _kdSplitterEvent: KdSplitterEvent,
    _convertionSvc, _dataSvc) {
        this._sanitizer = _sanitizer;
        this._elementRef = _elementRef;
        this._chartSvc = _chartSvc;
        this._convertionSvc = _convertionSvc;
        this._dataSvc = _dataSvc;
        this.isLayerLoading = true;
        this.smallLoaderValue = null;
        this.pieData = [];
        this.pieColor = [];
        this.backgroundColor = '#FFFFFF';
        this.checkMapScale = false;
        this.isAxisChart = false;
        this.isNegativeStack = false;
        this.chartType = [''];
        this.rotateTitleX = false;
        this.rotateTitleY = false;
        this.chartHide = false;
        this.haveAxisPadding = false;
        this.haveAxisSpecialPadding = false;
        this.xAxisOpposite = false;
        this.havekdChartNoBorderClass = false;
        this.htmlClassObj = {
            'chartsWrapper': '',
            'legendContainer': ''
        };
        this.api = {};
        this.icons = {};
        this.markersLegend = [];
        this.shapes = {
            triangle: 'M 4 0 L 4 0 L 0 8 L 8 8 z',
            triangleR: 'M 0 0 L 8 0 L 4 8 L 4 8 z',
            diamond: 'M 4 0 L 8 4 L 4 8 L 0 4 z',
            circle: 'M 4 0 A 4 4 0 1 0 4 8 A 4 4 0 1 0 4 0 Z',
            square: 'M 0 0 L 8 0 L 8 8 L 0 8 z'
        };
        this.legendInactive = [];
        this._colorListPosition = 0;
        this._pieDoneFlag = false;
        this.seriesThreshold = 1000;
        this.outputLegendData = new EventEmitter();
        this.outputData = new EventEmitter();
        this.outputArea = new EventEmitter();
        // this._splitterSubscriptionArr = this._initSplitterSubscriptions(_kdSplitterEvent);
    }
    ngOnInit() {
        // console.log('kd-chart init');
        this._setConfig(this.chartConfig, true);
        if (!this.chartData || !this.chartConfig)
            return;
        this._setData(this.chartData);
        this.initApi();
        // this._resizeListener = () => this._onResize();
        // this._initListener();
        // console.log('kd-chart data ', this.chartData);
        // console.log('kd-chart config ', this.chartConfig);
    }
    ngOnChanges(_simpleChanges) {
        if (_simpleChanges.hasOwnProperty('chartConfig') && !_simpleChanges['chartConfig'].firstChange) {
            if (_simpleChanges['chartConfig'].currentValue === this.config)
                return;
            this._setConfig(_simpleChanges.chartConfig.currentValue);
        }
        if (_simpleChanges.hasOwnProperty('chartData') && !_simpleChanges['chartData'].firstChange) {
            if (_simpleChanges['chartData'].currentValue === this.data)
                return;
            this._setData(Object.assign({}, _simpleChanges.chartData.currentValue));
        }
    }
    ngOnDestroy() {
        if (!this.chartData || !this.chartConfig)
            return;
        // this._unsubscribe(this._splitterSubscriptionArr);
        // this._removeListener();
    }
    /**
     * For EXPORT. export skips data massage and generateLegendData, hence need to setLegendData separately
     * (accurate as of v3.7.0) as legendData is for internal use, we do not put in Input. this function is accessed via ViewChild from KdVisualization
     * param {ILegendData }} _legendData
     */
    setLegendData(_legendData) {
        this.legendData = Object.assign({}, _legendData);
    }
    /**
     * initiate api from outside kd charts component
     */
    initApi() {
        if (typeof this.chartApi === 'undefined')
            return;
        this.chartApi.changeSeriesColor = (legendId, color, index) => {
            if (typeof index === 'number')
                this._setDataColorShape(index, color);
            this.legendData[legendId].color = color;
            this._updateLegendIconWithIndex(legendId, index);
            this.api.redraw();
        };
        this.chartApi.redraw = () => this.api.redraw();
        // this.chartApi.enableListener = (_haveListener: boolean) => {
        //     if (_haveListener) {
        //         this._initListener();
        //         if (this._splitterSubscriptionArr.length === 0) {
        //             this._splitterSubscriptionArr = this._initSplitterSubscriptions(this._kdSplitterEvent);
        //         }
        //     } else {
        //         this._removeListener();
        //         this._unsubscribe(this._splitterSubscriptionArr);
        //         this._splitterSubscriptionArr = [];
        //     }
        // };
    }
    // ================================= Listener ==================================
    // private _initListener() {
    //     window.addEventListener('resize', this._resizeListener);
    // }
    // private _removeListener() {
    //     window.removeEventListener('resize', this._resizeListener);
    // }
    // private _onResize(): void {
    //     clearTimeout(this._resizeTimeout);
    //     this._resizeTimeout = setTimeout(() => {
    //         this.api.redraw();
    //     }, 500);
    // }
    // ================================= Splitter Subscription ==================================
    // private _initSplitterSubscriptions(_splitterEvent): Subscription[] {
    //     if (!_splitterEvent) return;
    //     let subscriptionArr: Subscription[] = [];
    //     let toggleMenuSub = _splitterEvent.onToggleMenu().subscribe((): void => {
    //         timer(500).subscribe((): void => {
    //             this.api.redraw();
    //         });
    //     });
    //     let toggleSubPane = _splitterEvent.onToggleSubPane().subscribe((): void => {
    //         timer(500).subscribe((): void => {
    //             this.api.redraw();
    //         });
    //     });
    //     let dragMenuSub = _splitterEvent.onDrag()
    //         .pipe(
    //             debounceTime(100)
    //         )
    //         .subscribe((): void => {
    //             this.api.redraw();
    //         });
    //     subscriptionArr.push(toggleMenuSub);
    //     subscriptionArr.push(toggleSubPane);
    //     subscriptionArr.push(dragMenuSub);
    //     return subscriptionArr;
    // }
    // private _unsubscribe(_subscriptionArr: Subscription[] = []): void {
    //     if (_subscriptionArr.length === 0) return;
    //     _subscriptionArr.forEach(subscription => {
    //         if (subscription) subscription.unsubscribe();
    //     });
    // }
    // ================================= Config and Data ==================================
    _setConfig(_config, _isFirstChange) {
        // storing config in this component
        this.config = JSON.parse(JSON.stringify(DEFAULT_CONFIG));
        this._dataSvc.deepCombineObject(this.config, _config || {});
        // set config is called twice, to improve performance, only call the following once (after data massage)
        if (_isFirstChange)
            return;
        this.setChartStyle(_config);
        this.checkMapScale = false;
        this._setClassNames();
        this._populateLegendIcon();
        this._setLabelStyle();
        // storing config into chart service
        this._chartSvc.config = _config;
    }
    setChartStyle(_config) {
        this.havekdChartNoBorderClass = !_config.chart.mainArea.style["borderWidth"];
        if (_config.chart.mainArea.style["borderWidth"] && _config.chart.mainArea.style["borderWidth"] === '0px') {
            this.havekdChartNoBorderClass = true;
        }
    }
    /* To be revisit. Hot fix for downgrade component as ngclass value doesn't change.*/
    _setClassNames() {
        // htmlClassObj is a workaround for downgrade method
        this.htmlClassObj['chartsWrapper'] = '';
        this.htmlClassObj['legendContainer'] = '';
        if (typeof this.config.legend.float !== undefined && this.config.legend.float) {
            this.htmlClassObj.chartsWrapper += 'legend-float ';
            this.htmlClassObj.legendContainer += 'legend-float ';
        }
        if (typeof this.config.legend.verticalAlign !== undefined) {
            this.htmlClassObj.chartsWrapper += this.config.legend.verticalAlign + ' ';
            this.htmlClassObj.legendContainer += this.config.legend.verticalAlign + ' ';
        }
        if (typeof this.config.legend.align !== undefined) {
            this.htmlClassObj.chartsWrapper += this.config.legend.align + ' ';
            this.htmlClassObj.legendContainer += this.config.legend.align + ' ';
        }
        if (this.chartCategory === 'pie' || this.chartCategory === 'map')
            return;
        this.xAxisOpposite = this.config.xAxis.opposite;
        // setting class name for vertical axis title to rotate
        this.rotateTitleX = this.chartType[0] === 'bar' && this._chartSvc.checkRotateTitleEnabled(this.chartType, this.config);
        this.rotateTitleY = this.chartType[0] !== 'bar' && this._chartSvc.checkRotateTitleEnabled(this.chartType, this.config);
        // this flag is for all axisCharts except for bar. Bar do not need paddin
        this.haveAxisPadding = this.chartType[0] !== 'bar';
        this.haveAxisSpecialPadding = this.chartType[this.chartType.length - 1] === 'type2';
        this.isNegativeStack = (this.chartCategory === 'bar' || this.chartCategory === 'column') && this.chartType[1] === 'stack' && this.chartType[2] === 'negative';
    }
    _updateLegendIconWithIndex(_legendId, _index) {
        let legendId = _legendId, legendConfig;
        // if legendId is given, we should follow legendId
        if (!legendId) {
            // if no legendId, follow _index
            if (_index === null || _index === undefined)
                return;
            legendId = this.legendList[_index];
        }
        legendConfig = this.legendData[legendId];
        this._updateLegendIcon(legendId, legendConfig);
    }
    _populateLegendIcon(index) {
        if (!this.legendData)
            return;
        this.legendList = Object.keys(this.legendData);
        for (let i = 0; i < this.legendList.length; i++) {
            let legendId = this.legendList[i];
            let legendConfig = this.legendData[legendId];
            // let eachSvg = this.renderer.createElement('svg');
            // this.renderer.setAttribute(eachSvg, 'fill', this.config.legendData[legendId].color);
            // this.renderer.setAttribute(eachSvg, 'width', 8);
            // this.renderer.setAttribute(eachSvg, 'height', 8);
            // let eachSvgPath = this.renderer.createElement('path');
            // this.renderer.setAttribute(eachSvgPath, 'd', this.config.legendData[legendId].shape);
            // this.renderer.appendChild(eachSvg, eachSvgPath);
            // let xml = new XMLSerializer().serializeToString(eachSvg);ARI
            // let data = "data:image/svg+xml;base64," + btoa(xml);
            // this.icons[legendId] = this._sanitizer.bypassSecurityTrustResourceUrl('data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" fill="' + legendConfig.color + '" width="8" height="8"><path d="' + this.shapes[legendConfig.shape] + '"/></svg>');
            // this.icons[legendId] = this._sanitizer.bypassSecurityTrustResourceUrl(data);
            // legend is set based on whether there is deactive
            this._updateLegendIcon(legendId, legendConfig);
        }
    }
    _setLabelStyle() {
        if (this.config.chart.labels.enabled) {
            let labelStyle = this._chartSvc.getStyle(this.config.chart.labels.style);
            this._applyLabelStyle(labelStyle, ' span', true);
        }
    }
    _setData(_data) {
        this.legendInactive = [];
        this.markersLegend = [];
        this._setChartType(_data);
        if (this.config.skipMassage) {
            this.data = _data;
            this._setConfig(this.config);
            return;
        }
        if (this.chartCategory === 'pie' || this.chartCategory === 'map') {
            if (this.chartCategory === 'pie')
                this._dataMassageForPie(_data);
            else if (this.chartCategory === 'map')
                this._dataMassageForMap(_data);
            // else if (this.chartCategory === 'map') this.data = _data;
            this._setConfig(this.config);
        }
        else
            this._dataMassage(_data);
        // emit data to kd-visualization to prepare for export
        this.outputData.emit(this.data);
        // emit current config to kd-visualization to prepare for export
        this.outputLegendData.emit(this.legendData);
    }
    _setChartType(_data) {
        let dataToUse = _data;
        if (!this.config.skipMassage || (_data.chart && _data.chart.type == 'map')) {
            dataToUse = _data.chart;
        }
        this.chartCategory = dataToUse.type;
        this.chartType = dataToUse.layout.split('-');
        this.isAxisChart = dataToUse.type !== 'pie' && dataToUse.type !== 'map';
    }
    _setDataColorShape(_index, _color) {
        if (_index < 0) {
            return;
        }
        // let changeSeries: boolean = this.config.chart.hasOwnProperty('persistentSeriesChange') ? this.config.chart.persistentSeriesChange : true;
        let legendIds = Object.keys(this.legendData);
        if (this.chartCategory != 'map') {
            for (let xIndex = this.data.data.length - 1; xIndex >= 0; xIndex--) {
                for (let yIndex = this.data.data[xIndex].y.length - 1; yIndex >= 0; yIndex--) {
                    if (this.data.data[xIndex].y[yIndex].id === legendIds[_index]) {
                        this._changeSeries(xIndex, yIndex, 'color');
                        this._changeSeries(xIndex, yIndex, 'shape');
                    }
                }
            }
        }
    }
    _changeSeries(_xIndex, _yIndex, _element) {
        let legendId = this.data.data[_xIndex].y[_yIndex].id;
        let output = this.legendData[legendId][_element];
        if (_element === 'shape') {
            output = this.shapes[output];
        }
        if (this._isChangeSeries(_xIndex, _yIndex, _element)) {
            this.data.data[_xIndex].y[_yIndex][_element] = output;
        }
    }
    _isChangeSeries(_xIndex, _yIndex, _element) {
        let changeSeries = this.config.chart.hasOwnProperty('persistentSeriesChange') ? this.config.chart.persistentSeriesChange : true;
        if (changeSeries) {
            return true;
        }
        else {
            if (this.chartData.series[_yIndex].data[_xIndex].hasOwnProperty(_element)) {
                if (this.chartData.series[_yIndex].data[_xIndex][_element] !== null || this.chartData.series[_yIndex].data[_xIndex][_element].length > 0) {
                    return false;
                }
            }
        }
        return true;
    }
    onLegendClick(_id) {
        let legendConfig = this.legendData[_id];
        legendConfig.deactive = !legendConfig.deactive || false;
        this._updateLegendItem(_id, legendConfig);
        if (legendConfig.deactive) {
            this.legendInactive.push(_id);
        }
        else {
            let idIndex = this.legendInactive.indexOf(_id);
            if (idIndex !== -1) {
                this.legendInactive.splice(idIndex, 1);
            }
        }
        if (this.chartCategory != 'map') {
            let legendData = this.updateConfig();
            let data = this.updateData(legendData);
            this.api.legendClick(data, legendData);
            this._toggleDataLabel(_id, legendConfig.deactive);
            // update data to kd-visualization to prepare for exporting
            this.outputData.emit(data);
        }
        else {
            this.api.legendClick(_id, legendConfig.deactive);
        }
    }
    onClusterClick(_id) {
        let legendItemMarker = this._elementRef.nativeElement.querySelector('#kdli-' + _id.id + ' .awesome-marker');
        let legendItemLabel = this._elementRef.nativeElement.querySelector('#kdli-' + _id.id + ' .kdx-legend-label');
        this.api.clusterClick(_id, { 'legendItemMarker': legendItemMarker, 'legendItemLabel': legendItemLabel });
    }
    getOutputLegend(_legendData) {
        if (this.chartCategory == 'map' && Object.keys(_legendData).length == 0) {
            this.checkMapScale = true;
        }
        else {
            this.legendData = _legendData;
            this.checkMapScale = false;
            this._pieDoneFlag = true;
            this.outputLegendData.emit(this.legendData);
            this._populateLegendIcon(undefined);
        }
    }
    getOutputData(_data) {
        // this.outputData.emit(_data);
        this.outputArea.emit(_data);
    }
    getReady(_value) {
        this.isLayerLoading = _value;
    }
    _updateLegendItem(_id, _legendConfig) {
        this._updateLegendIcon(_id, _legendConfig);
        let textColor = (_legendConfig.deactive) ? this.config.legend.item.inactiveColor || '#CCCCCC' : this.config.legend.item.style.color || this.config.legend.item.activeColor || '#000000';
        this._elementRef.nativeElement.querySelector('#kdli-' + _id).style.color = textColor;
    }
    _updateLegendIcon(_id, _legendConfig) {
        let iconColor = (_legendConfig.deactive) ? this.config.legend.item.inactiveColor || '#CCCCCC' : _legendConfig.color || '#000000';
        let rgbColor = this._convertionSvc.colorToRgb(iconColor);
        this.icons[_id] = this._sanitizer.bypassSecurityTrustResourceUrl('data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" fill="' + rgbColor + '" width="8" height="8"><path d="' + this.shapes[_legendConfig.shape] + '"/></svg>');
    }
    _toggleDataLabel(id, deactive) {
        let displayState = (deactive) ? 'none' : 'flex';
        this._applyLabelStyle(displayState, '.y-' + id);
        if (!deactive)
            this._applyLabelStyle('display:' + displayState, '.y-' + id + ' span', true);
    }
    _applyLabelStyle(_style, target, isRepositioning) {
        target = target || '';
        let allLabel = this._elementRef.nativeElement.querySelectorAll('#' + this.config.id + ' .kdx-charts-data-label' + target);
        for (let i in allLabel) {
            if (allLabel[i].style) {
                if (isRepositioning) {
                    let labelWidth = allLabel[i].offsetWidth;
                    let labelCenter = (labelWidth - labelWidth / allLabel[i].innerText.toString().length) / 2;
                    let shiftPosition = 0 - labelCenter;
                    _style += 'left:' + shiftPosition + 'px;';
                    allLabel[i].style = _style;
                }
                else {
                    allLabel[i].style.display = _style;
                }
            }
        }
    }
    updateConfig() {
        let legendData = Object.assign({}, this.legendData);
        let legendInactive = this.legendInactive;
        legendData = Object.keys(legendData)
            .filter(key => !legendInactive.includes(key))
            .reduce((obj, key) => {
            obj[key] = legendData[key];
            return obj;
        }, {});
        return legendData;
    }
    updateData(_legendData) {
        let thisData = JSON.parse(JSON.stringify(this.data));
        let legendInactive = this.legendInactive;
        if (this.chartCategory === 'pie') {
            let legendData = _legendData;
            // piedata uses legendData instead of data
            thisData.data = Object.keys(legendData).map(key => legendData[key]).filter((value) => value.y && value.y > 0);
            return thisData;
        }
        else if (this.chartType[1] === '100' && this.chartType[0] === 'area') {
            for (let i = thisData.data.length - 1; i >= 0; i--) {
                let newYArr = thisData.data[i].y.filter(d => !legendInactive.includes(d.id));
                thisData.data[i] = Object.assign({}, thisData.data[i], { y: newYArr });
            }
        }
        let originalData = JSON.parse(JSON.stringify(thisData));
        let allSumArrMax = [0];
        let allSumArrMin = [0];
        let haveNegative = false;
        for (let i = 0; i < originalData.data.length; i++) {
            let totalSum = 1;
            if (this.chartType[1] === '100') {
                totalSum = thisData.data[i].y.reduce((acc, curr, yIndex) => {
                    if (legendInactive.includes(curr.id))
                        return acc;
                    return acc + curr.value;
                }, 0);
            }
            let newYArr = [];
            let sumArr = [];
            let sum = 0;
            let sumNegative = 0;
            for (let yIndex = 0; yIndex < originalData.data[i].y.length; yIndex++) {
                let currY = Object.assign({}, originalData.data[i].y[yIndex]);
                if (legendInactive.includes(currY.id))
                    continue;
                let currentVal = currY.value === null ? 0 : currY.value;
                let currSign = Math.sign(currentVal);
                if (currSign < 0 && !haveNegative) {
                    haveNegative = true;
                    if (this.chartType[1] === '100') {
                        this.chartHide = true;
                        break;
                    }
                }
                if (this.chartType[1] !== '100' && this.chartType[1] === 'stack') {
                    if (currSign >= 0) {
                        sum = (currentVal === null) ? sum : sum + currentVal;
                    }
                    else {
                        sumNegative = (currentVal === null) ? sumNegative : sumNegative + currentVal;
                    }
                }
                else if (this.chartType[1] === '100') {
                    if (currentVal !== null && totalSum !== 0) {
                        currentVal = currentVal / totalSum * 100;
                        sum = sum + currentVal;
                    }
                    else {
                        sum = sum;
                    }
                }
                else {
                    if (currSign >= 0) {
                        sum = (currentVal === null) ? 0 : currentVal;
                    }
                    else {
                        sumNegative = (currentVal === null) ? 0 : currentVal;
                    }
                }
                currY.sum = currentVal >= 0 ? sum : sumNegative;
                // value is used to display data-label and tooltip, renderVal is the acutal percentage to pass to d3 for rendering
                if (this.chartType[1] === '100')
                    currY['renderVal'] = currentVal;
                sumArr.push(Math.sign(currentVal) < 0 ? sumNegative : sum);
                newYArr.push(currY);
            }
            allSumArrMax.push(this._chartSvc.getD3MaxOrMin(sumArr, 'max'));
            allSumArrMin.push(this._chartSvc.getD3MaxOrMin(sumArr, 'min'));
            thisData.data[i] = Object.assign({}, originalData.data[i], { y: newYArr });
        }
        thisData['range'] = {
            max: this._chartSvc.getD3MaxOrMin(allSumArrMax, 'max'),
            min: this._chartSvc.getD3MaxOrMin(allSumArrMin, 'min')
        };
        thisData['haveNegative'] = haveNegative;
        return thisData;
    }
    _generateLegendData(_data, maxSeriesLength) {
        // empty out variables before regenerating
        this.legendData = {};
        // this.legendList = null;
        let legendIdSearch = {};
        let legendId, legendDataObj;
        let legendData = {};
        for (let i = 0; i < maxSeriesLength; i++) {
            legendId = (_data.series[i] && _data.series[i].length > 0) ? _data.series[i].id : 'id' + i;
            legendDataObj = {
                'name': _data.series[i].name,
                'id': legendId,
                'color': _data.series[i].color || this._getDefaultConfig('color', i),
                'shape': _data.series[i].shape || this._getDefaultConfig('shape', i)
            };
            if (this.chartCategory === 'line' || this.chartCategory === 'spline' || this.chartCategory === 'area' || this.chartCategory === 'dot') {
                legendDataObj['dotEnabled'] = (typeof _data.series[i].dotEnabled !== 'undefined') ? _data.series[i].dotEnabled : true;
                legendDataObj['dotBorderWidth'] = (typeof _data.series[i].dotBorderWidth !== 'undefined') ? _data.series[i].dotBorderWidth : 0;
                legendDataObj['dotBorderColor'] = (typeof _data.series[i].dotBorderColor !== 'undefined') ? _data.series[i].dotBorderColor : '#FFFFFF';
                if (this.chartCategory !== 'dot')
                    legendDataObj['lineStyle'] = (typeof _data.series[i].lineStyle !== 'undefined') ? _data.series[i].lineStyle : 'solid';
            }
            legendData[legendId] = legendDataObj;
            legendIdSearch[i] = legendId;
        }
        this.legendData = legendData;
        return legendIdSearch;
    }
    _dataMassage(_data) {
        let seriesLength = this._chartSvc.getD3MaxOrMin([_data.series.length, this.seriesThreshold], 'min');
        let chartDataObj, chartDataSeriesObj;
        let chartData = {
            'type': _data.chart['type'] ? _data.chart['type'] : null,
            'layout': _data.chart['layout'] ? _data.chart['layout'] : null,
            'config': this.config.plotOptions && this.config.plotOptions.hasOwnProperty(_data.chart['type']) ? this.config.plotOptions[_data.chart['type']] : {},
            'data': []
        };
        if (!this.config.hasOwnProperty('id')) {
            this.config['id'] = _data.chart['type'] ? _data.chart['type'] + '-1' : 'Default-1';
        }
        let categories = this._chartSvc.getLimitedCategories(_data.xAxis.categories, this.xThreshold);
        let legendIdSearch = this._generateLegendData(_data, seriesLength);
        let totalSumArr = this._getTotalSum(_data, seriesLength);
        let allSumArrMax = [0];
        let allSumArrMin = [0];
        let haveNegative = false;
        for (let i = 0; i < categories.length; i++) {
            chartDataObj = {
                'x': {
                    value: i.toString(),
                    label: categories[i]
                },
                'y': [],
            };
            let sumArr = [];
            let sum = 0;
            let sumNegative = 0;
            let forLoopInfo = this._chartSvc.getForLoopInfo(this._chartSvc.getForLoopSequence(this.chartType), seriesLength);
            // for (let j: number = 0; j < seriesLength; j++) {
            for (let j = forLoopInfo.start; forLoopInfo.check(j, forLoopInfo.end); j = forLoopInfo.iterate(j)) {
                if (typeof _data.series[j].data[i] === 'undefined')
                    continue;
                let currentVal = _data.series[j].data[i].value;
                let currSign = Math.sign(currentVal);
                if (typeof currentVal === 'undefined')
                    continue;
                if (currSign < 0 && !haveNegative) {
                    haveNegative = true;
                    if (this.chartType[1] === '100')
                        break;
                }
                if (this.chartType[1] !== '100' && this.chartType[1] === 'stack') {
                    if (currSign >= 0) {
                        sum = (currentVal === null) ? sum : sum + currentVal;
                    }
                    else {
                        sumNegative = (currentVal === null) ? sumNegative : sumNegative + currentVal;
                    }
                }
                else if (this.chartType[1] === '100') {
                    if (currentVal !== null && totalSumArr[i] !== 0) {
                        currentVal = currentVal / totalSumArr[i] * 100;
                    }
                    else {
                        currentVal = 0;
                    }
                    sum = sum + currentVal;
                }
                else {
                    if (currSign >= 0) {
                        sum = (currentVal === null) ? 0 : currentVal;
                    }
                    else {
                        sumNegative = (currentVal === null) ? 0 : currentVal;
                    }
                }
                chartDataSeriesObj = {
                    'sum': currentVal >= 0 ? sum : sumNegative,
                    'value': _data.series[j].data[i].value,
                    'color': this._getConfig('color', j, _data.series[j].data[i]),
                    'shape': this.shapes[this._getConfig('shape', j, _data.series[j].data[i])],
                    'id': legendIdSearch[j]
                };
                // value is used to display data-label and tooltip, renderVal is the acutal percentage to pass to d3 for rendering
                if (this.chartType[1] === '100')
                    chartDataSeriesObj['renderVal'] = currentVal;
                sumArr.push(Math.sign(currentVal) < 0 ? sumNegative : sum);
                chartDataObj.y.push(chartDataSeriesObj);
            }
            allSumArrMax.push(this._chartSvc.getD3MaxOrMin(sumArr, 'max'));
            allSumArrMin.push(this._chartSvc.getD3MaxOrMin(sumArr, 'min'));
            chartData.data.push(chartDataObj);
        }
        if (_data.chart.type !== 'pie') {
            chartData['range'] = {
                max: this._chartSvc.getD3MaxOrMin(allSumArrMax, 'max'),
                min: this._chartSvc.getD3MaxOrMin(allSumArrMin, 'min')
            };
            chartData['haveNegative'] = haveNegative;
        }
        this.data = chartData;
        this.chartHide = this.chartType[1] === '100' && haveNegative;
        this._setConfig(this.config);
    }
    _dataMassageForPie(_data) {
        if (_data !== undefined && _data !== null) {
            let chartData = {
                'type': _data.chart['type'] ? _data.chart['type'] : null,
                'layout': _data.chart['layout'] ? _data.chart['layout'] : null,
                'config': this.config.plotOptions && this.config.plotOptions.hasOwnProperty(_data.chart['type']) ? this.config.plotOptions[_data.chart['type']] : {},
                'data': []
            };
            let returnParams = this._chartSvc.singlePieDataMassage(this.legendData, _data, this.config, this.seriesThreshold);
            chartData['piedata'] = returnParams.pieData;
            this.data = chartData;
            this.config['pieColor'] = returnParams.pieColor;
            this.legendData = returnParams.legendData;
            // this.outputData.emit(this.data);
        }
    }
    _dataMassageForMap(_data) {
        this.data = _data;
        this._setLegendForMap();
    }
    _setLegendForMap() {
        let seriesData;
        if (this.data['mapSeriesData'] && this.config.skipMassage) {
            seriesData = JSON.parse(JSON.stringify(this.data['mapSeriesData']));
        }
        else {
            seriesData = JSON.parse(JSON.stringify(this.data['series']));
            for (let i = 0; i < seriesData.length; i++) {
                seriesData[i]['deactive'] = false;
            }
        }
        this.checkMapScale = false;
        if (!this.config.skipMassage) {
            if (this.config.colorAxis != undefined) {
                if (this.config.colorAxis.dataClasses && this.config.colorAxis.dataClasses.length != 0) {
                    this.legendData = this._chartSvc.setSingleLegendLevels(this.config.colorAxis.dataClasses, this.config.legend.valueDecimals, this.config.legend.valueSuffix);
                }
                else {
                    this.checkMapScale = true;
                }
            }
            else {
                this.legendData = this._chartSvc.setMapLegendData(this.legendData, seriesData, this.config);
            }
        }
        else {
            // output legend only for exporting
            if (this.config.colorAxis != undefined) {
                if (this.config.colorAxis.dataClasses && this.config.colorAxis.dataClasses.length != 0) {
                    this.legendData = this._chartSvc.setMapLegendData(this.legendData, seriesData, this.config);
                }
                else {
                    this.checkMapScale = true;
                }
            }
            else {
                this.legendData = this._chartSvc.setMapLegendData(this.legendData, seriesData, this.config);
            }
        }
    }
    _getTotalSum(_data, seriesLength) {
        if (this.chartType[1] === '100') {
            return this._chartSvc.getTotalSumArrFromSeries(_data.series, _data.xAxis.categories, seriesLength);
        }
    }
    _getConfig(_element, _seriesIndex, _data) {
        if (!this._chartSvc.isExist(_data))
            return;
        if (_data.hasOwnProperty(_element) && _data[_element] !== undefined) {
            return _data[_element];
        }
        let config = this._getLegendConfig(_element, _seriesIndex);
        return config;
    }
    _getLegendConfig(_element, _seriesIndex) {
        if (_element === 'shape' &&
            (this.chartData.chart.type === 'pie' || this.chartData.chart.type === 'bar')) {
            return 'circle';
        }
        let defaultConfig = this._getDefaultConfig(_element, _seriesIndex);
        let config;
        if (this.chartCategory == 'pie') {
            config = defaultConfig;
        }
        else {
            config = this.chartData.series[_seriesIndex][_element] || defaultConfig;
        }
        return config;
    }
    _getDefaultConfig(_element, _seriesIndex) {
        if (_element === 'shape')
            return 'circle';
        if (_seriesIndex || _seriesIndex === 0) {
            return this.config.colors[_seriesIndex];
        }
        else {
            this._colorListPosition++;
            return this.config.colors[this._colorListPosition - 1];
        }
    }
    getOutputMarker(_data) {
        this.markersLegend = _data;
    }
}
KdCharts.decorators = [
    { type: Component, args: [{
                selector: 'kd-charts',
                template: "<!-- <div class=\"kdx-charts-wrapper {{config.legend.verticalAlign}} {{config.legend.align}}\" [ngClass]=\"{'legend-float': config.legend.float}\"> -->\r\n\r\n<div class=\"kdx-charts-wrapper {{htmlClassObj.chartsWrapper}}\">\r\n    <div class=\"kdx-charts-main\">\r\n        <div class=\"kdx-header-container\" *ngIf=\"(config.title && config.title.enabled && config.title.text && config.title.text !== '') || (config.subtitle.enabled && config.subtitle.text && config.subtitle.text !== '')\">\r\n            <div *ngIf=\"config.title.enabled && config.title.text && config.title.text !== ''\" class=\"kdx-chart-title  {{config.title.align}}\" [ngStyle]=\"config.title.style\">\r\n                {{config.title.text}}\r\n            </div>\r\n            <div *ngIf=\"config.subtitle && config.subtitle.enabled && config.subtitle.text && config.subtitle.text !== ''\" class=\"kdx-chart-subtitle {{config.subtitle.align}}\" [ngStyle]=\"config.subtitle.style\">\r\n                {{config.subtitle.text}}\r\n            </div>\r\n        </div>\r\n\r\n        <div class=\"kdx-charts-dummy kdx-charts-invisible-axis-label\" [ngClass]=\"{'kdx-charts-child-padding-both': haveAxisPadding, 'kdx-charts-child-special-padding': haveAxisSpecialPadding, 'kdx-charts-axis-x-opposite': xAxisOpposite}\" [ngStyle]=\"config.xAxis.labels.style\"></div>\r\n        <div class=\"kdx-chart-container\" [ngStyle]=\"config.chart.plotArea.style\">\r\n            <div class=\"kdx-charts-axis-title kdx-charts-axis-title-x\" *ngIf=\"config.xAxis && config.xAxis.enabled && !chartHide && isAxisChart && config.xAxis.title.text !== ''\" [ngStyle]=\"config.xAxis.title.style\">\r\n                <div class=\"kdx-charts-axis-title-text\">{{config.xAxis.title.text}}</div>\r\n            </div>\r\n            <div class=\"kdx-charts-axis-label-container\" *ngIf=\"config.xAxis.enabled && config.xAxis.labels && config.xAxis.labels.enabled && !chartHide && isAxisChart\" [ngClass]=\"{'kdx-charts-child-padding-both': haveAxisPadding, 'kdx-charts-child-special-padding': haveAxisSpecialPadding, 'kdx-charts-axis-x-opposite': xAxisOpposite}\" [ngStyle]=\"config.xAxis.labels.style\">\r\n            </div>\r\n            <div *ngIf=\"config.chart.labels\" class=\"kdx-charts-data-label-container\" [ngStyle]=\"{'z-index': config.chart.labels.enabled ? 1 : -1}\"></div>\r\n            <div class=\"kdx-charts-svg-wrapper\">\r\n                <div id=\"{{config.id}}Leaflet\" class=\"kdx-charts-svg-container\">\r\n                    <svg width=\"0px\" height=\"0px\"></svg>\r\n                </div>\r\n                <div class=\"kdx-charts-axis-title kdx-charts-axis-title-y\" *ngIf=\"config.yAxis && config.yAxis.enabled && !chartHide && isAxisChart && config.yAxis.title && config.yAxis.title.text !== ''\" [ngStyle]=\"config.yAxis.title.style\">\r\n                    <div class=\"kdx-charts-axis-title-text\">{{config.yAxis.title.text}}</div>\r\n                </div>\r\n                <ng-container *ngIf=\"data\" [ngSwitch]=\"chartCategory\">\r\n                    <kd-bar-chart *ngSwitchCase=\"'bar'\" [data]=\"data\" [config]=\"config\" [api]=\"api\" [legend]=\"legendData\"></kd-bar-chart>\r\n                    <kd-bar-chart *ngSwitchCase=\"'column'\" [data]=\"data\" [config]=\"config\" [api]=\"api\" [legend]=\"legendData\"></kd-bar-chart>\r\n                    <kd-pie-chart *ngSwitchCase=\"'pie'\" [data]=\"data\" [config]=\"config\" [api]=\"api\" [legend]=\"legendData\" [seriesThreshold]=\"seriesThreshold\" (outputLegend)=\"getOutputLegend($event)\" (outputData)=\"getOutputData($event)\"></kd-pie-chart>\r\n                    <kd-line-chart *ngSwitchCase=\"'line'\" [data]=\"data\" [config]=\"config\" [api]=\"api\" [legend]=\"legendData\"></kd-line-chart>\r\n                    <kd-line-chart *ngSwitchCase=\"'dot'\" [data]=\"data\" [config]=\"config\" [api]=\"api\" [legend]=\"legendData\"></kd-line-chart>\r\n                    <kd-line-chart *ngSwitchCase=\"'spline'\" [data]=\"data\" [config]=\"config\" [api]=\"api\" [legend]=\"legendData\"></kd-line-chart>\r\n                    <kd-line-chart *ngSwitchCase=\"'area'\" [data]=\"data\" [config]=\"config\" [api]=\"api\" [legend]=\"legendData\"></kd-line-chart>\r\n                    <kd-map-chart *ngSwitchCase=\"'map'\" [data]=\"data\" [config]=\"config\" [api]=\"api\" [legend]=\"legendData\" (outputLegend)=\"getOutputLegend($event)\" (outputData)=\"getOutputData($event)\" (outputMarker)=\"getOutputMarker($event)\" (outputReady)=\"getReady($event)\"></kd-map-chart>\r\n                </ng-container>\r\n            </div>\r\n            <div class=\"kdx-charts-axis-label-container kdx-charts-double-axis-x\" *ngIf=\"config.xAxis.enabled && config.xAxis.labels && config.xAxis.labels.enabled && !chartHide && isAxisChart && isNegativeStack\" [ngClass]=\"{'kdx-charts-child-padding-both': haveAxisPadding, 'kdx-charts-child-special-padding': haveAxisSpecialPadding, 'kdx-charts-axis-x-opposite': !xAxisOpposite}\" [ngStyle]=\"config.xAxis.labels.style\">\r\n            </div>\r\n            <div class=\"kdx-charts-axis-title kdx-charts-axis-title-x kdx-charts-double-axis-x\" *ngIf=\"config.xAxis && config.xAxis.enabled && !chartHide && isAxisChart && config.xAxis.title.text !== '' && isNegativeStack\" [ngStyle]=\"config.xAxis.title.style\">\r\n                <div class=\"kdx-charts-axis-title-text\">{{config.xAxis.title.text}}</div>\r\n            </div>\r\n        </div>\r\n    </div>\r\n\r\n    <!-- <div *ngIf=\"config.legend.enabled && !chartHide\" [ngClass]=\"{'legend-float': config.legend.float}\" class=\"kdx-legend-container {{config.legend.verticalAlign}} {{config.legend.align}}\"> -->\r\n\r\n    <div class=\"kdx-legend-main-container {{htmlClassObj.chartsWrapper}}\" [ngClass]=\"{clusterChartMap: markersLegend.length > 0}\">\r\n        <div class=\"kdx-legend-container\" *ngIf=\"config.legend.enabled && !chartHide && markersLegend.length > 0\" [ngStyle]=\"{'flex': markersLegend.length > 0 ? '0 1 50%' : null}\">\r\n            <div class=\"kdx-legends\" [ngStyle]=\"config.clusterLegend.style\">\r\n                <div class=\"kdx-legend-title-container  {{config.clusterLegend.title.align}}\" *ngIf=\"config.clusterLegend.title && config.clusterLegend.title.text\" [ngStyle]=\"config.clusterLegend.title.style\">\r\n                    <div class=\"kdx-legend-title\">{{config.clusterLegend.title.text}}</div>\r\n                </div>\r\n                <div class=\"kdx-legend\">\r\n                    <div class=\"kdx-legend-item\" id=\"kdli-{{legendItem.id}}\" *ngFor=\"let legendItem of markersLegend\" (click)=\"onClusterClick(legendItem)\">\r\n                        <div class=\"kdx-legend-marker\" [innerHTML]=\"legendItem.icon.outerHTML\" ></div>\r\n                        <div class=\"kdx-legend-label\" [ngStyle]=\"config.clusterLegend.item.style\">\r\n                            <div class=\"kdx-label-text\">{{legendItem.label}}</div>\r\n                        </div>\r\n                    </div>\r\n                </div>\r\n            </div>\r\n        </div>\r\n        <div *ngIf=\"config.legend.enabled && !chartHide && !(chartCategory === 'map' && chartType[1] === 'cluster')\" class=\"kdx-legend-container\">\r\n            <div class=\"kdx-legends\" [ngStyle]=\"config.legend.style\">\r\n                <div *ngIf=\"config.legend.title && config.legend.title.text\" class=\"kdx-legend-title-container {{config.legend.title.align}}\" [ngStyle]=\"config.legend.title.style\">\r\n                    <div class=\"kdx-legend-title\">{{config.legend.title.text}}</div>\r\n                </div>\r\n                <div class=\"kdx-legend legend-scroll {{config.legend.layout}}\" *ngIf=\"legendList && !checkMapScale\" [ngClass]=\"{'legend-scroll': !config.legend.enableScroll}\">\r\n                    <div class=\"kdx-legend-item\" id=\"kdli-{{legendId}}\" [ngStyle]=\"{'color': config.legend.item.activeColor}\" *ngFor=\"let legendId of legendList\" (click)=\"onLegendClick(legendId)\">\r\n                        <div class=\"kdx-legend-marker\">\r\n                            <img id=\"legend-icon-{{legendId}}\" [src]=\"icons[legendId]\" />\r\n                        </div>\r\n                        <div class=\"kdx-legend-label\" [ngStyle]=\"config.legend.item.style\">\r\n                            <div class=\"kdx-label-text\" *ngIf=\"legendData[legendId]\" [ngClass]=\"{'kdx-label-lightgray': legendData[legendId].deactive}\" >{{legendData[legendId].name}}</div>\r\n                        </div>\r\n                    </div>\r\n                </div>\r\n              <!--   <div class=\"kdx-legend\"> [ngClass]=\"{'kdx-legend-main-container': markersLegend.length > 0}\"\r\n                    <div class=\"kdx-legend-item\" id=\"kdli-{{legendItem.id}}\" *ngFor=\"let legendItem of markersLegend\" (click)=\"onClusterClick(legendItem)\">\r\n                        <div class=\"kdx-legend-marker\" [innerHTML]=\"legendItem.icon.outerHTML\" ></div>\r\n                        <div class=\"kdx-legend-label\"><div class=\"kdx-label-text\">{{legendItem.label}}</div></div>\r\n                    </div>\r\n                </div> -->\r\n                <div class=\"kdx-legend legend-scroll {{config.legend.layout}}\" *ngIf=\"checkMapScale\">\r\n                    <div class=\"kdx-map-scale-wrapper\">\r\n                        <i class=\"fa fa-caret-down kdx-map-scale-triangle\"></i>\r\n                        <div class=\"kdx-map-scale-container\">\r\n                            <div id=\"mapScale\" class=\"kdx-map-scale\"></div>\r\n                            <div class=\"kdx-map-scale-text-container\"></div>\r\n                        </div>\r\n                    </div>\r\n                </div>\r\n            </div>\r\n        </div>\r\n    </div>\r\n</div>\r\n<div *ngIf=\"config.footer && config.footer.enabled\" class=\"kdx-charts-footer\" [ngClass]=\"{clusterChartMapFooter: markersLegend.length > 0}\">\r\n    <div *ngIf=\"config.footer.bottomLabel && config.footer.bottomLabel.enabled && config.footer.bottomLabel.text && config.footer.bottomLabel.text !== ''\" class=\"kdx-charts-bottom-label {{config.footer.bottomLabel.align}}\" [ngStyle]=\"config.footer.bottomLabel.style\">\r\n        {{config.footer.bottomLabel.text}}\r\n    </div>\r\n    <div *ngIf=\"config.footer.footNote && config.footer.footNote.enabled && config.footer.footNote.text && config.footer.footNote.text !== ''\" class=\"kdx-charts-foot-note {{config.footer.footNote.align}}\" [ngStyle]=\"config.footer.footNote.style\">\r\n        {{config.footer.footNote.text}}\r\n    </div>\r\n</div>\r\n<kd-progressloader *ngIf=\"((chartCategory === 'map' && chartType[1] === 'full') || (chartCategory === 'map' && chartType[1] === 'cluster')) && isLayerLoading\" configtype=\"small-spinner\" [configvalue]=\"smallLoaderValue\"></kd-progressloader>",
                encapsulation: ViewEncapsulation.None,
                providers: [KdChartsSvc, KdSplitterEvent, KdConvertionSvc, KdDomElemSvc, KdDataSvc],
                host: {
                    'class': 'kdx-charts',
                    '[attr.id]': 'config.id',
                    '[class.kdx-charts-axis-invert]': 'chartType[0] === "bar"',
                    '[class.kdx-charts-rotate-title-x]': 'rotateTitleX',
                    '[class.kdx-charts-rotate-title-y]': 'rotateTitleY',
                    '[class.kdx-charts-yAxis-opposite]': 'config.yAxis.opposite',
                    '[class.kdx-charts-xAxis-opposite]': 'config.xAxis.opposite',
                    '[class.kdx-charts-no-border]': 'havekdChartNoBorderClass',
                    '[style.background-color]': 'config.chart.mainArea.style["backgroundColor"]',
                    '[style.border-color]': 'config.chart.mainArea.style["borderColor"]',
                    '[style.border-width]': 'config.chart.mainArea.style["borderWidth"]',
                    '[style.border-radius]': 'config.chart.mainArea.style["borderRadius"]',
                    '[style.border-style]': 'config.chart.mainArea.style["borderStyle"]',
                    '[style.font-family]': 'config.chart.style.fontFamily',
                    '[style.opacity]': 'config.chart.mainArea.style.opacity',
                }
            },] }
];
KdCharts.ctorParameters = () => [
    { type: DomSanitizer },
    { type: ElementRef },
    { type: KdChartsSvc },
    { type: KdConvertionSvc },
    { type: KdDataSvc }
];
KdCharts.propDecorators = {
    chartData: [{ type: Input, args: ['data',] }],
    chartConfig: [{ type: Input, args: ['config',] }],
    chartApi: [{ type: Input, args: ['api',] }],
    xThreshold: [{ type: Input }],
    seriesThreshold: [{ type: Input }],
    outputLegendData: [{ type: Output }],
    outputData: [{ type: Output }],
    outputArea: [{ type: Output }]
};
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoia2QtYW5ndWxhci1jaGFydHMuanMiLCJzb3VyY2VSb290IjoiQzoveGFtcHAvaHRkb2NzL1N0eWxlZ3VpZGUvaW9zdGctb3BlbmVtaXMtc3R5bGVndWlkZS9wcm9qZWN0cy9vcGVuZW1pcy1zdHlsZWd1aWRlLWxpYi9zcmMvIiwic291cmNlcyI6WyJrZC1jb21wb25lbnRzL2tkLWFuZ3VsYXItY2hhcnRzL2tkLWFuZ3VsYXItY2hhcnRzLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBLE9BQU8sRUFDSCxTQUFTLEVBQ1QsaUJBQWlCLEVBQ2pCLEtBQUssRUFDTCxNQUFNLEVBQ04sWUFBWSxFQUlaLFVBQVUsRUFFYixNQUFNLGVBQWUsQ0FBQztBQUN2QixPQUFPLEVBQUUsWUFBWSxFQUFFLE1BQU0sMkJBQTJCLENBQUM7QUFHekQsT0FBTyxFQUFFLGVBQWUsRUFBRSxNQUFNLDhCQUE4QixDQUFDO0FBQy9ELE9BQU8sRUFBRSxlQUFlLEVBQUUsWUFBWSxFQUFFLFNBQVMsRUFBRSxNQUFNLG9CQUFvQixDQUFDO0FBQzlFLE9BQU8sRUFBRSxXQUFXLEVBQUUsTUFBTSx5QkFBeUIsQ0FBQztBQUN0RCxPQUFPLEVBQUUsY0FBYyxFQUFFLE1BQU0sNEJBQTRCLENBQUM7QUFzQzVELE1BQU0sT0FBTyxRQUFRO0lBNkRqQixZQUNZLFVBQXdCLEVBQ3hCLFdBQXVCLEVBQ3ZCLFNBQXNCO0lBQzlCLDRDQUE0QztJQUNyQyxjQUErQixFQUMvQixRQUFtQjtRQUxsQixlQUFVLEdBQVYsVUFBVSxDQUFjO1FBQ3hCLGdCQUFXLEdBQVgsV0FBVyxDQUFZO1FBQ3ZCLGNBQVMsR0FBVCxTQUFTLENBQWE7UUFFdkIsbUJBQWMsR0FBZCxjQUFjLENBQWlCO1FBQy9CLGFBQVEsR0FBUixRQUFRLENBQVc7UUFsRXZCLG1CQUFjLEdBQVksSUFBSSxDQUFDO1FBQy9CLHFCQUFnQixHQUFRLElBQUksQ0FBQztRQUM3QixZQUFPLEdBQWUsRUFBRSxDQUFDO1FBQ3pCLGFBQVEsR0FBZSxFQUFFLENBQUM7UUFDMUIsb0JBQWUsR0FBVyxTQUFTLENBQUM7UUFJcEMsa0JBQWEsR0FBWSxLQUFLLENBQUM7UUFFL0IsZ0JBQVcsR0FBWSxLQUFLLENBQUM7UUFDN0Isb0JBQWUsR0FBWSxLQUFLLENBQUM7UUFDakMsY0FBUyxHQUFrQixDQUFDLEVBQUUsQ0FBQyxDQUFDO1FBQ2hDLGlCQUFZLEdBQVksS0FBSyxDQUFDO1FBQzlCLGlCQUFZLEdBQVksS0FBSyxDQUFDO1FBQzlCLGNBQVMsR0FBWSxLQUFLLENBQUM7UUFDM0Isb0JBQWUsR0FBWSxLQUFLLENBQUM7UUFDakMsMkJBQXNCLEdBQVksS0FBSyxDQUFDO1FBQ3hDLGtCQUFhLEdBQVksS0FBSyxDQUFDO1FBQy9CLDZCQUF3QixHQUFZLEtBQUssQ0FBQztRQUUxQyxpQkFBWSxHQUFRO1lBQ3ZCLGVBQWUsRUFBRSxFQUFFO1lBQ25CLGlCQUFpQixFQUFFLEVBQUU7U0FDeEIsQ0FBQztRQUVLLFFBQUcsR0FBc0IsRUFBRSxDQUFDO1FBRTVCLFVBQUssR0FBVyxFQUFFLENBQUM7UUFHbkIsa0JBQWEsR0FBZSxFQUFFLENBQUM7UUFFOUIsV0FBTSxHQUFXO1lBQ3JCLFFBQVEsRUFBRSwyQkFBMkI7WUFDckMsU0FBUyxFQUFFLDJCQUEyQjtZQUN0QyxPQUFPLEVBQUUsMkJBQTJCO1lBQ3BDLE1BQU0sRUFBRSx5Q0FBeUM7WUFDakQsTUFBTSxFQUFFLDJCQUEyQjtTQUN0QyxDQUFDO1FBRU0sbUJBQWMsR0FBa0IsRUFBRSxDQUFDO1FBQ25DLHVCQUFrQixHQUFXLENBQUMsQ0FBQztRQU8vQixpQkFBWSxHQUFZLEtBQUssQ0FBQztRQU03QixvQkFBZSxHQUFXLElBQUksQ0FBQztRQUM5QixxQkFBZ0IsR0FBaUQsSUFBSSxZQUFZLEVBQUUsQ0FBQztRQUNwRixlQUFVLEdBQTBCLElBQUksWUFBWSxFQUFFLENBQUM7UUFDdkQsZUFBVSxHQUEwQixJQUFJLFlBQVksRUFBRSxDQUFDO1FBVTdELHFGQUFxRjtJQUN6RixDQUFDO0lBRUQsUUFBUTtRQUNKLGdDQUFnQztRQUNoQyxJQUFJLENBQUMsVUFBVSxDQUFDLElBQUksQ0FBQyxXQUFXLEVBQUUsSUFBSSxDQUFDLENBQUM7UUFDeEMsSUFBSSxDQUFDLElBQUksQ0FBQyxTQUFTLElBQUksQ0FBQyxJQUFJLENBQUMsV0FBVztZQUFFLE9BQU87UUFDakQsSUFBSSxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLENBQUM7UUFDOUIsSUFBSSxDQUFDLE9BQU8sRUFBRSxDQUFDO1FBQ2YsaURBQWlEO1FBQ2pELHdCQUF3QjtRQUN4QixpREFBaUQ7UUFDakQscURBQXFEO0lBQ3pELENBQUM7SUFFRCxXQUFXLENBQUMsY0FBNkI7UUFDckMsSUFBSSxjQUFjLENBQUMsY0FBYyxDQUFDLGFBQWEsQ0FBQyxJQUFJLENBQUMsY0FBYyxDQUFDLGFBQWEsQ0FBQyxDQUFDLFdBQVcsRUFBRTtZQUM1RixJQUFJLGNBQWMsQ0FBQyxhQUFhLENBQUMsQ0FBQyxZQUFZLEtBQUssSUFBSSxDQUFDLE1BQU07Z0JBQUUsT0FBTztZQUN2RSxJQUFJLENBQUMsVUFBVSxDQUFDLGNBQWMsQ0FBQyxXQUFXLENBQUMsWUFBWSxDQUFDLENBQUM7U0FDNUQ7UUFDRCxJQUFJLGNBQWMsQ0FBQyxjQUFjLENBQUMsV0FBVyxDQUFDLElBQUksQ0FBQyxjQUFjLENBQUMsV0FBVyxDQUFDLENBQUMsV0FBVyxFQUFFO1lBQ3hGLElBQUksY0FBYyxDQUFDLFdBQVcsQ0FBQyxDQUFDLFlBQVksS0FBSyxJQUFJLENBQUMsSUFBSTtnQkFBRSxPQUFPO1lBQ25FLElBQUksQ0FBQyxRQUFRLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxFQUFFLEVBQUUsY0FBYyxDQUFDLFNBQVMsQ0FBQyxZQUFZLENBQUMsQ0FBQyxDQUFDO1NBQzNFO0lBQ0wsQ0FBQztJQUVELFdBQVc7UUFDUCxJQUFJLENBQUMsSUFBSSxDQUFDLFNBQVMsSUFBSSxDQUFDLElBQUksQ0FBQyxXQUFXO1lBQUUsT0FBTztRQUNqRCxvREFBb0Q7UUFDcEQsMEJBQTBCO0lBQzlCLENBQUM7SUFFRDs7OztPQUlHO0lBQ0ksYUFBYSxDQUFDLFdBQTJDO1FBQzVELElBQUksQ0FBQyxVQUFVLEdBQUcsTUFBTSxDQUFDLE1BQU0sQ0FBQyxFQUFFLEVBQUUsV0FBVyxDQUFDLENBQUM7SUFDckQsQ0FBQztJQUVEOztPQUVHO0lBQ0ssT0FBTztRQUNYLElBQUksT0FBTyxJQUFJLENBQUMsUUFBUSxLQUFLLFdBQVc7WUFBRSxPQUFPO1FBRWpELElBQUksQ0FBQyxRQUFRLENBQUMsaUJBQWlCLEdBQUcsQ0FBQyxRQUFnQixFQUFFLEtBQWEsRUFBRSxLQUFjLEVBQUUsRUFBRTtZQUNsRixJQUFJLE9BQU8sS0FBSyxLQUFLLFFBQVE7Z0JBQUUsSUFBSSxDQUFDLGtCQUFrQixDQUFDLEtBQUssRUFBRSxLQUFLLENBQUMsQ0FBQztZQUNyRSxJQUFJLENBQUMsVUFBVSxDQUFDLFFBQVEsQ0FBQyxDQUFDLEtBQUssR0FBRyxLQUFLLENBQUM7WUFDeEMsSUFBSSxDQUFDLDBCQUEwQixDQUFDLFFBQVEsRUFBRSxLQUFLLENBQUMsQ0FBQztZQUNqRCxJQUFJLENBQUMsR0FBRyxDQUFDLE1BQU0sRUFBRSxDQUFDO1FBQ3RCLENBQUMsQ0FBQztRQUVGLElBQUksQ0FBQyxRQUFRLENBQUMsTUFBTSxHQUFHLEdBQUcsRUFBRSxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsTUFBTSxFQUFFLENBQUM7UUFFL0MsK0RBQStEO1FBQy9ELDJCQUEyQjtRQUMzQixnQ0FBZ0M7UUFDaEMsNERBQTREO1FBQzVELHNHQUFzRztRQUN0RyxZQUFZO1FBQ1osZUFBZTtRQUNmLGtDQUFrQztRQUNsQyw0REFBNEQ7UUFDNUQsOENBQThDO1FBQzlDLFFBQVE7UUFDUixLQUFLO0lBQ1QsQ0FBQztJQUVELGdGQUFnRjtJQUVoRiw0QkFBNEI7SUFDNUIsK0RBQStEO0lBQy9ELElBQUk7SUFFSiw4QkFBOEI7SUFDOUIsa0VBQWtFO0lBQ2xFLElBQUk7SUFFSiw4QkFBOEI7SUFDOUIseUNBQXlDO0lBQ3pDLCtDQUErQztJQUMvQyw2QkFBNkI7SUFDN0IsZUFBZTtJQUNmLElBQUk7SUFFSiw2RkFBNkY7SUFFN0YsdUVBQXVFO0lBQ3ZFLG1DQUFtQztJQUVuQyxnREFBZ0Q7SUFFaEQsZ0ZBQWdGO0lBQ2hGLDZDQUE2QztJQUM3QyxpQ0FBaUM7SUFDakMsY0FBYztJQUNkLFVBQVU7SUFDVixtRkFBbUY7SUFDbkYsNkNBQTZDO0lBQzdDLGlDQUFpQztJQUNqQyxjQUFjO0lBQ2QsVUFBVTtJQUNWLGdEQUFnRDtJQUNoRCxpQkFBaUI7SUFDakIsZ0NBQWdDO0lBQ2hDLFlBQVk7SUFDWixtQ0FBbUM7SUFDbkMsaUNBQWlDO0lBQ2pDLGNBQWM7SUFFZCwyQ0FBMkM7SUFDM0MsMkNBQTJDO0lBQzNDLHlDQUF5QztJQUV6Qyw4QkFBOEI7SUFDOUIsSUFBSTtJQUVKLHNFQUFzRTtJQUN0RSxpREFBaUQ7SUFDakQsaURBQWlEO0lBQ2pELHdEQUF3RDtJQUN4RCxVQUFVO0lBQ1YsSUFBSTtJQUVKLHVGQUF1RjtJQUUvRSxVQUFVLENBQUMsT0FBcUIsRUFBRSxjQUF3QjtRQUM5RCxtQ0FBbUM7UUFDbkMsSUFBSSxDQUFDLE1BQU0sR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsY0FBYyxDQUFDLENBQUMsQ0FBQztRQUN6RCxJQUFJLENBQUMsUUFBUSxDQUFDLGlCQUFpQixDQUFDLElBQUksQ0FBQyxNQUFNLEVBQUUsT0FBTyxJQUFJLEVBQUUsQ0FBQyxDQUFDO1FBRTVELHdHQUF3RztRQUN4RyxJQUFJLGNBQWM7WUFBRSxPQUFPO1FBRTNCLElBQUksQ0FBQyxhQUFhLENBQUMsT0FBTyxDQUFDLENBQUM7UUFFNUIsSUFBSSxDQUFDLGFBQWEsR0FBRyxLQUFLLENBQUM7UUFFM0IsSUFBSSxDQUFDLGNBQWMsRUFBRSxDQUFDO1FBRXRCLElBQUksQ0FBQyxtQkFBbUIsRUFBRSxDQUFDO1FBRTNCLElBQUksQ0FBQyxjQUFjLEVBQUUsQ0FBQztRQUd0QixvQ0FBb0M7UUFDcEMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxNQUFNLEdBQUcsT0FBTyxDQUFDO0lBQ3BDLENBQUM7SUFFTSxhQUFhLENBQUMsT0FBcUI7UUFDdEMsSUFBSSxDQUFDLHdCQUF3QixHQUFHLENBQUMsT0FBTyxDQUFDLEtBQUssQ0FBQyxRQUFRLENBQUMsS0FBSyxDQUFDLGFBQWEsQ0FBQyxDQUFDO1FBQzdFLElBQUksT0FBTyxDQUFDLEtBQUssQ0FBQyxRQUFRLENBQUMsS0FBSyxDQUFDLGFBQWEsQ0FBQyxJQUFJLE9BQU8sQ0FBQyxLQUFLLENBQUMsUUFBUSxDQUFDLEtBQUssQ0FBQyxhQUFhLENBQUMsS0FBSyxLQUFLLEVBQUU7WUFDdEcsSUFBSSxDQUFDLHdCQUF3QixHQUFHLElBQUksQ0FBQztTQUN4QztJQUNMLENBQUM7SUFFRCxvRkFBb0Y7SUFDNUUsY0FBYztRQUVsQixvREFBb0Q7UUFDcEQsSUFBSSxDQUFDLFlBQVksQ0FBQyxlQUFlLENBQUMsR0FBRyxFQUFFLENBQUM7UUFDeEMsSUFBSSxDQUFDLFlBQVksQ0FBQyxpQkFBaUIsQ0FBQyxHQUFHLEVBQUUsQ0FBQztRQUUxQyxJQUFJLE9BQU8sSUFBSSxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsS0FBSyxLQUFLLFNBQVMsSUFBSSxJQUFJLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxLQUFLLEVBQUU7WUFDM0UsSUFBSSxDQUFDLFlBQVksQ0FBQyxhQUFhLElBQUksZUFBZSxDQUFDO1lBQ25ELElBQUksQ0FBQyxZQUFZLENBQUMsZUFBZSxJQUFJLGVBQWUsQ0FBQztTQUN4RDtRQUVELElBQUksT0FBTyxJQUFJLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxhQUFhLEtBQUssU0FBUyxFQUFFO1lBQ3ZELElBQUksQ0FBQyxZQUFZLENBQUMsYUFBYSxJQUFJLElBQUksQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLGFBQWEsR0FBRyxHQUFHLENBQUM7WUFDMUUsSUFBSSxDQUFDLFlBQVksQ0FBQyxlQUFlLElBQUksSUFBSSxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsYUFBYSxHQUFHLEdBQUcsQ0FBQztTQUMvRTtRQUVELElBQUksT0FBTyxJQUFJLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxLQUFLLEtBQUssU0FBUyxFQUFFO1lBQy9DLElBQUksQ0FBQyxZQUFZLENBQUMsYUFBYSxJQUFJLElBQUksQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLEtBQUssR0FBRyxHQUFHLENBQUM7WUFDbEUsSUFBSSxDQUFDLFlBQVksQ0FBQyxlQUFlLElBQUksSUFBSSxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsS0FBSyxHQUFHLEdBQUcsQ0FBQztTQUN2RTtRQUVELElBQUksSUFBSSxDQUFDLGFBQWEsS0FBSyxLQUFLLElBQUksSUFBSSxDQUFDLGFBQWEsS0FBSyxLQUFLO1lBQUUsT0FBTztRQUN6RSxJQUFJLENBQUMsYUFBYSxHQUFHLElBQUksQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLFFBQVEsQ0FBQztRQUVoRCx1REFBdUQ7UUFDdkQsSUFBSSxDQUFDLFlBQVksR0FBRyxJQUFJLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxLQUFLLEtBQUssSUFBSSxJQUFJLENBQUMsU0FBUyxDQUFDLHVCQUF1QixDQUFDLElBQUksQ0FBQyxTQUFTLEVBQUUsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDO1FBQ3ZILElBQUksQ0FBQyxZQUFZLEdBQUcsSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsS0FBSyxLQUFLLElBQUksSUFBSSxDQUFDLFNBQVMsQ0FBQyx1QkFBdUIsQ0FBQyxJQUFJLENBQUMsU0FBUyxFQUFFLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQztRQUV2SCx5RUFBeUU7UUFDekUsSUFBSSxDQUFDLGVBQWUsR0FBRyxJQUFJLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxLQUFLLEtBQUssQ0FBQztRQUNuRCxJQUFJLENBQUMsc0JBQXNCLEdBQUcsSUFBSSxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLE1BQU0sR0FBRyxDQUFDLENBQUMsS0FBSyxPQUFPLENBQUM7UUFDcEYsSUFBSSxDQUFDLGVBQWUsR0FBRyxDQUFDLElBQUksQ0FBQyxhQUFhLEtBQUssS0FBSyxJQUFJLElBQUksQ0FBQyxhQUFhLEtBQUssUUFBUSxDQUFFLElBQUksSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsS0FBSyxPQUFPLElBQUksSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsS0FBSyxVQUFVLENBQUM7SUFDbkssQ0FBQztJQUVPLDBCQUEwQixDQUFDLFNBQVMsRUFBRSxNQUFlO1FBQ3pELElBQUksUUFBUSxHQUFXLFNBQVMsRUFBRSxZQUF5QixDQUFDO1FBQzVELGtEQUFrRDtRQUNsRCxJQUFJLENBQUMsUUFBUSxFQUFFO1lBQ1gsZ0NBQWdDO1lBQ2hDLElBQUksTUFBTSxLQUFLLElBQUksSUFBSSxNQUFNLEtBQUssU0FBUztnQkFBRSxPQUFPO1lBQ3BELFFBQVEsR0FBRyxJQUFJLENBQUMsVUFBVSxDQUFDLE1BQU0sQ0FBQyxDQUFDO1NBQ3RDO1FBQ0QsWUFBWSxHQUFHLElBQUksQ0FBQyxVQUFVLENBQUMsUUFBUSxDQUFDLENBQUM7UUFDekMsSUFBSSxDQUFDLGlCQUFpQixDQUFDLFFBQVEsRUFBRSxZQUFZLENBQUMsQ0FBQztJQUNuRCxDQUFDO0lBR08sbUJBQW1CLENBQUMsS0FBYztRQUN0QyxJQUFJLENBQUMsSUFBSSxDQUFDLFVBQVU7WUFBRSxPQUFPO1FBRTdCLElBQUksQ0FBQyxVQUFVLEdBQUcsTUFBTSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLENBQUM7UUFFL0MsS0FBSyxJQUFJLENBQUMsR0FBVyxDQUFDLEVBQUUsQ0FBQyxHQUFHLElBQUksQ0FBQyxVQUFVLENBQUMsTUFBTSxFQUFFLENBQUMsRUFBRSxFQUFFO1lBQ3JELElBQUksUUFBUSxHQUFXLElBQUksQ0FBQyxVQUFVLENBQUMsQ0FBQyxDQUFDLENBQUM7WUFDMUMsSUFBSSxZQUFZLEdBQWdCLElBQUksQ0FBQyxVQUFVLENBQUMsUUFBUSxDQUFDLENBQUM7WUFFMUQsb0RBQW9EO1lBQ3BELHVGQUF1RjtZQUN2RixtREFBbUQ7WUFDbkQsb0RBQW9EO1lBQ3BELHlEQUF5RDtZQUN6RCx3RkFBd0Y7WUFDeEYsbURBQW1EO1lBRW5ELCtEQUErRDtZQUMvRCx1REFBdUQ7WUFFdkQsNlBBQTZQO1lBQzdQLCtFQUErRTtZQUUvRSxtREFBbUQ7WUFDbkQsSUFBSSxDQUFDLGlCQUFpQixDQUFDLFFBQVEsRUFBRSxZQUFZLENBQUMsQ0FBQztTQUNsRDtJQUNMLENBQUM7SUFFTyxjQUFjO1FBQ2xCLElBQUksSUFBSSxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLE9BQU8sRUFBRTtZQUNsQyxJQUFJLFVBQVUsR0FBVyxJQUFJLENBQUMsU0FBUyxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLENBQUM7WUFFakYsSUFBSSxDQUFDLGdCQUFnQixDQUFDLFVBQVUsRUFBRSxPQUFPLEVBQUUsSUFBSSxDQUFDLENBQUM7U0FDcEQ7SUFDTCxDQUFDO0lBRU8sUUFBUSxDQUFDLEtBQVU7UUFDdkIsSUFBSSxDQUFDLGNBQWMsR0FBRyxFQUFFLENBQUM7UUFDekIsSUFBSSxDQUFDLGFBQWEsR0FBRyxFQUFFLENBQUM7UUFDeEIsSUFBSSxDQUFDLGFBQWEsQ0FBQyxLQUFLLENBQUMsQ0FBQztRQUUxQixJQUFJLElBQUksQ0FBQyxNQUFNLENBQUMsV0FBVyxFQUFFO1lBQ3pCLElBQUksQ0FBQyxJQUFJLEdBQUcsS0FBSyxDQUFDO1lBQ2xCLElBQUksQ0FBQyxVQUFVLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDO1lBQzdCLE9BQU87U0FDVjtRQUVELElBQUksSUFBSSxDQUFDLGFBQWEsS0FBSyxLQUFLLElBQUksSUFBSSxDQUFDLGFBQWEsS0FBSyxLQUFLLEVBQUU7WUFDOUQsSUFBSSxJQUFJLENBQUMsYUFBYSxLQUFLLEtBQUs7Z0JBQUUsSUFBSSxDQUFDLGtCQUFrQixDQUFDLEtBQUssQ0FBQyxDQUFDO2lCQUM1RCxJQUFJLElBQUksQ0FBQyxhQUFhLEtBQUssS0FBSztnQkFBRSxJQUFJLENBQUMsa0JBQWtCLENBQUMsS0FBSyxDQUFDLENBQUM7WUFDdEUsNERBQTREO1lBQzVELElBQUksQ0FBQyxVQUFVLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDO1NBQ2hDOztZQUFNLElBQUksQ0FBQyxZQUFZLENBQUMsS0FBSyxDQUFDLENBQUM7UUFFaEMsc0RBQXNEO1FBQ3RELElBQUksQ0FBQyxVQUFVLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQztRQUVoQyxnRUFBZ0U7UUFDaEUsSUFBSSxDQUFDLGdCQUFnQixDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLENBQUM7SUFDaEQsQ0FBQztJQUVPLGFBQWEsQ0FBQyxLQUFLO1FBQ3ZCLElBQUksU0FBUyxHQUFRLEtBQUssQ0FBQztRQUMzQixJQUFJLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxXQUFXLElBQUksQ0FBQyxLQUFLLENBQUMsS0FBSyxJQUFJLEtBQUssQ0FBQyxLQUFLLENBQUMsSUFBSSxJQUFJLEtBQUssQ0FBQyxFQUFFO1lBQ3hFLFNBQVMsR0FBRyxLQUFLLENBQUMsS0FBSyxDQUFDO1NBQzNCO1FBQ0QsSUFBSSxDQUFDLGFBQWEsR0FBRyxTQUFTLENBQUMsSUFBSSxDQUFDO1FBQ3BDLElBQUksQ0FBQyxTQUFTLEdBQUcsU0FBUyxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLENBQUM7UUFDN0MsSUFBSSxDQUFDLFdBQVcsR0FBRyxTQUFTLENBQUMsSUFBSSxLQUFLLEtBQUssSUFBSSxTQUFTLENBQUMsSUFBSSxLQUFLLEtBQUssQ0FBQztJQUM1RSxDQUFDO0lBRU8sa0JBQWtCLENBQUMsTUFBYyxFQUFFLE1BQWM7UUFDckQsSUFBSSxNQUFNLEdBQUcsQ0FBQyxFQUFFO1lBQUUsT0FBTztTQUFFO1FBQzNCLDRJQUE0STtRQUM1SSxJQUFJLFNBQVMsR0FBa0IsTUFBTSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLENBQUM7UUFDNUQsSUFBSSxJQUFJLENBQUMsYUFBYSxJQUFJLEtBQUssRUFBRTtZQUM3QixLQUFLLElBQUksTUFBTSxHQUFXLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLE1BQU0sR0FBRyxDQUFDLEVBQUUsTUFBTSxJQUFJLENBQUMsRUFBRSxNQUFNLEVBQUUsRUFBRTtnQkFDeEUsS0FBSyxJQUFJLE1BQU0sR0FBVyxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxHQUFHLENBQUMsRUFBRSxNQUFNLElBQUksQ0FBQyxFQUFFLE1BQU0sRUFBRSxFQUFFO29CQUNsRixJQUFJLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxFQUFFLEtBQUssU0FBUyxDQUFDLE1BQU0sQ0FBQyxFQUFFO3dCQUMzRCxJQUFJLENBQUMsYUFBYSxDQUFDLE1BQU0sRUFBRSxNQUFNLEVBQUUsT0FBTyxDQUFDLENBQUM7d0JBQzVDLElBQUksQ0FBQyxhQUFhLENBQUMsTUFBTSxFQUFFLE1BQU0sRUFBRSxPQUFPLENBQUMsQ0FBQztxQkFDL0M7aUJBQ0o7YUFDSjtTQUNKO0lBQ0wsQ0FBQztJQUVPLGFBQWEsQ0FBQyxPQUFlLEVBQUUsT0FBZSxFQUFFLFFBQTJCO1FBQy9FLElBQUksUUFBUSxHQUFXLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxFQUFFLENBQUM7UUFDN0QsSUFBSSxNQUFNLEdBQVEsSUFBSSxDQUFDLFVBQVUsQ0FBQyxRQUFRLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQztRQUN0RCxJQUFJLFFBQVEsS0FBSyxPQUFPLEVBQUU7WUFDdEIsTUFBTSxHQUFHLElBQUksQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLENBQUM7U0FDaEM7UUFDRCxJQUFJLElBQUksQ0FBQyxlQUFlLENBQUMsT0FBTyxFQUFFLE9BQU8sRUFBRSxRQUFRLENBQUMsRUFBRTtZQUNsRCxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsUUFBUSxDQUFDLEdBQUcsTUFBTSxDQUFDO1NBQ3pEO0lBQ0wsQ0FBQztJQUVPLGVBQWUsQ0FBQyxPQUFlLEVBQUUsT0FBZSxFQUFFLFFBQTJCO1FBQ2pGLElBQUksWUFBWSxHQUFZLElBQUksQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLGNBQWMsQ0FBQyx3QkFBd0IsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxzQkFBc0IsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDO1FBQ3pJLElBQUksWUFBWSxFQUFFO1lBQ2QsT0FBTyxJQUFJLENBQUM7U0FDZjthQUFNO1lBQ0gsSUFBSSxJQUFJLENBQUMsU0FBUyxDQUFDLE1BQU0sQ0FBQyxPQUFPLENBQUMsQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLENBQUMsY0FBYyxDQUFDLFFBQVEsQ0FBQyxFQUFFO2dCQUN2RSxJQUFJLElBQUksQ0FBQyxTQUFTLENBQUMsTUFBTSxDQUFDLE9BQU8sQ0FBQyxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsQ0FBQyxRQUFRLENBQUMsS0FBSyxJQUFJLElBQUksSUFBSSxDQUFDLFNBQVMsQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLE1BQU0sR0FBRyxDQUFDLEVBQUU7b0JBQ3RJLE9BQU8sS0FBSyxDQUFDO2lCQUNoQjthQUNKO1NBQ0o7UUFDRCxPQUFPLElBQUksQ0FBQztJQUNoQixDQUFDO0lBRU0sYUFBYSxDQUFDLEdBQVc7UUFDNUIsSUFBSSxZQUFZLEdBQWdCLElBQUksQ0FBQyxVQUFVLENBQUMsR0FBRyxDQUFDLENBQUM7UUFFckQsWUFBWSxDQUFDLFFBQVEsR0FBRyxDQUFDLFlBQVksQ0FBQyxRQUFRLElBQUksS0FBSyxDQUFDO1FBRXhELElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxHQUFHLEVBQUUsWUFBWSxDQUFDLENBQUM7UUFFMUMsSUFBSSxZQUFZLENBQUMsUUFBUSxFQUFFO1lBQ3ZCLElBQUksQ0FBQyxjQUFjLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFDO1NBQ2pDO2FBQU07WUFDSCxJQUFJLE9BQU8sR0FBVyxJQUFJLENBQUMsY0FBYyxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsQ0FBQztZQUN2RCxJQUFJLE9BQU8sS0FBSyxDQUFDLENBQUMsRUFBRTtnQkFDaEIsSUFBSSxDQUFDLGNBQWMsQ0FBQyxNQUFNLENBQUMsT0FBTyxFQUFFLENBQUMsQ0FBQyxDQUFDO2FBQzFDO1NBQ0o7UUFFRCxJQUFJLElBQUksQ0FBQyxhQUFhLElBQUksS0FBSyxFQUFFO1lBQzdCLElBQUksVUFBVSxHQUFtQyxJQUFJLENBQUMsWUFBWSxFQUFFLENBQUM7WUFDckUsSUFBSSxJQUFJLEdBQVksSUFBSSxDQUFDLFVBQVUsQ0FBQyxVQUFVLENBQUMsQ0FBQztZQUVoRCxJQUFJLENBQUMsR0FBRyxDQUFDLFdBQVcsQ0FBQyxJQUFJLEVBQUUsVUFBVSxDQUFDLENBQUM7WUFDdkMsSUFBSSxDQUFDLGdCQUFnQixDQUFDLEdBQUcsRUFBRSxZQUFZLENBQUMsUUFBUSxDQUFDLENBQUM7WUFDbEQsMkRBQTJEO1lBQzNELElBQUksQ0FBQyxVQUFVLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDO1NBQzlCO2FBQU07WUFDSCxJQUFJLENBQUMsR0FBRyxDQUFDLFdBQVcsQ0FBQyxHQUFHLEVBQUUsWUFBWSxDQUFDLFFBQVEsQ0FBQyxDQUFDO1NBQ3BEO0lBRUwsQ0FBQztJQUVNLGNBQWMsQ0FBQyxHQUFRO1FBQzFCLElBQUksZ0JBQWdCLEdBQWdCLElBQUksQ0FBQyxXQUFXLENBQUMsYUFBYSxDQUFDLGFBQWEsQ0FBQyxRQUFRLEdBQUcsR0FBRyxDQUFDLEVBQUUsR0FBRyxrQkFBa0IsQ0FBQyxDQUFDO1FBQ3pILElBQUksZUFBZSxHQUFnQixJQUFJLENBQUMsV0FBVyxDQUFDLGFBQWEsQ0FBQyxhQUFhLENBQUMsUUFBUSxHQUFHLEdBQUcsQ0FBQyxFQUFFLEdBQUcsb0JBQW9CLENBQUMsQ0FBQztRQUUxSCxJQUFJLENBQUMsR0FBRyxDQUFDLFlBQVksQ0FBQyxHQUFHLEVBQUUsRUFBQyxrQkFBa0IsRUFBRSxnQkFBZ0IsRUFBRSxpQkFBaUIsRUFBRSxlQUFlLEVBQUMsQ0FBQyxDQUFDO0lBQzNHLENBQUM7SUFFTSxlQUFlLENBQUMsV0FBMkM7UUFDOUQsSUFBSSxJQUFJLENBQUMsYUFBYSxJQUFJLEtBQUssSUFBSSxNQUFNLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxDQUFDLE1BQU0sSUFBSSxDQUFDLEVBQUU7WUFDckUsSUFBSSxDQUFDLGFBQWEsR0FBRyxJQUFJLENBQUM7U0FDN0I7YUFBTTtZQUNILElBQUksQ0FBQyxVQUFVLEdBQUcsV0FBVyxDQUFDO1lBQzlCLElBQUksQ0FBQyxhQUFhLEdBQUcsS0FBSyxDQUFDO1lBQzNCLElBQUksQ0FBQyxZQUFZLEdBQUcsSUFBSSxDQUFDO1lBQ3pCLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxDQUFDO1lBQzVDLElBQUksQ0FBQyxtQkFBbUIsQ0FBQyxTQUFTLENBQUMsQ0FBQztTQUN2QztJQUNMLENBQUM7SUFFTSxhQUFhLENBQUMsS0FBVTtRQUMzQiwrQkFBK0I7UUFDL0IsSUFBSSxDQUFDLFVBQVUsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLENBQUM7SUFDaEMsQ0FBQztJQUVNLFFBQVEsQ0FBQyxNQUFlO1FBQzNCLElBQUksQ0FBQyxjQUFjLEdBQUcsTUFBTSxDQUFDO0lBQ2pDLENBQUM7SUFFTyxpQkFBaUIsQ0FBQyxHQUFHLEVBQUUsYUFBYTtRQUN4QyxJQUFJLENBQUMsaUJBQWlCLENBQUMsR0FBRyxFQUFFLGFBQWEsQ0FBQyxDQUFDO1FBQzNDLElBQUksU0FBUyxHQUFXLENBQUMsYUFBYSxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsYUFBYSxJQUFJLFNBQVMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxLQUFLLElBQUksSUFBSSxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLFdBQVcsSUFBSSxTQUFTLENBQUM7UUFDaE0sSUFBSSxDQUFDLFdBQVcsQ0FBQyxhQUFhLENBQUMsYUFBYSxDQUFDLFFBQVEsR0FBRyxHQUFHLENBQUMsQ0FBQyxLQUFLLENBQUMsS0FBSyxHQUFHLFNBQVMsQ0FBQztJQUN6RixDQUFDO0lBRU8saUJBQWlCLENBQUMsR0FBRyxFQUFFLGFBQWE7UUFDeEMsSUFBSSxTQUFTLEdBQVcsQ0FBQyxhQUFhLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxhQUFhLElBQUksU0FBUyxDQUFDLENBQUMsQ0FBQyxhQUFhLENBQUMsS0FBSyxJQUFJLFNBQVMsQ0FBQztRQUN6SSxJQUFJLFFBQVEsR0FBVyxJQUFJLENBQUMsY0FBYyxDQUFDLFVBQVUsQ0FBQyxTQUFTLENBQUMsQ0FBQztRQUNqRSxJQUFJLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxHQUFHLElBQUksQ0FBQyxVQUFVLENBQUMsOEJBQThCLENBQUMsd0VBQXdFLEdBQUcsUUFBUSxHQUFHLGtDQUFrQyxHQUFHLElBQUksQ0FBQyxNQUFNLENBQUMsYUFBYSxDQUFDLEtBQUssQ0FBQyxHQUFHLFdBQVcsQ0FBQyxDQUFDO0lBQ2hQLENBQUM7SUFFTyxnQkFBZ0IsQ0FBQyxFQUFVLEVBQUUsUUFBaUI7UUFDbEQsSUFBSSxZQUFZLEdBQVcsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUM7UUFDeEQsSUFBSSxDQUFDLGdCQUFnQixDQUFDLFlBQVksRUFBRSxLQUFLLEdBQUcsRUFBRSxDQUFDLENBQUM7UUFDaEQsSUFBSSxDQUFDLFFBQVE7WUFBRSxJQUFJLENBQUMsZ0JBQWdCLENBQUMsVUFBVSxHQUFHLFlBQVksRUFBRSxLQUFLLEdBQUcsRUFBRSxHQUFHLE9BQU8sRUFBRSxJQUFJLENBQUMsQ0FBQztJQUNoRyxDQUFDO0lBRU8sZ0JBQWdCLENBQUMsTUFBYyxFQUFFLE1BQWMsRUFBRSxlQUF5QjtRQUM5RSxNQUFNLEdBQUcsTUFBTSxJQUFJLEVBQUUsQ0FBQztRQUN0QixJQUFJLFFBQVEsR0FBZ0IsSUFBSSxDQUFDLFdBQVcsQ0FBQyxhQUFhLENBQUMsZ0JBQWdCLENBQUMsR0FBRyxHQUFHLElBQUksQ0FBQyxNQUFNLENBQUMsRUFBRSxHQUFHLHlCQUF5QixHQUFHLE1BQU0sQ0FBQyxDQUFDO1FBQ3ZJLEtBQUssSUFBSSxDQUFDLElBQUksUUFBUSxFQUFFO1lBQ3BCLElBQUksUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssRUFBRTtnQkFFbkIsSUFBSSxlQUFlLEVBQUU7b0JBQ2pCLElBQUksVUFBVSxHQUFXLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxXQUFXLENBQUM7b0JBQ2pELElBQUksV0FBVyxHQUFXLENBQUMsVUFBVSxHQUFHLFVBQVUsR0FBRyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDLFFBQVEsRUFBRSxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsQ0FBQztvQkFDbEcsSUFBSSxhQUFhLEdBQVcsQ0FBQyxHQUFHLFdBQVcsQ0FBQztvQkFFNUMsTUFBTSxJQUFJLE9BQU8sR0FBRyxhQUFhLEdBQUcsS0FBSyxDQUFDO29CQUMxQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxHQUFHLE1BQU0sQ0FBQztpQkFDOUI7cUJBQU07b0JBQ0gsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxPQUFPLEdBQUcsTUFBTSxDQUFDO2lCQUN0QzthQUNKO1NBQ0o7SUFDTCxDQUFDO0lBRU8sWUFBWTtRQUNoQixJQUFJLFVBQVUsR0FBbUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxFQUFFLEVBQUUsSUFBSSxDQUFDLFVBQVUsQ0FBQyxDQUFDO1FBQ3BGLElBQUksY0FBYyxHQUFrQixJQUFJLENBQUMsY0FBYyxDQUFDO1FBQ3hELFVBQVUsR0FBRyxNQUFNLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQzthQUMvQixNQUFNLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxDQUFDLGNBQWMsQ0FBQyxRQUFRLENBQUMsR0FBRyxDQUFDLENBQUM7YUFDNUMsTUFBTSxDQUFDLENBQUMsR0FBRyxFQUFFLEdBQUcsRUFBRSxFQUFFO1lBQ2pCLEdBQUcsQ0FBQyxHQUFHLENBQUMsR0FBRyxVQUFVLENBQUMsR0FBRyxDQUFDLENBQUM7WUFDM0IsT0FBTyxHQUFHLENBQUM7UUFDZixDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUM7UUFDWCxPQUFPLFVBQVUsQ0FBQztJQUN0QixDQUFDO0lBRU8sVUFBVSxDQUFDLFdBQTRDO1FBQzNELElBQUksUUFBUSxHQUFZLElBQUksQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQztRQUM5RCxJQUFJLGNBQWMsR0FBa0IsSUFBSSxDQUFDLGNBQWMsQ0FBQztRQUV4RCxJQUFJLElBQUksQ0FBQyxhQUFhLEtBQUssS0FBSyxFQUFFO1lBQzlCLElBQUksVUFBVSxHQUFRLFdBQVcsQ0FBQztZQUNsQywwQ0FBMEM7WUFDMUMsUUFBUSxDQUFDLElBQUksR0FBRyxNQUFNLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLFVBQVUsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLEtBQUssRUFBRSxFQUFFLENBQUMsS0FBSyxDQUFDLENBQUMsSUFBSSxLQUFLLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDO1lBQzlHLE9BQU8sUUFBUSxDQUFDO1NBQ25CO2FBQU0sSUFBSSxJQUFJLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxLQUFLLEtBQUssSUFBSSxJQUFJLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxLQUFLLE1BQU0sRUFBRTtZQUNwRSxLQUFLLElBQUksQ0FBQyxHQUFXLFFBQVEsQ0FBQyxJQUFJLENBQUMsTUFBTSxHQUFHLENBQUMsRUFBRSxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFO2dCQUN4RCxJQUFJLE9BQU8sR0FBb0IsUUFBUSxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxjQUFjLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDO2dCQUM5RixRQUFRLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxHQUFHLE1BQU0sQ0FBQyxNQUFNLENBQUMsRUFBRSxFQUFFLFFBQVEsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLEVBQUUsRUFBRSxDQUFDLEVBQUUsT0FBTyxFQUFFLENBQUMsQ0FBQzthQUMxRTtTQUNKO1FBRUQsSUFBSSxZQUFZLEdBQVksSUFBSSxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUM7UUFFakUsSUFBSSxZQUFZLEdBQWtCLENBQUMsQ0FBQyxDQUFDLENBQUM7UUFDdEMsSUFBSSxZQUFZLEdBQWtCLENBQUMsQ0FBQyxDQUFDLENBQUM7UUFDdEMsSUFBSSxZQUFZLEdBQVksS0FBSyxDQUFDO1FBRWxDLEtBQUssSUFBSSxDQUFDLEdBQVcsQ0FBQyxFQUFFLENBQUMsR0FBRyxZQUFZLENBQUMsSUFBSSxDQUFDLE1BQU0sRUFBRSxDQUFDLEVBQUUsRUFBRTtZQUN2RCxJQUFJLFFBQVEsR0FBVyxDQUFDLENBQUM7WUFDekIsSUFBSSxJQUFJLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxLQUFLLEtBQUssRUFBRTtnQkFDN0IsUUFBUSxHQUFHLFFBQVEsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLEdBQUcsRUFBRSxJQUFJLEVBQUUsTUFBTSxFQUFFLEVBQUU7b0JBQ3ZELElBQUksY0FBYyxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDO3dCQUFFLE9BQU8sR0FBRyxDQUFDO29CQUNqRCxPQUFPLEdBQUcsR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDO2dCQUM1QixDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUM7YUFDVDtZQUVELElBQUksT0FBTyxHQUFlLEVBQUUsQ0FBQztZQUM3QixJQUFJLE1BQU0sR0FBa0IsRUFBRSxDQUFDO1lBQy9CLElBQUksR0FBRyxHQUFXLENBQUMsQ0FBQztZQUNwQixJQUFJLFdBQVcsR0FBVyxDQUFDLENBQUM7WUFFNUIsS0FBSyxJQUFJLE1BQU0sR0FBVyxDQUFDLEVBQUUsTUFBTSxHQUFHLFlBQVksQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sRUFBRSxNQUFNLEVBQUUsRUFBRTtnQkFDM0UsSUFBSSxLQUFLLEdBQWEsTUFBTSxDQUFDLE1BQU0sQ0FBQyxFQUFFLEVBQUUsWUFBWSxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQztnQkFDeEUsSUFBSSxjQUFjLENBQUMsUUFBUSxDQUFDLEtBQUssQ0FBQyxFQUFFLENBQUM7b0JBQUUsU0FBUztnQkFDaEQsSUFBSSxVQUFVLEdBQVcsS0FBSyxDQUFDLEtBQUssS0FBSyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQztnQkFDaEUsSUFBSSxRQUFRLEdBQVcsSUFBSSxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsQ0FBQztnQkFFN0MsSUFBSSxRQUFRLEdBQUcsQ0FBQyxJQUFJLENBQUMsWUFBWSxFQUFFO29CQUMvQixZQUFZLEdBQUcsSUFBSSxDQUFDO29CQUNwQixJQUFJLElBQUksQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLEtBQUssS0FBSyxFQUFFO3dCQUM3QixJQUFJLENBQUMsU0FBUyxHQUFHLElBQUksQ0FBQzt3QkFDdEIsTUFBTTtxQkFDVDtpQkFDSjtnQkFFRCxJQUFJLElBQUksQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLEtBQUssS0FBSyxJQUFJLElBQUksQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLEtBQUssT0FBTyxFQUFFO29CQUM5RCxJQUFJLFFBQVEsSUFBSSxDQUFDLEVBQUU7d0JBQ2YsR0FBRyxHQUFHLENBQUMsVUFBVSxLQUFLLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLEdBQUcsR0FBRyxVQUFVLENBQUM7cUJBQ3hEO3lCQUFNO3dCQUNILFdBQVcsR0FBRyxDQUFDLFVBQVUsS0FBSyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQyxXQUFXLEdBQUcsVUFBVSxDQUFDO3FCQUNoRjtpQkFDSjtxQkFBTSxJQUFJLElBQUksQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLEtBQUssS0FBSyxFQUFFO29CQUNwQyxJQUFJLFVBQVUsS0FBSyxJQUFJLElBQUksUUFBUSxLQUFLLENBQUMsRUFBRTt3QkFDdkMsVUFBVSxHQUFHLFVBQVUsR0FBRyxRQUFRLEdBQUcsR0FBRyxDQUFDO3dCQUN6QyxHQUFHLEdBQUcsR0FBRyxHQUFHLFVBQVUsQ0FBQztxQkFDMUI7eUJBQU07d0JBQ0gsR0FBRyxHQUFHLEdBQUcsQ0FBQztxQkFDYjtpQkFDSjtxQkFBTTtvQkFDSCxJQUFJLFFBQVEsSUFBSSxDQUFDLEVBQUU7d0JBQ2YsR0FBRyxHQUFHLENBQUMsVUFBVSxLQUFLLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFVBQVUsQ0FBQztxQkFDaEQ7eUJBQU07d0JBQ0gsV0FBVyxHQUFHLENBQUMsVUFBVSxLQUFLLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFVBQVUsQ0FBQztxQkFDeEQ7aUJBQ0o7Z0JBQ0QsS0FBSyxDQUFDLEdBQUcsR0FBRyxVQUFVLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLFdBQVcsQ0FBQztnQkFFaEQsa0hBQWtIO2dCQUNsSCxJQUFJLElBQUksQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLEtBQUssS0FBSztvQkFBRSxLQUFLLENBQUMsV0FBVyxDQUFDLEdBQUcsVUFBVSxDQUFDO2dCQUVqRSxNQUFNLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDO2dCQUMzRCxPQUFPLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFDO2FBQ3ZCO1lBQ0QsWUFBWSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLGFBQWEsQ0FBQyxNQUFNLEVBQUUsS0FBSyxDQUFDLENBQUMsQ0FBQztZQUMvRCxZQUFZLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsYUFBYSxDQUFDLE1BQU0sRUFBRSxLQUFLLENBQUMsQ0FBQyxDQUFDO1lBQy9ELFFBQVEsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLEdBQUcsTUFBTSxDQUFDLE1BQU0sQ0FBQyxFQUFFLEVBQUUsWUFBWSxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsRUFBRSxFQUFFLENBQUMsRUFBRSxPQUFPLEVBQUUsQ0FBQyxDQUFDO1NBQzlFO1FBRUQsUUFBUSxDQUFDLE9BQU8sQ0FBQyxHQUFHO1lBQ2hCLEdBQUcsRUFBRSxJQUFJLENBQUMsU0FBUyxDQUFDLGFBQWEsQ0FBQyxZQUFZLEVBQUUsS0FBSyxDQUFDO1lBQ3RELEdBQUcsRUFBRSxJQUFJLENBQUMsU0FBUyxDQUFDLGFBQWEsQ0FBQyxZQUFZLEVBQUUsS0FBSyxDQUFDO1NBQ3pELENBQUM7UUFDRixRQUFRLENBQUMsY0FBYyxDQUFDLEdBQUcsWUFBWSxDQUFDO1FBRXhDLE9BQU8sUUFBUSxDQUFDO0lBQ3BCLENBQUM7SUFFTyxtQkFBbUIsQ0FBQyxLQUFpQixFQUFFLGVBQXVCO1FBQ2xFLDBDQUEwQztRQUMxQyxJQUFJLENBQUMsVUFBVSxHQUFHLEVBQUUsQ0FBQztRQUNyQiwwQkFBMEI7UUFFMUIsSUFBSSxjQUFjLEdBQVcsRUFBRSxDQUFDO1FBQ2hDLElBQUksUUFBZ0IsRUFBRSxhQUEwQixDQUFDO1FBQ2pELElBQUksVUFBVSxHQUFtQyxFQUFFLENBQUM7UUFDcEQsS0FBSyxJQUFJLENBQUMsR0FBVyxDQUFDLEVBQUUsQ0FBQyxHQUFHLGVBQWUsRUFBRSxDQUFDLEVBQUUsRUFBRTtZQUM5QyxRQUFRLEdBQUcsQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxJQUFJLEtBQUssQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsSUFBSSxHQUFHLENBQUMsQ0FBQztZQUMzRixhQUFhLEdBQUc7Z0JBQ1osTUFBTSxFQUFFLEtBQUssQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSTtnQkFDNUIsSUFBSSxFQUFFLFFBQVE7Z0JBQ2QsT0FBTyxFQUFFLEtBQUssQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxJQUFJLElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxPQUFPLEVBQUUsQ0FBQyxDQUFDO2dCQUNwRSxPQUFPLEVBQUUsS0FBSyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLElBQUksSUFBSSxDQUFDLGlCQUFpQixDQUFDLE9BQU8sRUFBRSxDQUFDLENBQUM7YUFDdkUsQ0FBQztZQUNGLElBQUksSUFBSSxDQUFDLGFBQWEsS0FBSyxNQUFNLElBQUksSUFBSSxDQUFDLGFBQWEsS0FBSyxRQUFRLElBQUksSUFBSSxDQUFDLGFBQWEsS0FBSyxNQUFNLElBQUksSUFBSSxDQUFDLGFBQWEsS0FBSyxLQUFLLEVBQUU7Z0JBQ25JLGFBQWEsQ0FBQyxZQUFZLENBQUMsR0FBRyxDQUFDLE9BQU8sS0FBSyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxVQUFVLEtBQUssV0FBVyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUM7Z0JBQ3RILGFBQWEsQ0FBQyxnQkFBZ0IsQ0FBQyxHQUFHLENBQUMsT0FBTyxLQUFLLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLGNBQWMsS0FBSyxXQUFXLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxjQUFjLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztnQkFDL0gsYUFBYSxDQUFDLGdCQUFnQixDQUFDLEdBQUcsQ0FBQyxPQUFPLEtBQUssQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsY0FBYyxLQUFLLFdBQVcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLGNBQWMsQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDO2dCQUN2SSxJQUFJLElBQUksQ0FBQyxhQUFhLEtBQUssS0FBSztvQkFBRSxhQUFhLENBQUMsV0FBVyxDQUFDLEdBQUcsQ0FBQyxPQUFPLEtBQUssQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsU0FBUyxLQUFLLFdBQVcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDO2FBQzNKO1lBQ0QsVUFBVSxDQUFDLFFBQVEsQ0FBQyxHQUFHLGFBQWEsQ0FBQztZQUNyQyxjQUFjLENBQUMsQ0FBQyxDQUFDLEdBQUcsUUFBUSxDQUFDO1NBQ2hDO1FBQ0QsSUFBSSxDQUFDLFVBQVUsR0FBRyxVQUFVLENBQUM7UUFDN0IsT0FBTyxjQUFjLENBQUM7SUFDMUIsQ0FBQztJQUVPLFlBQVksQ0FBQyxLQUFpQjtRQUNsQyxJQUFJLFlBQVksR0FBVyxJQUFJLENBQUMsU0FBUyxDQUFDLGFBQWEsQ0FBQyxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsTUFBTSxFQUFFLElBQUksQ0FBQyxlQUFlLENBQUMsRUFBRSxLQUFLLENBQUMsQ0FBQztRQUM1RyxJQUFJLFlBQXlCLEVBQUUsa0JBQTRCLENBQUM7UUFDNUQsSUFBSSxTQUFTLEdBQVk7WUFDckIsTUFBTSxFQUFFLEtBQUssQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUk7WUFDeEQsUUFBUSxFQUFFLEtBQUssQ0FBQyxLQUFLLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUk7WUFDOUQsUUFBUSxFQUFFLElBQUksQ0FBQyxNQUFNLENBQUMsV0FBVyxJQUFJLElBQUksQ0FBQyxNQUFNLENBQUMsV0FBVyxDQUFDLGNBQWMsQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsV0FBVyxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRTtZQUNwSixNQUFNLEVBQUUsRUFBRTtTQUNiLENBQUM7UUFDRixJQUFJLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxjQUFjLENBQUMsSUFBSSxDQUFDLEVBQUU7WUFDbkMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsR0FBRyxLQUFLLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxHQUFHLElBQUksQ0FBQyxDQUFDLENBQUMsV0FBVyxDQUFDO1NBQ3RGO1FBRUQsSUFBSSxVQUFVLEdBQWtCLElBQUksQ0FBQyxTQUFTLENBQUMsb0JBQW9CLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxVQUFVLEVBQUUsSUFBSSxDQUFDLFVBQVUsQ0FBQyxDQUFDO1FBRTdHLElBQUksY0FBYyxHQUFXLElBQUksQ0FBQyxtQkFBbUIsQ0FBQyxLQUFLLEVBQUUsWUFBWSxDQUFDLENBQUM7UUFFM0UsSUFBSSxXQUFXLEdBQTJCLElBQUksQ0FBQyxZQUFZLENBQUMsS0FBSyxFQUFFLFlBQVksQ0FBQyxDQUFDO1FBQ2pGLElBQUksWUFBWSxHQUFrQixDQUFDLENBQUMsQ0FBQyxDQUFDO1FBQ3RDLElBQUksWUFBWSxHQUFrQixDQUFDLENBQUMsQ0FBQyxDQUFDO1FBQ3RDLElBQUksWUFBWSxHQUFZLEtBQUssQ0FBQztRQUVsQyxLQUFLLElBQUksQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLEdBQUcsVUFBVSxDQUFDLE1BQU0sRUFBRSxDQUFDLEVBQUUsRUFBRTtZQUN4QyxZQUFZLEdBQUc7Z0JBQ1gsR0FBRyxFQUFFO29CQUNELEtBQUssRUFBRSxDQUFDLENBQUMsUUFBUSxFQUFFO29CQUNuQixLQUFLLEVBQUUsVUFBVSxDQUFDLENBQUMsQ0FBQztpQkFDdkI7Z0JBQ0QsR0FBRyxFQUFFLEVBQUU7YUFFVixDQUFDO1lBRUYsSUFBSSxNQUFNLEdBQWtCLEVBQUUsQ0FBQztZQUMvQixJQUFJLEdBQUcsR0FBVyxDQUFDLENBQUM7WUFDcEIsSUFBSSxXQUFXLEdBQVcsQ0FBQyxDQUFDO1lBRTVCLElBQUksV0FBVyxHQUFpQixJQUFJLENBQUMsU0FBUyxDQUFDLGNBQWMsQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLGtCQUFrQixDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsRUFBRSxZQUFZLENBQUMsQ0FBQztZQUUvSCxtREFBbUQ7WUFDbkQsS0FBSyxJQUFJLENBQUMsR0FBVyxXQUFXLENBQUMsS0FBSyxFQUFFLFdBQVcsQ0FBQyxLQUFLLENBQUMsQ0FBQyxFQUFFLFdBQVcsQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLEdBQUcsV0FBVyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsRUFBRTtnQkFDdkcsSUFBSSxPQUFPLEtBQUssQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxLQUFLLFdBQVc7b0JBQUUsU0FBUztnQkFFN0QsSUFBSSxVQUFVLEdBQWtCLEtBQUssQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQztnQkFDOUQsSUFBSSxRQUFRLEdBQVcsSUFBSSxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsQ0FBQztnQkFFN0MsSUFBSSxPQUFPLFVBQVUsS0FBSyxXQUFXO29CQUFFLFNBQVM7Z0JBRWhELElBQUksUUFBUSxHQUFHLENBQUMsSUFBSSxDQUFDLFlBQVksRUFBRTtvQkFDL0IsWUFBWSxHQUFHLElBQUksQ0FBQztvQkFDcEIsSUFBSSxJQUFJLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxLQUFLLEtBQUs7d0JBQUUsTUFBTTtpQkFDMUM7Z0JBRUQsSUFBSSxJQUFJLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxLQUFLLEtBQUssSUFBSSxJQUFJLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxLQUFLLE9BQU8sRUFBRTtvQkFDOUQsSUFBSSxRQUFRLElBQUksQ0FBQyxFQUFFO3dCQUNmLEdBQUcsR0FBRyxDQUFDLFVBQVUsS0FBSyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxHQUFHLEdBQUcsVUFBVSxDQUFDO3FCQUN4RDt5QkFBTTt3QkFDSCxXQUFXLEdBQUcsQ0FBQyxVQUFVLEtBQUssSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUMsV0FBVyxHQUFHLFVBQVUsQ0FBQztxQkFDaEY7aUJBQ0o7cUJBQU0sSUFBSSxJQUFJLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxLQUFLLEtBQUssRUFBRTtvQkFDcEMsSUFBSSxVQUFVLEtBQUssSUFBSSxJQUFJLFdBQVcsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLEVBQUU7d0JBQzdDLFVBQVUsR0FBRyxVQUFVLEdBQUcsV0FBVyxDQUFDLENBQUMsQ0FBQyxHQUFHLEdBQUcsQ0FBQztxQkFDbEQ7eUJBQU07d0JBQ0gsVUFBVSxHQUFHLENBQUMsQ0FBQztxQkFDbEI7b0JBQ0QsR0FBRyxHQUFHLEdBQUcsR0FBRyxVQUFVLENBQUM7aUJBQzFCO3FCQUFNO29CQUNILElBQUksUUFBUSxJQUFJLENBQUMsRUFBRTt3QkFDZixHQUFHLEdBQUcsQ0FBQyxVQUFVLEtBQUssSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsVUFBVSxDQUFDO3FCQUNoRDt5QkFBTTt3QkFDSCxXQUFXLEdBQUcsQ0FBQyxVQUFVLEtBQUssSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsVUFBVSxDQUFDO3FCQUN4RDtpQkFDSjtnQkFFRCxrQkFBa0IsR0FBRztvQkFDakIsS0FBSyxFQUFFLFVBQVUsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsV0FBVztvQkFDMUMsT0FBTyxFQUFFLEtBQUssQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUs7b0JBQ3RDLE9BQU8sRUFBRSxJQUFJLENBQUMsVUFBVSxDQUFDLE9BQU8sRUFBRSxDQUFDLEVBQUUsS0FBSyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUM7b0JBQzdELE9BQU8sRUFBRSxJQUFJLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsT0FBTyxFQUFFLENBQUMsRUFBRSxLQUFLLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO29CQUMxRSxJQUFJLEVBQUUsY0FBYyxDQUFDLENBQUMsQ0FBQztpQkFDMUIsQ0FBQztnQkFFRixrSEFBa0g7Z0JBQ2xILElBQUksSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsS0FBSyxLQUFLO29CQUFFLGtCQUFrQixDQUFDLFdBQVcsQ0FBQyxHQUFHLFVBQVUsQ0FBQztnQkFFOUUsTUFBTSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQztnQkFDM0QsWUFBWSxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsa0JBQWtCLENBQUMsQ0FBQzthQUMzQztZQUVELFlBQVksQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxhQUFhLENBQUMsTUFBTSxFQUFFLEtBQUssQ0FBQyxDQUFDLENBQUM7WUFDL0QsWUFBWSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLGFBQWEsQ0FBQyxNQUFNLEVBQUUsS0FBSyxDQUFDLENBQUMsQ0FBQztZQUUvRCxTQUFTLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxZQUFZLENBQUMsQ0FBQztTQUNyQztRQUVELElBQUksS0FBSyxDQUFDLEtBQUssQ0FBQyxJQUFJLEtBQUssS0FBSyxFQUFFO1lBQzVCLFNBQVMsQ0FBQyxPQUFPLENBQUMsR0FBRztnQkFDakIsR0FBRyxFQUFFLElBQUksQ0FBQyxTQUFTLENBQUMsYUFBYSxDQUFDLFlBQVksRUFBRSxLQUFLLENBQUM7Z0JBQ3RELEdBQUcsRUFBRSxJQUFJLENBQUMsU0FBUyxDQUFDLGFBQWEsQ0FBQyxZQUFZLEVBQUUsS0FBSyxDQUFDO2FBQ3pELENBQUM7WUFDRixTQUFTLENBQUMsY0FBYyxDQUFDLEdBQUcsWUFBWSxDQUFDO1NBQzVDO1FBRUQsSUFBSSxDQUFDLElBQUksR0FBRyxTQUFTLENBQUM7UUFDdEIsSUFBSSxDQUFDLFNBQVMsR0FBRyxJQUFJLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxLQUFLLEtBQUssSUFBSSxZQUFZLENBQUM7UUFDN0QsSUFBSSxDQUFDLFVBQVUsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUM7SUFDakMsQ0FBQztJQUVPLGtCQUFrQixDQUFDLEtBQUs7UUFDNUIsSUFBSSxLQUFLLEtBQUssU0FBUyxJQUFJLEtBQUssS0FBSyxJQUFJLEVBQUU7WUFDdkMsSUFBSSxTQUFTLEdBQVk7Z0JBQ3JCLE1BQU0sRUFBRSxLQUFLLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJO2dCQUN4RCxRQUFRLEVBQUUsS0FBSyxDQUFDLEtBQUssQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSTtnQkFDOUQsUUFBUSxFQUFFLElBQUksQ0FBQyxNQUFNLENBQUMsV0FBVyxJQUFJLElBQUksQ0FBQyxNQUFNLENBQUMsV0FBVyxDQUFDLGNBQWMsQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsV0FBVyxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRTtnQkFDcEosTUFBTSxFQUFFLEVBQUU7YUFDYixDQUFDO1lBQ0YsSUFBSSxZQUFZLEdBQUcsSUFBSSxDQUFDLFNBQVMsQ0FBQyxvQkFBb0IsQ0FBQyxJQUFJLENBQUMsVUFBVSxFQUFFLEtBQUssRUFBRSxJQUFJLENBQUMsTUFBTSxFQUFFLElBQUksQ0FBQyxlQUFlLENBQUMsQ0FBQztZQUNsSCxTQUFTLENBQUMsU0FBUyxDQUFDLEdBQUcsWUFBWSxDQUFDLE9BQU8sQ0FBQztZQUM1QyxJQUFJLENBQUMsSUFBSSxHQUFHLFNBQVMsQ0FBQztZQUN0QixJQUFJLENBQUMsTUFBTSxDQUFDLFVBQVUsQ0FBQyxHQUFHLFlBQVksQ0FBQyxRQUFRLENBQUM7WUFDaEQsSUFBSSxDQUFDLFVBQVUsR0FBRyxZQUFZLENBQUMsVUFBVSxDQUFDO1lBQzFDLG1DQUFtQztTQUN0QztJQUNMLENBQUM7SUFFTyxrQkFBa0IsQ0FBQyxLQUFLO1FBQzVCLElBQUksQ0FBQyxJQUFJLEdBQUcsS0FBSyxDQUFDO1FBQ2xCLElBQUksQ0FBQyxnQkFBZ0IsRUFBRSxDQUFDO0lBQzVCLENBQUM7SUFFTyxnQkFBZ0I7UUFDcEIsSUFBSSxVQUFlLENBQUM7UUFDcEIsSUFBSSxJQUFJLENBQUMsSUFBSSxDQUFDLGVBQWUsQ0FBQyxJQUFJLElBQUksQ0FBQyxNQUFNLENBQUMsV0FBVyxFQUFFO1lBQ3ZELFVBQVUsR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxlQUFlLENBQUMsQ0FBQyxDQUFDLENBQUM7U0FDdkU7YUFBTTtZQUNILFVBQVUsR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUM7WUFDN0QsS0FBSyxJQUFJLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxHQUFHLFVBQVUsQ0FBQyxNQUFNLEVBQUUsQ0FBQyxFQUFFLEVBQUU7Z0JBQ3hDLFVBQVUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxVQUFVLENBQUMsR0FBRyxLQUFLLENBQUM7YUFDckM7U0FDSjtRQUNELElBQUksQ0FBQyxhQUFhLEdBQUcsS0FBSyxDQUFDO1FBQzNCLElBQUksQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLFdBQVcsRUFBRTtZQUMxQixJQUFJLElBQUksQ0FBQyxNQUFNLENBQUMsU0FBUyxJQUFJLFNBQVMsRUFBRTtnQkFDcEMsSUFBSSxJQUFJLENBQUMsTUFBTSxDQUFDLFNBQVMsQ0FBQyxXQUFXLElBQUksSUFBSSxDQUFDLE1BQU0sQ0FBQyxTQUFTLENBQUMsV0FBVyxDQUFDLE1BQU0sSUFBSSxDQUFDLEVBQUU7b0JBQ3BGLElBQUksQ0FBQyxVQUFVLEdBQUcsSUFBSSxDQUFDLFNBQVMsQ0FBQyxxQkFBcUIsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLFNBQVMsQ0FBQyxXQUFXLEVBQUUsSUFBSSxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsYUFBYSxFQUFFLElBQUksQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLFdBQVcsQ0FBQyxDQUFDO2lCQUMvSjtxQkFBTTtvQkFDSCxJQUFJLENBQUMsYUFBYSxHQUFHLElBQUksQ0FBQztpQkFDN0I7YUFDSjtpQkFBTTtnQkFDSCxJQUFJLENBQUMsVUFBVSxHQUFHLElBQUksQ0FBQyxTQUFTLENBQUMsZ0JBQWdCLENBQUMsSUFBSSxDQUFDLFVBQVUsRUFBRSxVQUFVLEVBQUUsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDO2FBQy9GO1NBQ0o7YUFBTTtZQUNILG1DQUFtQztZQUNuQyxJQUFJLElBQUksQ0FBQyxNQUFNLENBQUMsU0FBUyxJQUFJLFNBQVMsRUFBRTtnQkFDcEMsSUFBSSxJQUFJLENBQUMsTUFBTSxDQUFDLFNBQVMsQ0FBQyxXQUFXLElBQUksSUFBSSxDQUFDLE1BQU0sQ0FBQyxTQUFTLENBQUMsV0FBVyxDQUFDLE1BQU0sSUFBSSxDQUFDLEVBQUU7b0JBQ3BGLElBQUksQ0FBQyxVQUFVLEdBQUcsSUFBSSxDQUFDLFNBQVMsQ0FBQyxnQkFBZ0IsQ0FBQyxJQUFJLENBQUMsVUFBVSxFQUFFLFVBQVUsRUFBRSxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUM7aUJBQy9GO3FCQUFNO29CQUNILElBQUksQ0FBQyxhQUFhLEdBQUcsSUFBSSxDQUFDO2lCQUM3QjthQUNKO2lCQUFNO2dCQUNILElBQUksQ0FBQyxVQUFVLEdBQUcsSUFBSSxDQUFDLFNBQVMsQ0FBQyxnQkFBZ0IsQ0FBQyxJQUFJLENBQUMsVUFBVSxFQUFFLFVBQVUsRUFBRSxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUM7YUFDL0Y7U0FDSjtJQUNMLENBQUM7SUFFTyxZQUFZLENBQUMsS0FBaUIsRUFBRSxZQUFvQjtRQUN4RCxJQUFJLElBQUksQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLEtBQUssS0FBSyxFQUFFO1lBQzdCLE9BQU8sSUFBSSxDQUFDLFNBQVMsQ0FBQyx3QkFBd0IsQ0FBQyxLQUFLLENBQUMsTUFBTSxFQUFFLEtBQUssQ0FBQyxLQUFLLENBQUMsVUFBVSxFQUFFLFlBQVksQ0FBQyxDQUFDO1NBQ3RHO0lBQ0wsQ0FBQztJQUVPLFVBQVUsQ0FBQyxRQUFhLEVBQUUsWUFBb0IsRUFBRSxLQUFrQjtRQUV0RSxJQUFJLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxPQUFPLENBQUMsS0FBSyxDQUFDO1lBQUUsT0FBTztRQUUzQyxJQUFJLEtBQUssQ0FBQyxjQUFjLENBQUMsUUFBUSxDQUFDLElBQUksS0FBSyxDQUFDLFFBQVEsQ0FBQyxLQUFLLFNBQVMsRUFBRTtZQUNqRSxPQUFPLEtBQUssQ0FBQyxRQUFRLENBQUMsQ0FBQztTQUMxQjtRQUVELElBQUksTUFBTSxHQUFXLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxRQUFRLEVBQUUsWUFBWSxDQUFDLENBQUM7UUFDbkUsT0FBTyxNQUFNLENBQUM7SUFDbEIsQ0FBQztJQUVPLGdCQUFnQixDQUFDLFFBQWEsRUFBRSxZQUFvQjtRQUN4RCxJQUFJLFFBQVEsS0FBSyxPQUFPO1lBQ3BCLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxLQUFLLENBQUMsSUFBSSxLQUFLLEtBQUssSUFBSSxJQUFJLENBQUMsU0FBUyxDQUFDLEtBQUssQ0FBQyxJQUFJLEtBQUssS0FBSyxDQUFDLEVBQUU7WUFDOUUsT0FBTyxRQUFRLENBQUM7U0FDbkI7UUFFRCxJQUFJLGFBQWEsR0FBVyxJQUFJLENBQUMsaUJBQWlCLENBQUMsUUFBUSxFQUFFLFlBQVksQ0FBQyxDQUFDO1FBQzNFLElBQUksTUFBYyxDQUFDO1FBQ25CLElBQUksSUFBSSxDQUFDLGFBQWEsSUFBSSxLQUFLLEVBQUU7WUFDN0IsTUFBTSxHQUFHLGFBQWEsQ0FBQztTQUMxQjthQUFNO1lBQ0gsTUFBTSxHQUFHLElBQUksQ0FBQyxTQUFTLENBQUMsTUFBTSxDQUFDLFlBQVksQ0FBQyxDQUFDLFFBQVEsQ0FBQyxJQUFJLGFBQWEsQ0FBQztTQUMzRTtRQUNELE9BQU8sTUFBTSxDQUFDO0lBQ2xCLENBQUM7SUFFTSxpQkFBaUIsQ0FBQyxRQUFhLEVBQUUsWUFBcUI7UUFDekQsSUFBSSxRQUFRLEtBQUssT0FBTztZQUFFLE9BQU8sUUFBUSxDQUFDO1FBRTFDLElBQUksWUFBWSxJQUFJLFlBQVksS0FBSyxDQUFDLEVBQUU7WUFDcEMsT0FBTyxJQUFJLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxZQUFZLENBQUMsQ0FBQztTQUMzQzthQUFNO1lBQ0gsSUFBSSxDQUFDLGtCQUFrQixFQUFFLENBQUM7WUFDMUIsT0FBTyxJQUFJLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsa0JBQWtCLEdBQUcsQ0FBQyxDQUFDLENBQUM7U0FDMUQ7SUFDTCxDQUFDO0lBRU0sZUFBZSxDQUFDLEtBQVU7UUFDN0IsSUFBSSxDQUFDLGFBQWEsR0FBRyxLQUFLLENBQUM7SUFDL0IsQ0FBQzs7O1lBbjFCSixTQUFTLFNBQUM7Z0JBQ1AsUUFBUSxFQUFFLFdBQVc7Z0JBQ3JCLG9vVkFBdUM7Z0JBQ3ZDLGFBQWEsRUFBRSxpQkFBaUIsQ0FBQyxJQUFJO2dCQUNyQyxTQUFTLEVBQUUsQ0FBQyxXQUFXLEVBQUUsZUFBZSxFQUFFLGVBQWUsRUFBRSxZQUFZLEVBQUUsU0FBUyxDQUFDO2dCQUNuRixJQUFJLEVBQUU7b0JBQ0YsT0FBTyxFQUFFLFlBQVk7b0JBQ3JCLFdBQVcsRUFBRSxXQUFXO29CQUN4QixnQ0FBZ0MsRUFBRSx3QkFBd0I7b0JBQzFELG1DQUFtQyxFQUFFLGNBQWM7b0JBQ25ELG1DQUFtQyxFQUFFLGNBQWM7b0JBQ25ELG1DQUFtQyxFQUFFLHVCQUF1QjtvQkFDNUQsbUNBQW1DLEVBQUUsdUJBQXVCO29CQUM1RCw4QkFBOEIsRUFBRSwwQkFBMEI7b0JBQzFELDBCQUEwQixFQUFFLGdEQUFnRDtvQkFDNUUsc0JBQXNCLEVBQUUsNENBQTRDO29CQUNwRSxzQkFBc0IsRUFBRSw0Q0FBNEM7b0JBQ3BFLHVCQUF1QixFQUFFLDZDQUE2QztvQkFDdEUsc0JBQXNCLEVBQUUsNENBQTRDO29CQUNwRSxxQkFBcUIsRUFBRSwrQkFBK0I7b0JBQ3RELGlCQUFpQixFQUFFLHFDQUFxQztpQkFDM0Q7YUFDSjs7O1lBMUNRLFlBQVk7WUFIakIsVUFBVTtZQVFMLFdBQVc7WUFEWCxlQUFlO1lBQWdCLFNBQVM7Ozt3QkE0RjVDLEtBQUssU0FBQyxNQUFNOzBCQUNaLEtBQUssU0FBQyxRQUFRO3VCQUNkLEtBQUssU0FBQyxLQUFLO3lCQUNYLEtBQUs7OEJBQ0wsS0FBSzsrQkFDTCxNQUFNO3lCQUNOLE1BQU07eUJBQ04sTUFBTSIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7XHJcbiAgICBDb21wb25lbnQsXHJcbiAgICBWaWV3RW5jYXBzdWxhdGlvbixcclxuICAgIElucHV0LFxyXG4gICAgT3V0cHV0LFxyXG4gICAgRXZlbnRFbWl0dGVyLFxyXG4gICAgT25Jbml0LFxyXG4gICAgT25DaGFuZ2VzLFxyXG4gICAgU2ltcGxlQ2hhbmdlcyxcclxuICAgIEVsZW1lbnRSZWYsXHJcbiAgICBPbkRlc3Ryb3lcclxufSBmcm9tICdAYW5ndWxhci9jb3JlJztcclxuaW1wb3J0IHsgRG9tU2FuaXRpemVyIH0gZnJvbSAnQGFuZ3VsYXIvcGxhdGZvcm0tYnJvd3Nlcic7XHJcbmltcG9ydCB7IFN1YnNjcmlwdGlvbiwgIHRpbWVyIH0gZnJvbSAncnhqcyc7XHJcbmltcG9ydCB7IGRlYm91bmNlVGltZSB9IGZyb20gJ3J4anMvb3BlcmF0b3JzJztcclxuaW1wb3J0IHsgS2RTcGxpdHRlckV2ZW50IH0gZnJvbSAnLi4va2QtYW5ndWxhci1zcGxpdHRlci9pbmRleCc7XHJcbmltcG9ydCB7IEtkQ29udmVydGlvblN2YywgS2REb21FbGVtU3ZjLCBLZERhdGFTdmMgfSBmcm9tICcuLi9rZC1jb21tb24vaW5kZXgnO1xyXG5pbXBvcnQgeyBLZENoYXJ0c1N2YyB9IGZyb20gJy4va2QtYW5ndWxhci1jaGFydHMtc3ZjJztcclxuaW1wb3J0IHsgREVGQVVMVF9DT05GSUcgfSBmcm9tICcuL2tkLWFuZ3VsYXItY2hhcnRzLWNvbmZpZyc7XHJcbmltcG9ydCB7XHJcbiAgICBJQ2hhcnREYXRhLFxyXG4gICAgSUNoYXJ0Q29uZmlnLFxyXG4gICAgSVNlcmllc0RhdGEsXHJcbiAgICBJTGVnZW5kRGF0YSxcclxuICAgIElEM0RhdGEsXHJcbiAgICBJRDNZRGF0YSxcclxuICAgIElEM0RhdGFEYXRhLFxyXG4gICAgSUNoYXJ0QXBpLFxyXG4gICAgSUNoYXJ0SW50ZXJuYWxBcGksXHJcbiAgICBJRm9yTG9vcEluZm9cclxufSBmcm9tICcuL2tkLWFuZ3VsYXItY2hhcnRzLWludGVyZmFjZSc7XHJcblxyXG5AQ29tcG9uZW50KHtcclxuICAgIHNlbGVjdG9yOiAna2QtY2hhcnRzJyxcclxuICAgIHRlbXBsYXRlVXJsOiAnLi9rZC1hbmd1bGFyLWNoYXJ0cy5odG1sJyxcclxuICAgIGVuY2Fwc3VsYXRpb246IFZpZXdFbmNhcHN1bGF0aW9uLk5vbmUsXHJcbiAgICBwcm92aWRlcnM6IFtLZENoYXJ0c1N2YywgS2RTcGxpdHRlckV2ZW50LCBLZENvbnZlcnRpb25TdmMsIEtkRG9tRWxlbVN2YywgS2REYXRhU3ZjXSxcclxuICAgIGhvc3Q6IHtcclxuICAgICAgICAnY2xhc3MnOiAna2R4LWNoYXJ0cycsXHJcbiAgICAgICAgJ1thdHRyLmlkXSc6ICdjb25maWcuaWQnLFxyXG4gICAgICAgICdbY2xhc3Mua2R4LWNoYXJ0cy1heGlzLWludmVydF0nOiAnY2hhcnRUeXBlWzBdID09PSBcImJhclwiJyxcclxuICAgICAgICAnW2NsYXNzLmtkeC1jaGFydHMtcm90YXRlLXRpdGxlLXhdJzogJ3JvdGF0ZVRpdGxlWCcsXHJcbiAgICAgICAgJ1tjbGFzcy5rZHgtY2hhcnRzLXJvdGF0ZS10aXRsZS15XSc6ICdyb3RhdGVUaXRsZVknLFxyXG4gICAgICAgICdbY2xhc3Mua2R4LWNoYXJ0cy15QXhpcy1vcHBvc2l0ZV0nOiAnY29uZmlnLnlBeGlzLm9wcG9zaXRlJyxcclxuICAgICAgICAnW2NsYXNzLmtkeC1jaGFydHMteEF4aXMtb3Bwb3NpdGVdJzogJ2NvbmZpZy54QXhpcy5vcHBvc2l0ZScsXHJcbiAgICAgICAgJ1tjbGFzcy5rZHgtY2hhcnRzLW5vLWJvcmRlcl0nOiAnaGF2ZWtkQ2hhcnROb0JvcmRlckNsYXNzJyxcclxuICAgICAgICAnW3N0eWxlLmJhY2tncm91bmQtY29sb3JdJzogJ2NvbmZpZy5jaGFydC5tYWluQXJlYS5zdHlsZVtcImJhY2tncm91bmRDb2xvclwiXScsXHJcbiAgICAgICAgJ1tzdHlsZS5ib3JkZXItY29sb3JdJzogJ2NvbmZpZy5jaGFydC5tYWluQXJlYS5zdHlsZVtcImJvcmRlckNvbG9yXCJdJyxcclxuICAgICAgICAnW3N0eWxlLmJvcmRlci13aWR0aF0nOiAnY29uZmlnLmNoYXJ0Lm1haW5BcmVhLnN0eWxlW1wiYm9yZGVyV2lkdGhcIl0nLFxyXG4gICAgICAgICdbc3R5bGUuYm9yZGVyLXJhZGl1c10nOiAnY29uZmlnLmNoYXJ0Lm1haW5BcmVhLnN0eWxlW1wiYm9yZGVyUmFkaXVzXCJdJyxcclxuICAgICAgICAnW3N0eWxlLmJvcmRlci1zdHlsZV0nOiAnY29uZmlnLmNoYXJ0Lm1haW5BcmVhLnN0eWxlW1wiYm9yZGVyU3R5bGVcIl0nLFxyXG4gICAgICAgICdbc3R5bGUuZm9udC1mYW1pbHldJzogJ2NvbmZpZy5jaGFydC5zdHlsZS5mb250RmFtaWx5JyxcclxuICAgICAgICAnW3N0eWxlLm9wYWNpdHldJzogJ2NvbmZpZy5jaGFydC5tYWluQXJlYS5zdHlsZS5vcGFjaXR5JyxcclxuICAgIH1cclxufSlcclxuXHJcbmV4cG9ydCBjbGFzcyBLZENoYXJ0cyBpbXBsZW1lbnRzIE9uSW5pdCwgT25DaGFuZ2VzLCBPbkRlc3Ryb3kge1xyXG4gICAgcHVibGljIGlzTGF5ZXJMb2FkaW5nOiBib29sZWFuID0gdHJ1ZTtcclxuICAgIHB1YmxpYyBzbWFsbExvYWRlclZhbHVlOiBhbnkgPSBudWxsO1xyXG4gICAgcHVibGljIHBpZURhdGE6IEFycmF5PGFueT4gPSBbXTtcclxuICAgIHB1YmxpYyBwaWVDb2xvcjogQXJyYXk8YW55PiA9IFtdO1xyXG4gICAgcHVibGljIGJhY2tncm91bmRDb2xvcjogc3RyaW5nID0gJyNGRkZGRkYnO1xyXG4gICAgcHVibGljIGNvbmZpZzogSUNoYXJ0Q29uZmlnO1xyXG4gICAgcHVibGljIGRhdGE6IElEM0RhdGE7XHJcbiAgICBwdWJsaWMgbGVnZW5kTGlzdDogQXJyYXk8c3RyaW5nPjtcclxuICAgIHB1YmxpYyBjaGVja01hcFNjYWxlOiBib29sZWFuID0gZmFsc2U7XHJcbiAgICBwdWJsaWMgY2hhcnRDYXRlZ29yeTogJ3BpZScgfCAnYmFyJyB8ICdjb2x1bW4nIHwgJ2xpbmUnIHwgJ2FyZWEnIHwgJ2RvdCcgfCAnc3BsaW5lJyB8ICdtYXAnO1xyXG4gICAgcHVibGljIGlzQXhpc0NoYXJ0OiBib29sZWFuID0gZmFsc2U7XHJcbiAgICBwdWJsaWMgaXNOZWdhdGl2ZVN0YWNrOiBib29sZWFuID0gZmFsc2U7XHJcbiAgICBwdWJsaWMgY2hhcnRUeXBlOiBBcnJheTxzdHJpbmc+ID0gWycnXTtcclxuICAgIHB1YmxpYyByb3RhdGVUaXRsZVg6IGJvb2xlYW4gPSBmYWxzZTtcclxuICAgIHB1YmxpYyByb3RhdGVUaXRsZVk6IGJvb2xlYW4gPSBmYWxzZTtcclxuICAgIHB1YmxpYyBjaGFydEhpZGU6IGJvb2xlYW4gPSBmYWxzZTtcclxuICAgIHB1YmxpYyBoYXZlQXhpc1BhZGRpbmc6IGJvb2xlYW4gPSBmYWxzZTtcclxuICAgIHB1YmxpYyBoYXZlQXhpc1NwZWNpYWxQYWRkaW5nOiBib29sZWFuID0gZmFsc2U7XHJcbiAgICBwdWJsaWMgeEF4aXNPcHBvc2l0ZTogYm9vbGVhbiA9IGZhbHNlO1xyXG4gICAgcHVibGljIGhhdmVrZENoYXJ0Tm9Cb3JkZXJDbGFzczogYm9vbGVhbiA9IGZhbHNlO1xyXG5cclxuICAgIHB1YmxpYyBodG1sQ2xhc3NPYmo6IGFueSA9IHtcclxuICAgICAgICAnY2hhcnRzV3JhcHBlcic6ICcnLFxyXG4gICAgICAgICdsZWdlbmRDb250YWluZXInOiAnJ1xyXG4gICAgfTtcclxuXHJcbiAgICBwdWJsaWMgYXBpOiBJQ2hhcnRJbnRlcm5hbEFwaSA9IHt9O1xyXG5cclxuICAgIHB1YmxpYyBpY29uczogb2JqZWN0ID0ge307XHJcblxyXG4gICAgcHVibGljIGxlZ2VuZERhdGE6IHsgW2tleTogc3RyaW5nXTogSUxlZ2VuZERhdGEgfTtcclxuICAgIHB1YmxpYyBtYXJrZXJzTGVnZW5kOiBBcnJheTxhbnk+ID0gW107XHJcblxyXG4gICAgcHJpdmF0ZSBzaGFwZXM6IG9iamVjdCA9IHtcclxuICAgICAgICB0cmlhbmdsZTogJ00gNCAwIEwgNCAwIEwgMCA4IEwgOCA4IHonLFxyXG4gICAgICAgIHRyaWFuZ2xlUjogJ00gMCAwIEwgOCAwIEwgNCA4IEwgNCA4IHonLFxyXG4gICAgICAgIGRpYW1vbmQ6ICdNIDQgMCBMIDggNCBMIDQgOCBMIDAgNCB6JyxcclxuICAgICAgICBjaXJjbGU6ICdNIDQgMCBBIDQgNCAwIDEgMCA0IDggQSA0IDQgMCAxIDAgNCAwIFonLFxyXG4gICAgICAgIHNxdWFyZTogJ00gMCAwIEwgOCAwIEwgOCA4IEwgMCA4IHonXHJcbiAgICB9O1xyXG5cclxuICAgIHByaXZhdGUgbGVnZW5kSW5hY3RpdmU6IEFycmF5PHN0cmluZz4gPSBbXTtcclxuICAgIHByaXZhdGUgX2NvbG9yTGlzdFBvc2l0aW9uOiBudW1iZXIgPSAwO1xyXG5cclxuICAgIHByaXZhdGUgX3Jlc2l6ZVRpbWVvdXQ6IGFueTtcclxuXHJcbiAgICAvLyBwcml2YXRlIF9zcGxpdHRlclN1YnNjcmlwdGlvbkFycjogU3Vic2NyaXB0aW9uW10gPSBbXTtcclxuXHJcbiAgICBwcml2YXRlIF9yZXNpemVMaXN0ZW5lcjogYW55O1xyXG4gICAgcHJpdmF0ZSBfcGllRG9uZUZsYWc6IGJvb2xlYW4gPSBmYWxzZTtcclxuXHJcbiAgICBASW5wdXQoJ2RhdGEnKSBjaGFydERhdGE6IElDaGFydERhdGE7XHJcbiAgICBASW5wdXQoJ2NvbmZpZycpIGNoYXJ0Q29uZmlnOiBJQ2hhcnRDb25maWc7XHJcbiAgICBASW5wdXQoJ2FwaScpIGNoYXJ0QXBpOiBJQ2hhcnRBcGk7XHJcbiAgICBASW5wdXQoKSB4VGhyZXNob2xkOiBudW1iZXI7XHJcbiAgICBASW5wdXQoKSBzZXJpZXNUaHJlc2hvbGQ6IG51bWJlciA9IDEwMDA7XHJcbiAgICBAT3V0cHV0KCkgb3V0cHV0TGVnZW5kRGF0YTogRXZlbnRFbWl0dGVyPHsgW2tleTogc3RyaW5nXTogSUxlZ2VuZERhdGEgfT4gPSBuZXcgRXZlbnRFbWl0dGVyKCk7XHJcbiAgICBAT3V0cHV0KCkgb3V0cHV0RGF0YTogRXZlbnRFbWl0dGVyPElEM0RhdGE+ID0gbmV3IEV2ZW50RW1pdHRlcigpO1xyXG4gICAgQE91dHB1dCgpIG91dHB1dEFyZWE6IEV2ZW50RW1pdHRlcjxJRDNEYXRhPiA9IG5ldyBFdmVudEVtaXR0ZXIoKTtcclxuXHJcbiAgICBjb25zdHJ1Y3RvcihcclxuICAgICAgICBwcml2YXRlIF9zYW5pdGl6ZXI6IERvbVNhbml0aXplcixcclxuICAgICAgICBwcml2YXRlIF9lbGVtZW50UmVmOiBFbGVtZW50UmVmLFxyXG4gICAgICAgIHByaXZhdGUgX2NoYXJ0U3ZjOiBLZENoYXJ0c1N2YyxcclxuICAgICAgICAvLyBwdWJsaWMgX2tkU3BsaXR0ZXJFdmVudDogS2RTcGxpdHRlckV2ZW50LFxyXG4gICAgICAgIHB1YmxpYyBfY29udmVydGlvblN2YzogS2RDb252ZXJ0aW9uU3ZjLFxyXG4gICAgICAgIHB1YmxpYyBfZGF0YVN2YzogS2REYXRhU3ZjXHJcbiAgICApIHtcclxuICAgICAgICAvLyB0aGlzLl9zcGxpdHRlclN1YnNjcmlwdGlvbkFyciA9IHRoaXMuX2luaXRTcGxpdHRlclN1YnNjcmlwdGlvbnMoX2tkU3BsaXR0ZXJFdmVudCk7XHJcbiAgICB9XHJcblxyXG4gICAgbmdPbkluaXQoKTogdm9pZCB7XHJcbiAgICAgICAgLy8gY29uc29sZS5sb2coJ2tkLWNoYXJ0IGluaXQnKTtcclxuICAgICAgICB0aGlzLl9zZXRDb25maWcodGhpcy5jaGFydENvbmZpZywgdHJ1ZSk7XHJcbiAgICAgICAgaWYgKCF0aGlzLmNoYXJ0RGF0YSB8fCAhdGhpcy5jaGFydENvbmZpZykgcmV0dXJuO1xyXG4gICAgICAgIHRoaXMuX3NldERhdGEodGhpcy5jaGFydERhdGEpO1xyXG4gICAgICAgIHRoaXMuaW5pdEFwaSgpO1xyXG4gICAgICAgIC8vIHRoaXMuX3Jlc2l6ZUxpc3RlbmVyID0gKCkgPT4gdGhpcy5fb25SZXNpemUoKTtcclxuICAgICAgICAvLyB0aGlzLl9pbml0TGlzdGVuZXIoKTtcclxuICAgICAgICAvLyBjb25zb2xlLmxvZygna2QtY2hhcnQgZGF0YSAnLCB0aGlzLmNoYXJ0RGF0YSk7XHJcbiAgICAgICAgLy8gY29uc29sZS5sb2coJ2tkLWNoYXJ0IGNvbmZpZyAnLCB0aGlzLmNoYXJ0Q29uZmlnKTtcclxuICAgIH1cclxuXHJcbiAgICBuZ09uQ2hhbmdlcyhfc2ltcGxlQ2hhbmdlczogU2ltcGxlQ2hhbmdlcyk6IHZvaWQge1xyXG4gICAgICAgIGlmIChfc2ltcGxlQ2hhbmdlcy5oYXNPd25Qcm9wZXJ0eSgnY2hhcnRDb25maWcnKSAmJiAhX3NpbXBsZUNoYW5nZXNbJ2NoYXJ0Q29uZmlnJ10uZmlyc3RDaGFuZ2UpIHtcclxuICAgICAgICAgICAgaWYgKF9zaW1wbGVDaGFuZ2VzWydjaGFydENvbmZpZyddLmN1cnJlbnRWYWx1ZSA9PT0gdGhpcy5jb25maWcpIHJldHVybjtcclxuICAgICAgICAgICAgdGhpcy5fc2V0Q29uZmlnKF9zaW1wbGVDaGFuZ2VzLmNoYXJ0Q29uZmlnLmN1cnJlbnRWYWx1ZSk7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGlmIChfc2ltcGxlQ2hhbmdlcy5oYXNPd25Qcm9wZXJ0eSgnY2hhcnREYXRhJykgJiYgIV9zaW1wbGVDaGFuZ2VzWydjaGFydERhdGEnXS5maXJzdENoYW5nZSkge1xyXG4gICAgICAgICAgICBpZiAoX3NpbXBsZUNoYW5nZXNbJ2NoYXJ0RGF0YSddLmN1cnJlbnRWYWx1ZSA9PT0gdGhpcy5kYXRhKSByZXR1cm47XHJcbiAgICAgICAgICAgIHRoaXMuX3NldERhdGEoT2JqZWN0LmFzc2lnbih7fSwgX3NpbXBsZUNoYW5nZXMuY2hhcnREYXRhLmN1cnJlbnRWYWx1ZSkpO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICBuZ09uRGVzdHJveSgpOiB2b2lkIHtcclxuICAgICAgICBpZiAoIXRoaXMuY2hhcnREYXRhIHx8ICF0aGlzLmNoYXJ0Q29uZmlnKSByZXR1cm47XHJcbiAgICAgICAgLy8gdGhpcy5fdW5zdWJzY3JpYmUodGhpcy5fc3BsaXR0ZXJTdWJzY3JpcHRpb25BcnIpO1xyXG4gICAgICAgIC8vIHRoaXMuX3JlbW92ZUxpc3RlbmVyKCk7XHJcbiAgICB9XHJcblxyXG4gICAgLyoqXHJcbiAgICAgKiBGb3IgRVhQT1JULiBleHBvcnQgc2tpcHMgZGF0YSBtYXNzYWdlIGFuZCBnZW5lcmF0ZUxlZ2VuZERhdGEsIGhlbmNlIG5lZWQgdG8gc2V0TGVnZW5kRGF0YSBzZXBhcmF0ZWx5XHJcbiAgICAgKiAoYWNjdXJhdGUgYXMgb2YgdjMuNy4wKSBhcyBsZWdlbmREYXRhIGlzIGZvciBpbnRlcm5hbCB1c2UsIHdlIGRvIG5vdCBwdXQgaW4gSW5wdXQuIHRoaXMgZnVuY3Rpb24gaXMgYWNjZXNzZWQgdmlhIFZpZXdDaGlsZCBmcm9tIEtkVmlzdWFsaXphdGlvblxyXG4gICAgICogcGFyYW0ge0lMZWdlbmREYXRhIH19IF9sZWdlbmREYXRhXHJcbiAgICAgKi9cclxuICAgIHB1YmxpYyBzZXRMZWdlbmREYXRhKF9sZWdlbmREYXRhOiB7IFtrZXk6IHN0cmluZ106IElMZWdlbmREYXRhIH0pIHtcclxuICAgICAgICB0aGlzLmxlZ2VuZERhdGEgPSBPYmplY3QuYXNzaWduKHt9LCBfbGVnZW5kRGF0YSk7XHJcbiAgICB9XHJcblxyXG4gICAgLyoqXHJcbiAgICAgKiBpbml0aWF0ZSBhcGkgZnJvbSBvdXRzaWRlIGtkIGNoYXJ0cyBjb21wb25lbnRcclxuICAgICAqL1xyXG4gICAgcHJpdmF0ZSBpbml0QXBpKCk6IHZvaWQge1xyXG4gICAgICAgIGlmICh0eXBlb2YgdGhpcy5jaGFydEFwaSA9PT0gJ3VuZGVmaW5lZCcpIHJldHVybjtcclxuXHJcbiAgICAgICAgdGhpcy5jaGFydEFwaS5jaGFuZ2VTZXJpZXNDb2xvciA9IChsZWdlbmRJZDogc3RyaW5nLCBjb2xvcjogc3RyaW5nLCBpbmRleD86IG51bWJlcikgPT4ge1xyXG4gICAgICAgICAgICBpZiAodHlwZW9mIGluZGV4ID09PSAnbnVtYmVyJykgdGhpcy5fc2V0RGF0YUNvbG9yU2hhcGUoaW5kZXgsIGNvbG9yKTtcclxuICAgICAgICAgICAgdGhpcy5sZWdlbmREYXRhW2xlZ2VuZElkXS5jb2xvciA9IGNvbG9yO1xyXG4gICAgICAgICAgICB0aGlzLl91cGRhdGVMZWdlbmRJY29uV2l0aEluZGV4KGxlZ2VuZElkLCBpbmRleCk7XHJcbiAgICAgICAgICAgIHRoaXMuYXBpLnJlZHJhdygpO1xyXG4gICAgICAgIH07XHJcblxyXG4gICAgICAgIHRoaXMuY2hhcnRBcGkucmVkcmF3ID0gKCkgPT4gdGhpcy5hcGkucmVkcmF3KCk7XHJcblxyXG4gICAgICAgIC8vIHRoaXMuY2hhcnRBcGkuZW5hYmxlTGlzdGVuZXIgPSAoX2hhdmVMaXN0ZW5lcjogYm9vbGVhbikgPT4ge1xyXG4gICAgICAgIC8vICAgICBpZiAoX2hhdmVMaXN0ZW5lcikge1xyXG4gICAgICAgIC8vICAgICAgICAgdGhpcy5faW5pdExpc3RlbmVyKCk7XHJcbiAgICAgICAgLy8gICAgICAgICBpZiAodGhpcy5fc3BsaXR0ZXJTdWJzY3JpcHRpb25BcnIubGVuZ3RoID09PSAwKSB7XHJcbiAgICAgICAgLy8gICAgICAgICAgICAgdGhpcy5fc3BsaXR0ZXJTdWJzY3JpcHRpb25BcnIgPSB0aGlzLl9pbml0U3BsaXR0ZXJTdWJzY3JpcHRpb25zKHRoaXMuX2tkU3BsaXR0ZXJFdmVudCk7XHJcbiAgICAgICAgLy8gICAgICAgICB9XHJcbiAgICAgICAgLy8gICAgIH0gZWxzZSB7XHJcbiAgICAgICAgLy8gICAgICAgICB0aGlzLl9yZW1vdmVMaXN0ZW5lcigpO1xyXG4gICAgICAgIC8vICAgICAgICAgdGhpcy5fdW5zdWJzY3JpYmUodGhpcy5fc3BsaXR0ZXJTdWJzY3JpcHRpb25BcnIpO1xyXG4gICAgICAgIC8vICAgICAgICAgdGhpcy5fc3BsaXR0ZXJTdWJzY3JpcHRpb25BcnIgPSBbXTtcclxuICAgICAgICAvLyAgICAgfVxyXG4gICAgICAgIC8vIH07XHJcbiAgICB9XHJcblxyXG4gICAgLy8gPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09IExpc3RlbmVyID09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT1cclxuXHJcbiAgICAvLyBwcml2YXRlIF9pbml0TGlzdGVuZXIoKSB7XHJcbiAgICAvLyAgICAgd2luZG93LmFkZEV2ZW50TGlzdGVuZXIoJ3Jlc2l6ZScsIHRoaXMuX3Jlc2l6ZUxpc3RlbmVyKTtcclxuICAgIC8vIH1cclxuXHJcbiAgICAvLyBwcml2YXRlIF9yZW1vdmVMaXN0ZW5lcigpIHtcclxuICAgIC8vICAgICB3aW5kb3cucmVtb3ZlRXZlbnRMaXN0ZW5lcigncmVzaXplJywgdGhpcy5fcmVzaXplTGlzdGVuZXIpO1xyXG4gICAgLy8gfVxyXG5cclxuICAgIC8vIHByaXZhdGUgX29uUmVzaXplKCk6IHZvaWQge1xyXG4gICAgLy8gICAgIGNsZWFyVGltZW91dCh0aGlzLl9yZXNpemVUaW1lb3V0KTtcclxuICAgIC8vICAgICB0aGlzLl9yZXNpemVUaW1lb3V0ID0gc2V0VGltZW91dCgoKSA9PiB7XHJcbiAgICAvLyAgICAgICAgIHRoaXMuYXBpLnJlZHJhdygpO1xyXG4gICAgLy8gICAgIH0sIDUwMCk7XHJcbiAgICAvLyB9XHJcblxyXG4gICAgLy8gPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09IFNwbGl0dGVyIFN1YnNjcmlwdGlvbiA9PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09XHJcblxyXG4gICAgLy8gcHJpdmF0ZSBfaW5pdFNwbGl0dGVyU3Vic2NyaXB0aW9ucyhfc3BsaXR0ZXJFdmVudCk6IFN1YnNjcmlwdGlvbltdIHtcclxuICAgIC8vICAgICBpZiAoIV9zcGxpdHRlckV2ZW50KSByZXR1cm47XHJcblxyXG4gICAgLy8gICAgIGxldCBzdWJzY3JpcHRpb25BcnI6IFN1YnNjcmlwdGlvbltdID0gW107XHJcblxyXG4gICAgLy8gICAgIGxldCB0b2dnbGVNZW51U3ViID0gX3NwbGl0dGVyRXZlbnQub25Ub2dnbGVNZW51KCkuc3Vic2NyaWJlKCgpOiB2b2lkID0+IHtcclxuICAgIC8vICAgICAgICAgdGltZXIoNTAwKS5zdWJzY3JpYmUoKCk6IHZvaWQgPT4ge1xyXG4gICAgLy8gICAgICAgICAgICAgdGhpcy5hcGkucmVkcmF3KCk7XHJcbiAgICAvLyAgICAgICAgIH0pO1xyXG4gICAgLy8gICAgIH0pO1xyXG4gICAgLy8gICAgIGxldCB0b2dnbGVTdWJQYW5lID0gX3NwbGl0dGVyRXZlbnQub25Ub2dnbGVTdWJQYW5lKCkuc3Vic2NyaWJlKCgpOiB2b2lkID0+IHtcclxuICAgIC8vICAgICAgICAgdGltZXIoNTAwKS5zdWJzY3JpYmUoKCk6IHZvaWQgPT4ge1xyXG4gICAgLy8gICAgICAgICAgICAgdGhpcy5hcGkucmVkcmF3KCk7XHJcbiAgICAvLyAgICAgICAgIH0pO1xyXG4gICAgLy8gICAgIH0pO1xyXG4gICAgLy8gICAgIGxldCBkcmFnTWVudVN1YiA9IF9zcGxpdHRlckV2ZW50Lm9uRHJhZygpXHJcbiAgICAvLyAgICAgICAgIC5waXBlKFxyXG4gICAgLy8gICAgICAgICAgICAgZGVib3VuY2VUaW1lKDEwMClcclxuICAgIC8vICAgICAgICAgKVxyXG4gICAgLy8gICAgICAgICAuc3Vic2NyaWJlKCgpOiB2b2lkID0+IHtcclxuICAgIC8vICAgICAgICAgICAgIHRoaXMuYXBpLnJlZHJhdygpO1xyXG4gICAgLy8gICAgICAgICB9KTtcclxuXHJcbiAgICAvLyAgICAgc3Vic2NyaXB0aW9uQXJyLnB1c2godG9nZ2xlTWVudVN1Yik7XHJcbiAgICAvLyAgICAgc3Vic2NyaXB0aW9uQXJyLnB1c2godG9nZ2xlU3ViUGFuZSk7XHJcbiAgICAvLyAgICAgc3Vic2NyaXB0aW9uQXJyLnB1c2goZHJhZ01lbnVTdWIpO1xyXG5cclxuICAgIC8vICAgICByZXR1cm4gc3Vic2NyaXB0aW9uQXJyO1xyXG4gICAgLy8gfVxyXG5cclxuICAgIC8vIHByaXZhdGUgX3Vuc3Vic2NyaWJlKF9zdWJzY3JpcHRpb25BcnI6IFN1YnNjcmlwdGlvbltdID0gW10pOiB2b2lkIHtcclxuICAgIC8vICAgICBpZiAoX3N1YnNjcmlwdGlvbkFyci5sZW5ndGggPT09IDApIHJldHVybjtcclxuICAgIC8vICAgICBfc3Vic2NyaXB0aW9uQXJyLmZvckVhY2goc3Vic2NyaXB0aW9uID0+IHtcclxuICAgIC8vICAgICAgICAgaWYgKHN1YnNjcmlwdGlvbikgc3Vic2NyaXB0aW9uLnVuc3Vic2NyaWJlKCk7XHJcbiAgICAvLyAgICAgfSk7XHJcbiAgICAvLyB9XHJcblxyXG4gICAgLy8gPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09IENvbmZpZyBhbmQgRGF0YSA9PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09XHJcblxyXG4gICAgcHJpdmF0ZSBfc2V0Q29uZmlnKF9jb25maWc6IElDaGFydENvbmZpZywgX2lzRmlyc3RDaGFuZ2U/OiBib29sZWFuKTogdm9pZCB7XHJcbiAgICAgICAgLy8gc3RvcmluZyBjb25maWcgaW4gdGhpcyBjb21wb25lbnRcclxuICAgICAgICB0aGlzLmNvbmZpZyA9IEpTT04ucGFyc2UoSlNPTi5zdHJpbmdpZnkoREVGQVVMVF9DT05GSUcpKTtcclxuICAgICAgICB0aGlzLl9kYXRhU3ZjLmRlZXBDb21iaW5lT2JqZWN0KHRoaXMuY29uZmlnLCBfY29uZmlnIHx8IHt9KTtcclxuXHJcbiAgICAgICAgLy8gc2V0IGNvbmZpZyBpcyBjYWxsZWQgdHdpY2UsIHRvIGltcHJvdmUgcGVyZm9ybWFuY2UsIG9ubHkgY2FsbCB0aGUgZm9sbG93aW5nIG9uY2UgKGFmdGVyIGRhdGEgbWFzc2FnZSlcclxuICAgICAgICBpZiAoX2lzRmlyc3RDaGFuZ2UpIHJldHVybjtcclxuXHJcbiAgICAgICAgdGhpcy5zZXRDaGFydFN0eWxlKF9jb25maWcpO1xyXG4gICAgICAgIFxyXG4gICAgICAgIHRoaXMuY2hlY2tNYXBTY2FsZSA9IGZhbHNlO1xyXG5cclxuICAgICAgICB0aGlzLl9zZXRDbGFzc05hbWVzKCk7XHJcblxyXG4gICAgICAgIHRoaXMuX3BvcHVsYXRlTGVnZW5kSWNvbigpO1xyXG5cclxuICAgICAgICB0aGlzLl9zZXRMYWJlbFN0eWxlKCk7XHJcblxyXG5cclxuICAgICAgICAvLyBzdG9yaW5nIGNvbmZpZyBpbnRvIGNoYXJ0IHNlcnZpY2VcclxuICAgICAgICB0aGlzLl9jaGFydFN2Yy5jb25maWcgPSBfY29uZmlnO1xyXG4gICAgfVxyXG5cclxuICAgIHB1YmxpYyBzZXRDaGFydFN0eWxlKF9jb25maWc6IElDaGFydENvbmZpZyk6IHZvaWQge1xyXG4gICAgICAgIHRoaXMuaGF2ZWtkQ2hhcnROb0JvcmRlckNsYXNzID0gIV9jb25maWcuY2hhcnQubWFpbkFyZWEuc3R5bGVbXCJib3JkZXJXaWR0aFwiXTtcclxuICAgICAgICBpZiAoX2NvbmZpZy5jaGFydC5tYWluQXJlYS5zdHlsZVtcImJvcmRlcldpZHRoXCJdICYmIF9jb25maWcuY2hhcnQubWFpbkFyZWEuc3R5bGVbXCJib3JkZXJXaWR0aFwiXSA9PT0gJzBweCcpIHtcclxuICAgICAgICAgICAgdGhpcy5oYXZla2RDaGFydE5vQm9yZGVyQ2xhc3MgPSB0cnVlO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICAvKiBUbyBiZSByZXZpc2l0LiBIb3QgZml4IGZvciBkb3duZ3JhZGUgY29tcG9uZW50IGFzIG5nY2xhc3MgdmFsdWUgZG9lc24ndCBjaGFuZ2UuKi9cclxuICAgIHByaXZhdGUgX3NldENsYXNzTmFtZXMoKSB7XHJcblxyXG4gICAgICAgIC8vIGh0bWxDbGFzc09iaiBpcyBhIHdvcmthcm91bmQgZm9yIGRvd25ncmFkZSBtZXRob2RcclxuICAgICAgICB0aGlzLmh0bWxDbGFzc09ialsnY2hhcnRzV3JhcHBlciddID0gJyc7XHJcbiAgICAgICAgdGhpcy5odG1sQ2xhc3NPYmpbJ2xlZ2VuZENvbnRhaW5lciddID0gJyc7XHJcbiAgICAgICAgXHJcbiAgICAgICAgaWYgKHR5cGVvZiB0aGlzLmNvbmZpZy5sZWdlbmQuZmxvYXQgIT09IHVuZGVmaW5lZCAmJiB0aGlzLmNvbmZpZy5sZWdlbmQuZmxvYXQpIHtcclxuICAgICAgICAgICAgdGhpcy5odG1sQ2xhc3NPYmouY2hhcnRzV3JhcHBlciArPSAnbGVnZW5kLWZsb2F0ICc7XHJcbiAgICAgICAgICAgIHRoaXMuaHRtbENsYXNzT2JqLmxlZ2VuZENvbnRhaW5lciArPSAnbGVnZW5kLWZsb2F0ICc7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICBpZiAodHlwZW9mIHRoaXMuY29uZmlnLmxlZ2VuZC52ZXJ0aWNhbEFsaWduICE9PSB1bmRlZmluZWQpIHtcclxuICAgICAgICAgICAgdGhpcy5odG1sQ2xhc3NPYmouY2hhcnRzV3JhcHBlciArPSB0aGlzLmNvbmZpZy5sZWdlbmQudmVydGljYWxBbGlnbiArICcgJztcclxuICAgICAgICAgICAgdGhpcy5odG1sQ2xhc3NPYmoubGVnZW5kQ29udGFpbmVyICs9IHRoaXMuY29uZmlnLmxlZ2VuZC52ZXJ0aWNhbEFsaWduICsgJyAnO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgaWYgKHR5cGVvZiB0aGlzLmNvbmZpZy5sZWdlbmQuYWxpZ24gIT09IHVuZGVmaW5lZCkge1xyXG4gICAgICAgICAgICB0aGlzLmh0bWxDbGFzc09iai5jaGFydHNXcmFwcGVyICs9IHRoaXMuY29uZmlnLmxlZ2VuZC5hbGlnbiArICcgJztcclxuICAgICAgICAgICAgdGhpcy5odG1sQ2xhc3NPYmoubGVnZW5kQ29udGFpbmVyICs9IHRoaXMuY29uZmlnLmxlZ2VuZC5hbGlnbiArICcgJztcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIGlmICh0aGlzLmNoYXJ0Q2F0ZWdvcnkgPT09ICdwaWUnIHx8IHRoaXMuY2hhcnRDYXRlZ29yeSA9PT0gJ21hcCcpIHJldHVybjtcclxuICAgICAgICB0aGlzLnhBeGlzT3Bwb3NpdGUgPSB0aGlzLmNvbmZpZy54QXhpcy5vcHBvc2l0ZTtcclxuXHJcbiAgICAgICAgLy8gc2V0dGluZyBjbGFzcyBuYW1lIGZvciB2ZXJ0aWNhbCBheGlzIHRpdGxlIHRvIHJvdGF0ZVxyXG4gICAgICAgIHRoaXMucm90YXRlVGl0bGVYID0gdGhpcy5jaGFydFR5cGVbMF0gPT09ICdiYXInICYmIHRoaXMuX2NoYXJ0U3ZjLmNoZWNrUm90YXRlVGl0bGVFbmFibGVkKHRoaXMuY2hhcnRUeXBlLCB0aGlzLmNvbmZpZyk7XHJcbiAgICAgICAgdGhpcy5yb3RhdGVUaXRsZVkgPSB0aGlzLmNoYXJ0VHlwZVswXSAhPT0gJ2JhcicgJiYgdGhpcy5fY2hhcnRTdmMuY2hlY2tSb3RhdGVUaXRsZUVuYWJsZWQodGhpcy5jaGFydFR5cGUsIHRoaXMuY29uZmlnKTtcclxuXHJcbiAgICAgICAgLy8gdGhpcyBmbGFnIGlzIGZvciBhbGwgYXhpc0NoYXJ0cyBleGNlcHQgZm9yIGJhci4gQmFyIGRvIG5vdCBuZWVkIHBhZGRpblxyXG4gICAgICAgIHRoaXMuaGF2ZUF4aXNQYWRkaW5nID0gdGhpcy5jaGFydFR5cGVbMF0gIT09ICdiYXInO1xyXG4gICAgICAgIHRoaXMuaGF2ZUF4aXNTcGVjaWFsUGFkZGluZyA9IHRoaXMuY2hhcnRUeXBlW3RoaXMuY2hhcnRUeXBlLmxlbmd0aCAtIDFdID09PSAndHlwZTInO1xyXG4gICAgICAgIHRoaXMuaXNOZWdhdGl2ZVN0YWNrID0gKHRoaXMuY2hhcnRDYXRlZ29yeSA9PT0gJ2JhcicgfHwgdGhpcy5jaGFydENhdGVnb3J5ID09PSAnY29sdW1uJyApICYmIHRoaXMuY2hhcnRUeXBlWzFdID09PSAnc3RhY2snICYmIHRoaXMuY2hhcnRUeXBlWzJdID09PSAnbmVnYXRpdmUnO1xyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX3VwZGF0ZUxlZ2VuZEljb25XaXRoSW5kZXgoX2xlZ2VuZElkLCBfaW5kZXg/OiBudW1iZXIpIHtcclxuICAgICAgICBsZXQgbGVnZW5kSWQ6IHN0cmluZyA9IF9sZWdlbmRJZCwgbGVnZW5kQ29uZmlnOiBJTGVnZW5kRGF0YTtcclxuICAgICAgICAvLyBpZiBsZWdlbmRJZCBpcyBnaXZlbiwgd2Ugc2hvdWxkIGZvbGxvdyBsZWdlbmRJZFxyXG4gICAgICAgIGlmICghbGVnZW5kSWQpIHtcclxuICAgICAgICAgICAgLy8gaWYgbm8gbGVnZW5kSWQsIGZvbGxvdyBfaW5kZXhcclxuICAgICAgICAgICAgaWYgKF9pbmRleCA9PT0gbnVsbCB8fCBfaW5kZXggPT09IHVuZGVmaW5lZCkgcmV0dXJuO1xyXG4gICAgICAgICAgICBsZWdlbmRJZCA9IHRoaXMubGVnZW5kTGlzdFtfaW5kZXhdO1xyXG4gICAgICAgIH1cclxuICAgICAgICBsZWdlbmRDb25maWcgPSB0aGlzLmxlZ2VuZERhdGFbbGVnZW5kSWRdO1xyXG4gICAgICAgIHRoaXMuX3VwZGF0ZUxlZ2VuZEljb24obGVnZW5kSWQsIGxlZ2VuZENvbmZpZyk7XHJcbiAgICB9XHJcblxyXG5cclxuICAgIHByaXZhdGUgX3BvcHVsYXRlTGVnZW5kSWNvbihpbmRleD86IG51bWJlcik6IHZvaWQge1xyXG4gICAgICAgIGlmICghdGhpcy5sZWdlbmREYXRhKSByZXR1cm47XHJcblxyXG4gICAgICAgIHRoaXMubGVnZW5kTGlzdCA9IE9iamVjdC5rZXlzKHRoaXMubGVnZW5kRGF0YSk7XHJcblxyXG4gICAgICAgIGZvciAobGV0IGk6IG51bWJlciA9IDA7IGkgPCB0aGlzLmxlZ2VuZExpc3QubGVuZ3RoOyBpKyspIHtcclxuICAgICAgICAgICAgbGV0IGxlZ2VuZElkOiBzdHJpbmcgPSB0aGlzLmxlZ2VuZExpc3RbaV07XHJcbiAgICAgICAgICAgIGxldCBsZWdlbmRDb25maWc6IElMZWdlbmREYXRhID0gdGhpcy5sZWdlbmREYXRhW2xlZ2VuZElkXTtcclxuXHJcbiAgICAgICAgICAgIC8vIGxldCBlYWNoU3ZnID0gdGhpcy5yZW5kZXJlci5jcmVhdGVFbGVtZW50KCdzdmcnKTtcclxuICAgICAgICAgICAgLy8gdGhpcy5yZW5kZXJlci5zZXRBdHRyaWJ1dGUoZWFjaFN2ZywgJ2ZpbGwnLCB0aGlzLmNvbmZpZy5sZWdlbmREYXRhW2xlZ2VuZElkXS5jb2xvcik7XHJcbiAgICAgICAgICAgIC8vIHRoaXMucmVuZGVyZXIuc2V0QXR0cmlidXRlKGVhY2hTdmcsICd3aWR0aCcsIDgpO1xyXG4gICAgICAgICAgICAvLyB0aGlzLnJlbmRlcmVyLnNldEF0dHJpYnV0ZShlYWNoU3ZnLCAnaGVpZ2h0JywgOCk7XHJcbiAgICAgICAgICAgIC8vIGxldCBlYWNoU3ZnUGF0aCA9IHRoaXMucmVuZGVyZXIuY3JlYXRlRWxlbWVudCgncGF0aCcpO1xyXG4gICAgICAgICAgICAvLyB0aGlzLnJlbmRlcmVyLnNldEF0dHJpYnV0ZShlYWNoU3ZnUGF0aCwgJ2QnLCB0aGlzLmNvbmZpZy5sZWdlbmREYXRhW2xlZ2VuZElkXS5zaGFwZSk7XHJcbiAgICAgICAgICAgIC8vIHRoaXMucmVuZGVyZXIuYXBwZW5kQ2hpbGQoZWFjaFN2ZywgZWFjaFN2Z1BhdGgpO1xyXG5cclxuICAgICAgICAgICAgLy8gbGV0IHhtbCA9IG5ldyBYTUxTZXJpYWxpemVyKCkuc2VyaWFsaXplVG9TdHJpbmcoZWFjaFN2Zyk7QVJJXHJcbiAgICAgICAgICAgIC8vIGxldCBkYXRhID0gXCJkYXRhOmltYWdlL3N2Zyt4bWw7YmFzZTY0LFwiICsgYnRvYSh4bWwpO1xyXG5cclxuICAgICAgICAgICAgLy8gdGhpcy5pY29uc1tsZWdlbmRJZF0gPSB0aGlzLl9zYW5pdGl6ZXIuYnlwYXNzU2VjdXJpdHlUcnVzdFJlc291cmNlVXJsKCdkYXRhOmltYWdlL3N2Zyt4bWw7dXRmOCw8c3ZnIHhtbG5zPVwiaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmdcIiBmaWxsPVwiJyArIGxlZ2VuZENvbmZpZy5jb2xvciArICdcIiB3aWR0aD1cIjhcIiBoZWlnaHQ9XCI4XCI+PHBhdGggZD1cIicgKyB0aGlzLnNoYXBlc1tsZWdlbmRDb25maWcuc2hhcGVdICsgJ1wiLz48L3N2Zz4nKTtcclxuICAgICAgICAgICAgLy8gdGhpcy5pY29uc1tsZWdlbmRJZF0gPSB0aGlzLl9zYW5pdGl6ZXIuYnlwYXNzU2VjdXJpdHlUcnVzdFJlc291cmNlVXJsKGRhdGEpO1xyXG5cclxuICAgICAgICAgICAgLy8gbGVnZW5kIGlzIHNldCBiYXNlZCBvbiB3aGV0aGVyIHRoZXJlIGlzIGRlYWN0aXZlXHJcbiAgICAgICAgICAgIHRoaXMuX3VwZGF0ZUxlZ2VuZEljb24obGVnZW5kSWQsIGxlZ2VuZENvbmZpZyk7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX3NldExhYmVsU3R5bGUoKTogdm9pZCB7XHJcbiAgICAgICAgaWYgKHRoaXMuY29uZmlnLmNoYXJ0LmxhYmVscy5lbmFibGVkKSB7XHJcbiAgICAgICAgICAgIGxldCBsYWJlbFN0eWxlOiBzdHJpbmcgPSB0aGlzLl9jaGFydFN2Yy5nZXRTdHlsZSh0aGlzLmNvbmZpZy5jaGFydC5sYWJlbHMuc3R5bGUpO1xyXG5cclxuICAgICAgICAgICAgdGhpcy5fYXBwbHlMYWJlbFN0eWxlKGxhYmVsU3R5bGUsICcgc3BhbicsIHRydWUpO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF9zZXREYXRhKF9kYXRhOiBhbnkpOiB2b2lkIHtcclxuICAgICAgICB0aGlzLmxlZ2VuZEluYWN0aXZlID0gW107XHJcbiAgICAgICAgdGhpcy5tYXJrZXJzTGVnZW5kID0gW107ICAgICAgICBcclxuICAgICAgICB0aGlzLl9zZXRDaGFydFR5cGUoX2RhdGEpO1xyXG5cclxuICAgICAgICBpZiAodGhpcy5jb25maWcuc2tpcE1hc3NhZ2UpIHtcclxuICAgICAgICAgICAgdGhpcy5kYXRhID0gX2RhdGE7XHJcbiAgICAgICAgICAgIHRoaXMuX3NldENvbmZpZyh0aGlzLmNvbmZpZyk7XHJcbiAgICAgICAgICAgIHJldHVybjtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIGlmICh0aGlzLmNoYXJ0Q2F0ZWdvcnkgPT09ICdwaWUnIHx8IHRoaXMuY2hhcnRDYXRlZ29yeSA9PT0gJ21hcCcpIHtcclxuICAgICAgICAgICAgaWYgKHRoaXMuY2hhcnRDYXRlZ29yeSA9PT0gJ3BpZScpIHRoaXMuX2RhdGFNYXNzYWdlRm9yUGllKF9kYXRhKTtcclxuICAgICAgICAgICAgZWxzZSBpZiAodGhpcy5jaGFydENhdGVnb3J5ID09PSAnbWFwJykgdGhpcy5fZGF0YU1hc3NhZ2VGb3JNYXAoX2RhdGEpO1xyXG4gICAgICAgICAgICAvLyBlbHNlIGlmICh0aGlzLmNoYXJ0Q2F0ZWdvcnkgPT09ICdtYXAnKSB0aGlzLmRhdGEgPSBfZGF0YTtcclxuICAgICAgICAgICAgdGhpcy5fc2V0Q29uZmlnKHRoaXMuY29uZmlnKTtcclxuICAgICAgICB9IGVsc2UgdGhpcy5fZGF0YU1hc3NhZ2UoX2RhdGEpO1xyXG5cclxuICAgICAgICAvLyBlbWl0IGRhdGEgdG8ga2QtdmlzdWFsaXphdGlvbiB0byBwcmVwYXJlIGZvciBleHBvcnRcclxuICAgICAgICB0aGlzLm91dHB1dERhdGEuZW1pdCh0aGlzLmRhdGEpO1xyXG5cclxuICAgICAgICAvLyBlbWl0IGN1cnJlbnQgY29uZmlnIHRvIGtkLXZpc3VhbGl6YXRpb24gdG8gcHJlcGFyZSBmb3IgZXhwb3J0XHJcbiAgICAgICAgdGhpcy5vdXRwdXRMZWdlbmREYXRhLmVtaXQodGhpcy5sZWdlbmREYXRhKTtcclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF9zZXRDaGFydFR5cGUoX2RhdGEpIHtcclxuICAgICAgICBsZXQgZGF0YVRvVXNlOiBhbnkgPSBfZGF0YTtcclxuICAgICAgICBpZiAoIXRoaXMuY29uZmlnLnNraXBNYXNzYWdlIHx8IChfZGF0YS5jaGFydCAmJiBfZGF0YS5jaGFydC50eXBlID09ICdtYXAnKSkge1xyXG4gICAgICAgICAgICBkYXRhVG9Vc2UgPSBfZGF0YS5jaGFydDtcclxuICAgICAgICB9XHJcbiAgICAgICAgdGhpcy5jaGFydENhdGVnb3J5ID0gZGF0YVRvVXNlLnR5cGU7XHJcbiAgICAgICAgdGhpcy5jaGFydFR5cGUgPSBkYXRhVG9Vc2UubGF5b3V0LnNwbGl0KCctJyk7XHJcbiAgICAgICAgdGhpcy5pc0F4aXNDaGFydCA9IGRhdGFUb1VzZS50eXBlICE9PSAncGllJyAmJiBkYXRhVG9Vc2UudHlwZSAhPT0gJ21hcCc7XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfc2V0RGF0YUNvbG9yU2hhcGUoX2luZGV4OiBudW1iZXIsIF9jb2xvcjogc3RyaW5nKTogdm9pZCB7XHJcbiAgICAgICAgaWYgKF9pbmRleCA8IDApIHsgcmV0dXJuOyB9XHJcbiAgICAgICAgLy8gbGV0IGNoYW5nZVNlcmllczogYm9vbGVhbiA9IHRoaXMuY29uZmlnLmNoYXJ0Lmhhc093blByb3BlcnR5KCdwZXJzaXN0ZW50U2VyaWVzQ2hhbmdlJykgPyB0aGlzLmNvbmZpZy5jaGFydC5wZXJzaXN0ZW50U2VyaWVzQ2hhbmdlIDogdHJ1ZTtcclxuICAgICAgICBsZXQgbGVnZW5kSWRzOiBBcnJheTxzdHJpbmc+ID0gT2JqZWN0LmtleXModGhpcy5sZWdlbmREYXRhKTtcclxuICAgICAgICBpZiAodGhpcy5jaGFydENhdGVnb3J5ICE9ICdtYXAnKSB7XHJcbiAgICAgICAgICAgIGZvciAobGV0IHhJbmRleDogbnVtYmVyID0gdGhpcy5kYXRhLmRhdGEubGVuZ3RoIC0gMTsgeEluZGV4ID49IDA7IHhJbmRleC0tKSB7XHJcbiAgICAgICAgICAgICAgICBmb3IgKGxldCB5SW5kZXg6IG51bWJlciA9IHRoaXMuZGF0YS5kYXRhW3hJbmRleF0ueS5sZW5ndGggLSAxOyB5SW5kZXggPj0gMDsgeUluZGV4LS0pIHtcclxuICAgICAgICAgICAgICAgICAgICBpZiAodGhpcy5kYXRhLmRhdGFbeEluZGV4XS55W3lJbmRleF0uaWQgPT09IGxlZ2VuZElkc1tfaW5kZXhdKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuX2NoYW5nZVNlcmllcyh4SW5kZXgsIHlJbmRleCwgJ2NvbG9yJyk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuX2NoYW5nZVNlcmllcyh4SW5kZXgsIHlJbmRleCwgJ3NoYXBlJyk7XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX2NoYW5nZVNlcmllcyhfeEluZGV4OiBudW1iZXIsIF95SW5kZXg6IG51bWJlciwgX2VsZW1lbnQ6ICdjb2xvcicgfCAnc2hhcGUnKTogdm9pZCB7XHJcbiAgICAgICAgbGV0IGxlZ2VuZElkOiBzdHJpbmcgPSB0aGlzLmRhdGEuZGF0YVtfeEluZGV4XS55W195SW5kZXhdLmlkO1xyXG4gICAgICAgIGxldCBvdXRwdXQ6IGFueSA9IHRoaXMubGVnZW5kRGF0YVtsZWdlbmRJZF1bX2VsZW1lbnRdO1xyXG4gICAgICAgIGlmIChfZWxlbWVudCA9PT0gJ3NoYXBlJykge1xyXG4gICAgICAgICAgICBvdXRwdXQgPSB0aGlzLnNoYXBlc1tvdXRwdXRdO1xyXG4gICAgICAgIH1cclxuICAgICAgICBpZiAodGhpcy5faXNDaGFuZ2VTZXJpZXMoX3hJbmRleCwgX3lJbmRleCwgX2VsZW1lbnQpKSB7XHJcbiAgICAgICAgICAgIHRoaXMuZGF0YS5kYXRhW194SW5kZXhdLnlbX3lJbmRleF1bX2VsZW1lbnRdID0gb3V0cHV0O1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF9pc0NoYW5nZVNlcmllcyhfeEluZGV4OiBudW1iZXIsIF95SW5kZXg6IG51bWJlciwgX2VsZW1lbnQ6ICdjb2xvcicgfCAnc2hhcGUnKTogYm9vbGVhbiB7XHJcbiAgICAgICAgbGV0IGNoYW5nZVNlcmllczogYm9vbGVhbiA9IHRoaXMuY29uZmlnLmNoYXJ0Lmhhc093blByb3BlcnR5KCdwZXJzaXN0ZW50U2VyaWVzQ2hhbmdlJykgPyB0aGlzLmNvbmZpZy5jaGFydC5wZXJzaXN0ZW50U2VyaWVzQ2hhbmdlIDogdHJ1ZTtcclxuICAgICAgICBpZiAoY2hhbmdlU2VyaWVzKSB7XHJcbiAgICAgICAgICAgIHJldHVybiB0cnVlO1xyXG4gICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgIGlmICh0aGlzLmNoYXJ0RGF0YS5zZXJpZXNbX3lJbmRleF0uZGF0YVtfeEluZGV4XS5oYXNPd25Qcm9wZXJ0eShfZWxlbWVudCkpIHtcclxuICAgICAgICAgICAgICAgIGlmICh0aGlzLmNoYXJ0RGF0YS5zZXJpZXNbX3lJbmRleF0uZGF0YVtfeEluZGV4XVtfZWxlbWVudF0gIT09IG51bGwgfHwgdGhpcy5jaGFydERhdGEuc2VyaWVzW195SW5kZXhdLmRhdGFbX3hJbmRleF1bX2VsZW1lbnRdLmxlbmd0aCA+IDApIHtcclxuICAgICAgICAgICAgICAgICAgICByZXR1cm4gZmFsc2U7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICAgICAgcmV0dXJuIHRydWU7XHJcbiAgICB9XHJcblxyXG4gICAgcHVibGljIG9uTGVnZW5kQ2xpY2soX2lkOiBzdHJpbmcpOiB2b2lkIHtcclxuICAgICAgICBsZXQgbGVnZW5kQ29uZmlnOiBJTGVnZW5kRGF0YSA9IHRoaXMubGVnZW5kRGF0YVtfaWRdO1xyXG5cclxuICAgICAgICBsZWdlbmRDb25maWcuZGVhY3RpdmUgPSAhbGVnZW5kQ29uZmlnLmRlYWN0aXZlIHx8IGZhbHNlO1xyXG5cclxuICAgICAgICB0aGlzLl91cGRhdGVMZWdlbmRJdGVtKF9pZCwgbGVnZW5kQ29uZmlnKTtcclxuXHJcbiAgICAgICAgaWYgKGxlZ2VuZENvbmZpZy5kZWFjdGl2ZSkge1xyXG4gICAgICAgICAgICB0aGlzLmxlZ2VuZEluYWN0aXZlLnB1c2goX2lkKTtcclxuICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICBsZXQgaWRJbmRleDogbnVtYmVyID0gdGhpcy5sZWdlbmRJbmFjdGl2ZS5pbmRleE9mKF9pZCk7XHJcbiAgICAgICAgICAgIGlmIChpZEluZGV4ICE9PSAtMSkge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5sZWdlbmRJbmFjdGl2ZS5zcGxpY2UoaWRJbmRleCwgMSk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIGlmICh0aGlzLmNoYXJ0Q2F0ZWdvcnkgIT0gJ21hcCcpIHtcclxuICAgICAgICAgICAgbGV0IGxlZ2VuZERhdGE6IHsgW2tleTogc3RyaW5nXTogSUxlZ2VuZERhdGEgfSA9IHRoaXMudXBkYXRlQ29uZmlnKCk7XHJcbiAgICAgICAgICAgIGxldCBkYXRhOiBJRDNEYXRhID0gdGhpcy51cGRhdGVEYXRhKGxlZ2VuZERhdGEpO1xyXG5cclxuICAgICAgICAgICAgdGhpcy5hcGkubGVnZW5kQ2xpY2soZGF0YSwgbGVnZW5kRGF0YSk7XHJcbiAgICAgICAgICAgIHRoaXMuX3RvZ2dsZURhdGFMYWJlbChfaWQsIGxlZ2VuZENvbmZpZy5kZWFjdGl2ZSk7XHJcbiAgICAgICAgICAgIC8vIHVwZGF0ZSBkYXRhIHRvIGtkLXZpc3VhbGl6YXRpb24gdG8gcHJlcGFyZSBmb3IgZXhwb3J0aW5nXHJcbiAgICAgICAgICAgIHRoaXMub3V0cHV0RGF0YS5lbWl0KGRhdGEpO1xyXG4gICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgIHRoaXMuYXBpLmxlZ2VuZENsaWNrKF9pZCwgbGVnZW5kQ29uZmlnLmRlYWN0aXZlKTtcclxuICAgICAgICB9XHJcblxyXG4gICAgfVxyXG5cclxuICAgIHB1YmxpYyBvbkNsdXN0ZXJDbGljayhfaWQ6IGFueSk6IHZvaWQge1xyXG4gICAgICAgIGxldCBsZWdlbmRJdGVtTWFya2VyOiBIVE1MRWxlbWVudCA9IHRoaXMuX2VsZW1lbnRSZWYubmF0aXZlRWxlbWVudC5xdWVyeVNlbGVjdG9yKCcja2RsaS0nICsgX2lkLmlkICsgJyAuYXdlc29tZS1tYXJrZXInKTtcclxuICAgICAgICBsZXQgbGVnZW5kSXRlbUxhYmVsOiBIVE1MRWxlbWVudCA9IHRoaXMuX2VsZW1lbnRSZWYubmF0aXZlRWxlbWVudC5xdWVyeVNlbGVjdG9yKCcja2RsaS0nICsgX2lkLmlkICsgJyAua2R4LWxlZ2VuZC1sYWJlbCcpO1xyXG5cclxuICAgICAgICB0aGlzLmFwaS5jbHVzdGVyQ2xpY2soX2lkLCB7J2xlZ2VuZEl0ZW1NYXJrZXInOiBsZWdlbmRJdGVtTWFya2VyLCAnbGVnZW5kSXRlbUxhYmVsJzogbGVnZW5kSXRlbUxhYmVsfSk7XHJcbiAgICB9XHJcblxyXG4gICAgcHVibGljIGdldE91dHB1dExlZ2VuZChfbGVnZW5kRGF0YTogeyBba2V5OiBzdHJpbmddOiBJTGVnZW5kRGF0YSB9KTogdm9pZCB7XHJcbiAgICAgICAgaWYgKHRoaXMuY2hhcnRDYXRlZ29yeSA9PSAnbWFwJyAmJiBPYmplY3Qua2V5cyhfbGVnZW5kRGF0YSkubGVuZ3RoID09IDApIHtcclxuICAgICAgICAgICAgdGhpcy5jaGVja01hcFNjYWxlID0gdHJ1ZTtcclxuICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICB0aGlzLmxlZ2VuZERhdGEgPSBfbGVnZW5kRGF0YTtcclxuICAgICAgICAgICAgdGhpcy5jaGVja01hcFNjYWxlID0gZmFsc2U7XHJcbiAgICAgICAgICAgIHRoaXMuX3BpZURvbmVGbGFnID0gdHJ1ZTtcclxuICAgICAgICAgICAgdGhpcy5vdXRwdXRMZWdlbmREYXRhLmVtaXQodGhpcy5sZWdlbmREYXRhKTtcclxuICAgICAgICAgICAgdGhpcy5fcG9wdWxhdGVMZWdlbmRJY29uKHVuZGVmaW5lZCk7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIHB1YmxpYyBnZXRPdXRwdXREYXRhKF9kYXRhOiBhbnkpOiB2b2lkIHtcclxuICAgICAgICAvLyB0aGlzLm91dHB1dERhdGEuZW1pdChfZGF0YSk7XHJcbiAgICAgICAgdGhpcy5vdXRwdXRBcmVhLmVtaXQoX2RhdGEpO1xyXG4gICAgfVxyXG5cclxuICAgIHB1YmxpYyBnZXRSZWFkeShfdmFsdWU6IGJvb2xlYW4pIDogdm9pZCB7XHJcbiAgICAgICAgdGhpcy5pc0xheWVyTG9hZGluZyA9IF92YWx1ZTtcclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF91cGRhdGVMZWdlbmRJdGVtKF9pZCwgX2xlZ2VuZENvbmZpZyk6IHZvaWQge1xyXG4gICAgICAgIHRoaXMuX3VwZGF0ZUxlZ2VuZEljb24oX2lkLCBfbGVnZW5kQ29uZmlnKTtcclxuICAgICAgICBsZXQgdGV4dENvbG9yOiBzdHJpbmcgPSAoX2xlZ2VuZENvbmZpZy5kZWFjdGl2ZSkgPyB0aGlzLmNvbmZpZy5sZWdlbmQuaXRlbS5pbmFjdGl2ZUNvbG9yIHx8ICcjQ0NDQ0NDJyA6IHRoaXMuY29uZmlnLmxlZ2VuZC5pdGVtLnN0eWxlLmNvbG9yIHx8IHRoaXMuY29uZmlnLmxlZ2VuZC5pdGVtLmFjdGl2ZUNvbG9yIHx8ICcjMDAwMDAwJztcclxuICAgICAgICB0aGlzLl9lbGVtZW50UmVmLm5hdGl2ZUVsZW1lbnQucXVlcnlTZWxlY3RvcignI2tkbGktJyArIF9pZCkuc3R5bGUuY29sb3IgPSB0ZXh0Q29sb3I7XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfdXBkYXRlTGVnZW5kSWNvbihfaWQsIF9sZWdlbmRDb25maWcpOiB2b2lkIHtcclxuICAgICAgICBsZXQgaWNvbkNvbG9yOiBzdHJpbmcgPSAoX2xlZ2VuZENvbmZpZy5kZWFjdGl2ZSkgPyB0aGlzLmNvbmZpZy5sZWdlbmQuaXRlbS5pbmFjdGl2ZUNvbG9yIHx8ICcjQ0NDQ0NDJyA6IF9sZWdlbmRDb25maWcuY29sb3IgfHwgJyMwMDAwMDAnO1xyXG4gICAgICAgIGxldCByZ2JDb2xvcjogc3RyaW5nID0gdGhpcy5fY29udmVydGlvblN2Yy5jb2xvclRvUmdiKGljb25Db2xvcik7XHJcbiAgICAgICAgdGhpcy5pY29uc1tfaWRdID0gdGhpcy5fc2FuaXRpemVyLmJ5cGFzc1NlY3VyaXR5VHJ1c3RSZXNvdXJjZVVybCgnZGF0YTppbWFnZS9zdmcreG1sO3V0ZjgsPHN2ZyB4bWxucz1cImh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnXCIgZmlsbD1cIicgKyByZ2JDb2xvciArICdcIiB3aWR0aD1cIjhcIiBoZWlnaHQ9XCI4XCI+PHBhdGggZD1cIicgKyB0aGlzLnNoYXBlc1tfbGVnZW5kQ29uZmlnLnNoYXBlXSArICdcIi8+PC9zdmc+Jyk7XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfdG9nZ2xlRGF0YUxhYmVsKGlkOiBzdHJpbmcsIGRlYWN0aXZlOiBib29sZWFuKTogdm9pZCB7XHJcbiAgICAgICAgbGV0IGRpc3BsYXlTdGF0ZTogc3RyaW5nID0gKGRlYWN0aXZlKSA/ICdub25lJyA6ICdmbGV4JztcclxuICAgICAgICB0aGlzLl9hcHBseUxhYmVsU3R5bGUoZGlzcGxheVN0YXRlLCAnLnktJyArIGlkKTtcclxuICAgICAgICBpZiAoIWRlYWN0aXZlKSB0aGlzLl9hcHBseUxhYmVsU3R5bGUoJ2Rpc3BsYXk6JyArIGRpc3BsYXlTdGF0ZSwgJy55LScgKyBpZCArICcgc3BhbicsIHRydWUpO1xyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX2FwcGx5TGFiZWxTdHlsZShfc3R5bGU6IHN0cmluZywgdGFyZ2V0OiBzdHJpbmcsIGlzUmVwb3NpdGlvbmluZz86IGJvb2xlYW4pOiB2b2lkIHtcclxuICAgICAgICB0YXJnZXQgPSB0YXJnZXQgfHwgJyc7XHJcbiAgICAgICAgbGV0IGFsbExhYmVsOiBIVE1MRWxlbWVudCA9IHRoaXMuX2VsZW1lbnRSZWYubmF0aXZlRWxlbWVudC5xdWVyeVNlbGVjdG9yQWxsKCcjJyArIHRoaXMuY29uZmlnLmlkICsgJyAua2R4LWNoYXJ0cy1kYXRhLWxhYmVsJyArIHRhcmdldCk7XHJcbiAgICAgICAgZm9yIChsZXQgaSBpbiBhbGxMYWJlbCkge1xyXG4gICAgICAgICAgICBpZiAoYWxsTGFiZWxbaV0uc3R5bGUpIHtcclxuXHJcbiAgICAgICAgICAgICAgICBpZiAoaXNSZXBvc2l0aW9uaW5nKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgbGV0IGxhYmVsV2lkdGg6IG51bWJlciA9IGFsbExhYmVsW2ldLm9mZnNldFdpZHRoO1xyXG4gICAgICAgICAgICAgICAgICAgIGxldCBsYWJlbENlbnRlcjogbnVtYmVyID0gKGxhYmVsV2lkdGggLSBsYWJlbFdpZHRoIC8gYWxsTGFiZWxbaV0uaW5uZXJUZXh0LnRvU3RyaW5nKCkubGVuZ3RoKSAvIDI7XHJcbiAgICAgICAgICAgICAgICAgICAgbGV0IHNoaWZ0UG9zaXRpb246IG51bWJlciA9IDAgLSBsYWJlbENlbnRlcjtcclxuXHJcbiAgICAgICAgICAgICAgICAgICAgX3N0eWxlICs9ICdsZWZ0OicgKyBzaGlmdFBvc2l0aW9uICsgJ3B4Oyc7XHJcbiAgICAgICAgICAgICAgICAgICAgYWxsTGFiZWxbaV0uc3R5bGUgPSBfc3R5bGU7XHJcbiAgICAgICAgICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgICAgIGFsbExhYmVsW2ldLnN0eWxlLmRpc3BsYXkgPSBfc3R5bGU7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSB1cGRhdGVDb25maWcoKTogeyBba2V5OiBzdHJpbmddOiBJTGVnZW5kRGF0YSB9IHtcclxuICAgICAgICBsZXQgbGVnZW5kRGF0YTogeyBba2V5OiBzdHJpbmddOiBJTGVnZW5kRGF0YSB9ID0gT2JqZWN0LmFzc2lnbih7fSwgdGhpcy5sZWdlbmREYXRhKTtcclxuICAgICAgICBsZXQgbGVnZW5kSW5hY3RpdmU6IEFycmF5PHN0cmluZz4gPSB0aGlzLmxlZ2VuZEluYWN0aXZlO1xyXG4gICAgICAgIGxlZ2VuZERhdGEgPSBPYmplY3Qua2V5cyhsZWdlbmREYXRhKVxyXG4gICAgICAgICAgICAuZmlsdGVyKGtleSA9PiAhbGVnZW5kSW5hY3RpdmUuaW5jbHVkZXMoa2V5KSlcclxuICAgICAgICAgICAgLnJlZHVjZSgob2JqLCBrZXkpID0+IHtcclxuICAgICAgICAgICAgICAgIG9ialtrZXldID0gbGVnZW5kRGF0YVtrZXldO1xyXG4gICAgICAgICAgICAgICAgcmV0dXJuIG9iajtcclxuICAgICAgICAgICAgfSwge30pO1xyXG4gICAgICAgIHJldHVybiBsZWdlbmREYXRhO1xyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgdXBkYXRlRGF0YShfbGVnZW5kRGF0YT86IHsgW2tleTogc3RyaW5nXTogSUxlZ2VuZERhdGEgfSk6IElEM0RhdGEge1xyXG4gICAgICAgIGxldCB0aGlzRGF0YTogSUQzRGF0YSA9IEpTT04ucGFyc2UoSlNPTi5zdHJpbmdpZnkodGhpcy5kYXRhKSk7XHJcbiAgICAgICAgbGV0IGxlZ2VuZEluYWN0aXZlOiBBcnJheTxzdHJpbmc+ID0gdGhpcy5sZWdlbmRJbmFjdGl2ZTtcclxuXHJcbiAgICAgICAgaWYgKHRoaXMuY2hhcnRDYXRlZ29yeSA9PT0gJ3BpZScpIHtcclxuICAgICAgICAgICAgbGV0IGxlZ2VuZERhdGE6IGFueSA9IF9sZWdlbmREYXRhO1xyXG4gICAgICAgICAgICAvLyBwaWVkYXRhIHVzZXMgbGVnZW5kRGF0YSBpbnN0ZWFkIG9mIGRhdGFcclxuICAgICAgICAgICAgdGhpc0RhdGEuZGF0YSA9IE9iamVjdC5rZXlzKGxlZ2VuZERhdGEpLm1hcChrZXkgPT4gbGVnZW5kRGF0YVtrZXldKS5maWx0ZXIoKHZhbHVlKSA9PiB2YWx1ZS55ICYmIHZhbHVlLnkgPiAwKTtcclxuICAgICAgICAgICAgcmV0dXJuIHRoaXNEYXRhO1xyXG4gICAgICAgIH0gZWxzZSBpZiAodGhpcy5jaGFydFR5cGVbMV0gPT09ICcxMDAnICYmIHRoaXMuY2hhcnRUeXBlWzBdID09PSAnYXJlYScpIHtcclxuICAgICAgICAgICAgZm9yIChsZXQgaTogbnVtYmVyID0gdGhpc0RhdGEuZGF0YS5sZW5ndGggLSAxOyBpID49IDA7IGktLSkge1xyXG4gICAgICAgICAgICAgICAgbGV0IG5ld1lBcnI6IEFycmF5PElEM1lEYXRhPiA9IHRoaXNEYXRhLmRhdGFbaV0ueS5maWx0ZXIoZCA9PiAhbGVnZW5kSW5hY3RpdmUuaW5jbHVkZXMoZC5pZCkpO1xyXG4gICAgICAgICAgICAgICAgdGhpc0RhdGEuZGF0YVtpXSA9IE9iamVjdC5hc3NpZ24oe30sIHRoaXNEYXRhLmRhdGFbaV0sIHsgeTogbmV3WUFyciB9KTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgbGV0IG9yaWdpbmFsRGF0YTogSUQzRGF0YSA9IEpTT04ucGFyc2UoSlNPTi5zdHJpbmdpZnkodGhpc0RhdGEpKTtcclxuXHJcbiAgICAgICAgbGV0IGFsbFN1bUFyck1heDogQXJyYXk8bnVtYmVyPiA9IFswXTtcclxuICAgICAgICBsZXQgYWxsU3VtQXJyTWluOiBBcnJheTxudW1iZXI+ID0gWzBdO1xyXG4gICAgICAgIGxldCBoYXZlTmVnYXRpdmU6IGJvb2xlYW4gPSBmYWxzZTtcclxuXHJcbiAgICAgICAgZm9yIChsZXQgaTogbnVtYmVyID0gMDsgaSA8IG9yaWdpbmFsRGF0YS5kYXRhLmxlbmd0aDsgaSsrKSB7XHJcbiAgICAgICAgICAgIGxldCB0b3RhbFN1bTogbnVtYmVyID0gMTtcclxuICAgICAgICAgICAgaWYgKHRoaXMuY2hhcnRUeXBlWzFdID09PSAnMTAwJykge1xyXG4gICAgICAgICAgICAgICAgdG90YWxTdW0gPSB0aGlzRGF0YS5kYXRhW2ldLnkucmVkdWNlKChhY2MsIGN1cnIsIHlJbmRleCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgIGlmIChsZWdlbmRJbmFjdGl2ZS5pbmNsdWRlcyhjdXJyLmlkKSkgcmV0dXJuIGFjYztcclxuICAgICAgICAgICAgICAgICAgICByZXR1cm4gYWNjICsgY3Vyci52YWx1ZTtcclxuICAgICAgICAgICAgICAgIH0sIDApO1xyXG4gICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICBsZXQgbmV3WUFycjogQXJyYXk8YW55PiA9IFtdO1xyXG4gICAgICAgICAgICBsZXQgc3VtQXJyOiBBcnJheTxudW1iZXI+ID0gW107XHJcbiAgICAgICAgICAgIGxldCBzdW06IG51bWJlciA9IDA7XHJcbiAgICAgICAgICAgIGxldCBzdW1OZWdhdGl2ZTogbnVtYmVyID0gMDtcclxuXHJcbiAgICAgICAgICAgIGZvciAobGV0IHlJbmRleDogbnVtYmVyID0gMDsgeUluZGV4IDwgb3JpZ2luYWxEYXRhLmRhdGFbaV0ueS5sZW5ndGg7IHlJbmRleCsrKSB7XHJcbiAgICAgICAgICAgICAgICBsZXQgY3Vyclk6IElEM1lEYXRhID0gT2JqZWN0LmFzc2lnbih7fSwgb3JpZ2luYWxEYXRhLmRhdGFbaV0ueVt5SW5kZXhdKTtcclxuICAgICAgICAgICAgICAgIGlmIChsZWdlbmRJbmFjdGl2ZS5pbmNsdWRlcyhjdXJyWS5pZCkpIGNvbnRpbnVlO1xyXG4gICAgICAgICAgICAgICAgbGV0IGN1cnJlbnRWYWw6IG51bWJlciA9IGN1cnJZLnZhbHVlID09PSBudWxsID8gMCA6IGN1cnJZLnZhbHVlO1xyXG4gICAgICAgICAgICAgICAgbGV0IGN1cnJTaWduOiBudW1iZXIgPSBNYXRoLnNpZ24oY3VycmVudFZhbCk7XHJcblxyXG4gICAgICAgICAgICAgICAgaWYgKGN1cnJTaWduIDwgMCAmJiAhaGF2ZU5lZ2F0aXZlKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgaGF2ZU5lZ2F0aXZlID0gdHJ1ZTtcclxuICAgICAgICAgICAgICAgICAgICBpZiAodGhpcy5jaGFydFR5cGVbMV0gPT09ICcxMDAnKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuY2hhcnRIaWRlID0gdHJ1ZTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgICAgIGlmICh0aGlzLmNoYXJ0VHlwZVsxXSAhPT0gJzEwMCcgJiYgdGhpcy5jaGFydFR5cGVbMV0gPT09ICdzdGFjaycpIHtcclxuICAgICAgICAgICAgICAgICAgICBpZiAoY3VyclNpZ24gPj0gMCkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBzdW0gPSAoY3VycmVudFZhbCA9PT0gbnVsbCkgPyBzdW0gOiBzdW0gKyBjdXJyZW50VmFsO1xyXG4gICAgICAgICAgICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHN1bU5lZ2F0aXZlID0gKGN1cnJlbnRWYWwgPT09IG51bGwpID8gc3VtTmVnYXRpdmUgOiBzdW1OZWdhdGl2ZSArIGN1cnJlbnRWYWw7XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgfSBlbHNlIGlmICh0aGlzLmNoYXJ0VHlwZVsxXSA9PT0gJzEwMCcpIHtcclxuICAgICAgICAgICAgICAgICAgICBpZiAoY3VycmVudFZhbCAhPT0gbnVsbCAmJiB0b3RhbFN1bSAhPT0gMCkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBjdXJyZW50VmFsID0gY3VycmVudFZhbCAvIHRvdGFsU3VtICogMTAwO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBzdW0gPSBzdW0gKyBjdXJyZW50VmFsO1xyXG4gICAgICAgICAgICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHN1bSA9IHN1bTtcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgICAgIGlmIChjdXJyU2lnbiA+PSAwKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHN1bSA9IChjdXJyZW50VmFsID09PSBudWxsKSA/IDAgOiBjdXJyZW50VmFsO1xyXG4gICAgICAgICAgICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHN1bU5lZ2F0aXZlID0gKGN1cnJlbnRWYWwgPT09IG51bGwpID8gMCA6IGN1cnJlbnRWYWw7XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgY3Vyclkuc3VtID0gY3VycmVudFZhbCA+PSAwID8gc3VtIDogc3VtTmVnYXRpdmU7XHJcblxyXG4gICAgICAgICAgICAgICAgLy8gdmFsdWUgaXMgdXNlZCB0byBkaXNwbGF5IGRhdGEtbGFiZWwgYW5kIHRvb2x0aXAsIHJlbmRlclZhbCBpcyB0aGUgYWN1dGFsIHBlcmNlbnRhZ2UgdG8gcGFzcyB0byBkMyBmb3IgcmVuZGVyaW5nXHJcbiAgICAgICAgICAgICAgICBpZiAodGhpcy5jaGFydFR5cGVbMV0gPT09ICcxMDAnKSBjdXJyWVsncmVuZGVyVmFsJ10gPSBjdXJyZW50VmFsO1xyXG5cclxuICAgICAgICAgICAgICAgIHN1bUFyci5wdXNoKE1hdGguc2lnbihjdXJyZW50VmFsKSA8IDAgPyBzdW1OZWdhdGl2ZSA6IHN1bSk7XHJcbiAgICAgICAgICAgICAgICBuZXdZQXJyLnB1c2goY3VyclkpO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIGFsbFN1bUFyck1heC5wdXNoKHRoaXMuX2NoYXJ0U3ZjLmdldEQzTWF4T3JNaW4oc3VtQXJyLCAnbWF4JykpO1xyXG4gICAgICAgICAgICBhbGxTdW1BcnJNaW4ucHVzaCh0aGlzLl9jaGFydFN2Yy5nZXREM01heE9yTWluKHN1bUFyciwgJ21pbicpKTtcclxuICAgICAgICAgICAgdGhpc0RhdGEuZGF0YVtpXSA9IE9iamVjdC5hc3NpZ24oe30sIG9yaWdpbmFsRGF0YS5kYXRhW2ldLCB7IHk6IG5ld1lBcnIgfSk7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICB0aGlzRGF0YVsncmFuZ2UnXSA9IHtcclxuICAgICAgICAgICAgbWF4OiB0aGlzLl9jaGFydFN2Yy5nZXREM01heE9yTWluKGFsbFN1bUFyck1heCwgJ21heCcpLFxyXG4gICAgICAgICAgICBtaW46IHRoaXMuX2NoYXJ0U3ZjLmdldEQzTWF4T3JNaW4oYWxsU3VtQXJyTWluLCAnbWluJylcclxuICAgICAgICB9O1xyXG4gICAgICAgIHRoaXNEYXRhWydoYXZlTmVnYXRpdmUnXSA9IGhhdmVOZWdhdGl2ZTtcclxuXHJcbiAgICAgICAgcmV0dXJuIHRoaXNEYXRhO1xyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX2dlbmVyYXRlTGVnZW5kRGF0YShfZGF0YTogSUNoYXJ0RGF0YSwgbWF4U2VyaWVzTGVuZ3RoOiBudW1iZXIpOiBvYmplY3Qge1xyXG4gICAgICAgIC8vIGVtcHR5IG91dCB2YXJpYWJsZXMgYmVmb3JlIHJlZ2VuZXJhdGluZ1xyXG4gICAgICAgIHRoaXMubGVnZW5kRGF0YSA9IHt9O1xyXG4gICAgICAgIC8vIHRoaXMubGVnZW5kTGlzdCA9IG51bGw7XHJcblxyXG4gICAgICAgIGxldCBsZWdlbmRJZFNlYXJjaDogb2JqZWN0ID0ge307XHJcbiAgICAgICAgbGV0IGxlZ2VuZElkOiBzdHJpbmcsIGxlZ2VuZERhdGFPYmo6IElMZWdlbmREYXRhO1xyXG4gICAgICAgIGxldCBsZWdlbmREYXRhOiB7IFtrZXk6IHN0cmluZ106IElMZWdlbmREYXRhIH0gPSB7fTtcclxuICAgICAgICBmb3IgKGxldCBpOiBudW1iZXIgPSAwOyBpIDwgbWF4U2VyaWVzTGVuZ3RoOyBpKyspIHtcclxuICAgICAgICAgICAgbGVnZW5kSWQgPSAoX2RhdGEuc2VyaWVzW2ldICYmIF9kYXRhLnNlcmllc1tpXS5sZW5ndGggPiAwKSA/IF9kYXRhLnNlcmllc1tpXS5pZCA6ICdpZCcgKyBpO1xyXG4gICAgICAgICAgICBsZWdlbmREYXRhT2JqID0ge1xyXG4gICAgICAgICAgICAgICAgJ25hbWUnOiBfZGF0YS5zZXJpZXNbaV0ubmFtZSxcclxuICAgICAgICAgICAgICAgICdpZCc6IGxlZ2VuZElkLFxyXG4gICAgICAgICAgICAgICAgJ2NvbG9yJzogX2RhdGEuc2VyaWVzW2ldLmNvbG9yIHx8IHRoaXMuX2dldERlZmF1bHRDb25maWcoJ2NvbG9yJywgaSksXHJcbiAgICAgICAgICAgICAgICAnc2hhcGUnOiBfZGF0YS5zZXJpZXNbaV0uc2hhcGUgfHwgdGhpcy5fZ2V0RGVmYXVsdENvbmZpZygnc2hhcGUnLCBpKVxyXG4gICAgICAgICAgICB9O1xyXG4gICAgICAgICAgICBpZiAodGhpcy5jaGFydENhdGVnb3J5ID09PSAnbGluZScgfHwgdGhpcy5jaGFydENhdGVnb3J5ID09PSAnc3BsaW5lJyB8fCB0aGlzLmNoYXJ0Q2F0ZWdvcnkgPT09ICdhcmVhJyB8fCB0aGlzLmNoYXJ0Q2F0ZWdvcnkgPT09ICdkb3QnKSB7XHJcbiAgICAgICAgICAgICAgICBsZWdlbmREYXRhT2JqWydkb3RFbmFibGVkJ10gPSAodHlwZW9mIF9kYXRhLnNlcmllc1tpXS5kb3RFbmFibGVkICE9PSAndW5kZWZpbmVkJykgPyBfZGF0YS5zZXJpZXNbaV0uZG90RW5hYmxlZCA6IHRydWU7XHJcbiAgICAgICAgICAgICAgICBsZWdlbmREYXRhT2JqWydkb3RCb3JkZXJXaWR0aCddID0gKHR5cGVvZiBfZGF0YS5zZXJpZXNbaV0uZG90Qm9yZGVyV2lkdGggIT09ICd1bmRlZmluZWQnKSA/IF9kYXRhLnNlcmllc1tpXS5kb3RCb3JkZXJXaWR0aCA6IDA7XHJcbiAgICAgICAgICAgICAgICBsZWdlbmREYXRhT2JqWydkb3RCb3JkZXJDb2xvciddID0gKHR5cGVvZiBfZGF0YS5zZXJpZXNbaV0uZG90Qm9yZGVyQ29sb3IgIT09ICd1bmRlZmluZWQnKSA/IF9kYXRhLnNlcmllc1tpXS5kb3RCb3JkZXJDb2xvciA6ICcjRkZGRkZGJztcclxuICAgICAgICAgICAgICAgIGlmICh0aGlzLmNoYXJ0Q2F0ZWdvcnkgIT09ICdkb3QnKSBsZWdlbmREYXRhT2JqWydsaW5lU3R5bGUnXSA9ICh0eXBlb2YgX2RhdGEuc2VyaWVzW2ldLmxpbmVTdHlsZSAhPT0gJ3VuZGVmaW5lZCcpID8gX2RhdGEuc2VyaWVzW2ldLmxpbmVTdHlsZSA6ICdzb2xpZCc7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgbGVnZW5kRGF0YVtsZWdlbmRJZF0gPSBsZWdlbmREYXRhT2JqO1xyXG4gICAgICAgICAgICBsZWdlbmRJZFNlYXJjaFtpXSA9IGxlZ2VuZElkO1xyXG4gICAgICAgIH1cclxuICAgICAgICB0aGlzLmxlZ2VuZERhdGEgPSBsZWdlbmREYXRhO1xyXG4gICAgICAgIHJldHVybiBsZWdlbmRJZFNlYXJjaDtcclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF9kYXRhTWFzc2FnZShfZGF0YTogSUNoYXJ0RGF0YSk6IHZvaWQge1xyXG4gICAgICAgIGxldCBzZXJpZXNMZW5ndGg6IG51bWJlciA9IHRoaXMuX2NoYXJ0U3ZjLmdldEQzTWF4T3JNaW4oW19kYXRhLnNlcmllcy5sZW5ndGgsIHRoaXMuc2VyaWVzVGhyZXNob2xkXSwgJ21pbicpO1xyXG4gICAgICAgIGxldCBjaGFydERhdGFPYmo6IElEM0RhdGFEYXRhLCBjaGFydERhdGFTZXJpZXNPYmo6IElEM1lEYXRhO1xyXG4gICAgICAgIGxldCBjaGFydERhdGE6IElEM0RhdGEgPSB7XHJcbiAgICAgICAgICAgICd0eXBlJzogX2RhdGEuY2hhcnRbJ3R5cGUnXSA/IF9kYXRhLmNoYXJ0Wyd0eXBlJ10gOiBudWxsLFxyXG4gICAgICAgICAgICAnbGF5b3V0JzogX2RhdGEuY2hhcnRbJ2xheW91dCddID8gX2RhdGEuY2hhcnRbJ2xheW91dCddIDogbnVsbCxcclxuICAgICAgICAgICAgJ2NvbmZpZyc6IHRoaXMuY29uZmlnLnBsb3RPcHRpb25zICYmIHRoaXMuY29uZmlnLnBsb3RPcHRpb25zLmhhc093blByb3BlcnR5KF9kYXRhLmNoYXJ0Wyd0eXBlJ10pID8gdGhpcy5jb25maWcucGxvdE9wdGlvbnNbX2RhdGEuY2hhcnRbJ3R5cGUnXV0gOiB7fSxcclxuICAgICAgICAgICAgJ2RhdGEnOiBbXVxyXG4gICAgICAgIH07XHJcbiAgICAgICAgaWYgKCF0aGlzLmNvbmZpZy5oYXNPd25Qcm9wZXJ0eSgnaWQnKSkge1xyXG4gICAgICAgICAgICB0aGlzLmNvbmZpZ1snaWQnXSA9IF9kYXRhLmNoYXJ0Wyd0eXBlJ10gPyBfZGF0YS5jaGFydFsndHlwZSddICsgJy0xJyA6ICdEZWZhdWx0LTEnO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgbGV0IGNhdGVnb3JpZXM6IEFycmF5PHN0cmluZz4gPSB0aGlzLl9jaGFydFN2Yy5nZXRMaW1pdGVkQ2F0ZWdvcmllcyhfZGF0YS54QXhpcy5jYXRlZ29yaWVzLCB0aGlzLnhUaHJlc2hvbGQpO1xyXG5cclxuICAgICAgICBsZXQgbGVnZW5kSWRTZWFyY2g6IG9iamVjdCA9IHRoaXMuX2dlbmVyYXRlTGVnZW5kRGF0YShfZGF0YSwgc2VyaWVzTGVuZ3RoKTtcclxuXHJcbiAgICAgICAgbGV0IHRvdGFsU3VtQXJyOiBBcnJheTxudW1iZXI+IHwgb2JqZWN0ID0gdGhpcy5fZ2V0VG90YWxTdW0oX2RhdGEsIHNlcmllc0xlbmd0aCk7XHJcbiAgICAgICAgbGV0IGFsbFN1bUFyck1heDogQXJyYXk8bnVtYmVyPiA9IFswXTtcclxuICAgICAgICBsZXQgYWxsU3VtQXJyTWluOiBBcnJheTxudW1iZXI+ID0gWzBdO1xyXG4gICAgICAgIGxldCBoYXZlTmVnYXRpdmU6IGJvb2xlYW4gPSBmYWxzZTtcclxuXHJcbiAgICAgICAgZm9yIChsZXQgaSA9IDA7IGkgPCBjYXRlZ29yaWVzLmxlbmd0aDsgaSsrKSB7XHJcbiAgICAgICAgICAgIGNoYXJ0RGF0YU9iaiA9IHtcclxuICAgICAgICAgICAgICAgICd4Jzoge1xyXG4gICAgICAgICAgICAgICAgICAgIHZhbHVlOiBpLnRvU3RyaW5nKCksXHJcbiAgICAgICAgICAgICAgICAgICAgbGFiZWw6IGNhdGVnb3JpZXNbaV1cclxuICAgICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICAgICAneSc6IFtdLFxyXG4gICAgICAgICAgICAgICAgLy8gJ3onOiAnU2luZ2Fwb3JlJ1xyXG4gICAgICAgICAgICB9O1xyXG5cclxuICAgICAgICAgICAgbGV0IHN1bUFycjogQXJyYXk8bnVtYmVyPiA9IFtdO1xyXG4gICAgICAgICAgICBsZXQgc3VtOiBudW1iZXIgPSAwO1xyXG4gICAgICAgICAgICBsZXQgc3VtTmVnYXRpdmU6IG51bWJlciA9IDA7XHJcblxyXG4gICAgICAgICAgICBsZXQgZm9yTG9vcEluZm86IElGb3JMb29wSW5mbyA9IHRoaXMuX2NoYXJ0U3ZjLmdldEZvckxvb3BJbmZvKHRoaXMuX2NoYXJ0U3ZjLmdldEZvckxvb3BTZXF1ZW5jZSh0aGlzLmNoYXJ0VHlwZSksIHNlcmllc0xlbmd0aCk7XHJcblxyXG4gICAgICAgICAgICAvLyBmb3IgKGxldCBqOiBudW1iZXIgPSAwOyBqIDwgc2VyaWVzTGVuZ3RoOyBqKyspIHtcclxuICAgICAgICAgICAgZm9yIChsZXQgajogbnVtYmVyID0gZm9yTG9vcEluZm8uc3RhcnQ7IGZvckxvb3BJbmZvLmNoZWNrKGosIGZvckxvb3BJbmZvLmVuZCk7IGogPSBmb3JMb29wSW5mby5pdGVyYXRlKGopKSB7XHJcbiAgICAgICAgICAgICAgICBpZiAodHlwZW9mIF9kYXRhLnNlcmllc1tqXS5kYXRhW2ldID09PSAndW5kZWZpbmVkJykgY29udGludWU7XHJcblxyXG4gICAgICAgICAgICAgICAgbGV0IGN1cnJlbnRWYWw6IG51bWJlciB8IG51bGwgPSBfZGF0YS5zZXJpZXNbal0uZGF0YVtpXS52YWx1ZTtcclxuICAgICAgICAgICAgICAgIGxldCBjdXJyU2lnbjogbnVtYmVyID0gTWF0aC5zaWduKGN1cnJlbnRWYWwpO1xyXG5cclxuICAgICAgICAgICAgICAgIGlmICh0eXBlb2YgY3VycmVudFZhbCA9PT0gJ3VuZGVmaW5lZCcpIGNvbnRpbnVlO1xyXG5cclxuICAgICAgICAgICAgICAgIGlmIChjdXJyU2lnbiA8IDAgJiYgIWhhdmVOZWdhdGl2ZSkge1xyXG4gICAgICAgICAgICAgICAgICAgIGhhdmVOZWdhdGl2ZSA9IHRydWU7XHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKHRoaXMuY2hhcnRUeXBlWzFdID09PSAnMTAwJykgYnJlYWs7XHJcbiAgICAgICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICAgICAgaWYgKHRoaXMuY2hhcnRUeXBlWzFdICE9PSAnMTAwJyAmJiB0aGlzLmNoYXJ0VHlwZVsxXSA9PT0gJ3N0YWNrJykge1xyXG4gICAgICAgICAgICAgICAgICAgIGlmIChjdXJyU2lnbiA+PSAwKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHN1bSA9IChjdXJyZW50VmFsID09PSBudWxsKSA/IHN1bSA6IHN1bSArIGN1cnJlbnRWYWw7XHJcbiAgICAgICAgICAgICAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgc3VtTmVnYXRpdmUgPSAoY3VycmVudFZhbCA9PT0gbnVsbCkgPyBzdW1OZWdhdGl2ZSA6IHN1bU5lZ2F0aXZlICsgY3VycmVudFZhbDtcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICB9IGVsc2UgaWYgKHRoaXMuY2hhcnRUeXBlWzFdID09PSAnMTAwJykge1xyXG4gICAgICAgICAgICAgICAgICAgIGlmIChjdXJyZW50VmFsICE9PSBudWxsICYmIHRvdGFsU3VtQXJyW2ldICE9PSAwKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGN1cnJlbnRWYWwgPSBjdXJyZW50VmFsIC8gdG90YWxTdW1BcnJbaV0gKiAxMDA7XHJcbiAgICAgICAgICAgICAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgY3VycmVudFZhbCA9IDA7XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIHN1bSA9IHN1bSArIGN1cnJlbnRWYWw7XHJcbiAgICAgICAgICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgICAgIGlmIChjdXJyU2lnbiA+PSAwKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHN1bSA9IChjdXJyZW50VmFsID09PSBudWxsKSA/IDAgOiBjdXJyZW50VmFsO1xyXG4gICAgICAgICAgICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHN1bU5lZ2F0aXZlID0gKGN1cnJlbnRWYWwgPT09IG51bGwpID8gMCA6IGN1cnJlbnRWYWw7XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgICAgIGNoYXJ0RGF0YVNlcmllc09iaiA9IHtcclxuICAgICAgICAgICAgICAgICAgICAnc3VtJzogY3VycmVudFZhbCA+PSAwID8gc3VtIDogc3VtTmVnYXRpdmUsXHJcbiAgICAgICAgICAgICAgICAgICAgJ3ZhbHVlJzogX2RhdGEuc2VyaWVzW2pdLmRhdGFbaV0udmFsdWUsXHJcbiAgICAgICAgICAgICAgICAgICAgJ2NvbG9yJzogdGhpcy5fZ2V0Q29uZmlnKCdjb2xvcicsIGosIF9kYXRhLnNlcmllc1tqXS5kYXRhW2ldKSxcclxuICAgICAgICAgICAgICAgICAgICAnc2hhcGUnOiB0aGlzLnNoYXBlc1t0aGlzLl9nZXRDb25maWcoJ3NoYXBlJywgaiwgX2RhdGEuc2VyaWVzW2pdLmRhdGFbaV0pXSxcclxuICAgICAgICAgICAgICAgICAgICAnaWQnOiBsZWdlbmRJZFNlYXJjaFtqXVxyXG4gICAgICAgICAgICAgICAgfTtcclxuXHJcbiAgICAgICAgICAgICAgICAvLyB2YWx1ZSBpcyB1c2VkIHRvIGRpc3BsYXkgZGF0YS1sYWJlbCBhbmQgdG9vbHRpcCwgcmVuZGVyVmFsIGlzIHRoZSBhY3V0YWwgcGVyY2VudGFnZSB0byBwYXNzIHRvIGQzIGZvciByZW5kZXJpbmdcclxuICAgICAgICAgICAgICAgIGlmICh0aGlzLmNoYXJ0VHlwZVsxXSA9PT0gJzEwMCcpIGNoYXJ0RGF0YVNlcmllc09ialsncmVuZGVyVmFsJ10gPSBjdXJyZW50VmFsO1xyXG5cclxuICAgICAgICAgICAgICAgIHN1bUFyci5wdXNoKE1hdGguc2lnbihjdXJyZW50VmFsKSA8IDAgPyBzdW1OZWdhdGl2ZSA6IHN1bSk7XHJcbiAgICAgICAgICAgICAgICBjaGFydERhdGFPYmoueS5wdXNoKGNoYXJ0RGF0YVNlcmllc09iaik7XHJcbiAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgIGFsbFN1bUFyck1heC5wdXNoKHRoaXMuX2NoYXJ0U3ZjLmdldEQzTWF4T3JNaW4oc3VtQXJyLCAnbWF4JykpO1xyXG4gICAgICAgICAgICBhbGxTdW1BcnJNaW4ucHVzaCh0aGlzLl9jaGFydFN2Yy5nZXREM01heE9yTWluKHN1bUFyciwgJ21pbicpKTtcclxuXHJcbiAgICAgICAgICAgIGNoYXJ0RGF0YS5kYXRhLnB1c2goY2hhcnREYXRhT2JqKTtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIGlmIChfZGF0YS5jaGFydC50eXBlICE9PSAncGllJykge1xyXG4gICAgICAgICAgICBjaGFydERhdGFbJ3JhbmdlJ10gPSB7XHJcbiAgICAgICAgICAgICAgICBtYXg6IHRoaXMuX2NoYXJ0U3ZjLmdldEQzTWF4T3JNaW4oYWxsU3VtQXJyTWF4LCAnbWF4JyksXHJcbiAgICAgICAgICAgICAgICBtaW46IHRoaXMuX2NoYXJ0U3ZjLmdldEQzTWF4T3JNaW4oYWxsU3VtQXJyTWluLCAnbWluJylcclxuICAgICAgICAgICAgfTtcclxuICAgICAgICAgICAgY2hhcnREYXRhWydoYXZlTmVnYXRpdmUnXSA9IGhhdmVOZWdhdGl2ZTtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIHRoaXMuZGF0YSA9IGNoYXJ0RGF0YTtcclxuICAgICAgICB0aGlzLmNoYXJ0SGlkZSA9IHRoaXMuY2hhcnRUeXBlWzFdID09PSAnMTAwJyAmJiBoYXZlTmVnYXRpdmU7XHJcbiAgICAgICAgdGhpcy5fc2V0Q29uZmlnKHRoaXMuY29uZmlnKTtcclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF9kYXRhTWFzc2FnZUZvclBpZShfZGF0YSkge1xyXG4gICAgICAgIGlmIChfZGF0YSAhPT0gdW5kZWZpbmVkICYmIF9kYXRhICE9PSBudWxsKSB7XHJcbiAgICAgICAgICAgIGxldCBjaGFydERhdGE6IElEM0RhdGEgPSB7XHJcbiAgICAgICAgICAgICAgICAndHlwZSc6IF9kYXRhLmNoYXJ0Wyd0eXBlJ10gPyBfZGF0YS5jaGFydFsndHlwZSddIDogbnVsbCxcclxuICAgICAgICAgICAgICAgICdsYXlvdXQnOiBfZGF0YS5jaGFydFsnbGF5b3V0J10gPyBfZGF0YS5jaGFydFsnbGF5b3V0J10gOiBudWxsLFxyXG4gICAgICAgICAgICAgICAgJ2NvbmZpZyc6IHRoaXMuY29uZmlnLnBsb3RPcHRpb25zICYmIHRoaXMuY29uZmlnLnBsb3RPcHRpb25zLmhhc093blByb3BlcnR5KF9kYXRhLmNoYXJ0Wyd0eXBlJ10pID8gdGhpcy5jb25maWcucGxvdE9wdGlvbnNbX2RhdGEuY2hhcnRbJ3R5cGUnXV0gOiB7fSxcclxuICAgICAgICAgICAgICAgICdkYXRhJzogW11cclxuICAgICAgICAgICAgfTtcclxuICAgICAgICAgICAgbGV0IHJldHVyblBhcmFtcyA9IHRoaXMuX2NoYXJ0U3ZjLnNpbmdsZVBpZURhdGFNYXNzYWdlKHRoaXMubGVnZW5kRGF0YSwgX2RhdGEsIHRoaXMuY29uZmlnLCB0aGlzLnNlcmllc1RocmVzaG9sZCk7XHJcbiAgICAgICAgICAgIGNoYXJ0RGF0YVsncGllZGF0YSddID0gcmV0dXJuUGFyYW1zLnBpZURhdGE7XHJcbiAgICAgICAgICAgIHRoaXMuZGF0YSA9IGNoYXJ0RGF0YTtcclxuICAgICAgICAgICAgdGhpcy5jb25maWdbJ3BpZUNvbG9yJ10gPSByZXR1cm5QYXJhbXMucGllQ29sb3I7XHJcbiAgICAgICAgICAgIHRoaXMubGVnZW5kRGF0YSA9IHJldHVyblBhcmFtcy5sZWdlbmREYXRhO1xyXG4gICAgICAgICAgICAvLyB0aGlzLm91dHB1dERhdGEuZW1pdCh0aGlzLmRhdGEpO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF9kYXRhTWFzc2FnZUZvck1hcChfZGF0YSk6IHZvaWQge1xyXG4gICAgICAgIHRoaXMuZGF0YSA9IF9kYXRhO1xyXG4gICAgICAgIHRoaXMuX3NldExlZ2VuZEZvck1hcCgpO1xyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX3NldExlZ2VuZEZvck1hcCgpOiB2b2lkIHtcclxuICAgICAgICBsZXQgc2VyaWVzRGF0YTogYW55O1xyXG4gICAgICAgIGlmICh0aGlzLmRhdGFbJ21hcFNlcmllc0RhdGEnXSAmJiB0aGlzLmNvbmZpZy5za2lwTWFzc2FnZSkge1xyXG4gICAgICAgICAgICBzZXJpZXNEYXRhID0gSlNPTi5wYXJzZShKU09OLnN0cmluZ2lmeSh0aGlzLmRhdGFbJ21hcFNlcmllc0RhdGEnXSkpO1xyXG4gICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgIHNlcmllc0RhdGEgPSBKU09OLnBhcnNlKEpTT04uc3RyaW5naWZ5KHRoaXMuZGF0YVsnc2VyaWVzJ10pKTtcclxuICAgICAgICAgICAgZm9yIChsZXQgaSA9IDA7IGkgPCBzZXJpZXNEYXRhLmxlbmd0aDsgaSsrKSB7XHJcbiAgICAgICAgICAgICAgICBzZXJpZXNEYXRhW2ldWydkZWFjdGl2ZSddID0gZmFsc2U7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICAgICAgdGhpcy5jaGVja01hcFNjYWxlID0gZmFsc2U7XHJcbiAgICAgICAgaWYgKCF0aGlzLmNvbmZpZy5za2lwTWFzc2FnZSkge1xyXG4gICAgICAgICAgICBpZiAodGhpcy5jb25maWcuY29sb3JBeGlzICE9IHVuZGVmaW5lZCkge1xyXG4gICAgICAgICAgICAgICAgaWYgKHRoaXMuY29uZmlnLmNvbG9yQXhpcy5kYXRhQ2xhc3NlcyAmJiB0aGlzLmNvbmZpZy5jb2xvckF4aXMuZGF0YUNsYXNzZXMubGVuZ3RoICE9IDApIHtcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLmxlZ2VuZERhdGEgPSB0aGlzLl9jaGFydFN2Yy5zZXRTaW5nbGVMZWdlbmRMZXZlbHModGhpcy5jb25maWcuY29sb3JBeGlzLmRhdGFDbGFzc2VzLCB0aGlzLmNvbmZpZy5sZWdlbmQudmFsdWVEZWNpbWFscywgdGhpcy5jb25maWcubGVnZW5kLnZhbHVlU3VmZml4KTtcclxuICAgICAgICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5jaGVja01hcFNjYWxlID0gdHJ1ZTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgICAgIHRoaXMubGVnZW5kRGF0YSA9IHRoaXMuX2NoYXJ0U3ZjLnNldE1hcExlZ2VuZERhdGEodGhpcy5sZWdlbmREYXRhLCBzZXJpZXNEYXRhLCB0aGlzLmNvbmZpZyk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICAvLyBvdXRwdXQgbGVnZW5kIG9ubHkgZm9yIGV4cG9ydGluZ1xyXG4gICAgICAgICAgICBpZiAodGhpcy5jb25maWcuY29sb3JBeGlzICE9IHVuZGVmaW5lZCkge1xyXG4gICAgICAgICAgICAgICAgaWYgKHRoaXMuY29uZmlnLmNvbG9yQXhpcy5kYXRhQ2xhc3NlcyAmJiB0aGlzLmNvbmZpZy5jb2xvckF4aXMuZGF0YUNsYXNzZXMubGVuZ3RoICE9IDApIHtcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLmxlZ2VuZERhdGEgPSB0aGlzLl9jaGFydFN2Yy5zZXRNYXBMZWdlbmREYXRhKHRoaXMubGVnZW5kRGF0YSwgc2VyaWVzRGF0YSwgdGhpcy5jb25maWcpO1xyXG4gICAgICAgICAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLmNoZWNrTWFwU2NhbGUgPSB0cnVlO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5sZWdlbmREYXRhID0gdGhpcy5fY2hhcnRTdmMuc2V0TWFwTGVnZW5kRGF0YSh0aGlzLmxlZ2VuZERhdGEsIHNlcmllc0RhdGEsIHRoaXMuY29uZmlnKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF9nZXRUb3RhbFN1bShfZGF0YTogSUNoYXJ0RGF0YSwgc2VyaWVzTGVuZ3RoOiBudW1iZXIpOiBBcnJheTxudW1iZXI+IHwgb2JqZWN0IHtcclxuICAgICAgICBpZiAodGhpcy5jaGFydFR5cGVbMV0gPT09ICcxMDAnKSB7XHJcbiAgICAgICAgICAgIHJldHVybiB0aGlzLl9jaGFydFN2Yy5nZXRUb3RhbFN1bUFyckZyb21TZXJpZXMoX2RhdGEuc2VyaWVzLCBfZGF0YS54QXhpcy5jYXRlZ29yaWVzLCBzZXJpZXNMZW5ndGgpO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF9nZXRDb25maWcoX2VsZW1lbnQ6IGFueSwgX3Nlcmllc0luZGV4OiBudW1iZXIsIF9kYXRhOiBJU2VyaWVzRGF0YSk6IHN0cmluZyB7XHJcblxyXG4gICAgICAgIGlmICghdGhpcy5fY2hhcnRTdmMuaXNFeGlzdChfZGF0YSkpIHJldHVybjtcclxuXHJcbiAgICAgICAgaWYgKF9kYXRhLmhhc093blByb3BlcnR5KF9lbGVtZW50KSAmJiBfZGF0YVtfZWxlbWVudF0gIT09IHVuZGVmaW5lZCkge1xyXG4gICAgICAgICAgICByZXR1cm4gX2RhdGFbX2VsZW1lbnRdO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgbGV0IGNvbmZpZzogc3RyaW5nID0gdGhpcy5fZ2V0TGVnZW5kQ29uZmlnKF9lbGVtZW50LCBfc2VyaWVzSW5kZXgpO1xyXG4gICAgICAgIHJldHVybiBjb25maWc7XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfZ2V0TGVnZW5kQ29uZmlnKF9lbGVtZW50OiBhbnksIF9zZXJpZXNJbmRleDogbnVtYmVyKTogc3RyaW5nIHtcclxuICAgICAgICBpZiAoX2VsZW1lbnQgPT09ICdzaGFwZScgJiZcclxuICAgICAgICAgICAgKHRoaXMuY2hhcnREYXRhLmNoYXJ0LnR5cGUgPT09ICdwaWUnIHx8IHRoaXMuY2hhcnREYXRhLmNoYXJ0LnR5cGUgPT09ICdiYXInKSkge1xyXG4gICAgICAgICAgICByZXR1cm4gJ2NpcmNsZSc7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICBsZXQgZGVmYXVsdENvbmZpZzogc3RyaW5nID0gdGhpcy5fZ2V0RGVmYXVsdENvbmZpZyhfZWxlbWVudCwgX3Nlcmllc0luZGV4KTtcclxuICAgICAgICBsZXQgY29uZmlnOiBzdHJpbmc7XHJcbiAgICAgICAgaWYgKHRoaXMuY2hhcnRDYXRlZ29yeSA9PSAncGllJykge1xyXG4gICAgICAgICAgICBjb25maWcgPSBkZWZhdWx0Q29uZmlnO1xyXG4gICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgIGNvbmZpZyA9IHRoaXMuY2hhcnREYXRhLnNlcmllc1tfc2VyaWVzSW5kZXhdW19lbGVtZW50XSB8fCBkZWZhdWx0Q29uZmlnO1xyXG4gICAgICAgIH1cclxuICAgICAgICByZXR1cm4gY29uZmlnO1xyXG4gICAgfVxyXG5cclxuICAgIHB1YmxpYyBfZ2V0RGVmYXVsdENvbmZpZyhfZWxlbWVudDogYW55LCBfc2VyaWVzSW5kZXg/OiBudW1iZXIpOiBzdHJpbmcge1xyXG4gICAgICAgIGlmIChfZWxlbWVudCA9PT0gJ3NoYXBlJykgcmV0dXJuICdjaXJjbGUnO1xyXG5cclxuICAgICAgICBpZiAoX3Nlcmllc0luZGV4IHx8IF9zZXJpZXNJbmRleCA9PT0gMCkge1xyXG4gICAgICAgICAgICByZXR1cm4gdGhpcy5jb25maWcuY29sb3JzW19zZXJpZXNJbmRleF07XHJcbiAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgdGhpcy5fY29sb3JMaXN0UG9zaXRpb24rKztcclxuICAgICAgICAgICAgcmV0dXJuIHRoaXMuY29uZmlnLmNvbG9yc1t0aGlzLl9jb2xvckxpc3RQb3NpdGlvbiAtIDFdO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICBwdWJsaWMgZ2V0T3V0cHV0TWFya2VyKF9kYXRhOiBhbnkpOiB2b2lkIHtcclxuICAgICAgICB0aGlzLm1hcmtlcnNMZWdlbmQgPSBfZGF0YTtcclxuICAgIH1cclxufVxyXG4iXX0=