import { Component, ViewEncapsulation, Input } from '@angular/core';
import { KdChartBaseClass } from '../kd-angular-chart-base-class';
import { KdChartsSvc } from '../kd-angular-charts-svc';
import { KdDomElemSvc } from '../../kd-common/index';
import { KdBarChartSvc } from './kd-angular-bar-chart-svc';
export class KdBarChart extends KdChartBaseClass {
    constructor(_chartSvc, _domSvc, _barSvc) {
        super(_chartSvc, _domSvc);
        this._chartSvc = _chartSvc;
        this._domSvc = _domSvc;
        this._barSvc = _barSvc;
        this._isStartAtSum = false;
    }
    ngOnInit() {
        this._redrawChart(true, { data: this.allData, config: this.barConfig });
        this.api.legendClick = (_data) => {
            this._redrawChart(false, { data: _data });
        };
        this.api.redraw = () => {
            clearTimeout(this._resizeTimeout);
            this._resizeTimeout = setTimeout(() => {
                this._redrawChart(false, {});
            });
        };
    }
    ngOnChanges(_simpleChanges) {
        if (_simpleChanges.hasOwnProperty('allData') && !_simpleChanges['allData'].firstChange) {
            this._redrawChart(false, { data: _simpleChanges.allData.currentValue });
        }
        if (_simpleChanges.hasOwnProperty('barConfig') && !_simpleChanges['barConfig'].firstChange) {
            this._redrawChart(false, { config: _simpleChanges.barConfig.currentValue });
        }
    }
    ngOnDestroy() {
        this._resetChart();
    }
    _redrawChart(isFirstChange, _changes = {}) {
        if (!isFirstChange) {
            this._resetChart();
        }
        this.legendData = Object.assign({}, this.legend);
        if (_changes.hasOwnProperty('data'))
            this._setData(_changes.data);
        if (_changes.hasOwnProperty('config'))
            this._setConfig(_changes.config);
        super.chartTimeout(() => this._setChart());
    }
    _setData(_data) {
        this.data = Object.assign([], _data.data);
        // saving original data somewhere before trimming this.data. when no trimming, then this.data will just be initData
        this.initData = JSON.parse(JSON.stringify(this.data));
        this.chartCategory = 'bar';
        this.chartType = _data.layout.split('-');
        this._chartSvc.isInvert = this.chartType[0] === 'bar';
        this.bar.isInvert = this.chartType[0] === 'bar';
        this._chartSvc.isNegativeStack = this.chartType[1] === 'stack' && this.chartType[2] === 'negative';
        // range and negative flag calculated by kdChart, used in domain, recalculated when change graph type and legend
        this.dataRange = _data.range;
        this.haveNegative = _data.haveNegative;
        this._barSvc.originalDataRange = _data.range;
    }
    _setConfig(_config) {
        this.config = Object.assign({}, _config);
    }
    _setChart() {
        if (this.chartType[1] === '100' && this.haveNegative)
            return;
        if (this._chartSvc.isNegativeStack)
            this.negativeStackSymmetryLogic();
        super.setSvg();
        super.setDomain('band');
        this._drawChart();
    }
    _resetChart() {
        super.removeChart();
        if (this._barGraph) {
            this._barGraph.remove();
            this._barGraph = null;
        }
    }
    _drawChartContainer() {
        this._barGraph = this.graph.append('g').attr('class', 'bar-graph-container');
        this._barGraph.attr('clip-path', 'url(#kd-charts-clip-path-' + this.config.id + ')');
    }
    _drawChart() {
        if (!this._barGraph)
            this._drawChartContainer();
        this._isStartAtSum = this.bar.isInvert === this._chartSvc.isYReversed;
        let rectPosInfo = this._getRectPosInfo();
        this.data.forEach((d, i) => {
            let groups = this._setRectGroup(d, i, d.y, this._barGraph, rectPosInfo);
            super._initMouseEvents(groups.rectGroup, { data: d, index: i });
            if (this.config.chart.labels.enabled) {
                this._setBarChartLabel(d, i, groups);
                if (this.config.animation) {
                    groups.rectGroupTransite.on('end', (yData, yIndex) => {
                        // when the last rect transite ends
                        if ((yData.xIndex === this.data.length - 1)
                            && (yIndex === this.data[this.data.length - 1].y.length - 1)) {
                            this._displayAllLabel();
                        }
                    });
                }
                else {
                    this._displayAllLabel();
                }
            }
        });
    }
    _setRectGroup(_d, _xIndex, _yDataArr, _container, _rectPosInfo) {
        let rectGroup = _container.selectAll('rectGroup')
            .data(_yDataArr, (d) => { d['xIndex'] = _xIndex; return d; })
            .enter()
            .append('rect');
        let offset = 0, rectGroupTransite, xPosArr = [], yPosArr = [], widthArr = [], heightArr = [];
        rectGroup
            .attr('class', (yData) => 'bar x-' + _xIndex + ' y-' + yData.id)
            .attr('fill', (yData, yIndex) => this.legend.hasOwnProperty(yData.id) ? this.legend[yData.id].color || '' : '')
            .attr('aria-x-value', _d.x.value)
            .attr('aria-y-value', (yData) => yData.sum);
        if (this.chartType[0] === 'column') {
            rectGroup
                .attr('width', pushAndReturn(widthArr, _rectPosInfo.width))
                .attr('x', (yData, yIndex) => {
                if (this.chartType[1] === 'cluster')
                    offset = _rectPosInfo.width * yIndex + _rectPosInfo.padding * yIndex;
                return pushAndReturn(xPosArr, this.x(_d.x.value) + offset);
            });
            if (!this.config.animation) {
                rectGroup
                    .attr('y', (yData) => pushAndReturn(yPosArr, this._getVal('y', yData)))
                    .attr('height', (yData) => pushAndReturn(heightArr, this._getVal('height', yData)));
            }
            else {
                rectGroup
                    .attr('y', this.y(0))
                    .attr('height', 0);
                rectGroupTransite = rectGroup.transition().duration(this.lengthOfTransition)
                    .attr('y', (yData) => pushAndReturn(yPosArr, this._getVal('y', yData)))
                    .attr('height', (yData) => pushAndReturn(heightArr, this._getVal('height', yData)));
            }
        }
        else {
            rectGroup
                .attr('height', pushAndReturn(heightArr, _rectPosInfo.width))
                .attr('y', (yData, yIndex) => {
                if (this.chartType[1] === 'cluster')
                    offset = _rectPosInfo.width * yIndex + _rectPosInfo.padding * yIndex;
                return pushAndReturn(yPosArr, this.x(_d.x.value) + offset);
            });
            if (!this.config.animation) {
                rectGroup
                    .attr('x', (yData) => pushAndReturn(xPosArr, this._getVal('x', yData)))
                    .attr('width', (yData) => pushAndReturn(widthArr, this._getVal('width', yData)));
            }
            else {
                rectGroup
                    .attr('x', this.y(0))
                    .attr('width', 0);
                rectGroupTransite = rectGroup.transition().duration(this.lengthOfTransition)
                    .attr('x', (yData) => pushAndReturn(xPosArr, this._getVal('x', yData)))
                    .attr('width', (yData) => pushAndReturn(widthArr, this._getVal('width', yData)));
            }
        }
        return {
            rectGroup: rectGroup,
            rectGroupTransite: rectGroupTransite,
            xPosArr: xPosArr,
            yPosArr: yPosArr,
            widthArr: widthArr,
            heightArr: heightArr
        };
        function pushAndReturn(target, value) {
            target.push(value);
            return value;
        }
    }
    _getVal(_type, _yData) {
        let value = this.chartType[1] === '100' ? _yData.renderVal : _yData.value;
        let offset = value ? 1 : 0;
        if (_type === 'x' || _type === 'y') {
            return this._isStartAtSum ? this.y(negativeRecal(_yData.sum, value)) : this.y(negativeRecal(_yData.sum, value) - Math.abs(value));
        }
        if (_type === 'height')
            return Math.abs(this.y(negativeRecal(_yData.sum, value) - value) - this.y(negativeRecal(_yData.sum, value))) + offset;
        if (_type === 'width')
            return Math.abs(this.y(negativeRecal(_yData.sum, value)) - this.y(negativeRecal(_yData.sum, value) - value)) + offset;
        // rendering rect for negative uses values lesser by one index. eg: first value = -2, sum = -2, renders 0.... second value = -4, sum = -6, renders -2
        function negativeRecal(_sum, _value) {
            return Math.sign(_sum) < 0 ? _sum - _value : _sum;
        }
    }
    _setBarChartLabel(_d, _xIndex, _group) {
        for (let yIndex = 0; yIndex < _d.y.length; ++yIndex) {
            if (_d.y[yIndex].value === null)
                continue;
            let yData = Object.assign({}, _d.y[yIndex]), dimensions = {
                yPos: _group.yPosArr[yIndex],
                xPos: _group.xPosArr[yIndex],
                height: this.chartType[0] === 'column' ? _group.heightArr[yIndex] : _group.heightArr[0],
                width: this.chartType[0] === 'column' ? _group.widthArr[0] : _group.widthArr[yIndex]
            };
            if (!this.config.chart.labels.inside) {
                if (this.chartType[0] === 'column') {
                    if ((yData.value < 0 && !this._chartSvc.isYReversed) || (yData.value > 0 && this._chartSvc.isYReversed)) {
                        dimensions.yPos += _group.heightArr[yIndex];
                    }
                    // when rtl, div starts at top right of rect
                    if (this.isRtl)
                        dimensions.xPos += _group.widthArr[0];
                }
                else {
                    if ((yData.value > 0 && !this._chartSvc.isYReversed) || (yData.value < 0 && this._chartSvc.isYReversed)) {
                        dimensions.xPos += _group.widthArr[yIndex];
                    }
                }
            }
            else {
                if (this.isRtl) {
                    // when rtl,
                    // for Column, div starts at top right of rect
                    // for Bar, div start at end of rect and take the width of bars
                    let index = this.chartType[0] === 'column' ? 0 : yIndex;
                    dimensions.xPos += _group.widthArr[index];
                }
            }
            if (this._chartSvc.isNegativeStack)
                yData.value = this._chartSvc.checkAndReturnLabelsPositive(yData.value);
            let labelContainer = super.setLabel(yData, _xIndex, dimensions.xPos, dimensions.yPos);
            // value here is rawValue (negativeStackBar may have changed yData.value)
            this._setLabelStyle(labelContainer, _d.y[yIndex].value, dimensions);
        }
    }
    // for column, width is constant, height is vary
    // for bar, height is constant, width is vary
    _setLabelStyle(_labelContainer, _value, _dimensions) {
        let labelText = _labelContainer.select('.kdx-charts-data-label-text');
        let verticalAlign = this.config.chart.labels.verticalAlign;
        let inside = this.config.chart.labels.inside;
        let sign = Math.sign(_value);
        if (!verticalAlign)
            verticalAlign = this.chartType[0] === 'column' ? 'top' : 'middle';
        this._barSvc.setLabelContainerWidthOrHeight(_labelContainer, this.chartType[0], inside, _dimensions);
        // if label is higher than bar's/column's height
        let isLabelHigherThanRect = this._chartSvc._getLabelTextHeight() > _dimensions.height;
        if (isLabelHigherThanRect) {
            if (this.chartType[0] === 'bar') {
                verticalAlign = 'middle';
            }
            else if (inside) {
                // if column and inside, to make sure label will not hit into axis,
                // if axis is at bottom of chart, set to flex-end so that text will be placed above
                // if axis is at top of chart, set to flex-start so that text will be placed below
                verticalAlign = this._chartSvc.isYReversed ? 'top' : 'bottom';
            }
        }
        if (!inside) {
            if (this.chartType[0] === 'bar') {
                this._barSvc._setLabelTextPosHorizontal(labelText, this._chartSvc.isYReversed, { xPos: _dimensions.xPos, chartWidth: this.width, valueSign: sign });
            }
            else {
                let params = { valueSign: sign };
                let yPos = _dimensions.yPos; // used for boundary checking.
                if (isLabelHigherThanRect && this.chartType[1] === 'cluster') {
                    params['dimensions'] = _dimensions;
                    let needOffset = this._chartSvc.needOffsetForColumn(verticalAlign, params);
                    if (needOffset)
                        yPos += needOffset * _dimensions.height;
                }
                super.setLabelTextPosition(labelText, yPos, params);
            }
        }
        this._barSvc.setVerticalAlignCSS(_labelContainer, verticalAlign);
    }
    _displayAllLabel() {
        this.dataLabelContainer
            .selectAll('.kdx-charts-data-label')
            .style('visibility', 'visible');
    }
    _getRectPosInfo() {
        if (this.chartType[1] === 'cluster') {
            // the amount of yData for each x value will always be the same (if we don't remove null values)
            // hence this calculation only needs to run once
            let yArrLength = this.data[0] && this.data[0].y ? this.data[0].y.length : 0;
            return this._barSvc.getRectWidth(this.x.bandwidth(), this.bar.clusterPaddingPercent, yArrLength);
        }
        return {
            width: this.x.bandwidth(),
            padding: 0
        };
    }
    negativeStackSymmetryLogic() {
        let result = this._barSvc.applySymmetricAxis(this.dataRange, this.config.plotOptions, this.config.yAxis);
        if (result.hasOwnProperty('dataRange'))
            this.dataRange = result.dataRange;
        if (result.hasOwnProperty('yAxis')) {
            this.config.yAxis = Object.assign({}, this.config.yAxis, result.yAxis);
        }
    }
}
KdBarChart.decorators = [
    { type: Component, args: [{
                selector: 'kd-bar-chart',
                template: `
        <div *ngIf="chartType[1] === '100' && haveNegative" class="kdx-charts-error-msg">
            {{errorMsg}}
        </div>
    `,
                encapsulation: ViewEncapsulation.None,
                providers: [KdChartsSvc, KdDomElemSvc, KdBarChartSvc],
                host: {
                    'class': 'kdx-bar-chart',
                }
            },] }
];
KdBarChart.ctorParameters = () => [
    { type: KdChartsSvc },
    { type: KdDomElemSvc },
    { type: KdBarChartSvc }
];
KdBarChart.propDecorators = {
    allData: [{ type: Input, args: ['data',] }],
    barConfig: [{ type: Input, args: ['config',] }],
    legend: [{ type: Input }],
    api: [{ type: Input }]
};
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoia2QtYW5ndWxhci1iYXItY2hhcnQuanMiLCJzb3VyY2VSb290IjoiQzoveGFtcHAvaHRkb2NzL1N0eWxlZ3VpZGUvaW9zdGctb3BlbmVtaXMtc3R5bGVndWlkZS9wcm9qZWN0cy9vcGVuZW1pcy1zdHlsZWd1aWRlLWxpYi9zcmMvIiwic291cmNlcyI6WyJrZC1jb21wb25lbnRzL2tkLWFuZ3VsYXItY2hhcnRzL2tkLWFuZ3VsYXItYmFyLWNoYXJ0L2tkLWFuZ3VsYXItYmFyLWNoYXJ0LnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBLE9BQU8sRUFDSCxTQUFTLEVBQ1QsaUJBQWlCLEVBQ2pCLEtBQUssRUFLUixNQUFNLGVBQWUsQ0FBQztBQUN2QixPQUFPLEVBQUUsZ0JBQWdCLEVBQUUsTUFBTSxnQ0FBZ0MsQ0FBQztBQUNsRSxPQUFPLEVBQUUsV0FBVyxFQUFFLE1BQU0sMEJBQTBCLENBQUM7QUFHdkQsT0FBTyxFQUFFLFlBQVksRUFBRSxNQUFNLHVCQUF1QixDQUFDO0FBQ3JELE9BQU8sRUFBRSxhQUFhLEVBQUUsTUFBTSw0QkFBNEIsQ0FBQztBQWdCM0QsTUFBTSxPQUFPLFVBQVcsU0FBUSxnQkFBZ0I7SUFXNUMsWUFDVyxTQUFzQixFQUN0QixPQUFxQixFQUNyQixPQUFzQjtRQUU3QixLQUFLLENBQUMsU0FBUyxFQUFFLE9BQU8sQ0FBQyxDQUFDO1FBSm5CLGNBQVMsR0FBVCxTQUFTLENBQWE7UUFDdEIsWUFBTyxHQUFQLE9BQU8sQ0FBYztRQUNyQixZQUFPLEdBQVAsT0FBTyxDQUFlO1FBVnpCLGtCQUFhLEdBQVksS0FBSyxDQUFDO0lBYXZDLENBQUM7SUFFRCxRQUFRO1FBQ0osSUFBSSxDQUFDLFlBQVksQ0FBQyxJQUFJLEVBQUUsRUFBRSxJQUFJLEVBQUUsSUFBSSxDQUFDLE9BQU8sRUFBRSxNQUFNLEVBQUUsSUFBSSxDQUFDLFNBQVMsRUFBRSxDQUFDLENBQUM7UUFDeEUsSUFBSSxDQUFDLEdBQUcsQ0FBQyxXQUFXLEdBQUcsQ0FBQyxLQUFVLEVBQUUsRUFBRTtZQUNsQyxJQUFJLENBQUMsWUFBWSxDQUFDLEtBQUssRUFBRSxFQUFFLElBQUksRUFBRSxLQUFLLEVBQUUsQ0FBQyxDQUFDO1FBQzlDLENBQUMsQ0FBQztRQUNGLElBQUksQ0FBQyxHQUFHLENBQUMsTUFBTSxHQUFHLEdBQUcsRUFBRTtZQUNuQixZQUFZLENBQUMsSUFBSSxDQUFDLGNBQWMsQ0FBQyxDQUFDO1lBQ2xDLElBQUksQ0FBQyxjQUFjLEdBQUcsVUFBVSxDQUFDLEdBQUcsRUFBRTtnQkFDbEMsSUFBSSxDQUFDLFlBQVksQ0FBQyxLQUFLLEVBQUUsRUFBRSxDQUFDLENBQUM7WUFDakMsQ0FBQyxDQUFDLENBQUM7UUFDUCxDQUFDLENBQUM7SUFDTixDQUFDO0lBRUQsV0FBVyxDQUFDLGNBQTZCO1FBQ3JDLElBQUksY0FBYyxDQUFDLGNBQWMsQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDLGNBQWMsQ0FBQyxTQUFTLENBQUMsQ0FBQyxXQUFXLEVBQUU7WUFDcEYsSUFBSSxDQUFDLFlBQVksQ0FBQyxLQUFLLEVBQUUsRUFBRSxJQUFJLEVBQUUsY0FBYyxDQUFDLE9BQU8sQ0FBQyxZQUFZLEVBQUUsQ0FBQyxDQUFDO1NBQzNFO1FBQ0QsSUFBSSxjQUFjLENBQUMsY0FBYyxDQUFDLFdBQVcsQ0FBQyxJQUFJLENBQUMsY0FBYyxDQUFDLFdBQVcsQ0FBQyxDQUFDLFdBQVcsRUFBRTtZQUN4RixJQUFJLENBQUMsWUFBWSxDQUFDLEtBQUssRUFBRSxFQUFFLE1BQU0sRUFBRSxjQUFjLENBQUMsU0FBUyxDQUFDLFlBQVksRUFBRSxDQUFDLENBQUM7U0FDL0U7SUFDTCxDQUFDO0lBRUQsV0FBVztRQUNQLElBQUksQ0FBQyxXQUFXLEVBQUUsQ0FBQztJQUN2QixDQUFDO0lBRU8sWUFBWSxDQUFDLGFBQXNCLEVBQUUsV0FBc0QsRUFBRTtRQUNqRyxJQUFJLENBQUMsYUFBYSxFQUFFO1lBQ2hCLElBQUksQ0FBQyxXQUFXLEVBQUUsQ0FBQztTQUN0QjtRQUNELElBQUksQ0FBQyxVQUFVLEdBQUcsTUFBTSxDQUFDLE1BQU0sQ0FBQyxFQUFFLEVBQUUsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDO1FBQ2pELElBQUksUUFBUSxDQUFDLGNBQWMsQ0FBQyxNQUFNLENBQUM7WUFBRSxJQUFJLENBQUMsUUFBUSxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsQ0FBQztRQUNsRSxJQUFJLFFBQVEsQ0FBQyxjQUFjLENBQUMsUUFBUSxDQUFDO1lBQUUsSUFBSSxDQUFDLFVBQVUsQ0FBQyxRQUFRLENBQUMsTUFBTSxDQUFDLENBQUM7UUFDeEUsS0FBSyxDQUFDLFlBQVksQ0FBQyxHQUFHLEVBQUUsQ0FBQyxJQUFJLENBQUMsU0FBUyxFQUFFLENBQUMsQ0FBQztJQUMvQyxDQUFDO0lBRU8sUUFBUSxDQUFDLEtBQWM7UUFDM0IsSUFBSSxDQUFDLElBQUksR0FBRyxNQUFNLENBQUMsTUFBTSxDQUFDLEVBQUUsRUFBRSxLQUFLLENBQUMsSUFBSSxDQUFDLENBQUM7UUFDMUMsbUhBQW1IO1FBQ25ILElBQUksQ0FBQyxRQUFRLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDO1FBRXRELElBQUksQ0FBQyxhQUFhLEdBQUcsS0FBSyxDQUFDO1FBQzNCLElBQUksQ0FBQyxTQUFTLEdBQUcsS0FBSyxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLENBQUM7UUFDekMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxRQUFRLEdBQUcsSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsS0FBSyxLQUFLLENBQUM7UUFDdEQsSUFBSSxDQUFDLEdBQUcsQ0FBQyxRQUFRLEdBQUcsSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsS0FBSyxLQUFLLENBQUM7UUFDaEQsSUFBSSxDQUFDLFNBQVMsQ0FBQyxlQUFlLEdBQUcsSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsS0FBSyxPQUFPLElBQUksSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsS0FBSyxVQUFVLENBQUM7UUFFbkcsZ0hBQWdIO1FBQ2hILElBQUksQ0FBQyxTQUFTLEdBQUcsS0FBSyxDQUFDLEtBQUssQ0FBQztRQUM3QixJQUFJLENBQUMsWUFBWSxHQUFHLEtBQUssQ0FBQyxZQUFZLENBQUM7UUFDdkMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxpQkFBaUIsR0FBRyxLQUFLLENBQUMsS0FBSyxDQUFDO0lBQ2pELENBQUM7SUFFTyxVQUFVLENBQUMsT0FBcUI7UUFDcEMsSUFBSSxDQUFDLE1BQU0sR0FBRyxNQUFNLENBQUMsTUFBTSxDQUFDLEVBQUUsRUFBRSxPQUFPLENBQUMsQ0FBQztJQUM3QyxDQUFDO0lBRU8sU0FBUztRQUNiLElBQUksSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsS0FBSyxLQUFLLElBQUksSUFBSSxDQUFDLFlBQVk7WUFBRSxPQUFPO1FBQzdELElBQUksSUFBSSxDQUFDLFNBQVMsQ0FBQyxlQUFlO1lBQUUsSUFBSSxDQUFDLDBCQUEwQixFQUFFLENBQUM7UUFDdEUsS0FBSyxDQUFDLE1BQU0sRUFBRSxDQUFDO1FBQ2YsS0FBSyxDQUFDLFNBQVMsQ0FBQyxNQUFNLENBQUMsQ0FBQztRQUN4QixJQUFJLENBQUMsVUFBVSxFQUFFLENBQUM7SUFDdEIsQ0FBQztJQUVPLFdBQVc7UUFDZixLQUFLLENBQUMsV0FBVyxFQUFFLENBQUM7UUFDcEIsSUFBSSxJQUFJLENBQUMsU0FBUyxFQUFFO1lBQ2hCLElBQUksQ0FBQyxTQUFTLENBQUMsTUFBTSxFQUFFLENBQUM7WUFDeEIsSUFBSSxDQUFDLFNBQVMsR0FBRyxJQUFJLENBQUM7U0FDekI7SUFDTCxDQUFDO0lBRU8sbUJBQW1CO1FBQ3ZCLElBQUksQ0FBQyxTQUFTLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDLE9BQU8sRUFBRSxxQkFBcUIsQ0FBQyxDQUFDO1FBQzdFLElBQUksQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDLFdBQVcsRUFBRSwyQkFBMkIsR0FBRyxJQUFJLENBQUMsTUFBTSxDQUFDLEVBQUUsR0FBRyxHQUFHLENBQUMsQ0FBQztJQUN6RixDQUFDO0lBRU8sVUFBVTtRQUNkLElBQUksQ0FBQyxJQUFJLENBQUMsU0FBUztZQUFFLElBQUksQ0FBQyxtQkFBbUIsRUFBRSxDQUFDO1FBRWhELElBQUksQ0FBQyxhQUFhLEdBQUcsSUFBSSxDQUFDLEdBQUcsQ0FBQyxRQUFRLEtBQUssSUFBSSxDQUFDLFNBQVMsQ0FBQyxXQUFXLENBQUM7UUFFdEUsSUFBSSxXQUFXLEdBQXVDLElBQUksQ0FBQyxlQUFlLEVBQUUsQ0FBQztRQUU3RSxJQUFJLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQWMsRUFBRSxDQUFTLEVBQUUsRUFBRTtZQUM1QyxJQUFJLE1BQU0sR0FBZSxJQUFJLENBQUMsYUFBYSxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsRUFBRSxJQUFJLENBQUMsU0FBUyxFQUFFLFdBQVcsQ0FBQyxDQUFDO1lBRXBGLEtBQUssQ0FBQyxnQkFBZ0IsQ0FBQyxNQUFNLENBQUMsU0FBUyxFQUFFLEVBQUUsSUFBSSxFQUFFLENBQUMsRUFBRSxLQUFLLEVBQUUsQ0FBQyxFQUFFLENBQUMsQ0FBQztZQUVoRSxJQUFJLElBQUksQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxPQUFPLEVBQUU7Z0JBQ2xDLElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLE1BQU0sQ0FBQyxDQUFDO2dCQUVyQyxJQUFJLElBQUksQ0FBQyxNQUFNLENBQUMsU0FBUyxFQUFFO29CQUN2QixNQUFNLENBQUMsaUJBQWlCLENBQUMsRUFBRSxDQUFDLEtBQUssRUFBRSxDQUFDLEtBQUssRUFBRSxNQUFNLEVBQUUsRUFBRTt3QkFDakQsbUNBQW1DO3dCQUNuQyxJQUFJLENBQUMsS0FBSyxDQUFDLE1BQU0sS0FBSyxJQUFJLENBQUMsSUFBSSxDQUFDLE1BQU0sR0FBRyxDQUFDLENBQUM7K0JBQ3BDLENBQUMsTUFBTSxLQUFLLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxNQUFNLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sR0FBRyxDQUFDLENBQUMsRUFBRTs0QkFDOUQsSUFBSSxDQUFDLGdCQUFnQixFQUFFLENBQUM7eUJBQzNCO29CQUNMLENBQUMsQ0FBQyxDQUFDO2lCQUNOO3FCQUFNO29CQUNILElBQUksQ0FBQyxnQkFBZ0IsRUFBRSxDQUFDO2lCQUMzQjthQUVKO1FBQ0wsQ0FBQyxDQUFDLENBQUM7SUFDUCxDQUFDO0lBRU8sYUFBYSxDQUFDLEVBQWUsRUFBRSxPQUFlLEVBQUUsU0FBMEIsRUFBRSxVQUFlLEVBQUUsWUFBMEI7UUFDM0gsSUFBSSxTQUFTLEdBQUcsVUFBVSxDQUFDLFNBQVMsQ0FBQyxXQUFXLENBQUM7YUFDNUMsSUFBSSxDQUFDLFNBQVMsRUFBRSxDQUFDLENBQUMsRUFBRSxFQUFFLEdBQUcsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxHQUFHLE9BQU8sQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO2FBQzVELEtBQUssRUFBRTthQUNQLE1BQU0sQ0FBQyxNQUFNLENBQUMsQ0FBQztRQUNwQixJQUFJLE1BQU0sR0FBRyxDQUFDLEVBQUUsaUJBQXNCLEVBQUUsT0FBTyxHQUFrQixFQUFFLEVBQUUsT0FBTyxHQUFrQixFQUFFLEVBQUUsUUFBUSxHQUFrQixFQUFFLEVBQUUsU0FBUyxHQUFrQixFQUFFLENBQUM7UUFFOUosU0FBUzthQUNKLElBQUksQ0FBQyxPQUFPLEVBQUUsQ0FBQyxLQUFLLEVBQUUsRUFBRSxDQUFDLFFBQVEsR0FBRyxPQUFPLEdBQUcsS0FBSyxHQUFHLEtBQUssQ0FBQyxFQUFFLENBQUM7YUFDL0QsSUFBSSxDQUFDLE1BQU0sRUFBRSxDQUFDLEtBQUssRUFBRSxNQUFNLEVBQUUsRUFBRSxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsY0FBYyxDQUFDLEtBQUssQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsRUFBRSxDQUFDLENBQUMsS0FBSyxJQUFJLEVBQUUsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDO2FBQzlHLElBQUksQ0FBQyxjQUFjLEVBQUUsRUFBRSxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUM7YUFDaEMsSUFBSSxDQUFDLGNBQWMsRUFBRSxDQUFDLEtBQUssRUFBRSxFQUFFLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDO1FBRWhELElBQUksSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsS0FBSyxRQUFRLEVBQUU7WUFDaEMsU0FBUztpQkFDSixJQUFJLENBQUMsT0FBTyxFQUFFLGFBQWEsQ0FBQyxRQUFRLEVBQUUsWUFBWSxDQUFDLEtBQUssQ0FBQyxDQUFDO2lCQUMxRCxJQUFJLENBQUMsR0FBRyxFQUFFLENBQUMsS0FBSyxFQUFFLE1BQU0sRUFBRSxFQUFFO2dCQUN6QixJQUFJLElBQUksQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLEtBQUssU0FBUztvQkFBRSxNQUFNLEdBQUcsWUFBWSxDQUFDLEtBQUssR0FBRyxNQUFNLEdBQUcsWUFBWSxDQUFDLE9BQU8sR0FBRyxNQUFNLENBQUM7Z0JBQzFHLE9BQU8sYUFBYSxDQUFDLE9BQU8sRUFBRSxJQUFJLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLEdBQUcsTUFBTSxDQUFDLENBQUM7WUFDL0QsQ0FBQyxDQUFDLENBQUM7WUFFUCxJQUFJLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxTQUFTLEVBQUU7Z0JBQ3hCLFNBQVM7cUJBQ0osSUFBSSxDQUFDLEdBQUcsRUFBRSxDQUFDLEtBQUssRUFBRSxFQUFFLENBQUMsYUFBYSxDQUFDLE9BQU8sRUFBRSxJQUFJLENBQUMsT0FBTyxDQUFDLEdBQUcsRUFBRSxLQUFLLENBQUMsQ0FBQyxDQUFDO3FCQUN0RSxJQUFJLENBQUMsUUFBUSxFQUFFLENBQUMsS0FBSyxFQUFFLEVBQUUsQ0FBQyxhQUFhLENBQUMsU0FBUyxFQUFFLElBQUksQ0FBQyxPQUFPLENBQUMsUUFBUSxFQUFFLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQzthQUMzRjtpQkFBTTtnQkFDSCxTQUFTO3FCQUNKLElBQUksQ0FBQyxHQUFHLEVBQUUsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztxQkFDcEIsSUFBSSxDQUFDLFFBQVEsRUFBRSxDQUFDLENBQUMsQ0FBQztnQkFFdkIsaUJBQWlCLEdBQUcsU0FBUyxDQUFDLFVBQVUsRUFBRSxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsa0JBQWtCLENBQUM7cUJBQ3ZFLElBQUksQ0FBQyxHQUFHLEVBQUUsQ0FBQyxLQUFLLEVBQUUsRUFBRSxDQUFDLGFBQWEsQ0FBQyxPQUFPLEVBQUUsSUFBSSxDQUFDLE9BQU8sQ0FBQyxHQUFHLEVBQUUsS0FBSyxDQUFDLENBQUMsQ0FBQztxQkFDdEUsSUFBSSxDQUFDLFFBQVEsRUFBRSxDQUFDLEtBQUssRUFBRSxFQUFFLENBQUMsYUFBYSxDQUFDLFNBQVMsRUFBRSxJQUFJLENBQUMsT0FBTyxDQUFDLFFBQVEsRUFBRSxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUM7YUFDM0Y7U0FFSjthQUFNO1lBQ0gsU0FBUztpQkFDSixJQUFJLENBQUMsUUFBUSxFQUFFLGFBQWEsQ0FBQyxTQUFTLEVBQUUsWUFBWSxDQUFDLEtBQUssQ0FBQyxDQUFDO2lCQUM1RCxJQUFJLENBQUMsR0FBRyxFQUFFLENBQUMsS0FBSyxFQUFFLE1BQU0sRUFBRSxFQUFFO2dCQUN6QixJQUFJLElBQUksQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLEtBQUssU0FBUztvQkFBRSxNQUFNLEdBQUcsWUFBWSxDQUFDLEtBQUssR0FBRyxNQUFNLEdBQUcsWUFBWSxDQUFDLE9BQU8sR0FBRyxNQUFNLENBQUM7Z0JBQzFHLE9BQU8sYUFBYSxDQUFDLE9BQU8sRUFBRSxJQUFJLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLEdBQUcsTUFBTSxDQUFDLENBQUM7WUFDL0QsQ0FBQyxDQUFDLENBQUM7WUFFUCxJQUFJLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxTQUFTLEVBQUU7Z0JBQ3hCLFNBQVM7cUJBQ0osSUFBSSxDQUFDLEdBQUcsRUFBRSxDQUFDLEtBQUssRUFBRSxFQUFFLENBQUMsYUFBYSxDQUFDLE9BQU8sRUFBRSxJQUFJLENBQUMsT0FBTyxDQUFDLEdBQUcsRUFBRSxLQUFLLENBQUMsQ0FBQyxDQUFDO3FCQUN0RSxJQUFJLENBQUMsT0FBTyxFQUFFLENBQUMsS0FBSyxFQUFFLEVBQUUsQ0FBQyxhQUFhLENBQUMsUUFBUSxFQUFFLElBQUksQ0FBQyxPQUFPLENBQUMsT0FBTyxFQUFFLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQzthQUN4RjtpQkFBTTtnQkFDSCxTQUFTO3FCQUNKLElBQUksQ0FBQyxHQUFHLEVBQUUsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztxQkFDcEIsSUFBSSxDQUFDLE9BQU8sRUFBRSxDQUFDLENBQUMsQ0FBQztnQkFFdEIsaUJBQWlCLEdBQUcsU0FBUyxDQUFDLFVBQVUsRUFBRSxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsa0JBQWtCLENBQUM7cUJBQ3ZFLElBQUksQ0FBQyxHQUFHLEVBQUUsQ0FBQyxLQUFLLEVBQUUsRUFBRSxDQUFDLGFBQWEsQ0FBQyxPQUFPLEVBQUUsSUFBSSxDQUFDLE9BQU8sQ0FBQyxHQUFHLEVBQUUsS0FBSyxDQUFDLENBQUMsQ0FBQztxQkFDdEUsSUFBSSxDQUFDLE9BQU8sRUFBRSxDQUFDLEtBQUssRUFBRSxFQUFFLENBQUMsYUFBYSxDQUFDLFFBQVEsRUFBRSxJQUFJLENBQUMsT0FBTyxDQUFDLE9BQU8sRUFBRSxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUM7YUFDeEY7U0FFSjtRQUVELE9BQU87WUFDSCxTQUFTLEVBQUUsU0FBUztZQUNwQixpQkFBaUIsRUFBRSxpQkFBaUI7WUFDcEMsT0FBTyxFQUFFLE9BQU87WUFDaEIsT0FBTyxFQUFFLE9BQU87WUFDaEIsUUFBUSxFQUFFLFFBQVE7WUFDbEIsU0FBUyxFQUFFLFNBQVM7U0FDdkIsQ0FBQztRQUVGLFNBQVMsYUFBYSxDQUFDLE1BQXFCLEVBQUUsS0FBYTtZQUN2RCxNQUFNLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFDO1lBQ25CLE9BQU8sS0FBSyxDQUFDO1FBQ2pCLENBQUM7SUFDTCxDQUFDO0lBRU8sT0FBTyxDQUFDLEtBQXFDLEVBQUUsTUFBZ0I7UUFDbkUsSUFBSSxLQUFLLEdBQUcsSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsS0FBSyxLQUFLLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUM7UUFDMUUsSUFBSSxNQUFNLEdBQVcsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztRQUVuQyxJQUFJLEtBQUssS0FBSyxHQUFHLElBQUksS0FBSyxLQUFLLEdBQUcsRUFBRTtZQUNoQyxPQUFPLElBQUksQ0FBQyxhQUFhLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsYUFBYSxDQUFDLE1BQU0sQ0FBQyxHQUFHLEVBQUUsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxhQUFhLENBQUMsTUFBTSxDQUFDLEdBQUcsRUFBRSxLQUFLLENBQUMsR0FBRyxJQUFJLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUM7U0FDckk7UUFDRCxJQUFJLEtBQUssS0FBSyxRQUFRO1lBQUUsT0FBTyxJQUFJLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsYUFBYSxDQUFDLE1BQU0sQ0FBQyxHQUFHLEVBQUUsS0FBSyxDQUFDLEdBQUcsS0FBSyxDQUFDLEdBQUcsSUFBSSxDQUFDLENBQUMsQ0FBQyxhQUFhLENBQUMsTUFBTSxDQUFDLEdBQUcsRUFBRSxLQUFLLENBQUMsQ0FBQyxDQUFDLEdBQUcsTUFBTSxDQUFDO1FBQzlJLElBQUksS0FBSyxLQUFLLE9BQU87WUFBRSxPQUFPLElBQUksQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxhQUFhLENBQUMsTUFBTSxDQUFDLEdBQUcsRUFBRSxLQUFLLENBQUMsQ0FBQyxHQUFHLElBQUksQ0FBQyxDQUFDLENBQUMsYUFBYSxDQUFDLE1BQU0sQ0FBQyxHQUFHLEVBQUUsS0FBSyxDQUFDLEdBQUcsS0FBSyxDQUFDLENBQUMsR0FBRyxNQUFNLENBQUM7UUFFN0kscUpBQXFKO1FBQ3JKLFNBQVMsYUFBYSxDQUFDLElBQVksRUFBRSxNQUFjO1lBQy9DLE9BQU8sSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksR0FBRyxNQUFNLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQztRQUN0RCxDQUFDO0lBQ0wsQ0FBQztJQUVPLGlCQUFpQixDQUFDLEVBQWUsRUFBRSxPQUFlLEVBQUUsTUFBa0I7UUFDMUUsS0FBSyxJQUFJLE1BQU0sR0FBRyxDQUFDLEVBQUUsTUFBTSxHQUFHLEVBQUUsQ0FBQyxDQUFDLENBQUMsTUFBTSxFQUFFLEVBQUUsTUFBTSxFQUFFO1lBQ2pELElBQUksRUFBRSxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxLQUFLLEtBQUssSUFBSTtnQkFBRSxTQUFTO1lBRTFDLElBQUksS0FBSyxHQUFhLE1BQU0sQ0FBQyxNQUFNLENBQUMsRUFBRSxFQUFFLEVBQUUsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsRUFDakQsVUFBVSxHQUF1QjtnQkFDN0IsSUFBSSxFQUFFLE1BQU0sQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDO2dCQUM1QixJQUFJLEVBQUUsTUFBTSxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUM7Z0JBQzVCLE1BQU0sRUFBRSxJQUFJLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxLQUFLLFFBQVEsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLFNBQVMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUM7Z0JBQ3ZGLEtBQUssRUFBRSxJQUFJLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxLQUFLLFFBQVEsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLFFBQVEsQ0FBQyxNQUFNLENBQUM7YUFDdkYsQ0FBQztZQUVOLElBQUksQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsTUFBTSxFQUFFO2dCQUNsQyxJQUFJLElBQUksQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLEtBQUssUUFBUSxFQUFFO29CQUNoQyxJQUFJLENBQUMsS0FBSyxDQUFDLEtBQUssR0FBRyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLFdBQVcsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLEtBQUssR0FBRyxDQUFDLElBQUksSUFBSSxDQUFDLFNBQVMsQ0FBQyxXQUFXLENBQUMsRUFBRTt3QkFDckcsVUFBVSxDQUFDLElBQUksSUFBSSxNQUFNLENBQUMsU0FBUyxDQUFDLE1BQU0sQ0FBQyxDQUFDO3FCQUMvQztvQkFDRCw0Q0FBNEM7b0JBQzVDLElBQUksSUFBSSxDQUFDLEtBQUs7d0JBQUUsVUFBVSxDQUFDLElBQUksSUFBSSxNQUFNLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDO2lCQUN6RDtxQkFBTTtvQkFDSCxJQUFJLENBQUMsS0FBSyxDQUFDLEtBQUssR0FBRyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLFdBQVcsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLEtBQUssR0FBRyxDQUFDLElBQUksSUFBSSxDQUFDLFNBQVMsQ0FBQyxXQUFXLENBQUMsRUFBRTt3QkFDckcsVUFBVSxDQUFDLElBQUksSUFBSSxNQUFNLENBQUMsUUFBUSxDQUFDLE1BQU0sQ0FBQyxDQUFDO3FCQUM5QztpQkFDSjthQUNKO2lCQUFNO2dCQUNILElBQUksSUFBSSxDQUFDLEtBQUssRUFBRTtvQkFDWixZQUFZO29CQUNaLDhDQUE4QztvQkFDOUMsK0RBQStEO29CQUMvRCxJQUFJLEtBQUssR0FBRyxJQUFJLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxLQUFLLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUM7b0JBQ3hELFVBQVUsQ0FBQyxJQUFJLElBQUksTUFBTSxDQUFDLFFBQVEsQ0FBQyxLQUFLLENBQUMsQ0FBQztpQkFDN0M7YUFDSjtZQUNELElBQUksSUFBSSxDQUFDLFNBQVMsQ0FBQyxlQUFlO2dCQUFFLEtBQUssQ0FBQyxLQUFLLEdBQUcsSUFBSSxDQUFDLFNBQVMsQ0FBQyw0QkFBNEIsQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLENBQUM7WUFFM0csSUFBSSxjQUFjLEdBQVEsS0FBSyxDQUFDLFFBQVEsQ0FBQyxLQUFLLEVBQUUsT0FBTyxFQUFFLFVBQVUsQ0FBQyxJQUFJLEVBQUUsVUFBVSxDQUFDLElBQUksQ0FBQyxDQUFDO1lBRTNGLHlFQUF5RTtZQUN6RSxJQUFJLENBQUMsY0FBYyxDQUFDLGNBQWMsRUFBRSxFQUFFLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLEtBQUssRUFBRSxVQUFVLENBQUMsQ0FBQztTQUN2RTtJQUNMLENBQUM7SUFFRCxnREFBZ0Q7SUFDaEQsNkNBQTZDO0lBQ3JDLGNBQWMsQ0FBQyxlQUFlLEVBQUUsTUFBYyxFQUFFLFdBQStCO1FBQ25GLElBQUksU0FBUyxHQUFRLGVBQWUsQ0FBQyxNQUFNLENBQUMsNkJBQTZCLENBQUMsQ0FBQztRQUMzRSxJQUFJLGFBQWEsR0FBRyxJQUFJLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsYUFBYSxDQUFDO1FBQzNELElBQUksTUFBTSxHQUFZLElBQUksQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUM7UUFDdEQsSUFBSSxJQUFJLEdBQVcsSUFBSSxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQztRQUNyQyxJQUFJLENBQUMsYUFBYTtZQUFFLGFBQWEsR0FBRyxJQUFJLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxLQUFLLFFBQVEsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUM7UUFFdEYsSUFBSSxDQUFDLE9BQU8sQ0FBQyw4QkFBOEIsQ0FBQyxlQUFlLEVBQUUsSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsRUFBRSxNQUFNLEVBQUUsV0FBVyxDQUFDLENBQUM7UUFFckcsZ0RBQWdEO1FBQ2hELElBQUkscUJBQXFCLEdBQUcsSUFBSSxDQUFDLFNBQVMsQ0FBQyxtQkFBbUIsRUFBRSxHQUFHLFdBQVcsQ0FBQyxNQUFNLENBQUM7UUFDdEYsSUFBSSxxQkFBcUIsRUFBRTtZQUN2QixJQUFJLElBQUksQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLEtBQUssS0FBSyxFQUFFO2dCQUM3QixhQUFhLEdBQUcsUUFBUSxDQUFDO2FBQzVCO2lCQUFNLElBQUksTUFBTSxFQUFFO2dCQUNmLG1FQUFtRTtnQkFDbkUsbUZBQW1GO2dCQUNuRixrRkFBa0Y7Z0JBQ2xGLGFBQWEsR0FBRyxJQUFJLENBQUMsU0FBUyxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUM7YUFDakU7U0FDSjtRQUVELElBQUksQ0FBQyxNQUFNLEVBQUU7WUFDVCxJQUFJLElBQUksQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLEtBQUssS0FBSyxFQUFFO2dCQUM3QixJQUFJLENBQUMsT0FBTyxDQUFDLDBCQUEwQixDQUNuQyxTQUFTLEVBQ1QsSUFBSSxDQUFDLFNBQVMsQ0FBQyxXQUFXLEVBQzFCLEVBQUUsSUFBSSxFQUFFLFdBQVcsQ0FBQyxJQUFJLEVBQUUsVUFBVSxFQUFFLElBQUksQ0FBQyxLQUFLLEVBQUUsU0FBUyxFQUFFLElBQUksRUFBRSxDQUN0RSxDQUFDO2FBQ0w7aUJBQU07Z0JBQ0gsSUFBSSxNQUFNLEdBQUcsRUFBRSxTQUFTLEVBQUUsSUFBSSxFQUFFLENBQUM7Z0JBQ2pDLElBQUksSUFBSSxHQUFHLFdBQVcsQ0FBQyxJQUFJLENBQUMsQ0FBQyw4QkFBOEI7Z0JBQzNELElBQUkscUJBQXFCLElBQUksSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsS0FBSyxTQUFTLEVBQUU7b0JBQzFELE1BQU0sQ0FBQyxZQUFZLENBQUMsR0FBRyxXQUFXLENBQUM7b0JBQ25DLElBQUksVUFBVSxHQUFRLElBQUksQ0FBQyxTQUFTLENBQUMsbUJBQW1CLENBQUMsYUFBYSxFQUFFLE1BQU0sQ0FBQyxDQUFDO29CQUNoRixJQUFJLFVBQVU7d0JBQUUsSUFBSSxJQUFJLFVBQVUsR0FBRyxXQUFXLENBQUMsTUFBTSxDQUFDO2lCQUMzRDtnQkFDRCxLQUFLLENBQUMsb0JBQW9CLENBQUMsU0FBUyxFQUFFLElBQUksRUFBRSxNQUFNLENBQUMsQ0FBQzthQUN2RDtTQUNKO1FBR0QsSUFBSSxDQUFDLE9BQU8sQ0FBQyxtQkFBbUIsQ0FBQyxlQUFlLEVBQUUsYUFBYSxDQUFDLENBQUM7SUFDckUsQ0FBQztJQUVPLGdCQUFnQjtRQUNwQixJQUFJLENBQUMsa0JBQWtCO2FBQ2xCLFNBQVMsQ0FBQyx3QkFBd0IsQ0FBQzthQUNuQyxLQUFLLENBQUMsWUFBWSxFQUFFLFNBQVMsQ0FBQyxDQUFDO0lBQ3hDLENBQUM7SUFFTyxlQUFlO1FBQ25CLElBQUksSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsS0FBSyxTQUFTLEVBQUU7WUFDakMsZ0dBQWdHO1lBQ2hHLGdEQUFnRDtZQUNoRCxJQUFJLFVBQVUsR0FBRyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxJQUFJLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztZQUM1RSxPQUFPLElBQUksQ0FBQyxPQUFPLENBQUMsWUFBWSxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsU0FBUyxFQUFFLEVBQUUsSUFBSSxDQUFDLEdBQUcsQ0FBQyxxQkFBcUIsRUFBRSxVQUFVLENBQUMsQ0FBQztTQUNwRztRQUNELE9BQU87WUFDSCxLQUFLLEVBQUUsSUFBSSxDQUFDLENBQUMsQ0FBQyxTQUFTLEVBQUU7WUFDekIsT0FBTyxFQUFFLENBQUM7U0FDYixDQUFDO0lBQ04sQ0FBQztJQUVPLDBCQUEwQjtRQUM5QixJQUFJLE1BQU0sR0FBOEIsSUFBSSxDQUFDLE9BQU8sQ0FBQyxrQkFBa0IsQ0FBQyxJQUFJLENBQUMsU0FBUyxFQUFFLElBQUksQ0FBQyxNQUFNLENBQUMsV0FBVyxFQUFFLElBQUksQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLENBQUM7UUFDcEksSUFBSSxNQUFNLENBQUMsY0FBYyxDQUFDLFdBQVcsQ0FBQztZQUFFLElBQUksQ0FBQyxTQUFTLEdBQUcsTUFBTSxDQUFDLFNBQVMsQ0FBQztRQUMxRSxJQUFJLE1BQU0sQ0FBQyxjQUFjLENBQUMsT0FBTyxDQUFDLEVBQUU7WUFDaEMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxLQUFLLEdBQUcsTUFBTSxDQUFDLE1BQU0sQ0FBQyxFQUFFLEVBQUUsSUFBSSxDQUFDLE1BQU0sQ0FBQyxLQUFLLEVBQUUsTUFBTSxDQUFDLEtBQUssQ0FBQyxDQUFDO1NBQzFFO0lBQ0wsQ0FBQzs7O1lBMVZKLFNBQVMsU0FBQztnQkFDUCxRQUFRLEVBQUUsY0FBYztnQkFDeEIsUUFBUSxFQUFFOzs7O0tBSVQ7Z0JBQ0QsYUFBYSxFQUFFLGlCQUFpQixDQUFDLElBQUk7Z0JBQ3JDLFNBQVMsRUFBRSxDQUFDLFdBQVcsRUFBRSxZQUFZLEVBQUUsYUFBYSxDQUFDO2dCQUNyRCxJQUFJLEVBQUU7b0JBQ0YsT0FBTyxFQUFFLGVBQWU7aUJBQzNCO2FBQ0o7OztZQWxCUSxXQUFXO1lBR1gsWUFBWTtZQUNaLGFBQWE7OztzQkFzQmpCLEtBQUssU0FBQyxNQUFNO3dCQUNaLEtBQUssU0FBQyxRQUFRO3FCQUNkLEtBQUs7a0JBQ0wsS0FBSyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7XHJcbiAgICBDb21wb25lbnQsXHJcbiAgICBWaWV3RW5jYXBzdWxhdGlvbixcclxuICAgIElucHV0LFxyXG4gICAgT25Jbml0LFxyXG4gICAgT25DaGFuZ2VzLFxyXG4gICAgU2ltcGxlQ2hhbmdlcyxcclxuICAgIE9uRGVzdHJveVxyXG59IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xyXG5pbXBvcnQgeyBLZENoYXJ0QmFzZUNsYXNzIH0gZnJvbSAnLi4va2QtYW5ndWxhci1jaGFydC1iYXNlLWNsYXNzJztcclxuaW1wb3J0IHsgS2RDaGFydHNTdmMgfSBmcm9tICcuLi9rZC1hbmd1bGFyLWNoYXJ0cy1zdmMnO1xyXG5pbXBvcnQgeyBJRDNEYXRhLCBJQ2hhcnRDb25maWcsIElEM0RhdGFEYXRhLCBJRDNZRGF0YSwgSUxlZ2VuZERhdGEgfSBmcm9tICcuLi9rZC1hbmd1bGFyLWNoYXJ0cy1pbnRlcmZhY2UnO1xyXG5pbXBvcnQgeyBJUmVjdFBvc0luZm8sIElSZWN0R3JvdXAsIElCYXJSZWN0RGltZW5zaW9ucywgSU5lZ2F0aXZlU3RhY2tMb2dpY1JldHVybiB9IGZyb20gJy4va2QtYW5ndWxhci1iYXItY2hhcnQtaW50ZXJmYWNlJztcclxuaW1wb3J0IHsgS2REb21FbGVtU3ZjIH0gZnJvbSAnLi4vLi4va2QtY29tbW9uL2luZGV4JztcclxuaW1wb3J0IHsgS2RCYXJDaGFydFN2YyB9IGZyb20gJy4va2QtYW5ndWxhci1iYXItY2hhcnQtc3ZjJztcclxuXHJcbkBDb21wb25lbnQoe1xyXG4gICAgc2VsZWN0b3I6ICdrZC1iYXItY2hhcnQnLFxyXG4gICAgdGVtcGxhdGU6IGBcclxuICAgICAgICA8ZGl2ICpuZ0lmPVwiY2hhcnRUeXBlWzFdID09PSAnMTAwJyAmJiBoYXZlTmVnYXRpdmVcIiBjbGFzcz1cImtkeC1jaGFydHMtZXJyb3ItbXNnXCI+XHJcbiAgICAgICAgICAgIHt7ZXJyb3JNc2d9fVxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgYCxcclxuICAgIGVuY2Fwc3VsYXRpb246IFZpZXdFbmNhcHN1bGF0aW9uLk5vbmUsXHJcbiAgICBwcm92aWRlcnM6IFtLZENoYXJ0c1N2YywgS2REb21FbGVtU3ZjLCBLZEJhckNoYXJ0U3ZjXSxcclxuICAgIGhvc3Q6IHtcclxuICAgICAgICAnY2xhc3MnOiAna2R4LWJhci1jaGFydCcsXHJcbiAgICB9XHJcbn0pXHJcblxyXG5leHBvcnQgY2xhc3MgS2RCYXJDaGFydCBleHRlbmRzIEtkQ2hhcnRCYXNlQ2xhc3MgaW1wbGVtZW50cyBPbkluaXQsIE9uQ2hhbmdlcywgT25EZXN0cm95IHtcclxuXHJcbiAgICBwcml2YXRlIF9iYXJHcmFwaDogYW55O1xyXG4gICAgcHJpdmF0ZSBfcmVzaXplVGltZW91dDogYW55O1xyXG4gICAgcHJpdmF0ZSBfaXNTdGFydEF0U3VtOiBib29sZWFuID0gZmFsc2U7XHJcblxyXG4gICAgQElucHV0KCdkYXRhJykgYWxsRGF0YTogSUQzRGF0YTtcclxuICAgIEBJbnB1dCgnY29uZmlnJykgYmFyQ29uZmlnOiBJQ2hhcnRDb25maWc7XHJcbiAgICBASW5wdXQoKSBsZWdlbmQ6IHsgW2tleTogc3RyaW5nXTogSUxlZ2VuZERhdGEgfTtcclxuICAgIEBJbnB1dCgpIGFwaTogYW55O1xyXG5cclxuICAgIGNvbnN0cnVjdG9yKFxyXG4gICAgICAgIHB1YmxpYyBfY2hhcnRTdmM6IEtkQ2hhcnRzU3ZjLFxyXG4gICAgICAgIHB1YmxpYyBfZG9tU3ZjOiBLZERvbUVsZW1TdmMsXHJcbiAgICAgICAgcHVibGljIF9iYXJTdmM6IEtkQmFyQ2hhcnRTdmNcclxuICAgICkge1xyXG4gICAgICAgIHN1cGVyKF9jaGFydFN2YywgX2RvbVN2Yyk7XHJcbiAgICB9XHJcblxyXG4gICAgbmdPbkluaXQoKTogdm9pZCB7XHJcbiAgICAgICAgdGhpcy5fcmVkcmF3Q2hhcnQodHJ1ZSwgeyBkYXRhOiB0aGlzLmFsbERhdGEsIGNvbmZpZzogdGhpcy5iYXJDb25maWcgfSk7XHJcbiAgICAgICAgdGhpcy5hcGkubGVnZW5kQ2xpY2sgPSAoX2RhdGE6IGFueSkgPT4ge1xyXG4gICAgICAgICAgICB0aGlzLl9yZWRyYXdDaGFydChmYWxzZSwgeyBkYXRhOiBfZGF0YSB9KTtcclxuICAgICAgICB9O1xyXG4gICAgICAgIHRoaXMuYXBpLnJlZHJhdyA9ICgpID0+IHtcclxuICAgICAgICAgICAgY2xlYXJUaW1lb3V0KHRoaXMuX3Jlc2l6ZVRpbWVvdXQpO1xyXG4gICAgICAgICAgICB0aGlzLl9yZXNpemVUaW1lb3V0ID0gc2V0VGltZW91dCgoKSA9PiB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLl9yZWRyYXdDaGFydChmYWxzZSwge30pO1xyXG4gICAgICAgICAgICB9KTtcclxuICAgICAgICB9O1xyXG4gICAgfVxyXG5cclxuICAgIG5nT25DaGFuZ2VzKF9zaW1wbGVDaGFuZ2VzOiBTaW1wbGVDaGFuZ2VzKTogdm9pZCB7XHJcbiAgICAgICAgaWYgKF9zaW1wbGVDaGFuZ2VzLmhhc093blByb3BlcnR5KCdhbGxEYXRhJykgJiYgIV9zaW1wbGVDaGFuZ2VzWydhbGxEYXRhJ10uZmlyc3RDaGFuZ2UpIHtcclxuICAgICAgICAgICAgdGhpcy5fcmVkcmF3Q2hhcnQoZmFsc2UsIHsgZGF0YTogX3NpbXBsZUNoYW5nZXMuYWxsRGF0YS5jdXJyZW50VmFsdWUgfSk7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGlmIChfc2ltcGxlQ2hhbmdlcy5oYXNPd25Qcm9wZXJ0eSgnYmFyQ29uZmlnJykgJiYgIV9zaW1wbGVDaGFuZ2VzWydiYXJDb25maWcnXS5maXJzdENoYW5nZSkge1xyXG4gICAgICAgICAgICB0aGlzLl9yZWRyYXdDaGFydChmYWxzZSwgeyBjb25maWc6IF9zaW1wbGVDaGFuZ2VzLmJhckNvbmZpZy5jdXJyZW50VmFsdWUgfSk7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIG5nT25EZXN0cm95KCk6IHZvaWQge1xyXG4gICAgICAgIHRoaXMuX3Jlc2V0Q2hhcnQoKTtcclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF9yZWRyYXdDaGFydChpc0ZpcnN0Q2hhbmdlOiBib29sZWFuLCBfY2hhbmdlczogeyBkYXRhPzogSUQzRGF0YSwgY29uZmlnPzogSUNoYXJ0Q29uZmlnIH0gPSB7fSkge1xyXG4gICAgICAgIGlmICghaXNGaXJzdENoYW5nZSkge1xyXG4gICAgICAgICAgICB0aGlzLl9yZXNldENoYXJ0KCk7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIHRoaXMubGVnZW5kRGF0YSA9IE9iamVjdC5hc3NpZ24oe30sIHRoaXMubGVnZW5kKTtcclxuICAgICAgICBpZiAoX2NoYW5nZXMuaGFzT3duUHJvcGVydHkoJ2RhdGEnKSkgdGhpcy5fc2V0RGF0YShfY2hhbmdlcy5kYXRhKTtcclxuICAgICAgICBpZiAoX2NoYW5nZXMuaGFzT3duUHJvcGVydHkoJ2NvbmZpZycpKSB0aGlzLl9zZXRDb25maWcoX2NoYW5nZXMuY29uZmlnKTtcclxuICAgICAgICBzdXBlci5jaGFydFRpbWVvdXQoKCkgPT4gdGhpcy5fc2V0Q2hhcnQoKSk7XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfc2V0RGF0YShfZGF0YTogSUQzRGF0YSk6IHZvaWQge1xyXG4gICAgICAgIHRoaXMuZGF0YSA9IE9iamVjdC5hc3NpZ24oW10sIF9kYXRhLmRhdGEpO1xyXG4gICAgICAgIC8vIHNhdmluZyBvcmlnaW5hbCBkYXRhIHNvbWV3aGVyZSBiZWZvcmUgdHJpbW1pbmcgdGhpcy5kYXRhLiB3aGVuIG5vIHRyaW1taW5nLCB0aGVuIHRoaXMuZGF0YSB3aWxsIGp1c3QgYmUgaW5pdERhdGFcclxuICAgICAgICB0aGlzLmluaXREYXRhID0gSlNPTi5wYXJzZShKU09OLnN0cmluZ2lmeSh0aGlzLmRhdGEpKTtcclxuXHJcbiAgICAgICAgdGhpcy5jaGFydENhdGVnb3J5ID0gJ2Jhcic7XHJcbiAgICAgICAgdGhpcy5jaGFydFR5cGUgPSBfZGF0YS5sYXlvdXQuc3BsaXQoJy0nKTtcclxuICAgICAgICB0aGlzLl9jaGFydFN2Yy5pc0ludmVydCA9IHRoaXMuY2hhcnRUeXBlWzBdID09PSAnYmFyJztcclxuICAgICAgICB0aGlzLmJhci5pc0ludmVydCA9IHRoaXMuY2hhcnRUeXBlWzBdID09PSAnYmFyJztcclxuICAgICAgICB0aGlzLl9jaGFydFN2Yy5pc05lZ2F0aXZlU3RhY2sgPSB0aGlzLmNoYXJ0VHlwZVsxXSA9PT0gJ3N0YWNrJyAmJiB0aGlzLmNoYXJ0VHlwZVsyXSA9PT0gJ25lZ2F0aXZlJztcclxuXHJcbiAgICAgICAgLy8gcmFuZ2UgYW5kIG5lZ2F0aXZlIGZsYWcgY2FsY3VsYXRlZCBieSBrZENoYXJ0LCB1c2VkIGluIGRvbWFpbiwgcmVjYWxjdWxhdGVkIHdoZW4gY2hhbmdlIGdyYXBoIHR5cGUgYW5kIGxlZ2VuZFxyXG4gICAgICAgIHRoaXMuZGF0YVJhbmdlID0gX2RhdGEucmFuZ2U7XHJcbiAgICAgICAgdGhpcy5oYXZlTmVnYXRpdmUgPSBfZGF0YS5oYXZlTmVnYXRpdmU7XHJcbiAgICAgICAgdGhpcy5fYmFyU3ZjLm9yaWdpbmFsRGF0YVJhbmdlID0gX2RhdGEucmFuZ2U7XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfc2V0Q29uZmlnKF9jb25maWc6IElDaGFydENvbmZpZyk6IHZvaWQge1xyXG4gICAgICAgIHRoaXMuY29uZmlnID0gT2JqZWN0LmFzc2lnbih7fSwgX2NvbmZpZyk7XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfc2V0Q2hhcnQoKTogdm9pZCB7XHJcbiAgICAgICAgaWYgKHRoaXMuY2hhcnRUeXBlWzFdID09PSAnMTAwJyAmJiB0aGlzLmhhdmVOZWdhdGl2ZSkgcmV0dXJuO1xyXG4gICAgICAgIGlmICh0aGlzLl9jaGFydFN2Yy5pc05lZ2F0aXZlU3RhY2spIHRoaXMubmVnYXRpdmVTdGFja1N5bW1ldHJ5TG9naWMoKTtcclxuICAgICAgICBzdXBlci5zZXRTdmcoKTtcclxuICAgICAgICBzdXBlci5zZXREb21haW4oJ2JhbmQnKTtcclxuICAgICAgICB0aGlzLl9kcmF3Q2hhcnQoKTtcclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF9yZXNldENoYXJ0KCk6IHZvaWQge1xyXG4gICAgICAgIHN1cGVyLnJlbW92ZUNoYXJ0KCk7XHJcbiAgICAgICAgaWYgKHRoaXMuX2JhckdyYXBoKSB7XHJcbiAgICAgICAgICAgIHRoaXMuX2JhckdyYXBoLnJlbW92ZSgpO1xyXG4gICAgICAgICAgICB0aGlzLl9iYXJHcmFwaCA9IG51bGw7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX2RyYXdDaGFydENvbnRhaW5lcigpOiB2b2lkIHtcclxuICAgICAgICB0aGlzLl9iYXJHcmFwaCA9IHRoaXMuZ3JhcGguYXBwZW5kKCdnJykuYXR0cignY2xhc3MnLCAnYmFyLWdyYXBoLWNvbnRhaW5lcicpO1xyXG4gICAgICAgIHRoaXMuX2JhckdyYXBoLmF0dHIoJ2NsaXAtcGF0aCcsICd1cmwoI2tkLWNoYXJ0cy1jbGlwLXBhdGgtJyArIHRoaXMuY29uZmlnLmlkICsgJyknKTtcclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF9kcmF3Q2hhcnQoKTogdm9pZCB7XHJcbiAgICAgICAgaWYgKCF0aGlzLl9iYXJHcmFwaCkgdGhpcy5fZHJhd0NoYXJ0Q29udGFpbmVyKCk7XHJcblxyXG4gICAgICAgIHRoaXMuX2lzU3RhcnRBdFN1bSA9IHRoaXMuYmFyLmlzSW52ZXJ0ID09PSB0aGlzLl9jaGFydFN2Yy5pc1lSZXZlcnNlZDtcclxuXHJcbiAgICAgICAgbGV0IHJlY3RQb3NJbmZvOiB7IHdpZHRoOiBudW1iZXIsIHBhZGRpbmc6IG51bWJlciB9ID0gdGhpcy5fZ2V0UmVjdFBvc0luZm8oKTtcclxuXHJcbiAgICAgICAgdGhpcy5kYXRhLmZvckVhY2goKGQ6IElEM0RhdGFEYXRhLCBpOiBudW1iZXIpID0+IHtcclxuICAgICAgICAgICAgbGV0IGdyb3VwczogSVJlY3RHcm91cCA9IHRoaXMuX3NldFJlY3RHcm91cChkLCBpLCBkLnksIHRoaXMuX2JhckdyYXBoLCByZWN0UG9zSW5mbyk7XHJcblxyXG4gICAgICAgICAgICBzdXBlci5faW5pdE1vdXNlRXZlbnRzKGdyb3Vwcy5yZWN0R3JvdXAsIHsgZGF0YTogZCwgaW5kZXg6IGkgfSk7XHJcblxyXG4gICAgICAgICAgICBpZiAodGhpcy5jb25maWcuY2hhcnQubGFiZWxzLmVuYWJsZWQpIHtcclxuICAgICAgICAgICAgICAgIHRoaXMuX3NldEJhckNoYXJ0TGFiZWwoZCwgaSwgZ3JvdXBzKTtcclxuXHJcbiAgICAgICAgICAgICAgICBpZiAodGhpcy5jb25maWcuYW5pbWF0aW9uKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgZ3JvdXBzLnJlY3RHcm91cFRyYW5zaXRlLm9uKCdlbmQnLCAoeURhdGEsIHlJbmRleCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAvLyB3aGVuIHRoZSBsYXN0IHJlY3QgdHJhbnNpdGUgZW5kc1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAoKHlEYXRhLnhJbmRleCA9PT0gdGhpcy5kYXRhLmxlbmd0aCAtIDEpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAmJiAoeUluZGV4ID09PSB0aGlzLmRhdGFbdGhpcy5kYXRhLmxlbmd0aCAtIDFdLnkubGVuZ3RoIC0gMSkpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuX2Rpc3BsYXlBbGxMYWJlbCgpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuX2Rpc3BsYXlBbGxMYWJlbCgpO1xyXG4gICAgICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH0pO1xyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX3NldFJlY3RHcm91cChfZDogSUQzRGF0YURhdGEsIF94SW5kZXg6IG51bWJlciwgX3lEYXRhQXJyOiBBcnJheTxJRDNZRGF0YT4sIF9jb250YWluZXI6IGFueSwgX3JlY3RQb3NJbmZvOiBJUmVjdFBvc0luZm8pOiBJUmVjdEdyb3VwIHtcclxuICAgICAgICBsZXQgcmVjdEdyb3VwID0gX2NvbnRhaW5lci5zZWxlY3RBbGwoJ3JlY3RHcm91cCcpXHJcbiAgICAgICAgICAgIC5kYXRhKF95RGF0YUFyciwgKGQpID0+IHsgZFsneEluZGV4J10gPSBfeEluZGV4OyByZXR1cm4gZDsgfSlcclxuICAgICAgICAgICAgLmVudGVyKClcclxuICAgICAgICAgICAgLmFwcGVuZCgncmVjdCcpO1xyXG4gICAgICAgIGxldCBvZmZzZXQgPSAwLCByZWN0R3JvdXBUcmFuc2l0ZTogYW55LCB4UG9zQXJyOiBBcnJheTxudW1iZXI+ID0gW10sIHlQb3NBcnI6IEFycmF5PG51bWJlcj4gPSBbXSwgd2lkdGhBcnI6IEFycmF5PG51bWJlcj4gPSBbXSwgaGVpZ2h0QXJyOiBBcnJheTxudW1iZXI+ID0gW107XHJcblxyXG4gICAgICAgIHJlY3RHcm91cFxyXG4gICAgICAgICAgICAuYXR0cignY2xhc3MnLCAoeURhdGEpID0+ICdiYXIgeC0nICsgX3hJbmRleCArICcgeS0nICsgeURhdGEuaWQpXHJcbiAgICAgICAgICAgIC5hdHRyKCdmaWxsJywgKHlEYXRhLCB5SW5kZXgpID0+IHRoaXMubGVnZW5kLmhhc093blByb3BlcnR5KHlEYXRhLmlkKSA/IHRoaXMubGVnZW5kW3lEYXRhLmlkXS5jb2xvciB8fCAnJyA6ICcnKVxyXG4gICAgICAgICAgICAuYXR0cignYXJpYS14LXZhbHVlJywgX2QueC52YWx1ZSlcclxuICAgICAgICAgICAgLmF0dHIoJ2FyaWEteS12YWx1ZScsICh5RGF0YSkgPT4geURhdGEuc3VtKTtcclxuXHJcbiAgICAgICAgaWYgKHRoaXMuY2hhcnRUeXBlWzBdID09PSAnY29sdW1uJykge1xyXG4gICAgICAgICAgICByZWN0R3JvdXBcclxuICAgICAgICAgICAgICAgIC5hdHRyKCd3aWR0aCcsIHB1c2hBbmRSZXR1cm4od2lkdGhBcnIsIF9yZWN0UG9zSW5mby53aWR0aCkpXHJcbiAgICAgICAgICAgICAgICAuYXR0cigneCcsICh5RGF0YSwgeUluZGV4KSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKHRoaXMuY2hhcnRUeXBlWzFdID09PSAnY2x1c3RlcicpIG9mZnNldCA9IF9yZWN0UG9zSW5mby53aWR0aCAqIHlJbmRleCArIF9yZWN0UG9zSW5mby5wYWRkaW5nICogeUluZGV4O1xyXG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBwdXNoQW5kUmV0dXJuKHhQb3NBcnIsIHRoaXMueChfZC54LnZhbHVlKSArIG9mZnNldCk7XHJcbiAgICAgICAgICAgICAgICB9KTtcclxuXHJcbiAgICAgICAgICAgIGlmICghdGhpcy5jb25maWcuYW5pbWF0aW9uKSB7XHJcbiAgICAgICAgICAgICAgICByZWN0R3JvdXBcclxuICAgICAgICAgICAgICAgICAgICAuYXR0cigneScsICh5RGF0YSkgPT4gcHVzaEFuZFJldHVybih5UG9zQXJyLCB0aGlzLl9nZXRWYWwoJ3knLCB5RGF0YSkpKVxyXG4gICAgICAgICAgICAgICAgICAgIC5hdHRyKCdoZWlnaHQnLCAoeURhdGEpID0+IHB1c2hBbmRSZXR1cm4oaGVpZ2h0QXJyLCB0aGlzLl9nZXRWYWwoJ2hlaWdodCcsIHlEYXRhKSkpO1xyXG4gICAgICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgcmVjdEdyb3VwXHJcbiAgICAgICAgICAgICAgICAgICAgLmF0dHIoJ3knLCB0aGlzLnkoMCkpXHJcbiAgICAgICAgICAgICAgICAgICAgLmF0dHIoJ2hlaWdodCcsIDApO1xyXG5cclxuICAgICAgICAgICAgICAgIHJlY3RHcm91cFRyYW5zaXRlID0gcmVjdEdyb3VwLnRyYW5zaXRpb24oKS5kdXJhdGlvbih0aGlzLmxlbmd0aE9mVHJhbnNpdGlvbilcclxuICAgICAgICAgICAgICAgICAgICAuYXR0cigneScsICh5RGF0YSkgPT4gcHVzaEFuZFJldHVybih5UG9zQXJyLCB0aGlzLl9nZXRWYWwoJ3knLCB5RGF0YSkpKVxyXG4gICAgICAgICAgICAgICAgICAgIC5hdHRyKCdoZWlnaHQnLCAoeURhdGEpID0+IHB1c2hBbmRSZXR1cm4oaGVpZ2h0QXJyLCB0aGlzLl9nZXRWYWwoJ2hlaWdodCcsIHlEYXRhKSkpO1xyXG4gICAgICAgICAgICB9XHJcblxyXG4gICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgIHJlY3RHcm91cFxyXG4gICAgICAgICAgICAgICAgLmF0dHIoJ2hlaWdodCcsIHB1c2hBbmRSZXR1cm4oaGVpZ2h0QXJyLCBfcmVjdFBvc0luZm8ud2lkdGgpKVxyXG4gICAgICAgICAgICAgICAgLmF0dHIoJ3knLCAoeURhdGEsIHlJbmRleCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgIGlmICh0aGlzLmNoYXJ0VHlwZVsxXSA9PT0gJ2NsdXN0ZXInKSBvZmZzZXQgPSBfcmVjdFBvc0luZm8ud2lkdGggKiB5SW5kZXggKyBfcmVjdFBvc0luZm8ucGFkZGluZyAqIHlJbmRleDtcclxuICAgICAgICAgICAgICAgICAgICByZXR1cm4gcHVzaEFuZFJldHVybih5UG9zQXJyLCB0aGlzLngoX2QueC52YWx1ZSkgKyBvZmZzZXQpO1xyXG4gICAgICAgICAgICAgICAgfSk7XHJcblxyXG4gICAgICAgICAgICBpZiAoIXRoaXMuY29uZmlnLmFuaW1hdGlvbikge1xyXG4gICAgICAgICAgICAgICAgcmVjdEdyb3VwXHJcbiAgICAgICAgICAgICAgICAgICAgLmF0dHIoJ3gnLCAoeURhdGEpID0+IHB1c2hBbmRSZXR1cm4oeFBvc0FyciwgdGhpcy5fZ2V0VmFsKCd4JywgeURhdGEpKSlcclxuICAgICAgICAgICAgICAgICAgICAuYXR0cignd2lkdGgnLCAoeURhdGEpID0+IHB1c2hBbmRSZXR1cm4od2lkdGhBcnIsIHRoaXMuX2dldFZhbCgnd2lkdGgnLCB5RGF0YSkpKTtcclxuICAgICAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgICAgIHJlY3RHcm91cFxyXG4gICAgICAgICAgICAgICAgICAgIC5hdHRyKCd4JywgdGhpcy55KDApKVxyXG4gICAgICAgICAgICAgICAgICAgIC5hdHRyKCd3aWR0aCcsIDApO1xyXG5cclxuICAgICAgICAgICAgICAgIHJlY3RHcm91cFRyYW5zaXRlID0gcmVjdEdyb3VwLnRyYW5zaXRpb24oKS5kdXJhdGlvbih0aGlzLmxlbmd0aE9mVHJhbnNpdGlvbilcclxuICAgICAgICAgICAgICAgICAgICAuYXR0cigneCcsICh5RGF0YSkgPT4gcHVzaEFuZFJldHVybih4UG9zQXJyLCB0aGlzLl9nZXRWYWwoJ3gnLCB5RGF0YSkpKVxyXG4gICAgICAgICAgICAgICAgICAgIC5hdHRyKCd3aWR0aCcsICh5RGF0YSkgPT4gcHVzaEFuZFJldHVybih3aWR0aEFyciwgdGhpcy5fZ2V0VmFsKCd3aWR0aCcsIHlEYXRhKSkpO1xyXG4gICAgICAgICAgICB9XHJcblxyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgcmV0dXJuIHtcclxuICAgICAgICAgICAgcmVjdEdyb3VwOiByZWN0R3JvdXAsXHJcbiAgICAgICAgICAgIHJlY3RHcm91cFRyYW5zaXRlOiByZWN0R3JvdXBUcmFuc2l0ZSxcclxuICAgICAgICAgICAgeFBvc0FycjogeFBvc0FycixcclxuICAgICAgICAgICAgeVBvc0FycjogeVBvc0FycixcclxuICAgICAgICAgICAgd2lkdGhBcnI6IHdpZHRoQXJyLFxyXG4gICAgICAgICAgICBoZWlnaHRBcnI6IGhlaWdodEFyclxyXG4gICAgICAgIH07XHJcblxyXG4gICAgICAgIGZ1bmN0aW9uIHB1c2hBbmRSZXR1cm4odGFyZ2V0OiBBcnJheTxudW1iZXI+LCB2YWx1ZTogbnVtYmVyKTogbnVtYmVyIHtcclxuICAgICAgICAgICAgdGFyZ2V0LnB1c2godmFsdWUpO1xyXG4gICAgICAgICAgICByZXR1cm4gdmFsdWU7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX2dldFZhbChfdHlwZTogJ3gnIHwgJ3knIHwgJ2hlaWdodCcgfCAnd2lkdGgnLCBfeURhdGE6IElEM1lEYXRhKTogbnVtYmVyIHtcclxuICAgICAgICBsZXQgdmFsdWUgPSB0aGlzLmNoYXJ0VHlwZVsxXSA9PT0gJzEwMCcgPyBfeURhdGEucmVuZGVyVmFsIDogX3lEYXRhLnZhbHVlO1xyXG4gICAgICAgIGxldCBvZmZzZXQ6IG51bWJlciA9IHZhbHVlID8gMSA6IDA7XHJcblxyXG4gICAgICAgIGlmIChfdHlwZSA9PT0gJ3gnIHx8IF90eXBlID09PSAneScpIHtcclxuICAgICAgICAgICAgcmV0dXJuIHRoaXMuX2lzU3RhcnRBdFN1bSA/IHRoaXMueShuZWdhdGl2ZVJlY2FsKF95RGF0YS5zdW0sIHZhbHVlKSkgOiB0aGlzLnkobmVnYXRpdmVSZWNhbChfeURhdGEuc3VtLCB2YWx1ZSkgLSBNYXRoLmFicyh2YWx1ZSkpO1xyXG4gICAgICAgIH1cclxuICAgICAgICBpZiAoX3R5cGUgPT09ICdoZWlnaHQnKSByZXR1cm4gTWF0aC5hYnModGhpcy55KG5lZ2F0aXZlUmVjYWwoX3lEYXRhLnN1bSwgdmFsdWUpIC0gdmFsdWUpIC0gdGhpcy55KG5lZ2F0aXZlUmVjYWwoX3lEYXRhLnN1bSwgdmFsdWUpKSkgKyBvZmZzZXQ7XHJcbiAgICAgICAgaWYgKF90eXBlID09PSAnd2lkdGgnKSByZXR1cm4gTWF0aC5hYnModGhpcy55KG5lZ2F0aXZlUmVjYWwoX3lEYXRhLnN1bSwgdmFsdWUpKSAtIHRoaXMueShuZWdhdGl2ZVJlY2FsKF95RGF0YS5zdW0sIHZhbHVlKSAtIHZhbHVlKSkgKyBvZmZzZXQ7XHJcblxyXG4gICAgICAgIC8vIHJlbmRlcmluZyByZWN0IGZvciBuZWdhdGl2ZSB1c2VzIHZhbHVlcyBsZXNzZXIgYnkgb25lIGluZGV4LiBlZzogZmlyc3QgdmFsdWUgPSAtMiwgc3VtID0gLTIsIHJlbmRlcnMgMC4uLi4gc2Vjb25kIHZhbHVlID0gLTQsIHN1bSA9IC02LCByZW5kZXJzIC0yXHJcbiAgICAgICAgZnVuY3Rpb24gbmVnYXRpdmVSZWNhbChfc3VtOiBudW1iZXIsIF92YWx1ZTogbnVtYmVyKTogbnVtYmVyIHtcclxuICAgICAgICAgICAgcmV0dXJuIE1hdGguc2lnbihfc3VtKSA8IDAgPyBfc3VtIC0gX3ZhbHVlIDogX3N1bTtcclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfc2V0QmFyQ2hhcnRMYWJlbChfZDogSUQzRGF0YURhdGEsIF94SW5kZXg6IG51bWJlciwgX2dyb3VwOiBJUmVjdEdyb3VwKTogdm9pZCB7XHJcbiAgICAgICAgZm9yIChsZXQgeUluZGV4ID0gMDsgeUluZGV4IDwgX2QueS5sZW5ndGg7ICsreUluZGV4KSB7XHJcbiAgICAgICAgICAgIGlmIChfZC55W3lJbmRleF0udmFsdWUgPT09IG51bGwpIGNvbnRpbnVlO1xyXG5cclxuICAgICAgICAgICAgbGV0IHlEYXRhOiBJRDNZRGF0YSA9IE9iamVjdC5hc3NpZ24oe30sIF9kLnlbeUluZGV4XSksXHJcbiAgICAgICAgICAgICAgICBkaW1lbnNpb25zOiBJQmFyUmVjdERpbWVuc2lvbnMgPSB7XHJcbiAgICAgICAgICAgICAgICAgICAgeVBvczogX2dyb3VwLnlQb3NBcnJbeUluZGV4XSxcclxuICAgICAgICAgICAgICAgICAgICB4UG9zOiBfZ3JvdXAueFBvc0Fyclt5SW5kZXhdLFxyXG4gICAgICAgICAgICAgICAgICAgIGhlaWdodDogdGhpcy5jaGFydFR5cGVbMF0gPT09ICdjb2x1bW4nID8gX2dyb3VwLmhlaWdodEFyclt5SW5kZXhdIDogX2dyb3VwLmhlaWdodEFyclswXSxcclxuICAgICAgICAgICAgICAgICAgICB3aWR0aDogdGhpcy5jaGFydFR5cGVbMF0gPT09ICdjb2x1bW4nID8gX2dyb3VwLndpZHRoQXJyWzBdIDogX2dyb3VwLndpZHRoQXJyW3lJbmRleF1cclxuICAgICAgICAgICAgICAgIH07XHJcblxyXG4gICAgICAgICAgICBpZiAoIXRoaXMuY29uZmlnLmNoYXJ0LmxhYmVscy5pbnNpZGUpIHtcclxuICAgICAgICAgICAgICAgIGlmICh0aGlzLmNoYXJ0VHlwZVswXSA9PT0gJ2NvbHVtbicpIHtcclxuICAgICAgICAgICAgICAgICAgICBpZiAoKHlEYXRhLnZhbHVlIDwgMCAmJiAhdGhpcy5fY2hhcnRTdmMuaXNZUmV2ZXJzZWQpIHx8ICh5RGF0YS52YWx1ZSA+IDAgJiYgdGhpcy5fY2hhcnRTdmMuaXNZUmV2ZXJzZWQpKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGRpbWVuc2lvbnMueVBvcyArPSBfZ3JvdXAuaGVpZ2h0QXJyW3lJbmRleF07XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIC8vIHdoZW4gcnRsLCBkaXYgc3RhcnRzIGF0IHRvcCByaWdodCBvZiByZWN0XHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKHRoaXMuaXNSdGwpIGRpbWVuc2lvbnMueFBvcyArPSBfZ3JvdXAud2lkdGhBcnJbMF07XHJcbiAgICAgICAgICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgICAgIGlmICgoeURhdGEudmFsdWUgPiAwICYmICF0aGlzLl9jaGFydFN2Yy5pc1lSZXZlcnNlZCkgfHwgKHlEYXRhLnZhbHVlIDwgMCAmJiB0aGlzLl9jaGFydFN2Yy5pc1lSZXZlcnNlZCkpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgZGltZW5zaW9ucy54UG9zICs9IF9ncm91cC53aWR0aEFyclt5SW5kZXhdO1xyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgICAgIGlmICh0aGlzLmlzUnRsKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgLy8gd2hlbiBydGwsXHJcbiAgICAgICAgICAgICAgICAgICAgLy8gZm9yIENvbHVtbiwgZGl2IHN0YXJ0cyBhdCB0b3AgcmlnaHQgb2YgcmVjdFxyXG4gICAgICAgICAgICAgICAgICAgIC8vIGZvciBCYXIsIGRpdiBzdGFydCBhdCBlbmQgb2YgcmVjdCBhbmQgdGFrZSB0aGUgd2lkdGggb2YgYmFyc1xyXG4gICAgICAgICAgICAgICAgICAgIGxldCBpbmRleCA9IHRoaXMuY2hhcnRUeXBlWzBdID09PSAnY29sdW1uJyA/IDAgOiB5SW5kZXg7XHJcbiAgICAgICAgICAgICAgICAgICAgZGltZW5zaW9ucy54UG9zICs9IF9ncm91cC53aWR0aEFycltpbmRleF07XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgaWYgKHRoaXMuX2NoYXJ0U3ZjLmlzTmVnYXRpdmVTdGFjaykgeURhdGEudmFsdWUgPSB0aGlzLl9jaGFydFN2Yy5jaGVja0FuZFJldHVybkxhYmVsc1Bvc2l0aXZlKHlEYXRhLnZhbHVlKTtcclxuXHJcbiAgICAgICAgICAgIGxldCBsYWJlbENvbnRhaW5lcjogYW55ID0gc3VwZXIuc2V0TGFiZWwoeURhdGEsIF94SW5kZXgsIGRpbWVuc2lvbnMueFBvcywgZGltZW5zaW9ucy55UG9zKTtcclxuXHJcbiAgICAgICAgICAgIC8vIHZhbHVlIGhlcmUgaXMgcmF3VmFsdWUgKG5lZ2F0aXZlU3RhY2tCYXIgbWF5IGhhdmUgY2hhbmdlZCB5RGF0YS52YWx1ZSlcclxuICAgICAgICAgICAgdGhpcy5fc2V0TGFiZWxTdHlsZShsYWJlbENvbnRhaW5lciwgX2QueVt5SW5kZXhdLnZhbHVlLCBkaW1lbnNpb25zKTtcclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgLy8gZm9yIGNvbHVtbiwgd2lkdGggaXMgY29uc3RhbnQsIGhlaWdodCBpcyB2YXJ5XHJcbiAgICAvLyBmb3IgYmFyLCBoZWlnaHQgaXMgY29uc3RhbnQsIHdpZHRoIGlzIHZhcnlcclxuICAgIHByaXZhdGUgX3NldExhYmVsU3R5bGUoX2xhYmVsQ29udGFpbmVyLCBfdmFsdWU6IG51bWJlciwgX2RpbWVuc2lvbnM6IElCYXJSZWN0RGltZW5zaW9ucyk6IHZvaWQge1xyXG4gICAgICAgIGxldCBsYWJlbFRleHQ6IGFueSA9IF9sYWJlbENvbnRhaW5lci5zZWxlY3QoJy5rZHgtY2hhcnRzLWRhdGEtbGFiZWwtdGV4dCcpO1xyXG4gICAgICAgIGxldCB2ZXJ0aWNhbEFsaWduID0gdGhpcy5jb25maWcuY2hhcnQubGFiZWxzLnZlcnRpY2FsQWxpZ247XHJcbiAgICAgICAgbGV0IGluc2lkZTogYm9vbGVhbiA9IHRoaXMuY29uZmlnLmNoYXJ0LmxhYmVscy5pbnNpZGU7XHJcbiAgICAgICAgbGV0IHNpZ246IG51bWJlciA9IE1hdGguc2lnbihfdmFsdWUpO1xyXG4gICAgICAgIGlmICghdmVydGljYWxBbGlnbikgdmVydGljYWxBbGlnbiA9IHRoaXMuY2hhcnRUeXBlWzBdID09PSAnY29sdW1uJyA/ICd0b3AnIDogJ21pZGRsZSc7XHJcblxyXG4gICAgICAgIHRoaXMuX2JhclN2Yy5zZXRMYWJlbENvbnRhaW5lcldpZHRoT3JIZWlnaHQoX2xhYmVsQ29udGFpbmVyLCB0aGlzLmNoYXJ0VHlwZVswXSwgaW5zaWRlLCBfZGltZW5zaW9ucyk7XHJcblxyXG4gICAgICAgIC8vIGlmIGxhYmVsIGlzIGhpZ2hlciB0aGFuIGJhcidzL2NvbHVtbidzIGhlaWdodFxyXG4gICAgICAgIGxldCBpc0xhYmVsSGlnaGVyVGhhblJlY3QgPSB0aGlzLl9jaGFydFN2Yy5fZ2V0TGFiZWxUZXh0SGVpZ2h0KCkgPiBfZGltZW5zaW9ucy5oZWlnaHQ7XHJcbiAgICAgICAgaWYgKGlzTGFiZWxIaWdoZXJUaGFuUmVjdCkge1xyXG4gICAgICAgICAgICBpZiAodGhpcy5jaGFydFR5cGVbMF0gPT09ICdiYXInKSB7XHJcbiAgICAgICAgICAgICAgICB2ZXJ0aWNhbEFsaWduID0gJ21pZGRsZSc7XHJcbiAgICAgICAgICAgIH0gZWxzZSBpZiAoaW5zaWRlKSB7XHJcbiAgICAgICAgICAgICAgICAvLyBpZiBjb2x1bW4gYW5kIGluc2lkZSwgdG8gbWFrZSBzdXJlIGxhYmVsIHdpbGwgbm90IGhpdCBpbnRvIGF4aXMsXHJcbiAgICAgICAgICAgICAgICAvLyBpZiBheGlzIGlzIGF0IGJvdHRvbSBvZiBjaGFydCwgc2V0IHRvIGZsZXgtZW5kIHNvIHRoYXQgdGV4dCB3aWxsIGJlIHBsYWNlZCBhYm92ZVxyXG4gICAgICAgICAgICAgICAgLy8gaWYgYXhpcyBpcyBhdCB0b3Agb2YgY2hhcnQsIHNldCB0byBmbGV4LXN0YXJ0IHNvIHRoYXQgdGV4dCB3aWxsIGJlIHBsYWNlZCBiZWxvd1xyXG4gICAgICAgICAgICAgICAgdmVydGljYWxBbGlnbiA9IHRoaXMuX2NoYXJ0U3ZjLmlzWVJldmVyc2VkID8gJ3RvcCcgOiAnYm90dG9tJztcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgaWYgKCFpbnNpZGUpIHtcclxuICAgICAgICAgICAgaWYgKHRoaXMuY2hhcnRUeXBlWzBdID09PSAnYmFyJykge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5fYmFyU3ZjLl9zZXRMYWJlbFRleHRQb3NIb3Jpem9udGFsKFxyXG4gICAgICAgICAgICAgICAgICAgIGxhYmVsVGV4dCxcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLl9jaGFydFN2Yy5pc1lSZXZlcnNlZCxcclxuICAgICAgICAgICAgICAgICAgICB7IHhQb3M6IF9kaW1lbnNpb25zLnhQb3MsIGNoYXJ0V2lkdGg6IHRoaXMud2lkdGgsIHZhbHVlU2lnbjogc2lnbiB9XHJcbiAgICAgICAgICAgICAgICApO1xyXG4gICAgICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgbGV0IHBhcmFtcyA9IHsgdmFsdWVTaWduOiBzaWduIH07XHJcbiAgICAgICAgICAgICAgICBsZXQgeVBvcyA9IF9kaW1lbnNpb25zLnlQb3M7IC8vIHVzZWQgZm9yIGJvdW5kYXJ5IGNoZWNraW5nLlxyXG4gICAgICAgICAgICAgICAgaWYgKGlzTGFiZWxIaWdoZXJUaGFuUmVjdCAmJiB0aGlzLmNoYXJ0VHlwZVsxXSA9PT0gJ2NsdXN0ZXInKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgcGFyYW1zWydkaW1lbnNpb25zJ10gPSBfZGltZW5zaW9ucztcclxuICAgICAgICAgICAgICAgICAgICBsZXQgbmVlZE9mZnNldDogYW55ID0gdGhpcy5fY2hhcnRTdmMubmVlZE9mZnNldEZvckNvbHVtbih2ZXJ0aWNhbEFsaWduLCBwYXJhbXMpO1xyXG4gICAgICAgICAgICAgICAgICAgIGlmIChuZWVkT2Zmc2V0KSB5UG9zICs9IG5lZWRPZmZzZXQgKiBfZGltZW5zaW9ucy5oZWlnaHQ7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICBzdXBlci5zZXRMYWJlbFRleHRQb3NpdGlvbihsYWJlbFRleHQsIHlQb3MsIHBhcmFtcyk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcblxyXG5cclxuICAgICAgICB0aGlzLl9iYXJTdmMuc2V0VmVydGljYWxBbGlnbkNTUyhfbGFiZWxDb250YWluZXIsIHZlcnRpY2FsQWxpZ24pO1xyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX2Rpc3BsYXlBbGxMYWJlbCgpOiB2b2lkIHtcclxuICAgICAgICB0aGlzLmRhdGFMYWJlbENvbnRhaW5lclxyXG4gICAgICAgICAgICAuc2VsZWN0QWxsKCcua2R4LWNoYXJ0cy1kYXRhLWxhYmVsJylcclxuICAgICAgICAgICAgLnN0eWxlKCd2aXNpYmlsaXR5JywgJ3Zpc2libGUnKTtcclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF9nZXRSZWN0UG9zSW5mbygpOiBJUmVjdFBvc0luZm8ge1xyXG4gICAgICAgIGlmICh0aGlzLmNoYXJ0VHlwZVsxXSA9PT0gJ2NsdXN0ZXInKSB7XHJcbiAgICAgICAgICAgIC8vIHRoZSBhbW91bnQgb2YgeURhdGEgZm9yIGVhY2ggeCB2YWx1ZSB3aWxsIGFsd2F5cyBiZSB0aGUgc2FtZSAoaWYgd2UgZG9uJ3QgcmVtb3ZlIG51bGwgdmFsdWVzKVxyXG4gICAgICAgICAgICAvLyBoZW5jZSB0aGlzIGNhbGN1bGF0aW9uIG9ubHkgbmVlZHMgdG8gcnVuIG9uY2VcclxuICAgICAgICAgICAgbGV0IHlBcnJMZW5ndGggPSB0aGlzLmRhdGFbMF0gJiYgdGhpcy5kYXRhWzBdLnkgPyB0aGlzLmRhdGFbMF0ueS5sZW5ndGggOiAwO1xyXG4gICAgICAgICAgICByZXR1cm4gdGhpcy5fYmFyU3ZjLmdldFJlY3RXaWR0aCh0aGlzLnguYmFuZHdpZHRoKCksIHRoaXMuYmFyLmNsdXN0ZXJQYWRkaW5nUGVyY2VudCwgeUFyckxlbmd0aCk7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIHJldHVybiB7XHJcbiAgICAgICAgICAgIHdpZHRoOiB0aGlzLnguYmFuZHdpZHRoKCksXHJcbiAgICAgICAgICAgIHBhZGRpbmc6IDBcclxuICAgICAgICB9O1xyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgbmVnYXRpdmVTdGFja1N5bW1ldHJ5TG9naWMoKTogdm9pZCB7XHJcbiAgICAgICAgbGV0IHJlc3VsdDogSU5lZ2F0aXZlU3RhY2tMb2dpY1JldHVybiA9IHRoaXMuX2JhclN2Yy5hcHBseVN5bW1ldHJpY0F4aXModGhpcy5kYXRhUmFuZ2UsIHRoaXMuY29uZmlnLnBsb3RPcHRpb25zLCB0aGlzLmNvbmZpZy55QXhpcyk7XHJcbiAgICAgICAgaWYgKHJlc3VsdC5oYXNPd25Qcm9wZXJ0eSgnZGF0YVJhbmdlJykpIHRoaXMuZGF0YVJhbmdlID0gcmVzdWx0LmRhdGFSYW5nZTtcclxuICAgICAgICBpZiAocmVzdWx0Lmhhc093blByb3BlcnR5KCd5QXhpcycpKSB7XHJcbiAgICAgICAgICAgIHRoaXMuY29uZmlnLnlBeGlzID0gT2JqZWN0LmFzc2lnbih7fSwgdGhpcy5jb25maWcueUF4aXMsIHJlc3VsdC55QXhpcyk7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG59XHJcbiJdfQ==