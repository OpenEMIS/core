import { Injectable } from '@angular/core';
import { KdBroadcaster } from '../kd-common/index';
import * as i0 from "@angular/core";
import * as i1 from "../kd-common/kd-broadcaster-svc";
export class KdIntSearchEvent {
    constructor(_broadcaster) {
        this._broadcaster = _broadcaster;
    }
    onDisableButton() {
        return this._broadcaster.on('KdDisableButton');
    }
}
KdIntSearchEvent.decorators = [
    { type: Injectable }
];
KdIntSearchEvent.ctorParameters = () => [
    { type: KdBroadcaster }
];
export class KdSearchEvent {
    constructor(_broadcaster) {
        this._broadcaster = _broadcaster;
    }
    disableButton(data) {
        this._broadcaster.broadcast('KdDisableButton', data);
    }
}
KdSearchEvent.ɵprov = i0.ɵɵdefineInjectable({ factory: function KdSearchEvent_Factory() { return new KdSearchEvent(i0.ɵɵinject(i1.KdBroadcaster)); }, token: KdSearchEvent, providedIn: "root" });
KdSearchEvent.decorators = [
    { type: Injectable, args: [{
                providedIn: 'root'
            },] }
];
KdSearchEvent.ctorParameters = () => [
    { type: KdBroadcaster }
];
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoia2Qtc2VhcmNoLWV2ZW50LmpzIiwic291cmNlUm9vdCI6IkM6L3hhbXBwL2h0ZG9jcy9TdHlsZWd1aWRlL2lvc3RnLW9wZW5lbWlzLXN0eWxlZ3VpZGUvcHJvamVjdHMvb3BlbmVtaXMtc3R5bGVndWlkZS1saWIvc3JjLyIsInNvdXJjZXMiOlsia2QtY29tcG9uZW50cy9rZC1hbmd1bGFyLXNlYXJjaC9rZC1zZWFyY2gtZXZlbnQudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsT0FBTyxFQUFFLFVBQVUsRUFBRSxNQUFNLGVBQWUsQ0FBQztBQUUzQyxPQUFPLEVBQUUsYUFBYSxFQUFFLE1BQU0sb0JBQW9CLENBQUM7OztBQUduRCxNQUFNLE9BQU8sZ0JBQWdCO0lBQ3pCLFlBQW9CLFlBQTJCO1FBQTNCLGlCQUFZLEdBQVosWUFBWSxDQUFlO0lBQUksQ0FBQztJQUVwRCxlQUFlO1FBQ1gsT0FBTyxJQUFJLENBQUMsWUFBWSxDQUFDLEVBQUUsQ0FBTSxpQkFBaUIsQ0FBQyxDQUFDO0lBQ3hELENBQUM7OztZQU5KLFVBQVU7OztZQUZGLGFBQWE7O0FBY3RCLE1BQU0sT0FBTyxhQUFhO0lBQ3RCLFlBQW9CLFlBQTJCO1FBQTNCLGlCQUFZLEdBQVosWUFBWSxDQUFlO0lBQUksQ0FBQztJQUVwRCxhQUFhLENBQUMsSUFBVTtRQUNwQixJQUFJLENBQUMsWUFBWSxDQUFDLFNBQVMsQ0FBQyxpQkFBaUIsRUFBRSxJQUFJLENBQUMsQ0FBQztJQUN6RCxDQUFDOzs7O1lBUkosVUFBVSxTQUFDO2dCQUNSLFVBQVUsRUFBRSxNQUFNO2FBQ3JCOzs7WUFiUSxhQUFhIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgSW5qZWN0YWJsZSB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xyXG5pbXBvcnQgeyBPYnNlcnZhYmxlIH0gZnJvbSAncnhqcyc7XHJcbmltcG9ydCB7IEtkQnJvYWRjYXN0ZXIgfSBmcm9tICcuLi9rZC1jb21tb24vaW5kZXgnO1xyXG5cclxuQEluamVjdGFibGUoKVxyXG5leHBvcnQgY2xhc3MgS2RJbnRTZWFyY2hFdmVudCB7XHJcbiAgICBjb25zdHJ1Y3Rvcihwcml2YXRlIF9icm9hZGNhc3RlcjogS2RCcm9hZGNhc3RlcikgeyB9XHJcblxyXG4gICAgb25EaXNhYmxlQnV0dG9uKCk6IE9ic2VydmFibGU8YW55PiB7XHJcbiAgICAgICAgcmV0dXJuIHRoaXMuX2Jyb2FkY2FzdGVyLm9uPGFueT4oJ0tkRGlzYWJsZUJ1dHRvbicpO1xyXG4gICAgfVxyXG59XHJcblxyXG5ASW5qZWN0YWJsZSh7XHJcbiAgICBwcm92aWRlZEluOiAncm9vdCdcclxufSlcclxuZXhwb3J0IGNsYXNzIEtkU2VhcmNoRXZlbnQge1xyXG4gICAgY29uc3RydWN0b3IocHJpdmF0ZSBfYnJvYWRjYXN0ZXI6IEtkQnJvYWRjYXN0ZXIpIHsgfVxyXG5cclxuICAgIGRpc2FibGVCdXR0b24oZGF0YT86IGFueSk6IHZvaWQge1xyXG4gICAgICAgIHRoaXMuX2Jyb2FkY2FzdGVyLmJyb2FkY2FzdCgnS2REaXNhYmxlQnV0dG9uJywgZGF0YSk7XHJcbiAgICB9XHJcbn1cclxuIl19