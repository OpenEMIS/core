import { Component, ViewEncapsulation, Input, Output, EventEmitter } from '@angular/core';
import { KdIntSearchEvent } from './kd-search-event';
export { KdSearchEvent } from './kd-search-event';
export class KdSearch {
    constructor(_searchEvent) {
        this._searchEvent = _searchEvent;
        this._result = {};
        this._searchSettings = {};
        this._disable = false;
        this._defaultSettings = {
            title: 'Directory',
            searchPlaceholder: 'Search',
            description: 'Search Directory',
            filter: false,
            options: []
        };
        this.searchBtnClicked = new EventEmitter();
        this.advSearchBtnClicked = new EventEmitter();
    }
    ngOnInit() {
        this._searchSettings = Object.assign({}, this._defaultSettings, this.config);
        if (this._searchSettings.filter)
            this._result.optionVal = '';
        this._searchSub = this._searchEvent.onDisableButton().subscribe(data => {
            if (typeof data !== 'undefined')
                this._disable = data;
            else
                this._disable = !this._disable;
        });
    }
    ngOnDestroy() {
        this._searchSub.unsubscribe();
    }
    searchClicked(isSearch) {
        if (isSearch)
            this.searchBtnClicked.emit(this._result);
        else
            this.advSearchBtnClicked.emit(this._result);
    }
}
KdSearch.decorators = [
    { type: Component, args: [{
                selector: 'kd-search',
                template: `
        <div class="search-page-wrapper">
            <div class="search-page-box">
                <div class="search-title">
                    <h1>{{_searchSettings.title}}</h1>
                    <p *ngIf="_searchSettings.description">{{_searchSettings.description}}</p>
                </div>
                <div class="search-body">
                    <input type="text" [(ngModel)]="_result.searchText" placeholder="{{_searchSettings.searchPlaceholder}}"/>
                    <div *ngIf="_searchSettings.filter" class="kdx-input-select-wrapper">
                        <select [(ngModel)]="_result.optionVal">
                            <option *ngFor="let item of _searchSettings.options" [value]="item.key">{{item.value}}</option>
                        </select>
                    </div>
                </div>
                <div class="search-buttons">
                    <button class="btn btn-text" [disabled]="_disable" (click)="searchClicked(true)">Search </button>
                    <button class="btn btn-text" [disabled]="_disable" (click)="searchClicked(false)">Advance Search</button>
                </div>
            </div>
        </div>
    `,
                encapsulation: ViewEncapsulation.None,
                providers: [KdIntSearchEvent],
                host: { 'class': 'kdx kdx-search' }
            },] }
];
KdSearch.ctorParameters = () => [
    { type: KdIntSearchEvent }
];
KdSearch.propDecorators = {
    config: [{ type: Input }],
    searchBtnClicked: [{ type: Output }],
    advSearchBtnClicked: [{ type: Output }]
};
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoia2QtYW5ndWxhci1zZWFyY2guanMiLCJzb3VyY2VSb290IjoiQzoveGFtcHAvaHRkb2NzL1N0eWxlZ3VpZGUvaW9zdGctb3BlbmVtaXMtc3R5bGVndWlkZS9wcm9qZWN0cy9vcGVuZW1pcy1zdHlsZWd1aWRlLWxpYi9zcmMvIiwic291cmNlcyI6WyJrZC1jb21wb25lbnRzL2tkLWFuZ3VsYXItc2VhcmNoL2tkLWFuZ3VsYXItc2VhcmNoLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBLE9BQU8sRUFDSCxTQUFTLEVBR1QsaUJBQWlCLEVBQ2pCLEtBQUssRUFDTCxNQUFNLEVBQ04sWUFBWSxFQUNmLE1BQU0sZUFBZSxDQUFDO0FBRXZCLE9BQU8sRUFBRSxnQkFBZ0IsRUFBRSxNQUFNLG1CQUFtQixDQUFDO0FBQ3JELE9BQU8sRUFBRSxhQUFhLEVBQUUsTUFBTSxtQkFBbUIsQ0FBQztBQStCbEQsTUFBTSxPQUFPLFFBQVE7SUFrQmpCLFlBQ1ksWUFBOEI7UUFBOUIsaUJBQVksR0FBWixZQUFZLENBQWtCO1FBbEJuQyxZQUFPLEdBQVEsRUFBRSxDQUFDO1FBQ2xCLG9CQUFlLEdBQVEsRUFBRSxDQUFDO1FBQzFCLGFBQVEsR0FBWSxLQUFLLENBQUM7UUFFekIscUJBQWdCLEdBQVE7WUFDNUIsS0FBSyxFQUFFLFdBQVc7WUFDbEIsaUJBQWlCLEVBQUUsUUFBUTtZQUMzQixXQUFXLEVBQUUsa0JBQWtCO1lBQy9CLE1BQU0sRUFBRSxLQUFLO1lBQ2IsT0FBTyxFQUFFLEVBQUU7U0FDZCxDQUFDO1FBSVEscUJBQWdCLEdBQXNCLElBQUksWUFBWSxFQUFFLENBQUM7UUFDekQsd0JBQW1CLEdBQXNCLElBQUksWUFBWSxFQUFFLENBQUM7SUFJbEUsQ0FBQztJQUVMLFFBQVE7UUFDSixJQUFJLENBQUMsZUFBZSxHQUFHLE1BQU0sQ0FBQyxNQUFNLENBQUMsRUFBRSxFQUFFLElBQUksQ0FBQyxnQkFBZ0IsRUFBRSxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUM7UUFDN0UsSUFBSSxJQUFJLENBQUMsZUFBZSxDQUFDLE1BQU07WUFBRSxJQUFJLENBQUMsT0FBTyxDQUFDLFNBQVMsR0FBRyxFQUFFLENBQUM7UUFFN0QsSUFBSSxDQUFDLFVBQVUsR0FBRyxJQUFJLENBQUMsWUFBWSxDQUFDLGVBQWUsRUFBRSxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsRUFBRTtZQUNuRSxJQUFJLE9BQU8sSUFBSSxLQUFLLFdBQVc7Z0JBQUUsSUFBSSxDQUFDLFFBQVEsR0FBRyxJQUFJLENBQUM7O2dCQUNqRCxJQUFJLENBQUMsUUFBUSxHQUFHLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQztRQUN4QyxDQUFDLENBQUMsQ0FBQztJQUNQLENBQUM7SUFFRCxXQUFXO1FBQ1AsSUFBSSxDQUFDLFVBQVUsQ0FBQyxXQUFXLEVBQUUsQ0FBQztJQUNsQyxDQUFDO0lBRU0sYUFBYSxDQUFDLFFBQWlCO1FBQ2xDLElBQUksUUFBUTtZQUFFLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxDQUFDOztZQUNsRCxJQUFJLENBQUMsbUJBQW1CLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsQ0FBQztJQUNyRCxDQUFDOzs7WUFwRUosU0FBUyxTQUFDO2dCQUNQLFFBQVEsRUFBRSxXQUFXO2dCQUNyQixRQUFRLEVBQUU7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztLQXFCVDtnQkFDRCxhQUFhLEVBQUUsaUJBQWlCLENBQUMsSUFBSTtnQkFDckMsU0FBUyxFQUFFLENBQUMsZ0JBQWdCLENBQUM7Z0JBQzdCLElBQUksRUFBRSxFQUFFLE9BQU8sRUFBRyxnQkFBZ0IsRUFBRTthQUN2Qzs7O1lBOUJRLGdCQUFnQjs7O3FCQThDcEIsS0FBSzsrQkFDTCxNQUFNO2tDQUNOLE1BQU0iLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQge1xyXG4gICAgQ29tcG9uZW50LFxyXG4gICAgT25Jbml0LFxyXG4gICAgT25EZXN0cm95LFxyXG4gICAgVmlld0VuY2Fwc3VsYXRpb24sXHJcbiAgICBJbnB1dCxcclxuICAgIE91dHB1dCxcclxuICAgIEV2ZW50RW1pdHRlclxyXG59IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xyXG5pbXBvcnQgeyBTdWJzY3JpcHRpb24gfSBmcm9tICdyeGpzJztcclxuaW1wb3J0IHsgS2RJbnRTZWFyY2hFdmVudCB9IGZyb20gJy4va2Qtc2VhcmNoLWV2ZW50JztcclxuZXhwb3J0IHsgS2RTZWFyY2hFdmVudCB9IGZyb20gJy4va2Qtc2VhcmNoLWV2ZW50JztcclxuXHJcbkBDb21wb25lbnQoe1xyXG4gICAgc2VsZWN0b3I6ICdrZC1zZWFyY2gnLFxyXG4gICAgdGVtcGxhdGU6IGBcclxuICAgICAgICA8ZGl2IGNsYXNzPVwic2VhcmNoLXBhZ2Utd3JhcHBlclwiPlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzPVwic2VhcmNoLXBhZ2UtYm94XCI+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwic2VhcmNoLXRpdGxlXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPGgxPnt7X3NlYXJjaFNldHRpbmdzLnRpdGxlfX08L2gxPlxyXG4gICAgICAgICAgICAgICAgICAgIDxwICpuZ0lmPVwiX3NlYXJjaFNldHRpbmdzLmRlc2NyaXB0aW9uXCI+e3tfc2VhcmNoU2V0dGluZ3MuZGVzY3JpcHRpb259fTwvcD5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cInNlYXJjaC1ib2R5XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPGlucHV0IHR5cGU9XCJ0ZXh0XCIgWyhuZ01vZGVsKV09XCJfcmVzdWx0LnNlYXJjaFRleHRcIiBwbGFjZWhvbGRlcj1cInt7X3NlYXJjaFNldHRpbmdzLnNlYXJjaFBsYWNlaG9sZGVyfX1cIi8+XHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiAqbmdJZj1cIl9zZWFyY2hTZXR0aW5ncy5maWx0ZXJcIiBjbGFzcz1cImtkeC1pbnB1dC1zZWxlY3Qtd3JhcHBlclwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8c2VsZWN0IFsobmdNb2RlbCldPVwiX3Jlc3VsdC5vcHRpb25WYWxcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24gKm5nRm9yPVwibGV0IGl0ZW0gb2YgX3NlYXJjaFNldHRpbmdzLm9wdGlvbnNcIiBbdmFsdWVdPVwiaXRlbS5rZXlcIj57e2l0ZW0udmFsdWV9fTwvb3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L3NlbGVjdD5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cInNlYXJjaC1idXR0b25zXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPGJ1dHRvbiBjbGFzcz1cImJ0biBidG4tdGV4dFwiIFtkaXNhYmxlZF09XCJfZGlzYWJsZVwiIChjbGljayk9XCJzZWFyY2hDbGlja2VkKHRydWUpXCI+U2VhcmNoIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgICAgIDxidXR0b24gY2xhc3M9XCJidG4gYnRuLXRleHRcIiBbZGlzYWJsZWRdPVwiX2Rpc2FibGVcIiAoY2xpY2spPVwic2VhcmNoQ2xpY2tlZChmYWxzZSlcIj5BZHZhbmNlIFNlYXJjaDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgYCxcclxuICAgIGVuY2Fwc3VsYXRpb246IFZpZXdFbmNhcHN1bGF0aW9uLk5vbmUsXHJcbiAgICBwcm92aWRlcnM6IFtLZEludFNlYXJjaEV2ZW50XSxcclxuICAgIGhvc3Q6IHsgJ2NsYXNzJyA6ICdrZHgga2R4LXNlYXJjaCcgfVxyXG59KVxyXG5cclxuZXhwb3J0IGNsYXNzIEtkU2VhcmNoIGltcGxlbWVudHMgT25Jbml0LCBPbkRlc3Ryb3kge1xyXG4gICAgcHVibGljIF9yZXN1bHQ6IGFueSA9IHt9O1xyXG4gICAgcHVibGljIF9zZWFyY2hTZXR0aW5nczogYW55ID0ge307XHJcbiAgICBwdWJsaWMgX2Rpc2FibGU6IGJvb2xlYW4gPSBmYWxzZTtcclxuXHJcbiAgICBwcml2YXRlIF9kZWZhdWx0U2V0dGluZ3M6IGFueSA9IHtcclxuICAgICAgICB0aXRsZTogJ0RpcmVjdG9yeScsXHJcbiAgICAgICAgc2VhcmNoUGxhY2Vob2xkZXI6ICdTZWFyY2gnLFxyXG4gICAgICAgIGRlc2NyaXB0aW9uOiAnU2VhcmNoIERpcmVjdG9yeScsXHJcbiAgICAgICAgZmlsdGVyOiBmYWxzZSxcclxuICAgICAgICBvcHRpb25zOiBbXVxyXG4gICAgfTtcclxuICAgIHByaXZhdGUgX3NlYXJjaFN1YjogU3Vic2NyaXB0aW9uO1xyXG5cclxuICAgIEBJbnB1dCgpIGNvbmZpZzogYW55O1xyXG4gICAgQE91dHB1dCgpIHNlYXJjaEJ0bkNsaWNrZWQ6IEV2ZW50RW1pdHRlcjxhbnk+ID0gbmV3IEV2ZW50RW1pdHRlcigpO1xyXG4gICAgQE91dHB1dCgpIGFkdlNlYXJjaEJ0bkNsaWNrZWQ6IEV2ZW50RW1pdHRlcjxhbnk+ID0gbmV3IEV2ZW50RW1pdHRlcigpO1xyXG5cclxuICAgIGNvbnN0cnVjdG9yKFxyXG4gICAgICAgIHByaXZhdGUgX3NlYXJjaEV2ZW50OiBLZEludFNlYXJjaEV2ZW50XHJcbiAgICApIHsgfVxyXG5cclxuICAgIG5nT25Jbml0KCk6IHZvaWQge1xyXG4gICAgICAgIHRoaXMuX3NlYXJjaFNldHRpbmdzID0gT2JqZWN0LmFzc2lnbih7fSwgdGhpcy5fZGVmYXVsdFNldHRpbmdzLCB0aGlzLmNvbmZpZyk7XHJcbiAgICAgICAgaWYgKHRoaXMuX3NlYXJjaFNldHRpbmdzLmZpbHRlcikgdGhpcy5fcmVzdWx0Lm9wdGlvblZhbCA9ICcnO1xyXG5cclxuICAgICAgICB0aGlzLl9zZWFyY2hTdWIgPSB0aGlzLl9zZWFyY2hFdmVudC5vbkRpc2FibGVCdXR0b24oKS5zdWJzY3JpYmUoZGF0YSA9PiB7XHJcbiAgICAgICAgICAgIGlmICh0eXBlb2YgZGF0YSAhPT0gJ3VuZGVmaW5lZCcpIHRoaXMuX2Rpc2FibGUgPSBkYXRhO1xyXG4gICAgICAgICAgICBlbHNlIHRoaXMuX2Rpc2FibGUgPSAhdGhpcy5fZGlzYWJsZTtcclxuICAgICAgICB9KTtcclxuICAgIH1cclxuXHJcbiAgICBuZ09uRGVzdHJveSgpOiB2b2lkIHtcclxuICAgICAgICB0aGlzLl9zZWFyY2hTdWIudW5zdWJzY3JpYmUoKTtcclxuICAgIH1cclxuXHJcbiAgICBwdWJsaWMgc2VhcmNoQ2xpY2tlZChpc1NlYXJjaDogYm9vbGVhbik6IHZvaWQge1xyXG4gICAgICAgIGlmIChpc1NlYXJjaCkgdGhpcy5zZWFyY2hCdG5DbGlja2VkLmVtaXQodGhpcy5fcmVzdWx0KTtcclxuICAgICAgICBlbHNlIHRoaXMuYWR2U2VhcmNoQnRuQ2xpY2tlZC5lbWl0KHRoaXMuX3Jlc3VsdCk7XHJcbiAgICB9XHJcbn1cclxuIl19