import { Injectable } from '@angular/core';
export class KdLoginSvc {
    getHeaderConfigValues(_config, _defaultConfig) {
        let updateHeaderConfig = {};
        if (typeof _config === 'undefined' || typeof _config.header === 'undefined') {
            if (typeof _defaultConfig !== 'undefined')
                updateHeaderConfig = JSON.parse(JSON.stringify(_defaultConfig));
            else
                updateHeaderConfig = { icon: 'kd-openemis', title: 'OpenEMIS' };
        }
        else {
            updateHeaderConfig = _config.header;
            if (typeof updateHeaderConfig.img !== 'undefined' && typeof updateHeaderConfig.icon !== 'undefined')
                updateHeaderConfig.img = '';
            if (typeof updateHeaderConfig.img === 'undefined' && typeof updateHeaderConfig.icon === 'undefined')
                updateHeaderConfig.icon = '';
            if (typeof updateHeaderConfig.icon !== 'undefined' && typeof updateHeaderConfig.title === 'undefined')
                updateHeaderConfig.title = '';
            if (typeof updateHeaderConfig.img !== 'undefined' && typeof updateHeaderConfig.imgSize === 'undefined')
                updateHeaderConfig.imgSize = 'none';
            if (typeof updateHeaderConfig.headerMsg !== 'undefined' && typeof updateHeaderConfig.headerMsg === 'undefined')
                updateHeaderConfig.headerMsg = '';
        }
        return this._setProductAppConfig(updateHeaderConfig);
    }
    /*
        set default language config
            - if config is undefined, langunage undefined, show undefined - return default
                - if config list is defined, list got item, and show is true - set config to show with toggle
                - else if config default is defined - set config with default language and toggle false
        - return config
     */
    getLanguageConfigValues(_config) {
        if (_config.hasOwnProperty('language') && _config.language.hasOwnProperty('options')) {
            return _config.language.options;
        }
        return this.getSixDefaultLanguage();
    }
    getLangageDefaultValue(_config) {
        let returnVal = 'en';
        if (_config.hasOwnProperty('language') && _config.language.hasOwnProperty('value')) {
            return _config.language.value;
        }
        return returnVal;
    }
    getSixDefaultLanguage() {
        let defaultList = [
            {
                value: 'العربية', key: 'ar', dir: 'rtl'
            }, {
                value: '中文', key: 'zh', dir: 'ltr'
            }, {
                value: 'English', key: 'en', dir: 'ltr'
            }, {
                value: 'Français', key: 'fr', dir: 'ltr'
            }, {
                value: 'русский', key: 'ru', dir: 'ltr'
            }, {
                value: 'español', key: 'es', dir: 'ltr'
            } //,
            // value: 'en'
        ];
        return defaultList;
    }
    updateLanguageDir(_config, _selectedIndex) {
        // console.log('Parent svc run: ' + _selectedIndex);
        let langOptions = this.getLanguageConfigValues(_config);
        let dir = this.checkLanguageDir(langOptions, _selectedIndex);
        // console.log('Return this: ' + dir);
        return dir;
    }
    checkLanguageDir(_langOptions, _selectedIndex) {
        for (let i = 0; i < _langOptions.length; i++) {
            if (_langOptions[i].key === _selectedIndex) {
                // console.log('Detected this: ' + _langOptions[i].dir);
                return _langOptions[i].dir;
            }
        }
    }
    getFormInputs(_type, _config) {
        let formInputs = [];
        switch (_type) {
            case "reset-password":
                formInputs = [
                    {
                        'key': 'newpassword',
                        'label': 'Confirm Password',
                        'class': 'input',
                        'iconClass': 'fa fa-key iconSizeS',
                        'controlType': 'password',
                        'type': 'password',
                        'value': ''
                    },
                    {
                        'key': 'confirmpassword',
                        'label': 'New Password',
                        'class': 'input',
                        'iconClass': 'fa fa-key iconSizeS',
                        'controlType': 'password',
                        'type': 'password',
                        'value': ''
                    }
                ];
                break;
            case "forget-username":
                formInputs = [
                    {
                        'key': 'useremail',
                        'label': 'Email',
                        'class': 'input',
                        'iconClass': 'fa fa-envelope-o iconSizeS',
                        'controlType': 'textbox',
                        'value': ''
                    }
                ];
                break;
            case "forget-password":
                formInputs = [
                    {
                        'key': 'userinput',
                        'label': 'User Name or Email',
                        'class': 'input',
                        'iconClass': 'fa fa-user',
                        'controlType': 'textbox',
                        'value': ''
                    }
                    // {
                    //     'key': 'useremail',
                    //     'label': 'Email',
                    //     'class': 'input email',
                    //     'controlType': 'textbox',
                    //     'value': ''
                    // }
                ];
                break;
            default:
                formInputs = [
                    {
                        'key': 'username',
                        'label': 'User Name',
                        'class': 'input',
                        'iconClass': 'fa fa-user',
                        'controlType': 'text',
                        'value': ''
                    },
                    {
                        'key': 'password',
                        'label': 'Password',
                        'class': 'input',
                        'iconClass': 'fa fa-key iconSizeS',
                        'controlType': 'text',
                        'type': 'password',
                        'value': ''
                    },
                    {
                        'key': 'language',
                        'class': 'kdx-input-select-wrapper',
                        'iconClass': 'fa fa-globe',
                        'value': _config.value,
                        'options': _config.options,
                        'controlType': 'dropdown'
                    }
                ];
                break;
        }
        return formInputs;
    }
    getButtonLabel(_type, _label) {
        let tempLabel = "Submit";
        switch (_type) {
            case "reset-password":
                if (typeof _label !== 'undefined')
                    tempLabel = _label;
                else
                    tempLabel = 'Update Password';
                break;
            case "forget-username":
                if (typeof _label !== 'undefined')
                    tempLabel = _label;
                else
                    tempLabel = 'Recover Username';
                break;
            case "forget-password":
                if (typeof _label !== 'undefined')
                    tempLabel = _label;
                else
                    tempLabel = 'Reset Password';
                break;
            default:
                if (typeof _label !== 'undefined')
                    tempLabel = _label;
                else
                    tempLabel = 'Login';
                break;
        }
        return tempLabel;
    }
    getFormLinks(_config, _type) {
        let returnData = [];
        let defaultLink = this.getDefaultFormLinks(_type);
        switch (_type) {
            case "reset-password":
                returnData.push(Object.assign(defaultLink.back, _config.formLinks.back));
                break;
            case "forget-username":
                returnData.push(Object.assign(defaultLink.back, _config.formLinks.back));
                break;
            case "forget-password":
                returnData.push(Object.assign(defaultLink.back, _config.formLinks.back));
                break;
            default:
                if (_config.formLinks && _config.formLinks.forgetPassword)
                    returnData.push(Object.assign(defaultLink.forgetPassword, _config.formLinks.forgetPassword));
                if (_config.formLinks && _config.formLinks.forgetUser)
                    returnData.push(Object.assign(defaultLink.forgetUser, _config.formLinks.forgetUser));
                break;
        }
        return returnData;
        // if (_config.hasOwnProperty('formLinks') && _config.formLinks.hasOwnProperty(_linkType) && _config.formLinks[_linkType].hasOwnProperty('path')) {
        //     //return _config.formLinks.forgetPassword.path;
        //     let forgetPassword: any = {
        //         path: _config.formLinks.forgetPassword.path
        //     }
        // return forgetPassword;
        // }
    }
    getDefaultFormLinks(_type) {
        let returnData = {};
        switch (_type) {
            case "reset-password":
                returnData = {
                    back: {
                        label: 'Back to login?'
                    }
                };
                break;
            case "forget-username":
                returnData = {
                    back: {
                        label: 'Back to login?'
                    }
                };
                break;
            case "forget-password":
                returnData = {
                    back: {
                        label: 'Back to login?'
                    }
                };
                break;
            default:
                returnData = {
                    forgetPassword: {
                        label: 'Forget Password?'
                    },
                    forgetUser: {
                        label: 'Forget Username?'
                    }
                };
                break;
        }
        return returnData;
    }
    // public getFormAlerts(_config: ILoginConfig, _type: string): IFormAlertConfig | boolean {
    //     if (_config.hasOwnProperty('alert') && _config.alert.hasOwnProperty('errorMsg')) {
    //         let returnData: IFormAlertConfig = JSON.parse(JSON.stringify(_config.alert));
    //         if (!_config.alert.hasOwnProperty('successMsg') && _type !== 'login') {
    //             returnData['successMsg'] = 'An email will be send shortly. Please check your mailbox.';
    //         }
    //         return returnData;
    //     }
    //     return false;
    // }
    // public setAlertMessage(_value: string, _formAlerts: any): string {
    //     let returnVal: string;
    //     if (_value === 'success') {
    //         returnVal = _formAlerts.successMsg;
    //     } else if (_value === 'danger') {
    //         returnVal = _formAlerts.errorMsg;
    //     }
    //     return returnVal;
    // }
    _setProductAppConfig(_updateHeaderConfig) {
        // let tempHeaderConfig:any = _updateHeaderConfig;
        try {
            if (APP_CONFIGS.hasOwnProperty('product')) {
                let type = (APP_CONFIGS.product.hasOwnProperty('type')) ? APP_CONFIGS.product.type : 'icon';
                if (APP_CONFIGS.product.hasOwnProperty('name')) {
                    _updateHeaderConfig.title = APP_CONFIGS.product.name;
                }
                if (APP_CONFIGS.product.hasOwnProperty('src')) {
                    switch (type) {
                        case 'icon':
                            _updateHeaderConfig.icon = APP_CONFIGS.product.src;
                            break;
                        case 'image':
                            _updateHeaderConfig.img = APP_CONFIGS.product.src;
                            break;
                        default:
                            break;
                    }
                }
            }
        }
        catch (err) {
            // console.log(err);
        }
        return _updateHeaderConfig;
    }
    getLogoSizeClass(headerConfig) {
        if (typeof headerConfig.imgSize !== 'undefined')
            return headerConfig.imgSize;
        if (typeof headerConfig.img !== 'undefined' && typeof headerConfig.title === 'undefined')
            return 'full';
        return 'small';
    }
    getDemoLogin(requestString) {
        let tempString = requestString.replace(' ', '');
        let splitString = tempString.split(',');
        let demoInfo = {};
        if (splitString.length === 2) {
            demoInfo = {
                user: splitString[0],
                pass: splitString[1]
            };
        }
        return demoInfo;
    }
}
KdLoginSvc.decorators = [
    { type: Injectable }
];
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoia2QtYW5ndWxhci1sb2dpbi1zdmMuanMiLCJzb3VyY2VSb290IjoiQzoveGFtcHAvaHRkb2NzL1N0eWxlZ3VpZGUvaW9zdGctb3BlbmVtaXMtc3R5bGVndWlkZS9wcm9qZWN0cy9vcGVuZW1pcy1zdHlsZWd1aWRlLWxpYi9zcmMvIiwic291cmNlcyI6WyJrZC1jb21wb25lbnRzL2tkLWFuZ3VsYXItbG9naW4va2QtYW5ndWxhci1sb2dpbi1zdmMudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsT0FBTyxFQUFFLFVBQVUsRUFBYSxNQUFNLGVBQWUsQ0FBQztBQWN0RCxNQUFNLE9BQU8sVUFBVTtJQUlaLHFCQUFxQixDQUFDLE9BQVksRUFBRSxjQUFtQjtRQUMxRCxJQUFJLGtCQUFrQixHQUFRLEVBQUUsQ0FBQztRQUNqQyxJQUFJLE9BQU8sT0FBTyxLQUFLLFdBQVcsSUFBSSxPQUFPLE9BQU8sQ0FBQyxNQUFNLEtBQUssV0FBVyxFQUFFO1lBQ3pFLElBQUksT0FBTyxjQUFjLEtBQUssV0FBVztnQkFBRSxrQkFBa0IsR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsY0FBYyxDQUFDLENBQUMsQ0FBQzs7Z0JBQ3RHLGtCQUFrQixHQUFHLEVBQUUsSUFBSSxFQUFFLGFBQWEsRUFBRSxLQUFLLEVBQUUsVUFBVSxFQUFFLENBQUM7U0FDeEU7YUFDSTtZQUNELGtCQUFrQixHQUFHLE9BQU8sQ0FBQyxNQUFNLENBQUM7WUFDcEMsSUFBSSxPQUFPLGtCQUFrQixDQUFDLEdBQUcsS0FBSyxXQUFXLElBQUksT0FBTyxrQkFBa0IsQ0FBQyxJQUFJLEtBQUssV0FBVztnQkFBRSxrQkFBa0IsQ0FBQyxHQUFHLEdBQUcsRUFBRSxDQUFDO1lBQ2pJLElBQUksT0FBTyxrQkFBa0IsQ0FBQyxHQUFHLEtBQUssV0FBVyxJQUFJLE9BQU8sa0JBQWtCLENBQUMsSUFBSSxLQUFLLFdBQVc7Z0JBQUUsa0JBQWtCLENBQUMsSUFBSSxHQUFHLEVBQUUsQ0FBQztZQUNsSSxJQUFJLE9BQU8sa0JBQWtCLENBQUMsSUFBSSxLQUFLLFdBQVcsSUFBSSxPQUFPLGtCQUFrQixDQUFDLEtBQUssS0FBSyxXQUFXO2dCQUFFLGtCQUFrQixDQUFDLEtBQUssR0FBRyxFQUFFLENBQUM7WUFDckksSUFBSSxPQUFPLGtCQUFrQixDQUFDLEdBQUcsS0FBSyxXQUFXLElBQUksT0FBTyxrQkFBa0IsQ0FBQyxPQUFPLEtBQUssV0FBVztnQkFBRSxrQkFBa0IsQ0FBQyxPQUFPLEdBQUcsTUFBTSxDQUFDO1lBQzVJLElBQUksT0FBTyxrQkFBa0IsQ0FBQyxTQUFTLEtBQUssV0FBVyxJQUFJLE9BQU8sa0JBQWtCLENBQUMsU0FBUyxLQUFLLFdBQVc7Z0JBQUUsa0JBQWtCLENBQUMsU0FBUyxHQUFHLEVBQUUsQ0FBQztTQUNySjtRQUVELE9BQU8sSUFBSSxDQUFDLG9CQUFvQixDQUFDLGtCQUFrQixDQUFDLENBQUM7SUFDekQsQ0FBQztJQUVEOzs7Ozs7T0FNRztJQUNJLHVCQUF1QixDQUFDLE9BQXFCO1FBQ2hELElBQUksT0FBTyxDQUFDLGNBQWMsQ0FBQyxVQUFVLENBQUMsSUFBSSxPQUFPLENBQUMsUUFBUSxDQUFDLGNBQWMsQ0FBQyxTQUFTLENBQUMsRUFBRTtZQUNsRixPQUFPLE9BQU8sQ0FBQyxRQUFRLENBQUMsT0FBTyxDQUFDO1NBQ25DO1FBRUQsT0FBTyxJQUFJLENBQUMscUJBQXFCLEVBQUUsQ0FBQztJQUN4QyxDQUFDO0lBRU0sc0JBQXNCLENBQUMsT0FBcUI7UUFDL0MsSUFBSSxTQUFTLEdBQVcsSUFBSSxDQUFDO1FBQzdCLElBQUksT0FBTyxDQUFDLGNBQWMsQ0FBQyxVQUFVLENBQUMsSUFBSSxPQUFPLENBQUMsUUFBUSxDQUFDLGNBQWMsQ0FBQyxPQUFPLENBQUMsRUFBRTtZQUNoRixPQUFPLE9BQU8sQ0FBQyxRQUFRLENBQUMsS0FBSyxDQUFDO1NBQ2pDO1FBRUQsT0FBTyxTQUFTLENBQUM7SUFDckIsQ0FBQztJQUVNLHFCQUFxQjtRQUN4QixJQUFJLFdBQVcsR0FBZTtZQUMxQjtnQkFDSSxLQUFLLEVBQUUsU0FBUyxFQUFFLEdBQUcsRUFBRSxJQUFJLEVBQUUsR0FBRyxFQUFFLEtBQUs7YUFDMUMsRUFBRTtnQkFDQyxLQUFLLEVBQUUsSUFBSSxFQUFFLEdBQUcsRUFBRSxJQUFJLEVBQUUsR0FBRyxFQUFFLEtBQUs7YUFDckMsRUFBRTtnQkFDQyxLQUFLLEVBQUUsU0FBUyxFQUFFLEdBQUcsRUFBRSxJQUFJLEVBQUUsR0FBRyxFQUFFLEtBQUs7YUFDMUMsRUFBRTtnQkFDQyxLQUFLLEVBQUUsVUFBVSxFQUFFLEdBQUcsRUFBRSxJQUFJLEVBQUUsR0FBRyxFQUFFLEtBQUs7YUFDM0MsRUFBRTtnQkFDQyxLQUFLLEVBQUUsU0FBUyxFQUFFLEdBQUcsRUFBRSxJQUFJLEVBQUUsR0FBRyxFQUFFLEtBQUs7YUFDMUMsRUFBRTtnQkFDQyxLQUFLLEVBQUUsU0FBUyxFQUFFLEdBQUcsRUFBRSxJQUFJLEVBQUUsR0FBRyxFQUFFLEtBQUs7YUFDMUMsQ0FBQSxHQUFHO1lBQ0osY0FBYztTQUNqQixDQUFDO1FBRUYsT0FBTyxXQUFXLENBQUM7SUFDdkIsQ0FBQztJQUVNLGlCQUFpQixDQUFDLE9BQXFCLEVBQUUsY0FBc0I7UUFDbEUsb0RBQW9EO1FBQ3BELElBQUksV0FBVyxHQUFHLElBQUksQ0FBQyx1QkFBdUIsQ0FBQyxPQUFPLENBQUMsQ0FBQztRQUN4RCxJQUFJLEdBQUcsR0FBRyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsV0FBVyxFQUFFLGNBQWMsQ0FBQyxDQUFDO1FBQzdELHNDQUFzQztRQUN0QyxPQUFPLEdBQUcsQ0FBQztJQUdmLENBQUM7SUFFTSxnQkFBZ0IsQ0FBQyxZQUFpQixFQUFFLGNBQXNCO1FBQzdELEtBQUssSUFBSSxDQUFDLEdBQVcsQ0FBQyxFQUFFLENBQUMsR0FBRyxZQUFZLENBQUMsTUFBTSxFQUFFLENBQUMsRUFBRSxFQUFFO1lBQ2xELElBQUksWUFBWSxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsS0FBSyxjQUFjLEVBQUU7Z0JBQ3hDLHdEQUF3RDtnQkFDeEQsT0FBTyxZQUFZLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDO2FBRTlCO1NBQ0o7SUFDTCxDQUFDO0lBRU0sYUFBYSxDQUFDLEtBQWEsRUFBRSxPQUFhO1FBQzdDLElBQUksVUFBVSxHQUFlLEVBQUUsQ0FBQztRQUNoQyxRQUFRLEtBQUssRUFBRTtZQUNYLEtBQUssZ0JBQWdCO2dCQUNqQixVQUFVLEdBQUc7b0JBQ1Q7d0JBQ0ksS0FBSyxFQUFFLGFBQWE7d0JBQ3BCLE9BQU8sRUFBRSxrQkFBa0I7d0JBQzNCLE9BQU8sRUFBRSxPQUFPO3dCQUNoQixXQUFXLEVBQUUscUJBQXFCO3dCQUNsQyxhQUFhLEVBQUUsVUFBVTt3QkFDekIsTUFBTSxFQUFFLFVBQVU7d0JBQ2xCLE9BQU8sRUFBRSxFQUFFO3FCQUNkO29CQUNEO3dCQUNJLEtBQUssRUFBRSxpQkFBaUI7d0JBQ3hCLE9BQU8sRUFBRSxjQUFjO3dCQUN2QixPQUFPLEVBQUUsT0FBTzt3QkFDaEIsV0FBVyxFQUFFLHFCQUFxQjt3QkFDbEMsYUFBYSxFQUFFLFVBQVU7d0JBQ3pCLE1BQU0sRUFBRSxVQUFVO3dCQUNsQixPQUFPLEVBQUUsRUFBRTtxQkFDZDtpQkFDSixDQUFBO2dCQUNELE1BQU07WUFDVixLQUFLLGlCQUFpQjtnQkFDbEIsVUFBVSxHQUFHO29CQUNUO3dCQUNJLEtBQUssRUFBRSxXQUFXO3dCQUNsQixPQUFPLEVBQUUsT0FBTzt3QkFDaEIsT0FBTyxFQUFFLE9BQU87d0JBQ2hCLFdBQVcsRUFBRSw0QkFBNEI7d0JBQ3pDLGFBQWEsRUFBRSxTQUFTO3dCQUN4QixPQUFPLEVBQUUsRUFBRTtxQkFDZDtpQkFDSixDQUFBO2dCQUNELE1BQU07WUFDVixLQUFLLGlCQUFpQjtnQkFDbEIsVUFBVSxHQUFHO29CQUNUO3dCQUNJLEtBQUssRUFBRSxXQUFXO3dCQUNsQixPQUFPLEVBQUUsb0JBQW9CO3dCQUM3QixPQUFPLEVBQUUsT0FBTzt3QkFDaEIsV0FBVyxFQUFFLFlBQVk7d0JBQ3pCLGFBQWEsRUFBRSxTQUFTO3dCQUN4QixPQUFPLEVBQUUsRUFBRTtxQkFDZDtvQkFDRCxJQUFJO29CQUNKLDBCQUEwQjtvQkFDMUIsd0JBQXdCO29CQUN4Qiw4QkFBOEI7b0JBQzlCLGdDQUFnQztvQkFDaEMsa0JBQWtCO29CQUNsQixJQUFJO2lCQUNQLENBQUE7Z0JBQ0QsTUFBTTtZQUNWO2dCQUNJLFVBQVUsR0FBRztvQkFDVDt3QkFDSSxLQUFLLEVBQUUsVUFBVTt3QkFDakIsT0FBTyxFQUFFLFdBQVc7d0JBQ3BCLE9BQU8sRUFBRSxPQUFPO3dCQUNoQixXQUFXLEVBQUUsWUFBWTt3QkFDekIsYUFBYSxFQUFFLE1BQU07d0JBQ3JCLE9BQU8sRUFBRSxFQUFFO3FCQUNkO29CQUNEO3dCQUNJLEtBQUssRUFBRSxVQUFVO3dCQUNqQixPQUFPLEVBQUUsVUFBVTt3QkFDbkIsT0FBTyxFQUFFLE9BQU87d0JBQ2hCLFdBQVcsRUFBRSxxQkFBcUI7d0JBQ2xDLGFBQWEsRUFBRSxNQUFNO3dCQUNyQixNQUFNLEVBQUUsVUFBVTt3QkFDbEIsT0FBTyxFQUFFLEVBQUU7cUJBQ2Q7b0JBQ0Q7d0JBQ0ksS0FBSyxFQUFFLFVBQVU7d0JBQ2pCLE9BQU8sRUFBRSwwQkFBMEI7d0JBQ25DLFdBQVcsRUFBRSxhQUFhO3dCQUMxQixPQUFPLEVBQUUsT0FBTyxDQUFDLEtBQUs7d0JBQ3RCLFNBQVMsRUFBRSxPQUFPLENBQUMsT0FBTzt3QkFDMUIsYUFBYSxFQUFFLFVBQVU7cUJBQzVCO2lCQUNKLENBQUE7Z0JBQ0QsTUFBTTtTQUNiO1FBRUQsT0FBTyxVQUFVLENBQUM7SUFDdEIsQ0FBQztJQUVNLGNBQWMsQ0FBQyxLQUFhLEVBQUUsTUFBZTtRQUNoRCxJQUFJLFNBQVMsR0FBVyxRQUFRLENBQUM7UUFFakMsUUFBUSxLQUFLLEVBQUU7WUFFWCxLQUFLLGdCQUFnQjtnQkFDakIsSUFBSSxPQUFPLE1BQU0sS0FBSyxXQUFXO29CQUFFLFNBQVMsR0FBRyxNQUFNLENBQUM7O29CQUNqRCxTQUFTLEdBQUcsaUJBQWlCLENBQUE7Z0JBQ2xDLE1BQU07WUFFVixLQUFLLGlCQUFpQjtnQkFDbEIsSUFBSSxPQUFPLE1BQU0sS0FBSyxXQUFXO29CQUFFLFNBQVMsR0FBRyxNQUFNLENBQUM7O29CQUNqRCxTQUFTLEdBQUcsa0JBQWtCLENBQUE7Z0JBQ25DLE1BQU07WUFFVixLQUFLLGlCQUFpQjtnQkFDbEIsSUFBSSxPQUFPLE1BQU0sS0FBSyxXQUFXO29CQUFFLFNBQVMsR0FBRyxNQUFNLENBQUM7O29CQUNqRCxTQUFTLEdBQUcsZ0JBQWdCLENBQUE7Z0JBQ2pDLE1BQU07WUFFVjtnQkFDSSxJQUFJLE9BQU8sTUFBTSxLQUFLLFdBQVc7b0JBQUUsU0FBUyxHQUFHLE1BQU0sQ0FBQzs7b0JBQ2pELFNBQVMsR0FBRyxPQUFPLENBQUE7Z0JBQ3hCLE1BQU07U0FDYjtRQUVELE9BQU8sU0FBUyxDQUFDO0lBQ3JCLENBQUM7SUFFTSxZQUFZLENBQUMsT0FBcUIsRUFBRSxLQUFhO1FBQ3BELElBQUksVUFBVSxHQUEyQixFQUFFLENBQUE7UUFFM0MsSUFBSSxXQUFXLEdBQVEsSUFBSSxDQUFDLG1CQUFtQixDQUFDLEtBQUssQ0FBQyxDQUFDO1FBRXZELFFBQVEsS0FBSyxFQUFFO1lBRVgsS0FBSyxnQkFBZ0I7Z0JBQ2pCLFVBQVUsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxXQUFXLENBQUMsSUFBSSxFQUFFLE9BQU8sQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQTtnQkFDeEUsTUFBTTtZQUVWLEtBQUssaUJBQWlCO2dCQUNsQixVQUFVLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsV0FBVyxDQUFDLElBQUksRUFBRSxPQUFPLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUE7Z0JBQ3hFLE1BQU07WUFFVixLQUFLLGlCQUFpQjtnQkFDbEIsVUFBVSxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLFdBQVcsQ0FBQyxJQUFJLEVBQUUsT0FBTyxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFBO2dCQUN4RSxNQUFNO1lBRVY7Z0JBQ0ksSUFBRyxPQUFPLENBQUMsU0FBUyxJQUFJLE9BQU8sQ0FBQyxTQUFTLENBQUMsY0FBYztvQkFDeEQsVUFBVSxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLFdBQVcsQ0FBQyxjQUFjLEVBQUUsT0FBTyxDQUFDLFNBQVMsQ0FBQyxjQUFjLENBQUMsQ0FBQyxDQUFBO2dCQUM1RixJQUFHLE9BQU8sQ0FBQyxTQUFTLElBQUksT0FBTyxDQUFDLFNBQVMsQ0FBQyxVQUFVO29CQUNwRCxVQUFVLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsV0FBVyxDQUFDLFVBQVUsRUFBRSxPQUFPLENBQUMsU0FBUyxDQUFDLFVBQVUsQ0FBQyxDQUFDLENBQUE7Z0JBQ3BGLE1BQU07U0FDYjtRQUVELE9BQU8sVUFBVSxDQUFDO1FBRWxCLG1KQUFtSjtRQUNuSixzREFBc0Q7UUFDdEQsa0NBQWtDO1FBQ2xDLHNEQUFzRDtRQUN0RCxRQUFRO1FBRVIseUJBQXlCO1FBQ3pCLElBQUk7SUFDUixDQUFDO0lBRU8sbUJBQW1CLENBQUMsS0FBYTtRQUNyQyxJQUFJLFVBQVUsR0FBUSxFQUFFLENBQUM7UUFFekIsUUFBUSxLQUFLLEVBQUU7WUFFWCxLQUFLLGdCQUFnQjtnQkFDakIsVUFBVSxHQUFHO29CQUNULElBQUksRUFBRTt3QkFDRixLQUFLLEVBQUUsZ0JBQWdCO3FCQUMxQjtpQkFDSixDQUFBO2dCQUNELE1BQU07WUFFVixLQUFLLGlCQUFpQjtnQkFDbEIsVUFBVSxHQUFHO29CQUNULElBQUksRUFBRTt3QkFDRixLQUFLLEVBQUUsZ0JBQWdCO3FCQUMxQjtpQkFDSixDQUFBO2dCQUNELE1BQU07WUFFVixLQUFLLGlCQUFpQjtnQkFDbEIsVUFBVSxHQUFHO29CQUNULElBQUksRUFBRTt3QkFDRixLQUFLLEVBQUUsZ0JBQWdCO3FCQUMxQjtpQkFDSixDQUFBO2dCQUNELE1BQU07WUFFVjtnQkFDSSxVQUFVLEdBQUc7b0JBQ1QsY0FBYyxFQUFFO3dCQUNaLEtBQUssRUFBRSxrQkFBa0I7cUJBQzVCO29CQUNELFVBQVUsRUFBRTt3QkFDUixLQUFLLEVBQUUsa0JBQWtCO3FCQUM1QjtpQkFDSixDQUFBO2dCQUNELE1BQU07U0FDYjtRQUNELE9BQU8sVUFBVSxDQUFDO0lBQ3RCLENBQUM7SUFFRCwyRkFBMkY7SUFDM0YseUZBQXlGO0lBQ3pGLHdGQUF3RjtJQUV4RixrRkFBa0Y7SUFDbEYsc0dBQXNHO0lBQ3RHLFlBQVk7SUFDWiw2QkFBNkI7SUFDN0IsUUFBUTtJQUNSLG9CQUFvQjtJQUNwQixJQUFJO0lBRUoscUVBQXFFO0lBQ3JFLDZCQUE2QjtJQUU3QixrQ0FBa0M7SUFDbEMsOENBQThDO0lBQzlDLHdDQUF3QztJQUN4Qyw0Q0FBNEM7SUFDNUMsUUFBUTtJQUVSLHdCQUF3QjtJQUN4QixJQUFJO0lBS0ksb0JBQW9CLENBQUMsbUJBQXdCO1FBQ2pELGtEQUFrRDtRQUNsRCxJQUFJO1lBQ0EsSUFBSSxXQUFXLENBQUMsY0FBYyxDQUFDLFNBQVMsQ0FBQyxFQUFFO2dCQUN2QyxJQUFJLElBQUksR0FBVyxDQUFDLFdBQVcsQ0FBQyxPQUFPLENBQUMsY0FBYyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFdBQVcsQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUM7Z0JBRXBHLElBQUksV0FBVyxDQUFDLE9BQU8sQ0FBQyxjQUFjLENBQUMsTUFBTSxDQUFDLEVBQUU7b0JBQzVDLG1CQUFtQixDQUFDLEtBQUssR0FBRyxXQUFXLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQztpQkFDeEQ7Z0JBRUQsSUFBSSxXQUFXLENBQUMsT0FBTyxDQUFDLGNBQWMsQ0FBQyxLQUFLLENBQUMsRUFBRTtvQkFDM0MsUUFBUSxJQUFJLEVBQUU7d0JBQ1YsS0FBSyxNQUFNOzRCQUNQLG1CQUFtQixDQUFDLElBQUksR0FBRyxXQUFXLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQzs0QkFDbkQsTUFBTTt3QkFDVixLQUFLLE9BQU87NEJBQ1IsbUJBQW1CLENBQUMsR0FBRyxHQUFHLFdBQVcsQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDOzRCQUNsRCxNQUFNO3dCQUNWOzRCQUNJLE1BQU07cUJBQ2I7aUJBQ0o7YUFDSjtTQUNKO1FBQUMsT0FBTyxHQUFHLEVBQUU7WUFDVixvQkFBb0I7U0FDdkI7UUFFRCxPQUFPLG1CQUFtQixDQUFDO0lBQy9CLENBQUM7SUFJRCxnQkFBZ0IsQ0FBQyxZQUFpQjtRQUM5QixJQUFJLE9BQU8sWUFBWSxDQUFDLE9BQU8sS0FBSyxXQUFXO1lBQUUsT0FBTyxZQUFZLENBQUMsT0FBTyxDQUFDO1FBQzdFLElBQUksT0FBTyxZQUFZLENBQUMsR0FBRyxLQUFLLFdBQVcsSUFBSSxPQUFPLFlBQVksQ0FBQyxLQUFLLEtBQUssV0FBVztZQUFFLE9BQU8sTUFBTSxDQUFDO1FBQ3hHLE9BQU8sT0FBTyxDQUFDO0lBQ25CLENBQUM7SUFFRCxZQUFZLENBQUMsYUFBcUI7UUFDOUIsSUFBSSxVQUFVLEdBQVcsYUFBYSxDQUFDLE9BQU8sQ0FBQyxHQUFHLEVBQUUsRUFBRSxDQUFDLENBQUM7UUFDeEQsSUFBSSxXQUFXLEdBQWtCLFVBQVUsQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLENBQUM7UUFDdkQsSUFBSSxRQUFRLEdBQVEsRUFBRSxDQUFDO1FBQ3ZCLElBQUksV0FBVyxDQUFDLE1BQU0sS0FBSyxDQUFDLEVBQUU7WUFDMUIsUUFBUSxHQUFHO2dCQUNQLElBQUksRUFBRSxXQUFXLENBQUMsQ0FBQyxDQUFDO2dCQUNwQixJQUFJLEVBQUUsV0FBVyxDQUFDLENBQUMsQ0FBQzthQUN2QixDQUFDO1NBQ0w7UUFDRCxPQUFPLFFBQVEsQ0FBQztJQUNwQixDQUFDOzs7WUE3V0osVUFBVSIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IEluamVjdGFibGUsIFJlbmRlcmVyMiB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xyXG5pbXBvcnQgeyBLZERvbUVsZW1TdmMgfSBmcm9tICcuLi9rZC1jb21tb24vaW5kZXgnO1xyXG5pbXBvcnQge1xyXG4gICAgSUxvZ2luQ29uZmlnLFxyXG4gICAgSUxhbmd1YWdlT3B0aW9uc0NvbmZpZyxcclxuICAgIElGb3JtTGlua0NvbmZpZyxcclxuICAgIElGb3JtQWxlcnRDb25maWcsXHJcbiAgICBJTGFuZ3VhZ2VDb25maWdcclxufSBmcm9tICcuL2tkLWFuZ3VsYXItbG9naW4taW50ZXJmYWNlJztcclxuXHJcblxyXG5kZWNsYXJlIGxldCBBUFBfQ09ORklHUzogYW55O1xyXG5cclxuQEluamVjdGFibGUoKVxyXG5leHBvcnQgY2xhc3MgS2RMb2dpblN2YyB7XHJcbiAgICBwcml2YXRlIF9kb21TdmM6IEtkRG9tRWxlbVN2YztcclxuICAgIHByaXZhdGUgX3JlbmRlcmVyOiBSZW5kZXJlcjI7XHJcblxyXG4gICAgcHVibGljIGdldEhlYWRlckNvbmZpZ1ZhbHVlcyhfY29uZmlnOiBhbnksIF9kZWZhdWx0Q29uZmlnOiBhbnkpOiBhbnkge1xyXG4gICAgICAgIGxldCB1cGRhdGVIZWFkZXJDb25maWc6IGFueSA9IHt9O1xyXG4gICAgICAgIGlmICh0eXBlb2YgX2NvbmZpZyA9PT0gJ3VuZGVmaW5lZCcgfHwgdHlwZW9mIF9jb25maWcuaGVhZGVyID09PSAndW5kZWZpbmVkJykge1xyXG4gICAgICAgICAgICBpZiAodHlwZW9mIF9kZWZhdWx0Q29uZmlnICE9PSAndW5kZWZpbmVkJykgdXBkYXRlSGVhZGVyQ29uZmlnID0gSlNPTi5wYXJzZShKU09OLnN0cmluZ2lmeShfZGVmYXVsdENvbmZpZykpO1xyXG4gICAgICAgICAgICBlbHNlIHVwZGF0ZUhlYWRlckNvbmZpZyA9IHsgaWNvbjogJ2tkLW9wZW5lbWlzJywgdGl0bGU6ICdPcGVuRU1JUycgfTtcclxuICAgICAgICB9XHJcbiAgICAgICAgZWxzZSB7XHJcbiAgICAgICAgICAgIHVwZGF0ZUhlYWRlckNvbmZpZyA9IF9jb25maWcuaGVhZGVyO1xyXG4gICAgICAgICAgICBpZiAodHlwZW9mIHVwZGF0ZUhlYWRlckNvbmZpZy5pbWcgIT09ICd1bmRlZmluZWQnICYmIHR5cGVvZiB1cGRhdGVIZWFkZXJDb25maWcuaWNvbiAhPT0gJ3VuZGVmaW5lZCcpIHVwZGF0ZUhlYWRlckNvbmZpZy5pbWcgPSAnJztcclxuICAgICAgICAgICAgaWYgKHR5cGVvZiB1cGRhdGVIZWFkZXJDb25maWcuaW1nID09PSAndW5kZWZpbmVkJyAmJiB0eXBlb2YgdXBkYXRlSGVhZGVyQ29uZmlnLmljb24gPT09ICd1bmRlZmluZWQnKSB1cGRhdGVIZWFkZXJDb25maWcuaWNvbiA9ICcnO1xyXG4gICAgICAgICAgICBpZiAodHlwZW9mIHVwZGF0ZUhlYWRlckNvbmZpZy5pY29uICE9PSAndW5kZWZpbmVkJyAmJiB0eXBlb2YgdXBkYXRlSGVhZGVyQ29uZmlnLnRpdGxlID09PSAndW5kZWZpbmVkJykgdXBkYXRlSGVhZGVyQ29uZmlnLnRpdGxlID0gJyc7XHJcbiAgICAgICAgICAgIGlmICh0eXBlb2YgdXBkYXRlSGVhZGVyQ29uZmlnLmltZyAhPT0gJ3VuZGVmaW5lZCcgJiYgdHlwZW9mIHVwZGF0ZUhlYWRlckNvbmZpZy5pbWdTaXplID09PSAndW5kZWZpbmVkJykgdXBkYXRlSGVhZGVyQ29uZmlnLmltZ1NpemUgPSAnbm9uZSc7XHJcbiAgICAgICAgICAgIGlmICh0eXBlb2YgdXBkYXRlSGVhZGVyQ29uZmlnLmhlYWRlck1zZyAhPT0gJ3VuZGVmaW5lZCcgJiYgdHlwZW9mIHVwZGF0ZUhlYWRlckNvbmZpZy5oZWFkZXJNc2cgPT09ICd1bmRlZmluZWQnKSB1cGRhdGVIZWFkZXJDb25maWcuaGVhZGVyTXNnID0gJyc7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICByZXR1cm4gdGhpcy5fc2V0UHJvZHVjdEFwcENvbmZpZyh1cGRhdGVIZWFkZXJDb25maWcpO1xyXG4gICAgfVxyXG5cclxuICAgIC8qXHJcbiAgICAgICAgc2V0IGRlZmF1bHQgbGFuZ3VhZ2UgY29uZmlnXHJcbiAgICAgICAgICAgIC0gaWYgY29uZmlnIGlzIHVuZGVmaW5lZCwgbGFuZ3VuYWdlIHVuZGVmaW5lZCwgc2hvdyB1bmRlZmluZWQgLSByZXR1cm4gZGVmYXVsdFxyXG4gICAgICAgICAgICAgICAgLSBpZiBjb25maWcgbGlzdCBpcyBkZWZpbmVkLCBsaXN0IGdvdCBpdGVtLCBhbmQgc2hvdyBpcyB0cnVlIC0gc2V0IGNvbmZpZyB0byBzaG93IHdpdGggdG9nZ2xlXHJcbiAgICAgICAgICAgICAgICAtIGVsc2UgaWYgY29uZmlnIGRlZmF1bHQgaXMgZGVmaW5lZCAtIHNldCBjb25maWcgd2l0aCBkZWZhdWx0IGxhbmd1YWdlIGFuZCB0b2dnbGUgZmFsc2VcclxuICAgICAgICAtIHJldHVybiBjb25maWdcclxuICAgICAqL1xyXG4gICAgcHVibGljIGdldExhbmd1YWdlQ29uZmlnVmFsdWVzKF9jb25maWc6IElMb2dpbkNvbmZpZyk6IEFycmF5PElMYW5ndWFnZU9wdGlvbnNDb25maWc+IHtcclxuICAgICAgICBpZiAoX2NvbmZpZy5oYXNPd25Qcm9wZXJ0eSgnbGFuZ3VhZ2UnKSAmJiBfY29uZmlnLmxhbmd1YWdlLmhhc093blByb3BlcnR5KCdvcHRpb25zJykpIHtcclxuICAgICAgICAgICAgcmV0dXJuIF9jb25maWcubGFuZ3VhZ2Uub3B0aW9ucztcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIHJldHVybiB0aGlzLmdldFNpeERlZmF1bHRMYW5ndWFnZSgpO1xyXG4gICAgfVxyXG5cclxuICAgIHB1YmxpYyBnZXRMYW5nYWdlRGVmYXVsdFZhbHVlKF9jb25maWc6IElMb2dpbkNvbmZpZyk6IHN0cmluZyB7XHJcbiAgICAgICAgbGV0IHJldHVyblZhbDogc3RyaW5nID0gJ2VuJztcclxuICAgICAgICBpZiAoX2NvbmZpZy5oYXNPd25Qcm9wZXJ0eSgnbGFuZ3VhZ2UnKSAmJiBfY29uZmlnLmxhbmd1YWdlLmhhc093blByb3BlcnR5KCd2YWx1ZScpKSB7XHJcbiAgICAgICAgICAgIHJldHVybiBfY29uZmlnLmxhbmd1YWdlLnZhbHVlO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgcmV0dXJuIHJldHVyblZhbDtcclxuICAgIH1cclxuXHJcbiAgICBwdWJsaWMgZ2V0U2l4RGVmYXVsdExhbmd1YWdlKCk6IEFycmF5PGFueT4ge1xyXG4gICAgICAgIGxldCBkZWZhdWx0TGlzdDogQXJyYXk8YW55PiA9IFtcclxuICAgICAgICAgICAge1xyXG4gICAgICAgICAgICAgICAgdmFsdWU6ICfYp9mE2LnYsdio2YrYqScsIGtleTogJ2FyJywgZGlyOiAncnRsJ1xyXG4gICAgICAgICAgICB9LCB7XHJcbiAgICAgICAgICAgICAgICB2YWx1ZTogJ+S4reaWhycsIGtleTogJ3poJywgZGlyOiAnbHRyJ1xyXG4gICAgICAgICAgICB9LCB7XHJcbiAgICAgICAgICAgICAgICB2YWx1ZTogJ0VuZ2xpc2gnLCBrZXk6ICdlbicsIGRpcjogJ2x0cidcclxuICAgICAgICAgICAgfSwge1xyXG4gICAgICAgICAgICAgICAgdmFsdWU6ICdGcmFuw6dhaXMnLCBrZXk6ICdmcicsIGRpcjogJ2x0cidcclxuICAgICAgICAgICAgfSwge1xyXG4gICAgICAgICAgICAgICAgdmFsdWU6ICfRgNGD0YHRgdC60LjQuScsIGtleTogJ3J1JywgZGlyOiAnbHRyJ1xyXG4gICAgICAgICAgICB9LCB7XHJcbiAgICAgICAgICAgICAgICB2YWx1ZTogJ2VzcGHDsW9sJywga2V5OiAnZXMnLCBkaXI6ICdsdHInXHJcbiAgICAgICAgICAgIH0vLyxcclxuICAgICAgICAgICAgLy8gdmFsdWU6ICdlbidcclxuICAgICAgICBdO1xyXG5cclxuICAgICAgICByZXR1cm4gZGVmYXVsdExpc3Q7XHJcbiAgICB9XHJcblxyXG4gICAgcHVibGljIHVwZGF0ZUxhbmd1YWdlRGlyKF9jb25maWc6IElMb2dpbkNvbmZpZywgX3NlbGVjdGVkSW5kZXg6IHN0cmluZyk6IHN0cmluZyB7XHJcbiAgICAgICAgLy8gY29uc29sZS5sb2coJ1BhcmVudCBzdmMgcnVuOiAnICsgX3NlbGVjdGVkSW5kZXgpO1xyXG4gICAgICAgIGxldCBsYW5nT3B0aW9ucyA9IHRoaXMuZ2V0TGFuZ3VhZ2VDb25maWdWYWx1ZXMoX2NvbmZpZyk7XHJcbiAgICAgICAgbGV0IGRpciA9IHRoaXMuY2hlY2tMYW5ndWFnZURpcihsYW5nT3B0aW9ucywgX3NlbGVjdGVkSW5kZXgpO1xyXG4gICAgICAgIC8vIGNvbnNvbGUubG9nKCdSZXR1cm4gdGhpczogJyArIGRpcik7XHJcbiAgICAgICAgcmV0dXJuIGRpcjtcclxuXHJcblxyXG4gICAgfVxyXG5cclxuICAgIHB1YmxpYyBjaGVja0xhbmd1YWdlRGlyKF9sYW5nT3B0aW9uczogYW55LCBfc2VsZWN0ZWRJbmRleDogc3RyaW5nKTogc3RyaW5nIHtcclxuICAgICAgICBmb3IgKGxldCBpOiBudW1iZXIgPSAwOyBpIDwgX2xhbmdPcHRpb25zLmxlbmd0aDsgaSsrKSB7XHJcbiAgICAgICAgICAgIGlmIChfbGFuZ09wdGlvbnNbaV0ua2V5ID09PSBfc2VsZWN0ZWRJbmRleCkge1xyXG4gICAgICAgICAgICAgICAgLy8gY29uc29sZS5sb2coJ0RldGVjdGVkIHRoaXM6ICcgKyBfbGFuZ09wdGlvbnNbaV0uZGlyKTtcclxuICAgICAgICAgICAgICAgIHJldHVybiBfbGFuZ09wdGlvbnNbaV0uZGlyO1xyXG5cclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICBwdWJsaWMgZ2V0Rm9ybUlucHV0cyhfdHlwZTogc3RyaW5nLCBfY29uZmlnPzogYW55KTogQXJyYXk8YW55PiB7XHJcbiAgICAgICAgbGV0IGZvcm1JbnB1dHM6IEFycmF5PGFueT4gPSBbXTtcclxuICAgICAgICBzd2l0Y2ggKF90eXBlKSB7XHJcbiAgICAgICAgICAgIGNhc2UgXCJyZXNldC1wYXNzd29yZFwiOlxyXG4gICAgICAgICAgICAgICAgZm9ybUlucHV0cyA9IFtcclxuICAgICAgICAgICAgICAgICAgICB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICdrZXknOiAnbmV3cGFzc3dvcmQnLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAnbGFiZWwnOiAnQ29uZmlybSBQYXNzd29yZCcsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICdjbGFzcyc6ICdpbnB1dCcsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICdpY29uQ2xhc3MnOiAnZmEgZmEta2V5IGljb25TaXplUycsIFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAnY29udHJvbFR5cGUnOiAncGFzc3dvcmQnLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAndHlwZSc6ICdwYXNzd29yZCcsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICd2YWx1ZSc6ICcnXHJcbiAgICAgICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICAgICAgICB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICdrZXknOiAnY29uZmlybXBhc3N3b3JkJyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgJ2xhYmVsJzogJ05ldyBQYXNzd29yZCcsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICdjbGFzcyc6ICdpbnB1dCcsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICdpY29uQ2xhc3MnOiAnZmEgZmEta2V5IGljb25TaXplUycsIFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAnY29udHJvbFR5cGUnOiAncGFzc3dvcmQnLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAndHlwZSc6ICdwYXNzd29yZCcsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICd2YWx1ZSc6ICcnXHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgXVxyXG4gICAgICAgICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgICAgIGNhc2UgXCJmb3JnZXQtdXNlcm5hbWVcIjpcclxuICAgICAgICAgICAgICAgIGZvcm1JbnB1dHMgPSBbXHJcbiAgICAgICAgICAgICAgICAgICAge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAna2V5JzogJ3VzZXJlbWFpbCcsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICdsYWJlbCc6ICdFbWFpbCcsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICdjbGFzcyc6ICdpbnB1dCcsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICdpY29uQ2xhc3MnOiAnZmEgZmEtZW52ZWxvcGUtbyBpY29uU2l6ZVMnLCBcclxuICAgICAgICAgICAgICAgICAgICAgICAgJ2NvbnRyb2xUeXBlJzogJ3RleHRib3gnLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAndmFsdWUnOiAnJ1xyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIF1cclxuICAgICAgICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgICAgICBjYXNlIFwiZm9yZ2V0LXBhc3N3b3JkXCI6XHJcbiAgICAgICAgICAgICAgICBmb3JtSW5wdXRzID0gW1xyXG4gICAgICAgICAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgJ2tleSc6ICd1c2VyaW5wdXQnLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAnbGFiZWwnOiAnVXNlciBOYW1lIG9yIEVtYWlsJyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgJ2NsYXNzJzogJ2lucHV0JyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgJ2ljb25DbGFzcyc6ICdmYSBmYS11c2VyJywgXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICdjb250cm9sVHlwZSc6ICd0ZXh0Ym94JyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgJ3ZhbHVlJzogJydcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgLy8ge1xyXG4gICAgICAgICAgICAgICAgICAgIC8vICAgICAna2V5JzogJ3VzZXJlbWFpbCcsXHJcbiAgICAgICAgICAgICAgICAgICAgLy8gICAgICdsYWJlbCc6ICdFbWFpbCcsXHJcbiAgICAgICAgICAgICAgICAgICAgLy8gICAgICdjbGFzcyc6ICdpbnB1dCBlbWFpbCcsXHJcbiAgICAgICAgICAgICAgICAgICAgLy8gICAgICdjb250cm9sVHlwZSc6ICd0ZXh0Ym94JyxcclxuICAgICAgICAgICAgICAgICAgICAvLyAgICAgJ3ZhbHVlJzogJydcclxuICAgICAgICAgICAgICAgICAgICAvLyB9XHJcbiAgICAgICAgICAgICAgICBdXHJcbiAgICAgICAgICAgICAgICBicmVhaztcclxuICAgICAgICAgICAgZGVmYXVsdDpcclxuICAgICAgICAgICAgICAgIGZvcm1JbnB1dHMgPSBbXHJcbiAgICAgICAgICAgICAgICAgICAge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAna2V5JzogJ3VzZXJuYW1lJyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgJ2xhYmVsJzogJ1VzZXIgTmFtZScsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICdjbGFzcyc6ICdpbnB1dCcsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICdpY29uQ2xhc3MnOiAnZmEgZmEtdXNlcicsIFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAnY29udHJvbFR5cGUnOiAndGV4dCcsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICd2YWx1ZSc6ICcnXHJcbiAgICAgICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICAgICAgICB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICdrZXknOiAncGFzc3dvcmQnLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAnbGFiZWwnOiAnUGFzc3dvcmQnLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAnY2xhc3MnOiAnaW5wdXQnLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAnaWNvbkNsYXNzJzogJ2ZhIGZhLWtleSBpY29uU2l6ZVMnLCBcclxuICAgICAgICAgICAgICAgICAgICAgICAgJ2NvbnRyb2xUeXBlJzogJ3RleHQnLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAndHlwZSc6ICdwYXNzd29yZCcsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICd2YWx1ZSc6ICcnXHJcbiAgICAgICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICAgICAgICB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICdrZXknOiAnbGFuZ3VhZ2UnLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAnY2xhc3MnOiAna2R4LWlucHV0LXNlbGVjdC13cmFwcGVyJyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgJ2ljb25DbGFzcyc6ICdmYSBmYS1nbG9iZScsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICd2YWx1ZSc6IF9jb25maWcudmFsdWUsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICdvcHRpb25zJzogX2NvbmZpZy5vcHRpb25zLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAnY29udHJvbFR5cGUnOiAnZHJvcGRvd24nXHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgXVxyXG4gICAgICAgICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICByZXR1cm4gZm9ybUlucHV0cztcclxuICAgIH1cclxuXHJcbiAgICBwdWJsaWMgZ2V0QnV0dG9uTGFiZWwoX3R5cGU6IHN0cmluZywgX2xhYmVsPzogc3RyaW5nKTogc3RyaW5nIHtcclxuICAgICAgICBsZXQgdGVtcExhYmVsOiBzdHJpbmcgPSBcIlN1Ym1pdFwiO1xyXG5cclxuICAgICAgICBzd2l0Y2ggKF90eXBlKSB7XHJcblxyXG4gICAgICAgICAgICBjYXNlIFwicmVzZXQtcGFzc3dvcmRcIjpcclxuICAgICAgICAgICAgICAgIGlmICh0eXBlb2YgX2xhYmVsICE9PSAndW5kZWZpbmVkJykgdGVtcExhYmVsID0gX2xhYmVsO1xyXG4gICAgICAgICAgICAgICAgZWxzZSB0ZW1wTGFiZWwgPSAnVXBkYXRlIFBhc3N3b3JkJ1xyXG4gICAgICAgICAgICAgICAgYnJlYWs7XHJcblxyXG4gICAgICAgICAgICBjYXNlIFwiZm9yZ2V0LXVzZXJuYW1lXCI6XHJcbiAgICAgICAgICAgICAgICBpZiAodHlwZW9mIF9sYWJlbCAhPT0gJ3VuZGVmaW5lZCcpIHRlbXBMYWJlbCA9IF9sYWJlbDtcclxuICAgICAgICAgICAgICAgIGVsc2UgdGVtcExhYmVsID0gJ1JlY292ZXIgVXNlcm5hbWUnXHJcbiAgICAgICAgICAgICAgICBicmVhaztcclxuXHJcbiAgICAgICAgICAgIGNhc2UgXCJmb3JnZXQtcGFzc3dvcmRcIjpcclxuICAgICAgICAgICAgICAgIGlmICh0eXBlb2YgX2xhYmVsICE9PSAndW5kZWZpbmVkJykgdGVtcExhYmVsID0gX2xhYmVsO1xyXG4gICAgICAgICAgICAgICAgZWxzZSB0ZW1wTGFiZWwgPSAnUmVzZXQgUGFzc3dvcmQnXHJcbiAgICAgICAgICAgICAgICBicmVhaztcclxuXHJcbiAgICAgICAgICAgIGRlZmF1bHQ6XHJcbiAgICAgICAgICAgICAgICBpZiAodHlwZW9mIF9sYWJlbCAhPT0gJ3VuZGVmaW5lZCcpIHRlbXBMYWJlbCA9IF9sYWJlbDtcclxuICAgICAgICAgICAgICAgIGVsc2UgdGVtcExhYmVsID0gJ0xvZ2luJ1xyXG4gICAgICAgICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICByZXR1cm4gdGVtcExhYmVsO1xyXG4gICAgfVxyXG5cclxuICAgIHB1YmxpYyBnZXRGb3JtTGlua3MoX2NvbmZpZzogSUxvZ2luQ29uZmlnLCBfdHlwZTogc3RyaW5nKTogQXJyYXk8SUZvcm1MaW5rQ29uZmlnPiB7XHJcbiAgICAgICAgbGV0IHJldHVybkRhdGE6IEFycmF5PElGb3JtTGlua0NvbmZpZz4gPSBbXVxyXG5cclxuICAgICAgICBsZXQgZGVmYXVsdExpbms6IGFueSA9IHRoaXMuZ2V0RGVmYXVsdEZvcm1MaW5rcyhfdHlwZSk7XHJcblxyXG4gICAgICAgIHN3aXRjaCAoX3R5cGUpIHtcclxuXHJcbiAgICAgICAgICAgIGNhc2UgXCJyZXNldC1wYXNzd29yZFwiOlxyXG4gICAgICAgICAgICAgICAgcmV0dXJuRGF0YS5wdXNoKE9iamVjdC5hc3NpZ24oZGVmYXVsdExpbmsuYmFjaywgX2NvbmZpZy5mb3JtTGlua3MuYmFjaykpXHJcbiAgICAgICAgICAgICAgICBicmVhaztcclxuXHJcbiAgICAgICAgICAgIGNhc2UgXCJmb3JnZXQtdXNlcm5hbWVcIjpcclxuICAgICAgICAgICAgICAgIHJldHVybkRhdGEucHVzaChPYmplY3QuYXNzaWduKGRlZmF1bHRMaW5rLmJhY2ssIF9jb25maWcuZm9ybUxpbmtzLmJhY2spKVxyXG4gICAgICAgICAgICAgICAgYnJlYWs7XHJcblxyXG4gICAgICAgICAgICBjYXNlIFwiZm9yZ2V0LXBhc3N3b3JkXCI6XHJcbiAgICAgICAgICAgICAgICByZXR1cm5EYXRhLnB1c2goT2JqZWN0LmFzc2lnbihkZWZhdWx0TGluay5iYWNrLCBfY29uZmlnLmZvcm1MaW5rcy5iYWNrKSlcclxuICAgICAgICAgICAgICAgIGJyZWFrO1xyXG5cclxuICAgICAgICAgICAgZGVmYXVsdDpcclxuICAgICAgICAgICAgICAgIGlmKF9jb25maWcuZm9ybUxpbmtzICYmIF9jb25maWcuZm9ybUxpbmtzLmZvcmdldFBhc3N3b3JkKVxyXG4gICAgICAgICAgICAgICAgcmV0dXJuRGF0YS5wdXNoKE9iamVjdC5hc3NpZ24oZGVmYXVsdExpbmsuZm9yZ2V0UGFzc3dvcmQsIF9jb25maWcuZm9ybUxpbmtzLmZvcmdldFBhc3N3b3JkKSlcclxuICAgICAgICAgICAgICAgIGlmKF9jb25maWcuZm9ybUxpbmtzICYmIF9jb25maWcuZm9ybUxpbmtzLmZvcmdldFVzZXIpXHJcbiAgICAgICAgICAgICAgICByZXR1cm5EYXRhLnB1c2goT2JqZWN0LmFzc2lnbihkZWZhdWx0TGluay5mb3JnZXRVc2VyLCBfY29uZmlnLmZvcm1MaW5rcy5mb3JnZXRVc2VyKSlcclxuICAgICAgICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgcmV0dXJuIHJldHVybkRhdGE7XHJcblxyXG4gICAgICAgIC8vIGlmIChfY29uZmlnLmhhc093blByb3BlcnR5KCdmb3JtTGlua3MnKSAmJiBfY29uZmlnLmZvcm1MaW5rcy5oYXNPd25Qcm9wZXJ0eShfbGlua1R5cGUpICYmIF9jb25maWcuZm9ybUxpbmtzW19saW5rVHlwZV0uaGFzT3duUHJvcGVydHkoJ3BhdGgnKSkge1xyXG4gICAgICAgIC8vICAgICAvL3JldHVybiBfY29uZmlnLmZvcm1MaW5rcy5mb3JnZXRQYXNzd29yZC5wYXRoO1xyXG4gICAgICAgIC8vICAgICBsZXQgZm9yZ2V0UGFzc3dvcmQ6IGFueSA9IHtcclxuICAgICAgICAvLyAgICAgICAgIHBhdGg6IF9jb25maWcuZm9ybUxpbmtzLmZvcmdldFBhc3N3b3JkLnBhdGhcclxuICAgICAgICAvLyAgICAgfVxyXG5cclxuICAgICAgICAvLyByZXR1cm4gZm9yZ2V0UGFzc3dvcmQ7XHJcbiAgICAgICAgLy8gfVxyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgZ2V0RGVmYXVsdEZvcm1MaW5rcyhfdHlwZTogc3RyaW5nKTogYW55IHtcclxuICAgICAgICBsZXQgcmV0dXJuRGF0YTogYW55ID0ge307XHJcblxyXG4gICAgICAgIHN3aXRjaCAoX3R5cGUpIHtcclxuXHJcbiAgICAgICAgICAgIGNhc2UgXCJyZXNldC1wYXNzd29yZFwiOlxyXG4gICAgICAgICAgICAgICAgcmV0dXJuRGF0YSA9IHtcclxuICAgICAgICAgICAgICAgICAgICBiYWNrOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGxhYmVsOiAnQmFjayB0byBsb2dpbj8nXHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgYnJlYWs7XHJcblxyXG4gICAgICAgICAgICBjYXNlIFwiZm9yZ2V0LXVzZXJuYW1lXCI6XHJcbiAgICAgICAgICAgICAgICByZXR1cm5EYXRhID0ge1xyXG4gICAgICAgICAgICAgICAgICAgIGJhY2s6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgbGFiZWw6ICdCYWNrIHRvIGxvZ2luPydcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICBicmVhaztcclxuXHJcbiAgICAgICAgICAgIGNhc2UgXCJmb3JnZXQtcGFzc3dvcmRcIjpcclxuICAgICAgICAgICAgICAgIHJldHVybkRhdGEgPSB7XHJcbiAgICAgICAgICAgICAgICAgICAgYmFjazoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBsYWJlbDogJ0JhY2sgdG8gbG9naW4/J1xyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIGJyZWFrO1xyXG5cclxuICAgICAgICAgICAgZGVmYXVsdDpcclxuICAgICAgICAgICAgICAgIHJldHVybkRhdGEgPSB7XHJcbiAgICAgICAgICAgICAgICAgICAgZm9yZ2V0UGFzc3dvcmQ6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgbGFiZWw6ICdGb3JnZXQgUGFzc3dvcmQ/J1xyXG4gICAgICAgICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICAgICAgICAgZm9yZ2V0VXNlcjoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBsYWJlbDogJ0ZvcmdldCBVc2VybmFtZT8nXHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIHJldHVybiByZXR1cm5EYXRhO1xyXG4gICAgfVxyXG5cclxuICAgIC8vIHB1YmxpYyBnZXRGb3JtQWxlcnRzKF9jb25maWc6IElMb2dpbkNvbmZpZywgX3R5cGU6IHN0cmluZyk6IElGb3JtQWxlcnRDb25maWcgfCBib29sZWFuIHtcclxuICAgIC8vICAgICBpZiAoX2NvbmZpZy5oYXNPd25Qcm9wZXJ0eSgnYWxlcnQnKSAmJiBfY29uZmlnLmFsZXJ0Lmhhc093blByb3BlcnR5KCdlcnJvck1zZycpKSB7XHJcbiAgICAvLyAgICAgICAgIGxldCByZXR1cm5EYXRhOiBJRm9ybUFsZXJ0Q29uZmlnID0gSlNPTi5wYXJzZShKU09OLnN0cmluZ2lmeShfY29uZmlnLmFsZXJ0KSk7XHJcblxyXG4gICAgLy8gICAgICAgICBpZiAoIV9jb25maWcuYWxlcnQuaGFzT3duUHJvcGVydHkoJ3N1Y2Nlc3NNc2cnKSAmJiBfdHlwZSAhPT0gJ2xvZ2luJykge1xyXG4gICAgLy8gICAgICAgICAgICAgcmV0dXJuRGF0YVsnc3VjY2Vzc01zZyddID0gJ0FuIGVtYWlsIHdpbGwgYmUgc2VuZCBzaG9ydGx5LiBQbGVhc2UgY2hlY2sgeW91ciBtYWlsYm94Lic7XHJcbiAgICAvLyAgICAgICAgIH1cclxuICAgIC8vICAgICAgICAgcmV0dXJuIHJldHVybkRhdGE7XHJcbiAgICAvLyAgICAgfVxyXG4gICAgLy8gICAgIHJldHVybiBmYWxzZTtcclxuICAgIC8vIH1cclxuXHJcbiAgICAvLyBwdWJsaWMgc2V0QWxlcnRNZXNzYWdlKF92YWx1ZTogc3RyaW5nLCBfZm9ybUFsZXJ0czogYW55KTogc3RyaW5nIHtcclxuICAgIC8vICAgICBsZXQgcmV0dXJuVmFsOiBzdHJpbmc7XHJcblxyXG4gICAgLy8gICAgIGlmIChfdmFsdWUgPT09ICdzdWNjZXNzJykge1xyXG4gICAgLy8gICAgICAgICByZXR1cm5WYWwgPSBfZm9ybUFsZXJ0cy5zdWNjZXNzTXNnO1xyXG4gICAgLy8gICAgIH0gZWxzZSBpZiAoX3ZhbHVlID09PSAnZGFuZ2VyJykge1xyXG4gICAgLy8gICAgICAgICByZXR1cm5WYWwgPSBfZm9ybUFsZXJ0cy5lcnJvck1zZztcclxuICAgIC8vICAgICB9XHJcblxyXG4gICAgLy8gICAgIHJldHVybiByZXR1cm5WYWw7XHJcbiAgICAvLyB9XHJcblxyXG5cclxuXHJcblxyXG4gICAgcHJpdmF0ZSBfc2V0UHJvZHVjdEFwcENvbmZpZyhfdXBkYXRlSGVhZGVyQ29uZmlnOiBhbnkpOiBhbnkge1xyXG4gICAgICAgIC8vIGxldCB0ZW1wSGVhZGVyQ29uZmlnOmFueSA9IF91cGRhdGVIZWFkZXJDb25maWc7XHJcbiAgICAgICAgdHJ5IHtcclxuICAgICAgICAgICAgaWYgKEFQUF9DT05GSUdTLmhhc093blByb3BlcnR5KCdwcm9kdWN0JykpIHtcclxuICAgICAgICAgICAgICAgIGxldCB0eXBlOiBzdHJpbmcgPSAoQVBQX0NPTkZJR1MucHJvZHVjdC5oYXNPd25Qcm9wZXJ0eSgndHlwZScpKSA/IEFQUF9DT05GSUdTLnByb2R1Y3QudHlwZSA6ICdpY29uJztcclxuXHJcbiAgICAgICAgICAgICAgICBpZiAoQVBQX0NPTkZJR1MucHJvZHVjdC5oYXNPd25Qcm9wZXJ0eSgnbmFtZScpKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgX3VwZGF0ZUhlYWRlckNvbmZpZy50aXRsZSA9IEFQUF9DT05GSUdTLnByb2R1Y3QubmFtZTtcclxuICAgICAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgICAgICBpZiAoQVBQX0NPTkZJR1MucHJvZHVjdC5oYXNPd25Qcm9wZXJ0eSgnc3JjJykpIHtcclxuICAgICAgICAgICAgICAgICAgICBzd2l0Y2ggKHR5cGUpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgY2FzZSAnaWNvbic6XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBfdXBkYXRlSGVhZGVyQ29uZmlnLmljb24gPSBBUFBfQ09ORklHUy5wcm9kdWN0LnNyYztcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBjYXNlICdpbWFnZSc6XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBfdXBkYXRlSGVhZGVyQ29uZmlnLmltZyA9IEFQUF9DT05GSUdTLnByb2R1Y3Quc3JjO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGRlZmF1bHQ6XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBicmVhaztcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9IGNhdGNoIChlcnIpIHtcclxuICAgICAgICAgICAgLy8gY29uc29sZS5sb2coZXJyKTtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIHJldHVybiBfdXBkYXRlSGVhZGVyQ29uZmlnO1xyXG4gICAgfVxyXG5cclxuXHJcblxyXG4gICAgZ2V0TG9nb1NpemVDbGFzcyhoZWFkZXJDb25maWc6IGFueSk6IHN0cmluZyB7XHJcbiAgICAgICAgaWYgKHR5cGVvZiBoZWFkZXJDb25maWcuaW1nU2l6ZSAhPT0gJ3VuZGVmaW5lZCcpIHJldHVybiBoZWFkZXJDb25maWcuaW1nU2l6ZTtcclxuICAgICAgICBpZiAodHlwZW9mIGhlYWRlckNvbmZpZy5pbWcgIT09ICd1bmRlZmluZWQnICYmIHR5cGVvZiBoZWFkZXJDb25maWcudGl0bGUgPT09ICd1bmRlZmluZWQnKSByZXR1cm4gJ2Z1bGwnO1xyXG4gICAgICAgIHJldHVybiAnc21hbGwnO1xyXG4gICAgfVxyXG5cclxuICAgIGdldERlbW9Mb2dpbihyZXF1ZXN0U3RyaW5nOiBzdHJpbmcpOiBhbnkge1xyXG4gICAgICAgIGxldCB0ZW1wU3RyaW5nOiBzdHJpbmcgPSByZXF1ZXN0U3RyaW5nLnJlcGxhY2UoJyAnLCAnJyk7XHJcbiAgICAgICAgbGV0IHNwbGl0U3RyaW5nOiBBcnJheTxzdHJpbmc+ID0gdGVtcFN0cmluZy5zcGxpdCgnLCcpO1xyXG4gICAgICAgIGxldCBkZW1vSW5mbzogYW55ID0ge307XHJcbiAgICAgICAgaWYgKHNwbGl0U3RyaW5nLmxlbmd0aCA9PT0gMikge1xyXG4gICAgICAgICAgICBkZW1vSW5mbyA9IHtcclxuICAgICAgICAgICAgICAgIHVzZXI6IHNwbGl0U3RyaW5nWzBdLFxyXG4gICAgICAgICAgICAgICAgcGFzczogc3BsaXRTdHJpbmdbMV1cclxuICAgICAgICAgICAgfTtcclxuICAgICAgICB9XHJcbiAgICAgICAgcmV0dXJuIGRlbW9JbmZvO1xyXG4gICAgfVxyXG5cclxufVxyXG4iXX0=