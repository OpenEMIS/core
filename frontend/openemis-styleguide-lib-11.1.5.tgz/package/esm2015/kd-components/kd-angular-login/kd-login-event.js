import { Injectable } from '@angular/core';
import { KdBroadcaster, } from '../kd-common/index';
import * as i0 from "@angular/core";
import * as i1 from "../kd-common/kd-broadcaster-svc";
export class KdLoginErrorEvent {
    constructor(_broadcaster) {
        this._broadcaster = _broadcaster;
    }
    /*setErrorMsg(data?: any): void {
        this._broadcaster.broadcast('ErrorMsg', data);
    }*/
    setAlertStatus(status) {
        this._broadcaster.broadcast('AlertStatus', status);
    }
    /*onSetErrorMsg(): Observable<any> {
        return this._broadcaster.on<any>('ErrorMsg');
    }*/
    onSetAlertStatus() {
        return this._broadcaster.on('AlertStatus');
    }
}
KdLoginErrorEvent.ɵprov = i0.ɵɵdefineInjectable({ factory: function KdLoginErrorEvent_Factory() { return new KdLoginErrorEvent(i0.ɵɵinject(i1.KdBroadcaster)); }, token: KdLoginErrorEvent, providedIn: "root" });
KdLoginErrorEvent.decorators = [
    { type: Injectable, args: [{
                providedIn: 'root'
            },] }
];
KdLoginErrorEvent.ctorParameters = () => [
    { type: KdBroadcaster }
];
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoia2QtbG9naW4tZXZlbnQuanMiLCJzb3VyY2VSb290IjoiQzoveGFtcHAvaHRkb2NzL1N0eWxlZ3VpZGUvaW9zdGctb3BlbmVtaXMtc3R5bGVndWlkZS9wcm9qZWN0cy9vcGVuZW1pcy1zdHlsZWd1aWRlLWxpYi9zcmMvIiwic291cmNlcyI6WyJrZC1jb21wb25lbnRzL2tkLWFuZ3VsYXItbG9naW4va2QtbG9naW4tZXZlbnQudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsT0FBTyxFQUFFLFVBQVUsRUFBRSxNQUFNLGVBQWUsQ0FBQztBQUUzQyxPQUFPLEVBQUUsYUFBYSxHQUFHLE1BQU0sb0JBQW9CLENBQUM7OztBQUtwRCxNQUFNLE9BQU8saUJBQWlCO0lBQzFCLFlBQW9CLFlBQTJCO1FBQTNCLGlCQUFZLEdBQVosWUFBWSxDQUFlO0lBQUksQ0FBQztJQUVwRDs7T0FFRztJQUVILGNBQWMsQ0FBQyxNQUFjO1FBQ3pCLElBQUksQ0FBQyxZQUFZLENBQUMsU0FBUyxDQUFDLGFBQWEsRUFBRSxNQUFNLENBQUMsQ0FBQztJQUN2RCxDQUFDO0lBRUQ7O09BRUc7SUFFTixnQkFBZ0I7UUFDVCxPQUFPLElBQUksQ0FBQyxZQUFZLENBQUMsRUFBRSxDQUFNLGFBQWEsQ0FBQyxDQUFDO0lBQ3BELENBQUM7Ozs7WUFwQkosVUFBVSxTQUFDO2dCQUNSLFVBQVUsRUFBRSxNQUFNO2FBQ3JCOzs7WUFKUSxhQUFhIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgSW5qZWN0YWJsZSB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xyXG5pbXBvcnQgeyBPYnNlcnZhYmxlIH0gZnJvbSAncnhqcyc7XHJcbmltcG9ydCB7IEtkQnJvYWRjYXN0ZXIsIH0gZnJvbSAnLi4va2QtY29tbW9uL2luZGV4JztcclxuXHJcbkBJbmplY3RhYmxlKHtcclxuICAgIHByb3ZpZGVkSW46ICdyb290J1xyXG59KVxyXG5leHBvcnQgY2xhc3MgS2RMb2dpbkVycm9yRXZlbnQge1xyXG4gICAgY29uc3RydWN0b3IocHJpdmF0ZSBfYnJvYWRjYXN0ZXI6IEtkQnJvYWRjYXN0ZXIpIHsgfVxyXG5cclxuICAgIC8qc2V0RXJyb3JNc2coZGF0YT86IGFueSk6IHZvaWQge1xyXG4gICAgICAgIHRoaXMuX2Jyb2FkY2FzdGVyLmJyb2FkY2FzdCgnRXJyb3JNc2cnLCBkYXRhKTtcclxuICAgIH0qL1xyXG5cclxuICAgIHNldEFsZXJ0U3RhdHVzKHN0YXR1czogc3RyaW5nKTogdm9pZCB7XHJcbiAgICAgICAgdGhpcy5fYnJvYWRjYXN0ZXIuYnJvYWRjYXN0KCdBbGVydFN0YXR1cycsIHN0YXR1cyk7XHJcbiAgICB9XHJcblxyXG4gICAgLypvblNldEVycm9yTXNnKCk6IE9ic2VydmFibGU8YW55PiB7XHJcbiAgICAgICAgcmV0dXJuIHRoaXMuX2Jyb2FkY2FzdGVyLm9uPGFueT4oJ0Vycm9yTXNnJyk7XHJcbiAgICB9Ki9cclxuXHJcblx0b25TZXRBbGVydFN0YXR1cygpOiBPYnNlcnZhYmxlPGFueT4ge1xyXG4gICAgICAgIHJldHVybiB0aGlzLl9icm9hZGNhc3Rlci5vbjxhbnk+KCdBbGVydFN0YXR1cycpO1xyXG4gICAgfVxyXG5cclxufVxyXG4iXX0=