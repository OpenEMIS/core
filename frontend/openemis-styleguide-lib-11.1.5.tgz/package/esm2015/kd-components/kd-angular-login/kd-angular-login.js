import { Component, Input, Output, EventEmitter, ViewEncapsulation, ViewContainerRef, Inject, Renderer2 } from '@angular/core';
import { KdLoginSvc } from './kd-angular-login-svc';
import { KdDomElemSvc } from '../kd-common/index';
import { SESSION_STORAGE } from 'ngx-webstorage-service';
export class KdLogin {
    constructor(_loginSvc, _renderer, _vcr, 
    //private _alertSvc: KdLoginErrorEvent,
    // private _http: Http,
    _domSvc, storage) {
        this._loginSvc = _loginSvc;
        this._renderer = _renderer;
        this._vcr = _vcr;
        this._domSvc = _domSvc;
        this.storage = storage;
        this.headerConfig = {};
        this.alertMessage = '';
        this.alertStatus = '';
        this.logoSize = '';
        this.buttonTitle = '';
        this._langVal = '';
        this.enableCstmFtr = false;
        this.outputLangIndex = new EventEmitter();
        // if (_productInfo) {
        //     this.headerConfig.icon = _productInfo.brandLogo.src;
        //     this.headerConfig.title = _productInfo.brandLogo.name;
        // }
    }
    ngOnChanges(_simpleChanges) {
        // console.log
        // if (_simpleChanges.hasOwnProperty('alert')) {
        //     this._formAlert = this._loginSvc.getFormAlerts(this.config, this.config.type);
        // }
    }
    ngOnInit() {
        this._initApi();
        //console.log('The session is: ' + this.storage.get('STORAGE_KEY') || 'This storage is empty');
        this._selectedLangIndex = this.storage.get('STORAGE_KEY') || '';
        this.headerConfig = this._loginSvc.getHeaderConfigValues(this.config, this.headerConfig);
        if (this.config.footer) {
            this.enableCstmFtr = true;
            this.customFooter = this.config.footer;
        }
        if (this.config.type === 'login') {
            this._langVal = this._loginSvc.getLangageDefaultValue(this.config);
            if (this._selectedLangIndex !== '') {
                this._langVal = this._selectedLangIndex;
                //console.log("Enter into this condition with the value: "+this._selectedLangIndex);
            }
            let langConfig = {
                options: this._loginSvc.getLanguageConfigValues(this.config),
                value: this._langVal
            };
            this.defaultedIndex = langConfig.value;
            this.dir = this._loginSvc.checkLanguageDir(langConfig.options, this.defaultedIndex);
            this.formInputs = this._loginSvc.getFormInputs(this.config.type, langConfig);
        }
        else {
            let langConfig;
            this.formInputs = this._loginSvc.getFormInputs(this.config.type, langConfig);
        }
        this.formLinks = this._loginSvc.getFormLinks(this.config, this.config.type);
        this.buttonTitle = this._loginSvc.getButtonLabel(this.config.type, this.config.button.label);
        // this._formAlert = this._loginSvc.getFormAlerts(this.config, this.config.type);
        // this._alertSub = this._alertSvc.onSetAlertStatus().subscribe((_value: any): void => {
        //    if (this._formAlert !== false) {
        //        this.alertMessage = this._loginSvc.setAlertMessage(_value, this._formAlert);
        //         this.alertStatus = _value;
        //     }
        // });
        // console.log('OnInit(): ' + this.dir);
        this._updateHTMLDirection(this.dir);
    }
    ngAfterViewInit() {
        // this.defaultedIndex;
        if (this._vcr.element.nativeElement.querySelector('#username') !== null) {
            this._vcr.element.nativeElement.querySelector('#username').focus();
        }
    }
    // ngOnDestroy(): void {
    //     this._alertSub.unsubscribe();
    //     this.storage.remove('STORAGE_KEY');
    //     this._httpSub.unsubscribe();
    // }
    close() {
        this.alertMessage = '';
    }
    onFormSubmit(_formData) {
        if (this.config.hasOwnProperty('button') && this.config.button.hasOwnProperty('callback')) {
            this.config.button.callback(_formData);
        }
    }
    onLanguageChange(_selectedIndex) {
        // console.log('Parent receive: ' + _selectedIndex);
        if (typeof _selectedIndex === 'undefined') {
            _selectedIndex = this.defaultedIndex;
        }
        this.dir = this._loginSvc.updateLanguageDir(this.config, _selectedIndex);
        this._updateHTMLDirection(this.dir);
        this.outputLangIndex.emit(_selectedIndex);
    }
    _initApi() {
        if (!this.api)
            return;
        this.api.setAlertMessage = (_type, _msg) => {
            // if(_type === 'danger'){
            //     this.config.alert.errorMsg = _msg;
            this.alertMessage = _msg;
            this.alertStatus = _type;
            // }else{
            //     this.config.alert.successMsg = _msg;
            // }
        };
    }
    _updateHTMLDirection(_dir) {
        let htmlTag = document.querySelector('html');
        let removeClass;
        if (typeof _dir === 'undefined') {
            // console.log('do nothing!');
        }
        else {
            if (_dir === 'rtl') {
                removeClass = 'ltr';
            }
            else {
                removeClass = 'rtl';
            }
            __ngRendererSetElementAttributeHelper(this._renderer, htmlTag, 'dir', _dir);
            __ngRendererSetElementAttributeHelper(this._renderer, htmlTag, 'lang', _dir);
            this._domSvc.removeClass(htmlTag, removeClass);
            this._domSvc.addClass(htmlTag, _dir);
        }
    }
}
KdLogin.decorators = [
    { type: Component, args: [{
                selector: 'kd-login',
                template: "<div class=\"kdx-body-wrapper\">\r\n\t<div class=\"kdx-login-container\">\t\r\n\t\t<div class=\"kdx-black-tint\"></div>\r\n\t\t<div class=\"kdx-login-content\">\r\n\t\t\t<div class=\"kdx-title\">\r\n\t\t\t\t<div class=\"kdx-login-table\">\r\n\t\t\t\t\t<div class=\"kdx-logo-wrapper\" [ngClass]=\"logoSize\">\r\n\t\t\t\t\t\t<i *ngIf=\"headerConfig.icon\" [ngClass]=\"headerConfig.icon\"></i>\r\n\t\t\t\t\t\t<div *ngIf=\"headerConfig.img\" class=\"kdx-image-wrapper\">\r\n\t\t\t\t\t\t\t<img [src]=\"headerConfig.img\"/>\r\n\t\t\t\t\t\t</div>\r\n\t\t\t\t\t</div>\r\n\t\t\t\t\t<h1 *ngIf=\"headerConfig.title\">{{headerConfig.title}}</h1>\r\n\t\t\t\t</div>\r\n\t\t\t</div>\r\n\r\n\t\t\t<div *ngIf=\"alertMessage != ''\" class=\"kdx-alert {{alertStatus}}\">\r\n\t\t\t\t<span>{{alertMessage}}</span>\r\n\t\t\t\t<a class=\"close\" (click)=\"close()\">\u00D7</a>\r\n\t\t\t</div>\r\n\r\n\t\t\t<div class=\"kdx kdx-login-form\">\r\n\t\t\t\t<div *ngIf=\"headerConfig.headerMsg\" class=\"header-msg\">{{headerConfig.headerMsg}}</div>\r\n\r\n\t\t\t\t<!-- Original Code -->\r\n \t\t\t\t<!--<div class=\"input text\">\r\n\t\t\t\t\t<input type=\"text\" name=\"username\" placeholder=\"Username\" id=\"username\" [(ngModel)]=\"inputInfo.user\">\r\n\t\t\t\t</div>\r\n\t\t\t\t<div class=\"input password\">\r\n\t\t\t\t\t<input type=\"password\" name=\"password\" placeholder=\"Password\" id=\"password\" [(ngModel)]=\"inputInfo.pass\">\r\n\t\t\t\t</div>\r\n\r\n\t\t\t\t<div class=\"kdx-input-select-wrapper\" *ngIf=\"languageConfig.show\">\r\n\t\t\t\t\t<select name=\"System[language]\" id=\"system-language\" [(ngModel)]=\"_selectedIndex\" (ngModelChange)=\"updateLanguage()\">\r\n\t\t\t\t\t\t<option *ngFor=\"let item of languageConfig.list; let i = index\" [selected]=\"\" [value]=\"i\">{{item.name}}</option>\r\n\t\t\t\t\t</select>\r\n\t\t\t\t</div>-->\r\n\t\t\t\t<!-- With Dyanmic Form -->\r\n\t\t\t\t<!--<div *ngFor=\"let loginForm of loginForms\">\r\n      \t\t\t\t\t<div [formGroup]=\"form\">\r\n\r\n      \t\t\t\t\t\t<div [ngSwitch]=\"loginForm.controlType\">\r\n      \t\t\t\t\t\t\t<div [class]=\"loginForm.class\">\r\n        \t\t\t\t\t\t<input *ngSwitchCase=\"'textbox'\" [placeholder]=\"loginForm.label\" [formControlName]=\"loginForm.key\" [id]=\"loginForm.key\" [type]=\"loginForm.type\">\r\n\r\n        \t\t\t\t\t\t<div class=\"kdx-input-select-wrapper icon-class\" *ngSwitchCase=\"'dropdown'\">\r\n    \t\t\t\t\t\t\t\t<select [id]=\"loginForm.key\" *ngSwitchCase=\"'dropdown'\" [formControlName]=\"loginForm.key\">\r\n      \t\t\t\t\t\t\t\t\t<option *ngFor=\"let opt of loginForm.options\" [value]=\"opt.key\">{{opt.value}}</option>\r\n    \t\t\t\t\t\t\t\t</select>\r\n    \t\t\t\t\t\t\t</div>\r\n    \t\t\t\t\t\t\t</div>\r\n      \t\t\t\t\t\t</div>\r\n      \t\t\t\t\t</div>\r\n    \t\t\t</div>-->\r\n\t\t\t\t<!-- With Dynamic form as a Component on its own -->\r\n\t\t\t\t<kd-loginform [formData]= 'formInputs' [buttonTitle]='buttonTitle' [defaultLangVal]='defaultedIndex' (onFormSubmit)='onFormSubmit($event)' (onLanguageChange)='onLanguageChange($event)'></kd-loginform>\r\n\r\n\t\t\t\t<div class=\"kdx-forget-password\" >\r\n\t\t\t\t\t<a *ngFor=\"let item of formLinks;\" [routerLink]=\"item.path\">{{item.label}}</a>\r\n\t\t\t\t</div>\r\n\r\n\t\t\t</div>\t\r\n\r\n\r\n\t\t</div>\r\n\t</div>\r\n</div>\r\n<kd-footer enableFloat='true' [enableCustom]='enableCstmFtr' [customMessage]='customFooter'></kd-footer>\r\n\r\n\r\n\r\n\r\n\r\n\r\n",
                encapsulation: ViewEncapsulation.None,
                providers: [
                    KdLoginSvc,
                    // KdLoginErrorEvent,
                    KdDomElemSvc
                    // KdHeaderInfo
                ],
                host: { 'class': 'kdx-login' }
            },] }
];
KdLogin.ctorParameters = () => [
    { type: KdLoginSvc },
    { type: Renderer2 },
    { type: ViewContainerRef },
    { type: KdDomElemSvc },
    { type: undefined, decorators: [{ type: Inject, args: [SESSION_STORAGE,] }] }
];
KdLogin.propDecorators = {
    config: [{ type: Input }],
    api: [{ type: Input }],
    outputLangIndex: [{ type: Output }]
};
function __ngRendererSplitNamespaceHelper(name) {
    if (name[0] === ":") {
        const match = name.match(/^:([^:]+):(.+)$/);
        return [match[1], match[2]];
    }
    return ["", name];
}
function __ngRendererSetElementAttributeHelper(renderer, element, namespaceAndName, value) {
    const [namespace, name] = __ngRendererSplitNamespaceHelper(namespaceAndName);
    if (value != null) {
        renderer.setAttribute(element, name, value, namespace);
    }
    else {
        renderer.removeAttribute(element, name, namespace);
    }
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoia2QtYW5ndWxhci1sb2dpbi5qcyIsInNvdXJjZVJvb3QiOiJDOi94YW1wcC9odGRvY3MvU3R5bGVndWlkZS9pb3N0Zy1vcGVuZW1pcy1zdHlsZWd1aWRlL3Byb2plY3RzL29wZW5lbWlzLXN0eWxlZ3VpZGUtbGliL3NyYy8iLCJzb3VyY2VzIjpbImtkLWNvbXBvbmVudHMva2QtYW5ndWxhci1sb2dpbi9rZC1hbmd1bGFyLWxvZ2luLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBLE9BQU8sRUFBRSxTQUFTLEVBQUUsS0FBSyxFQUFFLE1BQU0sRUFBRSxZQUFZLEVBQUUsaUJBQWlCLEVBQUUsZ0JBQWdCLEVBQTRELE1BQU0sRUFBNkIsU0FBUyxFQUFFLE1BQU0sZUFBZSxDQUFDO0FBR3BOLE9BQU8sRUFBRSxVQUFVLEVBQUUsTUFBTSx3QkFBd0IsQ0FBQztBQUVwRCxPQUFPLEVBQUUsWUFBWSxFQUFFLE1BQU0sb0JBQW9CLENBQUM7QUFXbEQsT0FBTyxFQUFFLGVBQWUsRUFBa0IsTUFBTSx3QkFBd0IsQ0FBQztBQWlCekUsTUFBTSxPQUFPLE9BQU87SUF5QmhCLFlBQ1ksU0FBcUIsRUFDckIsU0FBb0IsRUFDcEIsSUFBc0I7SUFDOUIsdUNBQXVDO0lBQ3ZDLHVCQUF1QjtJQUNmLE9BQXFCLEVBRUksT0FBdUI7UUFQaEQsY0FBUyxHQUFULFNBQVMsQ0FBWTtRQUNyQixjQUFTLEdBQVQsU0FBUyxDQUFXO1FBQ3BCLFNBQUksR0FBSixJQUFJLENBQWtCO1FBR3RCLFlBQU8sR0FBUCxPQUFPLENBQWM7UUFFSSxZQUFPLEdBQVAsT0FBTyxDQUFnQjtRQWhDckQsaUJBQVksR0FBa0IsRUFBRSxDQUFDO1FBR2pDLGlCQUFZLEdBQVcsRUFBRSxDQUFDO1FBQzFCLGdCQUFXLEdBQVcsRUFBRSxDQUFDO1FBRXpCLGFBQVEsR0FBVyxFQUFFLENBQUM7UUFDdEIsZ0JBQVcsR0FBVyxFQUFFLENBQUM7UUFTeEIsYUFBUSxHQUFXLEVBQUUsQ0FBQztRQUN2QixrQkFBYSxHQUFHLEtBQUssQ0FBQztRQUtuQixvQkFBZSxHQUFzQixJQUFJLFlBQVksRUFBRSxDQUFDO1FBYTlELHNCQUFzQjtRQUN0QiwyREFBMkQ7UUFDM0QsNkRBQTZEO1FBQzdELElBQUk7SUFDUixDQUFDO0lBRUQsV0FBVyxDQUFDLGNBQTZCO1FBQ3JDLGNBQWM7UUFDZCxnREFBZ0Q7UUFDaEQscUZBQXFGO1FBQ3JGLElBQUk7SUFDUixDQUFDO0lBRUQsUUFBUTtRQUNKLElBQUksQ0FBQyxRQUFRLEVBQUUsQ0FBQztRQUNoQiwrRkFBK0Y7UUFDL0YsSUFBSSxDQUFDLGtCQUFrQixHQUFHLElBQUksQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLGFBQWEsQ0FBQyxJQUFJLEVBQUUsQ0FBQztRQUVoRSxJQUFJLENBQUMsWUFBWSxHQUFHLElBQUksQ0FBQyxTQUFTLENBQUMscUJBQXFCLENBQUMsSUFBSSxDQUFDLE1BQU0sRUFBRSxJQUFJLENBQUMsWUFBWSxDQUFDLENBQUM7UUFFekYsSUFBRyxJQUFJLENBQUMsTUFBTSxDQUFDLE1BQU0sRUFBQztZQUNsQixJQUFJLENBQUMsYUFBYSxHQUFHLElBQUksQ0FBQztZQUMxQixJQUFJLENBQUMsWUFBWSxHQUFHLElBQUksQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDO1NBQzFDO1FBRUQsSUFBSSxJQUFJLENBQUMsTUFBTSxDQUFDLElBQUksS0FBSyxPQUFPLEVBQUU7WUFFOUIsSUFBSSxDQUFDLFFBQVEsR0FBRyxJQUFJLENBQUMsU0FBUyxDQUFDLHNCQUFzQixDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQztZQUVuRSxJQUFJLElBQUksQ0FBQyxrQkFBa0IsS0FBSyxFQUFFLEVBQUU7Z0JBQ2hDLElBQUksQ0FBQyxRQUFRLEdBQUcsSUFBSSxDQUFDLGtCQUFrQixDQUFDO2dCQUN4QyxvRkFBb0Y7YUFDdkY7WUFFRCxJQUFJLFVBQVUsR0FBUTtnQkFDbEIsT0FBTyxFQUFFLElBQUksQ0FBQyxTQUFTLENBQUMsdUJBQXVCLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQztnQkFDNUQsS0FBSyxFQUFFLElBQUksQ0FBQyxRQUFRO2FBQ3ZCLENBQUM7WUFFRixJQUFJLENBQUMsY0FBYyxHQUFHLFVBQVUsQ0FBQyxLQUFLLENBQUM7WUFDdkMsSUFBSSxDQUFDLEdBQUcsR0FBRyxJQUFJLENBQUMsU0FBUyxDQUFDLGdCQUFnQixDQUFDLFVBQVUsQ0FBQyxPQUFPLEVBQUUsSUFBSSxDQUFDLGNBQWMsQ0FBQyxDQUFDO1lBQ3BGLElBQUksQ0FBQyxVQUFVLEdBQUcsSUFBSSxDQUFDLFNBQVMsQ0FBQyxhQUFhLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxJQUFJLEVBQUUsVUFBVSxDQUFDLENBQUM7U0FFaEY7YUFBTTtZQUNILElBQUksVUFBZSxDQUFDO1lBQ3BCLElBQUksQ0FBQyxVQUFVLEdBQUcsSUFBSSxDQUFDLFNBQVMsQ0FBQyxhQUFhLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxJQUFJLEVBQUUsVUFBVSxDQUFDLENBQUM7U0FDaEY7UUFFRCxJQUFJLENBQUMsU0FBUyxHQUFHLElBQUksQ0FBQyxTQUFTLENBQUMsWUFBWSxDQUFDLElBQUksQ0FBQyxNQUFNLEVBQUUsSUFBSSxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsQ0FBQztRQUM1RSxJQUFJLENBQUMsV0FBVyxHQUFHLElBQUksQ0FBQyxTQUFTLENBQUMsY0FBYyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsSUFBSSxFQUFFLElBQUksQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxDQUFDO1FBRTdGLGlGQUFpRjtRQUVqRix3RkFBd0Y7UUFDeEYsc0NBQXNDO1FBQ3RDLHNGQUFzRjtRQUN0RixxQ0FBcUM7UUFDckMsUUFBUTtRQUNSLE1BQU07UUFFTix3Q0FBd0M7UUFDeEMsSUFBSSxDQUFDLG9CQUFvQixDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQztJQUV4QyxDQUFDO0lBRUQsZUFBZTtRQUNYLHVCQUF1QjtRQUV2QixJQUFJLElBQUksQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLGFBQWEsQ0FBQyxhQUFhLENBQUMsV0FBVyxDQUFDLEtBQUssSUFBSSxFQUFFO1lBQ3JFLElBQUksQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLGFBQWEsQ0FBQyxhQUFhLENBQUMsV0FBVyxDQUFDLENBQUMsS0FBSyxFQUFFLENBQUM7U0FDdEU7SUFDTCxDQUFDO0lBRUQsd0JBQXdCO0lBQ3hCLG9DQUFvQztJQUNwQywwQ0FBMEM7SUFDMUMsbUNBQW1DO0lBQ25DLElBQUk7SUFFSixLQUFLO1FBQ0QsSUFBSSxDQUFDLFlBQVksR0FBRyxFQUFFLENBQUM7SUFDM0IsQ0FBQztJQUdNLFlBQVksQ0FBQyxTQUFjO1FBQzlCLElBQUksSUFBSSxDQUFDLE1BQU0sQ0FBQyxjQUFjLENBQUMsUUFBUSxDQUFDLElBQUksSUFBSSxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsY0FBYyxDQUFDLFVBQVUsQ0FBQyxFQUFFO1lBQ3ZGLElBQUksQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLFFBQVEsQ0FBQyxTQUFTLENBQUMsQ0FBQztTQUMxQztJQUNMLENBQUM7SUFFTSxnQkFBZ0IsQ0FBQyxjQUFzQjtRQUMxQyxvREFBb0Q7UUFDcEQsSUFBSSxPQUFPLGNBQWMsS0FBSyxXQUFXLEVBQUU7WUFDdkMsY0FBYyxHQUFHLElBQUksQ0FBQyxjQUFjLENBQUM7U0FDeEM7UUFDRCxJQUFJLENBQUMsR0FBRyxHQUFHLElBQUksQ0FBQyxTQUFTLENBQUMsaUJBQWlCLENBQUMsSUFBSSxDQUFDLE1BQU0sRUFBRSxjQUFjLENBQUMsQ0FBQztRQUV6RSxJQUFJLENBQUMsb0JBQW9CLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFDO1FBQ3BDLElBQUksQ0FBQyxlQUFlLENBQUMsSUFBSSxDQUFDLGNBQWMsQ0FBQyxDQUFDO0lBQzlDLENBQUM7SUFFTyxRQUFRO1FBQ1osSUFBSSxDQUFDLElBQUksQ0FBQyxHQUFHO1lBQUUsT0FBTztRQUV0QixJQUFJLENBQUMsR0FBRyxDQUFDLGVBQWUsR0FBSSxDQUFDLEtBQVksRUFBRSxJQUFZLEVBQUUsRUFBRTtZQUN2RCwwQkFBMEI7WUFDMUIseUNBQXlDO1lBQ3JDLElBQUksQ0FBQyxZQUFZLEdBQUcsSUFBSSxDQUFDO1lBQ3pCLElBQUksQ0FBQyxXQUFXLEdBQUcsS0FBSyxDQUFDO1lBQzdCLFNBQVM7WUFDVCwyQ0FBMkM7WUFFM0MsSUFBSTtRQUNSLENBQUMsQ0FBQTtJQUNMLENBQUM7SUFFTyxvQkFBb0IsQ0FBQyxJQUFZO1FBRXJDLElBQUksT0FBTyxHQUFnQixRQUFRLENBQUMsYUFBYSxDQUFDLE1BQU0sQ0FBQyxDQUFDO1FBQzFELElBQUksV0FBbUIsQ0FBQztRQUV4QixJQUFJLE9BQU8sSUFBSSxLQUFLLFdBQVcsRUFBRTtZQUM3Qiw4QkFBOEI7U0FDakM7YUFBTTtZQUNILElBQUksSUFBSSxLQUFLLEtBQUssRUFBRTtnQkFDaEIsV0FBVyxHQUFHLEtBQUssQ0FBQzthQUN2QjtpQkFDSTtnQkFDRCxXQUFXLEdBQUcsS0FBSyxDQUFDO2FBQ3ZCO1lBQ0QscUNBQXFDLENBQUMsSUFBSSxDQUFDLFNBQVMsRUFBRSxPQUFPLEVBQUUsS0FBSyxFQUFFLElBQUksQ0FBQyxDQUFDO1lBQzVFLHFDQUFxQyxDQUFDLElBQUksQ0FBQyxTQUFTLEVBQUUsT0FBTyxFQUFFLE1BQU0sRUFBRSxJQUFJLENBQUMsQ0FBQztZQUU3RSxJQUFJLENBQUMsT0FBTyxDQUFDLFdBQVcsQ0FBQyxPQUFPLEVBQUUsV0FBVyxDQUFDLENBQUM7WUFDL0MsSUFBSSxDQUFDLE9BQU8sQ0FBQyxRQUFRLENBQUMsT0FBTyxFQUFFLElBQUksQ0FBQyxDQUFDO1NBQ3hDO0lBQ0wsQ0FBQzs7O1lBMUxKLFNBQVMsU0FBQztnQkFDUCxRQUFRLEVBQUUsVUFBVTtnQkFDcEIsMjNHQUFzQztnQkFDdEMsYUFBYSxFQUFFLGlCQUFpQixDQUFDLElBQUk7Z0JBQ3JDLFNBQVMsRUFBRTtvQkFDUCxVQUFVO29CQUNWLHFCQUFxQjtvQkFDckIsWUFBWTtvQkFDWixlQUFlO2lCQUNsQjtnQkFDRCxJQUFJLEVBQUUsRUFBRSxPQUFPLEVBQUUsV0FBVyxFQUFFO2FBRWpDOzs7WUE1QlEsVUFBVTtZQUhnSyxTQUFTO1lBQXhILGdCQUFnQjtZQUszRSxZQUFZOzRDQTZEWixNQUFNLFNBQUMsZUFBZTs7O3FCQVoxQixLQUFLO2tCQUNMLEtBQUs7OEJBQ0wsTUFBTTs7QUEySlgsU0FBUyxnQ0FBZ0MsQ0FBQyxJQUFnQztJQUN0RSxJQUFJLElBQUksQ0FBQyxDQUFDLENBQUMsS0FBSyxHQUFHLEVBQUU7UUFDakIsTUFBTSxLQUFLLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQyxpQkFBaUIsQ0FBQyxDQUFDO1FBQzVDLE9BQU8sQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLEVBQUUsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7S0FDL0I7SUFDRCxPQUFPLENBQUMsRUFBRSxFQUFFLElBQUksQ0FBQyxDQUFDO0FBQ3RCLENBQUM7QUFFRCxTQUFTLHFDQUFxQyxDQUFDLFFBQW9DLEVBQUUsT0FBbUMsRUFBRSxnQkFBNEMsRUFBRSxLQUFrQztJQUN0TSxNQUFNLENBQUMsU0FBUyxFQUFFLElBQUksQ0FBQyxHQUFHLGdDQUFnQyxDQUFDLGdCQUFnQixDQUFDLENBQUM7SUFDN0UsSUFBSSxLQUFLLElBQUksSUFBSSxFQUFFO1FBQ2YsUUFBUSxDQUFDLFlBQVksQ0FBQyxPQUFPLEVBQUUsSUFBSSxFQUFFLEtBQUssRUFBRSxTQUFTLENBQUMsQ0FBQztLQUMxRDtTQUNJO1FBQ0QsUUFBUSxDQUFDLGVBQWUsQ0FBQyxPQUFPLEVBQUUsSUFBSSxFQUFFLFNBQVMsQ0FBQyxDQUFDO0tBQ3REO0FBQ0wsQ0FBQyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IENvbXBvbmVudCwgSW5wdXQsIE91dHB1dCwgRXZlbnRFbWl0dGVyLCBWaWV3RW5jYXBzdWxhdGlvbiwgVmlld0NvbnRhaW5lclJlZiwgSG9zdExpc3RlbmVyLCBPbkluaXQsIEFmdGVyVmlld0luaXQsIE9uRGVzdHJveSwgT3B0aW9uYWwsIEluamVjdCwgSW5qZWN0YWJsZSwgU2ltcGxlQ2hhbmdlcywgUmVuZGVyZXIyIH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XHJcbmltcG9ydCB7IEZvcm1Hcm91cCB9IGZyb20gJ0Bhbmd1bGFyL2Zvcm1zJztcclxuaW1wb3J0IHsgU3Vic2NyaXB0aW9uIH0gZnJvbSAncnhqcyc7XHJcbmltcG9ydCB7IEtkTG9naW5TdmMgfSBmcm9tICcuL2tkLWFuZ3VsYXItbG9naW4tc3ZjJztcclxuaW1wb3J0IHsgS2RMb2dpbkVycm9yRXZlbnQgfSBmcm9tICcuL2tkLWxvZ2luLWV2ZW50JztcclxuaW1wb3J0IHsgS2REb21FbGVtU3ZjIH0gZnJvbSAnLi4va2QtY29tbW9uL2luZGV4JztcclxuLy8gaW1wb3J0IHsgS2RIZWFkZXJJbmZvIH0gZnJvbSAnLi4va2QtYW5ndWxhci1oZWFkZXIva2QtYW5ndWxhci1oZWFkZXInO1xyXG5pbXBvcnQge1xyXG4gICAgSUxvZ2luQXBpLFxyXG4gICAgSUxvZ2luQ29uZmlnLFxyXG4gICAgSUhlYWRlckNvbmZpZyxcclxuICAgIElMYW5ndWFnZUNvbmZpZyxcclxuICAgIElGb3JtTGlua0NvbmZpZyxcclxuICAgIElGb3JtQWxlcnRDb25maWdcclxufSBmcm9tICcuL2tkLWFuZ3VsYXItbG9naW4taW50ZXJmYWNlJztcclxuXHJcbmltcG9ydCB7IFNFU1NJT05fU1RPUkFHRSwgU3RvcmFnZVNlcnZpY2UgfSBmcm9tICduZ3gtd2Vic3RvcmFnZS1zZXJ2aWNlJztcclxuXHJcblxyXG5AQ29tcG9uZW50KHtcclxuICAgIHNlbGVjdG9yOiAna2QtbG9naW4nLFxyXG4gICAgdGVtcGxhdGVVcmw6ICcuL2tkLWFuZ3VsYXItbG9naW4uaHRtbCcsXHJcbiAgICBlbmNhcHN1bGF0aW9uOiBWaWV3RW5jYXBzdWxhdGlvbi5Ob25lLFxyXG4gICAgcHJvdmlkZXJzOiBbXHJcbiAgICAgICAgS2RMb2dpblN2YyxcclxuICAgICAgICAvLyBLZExvZ2luRXJyb3JFdmVudCxcclxuICAgICAgICBLZERvbUVsZW1TdmNcclxuICAgICAgICAvLyBLZEhlYWRlckluZm9cclxuICAgIF0sXHJcbiAgICBob3N0OiB7ICdjbGFzcyc6ICdrZHgtbG9naW4nIH1cclxuXHJcbn0pXHJcblxyXG5leHBvcnQgY2xhc3MgS2RMb2dpbiBpbXBsZW1lbnRzIE9uSW5pdCwgQWZ0ZXJWaWV3SW5pdCB7XHJcbiAgICBwdWJsaWMgaGVhZGVyQ29uZmlnOiBJSGVhZGVyQ29uZmlnID0ge307XHJcbiAgICBwdWJsaWMgZGlyOiBzdHJpbmc7XHJcblxyXG4gICAgcHVibGljIGFsZXJ0TWVzc2FnZTogc3RyaW5nID0gJyc7XHJcbiAgICBwdWJsaWMgYWxlcnRTdGF0dXM6IHN0cmluZyA9ICcnO1xyXG5cclxuICAgIHB1YmxpYyBsb2dvU2l6ZTogc3RyaW5nID0gJyc7XHJcbiAgICBwdWJsaWMgYnV0dG9uVGl0bGU6IHN0cmluZyA9ICcnO1xyXG5cclxuICAgIHB1YmxpYyBmb3JtSW5wdXRzOiBBcnJheTxhbnk+O1xyXG4gICAgcHVibGljIGZvcm1MaW5rczogQXJyYXk8YW55PjtcclxuXHJcbiAgICBwcml2YXRlIF9mb3JtQWxlcnQ6IElGb3JtQWxlcnRDb25maWcgfCBib29sZWFuO1xyXG4gICAgcHVibGljIGRlZmF1bHRlZEluZGV4OiBzdHJpbmc7XHJcbiAgICBwcml2YXRlIF9hbGVydFN1YjogU3Vic2NyaXB0aW9uO1xyXG4gICAgcHJpdmF0ZSBfc2VsZWN0ZWRMYW5nSW5kZXg6IHN0cmluZztcclxuICAgIHByaXZhdGUgX2xhbmdWYWw6IHN0cmluZyA9ICcnO1xyXG4gICAgcHVibGljIGVuYWJsZUNzdG1GdHIgPSBmYWxzZTtcclxuICAgIHB1YmxpYyBjdXN0b21Gb290ZXI6IHN0cmluZztcclxuXHJcbiAgICBASW5wdXQoKSBjb25maWc6IElMb2dpbkNvbmZpZztcclxuICAgIEBJbnB1dCgpIGFwaT86IElMb2dpbkFwaTtcclxuICAgIEBPdXRwdXQoKSBvdXRwdXRMYW5nSW5kZXg6IEV2ZW50RW1pdHRlcjxhbnk+ID0gbmV3IEV2ZW50RW1pdHRlcigpO1xyXG5cclxuICAgIGNvbnN0cnVjdG9yKFxyXG4gICAgICAgIHByaXZhdGUgX2xvZ2luU3ZjOiBLZExvZ2luU3ZjLFxyXG4gICAgICAgIHByaXZhdGUgX3JlbmRlcmVyOiBSZW5kZXJlcjIsXHJcbiAgICAgICAgcHJpdmF0ZSBfdmNyOiBWaWV3Q29udGFpbmVyUmVmLFxyXG4gICAgICAgIC8vcHJpdmF0ZSBfYWxlcnRTdmM6IEtkTG9naW5FcnJvckV2ZW50LFxyXG4gICAgICAgIC8vIHByaXZhdGUgX2h0dHA6IEh0dHAsXHJcbiAgICAgICAgcHJpdmF0ZSBfZG9tU3ZjOiBLZERvbUVsZW1TdmMsXHJcblxyXG4gICAgICAgIEBJbmplY3QoU0VTU0lPTl9TVE9SQUdFKSBwcml2YXRlIHN0b3JhZ2U6IFN0b3JhZ2VTZXJ2aWNlLFxyXG4gICAgICAgIC8vIEBPcHRpb25hbCgpIF9wcm9kdWN0SW5mbzogS2RIZWFkZXJJbmZvXHJcbiAgICApIHtcclxuICAgICAgICAvLyBpZiAoX3Byb2R1Y3RJbmZvKSB7XHJcbiAgICAgICAgLy8gICAgIHRoaXMuaGVhZGVyQ29uZmlnLmljb24gPSBfcHJvZHVjdEluZm8uYnJhbmRMb2dvLnNyYztcclxuICAgICAgICAvLyAgICAgdGhpcy5oZWFkZXJDb25maWcudGl0bGUgPSBfcHJvZHVjdEluZm8uYnJhbmRMb2dvLm5hbWU7XHJcbiAgICAgICAgLy8gfVxyXG4gICAgfVxyXG5cclxuICAgIG5nT25DaGFuZ2VzKF9zaW1wbGVDaGFuZ2VzOiBTaW1wbGVDaGFuZ2VzKTogdm9pZCB7XHJcbiAgICAgICAgLy8gY29uc29sZS5sb2dcclxuICAgICAgICAvLyBpZiAoX3NpbXBsZUNoYW5nZXMuaGFzT3duUHJvcGVydHkoJ2FsZXJ0JykpIHtcclxuICAgICAgICAvLyAgICAgdGhpcy5fZm9ybUFsZXJ0ID0gdGhpcy5fbG9naW5TdmMuZ2V0Rm9ybUFsZXJ0cyh0aGlzLmNvbmZpZywgdGhpcy5jb25maWcudHlwZSk7XHJcbiAgICAgICAgLy8gfVxyXG4gICAgfVxyXG5cclxuICAgIG5nT25Jbml0KCk6IHZvaWQge1xyXG4gICAgICAgIHRoaXMuX2luaXRBcGkoKTtcclxuICAgICAgICAvL2NvbnNvbGUubG9nKCdUaGUgc2Vzc2lvbiBpczogJyArIHRoaXMuc3RvcmFnZS5nZXQoJ1NUT1JBR0VfS0VZJykgfHwgJ1RoaXMgc3RvcmFnZSBpcyBlbXB0eScpO1xyXG4gICAgICAgIHRoaXMuX3NlbGVjdGVkTGFuZ0luZGV4ID0gdGhpcy5zdG9yYWdlLmdldCgnU1RPUkFHRV9LRVknKSB8fCAnJztcclxuXHJcbiAgICAgICAgdGhpcy5oZWFkZXJDb25maWcgPSB0aGlzLl9sb2dpblN2Yy5nZXRIZWFkZXJDb25maWdWYWx1ZXModGhpcy5jb25maWcsIHRoaXMuaGVhZGVyQ29uZmlnKTtcclxuICAgICAgICBcclxuICAgICAgICBpZih0aGlzLmNvbmZpZy5mb290ZXIpe1xyXG4gICAgICAgICAgICB0aGlzLmVuYWJsZUNzdG1GdHIgPSB0cnVlO1xyXG4gICAgICAgICAgICB0aGlzLmN1c3RvbUZvb3RlciA9IHRoaXMuY29uZmlnLmZvb3RlcjtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIGlmICh0aGlzLmNvbmZpZy50eXBlID09PSAnbG9naW4nKSB7XHJcblxyXG4gICAgICAgICAgICB0aGlzLl9sYW5nVmFsID0gdGhpcy5fbG9naW5TdmMuZ2V0TGFuZ2FnZURlZmF1bHRWYWx1ZSh0aGlzLmNvbmZpZyk7XHJcblxyXG4gICAgICAgICAgICBpZiAodGhpcy5fc2VsZWN0ZWRMYW5nSW5kZXggIT09ICcnKSB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLl9sYW5nVmFsID0gdGhpcy5fc2VsZWN0ZWRMYW5nSW5kZXg7XHJcbiAgICAgICAgICAgICAgICAvL2NvbnNvbGUubG9nKFwiRW50ZXIgaW50byB0aGlzIGNvbmRpdGlvbiB3aXRoIHRoZSB2YWx1ZTogXCIrdGhpcy5fc2VsZWN0ZWRMYW5nSW5kZXgpO1xyXG4gICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICBsZXQgbGFuZ0NvbmZpZzogYW55ID0ge1xyXG4gICAgICAgICAgICAgICAgb3B0aW9uczogdGhpcy5fbG9naW5TdmMuZ2V0TGFuZ3VhZ2VDb25maWdWYWx1ZXModGhpcy5jb25maWcpLFxyXG4gICAgICAgICAgICAgICAgdmFsdWU6IHRoaXMuX2xhbmdWYWxcclxuICAgICAgICAgICAgfTtcclxuICAgICAgICAgICAgXHJcbiAgICAgICAgICAgIHRoaXMuZGVmYXVsdGVkSW5kZXggPSBsYW5nQ29uZmlnLnZhbHVlO1xyXG4gICAgICAgICAgICB0aGlzLmRpciA9IHRoaXMuX2xvZ2luU3ZjLmNoZWNrTGFuZ3VhZ2VEaXIobGFuZ0NvbmZpZy5vcHRpb25zLCB0aGlzLmRlZmF1bHRlZEluZGV4KTtcclxuICAgICAgICAgICAgdGhpcy5mb3JtSW5wdXRzID0gdGhpcy5fbG9naW5TdmMuZ2V0Rm9ybUlucHV0cyh0aGlzLmNvbmZpZy50eXBlLCBsYW5nQ29uZmlnKTtcclxuXHJcbiAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgbGV0IGxhbmdDb25maWc6IGFueTtcclxuICAgICAgICAgICAgdGhpcy5mb3JtSW5wdXRzID0gdGhpcy5fbG9naW5TdmMuZ2V0Rm9ybUlucHV0cyh0aGlzLmNvbmZpZy50eXBlLCBsYW5nQ29uZmlnKTtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIHRoaXMuZm9ybUxpbmtzID0gdGhpcy5fbG9naW5TdmMuZ2V0Rm9ybUxpbmtzKHRoaXMuY29uZmlnLCB0aGlzLmNvbmZpZy50eXBlKTtcclxuICAgICAgICB0aGlzLmJ1dHRvblRpdGxlID0gdGhpcy5fbG9naW5TdmMuZ2V0QnV0dG9uTGFiZWwodGhpcy5jb25maWcudHlwZSwgdGhpcy5jb25maWcuYnV0dG9uLmxhYmVsKTtcclxuXHJcbiAgICAgICAgLy8gdGhpcy5fZm9ybUFsZXJ0ID0gdGhpcy5fbG9naW5TdmMuZ2V0Rm9ybUFsZXJ0cyh0aGlzLmNvbmZpZywgdGhpcy5jb25maWcudHlwZSk7XHJcbiAgICAgICAgXHJcbiAgICAgICAgLy8gdGhpcy5fYWxlcnRTdWIgPSB0aGlzLl9hbGVydFN2Yy5vblNldEFsZXJ0U3RhdHVzKCkuc3Vic2NyaWJlKChfdmFsdWU6IGFueSk6IHZvaWQgPT4ge1xyXG4gICAgICAgIC8vICAgIGlmICh0aGlzLl9mb3JtQWxlcnQgIT09IGZhbHNlKSB7XHJcbiAgICAgICAgLy8gICAgICAgIHRoaXMuYWxlcnRNZXNzYWdlID0gdGhpcy5fbG9naW5TdmMuc2V0QWxlcnRNZXNzYWdlKF92YWx1ZSwgdGhpcy5fZm9ybUFsZXJ0KTtcclxuICAgICAgICAvLyAgICAgICAgIHRoaXMuYWxlcnRTdGF0dXMgPSBfdmFsdWU7XHJcbiAgICAgICAgLy8gICAgIH1cclxuICAgICAgICAvLyB9KTtcclxuXHJcbiAgICAgICAgLy8gY29uc29sZS5sb2coJ09uSW5pdCgpOiAnICsgdGhpcy5kaXIpO1xyXG4gICAgICAgIHRoaXMuX3VwZGF0ZUhUTUxEaXJlY3Rpb24odGhpcy5kaXIpO1xyXG5cclxuICAgIH1cclxuXHJcbiAgICBuZ0FmdGVyVmlld0luaXQoKTogdm9pZCB7XHJcbiAgICAgICAgLy8gdGhpcy5kZWZhdWx0ZWRJbmRleDtcclxuXHJcbiAgICAgICAgaWYgKHRoaXMuX3Zjci5lbGVtZW50Lm5hdGl2ZUVsZW1lbnQucXVlcnlTZWxlY3RvcignI3VzZXJuYW1lJykgIT09IG51bGwpIHtcclxuICAgICAgICAgICAgdGhpcy5fdmNyLmVsZW1lbnQubmF0aXZlRWxlbWVudC5xdWVyeVNlbGVjdG9yKCcjdXNlcm5hbWUnKS5mb2N1cygpO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICAvLyBuZ09uRGVzdHJveSgpOiB2b2lkIHtcclxuICAgIC8vICAgICB0aGlzLl9hbGVydFN1Yi51bnN1YnNjcmliZSgpO1xyXG4gICAgLy8gICAgIHRoaXMuc3RvcmFnZS5yZW1vdmUoJ1NUT1JBR0VfS0VZJyk7XHJcbiAgICAvLyAgICAgdGhpcy5faHR0cFN1Yi51bnN1YnNjcmliZSgpO1xyXG4gICAgLy8gfVxyXG5cclxuICAgIGNsb3NlKCk6IHZvaWQge1xyXG4gICAgICAgIHRoaXMuYWxlcnRNZXNzYWdlID0gJyc7XHJcbiAgICB9XHJcblxyXG5cclxuICAgIHB1YmxpYyBvbkZvcm1TdWJtaXQoX2Zvcm1EYXRhOiBhbnkpOiB2b2lkIHtcclxuICAgICAgICBpZiAodGhpcy5jb25maWcuaGFzT3duUHJvcGVydHkoJ2J1dHRvbicpICYmIHRoaXMuY29uZmlnLmJ1dHRvbi5oYXNPd25Qcm9wZXJ0eSgnY2FsbGJhY2snKSkge1xyXG4gICAgICAgICAgICB0aGlzLmNvbmZpZy5idXR0b24uY2FsbGJhY2soX2Zvcm1EYXRhKTtcclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgcHVibGljIG9uTGFuZ3VhZ2VDaGFuZ2UoX3NlbGVjdGVkSW5kZXg6IHN0cmluZyk6IHZvaWQge1xyXG4gICAgICAgIC8vIGNvbnNvbGUubG9nKCdQYXJlbnQgcmVjZWl2ZTogJyArIF9zZWxlY3RlZEluZGV4KTtcclxuICAgICAgICBpZiAodHlwZW9mIF9zZWxlY3RlZEluZGV4ID09PSAndW5kZWZpbmVkJykge1xyXG4gICAgICAgICAgICBfc2VsZWN0ZWRJbmRleCA9IHRoaXMuZGVmYXVsdGVkSW5kZXg7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIHRoaXMuZGlyID0gdGhpcy5fbG9naW5TdmMudXBkYXRlTGFuZ3VhZ2VEaXIodGhpcy5jb25maWcsIF9zZWxlY3RlZEluZGV4KTtcclxuXHJcbiAgICAgICAgdGhpcy5fdXBkYXRlSFRNTERpcmVjdGlvbih0aGlzLmRpcik7XHJcbiAgICAgICAgdGhpcy5vdXRwdXRMYW5nSW5kZXguZW1pdChfc2VsZWN0ZWRJbmRleCk7XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfaW5pdEFwaSgpOiB2b2lkIHtcclxuICAgICAgICBpZiAoIXRoaXMuYXBpKSByZXR1cm47XHJcblxyXG4gICAgICAgIHRoaXMuYXBpLnNldEFsZXJ0TWVzc2FnZSA9ICAoX3R5cGU6c3RyaW5nLCBfbXNnOiBzdHJpbmcpID0+IHtcclxuICAgICAgICAgICAgLy8gaWYoX3R5cGUgPT09ICdkYW5nZXInKXtcclxuICAgICAgICAgICAgLy8gICAgIHRoaXMuY29uZmlnLmFsZXJ0LmVycm9yTXNnID0gX21zZztcclxuICAgICAgICAgICAgICAgIHRoaXMuYWxlcnRNZXNzYWdlID0gX21zZztcclxuICAgICAgICAgICAgICAgIHRoaXMuYWxlcnRTdGF0dXMgPSBfdHlwZTtcclxuICAgICAgICAgICAgLy8gfWVsc2V7XHJcbiAgICAgICAgICAgIC8vICAgICB0aGlzLmNvbmZpZy5hbGVydC5zdWNjZXNzTXNnID0gX21zZztcclxuXHJcbiAgICAgICAgICAgIC8vIH1cclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfdXBkYXRlSFRNTERpcmVjdGlvbihfZGlyOiBzdHJpbmcpOiB2b2lkIHtcclxuXHJcbiAgICAgICAgbGV0IGh0bWxUYWc6IEhUTUxFbGVtZW50ID0gZG9jdW1lbnQucXVlcnlTZWxlY3RvcignaHRtbCcpO1xyXG4gICAgICAgIGxldCByZW1vdmVDbGFzczogc3RyaW5nO1xyXG5cclxuICAgICAgICBpZiAodHlwZW9mIF9kaXIgPT09ICd1bmRlZmluZWQnKSB7XHJcbiAgICAgICAgICAgIC8vIGNvbnNvbGUubG9nKCdkbyBub3RoaW5nIScpO1xyXG4gICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgIGlmIChfZGlyID09PSAncnRsJykge1xyXG4gICAgICAgICAgICAgICAgcmVtb3ZlQ2xhc3MgPSAnbHRyJztcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgICAgIHJlbW92ZUNsYXNzID0gJ3J0bCc7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgX19uZ1JlbmRlcmVyU2V0RWxlbWVudEF0dHJpYnV0ZUhlbHBlcih0aGlzLl9yZW5kZXJlciwgaHRtbFRhZywgJ2RpcicsIF9kaXIpO1xyXG4gICAgICAgICAgICBfX25nUmVuZGVyZXJTZXRFbGVtZW50QXR0cmlidXRlSGVscGVyKHRoaXMuX3JlbmRlcmVyLCBodG1sVGFnLCAnbGFuZycsIF9kaXIpO1xyXG5cclxuICAgICAgICAgICAgdGhpcy5fZG9tU3ZjLnJlbW92ZUNsYXNzKGh0bWxUYWcsIHJlbW92ZUNsYXNzKTtcclxuICAgICAgICAgICAgdGhpcy5fZG9tU3ZjLmFkZENsYXNzKGh0bWxUYWcsIF9kaXIpO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbn1cclxuXHJcbnR5cGUgQW55RHVyaW5nUmVuZGVyZXJNaWdyYXRpb24gPSBhbnk7XHJcblxyXG5mdW5jdGlvbiBfX25nUmVuZGVyZXJTcGxpdE5hbWVzcGFjZUhlbHBlcihuYW1lOiBBbnlEdXJpbmdSZW5kZXJlck1pZ3JhdGlvbikge1xyXG4gICAgaWYgKG5hbWVbMF0gPT09IFwiOlwiKSB7XHJcbiAgICAgICAgY29uc3QgbWF0Y2ggPSBuYW1lLm1hdGNoKC9eOihbXjpdKyk6KC4rKSQvKTtcclxuICAgICAgICByZXR1cm4gW21hdGNoWzFdLCBtYXRjaFsyXV07XHJcbiAgICB9XHJcbiAgICByZXR1cm4gW1wiXCIsIG5hbWVdO1xyXG59XHJcblxyXG5mdW5jdGlvbiBfX25nUmVuZGVyZXJTZXRFbGVtZW50QXR0cmlidXRlSGVscGVyKHJlbmRlcmVyOiBBbnlEdXJpbmdSZW5kZXJlck1pZ3JhdGlvbiwgZWxlbWVudDogQW55RHVyaW5nUmVuZGVyZXJNaWdyYXRpb24sIG5hbWVzcGFjZUFuZE5hbWU6IEFueUR1cmluZ1JlbmRlcmVyTWlncmF0aW9uLCB2YWx1ZT86IEFueUR1cmluZ1JlbmRlcmVyTWlncmF0aW9uKSB7XHJcbiAgICBjb25zdCBbbmFtZXNwYWNlLCBuYW1lXSA9IF9fbmdSZW5kZXJlclNwbGl0TmFtZXNwYWNlSGVscGVyKG5hbWVzcGFjZUFuZE5hbWUpO1xyXG4gICAgaWYgKHZhbHVlICE9IG51bGwpIHtcclxuICAgICAgICByZW5kZXJlci5zZXRBdHRyaWJ1dGUoZWxlbWVudCwgbmFtZSwgdmFsdWUsIG5hbWVzcGFjZSk7XHJcbiAgICB9XHJcbiAgICBlbHNlIHtcclxuICAgICAgICByZW5kZXJlci5yZW1vdmVBdHRyaWJ1dGUoZWxlbWVudCwgbmFtZSwgbmFtZXNwYWNlKTtcclxuICAgIH1cclxufVxyXG4iXX0=