import { Component, Input, Output, EventEmitter, HostListener } from '@angular/core';
import { KdLoginFormControlService } from '../form/kd-loginform-control.service';
import { KdLoginSvc } from '../kd-angular-login-svc';
export class KdLoginForm {
    constructor(_loginSvc, _loginFormSvc) {
        this._loginSvc = _loginSvc;
        this._loginFormSvc = _loginFormSvc;
        this.loginForms = [];
        this.onFormSubmit = new EventEmitter();
        this.onLanguageChange = new EventEmitter();
    }
    onKeyUp(_keyEvent) {
        if (_keyEvent.key === 'Enter') {
            this.buttonSubmit();
        }
    }
    ngOnInit() {
        this.loginForms = this._loginFormSvc.getLoginForm(this.formData);
        this.form = this._loginFormSvc.toFormGroup(this.loginForms);
        //this.defaultVal = this.formData[2].value;
        //console.log('Default value: ' + this.defaultLangVal);
        this.selectedIndex = this.defaultLangVal;
    }
    buttonSubmit() {
        let tempData = {
            formInputs: this.loginForms,
            formValues: this.form.value
        };
        this.onFormSubmit.emit(tempData);
    }
    updateDefaultLanguage() {
        //console.log('From Child: ' + this.selectedIndex);
        this.onLanguageChange.emit(this.selectedIndex);
    }
}
KdLoginForm.decorators = [
    { type: Component, args: [{
                selector: 'kd-loginform',
                template: "<div *ngFor=\"let loginForm of loginForms\">\r\n    <div [formGroup]=\"form\">\r\n        <div [ngSwitch]=\"loginForm.controlType\">\r\n            <div [class]=\"loginForm.class\">\r\n                <!--<i class=\"fa fa-user\"></i>-->\r\n                <input *ngSwitchCase=\"'text'\" [placeholder]=\"loginForm.label\" [formControlName]=\"loginForm.key\" [id]=\"loginForm.key\" [type]=\"loginForm.type\"><i [class]=\"loginForm.iconClass\"></i>\r\n                <div class=\"loginForm.class\" *ngSwitchCase=\"'dropdown'\">\r\n                    <!--<select [id]=\"loginForm.key\" *ngSwitchCase=\"'dropdown'\" [formControlName]=\"loginForm.key\" (ngModelChange)=\"updateLanguage()\">-->\r\n                        <select [id]=\"loginForm.key\" *ngSwitchCase=\"'dropdown'\" [formControlName]=\"loginForm.key\" [(ngModel)]=\"selectedIndex\" (ngModelChange)=\"updateDefaultLanguage()\">\r\n                        <option *ngFor=\"let opt of loginForm.options\" [value]=\"opt.key\">{{opt.value}}</option>\r\n                    </select><i [class]=\"loginForm.iconClass\"></i>\r\n                </div>\r\n            </div>\r\n        </div>\r\n    </div>\r\n</div>\r\n<button name=\"submit\" class=\"btn btn-primary kdx-btn-login\" (click)=\"buttonSubmit()\">{{buttonTitle}}</button>\r\n",
                providers: [
                    KdLoginFormControlService
                ],
                host: { 'class': 'kdx-login' }
            },] }
];
KdLoginForm.ctorParameters = () => [
    { type: KdLoginSvc },
    { type: KdLoginFormControlService }
];
KdLoginForm.propDecorators = {
    formData: [{ type: Input }],
    loginForms: [{ type: Input }],
    config: [{ type: Input }],
    buttonTitle: [{ type: Input }],
    defaultLangVal: [{ type: Input }],
    onFormSubmit: [{ type: Output }],
    onLanguageChange: [{ type: Output }],
    onKeyUp: [{ type: HostListener, args: ['document:keyup', ['$event'],] }]
};
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoia2QtbG9naW5mb3JtLmpzIiwic291cmNlUm9vdCI6IkM6L3hhbXBwL2h0ZG9jcy9TdHlsZWd1aWRlL2lvc3RnLW9wZW5lbWlzLXN0eWxlZ3VpZGUvcHJvamVjdHMvb3BlbmVtaXMtc3R5bGVndWlkZS1saWIvc3JjLyIsInNvdXJjZXMiOlsia2QtY29tcG9uZW50cy9rZC1hbmd1bGFyLWxvZ2luL2Zvcm0va2QtbG9naW5mb3JtLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBLE9BQU8sRUFDSCxTQUFTLEVBQ1QsS0FBSyxFQUNMLE1BQU0sRUFDTixZQUFZLEVBRVosWUFBWSxFQUVmLE1BQU0sZUFBZSxDQUFDO0FBR3ZCLE9BQU8sRUFBRSx5QkFBeUIsRUFBRSxNQUFNLHNDQUFzQyxDQUFDO0FBQ2pGLE9BQU8sRUFBRSxVQUFVLEVBQUUsTUFBTSx5QkFBeUIsQ0FBQztBQVVyRCxNQUFNLE9BQU8sV0FBVztJQWFwQixZQUNZLFNBQXFCLEVBQ3JCLGFBQXdDO1FBRHhDLGNBQVMsR0FBVCxTQUFTLENBQVk7UUFDckIsa0JBQWEsR0FBYixhQUFhLENBQTJCO1FBVjNDLGVBQVUsR0FBMkIsRUFBRSxDQUFDO1FBS3ZDLGlCQUFZLEdBQXNCLElBQUksWUFBWSxFQUFFLENBQUM7UUFDckQscUJBQWdCLEdBQXNCLElBQUksWUFBWSxFQUFFLENBQUM7SUFLL0QsQ0FBQztJQUdMLE9BQU8sQ0FBQyxTQUF3QjtRQUM1QixJQUFJLFNBQVMsQ0FBQyxHQUFHLEtBQUssT0FBTyxFQUFFO1lBQzNCLElBQUksQ0FBQyxZQUFZLEVBQUUsQ0FBQztTQUN2QjtJQUNMLENBQUM7SUFFRCxRQUFRO1FBQ0osSUFBSSxDQUFDLFVBQVUsR0FBRyxJQUFJLENBQUMsYUFBYSxDQUFDLFlBQVksQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLENBQUM7UUFDakUsSUFBSSxDQUFDLElBQUksR0FBRyxJQUFJLENBQUMsYUFBYSxDQUFDLFdBQVcsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLENBQUM7UUFDNUQsMkNBQTJDO1FBQzNDLHVEQUF1RDtRQUN2RCxJQUFJLENBQUMsYUFBYSxHQUFHLElBQUksQ0FBQyxjQUFjLENBQUM7SUFDN0MsQ0FBQztJQUVNLFlBQVk7UUFDZixJQUFJLFFBQVEsR0FBUTtZQUNoQixVQUFVLEVBQUUsSUFBSSxDQUFDLFVBQVU7WUFDM0IsVUFBVSxFQUFFLElBQUksQ0FBQyxJQUFJLENBQUMsS0FBSztTQUM5QixDQUFBO1FBQ0QsSUFBSSxDQUFDLFlBQVksQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLENBQUM7SUFDckMsQ0FBQztJQUVNLHFCQUFxQjtRQUN4QixtREFBbUQ7UUFDbkQsSUFBSSxDQUFDLGdCQUFnQixDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsYUFBYSxDQUFDLENBQUM7SUFFbkQsQ0FBQzs7O1lBckRKLFNBQVMsU0FBQztnQkFDUCxRQUFRLEVBQUUsY0FBYztnQkFDeEIsdXhDQUFrQztnQkFDbEMsU0FBUyxFQUFFO29CQUNQLHlCQUF5QjtpQkFBQztnQkFDOUIsSUFBSSxFQUFFLEVBQUUsT0FBTyxFQUFFLFdBQVcsRUFBRTthQUNqQzs7O1lBUlEsVUFBVTtZQURWLHlCQUF5Qjs7O3VCQWU3QixLQUFLO3lCQUNMLEtBQUs7cUJBRUwsS0FBSzswQkFDTCxLQUFLOzZCQUNMLEtBQUs7MkJBQ0wsTUFBTTsrQkFDTixNQUFNO3NCQU9OLFlBQVksU0FBQyxnQkFBZ0IsRUFBRSxDQUFDLFFBQVEsQ0FBQyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7XHJcbiAgICBDb21wb25lbnQsXHJcbiAgICBJbnB1dCxcclxuICAgIE91dHB1dCxcclxuICAgIEV2ZW50RW1pdHRlcixcclxuICAgIEhvc3RCaW5kaW5nLFxyXG4gICAgSG9zdExpc3RlbmVyLFxyXG4gICAgT25Jbml0XHJcbn0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XHJcbmltcG9ydCB7IEZvcm1Hcm91cCB9IGZyb20gJ0Bhbmd1bGFyL2Zvcm1zJztcclxuaW1wb3J0IHsgS2RMb2dpbkZvcm1CYXNlIH0gZnJvbSAnLi4vZm9ybS9rZC1sb2dpbmZvcm0tYmFzZSc7XHJcbmltcG9ydCB7IEtkTG9naW5Gb3JtQ29udHJvbFNlcnZpY2UgfSBmcm9tICcuLi9mb3JtL2tkLWxvZ2luZm9ybS1jb250cm9sLnNlcnZpY2UnO1xyXG5pbXBvcnQgeyBLZExvZ2luU3ZjIH0gZnJvbSAnLi4va2QtYW5ndWxhci1sb2dpbi1zdmMnO1xyXG5cclxuQENvbXBvbmVudCh7XHJcbiAgICBzZWxlY3RvcjogJ2tkLWxvZ2luZm9ybScsXHJcbiAgICB0ZW1wbGF0ZVVybDogJy4va2QtbG9naW5mb3JtLmh0bWwnLFxyXG4gICAgcHJvdmlkZXJzOiBbXHJcbiAgICAgICAgS2RMb2dpbkZvcm1Db250cm9sU2VydmljZV0sXHJcbiAgICBob3N0OiB7ICdjbGFzcyc6ICdrZHgtbG9naW4nIH1cclxufSlcclxuXHJcbmV4cG9ydCBjbGFzcyBLZExvZ2luRm9ybSBpbXBsZW1lbnRzIE9uSW5pdCB7XHJcbiAgICBwdWJsaWMgZm9ybTogRm9ybUdyb3VwO1xyXG4gICAgcHVibGljIHNlbGVjdGVkSW5kZXg6IHN0cmluZztcclxuXHJcbiAgICBASW5wdXQoKSBmb3JtRGF0YTogQXJyYXk8YW55PjtcclxuICAgIEBJbnB1dCgpIGxvZ2luRm9ybXM6IEtkTG9naW5Gb3JtQmFzZTxhbnk+W10gPSBbXTtcclxuXHJcbiAgICBASW5wdXQoKSBjb25maWc6IGFueTtcclxuICAgIEBJbnB1dCgpIGJ1dHRvblRpdGxlOiBzdHJpbmc7XHJcbiAgICBASW5wdXQoKSBkZWZhdWx0TGFuZ1ZhbDogc3RyaW5nO1xyXG4gICAgQE91dHB1dCgpIG9uRm9ybVN1Ym1pdDogRXZlbnRFbWl0dGVyPGFueT4gPSBuZXcgRXZlbnRFbWl0dGVyKCk7XHJcbiAgICBAT3V0cHV0KCkgb25MYW5ndWFnZUNoYW5nZTogRXZlbnRFbWl0dGVyPGFueT4gPSBuZXcgRXZlbnRFbWl0dGVyKCk7XHJcblxyXG4gICAgY29uc3RydWN0b3IoXHJcbiAgICAgICAgcHJpdmF0ZSBfbG9naW5TdmM6IEtkTG9naW5TdmMsXHJcbiAgICAgICAgcHJpdmF0ZSBfbG9naW5Gb3JtU3ZjOiBLZExvZ2luRm9ybUNvbnRyb2xTZXJ2aWNlLFxyXG4gICAgKSB7IH1cclxuXHJcbiAgICBASG9zdExpc3RlbmVyKCdkb2N1bWVudDprZXl1cCcsIFsnJGV2ZW50J10pXHJcbiAgICBvbktleVVwKF9rZXlFdmVudDogS2V5Ym9hcmRFdmVudCkge1xyXG4gICAgICAgIGlmIChfa2V5RXZlbnQua2V5ID09PSAnRW50ZXInKSB7XHJcbiAgICAgICAgICAgIHRoaXMuYnV0dG9uU3VibWl0KCk7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIG5nT25Jbml0KCk6IHZvaWQge1xyXG4gICAgICAgIHRoaXMubG9naW5Gb3JtcyA9IHRoaXMuX2xvZ2luRm9ybVN2Yy5nZXRMb2dpbkZvcm0odGhpcy5mb3JtRGF0YSk7XHJcbiAgICAgICAgdGhpcy5mb3JtID0gdGhpcy5fbG9naW5Gb3JtU3ZjLnRvRm9ybUdyb3VwKHRoaXMubG9naW5Gb3Jtcyk7XHJcbiAgICAgICAgLy90aGlzLmRlZmF1bHRWYWwgPSB0aGlzLmZvcm1EYXRhWzJdLnZhbHVlO1xyXG4gICAgICAgIC8vY29uc29sZS5sb2coJ0RlZmF1bHQgdmFsdWU6ICcgKyB0aGlzLmRlZmF1bHRMYW5nVmFsKTtcclxuICAgICAgICB0aGlzLnNlbGVjdGVkSW5kZXggPSB0aGlzLmRlZmF1bHRMYW5nVmFsO1xyXG4gICAgfVxyXG5cclxuICAgIHB1YmxpYyBidXR0b25TdWJtaXQoKTogdm9pZCB7XHJcbiAgICAgICAgbGV0IHRlbXBEYXRhOiBhbnkgPSB7XHJcbiAgICAgICAgICAgIGZvcm1JbnB1dHM6IHRoaXMubG9naW5Gb3JtcyxcclxuICAgICAgICAgICAgZm9ybVZhbHVlczogdGhpcy5mb3JtLnZhbHVlXHJcbiAgICAgICAgfVxyXG4gICAgICAgIHRoaXMub25Gb3JtU3VibWl0LmVtaXQodGVtcERhdGEpO1xyXG4gICAgfVxyXG5cclxuICAgIHB1YmxpYyB1cGRhdGVEZWZhdWx0TGFuZ3VhZ2UoKTogdm9pZCB7XHJcbiAgICAgICAgLy9jb25zb2xlLmxvZygnRnJvbSBDaGlsZDogJyArIHRoaXMuc2VsZWN0ZWRJbmRleCk7XHJcbiAgICAgICAgdGhpcy5vbkxhbmd1YWdlQ2hhbmdlLmVtaXQodGhpcy5zZWxlY3RlZEluZGV4KTtcclxuXHJcbiAgICB9XHJcblxyXG5cclxuXHJcbn1cclxuIl19