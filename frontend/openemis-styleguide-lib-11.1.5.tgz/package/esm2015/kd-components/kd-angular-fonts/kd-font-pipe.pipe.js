import { Pipe } from '@angular/core';
export class FilterArrayPipe {
    transform(value, args) {
        if (typeof args === 'undefined' || args.length === 0) {
            return value;
        }
        else if (value) {
            // .text is comparing a string  that is inside an object
            return value.filter((item) => {
                return (item.text.indexOf(args) !== -1) ? true : false;
            });
        }
    }
}
FilterArrayPipe.decorators = [
    { type: Pipe, args: [{ name: 'filter' },] }
];
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoia2QtZm9udC1waXBlLnBpcGUuanMiLCJzb3VyY2VSb290IjoiQzoveGFtcHAvaHRkb2NzL1N0eWxlZ3VpZGUvaW9zdGctb3BlbmVtaXMtc3R5bGVndWlkZS9wcm9qZWN0cy9vcGVuZW1pcy1zdHlsZWd1aWRlLWxpYi9zcmMvIiwic291cmNlcyI6WyJrZC1jb21wb25lbnRzL2tkLWFuZ3VsYXItZm9udHMva2QtZm9udC1waXBlLnBpcGUudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsT0FBTyxFQUFFLElBQUksRUFBRSxNQUFNLGVBQWUsQ0FBQztBQUdyQyxNQUFNLE9BQU8sZUFBZTtJQUV4QixTQUFTLENBQUMsS0FBVSxFQUFFLElBQVM7UUFDM0IsSUFBSSxPQUFPLElBQUksS0FBSyxXQUFXLElBQUksSUFBSSxDQUFDLE1BQU0sS0FBSyxDQUFDLEVBQUU7WUFDbEQsT0FBTyxLQUFLLENBQUM7U0FDaEI7YUFBTSxJQUFJLEtBQUssRUFBRTtZQUNkLHdEQUF3RDtZQUN4RCxPQUFPLEtBQUssQ0FBQyxNQUFNLENBQUMsQ0FBQyxJQUFTLEVBQVcsRUFBRTtnQkFDdkMsT0FBTyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDO1lBQzNELENBQUMsQ0FBQyxDQUFDO1NBQ047SUFDTCxDQUFDOzs7WUFaSixJQUFJLFNBQUMsRUFBRSxJQUFJLEVBQUUsUUFBUSxFQUFFIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgUGlwZSB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xyXG5cclxuQFBpcGUoeyBuYW1lOiAnZmlsdGVyJyB9KVxyXG5leHBvcnQgY2xhc3MgRmlsdGVyQXJyYXlQaXBlIHtcclxuXHJcbiAgICB0cmFuc2Zvcm0odmFsdWU6IGFueSwgYXJnczogYW55KSB7XHJcbiAgICAgICAgaWYgKHR5cGVvZiBhcmdzID09PSAndW5kZWZpbmVkJyB8fCBhcmdzLmxlbmd0aCA9PT0gMCkge1xyXG4gICAgICAgICAgICByZXR1cm4gdmFsdWU7XHJcbiAgICAgICAgfSBlbHNlIGlmICh2YWx1ZSkge1xyXG4gICAgICAgICAgICAvLyAudGV4dCBpcyBjb21wYXJpbmcgYSBzdHJpbmcgIHRoYXQgaXMgaW5zaWRlIGFuIG9iamVjdFxyXG4gICAgICAgICAgICByZXR1cm4gdmFsdWUuZmlsdGVyKChpdGVtOiBhbnkpOiBib29sZWFuID0+IHtcclxuICAgICAgICAgICAgICAgIHJldHVybiAoaXRlbS50ZXh0LmluZGV4T2YoYXJncykgIT09IC0xKSA/IHRydWUgOiBmYWxzZTtcclxuICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG59XHJcbiJdfQ==