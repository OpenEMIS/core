import { Component, Input } from '@angular/core';
import { FONTAWESOME_FONTS } from './config/config.fa-fonts';
import { KD_FONTS } from './config/config.kd-fonts';
export class KdFonts {
    constructor() {
        this._fontList = [];
    }
    ngOnInit() {
        switch (this.fontType) {
            case 'fa':
                this._fontList = FONTAWESOME_FONTS;
                break;
            default:
                this._fontList = KD_FONTS;
                break;
        }
    }
}
KdFonts.decorators = [
    { type: Component, args: [{
                selector: 'kd-fonts',
                template: `
        <div class="font-containter default-font-size">
            <div *ngFor="let item of _fontList | filter: textFilter" class="col-md-3 col-sm-4" style="height:38px;" [hidden]="item.hidden">
                <i class="fa {{item.text}}"></i> {{item.text}}
            </div>
        </div>
    `
            },] }
];
KdFonts.propDecorators = {
    fontType: [{ type: Input }],
    textFilter: [{ type: Input }]
};
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoia2QtYW5ndWxhci1mb250cy5qcyIsInNvdXJjZVJvb3QiOiJDOi94YW1wcC9odGRvY3MvU3R5bGVndWlkZS9pb3N0Zy1vcGVuZW1pcy1zdHlsZWd1aWRlL3Byb2plY3RzL29wZW5lbWlzLXN0eWxlZ3VpZGUtbGliL3NyYy8iLCJzb3VyY2VzIjpbImtkLWNvbXBvbmVudHMva2QtYW5ndWxhci1mb250cy9rZC1hbmd1bGFyLWZvbnRzLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBLE9BQU8sRUFBRSxTQUFTLEVBQVUsS0FBSyxFQUFFLE1BQU0sZUFBZSxDQUFDO0FBQ3pELE9BQU8sRUFBRSxpQkFBaUIsRUFBRSxNQUFNLDBCQUEwQixDQUFDO0FBQzdELE9BQU8sRUFBRSxRQUFRLEVBQUUsTUFBTSwwQkFBMEIsQ0FBQztBQWFwRCxNQUFNLE9BQU8sT0FBTztJQVhwQjtRQVlXLGNBQVMsR0FBZSxFQUFFLENBQUM7SUFldEMsQ0FBQztJQVZHLFFBQVE7UUFDSixRQUFRLElBQUksQ0FBQyxRQUFRLEVBQUU7WUFDbkIsS0FBSyxJQUFJO2dCQUNMLElBQUksQ0FBQyxTQUFTLEdBQUcsaUJBQWlCLENBQUM7Z0JBQ25DLE1BQU07WUFDVjtnQkFDSSxJQUFJLENBQUMsU0FBUyxHQUFHLFFBQVEsQ0FBQztnQkFDMUIsTUFBTTtTQUNiO0lBQ0wsQ0FBQzs7O1lBMUJKLFNBQVMsU0FBRTtnQkFDUixRQUFRLEVBQUUsVUFBVTtnQkFDcEIsUUFBUSxFQUFFOzs7Ozs7S0FNVDthQUNKOzs7dUJBS0ksS0FBSzt5QkFDTCxLQUFLIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgQ29tcG9uZW50LCBPbkluaXQsIElucHV0IH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XHJcbmltcG9ydCB7IEZPTlRBV0VTT01FX0ZPTlRTIH0gZnJvbSAnLi9jb25maWcvY29uZmlnLmZhLWZvbnRzJztcclxuaW1wb3J0IHsgS0RfRk9OVFMgfSBmcm9tICcuL2NvbmZpZy9jb25maWcua2QtZm9udHMnO1xyXG5cclxuQENvbXBvbmVudCAoe1xyXG4gICAgc2VsZWN0b3I6ICdrZC1mb250cycsXHJcbiAgICB0ZW1wbGF0ZTogYFxyXG4gICAgICAgIDxkaXYgY2xhc3M9XCJmb250LWNvbnRhaW50ZXIgZGVmYXVsdC1mb250LXNpemVcIj5cclxuICAgICAgICAgICAgPGRpdiAqbmdGb3I9XCJsZXQgaXRlbSBvZiBfZm9udExpc3QgfCBmaWx0ZXI6IHRleHRGaWx0ZXJcIiBjbGFzcz1cImNvbC1tZC0zIGNvbC1zbS00XCIgc3R5bGU9XCJoZWlnaHQ6MzhweDtcIiBbaGlkZGVuXT1cIml0ZW0uaGlkZGVuXCI+XHJcbiAgICAgICAgICAgICAgICA8aSBjbGFzcz1cImZhIHt7aXRlbS50ZXh0fX1cIj48L2k+IHt7aXRlbS50ZXh0fX1cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICBgXHJcbn0pXHJcblxyXG5leHBvcnQgY2xhc3MgS2RGb250cyBpbXBsZW1lbnRzIE9uSW5pdCB7XHJcbiAgICBwdWJsaWMgX2ZvbnRMaXN0OiBBcnJheTxhbnk+ID0gW107XHJcblxyXG4gICAgQElucHV0KCkgZm9udFR5cGU6IHN0cmluZztcclxuICAgIEBJbnB1dCgpIHRleHRGaWx0ZXI6IHN0cmluZztcclxuXHJcbiAgICBuZ09uSW5pdCgpOiB2b2lkIHtcclxuICAgICAgICBzd2l0Y2ggKHRoaXMuZm9udFR5cGUpIHtcclxuICAgICAgICAgICAgY2FzZSAnZmEnOlxyXG4gICAgICAgICAgICAgICAgdGhpcy5fZm9udExpc3QgPSBGT05UQVdFU09NRV9GT05UUztcclxuICAgICAgICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgICAgICBkZWZhdWx0OlxyXG4gICAgICAgICAgICAgICAgdGhpcy5fZm9udExpc3QgPSBLRF9GT05UUztcclxuICAgICAgICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxufVxyXG4iXX0=