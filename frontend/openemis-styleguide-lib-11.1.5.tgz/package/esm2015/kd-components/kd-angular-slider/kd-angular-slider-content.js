import { timer as observableTimer } from 'rxjs';
import { Component, ViewEncapsulation, Input, ElementRef, EventEmitter, Output, ViewChild, Renderer2 } from '@angular/core';
import { KdDomElemSvc } from '../kd-common/index';
import { KdSliderSvc } from './kd-angular-slider-svc';
export class KdSliderContent {
    constructor(_elementRef, _kdDomElemSvc, _renderer, _sliderSvc) {
        this._elementRef = _elementRef;
        this._renderer = _renderer;
        this._sliderSvc = _sliderSvc;
        this.selectedThumbIndex = 0;
        this.isMobile = false;
        this.config = {};
        this.noValue = false;
        this.tooltipApi = [{}, {}];
        this.tooltipLabel = [0];
        this.tooltipPlacement = 'top';
        this._tooltipAppeared = [false];
        this._isHovered = false;
        /** The percentage of the slider that coincides with the value. */
        this._percent = 0;
        this._percents = [0, 0.1];
        this._direction = 'ltr';
        /** The dimensions of the slider. */
        this._sliderDimensions = null;
        this._isFirstLoad = true;
        /**
        *  Whether or not the slider is clicked.
        *  Used to determine if there should be a show of tooltip via transitionend listener.
        */
        this._isClick = false;
        this.childValue = 0;
        this.isPlay = false;
        this.result = new EventEmitter();
        this.endPlay = new EventEmitter();
        this._direction = _kdDomElemSvc.getDocumentDirection(true) === 'left' ? 'ltr' : 'rtl';
        this._sliderSvc.direction = this._direction;
        this.isMobile = _kdDomElemSvc.isMobileDevice();
    }
    ngOnInit() {
        if (typeof this.childValue === 'undefined') {
            this.noValue = true;
            return;
        }
        this._setConfig(this.childConfig);
        this.value = this._setData(this.childValue);
        this._setFirstLoadPositionAndTooltip(this.childValue);
        this._initApi();
        this._isFirstLoad = false;
    }
    ngOnChanges(_simpleChanges) {
        if (_simpleChanges.hasOwnProperty('isPlay') && !this._isFirstLoad) {
            if (this.isPlay) {
                this._clickPlayBtn();
            }
            else {
                this._clickPauseBtn();
            }
        }
        if (_simpleChanges.hasOwnProperty('childValue') && !this._isFirstLoad) {
            if (_simpleChanges['childValue'].currentValue === this.value)
                return;
            this.value = this._setData(_simpleChanges['childValue'].currentValue);
            if (this.noValue) {
                this._setFirstLoadPositionAndTooltip(_simpleChanges['childValue'].currentValue);
                this.noValue = false;
            }
        }
        if (_simpleChanges.hasOwnProperty('childConfig') && !this._isFirstLoad) {
            if (_simpleChanges['childConfig'].currentValue === this.config)
                return;
            this._setConfig(_simpleChanges['childConfig'].currentValue);
        }
    }
    ngAfterViewInit() {
        if (this.noValue)
            return;
        let iterations = this.config.range ? 2 : 1;
        for (let i = 0; i < iterations; ++i) {
            this.tooltipApi[i].deactivateHostListener();
        }
        this._attachThumbTransitionListener();
        if (this.isMobile) {
            this._attachMobileWindowListener();
        }
        else {
            this._attachWindowListener();
        }
    }
    ngOnDestroy() {
        if (this.noValue)
            return;
        this._tooltipTransitionListener();
        if (this.config.range)
            this._tooltipTransitionListener1();
        if (this.isMobile) {
            this._windowTapListener();
        }
        else {
            this._windowScrollListener();
        }
        this._tooltipAppearControl('all hide');
    }
    _setConfig(_config) {
        this.config = Object.assign({}, _config);
        this._sliderSvc.config = _config;
        this._axis = _config.orientation === 'vertical' ? 'Y' : 'X';
        this._vertical = _config.orientation === 'vertical' ? true : false;
        this._isInvertAxis = this._sliderSvc.invertAxis();
        this._sliderSvc.calculateRoundLabelTo();
        this.tooltipPlacement = this._sliderSvc.setTooltipPlacement(_config.tooltipPlacement);
    }
    _setData(_value) {
        if (Array.isArray(_value))
            return _value.map((el) => { return el; });
        return _value;
    }
    _setFirstLoadPositionAndTooltip(_value) {
        if (Array.isArray(_value)) {
            this._percents = _value.map((el) => { return this._sliderSvc.calculatePercentage(el); });
            this.thumbContainerStyles = this._thumbContainerStyles(this._percents[0]);
            this.thumbContainerStyles1 = this._thumbContainerStyles(this._percents[1]);
            this._tooltipAppeared = [false, false];
            this.tooltipLabel = this._setTooltipLabel(_value);
        }
        else {
            this._percent = this._sliderSvc.calculatePercentage(_value);
            this.thumbContainerStyles = this._thumbContainerStyles(this._percent);
            this.tooltipLabel[0] = this._setTooltipLabel(_value);
        }
        this.trackFillStyles = this._trackFillStyles();
    }
    /***************************************************************************************/
    /* Event Listener
    /***************************************************************************************/
    onMouseEnter(event) {
        if (this.noValue)
            return;
        this._isHovered = true;
        this._tooltipAppearControl('all show');
        if (this.config.disabled) {
            return;
        }
        // We save the dimensions of the slider here so we can use them to update the spacing of the
        // ticks and determine where on the slider click and slide events happen.
        this._sliderDimensions = this._getSliderDimensions();
    }
    onMouseLeave(event) {
        if (this.noValue)
            return;
        if (!this.isMobile)
            this.onEnd('mouseleave');
        this._tooltipAppearControl('all hide');
        this._isHovered = false;
    }
    onClick(event) {
        if (this.noValue)
            return;
        this._onChoosePos({ x: event.clientX, y: event.clientY });
        event.stopPropagation();
    }
    onMouseDown(event, id) {
        if (this.noValue)
            return;
        if (!this.isMobile) {
            this.onStart({ x: event.clientX, y: event.clientY }, id);
        }
        event.preventDefault();
    }
    onMouseMove(event) {
        if (this.noValue)
            return;
        if (!this.isMobile) {
            this.onMove({ x: event.clientX, y: event.clientY });
        }
        event.preventDefault();
    }
    onMouseUp(event) {
        if (this.noValue)
            return;
        if (!this.isMobile)
            this.onEnd('mouseup');
        event.preventDefault();
    }
    onTouchStart(event, id) {
        if (this.noValue)
            return;
        this.onStart({ x: event.touches['0'].clientX, y: event.touches['0'].clientY }, id);
        event.preventDefault();
        event.stopPropagation();
    }
    onTouchMove(event) {
        if (this.noValue)
            return;
        this.onMove({ x: event.touches['0'].clientX, y: event.touches['0'].clientY });
        event.preventDefault();
        event.stopPropagation();
    }
    onTouchEnd(event) {
        if (this.noValue)
            return;
        this.onEnd('touchend');
        event.stopPropagation();
    }
    _attachMobileWindowListener() {
        this._windowTapListener = this._renderer.listen('document', 'touchstart', (event) => {
            this._tooltipAppearControl('all hide');
            this._isHovered = false;
        });
    }
    _attachWindowListener() {
        this._windowScrollListener = this._renderer.listen('window', 'mousewheel', (event) => {
            observableTimer(50).subscribe(() => {
                this._tooltipAppearControl('all hide');
                this._isHovered = false;
            });
        });
        this._windowScrollListener = this._renderer.listen('window', 'DOMMouseScroll', (event) => {
            observableTimer(50).subscribe(() => {
                this._tooltipAppearControl('all hide');
                this._isHovered = false;
            });
        });
    }
    _attachThumbTransitionListener() {
        let thumbContainerElements = this._elementRef.nativeElement.querySelectorAll('.kdx-slider .kdx-slider-content .kdx-slider-content-wrapper .kdx-slider-thumb-container');
        this._tooltipTransitionListener = this._renderer.listen(thumbContainerElements[0], 'transitionend', () => {
            if (this.isPlay && this.config.autoplay)
                this._updateAutoplayValue();
            if (!this.isPlay && this._isClick && !this._isSliding)
                this._tooltipOnThumbTransition();
        });
        if (this.config.range) {
            this._tooltipTransitionListener1 = this._renderer.listen(thumbContainerElements[1], 'transitionend', () => {
                if (!this.config.autoplay && this._isClick && !this._isSliding)
                    this._tooltipOnThumbTransition();
            });
        }
    }
    _tooltipOnThumbTransition() {
        this._tooltipAppearControl('show selected');
        this._isClick = false;
        if (!this._isHovered)
            setTimeout(() => this._tooltipAppearControl('hide selected'), 1000);
    }
    /***************************************************************************************/
    /* Listener Logic
    /***************************************************************************************/
    onStart(pos, id) {
        if (this.config.disabled || this._isSliding) {
            return;
        }
        // Simulate mouseenter in case this is a mobile device.
        this.onMouseEnter();
        this._isSliding = true;
        if (this.config.range) {
            this.selectedThumbIndex = id;
            this._valueOnSlideStart = this.value[this.selectedThumbIndex];
        }
        else {
            this._valueOnSlideStart = this.value;
        }
        this._handleValue(pos);
    }
    onMove(pos) {
        if (this.config.disabled || !this._isSliding) {
            return;
        }
        let oldValue = 0;
        if (this.config.range) {
            oldValue = this.value[this.selectedThumbIndex];
            this._handleValue(pos);
            if (oldValue !== this.value[this.selectedThumbIndex]) {
                this._emitChangeEvent('sliding');
                return;
            }
        }
        oldValue = this.value;
        this._handleValue(pos);
        // Native range elements always emit `input` events when the value changed while sliding.
        if (oldValue !== this.value) {
            this._emitChangeEvent('sliding');
        }
    }
    onEnd(_fromWhere) {
        if (!this._isSliding) {
            return;
        }
        if (_fromWhere === 'mouseleave') {
            this._isSliding = false;
        }
        else if (this.isMobile)
            this._isSliding = false;
        if (this.config.range) {
            if (this._valueOnSlideStart !== this.value[this.selectedThumbIndex])
                this._emitChangeEvent();
        }
        else {
            if (this._valueOnSlideStart !== this.value)
                this._emitChangeEvent();
        }
        this._valueOnSlideStart = null;
    }
    _onChoosePos(pos) {
        if (this.config.disabled) {
            return;
        }
        // Simulate mouseenter in case this is a mobile device.
        this.onMouseEnter();
        this._isClick = true;
        if (this._isClick && !this._isSliding) {
            this._tooltipAppearControl('hide selected');
        }
        this._isSliding = false;
        let oldValue = 0;
        if (this.config.range) {
            oldValue = this.value[this.selectedThumbIndex];
            this._handleValue(pos);
            if (oldValue !== this.value[this.selectedThumbIndex]) {
                this._emitChangeEvent();
                return;
            }
        }
        oldValue = this.value;
        this._handleValue(pos);
        /* Emit a change and input event if the value changed. */
        if (oldValue !== this.value) {
            this._emitChangeEvent();
        }
    }
    /***************************************************************************************/
    /* Autoplay
    /***************************************************************************************/
    _clickPlayBtn() {
        this.config.disabled = true;
        this._updateAutoplayValue();
    }
    _clickPauseBtn() {
        this.config.disabled = false;
    }
    _updateAutoplayValue() {
        this._tooltipAppearControl('show selected');
        setTimeout(() => {
            this._tooltipAppearControl('hide selected');
            if (!this.isPlay)
                return;
            this.value = this.value + (this.config.autoplayStep || 1);
            if (this.value > this.config.max) {
                this.value = this.config.min;
                this.endPlay.emit(true);
                this.tooltipApi[0].hideTooltip();
                this.config.disabled = false;
            }
            this._percent = this._sliderSvc.calculatePercentage(this.value);
            this._handlePosition();
            this._emitChangeEvent();
        }, this.config.autoplayDelay || 500);
    }
    /***************************************************************************************/
    /* Event Emit
    /***************************************************************************************/
    /** Emits a change event if the current value is different from the last emitted value. */
    _emitChangeEvent(_currentAction) {
        this.result.emit({
            value: this.value,
            currentAction: _currentAction
        });
    }
    /***************************************************************************************/
    /* CSS Styles
    /***************************************************************************************/
    _trackFillStyles() {
        if (this.config.range) {
            let invertOffset = (this._direction === 'rtl' && !this._vertical) ? !this._sliderSvc.invertAxis() : this._sliderSvc.invertAxis();
            let sign = invertOffset ? '-' : '';
            let firstThumbPosition = invertOffset ? this._calculateOffset(this._percents[0]) : 100 - this._calculateOffset(this._percents[0]);
            let scalePercent = this._percents[1] - this._percents[0];
            return {
                'transform': `translate${this._axis}(${sign}${firstThumbPosition}%) scale${this._axis}(${scalePercent})`
            };
        }
        return {
            'transform': `scale${this._axis}(${this._percent})`
        };
    }
    _thumbContainerStyles(_percent) {
        let offset = this._calculateOffset(_percent);
        return {
            'transform': `translate${this._axis}(-${offset}%)`
        };
    }
    _calculateOffset(_percent) {
        // For a horizontal slider in RTL languages we push the thumb container off the left edge
        // instead of the right edge to avoid causing a horizontal scrollbar to appear.
        let invertOffset = (this._direction === 'rtl' && !this._vertical) ? !this._sliderSvc.invertAxis() : this._sliderSvc.invertAxis();
        return (invertOffset ? _percent : 1 - _percent) * 100;
    }
    /***************************************************************************************/
    /* Setting Values
    /***************************************************************************************/
    _handleValue(_pos, _value) {
        let newValue = typeof _value !== 'undefined' ? _value : this._updateValueFromPosition(_pos);
        if (this.config.range) {
            this.value[this.selectedThumbIndex] = newValue;
            this._percents[this.selectedThumbIndex] = this._sliderSvc.calculatePercentage(newValue);
        }
        else {
            this.value = newValue;
            this._percent = this._sliderSvc.calculatePercentage(newValue);
        }
        this._handlePosition();
    }
    _updateValueFromPosition(_pos) {
        if (!this._sliderDimensions) {
            return;
        }
        let offset = this._vertical ? this._sliderDimensions.top : this._sliderDimensions.left;
        let size = this._vertical ? this._sliderDimensions.height : this._sliderDimensions.width;
        let posComponent = this._vertical ? _pos.y : _pos.x;
        // The exact value is calculated from the event and used to find the closest snap value.
        let percent = this._sliderSvc.clamp((posComponent - offset) / size);
        if (this._sliderSvc.invertMouseCoords()) {
            percent = 1 - percent;
        }
        let finalValue = this._sliderSvc.calculateValue(percent);
        if (this.config.range) {
            let otherValue = this.value[Math.abs(1 - this.selectedThumbIndex)];
            if (this._sliderSvc.checkValueConflict(finalValue, otherValue, this.selectedThumbIndex)) {
                finalValue = otherValue;
            }
        }
        return finalValue;
    }
    _handlePosition() {
        if (this.config.range) {
            if (this.selectedThumbIndex === 0) {
                this.thumbContainerStyles = this._thumbContainerStyles(this._percents[0]);
            }
            else {
                this.thumbContainerStyles1 = this._thumbContainerStyles(this._percents[1]);
            }
        }
        else {
            this.thumbContainerStyles = this._thumbContainerStyles(this._percent);
        }
        this.tooltipLabel[this.selectedThumbIndex] = this._setTooltipLabel(this.value);
        this.trackFillStyles = this._trackFillStyles();
        if (this._tooltipAppeared[this.selectedThumbIndex])
            this.tooltipApi[this.selectedThumbIndex].align();
    }
    /***************************************************************************************/
    /* Tooltip functions
    /***************************************************************************************/
    _setTooltipLabel(_value) {
        let text = '';
        if (this.config.range) {
            if (this._isFirstLoad) {
                return _value.map((num) => {
                    text = this._sliderSvc.calculateLabelValue(num);
                    return this._sliderSvc.getLabelFormatReplace(text, this.config.tooltipFormat);
                });
            }
            text = this._sliderSvc.calculateLabelValue(_value[this.selectedThumbIndex]);
        }
        else if (this.config.type === 'others') {
            text = this.config.options[_value].description || this.config.options[_value].value.toString();
        }
        else {
            text = this._sliderSvc.calculateLabelValue(_value);
        }
        return this._sliderSvc.getLabelFormatReplace(text, this.config.tooltipFormat);
    }
    /** Logic for tooltip showing and hiding */
    _tooltipAppearControl(_flag) {
        let iterations = this.config.range ? 2 : 1;
        switch (_flag) {
            case 'all show':
                for (let i = 0; i < iterations; ++i) {
                    if (!this._tooltipAppeared[i]) {
                        this.tooltipApi[i].showTooltip();
                        this._tooltipAppeared[i] = true;
                    }
                }
                break;
            case 'all hide':
                for (let i = 0; i < iterations; ++i) {
                    if (this._tooltipAppeared[i]) {
                        this.tooltipApi[i].hideTooltip();
                        this._tooltipAppeared[i] = false;
                    }
                }
                break;
            case 'show selected':
                if (!this._tooltipAppeared[this.selectedThumbIndex]) {
                    this.tooltipApi[this.selectedThumbIndex].showTooltip();
                    this._tooltipAppeared[this.selectedThumbIndex] = true;
                }
                break;
            case 'hide selected':
                if (this._tooltipAppeared[this.selectedThumbIndex]) {
                    this.tooltipApi[this.selectedThumbIndex].hideTooltip();
                    this._tooltipAppeared[this.selectedThumbIndex] = false;
                }
                break;
        }
    }
    /***************************************************************************************/
    /* Api
    /***************************************************************************************/
    _initApi() {
        if (typeof this.api !== 'undefined') {
            this.api.handleValue = (_value, index) => {
                if (typeof index !== 'undefined') {
                    this.selectedThumbIndex = index;
                    this.value[index] = _value;
                }
                else {
                    this.value = _value;
                }
                this._handleValue(null, _value);
                this._emitChangeEvent();
            };
        }
    }
    /***************************************************************************************/
    /* Helper functions for setting values
    /***************************************************************************************/
    /**
    * Get the bounding client rect of the slider track element.
    * The track is used rather than the native element to ignore the extra space that the thumb can
    * take up.
    */
    _getSliderDimensions() {
        return this._sliderWrapper ? this._sliderWrapper.nativeElement.getBoundingClientRect() : null;
    }
}
KdSliderContent.decorators = [
    { type: Component, args: [{
                selector: 'kd-slider-content',
                template: "<div class=\"kdx-slider-content-wrapper\" #sliderWrapper>\r\n  <div class=\"kdx-slider-track-wrapper\">\r\n    <div class=\"kdx-slider-track-background\"></div>\r\n    <div class=\"kdx-slider-track-fill\" [ngStyle]=\"trackFillStyles\"></div>\r\n  </div>\r\n  <div *ngIf=\"!noValue\" class=\"kdx-slider-thumb-container\" [ngStyle]=\"thumbContainerStyles\" id=\"0\">\r\n    <div class=\"kdx-thumb-buffer-container\" [ngClass]=\"{'kdx-selected-thumb': selectedThumbIndex === 0 && config.range}\"\r\n         (mousedown)=\"onMouseDown($event,0)\" (touchstart)=\"onTouchStart($event,0)\">\r\n      <div class=\"kdx-slider-thumb\" [kd-tooltip-dir]=\"tooltipLabel[0]\" [tooltipPosition]=\"tooltipPlacement\"\r\n         tooltipStyleClass=\"kdx-tooltip-default\" [escape]=\"false\" [api]=\"tooltipApi[0]\"\r\n         ></div>\r\n    </div>\r\n  </div>\r\n  <div *ngIf=\"config.range && !noValue\" class=\"kdx-slider-thumb-container\" [ngStyle]=\"thumbContainerStyles1\" id=\"1\" >\r\n    <div class=\"kdx-thumb-buffer-container\" [ngClass]=\"{'kdx-selected-thumb': selectedThumbIndex === 1 && config.range}\"\r\n         (mousedown)=\"onMouseDown($event,1)\" (touchstart)=\"onTouchStart($event,1)\">\r\n      <div class=\"kdx-slider-thumb\" [kd-tooltip-dir]=\"tooltipLabel[1]\" [tooltipPosition]=\"tooltipPlacement\"\r\n         tooltipStyleClass=\"kdx-tooltip-default\" [escape]=\"false\" [api]=\"tooltipApi[1]\"\r\n         ></div>\r\n    </div>\r\n  </div>\r\n</div>",
                encapsulation: ViewEncapsulation.None,
                providers: [KdDomElemSvc, KdSliderSvc],
                host: {
                    '(mouseenter)': 'onMouseEnter($event)',
                    '(mouseleave)': 'onMouseLeave($event)',
                    '(click)': 'onClick($event)',
                    '(mousemove)': 'onMouseMove($event)',
                    '(mouseup)': 'onMouseUp($event)',
                    '(touchmove)': 'onTouchMove($event)',
                    '(touchend)': 'onTouchEnd($event)',
                    'class': 'kdx-slider-content',
                    'role': 'slider',
                    '[attr.aria-disabled]': 'config.disabled',
                    '[attr.aria-valuemax]': 'config.max',
                    '[attr.aria-valuemin]': 'config.min',
                    '[attr.aria-valuenow]': 'value',
                    '[attr.aria-orientation]': '_vertical ? "vertical" : "horizontal"',
                    '[class.kdx-slider-disabled]': 'config.disabled',
                    '[class.kdx-slider-horizontal]': '!_vertical',
                    '[class.kdx-slider-axis-inverted]': '_isInvertAxis',
                    '[class.kdx-slider-sliding]': '_isSliding',
                    '[class.kdx-slider-vertical]': '_vertical',
                    '[class.kdx-slider-hovered]': '_isHovered',
                    '[class.kdx-slider-has-autoplay]': 'config.autoplay',
                    '[class.kdx-slider-has-range]': 'config.range',
                    '[class.kdx-slider-is-mobile]': 'isMobile',
                    '[class.kdx-slider-has-value]': '!noValue',
                }
            },] }
];
KdSliderContent.ctorParameters = () => [
    { type: ElementRef },
    { type: KdDomElemSvc },
    { type: Renderer2 },
    { type: KdSliderSvc }
];
KdSliderContent.propDecorators = {
    childValue: [{ type: Input, args: ['value',] }],
    childConfig: [{ type: Input, args: ['config',] }],
    isPlay: [{ type: Input }],
    api: [{ type: Input }],
    result: [{ type: Output }],
    endPlay: [{ type: Output }],
    _sliderWrapper: [{ type: ViewChild, args: ['sliderWrapper', { static: true },] }]
};
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoia2QtYW5ndWxhci1zbGlkZXItY29udGVudC5qcyIsInNvdXJjZVJvb3QiOiJDOi94YW1wcC9odGRvY3MvU3R5bGVndWlkZS9pb3N0Zy1vcGVuZW1pcy1zdHlsZWd1aWRlL3Byb2plY3RzL29wZW5lbWlzLXN0eWxlZ3VpZGUtbGliL3NyYy8iLCJzb3VyY2VzIjpbImtkLWNvbXBvbmVudHMva2QtYW5ndWxhci1zbGlkZXIva2QtYW5ndWxhci1zbGlkZXItY29udGVudC50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFDQSxPQUFPLEVBQUUsS0FBSyxJQUFJLGVBQWUsRUFBYyxNQUFNLE1BQU0sQ0FBQztBQUc1RCxPQUFPLEVBQ0gsU0FBUyxFQUNULGlCQUFpQixFQUNqQixLQUFLLEVBS0wsVUFBVSxFQUVWLFlBQVksRUFDWixNQUFNLEVBQ04sU0FBUyxFQUNULFNBQVMsRUFDWixNQUFNLGVBQWUsQ0FBQztBQUN2QixPQUFPLEVBQUUsWUFBWSxFQUFFLE1BQU0sb0JBQW9CLENBQUM7QUFHbEQsT0FBTyxFQUFFLFdBQVcsRUFBRSxNQUFNLHlCQUF5QixDQUFDO0FBbUN0RCxNQUFNLE9BQU8sZUFBZTtJQXlEeEIsWUFDWSxXQUF1QixFQUMvQixhQUEyQixFQUNuQixTQUFvQixFQUNwQixVQUF1QjtRQUh2QixnQkFBVyxHQUFYLFdBQVcsQ0FBWTtRQUV2QixjQUFTLEdBQVQsU0FBUyxDQUFXO1FBQ3BCLGVBQVUsR0FBVixVQUFVLENBQWE7UUF4RDVCLHVCQUFrQixHQUFXLENBQUMsQ0FBQztRQUMvQixhQUFRLEdBQVksS0FBSyxDQUFDO1FBQzFCLFdBQU0sR0FBa0IsRUFBRSxDQUFDO1FBRTNCLFlBQU8sR0FBWSxLQUFLLENBQUM7UUFFekIsZUFBVSxHQUF1QixDQUFDLEVBQUUsRUFBRSxFQUFFLENBQUMsQ0FBQztRQUMxQyxpQkFBWSxHQUFRLENBQUMsQ0FBQyxDQUFDLENBQUM7UUFDeEIscUJBQWdCLEdBQVcsS0FBSyxDQUFDO1FBQ2hDLHFCQUFnQixHQUFtQixDQUFDLEtBQUssQ0FBQyxDQUFDO1FBUzVDLGVBQVUsR0FBWSxLQUFLLENBQUM7UUFPbkMsa0VBQWtFO1FBQzFELGFBQVEsR0FBVyxDQUFDLENBQUM7UUFDckIsY0FBUyxHQUFrQixDQUFDLENBQUMsRUFBRSxHQUFHLENBQUMsQ0FBQztRQUNwQyxlQUFVLEdBQVcsS0FBSyxDQUFDO1FBRW5DLG9DQUFvQztRQUM1QixzQkFBaUIsR0FBc0IsSUFBSSxDQUFDO1FBRzVDLGlCQUFZLEdBQVksSUFBSSxDQUFDO1FBRXJDOzs7VUFHRTtRQUNNLGFBQVEsR0FBWSxLQUFLLENBQUM7UUFFbEIsZUFBVSxHQUFRLENBQUMsQ0FBQztRQUUzQixXQUFNLEdBQVksS0FBSyxDQUFDO1FBRXZCLFdBQU0sR0FBcUIsSUFBSSxZQUFZLEVBQUUsQ0FBQztRQUM5QyxZQUFPLEdBQXFCLElBQUksWUFBWSxFQUFFLENBQUM7UUFXckQsSUFBSSxDQUFDLFVBQVUsR0FBRyxhQUFhLENBQUMsb0JBQW9CLENBQUMsSUFBSSxDQUFDLEtBQUssTUFBTSxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQztRQUN0RixJQUFJLENBQUMsVUFBVSxDQUFDLFNBQVMsR0FBRyxJQUFJLENBQUMsVUFBVSxDQUFDO1FBQzVDLElBQUksQ0FBQyxRQUFRLEdBQUcsYUFBYSxDQUFDLGNBQWMsRUFBRSxDQUFDO0lBQ25ELENBQUM7SUFFRCxRQUFRO1FBQ0osSUFBSSxPQUFPLElBQUksQ0FBQyxVQUFVLEtBQUssV0FBVyxFQUFFO1lBQ3hDLElBQUksQ0FBQyxPQUFPLEdBQUcsSUFBSSxDQUFDO1lBQ3BCLE9BQU87U0FDVjtRQUNELElBQUksQ0FBQyxVQUFVLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxDQUFDO1FBQ2xDLElBQUksQ0FBQyxLQUFLLEdBQUcsSUFBSSxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLENBQUM7UUFDNUMsSUFBSSxDQUFDLCtCQUErQixDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsQ0FBQztRQUN0RCxJQUFJLENBQUMsUUFBUSxFQUFFLENBQUM7UUFDaEIsSUFBSSxDQUFDLFlBQVksR0FBRyxLQUFLLENBQUM7SUFDOUIsQ0FBQztJQUVELFdBQVcsQ0FBQyxjQUE2QjtRQUNyQyxJQUFJLGNBQWMsQ0FBQyxjQUFjLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsWUFBWSxFQUFFO1lBQy9ELElBQUksSUFBSSxDQUFDLE1BQU0sRUFBRTtnQkFDYixJQUFJLENBQUMsYUFBYSxFQUFFLENBQUM7YUFDeEI7aUJBQU07Z0JBQ0gsSUFBSSxDQUFDLGNBQWMsRUFBRSxDQUFDO2FBQ3pCO1NBQ0o7UUFFRCxJQUFJLGNBQWMsQ0FBQyxjQUFjLENBQUMsWUFBWSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsWUFBWSxFQUFFO1lBQ25FLElBQUksY0FBYyxDQUFDLFlBQVksQ0FBQyxDQUFDLFlBQVksS0FBSyxJQUFJLENBQUMsS0FBSztnQkFBRSxPQUFPO1lBQ3JFLElBQUksQ0FBQyxLQUFLLEdBQUcsSUFBSSxDQUFDLFFBQVEsQ0FBQyxjQUFjLENBQUMsWUFBWSxDQUFDLENBQUMsWUFBWSxDQUFDLENBQUM7WUFDdEUsSUFBSSxJQUFJLENBQUMsT0FBTyxFQUFFO2dCQUNkLElBQUksQ0FBQywrQkFBK0IsQ0FBQyxjQUFjLENBQUMsWUFBWSxDQUFDLENBQUMsWUFBWSxDQUFDLENBQUM7Z0JBQ2hGLElBQUksQ0FBQyxPQUFPLEdBQUcsS0FBSyxDQUFDO2FBQ3hCO1NBQ0o7UUFFRCxJQUFJLGNBQWMsQ0FBQyxjQUFjLENBQUMsYUFBYSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsWUFBWSxFQUFFO1lBQ3BFLElBQUksY0FBYyxDQUFDLGFBQWEsQ0FBQyxDQUFDLFlBQVksS0FBSyxJQUFJLENBQUMsTUFBTTtnQkFBRSxPQUFPO1lBQ3ZFLElBQUksQ0FBQyxVQUFVLENBQUMsY0FBYyxDQUFDLGFBQWEsQ0FBQyxDQUFDLFlBQVksQ0FBQyxDQUFDO1NBQy9EO0lBQ0wsQ0FBQztJQUVELGVBQWU7UUFDWCxJQUFJLElBQUksQ0FBQyxPQUFPO1lBQUUsT0FBTztRQUV6QixJQUFJLFVBQVUsR0FBVyxJQUFJLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7UUFDbkQsS0FBSyxJQUFJLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxHQUFHLFVBQVUsRUFBRSxFQUFFLENBQUMsRUFBRTtZQUNqQyxJQUFJLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQyxDQUFDLHNCQUFzQixFQUFFLENBQUM7U0FDL0M7UUFDRCxJQUFJLENBQUMsOEJBQThCLEVBQUUsQ0FBQztRQUN0QyxJQUFJLElBQUksQ0FBQyxRQUFRLEVBQUU7WUFDZixJQUFJLENBQUMsMkJBQTJCLEVBQUUsQ0FBQztTQUN0QzthQUFNO1lBQ0gsSUFBSSxDQUFDLHFCQUFxQixFQUFFLENBQUM7U0FDaEM7SUFDTCxDQUFDO0lBRUQsV0FBVztRQUNQLElBQUksSUFBSSxDQUFDLE9BQU87WUFBRSxPQUFPO1FBRXpCLElBQUksQ0FBQywwQkFBMEIsRUFBRSxDQUFDO1FBQ2xDLElBQUksSUFBSSxDQUFDLE1BQU0sQ0FBQyxLQUFLO1lBQUUsSUFBSSxDQUFDLDJCQUEyQixFQUFFLENBQUM7UUFFMUQsSUFBSSxJQUFJLENBQUMsUUFBUSxFQUFFO1lBQ2YsSUFBSSxDQUFDLGtCQUFrQixFQUFFLENBQUM7U0FDN0I7YUFBTTtZQUNILElBQUksQ0FBQyxxQkFBcUIsRUFBRSxDQUFDO1NBQ2hDO1FBQ0QsSUFBSSxDQUFDLHFCQUFxQixDQUFDLFVBQVUsQ0FBQyxDQUFDO0lBQzNDLENBQUM7SUFFTyxVQUFVLENBQUMsT0FBc0I7UUFDckMsSUFBSSxDQUFDLE1BQU0sR0FBRyxNQUFNLENBQUMsTUFBTSxDQUFDLEVBQUUsRUFBRSxPQUFPLENBQUMsQ0FBQztRQUN6QyxJQUFJLENBQUMsVUFBVSxDQUFDLE1BQU0sR0FBRyxPQUFPLENBQUM7UUFDakMsSUFBSSxDQUFDLEtBQUssR0FBRyxPQUFPLENBQUMsV0FBVyxLQUFLLFVBQVUsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUM7UUFDNUQsSUFBSSxDQUFDLFNBQVMsR0FBRyxPQUFPLENBQUMsV0FBVyxLQUFLLFVBQVUsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUM7UUFDbkUsSUFBSSxDQUFDLGFBQWEsR0FBRyxJQUFJLENBQUMsVUFBVSxDQUFDLFVBQVUsRUFBRSxDQUFDO1FBQ2xELElBQUksQ0FBQyxVQUFVLENBQUMscUJBQXFCLEVBQUUsQ0FBQztRQUN4QyxJQUFJLENBQUMsZ0JBQWdCLEdBQUcsSUFBSSxDQUFDLFVBQVUsQ0FBQyxtQkFBbUIsQ0FBQyxPQUFPLENBQUMsZ0JBQWdCLENBQUMsQ0FBQztJQUMxRixDQUFDO0lBRU8sUUFBUSxDQUFDLE1BQVc7UUFDeEIsSUFBSSxLQUFLLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQztZQUFFLE9BQU8sTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDLEVBQUUsRUFBRSxFQUFFLEdBQUcsT0FBTyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztRQUNyRSxPQUFPLE1BQU0sQ0FBQztJQUNsQixDQUFDO0lBRU8sK0JBQStCLENBQUMsTUFBTTtRQUMxQyxJQUFJLEtBQUssQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLEVBQUU7WUFDdkIsSUFBSSxDQUFDLFNBQVMsR0FBRyxNQUFNLENBQUMsR0FBRyxDQUFDLENBQUMsRUFBRSxFQUFFLEVBQUUsR0FBRyxPQUFPLElBQUksQ0FBQyxVQUFVLENBQUMsbUJBQW1CLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztZQUN6RixJQUFJLENBQUMsb0JBQW9CLEdBQUcsSUFBSSxDQUFDLHFCQUFxQixDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztZQUMxRSxJQUFJLENBQUMscUJBQXFCLEdBQUcsSUFBSSxDQUFDLHFCQUFxQixDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztZQUMzRSxJQUFJLENBQUMsZ0JBQWdCLEdBQUcsQ0FBQyxLQUFLLEVBQUUsS0FBSyxDQUFDLENBQUM7WUFDdkMsSUFBSSxDQUFDLFlBQVksR0FBRyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsTUFBTSxDQUFDLENBQUM7U0FDckQ7YUFBTTtZQUNILElBQUksQ0FBQyxRQUFRLEdBQUcsSUFBSSxDQUFDLFVBQVUsQ0FBQyxtQkFBbUIsQ0FBQyxNQUFNLENBQUMsQ0FBQztZQUM1RCxJQUFJLENBQUMsb0JBQW9CLEdBQUcsSUFBSSxDQUFDLHFCQUFxQixDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsQ0FBQztZQUN0RSxJQUFJLENBQUMsWUFBWSxDQUFDLENBQUMsQ0FBQyxHQUFHLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxNQUFNLENBQUMsQ0FBQztTQUN4RDtRQUNELElBQUksQ0FBQyxlQUFlLEdBQUcsSUFBSSxDQUFDLGdCQUFnQixFQUFFLENBQUM7SUFDbkQsQ0FBQztJQUdELHlGQUF5RjtJQUN6Rjs2RkFDeUY7SUFFekYsWUFBWSxDQUFDLEtBQVc7UUFDcEIsSUFBSSxJQUFJLENBQUMsT0FBTztZQUFFLE9BQU87UUFDekIsSUFBSSxDQUFDLFVBQVUsR0FBRyxJQUFJLENBQUM7UUFDdkIsSUFBSSxDQUFDLHFCQUFxQixDQUFDLFVBQVUsQ0FBQyxDQUFDO1FBQ3ZDLElBQUksSUFBSSxDQUFDLE1BQU0sQ0FBQyxRQUFRLEVBQUU7WUFDdEIsT0FBTztTQUNWO1FBQ0QsNEZBQTRGO1FBQzVGLHlFQUF5RTtRQUN6RSxJQUFJLENBQUMsaUJBQWlCLEdBQUcsSUFBSSxDQUFDLG9CQUFvQixFQUFFLENBQUM7SUFDekQsQ0FBQztJQUNELFlBQVksQ0FBQyxLQUFXO1FBQ3BCLElBQUksSUFBSSxDQUFDLE9BQU87WUFBRSxPQUFPO1FBQ3pCLElBQUksQ0FBQyxJQUFJLENBQUMsUUFBUTtZQUFFLElBQUksQ0FBQyxLQUFLLENBQUMsWUFBWSxDQUFDLENBQUM7UUFDN0MsSUFBSSxDQUFDLHFCQUFxQixDQUFDLFVBQVUsQ0FBQyxDQUFDO1FBQ3ZDLElBQUksQ0FBQyxVQUFVLEdBQUcsS0FBSyxDQUFDO0lBQzVCLENBQUM7SUFFRCxPQUFPLENBQUMsS0FBVTtRQUNkLElBQUksSUFBSSxDQUFDLE9BQU87WUFBRSxPQUFPO1FBQ3pCLElBQUksQ0FBQyxZQUFZLENBQUMsRUFBRSxDQUFDLEVBQUUsS0FBSyxDQUFDLE9BQU8sRUFBRSxDQUFDLEVBQUUsS0FBSyxDQUFDLE9BQU8sRUFBRSxDQUFDLENBQUM7UUFDMUQsS0FBSyxDQUFDLGVBQWUsRUFBRSxDQUFDO0lBQzVCLENBQUM7SUFFRCxXQUFXLENBQUMsS0FBVSxFQUFFLEVBQVU7UUFDOUIsSUFBSSxJQUFJLENBQUMsT0FBTztZQUFFLE9BQU87UUFDekIsSUFBSSxDQUFDLElBQUksQ0FBQyxRQUFRLEVBQUU7WUFDaEIsSUFBSSxDQUFDLE9BQU8sQ0FBQyxFQUFFLENBQUMsRUFBRSxLQUFLLENBQUMsT0FBTyxFQUFFLENBQUMsRUFBRSxLQUFLLENBQUMsT0FBTyxFQUFFLEVBQUUsRUFBRSxDQUFDLENBQUM7U0FDNUQ7UUFDRCxLQUFLLENBQUMsY0FBYyxFQUFFLENBQUM7SUFDM0IsQ0FBQztJQUNELFdBQVcsQ0FBQyxLQUFVO1FBQ2xCLElBQUksSUFBSSxDQUFDLE9BQU87WUFBRSxPQUFPO1FBQ3pCLElBQUksQ0FBQyxJQUFJLENBQUMsUUFBUSxFQUFFO1lBQ2hCLElBQUksQ0FBQyxNQUFNLENBQUMsRUFBRSxDQUFDLEVBQUUsS0FBSyxDQUFDLE9BQU8sRUFBRSxDQUFDLEVBQUUsS0FBSyxDQUFDLE9BQU8sRUFBRSxDQUFDLENBQUM7U0FDdkQ7UUFDRCxLQUFLLENBQUMsY0FBYyxFQUFFLENBQUM7SUFDM0IsQ0FBQztJQUNELFNBQVMsQ0FBQyxLQUFVO1FBQ2hCLElBQUksSUFBSSxDQUFDLE9BQU87WUFBRSxPQUFPO1FBQ3pCLElBQUksQ0FBQyxJQUFJLENBQUMsUUFBUTtZQUFFLElBQUksQ0FBQyxLQUFLLENBQUMsU0FBUyxDQUFDLENBQUM7UUFDMUMsS0FBSyxDQUFDLGNBQWMsRUFBRSxDQUFDO0lBQzNCLENBQUM7SUFFRCxZQUFZLENBQUMsS0FBVSxFQUFFLEVBQUU7UUFDdkIsSUFBSSxJQUFJLENBQUMsT0FBTztZQUFFLE9BQU87UUFDekIsSUFBSSxDQUFDLE9BQU8sQ0FBQyxFQUFFLENBQUMsRUFBRSxLQUFLLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxDQUFDLE9BQU8sRUFBRSxDQUFDLEVBQUUsS0FBSyxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsQ0FBQyxPQUFPLEVBQUUsRUFBRSxFQUFFLENBQUMsQ0FBQztRQUNuRixLQUFLLENBQUMsY0FBYyxFQUFFLENBQUM7UUFDdkIsS0FBSyxDQUFDLGVBQWUsRUFBRSxDQUFDO0lBRTVCLENBQUM7SUFDRCxXQUFXLENBQUMsS0FBVTtRQUNsQixJQUFJLElBQUksQ0FBQyxPQUFPO1lBQUUsT0FBTztRQUN6QixJQUFJLENBQUMsTUFBTSxDQUFDLEVBQUUsQ0FBQyxFQUFFLEtBQUssQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLENBQUMsT0FBTyxFQUFFLENBQUMsRUFBRSxLQUFLLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxDQUFDLE9BQU8sRUFBRSxDQUFDLENBQUM7UUFDOUUsS0FBSyxDQUFDLGNBQWMsRUFBRSxDQUFDO1FBQ3ZCLEtBQUssQ0FBQyxlQUFlLEVBQUUsQ0FBQztJQUM1QixDQUFDO0lBQ0QsVUFBVSxDQUFDLEtBQVU7UUFDakIsSUFBSSxJQUFJLENBQUMsT0FBTztZQUFFLE9BQU87UUFDekIsSUFBSSxDQUFDLEtBQUssQ0FBQyxVQUFVLENBQUMsQ0FBQztRQUN2QixLQUFLLENBQUMsZUFBZSxFQUFFLENBQUM7SUFDNUIsQ0FBQztJQUVPLDJCQUEyQjtRQUMvQixJQUFJLENBQUMsa0JBQWtCLEdBQUcsSUFBSSxDQUFDLFNBQVMsQ0FBQyxNQUFNLENBQUMsVUFBVSxFQUFFLFlBQVksRUFBRSxDQUFDLEtBQUssRUFBRSxFQUFFO1lBQ2hGLElBQUksQ0FBQyxxQkFBcUIsQ0FBQyxVQUFVLENBQUMsQ0FBQztZQUN2QyxJQUFJLENBQUMsVUFBVSxHQUFHLEtBQUssQ0FBQztRQUM1QixDQUFDLENBQUMsQ0FBQztJQUNQLENBQUM7SUFFTyxxQkFBcUI7UUFDekIsSUFBSSxDQUFDLHFCQUFxQixHQUFHLElBQUksQ0FBQyxTQUFTLENBQUMsTUFBTSxDQUFDLFFBQVEsRUFBRSxZQUFZLEVBQUUsQ0FBQyxLQUFLLEVBQUUsRUFBRTtZQUNqRixlQUFlLENBQUMsRUFBRSxDQUFDLENBQUMsU0FBUyxDQUFDLEdBQUcsRUFBRTtnQkFDL0IsSUFBSSxDQUFDLHFCQUFxQixDQUFDLFVBQVUsQ0FBQyxDQUFDO2dCQUN2QyxJQUFJLENBQUMsVUFBVSxHQUFHLEtBQUssQ0FBQztZQUM1QixDQUFDLENBQUMsQ0FBQztRQUNQLENBQUMsQ0FBQyxDQUFDO1FBQ0gsSUFBSSxDQUFDLHFCQUFxQixHQUFHLElBQUksQ0FBQyxTQUFTLENBQUMsTUFBTSxDQUFDLFFBQVEsRUFBRSxnQkFBZ0IsRUFBRSxDQUFDLEtBQUssRUFBRSxFQUFFO1lBQ3JGLGVBQWUsQ0FBQyxFQUFFLENBQUMsQ0FBQyxTQUFTLENBQUMsR0FBRyxFQUFFO2dCQUMvQixJQUFJLENBQUMscUJBQXFCLENBQUMsVUFBVSxDQUFDLENBQUM7Z0JBQ3ZDLElBQUksQ0FBQyxVQUFVLEdBQUcsS0FBSyxDQUFDO1lBQzVCLENBQUMsQ0FBQyxDQUFDO1FBQ1AsQ0FBQyxDQUFDLENBQUM7SUFDUCxDQUFDO0lBRU8sOEJBQThCO1FBQ2xDLElBQUksc0JBQXNCLEdBQUcsSUFBSSxDQUFDLFdBQVcsQ0FBQyxhQUFhLENBQUMsZ0JBQWdCLENBQUMseUZBQXlGLENBQUMsQ0FBQztRQUN4SyxJQUFJLENBQUMsMEJBQTBCLEdBQUcsSUFBSSxDQUFDLFNBQVMsQ0FBQyxNQUFNLENBQUMsc0JBQXNCLENBQUMsQ0FBQyxDQUFDLEVBQUUsZUFBZSxFQUFFLEdBQUcsRUFBRTtZQUNyRyxJQUFJLElBQUksQ0FBQyxNQUFNLElBQUksSUFBSSxDQUFDLE1BQU0sQ0FBQyxRQUFRO2dCQUFFLElBQUksQ0FBQyxvQkFBb0IsRUFBRSxDQUFDO1lBRXJFLElBQUksQ0FBQyxJQUFJLENBQUMsTUFBTSxJQUFJLElBQUksQ0FBQyxRQUFRLElBQUksQ0FBQyxJQUFJLENBQUMsVUFBVTtnQkFBRSxJQUFJLENBQUMseUJBQXlCLEVBQUUsQ0FBQztRQUM1RixDQUFDLENBQUMsQ0FBQztRQUNILElBQUksSUFBSSxDQUFDLE1BQU0sQ0FBQyxLQUFLLEVBQUU7WUFDbkIsSUFBSSxDQUFDLDJCQUEyQixHQUFHLElBQUksQ0FBQyxTQUFTLENBQUMsTUFBTSxDQUFDLHNCQUFzQixDQUFDLENBQUMsQ0FBQyxFQUFFLGVBQWUsRUFBRSxHQUFHLEVBQUU7Z0JBQ3RHLElBQUksQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLFFBQVEsSUFBSSxJQUFJLENBQUMsUUFBUSxJQUFJLENBQUMsSUFBSSxDQUFDLFVBQVU7b0JBQUUsSUFBSSxDQUFDLHlCQUF5QixFQUFFLENBQUM7WUFDckcsQ0FBQyxDQUFDLENBQUM7U0FDTjtJQUNMLENBQUM7SUFFTyx5QkFBeUI7UUFDN0IsSUFBSSxDQUFDLHFCQUFxQixDQUFDLGVBQWUsQ0FBQyxDQUFDO1FBQzVDLElBQUksQ0FBQyxRQUFRLEdBQUcsS0FBSyxDQUFDO1FBQ3RCLElBQUksQ0FBQyxJQUFJLENBQUMsVUFBVTtZQUFFLFVBQVUsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxJQUFJLENBQUMscUJBQXFCLENBQUMsZUFBZSxDQUFDLEVBQUUsSUFBSSxDQUFDLENBQUM7SUFDOUYsQ0FBQztJQUVELHlGQUF5RjtJQUN6Rjs2RkFDeUY7SUFFakYsT0FBTyxDQUFDLEdBQTZCLEVBQUUsRUFBRTtRQUM3QyxJQUFJLElBQUksQ0FBQyxNQUFNLENBQUMsUUFBUSxJQUFJLElBQUksQ0FBQyxVQUFVLEVBQUU7WUFDekMsT0FBTztTQUNWO1FBQ0QsdURBQXVEO1FBQ3ZELElBQUksQ0FBQyxZQUFZLEVBQUUsQ0FBQztRQUVwQixJQUFJLENBQUMsVUFBVSxHQUFHLElBQUksQ0FBQztRQUN2QixJQUFJLElBQUksQ0FBQyxNQUFNLENBQUMsS0FBSyxFQUFFO1lBQ25CLElBQUksQ0FBQyxrQkFBa0IsR0FBRyxFQUFFLENBQUM7WUFDN0IsSUFBSSxDQUFDLGtCQUFrQixHQUFHLElBQUksQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLGtCQUFrQixDQUFDLENBQUM7U0FDakU7YUFBTTtZQUNILElBQUksQ0FBQyxrQkFBa0IsR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDO1NBQ3hDO1FBQ0QsSUFBSSxDQUFDLFlBQVksQ0FBQyxHQUFHLENBQUMsQ0FBQztJQUMzQixDQUFDO0lBRU8sTUFBTSxDQUFDLEdBQTZCO1FBQ3hDLElBQUksSUFBSSxDQUFDLE1BQU0sQ0FBQyxRQUFRLElBQUksQ0FBQyxJQUFJLENBQUMsVUFBVSxFQUFFO1lBQzFDLE9BQU87U0FDVjtRQUVELElBQUksUUFBUSxHQUFXLENBQUMsQ0FBQztRQUV6QixJQUFJLElBQUksQ0FBQyxNQUFNLENBQUMsS0FBSyxFQUFFO1lBQ25CLFFBQVEsR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxDQUFDO1lBQy9DLElBQUksQ0FBQyxZQUFZLENBQUMsR0FBRyxDQUFDLENBQUM7WUFFdkIsSUFBSSxRQUFRLEtBQUssSUFBSSxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsa0JBQWtCLENBQUMsRUFBRTtnQkFDbEQsSUFBSSxDQUFDLGdCQUFnQixDQUFDLFNBQVMsQ0FBQyxDQUFDO2dCQUNqQyxPQUFPO2FBQ1Y7U0FDSjtRQUVELFFBQVEsR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDO1FBQ3RCLElBQUksQ0FBQyxZQUFZLENBQUMsR0FBRyxDQUFDLENBQUM7UUFDdkIseUZBQXlGO1FBQ3pGLElBQUksUUFBUSxLQUFLLElBQUksQ0FBQyxLQUFLLEVBQUU7WUFDekIsSUFBSSxDQUFDLGdCQUFnQixDQUFDLFNBQVMsQ0FBQyxDQUFDO1NBQ3BDO0lBQ0wsQ0FBQztJQUVPLEtBQUssQ0FBQyxVQUFrQjtRQUM1QixJQUFJLENBQUMsSUFBSSxDQUFDLFVBQVUsRUFBRTtZQUNsQixPQUFPO1NBQ1Y7UUFFRCxJQUFJLFVBQVUsS0FBSyxZQUFZLEVBQUU7WUFDN0IsSUFBSSxDQUFDLFVBQVUsR0FBRyxLQUFLLENBQUM7U0FDM0I7YUFBTSxJQUFJLElBQUksQ0FBQyxRQUFRO1lBQUUsSUFBSSxDQUFDLFVBQVUsR0FBRyxLQUFLLENBQUM7UUFFbEQsSUFBSSxJQUFJLENBQUMsTUFBTSxDQUFDLEtBQUssRUFBRTtZQUNuQixJQUFJLElBQUksQ0FBQyxrQkFBa0IsS0FBSyxJQUFJLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxrQkFBa0IsQ0FBQztnQkFBRSxJQUFJLENBQUMsZ0JBQWdCLEVBQUUsQ0FBQztTQUNoRzthQUFNO1lBQ0gsSUFBSSxJQUFJLENBQUMsa0JBQWtCLEtBQUssSUFBSSxDQUFDLEtBQUs7Z0JBQUUsSUFBSSxDQUFDLGdCQUFnQixFQUFFLENBQUM7U0FDdkU7UUFFRCxJQUFJLENBQUMsa0JBQWtCLEdBQUcsSUFBSSxDQUFDO0lBQ25DLENBQUM7SUFFTyxZQUFZLENBQUMsR0FBNkI7UUFDOUMsSUFBSSxJQUFJLENBQUMsTUFBTSxDQUFDLFFBQVEsRUFBRTtZQUN0QixPQUFPO1NBQ1Y7UUFFRCx1REFBdUQ7UUFDdkQsSUFBSSxDQUFDLFlBQVksRUFBRSxDQUFDO1FBRXBCLElBQUksQ0FBQyxRQUFRLEdBQUcsSUFBSSxDQUFDO1FBRXJCLElBQUksSUFBSSxDQUFDLFFBQVEsSUFBSSxDQUFDLElBQUksQ0FBQyxVQUFVLEVBQUU7WUFDbkMsSUFBSSxDQUFDLHFCQUFxQixDQUFDLGVBQWUsQ0FBQyxDQUFDO1NBQy9DO1FBQ0QsSUFBSSxDQUFDLFVBQVUsR0FBRyxLQUFLLENBQUM7UUFFeEIsSUFBSSxRQUFRLEdBQVcsQ0FBQyxDQUFDO1FBRXpCLElBQUksSUFBSSxDQUFDLE1BQU0sQ0FBQyxLQUFLLEVBQUU7WUFDbkIsUUFBUSxHQUFHLElBQUksQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLGtCQUFrQixDQUFDLENBQUM7WUFDL0MsSUFBSSxDQUFDLFlBQVksQ0FBQyxHQUFHLENBQUMsQ0FBQztZQUN2QixJQUFJLFFBQVEsS0FBSyxJQUFJLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxFQUFFO2dCQUNsRCxJQUFJLENBQUMsZ0JBQWdCLEVBQUUsQ0FBQztnQkFDeEIsT0FBTzthQUNWO1NBQ0o7UUFFRCxRQUFRLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQztRQUN0QixJQUFJLENBQUMsWUFBWSxDQUFDLEdBQUcsQ0FBQyxDQUFDO1FBRXZCLHlEQUF5RDtRQUN6RCxJQUFJLFFBQVEsS0FBSyxJQUFJLENBQUMsS0FBSyxFQUFFO1lBQ3pCLElBQUksQ0FBQyxnQkFBZ0IsRUFBRSxDQUFDO1NBQzNCO0lBQ0wsQ0FBQztJQUVELHlGQUF5RjtJQUN6Rjs2RkFDeUY7SUFFakYsYUFBYTtRQUNqQixJQUFJLENBQUMsTUFBTSxDQUFDLFFBQVEsR0FBRyxJQUFJLENBQUM7UUFDNUIsSUFBSSxDQUFDLG9CQUFvQixFQUFFLENBQUM7SUFDaEMsQ0FBQztJQUVPLGNBQWM7UUFDbEIsSUFBSSxDQUFDLE1BQU0sQ0FBQyxRQUFRLEdBQUcsS0FBSyxDQUFDO0lBQ2pDLENBQUM7SUFFTyxvQkFBb0I7UUFDeEIsSUFBSSxDQUFDLHFCQUFxQixDQUFDLGVBQWUsQ0FBQyxDQUFDO1FBQzVDLFVBQVUsQ0FBQyxHQUFHLEVBQUU7WUFDWixJQUFJLENBQUMscUJBQXFCLENBQUMsZUFBZSxDQUFDLENBQUM7WUFDNUMsSUFBSSxDQUFDLElBQUksQ0FBQyxNQUFNO2dCQUFFLE9BQU87WUFFekIsSUFBSSxDQUFDLEtBQUssR0FBRyxJQUFJLENBQUMsS0FBSyxHQUFHLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxZQUFZLElBQUksQ0FBQyxDQUFDLENBQUM7WUFFMUQsSUFBSSxJQUFJLENBQUMsS0FBSyxHQUFHLElBQUksQ0FBQyxNQUFNLENBQUMsR0FBRyxFQUFFO2dCQUM5QixJQUFJLENBQUMsS0FBSyxHQUFHLElBQUksQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDO2dCQUM3QixJQUFJLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQztnQkFDeEIsSUFBSSxDQUFDLFVBQVUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxXQUFXLEVBQUUsQ0FBQztnQkFDakMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxRQUFRLEdBQUcsS0FBSyxDQUFDO2FBQ2hDO1lBRUQsSUFBSSxDQUFDLFFBQVEsR0FBRyxJQUFJLENBQUMsVUFBVSxDQUFDLG1CQUFtQixDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQztZQUNoRSxJQUFJLENBQUMsZUFBZSxFQUFFLENBQUM7WUFDdkIsSUFBSSxDQUFDLGdCQUFnQixFQUFFLENBQUM7UUFDNUIsQ0FBQyxFQUFFLElBQUksQ0FBQyxNQUFNLENBQUMsYUFBYSxJQUFJLEdBQUcsQ0FBQyxDQUFDO0lBQ3pDLENBQUM7SUFFRCx5RkFBeUY7SUFDekY7NkZBQ3lGO0lBRXpGLDBGQUEwRjtJQUNsRixnQkFBZ0IsQ0FBQyxjQUEwQjtRQUMvQyxJQUFJLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQztZQUNiLEtBQUssRUFBRSxJQUFJLENBQUMsS0FBSztZQUNqQixhQUFhLEVBQUUsY0FBYztTQUNoQyxDQUFDLENBQUM7SUFDUCxDQUFDO0lBRUQseUZBQXlGO0lBQ3pGOzZGQUN5RjtJQUVqRixnQkFBZ0I7UUFDcEIsSUFBSSxJQUFJLENBQUMsTUFBTSxDQUFDLEtBQUssRUFBRTtZQUNuQixJQUFJLFlBQVksR0FBWSxDQUFDLElBQUksQ0FBQyxVQUFVLEtBQUssS0FBSyxJQUFJLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsVUFBVSxFQUFFLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsVUFBVSxFQUFFLENBQUM7WUFDMUksSUFBSSxJQUFJLEdBQVcsWUFBWSxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQztZQUMzQyxJQUFJLGtCQUFrQixHQUFXLFlBQVksQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLGdCQUFnQixDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxHQUFHLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7WUFDMUksSUFBSSxZQUFZLEdBQVcsSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsR0FBRyxJQUFJLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDO1lBQ2pFLE9BQU87Z0JBQ0gsV0FBVyxFQUFFLFlBQVksSUFBSSxDQUFDLEtBQUssSUFBSSxJQUFJLEdBQUcsa0JBQWtCLFdBQVcsSUFBSSxDQUFDLEtBQUssSUFBSSxZQUFZLEdBQUc7YUFDM0csQ0FBQztTQUNMO1FBQ0QsT0FBTztZQUNILFdBQVcsRUFBRSxRQUFRLElBQUksQ0FBQyxLQUFLLElBQUksSUFBSSxDQUFDLFFBQVEsR0FBRztTQUN0RCxDQUFDO0lBQ04sQ0FBQztJQUVPLHFCQUFxQixDQUFDLFFBQWdCO1FBQzFDLElBQUksTUFBTSxHQUFXLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxRQUFRLENBQUMsQ0FBQztRQUNyRCxPQUFPO1lBQ0gsV0FBVyxFQUFFLFlBQVksSUFBSSxDQUFDLEtBQUssS0FBSyxNQUFNLElBQUk7U0FDckQsQ0FBQztJQUNOLENBQUM7SUFFTyxnQkFBZ0IsQ0FBQyxRQUFnQjtRQUNyQyx5RkFBeUY7UUFDekYsK0VBQStFO1FBQy9FLElBQUksWUFBWSxHQUFZLENBQUMsSUFBSSxDQUFDLFVBQVUsS0FBSyxLQUFLLElBQUksQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxVQUFVLEVBQUUsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxVQUFVLEVBQUUsQ0FBQztRQUMxSSxPQUFPLENBQUMsWUFBWSxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxRQUFRLENBQUMsR0FBRyxHQUFHLENBQUM7SUFDMUQsQ0FBQztJQUVELHlGQUF5RjtJQUN6Rjs2RkFDeUY7SUFFakYsWUFBWSxDQUFDLElBQStCLEVBQUUsTUFBZTtRQUNqRSxJQUFJLFFBQVEsR0FBVyxPQUFPLE1BQU0sS0FBSyxXQUFXLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLHdCQUF3QixDQUFDLElBQUksQ0FBQyxDQUFDO1FBQ3BHLElBQUksSUFBSSxDQUFDLE1BQU0sQ0FBQyxLQUFLLEVBQUU7WUFDbkIsSUFBSSxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsa0JBQWtCLENBQUMsR0FBRyxRQUFRLENBQUM7WUFDL0MsSUFBSSxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsa0JBQWtCLENBQUMsR0FBRyxJQUFJLENBQUMsVUFBVSxDQUFDLG1CQUFtQixDQUFDLFFBQVEsQ0FBQyxDQUFDO1NBQzNGO2FBQU07WUFDSCxJQUFJLENBQUMsS0FBSyxHQUFHLFFBQVEsQ0FBQztZQUN0QixJQUFJLENBQUMsUUFBUSxHQUFHLElBQUksQ0FBQyxVQUFVLENBQUMsbUJBQW1CLENBQUMsUUFBUSxDQUFDLENBQUM7U0FDakU7UUFDRCxJQUFJLENBQUMsZUFBZSxFQUFFLENBQUM7SUFDM0IsQ0FBQztJQUVPLHdCQUF3QixDQUFDLElBQThCO1FBQzNELElBQUksQ0FBQyxJQUFJLENBQUMsaUJBQWlCLEVBQUU7WUFDekIsT0FBTztTQUNWO1FBRUQsSUFBSSxNQUFNLEdBQVcsSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLGlCQUFpQixDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLGlCQUFpQixDQUFDLElBQUksQ0FBQztRQUMvRixJQUFJLElBQUksR0FBVyxJQUFJLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsaUJBQWlCLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsaUJBQWlCLENBQUMsS0FBSyxDQUFDO1FBQ2pHLElBQUksWUFBWSxHQUFXLElBQUksQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUM7UUFFNUQsd0ZBQXdGO1FBQ3hGLElBQUksT0FBTyxHQUFXLElBQUksQ0FBQyxVQUFVLENBQUMsS0FBSyxDQUFDLENBQUMsWUFBWSxHQUFHLE1BQU0sQ0FBQyxHQUFHLElBQUksQ0FBQyxDQUFDO1FBQzVFLElBQUksSUFBSSxDQUFDLFVBQVUsQ0FBQyxpQkFBaUIsRUFBRSxFQUFFO1lBQ3JDLE9BQU8sR0FBRyxDQUFDLEdBQUcsT0FBTyxDQUFDO1NBQ3pCO1FBRUQsSUFBSSxVQUFVLEdBQVcsSUFBSSxDQUFDLFVBQVUsQ0FBQyxjQUFjLENBQUMsT0FBTyxDQUFDLENBQUM7UUFFakUsSUFBSSxJQUFJLENBQUMsTUFBTSxDQUFDLEtBQUssRUFBRTtZQUNuQixJQUFJLFVBQVUsR0FBVyxJQUFJLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQyxHQUFHLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxDQUFDLENBQUM7WUFDM0UsSUFBSSxJQUFJLENBQUMsVUFBVSxDQUFDLGtCQUFrQixDQUFDLFVBQVUsRUFBRSxVQUFVLEVBQUUsSUFBSSxDQUFDLGtCQUFrQixDQUFDLEVBQUU7Z0JBQ3JGLFVBQVUsR0FBRyxVQUFVLENBQUM7YUFDM0I7U0FDSjtRQUNELE9BQU8sVUFBVSxDQUFDO0lBQ3RCLENBQUM7SUFFTyxlQUFlO1FBQ25CLElBQUksSUFBSSxDQUFDLE1BQU0sQ0FBQyxLQUFLLEVBQUU7WUFDbkIsSUFBSSxJQUFJLENBQUMsa0JBQWtCLEtBQUssQ0FBQyxFQUFFO2dCQUMvQixJQUFJLENBQUMsb0JBQW9CLEdBQUcsSUFBSSxDQUFDLHFCQUFxQixDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQzthQUM3RTtpQkFBTTtnQkFDSCxJQUFJLENBQUMscUJBQXFCLEdBQUcsSUFBSSxDQUFDLHFCQUFxQixDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQzthQUM5RTtTQUNKO2FBQU07WUFDSCxJQUFJLENBQUMsb0JBQW9CLEdBQUcsSUFBSSxDQUFDLHFCQUFxQixDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsQ0FBQztTQUN6RTtRQUNELElBQUksQ0FBQyxZQUFZLENBQUMsSUFBSSxDQUFDLGtCQUFrQixDQUFDLEdBQUcsSUFBSSxDQUFDLGdCQUFnQixDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQztRQUMvRSxJQUFJLENBQUMsZUFBZSxHQUFHLElBQUksQ0FBQyxnQkFBZ0IsRUFBRSxDQUFDO1FBQy9DLElBQUksSUFBSSxDQUFDLGdCQUFnQixDQUFDLElBQUksQ0FBQyxrQkFBa0IsQ0FBQztZQUFFLElBQUksQ0FBQyxVQUFVLENBQUMsSUFBSSxDQUFDLGtCQUFrQixDQUFDLENBQUMsS0FBSyxFQUFFLENBQUM7SUFDekcsQ0FBQztJQUVELHlGQUF5RjtJQUN6Rjs2RkFDeUY7SUFFakYsZ0JBQWdCLENBQUMsTUFBTTtRQUMzQixJQUFJLElBQUksR0FBUSxFQUFFLENBQUM7UUFDbkIsSUFBSSxJQUFJLENBQUMsTUFBTSxDQUFDLEtBQUssRUFBRTtZQUNuQixJQUFJLElBQUksQ0FBQyxZQUFZLEVBQUU7Z0JBQ25CLE9BQU8sTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDLEdBQUcsRUFBRSxFQUFFO29CQUN0QixJQUFJLEdBQUcsSUFBSSxDQUFDLFVBQVUsQ0FBQyxtQkFBbUIsQ0FBQyxHQUFHLENBQUMsQ0FBQztvQkFDaEQsT0FBTyxJQUFJLENBQUMsVUFBVSxDQUFDLHFCQUFxQixDQUFDLElBQUksRUFBRSxJQUFJLENBQUMsTUFBTSxDQUFDLGFBQWEsQ0FBQyxDQUFDO2dCQUNsRixDQUFDLENBQUMsQ0FBQzthQUNOO1lBQ0QsSUFBSSxHQUFHLElBQUksQ0FBQyxVQUFVLENBQUMsbUJBQW1CLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxDQUFDLENBQUM7U0FDL0U7YUFBTSxJQUFJLElBQUksQ0FBQyxNQUFNLENBQUMsSUFBSSxLQUFLLFFBQVEsRUFBRTtZQUN0QyxJQUFJLEdBQUcsSUFBSSxDQUFDLE1BQU0sQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLENBQUMsV0FBVyxJQUFJLElBQUksQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxDQUFDLEtBQUssQ0FBQyxRQUFRLEVBQUUsQ0FBQztTQUNsRzthQUFNO1lBQ0gsSUFBSSxHQUFHLElBQUksQ0FBQyxVQUFVLENBQUMsbUJBQW1CLENBQUMsTUFBTSxDQUFDLENBQUM7U0FDdEQ7UUFDRCxPQUFPLElBQUksQ0FBQyxVQUFVLENBQUMscUJBQXFCLENBQUMsSUFBSSxFQUFFLElBQUksQ0FBQyxNQUFNLENBQUMsYUFBYSxDQUFDLENBQUM7SUFDbEYsQ0FBQztJQUVELDJDQUEyQztJQUNuQyxxQkFBcUIsQ0FBQyxLQUFrRTtRQUM1RixJQUFJLFVBQVUsR0FBVyxJQUFJLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7UUFDbkQsUUFBUSxLQUFLLEVBQUU7WUFDWCxLQUFLLFVBQVU7Z0JBQ1gsS0FBSyxJQUFJLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxHQUFHLFVBQVUsRUFBRSxFQUFFLENBQUMsRUFBRTtvQkFDakMsSUFBSSxDQUFDLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDLENBQUMsRUFBRTt3QkFDM0IsSUFBSSxDQUFDLFVBQVUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxXQUFXLEVBQUUsQ0FBQzt3QkFDakMsSUFBSSxDQUFDLGdCQUFnQixDQUFDLENBQUMsQ0FBQyxHQUFHLElBQUksQ0FBQztxQkFDbkM7aUJBQ0o7Z0JBQ0QsTUFBTTtZQUNWLEtBQUssVUFBVTtnQkFDWCxLQUFLLElBQUksQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLEdBQUcsVUFBVSxFQUFFLEVBQUUsQ0FBQyxFQUFFO29CQUNqQyxJQUFJLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDLENBQUMsRUFBRTt3QkFDMUIsSUFBSSxDQUFDLFVBQVUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxXQUFXLEVBQUUsQ0FBQzt3QkFDakMsSUFBSSxDQUFDLGdCQUFnQixDQUFDLENBQUMsQ0FBQyxHQUFHLEtBQUssQ0FBQztxQkFDcEM7aUJBQ0o7Z0JBQ0QsTUFBTTtZQUNWLEtBQUssZUFBZTtnQkFDaEIsSUFBSSxDQUFDLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxJQUFJLENBQUMsa0JBQWtCLENBQUMsRUFBRTtvQkFDakQsSUFBSSxDQUFDLFVBQVUsQ0FBQyxJQUFJLENBQUMsa0JBQWtCLENBQUMsQ0FBQyxXQUFXLEVBQUUsQ0FBQztvQkFDdkQsSUFBSSxDQUFDLGdCQUFnQixDQUFDLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxHQUFHLElBQUksQ0FBQztpQkFDekQ7Z0JBQ0QsTUFBTTtZQUNWLEtBQUssZUFBZTtnQkFDaEIsSUFBSSxJQUFJLENBQUMsZ0JBQWdCLENBQUMsSUFBSSxDQUFDLGtCQUFrQixDQUFDLEVBQUU7b0JBQ2hELElBQUksQ0FBQyxVQUFVLENBQUMsSUFBSSxDQUFDLGtCQUFrQixDQUFDLENBQUMsV0FBVyxFQUFFLENBQUM7b0JBQ3ZELElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxJQUFJLENBQUMsa0JBQWtCLENBQUMsR0FBRyxLQUFLLENBQUM7aUJBQzFEO2dCQUNELE1BQU07U0FDYjtJQUNMLENBQUM7SUFFRCx5RkFBeUY7SUFDekY7NkZBQ3lGO0lBRWpGLFFBQVE7UUFDWixJQUFJLE9BQU8sSUFBSSxDQUFDLEdBQUcsS0FBSyxXQUFXLEVBQUU7WUFDakMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxXQUFXLEdBQUcsQ0FBQyxNQUFjLEVBQUUsS0FBYyxFQUFFLEVBQUU7Z0JBQ3RELElBQUksT0FBTyxLQUFLLEtBQUssV0FBVyxFQUFFO29CQUM5QixJQUFJLENBQUMsa0JBQWtCLEdBQUcsS0FBSyxDQUFDO29CQUNoQyxJQUFJLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxHQUFHLE1BQU0sQ0FBQztpQkFDOUI7cUJBQU07b0JBQ0gsSUFBSSxDQUFDLEtBQUssR0FBRyxNQUFNLENBQUM7aUJBQ3ZCO2dCQUNELElBQUksQ0FBQyxZQUFZLENBQUMsSUFBSSxFQUFFLE1BQU0sQ0FBQyxDQUFDO2dCQUNoQyxJQUFJLENBQUMsZ0JBQWdCLEVBQUUsQ0FBQztZQUM1QixDQUFDLENBQUM7U0FDTDtJQUNMLENBQUM7SUFFRCx5RkFBeUY7SUFDekY7NkZBQ3lGO0lBRXpGOzs7O01BSUU7SUFDTSxvQkFBb0I7UUFDeEIsT0FBTyxJQUFJLENBQUMsY0FBYyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsY0FBYyxDQUFDLGFBQWEsQ0FBQyxxQkFBcUIsRUFBRSxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUM7SUFDbEcsQ0FBQzs7O1lBcG5CSixTQUFTLFNBQUM7Z0JBQ1AsUUFBUSxFQUFFLG1CQUFtQjtnQkFDN0IsaThDQUErQztnQkFDL0MsYUFBYSxFQUFFLGlCQUFpQixDQUFDLElBQUk7Z0JBQ3JDLFNBQVMsRUFBRSxDQUFDLFlBQVksRUFBRSxXQUFXLENBQUM7Z0JBQ3RDLElBQUksRUFBRTtvQkFDRixjQUFjLEVBQUUsc0JBQXNCO29CQUN0QyxjQUFjLEVBQUUsc0JBQXNCO29CQUN0QyxTQUFTLEVBQUUsaUJBQWlCO29CQUM1QixhQUFhLEVBQUUscUJBQXFCO29CQUNwQyxXQUFXLEVBQUUsbUJBQW1CO29CQUNoQyxhQUFhLEVBQUUscUJBQXFCO29CQUNwQyxZQUFZLEVBQUUsb0JBQW9CO29CQUNsQyxPQUFPLEVBQUUsb0JBQW9CO29CQUM3QixNQUFNLEVBQUUsUUFBUTtvQkFDaEIsc0JBQXNCLEVBQUUsaUJBQWlCO29CQUN6QyxzQkFBc0IsRUFBRSxZQUFZO29CQUNwQyxzQkFBc0IsRUFBRSxZQUFZO29CQUNwQyxzQkFBc0IsRUFBRSxPQUFPO29CQUMvQix5QkFBeUIsRUFBRSx1Q0FBdUM7b0JBQ2xFLDZCQUE2QixFQUFFLGlCQUFpQjtvQkFDaEQsK0JBQStCLEVBQUUsWUFBWTtvQkFDN0Msa0NBQWtDLEVBQUUsZUFBZTtvQkFDbkQsNEJBQTRCLEVBQUUsWUFBWTtvQkFDMUMsNkJBQTZCLEVBQUUsV0FBVztvQkFDMUMsNEJBQTRCLEVBQUUsWUFBWTtvQkFDMUMsaUNBQWlDLEVBQUUsaUJBQWlCO29CQUNwRCw4QkFBOEIsRUFBRSxjQUFjO29CQUM5Qyw4QkFBOEIsRUFBRSxVQUFVO29CQUMxQyw4QkFBOEIsRUFBRSxVQUFVO2lCQUM3QzthQUNKOzs7WUEzQ0csVUFBVTtZQU9MLFlBQVk7WUFGakIsU0FBUztZQUtKLFdBQVc7Ozt5QkFrRmYsS0FBSyxTQUFDLE9BQU87MEJBQ2IsS0FBSyxTQUFDLFFBQVE7cUJBQ2QsS0FBSztrQkFDTCxLQUFLO3FCQUNMLE1BQU07c0JBQ04sTUFBTTs2QkFHTixTQUFTLFNBQUMsZUFBZSxFQUFFLEVBQUUsTUFBTSxFQUFFLElBQUksRUFBRSIsInNvdXJjZXNDb250ZW50IjpbIlxyXG5pbXBvcnQgeyB0aW1lciBhcyBvYnNlcnZhYmxlVGltZXIsIE9ic2VydmFibGUgfSBmcm9tICdyeGpzJztcclxuXHJcblxyXG5pbXBvcnQge1xyXG4gICAgQ29tcG9uZW50LFxyXG4gICAgVmlld0VuY2Fwc3VsYXRpb24sXHJcbiAgICBJbnB1dCxcclxuICAgIE9uSW5pdCxcclxuICAgIE9uQ2hhbmdlcyxcclxuICAgIFNpbXBsZUNoYW5nZXMsXHJcbiAgICBPbkRlc3Ryb3ksXHJcbiAgICBFbGVtZW50UmVmLFxyXG4gICAgQWZ0ZXJWaWV3SW5pdCxcclxuICAgIEV2ZW50RW1pdHRlcixcclxuICAgIE91dHB1dCxcclxuICAgIFZpZXdDaGlsZCxcclxuICAgIFJlbmRlcmVyMlxyXG59IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xyXG5pbXBvcnQgeyBLZERvbUVsZW1TdmMgfSBmcm9tICcuLi9rZC1jb21tb24vaW5kZXgnO1xyXG5pbXBvcnQgeyBJVG9vbHRpcEFwaSB9IGZyb20gJy4uL2tkLWFuZ3VsYXItdG9vbHRpcC9pbmRleCc7XHJcbmltcG9ydCB7IElTbGlkZXJBcGlJbnRlcm5hbCwgSVNsaWRlckNvbmZpZyB9IGZyb20gJy4va2QtYW5ndWxhci1zbGlkZXItaW50ZXJmYWNlJztcclxuaW1wb3J0IHsgS2RTbGlkZXJTdmMgfSBmcm9tICcuL2tkLWFuZ3VsYXItc2xpZGVyLXN2Yyc7XHJcblxyXG5AQ29tcG9uZW50KHtcclxuICAgIHNlbGVjdG9yOiAna2Qtc2xpZGVyLWNvbnRlbnQnLFxyXG4gICAgdGVtcGxhdGVVcmw6ICcuL2tkLWFuZ3VsYXItc2xpZGVyLWNvbnRlbnQuaHRtbCcsXHJcbiAgICBlbmNhcHN1bGF0aW9uOiBWaWV3RW5jYXBzdWxhdGlvbi5Ob25lLFxyXG4gICAgcHJvdmlkZXJzOiBbS2REb21FbGVtU3ZjLCBLZFNsaWRlclN2Y10sXHJcbiAgICBob3N0OiB7XHJcbiAgICAgICAgJyhtb3VzZWVudGVyKSc6ICdvbk1vdXNlRW50ZXIoJGV2ZW50KScsXHJcbiAgICAgICAgJyhtb3VzZWxlYXZlKSc6ICdvbk1vdXNlTGVhdmUoJGV2ZW50KScsXHJcbiAgICAgICAgJyhjbGljayknOiAnb25DbGljaygkZXZlbnQpJyxcclxuICAgICAgICAnKG1vdXNlbW92ZSknOiAnb25Nb3VzZU1vdmUoJGV2ZW50KScsXHJcbiAgICAgICAgJyhtb3VzZXVwKSc6ICdvbk1vdXNlVXAoJGV2ZW50KScsXHJcbiAgICAgICAgJyh0b3VjaG1vdmUpJzogJ29uVG91Y2hNb3ZlKCRldmVudCknLFxyXG4gICAgICAgICcodG91Y2hlbmQpJzogJ29uVG91Y2hFbmQoJGV2ZW50KScsXHJcbiAgICAgICAgJ2NsYXNzJzogJ2tkeC1zbGlkZXItY29udGVudCcsXHJcbiAgICAgICAgJ3JvbGUnOiAnc2xpZGVyJyxcclxuICAgICAgICAnW2F0dHIuYXJpYS1kaXNhYmxlZF0nOiAnY29uZmlnLmRpc2FibGVkJyxcclxuICAgICAgICAnW2F0dHIuYXJpYS12YWx1ZW1heF0nOiAnY29uZmlnLm1heCcsXHJcbiAgICAgICAgJ1thdHRyLmFyaWEtdmFsdWVtaW5dJzogJ2NvbmZpZy5taW4nLFxyXG4gICAgICAgICdbYXR0ci5hcmlhLXZhbHVlbm93XSc6ICd2YWx1ZScsXHJcbiAgICAgICAgJ1thdHRyLmFyaWEtb3JpZW50YXRpb25dJzogJ192ZXJ0aWNhbCA/IFwidmVydGljYWxcIiA6IFwiaG9yaXpvbnRhbFwiJyxcclxuICAgICAgICAnW2NsYXNzLmtkeC1zbGlkZXItZGlzYWJsZWRdJzogJ2NvbmZpZy5kaXNhYmxlZCcsXHJcbiAgICAgICAgJ1tjbGFzcy5rZHgtc2xpZGVyLWhvcml6b250YWxdJzogJyFfdmVydGljYWwnLFxyXG4gICAgICAgICdbY2xhc3Mua2R4LXNsaWRlci1heGlzLWludmVydGVkXSc6ICdfaXNJbnZlcnRBeGlzJyxcclxuICAgICAgICAnW2NsYXNzLmtkeC1zbGlkZXItc2xpZGluZ10nOiAnX2lzU2xpZGluZycsXHJcbiAgICAgICAgJ1tjbGFzcy5rZHgtc2xpZGVyLXZlcnRpY2FsXSc6ICdfdmVydGljYWwnLFxyXG4gICAgICAgICdbY2xhc3Mua2R4LXNsaWRlci1ob3ZlcmVkXSc6ICdfaXNIb3ZlcmVkJyxcclxuICAgICAgICAnW2NsYXNzLmtkeC1zbGlkZXItaGFzLWF1dG9wbGF5XSc6ICdjb25maWcuYXV0b3BsYXknLFxyXG4gICAgICAgICdbY2xhc3Mua2R4LXNsaWRlci1oYXMtcmFuZ2VdJzogJ2NvbmZpZy5yYW5nZScsXHJcbiAgICAgICAgJ1tjbGFzcy5rZHgtc2xpZGVyLWlzLW1vYmlsZV0nOiAnaXNNb2JpbGUnLFxyXG4gICAgICAgICdbY2xhc3Mua2R4LXNsaWRlci1oYXMtdmFsdWVdJzogJyFub1ZhbHVlJyxcclxuICAgIH0sXHJcbn0pXHJcblxyXG5leHBvcnQgY2xhc3MgS2RTbGlkZXJDb250ZW50IGltcGxlbWVudHMgT25Jbml0LCBPbkNoYW5nZXMsIEFmdGVyVmlld0luaXQsIE9uRGVzdHJveSB7XHJcblxyXG4gICAgcHVibGljIHRyYWNrRmlsbFN0eWxlczogeyBba2V5OiBzdHJpbmddOiBzdHJpbmcgfTtcclxuICAgIHB1YmxpYyB0aHVtYkNvbnRhaW5lclN0eWxlczogeyBba2V5OiBzdHJpbmddOiBzdHJpbmcgfTtcclxuICAgIHB1YmxpYyB0aHVtYkNvbnRhaW5lclN0eWxlczE6IHsgW2tleTogc3RyaW5nXTogc3RyaW5nIH07XHJcbiAgICBwdWJsaWMgc2VsZWN0ZWRUaHVtYkluZGV4OiBudW1iZXIgPSAwO1xyXG4gICAgcHVibGljIGlzTW9iaWxlOiBib29sZWFuID0gZmFsc2U7XHJcbiAgICBwdWJsaWMgY29uZmlnOiBJU2xpZGVyQ29uZmlnID0ge307XHJcbiAgICBwdWJsaWMgdmFsdWU6IGFueTtcclxuICAgIHB1YmxpYyBub1ZhbHVlOiBib29sZWFuID0gZmFsc2U7XHJcblxyXG4gICAgcHVibGljIHRvb2x0aXBBcGk6IEFycmF5PElUb29sdGlwQXBpPiA9IFt7fSwge31dO1xyXG4gICAgcHVibGljIHRvb2x0aXBMYWJlbDogYW55ID0gWzBdO1xyXG4gICAgcHVibGljIHRvb2x0aXBQbGFjZW1lbnQ6IHN0cmluZyA9ICd0b3AnO1xyXG4gICAgcHJpdmF0ZSBfdG9vbHRpcEFwcGVhcmVkOiBBcnJheTxib29sZWFuPiA9IFtmYWxzZV07XHJcbiAgICBwcml2YXRlIF90b29sdGlwVHJhbnNpdGlvbkxpc3RlbmVyOiBhbnk7XHJcbiAgICBwcml2YXRlIF90b29sdGlwVHJhbnNpdGlvbkxpc3RlbmVyMTogYW55O1xyXG5cclxuICAgIHByaXZhdGUgX3dpbmRvd1RhcExpc3RlbmVyOiBhbnk7XHJcbiAgICBwcml2YXRlIF93aW5kb3dTY3JvbGxMaXN0ZW5lcjogYW55O1xyXG5cclxuICAgIHB1YmxpYyBfdmVydGljYWw6IGJvb2xlYW47XHJcbiAgICBwdWJsaWMgX2lzSW52ZXJ0QXhpczogYm9vbGVhbjtcclxuICAgIHB1YmxpYyBfaXNIb3ZlcmVkOiBib29sZWFuID0gZmFsc2U7XHJcblxyXG4gICAgLyoqXHJcbiAgICAqICBXaGV0aGVyIG9yIG5vdCB0aGUgdGh1bWIgaXMgc2xpZGluZy5cclxuICAgICogIFVzZWQgdG8gZGV0ZXJtaW5lIGlmIHRoZXJlIHNob3VsZCBiZSBhIHRyYW5zaXRpb24gZm9yIHRoZSB0aHVtYiBhbmQgZmlsbCB0cmFjay5cclxuICAgICovXHJcbiAgICBwdWJsaWMgX2lzU2xpZGluZzogYm9vbGVhbjtcclxuICAgIC8qKiBUaGUgcGVyY2VudGFnZSBvZiB0aGUgc2xpZGVyIHRoYXQgY29pbmNpZGVzIHdpdGggdGhlIHZhbHVlLiAqL1xyXG4gICAgcHJpdmF0ZSBfcGVyY2VudDogbnVtYmVyID0gMDtcclxuICAgIHByaXZhdGUgX3BlcmNlbnRzOiBBcnJheTxudW1iZXI+ID0gWzAsIDAuMV07XHJcbiAgICBwcml2YXRlIF9kaXJlY3Rpb246IHN0cmluZyA9ICdsdHInO1xyXG4gICAgcHJpdmF0ZSBfYXhpczogc3RyaW5nO1xyXG4gICAgLyoqIFRoZSBkaW1lbnNpb25zIG9mIHRoZSBzbGlkZXIuICovXHJcbiAgICBwcml2YXRlIF9zbGlkZXJEaW1lbnNpb25zOiBDbGllbnRSZWN0IHwgbnVsbCA9IG51bGw7XHJcbiAgICAvKiogVGhlIHZhbHVlIG9mIHRoZSBzbGlkZXIgd2hlbiB0aGUgc2xpZGUgc3RhcnQgZXZlbnQgZmlyZXMuICovXHJcbiAgICBwcml2YXRlIF92YWx1ZU9uU2xpZGVTdGFydDogbnVtYmVyIHwgbnVsbCB8IEFycmF5PG51bWJlcj47XHJcbiAgICBwcml2YXRlIF9pc0ZpcnN0TG9hZDogYm9vbGVhbiA9IHRydWU7XHJcblxyXG4gICAgLyoqXHJcbiAgICAqICBXaGV0aGVyIG9yIG5vdCB0aGUgc2xpZGVyIGlzIGNsaWNrZWQuXHJcbiAgICAqICBVc2VkIHRvIGRldGVybWluZSBpZiB0aGVyZSBzaG91bGQgYmUgYSBzaG93IG9mIHRvb2x0aXAgdmlhIHRyYW5zaXRpb25lbmQgbGlzdGVuZXIuXHJcbiAgICAqL1xyXG4gICAgcHJpdmF0ZSBfaXNDbGljazogYm9vbGVhbiA9IGZhbHNlO1xyXG5cclxuICAgIEBJbnB1dCgndmFsdWUnKSBjaGlsZFZhbHVlOiBhbnkgPSAwO1xyXG4gICAgQElucHV0KCdjb25maWcnKSBjaGlsZENvbmZpZzogSVNsaWRlckNvbmZpZztcclxuICAgIEBJbnB1dCgpIGlzUGxheTogYm9vbGVhbiA9IGZhbHNlO1xyXG4gICAgQElucHV0KCkgYXBpOiBJU2xpZGVyQXBpSW50ZXJuYWw7XHJcbiAgICBAT3V0cHV0KCkgcmVzdWx0OiBFdmVudEVtaXR0ZXI8e30+ID0gbmV3IEV2ZW50RW1pdHRlcigpO1xyXG4gICAgQE91dHB1dCgpIGVuZFBsYXk6IEV2ZW50RW1pdHRlcjx7fT4gPSBuZXcgRXZlbnRFbWl0dGVyKCk7XHJcblxyXG4gICAgLyoqIFJlZmVyZW5jZSB0byB0aGUgaW5uZXIgc2xpZGVyIHdyYXBwZXIgZWxlbWVudC4gKi9cclxuICAgIEBWaWV3Q2hpbGQoJ3NsaWRlcldyYXBwZXInLCB7IHN0YXRpYzogdHJ1ZSB9KSBwcml2YXRlIF9zbGlkZXJXcmFwcGVyOiBFbGVtZW50UmVmO1xyXG5cclxuICAgIGNvbnN0cnVjdG9yKFxyXG4gICAgICAgIHByaXZhdGUgX2VsZW1lbnRSZWY6IEVsZW1lbnRSZWYsXHJcbiAgICAgICAgX2tkRG9tRWxlbVN2YzogS2REb21FbGVtU3ZjLFxyXG4gICAgICAgIHByaXZhdGUgX3JlbmRlcmVyOiBSZW5kZXJlcjIsXHJcbiAgICAgICAgcHJpdmF0ZSBfc2xpZGVyU3ZjOiBLZFNsaWRlclN2Y1xyXG4gICAgKSB7XHJcbiAgICAgICAgdGhpcy5fZGlyZWN0aW9uID0gX2tkRG9tRWxlbVN2Yy5nZXREb2N1bWVudERpcmVjdGlvbih0cnVlKSA9PT0gJ2xlZnQnID8gJ2x0cicgOiAncnRsJztcclxuICAgICAgICB0aGlzLl9zbGlkZXJTdmMuZGlyZWN0aW9uID0gdGhpcy5fZGlyZWN0aW9uO1xyXG4gICAgICAgIHRoaXMuaXNNb2JpbGUgPSBfa2REb21FbGVtU3ZjLmlzTW9iaWxlRGV2aWNlKCk7XHJcbiAgICB9XHJcblxyXG4gICAgbmdPbkluaXQoKTogdm9pZCB7XHJcbiAgICAgICAgaWYgKHR5cGVvZiB0aGlzLmNoaWxkVmFsdWUgPT09ICd1bmRlZmluZWQnKSB7XHJcbiAgICAgICAgICAgIHRoaXMubm9WYWx1ZSA9IHRydWU7XHJcbiAgICAgICAgICAgIHJldHVybjtcclxuICAgICAgICB9XHJcbiAgICAgICAgdGhpcy5fc2V0Q29uZmlnKHRoaXMuY2hpbGRDb25maWcpO1xyXG4gICAgICAgIHRoaXMudmFsdWUgPSB0aGlzLl9zZXREYXRhKHRoaXMuY2hpbGRWYWx1ZSk7XHJcbiAgICAgICAgdGhpcy5fc2V0Rmlyc3RMb2FkUG9zaXRpb25BbmRUb29sdGlwKHRoaXMuY2hpbGRWYWx1ZSk7XHJcbiAgICAgICAgdGhpcy5faW5pdEFwaSgpO1xyXG4gICAgICAgIHRoaXMuX2lzRmlyc3RMb2FkID0gZmFsc2U7XHJcbiAgICB9XHJcblxyXG4gICAgbmdPbkNoYW5nZXMoX3NpbXBsZUNoYW5nZXM6IFNpbXBsZUNoYW5nZXMpOiB2b2lkIHtcclxuICAgICAgICBpZiAoX3NpbXBsZUNoYW5nZXMuaGFzT3duUHJvcGVydHkoJ2lzUGxheScpICYmICF0aGlzLl9pc0ZpcnN0TG9hZCkge1xyXG4gICAgICAgICAgICBpZiAodGhpcy5pc1BsYXkpIHtcclxuICAgICAgICAgICAgICAgIHRoaXMuX2NsaWNrUGxheUJ0bigpO1xyXG4gICAgICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5fY2xpY2tQYXVzZUJ0bigpO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICBpZiAoX3NpbXBsZUNoYW5nZXMuaGFzT3duUHJvcGVydHkoJ2NoaWxkVmFsdWUnKSAmJiAhdGhpcy5faXNGaXJzdExvYWQpIHtcclxuICAgICAgICAgICAgaWYgKF9zaW1wbGVDaGFuZ2VzWydjaGlsZFZhbHVlJ10uY3VycmVudFZhbHVlID09PSB0aGlzLnZhbHVlKSByZXR1cm47XHJcbiAgICAgICAgICAgIHRoaXMudmFsdWUgPSB0aGlzLl9zZXREYXRhKF9zaW1wbGVDaGFuZ2VzWydjaGlsZFZhbHVlJ10uY3VycmVudFZhbHVlKTtcclxuICAgICAgICAgICAgaWYgKHRoaXMubm9WYWx1ZSkge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5fc2V0Rmlyc3RMb2FkUG9zaXRpb25BbmRUb29sdGlwKF9zaW1wbGVDaGFuZ2VzWydjaGlsZFZhbHVlJ10uY3VycmVudFZhbHVlKTtcclxuICAgICAgICAgICAgICAgIHRoaXMubm9WYWx1ZSA9IGZhbHNlO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICBpZiAoX3NpbXBsZUNoYW5nZXMuaGFzT3duUHJvcGVydHkoJ2NoaWxkQ29uZmlnJykgJiYgIXRoaXMuX2lzRmlyc3RMb2FkKSB7XHJcbiAgICAgICAgICAgIGlmIChfc2ltcGxlQ2hhbmdlc1snY2hpbGRDb25maWcnXS5jdXJyZW50VmFsdWUgPT09IHRoaXMuY29uZmlnKSByZXR1cm47XHJcbiAgICAgICAgICAgIHRoaXMuX3NldENvbmZpZyhfc2ltcGxlQ2hhbmdlc1snY2hpbGRDb25maWcnXS5jdXJyZW50VmFsdWUpO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICBuZ0FmdGVyVmlld0luaXQoKTogdm9pZCB7XHJcbiAgICAgICAgaWYgKHRoaXMubm9WYWx1ZSkgcmV0dXJuO1xyXG5cclxuICAgICAgICBsZXQgaXRlcmF0aW9uczogbnVtYmVyID0gdGhpcy5jb25maWcucmFuZ2UgPyAyIDogMTtcclxuICAgICAgICBmb3IgKGxldCBpID0gMDsgaSA8IGl0ZXJhdGlvbnM7ICsraSkge1xyXG4gICAgICAgICAgICB0aGlzLnRvb2x0aXBBcGlbaV0uZGVhY3RpdmF0ZUhvc3RMaXN0ZW5lcigpO1xyXG4gICAgICAgIH1cclxuICAgICAgICB0aGlzLl9hdHRhY2hUaHVtYlRyYW5zaXRpb25MaXN0ZW5lcigpO1xyXG4gICAgICAgIGlmICh0aGlzLmlzTW9iaWxlKSB7XHJcbiAgICAgICAgICAgIHRoaXMuX2F0dGFjaE1vYmlsZVdpbmRvd0xpc3RlbmVyKCk7XHJcbiAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgdGhpcy5fYXR0YWNoV2luZG93TGlzdGVuZXIoKTtcclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgbmdPbkRlc3Ryb3koKTogdm9pZCB7XHJcbiAgICAgICAgaWYgKHRoaXMubm9WYWx1ZSkgcmV0dXJuO1xyXG5cclxuICAgICAgICB0aGlzLl90b29sdGlwVHJhbnNpdGlvbkxpc3RlbmVyKCk7XHJcbiAgICAgICAgaWYgKHRoaXMuY29uZmlnLnJhbmdlKSB0aGlzLl90b29sdGlwVHJhbnNpdGlvbkxpc3RlbmVyMSgpO1xyXG5cclxuICAgICAgICBpZiAodGhpcy5pc01vYmlsZSkge1xyXG4gICAgICAgICAgICB0aGlzLl93aW5kb3dUYXBMaXN0ZW5lcigpO1xyXG4gICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgIHRoaXMuX3dpbmRvd1Njcm9sbExpc3RlbmVyKCk7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIHRoaXMuX3Rvb2x0aXBBcHBlYXJDb250cm9sKCdhbGwgaGlkZScpO1xyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX3NldENvbmZpZyhfY29uZmlnOiBJU2xpZGVyQ29uZmlnKTogdm9pZCB7XHJcbiAgICAgICAgdGhpcy5jb25maWcgPSBPYmplY3QuYXNzaWduKHt9LCBfY29uZmlnKTtcclxuICAgICAgICB0aGlzLl9zbGlkZXJTdmMuY29uZmlnID0gX2NvbmZpZztcclxuICAgICAgICB0aGlzLl9heGlzID0gX2NvbmZpZy5vcmllbnRhdGlvbiA9PT0gJ3ZlcnRpY2FsJyA/ICdZJyA6ICdYJztcclxuICAgICAgICB0aGlzLl92ZXJ0aWNhbCA9IF9jb25maWcub3JpZW50YXRpb24gPT09ICd2ZXJ0aWNhbCcgPyB0cnVlIDogZmFsc2U7XHJcbiAgICAgICAgdGhpcy5faXNJbnZlcnRBeGlzID0gdGhpcy5fc2xpZGVyU3ZjLmludmVydEF4aXMoKTtcclxuICAgICAgICB0aGlzLl9zbGlkZXJTdmMuY2FsY3VsYXRlUm91bmRMYWJlbFRvKCk7XHJcbiAgICAgICAgdGhpcy50b29sdGlwUGxhY2VtZW50ID0gdGhpcy5fc2xpZGVyU3ZjLnNldFRvb2x0aXBQbGFjZW1lbnQoX2NvbmZpZy50b29sdGlwUGxhY2VtZW50KTtcclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF9zZXREYXRhKF92YWx1ZTogYW55KTogYW55IHtcclxuICAgICAgICBpZiAoQXJyYXkuaXNBcnJheShfdmFsdWUpKSByZXR1cm4gX3ZhbHVlLm1hcCgoZWwpID0+IHsgcmV0dXJuIGVsOyB9KTtcclxuICAgICAgICByZXR1cm4gX3ZhbHVlO1xyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX3NldEZpcnN0TG9hZFBvc2l0aW9uQW5kVG9vbHRpcChfdmFsdWUpOiB2b2lkIHtcclxuICAgICAgICBpZiAoQXJyYXkuaXNBcnJheShfdmFsdWUpKSB7XHJcbiAgICAgICAgICAgIHRoaXMuX3BlcmNlbnRzID0gX3ZhbHVlLm1hcCgoZWwpID0+IHsgcmV0dXJuIHRoaXMuX3NsaWRlclN2Yy5jYWxjdWxhdGVQZXJjZW50YWdlKGVsKTsgfSk7XHJcbiAgICAgICAgICAgIHRoaXMudGh1bWJDb250YWluZXJTdHlsZXMgPSB0aGlzLl90aHVtYkNvbnRhaW5lclN0eWxlcyh0aGlzLl9wZXJjZW50c1swXSk7XHJcbiAgICAgICAgICAgIHRoaXMudGh1bWJDb250YWluZXJTdHlsZXMxID0gdGhpcy5fdGh1bWJDb250YWluZXJTdHlsZXModGhpcy5fcGVyY2VudHNbMV0pO1xyXG4gICAgICAgICAgICB0aGlzLl90b29sdGlwQXBwZWFyZWQgPSBbZmFsc2UsIGZhbHNlXTtcclxuICAgICAgICAgICAgdGhpcy50b29sdGlwTGFiZWwgPSB0aGlzLl9zZXRUb29sdGlwTGFiZWwoX3ZhbHVlKTtcclxuICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICB0aGlzLl9wZXJjZW50ID0gdGhpcy5fc2xpZGVyU3ZjLmNhbGN1bGF0ZVBlcmNlbnRhZ2UoX3ZhbHVlKTtcclxuICAgICAgICAgICAgdGhpcy50aHVtYkNvbnRhaW5lclN0eWxlcyA9IHRoaXMuX3RodW1iQ29udGFpbmVyU3R5bGVzKHRoaXMuX3BlcmNlbnQpO1xyXG4gICAgICAgICAgICB0aGlzLnRvb2x0aXBMYWJlbFswXSA9IHRoaXMuX3NldFRvb2x0aXBMYWJlbChfdmFsdWUpO1xyXG4gICAgICAgIH1cclxuICAgICAgICB0aGlzLnRyYWNrRmlsbFN0eWxlcyA9IHRoaXMuX3RyYWNrRmlsbFN0eWxlcygpO1xyXG4gICAgfVxyXG5cclxuXHJcbiAgICAvKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqL1xyXG4gICAgLyogRXZlbnQgTGlzdGVuZXJcclxuICAgIC8qKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKiovXHJcblxyXG4gICAgb25Nb3VzZUVudGVyKGV2ZW50PzogYW55KTogdm9pZCB7XHJcbiAgICAgICAgaWYgKHRoaXMubm9WYWx1ZSkgcmV0dXJuO1xyXG4gICAgICAgIHRoaXMuX2lzSG92ZXJlZCA9IHRydWU7XHJcbiAgICAgICAgdGhpcy5fdG9vbHRpcEFwcGVhckNvbnRyb2woJ2FsbCBzaG93Jyk7XHJcbiAgICAgICAgaWYgKHRoaXMuY29uZmlnLmRpc2FibGVkKSB7XHJcbiAgICAgICAgICAgIHJldHVybjtcclxuICAgICAgICB9XHJcbiAgICAgICAgLy8gV2Ugc2F2ZSB0aGUgZGltZW5zaW9ucyBvZiB0aGUgc2xpZGVyIGhlcmUgc28gd2UgY2FuIHVzZSB0aGVtIHRvIHVwZGF0ZSB0aGUgc3BhY2luZyBvZiB0aGVcclxuICAgICAgICAvLyB0aWNrcyBhbmQgZGV0ZXJtaW5lIHdoZXJlIG9uIHRoZSBzbGlkZXIgY2xpY2sgYW5kIHNsaWRlIGV2ZW50cyBoYXBwZW4uXHJcbiAgICAgICAgdGhpcy5fc2xpZGVyRGltZW5zaW9ucyA9IHRoaXMuX2dldFNsaWRlckRpbWVuc2lvbnMoKTtcclxuICAgIH1cclxuICAgIG9uTW91c2VMZWF2ZShldmVudD86IGFueSk6IHZvaWQge1xyXG4gICAgICAgIGlmICh0aGlzLm5vVmFsdWUpIHJldHVybjtcclxuICAgICAgICBpZiAoIXRoaXMuaXNNb2JpbGUpIHRoaXMub25FbmQoJ21vdXNlbGVhdmUnKTtcclxuICAgICAgICB0aGlzLl90b29sdGlwQXBwZWFyQ29udHJvbCgnYWxsIGhpZGUnKTtcclxuICAgICAgICB0aGlzLl9pc0hvdmVyZWQgPSBmYWxzZTtcclxuICAgIH1cclxuXHJcbiAgICBvbkNsaWNrKGV2ZW50OiBhbnkpOiB2b2lkIHtcclxuICAgICAgICBpZiAodGhpcy5ub1ZhbHVlKSByZXR1cm47XHJcbiAgICAgICAgdGhpcy5fb25DaG9vc2VQb3MoeyB4OiBldmVudC5jbGllbnRYLCB5OiBldmVudC5jbGllbnRZIH0pO1xyXG4gICAgICAgIGV2ZW50LnN0b3BQcm9wYWdhdGlvbigpO1xyXG4gICAgfVxyXG5cclxuICAgIG9uTW91c2VEb3duKGV2ZW50OiBhbnksIGlkOiBudW1iZXIpOiB2b2lkIHtcclxuICAgICAgICBpZiAodGhpcy5ub1ZhbHVlKSByZXR1cm47XHJcbiAgICAgICAgaWYgKCF0aGlzLmlzTW9iaWxlKSB7XHJcbiAgICAgICAgICAgIHRoaXMub25TdGFydCh7IHg6IGV2ZW50LmNsaWVudFgsIHk6IGV2ZW50LmNsaWVudFkgfSwgaWQpO1xyXG4gICAgICAgIH1cclxuICAgICAgICBldmVudC5wcmV2ZW50RGVmYXVsdCgpO1xyXG4gICAgfVxyXG4gICAgb25Nb3VzZU1vdmUoZXZlbnQ6IGFueSk6IHZvaWQge1xyXG4gICAgICAgIGlmICh0aGlzLm5vVmFsdWUpIHJldHVybjtcclxuICAgICAgICBpZiAoIXRoaXMuaXNNb2JpbGUpIHtcclxuICAgICAgICAgICAgdGhpcy5vbk1vdmUoeyB4OiBldmVudC5jbGllbnRYLCB5OiBldmVudC5jbGllbnRZIH0pO1xyXG4gICAgICAgIH1cclxuICAgICAgICBldmVudC5wcmV2ZW50RGVmYXVsdCgpO1xyXG4gICAgfVxyXG4gICAgb25Nb3VzZVVwKGV2ZW50OiBhbnkpOiB2b2lkIHtcclxuICAgICAgICBpZiAodGhpcy5ub1ZhbHVlKSByZXR1cm47XHJcbiAgICAgICAgaWYgKCF0aGlzLmlzTW9iaWxlKSB0aGlzLm9uRW5kKCdtb3VzZXVwJyk7XHJcbiAgICAgICAgZXZlbnQucHJldmVudERlZmF1bHQoKTtcclxuICAgIH1cclxuXHJcbiAgICBvblRvdWNoU3RhcnQoZXZlbnQ6IGFueSwgaWQpOiB2b2lkIHtcclxuICAgICAgICBpZiAodGhpcy5ub1ZhbHVlKSByZXR1cm47XHJcbiAgICAgICAgdGhpcy5vblN0YXJ0KHsgeDogZXZlbnQudG91Y2hlc1snMCddLmNsaWVudFgsIHk6IGV2ZW50LnRvdWNoZXNbJzAnXS5jbGllbnRZIH0sIGlkKTtcclxuICAgICAgICBldmVudC5wcmV2ZW50RGVmYXVsdCgpO1xyXG4gICAgICAgIGV2ZW50LnN0b3BQcm9wYWdhdGlvbigpO1xyXG5cclxuICAgIH1cclxuICAgIG9uVG91Y2hNb3ZlKGV2ZW50OiBhbnkpOiB2b2lkIHtcclxuICAgICAgICBpZiAodGhpcy5ub1ZhbHVlKSByZXR1cm47XHJcbiAgICAgICAgdGhpcy5vbk1vdmUoeyB4OiBldmVudC50b3VjaGVzWycwJ10uY2xpZW50WCwgeTogZXZlbnQudG91Y2hlc1snMCddLmNsaWVudFkgfSk7XHJcbiAgICAgICAgZXZlbnQucHJldmVudERlZmF1bHQoKTtcclxuICAgICAgICBldmVudC5zdG9wUHJvcGFnYXRpb24oKTtcclxuICAgIH1cclxuICAgIG9uVG91Y2hFbmQoZXZlbnQ6IGFueSk6IHZvaWQge1xyXG4gICAgICAgIGlmICh0aGlzLm5vVmFsdWUpIHJldHVybjtcclxuICAgICAgICB0aGlzLm9uRW5kKCd0b3VjaGVuZCcpO1xyXG4gICAgICAgIGV2ZW50LnN0b3BQcm9wYWdhdGlvbigpO1xyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX2F0dGFjaE1vYmlsZVdpbmRvd0xpc3RlbmVyKCkge1xyXG4gICAgICAgIHRoaXMuX3dpbmRvd1RhcExpc3RlbmVyID0gdGhpcy5fcmVuZGVyZXIubGlzdGVuKCdkb2N1bWVudCcsICd0b3VjaHN0YXJ0JywgKGV2ZW50KSA9PiB7XHJcbiAgICAgICAgICAgIHRoaXMuX3Rvb2x0aXBBcHBlYXJDb250cm9sKCdhbGwgaGlkZScpO1xyXG4gICAgICAgICAgICB0aGlzLl9pc0hvdmVyZWQgPSBmYWxzZTtcclxuICAgICAgICB9KTtcclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF9hdHRhY2hXaW5kb3dMaXN0ZW5lcigpIHtcclxuICAgICAgICB0aGlzLl93aW5kb3dTY3JvbGxMaXN0ZW5lciA9IHRoaXMuX3JlbmRlcmVyLmxpc3Rlbignd2luZG93JywgJ21vdXNld2hlZWwnLCAoZXZlbnQpID0+IHtcclxuICAgICAgICAgICAgb2JzZXJ2YWJsZVRpbWVyKDUwKS5zdWJzY3JpYmUoKCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5fdG9vbHRpcEFwcGVhckNvbnRyb2woJ2FsbCBoaWRlJyk7XHJcbiAgICAgICAgICAgICAgICB0aGlzLl9pc0hvdmVyZWQgPSBmYWxzZTtcclxuICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgfSk7XHJcbiAgICAgICAgdGhpcy5fd2luZG93U2Nyb2xsTGlzdGVuZXIgPSB0aGlzLl9yZW5kZXJlci5saXN0ZW4oJ3dpbmRvdycsICdET01Nb3VzZVNjcm9sbCcsIChldmVudCkgPT4ge1xyXG4gICAgICAgICAgICBvYnNlcnZhYmxlVGltZXIoNTApLnN1YnNjcmliZSgoKSA9PiB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLl90b29sdGlwQXBwZWFyQ29udHJvbCgnYWxsIGhpZGUnKTtcclxuICAgICAgICAgICAgICAgIHRoaXMuX2lzSG92ZXJlZCA9IGZhbHNlO1xyXG4gICAgICAgICAgICB9KTtcclxuICAgICAgICB9KTtcclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF9hdHRhY2hUaHVtYlRyYW5zaXRpb25MaXN0ZW5lcigpIHtcclxuICAgICAgICBsZXQgdGh1bWJDb250YWluZXJFbGVtZW50cyA9IHRoaXMuX2VsZW1lbnRSZWYubmF0aXZlRWxlbWVudC5xdWVyeVNlbGVjdG9yQWxsKCcua2R4LXNsaWRlciAua2R4LXNsaWRlci1jb250ZW50IC5rZHgtc2xpZGVyLWNvbnRlbnQtd3JhcHBlciAua2R4LXNsaWRlci10aHVtYi1jb250YWluZXInKTtcclxuICAgICAgICB0aGlzLl90b29sdGlwVHJhbnNpdGlvbkxpc3RlbmVyID0gdGhpcy5fcmVuZGVyZXIubGlzdGVuKHRodW1iQ29udGFpbmVyRWxlbWVudHNbMF0sICd0cmFuc2l0aW9uZW5kJywgKCkgPT4ge1xyXG4gICAgICAgICAgICBpZiAodGhpcy5pc1BsYXkgJiYgdGhpcy5jb25maWcuYXV0b3BsYXkpIHRoaXMuX3VwZGF0ZUF1dG9wbGF5VmFsdWUoKTtcclxuXHJcbiAgICAgICAgICAgIGlmICghdGhpcy5pc1BsYXkgJiYgdGhpcy5faXNDbGljayAmJiAhdGhpcy5faXNTbGlkaW5nKSB0aGlzLl90b29sdGlwT25UaHVtYlRyYW5zaXRpb24oKTtcclxuICAgICAgICB9KTtcclxuICAgICAgICBpZiAodGhpcy5jb25maWcucmFuZ2UpIHtcclxuICAgICAgICAgICAgdGhpcy5fdG9vbHRpcFRyYW5zaXRpb25MaXN0ZW5lcjEgPSB0aGlzLl9yZW5kZXJlci5saXN0ZW4odGh1bWJDb250YWluZXJFbGVtZW50c1sxXSwgJ3RyYW5zaXRpb25lbmQnLCAoKSA9PiB7XHJcbiAgICAgICAgICAgICAgICBpZiAoIXRoaXMuY29uZmlnLmF1dG9wbGF5ICYmIHRoaXMuX2lzQ2xpY2sgJiYgIXRoaXMuX2lzU2xpZGluZykgdGhpcy5fdG9vbHRpcE9uVGh1bWJUcmFuc2l0aW9uKCk7XHJcbiAgICAgICAgICAgIH0pO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF90b29sdGlwT25UaHVtYlRyYW5zaXRpb24oKSB7XHJcbiAgICAgICAgdGhpcy5fdG9vbHRpcEFwcGVhckNvbnRyb2woJ3Nob3cgc2VsZWN0ZWQnKTtcclxuICAgICAgICB0aGlzLl9pc0NsaWNrID0gZmFsc2U7XHJcbiAgICAgICAgaWYgKCF0aGlzLl9pc0hvdmVyZWQpIHNldFRpbWVvdXQoKCkgPT4gdGhpcy5fdG9vbHRpcEFwcGVhckNvbnRyb2woJ2hpZGUgc2VsZWN0ZWQnKSwgMTAwMCk7XHJcbiAgICB9XHJcblxyXG4gICAgLyoqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKi9cclxuICAgIC8qIExpc3RlbmVyIExvZ2ljXHJcbiAgICAvKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqL1xyXG5cclxuICAgIHByaXZhdGUgb25TdGFydChwb3M6IHsgeDogbnVtYmVyLCB5OiBudW1iZXIgfSwgaWQpOiB2b2lkIHtcclxuICAgICAgICBpZiAodGhpcy5jb25maWcuZGlzYWJsZWQgfHwgdGhpcy5faXNTbGlkaW5nKSB7XHJcbiAgICAgICAgICAgIHJldHVybjtcclxuICAgICAgICB9XHJcbiAgICAgICAgLy8gU2ltdWxhdGUgbW91c2VlbnRlciBpbiBjYXNlIHRoaXMgaXMgYSBtb2JpbGUgZGV2aWNlLlxyXG4gICAgICAgIHRoaXMub25Nb3VzZUVudGVyKCk7XHJcblxyXG4gICAgICAgIHRoaXMuX2lzU2xpZGluZyA9IHRydWU7XHJcbiAgICAgICAgaWYgKHRoaXMuY29uZmlnLnJhbmdlKSB7XHJcbiAgICAgICAgICAgIHRoaXMuc2VsZWN0ZWRUaHVtYkluZGV4ID0gaWQ7XHJcbiAgICAgICAgICAgIHRoaXMuX3ZhbHVlT25TbGlkZVN0YXJ0ID0gdGhpcy52YWx1ZVt0aGlzLnNlbGVjdGVkVGh1bWJJbmRleF07XHJcbiAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgdGhpcy5fdmFsdWVPblNsaWRlU3RhcnQgPSB0aGlzLnZhbHVlO1xyXG4gICAgICAgIH1cclxuICAgICAgICB0aGlzLl9oYW5kbGVWYWx1ZShwb3MpO1xyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgb25Nb3ZlKHBvczogeyB4OiBudW1iZXIsIHk6IG51bWJlciB9KTogdm9pZCB7XHJcbiAgICAgICAgaWYgKHRoaXMuY29uZmlnLmRpc2FibGVkIHx8ICF0aGlzLl9pc1NsaWRpbmcpIHtcclxuICAgICAgICAgICAgcmV0dXJuO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgbGV0IG9sZFZhbHVlOiBudW1iZXIgPSAwO1xyXG5cclxuICAgICAgICBpZiAodGhpcy5jb25maWcucmFuZ2UpIHtcclxuICAgICAgICAgICAgb2xkVmFsdWUgPSB0aGlzLnZhbHVlW3RoaXMuc2VsZWN0ZWRUaHVtYkluZGV4XTtcclxuICAgICAgICAgICAgdGhpcy5faGFuZGxlVmFsdWUocG9zKTtcclxuXHJcbiAgICAgICAgICAgIGlmIChvbGRWYWx1ZSAhPT0gdGhpcy52YWx1ZVt0aGlzLnNlbGVjdGVkVGh1bWJJbmRleF0pIHtcclxuICAgICAgICAgICAgICAgIHRoaXMuX2VtaXRDaGFuZ2VFdmVudCgnc2xpZGluZycpO1xyXG4gICAgICAgICAgICAgICAgcmV0dXJuO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICBvbGRWYWx1ZSA9IHRoaXMudmFsdWU7XHJcbiAgICAgICAgdGhpcy5faGFuZGxlVmFsdWUocG9zKTtcclxuICAgICAgICAvLyBOYXRpdmUgcmFuZ2UgZWxlbWVudHMgYWx3YXlzIGVtaXQgYGlucHV0YCBldmVudHMgd2hlbiB0aGUgdmFsdWUgY2hhbmdlZCB3aGlsZSBzbGlkaW5nLlxyXG4gICAgICAgIGlmIChvbGRWYWx1ZSAhPT0gdGhpcy52YWx1ZSkge1xyXG4gICAgICAgICAgICB0aGlzLl9lbWl0Q2hhbmdlRXZlbnQoJ3NsaWRpbmcnKTtcclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBvbkVuZChfZnJvbVdoZXJlOiBzdHJpbmcpOiB2b2lkIHtcclxuICAgICAgICBpZiAoIXRoaXMuX2lzU2xpZGluZykge1xyXG4gICAgICAgICAgICByZXR1cm47XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICBpZiAoX2Zyb21XaGVyZSA9PT0gJ21vdXNlbGVhdmUnKSB7XHJcbiAgICAgICAgICAgIHRoaXMuX2lzU2xpZGluZyA9IGZhbHNlO1xyXG4gICAgICAgIH0gZWxzZSBpZiAodGhpcy5pc01vYmlsZSkgdGhpcy5faXNTbGlkaW5nID0gZmFsc2U7XHJcblxyXG4gICAgICAgIGlmICh0aGlzLmNvbmZpZy5yYW5nZSkge1xyXG4gICAgICAgICAgICBpZiAodGhpcy5fdmFsdWVPblNsaWRlU3RhcnQgIT09IHRoaXMudmFsdWVbdGhpcy5zZWxlY3RlZFRodW1iSW5kZXhdKSB0aGlzLl9lbWl0Q2hhbmdlRXZlbnQoKTtcclxuICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICBpZiAodGhpcy5fdmFsdWVPblNsaWRlU3RhcnQgIT09IHRoaXMudmFsdWUpIHRoaXMuX2VtaXRDaGFuZ2VFdmVudCgpO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgdGhpcy5fdmFsdWVPblNsaWRlU3RhcnQgPSBudWxsO1xyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX29uQ2hvb3NlUG9zKHBvczogeyB4OiBudW1iZXIsIHk6IG51bWJlciB9KTogdm9pZCB7XHJcbiAgICAgICAgaWYgKHRoaXMuY29uZmlnLmRpc2FibGVkKSB7XHJcbiAgICAgICAgICAgIHJldHVybjtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIC8vIFNpbXVsYXRlIG1vdXNlZW50ZXIgaW4gY2FzZSB0aGlzIGlzIGEgbW9iaWxlIGRldmljZS5cclxuICAgICAgICB0aGlzLm9uTW91c2VFbnRlcigpO1xyXG5cclxuICAgICAgICB0aGlzLl9pc0NsaWNrID0gdHJ1ZTtcclxuXHJcbiAgICAgICAgaWYgKHRoaXMuX2lzQ2xpY2sgJiYgIXRoaXMuX2lzU2xpZGluZykge1xyXG4gICAgICAgICAgICB0aGlzLl90b29sdGlwQXBwZWFyQ29udHJvbCgnaGlkZSBzZWxlY3RlZCcpO1xyXG4gICAgICAgIH1cclxuICAgICAgICB0aGlzLl9pc1NsaWRpbmcgPSBmYWxzZTtcclxuXHJcbiAgICAgICAgbGV0IG9sZFZhbHVlOiBudW1iZXIgPSAwO1xyXG5cclxuICAgICAgICBpZiAodGhpcy5jb25maWcucmFuZ2UpIHtcclxuICAgICAgICAgICAgb2xkVmFsdWUgPSB0aGlzLnZhbHVlW3RoaXMuc2VsZWN0ZWRUaHVtYkluZGV4XTtcclxuICAgICAgICAgICAgdGhpcy5faGFuZGxlVmFsdWUocG9zKTtcclxuICAgICAgICAgICAgaWYgKG9sZFZhbHVlICE9PSB0aGlzLnZhbHVlW3RoaXMuc2VsZWN0ZWRUaHVtYkluZGV4XSkge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5fZW1pdENoYW5nZUV2ZW50KCk7XHJcbiAgICAgICAgICAgICAgICByZXR1cm47XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIG9sZFZhbHVlID0gdGhpcy52YWx1ZTtcclxuICAgICAgICB0aGlzLl9oYW5kbGVWYWx1ZShwb3MpO1xyXG5cclxuICAgICAgICAvKiBFbWl0IGEgY2hhbmdlIGFuZCBpbnB1dCBldmVudCBpZiB0aGUgdmFsdWUgY2hhbmdlZC4gKi9cclxuICAgICAgICBpZiAob2xkVmFsdWUgIT09IHRoaXMudmFsdWUpIHtcclxuICAgICAgICAgICAgdGhpcy5fZW1pdENoYW5nZUV2ZW50KCk7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIC8qKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKiovXHJcbiAgICAvKiBBdXRvcGxheVxyXG4gICAgLyoqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKi9cclxuXHJcbiAgICBwcml2YXRlIF9jbGlja1BsYXlCdG4oKTogdm9pZCB7XHJcbiAgICAgICAgdGhpcy5jb25maWcuZGlzYWJsZWQgPSB0cnVlO1xyXG4gICAgICAgIHRoaXMuX3VwZGF0ZUF1dG9wbGF5VmFsdWUoKTtcclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF9jbGlja1BhdXNlQnRuKCk6IHZvaWQge1xyXG4gICAgICAgIHRoaXMuY29uZmlnLmRpc2FibGVkID0gZmFsc2U7XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfdXBkYXRlQXV0b3BsYXlWYWx1ZSgpOiB2b2lkIHtcclxuICAgICAgICB0aGlzLl90b29sdGlwQXBwZWFyQ29udHJvbCgnc2hvdyBzZWxlY3RlZCcpO1xyXG4gICAgICAgIHNldFRpbWVvdXQoKCkgPT4ge1xyXG4gICAgICAgICAgICB0aGlzLl90b29sdGlwQXBwZWFyQ29udHJvbCgnaGlkZSBzZWxlY3RlZCcpO1xyXG4gICAgICAgICAgICBpZiAoIXRoaXMuaXNQbGF5KSByZXR1cm47XHJcblxyXG4gICAgICAgICAgICB0aGlzLnZhbHVlID0gdGhpcy52YWx1ZSArICh0aGlzLmNvbmZpZy5hdXRvcGxheVN0ZXAgfHwgMSk7XHJcblxyXG4gICAgICAgICAgICBpZiAodGhpcy52YWx1ZSA+IHRoaXMuY29uZmlnLm1heCkge1xyXG4gICAgICAgICAgICAgICAgdGhpcy52YWx1ZSA9IHRoaXMuY29uZmlnLm1pbjtcclxuICAgICAgICAgICAgICAgIHRoaXMuZW5kUGxheS5lbWl0KHRydWUpO1xyXG4gICAgICAgICAgICAgICAgdGhpcy50b29sdGlwQXBpWzBdLmhpZGVUb29sdGlwKCk7XHJcbiAgICAgICAgICAgICAgICB0aGlzLmNvbmZpZy5kaXNhYmxlZCA9IGZhbHNlO1xyXG4gICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICB0aGlzLl9wZXJjZW50ID0gdGhpcy5fc2xpZGVyU3ZjLmNhbGN1bGF0ZVBlcmNlbnRhZ2UodGhpcy52YWx1ZSk7XHJcbiAgICAgICAgICAgIHRoaXMuX2hhbmRsZVBvc2l0aW9uKCk7XHJcbiAgICAgICAgICAgIHRoaXMuX2VtaXRDaGFuZ2VFdmVudCgpO1xyXG4gICAgICAgIH0sIHRoaXMuY29uZmlnLmF1dG9wbGF5RGVsYXkgfHwgNTAwKTtcclxuICAgIH1cclxuXHJcbiAgICAvKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqL1xyXG4gICAgLyogRXZlbnQgRW1pdFxyXG4gICAgLyoqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKi9cclxuXHJcbiAgICAvKiogRW1pdHMgYSBjaGFuZ2UgZXZlbnQgaWYgdGhlIGN1cnJlbnQgdmFsdWUgaXMgZGlmZmVyZW50IGZyb20gdGhlIGxhc3QgZW1pdHRlZCB2YWx1ZS4gKi9cclxuICAgIHByaXZhdGUgX2VtaXRDaGFuZ2VFdmVudChfY3VycmVudEFjdGlvbj86ICdzbGlkaW5nJyk6IHZvaWQge1xyXG4gICAgICAgIHRoaXMucmVzdWx0LmVtaXQoe1xyXG4gICAgICAgICAgICB2YWx1ZTogdGhpcy52YWx1ZSxcclxuICAgICAgICAgICAgY3VycmVudEFjdGlvbjogX2N1cnJlbnRBY3Rpb25cclxuICAgICAgICB9KTtcclxuICAgIH1cclxuXHJcbiAgICAvKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqL1xyXG4gICAgLyogQ1NTIFN0eWxlc1xyXG4gICAgLyoqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKi9cclxuXHJcbiAgICBwcml2YXRlIF90cmFja0ZpbGxTdHlsZXMoKTogeyBba2V5OiBzdHJpbmddOiBzdHJpbmcgfSB7XHJcbiAgICAgICAgaWYgKHRoaXMuY29uZmlnLnJhbmdlKSB7XHJcbiAgICAgICAgICAgIGxldCBpbnZlcnRPZmZzZXQ6IGJvb2xlYW4gPSAodGhpcy5fZGlyZWN0aW9uID09PSAncnRsJyAmJiAhdGhpcy5fdmVydGljYWwpID8gIXRoaXMuX3NsaWRlclN2Yy5pbnZlcnRBeGlzKCkgOiB0aGlzLl9zbGlkZXJTdmMuaW52ZXJ0QXhpcygpO1xyXG4gICAgICAgICAgICBsZXQgc2lnbjogc3RyaW5nID0gaW52ZXJ0T2Zmc2V0ID8gJy0nIDogJyc7XHJcbiAgICAgICAgICAgIGxldCBmaXJzdFRodW1iUG9zaXRpb246IG51bWJlciA9IGludmVydE9mZnNldCA/IHRoaXMuX2NhbGN1bGF0ZU9mZnNldCh0aGlzLl9wZXJjZW50c1swXSkgOiAxMDAgLSB0aGlzLl9jYWxjdWxhdGVPZmZzZXQodGhpcy5fcGVyY2VudHNbMF0pO1xyXG4gICAgICAgICAgICBsZXQgc2NhbGVQZXJjZW50OiBudW1iZXIgPSB0aGlzLl9wZXJjZW50c1sxXSAtIHRoaXMuX3BlcmNlbnRzWzBdO1xyXG4gICAgICAgICAgICByZXR1cm4ge1xyXG4gICAgICAgICAgICAgICAgJ3RyYW5zZm9ybSc6IGB0cmFuc2xhdGUke3RoaXMuX2F4aXN9KCR7c2lnbn0ke2ZpcnN0VGh1bWJQb3NpdGlvbn0lKSBzY2FsZSR7dGhpcy5fYXhpc30oJHtzY2FsZVBlcmNlbnR9KWBcclxuICAgICAgICAgICAgfTtcclxuICAgICAgICB9XHJcbiAgICAgICAgcmV0dXJuIHtcclxuICAgICAgICAgICAgJ3RyYW5zZm9ybSc6IGBzY2FsZSR7dGhpcy5fYXhpc30oJHt0aGlzLl9wZXJjZW50fSlgXHJcbiAgICAgICAgfTtcclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF90aHVtYkNvbnRhaW5lclN0eWxlcyhfcGVyY2VudDogbnVtYmVyKTogeyBba2V5OiBzdHJpbmddOiBzdHJpbmcgfSB7XHJcbiAgICAgICAgbGV0IG9mZnNldDogbnVtYmVyID0gdGhpcy5fY2FsY3VsYXRlT2Zmc2V0KF9wZXJjZW50KTtcclxuICAgICAgICByZXR1cm4ge1xyXG4gICAgICAgICAgICAndHJhbnNmb3JtJzogYHRyYW5zbGF0ZSR7dGhpcy5fYXhpc30oLSR7b2Zmc2V0fSUpYFxyXG4gICAgICAgIH07XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfY2FsY3VsYXRlT2Zmc2V0KF9wZXJjZW50OiBudW1iZXIpOiBudW1iZXIge1xyXG4gICAgICAgIC8vIEZvciBhIGhvcml6b250YWwgc2xpZGVyIGluIFJUTCBsYW5ndWFnZXMgd2UgcHVzaCB0aGUgdGh1bWIgY29udGFpbmVyIG9mZiB0aGUgbGVmdCBlZGdlXHJcbiAgICAgICAgLy8gaW5zdGVhZCBvZiB0aGUgcmlnaHQgZWRnZSB0byBhdm9pZCBjYXVzaW5nIGEgaG9yaXpvbnRhbCBzY3JvbGxiYXIgdG8gYXBwZWFyLlxyXG4gICAgICAgIGxldCBpbnZlcnRPZmZzZXQ6IGJvb2xlYW4gPSAodGhpcy5fZGlyZWN0aW9uID09PSAncnRsJyAmJiAhdGhpcy5fdmVydGljYWwpID8gIXRoaXMuX3NsaWRlclN2Yy5pbnZlcnRBeGlzKCkgOiB0aGlzLl9zbGlkZXJTdmMuaW52ZXJ0QXhpcygpO1xyXG4gICAgICAgIHJldHVybiAoaW52ZXJ0T2Zmc2V0ID8gX3BlcmNlbnQgOiAxIC0gX3BlcmNlbnQpICogMTAwO1xyXG4gICAgfVxyXG5cclxuICAgIC8qKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKiovXHJcbiAgICAvKiBTZXR0aW5nIFZhbHVlc1xyXG4gICAgLyoqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKi9cclxuXHJcbiAgICBwcml2YXRlIF9oYW5kbGVWYWx1ZShfcG9zPzogeyB4OiBudW1iZXIsIHk6IG51bWJlciB9LCBfdmFsdWU/OiBudW1iZXIpOiB2b2lkIHtcclxuICAgICAgICBsZXQgbmV3VmFsdWU6IG51bWJlciA9IHR5cGVvZiBfdmFsdWUgIT09ICd1bmRlZmluZWQnID8gX3ZhbHVlIDogdGhpcy5fdXBkYXRlVmFsdWVGcm9tUG9zaXRpb24oX3Bvcyk7XHJcbiAgICAgICAgaWYgKHRoaXMuY29uZmlnLnJhbmdlKSB7XHJcbiAgICAgICAgICAgIHRoaXMudmFsdWVbdGhpcy5zZWxlY3RlZFRodW1iSW5kZXhdID0gbmV3VmFsdWU7XHJcbiAgICAgICAgICAgIHRoaXMuX3BlcmNlbnRzW3RoaXMuc2VsZWN0ZWRUaHVtYkluZGV4XSA9IHRoaXMuX3NsaWRlclN2Yy5jYWxjdWxhdGVQZXJjZW50YWdlKG5ld1ZhbHVlKTtcclxuICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICB0aGlzLnZhbHVlID0gbmV3VmFsdWU7XHJcbiAgICAgICAgICAgIHRoaXMuX3BlcmNlbnQgPSB0aGlzLl9zbGlkZXJTdmMuY2FsY3VsYXRlUGVyY2VudGFnZShuZXdWYWx1ZSk7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIHRoaXMuX2hhbmRsZVBvc2l0aW9uKCk7XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfdXBkYXRlVmFsdWVGcm9tUG9zaXRpb24oX3BvczogeyB4OiBudW1iZXIsIHk6IG51bWJlciB9KTogbnVtYmVyIHtcclxuICAgICAgICBpZiAoIXRoaXMuX3NsaWRlckRpbWVuc2lvbnMpIHtcclxuICAgICAgICAgICAgcmV0dXJuO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgbGV0IG9mZnNldDogbnVtYmVyID0gdGhpcy5fdmVydGljYWwgPyB0aGlzLl9zbGlkZXJEaW1lbnNpb25zLnRvcCA6IHRoaXMuX3NsaWRlckRpbWVuc2lvbnMubGVmdDtcclxuICAgICAgICBsZXQgc2l6ZTogbnVtYmVyID0gdGhpcy5fdmVydGljYWwgPyB0aGlzLl9zbGlkZXJEaW1lbnNpb25zLmhlaWdodCA6IHRoaXMuX3NsaWRlckRpbWVuc2lvbnMud2lkdGg7XHJcbiAgICAgICAgbGV0IHBvc0NvbXBvbmVudDogbnVtYmVyID0gdGhpcy5fdmVydGljYWwgPyBfcG9zLnkgOiBfcG9zLng7XHJcblxyXG4gICAgICAgIC8vIFRoZSBleGFjdCB2YWx1ZSBpcyBjYWxjdWxhdGVkIGZyb20gdGhlIGV2ZW50IGFuZCB1c2VkIHRvIGZpbmQgdGhlIGNsb3Nlc3Qgc25hcCB2YWx1ZS5cclxuICAgICAgICBsZXQgcGVyY2VudDogbnVtYmVyID0gdGhpcy5fc2xpZGVyU3ZjLmNsYW1wKChwb3NDb21wb25lbnQgLSBvZmZzZXQpIC8gc2l6ZSk7XHJcbiAgICAgICAgaWYgKHRoaXMuX3NsaWRlclN2Yy5pbnZlcnRNb3VzZUNvb3JkcygpKSB7XHJcbiAgICAgICAgICAgIHBlcmNlbnQgPSAxIC0gcGVyY2VudDtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIGxldCBmaW5hbFZhbHVlOiBudW1iZXIgPSB0aGlzLl9zbGlkZXJTdmMuY2FsY3VsYXRlVmFsdWUocGVyY2VudCk7XHJcblxyXG4gICAgICAgIGlmICh0aGlzLmNvbmZpZy5yYW5nZSkge1xyXG4gICAgICAgICAgICBsZXQgb3RoZXJWYWx1ZTogbnVtYmVyID0gdGhpcy52YWx1ZVtNYXRoLmFicygxIC0gdGhpcy5zZWxlY3RlZFRodW1iSW5kZXgpXTtcclxuICAgICAgICAgICAgaWYgKHRoaXMuX3NsaWRlclN2Yy5jaGVja1ZhbHVlQ29uZmxpY3QoZmluYWxWYWx1ZSwgb3RoZXJWYWx1ZSwgdGhpcy5zZWxlY3RlZFRodW1iSW5kZXgpKSB7XHJcbiAgICAgICAgICAgICAgICBmaW5hbFZhbHVlID0gb3RoZXJWYWx1ZTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgICAgICByZXR1cm4gZmluYWxWYWx1ZTtcclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF9oYW5kbGVQb3NpdGlvbigpOiB2b2lkIHtcclxuICAgICAgICBpZiAodGhpcy5jb25maWcucmFuZ2UpIHtcclxuICAgICAgICAgICAgaWYgKHRoaXMuc2VsZWN0ZWRUaHVtYkluZGV4ID09PSAwKSB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLnRodW1iQ29udGFpbmVyU3R5bGVzID0gdGhpcy5fdGh1bWJDb250YWluZXJTdHlsZXModGhpcy5fcGVyY2VudHNbMF0pO1xyXG4gICAgICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgdGhpcy50aHVtYkNvbnRhaW5lclN0eWxlczEgPSB0aGlzLl90aHVtYkNvbnRhaW5lclN0eWxlcyh0aGlzLl9wZXJjZW50c1sxXSk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICB0aGlzLnRodW1iQ29udGFpbmVyU3R5bGVzID0gdGhpcy5fdGh1bWJDb250YWluZXJTdHlsZXModGhpcy5fcGVyY2VudCk7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIHRoaXMudG9vbHRpcExhYmVsW3RoaXMuc2VsZWN0ZWRUaHVtYkluZGV4XSA9IHRoaXMuX3NldFRvb2x0aXBMYWJlbCh0aGlzLnZhbHVlKTtcclxuICAgICAgICB0aGlzLnRyYWNrRmlsbFN0eWxlcyA9IHRoaXMuX3RyYWNrRmlsbFN0eWxlcygpO1xyXG4gICAgICAgIGlmICh0aGlzLl90b29sdGlwQXBwZWFyZWRbdGhpcy5zZWxlY3RlZFRodW1iSW5kZXhdKSB0aGlzLnRvb2x0aXBBcGlbdGhpcy5zZWxlY3RlZFRodW1iSW5kZXhdLmFsaWduKCk7XHJcbiAgICB9XHJcblxyXG4gICAgLyoqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKi9cclxuICAgIC8qIFRvb2x0aXAgZnVuY3Rpb25zXHJcbiAgICAvKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqL1xyXG5cclxuICAgIHByaXZhdGUgX3NldFRvb2x0aXBMYWJlbChfdmFsdWUpOiBBcnJheTxudW1iZXI+IHwgc3RyaW5nIHtcclxuICAgICAgICBsZXQgdGV4dDogYW55ID0gJyc7XHJcbiAgICAgICAgaWYgKHRoaXMuY29uZmlnLnJhbmdlKSB7XHJcbiAgICAgICAgICAgIGlmICh0aGlzLl9pc0ZpcnN0TG9hZCkge1xyXG4gICAgICAgICAgICAgICAgcmV0dXJuIF92YWx1ZS5tYXAoKG51bSkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgIHRleHQgPSB0aGlzLl9zbGlkZXJTdmMuY2FsY3VsYXRlTGFiZWxWYWx1ZShudW0pO1xyXG4gICAgICAgICAgICAgICAgICAgIHJldHVybiB0aGlzLl9zbGlkZXJTdmMuZ2V0TGFiZWxGb3JtYXRSZXBsYWNlKHRleHQsIHRoaXMuY29uZmlnLnRvb2x0aXBGb3JtYXQpO1xyXG4gICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgdGV4dCA9IHRoaXMuX3NsaWRlclN2Yy5jYWxjdWxhdGVMYWJlbFZhbHVlKF92YWx1ZVt0aGlzLnNlbGVjdGVkVGh1bWJJbmRleF0pO1xyXG4gICAgICAgIH0gZWxzZSBpZiAodGhpcy5jb25maWcudHlwZSA9PT0gJ290aGVycycpIHtcclxuICAgICAgICAgICAgdGV4dCA9IHRoaXMuY29uZmlnLm9wdGlvbnNbX3ZhbHVlXS5kZXNjcmlwdGlvbiB8fCB0aGlzLmNvbmZpZy5vcHRpb25zW192YWx1ZV0udmFsdWUudG9TdHJpbmcoKTtcclxuICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICB0ZXh0ID0gdGhpcy5fc2xpZGVyU3ZjLmNhbGN1bGF0ZUxhYmVsVmFsdWUoX3ZhbHVlKTtcclxuICAgICAgICB9XHJcbiAgICAgICAgcmV0dXJuIHRoaXMuX3NsaWRlclN2Yy5nZXRMYWJlbEZvcm1hdFJlcGxhY2UodGV4dCwgdGhpcy5jb25maWcudG9vbHRpcEZvcm1hdCk7XHJcbiAgICB9XHJcblxyXG4gICAgLyoqIExvZ2ljIGZvciB0b29sdGlwIHNob3dpbmcgYW5kIGhpZGluZyAqL1xyXG4gICAgcHJpdmF0ZSBfdG9vbHRpcEFwcGVhckNvbnRyb2woX2ZsYWc6ICdhbGwgc2hvdycgfCAnYWxsIGhpZGUnIHwgJ3Nob3cgc2VsZWN0ZWQnIHwgJ2hpZGUgc2VsZWN0ZWQnKTogdm9pZCB7XHJcbiAgICAgICAgbGV0IGl0ZXJhdGlvbnM6IG51bWJlciA9IHRoaXMuY29uZmlnLnJhbmdlID8gMiA6IDE7XHJcbiAgICAgICAgc3dpdGNoIChfZmxhZykge1xyXG4gICAgICAgICAgICBjYXNlICdhbGwgc2hvdyc6XHJcbiAgICAgICAgICAgICAgICBmb3IgKGxldCBpID0gMDsgaSA8IGl0ZXJhdGlvbnM7ICsraSkge1xyXG4gICAgICAgICAgICAgICAgICAgIGlmICghdGhpcy5fdG9vbHRpcEFwcGVhcmVkW2ldKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMudG9vbHRpcEFwaVtpXS5zaG93VG9vbHRpcCgpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLl90b29sdGlwQXBwZWFyZWRbaV0gPSB0cnVlO1xyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgICAgICBjYXNlICdhbGwgaGlkZSc6XHJcbiAgICAgICAgICAgICAgICBmb3IgKGxldCBpID0gMDsgaSA8IGl0ZXJhdGlvbnM7ICsraSkge1xyXG4gICAgICAgICAgICAgICAgICAgIGlmICh0aGlzLl90b29sdGlwQXBwZWFyZWRbaV0pIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy50b29sdGlwQXBpW2ldLmhpZGVUb29sdGlwKCk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuX3Rvb2x0aXBBcHBlYXJlZFtpXSA9IGZhbHNlO1xyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgICAgICBjYXNlICdzaG93IHNlbGVjdGVkJzpcclxuICAgICAgICAgICAgICAgIGlmICghdGhpcy5fdG9vbHRpcEFwcGVhcmVkW3RoaXMuc2VsZWN0ZWRUaHVtYkluZGV4XSkge1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMudG9vbHRpcEFwaVt0aGlzLnNlbGVjdGVkVGh1bWJJbmRleF0uc2hvd1Rvb2x0aXAoKTtcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLl90b29sdGlwQXBwZWFyZWRbdGhpcy5zZWxlY3RlZFRodW1iSW5kZXhdID0gdHJ1ZTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgICAgICBjYXNlICdoaWRlIHNlbGVjdGVkJzpcclxuICAgICAgICAgICAgICAgIGlmICh0aGlzLl90b29sdGlwQXBwZWFyZWRbdGhpcy5zZWxlY3RlZFRodW1iSW5kZXhdKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy50b29sdGlwQXBpW3RoaXMuc2VsZWN0ZWRUaHVtYkluZGV4XS5oaWRlVG9vbHRpcCgpO1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuX3Rvb2x0aXBBcHBlYXJlZFt0aGlzLnNlbGVjdGVkVGh1bWJJbmRleF0gPSBmYWxzZTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICAvKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqL1xyXG4gICAgLyogQXBpXHJcbiAgICAvKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqL1xyXG5cclxuICAgIHByaXZhdGUgX2luaXRBcGkoKTogdm9pZCB7XHJcbiAgICAgICAgaWYgKHR5cGVvZiB0aGlzLmFwaSAhPT0gJ3VuZGVmaW5lZCcpIHtcclxuICAgICAgICAgICAgdGhpcy5hcGkuaGFuZGxlVmFsdWUgPSAoX3ZhbHVlOiBudW1iZXIsIGluZGV4PzogbnVtYmVyKSA9PiB7XHJcbiAgICAgICAgICAgICAgICBpZiAodHlwZW9mIGluZGV4ICE9PSAndW5kZWZpbmVkJykge1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuc2VsZWN0ZWRUaHVtYkluZGV4ID0gaW5kZXg7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy52YWx1ZVtpbmRleF0gPSBfdmFsdWU7XHJcbiAgICAgICAgICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMudmFsdWUgPSBfdmFsdWU7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICB0aGlzLl9oYW5kbGVWYWx1ZShudWxsLCBfdmFsdWUpO1xyXG4gICAgICAgICAgICAgICAgdGhpcy5fZW1pdENoYW5nZUV2ZW50KCk7XHJcbiAgICAgICAgICAgIH07XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIC8qKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKiovXHJcbiAgICAvKiBIZWxwZXIgZnVuY3Rpb25zIGZvciBzZXR0aW5nIHZhbHVlc1xyXG4gICAgLyoqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKi9cclxuXHJcbiAgICAvKipcclxuICAgICogR2V0IHRoZSBib3VuZGluZyBjbGllbnQgcmVjdCBvZiB0aGUgc2xpZGVyIHRyYWNrIGVsZW1lbnQuXHJcbiAgICAqIFRoZSB0cmFjayBpcyB1c2VkIHJhdGhlciB0aGFuIHRoZSBuYXRpdmUgZWxlbWVudCB0byBpZ25vcmUgdGhlIGV4dHJhIHNwYWNlIHRoYXQgdGhlIHRodW1iIGNhblxyXG4gICAgKiB0YWtlIHVwLlxyXG4gICAgKi9cclxuICAgIHByaXZhdGUgX2dldFNsaWRlckRpbWVuc2lvbnMoKSB7XHJcbiAgICAgICAgcmV0dXJuIHRoaXMuX3NsaWRlcldyYXBwZXIgPyB0aGlzLl9zbGlkZXJXcmFwcGVyLm5hdGl2ZUVsZW1lbnQuZ2V0Qm91bmRpbmdDbGllbnRSZWN0KCkgOiBudWxsO1xyXG4gICAgfVxyXG5cclxufVxyXG4iXX0=