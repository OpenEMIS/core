import { Component, Input, EventEmitter, Output, } from '@angular/core';
import { KdSliderSvc } from './kd-angular-slider-svc';
export class KdSlider {
    constructor(_sliderSvc) {
        this._sliderSvc = _sliderSvc;
        this.config = {};
        this.value = 0;
        this.isPlay = false;
        this.wrapperStyle = {};
        this.apiInternal = {};
        this._defaultConfig = {
            orientation: 'horizontal',
            range: false,
            max: 100,
            min: 0,
            step: 1,
            disabled: false,
            autoplay: false,
            autoplayStep: 1,
        };
        this.sliderValue = 0;
        this.result = new EventEmitter();
    }
    ngOnInit() {
        this._setConfig(this.sliderConfig);
        this.value = this._setData(this.sliderValue, this.config);
        this._outputValue = this.value;
        this.sliderId = typeof this.id !== 'undefined' ? this.id : 'slider';
        this._initApi();
    }
    ngOnChanges(_simpleChanges) {
        if (_simpleChanges.hasOwnProperty('sliderConfig') && !_simpleChanges['sliderConfig'].firstChange) {
            if (_simpleChanges['sliderConfig'].currentValue === this.config)
                return;
            this._setConfig(_simpleChanges['sliderConfig'].currentValue);
        }
        if (_simpleChanges.hasOwnProperty('sliderValue') && !_simpleChanges['sliderValue'].firstChange) {
            if (_simpleChanges['sliderValue'].currentValue === this.value)
                return;
            this.value = this._setData(_simpleChanges['sliderValue'].currentValue, this.config);
            this._outputValue = this.value;
        }
        if (_simpleChanges.hasOwnProperty('id') && !_simpleChanges['id'].firstChange) {
            if (_simpleChanges['id'].currentValue === this.sliderId)
                return;
            this.sliderId = typeof _simpleChanges['id'].currentValue !== 'undefined' ? _simpleChanges['id'].currentValue : 'slider';
        }
    }
    /** Emits a change event if the current value is different from the last emitted value. */
    emitChangeEvent(_result) {
        /**type === number | Array<number> | Object with at least the following properties:
        * {
        *   description?: string;
        *   value: string | number;
        * }
        * */
        this._outputValue = this.config.type && this.config.type === 'others' ? this.config.options[Math.round(_result.value)] : _result.value;
        if (_result.currentAction !== 'sliding')
            this.result.emit(this._outputValue);
        this.sideValueLabel = this._sliderSvc.setSideValueLabel(this._outputValue, this.config.sideValueLabelFormat);
    }
    /** Toggle autoplay */
    clickPlayBtn() {
        if (this.config.disabled)
            return;
        this.isPlay = this.isPlay ? false : true;
    }
    /** Update this.isPlay when end of slider is reached */
    endPlay(_end) {
        this.isPlay = _end ? false : true;
    }
    _initApi() {
        if (typeof this.api !== 'undefined') {
            this.api.disable = (_flag) => {
                this.config = Object.assign({}, this.config, { disabled: _flag });
            };
            this.api.getSliderThumbValue = () => {
                return this._outputValue;
            };
            this.api.setSliderThumbValue = (_value, _thumbIndex) => {
                let valueToUpdate = _value;
                if (Array.isArray(_value)) {
                    if (typeof _thumbIndex === 'undefined') {
                        console.log('please pass the _thumbIndex of which to update value to');
                        return;
                    }
                    valueToUpdate = _value[_thumbIndex];
                }
                if (this.config.type === 'others') {
                    for (let i = 0; i < this.sliderValue.length; ++i) {
                        if (this.sliderValue[i].value === _value.value) {
                            valueToUpdate = i;
                            break;
                        }
                    }
                }
                this.apiInternal.handleValue(valueToUpdate, _thumbIndex);
            };
        }
    }
    _setConfig(_config) {
        this.config = Object.assign({}, this._defaultConfig, _config);
        if (this.config.width)
            this.wrapperStyle = { 'width': this.config.width };
        this._sliderSvc.config = this.config;
        this.sideValueLabel = this._sliderSvc.setSideValueLabel(this.sliderValue, this.config.sideValueLabelFormat);
    }
    _setData(_value, _config) {
        if (_config.type === 'others') {
            let newValue;
            this.config.max = _config.options.length - 1;
            this.config.step = 1;
            this.config.min = 0;
            this._sliderSvc.config = this.config;
            for (let i = 0; i < _config.options.length; ++i) {
                if (_config.options[i].value === _value.value) {
                    newValue = i;
                    break;
                }
            }
            return newValue || 0;
        }
        if (!Array.isArray(_value)) {
            this.config.range = false;
            this._sliderSvc.config = this.config;
            return _value;
        }
        if (_config.range) {
            this.config.autoplay = false;
            let newValue = _value.map((el) => {
                if (typeof el !== 'number')
                    el = parseFloat(el);
                return this._sliderSvc.clamp(el, this.config.min, this.config.max);
            });
            return newValue;
        }
        return 0;
    }
}
KdSlider.decorators = [
    { type: Component, args: [{
                selector: 'kd-slider',
                template: `
        <div class="kdx-slider-wrapper" [id]="sliderId" [ngStyle]="wrapperStyle">
            <div class="kdx-slider-container" [ngClass]="{'kdx-slider-container-vertical': config.orientation === 'vertical'}">
                <button *ngIf="config.autoplay" class="btn" (click)="clickPlayBtn()" [attr.disabled]="config.disabled? '': null">
                    <i class="play-icon fa" aria-hidden="true" [ngClass]="{'fa-play': !isPlay, 'fa-pause': isPlay}"></i>
                </button>
                <kd-slider-content [value]="value"
                                   [config]="config"
                                   [isPlay]="isPlay"
                                   [api]="apiInternal"
                                   (endPlay)="endPlay($event)"
                                   (result)="emitChangeEvent($event)">
                </kd-slider-content>
                <div *ngIf="config.sideValueLabel" class="side-value-label kdx-label">{{sideValueLabel}}</div>
            </div>
            <div *ngIf="config.startLabel" class="kdx-label-container">
                <div *ngIf="config.startLabel" class="kdx-label" >
                    {{config.startLabel}}
                </div>
                <div *ngIf="config.endLabel" class="kdx-label" >
                    {{config.endLabel}}
                </div>
            </div>
           <ng-content></ng-content>
        </div>
    `,
                providers: [KdSliderSvc],
                host: {
                    'class': 'kdx-slider',
                    '[class.kdx-slider-has-start-label]': 'config.startLabel',
                }
            },] }
];
KdSlider.ctorParameters = () => [
    { type: KdSliderSvc }
];
KdSlider.propDecorators = {
    id: [{ type: Input }],
    sliderValue: [{ type: Input, args: ['value',] }],
    sliderConfig: [{ type: Input, args: ['config',] }],
    api: [{ type: Input }],
    result: [{ type: Output }]
};
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoia2QtYW5ndWxhci1zbGlkZXIuanMiLCJzb3VyY2VSb290IjoiQzoveGFtcHAvaHRkb2NzL1N0eWxlZ3VpZGUvaW9zdGctb3BlbmVtaXMtc3R5bGVndWlkZS9wcm9qZWN0cy9vcGVuZW1pcy1zdHlsZWd1aWRlLWxpYi9zcmMvIiwic291cmNlcyI6WyJrZC1jb21wb25lbnRzL2tkLWFuZ3VsYXItc2xpZGVyL2tkLWFuZ3VsYXItc2xpZGVyLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBLE9BQU8sRUFDSCxTQUFTLEVBQ1QsS0FBSyxFQUlMLFlBQVksRUFDWixNQUFNLEdBQ1QsTUFBTSxlQUFlLENBQUM7QUFDdkIsT0FBTyxFQUFFLFdBQVcsRUFBRSxNQUFNLHlCQUF5QixDQUFDO0FBMEN0RCxNQUFNLE9BQU8sUUFBUTtJQTRCakIsWUFBb0IsVUFBdUI7UUFBdkIsZUFBVSxHQUFWLFVBQVUsQ0FBYTtRQTFCcEMsV0FBTSxHQUFrQixFQUFFLENBQUM7UUFDM0IsVUFBSyxHQUFRLENBQUMsQ0FBQztRQUNmLFdBQU0sR0FBWSxLQUFLLENBQUM7UUFFeEIsaUJBQVksR0FBOEIsRUFBRSxDQUFDO1FBRTdDLGdCQUFXLEdBQXVCLEVBQUUsQ0FBQztRQUVwQyxtQkFBYyxHQUFrQjtZQUNwQyxXQUFXLEVBQUUsWUFBWTtZQUN6QixLQUFLLEVBQUUsS0FBSztZQUNaLEdBQUcsRUFBRSxHQUFHO1lBQ1IsR0FBRyxFQUFFLENBQUM7WUFDTixJQUFJLEVBQUUsQ0FBQztZQUNQLFFBQVEsRUFBRSxLQUFLO1lBQ2YsUUFBUSxFQUFFLEtBQUs7WUFDZixZQUFZLEVBQUUsQ0FBQztTQUNsQixDQUFDO1FBSWMsZ0JBQVcsR0FBUSxDQUFDLENBQUM7UUFHM0IsV0FBTSxHQUFxQixJQUFJLFlBQVksRUFBRSxDQUFDO0lBRVQsQ0FBQztJQUVoRCxRQUFRO1FBQ0osSUFBSSxDQUFDLFVBQVUsQ0FBQyxJQUFJLENBQUMsWUFBWSxDQUFDLENBQUM7UUFDbkMsSUFBSSxDQUFDLEtBQUssR0FBRyxJQUFJLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxXQUFXLEVBQUUsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDO1FBQzFELElBQUksQ0FBQyxZQUFZLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQztRQUMvQixJQUFJLENBQUMsUUFBUSxHQUFHLE9BQU8sSUFBSSxDQUFDLEVBQUUsS0FBSyxXQUFXLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQztRQUNwRSxJQUFJLENBQUMsUUFBUSxFQUFFLENBQUM7SUFDcEIsQ0FBQztJQUVELFdBQVcsQ0FBQyxjQUE2QjtRQUNyQyxJQUFJLGNBQWMsQ0FBQyxjQUFjLENBQUMsY0FBYyxDQUFDLElBQUksQ0FBQyxjQUFjLENBQUMsY0FBYyxDQUFDLENBQUMsV0FBVyxFQUFFO1lBQzlGLElBQUksY0FBYyxDQUFDLGNBQWMsQ0FBQyxDQUFDLFlBQVksS0FBSyxJQUFJLENBQUMsTUFBTTtnQkFBRSxPQUFPO1lBQ3hFLElBQUksQ0FBQyxVQUFVLENBQUMsY0FBYyxDQUFDLGNBQWMsQ0FBQyxDQUFDLFlBQVksQ0FBQyxDQUFDO1NBQ2hFO1FBQ0QsSUFBSSxjQUFjLENBQUMsY0FBYyxDQUFDLGFBQWEsQ0FBQyxJQUFJLENBQUMsY0FBYyxDQUFDLGFBQWEsQ0FBQyxDQUFDLFdBQVcsRUFBRTtZQUM1RixJQUFJLGNBQWMsQ0FBQyxhQUFhLENBQUMsQ0FBQyxZQUFZLEtBQUssSUFBSSxDQUFDLEtBQUs7Z0JBQUUsT0FBTztZQUN0RSxJQUFJLENBQUMsS0FBSyxHQUFHLElBQUksQ0FBQyxRQUFRLENBQUMsY0FBYyxDQUFDLGFBQWEsQ0FBQyxDQUFDLFlBQVksRUFBRSxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUM7WUFDcEYsSUFBSSxDQUFDLFlBQVksR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDO1NBQ2xDO1FBQ0QsSUFBSSxjQUFjLENBQUMsY0FBYyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsY0FBYyxDQUFDLElBQUksQ0FBQyxDQUFDLFdBQVcsRUFBRTtZQUMxRSxJQUFJLGNBQWMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxZQUFZLEtBQUssSUFBSSxDQUFDLFFBQVE7Z0JBQUUsT0FBTztZQUNoRSxJQUFJLENBQUMsUUFBUSxHQUFHLE9BQU8sY0FBYyxDQUFDLElBQUksQ0FBQyxDQUFDLFlBQVksS0FBSyxXQUFXLENBQUMsQ0FBQyxDQUFDLGNBQWMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxZQUFZLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQztTQUMzSDtJQUNMLENBQUM7SUFFRCwwRkFBMEY7SUFDbkYsZUFBZSxDQUFDLE9BQWtEO1FBQ3JFOzs7OztZQUtJO1FBQ0osSUFBSSxDQUFDLFlBQVksR0FBRyxJQUFJLENBQUMsTUFBTSxDQUFDLElBQUksSUFBSSxJQUFJLENBQUMsTUFBTSxDQUFDLElBQUksS0FBSyxRQUFRLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxLQUFLLENBQUM7UUFDdkksSUFBSSxPQUFPLENBQUMsYUFBYSxLQUFLLFNBQVM7WUFBRSxJQUFJLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsWUFBWSxDQUFDLENBQUM7UUFDN0UsSUFBSSxDQUFDLGNBQWMsR0FBRyxJQUFJLENBQUMsVUFBVSxDQUFDLGlCQUFpQixDQUFDLElBQUksQ0FBQyxZQUFZLEVBQUUsSUFBSSxDQUFDLE1BQU0sQ0FBQyxvQkFBb0IsQ0FBQyxDQUFDO0lBQ2pILENBQUM7SUFFRCxzQkFBc0I7SUFDZixZQUFZO1FBQ2YsSUFBSSxJQUFJLENBQUMsTUFBTSxDQUFDLFFBQVE7WUFBRSxPQUFPO1FBQ2pDLElBQUksQ0FBQyxNQUFNLEdBQUcsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUM7SUFDN0MsQ0FBQztJQUVELHVEQUF1RDtJQUNoRCxPQUFPLENBQUMsSUFBYTtRQUN4QixJQUFJLENBQUMsTUFBTSxHQUFHLElBQUksQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUM7SUFDdEMsQ0FBQztJQUdPLFFBQVE7UUFDWixJQUFJLE9BQU8sSUFBSSxDQUFDLEdBQUcsS0FBSyxXQUFXLEVBQUU7WUFDakMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxPQUFPLEdBQUcsQ0FBQyxLQUFjLEVBQUUsRUFBRTtnQkFDbEMsSUFBSSxDQUFDLE1BQU0sR0FBRyxNQUFNLENBQUMsTUFBTSxDQUFDLEVBQUUsRUFBRSxJQUFJLENBQUMsTUFBTSxFQUFFLEVBQUUsUUFBUSxFQUFFLEtBQUssRUFBRSxDQUFDLENBQUM7WUFDdEUsQ0FBQyxDQUFDO1lBQ0YsSUFBSSxDQUFDLEdBQUcsQ0FBQyxtQkFBbUIsR0FBRyxHQUFHLEVBQUU7Z0JBQ2hDLE9BQU8sSUFBSSxDQUFDLFlBQVksQ0FBQztZQUM3QixDQUFDLENBQUM7WUFDRixJQUFJLENBQUMsR0FBRyxDQUFDLG1CQUFtQixHQUFHLENBQUMsTUFBVyxFQUFFLFdBQW9CLEVBQUUsRUFBRTtnQkFDakUsSUFBSSxhQUFhLEdBQVEsTUFBTSxDQUFDO2dCQUNoQyxJQUFJLEtBQUssQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLEVBQUU7b0JBQ3ZCLElBQUksT0FBTyxXQUFXLEtBQUssV0FBVyxFQUFFO3dCQUNwQyxPQUFPLENBQUMsR0FBRyxDQUFDLHlEQUF5RCxDQUFDLENBQUM7d0JBQ3ZFLE9BQU87cUJBQ1Y7b0JBQ0QsYUFBYSxHQUFHLE1BQU0sQ0FBQyxXQUFXLENBQUMsQ0FBQztpQkFDdkM7Z0JBRUQsSUFBSSxJQUFJLENBQUMsTUFBTSxDQUFDLElBQUksS0FBSyxRQUFRLEVBQUU7b0JBQy9CLEtBQUssSUFBSSxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsR0FBRyxJQUFJLENBQUMsV0FBVyxDQUFDLE1BQU0sRUFBRSxFQUFFLENBQUMsRUFBRTt3QkFDOUMsSUFBSSxJQUFJLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssS0FBSyxNQUFNLENBQUMsS0FBSyxFQUFFOzRCQUM1QyxhQUFhLEdBQUcsQ0FBQyxDQUFDOzRCQUNsQixNQUFNO3lCQUNUO3FCQUNKO2lCQUNKO2dCQUVELElBQUksQ0FBQyxXQUFXLENBQUMsV0FBVyxDQUFDLGFBQWEsRUFBRSxXQUFXLENBQUMsQ0FBQztZQUM3RCxDQUFDLENBQUM7U0FDTDtJQUNMLENBQUM7SUFFTyxVQUFVLENBQUMsT0FBTztRQUN0QixJQUFJLENBQUMsTUFBTSxHQUFHLE1BQU0sQ0FBQyxNQUFNLENBQUMsRUFBRSxFQUFFLElBQUksQ0FBQyxjQUFjLEVBQUUsT0FBTyxDQUFDLENBQUM7UUFDOUQsSUFBSSxJQUFJLENBQUMsTUFBTSxDQUFDLEtBQUs7WUFBRSxJQUFJLENBQUMsWUFBWSxHQUFHLEVBQUUsT0FBTyxFQUFFLElBQUksQ0FBQyxNQUFNLENBQUMsS0FBSyxFQUFFLENBQUM7UUFDMUUsSUFBSSxDQUFDLFVBQVUsQ0FBQyxNQUFNLEdBQUcsSUFBSSxDQUFDLE1BQU0sQ0FBQztRQUNyQyxJQUFJLENBQUMsY0FBYyxHQUFHLElBQUksQ0FBQyxVQUFVLENBQUMsaUJBQWlCLENBQUMsSUFBSSxDQUFDLFdBQVcsRUFBRSxJQUFJLENBQUMsTUFBTSxDQUFDLG9CQUFvQixDQUFDLENBQUM7SUFDaEgsQ0FBQztJQUVPLFFBQVEsQ0FBQyxNQUFNLEVBQUUsT0FBTztRQUU1QixJQUFJLE9BQU8sQ0FBQyxJQUFJLEtBQUssUUFBUSxFQUFFO1lBQzNCLElBQUksUUFBZ0IsQ0FBQztZQUNyQixJQUFJLENBQUMsTUFBTSxDQUFDLEdBQUcsR0FBRyxPQUFPLENBQUMsT0FBTyxDQUFDLE1BQU0sR0FBRyxDQUFDLENBQUM7WUFDN0MsSUFBSSxDQUFDLE1BQU0sQ0FBQyxJQUFJLEdBQUcsQ0FBQyxDQUFDO1lBQ3JCLElBQUksQ0FBQyxNQUFNLENBQUMsR0FBRyxHQUFHLENBQUMsQ0FBQztZQUNwQixJQUFJLENBQUMsVUFBVSxDQUFDLE1BQU0sR0FBRyxJQUFJLENBQUMsTUFBTSxDQUFDO1lBRXJDLEtBQUssSUFBSSxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsR0FBRyxPQUFPLENBQUMsT0FBTyxDQUFDLE1BQU0sRUFBRSxFQUFFLENBQUMsRUFBRTtnQkFDN0MsSUFBSSxPQUFPLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssS0FBSyxNQUFNLENBQUMsS0FBSyxFQUFFO29CQUMzQyxRQUFRLEdBQUcsQ0FBQyxDQUFDO29CQUNiLE1BQU07aUJBQ1Q7YUFDSjtZQUNELE9BQU8sUUFBUSxJQUFJLENBQUMsQ0FBQztTQUN4QjtRQUVELElBQUksQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxFQUFFO1lBQ3hCLElBQUksQ0FBQyxNQUFNLENBQUMsS0FBSyxHQUFHLEtBQUssQ0FBQztZQUMxQixJQUFJLENBQUMsVUFBVSxDQUFDLE1BQU0sR0FBRyxJQUFJLENBQUMsTUFBTSxDQUFDO1lBQ3JDLE9BQU8sTUFBTSxDQUFDO1NBQ2pCO1FBRUQsSUFBSSxPQUFPLENBQUMsS0FBSyxFQUFFO1lBQ2YsSUFBSSxDQUFDLE1BQU0sQ0FBQyxRQUFRLEdBQUcsS0FBSyxDQUFDO1lBQzdCLElBQUksUUFBUSxHQUFHLE1BQU0sQ0FBQyxHQUFHLENBQUMsQ0FBQyxFQUFFLEVBQUUsRUFBRTtnQkFDN0IsSUFBSSxPQUFPLEVBQUUsS0FBSyxRQUFRO29CQUFFLEVBQUUsR0FBRyxVQUFVLENBQUMsRUFBRSxDQUFDLENBQUM7Z0JBQ2hELE9BQU8sSUFBSSxDQUFDLFVBQVUsQ0FBQyxLQUFLLENBQUMsRUFBRSxFQUFFLElBQUksQ0FBQyxNQUFNLENBQUMsR0FBRyxFQUFFLElBQUksQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLENBQUM7WUFDdkUsQ0FBQyxDQUFDLENBQUM7WUFDSCxPQUFPLFFBQVEsQ0FBQztTQUNuQjtRQUVELE9BQU8sQ0FBQyxDQUFDO0lBQ2IsQ0FBQzs7O1lBM0xKLFNBQVMsU0FBQztnQkFDUCxRQUFRLEVBQUUsV0FBVztnQkFDckIsUUFBUSxFQUFFOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0tBeUJUO2dCQUNELFNBQVMsRUFBRSxDQUFDLFdBQVcsQ0FBQztnQkFDeEIsSUFBSSxFQUFFO29CQUNGLE9BQU8sRUFBRSxZQUFZO29CQUNyQixvQ0FBb0MsRUFBRSxtQkFBbUI7aUJBQzVEO2FBQ0o7OztZQXhDUSxXQUFXOzs7aUJBZ0VmLEtBQUs7MEJBQ0wsS0FBSyxTQUFDLE9BQU87MkJBQ2IsS0FBSyxTQUFDLFFBQVE7a0JBQ2QsS0FBSztxQkFDTCxNQUFNIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHtcclxuICAgIENvbXBvbmVudCxcclxuICAgIElucHV0LFxyXG4gICAgT25Jbml0LFxyXG4gICAgT25DaGFuZ2VzLFxyXG4gICAgU2ltcGxlQ2hhbmdlcyxcclxuICAgIEV2ZW50RW1pdHRlcixcclxuICAgIE91dHB1dCxcclxufSBmcm9tICdAYW5ndWxhci9jb3JlJztcclxuaW1wb3J0IHsgS2RTbGlkZXJTdmMgfSBmcm9tICcuL2tkLWFuZ3VsYXItc2xpZGVyLXN2Yyc7XHJcbmltcG9ydCB7XHJcbiAgICBJU2xpZGVyQXBpLFxyXG4gICAgSVNsaWRlckNvbmZpZyxcclxuICAgIElTbGlkZXJBcGlJbnRlcm5hbFxyXG59IGZyb20gJy4va2QtYW5ndWxhci1zbGlkZXItaW50ZXJmYWNlJztcclxuXHJcbkBDb21wb25lbnQoe1xyXG4gICAgc2VsZWN0b3I6ICdrZC1zbGlkZXInLFxyXG4gICAgdGVtcGxhdGU6IGBcclxuICAgICAgICA8ZGl2IGNsYXNzPVwia2R4LXNsaWRlci13cmFwcGVyXCIgW2lkXT1cInNsaWRlcklkXCIgW25nU3R5bGVdPVwid3JhcHBlclN0eWxlXCI+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJrZHgtc2xpZGVyLWNvbnRhaW5lclwiIFtuZ0NsYXNzXT1cInsna2R4LXNsaWRlci1jb250YWluZXItdmVydGljYWwnOiBjb25maWcub3JpZW50YXRpb24gPT09ICd2ZXJ0aWNhbCd9XCI+XHJcbiAgICAgICAgICAgICAgICA8YnV0dG9uICpuZ0lmPVwiY29uZmlnLmF1dG9wbGF5XCIgY2xhc3M9XCJidG5cIiAoY2xpY2spPVwiY2xpY2tQbGF5QnRuKClcIiBbYXR0ci5kaXNhYmxlZF09XCJjb25maWcuZGlzYWJsZWQ/ICcnOiBudWxsXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPGkgY2xhc3M9XCJwbGF5LWljb24gZmFcIiBhcmlhLWhpZGRlbj1cInRydWVcIiBbbmdDbGFzc109XCJ7J2ZhLXBsYXknOiAhaXNQbGF5LCAnZmEtcGF1c2UnOiBpc1BsYXl9XCI+PC9pPlxyXG4gICAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgICA8a2Qtc2xpZGVyLWNvbnRlbnQgW3ZhbHVlXT1cInZhbHVlXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBbY29uZmlnXT1cImNvbmZpZ1wiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgW2lzUGxheV09XCJpc1BsYXlcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFthcGldPVwiYXBpSW50ZXJuYWxcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIChlbmRQbGF5KT1cImVuZFBsYXkoJGV2ZW50KVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKHJlc3VsdCk9XCJlbWl0Q2hhbmdlRXZlbnQoJGV2ZW50KVwiPlxyXG4gICAgICAgICAgICAgICAgPC9rZC1zbGlkZXItY29udGVudD5cclxuICAgICAgICAgICAgICAgIDxkaXYgKm5nSWY9XCJjb25maWcuc2lkZVZhbHVlTGFiZWxcIiBjbGFzcz1cInNpZGUtdmFsdWUtbGFiZWwga2R4LWxhYmVsXCI+e3tzaWRlVmFsdWVMYWJlbH19PC9kaXY+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8ZGl2ICpuZ0lmPVwiY29uZmlnLnN0YXJ0TGFiZWxcIiBjbGFzcz1cImtkeC1sYWJlbC1jb250YWluZXJcIj5cclxuICAgICAgICAgICAgICAgIDxkaXYgKm5nSWY9XCJjb25maWcuc3RhcnRMYWJlbFwiIGNsYXNzPVwia2R4LWxhYmVsXCIgPlxyXG4gICAgICAgICAgICAgICAgICAgIHt7Y29uZmlnLnN0YXJ0TGFiZWx9fVxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8ZGl2ICpuZ0lmPVwiY29uZmlnLmVuZExhYmVsXCIgY2xhc3M9XCJrZHgtbGFiZWxcIiA+XHJcbiAgICAgICAgICAgICAgICAgICAge3tjb25maWcuZW5kTGFiZWx9fVxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgIDxuZy1jb250ZW50PjwvbmctY29udGVudD5cclxuICAgICAgICA8L2Rpdj5cclxuICAgIGAsXHJcbiAgICBwcm92aWRlcnM6IFtLZFNsaWRlclN2Y10sXHJcbiAgICBob3N0OiB7XHJcbiAgICAgICAgJ2NsYXNzJzogJ2tkeC1zbGlkZXInLFxyXG4gICAgICAgICdbY2xhc3Mua2R4LXNsaWRlci1oYXMtc3RhcnQtbGFiZWxdJzogJ2NvbmZpZy5zdGFydExhYmVsJyxcclxuICAgIH1cclxufSlcclxuXHJcbmV4cG9ydCBjbGFzcyBLZFNsaWRlciBpbXBsZW1lbnRzIE9uSW5pdCwgT25DaGFuZ2VzIHtcclxuXHJcbiAgICBwdWJsaWMgY29uZmlnOiBJU2xpZGVyQ29uZmlnID0ge307XHJcbiAgICBwdWJsaWMgdmFsdWU6IGFueSA9IDA7XHJcbiAgICBwdWJsaWMgaXNQbGF5OiBib29sZWFuID0gZmFsc2U7XHJcbiAgICBwdWJsaWMgc2xpZGVySWQ6IHN0cmluZztcclxuICAgIHB1YmxpYyB3cmFwcGVyU3R5bGU6IHsgW2tleTogc3RyaW5nXTogc3RyaW5nIH0gPSB7fTtcclxuICAgIHB1YmxpYyBzaWRlVmFsdWVMYWJlbDogc3RyaW5nIHwgbnVtYmVyO1xyXG4gICAgcHVibGljIGFwaUludGVybmFsOiBJU2xpZGVyQXBpSW50ZXJuYWwgPSB7fTtcclxuXHJcbiAgICBwcml2YXRlIF9kZWZhdWx0Q29uZmlnOiBJU2xpZGVyQ29uZmlnID0ge1xyXG4gICAgICAgIG9yaWVudGF0aW9uOiAnaG9yaXpvbnRhbCcsXHJcbiAgICAgICAgcmFuZ2U6IGZhbHNlLFxyXG4gICAgICAgIG1heDogMTAwLFxyXG4gICAgICAgIG1pbjogMCxcclxuICAgICAgICBzdGVwOiAxLFxyXG4gICAgICAgIGRpc2FibGVkOiBmYWxzZSxcclxuICAgICAgICBhdXRvcGxheTogZmFsc2UsXHJcbiAgICAgICAgYXV0b3BsYXlTdGVwOiAxLFxyXG4gICAgfTtcclxuICAgIHByaXZhdGUgX291dHB1dFZhbHVlOiBhbnk7XHJcblxyXG4gICAgQElucHV0KCkgaWQ6IHN0cmluZztcclxuICAgIEBJbnB1dCgndmFsdWUnKSBzbGlkZXJWYWx1ZTogYW55ID0gMDtcclxuICAgIEBJbnB1dCgnY29uZmlnJykgc2xpZGVyQ29uZmlnOiBJU2xpZGVyQ29uZmlnO1xyXG4gICAgQElucHV0KCkgYXBpOiBJU2xpZGVyQXBpO1xyXG4gICAgQE91dHB1dCgpIHJlc3VsdDogRXZlbnRFbWl0dGVyPHt9PiA9IG5ldyBFdmVudEVtaXR0ZXIoKTtcclxuXHJcbiAgICBjb25zdHJ1Y3Rvcihwcml2YXRlIF9zbGlkZXJTdmM6IEtkU2xpZGVyU3ZjKSB7IH1cclxuXHJcbiAgICBuZ09uSW5pdCgpOiB2b2lkIHtcclxuICAgICAgICB0aGlzLl9zZXRDb25maWcodGhpcy5zbGlkZXJDb25maWcpO1xyXG4gICAgICAgIHRoaXMudmFsdWUgPSB0aGlzLl9zZXREYXRhKHRoaXMuc2xpZGVyVmFsdWUsIHRoaXMuY29uZmlnKTtcclxuICAgICAgICB0aGlzLl9vdXRwdXRWYWx1ZSA9IHRoaXMudmFsdWU7XHJcbiAgICAgICAgdGhpcy5zbGlkZXJJZCA9IHR5cGVvZiB0aGlzLmlkICE9PSAndW5kZWZpbmVkJyA/IHRoaXMuaWQgOiAnc2xpZGVyJztcclxuICAgICAgICB0aGlzLl9pbml0QXBpKCk7XHJcbiAgICB9XHJcblxyXG4gICAgbmdPbkNoYW5nZXMoX3NpbXBsZUNoYW5nZXM6IFNpbXBsZUNoYW5nZXMpOiB2b2lkIHtcclxuICAgICAgICBpZiAoX3NpbXBsZUNoYW5nZXMuaGFzT3duUHJvcGVydHkoJ3NsaWRlckNvbmZpZycpICYmICFfc2ltcGxlQ2hhbmdlc1snc2xpZGVyQ29uZmlnJ10uZmlyc3RDaGFuZ2UpIHtcclxuICAgICAgICAgICAgaWYgKF9zaW1wbGVDaGFuZ2VzWydzbGlkZXJDb25maWcnXS5jdXJyZW50VmFsdWUgPT09IHRoaXMuY29uZmlnKSByZXR1cm47XHJcbiAgICAgICAgICAgIHRoaXMuX3NldENvbmZpZyhfc2ltcGxlQ2hhbmdlc1snc2xpZGVyQ29uZmlnJ10uY3VycmVudFZhbHVlKTtcclxuICAgICAgICB9XHJcbiAgICAgICAgaWYgKF9zaW1wbGVDaGFuZ2VzLmhhc093blByb3BlcnR5KCdzbGlkZXJWYWx1ZScpICYmICFfc2ltcGxlQ2hhbmdlc1snc2xpZGVyVmFsdWUnXS5maXJzdENoYW5nZSkge1xyXG4gICAgICAgICAgICBpZiAoX3NpbXBsZUNoYW5nZXNbJ3NsaWRlclZhbHVlJ10uY3VycmVudFZhbHVlID09PSB0aGlzLnZhbHVlKSByZXR1cm47XHJcbiAgICAgICAgICAgIHRoaXMudmFsdWUgPSB0aGlzLl9zZXREYXRhKF9zaW1wbGVDaGFuZ2VzWydzbGlkZXJWYWx1ZSddLmN1cnJlbnRWYWx1ZSwgdGhpcy5jb25maWcpO1xyXG4gICAgICAgICAgICB0aGlzLl9vdXRwdXRWYWx1ZSA9IHRoaXMudmFsdWU7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGlmIChfc2ltcGxlQ2hhbmdlcy5oYXNPd25Qcm9wZXJ0eSgnaWQnKSAmJiAhX3NpbXBsZUNoYW5nZXNbJ2lkJ10uZmlyc3RDaGFuZ2UpIHtcclxuICAgICAgICAgICAgaWYgKF9zaW1wbGVDaGFuZ2VzWydpZCddLmN1cnJlbnRWYWx1ZSA9PT0gdGhpcy5zbGlkZXJJZCkgcmV0dXJuO1xyXG4gICAgICAgICAgICB0aGlzLnNsaWRlcklkID0gdHlwZW9mIF9zaW1wbGVDaGFuZ2VzWydpZCddLmN1cnJlbnRWYWx1ZSAhPT0gJ3VuZGVmaW5lZCcgPyBfc2ltcGxlQ2hhbmdlc1snaWQnXS5jdXJyZW50VmFsdWUgOiAnc2xpZGVyJztcclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgLyoqIEVtaXRzIGEgY2hhbmdlIGV2ZW50IGlmIHRoZSBjdXJyZW50IHZhbHVlIGlzIGRpZmZlcmVudCBmcm9tIHRoZSBsYXN0IGVtaXR0ZWQgdmFsdWUuICovXHJcbiAgICBwdWJsaWMgZW1pdENoYW5nZUV2ZW50KF9yZXN1bHQ6IHsgdmFsdWU6IGFueSwgY3VycmVudEFjdGlvbj86ICdzbGlkaW5nJyB9KTogdm9pZCB7XHJcbiAgICAgICAgLyoqdHlwZSA9PT0gbnVtYmVyIHwgQXJyYXk8bnVtYmVyPiB8IE9iamVjdCB3aXRoIGF0IGxlYXN0IHRoZSBmb2xsb3dpbmcgcHJvcGVydGllczpcclxuICAgICAgICAqIHtcclxuICAgICAgICAqICAgZGVzY3JpcHRpb24/OiBzdHJpbmc7XHJcbiAgICAgICAgKiAgIHZhbHVlOiBzdHJpbmcgfCBudW1iZXI7XHJcbiAgICAgICAgKiB9XHJcbiAgICAgICAgKiAqL1xyXG4gICAgICAgIHRoaXMuX291dHB1dFZhbHVlID0gdGhpcy5jb25maWcudHlwZSAmJiB0aGlzLmNvbmZpZy50eXBlID09PSAnb3RoZXJzJyA/IHRoaXMuY29uZmlnLm9wdGlvbnNbTWF0aC5yb3VuZChfcmVzdWx0LnZhbHVlKV0gOiBfcmVzdWx0LnZhbHVlO1xyXG4gICAgICAgIGlmIChfcmVzdWx0LmN1cnJlbnRBY3Rpb24gIT09ICdzbGlkaW5nJykgdGhpcy5yZXN1bHQuZW1pdCh0aGlzLl9vdXRwdXRWYWx1ZSk7XHJcbiAgICAgICAgdGhpcy5zaWRlVmFsdWVMYWJlbCA9IHRoaXMuX3NsaWRlclN2Yy5zZXRTaWRlVmFsdWVMYWJlbCh0aGlzLl9vdXRwdXRWYWx1ZSwgdGhpcy5jb25maWcuc2lkZVZhbHVlTGFiZWxGb3JtYXQpO1xyXG4gICAgfVxyXG5cclxuICAgIC8qKiBUb2dnbGUgYXV0b3BsYXkgKi9cclxuICAgIHB1YmxpYyBjbGlja1BsYXlCdG4oKTogdm9pZCB7XHJcbiAgICAgICAgaWYgKHRoaXMuY29uZmlnLmRpc2FibGVkKSByZXR1cm47XHJcbiAgICAgICAgdGhpcy5pc1BsYXkgPSB0aGlzLmlzUGxheSA/IGZhbHNlIDogdHJ1ZTtcclxuICAgIH1cclxuXHJcbiAgICAvKiogVXBkYXRlIHRoaXMuaXNQbGF5IHdoZW4gZW5kIG9mIHNsaWRlciBpcyByZWFjaGVkICovXHJcbiAgICBwdWJsaWMgZW5kUGxheShfZW5kOiBib29sZWFuKTogdm9pZCB7XHJcbiAgICAgICAgdGhpcy5pc1BsYXkgPSBfZW5kID8gZmFsc2UgOiB0cnVlO1xyXG4gICAgfVxyXG5cclxuXHJcbiAgICBwcml2YXRlIF9pbml0QXBpKCk6IHZvaWQge1xyXG4gICAgICAgIGlmICh0eXBlb2YgdGhpcy5hcGkgIT09ICd1bmRlZmluZWQnKSB7XHJcbiAgICAgICAgICAgIHRoaXMuYXBpLmRpc2FibGUgPSAoX2ZsYWc6IGJvb2xlYW4pID0+IHtcclxuICAgICAgICAgICAgICAgIHRoaXMuY29uZmlnID0gT2JqZWN0LmFzc2lnbih7fSwgdGhpcy5jb25maWcsIHsgZGlzYWJsZWQ6IF9mbGFnIH0pO1xyXG4gICAgICAgICAgICB9O1xyXG4gICAgICAgICAgICB0aGlzLmFwaS5nZXRTbGlkZXJUaHVtYlZhbHVlID0gKCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgcmV0dXJuIHRoaXMuX291dHB1dFZhbHVlO1xyXG4gICAgICAgICAgICB9O1xyXG4gICAgICAgICAgICB0aGlzLmFwaS5zZXRTbGlkZXJUaHVtYlZhbHVlID0gKF92YWx1ZTogYW55LCBfdGh1bWJJbmRleD86IG51bWJlcikgPT4ge1xyXG4gICAgICAgICAgICAgICAgbGV0IHZhbHVlVG9VcGRhdGU6IGFueSA9IF92YWx1ZTtcclxuICAgICAgICAgICAgICAgIGlmIChBcnJheS5pc0FycmF5KF92YWx1ZSkpIHtcclxuICAgICAgICAgICAgICAgICAgICBpZiAodHlwZW9mIF90aHVtYkluZGV4ID09PSAndW5kZWZpbmVkJykge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBjb25zb2xlLmxvZygncGxlYXNlIHBhc3MgdGhlIF90aHVtYkluZGV4IG9mIHdoaWNoIHRvIHVwZGF0ZSB2YWx1ZSB0bycpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICByZXR1cm47XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIHZhbHVlVG9VcGRhdGUgPSBfdmFsdWVbX3RodW1iSW5kZXhdO1xyXG4gICAgICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgICAgIGlmICh0aGlzLmNvbmZpZy50eXBlID09PSAnb3RoZXJzJykge1xyXG4gICAgICAgICAgICAgICAgICAgIGZvciAobGV0IGkgPSAwOyBpIDwgdGhpcy5zbGlkZXJWYWx1ZS5sZW5ndGg7ICsraSkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAodGhpcy5zbGlkZXJWYWx1ZVtpXS52YWx1ZSA9PT0gX3ZhbHVlLnZhbHVlKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZVRvVXBkYXRlID0gaTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgICAgIHRoaXMuYXBpSW50ZXJuYWwuaGFuZGxlVmFsdWUodmFsdWVUb1VwZGF0ZSwgX3RodW1iSW5kZXgpO1xyXG4gICAgICAgICAgICB9O1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF9zZXRDb25maWcoX2NvbmZpZyk6IHZvaWQge1xyXG4gICAgICAgIHRoaXMuY29uZmlnID0gT2JqZWN0LmFzc2lnbih7fSwgdGhpcy5fZGVmYXVsdENvbmZpZywgX2NvbmZpZyk7XHJcbiAgICAgICAgaWYgKHRoaXMuY29uZmlnLndpZHRoKSB0aGlzLndyYXBwZXJTdHlsZSA9IHsgJ3dpZHRoJzogdGhpcy5jb25maWcud2lkdGggfTtcclxuICAgICAgICB0aGlzLl9zbGlkZXJTdmMuY29uZmlnID0gdGhpcy5jb25maWc7XHJcbiAgICAgICAgdGhpcy5zaWRlVmFsdWVMYWJlbCA9IHRoaXMuX3NsaWRlclN2Yy5zZXRTaWRlVmFsdWVMYWJlbCh0aGlzLnNsaWRlclZhbHVlLCB0aGlzLmNvbmZpZy5zaWRlVmFsdWVMYWJlbEZvcm1hdCk7XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfc2V0RGF0YShfdmFsdWUsIF9jb25maWcpOiBBcnJheTxudW1iZXI+IHwgbnVtYmVyIHtcclxuXHJcbiAgICAgICAgaWYgKF9jb25maWcudHlwZSA9PT0gJ290aGVycycpIHtcclxuICAgICAgICAgICAgbGV0IG5ld1ZhbHVlOiBudW1iZXI7XHJcbiAgICAgICAgICAgIHRoaXMuY29uZmlnLm1heCA9IF9jb25maWcub3B0aW9ucy5sZW5ndGggLSAxO1xyXG4gICAgICAgICAgICB0aGlzLmNvbmZpZy5zdGVwID0gMTtcclxuICAgICAgICAgICAgdGhpcy5jb25maWcubWluID0gMDtcclxuICAgICAgICAgICAgdGhpcy5fc2xpZGVyU3ZjLmNvbmZpZyA9IHRoaXMuY29uZmlnO1xyXG5cclxuICAgICAgICAgICAgZm9yIChsZXQgaSA9IDA7IGkgPCBfY29uZmlnLm9wdGlvbnMubGVuZ3RoOyArK2kpIHtcclxuICAgICAgICAgICAgICAgIGlmIChfY29uZmlnLm9wdGlvbnNbaV0udmFsdWUgPT09IF92YWx1ZS52YWx1ZSkge1xyXG4gICAgICAgICAgICAgICAgICAgIG5ld1ZhbHVlID0gaTtcclxuICAgICAgICAgICAgICAgICAgICBicmVhaztcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICByZXR1cm4gbmV3VmFsdWUgfHwgMDtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIGlmICghQXJyYXkuaXNBcnJheShfdmFsdWUpKSB7XHJcbiAgICAgICAgICAgIHRoaXMuY29uZmlnLnJhbmdlID0gZmFsc2U7XHJcbiAgICAgICAgICAgIHRoaXMuX3NsaWRlclN2Yy5jb25maWcgPSB0aGlzLmNvbmZpZztcclxuICAgICAgICAgICAgcmV0dXJuIF92YWx1ZTtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIGlmIChfY29uZmlnLnJhbmdlKSB7XHJcbiAgICAgICAgICAgIHRoaXMuY29uZmlnLmF1dG9wbGF5ID0gZmFsc2U7XHJcbiAgICAgICAgICAgIGxldCBuZXdWYWx1ZSA9IF92YWx1ZS5tYXAoKGVsKSA9PiB7XHJcbiAgICAgICAgICAgICAgICBpZiAodHlwZW9mIGVsICE9PSAnbnVtYmVyJykgZWwgPSBwYXJzZUZsb2F0KGVsKTtcclxuICAgICAgICAgICAgICAgIHJldHVybiB0aGlzLl9zbGlkZXJTdmMuY2xhbXAoZWwsIHRoaXMuY29uZmlnLm1pbiwgdGhpcy5jb25maWcubWF4KTtcclxuICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgIHJldHVybiBuZXdWYWx1ZTtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIHJldHVybiAwO1xyXG4gICAgfVxyXG59XHJcbiJdfQ==