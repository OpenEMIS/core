import { Injectable } from '@angular/core';
export class KdSliderSvc {
    /**
     * [config description] set config in service
     *  _config [description]
     */
    set config(_config) {
        this._config = _config;
    }
    /**
     * [direction description] set direction in service
     *  _direction [description]
     */
    set direction(_direction) {
        this._direction = _direction;
    }
    /**
     * [setSideValueLabel description] sets the value to show beside the slider
     *     _value [description] value to be emitted from kd-angular-slider
     *         [description] string to be passed to sideValueLabel HTML element
     */
    setSideValueLabel(_value, _format) {
        let finalLabel = '';
        if (!_value) {
            finalLabel = this._setDefaultValueForLabel();
        }
        else if (Array.isArray(_value)) {
            finalLabel = _value[0] + '-' + _value[1];
        }
        else if (typeof _value === 'object') {
            finalLabel = _value.value;
        }
        else {
            finalLabel = _value;
        }
        return this.getLabelFormatReplace(finalLabel, _format);
    }
    /**
     * [setTooltipPlacement description]
     *  _placement [description]
     *             [description]
     */
    setTooltipPlacement(_placement) {
        if (typeof _placement !== 'undefined')
            return _placement;
        if (this._config.orientation === 'vertical') {
            return 'left';
        }
        return 'top';
    }
    /**
     * [invertAxis description] check whether to invert axis when orientation is vertical
     *  [description]
     */
    invertAxis() {
        return this._config.orientation === 'vertical' ? true : false;
    }
    /**
     * [invertMouseCoords description] check whether to invert mouse coords when orientation is vertical and direction is rtl
     *  [description]
     */
    invertMouseCoords() {
        return (this._direction === 'rtl' && !(this._config.orientation === 'vertical')) ? !this.invertAxis() : this.invertAxis();
    }
    /**
     * [calculateRoundLabelTo description] decimal places to round value (to be emitted) and tooltip label to
     */
    calculateRoundLabelTo() {
        this._roundLabelTo = this._config.step.toString().split('.').pop().length;
    }
    /**
     * [checkValueConflict description] for range only. to check the first thumb value is not larger than the second thumb or the second thumb value is not lesser than first
     *   _currentValue [description]
     *   _otherValue   [description]
     *   _currentId    [description]
     *                [description]
     */
    checkValueConflict(_currentValue, _otherValue, _currentId) {
        switch (_currentId) {
            case 0:
                if (_currentValue > _otherValue)
                    return true;
                return false;
            case 1:
                if (_currentValue < _otherValue)
                    return true;
                return false;
            default:
                return false;
        }
    }
    /**
     * [clamp description] Return a number between two numbers.
     *  value [description]
     *  min   =             0 [description]
     *  max   =             1 [description]
     *        [description]
     */
    clamp(value, min = 0, max = 1) {
        return Math.max(min, Math.min(value, max));
    }
    /**
     * [calculateLabelValue description] calculate how many decimals to round the tooltip text to
     *  _value [description]
     *         [description]
     */
    calculateLabelValue(_value) {
        if (this._roundLabelTo && _value && _value % 1 !== 0) {
            return _value.toFixed(this._roundLabelTo);
        }
        else {
            return _value.toString() || '0';
        }
    }
    /**
     * [calculatePercentage description] Calculates the percentage of the slider that a value is.
     *         _value [description]
     *       [description]
     */
    calculatePercentage(_value) {
        return ((_value || 0) - this._config.min) / (this._config.max - this._config.min);
    }
    /**
     * [calculateValue description] Calculates the value a percentage of the slider corresponds to.
     *  _percentage [description]
     *              [description]
     */
    calculateValue(_percentage) {
        let exactValue = this.convertPercentToValue(_percentage);
        let closestValue = parseFloat((Math.round((exactValue - this._config.min) / this._config.step) * this._config.step).toFixed(this._roundLabelTo)) + this._config.min;
        return this.clamp(closestValue, this._config.min, this._config.max);
    }
    /**
     * takes in this.config.labelFormat and replaces {value} to text
     * _format {value} will be replaced by text
     * _text   value
     */
    getLabelFormatReplace(_text, _format) {
        return _format ? _format.replace(/{value}/g, _text) : _text;
    }
    /**
     * [convertPercentToValue description] Converts percent of the slider to value (not rounded)
     *  _percentage [description]
     *              [description]
     */
    convertPercentToValue(_percentage) {
        return this._config.min + _percentage * (this._config.max - this._config.min);
    }
    /**
     * [_setDefaultValueForLabel description]
     *  [description]
     */
    _setDefaultValueForLabel() {
        if (this._config.type === 'others')
            return this._config.options[0];
        if (this._config.range)
            this._config.range = false;
        return 0;
    }
}
KdSliderSvc.decorators = [
    { type: Injectable }
];
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoia2QtYW5ndWxhci1zbGlkZXItc3ZjLmpzIiwic291cmNlUm9vdCI6IkM6L3hhbXBwL2h0ZG9jcy9TdHlsZWd1aWRlL2lvc3RnLW9wZW5lbWlzLXN0eWxlZ3VpZGUvcHJvamVjdHMvb3BlbmVtaXMtc3R5bGVndWlkZS1saWIvc3JjLyIsInNvdXJjZXMiOlsia2QtY29tcG9uZW50cy9rZC1hbmd1bGFyLXNsaWRlci9rZC1hbmd1bGFyLXNsaWRlci1zdmMudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsT0FBTyxFQUFFLFVBQVUsRUFBRSxNQUFNLGVBQWUsQ0FBQztBQUkzQyxNQUFNLE9BQU8sV0FBVztJQU1wQjs7O09BR0c7SUFDSCxJQUFJLE1BQU0sQ0FBQyxPQUFzQjtRQUM3QixJQUFJLENBQUMsT0FBTyxHQUFHLE9BQU8sQ0FBQztJQUMzQixDQUFDO0lBRUQ7OztPQUdHO0lBQ0gsSUFBSSxTQUFTLENBQUMsVUFBVTtRQUNwQixJQUFJLENBQUMsVUFBVSxHQUFHLFVBQVUsQ0FBQztJQUNqQyxDQUFDO0lBRUQ7Ozs7T0FJRztJQUNJLGlCQUFpQixDQUFDLE1BQVcsRUFBRSxPQUFlO1FBQ2pELElBQUksVUFBVSxHQUFRLEVBQUUsQ0FBQztRQUN6QixJQUFJLENBQUMsTUFBTSxFQUFFO1lBQ1QsVUFBVSxHQUFHLElBQUksQ0FBQyx3QkFBd0IsRUFBRSxDQUFDO1NBQ2hEO2FBQU0sSUFBSSxLQUFLLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxFQUFFO1lBQzlCLFVBQVUsR0FBRyxNQUFNLENBQUMsQ0FBQyxDQUFDLEdBQUcsR0FBRyxHQUFHLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQztTQUM1QzthQUFNLElBQUksT0FBTyxNQUFNLEtBQUssUUFBUSxFQUFFO1lBQ25DLFVBQVUsR0FBRyxNQUFNLENBQUMsS0FBSyxDQUFDO1NBQzdCO2FBQU07WUFDSCxVQUFVLEdBQUcsTUFBTSxDQUFBO1NBQ3RCO1FBRUQsT0FBTyxJQUFJLENBQUMscUJBQXFCLENBQUMsVUFBVSxFQUFFLE9BQU8sQ0FBQyxDQUFDO0lBQzNELENBQUM7SUFFRDs7OztPQUlHO0lBQ0ksbUJBQW1CLENBQUMsVUFBa0I7UUFDekMsSUFBSSxPQUFPLFVBQVUsS0FBSyxXQUFXO1lBQUUsT0FBTyxVQUFVLENBQUM7UUFDekQsSUFBSSxJQUFJLENBQUMsT0FBTyxDQUFDLFdBQVcsS0FBSyxVQUFVLEVBQUU7WUFDekMsT0FBTyxNQUFNLENBQUM7U0FDakI7UUFDRCxPQUFPLEtBQUssQ0FBQztJQUNqQixDQUFDO0lBRUQ7OztPQUdHO0lBQ0ksVUFBVTtRQUNiLE9BQU8sSUFBSSxDQUFDLE9BQU8sQ0FBQyxXQUFXLEtBQUssVUFBVSxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQztJQUNsRSxDQUFDO0lBRUQ7OztPQUdHO0lBQ0ksaUJBQWlCO1FBQ3BCLE9BQU8sQ0FBQyxJQUFJLENBQUMsVUFBVSxLQUFLLEtBQUssSUFBSSxDQUFDLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxXQUFXLEtBQUssVUFBVSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsVUFBVSxFQUFFLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxVQUFVLEVBQUUsQ0FBQztJQUM5SCxDQUFDO0lBRUQ7O09BRUc7SUFDSSxxQkFBcUI7UUFDeEIsSUFBSSxDQUFDLGFBQWEsR0FBRyxJQUFJLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxRQUFRLEVBQUUsQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLENBQUMsR0FBRyxFQUFHLENBQUMsTUFBTSxDQUFDO0lBQy9FLENBQUM7SUFFRDs7Ozs7O09BTUc7SUFDSSxrQkFBa0IsQ0FBQyxhQUFxQixFQUFFLFdBQW1CLEVBQUUsVUFBa0I7UUFDcEYsUUFBUSxVQUFVLEVBQUU7WUFDaEIsS0FBSyxDQUFDO2dCQUNGLElBQUksYUFBYSxHQUFHLFdBQVc7b0JBQUUsT0FBTyxJQUFJLENBQUM7Z0JBQzdDLE9BQU8sS0FBSyxDQUFDO1lBQ2pCLEtBQUssQ0FBQztnQkFDRixJQUFJLGFBQWEsR0FBRyxXQUFXO29CQUFFLE9BQU8sSUFBSSxDQUFDO2dCQUM3QyxPQUFPLEtBQUssQ0FBQztZQUNqQjtnQkFDSSxPQUFPLEtBQUssQ0FBQztTQUNwQjtJQUNMLENBQUM7SUFFRDs7Ozs7O09BTUc7SUFDSSxLQUFLLENBQUMsS0FBYSxFQUFFLEdBQUcsR0FBRyxDQUFDLEVBQUUsR0FBRyxHQUFHLENBQUM7UUFDeEMsT0FBTyxJQUFJLENBQUMsR0FBRyxDQUFDLEdBQUcsRUFBRSxJQUFJLENBQUMsR0FBRyxDQUFDLEtBQUssRUFBRSxHQUFHLENBQUMsQ0FBQyxDQUFDO0lBQy9DLENBQUM7SUFFRDs7OztPQUlHO0lBQ0ksbUJBQW1CLENBQUMsTUFBYztRQUNyQyxJQUFJLElBQUksQ0FBQyxhQUFhLElBQUksTUFBTSxJQUFJLE1BQU0sR0FBRyxDQUFDLEtBQUssQ0FBQyxFQUFFO1lBQ2xELE9BQU8sTUFBTSxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsYUFBYSxDQUFDLENBQUM7U0FDN0M7YUFBTTtZQUNILE9BQU8sTUFBTSxDQUFDLFFBQVEsRUFBRSxJQUFJLEdBQUcsQ0FBQztTQUNuQztJQUNMLENBQUM7SUFFRDs7OztPQUlHO0lBQ0ksbUJBQW1CLENBQUMsTUFBcUI7UUFDNUMsT0FBTyxDQUFDLENBQUMsTUFBTSxJQUFJLENBQUMsQ0FBQyxHQUFHLElBQUksQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLEdBQUcsR0FBRyxJQUFJLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxDQUFDO0lBQ3RGLENBQUM7SUFFRDs7OztPQUlHO0lBQ0ksY0FBYyxDQUFDLFdBQW1CO1FBQ3JDLElBQUksVUFBVSxHQUFXLElBQUksQ0FBQyxxQkFBcUIsQ0FBQyxXQUFXLENBQUMsQ0FBQztRQUNqRSxJQUFJLFlBQVksR0FBVyxVQUFVLENBQUMsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLENBQUMsVUFBVSxHQUFHLElBQUksQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLEdBQUcsSUFBSSxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsR0FBRyxJQUFJLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsYUFBYSxDQUFDLENBQUMsR0FBRyxJQUFJLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQztRQUM1SyxPQUFPLElBQUksQ0FBQyxLQUFLLENBQUMsWUFBWSxFQUFFLElBQUksQ0FBQyxPQUFPLENBQUMsR0FBRyxFQUFFLElBQUksQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLENBQUM7SUFDeEUsQ0FBQztJQUVEOzs7O09BSUc7SUFDSSxxQkFBcUIsQ0FBQyxLQUFhLEVBQUUsT0FBZTtRQUN2RCxPQUFPLE9BQU8sQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLE9BQU8sQ0FBQyxVQUFVLEVBQUUsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQztJQUNoRSxDQUFDO0lBRUQ7Ozs7T0FJRztJQUNJLHFCQUFxQixDQUFDLFdBQW1CO1FBQzVDLE9BQU8sSUFBSSxDQUFDLE9BQU8sQ0FBQyxHQUFHLEdBQUcsV0FBVyxHQUFHLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxHQUFHLEdBQUcsSUFBSSxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsQ0FBQztJQUNsRixDQUFDO0lBRUQ7OztPQUdHO0lBQ0ssd0JBQXdCO1FBQzVCLElBQUksSUFBSSxDQUFDLE9BQU8sQ0FBQyxJQUFJLEtBQUssUUFBUTtZQUFFLE9BQU8sSUFBSSxDQUFDLE9BQU8sQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUM7UUFDbkUsSUFBSSxJQUFJLENBQUMsT0FBTyxDQUFDLEtBQUs7WUFBRSxJQUFJLENBQUMsT0FBTyxDQUFDLEtBQUssR0FBRyxLQUFLLENBQUM7UUFDbkQsT0FBTyxDQUFDLENBQUM7SUFDYixDQUFDOzs7WUF6S0osVUFBVSIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IEluamVjdGFibGUgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcclxuaW1wb3J0IHsgSVNsaWRlckNvbmZpZyB9IGZyb20gJy4va2QtYW5ndWxhci1zbGlkZXItaW50ZXJmYWNlJztcclxuXHJcbkBJbmplY3RhYmxlKClcclxuZXhwb3J0IGNsYXNzIEtkU2xpZGVyU3ZjIHtcclxuXHJcbiAgICBwcml2YXRlIF9yb3VuZExhYmVsVG86IG51bWJlcjtcclxuICAgIHByaXZhdGUgX2NvbmZpZzogSVNsaWRlckNvbmZpZztcclxuICAgIHByaXZhdGUgX2RpcmVjdGlvbjogJ3J0bCcgfCAnbHRyJztcclxuXHJcbiAgICAvKipcclxuICAgICAqIFtjb25maWcgZGVzY3JpcHRpb25dIHNldCBjb25maWcgaW4gc2VydmljZVxyXG4gICAgICogIF9jb25maWcgW2Rlc2NyaXB0aW9uXVxyXG4gICAgICovXHJcbiAgICBzZXQgY29uZmlnKF9jb25maWc6IElTbGlkZXJDb25maWcpIHtcclxuICAgICAgICB0aGlzLl9jb25maWcgPSBfY29uZmlnO1xyXG4gICAgfVxyXG5cclxuICAgIC8qKlxyXG4gICAgICogW2RpcmVjdGlvbiBkZXNjcmlwdGlvbl0gc2V0IGRpcmVjdGlvbiBpbiBzZXJ2aWNlXHJcbiAgICAgKiAgX2RpcmVjdGlvbiBbZGVzY3JpcHRpb25dXHJcbiAgICAgKi9cclxuICAgIHNldCBkaXJlY3Rpb24oX2RpcmVjdGlvbikge1xyXG4gICAgICAgIHRoaXMuX2RpcmVjdGlvbiA9IF9kaXJlY3Rpb247XHJcbiAgICB9XHJcblxyXG4gICAgLyoqXHJcbiAgICAgKiBbc2V0U2lkZVZhbHVlTGFiZWwgZGVzY3JpcHRpb25dIHNldHMgdGhlIHZhbHVlIHRvIHNob3cgYmVzaWRlIHRoZSBzbGlkZXJcclxuICAgICAqICAgICBfdmFsdWUgW2Rlc2NyaXB0aW9uXSB2YWx1ZSB0byBiZSBlbWl0dGVkIGZyb20ga2QtYW5ndWxhci1zbGlkZXJcclxuICAgICAqICAgICAgICAgW2Rlc2NyaXB0aW9uXSBzdHJpbmcgdG8gYmUgcGFzc2VkIHRvIHNpZGVWYWx1ZUxhYmVsIEhUTUwgZWxlbWVudFxyXG4gICAgICovXHJcbiAgICBwdWJsaWMgc2V0U2lkZVZhbHVlTGFiZWwoX3ZhbHVlOiBhbnksIF9mb3JtYXQ6IHN0cmluZyk6IHN0cmluZyB7XHJcbiAgICAgICAgbGV0IGZpbmFsTGFiZWw6IGFueSA9ICcnO1xyXG4gICAgICAgIGlmICghX3ZhbHVlKSB7XHJcbiAgICAgICAgICAgIGZpbmFsTGFiZWwgPSB0aGlzLl9zZXREZWZhdWx0VmFsdWVGb3JMYWJlbCgpO1xyXG4gICAgICAgIH0gZWxzZSBpZiAoQXJyYXkuaXNBcnJheShfdmFsdWUpKSB7XHJcbiAgICAgICAgICAgIGZpbmFsTGFiZWwgPSBfdmFsdWVbMF0gKyAnLScgKyBfdmFsdWVbMV07XHJcbiAgICAgICAgfSBlbHNlIGlmICh0eXBlb2YgX3ZhbHVlID09PSAnb2JqZWN0Jykge1xyXG4gICAgICAgICAgICBmaW5hbExhYmVsID0gX3ZhbHVlLnZhbHVlO1xyXG4gICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgIGZpbmFsTGFiZWwgPSBfdmFsdWVcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIHJldHVybiB0aGlzLmdldExhYmVsRm9ybWF0UmVwbGFjZShmaW5hbExhYmVsLCBfZm9ybWF0KTtcclxuICAgIH1cclxuXHJcbiAgICAvKipcclxuICAgICAqIFtzZXRUb29sdGlwUGxhY2VtZW50IGRlc2NyaXB0aW9uXVxyXG4gICAgICogIF9wbGFjZW1lbnQgW2Rlc2NyaXB0aW9uXVxyXG4gICAgICogICAgICAgICAgICAgW2Rlc2NyaXB0aW9uXVxyXG4gICAgICovXHJcbiAgICBwdWJsaWMgc2V0VG9vbHRpcFBsYWNlbWVudChfcGxhY2VtZW50OiBzdHJpbmcpOiBzdHJpbmcge1xyXG4gICAgICAgIGlmICh0eXBlb2YgX3BsYWNlbWVudCAhPT0gJ3VuZGVmaW5lZCcpIHJldHVybiBfcGxhY2VtZW50O1xyXG4gICAgICAgIGlmICh0aGlzLl9jb25maWcub3JpZW50YXRpb24gPT09ICd2ZXJ0aWNhbCcpIHtcclxuICAgICAgICAgICAgcmV0dXJuICdsZWZ0JztcclxuICAgICAgICB9XHJcbiAgICAgICAgcmV0dXJuICd0b3AnO1xyXG4gICAgfVxyXG5cclxuICAgIC8qKlxyXG4gICAgICogW2ludmVydEF4aXMgZGVzY3JpcHRpb25dIGNoZWNrIHdoZXRoZXIgdG8gaW52ZXJ0IGF4aXMgd2hlbiBvcmllbnRhdGlvbiBpcyB2ZXJ0aWNhbFxyXG4gICAgICogIFtkZXNjcmlwdGlvbl1cclxuICAgICAqL1xyXG4gICAgcHVibGljIGludmVydEF4aXMoKTogYm9vbGVhbiB7XHJcbiAgICAgICAgcmV0dXJuIHRoaXMuX2NvbmZpZy5vcmllbnRhdGlvbiA9PT0gJ3ZlcnRpY2FsJyA/IHRydWUgOiBmYWxzZTtcclxuICAgIH1cclxuXHJcbiAgICAvKipcclxuICAgICAqIFtpbnZlcnRNb3VzZUNvb3JkcyBkZXNjcmlwdGlvbl0gY2hlY2sgd2hldGhlciB0byBpbnZlcnQgbW91c2UgY29vcmRzIHdoZW4gb3JpZW50YXRpb24gaXMgdmVydGljYWwgYW5kIGRpcmVjdGlvbiBpcyBydGxcclxuICAgICAqICBbZGVzY3JpcHRpb25dXHJcbiAgICAgKi9cclxuICAgIHB1YmxpYyBpbnZlcnRNb3VzZUNvb3JkcygpOiBib29sZWFuIHtcclxuICAgICAgICByZXR1cm4gKHRoaXMuX2RpcmVjdGlvbiA9PT0gJ3J0bCcgJiYgISh0aGlzLl9jb25maWcub3JpZW50YXRpb24gPT09ICd2ZXJ0aWNhbCcpKSA/ICF0aGlzLmludmVydEF4aXMoKSA6IHRoaXMuaW52ZXJ0QXhpcygpO1xyXG4gICAgfVxyXG5cclxuICAgIC8qKlxyXG4gICAgICogW2NhbGN1bGF0ZVJvdW5kTGFiZWxUbyBkZXNjcmlwdGlvbl0gZGVjaW1hbCBwbGFjZXMgdG8gcm91bmQgdmFsdWUgKHRvIGJlIGVtaXR0ZWQpIGFuZCB0b29sdGlwIGxhYmVsIHRvXHJcbiAgICAgKi9cclxuICAgIHB1YmxpYyBjYWxjdWxhdGVSb3VuZExhYmVsVG8oKSB7XHJcbiAgICAgICAgdGhpcy5fcm91bmRMYWJlbFRvID0gdGhpcy5fY29uZmlnLnN0ZXAudG9TdHJpbmcoKS5zcGxpdCgnLicpLnBvcCgpIS5sZW5ndGg7XHJcbiAgICB9XHJcblxyXG4gICAgLyoqXHJcbiAgICAgKiBbY2hlY2tWYWx1ZUNvbmZsaWN0IGRlc2NyaXB0aW9uXSBmb3IgcmFuZ2Ugb25seS4gdG8gY2hlY2sgdGhlIGZpcnN0IHRodW1iIHZhbHVlIGlzIG5vdCBsYXJnZXIgdGhhbiB0aGUgc2Vjb25kIHRodW1iIG9yIHRoZSBzZWNvbmQgdGh1bWIgdmFsdWUgaXMgbm90IGxlc3NlciB0aGFuIGZpcnN0XHJcbiAgICAgKiAgIF9jdXJyZW50VmFsdWUgW2Rlc2NyaXB0aW9uXVxyXG4gICAgICogICBfb3RoZXJWYWx1ZSAgIFtkZXNjcmlwdGlvbl1cclxuICAgICAqICAgX2N1cnJlbnRJZCAgICBbZGVzY3JpcHRpb25dXHJcbiAgICAgKiAgICAgICAgICAgICAgICBbZGVzY3JpcHRpb25dXHJcbiAgICAgKi9cclxuICAgIHB1YmxpYyBjaGVja1ZhbHVlQ29uZmxpY3QoX2N1cnJlbnRWYWx1ZTogbnVtYmVyLCBfb3RoZXJWYWx1ZTogbnVtYmVyLCBfY3VycmVudElkOiBudW1iZXIpOiBib29sZWFuIHtcclxuICAgICAgICBzd2l0Y2ggKF9jdXJyZW50SWQpIHtcclxuICAgICAgICAgICAgY2FzZSAwOlxyXG4gICAgICAgICAgICAgICAgaWYgKF9jdXJyZW50VmFsdWUgPiBfb3RoZXJWYWx1ZSkgcmV0dXJuIHRydWU7XHJcbiAgICAgICAgICAgICAgICByZXR1cm4gZmFsc2U7XHJcbiAgICAgICAgICAgIGNhc2UgMTpcclxuICAgICAgICAgICAgICAgIGlmIChfY3VycmVudFZhbHVlIDwgX290aGVyVmFsdWUpIHJldHVybiB0cnVlO1xyXG4gICAgICAgICAgICAgICAgcmV0dXJuIGZhbHNlO1xyXG4gICAgICAgICAgICBkZWZhdWx0OlxyXG4gICAgICAgICAgICAgICAgcmV0dXJuIGZhbHNlO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICAvKipcclxuICAgICAqIFtjbGFtcCBkZXNjcmlwdGlvbl0gUmV0dXJuIGEgbnVtYmVyIGJldHdlZW4gdHdvIG51bWJlcnMuXHJcbiAgICAgKiAgdmFsdWUgW2Rlc2NyaXB0aW9uXVxyXG4gICAgICogIG1pbiAgID0gICAgICAgICAgICAgMCBbZGVzY3JpcHRpb25dXHJcbiAgICAgKiAgbWF4ICAgPSAgICAgICAgICAgICAxIFtkZXNjcmlwdGlvbl1cclxuICAgICAqICAgICAgICBbZGVzY3JpcHRpb25dXHJcbiAgICAgKi9cclxuICAgIHB1YmxpYyBjbGFtcCh2YWx1ZTogbnVtYmVyLCBtaW4gPSAwLCBtYXggPSAxKTogbnVtYmVyIHtcclxuICAgICAgICByZXR1cm4gTWF0aC5tYXgobWluLCBNYXRoLm1pbih2YWx1ZSwgbWF4KSk7XHJcbiAgICB9XHJcblxyXG4gICAgLyoqXHJcbiAgICAgKiBbY2FsY3VsYXRlTGFiZWxWYWx1ZSBkZXNjcmlwdGlvbl0gY2FsY3VsYXRlIGhvdyBtYW55IGRlY2ltYWxzIHRvIHJvdW5kIHRoZSB0b29sdGlwIHRleHQgdG9cclxuICAgICAqICBfdmFsdWUgW2Rlc2NyaXB0aW9uXVxyXG4gICAgICogICAgICAgICBbZGVzY3JpcHRpb25dXHJcbiAgICAgKi9cclxuICAgIHB1YmxpYyBjYWxjdWxhdGVMYWJlbFZhbHVlKF92YWx1ZTogbnVtYmVyKTogc3RyaW5nIHtcclxuICAgICAgICBpZiAodGhpcy5fcm91bmRMYWJlbFRvICYmIF92YWx1ZSAmJiBfdmFsdWUgJSAxICE9PSAwKSB7XHJcbiAgICAgICAgICAgIHJldHVybiBfdmFsdWUudG9GaXhlZCh0aGlzLl9yb3VuZExhYmVsVG8pO1xyXG4gICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgIHJldHVybiBfdmFsdWUudG9TdHJpbmcoKSB8fCAnMCc7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIC8qKlxyXG4gICAgICogW2NhbGN1bGF0ZVBlcmNlbnRhZ2UgZGVzY3JpcHRpb25dIENhbGN1bGF0ZXMgdGhlIHBlcmNlbnRhZ2Ugb2YgdGhlIHNsaWRlciB0aGF0IGEgdmFsdWUgaXMuXHJcbiAgICAgKiAgICAgICAgIF92YWx1ZSBbZGVzY3JpcHRpb25dXHJcbiAgICAgKiAgICAgICBbZGVzY3JpcHRpb25dXHJcbiAgICAgKi9cclxuICAgIHB1YmxpYyBjYWxjdWxhdGVQZXJjZW50YWdlKF92YWx1ZTogbnVtYmVyIHwgbnVsbCk6IG51bWJlciB7XHJcbiAgICAgICAgcmV0dXJuICgoX3ZhbHVlIHx8IDApIC0gdGhpcy5fY29uZmlnLm1pbikgLyAodGhpcy5fY29uZmlnLm1heCAtIHRoaXMuX2NvbmZpZy5taW4pO1xyXG4gICAgfVxyXG5cclxuICAgIC8qKlxyXG4gICAgICogW2NhbGN1bGF0ZVZhbHVlIGRlc2NyaXB0aW9uXSBDYWxjdWxhdGVzIHRoZSB2YWx1ZSBhIHBlcmNlbnRhZ2Ugb2YgdGhlIHNsaWRlciBjb3JyZXNwb25kcyB0by5cclxuICAgICAqICBfcGVyY2VudGFnZSBbZGVzY3JpcHRpb25dXHJcbiAgICAgKiAgICAgICAgICAgICAgW2Rlc2NyaXB0aW9uXVxyXG4gICAgICovXHJcbiAgICBwdWJsaWMgY2FsY3VsYXRlVmFsdWUoX3BlcmNlbnRhZ2U6IG51bWJlcik6IG51bWJlciB7XHJcbiAgICAgICAgbGV0IGV4YWN0VmFsdWU6IG51bWJlciA9IHRoaXMuY29udmVydFBlcmNlbnRUb1ZhbHVlKF9wZXJjZW50YWdlKTtcclxuICAgICAgICBsZXQgY2xvc2VzdFZhbHVlOiBudW1iZXIgPSBwYXJzZUZsb2F0KChNYXRoLnJvdW5kKChleGFjdFZhbHVlIC0gdGhpcy5fY29uZmlnLm1pbikgLyB0aGlzLl9jb25maWcuc3RlcCkgKiB0aGlzLl9jb25maWcuc3RlcCkudG9GaXhlZCh0aGlzLl9yb3VuZExhYmVsVG8pKSArIHRoaXMuX2NvbmZpZy5taW47XHJcbiAgICAgICAgcmV0dXJuIHRoaXMuY2xhbXAoY2xvc2VzdFZhbHVlLCB0aGlzLl9jb25maWcubWluLCB0aGlzLl9jb25maWcubWF4KTtcclxuICAgIH1cclxuXHJcbiAgICAvKipcclxuICAgICAqIHRha2VzIGluIHRoaXMuY29uZmlnLmxhYmVsRm9ybWF0IGFuZCByZXBsYWNlcyB7dmFsdWV9IHRvIHRleHRcclxuICAgICAqIF9mb3JtYXQge3ZhbHVlfSB3aWxsIGJlIHJlcGxhY2VkIGJ5IHRleHRcclxuICAgICAqIF90ZXh0ICAgdmFsdWVcclxuICAgICAqL1xyXG4gICAgcHVibGljIGdldExhYmVsRm9ybWF0UmVwbGFjZShfdGV4dDogc3RyaW5nLCBfZm9ybWF0OiBzdHJpbmcpOiBzdHJpbmcge1xyXG4gICAgICAgIHJldHVybiBfZm9ybWF0ID8gX2Zvcm1hdC5yZXBsYWNlKC97dmFsdWV9L2csIF90ZXh0KSA6IF90ZXh0O1xyXG4gICAgfVxyXG5cclxuICAgIC8qKlxyXG4gICAgICogW2NvbnZlcnRQZXJjZW50VG9WYWx1ZSBkZXNjcmlwdGlvbl0gQ29udmVydHMgcGVyY2VudCBvZiB0aGUgc2xpZGVyIHRvIHZhbHVlIChub3Qgcm91bmRlZClcclxuICAgICAqICBfcGVyY2VudGFnZSBbZGVzY3JpcHRpb25dXHJcbiAgICAgKiAgICAgICAgICAgICAgW2Rlc2NyaXB0aW9uXVxyXG4gICAgICovXHJcbiAgICBwdWJsaWMgY29udmVydFBlcmNlbnRUb1ZhbHVlKF9wZXJjZW50YWdlOiBudW1iZXIpOiBudW1iZXIge1xyXG4gICAgICAgIHJldHVybiB0aGlzLl9jb25maWcubWluICsgX3BlcmNlbnRhZ2UgKiAodGhpcy5fY29uZmlnLm1heCAtIHRoaXMuX2NvbmZpZy5taW4pO1xyXG4gICAgfVxyXG5cclxuICAgIC8qKlxyXG4gICAgICogW19zZXREZWZhdWx0VmFsdWVGb3JMYWJlbCBkZXNjcmlwdGlvbl1cclxuICAgICAqICBbZGVzY3JpcHRpb25dXHJcbiAgICAgKi9cclxuICAgIHByaXZhdGUgX3NldERlZmF1bHRWYWx1ZUZvckxhYmVsKCk6IGFueSB7XHJcbiAgICAgICAgaWYgKHRoaXMuX2NvbmZpZy50eXBlID09PSAnb3RoZXJzJykgcmV0dXJuIHRoaXMuX2NvbmZpZy5vcHRpb25zWzBdO1xyXG4gICAgICAgIGlmICh0aGlzLl9jb25maWcucmFuZ2UpIHRoaXMuX2NvbmZpZy5yYW5nZSA9IGZhbHNlO1xyXG4gICAgICAgIHJldHVybiAwO1xyXG4gICAgfVxyXG59XHJcbiJdfQ==