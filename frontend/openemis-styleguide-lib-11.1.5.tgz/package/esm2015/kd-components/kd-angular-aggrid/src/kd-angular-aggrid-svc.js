import { Injectable } from '@angular/core';
// import {
//     KdAGDropdown,
//     KdAGPhoto,
//     KdAGForm,
//     KdAGCheckboxRadio
// } from './ag-grid-components/kd-aggrid-components';
export class KdAggridSvc {
    constructor() {
        this._resizeableCol = 0;
    }
    // private _dataSvc: KdDataSvc = new KdDataSvc();
    getGridOptions() {
        let options = {
            rowData: [],
            columnDefs: [],
            // debug: true,
            headerHeight: 38,
            getRowHeight: this._getRowHeight,
            // animateRows: true,
            // rowBuffer: 5,
            suppressContextMenu: true,
            // suppressMenuMainPanel: true,
            // suppressMenuColumnPanel: true,
            suppressMovableColumns: true,
            suppressMenuHide: true,
            suppressColumnVirtualisation: true,
            unSortIcon: true,
            icons: {
                filter: '<i class="fa fa-filter"/>',
                sortAscending: '<i class="fa fa-caret-down"/>',
                sortDescending: '<i class="fa fa-caret-up"/>',
                sortUnSort: '<i class="fa fa-sort"/>',
                groupExpanded: '<i class="fa fa-minus-circle"/>',
                groupContracted: '<i class="fa fa-plus-circle"/>',
            },
            overlayNoRowsTemplate: '<span class="ag-custom-overlay"><i class="fa fa-info-circle fa-lg margin-right10"></i>No student record found</span>'
        };
        return options;
    }
    setResult(_config) {
        let updateResult = {};
        updateResult.id = (typeof _config !== 'undefined' && typeof _config.id !== 'undefined') ? _config.id : 'kd-grid';
        updateResult.gridHeight = this._checkGridHeight(_config);
        updateResult.checkbox = (typeof _config !== 'undefined' && typeof _config.checkbox !== 'undefined') ? _config.checkbox : false;
        updateResult.radio = (typeof _config !== 'undefined' && typeof _config.radio !== 'undefined') ? _config.radio : false;
        updateResult.externalFilter = (typeof _config !== 'undefined' && typeof _config.externalFilter !== 'undefined') ? _config.externalFilter : false;
        updateResult.loadType = this._checkLoadType(_config);
        updateResult.paginationType = this._checkPaginationType(updateResult.loadType);
        updateResult.pagesize = this._checkPagesize(_config, updateResult.loadType);
        updateResult.totalData = (typeof _config !== 'undefined' && typeof _config.totalData !== 'undefined') ? _config.totalData : -1;
        updateResult.button = (typeof _config !== 'undefined' && typeof _config.button !== 'undefined') ? _config.button : false;
        updateResult.buttonConfig = (typeof _config !== 'undefined' && typeof _config.buttonConfig !== 'undefined') ? this._checkBtnConfig(_config.buttonConfig) : null;
        updateResult.alignment = (typeof _config !== 'undefined' && typeof _config.alignment !== 'undefined') ? _config.alignment : 'middle';
        updateResult.suppressHeightResize = (typeof _config !== 'undefined' && typeof _config.suppressHeightResize !== 'undefined') ? _config.suppressHeightResize : true;
        updateResult.rowClickable = (typeof _config !== 'undefined' && typeof _config.rowClickable !== 'undefined') ? _config.rowClickable : false;
        updateResult.rowMapActionType = (typeof _config !== 'undefined' && typeof _config.rowMapActionType !== 'undefined') ? _config.rowMapActionType : null;
        if (updateResult.radio && updateResult.checkbox)
            updateResult.radio = false;
        return updateResult;
    }
    setRowResult(_rowData) {
        let tableData = (typeof _rowData !== 'undefined') ? _rowData : [];
        return tableData;
    }
    setColDefs(_colDef, _gridOptions, /*_dataSvc: KdDataSvc, */ _router, _isRecursive = false) {
        let colDefConfig = { editMode: false, updatedColDef: [] };
        let tableColumn = {};
        for (let key in _colDef) {
            if (_colDef.hasOwnProperty(key)) {
                this._resizeableCol++;
                tableColumn = {
                    headerName: _colDef[key].headerName,
                    field: (typeof _colDef[key].config !== 'undefined' && typeof _colDef[key].config.map !== 'undefined') ? _colDef[key].config.map : key,
                    editable: false,
                    suppressMenu: (typeof _colDef[key].filterable !== 'undefined') ? !_colDef[key].filterable : true,
                    suppressSorting: (typeof _colDef[key].sortable !== 'undefined') ? !_colDef[key].sortable : true,
                    colId: key,
                    config: (typeof _colDef[key].config !== 'undefined') ? _colDef[key].config : undefined,
                    // cellRenderer: (_params: any): any => {
                    //     if (typeof _params.value === 'number') {
                    //         return _params.value.toString();
                    //     }
                    //     else if (_params.value instanceof Array) {
                    //         JSON.stringify(_params.value);
                    //     }
                    //     return _params.value;
                    // },
                    hide: (typeof _colDef[key].visible !== 'undefined') ? !(_colDef[key].visible) : false,
                    cellClass: 'ag-default'
                };
                if (!tableColumn.suppressMenu) {
                    tableColumn['menuTabs'] = ['filterMenuTab'];
                    tableColumn.filterParams = {
                        newRowsAction: 'keep',
                        cellHeight: 30,
                        selectAllOnMiniFilter: true,
                        values: (typeof _colDef[key].filterVal !== 'undefined' && _colDef[key].filterVal.length > 0) ? _colDef[key].filterVal : undefined
                    };
                }
                if (typeof _colDef[key].config !== 'undefined') {
                    if (typeof _colDef[key].config.input !== 'undefined' && _colDef[key].config.input) {
                        colDefConfig.editMode = true;
                    }
                    tableColumn = this._setColumnConfig(tableColumn, _colDef[key].config, /*_dataSvc,*/ _router);
                    if (tableColumn.hasOwnProperty('cellRendererFramework')) {
                        delete tableColumn.cellRenderer;
                    }
                }
                if (typeof tableColumn.config !== 'undefined' && ((typeof tableColumn.config.checkbox !== 'undefined' && tableColumn.config.checkbox) ||
                    (typeof tableColumn.config.radio !== 'undefined' && tableColumn.config.radio))) {
                    colDefConfig.updatedColDef.unshift(tableColumn);
                }
                else {
                    colDefConfig.updatedColDef.push(tableColumn);
                }
            }
        }
        return colDefConfig;
    }
    setFilterAndSortOptions(params) {
        let updatedOptions = params.gridOptions;
        if (params.loadType === 'server-pagination' || params.loadType === 'oneshot-pagination') {
            updatedOptions.enableServerSideFilter = true;
            updatedOptions.enableServerSideSorting = true;
            updatedOptions.paginationPageSize = params.pagesize;
        }
        else if (params.loadType === 'virtual') {
            updatedOptions.enableServerSideFilter = true;
            updatedOptions.enableServerSideSorting = true;
            updatedOptions.paginationPageSize = params.pagesize;
            updatedOptions.maxPagesInCache = 3;
            updatedOptions.maxConcurrentDatasourceRequests = 2;
            updatedOptions.overflowSize = 30;
        }
        else {
            updatedOptions.enableFilter = true;
            updatedOptions.enableSorting = true;
        }
        if (params.loadType === 'server-pagination' || params.loadType === 'oneshot-pagination') {
            updatedOptions.pagination = true;
        }
        else {
            updatedOptions.rowModelType = params.paginationType;
        }
        return updatedOptions;
    }
    calcColWidth(_gridOptions) {
        let columns = _gridOptions.columnApi.getAllColumns();
        let updatedWidth = [];
        for (let i = 0; i < columns.length; i++) {
            let columnDef = columns[i].getColDef();
            let colWidth = -1;
            if (columnDef.cellClass.indexOf('ag-checkbox-radio') !== -1) {
                colWidth = 50;
                _gridOptions.columnApi.setColumnWidth(columns[i], colWidth);
            }
            else if (typeof columnDef.config !== 'undefined' && typeof columnDef.config.action !== 'undefined' && columnDef.config.action) {
                colWidth = 120;
                _gridOptions.columnApi.setColumnWidth(columns[i], colWidth);
            }
            else if (typeof columnDef.config !== 'undefined' && typeof columnDef.config.photo !== 'undefined' && columnDef.config.photo) {
                colWidth = 100;
                _gridOptions.columnApi.setColumnWidth(columns[i], colWidth);
            }
            else if (typeof columnDef.config !== 'undefined' && typeof columnDef.config.input !== 'undefined' && columnDef.config.input) {
                colWidth = 280;
            }
            else {
                colWidth = columns[i].getActualWidth() + 30;
            }
            updatedWidth.push({ width: colWidth, id: columnDef.colId });
        }
        return updatedWidth;
    }
    colTotalWidth(_colArray, column) {
        let total = 0;
        for (let i = 0; i < _colArray.length; i++) {
            if (column[i].isVisible()) {
                total += _colArray[i].width;
            }
        }
        return total;
    }
    calcUsableWidth(_vcr) {
        let agGridEle = _vcr.element.nativeElement.querySelector('.stg-theme');
        let parentWidth = Math.round(agGridEle.getBoundingClientRect().width);
        let computedStyle = window.getComputedStyle(agGridEle);
        let borderLeft = (computedStyle.borderLeft !== '') ? parseInt(computedStyle.borderLeft) : 0;
        let borderRight = (computedStyle.borderRight !== '') ? parseInt(computedStyle.borderRight) : 0;
        let borderLeftRight = borderLeft + borderRight;
        return parentWidth - borderLeftRight;
    }
    calcResizeableCol(_columns) {
        let resizeableCol = this._resizeableCol;
        for (let i = 0; i < _columns.length; i++) {
            let colDef = _columns[i].getColDef();
            if (typeof colDef.config === 'undefined' && !_columns[i].isVisible()) {
                --resizeableCol;
            }
            // more checks to implement
        }
        return resizeableCol;
    }
    calcGridHeightWeb(_gridHeight, _model, _vcr) {
        let actualHeight = 38 + 8;
        let idSouth = _vcr.element.nativeElement.querySelector('#south');
        if (idSouth !== null) {
            actualHeight += idSouth.getBoundingClientRect().height;
        }
        for (let i = 0; i < _model.getRowCount(); i++) {
            actualHeight += _model.getRow(i).rowHeight;
            if (actualHeight > _gridHeight) {
                break;
            }
        }
        if (actualHeight < _gridHeight) {
            return actualHeight;
        }
        return _gridHeight;
    }
    calcGridHeightMobile(_vcr) {
        let totalHeight = 0;
        let nativeEle = _vcr.element.nativeElement;
        let headerContainer = nativeEle.querySelector('.ag-header-container');
        if (nativeEle === null || headerContainer === null)
            return totalHeight;
        totalHeight += Math.ceil(headerContainer.getBoundingClientRect().height);
        totalHeight += Math.ceil(nativeEle.querySelector('.ag-body-container').getBoundingClientRect().height);
        let paginationBottom = nativeEle.querySelector('#south');
        if (paginationBottom !== null) {
            totalHeight += Math.ceil(paginationBottom.getBoundingClientRect().height);
        }
        totalHeight += 8;
        return totalHeight;
    }
    serverSortAndFilter(_data, _sortModel, _filterModel) {
        return this._serverSortData(_sortModel, this._serverFilterData(_filterModel, _data));
    }
    checkColumnDef(_colDef, _hasCheckbox, _hasRadio) {
        if (_hasCheckbox) {
            _colDef['ag-checkbox'] = {
                config: {
                    checkbox: true
                }
            };
        }
        else if (_hasRadio) {
            _colDef['ag-radio'] = {
                config: {
                    radio: true
                }
            };
        }
        return _colDef;
    }
    getActionList(_rowData, _column) {
        if (typeof _rowData.action !== 'undefined') {
            return _rowData.action;
        }
        for (let i = 0; i < _column.length; i++) {
            let colDef = _column[i].getColDef();
            if (typeof colDef.config !== 'undefined' &&
                typeof colDef.config.action !== 'undefined' &&
                colDef.config.action) {
                return colDef.config.items;
            }
        }
        return [];
    }
    checkIsTargetClickable(_rowEvent) {
        let element = _rowEvent.target;
        let checkList = ['action-btn', 'checkbox-radio-input', 'fa-chevron-down'];
        for (let i = 0; i < checkList.length; i++) {
            if (element.classList.contains(checkList[i])) {
                return false;
            }
        }
        return true;
    }
    checkIsConfigColumn(_colDef) {
        if (_colDef.cellClass.indexOf('ag-checkbox-radio') !== -1) {
            return true;
        }
        if (typeof _colDef.config !== 'undefined' &&
            ((typeof _colDef.config.photo !== 'undefined' && _colDef.config.photo) ||
                (typeof _colDef.config.action !== 'undefined' && _colDef.config.action))) {
            return true;
        }
        return false;
    }
    _setColumnConfig(_column, _config, /*_dataSvc: KdDataSvc,*/ _router) {
        let updatedColumn = Object.assign({}, _column);
        // if (typeof _config.input !== 'undefined' && _config.input) {
        //     updatedColumn.suppressMenu = true;
        //     updatedColumn.suppressSorting = true;
        //     updatedColumn.cellClass = 'ag-form';
        //     updatedColumn.cellRendererFramework = KdAGForm;
        // }
        // else if (typeof _config.action !== 'undefined' && _config.action) {
        //     updatedColumn.suppressMenu = true;
        //     updatedColumn.suppressSorting = true;
        //     updatedColumn.suppressSizeToFit = true;
        //     updatedColumn.width = 120;
        //     updatedColumn.cellClass = 'dropdown-action';
        //     updatedColumn.cellRendererFramework = KdAGDropdown;
        //     this._resizeableCol--;
        // }
        // else if (typeof _config.photo !== 'undefined' && _config.photo) {
        //     updatedColumn.suppressMenu = true;
        //     updatedColumn.suppressSorting = true;
        //     updatedColumn.suppressSizeToFit = true;
        //     updatedColumn.width = 100;
        //     updatedColumn.cellClass = 'ag-photo';
        //     updatedColumn.cellRendererFramework = KdAGPhoto;
        //     this._resizeableCol--;
        // }
        // else if (typeof _config.checkbox !== 'undefined' && _config.checkbox) {
        //     updatedColumn.suppressMenu = true;
        //     updatedColumn.suppressSorting = true;
        //     updatedColumn.suppressSizeToFit = true;
        //     updatedColumn.width = 50;
        //     updatedColumn.cellClass = 'ag-default ag-checkbox-radio';
        //     updatedColumn.colId = 'checkbox';
        //     updatedColumn.cellRendererFramework = KdAGCheckboxRadio;
        //     updatedColumn.headerComponentFramework = KdAGCheckboxRadio;
        //     this._resizeableCol--;
        // }
        // else if (typeof _config.radio !== 'undefined' && _config.radio) {
        //     updatedColumn.suppressMenu = true;
        //     updatedColumn.suppressSorting = true;
        //     updatedColumn.suppressSizeToFit = true;
        //     updatedColumn.width = 50;
        //     updatedColumn.cellClass = 'ag-default ag-checkbox-radio';
        //     updatedColumn.colId = 'radio';
        //     updatedColumn.cellRendererFramework = KdAGCheckboxRadio;
        //     updatedColumn.headerName = '';
        //     this._resizeableCol--;
        // }
        // else if (typeof _config.displayFrom !== 'undefined' && _config.displayFrom) {
        // updatedColumn.cellRenderer = (params: any): any => {
        //     if (typeof params.value !== 'undefined') {
        //         if (params.value instanceof Array) {
        //             let displayArray: Array<any> = [];
        //             for (let i: number = 0; i < params.value.length; i++) {
        //                 let display: any = this._dataSvc.getDataValue(params.value[i], _config.displayFrom);
        //                 if (display !== null) displayArray.push(display);
        //             }
        //             return displayArray;
        //         }
        //         else {
        //             let display: any = this._dataSvc.getDataValue(params.value, _config.displayFrom);
        //             if (display !== null) return display;
        //         }
        //     }
        //     return params.value;
        // }
        // }
        return updatedColumn;
    }
    _serverFilterData(_filterModel, _data) {
        let filteredData = _data.slice();
        if (typeof _filterModel === 'undefined' || Object.keys(_filterModel).length === 0) {
            return filteredData;
        }
        let updatedData = [];
        for (let key in _filterModel) {
            if (_filterModel.hasOwnProperty(key)) {
                for (let k = 0; k < _filterModel[key].length; k++) {
                    for (let j = 0; j < _data.length; j++) {
                        if (_data[j][key] === _filterModel[key][k]) {
                            updatedData.push(_data[j]);
                        }
                    }
                }
            }
        }
        return updatedData;
    }
    _serverSortData(_sortModel, _data) {
        let sortedData = _data.slice();
        if (typeof _sortModel === 'undefined' || _sortModel.length === 0) {
            return sortedData;
        }
        sortedData.sort((a, b) => {
            for (let i = 0; i < _sortModel.length; i++) {
                let sortColModel = _sortModel[i];
                let valA = a[sortColModel.colId];
                let valB = b[sortColModel.colId];
                if (valA === valB) {
                    continue;
                }
                let direction = (sortColModel.sort === 'asc') ? 1 : -1;
                if (valA > valB) {
                    return direction;
                }
                else {
                    return direction * -1;
                }
            }
            return 0;
        });
        return sortedData;
    }
    _checkGridHeight(_config) {
        let defaultHeight = 600;
        if (typeof _config === 'undefined') {
            return defaultHeight;
        }
        else if (typeof _config.gridHeight !== 'undefined' &&
            typeof _config.gridHeight === 'string' &&
            _config.gridHeight === 'auto') {
            return _config.gridHeight;
        }
        else if (typeof _config.gridHeight !== 'undefined' &&
            typeof _config.gridHeight === 'number') {
            return _config.gridHeight;
        }
        return defaultHeight;
    }
    // private _checkPaginationData(_config: any, _loadType: string): any {
    //     if (typeof _config !== 'undefined' &&
    //         typeof _config.paginationSetData !== 'undefined' &&
    //         _loadType === 'server-pagination') {
    //             return _config.paginationSetData;
    //     }
    //     else if (typeof _config !== 'undefined' &&
    //         typeof _config.paginationSetData === 'undefined' &&
    //         _loadType === 'server-pagination') {
    //             console.error('Server pagination requires callback to retrieve data. Please provide the callback function.');
    //     }
    //     return undefined;
    // }
    _checkPaginationType(_loadType) {
        if (_loadType === 'infinite')
            return 'infinite';
        if (_loadType === 'server-pagination' || _loadType === 'oneshot-pagination')
            return 'pagination';
        return '';
    }
    _checkLoadType(_config) {
        let defaultLoadType = 'normal';
        if (typeof _config === 'undefined' || typeof _config.loadType === 'undefined') {
            return defaultLoadType;
        }
        if (_config.loadType === 'normal' ||
            _config.loadType === 'server-pagination' ||
            _config.loadType === 'virtual' ||
            _config.loadType === 'oneshot-pagination') {
            return _config.loadType;
        }
        return defaultLoadType;
    }
    _checkPagesize(_config, _loadType) {
        if (_loadType === 'normal')
            return -1;
        if (typeof _config !== 'undefined' && typeof _config.pagesize !== 'undefined')
            return _config.pagesize;
        return 25;
    }
    _getRowHeight(_params) {
        let gridOptions = this;
        let colDef = gridOptions.columnDefs;
        let rowHeight = 50;
        for (let i = 0; i < colDef.length; i++) {
            if (typeof colDef[i].config !== 'undefined') {
                if (typeof colDef[i].config.photo !== 'undefined' && colDef[i].config.photo)
                    return 120;
                else if (typeof colDef[i].config.textarea !== 'undefined' && colDef[i].config.textarea)
                    return 120;
                else if (typeof colDef[i].config.input !== 'undefined' && colDef[i].config.input) {
                    if (_params.data[colDef[i].colId] instanceof Array)
                        return rowHeight * _params.data[colDef[i].colId].length;
                }
            }
        }
        return 50;
    }
    _checkBtnConfig(_buttonList) {
        let updatedBtnConfig = [];
        for (let i = 0; i < _buttonList.length; i++) {
            updatedBtnConfig.push(this._checkButton(_buttonList[i]));
        }
        return updatedBtnConfig;
    }
    _checkButton(_buttonItem) {
        let defaultButton = {
            type: null,
            label: '',
            icon: '',
            config: null,
            callback: null,
            path: null
        };
        return Object.assign(defaultButton, _buttonItem);
    }
}
KdAggridSvc.decorators = [
    { type: Injectable }
];
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoia2QtYW5ndWxhci1hZ2dyaWQtc3ZjLmpzIiwic291cmNlUm9vdCI6IkM6L3hhbXBwL2h0ZG9jcy9TdHlsZWd1aWRlL2lvc3RnLW9wZW5lbWlzLXN0eWxlZ3VpZGUvcHJvamVjdHMvb3BlbmVtaXMtc3R5bGVndWlkZS1saWIvc3JjLyIsInNvdXJjZXMiOlsia2QtY29tcG9uZW50cy9rZC1hbmd1bGFyLWFnZ3JpZC9zcmMva2QtYW5ndWxhci1hZ2dyaWQtc3ZjLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBLE9BQU8sRUFBRSxVQUFVLEVBQW9CLE1BQU0sZUFBZSxDQUFDO0FBRzdELFdBQVc7QUFDWCxvQkFBb0I7QUFDcEIsaUJBQWlCO0FBQ2pCLGdCQUFnQjtBQUNoQix3QkFBd0I7QUFDeEIsc0RBQXNEO0FBR3RELE1BQU0sT0FBTyxXQUFXO0lBRHhCO1FBRVksbUJBQWMsR0FBVyxDQUFDLENBQUM7SUFxakJ2QyxDQUFDO0lBcGpCRyxpREFBaUQ7SUFFakQsY0FBYztRQUNWLElBQUksT0FBTyxHQUFRO1lBQ2YsT0FBTyxFQUFFLEVBQUU7WUFDWCxVQUFVLEVBQUUsRUFBRTtZQUNkLGVBQWU7WUFDZixZQUFZLEVBQUUsRUFBRTtZQUNoQixZQUFZLEVBQUUsSUFBSSxDQUFDLGFBQWE7WUFDaEMscUJBQXFCO1lBQ3JCLGdCQUFnQjtZQUNoQixtQkFBbUIsRUFBRSxJQUFJO1lBQ3pCLCtCQUErQjtZQUMvQixpQ0FBaUM7WUFDakMsc0JBQXNCLEVBQUUsSUFBSTtZQUM1QixnQkFBZ0IsRUFBRSxJQUFJO1lBQ3RCLDRCQUE0QixFQUFFLElBQUk7WUFDbEMsVUFBVSxFQUFFLElBQUk7WUFDaEIsS0FBSyxFQUFFO2dCQUNILE1BQU0sRUFBRSwyQkFBMkI7Z0JBQ25DLGFBQWEsRUFBRSwrQkFBK0I7Z0JBQzlDLGNBQWMsRUFBRSw2QkFBNkI7Z0JBQzdDLFVBQVUsRUFBRSx5QkFBeUI7Z0JBQ3JDLGFBQWEsRUFBRSxpQ0FBaUM7Z0JBQ2hELGVBQWUsRUFBRSxnQ0FBZ0M7YUFDcEQ7WUFDRCxxQkFBcUIsRUFBRSxzSEFBc0g7U0FDaEosQ0FBQztRQUNGLE9BQU8sT0FBTyxDQUFDO0lBQ25CLENBQUM7SUFFRCxTQUFTLENBQUMsT0FBWTtRQUNsQixJQUFJLFlBQVksR0FBUSxFQUFFLENBQUM7UUFDM0IsWUFBWSxDQUFDLEVBQUUsR0FBRyxDQUFDLE9BQU8sT0FBTyxLQUFLLFdBQVcsSUFBSSxPQUFPLE9BQU8sQ0FBQyxFQUFFLEtBQUssV0FBVyxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQztRQUNqSCxZQUFZLENBQUMsVUFBVSxHQUFHLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxPQUFPLENBQUMsQ0FBQztRQUN6RCxZQUFZLENBQUMsUUFBUSxHQUFHLENBQUMsT0FBTyxPQUFPLEtBQUssV0FBVyxJQUFJLE9BQU8sT0FBTyxDQUFDLFFBQVEsS0FBSyxXQUFXLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDO1FBQy9ILFlBQVksQ0FBQyxLQUFLLEdBQUcsQ0FBQyxPQUFPLE9BQU8sS0FBSyxXQUFXLElBQUksT0FBTyxPQUFPLENBQUMsS0FBSyxLQUFLLFdBQVcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUM7UUFDdEgsWUFBWSxDQUFDLGNBQWMsR0FBRyxDQUFDLE9BQU8sT0FBTyxLQUFLLFdBQVcsSUFBSSxPQUFPLE9BQU8sQ0FBQyxjQUFjLEtBQUssV0FBVyxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxjQUFjLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQztRQUNqSixZQUFZLENBQUMsUUFBUSxHQUFHLElBQUksQ0FBQyxjQUFjLENBQUMsT0FBTyxDQUFDLENBQUM7UUFDckQsWUFBWSxDQUFDLGNBQWMsR0FBRyxJQUFJLENBQUMsb0JBQW9CLENBQUMsWUFBWSxDQUFDLFFBQVEsQ0FBQyxDQUFDO1FBQy9FLFlBQVksQ0FBQyxRQUFRLEdBQUcsSUFBSSxDQUFDLGNBQWMsQ0FBQyxPQUFPLEVBQUUsWUFBWSxDQUFDLFFBQVEsQ0FBQyxDQUFDO1FBQzVFLFlBQVksQ0FBQyxTQUFTLEdBQUcsQ0FBQyxPQUFPLE9BQU8sS0FBSyxXQUFXLElBQUksT0FBTyxPQUFPLENBQUMsU0FBUyxLQUFLLFdBQVcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztRQUMvSCxZQUFZLENBQUMsTUFBTSxHQUFHLENBQUMsT0FBTyxPQUFPLEtBQUssV0FBVyxJQUFJLE9BQU8sT0FBTyxDQUFDLE1BQU0sS0FBSyxXQUFXLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDO1FBQ3pILFlBQVksQ0FBQyxZQUFZLEdBQUcsQ0FBQyxPQUFPLE9BQU8sS0FBSyxXQUFXLElBQUksT0FBTyxPQUFPLENBQUMsWUFBWSxLQUFLLFdBQVcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsZUFBZSxDQUFDLE9BQU8sQ0FBQyxZQUFZLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDO1FBQ2hLLFlBQVksQ0FBQyxTQUFTLEdBQUcsQ0FBQyxPQUFPLE9BQU8sS0FBSyxXQUFXLElBQUksT0FBTyxPQUFPLENBQUMsU0FBUyxLQUFLLFdBQVcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUM7UUFDckksWUFBWSxDQUFDLG9CQUFvQixHQUFHLENBQUMsT0FBTyxPQUFPLEtBQUssV0FBVyxJQUFJLE9BQU8sT0FBTyxDQUFDLG9CQUFvQixLQUFLLFdBQVcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsb0JBQW9CLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQztRQUNsSyxZQUFZLENBQUMsWUFBWSxHQUFHLENBQUMsT0FBTyxPQUFPLEtBQUssV0FBVyxJQUFJLE9BQU8sT0FBTyxDQUFDLFlBQVksS0FBSyxXQUFXLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLFlBQVksQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDO1FBQzNJLFlBQVksQ0FBQyxnQkFBZ0IsR0FBRyxDQUFDLE9BQU8sT0FBTyxLQUFLLFdBQVcsSUFBSSxPQUFPLE9BQU8sQ0FBQyxnQkFBZ0IsS0FBSyxXQUFXLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLGdCQUFnQixDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUM7UUFFdEosSUFBSSxZQUFZLENBQUMsS0FBSyxJQUFJLFlBQVksQ0FBQyxRQUFRO1lBQUUsWUFBWSxDQUFDLEtBQUssR0FBRyxLQUFLLENBQUM7UUFDNUUsT0FBTyxZQUFZLENBQUM7SUFDeEIsQ0FBQztJQUVELFlBQVksQ0FBQyxRQUFvQjtRQUM3QixJQUFJLFNBQVMsR0FBZSxDQUFDLE9BQU8sUUFBUSxLQUFLLFdBQVcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQztRQUM5RSxPQUFPLFNBQVMsQ0FBQztJQUNyQixDQUFDO0lBRUQsVUFBVSxDQUFDLE9BQVksRUFBRSxZQUF5QixFQUFFLHlCQUF5QixDQUFBLE9BQWdCLEVBQUUsZUFBd0IsS0FBSztRQUN4SCxJQUFJLFlBQVksR0FBUSxFQUFFLFFBQVEsRUFBRSxLQUFLLEVBQUUsYUFBYSxFQUFFLEVBQUUsRUFBRSxDQUFDO1FBQy9ELElBQUksV0FBVyxHQUFRLEVBQUUsQ0FBQztRQUUxQixLQUFLLElBQUksR0FBRyxJQUFJLE9BQU8sRUFBRTtZQUNyQixJQUFJLE9BQU8sQ0FBQyxjQUFjLENBQUMsR0FBRyxDQUFDLEVBQUU7Z0JBQzdCLElBQUksQ0FBQyxjQUFjLEVBQUUsQ0FBQztnQkFFdEIsV0FBVyxHQUFHO29CQUNWLFVBQVUsRUFBRSxPQUFPLENBQUMsR0FBRyxDQUFDLENBQUMsVUFBVTtvQkFDbkMsS0FBSyxFQUFFLENBQUMsT0FBTyxPQUFPLENBQUMsR0FBRyxDQUFDLENBQUMsTUFBTSxLQUFLLFdBQVcsSUFBSSxPQUFPLE9BQU8sQ0FBQyxHQUFHLENBQUMsQ0FBQyxNQUFNLENBQUMsR0FBRyxLQUFLLFdBQVcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsR0FBRztvQkFDckksUUFBUSxFQUFFLEtBQUs7b0JBQ2YsWUFBWSxFQUFFLENBQUMsT0FBTyxPQUFPLENBQUMsR0FBRyxDQUFDLENBQUMsVUFBVSxLQUFLLFdBQVcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsQ0FBQyxVQUFVLENBQUMsQ0FBQyxDQUFDLElBQUk7b0JBQ2hHLGVBQWUsRUFBRSxDQUFDLE9BQU8sT0FBTyxDQUFDLEdBQUcsQ0FBQyxDQUFDLFFBQVEsS0FBSyxXQUFXLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxJQUFJO29CQUMvRixLQUFLLEVBQUUsR0FBRztvQkFDVixNQUFNLEVBQUUsQ0FBQyxPQUFPLE9BQU8sQ0FBQyxHQUFHLENBQUMsQ0FBQyxNQUFNLEtBQUssV0FBVyxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLFNBQVM7b0JBQ3RGLHlDQUF5QztvQkFDekMsK0NBQStDO29CQUMvQywyQ0FBMkM7b0JBQzNDLFFBQVE7b0JBQ1IsaURBQWlEO29CQUNqRCx5Q0FBeUM7b0JBQ3pDLFFBQVE7b0JBQ1IsNEJBQTRCO29CQUM1QixLQUFLO29CQUNMLElBQUksRUFBRSxDQUFDLE9BQU8sT0FBTyxDQUFDLEdBQUcsQ0FBQyxDQUFDLE9BQU8sS0FBSyxXQUFXLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSztvQkFDckYsU0FBUyxFQUFFLFlBQVk7aUJBQzFCLENBQUM7Z0JBRUYsSUFBSSxDQUFDLFdBQVcsQ0FBQyxZQUFZLEVBQUU7b0JBQzNCLFdBQVcsQ0FBQyxVQUFVLENBQUMsR0FBRyxDQUFDLGVBQWUsQ0FBQyxDQUFDO29CQUM1QyxXQUFXLENBQUMsWUFBWSxHQUFHO3dCQUN2QixhQUFhLEVBQUUsTUFBTTt3QkFDckIsVUFBVSxFQUFFLEVBQUU7d0JBQ2QscUJBQXFCLEVBQUUsSUFBSTt3QkFDM0IsTUFBTSxFQUFFLENBQUMsT0FBTyxPQUFPLENBQUMsR0FBRyxDQUFDLENBQUMsU0FBUyxLQUFLLFdBQVcsSUFBSSxPQUFPLENBQUMsR0FBRyxDQUFDLENBQUMsU0FBUyxDQUFDLE1BQU0sR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsU0FBUztxQkFDcEksQ0FBQztpQkFDTDtnQkFFRCxJQUFJLE9BQU8sT0FBTyxDQUFDLEdBQUcsQ0FBQyxDQUFDLE1BQU0sS0FBSyxXQUFXLEVBQUU7b0JBQzVDLElBQUksT0FBTyxPQUFPLENBQUMsR0FBRyxDQUFDLENBQUMsTUFBTSxDQUFDLEtBQUssS0FBSyxXQUFXLElBQUksT0FBTyxDQUFDLEdBQUcsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxLQUFLLEVBQUU7d0JBQy9FLFlBQVksQ0FBQyxRQUFRLEdBQUcsSUFBSSxDQUFDO3FCQUNoQztvQkFFRCxXQUFXLEdBQUcsSUFBSSxDQUFDLGdCQUFnQixDQUFDLFdBQVcsRUFBRSxPQUFPLENBQUMsR0FBRyxDQUFDLENBQUMsTUFBTSxFQUFFLGFBQWEsQ0FBQyxPQUFPLENBQUMsQ0FBQztvQkFFN0YsSUFBSSxXQUFXLENBQUMsY0FBYyxDQUFDLHVCQUF1QixDQUFDLEVBQUU7d0JBQ3JELE9BQU8sV0FBVyxDQUFDLFlBQVksQ0FBQztxQkFDbkM7aUJBQ0o7Z0JBRUQsSUFBSSxPQUFPLFdBQVcsQ0FBQyxNQUFNLEtBQUssV0FBVyxJQUFJLENBQzdDLENBQUMsT0FBTyxXQUFXLENBQUMsTUFBTSxDQUFDLFFBQVEsS0FBSyxXQUFXLElBQUksV0FBVyxDQUFDLE1BQU0sQ0FBQyxRQUFRLENBQUM7b0JBQ25GLENBQUMsT0FBTyxXQUFXLENBQUMsTUFBTSxDQUFDLEtBQUssS0FBSyxXQUFXLElBQUksV0FBVyxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsQ0FBQyxFQUFFO29CQUM1RSxZQUFZLENBQUMsYUFBYSxDQUFDLE9BQU8sQ0FBQyxXQUFXLENBQUMsQ0FBQztpQkFDdkQ7cUJBQ0k7b0JBQ0QsWUFBWSxDQUFDLGFBQWEsQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFDLENBQUM7aUJBQ2hEO2FBQ0o7U0FDSjtRQUVELE9BQU8sWUFBWSxDQUFDO0lBQ3hCLENBQUM7SUFFRCx1QkFBdUIsQ0FBQyxNQUFXO1FBQy9CLElBQUksY0FBYyxHQUFHLE1BQU0sQ0FBQyxXQUFXLENBQUM7UUFFeEMsSUFBSSxNQUFNLENBQUMsUUFBUSxLQUFLLG1CQUFtQixJQUFJLE1BQU0sQ0FBQyxRQUFRLEtBQUssb0JBQW9CLEVBQUU7WUFDckYsY0FBYyxDQUFDLHNCQUFzQixHQUFHLElBQUksQ0FBQztZQUM3QyxjQUFjLENBQUMsdUJBQXVCLEdBQUcsSUFBSSxDQUFDO1lBQzlDLGNBQWMsQ0FBQyxrQkFBa0IsR0FBRyxNQUFNLENBQUMsUUFBUSxDQUFDO1NBQ3ZEO2FBQ0ksSUFBSSxNQUFNLENBQUMsUUFBUSxLQUFLLFNBQVMsRUFBRTtZQUNwQyxjQUFjLENBQUMsc0JBQXNCLEdBQUcsSUFBSSxDQUFDO1lBQzdDLGNBQWMsQ0FBQyx1QkFBdUIsR0FBRyxJQUFJLENBQUM7WUFDOUMsY0FBYyxDQUFDLGtCQUFrQixHQUFHLE1BQU0sQ0FBQyxRQUFRLENBQUM7WUFDcEQsY0FBYyxDQUFDLGVBQWUsR0FBRyxDQUFDLENBQUM7WUFDbkMsY0FBYyxDQUFDLCtCQUErQixHQUFHLENBQUMsQ0FBQztZQUNuRCxjQUFjLENBQUMsWUFBWSxHQUFHLEVBQUUsQ0FBQztTQUNwQzthQUNJO1lBQ0QsY0FBYyxDQUFDLFlBQVksR0FBRyxJQUFJLENBQUM7WUFDbkMsY0FBYyxDQUFDLGFBQWEsR0FBRyxJQUFJLENBQUM7U0FDdkM7UUFFRCxJQUFJLE1BQU0sQ0FBQyxRQUFRLEtBQUssbUJBQW1CLElBQUksTUFBTSxDQUFDLFFBQVEsS0FBSyxvQkFBb0IsRUFBRTtZQUNyRixjQUFjLENBQUMsVUFBVSxHQUFHLElBQUksQ0FBQztTQUNwQzthQUNJO1lBQ0QsY0FBYyxDQUFDLFlBQVksR0FBRyxNQUFNLENBQUMsY0FBYyxDQUFDO1NBQ3ZEO1FBRUQsT0FBTyxjQUFjLENBQUM7SUFDMUIsQ0FBQztJQUVELFlBQVksQ0FBQyxZQUF5QjtRQUNsQyxJQUFJLE9BQU8sR0FBa0IsWUFBWSxDQUFDLFNBQVMsQ0FBQyxhQUFhLEVBQUUsQ0FBQztRQUNwRSxJQUFJLFlBQVksR0FBdUMsRUFBRSxDQUFDO1FBRTFELEtBQUssSUFBSSxDQUFDLEdBQVcsQ0FBQyxFQUFFLENBQUMsR0FBRyxPQUFPLENBQUMsTUFBTSxFQUFFLENBQUMsRUFBRSxFQUFFO1lBQzdDLElBQUksU0FBUyxHQUFRLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxTQUFTLEVBQUUsQ0FBQztZQUM1QyxJQUFJLFFBQVEsR0FBVyxDQUFDLENBQUMsQ0FBQztZQUUxQixJQUFJLFNBQVMsQ0FBQyxTQUFTLENBQUMsT0FBTyxDQUFDLG1CQUFtQixDQUFDLEtBQUssQ0FBQyxDQUFDLEVBQUU7Z0JBQ3pELFFBQVEsR0FBRyxFQUFFLENBQUM7Z0JBQ2QsWUFBWSxDQUFDLFNBQVMsQ0FBQyxjQUFjLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxFQUFFLFFBQVEsQ0FBQyxDQUFDO2FBQy9EO2lCQUNJLElBQUksT0FBTyxTQUFTLENBQUMsTUFBTSxLQUFLLFdBQVcsSUFBSSxPQUFPLFNBQVMsQ0FBQyxNQUFNLENBQUMsTUFBTSxLQUFLLFdBQVcsSUFBSSxTQUFTLENBQUMsTUFBTSxDQUFDLE1BQU0sRUFBRTtnQkFDM0gsUUFBUSxHQUFHLEdBQUcsQ0FBQztnQkFDZixZQUFZLENBQUMsU0FBUyxDQUFDLGNBQWMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLEVBQUUsUUFBUSxDQUFDLENBQUM7YUFDL0Q7aUJBQ0ksSUFBSSxPQUFPLFNBQVMsQ0FBQyxNQUFNLEtBQUssV0FBVyxJQUFJLE9BQU8sU0FBUyxDQUFDLE1BQU0sQ0FBQyxLQUFLLEtBQUssV0FBVyxJQUFJLFNBQVMsQ0FBQyxNQUFNLENBQUMsS0FBSyxFQUFFO2dCQUN6SCxRQUFRLEdBQUcsR0FBRyxDQUFDO2dCQUNmLFlBQVksQ0FBQyxTQUFTLENBQUMsY0FBYyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsRUFBRSxRQUFRLENBQUMsQ0FBQzthQUMvRDtpQkFDSSxJQUFJLE9BQU8sU0FBUyxDQUFDLE1BQU0sS0FBSyxXQUFXLElBQUksT0FBTyxTQUFTLENBQUMsTUFBTSxDQUFDLEtBQUssS0FBSyxXQUFXLElBQUksU0FBUyxDQUFDLE1BQU0sQ0FBQyxLQUFLLEVBQUU7Z0JBQ3pILFFBQVEsR0FBRyxHQUFHLENBQUM7YUFDbEI7aUJBQ0k7Z0JBQ0QsUUFBUSxHQUFHLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxjQUFjLEVBQUUsR0FBRyxFQUFFLENBQUM7YUFDL0M7WUFFRCxZQUFZLENBQUMsSUFBSSxDQUFDLEVBQUMsS0FBSyxFQUFFLFFBQVEsRUFBRSxFQUFFLEVBQUUsU0FBUyxDQUFDLEtBQUssRUFBQyxDQUFDLENBQUM7U0FDN0Q7UUFFRCxPQUFPLFlBQVksQ0FBQztJQUN4QixDQUFDO0lBRUQsYUFBYSxDQUFDLFNBQTZDLEVBQUUsTUFBcUI7UUFDOUUsSUFBSSxLQUFLLEdBQVcsQ0FBQyxDQUFDO1FBQ3RCLEtBQUssSUFBSSxDQUFDLEdBQVcsQ0FBQyxFQUFFLENBQUMsR0FBRyxTQUFTLENBQUMsTUFBTSxFQUFFLENBQUMsRUFBRSxFQUFFO1lBQy9DLElBQUksTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLFNBQVMsRUFBRSxFQUFFO2dCQUN2QixLQUFLLElBQUksU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQzthQUMvQjtTQUNKO1FBRUQsT0FBTyxLQUFLLENBQUM7SUFDakIsQ0FBQztJQUVELGVBQWUsQ0FBQyxJQUFzQjtRQUNsQyxJQUFJLFNBQVMsR0FBZ0IsSUFBSSxDQUFDLE9BQU8sQ0FBQyxhQUFhLENBQUMsYUFBYSxDQUFDLFlBQVksQ0FBQyxDQUFDO1FBQ3BGLElBQUksV0FBVyxHQUFXLElBQUksQ0FBQyxLQUFLLENBQUMsU0FBUyxDQUFDLHFCQUFxQixFQUFFLENBQUMsS0FBSyxDQUFDLENBQUM7UUFDOUUsSUFBSSxhQUFhLEdBQXdCLE1BQU0sQ0FBQyxnQkFBZ0IsQ0FBQyxTQUFTLENBQUMsQ0FBQztRQUM1RSxJQUFJLFVBQVUsR0FBVyxDQUFDLGFBQWEsQ0FBQyxVQUFVLEtBQUssRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxhQUFhLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztRQUNwRyxJQUFJLFdBQVcsR0FBVyxDQUFDLGFBQWEsQ0FBQyxXQUFXLEtBQUssRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxhQUFhLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztRQUN2RyxJQUFJLGVBQWUsR0FBRyxVQUFVLEdBQUcsV0FBVyxDQUFDO1FBQy9DLE9BQU8sV0FBVyxHQUFHLGVBQWUsQ0FBQztJQUN6QyxDQUFDO0lBRUQsaUJBQWlCLENBQUMsUUFBdUI7UUFDckMsSUFBSSxhQUFhLEdBQVcsSUFBSSxDQUFDLGNBQWMsQ0FBQztRQUVoRCxLQUFLLElBQUksQ0FBQyxHQUFXLENBQUMsRUFBRSxDQUFDLEdBQUcsUUFBUSxDQUFDLE1BQU0sRUFBRSxDQUFDLEVBQUUsRUFBRTtZQUM5QyxJQUFJLE1BQU0sR0FBUSxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsU0FBUyxFQUFFLENBQUM7WUFFMUMsSUFBSSxPQUFPLE1BQU0sQ0FBQyxNQUFNLEtBQUssV0FBVyxJQUFJLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLFNBQVMsRUFBRSxFQUFFO2dCQUNsRSxFQUFFLGFBQWEsQ0FBQzthQUNuQjtZQUVELDJCQUEyQjtTQUM5QjtRQUVELE9BQU8sYUFBYSxDQUFDO0lBQ3pCLENBQUM7SUFFRCxpQkFBaUIsQ0FBQyxXQUFnQixFQUFFLE1BQWlCLEVBQUUsSUFBc0I7UUFDekUsSUFBSSxZQUFZLEdBQVcsRUFBRSxHQUFHLENBQUMsQ0FBQztRQUNsQyxJQUFJLE9BQU8sR0FBWSxJQUFJLENBQUMsT0FBTyxDQUFDLGFBQWEsQ0FBQyxhQUFhLENBQUMsUUFBUSxDQUFDLENBQUM7UUFFMUUsSUFBSSxPQUFPLEtBQUssSUFBSSxFQUFFO1lBQ2xCLFlBQVksSUFBSSxPQUFPLENBQUMscUJBQXFCLEVBQUUsQ0FBQyxNQUFNLENBQUM7U0FDMUQ7UUFFRCxLQUFLLElBQUksQ0FBQyxHQUFXLENBQUMsRUFBRSxDQUFDLEdBQUcsTUFBTSxDQUFDLFdBQVcsRUFBRSxFQUFFLENBQUMsRUFBRSxFQUFFO1lBQ25ELFlBQVksSUFBSSxNQUFNLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQztZQUMzQyxJQUFJLFlBQVksR0FBRyxXQUFXLEVBQUU7Z0JBQzVCLE1BQU07YUFDVDtTQUNKO1FBRUQsSUFBSSxZQUFZLEdBQUcsV0FBVyxFQUFFO1lBQzVCLE9BQU8sWUFBWSxDQUFDO1NBQ3ZCO1FBRUQsT0FBTyxXQUFXLENBQUM7SUFDdkIsQ0FBQztJQUVELG9CQUFvQixDQUFDLElBQXNCO1FBQ3ZDLElBQUksV0FBVyxHQUFXLENBQUMsQ0FBQztRQUM1QixJQUFJLFNBQVMsR0FBWSxJQUFJLENBQUMsT0FBTyxDQUFDLGFBQWEsQ0FBQztRQUNwRCxJQUFJLGVBQWUsR0FBWSxTQUFTLENBQUMsYUFBYSxDQUFDLHNCQUFzQixDQUFDLENBQUM7UUFDL0UsSUFBSSxTQUFTLEtBQUssSUFBSSxJQUFJLGVBQWUsS0FBSyxJQUFJO1lBQUUsT0FBTyxXQUFXLENBQUM7UUFDdkUsV0FBVyxJQUFJLElBQUksQ0FBQyxJQUFJLENBQUMsZUFBZSxDQUFDLHFCQUFxQixFQUFFLENBQUMsTUFBTSxDQUFDLENBQUM7UUFDekUsV0FBVyxJQUFJLElBQUksQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLGFBQWEsQ0FBQyxvQkFBb0IsQ0FBQyxDQUFDLHFCQUFxQixFQUFFLENBQUMsTUFBTSxDQUFDLENBQUM7UUFFdkcsSUFBSSxnQkFBZ0IsR0FBWSxTQUFTLENBQUMsYUFBYSxDQUFDLFFBQVEsQ0FBQyxDQUFDO1FBQ2xFLElBQUksZ0JBQWdCLEtBQUssSUFBSSxFQUFFO1lBQzNCLFdBQVcsSUFBSSxJQUFJLENBQUMsSUFBSSxDQUFDLGdCQUFnQixDQUFDLHFCQUFxQixFQUFFLENBQUMsTUFBTSxDQUFDLENBQUM7U0FDN0U7UUFDRCxXQUFXLElBQUksQ0FBQyxDQUFDO1FBQ2pCLE9BQU8sV0FBVyxDQUFDO0lBQ3ZCLENBQUM7SUFFRCxtQkFBbUIsQ0FBQyxLQUFpQixFQUFFLFVBQXNCLEVBQUUsWUFBaUI7UUFDNUUsT0FBTyxJQUFJLENBQUMsZUFBZSxDQUFDLFVBQVUsRUFBRSxJQUFJLENBQUMsaUJBQWlCLENBQUMsWUFBWSxFQUFFLEtBQUssQ0FBQyxDQUFDLENBQUM7SUFDekYsQ0FBQztJQUVELGNBQWMsQ0FBQyxPQUFZLEVBQUUsWUFBcUIsRUFBRSxTQUFrQjtRQUNsRSxJQUFJLFlBQVksRUFBRTtZQUNkLE9BQU8sQ0FBQyxhQUFhLENBQUMsR0FBRztnQkFDckIsTUFBTSxFQUFFO29CQUNKLFFBQVEsRUFBRSxJQUFJO2lCQUNqQjthQUNKLENBQUM7U0FDTDthQUNJLElBQUksU0FBUyxFQUFFO1lBQ2hCLE9BQU8sQ0FBQyxVQUFVLENBQUMsR0FBRztnQkFDbEIsTUFBTSxFQUFFO29CQUNKLEtBQUssRUFBRSxJQUFJO2lCQUNkO2FBQ0osQ0FBQztTQUNMO1FBRUQsT0FBTyxPQUFPLENBQUM7SUFDbkIsQ0FBQztJQUVELGFBQWEsQ0FBQyxRQUFhLEVBQUUsT0FBc0I7UUFDL0MsSUFBSSxPQUFPLFFBQVEsQ0FBQyxNQUFNLEtBQUssV0FBVyxFQUFFO1lBQ3hDLE9BQU8sUUFBUSxDQUFDLE1BQU0sQ0FBQztTQUMxQjtRQUVELEtBQUssSUFBSSxDQUFDLEdBQVcsQ0FBQyxFQUFFLENBQUMsR0FBRyxPQUFPLENBQUMsTUFBTSxFQUFFLENBQUMsRUFBRSxFQUFFO1lBQzdDLElBQUksTUFBTSxHQUFRLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxTQUFTLEVBQUUsQ0FBQztZQUN6QyxJQUFJLE9BQU8sTUFBTSxDQUFDLE1BQU0sS0FBSyxXQUFXO2dCQUNwQyxPQUFPLE1BQU0sQ0FBQyxNQUFNLENBQUMsTUFBTSxLQUFLLFdBQVc7Z0JBQzNDLE1BQU0sQ0FBQyxNQUFNLENBQUMsTUFBTSxFQUFFO2dCQUNsQixPQUFPLE1BQU0sQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDO2FBQ2xDO1NBQ0o7UUFDRCxPQUFPLEVBQUUsQ0FBQztJQUNkLENBQUM7SUFFRCxzQkFBc0IsQ0FBQyxTQUFnQjtRQUNuQyxJQUFJLE9BQU8sR0FBNkIsU0FBUyxDQUFDLE1BQU0sQ0FBQztRQUN6RCxJQUFJLFNBQVMsR0FBa0IsQ0FBQyxZQUFZLEVBQUUsc0JBQXNCLEVBQUUsaUJBQWlCLENBQUMsQ0FBQztRQUV6RixLQUFLLElBQUksQ0FBQyxHQUFXLENBQUMsRUFBRSxDQUFDLEdBQUcsU0FBUyxDQUFDLE1BQU0sRUFBRSxDQUFDLEVBQUUsRUFBRTtZQUMvQyxJQUFJLE9BQU8sQ0FBQyxTQUFTLENBQUMsUUFBUSxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFO2dCQUMxQyxPQUFPLEtBQUssQ0FBQzthQUNoQjtTQUNKO1FBRUQsT0FBTyxJQUFJLENBQUM7SUFDaEIsQ0FBQztJQUVELG1CQUFtQixDQUFDLE9BQVk7UUFDNUIsSUFBSSxPQUFPLENBQUMsU0FBUyxDQUFDLE9BQU8sQ0FBQyxtQkFBbUIsQ0FBQyxLQUFLLENBQUMsQ0FBQyxFQUFFO1lBQ3ZELE9BQU8sSUFBSSxDQUFDO1NBQ2Y7UUFFRCxJQUFJLE9BQU8sT0FBTyxDQUFDLE1BQU0sS0FBSyxXQUFXO1lBQ3JDLENBQUMsQ0FBQyxPQUFPLE9BQU8sQ0FBQyxNQUFNLENBQUMsS0FBSyxLQUFLLFdBQVcsSUFBSSxPQUFPLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQztnQkFDckUsQ0FBQyxPQUFPLE9BQU8sQ0FBQyxNQUFNLENBQUMsTUFBTSxLQUFLLFdBQVcsSUFBSSxPQUFPLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxDQUFDLEVBQzNFO1lBQ0UsT0FBTyxJQUFJLENBQUM7U0FDZjtRQUVELE9BQU8sS0FBSyxDQUFDO0lBQ2pCLENBQUM7SUFFTyxnQkFBZ0IsQ0FBQyxPQUFZLEVBQUUsT0FBWSxFQUFFLHdCQUF3QixDQUFDLE9BQWdCO1FBQzFGLElBQUksYUFBYSxHQUFjLE1BQU8sQ0FBQyxNQUFNLENBQUMsRUFBRSxFQUFFLE9BQU8sQ0FBQyxDQUFDO1FBRTNELCtEQUErRDtRQUMvRCx5Q0FBeUM7UUFDekMsNENBQTRDO1FBQzVDLDJDQUEyQztRQUMzQyxzREFBc0Q7UUFDdEQsSUFBSTtRQUVKLHNFQUFzRTtRQUN0RSx5Q0FBeUM7UUFDekMsNENBQTRDO1FBQzVDLDhDQUE4QztRQUM5QyxpQ0FBaUM7UUFDakMsbURBQW1EO1FBQ25ELDBEQUEwRDtRQUUxRCw2QkFBNkI7UUFDN0IsSUFBSTtRQUVKLG9FQUFvRTtRQUNwRSx5Q0FBeUM7UUFDekMsNENBQTRDO1FBQzVDLDhDQUE4QztRQUM5QyxpQ0FBaUM7UUFDakMsNENBQTRDO1FBQzVDLHVEQUF1RDtRQUV2RCw2QkFBNkI7UUFDN0IsSUFBSTtRQUVKLDBFQUEwRTtRQUMxRSx5Q0FBeUM7UUFDekMsNENBQTRDO1FBQzVDLDhDQUE4QztRQUM5QyxnQ0FBZ0M7UUFDaEMsZ0VBQWdFO1FBQ2hFLHdDQUF3QztRQUN4QywrREFBK0Q7UUFDL0Qsa0VBQWtFO1FBRWxFLDZCQUE2QjtRQUM3QixJQUFJO1FBRUosb0VBQW9FO1FBQ3BFLHlDQUF5QztRQUN6Qyw0Q0FBNEM7UUFDNUMsOENBQThDO1FBQzlDLGdDQUFnQztRQUNoQyxnRUFBZ0U7UUFDaEUscUNBQXFDO1FBQ3JDLCtEQUErRDtRQUMvRCxxQ0FBcUM7UUFFckMsNkJBQTZCO1FBQzdCLElBQUk7UUFFSixnRkFBZ0Y7UUFDNUUsdURBQXVEO1FBQ3ZELGlEQUFpRDtRQUNqRCwrQ0FBK0M7UUFDL0MsaURBQWlEO1FBQ2pELHNFQUFzRTtRQUN0RSx1R0FBdUc7UUFDdkcsb0VBQW9FO1FBQ3BFLGdCQUFnQjtRQUNoQixtQ0FBbUM7UUFDbkMsWUFBWTtRQUNaLGlCQUFpQjtRQUNqQixnR0FBZ0c7UUFDaEcsb0RBQW9EO1FBQ3BELFlBQVk7UUFDWixRQUFRO1FBQ1IsMkJBQTJCO1FBQzNCLElBQUk7UUFDUixJQUFJO1FBRUosT0FBTyxhQUFhLENBQUM7SUFDekIsQ0FBQztJQUVPLGlCQUFpQixDQUFDLFlBQWlCLEVBQUUsS0FBaUI7UUFDMUQsSUFBSSxZQUFZLEdBQWUsS0FBSyxDQUFDLEtBQUssRUFBRSxDQUFDO1FBRTdDLElBQUksT0FBTyxZQUFZLEtBQUssV0FBVyxJQUFJLE1BQU0sQ0FBQyxJQUFJLENBQUMsWUFBWSxDQUFDLENBQUMsTUFBTSxLQUFLLENBQUMsRUFBRTtZQUMvRSxPQUFPLFlBQVksQ0FBQztTQUN2QjtRQUVELElBQUksV0FBVyxHQUFlLEVBQUUsQ0FBQztRQUNqQyxLQUFLLElBQUksR0FBRyxJQUFJLFlBQVksRUFBRTtZQUMxQixJQUFJLFlBQVksQ0FBQyxjQUFjLENBQUMsR0FBRyxDQUFDLEVBQUU7Z0JBQ2xDLEtBQUssSUFBSSxDQUFDLEdBQVcsQ0FBQyxFQUFFLENBQUMsR0FBRyxZQUFZLENBQUMsR0FBRyxDQUFDLENBQUMsTUFBTSxFQUFFLENBQUMsRUFBRSxFQUFFO29CQUN2RCxLQUFLLElBQUksQ0FBQyxHQUFXLENBQUMsRUFBRSxDQUFDLEdBQUcsS0FBSyxDQUFDLE1BQU0sRUFBRSxDQUFDLEVBQUUsRUFBRTt3QkFDM0MsSUFBSSxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLEtBQUssWUFBWSxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFOzRCQUN4QyxXQUFXLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO3lCQUM5QjtxQkFDSjtpQkFDSjthQUNKO1NBQ0o7UUFFRCxPQUFPLFdBQVcsQ0FBQztJQUN2QixDQUFDO0lBRU8sZUFBZSxDQUFDLFVBQXNCLEVBQUUsS0FBaUI7UUFDN0QsSUFBSSxVQUFVLEdBQWUsS0FBSyxDQUFDLEtBQUssRUFBRSxDQUFDO1FBRTNDLElBQUksT0FBTyxVQUFVLEtBQUssV0FBVyxJQUFJLFVBQVUsQ0FBQyxNQUFNLEtBQUssQ0FBQyxFQUFFO1lBQzlELE9BQU8sVUFBVSxDQUFDO1NBQ3JCO1FBRUQsVUFBVSxDQUFDLElBQUksQ0FBQyxDQUFDLENBQU0sRUFBRSxDQUFNLEVBQVUsRUFBRTtZQUN2QyxLQUFLLElBQUksQ0FBQyxHQUFXLENBQUMsRUFBRSxDQUFDLEdBQUcsVUFBVSxDQUFDLE1BQU0sRUFBRSxDQUFDLEVBQUUsRUFBRTtnQkFDaEQsSUFBSSxZQUFZLEdBQVEsVUFBVSxDQUFDLENBQUMsQ0FBQyxDQUFDO2dCQUN0QyxJQUFJLElBQUksR0FBUSxDQUFDLENBQUMsWUFBWSxDQUFDLEtBQUssQ0FBQyxDQUFDO2dCQUN0QyxJQUFJLElBQUksR0FBUSxDQUFDLENBQUMsWUFBWSxDQUFDLEtBQUssQ0FBQyxDQUFDO2dCQUV0QyxJQUFJLElBQUksS0FBSyxJQUFJLEVBQUU7b0JBQ2YsU0FBUztpQkFDWjtnQkFFRCxJQUFJLFNBQVMsR0FBRyxDQUFDLFlBQVksQ0FBQyxJQUFJLEtBQUssS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7Z0JBRXZELElBQUksSUFBSSxHQUFHLElBQUksRUFBRTtvQkFDYixPQUFPLFNBQVMsQ0FBQztpQkFDcEI7cUJBQ0k7b0JBQ0QsT0FBTyxTQUFTLEdBQUcsQ0FBQyxDQUFDLENBQUM7aUJBQ3pCO2FBQ0g7WUFFRixPQUFPLENBQUMsQ0FBQztRQUNiLENBQUMsQ0FBQyxDQUFDO1FBQ0gsT0FBTyxVQUFVLENBQUM7SUFDdEIsQ0FBQztJQUVPLGdCQUFnQixDQUFDLE9BQVk7UUFDakMsSUFBSSxhQUFhLEdBQVcsR0FBRyxDQUFDO1FBRWhDLElBQUksT0FBTyxPQUFPLEtBQUssV0FBVyxFQUFFO1lBQ2hDLE9BQU8sYUFBYSxDQUFDO1NBQ3hCO2FBRUksSUFBSSxPQUFPLE9BQU8sQ0FBQyxVQUFVLEtBQUssV0FBVztZQUM5QyxPQUFPLE9BQU8sQ0FBQyxVQUFVLEtBQUssUUFBUTtZQUN0QyxPQUFPLENBQUMsVUFBVSxLQUFLLE1BQU0sRUFBRTtZQUMzQixPQUFPLE9BQU8sQ0FBQyxVQUFVLENBQUM7U0FDakM7YUFDSSxJQUFJLE9BQU8sT0FBTyxDQUFDLFVBQVUsS0FBSyxXQUFXO1lBQzlDLE9BQU8sT0FBTyxDQUFDLFVBQVUsS0FBSyxRQUFRLEVBQUU7WUFDcEMsT0FBTyxPQUFPLENBQUMsVUFBVSxDQUFDO1NBQ2pDO1FBRUQsT0FBTyxhQUFhLENBQUM7SUFDekIsQ0FBQztJQUVELHVFQUF1RTtJQUN2RSw0Q0FBNEM7SUFDNUMsOERBQThEO0lBQzlELCtDQUErQztJQUMvQyxnREFBZ0Q7SUFDaEQsUUFBUTtJQUNSLGlEQUFpRDtJQUNqRCw4REFBOEQ7SUFDOUQsK0NBQStDO0lBQy9DLDRIQUE0SDtJQUM1SCxRQUFRO0lBRVIsd0JBQXdCO0lBQ3hCLElBQUk7SUFFSSxvQkFBb0IsQ0FBQyxTQUFpQjtRQUMxQyxJQUFJLFNBQVMsS0FBSyxVQUFVO1lBQUUsT0FBTyxVQUFVLENBQUM7UUFDaEQsSUFBSSxTQUFTLEtBQUssbUJBQW1CLElBQUksU0FBUyxLQUFLLG9CQUFvQjtZQUFFLE9BQU8sWUFBWSxDQUFDO1FBQ2pHLE9BQU8sRUFBRSxDQUFDO0lBQ2QsQ0FBQztJQUVPLGNBQWMsQ0FBQyxPQUFZO1FBQy9CLElBQUksZUFBZSxHQUFXLFFBQVEsQ0FBQztRQUV2QyxJQUFJLE9BQU8sT0FBTyxLQUFLLFdBQVcsSUFBSSxPQUFPLE9BQU8sQ0FBQyxRQUFRLEtBQUssV0FBVyxFQUFFO1lBQzNFLE9BQU8sZUFBZSxDQUFDO1NBQzFCO1FBRUQsSUFBSSxPQUFPLENBQUMsUUFBUSxLQUFLLFFBQVE7WUFDN0IsT0FBTyxDQUFDLFFBQVEsS0FBSyxtQkFBbUI7WUFDeEMsT0FBTyxDQUFDLFFBQVEsS0FBSyxTQUFTO1lBQzlCLE9BQU8sQ0FBQyxRQUFRLEtBQUssb0JBQW9CLEVBQUU7WUFDdkMsT0FBTyxPQUFPLENBQUMsUUFBUSxDQUFDO1NBQy9CO1FBRUQsT0FBTyxlQUFlLENBQUM7SUFDM0IsQ0FBQztJQUVPLGNBQWMsQ0FBQyxPQUFZLEVBQUUsU0FBaUI7UUFDbEQsSUFBSSxTQUFTLEtBQUssUUFBUTtZQUFFLE9BQU8sQ0FBQyxDQUFDLENBQUM7UUFDdEMsSUFBSSxPQUFPLE9BQU8sS0FBSyxXQUFXLElBQUksT0FBTyxPQUFPLENBQUMsUUFBUSxLQUFLLFdBQVc7WUFBRSxPQUFPLE9BQU8sQ0FBQyxRQUFRLENBQUM7UUFDdkcsT0FBTyxFQUFFLENBQUM7SUFDZCxDQUFDO0lBRU8sYUFBYSxDQUFDLE9BQVk7UUFDOUIsSUFBSSxXQUFXLEdBQVEsSUFBSSxDQUFDO1FBQzVCLElBQUksTUFBTSxHQUFlLFdBQVcsQ0FBQyxVQUFVLENBQUM7UUFDaEQsSUFBSSxTQUFTLEdBQVcsRUFBRSxDQUFDO1FBQzNCLEtBQUssSUFBSSxDQUFDLEdBQVcsQ0FBQyxFQUFFLENBQUMsR0FBRyxNQUFNLENBQUMsTUFBTSxFQUFFLENBQUMsRUFBRSxFQUFFO1lBQzVDLElBQUksT0FBTyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxLQUFLLFdBQVcsRUFBRTtnQkFDekMsSUFBSSxPQUFPLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsS0FBSyxLQUFLLFdBQVcsSUFBSSxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLEtBQUs7b0JBQUUsT0FBTyxHQUFHLENBQUM7cUJBQ25GLElBQUksT0FBTyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLFFBQVEsS0FBSyxXQUFXLElBQUksTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxRQUFRO29CQUFFLE9BQU8sR0FBRyxDQUFDO3FCQUM5RixJQUFJLE9BQU8sTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxLQUFLLEtBQUssV0FBVyxJQUFJLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsS0FBSyxFQUFFO29CQUM5RSxJQUFJLE9BQU8sQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxZQUFZLEtBQUs7d0JBQUUsT0FBTyxTQUFTLEdBQUcsT0FBTyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsTUFBTSxDQUFDO2lCQUMvRzthQUNKO1NBQ0o7UUFDRCxPQUFPLEVBQUUsQ0FBQztJQUNkLENBQUM7SUFFTyxlQUFlLENBQUMsV0FBdUI7UUFDM0MsSUFBSSxnQkFBZ0IsR0FBZSxFQUFFLENBQUM7UUFDdEMsS0FBSyxJQUFJLENBQUMsR0FBVyxDQUFDLEVBQUUsQ0FBQyxHQUFHLFdBQVcsQ0FBQyxNQUFNLEVBQUUsQ0FBQyxFQUFFLEVBQUU7WUFDakQsZ0JBQWdCLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxZQUFZLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztTQUM1RDtRQUNELE9BQU8sZ0JBQWdCLENBQUM7SUFDNUIsQ0FBQztJQUVPLFlBQVksQ0FBQyxXQUFnQjtRQUNqQyxJQUFJLGFBQWEsR0FBUTtZQUNyQixJQUFJLEVBQUUsSUFBSTtZQUNWLEtBQUssRUFBRSxFQUFFO1lBQ1QsSUFBSSxFQUFFLEVBQUU7WUFDUixNQUFNLEVBQUUsSUFBSTtZQUNaLFFBQVEsRUFBRSxJQUFJO1lBQ2QsSUFBSSxFQUFFLElBQUk7U0FDYixDQUFDO1FBQ0YsT0FBTyxNQUFNLENBQUMsTUFBTSxDQUFDLGFBQWEsRUFBRSxXQUFXLENBQUMsQ0FBQztJQUNyRCxDQUFDOzs7WUF0akJKLFVBQVUiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBJbmplY3RhYmxlLCBWaWV3Q29udGFpbmVyUmVmIH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XHJcbmltcG9ydCB7IFJvdXRlciB9IGZyb20gJ0Bhbmd1bGFyL3JvdXRlcic7XHJcbmltcG9ydCB7IEdyaWRPcHRpb25zLCBDb2x1bW4sIElSb3dNb2RlbCB9IGZyb20gJ2FnLWdyaWQtY29tbXVuaXR5JztcclxuLy8gaW1wb3J0IHtcclxuLy8gICAgIEtkQUdEcm9wZG93bixcclxuLy8gICAgIEtkQUdQaG90byxcclxuLy8gICAgIEtkQUdGb3JtLFxyXG4vLyAgICAgS2RBR0NoZWNrYm94UmFkaW9cclxuLy8gfSBmcm9tICcuL2FnLWdyaWQtY29tcG9uZW50cy9rZC1hZ2dyaWQtY29tcG9uZW50cyc7XHJcblxyXG5ASW5qZWN0YWJsZSgpXHJcbmV4cG9ydCBjbGFzcyBLZEFnZ3JpZFN2YyB7XHJcbiAgICBwcml2YXRlIF9yZXNpemVhYmxlQ29sOiBudW1iZXIgPSAwO1xyXG4gICAgLy8gcHJpdmF0ZSBfZGF0YVN2YzogS2REYXRhU3ZjID0gbmV3IEtkRGF0YVN2YygpO1xyXG5cclxuICAgIGdldEdyaWRPcHRpb25zKCk6IGFueSB7XHJcbiAgICAgICAgbGV0IG9wdGlvbnM6IGFueSA9IHtcclxuICAgICAgICAgICAgcm93RGF0YTogW10sXHJcbiAgICAgICAgICAgIGNvbHVtbkRlZnM6IFtdLFxyXG4gICAgICAgICAgICAvLyBkZWJ1ZzogdHJ1ZSxcclxuICAgICAgICAgICAgaGVhZGVySGVpZ2h0OiAzOCxcclxuICAgICAgICAgICAgZ2V0Um93SGVpZ2h0OiB0aGlzLl9nZXRSb3dIZWlnaHQsXHJcbiAgICAgICAgICAgIC8vIGFuaW1hdGVSb3dzOiB0cnVlLFxyXG4gICAgICAgICAgICAvLyByb3dCdWZmZXI6IDUsXHJcbiAgICAgICAgICAgIHN1cHByZXNzQ29udGV4dE1lbnU6IHRydWUsXHJcbiAgICAgICAgICAgIC8vIHN1cHByZXNzTWVudU1haW5QYW5lbDogdHJ1ZSxcclxuICAgICAgICAgICAgLy8gc3VwcHJlc3NNZW51Q29sdW1uUGFuZWw6IHRydWUsXHJcbiAgICAgICAgICAgIHN1cHByZXNzTW92YWJsZUNvbHVtbnM6IHRydWUsXHJcbiAgICAgICAgICAgIHN1cHByZXNzTWVudUhpZGU6IHRydWUsXHJcbiAgICAgICAgICAgIHN1cHByZXNzQ29sdW1uVmlydHVhbGlzYXRpb246IHRydWUsXHJcbiAgICAgICAgICAgIHVuU29ydEljb246IHRydWUsXHJcbiAgICAgICAgICAgIGljb25zOiB7XHJcbiAgICAgICAgICAgICAgICBmaWx0ZXI6ICc8aSBjbGFzcz1cImZhIGZhLWZpbHRlclwiLz4nLFxyXG4gICAgICAgICAgICAgICAgc29ydEFzY2VuZGluZzogJzxpIGNsYXNzPVwiZmEgZmEtY2FyZXQtZG93blwiLz4nLFxyXG4gICAgICAgICAgICAgICAgc29ydERlc2NlbmRpbmc6ICc8aSBjbGFzcz1cImZhIGZhLWNhcmV0LXVwXCIvPicsXHJcbiAgICAgICAgICAgICAgICBzb3J0VW5Tb3J0OiAnPGkgY2xhc3M9XCJmYSBmYS1zb3J0XCIvPicsXHJcbiAgICAgICAgICAgICAgICBncm91cEV4cGFuZGVkOiAnPGkgY2xhc3M9XCJmYSBmYS1taW51cy1jaXJjbGVcIi8+JyxcclxuICAgICAgICAgICAgICAgIGdyb3VwQ29udHJhY3RlZDogJzxpIGNsYXNzPVwiZmEgZmEtcGx1cy1jaXJjbGVcIi8+JyxcclxuICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgb3ZlcmxheU5vUm93c1RlbXBsYXRlOiAnPHNwYW4gY2xhc3M9XCJhZy1jdXN0b20tb3ZlcmxheVwiPjxpIGNsYXNzPVwiZmEgZmEtaW5mby1jaXJjbGUgZmEtbGcgbWFyZ2luLXJpZ2h0MTBcIj48L2k+Tm8gc3R1ZGVudCByZWNvcmQgZm91bmQ8L3NwYW4+J1xyXG4gICAgICAgIH07XHJcbiAgICAgICAgcmV0dXJuIG9wdGlvbnM7XHJcbiAgICB9XHJcblxyXG4gICAgc2V0UmVzdWx0KF9jb25maWc6IGFueSk6IGFueSB7XHJcbiAgICAgICAgbGV0IHVwZGF0ZVJlc3VsdDogYW55ID0ge307XHJcbiAgICAgICAgdXBkYXRlUmVzdWx0LmlkID0gKHR5cGVvZiBfY29uZmlnICE9PSAndW5kZWZpbmVkJyAmJiB0eXBlb2YgX2NvbmZpZy5pZCAhPT0gJ3VuZGVmaW5lZCcpID8gX2NvbmZpZy5pZCA6ICdrZC1ncmlkJztcclxuICAgICAgICB1cGRhdGVSZXN1bHQuZ3JpZEhlaWdodCA9IHRoaXMuX2NoZWNrR3JpZEhlaWdodChfY29uZmlnKTtcclxuICAgICAgICB1cGRhdGVSZXN1bHQuY2hlY2tib3ggPSAodHlwZW9mIF9jb25maWcgIT09ICd1bmRlZmluZWQnICYmIHR5cGVvZiBfY29uZmlnLmNoZWNrYm94ICE9PSAndW5kZWZpbmVkJykgPyBfY29uZmlnLmNoZWNrYm94IDogZmFsc2U7XHJcbiAgICAgICAgdXBkYXRlUmVzdWx0LnJhZGlvID0gKHR5cGVvZiBfY29uZmlnICE9PSAndW5kZWZpbmVkJyAmJiB0eXBlb2YgX2NvbmZpZy5yYWRpbyAhPT0gJ3VuZGVmaW5lZCcpID8gX2NvbmZpZy5yYWRpbyA6IGZhbHNlO1xyXG4gICAgICAgIHVwZGF0ZVJlc3VsdC5leHRlcm5hbEZpbHRlciA9ICh0eXBlb2YgX2NvbmZpZyAhPT0gJ3VuZGVmaW5lZCcgJiYgdHlwZW9mIF9jb25maWcuZXh0ZXJuYWxGaWx0ZXIgIT09ICd1bmRlZmluZWQnKSA/IF9jb25maWcuZXh0ZXJuYWxGaWx0ZXIgOiBmYWxzZTtcclxuICAgICAgICB1cGRhdGVSZXN1bHQubG9hZFR5cGUgPSB0aGlzLl9jaGVja0xvYWRUeXBlKF9jb25maWcpO1xyXG4gICAgICAgIHVwZGF0ZVJlc3VsdC5wYWdpbmF0aW9uVHlwZSA9IHRoaXMuX2NoZWNrUGFnaW5hdGlvblR5cGUodXBkYXRlUmVzdWx0LmxvYWRUeXBlKTtcclxuICAgICAgICB1cGRhdGVSZXN1bHQucGFnZXNpemUgPSB0aGlzLl9jaGVja1BhZ2VzaXplKF9jb25maWcsIHVwZGF0ZVJlc3VsdC5sb2FkVHlwZSk7XHJcbiAgICAgICAgdXBkYXRlUmVzdWx0LnRvdGFsRGF0YSA9ICh0eXBlb2YgX2NvbmZpZyAhPT0gJ3VuZGVmaW5lZCcgJiYgdHlwZW9mIF9jb25maWcudG90YWxEYXRhICE9PSAndW5kZWZpbmVkJykgPyBfY29uZmlnLnRvdGFsRGF0YSA6IC0xO1xyXG4gICAgICAgIHVwZGF0ZVJlc3VsdC5idXR0b24gPSAodHlwZW9mIF9jb25maWcgIT09ICd1bmRlZmluZWQnICYmIHR5cGVvZiBfY29uZmlnLmJ1dHRvbiAhPT0gJ3VuZGVmaW5lZCcpID8gX2NvbmZpZy5idXR0b24gOiBmYWxzZTtcclxuICAgICAgICB1cGRhdGVSZXN1bHQuYnV0dG9uQ29uZmlnID0gKHR5cGVvZiBfY29uZmlnICE9PSAndW5kZWZpbmVkJyAmJiB0eXBlb2YgX2NvbmZpZy5idXR0b25Db25maWcgIT09ICd1bmRlZmluZWQnKSA/IHRoaXMuX2NoZWNrQnRuQ29uZmlnKF9jb25maWcuYnV0dG9uQ29uZmlnKSA6IG51bGw7XHJcbiAgICAgICAgdXBkYXRlUmVzdWx0LmFsaWdubWVudCA9ICh0eXBlb2YgX2NvbmZpZyAhPT0gJ3VuZGVmaW5lZCcgJiYgdHlwZW9mIF9jb25maWcuYWxpZ25tZW50ICE9PSAndW5kZWZpbmVkJykgPyBfY29uZmlnLmFsaWdubWVudCA6ICdtaWRkbGUnO1xyXG4gICAgICAgIHVwZGF0ZVJlc3VsdC5zdXBwcmVzc0hlaWdodFJlc2l6ZSA9ICh0eXBlb2YgX2NvbmZpZyAhPT0gJ3VuZGVmaW5lZCcgJiYgdHlwZW9mIF9jb25maWcuc3VwcHJlc3NIZWlnaHRSZXNpemUgIT09ICd1bmRlZmluZWQnKSA/IF9jb25maWcuc3VwcHJlc3NIZWlnaHRSZXNpemUgOiB0cnVlO1xyXG4gICAgICAgIHVwZGF0ZVJlc3VsdC5yb3dDbGlja2FibGUgPSAodHlwZW9mIF9jb25maWcgIT09ICd1bmRlZmluZWQnICYmIHR5cGVvZiBfY29uZmlnLnJvd0NsaWNrYWJsZSAhPT0gJ3VuZGVmaW5lZCcpID8gX2NvbmZpZy5yb3dDbGlja2FibGUgOiBmYWxzZTtcclxuICAgICAgICB1cGRhdGVSZXN1bHQucm93TWFwQWN0aW9uVHlwZSA9ICh0eXBlb2YgX2NvbmZpZyAhPT0gJ3VuZGVmaW5lZCcgJiYgdHlwZW9mIF9jb25maWcucm93TWFwQWN0aW9uVHlwZSAhPT0gJ3VuZGVmaW5lZCcpID8gX2NvbmZpZy5yb3dNYXBBY3Rpb25UeXBlIDogbnVsbDtcclxuXHJcbiAgICAgICAgaWYgKHVwZGF0ZVJlc3VsdC5yYWRpbyAmJiB1cGRhdGVSZXN1bHQuY2hlY2tib3gpIHVwZGF0ZVJlc3VsdC5yYWRpbyA9IGZhbHNlO1xyXG4gICAgICAgIHJldHVybiB1cGRhdGVSZXN1bHQ7XHJcbiAgICB9XHJcblxyXG4gICAgc2V0Um93UmVzdWx0KF9yb3dEYXRhOiBBcnJheTxhbnk+KTogQXJyYXk8YW55PiB7XHJcbiAgICAgICAgbGV0IHRhYmxlRGF0YTogQXJyYXk8YW55PiA9ICh0eXBlb2YgX3Jvd0RhdGEgIT09ICd1bmRlZmluZWQnKSA/IF9yb3dEYXRhIDogW107XHJcbiAgICAgICAgcmV0dXJuIHRhYmxlRGF0YTtcclxuICAgIH1cclxuXHJcbiAgICBzZXRDb2xEZWZzKF9jb2xEZWY6IGFueSwgX2dyaWRPcHRpb25zOiBHcmlkT3B0aW9ucywgLypfZGF0YVN2YzogS2REYXRhU3ZjLCAqL19yb3V0ZXI/OiBSb3V0ZXIsIF9pc1JlY3Vyc2l2ZTogYm9vbGVhbiA9IGZhbHNlKTogYW55IHtcclxuICAgICAgICBsZXQgY29sRGVmQ29uZmlnOiBhbnkgPSB7IGVkaXRNb2RlOiBmYWxzZSwgdXBkYXRlZENvbERlZjogW10gfTtcclxuICAgICAgICBsZXQgdGFibGVDb2x1bW46IGFueSA9IHt9O1xyXG5cclxuICAgICAgICBmb3IgKGxldCBrZXkgaW4gX2NvbERlZikge1xyXG4gICAgICAgICAgICBpZiAoX2NvbERlZi5oYXNPd25Qcm9wZXJ0eShrZXkpKSB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLl9yZXNpemVhYmxlQ29sKys7XHJcblxyXG4gICAgICAgICAgICAgICAgdGFibGVDb2x1bW4gPSB7XHJcbiAgICAgICAgICAgICAgICAgICAgaGVhZGVyTmFtZTogX2NvbERlZltrZXldLmhlYWRlck5hbWUsXHJcbiAgICAgICAgICAgICAgICAgICAgZmllbGQ6ICh0eXBlb2YgX2NvbERlZltrZXldLmNvbmZpZyAhPT0gJ3VuZGVmaW5lZCcgJiYgdHlwZW9mIF9jb2xEZWZba2V5XS5jb25maWcubWFwICE9PSAndW5kZWZpbmVkJykgPyBfY29sRGVmW2tleV0uY29uZmlnLm1hcCA6IGtleSxcclxuICAgICAgICAgICAgICAgICAgICBlZGl0YWJsZTogZmFsc2UsIC8vICh0eXBlb2YgX2NvbERlZltrZXldLmVkaXRhYmxlICE9PSAndW5kZWZpbmVkJykgPyBfY29sRGVmW2tleV0uZWRpdGFibGUgOiBmYWxzZSxcclxuICAgICAgICAgICAgICAgICAgICBzdXBwcmVzc01lbnU6ICh0eXBlb2YgX2NvbERlZltrZXldLmZpbHRlcmFibGUgIT09ICd1bmRlZmluZWQnKSA/ICFfY29sRGVmW2tleV0uZmlsdGVyYWJsZSA6IHRydWUsXHJcbiAgICAgICAgICAgICAgICAgICAgc3VwcHJlc3NTb3J0aW5nOiAodHlwZW9mIF9jb2xEZWZba2V5XS5zb3J0YWJsZSAhPT0gJ3VuZGVmaW5lZCcpID8gIV9jb2xEZWZba2V5XS5zb3J0YWJsZSA6IHRydWUsXHJcbiAgICAgICAgICAgICAgICAgICAgY29sSWQ6IGtleSxcclxuICAgICAgICAgICAgICAgICAgICBjb25maWc6ICh0eXBlb2YgX2NvbERlZltrZXldLmNvbmZpZyAhPT0gJ3VuZGVmaW5lZCcpID8gX2NvbERlZltrZXldLmNvbmZpZyA6IHVuZGVmaW5lZCxcclxuICAgICAgICAgICAgICAgICAgICAvLyBjZWxsUmVuZGVyZXI6IChfcGFyYW1zOiBhbnkpOiBhbnkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgIC8vICAgICBpZiAodHlwZW9mIF9wYXJhbXMudmFsdWUgPT09ICdudW1iZXInKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgLy8gICAgICAgICByZXR1cm4gX3BhcmFtcy52YWx1ZS50b1N0cmluZygpO1xyXG4gICAgICAgICAgICAgICAgICAgIC8vICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgLy8gICAgIGVsc2UgaWYgKF9wYXJhbXMudmFsdWUgaW5zdGFuY2VvZiBBcnJheSkge1xyXG4gICAgICAgICAgICAgICAgICAgIC8vICAgICAgICAgSlNPTi5zdHJpbmdpZnkoX3BhcmFtcy52YWx1ZSk7XHJcbiAgICAgICAgICAgICAgICAgICAgLy8gICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAvLyAgICAgcmV0dXJuIF9wYXJhbXMudmFsdWU7XHJcbiAgICAgICAgICAgICAgICAgICAgLy8gfSxcclxuICAgICAgICAgICAgICAgICAgICBoaWRlOiAodHlwZW9mIF9jb2xEZWZba2V5XS52aXNpYmxlICE9PSAndW5kZWZpbmVkJykgPyAhKF9jb2xEZWZba2V5XS52aXNpYmxlKSA6IGZhbHNlLFxyXG4gICAgICAgICAgICAgICAgICAgIGNlbGxDbGFzczogJ2FnLWRlZmF1bHQnXHJcbiAgICAgICAgICAgICAgICB9O1xyXG5cclxuICAgICAgICAgICAgICAgIGlmICghdGFibGVDb2x1bW4uc3VwcHJlc3NNZW51KSB7XHJcbiAgICAgICAgICAgICAgICAgICAgdGFibGVDb2x1bW5bJ21lbnVUYWJzJ10gPSBbJ2ZpbHRlck1lbnVUYWInXTtcclxuICAgICAgICAgICAgICAgICAgICB0YWJsZUNvbHVtbi5maWx0ZXJQYXJhbXMgPSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG5ld1Jvd3NBY3Rpb246ICdrZWVwJyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgY2VsbEhlaWdodDogMzAsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHNlbGVjdEFsbE9uTWluaUZpbHRlcjogdHJ1ZSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWVzOiAodHlwZW9mIF9jb2xEZWZba2V5XS5maWx0ZXJWYWwgIT09ICd1bmRlZmluZWQnICYmIF9jb2xEZWZba2V5XS5maWx0ZXJWYWwubGVuZ3RoID4gMCkgPyBfY29sRGVmW2tleV0uZmlsdGVyVmFsIDogdW5kZWZpbmVkXHJcbiAgICAgICAgICAgICAgICAgICAgfTtcclxuICAgICAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgICAgICBpZiAodHlwZW9mIF9jb2xEZWZba2V5XS5jb25maWcgIT09ICd1bmRlZmluZWQnKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKHR5cGVvZiBfY29sRGVmW2tleV0uY29uZmlnLmlucHV0ICE9PSAndW5kZWZpbmVkJyAmJiBfY29sRGVmW2tleV0uY29uZmlnLmlucHV0KSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbERlZkNvbmZpZy5lZGl0TW9kZSA9IHRydWU7XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgICAgICAgICB0YWJsZUNvbHVtbiA9IHRoaXMuX3NldENvbHVtbkNvbmZpZyh0YWJsZUNvbHVtbiwgX2NvbERlZltrZXldLmNvbmZpZywgLypfZGF0YVN2YywqLyBfcm91dGVyKTtcclxuXHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKHRhYmxlQ29sdW1uLmhhc093blByb3BlcnR5KCdjZWxsUmVuZGVyZXJGcmFtZXdvcmsnKSkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBkZWxldGUgdGFibGVDb2x1bW4uY2VsbFJlbmRlcmVyO1xyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgICAgICBpZiAodHlwZW9mIHRhYmxlQ29sdW1uLmNvbmZpZyAhPT0gJ3VuZGVmaW5lZCcgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgICh0eXBlb2YgdGFibGVDb2x1bW4uY29uZmlnLmNoZWNrYm94ICE9PSAndW5kZWZpbmVkJyAmJiB0YWJsZUNvbHVtbi5jb25maWcuY2hlY2tib3gpIHx8XHJcbiAgICAgICAgICAgICAgICAgICAgKHR5cGVvZiB0YWJsZUNvbHVtbi5jb25maWcucmFkaW8gIT09ICd1bmRlZmluZWQnICYmIHRhYmxlQ29sdW1uLmNvbmZpZy5yYWRpbykpKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbERlZkNvbmZpZy51cGRhdGVkQ29sRGVmLnVuc2hpZnQodGFibGVDb2x1bW4pO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgZWxzZSB7XHJcbiAgICAgICAgICAgICAgICAgICAgY29sRGVmQ29uZmlnLnVwZGF0ZWRDb2xEZWYucHVzaCh0YWJsZUNvbHVtbik7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIHJldHVybiBjb2xEZWZDb25maWc7XHJcbiAgICB9XHJcblxyXG4gICAgc2V0RmlsdGVyQW5kU29ydE9wdGlvbnMocGFyYW1zOiBhbnkpOiBHcmlkT3B0aW9ucyB7XHJcbiAgICAgICAgbGV0IHVwZGF0ZWRPcHRpb25zID0gcGFyYW1zLmdyaWRPcHRpb25zO1xyXG5cclxuICAgICAgICBpZiAocGFyYW1zLmxvYWRUeXBlID09PSAnc2VydmVyLXBhZ2luYXRpb24nIHx8IHBhcmFtcy5sb2FkVHlwZSA9PT0gJ29uZXNob3QtcGFnaW5hdGlvbicpIHtcclxuICAgICAgICAgICAgdXBkYXRlZE9wdGlvbnMuZW5hYmxlU2VydmVyU2lkZUZpbHRlciA9IHRydWU7XHJcbiAgICAgICAgICAgIHVwZGF0ZWRPcHRpb25zLmVuYWJsZVNlcnZlclNpZGVTb3J0aW5nID0gdHJ1ZTtcclxuICAgICAgICAgICAgdXBkYXRlZE9wdGlvbnMucGFnaW5hdGlvblBhZ2VTaXplID0gcGFyYW1zLnBhZ2VzaXplO1xyXG4gICAgICAgIH1cclxuICAgICAgICBlbHNlIGlmIChwYXJhbXMubG9hZFR5cGUgPT09ICd2aXJ0dWFsJykge1xyXG4gICAgICAgICAgICB1cGRhdGVkT3B0aW9ucy5lbmFibGVTZXJ2ZXJTaWRlRmlsdGVyID0gdHJ1ZTtcclxuICAgICAgICAgICAgdXBkYXRlZE9wdGlvbnMuZW5hYmxlU2VydmVyU2lkZVNvcnRpbmcgPSB0cnVlO1xyXG4gICAgICAgICAgICB1cGRhdGVkT3B0aW9ucy5wYWdpbmF0aW9uUGFnZVNpemUgPSBwYXJhbXMucGFnZXNpemU7XHJcbiAgICAgICAgICAgIHVwZGF0ZWRPcHRpb25zLm1heFBhZ2VzSW5DYWNoZSA9IDM7XHJcbiAgICAgICAgICAgIHVwZGF0ZWRPcHRpb25zLm1heENvbmN1cnJlbnREYXRhc291cmNlUmVxdWVzdHMgPSAyO1xyXG4gICAgICAgICAgICB1cGRhdGVkT3B0aW9ucy5vdmVyZmxvd1NpemUgPSAzMDtcclxuICAgICAgICB9XHJcbiAgICAgICAgZWxzZSB7XHJcbiAgICAgICAgICAgIHVwZGF0ZWRPcHRpb25zLmVuYWJsZUZpbHRlciA9IHRydWU7XHJcbiAgICAgICAgICAgIHVwZGF0ZWRPcHRpb25zLmVuYWJsZVNvcnRpbmcgPSB0cnVlO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgaWYgKHBhcmFtcy5sb2FkVHlwZSA9PT0gJ3NlcnZlci1wYWdpbmF0aW9uJyB8fCBwYXJhbXMubG9hZFR5cGUgPT09ICdvbmVzaG90LXBhZ2luYXRpb24nKSB7XHJcbiAgICAgICAgICAgIHVwZGF0ZWRPcHRpb25zLnBhZ2luYXRpb24gPSB0cnVlO1xyXG4gICAgICAgIH1cclxuICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgdXBkYXRlZE9wdGlvbnMucm93TW9kZWxUeXBlID0gcGFyYW1zLnBhZ2luYXRpb25UeXBlO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgcmV0dXJuIHVwZGF0ZWRPcHRpb25zO1xyXG4gICAgfVxyXG5cclxuICAgIGNhbGNDb2xXaWR0aChfZ3JpZE9wdGlvbnM6IEdyaWRPcHRpb25zKTogQXJyYXk8e3dpZHRoOiBudW1iZXIsIGlkOiBzdHJpbmd9PiB7XHJcbiAgICAgICAgbGV0IGNvbHVtbnM6IEFycmF5PENvbHVtbj4gPSBfZ3JpZE9wdGlvbnMuY29sdW1uQXBpLmdldEFsbENvbHVtbnMoKTtcclxuICAgICAgICBsZXQgdXBkYXRlZFdpZHRoOiBBcnJheTx7d2lkdGg6IG51bWJlciwgaWQ6IHN0cmluZ30+ID0gW107XHJcblxyXG4gICAgICAgIGZvciAobGV0IGk6IG51bWJlciA9IDA7IGkgPCBjb2x1bW5zLmxlbmd0aDsgaSsrKSB7XHJcbiAgICAgICAgICAgIGxldCBjb2x1bW5EZWY6IGFueSA9IGNvbHVtbnNbaV0uZ2V0Q29sRGVmKCk7XHJcbiAgICAgICAgICAgIGxldCBjb2xXaWR0aDogbnVtYmVyID0gLTE7XHJcblxyXG4gICAgICAgICAgICBpZiAoY29sdW1uRGVmLmNlbGxDbGFzcy5pbmRleE9mKCdhZy1jaGVja2JveC1yYWRpbycpICE9PSAtMSkge1xyXG4gICAgICAgICAgICAgICAgY29sV2lkdGggPSA1MDtcclxuICAgICAgICAgICAgICAgIF9ncmlkT3B0aW9ucy5jb2x1bW5BcGkuc2V0Q29sdW1uV2lkdGgoY29sdW1uc1tpXSwgY29sV2lkdGgpO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIGVsc2UgaWYgKHR5cGVvZiBjb2x1bW5EZWYuY29uZmlnICE9PSAndW5kZWZpbmVkJyAmJiB0eXBlb2YgY29sdW1uRGVmLmNvbmZpZy5hY3Rpb24gIT09ICd1bmRlZmluZWQnICYmIGNvbHVtbkRlZi5jb25maWcuYWN0aW9uKSB7XHJcbiAgICAgICAgICAgICAgICBjb2xXaWR0aCA9IDEyMDtcclxuICAgICAgICAgICAgICAgIF9ncmlkT3B0aW9ucy5jb2x1bW5BcGkuc2V0Q29sdW1uV2lkdGgoY29sdW1uc1tpXSwgY29sV2lkdGgpO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIGVsc2UgaWYgKHR5cGVvZiBjb2x1bW5EZWYuY29uZmlnICE9PSAndW5kZWZpbmVkJyAmJiB0eXBlb2YgY29sdW1uRGVmLmNvbmZpZy5waG90byAhPT0gJ3VuZGVmaW5lZCcgJiYgY29sdW1uRGVmLmNvbmZpZy5waG90bykge1xyXG4gICAgICAgICAgICAgICAgY29sV2lkdGggPSAxMDA7XHJcbiAgICAgICAgICAgICAgICBfZ3JpZE9wdGlvbnMuY29sdW1uQXBpLnNldENvbHVtbldpZHRoKGNvbHVtbnNbaV0sIGNvbFdpZHRoKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBlbHNlIGlmICh0eXBlb2YgY29sdW1uRGVmLmNvbmZpZyAhPT0gJ3VuZGVmaW5lZCcgJiYgdHlwZW9mIGNvbHVtbkRlZi5jb25maWcuaW5wdXQgIT09ICd1bmRlZmluZWQnICYmIGNvbHVtbkRlZi5jb25maWcuaW5wdXQpIHtcclxuICAgICAgICAgICAgICAgIGNvbFdpZHRoID0gMjgwO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgY29sV2lkdGggPSBjb2x1bW5zW2ldLmdldEFjdHVhbFdpZHRoKCkgKyAzMDtcclxuICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgdXBkYXRlZFdpZHRoLnB1c2goe3dpZHRoOiBjb2xXaWR0aCwgaWQ6IGNvbHVtbkRlZi5jb2xJZH0pO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgcmV0dXJuIHVwZGF0ZWRXaWR0aDtcclxuICAgIH1cclxuXHJcbiAgICBjb2xUb3RhbFdpZHRoKF9jb2xBcnJheTogQXJyYXk8e3dpZHRoOiBudW1iZXIsIGlkOiBzdHJpbmd9PiwgY29sdW1uOiBBcnJheTxDb2x1bW4+KTogbnVtYmVyIHtcclxuICAgICAgICBsZXQgdG90YWw6IG51bWJlciA9IDA7XHJcbiAgICAgICAgZm9yIChsZXQgaTogbnVtYmVyID0gMDsgaSA8IF9jb2xBcnJheS5sZW5ndGg7IGkrKykge1xyXG4gICAgICAgICAgICBpZiAoY29sdW1uW2ldLmlzVmlzaWJsZSgpKSB7XHJcbiAgICAgICAgICAgICAgICB0b3RhbCArPSBfY29sQXJyYXlbaV0ud2lkdGg7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIHJldHVybiB0b3RhbDtcclxuICAgIH1cclxuXHJcbiAgICBjYWxjVXNhYmxlV2lkdGgoX3ZjcjogVmlld0NvbnRhaW5lclJlZik6IG51bWJlciB7XHJcbiAgICAgICAgbGV0IGFnR3JpZEVsZTogSFRNTEVsZW1lbnQgPSBfdmNyLmVsZW1lbnQubmF0aXZlRWxlbWVudC5xdWVyeVNlbGVjdG9yKCcuc3RnLXRoZW1lJyk7XHJcbiAgICAgICAgbGV0IHBhcmVudFdpZHRoOiBudW1iZXIgPSBNYXRoLnJvdW5kKGFnR3JpZEVsZS5nZXRCb3VuZGluZ0NsaWVudFJlY3QoKS53aWR0aCk7XHJcbiAgICAgICAgbGV0IGNvbXB1dGVkU3R5bGU6IENTU1N0eWxlRGVjbGFyYXRpb24gPSB3aW5kb3cuZ2V0Q29tcHV0ZWRTdHlsZShhZ0dyaWRFbGUpO1xyXG4gICAgICAgIGxldCBib3JkZXJMZWZ0OiBudW1iZXIgPSAoY29tcHV0ZWRTdHlsZS5ib3JkZXJMZWZ0ICE9PSAnJykgPyBwYXJzZUludChjb21wdXRlZFN0eWxlLmJvcmRlckxlZnQpIDogMDtcclxuICAgICAgICBsZXQgYm9yZGVyUmlnaHQ6IG51bWJlciA9IChjb21wdXRlZFN0eWxlLmJvcmRlclJpZ2h0ICE9PSAnJykgPyBwYXJzZUludChjb21wdXRlZFN0eWxlLmJvcmRlclJpZ2h0KSA6IDA7XHJcbiAgICAgICAgbGV0IGJvcmRlckxlZnRSaWdodCA9IGJvcmRlckxlZnQgKyBib3JkZXJSaWdodDtcclxuICAgICAgICByZXR1cm4gcGFyZW50V2lkdGggLSBib3JkZXJMZWZ0UmlnaHQ7XHJcbiAgICB9XHJcblxyXG4gICAgY2FsY1Jlc2l6ZWFibGVDb2woX2NvbHVtbnM6IEFycmF5PENvbHVtbj4pOiBudW1iZXIge1xyXG4gICAgICAgIGxldCByZXNpemVhYmxlQ29sOiBudW1iZXIgPSB0aGlzLl9yZXNpemVhYmxlQ29sO1xyXG5cclxuICAgICAgICBmb3IgKGxldCBpOiBudW1iZXIgPSAwOyBpIDwgX2NvbHVtbnMubGVuZ3RoOyBpKyspIHtcclxuICAgICAgICAgICAgbGV0IGNvbERlZjogYW55ID0gX2NvbHVtbnNbaV0uZ2V0Q29sRGVmKCk7XHJcblxyXG4gICAgICAgICAgICBpZiAodHlwZW9mIGNvbERlZi5jb25maWcgPT09ICd1bmRlZmluZWQnICYmICFfY29sdW1uc1tpXS5pc1Zpc2libGUoKSkge1xyXG4gICAgICAgICAgICAgICAgLS1yZXNpemVhYmxlQ29sO1xyXG4gICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICAvLyBtb3JlIGNoZWNrcyB0byBpbXBsZW1lbnRcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIHJldHVybiByZXNpemVhYmxlQ29sO1xyXG4gICAgfVxyXG5cclxuICAgIGNhbGNHcmlkSGVpZ2h0V2ViKF9ncmlkSGVpZ2h0OiBhbnksIF9tb2RlbDogSVJvd01vZGVsLCBfdmNyOiBWaWV3Q29udGFpbmVyUmVmKTogbnVtYmVyIHtcclxuICAgICAgICBsZXQgYWN0dWFsSGVpZ2h0OiBudW1iZXIgPSAzOCArIDg7XHJcbiAgICAgICAgbGV0IGlkU291dGg6IEVsZW1lbnQgPSBfdmNyLmVsZW1lbnQubmF0aXZlRWxlbWVudC5xdWVyeVNlbGVjdG9yKCcjc291dGgnKTtcclxuXHJcbiAgICAgICAgaWYgKGlkU291dGggIT09IG51bGwpIHtcclxuICAgICAgICAgICAgYWN0dWFsSGVpZ2h0ICs9IGlkU291dGguZ2V0Qm91bmRpbmdDbGllbnRSZWN0KCkuaGVpZ2h0O1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgZm9yIChsZXQgaTogbnVtYmVyID0gMDsgaSA8IF9tb2RlbC5nZXRSb3dDb3VudCgpOyBpKyspIHtcclxuICAgICAgICAgICAgYWN0dWFsSGVpZ2h0ICs9IF9tb2RlbC5nZXRSb3coaSkucm93SGVpZ2h0O1xyXG4gICAgICAgICAgICBpZiAoYWN0dWFsSGVpZ2h0ID4gX2dyaWRIZWlnaHQpIHtcclxuICAgICAgICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICBpZiAoYWN0dWFsSGVpZ2h0IDwgX2dyaWRIZWlnaHQpIHtcclxuICAgICAgICAgICAgcmV0dXJuIGFjdHVhbEhlaWdodDtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIHJldHVybiBfZ3JpZEhlaWdodDtcclxuICAgIH1cclxuXHJcbiAgICBjYWxjR3JpZEhlaWdodE1vYmlsZShfdmNyOiBWaWV3Q29udGFpbmVyUmVmKTogbnVtYmVyIHtcclxuICAgICAgICBsZXQgdG90YWxIZWlnaHQ6IG51bWJlciA9IDA7XHJcbiAgICAgICAgbGV0IG5hdGl2ZUVsZTogRWxlbWVudCA9IF92Y3IuZWxlbWVudC5uYXRpdmVFbGVtZW50O1xyXG4gICAgICAgIGxldCBoZWFkZXJDb250YWluZXI6IEVsZW1lbnQgPSBuYXRpdmVFbGUucXVlcnlTZWxlY3RvcignLmFnLWhlYWRlci1jb250YWluZXInKTtcclxuICAgICAgICBpZiAobmF0aXZlRWxlID09PSBudWxsIHx8IGhlYWRlckNvbnRhaW5lciA9PT0gbnVsbCkgcmV0dXJuIHRvdGFsSGVpZ2h0O1xyXG4gICAgICAgIHRvdGFsSGVpZ2h0ICs9IE1hdGguY2VpbChoZWFkZXJDb250YWluZXIuZ2V0Qm91bmRpbmdDbGllbnRSZWN0KCkuaGVpZ2h0KTtcclxuICAgICAgICB0b3RhbEhlaWdodCArPSBNYXRoLmNlaWwobmF0aXZlRWxlLnF1ZXJ5U2VsZWN0b3IoJy5hZy1ib2R5LWNvbnRhaW5lcicpLmdldEJvdW5kaW5nQ2xpZW50UmVjdCgpLmhlaWdodCk7XHJcblxyXG4gICAgICAgIGxldCBwYWdpbmF0aW9uQm90dG9tOiBFbGVtZW50ID0gbmF0aXZlRWxlLnF1ZXJ5U2VsZWN0b3IoJyNzb3V0aCcpO1xyXG4gICAgICAgIGlmIChwYWdpbmF0aW9uQm90dG9tICE9PSBudWxsKSB7XHJcbiAgICAgICAgICAgIHRvdGFsSGVpZ2h0ICs9IE1hdGguY2VpbChwYWdpbmF0aW9uQm90dG9tLmdldEJvdW5kaW5nQ2xpZW50UmVjdCgpLmhlaWdodCk7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIHRvdGFsSGVpZ2h0ICs9IDg7XHJcbiAgICAgICAgcmV0dXJuIHRvdGFsSGVpZ2h0O1xyXG4gICAgfVxyXG5cclxuICAgIHNlcnZlclNvcnRBbmRGaWx0ZXIoX2RhdGE6IEFycmF5PGFueT4sIF9zb3J0TW9kZWw6IEFycmF5PGFueT4sIF9maWx0ZXJNb2RlbDogYW55KSB7XHJcbiAgICAgICAgcmV0dXJuIHRoaXMuX3NlcnZlclNvcnREYXRhKF9zb3J0TW9kZWwsIHRoaXMuX3NlcnZlckZpbHRlckRhdGEoX2ZpbHRlck1vZGVsLCBfZGF0YSkpO1xyXG4gICAgfVxyXG5cclxuICAgIGNoZWNrQ29sdW1uRGVmKF9jb2xEZWY6IGFueSwgX2hhc0NoZWNrYm94OiBib29sZWFuLCBfaGFzUmFkaW86IGJvb2xlYW4pOiBhbnkge1xyXG4gICAgICAgIGlmIChfaGFzQ2hlY2tib3gpIHtcclxuICAgICAgICAgICAgX2NvbERlZlsnYWctY2hlY2tib3gnXSA9IHtcclxuICAgICAgICAgICAgICAgIGNvbmZpZzoge1xyXG4gICAgICAgICAgICAgICAgICAgIGNoZWNrYm94OiB0cnVlXHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH07XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGVsc2UgaWYgKF9oYXNSYWRpbykge1xyXG4gICAgICAgICAgICBfY29sRGVmWydhZy1yYWRpbyddID0ge1xyXG4gICAgICAgICAgICAgICAgY29uZmlnOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgcmFkaW86IHRydWVcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfTtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIHJldHVybiBfY29sRGVmO1xyXG4gICAgfVxyXG5cclxuICAgIGdldEFjdGlvbkxpc3QoX3Jvd0RhdGE6IGFueSwgX2NvbHVtbjogQXJyYXk8Q29sdW1uPik6IEFycmF5PGFueT4ge1xyXG4gICAgICAgIGlmICh0eXBlb2YgX3Jvd0RhdGEuYWN0aW9uICE9PSAndW5kZWZpbmVkJykge1xyXG4gICAgICAgICAgICByZXR1cm4gX3Jvd0RhdGEuYWN0aW9uO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgZm9yIChsZXQgaTogbnVtYmVyID0gMDsgaSA8IF9jb2x1bW4ubGVuZ3RoOyBpKyspIHtcclxuICAgICAgICAgICAgbGV0IGNvbERlZjogYW55ID0gX2NvbHVtbltpXS5nZXRDb2xEZWYoKTtcclxuICAgICAgICAgICAgaWYgKHR5cGVvZiBjb2xEZWYuY29uZmlnICE9PSAndW5kZWZpbmVkJyAmJlxyXG4gICAgICAgICAgICAgICAgdHlwZW9mIGNvbERlZi5jb25maWcuYWN0aW9uICE9PSAndW5kZWZpbmVkJyAmJlxyXG4gICAgICAgICAgICAgICAgY29sRGVmLmNvbmZpZy5hY3Rpb24pIHtcclxuICAgICAgICAgICAgICAgICAgICByZXR1cm4gY29sRGVmLmNvbmZpZy5pdGVtcztcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgICAgICByZXR1cm4gW107XHJcbiAgICB9XHJcblxyXG4gICAgY2hlY2tJc1RhcmdldENsaWNrYWJsZShfcm93RXZlbnQ6IEV2ZW50KTogYm9vbGVhbiB7XHJcbiAgICAgICAgbGV0IGVsZW1lbnQ6IEhUTUxFbGVtZW50ID0gPEhUTUxFbGVtZW50Pl9yb3dFdmVudC50YXJnZXQ7XHJcbiAgICAgICAgbGV0IGNoZWNrTGlzdDogQXJyYXk8c3RyaW5nPiA9IFsnYWN0aW9uLWJ0bicsICdjaGVja2JveC1yYWRpby1pbnB1dCcsICdmYS1jaGV2cm9uLWRvd24nXTtcclxuXHJcbiAgICAgICAgZm9yIChsZXQgaTogbnVtYmVyID0gMDsgaSA8IGNoZWNrTGlzdC5sZW5ndGg7IGkrKykge1xyXG4gICAgICAgICAgICBpZiAoZWxlbWVudC5jbGFzc0xpc3QuY29udGFpbnMoY2hlY2tMaXN0W2ldKSkge1xyXG4gICAgICAgICAgICAgICAgcmV0dXJuIGZhbHNlO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICByZXR1cm4gdHJ1ZTtcclxuICAgIH1cclxuXHJcbiAgICBjaGVja0lzQ29uZmlnQ29sdW1uKF9jb2xEZWY6IGFueSk6IGJvb2xlYW4ge1xyXG4gICAgICAgIGlmIChfY29sRGVmLmNlbGxDbGFzcy5pbmRleE9mKCdhZy1jaGVja2JveC1yYWRpbycpICE9PSAtMSkge1xyXG4gICAgICAgICAgICByZXR1cm4gdHJ1ZTtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIGlmICh0eXBlb2YgX2NvbERlZi5jb25maWcgIT09ICd1bmRlZmluZWQnICYmXHJcbiAgICAgICAgICAgICgodHlwZW9mIF9jb2xEZWYuY29uZmlnLnBob3RvICE9PSAndW5kZWZpbmVkJyAmJiBfY29sRGVmLmNvbmZpZy5waG90bykgfHxcclxuICAgICAgICAgICAgICh0eXBlb2YgX2NvbERlZi5jb25maWcuYWN0aW9uICE9PSAndW5kZWZpbmVkJyAmJiBfY29sRGVmLmNvbmZpZy5hY3Rpb24pKVxyXG4gICAgICAgICkge1xyXG4gICAgICAgICAgICByZXR1cm4gdHJ1ZTtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIHJldHVybiBmYWxzZTtcclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF9zZXRDb2x1bW5Db25maWcoX2NvbHVtbjogYW55LCBfY29uZmlnOiBhbnksIC8qX2RhdGFTdmM6IEtkRGF0YVN2YywqLyBfcm91dGVyPzogUm91dGVyKTogYW55IHtcclxuICAgICAgICBsZXQgdXBkYXRlZENvbHVtbjogYW55ID0gKDxhbnk+T2JqZWN0KS5hc3NpZ24oe30sIF9jb2x1bW4pO1xyXG5cclxuICAgICAgICAvLyBpZiAodHlwZW9mIF9jb25maWcuaW5wdXQgIT09ICd1bmRlZmluZWQnICYmIF9jb25maWcuaW5wdXQpIHtcclxuICAgICAgICAvLyAgICAgdXBkYXRlZENvbHVtbi5zdXBwcmVzc01lbnUgPSB0cnVlO1xyXG4gICAgICAgIC8vICAgICB1cGRhdGVkQ29sdW1uLnN1cHByZXNzU29ydGluZyA9IHRydWU7XHJcbiAgICAgICAgLy8gICAgIHVwZGF0ZWRDb2x1bW4uY2VsbENsYXNzID0gJ2FnLWZvcm0nO1xyXG4gICAgICAgIC8vICAgICB1cGRhdGVkQ29sdW1uLmNlbGxSZW5kZXJlckZyYW1ld29yayA9IEtkQUdGb3JtO1xyXG4gICAgICAgIC8vIH1cclxuXHJcbiAgICAgICAgLy8gZWxzZSBpZiAodHlwZW9mIF9jb25maWcuYWN0aW9uICE9PSAndW5kZWZpbmVkJyAmJiBfY29uZmlnLmFjdGlvbikge1xyXG4gICAgICAgIC8vICAgICB1cGRhdGVkQ29sdW1uLnN1cHByZXNzTWVudSA9IHRydWU7XHJcbiAgICAgICAgLy8gICAgIHVwZGF0ZWRDb2x1bW4uc3VwcHJlc3NTb3J0aW5nID0gdHJ1ZTtcclxuICAgICAgICAvLyAgICAgdXBkYXRlZENvbHVtbi5zdXBwcmVzc1NpemVUb0ZpdCA9IHRydWU7XHJcbiAgICAgICAgLy8gICAgIHVwZGF0ZWRDb2x1bW4ud2lkdGggPSAxMjA7XHJcbiAgICAgICAgLy8gICAgIHVwZGF0ZWRDb2x1bW4uY2VsbENsYXNzID0gJ2Ryb3Bkb3duLWFjdGlvbic7XHJcbiAgICAgICAgLy8gICAgIHVwZGF0ZWRDb2x1bW4uY2VsbFJlbmRlcmVyRnJhbWV3b3JrID0gS2RBR0Ryb3Bkb3duO1xyXG5cclxuICAgICAgICAvLyAgICAgdGhpcy5fcmVzaXplYWJsZUNvbC0tO1xyXG4gICAgICAgIC8vIH1cclxuXHJcbiAgICAgICAgLy8gZWxzZSBpZiAodHlwZW9mIF9jb25maWcucGhvdG8gIT09ICd1bmRlZmluZWQnICYmIF9jb25maWcucGhvdG8pIHtcclxuICAgICAgICAvLyAgICAgdXBkYXRlZENvbHVtbi5zdXBwcmVzc01lbnUgPSB0cnVlO1xyXG4gICAgICAgIC8vICAgICB1cGRhdGVkQ29sdW1uLnN1cHByZXNzU29ydGluZyA9IHRydWU7XHJcbiAgICAgICAgLy8gICAgIHVwZGF0ZWRDb2x1bW4uc3VwcHJlc3NTaXplVG9GaXQgPSB0cnVlO1xyXG4gICAgICAgIC8vICAgICB1cGRhdGVkQ29sdW1uLndpZHRoID0gMTAwO1xyXG4gICAgICAgIC8vICAgICB1cGRhdGVkQ29sdW1uLmNlbGxDbGFzcyA9ICdhZy1waG90byc7XHJcbiAgICAgICAgLy8gICAgIHVwZGF0ZWRDb2x1bW4uY2VsbFJlbmRlcmVyRnJhbWV3b3JrID0gS2RBR1Bob3RvO1xyXG5cclxuICAgICAgICAvLyAgICAgdGhpcy5fcmVzaXplYWJsZUNvbC0tO1xyXG4gICAgICAgIC8vIH1cclxuXHJcbiAgICAgICAgLy8gZWxzZSBpZiAodHlwZW9mIF9jb25maWcuY2hlY2tib3ggIT09ICd1bmRlZmluZWQnICYmIF9jb25maWcuY2hlY2tib3gpIHtcclxuICAgICAgICAvLyAgICAgdXBkYXRlZENvbHVtbi5zdXBwcmVzc01lbnUgPSB0cnVlO1xyXG4gICAgICAgIC8vICAgICB1cGRhdGVkQ29sdW1uLnN1cHByZXNzU29ydGluZyA9IHRydWU7XHJcbiAgICAgICAgLy8gICAgIHVwZGF0ZWRDb2x1bW4uc3VwcHJlc3NTaXplVG9GaXQgPSB0cnVlO1xyXG4gICAgICAgIC8vICAgICB1cGRhdGVkQ29sdW1uLndpZHRoID0gNTA7XHJcbiAgICAgICAgLy8gICAgIHVwZGF0ZWRDb2x1bW4uY2VsbENsYXNzID0gJ2FnLWRlZmF1bHQgYWctY2hlY2tib3gtcmFkaW8nO1xyXG4gICAgICAgIC8vICAgICB1cGRhdGVkQ29sdW1uLmNvbElkID0gJ2NoZWNrYm94JztcclxuICAgICAgICAvLyAgICAgdXBkYXRlZENvbHVtbi5jZWxsUmVuZGVyZXJGcmFtZXdvcmsgPSBLZEFHQ2hlY2tib3hSYWRpbztcclxuICAgICAgICAvLyAgICAgdXBkYXRlZENvbHVtbi5oZWFkZXJDb21wb25lbnRGcmFtZXdvcmsgPSBLZEFHQ2hlY2tib3hSYWRpbztcclxuXHJcbiAgICAgICAgLy8gICAgIHRoaXMuX3Jlc2l6ZWFibGVDb2wtLTtcclxuICAgICAgICAvLyB9XHJcblxyXG4gICAgICAgIC8vIGVsc2UgaWYgKHR5cGVvZiBfY29uZmlnLnJhZGlvICE9PSAndW5kZWZpbmVkJyAmJiBfY29uZmlnLnJhZGlvKSB7XHJcbiAgICAgICAgLy8gICAgIHVwZGF0ZWRDb2x1bW4uc3VwcHJlc3NNZW51ID0gdHJ1ZTtcclxuICAgICAgICAvLyAgICAgdXBkYXRlZENvbHVtbi5zdXBwcmVzc1NvcnRpbmcgPSB0cnVlO1xyXG4gICAgICAgIC8vICAgICB1cGRhdGVkQ29sdW1uLnN1cHByZXNzU2l6ZVRvRml0ID0gdHJ1ZTtcclxuICAgICAgICAvLyAgICAgdXBkYXRlZENvbHVtbi53aWR0aCA9IDUwO1xyXG4gICAgICAgIC8vICAgICB1cGRhdGVkQ29sdW1uLmNlbGxDbGFzcyA9ICdhZy1kZWZhdWx0IGFnLWNoZWNrYm94LXJhZGlvJztcclxuICAgICAgICAvLyAgICAgdXBkYXRlZENvbHVtbi5jb2xJZCA9ICdyYWRpbyc7XHJcbiAgICAgICAgLy8gICAgIHVwZGF0ZWRDb2x1bW4uY2VsbFJlbmRlcmVyRnJhbWV3b3JrID0gS2RBR0NoZWNrYm94UmFkaW87XHJcbiAgICAgICAgLy8gICAgIHVwZGF0ZWRDb2x1bW4uaGVhZGVyTmFtZSA9ICcnO1xyXG5cclxuICAgICAgICAvLyAgICAgdGhpcy5fcmVzaXplYWJsZUNvbC0tO1xyXG4gICAgICAgIC8vIH1cclxuXHJcbiAgICAgICAgLy8gZWxzZSBpZiAodHlwZW9mIF9jb25maWcuZGlzcGxheUZyb20gIT09ICd1bmRlZmluZWQnICYmIF9jb25maWcuZGlzcGxheUZyb20pIHtcclxuICAgICAgICAgICAgLy8gdXBkYXRlZENvbHVtbi5jZWxsUmVuZGVyZXIgPSAocGFyYW1zOiBhbnkpOiBhbnkgPT4ge1xyXG4gICAgICAgICAgICAvLyAgICAgaWYgKHR5cGVvZiBwYXJhbXMudmFsdWUgIT09ICd1bmRlZmluZWQnKSB7XHJcbiAgICAgICAgICAgIC8vICAgICAgICAgaWYgKHBhcmFtcy52YWx1ZSBpbnN0YW5jZW9mIEFycmF5KSB7XHJcbiAgICAgICAgICAgIC8vICAgICAgICAgICAgIGxldCBkaXNwbGF5QXJyYXk6IEFycmF5PGFueT4gPSBbXTtcclxuICAgICAgICAgICAgLy8gICAgICAgICAgICAgZm9yIChsZXQgaTogbnVtYmVyID0gMDsgaSA8IHBhcmFtcy52YWx1ZS5sZW5ndGg7IGkrKykge1xyXG4gICAgICAgICAgICAvLyAgICAgICAgICAgICAgICAgbGV0IGRpc3BsYXk6IGFueSA9IHRoaXMuX2RhdGFTdmMuZ2V0RGF0YVZhbHVlKHBhcmFtcy52YWx1ZVtpXSwgX2NvbmZpZy5kaXNwbGF5RnJvbSk7XHJcbiAgICAgICAgICAgIC8vICAgICAgICAgICAgICAgICBpZiAoZGlzcGxheSAhPT0gbnVsbCkgZGlzcGxheUFycmF5LnB1c2goZGlzcGxheSk7XHJcbiAgICAgICAgICAgIC8vICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgLy8gICAgICAgICAgICAgcmV0dXJuIGRpc3BsYXlBcnJheTtcclxuICAgICAgICAgICAgLy8gICAgICAgICB9XHJcbiAgICAgICAgICAgIC8vICAgICAgICAgZWxzZSB7XHJcbiAgICAgICAgICAgIC8vICAgICAgICAgICAgIGxldCBkaXNwbGF5OiBhbnkgPSB0aGlzLl9kYXRhU3ZjLmdldERhdGFWYWx1ZShwYXJhbXMudmFsdWUsIF9jb25maWcuZGlzcGxheUZyb20pO1xyXG4gICAgICAgICAgICAvLyAgICAgICAgICAgICBpZiAoZGlzcGxheSAhPT0gbnVsbCkgcmV0dXJuIGRpc3BsYXk7XHJcbiAgICAgICAgICAgIC8vICAgICAgICAgfVxyXG4gICAgICAgICAgICAvLyAgICAgfVxyXG4gICAgICAgICAgICAvLyAgICAgcmV0dXJuIHBhcmFtcy52YWx1ZTtcclxuICAgICAgICAgICAgLy8gfVxyXG4gICAgICAgIC8vIH1cclxuXHJcbiAgICAgICAgcmV0dXJuIHVwZGF0ZWRDb2x1bW47XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfc2VydmVyRmlsdGVyRGF0YShfZmlsdGVyTW9kZWw6IGFueSwgX2RhdGE6IEFycmF5PGFueT4pOiBBcnJheTxhbnk+IHtcclxuICAgICAgICBsZXQgZmlsdGVyZWREYXRhOiBBcnJheTxhbnk+ID0gX2RhdGEuc2xpY2UoKTtcclxuXHJcbiAgICAgICAgaWYgKHR5cGVvZiBfZmlsdGVyTW9kZWwgPT09ICd1bmRlZmluZWQnIHx8IE9iamVjdC5rZXlzKF9maWx0ZXJNb2RlbCkubGVuZ3RoID09PSAwKSB7XHJcbiAgICAgICAgICAgIHJldHVybiBmaWx0ZXJlZERhdGE7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICBsZXQgdXBkYXRlZERhdGE6IEFycmF5PGFueT4gPSBbXTtcclxuICAgICAgICBmb3IgKGxldCBrZXkgaW4gX2ZpbHRlck1vZGVsKSB7XHJcbiAgICAgICAgICAgIGlmIChfZmlsdGVyTW9kZWwuaGFzT3duUHJvcGVydHkoa2V5KSkge1xyXG4gICAgICAgICAgICAgICAgZm9yIChsZXQgazogbnVtYmVyID0gMDsgayA8IF9maWx0ZXJNb2RlbFtrZXldLmxlbmd0aDsgaysrKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgZm9yIChsZXQgajogbnVtYmVyID0gMDsgaiA8IF9kYXRhLmxlbmd0aDsgaisrKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGlmIChfZGF0YVtqXVtrZXldID09PSBfZmlsdGVyTW9kZWxba2V5XVtrXSkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdXBkYXRlZERhdGEucHVzaChfZGF0YVtqXSk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIHJldHVybiB1cGRhdGVkRGF0YTtcclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF9zZXJ2ZXJTb3J0RGF0YShfc29ydE1vZGVsOiBBcnJheTxhbnk+LCBfZGF0YTogQXJyYXk8YW55Pik6IEFycmF5PGFueT4ge1xyXG4gICAgICAgIGxldCBzb3J0ZWREYXRhOiBBcnJheTxhbnk+ID0gX2RhdGEuc2xpY2UoKTtcclxuXHJcbiAgICAgICAgaWYgKHR5cGVvZiBfc29ydE1vZGVsID09PSAndW5kZWZpbmVkJyB8fCBfc29ydE1vZGVsLmxlbmd0aCA9PT0gMCkge1xyXG4gICAgICAgICAgICByZXR1cm4gc29ydGVkRGF0YTtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIHNvcnRlZERhdGEuc29ydCgoYTogYW55LCBiOiBhbnkpOiBudW1iZXIgPT4ge1xyXG4gICAgICAgICAgICBmb3IgKGxldCBpOiBudW1iZXIgPSAwOyBpIDwgX3NvcnRNb2RlbC5sZW5ndGg7IGkrKykge1xyXG4gICAgICAgICAgICAgICAgbGV0IHNvcnRDb2xNb2RlbDogYW55ID0gX3NvcnRNb2RlbFtpXTtcclxuICAgICAgICAgICAgICAgIGxldCB2YWxBOiBhbnkgPSBhW3NvcnRDb2xNb2RlbC5jb2xJZF07XHJcbiAgICAgICAgICAgICAgICBsZXQgdmFsQjogYW55ID0gYltzb3J0Q29sTW9kZWwuY29sSWRdO1xyXG5cclxuICAgICAgICAgICAgICAgIGlmICh2YWxBID09PSB2YWxCKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgY29udGludWU7XHJcbiAgICAgICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICAgICAgbGV0IGRpcmVjdGlvbiA9IChzb3J0Q29sTW9kZWwuc29ydCA9PT0gJ2FzYycpID8gMSA6IC0xO1xyXG5cclxuICAgICAgICAgICAgICAgIGlmICh2YWxBID4gdmFsQikge1xyXG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBkaXJlY3Rpb247XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgICAgICAgICByZXR1cm4gZGlyZWN0aW9uICogLTE7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICByZXR1cm4gMDtcclxuICAgICAgICB9KTtcclxuICAgICAgICByZXR1cm4gc29ydGVkRGF0YTtcclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF9jaGVja0dyaWRIZWlnaHQoX2NvbmZpZzogYW55KTogbnVtYmVyIHwgc3RyaW5nIHtcclxuICAgICAgICBsZXQgZGVmYXVsdEhlaWdodDogbnVtYmVyID0gNjAwO1xyXG5cclxuICAgICAgICBpZiAodHlwZW9mIF9jb25maWcgPT09ICd1bmRlZmluZWQnKSB7XHJcbiAgICAgICAgICAgIHJldHVybiBkZWZhdWx0SGVpZ2h0O1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgZWxzZSBpZiAodHlwZW9mIF9jb25maWcuZ3JpZEhlaWdodCAhPT0gJ3VuZGVmaW5lZCcgJiZcclxuICAgICAgICAgICAgdHlwZW9mIF9jb25maWcuZ3JpZEhlaWdodCA9PT0gJ3N0cmluZycgJiZcclxuICAgICAgICAgICAgX2NvbmZpZy5ncmlkSGVpZ2h0ID09PSAnYXV0bycpIHtcclxuICAgICAgICAgICAgICAgIHJldHVybiBfY29uZmlnLmdyaWRIZWlnaHQ7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGVsc2UgaWYgKHR5cGVvZiBfY29uZmlnLmdyaWRIZWlnaHQgIT09ICd1bmRlZmluZWQnICYmXHJcbiAgICAgICAgICAgIHR5cGVvZiBfY29uZmlnLmdyaWRIZWlnaHQgPT09ICdudW1iZXInKSB7XHJcbiAgICAgICAgICAgICAgICByZXR1cm4gX2NvbmZpZy5ncmlkSGVpZ2h0O1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgcmV0dXJuIGRlZmF1bHRIZWlnaHQ7XHJcbiAgICB9XHJcblxyXG4gICAgLy8gcHJpdmF0ZSBfY2hlY2tQYWdpbmF0aW9uRGF0YShfY29uZmlnOiBhbnksIF9sb2FkVHlwZTogc3RyaW5nKTogYW55IHtcclxuICAgIC8vICAgICBpZiAodHlwZW9mIF9jb25maWcgIT09ICd1bmRlZmluZWQnICYmXHJcbiAgICAvLyAgICAgICAgIHR5cGVvZiBfY29uZmlnLnBhZ2luYXRpb25TZXREYXRhICE9PSAndW5kZWZpbmVkJyAmJlxyXG4gICAgLy8gICAgICAgICBfbG9hZFR5cGUgPT09ICdzZXJ2ZXItcGFnaW5hdGlvbicpIHtcclxuICAgIC8vICAgICAgICAgICAgIHJldHVybiBfY29uZmlnLnBhZ2luYXRpb25TZXREYXRhO1xyXG4gICAgLy8gICAgIH1cclxuICAgIC8vICAgICBlbHNlIGlmICh0eXBlb2YgX2NvbmZpZyAhPT0gJ3VuZGVmaW5lZCcgJiZcclxuICAgIC8vICAgICAgICAgdHlwZW9mIF9jb25maWcucGFnaW5hdGlvblNldERhdGEgPT09ICd1bmRlZmluZWQnICYmXHJcbiAgICAvLyAgICAgICAgIF9sb2FkVHlwZSA9PT0gJ3NlcnZlci1wYWdpbmF0aW9uJykge1xyXG4gICAgLy8gICAgICAgICAgICAgY29uc29sZS5lcnJvcignU2VydmVyIHBhZ2luYXRpb24gcmVxdWlyZXMgY2FsbGJhY2sgdG8gcmV0cmlldmUgZGF0YS4gUGxlYXNlIHByb3ZpZGUgdGhlIGNhbGxiYWNrIGZ1bmN0aW9uLicpO1xyXG4gICAgLy8gICAgIH1cclxuXHJcbiAgICAvLyAgICAgcmV0dXJuIHVuZGVmaW5lZDtcclxuICAgIC8vIH1cclxuXHJcbiAgICBwcml2YXRlIF9jaGVja1BhZ2luYXRpb25UeXBlKF9sb2FkVHlwZTogc3RyaW5nKTogc3RyaW5nIHtcclxuICAgICAgICBpZiAoX2xvYWRUeXBlID09PSAnaW5maW5pdGUnKSByZXR1cm4gJ2luZmluaXRlJztcclxuICAgICAgICBpZiAoX2xvYWRUeXBlID09PSAnc2VydmVyLXBhZ2luYXRpb24nIHx8IF9sb2FkVHlwZSA9PT0gJ29uZXNob3QtcGFnaW5hdGlvbicpIHJldHVybiAncGFnaW5hdGlvbic7XHJcbiAgICAgICAgcmV0dXJuICcnO1xyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX2NoZWNrTG9hZFR5cGUoX2NvbmZpZzogYW55KTogc3RyaW5nIHtcclxuICAgICAgICBsZXQgZGVmYXVsdExvYWRUeXBlOiBzdHJpbmcgPSAnbm9ybWFsJztcclxuXHJcbiAgICAgICAgaWYgKHR5cGVvZiBfY29uZmlnID09PSAndW5kZWZpbmVkJyB8fCB0eXBlb2YgX2NvbmZpZy5sb2FkVHlwZSA9PT0gJ3VuZGVmaW5lZCcpIHtcclxuICAgICAgICAgICAgcmV0dXJuIGRlZmF1bHRMb2FkVHlwZTtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIGlmIChfY29uZmlnLmxvYWRUeXBlID09PSAnbm9ybWFsJyB8fFxyXG4gICAgICAgICAgICBfY29uZmlnLmxvYWRUeXBlID09PSAnc2VydmVyLXBhZ2luYXRpb24nIHx8XHJcbiAgICAgICAgICAgIF9jb25maWcubG9hZFR5cGUgPT09ICd2aXJ0dWFsJyB8fFxyXG4gICAgICAgICAgICBfY29uZmlnLmxvYWRUeXBlID09PSAnb25lc2hvdC1wYWdpbmF0aW9uJykge1xyXG4gICAgICAgICAgICAgICAgcmV0dXJuIF9jb25maWcubG9hZFR5cGU7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICByZXR1cm4gZGVmYXVsdExvYWRUeXBlO1xyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX2NoZWNrUGFnZXNpemUoX2NvbmZpZzogYW55LCBfbG9hZFR5cGU6IHN0cmluZyk6IG51bWJlciB7XHJcbiAgICAgICAgaWYgKF9sb2FkVHlwZSA9PT0gJ25vcm1hbCcpIHJldHVybiAtMTtcclxuICAgICAgICBpZiAodHlwZW9mIF9jb25maWcgIT09ICd1bmRlZmluZWQnICYmIHR5cGVvZiBfY29uZmlnLnBhZ2VzaXplICE9PSAndW5kZWZpbmVkJykgcmV0dXJuIF9jb25maWcucGFnZXNpemU7XHJcbiAgICAgICAgcmV0dXJuIDI1O1xyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX2dldFJvd0hlaWdodChfcGFyYW1zOiBhbnkpOiBudW1iZXIge1xyXG4gICAgICAgIGxldCBncmlkT3B0aW9uczogYW55ID0gdGhpcztcclxuICAgICAgICBsZXQgY29sRGVmOiBBcnJheTxhbnk+ID0gZ3JpZE9wdGlvbnMuY29sdW1uRGVmcztcclxuICAgICAgICBsZXQgcm93SGVpZ2h0OiBudW1iZXIgPSA1MDtcclxuICAgICAgICBmb3IgKGxldCBpOiBudW1iZXIgPSAwOyBpIDwgY29sRGVmLmxlbmd0aDsgaSsrKSB7XHJcbiAgICAgICAgICAgIGlmICh0eXBlb2YgY29sRGVmW2ldLmNvbmZpZyAhPT0gJ3VuZGVmaW5lZCcpIHtcclxuICAgICAgICAgICAgICAgIGlmICh0eXBlb2YgY29sRGVmW2ldLmNvbmZpZy5waG90byAhPT0gJ3VuZGVmaW5lZCcgJiYgY29sRGVmW2ldLmNvbmZpZy5waG90bykgcmV0dXJuIDEyMDtcclxuICAgICAgICAgICAgICAgIGVsc2UgaWYgKHR5cGVvZiBjb2xEZWZbaV0uY29uZmlnLnRleHRhcmVhICE9PSAndW5kZWZpbmVkJyAmJiBjb2xEZWZbaV0uY29uZmlnLnRleHRhcmVhKSByZXR1cm4gMTIwO1xyXG4gICAgICAgICAgICAgICAgZWxzZSBpZiAodHlwZW9mIGNvbERlZltpXS5jb25maWcuaW5wdXQgIT09ICd1bmRlZmluZWQnICYmIGNvbERlZltpXS5jb25maWcuaW5wdXQpIHtcclxuICAgICAgICAgICAgICAgICAgICBpZiAoX3BhcmFtcy5kYXRhW2NvbERlZltpXS5jb2xJZF0gaW5zdGFuY2VvZiBBcnJheSkgcmV0dXJuIHJvd0hlaWdodCAqIF9wYXJhbXMuZGF0YVtjb2xEZWZbaV0uY29sSWRdLmxlbmd0aDtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgICAgICByZXR1cm4gNTA7XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfY2hlY2tCdG5Db25maWcoX2J1dHRvbkxpc3Q6IEFycmF5PGFueT4pOiBBcnJheTxhbnk+IHtcclxuICAgICAgICBsZXQgdXBkYXRlZEJ0bkNvbmZpZzogQXJyYXk8YW55PiA9IFtdO1xyXG4gICAgICAgIGZvciAobGV0IGk6IG51bWJlciA9IDA7IGkgPCBfYnV0dG9uTGlzdC5sZW5ndGg7IGkrKykge1xyXG4gICAgICAgICAgICB1cGRhdGVkQnRuQ29uZmlnLnB1c2godGhpcy5fY2hlY2tCdXR0b24oX2J1dHRvbkxpc3RbaV0pKTtcclxuICAgICAgICB9XHJcbiAgICAgICAgcmV0dXJuIHVwZGF0ZWRCdG5Db25maWc7XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfY2hlY2tCdXR0b24oX2J1dHRvbkl0ZW06IGFueSk6IGFueSB7XHJcbiAgICAgICAgbGV0IGRlZmF1bHRCdXR0b246IGFueSA9IHtcclxuICAgICAgICAgICAgdHlwZTogbnVsbCxcclxuICAgICAgICAgICAgbGFiZWw6ICcnLFxyXG4gICAgICAgICAgICBpY29uOiAnJyxcclxuICAgICAgICAgICAgY29uZmlnOiBudWxsLFxyXG4gICAgICAgICAgICBjYWxsYmFjazogbnVsbCxcclxuICAgICAgICAgICAgcGF0aDogbnVsbFxyXG4gICAgICAgIH07XHJcbiAgICAgICAgcmV0dXJuIE9iamVjdC5hc3NpZ24oZGVmYXVsdEJ1dHRvbiwgX2J1dHRvbkl0ZW0pO1xyXG4gICAgfVxyXG59XHJcbiJdfQ==