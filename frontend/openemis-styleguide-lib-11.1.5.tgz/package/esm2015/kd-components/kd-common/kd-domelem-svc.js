import { Injectable, Renderer2 } from '@angular/core';
import * as i0 from "@angular/core";
export class KdDomElemSvc {
    constructor(_renderer) {
        this._renderer = _renderer;
    }
    isMobile() {
        return (window.innerWidth > 1024) ? false : true;
    }
    isMobileDevice() {
        let ua = navigator.userAgent.toLowerCase();
        return /android|webos|iphone|ipad|ipod|blackberry|iemobile|opera mini|mobi|j2me/i.test(ua);
    }
    getDocumentLang() {
        return document.documentElement.lang;
    }
    getDocumentTheme() {
        let theme = 'openemis-styleguide';
        let bodyElem = document.querySelector('body[class^="openemis-"]');
        if (bodyElem !== null) {
            // console.log(bodyElem.classList);
            // console.log(this.el);
            for (let i = 0; i < bodyElem.classList.length; i++) {
                if (bodyElem.classList[i].match(/^[openemis\-]/)) {
                    theme = bodyElem.classList[i];
                    break;
                }
            }
        }
        return theme;
    }
    /**
     * [To get document direction either LTR or RTL]
     * _isFullStr    : [whether to return short form like 'ltr' or string 'left']
     */
    getDocumentDirection(_isFullStr) {
        if (typeof _isFullStr === 'undefined')
            _isFullStr = false;
        let doc = document.querySelector('[dir]');
        let shortDir = 'ltr';
        if (doc !== null && doc.localName === 'html')
            shortDir = doc['dir'];
        if (_isFullStr) {
            return (shortDir === 'ltr') ? 'left' : 'right';
        }
        else {
            return shortDir;
        }
    }
    createElement(_parentElem, _classes, _name) {
        _name = (typeof _name === 'undefined') ? 'div' : _name;
        _name = (_name === null) ? 'div' : _name;
        let newElem = __ngRendererCreateElementHelper(this._renderer, _parentElem, _name);
        if (_classes !== null)
            this.addClass(newElem, _classes);
        return newElem;
    }
    addClass(_targetElem, _classes) {
        _classes = (typeof _classes === 'undefined') ? '' : _classes;
        let classes = _classes.split(' ');
        for (let i = 0; i < classes.length; i++) {
            // console.log(classes[i]);
            if (classes[i] === '')
                continue;
            this.setElementClass(_targetElem, classes[i], true);
        }
    }
    removeClass(_targetElem, _classes) {
        _classes = (typeof _classes === 'undefined') ? '' : _classes;
        let classes = _classes.split(' ');
        for (let i = 0; i < classes.length; i++) {
            // console.log(classes[i]);
            this.setElementClass(_targetElem, classes[i], false);
        }
    }
    setAttribute(_targetElem, _attribute, _attributeValue) {
        __ngRendererSetElementAttributeHelper(this._renderer, _targetElem, _attribute, _attributeValue);
    }
    setElementClass(_targetElem, _class, _add) {
        _add ? this._renderer.addClass(_targetElem, _class) : this._renderer.removeClass(_targetElem, _class);
    }
    setElementStyle(_targetElem, _slyleName, _styleValue) {
        this._renderer.setStyle(_targetElem, _slyleName, _styleValue);
        return _targetElem;
    }
    invokeElementMethod(_targetElem, _methodName, _arg) {
        _targetElem[_methodName].apply(_targetElem, _arg);
    }
    /**
     * [To remove dom element]
     * _class          : [class of the item to be deleted]
     * _containerElem  : [specify a container to search or the delete element
     *                                     e.g > this.element.nativeElement
     *                                     by default it will search the entire dom]
     */
    removeElementByClass(_class, _containerElem) {
        let containerElem = (typeof _containerElem === 'undefined') ? document : _containerElem;
        let deleteElem = containerElem.querySelector(_class);
        if (deleteElem !== null) {
            deleteElem.parentElement.removeChild(deleteElem);
        }
    }
    /**
     * To do auto append for font icon. For now only support Font Awesome type
     * _class    : [class name. e.g. "fa fa-university" or "fa-university"]
     *            [it will return whether to prepend the a class name or not]
     */
    setIconClass(_class) {
        let className = _class;
        let isSingleWord = _class.indexOf(' ') === -1;
        if (typeof _class === 'undefined' || _class === '' || !isSingleWord)
            return className;
        // Only append for font-awesome prefix class name
        let classes = _class.split('-');
        if (classes[0] === 'fa')
            className = 'fa ' + className;
        return className;
    }
}
KdDomElemSvc.ɵprov = i0.ɵɵdefineInjectable({ factory: function KdDomElemSvc_Factory() { return new KdDomElemSvc(i0.ɵɵinject(i0.Renderer2)); }, token: KdDomElemSvc, providedIn: "root" });
KdDomElemSvc.decorators = [
    { type: Injectable, args: [{
                providedIn: 'root'
            },] }
];
KdDomElemSvc.ctorParameters = () => [
    { type: Renderer2 }
];
function __ngRendererSplitNamespaceHelper(name) {
    if (name[0] === ":") {
        const match = name.match(/^:([^:]+):(.+)$/);
        return [match[1], match[2]];
    }
    return ["", name];
}
function __ngRendererCreateElementHelper(renderer, parent, namespaceAndName) {
    const [namespace, name] = __ngRendererSplitNamespaceHelper(namespaceAndName);
    const node = renderer.createElement(name, namespace);
    if (parent) {
        renderer.appendChild(parent, node);
    }
    return node;
}
function __ngRendererSetElementAttributeHelper(renderer, element, namespaceAndName, value) {
    const [namespace, name] = __ngRendererSplitNamespaceHelper(namespaceAndName);
    if (value != null) {
        renderer.setAttribute(element, name, value, namespace);
    }
    else {
        renderer.removeAttribute(element, name, namespace);
    }
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoia2QtZG9tZWxlbS1zdmMuanMiLCJzb3VyY2VSb290IjoiQzoveGFtcHAvaHRkb2NzL1N0eWxlZ3VpZGUvaW9zdGctb3BlbmVtaXMtc3R5bGVndWlkZS9wcm9qZWN0cy9vcGVuZW1pcy1zdHlsZWd1aWRlLWxpYi9zcmMvIiwic291cmNlcyI6WyJrZC1jb21wb25lbnRzL2tkLWNvbW1vbi9rZC1kb21lbGVtLXN2Yy50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQSxPQUFPLEVBQUUsVUFBVSxFQUFjLFNBQVMsRUFBRSxNQUFNLGVBQWUsQ0FBQzs7QUFLbEUsTUFBTSxPQUFPLFlBQVk7SUFDckIsWUFDWSxTQUFvQjtRQUFwQixjQUFTLEdBQVQsU0FBUyxDQUFXO0lBQzVCLENBQUM7SUFFTCxRQUFRO1FBQ0osT0FBTyxDQUFDLE1BQU0sQ0FBQyxVQUFVLEdBQUcsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDO0lBQ3JELENBQUM7SUFFRCxjQUFjO1FBQ1YsSUFBSSxFQUFFLEdBQVcsU0FBUyxDQUFDLFNBQVMsQ0FBQyxXQUFXLEVBQUUsQ0FBQztRQUNuRCxPQUFPLDBFQUEwRSxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsQ0FBQztJQUMvRixDQUFDO0lBRUQsZUFBZTtRQUNYLE9BQU8sUUFBUSxDQUFDLGVBQWUsQ0FBQyxJQUFJLENBQUM7SUFDekMsQ0FBQztJQUVELGdCQUFnQjtRQUNaLElBQUksS0FBSyxHQUFXLHFCQUFxQixDQUFDO1FBQzFDLElBQUksUUFBUSxHQUFRLFFBQVEsQ0FBQyxhQUFhLENBQUMsMEJBQTBCLENBQUMsQ0FBQztRQUN2RSxJQUFJLFFBQVEsS0FBSyxJQUFJLEVBQUU7WUFDbkIsbUNBQW1DO1lBQ25DLHdCQUF3QjtZQUV4QixLQUFLLElBQUksQ0FBQyxHQUFXLENBQUMsRUFBRSxDQUFDLEdBQUcsUUFBUSxDQUFDLFNBQVMsQ0FBQyxNQUFNLEVBQUUsQ0FBQyxFQUFFLEVBQUU7Z0JBQ3hELElBQUksUUFBUSxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsZUFBZSxDQUFDLEVBQUU7b0JBQzlDLEtBQUssR0FBRyxRQUFRLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDO29CQUM5QixNQUFNO2lCQUNUO2FBQ0o7U0FDSjtRQUVELE9BQU8sS0FBSyxDQUFDO0lBQ2pCLENBQUM7SUFFRDs7O09BR0c7SUFDSCxvQkFBb0IsQ0FBQyxVQUFvQjtRQUNyQyxJQUFJLE9BQU8sVUFBVSxLQUFLLFdBQVc7WUFBRSxVQUFVLEdBQUcsS0FBSyxDQUFDO1FBQzFELElBQUksR0FBRyxHQUFZLFFBQVEsQ0FBQyxhQUFhLENBQUMsT0FBTyxDQUFDLENBQUM7UUFDbkQsSUFBSSxRQUFRLEdBQUcsS0FBSyxDQUFDO1FBQ3JCLElBQUksR0FBRyxLQUFLLElBQUksSUFBSSxHQUFHLENBQUMsU0FBUyxLQUFLLE1BQU07WUFBRSxRQUFRLEdBQUcsR0FBRyxDQUFDLEtBQUssQ0FBQyxDQUFDO1FBRXBFLElBQUksVUFBVSxFQUFFO1lBQ1osT0FBTyxDQUFDLFFBQVEsS0FBSyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUM7U0FDbEQ7YUFDSTtZQUNELE9BQU8sUUFBUSxDQUFDO1NBQ25CO0lBQ0wsQ0FBQztJQUVELGFBQWEsQ0FBQyxXQUFnQixFQUFFLFFBQWlCLEVBQUUsS0FBYztRQUM3RCxLQUFLLEdBQUcsQ0FBQyxPQUFPLEtBQUssS0FBSyxXQUFXLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUM7UUFDdkQsS0FBSyxHQUFHLENBQUMsS0FBSyxLQUFLLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQztRQUV6QyxJQUFJLE9BQU8sR0FBZSwrQkFBK0IsQ0FBQyxJQUFJLENBQUMsU0FBUyxFQUFFLFdBQVcsRUFBRSxLQUFLLENBQUMsQ0FBQztRQUM5RixJQUFJLFFBQVEsS0FBSyxJQUFJO1lBQUUsSUFBSSxDQUFDLFFBQVEsQ0FBQyxPQUFPLEVBQUUsUUFBUSxDQUFDLENBQUM7UUFFeEQsT0FBTyxPQUFPLENBQUM7SUFDbkIsQ0FBQztJQUVELFFBQVEsQ0FBQyxXQUFnQixFQUFFLFFBQWdCO1FBQ3ZDLFFBQVEsR0FBRyxDQUFDLE9BQU8sUUFBUSxLQUFLLFdBQVcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQztRQUM3RCxJQUFJLE9BQU8sR0FBZSxRQUFRLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDO1FBRTlDLEtBQUssSUFBSSxDQUFDLEdBQVcsQ0FBQyxFQUFFLENBQUMsR0FBRyxPQUFPLENBQUMsTUFBTSxFQUFFLENBQUMsRUFBRSxFQUFFO1lBQzdDLDJCQUEyQjtZQUMzQixJQUFJLE9BQU8sQ0FBQyxDQUFDLENBQUMsS0FBSyxFQUFFO2dCQUFFLFNBQVM7WUFDaEMsSUFBSSxDQUFDLGVBQWUsQ0FBQyxXQUFXLEVBQUUsT0FBTyxDQUFDLENBQUMsQ0FBQyxFQUFFLElBQUksQ0FBQyxDQUFDO1NBQ3ZEO0lBQ0wsQ0FBQztJQUVELFdBQVcsQ0FBQyxXQUFnQixFQUFFLFFBQWdCO1FBQzFDLFFBQVEsR0FBRyxDQUFDLE9BQU8sUUFBUSxLQUFLLFdBQVcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQztRQUM3RCxJQUFJLE9BQU8sR0FBZSxRQUFRLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDO1FBRTlDLEtBQUssSUFBSSxDQUFDLEdBQVcsQ0FBQyxFQUFFLENBQUMsR0FBRyxPQUFPLENBQUMsTUFBTSxFQUFFLENBQUMsRUFBRSxFQUFFO1lBQzdDLDJCQUEyQjtZQUMzQixJQUFJLENBQUMsZUFBZSxDQUFDLFdBQVcsRUFBRSxPQUFPLENBQUMsQ0FBQyxDQUFDLEVBQUUsS0FBSyxDQUFDLENBQUM7U0FDeEQ7SUFDTCxDQUFDO0lBRUQsWUFBWSxDQUFDLFdBQWdCLEVBQUUsVUFBa0IsRUFBRSxlQUF1QjtRQUN0RSxxQ0FBcUMsQ0FBQyxJQUFJLENBQUMsU0FBUyxFQUFFLFdBQVcsRUFBRSxVQUFVLEVBQUUsZUFBZSxDQUFDLENBQUM7SUFDcEcsQ0FBQztJQUVELGVBQWUsQ0FBQyxXQUFnQixFQUFFLE1BQWMsRUFBRSxJQUFhO1FBQzNELElBQUksQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxRQUFRLENBQUMsV0FBVyxFQUFFLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLFdBQVcsQ0FBQyxXQUFXLEVBQUUsTUFBTSxDQUFDLENBQUM7SUFDMUcsQ0FBQztJQUVELGVBQWUsQ0FBQyxXQUFnQixFQUFFLFVBQWtCLEVBQUUsV0FBbUI7UUFDckUsSUFBSSxDQUFDLFNBQVMsQ0FBQyxRQUFRLENBQUMsV0FBVyxFQUFFLFVBQVUsRUFBRSxXQUFXLENBQUMsQ0FBQztRQUM5RCxPQUFPLFdBQVcsQ0FBQztJQUN2QixDQUFDO0lBRUQsbUJBQW1CLENBQUMsV0FBZ0IsRUFBRSxXQUFtQixFQUFFLElBQVk7UUFDbEUsV0FBbUIsQ0FBQyxXQUFXLENBQUMsQ0FBQyxLQUFLLENBQUMsV0FBVyxFQUFFLElBQUksQ0FBQyxDQUFDO0lBQy9ELENBQUM7SUFFRDs7Ozs7O09BTUc7SUFDSCxvQkFBb0IsQ0FBQyxNQUFjLEVBQUUsY0FBNEI7UUFDN0QsSUFBSSxhQUFhLEdBQUcsQ0FBQyxPQUFPLGNBQWMsS0FBSyxXQUFXLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxjQUFjLENBQUM7UUFDeEYsSUFBSSxVQUFVLEdBQUcsYUFBYSxDQUFDLGFBQWEsQ0FBQyxNQUFNLENBQUMsQ0FBQztRQUNyRCxJQUFJLFVBQVUsS0FBSyxJQUFJLEVBQUU7WUFDckIsVUFBVSxDQUFDLGFBQWEsQ0FBQyxXQUFXLENBQUMsVUFBVSxDQUFDLENBQUM7U0FDcEQ7SUFDTCxDQUFDO0lBRUQ7Ozs7T0FJRztJQUNILFlBQVksQ0FBQyxNQUFjO1FBQ3ZCLElBQUksU0FBUyxHQUFXLE1BQU0sQ0FBQztRQUMvQixJQUFJLFlBQVksR0FBWSxNQUFNLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDO1FBRXZELElBQUksT0FBTyxNQUFNLEtBQUssV0FBVyxJQUFJLE1BQU0sS0FBSyxFQUFFLElBQUksQ0FBQyxZQUFZO1lBQUUsT0FBTyxTQUFTLENBQUM7UUFDdEYsaURBQWlEO1FBQ2pELElBQUksT0FBTyxHQUFlLE1BQU0sQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLENBQUM7UUFDNUMsSUFBSSxPQUFPLENBQUMsQ0FBQyxDQUFDLEtBQUssSUFBSTtZQUFFLFNBQVMsR0FBRyxLQUFLLEdBQUcsU0FBUyxDQUFDO1FBQ3ZELE9BQU8sU0FBUyxDQUFDO0lBQ3JCLENBQUM7Ozs7WUF0SUosVUFBVSxTQUFDO2dCQUNSLFVBQVUsRUFBRSxNQUFNO2FBQ3JCOzs7WUFKZ0MsU0FBUzs7QUE2STFDLFNBQVMsZ0NBQWdDLENBQUMsSUFBZ0M7SUFDdEUsSUFBSSxJQUFJLENBQUMsQ0FBQyxDQUFDLEtBQUssR0FBRyxFQUFFO1FBQ2pCLE1BQU0sS0FBSyxHQUFHLElBQUksQ0FBQyxLQUFLLENBQUMsaUJBQWlCLENBQUMsQ0FBQztRQUM1QyxPQUFPLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxFQUFFLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0tBQy9CO0lBQ0QsT0FBTyxDQUFDLEVBQUUsRUFBRSxJQUFJLENBQUMsQ0FBQztBQUN0QixDQUFDO0FBRUQsU0FBUywrQkFBK0IsQ0FBQyxRQUFvQyxFQUFFLE1BQWtDLEVBQUUsZ0JBQTRDO0lBQzNKLE1BQU0sQ0FBQyxTQUFTLEVBQUUsSUFBSSxDQUFDLEdBQUcsZ0NBQWdDLENBQUMsZ0JBQWdCLENBQUMsQ0FBQztJQUM3RSxNQUFNLElBQUksR0FBRyxRQUFRLENBQUMsYUFBYSxDQUFDLElBQUksRUFBRSxTQUFTLENBQUMsQ0FBQztJQUNyRCxJQUFJLE1BQU0sRUFBRTtRQUNSLFFBQVEsQ0FBQyxXQUFXLENBQUMsTUFBTSxFQUFFLElBQUksQ0FBQyxDQUFDO0tBQ3RDO0lBQ0QsT0FBTyxJQUFJLENBQUM7QUFDaEIsQ0FBQztBQUVELFNBQVMscUNBQXFDLENBQUMsUUFBb0MsRUFBRSxPQUFtQyxFQUFFLGdCQUE0QyxFQUFFLEtBQWtDO0lBQ3RNLE1BQU0sQ0FBQyxTQUFTLEVBQUUsSUFBSSxDQUFDLEdBQUcsZ0NBQWdDLENBQUMsZ0JBQWdCLENBQUMsQ0FBQztJQUM3RSxJQUFJLEtBQUssSUFBSSxJQUFJLEVBQUU7UUFDZixRQUFRLENBQUMsWUFBWSxDQUFDLE9BQU8sRUFBRSxJQUFJLEVBQUUsS0FBSyxFQUFFLFNBQVMsQ0FBQyxDQUFDO0tBQzFEO1NBQ0k7UUFDRCxRQUFRLENBQUMsZUFBZSxDQUFDLE9BQU8sRUFBRSxJQUFJLEVBQUUsU0FBUyxDQUFDLENBQUM7S0FDdEQ7QUFDTCxDQUFDIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgSW5qZWN0YWJsZSwgRWxlbWVudFJlZiwgUmVuZGVyZXIyIH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XHJcblxyXG5ASW5qZWN0YWJsZSh7XHJcbiAgICBwcm92aWRlZEluOiAncm9vdCdcclxufSlcclxuZXhwb3J0IGNsYXNzIEtkRG9tRWxlbVN2YyB7XHJcbiAgICBjb25zdHJ1Y3RvcihcclxuICAgICAgICBwcml2YXRlIF9yZW5kZXJlcjogUmVuZGVyZXIyXHJcbiAgICApIHsgfVxyXG5cclxuICAgIGlzTW9iaWxlKCk6IGJvb2xlYW4ge1xyXG4gICAgICAgIHJldHVybiAod2luZG93LmlubmVyV2lkdGggPiAxMDI0KSA/IGZhbHNlIDogdHJ1ZTtcclxuICAgIH1cclxuXHJcbiAgICBpc01vYmlsZURldmljZSgpOiBib29sZWFuIHtcclxuICAgICAgICBsZXQgdWE6IHN0cmluZyA9IG5hdmlnYXRvci51c2VyQWdlbnQudG9Mb3dlckNhc2UoKTtcclxuICAgICAgICByZXR1cm4gL2FuZHJvaWR8d2Vib3N8aXBob25lfGlwYWR8aXBvZHxibGFja2JlcnJ5fGllbW9iaWxlfG9wZXJhIG1pbml8bW9iaXxqMm1lL2kudGVzdCh1YSk7XHJcbiAgICB9XHJcblxyXG4gICAgZ2V0RG9jdW1lbnRMYW5nKCk6IHN0cmluZyB7XHJcbiAgICAgICAgcmV0dXJuIGRvY3VtZW50LmRvY3VtZW50RWxlbWVudC5sYW5nO1xyXG4gICAgfVxyXG5cclxuICAgIGdldERvY3VtZW50VGhlbWUoKTogc3RyaW5nIHtcclxuICAgICAgICBsZXQgdGhlbWU6IHN0cmluZyA9ICdvcGVuZW1pcy1zdHlsZWd1aWRlJztcclxuICAgICAgICBsZXQgYm9keUVsZW06IGFueSA9IGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3IoJ2JvZHlbY2xhc3NePVwib3BlbmVtaXMtXCJdJyk7XHJcbiAgICAgICAgaWYgKGJvZHlFbGVtICE9PSBudWxsKSB7XHJcbiAgICAgICAgICAgIC8vIGNvbnNvbGUubG9nKGJvZHlFbGVtLmNsYXNzTGlzdCk7XHJcbiAgICAgICAgICAgIC8vIGNvbnNvbGUubG9nKHRoaXMuZWwpO1xyXG5cclxuICAgICAgICAgICAgZm9yIChsZXQgaTogbnVtYmVyID0gMDsgaSA8IGJvZHlFbGVtLmNsYXNzTGlzdC5sZW5ndGg7IGkrKykge1xyXG4gICAgICAgICAgICAgICAgaWYgKGJvZHlFbGVtLmNsYXNzTGlzdFtpXS5tYXRjaCgvXltvcGVuZW1pc1xcLV0vKSkge1xyXG4gICAgICAgICAgICAgICAgICAgIHRoZW1lID0gYm9keUVsZW0uY2xhc3NMaXN0W2ldO1xyXG4gICAgICAgICAgICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICByZXR1cm4gdGhlbWU7XHJcbiAgICB9XHJcblxyXG4gICAgLyoqXHJcbiAgICAgKiBbVG8gZ2V0IGRvY3VtZW50IGRpcmVjdGlvbiBlaXRoZXIgTFRSIG9yIFJUTF1cclxuICAgICAqIF9pc0Z1bGxTdHIgICAgOiBbd2hldGhlciB0byByZXR1cm4gc2hvcnQgZm9ybSBsaWtlICdsdHInIG9yIHN0cmluZyAnbGVmdCddXHJcbiAgICAgKi9cclxuICAgIGdldERvY3VtZW50RGlyZWN0aW9uKF9pc0Z1bGxTdHI/OiBib29sZWFuKTogc3RyaW5nIHtcclxuICAgICAgICBpZiAodHlwZW9mIF9pc0Z1bGxTdHIgPT09ICd1bmRlZmluZWQnKSBfaXNGdWxsU3RyID0gZmFsc2U7XHJcbiAgICAgICAgbGV0IGRvYzogRWxlbWVudCA9IGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3IoJ1tkaXJdJyk7XHJcbiAgICAgICAgbGV0IHNob3J0RGlyID0gJ2x0cic7XHJcbiAgICAgICAgaWYgKGRvYyAhPT0gbnVsbCAmJiBkb2MubG9jYWxOYW1lID09PSAnaHRtbCcpIHNob3J0RGlyID0gZG9jWydkaXInXTtcclxuXHJcbiAgICAgICAgaWYgKF9pc0Z1bGxTdHIpIHtcclxuICAgICAgICAgICAgcmV0dXJuIChzaG9ydERpciA9PT0gJ2x0cicpID8gJ2xlZnQnIDogJ3JpZ2h0JztcclxuICAgICAgICB9XHJcbiAgICAgICAgZWxzZSB7XHJcbiAgICAgICAgICAgIHJldHVybiBzaG9ydERpcjtcclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgY3JlYXRlRWxlbWVudChfcGFyZW50RWxlbTogYW55LCBfY2xhc3Nlcz86IHN0cmluZywgX25hbWU/OiBzdHJpbmcpOiBhbnkge1xyXG4gICAgICAgIF9uYW1lID0gKHR5cGVvZiBfbmFtZSA9PT0gJ3VuZGVmaW5lZCcpID8gJ2RpdicgOiBfbmFtZTtcclxuICAgICAgICBfbmFtZSA9IChfbmFtZSA9PT0gbnVsbCkgPyAnZGl2JyA6IF9uYW1lO1xyXG5cclxuICAgICAgICBsZXQgbmV3RWxlbTogRWxlbWVudFJlZiA9IF9fbmdSZW5kZXJlckNyZWF0ZUVsZW1lbnRIZWxwZXIodGhpcy5fcmVuZGVyZXIsIF9wYXJlbnRFbGVtLCBfbmFtZSk7XHJcbiAgICAgICAgaWYgKF9jbGFzc2VzICE9PSBudWxsKSB0aGlzLmFkZENsYXNzKG5ld0VsZW0sIF9jbGFzc2VzKTtcclxuXHJcbiAgICAgICAgcmV0dXJuIG5ld0VsZW07XHJcbiAgICB9XHJcblxyXG4gICAgYWRkQ2xhc3MoX3RhcmdldEVsZW06IGFueSwgX2NsYXNzZXM6IHN0cmluZyk6IHZvaWQge1xyXG4gICAgICAgIF9jbGFzc2VzID0gKHR5cGVvZiBfY2xhc3NlcyA9PT0gJ3VuZGVmaW5lZCcpID8gJycgOiBfY2xhc3NlcztcclxuICAgICAgICBsZXQgY2xhc3NlczogQXJyYXk8YW55PiA9IF9jbGFzc2VzLnNwbGl0KCcgJyk7XHJcblxyXG4gICAgICAgIGZvciAobGV0IGk6IG51bWJlciA9IDA7IGkgPCBjbGFzc2VzLmxlbmd0aDsgaSsrKSB7XHJcbiAgICAgICAgICAgIC8vIGNvbnNvbGUubG9nKGNsYXNzZXNbaV0pO1xyXG4gICAgICAgICAgICBpZiAoY2xhc3Nlc1tpXSA9PT0gJycpIGNvbnRpbnVlO1xyXG4gICAgICAgICAgICB0aGlzLnNldEVsZW1lbnRDbGFzcyhfdGFyZ2V0RWxlbSwgY2xhc3Nlc1tpXSwgdHJ1ZSk7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIHJlbW92ZUNsYXNzKF90YXJnZXRFbGVtOiBhbnksIF9jbGFzc2VzOiBzdHJpbmcpOiB2b2lkIHtcclxuICAgICAgICBfY2xhc3NlcyA9ICh0eXBlb2YgX2NsYXNzZXMgPT09ICd1bmRlZmluZWQnKSA/ICcnIDogX2NsYXNzZXM7XHJcbiAgICAgICAgbGV0IGNsYXNzZXM6IEFycmF5PGFueT4gPSBfY2xhc3Nlcy5zcGxpdCgnICcpO1xyXG5cclxuICAgICAgICBmb3IgKGxldCBpOiBudW1iZXIgPSAwOyBpIDwgY2xhc3Nlcy5sZW5ndGg7IGkrKykge1xyXG4gICAgICAgICAgICAvLyBjb25zb2xlLmxvZyhjbGFzc2VzW2ldKTtcclxuICAgICAgICAgICAgdGhpcy5zZXRFbGVtZW50Q2xhc3MoX3RhcmdldEVsZW0sIGNsYXNzZXNbaV0sIGZhbHNlKTtcclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgc2V0QXR0cmlidXRlKF90YXJnZXRFbGVtOiBhbnksIF9hdHRyaWJ1dGU6IHN0cmluZywgX2F0dHJpYnV0ZVZhbHVlOiBzdHJpbmcpOiB2b2lkIHtcclxuICAgICAgICBfX25nUmVuZGVyZXJTZXRFbGVtZW50QXR0cmlidXRlSGVscGVyKHRoaXMuX3JlbmRlcmVyLCBfdGFyZ2V0RWxlbSwgX2F0dHJpYnV0ZSwgX2F0dHJpYnV0ZVZhbHVlKTtcclxuICAgIH1cclxuXHJcbiAgICBzZXRFbGVtZW50Q2xhc3MoX3RhcmdldEVsZW06IGFueSwgX2NsYXNzOiBzdHJpbmcsIF9hZGQ6IGJvb2xlYW4pOiB2b2lkIHtcclxuICAgICAgICBfYWRkID8gdGhpcy5fcmVuZGVyZXIuYWRkQ2xhc3MoX3RhcmdldEVsZW0sIF9jbGFzcykgOiB0aGlzLl9yZW5kZXJlci5yZW1vdmVDbGFzcyhfdGFyZ2V0RWxlbSwgX2NsYXNzKTtcclxuICAgIH1cclxuXHJcbiAgICBzZXRFbGVtZW50U3R5bGUoX3RhcmdldEVsZW06IGFueSwgX3NseWxlTmFtZTogc3RyaW5nLCBfc3R5bGVWYWx1ZTogc3RyaW5nKTogYW55IHtcclxuICAgICAgICB0aGlzLl9yZW5kZXJlci5zZXRTdHlsZShfdGFyZ2V0RWxlbSwgX3NseWxlTmFtZSwgX3N0eWxlVmFsdWUpO1xyXG4gICAgICAgIHJldHVybiBfdGFyZ2V0RWxlbTtcclxuICAgIH1cclxuXHJcbiAgICBpbnZva2VFbGVtZW50TWV0aG9kKF90YXJnZXRFbGVtOiBhbnksIF9tZXRob2ROYW1lOiBzdHJpbmcsIF9hcmc/OiBhbnlbXSk6IGFueSB7XHJcbiAgICAgICAgKF90YXJnZXRFbGVtIGFzIGFueSlbX21ldGhvZE5hbWVdLmFwcGx5KF90YXJnZXRFbGVtLCBfYXJnKTtcclxuICAgIH1cclxuXHJcbiAgICAvKipcclxuICAgICAqIFtUbyByZW1vdmUgZG9tIGVsZW1lbnRdXHJcbiAgICAgKiBfY2xhc3MgICAgICAgICAgOiBbY2xhc3Mgb2YgdGhlIGl0ZW0gdG8gYmUgZGVsZXRlZF1cclxuICAgICAqIF9jb250YWluZXJFbGVtICA6IFtzcGVjaWZ5IGEgY29udGFpbmVyIHRvIHNlYXJjaCBvciB0aGUgZGVsZXRlIGVsZW1lbnRcclxuICAgICAqICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGUuZyA+IHRoaXMuZWxlbWVudC5uYXRpdmVFbGVtZW50XHJcbiAgICAgKiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBieSBkZWZhdWx0IGl0IHdpbGwgc2VhcmNoIHRoZSBlbnRpcmUgZG9tXVxyXG4gICAgICovXHJcbiAgICByZW1vdmVFbGVtZW50QnlDbGFzcyhfY2xhc3M6IHN0cmluZywgX2NvbnRhaW5lckVsZW0/OiBIVE1MRWxlbWVudCk6IHZvaWQge1xyXG4gICAgICAgIGxldCBjb250YWluZXJFbGVtID0gKHR5cGVvZiBfY29udGFpbmVyRWxlbSA9PT0gJ3VuZGVmaW5lZCcpID8gZG9jdW1lbnQgOiBfY29udGFpbmVyRWxlbTtcclxuICAgICAgICBsZXQgZGVsZXRlRWxlbSA9IGNvbnRhaW5lckVsZW0ucXVlcnlTZWxlY3RvcihfY2xhc3MpO1xyXG4gICAgICAgIGlmIChkZWxldGVFbGVtICE9PSBudWxsKSB7XHJcbiAgICAgICAgICAgIGRlbGV0ZUVsZW0ucGFyZW50RWxlbWVudC5yZW1vdmVDaGlsZChkZWxldGVFbGVtKTtcclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgLyoqXHJcbiAgICAgKiBUbyBkbyBhdXRvIGFwcGVuZCBmb3IgZm9udCBpY29uLiBGb3Igbm93IG9ubHkgc3VwcG9ydCBGb250IEF3ZXNvbWUgdHlwZVxyXG4gICAgICogX2NsYXNzICAgIDogW2NsYXNzIG5hbWUuIGUuZy4gXCJmYSBmYS11bml2ZXJzaXR5XCIgb3IgXCJmYS11bml2ZXJzaXR5XCJdXHJcbiAgICAgKiAgICAgICAgICAgIFtpdCB3aWxsIHJldHVybiB3aGV0aGVyIHRvIHByZXBlbmQgdGhlIGEgY2xhc3MgbmFtZSBvciBub3RdXHJcbiAgICAgKi9cclxuICAgIHNldEljb25DbGFzcyhfY2xhc3M6IHN0cmluZyk6IHN0cmluZyB7XHJcbiAgICAgICAgbGV0IGNsYXNzTmFtZTogc3RyaW5nID0gX2NsYXNzO1xyXG4gICAgICAgIGxldCBpc1NpbmdsZVdvcmQ6IGJvb2xlYW4gPSBfY2xhc3MuaW5kZXhPZignICcpID09PSAtMTtcclxuXHJcbiAgICAgICAgaWYgKHR5cGVvZiBfY2xhc3MgPT09ICd1bmRlZmluZWQnIHx8IF9jbGFzcyA9PT0gJycgfHwgIWlzU2luZ2xlV29yZCkgcmV0dXJuIGNsYXNzTmFtZTtcclxuICAgICAgICAvLyBPbmx5IGFwcGVuZCBmb3IgZm9udC1hd2Vzb21lIHByZWZpeCBjbGFzcyBuYW1lXHJcbiAgICAgICAgbGV0IGNsYXNzZXM6IEFycmF5PGFueT4gPSBfY2xhc3Muc3BsaXQoJy0nKTtcclxuICAgICAgICBpZiAoY2xhc3Nlc1swXSA9PT0gJ2ZhJykgY2xhc3NOYW1lID0gJ2ZhICcgKyBjbGFzc05hbWU7XHJcbiAgICAgICAgcmV0dXJuIGNsYXNzTmFtZTtcclxuICAgIH1cclxufVxyXG5cclxudHlwZSBBbnlEdXJpbmdSZW5kZXJlck1pZ3JhdGlvbiA9IGFueTtcclxuXHJcbmZ1bmN0aW9uIF9fbmdSZW5kZXJlclNwbGl0TmFtZXNwYWNlSGVscGVyKG5hbWU6IEFueUR1cmluZ1JlbmRlcmVyTWlncmF0aW9uKSB7XHJcbiAgICBpZiAobmFtZVswXSA9PT0gXCI6XCIpIHtcclxuICAgICAgICBjb25zdCBtYXRjaCA9IG5hbWUubWF0Y2goL146KFteOl0rKTooLispJC8pO1xyXG4gICAgICAgIHJldHVybiBbbWF0Y2hbMV0sIG1hdGNoWzJdXTtcclxuICAgIH1cclxuICAgIHJldHVybiBbXCJcIiwgbmFtZV07XHJcbn1cclxuXHJcbmZ1bmN0aW9uIF9fbmdSZW5kZXJlckNyZWF0ZUVsZW1lbnRIZWxwZXIocmVuZGVyZXI6IEFueUR1cmluZ1JlbmRlcmVyTWlncmF0aW9uLCBwYXJlbnQ6IEFueUR1cmluZ1JlbmRlcmVyTWlncmF0aW9uLCBuYW1lc3BhY2VBbmROYW1lOiBBbnlEdXJpbmdSZW5kZXJlck1pZ3JhdGlvbikge1xyXG4gICAgY29uc3QgW25hbWVzcGFjZSwgbmFtZV0gPSBfX25nUmVuZGVyZXJTcGxpdE5hbWVzcGFjZUhlbHBlcihuYW1lc3BhY2VBbmROYW1lKTtcclxuICAgIGNvbnN0IG5vZGUgPSByZW5kZXJlci5jcmVhdGVFbGVtZW50KG5hbWUsIG5hbWVzcGFjZSk7XHJcbiAgICBpZiAocGFyZW50KSB7XHJcbiAgICAgICAgcmVuZGVyZXIuYXBwZW5kQ2hpbGQocGFyZW50LCBub2RlKTtcclxuICAgIH1cclxuICAgIHJldHVybiBub2RlO1xyXG59XHJcblxyXG5mdW5jdGlvbiBfX25nUmVuZGVyZXJTZXRFbGVtZW50QXR0cmlidXRlSGVscGVyKHJlbmRlcmVyOiBBbnlEdXJpbmdSZW5kZXJlck1pZ3JhdGlvbiwgZWxlbWVudDogQW55RHVyaW5nUmVuZGVyZXJNaWdyYXRpb24sIG5hbWVzcGFjZUFuZE5hbWU6IEFueUR1cmluZ1JlbmRlcmVyTWlncmF0aW9uLCB2YWx1ZT86IEFueUR1cmluZ1JlbmRlcmVyTWlncmF0aW9uKSB7XHJcbiAgICBjb25zdCBbbmFtZXNwYWNlLCBuYW1lXSA9IF9fbmdSZW5kZXJlclNwbGl0TmFtZXNwYWNlSGVscGVyKG5hbWVzcGFjZUFuZE5hbWUpO1xyXG4gICAgaWYgKHZhbHVlICE9IG51bGwpIHtcclxuICAgICAgICByZW5kZXJlci5zZXRBdHRyaWJ1dGUoZWxlbWVudCwgbmFtZSwgdmFsdWUsIG5hbWVzcGFjZSk7XHJcbiAgICB9XHJcbiAgICBlbHNlIHtcclxuICAgICAgICByZW5kZXJlci5yZW1vdmVBdHRyaWJ1dGUoZWxlbWVudCwgbmFtZSwgbmFtZXNwYWNlKTtcclxuICAgIH1cclxufVxyXG4iXX0=