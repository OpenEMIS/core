import { Injectable } from '@angular/core';
// import { KdBroadcaster } from '../kd-broadcaster/kd-broadcaster-svc';
// import { KdBroadcaster } from '../../';
import { KdBroadcaster } from '../index';
import * as i0 from "@angular/core";
import * as i1 from "../kd-broadcaster-svc";
export class KdPageBaseEvent {
    // public broadcaster: KdBroadcaster;
    constructor(broadcaster) {
        this.broadcaster = broadcaster;
    }
    updatePageHeader(data) {
        this.broadcaster.broadcast('Template_UpdatePageHeader', data);
    }
    onUpdatePageHeader() {
        return this.broadcaster.on('Template_UpdatePageHeader');
    }
    updateHeader(data) {
        this.broadcaster.broadcast('Template_UpdateHeader', data);
    }
    onUpdateHeader() {
        return this.broadcaster.on('Template_UpdateHeader');
    }
    updateBreadcrumb(data) {
        this.broadcaster.broadcast('Template_UpdateBreadcrumb', data);
    }
    onUpdateBreadcrumb() {
        return this.broadcaster.on('Template_UpdateBreadcrumb');
    }
    updateLeftmenu(data) {
        this.broadcaster.broadcast('Template_UpdateLeftMenu', data);
    }
    onUpdateLeftmenu() {
        return this.broadcaster.on('Template_UpdateLeftMenu');
    }
    appReady() {
        // this.broadcaster.broadcastReplay('AppReady');
        this.broadcaster.broadcastAsync('AppReady');
    }
    onAppReady() {
        // return this.broadcaster.onReplay<any>('AppReady');
        return this.broadcaster.onAsync('AppReady');
    }
    onAppReadyComplete() {
        this.broadcaster.completeAsync('AppReady');
    }
    // loadV2(data: any): void {
    //     this.broadcaster.broadcast('LoadV2', data);
    // }
    // onLoadV2(): Observable<any> {
    //     return this.broadcaster.on<any>('LoadV2');
    // }
    updateModal(data) {
        this.broadcaster.broadcast('ShowModal', data);
    }
    onUpdateModal() {
        return this.broadcaster.on('ShowModal');
    }
}
KdPageBaseEvent.ɵprov = i0.ɵɵdefineInjectable({ factory: function KdPageBaseEvent_Factory() { return new KdPageBaseEvent(i0.ɵɵinject(i1.KdBroadcaster)); }, token: KdPageBaseEvent, providedIn: "root" });
KdPageBaseEvent.decorators = [
    { type: Injectable, args: [{
                providedIn: 'root'
            },] }
];
KdPageBaseEvent.ctorParameters = () => [
    { type: KdBroadcaster }
];
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoia2QtcGFnZS1iYXNlLmV2ZW50LmpzIiwic291cmNlUm9vdCI6IkM6L3hhbXBwL2h0ZG9jcy9TdHlsZWd1aWRlL2lvc3RnLW9wZW5lbWlzLXN0eWxlZ3VpZGUvcHJvamVjdHMvb3BlbmVtaXMtc3R5bGVndWlkZS1saWIvc3JjLyIsInNvdXJjZXMiOlsia2QtY29tcG9uZW50cy9rZC1jb21tb24va2QtcGFnZS1iYXNlL2tkLXBhZ2UtYmFzZS5ldmVudC50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQSxPQUFPLEVBQUUsVUFBVSxFQUFFLE1BQU0sZUFBZSxDQUFDO0FBRTNDLHdFQUF3RTtBQUN4RSwwQ0FBMEM7QUFDMUMsT0FBTyxFQUFFLGFBQWEsRUFBRSxNQUFNLFVBQVUsQ0FBQzs7O0FBS3pDLE1BQU0sT0FBTyxlQUFlO0lBQ3hCLHFDQUFxQztJQUNyQyxZQUFzQixXQUEwQjtRQUExQixnQkFBVyxHQUFYLFdBQVcsQ0FBZTtJQUFJLENBQUM7SUFFckQsZ0JBQWdCLENBQUMsSUFBUztRQUN0QixJQUFJLENBQUMsV0FBVyxDQUFDLFNBQVMsQ0FBQywyQkFBMkIsRUFBRSxJQUFJLENBQUMsQ0FBQztJQUNsRSxDQUFDO0lBRUQsa0JBQWtCO1FBQ2QsT0FBTyxJQUFJLENBQUMsV0FBVyxDQUFDLEVBQUUsQ0FBTSwyQkFBMkIsQ0FBQyxDQUFDO0lBQ2pFLENBQUM7SUFFRCxZQUFZLENBQUMsSUFBUztRQUNsQixJQUFJLENBQUMsV0FBVyxDQUFDLFNBQVMsQ0FBQyx1QkFBdUIsRUFBRSxJQUFJLENBQUMsQ0FBQztJQUM5RCxDQUFDO0lBRUQsY0FBYztRQUNWLE9BQU8sSUFBSSxDQUFDLFdBQVcsQ0FBQyxFQUFFLENBQU0sdUJBQXVCLENBQUMsQ0FBQztJQUM3RCxDQUFDO0lBRUQsZ0JBQWdCLENBQUMsSUFBUztRQUN0QixJQUFJLENBQUMsV0FBVyxDQUFDLFNBQVMsQ0FBQywyQkFBMkIsRUFBRSxJQUFJLENBQUMsQ0FBQztJQUNsRSxDQUFDO0lBRUQsa0JBQWtCO1FBQ2QsT0FBTyxJQUFJLENBQUMsV0FBVyxDQUFDLEVBQUUsQ0FBTSwyQkFBMkIsQ0FBQyxDQUFDO0lBQ2pFLENBQUM7SUFFRCxjQUFjLENBQUMsSUFBUztRQUNwQixJQUFJLENBQUMsV0FBVyxDQUFDLFNBQVMsQ0FBQyx5QkFBeUIsRUFBRSxJQUFJLENBQUMsQ0FBQztJQUNoRSxDQUFDO0lBRUQsZ0JBQWdCO1FBQ1osT0FBTyxJQUFJLENBQUMsV0FBVyxDQUFDLEVBQUUsQ0FBTSx5QkFBeUIsQ0FBQyxDQUFDO0lBQy9ELENBQUM7SUFFRCxRQUFRO1FBQ0osZ0RBQWdEO1FBQ2hELElBQUksQ0FBQyxXQUFXLENBQUMsY0FBYyxDQUFDLFVBQVUsQ0FBQyxDQUFDO0lBQ2hELENBQUM7SUFFRCxVQUFVO1FBQ04scURBQXFEO1FBQ3JELE9BQU8sSUFBSSxDQUFDLFdBQVcsQ0FBQyxPQUFPLENBQU0sVUFBVSxDQUFDLENBQUM7SUFDckQsQ0FBQztJQUVELGtCQUFrQjtRQUNkLElBQUksQ0FBQyxXQUFXLENBQUMsYUFBYSxDQUFDLFVBQVUsQ0FBQyxDQUFDO0lBQy9DLENBQUM7SUFFRCw0QkFBNEI7SUFDNUIsa0RBQWtEO0lBQ2xELElBQUk7SUFFSixnQ0FBZ0M7SUFDaEMsaURBQWlEO0lBQ2pELElBQUk7SUFFSixXQUFXLENBQUMsSUFBUztRQUNqQixJQUFJLENBQUMsV0FBVyxDQUFDLFNBQVMsQ0FBQyxXQUFXLEVBQUUsSUFBSSxDQUFDLENBQUM7SUFDbEQsQ0FBQztJQUVELGFBQWE7UUFDVCxPQUFPLElBQUksQ0FBQyxXQUFXLENBQUMsRUFBRSxDQUFNLFdBQVcsQ0FBQyxDQUFDO0lBQ2pELENBQUM7Ozs7WUFuRUosVUFBVSxTQUFFO2dCQUNSLFVBQVUsRUFBRSxNQUFNO2FBQ3RCOzs7WUFKUSxhQUFhIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgSW5qZWN0YWJsZSB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xyXG5pbXBvcnQgeyBPYnNlcnZhYmxlIH0gZnJvbSAncnhqcyc7XHJcbi8vIGltcG9ydCB7IEtkQnJvYWRjYXN0ZXIgfSBmcm9tICcuLi9rZC1icm9hZGNhc3Rlci9rZC1icm9hZGNhc3Rlci1zdmMnO1xyXG4vLyBpbXBvcnQgeyBLZEJyb2FkY2FzdGVyIH0gZnJvbSAnLi4vLi4vJztcclxuaW1wb3J0IHsgS2RCcm9hZGNhc3RlciB9IGZyb20gJy4uL2luZGV4JztcclxuXHJcbkBJbmplY3RhYmxlKCB7XHJcbiAgICAgcHJvdmlkZWRJbjogJ3Jvb3QnXHJcbn0gKVxyXG5leHBvcnQgY2xhc3MgS2RQYWdlQmFzZUV2ZW50IHtcclxuICAgIC8vIHB1YmxpYyBicm9hZGNhc3RlcjogS2RCcm9hZGNhc3RlcjtcclxuICAgIGNvbnN0cnVjdG9yKHByb3RlY3RlZCBicm9hZGNhc3RlcjogS2RCcm9hZGNhc3RlcikgeyB9XHJcblxyXG4gICAgdXBkYXRlUGFnZUhlYWRlcihkYXRhOiBhbnkpOiB2b2lkIHtcclxuICAgICAgICB0aGlzLmJyb2FkY2FzdGVyLmJyb2FkY2FzdCgnVGVtcGxhdGVfVXBkYXRlUGFnZUhlYWRlcicsIGRhdGEpO1xyXG4gICAgfVxyXG5cclxuICAgIG9uVXBkYXRlUGFnZUhlYWRlcigpOiBPYnNlcnZhYmxlPGFueT4ge1xyXG4gICAgICAgIHJldHVybiB0aGlzLmJyb2FkY2FzdGVyLm9uPGFueT4oJ1RlbXBsYXRlX1VwZGF0ZVBhZ2VIZWFkZXInKTtcclxuICAgIH1cclxuXHJcbiAgICB1cGRhdGVIZWFkZXIoZGF0YTogYW55KTogdm9pZCB7XHJcbiAgICAgICAgdGhpcy5icm9hZGNhc3Rlci5icm9hZGNhc3QoJ1RlbXBsYXRlX1VwZGF0ZUhlYWRlcicsIGRhdGEpO1xyXG4gICAgfVxyXG5cclxuICAgIG9uVXBkYXRlSGVhZGVyKCk6IE9ic2VydmFibGU8YW55PiB7XHJcbiAgICAgICAgcmV0dXJuIHRoaXMuYnJvYWRjYXN0ZXIub248YW55PignVGVtcGxhdGVfVXBkYXRlSGVhZGVyJyk7XHJcbiAgICB9XHJcblxyXG4gICAgdXBkYXRlQnJlYWRjcnVtYihkYXRhOiBhbnkpOiB2b2lkIHtcclxuICAgICAgICB0aGlzLmJyb2FkY2FzdGVyLmJyb2FkY2FzdCgnVGVtcGxhdGVfVXBkYXRlQnJlYWRjcnVtYicsIGRhdGEpO1xyXG4gICAgfVxyXG5cclxuICAgIG9uVXBkYXRlQnJlYWRjcnVtYigpOiBPYnNlcnZhYmxlPGFueT4ge1xyXG4gICAgICAgIHJldHVybiB0aGlzLmJyb2FkY2FzdGVyLm9uPGFueT4oJ1RlbXBsYXRlX1VwZGF0ZUJyZWFkY3J1bWInKTtcclxuICAgIH1cclxuXHJcbiAgICB1cGRhdGVMZWZ0bWVudShkYXRhOiBhbnkpOiB2b2lkIHtcclxuICAgICAgICB0aGlzLmJyb2FkY2FzdGVyLmJyb2FkY2FzdCgnVGVtcGxhdGVfVXBkYXRlTGVmdE1lbnUnLCBkYXRhKTtcclxuICAgIH1cclxuXHJcbiAgICBvblVwZGF0ZUxlZnRtZW51KCk6IE9ic2VydmFibGU8YW55PiB7XHJcbiAgICAgICAgcmV0dXJuIHRoaXMuYnJvYWRjYXN0ZXIub248YW55PignVGVtcGxhdGVfVXBkYXRlTGVmdE1lbnUnKTtcclxuICAgIH1cclxuXHJcbiAgICBhcHBSZWFkeSgpOiB2b2lkIHtcclxuICAgICAgICAvLyB0aGlzLmJyb2FkY2FzdGVyLmJyb2FkY2FzdFJlcGxheSgnQXBwUmVhZHknKTtcclxuICAgICAgICB0aGlzLmJyb2FkY2FzdGVyLmJyb2FkY2FzdEFzeW5jKCdBcHBSZWFkeScpO1xyXG4gICAgfVxyXG5cclxuICAgIG9uQXBwUmVhZHkoKTogT2JzZXJ2YWJsZTxhbnk+IHtcclxuICAgICAgICAvLyByZXR1cm4gdGhpcy5icm9hZGNhc3Rlci5vblJlcGxheTxhbnk+KCdBcHBSZWFkeScpO1xyXG4gICAgICAgIHJldHVybiB0aGlzLmJyb2FkY2FzdGVyLm9uQXN5bmM8YW55PignQXBwUmVhZHknKTtcclxuICAgIH1cclxuXHJcbiAgICBvbkFwcFJlYWR5Q29tcGxldGUoKTogdm9pZCB7XHJcbiAgICAgICAgdGhpcy5icm9hZGNhc3Rlci5jb21wbGV0ZUFzeW5jKCdBcHBSZWFkeScpO1xyXG4gICAgfVxyXG5cclxuICAgIC8vIGxvYWRWMihkYXRhOiBhbnkpOiB2b2lkIHtcclxuICAgIC8vICAgICB0aGlzLmJyb2FkY2FzdGVyLmJyb2FkY2FzdCgnTG9hZFYyJywgZGF0YSk7XHJcbiAgICAvLyB9XHJcblxyXG4gICAgLy8gb25Mb2FkVjIoKTogT2JzZXJ2YWJsZTxhbnk+IHtcclxuICAgIC8vICAgICByZXR1cm4gdGhpcy5icm9hZGNhc3Rlci5vbjxhbnk+KCdMb2FkVjInKTtcclxuICAgIC8vIH1cclxuXHJcbiAgICB1cGRhdGVNb2RhbChkYXRhOiBhbnkpOiB2b2lkIHtcclxuICAgICAgICB0aGlzLmJyb2FkY2FzdGVyLmJyb2FkY2FzdCgnU2hvd01vZGFsJywgZGF0YSk7XHJcbiAgICB9XHJcblxyXG4gICAgb25VcGRhdGVNb2RhbCgpOiBPYnNlcnZhYmxlPGFueT4ge1xyXG4gICAgICAgIHJldHVybiB0aGlzLmJyb2FkY2FzdGVyLm9uPGFueT4oJ1Nob3dNb2RhbCcpO1xyXG4gICAgfVxyXG59XHJcbiJdfQ==