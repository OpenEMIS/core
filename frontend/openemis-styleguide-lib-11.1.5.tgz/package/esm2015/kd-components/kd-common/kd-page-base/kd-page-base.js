import { NavigationEnd } from '@angular/router';
import { KdConvertionSvc, KdDataSvc } from '../index';
export class KdPageBase {
    constructor(options) {
        this.options = options;
        this._textOmitted = '';
        this._header = {
            brandLogo: {},
            userInfo: {
                name: '',
                imgType: 'icon',
                imgSrc: '',
                path: ''
            },
            btnGroup: []
        };
        this._pageheader = {
            pageheaderText: '',
            leftBtn: [],
            // leftBtn: [{
            //     type: 'add'
            // }],
            moreBtn: false,
            moreAction: [],
            searchBtn: false,
            searchEvent: ['change', 'keyup']
        };
        this._breadcrumbList = {
            home: { icon: 'fa fa-home', url: '', path: '/App/InstitutionClasses/list' },
            list: []
        };
        this._pageParams = {};
        this._prevPageURL = '';
        this._currentURL = '';
        this.convertionSvc = new KdConvertionSvc();
        this.dataSvc = new KdDataSvc();
        // this._prevPageInfo = this.initPrevHistory();
        // this.options.router.events
        //     .filter(e => e instanceof RoutesRecognized)
        //     // .filter(e => (e.constructor.name === 'RoutesRecognized') || ( e.constructor.name === 'NavigationEnd'))
        //     .pairwise()
        //     .subscribe((e: any[]): void => {
        //         console.log('1 on init > url info ', e);
        //         console.log(new Date());
        //         console.log(e[0]);
        //         console.log(e[e.length - 1]);
        //         this._prevPageInfo = e[0].urlAfterRedirects;
        //         // console.log('this._prevPageInfo = > ', this._prevPageInfo);
        //         // this._routerHistorySub.unsubscribe();
        //     });
        // console.log('constructor >> ',this._prevPageInfo);
        this._routerSub = this.options.router.events
            .subscribe(event => {
            // if (event instanceof RoutesRecognized) {
            // console.log('RoutesRecognized > event - ', Object.assign({}, event));
            // }
            if (event instanceof NavigationEnd) {
                // console.log('>>', event);
                this._prevPageURL = JSON.stringify(this._currentURL);
                this._currentURL = event.urlAfterRedirects;
                this._breadcrumbList.list = this.convertionSvc.urlToArray(event.urlAfterRedirects, this._textOmitted);
                // console.log('this._breadcrumbList.list',this._breadcrumbList.list);
                if (typeof this.options.pageEvent !== 'undefined') {
                    this.options.pageEvent.appReady();
                    this.options.pageEvent.onAppReadyComplete();
                }
                if (typeof this.options.pageBaseEvent !== 'undefined') {
                    console.error('please change to PageEvent instead of PageBaseEvent');
                }
            }
        });
        this._activatedRouteSub = this.options.activatedRoute.params.subscribe((_params) => {
            this._pageParams = _params;
        });
    }
    // protected enableLoadV2(_bool: boolean) {
    //     // this.options.pageEvent.loadV2(_bool);
    // }
    /**
     * [destroyPageBaseSub - Manually discard the all the subscriptions]
     */
    destroyPageBaseSub() {
        if (typeof this._routerSub !== 'undefined')
            this._routerSub.unsubscribe();
        if (typeof this._activatedRouteSub !== 'undefined')
            this._activatedRouteSub.unsubscribe();
    }
    /**
     * Application Header (Product Header)
     */
    getHeaderConfig() {
        return this._header.userInfo;
    }
    setHeaderConfig(_conf) {
        this._header.userInfo = _conf;
    }
    updateHeader() {
        this.options.pageEvent.updateHeader(this._header);
    }
    /**
     * Left Navigation
     */
    setLeftMenuList(_leftMenuObj) {
        this.options.pageEvent.updateLeftmenu(_leftMenuObj);
    }
    /**
     * Page Header
     */
    getPageTitle() {
        return this._pageheader.pageheaderText;
    }
    setPageTitle(_title, _humanize = true) {
        let tempStr = _title.replace(this._textOmitted, '');
        if (_humanize) {
            tempStr = this.humanize(this.underscore(tempStr));
        }
        // console.log('setPageTitle=',tempStr);
        this._pageheader.pageheaderText = tempStr;
    }
    getToolbarMainBtns() {
        return JSON.parse(JSON.stringify(this._pageheader.leftBtn));
    }
    setToolbarMainBtns(_buttons) {
        this._pageheader.leftBtn = _buttons;
    }
    getToolbarMoreActionBtns() {
        return this._pageheader.moreAction;
    }
    enableMoreActionBtns(_enable, _buttons) {
        this._pageheader.moreBtn = _enable;
        if (_buttons) {
            this._pageheader.moreAction = _buttons;
        }
    }
    enableToolbarSearch(_enable, _callback) {
        this._pageheader.searchBtn = _enable;
        if (_enable && _callback) {
            this._pageheader.searchCallback = _callback;
        }
    }
    updateSearchText(_searchText) {
        this._pageheader.searchText = _searchText;
    }
    updatePageHeader() {
        console.log('broadcast updatePageHeader', this._pageheader);
        this.options.pageEvent.updatePageHeader(this._pageheader);
    }
    /**
     * Breadcrumbs
     */
    setBreadcrumbsList(_list) {
        this._breadcrumbList.list = _list;
        this.updateBreadcrumb();
    }
    getBreadcrumbsList() {
        return this._breadcrumbList.list;
    }
    updateBreadcrumb() {
        this.options.pageEvent.updateBreadcrumb(JSON.parse(JSON.stringify(this._breadcrumbList)));
    }
    /**
     * Alerts
     */
    setAlert(_config, _type) {
        if (this.options.alertEvent) {
            this.options.alertEvent[_type](_config);
        }
        else {
            console.warn('Missing event - KdAlertEvent');
        }
    }
    /**
     * [setModal Creating modal view]
     *  _configConfimation {
     *              header: '',
     *              message: '',
     *              buttonConfirm: {
     *                  text: 'test text',
     *                  callback: () =>{
     *
     *                  }
     *              }
     *          }
     */
    setModal() {
        let _pageBaseEvent;
        if (this.options.pageEvent) {
            _pageBaseEvent = this.options.pageEvent;
        }
        else {
            console.warn('Please import \'PageBaseEvent\' to use modal');
        }
        /**
         * [confirmation a modal dialog with 2 buttons: 'Confirm' and 'Cancel']
         */
        function confirmation(_config) {
            if (_pageBaseEvent) {
                let updatedConfig = {};
                let defaultConfig = {
                    suspendClose: true,
                    title: 'Alert',
                    body: 'Dummy text - confirmation',
                    button: [{
                            text: 'Confirm',
                            class: 'btn-text',
                            callback: () => { }
                        },
                        {
                            text: 'Cancel',
                            class: 'btn-outline',
                            callback: () => { _pageBaseEvent.updateModal({ close: true }); }
                        }]
                };
                updatedConfig = applyConfig(_config, defaultConfig);
                _pageBaseEvent.updateModal({ enabled: true, config: updatedConfig });
            }
        }
        /**
         * [notify a modal dialog with 1 button: 'Done']
         */
        function notify(_config) {
            if (_pageBaseEvent) {
                let updatedConfig = {};
                let defaultConfig = {
                    suspendClose: true,
                    title: 'Alert',
                    body: 'Dummy text - notify',
                    button: [{
                            text: 'Done',
                            class: 'btn-text',
                            callback: () => { _pageBaseEvent.updateModal({ close: true }); }
                        }]
                };
                updatedConfig = applyConfig(_config, defaultConfig);
                _pageBaseEvent.updateModal({ enabled: true, config: updatedConfig });
            }
        }
        function disabled() {
            if (_pageBaseEvent)
                _pageBaseEvent.updateModal({ enabled: false });
        }
        function close() {
            if (_pageBaseEvent)
                _pageBaseEvent.updateModal({ close: true });
        }
        function applyConfig(_sourceConfig, _targetConfig) {
            let updatedConfig = {};
            Object.assign(updatedConfig, _targetConfig);
            if (_sourceConfig.header)
                updatedConfig.title = _sourceConfig.header;
            if (_sourceConfig.message)
                updatedConfig.body = _sourceConfig.message;
            if (_sourceConfig.buttonConfirm) {
                if (_sourceConfig.buttonConfirm.text)
                    updatedConfig.button[0].text = _sourceConfig.buttonConfirm.text;
                if (_sourceConfig.buttonConfirm.callback)
                    updatedConfig.button[0].callback = _sourceConfig.buttonConfirm.callback;
            }
            return updatedConfig;
        }
        return {
            confirmation: confirmation,
            notify: notify,
            disabled: disabled,
            close: close
        };
    }
    /**
     * Utils Methods
     */
    // private initPrevHistory(){
    //     // this._routerHistorySub = this.options.router.events
    //     return this.options.router.events
    //         .filter(e => e instanceof RoutesRecognized)
    //         // .filter(e => (e.constructor.name === 'RoutesRecognized') || ( e.constructor.name === 'NavigationEnd'))
    //         .pairwise()
    //         .subscribe((e: any[]): void => {
    //             console.log('1 on init > url info ', e);
    //             console.log(new Date());
    //             console.log(e[0]);
    //             console.log(e[e.length - 1]);
    //             return e[0];
    //             // console.log('this._prevPageInfo = > ', this._prevPageInfo);
    //             // this._routerHistorySub.unsubscribe();
    //         });
    // }
    getCurrentURL() {
        return this._currentURL;
    }
    setTextOmit(_text) {
        this._textOmitted = _text;
    }
    getParams() {
        return this._pageParams;
    }
    getPrevPageInfo() {
        console.log('getPrevPageInfo . >> ', this._prevPageURL);
        return this._prevPageURL;
    }
    underscore(_camelCase) {
        return this.convertionSvc.underscore(_camelCase);
    }
    humanize(_underscored) {
        return this.convertionSvc.humanize(_underscored);
    }
    camelCase(_text) {
        return this.convertionSvc.camelCase(_text, ' ');
    }
    slug(_word) {
        return this.convertionSvc.slug(_word);
    }
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoia2QtcGFnZS1iYXNlLmpzIiwic291cmNlUm9vdCI6IkM6L3hhbXBwL2h0ZG9jcy9TdHlsZWd1aWRlL2lvc3RnLW9wZW5lbWlzLXN0eWxlZ3VpZGUvcHJvamVjdHMvb3BlbmVtaXMtc3R5bGVndWlkZS1saWIvc3JjLyIsInNvdXJjZXMiOlsia2QtY29tcG9uZW50cy9rZC1jb21tb24va2QtcGFnZS1iYXNlL2tkLXBhZ2UtYmFzZS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFDQSxPQUFPLEVBQVUsYUFBYSxFQUEwQixNQUFNLGlCQUFpQixDQUFDO0FBRWhGLE9BQU8sRUFBRSxlQUFlLEVBQUUsU0FBUyxFQUFFLE1BQU0sVUFBVSxDQUFDO0FBY3RELE1BQU0sT0FBTyxVQUFVO0lBc0NuQixZQUNXLE9BQXlCO1FBQXpCLFlBQU8sR0FBUCxPQUFPLENBQWtCO1FBdEM1QixpQkFBWSxHQUFXLEVBQUUsQ0FBQztRQUMxQixZQUFPLEdBQVE7WUFDbkIsU0FBUyxFQUFFLEVBQUU7WUFDYixRQUFRLEVBQUU7Z0JBQ04sSUFBSSxFQUFFLEVBQUU7Z0JBQ1IsT0FBTyxFQUFFLE1BQU07Z0JBQ2YsTUFBTSxFQUFFLEVBQUU7Z0JBQ1YsSUFBSSxFQUFFLEVBQUU7YUFDWDtZQUNELFFBQVEsRUFBRSxFQUFFO1NBQ2YsQ0FBQztRQUVNLGdCQUFXLEdBQXNCO1lBQ3JDLGNBQWMsRUFBRSxFQUFFO1lBQ2xCLE9BQU8sRUFBRSxFQUFFO1lBQ1gsY0FBYztZQUNkLGtCQUFrQjtZQUNsQixNQUFNO1lBQ04sT0FBTyxFQUFFLEtBQUs7WUFDZCxVQUFVLEVBQUUsRUFBRTtZQUNkLFNBQVMsRUFBRSxLQUFLO1lBQ2hCLFdBQVcsRUFBRSxDQUFDLFFBQVEsRUFBRSxPQUFPLENBQUM7U0FDbkMsQ0FBQztRQUVNLG9CQUFlLEdBQVE7WUFDM0IsSUFBSSxFQUFFLEVBQUUsSUFBSSxFQUFFLFlBQVksRUFBRSxHQUFHLEVBQUUsRUFBRSxFQUFFLElBQUksRUFBRSw4QkFBOEIsRUFBRTtZQUMzRSxJQUFJLEVBQUUsRUFBRTtTQUNYLENBQUM7UUFDTSxnQkFBVyxHQUFRLEVBQUUsQ0FBQztRQUN0QixpQkFBWSxHQUFXLEVBQUUsQ0FBQztRQU8xQixnQkFBVyxHQUFXLEVBQUUsQ0FBQztRQUk3QixJQUFJLENBQUMsYUFBYSxHQUFHLElBQUksZUFBZSxFQUFFLENBQUM7UUFDM0MsSUFBSSxDQUFDLE9BQU8sR0FBRyxJQUFJLFNBQVMsRUFBRSxDQUFDO1FBRS9CLCtDQUErQztRQUMvQyw2QkFBNkI7UUFDN0Isa0RBQWtEO1FBQ2xELGdIQUFnSDtRQUNoSCxrQkFBa0I7UUFDbEIsdUNBQXVDO1FBQ3ZDLG1EQUFtRDtRQUNuRCxtQ0FBbUM7UUFDbkMsNkJBQTZCO1FBQzdCLHdDQUF3QztRQUN4Qyx1REFBdUQ7UUFDdkQseUVBQXlFO1FBQ3pFLG1EQUFtRDtRQUNuRCxVQUFVO1FBRVYscURBQXFEO1FBQ3JELElBQUksQ0FBQyxVQUFVLEdBQUcsSUFBSSxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsTUFBTTthQUN2QyxTQUFTLENBQUMsS0FBSyxDQUFDLEVBQUU7WUFDZiwyQ0FBMkM7WUFDM0Msd0VBQXdFO1lBQ3hFLElBQUk7WUFDSixJQUFJLEtBQUssWUFBWSxhQUFhLEVBQUU7Z0JBQ2hDLDRCQUE0QjtnQkFDNUIsSUFBSSxDQUFDLFlBQVksR0FBRyxJQUFJLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQyxXQUFXLENBQUMsQ0FBQztnQkFDckQsSUFBSSxDQUFDLFdBQVcsR0FBRyxLQUFLLENBQUMsaUJBQWlCLENBQUM7Z0JBQzNDLElBQUksQ0FBQyxlQUFlLENBQUMsSUFBSSxHQUFHLElBQUksQ0FBQyxhQUFhLENBQUMsVUFBVSxDQUFDLEtBQUssQ0FBQyxpQkFBaUIsRUFBRSxJQUFJLENBQUMsWUFBWSxDQUFDLENBQUM7Z0JBQ3RHLHNFQUFzRTtnQkFDdEUsSUFBSSxPQUFPLElBQUksQ0FBQyxPQUFPLENBQUMsU0FBUyxLQUFLLFdBQVcsRUFBRTtvQkFDL0MsSUFBSSxDQUFDLE9BQU8sQ0FBQyxTQUFTLENBQUMsUUFBUSxFQUFFLENBQUM7b0JBQ2xDLElBQUksQ0FBQyxPQUFPLENBQUMsU0FBUyxDQUFDLGtCQUFrQixFQUFFLENBQUM7aUJBQy9DO2dCQUVELElBQUksT0FBTyxJQUFJLENBQUMsT0FBTyxDQUFDLGFBQWEsS0FBSyxXQUFXLEVBQUU7b0JBQ25ELE9BQU8sQ0FBQyxLQUFLLENBQUMscURBQXFELENBQUMsQ0FBQztpQkFDeEU7YUFDSjtRQUNMLENBQUMsQ0FBQyxDQUFDO1FBRVAsSUFBSSxDQUFDLGtCQUFrQixHQUFHLElBQUksQ0FBQyxPQUFPLENBQUMsY0FBYyxDQUFDLE1BQU0sQ0FBQyxTQUFTLENBQUMsQ0FBQyxPQUFlLEVBQVEsRUFBRTtZQUM3RixJQUFJLENBQUMsV0FBVyxHQUFHLE9BQU8sQ0FBQztRQUMvQixDQUFDLENBQUMsQ0FBQztJQUNQLENBQUM7SUFDRCwyQ0FBMkM7SUFDM0MsK0NBQStDO0lBQy9DLElBQUk7SUFFSjs7T0FFRztJQUNPLGtCQUFrQjtRQUN4QixJQUFJLE9BQU8sSUFBSSxDQUFDLFVBQVUsS0FBSyxXQUFXO1lBQUUsSUFBSSxDQUFDLFVBQVUsQ0FBQyxXQUFXLEVBQUUsQ0FBQztRQUMxRSxJQUFJLE9BQU8sSUFBSSxDQUFDLGtCQUFrQixLQUFLLFdBQVc7WUFBRSxJQUFJLENBQUMsa0JBQWtCLENBQUMsV0FBVyxFQUFFLENBQUM7SUFDOUYsQ0FBQztJQUVEOztPQUVHO0lBRU8sZUFBZTtRQUNyQixPQUFPLElBQUksQ0FBQyxPQUFPLENBQUMsUUFBUSxDQUFDO0lBQ2pDLENBQUM7SUFFUyxlQUFlLENBQUMsS0FBVTtRQUNoQyxJQUFJLENBQUMsT0FBTyxDQUFDLFFBQVEsR0FBRyxLQUFLLENBQUM7SUFDbEMsQ0FBQztJQUVTLFlBQVk7UUFDbEIsSUFBSSxDQUFDLE9BQU8sQ0FBQyxTQUFTLENBQUMsWUFBWSxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsQ0FBQztJQUN0RCxDQUFDO0lBRUQ7O09BRUc7SUFFTyxlQUFlLENBQUMsWUFBaUI7UUFDdkMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxTQUFTLENBQUMsY0FBYyxDQUFDLFlBQVksQ0FBQyxDQUFDO0lBQ3hELENBQUM7SUFFRDs7T0FFRztJQUVPLFlBQVk7UUFDbEIsT0FBTyxJQUFJLENBQUMsV0FBVyxDQUFDLGNBQWMsQ0FBQztJQUMzQyxDQUFDO0lBRVMsWUFBWSxDQUFDLE1BQWMsRUFBRSxZQUFxQixJQUFJO1FBQzVELElBQUksT0FBTyxHQUFXLE1BQU0sQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLFlBQVksRUFBRSxFQUFFLENBQUMsQ0FBQztRQUM1RCxJQUFJLFNBQVMsRUFBRTtZQUNYLE9BQU8sR0FBRyxJQUFJLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQztTQUNyRDtRQUNELHdDQUF3QztRQUN4QyxJQUFJLENBQUMsV0FBVyxDQUFDLGNBQWMsR0FBRyxPQUFPLENBQUM7SUFDOUMsQ0FBQztJQUVTLGtCQUFrQjtRQUN4QixPQUFPLElBQUksQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUM7SUFDaEUsQ0FBQztJQUVTLGtCQUFrQixDQUFDLFFBQW9CO1FBQzdDLElBQUksQ0FBQyxXQUFXLENBQUMsT0FBTyxHQUFHLFFBQVEsQ0FBQztJQUN4QyxDQUFDO0lBRVMsd0JBQXdCO1FBQzlCLE9BQU8sSUFBSSxDQUFDLFdBQVcsQ0FBQyxVQUFVLENBQUM7SUFDdkMsQ0FBQztJQUVTLG9CQUFvQixDQUFDLE9BQWdCLEVBQUUsUUFBcUI7UUFDbEUsSUFBSSxDQUFDLFdBQVcsQ0FBQyxPQUFPLEdBQUcsT0FBTyxDQUFDO1FBQ25DLElBQUksUUFBUSxFQUFFO1lBQ1YsSUFBSSxDQUFDLFdBQVcsQ0FBQyxVQUFVLEdBQUcsUUFBUSxDQUFDO1NBQzFDO0lBQ0wsQ0FBQztJQUVTLG1CQUFtQixDQUFDLE9BQWdCLEVBQUUsU0FBbUM7UUFDL0UsSUFBSSxDQUFDLFdBQVcsQ0FBQyxTQUFTLEdBQUcsT0FBTyxDQUFDO1FBQ3JDLElBQUksT0FBTyxJQUFJLFNBQVMsRUFBRTtZQUN0QixJQUFJLENBQUMsV0FBVyxDQUFDLGNBQWMsR0FBRyxTQUFTLENBQUM7U0FDL0M7SUFDTCxDQUFDO0lBRVMsZ0JBQWdCLENBQUMsV0FBbUI7UUFDMUMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxVQUFVLEdBQUcsV0FBVyxDQUFDO0lBQzlDLENBQUM7SUFFUyxnQkFBZ0I7UUFDdEIsT0FBTyxDQUFDLEdBQUcsQ0FBQyw0QkFBNEIsRUFBRSxJQUFJLENBQUMsV0FBVyxDQUFDLENBQUM7UUFDNUQsSUFBSSxDQUFDLE9BQU8sQ0FBQyxTQUFTLENBQUMsZ0JBQWdCLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxDQUFDO0lBQzlELENBQUM7SUFFRDs7T0FFRztJQUVPLGtCQUFrQixDQUFDLEtBQWlCO1FBQzFDLElBQUksQ0FBQyxlQUFlLENBQUMsSUFBSSxHQUFHLEtBQUssQ0FBQztRQUNsQyxJQUFJLENBQUMsZ0JBQWdCLEVBQUUsQ0FBQztJQUM1QixDQUFDO0lBRVMsa0JBQWtCO1FBQ3hCLE9BQU8sSUFBSSxDQUFDLGVBQWUsQ0FBQyxJQUFJLENBQUM7SUFDckMsQ0FBQztJQUVTLGdCQUFnQjtRQUN0QixJQUFJLENBQUMsT0FBTyxDQUFDLFNBQVMsQ0FBQyxnQkFBZ0IsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDLGVBQWUsQ0FBQyxDQUFDLENBQUMsQ0FBQztJQUM5RixDQUFDO0lBRUQ7O09BRUc7SUFFTyxRQUFRLENBQUMsT0FBWSxFQUFFLEtBQWE7UUFDMUMsSUFBSSxJQUFJLENBQUMsT0FBTyxDQUFDLFVBQVUsRUFBRTtZQUN6QixJQUFJLENBQUMsT0FBTyxDQUFDLFVBQVUsQ0FBQyxLQUFLLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQztTQUMzQzthQUNJO1lBQ0QsT0FBTyxDQUFDLElBQUksQ0FBQyw4QkFBOEIsQ0FBQyxDQUFDO1NBQ2hEO0lBQ0wsQ0FBQztJQUVEOzs7Ozs7Ozs7Ozs7T0FZRztJQUNPLFFBQVE7UUFDZCxJQUFJLGNBQStCLENBQUM7UUFDcEMsSUFBSSxJQUFJLENBQUMsT0FBTyxDQUFDLFNBQVMsRUFBRTtZQUN4QixjQUFjLEdBQUcsSUFBSSxDQUFDLE9BQU8sQ0FBQyxTQUFTLENBQUM7U0FDM0M7YUFDSTtZQUNELE9BQU8sQ0FBQyxJQUFJLENBQUMsOENBQThDLENBQUMsQ0FBQztTQUNoRTtRQUVEOztXQUVHO1FBQ0gsU0FBUyxZQUFZLENBQUMsT0FBYTtZQUMvQixJQUFJLGNBQWMsRUFBRTtnQkFDaEIsSUFBSSxhQUFhLEdBQVEsRUFBRSxDQUFDO2dCQUM1QixJQUFJLGFBQWEsR0FBUTtvQkFDckIsWUFBWSxFQUFFLElBQUk7b0JBQ2xCLEtBQUssRUFBRSxPQUFPO29CQUNkLElBQUksRUFBRSwyQkFBMkI7b0JBQ2pDLE1BQU0sRUFBRSxDQUFDOzRCQUNMLElBQUksRUFBRSxTQUFTOzRCQUNmLEtBQUssRUFBRSxVQUFVOzRCQUNqQixRQUFRLEVBQUUsR0FBUyxFQUFFLEdBQUcsQ0FBQzt5QkFDNUI7d0JBQ0Q7NEJBQ0ksSUFBSSxFQUFFLFFBQVE7NEJBQ2QsS0FBSyxFQUFFLGFBQWE7NEJBQ3BCLFFBQVEsRUFBRSxHQUFTLEVBQUUsR0FBRyxjQUFjLENBQUMsV0FBVyxDQUFDLEVBQUUsS0FBSyxFQUFFLElBQUksRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDO3lCQUN6RSxDQUFDO2lCQUNMLENBQUM7Z0JBRUYsYUFBYSxHQUFHLFdBQVcsQ0FBQyxPQUFPLEVBQUUsYUFBYSxDQUFDLENBQUM7Z0JBQ3BELGNBQWMsQ0FBQyxXQUFXLENBQUMsRUFBRSxPQUFPLEVBQUUsSUFBSSxFQUFFLE1BQU0sRUFBRSxhQUFhLEVBQUUsQ0FBQyxDQUFDO2FBQ3hFO1FBQ0wsQ0FBQztRQUVEOztXQUVHO1FBQ0gsU0FBUyxNQUFNLENBQUMsT0FBYTtZQUN6QixJQUFJLGNBQWMsRUFBRTtnQkFDaEIsSUFBSSxhQUFhLEdBQVEsRUFBRSxDQUFDO2dCQUM1QixJQUFJLGFBQWEsR0FBUTtvQkFDckIsWUFBWSxFQUFFLElBQUk7b0JBQ2xCLEtBQUssRUFBRSxPQUFPO29CQUNkLElBQUksRUFBRSxxQkFBcUI7b0JBQzNCLE1BQU0sRUFBRSxDQUFDOzRCQUNMLElBQUksRUFBRSxNQUFNOzRCQUNaLEtBQUssRUFBRSxVQUFVOzRCQUNqQixRQUFRLEVBQUUsR0FBUyxFQUFFLEdBQUcsY0FBYyxDQUFDLFdBQVcsQ0FBQyxFQUFFLEtBQUssRUFBRSxJQUFJLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQzt5QkFDekUsQ0FBQztpQkFDTCxDQUFDO2dCQUVGLGFBQWEsR0FBRyxXQUFXLENBQUMsT0FBTyxFQUFFLGFBQWEsQ0FBQyxDQUFDO2dCQUNwRCxjQUFjLENBQUMsV0FBVyxDQUFDLEVBQUUsT0FBTyxFQUFFLElBQUksRUFBRSxNQUFNLEVBQUUsYUFBYSxFQUFFLENBQUMsQ0FBQzthQUN4RTtRQUNMLENBQUM7UUFFRCxTQUFTLFFBQVE7WUFDYixJQUFJLGNBQWM7Z0JBQUUsY0FBYyxDQUFDLFdBQVcsQ0FBQyxFQUFFLE9BQU8sRUFBRSxLQUFLLEVBQUUsQ0FBQyxDQUFDO1FBQ3ZFLENBQUM7UUFFRCxTQUFTLEtBQUs7WUFDVixJQUFJLGNBQWM7Z0JBQUUsY0FBYyxDQUFDLFdBQVcsQ0FBQyxFQUFFLEtBQUssRUFBRSxJQUFJLEVBQUUsQ0FBQyxDQUFDO1FBQ3BFLENBQUM7UUFFRCxTQUFTLFdBQVcsQ0FBQyxhQUFrQixFQUFFLGFBQWtCO1lBQ3ZELElBQUksYUFBYSxHQUFRLEVBQUUsQ0FBQztZQUN0QixNQUFPLENBQUMsTUFBTSxDQUFDLGFBQWEsRUFBRSxhQUFhLENBQUMsQ0FBQztZQUVuRCxJQUFJLGFBQWEsQ0FBQyxNQUFNO2dCQUFFLGFBQWEsQ0FBQyxLQUFLLEdBQUcsYUFBYSxDQUFDLE1BQU0sQ0FBQztZQUNyRSxJQUFJLGFBQWEsQ0FBQyxPQUFPO2dCQUFFLGFBQWEsQ0FBQyxJQUFJLEdBQUcsYUFBYSxDQUFDLE9BQU8sQ0FBQztZQUN0RSxJQUFJLGFBQWEsQ0FBQyxhQUFhLEVBQUU7Z0JBQzdCLElBQUksYUFBYSxDQUFDLGFBQWEsQ0FBQyxJQUFJO29CQUFFLGFBQWEsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxHQUFHLGFBQWEsQ0FBQyxhQUFhLENBQUMsSUFBSSxDQUFDO2dCQUN0RyxJQUFJLGFBQWEsQ0FBQyxhQUFhLENBQUMsUUFBUTtvQkFBRSxhQUFhLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsR0FBRyxhQUFhLENBQUMsYUFBYSxDQUFDLFFBQVEsQ0FBQzthQUNySDtZQUVELE9BQU8sYUFBYSxDQUFDO1FBQ3pCLENBQUM7UUFFRCxPQUFPO1lBQ0gsWUFBWSxFQUFFLFlBQVk7WUFDMUIsTUFBTSxFQUFFLE1BQU07WUFDZCxRQUFRLEVBQUUsUUFBUTtZQUNsQixLQUFLLEVBQUUsS0FBSztTQUNmLENBQUM7SUFDTixDQUFDO0lBSUQ7O09BRUc7SUFFSCw2QkFBNkI7SUFDN0IsNkRBQTZEO0lBQzdELHdDQUF3QztJQUN4QyxzREFBc0Q7SUFDdEQsb0hBQW9IO0lBQ3BILHNCQUFzQjtJQUN0QiwyQ0FBMkM7SUFDM0MsdURBQXVEO0lBQ3ZELHVDQUF1QztJQUN2QyxpQ0FBaUM7SUFDakMsNENBQTRDO0lBQzVDLDJCQUEyQjtJQUMzQiw2RUFBNkU7SUFDN0UsdURBQXVEO0lBQ3ZELGNBQWM7SUFDZCxJQUFJO0lBRU0sYUFBYTtRQUNuQixPQUFPLElBQUksQ0FBQyxXQUFXLENBQUM7SUFDNUIsQ0FBQztJQUVTLFdBQVcsQ0FBQyxLQUFhO1FBQy9CLElBQUksQ0FBQyxZQUFZLEdBQUcsS0FBSyxDQUFDO0lBQzlCLENBQUM7SUFFUyxTQUFTO1FBQ2YsT0FBTyxJQUFJLENBQUMsV0FBVyxDQUFDO0lBQzVCLENBQUM7SUFFUyxlQUFlO1FBQ3JCLE9BQU8sQ0FBQyxHQUFHLENBQUMsdUJBQXVCLEVBQUUsSUFBSSxDQUFDLFlBQVksQ0FBQyxDQUFDO1FBQ3hELE9BQU8sSUFBSSxDQUFDLFlBQVksQ0FBQztJQUM3QixDQUFDO0lBRVMsVUFBVSxDQUFDLFVBQWtCO1FBQ25DLE9BQU8sSUFBSSxDQUFDLGFBQWEsQ0FBQyxVQUFVLENBQUMsVUFBVSxDQUFDLENBQUM7SUFDckQsQ0FBQztJQUVTLFFBQVEsQ0FBQyxZQUFvQjtRQUNuQyxPQUFPLElBQUksQ0FBQyxhQUFhLENBQUMsUUFBUSxDQUFDLFlBQVksQ0FBQyxDQUFDO0lBQ3JELENBQUM7SUFFUyxTQUFTLENBQUMsS0FBYTtRQUM3QixPQUFPLElBQUksQ0FBQyxhQUFhLENBQUMsU0FBUyxDQUFDLEtBQUssRUFBRSxHQUFHLENBQUMsQ0FBQztJQUNwRCxDQUFDO0lBR1MsSUFBSSxDQUFDLEtBQWE7UUFDeEIsT0FBTyxJQUFJLENBQUMsYUFBYSxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQztJQUMxQyxDQUFDO0NBQ0oiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBTdWJzY3JpcHRpb24gfSBmcm9tICdyeGpzJztcclxuaW1wb3J0IHsgUm91dGVyLCBOYXZpZ2F0aW9uRW5kLCBBY3RpdmF0ZWRSb3V0ZSwgUGFyYW1zIH0gZnJvbSAnQGFuZ3VsYXIvcm91dGVyJztcclxuaW1wb3J0IHsgS2RBbGVydEV2ZW50IH0gZnJvbSAnLi4vLi4va2QtYW5ndWxhci1hbGVydC9pbmRleCc7XHJcbmltcG9ydCB7IEtkQ29udmVydGlvblN2YywgS2REYXRhU3ZjIH0gZnJvbSAnLi4vaW5kZXgnO1xyXG5pbXBvcnQgeyBJUGFnZWhlYWRlckNvbmZpZyB9IGZyb20gJy4uLy4uL2luZGV4JztcclxuXHJcbmltcG9ydCB7IEtkUGFnZUJhc2VFdmVudCB9IGZyb20gJy4va2QtcGFnZS1iYXNlLmV2ZW50JztcclxuXHJcbmV4cG9ydCBpbnRlcmZhY2UgSVBhZ2VCYXNlT3B0aW9ucyB7XHJcbiAgICByb3V0ZXI6IFJvdXRlcjtcclxuICAgIGFjdGl2YXRlZFJvdXRlOiBBY3RpdmF0ZWRSb3V0ZTtcclxuICAgIHBhZ2VFdmVudD86IEtkUGFnZUJhc2VFdmVudCB8IGFueTtcclxuICAgIHBhZ2VCYXNlRXZlbnQ/OiBLZFBhZ2VCYXNlRXZlbnQ7XHJcbiAgICBhbGVydEV2ZW50PzogS2RBbGVydEV2ZW50O1xyXG4gICAgLy8gbW9kYWxFdmVudD86IEtkTW9kYWxFdmVudDtcclxufVxyXG5cclxuZXhwb3J0IGNsYXNzIEtkUGFnZUJhc2Uge1xyXG4gICAgcHJpdmF0ZSBfdGV4dE9taXR0ZWQ6IHN0cmluZyA9ICcnO1xyXG4gICAgcHJpdmF0ZSBfaGVhZGVyOiBhbnkgPSB7XHJcbiAgICAgICAgYnJhbmRMb2dvOiB7fSxcclxuICAgICAgICB1c2VySW5mbzoge1xyXG4gICAgICAgICAgICBuYW1lOiAnJyxcclxuICAgICAgICAgICAgaW1nVHlwZTogJ2ljb24nLFxyXG4gICAgICAgICAgICBpbWdTcmM6ICcnLFxyXG4gICAgICAgICAgICBwYXRoOiAnJ1xyXG4gICAgICAgIH0sXHJcbiAgICAgICAgYnRuR3JvdXA6IFtdXHJcbiAgICB9O1xyXG5cclxuICAgIHByaXZhdGUgX3BhZ2VoZWFkZXI6IElQYWdlaGVhZGVyQ29uZmlnID0ge1xyXG4gICAgICAgIHBhZ2VoZWFkZXJUZXh0OiAnJyxcclxuICAgICAgICBsZWZ0QnRuOiBbXSxcclxuICAgICAgICAvLyBsZWZ0QnRuOiBbe1xyXG4gICAgICAgIC8vICAgICB0eXBlOiAnYWRkJ1xyXG4gICAgICAgIC8vIH1dLFxyXG4gICAgICAgIG1vcmVCdG46IGZhbHNlLFxyXG4gICAgICAgIG1vcmVBY3Rpb246IFtdLFxyXG4gICAgICAgIHNlYXJjaEJ0bjogZmFsc2UsXHJcbiAgICAgICAgc2VhcmNoRXZlbnQ6IFsnY2hhbmdlJywgJ2tleXVwJ11cclxuICAgIH07XHJcblxyXG4gICAgcHJpdmF0ZSBfYnJlYWRjcnVtYkxpc3Q6IGFueSA9IHtcclxuICAgICAgICBob21lOiB7IGljb246ICdmYSBmYS1ob21lJywgdXJsOiAnJywgcGF0aDogJy9BcHAvSW5zdGl0dXRpb25DbGFzc2VzL2xpc3QnIH0sXHJcbiAgICAgICAgbGlzdDogW11cclxuICAgIH07XHJcbiAgICBwcml2YXRlIF9wYWdlUGFyYW1zOiBhbnkgPSB7fTtcclxuICAgIHByaXZhdGUgX3ByZXZQYWdlVVJMOiBzdHJpbmcgPSAnJztcclxuICAgIHB1YmxpYyBjb252ZXJ0aW9uU3ZjOiBLZENvbnZlcnRpb25TdmM7XHJcbiAgICBwdWJsaWMgZGF0YVN2YzogS2REYXRhU3ZjO1xyXG4gICAgLy8gcHJpdmF0ZSBfYWxlcnRFdmVudDogS2RBbGVydEV2ZW50O1xyXG5cclxuICAgIHByaXZhdGUgX3JvdXRlclN1YjogU3Vic2NyaXB0aW9uO1xyXG4gICAgcHJpdmF0ZSBfYWN0aXZhdGVkUm91dGVTdWI6IFN1YnNjcmlwdGlvbjtcclxuICAgIHByaXZhdGUgX2N1cnJlbnRVUkw6IHN0cmluZyA9ICcnO1xyXG4gICAgY29uc3RydWN0b3IoXHJcbiAgICAgICAgcHVibGljIG9wdGlvbnM6IElQYWdlQmFzZU9wdGlvbnNcclxuICAgICkge1xyXG4gICAgICAgIHRoaXMuY29udmVydGlvblN2YyA9IG5ldyBLZENvbnZlcnRpb25TdmMoKTtcclxuICAgICAgICB0aGlzLmRhdGFTdmMgPSBuZXcgS2REYXRhU3ZjKCk7XHJcblxyXG4gICAgICAgIC8vIHRoaXMuX3ByZXZQYWdlSW5mbyA9IHRoaXMuaW5pdFByZXZIaXN0b3J5KCk7XHJcbiAgICAgICAgLy8gdGhpcy5vcHRpb25zLnJvdXRlci5ldmVudHNcclxuICAgICAgICAvLyAgICAgLmZpbHRlcihlID0+IGUgaW5zdGFuY2VvZiBSb3V0ZXNSZWNvZ25pemVkKVxyXG4gICAgICAgIC8vICAgICAvLyAuZmlsdGVyKGUgPT4gKGUuY29uc3RydWN0b3IubmFtZSA9PT0gJ1JvdXRlc1JlY29nbml6ZWQnKSB8fCAoIGUuY29uc3RydWN0b3IubmFtZSA9PT0gJ05hdmlnYXRpb25FbmQnKSlcclxuICAgICAgICAvLyAgICAgLnBhaXJ3aXNlKClcclxuICAgICAgICAvLyAgICAgLnN1YnNjcmliZSgoZTogYW55W10pOiB2b2lkID0+IHtcclxuICAgICAgICAvLyAgICAgICAgIGNvbnNvbGUubG9nKCcxIG9uIGluaXQgPiB1cmwgaW5mbyAnLCBlKTtcclxuICAgICAgICAvLyAgICAgICAgIGNvbnNvbGUubG9nKG5ldyBEYXRlKCkpO1xyXG4gICAgICAgIC8vICAgICAgICAgY29uc29sZS5sb2coZVswXSk7XHJcbiAgICAgICAgLy8gICAgICAgICBjb25zb2xlLmxvZyhlW2UubGVuZ3RoIC0gMV0pO1xyXG4gICAgICAgIC8vICAgICAgICAgdGhpcy5fcHJldlBhZ2VJbmZvID0gZVswXS51cmxBZnRlclJlZGlyZWN0cztcclxuICAgICAgICAvLyAgICAgICAgIC8vIGNvbnNvbGUubG9nKCd0aGlzLl9wcmV2UGFnZUluZm8gPSA+ICcsIHRoaXMuX3ByZXZQYWdlSW5mbyk7XHJcbiAgICAgICAgLy8gICAgICAgICAvLyB0aGlzLl9yb3V0ZXJIaXN0b3J5U3ViLnVuc3Vic2NyaWJlKCk7XHJcbiAgICAgICAgLy8gICAgIH0pO1xyXG5cclxuICAgICAgICAvLyBjb25zb2xlLmxvZygnY29uc3RydWN0b3IgPj4gJyx0aGlzLl9wcmV2UGFnZUluZm8pO1xyXG4gICAgICAgIHRoaXMuX3JvdXRlclN1YiA9IHRoaXMub3B0aW9ucy5yb3V0ZXIuZXZlbnRzXHJcbiAgICAgICAgICAgIC5zdWJzY3JpYmUoZXZlbnQgPT4ge1xyXG4gICAgICAgICAgICAgICAgLy8gaWYgKGV2ZW50IGluc3RhbmNlb2YgUm91dGVzUmVjb2duaXplZCkge1xyXG4gICAgICAgICAgICAgICAgLy8gY29uc29sZS5sb2coJ1JvdXRlc1JlY29nbml6ZWQgPiBldmVudCAtICcsIE9iamVjdC5hc3NpZ24oe30sIGV2ZW50KSk7XHJcbiAgICAgICAgICAgICAgICAvLyB9XHJcbiAgICAgICAgICAgICAgICBpZiAoZXZlbnQgaW5zdGFuY2VvZiBOYXZpZ2F0aW9uRW5kKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgLy8gY29uc29sZS5sb2coJz4+JywgZXZlbnQpO1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuX3ByZXZQYWdlVVJMID0gSlNPTi5zdHJpbmdpZnkodGhpcy5fY3VycmVudFVSTCk7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5fY3VycmVudFVSTCA9IGV2ZW50LnVybEFmdGVyUmVkaXJlY3RzO1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuX2JyZWFkY3J1bWJMaXN0Lmxpc3QgPSB0aGlzLmNvbnZlcnRpb25TdmMudXJsVG9BcnJheShldmVudC51cmxBZnRlclJlZGlyZWN0cywgdGhpcy5fdGV4dE9taXR0ZWQpO1xyXG4gICAgICAgICAgICAgICAgICAgIC8vIGNvbnNvbGUubG9nKCd0aGlzLl9icmVhZGNydW1iTGlzdC5saXN0Jyx0aGlzLl9icmVhZGNydW1iTGlzdC5saXN0KTtcclxuICAgICAgICAgICAgICAgICAgICBpZiAodHlwZW9mIHRoaXMub3B0aW9ucy5wYWdlRXZlbnQgIT09ICd1bmRlZmluZWQnKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMub3B0aW9ucy5wYWdlRXZlbnQuYXBwUmVhZHkoKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5vcHRpb25zLnBhZ2VFdmVudC5vbkFwcFJlYWR5Q29tcGxldGUoKTtcclxuICAgICAgICAgICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIGlmICh0eXBlb2YgdGhpcy5vcHRpb25zLnBhZ2VCYXNlRXZlbnQgIT09ICd1bmRlZmluZWQnKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbnNvbGUuZXJyb3IoJ3BsZWFzZSBjaGFuZ2UgdG8gUGFnZUV2ZW50IGluc3RlYWQgb2YgUGFnZUJhc2VFdmVudCcpO1xyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfSk7XHJcblxyXG4gICAgICAgIHRoaXMuX2FjdGl2YXRlZFJvdXRlU3ViID0gdGhpcy5vcHRpb25zLmFjdGl2YXRlZFJvdXRlLnBhcmFtcy5zdWJzY3JpYmUoKF9wYXJhbXM6IFBhcmFtcyk6IHZvaWQgPT4ge1xyXG4gICAgICAgICAgICB0aGlzLl9wYWdlUGFyYW1zID0gX3BhcmFtcztcclxuICAgICAgICB9KTtcclxuICAgIH1cclxuICAgIC8vIHByb3RlY3RlZCBlbmFibGVMb2FkVjIoX2Jvb2w6IGJvb2xlYW4pIHtcclxuICAgIC8vICAgICAvLyB0aGlzLm9wdGlvbnMucGFnZUV2ZW50LmxvYWRWMihfYm9vbCk7XHJcbiAgICAvLyB9XHJcblxyXG4gICAgLyoqXHJcbiAgICAgKiBbZGVzdHJveVBhZ2VCYXNlU3ViIC0gTWFudWFsbHkgZGlzY2FyZCB0aGUgYWxsIHRoZSBzdWJzY3JpcHRpb25zXVxyXG4gICAgICovXHJcbiAgICBwcm90ZWN0ZWQgZGVzdHJveVBhZ2VCYXNlU3ViKCk6IHZvaWQge1xyXG4gICAgICAgIGlmICh0eXBlb2YgdGhpcy5fcm91dGVyU3ViICE9PSAndW5kZWZpbmVkJykgdGhpcy5fcm91dGVyU3ViLnVuc3Vic2NyaWJlKCk7XHJcbiAgICAgICAgaWYgKHR5cGVvZiB0aGlzLl9hY3RpdmF0ZWRSb3V0ZVN1YiAhPT0gJ3VuZGVmaW5lZCcpIHRoaXMuX2FjdGl2YXRlZFJvdXRlU3ViLnVuc3Vic2NyaWJlKCk7XHJcbiAgICB9XHJcblxyXG4gICAgLyoqXHJcbiAgICAgKiBBcHBsaWNhdGlvbiBIZWFkZXIgKFByb2R1Y3QgSGVhZGVyKVxyXG4gICAgICovXHJcblxyXG4gICAgcHJvdGVjdGVkIGdldEhlYWRlckNvbmZpZygpOiBhbnkge1xyXG4gICAgICAgIHJldHVybiB0aGlzLl9oZWFkZXIudXNlckluZm87XHJcbiAgICB9XHJcblxyXG4gICAgcHJvdGVjdGVkIHNldEhlYWRlckNvbmZpZyhfY29uZjogYW55KSB7XHJcbiAgICAgICAgdGhpcy5faGVhZGVyLnVzZXJJbmZvID0gX2NvbmY7XHJcbiAgICB9XHJcblxyXG4gICAgcHJvdGVjdGVkIHVwZGF0ZUhlYWRlcigpIHtcclxuICAgICAgICB0aGlzLm9wdGlvbnMucGFnZUV2ZW50LnVwZGF0ZUhlYWRlcih0aGlzLl9oZWFkZXIpO1xyXG4gICAgfVxyXG5cclxuICAgIC8qKlxyXG4gICAgICogTGVmdCBOYXZpZ2F0aW9uXHJcbiAgICAgKi9cclxuXHJcbiAgICBwcm90ZWN0ZWQgc2V0TGVmdE1lbnVMaXN0KF9sZWZ0TWVudU9iajogYW55KSB7XHJcbiAgICAgICAgdGhpcy5vcHRpb25zLnBhZ2VFdmVudC51cGRhdGVMZWZ0bWVudShfbGVmdE1lbnVPYmopO1xyXG4gICAgfVxyXG5cclxuICAgIC8qKlxyXG4gICAgICogUGFnZSBIZWFkZXJcclxuICAgICAqL1xyXG5cclxuICAgIHByb3RlY3RlZCBnZXRQYWdlVGl0bGUoKTogc3RyaW5nIHtcclxuICAgICAgICByZXR1cm4gdGhpcy5fcGFnZWhlYWRlci5wYWdlaGVhZGVyVGV4dDtcclxuICAgIH1cclxuXHJcbiAgICBwcm90ZWN0ZWQgc2V0UGFnZVRpdGxlKF90aXRsZTogc3RyaW5nLCBfaHVtYW5pemU6IGJvb2xlYW4gPSB0cnVlKSB7XHJcbiAgICAgICAgbGV0IHRlbXBTdHI6IHN0cmluZyA9IF90aXRsZS5yZXBsYWNlKHRoaXMuX3RleHRPbWl0dGVkLCAnJyk7XHJcbiAgICAgICAgaWYgKF9odW1hbml6ZSkge1xyXG4gICAgICAgICAgICB0ZW1wU3RyID0gdGhpcy5odW1hbml6ZSh0aGlzLnVuZGVyc2NvcmUodGVtcFN0cikpO1xyXG4gICAgICAgIH1cclxuICAgICAgICAvLyBjb25zb2xlLmxvZygnc2V0UGFnZVRpdGxlPScsdGVtcFN0cik7XHJcbiAgICAgICAgdGhpcy5fcGFnZWhlYWRlci5wYWdlaGVhZGVyVGV4dCA9IHRlbXBTdHI7XHJcbiAgICB9XHJcblxyXG4gICAgcHJvdGVjdGVkIGdldFRvb2xiYXJNYWluQnRucygpOiBBcnJheTxhbnk+IHtcclxuICAgICAgICByZXR1cm4gSlNPTi5wYXJzZShKU09OLnN0cmluZ2lmeSh0aGlzLl9wYWdlaGVhZGVyLmxlZnRCdG4pKTtcclxuICAgIH1cclxuXHJcbiAgICBwcm90ZWN0ZWQgc2V0VG9vbGJhck1haW5CdG5zKF9idXR0b25zOiBBcnJheTxhbnk+KSB7XHJcbiAgICAgICAgdGhpcy5fcGFnZWhlYWRlci5sZWZ0QnRuID0gX2J1dHRvbnM7XHJcbiAgICB9XHJcblxyXG4gICAgcHJvdGVjdGVkIGdldFRvb2xiYXJNb3JlQWN0aW9uQnRucygpOiBBcnJheTxhbnk+IHtcclxuICAgICAgICByZXR1cm4gdGhpcy5fcGFnZWhlYWRlci5tb3JlQWN0aW9uO1xyXG4gICAgfVxyXG5cclxuICAgIHByb3RlY3RlZCBlbmFibGVNb3JlQWN0aW9uQnRucyhfZW5hYmxlOiBib29sZWFuLCBfYnV0dG9ucz86IEFycmF5PGFueT4pIHtcclxuICAgICAgICB0aGlzLl9wYWdlaGVhZGVyLm1vcmVCdG4gPSBfZW5hYmxlO1xyXG4gICAgICAgIGlmIChfYnV0dG9ucykge1xyXG4gICAgICAgICAgICB0aGlzLl9wYWdlaGVhZGVyLm1vcmVBY3Rpb24gPSBfYnV0dG9ucztcclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgcHJvdGVjdGVkIGVuYWJsZVRvb2xiYXJTZWFyY2goX2VuYWJsZTogYm9vbGVhbiwgX2NhbGxiYWNrPzogKF90ZXh0OiBzdHJpbmcpID0+IHZvaWQpIHtcclxuICAgICAgICB0aGlzLl9wYWdlaGVhZGVyLnNlYXJjaEJ0biA9IF9lbmFibGU7XHJcbiAgICAgICAgaWYgKF9lbmFibGUgJiYgX2NhbGxiYWNrKSB7XHJcbiAgICAgICAgICAgIHRoaXMuX3BhZ2VoZWFkZXIuc2VhcmNoQ2FsbGJhY2sgPSBfY2FsbGJhY2s7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIHByb3RlY3RlZCB1cGRhdGVTZWFyY2hUZXh0KF9zZWFyY2hUZXh0OiBzdHJpbmcpIHtcclxuICAgICAgICB0aGlzLl9wYWdlaGVhZGVyLnNlYXJjaFRleHQgPSBfc2VhcmNoVGV4dDtcclxuICAgIH1cclxuXHJcbiAgICBwcm90ZWN0ZWQgdXBkYXRlUGFnZUhlYWRlcigpIHtcclxuICAgICAgICBjb25zb2xlLmxvZygnYnJvYWRjYXN0IHVwZGF0ZVBhZ2VIZWFkZXInLCB0aGlzLl9wYWdlaGVhZGVyKTtcclxuICAgICAgICB0aGlzLm9wdGlvbnMucGFnZUV2ZW50LnVwZGF0ZVBhZ2VIZWFkZXIodGhpcy5fcGFnZWhlYWRlcik7XHJcbiAgICB9XHJcblxyXG4gICAgLyoqXHJcbiAgICAgKiBCcmVhZGNydW1ic1xyXG4gICAgICovXHJcblxyXG4gICAgcHJvdGVjdGVkIHNldEJyZWFkY3J1bWJzTGlzdChfbGlzdDogQXJyYXk8YW55Pik6IHZvaWQge1xyXG4gICAgICAgIHRoaXMuX2JyZWFkY3J1bWJMaXN0Lmxpc3QgPSBfbGlzdDtcclxuICAgICAgICB0aGlzLnVwZGF0ZUJyZWFkY3J1bWIoKTtcclxuICAgIH1cclxuXHJcbiAgICBwcm90ZWN0ZWQgZ2V0QnJlYWRjcnVtYnNMaXN0KCk6IEFycmF5PGFueT4ge1xyXG4gICAgICAgIHJldHVybiB0aGlzLl9icmVhZGNydW1iTGlzdC5saXN0O1xyXG4gICAgfVxyXG5cclxuICAgIHByb3RlY3RlZCB1cGRhdGVCcmVhZGNydW1iKCk6IHZvaWQge1xyXG4gICAgICAgIHRoaXMub3B0aW9ucy5wYWdlRXZlbnQudXBkYXRlQnJlYWRjcnVtYihKU09OLnBhcnNlKEpTT04uc3RyaW5naWZ5KHRoaXMuX2JyZWFkY3J1bWJMaXN0KSkpO1xyXG4gICAgfVxyXG5cclxuICAgIC8qKlxyXG4gICAgICogQWxlcnRzXHJcbiAgICAgKi9cclxuXHJcbiAgICBwcm90ZWN0ZWQgc2V0QWxlcnQoX2NvbmZpZzogYW55LCBfdHlwZTogc3RyaW5nKTogdm9pZCB7XHJcbiAgICAgICAgaWYgKHRoaXMub3B0aW9ucy5hbGVydEV2ZW50KSB7XHJcbiAgICAgICAgICAgIHRoaXMub3B0aW9ucy5hbGVydEV2ZW50W190eXBlXShfY29uZmlnKTtcclxuICAgICAgICB9XHJcbiAgICAgICAgZWxzZSB7XHJcbiAgICAgICAgICAgIGNvbnNvbGUud2FybignTWlzc2luZyBldmVudCAtIEtkQWxlcnRFdmVudCcpO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICAvKipcclxuICAgICAqIFtzZXRNb2RhbCBDcmVhdGluZyBtb2RhbCB2aWV3XVxyXG4gICAgICogIF9jb25maWdDb25maW1hdGlvbiB7XHJcbiAgICAgKiAgICAgICAgICAgICAgaGVhZGVyOiAnJyxcclxuICAgICAqICAgICAgICAgICAgICBtZXNzYWdlOiAnJyxcclxuICAgICAqICAgICAgICAgICAgICBidXR0b25Db25maXJtOiB7XHJcbiAgICAgKiAgICAgICAgICAgICAgICAgIHRleHQ6ICd0ZXN0IHRleHQnLFxyXG4gICAgICogICAgICAgICAgICAgICAgICBjYWxsYmFjazogKCkgPT57XHJcbiAgICAgKlxyXG4gICAgICogICAgICAgICAgICAgICAgICB9XHJcbiAgICAgKiAgICAgICAgICAgICAgfVxyXG4gICAgICogICAgICAgICAgfVxyXG4gICAgICovXHJcbiAgICBwcm90ZWN0ZWQgc2V0TW9kYWwoKTogeyBjb25maXJtYXRpb246IEZ1bmN0aW9uLCBub3RpZnk6IEZ1bmN0aW9uLCBkaXNhYmxlZDogRnVuY3Rpb24sIGNsb3NlOiBGdW5jdGlvbiB9IHtcclxuICAgICAgICBsZXQgX3BhZ2VCYXNlRXZlbnQ6IEtkUGFnZUJhc2VFdmVudDtcclxuICAgICAgICBpZiAodGhpcy5vcHRpb25zLnBhZ2VFdmVudCkge1xyXG4gICAgICAgICAgICBfcGFnZUJhc2VFdmVudCA9IHRoaXMub3B0aW9ucy5wYWdlRXZlbnQ7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICBjb25zb2xlLndhcm4oJ1BsZWFzZSBpbXBvcnQgXFwnUGFnZUJhc2VFdmVudFxcJyB0byB1c2UgbW9kYWwnKTtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIC8qKlxyXG4gICAgICAgICAqIFtjb25maXJtYXRpb24gYSBtb2RhbCBkaWFsb2cgd2l0aCAyIGJ1dHRvbnM6ICdDb25maXJtJyBhbmQgJ0NhbmNlbCddXHJcbiAgICAgICAgICovXHJcbiAgICAgICAgZnVuY3Rpb24gY29uZmlybWF0aW9uKF9jb25maWc/OiBhbnkpOiB2b2lkIHtcclxuICAgICAgICAgICAgaWYgKF9wYWdlQmFzZUV2ZW50KSB7XHJcbiAgICAgICAgICAgICAgICBsZXQgdXBkYXRlZENvbmZpZzogYW55ID0ge307XHJcbiAgICAgICAgICAgICAgICBsZXQgZGVmYXVsdENvbmZpZzogYW55ID0ge1xyXG4gICAgICAgICAgICAgICAgICAgIHN1c3BlbmRDbG9zZTogdHJ1ZSxcclxuICAgICAgICAgICAgICAgICAgICB0aXRsZTogJ0FsZXJ0JyxcclxuICAgICAgICAgICAgICAgICAgICBib2R5OiAnRHVtbXkgdGV4dCAtIGNvbmZpcm1hdGlvbicsXHJcbiAgICAgICAgICAgICAgICAgICAgYnV0dG9uOiBbe1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB0ZXh0OiAnQ29uZmlybScsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzOiAnYnRuLXRleHQnLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBjYWxsYmFjazogKCk6IHZvaWQgPT4geyB9XHJcbiAgICAgICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICAgICAgICB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHRleHQ6ICdDYW5jZWwnLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBjbGFzczogJ2J0bi1vdXRsaW5lJyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgY2FsbGJhY2s6ICgpOiB2b2lkID0+IHsgX3BhZ2VCYXNlRXZlbnQudXBkYXRlTW9kYWwoeyBjbG9zZTogdHJ1ZSB9KTsgfVxyXG4gICAgICAgICAgICAgICAgICAgIH1dXHJcbiAgICAgICAgICAgICAgICB9O1xyXG5cclxuICAgICAgICAgICAgICAgIHVwZGF0ZWRDb25maWcgPSBhcHBseUNvbmZpZyhfY29uZmlnLCBkZWZhdWx0Q29uZmlnKTtcclxuICAgICAgICAgICAgICAgIF9wYWdlQmFzZUV2ZW50LnVwZGF0ZU1vZGFsKHsgZW5hYmxlZDogdHJ1ZSwgY29uZmlnOiB1cGRhdGVkQ29uZmlnIH0pO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICAvKipcclxuICAgICAgICAgKiBbbm90aWZ5IGEgbW9kYWwgZGlhbG9nIHdpdGggMSBidXR0b246ICdEb25lJ11cclxuICAgICAgICAgKi9cclxuICAgICAgICBmdW5jdGlvbiBub3RpZnkoX2NvbmZpZz86IGFueSk6IHZvaWQge1xyXG4gICAgICAgICAgICBpZiAoX3BhZ2VCYXNlRXZlbnQpIHtcclxuICAgICAgICAgICAgICAgIGxldCB1cGRhdGVkQ29uZmlnOiBhbnkgPSB7fTtcclxuICAgICAgICAgICAgICAgIGxldCBkZWZhdWx0Q29uZmlnOiBhbnkgPSB7XHJcbiAgICAgICAgICAgICAgICAgICAgc3VzcGVuZENsb3NlOiB0cnVlLFxyXG4gICAgICAgICAgICAgICAgICAgIHRpdGxlOiAnQWxlcnQnLFxyXG4gICAgICAgICAgICAgICAgICAgIGJvZHk6ICdEdW1teSB0ZXh0IC0gbm90aWZ5JyxcclxuICAgICAgICAgICAgICAgICAgICBidXR0b246IFt7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHRleHQ6ICdEb25lJyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3M6ICdidG4tdGV4dCcsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNhbGxiYWNrOiAoKTogdm9pZCA9PiB7IF9wYWdlQmFzZUV2ZW50LnVwZGF0ZU1vZGFsKHsgY2xvc2U6IHRydWUgfSk7IH1cclxuICAgICAgICAgICAgICAgICAgICB9XVxyXG4gICAgICAgICAgICAgICAgfTtcclxuXHJcbiAgICAgICAgICAgICAgICB1cGRhdGVkQ29uZmlnID0gYXBwbHlDb25maWcoX2NvbmZpZywgZGVmYXVsdENvbmZpZyk7XHJcbiAgICAgICAgICAgICAgICBfcGFnZUJhc2VFdmVudC51cGRhdGVNb2RhbCh7IGVuYWJsZWQ6IHRydWUsIGNvbmZpZzogdXBkYXRlZENvbmZpZyB9KTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgZnVuY3Rpb24gZGlzYWJsZWQoKTogdm9pZCB7XHJcbiAgICAgICAgICAgIGlmIChfcGFnZUJhc2VFdmVudCkgX3BhZ2VCYXNlRXZlbnQudXBkYXRlTW9kYWwoeyBlbmFibGVkOiBmYWxzZSB9KTtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIGZ1bmN0aW9uIGNsb3NlKCk6IHZvaWQge1xyXG4gICAgICAgICAgICBpZiAoX3BhZ2VCYXNlRXZlbnQpIF9wYWdlQmFzZUV2ZW50LnVwZGF0ZU1vZGFsKHsgY2xvc2U6IHRydWUgfSk7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICBmdW5jdGlvbiBhcHBseUNvbmZpZyhfc291cmNlQ29uZmlnOiBhbnksIF90YXJnZXRDb25maWc6IGFueSk6IHt9IHtcclxuICAgICAgICAgICAgbGV0IHVwZGF0ZWRDb25maWc6IGFueSA9IHt9O1xyXG4gICAgICAgICAgICAoPGFueT5PYmplY3QpLmFzc2lnbih1cGRhdGVkQ29uZmlnLCBfdGFyZ2V0Q29uZmlnKTtcclxuXHJcbiAgICAgICAgICAgIGlmIChfc291cmNlQ29uZmlnLmhlYWRlcikgdXBkYXRlZENvbmZpZy50aXRsZSA9IF9zb3VyY2VDb25maWcuaGVhZGVyO1xyXG4gICAgICAgICAgICBpZiAoX3NvdXJjZUNvbmZpZy5tZXNzYWdlKSB1cGRhdGVkQ29uZmlnLmJvZHkgPSBfc291cmNlQ29uZmlnLm1lc3NhZ2U7XHJcbiAgICAgICAgICAgIGlmIChfc291cmNlQ29uZmlnLmJ1dHRvbkNvbmZpcm0pIHtcclxuICAgICAgICAgICAgICAgIGlmIChfc291cmNlQ29uZmlnLmJ1dHRvbkNvbmZpcm0udGV4dCkgdXBkYXRlZENvbmZpZy5idXR0b25bMF0udGV4dCA9IF9zb3VyY2VDb25maWcuYnV0dG9uQ29uZmlybS50ZXh0O1xyXG4gICAgICAgICAgICAgICAgaWYgKF9zb3VyY2VDb25maWcuYnV0dG9uQ29uZmlybS5jYWxsYmFjaykgdXBkYXRlZENvbmZpZy5idXR0b25bMF0uY2FsbGJhY2sgPSBfc291cmNlQ29uZmlnLmJ1dHRvbkNvbmZpcm0uY2FsbGJhY2s7XHJcbiAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgIHJldHVybiB1cGRhdGVkQ29uZmlnO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgcmV0dXJuIHtcclxuICAgICAgICAgICAgY29uZmlybWF0aW9uOiBjb25maXJtYXRpb24sXHJcbiAgICAgICAgICAgIG5vdGlmeTogbm90aWZ5LFxyXG4gICAgICAgICAgICBkaXNhYmxlZDogZGlzYWJsZWQsXHJcbiAgICAgICAgICAgIGNsb3NlOiBjbG9zZVxyXG4gICAgICAgIH07XHJcbiAgICB9XHJcblxyXG5cclxuXHJcbiAgICAvKipcclxuICAgICAqIFV0aWxzIE1ldGhvZHNcclxuICAgICAqL1xyXG5cclxuICAgIC8vIHByaXZhdGUgaW5pdFByZXZIaXN0b3J5KCl7XHJcbiAgICAvLyAgICAgLy8gdGhpcy5fcm91dGVySGlzdG9yeVN1YiA9IHRoaXMub3B0aW9ucy5yb3V0ZXIuZXZlbnRzXHJcbiAgICAvLyAgICAgcmV0dXJuIHRoaXMub3B0aW9ucy5yb3V0ZXIuZXZlbnRzXHJcbiAgICAvLyAgICAgICAgIC5maWx0ZXIoZSA9PiBlIGluc3RhbmNlb2YgUm91dGVzUmVjb2duaXplZClcclxuICAgIC8vICAgICAgICAgLy8gLmZpbHRlcihlID0+IChlLmNvbnN0cnVjdG9yLm5hbWUgPT09ICdSb3V0ZXNSZWNvZ25pemVkJykgfHwgKCBlLmNvbnN0cnVjdG9yLm5hbWUgPT09ICdOYXZpZ2F0aW9uRW5kJykpXHJcbiAgICAvLyAgICAgICAgIC5wYWlyd2lzZSgpXHJcbiAgICAvLyAgICAgICAgIC5zdWJzY3JpYmUoKGU6IGFueVtdKTogdm9pZCA9PiB7XHJcbiAgICAvLyAgICAgICAgICAgICBjb25zb2xlLmxvZygnMSBvbiBpbml0ID4gdXJsIGluZm8gJywgZSk7XHJcbiAgICAvLyAgICAgICAgICAgICBjb25zb2xlLmxvZyhuZXcgRGF0ZSgpKTtcclxuICAgIC8vICAgICAgICAgICAgIGNvbnNvbGUubG9nKGVbMF0pO1xyXG4gICAgLy8gICAgICAgICAgICAgY29uc29sZS5sb2coZVtlLmxlbmd0aCAtIDFdKTtcclxuICAgIC8vICAgICAgICAgICAgIHJldHVybiBlWzBdO1xyXG4gICAgLy8gICAgICAgICAgICAgLy8gY29uc29sZS5sb2coJ3RoaXMuX3ByZXZQYWdlSW5mbyA9ID4gJywgdGhpcy5fcHJldlBhZ2VJbmZvKTtcclxuICAgIC8vICAgICAgICAgICAgIC8vIHRoaXMuX3JvdXRlckhpc3RvcnlTdWIudW5zdWJzY3JpYmUoKTtcclxuICAgIC8vICAgICAgICAgfSk7XHJcbiAgICAvLyB9XHJcblxyXG4gICAgcHJvdGVjdGVkIGdldEN1cnJlbnRVUkwoKTogc3RyaW5nIHtcclxuICAgICAgICByZXR1cm4gdGhpcy5fY3VycmVudFVSTDtcclxuICAgIH1cclxuXHJcbiAgICBwcm90ZWN0ZWQgc2V0VGV4dE9taXQoX3RleHQ6IHN0cmluZykge1xyXG4gICAgICAgIHRoaXMuX3RleHRPbWl0dGVkID0gX3RleHQ7XHJcbiAgICB9XHJcblxyXG4gICAgcHJvdGVjdGVkIGdldFBhcmFtcygpOiBhbnkge1xyXG4gICAgICAgIHJldHVybiB0aGlzLl9wYWdlUGFyYW1zO1xyXG4gICAgfVxyXG5cclxuICAgIHByb3RlY3RlZCBnZXRQcmV2UGFnZUluZm8oKTogc3RyaW5nIHtcclxuICAgICAgICBjb25zb2xlLmxvZygnZ2V0UHJldlBhZ2VJbmZvIC4gPj4gJywgdGhpcy5fcHJldlBhZ2VVUkwpO1xyXG4gICAgICAgIHJldHVybiB0aGlzLl9wcmV2UGFnZVVSTDtcclxuICAgIH1cclxuXHJcbiAgICBwcm90ZWN0ZWQgdW5kZXJzY29yZShfY2FtZWxDYXNlOiBzdHJpbmcpOiBzdHJpbmcge1xyXG4gICAgICAgIHJldHVybiB0aGlzLmNvbnZlcnRpb25TdmMudW5kZXJzY29yZShfY2FtZWxDYXNlKTtcclxuICAgIH1cclxuXHJcbiAgICBwcm90ZWN0ZWQgaHVtYW5pemUoX3VuZGVyc2NvcmVkOiBzdHJpbmcpOiBzdHJpbmcge1xyXG4gICAgICAgIHJldHVybiB0aGlzLmNvbnZlcnRpb25TdmMuaHVtYW5pemUoX3VuZGVyc2NvcmVkKTtcclxuICAgIH1cclxuXHJcbiAgICBwcm90ZWN0ZWQgY2FtZWxDYXNlKF90ZXh0OiBzdHJpbmcpOiBzdHJpbmcge1xyXG4gICAgICAgIHJldHVybiB0aGlzLmNvbnZlcnRpb25TdmMuY2FtZWxDYXNlKF90ZXh0LCAnICcpO1xyXG4gICAgfVxyXG5cclxuXHJcbiAgICBwcm90ZWN0ZWQgc2x1Zyhfd29yZDogc3RyaW5nKSB7XHJcbiAgICAgICAgcmV0dXJuIHRoaXMuY29udmVydGlvblN2Yy5zbHVnKF93b3JkKTtcclxuICAgIH1cclxufVxyXG4iXX0=