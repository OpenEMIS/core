/*******************************************************************************
    File: config.variable.ts
    Version: 1.0
    Purpose: General variables usage for kd-component libraries

    Last change:
        -

 ******************************************************************************/
// Standard delay timing for all components
export const DELAY_TIME = 300;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiY29uZmlnLnZhcmlhYmxlLmpzIiwic291cmNlUm9vdCI6IkM6L3hhbXBwL2h0ZG9jcy9TdHlsZWd1aWRlL2lvc3RnLW9wZW5lbWlzLXN0eWxlZ3VpZGUvcHJvamVjdHMvb3BlbmVtaXMtc3R5bGVndWlkZS1saWIvc3JjLyIsInNvdXJjZXMiOlsia2QtY29tcG9uZW50cy9rZC1jb21tb24vY29uZmlncy9jb25maWcudmFyaWFibGUudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7Ozs7Ozs7O2dGQVFnRjtBQUVoRiwyQ0FBMkM7QUFDM0MsTUFBTSxDQUFDLE1BQU0sVUFBVSxHQUFXLEdBQUcsQ0FBQyIsInNvdXJjZXNDb250ZW50IjpbIi8qKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqXHJcblx0RmlsZTogY29uZmlnLnZhcmlhYmxlLnRzXHJcblx0VmVyc2lvbjogMS4wXHJcblx0UHVycG9zZTogR2VuZXJhbCB2YXJpYWJsZXMgdXNhZ2UgZm9yIGtkLWNvbXBvbmVudCBsaWJyYXJpZXNcclxuXHJcblx0TGFzdCBjaGFuZ2U6XHJcblx0XHQtXHJcblxyXG4gKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqL1xyXG5cclxuLy8gU3RhbmRhcmQgZGVsYXkgdGltaW5nIGZvciBhbGwgY29tcG9uZW50c1xyXG5leHBvcnQgY29uc3QgREVMQVlfVElNRTogbnVtYmVyID0gMzAwO1xyXG4iXX0=