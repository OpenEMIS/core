import { Component, ViewEncapsulation, Input, ElementRef, ViewChild, HostBinding, ChangeDetectorRef } from '@angular/core';
// import { Subscription } from 'rxjs/Subscription';
import { timer } from 'rxjs';
// import { debounceTime } from 'rxjs/operators';
import * as L from 'leaflet';
import 'leaflet.markercluster';
import 'leaflet.awesome-markers/dist/leaflet.awesome-markers';
import { KdSplitterEvent } from '../kd-angular-splitter/index';
import { KdDomElemSvc } from '../kd-common/index';
import { KdMapSvc } from './kd-angular-map-svc';
import { KdDataSvc } from '../kd-common/index';
export class KdMap {
    constructor(_elementRef, _kdSplitterEvent, _kdDomElemSvc, _kdMapSvc, _cd, _dataSvc) {
        this._elementRef = _elementRef;
        this._kdDomElemSvc = _kdDomElemSvc;
        this._kdMapSvc = _kdMapSvc;
        this._cd = _cd;
        this._dataSvc = _dataSvc;
        // private static mapPinImage: string = 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABkAAAApCAYAAADAk4LOAAAFgUlEQVR4Aa1XA5BjWRTN2oW17d3YaZtr2962HUzbDNpjszW24mRt28p47v7zq/bXZtrp/lWnXr337j3nPCe85NcypgSFdugCpW5YoDAMRaIMqRi6aKq5E3YqDQO3qAwjVWrD8Ncq/RBpykd8oZUb/kaJutow8r1aP9II0WmLKLIsJyv1w/kqw9Ch2MYdB++12Onxee/QMwvf4/Dk/Lfp/i4nxTXtOoQ4pW5Aj7wpici1A9erdAN2OH64x8OSP9j3Ft3b7aWkTg/Fm91siTra0f9on5sQr9INejH6CUUUpavjFNq1B+Oadhxmnfa8RfEmN8VNAsQhPqF55xHkMzz3jSmChWU6f7/XZKNH+9+hBLOHYozuKQPxyMPUKkrX/K0uWnfFaJGS1QPRtZsOPtr3NsW0uyh6NNCOkU3Yz+bXbT3I8G3xE5EXLXtCXbbqwCO9zPQYPRTZ5vIDXD7U+w7rFDEoUUf7ibHIR4y6bLVPXrz8JVZEql13trxwue/uDivd3fkWRbS6/IA2bID4uk0UpF1N8qLlbBlXs4Ee7HLTfV1j54APvODnSfOWBqtKVvjgLKzF5YdEk5ewRkGlK0i33Eofffc7HT56jD7/6U+qH3Cx7SBLNntH5YIPvODnyfIXZYRVDPqgHtLs5ABHD3YzLuespb7t79FY34DjMwrVrcTuwlT55YMPvOBnRrJ4VXTdNnYug5ucHLBjEpt30701A3Ts+HEa73u6dT3FNWwflY86eMHPk+Yu+i6pzUpRrW7SNDg5JHR4KapmM5Wv2E8Tfcb1HoqqHMHU+uWDD7zg54mz5/2BSnizi9T1Dg4QQXLToGNCkb6tb1NU+QAlGr1++eADrzhn/u8Q2YZhQVlZ5+CAOtqfbhmaUCS1ezNFVm2imDbPmPng5wmz+gwh+oHDce0eUtQ6OGDIyR0uUhUsoO3vfDmmgOezH0mZN59x7MBi++WDL1g/eEiU3avlidO671bkLfwbw5XV2P8Pzo0ydy4t2/0eu33xYSOMOD8hTf4CrBtGMSoXfPLchX+J0ruSePw3LZeK0juPJbYzrhkH0io7B3k164hiGvawhOKMLkrQLyVpZg8rHFW7E2uHOL888IBPlNZ1FPzstSJM694fWr6RwpvcJK60+0HCILTBzZLFNdtAzJaohze60T8qBzyh5ZuOg5e7uwQppofEmf2++DYvmySqGBuKaicF1blQjhuHdvCIMvp8whTTfZzI7RldpwtSzL+F1+wkdZ2TBOW2gIF88PBTzD/gpeREAMEbxnJcaJHNHrpzji0gQCS6hdkEeYt9DF/2qPcEC8RM28Hwmr3sdNyht00byAut2k3gufWNtgtOEOFGUwcXWNDbdNbpgBGxEvKkOQsxivJx33iow0Vw5S6SVTrpVq11ysA2Rp7gTfPfktc6zhtXBBC+adRLshf6sG2RfHPZ5EAc4sVZ83yCN00Fk/4kggu40ZTvIEm5g24qtU4KjBrx/BTTH8ifVASAG7gKrnWxJDcU7x8X6Ecczhm3o6YicvsLXWfh3Ch1W0k8x0nXF+0fFxgt4phz8QvypiwCCFKMqXCnqXExjq10beH+UUA7+nG6mdG/Pu0f3LgFcGrl2s0kNNjpmoJ9o4B29CMO8dMT4Q5ox8uitF6fqsrJOr8qnwNbRzv6hSnG5wP+64C7h9lp30hKNtKdWjtdkbuPA19nJ7Tz3zR/ibgARbhb4AlhavcBebmTHcFl2fvYEnW0ox9xMxKBS8btJ+KiEbq9zA4RthQXDhPa0T9TEe69gWupwc6uBUphquXgf+/FrIjweHQS4/pduMe5ERUMHUd9xv8ZR98CxkS4F2n3EUrUZ10EYNw7BWm9x1GiPssi3GgiGRDKWRYZfXlON+dfNbM+GgIwYdwAAAAASUVORK5CYII=';
        // private static mapPinShadowImage: string = 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACkAAAApCAQAAAACach9AAACMUlEQVR4Ae3ShY7jQBAE0Aoz/f9/HTMzhg1zrdKUrJbdx+Kd2nD8VNudfsL/Th///dyQN2TH6f3y/BGpC379rV+S+qqetBOxImNQXL8JCAr2V4iMQXHGNJxeCfZXhSRBcQMfvkOWUdtfzlLgAENmZDcmo2TVmt8OSM2eXxBp3DjHSMFutqS7SbmemzBiR+xpKCNUIRkdkkYxhAkyGoBvyQFEJEefwSmmvBfJuJ6aKqKWnAkvGZOaZXTUgFqYULWNSHUckZuR1HIIimUExutRxwzOLROIG4vKmCKQt364mIlhSyzAf1m9lHZHJZrlAOMMztRRiKimp/rpdJDc9Awry5xTZCte7FHtuS8wJgeYGrex28xNTd086Dik7vUMscQOa8y4DoGtCCSkAKlNwpgNtphjrC6MIHUkR6YWxxs6Sc5xqn222mmCRFzIt8lEdKx+ikCtg91qS2WpwVfBelJCiQJwvzixfI9cxZQWgiSJelKnwBElKYtDOb2MFbhmUigbReQBV0Cg4+qMXSxXSyGUn4UbF8l+7qdSGnTC0XLCmahIgUHLhLOhpVCtw4CzYXvLQWQbJNmxoCsOKAxSgBJno75avolkRw8iIAFcsdc02e9iyCd8tHwmeSSoKTowIgvscSGZUOA7PuCN5b2BX9mQM7S0wYhMNU74zgsPBj3HU7wguAfnxxjFQGBE6pwN+GjME9zHY7zGp8wVxMShYX9NXvEWD3HbwJf4giO4CFIQxXScH1/TM+04kkBiAAAAAElFTkSuQmCC';
        this.smallLoaderValue = null;
        this.isMapShown = true;
        this.isLayerLoading = true;
        this.isLinkToGoogle = false;
        this.googleLink = '';
        this.errorMessage = '';
        this.googleImage = 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADIAAAAyCAYAAAAeP4ixAAAABHNCSVQICAgIfAhkiAAAAAlwSFlzAAAOawAADmsBVP4NBgAAABl0RVh0U29mdHdhcmUAd3d3Lmlua3NjYXBlLm9yZ5vuPBoAAAatSURBVGiB7ZlbbBzVGcd/Z2Zn7L34Hmyyu97cHIfEjdNYMXUwRLaSUtJC1YoQqw1tKVIpyUPVclFLLyqR0zxUlYJUKYIIqQ/lhVDoRS2NiiEuIIpJ0lxMGyAbAontpNSX2PF6vbc5fXDH8WVmdtZeK63k/9PZ75zzne+335lvzp6FRf1vSdzoAAC6tzRWe4T4EshtQDVQAgwDl6SUf9EU9ferO7t6nHzcUJD3mjcG8Xj2SngA8DgMTQG/kobx5Lo3Tly2GnDDQP7R2rhVMTgMlOcwbUBIsfOW1995bWbHDQF5r3VTszTEq0DBHKaPS6G0ruvsenuq0REk+Mx9EUUojwlokFIUzmHRWaqKpbSDR3rWFScMp62UTVcMwca6zmNXTIOts+Az90UUlFNIyiQAch7rXtfXu4coThjzdXOzKmkHvmUabEEUxKNA2Uz7Em8xX1x1G+uXrERVFM4N9fLnC11Er/ZlXb0ylmbrhWuOYyQwljHwqYrjdpHwjXMtn9lrVjOH9Iq6mZZ7V9/BvtsfJKB5p9kf27STX578Lb84ftgxyC0XY6g2iZXAu7E4Z66Nk5AGBYqgPuClzleIIiyRtBSZHcBTAIo9B+pMiAOtewhoXuLpBH/r+yevXjxJf3yEjMxw+t/nHSEANv4rbtt3ejTOsZExEnJi2yUMybGRMc7E7OcIKbaabVcPXEmBn/bmbyIQnPwkyu6Op+gd7QfArxVSUxpyBVIZS1vazWxYqXt0nPqAz+YblxGzZZ+RKfrCiiaKdB9j6QQPdxyYhACIpcZdQQAUpawf8rhhkDSs91xKSuIZu+IgKsyWq4ysq1gGwKlPovSNDkzaT9z/NJW+0mljD535I+1vP2fpZ0wVVFjYvYqCrghLGE0IvKpNPpAjZttVRsyHLWNkL5uaYv/dfFyqW9oF8OmA17KvochuW4FAvGu2XWUkerUXgA2VKykp8DOciAFw/8v78SgedNXDc9ufIKB76Zmy7WaqM+Ln9ksxy746vxfJxEOfNCS6ItgQ8LLWZ//yF0JOlklXGfnTh13E0wmKdT8HWvZMlt+zgxfp7v+Qu5Y3EtC9SCSdl07Z+nkzEqDfq1r2CWC938uuqnLaKsvYVVXOer/XrvQC9Fwm8Dvzg7VXoPieTz0ALIeJBzqeTtJSvYFVpUF21G5hTXmYpmAdjzfu5O6VTQD8IfoWvz7bYQsiBfg12NDrUFIBXRFZD4FSyh/e+te3uszPrs87z3a/TJHu47sN93Kzv5y2Na3T+jsvneYHbz7r6KNKz/BgWxJ9WCH2/ryOKa+sff34wamGnA5uB078hiMX3qHtllZqy8KkMmn6YgMcuXCMN3rPYEj781iVnuH5+gFW+dIkv6rx0f4kRmJO57drhsjsETMOf7YZDB9qO4qkZS4rzdRUiMlo/p6h91Aqd2eK3LH26PEXZ5nnFaELVVpAABQ1qPg3l+Tka6ihPmkFAQsMUqlnOGwBARAzIgx8+QmMpUFXvoxgkJ577h6z618wkGwQH4w/RFoNkGjbBUqWMFSV8bavYXhsi+zCgDhCyGV8MP4QGTnxgzNTvYxUy9ZZ46Yq2boNI1ztOCbvIE4QGX0N8Yp9oPin2ROf3Y5RbnUKA6NiCaltd2VdN68g2SBGy/bi0UsIh6pR1SnbRNdJ3bnd0mfyc59HalrWtfMG4gZCCh8AmqYTXBqaBpNqaMQomV7FjJJS0hs3uVo/LyBOEO8PruF08jqEqYKCQsKhyHUYVSXd1DxtTGpzc/ZC8F/NG8QJ4mx/Ld/raOfHLwQ4d2X2XE3TpsGkGpvAPCQqCulbb3Mdx7xAskE8+to+YkkfsQT89AUlK4wsK8cIhQEwwhFkifsX5pxB3EKYcguTrqkFIFOzOqd45gSSK4QpNzCsWAlMvF9yUc4gc4UwlQ2matNmYGJr5aKcQOYLYcoJpiAUpvhHexE33ZRLaO5B8gVhygnG17h59kszi1yB5BvClPM20wnlAJMVZKEgTDnB6DnAOILY/SiC/ECYygeMLUh1YUZ/vn6AmgWGMJUNZmkwRIFHt43XtuPnNVdrrCCiQyv4/tEn8wphKpaA9pcUPra44yvUCwlXhWzvGGxB4oaY9e9pdGg5j3T8jOFE8VxjzarhMfjJYWuYnvHBqN08W5Bo3PPwSEZMXrmcvxrhkY79CwphyoT5qP/63ddIckxGB/t2281xvNA7+Mr2plpf+mk9VbVqf9fu1NB4ID9/JLpUmU8V37lT0xKey+ejg5e//fgdX+nKPmtRi1rUov4f9B+IBMnVIJV2nAAAAABJRU5ErkJggg==';
        this.markersLegend = [];
        this.htmlClass = '';
        this._clusterMarkers = {};
        this._isLayerError = false;
        this._isMarkerLoaded = false;
        this._isTilesLoaded = false;
        this._layerReloadTimes = 0;
        this._tileloadIndex = 0;
    }
    ngOnInit() {
        window.addEventListener('resize', this._resizeMap);
        if (typeof this.config.id === 'undefined') {
            this.config.id = 'kdx-map-01';
        }
    }
    ngOnChanges(_simpleChanges) {
        if (_simpleChanges.hasOwnProperty('api')) {
            this._initApi();
        }
        if (_simpleChanges.hasOwnProperty('position')) {
            this._validateLatLng(_simpleChanges.position.currentValue);
            if (!_simpleChanges['position'].firstChange && this.isMapShown) {
                if (typeof this._myMap === 'undefined') {
                    timer(200).subscribe(() => { this._reinitMap(); });
                }
                else
                    this._myMap.panTo(this.position);
            }
        }
        if (_simpleChanges.hasOwnProperty('config')) {
            this.errorMessage = _simpleChanges.config.currentValue.errorMessage || 'Invalid latitude/longitude value';
            if (_simpleChanges.hasOwnProperty('position')) {
                if (_simpleChanges.config.currentValue.googleLink && _simpleChanges.config.currentValue.googleLink.display && this.isMapShown) {
                    this._setGoogleLink(_simpleChanges.position.currentValue);
                }
            }
            if (!_simpleChanges['config'].firstChange) {
                if (this.config.zoom) {
                    this._checkZoomConfig(this.config.zoom);
                    if (this.config.zoom.value) {
                        if (typeof this._myMap !== 'undefined')
                            this._myMap.setZoom(this.config.zoom.value);
                    }
                }
                if (this.config.attribution)
                    this._removeDefaultAttribution(this.config.attribution);
                if (this.config.type !== 'basic') {
                    this._removeAllMarkerLayers();
                    this._setMarkers();
                }
            }
            this._setDefaultConfig();
        }
        if (_simpleChanges.hasOwnProperty('data') && !_simpleChanges['data'].firstChange && this.config.type !== 'basic') {
            this._removeAllMarkerLayers();
            this._setMarkers();
        }
    }
    ngAfterViewInit() {
        if (this.isMapShown) {
            this._initMap();
            this._cd.detectChanges();
            this._resizeMap();
        }
    }
    ngOnDestroy() {
        window.removeEventListener('resize', this._resizeMap);
    }
    onLegendClick(_legendItem) {
        let legendItemMarker = this._elementRef.nativeElement.querySelector('#kdli-' + _legendItem.id + ' .awesome-marker');
        let legendItemLabel = this._elementRef.nativeElement.querySelector('#kdli-' + _legendItem.id + ' .kdx-legend-label');
        let selectedMarkerGroup;
        switch (this.config.type) {
            case 'cluster':
            case 'group-cluster':
                selectedMarkerGroup = this._clusterMarkers[_legendItem.id];
                break;
            default:
                selectedMarkerGroup = this._marker;
                break;
        }
        if (this._myMap.hasLayer(selectedMarkerGroup)) {
            this._myMap.removeLayer(selectedMarkerGroup);
            this._kdDomElemSvc.addClass(legendItemMarker, 'awesome-marker-icon-lightgray');
            this._kdDomElemSvc.addClass(legendItemLabel, 'kdx-label-lightgray');
        }
        else {
            this._myMap.addLayer(selectedMarkerGroup);
            this._kdDomElemSvc.removeClass(legendItemMarker, 'awesome-marker-icon-lightgray');
            this._kdDomElemSvc.removeClass(legendItemLabel, 'kdx-label-lightgray');
        }
    }
    _validateLatLng(_position) {
        if (!_position) {
            this.isMapShown = false;
            this.isMapError = !this.isMapShown;
        }
        else {
            let _lat = _position.lat;
            let _lng = _position.lng;
            this.isMapShown = (typeof _lat === 'undefined') || (typeof _lng === 'undefined') || (_lng < -180 || _lng > 180) || (_lat < -90 || _lat > 90) ? false : true;
            this.isMapError = !this.isMapShown;
        }
        if (!this.isMapShown && this._myMap) {
            delete this._myMap;
            delete this._layer;
            delete this._marker;
            delete this._clusterMarkers;
            delete this.markersLegend;
        }
    }
    _initMap() {
        this._myMap = L.map(this.myMap.nativeElement, {
            center: this.position,
            zoom: (this.config.zoom && this.config.zoom.value) || 14,
        });
        if (this.config.zoom)
            this._checkZoomConfig(this.config.zoom);
        this._setLayer();
        this._setMarkers();
        this._removeDefaultAttribution(this.config.attribution);
        if (this.config.googleLink && this.config.googleLink.display && this.config.type === 'basic')
            this._setLinkStyle(this.config.zoom, this.config.googleLink.position);
    }
    _reinitMap() {
        timer(50).subscribe(() => {
            if (typeof this.myMap === 'undefined')
                this._reinitMap();
            else
                this._initMap();
        });
    }
    _initApi() {
        if (typeof this.api !== 'undefined' && Object.keys(this.api).length === 0) {
            this.api.resizeMap = () => this._resizeMap();
            this.api.getZoom = () => this._myMap.getZoom();
        }
    }
    _checkZoomConfig(_config) {
        if (typeof this._myMap !== 'undefined') {
            _config.isZoomButton ? this._myMap.addControl(this._myMap.zoomControl) : this._myMap.removeControl(this._myMap.zoomControl);
            _config.isScrollZoom ? this._myMap.scrollWheelZoom.enable() : this._myMap.scrollWheelZoom.disable();
            _config.isTouchZoom ? this._myMap.touchZoom.enable() : this._myMap.touchZoom.disable();
            _config.isDoubleClickZoom ? this._myMap.doubleClickZoom.enable() : this._myMap.doubleClickZoom.disable();
        }
    }
    _setLayer() {
        if (this._layer)
            this._layer.remove();
        this._isLayerError = false;
        this.isLayerLoading = true;
        this._layer = L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
            attribution: '&copy; <a href="http://www.openstreetmap.org/copyright">OpenStreetMap</a>',
            maxZoom: 18,
        });
        this._layer.addTo(this._myMap);
        this._attachTileListener();
    }
    _removeDefaultAttribution(_attribution) {
        let attributionElement = this._elementRef.nativeElement.querySelector('.leaflet-control-attribution');
        if (attributionElement !== null) {
            let newAttributionElement = this._kdDomElemSvc.createElement(attributionElement, 'custom-attribution');
            newAttributionElement.innerText = _attribution || 'OpenEMIS';
            attributionElement.replaceChild(newAttributionElement, attributionElement.firstChild);
        }
    }
    _attachTileListener() {
        /* Checks every tile. Only called when some tile load has failed. */
        this._layer.on('tileerror', (error) => {
            // only execute the following for the first tile error
            if (!this._isLayerError) {
                this._isLayerError = true;
                this._layerReloadTimes++;
                if (this._layerReloadTimes < 5 || this._layerReloadTimes === 5) {
                    this._setLayer();
                }
                if (this._layerReloadTimes > 5) {
                    this.isMapShown = false;
                    this.errorMessage = 'Max retry reached. Map cannot be loaded now. Please check your internet connection or try again later.';
                }
            }
        });
        /* Checks every tile. Only called when each tile load is successful. */
        this._layer.on('tileload', () => {
            this._tileloadIndex++;
            if (this.isLayerLoading && this._tileloadIndex === Object.keys(this._layer._tiles).length) {
                // only stop progress loader when last tile loaded successfully
                // this.isLayerLoading = false;
                this._isTilesLoaded = true;
                this._hideLoadingScreen();
                // reset counters
                this._layerReloadTimes = 0;
                this._tileloadIndex = 0;
            }
        });
    }
    _resizeMap() {
        if (this.isMapShown) {
            timer().subscribe(() => {
                this._myMap.invalidateSize({});
            });
        }
    }
    _setGoogleLink(_position) {
        if (this.config.type === 'basic') {
            this.isLinkToGoogle = true;
            this.googleLink = 'https://www.google.com/maps/?q=' + _position.lat.toString() + ',' + _position.lng.toString();
        }
        else {
            this.isLinkToGoogle = false;
        }
    }
    _setLinkStyle(_zoomConfig, _linkPosition) {
        let linkElement = this._elementRef.nativeElement.querySelector('.kdx-map .link-wrapper');
        switch (_linkPosition) {
            case 'top-left':
            default:
                // only when Zoom Buttons are removed then we put googleLink at the position of the Zoom Buttons
                let newClass = _zoomConfig && _zoomConfig.isZoomButton === false ? '' : ' below-zoom';
                this._kdDomElemSvc.addClass(linkElement, 'leaflet-top leaflet-left' + newClass);
                break;
            case 'top-right':
                this._kdDomElemSvc.addClass(linkElement, 'leaflet-top leaflet-right');
                break;
            case 'bottom-left':
                this._kdDomElemSvc.addClass(linkElement, 'leaflet-bottom leaflet-left');
                break;
            case 'bottom-right':
                this._kdDomElemSvc.addClass(linkElement, 'leaflet-bottom leaflet-right above-attribution');
                break;
        }
    }
    _setMarkers() {
        if (typeof this._myMap !== 'undefined') {
            switch (this.config.type) {
                case 'cluster':
                case 'group-cluster':
                    if (typeof this.data !== 'undefined' && Object.keys(this.data).length !== 0) {
                        let clusterData = this._kdMapSvc.populateMarkers(this.data, this._myMap, this.config.type);
                        this.markersLegend = clusterData.markersLegend;
                        this._clusterMarkers = clusterData.clusterMarkers;
                        this._isMarkerLoaded = true;
                    }
                    break;
                default:
                    let defaultIcon = {
                        markerColor: 'purple',
                        title: this.config.marker.title
                    };
                    let iconMarker = this._kdMapSvc.setIcon(defaultIcon);
                    this._marker = L.marker(this.position, { icon: iconMarker }).addTo(this._myMap);
                    this._isMarkerLoaded = true;
                    if (this.config.hasOwnProperty('content')) {
                        this._marker.bindPopup(this.config.content);
                    }
                    if (this.config.hasOwnProperty('legend')) {
                        this.markersLegend = [{
                                icon: iconMarker.createIcon(),
                                label: this.config.marker.title,
                                id: this.config.marker.hasOwnProperty('id') ? this.config.marker.id : 'kdx-single-marker'
                            }];
                    }
                    break;
            }
        }
        this._hideLoadingScreen();
    }
    _hideLoadingScreen() {
        if (this._isMarkerLoaded && this._isTilesLoaded) {
            this.isLayerLoading = false;
        }
    }
    _removeAllMarkerLayers() {
        for (let legendItemId in this._clusterMarkers) {
            if (this._clusterMarkers[legendItemId])
                this._myMap.removeLayer(this._clusterMarkers[legendItemId]);
        }
        this.markersLegend = [];
    }
    _setDefaultConfig() {
        this.mapConfig = this._kdMapSvc.getDefaultConfig();
        this._dataSvc.deepMergeObject(this.mapConfig, this.config, false);
        this.mapConfig.legend.enabled = this._setEnabled('legend', ['title']);
        if (this.mapConfig.footer)
            this.mapConfig.footer.enabled = this._setEnabled('footer', ['bottomLabel', 'footNote']);
        this._setClassNames();
    }
    _setEnabled(_objKey, _textKeys) {
        if (this.mapConfig[_objKey] && typeof this.mapConfig[_objKey].enabled !== 'undefined') {
            return this.mapConfig[_objKey].enabled;
        }
        for (let i = _textKeys.length - 1; i >= 0; i--) {
            if (this.mapConfig[_objKey][_textKeys[i]] && this.mapConfig[_objKey][_textKeys[i]].text !== '') {
                return true;
            }
        }
        if (_objKey === 'legend' && this.markersLegend.length === 0) {
            return false;
        }
        return false;
    }
    /* To be revisit. Hot fix for downgrade component as ngclass value doesn't change.*/
    _setClassNames() {
        // htmlClassObj is a workaround for downgrade method
        this.htmlClass = '';
        if (typeof this.config.legend.float !== 'undefined' && this.config.legend.float) {
            this.htmlClass += 'legend-float ';
        }
        if (typeof this.config.legend.verticalAlign !== 'undefined') {
            this.htmlClass += this.config.legend.verticalAlign + ' ';
        }
        if (typeof this.config.legend.align !== 'undefined') {
            this.htmlClass += this.config.legend.align;
        }
    }
}
KdMap.decorators = [
    { type: Component, args: [{
                selector: 'kd-map',
                template: "<div class=\"kdx-charts-wrapper {{htmlClass}}\" id=\"{{config.id}}\">\r\n    <div class=\"kdx-charts-main\">\r\n        <div class=\"kdx-header-container\" *ngIf=\"mapConfig.title && mapConfig.title.text && mapConfig.title.text !== '' || mapConfig.subtitle && mapConfig.subtitle.text && mapConfig.subtitle.text !== ''\">\r\n            <div class=\"kdx-chart-title {{mapConfig.title.align}}\" *ngIf=\"mapConfig.title && mapConfig.title.text && mapConfig.title.text !== ''\" [ngStyle]=\"mapConfig.title.style\">\r\n                {{mapConfig.title.text}}\r\n            </div>\r\n            <div class=\"kdx-chart-subtitle {{mapConfig.subtitle.align}}\" *ngIf=\"mapConfig.subtitle && mapConfig.subtitle.text && mapConfig.subtitle.text !== ''\" [ngStyle]=\"mapConfig.subtitle.style\">\r\n                {{mapConfig.subtitle.text}}\r\n            </div>\r\n        </div>\r\n        <div class=\"kdx-chart-container\" *ngIf=\"isMapShown\" #myMap>\r\n            <div class=\"link-wrapper\" *ngIf=\"isLinkToGoogle\">\r\n                <a class=\"google-link leaflet-bar leaflet-control\" [attr.href]=\"googleLink\" target=\"_blank\">\r\n                    <img class=\"google-image\" [src]=\"googleImage\">\r\n                </a>\r\n            </div>\r\n        </div>\r\n        <div class=\"kdx-error-map\" *ngIf=\"!isMapShown\">\r\n            <div class=\"kdx-error-icon\"><i class=\"fa fa-map-o\"></i></div>\r\n            <div class=\"kdx-error-message\">{{errorMessage}}</div>\r\n        </div>\r\n    </div>\r\n    <div class=\"kdx-legend-container {{htmlClass}}\" *ngIf=\"mapConfig.legend.enabled && isMapShown\">\r\n        <div class=\"kdx-legends\" *ngIf=\"mapConfig.legend\" [ngStyle]=\"mapConfig.legend.style\">\r\n            <div class=\"kdx-legend-title-container {{mapConfig.legend.title.align}}\" *ngIf=\"mapConfig.legend.title && mapConfig.legend.title.text && mapConfig.legend.title.text !== ''\" [ngStyle]=\"mapConfig.legend.title.style\">\r\n                <div class=\"kdx-legend-title\">{{mapConfig.legend.title.text}}</div>\r\n            </div>\r\n            <div class=\"kdx-legend legend-scroll {{mapConfig.legend.layout}}\">\r\n                <div class=\"kdx-legend-item\" id=\"kdli-{{legendItem.id}}\" *ngFor=\"let legendItem of markersLegend\" (click)=\"onLegendClick(legendItem)\">\r\n                    <div class=\"kdx-legend-marker\" [innerHTML]=\"legendItem.icon.outerHTML\"></div>\r\n                    <div class=\"kdx-legend-label\" [ngStyle]=\"mapConfig.legend.item.style\">\r\n                        <div class=\"kdx-label-text\">{{legendItem.label}}</div>\r\n                    </div>\r\n                </div>\r\n            </div>\r\n        </div>\r\n    </div>\r\n    <kd-progressloader *ngIf=\"isLayerLoading && isMapShown\" configtype=\"small-spinner\" [configvalue]=\"smallLoaderValue\"></kd-progressloader>\r\n</div>\r\n<div class=\"kdx-charts-footer\" *ngIf=\"mapConfig.footer && mapConfig.footer.enabled\">\r\n    <div class=\"kdx-charts-bottom-label {{mapConfig.footer.bottomLabel.align}}\" *ngIf=\"mapConfig.footer && mapConfig.footer.bottomLabel && mapConfig.footer.bottomLabel.text && mapConfig.footer.bottomLabel.text !== ''\" [ngStyle]=\"mapConfig.footer.bottomLabel.style\">\r\n        {{mapConfig.footer.bottomLabel.text}}\r\n    </div>\r\n    <div class=\"kdx-charts-foot-note {{mapConfig.footer.footNote.align}}\" *ngIf=\"mapConfig.footer && mapConfig.footer.footNote && mapConfig.footer.footNote.text && mapConfig.footer.footNote.text !== ''\" [ngStyle]=\"mapConfig.footer.footNote.style\">\r\n        {{mapConfig.footer.footNote.text}}\r\n    </div>\r\n</div>",
                /*template: `
                        <div class="header-container">
                            <div class="chart-title left">{{config.legend.title.text}}</div>
                            <div class="chart-subtitle right">{{config.legend.title.text}}</div>
                        </div>
                        <div *ngIf="isMapShown" class="chart-container"  #myMap>
                            <div class="link-wrapper" *ngIf="isLinkToGoogle">
                                <a [attr.href]="googleLink" target="_blank" class="google-link leaflet-bar leaflet-control">
                                    <img class="google-image" [src]="googleImage">
                                </a>
                            </div>
                        </div>
                        <div class="legend-container center" *ngIf="config.legend && isMapShown">
                            <div class="legends">
                                <div class="legend-title-container right" *ngIf="config.legend.title.text">
                                    <div class="title">{{config.legend.title.text}}</div>
                                </div>
                                <div class="legend">
                                    <div class="legend-item" id="kdli-{{legendItem.id}}" *ngFor="let legendItem of markersLegend" (click)="onLegendClick(legendItem)">
                                        <div class="legend-marker" [innerHTML]="legendItem.icon.outerHTML" ></div>
                                        <div class="legend-label"><div class="label-text">{{legendItem.label}}</div></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div *ngIf="!isMapShown" class="error-map">
                            <div class="error-icon"><i class="fa fa-map-o"></i></div>
                            <div class="error-message">{{errorMessage}}</div>
                        </div>
                        <kd-progressloader *ngIf="isLayerLoading && isMapShown" configtype="small-spinner" [configvalue]="smallLoaderValue"></kd-progressloader>
            
                `,*/
                encapsulation: ViewEncapsulation.None,
                host: {
                    'class': 'kdx-map',
                    '[style.background-color]': 'mapConfig.mapArea.style.backgroundColor',
                    '[style.font-family]': 'mapConfig.mapArea.style.fontFamily'
                },
                providers: [KdDomElemSvc, KdMapSvc, KdDataSvc]
            },] }
];
KdMap.ctorParameters = () => [
    { type: ElementRef },
    { type: KdSplitterEvent },
    { type: KdDomElemSvc },
    { type: KdMapSvc },
    { type: ChangeDetectorRef },
    { type: KdDataSvc }
];
KdMap.propDecorators = {
    position: [{ type: Input }],
    config: [{ type: Input }],
    data: [{ type: Input }],
    api: [{ type: Input }],
    myMap: [{ type: ViewChild, args: ['myMap',] }],
    isMapError: [{ type: HostBinding, args: ['class.error',] }]
};
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoia2QtYW5ndWxhci1tYXAuanMiLCJzb3VyY2VSb290IjoiQzoveGFtcHAvaHRkb2NzL1N0eWxlZ3VpZGUvaW9zdGctb3BlbmVtaXMtc3R5bGVndWlkZS9wcm9qZWN0cy9vcGVuZW1pcy1zdHlsZWd1aWRlLWxpYi9zcmMvIiwic291cmNlcyI6WyJrZC1jb21wb25lbnRzL2tkLWFuZ3VsYXItbWFwL2tkLWFuZ3VsYXItbWFwLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBLE9BQU8sRUFDSCxTQUFTLEVBQ1QsaUJBQWlCLEVBQ2pCLEtBQUssRUFLTCxVQUFVLEVBRVYsU0FBUyxFQUVULFdBQVcsRUFDWCxpQkFBaUIsRUFDcEIsTUFBTSxlQUFlLENBQUM7QUFDdkIsb0RBQW9EO0FBQ3BELE9BQU8sRUFBRSxLQUFLLEVBQUUsTUFBTSxNQUFNLENBQUM7QUFDN0IsaURBQWlEO0FBQ2pELE9BQU8sS0FBSyxDQUFDLE1BQU0sU0FBUyxDQUFDO0FBQzdCLE9BQU8sdUJBQXVCLENBQUM7QUFDL0IsT0FBTyxzREFBc0QsQ0FBQztBQUM5RCxPQUFPLEVBQUUsZUFBZSxFQUFFLE1BQU0sOEJBQThCLENBQUM7QUFDL0QsT0FBTyxFQUFFLFlBQVksRUFBRSxNQUFNLG9CQUFvQixDQUFDO0FBQ2xELE9BQU8sRUFBRSxRQUFRLEVBQTJCLE1BQU0sc0JBQXNCLENBQUM7QUFTekUsT0FBTyxFQUFFLFNBQVMsRUFBRSxNQUFNLG9CQUFvQixDQUFDO0FBOEMvQyxNQUFNLE9BQU8sS0FBSztJQXdDZCxZQUNZLFdBQXVCLEVBQy9CLGdCQUFpQyxFQUN6QixhQUEyQixFQUMzQixTQUFtQixFQUNuQixHQUFzQixFQUN0QixRQUFtQjtRQUxuQixnQkFBVyxHQUFYLFdBQVcsQ0FBWTtRQUV2QixrQkFBYSxHQUFiLGFBQWEsQ0FBYztRQUMzQixjQUFTLEdBQVQsU0FBUyxDQUFVO1FBQ25CLFFBQUcsR0FBSCxHQUFHLENBQW1CO1FBQ3RCLGFBQVEsR0FBUixRQUFRLENBQVc7UUE1Qy9CLHErREFBcStEO1FBQ3IrRCwrM0JBQSszQjtRQUV4M0IscUJBQWdCLEdBQVEsSUFBSSxDQUFDO1FBQzdCLGVBQVUsR0FBWSxJQUFJLENBQUM7UUFDM0IsbUJBQWMsR0FBWSxJQUFJLENBQUM7UUFDL0IsbUJBQWMsR0FBWSxLQUFLLENBQUM7UUFDaEMsZUFBVSxHQUFXLEVBQUUsQ0FBQztRQUN4QixpQkFBWSxHQUFXLEVBQUUsQ0FBQztRQUMxQixnQkFBVyxHQUFXLGc3RUFBZzdFLENBQUM7UUFFdjhFLGtCQUFhLEdBQWUsRUFBRSxDQUFDO1FBRS9CLGNBQVMsR0FBVyxFQUFFLENBQUM7UUFRdEIsb0JBQWUsR0FBNEMsRUFBRSxDQUFDO1FBRTlELGtCQUFhLEdBQVksS0FBSyxDQUFDO1FBQy9CLG9CQUFlLEdBQVksS0FBSyxDQUFDO1FBQ2pDLG1CQUFjLEdBQVksS0FBSyxDQUFDO1FBQ2hDLHNCQUFpQixHQUFXLENBQUMsQ0FBQztRQUM5QixtQkFBYyxHQUFXLENBQUMsQ0FBQztJQWtCL0IsQ0FBQztJQUVMLFFBQVE7UUFDSixNQUFNLENBQUMsZ0JBQWdCLENBQUMsUUFBUSxFQUFFLElBQUksQ0FBQyxVQUFVLENBQUMsQ0FBQztRQUVuRCxJQUFJLE9BQU8sSUFBSSxDQUFDLE1BQU0sQ0FBQyxFQUFFLEtBQUssV0FBVyxFQUFFO1lBQ3ZDLElBQUksQ0FBQyxNQUFNLENBQUMsRUFBRSxHQUFHLFlBQVksQ0FBQztTQUNqQztJQUNMLENBQUM7SUFFRCxXQUFXLENBQUMsY0FBNkI7UUFDckMsSUFBSSxjQUFjLENBQUMsY0FBYyxDQUFDLEtBQUssQ0FBQyxFQUFFO1lBQ3RDLElBQUksQ0FBQyxRQUFRLEVBQUUsQ0FBQztTQUNuQjtRQUVELElBQUksY0FBYyxDQUFDLGNBQWMsQ0FBQyxVQUFVLENBQUMsRUFBRTtZQUMzQyxJQUFJLENBQUMsZUFBZSxDQUFDLGNBQWMsQ0FBQyxRQUFRLENBQUMsWUFBWSxDQUFDLENBQUM7WUFFM0QsSUFBSSxDQUFDLGNBQWMsQ0FBQyxVQUFVLENBQUMsQ0FBQyxXQUFXLElBQUksSUFBSSxDQUFDLFVBQVUsRUFBRTtnQkFFNUQsSUFBSSxPQUFPLElBQUksQ0FBQyxNQUFNLEtBQUssV0FBVyxFQUFFO29CQUNwQyxLQUFLLENBQUMsR0FBRyxDQUFDLENBQUMsU0FBUyxDQUFDLEdBQVMsRUFBRSxHQUFHLElBQUksQ0FBQyxVQUFVLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO2lCQUM1RDs7b0JBQ0ksSUFBSSxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxDQUFDO2FBQ3pDO1NBQ0o7UUFHRCxJQUFJLGNBQWMsQ0FBQyxjQUFjLENBQUMsUUFBUSxDQUFDLEVBQUU7WUFDekMsSUFBSSxDQUFDLFlBQVksR0FBRyxjQUFjLENBQUMsTUFBTSxDQUFDLFlBQVksQ0FBQyxZQUFZLElBQUksa0NBQWtDLENBQUM7WUFFMUcsSUFBSSxjQUFjLENBQUMsY0FBYyxDQUFDLFVBQVUsQ0FBQyxFQUFFO2dCQUMzQyxJQUFJLGNBQWMsQ0FBQyxNQUFNLENBQUMsWUFBWSxDQUFDLFVBQVUsSUFBSSxjQUFjLENBQUMsTUFBTSxDQUFDLFlBQVksQ0FBQyxVQUFVLENBQUMsT0FBTyxJQUFJLElBQUksQ0FBQyxVQUFVLEVBQUU7b0JBQzNILElBQUksQ0FBQyxjQUFjLENBQUMsY0FBYyxDQUFDLFFBQVEsQ0FBQyxZQUFZLENBQUMsQ0FBQztpQkFDN0Q7YUFDSjtZQUNELElBQUksQ0FBQyxjQUFjLENBQUMsUUFBUSxDQUFDLENBQUMsV0FBVyxFQUFFO2dCQUN2QyxJQUFJLElBQUksQ0FBQyxNQUFNLENBQUMsSUFBSSxFQUFFO29CQUNsQixJQUFJLENBQUMsZ0JBQWdCLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsQ0FBQztvQkFFeEMsSUFBSSxJQUFJLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxLQUFLLEVBQUU7d0JBQ3hCLElBQUksT0FBTyxJQUFJLENBQUMsTUFBTSxLQUFLLFdBQVc7NEJBQUUsSUFBSSxDQUFDLE1BQU0sQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLENBQUM7cUJBQ3ZGO2lCQUNKO2dCQUVELElBQUksSUFBSSxDQUFDLE1BQU0sQ0FBQyxXQUFXO29CQUFFLElBQUksQ0FBQyx5QkFBeUIsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLFdBQVcsQ0FBQyxDQUFDO2dCQUVyRixJQUFJLElBQUksQ0FBQyxNQUFNLENBQUMsSUFBSSxLQUFLLE9BQU8sRUFBRTtvQkFDOUIsSUFBSSxDQUFDLHNCQUFzQixFQUFFLENBQUM7b0JBQzlCLElBQUksQ0FBQyxXQUFXLEVBQUUsQ0FBQztpQkFDdEI7YUFDSjtZQUVELElBQUksQ0FBQyxpQkFBaUIsRUFBRSxDQUFDO1NBQzVCO1FBRUQsSUFBSSxjQUFjLENBQUMsY0FBYyxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsY0FBYyxDQUFDLE1BQU0sQ0FBQyxDQUFDLFdBQVcsSUFBSSxJQUFJLENBQUMsTUFBTSxDQUFDLElBQUksS0FBSyxPQUFPLEVBQUU7WUFDOUcsSUFBSSxDQUFDLHNCQUFzQixFQUFFLENBQUM7WUFDOUIsSUFBSSxDQUFDLFdBQVcsRUFBRSxDQUFDO1NBQ3RCO0lBQ0wsQ0FBQztJQUVELGVBQWU7UUFDWCxJQUFJLElBQUksQ0FBQyxVQUFVLEVBQUU7WUFDakIsSUFBSSxDQUFDLFFBQVEsRUFBRSxDQUFDO1lBQ2hCLElBQUksQ0FBQyxHQUFHLENBQUMsYUFBYSxFQUFFLENBQUM7WUFFekIsSUFBSSxDQUFDLFVBQVUsRUFBRSxDQUFDO1NBQ3JCO0lBQ0wsQ0FBQztJQUVELFdBQVc7UUFDUCxNQUFNLENBQUMsbUJBQW1CLENBQUMsUUFBUSxFQUFFLElBQUksQ0FBQyxVQUFVLENBQUMsQ0FBQztJQUMxRCxDQUFDO0lBRU0sYUFBYSxDQUFDLFdBQWdCO1FBQ2pDLElBQUksZ0JBQWdCLEdBQWdCLElBQUksQ0FBQyxXQUFXLENBQUMsYUFBYSxDQUFDLGFBQWEsQ0FBQyxRQUFRLEdBQUcsV0FBVyxDQUFDLEVBQUUsR0FBRyxrQkFBa0IsQ0FBQyxDQUFDO1FBQ2pJLElBQUksZUFBZSxHQUFnQixJQUFJLENBQUMsV0FBVyxDQUFDLGFBQWEsQ0FBQyxhQUFhLENBQUMsUUFBUSxHQUFHLFdBQVcsQ0FBQyxFQUFFLEdBQUcsb0JBQW9CLENBQUMsQ0FBQztRQUNsSSxJQUFJLG1CQUFvRCxDQUFDO1FBRXpELFFBQVEsSUFBSSxDQUFDLE1BQU0sQ0FBQyxJQUFJLEVBQUU7WUFDdEIsS0FBSyxTQUFTLENBQUM7WUFDZixLQUFLLGVBQWU7Z0JBQ2hCLG1CQUFtQixHQUFHLElBQUksQ0FBQyxlQUFlLENBQUMsV0FBVyxDQUFDLEVBQUUsQ0FBQyxDQUFDO2dCQUMzRCxNQUFNO1lBQ1Y7Z0JBQ0ksbUJBQW1CLEdBQUcsSUFBSSxDQUFDLE9BQU8sQ0FBQztnQkFDbkMsTUFBTTtTQUNiO1FBRUQsSUFBSSxJQUFJLENBQUMsTUFBTSxDQUFDLFFBQVEsQ0FBQyxtQkFBbUIsQ0FBQyxFQUFFO1lBQzNDLElBQUksQ0FBQyxNQUFNLENBQUMsV0FBVyxDQUFDLG1CQUFtQixDQUFDLENBQUM7WUFDN0MsSUFBSSxDQUFDLGFBQWEsQ0FBQyxRQUFRLENBQUMsZ0JBQWdCLEVBQUUsK0JBQStCLENBQUMsQ0FBQztZQUMvRSxJQUFJLENBQUMsYUFBYSxDQUFDLFFBQVEsQ0FBQyxlQUFlLEVBQUUscUJBQXFCLENBQUMsQ0FBQztTQUN2RTthQUNJO1lBQ0QsSUFBSSxDQUFDLE1BQU0sQ0FBQyxRQUFRLENBQUMsbUJBQW1CLENBQUMsQ0FBQztZQUMxQyxJQUFJLENBQUMsYUFBYSxDQUFDLFdBQVcsQ0FBQyxnQkFBZ0IsRUFBRSwrQkFBK0IsQ0FBQyxDQUFDO1lBQ2xGLElBQUksQ0FBQyxhQUFhLENBQUMsV0FBVyxDQUFDLGVBQWUsRUFBRSxxQkFBcUIsQ0FBQyxDQUFDO1NBQzFFO0lBQ0wsQ0FBQztJQUVPLGVBQWUsQ0FBQyxTQUF1QjtRQUMzQyxJQUFJLENBQUMsU0FBUyxFQUFFO1lBQ1osSUFBSSxDQUFDLFVBQVUsR0FBRyxLQUFLLENBQUM7WUFDeEIsSUFBSSxDQUFDLFVBQVUsR0FBRyxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUM7U0FDdEM7YUFBTTtZQUNILElBQUksSUFBSSxHQUFXLFNBQVMsQ0FBQyxHQUFHLENBQUM7WUFDakMsSUFBSSxJQUFJLEdBQVcsU0FBUyxDQUFDLEdBQUcsQ0FBQztZQUNqQyxJQUFJLENBQUMsVUFBVSxHQUFHLENBQUMsT0FBTyxJQUFJLEtBQUssV0FBVyxDQUFDLElBQUksQ0FBQyxPQUFPLElBQUksS0FBSyxXQUFXLENBQUMsSUFBSSxDQUFDLElBQUksR0FBRyxDQUFDLEdBQUcsSUFBSSxJQUFJLEdBQUcsR0FBRyxDQUFDLElBQUksQ0FBQyxJQUFJLEdBQUcsQ0FBQyxFQUFFLElBQUksSUFBSSxHQUFHLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQztZQUM1SixJQUFJLENBQUMsVUFBVSxHQUFHLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQztTQUN0QztRQUNELElBQUksQ0FBQyxJQUFJLENBQUMsVUFBVSxJQUFJLElBQUksQ0FBQyxNQUFNLEVBQUU7WUFDakMsT0FBTyxJQUFJLENBQUMsTUFBTSxDQUFDO1lBQ25CLE9BQU8sSUFBSSxDQUFDLE1BQU0sQ0FBQztZQUNuQixPQUFPLElBQUksQ0FBQyxPQUFPLENBQUM7WUFDcEIsT0FBTyxJQUFJLENBQUMsZUFBZSxDQUFDO1lBQzVCLE9BQU8sSUFBSSxDQUFDLGFBQWEsQ0FBQztTQUM3QjtJQUNMLENBQUM7SUFFTyxRQUFRO1FBRVosSUFBSSxDQUFDLE1BQU0sR0FBRyxDQUFDLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsYUFBYSxFQUFFO1lBQzFDLE1BQU0sRUFBRSxJQUFJLENBQUMsUUFBUTtZQUNyQixJQUFJLEVBQUUsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLElBQUksSUFBSSxJQUFJLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsSUFBSSxFQUFFO1NBQzNELENBQUMsQ0FBQztRQUVILElBQUksSUFBSSxDQUFDLE1BQU0sQ0FBQyxJQUFJO1lBQUUsSUFBSSxDQUFDLGdCQUFnQixDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLENBQUM7UUFFOUQsSUFBSSxDQUFDLFNBQVMsRUFBRSxDQUFDO1FBQ2pCLElBQUksQ0FBQyxXQUFXLEVBQUUsQ0FBQztRQUVuQixJQUFJLENBQUMseUJBQXlCLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxXQUFXLENBQUMsQ0FBQztRQUN4RCxJQUFJLElBQUksQ0FBQyxNQUFNLENBQUMsVUFBVSxJQUFJLElBQUksQ0FBQyxNQUFNLENBQUMsVUFBVSxDQUFDLE9BQU8sSUFBSSxJQUFJLENBQUMsTUFBTSxDQUFDLElBQUksS0FBSyxPQUFPO1lBQUUsSUFBSSxDQUFDLGFBQWEsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLElBQUksRUFBRSxJQUFJLENBQUMsTUFBTSxDQUFDLFVBQVUsQ0FBQyxRQUFRLENBQUMsQ0FBQztJQUN4SyxDQUFDO0lBRU8sVUFBVTtRQUNkLEtBQUssQ0FBQyxFQUFFLENBQUMsQ0FBQyxTQUFTLENBQUMsR0FBUyxFQUFFO1lBQzNCLElBQUksT0FBTyxJQUFJLENBQUMsS0FBSyxLQUFLLFdBQVc7Z0JBQUUsSUFBSSxDQUFDLFVBQVUsRUFBRSxDQUFDOztnQkFDcEQsSUFBSSxDQUFDLFFBQVEsRUFBRSxDQUFDO1FBQ3pCLENBQUMsQ0FBQyxDQUFDO0lBQ1AsQ0FBQztJQUVPLFFBQVE7UUFDWixJQUFJLE9BQU8sSUFBSSxDQUFDLEdBQUcsS0FBSyxXQUFXLElBQUksTUFBTSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUMsTUFBTSxLQUFLLENBQUMsRUFBRTtZQUN2RSxJQUFJLENBQUMsR0FBRyxDQUFDLFNBQVMsR0FBRyxHQUFTLEVBQUUsQ0FBQyxJQUFJLENBQUMsVUFBVSxFQUFFLENBQUM7WUFDbkQsSUFBSSxDQUFDLEdBQUcsQ0FBQyxPQUFPLEdBQUcsR0FBVyxFQUFFLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxPQUFPLEVBQUUsQ0FBQztTQUMxRDtJQUNMLENBQUM7SUFFTyxnQkFBZ0IsQ0FBQyxPQUF1QjtRQUM1QyxJQUFJLE9BQU8sSUFBSSxDQUFDLE1BQU0sS0FBSyxXQUFXLEVBQUU7WUFDcEMsT0FBTyxDQUFDLFlBQVksQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxVQUFVLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxhQUFhLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxXQUFXLENBQUMsQ0FBQztZQUM1SCxPQUFPLENBQUMsWUFBWSxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLGVBQWUsQ0FBQyxNQUFNLEVBQUUsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxlQUFlLENBQUMsT0FBTyxFQUFFLENBQUM7WUFDcEcsT0FBTyxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxTQUFTLENBQUMsTUFBTSxFQUFFLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsU0FBUyxDQUFDLE9BQU8sRUFBRSxDQUFDO1lBQ3ZGLE9BQU8sQ0FBQyxpQkFBaUIsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxlQUFlLENBQUMsTUFBTSxFQUFFLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsZUFBZSxDQUFDLE9BQU8sRUFBRSxDQUFDO1NBQzVHO0lBQ0wsQ0FBQztJQUVPLFNBQVM7UUFDYixJQUFJLElBQUksQ0FBQyxNQUFNO1lBQUUsSUFBSSxDQUFDLE1BQU0sQ0FBQyxNQUFNLEVBQUUsQ0FBQztRQUN0QyxJQUFJLENBQUMsYUFBYSxHQUFHLEtBQUssQ0FBQztRQUMzQixJQUFJLENBQUMsY0FBYyxHQUFHLElBQUksQ0FBQztRQUMzQixJQUFJLENBQUMsTUFBTSxHQUFHLENBQUMsQ0FBQyxTQUFTLENBQUMsb0RBQW9ELEVBQUU7WUFDNUUsV0FBVyxFQUFFLDJFQUEyRTtZQUN4RixPQUFPLEVBQUUsRUFBRTtTQUNkLENBQUMsQ0FBQztRQUNILElBQUksQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQztRQUMvQixJQUFJLENBQUMsbUJBQW1CLEVBQUUsQ0FBQztJQUMvQixDQUFDO0lBRU8seUJBQXlCLENBQUMsWUFBb0I7UUFDbEQsSUFBSSxrQkFBa0IsR0FBWSxJQUFJLENBQUMsV0FBVyxDQUFDLGFBQWEsQ0FBQyxhQUFhLENBQUMsOEJBQThCLENBQUMsQ0FBQztRQUMvRyxJQUFJLGtCQUFrQixLQUFLLElBQUksRUFBRTtZQUM3QixJQUFJLHFCQUFxQixHQUFnQixJQUFJLENBQUMsYUFBYSxDQUFDLGFBQWEsQ0FBQyxrQkFBa0IsRUFBRSxvQkFBb0IsQ0FBQyxDQUFDO1lBQ3BILHFCQUFxQixDQUFDLFNBQVMsR0FBRyxZQUFZLElBQUksVUFBVSxDQUFDO1lBQzdELGtCQUFrQixDQUFDLFlBQVksQ0FBQyxxQkFBcUIsRUFBRSxrQkFBa0IsQ0FBQyxVQUFVLENBQUMsQ0FBQztTQUN6RjtJQUNMLENBQUM7SUFFTyxtQkFBbUI7UUFDdkIsb0VBQW9FO1FBQ3BFLElBQUksQ0FBQyxNQUFNLENBQUMsRUFBRSxDQUFDLFdBQVcsRUFBRSxDQUFDLEtBQUssRUFBUSxFQUFFO1lBQ3hDLHNEQUFzRDtZQUN0RCxJQUFJLENBQUMsSUFBSSxDQUFDLGFBQWEsRUFBRTtnQkFDckIsSUFBSSxDQUFDLGFBQWEsR0FBRyxJQUFJLENBQUM7Z0JBQzFCLElBQUksQ0FBQyxpQkFBaUIsRUFBRSxDQUFDO2dCQUN6QixJQUFJLElBQUksQ0FBQyxpQkFBaUIsR0FBRyxDQUFDLElBQUksSUFBSSxDQUFDLGlCQUFpQixLQUFLLENBQUMsRUFBRTtvQkFDNUQsSUFBSSxDQUFDLFNBQVMsRUFBRSxDQUFDO2lCQUNwQjtnQkFDRCxJQUFJLElBQUksQ0FBQyxpQkFBaUIsR0FBRyxDQUFDLEVBQUU7b0JBQzVCLElBQUksQ0FBQyxVQUFVLEdBQUcsS0FBSyxDQUFDO29CQUN4QixJQUFJLENBQUMsWUFBWSxHQUFHLHdHQUF3RyxDQUFDO2lCQUNoSTthQUNKO1FBQ0wsQ0FBQyxDQUFDLENBQUM7UUFFSCx1RUFBdUU7UUFDdkUsSUFBSSxDQUFDLE1BQU0sQ0FBQyxFQUFFLENBQUMsVUFBVSxFQUFFLEdBQVMsRUFBRTtZQUNsQyxJQUFJLENBQUMsY0FBYyxFQUFFLENBQUM7WUFDdEIsSUFBSSxJQUFJLENBQUMsY0FBYyxJQUFJLElBQUksQ0FBQyxjQUFjLEtBQUssTUFBTSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxDQUFDLE1BQU0sRUFBRTtnQkFDdkYsK0RBQStEO2dCQUMvRCwrQkFBK0I7Z0JBQy9CLElBQUksQ0FBQyxjQUFjLEdBQUcsSUFBSSxDQUFDO2dCQUMzQixJQUFJLENBQUMsa0JBQWtCLEVBQUUsQ0FBQztnQkFDMUIsaUJBQWlCO2dCQUNqQixJQUFJLENBQUMsaUJBQWlCLEdBQUcsQ0FBQyxDQUFDO2dCQUMzQixJQUFJLENBQUMsY0FBYyxHQUFHLENBQUMsQ0FBQzthQUMzQjtRQUNMLENBQUMsQ0FBQyxDQUFDO0lBQ1AsQ0FBQztJQUVPLFVBQVU7UUFDZCxJQUFJLElBQUksQ0FBQyxVQUFVLEVBQUU7WUFDakIsS0FBSyxFQUFFLENBQUMsU0FBUyxDQUFDLEdBQVMsRUFBRTtnQkFDekIsSUFBSSxDQUFDLE1BQU0sQ0FBQyxjQUFjLENBQUMsRUFBRSxDQUFDLENBQUM7WUFDbkMsQ0FBQyxDQUFDLENBQUM7U0FDTjtJQUNMLENBQUM7SUFFTyxjQUFjLENBQUMsU0FBdUI7UUFDMUMsSUFBSSxJQUFJLENBQUMsTUFBTSxDQUFDLElBQUksS0FBSyxPQUFPLEVBQUU7WUFDOUIsSUFBSSxDQUFDLGNBQWMsR0FBRyxJQUFJLENBQUM7WUFDM0IsSUFBSSxDQUFDLFVBQVUsR0FBRyxpQ0FBaUMsR0FBRyxTQUFTLENBQUMsR0FBRyxDQUFDLFFBQVEsRUFBRSxHQUFHLEdBQUcsR0FBRyxTQUFTLENBQUMsR0FBRyxDQUFDLFFBQVEsRUFBRSxDQUFDO1NBQ25IO2FBQ0k7WUFDRCxJQUFJLENBQUMsY0FBYyxHQUFHLEtBQUssQ0FBQztTQUMvQjtJQUNMLENBQUM7SUFFTyxhQUFhLENBQUMsV0FBMkIsRUFBRSxhQUFxQjtRQUNwRSxJQUFJLFdBQVcsR0FBZ0IsSUFBSSxDQUFDLFdBQVcsQ0FBQyxhQUFhLENBQUMsYUFBYSxDQUFDLHdCQUF3QixDQUFDLENBQUM7UUFDdEcsUUFBUSxhQUFhLEVBQUU7WUFDbkIsS0FBSyxVQUFVLENBQUM7WUFDaEI7Z0JBQ0ksZ0dBQWdHO2dCQUNoRyxJQUFJLFFBQVEsR0FBVyxXQUFXLElBQUksV0FBVyxDQUFDLFlBQVksS0FBSyxLQUFLLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsYUFBYSxDQUFDO2dCQUM5RixJQUFJLENBQUMsYUFBYSxDQUFDLFFBQVEsQ0FBQyxXQUFXLEVBQUUsMEJBQTBCLEdBQUcsUUFBUSxDQUFDLENBQUM7Z0JBQ2hGLE1BQU07WUFDVixLQUFLLFdBQVc7Z0JBQ1osSUFBSSxDQUFDLGFBQWEsQ0FBQyxRQUFRLENBQUMsV0FBVyxFQUFFLDJCQUEyQixDQUFDLENBQUM7Z0JBQ3RFLE1BQU07WUFDVixLQUFLLGFBQWE7Z0JBQ2QsSUFBSSxDQUFDLGFBQWEsQ0FBQyxRQUFRLENBQUMsV0FBVyxFQUFFLDZCQUE2QixDQUFDLENBQUM7Z0JBQ3hFLE1BQU07WUFDVixLQUFLLGNBQWM7Z0JBQ2YsSUFBSSxDQUFDLGFBQWEsQ0FBQyxRQUFRLENBQUMsV0FBVyxFQUFFLGdEQUFnRCxDQUFDLENBQUM7Z0JBQzNGLE1BQU07U0FDYjtJQUNMLENBQUM7SUFFTyxXQUFXO1FBQ2YsSUFBSSxPQUFPLElBQUksQ0FBQyxNQUFNLEtBQUssV0FBVyxFQUFFO1lBQ3BDLFFBQVEsSUFBSSxDQUFDLE1BQU0sQ0FBQyxJQUFJLEVBQUU7Z0JBQ3RCLEtBQUssU0FBUyxDQUFDO2dCQUNmLEtBQUssZUFBZTtvQkFDaEIsSUFBSSxPQUFPLElBQUksQ0FBQyxJQUFJLEtBQUssV0FBVyxJQUFJLE1BQU0sQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDLE1BQU0sS0FBSyxDQUFDLEVBQUU7d0JBQ3pFLElBQUksV0FBVyxHQUE0QixJQUFJLENBQUMsU0FBUyxDQUFDLGVBQWUsQ0FBQyxJQUFJLENBQUMsSUFBSSxFQUFFLElBQUksQ0FBQyxNQUFNLEVBQUUsSUFBSSxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsQ0FBQzt3QkFFcEgsSUFBSSxDQUFDLGFBQWEsR0FBRyxXQUFXLENBQUMsYUFBYSxDQUFDO3dCQUMvQyxJQUFJLENBQUMsZUFBZSxHQUFHLFdBQVcsQ0FBQyxjQUFjLENBQUM7d0JBQ2xELElBQUksQ0FBQyxlQUFlLEdBQUcsSUFBSSxDQUFDO3FCQUMvQjtvQkFDRCxNQUFNO2dCQUNWO29CQUNJLElBQUksV0FBVyxHQUFlO3dCQUMxQixXQUFXLEVBQUUsUUFBUTt3QkFDckIsS0FBSyxFQUFFLElBQUksQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLEtBQUs7cUJBQ2xDLENBQUM7b0JBQ0YsSUFBSSxVQUFVLEdBQVcsSUFBSSxDQUFDLFNBQVMsQ0FBQyxPQUFPLENBQUMsV0FBVyxDQUFDLENBQUM7b0JBQzdELElBQUksQ0FBQyxPQUFPLEdBQUcsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsUUFBUSxFQUFFLEVBQUUsSUFBSSxFQUFFLFVBQVUsRUFBRSxDQUFDLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQztvQkFDaEYsSUFBSSxDQUFDLGVBQWUsR0FBRyxJQUFJLENBQUM7b0JBQzVCLElBQUksSUFBSSxDQUFDLE1BQU0sQ0FBQyxjQUFjLENBQUMsU0FBUyxDQUFDLEVBQUU7d0JBQ3ZDLElBQUksQ0FBQyxPQUFPLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDLENBQUM7cUJBQy9DO29CQUVELElBQUksSUFBSSxDQUFDLE1BQU0sQ0FBQyxjQUFjLENBQUMsUUFBUSxDQUFDLEVBQUU7d0JBQ3RDLElBQUksQ0FBQyxhQUFhLEdBQUcsQ0FBQztnQ0FDbEIsSUFBSSxFQUFFLFVBQVUsQ0FBQyxVQUFVLEVBQUU7Z0NBQzdCLEtBQUssRUFBRSxJQUFJLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxLQUFLO2dDQUMvQixFQUFFLEVBQUUsSUFBSSxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsY0FBYyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLG1CQUFtQjs2QkFDNUYsQ0FBQyxDQUFDO3FCQUNOO29CQUNELE1BQU07YUFDYjtTQUVKO1FBRUQsSUFBSSxDQUFDLGtCQUFrQixFQUFFLENBQUM7SUFDOUIsQ0FBQztJQUVPLGtCQUFrQjtRQUN0QixJQUFJLElBQUksQ0FBQyxlQUFlLElBQUksSUFBSSxDQUFDLGNBQWMsRUFBRTtZQUM3QyxJQUFJLENBQUMsY0FBYyxHQUFHLEtBQUssQ0FBQztTQUMvQjtJQUNMLENBQUM7SUFFTyxzQkFBc0I7UUFDMUIsS0FBSyxJQUFJLFlBQVksSUFBSSxJQUFJLENBQUMsZUFBZSxFQUFFO1lBQzNDLElBQUksSUFBSSxDQUFDLGVBQWUsQ0FBQyxZQUFZLENBQUM7Z0JBQUUsSUFBSSxDQUFDLE1BQU0sQ0FBQyxXQUFXLENBQUMsSUFBSSxDQUFDLGVBQWUsQ0FBQyxZQUFZLENBQUMsQ0FBQyxDQUFDO1NBQ3ZHO1FBRUQsSUFBSSxDQUFDLGFBQWEsR0FBRyxFQUFFLENBQUM7SUFDNUIsQ0FBQztJQUVPLGlCQUFpQjtRQUNyQixJQUFJLENBQUMsU0FBUyxHQUFHLElBQUksQ0FBQyxTQUFTLENBQUMsZ0JBQWdCLEVBQUUsQ0FBQztRQUNuRCxJQUFJLENBQUMsUUFBUSxDQUFDLGVBQWUsQ0FBQyxJQUFJLENBQUMsU0FBUyxFQUFFLElBQUksQ0FBQyxNQUFNLEVBQUUsS0FBSyxDQUFDLENBQUM7UUFFbEUsSUFBSSxDQUFDLFNBQVMsQ0FBQyxNQUFNLENBQUMsT0FBTyxHQUFHLElBQUksQ0FBQyxXQUFXLENBQUMsUUFBUSxFQUFFLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQztRQUN0RSxJQUFJLElBQUksQ0FBQyxTQUFTLENBQUMsTUFBTTtZQUFFLElBQUksQ0FBQyxTQUFTLENBQUMsTUFBTSxDQUFDLE9BQU8sR0FBRyxJQUFJLENBQUMsV0FBVyxDQUFDLFFBQVEsRUFBRSxDQUFDLGFBQWEsRUFBRSxVQUFVLENBQUMsQ0FBQyxDQUFDO1FBRW5ILElBQUksQ0FBQyxjQUFjLEVBQUUsQ0FBQztJQUMxQixDQUFDO0lBRU8sV0FBVyxDQUFDLE9BQWUsRUFBRSxTQUF3QjtRQUN6RCxJQUFJLElBQUksQ0FBQyxTQUFTLENBQUMsT0FBTyxDQUFDLElBQUksT0FBTyxJQUFJLENBQUMsU0FBUyxDQUFDLE9BQU8sQ0FBQyxDQUFDLE9BQU8sS0FBSyxXQUFXLEVBQUU7WUFDbkYsT0FBTyxJQUFJLENBQUMsU0FBUyxDQUFDLE9BQU8sQ0FBQyxDQUFDLE9BQU8sQ0FBQztTQUMxQztRQUVELEtBQUssSUFBSSxDQUFDLEdBQVcsU0FBUyxDQUFDLE1BQU0sR0FBRyxDQUFDLEVBQUUsQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRTtZQUNwRCxJQUFJLElBQUksQ0FBQyxTQUFTLENBQUMsT0FBTyxDQUFDLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksSUFBSSxDQUFDLFNBQVMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLEtBQUssRUFBRSxFQUFFO2dCQUM1RixPQUFPLElBQUksQ0FBQzthQUNmO1NBQ0o7UUFFRCxJQUFJLE9BQU8sS0FBSyxRQUFRLElBQUksSUFBSSxDQUFDLGFBQWEsQ0FBQyxNQUFNLEtBQUssQ0FBQyxFQUFFO1lBQ3pELE9BQU8sS0FBSyxDQUFDO1NBQ2hCO1FBRUQsT0FBTyxLQUFLLENBQUE7SUFDaEIsQ0FBQztJQUVELG9GQUFvRjtJQUM1RSxjQUFjO1FBRWxCLG9EQUFvRDtRQUNwRCxJQUFJLENBQUMsU0FBUyxHQUFHLEVBQUUsQ0FBQztRQUVwQixJQUFJLE9BQU8sSUFBSSxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsS0FBSyxLQUFLLFdBQVcsSUFBSSxJQUFJLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxLQUFLLEVBQUU7WUFDN0UsSUFBSSxDQUFDLFNBQVMsSUFBSSxlQUFlLENBQUM7U0FDckM7UUFFRCxJQUFJLE9BQU8sSUFBSSxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsYUFBYSxLQUFLLFdBQVcsRUFBRTtZQUN6RCxJQUFJLENBQUMsU0FBUyxJQUFJLElBQUksQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLGFBQWEsR0FBRyxHQUFHLENBQUM7U0FDNUQ7UUFFRCxJQUFJLE9BQU8sSUFBSSxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsS0FBSyxLQUFLLFdBQVcsRUFBRTtZQUNqRCxJQUFJLENBQUMsU0FBUyxJQUFJLElBQUksQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQztTQUM5QztJQUNMLENBQUM7OztZQTFiSixTQUFTLFNBQUM7Z0JBQ1AsUUFBUSxFQUFFLFFBQVE7Z0JBQ2xCLCtqSEFBb0M7Z0JBQ3BDOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O29CQStCSTtnQkFDSixhQUFhLEVBQUUsaUJBQWlCLENBQUMsSUFBSTtnQkFDckMsSUFBSSxFQUFFO29CQUNGLE9BQU8sRUFBRSxTQUFTO29CQUNsQiwwQkFBMEIsRUFBRSx5Q0FBeUM7b0JBQ3JFLHFCQUFxQixFQUFFLG9DQUFvQztpQkFDOUQ7Z0JBQ0QsU0FBUyxFQUFFLENBQUMsWUFBWSxFQUFFLFFBQVEsRUFBRSxTQUFTLENBQUM7YUFDakQ7OztZQXBFRyxVQUFVO1lBYUwsZUFBZTtZQUNmLFlBQVk7WUFDWixRQUFRO1lBVmIsaUJBQWlCO1lBbUJaLFNBQVM7Ozt1QkE4RWIsS0FBSztxQkFDTCxLQUFLO21CQUNMLEtBQUs7a0JBQ0wsS0FBSztvQkFFTCxTQUFTLFNBQUMsT0FBTzt5QkFDakIsV0FBVyxTQUFDLGFBQWEiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQge1xyXG4gICAgQ29tcG9uZW50LFxyXG4gICAgVmlld0VuY2Fwc3VsYXRpb24sXHJcbiAgICBJbnB1dCxcclxuICAgIE9uSW5pdCxcclxuICAgIE9uQ2hhbmdlcyxcclxuICAgIFNpbXBsZUNoYW5nZXMsXHJcbiAgICBPbkRlc3Ryb3ksXHJcbiAgICBFbGVtZW50UmVmLFxyXG4gICAgQWZ0ZXJWaWV3SW5pdCxcclxuICAgIFZpZXdDaGlsZCxcclxuICAgIEhvc3RMaXN0ZW5lcixcclxuICAgIEhvc3RCaW5kaW5nLFxyXG4gICAgQ2hhbmdlRGV0ZWN0b3JSZWZcclxufSBmcm9tICdAYW5ndWxhci9jb3JlJztcclxuLy8gaW1wb3J0IHsgU3Vic2NyaXB0aW9uIH0gZnJvbSAncnhqcy9TdWJzY3JpcHRpb24nO1xyXG5pbXBvcnQgeyB0aW1lciB9IGZyb20gJ3J4anMnO1xyXG4vLyBpbXBvcnQgeyBkZWJvdW5jZVRpbWUgfSBmcm9tICdyeGpzL29wZXJhdG9ycyc7XHJcbmltcG9ydCAqIGFzIEwgZnJvbSAnbGVhZmxldCc7XHJcbmltcG9ydCAnbGVhZmxldC5tYXJrZXJjbHVzdGVyJztcclxuaW1wb3J0ICdsZWFmbGV0LmF3ZXNvbWUtbWFya2Vycy9kaXN0L2xlYWZsZXQuYXdlc29tZS1tYXJrZXJzJztcclxuaW1wb3J0IHsgS2RTcGxpdHRlckV2ZW50IH0gZnJvbSAnLi4va2QtYW5ndWxhci1zcGxpdHRlci9pbmRleCc7XHJcbmltcG9ydCB7IEtkRG9tRWxlbVN2YyB9IGZyb20gJy4uL2tkLWNvbW1vbi9pbmRleCc7XHJcbmltcG9ydCB7IEtkTWFwU3ZjLCBJTWFwUG9wdWxhdGVDbHVzdGVyRGF0YSB9IGZyb20gJy4va2QtYW5ndWxhci1tYXAtc3ZjJztcclxuaW1wb3J0IHtcclxuICAgIElNYXBDb25maWcsXHJcbiAgICBJTWFwUG9zaXRpb24sXHJcbiAgICBJTWFwQ2x1c3RlckRhdGEsXHJcbiAgICBJTWFwWm9vbUNvbmZpZyxcclxuICAgIElNYXBBcGksXHJcbiAgICBJTWFwTWFya2VyLFxyXG59IGZyb20gJy4va2QtYW5ndWxhci1tYXAtaW50ZXJmYWNlJztcclxuaW1wb3J0IHsgS2REYXRhU3ZjIH0gZnJvbSAnLi4va2QtY29tbW9uL2luZGV4JztcclxuXHJcbkBDb21wb25lbnQoe1xyXG4gICAgc2VsZWN0b3I6ICdrZC1tYXAnLFxyXG4gICAgdGVtcGxhdGVVcmw6ICcuL2tkLWFuZ3VsYXItbWFwLmh0bWwnLFxyXG4gICAgLyp0ZW1wbGF0ZTogYFxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzPVwiaGVhZGVyLWNvbnRhaW5lclwiPlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cImNoYXJ0LXRpdGxlIGxlZnRcIj57e2NvbmZpZy5sZWdlbmQudGl0bGUudGV4dH19PC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwiY2hhcnQtc3VidGl0bGUgcmlnaHRcIj57e2NvbmZpZy5sZWdlbmQudGl0bGUudGV4dH19PC9kaXY+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8ZGl2ICpuZ0lmPVwiaXNNYXBTaG93blwiIGNsYXNzPVwiY2hhcnQtY29udGFpbmVyXCIgICNteU1hcD5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJsaW5rLXdyYXBwZXJcIiAqbmdJZj1cImlzTGlua1RvR29vZ2xlXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPGEgW2F0dHIuaHJlZl09XCJnb29nbGVMaW5rXCIgdGFyZ2V0PVwiX2JsYW5rXCIgY2xhc3M9XCJnb29nbGUtbGluayBsZWFmbGV0LWJhciBsZWFmbGV0LWNvbnRyb2xcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGltZyBjbGFzcz1cImdvb2dsZS1pbWFnZVwiIFtzcmNdPVwiZ29vZ2xlSW1hZ2VcIj5cclxuICAgICAgICAgICAgICAgICAgICA8L2E+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJsZWdlbmQtY29udGFpbmVyIGNlbnRlclwiICpuZ0lmPVwiY29uZmlnLmxlZ2VuZCAmJiBpc01hcFNob3duXCI+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwibGVnZW5kc1wiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJsZWdlbmQtdGl0bGUtY29udGFpbmVyIHJpZ2h0XCIgKm5nSWY9XCJjb25maWcubGVnZW5kLnRpdGxlLnRleHRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cInRpdGxlXCI+e3tjb25maWcubGVnZW5kLnRpdGxlLnRleHR9fTwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJsZWdlbmRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cImxlZ2VuZC1pdGVtXCIgaWQ9XCJrZGxpLXt7bGVnZW5kSXRlbS5pZH19XCIgKm5nRm9yPVwibGV0IGxlZ2VuZEl0ZW0gb2YgbWFya2Vyc0xlZ2VuZFwiIChjbGljayk9XCJvbkxlZ2VuZENsaWNrKGxlZ2VuZEl0ZW0pXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwibGVnZW5kLW1hcmtlclwiIFtpbm5lckhUTUxdPVwibGVnZW5kSXRlbS5pY29uLm91dGVySFRNTFwiID48L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJsZWdlbmQtbGFiZWxcIj48ZGl2IGNsYXNzPVwibGFiZWwtdGV4dFwiPnt7bGVnZW5kSXRlbS5sYWJlbH19PC9kaXY+PC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8ZGl2ICpuZ0lmPVwiIWlzTWFwU2hvd25cIiBjbGFzcz1cImVycm9yLW1hcFwiPlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cImVycm9yLWljb25cIj48aSBjbGFzcz1cImZhIGZhLW1hcC1vXCI+PC9pPjwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cImVycm9yLW1lc3NhZ2VcIj57e2Vycm9yTWVzc2FnZX19PC9kaXY+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8a2QtcHJvZ3Jlc3Nsb2FkZXIgKm5nSWY9XCJpc0xheWVyTG9hZGluZyAmJiBpc01hcFNob3duXCIgY29uZmlndHlwZT1cInNtYWxsLXNwaW5uZXJcIiBbY29uZmlndmFsdWVdPVwic21hbGxMb2FkZXJWYWx1ZVwiPjwva2QtcHJvZ3Jlc3Nsb2FkZXI+XHJcblxyXG4gICAgYCwqL1xyXG4gICAgZW5jYXBzdWxhdGlvbjogVmlld0VuY2Fwc3VsYXRpb24uTm9uZSxcclxuICAgIGhvc3Q6IHtcclxuICAgICAgICAnY2xhc3MnOiAna2R4LW1hcCcsXHJcbiAgICAgICAgJ1tzdHlsZS5iYWNrZ3JvdW5kLWNvbG9yXSc6ICdtYXBDb25maWcubWFwQXJlYS5zdHlsZS5iYWNrZ3JvdW5kQ29sb3InLFxyXG4gICAgICAgICdbc3R5bGUuZm9udC1mYW1pbHldJzogJ21hcENvbmZpZy5tYXBBcmVhLnN0eWxlLmZvbnRGYW1pbHknXHJcbiAgICB9LFxyXG4gICAgcHJvdmlkZXJzOiBbS2REb21FbGVtU3ZjLCBLZE1hcFN2YywgS2REYXRhU3ZjXVxyXG59KVxyXG5cclxuZXhwb3J0IGNsYXNzIEtkTWFwIGltcGxlbWVudHMgT25Jbml0LCBPbkNoYW5nZXMsIEFmdGVyVmlld0luaXQsIE9uRGVzdHJveSB7XHJcblxyXG4gICAgLy8gcHJpdmF0ZSBzdGF0aWMgbWFwUGluSW1hZ2U6IHN0cmluZyA9ICdkYXRhOmltYWdlL3BuZztiYXNlNjQsaVZCT1J3MEtHZ29BQUFBTlNVaEVVZ0FBQUJrQUFBQXBDQVlBQUFEQWs0TE9BQUFGZ1VsRVFWUjRBYTFYQTVCaldSVE4yb1cxN2QzWWFadHIyOTYySFV6YkROcGpzelcyNG1SdDI4cDQ3djd6cS9iWFp0cnAvbFduWHIzMzdqM25QQ2U4NU5jeXBnU0ZkdWdDcFc1WW9EQU1SYUlNcVJpNmFLcTVFM1lxRFFPM3FBd2pWV3JEOE5jcS9SQnB5a2Q4b1pVYi9rYUp1dG93OHIxYVA5SUkwV21MS0xJc0p5djF3L2txdzlDaDJNWWRCKysxMk9ueGVlL1FNd3ZmNC9Eay9MZnAvaTRueFRYdE9vUTRwVzVBajd3cGljaTFBOWVyZEFOMk9INjR4OE9TUDlqM0Z0M2I3YVdrVGcvRm05MXNpVHJhMGY5b241c1FyOUlOZWpINkNVVVVwYXZqRk5xMUIrT2FkaHhtbmZhOFJmRW1OOFZOQXNRaFBxRjU1eEhrTXp6M2pTbUNoV1U2ZjcvWFpLTkgrOStoQkxPSFlvenVLUVB4eU1QVUtrclgvSzB1V25mRmFKR1MxUVBSdFpzT1B0cjNOc1cwdXloNk5OQ09rVTNZeitiWGJUM0k4RzN4RTVFWExYdENYYmJxd0NPOXpQUVlQUlRaNXZJRFhEN1UrdzdyRkRFb1VVZjdpYkhJUjR5NmJMVlBYcno4SlZaRXFsMTN0cnh3dWUvdURpdmQzZmtXUmJTNi9JQTJiSUQ0dWswVXBGMU44cUxsYkJsWHM0RWU3SExUZlYxajU0QVB2T0RuU2ZPV0JxdEtWdmpnTEt6RjVZZEVrNWV3UmtHbEswaTMzRW9mZmZjN0hUNTZqRDcvNlUrcUgzQ3g3U0JMTm50SDVZSVB2T0RueWZJWFpZUlZEUHFnSHRMczVBQkhEM1l6THVlc3BiN3Q3OUZZMzREak13clZyY1R1d2xUNTVZTVB2T0JuUnJKNFZYVGRObll1ZzV1Y0hMQmpFcHQzMDcwMUEzVHMrSEVhNzN1NmRUM0ZOV3dmbFk4NmVNSFBrK1l1K2k2cHpVcFJyVzdTTkRnNUpIUjRLYXBtTTVXdjJFOFRmY2IxSG9xcUhNSFUrdVdERDd6ZzU0bXo1LzJCU25pemk5VDFEZzRRUVhMVG9HTkNrYjZ0YjFOVStRQWxHcjErK2VBRHJ6aG4vdThRMllaaFFWbFo1K0NBT3RxZmJobWFVQ1MxZXpORlZtMmltRGJQbVBuZzV3bXorZ3doK29IRGNlMGVVdFE2T0dESXlSMHVVaFVzb08zdmZEbW1nT2V6SDBtWk41OXg3TUJpKytXREwxZy9lRWlVM2F2bGlkTzY3MWJrTGZ3Ync1WFYyUDhQem8weWR5NHQyLzBldTMzeFlTT01PRDhoVGY0Q3JCdEdNU29YZlBMY2hYK0owcnVTZVB3M0xaZUswanVQSmJZenJoa0gwaW83QjNrMTY0aGlHdmF3aE9LTUxrclFMeVZwWmc4ckhGVzdFMnVIT0w4ODhJQlBsTloxRlB6c3RTSk02OTRmV3I2UndwdmNKSzYwKzBIQ0lMVEJ6WkxGTmR0QXpKYW9oemU2MFQ4cUJ6eWg1WnVPZzVlN3V3UXBwb2ZFbWYyKytEWXZteVNxR0J1S2FpY0YxYmxRamh1SGR2Q0lNdnA4d2hUVGZaekk3UmxkcHd0U3pMK0YxK3drZFoyVEJPVzJnSUY4OFBCVHpEL2dwZVJFQU1FYnhuSmNhSkhOSHJwemppMGdRQ1M2aGRrRWVZdDlERi8ycVBjRUM4Uk0yOEh3bXIzc2ROeWh0MDBieUF1dDJrM2d1ZldOdGd0T0VPRkdVd2NYV05EYmROYnBnQkd4RXZLa09Rc3hpdkp4MzNpb3cwVnc1UzZTVlRycFZxMTF5c0EyUnA3Z1RmUGZrdGM2emh0WEJCQythZFJMc2hmNnNHMlJmSFBaNUVBYzRzVlo4M3lDTjAwRmsvNGtnZ3U0MFpUdklFbTVnMjRxdFU0S2pCcngvQlRUSDhpZlZBU0FHN2dLcm5XeEpEY1U3eDhYNkVjY3pobTNvNllpY3ZzTFhXZmgzQ2gxVzBrOHgwblhGKzBmRnhndDRwaHo4UXZ5cGl3Q0NGS01xWENucVhFeGpxMTBiZUgrVVVBNytuRzZtZEcvUHUwZjNMZ0ZjR3JsMnMwa05OanBtb0o5bzRCMjlDTU84ZE1UNFE1b3g4dWl0RjZmcXNySk9yOHFud05iUnp2NmhTbkc1d1ArNjRDN2g5bHAzMGhLTnRLZFdqdGRrYnVQQTE5bko3VHozelIvaWJnQVJiaGI0QWxoYXZjQmVibVRIY0ZsMmZ2WUVuVzBveDl4TXhLQlM4YnRKK0tpRWJxOXpBNFJ0aFFYRGhQYTBUOVRFZTY5Z1d1cHdjNnVCVXBocXVYZ2YrL0ZySWp3ZUhRUzQvcGR1TWU1RVJVTUhVZDl4djhaUjk4Q3hrUzRGMm4zRVVyVVoxMEVZTnc3QldtOXgxR2lQc3NpM0dnaUdSREtXUllaZlhsT04rZGZOYk0rR2dJd1lkd0FBQUFBU1VWT1JLNUNZSUk9JztcclxuICAgIC8vIHByaXZhdGUgc3RhdGljIG1hcFBpblNoYWRvd0ltYWdlOiBzdHJpbmcgPSAnZGF0YTppbWFnZS9wbmc7YmFzZTY0LGlWQk9SdzBLR2dvQUFBQU5TVWhFVWdBQUFDa0FBQUFwQ0FRQUFBQUNhY2g5QUFBQ01VbEVRVlI0QWUzU2hZN2pRQkFFMEFvei9mOS9IVE16aGcxenJkS1VySmJkeCtLZDJuRDhWTnVkZnNML1RoLy8vZHlRTjJUSDZmM3kvQkdwQzM3OXJWK1MrcXFldEJPeEltTlFYTDhKQ0FyMlY0aU1RWEhHTkp4ZUNmWlhoU1JCY1FNZnZrT1dVZHRmemxMZ0FFTm1aRGNtbzJUVm10OE9TTTJlWHhCcDNEakhTTUZ1dHFTN1NibWVtekJpUit4cEtDTlVJUmtka2tZeGhBa3lHb0J2eVFGRUpFZWZ3U21tdkJmSnVKNmFLcUtXbkFrdkdaT2FaWFRVZ0ZxWVVMV05TSFVja1p1UjFISUlpbVVFeHV0Unh3ek9MUk9JRzR2S21DS1F0MzY0bUlsaFN5ekFmMW05bEhaSEpacmxBT01NenRSUmlLaW1wL3JwZEpEYzlBd3J5NXhUWkN0ZTdGSHR1Uzh3SmdlWUdyZXgyOHhOVGQwODZEaWs3dlVNc2NRT2E4eTREb0d0Q0NTa0FLbE53cGdOdHBoanJDNk1JSFVrUjZZV3h4czZTYzV4cW4yMjJtbUNSRnpJdDhsRWRLeCtpa0N0ZzkxcVMyV3B3VmZCZWxKQ2lRSnd2eml4Zkk5Y3haUVdnaVNKZWxLbndCRWxLWXRET2IyTUZiaG1VaWdiUmVRQlYwQ2c0K3FNWFN4WFN5R1VuNFViRjhsKzdxZFNHblRDMFhMQ21haElnVUhMaExPaHBWQ3R3NEN6WVh2TFFXUWJKTm14b0NzT0tBeFNnQkpubzc1YXZvbGtSdzhpSUFGY3NkYzAyZTlpeUNkOHRId21lU1NvS1Rvd0lndnNjU0daVU9BN1B1Q041YjJCWDltUU03UzB3WWhNTlU3NHpnc1BCajNIVTd3Z3VBZm54eGpGUUdCRTZwd04rR2pNRTl6SFk3ekdwOHdWeE1TaFlYOU5YdkVXRDNIYndKZjRnaU80Q0ZJUXhYU2NIMS9UTSswNGtrQmlBQUFBQUVsRlRrU3VRbUNDJztcclxuXHJcbiAgICBwdWJsaWMgc21hbGxMb2FkZXJWYWx1ZTogYW55ID0gbnVsbDtcclxuICAgIHB1YmxpYyBpc01hcFNob3duOiBib29sZWFuID0gdHJ1ZTtcclxuICAgIHB1YmxpYyBpc0xheWVyTG9hZGluZzogYm9vbGVhbiA9IHRydWU7XHJcbiAgICBwdWJsaWMgaXNMaW5rVG9Hb29nbGU6IGJvb2xlYW4gPSBmYWxzZTtcclxuICAgIHB1YmxpYyBnb29nbGVMaW5rOiBzdHJpbmcgPSAnJztcclxuICAgIHB1YmxpYyBlcnJvck1lc3NhZ2U6IHN0cmluZyA9ICcnO1xyXG4gICAgcHVibGljIGdvb2dsZUltYWdlOiBzdHJpbmcgPSAnZGF0YTppbWFnZS9wbmc7YmFzZTY0LGlWQk9SdzBLR2dvQUFBQU5TVWhFVWdBQUFESUFBQUF5Q0FZQUFBQWVQNGl4QUFBQUJITkNTVlFJQ0FnSWZBaGtpQUFBQUFsd1NGbHpBQUFPYXdBQURtc0JWUDROQmdBQUFCbDBSVmgwVTI5bWRIZGhjbVVBZDNkM0xtbHVhM05qWVhCbExtOXlaNXZ1UEJvQUFBYXRTVVJCVkdpQjdabGJiQnpWR2NkL1oyWm43TDM0SG15eXU5N2NISWZFamROWU1YVXdSTGFTVXRKQzFZb1FxdzF0S1ZJcHlVUFZjbEZMTHlxUjB6eFVsWUpVS1lJSXFRL2xoVkRvUlMyTmlpRXVJSXBKMGx4TUd5QWJBb250cE5TWDJQRjZ2YmM1ZlhESDhXVm1kdFplSzYzay85UFo3NXp6bmUrMzM1bHZ6cDZGUmYxdlNkem9BQUM2dHpSV2U0VDRFc2h0UURWUUFnd0RsNlNVZjlFVTlmZXJPN3Q2bkh6Y1VKRDNtamNHOFhqMlNuZ0E4RGdNVFFHL2tvYng1TG8zVGx5MkduRERRUDdSMnJoVk1UZ01sT2N3YlVCSXNmT1cxOTk1YldiSERRRjVyM1ZUc3pURXEwREJIS2FQUzZHMHJ1dnNlbnVxMFJFaytNeDlFVVVvandsb2tGSVV6bUhSV2FxS3BiU0RSM3JXRlNjTXA2MlVUVmNNd2NhNnptTlhUSU90cytBejkwVVVsRk5JeWlRQWNoN3JYdGZYdTRjb1RoanpkWE96S21rSHZtVWFiRUVVeEtOQTJVejdFbTh4WDF4MUcrdVhyRVJWRk00TjlmTG5DMTFFci9abFhiMHlsbWJyaFd1T1l5UXdsakh3cVlyamRwSHdqWE10bjlsclZqT0g5SXE2bVpaN1Y5L0J2dHNmSktCNXA5a2YyN1NUWDU3OExiODRmdGd4eUMwWFk2ZzJpWlhBdTdFNFo2Nk5rNUFHQllxZ1B1Q2x6bGVJSWl5UnRCU1pIY0JUQUlvOUIrcE1pQU90ZXdob1h1THBCSC9yK3lldlhqeEpmM3lFak14dyt0L25IU0VBTnY0cmJ0dDNlalRPc1pFeEVuSmkyeVVNeWJHUk1jN0U3T2NJS2JhYWJWY1BYRW1Cbi9ibWJ5SVFuUHdreXU2T3ArZ2Q3UWZBcnhWU1V4cHlCVklaUzF2YXpXeFlxWHQwblBxQXorWWJseEd6WlorUktmckNpaWFLZEI5ajZRUVBkeHlZaEFDSXBjWmRRUUFVcGF3ZjhyaGhrRFNzOTF4S1N1SVp1K0lnS3N5V3E0eXNxMWdHd0tsUG92U05Ea3phVDl6L05KVyswbWxqRDUzNUkrMXZQMmZwWjB3VlZGall2WXFDcmdoTEdFMEl2S3BOUHBBalp0dFZSc3lITFdOa0w1dWFZdi9kZkZ5cVc5b0Y4T21BMTdLdm9jaHVXNEZBdkd1MlhXVWtlclVYZ0EyVkt5a3A4RE9jaUFGdy84djc4U2dlZE5YRGM5dWZJS0I3NlpteTdXYXFNK0xuOWtzeHk3NDZ2eGZKeEVPZk5DUzZJdGdROExMV1ovL3lGMEpPbGtsWEdmblRoMTNFMHdtS2RUOEhXdlpNbHQremd4ZnA3ditRdTVZM0V0QzlTQ1NkbDA3Witua3pFcURmcTFyMkNXQzkzOHV1cW5MYUtzdllWVlhPZXIvWHJ2UUM5RndtOER2emc3VlhvUGllVHowQUxJZUpCenFlVHRKU3ZZRlZwVUYyMUc1aFRYbVlwbUFkanpmdTVPNlZUUUQ4SWZvV3Z6N2JZUXNpQmZnMTJORHJVRklCWFJGWkQ0RlN5aC9lK3RlM3VzelByczg3ejNhL1RKSHU0N3NOOTNLenY1eTJOYTNUK2pzdm5lWUhiejdyNktOS3ovQmdXeEo5V0NIMi9yeU9LYStzZmYzNHdhbUduQTV1QjA3OGhpTVgzcUh0bGxacXk4S2tNbW42WWdNY3VYQ01OM3JQWUVqNzgxaVZudUg1K2dGVytkSWt2NnJ4MGY0a1JtSk81N2RyaHNqc0VUTU9mN1laREI5cU80cWtaUzRyemRSVWlNbG8vcDZoOTFBcWQyZUszTEgyNlBFWFo1bm5GYUVMVlZwQUFCUTFxUGczbCtUa2E2aWhQbWtGQVFzTVVxbG5PR3dCQVJBeklneDgrUW1NcFVGWHZveGdrSjU3N2g2ejYxOHdrR3dRSDR3L1JGb05rR2piQlVxV01GU1Y4YmF2WVhoc2krekNnRGhDeUdWOE1QNFFHVG54Z3pOVHZZeFV5OVpaNDZZcTJib05JMXp0T0NidklFNFFHWDBOOFlwOW9QaW4yUk9mM1k1UmJuVUtBNk5pQ2FsdGQyVmRONjhnMlNCR3kvYmkwVXNJaDZwUjFTbmJSTmRKM2JuZDBtZnljNTlIYWxyV3RmTUc0Z1pDQ2g4QW1xWVRYQnFhQnBOcWFNUW9tVjdGakpKUzBoczN1Vm8vTHlCT0VPOFBydUYwOGpxRXFZS0NRc0toeUhVWVZTWGQxRHh0VEdwemMvWkM4Ri9ORzhRSjRteC9MZC9yYU9mSEx3UTRkMlgyWEUzVHBzR2tHcHZBUENRcUN1bGJiM01keDd4QXNrRTgrdG8rWWtrZnNRVDg5QVVsSzR3c0s4Y0loUUV3d2hGa2lmc1g1cHhCM0VLWWNndVRycWtGSUZPek9xZDQ1Z1NTSzRRcE56Q3NXQWxNdkY5eVVjNGdjNFV3bFEybWF0Tm1ZR0pyNWFLY1FPWUxZY29KcGlBVXB2aEhleEUzM1pSTGFPNUI4Z1ZoeWduRzE3aDU5a3N6aTF5QjVCdkNsUE0yMHdubEFKTVZaS0VnVERuQjZEbkFPSUxZL1NpQy9FQ1l5Z2VNTFVoMVlVWi92bjZBbWdXR01KVU5abWt3UklGSHQ0M1h0dVBuTlZkcnJDQ2lReXY0L3RFbjh3cGhLcGFBOXBjVVByYTQ0eXZVQ3dsWGhXenZHR3hCNG9hWTllOXBkR2c1ajNUOGpPRkU4VnhqemFyaE1makpZV3VZbnZIQnFOMDhXNUJvM1BQd1NFWk1Ycm1jdnhyaGtZNzlDd3BoeW9UNXFQLzYzZGRJY2t4R0IvdDIyODF4dk5BNytNcjJwbHBmK21rOVZiVnFmOWZ1MU5CNElEOS9KTHBVbVU4VjM3bFQweEtleStlamc1ZS8vZmdkWCtuS1BtdFJpMXJVb3Y0ZjlCK0lCTW5WSUpWMm5BQUFBQUJKUlU1RXJrSmdnZz09JztcclxuXHJcbiAgICBwdWJsaWMgbWFya2Vyc0xlZ2VuZDogQXJyYXk8YW55PiA9IFtdO1xyXG5cclxuICAgIHB1YmxpYyBodG1sQ2xhc3M6IHN0cmluZyA9ICcnO1xyXG5cclxuICAgIHB1YmxpYyBtYXBDb25maWc6IElNYXBDb25maWc7XHJcblxyXG4gICAgcHJpdmF0ZSBfbXlNYXA6IEwuTWFwO1xyXG4gICAgcHJpdmF0ZSBfbWFya2VyOiBMLk1hcmtlcjtcclxuICAgIHByaXZhdGUgX2xheWVyOiBMLlRpbGVsYXllcjtcclxuXHJcbiAgICBwcml2YXRlIF9jbHVzdGVyTWFya2VyczogeyBba2V5OiBzdHJpbmddOiBMLk1hcmtlckNsdXN0ZXJHcm91cCB9ID0ge307XHJcblxyXG4gICAgcHJpdmF0ZSBfaXNMYXllckVycm9yOiBib29sZWFuID0gZmFsc2U7XHJcbiAgICBwcml2YXRlIF9pc01hcmtlckxvYWRlZDogYm9vbGVhbiA9IGZhbHNlO1xyXG4gICAgcHJpdmF0ZSBfaXNUaWxlc0xvYWRlZDogYm9vbGVhbiA9IGZhbHNlO1xyXG4gICAgcHJpdmF0ZSBfbGF5ZXJSZWxvYWRUaW1lczogbnVtYmVyID0gMDtcclxuICAgIHByaXZhdGUgX3RpbGVsb2FkSW5kZXg6IG51bWJlciA9IDA7XHJcblxyXG5cclxuICAgIEBJbnB1dCgpIHBvc2l0aW9uOiBJTWFwUG9zaXRpb247XHJcbiAgICBASW5wdXQoKSBjb25maWc6IElNYXBDb25maWc7XHJcbiAgICBASW5wdXQoKSBkYXRhOiBJTWFwQ2x1c3RlckRhdGE7XHJcbiAgICBASW5wdXQoKSBhcGk6IElNYXBBcGk7XHJcblxyXG4gICAgQFZpZXdDaGlsZCgnbXlNYXAnKSBteU1hcDogRWxlbWVudFJlZjtcclxuICAgIEBIb3N0QmluZGluZygnY2xhc3MuZXJyb3InKSBpc01hcEVycm9yOiBib29sZWFuO1xyXG5cclxuICAgIGNvbnN0cnVjdG9yKFxyXG4gICAgICAgIHByaXZhdGUgX2VsZW1lbnRSZWY6IEVsZW1lbnRSZWYsXHJcbiAgICAgICAgX2tkU3BsaXR0ZXJFdmVudDogS2RTcGxpdHRlckV2ZW50LFxyXG4gICAgICAgIHByaXZhdGUgX2tkRG9tRWxlbVN2YzogS2REb21FbGVtU3ZjLFxyXG4gICAgICAgIHByaXZhdGUgX2tkTWFwU3ZjOiBLZE1hcFN2YyxcclxuICAgICAgICBwcml2YXRlIF9jZDogQ2hhbmdlRGV0ZWN0b3JSZWYsXHJcbiAgICAgICAgcHJpdmF0ZSBfZGF0YVN2YzogS2REYXRhU3ZjXHJcbiAgICApIHsgfVxyXG5cclxuICAgIG5nT25Jbml0KCk6IHZvaWQge1xyXG4gICAgICAgIHdpbmRvdy5hZGRFdmVudExpc3RlbmVyKCdyZXNpemUnLCB0aGlzLl9yZXNpemVNYXApO1xyXG5cclxuICAgICAgICBpZiAodHlwZW9mIHRoaXMuY29uZmlnLmlkID09PSAndW5kZWZpbmVkJykge1xyXG4gICAgICAgICAgICB0aGlzLmNvbmZpZy5pZCA9ICdrZHgtbWFwLTAxJztcclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgbmdPbkNoYW5nZXMoX3NpbXBsZUNoYW5nZXM6IFNpbXBsZUNoYW5nZXMpOiB2b2lkIHtcclxuICAgICAgICBpZiAoX3NpbXBsZUNoYW5nZXMuaGFzT3duUHJvcGVydHkoJ2FwaScpKSB7XHJcbiAgICAgICAgICAgIHRoaXMuX2luaXRBcGkoKTtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIGlmIChfc2ltcGxlQ2hhbmdlcy5oYXNPd25Qcm9wZXJ0eSgncG9zaXRpb24nKSkge1xyXG4gICAgICAgICAgICB0aGlzLl92YWxpZGF0ZUxhdExuZyhfc2ltcGxlQ2hhbmdlcy5wb3NpdGlvbi5jdXJyZW50VmFsdWUpO1xyXG5cclxuICAgICAgICAgICAgaWYgKCFfc2ltcGxlQ2hhbmdlc1sncG9zaXRpb24nXS5maXJzdENoYW5nZSAmJiB0aGlzLmlzTWFwU2hvd24pIHtcclxuXHJcbiAgICAgICAgICAgICAgICBpZiAodHlwZW9mIHRoaXMuX215TWFwID09PSAndW5kZWZpbmVkJykge1xyXG4gICAgICAgICAgICAgICAgICAgIHRpbWVyKDIwMCkuc3Vic2NyaWJlKCgpOiB2b2lkID0+IHsgdGhpcy5fcmVpbml0TWFwKCk7IH0pO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgZWxzZSB0aGlzLl9teU1hcC5wYW5Ubyh0aGlzLnBvc2l0aW9uKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuXHJcblxyXG4gICAgICAgIGlmIChfc2ltcGxlQ2hhbmdlcy5oYXNPd25Qcm9wZXJ0eSgnY29uZmlnJykpIHtcclxuICAgICAgICAgICAgdGhpcy5lcnJvck1lc3NhZ2UgPSBfc2ltcGxlQ2hhbmdlcy5jb25maWcuY3VycmVudFZhbHVlLmVycm9yTWVzc2FnZSB8fCAnSW52YWxpZCBsYXRpdHVkZS9sb25naXR1ZGUgdmFsdWUnO1xyXG5cclxuICAgICAgICAgICAgaWYgKF9zaW1wbGVDaGFuZ2VzLmhhc093blByb3BlcnR5KCdwb3NpdGlvbicpKSB7XHJcbiAgICAgICAgICAgICAgICBpZiAoX3NpbXBsZUNoYW5nZXMuY29uZmlnLmN1cnJlbnRWYWx1ZS5nb29nbGVMaW5rICYmIF9zaW1wbGVDaGFuZ2VzLmNvbmZpZy5jdXJyZW50VmFsdWUuZ29vZ2xlTGluay5kaXNwbGF5ICYmIHRoaXMuaXNNYXBTaG93bikge1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuX3NldEdvb2dsZUxpbmsoX3NpbXBsZUNoYW5nZXMucG9zaXRpb24uY3VycmVudFZhbHVlKTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBpZiAoIV9zaW1wbGVDaGFuZ2VzWydjb25maWcnXS5maXJzdENoYW5nZSkge1xyXG4gICAgICAgICAgICAgICAgaWYgKHRoaXMuY29uZmlnLnpvb20pIHtcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLl9jaGVja1pvb21Db25maWcodGhpcy5jb25maWcuem9vbSk7XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIGlmICh0aGlzLmNvbmZpZy56b29tLnZhbHVlKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGlmICh0eXBlb2YgdGhpcy5fbXlNYXAgIT09ICd1bmRlZmluZWQnKSB0aGlzLl9teU1hcC5zZXRab29tKHRoaXMuY29uZmlnLnpvb20udmFsdWUpO1xyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgICAgICBpZiAodGhpcy5jb25maWcuYXR0cmlidXRpb24pIHRoaXMuX3JlbW92ZURlZmF1bHRBdHRyaWJ1dGlvbih0aGlzLmNvbmZpZy5hdHRyaWJ1dGlvbik7XHJcblxyXG4gICAgICAgICAgICAgICAgaWYgKHRoaXMuY29uZmlnLnR5cGUgIT09ICdiYXNpYycpIHtcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLl9yZW1vdmVBbGxNYXJrZXJMYXllcnMoKTtcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLl9zZXRNYXJrZXJzKCk7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgIHRoaXMuX3NldERlZmF1bHRDb25maWcoKTtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIGlmIChfc2ltcGxlQ2hhbmdlcy5oYXNPd25Qcm9wZXJ0eSgnZGF0YScpICYmICFfc2ltcGxlQ2hhbmdlc1snZGF0YSddLmZpcnN0Q2hhbmdlICYmIHRoaXMuY29uZmlnLnR5cGUgIT09ICdiYXNpYycpIHtcclxuICAgICAgICAgICAgdGhpcy5fcmVtb3ZlQWxsTWFya2VyTGF5ZXJzKCk7XHJcbiAgICAgICAgICAgIHRoaXMuX3NldE1hcmtlcnMoKTtcclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgbmdBZnRlclZpZXdJbml0KCk6IHZvaWQge1xyXG4gICAgICAgIGlmICh0aGlzLmlzTWFwU2hvd24pIHtcclxuICAgICAgICAgICAgdGhpcy5faW5pdE1hcCgpO1xyXG4gICAgICAgICAgICB0aGlzLl9jZC5kZXRlY3RDaGFuZ2VzKCk7XHJcblxyXG4gICAgICAgICAgICB0aGlzLl9yZXNpemVNYXAoKTtcclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgbmdPbkRlc3Ryb3koKTogdm9pZCB7XHJcbiAgICAgICAgd2luZG93LnJlbW92ZUV2ZW50TGlzdGVuZXIoJ3Jlc2l6ZScsIHRoaXMuX3Jlc2l6ZU1hcCk7XHJcbiAgICB9XHJcblxyXG4gICAgcHVibGljIG9uTGVnZW5kQ2xpY2soX2xlZ2VuZEl0ZW06IGFueSkge1xyXG4gICAgICAgIGxldCBsZWdlbmRJdGVtTWFya2VyOiBIVE1MRWxlbWVudCA9IHRoaXMuX2VsZW1lbnRSZWYubmF0aXZlRWxlbWVudC5xdWVyeVNlbGVjdG9yKCcja2RsaS0nICsgX2xlZ2VuZEl0ZW0uaWQgKyAnIC5hd2Vzb21lLW1hcmtlcicpO1xyXG4gICAgICAgIGxldCBsZWdlbmRJdGVtTGFiZWw6IEhUTUxFbGVtZW50ID0gdGhpcy5fZWxlbWVudFJlZi5uYXRpdmVFbGVtZW50LnF1ZXJ5U2VsZWN0b3IoJyNrZGxpLScgKyBfbGVnZW5kSXRlbS5pZCArICcgLmtkeC1sZWdlbmQtbGFiZWwnKTtcclxuICAgICAgICBsZXQgc2VsZWN0ZWRNYXJrZXJHcm91cDogTC5NYXJrZXJDbHVzdGVyR3JvdXAgfCBMLm1hcmtlcjtcclxuXHJcbiAgICAgICAgc3dpdGNoICh0aGlzLmNvbmZpZy50eXBlKSB7XHJcbiAgICAgICAgICAgIGNhc2UgJ2NsdXN0ZXInOlxyXG4gICAgICAgICAgICBjYXNlICdncm91cC1jbHVzdGVyJzpcclxuICAgICAgICAgICAgICAgIHNlbGVjdGVkTWFya2VyR3JvdXAgPSB0aGlzLl9jbHVzdGVyTWFya2Vyc1tfbGVnZW5kSXRlbS5pZF07XHJcbiAgICAgICAgICAgICAgICBicmVhaztcclxuICAgICAgICAgICAgZGVmYXVsdDpcclxuICAgICAgICAgICAgICAgIHNlbGVjdGVkTWFya2VyR3JvdXAgPSB0aGlzLl9tYXJrZXI7XHJcbiAgICAgICAgICAgICAgICBicmVhaztcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIGlmICh0aGlzLl9teU1hcC5oYXNMYXllcihzZWxlY3RlZE1hcmtlckdyb3VwKSkge1xyXG4gICAgICAgICAgICB0aGlzLl9teU1hcC5yZW1vdmVMYXllcihzZWxlY3RlZE1hcmtlckdyb3VwKTtcclxuICAgICAgICAgICAgdGhpcy5fa2REb21FbGVtU3ZjLmFkZENsYXNzKGxlZ2VuZEl0ZW1NYXJrZXIsICdhd2Vzb21lLW1hcmtlci1pY29uLWxpZ2h0Z3JheScpO1xyXG4gICAgICAgICAgICB0aGlzLl9rZERvbUVsZW1TdmMuYWRkQ2xhc3MobGVnZW5kSXRlbUxhYmVsLCAna2R4LWxhYmVsLWxpZ2h0Z3JheScpO1xyXG4gICAgICAgIH1cclxuICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgdGhpcy5fbXlNYXAuYWRkTGF5ZXIoc2VsZWN0ZWRNYXJrZXJHcm91cCk7XHJcbiAgICAgICAgICAgIHRoaXMuX2tkRG9tRWxlbVN2Yy5yZW1vdmVDbGFzcyhsZWdlbmRJdGVtTWFya2VyLCAnYXdlc29tZS1tYXJrZXItaWNvbi1saWdodGdyYXknKTtcclxuICAgICAgICAgICAgdGhpcy5fa2REb21FbGVtU3ZjLnJlbW92ZUNsYXNzKGxlZ2VuZEl0ZW1MYWJlbCwgJ2tkeC1sYWJlbC1saWdodGdyYXknKTtcclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfdmFsaWRhdGVMYXRMbmcoX3Bvc2l0aW9uOiBJTWFwUG9zaXRpb24pOiB2b2lkIHtcclxuICAgICAgICBpZiAoIV9wb3NpdGlvbikge1xyXG4gICAgICAgICAgICB0aGlzLmlzTWFwU2hvd24gPSBmYWxzZTtcclxuICAgICAgICAgICAgdGhpcy5pc01hcEVycm9yID0gIXRoaXMuaXNNYXBTaG93bjtcclxuICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICBsZXQgX2xhdDogbnVtYmVyID0gX3Bvc2l0aW9uLmxhdDtcclxuICAgICAgICAgICAgbGV0IF9sbmc6IG51bWJlciA9IF9wb3NpdGlvbi5sbmc7XHJcbiAgICAgICAgICAgIHRoaXMuaXNNYXBTaG93biA9ICh0eXBlb2YgX2xhdCA9PT0gJ3VuZGVmaW5lZCcpIHx8ICh0eXBlb2YgX2xuZyA9PT0gJ3VuZGVmaW5lZCcpIHx8IChfbG5nIDwgLTE4MCB8fCBfbG5nID4gMTgwKSB8fCAoX2xhdCA8IC05MCB8fCBfbGF0ID4gOTApID8gZmFsc2UgOiB0cnVlO1xyXG4gICAgICAgICAgICB0aGlzLmlzTWFwRXJyb3IgPSAhdGhpcy5pc01hcFNob3duO1xyXG4gICAgICAgIH1cclxuICAgICAgICBpZiAoIXRoaXMuaXNNYXBTaG93biAmJiB0aGlzLl9teU1hcCkge1xyXG4gICAgICAgICAgICBkZWxldGUgdGhpcy5fbXlNYXA7XHJcbiAgICAgICAgICAgIGRlbGV0ZSB0aGlzLl9sYXllcjtcclxuICAgICAgICAgICAgZGVsZXRlIHRoaXMuX21hcmtlcjtcclxuICAgICAgICAgICAgZGVsZXRlIHRoaXMuX2NsdXN0ZXJNYXJrZXJzO1xyXG4gICAgICAgICAgICBkZWxldGUgdGhpcy5tYXJrZXJzTGVnZW5kO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF9pbml0TWFwKCk6IHZvaWQge1xyXG5cclxuICAgICAgICB0aGlzLl9teU1hcCA9IEwubWFwKHRoaXMubXlNYXAubmF0aXZlRWxlbWVudCwge1xyXG4gICAgICAgICAgICBjZW50ZXI6IHRoaXMucG9zaXRpb24sXHJcbiAgICAgICAgICAgIHpvb206ICh0aGlzLmNvbmZpZy56b29tICYmIHRoaXMuY29uZmlnLnpvb20udmFsdWUpIHx8IDE0LFxyXG4gICAgICAgIH0pO1xyXG5cclxuICAgICAgICBpZiAodGhpcy5jb25maWcuem9vbSkgdGhpcy5fY2hlY2tab29tQ29uZmlnKHRoaXMuY29uZmlnLnpvb20pO1xyXG5cclxuICAgICAgICB0aGlzLl9zZXRMYXllcigpO1xyXG4gICAgICAgIHRoaXMuX3NldE1hcmtlcnMoKTtcclxuXHJcbiAgICAgICAgdGhpcy5fcmVtb3ZlRGVmYXVsdEF0dHJpYnV0aW9uKHRoaXMuY29uZmlnLmF0dHJpYnV0aW9uKTtcclxuICAgICAgICBpZiAodGhpcy5jb25maWcuZ29vZ2xlTGluayAmJiB0aGlzLmNvbmZpZy5nb29nbGVMaW5rLmRpc3BsYXkgJiYgdGhpcy5jb25maWcudHlwZSA9PT0gJ2Jhc2ljJykgdGhpcy5fc2V0TGlua1N0eWxlKHRoaXMuY29uZmlnLnpvb20sIHRoaXMuY29uZmlnLmdvb2dsZUxpbmsucG9zaXRpb24pO1xyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX3JlaW5pdE1hcCgpOiB2b2lkIHtcclxuICAgICAgICB0aW1lcig1MCkuc3Vic2NyaWJlKCgpOiB2b2lkID0+IHtcclxuICAgICAgICAgICAgaWYgKHR5cGVvZiB0aGlzLm15TWFwID09PSAndW5kZWZpbmVkJykgdGhpcy5fcmVpbml0TWFwKCk7XHJcbiAgICAgICAgICAgIGVsc2UgdGhpcy5faW5pdE1hcCgpO1xyXG4gICAgICAgIH0pO1xyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX2luaXRBcGkoKTogdm9pZCB7XHJcbiAgICAgICAgaWYgKHR5cGVvZiB0aGlzLmFwaSAhPT0gJ3VuZGVmaW5lZCcgJiYgT2JqZWN0LmtleXModGhpcy5hcGkpLmxlbmd0aCA9PT0gMCkge1xyXG4gICAgICAgICAgICB0aGlzLmFwaS5yZXNpemVNYXAgPSAoKTogdm9pZCA9PiB0aGlzLl9yZXNpemVNYXAoKTtcclxuICAgICAgICAgICAgdGhpcy5hcGkuZ2V0Wm9vbSA9ICgpOiBudW1iZXIgPT4gdGhpcy5fbXlNYXAuZ2V0Wm9vbSgpO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF9jaGVja1pvb21Db25maWcoX2NvbmZpZzogSU1hcFpvb21Db25maWcpOiB2b2lkIHtcclxuICAgICAgICBpZiAodHlwZW9mIHRoaXMuX215TWFwICE9PSAndW5kZWZpbmVkJykge1xyXG4gICAgICAgICAgICBfY29uZmlnLmlzWm9vbUJ1dHRvbiA/IHRoaXMuX215TWFwLmFkZENvbnRyb2wodGhpcy5fbXlNYXAuem9vbUNvbnRyb2wpIDogdGhpcy5fbXlNYXAucmVtb3ZlQ29udHJvbCh0aGlzLl9teU1hcC56b29tQ29udHJvbCk7XHJcbiAgICAgICAgICAgIF9jb25maWcuaXNTY3JvbGxab29tID8gdGhpcy5fbXlNYXAuc2Nyb2xsV2hlZWxab29tLmVuYWJsZSgpIDogdGhpcy5fbXlNYXAuc2Nyb2xsV2hlZWxab29tLmRpc2FibGUoKTtcclxuICAgICAgICAgICAgX2NvbmZpZy5pc1RvdWNoWm9vbSA/IHRoaXMuX215TWFwLnRvdWNoWm9vbS5lbmFibGUoKSA6IHRoaXMuX215TWFwLnRvdWNoWm9vbS5kaXNhYmxlKCk7XHJcbiAgICAgICAgICAgIF9jb25maWcuaXNEb3VibGVDbGlja1pvb20gPyB0aGlzLl9teU1hcC5kb3VibGVDbGlja1pvb20uZW5hYmxlKCkgOiB0aGlzLl9teU1hcC5kb3VibGVDbGlja1pvb20uZGlzYWJsZSgpO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF9zZXRMYXllcigpOiB2b2lkIHtcclxuICAgICAgICBpZiAodGhpcy5fbGF5ZXIpIHRoaXMuX2xheWVyLnJlbW92ZSgpO1xyXG4gICAgICAgIHRoaXMuX2lzTGF5ZXJFcnJvciA9IGZhbHNlO1xyXG4gICAgICAgIHRoaXMuaXNMYXllckxvYWRpbmcgPSB0cnVlO1xyXG4gICAgICAgIHRoaXMuX2xheWVyID0gTC50aWxlTGF5ZXIoJ2h0dHBzOi8ve3N9LnRpbGUub3BlbnN0cmVldG1hcC5vcmcve3p9L3t4fS97eX0ucG5nJywge1xyXG4gICAgICAgICAgICBhdHRyaWJ1dGlvbjogJyZjb3B5OyA8YSBocmVmPVwiaHR0cDovL3d3dy5vcGVuc3RyZWV0bWFwLm9yZy9jb3B5cmlnaHRcIj5PcGVuU3RyZWV0TWFwPC9hPicsXHJcbiAgICAgICAgICAgIG1heFpvb206IDE4LFxyXG4gICAgICAgIH0pO1xyXG4gICAgICAgIHRoaXMuX2xheWVyLmFkZFRvKHRoaXMuX215TWFwKTtcclxuICAgICAgICB0aGlzLl9hdHRhY2hUaWxlTGlzdGVuZXIoKTtcclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF9yZW1vdmVEZWZhdWx0QXR0cmlidXRpb24oX2F0dHJpYnV0aW9uOiBzdHJpbmcpOiB2b2lkIHtcclxuICAgICAgICBsZXQgYXR0cmlidXRpb25FbGVtZW50OiBFbGVtZW50ID0gdGhpcy5fZWxlbWVudFJlZi5uYXRpdmVFbGVtZW50LnF1ZXJ5U2VsZWN0b3IoJy5sZWFmbGV0LWNvbnRyb2wtYXR0cmlidXRpb24nKTtcclxuICAgICAgICBpZiAoYXR0cmlidXRpb25FbGVtZW50ICE9PSBudWxsKSB7XHJcbiAgICAgICAgICAgIGxldCBuZXdBdHRyaWJ1dGlvbkVsZW1lbnQ6IEhUTUxFbGVtZW50ID0gdGhpcy5fa2REb21FbGVtU3ZjLmNyZWF0ZUVsZW1lbnQoYXR0cmlidXRpb25FbGVtZW50LCAnY3VzdG9tLWF0dHJpYnV0aW9uJyk7XHJcbiAgICAgICAgICAgIG5ld0F0dHJpYnV0aW9uRWxlbWVudC5pbm5lclRleHQgPSBfYXR0cmlidXRpb24gfHwgJ09wZW5FTUlTJztcclxuICAgICAgICAgICAgYXR0cmlidXRpb25FbGVtZW50LnJlcGxhY2VDaGlsZChuZXdBdHRyaWJ1dGlvbkVsZW1lbnQsIGF0dHJpYnV0aW9uRWxlbWVudC5maXJzdENoaWxkKTtcclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfYXR0YWNoVGlsZUxpc3RlbmVyKCk6IHZvaWQge1xyXG4gICAgICAgIC8qIENoZWNrcyBldmVyeSB0aWxlLiBPbmx5IGNhbGxlZCB3aGVuIHNvbWUgdGlsZSBsb2FkIGhhcyBmYWlsZWQuICovXHJcbiAgICAgICAgdGhpcy5fbGF5ZXIub24oJ3RpbGVlcnJvcicsIChlcnJvcik6IHZvaWQgPT4ge1xyXG4gICAgICAgICAgICAvLyBvbmx5IGV4ZWN1dGUgdGhlIGZvbGxvd2luZyBmb3IgdGhlIGZpcnN0IHRpbGUgZXJyb3JcclxuICAgICAgICAgICAgaWYgKCF0aGlzLl9pc0xheWVyRXJyb3IpIHtcclxuICAgICAgICAgICAgICAgIHRoaXMuX2lzTGF5ZXJFcnJvciA9IHRydWU7XHJcbiAgICAgICAgICAgICAgICB0aGlzLl9sYXllclJlbG9hZFRpbWVzKys7XHJcbiAgICAgICAgICAgICAgICBpZiAodGhpcy5fbGF5ZXJSZWxvYWRUaW1lcyA8IDUgfHwgdGhpcy5fbGF5ZXJSZWxvYWRUaW1lcyA9PT0gNSkge1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuX3NldExheWVyKCk7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICBpZiAodGhpcy5fbGF5ZXJSZWxvYWRUaW1lcyA+IDUpIHtcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLmlzTWFwU2hvd24gPSBmYWxzZTtcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLmVycm9yTWVzc2FnZSA9ICdNYXggcmV0cnkgcmVhY2hlZC4gTWFwIGNhbm5vdCBiZSBsb2FkZWQgbm93LiBQbGVhc2UgY2hlY2sgeW91ciBpbnRlcm5ldCBjb25uZWN0aW9uIG9yIHRyeSBhZ2FpbiBsYXRlci4nO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfSk7XHJcblxyXG4gICAgICAgIC8qIENoZWNrcyBldmVyeSB0aWxlLiBPbmx5IGNhbGxlZCB3aGVuIGVhY2ggdGlsZSBsb2FkIGlzIHN1Y2Nlc3NmdWwuICovXHJcbiAgICAgICAgdGhpcy5fbGF5ZXIub24oJ3RpbGVsb2FkJywgKCk6IHZvaWQgPT4ge1xyXG4gICAgICAgICAgICB0aGlzLl90aWxlbG9hZEluZGV4Kys7XHJcbiAgICAgICAgICAgIGlmICh0aGlzLmlzTGF5ZXJMb2FkaW5nICYmIHRoaXMuX3RpbGVsb2FkSW5kZXggPT09IE9iamVjdC5rZXlzKHRoaXMuX2xheWVyLl90aWxlcykubGVuZ3RoKSB7XHJcbiAgICAgICAgICAgICAgICAvLyBvbmx5IHN0b3AgcHJvZ3Jlc3MgbG9hZGVyIHdoZW4gbGFzdCB0aWxlIGxvYWRlZCBzdWNjZXNzZnVsbHlcclxuICAgICAgICAgICAgICAgIC8vIHRoaXMuaXNMYXllckxvYWRpbmcgPSBmYWxzZTtcclxuICAgICAgICAgICAgICAgIHRoaXMuX2lzVGlsZXNMb2FkZWQgPSB0cnVlO1xyXG4gICAgICAgICAgICAgICAgdGhpcy5faGlkZUxvYWRpbmdTY3JlZW4oKTtcclxuICAgICAgICAgICAgICAgIC8vIHJlc2V0IGNvdW50ZXJzXHJcbiAgICAgICAgICAgICAgICB0aGlzLl9sYXllclJlbG9hZFRpbWVzID0gMDtcclxuICAgICAgICAgICAgICAgIHRoaXMuX3RpbGVsb2FkSW5kZXggPSAwO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfSk7XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfcmVzaXplTWFwKCk6IHZvaWQge1xyXG4gICAgICAgIGlmICh0aGlzLmlzTWFwU2hvd24pIHtcclxuICAgICAgICAgICAgdGltZXIoKS5zdWJzY3JpYmUoKCk6IHZvaWQgPT4ge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5fbXlNYXAuaW52YWxpZGF0ZVNpemUoe30pO1xyXG4gICAgICAgICAgICB9KTtcclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfc2V0R29vZ2xlTGluayhfcG9zaXRpb246IElNYXBQb3NpdGlvbik6IHZvaWQge1xyXG4gICAgICAgIGlmICh0aGlzLmNvbmZpZy50eXBlID09PSAnYmFzaWMnKSB7XHJcbiAgICAgICAgICAgIHRoaXMuaXNMaW5rVG9Hb29nbGUgPSB0cnVlO1xyXG4gICAgICAgICAgICB0aGlzLmdvb2dsZUxpbmsgPSAnaHR0cHM6Ly93d3cuZ29vZ2xlLmNvbS9tYXBzLz9xPScgKyBfcG9zaXRpb24ubGF0LnRvU3RyaW5nKCkgKyAnLCcgKyBfcG9zaXRpb24ubG5nLnRvU3RyaW5nKCk7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICB0aGlzLmlzTGlua1RvR29vZ2xlID0gZmFsc2U7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX3NldExpbmtTdHlsZShfem9vbUNvbmZpZzogSU1hcFpvb21Db25maWcsIF9saW5rUG9zaXRpb246IHN0cmluZyk6IHZvaWQge1xyXG4gICAgICAgIGxldCBsaW5rRWxlbWVudDogSFRNTEVsZW1lbnQgPSB0aGlzLl9lbGVtZW50UmVmLm5hdGl2ZUVsZW1lbnQucXVlcnlTZWxlY3RvcignLmtkeC1tYXAgLmxpbmstd3JhcHBlcicpO1xyXG4gICAgICAgIHN3aXRjaCAoX2xpbmtQb3NpdGlvbikge1xyXG4gICAgICAgICAgICBjYXNlICd0b3AtbGVmdCc6XHJcbiAgICAgICAgICAgIGRlZmF1bHQ6XHJcbiAgICAgICAgICAgICAgICAvLyBvbmx5IHdoZW4gWm9vbSBCdXR0b25zIGFyZSByZW1vdmVkIHRoZW4gd2UgcHV0IGdvb2dsZUxpbmsgYXQgdGhlIHBvc2l0aW9uIG9mIHRoZSBab29tIEJ1dHRvbnNcclxuICAgICAgICAgICAgICAgIGxldCBuZXdDbGFzczogc3RyaW5nID0gX3pvb21Db25maWcgJiYgX3pvb21Db25maWcuaXNab29tQnV0dG9uID09PSBmYWxzZSA/ICcnIDogJyBiZWxvdy16b29tJztcclxuICAgICAgICAgICAgICAgIHRoaXMuX2tkRG9tRWxlbVN2Yy5hZGRDbGFzcyhsaW5rRWxlbWVudCwgJ2xlYWZsZXQtdG9wIGxlYWZsZXQtbGVmdCcgKyBuZXdDbGFzcyk7XHJcbiAgICAgICAgICAgICAgICBicmVhaztcclxuICAgICAgICAgICAgY2FzZSAndG9wLXJpZ2h0JzpcclxuICAgICAgICAgICAgICAgIHRoaXMuX2tkRG9tRWxlbVN2Yy5hZGRDbGFzcyhsaW5rRWxlbWVudCwgJ2xlYWZsZXQtdG9wIGxlYWZsZXQtcmlnaHQnKTtcclxuICAgICAgICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgICAgICBjYXNlICdib3R0b20tbGVmdCc6XHJcbiAgICAgICAgICAgICAgICB0aGlzLl9rZERvbUVsZW1TdmMuYWRkQ2xhc3MobGlua0VsZW1lbnQsICdsZWFmbGV0LWJvdHRvbSBsZWFmbGV0LWxlZnQnKTtcclxuICAgICAgICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgICAgICBjYXNlICdib3R0b20tcmlnaHQnOlxyXG4gICAgICAgICAgICAgICAgdGhpcy5fa2REb21FbGVtU3ZjLmFkZENsYXNzKGxpbmtFbGVtZW50LCAnbGVhZmxldC1ib3R0b20gbGVhZmxldC1yaWdodCBhYm92ZS1hdHRyaWJ1dGlvbicpO1xyXG4gICAgICAgICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX3NldE1hcmtlcnMoKTogdm9pZCB7XHJcbiAgICAgICAgaWYgKHR5cGVvZiB0aGlzLl9teU1hcCAhPT0gJ3VuZGVmaW5lZCcpIHtcclxuICAgICAgICAgICAgc3dpdGNoICh0aGlzLmNvbmZpZy50eXBlKSB7XHJcbiAgICAgICAgICAgICAgICBjYXNlICdjbHVzdGVyJzpcclxuICAgICAgICAgICAgICAgIGNhc2UgJ2dyb3VwLWNsdXN0ZXInOlxyXG4gICAgICAgICAgICAgICAgICAgIGlmICh0eXBlb2YgdGhpcy5kYXRhICE9PSAndW5kZWZpbmVkJyAmJiBPYmplY3Qua2V5cyh0aGlzLmRhdGEpLmxlbmd0aCAhPT0gMCkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBsZXQgY2x1c3RlckRhdGE6IElNYXBQb3B1bGF0ZUNsdXN0ZXJEYXRhID0gdGhpcy5fa2RNYXBTdmMucG9wdWxhdGVNYXJrZXJzKHRoaXMuZGF0YSwgdGhpcy5fbXlNYXAsIHRoaXMuY29uZmlnLnR5cGUpO1xyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5tYXJrZXJzTGVnZW5kID0gY2x1c3RlckRhdGEubWFya2Vyc0xlZ2VuZDtcclxuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5fY2x1c3Rlck1hcmtlcnMgPSBjbHVzdGVyRGF0YS5jbHVzdGVyTWFya2VycztcclxuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5faXNNYXJrZXJMb2FkZWQgPSB0cnVlO1xyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICBicmVhaztcclxuICAgICAgICAgICAgICAgIGRlZmF1bHQ6XHJcbiAgICAgICAgICAgICAgICAgICAgbGV0IGRlZmF1bHRJY29uOiBJTWFwTWFya2VyID0ge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBtYXJrZXJDb2xvcjogJ3B1cnBsZScsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHRpdGxlOiB0aGlzLmNvbmZpZy5tYXJrZXIudGl0bGVcclxuICAgICAgICAgICAgICAgICAgICB9O1xyXG4gICAgICAgICAgICAgICAgICAgIGxldCBpY29uTWFya2VyOiBMLkljb24gPSB0aGlzLl9rZE1hcFN2Yy5zZXRJY29uKGRlZmF1bHRJY29uKTtcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLl9tYXJrZXIgPSBMLm1hcmtlcih0aGlzLnBvc2l0aW9uLCB7IGljb246IGljb25NYXJrZXIgfSkuYWRkVG8odGhpcy5fbXlNYXApO1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuX2lzTWFya2VyTG9hZGVkID0gdHJ1ZTtcclxuICAgICAgICAgICAgICAgICAgICBpZiAodGhpcy5jb25maWcuaGFzT3duUHJvcGVydHkoJ2NvbnRlbnQnKSkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLl9tYXJrZXIuYmluZFBvcHVwKHRoaXMuY29uZmlnLmNvbnRlbnQpO1xyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKHRoaXMuY29uZmlnLmhhc093blByb3BlcnR5KCdsZWdlbmQnKSkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLm1hcmtlcnNMZWdlbmQgPSBbe1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaWNvbjogaWNvbk1hcmtlci5jcmVhdGVJY29uKCksXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBsYWJlbDogdGhpcy5jb25maWcubWFya2VyLnRpdGxlLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaWQ6IHRoaXMuY29uZmlnLm1hcmtlci5oYXNPd25Qcm9wZXJ0eSgnaWQnKSA/IHRoaXMuY29uZmlnLm1hcmtlci5pZCA6ICdrZHgtc2luZ2xlLW1hcmtlcidcclxuICAgICAgICAgICAgICAgICAgICAgICAgfV07XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgICAgICB9XHJcblxyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgdGhpcy5faGlkZUxvYWRpbmdTY3JlZW4oKTtcclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF9oaWRlTG9hZGluZ1NjcmVlbigpOiB2b2lkIHtcclxuICAgICAgICBpZiAodGhpcy5faXNNYXJrZXJMb2FkZWQgJiYgdGhpcy5faXNUaWxlc0xvYWRlZCkge1xyXG4gICAgICAgICAgICB0aGlzLmlzTGF5ZXJMb2FkaW5nID0gZmFsc2U7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX3JlbW92ZUFsbE1hcmtlckxheWVycygpOiB2b2lkIHtcclxuICAgICAgICBmb3IgKGxldCBsZWdlbmRJdGVtSWQgaW4gdGhpcy5fY2x1c3Rlck1hcmtlcnMpIHtcclxuICAgICAgICAgICAgaWYgKHRoaXMuX2NsdXN0ZXJNYXJrZXJzW2xlZ2VuZEl0ZW1JZF0pIHRoaXMuX215TWFwLnJlbW92ZUxheWVyKHRoaXMuX2NsdXN0ZXJNYXJrZXJzW2xlZ2VuZEl0ZW1JZF0pO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgdGhpcy5tYXJrZXJzTGVnZW5kID0gW107XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfc2V0RGVmYXVsdENvbmZpZygpOiB2b2lkIHtcclxuICAgICAgICB0aGlzLm1hcENvbmZpZyA9IHRoaXMuX2tkTWFwU3ZjLmdldERlZmF1bHRDb25maWcoKTtcclxuICAgICAgICB0aGlzLl9kYXRhU3ZjLmRlZXBNZXJnZU9iamVjdCh0aGlzLm1hcENvbmZpZywgdGhpcy5jb25maWcsIGZhbHNlKTtcclxuXHJcbiAgICAgICAgdGhpcy5tYXBDb25maWcubGVnZW5kLmVuYWJsZWQgPSB0aGlzLl9zZXRFbmFibGVkKCdsZWdlbmQnLCBbJ3RpdGxlJ10pO1xyXG4gICAgICAgIGlmICh0aGlzLm1hcENvbmZpZy5mb290ZXIpIHRoaXMubWFwQ29uZmlnLmZvb3Rlci5lbmFibGVkID0gdGhpcy5fc2V0RW5hYmxlZCgnZm9vdGVyJywgWydib3R0b21MYWJlbCcsICdmb290Tm90ZSddKTtcclxuXHJcbiAgICAgICAgdGhpcy5fc2V0Q2xhc3NOYW1lcygpO1xyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX3NldEVuYWJsZWQoX29iaktleTogc3RyaW5nLCBfdGV4dEtleXM6IEFycmF5PHN0cmluZz4pOiBib29sZWFuIHtcclxuICAgICAgICBpZiAodGhpcy5tYXBDb25maWdbX29iaktleV0gJiYgdHlwZW9mIHRoaXMubWFwQ29uZmlnW19vYmpLZXldLmVuYWJsZWQgIT09ICd1bmRlZmluZWQnKSB7XHJcbiAgICAgICAgICAgIHJldHVybiB0aGlzLm1hcENvbmZpZ1tfb2JqS2V5XS5lbmFibGVkO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgZm9yIChsZXQgaTogbnVtYmVyID0gX3RleHRLZXlzLmxlbmd0aCAtIDE7IGkgPj0gMDsgaS0tKSB7XHJcbiAgICAgICAgICAgIGlmICh0aGlzLm1hcENvbmZpZ1tfb2JqS2V5XVtfdGV4dEtleXNbaV1dICYmIHRoaXMubWFwQ29uZmlnW19vYmpLZXldW190ZXh0S2V5c1tpXV0udGV4dCAhPT0gJycpIHtcclxuICAgICAgICAgICAgICAgIHJldHVybiB0cnVlO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICBpZiAoX29iaktleSA9PT0gJ2xlZ2VuZCcgJiYgdGhpcy5tYXJrZXJzTGVnZW5kLmxlbmd0aCA9PT0gMCkge1xyXG4gICAgICAgICAgICByZXR1cm4gZmFsc2U7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICByZXR1cm4gZmFsc2VcclxuICAgIH1cclxuXHJcbiAgICAvKiBUbyBiZSByZXZpc2l0LiBIb3QgZml4IGZvciBkb3duZ3JhZGUgY29tcG9uZW50IGFzIG5nY2xhc3MgdmFsdWUgZG9lc24ndCBjaGFuZ2UuKi9cclxuICAgIHByaXZhdGUgX3NldENsYXNzTmFtZXMoKTogdm9pZCB7XHJcblxyXG4gICAgICAgIC8vIGh0bWxDbGFzc09iaiBpcyBhIHdvcmthcm91bmQgZm9yIGRvd25ncmFkZSBtZXRob2RcclxuICAgICAgICB0aGlzLmh0bWxDbGFzcyA9ICcnO1xyXG5cclxuICAgICAgICBpZiAodHlwZW9mIHRoaXMuY29uZmlnLmxlZ2VuZC5mbG9hdCAhPT0gJ3VuZGVmaW5lZCcgJiYgdGhpcy5jb25maWcubGVnZW5kLmZsb2F0KSB7XHJcbiAgICAgICAgICAgIHRoaXMuaHRtbENsYXNzICs9ICdsZWdlbmQtZmxvYXQgJztcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIGlmICh0eXBlb2YgdGhpcy5jb25maWcubGVnZW5kLnZlcnRpY2FsQWxpZ24gIT09ICd1bmRlZmluZWQnKSB7XHJcbiAgICAgICAgICAgIHRoaXMuaHRtbENsYXNzICs9IHRoaXMuY29uZmlnLmxlZ2VuZC52ZXJ0aWNhbEFsaWduICsgJyAnO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgaWYgKHR5cGVvZiB0aGlzLmNvbmZpZy5sZWdlbmQuYWxpZ24gIT09ICd1bmRlZmluZWQnKSB7XHJcbiAgICAgICAgICAgIHRoaXMuaHRtbENsYXNzICs9IHRoaXMuY29uZmlnLmxlZ2VuZC5hbGlnbjtcclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG59XHJcbiJdfQ==