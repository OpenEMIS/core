import { Component, ViewContainerRef, Input, Output, EventEmitter, ViewChild, ViewEncapsulation, Renderer2 } from '@angular/core';
import { timer } from 'rxjs';
import { KdTextInputSvc } from './kd-angular-textinput-svc';
import { KdDomElemSvc } from '../kd-common/index';
import { AutoComplete } from 'primeng/autocomplete';
export class KdTextInput {
    constructor(_renderer, _vcr, _textInputSvc) {
        this._renderer = _renderer;
        this._vcr = _vcr;
        this._textInputSvc = _textInputSvc;
        this._textSetting = {};
        this._isLoading = false;
        this.updatedValue = new EventEmitter();
    }
    ngOnInit() {
        this._textSetting = this._textInputSvc.setInitSetting(this.config);
        this._textValue = (typeof this.value !== 'undefined') ? this.value : '';
        if (typeof this.options !== 'undefined' && this.options !== null) {
            let currentSelected = typeof this._textValue !== 'undefined' ? this._textValue : [];
            this._resultList = this._textInputSvc.checkMultiSelect(this.options, currentSelected);
        }
        else if (typeof this.config.dropdownCallback === 'undefined') {
            this._textSetting.multiselect = false;
            this._textSetting.autocomplete = false;
        }
    }
    ngOnChanges(changes) {
        if (changes.hasOwnProperty('options') && typeof changes['options'].currentValue !== 'undefined') {
            let currentSelected = typeof this._textValue !== 'undefined' ? this._textValue : [];
            this._resultList = this._textInputSvc.checkMultiSelect(changes['options'].currentValue, currentSelected);
        }
        if (changes.hasOwnProperty('value')) {
            if (typeof changes['value'] !== 'undefined' && typeof changes['value'].currentValue !== 'undefined') {
                if (changes['value'].currentValue !== '') {
                    this._textValue = changes['value'].currentValue;
                }
                else {
                    if (this._textSetting.multiselect) {
                        this._textValue = [];
                    }
                    else {
                        this._textValue = '';
                    }
                }
            }
            else {
                this._textValue = '';
            }
            // this._textValue = (typeof changes["value"].currentValue != "undefined") ? changes["value"].currentValue : "";
        }
    }
    ngAfterViewInit() {
        timer().subscribe(() => {
            if (this._textSetting.multiselect && this._textSetting.dropdownToggle) {
                let queryString = '.ui-autocomplete-multiple .ui-autocomplete-input-token input';
                this._addClickListener(queryString);
            }
            else if (this._textSetting.autocomplete && this._textSetting.dropdownToggle) {
                let queryString = '.ui-autocomplete input.ui-inputtext';
                this._addClickListener(queryString);
            }
        });
    }
    ngOnDestroy() {
        if (typeof this._subscription !== 'undefined')
            this._subscription.unsubscribe();
        if (typeof this._rendererListenFunc !== 'undefined')
            this._rendererListenFunc();
    }
    emitValue() {
        this.updatedValue.emit(this._textValue);
    }
    searchMulti(_event, _state) {
        let query = this._textInputSvc.checkQuery(_event);
        if (typeof this._resultList !== 'undefined') {
            let searchResult = this._textInputSvc.searchList(query, this._resultList);
            this._checkSearchResult(searchResult, query);
        }
        else {
            this._checkLoadingFunc(query);
        }
    }
    multiSelection(val, state) {
        if (this._textSetting.multiselect && typeof this._resultList !== 'undefined') {
            this._updateResultList(val, state);
        }
    }
    checkEnterAndError(event) {
        let inputVal = event.target.value;
        if (inputVal.length < this._textSetting.minLength) {
            this.config.errors = undefined;
        }
        if (event.key === 'Backspace' && typeof this.config.dropdownCallback !== 'undefined' && !this._textSetting.enter) {
            if (typeof this._subscription !== 'undefined') {
                this._subscription.unsubscribe();
            }
            this._isLoading = false;
        }
        if (event.key === 'Enter' && typeof inputVal !== 'undefined' && inputVal !== '') {
            if (this._textSetting.multiselect) {
                this.searchMulti(inputVal, 'selected');
            }
            else if (!this._textSetting.multiselect && typeof this.config.value !== 'undefined' && typeof this.config.value !== 'object') {
                this.searchMulti(inputVal, 'selected');
            }
        }
    }
    _addClickListener(_queryString) {
        let clickEventEle = this._vcr.element.nativeElement.querySelector(_queryString);
        this._rendererListenFunc = this._renderer.listen(clickEventEle, 'click', (_event) => {
            this.autocompleteComponent.handleDropdownClick(_event);
        });
    }
    _updateResultList(_val, _state) {
        if (_state === 'selected') {
            for (let i = 0; i < this._resultList.length; i++) {
                if (_val.value === this._resultList[i].value) {
                    this._resultList.splice(i, 1);
                    break;
                }
            }
        }
        else {
            let sortFunc = (a, b) => {
                if (a.value < b.value)
                    return -1;
                else if (a.value > b.value)
                    return 1;
                return 0;
            };
            this._resultList.push(_val);
            this._resultList.sort(sortFunc);
        }
    }
    _checkSearchResult(_value, _query) {
        let filteredOptions = this._textInputSvc.filterOptionList(_value, this._textValue);
        timer().subscribe(() => {
            this._suggestionList = filteredOptions.slice();
            let checkedResult = this._textInputSvc.checkError(this._suggestionList, _query);
            if (typeof checkedResult !== 'undefined') {
                let result = [];
                result.push(checkedResult.dialogueMessage);
                this.config.errors = result;
            }
        });
    }
    _checkLoadingFunc(_query) {
        this._isLoading = true;
        let selectedVal = (typeof this.config.value !== 'undefined') ? this.config.value : [];
        let params = { query: _query, currentSelected: selectedVal };
        if (typeof this._subscription !== 'undefined') {
            this._subscription.unsubscribe();
        }
        this._subscription = this.config.dropdownCallback(params).subscribe((_value) => {
            // console.log(">>> value", _value);
            this._checkSearchResult(_value, _query);
            this._isLoading = false;
        });
    }
}
KdTextInput.decorators = [
    { type: Component, args: [{
                selector: 'kd-text-input',
                template: "<p-autoComplete \r\n\t*ngIf=\"_textSetting.multiselect && !_textSetting.enter\" \r\n\t[multiple]=\"_textSetting.multiselect\" \r\n\t[suggestions]=\"_suggestionList\" \r\n\t(keyup)=\"checkEnterAndError($event)\" \r\n\t(completeMethod)=\"searchMulti($event, 'complete')\" \r\n\t(onSelect)=\"multiSelection($event, 'selected')\" \r\n\t(onUnselect)=\"multiSelection($event, 'unselected')\" \r\n\t[minLength]=\"_textSetting.minLength\" \r\n\t(onDropdownClick)=\"searchMulti($event, 'dropdown')\" \r\n\t[(ngModel)]=\"_textValue\" \r\n\t(ngModelChange)=\"emitValue()\" \r\n\t[disabled]=\"disabled || readonly\" \r\n\t[placeholder]=\"_textSetting.placeholder\"\r\n\tfield=\"value\"\r\n\tclass=\"kdx-p-autocomplete\"\r\n>\r\n</p-autoComplete>\r\n\r\n<p-autoComplete  \r\n\t*ngIf=\"_textSetting.autocomplete && !_textSetting.enter\"\r\n\t[suggestions]=\"_suggestionList\"\r\n\t(keyup)=\"checkEnterAndError($event)\"\r\n\t(completeMethod)=\"searchMulti($event, 'complete')\"\r\n\t(onSelect)=\"multiSelection($event, 'selected')\"\r\n\t[minLength]=\"_textSetting.minLength\"\r\n\t[placeholder]=\"_textSetting.placeholder\"\r\n\t(onDropdownClick)=\"searchMulti($event, 'dropdown')\"\r\n\t[(ngModel)]=\"_textValue\" \r\n\t(ngModelChange)=\"emitValue()\"\r\n\t[disabled]=\"disabled\"\r\n\t[readonly]=\"readonly\" \r\n\tfield=\"value\"\r\n\tclass=\"kdx-p-autocomplete\"\r\n>\r\n</p-autoComplete>\r\n\r\n<div *ngIf=\"_textSetting.multiselect && _textSetting.enter\" class=\"kdx-input-with-btn\">\r\n\t<p-autoComplete \r\n\t\t[multiple]=\"_textSetting.multiselect\"\r\n\t\t(keyup)=\"checkEnterAndError($event)\"\r\n\t\t[dropdown]=\"true\"\r\n\t\t(completeMethod)=\"searchMulti($event, 'complete')\"\r\n\t\t[suggestions]=\"_suggestionList\"\r\n\t\t(onSelect)=\"multiSelection($event, 'selected')\"\r\n\t\t(onUnselect)=\"multiSelection($event, 'unselected')\"\r\n\t\t(onDropdownClick)=\"searchMulti($event, 'dropdown')\"\r\n\t\t[placeholder]=\"_textSetting.placeholder\"\r\n\t\t[(ngModel)]=\"_textValue\" \r\n\t\t(ngModelChange)=\"emitValue()\"\r\n\t\t[disabled]=\"disabled || readonly\"\r\n\t\t[readonly]=\"readonly\"\r\n\t\tfield=\"value\"\r\n\t\tclass=\"kdx-p-autocomplete\"\r\n\t>\r\n\t</p-autoComplete>\r\n</div>\r\n\r\n<div *ngIf=\"_textSetting.autocomplete && _textSetting.enter\" class=\"kdx-input-with-btn\">\r\n\t<p-autoComplete \r\n\t\t(keyup)=\"checkEnterAndError($event)\"\r\n\t\t[dropdown]=\"true\"\r\n\t\t[suggestions]=\"_suggestionList\"\r\n\t\t(completeMethod)=\"searchMulti($event, 'complete')\"\r\n\t\t(onDropdownClick)=\"searchMulti($event, 'dropdown')\"\r\n\t\t(onSelect)=\"multiSelection($event, 'selected')\"\r\n\t\t[placeholder]=\"_textSetting.placeholder\"\r\n\t\t[(ngModel)]=\"_textValue\" \r\n\t\t(ngModelChange)=\"emitValue()\"\r\n\t\t[disabled]=\"disabled\"\r\n\t\t[readonly]=\"readonly\" \r\n\t\tfield=\"value\"\r\n\t\tclass=\"kdx-p-autocomplete\"\r\n\t>\r\n\t</p-autoComplete>\r\n</div>\r\n\r\n<div [hidden]=\"!_isLoading\" class=\"kdx-input-loader-wrapper\">\r\n\t<i class=\"fa fa-spinner fa-pulse fa-lg fa-fw input-loader\"></i>\r\n</div>\r\n\r\n<input \r\n\t*ngIf=\"!_textSetting.autocomplete && !_textSetting.multiselect\" \r\n\ttype=\"text\" \r\n\t[placeholder]=\"_textSetting.placeholder\" \r\n\t[(ngModel)]=\"_textValue\" \r\n\t[attr.maxlength]=\"maxLength\" \r\n\t[attr.disabled]=\"disabled ? disabled : null\" \r\n\t[attr.readonly]=\"readonly ? readonly : null\" \r\n\t(ngModelChange)=\"emitValue()\"\r\n/>\r\n\r\n<ng-content></ng-content>",
                encapsulation: ViewEncapsulation.None,
                providers: [KdTextInputSvc, KdDomElemSvc],
                host: { 'class': 'kdx kdx-text-input' }
            },] }
];
KdTextInput.ctorParameters = () => [
    { type: Renderer2 },
    { type: ViewContainerRef },
    { type: KdTextInputSvc }
];
KdTextInput.propDecorators = {
    config: [{ type: Input }],
    options: [{ type: Input }],
    disabled: [{ type: Input }],
    readonly: [{ type: Input }],
    value: [{ type: Input }],
    maxLength: [{ type: Input }],
    updatedValue: [{ type: Output }],
    autocompleteComponent: [{ type: ViewChild, args: [AutoComplete,] }]
};
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoia2QtYW5ndWxhci10ZXh0LWlucHV0LmpzIiwic291cmNlUm9vdCI6IkM6L3hhbXBwL2h0ZG9jcy9TdHlsZWd1aWRlL2lvc3RnLW9wZW5lbWlzLXN0eWxlZ3VpZGUvcHJvamVjdHMvb3BlbmVtaXMtc3R5bGVndWlkZS1saWIvc3JjLyIsInNvdXJjZXMiOlsia2QtY29tcG9uZW50cy9rZC1hbmd1bGFyLXRleHQtaW5wdXQva2QtYW5ndWxhci10ZXh0LWlucHV0LnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBLE9BQU8sRUFBRSxTQUFTLEVBQUUsZ0JBQWdCLEVBQUUsS0FBSyxFQUFhLE1BQU0sRUFBRSxZQUFZLEVBQUUsU0FBUyxFQUFFLGlCQUFpQixFQUFtRCxTQUFTLEVBQUUsTUFBTSxlQUFlLENBQUM7QUFDOUwsT0FBTyxFQUFFLEtBQUssRUFBa0IsTUFBTSxNQUFNLENBQUM7QUFDN0MsT0FBTyxFQUFFLGNBQWMsRUFBRSxNQUFNLDRCQUE0QixDQUFDO0FBQzVELE9BQU8sRUFBRSxZQUFZLEVBQUUsTUFBTSxvQkFBb0IsQ0FBQztBQUNsRCxPQUFPLEVBQUUsWUFBWSxFQUFFLE1BQU0sc0JBQXNCLENBQUM7QUFXcEQsTUFBTSxPQUFPLFdBQVc7SUFrQnBCLFlBQ1ksU0FBb0IsRUFDcEIsSUFBc0IsRUFDdEIsYUFBNkI7UUFGN0IsY0FBUyxHQUFULFNBQVMsQ0FBVztRQUNwQixTQUFJLEdBQUosSUFBSSxDQUFrQjtRQUN0QixrQkFBYSxHQUFiLGFBQWEsQ0FBZ0I7UUFwQmxDLGlCQUFZLEdBQVEsRUFBRSxDQUFDO1FBQ3ZCLGVBQVUsR0FBWSxLQUFLLENBQUM7UUFhekIsaUJBQVksR0FBc0IsSUFBSSxZQUFZLEVBQUUsQ0FBQztJQU8zRCxDQUFDO0lBRUwsUUFBUTtRQUNKLElBQUksQ0FBQyxZQUFZLEdBQUcsSUFBSSxDQUFDLGFBQWEsQ0FBQyxjQUFjLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDO1FBQ25FLElBQUksQ0FBQyxVQUFVLEdBQUcsQ0FBQyxPQUFPLElBQUksQ0FBQyxLQUFLLEtBQUssV0FBVyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQztRQUV4RSxJQUFJLE9BQU8sSUFBSSxDQUFDLE9BQU8sS0FBSyxXQUFXLElBQUksSUFBSSxDQUFDLE9BQU8sS0FBSyxJQUFJLEVBQUU7WUFDOUQsSUFBSSxlQUFlLEdBQWUsT0FBTyxJQUFJLENBQUMsVUFBVSxLQUFLLFdBQVcsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDO1lBQ2hHLElBQUksQ0FBQyxXQUFXLEdBQUcsSUFBSSxDQUFDLGFBQWEsQ0FBQyxnQkFBZ0IsQ0FBQyxJQUFJLENBQUMsT0FBTyxFQUFFLGVBQWUsQ0FBQyxDQUFDO1NBQ3pGO2FBQ0ksSUFBSSxPQUFPLElBQUksQ0FBQyxNQUFNLENBQUMsZ0JBQWdCLEtBQUssV0FBVyxFQUFFO1lBQzFELElBQUksQ0FBQyxZQUFZLENBQUMsV0FBVyxHQUFHLEtBQUssQ0FBQztZQUN0QyxJQUFJLENBQUMsWUFBWSxDQUFDLFlBQVksR0FBRyxLQUFLLENBQUM7U0FDMUM7SUFDTCxDQUFDO0lBRUQsV0FBVyxDQUFDLE9BQXNCO1FBQzlCLElBQUksT0FBTyxDQUFDLGNBQWMsQ0FBQyxTQUFTLENBQUMsSUFBSSxPQUFPLE9BQU8sQ0FBQyxTQUFTLENBQUMsQ0FBQyxZQUFZLEtBQUssV0FBVyxFQUFFO1lBQzdGLElBQUksZUFBZSxHQUFlLE9BQU8sSUFBSSxDQUFDLFVBQVUsS0FBSyxXQUFXLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQztZQUNoRyxJQUFJLENBQUMsV0FBVyxHQUFHLElBQUksQ0FBQyxhQUFhLENBQUMsZ0JBQWdCLENBQUMsT0FBTyxDQUFDLFNBQVMsQ0FBQyxDQUFDLFlBQVksRUFBRSxlQUFlLENBQUMsQ0FBQztTQUM1RztRQUVELElBQUksT0FBTyxDQUFDLGNBQWMsQ0FBQyxPQUFPLENBQUMsRUFBRTtZQUNqQyxJQUFJLE9BQU8sT0FBTyxDQUFDLE9BQU8sQ0FBQyxLQUFLLFdBQVcsSUFBSSxPQUFPLE9BQU8sQ0FBQyxPQUFPLENBQUMsQ0FBQyxZQUFZLEtBQUssV0FBVyxFQUFFO2dCQUNqRyxJQUFJLE9BQU8sQ0FBQyxPQUFPLENBQUMsQ0FBQyxZQUFZLEtBQUssRUFBRSxFQUFFO29CQUN0QyxJQUFJLENBQUMsVUFBVSxHQUFHLE9BQU8sQ0FBQyxPQUFPLENBQUMsQ0FBQyxZQUFZLENBQUM7aUJBQ25EO3FCQUNJO29CQUNELElBQUksSUFBSSxDQUFDLFlBQVksQ0FBQyxXQUFXLEVBQUU7d0JBQy9CLElBQUksQ0FBQyxVQUFVLEdBQUcsRUFBRSxDQUFDO3FCQUN4Qjt5QkFDSTt3QkFDRCxJQUFJLENBQUMsVUFBVSxHQUFHLEVBQUUsQ0FBQztxQkFDeEI7aUJBQ0o7YUFDSjtpQkFBTTtnQkFDSCxJQUFJLENBQUMsVUFBVSxHQUFHLEVBQUUsQ0FBQzthQUN4QjtZQUVELGdIQUFnSDtTQUNuSDtJQUNMLENBQUM7SUFFRCxlQUFlO1FBQ1gsS0FBSyxFQUFFLENBQUMsU0FBUyxDQUFDLEdBQVMsRUFBRTtZQUN6QixJQUFJLElBQUksQ0FBQyxZQUFZLENBQUMsV0FBVyxJQUFJLElBQUksQ0FBQyxZQUFZLENBQUMsY0FBYyxFQUFFO2dCQUNuRSxJQUFJLFdBQVcsR0FBVyw4REFBOEQsQ0FBQztnQkFDekYsSUFBSSxDQUFDLGlCQUFpQixDQUFDLFdBQVcsQ0FBQyxDQUFDO2FBQ3ZDO2lCQUNJLElBQUksSUFBSSxDQUFDLFlBQVksQ0FBQyxZQUFZLElBQUksSUFBSSxDQUFDLFlBQVksQ0FBQyxjQUFjLEVBQUU7Z0JBQ3pFLElBQUksV0FBVyxHQUFXLHFDQUFxQyxDQUFDO2dCQUNoRSxJQUFJLENBQUMsaUJBQWlCLENBQUMsV0FBVyxDQUFDLENBQUM7YUFDdkM7UUFDTCxDQUFDLENBQUMsQ0FBQztJQUVQLENBQUM7SUFFRCxXQUFXO1FBQ1AsSUFBSSxPQUFPLElBQUksQ0FBQyxhQUFhLEtBQUssV0FBVztZQUFFLElBQUksQ0FBQyxhQUFhLENBQUMsV0FBVyxFQUFFLENBQUM7UUFDaEYsSUFBSSxPQUFPLElBQUksQ0FBQyxtQkFBbUIsS0FBSyxXQUFXO1lBQUUsSUFBSSxDQUFDLG1CQUFtQixFQUFFLENBQUM7SUFDcEYsQ0FBQztJQUVELFNBQVM7UUFDTCxJQUFJLENBQUMsWUFBWSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLENBQUM7SUFDNUMsQ0FBQztJQUVELFdBQVcsQ0FBQyxNQUFXLEVBQUUsTUFBYztRQUNuQyxJQUFJLEtBQUssR0FBVyxJQUFJLENBQUMsYUFBYSxDQUFDLFVBQVUsQ0FBQyxNQUFNLENBQUMsQ0FBQztRQUUxRCxJQUFJLE9BQU8sSUFBSSxDQUFDLFdBQVcsS0FBSyxXQUFXLEVBQUU7WUFDekMsSUFBSSxZQUFZLEdBQWUsSUFBSSxDQUFDLGFBQWEsQ0FBQyxVQUFVLENBQUMsS0FBSyxFQUFFLElBQUksQ0FBQyxXQUFXLENBQUMsQ0FBQztZQUN0RixJQUFJLENBQUMsa0JBQWtCLENBQUMsWUFBWSxFQUFFLEtBQUssQ0FBQyxDQUFDO1NBQ2hEO2FBQ0k7WUFDRCxJQUFJLENBQUMsaUJBQWlCLENBQUMsS0FBSyxDQUFDLENBQUM7U0FDakM7SUFDTCxDQUFDO0lBRUQsY0FBYyxDQUFDLEdBQVEsRUFBRSxLQUFhO1FBQ2xDLElBQUksSUFBSSxDQUFDLFlBQVksQ0FBQyxXQUFXLElBQUksT0FBTyxJQUFJLENBQUMsV0FBVyxLQUFLLFdBQVcsRUFBRTtZQUMxRSxJQUFJLENBQUMsaUJBQWlCLENBQUMsR0FBRyxFQUFFLEtBQUssQ0FBQyxDQUFDO1NBQ3RDO0lBQ0wsQ0FBQztJQUVELGtCQUFrQixDQUFDLEtBQVU7UUFDekIsSUFBSSxRQUFRLEdBQVcsS0FBSyxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUM7UUFFMUMsSUFBSSxRQUFRLENBQUMsTUFBTSxHQUFHLElBQUksQ0FBQyxZQUFZLENBQUMsU0FBUyxFQUFFO1lBQy9DLElBQUksQ0FBQyxNQUFNLENBQUMsTUFBTSxHQUFHLFNBQVMsQ0FBQztTQUNsQztRQUVELElBQUksS0FBSyxDQUFDLEdBQUcsS0FBSyxXQUFXLElBQUksT0FBTyxJQUFJLENBQUMsTUFBTSxDQUFDLGdCQUFnQixLQUFLLFdBQVcsSUFBSSxDQUFDLElBQUksQ0FBQyxZQUFZLENBQUMsS0FBSyxFQUFFO1lBQzlHLElBQUksT0FBTyxJQUFJLENBQUMsYUFBYSxLQUFLLFdBQVcsRUFBRTtnQkFDM0MsSUFBSSxDQUFDLGFBQWEsQ0FBQyxXQUFXLEVBQUUsQ0FBQzthQUNwQztZQUVELElBQUksQ0FBQyxVQUFVLEdBQUcsS0FBSyxDQUFDO1NBQzNCO1FBRUQsSUFBSSxLQUFLLENBQUMsR0FBRyxLQUFLLE9BQU8sSUFBSSxPQUFPLFFBQVEsS0FBSyxXQUFXLElBQUksUUFBUSxLQUFLLEVBQUUsRUFBRTtZQUM3RSxJQUFJLElBQUksQ0FBQyxZQUFZLENBQUMsV0FBVyxFQUFFO2dCQUMvQixJQUFJLENBQUMsV0FBVyxDQUFDLFFBQVEsRUFBRSxVQUFVLENBQUMsQ0FBQzthQUMxQztpQkFFSSxJQUFJLENBQUMsSUFBSSxDQUFDLFlBQVksQ0FBQyxXQUFXLElBQUksT0FBTyxJQUFJLENBQUMsTUFBTSxDQUFDLEtBQUssS0FBSyxXQUFXLElBQUksT0FBTyxJQUFJLENBQUMsTUFBTSxDQUFDLEtBQUssS0FBSyxRQUFRLEVBQUU7Z0JBQzFILElBQUksQ0FBQyxXQUFXLENBQUMsUUFBUSxFQUFFLFVBQVUsQ0FBQyxDQUFDO2FBQzFDO1NBQ0o7SUFDTCxDQUFDO0lBRU8saUJBQWlCLENBQUMsWUFBb0I7UUFDMUMsSUFBSSxhQUFhLEdBQWdCLElBQUksQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLGFBQWEsQ0FBQyxhQUFhLENBQUMsWUFBWSxDQUFDLENBQUM7UUFFN0YsSUFBSSxDQUFDLG1CQUFtQixHQUFHLElBQUksQ0FBQyxTQUFTLENBQUMsTUFBTSxDQUFDLGFBQWEsRUFBRSxPQUFPLEVBQUUsQ0FBQyxNQUFXLEVBQVEsRUFBRTtZQUNuRyxJQUFJLENBQUMscUJBQXFCLENBQUMsbUJBQW1CLENBQUMsTUFBTSxDQUFDLENBQUM7UUFDM0QsQ0FBQyxDQUFDLENBQUM7SUFDQyxDQUFDO0lBRU8saUJBQWlCLENBQUMsSUFBUyxFQUFFLE1BQWM7UUFDL0MsSUFBSSxNQUFNLEtBQUssVUFBVSxFQUFFO1lBQ3ZCLEtBQUssSUFBSSxDQUFDLEdBQVcsQ0FBQyxFQUFFLENBQUMsR0FBRyxJQUFJLENBQUMsV0FBVyxDQUFDLE1BQU0sRUFBRSxDQUFDLEVBQUUsRUFBRTtnQkFDdEQsSUFBSSxJQUFJLENBQUMsS0FBSyxLQUFLLElBQUksQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxFQUFFO29CQUMxQyxJQUFJLENBQUMsV0FBVyxDQUFDLE1BQU0sQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUM7b0JBQzlCLE1BQU07aUJBQ1Q7YUFDSjtTQUNKO2FBQ0k7WUFDRCxJQUFJLFFBQVEsR0FBK0IsQ0FBQyxDQUFNLEVBQUUsQ0FBTSxFQUFVLEVBQUU7Z0JBQ2xFLElBQUksQ0FBQyxDQUFDLEtBQUssR0FBRyxDQUFDLENBQUMsS0FBSztvQkFBRSxPQUFPLENBQUMsQ0FBQyxDQUFDO3FCQUM1QixJQUFJLENBQUMsQ0FBQyxLQUFLLEdBQUcsQ0FBQyxDQUFDLEtBQUs7b0JBQUUsT0FBTyxDQUFDLENBQUM7Z0JBQ3JDLE9BQU8sQ0FBQyxDQUFDO1lBQ2IsQ0FBQyxDQUFDO1lBRUYsSUFBSSxDQUFDLFdBQVcsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUM7WUFDNUIsSUFBSSxDQUFDLFdBQVcsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLENBQUM7U0FDbkM7SUFDTCxDQUFDO0lBRU8sa0JBQWtCLENBQUMsTUFBa0IsRUFBRSxNQUFjO1FBQ3pELElBQUksZUFBZSxHQUFlLElBQUksQ0FBQyxhQUFhLENBQUMsZ0JBQWdCLENBQUMsTUFBTSxFQUFFLElBQUksQ0FBQyxVQUFVLENBQUMsQ0FBQztRQUUvRixLQUFLLEVBQUUsQ0FBQyxTQUFTLENBQUMsR0FBUyxFQUFFO1lBQ3pCLElBQUksQ0FBQyxlQUFlLEdBQUcsZUFBZSxDQUFDLEtBQUssRUFBRSxDQUFDO1lBRS9DLElBQUksYUFBYSxHQUFHLElBQUksQ0FBQyxhQUFhLENBQUMsVUFBVSxDQUFDLElBQUksQ0FBQyxlQUFlLEVBQUUsTUFBTSxDQUFDLENBQUM7WUFFaEYsSUFBSSxPQUFPLGFBQWEsS0FBSyxXQUFXLEVBQUU7Z0JBQ3RDLElBQUksTUFBTSxHQUFrQixFQUFFLENBQUM7Z0JBQy9CLE1BQU0sQ0FBQyxJQUFJLENBQUMsYUFBYSxDQUFDLGVBQWUsQ0FBQyxDQUFDO2dCQUMzQyxJQUFJLENBQUMsTUFBTSxDQUFDLE1BQU0sR0FBRyxNQUFNLENBQUM7YUFDL0I7UUFDTCxDQUFDLENBQUMsQ0FBQztJQUNQLENBQUM7SUFFTyxpQkFBaUIsQ0FBQyxNQUFjO1FBQ3BDLElBQUksQ0FBQyxVQUFVLEdBQUcsSUFBSSxDQUFDO1FBRXZCLElBQUksV0FBVyxHQUFHLENBQUMsT0FBTyxJQUFJLENBQUMsTUFBTSxDQUFDLEtBQUssS0FBSyxXQUFXLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQztRQUN0RixJQUFJLE1BQU0sR0FBRyxFQUFDLEtBQUssRUFBRSxNQUFNLEVBQUUsZUFBZSxFQUFFLFdBQVcsRUFBQyxDQUFDO1FBRTNELElBQUksT0FBTyxJQUFJLENBQUMsYUFBYSxLQUFLLFdBQVcsRUFBRTtZQUMzQyxJQUFJLENBQUMsYUFBYSxDQUFDLFdBQVcsRUFBRSxDQUFDO1NBQ3BDO1FBRUQsSUFBSSxDQUFDLGFBQWEsR0FBRyxJQUFJLENBQUMsTUFBTSxDQUFDLGdCQUFnQixDQUFDLE1BQU0sQ0FBQyxDQUFDLFNBQVMsQ0FBQyxDQUFDLE1BQVcsRUFBUSxFQUFFO1lBQ3RGLG9DQUFvQztZQUNwQyxJQUFJLENBQUMsa0JBQWtCLENBQUMsTUFBTSxFQUFFLE1BQU0sQ0FBQyxDQUFDO1lBQ3hDLElBQUksQ0FBQyxVQUFVLEdBQUcsS0FBSyxDQUFDO1FBQzVCLENBQUMsQ0FBQyxDQUFDO0lBQ1AsQ0FBQzs7O1lBeE1KLFNBQVMsU0FBQztnQkFDUCxRQUFRLEVBQUUsZUFBZTtnQkFDekIsKzRHQUEyQztnQkFDM0MsYUFBYSxFQUFFLGlCQUFpQixDQUFDLElBQUk7Z0JBQ3JDLFNBQVMsRUFBRSxDQUFDLGNBQWMsRUFBRSxZQUFZLENBQUM7Z0JBQ3pDLElBQUksRUFBRyxFQUFFLE9BQU8sRUFBRyxvQkFBb0IsRUFBRTthQUM1Qzs7O1lBYjRKLFNBQVM7WUFBbEosZ0JBQWdCO1lBRTNCLGNBQWM7OztxQkFzQmxCLEtBQUs7c0JBQ0wsS0FBSzt1QkFDTCxLQUFLO3VCQUNMLEtBQUs7b0JBQ0wsS0FBSzt3QkFDTCxLQUFLOzJCQUNMLE1BQU07b0NBQ04sU0FBUyxTQUFDLFlBQVkiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBDb21wb25lbnQsIFZpZXdDb250YWluZXJSZWYsIElucHV0LCBPbkNoYW5nZXMsIE91dHB1dCwgRXZlbnRFbWl0dGVyLCBWaWV3Q2hpbGQsIFZpZXdFbmNhcHN1bGF0aW9uLCBPbkluaXQsIEFmdGVyVmlld0luaXQsIE9uRGVzdHJveSwgU2ltcGxlQ2hhbmdlcywgUmVuZGVyZXIyIH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XHJcbmltcG9ydCB7IHRpbWVyICwgIFN1YnNjcmlwdGlvbiB9IGZyb20gJ3J4anMnO1xyXG5pbXBvcnQgeyBLZFRleHRJbnB1dFN2YyB9IGZyb20gJy4va2QtYW5ndWxhci10ZXh0aW5wdXQtc3ZjJztcclxuaW1wb3J0IHsgS2REb21FbGVtU3ZjIH0gZnJvbSAnLi4va2QtY29tbW9uL2luZGV4JztcclxuaW1wb3J0IHsgQXV0b0NvbXBsZXRlIH0gZnJvbSAncHJpbWVuZy9hdXRvY29tcGxldGUnO1xyXG5cclxuXHJcbkBDb21wb25lbnQoe1xyXG4gICAgc2VsZWN0b3I6ICdrZC10ZXh0LWlucHV0JyxcclxuICAgIHRlbXBsYXRlVXJsOiAnLi9rZC1hbmd1bGFyLXRleHQtaW5wdXQuaHRtbCcsXHJcbiAgICBlbmNhcHN1bGF0aW9uOiBWaWV3RW5jYXBzdWxhdGlvbi5Ob25lLFxyXG4gICAgcHJvdmlkZXJzOiBbS2RUZXh0SW5wdXRTdmMsIEtkRG9tRWxlbVN2Y10sXHJcbiAgICBob3N0IDogeyAnY2xhc3MnIDogJ2tkeCBrZHgtdGV4dC1pbnB1dCcgfVxyXG59KVxyXG5cclxuZXhwb3J0IGNsYXNzIEtkVGV4dElucHV0IGltcGxlbWVudHMgT25Jbml0LCBPbkNoYW5nZXMsIEFmdGVyVmlld0luaXQsIE9uRGVzdHJveSB7XHJcbiAgICBwdWJsaWMgX3RleHRTZXR0aW5nOiBhbnkgPSB7fTtcclxuICAgIHB1YmxpYyBfaXNMb2FkaW5nOiBib29sZWFuID0gZmFsc2U7XHJcbiAgICBwcml2YXRlIF9yZXN1bHRMaXN0OiBBcnJheTxhbnk+O1xyXG4gICAgcHVibGljIF9zdWdnZXN0aW9uTGlzdDogQXJyYXk8c3RyaW5nPjtcclxuICAgIHByaXZhdGUgX3N1YnNjcmlwdGlvbjogU3Vic2NyaXB0aW9uO1xyXG4gICAgcHJpdmF0ZSBfcmVuZGVyZXJMaXN0ZW5GdW5jOiBGdW5jdGlvbjtcclxuICAgIHB1YmxpYyBfdGV4dFZhbHVlOiBhbnk7XHJcblxyXG4gICAgQElucHV0KCkgY29uZmlnOiBhbnk7XHJcbiAgICBASW5wdXQoKSBvcHRpb25zOiBhbnk7XHJcbiAgICBASW5wdXQoKSBkaXNhYmxlZDogYm9vbGVhbjtcclxuICAgIEBJbnB1dCgpIHJlYWRvbmx5OiBib29sZWFuO1xyXG4gICAgQElucHV0KCkgdmFsdWU6IGFueTtcclxuICAgIEBJbnB1dCgpIG1heExlbmd0aDogbnVtYmVyO1xyXG4gICAgQE91dHB1dCgpIHVwZGF0ZWRWYWx1ZTogRXZlbnRFbWl0dGVyPGFueT4gPSBuZXcgRXZlbnRFbWl0dGVyKCk7XHJcbiAgICBAVmlld0NoaWxkKEF1dG9Db21wbGV0ZSkgYXV0b2NvbXBsZXRlQ29tcG9uZW50OiBBdXRvQ29tcGxldGU7XHJcblxyXG4gICAgY29uc3RydWN0b3IoXHJcbiAgICAgICAgcHJpdmF0ZSBfcmVuZGVyZXI6IFJlbmRlcmVyMixcclxuICAgICAgICBwcml2YXRlIF92Y3I6IFZpZXdDb250YWluZXJSZWYsXHJcbiAgICAgICAgcHJpdmF0ZSBfdGV4dElucHV0U3ZjOiBLZFRleHRJbnB1dFN2Y1xyXG4gICAgKSB7IH1cclxuXHJcbiAgICBuZ09uSW5pdCgpOiB2b2lkIHtcclxuICAgICAgICB0aGlzLl90ZXh0U2V0dGluZyA9IHRoaXMuX3RleHRJbnB1dFN2Yy5zZXRJbml0U2V0dGluZyh0aGlzLmNvbmZpZyk7XHJcbiAgICAgICAgdGhpcy5fdGV4dFZhbHVlID0gKHR5cGVvZiB0aGlzLnZhbHVlICE9PSAndW5kZWZpbmVkJykgPyB0aGlzLnZhbHVlIDogJyc7XHJcblxyXG4gICAgICAgIGlmICh0eXBlb2YgdGhpcy5vcHRpb25zICE9PSAndW5kZWZpbmVkJyAmJiB0aGlzLm9wdGlvbnMgIT09IG51bGwpIHtcclxuICAgICAgICAgICAgbGV0IGN1cnJlbnRTZWxlY3RlZDogQXJyYXk8YW55PiA9IHR5cGVvZiB0aGlzLl90ZXh0VmFsdWUgIT09ICd1bmRlZmluZWQnID8gdGhpcy5fdGV4dFZhbHVlIDogW107XHJcbiAgICAgICAgICAgIHRoaXMuX3Jlc3VsdExpc3QgPSB0aGlzLl90ZXh0SW5wdXRTdmMuY2hlY2tNdWx0aVNlbGVjdCh0aGlzLm9wdGlvbnMsIGN1cnJlbnRTZWxlY3RlZCk7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGVsc2UgaWYgKHR5cGVvZiB0aGlzLmNvbmZpZy5kcm9wZG93bkNhbGxiYWNrID09PSAndW5kZWZpbmVkJykge1xyXG4gICAgICAgICAgICB0aGlzLl90ZXh0U2V0dGluZy5tdWx0aXNlbGVjdCA9IGZhbHNlO1xyXG4gICAgICAgICAgICB0aGlzLl90ZXh0U2V0dGluZy5hdXRvY29tcGxldGUgPSBmYWxzZTtcclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgbmdPbkNoYW5nZXMoY2hhbmdlczogU2ltcGxlQ2hhbmdlcyk6IHZvaWQge1xyXG4gICAgICAgIGlmIChjaGFuZ2VzLmhhc093blByb3BlcnR5KCdvcHRpb25zJykgJiYgdHlwZW9mIGNoYW5nZXNbJ29wdGlvbnMnXS5jdXJyZW50VmFsdWUgIT09ICd1bmRlZmluZWQnKSB7XHJcbiAgICAgICAgICAgIGxldCBjdXJyZW50U2VsZWN0ZWQ6IEFycmF5PGFueT4gPSB0eXBlb2YgdGhpcy5fdGV4dFZhbHVlICE9PSAndW5kZWZpbmVkJyA/IHRoaXMuX3RleHRWYWx1ZSA6IFtdO1xyXG4gICAgICAgICAgICB0aGlzLl9yZXN1bHRMaXN0ID0gdGhpcy5fdGV4dElucHV0U3ZjLmNoZWNrTXVsdGlTZWxlY3QoY2hhbmdlc1snb3B0aW9ucyddLmN1cnJlbnRWYWx1ZSwgY3VycmVudFNlbGVjdGVkKTtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIGlmIChjaGFuZ2VzLmhhc093blByb3BlcnR5KCd2YWx1ZScpKSB7XHJcbiAgICAgICAgICAgIGlmICh0eXBlb2YgY2hhbmdlc1sndmFsdWUnXSAhPT0gJ3VuZGVmaW5lZCcgJiYgdHlwZW9mIGNoYW5nZXNbJ3ZhbHVlJ10uY3VycmVudFZhbHVlICE9PSAndW5kZWZpbmVkJykge1xyXG4gICAgICAgICAgICAgICAgaWYgKGNoYW5nZXNbJ3ZhbHVlJ10uY3VycmVudFZhbHVlICE9PSAnJykge1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuX3RleHRWYWx1ZSA9IGNoYW5nZXNbJ3ZhbHVlJ10uY3VycmVudFZhbHVlO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgZWxzZSB7XHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKHRoaXMuX3RleHRTZXR0aW5nLm11bHRpc2VsZWN0KSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuX3RleHRWYWx1ZSA9IFtdO1xyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5fdGV4dFZhbHVlID0gJyc7XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5fdGV4dFZhbHVlID0gJyc7XHJcbiAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgIC8vIHRoaXMuX3RleHRWYWx1ZSA9ICh0eXBlb2YgY2hhbmdlc1tcInZhbHVlXCJdLmN1cnJlbnRWYWx1ZSAhPSBcInVuZGVmaW5lZFwiKSA/IGNoYW5nZXNbXCJ2YWx1ZVwiXS5jdXJyZW50VmFsdWUgOiBcIlwiO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICBuZ0FmdGVyVmlld0luaXQoKTogdm9pZCB7XHJcbiAgICAgICAgdGltZXIoKS5zdWJzY3JpYmUoKCk6IHZvaWQgPT4ge1xyXG4gICAgICAgICAgICBpZiAodGhpcy5fdGV4dFNldHRpbmcubXVsdGlzZWxlY3QgJiYgdGhpcy5fdGV4dFNldHRpbmcuZHJvcGRvd25Ub2dnbGUpIHtcclxuICAgICAgICAgICAgICAgIGxldCBxdWVyeVN0cmluZzogc3RyaW5nID0gJy51aS1hdXRvY29tcGxldGUtbXVsdGlwbGUgLnVpLWF1dG9jb21wbGV0ZS1pbnB1dC10b2tlbiBpbnB1dCc7XHJcbiAgICAgICAgICAgICAgICB0aGlzLl9hZGRDbGlja0xpc3RlbmVyKHF1ZXJ5U3RyaW5nKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBlbHNlIGlmICh0aGlzLl90ZXh0U2V0dGluZy5hdXRvY29tcGxldGUgJiYgdGhpcy5fdGV4dFNldHRpbmcuZHJvcGRvd25Ub2dnbGUpIHtcclxuICAgICAgICAgICAgICAgIGxldCBxdWVyeVN0cmluZzogc3RyaW5nID0gJy51aS1hdXRvY29tcGxldGUgaW5wdXQudWktaW5wdXR0ZXh0JztcclxuICAgICAgICAgICAgICAgIHRoaXMuX2FkZENsaWNrTGlzdGVuZXIocXVlcnlTdHJpbmcpO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfSk7XHJcblxyXG4gICAgfVxyXG5cclxuICAgIG5nT25EZXN0cm95KCk6IHZvaWQge1xyXG4gICAgICAgIGlmICh0eXBlb2YgdGhpcy5fc3Vic2NyaXB0aW9uICE9PSAndW5kZWZpbmVkJykgdGhpcy5fc3Vic2NyaXB0aW9uLnVuc3Vic2NyaWJlKCk7XHJcbiAgICAgICAgaWYgKHR5cGVvZiB0aGlzLl9yZW5kZXJlckxpc3RlbkZ1bmMgIT09ICd1bmRlZmluZWQnKSB0aGlzLl9yZW5kZXJlckxpc3RlbkZ1bmMoKTtcclxuICAgIH1cclxuXHJcbiAgICBlbWl0VmFsdWUoKTogdm9pZCB7XHJcbiAgICAgICAgdGhpcy51cGRhdGVkVmFsdWUuZW1pdCh0aGlzLl90ZXh0VmFsdWUpO1xyXG4gICAgfVxyXG5cclxuICAgIHNlYXJjaE11bHRpKF9ldmVudDogYW55LCBfc3RhdGU6IHN0cmluZyk6IHZvaWQge1xyXG4gICAgICAgIGxldCBxdWVyeTogc3RyaW5nID0gdGhpcy5fdGV4dElucHV0U3ZjLmNoZWNrUXVlcnkoX2V2ZW50KTtcclxuXHJcbiAgICAgICAgaWYgKHR5cGVvZiB0aGlzLl9yZXN1bHRMaXN0ICE9PSAndW5kZWZpbmVkJykge1xyXG4gICAgICAgICAgICBsZXQgc2VhcmNoUmVzdWx0OiBBcnJheTxhbnk+ID0gdGhpcy5fdGV4dElucHV0U3ZjLnNlYXJjaExpc3QocXVlcnksIHRoaXMuX3Jlc3VsdExpc3QpO1xyXG4gICAgICAgICAgICB0aGlzLl9jaGVja1NlYXJjaFJlc3VsdChzZWFyY2hSZXN1bHQsIHF1ZXJ5KTtcclxuICAgICAgICB9XHJcbiAgICAgICAgZWxzZSB7XHJcbiAgICAgICAgICAgIHRoaXMuX2NoZWNrTG9hZGluZ0Z1bmMocXVlcnkpO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICBtdWx0aVNlbGVjdGlvbih2YWw6IGFueSwgc3RhdGU6IHN0cmluZyk6IHZvaWQge1xyXG4gICAgICAgIGlmICh0aGlzLl90ZXh0U2V0dGluZy5tdWx0aXNlbGVjdCAmJiB0eXBlb2YgdGhpcy5fcmVzdWx0TGlzdCAhPT0gJ3VuZGVmaW5lZCcpIHtcclxuICAgICAgICAgICAgdGhpcy5fdXBkYXRlUmVzdWx0TGlzdCh2YWwsIHN0YXRlKTtcclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgY2hlY2tFbnRlckFuZEVycm9yKGV2ZW50OiBhbnkpOiB2b2lkIHtcclxuICAgICAgICBsZXQgaW5wdXRWYWw6IHN0cmluZyA9IGV2ZW50LnRhcmdldC52YWx1ZTtcclxuXHJcbiAgICAgICAgaWYgKGlucHV0VmFsLmxlbmd0aCA8IHRoaXMuX3RleHRTZXR0aW5nLm1pbkxlbmd0aCkge1xyXG4gICAgICAgICAgICB0aGlzLmNvbmZpZy5lcnJvcnMgPSB1bmRlZmluZWQ7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICBpZiAoZXZlbnQua2V5ID09PSAnQmFja3NwYWNlJyAmJiB0eXBlb2YgdGhpcy5jb25maWcuZHJvcGRvd25DYWxsYmFjayAhPT0gJ3VuZGVmaW5lZCcgJiYgIXRoaXMuX3RleHRTZXR0aW5nLmVudGVyKSB7XHJcbiAgICAgICAgICAgIGlmICh0eXBlb2YgdGhpcy5fc3Vic2NyaXB0aW9uICE9PSAndW5kZWZpbmVkJykge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5fc3Vic2NyaXB0aW9uLnVuc3Vic2NyaWJlKCk7XHJcbiAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgIHRoaXMuX2lzTG9hZGluZyA9IGZhbHNlO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgaWYgKGV2ZW50LmtleSA9PT0gJ0VudGVyJyAmJiB0eXBlb2YgaW5wdXRWYWwgIT09ICd1bmRlZmluZWQnICYmIGlucHV0VmFsICE9PSAnJykge1xyXG4gICAgICAgICAgICBpZiAodGhpcy5fdGV4dFNldHRpbmcubXVsdGlzZWxlY3QpIHtcclxuICAgICAgICAgICAgICAgIHRoaXMuc2VhcmNoTXVsdGkoaW5wdXRWYWwsICdzZWxlY3RlZCcpO1xyXG4gICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICBlbHNlIGlmICghdGhpcy5fdGV4dFNldHRpbmcubXVsdGlzZWxlY3QgJiYgdHlwZW9mIHRoaXMuY29uZmlnLnZhbHVlICE9PSAndW5kZWZpbmVkJyAmJiB0eXBlb2YgdGhpcy5jb25maWcudmFsdWUgIT09ICdvYmplY3QnKSB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLnNlYXJjaE11bHRpKGlucHV0VmFsLCAnc2VsZWN0ZWQnKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF9hZGRDbGlja0xpc3RlbmVyKF9xdWVyeVN0cmluZzogc3RyaW5nKTogdm9pZCB7XHJcbiAgICAgICAgbGV0IGNsaWNrRXZlbnRFbGU6IEhUTUxFbGVtZW50ID0gdGhpcy5fdmNyLmVsZW1lbnQubmF0aXZlRWxlbWVudC5xdWVyeVNlbGVjdG9yKF9xdWVyeVN0cmluZyk7XHJcblxyXG4gICAgICAgIHRoaXMuX3JlbmRlcmVyTGlzdGVuRnVuYyA9IHRoaXMuX3JlbmRlcmVyLmxpc3RlbihjbGlja0V2ZW50RWxlLCAnY2xpY2snLCAoX2V2ZW50OiBhbnkpOiB2b2lkID0+IHtcclxuICAgIHRoaXMuYXV0b2NvbXBsZXRlQ29tcG9uZW50LmhhbmRsZURyb3Bkb3duQ2xpY2soX2V2ZW50KTtcclxufSk7XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfdXBkYXRlUmVzdWx0TGlzdChfdmFsOiBhbnksIF9zdGF0ZTogc3RyaW5nKTogdm9pZCB7XHJcbiAgICAgICAgaWYgKF9zdGF0ZSA9PT0gJ3NlbGVjdGVkJykge1xyXG4gICAgICAgICAgICBmb3IgKGxldCBpOiBudW1iZXIgPSAwOyBpIDwgdGhpcy5fcmVzdWx0TGlzdC5sZW5ndGg7IGkrKykge1xyXG4gICAgICAgICAgICAgICAgaWYgKF92YWwudmFsdWUgPT09IHRoaXMuX3Jlc3VsdExpc3RbaV0udmFsdWUpIHtcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLl9yZXN1bHRMaXN0LnNwbGljZShpLCAxKTtcclxuICAgICAgICAgICAgICAgICAgICBicmVhaztcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgbGV0IHNvcnRGdW5jOiAoYTogYW55LCBiOiBhbnkpID0+IG51bWJlciA9IChhOiBhbnksIGI6IGFueSk6IG51bWJlciA9PiB7XHJcbiAgICAgICAgICAgICAgICBpZiAoYS52YWx1ZSA8IGIudmFsdWUpIHJldHVybiAtMTtcclxuICAgICAgICAgICAgICAgIGVsc2UgaWYgKGEudmFsdWUgPiBiLnZhbHVlKSByZXR1cm4gMTtcclxuICAgICAgICAgICAgICAgIHJldHVybiAwO1xyXG4gICAgICAgICAgICB9O1xyXG5cclxuICAgICAgICAgICAgdGhpcy5fcmVzdWx0TGlzdC5wdXNoKF92YWwpO1xyXG4gICAgICAgICAgICB0aGlzLl9yZXN1bHRMaXN0LnNvcnQoc29ydEZ1bmMpO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF9jaGVja1NlYXJjaFJlc3VsdChfdmFsdWU6IEFycmF5PGFueT4sIF9xdWVyeTogc3RyaW5nKTogdm9pZCB7XHJcbiAgICAgICAgbGV0IGZpbHRlcmVkT3B0aW9uczogQXJyYXk8YW55PiA9IHRoaXMuX3RleHRJbnB1dFN2Yy5maWx0ZXJPcHRpb25MaXN0KF92YWx1ZSwgdGhpcy5fdGV4dFZhbHVlKTtcclxuXHJcbiAgICAgICAgdGltZXIoKS5zdWJzY3JpYmUoKCk6IHZvaWQgPT4ge1xyXG4gICAgICAgICAgICB0aGlzLl9zdWdnZXN0aW9uTGlzdCA9IGZpbHRlcmVkT3B0aW9ucy5zbGljZSgpO1xyXG5cclxuICAgICAgICAgICAgbGV0IGNoZWNrZWRSZXN1bHQgPSB0aGlzLl90ZXh0SW5wdXRTdmMuY2hlY2tFcnJvcih0aGlzLl9zdWdnZXN0aW9uTGlzdCwgX3F1ZXJ5KTtcclxuXHJcbiAgICAgICAgICAgIGlmICh0eXBlb2YgY2hlY2tlZFJlc3VsdCAhPT0gJ3VuZGVmaW5lZCcpIHtcclxuICAgICAgICAgICAgICAgIGxldCByZXN1bHQ6IEFycmF5PHN0cmluZz4gPSBbXTtcclxuICAgICAgICAgICAgICAgIHJlc3VsdC5wdXNoKGNoZWNrZWRSZXN1bHQuZGlhbG9ndWVNZXNzYWdlKTtcclxuICAgICAgICAgICAgICAgIHRoaXMuY29uZmlnLmVycm9ycyA9IHJlc3VsdDtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH0pO1xyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX2NoZWNrTG9hZGluZ0Z1bmMoX3F1ZXJ5OiBzdHJpbmcpOiB2b2lkIHtcclxuICAgICAgICB0aGlzLl9pc0xvYWRpbmcgPSB0cnVlO1xyXG5cclxuICAgICAgICBsZXQgc2VsZWN0ZWRWYWwgPSAodHlwZW9mIHRoaXMuY29uZmlnLnZhbHVlICE9PSAndW5kZWZpbmVkJykgPyB0aGlzLmNvbmZpZy52YWx1ZSA6IFtdO1xyXG4gICAgICAgIGxldCBwYXJhbXMgPSB7cXVlcnk6IF9xdWVyeSwgY3VycmVudFNlbGVjdGVkOiBzZWxlY3RlZFZhbH07XHJcblxyXG4gICAgICAgIGlmICh0eXBlb2YgdGhpcy5fc3Vic2NyaXB0aW9uICE9PSAndW5kZWZpbmVkJykge1xyXG4gICAgICAgICAgICB0aGlzLl9zdWJzY3JpcHRpb24udW5zdWJzY3JpYmUoKTtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIHRoaXMuX3N1YnNjcmlwdGlvbiA9IHRoaXMuY29uZmlnLmRyb3Bkb3duQ2FsbGJhY2socGFyYW1zKS5zdWJzY3JpYmUoKF92YWx1ZTogYW55KTogdm9pZCA9PiB7XHJcbiAgICAgICAgICAgIC8vIGNvbnNvbGUubG9nKFwiPj4+IHZhbHVlXCIsIF92YWx1ZSk7XHJcbiAgICAgICAgICAgIHRoaXMuX2NoZWNrU2VhcmNoUmVzdWx0KF92YWx1ZSwgX3F1ZXJ5KTtcclxuICAgICAgICAgICAgdGhpcy5faXNMb2FkaW5nID0gZmFsc2U7XHJcbiAgICAgICAgfSk7XHJcbiAgICB9XHJcbn1cclxuIl19