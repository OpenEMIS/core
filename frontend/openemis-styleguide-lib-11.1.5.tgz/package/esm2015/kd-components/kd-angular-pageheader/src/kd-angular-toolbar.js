import { timer as observableTimer } from 'rxjs';
/****************************************************************************************
    Component file     : kd-angular-toolbar.ts
    Service file       : kd-angular-toolbar-svc.ts
    Event file         : kd-toolbar-event.ts
    Interface file     : kd-angular-pageheader-interface.ts
    Version            : 2.0
    Created by         : Cheng Kok Keong
    Purpose            : Show the toolbars and search input in the template area under breadcrumb

    Behaviour           :
        - Search button in web view is able to see the search box and able to
          search straight in the input field
        - Search button in mobile view is a button with the input field hidden.
          Only when clicked, the input field will takes up 100% width for search

        - Behaviour for search button element (cross icon):
            -----------------------------------------------------------------------------
            | View Type   | Search Text exist  | Behaviour                              |
            -----------------------------------------------------------------------------
            | Windows     | (/)                | Cross icon will show, when clicked,    |
            |             |                    | remove search text and hide cross icon.|
            |             |                    |                                        |
            |             | (x)                | Cross icon is hidden.                  |
            -----------------------------------------------------------------------------
            | Mobile      | (/)                | Cross icon will show, when clicked,    |
            |             |                    | remove search text, and behaves like   |
            |             |                    | Mobile - No search text                |
            |             |                    |                                        |
            |             | (x)                | Cross icon will show, when clicked     |
            |             |                    | close the search input.                |
            -----------------------------------------------------------------------------


    Last changes       :
        - Rewrite component and service

 ****************************************************************************************/
import { Component, ViewEncapsulation, Input, Output, EventEmitter } from '@angular/core';
import { Router } from '@angular/router';
import { KdToolbarSvc } from './kd-angular-toolbar-svc';
import { KdToolbarEvent } from './kd-toolbar-event';
export class KdToolbar {
    constructor(_router, _toolbarSvc, _toolbarEvent) {
        this._router = _router;
        this._toolbarSvc = _toolbarSvc;
        this._toolbarEvent = _toolbarEvent;
        this.searchExpend = false;
        this.showSearchCloseBtn = false;
        this.searchTextChanged = new EventEmitter();
    }
    /************************* Life cycles functions *****************************/
    ngOnInit() {
        // console.log('-- KdToolbar: OnInit -- ', this.config);
        if (typeof this.config !== 'undefined') {
            this._updateLeftToolbar(this.config);
            this._updateSearchCloseBtn();
        }
    }
    ngOnChanges(_simpleChanges) {
        // console.log('-- KdToolbar: OnChanges -- ', _simpleChanges);
        if (_simpleChanges.hasOwnProperty('config') && typeof _simpleChanges['config'].currentValue !== 'undefined') {
            this._updateLeftToolbar(this.config);
            this._updateSearchCloseBtn();
        }
        if (_simpleChanges.hasOwnProperty('mobileView')) {
            this._checkToShowSearchClose();
            if (!this.mobileView) {
                this.searchExpend = false;
            }
        }
    }
    ngAfterViewInit() {
        // console.log('-- KdToolbar: AfterViewInit -- ');
        observableTimer().subscribe(() => {
            this._checkToShowSearchClose();
        });
    }
    ngOnDestroy() {
        // console.log('-- KdToolbar: OnDestroy -- ');
    }
    /**************************** Events functions *******************************/
    ///////////////////////////////////////////////////////
    /// Button events
    ///////////////////////////////////////////////////////
    buttonClick(_e, _button) {
        // console.log('-- KdToolbar: Button clicked -- ', _button);
        if (typeof _button.path !== 'undefined') {
            this._router.navigate([_button.path]);
        }
        else if (typeof _button.callback !== 'undefined') {
            _button.callback();
        }
        else {
            console.error('KdToolbar: Button is clicked but no path or callback is specified.');
        }
    }
    ///////////////////////////////////////////////////////
    /// Search functions
    ///////////////////////////////////////////////////////
    searchClicked() {
        if (!this.mobileView)
            return;
        this.searchExpend = !this.searchExpend;
        this._checkToShowSearchClose();
    }
    searchChanged(_event) {
        // console.log('-- KdToolbar: Search text changed -- ', _event);
        if (typeof this.config.searchCallback !== 'undefined') {
            this.config.searchCallback(_event);
        }
        this._updateSearchCloseBtn();
        this._emitSearchTextChanged();
    }
    searchCloseClicked() {
        // console.log('-- KdToolbar: Search close clicked -- ');
        if (this.mobileView) {
            if (this.config.searchText !== '') {
                this._clearSearch();
            }
            else {
                this.searchExpend = false;
                this.showSearchCloseBtn = false;
            }
        }
        else {
            this._clearSearch();
            this.showSearchCloseBtn = false;
        }
    }
    /**************************** Private functions ******************************/
    ///////////////////////////////////////////////////////
    /// DOM function
    ///////////////////////////////////////////////////////
    _checkToShowSearchClose() {
        if (this.mobileView) {
            this.showSearchCloseBtn = this.searchExpend;
        }
        else {
            this.showSearchCloseBtn = this.config.searchText !== '';
        }
    }
    _clearSearch() {
        this.config.searchText = '';
        this._emitSearchTextChanged();
    }
    _updateSearchCloseBtn() {
        if (!this.mobileView) {
            this.showSearchCloseBtn = this.config.searchText !== '';
        }
    }
    ///////////////////////////////////////////////////////
    /// Update Toolbar buttons function
    ///////////////////////////////////////////////////////
    _updateLeftToolbar(_config) {
        _config.leftBtn = this._toolbarSvc.updateLeftToolbar(_config.leftBtn);
    }
    ///////////////////////////////////////////////////////
    /// Emitter function
    ///////////////////////////////////////////////////////
    _emitSearchTextChanged() {
        this.searchTextChanged.emit(this.config.searchText);
        this._toolbarEvent.sendSearchText(this.config.searchText);
    }
}
KdToolbar.decorators = [
    { type: Component, args: [{
                selector: 'kd-toolbar',
                template: "<div class='kdx-toolbar'>\r\n\r\n    <!-- Left toolbar -->\r\n    <div *ngIf='config.leftBtn.length > 0' class='kdx-toolbar-left'>\r\n        <ng-template ngFor let-item [ngForOf]='config.leftBtn'>\r\n\r\n            <!-- Normal button -->\r\n            <button *ngIf='item.type != \"more\"' type='button' (click)='buttonClick($event, item)' class='btn btn-icon btn-xs' placement='bottom' ngbTooltip='{{item.tooltip}}'>\r\n                <i class='{{item.icon}}'></i>\r\n            </button>\r\n\r\n            <!-- More button -->\r\n            <div *ngIf='item.type == \"more\"' ngbDropdown class=\"d-inline-block more-btn\">\r\n                <button class=\"btn btn-outline-primary\" id=\"moreDropdown\" ngbDropdownToggle  placement=\"bottom\"  ngbTooltip=\"{{item.tooltip}}\">\r\n                    <i class=\"{{item.icon}}\"></i>\r\n                </button>\r\n                <div ngbDropdownMenu class=\"dropdown-menu\" aria-labelledby=\"moreDropdown\">\r\n                    <ng-template ngFor let-item [ngForOf]=\"item.dropdown\">\r\n                        <button type='button' class='dropdown-item' (click)='buttonClick($event, item)'>{{item.text}}</button>\r\n                    </ng-template>\r\n                </div>\r\n            </div>\r\n\r\n        </ng-template>\r\n    </div>\r\n\r\n    <!-- Right toolbar -->\r\n    <div class='kdx-toolbar-right' [ngClass]=\"{'has-more-btn': config.moreAction.length > 0, 'full-width': mobileView && searchExpend}\">\r\n\r\n        <!-- Search -->\r\n        <div *ngIf=\"config.searchBtn\" class=\"kdx-search-wrapper\" [ngClass]=\"{ 'collapsed': !searchExpend && mobileView, 'expend': searchExpend && mobileView }\">\r\n            <div class=\"kdx-search-icon\" [ngClass]=\"{ 'btn btn-icon': mobileView }\" (click)=\"searchClicked()\">\r\n                <i class=\"fa fa-search\"></i>\r\n            </div>\r\n            <input type=\"text\" [hidden]=\"mobileView && !searchExpend\" class=\"form-control search-input\" [(ngModel)]=\"config.searchText\" (ngModelChange)=\"searchChanged($event)\" placeholder=\"{{config.searchPlaceholder}}\">\r\n            <button class=\"btn btn-icon close-btn\" *ngIf=\"showSearchCloseBtn\" (click)=\"searchCloseClicked()\" type=\"button\">\r\n                <i class=\"kd-close-round\"></i>\r\n           </button>\r\n        </div>\r\n\r\n        <!-- More action -->\r\n        <div *ngIf='config.moreAction.length > 0' class='btn-dropdown' ngbDropdown>\r\n            <button type=\"button\" class=\"btn btn-icon btn-xs\" placement=\"bottom\" ngbTooltip=\"More\" id=\"moreActionMenu\" ngbDropdownToggle>\r\n                <i class=\"kd-ellipsis\"></i>\r\n            </button>\r\n            <div ngbDropdownMenu class=\"dropdown-menu\" aria-labelledby=\"moreActionMenu\">\r\n                <ng-template ngFor let-item [ngForOf]=\"config.moreAction\">\r\n                    <button (click)='buttonClick($event, item)' class='dropdown-item'>{{item.text}}</button>\r\n                </ng-template>\r\n            </div>\r\n        </div>\r\n\r\n    </div>\r\n</div>",
                encapsulation: ViewEncapsulation.None,
                providers: [KdToolbarSvc]
            },] }
];
KdToolbar.ctorParameters = () => [
    { type: Router },
    { type: KdToolbarSvc },
    { type: KdToolbarEvent }
];
KdToolbar.propDecorators = {
    config: [{ type: Input }],
    mobileView: [{ type: Input }],
    searchTextChanged: [{ type: Output }]
};
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoia2QtYW5ndWxhci10b29sYmFyLmpzIiwic291cmNlUm9vdCI6IkM6L3hhbXBwL2h0ZG9jcy9TdHlsZWd1aWRlL2lvc3RnLW9wZW5lbWlzLXN0eWxlZ3VpZGUvcHJvamVjdHMvb3BlbmVtaXMtc3R5bGVndWlkZS1saWIvc3JjLyIsInNvdXJjZXMiOlsia2QtY29tcG9uZW50cy9rZC1hbmd1bGFyLXBhZ2VoZWFkZXIvc3JjL2tkLWFuZ3VsYXItdG9vbGJhci50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFDQSxPQUFPLEVBQUMsS0FBSyxJQUFJLGVBQWUsRUFBRSxNQUFNLE1BQU0sQ0FBQztBQUMvQzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OzBGQW9DMEY7QUFJMUYsT0FBTyxFQUNILFNBQVMsRUFDVCxpQkFBaUIsRUFDakIsS0FBSyxFQUNMLE1BQU0sRUFDTixZQUFZLEVBTWYsTUFBTSxlQUFlLENBQUM7QUFDdkIsT0FBTyxFQUFFLE1BQU0sRUFBRSxNQUFNLGlCQUFpQixDQUFDO0FBQ3pDLE9BQU8sRUFBRSxZQUFZLEVBQUUsTUFBTSwwQkFBMEIsQ0FBQztBQUN4RCxPQUFPLEVBQUUsY0FBYyxFQUFFLE1BQU0sb0JBQW9CLENBQUM7QUFVcEQsTUFBTSxPQUFPLFNBQVM7SUFRbEIsWUFDWSxPQUFlLEVBQ2YsV0FBeUIsRUFDekIsYUFBNkI7UUFGN0IsWUFBTyxHQUFQLE9BQU8sQ0FBUTtRQUNmLGdCQUFXLEdBQVgsV0FBVyxDQUFjO1FBQ3pCLGtCQUFhLEdBQWIsYUFBYSxDQUFnQjtRQVZsQyxpQkFBWSxHQUFZLEtBQUssQ0FBQztRQUM5Qix1QkFBa0IsR0FBWSxLQUFLLENBQUM7UUFJakMsc0JBQWlCLEdBQXlCLElBQUksWUFBWSxFQUFVLENBQUM7SUFNM0UsQ0FBQztJQUVMLCtFQUErRTtJQUMvRSxRQUFRO1FBQ0osd0RBQXdEO1FBQ3hELElBQUksT0FBTyxJQUFJLENBQUMsTUFBTSxLQUFLLFdBQVcsRUFBRTtZQUNwQyxJQUFJLENBQUMsa0JBQWtCLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDO1lBQ3JDLElBQUksQ0FBQyxxQkFBcUIsRUFBRSxDQUFDO1NBQ2hDO0lBQ0wsQ0FBQztJQUVELFdBQVcsQ0FBQyxjQUE2QjtRQUNyQyw4REFBOEQ7UUFDOUQsSUFBSSxjQUFjLENBQUMsY0FBYyxDQUFDLFFBQVEsQ0FBQyxJQUFJLE9BQU8sY0FBYyxDQUFDLFFBQVEsQ0FBQyxDQUFDLFlBQVksS0FBSyxXQUFXLEVBQUU7WUFDekcsSUFBSSxDQUFDLGtCQUFrQixDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQztZQUNyQyxJQUFJLENBQUMscUJBQXFCLEVBQUUsQ0FBQztTQUNoQztRQUVELElBQUksY0FBYyxDQUFDLGNBQWMsQ0FBQyxZQUFZLENBQUMsRUFBRTtZQUM3QyxJQUFJLENBQUMsdUJBQXVCLEVBQUUsQ0FBQztZQUUvQixJQUFJLENBQUMsSUFBSSxDQUFDLFVBQVUsRUFBRTtnQkFDbEIsSUFBSSxDQUFDLFlBQVksR0FBRyxLQUFLLENBQUM7YUFDN0I7U0FDSjtJQUNMLENBQUM7SUFFRCxlQUFlO1FBQ1gsa0RBQWtEO1FBQ2xELGVBQWUsRUFBRSxDQUFDLFNBQVMsQ0FBQyxHQUFTLEVBQUU7WUFDbkMsSUFBSSxDQUFDLHVCQUF1QixFQUFFLENBQUM7UUFDbkMsQ0FBQyxDQUFDLENBQUM7SUFDUCxDQUFDO0lBRUQsV0FBVztRQUNQLDhDQUE4QztJQUNsRCxDQUFDO0lBRUQsK0VBQStFO0lBQy9FLHVEQUF1RDtJQUN2RCxpQkFBaUI7SUFDakIsdURBQXVEO0lBQ2hELFdBQVcsQ0FBQyxFQUFTLEVBQUUsT0FBdUI7UUFDakQsNERBQTREO1FBQzVELElBQUksT0FBTyxPQUFPLENBQUMsSUFBSSxLQUFLLFdBQVcsRUFBRTtZQUNyQyxJQUFJLENBQUMsT0FBTyxDQUFDLFFBQVEsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDO1NBQ3pDO2FBQ0ksSUFBSSxPQUFPLE9BQU8sQ0FBQyxRQUFRLEtBQUssV0FBVyxFQUFFO1lBQzlDLE9BQU8sQ0FBQyxRQUFRLEVBQUUsQ0FBQztTQUN0QjthQUNJO1lBQ0QsT0FBTyxDQUFDLEtBQUssQ0FBQyxvRUFBb0UsQ0FBQyxDQUFDO1NBQ3ZGO0lBQ0wsQ0FBQztJQUVELHVEQUF1RDtJQUN2RCxvQkFBb0I7SUFDcEIsdURBQXVEO0lBQ2hELGFBQWE7UUFDaEIsSUFBSSxDQUFDLElBQUksQ0FBQyxVQUFVO1lBQUUsT0FBTztRQUU3QixJQUFJLENBQUMsWUFBWSxHQUFHLENBQUMsSUFBSSxDQUFDLFlBQVksQ0FBQztRQUN2QyxJQUFJLENBQUMsdUJBQXVCLEVBQUUsQ0FBQztJQUNuQyxDQUFDO0lBRU0sYUFBYSxDQUFDLE1BQWM7UUFDL0IsZ0VBQWdFO1FBQ2hFLElBQUksT0FBTyxJQUFJLENBQUMsTUFBTSxDQUFDLGNBQWMsS0FBSyxXQUFXLEVBQUU7WUFDbkQsSUFBSSxDQUFDLE1BQU0sQ0FBQyxjQUFjLENBQUMsTUFBTSxDQUFDLENBQUM7U0FDdEM7UUFFRCxJQUFJLENBQUMscUJBQXFCLEVBQUUsQ0FBQztRQUM3QixJQUFJLENBQUMsc0JBQXNCLEVBQUUsQ0FBQztJQUNsQyxDQUFDO0lBRU0sa0JBQWtCO1FBQ3JCLHlEQUF5RDtRQUN6RCxJQUFJLElBQUksQ0FBQyxVQUFVLEVBQUU7WUFDakIsSUFBSSxJQUFJLENBQUMsTUFBTSxDQUFDLFVBQVUsS0FBSyxFQUFFLEVBQUU7Z0JBQy9CLElBQUksQ0FBQyxZQUFZLEVBQUUsQ0FBQzthQUN2QjtpQkFDSTtnQkFDRCxJQUFJLENBQUMsWUFBWSxHQUFHLEtBQUssQ0FBQztnQkFDMUIsSUFBSSxDQUFDLGtCQUFrQixHQUFHLEtBQUssQ0FBQzthQUNuQztTQUNKO2FBQ0k7WUFDRCxJQUFJLENBQUMsWUFBWSxFQUFFLENBQUM7WUFDcEIsSUFBSSxDQUFDLGtCQUFrQixHQUFHLEtBQUssQ0FBQztTQUNuQztJQUNMLENBQUM7SUFFRCwrRUFBK0U7SUFDL0UsdURBQXVEO0lBQ3ZELGdCQUFnQjtJQUNoQix1REFBdUQ7SUFDL0MsdUJBQXVCO1FBQzNCLElBQUksSUFBSSxDQUFDLFVBQVUsRUFBRTtZQUNqQixJQUFJLENBQUMsa0JBQWtCLEdBQUcsSUFBSSxDQUFDLFlBQVksQ0FBQztTQUMvQzthQUNJO1lBQ0QsSUFBSSxDQUFDLGtCQUFrQixHQUFHLElBQUksQ0FBQyxNQUFNLENBQUMsVUFBVSxLQUFLLEVBQUUsQ0FBQztTQUMzRDtJQUNMLENBQUM7SUFFTyxZQUFZO1FBQ2hCLElBQUksQ0FBQyxNQUFNLENBQUMsVUFBVSxHQUFHLEVBQUUsQ0FBQztRQUM1QixJQUFJLENBQUMsc0JBQXNCLEVBQUUsQ0FBQztJQUNsQyxDQUFDO0lBRU8scUJBQXFCO1FBQ3pCLElBQUksQ0FBQyxJQUFJLENBQUMsVUFBVSxFQUFFO1lBQ2xCLElBQUksQ0FBQyxrQkFBa0IsR0FBRyxJQUFJLENBQUMsTUFBTSxDQUFDLFVBQVUsS0FBSyxFQUFFLENBQUM7U0FDM0Q7SUFDTCxDQUFDO0lBRUQsdURBQXVEO0lBQ3ZELG1DQUFtQztJQUNuQyx1REFBdUQ7SUFDL0Msa0JBQWtCLENBQUMsT0FBdUI7UUFDOUMsT0FBTyxDQUFDLE9BQU8sR0FBRyxJQUFJLENBQUMsV0FBVyxDQUFDLGlCQUFpQixDQUFDLE9BQU8sQ0FBQyxPQUFPLENBQUMsQ0FBQztJQUMxRSxDQUFDO0lBRUQsdURBQXVEO0lBQ3ZELG9CQUFvQjtJQUNwQix1REFBdUQ7SUFDL0Msc0JBQXNCO1FBQzFCLElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxVQUFVLENBQUMsQ0FBQztRQUNwRCxJQUFJLENBQUMsYUFBYSxDQUFDLGNBQWMsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLFVBQVUsQ0FBQyxDQUFDO0lBQzlELENBQUM7OztZQXBKSixTQUFTLFNBQUM7Z0JBQ1AsUUFBUSxFQUFFLFlBQVk7Z0JBQ3RCLG1oR0FBd0M7Z0JBQ3hDLGFBQWEsRUFBRSxpQkFBaUIsQ0FBQyxJQUFJO2dCQUNyQyxTQUFTLEVBQUUsQ0FBQyxZQUFZLENBQUM7YUFDNUI7OztZQVZRLE1BQU07WUFDTixZQUFZO1lBQ1osY0FBYzs7O3FCQWNsQixLQUFLO3lCQUNMLEtBQUs7Z0NBQ0wsTUFBTSIsInNvdXJjZXNDb250ZW50IjpbIlxyXG5pbXBvcnQge3RpbWVyIGFzIG9ic2VydmFibGVUaW1lciB9IGZyb20gJ3J4anMnO1xyXG4vKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKlxyXG4gICAgQ29tcG9uZW50IGZpbGUgICAgIDoga2QtYW5ndWxhci10b29sYmFyLnRzXHJcbiAgICBTZXJ2aWNlIGZpbGUgICAgICAgOiBrZC1hbmd1bGFyLXRvb2xiYXItc3ZjLnRzXHJcbiAgICBFdmVudCBmaWxlICAgICAgICAgOiBrZC10b29sYmFyLWV2ZW50LnRzXHJcbiAgICBJbnRlcmZhY2UgZmlsZSAgICAgOiBrZC1hbmd1bGFyLXBhZ2VoZWFkZXItaW50ZXJmYWNlLnRzXHJcbiAgICBWZXJzaW9uICAgICAgICAgICAgOiAyLjBcclxuICAgIENyZWF0ZWQgYnkgICAgICAgICA6IENoZW5nIEtvayBLZW9uZ1xyXG4gICAgUHVycG9zZSAgICAgICAgICAgIDogU2hvdyB0aGUgdG9vbGJhcnMgYW5kIHNlYXJjaCBpbnB1dCBpbiB0aGUgdGVtcGxhdGUgYXJlYSB1bmRlciBicmVhZGNydW1iXHJcblxyXG4gICAgQmVoYXZpb3VyICAgICAgICAgICA6XHJcbiAgICAgICAgLSBTZWFyY2ggYnV0dG9uIGluIHdlYiB2aWV3IGlzIGFibGUgdG8gc2VlIHRoZSBzZWFyY2ggYm94IGFuZCBhYmxlIHRvXHJcbiAgICAgICAgICBzZWFyY2ggc3RyYWlnaHQgaW4gdGhlIGlucHV0IGZpZWxkXHJcbiAgICAgICAgLSBTZWFyY2ggYnV0dG9uIGluIG1vYmlsZSB2aWV3IGlzIGEgYnV0dG9uIHdpdGggdGhlIGlucHV0IGZpZWxkIGhpZGRlbi5cclxuICAgICAgICAgIE9ubHkgd2hlbiBjbGlja2VkLCB0aGUgaW5wdXQgZmllbGQgd2lsbCB0YWtlcyB1cCAxMDAlIHdpZHRoIGZvciBzZWFyY2hcclxuXHJcbiAgICAgICAgLSBCZWhhdmlvdXIgZm9yIHNlYXJjaCBidXR0b24gZWxlbWVudCAoY3Jvc3MgaWNvbik6XHJcbiAgICAgICAgICAgIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXHJcbiAgICAgICAgICAgIHwgVmlldyBUeXBlICAgfCBTZWFyY2ggVGV4dCBleGlzdCAgfCBCZWhhdmlvdXIgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB8XHJcbiAgICAgICAgICAgIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXHJcbiAgICAgICAgICAgIHwgV2luZG93cyAgICAgfCAoLykgICAgICAgICAgICAgICAgfCBDcm9zcyBpY29uIHdpbGwgc2hvdywgd2hlbiBjbGlja2VkLCAgICB8XHJcbiAgICAgICAgICAgIHwgICAgICAgICAgICAgfCAgICAgICAgICAgICAgICAgICAgfCByZW1vdmUgc2VhcmNoIHRleHQgYW5kIGhpZGUgY3Jvc3MgaWNvbi58XHJcbiAgICAgICAgICAgIHwgICAgICAgICAgICAgfCAgICAgICAgICAgICAgICAgICAgfCAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB8XHJcbiAgICAgICAgICAgIHwgICAgICAgICAgICAgfCAoeCkgICAgICAgICAgICAgICAgfCBDcm9zcyBpY29uIGlzIGhpZGRlbi4gICAgICAgICAgICAgICAgICB8XHJcbiAgICAgICAgICAgIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXHJcbiAgICAgICAgICAgIHwgTW9iaWxlICAgICAgfCAoLykgICAgICAgICAgICAgICAgfCBDcm9zcyBpY29uIHdpbGwgc2hvdywgd2hlbiBjbGlja2VkLCAgICB8XHJcbiAgICAgICAgICAgIHwgICAgICAgICAgICAgfCAgICAgICAgICAgICAgICAgICAgfCByZW1vdmUgc2VhcmNoIHRleHQsIGFuZCBiZWhhdmVzIGxpa2UgICB8XHJcbiAgICAgICAgICAgIHwgICAgICAgICAgICAgfCAgICAgICAgICAgICAgICAgICAgfCBNb2JpbGUgLSBObyBzZWFyY2ggdGV4dCAgICAgICAgICAgICAgICB8XHJcbiAgICAgICAgICAgIHwgICAgICAgICAgICAgfCAgICAgICAgICAgICAgICAgICAgfCAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB8XHJcbiAgICAgICAgICAgIHwgICAgICAgICAgICAgfCAoeCkgICAgICAgICAgICAgICAgfCBDcm9zcyBpY29uIHdpbGwgc2hvdywgd2hlbiBjbGlja2VkICAgICB8XHJcbiAgICAgICAgICAgIHwgICAgICAgICAgICAgfCAgICAgICAgICAgICAgICAgICAgfCBjbG9zZSB0aGUgc2VhcmNoIGlucHV0LiAgICAgICAgICAgICAgICB8XHJcbiAgICAgICAgICAgIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXHJcblxyXG5cclxuICAgIExhc3QgY2hhbmdlcyAgICAgICA6XHJcbiAgICAgICAgLSBSZXdyaXRlIGNvbXBvbmVudCBhbmQgc2VydmljZVxyXG5cclxuICoqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKiovXHJcblxyXG5cclxuXHJcbmltcG9ydCB7XHJcbiAgICBDb21wb25lbnQsXHJcbiAgICBWaWV3RW5jYXBzdWxhdGlvbixcclxuICAgIElucHV0LFxyXG4gICAgT3V0cHV0LFxyXG4gICAgRXZlbnRFbWl0dGVyLFxyXG4gICAgT25Jbml0LFxyXG4gICAgT25DaGFuZ2VzLFxyXG4gICAgU2ltcGxlQ2hhbmdlcyxcclxuICAgIEFmdGVyVmlld0luaXQsXHJcbiAgICBPbkRlc3Ryb3lcclxufSBmcm9tICdAYW5ndWxhci9jb3JlJztcclxuaW1wb3J0IHsgUm91dGVyIH0gZnJvbSAnQGFuZ3VsYXIvcm91dGVyJztcclxuaW1wb3J0IHsgS2RUb29sYmFyU3ZjIH0gZnJvbSAnLi9rZC1hbmd1bGFyLXRvb2xiYXItc3ZjJztcclxuaW1wb3J0IHsgS2RUb29sYmFyRXZlbnQgfSBmcm9tICcuL2tkLXRvb2xiYXItZXZlbnQnO1xyXG5pbXBvcnQgeyBJVG9vbGJhckNvbmZpZywgSVRvb2xiYXJCdXR0b24gfSBmcm9tICcuLi9rZC1hbmd1bGFyLXBhZ2VoZWFkZXItaW50ZXJmYWNlJztcclxuXHJcbkBDb21wb25lbnQoe1xyXG4gICAgc2VsZWN0b3I6ICdrZC10b29sYmFyJyxcclxuICAgIHRlbXBsYXRlVXJsOiAnLi9rZC1hbmd1bGFyLXRvb2xiYXIuaHRtbCcsXHJcbiAgICBlbmNhcHN1bGF0aW9uOiBWaWV3RW5jYXBzdWxhdGlvbi5Ob25lLFxyXG4gICAgcHJvdmlkZXJzOiBbS2RUb29sYmFyU3ZjXVxyXG59KVxyXG5cclxuZXhwb3J0IGNsYXNzIEtkVG9vbGJhciBpbXBsZW1lbnRzIE9uSW5pdCwgT25DaGFuZ2VzLCBBZnRlclZpZXdJbml0LCBPbkRlc3Ryb3kge1xyXG4gICAgcHVibGljIHNlYXJjaEV4cGVuZDogYm9vbGVhbiA9IGZhbHNlO1xyXG4gICAgcHVibGljIHNob3dTZWFyY2hDbG9zZUJ0bjogYm9vbGVhbiA9IGZhbHNlO1xyXG5cclxuICAgIEBJbnB1dCgpIGNvbmZpZzogSVRvb2xiYXJDb25maWc7XHJcbiAgICBASW5wdXQoKSBtb2JpbGVWaWV3OiBib29sZWFuO1xyXG4gICAgQE91dHB1dCgpIHNlYXJjaFRleHRDaGFuZ2VkOiBFdmVudEVtaXR0ZXI8c3RyaW5nPiA9IG5ldyBFdmVudEVtaXR0ZXI8c3RyaW5nPigpO1xyXG5cclxuICAgIGNvbnN0cnVjdG9yKFxyXG4gICAgICAgIHByaXZhdGUgX3JvdXRlcjogUm91dGVyLFxyXG4gICAgICAgIHByaXZhdGUgX3Rvb2xiYXJTdmM6IEtkVG9vbGJhclN2YyxcclxuICAgICAgICBwcml2YXRlIF90b29sYmFyRXZlbnQ6IEtkVG9vbGJhckV2ZW50XHJcbiAgICApIHsgfVxyXG5cclxuICAgIC8qKioqKioqKioqKioqKioqKioqKioqKioqIExpZmUgY3ljbGVzIGZ1bmN0aW9ucyAqKioqKioqKioqKioqKioqKioqKioqKioqKioqKi9cclxuICAgIG5nT25Jbml0KCk6IHZvaWQge1xyXG4gICAgICAgIC8vIGNvbnNvbGUubG9nKCctLSBLZFRvb2xiYXI6IE9uSW5pdCAtLSAnLCB0aGlzLmNvbmZpZyk7XHJcbiAgICAgICAgaWYgKHR5cGVvZiB0aGlzLmNvbmZpZyAhPT0gJ3VuZGVmaW5lZCcpIHtcclxuICAgICAgICAgICAgdGhpcy5fdXBkYXRlTGVmdFRvb2xiYXIodGhpcy5jb25maWcpO1xyXG4gICAgICAgICAgICB0aGlzLl91cGRhdGVTZWFyY2hDbG9zZUJ0bigpO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICBuZ09uQ2hhbmdlcyhfc2ltcGxlQ2hhbmdlczogU2ltcGxlQ2hhbmdlcyk6IHZvaWQge1xyXG4gICAgICAgIC8vIGNvbnNvbGUubG9nKCctLSBLZFRvb2xiYXI6IE9uQ2hhbmdlcyAtLSAnLCBfc2ltcGxlQ2hhbmdlcyk7XHJcbiAgICAgICAgaWYgKF9zaW1wbGVDaGFuZ2VzLmhhc093blByb3BlcnR5KCdjb25maWcnKSAmJiB0eXBlb2YgX3NpbXBsZUNoYW5nZXNbJ2NvbmZpZyddLmN1cnJlbnRWYWx1ZSAhPT0gJ3VuZGVmaW5lZCcpIHtcclxuICAgICAgICAgICAgdGhpcy5fdXBkYXRlTGVmdFRvb2xiYXIodGhpcy5jb25maWcpO1xyXG4gICAgICAgICAgICB0aGlzLl91cGRhdGVTZWFyY2hDbG9zZUJ0bigpO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgaWYgKF9zaW1wbGVDaGFuZ2VzLmhhc093blByb3BlcnR5KCdtb2JpbGVWaWV3JykpIHtcclxuICAgICAgICAgICAgdGhpcy5fY2hlY2tUb1Nob3dTZWFyY2hDbG9zZSgpO1xyXG5cclxuICAgICAgICAgICAgaWYgKCF0aGlzLm1vYmlsZVZpZXcpIHtcclxuICAgICAgICAgICAgICAgIHRoaXMuc2VhcmNoRXhwZW5kID0gZmFsc2U7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgbmdBZnRlclZpZXdJbml0KCk6IHZvaWQge1xyXG4gICAgICAgIC8vIGNvbnNvbGUubG9nKCctLSBLZFRvb2xiYXI6IEFmdGVyVmlld0luaXQgLS0gJyk7XHJcbiAgICAgICAgb2JzZXJ2YWJsZVRpbWVyKCkuc3Vic2NyaWJlKCgpOiB2b2lkID0+IHtcclxuICAgICAgICAgICAgdGhpcy5fY2hlY2tUb1Nob3dTZWFyY2hDbG9zZSgpO1xyXG4gICAgICAgIH0pO1xyXG4gICAgfVxyXG5cclxuICAgIG5nT25EZXN0cm95KCk6IHZvaWQge1xyXG4gICAgICAgIC8vIGNvbnNvbGUubG9nKCctLSBLZFRvb2xiYXI6IE9uRGVzdHJveSAtLSAnKTtcclxuICAgIH1cclxuXHJcbiAgICAvKioqKioqKioqKioqKioqKioqKioqKioqKioqKiBFdmVudHMgZnVuY3Rpb25zICoqKioqKioqKioqKioqKioqKioqKioqKioqKioqKiovXHJcbiAgICAvLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vXHJcbiAgICAvLy8gQnV0dG9uIGV2ZW50c1xyXG4gICAgLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vL1xyXG4gICAgcHVibGljIGJ1dHRvbkNsaWNrKF9lOiBFdmVudCwgX2J1dHRvbjogSVRvb2xiYXJCdXR0b24pOiB2b2lkIHtcclxuICAgICAgICAvLyBjb25zb2xlLmxvZygnLS0gS2RUb29sYmFyOiBCdXR0b24gY2xpY2tlZCAtLSAnLCBfYnV0dG9uKTtcclxuICAgICAgICBpZiAodHlwZW9mIF9idXR0b24ucGF0aCAhPT0gJ3VuZGVmaW5lZCcpIHtcclxuICAgICAgICAgICAgdGhpcy5fcm91dGVyLm5hdmlnYXRlKFtfYnV0dG9uLnBhdGhdKTtcclxuICAgICAgICB9XHJcbiAgICAgICAgZWxzZSBpZiAodHlwZW9mIF9idXR0b24uY2FsbGJhY2sgIT09ICd1bmRlZmluZWQnKSB7XHJcbiAgICAgICAgICAgIF9idXR0b24uY2FsbGJhY2soKTtcclxuICAgICAgICB9XHJcbiAgICAgICAgZWxzZSB7XHJcbiAgICAgICAgICAgIGNvbnNvbGUuZXJyb3IoJ0tkVG9vbGJhcjogQnV0dG9uIGlzIGNsaWNrZWQgYnV0IG5vIHBhdGggb3IgY2FsbGJhY2sgaXMgc3BlY2lmaWVkLicpO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICAvLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vXHJcbiAgICAvLy8gU2VhcmNoIGZ1bmN0aW9uc1xyXG4gICAgLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vL1xyXG4gICAgcHVibGljIHNlYXJjaENsaWNrZWQoKTogdm9pZCB7XHJcbiAgICAgICAgaWYgKCF0aGlzLm1vYmlsZVZpZXcpIHJldHVybjtcclxuXHJcbiAgICAgICAgdGhpcy5zZWFyY2hFeHBlbmQgPSAhdGhpcy5zZWFyY2hFeHBlbmQ7XHJcbiAgICAgICAgdGhpcy5fY2hlY2tUb1Nob3dTZWFyY2hDbG9zZSgpO1xyXG4gICAgfVxyXG5cclxuICAgIHB1YmxpYyBzZWFyY2hDaGFuZ2VkKF9ldmVudDogc3RyaW5nKTogdm9pZCB7XHJcbiAgICAgICAgLy8gY29uc29sZS5sb2coJy0tIEtkVG9vbGJhcjogU2VhcmNoIHRleHQgY2hhbmdlZCAtLSAnLCBfZXZlbnQpO1xyXG4gICAgICAgIGlmICh0eXBlb2YgdGhpcy5jb25maWcuc2VhcmNoQ2FsbGJhY2sgIT09ICd1bmRlZmluZWQnKSB7XHJcbiAgICAgICAgICAgIHRoaXMuY29uZmlnLnNlYXJjaENhbGxiYWNrKF9ldmVudCk7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICB0aGlzLl91cGRhdGVTZWFyY2hDbG9zZUJ0bigpO1xyXG4gICAgICAgIHRoaXMuX2VtaXRTZWFyY2hUZXh0Q2hhbmdlZCgpO1xyXG4gICAgfVxyXG5cclxuICAgIHB1YmxpYyBzZWFyY2hDbG9zZUNsaWNrZWQoKTogdm9pZCB7XHJcbiAgICAgICAgLy8gY29uc29sZS5sb2coJy0tIEtkVG9vbGJhcjogU2VhcmNoIGNsb3NlIGNsaWNrZWQgLS0gJyk7XHJcbiAgICAgICAgaWYgKHRoaXMubW9iaWxlVmlldykge1xyXG4gICAgICAgICAgICBpZiAodGhpcy5jb25maWcuc2VhcmNoVGV4dCAhPT0gJycpIHtcclxuICAgICAgICAgICAgICAgIHRoaXMuX2NsZWFyU2VhcmNoKCk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgZWxzZSB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLnNlYXJjaEV4cGVuZCA9IGZhbHNlO1xyXG4gICAgICAgICAgICAgICAgdGhpcy5zaG93U2VhcmNoQ2xvc2VCdG4gPSBmYWxzZTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgdGhpcy5fY2xlYXJTZWFyY2goKTtcclxuICAgICAgICAgICAgdGhpcy5zaG93U2VhcmNoQ2xvc2VCdG4gPSBmYWxzZTtcclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgLyoqKioqKioqKioqKioqKioqKioqKioqKioqKiogUHJpdmF0ZSBmdW5jdGlvbnMgKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqL1xyXG4gICAgLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vL1xyXG4gICAgLy8vIERPTSBmdW5jdGlvblxyXG4gICAgLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vL1xyXG4gICAgcHJpdmF0ZSBfY2hlY2tUb1Nob3dTZWFyY2hDbG9zZSgpOiB2b2lkIHtcclxuICAgICAgICBpZiAodGhpcy5tb2JpbGVWaWV3KSB7XHJcbiAgICAgICAgICAgIHRoaXMuc2hvd1NlYXJjaENsb3NlQnRuID0gdGhpcy5zZWFyY2hFeHBlbmQ7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICB0aGlzLnNob3dTZWFyY2hDbG9zZUJ0biA9IHRoaXMuY29uZmlnLnNlYXJjaFRleHQgIT09ICcnO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF9jbGVhclNlYXJjaCgpOiB2b2lkIHtcclxuICAgICAgICB0aGlzLmNvbmZpZy5zZWFyY2hUZXh0ID0gJyc7XHJcbiAgICAgICAgdGhpcy5fZW1pdFNlYXJjaFRleHRDaGFuZ2VkKCk7XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfdXBkYXRlU2VhcmNoQ2xvc2VCdG4oKTogdm9pZCB7XHJcbiAgICAgICAgaWYgKCF0aGlzLm1vYmlsZVZpZXcpIHtcclxuICAgICAgICAgICAgdGhpcy5zaG93U2VhcmNoQ2xvc2VCdG4gPSB0aGlzLmNvbmZpZy5zZWFyY2hUZXh0ICE9PSAnJztcclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vL1xyXG4gICAgLy8vIFVwZGF0ZSBUb29sYmFyIGJ1dHRvbnMgZnVuY3Rpb25cclxuICAgIC8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy9cclxuICAgIHByaXZhdGUgX3VwZGF0ZUxlZnRUb29sYmFyKF9jb25maWc6IElUb29sYmFyQ29uZmlnKTogdm9pZCB7XHJcbiAgICAgICAgX2NvbmZpZy5sZWZ0QnRuID0gdGhpcy5fdG9vbGJhclN2Yy51cGRhdGVMZWZ0VG9vbGJhcihfY29uZmlnLmxlZnRCdG4pO1xyXG4gICAgfVxyXG5cclxuICAgIC8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy9cclxuICAgIC8vLyBFbWl0dGVyIGZ1bmN0aW9uXHJcbiAgICAvLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vXHJcbiAgICBwcml2YXRlIF9lbWl0U2VhcmNoVGV4dENoYW5nZWQoKTogdm9pZCB7XHJcbiAgICAgICAgdGhpcy5zZWFyY2hUZXh0Q2hhbmdlZC5lbWl0KHRoaXMuY29uZmlnLnNlYXJjaFRleHQpO1xyXG4gICAgICAgIHRoaXMuX3Rvb2xiYXJFdmVudC5zZW5kU2VhcmNoVGV4dCh0aGlzLmNvbmZpZy5zZWFyY2hUZXh0KTtcclxuICAgIH1cclxufVxyXG4iXX0=