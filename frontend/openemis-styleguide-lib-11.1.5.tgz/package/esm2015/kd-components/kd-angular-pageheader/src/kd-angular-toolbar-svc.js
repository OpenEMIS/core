/****************************************************************************************
    File               : kd-angular-toolbar-svc.ts
    Version            : 2.0
    Created by         : Cheng Kok Keong
    Purpose            : Service file for kd-angular-toolbar.ts

    Functions          :
        - Variables:
            - DEFAULT_TYPE - Default non-custom type buttons supported for the left buttons

        - Public functions:
            - updateLeftToolbar

        - Private functions:
            - _isCustomType - Checks if the button is a custom type

    Last changes       :
        - Rewrite component and service

 ****************************************************************************************/
import { Injectable } from '@angular/core';
export class KdToolbarSvc {
    constructor() {
        /******************************* Variables ***********************************/
        this.DEFAULT_TYPE = {
            'more': {
                tooltip: 'More',
                icon: 'fa kd-ellipsis fa-rotate-90',
            },
            'add': {
                tooltip: 'Add',
                icon: 'kd-add'
            },
            'back': {
                tooltip: 'Back',
                icon: 'fa fa-chevron-left'
            },
            'import': {
                tooltip: 'Import',
                icon: 'kd-import'
            },
            'export': {
                tooltip: 'Export',
                icon: 'kd-export'
            },
            'graduate': {
                tooltip: 'Graduate',
                icon: 'kd-graduate'
            },
            'transfer': {
                tooltip: 'Transfer',
                icon: 'kd-transfer'
            },
            'dropdown': {
                tooltip: 'Dropout',
                icon: 'kd-dropout'
            },
            'undo': {
                tooltip: 'Undo',
                icon: 'kd-undo'
            },
            'edit': {
                tooltip: 'Edit',
                icon: 'kd-edit'
            },
            'delete': {
                tooltip: 'Delete',
                icon: 'fa fa-trash'
            },
            'list': {
                tooltip: 'List',
                icon: 'fa fa-list'
            }
        };
    }
    /**************************** Public functions *******************************/
    ///////////////////////////////////////////////////////
    /// Left toolbar buttons function
    ///////////////////////////////////////////////////////
    updateLeftToolbar(_leftConfig) {
        let leftToolbar = [];
        for (let i = 0; i < _leftConfig.length; ++i) {
            if (!this._isCustomType(_leftConfig[i])) {
                leftToolbar.push(Object.assign({}, _leftConfig[i], this.DEFAULT_TYPE[_leftConfig[i].type]));
            }
            else {
                leftToolbar.push(_leftConfig[i]);
            }
        }
        return leftToolbar;
    }
    /**************************** Private functions *******************************/
    ///////////////////////////////////////////////////////
    /// Checking function
    ///////////////////////////////////////////////////////
    _isCustomType(_button) {
        return (typeof _button.custom !== 'undefined' && _button.custom);
    }
}
KdToolbarSvc.decorators = [
    { type: Injectable }
];
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoia2QtYW5ndWxhci10b29sYmFyLXN2Yy5qcyIsInNvdXJjZVJvb3QiOiJDOi94YW1wcC9odGRvY3MvU3R5bGVndWlkZS9pb3N0Zy1vcGVuZW1pcy1zdHlsZWd1aWRlL3Byb2plY3RzL29wZW5lbWlzLXN0eWxlZ3VpZGUtbGliL3NyYy8iLCJzb3VyY2VzIjpbImtkLWNvbXBvbmVudHMva2QtYW5ndWxhci1wYWdlaGVhZGVyL3NyYy9rZC1hbmd1bGFyLXRvb2xiYXItc3ZjLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBOzs7Ozs7Ozs7Ozs7Ozs7Ozs7OzBGQW1CMEY7QUFHMUYsT0FBTyxFQUFFLFVBQVUsRUFBRSxNQUFNLGVBQWUsQ0FBQztBQUkzQyxNQUFNLE9BQU8sWUFBWTtJQUR6QjtRQUVJLCtFQUErRTtRQUN0RSxpQkFBWSxHQUFvQztZQUNyRCxNQUFNLEVBQUU7Z0JBQ0osT0FBTyxFQUFFLE1BQU07Z0JBQ2YsSUFBSSxFQUFFLDZCQUE2QjthQUN0QztZQUNELEtBQUssRUFBRTtnQkFDSCxPQUFPLEVBQUUsS0FBSztnQkFDZCxJQUFJLEVBQUUsUUFBUTthQUNqQjtZQUNELE1BQU0sRUFBRTtnQkFDSixPQUFPLEVBQUUsTUFBTTtnQkFDZixJQUFJLEVBQUUsb0JBQW9CO2FBQzdCO1lBQ0QsUUFBUSxFQUFFO2dCQUNOLE9BQU8sRUFBRSxRQUFRO2dCQUNqQixJQUFJLEVBQUUsV0FBVzthQUNwQjtZQUNELFFBQVEsRUFBRTtnQkFDTixPQUFPLEVBQUUsUUFBUTtnQkFDakIsSUFBSSxFQUFFLFdBQVc7YUFDcEI7WUFDRCxVQUFVLEVBQUU7Z0JBQ1IsT0FBTyxFQUFFLFVBQVU7Z0JBQ25CLElBQUksRUFBRSxhQUFhO2FBQ3RCO1lBQ0QsVUFBVSxFQUFFO2dCQUNSLE9BQU8sRUFBRSxVQUFVO2dCQUNuQixJQUFJLEVBQUUsYUFBYTthQUN0QjtZQUNELFVBQVUsRUFBRTtnQkFDUixPQUFPLEVBQUUsU0FBUztnQkFDbEIsSUFBSSxFQUFFLFlBQVk7YUFDckI7WUFDRCxNQUFNLEVBQUU7Z0JBQ0osT0FBTyxFQUFFLE1BQU07Z0JBQ2YsSUFBSSxFQUFFLFNBQVM7YUFDbEI7WUFDRCxNQUFNLEVBQUU7Z0JBQ0osT0FBTyxFQUFFLE1BQU07Z0JBQ2YsSUFBSSxFQUFFLFNBQVM7YUFDbEI7WUFDRCxRQUFRLEVBQUU7Z0JBQ04sT0FBTyxFQUFFLFFBQVE7Z0JBQ2pCLElBQUksRUFBRSxhQUFhO2FBQ3RCO1lBQ0QsTUFBTSxFQUFFO2dCQUNKLE9BQU8sRUFBRSxNQUFNO2dCQUNmLElBQUksRUFBRSxZQUFZO2FBQ3JCO1NBQ0osQ0FBQztJQTRCTixDQUFDO0lBMUJHLCtFQUErRTtJQUMvRSx1REFBdUQ7SUFDdkQsaUNBQWlDO0lBQ2pDLHVEQUF1RDtJQUNoRCxpQkFBaUIsQ0FBQyxXQUFrQztRQUN2RCxJQUFJLFdBQVcsR0FBMEIsRUFBRSxDQUFDO1FBRTVDLEtBQUssSUFBSSxDQUFDLEdBQVcsQ0FBQyxFQUFFLENBQUMsR0FBRyxXQUFXLENBQUMsTUFBTSxFQUFFLEVBQUUsQ0FBQyxFQUFFO1lBQ2pELElBQUksQ0FBQyxJQUFJLENBQUMsYUFBYSxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFO2dCQUNyQyxXQUFXLENBQUMsSUFBSSxDQUFPLE1BQU8sQ0FBQyxNQUFNLENBQUMsRUFBRSxFQUFFLFdBQVcsQ0FBQyxDQUFDLENBQUMsRUFBRSxJQUFJLENBQUMsWUFBWSxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUM7YUFDdEc7aUJBQ0k7Z0JBQ0QsV0FBVyxDQUFDLElBQUksQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQzthQUNwQztTQUNKO1FBRUQsT0FBTyxXQUFXLENBQUM7SUFDdkIsQ0FBQztJQUVELGdGQUFnRjtJQUNoRix1REFBdUQ7SUFDdkQscUJBQXFCO0lBQ3JCLHVEQUF1RDtJQUMvQyxhQUFhLENBQUMsT0FBdUI7UUFDekMsT0FBTyxDQUFDLE9BQU8sT0FBTyxDQUFDLE1BQU0sS0FBSyxXQUFXLElBQUksT0FBTyxDQUFDLE1BQU0sQ0FBQyxDQUFDO0lBQ3JFLENBQUM7OztZQS9FSixVQUFVIiwic291cmNlc0NvbnRlbnQiOlsiLyoqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKipcclxuICAgIEZpbGUgICAgICAgICAgICAgICA6IGtkLWFuZ3VsYXItdG9vbGJhci1zdmMudHNcclxuICAgIFZlcnNpb24gICAgICAgICAgICA6IDIuMFxyXG4gICAgQ3JlYXRlZCBieSAgICAgICAgIDogQ2hlbmcgS29rIEtlb25nXHJcbiAgICBQdXJwb3NlICAgICAgICAgICAgOiBTZXJ2aWNlIGZpbGUgZm9yIGtkLWFuZ3VsYXItdG9vbGJhci50c1xyXG5cclxuICAgIEZ1bmN0aW9ucyAgICAgICAgICA6XHJcbiAgICAgICAgLSBWYXJpYWJsZXM6XHJcbiAgICAgICAgICAgIC0gREVGQVVMVF9UWVBFIC0gRGVmYXVsdCBub24tY3VzdG9tIHR5cGUgYnV0dG9ucyBzdXBwb3J0ZWQgZm9yIHRoZSBsZWZ0IGJ1dHRvbnNcclxuXHJcbiAgICAgICAgLSBQdWJsaWMgZnVuY3Rpb25zOlxyXG4gICAgICAgICAgICAtIHVwZGF0ZUxlZnRUb29sYmFyXHJcblxyXG4gICAgICAgIC0gUHJpdmF0ZSBmdW5jdGlvbnM6XHJcbiAgICAgICAgICAgIC0gX2lzQ3VzdG9tVHlwZSAtIENoZWNrcyBpZiB0aGUgYnV0dG9uIGlzIGEgY3VzdG9tIHR5cGVcclxuXHJcbiAgICBMYXN0IGNoYW5nZXMgICAgICAgOlxyXG4gICAgICAgIC0gUmV3cml0ZSBjb21wb25lbnQgYW5kIHNlcnZpY2VcclxuXHJcbiAqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqL1xyXG5cclxuXHJcbmltcG9ydCB7IEluamVjdGFibGUgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcclxuaW1wb3J0IHsgSVRvb2xiYXJCdXR0b24gfSBmcm9tICcuLi9rZC1hbmd1bGFyLXBhZ2VoZWFkZXItaW50ZXJmYWNlJztcclxuXHJcbkBJbmplY3RhYmxlKClcclxuZXhwb3J0IGNsYXNzIEtkVG9vbGJhclN2YyB7XHJcbiAgICAvKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKiBWYXJpYWJsZXMgKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKiovXHJcbiAgICByZWFkb25seSBERUZBVUxUX1RZUEU6IHtba2V5OiBzdHJpbmddOiBJVG9vbGJhckJ1dHRvbn0gPSB7XHJcbiAgICAgICAgJ21vcmUnOiB7XHJcbiAgICAgICAgICAgIHRvb2x0aXA6ICdNb3JlJyxcclxuICAgICAgICAgICAgaWNvbjogJ2ZhIGtkLWVsbGlwc2lzIGZhLXJvdGF0ZS05MCcsXHJcbiAgICAgICAgfSxcclxuICAgICAgICAnYWRkJzoge1xyXG4gICAgICAgICAgICB0b29sdGlwOiAnQWRkJyxcclxuICAgICAgICAgICAgaWNvbjogJ2tkLWFkZCdcclxuICAgICAgICB9LFxyXG4gICAgICAgICdiYWNrJzoge1xyXG4gICAgICAgICAgICB0b29sdGlwOiAnQmFjaycsXHJcbiAgICAgICAgICAgIGljb246ICdmYSBmYS1jaGV2cm9uLWxlZnQnXHJcbiAgICAgICAgfSxcclxuICAgICAgICAnaW1wb3J0Jzoge1xyXG4gICAgICAgICAgICB0b29sdGlwOiAnSW1wb3J0JyxcclxuICAgICAgICAgICAgaWNvbjogJ2tkLWltcG9ydCdcclxuICAgICAgICB9LFxyXG4gICAgICAgICdleHBvcnQnOiB7XHJcbiAgICAgICAgICAgIHRvb2x0aXA6ICdFeHBvcnQnLFxyXG4gICAgICAgICAgICBpY29uOiAna2QtZXhwb3J0J1xyXG4gICAgICAgIH0sXHJcbiAgICAgICAgJ2dyYWR1YXRlJzoge1xyXG4gICAgICAgICAgICB0b29sdGlwOiAnR3JhZHVhdGUnLFxyXG4gICAgICAgICAgICBpY29uOiAna2QtZ3JhZHVhdGUnXHJcbiAgICAgICAgfSxcclxuICAgICAgICAndHJhbnNmZXInOiB7XHJcbiAgICAgICAgICAgIHRvb2x0aXA6ICdUcmFuc2ZlcicsXHJcbiAgICAgICAgICAgIGljb246ICdrZC10cmFuc2ZlcidcclxuICAgICAgICB9LFxyXG4gICAgICAgICdkcm9wZG93bic6IHtcclxuICAgICAgICAgICAgdG9vbHRpcDogJ0Ryb3BvdXQnLFxyXG4gICAgICAgICAgICBpY29uOiAna2QtZHJvcG91dCdcclxuICAgICAgICB9LFxyXG4gICAgICAgICd1bmRvJzoge1xyXG4gICAgICAgICAgICB0b29sdGlwOiAnVW5kbycsXHJcbiAgICAgICAgICAgIGljb246ICdrZC11bmRvJ1xyXG4gICAgICAgIH0sXHJcbiAgICAgICAgJ2VkaXQnOiB7XHJcbiAgICAgICAgICAgIHRvb2x0aXA6ICdFZGl0JyxcclxuICAgICAgICAgICAgaWNvbjogJ2tkLWVkaXQnXHJcbiAgICAgICAgfSxcclxuICAgICAgICAnZGVsZXRlJzoge1xyXG4gICAgICAgICAgICB0b29sdGlwOiAnRGVsZXRlJyxcclxuICAgICAgICAgICAgaWNvbjogJ2ZhIGZhLXRyYXNoJ1xyXG4gICAgICAgIH0sXHJcbiAgICAgICAgJ2xpc3QnOiB7XHJcbiAgICAgICAgICAgIHRvb2x0aXA6ICdMaXN0JyxcclxuICAgICAgICAgICAgaWNvbjogJ2ZhIGZhLWxpc3QnXHJcbiAgICAgICAgfVxyXG4gICAgfTtcclxuXHJcbiAgICAvKioqKioqKioqKioqKioqKioqKioqKioqKioqKiBQdWJsaWMgZnVuY3Rpb25zICoqKioqKioqKioqKioqKioqKioqKioqKioqKioqKiovXHJcbiAgICAvLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vXHJcbiAgICAvLy8gTGVmdCB0b29sYmFyIGJ1dHRvbnMgZnVuY3Rpb25cclxuICAgIC8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy9cclxuICAgIHB1YmxpYyB1cGRhdGVMZWZ0VG9vbGJhcihfbGVmdENvbmZpZzogQXJyYXk8SVRvb2xiYXJCdXR0b24+KTogQXJyYXk8SVRvb2xiYXJCdXR0b24+IHtcclxuICAgICAgICBsZXQgbGVmdFRvb2xiYXI6IEFycmF5PElUb29sYmFyQnV0dG9uPiA9IFtdO1xyXG5cclxuICAgICAgICBmb3IgKGxldCBpOiBudW1iZXIgPSAwOyBpIDwgX2xlZnRDb25maWcubGVuZ3RoOyArK2kpIHtcclxuICAgICAgICAgICAgaWYgKCF0aGlzLl9pc0N1c3RvbVR5cGUoX2xlZnRDb25maWdbaV0pKSB7XHJcbiAgICAgICAgICAgICAgICBsZWZ0VG9vbGJhci5wdXNoKCg8YW55Pk9iamVjdCkuYXNzaWduKHt9LCBfbGVmdENvbmZpZ1tpXSwgdGhpcy5ERUZBVUxUX1RZUEVbX2xlZnRDb25maWdbaV0udHlwZV0pKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgICAgIGxlZnRUb29sYmFyLnB1c2goX2xlZnRDb25maWdbaV0pO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICByZXR1cm4gbGVmdFRvb2xiYXI7XHJcbiAgICB9XHJcblxyXG4gICAgLyoqKioqKioqKioqKioqKioqKioqKioqKioqKiogUHJpdmF0ZSBmdW5jdGlvbnMgKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKi9cclxuICAgIC8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy9cclxuICAgIC8vLyBDaGVja2luZyBmdW5jdGlvblxyXG4gICAgLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vL1xyXG4gICAgcHJpdmF0ZSBfaXNDdXN0b21UeXBlKF9idXR0b246IElUb29sYmFyQnV0dG9uKTogYm9vbGVhbiB7XHJcbiAgICAgICAgcmV0dXJuICh0eXBlb2YgX2J1dHRvbi5jdXN0b20gIT09ICd1bmRlZmluZWQnICYmIF9idXR0b24uY3VzdG9tKTtcclxuICAgIH1cclxufVxyXG4iXX0=