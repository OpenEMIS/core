import { Injectable } from '@angular/core';
import { KdBroadcaster } from '../../kd-common/index';
import * as i0 from "@angular/core";
import * as i1 from "../../kd-common/kd-broadcaster-svc";
export class KdToolbarEvent {
    constructor(_broadcaster) {
        this._broadcaster = _broadcaster;
    }
    sendSearchText(data) {
        this._broadcaster.broadcast('sendSearchText', data);
    }
    onSendSearchText() {
        return this._broadcaster.on('sendSearchText');
    }
}
KdToolbarEvent.ɵprov = i0.ɵɵdefineInjectable({ factory: function KdToolbarEvent_Factory() { return new KdToolbarEvent(i0.ɵɵinject(i1.KdBroadcaster)); }, token: KdToolbarEvent, providedIn: "root" });
KdToolbarEvent.decorators = [
    { type: Injectable, args: [{
                providedIn: 'root'
            },] }
];
KdToolbarEvent.ctorParameters = () => [
    { type: KdBroadcaster }
];
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoia2QtdG9vbGJhci1ldmVudC5qcyIsInNvdXJjZVJvb3QiOiJDOi94YW1wcC9odGRvY3MvU3R5bGVndWlkZS9pb3N0Zy1vcGVuZW1pcy1zdHlsZWd1aWRlL3Byb2plY3RzL29wZW5lbWlzLXN0eWxlZ3VpZGUtbGliL3NyYy8iLCJzb3VyY2VzIjpbImtkLWNvbXBvbmVudHMva2QtYW5ndWxhci1wYWdlaGVhZGVyL3NyYy9rZC10b29sYmFyLWV2ZW50LnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBLE9BQU8sRUFBRSxVQUFVLEVBQUUsTUFBTSxlQUFlLENBQUM7QUFFM0MsT0FBTyxFQUFFLGFBQWEsRUFBRSxNQUFNLHVCQUF1QixDQUFDOzs7QUFLdEQsTUFBTSxPQUFPLGNBQWM7SUFDdkIsWUFBb0IsWUFBMkI7UUFBM0IsaUJBQVksR0FBWixZQUFZLENBQWU7SUFBSSxDQUFDO0lBRXBELGNBQWMsQ0FBQyxJQUFhO1FBQ3hCLElBQUksQ0FBQyxZQUFZLENBQUMsU0FBUyxDQUFDLGdCQUFnQixFQUFFLElBQUksQ0FBQyxDQUFDO0lBQ3hELENBQUM7SUFFRCxnQkFBZ0I7UUFDWixPQUFPLElBQUksQ0FBQyxZQUFZLENBQUMsRUFBRSxDQUFTLGdCQUFnQixDQUFDLENBQUM7SUFDMUQsQ0FBQzs7OztZQVpKLFVBQVUsU0FBQztnQkFDUixVQUFVLEVBQUUsTUFBTTthQUNyQjs7O1lBSlEsYUFBYSIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IEluamVjdGFibGUgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcclxuaW1wb3J0IHsgT2JzZXJ2YWJsZSB9IGZyb20gJ3J4anMnO1xyXG5pbXBvcnQgeyBLZEJyb2FkY2FzdGVyIH0gZnJvbSAnLi4vLi4va2QtY29tbW9uL2luZGV4JztcclxuXHJcbkBJbmplY3RhYmxlKHtcclxuICAgIHByb3ZpZGVkSW46ICdyb290J1xyXG59KVxyXG5leHBvcnQgY2xhc3MgS2RUb29sYmFyRXZlbnQge1xyXG4gICAgY29uc3RydWN0b3IocHJpdmF0ZSBfYnJvYWRjYXN0ZXI6IEtkQnJvYWRjYXN0ZXIpIHsgfVxyXG5cclxuICAgIHNlbmRTZWFyY2hUZXh0KGRhdGE/OiBzdHJpbmcpOiB2b2lkIHtcclxuICAgICAgICB0aGlzLl9icm9hZGNhc3Rlci5icm9hZGNhc3QoJ3NlbmRTZWFyY2hUZXh0JywgZGF0YSk7XHJcbiAgICB9XHJcblxyXG4gICAgb25TZW5kU2VhcmNoVGV4dCgpOiBPYnNlcnZhYmxlPHN0cmluZz4ge1xyXG4gICAgICAgIHJldHVybiB0aGlzLl9icm9hZGNhc3Rlci5vbjxzdHJpbmc+KCdzZW5kU2VhcmNoVGV4dCcpO1xyXG4gICAgfVxyXG59XHJcbiJdfQ==