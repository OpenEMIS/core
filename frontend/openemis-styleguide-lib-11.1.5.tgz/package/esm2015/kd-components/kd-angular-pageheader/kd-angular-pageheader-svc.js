/****************************************************************************************
    File               : kd-angular-pageheader-svc.ts
    Version            : 2.0
    Created by         : Cheng Kok Keong
    Purpose            : Service file for kd-angular-pageheader.ts

    Functions          :
        - Variables:
            - PLACEHOLDER_DEFAULT - Default text for placeholder

        - Public functions:
            - isToolbarExist - Check if there is any configurations for toolbar and renders accordingly.
            - updateToolbarConfig - Update defaults and undefines for placeholder

        - Private functions:
            - _isLeftButtonExist
            - _isMoreBtnExist
            - _isSearchBtnExist

    Last changes       :
        - Rewrite component and service

 ****************************************************************************************/
import { Injectable } from '@angular/core';
export class KdPageheaderSvc {
    constructor() {
        /*********************** Variables ************************/
        this.PLACEHOLDER_DEFAULT = 'Search';
    }
    /******************* Public function **********************/
    isToolbarExist(_config) {
        return (this._isLeftButtonExist(_config.leftBtn) ||
            this._isMoreBtnExist(_config.moreBtn) ||
            this._isSearchBtnExist(_config.searchBtn));
    }
    updateToolbarConfig(_config) {
        let toolbarConfig = {};
        let searchConfig = {};
        /// Title checks
        if (typeof _config.pageheaderText === 'undefined') {
            _config.pageheaderText = '';
        }
        /// More button checks
        if (typeof _config.moreAction === 'undefined' || (typeof _config.moreBtn === 'undefined' || !_config.moreBtn)) {
            _config.moreAction = [];
        }
        /// Left button checks
        if (typeof _config.leftBtn === 'undefined') {
            _config.leftBtn = [];
        }
        if (_config.leftBtn.length > 6) {
            console.warn('KdToolbar warning: Left buttons only take up to 6 buttons. Slicing to 6 buttons');
            _config.leftBtn.splice(6);
        }
        /// Search checks
        if (typeof _config.searchEvent === 'undefined') {
            _config.searchEvent = [];
        }
        if (typeof _config.searchPlaceholder === 'undefined') {
            _config.searchPlaceholder = this.PLACEHOLDER_DEFAULT;
        }
        if (typeof _config.searchText === 'undefined') {
            _config.searchText = '';
        }
        if (typeof _config.searchBtn === 'undefined') {
            _config.searchBtn = false;
        }
        if (_config.searchBtn) {
            searchConfig = {
                searchPlaceholder: _config.searchPlaceholder,
                searchCallback: _config.searchCallback,
                searchEvent: _config.searchEvent,
                searchText: _config.searchText
            };
        }
        toolbarConfig = {
            leftBtn: _config.leftBtn,
            moreAction: _config.moreAction,
            searchBtn: _config.searchBtn
        };
        return Object.assign(Object.assign({}, toolbarConfig), searchConfig);
    }
    /****************** Private function **********************/
    ///////////////////////////////////////////////////////
    /// Checking function
    ///////////////////////////////////////////////////////
    _isLeftButtonExist(_leftBtn) {
        return (typeof _leftBtn !== 'undefined' && _leftBtn.length > 0);
    }
    _isMoreBtnExist(_moreBtn) {
        return (typeof _moreBtn !== 'undefined' && _moreBtn);
    }
    _isSearchBtnExist(_searchBtn) {
        return (typeof _searchBtn !== 'undefined' && _searchBtn);
    }
}
KdPageheaderSvc.decorators = [
    { type: Injectable }
];
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoia2QtYW5ndWxhci1wYWdlaGVhZGVyLXN2Yy5qcyIsInNvdXJjZVJvb3QiOiJDOi94YW1wcC9odGRvY3MvU3R5bGVndWlkZS9pb3N0Zy1vcGVuZW1pcy1zdHlsZWd1aWRlL3Byb2plY3RzL29wZW5lbWlzLXN0eWxlZ3VpZGUtbGliL3NyYy8iLCJzb3VyY2VzIjpbImtkLWNvbXBvbmVudHMva2QtYW5ndWxhci1wYWdlaGVhZGVyL2tkLWFuZ3VsYXItcGFnZWhlYWRlci1zdmMudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7MEZBc0IwRjtBQUUxRixPQUFPLEVBQUUsVUFBVSxFQUFFLE1BQU0sZUFBZSxDQUFDO0FBSTNDLE1BQU0sT0FBTyxlQUFlO0lBRDVCO1FBRUksNERBQTREO1FBQ25ELHdCQUFtQixHQUFXLFFBQVEsQ0FBQztJQXFGcEQsQ0FBQztJQW5GRyw0REFBNEQ7SUFDckQsY0FBYyxDQUFDLE9BQTBCO1FBQzVDLE9BQU8sQ0FDSCxJQUFJLENBQUMsa0JBQWtCLENBQUMsT0FBTyxDQUFDLE9BQU8sQ0FBQztZQUN4QyxJQUFJLENBQUMsZUFBZSxDQUFDLE9BQU8sQ0FBQyxPQUFPLENBQUM7WUFDckMsSUFBSSxDQUFDLGlCQUFpQixDQUFDLE9BQU8sQ0FBQyxTQUFTLENBQUMsQ0FDNUMsQ0FBQztJQUNOLENBQUM7SUFFTSxtQkFBbUIsQ0FBRSxPQUEwQjtRQUNsRCxJQUFJLGFBQWEsR0FBbUIsRUFBRSxDQUFDO1FBQ3ZDLElBQUksWUFBWSxHQUFtQixFQUFFLENBQUM7UUFFdEMsZ0JBQWdCO1FBQ2hCLElBQUksT0FBTyxPQUFPLENBQUMsY0FBYyxLQUFLLFdBQVcsRUFBRTtZQUMvQyxPQUFPLENBQUMsY0FBYyxHQUFHLEVBQUUsQ0FBQztTQUMvQjtRQUVELHNCQUFzQjtRQUN0QixJQUFJLE9BQU8sT0FBTyxDQUFDLFVBQVUsS0FBSyxXQUFXLElBQUksQ0FBQyxPQUFPLE9BQU8sQ0FBQyxPQUFPLEtBQUssV0FBVyxJQUFJLENBQUMsT0FBTyxDQUFDLE9BQU8sQ0FBQyxFQUFFO1lBQzNHLE9BQU8sQ0FBQyxVQUFVLEdBQUcsRUFBRSxDQUFDO1NBQzNCO1FBRUQsc0JBQXNCO1FBQ3RCLElBQUksT0FBTyxPQUFPLENBQUMsT0FBTyxLQUFLLFdBQVcsRUFBRTtZQUN4QyxPQUFPLENBQUMsT0FBTyxHQUFHLEVBQUUsQ0FBQztTQUN4QjtRQUVELElBQUksT0FBTyxDQUFDLE9BQU8sQ0FBQyxNQUFNLEdBQUcsQ0FBQyxFQUFFO1lBQzVCLE9BQU8sQ0FBQyxJQUFJLENBQUMsaUZBQWlGLENBQUMsQ0FBQztZQUNoRyxPQUFPLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQztTQUM3QjtRQUVELGlCQUFpQjtRQUNqQixJQUFJLE9BQU8sT0FBTyxDQUFDLFdBQVcsS0FBSyxXQUFXLEVBQUU7WUFDNUMsT0FBTyxDQUFDLFdBQVcsR0FBRyxFQUFFLENBQUM7U0FDNUI7UUFFRCxJQUFJLE9BQU8sT0FBTyxDQUFDLGlCQUFpQixLQUFLLFdBQVcsRUFBRTtZQUNsRCxPQUFPLENBQUMsaUJBQWlCLEdBQUcsSUFBSSxDQUFDLG1CQUFtQixDQUFDO1NBQ3hEO1FBRUQsSUFBSSxPQUFPLE9BQU8sQ0FBQyxVQUFVLEtBQUssV0FBVyxFQUFFO1lBQzNDLE9BQU8sQ0FBQyxVQUFVLEdBQUcsRUFBRSxDQUFDO1NBQzNCO1FBRUQsSUFBSSxPQUFPLE9BQU8sQ0FBQyxTQUFTLEtBQUssV0FBVyxFQUFFO1lBQzFDLE9BQU8sQ0FBQyxTQUFTLEdBQUcsS0FBSyxDQUFDO1NBQzdCO1FBRUQsSUFBSSxPQUFPLENBQUMsU0FBUyxFQUFFO1lBQ25CLFlBQVksR0FBRztnQkFDWCxpQkFBaUIsRUFBRSxPQUFPLENBQUMsaUJBQWlCO2dCQUM1QyxjQUFjLEVBQUUsT0FBTyxDQUFDLGNBQWM7Z0JBQ3RDLFdBQVcsRUFBRSxPQUFPLENBQUMsV0FBVztnQkFDaEMsVUFBVSxFQUFFLE9BQU8sQ0FBQyxVQUFVO2FBQ2pDLENBQUM7U0FDTDtRQUVELGFBQWEsR0FBRztZQUNaLE9BQU8sRUFBRSxPQUFPLENBQUMsT0FBTztZQUN4QixVQUFVLEVBQUUsT0FBTyxDQUFDLFVBQVU7WUFDOUIsU0FBUyxFQUFFLE9BQU8sQ0FBQyxTQUFTO1NBQy9CLENBQUM7UUFFRix1Q0FBVyxhQUFhLEdBQUssWUFBWSxFQUFFO0lBQy9DLENBQUM7SUFFRCw0REFBNEQ7SUFDNUQsdURBQXVEO0lBQ3ZELHFCQUFxQjtJQUNyQix1REFBdUQ7SUFDL0Msa0JBQWtCLENBQUMsUUFBK0I7UUFDdEQsT0FBTyxDQUFDLE9BQU8sUUFBUSxLQUFLLFdBQVcsSUFBSSxRQUFRLENBQUMsTUFBTSxHQUFHLENBQUMsQ0FBQyxDQUFDO0lBQ3BFLENBQUM7SUFFTyxlQUFlLENBQUMsUUFBaUI7UUFDckMsT0FBTyxDQUFDLE9BQU8sUUFBUSxLQUFLLFdBQVcsSUFBSSxRQUFRLENBQUMsQ0FBQztJQUN6RCxDQUFDO0lBRU8saUJBQWlCLENBQUMsVUFBbUI7UUFDekMsT0FBTyxDQUFDLE9BQU8sVUFBVSxLQUFLLFdBQVcsSUFBSSxVQUFVLENBQUMsQ0FBQztJQUM3RCxDQUFDOzs7WUF2RkosVUFBVSIsInNvdXJjZXNDb250ZW50IjpbIi8qKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqXHJcbiAgICBGaWxlICAgICAgICAgICAgICAgOiBrZC1hbmd1bGFyLXBhZ2VoZWFkZXItc3ZjLnRzXHJcbiAgICBWZXJzaW9uICAgICAgICAgICAgOiAyLjBcclxuICAgIENyZWF0ZWQgYnkgICAgICAgICA6IENoZW5nIEtvayBLZW9uZ1xyXG4gICAgUHVycG9zZSAgICAgICAgICAgIDogU2VydmljZSBmaWxlIGZvciBrZC1hbmd1bGFyLXBhZ2VoZWFkZXIudHNcclxuXHJcbiAgICBGdW5jdGlvbnMgICAgICAgICAgOlxyXG4gICAgICAgIC0gVmFyaWFibGVzOlxyXG4gICAgICAgICAgICAtIFBMQUNFSE9MREVSX0RFRkFVTFQgLSBEZWZhdWx0IHRleHQgZm9yIHBsYWNlaG9sZGVyXHJcblxyXG4gICAgICAgIC0gUHVibGljIGZ1bmN0aW9uczpcclxuICAgICAgICAgICAgLSBpc1Rvb2xiYXJFeGlzdCAtIENoZWNrIGlmIHRoZXJlIGlzIGFueSBjb25maWd1cmF0aW9ucyBmb3IgdG9vbGJhciBhbmQgcmVuZGVycyBhY2NvcmRpbmdseS5cclxuICAgICAgICAgICAgLSB1cGRhdGVUb29sYmFyQ29uZmlnIC0gVXBkYXRlIGRlZmF1bHRzIGFuZCB1bmRlZmluZXMgZm9yIHBsYWNlaG9sZGVyXHJcblxyXG4gICAgICAgIC0gUHJpdmF0ZSBmdW5jdGlvbnM6XHJcbiAgICAgICAgICAgIC0gX2lzTGVmdEJ1dHRvbkV4aXN0XHJcbiAgICAgICAgICAgIC0gX2lzTW9yZUJ0bkV4aXN0XHJcbiAgICAgICAgICAgIC0gX2lzU2VhcmNoQnRuRXhpc3RcclxuXHJcbiAgICBMYXN0IGNoYW5nZXMgICAgICAgOlxyXG4gICAgICAgIC0gUmV3cml0ZSBjb21wb25lbnQgYW5kIHNlcnZpY2VcclxuXHJcbiAqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqL1xyXG5cclxuaW1wb3J0IHsgSW5qZWN0YWJsZSB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xyXG5pbXBvcnQgeyBJUGFnZWhlYWRlckNvbmZpZywgSVRvb2xiYXJCdXR0b24sIElUb29sYmFyQ29uZmlnIH0gZnJvbSAnLi9rZC1hbmd1bGFyLXBhZ2VoZWFkZXItaW50ZXJmYWNlJztcclxuXHJcbkBJbmplY3RhYmxlKClcclxuZXhwb3J0IGNsYXNzIEtkUGFnZWhlYWRlclN2YyB7XHJcbiAgICAvKioqKioqKioqKioqKioqKioqKioqKiogVmFyaWFibGVzICoqKioqKioqKioqKioqKioqKioqKioqKi9cclxuICAgIHJlYWRvbmx5IFBMQUNFSE9MREVSX0RFRkFVTFQ6IHN0cmluZyA9ICdTZWFyY2gnO1xyXG5cclxuICAgIC8qKioqKioqKioqKioqKioqKioqIFB1YmxpYyBmdW5jdGlvbiAqKioqKioqKioqKioqKioqKioqKioqL1xyXG4gICAgcHVibGljIGlzVG9vbGJhckV4aXN0KF9jb25maWc6IElQYWdlaGVhZGVyQ29uZmlnKTogYm9vbGVhbiB7XHJcbiAgICAgICAgcmV0dXJuIChcclxuICAgICAgICAgICAgdGhpcy5faXNMZWZ0QnV0dG9uRXhpc3QoX2NvbmZpZy5sZWZ0QnRuKSB8fFxyXG4gICAgICAgICAgICB0aGlzLl9pc01vcmVCdG5FeGlzdChfY29uZmlnLm1vcmVCdG4pIHx8XHJcbiAgICAgICAgICAgIHRoaXMuX2lzU2VhcmNoQnRuRXhpc3QoX2NvbmZpZy5zZWFyY2hCdG4pXHJcbiAgICAgICAgKTtcclxuICAgIH1cclxuXHJcbiAgICBwdWJsaWMgdXBkYXRlVG9vbGJhckNvbmZpZyAoX2NvbmZpZzogSVBhZ2VoZWFkZXJDb25maWcpOiBJVG9vbGJhckNvbmZpZyB7XHJcbiAgICAgICAgbGV0IHRvb2xiYXJDb25maWc6IElUb29sYmFyQ29uZmlnID0ge307XHJcbiAgICAgICAgbGV0IHNlYXJjaENvbmZpZzogSVRvb2xiYXJDb25maWcgPSB7fTtcclxuXHJcbiAgICAgICAgLy8vIFRpdGxlIGNoZWNrc1xyXG4gICAgICAgIGlmICh0eXBlb2YgX2NvbmZpZy5wYWdlaGVhZGVyVGV4dCA9PT0gJ3VuZGVmaW5lZCcpIHtcclxuICAgICAgICAgICAgX2NvbmZpZy5wYWdlaGVhZGVyVGV4dCA9ICcnO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgLy8vIE1vcmUgYnV0dG9uIGNoZWNrc1xyXG4gICAgICAgIGlmICh0eXBlb2YgX2NvbmZpZy5tb3JlQWN0aW9uID09PSAndW5kZWZpbmVkJyB8fCAodHlwZW9mIF9jb25maWcubW9yZUJ0biA9PT0gJ3VuZGVmaW5lZCcgfHwgIV9jb25maWcubW9yZUJ0bikpIHtcclxuICAgICAgICAgICAgX2NvbmZpZy5tb3JlQWN0aW9uID0gW107XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICAvLy8gTGVmdCBidXR0b24gY2hlY2tzXHJcbiAgICAgICAgaWYgKHR5cGVvZiBfY29uZmlnLmxlZnRCdG4gPT09ICd1bmRlZmluZWQnKSB7XHJcbiAgICAgICAgICAgIF9jb25maWcubGVmdEJ0biA9IFtdO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgaWYgKF9jb25maWcubGVmdEJ0bi5sZW5ndGggPiA2KSB7XHJcbiAgICAgICAgICAgIGNvbnNvbGUud2FybignS2RUb29sYmFyIHdhcm5pbmc6IExlZnQgYnV0dG9ucyBvbmx5IHRha2UgdXAgdG8gNiBidXR0b25zLiBTbGljaW5nIHRvIDYgYnV0dG9ucycpO1xyXG4gICAgICAgICAgICBfY29uZmlnLmxlZnRCdG4uc3BsaWNlKDYpO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgLy8vIFNlYXJjaCBjaGVja3NcclxuICAgICAgICBpZiAodHlwZW9mIF9jb25maWcuc2VhcmNoRXZlbnQgPT09ICd1bmRlZmluZWQnKSB7XHJcbiAgICAgICAgICAgIF9jb25maWcuc2VhcmNoRXZlbnQgPSBbXTtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIGlmICh0eXBlb2YgX2NvbmZpZy5zZWFyY2hQbGFjZWhvbGRlciA9PT0gJ3VuZGVmaW5lZCcpIHtcclxuICAgICAgICAgICAgX2NvbmZpZy5zZWFyY2hQbGFjZWhvbGRlciA9IHRoaXMuUExBQ0VIT0xERVJfREVGQVVMVDtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIGlmICh0eXBlb2YgX2NvbmZpZy5zZWFyY2hUZXh0ID09PSAndW5kZWZpbmVkJykge1xyXG4gICAgICAgICAgICBfY29uZmlnLnNlYXJjaFRleHQgPSAnJztcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIGlmICh0eXBlb2YgX2NvbmZpZy5zZWFyY2hCdG4gPT09ICd1bmRlZmluZWQnKSB7XHJcbiAgICAgICAgICAgIF9jb25maWcuc2VhcmNoQnRuID0gZmFsc2U7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICBpZiAoX2NvbmZpZy5zZWFyY2hCdG4pIHtcclxuICAgICAgICAgICAgc2VhcmNoQ29uZmlnID0ge1xyXG4gICAgICAgICAgICAgICAgc2VhcmNoUGxhY2Vob2xkZXI6IF9jb25maWcuc2VhcmNoUGxhY2Vob2xkZXIsXHJcbiAgICAgICAgICAgICAgICBzZWFyY2hDYWxsYmFjazogX2NvbmZpZy5zZWFyY2hDYWxsYmFjayxcclxuICAgICAgICAgICAgICAgIHNlYXJjaEV2ZW50OiBfY29uZmlnLnNlYXJjaEV2ZW50LFxyXG4gICAgICAgICAgICAgICAgc2VhcmNoVGV4dDogX2NvbmZpZy5zZWFyY2hUZXh0XHJcbiAgICAgICAgICAgIH07XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICB0b29sYmFyQ29uZmlnID0ge1xyXG4gICAgICAgICAgICBsZWZ0QnRuOiBfY29uZmlnLmxlZnRCdG4sXHJcbiAgICAgICAgICAgIG1vcmVBY3Rpb246IF9jb25maWcubW9yZUFjdGlvbixcclxuICAgICAgICAgICAgc2VhcmNoQnRuOiBfY29uZmlnLnNlYXJjaEJ0blxyXG4gICAgICAgIH07XHJcblxyXG4gICAgICAgIHJldHVybiB7Li4udG9vbGJhckNvbmZpZywgLi4uc2VhcmNoQ29uZmlnfTtcclxuICAgIH1cclxuXHJcbiAgICAvKioqKioqKioqKioqKioqKioqIFByaXZhdGUgZnVuY3Rpb24gKioqKioqKioqKioqKioqKioqKioqKi9cclxuICAgIC8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy9cclxuICAgIC8vLyBDaGVja2luZyBmdW5jdGlvblxyXG4gICAgLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vL1xyXG4gICAgcHJpdmF0ZSBfaXNMZWZ0QnV0dG9uRXhpc3QoX2xlZnRCdG46IEFycmF5PElUb29sYmFyQnV0dG9uPik6IGJvb2xlYW4ge1xyXG4gICAgICAgIHJldHVybiAodHlwZW9mIF9sZWZ0QnRuICE9PSAndW5kZWZpbmVkJyAmJiBfbGVmdEJ0bi5sZW5ndGggPiAwKTtcclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF9pc01vcmVCdG5FeGlzdChfbW9yZUJ0bjogYm9vbGVhbik6IGJvb2xlYW4ge1xyXG4gICAgICAgIHJldHVybiAodHlwZW9mIF9tb3JlQnRuICE9PSAndW5kZWZpbmVkJyAmJiBfbW9yZUJ0bik7XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfaXNTZWFyY2hCdG5FeGlzdChfc2VhcmNoQnRuOiBib29sZWFuKSB7XHJcbiAgICAgICAgcmV0dXJuICh0eXBlb2YgX3NlYXJjaEJ0biAhPT0gJ3VuZGVmaW5lZCcgJiYgX3NlYXJjaEJ0bik7XHJcbiAgICB9XHJcbn1cclxuIl19