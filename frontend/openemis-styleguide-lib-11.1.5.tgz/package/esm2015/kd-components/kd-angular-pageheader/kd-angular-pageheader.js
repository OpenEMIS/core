import { timer as observableTimer, fromEvent } from 'rxjs';
import { debounceTime } from 'rxjs/operators';
/*******************************************************************************
    Component file     : kd-angular-pageheader.ts
    Service file       : kd-angular-pageheader-svc.ts
    Event file         : -
    Interface file     : kd-angular-pageheader-interface.ts
    Version            : 2.0
    Created by         : Cheng Kok Keong
    Purpose            : Show the title of the current page in the template area under breadcrumb

    Behaviour           :
        - Behaviour for page title element:
            --------------------------------------------------------------------------
            | Case | Left buttons | Search button | More button | Width              |
            --------------------------------------------------------------------------
            |  Left buttons                                                          |
            |      | (/)          | (/)           | (/)         | 200px              |
            |      | (/)          | (/)           | (x)         | 200px              |
            |      | (/)          | (x)           | (/)         | 200px              |
            |      | (/)          | (x)           | (x)         | 200px              |
            --------------------------------------------------------------------------
            |  Search buttons                                                        |
            |      | (x)          | (/)           | (/)         | calc(100% - 340px) |
            |      | (x)          | (/)           | (x)         | calc(100% - 300px) |
            --------------------------------------------------------------------------
            |  More buttons                                                          |
            |      | (x)          | (x)           | (/)         | calc(100% - 40px)  |
            --------------------------------------------------------------------------
            |  No buttons                                                            |
            |      | (x)          | (x)           | (x)         | 100%               |
            --------------------------------------------------------------------------

    Last change         :
        - Rewrite component and service

 *******************************************************************************/
import { Component, Input, ViewEncapsulation, HostBinding, ViewContainerRef, } from '@angular/core';
import { KdPageheaderSvc } from './kd-angular-pageheader-svc';
import { DELAY_TIME } from '../kd-common/index';
export class KdPageheader {
    constructor(_vcr, _pageheaderSvc) {
        this._vcr = _vcr;
        this._pageheaderSvc = _pageheaderSvc;
        this.toolbarExist = false;
        this.expendTitle = false;
        this.toggleTransition = false;
        this.titleClickable = false;
        this.checkTitleComplete = false;
        this.hideToolbar = false;
        this._subscriptionObj = {};
        this.hasLeftBtns = false;
        this.hasSearchBtn = false;
        this.hasMoreBtn = false;
        this.mobileView = false;
    }
    /************************* Life cycles functions *****************************/
    ngOnInit() {
        // console.log('-- Pageheader Component: OnInit --', this.config);
        this._setTransitionTo(false);
        this._setupObservableEvents();
        this._processConfigCycle();
        this._generateApi(this.api, this.config);
    }
    ngOnChanges(_simpleChanges) {
        // console.log('-- Pageheader Component: OnChanges --', _simpleChanges);
        if (_simpleChanges.hasOwnProperty('config') && !_simpleChanges['config'].firstChange) {
            this._processConfigCycle();
            this._updateDOMCycle(DELAY_TIME);
        }
    }
    ngAfterViewInit() {
        // console.log('-- Pageheader Component: AfterViewInit --');
        this._updateDOMCycle();
    }
    ngOnDestroy() {
        // console.log('-- Pageheader Component: OnDestroy --');
        for (let subObject in this._subscriptionObj) {
            if (this._subscriptionObj.hasOwnProperty(subObject)) {
                this._subscriptionObj[subObject].unsubscribe();
            }
        }
    }
    /**************************** Events functions *******************************/
    titleClicked(_event) {
        if (this.mobileView || !this.titleClickable)
            return;
        this.expendTitle = !this.expendTitle;
    }
    updateSearchText(_searchText) {
        this.config.searchText = _searchText;
    }
    /**************************** Private functions ******************************/
    ///////////////////////////////////////////////////////
    /// Cycle events
    ///////////////////////////////////////////////////////
    _processConfigCycle() {
        if (typeof this.config === 'undefined') {
            this.config = {};
        }
        this.toolbarConfig = this._pageheaderSvc.updateToolbarConfig(this.config);
        this._updateToolbarExist();
        this._updateHostBinding();
    }
    _updateDOMCycle(_delayTime = 1) {
        observableTimer().subscribe(() => {
            this._updateViewClass();
            this._updateClickableCycle(_delayTime);
        });
    }
    _updateClickableCycle(_delayTime = 1) {
        if (this._subscriptionObj.hasOwnProperty('timer')) {
            this._subscriptionObj['timer'].unsubscribe();
        }
        this.checkTitleComplete = false;
        this._setTitleClickable(_delayTime);
    }
    ///////////////////////////////////////////////////////
    /// DOM Cycle function
    ///////////////////////////////////////////////////////
    _setupObservableEvents() {
        this._subscriptionObj['resize'] = fromEvent(window, 'resize')
            .pipe(debounceTime(DELAY_TIME))
            .subscribe((_event) => {
            this._updateDOMCycle();
        });
    }
    _updateViewClass() {
        this.mobileView = window.innerWidth <= 1024;
        if (this.mobileView) {
            this.expendTitle = false;
        }
    }
    _setTransitionTo(_toggle) {
        this.toggleTransition = _toggle;
    }
    _setTitleClickable(_delay) {
        this._subscriptionObj['timer'] = observableTimer(_delay)
            .subscribe(() => {
            let titleElement = this._vcr.element.nativeElement.querySelector('.title');
            let actualElement = this._vcr.element.nativeElement.querySelector('#heightCheck');
            if (titleElement !== null && actualElement !== null) {
                this.titleClickable = titleElement.getBoundingClientRect().width < actualElement.getBoundingClientRect().width;
            }
            else {
                this.titleClickable = false;
            }
            this._setTransitionTo(true);
            this.checkTitleComplete = true;
        });
    }
    _updateHostBinding() {
        this.hasLeftBtns = this.toolbarConfig.leftBtn.length > 0;
        this.hasMoreBtn = this.toolbarConfig.moreAction.length > 0;
        this.hasSearchBtn = this.toolbarConfig.searchBtn;
    }
    ///////////////////////////////////////////////////////
    /// API Generation
    ///////////////////////////////////////////////////////
    _generateApi(_api, _config) {
        if (typeof _api !== 'undefined') {
            _api.updateTitle = (_newTitle = '') => {
                _config.pageheaderText = _newTitle;
                this._updateClickableCycle();
            };
            _api.updateLeftButton = (_newLeftBtn) => {
                this._setTransitionTo(false);
                this.config.leftBtn = _newLeftBtn;
                this._processConfigCycle();
                this._updateClickableCycle(DELAY_TIME);
            };
            _api.updateMoreButton = (_enabled, _list) => {
                this._setTransitionTo(false);
                this.config.moreBtn = _enabled;
                this.config.moreAction = _list;
                this._processConfigCycle();
                this._updateClickableCycle(DELAY_TIME);
            };
            _api.updateSearchButton = (_searchConfig) => {
                this._setTransitionTo(false);
                this.config = Object.assign(this.config, _searchConfig);
                this._processConfigCycle();
                this._updateClickableCycle(DELAY_TIME);
            };
        }
        else {
            console.warn('KdPageheader warning: No api is passed in.');
        }
    }
    ///////////////////////////////////////////////////////
    /// Config functions
    ///////////////////////////////////////////////////////
    _updateToolbarExist() {
        this.toolbarExist = this._pageheaderSvc.isToolbarExist(this.config);
    }
}
KdPageheader.decorators = [
    { type: Component, args: [{
                selector: 'kd-pageheader',
                template: "<div class='kdx-page-header'>\r\n    <div class='title' \r\n        [ngClass]=\" {\r\n            'expend-title': expendTitle && titleClickable,\r\n            'collapse-title': !expendTitle && titleClickable,\r\n            'animation': toggleTransition \r\n        }\" (click)='titleClicked($event)'>\r\n            <h2 class='page-title'>{{config.pageheaderText}}</h2>\r\n            <i class=\"arrow-icon\"></i>\r\n    </div>\r\n    <ng-template [ngIf]='toolbarExist'>\r\n        <kd-toolbar \r\n            class='page-toolbar'\r\n            [ngClass]=\"{'hide-toolbar': hideToolbar}\"\r\n            [config]='toolbarConfig'\r\n            [mobileView]='mobileView'\r\n            (searchTextChanged)='updateSearchText($event)'\r\n        ></kd-toolbar>\r\n    </ng-template>\r\n</div>\r\n<h2 *ngIf=\"!checkTitleComplete\" id='heightCheck' style=\"position: absolute; z-index: -1;\">{{config.pageheaderText}}</h2>\r\n",
                encapsulation: ViewEncapsulation.None,
                providers: [KdPageheaderSvc]
            },] }
];
KdPageheader.ctorParameters = () => [
    { type: ViewContainerRef },
    { type: KdPageheaderSvc }
];
KdPageheader.propDecorators = {
    config: [{ type: Input }],
    api: [{ type: Input }],
    hasLeftBtns: [{ type: HostBinding, args: ['class.has-left-btn',] }],
    hasSearchBtn: [{ type: HostBinding, args: ['class.has-search-btn',] }],
    hasMoreBtn: [{ type: HostBinding, args: ['class.has-more-btn',] }],
    mobileView: [{ type: HostBinding, args: ['class.pageheader-mobile',] }]
};
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoia2QtYW5ndWxhci1wYWdlaGVhZGVyLmpzIiwic291cmNlUm9vdCI6IkM6L3hhbXBwL2h0ZG9jcy9TdHlsZWd1aWRlL2lvc3RnLW9wZW5lbWlzLXN0eWxlZ3VpZGUvcHJvamVjdHMvb3BlbmVtaXMtc3R5bGVndWlkZS1saWIvc3JjLyIsInNvdXJjZXMiOlsia2QtY29tcG9uZW50cy9rZC1hbmd1bGFyLXBhZ2VoZWFkZXIva2QtYW5ndWxhci1wYWdlaGVhZGVyLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUNBLE9BQU8sRUFBRSxLQUFLLElBQUksZUFBZSxFQUFnQixTQUFTLEVBQUUsTUFBTSxNQUFNLENBQUM7QUFDekUsT0FBTyxFQUFFLFlBQVksRUFBRSxNQUFNLGdCQUFnQixDQUFDO0FBQzlDOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O2lGQWtDaUY7QUFJakYsT0FBTyxFQUNILFNBQVMsRUFNVCxLQUFLLEVBQ0wsaUJBQWlCLEVBQ2pCLFdBQVcsRUFDWCxnQkFBZ0IsR0FDbkIsTUFBTSxlQUFlLENBQUM7QUFDdkIsT0FBTyxFQUFFLGVBQWUsRUFBRSxNQUFNLDZCQUE2QixDQUFDO0FBUzlELE9BQU8sRUFBRSxVQUFVLEVBQUUsTUFBTSxvQkFBb0IsQ0FBQztBQVNoRCxNQUFNLE9BQU8sWUFBWTtJQWtCckIsWUFDWSxJQUFzQixFQUN0QixjQUErQjtRQUQvQixTQUFJLEdBQUosSUFBSSxDQUFrQjtRQUN0QixtQkFBYyxHQUFkLGNBQWMsQ0FBaUI7UUFsQnBDLGlCQUFZLEdBQVksS0FBSyxDQUFDO1FBQzlCLGdCQUFXLEdBQVksS0FBSyxDQUFDO1FBQzdCLHFCQUFnQixHQUFZLEtBQUssQ0FBQztRQUNsQyxtQkFBYyxHQUFZLEtBQUssQ0FBQztRQUNoQyx1QkFBa0IsR0FBWSxLQUFLLENBQUM7UUFDcEMsZ0JBQVcsR0FBWSxLQUFLLENBQUM7UUFFNUIscUJBQWdCLEdBQW9DLEVBQUUsQ0FBQztRQUk1QixnQkFBVyxHQUFZLEtBQUssQ0FBQztRQUMzQixpQkFBWSxHQUFZLEtBQUssQ0FBQztRQUNoQyxlQUFVLEdBQVksS0FBSyxDQUFDO1FBQ3ZCLGVBQVUsR0FBWSxLQUFLLENBQUM7SUFLaEUsQ0FBQztJQUVMLCtFQUErRTtJQUMvRSxRQUFRO1FBQ0osa0VBQWtFO1FBQ2xFLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxLQUFLLENBQUMsQ0FBQztRQUM3QixJQUFJLENBQUMsc0JBQXNCLEVBQUUsQ0FBQztRQUM5QixJQUFJLENBQUMsbUJBQW1CLEVBQUUsQ0FBQztRQUMzQixJQUFJLENBQUMsWUFBWSxDQUFDLElBQUksQ0FBQyxHQUFHLEVBQUUsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDO0lBQzdDLENBQUM7SUFFRCxXQUFXLENBQUMsY0FBNkI7UUFDckMsd0VBQXdFO1FBQ3hFLElBQUksY0FBYyxDQUFDLGNBQWMsQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLGNBQWMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxXQUFXLEVBQUU7WUFDbEYsSUFBSSxDQUFDLG1CQUFtQixFQUFFLENBQUM7WUFDM0IsSUFBSSxDQUFDLGVBQWUsQ0FBQyxVQUFVLENBQUMsQ0FBQztTQUNwQztJQUNMLENBQUM7SUFFRCxlQUFlO1FBQ1gsNERBQTREO1FBQzVELElBQUksQ0FBQyxlQUFlLEVBQUUsQ0FBQztJQUMzQixDQUFDO0lBRUQsV0FBVztRQUNQLHdEQUF3RDtRQUN4RCxLQUFLLElBQUksU0FBUyxJQUFJLElBQUksQ0FBQyxnQkFBZ0IsRUFBRTtZQUN6QyxJQUFJLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxjQUFjLENBQUMsU0FBUyxDQUFDLEVBQUU7Z0JBQ2pELElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxTQUFTLENBQUMsQ0FBQyxXQUFXLEVBQUUsQ0FBQzthQUNsRDtTQUNKO0lBQ0wsQ0FBQztJQUVELCtFQUErRTtJQUN4RSxZQUFZLENBQUMsTUFBYTtRQUM3QixJQUFJLElBQUksQ0FBQyxVQUFVLElBQUksQ0FBQyxJQUFJLENBQUMsY0FBYztZQUFFLE9BQU87UUFFcEQsSUFBSSxDQUFDLFdBQVcsR0FBRyxDQUFDLElBQUksQ0FBQyxXQUFXLENBQUM7SUFDekMsQ0FBQztJQUVNLGdCQUFnQixDQUFDLFdBQW1CO1FBQ3ZDLElBQUksQ0FBQyxNQUFNLENBQUMsVUFBVSxHQUFHLFdBQVcsQ0FBQztJQUN6QyxDQUFDO0lBRUQsK0VBQStFO0lBQy9FLHVEQUF1RDtJQUN2RCxnQkFBZ0I7SUFDaEIsdURBQXVEO0lBQy9DLG1CQUFtQjtRQUN2QixJQUFJLE9BQU8sSUFBSSxDQUFDLE1BQU0sS0FBSyxXQUFXLEVBQUU7WUFDcEMsSUFBSSxDQUFDLE1BQU0sR0FBRyxFQUFFLENBQUM7U0FDcEI7UUFFRCxJQUFJLENBQUMsYUFBYSxHQUFHLElBQUksQ0FBQyxjQUFjLENBQUMsbUJBQW1CLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDO1FBQzFFLElBQUksQ0FBQyxtQkFBbUIsRUFBRSxDQUFDO1FBQzNCLElBQUksQ0FBQyxrQkFBa0IsRUFBRSxDQUFDO0lBQzlCLENBQUM7SUFFTyxlQUFlLENBQUMsYUFBcUIsQ0FBQztRQUMxQyxlQUFlLEVBQUUsQ0FBQyxTQUFTLENBQUMsR0FBUyxFQUFFO1lBQ25DLElBQUksQ0FBQyxnQkFBZ0IsRUFBRSxDQUFDO1lBQ3hCLElBQUksQ0FBQyxxQkFBcUIsQ0FBQyxVQUFVLENBQUMsQ0FBQztRQUMzQyxDQUFDLENBQUMsQ0FBQztJQUNQLENBQUM7SUFFTyxxQkFBcUIsQ0FBQyxhQUFxQixDQUFDO1FBQ2hELElBQUksSUFBSSxDQUFDLGdCQUFnQixDQUFDLGNBQWMsQ0FBQyxPQUFPLENBQUMsRUFBRTtZQUMvQyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsT0FBTyxDQUFDLENBQUMsV0FBVyxFQUFFLENBQUM7U0FDaEQ7UUFFRCxJQUFJLENBQUMsa0JBQWtCLEdBQUcsS0FBSyxDQUFDO1FBQ2hDLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxVQUFVLENBQUMsQ0FBQztJQUN4QyxDQUFDO0lBRUQsdURBQXVEO0lBQ3ZELHNCQUFzQjtJQUN0Qix1REFBdUQ7SUFDL0Msc0JBQXNCO1FBQzFCLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxRQUFRLENBQUMsR0FBRyxTQUFTLENBQUMsTUFBTSxFQUFFLFFBQVEsQ0FBQzthQUN4RCxJQUFJLENBQ0QsWUFBWSxDQUFDLFVBQVUsQ0FBQyxDQUMzQjthQUNBLFNBQVMsQ0FDTixDQUFDLE1BQWEsRUFBUSxFQUFFO1lBQ3BCLElBQUksQ0FBQyxlQUFlLEVBQUUsQ0FBQztRQUMzQixDQUFDLENBQ0osQ0FBQztJQUNWLENBQUM7SUFFTyxnQkFBZ0I7UUFDcEIsSUFBSSxDQUFDLFVBQVUsR0FBRyxNQUFNLENBQUMsVUFBVSxJQUFJLElBQUksQ0FBQztRQUU1QyxJQUFJLElBQUksQ0FBQyxVQUFVLEVBQUU7WUFDakIsSUFBSSxDQUFDLFdBQVcsR0FBRyxLQUFLLENBQUM7U0FDNUI7SUFDTCxDQUFDO0lBRU8sZ0JBQWdCLENBQUMsT0FBZ0I7UUFDckMsSUFBSSxDQUFDLGdCQUFnQixHQUFHLE9BQU8sQ0FBQztJQUNwQyxDQUFDO0lBRU8sa0JBQWtCLENBQUMsTUFBYztRQUNyQyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsT0FBTyxDQUFDLEdBQUcsZUFBZSxDQUFDLE1BQU0sQ0FBQzthQUNuRCxTQUFTLENBQ04sR0FBUyxFQUFFO1lBQ1AsSUFBSSxZQUFZLEdBQVksSUFBSSxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsYUFBYSxDQUFDLGFBQWEsQ0FBQyxRQUFRLENBQUMsQ0FBQztZQUNwRixJQUFJLGFBQWEsR0FBWSxJQUFJLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxhQUFhLENBQUMsYUFBYSxDQUFDLGNBQWMsQ0FBQyxDQUFDO1lBRTNGLElBQUksWUFBWSxLQUFLLElBQUksSUFBSSxhQUFhLEtBQUssSUFBSSxFQUFFO2dCQUNqRCxJQUFJLENBQUMsY0FBYyxHQUFHLFlBQVksQ0FBQyxxQkFBcUIsRUFBRSxDQUFDLEtBQUssR0FBRyxhQUFhLENBQUMscUJBQXFCLEVBQUUsQ0FBQyxLQUFLLENBQUM7YUFDbEg7aUJBQ0k7Z0JBQ0QsSUFBSSxDQUFDLGNBQWMsR0FBRyxLQUFLLENBQUM7YUFDL0I7WUFFRCxJQUFJLENBQUMsZ0JBQWdCLENBQUMsSUFBSSxDQUFDLENBQUM7WUFDNUIsSUFBSSxDQUFDLGtCQUFrQixHQUFHLElBQUksQ0FBQztRQUNuQyxDQUFDLENBQ0osQ0FBQztJQUNWLENBQUM7SUFFTyxrQkFBa0I7UUFDdEIsSUFBSSxDQUFDLFdBQVcsR0FBRyxJQUFJLENBQUMsYUFBYSxDQUFDLE9BQU8sQ0FBQyxNQUFNLEdBQUcsQ0FBQyxDQUFDO1FBQ3pELElBQUksQ0FBQyxVQUFVLEdBQUcsSUFBSSxDQUFDLGFBQWEsQ0FBQyxVQUFVLENBQUMsTUFBTSxHQUFHLENBQUMsQ0FBQztRQUMzRCxJQUFJLENBQUMsWUFBWSxHQUFHLElBQUksQ0FBQyxhQUFhLENBQUMsU0FBUyxDQUFDO0lBQ3JELENBQUM7SUFFRCx1REFBdUQ7SUFDdkQsa0JBQWtCO0lBQ2xCLHVEQUF1RDtJQUMvQyxZQUFZLENBQUMsSUFBb0IsRUFBRSxPQUEwQjtRQUNqRSxJQUFJLE9BQU8sSUFBSSxLQUFLLFdBQVcsRUFBRTtZQUM3QixJQUFJLENBQUMsV0FBVyxHQUFHLENBQUMsWUFBb0IsRUFBRSxFQUFRLEVBQUU7Z0JBQ2hELE9BQU8sQ0FBQyxjQUFjLEdBQUcsU0FBUyxDQUFDO2dCQUNuQyxJQUFJLENBQUMscUJBQXFCLEVBQUUsQ0FBQztZQUNqQyxDQUFDLENBQUM7WUFFRixJQUFJLENBQUMsZ0JBQWdCLEdBQUcsQ0FBQyxXQUFtQyxFQUFRLEVBQUU7Z0JBQ2xFLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxLQUFLLENBQUMsQ0FBQztnQkFDN0IsSUFBSSxDQUFDLE1BQU0sQ0FBQyxPQUFPLEdBQUcsV0FBVyxDQUFDO2dCQUNsQyxJQUFJLENBQUMsbUJBQW1CLEVBQUUsQ0FBQztnQkFDM0IsSUFBSSxDQUFDLHFCQUFxQixDQUFDLFVBQVUsQ0FBQyxDQUFDO1lBQzNDLENBQUMsQ0FBQztZQUVGLElBQUksQ0FBQyxnQkFBZ0IsR0FBRyxDQUFDLFFBQWlCLEVBQUUsS0FBZ0MsRUFBUSxFQUFFO2dCQUNsRixJQUFJLENBQUMsZ0JBQWdCLENBQUMsS0FBSyxDQUFDLENBQUM7Z0JBQzdCLElBQUksQ0FBQyxNQUFNLENBQUMsT0FBTyxHQUFHLFFBQVEsQ0FBQztnQkFDL0IsSUFBSSxDQUFDLE1BQU0sQ0FBQyxVQUFVLEdBQUcsS0FBSyxDQUFDO2dCQUMvQixJQUFJLENBQUMsbUJBQW1CLEVBQUUsQ0FBQztnQkFDM0IsSUFBSSxDQUFDLHFCQUFxQixDQUFDLFVBQVUsQ0FBQyxDQUFDO1lBQzNDLENBQUMsQ0FBQztZQUVGLElBQUksQ0FBQyxrQkFBa0IsR0FBRyxDQUFDLGFBQW9DLEVBQVEsRUFBRTtnQkFDckUsSUFBSSxDQUFDLGdCQUFnQixDQUFDLEtBQUssQ0FBQyxDQUFDO2dCQUM3QixJQUFJLENBQUMsTUFBTSxHQUFHLE1BQU0sQ0FBQyxNQUFNLENBQTZDLElBQUksQ0FBQyxNQUFNLEVBQUUsYUFBYSxDQUFDLENBQUM7Z0JBQ3BHLElBQUksQ0FBQyxtQkFBbUIsRUFBRSxDQUFDO2dCQUMzQixJQUFJLENBQUMscUJBQXFCLENBQUMsVUFBVSxDQUFDLENBQUM7WUFDM0MsQ0FBQyxDQUFDO1NBQ0w7YUFDSTtZQUNELE9BQU8sQ0FBQyxJQUFJLENBQUMsNENBQTRDLENBQUMsQ0FBQztTQUM5RDtJQUNMLENBQUM7SUFFRCx1REFBdUQ7SUFDdkQsb0JBQW9CO0lBQ3BCLHVEQUF1RDtJQUMvQyxtQkFBbUI7UUFDdkIsSUFBSSxDQUFDLFlBQVksR0FBRyxJQUFJLENBQUMsY0FBYyxDQUFDLGNBQWMsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUM7SUFDeEUsQ0FBQzs7O1lBck1KLFNBQVMsU0FBQztnQkFDUCxRQUFRLEVBQUUsZUFBZTtnQkFDekIsdzZCQUEyQztnQkFDM0MsYUFBYSxFQUFFLGlCQUFpQixDQUFDLElBQUk7Z0JBQ3JDLFNBQVMsRUFBRSxDQUFDLGVBQWUsQ0FBQzthQUMvQjs7O1lBbEJHLGdCQUFnQjtZQUVYLGVBQWU7OztxQkE2Qm5CLEtBQUs7a0JBQ0wsS0FBSzswQkFDTCxXQUFXLFNBQUMsb0JBQW9COzJCQUNoQyxXQUFXLFNBQUMsc0JBQXNCO3lCQUNsQyxXQUFXLFNBQUMsb0JBQW9CO3lCQUNoQyxXQUFXLFNBQUMseUJBQXlCIiwic291cmNlc0NvbnRlbnQiOlsiXHJcbmltcG9ydCB7IHRpbWVyIGFzIG9ic2VydmFibGVUaW1lciwgU3Vic2NyaXB0aW9uLCBmcm9tRXZlbnQgfSBmcm9tICdyeGpzJztcclxuaW1wb3J0IHsgZGVib3VuY2VUaW1lIH0gZnJvbSAncnhqcy9vcGVyYXRvcnMnO1xyXG4vKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKlxyXG4gICAgQ29tcG9uZW50IGZpbGUgICAgIDoga2QtYW5ndWxhci1wYWdlaGVhZGVyLnRzXHJcbiAgICBTZXJ2aWNlIGZpbGUgICAgICAgOiBrZC1hbmd1bGFyLXBhZ2VoZWFkZXItc3ZjLnRzXHJcbiAgICBFdmVudCBmaWxlICAgICAgICAgOiAtXHJcbiAgICBJbnRlcmZhY2UgZmlsZSAgICAgOiBrZC1hbmd1bGFyLXBhZ2VoZWFkZXItaW50ZXJmYWNlLnRzXHJcbiAgICBWZXJzaW9uICAgICAgICAgICAgOiAyLjBcclxuICAgIENyZWF0ZWQgYnkgICAgICAgICA6IENoZW5nIEtvayBLZW9uZ1xyXG4gICAgUHVycG9zZSAgICAgICAgICAgIDogU2hvdyB0aGUgdGl0bGUgb2YgdGhlIGN1cnJlbnQgcGFnZSBpbiB0aGUgdGVtcGxhdGUgYXJlYSB1bmRlciBicmVhZGNydW1iXHJcblxyXG4gICAgQmVoYXZpb3VyICAgICAgICAgICA6XHJcbiAgICAgICAgLSBCZWhhdmlvdXIgZm9yIHBhZ2UgdGl0bGUgZWxlbWVudDpcclxuICAgICAgICAgICAgLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cclxuICAgICAgICAgICAgfCBDYXNlIHwgTGVmdCBidXR0b25zIHwgU2VhcmNoIGJ1dHRvbiB8IE1vcmUgYnV0dG9uIHwgV2lkdGggICAgICAgICAgICAgIHxcclxuICAgICAgICAgICAgLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cclxuICAgICAgICAgICAgfCAgTGVmdCBidXR0b25zICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHxcclxuICAgICAgICAgICAgfCAgICAgIHwgKC8pICAgICAgICAgIHwgKC8pICAgICAgICAgICB8ICgvKSAgICAgICAgIHwgMjAwcHggICAgICAgICAgICAgIHxcclxuICAgICAgICAgICAgfCAgICAgIHwgKC8pICAgICAgICAgIHwgKC8pICAgICAgICAgICB8ICh4KSAgICAgICAgIHwgMjAwcHggICAgICAgICAgICAgIHxcclxuICAgICAgICAgICAgfCAgICAgIHwgKC8pICAgICAgICAgIHwgKHgpICAgICAgICAgICB8ICgvKSAgICAgICAgIHwgMjAwcHggICAgICAgICAgICAgIHxcclxuICAgICAgICAgICAgfCAgICAgIHwgKC8pICAgICAgICAgIHwgKHgpICAgICAgICAgICB8ICh4KSAgICAgICAgIHwgMjAwcHggICAgICAgICAgICAgIHxcclxuICAgICAgICAgICAgLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cclxuICAgICAgICAgICAgfCAgU2VhcmNoIGJ1dHRvbnMgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHxcclxuICAgICAgICAgICAgfCAgICAgIHwgKHgpICAgICAgICAgIHwgKC8pICAgICAgICAgICB8ICgvKSAgICAgICAgIHwgY2FsYygxMDAlIC0gMzQwcHgpIHxcclxuICAgICAgICAgICAgfCAgICAgIHwgKHgpICAgICAgICAgIHwgKC8pICAgICAgICAgICB8ICh4KSAgICAgICAgIHwgY2FsYygxMDAlIC0gMzAwcHgpIHxcclxuICAgICAgICAgICAgLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cclxuICAgICAgICAgICAgfCAgTW9yZSBidXR0b25zICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHxcclxuICAgICAgICAgICAgfCAgICAgIHwgKHgpICAgICAgICAgIHwgKHgpICAgICAgICAgICB8ICgvKSAgICAgICAgIHwgY2FsYygxMDAlIC0gNDBweCkgIHxcclxuICAgICAgICAgICAgLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cclxuICAgICAgICAgICAgfCAgTm8gYnV0dG9ucyAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHxcclxuICAgICAgICAgICAgfCAgICAgIHwgKHgpICAgICAgICAgIHwgKHgpICAgICAgICAgICB8ICh4KSAgICAgICAgIHwgMTAwJSAgICAgICAgICAgICAgIHxcclxuICAgICAgICAgICAgLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cclxuXHJcbiAgICBMYXN0IGNoYW5nZSAgICAgICAgIDpcclxuICAgICAgICAtIFJld3JpdGUgY29tcG9uZW50IGFuZCBzZXJ2aWNlXHJcblxyXG4gKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKi9cclxuXHJcblxyXG5cclxuaW1wb3J0IHtcclxuICAgIENvbXBvbmVudCxcclxuICAgIE9uSW5pdCxcclxuICAgIEFmdGVyVmlld0luaXQsXHJcbiAgICBPbkNoYW5nZXMsXHJcbiAgICBTaW1wbGVDaGFuZ2VzLFxyXG4gICAgT25EZXN0cm95LFxyXG4gICAgSW5wdXQsXHJcbiAgICBWaWV3RW5jYXBzdWxhdGlvbixcclxuICAgIEhvc3RCaW5kaW5nLFxyXG4gICAgVmlld0NvbnRhaW5lclJlZixcclxufSBmcm9tICdAYW5ndWxhci9jb3JlJztcclxuaW1wb3J0IHsgS2RQYWdlaGVhZGVyU3ZjIH0gZnJvbSAnLi9rZC1hbmd1bGFyLXBhZ2VoZWFkZXItc3ZjJztcclxuaW1wb3J0IHtcclxuICAgIElUb29sYmFyU2VhcmNoQ29uZmlnLFxyXG4gICAgSVRvb2xiYXJDb25maWcsXHJcbiAgICBJVG9vbGJhck1vcmVCdXR0b24sXHJcbiAgICBJVG9vbGJhckJ1dHRvbixcclxuICAgIElQYWdlaGVhZGVyQ29uZmlnLFxyXG4gICAgSVBhZ2VoZWFkZXJBcGlcclxufSBmcm9tICcuL2tkLWFuZ3VsYXItcGFnZWhlYWRlci1pbnRlcmZhY2UnO1xyXG5pbXBvcnQgeyBERUxBWV9USU1FIH0gZnJvbSAnLi4va2QtY29tbW9uL2luZGV4JztcclxuXHJcbkBDb21wb25lbnQoe1xyXG4gICAgc2VsZWN0b3I6ICdrZC1wYWdlaGVhZGVyJyxcclxuICAgIHRlbXBsYXRlVXJsOiAnLi9rZC1hbmd1bGFyLXBhZ2VoZWFkZXIuaHRtbCcsXHJcbiAgICBlbmNhcHN1bGF0aW9uOiBWaWV3RW5jYXBzdWxhdGlvbi5Ob25lLFxyXG4gICAgcHJvdmlkZXJzOiBbS2RQYWdlaGVhZGVyU3ZjXVxyXG59KVxyXG5cclxuZXhwb3J0IGNsYXNzIEtkUGFnZWhlYWRlciBpbXBsZW1lbnRzIE9uSW5pdCwgT25DaGFuZ2VzLCBBZnRlclZpZXdJbml0LCBPbkRlc3Ryb3kge1xyXG4gICAgcHVibGljIHRvb2xiYXJDb25maWc6IElUb29sYmFyQ29uZmlnO1xyXG4gICAgcHVibGljIHRvb2xiYXJFeGlzdDogYm9vbGVhbiA9IGZhbHNlO1xyXG4gICAgcHVibGljIGV4cGVuZFRpdGxlOiBib29sZWFuID0gZmFsc2U7XHJcbiAgICBwdWJsaWMgdG9nZ2xlVHJhbnNpdGlvbjogYm9vbGVhbiA9IGZhbHNlO1xyXG4gICAgcHVibGljIHRpdGxlQ2xpY2thYmxlOiBib29sZWFuID0gZmFsc2U7XHJcbiAgICBwdWJsaWMgY2hlY2tUaXRsZUNvbXBsZXRlOiBib29sZWFuID0gZmFsc2U7XHJcbiAgICBwdWJsaWMgaGlkZVRvb2xiYXI6IGJvb2xlYW4gPSBmYWxzZTtcclxuXHJcbiAgICBwcml2YXRlIF9zdWJzY3JpcHRpb25PYmo6IHsgW2tleTogc3RyaW5nXTogU3Vic2NyaXB0aW9uIH0gPSB7fTtcclxuXHJcbiAgICBASW5wdXQoKSBjb25maWc6IElQYWdlaGVhZGVyQ29uZmlnO1xyXG4gICAgQElucHV0KCkgYXBpOiBJUGFnZWhlYWRlckFwaTtcclxuICAgIEBIb3N0QmluZGluZygnY2xhc3MuaGFzLWxlZnQtYnRuJykgaGFzTGVmdEJ0bnM6IGJvb2xlYW4gPSBmYWxzZTtcclxuICAgIEBIb3N0QmluZGluZygnY2xhc3MuaGFzLXNlYXJjaC1idG4nKSBoYXNTZWFyY2hCdG46IGJvb2xlYW4gPSBmYWxzZTtcclxuICAgIEBIb3N0QmluZGluZygnY2xhc3MuaGFzLW1vcmUtYnRuJykgaGFzTW9yZUJ0bjogYm9vbGVhbiA9IGZhbHNlO1xyXG4gICAgQEhvc3RCaW5kaW5nKCdjbGFzcy5wYWdlaGVhZGVyLW1vYmlsZScpIG1vYmlsZVZpZXc6IGJvb2xlYW4gPSBmYWxzZTtcclxuXHJcbiAgICBjb25zdHJ1Y3RvcihcclxuICAgICAgICBwcml2YXRlIF92Y3I6IFZpZXdDb250YWluZXJSZWYsXHJcbiAgICAgICAgcHJpdmF0ZSBfcGFnZWhlYWRlclN2YzogS2RQYWdlaGVhZGVyU3ZjXHJcbiAgICApIHsgfVxyXG5cclxuICAgIC8qKioqKioqKioqKioqKioqKioqKioqKioqIExpZmUgY3ljbGVzIGZ1bmN0aW9ucyAqKioqKioqKioqKioqKioqKioqKioqKioqKioqKi9cclxuICAgIG5nT25Jbml0KCk6IHZvaWQge1xyXG4gICAgICAgIC8vIGNvbnNvbGUubG9nKCctLSBQYWdlaGVhZGVyIENvbXBvbmVudDogT25Jbml0IC0tJywgdGhpcy5jb25maWcpO1xyXG4gICAgICAgIHRoaXMuX3NldFRyYW5zaXRpb25UbyhmYWxzZSk7XHJcbiAgICAgICAgdGhpcy5fc2V0dXBPYnNlcnZhYmxlRXZlbnRzKCk7XHJcbiAgICAgICAgdGhpcy5fcHJvY2Vzc0NvbmZpZ0N5Y2xlKCk7XHJcbiAgICAgICAgdGhpcy5fZ2VuZXJhdGVBcGkodGhpcy5hcGksIHRoaXMuY29uZmlnKTtcclxuICAgIH1cclxuXHJcbiAgICBuZ09uQ2hhbmdlcyhfc2ltcGxlQ2hhbmdlczogU2ltcGxlQ2hhbmdlcyk6IHZvaWQge1xyXG4gICAgICAgIC8vIGNvbnNvbGUubG9nKCctLSBQYWdlaGVhZGVyIENvbXBvbmVudDogT25DaGFuZ2VzIC0tJywgX3NpbXBsZUNoYW5nZXMpO1xyXG4gICAgICAgIGlmIChfc2ltcGxlQ2hhbmdlcy5oYXNPd25Qcm9wZXJ0eSgnY29uZmlnJykgJiYgIV9zaW1wbGVDaGFuZ2VzWydjb25maWcnXS5maXJzdENoYW5nZSkge1xyXG4gICAgICAgICAgICB0aGlzLl9wcm9jZXNzQ29uZmlnQ3ljbGUoKTtcclxuICAgICAgICAgICAgdGhpcy5fdXBkYXRlRE9NQ3ljbGUoREVMQVlfVElNRSk7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIG5nQWZ0ZXJWaWV3SW5pdCgpOiB2b2lkIHtcclxuICAgICAgICAvLyBjb25zb2xlLmxvZygnLS0gUGFnZWhlYWRlciBDb21wb25lbnQ6IEFmdGVyVmlld0luaXQgLS0nKTtcclxuICAgICAgICB0aGlzLl91cGRhdGVET01DeWNsZSgpO1xyXG4gICAgfVxyXG5cclxuICAgIG5nT25EZXN0cm95KCk6IHZvaWQge1xyXG4gICAgICAgIC8vIGNvbnNvbGUubG9nKCctLSBQYWdlaGVhZGVyIENvbXBvbmVudDogT25EZXN0cm95IC0tJyk7XHJcbiAgICAgICAgZm9yIChsZXQgc3ViT2JqZWN0IGluIHRoaXMuX3N1YnNjcmlwdGlvbk9iaikge1xyXG4gICAgICAgICAgICBpZiAodGhpcy5fc3Vic2NyaXB0aW9uT2JqLmhhc093blByb3BlcnR5KHN1Yk9iamVjdCkpIHtcclxuICAgICAgICAgICAgICAgIHRoaXMuX3N1YnNjcmlwdGlvbk9ialtzdWJPYmplY3RdLnVuc3Vic2NyaWJlKCk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgLyoqKioqKioqKioqKioqKioqKioqKioqKioqKiogRXZlbnRzIGZ1bmN0aW9ucyAqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqL1xyXG4gICAgcHVibGljIHRpdGxlQ2xpY2tlZChfZXZlbnQ6IEV2ZW50KTogdm9pZCB7XHJcbiAgICAgICAgaWYgKHRoaXMubW9iaWxlVmlldyB8fCAhdGhpcy50aXRsZUNsaWNrYWJsZSkgcmV0dXJuO1xyXG5cclxuICAgICAgICB0aGlzLmV4cGVuZFRpdGxlID0gIXRoaXMuZXhwZW5kVGl0bGU7XHJcbiAgICB9XHJcblxyXG4gICAgcHVibGljIHVwZGF0ZVNlYXJjaFRleHQoX3NlYXJjaFRleHQ6IHN0cmluZyk6IHZvaWQge1xyXG4gICAgICAgIHRoaXMuY29uZmlnLnNlYXJjaFRleHQgPSBfc2VhcmNoVGV4dDtcclxuICAgIH1cclxuXHJcbiAgICAvKioqKioqKioqKioqKioqKioqKioqKioqKioqKiBQcml2YXRlIGZ1bmN0aW9ucyAqKioqKioqKioqKioqKioqKioqKioqKioqKioqKiovXHJcbiAgICAvLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vXHJcbiAgICAvLy8gQ3ljbGUgZXZlbnRzXHJcbiAgICAvLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vXHJcbiAgICBwcml2YXRlIF9wcm9jZXNzQ29uZmlnQ3ljbGUoKTogdm9pZCB7XHJcbiAgICAgICAgaWYgKHR5cGVvZiB0aGlzLmNvbmZpZyA9PT0gJ3VuZGVmaW5lZCcpIHtcclxuICAgICAgICAgICAgdGhpcy5jb25maWcgPSB7fTtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIHRoaXMudG9vbGJhckNvbmZpZyA9IHRoaXMuX3BhZ2VoZWFkZXJTdmMudXBkYXRlVG9vbGJhckNvbmZpZyh0aGlzLmNvbmZpZyk7XHJcbiAgICAgICAgdGhpcy5fdXBkYXRlVG9vbGJhckV4aXN0KCk7XHJcbiAgICAgICAgdGhpcy5fdXBkYXRlSG9zdEJpbmRpbmcoKTtcclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF91cGRhdGVET01DeWNsZShfZGVsYXlUaW1lOiBudW1iZXIgPSAxKTogdm9pZCB7XHJcbiAgICAgICAgb2JzZXJ2YWJsZVRpbWVyKCkuc3Vic2NyaWJlKCgpOiB2b2lkID0+IHtcclxuICAgICAgICAgICAgdGhpcy5fdXBkYXRlVmlld0NsYXNzKCk7XHJcbiAgICAgICAgICAgIHRoaXMuX3VwZGF0ZUNsaWNrYWJsZUN5Y2xlKF9kZWxheVRpbWUpO1xyXG4gICAgICAgIH0pO1xyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX3VwZGF0ZUNsaWNrYWJsZUN5Y2xlKF9kZWxheVRpbWU6IG51bWJlciA9IDEpOiB2b2lkIHtcclxuICAgICAgICBpZiAodGhpcy5fc3Vic2NyaXB0aW9uT2JqLmhhc093blByb3BlcnR5KCd0aW1lcicpKSB7XHJcbiAgICAgICAgICAgIHRoaXMuX3N1YnNjcmlwdGlvbk9ialsndGltZXInXS51bnN1YnNjcmliZSgpO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgdGhpcy5jaGVja1RpdGxlQ29tcGxldGUgPSBmYWxzZTtcclxuICAgICAgICB0aGlzLl9zZXRUaXRsZUNsaWNrYWJsZShfZGVsYXlUaW1lKTtcclxuICAgIH1cclxuXHJcbiAgICAvLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vXHJcbiAgICAvLy8gRE9NIEN5Y2xlIGZ1bmN0aW9uXHJcbiAgICAvLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vXHJcbiAgICBwcml2YXRlIF9zZXR1cE9ic2VydmFibGVFdmVudHMoKTogdm9pZCB7XHJcbiAgICAgICAgdGhpcy5fc3Vic2NyaXB0aW9uT2JqWydyZXNpemUnXSA9IGZyb21FdmVudCh3aW5kb3csICdyZXNpemUnKVxyXG4gICAgICAgICAgICAucGlwZShcclxuICAgICAgICAgICAgICAgIGRlYm91bmNlVGltZShERUxBWV9USU1FKVxyXG4gICAgICAgICAgICApXHJcbiAgICAgICAgICAgIC5zdWJzY3JpYmUoXHJcbiAgICAgICAgICAgICAgICAoX2V2ZW50OiBFdmVudCk6IHZvaWQgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuX3VwZGF0ZURPTUN5Y2xlKCk7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICk7XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfdXBkYXRlVmlld0NsYXNzKCk6IHZvaWQge1xyXG4gICAgICAgIHRoaXMubW9iaWxlVmlldyA9IHdpbmRvdy5pbm5lcldpZHRoIDw9IDEwMjQ7XHJcblxyXG4gICAgICAgIGlmICh0aGlzLm1vYmlsZVZpZXcpIHtcclxuICAgICAgICAgICAgdGhpcy5leHBlbmRUaXRsZSA9IGZhbHNlO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF9zZXRUcmFuc2l0aW9uVG8oX3RvZ2dsZTogYm9vbGVhbik6IHZvaWQge1xyXG4gICAgICAgIHRoaXMudG9nZ2xlVHJhbnNpdGlvbiA9IF90b2dnbGU7XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfc2V0VGl0bGVDbGlja2FibGUoX2RlbGF5OiBudW1iZXIpOiB2b2lkIHtcclxuICAgICAgICB0aGlzLl9zdWJzY3JpcHRpb25PYmpbJ3RpbWVyJ10gPSBvYnNlcnZhYmxlVGltZXIoX2RlbGF5KVxyXG4gICAgICAgICAgICAuc3Vic2NyaWJlKFxyXG4gICAgICAgICAgICAgICAgKCk6IHZvaWQgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgIGxldCB0aXRsZUVsZW1lbnQ6IEVsZW1lbnQgPSB0aGlzLl92Y3IuZWxlbWVudC5uYXRpdmVFbGVtZW50LnF1ZXJ5U2VsZWN0b3IoJy50aXRsZScpO1xyXG4gICAgICAgICAgICAgICAgICAgIGxldCBhY3R1YWxFbGVtZW50OiBFbGVtZW50ID0gdGhpcy5fdmNyLmVsZW1lbnQubmF0aXZlRWxlbWVudC5xdWVyeVNlbGVjdG9yKCcjaGVpZ2h0Q2hlY2snKTtcclxuXHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKHRpdGxlRWxlbWVudCAhPT0gbnVsbCAmJiBhY3R1YWxFbGVtZW50ICE9PSBudWxsKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMudGl0bGVDbGlja2FibGUgPSB0aXRsZUVsZW1lbnQuZ2V0Qm91bmRpbmdDbGllbnRSZWN0KCkud2lkdGggPCBhY3R1YWxFbGVtZW50LmdldEJvdW5kaW5nQ2xpZW50UmVjdCgpLndpZHRoO1xyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy50aXRsZUNsaWNrYWJsZSA9IGZhbHNlO1xyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5fc2V0VHJhbnNpdGlvblRvKHRydWUpO1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuY2hlY2tUaXRsZUNvbXBsZXRlID0gdHJ1ZTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgKTtcclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF91cGRhdGVIb3N0QmluZGluZygpOiB2b2lkIHtcclxuICAgICAgICB0aGlzLmhhc0xlZnRCdG5zID0gdGhpcy50b29sYmFyQ29uZmlnLmxlZnRCdG4ubGVuZ3RoID4gMDtcclxuICAgICAgICB0aGlzLmhhc01vcmVCdG4gPSB0aGlzLnRvb2xiYXJDb25maWcubW9yZUFjdGlvbi5sZW5ndGggPiAwO1xyXG4gICAgICAgIHRoaXMuaGFzU2VhcmNoQnRuID0gdGhpcy50b29sYmFyQ29uZmlnLnNlYXJjaEJ0bjtcclxuICAgIH1cclxuXHJcbiAgICAvLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vXHJcbiAgICAvLy8gQVBJIEdlbmVyYXRpb25cclxuICAgIC8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy9cclxuICAgIHByaXZhdGUgX2dlbmVyYXRlQXBpKF9hcGk6IElQYWdlaGVhZGVyQXBpLCBfY29uZmlnOiBJUGFnZWhlYWRlckNvbmZpZyk6IHZvaWQge1xyXG4gICAgICAgIGlmICh0eXBlb2YgX2FwaSAhPT0gJ3VuZGVmaW5lZCcpIHtcclxuICAgICAgICAgICAgX2FwaS51cGRhdGVUaXRsZSA9IChfbmV3VGl0bGU6IHN0cmluZyA9ICcnKTogdm9pZCA9PiB7XHJcbiAgICAgICAgICAgICAgICBfY29uZmlnLnBhZ2VoZWFkZXJUZXh0ID0gX25ld1RpdGxlO1xyXG4gICAgICAgICAgICAgICAgdGhpcy5fdXBkYXRlQ2xpY2thYmxlQ3ljbGUoKTtcclxuICAgICAgICAgICAgfTtcclxuXHJcbiAgICAgICAgICAgIF9hcGkudXBkYXRlTGVmdEJ1dHRvbiA9IChfbmV3TGVmdEJ0bj86IEFycmF5PElUb29sYmFyQnV0dG9uPik6IHZvaWQgPT4ge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5fc2V0VHJhbnNpdGlvblRvKGZhbHNlKTtcclxuICAgICAgICAgICAgICAgIHRoaXMuY29uZmlnLmxlZnRCdG4gPSBfbmV3TGVmdEJ0bjtcclxuICAgICAgICAgICAgICAgIHRoaXMuX3Byb2Nlc3NDb25maWdDeWNsZSgpO1xyXG4gICAgICAgICAgICAgICAgdGhpcy5fdXBkYXRlQ2xpY2thYmxlQ3ljbGUoREVMQVlfVElNRSk7XHJcbiAgICAgICAgICAgIH07XHJcblxyXG4gICAgICAgICAgICBfYXBpLnVwZGF0ZU1vcmVCdXR0b24gPSAoX2VuYWJsZWQ6IGJvb2xlYW4sIF9saXN0OiBBcnJheTxJVG9vbGJhck1vcmVCdXR0b24+KTogdm9pZCA9PiB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLl9zZXRUcmFuc2l0aW9uVG8oZmFsc2UpO1xyXG4gICAgICAgICAgICAgICAgdGhpcy5jb25maWcubW9yZUJ0biA9IF9lbmFibGVkO1xyXG4gICAgICAgICAgICAgICAgdGhpcy5jb25maWcubW9yZUFjdGlvbiA9IF9saXN0O1xyXG4gICAgICAgICAgICAgICAgdGhpcy5fcHJvY2Vzc0NvbmZpZ0N5Y2xlKCk7XHJcbiAgICAgICAgICAgICAgICB0aGlzLl91cGRhdGVDbGlja2FibGVDeWNsZShERUxBWV9USU1FKTtcclxuICAgICAgICAgICAgfTtcclxuXHJcbiAgICAgICAgICAgIF9hcGkudXBkYXRlU2VhcmNoQnV0dG9uID0gKF9zZWFyY2hDb25maWc/OiBJVG9vbGJhclNlYXJjaENvbmZpZyk6IHZvaWQgPT4ge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5fc2V0VHJhbnNpdGlvblRvKGZhbHNlKTtcclxuICAgICAgICAgICAgICAgIHRoaXMuY29uZmlnID0gT2JqZWN0LmFzc2lnbjxJVG9vbGJhclNlYXJjaENvbmZpZywgSVRvb2xiYXJTZWFyY2hDb25maWc+KHRoaXMuY29uZmlnLCBfc2VhcmNoQ29uZmlnKTtcclxuICAgICAgICAgICAgICAgIHRoaXMuX3Byb2Nlc3NDb25maWdDeWNsZSgpO1xyXG4gICAgICAgICAgICAgICAgdGhpcy5fdXBkYXRlQ2xpY2thYmxlQ3ljbGUoREVMQVlfVElNRSk7XHJcbiAgICAgICAgICAgIH07XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICBjb25zb2xlLndhcm4oJ0tkUGFnZWhlYWRlciB3YXJuaW5nOiBObyBhcGkgaXMgcGFzc2VkIGluLicpO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICAvLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vXHJcbiAgICAvLy8gQ29uZmlnIGZ1bmN0aW9uc1xyXG4gICAgLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vL1xyXG4gICAgcHJpdmF0ZSBfdXBkYXRlVG9vbGJhckV4aXN0KCk6IHZvaWQge1xyXG4gICAgICAgIHRoaXMudG9vbGJhckV4aXN0ID0gdGhpcy5fcGFnZWhlYWRlclN2Yy5pc1Rvb2xiYXJFeGlzdCh0aGlzLmNvbmZpZyk7XHJcbiAgICB9XHJcbn1cclxuIl19