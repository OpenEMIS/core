import { Component, ViewEncapsulation, Input, Output, EventEmitter, ElementRef } from '@angular/core';
import { format, differenceInCalendarDays } from 'date-fns';
import { CalendarEventTitleFormatter, CalendarDateFormatter } from 'angular-calendar';
import { CustomEventTitleFormatter, CustomDateFormatter, CalendarHelper } from './config/kd-calendar-svc';
import { Subject } from 'rxjs';
export class KdCalendar {
    constructor(_calendarHelper, _elRef) {
        this._calendarHelper = _calendarHelper;
        this._elRef = _elRef;
        this.refresh = new Subject();
        this.viewDate = new Date();
        this.activeDayIsOpen = false;
        this._colorTray = {
            'blue': { primary: '#2a6db0', secondary: '#2F79C3' },
            'red': { primary: '#b84242', secondary: '#CB4945' },
            'yellow': { primary: '#d78f32', secondary: '#EF9F38' },
            'green': { primary: '#159e82', secondary: '#17b090' }
        };
        // public eventCalendar: Array<ICalendar>;
        this.calendarType = 'month';
        this.events = [];
        this.onEventClicked = new EventEmitter();
    }
    // init
    ngOnInit() {
        // this.eventCalendar = [];
        for (let i = 0; i < this.events.length; i++) {
            let event = this.events[i];
            let returnData = this._calendarHelper.addMissingRequiredPropertyForEvent(event, this._colorTray);
            if (returnData === false) {
                continue;
            }
        }
        this.initApi();
    }
    ngOnChanges(changes) {
        if (changes.hasOwnProperty('events')) {
            for (let i = 0; i < changes.events.currentValue.length; i++) {
                let event = changes.events.currentValue[i];
                let returnData = this._calendarHelper.addMissingRequiredPropertyForEvent(event, this._colorTray);
                if (returnData === false) {
                    continue;
                }
            }
            this.refresh.next();
        }
    }
    initApi() {
        this.api.getCalendarDate = () => { return format(this._calendarHelper.stringToDate(this.viewDate), 'YYYY-MM-DD'); };
        this.api.setCalendarType = (_type) => this.calendarType = _type;
        this.api.nextMonth = () => this._onViewChange('month', 'next');
        this.api.nextWeek = () => this._onViewChange('week', 'next');
        this.api.nextDay = () => this._onViewChange('day', 'next');
        this.api.previousMonth = () => this._onViewChange('month', 'previous');
        this.api.previousWeek = () => this._onViewChange('week', 'previous');
        this.api.previousDay = () => this._onViewChange('day', 'previous');
        this.api.goDate = (dateString) => { let goWhere = (dateString) ? dateString : 'today'; this._onViewChange(goWhere, 'go'); };
    }
    beforeMonthViewRender({ body }) {
        body.forEach(day => {
            if (this._calendarHelper.getUniqueDateToHighlight(day.date, this.events)) {
                day.cssClass = 'highlight-cell-grey';
            }
        });
    }
    generateViewMoreValue(events) {
        let eventsLength = events.length;
        if (events[0].id === 1) {
            eventsLength = 2000;
        }
        let value = this._calendarHelper.generateViewMoreValue(eventsLength);
        return value;
    }
    dayClicked({ date, events }) {
        let isSameDate = (this.viewDate === date || differenceInCalendarDays(this.viewDate, date) === 0);
        if ((isSameDate === true && this.activeDayIsOpen === true) || events.length === 0) {
            this.activeDayIsOpen = false;
        }
        else {
            this.activeDayIsOpen = true;
            this.viewDate = date;
            this._showCloseIcon();
        }
    }
    _showCloseIcon() {
        let thisController = this;
        let time = 1;
        setTimeout(function () {
            let eventOpenedDrawers = thisController._elRef.nativeElement.querySelectorAll('.cal-open-day-events');
            if (eventOpenedDrawers) {
                let addIcon = thisController._calendarHelper.getOpenedDrawer(eventOpenedDrawers, thisController._currentDrawer);
                thisController._currentDrawer = addIcon.element;
                let isIconAdded = addIcon.isIconAdded;
                if (!isIconAdded) {
                    let spanEl = thisController._calendarHelper.createCloseIconElement();
                    spanEl.onclick = function (event) {
                        thisController.closeEventDetailPanel(event);
                    };
                    thisController._currentDrawer.insertBefore(spanEl, thisController._currentDrawer.firstChild);
                }
            }
            else {
                time++;
                thisController._showCloseIcon();
            }
        }, time);
    }
    closeEventDetailPanel(event) {
        event.stopPropagation();
        this.activeDayIsOpen = false;
    }
    // api
    handleEvent(_event) {
        let eventClean = this._calendarHelper.cleanEventProperty(_event);
        this.onEventClicked.emit(eventClean);
        this._calendarHelper.addMissingRequiredPropertyForEvent(eventClean, this._colorTray);
        this.refresh.next();
    }
    _onViewChange(_calendarType, _action) {
        let newDate = this._calendarHelper.getViewDate(_calendarType, _action, this.viewDate);
        if (typeof newDate !== 'boolean') {
            this.activeDayIsOpen = false;
            this.viewDate = this._calendarHelper.stringToDate(newDate);
            this.api.getCalendarDate(format(this._calendarHelper.stringToDate(this.viewDate), 'YYYY-MM-DD'));
            this.refresh.next();
        }
        else {
            console.warn('Kd-Calendar ERROR: calendarType: ' + _calendarType + ' and action:' + _action + ' for onViewChange function only takes in calendar type: "year" or "month" or "week" or "day", action: "next" or "previous" or "today" as the argument');
        }
    }
}
KdCalendar.decorators = [
    { type: Component, args: [{
                selector: 'kd-calendar',
                template: "<ng-template #customCellTemplate let-day=\"day\" let-locale=\"locale\">\r\n    <div class=\"cal-cell-top\">\r\n        <span class=\"cal-day-number\">{{ day.date | calendarDate:'monthViewDayNumber':locale }}</span>\r\n        <span class=\"kdx-cal-view-more\" *ngIf=\"day.events.length > 4\">{{ generateViewMoreValue(day.events) }}</span>\r\n        <div class=\"kdx-cal-cell-event-top\">\r\n            <ng-container *ngFor=\"let event; of:day.events|slice:0:4; let i=index\">\r\n                <div *ngIf=\"i<4 && event.badge.position === 'top'\" class=\"cal-cell-event-type\">\r\n                    <small class=\"kdx-cal-day-event\" *ngIf=\"event.badge.position === 'top'\" [ngClass]=\"(event.badge.color === 'green') ? 'kdx btn-success' : (event.badge.color === 'red') ? 'kdx btn-error' : (event.badge.color === 'yellow') ? 'kdx btn-warning' : 'kdx btn-info'\">{{ event.badge.label }}</small>\r\n                </div>\r\n            </ng-container>\r\n        </div>\r\n    </div>\r\n    <div class=\"kdx-cal-cell-event-bottom\">\r\n        <ng-container *ngFor=\"let event; of:day.events|slice:0:4; let i=index\">\r\n            <div *ngIf=\"i<4 && event.badge.position === 'bottom'\" class=\"cal-cell-event-type\">\r\n                <small class=\"kdx-cal-day-event\" *ngIf=\"event.badge.position === 'bottom'\" [ngClass]=\"(event.badge.color === 'green') ? 'kdx btn-success' : (event.badge.color === 'red') ? 'kdx btn-error' : (event.badge.color === 'yellow') ? 'kdx btn-warning' : 'kdx btn-info'\">{{ event.badge.label }}</small>\r\n            </div>\r\n        </ng-container>\r\n    </div>\r\n</ng-template>\r\n<div class=\"kdx-calendar\">\r\n    <div [ngSwitch]=\"calendarType\">\r\n        <mwl-calendar-month-view *ngSwitchCase=\"'month'\" class=\"cal-month-view\" [viewDate]=\"viewDate\" [(events)]=\"events\" [refresh]=\"refresh\" [activeDayIsOpen]=\"activeDayIsOpen\" (dayClicked)=\"dayClicked($event.day)\" (eventClicked)=\"handleEvent($event.event)\" (beforeViewRender)=\"beforeMonthViewRender($event)\" [cellTemplate]=\"customCellTemplate\">\r\n        </mwl-calendar-month-view>\r\n        <mwl-calendar-week-view *ngSwitchCase=\"'week'\" class=\"cal-week-view\" [viewDate]=\"viewDate\" [(events)]=\"events\" [refresh]=\"refresh\" (eventClicked)=\"handleEvent($event.event)\">\r\n        </mwl-calendar-week-view>\r\n        <!-- <mwl-calendar-day-view *ngSwitchCase=\"'day'\" class=\"cal-day-view\" [viewDate]=\"viewDate\" [(events)]=\"events\" [refresh]=\"refresh\" (eventClicked)=\"handleEvent($event.event)\">\r\n        </mwl-calendar-day-view> -->\r\n    </div>\r\n</div>\r\n",
                encapsulation: ViewEncapsulation.None,
                providers: [
                    {
                        provide: CalendarEventTitleFormatter,
                        useClass: CustomEventTitleFormatter
                    },
                    {
                        provide: CalendarDateFormatter,
                        useClass: CustomDateFormatter
                    },
                    CalendarHelper
                ]
            },] }
];
KdCalendar.ctorParameters = () => [
    { type: CalendarHelper },
    { type: ElementRef }
];
KdCalendar.propDecorators = {
    calendarType: [{ type: Input }],
    events: [{ type: Input }],
    api: [{ type: Input }],
    onEventClicked: [{ type: Output }]
};
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoia2QtY2FsZW5kYXIuanMiLCJzb3VyY2VSb290IjoiQzoveGFtcHAvaHRkb2NzL1N0eWxlZ3VpZGUvaW9zdGctb3BlbmVtaXMtc3R5bGVndWlkZS9wcm9qZWN0cy9vcGVuZW1pcy1zdHlsZWd1aWRlLWxpYi9zcmMvIiwic291cmNlcyI6WyJrZC1jb21wb25lbnRzL2tkLWFuZ3VsYXItY2FsZW5kYXIva2QtY2FsZW5kYXIudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsT0FBTyxFQUNILFNBQVMsRUFDVCxpQkFBaUIsRUFJakIsS0FBSyxFQUNMLE1BQU0sRUFDTixZQUFZLEVBQ1osVUFBVSxFQUNiLE1BQU0sZUFBZSxDQUFDO0FBQ3ZCLE9BQU8sRUFDSCxNQUFNLEVBQ04sd0JBQXdCLEVBQzNCLE1BQU0sVUFBVSxDQUFDO0FBQ2xCLE9BQU8sRUFFSCwyQkFBMkIsRUFFM0IscUJBQXFCLEVBQ3hCLE1BQU0sa0JBQWtCLENBQUM7QUFDMUIsT0FBTyxFQUFFLHlCQUF5QixFQUFFLG1CQUFtQixFQUFFLGNBQWMsRUFBRSxNQUFNLDBCQUEwQixDQUFDO0FBQzFHLE9BQU8sRUFBRSxPQUFPLEVBQUUsTUFBTSxNQUFNLENBQUM7QUFxQi9CLE1BQU0sT0FBTyxVQUFVO0lBMEJuQixZQUNZLGVBQStCLEVBQy9CLE1BQWtCO1FBRGxCLG9CQUFlLEdBQWYsZUFBZSxDQUFnQjtRQUMvQixXQUFNLEdBQU4sTUFBTSxDQUFZO1FBMUJ2QixZQUFPLEdBQWlCLElBQUksT0FBTyxFQUFFLENBQUM7UUFFdEMsYUFBUSxHQUFTLElBQUksSUFBSSxFQUFFLENBQUM7UUFFNUIsb0JBQWUsR0FBWSxLQUFLLENBQUM7UUFFaEMsZUFBVSxHQUFXO1lBQ3pCLE1BQU0sRUFBRyxFQUFDLE9BQU8sRUFBRSxTQUFTLEVBQUUsU0FBUyxFQUFFLFNBQVMsRUFBQztZQUNuRCxLQUFLLEVBQUcsRUFBQyxPQUFPLEVBQUUsU0FBUyxFQUFFLFNBQVMsRUFBRSxTQUFTLEVBQUM7WUFDbEQsUUFBUSxFQUFHLEVBQUMsT0FBTyxFQUFFLFNBQVMsRUFBRSxTQUFTLEVBQUUsU0FBUyxFQUFDO1lBQ3JELE9BQU8sRUFBRyxFQUFDLE9BQU8sRUFBRSxTQUFTLEVBQUUsU0FBUyxFQUFFLFNBQVMsRUFBQztTQUN2RCxDQUFDO1FBR0YsMENBQTBDO1FBRWpDLGlCQUFZLEdBQVcsT0FBTyxDQUFDO1FBRS9CLFdBQU0sR0FBcUIsRUFBRSxDQUFDO1FBSTdCLG1CQUFjLEdBQTRCLElBQUksWUFBWSxFQUFhLENBQUM7SUFLOUUsQ0FBQztJQUVMLE9BQU87SUFFUCxRQUFRO1FBRUosMkJBQTJCO1FBRTNCLEtBQU0sSUFBSSxDQUFDLEdBQVcsQ0FBQyxFQUFFLENBQUMsR0FBRyxJQUFJLENBQUMsTUFBTSxDQUFDLE1BQU0sRUFBRSxDQUFDLEVBQUUsRUFBRztZQUNuRCxJQUFJLEtBQUssR0FBYyxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDO1lBQ3RDLElBQUksVUFBVSxHQUFZLElBQUksQ0FBQyxlQUFlLENBQUMsa0NBQWtDLENBQUMsS0FBSyxFQUFFLElBQUksQ0FBQyxVQUFVLENBQUMsQ0FBQztZQUMxRyxJQUFLLFVBQVUsS0FBSyxLQUFLLEVBQUc7Z0JBQ3hCLFNBQVM7YUFDWjtTQUNKO1FBRUQsSUFBSSxDQUFDLE9BQU8sRUFBRSxDQUFDO0lBQ25CLENBQUM7SUFFRCxXQUFXLENBQUMsT0FBc0I7UUFDOUIsSUFBSyxPQUFPLENBQUMsY0FBYyxDQUFDLFFBQVEsQ0FBQyxFQUFHO1lBRXBDLEtBQU0sSUFBSSxDQUFDLEdBQVcsQ0FBQyxFQUFFLENBQUMsR0FBRyxPQUFPLENBQUMsTUFBTSxDQUFDLFlBQVksQ0FBQyxNQUFNLEVBQUUsQ0FBQyxFQUFFLEVBQUc7Z0JBQ25FLElBQUksS0FBSyxHQUFjLE9BQU8sQ0FBQyxNQUFNLENBQUMsWUFBWSxDQUFDLENBQUMsQ0FBQyxDQUFDO2dCQUN0RCxJQUFJLFVBQVUsR0FBWSxJQUFJLENBQUMsZUFBZSxDQUFDLGtDQUFrQyxDQUFDLEtBQUssRUFBRSxJQUFJLENBQUMsVUFBVSxDQUFDLENBQUM7Z0JBQzFHLElBQUssVUFBVSxLQUFLLEtBQUssRUFBRztvQkFDeEIsU0FBUztpQkFDWjthQUNKO1lBRUQsSUFBSSxDQUFDLE9BQU8sQ0FBQyxJQUFJLEVBQUUsQ0FBQztTQUN2QjtJQUNMLENBQUM7SUFFRCxPQUFPO1FBQ0gsSUFBSSxDQUFDLEdBQUcsQ0FBQyxlQUFlLEdBQUcsR0FBVyxFQUFFLEdBQUcsT0FBTyxNQUFNLENBQUMsSUFBSSxDQUFDLGVBQWUsQ0FBQyxZQUFZLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxFQUFFLFlBQVksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO1FBQzVILElBQUksQ0FBQyxHQUFHLENBQUMsZUFBZSxHQUFHLENBQUMsS0FBYSxFQUFFLEVBQUUsQ0FBQyxJQUFJLENBQUMsWUFBWSxHQUFHLEtBQUssQ0FBQztRQUN4RSxJQUFJLENBQUMsR0FBRyxDQUFDLFNBQVMsR0FBRyxHQUFHLEVBQUUsQ0FBQyxJQUFJLENBQUMsYUFBYSxDQUFDLE9BQU8sRUFBRSxNQUFNLENBQUMsQ0FBQztRQUMvRCxJQUFJLENBQUMsR0FBRyxDQUFDLFFBQVEsR0FBRyxHQUFHLEVBQUUsQ0FBQyxJQUFJLENBQUMsYUFBYSxDQUFDLE1BQU0sRUFBRSxNQUFNLENBQUMsQ0FBQztRQUM3RCxJQUFJLENBQUMsR0FBRyxDQUFDLE9BQU8sR0FBRyxHQUFHLEVBQUUsQ0FBQyxJQUFJLENBQUMsYUFBYSxDQUFDLEtBQUssRUFBRSxNQUFNLENBQUMsQ0FBQztRQUMzRCxJQUFJLENBQUMsR0FBRyxDQUFDLGFBQWEsR0FBRyxHQUFHLEVBQUUsQ0FBQyxJQUFJLENBQUMsYUFBYSxDQUFDLE9BQU8sRUFBRSxVQUFVLENBQUMsQ0FBQztRQUN2RSxJQUFJLENBQUMsR0FBRyxDQUFDLFlBQVksR0FBRyxHQUFHLEVBQUUsQ0FBQyxJQUFJLENBQUMsYUFBYSxDQUFDLE1BQU0sRUFBRSxVQUFVLENBQUMsQ0FBQztRQUNyRSxJQUFJLENBQUMsR0FBRyxDQUFDLFdBQVcsR0FBRyxHQUFHLEVBQUUsQ0FBQyxJQUFJLENBQUMsYUFBYSxDQUFDLEtBQUssRUFBRSxVQUFVLENBQUMsQ0FBQztRQUNuRSxJQUFJLENBQUMsR0FBRyxDQUFDLE1BQU0sR0FBRyxDQUFDLFVBQW1CLEVBQUUsRUFBRSxHQUFHLElBQUksT0FBTyxHQUFXLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQyxDQUFDLFVBQVUsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsSUFBSSxDQUFDLGFBQWEsQ0FBQyxPQUFPLEVBQUUsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7SUFDakosQ0FBQztJQUVELHFCQUFxQixDQUFDLEVBQUUsSUFBSSxFQUFvQztRQUM1RCxJQUFJLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxFQUFFO1lBQ2YsSUFBSyxJQUFJLENBQUMsZUFBZSxDQUFDLHdCQUF3QixDQUFDLEdBQUcsQ0FBQyxJQUFJLEVBQUUsSUFBSSxDQUFDLE1BQU0sQ0FBQyxFQUFHO2dCQUN4RSxHQUFHLENBQUMsUUFBUSxHQUFHLHFCQUFxQixDQUFDO2FBQ3hDO1FBQ0wsQ0FBQyxDQUFDLENBQUM7SUFDUCxDQUFDO0lBRUQscUJBQXFCLENBQUMsTUFBbUI7UUFDckMsSUFBSSxZQUFZLEdBQVcsTUFBTSxDQUFDLE1BQU0sQ0FBQztRQUN6QyxJQUFLLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLEtBQUssQ0FBQyxFQUFHO1lBQ3RCLFlBQVksR0FBRyxJQUFJLENBQUM7U0FDdkI7UUFDRCxJQUFJLEtBQUssR0FBVyxJQUFJLENBQUMsZUFBZSxDQUFDLHFCQUFxQixDQUFDLFlBQVksQ0FBQyxDQUFDO1FBQzdFLE9BQU8sS0FBSyxDQUFDO0lBQ2pCLENBQUM7SUFFRCxVQUFVLENBQUMsRUFBRSxJQUFJLEVBQUUsTUFBTSxFQUEwQztRQUUvRCxJQUFJLFVBQVUsR0FBWSxDQUFDLElBQUksQ0FBQyxRQUFRLEtBQUssSUFBSSxJQUFJLHdCQUF3QixDQUFDLElBQUksQ0FBQyxRQUFRLEVBQUUsSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUM7UUFDMUcsSUFBSSxDQUFFLFVBQVUsS0FBSyxJQUFJLElBQUksSUFBSSxDQUFDLGVBQWUsS0FBSyxJQUFJLENBQUMsSUFBSSxNQUFNLENBQUMsTUFBTSxLQUFLLENBQUMsRUFBRztZQUNqRixJQUFJLENBQUMsZUFBZSxHQUFHLEtBQUssQ0FBQztTQUNoQzthQUFNO1lBQ0gsSUFBSSxDQUFDLGVBQWUsR0FBRyxJQUFJLENBQUM7WUFDNUIsSUFBSSxDQUFDLFFBQVEsR0FBRyxJQUFJLENBQUM7WUFDckIsSUFBSSxDQUFDLGNBQWMsRUFBRSxDQUFDO1NBQ3pCO0lBQ0wsQ0FBQztJQUVPLGNBQWM7UUFFbEIsSUFBSSxjQUFjLEdBQVMsSUFBSSxDQUFDO1FBQ2hDLElBQUksSUFBSSxHQUFXLENBQUMsQ0FBQztRQUVyQixVQUFVLENBQUM7WUFFUCxJQUFJLGtCQUFrQixHQUFtQixjQUFjLENBQUMsTUFBTSxDQUFDLGFBQWEsQ0FBQyxnQkFBZ0IsQ0FBQyxzQkFBc0IsQ0FBQyxDQUFDO1lBRXRILElBQUssa0JBQWtCLEVBQUc7Z0JBRXRCLElBQUksT0FBTyxHQUF3QixjQUFjLENBQUMsZUFBZSxDQUFDLGVBQWUsQ0FBQyxrQkFBa0IsRUFBRSxjQUFjLENBQUMsY0FBYyxDQUFDLENBQUM7Z0JBRXJJLGNBQWMsQ0FBQyxjQUFjLEdBQUcsT0FBTyxDQUFDLE9BQU8sQ0FBQztnQkFDaEQsSUFBSSxXQUFXLEdBQUcsT0FBTyxDQUFDLFdBQVcsQ0FBQztnQkFFdEMsSUFBSyxDQUFDLFdBQVcsRUFBRztvQkFDaEIsSUFBSSxNQUFNLEdBQW9CLGNBQWMsQ0FBQyxlQUFlLENBQUMsc0JBQXNCLEVBQUUsQ0FBQztvQkFDdEYsTUFBTSxDQUFDLE9BQU8sR0FBRyxVQUFTLEtBQUs7d0JBQzNCLGNBQWMsQ0FBQyxxQkFBcUIsQ0FBQyxLQUFLLENBQUMsQ0FBQztvQkFDaEQsQ0FBQyxDQUFDO29CQUVGLGNBQWMsQ0FBQyxjQUFjLENBQUMsWUFBWSxDQUFDLE1BQU0sRUFBRSxjQUFjLENBQUMsY0FBYyxDQUFDLFVBQVUsQ0FBQyxDQUFDO2lCQUNoRzthQUNKO2lCQUFNO2dCQUNILElBQUksRUFBRSxDQUFDO2dCQUNQLGNBQWMsQ0FBQyxjQUFjLEVBQUUsQ0FBQzthQUNuQztRQUNMLENBQUMsRUFBRSxJQUFJLENBQUMsQ0FBQztJQUNiLENBQUM7SUFFRCxxQkFBcUIsQ0FBQyxLQUFLO1FBQ3ZCLEtBQUssQ0FBQyxlQUFlLEVBQUUsQ0FBQztRQUN4QixJQUFJLENBQUMsZUFBZSxHQUFHLEtBQUssQ0FBQztJQUNqQyxDQUFDO0lBRUQsTUFBTTtJQUVOLFdBQVcsQ0FBQyxNQUFpQjtRQUV6QixJQUFJLFVBQVUsR0FBYyxJQUFJLENBQUMsZUFBZSxDQUFDLGtCQUFrQixDQUFDLE1BQU0sQ0FBQyxDQUFDO1FBRTVFLElBQUksQ0FBQyxjQUFjLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxDQUFDO1FBQ3JDLElBQUksQ0FBQyxlQUFlLENBQUMsa0NBQWtDLENBQUMsVUFBVSxFQUFFLElBQUksQ0FBQyxVQUFVLENBQUMsQ0FBQztRQUVyRixJQUFJLENBQUMsT0FBTyxDQUFDLElBQUksRUFBRSxDQUFDO0lBQ3hCLENBQUM7SUFFTyxhQUFhLENBQUMsYUFBcUIsRUFBRSxPQUFlO1FBRXhELElBQUksT0FBTyxHQUFpQixJQUFJLENBQUMsZUFBZSxDQUFDLFdBQVcsQ0FBQyxhQUFhLEVBQUUsT0FBTyxFQUFFLElBQUksQ0FBQyxRQUFRLENBQUMsQ0FBQztRQUVwRyxJQUFLLE9BQU8sT0FBTyxLQUFLLFNBQVMsRUFBRztZQUNoQyxJQUFJLENBQUMsZUFBZSxHQUFHLEtBQUssQ0FBQztZQUM3QixJQUFJLENBQUMsUUFBUSxHQUFHLElBQUksQ0FBQyxlQUFlLENBQUMsWUFBWSxDQUFDLE9BQU8sQ0FBQyxDQUFDO1lBQzNELElBQUksQ0FBQyxHQUFHLENBQUMsZUFBZSxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsZUFBZSxDQUFDLFlBQVksQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLEVBQUUsWUFBWSxDQUFDLENBQUMsQ0FBQztZQUNqRyxJQUFJLENBQUMsT0FBTyxDQUFDLElBQUksRUFBRSxDQUFDO1NBQ3ZCO2FBQU07WUFDSCxPQUFPLENBQUMsSUFBSSxDQUFDLG1DQUFtQyxHQUFHLGFBQWEsR0FBRyxjQUFjLEdBQUcsT0FBTyxHQUFHLHVKQUF1SixDQUFDLENBQUM7U0FDMVA7SUFDTCxDQUFDOzs7WUF0TEosU0FBUyxTQUFDO2dCQUNQLFFBQVEsRUFBRSxhQUFhO2dCQUN2QiwyakZBQWlDO2dCQUNqQyxhQUFhLEVBQUUsaUJBQWlCLENBQUMsSUFBSTtnQkFDckMsU0FBUyxFQUFFO29CQUNQO3dCQUNFLE9BQU8sRUFBRSwyQkFBMkI7d0JBQ3BDLFFBQVEsRUFBRSx5QkFBeUI7cUJBQ3BDO29CQUVEO3dCQUNFLE9BQU8sRUFBRSxxQkFBcUI7d0JBQzlCLFFBQVEsRUFBRSxtQkFBbUI7cUJBQzlCO29CQUNELGNBQWM7aUJBQ2pCO2FBQ0o7OztZQXBCd0QsY0FBYztZQVpuRSxVQUFVOzs7MkJBb0RULEtBQUs7cUJBRUwsS0FBSztrQkFFTCxLQUFLOzZCQUVMLE1BQU0iLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQge1xyXG4gICAgQ29tcG9uZW50LFxyXG4gICAgVmlld0VuY2Fwc3VsYXRpb24sXHJcbiAgICBPbkluaXQsXHJcbiAgICBPbkNoYW5nZXMsXHJcbiAgICBTaW1wbGVDaGFuZ2VzLFxyXG4gICAgSW5wdXQsXHJcbiAgICBPdXRwdXQsXHJcbiAgICBFdmVudEVtaXR0ZXIsXHJcbiAgICBFbGVtZW50UmVmXHJcbn0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XHJcbmltcG9ydCB7XHJcbiAgICBmb3JtYXQsXHJcbiAgICBkaWZmZXJlbmNlSW5DYWxlbmRhckRheXNcclxufSBmcm9tICdkYXRlLWZucyc7XHJcbmltcG9ydCB7XHJcbiAgICBDYWxlbmRhckV2ZW50LFxyXG4gICAgQ2FsZW5kYXJFdmVudFRpdGxlRm9ybWF0dGVyLFxyXG4gICAgQ2FsZW5kYXJNb250aFZpZXdEYXksXHJcbiAgICBDYWxlbmRhckRhdGVGb3JtYXR0ZXJcclxufSBmcm9tICdhbmd1bGFyLWNhbGVuZGFyJztcclxuaW1wb3J0IHsgQ3VzdG9tRXZlbnRUaXRsZUZvcm1hdHRlciwgQ3VzdG9tRGF0ZUZvcm1hdHRlciwgQ2FsZW5kYXJIZWxwZXIgfSBmcm9tICcuL2NvbmZpZy9rZC1jYWxlbmRhci1zdmMnO1xyXG5pbXBvcnQgeyBTdWJqZWN0IH0gZnJvbSAncnhqcyc7XHJcbmltcG9ydCB7IElDYWxlbmRhciwgSUNhbGVuZGFyQXBpLCBJQ2FsZW5kYXJPcGVuRHJhd2VyIH0gZnJvbSAnLi9rZC1hbmd1bGFyLWNhbGVuZGFyLWludGVyZmFjZSc7XHJcblxyXG5AQ29tcG9uZW50KHtcclxuICAgIHNlbGVjdG9yOiAna2QtY2FsZW5kYXInLFxyXG4gICAgdGVtcGxhdGVVcmw6ICcuL2tkLWNhbGVuZGFyLmh0bWwnLFxyXG4gICAgZW5jYXBzdWxhdGlvbjogVmlld0VuY2Fwc3VsYXRpb24uTm9uZSxcclxuICAgIHByb3ZpZGVyczogW1xyXG4gICAgICAgIHtcclxuICAgICAgICAgIHByb3ZpZGU6IENhbGVuZGFyRXZlbnRUaXRsZUZvcm1hdHRlcixcclxuICAgICAgICAgIHVzZUNsYXNzOiBDdXN0b21FdmVudFRpdGxlRm9ybWF0dGVyXHJcbiAgICAgICAgfSxcclxuXHJcbiAgICAgICAge1xyXG4gICAgICAgICAgcHJvdmlkZTogQ2FsZW5kYXJEYXRlRm9ybWF0dGVyLFxyXG4gICAgICAgICAgdXNlQ2xhc3M6IEN1c3RvbURhdGVGb3JtYXR0ZXJcclxuICAgICAgICB9LFxyXG4gICAgICAgIENhbGVuZGFySGVscGVyXHJcbiAgICBdXHJcbn0pXHJcblxyXG5leHBvcnQgY2xhc3MgS2RDYWxlbmRhciBpbXBsZW1lbnRzIE9uSW5pdCwgT25DaGFuZ2VzIHtcclxuXHJcbiAgICBwdWJsaWMgcmVmcmVzaDogU3ViamVjdDxhbnk+ID0gbmV3IFN1YmplY3QoKTtcclxuXHJcbiAgICBwdWJsaWMgdmlld0RhdGU6IERhdGUgPSBuZXcgRGF0ZSgpO1xyXG5cclxuICAgIHB1YmxpYyBhY3RpdmVEYXlJc09wZW46IGJvb2xlYW4gPSBmYWxzZTtcclxuXHJcbiAgICBwcml2YXRlIF9jb2xvclRyYXk6IG9iamVjdCA9IHtcclxuICAgICAgICAnYmx1ZScgOiB7cHJpbWFyeTogJyMyYTZkYjAnLCBzZWNvbmRhcnk6ICcjMkY3OUMzJ30sXHJcbiAgICAgICAgJ3JlZCcgOiB7cHJpbWFyeTogJyNiODQyNDInLCBzZWNvbmRhcnk6ICcjQ0I0OTQ1J30sXHJcbiAgICAgICAgJ3llbGxvdycgOiB7cHJpbWFyeTogJyNkNzhmMzInLCBzZWNvbmRhcnk6ICcjRUY5RjM4J30sXHJcbiAgICAgICAgJ2dyZWVuJyA6IHtwcmltYXJ5OiAnIzE1OWU4MicsIHNlY29uZGFyeTogJyMxN2IwOTAnfVxyXG4gICAgfTtcclxuICAgIHByaXZhdGUgX2N1cnJlbnREcmF3ZXI6IEVsZW1lbnQ7XHJcblxyXG4gICAgLy8gcHVibGljIGV2ZW50Q2FsZW5kYXI6IEFycmF5PElDYWxlbmRhcj47XHJcblxyXG4gICAgQElucHV0KCkgY2FsZW5kYXJUeXBlOiBzdHJpbmcgPSAnbW9udGgnO1xyXG5cclxuICAgIEBJbnB1dCgpIGV2ZW50czogQXJyYXk8SUNhbGVuZGFyPiA9IFtdO1xyXG5cclxuICAgIEBJbnB1dCgpIGFwaTogSUNhbGVuZGFyQXBpO1xyXG5cclxuICAgIEBPdXRwdXQoKSBvbkV2ZW50Q2xpY2tlZDogRXZlbnRFbWl0dGVyPElDYWxlbmRhcj4gPSBuZXcgRXZlbnRFbWl0dGVyPElDYWxlbmRhcj4oKTtcclxuXHJcbiAgICBjb25zdHJ1Y3RvcihcclxuICAgICAgICBwcml2YXRlIF9jYWxlbmRhckhlbHBlcjogQ2FsZW5kYXJIZWxwZXIsXHJcbiAgICAgICAgcHJpdmF0ZSBfZWxSZWY6IEVsZW1lbnRSZWZcclxuICAgICkgeyB9XHJcblxyXG4gICAgLy8gaW5pdFxyXG5cclxuICAgIG5nT25Jbml0KCk6IHZvaWQge1xyXG5cclxuICAgICAgICAvLyB0aGlzLmV2ZW50Q2FsZW5kYXIgPSBbXTtcclxuXHJcbiAgICAgICAgZm9yICggbGV0IGk6IG51bWJlciA9IDA7IGkgPCB0aGlzLmV2ZW50cy5sZW5ndGg7IGkrKyApIHtcclxuICAgICAgICAgICAgbGV0IGV2ZW50OiBJQ2FsZW5kYXIgPSB0aGlzLmV2ZW50c1tpXTtcclxuICAgICAgICAgICAgbGV0IHJldHVybkRhdGE6IGJvb2xlYW4gPSB0aGlzLl9jYWxlbmRhckhlbHBlci5hZGRNaXNzaW5nUmVxdWlyZWRQcm9wZXJ0eUZvckV2ZW50KGV2ZW50LCB0aGlzLl9jb2xvclRyYXkpO1xyXG4gICAgICAgICAgICBpZiAoIHJldHVybkRhdGEgPT09IGZhbHNlICkge1xyXG4gICAgICAgICAgICAgICAgY29udGludWU7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIHRoaXMuaW5pdEFwaSgpO1xyXG4gICAgfVxyXG5cclxuICAgIG5nT25DaGFuZ2VzKGNoYW5nZXM6IFNpbXBsZUNoYW5nZXMpOiB2b2lkIHtcclxuICAgICAgICBpZiAoIGNoYW5nZXMuaGFzT3duUHJvcGVydHkoJ2V2ZW50cycpICkge1xyXG5cclxuICAgICAgICAgICAgZm9yICggbGV0IGk6IG51bWJlciA9IDA7IGkgPCBjaGFuZ2VzLmV2ZW50cy5jdXJyZW50VmFsdWUubGVuZ3RoOyBpKysgKSB7XHJcbiAgICAgICAgICAgICAgICBsZXQgZXZlbnQ6IElDYWxlbmRhciA9IGNoYW5nZXMuZXZlbnRzLmN1cnJlbnRWYWx1ZVtpXTtcclxuICAgICAgICAgICAgICAgIGxldCByZXR1cm5EYXRhOiBib29sZWFuID0gdGhpcy5fY2FsZW5kYXJIZWxwZXIuYWRkTWlzc2luZ1JlcXVpcmVkUHJvcGVydHlGb3JFdmVudChldmVudCwgdGhpcy5fY29sb3JUcmF5KTtcclxuICAgICAgICAgICAgICAgIGlmICggcmV0dXJuRGF0YSA9PT0gZmFsc2UgKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgY29udGludWU7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgIHRoaXMucmVmcmVzaC5uZXh0KCk7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIGluaXRBcGkoKTogdm9pZCB7XHJcbiAgICAgICAgdGhpcy5hcGkuZ2V0Q2FsZW5kYXJEYXRlID0gKCk6IHN0cmluZyA9PiB7IHJldHVybiBmb3JtYXQodGhpcy5fY2FsZW5kYXJIZWxwZXIuc3RyaW5nVG9EYXRlKHRoaXMudmlld0RhdGUpLCAnWVlZWS1NTS1ERCcpOyB9O1xyXG4gICAgICAgIHRoaXMuYXBpLnNldENhbGVuZGFyVHlwZSA9IChfdHlwZTogc3RyaW5nKSA9PiB0aGlzLmNhbGVuZGFyVHlwZSA9IF90eXBlO1xyXG4gICAgICAgIHRoaXMuYXBpLm5leHRNb250aCA9ICgpID0+IHRoaXMuX29uVmlld0NoYW5nZSgnbW9udGgnLCAnbmV4dCcpO1xyXG4gICAgICAgIHRoaXMuYXBpLm5leHRXZWVrID0gKCkgPT4gdGhpcy5fb25WaWV3Q2hhbmdlKCd3ZWVrJywgJ25leHQnKTtcclxuICAgICAgICB0aGlzLmFwaS5uZXh0RGF5ID0gKCkgPT4gdGhpcy5fb25WaWV3Q2hhbmdlKCdkYXknLCAnbmV4dCcpO1xyXG4gICAgICAgIHRoaXMuYXBpLnByZXZpb3VzTW9udGggPSAoKSA9PiB0aGlzLl9vblZpZXdDaGFuZ2UoJ21vbnRoJywgJ3ByZXZpb3VzJyk7XHJcbiAgICAgICAgdGhpcy5hcGkucHJldmlvdXNXZWVrID0gKCkgPT4gdGhpcy5fb25WaWV3Q2hhbmdlKCd3ZWVrJywgJ3ByZXZpb3VzJyk7XHJcbiAgICAgICAgdGhpcy5hcGkucHJldmlvdXNEYXkgPSAoKSA9PiB0aGlzLl9vblZpZXdDaGFuZ2UoJ2RheScsICdwcmV2aW91cycpO1xyXG4gICAgICAgIHRoaXMuYXBpLmdvRGF0ZSA9IChkYXRlU3RyaW5nPzogc3RyaW5nKSA9PiB7IGxldCBnb1doZXJlOiBzdHJpbmcgPSAoZGF0ZVN0cmluZykgPyBkYXRlU3RyaW5nIDogJ3RvZGF5JzsgdGhpcy5fb25WaWV3Q2hhbmdlKGdvV2hlcmUsICdnbycpOyB9O1xyXG4gICAgfVxyXG5cclxuICAgIGJlZm9yZU1vbnRoVmlld1JlbmRlcih7IGJvZHkgfTogeyBib2R5OiBDYWxlbmRhck1vbnRoVmlld0RheVtdIH0pOiB2b2lkIHtcclxuICAgICAgICBib2R5LmZvckVhY2goZGF5ID0+IHtcclxuICAgICAgICAgICAgaWYgKCB0aGlzLl9jYWxlbmRhckhlbHBlci5nZXRVbmlxdWVEYXRlVG9IaWdobGlnaHQoZGF5LmRhdGUsIHRoaXMuZXZlbnRzKSApIHtcclxuICAgICAgICAgICAgICAgIGRheS5jc3NDbGFzcyA9ICdoaWdobGlnaHQtY2VsbC1ncmV5JztcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH0pO1xyXG4gICAgfVxyXG5cclxuICAgIGdlbmVyYXRlVmlld01vcmVWYWx1ZShldmVudHM6IElDYWxlbmRhcltdKTogc3RyaW5nIHtcclxuICAgICAgICBsZXQgZXZlbnRzTGVuZ3RoOiBudW1iZXIgPSBldmVudHMubGVuZ3RoO1xyXG4gICAgICAgIGlmICggZXZlbnRzWzBdLmlkID09PSAxICkge1xyXG4gICAgICAgICAgICBldmVudHNMZW5ndGggPSAyMDAwO1xyXG4gICAgICAgIH1cclxuICAgICAgICBsZXQgdmFsdWU6IHN0cmluZyA9IHRoaXMuX2NhbGVuZGFySGVscGVyLmdlbmVyYXRlVmlld01vcmVWYWx1ZShldmVudHNMZW5ndGgpO1xyXG4gICAgICAgIHJldHVybiB2YWx1ZTtcclxuICAgIH1cclxuXHJcbiAgICBkYXlDbGlja2VkKHsgZGF0ZSwgZXZlbnRzfTogeyBkYXRlOiBEYXRlOyBldmVudHM6IENhbGVuZGFyRXZlbnRbXSB9KTogdm9pZCB7XHJcblxyXG4gICAgICAgIGxldCBpc1NhbWVEYXRlOiBib29sZWFuID0gKHRoaXMudmlld0RhdGUgPT09IGRhdGUgfHwgZGlmZmVyZW5jZUluQ2FsZW5kYXJEYXlzKHRoaXMudmlld0RhdGUsIGRhdGUpID09PSAwKTtcclxuICAgICAgICBpZiAoKCBpc1NhbWVEYXRlID09PSB0cnVlICYmIHRoaXMuYWN0aXZlRGF5SXNPcGVuID09PSB0cnVlKSB8fCBldmVudHMubGVuZ3RoID09PSAwICkge1xyXG4gICAgICAgICAgICB0aGlzLmFjdGl2ZURheUlzT3BlbiA9IGZhbHNlO1xyXG4gICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgIHRoaXMuYWN0aXZlRGF5SXNPcGVuID0gdHJ1ZTtcclxuICAgICAgICAgICAgdGhpcy52aWV3RGF0ZSA9IGRhdGU7XHJcbiAgICAgICAgICAgIHRoaXMuX3Nob3dDbG9zZUljb24oKTtcclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfc2hvd0Nsb3NlSWNvbigpOiB2b2lkIHtcclxuXHJcbiAgICAgICAgbGV0IHRoaXNDb250cm9sbGVyOiB0aGlzID0gdGhpcztcclxuICAgICAgICBsZXQgdGltZTogbnVtYmVyID0gMTtcclxuXHJcbiAgICAgICAgc2V0VGltZW91dChmdW5jdGlvbigpIHtcclxuXHJcbiAgICAgICAgICAgIGxldCBldmVudE9wZW5lZERyYXdlcnM6IEFycmF5PEVsZW1lbnQ+ID0gdGhpc0NvbnRyb2xsZXIuX2VsUmVmLm5hdGl2ZUVsZW1lbnQucXVlcnlTZWxlY3RvckFsbCgnLmNhbC1vcGVuLWRheS1ldmVudHMnKTtcclxuXHJcbiAgICAgICAgICAgIGlmICggZXZlbnRPcGVuZWREcmF3ZXJzICkge1xyXG5cclxuICAgICAgICAgICAgICAgIGxldCBhZGRJY29uOiBJQ2FsZW5kYXJPcGVuRHJhd2VyID0gdGhpc0NvbnRyb2xsZXIuX2NhbGVuZGFySGVscGVyLmdldE9wZW5lZERyYXdlcihldmVudE9wZW5lZERyYXdlcnMsIHRoaXNDb250cm9sbGVyLl9jdXJyZW50RHJhd2VyKTtcclxuXHJcbiAgICAgICAgICAgICAgICB0aGlzQ29udHJvbGxlci5fY3VycmVudERyYXdlciA9IGFkZEljb24uZWxlbWVudDtcclxuICAgICAgICAgICAgICAgIGxldCBpc0ljb25BZGRlZCA9IGFkZEljb24uaXNJY29uQWRkZWQ7XHJcblxyXG4gICAgICAgICAgICAgICAgaWYgKCAhaXNJY29uQWRkZWQgKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgbGV0IHNwYW5FbDogSFRNTFNwYW5FbGVtZW50ID0gdGhpc0NvbnRyb2xsZXIuX2NhbGVuZGFySGVscGVyLmNyZWF0ZUNsb3NlSWNvbkVsZW1lbnQoKTtcclxuICAgICAgICAgICAgICAgICAgICBzcGFuRWwub25jbGljayA9IGZ1bmN0aW9uKGV2ZW50KSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXNDb250cm9sbGVyLmNsb3NlRXZlbnREZXRhaWxQYW5lbChldmVudCk7XHJcbiAgICAgICAgICAgICAgICAgICAgfTtcclxuXHJcbiAgICAgICAgICAgICAgICAgICAgdGhpc0NvbnRyb2xsZXIuX2N1cnJlbnREcmF3ZXIuaW5zZXJ0QmVmb3JlKHNwYW5FbCwgdGhpc0NvbnRyb2xsZXIuX2N1cnJlbnREcmF3ZXIuZmlyc3RDaGlsZCk7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgICAgICB0aW1lKys7XHJcbiAgICAgICAgICAgICAgICB0aGlzQ29udHJvbGxlci5fc2hvd0Nsb3NlSWNvbigpO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfSwgdGltZSk7XHJcbiAgICB9XHJcblxyXG4gICAgY2xvc2VFdmVudERldGFpbFBhbmVsKGV2ZW50KTogdm9pZCB7XHJcbiAgICAgICAgZXZlbnQuc3RvcFByb3BhZ2F0aW9uKCk7XHJcbiAgICAgICAgdGhpcy5hY3RpdmVEYXlJc09wZW4gPSBmYWxzZTtcclxuICAgIH1cclxuXHJcbiAgICAvLyBhcGlcclxuXHJcbiAgICBoYW5kbGVFdmVudChfZXZlbnQ6IElDYWxlbmRhcik6IHZvaWQge1xyXG5cclxuICAgICAgICBsZXQgZXZlbnRDbGVhbjogSUNhbGVuZGFyID0gdGhpcy5fY2FsZW5kYXJIZWxwZXIuY2xlYW5FdmVudFByb3BlcnR5KF9ldmVudCk7XHJcblxyXG4gICAgICAgIHRoaXMub25FdmVudENsaWNrZWQuZW1pdChldmVudENsZWFuKTtcclxuICAgICAgICB0aGlzLl9jYWxlbmRhckhlbHBlci5hZGRNaXNzaW5nUmVxdWlyZWRQcm9wZXJ0eUZvckV2ZW50KGV2ZW50Q2xlYW4sIHRoaXMuX2NvbG9yVHJheSk7XHJcblxyXG4gICAgICAgIHRoaXMucmVmcmVzaC5uZXh0KCk7XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfb25WaWV3Q2hhbmdlKF9jYWxlbmRhclR5cGU6IHN0cmluZywgX2FjdGlvbjogc3RyaW5nKTogdm9pZCB7XHJcblxyXG4gICAgICAgIGxldCBuZXdEYXRlOiBib29sZWFufERhdGUgPSB0aGlzLl9jYWxlbmRhckhlbHBlci5nZXRWaWV3RGF0ZShfY2FsZW5kYXJUeXBlLCBfYWN0aW9uLCB0aGlzLnZpZXdEYXRlKTtcclxuXHJcbiAgICAgICAgaWYgKCB0eXBlb2YgbmV3RGF0ZSAhPT0gJ2Jvb2xlYW4nICkge1xyXG4gICAgICAgICAgICB0aGlzLmFjdGl2ZURheUlzT3BlbiA9IGZhbHNlO1xyXG4gICAgICAgICAgICB0aGlzLnZpZXdEYXRlID0gdGhpcy5fY2FsZW5kYXJIZWxwZXIuc3RyaW5nVG9EYXRlKG5ld0RhdGUpO1xyXG4gICAgICAgICAgICB0aGlzLmFwaS5nZXRDYWxlbmRhckRhdGUoZm9ybWF0KHRoaXMuX2NhbGVuZGFySGVscGVyLnN0cmluZ1RvRGF0ZSh0aGlzLnZpZXdEYXRlKSwgJ1lZWVktTU0tREQnKSk7XHJcbiAgICAgICAgICAgIHRoaXMucmVmcmVzaC5uZXh0KCk7XHJcbiAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgY29uc29sZS53YXJuKCdLZC1DYWxlbmRhciBFUlJPUjogY2FsZW5kYXJUeXBlOiAnICsgX2NhbGVuZGFyVHlwZSArICcgYW5kIGFjdGlvbjonICsgX2FjdGlvbiArICcgZm9yIG9uVmlld0NoYW5nZSBmdW5jdGlvbiBvbmx5IHRha2VzIGluIGNhbGVuZGFyIHR5cGU6IFwieWVhclwiIG9yIFwibW9udGhcIiBvciBcIndlZWtcIiBvciBcImRheVwiLCBhY3Rpb246IFwibmV4dFwiIG9yIFwicHJldmlvdXNcIiBvciBcInRvZGF5XCIgYXMgdGhlIGFyZ3VtZW50Jyk7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxufVxyXG4iXX0=