import { Component, ViewEncapsulation, Input, Output, EventEmitter } from '@angular/core';
import { NgbTimepickerConfig } from '@ng-bootstrap/ng-bootstrap';
export class KdTimepicker {
    constructor() {
        this._defaultConfig = new NgbTimepickerConfig();
        this.timeConfig = new EventEmitter();
    }
    ngOnInit() {
        if (typeof this.inputVal !== 'undefined')
            this.newVal = this.inputVal;
        this.timepickerConfig();
    }
    timepickerConfig() {
        for (let i in this.config) {
            if (this.config.hasOwnProperty(i)) {
                this._defaultConfig[i] = this.config[i];
            }
        }
    }
    emitValue() {
        this.timeConfig.emit(this.newVal);
    }
}
KdTimepicker.decorators = [
    { type: Component, args: [{
                selector: 'kd-timepicker',
                template: "<div class=\"kdx-timepicker-wrapper\">\r\n\t<ngb-timepicker\r\n\t\t[(ngModel)]=\"newVal\"\r\n\t\t(ngModelChange)=\"emitValue()\"\r\n\t\t[disabled]=\"_defaultConfig.disabled\"\r\n\t\t[hourStep]=\"_defaultConfig.hourStep\"\r\n\t\t[meridian]=\"_defaultConfig.meridian\"\r\n\t\t[minuteStep]=\"_defaultConfig.minuteStep\"\r\n\t\t[readonlyInputs]=\"_defaultConfig.readonlyInputs\"\r\n\t\t[secondStep]=\"_defaultConfig.secondStep\"\r\n\t\t[seconds]=\"_defaultConfig.seconds\"\r\n\t\t[spinners]=\"_defaultConfig.spinners\"\r\n\t></ngb-timepicker>\r\n\t<ng-content></ng-content>\r\n</div>\r\n\r\n",
                encapsulation: ViewEncapsulation.None,
                host: { 'class': 'kdx kdx-timepicker' }
            },] }
];
KdTimepicker.propDecorators = {
    config: [{ type: Input }],
    inputVal: [{ type: Input }],
    timeConfig: [{ type: Output }]
};
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoia2QtYW5ndWxhci10aW1lcGlja2VyLmpzIiwic291cmNlUm9vdCI6IkM6L3hhbXBwL2h0ZG9jcy9TdHlsZWd1aWRlL2lvc3RnLW9wZW5lbWlzLXN0eWxlZ3VpZGUvcHJvamVjdHMvb3BlbmVtaXMtc3R5bGVndWlkZS1saWIvc3JjLyIsInNvdXJjZXMiOlsia2QtY29tcG9uZW50cy9rZC1hbmd1bGFyLXRpbWVwaWNrZXIva2QtYW5ndWxhci10aW1lcGlja2VyLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBLE9BQU8sRUFDSCxTQUFTLEVBQ1QsaUJBQWlCLEVBQ2pCLEtBQUssRUFDTCxNQUFNLEVBQ04sWUFBWSxFQUVmLE1BQU0sZUFBZSxDQUFDO0FBQ3ZCLE9BQU8sRUFBRSxtQkFBbUIsRUFBRSxNQUFNLDRCQUE0QixDQUFDO0FBU2pFLE1BQU0sT0FBTyxZQUFZO0lBUHpCO1FBU1csbUJBQWMsR0FBd0IsSUFBSSxtQkFBbUIsRUFBRSxDQUFDO1FBSTdELGVBQVUsR0FBcUIsSUFBSSxZQUFZLEVBQUUsQ0FBQztJQWtCaEUsQ0FBQztJQWhCRyxRQUFRO1FBQ0osSUFBSSxPQUFPLElBQUksQ0FBQyxRQUFRLEtBQUssV0FBVztZQUFFLElBQUksQ0FBQyxNQUFNLEdBQUcsSUFBSSxDQUFDLFFBQVEsQ0FBQztRQUN0RSxJQUFJLENBQUMsZ0JBQWdCLEVBQUUsQ0FBQztJQUM1QixDQUFDO0lBRUQsZ0JBQWdCO1FBQ1osS0FBSyxJQUFJLENBQUMsSUFBSSxJQUFJLENBQUMsTUFBTSxFQUFFO1lBQ3ZCLElBQUksSUFBSSxDQUFDLE1BQU0sQ0FBQyxjQUFjLENBQUMsQ0FBQyxDQUFDLEVBQUU7Z0JBQy9CLElBQUksQ0FBQyxjQUFjLENBQUMsQ0FBQyxDQUFDLEdBQUcsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQzthQUMzQztTQUNKO0lBQ0wsQ0FBQztJQUVELFNBQVM7UUFDTCxJQUFJLENBQUMsVUFBVSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUM7SUFDdEMsQ0FBQzs7O1lBOUJKLFNBQVMsU0FBQztnQkFDUCxRQUFRLEVBQUUsZUFBZTtnQkFDekIsdWxCQUEyQztnQkFDM0MsYUFBYSxFQUFFLGlCQUFpQixDQUFDLElBQUk7Z0JBQ3JDLElBQUksRUFBRyxFQUFFLE9BQU8sRUFBRyxvQkFBb0IsRUFBRTthQUM1Qzs7O3FCQU1JLEtBQUs7dUJBQ0wsS0FBSzt5QkFDTCxNQUFNIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHtcclxuICAgIENvbXBvbmVudCxcclxuICAgIFZpZXdFbmNhcHN1bGF0aW9uLFxyXG4gICAgSW5wdXQsXHJcbiAgICBPdXRwdXQsXHJcbiAgICBFdmVudEVtaXR0ZXIsXHJcbiAgICBPbkluaXRcclxufSBmcm9tICdAYW5ndWxhci9jb3JlJztcclxuaW1wb3J0IHsgTmdiVGltZXBpY2tlckNvbmZpZyB9IGZyb20gJ0BuZy1ib290c3RyYXAvbmctYm9vdHN0cmFwJztcclxuXHJcbkBDb21wb25lbnQoe1xyXG4gICAgc2VsZWN0b3I6ICdrZC10aW1lcGlja2VyJyxcclxuICAgIHRlbXBsYXRlVXJsOiAnLi9rZC1hbmd1bGFyLXRpbWVwaWNrZXIuaHRtbCcsXHJcbiAgICBlbmNhcHN1bGF0aW9uOiBWaWV3RW5jYXBzdWxhdGlvbi5Ob25lLFxyXG4gICAgaG9zdCA6IHsgJ2NsYXNzJyA6ICdrZHgga2R4LXRpbWVwaWNrZXInIH1cclxufSlcclxuXHJcbmV4cG9ydCBjbGFzcyBLZFRpbWVwaWNrZXIgaW1wbGVtZW50cyBPbkluaXQge1xyXG4gICAgcHVibGljIG5ld1ZhbDogYW55O1xyXG4gICAgcHVibGljIF9kZWZhdWx0Q29uZmlnOiBOZ2JUaW1lcGlja2VyQ29uZmlnID0gbmV3IE5nYlRpbWVwaWNrZXJDb25maWcoKTtcclxuXHJcbiAgICBASW5wdXQoKSBjb25maWc6IGFueTtcclxuICAgIEBJbnB1dCgpIGlucHV0VmFsOiBhbnk7XHJcbiAgICBAT3V0cHV0KCkgdGltZUNvbmZpZzogRXZlbnRFbWl0dGVyPHt9PiA9IG5ldyBFdmVudEVtaXR0ZXIoKTtcclxuXHJcbiAgICBuZ09uSW5pdCgpOiB2b2lkIHtcclxuICAgICAgICBpZiAodHlwZW9mIHRoaXMuaW5wdXRWYWwgIT09ICd1bmRlZmluZWQnKSB0aGlzLm5ld1ZhbCA9IHRoaXMuaW5wdXRWYWw7XHJcbiAgICAgICAgdGhpcy50aW1lcGlja2VyQ29uZmlnKCk7XHJcbiAgICB9XHJcblxyXG4gICAgdGltZXBpY2tlckNvbmZpZygpIHtcclxuICAgICAgICBmb3IgKGxldCBpIGluIHRoaXMuY29uZmlnKSB7XHJcbiAgICAgICAgICAgIGlmICh0aGlzLmNvbmZpZy5oYXNPd25Qcm9wZXJ0eShpKSkge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5fZGVmYXVsdENvbmZpZ1tpXSA9IHRoaXMuY29uZmlnW2ldO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIGVtaXRWYWx1ZSgpIHtcclxuICAgICAgICB0aGlzLnRpbWVDb25maWcuZW1pdCh0aGlzLm5ld1ZhbCk7XHJcbiAgICB9XHJcbn1cclxuIl19