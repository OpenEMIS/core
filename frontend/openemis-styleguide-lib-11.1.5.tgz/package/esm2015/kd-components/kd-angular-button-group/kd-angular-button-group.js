import { Component, Input, Output, EventEmitter, ViewEncapsulation } from '@angular/core';
import { KdDomElemSvc } from '../kd-common/index';
export class KdButtonGroup {
    constructor(_domElmSvc) {
        this._domElmSvc = _domElmSvc;
        this.buttons = [];
        this.disableToolTip = true;
        this.isIconOnly = false;
        this.name = 'kdbuttongroup';
        this.updatedValue = new EventEmitter();
    }
    ngOnChanges(_simpleChanges) {
        if (_simpleChanges.hasOwnProperty('data')) {
            this.buttons = this._buttonSizeValidation(this.data);
        }
        if (_simpleChanges.hasOwnProperty('type') && typeof _simpleChanges.type.currentValue !== 'undefined') {
            this.config['type'] = this.type;
        }
        if (_simpleChanges.hasOwnProperty('value') && typeof _simpleChanges.value.currentValue !== 'undefined') {
            this._validateValueType();
        }
        if (_simpleChanges.hasOwnProperty('config')) {
            if (this.config.hasOwnProperty('iconOnly') && typeof this.config.iconOnly === 'boolean') {
                this.isIconOnly = this.config.iconOnly;
                this.disableToolTip = !this.isIconOnly;
            }
        }
    }
    emitValue() {
        this.updatedValue.emit(this.modalValue);
    }
    isButtonDisabled(_btnCond) {
        let btnDisabled;
        if (typeof this.disabled !== 'undefined' && this.disabled)
            btnDisabled = true;
        else
            btnDisabled = _btnCond ? _btnCond : false;
        return btnDisabled;
    }
    _validateValueType() {
        if (this.config.type === 'radio' &&
            this.buttons.length > 0 &&
            typeof this.buttons[0]['value'] !== typeof this.value) {
            console.warn('Value data type mismatch! ' + typeof this.buttons[0]['value'] + ' !== ' + typeof this.value);
        }
        this.modalValue = this.value;
    }
    _buttonSizeValidation(_buttons) {
        let btnList = [];
        let maxSize = 6;
        if (typeof _buttons === 'undefined')
            return [];
        this._validateValueType();
        for (let i = 0; i < _buttons.length; i++) {
            if (i < maxSize) {
                let button = _buttons[i];
                if (button.icon)
                    button.icon = this._domElmSvc.setIconClass(button.icon);
                btnList.push(button);
            }
            else {
                break;
            }
        }
        return btnList;
    }
}
KdButtonGroup.decorators = [
    { type: Component, args: [{
                selector: 'kd-button-group',
                template: `
        <ng-container [ngSwitch]="config.type">
            <ng-container  *ngSwitchCase="'radio'" >
                <div ngbRadioGroup class="btn-group btn-group-toggle" name="{{name}}" [(ngModel)]="modalValue" (ngModelChange)="emitValue()">
                    <label ngbButtonLabel class="btn-outline" [class.btn-icon]="isIconOnly" *ngFor="let button of buttons" [kd-tooltip-dir]="button.key" tooltipPosition="bottom" tooltipStyleClass="kdx-tooltip-default" [tooltipDisabled]="disableToolTip">
                        <i *ngIf="button.icon" class="{{button.icon}}"></i>
                        <span *ngIf="button.key && !isIconOnly" >{{button.key}}</span>
                        <input ngbButton type="radio" [value]="button.value" [disabled]="isButtonDisabled(button.disabled)" >
                    </label>
                </div>
            </ng-container>

            <div *ngSwitchDefault class="btn-group btn-group-toggle btn-group-checkbox">
                <label ngbButtonLabel class="btn-outline" [class.btn-icon]="isIconOnly" *ngFor="let button of buttons" [kd-tooltip-dir]="button.key" tooltipPosition="bottom" tooltipStyleClass="kdx-tooltip-default" [tooltipDisabled]="disableToolTip">
                    <i *ngIf="button.icon" class="{{button.icon}}"></i>
                    <span *ngIf="button.key && !isIconOnly" >{{button.key}}</span>
                    <input ngbButton type="checkbox" [(ngModel)]="modalValue[button.value]" (ngModelChange)="emitValue()" [disabled]="isButtonDisabled(button.disabled)">
                </label>
            </div>
        </ng-container>
    `,
                encapsulation: ViewEncapsulation.None,
                host: { 'class': 'kdx-button-group' }
            },] }
];
KdButtonGroup.ctorParameters = () => [
    { type: KdDomElemSvc }
];
KdButtonGroup.propDecorators = {
    data: [{ type: Input }],
    name: [{ type: Input }],
    value: [{ type: Input }],
    disabled: [{ type: Input }],
    config: [{ type: Input }],
    type: [{ type: Input }],
    updatedValue: [{ type: Output }]
};
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoia2QtYW5ndWxhci1idXR0b24tZ3JvdXAuanMiLCJzb3VyY2VSb290IjoiQzoveGFtcHAvaHRkb2NzL1N0eWxlZ3VpZGUvaW9zdGctb3BlbmVtaXMtc3R5bGVndWlkZS9wcm9qZWN0cy9vcGVuZW1pcy1zdHlsZWd1aWRlLWxpYi9zcmMvIiwic291cmNlcyI6WyJrZC1jb21wb25lbnRzL2tkLWFuZ3VsYXItYnV0dG9uLWdyb3VwL2tkLWFuZ3VsYXItYnV0dG9uLWdyb3VwLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBLE9BQU8sRUFDSCxTQUFTLEVBQ1QsS0FBSyxFQUNMLE1BQU0sRUFDTixZQUFZLEVBQ1osaUJBQWlCLEVBR3BCLE1BQU0sZUFBZSxDQUFDO0FBQ3ZCLE9BQU8sRUFBRSxZQUFZLEVBQUUsTUFBTSxvQkFBb0IsQ0FBQztBQThCbEQsTUFBTSxPQUFPLGFBQWE7SUFnQnRCLFlBQW9CLFVBQXdCO1FBQXhCLGVBQVUsR0FBVixVQUFVLENBQWM7UUFmckMsWUFBTyxHQUFjLEVBQUUsQ0FBQztRQUN4QixtQkFBYyxHQUFZLElBQUksQ0FBQztRQUUvQixlQUFVLEdBQVksS0FBSyxDQUFDO1FBSzFCLFNBQUksR0FBWSxlQUFlLENBQUM7UUFLL0IsaUJBQVksR0FBc0IsSUFBSSxZQUFZLEVBQUUsQ0FBQztJQUVmLENBQUM7SUFFakQsV0FBVyxDQUFDLGNBQTZCO1FBRXJDLElBQUksY0FBYyxDQUFDLGNBQWMsQ0FBQyxNQUFNLENBQUMsRUFBRTtZQUN2QyxJQUFJLENBQUMsT0FBTyxHQUFHLElBQUksQ0FBQyxxQkFBcUIsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUM7U0FDeEQ7UUFFRCxJQUFJLGNBQWMsQ0FBQyxjQUFjLENBQUMsTUFBTSxDQUFDLElBQUksT0FBTyxjQUFjLENBQUMsSUFBSSxDQUFDLFlBQVksS0FBSyxXQUFXLEVBQUU7WUFDbEcsSUFBSSxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsR0FBRyxJQUFJLENBQUMsSUFBSSxDQUFDO1NBQ25DO1FBRUQsSUFBSSxjQUFjLENBQUMsY0FBYyxDQUFDLE9BQU8sQ0FBQyxJQUFJLE9BQU8sY0FBYyxDQUFDLEtBQUssQ0FBQyxZQUFZLEtBQUssV0FBVyxFQUFFO1lBQ3BHLElBQUksQ0FBQyxrQkFBa0IsRUFBRSxDQUFDO1NBQzdCO1FBRUQsSUFBSSxjQUFjLENBQUMsY0FBYyxDQUFDLFFBQVEsQ0FBQyxFQUFFO1lBQ3pDLElBQUksSUFBSSxDQUFDLE1BQU0sQ0FBQyxjQUFjLENBQUMsVUFBVSxDQUFDLElBQUksT0FBTyxJQUFJLENBQUMsTUFBTSxDQUFDLFFBQVEsS0FBSyxTQUFTLEVBQUU7Z0JBQ3JGLElBQUksQ0FBQyxVQUFVLEdBQUcsSUFBSSxDQUFDLE1BQU0sQ0FBQyxRQUFRLENBQUM7Z0JBQ3ZDLElBQUksQ0FBQyxjQUFjLEdBQUcsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDO2FBQzFDO1NBQ0o7SUFDTCxDQUFDO0lBRU0sU0FBUztRQUNaLElBQUksQ0FBQyxZQUFZLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsQ0FBQztJQUM1QyxDQUFDO0lBRU0sZ0JBQWdCLENBQUMsUUFBd0I7UUFDNUMsSUFBSSxXQUFvQixDQUFDO1FBRXpCLElBQUksT0FBTyxJQUFJLENBQUMsUUFBUSxLQUFLLFdBQVcsSUFBSSxJQUFJLENBQUMsUUFBUTtZQUFFLFdBQVcsR0FBRyxJQUFJLENBQUM7O1lBQ3pFLFdBQVcsR0FBRyxRQUFRLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDO1FBRS9DLE9BQU8sV0FBVyxDQUFDO0lBQ3ZCLENBQUM7SUFFTyxrQkFBa0I7UUFDdEIsSUFBSSxJQUFJLENBQUMsTUFBTSxDQUFDLElBQUksS0FBSyxPQUFPO1lBQzVCLElBQUksQ0FBQyxPQUFPLENBQUMsTUFBTSxHQUFHLENBQUM7WUFDdkIsT0FBTyxJQUFJLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxLQUFLLE9BQU8sSUFBSSxDQUFDLEtBQUssRUFDdkQ7WUFDRSxPQUFPLENBQUMsSUFBSSxDQUFDLDRCQUE0QixHQUFHLE9BQU8sSUFBSSxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsR0FBRyxPQUFPLEdBQUcsT0FBTyxJQUFJLENBQUMsS0FBSyxDQUFDLENBQUM7U0FDOUc7UUFFRCxJQUFJLENBQUMsVUFBVSxHQUFHLElBQUksQ0FBQyxLQUFLLENBQUM7SUFDakMsQ0FBQztJQUVPLHFCQUFxQixDQUFDLFFBQW1CO1FBQzdDLElBQUksT0FBTyxHQUFjLEVBQUUsQ0FBQztRQUM1QixJQUFJLE9BQU8sR0FBVyxDQUFDLENBQUM7UUFFeEIsSUFBSSxPQUFPLFFBQVEsS0FBSyxXQUFXO1lBQUUsT0FBTyxFQUFFLENBQUM7UUFDL0MsSUFBSSxDQUFDLGtCQUFrQixFQUFFLENBQUM7UUFFMUIsS0FBSyxJQUFJLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxHQUFHLFFBQVEsQ0FBQyxNQUFNLEVBQUUsQ0FBQyxFQUFFLEVBQUU7WUFDdEMsSUFBSSxDQUFDLEdBQUcsT0FBTyxFQUFFO2dCQUNiLElBQUksTUFBTSxHQUFRLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQztnQkFDOUIsSUFBSSxNQUFNLENBQUMsSUFBSTtvQkFBRSxNQUFNLENBQUMsSUFBSSxHQUFHLElBQUksQ0FBQyxVQUFVLENBQUMsWUFBWSxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsQ0FBQztnQkFDekUsT0FBTyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQzthQUN4QjtpQkFDSTtnQkFDRCxNQUFNO2FBQ1Q7U0FDSjtRQUVELE9BQU8sT0FBTyxDQUFDO0lBQ25CLENBQUM7OztZQTlHSixTQUFTLFNBQUM7Z0JBQ1AsUUFBUSxFQUFFLGlCQUFpQjtnQkFDM0IsUUFBUSxFQUFFOzs7Ozs7Ozs7Ozs7Ozs7Ozs7OztLQW9CVDtnQkFDRCxhQUFhLEVBQUUsaUJBQWlCLENBQUMsSUFBSTtnQkFDckMsSUFBSSxFQUFFLEVBQUUsT0FBTyxFQUFFLGtCQUFrQixFQUFFO2FBQ3hDOzs7WUE1QlEsWUFBWTs7O21CQXNDaEIsS0FBSzttQkFDTCxLQUFLO29CQUNMLEtBQUs7dUJBQ0wsS0FBSztxQkFDTCxLQUFLO21CQUNMLEtBQUs7MkJBQ0wsTUFBTSIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7XHJcbiAgICBDb21wb25lbnQsXHJcbiAgICBJbnB1dCxcclxuICAgIE91dHB1dCxcclxuICAgIEV2ZW50RW1pdHRlcixcclxuICAgIFZpZXdFbmNhcHN1bGF0aW9uLFxyXG4gICAgT25DaGFuZ2VzLFxyXG4gICAgU2ltcGxlQ2hhbmdlc1xyXG59IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xyXG5pbXBvcnQgeyBLZERvbUVsZW1TdmMgfSBmcm9tICcuLi9rZC1jb21tb24vaW5kZXgnO1xyXG5pbXBvcnQgeyBJQnRuR3JvdXBDb25maWcsIElCdG5Hcm91cERhdGEgfSBmcm9tICcuL2tkLWFuZ3VsYXItYnV0dG9uLWdyb3VwLWludGVyZmFjZSc7XHJcblxyXG5AQ29tcG9uZW50KHtcclxuICAgIHNlbGVjdG9yOiAna2QtYnV0dG9uLWdyb3VwJyxcclxuICAgIHRlbXBsYXRlOiBgXHJcbiAgICAgICAgPG5nLWNvbnRhaW5lciBbbmdTd2l0Y2hdPVwiY29uZmlnLnR5cGVcIj5cclxuICAgICAgICAgICAgPG5nLWNvbnRhaW5lciAgKm5nU3dpdGNoQ2FzZT1cIidyYWRpbydcIiA+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IG5nYlJhZGlvR3JvdXAgY2xhc3M9XCJidG4tZ3JvdXAgYnRuLWdyb3VwLXRvZ2dsZVwiIG5hbWU9XCJ7e25hbWV9fVwiIFsobmdNb2RlbCldPVwibW9kYWxWYWx1ZVwiIChuZ01vZGVsQ2hhbmdlKT1cImVtaXRWYWx1ZSgpXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPGxhYmVsIG5nYkJ1dHRvbkxhYmVsIGNsYXNzPVwiYnRuLW91dGxpbmVcIiBbY2xhc3MuYnRuLWljb25dPVwiaXNJY29uT25seVwiICpuZ0Zvcj1cImxldCBidXR0b24gb2YgYnV0dG9uc1wiIFtrZC10b29sdGlwLWRpcl09XCJidXR0b24ua2V5XCIgdG9vbHRpcFBvc2l0aW9uPVwiYm90dG9tXCIgdG9vbHRpcFN0eWxlQ2xhc3M9XCJrZHgtdG9vbHRpcC1kZWZhdWx0XCIgW3Rvb2x0aXBEaXNhYmxlZF09XCJkaXNhYmxlVG9vbFRpcFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8aSAqbmdJZj1cImJ1dHRvbi5pY29uXCIgY2xhc3M9XCJ7e2J1dHRvbi5pY29ufX1cIj48L2k+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuICpuZ0lmPVwiYnV0dG9uLmtleSAmJiAhaXNJY29uT25seVwiID57e2J1dHRvbi5rZXl9fTwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGlucHV0IG5nYkJ1dHRvbiB0eXBlPVwicmFkaW9cIiBbdmFsdWVdPVwiYnV0dG9uLnZhbHVlXCIgW2Rpc2FibGVkXT1cImlzQnV0dG9uRGlzYWJsZWQoYnV0dG9uLmRpc2FibGVkKVwiID5cclxuICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDwvbmctY29udGFpbmVyPlxyXG5cclxuICAgICAgICAgICAgPGRpdiAqbmdTd2l0Y2hEZWZhdWx0IGNsYXNzPVwiYnRuLWdyb3VwIGJ0bi1ncm91cC10b2dnbGUgYnRuLWdyb3VwLWNoZWNrYm94XCI+XHJcbiAgICAgICAgICAgICAgICA8bGFiZWwgbmdiQnV0dG9uTGFiZWwgY2xhc3M9XCJidG4tb3V0bGluZVwiIFtjbGFzcy5idG4taWNvbl09XCJpc0ljb25Pbmx5XCIgKm5nRm9yPVwibGV0IGJ1dHRvbiBvZiBidXR0b25zXCIgW2tkLXRvb2x0aXAtZGlyXT1cImJ1dHRvbi5rZXlcIiB0b29sdGlwUG9zaXRpb249XCJib3R0b21cIiB0b29sdGlwU3R5bGVDbGFzcz1cImtkeC10b29sdGlwLWRlZmF1bHRcIiBbdG9vbHRpcERpc2FibGVkXT1cImRpc2FibGVUb29sVGlwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPGkgKm5nSWY9XCJidXR0b24uaWNvblwiIGNsYXNzPVwie3tidXR0b24uaWNvbn19XCI+PC9pPlxyXG4gICAgICAgICAgICAgICAgICAgIDxzcGFuICpuZ0lmPVwiYnV0dG9uLmtleSAmJiAhaXNJY29uT25seVwiID57e2J1dHRvbi5rZXl9fTwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICA8aW5wdXQgbmdiQnV0dG9uIHR5cGU9XCJjaGVja2JveFwiIFsobmdNb2RlbCldPVwibW9kYWxWYWx1ZVtidXR0b24udmFsdWVdXCIgKG5nTW9kZWxDaGFuZ2UpPVwiZW1pdFZhbHVlKClcIiBbZGlzYWJsZWRdPVwiaXNCdXR0b25EaXNhYmxlZChidXR0b24uZGlzYWJsZWQpXCI+XHJcbiAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8L25nLWNvbnRhaW5lcj5cclxuICAgIGAsXHJcbiAgICBlbmNhcHN1bGF0aW9uOiBWaWV3RW5jYXBzdWxhdGlvbi5Ob25lLFxyXG4gICAgaG9zdDogeyAnY2xhc3MnOiAna2R4LWJ1dHRvbi1ncm91cCcgfVxyXG59KVxyXG5cclxuZXhwb3J0IGNsYXNzIEtkQnV0dG9uR3JvdXAgaW1wbGVtZW50cyBPbkNoYW5nZXMge1xyXG4gICAgcHVibGljIGJ1dHRvbnM6IEFycmF5PHt9PiA9IFtdO1xyXG4gICAgcHVibGljIGRpc2FibGVUb29sVGlwOiBib29sZWFuID0gdHJ1ZTtcclxuICAgIHB1YmxpYyBpc1N0cmluZ01vZGU6IGJvb2xlYW47XHJcbiAgICBwdWJsaWMgaXNJY29uT25seTogYm9vbGVhbiA9IGZhbHNlO1xyXG5cclxuICAgIHB1YmxpYyBtb2RhbFZhbHVlOiBhbnk7XHJcblxyXG4gICAgQElucHV0KCkgZGF0YTogQXJyYXk8SUJ0bkdyb3VwRGF0YT47XHJcbiAgICBASW5wdXQoKSBuYW1lPzogc3RyaW5nID0gJ2tkYnV0dG9uZ3JvdXAnO1xyXG4gICAgQElucHV0KCkgdmFsdWU6IGFueTtcclxuICAgIEBJbnB1dCgpIGRpc2FibGVkPzogYm9vbGVhbjtcclxuICAgIEBJbnB1dCgpIGNvbmZpZz86IElCdG5Hcm91cENvbmZpZztcclxuICAgIEBJbnB1dCgpIHR5cGU/OiAnY2hlY2tib3gnfCdyYWRpbyc7XHJcbiAgICBAT3V0cHV0KCkgdXBkYXRlZFZhbHVlOiBFdmVudEVtaXR0ZXI8YW55PiA9IG5ldyBFdmVudEVtaXR0ZXIoKTtcclxuXHJcbiAgICBjb25zdHJ1Y3Rvcihwcml2YXRlIF9kb21FbG1TdmM6IEtkRG9tRWxlbVN2YykgeyB9XHJcblxyXG4gICAgbmdPbkNoYW5nZXMoX3NpbXBsZUNoYW5nZXM6IFNpbXBsZUNoYW5nZXMpOiB2b2lkIHtcclxuXHJcbiAgICAgICAgaWYgKF9zaW1wbGVDaGFuZ2VzLmhhc093blByb3BlcnR5KCdkYXRhJykpIHtcclxuICAgICAgICAgICAgdGhpcy5idXR0b25zID0gdGhpcy5fYnV0dG9uU2l6ZVZhbGlkYXRpb24odGhpcy5kYXRhKTtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIGlmIChfc2ltcGxlQ2hhbmdlcy5oYXNPd25Qcm9wZXJ0eSgndHlwZScpICYmIHR5cGVvZiBfc2ltcGxlQ2hhbmdlcy50eXBlLmN1cnJlbnRWYWx1ZSAhPT0gJ3VuZGVmaW5lZCcpIHtcclxuICAgICAgICAgICAgdGhpcy5jb25maWdbJ3R5cGUnXSA9IHRoaXMudHlwZTtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIGlmIChfc2ltcGxlQ2hhbmdlcy5oYXNPd25Qcm9wZXJ0eSgndmFsdWUnKSAmJiB0eXBlb2YgX3NpbXBsZUNoYW5nZXMudmFsdWUuY3VycmVudFZhbHVlICE9PSAndW5kZWZpbmVkJykge1xyXG4gICAgICAgICAgICB0aGlzLl92YWxpZGF0ZVZhbHVlVHlwZSgpO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgaWYgKF9zaW1wbGVDaGFuZ2VzLmhhc093blByb3BlcnR5KCdjb25maWcnKSkge1xyXG4gICAgICAgICAgICBpZiAodGhpcy5jb25maWcuaGFzT3duUHJvcGVydHkoJ2ljb25Pbmx5JykgJiYgdHlwZW9mIHRoaXMuY29uZmlnLmljb25Pbmx5ID09PSAnYm9vbGVhbicpIHtcclxuICAgICAgICAgICAgICAgIHRoaXMuaXNJY29uT25seSA9IHRoaXMuY29uZmlnLmljb25Pbmx5O1xyXG4gICAgICAgICAgICAgICAgdGhpcy5kaXNhYmxlVG9vbFRpcCA9ICF0aGlzLmlzSWNvbk9ubHk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgcHVibGljIGVtaXRWYWx1ZSgpOiB2b2lkIHtcclxuICAgICAgICB0aGlzLnVwZGF0ZWRWYWx1ZS5lbWl0KHRoaXMubW9kYWxWYWx1ZSk7XHJcbiAgICB9XHJcblxyXG4gICAgcHVibGljIGlzQnV0dG9uRGlzYWJsZWQoX2J0bkNvbmQ6IGJvb2xlYW4gfCBudWxsKTogYm9vbGVhbiB7XHJcbiAgICAgICAgbGV0IGJ0bkRpc2FibGVkOiBib29sZWFuO1xyXG5cclxuICAgICAgICBpZiAodHlwZW9mIHRoaXMuZGlzYWJsZWQgIT09ICd1bmRlZmluZWQnICYmIHRoaXMuZGlzYWJsZWQpIGJ0bkRpc2FibGVkID0gdHJ1ZTtcclxuICAgICAgICBlbHNlIGJ0bkRpc2FibGVkID0gX2J0bkNvbmQgPyBfYnRuQ29uZCA6IGZhbHNlO1xyXG5cclxuICAgICAgICByZXR1cm4gYnRuRGlzYWJsZWQ7XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfdmFsaWRhdGVWYWx1ZVR5cGUoKTogdm9pZCB7XHJcbiAgICAgICAgaWYgKHRoaXMuY29uZmlnLnR5cGUgPT09ICdyYWRpbycgJiZcclxuICAgICAgICAgICAgdGhpcy5idXR0b25zLmxlbmd0aCA+IDAgJiZcclxuICAgICAgICAgICAgdHlwZW9mIHRoaXMuYnV0dG9uc1swXVsndmFsdWUnXSAhPT0gdHlwZW9mIHRoaXMudmFsdWVcclxuICAgICAgICApIHtcclxuICAgICAgICAgICAgY29uc29sZS53YXJuKCdWYWx1ZSBkYXRhIHR5cGUgbWlzbWF0Y2ghICcgKyB0eXBlb2YgdGhpcy5idXR0b25zWzBdWyd2YWx1ZSddICsgJyAhPT0gJyArIHR5cGVvZiB0aGlzLnZhbHVlKTtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIHRoaXMubW9kYWxWYWx1ZSA9IHRoaXMudmFsdWU7XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfYnV0dG9uU2l6ZVZhbGlkYXRpb24oX2J1dHRvbnM6IEFycmF5PHt9Pik6IEFycmF5PHt9PiB7XHJcbiAgICAgICAgbGV0IGJ0bkxpc3Q6IEFycmF5PHt9PiA9IFtdO1xyXG4gICAgICAgIGxldCBtYXhTaXplOiBudW1iZXIgPSA2O1xyXG5cclxuICAgICAgICBpZiAodHlwZW9mIF9idXR0b25zID09PSAndW5kZWZpbmVkJykgcmV0dXJuIFtdO1xyXG4gICAgICAgIHRoaXMuX3ZhbGlkYXRlVmFsdWVUeXBlKCk7XHJcblxyXG4gICAgICAgIGZvciAobGV0IGkgPSAwOyBpIDwgX2J1dHRvbnMubGVuZ3RoOyBpKyspIHtcclxuICAgICAgICAgICAgaWYgKGkgPCBtYXhTaXplKSB7XHJcbiAgICAgICAgICAgICAgICBsZXQgYnV0dG9uOiBhbnkgPSBfYnV0dG9uc1tpXTtcclxuICAgICAgICAgICAgICAgIGlmIChidXR0b24uaWNvbikgYnV0dG9uLmljb24gPSB0aGlzLl9kb21FbG1TdmMuc2V0SWNvbkNsYXNzKGJ1dHRvbi5pY29uKTtcclxuICAgICAgICAgICAgICAgIGJ0bkxpc3QucHVzaChidXR0b24pO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIHJldHVybiBidG5MaXN0O1xyXG4gICAgfVxyXG59XHJcbiJdfQ==