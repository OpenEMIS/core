import { Component, Input } from '@angular/core';
import { Location } from '@angular/common';
import { Router } from '@angular/router';
export class KdError {
    constructor(_location, _router) {
        this._location = _location;
        this._router = _router;
        this._finalConfig = {};
        this._defaultConfig = {
            homePath: '',
            email: 'support@openemis.org',
            backPath: '',
            forbiddenPath: ''
        };
    }
    ngOnInit() {
        if (typeof this.errorType === 'undefined')
            this.errorType = '403';
        switch (this.errorType) {
            case '404':
                this._defaultConfig.icon = 'kd-404-error';
                break;
            default:
                this._defaultConfig.icon = 'kd-403-error';
                break;
        }
        this._finalConfig = Object.assign(this._defaultConfig, this.config);
    }
    redirect() {
        if (this._finalConfig.homePath !== '') {
            this._router.navigate(['.' + this._finalConfig.homePath]);
        }
        else {
            console.log('Please specify the home path');
        }
    }
    back() {
        // if(typeof this.config.backbtn === 'undefined' || this.config.backbtn =='') {
        //     this._location.back();
        // } else {
        //     this._router.navigate(['.'+this.config.backbtn]);
        // }
        if (this._finalConfig.backPath !== '') {
            this._router.navigate(['.' + this._finalConfig.backPath]);
        }
        else {
            console.log('Please specify the back path');
        }
    }
}
KdError.decorators = [
    { type: Component, args: [{
                selector: 'kd-error',
                template: "<div class=\"kdx-error\">\r\n    <div class=\"kdx-error-page-icon\">\r\n        <i class=\"fa fa-5x\" [ngClass]=\"_finalConfig.icon\"></i>\r\n    </div>\r\n    <div class=\"kdx-error-page-text\" [ngSwitch]=\"errorType\">\r\n        <div *ngSwitchCase=\"'403'\">\r\n            <h1>403 Forbidden: No Permission to Access</h1>\r\n            <h5>You don't have permission to access \"{{_finalConfig.forbiddenPath}}\" on this server. If you believe you should be able to view this directory or page, please contact the administrator <a href=\"mailto:{{_finalConfig.email}}\">here</a>.</h5>\r\n        </div>\r\n        <div *ngSwitchCase=\"'404'\">\r\n            <h1>404 Forbidden: Page Not Found</h1>\r\n            <h5>The page you are looking for might have been removed, renamed or is temporarily unavailable. If you have any enquiries, please contact the administrator <a href=\"mailto:{{_finalConfig.email}}\">here</a>.</h5>\r\n        </div>\r\n    </div>\r\n    <div class=\"kdx-error-page-buttons\">\r\n    \t<button class=\"btn btn-icon btn-outline\" type=\"button\" (click)=\"back()\">\r\n            <i class=\"fa fa-caret-left\" aria-hidden=\"true\"></i> Back\r\n        </button>\r\n        <button class=\"btn btn-icon\" type=\"button\" (click)=\"redirect()\">\r\n            <i class=\"fa fa-home\" aria-hidden=\"true\"></i> Home\r\n        </button>\r\n    </div>\r\n</div>"
            },] }
];
KdError.ctorParameters = () => [
    { type: Location },
    { type: Router }
];
KdError.propDecorators = {
    config: [{ type: Input }],
    errorType: [{ type: Input, args: ['error-type',] }]
};
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoia2QtYW5ndWxhci1lcnJvci5qcyIsInNvdXJjZVJvb3QiOiJDOi94YW1wcC9odGRvY3MvU3R5bGVndWlkZS9pb3N0Zy1vcGVuZW1pcy1zdHlsZWd1aWRlL3Byb2plY3RzL29wZW5lbWlzLXN0eWxlZ3VpZGUtbGliL3NyYy8iLCJzb3VyY2VzIjpbImtkLWNvbXBvbmVudHMva2QtYW5ndWxhci1lcnJvci9rZC1hbmd1bGFyLWVycm9yLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBLE9BQU8sRUFBRSxTQUFTLEVBQUUsS0FBSyxFQUFVLE1BQU0sZUFBZSxDQUFDO0FBQ3pELE9BQU8sRUFBRSxRQUFRLEVBQUUsTUFBTSxpQkFBaUIsQ0FBQztBQUMzQyxPQUFPLEVBQUUsTUFBTSxFQUFFLE1BQU0saUJBQWlCLENBQUM7QUFPekMsTUFBTSxPQUFPLE9BQU87SUFZaEIsWUFDYyxTQUFtQixFQUNuQixPQUFlO1FBRGYsY0FBUyxHQUFULFNBQVMsQ0FBVTtRQUNuQixZQUFPLEdBQVAsT0FBTyxDQUFRO1FBYnRCLGlCQUFZLEdBQVEsRUFBRSxDQUFDO1FBQ3RCLG1CQUFjLEdBQVE7WUFDMUIsUUFBUSxFQUFFLEVBQUU7WUFDWixLQUFLLEVBQUUsc0JBQXNCO1lBQzdCLFFBQVEsRUFBRSxFQUFFO1lBQ1osYUFBYSxFQUFFLEVBQUU7U0FDcEIsQ0FBQztJQVFFLENBQUM7SUFFTCxRQUFRO1FBRUosSUFBSSxPQUFPLElBQUksQ0FBQyxTQUFTLEtBQUssV0FBVztZQUFFLElBQUksQ0FBQyxTQUFTLEdBQUcsS0FBSyxDQUFDO1FBRWxFLFFBQVEsSUFBSSxDQUFDLFNBQVMsRUFBRTtZQUNwQixLQUFLLEtBQUs7Z0JBQ04sSUFBSSxDQUFDLGNBQWMsQ0FBQyxJQUFJLEdBQUcsY0FBYyxDQUFDO2dCQUMxQyxNQUFNO1lBQ1Y7Z0JBQ0ksSUFBSSxDQUFDLGNBQWMsQ0FBQyxJQUFJLEdBQUcsY0FBYyxDQUFDO2dCQUMxQyxNQUFNO1NBQ2I7UUFFRCxJQUFJLENBQUMsWUFBWSxHQUFHLE1BQU0sQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLGNBQWMsRUFBRSxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUM7SUFDeEUsQ0FBQztJQUVELFFBQVE7UUFDSixJQUFJLElBQUksQ0FBQyxZQUFZLENBQUMsUUFBUSxLQUFLLEVBQUUsRUFBRTtZQUNuQyxJQUFJLENBQUMsT0FBTyxDQUFDLFFBQVEsQ0FBQyxDQUFDLEdBQUcsR0FBRyxJQUFJLENBQUMsWUFBWSxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUM7U0FDN0Q7YUFDSTtZQUNELE9BQU8sQ0FBQyxHQUFHLENBQUMsOEJBQThCLENBQUMsQ0FBQztTQUMvQztJQUNMLENBQUM7SUFFRCxJQUFJO1FBQ0EsK0VBQStFO1FBQy9FLDZCQUE2QjtRQUM3QixXQUFXO1FBQ1gsd0RBQXdEO1FBQ3hELElBQUk7UUFDSixJQUFJLElBQUksQ0FBQyxZQUFZLENBQUMsUUFBUSxLQUFLLEVBQUUsRUFBRTtZQUNuQyxJQUFJLENBQUMsT0FBTyxDQUFDLFFBQVEsQ0FBQyxDQUFDLEdBQUcsR0FBRyxJQUFJLENBQUMsWUFBWSxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUM7U0FDN0Q7YUFBTTtZQUNILE9BQU8sQ0FBQyxHQUFHLENBQUMsOEJBQThCLENBQUMsQ0FBQztTQUMvQztJQUNMLENBQUM7OztZQTFESixTQUFTLFNBQUM7Z0JBQ1AsUUFBUSxFQUFFLFVBQVU7Z0JBQ3BCLHczQ0FBc0M7YUFDekM7OztZQU5RLFFBQVE7WUFDUixNQUFNOzs7cUJBZ0JWLEtBQUs7d0JBQ0wsS0FBSyxTQUFDLFlBQVkiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBDb21wb25lbnQsIElucHV0LCBPbkluaXQgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcclxuaW1wb3J0IHsgTG9jYXRpb24gfSBmcm9tICdAYW5ndWxhci9jb21tb24nO1xyXG5pbXBvcnQgeyBSb3V0ZXIgfSBmcm9tICdAYW5ndWxhci9yb3V0ZXInO1xyXG5cclxuQENvbXBvbmVudCh7XHJcbiAgICBzZWxlY3RvcjogJ2tkLWVycm9yJyxcclxuICAgIHRlbXBsYXRlVXJsOiAnLi9rZC1hbmd1bGFyLWVycm9yLmh0bWwnLFxyXG59KVxyXG5cclxuZXhwb3J0IGNsYXNzIEtkRXJyb3IgaW1wbGVtZW50cyBPbkluaXQge1xyXG4gICAgcHVibGljIF9maW5hbENvbmZpZzogYW55ID0ge307XHJcbiAgICBwcml2YXRlIF9kZWZhdWx0Q29uZmlnOiBhbnkgPSB7XHJcbiAgICAgICAgaG9tZVBhdGg6ICcnLFxyXG4gICAgICAgIGVtYWlsOiAnc3VwcG9ydEBvcGVuZW1pcy5vcmcnLFxyXG4gICAgICAgIGJhY2tQYXRoOiAnJyxcclxuICAgICAgICBmb3JiaWRkZW5QYXRoOiAnJ1xyXG4gICAgfTtcclxuXHJcbiAgICBASW5wdXQoKSBjb25maWc6IGFueTtcclxuICAgIEBJbnB1dCgnZXJyb3ItdHlwZScpIGVycm9yVHlwZTogc3RyaW5nO1xyXG5cclxuICAgIGNvbnN0cnVjdG9yKFxyXG4gICAgICAgIHByb3RlY3RlZCBfbG9jYXRpb246IExvY2F0aW9uLFxyXG4gICAgICAgIHByb3RlY3RlZCBfcm91dGVyOiBSb3V0ZXJcclxuICAgICkgeyB9XHJcblxyXG4gICAgbmdPbkluaXQoKTogdm9pZCB7XHJcblxyXG4gICAgICAgIGlmICh0eXBlb2YgdGhpcy5lcnJvclR5cGUgPT09ICd1bmRlZmluZWQnKSB0aGlzLmVycm9yVHlwZSA9ICc0MDMnO1xyXG5cclxuICAgICAgICBzd2l0Y2ggKHRoaXMuZXJyb3JUeXBlKSB7XHJcbiAgICAgICAgICAgIGNhc2UgJzQwNCc6XHJcbiAgICAgICAgICAgICAgICB0aGlzLl9kZWZhdWx0Q29uZmlnLmljb24gPSAna2QtNDA0LWVycm9yJztcclxuICAgICAgICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgICAgICBkZWZhdWx0OlxyXG4gICAgICAgICAgICAgICAgdGhpcy5fZGVmYXVsdENvbmZpZy5pY29uID0gJ2tkLTQwMy1lcnJvcic7XHJcbiAgICAgICAgICAgICAgICBicmVhaztcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIHRoaXMuX2ZpbmFsQ29uZmlnID0gT2JqZWN0LmFzc2lnbih0aGlzLl9kZWZhdWx0Q29uZmlnLCB0aGlzLmNvbmZpZyk7XHJcbiAgICB9XHJcblxyXG4gICAgcmVkaXJlY3QoKSB7XHJcbiAgICAgICAgaWYgKHRoaXMuX2ZpbmFsQ29uZmlnLmhvbWVQYXRoICE9PSAnJykge1xyXG4gICAgICAgICAgICB0aGlzLl9yb3V0ZXIubmF2aWdhdGUoWycuJyArIHRoaXMuX2ZpbmFsQ29uZmlnLmhvbWVQYXRoXSk7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICBjb25zb2xlLmxvZygnUGxlYXNlIHNwZWNpZnkgdGhlIGhvbWUgcGF0aCcpO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICBiYWNrKCkge1xyXG4gICAgICAgIC8vIGlmKHR5cGVvZiB0aGlzLmNvbmZpZy5iYWNrYnRuID09PSAndW5kZWZpbmVkJyB8fCB0aGlzLmNvbmZpZy5iYWNrYnRuID09JycpIHtcclxuICAgICAgICAvLyAgICAgdGhpcy5fbG9jYXRpb24uYmFjaygpO1xyXG4gICAgICAgIC8vIH0gZWxzZSB7XHJcbiAgICAgICAgLy8gICAgIHRoaXMuX3JvdXRlci5uYXZpZ2F0ZShbJy4nK3RoaXMuY29uZmlnLmJhY2tidG5dKTtcclxuICAgICAgICAvLyB9XHJcbiAgICAgICAgaWYgKHRoaXMuX2ZpbmFsQ29uZmlnLmJhY2tQYXRoICE9PSAnJykge1xyXG4gICAgICAgICAgICB0aGlzLl9yb3V0ZXIubmF2aWdhdGUoWycuJyArIHRoaXMuX2ZpbmFsQ29uZmlnLmJhY2tQYXRoXSk7XHJcbiAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgY29uc29sZS5sb2coJ1BsZWFzZSBzcGVjaWZ5IHRoZSBiYWNrIHBhdGgnKTtcclxuICAgICAgICB9XHJcbiAgICB9XHJcbn1cclxuIl19