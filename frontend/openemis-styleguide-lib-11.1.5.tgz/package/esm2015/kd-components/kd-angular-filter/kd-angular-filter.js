import { Component, Input, ViewEncapsulation, ViewChild, Output, EventEmitter } from '@angular/core';
import { KdView } from '../kd-angular-view/index';
export class KdFilter {
    constructor() {
        this._filteredData = [];
        this.valueUpdate = new EventEmitter();
    }
    ngOnInit() {
        this._filteredData = this._getUpdatedData(this.inputData);
    }
    getInputProperty(key, propertyName) {
        return this._updateView.getInputProperty(key, propertyName);
    }
    setInputProperty(_key, _propertyName, _data) {
        this._updateView.setInputProperty(_key, _propertyName, _data);
    }
    detectValue(_question) {
        this.valueUpdate.emit(_question);
    }
    _getUpdatedData(_inputData) {
        let updatedData = [];
        for (let i = 0; i < _inputData.length; i++) {
            if (_inputData[i].controlType !== 'multiselect' &&
                _inputData[i].controlType !== 'password' &&
                _inputData[i].controlType !== 'textarea' &&
                _inputData[i].controlType !== 'hidden' &&
                _inputData[i].controlType !== 'disabled' &&
                _inputData[i].controlType !== 'readonly' &&
                _inputData[i].controlType !== 'file-input' &&
                _inputData[i].controlType !== 'radio' &&
                // _inputData[i].controlType !== 'tree' &&
                _inputData[i].controlType !== 'multi-table' &&
                _inputData[i].controlType !== 'aggrid' &&
                _inputData[i].controlType !== 'text') {
                updatedData.push(_inputData[i]);
            }
            if (_inputData[i].controlType === 'text' && _inputData[i].type !== 'multiselect')
                updatedData.push(_inputData[i]);
        }
        return updatedData;
    }
}
KdFilter.decorators = [
    { type: Component, args: [{
                selector: 'kd-filter',
                template: `<kd-view displayType='horizontal-form' [inputData]='_filteredData' (detectFrom)='detectValue($event)'></kd-view>`,
                encapsulation: ViewEncapsulation.None,
                host: { 'class': 'kdx-filter' }
            },] }
];
KdFilter.propDecorators = {
    inputData: [{ type: Input }],
    valueUpdate: [{ type: Output }],
    _updateView: [{ type: ViewChild, args: [KdView, { static: true },] }]
};
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoia2QtYW5ndWxhci1maWx0ZXIuanMiLCJzb3VyY2VSb290IjoiQzoveGFtcHAvaHRkb2NzL1N0eWxlZ3VpZGUvaW9zdGctb3BlbmVtaXMtc3R5bGVndWlkZS9wcm9qZWN0cy9vcGVuZW1pcy1zdHlsZWd1aWRlLWxpYi9zcmMvIiwic291cmNlcyI6WyJrZC1jb21wb25lbnRzL2tkLWFuZ3VsYXItZmlsdGVyL2tkLWFuZ3VsYXItZmlsdGVyLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBLE9BQU8sRUFDSCxTQUFTLEVBQ1QsS0FBSyxFQUNMLGlCQUFpQixFQUNqQixTQUFTLEVBQ1QsTUFBTSxFQUNOLFlBQVksRUFFZixNQUFNLGVBQWUsQ0FBQztBQUN2QixPQUFPLEVBQUUsTUFBTSxFQUFFLE1BQU0sMEJBQTBCLENBQUM7QUFRbEQsTUFBTSxPQUFPLFFBQVE7SUFOckI7UUFPVyxrQkFBYSxHQUFlLEVBQUUsQ0FBQztRQUc1QixnQkFBVyxHQUFzQixJQUFJLFlBQVksRUFBRSxDQUFDO0lBMkNsRSxDQUFDO0lBeENHLFFBQVE7UUFDSixJQUFJLENBQUMsYUFBYSxHQUFHLElBQUksQ0FBQyxlQUFlLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDO0lBQzlELENBQUM7SUFFTSxnQkFBZ0IsQ0FBQyxHQUFXLEVBQUUsWUFBb0I7UUFDckQsT0FBTyxJQUFJLENBQUMsV0FBVyxDQUFDLGdCQUFnQixDQUFDLEdBQUcsRUFBRSxZQUFZLENBQUMsQ0FBQztJQUNoRSxDQUFDO0lBRU0sZ0JBQWdCLENBQUMsSUFBWSxFQUFFLGFBQXFCLEVBQUUsS0FBVTtRQUNuRSxJQUFJLENBQUMsV0FBVyxDQUFDLGdCQUFnQixDQUFDLElBQUksRUFBRSxhQUFhLEVBQUUsS0FBSyxDQUFDLENBQUM7SUFDbEUsQ0FBQztJQUVNLFdBQVcsQ0FBQyxTQUFjO1FBQzdCLElBQUksQ0FBQyxXQUFXLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDO0lBQ3JDLENBQUM7SUFFTyxlQUFlLENBQUMsVUFBc0I7UUFDMUMsSUFBSSxXQUFXLEdBQWUsRUFBRSxDQUFDO1FBQ2pDLEtBQUssSUFBSSxDQUFDLEdBQVcsQ0FBQyxFQUFFLENBQUMsR0FBRyxVQUFVLENBQUMsTUFBTSxFQUFFLENBQUMsRUFBRSxFQUFFO1lBQ2hELElBQ0ksVUFBVSxDQUFDLENBQUMsQ0FBQyxDQUFDLFdBQVcsS0FBSyxhQUFhO2dCQUMzQyxVQUFVLENBQUMsQ0FBQyxDQUFDLENBQUMsV0FBVyxLQUFLLFVBQVU7Z0JBQ3hDLFVBQVUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxXQUFXLEtBQUssVUFBVTtnQkFDeEMsVUFBVSxDQUFDLENBQUMsQ0FBQyxDQUFDLFdBQVcsS0FBSyxRQUFRO2dCQUN0QyxVQUFVLENBQUMsQ0FBQyxDQUFDLENBQUMsV0FBVyxLQUFLLFVBQVU7Z0JBQ3hDLFVBQVUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxXQUFXLEtBQUssVUFBVTtnQkFDeEMsVUFBVSxDQUFDLENBQUMsQ0FBQyxDQUFDLFdBQVcsS0FBSyxZQUFZO2dCQUMxQyxVQUFVLENBQUMsQ0FBQyxDQUFDLENBQUMsV0FBVyxLQUFLLE9BQU87Z0JBQ3JDLDBDQUEwQztnQkFDMUMsVUFBVSxDQUFDLENBQUMsQ0FBQyxDQUFDLFdBQVcsS0FBSyxhQUFhO2dCQUMzQyxVQUFVLENBQUMsQ0FBQyxDQUFDLENBQUMsV0FBVyxLQUFLLFFBQVE7Z0JBQ3RDLFVBQVUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxXQUFXLEtBQUssTUFBTSxFQUN0QztnQkFDRSxXQUFXLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO2FBQ25DO1lBRUQsSUFBSSxVQUFVLENBQUMsQ0FBQyxDQUFDLENBQUMsV0FBVyxLQUFLLE1BQU0sSUFBSSxVQUFVLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxLQUFLLGFBQWE7Z0JBQUUsV0FBVyxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztTQUNySDtRQUNELE9BQU8sV0FBVyxDQUFDO0lBQ3ZCLENBQUM7OztZQXBESixTQUFTLFNBQUM7Z0JBQ1AsUUFBUSxFQUFFLFdBQVc7Z0JBQ3JCLFFBQVEsRUFBRSxrSEFBa0g7Z0JBQzVILGFBQWEsRUFBRSxpQkFBaUIsQ0FBQyxJQUFJO2dCQUNyQyxJQUFJLEVBQUUsRUFBRSxPQUFPLEVBQUcsWUFBWSxFQUFFO2FBQ25DOzs7d0JBSUksS0FBSzswQkFDTCxNQUFNOzBCQUNOLFNBQVMsU0FBQyxNQUFNLEVBQUUsRUFBRSxNQUFNLEVBQUUsSUFBSSxFQUFFIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHtcclxuICAgIENvbXBvbmVudCxcclxuICAgIElucHV0LFxyXG4gICAgVmlld0VuY2Fwc3VsYXRpb24sXHJcbiAgICBWaWV3Q2hpbGQsXHJcbiAgICBPdXRwdXQsXHJcbiAgICBFdmVudEVtaXR0ZXIsXHJcbiAgICBPbkluaXRcclxufSBmcm9tICdAYW5ndWxhci9jb3JlJztcclxuaW1wb3J0IHsgS2RWaWV3IH0gZnJvbSAnLi4va2QtYW5ndWxhci12aWV3L2luZGV4JztcclxuXHJcbkBDb21wb25lbnQoe1xyXG4gICAgc2VsZWN0b3I6ICdrZC1maWx0ZXInLFxyXG4gICAgdGVtcGxhdGU6IGA8a2QtdmlldyBkaXNwbGF5VHlwZT0naG9yaXpvbnRhbC1mb3JtJyBbaW5wdXREYXRhXT0nX2ZpbHRlcmVkRGF0YScgKGRldGVjdEZyb20pPSdkZXRlY3RWYWx1ZSgkZXZlbnQpJz48L2tkLXZpZXc+YCxcclxuICAgIGVuY2Fwc3VsYXRpb246IFZpZXdFbmNhcHN1bGF0aW9uLk5vbmUsXHJcbiAgICBob3N0OiB7ICdjbGFzcycgOiAna2R4LWZpbHRlcicgfVxyXG59KVxyXG5leHBvcnQgY2xhc3MgS2RGaWx0ZXIgaW1wbGVtZW50cyBPbkluaXQge1xyXG4gICAgcHVibGljIF9maWx0ZXJlZERhdGE6IEFycmF5PGFueT4gPSBbXTtcclxuXHJcbiAgICBASW5wdXQoKSBpbnB1dERhdGE6IGFueTtcclxuICAgIEBPdXRwdXQoKSB2YWx1ZVVwZGF0ZTogRXZlbnRFbWl0dGVyPGFueT4gPSBuZXcgRXZlbnRFbWl0dGVyKCk7XHJcbiAgICBAVmlld0NoaWxkKEtkVmlldywgeyBzdGF0aWM6IHRydWUgfSkgX3VwZGF0ZVZpZXc6IEtkVmlldztcclxuXHJcbiAgICBuZ09uSW5pdCgpOiB2b2lkIHtcclxuICAgICAgICB0aGlzLl9maWx0ZXJlZERhdGEgPSB0aGlzLl9nZXRVcGRhdGVkRGF0YSh0aGlzLmlucHV0RGF0YSk7XHJcbiAgICB9XHJcblxyXG4gICAgcHVibGljIGdldElucHV0UHJvcGVydHkoa2V5OiBzdHJpbmcsIHByb3BlcnR5TmFtZTogc3RyaW5nKTogYW55IHtcclxuICAgICAgICByZXR1cm4gdGhpcy5fdXBkYXRlVmlldy5nZXRJbnB1dFByb3BlcnR5KGtleSwgcHJvcGVydHlOYW1lKTtcclxuICAgIH1cclxuXHJcbiAgICBwdWJsaWMgc2V0SW5wdXRQcm9wZXJ0eShfa2V5OiBzdHJpbmcsIF9wcm9wZXJ0eU5hbWU6IHN0cmluZywgX2RhdGE6IGFueSk6IHZvaWQge1xyXG4gICAgICAgIHRoaXMuX3VwZGF0ZVZpZXcuc2V0SW5wdXRQcm9wZXJ0eShfa2V5LCBfcHJvcGVydHlOYW1lLCBfZGF0YSk7XHJcbiAgICB9XHJcblxyXG4gICAgcHVibGljIGRldGVjdFZhbHVlKF9xdWVzdGlvbjogYW55KTogdm9pZCB7XHJcbiAgICAgICAgdGhpcy52YWx1ZVVwZGF0ZS5lbWl0KF9xdWVzdGlvbik7XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfZ2V0VXBkYXRlZERhdGEoX2lucHV0RGF0YTogQXJyYXk8YW55Pik6IEFycmF5PGFueT4ge1xyXG4gICAgICAgIGxldCB1cGRhdGVkRGF0YTogQXJyYXk8YW55PiA9IFtdO1xyXG4gICAgICAgIGZvciAobGV0IGk6IG51bWJlciA9IDA7IGkgPCBfaW5wdXREYXRhLmxlbmd0aDsgaSsrKSB7XHJcbiAgICAgICAgICAgIGlmIChcclxuICAgICAgICAgICAgICAgIF9pbnB1dERhdGFbaV0uY29udHJvbFR5cGUgIT09ICdtdWx0aXNlbGVjdCcgJiZcclxuICAgICAgICAgICAgICAgIF9pbnB1dERhdGFbaV0uY29udHJvbFR5cGUgIT09ICdwYXNzd29yZCcgJiZcclxuICAgICAgICAgICAgICAgIF9pbnB1dERhdGFbaV0uY29udHJvbFR5cGUgIT09ICd0ZXh0YXJlYScgJiZcclxuICAgICAgICAgICAgICAgIF9pbnB1dERhdGFbaV0uY29udHJvbFR5cGUgIT09ICdoaWRkZW4nICYmXHJcbiAgICAgICAgICAgICAgICBfaW5wdXREYXRhW2ldLmNvbnRyb2xUeXBlICE9PSAnZGlzYWJsZWQnICYmXHJcbiAgICAgICAgICAgICAgICBfaW5wdXREYXRhW2ldLmNvbnRyb2xUeXBlICE9PSAncmVhZG9ubHknICYmXHJcbiAgICAgICAgICAgICAgICBfaW5wdXREYXRhW2ldLmNvbnRyb2xUeXBlICE9PSAnZmlsZS1pbnB1dCcgJiZcclxuICAgICAgICAgICAgICAgIF9pbnB1dERhdGFbaV0uY29udHJvbFR5cGUgIT09ICdyYWRpbycgJiZcclxuICAgICAgICAgICAgICAgIC8vIF9pbnB1dERhdGFbaV0uY29udHJvbFR5cGUgIT09ICd0cmVlJyAmJlxyXG4gICAgICAgICAgICAgICAgX2lucHV0RGF0YVtpXS5jb250cm9sVHlwZSAhPT0gJ211bHRpLXRhYmxlJyAmJlxyXG4gICAgICAgICAgICAgICAgX2lucHV0RGF0YVtpXS5jb250cm9sVHlwZSAhPT0gJ2FnZ3JpZCcgJiZcclxuICAgICAgICAgICAgICAgIF9pbnB1dERhdGFbaV0uY29udHJvbFR5cGUgIT09ICd0ZXh0J1xyXG4gICAgICAgICAgICApIHtcclxuICAgICAgICAgICAgICAgIHVwZGF0ZWREYXRhLnB1c2goX2lucHV0RGF0YVtpXSk7XHJcbiAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgIGlmIChfaW5wdXREYXRhW2ldLmNvbnRyb2xUeXBlID09PSAndGV4dCcgJiYgX2lucHV0RGF0YVtpXS50eXBlICE9PSAnbXVsdGlzZWxlY3QnKSB1cGRhdGVkRGF0YS5wdXNoKF9pbnB1dERhdGFbaV0pO1xyXG4gICAgICAgIH1cclxuICAgICAgICByZXR1cm4gdXBkYXRlZERhdGE7XHJcbiAgICB9XHJcbn1cclxuIl19