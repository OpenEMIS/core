import { Injectable } from '@angular/core';
export class KdMultiSelectTableSvc {
    getBothOptions(_config, _masterData, _slaveData) {
        // let masterData = (typeof config.masterData != "undefined") ? config.masterData.slice() : [];
        // let slaveData = (typeof config.slaveData != "undefined") ? config.slaveData.slice() : [];
        // console.log(_config);
        // console.log(_masterData);
        // console.log(_slaveData);
        let updatedOptions = {
            masterGridOption: this._getGridOptions('master', _masterData),
            slaveGridOption: this._getGridOptions('slave', _slaveData)
        };
        return updatedOptions;
    }
    getPrimarykey(config) {
        // if user set more than one primary key, only the first one will be used.
        if (typeof config.colDef !== 'undefined') {
            for (let i in config.colDef) {
                if (config.colDef[i].primaryKey) {
                    return i;
                }
            }
            return 'id';
        }
    }
    getColDefs(_colDef) {
        let updatedColDef = [];
        for (let i in _colDef) {
            if (typeof _colDef[i] !== 'undefined') {
                let tableColumn = {
                    headerName: _colDef[i].headerName,
                    field: i,
                    colId: i,
                    cellClass: 'ag-default',
                    menuTabs: []
                };
                updatedColDef.push(tableColumn);
            }
        }
        return updatedColDef;
    }
    getPlaceholder(config, grid) {
        // grid is either top or bottom
        let query = grid + 'Placeholder';
        if (typeof config.gridSetting !== 'undefined' && typeof config.gridSetting[query] !== 'undefined')
            return config.gridSetting[query];
        return 'Undefined';
    }
    getButton(config, grid) {
        // grid is either toTopBtn or toBottomBtn
        let updatedBtn = {};
        if (typeof config.gridSetting !== 'undefined' && typeof config.gridSetting[grid].icon !== 'undefined')
            updatedBtn.icon = config.gridSetting[grid].icon;
        else
            updatedBtn.icon = '';
        if (typeof config.gridSetting[grid] !== 'undefined' && typeof config.gridSetting[grid].text !== 'undefined')
            updatedBtn.text = config.gridSetting[grid].text;
        else
            updatedBtn.text = 'Undefined';
        return updatedBtn;
    }
    getCheckboxDefault() {
        return {
            width: 50,
            minWidth: 50,
            maxWidth: 50,
            colId: 'checkbox',
            headerName: '',
            suppressMenu: true,
            suppressSorting: true,
            suppressSizeToFit: true,
            cellClass: 'ag-checkbox-radio'
        };
    }
    calcMobileHeight(masterGrid, slaveGrid, vcr) {
        let topData = masterGrid.api.getModel().getRowCount();
        let bottomData = slaveGrid.api.getModel().getRowCount();
        let topHeight = (typeof topData !== 'undefined' && topData > 0) ? this._getGridHeight(topData, 'top') : 150;
        let bottomHeight = (typeof bottomData !== 'undefined' && bottomData > 0) ? this._getGridHeight(bottomData, 'bottom') : 150;
        let result = {
            top: topHeight,
            bottom: bottomHeight
        };
        return result;
    }
    calcWebHeight(height) {
        let separator = 65;
        let checkedHeight = ((typeof height !== 'number') ? 600 : height) - separator;
        let bottomHeight = (checkedHeight - 38) / 2;
        let webHeight = {
            top: bottomHeight + 38,
            bottom: bottomHeight
        };
        return webHeight;
    }
    // getColDefWidth(_gridOptions: GridOptions): Array<any> {
    //     let column: Array<Column> = _gridOptions.columnApi.getAllColumns();
    //     let colWidth: Array<number> = [];
    //     for(let i: number = 0; i < column.length; i++){
    //         if(column[i].getColId() !== 'checkbox') {
    //             colWidth.push(column[i].getActualWidth() + 30);
    //         }
    //         else{
    //             colWidth.push(50);
    //         }
    //     }
    //     // console.log(colWidth);
    //     return colWidth;
    // }
    // getColTotalWidth(_colArray: Array<number>): number {
    //     let total: number = 0;
    //     for (let i: number = 0; i < _colArray.length; i++) {
    //         total += _colArray[i];
    //     }
    //     return total;
    // }
    // getUsableWidth(_vcr: ViewContainerRef): number {
    //     let agGridEle: HTMLElement = _vcr.element.nativeElement.querySelector('.stg-theme');
    //     let parentWidth: number = Math.round(agGridEle.getBoundingClientRect().width);
    //     let computedStyle: CSSStyleDeclaration = window.getComputedStyle(agGridEle);
    //     let borderLeft: number = (computedStyle.borderLeft !== '') ? parseInt(computedStyle.borderLeft) : 0;
    //     let borderRight: number = (computedStyle.borderRight !== '') ? parseInt(computedStyle.borderRight) : 0;
    //     let borderLeftRight = borderLeft + borderRight
    //     return parentWidth - borderLeftRight;
    // }
    checkSelection(topOptions, bottomOptions) {
        let updateDisabled = { top: true, bottom: true };
        updateDisabled.top = (topOptions.api.getSelectedNodes().length > 0) ? false : true;
        updateDisabled.bottom = (bottomOptions.api.getSelectedNodes().length > 0) ? false : true;
        return updateDisabled;
    }
    checkOverlay(topOptions, bottomOptions) {
        let topOverlay = (topOptions.api.getModel().getRowCount() > 0) ? false : true;
        let bottomOverlay = (bottomOptions.api.getModel().getRowCount() > 0) ? false : true;
        if (topOverlay)
            topOptions.api.showNoRowsOverlay();
        else
            topOptions.api.hideOverlay();
        if (bottomOverlay)
            bottomOptions.api.showNoRowsOverlay();
        else
            bottomOptions.api.hideOverlay();
    }
    // setRtlView(_gridOptions: GridOptions): void {
    //     let colDefLength: number = _gridOptions.columnDefs.length;
    //     for (let i: number = 0; i < colDefLength; i++) {
    //         _gridOptions.columnApi.moveColumn(0, colDefLength - (i + 1));
    //     }
    //     // _gridOptions.api.setColumnDefs(_gridOptions.columnDefs);
    //     _gridOptions.api.refreshView();
    // }
    setCheckboxFalseAfterUpdate(vcr) {
        let selectAllCheckbox = vcr.element.nativeElement.querySelectorAll('.selection-wrapper input.select-all');
        for (let i = 0; i < selectAllCheckbox.length; i++) {
            selectAllCheckbox[i].checked = false;
        }
    }
    setCheckboxFalse(removedElement) {
        for (let i = 0; i < removedElement.length; i++) {
            removedElement[i].checked = false;
        }
    }
    _getGridHeight(dataCount, grid) {
        let floatingHeight = 38;
        let headerHeight = (grid === 'top') ? 38 : 0;
        let dataHeight = 38 * dataCount;
        return (floatingHeight + headerHeight + dataHeight + 8);
        /*   height calculation based on vcr
            let totalHeight: number = 0;
            let queryEleString: string = '#' + grid;
            let nativeEle: Element = vcr.element.nativeElement.querySelector(queryEleString);
            console.log(nativeEle);
            totalHeight += Math.ceil(nativeEle.querySelector('.ag-header-container').getBoundingClientRect().height);
            totalHeight += Math.ceil(nativeEle.querySelector('.ag-body-container').getBoundingClientRect().height);
            totalHeight += Math.ceil(nativeEle.querySelector('.ag-floating-top-full-width-container').getBoundingClientRect().height);
            let paginationBottom: Element = nativeEle.querySelector('#south')
            if(paginationBottom !== null) {
                totalHeight += Math.ceil(paginationBottom.getBoundingClientRect().height);
            }

            totalHeight += 8;
            return totalHeight;
            */
    }
    _getGridOptions(grid, rowData) {
        let options = {
            // rowData: [],
            rowData: rowData,
            columnDefs: [],
            // debug: true,
            headerHeight: (grid === 'slave') ? 0 : 38,
            rowHeight: 38,
            suppressContextMenu: true,
            // suppressMenuMainPanel: true,
            // suppressMenuColumnPanel: true,
            // suppressMenuFilterPanel: true,
            suppressMovableColumns: true,
            suppressMenuHide: true,
            suppressColumnVirtualisation: true,
            enableFilter: true,
            enableSorting: true,
            enableColResize: false,
            unSortIcon: true,
            icons: {
                // use font awesome for menu icons
                // menu: '<i class='fa fa-bars'/>',
                filter: '<i class="fa fa-filter"/>',
                sortAscending: '<i class="fa fa-caret-down"/>',
                sortDescending: '<i class="fa fa-caret-up"/>',
                sortUnSort: '<i class="fa fa-sort"/>',
                groupExpanded: '<i class="fa fa-minus-circle"/>',
                groupContracted: '<i class="fa fa-plus-circle"/>'
            },
            // onGridSizeChanged: function(e) {
            //     this.api.sizeColumnsToFit();
            // },
            getRowClass: function (params) {
                if (params.data.hasOwnProperty('newRow')) {
                    delete params.data.newRow;
                    return 'new-row-highlight';
                }
                return;
            },
            alignedGrids: [],
            overlayNoRowsTemplate: '<span class="ag-custom-overlay"><i class="fa fa-info-circle fa-lg margin-right10"></i>No student record found</span>'
        };
        return options;
    }
}
KdMultiSelectTableSvc.decorators = [
    { type: Injectable }
];
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoia2QtbXVsdGlzZWxlY3QtdGFibGUtc3ZjLmpzIiwic291cmNlUm9vdCI6IkM6L3hhbXBwL2h0ZG9jcy9TdHlsZWd1aWRlL2lvc3RnLW9wZW5lbWlzLXN0eWxlZ3VpZGUvcHJvamVjdHMvb3BlbmVtaXMtc3R5bGVndWlkZS1saWIvc3JjLyIsInNvdXJjZXMiOlsia2QtY29tcG9uZW50cy9rZC1hbmd1bGFyLW11bHRpc2VsZWN0LXRhYmxlL2tkLW11bHRpc2VsZWN0LXRhYmxlLXN2Yy50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQSxPQUFPLEVBQUUsVUFBVSxFQUFvQixNQUFNLGVBQWUsQ0FBQztBQUk3RCxNQUFNLE9BQU8scUJBQXFCO0lBQzlCLGNBQWMsQ0FBQyxPQUFZLEVBQUUsV0FBdUIsRUFBRSxVQUFzQjtRQUN4RSwrRkFBK0Y7UUFDL0YsNEZBQTRGO1FBQzVGLHdCQUF3QjtRQUN4Qiw0QkFBNEI7UUFDNUIsMkJBQTJCO1FBRTNCLElBQUksY0FBYyxHQUFRO1lBQ3RCLGdCQUFnQixFQUFFLElBQUksQ0FBQyxlQUFlLENBQUMsUUFBUSxFQUFFLFdBQVcsQ0FBQztZQUM3RCxlQUFlLEVBQUUsSUFBSSxDQUFDLGVBQWUsQ0FBQyxPQUFPLEVBQUUsVUFBVSxDQUFDO1NBQzdELENBQUM7UUFFRixPQUFPLGNBQWMsQ0FBQztJQUMxQixDQUFDO0lBRUQsYUFBYSxDQUFDLE1BQVc7UUFDckIsMEVBQTBFO1FBQzFFLElBQUksT0FBTyxNQUFNLENBQUMsTUFBTSxLQUFLLFdBQVcsRUFBRTtZQUN0QyxLQUFLLElBQUksQ0FBQyxJQUFJLE1BQU0sQ0FBQyxNQUFNLEVBQUU7Z0JBQ3pCLElBQUksTUFBTSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxVQUFVLEVBQUU7b0JBQzdCLE9BQU8sQ0FBQyxDQUFDO2lCQUNaO2FBQ0o7WUFDRCxPQUFPLElBQUksQ0FBQztTQUNmO0lBQ0wsQ0FBQztJQUVELFVBQVUsQ0FBQyxPQUFZO1FBQ25CLElBQUksYUFBYSxHQUFlLEVBQUUsQ0FBQztRQUNuQyxLQUFLLElBQUksQ0FBQyxJQUFJLE9BQU8sRUFBRTtZQUNuQixJQUFJLE9BQU8sT0FBTyxDQUFDLENBQUMsQ0FBQyxLQUFLLFdBQVcsRUFBRTtnQkFDbkMsSUFBSSxXQUFXLEdBQVE7b0JBQ25CLFVBQVUsRUFBRSxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsVUFBVTtvQkFDakMsS0FBSyxFQUFFLENBQUM7b0JBQ1IsS0FBSyxFQUFFLENBQUM7b0JBQ1IsU0FBUyxFQUFFLFlBQVk7b0JBQ3ZCLFFBQVEsRUFBRSxFQUFFO2lCQUNmLENBQUM7Z0JBRUYsYUFBYSxDQUFDLElBQUksQ0FBQyxXQUFXLENBQUMsQ0FBQzthQUNuQztTQUNKO1FBQ0QsT0FBTyxhQUFhLENBQUM7SUFDekIsQ0FBQztJQUVELGNBQWMsQ0FBQyxNQUFXLEVBQUUsSUFBWTtRQUNwQywrQkFBK0I7UUFDL0IsSUFBSSxLQUFLLEdBQUcsSUFBSSxHQUFHLGFBQWEsQ0FBQztRQUNqQyxJQUFJLE9BQU8sTUFBTSxDQUFDLFdBQVcsS0FBSyxXQUFXLElBQUksT0FBTyxNQUFNLENBQUMsV0FBVyxDQUFDLEtBQUssQ0FBQyxLQUFLLFdBQVc7WUFBRSxPQUFPLE1BQU0sQ0FBQyxXQUFXLENBQUMsS0FBSyxDQUFDLENBQUM7UUFDcEksT0FBTyxXQUFXLENBQUM7SUFDdkIsQ0FBQztJQUVELFNBQVMsQ0FBQyxNQUFXLEVBQUUsSUFBUztRQUM1Qix5Q0FBeUM7UUFDekMsSUFBSSxVQUFVLEdBQVEsRUFBRSxDQUFDO1FBRXpCLElBQUksT0FBTyxNQUFNLENBQUMsV0FBVyxLQUFLLFdBQVcsSUFBSSxPQUFPLE1BQU0sQ0FBQyxXQUFXLENBQUMsSUFBSSxDQUFDLENBQUMsSUFBSSxLQUFLLFdBQVc7WUFBRSxVQUFVLENBQUMsSUFBSSxHQUFHLE1BQU0sQ0FBQyxXQUFXLENBQUMsSUFBSSxDQUFDLENBQUMsSUFBSSxDQUFDOztZQUNsSixVQUFVLENBQUMsSUFBSSxHQUFHLEVBQUUsQ0FBQztRQUUxQixJQUFJLE9BQU8sTUFBTSxDQUFDLFdBQVcsQ0FBQyxJQUFJLENBQUMsS0FBSyxXQUFXLElBQUksT0FBTyxNQUFNLENBQUMsV0FBVyxDQUFDLElBQUksQ0FBQyxDQUFDLElBQUksS0FBSyxXQUFXO1lBQUUsVUFBVSxDQUFDLElBQUksR0FBRyxNQUFNLENBQUMsV0FBVyxDQUFDLElBQUksQ0FBQyxDQUFDLElBQUksQ0FBQzs7WUFDeEosVUFBVSxDQUFDLElBQUksR0FBRyxXQUFXLENBQUM7UUFFbkMsT0FBTyxVQUFVLENBQUM7SUFDdEIsQ0FBQztJQUVELGtCQUFrQjtRQUNkLE9BQU87WUFDSCxLQUFLLEVBQUUsRUFBRTtZQUNULFFBQVEsRUFBRSxFQUFFO1lBQ1osUUFBUSxFQUFFLEVBQUU7WUFDWixLQUFLLEVBQUUsVUFBVTtZQUNqQixVQUFVLEVBQUUsRUFBRTtZQUNkLFlBQVksRUFBRSxJQUFJO1lBQ2xCLGVBQWUsRUFBRSxJQUFJO1lBQ3JCLGlCQUFpQixFQUFFLElBQUk7WUFDdkIsU0FBUyxFQUFFLG1CQUFtQjtTQUNqQyxDQUFDO0lBQ04sQ0FBQztJQUVELGdCQUFnQixDQUFDLFVBQXVCLEVBQUUsU0FBc0IsRUFBRSxHQUFxQjtRQUNuRixJQUFJLE9BQU8sR0FBVyxVQUFVLENBQUMsR0FBRyxDQUFDLFFBQVEsRUFBRSxDQUFDLFdBQVcsRUFBRSxDQUFDO1FBQzlELElBQUksVUFBVSxHQUFXLFNBQVMsQ0FBQyxHQUFHLENBQUMsUUFBUSxFQUFFLENBQUMsV0FBVyxFQUFFLENBQUM7UUFDaEUsSUFBSSxTQUFTLEdBQUcsQ0FBQyxPQUFPLE9BQU8sS0FBSyxXQUFXLElBQUksT0FBTyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsY0FBYyxDQUFDLE9BQU8sRUFBRSxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDO1FBQzVHLElBQUksWUFBWSxHQUFHLENBQUMsT0FBTyxVQUFVLEtBQUssV0FBVyxJQUFJLFVBQVUsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLGNBQWMsQ0FBQyxVQUFVLEVBQUUsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQztRQUMzSCxJQUFJLE1BQU0sR0FBUTtZQUNkLEdBQUcsRUFBRSxTQUFTO1lBQ2QsTUFBTSxFQUFFLFlBQVk7U0FDdkIsQ0FBQztRQUNGLE9BQU8sTUFBTSxDQUFDO0lBQ2xCLENBQUM7SUFFRCxhQUFhLENBQUMsTUFBYztRQUN4QixJQUFJLFNBQVMsR0FBVyxFQUFFLENBQUM7UUFDM0IsSUFBSSxhQUFhLEdBQVcsQ0FBQyxDQUFDLE9BQU8sTUFBTSxLQUFLLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxHQUFHLFNBQVMsQ0FBQztRQUN0RixJQUFJLFlBQVksR0FBVyxDQUFDLGFBQWEsR0FBRyxFQUFFLENBQUMsR0FBRyxDQUFDLENBQUM7UUFDcEQsSUFBSSxTQUFTLEdBQVE7WUFDakIsR0FBRyxFQUFFLFlBQVksR0FBRyxFQUFFO1lBQ3RCLE1BQU0sRUFBRSxZQUFZO1NBQ3ZCLENBQUM7UUFFRixPQUFPLFNBQVMsQ0FBQztJQUNyQixDQUFDO0lBRUQsMERBQTBEO0lBQzFELDBFQUEwRTtJQUMxRSx3Q0FBd0M7SUFDeEMsc0RBQXNEO0lBQ3RELG9EQUFvRDtJQUNwRCw4REFBOEQ7SUFDOUQsWUFBWTtJQUNaLGdCQUFnQjtJQUNoQixpQ0FBaUM7SUFDakMsWUFBWTtJQUNaLFFBQVE7SUFFUixnQ0FBZ0M7SUFDaEMsdUJBQXVCO0lBQ3ZCLElBQUk7SUFFSix1REFBdUQ7SUFDdkQsNkJBQTZCO0lBRTdCLDJEQUEyRDtJQUMzRCxpQ0FBaUM7SUFDakMsUUFBUTtJQUVSLG9CQUFvQjtJQUNwQixJQUFJO0lBRUosbURBQW1EO0lBQ25ELDJGQUEyRjtJQUMzRixxRkFBcUY7SUFDckYsbUZBQW1GO0lBQ25GLDJHQUEyRztJQUMzRyw4R0FBOEc7SUFDOUcscURBQXFEO0lBQ3JELDRDQUE0QztJQUM1QyxJQUFJO0lBRUosY0FBYyxDQUFDLFVBQXVCLEVBQUUsYUFBMEI7UUFDOUQsSUFBSSxjQUFjLEdBQVEsRUFBRSxHQUFHLEVBQUUsSUFBSSxFQUFFLE1BQU0sRUFBRSxJQUFJLEVBQUUsQ0FBQztRQUV0RCxjQUFjLENBQUMsR0FBRyxHQUFHLENBQUMsVUFBVSxDQUFDLEdBQUcsQ0FBQyxnQkFBZ0IsRUFBRSxDQUFDLE1BQU0sR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUM7UUFDbkYsY0FBYyxDQUFDLE1BQU0sR0FBRyxDQUFDLGFBQWEsQ0FBQyxHQUFHLENBQUMsZ0JBQWdCLEVBQUUsQ0FBQyxNQUFNLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDO1FBRXpGLE9BQU8sY0FBYyxDQUFDO0lBQzFCLENBQUM7SUFFRCxZQUFZLENBQUMsVUFBdUIsRUFBRSxhQUEwQjtRQUM1RCxJQUFJLFVBQVUsR0FBWSxDQUFDLFVBQVUsQ0FBQyxHQUFHLENBQUMsUUFBUSxFQUFFLENBQUMsV0FBVyxFQUFFLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDO1FBQ3ZGLElBQUksYUFBYSxHQUFZLENBQUMsYUFBYSxDQUFDLEdBQUcsQ0FBQyxRQUFRLEVBQUUsQ0FBQyxXQUFXLEVBQUUsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUM7UUFFN0YsSUFBSSxVQUFVO1lBQUUsVUFBVSxDQUFDLEdBQUcsQ0FBQyxpQkFBaUIsRUFBRSxDQUFDOztZQUM5QyxVQUFVLENBQUMsR0FBRyxDQUFDLFdBQVcsRUFBRSxDQUFDO1FBQ2xDLElBQUksYUFBYTtZQUFFLGFBQWEsQ0FBQyxHQUFHLENBQUMsaUJBQWlCLEVBQUUsQ0FBQzs7WUFDcEQsYUFBYSxDQUFDLEdBQUcsQ0FBQyxXQUFXLEVBQUUsQ0FBQztJQUN6QyxDQUFDO0lBRUQsZ0RBQWdEO0lBQ2hELGlFQUFpRTtJQUNqRSx1REFBdUQ7SUFDdkQsd0VBQXdFO0lBQ3hFLFFBQVE7SUFDUixrRUFBa0U7SUFDbEUsc0NBQXNDO0lBQ3RDLElBQUk7SUFFSiwyQkFBMkIsQ0FBQyxHQUFxQjtRQUM3QyxJQUFJLGlCQUFpQixHQUFlLEdBQUcsQ0FBQyxPQUFPLENBQUMsYUFBYSxDQUFDLGdCQUFnQixDQUFDLHFDQUFxQyxDQUFDLENBQUM7UUFDdEgsS0FBSyxJQUFJLENBQUMsR0FBVyxDQUFDLEVBQUUsQ0FBQyxHQUFHLGlCQUFpQixDQUFDLE1BQU0sRUFBRSxDQUFDLEVBQUUsRUFBRTtZQUN2RCxpQkFBaUIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPLEdBQUcsS0FBSyxDQUFDO1NBQ3hDO0lBQ0wsQ0FBQztJQUVELGdCQUFnQixDQUFDLGNBQXVDO1FBQ3BELEtBQUssSUFBSSxDQUFDLEdBQVcsQ0FBQyxFQUFFLENBQUMsR0FBRyxjQUFjLENBQUMsTUFBTSxFQUFFLENBQUMsRUFBRSxFQUFFO1lBQ3BELGNBQWMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPLEdBQUcsS0FBSyxDQUFDO1NBQ3JDO0lBQ0wsQ0FBQztJQUVPLGNBQWMsQ0FBQyxTQUFpQixFQUFFLElBQVk7UUFDbEQsSUFBSSxjQUFjLEdBQUcsRUFBRSxDQUFDO1FBQ3hCLElBQUksWUFBWSxHQUFHLENBQUMsSUFBSSxLQUFLLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztRQUM3QyxJQUFJLFVBQVUsR0FBRyxFQUFFLEdBQUcsU0FBUyxDQUFDO1FBRWhDLE9BQU8sQ0FBQyxjQUFjLEdBQUcsWUFBWSxHQUFHLFVBQVUsR0FBRyxDQUFDLENBQUMsQ0FBQztRQUV4RDs7Ozs7Ozs7Ozs7Ozs7O2NBZU07SUFDVixDQUFDO0lBRU8sZUFBZSxDQUFDLElBQVksRUFBRSxPQUFtQjtRQUNyRCxJQUFJLE9BQU8sR0FBUTtZQUNmLGVBQWU7WUFDZixPQUFPLEVBQUUsT0FBTztZQUNoQixVQUFVLEVBQUUsRUFBRTtZQUNkLGVBQWU7WUFFZixZQUFZLEVBQUUsQ0FBQyxJQUFJLEtBQUssT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRTtZQUN6QyxTQUFTLEVBQUUsRUFBRTtZQUViLG1CQUFtQixFQUFFLElBQUk7WUFDekIsK0JBQStCO1lBQy9CLGlDQUFpQztZQUNqQyxpQ0FBaUM7WUFDakMsc0JBQXNCLEVBQUUsSUFBSTtZQUM1QixnQkFBZ0IsRUFBRSxJQUFJO1lBQ3RCLDRCQUE0QixFQUFFLElBQUk7WUFDbEMsWUFBWSxFQUFFLElBQUk7WUFDbEIsYUFBYSxFQUFFLElBQUk7WUFDbkIsZUFBZSxFQUFFLEtBQUs7WUFFdEIsVUFBVSxFQUFFLElBQUk7WUFDaEIsS0FBSyxFQUFFO2dCQUNILGtDQUFrQztnQkFDbEMsbUNBQW1DO2dCQUNuQyxNQUFNLEVBQUUsMkJBQTJCO2dCQUNuQyxhQUFhLEVBQUUsK0JBQStCO2dCQUM5QyxjQUFjLEVBQUUsNkJBQTZCO2dCQUM3QyxVQUFVLEVBQUUseUJBQXlCO2dCQUNyQyxhQUFhLEVBQUUsaUNBQWlDO2dCQUNoRCxlQUFlLEVBQUUsZ0NBQWdDO2FBQ3BEO1lBQ0QsbUNBQW1DO1lBQ25DLG1DQUFtQztZQUNuQyxLQUFLO1lBQ0wsV0FBVyxFQUFFLFVBQVMsTUFBZTtnQkFDakMsSUFBSSxNQUFNLENBQUMsSUFBSSxDQUFDLGNBQWMsQ0FBQyxRQUFRLENBQUMsRUFBRTtvQkFDdEMsT0FBTyxNQUFNLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQztvQkFDMUIsT0FBTyxtQkFBbUIsQ0FBQztpQkFDOUI7Z0JBQ0QsT0FBTztZQUNYLENBQUM7WUFDRCxZQUFZLEVBQUUsRUFBRTtZQUNoQixxQkFBcUIsRUFBRSxzSEFBc0g7U0FDaEosQ0FBQztRQUdGLE9BQU8sT0FBTyxDQUFDO0lBQ25CLENBQUM7OztZQS9QSixVQUFVIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgSW5qZWN0YWJsZSwgVmlld0NvbnRhaW5lclJlZiB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xyXG5pbXBvcnQgeyBSb3dOb2RlLCBHcmlkT3B0aW9ucyB9IGZyb20gJ2FnLWdyaWQtY29tbXVuaXR5JztcclxuXHJcbkBJbmplY3RhYmxlKClcclxuZXhwb3J0IGNsYXNzIEtkTXVsdGlTZWxlY3RUYWJsZVN2YyB7XHJcbiAgICBnZXRCb3RoT3B0aW9ucyhfY29uZmlnOiBhbnksIF9tYXN0ZXJEYXRhOiBBcnJheTxhbnk+LCBfc2xhdmVEYXRhOiBBcnJheTxhbnk+KTogYW55IHtcclxuICAgICAgICAvLyBsZXQgbWFzdGVyRGF0YSA9ICh0eXBlb2YgY29uZmlnLm1hc3RlckRhdGEgIT0gXCJ1bmRlZmluZWRcIikgPyBjb25maWcubWFzdGVyRGF0YS5zbGljZSgpIDogW107XHJcbiAgICAgICAgLy8gbGV0IHNsYXZlRGF0YSA9ICh0eXBlb2YgY29uZmlnLnNsYXZlRGF0YSAhPSBcInVuZGVmaW5lZFwiKSA/IGNvbmZpZy5zbGF2ZURhdGEuc2xpY2UoKSA6IFtdO1xyXG4gICAgICAgIC8vIGNvbnNvbGUubG9nKF9jb25maWcpO1xyXG4gICAgICAgIC8vIGNvbnNvbGUubG9nKF9tYXN0ZXJEYXRhKTtcclxuICAgICAgICAvLyBjb25zb2xlLmxvZyhfc2xhdmVEYXRhKTtcclxuXHJcbiAgICAgICAgbGV0IHVwZGF0ZWRPcHRpb25zOiBhbnkgPSB7XHJcbiAgICAgICAgICAgIG1hc3RlckdyaWRPcHRpb246IHRoaXMuX2dldEdyaWRPcHRpb25zKCdtYXN0ZXInLCBfbWFzdGVyRGF0YSksXHJcbiAgICAgICAgICAgIHNsYXZlR3JpZE9wdGlvbjogdGhpcy5fZ2V0R3JpZE9wdGlvbnMoJ3NsYXZlJywgX3NsYXZlRGF0YSlcclxuICAgICAgICB9O1xyXG5cclxuICAgICAgICByZXR1cm4gdXBkYXRlZE9wdGlvbnM7XHJcbiAgICB9XHJcblxyXG4gICAgZ2V0UHJpbWFyeWtleShjb25maWc6IGFueSk6IGFueSB7XHJcbiAgICAgICAgLy8gaWYgdXNlciBzZXQgbW9yZSB0aGFuIG9uZSBwcmltYXJ5IGtleSwgb25seSB0aGUgZmlyc3Qgb25lIHdpbGwgYmUgdXNlZC5cclxuICAgICAgICBpZiAodHlwZW9mIGNvbmZpZy5jb2xEZWYgIT09ICd1bmRlZmluZWQnKSB7XHJcbiAgICAgICAgICAgIGZvciAobGV0IGkgaW4gY29uZmlnLmNvbERlZikge1xyXG4gICAgICAgICAgICAgICAgaWYgKGNvbmZpZy5jb2xEZWZbaV0ucHJpbWFyeUtleSkge1xyXG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBpO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIHJldHVybiAnaWQnO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICBnZXRDb2xEZWZzKF9jb2xEZWY6IGFueSk6IEFycmF5PGFueT4ge1xyXG4gICAgICAgIGxldCB1cGRhdGVkQ29sRGVmOiBBcnJheTxhbnk+ID0gW107XHJcbiAgICAgICAgZm9yIChsZXQgaSBpbiBfY29sRGVmKSB7XHJcbiAgICAgICAgICAgIGlmICh0eXBlb2YgX2NvbERlZltpXSAhPT0gJ3VuZGVmaW5lZCcpIHtcclxuICAgICAgICAgICAgICAgIGxldCB0YWJsZUNvbHVtbjogYW55ID0ge1xyXG4gICAgICAgICAgICAgICAgICAgIGhlYWRlck5hbWU6IF9jb2xEZWZbaV0uaGVhZGVyTmFtZSxcclxuICAgICAgICAgICAgICAgICAgICBmaWVsZDogaSxcclxuICAgICAgICAgICAgICAgICAgICBjb2xJZDogaSxcclxuICAgICAgICAgICAgICAgICAgICBjZWxsQ2xhc3M6ICdhZy1kZWZhdWx0JyxcclxuICAgICAgICAgICAgICAgICAgICBtZW51VGFiczogW11cclxuICAgICAgICAgICAgICAgIH07XHJcblxyXG4gICAgICAgICAgICAgICAgdXBkYXRlZENvbERlZi5wdXNoKHRhYmxlQ29sdW1uKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgICAgICByZXR1cm4gdXBkYXRlZENvbERlZjtcclxuICAgIH1cclxuXHJcbiAgICBnZXRQbGFjZWhvbGRlcihjb25maWc6IGFueSwgZ3JpZDogc3RyaW5nKTogc3RyaW5nIHtcclxuICAgICAgICAvLyBncmlkIGlzIGVpdGhlciB0b3Agb3IgYm90dG9tXHJcbiAgICAgICAgbGV0IHF1ZXJ5ID0gZ3JpZCArICdQbGFjZWhvbGRlcic7XHJcbiAgICAgICAgaWYgKHR5cGVvZiBjb25maWcuZ3JpZFNldHRpbmcgIT09ICd1bmRlZmluZWQnICYmIHR5cGVvZiBjb25maWcuZ3JpZFNldHRpbmdbcXVlcnldICE9PSAndW5kZWZpbmVkJykgcmV0dXJuIGNvbmZpZy5ncmlkU2V0dGluZ1txdWVyeV07XHJcbiAgICAgICAgcmV0dXJuICdVbmRlZmluZWQnO1xyXG4gICAgfVxyXG5cclxuICAgIGdldEJ1dHRvbihjb25maWc6IGFueSwgZ3JpZDogYW55KTogYW55IHtcclxuICAgICAgICAvLyBncmlkIGlzIGVpdGhlciB0b1RvcEJ0biBvciB0b0JvdHRvbUJ0blxyXG4gICAgICAgIGxldCB1cGRhdGVkQnRuOiBhbnkgPSB7fTtcclxuXHJcbiAgICAgICAgaWYgKHR5cGVvZiBjb25maWcuZ3JpZFNldHRpbmcgIT09ICd1bmRlZmluZWQnICYmIHR5cGVvZiBjb25maWcuZ3JpZFNldHRpbmdbZ3JpZF0uaWNvbiAhPT0gJ3VuZGVmaW5lZCcpIHVwZGF0ZWRCdG4uaWNvbiA9IGNvbmZpZy5ncmlkU2V0dGluZ1tncmlkXS5pY29uO1xyXG4gICAgICAgIGVsc2UgdXBkYXRlZEJ0bi5pY29uID0gJyc7XHJcblxyXG4gICAgICAgIGlmICh0eXBlb2YgY29uZmlnLmdyaWRTZXR0aW5nW2dyaWRdICE9PSAndW5kZWZpbmVkJyAmJiB0eXBlb2YgY29uZmlnLmdyaWRTZXR0aW5nW2dyaWRdLnRleHQgIT09ICd1bmRlZmluZWQnKSB1cGRhdGVkQnRuLnRleHQgPSBjb25maWcuZ3JpZFNldHRpbmdbZ3JpZF0udGV4dDtcclxuICAgICAgICBlbHNlIHVwZGF0ZWRCdG4udGV4dCA9ICdVbmRlZmluZWQnO1xyXG5cclxuICAgICAgICByZXR1cm4gdXBkYXRlZEJ0bjtcclxuICAgIH1cclxuXHJcbiAgICBnZXRDaGVja2JveERlZmF1bHQoKTogYW55IHtcclxuICAgICAgICByZXR1cm4ge1xyXG4gICAgICAgICAgICB3aWR0aDogNTAsXHJcbiAgICAgICAgICAgIG1pbldpZHRoOiA1MCxcclxuICAgICAgICAgICAgbWF4V2lkdGg6IDUwLFxyXG4gICAgICAgICAgICBjb2xJZDogJ2NoZWNrYm94JyxcclxuICAgICAgICAgICAgaGVhZGVyTmFtZTogJycsXHJcbiAgICAgICAgICAgIHN1cHByZXNzTWVudTogdHJ1ZSxcclxuICAgICAgICAgICAgc3VwcHJlc3NTb3J0aW5nOiB0cnVlLFxyXG4gICAgICAgICAgICBzdXBwcmVzc1NpemVUb0ZpdDogdHJ1ZSxcclxuICAgICAgICAgICAgY2VsbENsYXNzOiAnYWctY2hlY2tib3gtcmFkaW8nXHJcbiAgICAgICAgfTtcclxuICAgIH1cclxuXHJcbiAgICBjYWxjTW9iaWxlSGVpZ2h0KG1hc3RlckdyaWQ6IEdyaWRPcHRpb25zLCBzbGF2ZUdyaWQ6IEdyaWRPcHRpb25zLCB2Y3I6IFZpZXdDb250YWluZXJSZWYpOiBhbnkge1xyXG4gICAgICAgIGxldCB0b3BEYXRhOiBudW1iZXIgPSBtYXN0ZXJHcmlkLmFwaS5nZXRNb2RlbCgpLmdldFJvd0NvdW50KCk7XHJcbiAgICAgICAgbGV0IGJvdHRvbURhdGE6IG51bWJlciA9IHNsYXZlR3JpZC5hcGkuZ2V0TW9kZWwoKS5nZXRSb3dDb3VudCgpO1xyXG4gICAgICAgIGxldCB0b3BIZWlnaHQgPSAodHlwZW9mIHRvcERhdGEgIT09ICd1bmRlZmluZWQnICYmIHRvcERhdGEgPiAwKSA/IHRoaXMuX2dldEdyaWRIZWlnaHQodG9wRGF0YSwgJ3RvcCcpIDogMTUwO1xyXG4gICAgICAgIGxldCBib3R0b21IZWlnaHQgPSAodHlwZW9mIGJvdHRvbURhdGEgIT09ICd1bmRlZmluZWQnICYmIGJvdHRvbURhdGEgPiAwKSA/IHRoaXMuX2dldEdyaWRIZWlnaHQoYm90dG9tRGF0YSwgJ2JvdHRvbScpIDogMTUwO1xyXG4gICAgICAgIGxldCByZXN1bHQ6IGFueSA9IHtcclxuICAgICAgICAgICAgdG9wOiB0b3BIZWlnaHQsXHJcbiAgICAgICAgICAgIGJvdHRvbTogYm90dG9tSGVpZ2h0XHJcbiAgICAgICAgfTtcclxuICAgICAgICByZXR1cm4gcmVzdWx0O1xyXG4gICAgfVxyXG5cclxuICAgIGNhbGNXZWJIZWlnaHQoaGVpZ2h0OiBudW1iZXIpOiBhbnkge1xyXG4gICAgICAgIGxldCBzZXBhcmF0b3I6IG51bWJlciA9IDY1O1xyXG4gICAgICAgIGxldCBjaGVja2VkSGVpZ2h0OiBudW1iZXIgPSAoKHR5cGVvZiBoZWlnaHQgIT09ICdudW1iZXInKSA/IDYwMCA6IGhlaWdodCkgLSBzZXBhcmF0b3I7XHJcbiAgICAgICAgbGV0IGJvdHRvbUhlaWdodDogbnVtYmVyID0gKGNoZWNrZWRIZWlnaHQgLSAzOCkgLyAyO1xyXG4gICAgICAgIGxldCB3ZWJIZWlnaHQ6IGFueSA9IHtcclxuICAgICAgICAgICAgdG9wOiBib3R0b21IZWlnaHQgKyAzOCxcclxuICAgICAgICAgICAgYm90dG9tOiBib3R0b21IZWlnaHRcclxuICAgICAgICB9O1xyXG5cclxuICAgICAgICByZXR1cm4gd2ViSGVpZ2h0O1xyXG4gICAgfVxyXG5cclxuICAgIC8vIGdldENvbERlZldpZHRoKF9ncmlkT3B0aW9uczogR3JpZE9wdGlvbnMpOiBBcnJheTxhbnk+IHtcclxuICAgIC8vICAgICBsZXQgY29sdW1uOiBBcnJheTxDb2x1bW4+ID0gX2dyaWRPcHRpb25zLmNvbHVtbkFwaS5nZXRBbGxDb2x1bW5zKCk7XHJcbiAgICAvLyAgICAgbGV0IGNvbFdpZHRoOiBBcnJheTxudW1iZXI+ID0gW107XHJcbiAgICAvLyAgICAgZm9yKGxldCBpOiBudW1iZXIgPSAwOyBpIDwgY29sdW1uLmxlbmd0aDsgaSsrKXtcclxuICAgIC8vICAgICAgICAgaWYoY29sdW1uW2ldLmdldENvbElkKCkgIT09ICdjaGVja2JveCcpIHtcclxuICAgIC8vICAgICAgICAgICAgIGNvbFdpZHRoLnB1c2goY29sdW1uW2ldLmdldEFjdHVhbFdpZHRoKCkgKyAzMCk7XHJcbiAgICAvLyAgICAgICAgIH1cclxuICAgIC8vICAgICAgICAgZWxzZXtcclxuICAgIC8vICAgICAgICAgICAgIGNvbFdpZHRoLnB1c2goNTApO1xyXG4gICAgLy8gICAgICAgICB9XHJcbiAgICAvLyAgICAgfVxyXG5cclxuICAgIC8vICAgICAvLyBjb25zb2xlLmxvZyhjb2xXaWR0aCk7XHJcbiAgICAvLyAgICAgcmV0dXJuIGNvbFdpZHRoO1xyXG4gICAgLy8gfVxyXG5cclxuICAgIC8vIGdldENvbFRvdGFsV2lkdGgoX2NvbEFycmF5OiBBcnJheTxudW1iZXI+KTogbnVtYmVyIHtcclxuICAgIC8vICAgICBsZXQgdG90YWw6IG51bWJlciA9IDA7XHJcblxyXG4gICAgLy8gICAgIGZvciAobGV0IGk6IG51bWJlciA9IDA7IGkgPCBfY29sQXJyYXkubGVuZ3RoOyBpKyspIHtcclxuICAgIC8vICAgICAgICAgdG90YWwgKz0gX2NvbEFycmF5W2ldO1xyXG4gICAgLy8gICAgIH1cclxuXHJcbiAgICAvLyAgICAgcmV0dXJuIHRvdGFsO1xyXG4gICAgLy8gfVxyXG5cclxuICAgIC8vIGdldFVzYWJsZVdpZHRoKF92Y3I6IFZpZXdDb250YWluZXJSZWYpOiBudW1iZXIge1xyXG4gICAgLy8gICAgIGxldCBhZ0dyaWRFbGU6IEhUTUxFbGVtZW50ID0gX3Zjci5lbGVtZW50Lm5hdGl2ZUVsZW1lbnQucXVlcnlTZWxlY3RvcignLnN0Zy10aGVtZScpO1xyXG4gICAgLy8gICAgIGxldCBwYXJlbnRXaWR0aDogbnVtYmVyID0gTWF0aC5yb3VuZChhZ0dyaWRFbGUuZ2V0Qm91bmRpbmdDbGllbnRSZWN0KCkud2lkdGgpO1xyXG4gICAgLy8gICAgIGxldCBjb21wdXRlZFN0eWxlOiBDU1NTdHlsZURlY2xhcmF0aW9uID0gd2luZG93LmdldENvbXB1dGVkU3R5bGUoYWdHcmlkRWxlKTtcclxuICAgIC8vICAgICBsZXQgYm9yZGVyTGVmdDogbnVtYmVyID0gKGNvbXB1dGVkU3R5bGUuYm9yZGVyTGVmdCAhPT0gJycpID8gcGFyc2VJbnQoY29tcHV0ZWRTdHlsZS5ib3JkZXJMZWZ0KSA6IDA7XHJcbiAgICAvLyAgICAgbGV0IGJvcmRlclJpZ2h0OiBudW1iZXIgPSAoY29tcHV0ZWRTdHlsZS5ib3JkZXJSaWdodCAhPT0gJycpID8gcGFyc2VJbnQoY29tcHV0ZWRTdHlsZS5ib3JkZXJSaWdodCkgOiAwO1xyXG4gICAgLy8gICAgIGxldCBib3JkZXJMZWZ0UmlnaHQgPSBib3JkZXJMZWZ0ICsgYm9yZGVyUmlnaHRcclxuICAgIC8vICAgICByZXR1cm4gcGFyZW50V2lkdGggLSBib3JkZXJMZWZ0UmlnaHQ7XHJcbiAgICAvLyB9XHJcblxyXG4gICAgY2hlY2tTZWxlY3Rpb24odG9wT3B0aW9uczogR3JpZE9wdGlvbnMsIGJvdHRvbU9wdGlvbnM6IEdyaWRPcHRpb25zKTogYW55IHtcclxuICAgICAgICBsZXQgdXBkYXRlRGlzYWJsZWQ6IGFueSA9IHsgdG9wOiB0cnVlLCBib3R0b206IHRydWUgfTtcclxuXHJcbiAgICAgICAgdXBkYXRlRGlzYWJsZWQudG9wID0gKHRvcE9wdGlvbnMuYXBpLmdldFNlbGVjdGVkTm9kZXMoKS5sZW5ndGggPiAwKSA/IGZhbHNlIDogdHJ1ZTtcclxuICAgICAgICB1cGRhdGVEaXNhYmxlZC5ib3R0b20gPSAoYm90dG9tT3B0aW9ucy5hcGkuZ2V0U2VsZWN0ZWROb2RlcygpLmxlbmd0aCA+IDApID8gZmFsc2UgOiB0cnVlO1xyXG5cclxuICAgICAgICByZXR1cm4gdXBkYXRlRGlzYWJsZWQ7XHJcbiAgICB9XHJcblxyXG4gICAgY2hlY2tPdmVybGF5KHRvcE9wdGlvbnM6IEdyaWRPcHRpb25zLCBib3R0b21PcHRpb25zOiBHcmlkT3B0aW9ucyk6IHZvaWQge1xyXG4gICAgICAgIGxldCB0b3BPdmVybGF5OiBib29sZWFuID0gKHRvcE9wdGlvbnMuYXBpLmdldE1vZGVsKCkuZ2V0Um93Q291bnQoKSA+IDApID8gZmFsc2UgOiB0cnVlO1xyXG4gICAgICAgIGxldCBib3R0b21PdmVybGF5OiBib29sZWFuID0gKGJvdHRvbU9wdGlvbnMuYXBpLmdldE1vZGVsKCkuZ2V0Um93Q291bnQoKSA+IDApID8gZmFsc2UgOiB0cnVlO1xyXG5cclxuICAgICAgICBpZiAodG9wT3ZlcmxheSkgdG9wT3B0aW9ucy5hcGkuc2hvd05vUm93c092ZXJsYXkoKTtcclxuICAgICAgICBlbHNlIHRvcE9wdGlvbnMuYXBpLmhpZGVPdmVybGF5KCk7XHJcbiAgICAgICAgaWYgKGJvdHRvbU92ZXJsYXkpIGJvdHRvbU9wdGlvbnMuYXBpLnNob3dOb1Jvd3NPdmVybGF5KCk7XHJcbiAgICAgICAgZWxzZSBib3R0b21PcHRpb25zLmFwaS5oaWRlT3ZlcmxheSgpO1xyXG4gICAgfVxyXG5cclxuICAgIC8vIHNldFJ0bFZpZXcoX2dyaWRPcHRpb25zOiBHcmlkT3B0aW9ucyk6IHZvaWQge1xyXG4gICAgLy8gICAgIGxldCBjb2xEZWZMZW5ndGg6IG51bWJlciA9IF9ncmlkT3B0aW9ucy5jb2x1bW5EZWZzLmxlbmd0aDtcclxuICAgIC8vICAgICBmb3IgKGxldCBpOiBudW1iZXIgPSAwOyBpIDwgY29sRGVmTGVuZ3RoOyBpKyspIHtcclxuICAgIC8vICAgICAgICAgX2dyaWRPcHRpb25zLmNvbHVtbkFwaS5tb3ZlQ29sdW1uKDAsIGNvbERlZkxlbmd0aCAtIChpICsgMSkpO1xyXG4gICAgLy8gICAgIH1cclxuICAgIC8vICAgICAvLyBfZ3JpZE9wdGlvbnMuYXBpLnNldENvbHVtbkRlZnMoX2dyaWRPcHRpb25zLmNvbHVtbkRlZnMpO1xyXG4gICAgLy8gICAgIF9ncmlkT3B0aW9ucy5hcGkucmVmcmVzaFZpZXcoKTtcclxuICAgIC8vIH1cclxuXHJcbiAgICBzZXRDaGVja2JveEZhbHNlQWZ0ZXJVcGRhdGUodmNyOiBWaWV3Q29udGFpbmVyUmVmKTogdm9pZCB7XHJcbiAgICAgICAgbGV0IHNlbGVjdEFsbENoZWNrYm94OiBBcnJheTxhbnk+ID0gdmNyLmVsZW1lbnQubmF0aXZlRWxlbWVudC5xdWVyeVNlbGVjdG9yQWxsKCcuc2VsZWN0aW9uLXdyYXBwZXIgaW5wdXQuc2VsZWN0LWFsbCcpO1xyXG4gICAgICAgIGZvciAobGV0IGk6IG51bWJlciA9IDA7IGkgPCBzZWxlY3RBbGxDaGVja2JveC5sZW5ndGg7IGkrKykge1xyXG4gICAgICAgICAgICBzZWxlY3RBbGxDaGVja2JveFtpXS5jaGVja2VkID0gZmFsc2U7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIHNldENoZWNrYm94RmFsc2UocmVtb3ZlZEVsZW1lbnQ6IEFycmF5PEhUTUxJbnB1dEVsZW1lbnQ+KTogdm9pZCB7XHJcbiAgICAgICAgZm9yIChsZXQgaTogbnVtYmVyID0gMDsgaSA8IHJlbW92ZWRFbGVtZW50Lmxlbmd0aDsgaSsrKSB7XHJcbiAgICAgICAgICAgIHJlbW92ZWRFbGVtZW50W2ldLmNoZWNrZWQgPSBmYWxzZTtcclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfZ2V0R3JpZEhlaWdodChkYXRhQ291bnQ6IG51bWJlciwgZ3JpZDogc3RyaW5nKTogbnVtYmVyIHtcclxuICAgICAgICBsZXQgZmxvYXRpbmdIZWlnaHQgPSAzODtcclxuICAgICAgICBsZXQgaGVhZGVySGVpZ2h0ID0gKGdyaWQgPT09ICd0b3AnKSA/IDM4IDogMDtcclxuICAgICAgICBsZXQgZGF0YUhlaWdodCA9IDM4ICogZGF0YUNvdW50O1xyXG5cclxuICAgICAgICByZXR1cm4gKGZsb2F0aW5nSGVpZ2h0ICsgaGVhZGVySGVpZ2h0ICsgZGF0YUhlaWdodCArIDgpO1xyXG5cclxuICAgICAgICAvKiAgIGhlaWdodCBjYWxjdWxhdGlvbiBiYXNlZCBvbiB2Y3JcclxuICAgICAgICAgICAgbGV0IHRvdGFsSGVpZ2h0OiBudW1iZXIgPSAwO1xyXG4gICAgICAgICAgICBsZXQgcXVlcnlFbGVTdHJpbmc6IHN0cmluZyA9ICcjJyArIGdyaWQ7XHJcbiAgICAgICAgICAgIGxldCBuYXRpdmVFbGU6IEVsZW1lbnQgPSB2Y3IuZWxlbWVudC5uYXRpdmVFbGVtZW50LnF1ZXJ5U2VsZWN0b3IocXVlcnlFbGVTdHJpbmcpO1xyXG4gICAgICAgICAgICBjb25zb2xlLmxvZyhuYXRpdmVFbGUpO1xyXG4gICAgICAgICAgICB0b3RhbEhlaWdodCArPSBNYXRoLmNlaWwobmF0aXZlRWxlLnF1ZXJ5U2VsZWN0b3IoJy5hZy1oZWFkZXItY29udGFpbmVyJykuZ2V0Qm91bmRpbmdDbGllbnRSZWN0KCkuaGVpZ2h0KTtcclxuICAgICAgICAgICAgdG90YWxIZWlnaHQgKz0gTWF0aC5jZWlsKG5hdGl2ZUVsZS5xdWVyeVNlbGVjdG9yKCcuYWctYm9keS1jb250YWluZXInKS5nZXRCb3VuZGluZ0NsaWVudFJlY3QoKS5oZWlnaHQpO1xyXG4gICAgICAgICAgICB0b3RhbEhlaWdodCArPSBNYXRoLmNlaWwobmF0aXZlRWxlLnF1ZXJ5U2VsZWN0b3IoJy5hZy1mbG9hdGluZy10b3AtZnVsbC13aWR0aC1jb250YWluZXInKS5nZXRCb3VuZGluZ0NsaWVudFJlY3QoKS5oZWlnaHQpO1xyXG4gICAgICAgICAgICBsZXQgcGFnaW5hdGlvbkJvdHRvbTogRWxlbWVudCA9IG5hdGl2ZUVsZS5xdWVyeVNlbGVjdG9yKCcjc291dGgnKVxyXG4gICAgICAgICAgICBpZihwYWdpbmF0aW9uQm90dG9tICE9PSBudWxsKSB7XHJcbiAgICAgICAgICAgICAgICB0b3RhbEhlaWdodCArPSBNYXRoLmNlaWwocGFnaW5hdGlvbkJvdHRvbS5nZXRCb3VuZGluZ0NsaWVudFJlY3QoKS5oZWlnaHQpO1xyXG4gICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICB0b3RhbEhlaWdodCArPSA4O1xyXG4gICAgICAgICAgICByZXR1cm4gdG90YWxIZWlnaHQ7XHJcbiAgICAgICAgICAgICovXHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfZ2V0R3JpZE9wdGlvbnMoZ3JpZDogc3RyaW5nLCByb3dEYXRhOiBBcnJheTxhbnk+KTogYW55IHtcclxuICAgICAgICBsZXQgb3B0aW9uczogYW55ID0ge1xyXG4gICAgICAgICAgICAvLyByb3dEYXRhOiBbXSxcclxuICAgICAgICAgICAgcm93RGF0YTogcm93RGF0YSxcclxuICAgICAgICAgICAgY29sdW1uRGVmczogW10sXHJcbiAgICAgICAgICAgIC8vIGRlYnVnOiB0cnVlLFxyXG5cclxuICAgICAgICAgICAgaGVhZGVySGVpZ2h0OiAoZ3JpZCA9PT0gJ3NsYXZlJykgPyAwIDogMzgsXHJcbiAgICAgICAgICAgIHJvd0hlaWdodDogMzgsXHJcblxyXG4gICAgICAgICAgICBzdXBwcmVzc0NvbnRleHRNZW51OiB0cnVlLFxyXG4gICAgICAgICAgICAvLyBzdXBwcmVzc01lbnVNYWluUGFuZWw6IHRydWUsXHJcbiAgICAgICAgICAgIC8vIHN1cHByZXNzTWVudUNvbHVtblBhbmVsOiB0cnVlLFxyXG4gICAgICAgICAgICAvLyBzdXBwcmVzc01lbnVGaWx0ZXJQYW5lbDogdHJ1ZSxcclxuICAgICAgICAgICAgc3VwcHJlc3NNb3ZhYmxlQ29sdW1uczogdHJ1ZSxcclxuICAgICAgICAgICAgc3VwcHJlc3NNZW51SGlkZTogdHJ1ZSxcclxuICAgICAgICAgICAgc3VwcHJlc3NDb2x1bW5WaXJ0dWFsaXNhdGlvbjogdHJ1ZSxcclxuICAgICAgICAgICAgZW5hYmxlRmlsdGVyOiB0cnVlLFxyXG4gICAgICAgICAgICBlbmFibGVTb3J0aW5nOiB0cnVlLFxyXG4gICAgICAgICAgICBlbmFibGVDb2xSZXNpemU6IGZhbHNlLFxyXG5cclxuICAgICAgICAgICAgdW5Tb3J0SWNvbjogdHJ1ZSxcclxuICAgICAgICAgICAgaWNvbnM6IHtcclxuICAgICAgICAgICAgICAgIC8vIHVzZSBmb250IGF3ZXNvbWUgZm9yIG1lbnUgaWNvbnNcclxuICAgICAgICAgICAgICAgIC8vIG1lbnU6ICc8aSBjbGFzcz0nZmEgZmEtYmFycycvPicsXHJcbiAgICAgICAgICAgICAgICBmaWx0ZXI6ICc8aSBjbGFzcz1cImZhIGZhLWZpbHRlclwiLz4nLFxyXG4gICAgICAgICAgICAgICAgc29ydEFzY2VuZGluZzogJzxpIGNsYXNzPVwiZmEgZmEtY2FyZXQtZG93blwiLz4nLFxyXG4gICAgICAgICAgICAgICAgc29ydERlc2NlbmRpbmc6ICc8aSBjbGFzcz1cImZhIGZhLWNhcmV0LXVwXCIvPicsXHJcbiAgICAgICAgICAgICAgICBzb3J0VW5Tb3J0OiAnPGkgY2xhc3M9XCJmYSBmYS1zb3J0XCIvPicsXHJcbiAgICAgICAgICAgICAgICBncm91cEV4cGFuZGVkOiAnPGkgY2xhc3M9XCJmYSBmYS1taW51cy1jaXJjbGVcIi8+JyxcclxuICAgICAgICAgICAgICAgIGdyb3VwQ29udHJhY3RlZDogJzxpIGNsYXNzPVwiZmEgZmEtcGx1cy1jaXJjbGVcIi8+J1xyXG4gICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAvLyBvbkdyaWRTaXplQ2hhbmdlZDogZnVuY3Rpb24oZSkge1xyXG4gICAgICAgICAgICAvLyAgICAgdGhpcy5hcGkuc2l6ZUNvbHVtbnNUb0ZpdCgpO1xyXG4gICAgICAgICAgICAvLyB9LFxyXG4gICAgICAgICAgICBnZXRSb3dDbGFzczogZnVuY3Rpb24ocGFyYW1zOiBSb3dOb2RlKTogYW55IHtcclxuICAgICAgICAgICAgICAgIGlmIChwYXJhbXMuZGF0YS5oYXNPd25Qcm9wZXJ0eSgnbmV3Um93JykpIHtcclxuICAgICAgICAgICAgICAgICAgICBkZWxldGUgcGFyYW1zLmRhdGEubmV3Um93O1xyXG4gICAgICAgICAgICAgICAgICAgIHJldHVybiAnbmV3LXJvdy1oaWdobGlnaHQnO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgcmV0dXJuO1xyXG4gICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICBhbGlnbmVkR3JpZHM6IFtdLFxyXG4gICAgICAgICAgICBvdmVybGF5Tm9Sb3dzVGVtcGxhdGU6ICc8c3BhbiBjbGFzcz1cImFnLWN1c3RvbS1vdmVybGF5XCI+PGkgY2xhc3M9XCJmYSBmYS1pbmZvLWNpcmNsZSBmYS1sZyBtYXJnaW4tcmlnaHQxMFwiPjwvaT5ObyBzdHVkZW50IHJlY29yZCBmb3VuZDwvc3Bhbj4nXHJcbiAgICAgICAgfTtcclxuXHJcblxyXG4gICAgICAgIHJldHVybiBvcHRpb25zO1xyXG4gICAgfVxyXG59XHJcbiJdfQ==