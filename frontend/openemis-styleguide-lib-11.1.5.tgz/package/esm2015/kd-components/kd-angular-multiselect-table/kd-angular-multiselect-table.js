import { Component, Input, Output, EventEmitter, ViewEncapsulation, ViewContainerRef, HostListener, Renderer2 } from '@angular/core';
import { timer } from 'rxjs';
import 'ag-grid-enterprise';
import { KdDomElemSvc, AG_GRID_KEY } from '../kd-common/index';
import { KdSplitterEvent } from '../kd-angular-splitter/index';
import { KdMultiSelectTableSvc } from './kd-multiselect-table-svc';
import { KdAggridSvc } from '../kd-angular-aggrid/src/kd-angular-aggrid-svc';
import { LicenseManager } from "ag-grid-enterprise";
export class KdMultiSelectTable {
    constructor(_multiTableSvc, _domSvc, _vcr, _renderer, _splitterEvent, _aggridSvc) {
        this._multiTableSvc = _multiTableSvc;
        this._domSvc = _domSvc;
        this._vcr = _vcr;
        this._renderer = _renderer;
        this._splitterEvent = _splitterEvent;
        this._aggridSvc = _aggridSvc;
        this._masterSearch = '';
        this._slaveSearch = '';
        this._disableButton = {};
        this._placeholder = {};
        this._buttons = {};
        this.enterprise = require('ag-grid-enterprise');
        this._masterSelectAll = false;
        this._slaveSelectAll = false;
        this._colDefArrayWidth = [];
        this._firstRun = true;
        this._masterData = [];
        this._slaveData = [];
        this.topBottomData = new EventEmitter();
        LicenseManager.setLicenseKey(AG_GRID_KEY.value);
    }
    onResize(e) {
        this._setView();
    }
    ngOnInit() {
        this._direction = (this._domSvc.getDocumentDirection(true));
        this._masterData = (typeof this.masterData !== 'undefined') ? this.masterData.slice() : [];
        this._slaveData = (typeof this.slaveData !== 'undefined') ? this.slaveData.slice() : [];
        this._setGridOptions();
        this._splitterClickSub = this._splitterEvent.onToggleMenu().subscribe(() => {
            timer(700).subscribe(() => {
                this._setView();
            });
        });
        this._splitterDragSub = this._splitterEvent.onDrag().subscribe(() => {
            timer(200).subscribe(() => {
                this._setView();
            });
        });
        let currentSelection = {};
        this._masterGridOptions.enableRtl = this._direction === 'right';
        this._slaveGridOptions.enableRtl = this._direction === 'right';
        currentSelection.topGrid = this._masterGridOptions.rowData;
        currentSelection.bottomGrid = this._slaveGridOptions.rowData;
        timer().subscribe(() => {
            this.topBottomData.emit(currentSelection);
        });
    }
    ngOnChanges(_simpleChange) {
        if (!this._firstRun) {
            if (_simpleChange.hasOwnProperty('masterData')) {
                this._masterGridOptions.rowData = _simpleChange['masterData'].currentValue;
                this._masterGridOptions.api.setRowData(_simpleChange['masterData'].currentValue);
                this._emitData();
            }
            if (_simpleChange.hasOwnProperty('slaveData')) {
                this._slaveGridOptions.rowData = _simpleChange['slaveData'].currentValue;
                this._slaveGridOptions.api.setRowData(_simpleChange['slaveData'].currentValue);
                this._emitData();
            }
        }
    }
    ngAfterViewInit() {
        if (this._masterGridOptions.rowData.length === 0) {
            this._masterGridOptions.api.showNoRowsOverlay();
        }
        if (this._slaveGridOptions.rowData.length === 0) {
            this._slaveGridOptions.api.showNoRowsOverlay();
        }
        this._updateNoDataClass();
        this._masterGridOptions.columnApi.autoSizeAllColumns();
        this._colDefArrayWidth = this._aggridSvc.calcColWidth(this._masterGridOptions);
        timer(300).subscribe(() => {
            this._setView();
        });
        this._firstRun = false;
    }
    ngOnDestroy() {
        this._splitterDragSub.unsubscribe();
        this._splitterClickSub.unsubscribe();
    }
    assign(_target) {
        if (_target === 'toTop') {
            this._updateRowData(this._slaveGridOptions, this._masterGridOptions);
        }
        else {
            this._updateRowData(this._masterGridOptions, this._slaveGridOptions);
        }
        if (this._domSvc.isMobile()) {
            this._setHeight(true);
        }
    }
    resetSearch(_e, _grid) {
        _e.stopPropagation();
        let isMobile = this._domSvc.isMobile();
        let search = (_grid === 'top') ? this._masterSearch : this._slaveSearch;
        if (isMobile && search.length === 0) {
            this._searchState(_grid, 'collapse');
        }
        else {
            if (_grid === 'top') {
                this._masterSearch = '';
            }
            else {
                this._slaveSearch = '';
            }
        }
        this.filterChanged(_grid);
    }
    filterChanged(_grid) {
        let isMobile = this._domSvc.isMobile();
        let gridFilterOptions;
        let search = '';
        if (_grid === 'top') {
            gridFilterOptions = this._masterGridOptions;
            search = this._masterSearch;
        }
        else {
            gridFilterOptions = this._slaveGridOptions;
            search = this._slaveSearch;
        }
        gridFilterOptions.api.setQuickFilter(search);
        if (isMobile) {
            this._setHeight(isMobile);
        }
        this._multiTableSvc.checkOverlay(this._masterGridOptions, this._slaveGridOptions);
    }
    sortGrid() {
        let sortModel = this._masterGridOptions.api.getSortModel();
        this._slaveGridOptions.api.setSortModel(sortModel);
    }
    _setView() {
        let isMobile = this._domSvc.isMobile();
        this._setSearchState(isMobile);
        this._setColWidth();
        this._setHeight(isMobile);
        this._setClickSearch(isMobile);
    }
    _setSearchState(_isMobile) {
        if (_isMobile) {
            let search = [];
            search.push(this._vcr.element.nativeElement.querySelector('.search-table-top'));
            search.push(this._vcr.element.nativeElement.querySelector('.search-table-bottom'));
            for (let i = 0; i < search.length; i++) {
                let isCurrentStateExist = search[i].classList.contains('collapse-search') || search[i].classList.contains('expand-search');
                if (!isCurrentStateExist) {
                    let grid;
                    let searchString;
                    if (i === 0) {
                        grid = 'top';
                        searchString = this._masterSearch;
                    }
                    else {
                        grid = 'bottom';
                        searchString = this._slaveSearch;
                    }
                    if (searchString === '') {
                        this._searchState(grid, 'collapse');
                    }
                    else {
                        this._searchState(grid, 'expand');
                    }
                }
            }
        }
        else {
            this._searchState('top', 'reset');
            this._searchState('bottom', 'reset');
        }
    }
    _updateNoDataClass() {
        this._setNoData('top');
        this._setNoData('bottom');
    }
    _setNoData(_grid) {
        let queryString = '.search-table-' + _grid + ' input.search-' + _grid;
        let checkGrid = (_grid === 'top') ? this._masterGridOptions : this._slaveGridOptions;
        let inputEle = this._vcr.element.nativeElement.querySelector(queryString);
        if (checkGrid.rowData.length === 0) {
            this._domSvc.addClass(inputEle, 'no-data');
        }
        else {
            this._domSvc.removeClass(inputEle, 'no-data');
        }
    }
    _setColWidth() {
        let usableWidth = this._aggridSvc.calcUsableWidth(this._vcr);
        if (this._masterGridOptions.columnApi !== null) {
            let totalWidth = this._aggridSvc.colTotalWidth(this._colDefArrayWidth, this._masterGridOptions.columnApi.getAllColumns());
            if (this._masterGridOptions.columnApi !== null) {
                let colDef = this._masterGridOptions.columnApi.getAllColumns();
                let extraPerCol = 0;
                if (totalWidth < usableWidth) {
                    let leftoverWidth = usableWidth - totalWidth;
                    extraPerCol = leftoverWidth / (this._colDefArrayWidth.length - 1);
                }
                for (let i = 0; i < this._colDefArrayWidth.length; i++) {
                    let width = (colDef[i].getColId() === 'checkbox') ? this._colDefArrayWidth[i].width : this._colDefArrayWidth[i].width + extraPerCol;
                    this._masterGridOptions.columnApi.setColumnWidth(colDef[i], width);
                }
            }
        }
    }
    _setClickSearch(_isMobile) {
        let tableTop = this._vcr.element.nativeElement.querySelector('.search-table-top');
        let tableBottom = this._vcr.element.nativeElement.querySelector('.search-table-bottom');
        if (_isMobile) {
            this._renderer.listen(tableTop, 'click', (_e) => {
                if (tableTop.classList.contains('collapse-search')) {
                    this._searchState('top', 'expand');
                }
            });
            this._renderer.listen(tableBottom, 'click', (_e) => {
                if (tableBottom.classList.contains('collapse-search')) {
                    this._searchState('bottom', 'expand');
                }
            });
        }
    }
    _setGridOptions() {
        let settings = this._multiTableSvc.getBothOptions(this.config, this._masterData, this._slaveData);
        this._primaryKey = this._multiTableSvc.getPrimarykey(this.config);
        this._masterGridOptions = settings.masterGridOption;
        this._slaveGridOptions = settings.slaveGridOption;
        this._masterGridOptions.alignedGrids = [this._slaveGridOptions];
        this._slaveGridOptions.alignedGrids = [this._masterGridOptions];
        this._disableButton.top = true;
        this._disableButton.bottom = true;
        this._placeholder.top = this._multiTableSvc.getPlaceholder(this.config, 'top');
        this._placeholder.bottom = this._multiTableSvc.getPlaceholder(this.config, 'bottom');
        this._buttons.toTop = this._multiTableSvc.getButton(this.config, 'toTopBtn');
        this._buttons.toBottom = this._multiTableSvc.getButton(this.config, 'toBottomBtn');
        this._setColDefFloating('master');
        this._setColDefFloating('slave');
    }
    _setColDefFloating(_grid) {
        let newKdAgGridSvc = new KdAggridSvc();
        this._setFloatingTop(_grid);
        let genericGrid = (_grid === 'master') ? this._masterGridOptions : this._slaveGridOptions;
        let colDef = newKdAgGridSvc.setColDefs(this.config.colDef, genericGrid);
        colDef.updatedColDef.unshift(this._setCheckbox(_grid));
        genericGrid.columnDefs = colDef.updatedColDef;
    }
    _updateRowData(_fromGrid, _toGrid) {
        let selectedNodes = _fromGrid.api.getSelectedNodes();
        let offset = 0;
        for (let i = 0; i < selectedNodes.length; i++) {
            selectedNodes[i].data.newRow = true;
            _toGrid.rowData.push(selectedNodes[i].data);
            _fromGrid.rowData.splice(parseInt(selectedNodes[i].id) - offset, 1);
            offset++;
        }
        _toGrid.api.setRowData(_toGrid.rowData);
        _fromGrid.api.setRowData(_fromGrid.rowData);
        let newRow = -1;
        _toGrid.api.forEachNodeAfterFilter((_node) => {
            if (selectedNodes[0].data[this._primaryKey] === _node.data[this._primaryKey]) {
                newRow = _node.childIndex;
            }
        });
        _toGrid.api.ensureIndexVisible(newRow);
        this._disableButton = this._multiTableSvc.checkSelection(this._masterGridOptions, this._slaveGridOptions);
        this._updateNoDataClass();
        this._setCheckboxAfterUpdate();
        this._emitData();
    }
    _setCheckboxAfterUpdate() {
        this._masterSelectAll = false;
        this._slaveSelectAll = false;
        this._multiTableSvc.setCheckboxFalseAfterUpdate(this._vcr);
    }
    _emitData() {
        let currentSelection = {};
        currentSelection.topGrid = this._masterGridOptions.rowData;
        currentSelection.bottomGrid = this._slaveGridOptions.rowData;
        this.topBottomData.emit(currentSelection);
    }
    // private _getRowData(): void {
    // }
    _setFloatingTop(_grid) {
        let gridOptions;
        let selectAllCheck;
        if (_grid === 'master') {
            gridOptions = this._masterGridOptions;
            selectAllCheck = this._masterSelectAll;
        }
        else {
            gridOptions = this._slaveGridOptions;
            selectAllCheck = this._slaveSelectAll;
        }
        gridOptions.pinnedTopRowData = [{ fullWidth: true }];
        gridOptions.isFullWidthCell = (_rowNode) => {
            if (typeof _rowNode.data.fullWidth !== 'undefined') {
                return _rowNode.data.fullWidth;
            }
            return false;
        };
        gridOptions.fullWidthCellRenderer = (params) => {
            let parentWrapper = document.createElement('div');
            let checkboxWrapper = this._domSvc.createElement(parentWrapper, 'selection-wrapper select-all', 'div');
            let checkbox = this._domSvc.createElement(checkboxWrapper, 'select-all', 'input');
            checkbox.type = 'checkbox';
            this._domSvc.createElement(checkboxWrapper, 'label', 'label');
            checkboxWrapper.addEventListener('change', () => {
                let isChecked = checkbox.checked;
                this._checkSelectAllBox(params, _grid, isChecked);
            });
            if (selectAllCheck) {
                checkbox.checked = true;
            }
            let displayData = this._domSvc.createElement(parentWrapper, 'checkbox-text', 'div');
            let pTag = this._domSvc.createElement(displayData, 'check-data', 'div');
            let data = gridOptions.api.getModel().getRowCount();
            pTag.innerHTML = 'Select all ' + data + ' results';
            return parentWrapper;
        };
    }
    _setHeight(_isMobile) {
        let height;
        if (_isMobile) {
            height = this._multiTableSvc.calcMobileHeight(this._masterGridOptions, this._slaveGridOptions, this._vcr);
        }
        else {
            height = this._multiTableSvc.calcWebHeight(this.config.height);
        }
        this._setGridHeight('master', height);
        this._setGridHeight('slave', height);
    }
    _setGridHeight(_grid, _height) {
        let queryString = '.stg-theme.' + _grid;
        let gridHeight;
        let htmlEle = this._vcr.element.nativeElement.querySelector(queryString);
        if (_grid === 'master') {
            gridHeight = _height.top + 'px';
        }
        else {
            gridHeight = _height.bottom + 'px';
        }
        this._domSvc.setElementStyle(htmlEle, 'height', gridHeight);
    }
    _setCheckbox(_grid) {
        let checkboxSetting = this._multiTableSvc.getCheckboxDefault();
        checkboxSetting.pinned = this._direction;
        checkboxSetting.cellClass = 'ag-checkbox-radio';
        checkboxSetting.cellRenderer = (_params) => this._setCellRendering(_params, _grid);
        return checkboxSetting;
    }
    _setCellRendering(params, grid) {
        let header = document.createElement('div');
        let input = this._domSvc.createElement(header, 'checkbox', 'input');
        this._domSvc.createElement(header, 'label', 'label');
        let gridOptions = (grid === 'master') ? this._masterGridOptions : this._slaveGridOptions;
        let currentNode = gridOptions.api.getModel().getRow(params.rowIndex);
        input.type = 'checkbox';
        header.className = 'selection-wrapper';
        header.addEventListener('change', ($event) => {
            currentNode.selectThisNode(input.checked);
            this._checkSelectBox(params, grid);
        });
        if (currentNode.isSelected())
            input.checked = true;
        return header;
    }
    _checkSelectBox(params, grid) {
        let gridOptions = (grid === 'master') ? this._masterGridOptions : this._slaveGridOptions;
        let selectAll = (grid === 'master') ? this._masterSelectAll : this._slaveSelectAll;
        let queryString = '#' + grid + ' .select-all input';
        let rowModelCount = gridOptions.api.getModel().getRowCount();
        let selectedNodesCount = gridOptions.api.getSelectedNodes().length;
        selectAll = (rowModelCount === selectedNodesCount);
        if (grid === 'master')
            this._masterSelectAll = selectAll;
        else
            this._slaveSelectAll = selectAll;
        this._vcr.element.nativeElement.querySelector(queryString).checked = selectAll;
        this._updateSelection(grid);
        this._disableButton = this._multiTableSvc.checkSelection(this._masterGridOptions, this._slaveGridOptions);
    }
    _checkSelectAllBox(params, grid, isChecked) {
        let eleClass = '#' + grid + ((this._direction === 'left') ? ' .ag-pinned-left-cols-container' : ' .ag-pinned-right-cols-container');
        let bodyContainer = this._vcr.element.nativeElement.querySelector(eleClass);
        let inputEle = bodyContainer.querySelectorAll('.selection-wrapper input');
        let gridOptions = (grid === 'master') ? this._masterGridOptions : this._slaveGridOptions;
        let modelApi = gridOptions.api.getModel();
        if (grid === 'master')
            this._masterSelectAll = isChecked;
        else
            this._slaveSelectAll = isChecked;
        let selectAll = (grid === 'master') ? this._masterSelectAll : this._slaveSelectAll;
        for (let i = 0; i < modelApi.getRowCount(); i++) {
            modelApi.getRow(i).selectThisNode(selectAll);
            if (typeof inputEle[i] !== 'undefined')
                inputEle[i].checked = selectAll;
        }
        this._updateSelection(grid);
        this._disableButton = this._multiTableSvc.checkSelection(this._masterGridOptions, this._slaveGridOptions);
    }
    _updateSelection(checkedGrid) {
        let queryString = (checkedGrid === 'master') ? '#slave .selection-wrapper input' : '#master .selection-wrapper input';
        let allElement = this._vcr.element.nativeElement.querySelectorAll(queryString);
        this._multiTableSvc.setCheckboxFalse(allElement);
        if (checkedGrid === 'master') {
            this._slaveGridOptions.api.deselectAll();
            this._slaveSelectAll = false;
        }
        else {
            this._masterGridOptions.api.deselectAll();
            this._masterSelectAll = false;
        }
    }
    _searchState(grid, state) {
        let queryString = '.search-table-' + grid;
        let renderGrid = this._vcr.element.nativeElement.querySelector(queryString);
        if (state === 'collapse') {
            this._domSvc.addClass(renderGrid, 'collapse-search');
            this._domSvc.removeClass(renderGrid, 'expand-search');
        }
        else if (state === 'expand') {
            this._domSvc.addClass(renderGrid, 'expand-search');
            this._domSvc.removeClass(renderGrid, 'collapse-search');
        }
        // 'reset'
        else {
            this._domSvc.removeClass(renderGrid, 'expand-search');
            this._domSvc.removeClass(renderGrid, 'collapse-search');
        }
    }
}
KdMultiSelectTable.decorators = [
    { type: Component, args: [{
                selector: 'kd-multiselect-table',
                template: "<div class='kdx-table-wrapper'>\r\n    <div class='kdx-table-top'>\r\n        <div class='kdx search-table-top'>\r\n            <i class='fa fa-search'></i>\r\n            <input [placeholder]='_placeholder.top' name='focus' class='search-top' type='text' [(ngModel)]=\"_masterSearch\" (ngModelChange)=\"filterChanged('top')\">\r\n            <button type='button' class='close-icon' (click)=\"resetSearch($event, 'top')\" [hidden]='!_masterSearch.length'></button>\r\n        </div>\r\n   \t\t<ag-grid-angular #agGridMaster id=\"master\" class=\"stg-theme master\"\r\n                [gridOptions]=\"_masterGridOptions\" \r\n                (sortChanged) = \"sortGrid()\"\r\n        >\r\n        </ag-grid-angular>\r\n    </div>\r\n    <div class='table-action-btn'>\r\n        <button class='btn btn-default' id='assignBtn' type=\"button\" [disabled]=\"_disableButton.top\" (click)=\"assign('toBottom')\">\r\n            <i [class]='_buttons.toBottom.icon'></i> {{_buttons.toBottom.text}}\r\n        </button>\r\n        <button class='btn btn-default' id='unassignBtn' type=\"button\" [disabled]=\"_disableButton.bottom\" (click)=\"assign('toTop')\">\r\n            <i [class]='_buttons.toTop.icon'></i> {{_buttons.toTop.text}}\r\n        </button>\r\n    </div>\r\n    <div class='kdx-table-bottom'>\r\n        <div class='kdx search-table-bottom'>\r\n            <i class='fa fa-search'></i>\r\n            <input [placeholder]='_placeholder.bottom' name='focus' class='search-bottom' type='text' [(ngModel)]=\"_slaveSearch\" (ngModelChange)=\"filterChanged('bottom')\">\r\n            <button type='button' class='close-icon' (click)=\"resetSearch($event, 'bottom')\" [hidden]=\"!_slaveSearch.length\"></button>\r\n        </div>\r\n       \t<ag-grid-angular #agGridSlave id=\"slave\" class=\"stg-theme slave\" \r\n       \t\t[gridOptions]=\"_slaveGridOptions\"\r\n       \t>\r\n        </ag-grid-angular>\r\n    </div>\r\n</div>",
                providers: [KdMultiSelectTableSvc, KdDomElemSvc, KdAggridSvc],
                encapsulation: ViewEncapsulation.None,
                host: { 'class': 'kdx-multiselect-table' }
            },] }
];
KdMultiSelectTable.ctorParameters = () => [
    { type: KdMultiSelectTableSvc },
    { type: KdDomElemSvc },
    { type: ViewContainerRef },
    { type: Renderer2 },
    { type: KdSplitterEvent },
    { type: KdAggridSvc }
];
KdMultiSelectTable.propDecorators = {
    config: [{ type: Input }],
    masterData: [{ type: Input }],
    slaveData: [{ type: Input }],
    topBottomData: [{ type: Output }],
    onResize: [{ type: HostListener, args: ['window:resize', ['$event'],] }]
};
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoia2QtYW5ndWxhci1tdWx0aXNlbGVjdC10YWJsZS5qcyIsInNvdXJjZVJvb3QiOiJDOi94YW1wcC9odGRvY3MvU3R5bGVndWlkZS9pb3N0Zy1vcGVuZW1pcy1zdHlsZWd1aWRlL3Byb2plY3RzL29wZW5lbWlzLXN0eWxlZ3VpZGUtbGliL3NyYy8iLCJzb3VyY2VzIjpbImtkLWNvbXBvbmVudHMva2QtYW5ndWxhci1tdWx0aXNlbGVjdC10YWJsZS9rZC1hbmd1bGFyLW11bHRpc2VsZWN0LXRhYmxlLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBLE9BQU8sRUFBRSxTQUFTLEVBQW9DLEtBQUssRUFBRSxNQUFNLEVBQUUsWUFBWSxFQUFFLGlCQUFpQixFQUFFLGdCQUFnQixFQUFFLFlBQVksRUFBaUIsU0FBUyxFQUFFLE1BQU0sZUFBZSxDQUFDO0FBQ3RMLE9BQU8sRUFBRSxLQUFLLEVBQWtCLE1BQU0sTUFBTSxDQUFDO0FBRTdDLE9BQU8sb0JBQW9CLENBQUM7QUFDNUIsT0FBTyxFQUFFLFlBQVksRUFBRSxXQUFXLEVBQUUsTUFBTSxvQkFBb0IsQ0FBQztBQUMvRCxPQUFPLEVBQUUsZUFBZSxFQUFFLE1BQU0sOEJBQThCLENBQUM7QUFDL0QsT0FBTyxFQUFFLHFCQUFxQixFQUFFLE1BQU0sNEJBQTRCLENBQUM7QUFDbkUsT0FBTyxFQUFFLFdBQVcsRUFBRSxNQUFNLGdEQUFnRCxDQUFDO0FBQzdFLE9BQU8sRUFBQyxjQUFjLEVBQUMsTUFBTSxvQkFBb0IsQ0FBQztBQVlsRCxNQUFNLE9BQU8sa0JBQWtCO0lBMEIzQixZQUNZLGNBQXFDLEVBQ3JDLE9BQXFCLEVBQ3JCLElBQXNCLEVBQ3RCLFNBQW9CLEVBQ3BCLGNBQStCLEVBQy9CLFVBQXVCO1FBTHZCLG1CQUFjLEdBQWQsY0FBYyxDQUF1QjtRQUNyQyxZQUFPLEdBQVAsT0FBTyxDQUFjO1FBQ3JCLFNBQUksR0FBSixJQUFJLENBQWtCO1FBQ3RCLGNBQVMsR0FBVCxTQUFTLENBQVc7UUFDcEIsbUJBQWMsR0FBZCxjQUFjLENBQWlCO1FBQy9CLGVBQVUsR0FBVixVQUFVLENBQWE7UUEvQjVCLGtCQUFhLEdBQVcsRUFBRSxDQUFDO1FBQzNCLGlCQUFZLEdBQVcsRUFBRSxDQUFDO1FBRzFCLG1CQUFjLEdBQVEsRUFBRSxDQUFDO1FBQ3pCLGlCQUFZLEdBQVEsRUFBRSxDQUFDO1FBQ3ZCLGFBQVEsR0FBUSxFQUFFLENBQUM7UUFFbEIsZUFBVSxHQUFHLE9BQU8sQ0FBQyxvQkFBb0IsQ0FBQyxDQUFDO1FBQzNDLHFCQUFnQixHQUFZLEtBQUssQ0FBQztRQUNsQyxvQkFBZSxHQUFZLEtBQUssQ0FBQztRQUNqQyxzQkFBaUIsR0FBdUMsRUFBRSxDQUFDO1FBRzNELGNBQVMsR0FBWSxJQUFJLENBQUM7UUFDMUIsZ0JBQVcsR0FBZSxFQUFFLENBQUM7UUFDN0IsZUFBVSxHQUFlLEVBQUUsQ0FBQztRQU8xQixrQkFBYSxHQUFzQixJQUFJLFlBQVksRUFBRSxDQUFDO1FBVTVELGNBQWMsQ0FBQyxhQUFhLENBQUMsV0FBVyxDQUFDLEtBQUssQ0FBQyxDQUFDO0lBQ3BELENBQUM7SUFHRCxRQUFRLENBQUMsQ0FBUTtRQUNiLElBQUksQ0FBQyxRQUFRLEVBQUUsQ0FBQztJQUNwQixDQUFDO0lBRUQsUUFBUTtRQUNKLElBQUksQ0FBQyxVQUFVLEdBQUcsQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLG9CQUFvQixDQUFDLElBQUksQ0FBQyxDQUFDLENBQUM7UUFDNUQsSUFBSSxDQUFDLFdBQVcsR0FBRyxDQUFDLE9BQU8sSUFBSSxDQUFDLFVBQVUsS0FBSyxXQUFXLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxLQUFLLEVBQUUsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDO1FBQzNGLElBQUksQ0FBQyxVQUFVLEdBQUcsQ0FBQyxPQUFPLElBQUksQ0FBQyxTQUFTLEtBQUssV0FBVyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsS0FBSyxFQUFFLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQztRQUN4RixJQUFJLENBQUMsZUFBZSxFQUFFLENBQUM7UUFFdkIsSUFBSSxDQUFDLGlCQUFpQixHQUFHLElBQUksQ0FBQyxjQUFjLENBQUMsWUFBWSxFQUFFLENBQUMsU0FBUyxDQUFDLEdBQVMsRUFBRTtZQUM3RSxLQUFLLENBQUMsR0FBRyxDQUFDLENBQUMsU0FBUyxDQUFDLEdBQVMsRUFBRTtnQkFDNUIsSUFBSSxDQUFDLFFBQVEsRUFBRSxDQUFDO1lBQ3BCLENBQUMsQ0FBQyxDQUFDO1FBQ1AsQ0FBQyxDQUFDLENBQUM7UUFFSCxJQUFJLENBQUMsZ0JBQWdCLEdBQUcsSUFBSSxDQUFDLGNBQWMsQ0FBQyxNQUFNLEVBQUUsQ0FBQyxTQUFTLENBQUMsR0FBUyxFQUFFO1lBQ3RFLEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FBQyxTQUFTLENBQUMsR0FBUyxFQUFFO2dCQUM1QixJQUFJLENBQUMsUUFBUSxFQUFFLENBQUM7WUFDcEIsQ0FBQyxDQUFDLENBQUM7UUFDUCxDQUFDLENBQUMsQ0FBQztRQUVILElBQUksZ0JBQWdCLEdBQVEsRUFBRSxDQUFDO1FBRS9CLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxTQUFTLEdBQUcsSUFBSSxDQUFDLFVBQVUsS0FBSyxPQUFPLENBQUM7UUFDaEUsSUFBSSxDQUFDLGlCQUFpQixDQUFDLFNBQVMsR0FBRyxJQUFJLENBQUMsVUFBVSxLQUFLLE9BQU8sQ0FBQztRQUUvRCxnQkFBZ0IsQ0FBQyxPQUFPLEdBQUcsSUFBSSxDQUFDLGtCQUFrQixDQUFDLE9BQU8sQ0FBQztRQUMzRCxnQkFBZ0IsQ0FBQyxVQUFVLEdBQUcsSUFBSSxDQUFDLGlCQUFpQixDQUFDLE9BQU8sQ0FBQztRQUM3RCxLQUFLLEVBQUUsQ0FBQyxTQUFTLENBQUMsR0FBUyxFQUFFO1lBQ3pCLElBQUksQ0FBQyxhQUFhLENBQUMsSUFBSSxDQUFDLGdCQUFnQixDQUFDLENBQUM7UUFDOUMsQ0FBQyxDQUFDLENBQUM7SUFDUCxDQUFDO0lBRUQsV0FBVyxDQUFDLGFBQTRCO1FBQ3BDLElBQUksQ0FBQyxJQUFJLENBQUMsU0FBUyxFQUFFO1lBQ2pCLElBQUksYUFBYSxDQUFDLGNBQWMsQ0FBQyxZQUFZLENBQUMsRUFBRTtnQkFDNUMsSUFBSSxDQUFDLGtCQUFrQixDQUFDLE9BQU8sR0FBRyxhQUFhLENBQUMsWUFBWSxDQUFDLENBQUMsWUFBWSxDQUFDO2dCQUMzRSxJQUFJLENBQUMsa0JBQWtCLENBQUMsR0FBRyxDQUFDLFVBQVUsQ0FBQyxhQUFhLENBQUMsWUFBWSxDQUFDLENBQUMsWUFBWSxDQUFDLENBQUM7Z0JBQ2pGLElBQUksQ0FBQyxTQUFTLEVBQUUsQ0FBQzthQUNwQjtZQUNELElBQUksYUFBYSxDQUFDLGNBQWMsQ0FBQyxXQUFXLENBQUMsRUFBRTtnQkFDM0MsSUFBSSxDQUFDLGlCQUFpQixDQUFDLE9BQU8sR0FBRyxhQUFhLENBQUMsV0FBVyxDQUFDLENBQUMsWUFBWSxDQUFDO2dCQUN6RSxJQUFJLENBQUMsaUJBQWlCLENBQUMsR0FBRyxDQUFDLFVBQVUsQ0FBQyxhQUFhLENBQUMsV0FBVyxDQUFDLENBQUMsWUFBWSxDQUFDLENBQUM7Z0JBQy9FLElBQUksQ0FBQyxTQUFTLEVBQUUsQ0FBQzthQUNwQjtTQUNKO0lBQ0wsQ0FBQztJQUVELGVBQWU7UUFDWCxJQUFJLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxPQUFPLENBQUMsTUFBTSxLQUFLLENBQUMsRUFBRTtZQUM5QyxJQUFJLENBQUMsa0JBQWtCLENBQUMsR0FBRyxDQUFDLGlCQUFpQixFQUFFLENBQUM7U0FDbkQ7UUFFRCxJQUFJLElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxPQUFPLENBQUMsTUFBTSxLQUFLLENBQUMsRUFBRTtZQUM3QyxJQUFJLENBQUMsaUJBQWlCLENBQUMsR0FBRyxDQUFDLGlCQUFpQixFQUFFLENBQUM7U0FDbEQ7UUFFRCxJQUFJLENBQUMsa0JBQWtCLEVBQUUsQ0FBQztRQUMxQixJQUFJLENBQUMsa0JBQWtCLENBQUMsU0FBUyxDQUFDLGtCQUFrQixFQUFFLENBQUM7UUFDdkQsSUFBSSxDQUFDLGlCQUFpQixHQUFHLElBQUksQ0FBQyxVQUFVLENBQUMsWUFBWSxDQUFDLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxDQUFDO1FBRS9FLEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FBQyxTQUFTLENBQUMsR0FBUyxFQUFFO1lBQzVCLElBQUksQ0FBQyxRQUFRLEVBQUUsQ0FBQztRQUNwQixDQUFDLENBQUMsQ0FBQztRQUVILElBQUksQ0FBQyxTQUFTLEdBQUcsS0FBSyxDQUFDO0lBQzNCLENBQUM7SUFFRCxXQUFXO1FBQ1AsSUFBSSxDQUFDLGdCQUFnQixDQUFDLFdBQVcsRUFBRSxDQUFDO1FBQ3BDLElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxXQUFXLEVBQUUsQ0FBQztJQUN6QyxDQUFDO0lBRUQsTUFBTSxDQUFDLE9BQWU7UUFDbEIsSUFBSSxPQUFPLEtBQUssT0FBTyxFQUFFO1lBQ3JCLElBQUksQ0FBQyxjQUFjLENBQUMsSUFBSSxDQUFDLGlCQUFpQixFQUFFLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxDQUFDO1NBQ3hFO2FBQ0k7WUFDRCxJQUFJLENBQUMsY0FBYyxDQUFDLElBQUksQ0FBQyxrQkFBa0IsRUFBRSxJQUFJLENBQUMsaUJBQWlCLENBQUMsQ0FBQztTQUN4RTtRQUVELElBQUksSUFBSSxDQUFDLE9BQU8sQ0FBQyxRQUFRLEVBQUUsRUFBRTtZQUN6QixJQUFJLENBQUMsVUFBVSxDQUFDLElBQUksQ0FBQyxDQUFDO1NBQ3pCO0lBQ0wsQ0FBQztJQUVELFdBQVcsQ0FBQyxFQUFTLEVBQUUsS0FBYTtRQUNoQyxFQUFFLENBQUMsZUFBZSxFQUFFLENBQUM7UUFFckIsSUFBSSxRQUFRLEdBQVksSUFBSSxDQUFDLE9BQU8sQ0FBQyxRQUFRLEVBQUUsQ0FBQztRQUNoRCxJQUFJLE1BQU0sR0FBVyxDQUFDLEtBQUssS0FBSyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLGFBQWEsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLFlBQVksQ0FBQztRQUVoRixJQUFJLFFBQVEsSUFBSSxNQUFNLENBQUMsTUFBTSxLQUFLLENBQUMsRUFBRTtZQUNqQyxJQUFJLENBQUMsWUFBWSxDQUFDLEtBQUssRUFBRSxVQUFVLENBQUMsQ0FBQztTQUN4QzthQUNJO1lBQ0QsSUFBSSxLQUFLLEtBQUssS0FBSyxFQUFFO2dCQUNqQixJQUFJLENBQUMsYUFBYSxHQUFHLEVBQUUsQ0FBQzthQUMzQjtpQkFDSTtnQkFDRCxJQUFJLENBQUMsWUFBWSxHQUFHLEVBQUUsQ0FBQzthQUMxQjtTQUNKO1FBRUQsSUFBSSxDQUFDLGFBQWEsQ0FBQyxLQUFLLENBQUMsQ0FBQztJQUM5QixDQUFDO0lBRUQsYUFBYSxDQUFDLEtBQWE7UUFDdkIsSUFBSSxRQUFRLEdBQVksSUFBSSxDQUFDLE9BQU8sQ0FBQyxRQUFRLEVBQUUsQ0FBQztRQUNoRCxJQUFJLGlCQUE4QixDQUFDO1FBQ25DLElBQUksTUFBTSxHQUFXLEVBQUUsQ0FBQztRQUV4QixJQUFJLEtBQUssS0FBSyxLQUFLLEVBQUU7WUFDakIsaUJBQWlCLEdBQUcsSUFBSSxDQUFDLGtCQUFrQixDQUFDO1lBQzVDLE1BQU0sR0FBRyxJQUFJLENBQUMsYUFBYSxDQUFDO1NBQy9CO2FBQ0k7WUFDRCxpQkFBaUIsR0FBRyxJQUFJLENBQUMsaUJBQWlCLENBQUM7WUFDM0MsTUFBTSxHQUFHLElBQUksQ0FBQyxZQUFZLENBQUM7U0FDOUI7UUFFRCxpQkFBaUIsQ0FBQyxHQUFHLENBQUMsY0FBYyxDQUFDLE1BQU0sQ0FBQyxDQUFDO1FBRTdDLElBQUksUUFBUSxFQUFFO1lBQ1YsSUFBSSxDQUFDLFVBQVUsQ0FBQyxRQUFRLENBQUMsQ0FBQztTQUM3QjtRQUVELElBQUksQ0FBQyxjQUFjLENBQUMsWUFBWSxDQUFDLElBQUksQ0FBQyxrQkFBa0IsRUFBRSxJQUFJLENBQUMsaUJBQWlCLENBQUMsQ0FBQztJQUN0RixDQUFDO0lBRUQsUUFBUTtRQUNKLElBQUksU0FBUyxHQUFRLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxHQUFHLENBQUMsWUFBWSxFQUFFLENBQUM7UUFDaEUsSUFBSSxDQUFDLGlCQUFpQixDQUFDLEdBQUcsQ0FBQyxZQUFZLENBQUMsU0FBUyxDQUFDLENBQUM7SUFDdkQsQ0FBQztJQUVPLFFBQVE7UUFDWixJQUFJLFFBQVEsR0FBRyxJQUFJLENBQUMsT0FBTyxDQUFDLFFBQVEsRUFBRSxDQUFDO1FBQ3ZDLElBQUksQ0FBQyxlQUFlLENBQUMsUUFBUSxDQUFDLENBQUM7UUFDL0IsSUFBSSxDQUFDLFlBQVksRUFBRSxDQUFDO1FBQ3BCLElBQUksQ0FBQyxVQUFVLENBQUMsUUFBUSxDQUFDLENBQUM7UUFDMUIsSUFBSSxDQUFDLGVBQWUsQ0FBQyxRQUFRLENBQUMsQ0FBQztJQUNuQyxDQUFDO0lBRU8sZUFBZSxDQUFDLFNBQWtCO1FBQ3RDLElBQUksU0FBUyxFQUFFO1lBQ1gsSUFBSSxNQUFNLEdBQXVCLEVBQUUsQ0FBQztZQUVwQyxNQUFNLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLGFBQWEsQ0FBQyxhQUFhLENBQUMsbUJBQW1CLENBQUMsQ0FBQyxDQUFDO1lBQ2hGLE1BQU0sQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsYUFBYSxDQUFDLGFBQWEsQ0FBQyxzQkFBc0IsQ0FBQyxDQUFDLENBQUM7WUFFbkYsS0FBSyxJQUFJLENBQUMsR0FBVyxDQUFDLEVBQUUsQ0FBQyxHQUFHLE1BQU0sQ0FBQyxNQUFNLEVBQUUsQ0FBQyxFQUFFLEVBQUU7Z0JBQzVDLElBQUksbUJBQW1CLEdBQVksTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxRQUFRLENBQUMsaUJBQWlCLENBQUMsSUFBSSxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDLFFBQVEsQ0FBQyxlQUFlLENBQUMsQ0FBQztnQkFFcEksSUFBSSxDQUFDLG1CQUFtQixFQUFFO29CQUN0QixJQUFJLElBQVksQ0FBQztvQkFDakIsSUFBSSxZQUFvQixDQUFDO29CQUV6QixJQUFJLENBQUMsS0FBSyxDQUFDLEVBQUU7d0JBQ1QsSUFBSSxHQUFHLEtBQUssQ0FBQzt3QkFDYixZQUFZLEdBQUcsSUFBSSxDQUFDLGFBQWEsQ0FBQztxQkFDckM7eUJBQ0k7d0JBQ0QsSUFBSSxHQUFHLFFBQVEsQ0FBQzt3QkFDaEIsWUFBWSxHQUFHLElBQUksQ0FBQyxZQUFZLENBQUM7cUJBQ3BDO29CQUVELElBQUksWUFBWSxLQUFLLEVBQUUsRUFBRTt3QkFDckIsSUFBSSxDQUFDLFlBQVksQ0FBQyxJQUFJLEVBQUUsVUFBVSxDQUFDLENBQUM7cUJBQ3ZDO3lCQUNJO3dCQUNELElBQUksQ0FBQyxZQUFZLENBQUMsSUFBSSxFQUFFLFFBQVEsQ0FBQyxDQUFDO3FCQUNyQztpQkFDSjthQUNKO1NBQ0o7YUFDSTtZQUNELElBQUksQ0FBQyxZQUFZLENBQUMsS0FBSyxFQUFFLE9BQU8sQ0FBQyxDQUFDO1lBQ2xDLElBQUksQ0FBQyxZQUFZLENBQUMsUUFBUSxFQUFFLE9BQU8sQ0FBQyxDQUFDO1NBQ3hDO0lBQ0wsQ0FBQztJQUVPLGtCQUFrQjtRQUN0QixJQUFJLENBQUMsVUFBVSxDQUFDLEtBQUssQ0FBQyxDQUFDO1FBQ3ZCLElBQUksQ0FBQyxVQUFVLENBQUMsUUFBUSxDQUFDLENBQUM7SUFDOUIsQ0FBQztJQUVPLFVBQVUsQ0FBQyxLQUFhO1FBQzVCLElBQUksV0FBVyxHQUFXLGdCQUFnQixHQUFHLEtBQUssR0FBRyxnQkFBZ0IsR0FBRyxLQUFLLENBQUM7UUFDOUUsSUFBSSxTQUFTLEdBQWdCLENBQUMsS0FBSyxLQUFLLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsa0JBQWtCLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxpQkFBaUIsQ0FBQztRQUNsRyxJQUFJLFFBQVEsR0FBZ0IsSUFBSSxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsYUFBYSxDQUFDLGFBQWEsQ0FBQyxXQUFXLENBQUMsQ0FBQztRQUV2RixJQUFJLFNBQVMsQ0FBQyxPQUFPLENBQUMsTUFBTSxLQUFLLENBQUMsRUFBRTtZQUNoQyxJQUFJLENBQUMsT0FBTyxDQUFDLFFBQVEsQ0FBQyxRQUFRLEVBQUUsU0FBUyxDQUFDLENBQUM7U0FDOUM7YUFDSTtZQUNELElBQUksQ0FBQyxPQUFPLENBQUMsV0FBVyxDQUFDLFFBQVEsRUFBRSxTQUFTLENBQUMsQ0FBQztTQUNqRDtJQUNMLENBQUM7SUFFTyxZQUFZO1FBQ2hCLElBQUksV0FBVyxHQUFXLElBQUksQ0FBQyxVQUFVLENBQUMsZUFBZSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQztRQUVyRSxJQUFJLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxTQUFTLEtBQUssSUFBSSxFQUFFO1lBQzVDLElBQUksVUFBVSxHQUFXLElBQUksQ0FBQyxVQUFVLENBQUMsYUFBYSxDQUFDLElBQUksQ0FBQyxpQkFBaUIsRUFBRSxJQUFJLENBQUMsa0JBQWtCLENBQUMsU0FBUyxDQUFDLGFBQWEsRUFBRSxDQUFDLENBQUM7WUFFbEksSUFBSSxJQUFJLENBQUMsa0JBQWtCLENBQUMsU0FBUyxLQUFLLElBQUksRUFBRTtnQkFDNUMsSUFBSSxNQUFNLEdBQWtCLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxTQUFTLENBQUMsYUFBYSxFQUFFLENBQUM7Z0JBQzlFLElBQUksV0FBVyxHQUFXLENBQUMsQ0FBQztnQkFFNUIsSUFBSSxVQUFVLEdBQUcsV0FBVyxFQUFFO29CQUMxQixJQUFJLGFBQWEsR0FBVyxXQUFXLEdBQUcsVUFBVSxDQUFDO29CQUNyRCxXQUFXLEdBQUcsYUFBYSxHQUFHLENBQUMsSUFBSSxDQUFDLGlCQUFpQixDQUFDLE1BQU0sR0FBRyxDQUFDLENBQUMsQ0FBQztpQkFDckU7Z0JBRUQsS0FBSyxJQUFJLENBQUMsR0FBVyxDQUFDLEVBQUUsQ0FBQyxHQUFHLElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxNQUFNLEVBQUUsQ0FBQyxFQUFFLEVBQUU7b0JBQzVELElBQUksS0FBSyxHQUFXLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsRUFBRSxLQUFLLFVBQVUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsaUJBQWlCLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsaUJBQWlCLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxHQUFHLFdBQVcsQ0FBQztvQkFDNUksSUFBSSxDQUFDLGtCQUFrQixDQUFDLFNBQVMsQ0FBQyxjQUFjLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxFQUFFLEtBQUssQ0FBQyxDQUFDO2lCQUN0RTthQUNKO1NBQ0o7SUFDTCxDQUFDO0lBRU8sZUFBZSxDQUFDLFNBQWtCO1FBQ3RDLElBQUksUUFBUSxHQUFnQixJQUFJLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxhQUFhLENBQUMsYUFBYSxDQUFDLG1CQUFtQixDQUFDLENBQUM7UUFDL0YsSUFBSSxXQUFXLEdBQWdCLElBQUksQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLGFBQWEsQ0FBQyxhQUFhLENBQUMsc0JBQXNCLENBQUMsQ0FBQztRQUVyRyxJQUFJLFNBQVMsRUFBRTtZQUNYLElBQUksQ0FBQyxTQUFTLENBQUMsTUFBTSxDQUFDLFFBQVEsRUFBRSxPQUFPLEVBQUUsQ0FBQyxFQUFTLEVBQVEsRUFBRTtnQkFDckUsSUFBSSxRQUFRLENBQUMsU0FBUyxDQUFDLFFBQVEsQ0FBQyxpQkFBaUIsQ0FBQyxFQUFFO29CQUNoRCxJQUFJLENBQUMsWUFBWSxDQUFDLEtBQUssRUFBRSxRQUFRLENBQUMsQ0FBQztpQkFDdEM7WUFDTCxDQUFDLENBQUMsQ0FBQztZQUVTLElBQUksQ0FBQyxTQUFTLENBQUMsTUFBTSxDQUFDLFdBQVcsRUFBRSxPQUFPLEVBQUUsQ0FBQyxFQUFTLEVBQVEsRUFBRTtnQkFDeEUsSUFBSSxXQUFXLENBQUMsU0FBUyxDQUFDLFFBQVEsQ0FBQyxpQkFBaUIsQ0FBQyxFQUFFO29CQUNuRCxJQUFJLENBQUMsWUFBWSxDQUFDLFFBQVEsRUFBRSxRQUFRLENBQUMsQ0FBQztpQkFDekM7WUFDTCxDQUFDLENBQUMsQ0FBQztTQUNNO0lBQ0wsQ0FBQztJQUVPLGVBQWU7UUFDbkIsSUFBSSxRQUFRLEdBQVEsSUFBSSxDQUFDLGNBQWMsQ0FBQyxjQUFjLENBQUMsSUFBSSxDQUFDLE1BQU0sRUFBRSxJQUFJLENBQUMsV0FBVyxFQUFFLElBQUksQ0FBQyxVQUFVLENBQUMsQ0FBQztRQUN2RyxJQUFJLENBQUMsV0FBVyxHQUFHLElBQUksQ0FBQyxjQUFjLENBQUMsYUFBYSxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQztRQUVsRSxJQUFJLENBQUMsa0JBQWtCLEdBQUcsUUFBUSxDQUFDLGdCQUFnQixDQUFDO1FBQ3BELElBQUksQ0FBQyxpQkFBaUIsR0FBRyxRQUFRLENBQUMsZUFBZSxDQUFDO1FBQ2xELElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxZQUFZLEdBQUcsQ0FBQyxJQUFJLENBQUMsaUJBQWlCLENBQUMsQ0FBQztRQUNoRSxJQUFJLENBQUMsaUJBQWlCLENBQUMsWUFBWSxHQUFHLENBQUMsSUFBSSxDQUFDLGtCQUFrQixDQUFDLENBQUM7UUFFaEUsSUFBSSxDQUFDLGNBQWMsQ0FBQyxHQUFHLEdBQUcsSUFBSSxDQUFDO1FBQy9CLElBQUksQ0FBQyxjQUFjLENBQUMsTUFBTSxHQUFHLElBQUksQ0FBQztRQUVsQyxJQUFJLENBQUMsWUFBWSxDQUFDLEdBQUcsR0FBRyxJQUFJLENBQUMsY0FBYyxDQUFDLGNBQWMsQ0FBQyxJQUFJLENBQUMsTUFBTSxFQUFFLEtBQUssQ0FBQyxDQUFDO1FBQy9FLElBQUksQ0FBQyxZQUFZLENBQUMsTUFBTSxHQUFHLElBQUksQ0FBQyxjQUFjLENBQUMsY0FBYyxDQUFDLElBQUksQ0FBQyxNQUFNLEVBQUUsUUFBUSxDQUFDLENBQUM7UUFFckYsSUFBSSxDQUFDLFFBQVEsQ0FBQyxLQUFLLEdBQUcsSUFBSSxDQUFDLGNBQWMsQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDLE1BQU0sRUFBRSxVQUFVLENBQUMsQ0FBQztRQUM3RSxJQUFJLENBQUMsUUFBUSxDQUFDLFFBQVEsR0FBRyxJQUFJLENBQUMsY0FBYyxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsTUFBTSxFQUFFLGFBQWEsQ0FBQyxDQUFDO1FBRW5GLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxRQUFRLENBQUMsQ0FBQztRQUNsQyxJQUFJLENBQUMsa0JBQWtCLENBQUMsT0FBTyxDQUFDLENBQUM7SUFDckMsQ0FBQztJQUVPLGtCQUFrQixDQUFDLEtBQWE7UUFDcEMsSUFBSSxjQUFjLEdBQWdCLElBQUksV0FBVyxFQUFFLENBQUM7UUFDcEQsSUFBSSxDQUFDLGVBQWUsQ0FBQyxLQUFLLENBQUMsQ0FBQztRQUU1QixJQUFJLFdBQVcsR0FBZ0IsQ0FBQyxLQUFLLEtBQUssUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLGlCQUFpQixDQUFDO1FBQ3ZHLElBQUksTUFBTSxHQUFRLGNBQWMsQ0FBQyxVQUFVLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxNQUFNLEVBQUUsV0FBVyxDQUFDLENBQUM7UUFDN0UsTUFBTSxDQUFDLGFBQWEsQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLFlBQVksQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDO1FBQ3ZELFdBQVcsQ0FBQyxVQUFVLEdBQUcsTUFBTSxDQUFDLGFBQWEsQ0FBQztJQUNsRCxDQUFDO0lBRU8sY0FBYyxDQUFDLFNBQXNCLEVBQUUsT0FBb0I7UUFDL0QsSUFBSSxhQUFhLEdBQW1CLFNBQVMsQ0FBQyxHQUFHLENBQUMsZ0JBQWdCLEVBQUUsQ0FBQztRQUNyRSxJQUFJLE1BQU0sR0FBVyxDQUFDLENBQUM7UUFFdkIsS0FBSyxJQUFJLENBQUMsR0FBVyxDQUFDLEVBQUUsQ0FBQyxHQUFHLGFBQWEsQ0FBQyxNQUFNLEVBQUUsQ0FBQyxFQUFFLEVBQUU7WUFDbkQsYUFBYSxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxNQUFNLEdBQUcsSUFBSSxDQUFDO1lBRXBDLE9BQU8sQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLGFBQWEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQztZQUM1QyxTQUFTLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxRQUFRLENBQUMsYUFBYSxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxHQUFHLE1BQU0sRUFBRSxDQUFDLENBQUMsQ0FBQztZQUVwRSxNQUFNLEVBQUUsQ0FBQztTQUNaO1FBRUQsT0FBTyxDQUFDLEdBQUcsQ0FBQyxVQUFVLENBQUMsT0FBTyxDQUFDLE9BQU8sQ0FBQyxDQUFDO1FBQ3hDLFNBQVMsQ0FBQyxHQUFHLENBQUMsVUFBVSxDQUFDLFNBQVMsQ0FBQyxPQUFPLENBQUMsQ0FBQztRQUU1QyxJQUFJLE1BQU0sR0FBVyxDQUFDLENBQUMsQ0FBQztRQUN4QixPQUFPLENBQUMsR0FBRyxDQUFDLHNCQUFzQixDQUFDLENBQUMsS0FBYyxFQUFRLEVBQUU7WUFDeEQsSUFBSSxhQUFhLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxXQUFXLENBQUMsS0FBSyxLQUFLLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxXQUFXLENBQUMsRUFBRTtnQkFDMUUsTUFBTSxHQUFHLEtBQUssQ0FBQyxVQUFVLENBQUM7YUFDN0I7UUFDTCxDQUFDLENBQUMsQ0FBQztRQUVILE9BQU8sQ0FBQyxHQUFHLENBQUMsa0JBQWtCLENBQUMsTUFBTSxDQUFDLENBQUM7UUFFdkMsSUFBSSxDQUFDLGNBQWMsR0FBRyxJQUFJLENBQUMsY0FBYyxDQUFDLGNBQWMsQ0FBQyxJQUFJLENBQUMsa0JBQWtCLEVBQUUsSUFBSSxDQUFDLGlCQUFpQixDQUFDLENBQUM7UUFDMUcsSUFBSSxDQUFDLGtCQUFrQixFQUFFLENBQUM7UUFDMUIsSUFBSSxDQUFDLHVCQUF1QixFQUFFLENBQUM7UUFDL0IsSUFBSSxDQUFDLFNBQVMsRUFBRSxDQUFDO0lBQ3JCLENBQUM7SUFFTyx1QkFBdUI7UUFDM0IsSUFBSSxDQUFDLGdCQUFnQixHQUFHLEtBQUssQ0FBQztRQUM5QixJQUFJLENBQUMsZUFBZSxHQUFHLEtBQUssQ0FBQztRQUM3QixJQUFJLENBQUMsY0FBYyxDQUFDLDJCQUEyQixDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQztJQUMvRCxDQUFDO0lBRU8sU0FBUztRQUNiLElBQUksZ0JBQWdCLEdBQVEsRUFBRSxDQUFDO1FBQy9CLGdCQUFnQixDQUFDLE9BQU8sR0FBRyxJQUFJLENBQUMsa0JBQWtCLENBQUMsT0FBTyxDQUFDO1FBQzNELGdCQUFnQixDQUFDLFVBQVUsR0FBRyxJQUFJLENBQUMsaUJBQWlCLENBQUMsT0FBTyxDQUFDO1FBQzdELElBQUksQ0FBQyxhQUFhLENBQUMsSUFBSSxDQUFDLGdCQUFnQixDQUFDLENBQUM7SUFDOUMsQ0FBQztJQUVELGdDQUFnQztJQUVoQyxJQUFJO0lBRUksZUFBZSxDQUFDLEtBQWE7UUFDakMsSUFBSSxXQUF3QixDQUFDO1FBQzdCLElBQUksY0FBdUIsQ0FBQztRQUU1QixJQUFJLEtBQUssS0FBSyxRQUFRLEVBQUU7WUFDcEIsV0FBVyxHQUFHLElBQUksQ0FBQyxrQkFBa0IsQ0FBQztZQUN0QyxjQUFjLEdBQUcsSUFBSSxDQUFDLGdCQUFnQixDQUFDO1NBQzFDO2FBQ0k7WUFDRCxXQUFXLEdBQUcsSUFBSSxDQUFDLGlCQUFpQixDQUFDO1lBQ3JDLGNBQWMsR0FBRyxJQUFJLENBQUMsZUFBZSxDQUFDO1NBQ3pDO1FBRUQsV0FBVyxDQUFDLGdCQUFnQixHQUFHLENBQUMsRUFBQyxTQUFTLEVBQUUsSUFBSSxFQUFDLENBQUMsQ0FBQztRQUNuRCxXQUFXLENBQUMsZUFBZSxHQUFHLENBQUMsUUFBaUIsRUFBVyxFQUFFO1lBQ3pELElBQUksT0FBTyxRQUFRLENBQUMsSUFBSSxDQUFDLFNBQVMsS0FBSyxXQUFXLEVBQUU7Z0JBQ2hELE9BQU8sUUFBUSxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUM7YUFDbEM7WUFDRCxPQUFPLEtBQUssQ0FBQztRQUNqQixDQUFDLENBQUM7UUFFRixXQUFXLENBQUMscUJBQXFCLEdBQUcsQ0FBQyxNQUFXLEVBQWUsRUFBRTtZQUM3RCxJQUFJLGFBQWEsR0FBZ0IsUUFBUSxDQUFDLGFBQWEsQ0FBQyxLQUFLLENBQUMsQ0FBQztZQUMvRCxJQUFJLGVBQWUsR0FBbUIsSUFBSSxDQUFDLE9BQU8sQ0FBQyxhQUFhLENBQUMsYUFBYSxFQUFFLDhCQUE4QixFQUFFLEtBQUssQ0FBQyxDQUFDO1lBQ3ZILElBQUksUUFBUSxHQUFxQixJQUFJLENBQUMsT0FBTyxDQUFDLGFBQWEsQ0FBQyxlQUFlLEVBQUUsWUFBWSxFQUFFLE9BQU8sQ0FBQyxDQUFDO1lBRXBHLFFBQVEsQ0FBQyxJQUFJLEdBQUcsVUFBVSxDQUFDO1lBRTNCLElBQUksQ0FBQyxPQUFPLENBQUMsYUFBYSxDQUFDLGVBQWUsRUFBRSxPQUFPLEVBQUUsT0FBTyxDQUFDLENBQUM7WUFDOUQsZUFBZSxDQUFDLGdCQUFnQixDQUFDLFFBQVEsRUFBRSxHQUFTLEVBQUU7Z0JBQ2xELElBQUksU0FBUyxHQUFZLFFBQVEsQ0FBQyxPQUFPLENBQUM7Z0JBQzFDLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxNQUFNLEVBQUUsS0FBSyxFQUFFLFNBQVMsQ0FBQyxDQUFDO1lBQ3RELENBQUMsQ0FBQyxDQUFDO1lBRUgsSUFBSSxjQUFjLEVBQUU7Z0JBQ2hCLFFBQVEsQ0FBQyxPQUFPLEdBQUcsSUFBSSxDQUFDO2FBQzNCO1lBRUQsSUFBSSxXQUFXLEdBQW1CLElBQUksQ0FBQyxPQUFPLENBQUMsYUFBYSxDQUFDLGFBQWEsRUFBRSxlQUFlLEVBQUUsS0FBSyxDQUFDLENBQUM7WUFDcEcsSUFBSSxJQUFJLEdBQW1CLElBQUksQ0FBQyxPQUFPLENBQUMsYUFBYSxDQUFDLFdBQVcsRUFBRSxZQUFZLEVBQUUsS0FBSyxDQUFDLENBQUM7WUFDeEYsSUFBSSxJQUFJLEdBQUcsV0FBVyxDQUFDLEdBQUcsQ0FBQyxRQUFRLEVBQUUsQ0FBQyxXQUFXLEVBQUUsQ0FBQztZQUNwRCxJQUFJLENBQUMsU0FBUyxHQUFHLGFBQWEsR0FBRyxJQUFJLEdBQUcsVUFBVSxDQUFDO1lBRW5ELE9BQU8sYUFBYSxDQUFDO1FBQ3pCLENBQUMsQ0FBQztJQUNOLENBQUM7SUFFTyxVQUFVLENBQUMsU0FBa0I7UUFDakMsSUFBSSxNQUFXLENBQUM7UUFFaEIsSUFBSSxTQUFTLEVBQUU7WUFDWCxNQUFNLEdBQUcsSUFBSSxDQUFDLGNBQWMsQ0FBQyxnQkFBZ0IsQ0FBQyxJQUFJLENBQUMsa0JBQWtCLEVBQUUsSUFBSSxDQUFDLGlCQUFpQixFQUFFLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQztTQUM3RzthQUNJO1lBQ0QsTUFBTSxHQUFHLElBQUksQ0FBQyxjQUFjLENBQUMsYUFBYSxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLENBQUM7U0FDbEU7UUFFRCxJQUFJLENBQUMsY0FBYyxDQUFDLFFBQVEsRUFBRSxNQUFNLENBQUMsQ0FBQztRQUN0QyxJQUFJLENBQUMsY0FBYyxDQUFDLE9BQU8sRUFBRSxNQUFNLENBQUMsQ0FBQztJQUN6QyxDQUFDO0lBRU8sY0FBYyxDQUFDLEtBQWEsRUFBRSxPQUFZO1FBQzlDLElBQUksV0FBVyxHQUFXLGFBQWEsR0FBRyxLQUFLLENBQUM7UUFDaEQsSUFBSSxVQUFrQixDQUFDO1FBQ3ZCLElBQUksT0FBTyxHQUFnQixJQUFJLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxhQUFhLENBQUMsYUFBYSxDQUFDLFdBQVcsQ0FBQyxDQUFDO1FBRXRGLElBQUksS0FBSyxLQUFLLFFBQVEsRUFBRTtZQUNwQixVQUFVLEdBQUcsT0FBTyxDQUFDLEdBQUcsR0FBRyxJQUFJLENBQUM7U0FDbkM7YUFDSTtZQUNELFVBQVUsR0FBRyxPQUFPLENBQUMsTUFBTSxHQUFHLElBQUksQ0FBQztTQUN0QztRQUVELElBQUksQ0FBQyxPQUFPLENBQUMsZUFBZSxDQUFDLE9BQU8sRUFBRSxRQUFRLEVBQUUsVUFBVSxDQUFDLENBQUM7SUFDaEUsQ0FBQztJQUVPLFlBQVksQ0FBQyxLQUFhO1FBQzlCLElBQUksZUFBZSxHQUFRLElBQUksQ0FBQyxjQUFjLENBQUMsa0JBQWtCLEVBQUUsQ0FBQztRQUNwRSxlQUFlLENBQUMsTUFBTSxHQUFJLElBQUksQ0FBQyxVQUFVLENBQUM7UUFDMUMsZUFBZSxDQUFDLFNBQVMsR0FBRyxtQkFBbUIsQ0FBQztRQUNoRCxlQUFlLENBQUMsWUFBWSxHQUFHLENBQUMsT0FBWSxFQUFlLEVBQUUsQ0FBQyxJQUFJLENBQUMsaUJBQWlCLENBQUMsT0FBTyxFQUFFLEtBQUssQ0FBQyxDQUFDO1FBRXJHLE9BQU8sZUFBZSxDQUFDO0lBQzNCLENBQUM7SUFFTyxpQkFBaUIsQ0FBQyxNQUFXLEVBQUUsSUFBWTtRQUMvQyxJQUFJLE1BQU0sR0FBbUIsUUFBUSxDQUFDLGFBQWEsQ0FBQyxLQUFLLENBQUMsQ0FBQztRQUMzRCxJQUFJLEtBQUssR0FBcUIsSUFBSSxDQUFDLE9BQU8sQ0FBQyxhQUFhLENBQUMsTUFBTSxFQUFFLFVBQVUsRUFBRSxPQUFPLENBQUMsQ0FBQztRQUN0RixJQUFJLENBQUMsT0FBTyxDQUFDLGFBQWEsQ0FBQyxNQUFNLEVBQUUsT0FBTyxFQUFFLE9BQU8sQ0FBQyxDQUFDO1FBQ3JELElBQUksV0FBVyxHQUFnQixDQUFDLElBQUksS0FBSyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLGtCQUFrQixDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsaUJBQWlCLENBQUM7UUFDdEcsSUFBSSxXQUFXLEdBQVksV0FBVyxDQUFDLEdBQUcsQ0FBQyxRQUFRLEVBQUUsQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLFFBQVEsQ0FBQyxDQUFDO1FBQzlFLEtBQUssQ0FBQyxJQUFJLEdBQUcsVUFBVSxDQUFDO1FBQ3hCLE1BQU0sQ0FBQyxTQUFTLEdBQUcsbUJBQW1CLENBQUM7UUFDdkMsTUFBTSxDQUFDLGdCQUFnQixDQUFDLFFBQVEsRUFBRSxDQUFDLE1BQU0sRUFBUSxFQUFFO1lBQy9DLFdBQVcsQ0FBQyxjQUFjLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxDQUFDO1lBQzFDLElBQUksQ0FBQyxlQUFlLENBQUMsTUFBTSxFQUFFLElBQUksQ0FBQyxDQUFDO1FBQ3ZDLENBQUMsQ0FBQyxDQUFDO1FBQ0gsSUFBSSxXQUFXLENBQUMsVUFBVSxFQUFFO1lBQUUsS0FBSyxDQUFDLE9BQU8sR0FBRyxJQUFJLENBQUM7UUFFbkQsT0FBTyxNQUFNLENBQUM7SUFDbEIsQ0FBQztJQUVPLGVBQWUsQ0FBQyxNQUFXLEVBQUUsSUFBWTtRQUM3QyxJQUFJLFdBQVcsR0FBZ0IsQ0FBQyxJQUFJLEtBQUssUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLGlCQUFpQixDQUFDO1FBQ3RHLElBQUksU0FBUyxHQUFZLENBQUMsSUFBSSxLQUFLLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxlQUFlLENBQUM7UUFDNUYsSUFBSSxXQUFXLEdBQVcsR0FBRyxHQUFHLElBQUksR0FBRyxvQkFBb0IsQ0FBQztRQUM1RCxJQUFJLGFBQWEsR0FBRyxXQUFXLENBQUMsR0FBRyxDQUFDLFFBQVEsRUFBRSxDQUFDLFdBQVcsRUFBRSxDQUFDO1FBQzdELElBQUksa0JBQWtCLEdBQUcsV0FBVyxDQUFDLEdBQUcsQ0FBQyxnQkFBZ0IsRUFBRSxDQUFDLE1BQU0sQ0FBQztRQUNuRSxTQUFTLEdBQUcsQ0FBQyxhQUFhLEtBQUssa0JBQWtCLENBQUMsQ0FBQztRQUVuRCxJQUFJLElBQUksS0FBSyxRQUFRO1lBQUUsSUFBSSxDQUFDLGdCQUFnQixHQUFHLFNBQVMsQ0FBQzs7WUFDcEQsSUFBSSxDQUFDLGVBQWUsR0FBRyxTQUFTLENBQUM7UUFFdEMsSUFBSSxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsYUFBYSxDQUFDLGFBQWEsQ0FBQyxXQUFXLENBQUMsQ0FBQyxPQUFPLEdBQUcsU0FBUyxDQUFDO1FBQy9FLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxJQUFJLENBQUMsQ0FBQztRQUM1QixJQUFJLENBQUMsY0FBYyxHQUFHLElBQUksQ0FBQyxjQUFjLENBQUMsY0FBYyxDQUFDLElBQUksQ0FBQyxrQkFBa0IsRUFBRSxJQUFJLENBQUMsaUJBQWlCLENBQUMsQ0FBQztJQUM5RyxDQUFDO0lBRU8sa0JBQWtCLENBQUMsTUFBVyxFQUFFLElBQVksRUFBRSxTQUFrQjtRQUNwRSxJQUFJLFFBQVEsR0FBVyxHQUFHLEdBQUcsSUFBSSxHQUFHLENBQUMsQ0FBQyxJQUFJLENBQUMsVUFBVSxLQUFLLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxpQ0FBaUMsQ0FBQyxDQUFDLENBQUMsa0NBQWtDLENBQUMsQ0FBQztRQUM1SSxJQUFJLGFBQWEsR0FBZ0IsSUFBSSxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsYUFBYSxDQUFDLGFBQWEsQ0FBQyxRQUFRLENBQUMsQ0FBQztRQUN6RixJQUFJLFFBQVEsR0FBb0IsYUFBYSxDQUFDLGdCQUFnQixDQUFDLDBCQUEwQixDQUFDLENBQUM7UUFDM0YsSUFBSSxXQUFXLEdBQWdCLENBQUMsSUFBSSxLQUFLLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsa0JBQWtCLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxpQkFBaUIsQ0FBQztRQUN0RyxJQUFJLFFBQVEsR0FBYyxXQUFXLENBQUMsR0FBRyxDQUFDLFFBQVEsRUFBRSxDQUFDO1FBRXJELElBQUksSUFBSSxLQUFLLFFBQVE7WUFBRSxJQUFJLENBQUMsZ0JBQWdCLEdBQUcsU0FBUyxDQUFDOztZQUNwRCxJQUFJLENBQUMsZUFBZSxHQUFHLFNBQVMsQ0FBQztRQUV0QyxJQUFJLFNBQVMsR0FBWSxDQUFDLElBQUksS0FBSyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLGdCQUFnQixDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsZUFBZSxDQUFDO1FBQzVGLEtBQUssSUFBSSxDQUFDLEdBQVcsQ0FBQyxFQUFFLENBQUMsR0FBRyxRQUFRLENBQUMsV0FBVyxFQUFFLEVBQUUsQ0FBQyxFQUFFLEVBQUU7WUFDckQsUUFBUSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxjQUFjLENBQUMsU0FBUyxDQUFDLENBQUM7WUFDN0MsSUFBSSxPQUFPLFFBQVEsQ0FBQyxDQUFDLENBQUMsS0FBSyxXQUFXO2dCQUFFLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPLEdBQUcsU0FBUyxDQUFDO1NBQzNFO1FBQ0QsSUFBSSxDQUFDLGdCQUFnQixDQUFDLElBQUksQ0FBQyxDQUFDO1FBQzVCLElBQUksQ0FBQyxjQUFjLEdBQUcsSUFBSSxDQUFDLGNBQWMsQ0FBQyxjQUFjLENBQUMsSUFBSSxDQUFDLGtCQUFrQixFQUFFLElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxDQUFDO0lBQzlHLENBQUM7SUFFTyxnQkFBZ0IsQ0FBQyxXQUFtQjtRQUN4QyxJQUFJLFdBQVcsR0FBVyxDQUFDLFdBQVcsS0FBSyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsaUNBQWlDLENBQUMsQ0FBQyxDQUFDLGtDQUFrQyxDQUFDO1FBQzlILElBQUksVUFBVSxHQUFlLElBQUksQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLGFBQWEsQ0FBQyxnQkFBZ0IsQ0FBQyxXQUFXLENBQUMsQ0FBQztRQUMzRixJQUFJLENBQUMsY0FBYyxDQUFDLGdCQUFnQixDQUFDLFVBQVUsQ0FBQyxDQUFDO1FBQ2pELElBQUksV0FBVyxLQUFLLFFBQVEsRUFBRTtZQUMxQixJQUFJLENBQUMsaUJBQWlCLENBQUMsR0FBRyxDQUFDLFdBQVcsRUFBRSxDQUFDO1lBQ3pDLElBQUksQ0FBQyxlQUFlLEdBQUcsS0FBSyxDQUFDO1NBQ2hDO2FBQ0k7WUFDRCxJQUFJLENBQUMsa0JBQWtCLENBQUMsR0FBRyxDQUFDLFdBQVcsRUFBRSxDQUFDO1lBQzFDLElBQUksQ0FBQyxnQkFBZ0IsR0FBRyxLQUFLLENBQUM7U0FDakM7SUFDTCxDQUFDO0lBRU8sWUFBWSxDQUFDLElBQVksRUFBRSxLQUFhO1FBQzVDLElBQUksV0FBVyxHQUFXLGdCQUFnQixHQUFHLElBQUksQ0FBQztRQUNsRCxJQUFJLFVBQVUsR0FBZ0IsSUFBSSxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsYUFBYSxDQUFDLGFBQWEsQ0FBQyxXQUFXLENBQUMsQ0FBQztRQUN6RixJQUFJLEtBQUssS0FBSyxVQUFVLEVBQUU7WUFDdEIsSUFBSSxDQUFDLE9BQU8sQ0FBQyxRQUFRLENBQUMsVUFBVSxFQUFFLGlCQUFpQixDQUFDLENBQUM7WUFDckQsSUFBSSxDQUFDLE9BQU8sQ0FBQyxXQUFXLENBQUMsVUFBVSxFQUFFLGVBQWUsQ0FBQyxDQUFDO1NBQ3pEO2FBQ0ksSUFBSSxLQUFLLEtBQUssUUFBUSxFQUFFO1lBQ3pCLElBQUksQ0FBQyxPQUFPLENBQUMsUUFBUSxDQUFDLFVBQVUsRUFBRSxlQUFlLENBQUMsQ0FBQztZQUNuRCxJQUFJLENBQUMsT0FBTyxDQUFDLFdBQVcsQ0FBQyxVQUFVLEVBQUUsaUJBQWlCLENBQUMsQ0FBQztTQUMzRDtRQUNELFVBQVU7YUFDTDtZQUNELElBQUksQ0FBQyxPQUFPLENBQUMsV0FBVyxDQUFDLFVBQVUsRUFBRSxlQUFlLENBQUMsQ0FBQztZQUN0RCxJQUFJLENBQUMsT0FBTyxDQUFDLFdBQVcsQ0FBQyxVQUFVLEVBQUUsaUJBQWlCLENBQUMsQ0FBQztTQUMzRDtJQUNMLENBQUM7OztZQXZoQkosU0FBUyxTQUFDO2dCQUNQLFFBQVEsRUFBRSxzQkFBc0I7Z0JBQ2hDLDI1REFBa0Q7Z0JBQ2xELFNBQVMsRUFBRSxDQUFDLHFCQUFxQixFQUFFLFlBQVksRUFBRSxXQUFXLENBQUM7Z0JBQzdELGFBQWEsRUFBRSxpQkFBaUIsQ0FBQyxJQUFJO2dCQUNyQyxJQUFJLEVBQUcsRUFBRSxPQUFPLEVBQUcsdUJBQXVCLEVBQUU7YUFDL0M7OztZQVpRLHFCQUFxQjtZQUZyQixZQUFZO1lBSmlGLGdCQUFnQjtZQUErQixTQUFTO1lBS3JKLGVBQWU7WUFFZixXQUFXOzs7cUJBa0NmLEtBQUs7eUJBQ0wsS0FBSzt3QkFDTCxLQUFLOzRCQUNMLE1BQU07dUJBYU4sWUFBWSxTQUFDLGVBQWUsRUFBRSxDQUFDLFFBQVEsQ0FBQyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IENvbXBvbmVudCwgT25Jbml0LCBBZnRlclZpZXdJbml0LCBPbkRlc3Ryb3ksIElucHV0LCBPdXRwdXQsIEV2ZW50RW1pdHRlciwgVmlld0VuY2Fwc3VsYXRpb24sIFZpZXdDb250YWluZXJSZWYsIEhvc3RMaXN0ZW5lciwgU2ltcGxlQ2hhbmdlcywgUmVuZGVyZXIyIH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XHJcbmltcG9ydCB7IHRpbWVyICwgIFN1YnNjcmlwdGlvbiB9IGZyb20gJ3J4anMnO1xyXG5pbXBvcnQgeyBHcmlkT3B0aW9ucywgUm93Tm9kZSwgSVJvd01vZGVsLCBDb2x1bW4gfSBmcm9tICdhZy1ncmlkLWNvbW11bml0eSc7XHJcbmltcG9ydCAnYWctZ3JpZC1lbnRlcnByaXNlJztcclxuaW1wb3J0IHsgS2REb21FbGVtU3ZjLCBBR19HUklEX0tFWSB9IGZyb20gJy4uL2tkLWNvbW1vbi9pbmRleCc7XHJcbmltcG9ydCB7IEtkU3BsaXR0ZXJFdmVudCB9IGZyb20gJy4uL2tkLWFuZ3VsYXItc3BsaXR0ZXIvaW5kZXgnO1xyXG5pbXBvcnQgeyBLZE11bHRpU2VsZWN0VGFibGVTdmMgfSBmcm9tICcuL2tkLW11bHRpc2VsZWN0LXRhYmxlLXN2Yyc7XHJcbmltcG9ydCB7IEtkQWdncmlkU3ZjIH0gZnJvbSAnLi4va2QtYW5ndWxhci1hZ2dyaWQvc3JjL2tkLWFuZ3VsYXItYWdncmlkLXN2Yyc7XHJcbmltcG9ydCB7TGljZW5zZU1hbmFnZXJ9IGZyb20gXCJhZy1ncmlkLWVudGVycHJpc2VcIjtcclxuXHJcbmRlY2xhcmUgdmFyIHJlcXVpcmU6IGFueTtcclxuXHJcbkBDb21wb25lbnQoe1xyXG4gICAgc2VsZWN0b3I6ICdrZC1tdWx0aXNlbGVjdC10YWJsZScsXHJcbiAgICB0ZW1wbGF0ZVVybDogJy4va2QtYW5ndWxhci1tdWx0aXNlbGVjdC10YWJsZS5odG1sJyxcclxuICAgIHByb3ZpZGVyczogW0tkTXVsdGlTZWxlY3RUYWJsZVN2YywgS2REb21FbGVtU3ZjLCBLZEFnZ3JpZFN2Y10sXHJcbiAgICBlbmNhcHN1bGF0aW9uOiBWaWV3RW5jYXBzdWxhdGlvbi5Ob25lLFxyXG4gICAgaG9zdCA6IHsgJ2NsYXNzJyA6ICdrZHgtbXVsdGlzZWxlY3QtdGFibGUnIH1cclxufSlcclxuXHJcbmV4cG9ydCBjbGFzcyBLZE11bHRpU2VsZWN0VGFibGUgaW1wbGVtZW50cyBPbkluaXQsIEFmdGVyVmlld0luaXQsIE9uRGVzdHJveSB7XHJcbiAgICBwdWJsaWMgX21hc3RlclNlYXJjaDogc3RyaW5nID0gJyc7XHJcbiAgICBwdWJsaWMgX3NsYXZlU2VhcmNoOiBzdHJpbmcgPSAnJztcclxuICAgIHB1YmxpYyBfbWFzdGVyR3JpZE9wdGlvbnM6IEdyaWRPcHRpb25zO1xyXG4gICAgcHVibGljIF9zbGF2ZUdyaWRPcHRpb25zOiBHcmlkT3B0aW9ucztcclxuICAgIHB1YmxpYyBfZGlzYWJsZUJ1dHRvbjogYW55ID0ge307XHJcbiAgICBwdWJsaWMgX3BsYWNlaG9sZGVyOiBhbnkgPSB7fTtcclxuICAgIHB1YmxpYyBfYnV0dG9uczogYW55ID0ge307XHJcblxyXG4gICAgcHJpdmF0ZSBlbnRlcnByaXNlID0gcmVxdWlyZSgnYWctZ3JpZC1lbnRlcnByaXNlJyk7XHJcbiAgICBwcml2YXRlIF9tYXN0ZXJTZWxlY3RBbGw6IGJvb2xlYW4gPSBmYWxzZTtcclxuICAgIHByaXZhdGUgX3NsYXZlU2VsZWN0QWxsOiBib29sZWFuID0gZmFsc2U7XHJcbiAgICBwcml2YXRlIF9jb2xEZWZBcnJheVdpZHRoOiBBcnJheTx7d2lkdGg6IG51bWJlciwgaWQ6IHN0cmluZ30+ID0gW107XHJcbiAgICBwcml2YXRlIF9kaXJlY3Rpb246IHN0cmluZztcclxuICAgIHByaXZhdGUgX3ByaW1hcnlLZXk6IGFueTtcclxuICAgIHByaXZhdGUgX2ZpcnN0UnVuOiBib29sZWFuID0gdHJ1ZTtcclxuICAgIHByaXZhdGUgX21hc3RlckRhdGE6IEFycmF5PGFueT4gPSBbXTtcclxuICAgIHByaXZhdGUgX3NsYXZlRGF0YTogQXJyYXk8YW55PiA9IFtdO1xyXG4gICAgcHJpdmF0ZSBfc3BsaXR0ZXJDbGlja1N1YjogU3Vic2NyaXB0aW9uO1xyXG4gICAgcHJpdmF0ZSBfc3BsaXR0ZXJEcmFnU3ViOiBTdWJzY3JpcHRpb247XHJcblxyXG4gICAgQElucHV0KCkgY29uZmlnOiBhbnk7XHJcbiAgICBASW5wdXQoKSBtYXN0ZXJEYXRhOiBBcnJheTxhbnk+O1xyXG4gICAgQElucHV0KCkgc2xhdmVEYXRhOiBBcnJheTxhbnk+O1xyXG4gICAgQE91dHB1dCgpIHRvcEJvdHRvbURhdGE6IEV2ZW50RW1pdHRlcjxhbnk+ID0gbmV3IEV2ZW50RW1pdHRlcigpO1xyXG5cclxuICAgIGNvbnN0cnVjdG9yKFxyXG4gICAgICAgIHByaXZhdGUgX211bHRpVGFibGVTdmM6IEtkTXVsdGlTZWxlY3RUYWJsZVN2YyxcclxuICAgICAgICBwcml2YXRlIF9kb21TdmM6IEtkRG9tRWxlbVN2YyxcclxuICAgICAgICBwcml2YXRlIF92Y3I6IFZpZXdDb250YWluZXJSZWYsXHJcbiAgICAgICAgcHJpdmF0ZSBfcmVuZGVyZXI6IFJlbmRlcmVyMixcclxuICAgICAgICBwcml2YXRlIF9zcGxpdHRlckV2ZW50OiBLZFNwbGl0dGVyRXZlbnQsXHJcbiAgICAgICAgcHJpdmF0ZSBfYWdncmlkU3ZjOiBLZEFnZ3JpZFN2Y1xyXG4gICAgKSB7XHJcbiAgICAgICAgTGljZW5zZU1hbmFnZXIuc2V0TGljZW5zZUtleShBR19HUklEX0tFWS52YWx1ZSk7XHJcbiAgICB9XHJcblxyXG4gICAgQEhvc3RMaXN0ZW5lcignd2luZG93OnJlc2l6ZScsIFsnJGV2ZW50J10pXHJcbiAgICBvblJlc2l6ZShlOiBFdmVudCkge1xyXG4gICAgICAgIHRoaXMuX3NldFZpZXcoKTtcclxuICAgIH1cclxuXHJcbiAgICBuZ09uSW5pdCgpOiB2b2lkIHtcclxuICAgICAgICB0aGlzLl9kaXJlY3Rpb24gPSAodGhpcy5fZG9tU3ZjLmdldERvY3VtZW50RGlyZWN0aW9uKHRydWUpKTtcclxuICAgICAgICB0aGlzLl9tYXN0ZXJEYXRhID0gKHR5cGVvZiB0aGlzLm1hc3RlckRhdGEgIT09ICd1bmRlZmluZWQnKSA/IHRoaXMubWFzdGVyRGF0YS5zbGljZSgpIDogW107XHJcbiAgICAgICAgdGhpcy5fc2xhdmVEYXRhID0gKHR5cGVvZiB0aGlzLnNsYXZlRGF0YSAhPT0gJ3VuZGVmaW5lZCcpID8gdGhpcy5zbGF2ZURhdGEuc2xpY2UoKSA6IFtdO1xyXG4gICAgICAgIHRoaXMuX3NldEdyaWRPcHRpb25zKCk7XHJcblxyXG4gICAgICAgIHRoaXMuX3NwbGl0dGVyQ2xpY2tTdWIgPSB0aGlzLl9zcGxpdHRlckV2ZW50Lm9uVG9nZ2xlTWVudSgpLnN1YnNjcmliZSgoKTogdm9pZCA9PiB7XHJcbiAgICAgICAgICAgIHRpbWVyKDcwMCkuc3Vic2NyaWJlKCgpOiB2b2lkID0+IHtcclxuICAgICAgICAgICAgICAgIHRoaXMuX3NldFZpZXcoKTtcclxuICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgfSk7XHJcblxyXG4gICAgICAgIHRoaXMuX3NwbGl0dGVyRHJhZ1N1YiA9IHRoaXMuX3NwbGl0dGVyRXZlbnQub25EcmFnKCkuc3Vic2NyaWJlKCgpOiB2b2lkID0+IHtcclxuICAgICAgICAgICAgdGltZXIoMjAwKS5zdWJzY3JpYmUoKCk6IHZvaWQgPT4ge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5fc2V0VmlldygpO1xyXG4gICAgICAgICAgICB9KTtcclxuICAgICAgICB9KTtcclxuXHJcbiAgICAgICAgbGV0IGN1cnJlbnRTZWxlY3Rpb246IGFueSA9IHt9O1xyXG5cclxuICAgICAgICB0aGlzLl9tYXN0ZXJHcmlkT3B0aW9ucy5lbmFibGVSdGwgPSB0aGlzLl9kaXJlY3Rpb24gPT09ICdyaWdodCc7XHJcbiAgICAgICAgdGhpcy5fc2xhdmVHcmlkT3B0aW9ucy5lbmFibGVSdGwgPSB0aGlzLl9kaXJlY3Rpb24gPT09ICdyaWdodCc7XHJcblxyXG4gICAgICAgIGN1cnJlbnRTZWxlY3Rpb24udG9wR3JpZCA9IHRoaXMuX21hc3RlckdyaWRPcHRpb25zLnJvd0RhdGE7XHJcbiAgICAgICAgY3VycmVudFNlbGVjdGlvbi5ib3R0b21HcmlkID0gdGhpcy5fc2xhdmVHcmlkT3B0aW9ucy5yb3dEYXRhO1xyXG4gICAgICAgIHRpbWVyKCkuc3Vic2NyaWJlKCgpOiB2b2lkID0+IHtcclxuICAgICAgICAgICAgdGhpcy50b3BCb3R0b21EYXRhLmVtaXQoY3VycmVudFNlbGVjdGlvbik7XHJcbiAgICAgICAgfSk7XHJcbiAgICB9XHJcblxyXG4gICAgbmdPbkNoYW5nZXMoX3NpbXBsZUNoYW5nZTogU2ltcGxlQ2hhbmdlcyk6IHZvaWQge1xyXG4gICAgICAgIGlmICghdGhpcy5fZmlyc3RSdW4pIHtcclxuICAgICAgICAgICAgaWYgKF9zaW1wbGVDaGFuZ2UuaGFzT3duUHJvcGVydHkoJ21hc3RlckRhdGEnKSkge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5fbWFzdGVyR3JpZE9wdGlvbnMucm93RGF0YSA9IF9zaW1wbGVDaGFuZ2VbJ21hc3RlckRhdGEnXS5jdXJyZW50VmFsdWU7XHJcbiAgICAgICAgICAgICAgICB0aGlzLl9tYXN0ZXJHcmlkT3B0aW9ucy5hcGkuc2V0Um93RGF0YShfc2ltcGxlQ2hhbmdlWydtYXN0ZXJEYXRhJ10uY3VycmVudFZhbHVlKTtcclxuICAgICAgICAgICAgICAgIHRoaXMuX2VtaXREYXRhKCk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgaWYgKF9zaW1wbGVDaGFuZ2UuaGFzT3duUHJvcGVydHkoJ3NsYXZlRGF0YScpKSB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLl9zbGF2ZUdyaWRPcHRpb25zLnJvd0RhdGEgPSBfc2ltcGxlQ2hhbmdlWydzbGF2ZURhdGEnXS5jdXJyZW50VmFsdWU7XHJcbiAgICAgICAgICAgICAgICB0aGlzLl9zbGF2ZUdyaWRPcHRpb25zLmFwaS5zZXRSb3dEYXRhKF9zaW1wbGVDaGFuZ2VbJ3NsYXZlRGF0YSddLmN1cnJlbnRWYWx1ZSk7XHJcbiAgICAgICAgICAgICAgICB0aGlzLl9lbWl0RGF0YSgpO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIG5nQWZ0ZXJWaWV3SW5pdCgpOiB2b2lkIHtcclxuICAgICAgICBpZiAodGhpcy5fbWFzdGVyR3JpZE9wdGlvbnMucm93RGF0YS5sZW5ndGggPT09IDApIHtcclxuICAgICAgICAgICAgdGhpcy5fbWFzdGVyR3JpZE9wdGlvbnMuYXBpLnNob3dOb1Jvd3NPdmVybGF5KCk7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICBpZiAodGhpcy5fc2xhdmVHcmlkT3B0aW9ucy5yb3dEYXRhLmxlbmd0aCA9PT0gMCkge1xyXG4gICAgICAgICAgICB0aGlzLl9zbGF2ZUdyaWRPcHRpb25zLmFwaS5zaG93Tm9Sb3dzT3ZlcmxheSgpO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgdGhpcy5fdXBkYXRlTm9EYXRhQ2xhc3MoKTtcclxuICAgICAgICB0aGlzLl9tYXN0ZXJHcmlkT3B0aW9ucy5jb2x1bW5BcGkuYXV0b1NpemVBbGxDb2x1bW5zKCk7XHJcbiAgICAgICAgdGhpcy5fY29sRGVmQXJyYXlXaWR0aCA9IHRoaXMuX2FnZ3JpZFN2Yy5jYWxjQ29sV2lkdGgodGhpcy5fbWFzdGVyR3JpZE9wdGlvbnMpO1xyXG5cclxuICAgICAgICB0aW1lcigzMDApLnN1YnNjcmliZSgoKTogdm9pZCA9PiB7XHJcbiAgICAgICAgICAgIHRoaXMuX3NldFZpZXcoKTtcclxuICAgICAgICB9KTtcclxuXHJcbiAgICAgICAgdGhpcy5fZmlyc3RSdW4gPSBmYWxzZTtcclxuICAgIH1cclxuXHJcbiAgICBuZ09uRGVzdHJveSgpOiB2b2lkIHtcclxuICAgICAgICB0aGlzLl9zcGxpdHRlckRyYWdTdWIudW5zdWJzY3JpYmUoKTtcclxuICAgICAgICB0aGlzLl9zcGxpdHRlckNsaWNrU3ViLnVuc3Vic2NyaWJlKCk7XHJcbiAgICB9XHJcblxyXG4gICAgYXNzaWduKF90YXJnZXQ6IHN0cmluZyk6IHZvaWQge1xyXG4gICAgICAgIGlmIChfdGFyZ2V0ID09PSAndG9Ub3AnKSB7XHJcbiAgICAgICAgICAgIHRoaXMuX3VwZGF0ZVJvd0RhdGEodGhpcy5fc2xhdmVHcmlkT3B0aW9ucywgdGhpcy5fbWFzdGVyR3JpZE9wdGlvbnMpO1xyXG4gICAgICAgIH1cclxuICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgdGhpcy5fdXBkYXRlUm93RGF0YSh0aGlzLl9tYXN0ZXJHcmlkT3B0aW9ucywgdGhpcy5fc2xhdmVHcmlkT3B0aW9ucyk7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICBpZiAodGhpcy5fZG9tU3ZjLmlzTW9iaWxlKCkpIHtcclxuICAgICAgICAgICAgdGhpcy5fc2V0SGVpZ2h0KHRydWUpO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICByZXNldFNlYXJjaChfZTogRXZlbnQsIF9ncmlkOiBzdHJpbmcpOiB2b2lkIHtcclxuICAgICAgICBfZS5zdG9wUHJvcGFnYXRpb24oKTtcclxuXHJcbiAgICAgICAgbGV0IGlzTW9iaWxlOiBib29sZWFuID0gdGhpcy5fZG9tU3ZjLmlzTW9iaWxlKCk7XHJcbiAgICAgICAgbGV0IHNlYXJjaDogc3RyaW5nID0gKF9ncmlkID09PSAndG9wJykgPyB0aGlzLl9tYXN0ZXJTZWFyY2ggOiB0aGlzLl9zbGF2ZVNlYXJjaDtcclxuXHJcbiAgICAgICAgaWYgKGlzTW9iaWxlICYmIHNlYXJjaC5sZW5ndGggPT09IDApIHtcclxuICAgICAgICAgICAgdGhpcy5fc2VhcmNoU3RhdGUoX2dyaWQsICdjb2xsYXBzZScpO1xyXG4gICAgICAgIH1cclxuICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgaWYgKF9ncmlkID09PSAndG9wJykge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5fbWFzdGVyU2VhcmNoID0gJyc7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgZWxzZSB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLl9zbGF2ZVNlYXJjaCA9ICcnO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICB0aGlzLmZpbHRlckNoYW5nZWQoX2dyaWQpO1xyXG4gICAgfVxyXG5cclxuICAgIGZpbHRlckNoYW5nZWQoX2dyaWQ6IHN0cmluZyk6IHZvaWQge1xyXG4gICAgICAgIGxldCBpc01vYmlsZTogYm9vbGVhbiA9IHRoaXMuX2RvbVN2Yy5pc01vYmlsZSgpO1xyXG4gICAgICAgIGxldCBncmlkRmlsdGVyT3B0aW9uczogR3JpZE9wdGlvbnM7XHJcbiAgICAgICAgbGV0IHNlYXJjaDogc3RyaW5nID0gJyc7XHJcblxyXG4gICAgICAgIGlmIChfZ3JpZCA9PT0gJ3RvcCcpIHtcclxuICAgICAgICAgICAgZ3JpZEZpbHRlck9wdGlvbnMgPSB0aGlzLl9tYXN0ZXJHcmlkT3B0aW9ucztcclxuICAgICAgICAgICAgc2VhcmNoID0gdGhpcy5fbWFzdGVyU2VhcmNoO1xyXG4gICAgICAgIH1cclxuICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgZ3JpZEZpbHRlck9wdGlvbnMgPSB0aGlzLl9zbGF2ZUdyaWRPcHRpb25zO1xyXG4gICAgICAgICAgICBzZWFyY2ggPSB0aGlzLl9zbGF2ZVNlYXJjaDtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIGdyaWRGaWx0ZXJPcHRpb25zLmFwaS5zZXRRdWlja0ZpbHRlcihzZWFyY2gpO1xyXG5cclxuICAgICAgICBpZiAoaXNNb2JpbGUpIHtcclxuICAgICAgICAgICAgdGhpcy5fc2V0SGVpZ2h0KGlzTW9iaWxlKTtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIHRoaXMuX211bHRpVGFibGVTdmMuY2hlY2tPdmVybGF5KHRoaXMuX21hc3RlckdyaWRPcHRpb25zLCB0aGlzLl9zbGF2ZUdyaWRPcHRpb25zKTtcclxuICAgIH1cclxuXHJcbiAgICBzb3J0R3JpZCgpOiB2b2lkIHtcclxuICAgICAgICBsZXQgc29ydE1vZGVsOiBhbnkgPSB0aGlzLl9tYXN0ZXJHcmlkT3B0aW9ucy5hcGkuZ2V0U29ydE1vZGVsKCk7XHJcbiAgICAgICAgdGhpcy5fc2xhdmVHcmlkT3B0aW9ucy5hcGkuc2V0U29ydE1vZGVsKHNvcnRNb2RlbCk7XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfc2V0VmlldygpOiB2b2lkIHtcclxuICAgICAgICBsZXQgaXNNb2JpbGUgPSB0aGlzLl9kb21TdmMuaXNNb2JpbGUoKTtcclxuICAgICAgICB0aGlzLl9zZXRTZWFyY2hTdGF0ZShpc01vYmlsZSk7XHJcbiAgICAgICAgdGhpcy5fc2V0Q29sV2lkdGgoKTtcclxuICAgICAgICB0aGlzLl9zZXRIZWlnaHQoaXNNb2JpbGUpO1xyXG4gICAgICAgIHRoaXMuX3NldENsaWNrU2VhcmNoKGlzTW9iaWxlKTtcclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF9zZXRTZWFyY2hTdGF0ZShfaXNNb2JpbGU6IGJvb2xlYW4pOiB2b2lkIHtcclxuICAgICAgICBpZiAoX2lzTW9iaWxlKSB7XHJcbiAgICAgICAgICAgIGxldCBzZWFyY2g6IEFycmF5PEhUTUxFbGVtZW50PiA9IFtdO1xyXG5cclxuICAgICAgICAgICAgc2VhcmNoLnB1c2godGhpcy5fdmNyLmVsZW1lbnQubmF0aXZlRWxlbWVudC5xdWVyeVNlbGVjdG9yKCcuc2VhcmNoLXRhYmxlLXRvcCcpKTtcclxuICAgICAgICAgICAgc2VhcmNoLnB1c2godGhpcy5fdmNyLmVsZW1lbnQubmF0aXZlRWxlbWVudC5xdWVyeVNlbGVjdG9yKCcuc2VhcmNoLXRhYmxlLWJvdHRvbScpKTtcclxuXHJcbiAgICAgICAgICAgIGZvciAobGV0IGk6IG51bWJlciA9IDA7IGkgPCBzZWFyY2gubGVuZ3RoOyBpKyspIHtcclxuICAgICAgICAgICAgICAgIGxldCBpc0N1cnJlbnRTdGF0ZUV4aXN0OiBib29sZWFuID0gc2VhcmNoW2ldLmNsYXNzTGlzdC5jb250YWlucygnY29sbGFwc2Utc2VhcmNoJykgfHwgc2VhcmNoW2ldLmNsYXNzTGlzdC5jb250YWlucygnZXhwYW5kLXNlYXJjaCcpO1xyXG5cclxuICAgICAgICAgICAgICAgIGlmICghaXNDdXJyZW50U3RhdGVFeGlzdCkge1xyXG4gICAgICAgICAgICAgICAgICAgIGxldCBncmlkOiBzdHJpbmc7XHJcbiAgICAgICAgICAgICAgICAgICAgbGV0IHNlYXJjaFN0cmluZzogc3RyaW5nO1xyXG5cclxuICAgICAgICAgICAgICAgICAgICBpZiAoaSA9PT0gMCkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBncmlkID0gJ3RvcCc7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHNlYXJjaFN0cmluZyA9IHRoaXMuX21hc3RlclNlYXJjaDtcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgZWxzZSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGdyaWQgPSAnYm90dG9tJztcclxuICAgICAgICAgICAgICAgICAgICAgICAgc2VhcmNoU3RyaW5nID0gdGhpcy5fc2xhdmVTZWFyY2g7XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgICAgICAgICBpZiAoc2VhcmNoU3RyaW5nID09PSAnJykge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLl9zZWFyY2hTdGF0ZShncmlkLCAnY29sbGFwc2UnKTtcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgZWxzZSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuX3NlYXJjaFN0YXRlKGdyaWQsICdleHBhbmQnKTtcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICAgICAgZWxzZSB7XHJcbiAgICAgICAgICAgIHRoaXMuX3NlYXJjaFN0YXRlKCd0b3AnLCAncmVzZXQnKTtcclxuICAgICAgICAgICAgdGhpcy5fc2VhcmNoU3RhdGUoJ2JvdHRvbScsICdyZXNldCcpO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF91cGRhdGVOb0RhdGFDbGFzcygpOiB2b2lkIHtcclxuICAgICAgICB0aGlzLl9zZXROb0RhdGEoJ3RvcCcpO1xyXG4gICAgICAgIHRoaXMuX3NldE5vRGF0YSgnYm90dG9tJyk7XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfc2V0Tm9EYXRhKF9ncmlkOiBzdHJpbmcpOiB2b2lkIHtcclxuICAgICAgICBsZXQgcXVlcnlTdHJpbmc6IHN0cmluZyA9ICcuc2VhcmNoLXRhYmxlLScgKyBfZ3JpZCArICcgaW5wdXQuc2VhcmNoLScgKyBfZ3JpZDtcclxuICAgICAgICBsZXQgY2hlY2tHcmlkOiBHcmlkT3B0aW9ucyA9IChfZ3JpZCA9PT0gJ3RvcCcpID8gdGhpcy5fbWFzdGVyR3JpZE9wdGlvbnMgOiB0aGlzLl9zbGF2ZUdyaWRPcHRpb25zO1xyXG4gICAgICAgIGxldCBpbnB1dEVsZTogSFRNTEVsZW1lbnQgPSB0aGlzLl92Y3IuZWxlbWVudC5uYXRpdmVFbGVtZW50LnF1ZXJ5U2VsZWN0b3IocXVlcnlTdHJpbmcpO1xyXG5cclxuICAgICAgICBpZiAoY2hlY2tHcmlkLnJvd0RhdGEubGVuZ3RoID09PSAwKSB7XHJcbiAgICAgICAgICAgIHRoaXMuX2RvbVN2Yy5hZGRDbGFzcyhpbnB1dEVsZSwgJ25vLWRhdGEnKTtcclxuICAgICAgICB9XHJcbiAgICAgICAgZWxzZSB7XHJcbiAgICAgICAgICAgIHRoaXMuX2RvbVN2Yy5yZW1vdmVDbGFzcyhpbnB1dEVsZSwgJ25vLWRhdGEnKTtcclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfc2V0Q29sV2lkdGgoKTogdm9pZCB7XHJcbiAgICAgICAgbGV0IHVzYWJsZVdpZHRoOiBudW1iZXIgPSB0aGlzLl9hZ2dyaWRTdmMuY2FsY1VzYWJsZVdpZHRoKHRoaXMuX3Zjcik7XHJcblxyXG4gICAgICAgIGlmICh0aGlzLl9tYXN0ZXJHcmlkT3B0aW9ucy5jb2x1bW5BcGkgIT09IG51bGwpIHtcclxuICAgICAgICAgICAgbGV0IHRvdGFsV2lkdGg6IG51bWJlciA9IHRoaXMuX2FnZ3JpZFN2Yy5jb2xUb3RhbFdpZHRoKHRoaXMuX2NvbERlZkFycmF5V2lkdGgsIHRoaXMuX21hc3RlckdyaWRPcHRpb25zLmNvbHVtbkFwaS5nZXRBbGxDb2x1bW5zKCkpO1xyXG5cclxuICAgICAgICAgICAgaWYgKHRoaXMuX21hc3RlckdyaWRPcHRpb25zLmNvbHVtbkFwaSAhPT0gbnVsbCkge1xyXG4gICAgICAgICAgICAgICAgbGV0IGNvbERlZjogQXJyYXk8Q29sdW1uPiA9IHRoaXMuX21hc3RlckdyaWRPcHRpb25zLmNvbHVtbkFwaS5nZXRBbGxDb2x1bW5zKCk7XHJcbiAgICAgICAgICAgICAgICBsZXQgZXh0cmFQZXJDb2w6IG51bWJlciA9IDA7XHJcblxyXG4gICAgICAgICAgICAgICAgaWYgKHRvdGFsV2lkdGggPCB1c2FibGVXaWR0aCkge1xyXG4gICAgICAgICAgICAgICAgICAgIGxldCBsZWZ0b3ZlcldpZHRoOiBudW1iZXIgPSB1c2FibGVXaWR0aCAtIHRvdGFsV2lkdGg7XHJcbiAgICAgICAgICAgICAgICAgICAgZXh0cmFQZXJDb2wgPSBsZWZ0b3ZlcldpZHRoIC8gKHRoaXMuX2NvbERlZkFycmF5V2lkdGgubGVuZ3RoIC0gMSk7XHJcbiAgICAgICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICAgICAgZm9yIChsZXQgaTogbnVtYmVyID0gMDsgaSA8IHRoaXMuX2NvbERlZkFycmF5V2lkdGgubGVuZ3RoOyBpKyspIHtcclxuICAgICAgICAgICAgICAgICAgICBsZXQgd2lkdGg6IG51bWJlciA9IChjb2xEZWZbaV0uZ2V0Q29sSWQoKSA9PT0gJ2NoZWNrYm94JykgPyB0aGlzLl9jb2xEZWZBcnJheVdpZHRoW2ldLndpZHRoIDogdGhpcy5fY29sRGVmQXJyYXlXaWR0aFtpXS53aWR0aCArIGV4dHJhUGVyQ29sO1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuX21hc3RlckdyaWRPcHRpb25zLmNvbHVtbkFwaS5zZXRDb2x1bW5XaWR0aChjb2xEZWZbaV0sIHdpZHRoKTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF9zZXRDbGlja1NlYXJjaChfaXNNb2JpbGU6IGJvb2xlYW4pOiB2b2lkIHtcclxuICAgICAgICBsZXQgdGFibGVUb3A6IEhUTUxFbGVtZW50ID0gdGhpcy5fdmNyLmVsZW1lbnQubmF0aXZlRWxlbWVudC5xdWVyeVNlbGVjdG9yKCcuc2VhcmNoLXRhYmxlLXRvcCcpO1xyXG4gICAgICAgIGxldCB0YWJsZUJvdHRvbTogSFRNTEVsZW1lbnQgPSB0aGlzLl92Y3IuZWxlbWVudC5uYXRpdmVFbGVtZW50LnF1ZXJ5U2VsZWN0b3IoJy5zZWFyY2gtdGFibGUtYm90dG9tJyk7XHJcblxyXG4gICAgICAgIGlmIChfaXNNb2JpbGUpIHtcclxuICAgICAgICAgICAgdGhpcy5fcmVuZGVyZXIubGlzdGVuKHRhYmxlVG9wLCAnY2xpY2snLCAoX2U6IEV2ZW50KTogdm9pZCA9PiB7XHJcbiAgICBpZiAodGFibGVUb3AuY2xhc3NMaXN0LmNvbnRhaW5zKCdjb2xsYXBzZS1zZWFyY2gnKSkge1xyXG4gICAgICAgIHRoaXMuX3NlYXJjaFN0YXRlKCd0b3AnLCAnZXhwYW5kJyk7XHJcbiAgICB9XHJcbn0pO1xyXG5cclxuICAgICAgICAgICAgdGhpcy5fcmVuZGVyZXIubGlzdGVuKHRhYmxlQm90dG9tLCAnY2xpY2snLCAoX2U6IEV2ZW50KTogdm9pZCA9PiB7XHJcbiAgICBpZiAodGFibGVCb3R0b20uY2xhc3NMaXN0LmNvbnRhaW5zKCdjb2xsYXBzZS1zZWFyY2gnKSkge1xyXG4gICAgICAgIHRoaXMuX3NlYXJjaFN0YXRlKCdib3R0b20nLCAnZXhwYW5kJyk7XHJcbiAgICB9XHJcbn0pO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF9zZXRHcmlkT3B0aW9ucygpOiB2b2lkIHtcclxuICAgICAgICBsZXQgc2V0dGluZ3M6IGFueSA9IHRoaXMuX211bHRpVGFibGVTdmMuZ2V0Qm90aE9wdGlvbnModGhpcy5jb25maWcsIHRoaXMuX21hc3RlckRhdGEsIHRoaXMuX3NsYXZlRGF0YSk7XHJcbiAgICAgICAgdGhpcy5fcHJpbWFyeUtleSA9IHRoaXMuX211bHRpVGFibGVTdmMuZ2V0UHJpbWFyeWtleSh0aGlzLmNvbmZpZyk7XHJcblxyXG4gICAgICAgIHRoaXMuX21hc3RlckdyaWRPcHRpb25zID0gc2V0dGluZ3MubWFzdGVyR3JpZE9wdGlvbjtcclxuICAgICAgICB0aGlzLl9zbGF2ZUdyaWRPcHRpb25zID0gc2V0dGluZ3Muc2xhdmVHcmlkT3B0aW9uO1xyXG4gICAgICAgIHRoaXMuX21hc3RlckdyaWRPcHRpb25zLmFsaWduZWRHcmlkcyA9IFt0aGlzLl9zbGF2ZUdyaWRPcHRpb25zXTtcclxuICAgICAgICB0aGlzLl9zbGF2ZUdyaWRPcHRpb25zLmFsaWduZWRHcmlkcyA9IFt0aGlzLl9tYXN0ZXJHcmlkT3B0aW9uc107XHJcblxyXG4gICAgICAgIHRoaXMuX2Rpc2FibGVCdXR0b24udG9wID0gdHJ1ZTtcclxuICAgICAgICB0aGlzLl9kaXNhYmxlQnV0dG9uLmJvdHRvbSA9IHRydWU7XHJcblxyXG4gICAgICAgIHRoaXMuX3BsYWNlaG9sZGVyLnRvcCA9IHRoaXMuX211bHRpVGFibGVTdmMuZ2V0UGxhY2Vob2xkZXIodGhpcy5jb25maWcsICd0b3AnKTtcclxuICAgICAgICB0aGlzLl9wbGFjZWhvbGRlci5ib3R0b20gPSB0aGlzLl9tdWx0aVRhYmxlU3ZjLmdldFBsYWNlaG9sZGVyKHRoaXMuY29uZmlnLCAnYm90dG9tJyk7XHJcblxyXG4gICAgICAgIHRoaXMuX2J1dHRvbnMudG9Ub3AgPSB0aGlzLl9tdWx0aVRhYmxlU3ZjLmdldEJ1dHRvbih0aGlzLmNvbmZpZywgJ3RvVG9wQnRuJyk7XHJcbiAgICAgICAgdGhpcy5fYnV0dG9ucy50b0JvdHRvbSA9IHRoaXMuX211bHRpVGFibGVTdmMuZ2V0QnV0dG9uKHRoaXMuY29uZmlnLCAndG9Cb3R0b21CdG4nKTtcclxuXHJcbiAgICAgICAgdGhpcy5fc2V0Q29sRGVmRmxvYXRpbmcoJ21hc3RlcicpO1xyXG4gICAgICAgIHRoaXMuX3NldENvbERlZkZsb2F0aW5nKCdzbGF2ZScpO1xyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX3NldENvbERlZkZsb2F0aW5nKF9ncmlkOiBzdHJpbmcpOiB2b2lkIHtcclxuICAgICAgICBsZXQgbmV3S2RBZ0dyaWRTdmM6IEtkQWdncmlkU3ZjID0gbmV3IEtkQWdncmlkU3ZjKCk7XHJcbiAgICAgICAgdGhpcy5fc2V0RmxvYXRpbmdUb3AoX2dyaWQpO1xyXG5cclxuICAgICAgICBsZXQgZ2VuZXJpY0dyaWQ6IEdyaWRPcHRpb25zID0gKF9ncmlkID09PSAnbWFzdGVyJykgPyB0aGlzLl9tYXN0ZXJHcmlkT3B0aW9ucyA6IHRoaXMuX3NsYXZlR3JpZE9wdGlvbnM7XHJcbiAgICAgICAgbGV0IGNvbERlZjogYW55ID0gbmV3S2RBZ0dyaWRTdmMuc2V0Q29sRGVmcyh0aGlzLmNvbmZpZy5jb2xEZWYsIGdlbmVyaWNHcmlkKTtcclxuICAgICAgICBjb2xEZWYudXBkYXRlZENvbERlZi51bnNoaWZ0KHRoaXMuX3NldENoZWNrYm94KF9ncmlkKSk7XHJcbiAgICAgICAgZ2VuZXJpY0dyaWQuY29sdW1uRGVmcyA9IGNvbERlZi51cGRhdGVkQ29sRGVmO1xyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX3VwZGF0ZVJvd0RhdGEoX2Zyb21HcmlkOiBHcmlkT3B0aW9ucywgX3RvR3JpZDogR3JpZE9wdGlvbnMpOiB2b2lkIHtcclxuICAgICAgICBsZXQgc2VsZWN0ZWROb2RlczogQXJyYXk8Um93Tm9kZT4gPSBfZnJvbUdyaWQuYXBpLmdldFNlbGVjdGVkTm9kZXMoKTtcclxuICAgICAgICBsZXQgb2Zmc2V0OiBudW1iZXIgPSAwO1xyXG5cclxuICAgICAgICBmb3IgKGxldCBpOiBudW1iZXIgPSAwOyBpIDwgc2VsZWN0ZWROb2Rlcy5sZW5ndGg7IGkrKykge1xyXG4gICAgICAgICAgICBzZWxlY3RlZE5vZGVzW2ldLmRhdGEubmV3Um93ID0gdHJ1ZTtcclxuXHJcbiAgICAgICAgICAgIF90b0dyaWQucm93RGF0YS5wdXNoKHNlbGVjdGVkTm9kZXNbaV0uZGF0YSk7XHJcbiAgICAgICAgICAgIF9mcm9tR3JpZC5yb3dEYXRhLnNwbGljZShwYXJzZUludChzZWxlY3RlZE5vZGVzW2ldLmlkKSAtIG9mZnNldCwgMSk7XHJcblxyXG4gICAgICAgICAgICBvZmZzZXQrKztcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIF90b0dyaWQuYXBpLnNldFJvd0RhdGEoX3RvR3JpZC5yb3dEYXRhKTtcclxuICAgICAgICBfZnJvbUdyaWQuYXBpLnNldFJvd0RhdGEoX2Zyb21HcmlkLnJvd0RhdGEpO1xyXG5cclxuICAgICAgICBsZXQgbmV3Um93OiBudW1iZXIgPSAtMTtcclxuICAgICAgICBfdG9HcmlkLmFwaS5mb3JFYWNoTm9kZUFmdGVyRmlsdGVyKChfbm9kZTogUm93Tm9kZSk6IHZvaWQgPT4ge1xyXG4gICAgICAgICAgICBpZiAoc2VsZWN0ZWROb2Rlc1swXS5kYXRhW3RoaXMuX3ByaW1hcnlLZXldID09PSBfbm9kZS5kYXRhW3RoaXMuX3ByaW1hcnlLZXldKSB7XHJcbiAgICAgICAgICAgICAgICBuZXdSb3cgPSBfbm9kZS5jaGlsZEluZGV4O1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfSk7XHJcblxyXG4gICAgICAgIF90b0dyaWQuYXBpLmVuc3VyZUluZGV4VmlzaWJsZShuZXdSb3cpO1xyXG5cclxuICAgICAgICB0aGlzLl9kaXNhYmxlQnV0dG9uID0gdGhpcy5fbXVsdGlUYWJsZVN2Yy5jaGVja1NlbGVjdGlvbih0aGlzLl9tYXN0ZXJHcmlkT3B0aW9ucywgdGhpcy5fc2xhdmVHcmlkT3B0aW9ucyk7XHJcbiAgICAgICAgdGhpcy5fdXBkYXRlTm9EYXRhQ2xhc3MoKTtcclxuICAgICAgICB0aGlzLl9zZXRDaGVja2JveEFmdGVyVXBkYXRlKCk7XHJcbiAgICAgICAgdGhpcy5fZW1pdERhdGEoKTtcclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF9zZXRDaGVja2JveEFmdGVyVXBkYXRlKCk6IHZvaWQge1xyXG4gICAgICAgIHRoaXMuX21hc3RlclNlbGVjdEFsbCA9IGZhbHNlO1xyXG4gICAgICAgIHRoaXMuX3NsYXZlU2VsZWN0QWxsID0gZmFsc2U7XHJcbiAgICAgICAgdGhpcy5fbXVsdGlUYWJsZVN2Yy5zZXRDaGVja2JveEZhbHNlQWZ0ZXJVcGRhdGUodGhpcy5fdmNyKTtcclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF9lbWl0RGF0YSgpOiB2b2lkIHtcclxuICAgICAgICBsZXQgY3VycmVudFNlbGVjdGlvbjogYW55ID0ge307XHJcbiAgICAgICAgY3VycmVudFNlbGVjdGlvbi50b3BHcmlkID0gdGhpcy5fbWFzdGVyR3JpZE9wdGlvbnMucm93RGF0YTtcclxuICAgICAgICBjdXJyZW50U2VsZWN0aW9uLmJvdHRvbUdyaWQgPSB0aGlzLl9zbGF2ZUdyaWRPcHRpb25zLnJvd0RhdGE7XHJcbiAgICAgICAgdGhpcy50b3BCb3R0b21EYXRhLmVtaXQoY3VycmVudFNlbGVjdGlvbik7XHJcbiAgICB9XHJcblxyXG4gICAgLy8gcHJpdmF0ZSBfZ2V0Um93RGF0YSgpOiB2b2lkIHtcclxuXHJcbiAgICAvLyB9XHJcblxyXG4gICAgcHJpdmF0ZSBfc2V0RmxvYXRpbmdUb3AoX2dyaWQ6IHN0cmluZyk6IHZvaWQge1xyXG4gICAgICAgIGxldCBncmlkT3B0aW9uczogR3JpZE9wdGlvbnM7XHJcbiAgICAgICAgbGV0IHNlbGVjdEFsbENoZWNrOiBib29sZWFuO1xyXG5cclxuICAgICAgICBpZiAoX2dyaWQgPT09ICdtYXN0ZXInKSB7XHJcbiAgICAgICAgICAgIGdyaWRPcHRpb25zID0gdGhpcy5fbWFzdGVyR3JpZE9wdGlvbnM7XHJcbiAgICAgICAgICAgIHNlbGVjdEFsbENoZWNrID0gdGhpcy5fbWFzdGVyU2VsZWN0QWxsO1xyXG4gICAgICAgIH1cclxuICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgZ3JpZE9wdGlvbnMgPSB0aGlzLl9zbGF2ZUdyaWRPcHRpb25zO1xyXG4gICAgICAgICAgICBzZWxlY3RBbGxDaGVjayA9IHRoaXMuX3NsYXZlU2VsZWN0QWxsO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgZ3JpZE9wdGlvbnMucGlubmVkVG9wUm93RGF0YSA9IFt7ZnVsbFdpZHRoOiB0cnVlfV07XHJcbiAgICAgICAgZ3JpZE9wdGlvbnMuaXNGdWxsV2lkdGhDZWxsID0gKF9yb3dOb2RlOiBSb3dOb2RlKTogYm9vbGVhbiA9PiB7XHJcbiAgICAgICAgICAgIGlmICh0eXBlb2YgX3Jvd05vZGUuZGF0YS5mdWxsV2lkdGggIT09ICd1bmRlZmluZWQnKSB7XHJcbiAgICAgICAgICAgICAgICByZXR1cm4gX3Jvd05vZGUuZGF0YS5mdWxsV2lkdGg7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgcmV0dXJuIGZhbHNlO1xyXG4gICAgICAgIH07XHJcblxyXG4gICAgICAgIGdyaWRPcHRpb25zLmZ1bGxXaWR0aENlbGxSZW5kZXJlciA9IChwYXJhbXM6IGFueSk6IEhUTUxFbGVtZW50ID0+IHtcclxuICAgICAgICAgICAgbGV0IHBhcmVudFdyYXBwZXI6IEhUTUxFbGVtZW50ID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnZGl2Jyk7XHJcbiAgICAgICAgICAgIGxldCBjaGVja2JveFdyYXBwZXI6IEhUTUxEaXZFbGVtZW50ID0gdGhpcy5fZG9tU3ZjLmNyZWF0ZUVsZW1lbnQocGFyZW50V3JhcHBlciwgJ3NlbGVjdGlvbi13cmFwcGVyIHNlbGVjdC1hbGwnLCAnZGl2Jyk7XHJcbiAgICAgICAgICAgIGxldCBjaGVja2JveDogSFRNTElucHV0RWxlbWVudCA9IHRoaXMuX2RvbVN2Yy5jcmVhdGVFbGVtZW50KGNoZWNrYm94V3JhcHBlciwgJ3NlbGVjdC1hbGwnLCAnaW5wdXQnKTtcclxuXHJcbiAgICAgICAgICAgIGNoZWNrYm94LnR5cGUgPSAnY2hlY2tib3gnO1xyXG5cclxuICAgICAgICAgICAgdGhpcy5fZG9tU3ZjLmNyZWF0ZUVsZW1lbnQoY2hlY2tib3hXcmFwcGVyLCAnbGFiZWwnLCAnbGFiZWwnKTtcclxuICAgICAgICAgICAgY2hlY2tib3hXcmFwcGVyLmFkZEV2ZW50TGlzdGVuZXIoJ2NoYW5nZScsICgpOiB2b2lkID0+IHtcclxuICAgICAgICAgICAgICAgIGxldCBpc0NoZWNrZWQ6IGJvb2xlYW4gPSBjaGVja2JveC5jaGVja2VkO1xyXG4gICAgICAgICAgICAgICAgdGhpcy5fY2hlY2tTZWxlY3RBbGxCb3gocGFyYW1zLCBfZ3JpZCwgaXNDaGVja2VkKTtcclxuICAgICAgICAgICAgfSk7XHJcblxyXG4gICAgICAgICAgICBpZiAoc2VsZWN0QWxsQ2hlY2spIHtcclxuICAgICAgICAgICAgICAgIGNoZWNrYm94LmNoZWNrZWQgPSB0cnVlO1xyXG4gICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICBsZXQgZGlzcGxheURhdGE6IEhUTUxEaXZFbGVtZW50ID0gdGhpcy5fZG9tU3ZjLmNyZWF0ZUVsZW1lbnQocGFyZW50V3JhcHBlciwgJ2NoZWNrYm94LXRleHQnLCAnZGl2Jyk7XHJcbiAgICAgICAgICAgIGxldCBwVGFnOiBIVE1MRGl2RWxlbWVudCA9IHRoaXMuX2RvbVN2Yy5jcmVhdGVFbGVtZW50KGRpc3BsYXlEYXRhLCAnY2hlY2stZGF0YScsICdkaXYnKTtcclxuICAgICAgICAgICAgbGV0IGRhdGEgPSBncmlkT3B0aW9ucy5hcGkuZ2V0TW9kZWwoKS5nZXRSb3dDb3VudCgpO1xyXG4gICAgICAgICAgICBwVGFnLmlubmVySFRNTCA9ICdTZWxlY3QgYWxsICcgKyBkYXRhICsgJyByZXN1bHRzJztcclxuXHJcbiAgICAgICAgICAgIHJldHVybiBwYXJlbnRXcmFwcGVyO1xyXG4gICAgICAgIH07XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfc2V0SGVpZ2h0KF9pc01vYmlsZTogYm9vbGVhbik6IHZvaWQge1xyXG4gICAgICAgIGxldCBoZWlnaHQ6IGFueTtcclxuXHJcbiAgICAgICAgaWYgKF9pc01vYmlsZSkge1xyXG4gICAgICAgICAgICBoZWlnaHQgPSB0aGlzLl9tdWx0aVRhYmxlU3ZjLmNhbGNNb2JpbGVIZWlnaHQodGhpcy5fbWFzdGVyR3JpZE9wdGlvbnMsIHRoaXMuX3NsYXZlR3JpZE9wdGlvbnMsIHRoaXMuX3Zjcik7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICBoZWlnaHQgPSB0aGlzLl9tdWx0aVRhYmxlU3ZjLmNhbGNXZWJIZWlnaHQodGhpcy5jb25maWcuaGVpZ2h0KTtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIHRoaXMuX3NldEdyaWRIZWlnaHQoJ21hc3RlcicsIGhlaWdodCk7XHJcbiAgICAgICAgdGhpcy5fc2V0R3JpZEhlaWdodCgnc2xhdmUnLCBoZWlnaHQpO1xyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX3NldEdyaWRIZWlnaHQoX2dyaWQ6IHN0cmluZywgX2hlaWdodDogYW55KTogdm9pZCB7XHJcbiAgICAgICAgbGV0IHF1ZXJ5U3RyaW5nOiBzdHJpbmcgPSAnLnN0Zy10aGVtZS4nICsgX2dyaWQ7XHJcbiAgICAgICAgbGV0IGdyaWRIZWlnaHQ6IHN0cmluZztcclxuICAgICAgICBsZXQgaHRtbEVsZTogSFRNTEVsZW1lbnQgPSB0aGlzLl92Y3IuZWxlbWVudC5uYXRpdmVFbGVtZW50LnF1ZXJ5U2VsZWN0b3IocXVlcnlTdHJpbmcpO1xyXG5cclxuICAgICAgICBpZiAoX2dyaWQgPT09ICdtYXN0ZXInKSB7XHJcbiAgICAgICAgICAgIGdyaWRIZWlnaHQgPSBfaGVpZ2h0LnRvcCArICdweCc7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICBncmlkSGVpZ2h0ID0gX2hlaWdodC5ib3R0b20gKyAncHgnO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgdGhpcy5fZG9tU3ZjLnNldEVsZW1lbnRTdHlsZShodG1sRWxlLCAnaGVpZ2h0JywgZ3JpZEhlaWdodCk7XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfc2V0Q2hlY2tib3goX2dyaWQ6IHN0cmluZyk6IGFueSB7XHJcbiAgICAgICAgbGV0IGNoZWNrYm94U2V0dGluZzogYW55ID0gdGhpcy5fbXVsdGlUYWJsZVN2Yy5nZXRDaGVja2JveERlZmF1bHQoKTtcclxuICAgICAgICBjaGVja2JveFNldHRpbmcucGlubmVkID0gIHRoaXMuX2RpcmVjdGlvbjtcclxuICAgICAgICBjaGVja2JveFNldHRpbmcuY2VsbENsYXNzID0gJ2FnLWNoZWNrYm94LXJhZGlvJztcclxuICAgICAgICBjaGVja2JveFNldHRpbmcuY2VsbFJlbmRlcmVyID0gKF9wYXJhbXM6IGFueSk6IEhUTUxFbGVtZW50ID0+IHRoaXMuX3NldENlbGxSZW5kZXJpbmcoX3BhcmFtcywgX2dyaWQpO1xyXG5cclxuICAgICAgICByZXR1cm4gY2hlY2tib3hTZXR0aW5nO1xyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX3NldENlbGxSZW5kZXJpbmcocGFyYW1zOiBhbnksIGdyaWQ6IHN0cmluZyk6IEhUTUxFbGVtZW50IHtcclxuICAgICAgICBsZXQgaGVhZGVyOiBIVE1MRGl2RWxlbWVudCA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2RpdicpO1xyXG4gICAgICAgIGxldCBpbnB1dDogSFRNTElucHV0RWxlbWVudCA9IHRoaXMuX2RvbVN2Yy5jcmVhdGVFbGVtZW50KGhlYWRlciwgJ2NoZWNrYm94JywgJ2lucHV0Jyk7XHJcbiAgICAgICAgdGhpcy5fZG9tU3ZjLmNyZWF0ZUVsZW1lbnQoaGVhZGVyLCAnbGFiZWwnLCAnbGFiZWwnKTtcclxuICAgICAgICBsZXQgZ3JpZE9wdGlvbnM6IEdyaWRPcHRpb25zID0gKGdyaWQgPT09ICdtYXN0ZXInKSA/IHRoaXMuX21hc3RlckdyaWRPcHRpb25zIDogdGhpcy5fc2xhdmVHcmlkT3B0aW9ucztcclxuICAgICAgICBsZXQgY3VycmVudE5vZGU6IFJvd05vZGUgPSBncmlkT3B0aW9ucy5hcGkuZ2V0TW9kZWwoKS5nZXRSb3cocGFyYW1zLnJvd0luZGV4KTtcclxuICAgICAgICBpbnB1dC50eXBlID0gJ2NoZWNrYm94JztcclxuICAgICAgICBoZWFkZXIuY2xhc3NOYW1lID0gJ3NlbGVjdGlvbi13cmFwcGVyJztcclxuICAgICAgICBoZWFkZXIuYWRkRXZlbnRMaXN0ZW5lcignY2hhbmdlJywgKCRldmVudCk6IHZvaWQgPT4ge1xyXG4gICAgICAgICAgICBjdXJyZW50Tm9kZS5zZWxlY3RUaGlzTm9kZShpbnB1dC5jaGVja2VkKTtcclxuICAgICAgICAgICAgdGhpcy5fY2hlY2tTZWxlY3RCb3gocGFyYW1zLCBncmlkKTtcclxuICAgICAgICB9KTtcclxuICAgICAgICBpZiAoY3VycmVudE5vZGUuaXNTZWxlY3RlZCgpKSBpbnB1dC5jaGVja2VkID0gdHJ1ZTtcclxuXHJcbiAgICAgICAgcmV0dXJuIGhlYWRlcjtcclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF9jaGVja1NlbGVjdEJveChwYXJhbXM6IGFueSwgZ3JpZDogc3RyaW5nKTogdm9pZCB7XHJcbiAgICAgICAgbGV0IGdyaWRPcHRpb25zOiBHcmlkT3B0aW9ucyA9IChncmlkID09PSAnbWFzdGVyJykgPyB0aGlzLl9tYXN0ZXJHcmlkT3B0aW9ucyA6IHRoaXMuX3NsYXZlR3JpZE9wdGlvbnM7XHJcbiAgICAgICAgbGV0IHNlbGVjdEFsbDogYm9vbGVhbiA9IChncmlkID09PSAnbWFzdGVyJykgPyB0aGlzLl9tYXN0ZXJTZWxlY3RBbGwgOiB0aGlzLl9zbGF2ZVNlbGVjdEFsbDtcclxuICAgICAgICBsZXQgcXVlcnlTdHJpbmc6IHN0cmluZyA9ICcjJyArIGdyaWQgKyAnIC5zZWxlY3QtYWxsIGlucHV0JztcclxuICAgICAgICBsZXQgcm93TW9kZWxDb3VudCA9IGdyaWRPcHRpb25zLmFwaS5nZXRNb2RlbCgpLmdldFJvd0NvdW50KCk7XHJcbiAgICAgICAgbGV0IHNlbGVjdGVkTm9kZXNDb3VudCA9IGdyaWRPcHRpb25zLmFwaS5nZXRTZWxlY3RlZE5vZGVzKCkubGVuZ3RoO1xyXG4gICAgICAgIHNlbGVjdEFsbCA9IChyb3dNb2RlbENvdW50ID09PSBzZWxlY3RlZE5vZGVzQ291bnQpO1xyXG5cclxuICAgICAgICBpZiAoZ3JpZCA9PT0gJ21hc3RlcicpIHRoaXMuX21hc3RlclNlbGVjdEFsbCA9IHNlbGVjdEFsbDtcclxuICAgICAgICBlbHNlIHRoaXMuX3NsYXZlU2VsZWN0QWxsID0gc2VsZWN0QWxsO1xyXG5cclxuICAgICAgICB0aGlzLl92Y3IuZWxlbWVudC5uYXRpdmVFbGVtZW50LnF1ZXJ5U2VsZWN0b3IocXVlcnlTdHJpbmcpLmNoZWNrZWQgPSBzZWxlY3RBbGw7XHJcbiAgICAgICAgdGhpcy5fdXBkYXRlU2VsZWN0aW9uKGdyaWQpO1xyXG4gICAgICAgIHRoaXMuX2Rpc2FibGVCdXR0b24gPSB0aGlzLl9tdWx0aVRhYmxlU3ZjLmNoZWNrU2VsZWN0aW9uKHRoaXMuX21hc3RlckdyaWRPcHRpb25zLCB0aGlzLl9zbGF2ZUdyaWRPcHRpb25zKTtcclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF9jaGVja1NlbGVjdEFsbEJveChwYXJhbXM6IGFueSwgZ3JpZDogc3RyaW5nLCBpc0NoZWNrZWQ6IGJvb2xlYW4pOiB2b2lkIHtcclxuICAgICAgICBsZXQgZWxlQ2xhc3M6IHN0cmluZyA9ICcjJyArIGdyaWQgKyAoKHRoaXMuX2RpcmVjdGlvbiA9PT0gJ2xlZnQnKSA/ICcgLmFnLXBpbm5lZC1sZWZ0LWNvbHMtY29udGFpbmVyJyA6ICcgLmFnLXBpbm5lZC1yaWdodC1jb2xzLWNvbnRhaW5lcicpO1xyXG4gICAgICAgIGxldCBib2R5Q29udGFpbmVyOiBIVE1MRWxlbWVudCA9IHRoaXMuX3Zjci5lbGVtZW50Lm5hdGl2ZUVsZW1lbnQucXVlcnlTZWxlY3RvcihlbGVDbGFzcyk7XHJcbiAgICAgICAgbGV0IGlucHV0RWxlOiBOb2RlTGlzdE9mPGFueT4gPSBib2R5Q29udGFpbmVyLnF1ZXJ5U2VsZWN0b3JBbGwoJy5zZWxlY3Rpb24td3JhcHBlciBpbnB1dCcpO1xyXG4gICAgICAgIGxldCBncmlkT3B0aW9uczogR3JpZE9wdGlvbnMgPSAoZ3JpZCA9PT0gJ21hc3RlcicpID8gdGhpcy5fbWFzdGVyR3JpZE9wdGlvbnMgOiB0aGlzLl9zbGF2ZUdyaWRPcHRpb25zO1xyXG4gICAgICAgIGxldCBtb2RlbEFwaTogSVJvd01vZGVsID0gZ3JpZE9wdGlvbnMuYXBpLmdldE1vZGVsKCk7XHJcblxyXG4gICAgICAgIGlmIChncmlkID09PSAnbWFzdGVyJykgdGhpcy5fbWFzdGVyU2VsZWN0QWxsID0gaXNDaGVja2VkO1xyXG4gICAgICAgIGVsc2UgdGhpcy5fc2xhdmVTZWxlY3RBbGwgPSBpc0NoZWNrZWQ7XHJcblxyXG4gICAgICAgIGxldCBzZWxlY3RBbGw6IGJvb2xlYW4gPSAoZ3JpZCA9PT0gJ21hc3RlcicpID8gdGhpcy5fbWFzdGVyU2VsZWN0QWxsIDogdGhpcy5fc2xhdmVTZWxlY3RBbGw7XHJcbiAgICAgICAgZm9yIChsZXQgaTogbnVtYmVyID0gMDsgaSA8IG1vZGVsQXBpLmdldFJvd0NvdW50KCk7IGkrKykge1xyXG4gICAgICAgICAgICBtb2RlbEFwaS5nZXRSb3coaSkuc2VsZWN0VGhpc05vZGUoc2VsZWN0QWxsKTtcclxuICAgICAgICAgICAgaWYgKHR5cGVvZiBpbnB1dEVsZVtpXSAhPT0gJ3VuZGVmaW5lZCcpIGlucHV0RWxlW2ldLmNoZWNrZWQgPSBzZWxlY3RBbGw7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIHRoaXMuX3VwZGF0ZVNlbGVjdGlvbihncmlkKTtcclxuICAgICAgICB0aGlzLl9kaXNhYmxlQnV0dG9uID0gdGhpcy5fbXVsdGlUYWJsZVN2Yy5jaGVja1NlbGVjdGlvbih0aGlzLl9tYXN0ZXJHcmlkT3B0aW9ucywgdGhpcy5fc2xhdmVHcmlkT3B0aW9ucyk7XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfdXBkYXRlU2VsZWN0aW9uKGNoZWNrZWRHcmlkOiBzdHJpbmcpOiB2b2lkIHtcclxuICAgICAgICBsZXQgcXVlcnlTdHJpbmc6IHN0cmluZyA9IChjaGVja2VkR3JpZCA9PT0gJ21hc3RlcicpID8gJyNzbGF2ZSAuc2VsZWN0aW9uLXdyYXBwZXIgaW5wdXQnIDogJyNtYXN0ZXIgLnNlbGVjdGlvbi13cmFwcGVyIGlucHV0JztcclxuICAgICAgICBsZXQgYWxsRWxlbWVudDogQXJyYXk8YW55PiA9IHRoaXMuX3Zjci5lbGVtZW50Lm5hdGl2ZUVsZW1lbnQucXVlcnlTZWxlY3RvckFsbChxdWVyeVN0cmluZyk7XHJcbiAgICAgICAgdGhpcy5fbXVsdGlUYWJsZVN2Yy5zZXRDaGVja2JveEZhbHNlKGFsbEVsZW1lbnQpO1xyXG4gICAgICAgIGlmIChjaGVja2VkR3JpZCA9PT0gJ21hc3RlcicpIHtcclxuICAgICAgICAgICAgdGhpcy5fc2xhdmVHcmlkT3B0aW9ucy5hcGkuZGVzZWxlY3RBbGwoKTtcclxuICAgICAgICAgICAgdGhpcy5fc2xhdmVTZWxlY3RBbGwgPSBmYWxzZTtcclxuICAgICAgICB9XHJcbiAgICAgICAgZWxzZSB7XHJcbiAgICAgICAgICAgIHRoaXMuX21hc3RlckdyaWRPcHRpb25zLmFwaS5kZXNlbGVjdEFsbCgpO1xyXG4gICAgICAgICAgICB0aGlzLl9tYXN0ZXJTZWxlY3RBbGwgPSBmYWxzZTtcclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfc2VhcmNoU3RhdGUoZ3JpZDogc3RyaW5nLCBzdGF0ZTogc3RyaW5nKTogdm9pZCB7XHJcbiAgICAgICAgbGV0IHF1ZXJ5U3RyaW5nOiBzdHJpbmcgPSAnLnNlYXJjaC10YWJsZS0nICsgZ3JpZDtcclxuICAgICAgICBsZXQgcmVuZGVyR3JpZDogSFRNTEVsZW1lbnQgPSB0aGlzLl92Y3IuZWxlbWVudC5uYXRpdmVFbGVtZW50LnF1ZXJ5U2VsZWN0b3IocXVlcnlTdHJpbmcpO1xyXG4gICAgICAgIGlmIChzdGF0ZSA9PT0gJ2NvbGxhcHNlJykge1xyXG4gICAgICAgICAgICB0aGlzLl9kb21TdmMuYWRkQ2xhc3MocmVuZGVyR3JpZCwgJ2NvbGxhcHNlLXNlYXJjaCcpO1xyXG4gICAgICAgICAgICB0aGlzLl9kb21TdmMucmVtb3ZlQ2xhc3MocmVuZGVyR3JpZCwgJ2V4cGFuZC1zZWFyY2gnKTtcclxuICAgICAgICB9XHJcbiAgICAgICAgZWxzZSBpZiAoc3RhdGUgPT09ICdleHBhbmQnKSB7XHJcbiAgICAgICAgICAgIHRoaXMuX2RvbVN2Yy5hZGRDbGFzcyhyZW5kZXJHcmlkLCAnZXhwYW5kLXNlYXJjaCcpO1xyXG4gICAgICAgICAgICB0aGlzLl9kb21TdmMucmVtb3ZlQ2xhc3MocmVuZGVyR3JpZCwgJ2NvbGxhcHNlLXNlYXJjaCcpO1xyXG4gICAgICAgIH1cclxuICAgICAgICAvLyAncmVzZXQnXHJcbiAgICAgICAgZWxzZSB7XHJcbiAgICAgICAgICAgIHRoaXMuX2RvbVN2Yy5yZW1vdmVDbGFzcyhyZW5kZXJHcmlkLCAnZXhwYW5kLXNlYXJjaCcpO1xyXG4gICAgICAgICAgICB0aGlzLl9kb21TdmMucmVtb3ZlQ2xhc3MocmVuZGVyR3JpZCwgJ2NvbGxhcHNlLXNlYXJjaCcpO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxufVxyXG4iXX0=