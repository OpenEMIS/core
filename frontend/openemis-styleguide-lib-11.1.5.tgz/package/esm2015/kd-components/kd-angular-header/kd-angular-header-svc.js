import { Injectable } from '@angular/core';
export class KdHeaderSvc {
    getDefaultConfig() {
        return {
            brandLogo: {
                //  prefix: 'OpenEMIS',
                name: 'OpenEMIS Styleguide',
                type: 'icon',
                src: 'kd-openemis'
            },
            userInfo: {
                showUser: true,
                name: '',
                imgType: 'icon',
                imgSrc: 'kd-role',
                role: ''
            },
            btnGroup: [{
                    btnIcon: 'fa fa-home fa-lg',
                    dropdownType: 'default'
                }, {
                    btnIcon: 'kd-grid',
                    dropdownType: 'grid',
                    dropdownContent: [{
                            icon: 'kd-openemis kd-analyzer',
                            text: 'Analyzer',
                            theme: 'openemis-analyzer'
                        }, {
                            icon: 'kd-openemis kd-community',
                            text: 'Community',
                            theme: 'openemis-community'
                        }, {
                            icon: 'kd-openemis kd-connect',
                            text: 'Connect',
                            theme: 'openemis-connect'
                        }, {
                            icon: 'kd-openemis kd-core',
                            text: 'Core',
                            theme: 'openemis-core'
                        }, {
                            icon: 'kd-openemis kd-datamanager',
                            text: 'DataManager',
                            theme: 'openemis-datamanager'
                        }, {
                            icon: 'kd-openemis kd-dashboard',
                            text: 'Dashboard',
                            theme: 'openemis-dashboard'
                        }, {
                            icon: 'kd-openemis kd-exams',
                            text: 'Exams',
                            theme: 'openemis-exams'
                        }, {
                            icon: 'kd-openemis kd-identity',
                            text: 'Identity',
                            theme: 'openemis-identity'
                        }, {
                            icon: 'kd-openemis kd-insight',
                            text: 'Insight',
                            theme: 'openemis-insight'
                        }, {
                            icon: 'kd-openemis kd-integrator',
                            text: 'Integrator',
                            theme: 'openemis-integrator'
                        }, {
                            icon: 'kd-openemis kd-learning',
                            text: 'Learning',
                            theme: 'openemis-learning'
                        }, {
                            icon: 'kd-openemis kd-logistics',
                            text: 'Logistics',
                            theme: 'openemis-logistics'
                        }, {
                            icon: 'kd-openemis kd-modelling',
                            text: 'Modelling',
                            theme: 'openemis-modelling'
                        }, {
                            icon: 'kd-openemis kd-monitoring',
                            text: 'Monitoring',
                            theme: 'openemis-monitoring'
                        }, {
                            icon: 'kd-openemis kd-school',
                            text: 'School',
                            theme: 'openemis-school'
                        },
                        {
                            icon: 'kd-openemis kd-styleguide',
                            text: 'Styleguide',
                            theme: 'openemis-styleguide'
                        }]
                }, {
                    btnIcon: 'kd-ellipsis',
                    dropdownType: 'list',
                    dropdownContent: [{
                            icon: 'fa fa-user',
                            text: 'About'
                        }, {
                            icon: 'fa fa-cog',
                            text: 'Preferences'
                        }, {
                            icon: 'fa fa-question-circle',
                            text: 'Help'
                        }, {
                            icon: 'fa fa-power-off',
                            text: 'Logout'
                        }]
                }]
        };
    }
}
KdHeaderSvc.decorators = [
    { type: Injectable }
];
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoia2QtYW5ndWxhci1oZWFkZXItc3ZjLmpzIiwic291cmNlUm9vdCI6IkM6L3hhbXBwL2h0ZG9jcy9TdHlsZWd1aWRlL2lvc3RnLW9wZW5lbWlzLXN0eWxlZ3VpZGUvcHJvamVjdHMvb3BlbmVtaXMtc3R5bGVndWlkZS1saWIvc3JjLyIsInNvdXJjZXMiOlsia2QtY29tcG9uZW50cy9rZC1hbmd1bGFyLWhlYWRlci9rZC1hbmd1bGFyLWhlYWRlci1zdmMudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsT0FBTyxFQUFFLFVBQVUsRUFBRSxNQUFNLGVBQWUsQ0FBQztBQVkzQyxNQUFNLE9BQU8sV0FBVztJQUViLGdCQUFnQjtRQUNuQixPQUFPO1lBQ0gsU0FBUyxFQUFFO2dCQUNQLHVCQUF1QjtnQkFDdkIsSUFBSSxFQUFFLHFCQUFxQjtnQkFDM0IsSUFBSSxFQUFFLE1BQU07Z0JBQ1osR0FBRyxFQUFFLGFBQWE7YUFDckI7WUFDRCxRQUFRLEVBQUU7Z0JBQ04sUUFBUSxFQUFFLElBQUk7Z0JBQ2QsSUFBSSxFQUFFLEVBQUU7Z0JBQ1IsT0FBTyxFQUFFLE1BQU07Z0JBQ2YsTUFBTSxFQUFFLFNBQVM7Z0JBQ2pCLElBQUksRUFBRSxFQUFFO2FBQ1g7WUFDRCxRQUFRLEVBQUUsQ0FBQztvQkFDUCxPQUFPLEVBQUUsa0JBQWtCO29CQUMzQixZQUFZLEVBQUUsU0FBUztpQkFDMUIsRUFBRTtvQkFDQyxPQUFPLEVBQUUsU0FBUztvQkFDbEIsWUFBWSxFQUFFLE1BQU07b0JBQ3BCLGVBQWUsRUFBRSxDQUFDOzRCQUNkLElBQUksRUFBRSx5QkFBeUI7NEJBQy9CLElBQUksRUFBRSxVQUFVOzRCQUNoQixLQUFLLEVBQUUsbUJBQW1CO3lCQUM3QixFQUFFOzRCQUNDLElBQUksRUFBRSwwQkFBMEI7NEJBQ2hDLElBQUksRUFBRSxXQUFXOzRCQUNqQixLQUFLLEVBQUUsb0JBQW9CO3lCQUM5QixFQUFFOzRCQUNDLElBQUksRUFBRSx3QkFBd0I7NEJBQzlCLElBQUksRUFBRSxTQUFTOzRCQUNmLEtBQUssRUFBRSxrQkFBa0I7eUJBQzVCLEVBQUU7NEJBQ0MsSUFBSSxFQUFFLHFCQUFxQjs0QkFDM0IsSUFBSSxFQUFFLE1BQU07NEJBQ1osS0FBSyxFQUFFLGVBQWU7eUJBQ3pCLEVBQUU7NEJBQ0MsSUFBSSxFQUFFLDRCQUE0Qjs0QkFDbEMsSUFBSSxFQUFFLGFBQWE7NEJBQ25CLEtBQUssRUFBRSxzQkFBc0I7eUJBQ2hDLEVBQUU7NEJBQ0MsSUFBSSxFQUFFLDBCQUEwQjs0QkFDaEMsSUFBSSxFQUFFLFdBQVc7NEJBQ2pCLEtBQUssRUFBRSxvQkFBb0I7eUJBQzlCLEVBQUU7NEJBQ0MsSUFBSSxFQUFFLHNCQUFzQjs0QkFDNUIsSUFBSSxFQUFFLE9BQU87NEJBQ2IsS0FBSyxFQUFFLGdCQUFnQjt5QkFDMUIsRUFBRTs0QkFDQyxJQUFJLEVBQUUseUJBQXlCOzRCQUMvQixJQUFJLEVBQUUsVUFBVTs0QkFDaEIsS0FBSyxFQUFFLG1CQUFtQjt5QkFDN0IsRUFBRTs0QkFDQyxJQUFJLEVBQUUsd0JBQXdCOzRCQUM5QixJQUFJLEVBQUUsU0FBUzs0QkFDZixLQUFLLEVBQUUsa0JBQWtCO3lCQUM1QixFQUFFOzRCQUNDLElBQUksRUFBRSwyQkFBMkI7NEJBQ2pDLElBQUksRUFBRSxZQUFZOzRCQUNsQixLQUFLLEVBQUUscUJBQXFCO3lCQUMvQixFQUFFOzRCQUNDLElBQUksRUFBRSx5QkFBeUI7NEJBQy9CLElBQUksRUFBRSxVQUFVOzRCQUNoQixLQUFLLEVBQUUsbUJBQW1CO3lCQUM3QixFQUFFOzRCQUNDLElBQUksRUFBRSwwQkFBMEI7NEJBQ2hDLElBQUksRUFBRSxXQUFXOzRCQUNqQixLQUFLLEVBQUUsb0JBQW9CO3lCQUM5QixFQUFFOzRCQUNDLElBQUksRUFBRSwwQkFBMEI7NEJBQ2hDLElBQUksRUFBRSxXQUFXOzRCQUNqQixLQUFLLEVBQUUsb0JBQW9CO3lCQUM5QixFQUFFOzRCQUNDLElBQUksRUFBRSwyQkFBMkI7NEJBQ2pDLElBQUksRUFBRSxZQUFZOzRCQUNsQixLQUFLLEVBQUUscUJBQXFCO3lCQUMvQixFQUFFOzRCQUNDLElBQUksRUFBRSx1QkFBdUI7NEJBQzdCLElBQUksRUFBRSxRQUFROzRCQUNkLEtBQUssRUFBRSxpQkFBaUI7eUJBQzNCO3dCQUlJOzRCQUNELElBQUksRUFBRSwyQkFBMkI7NEJBQ2pDLElBQUksRUFBRSxZQUFZOzRCQUNsQixLQUFLLEVBQUUscUJBQXFCO3lCQUMvQixDQUFDO2lCQUNMLEVBQUU7b0JBQ0MsT0FBTyxFQUFFLGFBQWE7b0JBQ3RCLFlBQVksRUFBRSxNQUFNO29CQUNwQixlQUFlLEVBQUUsQ0FBQzs0QkFDZCxJQUFJLEVBQUUsWUFBWTs0QkFDbEIsSUFBSSxFQUFFLE9BQU87eUJBQ2hCLEVBQUU7NEJBQ0MsSUFBSSxFQUFFLFdBQVc7NEJBQ2pCLElBQUksRUFBRSxhQUFhO3lCQUN0QixFQUFFOzRCQUNDLElBQUksRUFBRSx1QkFBdUI7NEJBQzdCLElBQUksRUFBRSxNQUFNO3lCQUNmLEVBQUU7NEJBQ0MsSUFBSSxFQUFFLGlCQUFpQjs0QkFDdkIsSUFBSSxFQUFFLFFBQVE7eUJBQ2pCLENBQUM7aUJBQ0wsQ0FBQztTQUNMLENBQUM7SUFDTixDQUFDOzs7WUEvR0osVUFBVSIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IEluamVjdGFibGUgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcclxuaW1wb3J0IHtcclxuICAgIC8vIElIZWFkZXJCdXR0b24sXHJcbiAgICAvLyBJSGVhZGVyQnJhbmRMb2dvLFxyXG4gICAgLy8gSUhlYWRlckRyb3Bkb3duSXRlbSxcclxuICAgIC8vIElIZWFkZXJVc2VySW5mbyxcclxuICAgIC8vIElIZWFkZXJBUEksXHJcbiAgICBJSGVhZGVyQ29uZmlnXHJcbn0gZnJvbSAnLi9rZC1hbmd1bGFyLWhlYWRlci1pbnRlcmZhY2UnO1xyXG5cclxuXHJcbkBJbmplY3RhYmxlKClcclxuZXhwb3J0IGNsYXNzIEtkSGVhZGVyU3ZjIHtcclxuXHJcbiAgICBwdWJsaWMgZ2V0RGVmYXVsdENvbmZpZygpOiBJSGVhZGVyQ29uZmlnIHtcclxuICAgICAgICByZXR1cm4ge1xyXG4gICAgICAgICAgICBicmFuZExvZ286IHtcclxuICAgICAgICAgICAgICAgIC8vICBwcmVmaXg6ICdPcGVuRU1JUycsXHJcbiAgICAgICAgICAgICAgICBuYW1lOiAnT3BlbkVNSVMgU3R5bGVndWlkZScsXHJcbiAgICAgICAgICAgICAgICB0eXBlOiAnaWNvbicsIC8vIGljb24sIGltYWdlLCBub25lXHJcbiAgICAgICAgICAgICAgICBzcmM6ICdrZC1vcGVuZW1pcydcclxuICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgdXNlckluZm86IHtcclxuICAgICAgICAgICAgICAgIHNob3dVc2VyOiB0cnVlLCAvLyB0cnVlLCBmYWxzZVxyXG4gICAgICAgICAgICAgICAgbmFtZTogJycsXHJcbiAgICAgICAgICAgICAgICBpbWdUeXBlOiAnaWNvbicsIC8vIGljb24sIGltYWdlLCBub25lXHJcbiAgICAgICAgICAgICAgICBpbWdTcmM6ICdrZC1yb2xlJyxcclxuICAgICAgICAgICAgICAgIHJvbGU6ICcnXHJcbiAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgIGJ0bkdyb3VwOiBbe1xyXG4gICAgICAgICAgICAgICAgYnRuSWNvbjogJ2ZhIGZhLWhvbWUgZmEtbGcnLFxyXG4gICAgICAgICAgICAgICAgZHJvcGRvd25UeXBlOiAnZGVmYXVsdCdcclxuICAgICAgICAgICAgfSwge1xyXG4gICAgICAgICAgICAgICAgYnRuSWNvbjogJ2tkLWdyaWQnLFxyXG4gICAgICAgICAgICAgICAgZHJvcGRvd25UeXBlOiAnZ3JpZCcsXHJcbiAgICAgICAgICAgICAgICBkcm9wZG93bkNvbnRlbnQ6IFt7XHJcbiAgICAgICAgICAgICAgICAgICAgaWNvbjogJ2tkLW9wZW5lbWlzIGtkLWFuYWx5emVyJyxcclxuICAgICAgICAgICAgICAgICAgICB0ZXh0OiAnQW5hbHl6ZXInLFxyXG4gICAgICAgICAgICAgICAgICAgIHRoZW1lOiAnb3BlbmVtaXMtYW5hbHl6ZXInXHJcbiAgICAgICAgICAgICAgICB9LCB7XHJcbiAgICAgICAgICAgICAgICAgICAgaWNvbjogJ2tkLW9wZW5lbWlzIGtkLWNvbW11bml0eScsXHJcbiAgICAgICAgICAgICAgICAgICAgdGV4dDogJ0NvbW11bml0eScsXHJcbiAgICAgICAgICAgICAgICAgICAgdGhlbWU6ICdvcGVuZW1pcy1jb21tdW5pdHknXHJcbiAgICAgICAgICAgICAgICB9LCB7XHJcbiAgICAgICAgICAgICAgICAgICAgaWNvbjogJ2tkLW9wZW5lbWlzIGtkLWNvbm5lY3QnLFxyXG4gICAgICAgICAgICAgICAgICAgIHRleHQ6ICdDb25uZWN0JyxcclxuICAgICAgICAgICAgICAgICAgICB0aGVtZTogJ29wZW5lbWlzLWNvbm5lY3QnXHJcbiAgICAgICAgICAgICAgICB9LCB7XHJcbiAgICAgICAgICAgICAgICAgICAgaWNvbjogJ2tkLW9wZW5lbWlzIGtkLWNvcmUnLFxyXG4gICAgICAgICAgICAgICAgICAgIHRleHQ6ICdDb3JlJyxcclxuICAgICAgICAgICAgICAgICAgICB0aGVtZTogJ29wZW5lbWlzLWNvcmUnXHJcbiAgICAgICAgICAgICAgICB9LCB7XHJcbiAgICAgICAgICAgICAgICAgICAgaWNvbjogJ2tkLW9wZW5lbWlzIGtkLWRhdGFtYW5hZ2VyJyxcclxuICAgICAgICAgICAgICAgICAgICB0ZXh0OiAnRGF0YU1hbmFnZXInLFxyXG4gICAgICAgICAgICAgICAgICAgIHRoZW1lOiAnb3BlbmVtaXMtZGF0YW1hbmFnZXInXHJcbiAgICAgICAgICAgICAgICB9LCB7XHJcbiAgICAgICAgICAgICAgICAgICAgaWNvbjogJ2tkLW9wZW5lbWlzIGtkLWRhc2hib2FyZCcsXHJcbiAgICAgICAgICAgICAgICAgICAgdGV4dDogJ0Rhc2hib2FyZCcsXHJcbiAgICAgICAgICAgICAgICAgICAgdGhlbWU6ICdvcGVuZW1pcy1kYXNoYm9hcmQnXHJcbiAgICAgICAgICAgICAgICB9LCB7XHJcbiAgICAgICAgICAgICAgICAgICAgaWNvbjogJ2tkLW9wZW5lbWlzIGtkLWV4YW1zJyxcclxuICAgICAgICAgICAgICAgICAgICB0ZXh0OiAnRXhhbXMnLFxyXG4gICAgICAgICAgICAgICAgICAgIHRoZW1lOiAnb3BlbmVtaXMtZXhhbXMnXHJcbiAgICAgICAgICAgICAgICB9LCB7XHJcbiAgICAgICAgICAgICAgICAgICAgaWNvbjogJ2tkLW9wZW5lbWlzIGtkLWlkZW50aXR5JyxcclxuICAgICAgICAgICAgICAgICAgICB0ZXh0OiAnSWRlbnRpdHknLFxyXG4gICAgICAgICAgICAgICAgICAgIHRoZW1lOiAnb3BlbmVtaXMtaWRlbnRpdHknXHJcbiAgICAgICAgICAgICAgICB9LCB7XHJcbiAgICAgICAgICAgICAgICAgICAgaWNvbjogJ2tkLW9wZW5lbWlzIGtkLWluc2lnaHQnLFxyXG4gICAgICAgICAgICAgICAgICAgIHRleHQ6ICdJbnNpZ2h0JyxcclxuICAgICAgICAgICAgICAgICAgICB0aGVtZTogJ29wZW5lbWlzLWluc2lnaHQnXHJcbiAgICAgICAgICAgICAgICB9LCB7XHJcbiAgICAgICAgICAgICAgICAgICAgaWNvbjogJ2tkLW9wZW5lbWlzIGtkLWludGVncmF0b3InLFxyXG4gICAgICAgICAgICAgICAgICAgIHRleHQ6ICdJbnRlZ3JhdG9yJyxcclxuICAgICAgICAgICAgICAgICAgICB0aGVtZTogJ29wZW5lbWlzLWludGVncmF0b3InXHJcbiAgICAgICAgICAgICAgICB9LCB7XHJcbiAgICAgICAgICAgICAgICAgICAgaWNvbjogJ2tkLW9wZW5lbWlzIGtkLWxlYXJuaW5nJyxcclxuICAgICAgICAgICAgICAgICAgICB0ZXh0OiAnTGVhcm5pbmcnLFxyXG4gICAgICAgICAgICAgICAgICAgIHRoZW1lOiAnb3BlbmVtaXMtbGVhcm5pbmcnXHJcbiAgICAgICAgICAgICAgICB9LCB7XHJcbiAgICAgICAgICAgICAgICAgICAgaWNvbjogJ2tkLW9wZW5lbWlzIGtkLWxvZ2lzdGljcycsXHJcbiAgICAgICAgICAgICAgICAgICAgdGV4dDogJ0xvZ2lzdGljcycsXHJcbiAgICAgICAgICAgICAgICAgICAgdGhlbWU6ICdvcGVuZW1pcy1sb2dpc3RpY3MnXHJcbiAgICAgICAgICAgICAgICB9LCB7XHJcbiAgICAgICAgICAgICAgICAgICAgaWNvbjogJ2tkLW9wZW5lbWlzIGtkLW1vZGVsbGluZycsXHJcbiAgICAgICAgICAgICAgICAgICAgdGV4dDogJ01vZGVsbGluZycsXHJcbiAgICAgICAgICAgICAgICAgICAgdGhlbWU6ICdvcGVuZW1pcy1tb2RlbGxpbmcnXHJcbiAgICAgICAgICAgICAgICB9LCB7XHJcbiAgICAgICAgICAgICAgICAgICAgaWNvbjogJ2tkLW9wZW5lbWlzIGtkLW1vbml0b3JpbmcnLFxyXG4gICAgICAgICAgICAgICAgICAgIHRleHQ6ICdNb25pdG9yaW5nJyxcclxuICAgICAgICAgICAgICAgICAgICB0aGVtZTogJ29wZW5lbWlzLW1vbml0b3JpbmcnXHJcbiAgICAgICAgICAgICAgICB9LCB7XHJcbiAgICAgICAgICAgICAgICAgICAgaWNvbjogJ2tkLW9wZW5lbWlzIGtkLXNjaG9vbCcsXHJcbiAgICAgICAgICAgICAgICAgICAgdGV4dDogJ1NjaG9vbCcsXHJcbiAgICAgICAgICAgICAgICAgICAgdGhlbWU6ICdvcGVuZW1pcy1zY2hvb2wnXHJcbiAgICAgICAgICAgICAgICB9LCAvKntcclxuICAgICAgICAgICAgICAgICAgICBpY29uOiAna2Qtb3BlbmVtaXMga2QtdmlzdWFsaXplcicsXHJcbiAgICAgICAgICAgICAgICAgICAgdGV4dDogJ1Zpc3VhbGl6ZXInLFxyXG4gICAgICAgICAgICAgICAgICAgIHRoZW1lOiAnb3BlbmVtaXMtdmlzdWFsaXplcidcclxuICAgICAgICAgICAgICAgIH0sKi8ge1xyXG4gICAgICAgICAgICAgICAgICAgIGljb246ICdrZC1vcGVuZW1pcyBrZC1zdHlsZWd1aWRlJyxcclxuICAgICAgICAgICAgICAgICAgICB0ZXh0OiAnU3R5bGVndWlkZScsXHJcbiAgICAgICAgICAgICAgICAgICAgdGhlbWU6ICdvcGVuZW1pcy1zdHlsZWd1aWRlJ1xyXG4gICAgICAgICAgICAgICAgfV1cclxuICAgICAgICAgICAgfSwge1xyXG4gICAgICAgICAgICAgICAgYnRuSWNvbjogJ2tkLWVsbGlwc2lzJyxcclxuICAgICAgICAgICAgICAgIGRyb3Bkb3duVHlwZTogJ2xpc3QnLFxyXG4gICAgICAgICAgICAgICAgZHJvcGRvd25Db250ZW50OiBbe1xyXG4gICAgICAgICAgICAgICAgICAgIGljb246ICdmYSBmYS11c2VyJyxcclxuICAgICAgICAgICAgICAgICAgICB0ZXh0OiAnQWJvdXQnXHJcbiAgICAgICAgICAgICAgICB9LCB7XHJcbiAgICAgICAgICAgICAgICAgICAgaWNvbjogJ2ZhIGZhLWNvZycsXHJcbiAgICAgICAgICAgICAgICAgICAgdGV4dDogJ1ByZWZlcmVuY2VzJ1xyXG4gICAgICAgICAgICAgICAgfSwge1xyXG4gICAgICAgICAgICAgICAgICAgIGljb246ICdmYSBmYS1xdWVzdGlvbi1jaXJjbGUnLFxyXG4gICAgICAgICAgICAgICAgICAgIHRleHQ6ICdIZWxwJ1xyXG4gICAgICAgICAgICAgICAgfSwge1xyXG4gICAgICAgICAgICAgICAgICAgIGljb246ICdmYSBmYS1wb3dlci1vZmYnLFxyXG4gICAgICAgICAgICAgICAgICAgIHRleHQ6ICdMb2dvdXQnXHJcbiAgICAgICAgICAgICAgICB9XVxyXG4gICAgICAgICAgICB9XVxyXG4gICAgICAgIH07XHJcbiAgICB9XHJcbn1cclxuIl19