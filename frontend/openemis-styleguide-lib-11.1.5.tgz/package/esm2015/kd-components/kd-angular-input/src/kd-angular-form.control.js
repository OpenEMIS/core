import { Injectable } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
export class KdInputControlService {
    constructor() { }
    toFormGroup(inputs) {
        let group = {};
        for (let i = 0; i < inputs.length; i++) {
            let validatorArr = [];
            // Grace -- 7 Nov 2017 --
            // testing generate validator function by passing validation logic as string but load speed will become very slow
            // if(inputs[i].getProperty('required')){
            //     validatorArr.push(this._generalValidatorFnGenerator({
            //         target: 'control.value',
            //         compare: '',
            //         logic: 'return a !== b? false: true'
            //     }, 'this field cannot be empty' ))
            // }
            if (inputs[i].getProperty('controlType') === 'file-input') {
                const config = inputs[i].getProperty('config');
                validatorArr.push(this._fileSizeValidator(config.maxFileSize, config.errorMessage));
            }
            // if (inputs[i].getProperty('required')) {
            //     validatorArr.push(this._requiredValidator('This field should not be empty'));
            // }
            group[inputs[i].getProperty('key')] = new FormControl(inputs[i].getProperty('value') || '', Validators.compose(validatorArr));
        }
        return new FormGroup(group);
    }
    emptyFormGroup() {
        return new FormGroup({});
    }
    _fileSizeValidator(maxFileSize, errorMessage) {
        return (control) => {
            let sizeExceed = false;
            if (typeof control !== 'undefined' &&
                typeof control.value !== 'undefined' &&
                typeof control.value.size !== 'undefined') {
                sizeExceed = control.value.size > maxFileSize;
            }
            return sizeExceed ? { [new Date().toISOString()]: errorMessage } : null;
        };
    }
}
KdInputControlService.decorators = [
    { type: Injectable }
];
KdInputControlService.ctorParameters = () => [];
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoia2QtYW5ndWxhci1mb3JtLmNvbnRyb2wuanMiLCJzb3VyY2VSb290IjoiQzoveGFtcHAvaHRkb2NzL1N0eWxlZ3VpZGUvaW9zdGctb3BlbmVtaXMtc3R5bGVndWlkZS9wcm9qZWN0cy9vcGVuZW1pcy1zdHlsZWd1aWRlLWxpYi9zcmMvIiwic291cmNlcyI6WyJrZC1jb21wb25lbnRzL2tkLWFuZ3VsYXItaW5wdXQvc3JjL2tkLWFuZ3VsYXItZm9ybS5jb250cm9sLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBLE9BQU8sRUFBRSxVQUFVLEVBQUUsTUFBTSxlQUFlLENBQUM7QUFDM0MsT0FBTyxFQUFFLFdBQVcsRUFBRSxTQUFTLEVBQUUsVUFBVSxFQUFnQyxNQUFNLGdCQUFnQixDQUFDO0FBS2xHLE1BQU0sT0FBTyxxQkFBcUI7SUFDOUIsZ0JBQWdCLENBQUM7SUFFakIsV0FBVyxDQUFDLE1BQXdCO1FBQ2hDLElBQUksS0FBSyxHQUFRLEVBQUUsQ0FBQztRQUVwQixLQUFLLElBQUksQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLEdBQUcsTUFBTSxDQUFDLE1BQU0sRUFBRSxDQUFDLEVBQUUsRUFBRTtZQUNwQyxJQUFJLFlBQVksR0FBdUIsRUFBRSxDQUFDO1lBRzFDLHlCQUF5QjtZQUN6QixpSEFBaUg7WUFDakgseUNBQXlDO1lBQ3pDLDREQUE0RDtZQUM1RCxtQ0FBbUM7WUFDbkMsdUJBQXVCO1lBQ3ZCLCtDQUErQztZQUMvQyx5Q0FBeUM7WUFDekMsSUFBSTtZQUVKLElBQUksTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLFdBQVcsQ0FBQyxhQUFhLENBQUMsS0FBSyxZQUFZLEVBQUU7Z0JBQ3ZELE1BQU0sTUFBTSxHQUFHLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxXQUFXLENBQUMsUUFBUSxDQUFDLENBQUM7Z0JBQy9DLFlBQVksQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLGtCQUFrQixDQUFDLE1BQU0sQ0FBQyxXQUFXLEVBQUUsTUFBTSxDQUFDLFlBQVksQ0FBQyxDQUFDLENBQUM7YUFDdkY7WUFFRCwyQ0FBMkM7WUFDM0Msb0ZBQW9GO1lBQ3BGLElBQUk7WUFFSixLQUFLLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLFdBQVcsQ0FBQyxLQUFLLENBQUMsQ0FBQyxHQUFHLElBQUksV0FBVyxDQUNqRCxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsV0FBVyxDQUFDLE9BQU8sQ0FBQyxJQUFJLEVBQUUsRUFDcEMsVUFBVSxDQUFDLE9BQU8sQ0FBQyxZQUFZLENBQUMsQ0FDbkMsQ0FBQztTQUNMO1FBQ0QsT0FBTyxJQUFJLFNBQVMsQ0FBQyxLQUFLLENBQUMsQ0FBQztJQUNoQyxDQUFDO0lBRUQsY0FBYztRQUNWLE9BQU8sSUFBSSxTQUFTLENBQUMsRUFBRSxDQUFDLENBQUM7SUFDN0IsQ0FBQztJQUVPLGtCQUFrQixDQUFDLFdBQW1CLEVBQUUsWUFBb0I7UUFDaEUsT0FBTyxDQUFDLE9BQXdCLEVBQTBCLEVBQUU7WUFDeEQsSUFBSSxVQUFVLEdBQVksS0FBSyxDQUFDO1lBRWhDLElBQUksT0FBTyxPQUFPLEtBQUssV0FBVztnQkFDOUIsT0FBTyxPQUFPLENBQUMsS0FBSyxLQUFLLFdBQVc7Z0JBQ3BDLE9BQU8sT0FBTyxDQUFDLEtBQUssQ0FBQyxJQUFJLEtBQUssV0FBVyxFQUFFO2dCQUN2QyxVQUFVLEdBQUcsT0FBTyxDQUFDLEtBQUssQ0FBQyxJQUFJLEdBQUcsV0FBVyxDQUFDO2FBQ3JEO1lBQ0QsT0FBTyxVQUFVLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxJQUFJLElBQUksRUFBRSxDQUFDLFdBQVcsRUFBRSxDQUFDLEVBQUUsWUFBWSxFQUFFLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQztRQUM1RSxDQUFDLENBQUM7SUFDTixDQUFDOzs7WUFyREosVUFBVSIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IEluamVjdGFibGUgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcclxuaW1wb3J0IHsgRm9ybUNvbnRyb2wsIEZvcm1Hcm91cCwgVmFsaWRhdG9ycywgVmFsaWRhdG9yRm4sIEFic3RyYWN0Q29udHJvbCB9IGZyb20gJ0Bhbmd1bGFyL2Zvcm1zJztcclxuXHJcbmltcG9ydCB7IElucHV0QmFzZSB9IGZyb20gJy4va2QtaW5wdXQtYmFzZSc7XHJcblxyXG5ASW5qZWN0YWJsZSgpXHJcbmV4cG9ydCBjbGFzcyBLZElucHV0Q29udHJvbFNlcnZpY2Uge1xyXG4gICAgY29uc3RydWN0b3IoKSB7IH1cclxuXHJcbiAgICB0b0Zvcm1Hcm91cChpbnB1dHM6IElucHV0QmFzZTxhbnk+W10pOiBGb3JtR3JvdXAge1xyXG4gICAgICAgIGxldCBncm91cDogYW55ID0ge307XHJcblxyXG4gICAgICAgIGZvciAobGV0IGkgPSAwOyBpIDwgaW5wdXRzLmxlbmd0aDsgaSsrKSB7XHJcbiAgICAgICAgICAgIGxldCB2YWxpZGF0b3JBcnI6IEFycmF5PFZhbGlkYXRvckZuPiA9IFtdO1xyXG5cclxuXHJcbiAgICAgICAgICAgIC8vIEdyYWNlIC0tIDcgTm92IDIwMTcgLS1cclxuICAgICAgICAgICAgLy8gdGVzdGluZyBnZW5lcmF0ZSB2YWxpZGF0b3IgZnVuY3Rpb24gYnkgcGFzc2luZyB2YWxpZGF0aW9uIGxvZ2ljIGFzIHN0cmluZyBidXQgbG9hZCBzcGVlZCB3aWxsIGJlY29tZSB2ZXJ5IHNsb3dcclxuICAgICAgICAgICAgLy8gaWYoaW5wdXRzW2ldLmdldFByb3BlcnR5KCdyZXF1aXJlZCcpKXtcclxuICAgICAgICAgICAgLy8gICAgIHZhbGlkYXRvckFyci5wdXNoKHRoaXMuX2dlbmVyYWxWYWxpZGF0b3JGbkdlbmVyYXRvcih7XHJcbiAgICAgICAgICAgIC8vICAgICAgICAgdGFyZ2V0OiAnY29udHJvbC52YWx1ZScsXHJcbiAgICAgICAgICAgIC8vICAgICAgICAgY29tcGFyZTogJycsXHJcbiAgICAgICAgICAgIC8vICAgICAgICAgbG9naWM6ICdyZXR1cm4gYSAhPT0gYj8gZmFsc2U6IHRydWUnXHJcbiAgICAgICAgICAgIC8vICAgICB9LCAndGhpcyBmaWVsZCBjYW5ub3QgYmUgZW1wdHknICkpXHJcbiAgICAgICAgICAgIC8vIH1cclxuXHJcbiAgICAgICAgICAgIGlmIChpbnB1dHNbaV0uZ2V0UHJvcGVydHkoJ2NvbnRyb2xUeXBlJykgPT09ICdmaWxlLWlucHV0Jykge1xyXG4gICAgICAgICAgICAgICAgY29uc3QgY29uZmlnID0gaW5wdXRzW2ldLmdldFByb3BlcnR5KCdjb25maWcnKTtcclxuICAgICAgICAgICAgICAgIHZhbGlkYXRvckFyci5wdXNoKHRoaXMuX2ZpbGVTaXplVmFsaWRhdG9yKGNvbmZpZy5tYXhGaWxlU2l6ZSwgY29uZmlnLmVycm9yTWVzc2FnZSkpO1xyXG4gICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICAvLyBpZiAoaW5wdXRzW2ldLmdldFByb3BlcnR5KCdyZXF1aXJlZCcpKSB7XHJcbiAgICAgICAgICAgIC8vICAgICB2YWxpZGF0b3JBcnIucHVzaCh0aGlzLl9yZXF1aXJlZFZhbGlkYXRvcignVGhpcyBmaWVsZCBzaG91bGQgbm90IGJlIGVtcHR5JykpO1xyXG4gICAgICAgICAgICAvLyB9XHJcblxyXG4gICAgICAgICAgICBncm91cFtpbnB1dHNbaV0uZ2V0UHJvcGVydHkoJ2tleScpXSA9IG5ldyBGb3JtQ29udHJvbChcclxuICAgICAgICAgICAgICAgIGlucHV0c1tpXS5nZXRQcm9wZXJ0eSgndmFsdWUnKSB8fCAnJyxcclxuICAgICAgICAgICAgICAgIFZhbGlkYXRvcnMuY29tcG9zZSh2YWxpZGF0b3JBcnIpXHJcbiAgICAgICAgICAgICk7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIHJldHVybiBuZXcgRm9ybUdyb3VwKGdyb3VwKTtcclxuICAgIH1cclxuXHJcbiAgICBlbXB0eUZvcm1Hcm91cCgpOiBGb3JtR3JvdXAge1xyXG4gICAgICAgIHJldHVybiBuZXcgRm9ybUdyb3VwKHt9KTtcclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF9maWxlU2l6ZVZhbGlkYXRvcihtYXhGaWxlU2l6ZTogbnVtYmVyLCBlcnJvck1lc3NhZ2U6IHN0cmluZyk6IFZhbGlkYXRvckZuIHtcclxuICAgICAgICByZXR1cm4gKGNvbnRyb2w6IEFic3RyYWN0Q29udHJvbCk6IHsgW2tleTogc3RyaW5nXTogYW55IH0gPT4ge1xyXG4gICAgICAgICAgICBsZXQgc2l6ZUV4Y2VlZDogYm9vbGVhbiA9IGZhbHNlO1xyXG5cclxuICAgICAgICAgICAgaWYgKHR5cGVvZiBjb250cm9sICE9PSAndW5kZWZpbmVkJyAmJlxyXG4gICAgICAgICAgICAgICAgdHlwZW9mIGNvbnRyb2wudmFsdWUgIT09ICd1bmRlZmluZWQnICYmXHJcbiAgICAgICAgICAgICAgICB0eXBlb2YgY29udHJvbC52YWx1ZS5zaXplICE9PSAndW5kZWZpbmVkJykge1xyXG4gICAgICAgICAgICAgICAgICAgIHNpemVFeGNlZWQgPSBjb250cm9sLnZhbHVlLnNpemUgPiBtYXhGaWxlU2l6ZTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICByZXR1cm4gc2l6ZUV4Y2VlZCA/IHsgW25ldyBEYXRlKCkudG9JU09TdHJpbmcoKV06IGVycm9yTWVzc2FnZSB9IDogbnVsbDtcclxuICAgICAgICB9O1xyXG4gICAgfVxyXG5cclxuICAgIC8vIHByaXZhdGUgX3JlcXVpcmVkVmFsaWRhdG9yKGVycm9yTWVzc2FnZTogc3RyaW5nKTogVmFsaWRhdG9yRm4ge1xyXG4gICAgLy8gICAgIHJldHVybiAoY29udHJvbDogQWJzdHJhY3RDb250cm9sKToge1trZXk6IHN0cmluZ106IGFueX0gPT4ge1xyXG4gICAgLy8gICAgICAgICBpZiAodHlwZW9mIGNvbnRyb2wudmFsdWUgIT09ICd1bmRlZmluZWQnKSB7XHJcbiAgICAvLyAgICAgICAgICAgICBjb25zdCBlcnJvcjogYm9vbGVhbiA9IGNvbnRyb2wudmFsdWUgPT09ICcnID8gdHJ1ZSA6IGZhbHNlO1xyXG4gICAgLy8gICAgICAgICAgICAgcmV0dXJuIGVycm9yID8ge1tuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nICgpXTogZXJyb3JNZXNzYWdlfSA6IG51bGw7XHJcbiAgICAvLyAgICAgICAgIH1cclxuICAgIC8vICAgICB9O1xyXG4gICAgLy8gfVxyXG5cclxuICAgIC8vIEdyYWNlIC0tIDcgTm92IDIwMTcgLS0gZ2VuZXJhbCB2YWxpZGF0b3IgZnVuY3Rpb24gZ2VuZXJhdG9yXHJcbiAgICAvLyBwcml2YXRlIF9nZW5lcmFsVmFsaWRhdG9yRm5HZW5lcmF0b3IobG9naWNUb1Rlc3Q6b2JqZWN0LCBlcnJvck1lc3NhZ2U6IHN0cmluZyk6VmFsaWRhdG9yRm4ge1xyXG4gICAgLy8gICAgIHJldHVybiAoY29udHJvbDogQWJzdHJhY3RDb250cm9sKToge1trZXk6IHN0cmluZ106IGFueX0gPT4ge1xyXG4gICAgLy8gICAgIGxldCBsb2dpY0Z1bmN0aW9uID0gbmV3IEZ1bmN0aW9uKCdhJywnYicsIGxvZ2ljVG9UZXN0LmxvZ2ljKVxyXG4gICAgLy8gICAgIGxldCBlcnJvciA9IGxvZ2ljRnVuY3Rpb24oZXZhbChsb2dpY1RvVGVzdC50YXJnZXQpLGxvZ2ljVG9UZXN0LmNvbXBhcmUpO1xyXG4gICAgLy8gICAgIHJldHVybiBlcnJvciA/IHsgW25ldyBEYXRlKCkudG9JU09TdHJpbmcgKCldIDogZXJyb3JNZXNzYWdlfSA6IG51bGw7XHJcbiAgICAvLyAgIH07XHJcbiAgICAvLyB9XHJcbn1cclxuIl19