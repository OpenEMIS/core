import { Component, Input, ViewEncapsulation, ViewContainerRef, ChangeDetectorRef, Renderer2 } from '@angular/core';
import { timer } from 'rxjs';
import { Router, NavigationEnd } from '@angular/router';
import { KdDomElemSvc } from '../kd-common/index';
import { KdLeftmenuSvc } from './kd-angular-leftmenu-svc';
export class KdLeftMenu {
    constructor(_renderer, _vcr, _leftmenuSvc, _router, _cdf, _domSvc) {
        this._renderer = _renderer;
        this._vcr = _vcr;
        this._leftmenuSvc = _leftmenuSvc;
        this._router = _router;
        this._cdf = _cdf;
        this._domSvc = _domSvc;
        this.list = [];
        this._previousId = [];
        this._previousItem = {};
        this._activeIdFound = false;
        this._firstRouteCheck = true;
        this._currentRoute = '';
        this._routerSub = _router.events.subscribe(event => {
            if (event instanceof NavigationEnd) {
                this._currentRoute = event.urlAfterRedirects;
                if (!this._firstRouteCheck) {
                    this._setInitOpen(event.urlAfterRedirects);
                    // close the previous item if current clicked path do not much any path in the sidemenu
                    if (!this._activeIdFound && typeof this._previousItem.nav_id !== 'undefined') {
                        let close = this._leftmenuSvc.getId(this._previousItem);
                        this._leftmenuSvc.toggleState(close, 'close', this.list);
                        this._previousId = [];
                        this._previousItem = {};
                    }
                }
            }
        });
    }
    ngOnInit() {
        this._initApi();
    }
    ngOnChanges(_simpleChanges) {
        if (_simpleChanges.hasOwnProperty('sideConfig')) {
            this.list = this._leftmenuSvc.setIsOpen(this.sideConfig);
            if (_simpleChanges.sideConfig.isFirstChange) {
                this._setAlpha(true);
                timer(500).subscribe(() => {
                    this._setInitOpen(this._router.url);
                    this._setAlpha(false);
                    this._firstRouteCheck = false;
                });
            }
        }
    }
    ngAfterViewInit() { }
    ngOnDestroy() {
        if (typeof this._routerSub !== 'undefined') {
            this._routerSub.unsubscribe();
        }
    }
    clickToggle(item) {
        this._checkToggle(item);
        if (typeof item.list === 'undefined') {
            this._checkPathAndNavigate(item);
        }
        // triggers click event when api is initialised
        if (this.api)
            this._leftmenuSvc.menuItemClicked(item);
    }
    getPaddingSize(_itemId) {
        let size = 10;
        let navLevels = _itemId.split('-');
        if (navLevels.length > 2) {
            size += (17 * (navLevels.length - 2));
        }
        // console.log(_itemId);
        if (this._domSvc.getDocumentDirection().toLowerCase() === 'ltr')
            return '10px 25px 10px ' + size + 'px';
        else
            return '10px ' + size + 'px 10px 25px';
    }
    getItemOrder(_item) {
        return (typeof _item.order === 'undefined') ? 1 : _item.order;
    }
    _checkPathAndNavigate(item) {
        if (typeof item.path !== 'undefined') {
            this._router.navigate([item.path]);
        }
        else {
            this._router.navigate(['/']);
        }
    }
    _setAlpha(bool) {
        let ulList = this._vcr.element.nativeElement.querySelector('ul.nav.root-nav');
        bool ? this._renderer.addClass(ulList, 'alpha-0') : this._renderer.removeClass(ulList, 'alpha-0');
    }
    _setInitOpen(rawUrl) {
        this._activeIdFound = false;
        let url = rawUrl.split('/');
        let testUrl = [];
        let joinUrl = '';
        for (let i = url.length - 1; i >= 0; i--) {
            testUrl = [];
            //  console.log('----> round ' + i);
            for (let j = 0; j <= i; j++) {
                testUrl.push(url[j]);
            }
            joinUrl = testUrl.join('/').substring(1);
            if (this._activeIdFound === false) {
                // this._cdf.detach();
                this._checkPath(joinUrl, this.list);
                this._cdf.detectChanges();
                // this._cdf.reattach();
            }
        }
    }
    _checkPath(url, itemList) {
        let resultPath = '';
        for (let i = 0; i < itemList.length; i++) {
            if (typeof itemList[i].list !== 'undefined') {
                this._checkPath(url, itemList[i].list);
            }
            resultPath = (typeof itemList[i].basePath !== 'undefined' && itemList[i].basePath[0] === '/') ? itemList[i].basePath.substring(1) : itemList[i].basePath;
            if (resultPath === url) {
                this._itemSelected(itemList[i]);
                this._activeIdFound = true;
                break;
            }
        }
    }
    _itemSelected(item) {
        this._checkToggle(item);
        this._previousItem.isSelected = false;
        this._previousItem = item;
        item.isSelected = true;
    }
    _checkToggle(item) {
        let currentId = this._leftmenuSvc.getId(item);
        // if user clicked the same, toggle state
        if (this._leftmenuSvc.isArrayEqual(currentId, this._previousId) && item.hasOwnProperty('isOpen')) {
            this._leftmenuSvc.toggleState(currentId, 'toggle', this.list);
        }
        // if user clicked on something more on the surface, check
        else if (this._previousId.length > currentId.length) {
            //  this._closeDifferent(currentId, this._previousId);
            this._leftmenuSvc.closeDifferent(currentId, this._previousId, this.list);
        }
        // if user clicked on something deeper, close previous and open current
        else {
            //  if (item.hasOwnProperty('isOpen')) {
            if (this._previousId.length > 0) {
                this._leftmenuSvc.toggleState(this._previousId, 'close', this.list);
            }
            //  }
            this._leftmenuSvc.toggleState(currentId, 'open', this.list);
        }
        this._previousId = currentId;
    }
    _initApi() {
        if (!this.api)
            return;
        this.api.onMenuItemClicked = this._leftmenuSvc.onMenuItemClicked();
        this.api.updateMenuList = (_nav_id, _list) => {
            let navPos = this._leftmenuSvc.getId(_nav_id);
            let selectedItem = {};
            if (navPos.length > 0) {
                selectedItem = this.list[navPos[0]];
                for (let i = 1; i < navPos.length; i++) {
                    selectedItem = selectedItem.list[navPos[i]];
                }
                if (typeof _list !== 'undefined') {
                    selectedItem['list'] = _list;
                    this.list = this._leftmenuSvc.setIsOpen(this.list);
                    this._setInitOpen(this._currentRoute);
                }
            }
        };
    }
}
KdLeftMenu.decorators = [
    { type: Component, args: [{
                selector: 'kd-leftmenu',
                template: "<div class=\"kdx-left-menu\">\r\n    <div class=\"panel-group\">\r\n        <ul class=\"nav root-nav\">\r\n            <ng-template #recursiveList let-list>\r\n                <li *ngFor=\"let item of list\" [style.order]=\"getItemOrder(item)\">\r\n                    <a [ngClass]=\"{'selected': item.isSelected, 'accordion-toggle': item.list, 'expand': item.isOpen}\" \r\n                    [hidden]=\"item.selected\" \r\n                    [attr.id]=\"item.nav_id\" \r\n                    (click)=\"clickToggle(item)\" \r\n                    [style.padding]=\"getPaddingSize(item.nav_id)\">\r\n                        <i *ngIf=\"item.icon\" class=\"{{item.icon}}\"></i><span>{{item.header}}</span>\r\n                    </a>\r\n                    <ul *ngIf=\"item.list\" class=\"nav\" [ngClass]=\"{'toggle': item.isOpen, 'untoggle': !item.isOpen}\">\r\n                        <ng-container *ngTemplateOutlet=\"recursiveList; context:{ $implicit: item.list }\"></ng-container>\r\n                    </ul>\r\n                </li>\r\n            </ng-template>\r\n            <ng-container *ngTemplateOutlet=\"recursiveList; context:{ $implicit: list }\"></ng-container>\r\n        </ul>\r\n    </div>\r\n</div>\r\n",
                encapsulation: ViewEncapsulation.None,
                providers: [KdLeftmenuSvc, KdDomElemSvc],
                styles: [`
        .alpha-0{
            opacity: 0;
        }
    `]
            },] }
];
KdLeftMenu.ctorParameters = () => [
    { type: Renderer2 },
    { type: ViewContainerRef },
    { type: KdLeftmenuSvc },
    { type: Router },
    { type: ChangeDetectorRef },
    { type: KdDomElemSvc }
];
KdLeftMenu.propDecorators = {
    sideConfig: [{ type: Input, args: ['config',] }],
    api: [{ type: Input }]
};
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoia2QtYW5ndWxhci1sZWZ0bWVudS5qcyIsInNvdXJjZVJvb3QiOiJDOi94YW1wcC9odGRvY3MvU3R5bGVndWlkZS9pb3N0Zy1vcGVuZW1pcy1zdHlsZWd1aWRlL3Byb2plY3RzL29wZW5lbWlzLXN0eWxlZ3VpZGUtbGliL3NyYy8iLCJzb3VyY2VzIjpbImtkLWNvbXBvbmVudHMva2QtYW5ndWxhci1sZWZ0bWVudS9rZC1hbmd1bGFyLWxlZnRtZW51LnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBLE9BQU8sRUFBRSxTQUFTLEVBQUUsS0FBSyxFQUF5QixpQkFBaUIsRUFBRSxnQkFBZ0IsRUFBRSxpQkFBaUIsRUFBaUIsU0FBUyxFQUFFLE1BQU0sZUFBZSxDQUFDO0FBQzFKLE9BQU8sRUFBRSxLQUFLLEVBQWdCLE1BQU0sTUFBTSxDQUFDO0FBQzNDLE9BQU8sRUFBRSxNQUFNLEVBQUUsYUFBYSxFQUFFLE1BQU0saUJBQWlCLENBQUM7QUFDeEQsT0FBTyxFQUFFLFlBQVksRUFBRSxNQUFNLG9CQUFvQixDQUFDO0FBQ2xELE9BQU8sRUFBRSxhQUFhLEVBQUUsTUFBTSwyQkFBMkIsQ0FBQztBQWMxRCxNQUFNLE9BQU8sVUFBVTtJQVluQixZQUNZLFNBQW9CLEVBQ3BCLElBQXNCLEVBQ3RCLFlBQTJCLEVBQzNCLE9BQWUsRUFDZixJQUF1QixFQUN2QixPQUFxQjtRQUxyQixjQUFTLEdBQVQsU0FBUyxDQUFXO1FBQ3BCLFNBQUksR0FBSixJQUFJLENBQWtCO1FBQ3RCLGlCQUFZLEdBQVosWUFBWSxDQUFlO1FBQzNCLFlBQU8sR0FBUCxPQUFPLENBQVE7UUFDZixTQUFJLEdBQUosSUFBSSxDQUFtQjtRQUN2QixZQUFPLEdBQVAsT0FBTyxDQUFjO1FBakIxQixTQUFJLEdBQWUsRUFBRSxDQUFDO1FBQ3JCLGdCQUFXLEdBQWtCLEVBQUUsQ0FBQztRQUNoQyxrQkFBYSxHQUFRLEVBQUUsQ0FBQztRQUN4QixtQkFBYyxHQUFZLEtBQUssQ0FBQztRQUNoQyxxQkFBZ0IsR0FBWSxJQUFJLENBQUM7UUFFakMsa0JBQWEsR0FBVyxFQUFFLENBQUM7UUFhL0IsSUFBSSxDQUFDLFVBQVUsR0FBRyxPQUFPLENBQUMsTUFBTSxDQUFDLFNBQVMsQ0FBQyxLQUFLLENBQUMsRUFBRTtZQUMvQyxJQUFJLEtBQUssWUFBWSxhQUFhLEVBQUU7Z0JBQ2hDLElBQUksQ0FBQyxhQUFhLEdBQUcsS0FBSyxDQUFDLGlCQUFpQixDQUFDO2dCQUM3QyxJQUFJLENBQUMsSUFBSSxDQUFDLGdCQUFnQixFQUFFO29CQUN4QixJQUFJLENBQUMsWUFBWSxDQUFDLEtBQUssQ0FBQyxpQkFBaUIsQ0FBQyxDQUFDO29CQUMzQyx1RkFBdUY7b0JBQ3ZGLElBQUksQ0FBQyxJQUFJLENBQUMsY0FBYyxJQUFJLE9BQU8sSUFBSSxDQUFDLGFBQWEsQ0FBQyxNQUFNLEtBQUssV0FBVyxFQUFFO3dCQUMxRSxJQUFJLEtBQUssR0FBZSxJQUFJLENBQUMsWUFBWSxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsYUFBYSxDQUFDLENBQUM7d0JBQ3BFLElBQUksQ0FBQyxZQUFZLENBQUMsV0FBVyxDQUFDLEtBQUssRUFBRSxPQUFPLEVBQUUsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDO3dCQUN6RCxJQUFJLENBQUMsV0FBVyxHQUFHLEVBQUUsQ0FBQzt3QkFDdEIsSUFBSSxDQUFDLGFBQWEsR0FBRyxFQUFFLENBQUM7cUJBQzNCO2lCQUNKO2FBQ0o7UUFDTCxDQUFDLENBQUMsQ0FBQztJQUNQLENBQUM7SUFFRCxRQUFRO1FBQ0osSUFBSSxDQUFDLFFBQVEsRUFBRSxDQUFDO0lBQ3BCLENBQUM7SUFFRCxXQUFXLENBQUMsY0FBNkI7UUFDckMsSUFBSSxjQUFjLENBQUMsY0FBYyxDQUFDLFlBQVksQ0FBQyxFQUFFO1lBQzdDLElBQUksQ0FBQyxJQUFJLEdBQUcsSUFBSSxDQUFDLFlBQVksQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxDQUFDO1lBRXpELElBQUksY0FBYyxDQUFDLFVBQVUsQ0FBQyxhQUFhLEVBQUU7Z0JBQ3pDLElBQUksQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDLENBQUM7Z0JBRXJCLEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FBQyxTQUFTLENBQUMsR0FBRyxFQUFFO29CQUN0QixJQUFJLENBQUMsWUFBWSxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLENBQUM7b0JBQ3BDLElBQUksQ0FBQyxTQUFTLENBQUMsS0FBSyxDQUFDLENBQUM7b0JBQ3RCLElBQUksQ0FBQyxnQkFBZ0IsR0FBRyxLQUFLLENBQUM7Z0JBQ2xDLENBQUMsQ0FBQyxDQUFDO2FBQ047U0FDSjtJQUNMLENBQUM7SUFFRCxlQUFlLEtBQVcsQ0FBQztJQUUzQixXQUFXO1FBQ1AsSUFBSSxPQUFPLElBQUksQ0FBQyxVQUFVLEtBQUssV0FBVyxFQUFFO1lBQ3hDLElBQUksQ0FBQyxVQUFVLENBQUMsV0FBVyxFQUFFLENBQUM7U0FDakM7SUFDTCxDQUFDO0lBRU0sV0FBVyxDQUFDLElBQVM7UUFDeEIsSUFBSSxDQUFDLFlBQVksQ0FBQyxJQUFJLENBQUMsQ0FBQztRQUV4QixJQUFJLE9BQU8sSUFBSSxDQUFDLElBQUksS0FBSyxXQUFXLEVBQUU7WUFDbEMsSUFBSSxDQUFDLHFCQUFxQixDQUFDLElBQUksQ0FBQyxDQUFDO1NBQ3BDO1FBRUQsK0NBQStDO1FBQy9DLElBQUksSUFBSSxDQUFDLEdBQUc7WUFBRSxJQUFJLENBQUMsWUFBWSxDQUFDLGVBQWUsQ0FBQyxJQUFJLENBQUMsQ0FBQztJQUMxRCxDQUFDO0lBRU0sY0FBYyxDQUFDLE9BQWU7UUFDakMsSUFBSSxJQUFJLEdBQVcsRUFBRSxDQUFDO1FBQ3RCLElBQUksU0FBUyxHQUFrQixPQUFPLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDO1FBRWxELElBQUksU0FBUyxDQUFDLE1BQU0sR0FBRyxDQUFDLEVBQUU7WUFDdEIsSUFBSSxJQUFJLENBQUMsRUFBRSxHQUFHLENBQUMsU0FBUyxDQUFDLE1BQU0sR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDO1NBQ3pDO1FBQ0Qsd0JBQXdCO1FBQ3hCLElBQUksSUFBSSxDQUFDLE9BQU8sQ0FBQyxvQkFBb0IsRUFBRSxDQUFDLFdBQVcsRUFBRSxLQUFLLEtBQUs7WUFBRSxPQUFPLGlCQUFpQixHQUFHLElBQUksR0FBRyxJQUFJLENBQUM7O1lBQ25HLE9BQU8sT0FBTyxHQUFHLElBQUksR0FBRyxjQUFjLENBQUM7SUFDaEQsQ0FBQztJQUVNLFlBQVksQ0FBQyxLQUFVO1FBQzFCLE9BQU8sQ0FBQyxPQUFPLEtBQUssQ0FBQyxLQUFLLEtBQUssV0FBVyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQztJQUNsRSxDQUFDO0lBRU8scUJBQXFCLENBQUMsSUFBUztRQUNuQyxJQUFJLE9BQU8sSUFBSSxDQUFDLElBQUksS0FBSyxXQUFXLEVBQUU7WUFDbEMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxRQUFRLENBQUMsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQztTQUN0QzthQUNJO1lBQ0QsSUFBSSxDQUFDLE9BQU8sQ0FBQyxRQUFRLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDO1NBQ2hDO0lBQ0wsQ0FBQztJQUVPLFNBQVMsQ0FBQyxJQUFhO1FBQzNCLElBQUksTUFBTSxHQUFHLElBQUksQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLGFBQWEsQ0FBQyxhQUFhLENBQUMsaUJBQWlCLENBQUMsQ0FBQztRQUM5RSxJQUFJLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsUUFBUSxDQUFDLE1BQU0sRUFBRSxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxXQUFXLENBQUMsTUFBTSxFQUFFLFNBQVMsQ0FBQyxDQUFDO0lBQ3RHLENBQUM7SUFFTyxZQUFZLENBQUMsTUFBYztRQUMvQixJQUFJLENBQUMsY0FBYyxHQUFHLEtBQUssQ0FBQztRQUM1QixJQUFJLEdBQUcsR0FBZSxNQUFNLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDO1FBQ3hDLElBQUksT0FBTyxHQUFlLEVBQUUsQ0FBQztRQUM3QixJQUFJLE9BQU8sR0FBVyxFQUFFLENBQUM7UUFFekIsS0FBSyxJQUFJLENBQUMsR0FBVyxHQUFHLENBQUMsTUFBTSxHQUFHLENBQUMsRUFBRSxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFO1lBQzlDLE9BQU8sR0FBRyxFQUFFLENBQUM7WUFDYixvQ0FBb0M7WUFDcEMsS0FBSyxJQUFJLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRTtnQkFDekIsT0FBTyxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQzthQUN4QjtZQUVELE9BQU8sR0FBRyxPQUFPLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQztZQUN6QyxJQUFJLElBQUksQ0FBQyxjQUFjLEtBQUssS0FBSyxFQUFFO2dCQUMvQixzQkFBc0I7Z0JBQ3RCLElBQUksQ0FBQyxVQUFVLENBQUMsT0FBTyxFQUFFLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQztnQkFDcEMsSUFBSSxDQUFDLElBQUksQ0FBQyxhQUFhLEVBQUUsQ0FBQztnQkFDMUIsd0JBQXdCO2FBQzNCO1NBQ0o7SUFDTCxDQUFDO0lBRU8sVUFBVSxDQUFDLEdBQVcsRUFBRSxRQUFvQjtRQUNoRCxJQUFJLFVBQVUsR0FBVyxFQUFFLENBQUM7UUFFNUIsS0FBSyxJQUFJLENBQUMsR0FBVyxDQUFDLEVBQUUsQ0FBQyxHQUFHLFFBQVEsQ0FBQyxNQUFNLEVBQUUsQ0FBQyxFQUFFLEVBQUU7WUFDOUMsSUFBSSxPQUFPLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLEtBQUssV0FBVyxFQUFFO2dCQUN6QyxJQUFJLENBQUMsVUFBVSxDQUFDLEdBQUcsRUFBRSxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUM7YUFDMUM7WUFFRCxVQUFVLEdBQUcsQ0FBQyxPQUFPLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLEtBQUssV0FBVyxJQUFJLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLEtBQUssR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDO1lBRXpKLElBQUksVUFBVSxLQUFLLEdBQUcsRUFBRTtnQkFDcEIsSUFBSSxDQUFDLGFBQWEsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztnQkFDaEMsSUFBSSxDQUFDLGNBQWMsR0FBRyxJQUFJLENBQUM7Z0JBQzNCLE1BQU07YUFDVDtTQUNKO0lBQ0wsQ0FBQztJQUVPLGFBQWEsQ0FBQyxJQUFTO1FBQzNCLElBQUksQ0FBQyxZQUFZLENBQUMsSUFBSSxDQUFDLENBQUM7UUFDeEIsSUFBSSxDQUFDLGFBQWEsQ0FBQyxVQUFVLEdBQUcsS0FBSyxDQUFDO1FBQ3RDLElBQUksQ0FBQyxhQUFhLEdBQUcsSUFBSSxDQUFDO1FBQzFCLElBQUksQ0FBQyxVQUFVLEdBQUcsSUFBSSxDQUFDO0lBQzNCLENBQUM7SUFFTyxZQUFZLENBQUMsSUFBUztRQUMxQixJQUFJLFNBQVMsR0FBRyxJQUFJLENBQUMsWUFBWSxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsQ0FBQztRQUU5Qyx5Q0FBeUM7UUFDekMsSUFBSSxJQUFJLENBQUMsWUFBWSxDQUFDLFlBQVksQ0FBQyxTQUFTLEVBQUUsSUFBSSxDQUFDLFdBQVcsQ0FBQyxJQUFJLElBQUksQ0FBQyxjQUFjLENBQUMsUUFBUSxDQUFDLEVBQUU7WUFDOUYsSUFBSSxDQUFDLFlBQVksQ0FBQyxXQUFXLENBQUMsU0FBUyxFQUFFLFFBQVEsRUFBRSxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUM7U0FDakU7UUFFRCwwREFBMEQ7YUFDckQsSUFBSSxJQUFJLENBQUMsV0FBVyxDQUFDLE1BQU0sR0FBRyxTQUFTLENBQUMsTUFBTSxFQUFFO1lBQ2pELHNEQUFzRDtZQUN0RCxJQUFJLENBQUMsWUFBWSxDQUFDLGNBQWMsQ0FBQyxTQUFTLEVBQUUsSUFBSSxDQUFDLFdBQVcsRUFBRSxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUM7U0FDNUU7UUFFRCx1RUFBdUU7YUFDbEU7WUFDRCx3Q0FBd0M7WUFDeEMsSUFBSSxJQUFJLENBQUMsV0FBVyxDQUFDLE1BQU0sR0FBRyxDQUFDLEVBQUU7Z0JBQzdCLElBQUksQ0FBQyxZQUFZLENBQUMsV0FBVyxDQUFDLElBQUksQ0FBQyxXQUFXLEVBQUUsT0FBTyxFQUFFLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQzthQUN2RTtZQUNELEtBQUs7WUFDTCxJQUFJLENBQUMsWUFBWSxDQUFDLFdBQVcsQ0FBQyxTQUFTLEVBQUUsTUFBTSxFQUFFLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQztTQUMvRDtRQUNELElBQUksQ0FBQyxXQUFXLEdBQUcsU0FBUyxDQUFDO0lBQ2pDLENBQUM7SUFFTyxRQUFRO1FBQ1osSUFBSSxDQUFDLElBQUksQ0FBQyxHQUFHO1lBQUUsT0FBTztRQUV0QixJQUFJLENBQUMsR0FBRyxDQUFDLGlCQUFpQixHQUFHLElBQUksQ0FBQyxZQUFZLENBQUMsaUJBQWlCLEVBQUUsQ0FBQztRQUVuRSxJQUFJLENBQUMsR0FBRyxDQUFDLGNBQWMsR0FBRyxDQUFDLE9BQWUsRUFBRSxLQUFrQixFQUFFLEVBQUU7WUFDOUQsSUFBSSxNQUFNLEdBQWtCLElBQUksQ0FBQyxZQUFZLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxDQUFDO1lBQzdELElBQUksWUFBWSxHQUFRLEVBQUUsQ0FBQztZQUMzQixJQUFJLE1BQU0sQ0FBQyxNQUFNLEdBQUcsQ0FBQyxFQUFFO2dCQUNuQixZQUFZLEdBQUcsSUFBSSxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztnQkFDcEMsS0FBSyxJQUFJLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxHQUFHLE1BQU0sQ0FBQyxNQUFNLEVBQUUsQ0FBQyxFQUFFLEVBQUU7b0JBQ3BDLFlBQVksR0FBRyxZQUFZLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO2lCQUMvQztnQkFFRCxJQUFJLE9BQU8sS0FBSyxLQUFLLFdBQVcsRUFBRTtvQkFDOUIsWUFBWSxDQUFDLE1BQU0sQ0FBQyxHQUFHLEtBQUssQ0FBQztvQkFDN0IsSUFBSSxDQUFDLElBQUksR0FBRyxJQUFJLENBQUMsWUFBWSxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUM7b0JBQ25ELElBQUksQ0FBQyxZQUFZLENBQUMsSUFBSSxDQUFDLGFBQWEsQ0FBQyxDQUFDO2lCQUN6QzthQUNKO1FBQ0wsQ0FBQyxDQUFDO0lBQ04sQ0FBQzs7O1lBck5KLFNBQVMsU0FBQztnQkFDUCxRQUFRLEVBQUUsYUFBYTtnQkFDdkIsb3RDQUF5QztnQkFNekMsYUFBYSxFQUFFLGlCQUFpQixDQUFDLElBQUk7Z0JBQ3JDLFNBQVMsRUFBRSxDQUFDLGFBQWEsRUFBRSxZQUFZLENBQUM7eUJBTi9COzs7O0tBSVI7YUFHSjs7O1lBaEJ3SCxTQUFTO1lBQTdELGdCQUFnQjtZQUk1RSxhQUFhO1lBRmIsTUFBTTtZQUZ3RSxpQkFBaUI7WUFHL0YsWUFBWTs7O3lCQXdCaEIsS0FBSyxTQUFDLFFBQVE7a0JBQ2QsS0FBSyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IENvbXBvbmVudCwgSW5wdXQsIE9uSW5pdCwgQWZ0ZXJWaWV3SW5pdCwgVmlld0VuY2Fwc3VsYXRpb24sIFZpZXdDb250YWluZXJSZWYsIENoYW5nZURldGVjdG9yUmVmLCBTaW1wbGVDaGFuZ2VzLCBSZW5kZXJlcjIgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcclxuaW1wb3J0IHsgdGltZXIsIFN1YnNjcmlwdGlvbiB9IGZyb20gJ3J4anMnO1xyXG5pbXBvcnQgeyBSb3V0ZXIsIE5hdmlnYXRpb25FbmQgfSBmcm9tICdAYW5ndWxhci9yb3V0ZXInO1xyXG5pbXBvcnQgeyBLZERvbUVsZW1TdmMgfSBmcm9tICcuLi9rZC1jb21tb24vaW5kZXgnO1xyXG5pbXBvcnQgeyBLZExlZnRtZW51U3ZjIH0gZnJvbSAnLi9rZC1hbmd1bGFyLWxlZnRtZW51LXN2Yyc7XHJcblxyXG5AQ29tcG9uZW50KHtcclxuICAgIHNlbGVjdG9yOiAna2QtbGVmdG1lbnUnLFxyXG4gICAgdGVtcGxhdGVVcmw6ICcuL2tkLWFuZ3VsYXItbGVmdG1lbnUuaHRtbCcsXHJcbiAgICBzdHlsZXM6IFtgXHJcbiAgICAgICAgLmFscGhhLTB7XHJcbiAgICAgICAgICAgIG9wYWNpdHk6IDA7XHJcbiAgICAgICAgfVxyXG4gICAgYF0sXHJcbiAgICBlbmNhcHN1bGF0aW9uOiBWaWV3RW5jYXBzdWxhdGlvbi5Ob25lLFxyXG4gICAgcHJvdmlkZXJzOiBbS2RMZWZ0bWVudVN2YywgS2REb21FbGVtU3ZjXVxyXG59KVxyXG5cclxuZXhwb3J0IGNsYXNzIEtkTGVmdE1lbnUgaW1wbGVtZW50cyBPbkluaXQsIEFmdGVyVmlld0luaXQge1xyXG4gICAgcHVibGljIGxpc3Q6IEFycmF5PGFueT4gPSBbXTtcclxuICAgIHByaXZhdGUgX3ByZXZpb3VzSWQ6IEFycmF5PG51bWJlcj4gPSBbXTtcclxuICAgIHByaXZhdGUgX3ByZXZpb3VzSXRlbTogYW55ID0ge307XHJcbiAgICBwcml2YXRlIF9hY3RpdmVJZEZvdW5kOiBib29sZWFuID0gZmFsc2U7XHJcbiAgICBwcml2YXRlIF9maXJzdFJvdXRlQ2hlY2s6IGJvb2xlYW4gPSB0cnVlO1xyXG4gICAgcHJpdmF0ZSBfcm91dGVyU3ViOiBTdWJzY3JpcHRpb247XHJcbiAgICBwcml2YXRlIF9jdXJyZW50Um91dGU6IHN0cmluZyA9ICcnO1xyXG5cclxuICAgIEBJbnB1dCgnY29uZmlnJykgc2lkZUNvbmZpZzogQXJyYXk8YW55PjtcclxuICAgIEBJbnB1dCgpIGFwaTogYW55O1xyXG5cclxuICAgIGNvbnN0cnVjdG9yKFxyXG4gICAgICAgIHByaXZhdGUgX3JlbmRlcmVyOiBSZW5kZXJlcjIsXHJcbiAgICAgICAgcHJpdmF0ZSBfdmNyOiBWaWV3Q29udGFpbmVyUmVmLFxyXG4gICAgICAgIHByaXZhdGUgX2xlZnRtZW51U3ZjOiBLZExlZnRtZW51U3ZjLFxyXG4gICAgICAgIHByaXZhdGUgX3JvdXRlcjogUm91dGVyLFxyXG4gICAgICAgIHByaXZhdGUgX2NkZjogQ2hhbmdlRGV0ZWN0b3JSZWYsXHJcbiAgICAgICAgcHJpdmF0ZSBfZG9tU3ZjOiBLZERvbUVsZW1TdmNcclxuICAgICkge1xyXG4gICAgICAgIHRoaXMuX3JvdXRlclN1YiA9IF9yb3V0ZXIuZXZlbnRzLnN1YnNjcmliZShldmVudCA9PiB7XHJcbiAgICAgICAgICAgIGlmIChldmVudCBpbnN0YW5jZW9mIE5hdmlnYXRpb25FbmQpIHtcclxuICAgICAgICAgICAgICAgIHRoaXMuX2N1cnJlbnRSb3V0ZSA9IGV2ZW50LnVybEFmdGVyUmVkaXJlY3RzO1xyXG4gICAgICAgICAgICAgICAgaWYgKCF0aGlzLl9maXJzdFJvdXRlQ2hlY2spIHtcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLl9zZXRJbml0T3BlbihldmVudC51cmxBZnRlclJlZGlyZWN0cyk7XHJcbiAgICAgICAgICAgICAgICAgICAgLy8gY2xvc2UgdGhlIHByZXZpb3VzIGl0ZW0gaWYgY3VycmVudCBjbGlja2VkIHBhdGggZG8gbm90IG11Y2ggYW55IHBhdGggaW4gdGhlIHNpZGVtZW51XHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKCF0aGlzLl9hY3RpdmVJZEZvdW5kICYmIHR5cGVvZiB0aGlzLl9wcmV2aW91c0l0ZW0ubmF2X2lkICE9PSAndW5kZWZpbmVkJykge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBsZXQgY2xvc2U6IEFycmF5PGFueT4gPSB0aGlzLl9sZWZ0bWVudVN2Yy5nZXRJZCh0aGlzLl9wcmV2aW91c0l0ZW0pO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLl9sZWZ0bWVudVN2Yy50b2dnbGVTdGF0ZShjbG9zZSwgJ2Nsb3NlJywgdGhpcy5saXN0KTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5fcHJldmlvdXNJZCA9IFtdO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLl9wcmV2aW91c0l0ZW0gPSB7fTtcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9KTtcclxuICAgIH1cclxuXHJcbiAgICBuZ09uSW5pdCgpOiB2b2lkIHtcclxuICAgICAgICB0aGlzLl9pbml0QXBpKCk7XHJcbiAgICB9XHJcblxyXG4gICAgbmdPbkNoYW5nZXMoX3NpbXBsZUNoYW5nZXM6IFNpbXBsZUNoYW5nZXMpOiB2b2lkIHtcclxuICAgICAgICBpZiAoX3NpbXBsZUNoYW5nZXMuaGFzT3duUHJvcGVydHkoJ3NpZGVDb25maWcnKSkge1xyXG4gICAgICAgICAgICB0aGlzLmxpc3QgPSB0aGlzLl9sZWZ0bWVudVN2Yy5zZXRJc09wZW4odGhpcy5zaWRlQ29uZmlnKTtcclxuXHJcbiAgICAgICAgICAgIGlmIChfc2ltcGxlQ2hhbmdlcy5zaWRlQ29uZmlnLmlzRmlyc3RDaGFuZ2UpIHtcclxuICAgICAgICAgICAgICAgIHRoaXMuX3NldEFscGhhKHRydWUpO1xyXG5cclxuICAgICAgICAgICAgICAgIHRpbWVyKDUwMCkuc3Vic2NyaWJlKCgpID0+IHtcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLl9zZXRJbml0T3Blbih0aGlzLl9yb3V0ZXIudXJsKTtcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLl9zZXRBbHBoYShmYWxzZSk7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5fZmlyc3RSb3V0ZUNoZWNrID0gZmFsc2U7XHJcbiAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICBuZ0FmdGVyVmlld0luaXQoKTogdm9pZCB7IH1cclxuXHJcbiAgICBuZ09uRGVzdHJveSgpOiB2b2lkIHtcclxuICAgICAgICBpZiAodHlwZW9mIHRoaXMuX3JvdXRlclN1YiAhPT0gJ3VuZGVmaW5lZCcpIHtcclxuICAgICAgICAgICAgdGhpcy5fcm91dGVyU3ViLnVuc3Vic2NyaWJlKCk7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIHB1YmxpYyBjbGlja1RvZ2dsZShpdGVtOiBhbnkpOiB2b2lkIHtcclxuICAgICAgICB0aGlzLl9jaGVja1RvZ2dsZShpdGVtKTtcclxuXHJcbiAgICAgICAgaWYgKHR5cGVvZiBpdGVtLmxpc3QgPT09ICd1bmRlZmluZWQnKSB7XHJcbiAgICAgICAgICAgIHRoaXMuX2NoZWNrUGF0aEFuZE5hdmlnYXRlKGl0ZW0pO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgLy8gdHJpZ2dlcnMgY2xpY2sgZXZlbnQgd2hlbiBhcGkgaXMgaW5pdGlhbGlzZWRcclxuICAgICAgICBpZiAodGhpcy5hcGkpIHRoaXMuX2xlZnRtZW51U3ZjLm1lbnVJdGVtQ2xpY2tlZChpdGVtKTtcclxuICAgIH1cclxuXHJcbiAgICBwdWJsaWMgZ2V0UGFkZGluZ1NpemUoX2l0ZW1JZDogc3RyaW5nKTogc3RyaW5nIHtcclxuICAgICAgICBsZXQgc2l6ZTogbnVtYmVyID0gMTA7XHJcbiAgICAgICAgbGV0IG5hdkxldmVsczogQXJyYXk8c3RyaW5nPiA9IF9pdGVtSWQuc3BsaXQoJy0nKTtcclxuXHJcbiAgICAgICAgaWYgKG5hdkxldmVscy5sZW5ndGggPiAyKSB7XHJcbiAgICAgICAgICAgIHNpemUgKz0gKDE3ICogKG5hdkxldmVscy5sZW5ndGggLSAyKSk7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIC8vIGNvbnNvbGUubG9nKF9pdGVtSWQpO1xyXG4gICAgICAgIGlmICh0aGlzLl9kb21TdmMuZ2V0RG9jdW1lbnREaXJlY3Rpb24oKS50b0xvd2VyQ2FzZSgpID09PSAnbHRyJykgcmV0dXJuICcxMHB4IDI1cHggMTBweCAnICsgc2l6ZSArICdweCc7XHJcbiAgICAgICAgZWxzZSByZXR1cm4gJzEwcHggJyArIHNpemUgKyAncHggMTBweCAyNXB4JztcclxuICAgIH1cclxuXHJcbiAgICBwdWJsaWMgZ2V0SXRlbU9yZGVyKF9pdGVtOiBhbnkpOiBudW1iZXIge1xyXG4gICAgICAgIHJldHVybiAodHlwZW9mIF9pdGVtLm9yZGVyID09PSAndW5kZWZpbmVkJykgPyAxIDogX2l0ZW0ub3JkZXI7XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfY2hlY2tQYXRoQW5kTmF2aWdhdGUoaXRlbTogYW55KTogdm9pZCB7XHJcbiAgICAgICAgaWYgKHR5cGVvZiBpdGVtLnBhdGggIT09ICd1bmRlZmluZWQnKSB7XHJcbiAgICAgICAgICAgIHRoaXMuX3JvdXRlci5uYXZpZ2F0ZShbaXRlbS5wYXRoXSk7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICB0aGlzLl9yb3V0ZXIubmF2aWdhdGUoWycvJ10pO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF9zZXRBbHBoYShib29sOiBib29sZWFuKTogdm9pZCB7XHJcbiAgICAgICAgbGV0IHVsTGlzdCA9IHRoaXMuX3Zjci5lbGVtZW50Lm5hdGl2ZUVsZW1lbnQucXVlcnlTZWxlY3RvcigndWwubmF2LnJvb3QtbmF2Jyk7XHJcbiAgICAgICAgYm9vbCA/IHRoaXMuX3JlbmRlcmVyLmFkZENsYXNzKHVsTGlzdCwgJ2FscGhhLTAnKSA6IHRoaXMuX3JlbmRlcmVyLnJlbW92ZUNsYXNzKHVsTGlzdCwgJ2FscGhhLTAnKTtcclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF9zZXRJbml0T3BlbihyYXdVcmw6IHN0cmluZyk6IHZvaWQge1xyXG4gICAgICAgIHRoaXMuX2FjdGl2ZUlkRm91bmQgPSBmYWxzZTtcclxuICAgICAgICBsZXQgdXJsOiBBcnJheTxhbnk+ID0gcmF3VXJsLnNwbGl0KCcvJyk7XHJcbiAgICAgICAgbGV0IHRlc3RVcmw6IEFycmF5PGFueT4gPSBbXTtcclxuICAgICAgICBsZXQgam9pblVybDogc3RyaW5nID0gJyc7XHJcblxyXG4gICAgICAgIGZvciAobGV0IGk6IG51bWJlciA9IHVybC5sZW5ndGggLSAxOyBpID49IDA7IGktLSkge1xyXG4gICAgICAgICAgICB0ZXN0VXJsID0gW107XHJcbiAgICAgICAgICAgIC8vICBjb25zb2xlLmxvZygnLS0tLT4gcm91bmQgJyArIGkpO1xyXG4gICAgICAgICAgICBmb3IgKGxldCBqID0gMDsgaiA8PSBpOyBqKyspIHtcclxuICAgICAgICAgICAgICAgIHRlc3RVcmwucHVzaCh1cmxbal0pO1xyXG4gICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICBqb2luVXJsID0gdGVzdFVybC5qb2luKCcvJykuc3Vic3RyaW5nKDEpO1xyXG4gICAgICAgICAgICBpZiAodGhpcy5fYWN0aXZlSWRGb3VuZCA9PT0gZmFsc2UpIHtcclxuICAgICAgICAgICAgICAgIC8vIHRoaXMuX2NkZi5kZXRhY2goKTtcclxuICAgICAgICAgICAgICAgIHRoaXMuX2NoZWNrUGF0aChqb2luVXJsLCB0aGlzLmxpc3QpO1xyXG4gICAgICAgICAgICAgICAgdGhpcy5fY2RmLmRldGVjdENoYW5nZXMoKTtcclxuICAgICAgICAgICAgICAgIC8vIHRoaXMuX2NkZi5yZWF0dGFjaCgpO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX2NoZWNrUGF0aCh1cmw6IHN0cmluZywgaXRlbUxpc3Q6IEFycmF5PGFueT4pOiB2b2lkIHtcclxuICAgICAgICBsZXQgcmVzdWx0UGF0aDogc3RyaW5nID0gJyc7XHJcblxyXG4gICAgICAgIGZvciAobGV0IGk6IG51bWJlciA9IDA7IGkgPCBpdGVtTGlzdC5sZW5ndGg7IGkrKykge1xyXG4gICAgICAgICAgICBpZiAodHlwZW9mIGl0ZW1MaXN0W2ldLmxpc3QgIT09ICd1bmRlZmluZWQnKSB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLl9jaGVja1BhdGgodXJsLCBpdGVtTGlzdFtpXS5saXN0KTtcclxuICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgcmVzdWx0UGF0aCA9ICh0eXBlb2YgaXRlbUxpc3RbaV0uYmFzZVBhdGggIT09ICd1bmRlZmluZWQnICYmIGl0ZW1MaXN0W2ldLmJhc2VQYXRoWzBdID09PSAnLycpID8gaXRlbUxpc3RbaV0uYmFzZVBhdGguc3Vic3RyaW5nKDEpIDogaXRlbUxpc3RbaV0uYmFzZVBhdGg7XHJcblxyXG4gICAgICAgICAgICBpZiAocmVzdWx0UGF0aCA9PT0gdXJsKSB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLl9pdGVtU2VsZWN0ZWQoaXRlbUxpc3RbaV0pO1xyXG4gICAgICAgICAgICAgICAgdGhpcy5fYWN0aXZlSWRGb3VuZCA9IHRydWU7XHJcbiAgICAgICAgICAgICAgICBicmVhaztcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF9pdGVtU2VsZWN0ZWQoaXRlbTogYW55KTogdm9pZCB7XHJcbiAgICAgICAgdGhpcy5fY2hlY2tUb2dnbGUoaXRlbSk7XHJcbiAgICAgICAgdGhpcy5fcHJldmlvdXNJdGVtLmlzU2VsZWN0ZWQgPSBmYWxzZTtcclxuICAgICAgICB0aGlzLl9wcmV2aW91c0l0ZW0gPSBpdGVtO1xyXG4gICAgICAgIGl0ZW0uaXNTZWxlY3RlZCA9IHRydWU7XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfY2hlY2tUb2dnbGUoaXRlbTogYW55KTogdm9pZCB7XHJcbiAgICAgICAgbGV0IGN1cnJlbnRJZCA9IHRoaXMuX2xlZnRtZW51U3ZjLmdldElkKGl0ZW0pO1xyXG5cclxuICAgICAgICAvLyBpZiB1c2VyIGNsaWNrZWQgdGhlIHNhbWUsIHRvZ2dsZSBzdGF0ZVxyXG4gICAgICAgIGlmICh0aGlzLl9sZWZ0bWVudVN2Yy5pc0FycmF5RXF1YWwoY3VycmVudElkLCB0aGlzLl9wcmV2aW91c0lkKSAmJiBpdGVtLmhhc093blByb3BlcnR5KCdpc09wZW4nKSkge1xyXG4gICAgICAgICAgICB0aGlzLl9sZWZ0bWVudVN2Yy50b2dnbGVTdGF0ZShjdXJyZW50SWQsICd0b2dnbGUnLCB0aGlzLmxpc3QpO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgLy8gaWYgdXNlciBjbGlja2VkIG9uIHNvbWV0aGluZyBtb3JlIG9uIHRoZSBzdXJmYWNlLCBjaGVja1xyXG4gICAgICAgIGVsc2UgaWYgKHRoaXMuX3ByZXZpb3VzSWQubGVuZ3RoID4gY3VycmVudElkLmxlbmd0aCkge1xyXG4gICAgICAgICAgICAvLyAgdGhpcy5fY2xvc2VEaWZmZXJlbnQoY3VycmVudElkLCB0aGlzLl9wcmV2aW91c0lkKTtcclxuICAgICAgICAgICAgdGhpcy5fbGVmdG1lbnVTdmMuY2xvc2VEaWZmZXJlbnQoY3VycmVudElkLCB0aGlzLl9wcmV2aW91c0lkLCB0aGlzLmxpc3QpO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgLy8gaWYgdXNlciBjbGlja2VkIG9uIHNvbWV0aGluZyBkZWVwZXIsIGNsb3NlIHByZXZpb3VzIGFuZCBvcGVuIGN1cnJlbnRcclxuICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgLy8gIGlmIChpdGVtLmhhc093blByb3BlcnR5KCdpc09wZW4nKSkge1xyXG4gICAgICAgICAgICBpZiAodGhpcy5fcHJldmlvdXNJZC5sZW5ndGggPiAwKSB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLl9sZWZ0bWVudVN2Yy50b2dnbGVTdGF0ZSh0aGlzLl9wcmV2aW91c0lkLCAnY2xvc2UnLCB0aGlzLmxpc3QpO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIC8vICB9XHJcbiAgICAgICAgICAgIHRoaXMuX2xlZnRtZW51U3ZjLnRvZ2dsZVN0YXRlKGN1cnJlbnRJZCwgJ29wZW4nLCB0aGlzLmxpc3QpO1xyXG4gICAgICAgIH1cclxuICAgICAgICB0aGlzLl9wcmV2aW91c0lkID0gY3VycmVudElkO1xyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX2luaXRBcGkoKTogdm9pZCB7XHJcbiAgICAgICAgaWYgKCF0aGlzLmFwaSkgcmV0dXJuO1xyXG5cclxuICAgICAgICB0aGlzLmFwaS5vbk1lbnVJdGVtQ2xpY2tlZCA9IHRoaXMuX2xlZnRtZW51U3ZjLm9uTWVudUl0ZW1DbGlja2VkKCk7XHJcblxyXG4gICAgICAgIHRoaXMuYXBpLnVwZGF0ZU1lbnVMaXN0ID0gKF9uYXZfaWQ6IHN0cmluZywgX2xpc3Q/OiBBcnJheTxhbnk+KSA9PiB7XHJcbiAgICAgICAgICAgIGxldCBuYXZQb3M6IEFycmF5PG51bWJlcj4gPSB0aGlzLl9sZWZ0bWVudVN2Yy5nZXRJZChfbmF2X2lkKTtcclxuICAgICAgICAgICAgbGV0IHNlbGVjdGVkSXRlbTogYW55ID0ge307XHJcbiAgICAgICAgICAgIGlmIChuYXZQb3MubGVuZ3RoID4gMCkge1xyXG4gICAgICAgICAgICAgICAgc2VsZWN0ZWRJdGVtID0gdGhpcy5saXN0W25hdlBvc1swXV07XHJcbiAgICAgICAgICAgICAgICBmb3IgKGxldCBpID0gMTsgaSA8IG5hdlBvcy5sZW5ndGg7IGkrKykge1xyXG4gICAgICAgICAgICAgICAgICAgIHNlbGVjdGVkSXRlbSA9IHNlbGVjdGVkSXRlbS5saXN0W25hdlBvc1tpXV07XHJcbiAgICAgICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICAgICAgaWYgKHR5cGVvZiBfbGlzdCAhPT0gJ3VuZGVmaW5lZCcpIHtcclxuICAgICAgICAgICAgICAgICAgICBzZWxlY3RlZEl0ZW1bJ2xpc3QnXSA9IF9saXN0O1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMubGlzdCA9IHRoaXMuX2xlZnRtZW51U3ZjLnNldElzT3Blbih0aGlzLmxpc3QpO1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuX3NldEluaXRPcGVuKHRoaXMuX2N1cnJlbnRSb3V0ZSk7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9O1xyXG4gICAgfVxyXG59XHJcbiJdfQ==