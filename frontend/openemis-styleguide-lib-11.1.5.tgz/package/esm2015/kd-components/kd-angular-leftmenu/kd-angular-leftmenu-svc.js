import { Injectable } from '@angular/core';
import { KdBroadcaster } from '../kd-common/index';
export class KdLeftmenuSvc {
    constructor(broadcaster) {
        this.broadcaster = broadcaster;
    }
    // set isOpen property to objects with list (lv1, lv2, lv3) - nested navs
    setIsOpen(_sideConfig) {
        if (typeof _sideConfig === 'undefined')
            return [];
        let updateResult = _sideConfig.slice();
        this._processNavItem(updateResult);
        return updateResult;
    }
    isArrayEqual(currentItem, previousItem) {
        if (currentItem.length !== previousItem.length) {
            return false;
        }
        for (let i = 0; i < currentItem.length; i++) {
            if (currentItem[i] !== previousItem[i]) {
                return false;
            }
        }
        return true;
    }
    getId(item) {
        let nav_id = (typeof item === 'string') ? item : item.nav_id;
        let currentId = nav_id.split('-');
        currentId.splice(0, 1);
        for (let i = 0; i < currentId.length; i++) {
            currentId[i] = +currentId[i];
        }
        return currentId;
    }
    closeDifferent(currentItem, previousItem, _navItems) {
        let currentNode = {};
        let previousCurrentNode = {};
        let previousNode;
        let diffBranch = false;
        for (let i = 0; i < previousItem.length; i++) {
            if (i === 0) {
                previousCurrentNode = _navItems[previousItem[i]];
                currentNode = _navItems[currentItem[i]];
            }
            else {
                previousCurrentNode = previousCurrentNode.list[previousItem[i]];
                if (typeof currentItem[i] !== 'undefined') {
                    currentNode = currentNode.list[currentItem[i]];
                }
                else {
                    currentNode = undefined;
                }
            }
            /**********set the previous node to true only when there is next node*******************
            e.g.
              previous node open -    0 0 0          previous node open -  0 0 0
              current node open  -    0              current node open  -  0 0
              current node should be closed          current node at index 0 is open, index 1 is closed
            *********************************************************************************/
            if (previousCurrentNode.hasOwnProperty('isOpen')) {
                if (typeof previousNode !== 'undefined' && typeof currentItem[i] !== 'undefined') {
                    previousNode.isOpen = true;
                }
                if (currentItem[i] === previousItem[i] && diffBranch === false) {
                    previousNode = previousCurrentNode;
                    previousCurrentNode.isOpen = false;
                }
                else {
                    diffBranch = true;
                    previousCurrentNode.isOpen = false;
                    if (typeof currentNode !== 'undefined') {
                        if (typeof currentNode.isOpen !== 'undefined')
                            currentNode.isOpen = true;
                        else
                            currentNode.isSelected = true;
                    }
                }
            }
        }
    }
    toggleState(currentId, state, _navItems) {
        let currentNode = {};
        for (let i = 0; i < currentId.length; i++) {
            currentNode = (i === 0) ? _navItems[currentId[i]] : currentNode.list[currentId[i]];
            if (typeof currentNode.isOpen !== 'undefined') {
                if (state === 'open') {
                    currentNode.isOpen = true;
                }
                else if (state === 'close') {
                    currentNode.isOpen = false;
                }
                else if (state === 'toggle' && i === currentId.length - 1) {
                    currentNode.isOpen = !currentNode.isOpen;
                }
            }
            else if (typeof currentNode.isSelected !== 'undefined' && i === currentId.length - 1) {
                currentNode.isSelected = false;
            }
        }
    }
    _processNavItem(_navItems, _prefix) {
        for (let i = 0; i < _navItems.length; i++) {
            let itemId = this._idFormatter(i, _prefix);
            _navItems[i]['nav_id'] = itemId;
            this._checkNavItem(_navItems[i], itemId);
        }
    }
    _checkNavItem(_item, _prefix) {
        if (typeof _item.list !== 'undefined') {
            _item.isOpen = false;
            this._processNavItem(_item.list, _prefix);
        }
        else {
            _item.isSelected = false;
            if (typeof _item.basePath === 'undefined') {
                _item.basePath = _item.path;
            }
        }
    }
    _idFormatter(_number, _prefix) {
        let prefix = (typeof _prefix === 'undefined') ? 'nav' : _prefix;
        let formatString = prefix;
        formatString += '-' + _number.toString();
        return formatString;
    }
    /* For API Usage  */
    onMenuItemClicked() {
        return this.broadcaster.on('KdGridsterEvent_onRemoved');
    }
    menuItemClicked(_item) {
        this.broadcaster.broadcast('KdGridsterEvent_onRemoved');
    }
}
KdLeftmenuSvc.decorators = [
    { type: Injectable }
];
KdLeftmenuSvc.ctorParameters = () => [
    { type: KdBroadcaster }
];
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoia2QtYW5ndWxhci1sZWZ0bWVudS1zdmMuanMiLCJzb3VyY2VSb290IjoiQzoveGFtcHAvaHRkb2NzL1N0eWxlZ3VpZGUvaW9zdGctb3BlbmVtaXMtc3R5bGVndWlkZS9wcm9qZWN0cy9vcGVuZW1pcy1zdHlsZWd1aWRlLWxpYi9zcmMvIiwic291cmNlcyI6WyJrZC1jb21wb25lbnRzL2tkLWFuZ3VsYXItbGVmdG1lbnUva2QtYW5ndWxhci1sZWZ0bWVudS1zdmMudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsT0FBTyxFQUFFLFVBQVUsRUFBRSxNQUFNLGVBQWUsQ0FBQztBQUMzQyxPQUFPLEVBQUUsYUFBYSxFQUFFLE1BQU0sb0JBQW9CLENBQUM7QUFJbkQsTUFBTSxPQUFPLGFBQWE7SUFDdEIsWUFBb0IsV0FBMEI7UUFBMUIsZ0JBQVcsR0FBWCxXQUFXLENBQWU7SUFBSSxDQUFDO0lBRW5ELHlFQUF5RTtJQUNsRSxTQUFTLENBQUMsV0FBdUI7UUFDcEMsSUFBSSxPQUFPLFdBQVcsS0FBSyxXQUFXO1lBQUUsT0FBTyxFQUFFLENBQUM7UUFFbEQsSUFBSSxZQUFZLEdBQWUsV0FBVyxDQUFDLEtBQUssRUFBRSxDQUFDO1FBQ25ELElBQUksQ0FBQyxlQUFlLENBQUMsWUFBWSxDQUFDLENBQUM7UUFFbkMsT0FBTyxZQUFZLENBQUM7SUFDeEIsQ0FBQztJQUVNLFlBQVksQ0FBQyxXQUEwQixFQUFFLFlBQTJCO1FBQ3ZFLElBQUksV0FBVyxDQUFDLE1BQU0sS0FBSyxZQUFZLENBQUMsTUFBTSxFQUFFO1lBQzVDLE9BQU8sS0FBSyxDQUFDO1NBQ2hCO1FBQ0QsS0FBSyxJQUFJLENBQUMsR0FBVyxDQUFDLEVBQUUsQ0FBQyxHQUFHLFdBQVcsQ0FBQyxNQUFNLEVBQUUsQ0FBQyxFQUFFLEVBQUU7WUFDakQsSUFBSSxXQUFXLENBQUMsQ0FBQyxDQUFDLEtBQUssWUFBWSxDQUFDLENBQUMsQ0FBQyxFQUFFO2dCQUNwQyxPQUFPLEtBQUssQ0FBQzthQUNoQjtTQUNKO1FBQ0QsT0FBTyxJQUFJLENBQUM7SUFDaEIsQ0FBQztJQUdNLEtBQUssQ0FBQyxJQUFrQjtRQUMzQixJQUFJLE1BQU0sR0FBVyxDQUFDLE9BQU8sSUFBSSxLQUFLLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUM7UUFDckUsSUFBSSxTQUFTLEdBQWUsTUFBTSxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FBQztRQUM5QyxTQUFTLENBQUMsTUFBTSxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQztRQUV2QixLQUFLLElBQUksQ0FBQyxHQUFXLENBQUMsRUFBRSxDQUFDLEdBQUcsU0FBUyxDQUFDLE1BQU0sRUFBRSxDQUFDLEVBQUUsRUFBRTtZQUMvQyxTQUFTLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUM7U0FDaEM7UUFDRCxPQUFPLFNBQVMsQ0FBQztJQUNyQixDQUFDO0lBRU0sY0FBYyxDQUFDLFdBQTBCLEVBQUUsWUFBMkIsRUFBRSxTQUFxQjtRQUNoRyxJQUFJLFdBQVcsR0FBUSxFQUFFLENBQUM7UUFDMUIsSUFBSSxtQkFBbUIsR0FBUSxFQUFFLENBQUM7UUFDbEMsSUFBSSxZQUFpQixDQUFDO1FBQ3RCLElBQUksVUFBVSxHQUFZLEtBQUssQ0FBQztRQUVoQyxLQUFLLElBQUksQ0FBQyxHQUFXLENBQUMsRUFBRSxDQUFDLEdBQUcsWUFBWSxDQUFDLE1BQU0sRUFBRSxDQUFDLEVBQUUsRUFBRTtZQUNsRCxJQUFJLENBQUMsS0FBSyxDQUFDLEVBQUU7Z0JBQ1QsbUJBQW1CLEdBQUcsU0FBUyxDQUFDLFlBQVksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO2dCQUNqRCxXQUFXLEdBQUcsU0FBUyxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO2FBQzNDO2lCQUNJO2dCQUNELG1CQUFtQixHQUFHLG1CQUFtQixDQUFDLElBQUksQ0FBQyxZQUFZLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztnQkFDaEUsSUFBSSxPQUFPLFdBQVcsQ0FBQyxDQUFDLENBQUMsS0FBSyxXQUFXLEVBQUU7b0JBQ3ZDLFdBQVcsR0FBRyxXQUFXLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO2lCQUNsRDtxQkFDSTtvQkFDRCxXQUFXLEdBQUcsU0FBUyxDQUFDO2lCQUMzQjthQUNKO1lBRUQ7Ozs7OzhGQUtrRjtZQUdsRixJQUFJLG1CQUFtQixDQUFDLGNBQWMsQ0FBQyxRQUFRLENBQUMsRUFBRTtnQkFDOUMsSUFBSSxPQUFPLFlBQVksS0FBSyxXQUFXLElBQUksT0FBTyxXQUFXLENBQUMsQ0FBQyxDQUFDLEtBQUssV0FBVyxFQUFFO29CQUM5RSxZQUFZLENBQUMsTUFBTSxHQUFHLElBQUksQ0FBQztpQkFDOUI7Z0JBRUQsSUFBSSxXQUFXLENBQUMsQ0FBQyxDQUFDLEtBQUssWUFBWSxDQUFDLENBQUMsQ0FBQyxJQUFJLFVBQVUsS0FBSyxLQUFLLEVBQUU7b0JBQzVELFlBQVksR0FBRyxtQkFBbUIsQ0FBQztvQkFDbkMsbUJBQW1CLENBQUMsTUFBTSxHQUFHLEtBQUssQ0FBQztpQkFDdEM7cUJBQ0k7b0JBQ0QsVUFBVSxHQUFHLElBQUksQ0FBQztvQkFDbEIsbUJBQW1CLENBQUMsTUFBTSxHQUFHLEtBQUssQ0FBQztvQkFDbkMsSUFBSSxPQUFPLFdBQVcsS0FBSyxXQUFXLEVBQUU7d0JBQ3BDLElBQUksT0FBTyxXQUFXLENBQUMsTUFBTSxLQUFLLFdBQVc7NEJBQUUsV0FBVyxDQUFDLE1BQU0sR0FBRyxJQUFJLENBQUM7OzRCQUNwRSxXQUFXLENBQUMsVUFBVSxHQUFHLElBQUksQ0FBQztxQkFDdEM7aUJBQ0o7YUFDSjtTQUNKO0lBQ0wsQ0FBQztJQUVNLFdBQVcsQ0FBQyxTQUFxQixFQUFFLEtBQWEsRUFBRSxTQUFxQjtRQUMxRSxJQUFJLFdBQVcsR0FBUSxFQUFFLENBQUM7UUFDMUIsS0FBSyxJQUFJLENBQUMsR0FBVyxDQUFDLEVBQUUsQ0FBQyxHQUFHLFNBQVMsQ0FBQyxNQUFNLEVBQUUsQ0FBQyxFQUFFLEVBQUU7WUFFL0MsV0FBVyxHQUFHLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFdBQVcsQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7WUFHbkYsSUFBSSxPQUFPLFdBQVcsQ0FBQyxNQUFNLEtBQUssV0FBVyxFQUFFO2dCQUMzQyxJQUFJLEtBQUssS0FBSyxNQUFNLEVBQUU7b0JBQ2xCLFdBQVcsQ0FBQyxNQUFNLEdBQUcsSUFBSSxDQUFDO2lCQUM3QjtxQkFFSSxJQUFJLEtBQUssS0FBSyxPQUFPLEVBQUU7b0JBQ3hCLFdBQVcsQ0FBQyxNQUFNLEdBQUcsS0FBSyxDQUFDO2lCQUM5QjtxQkFFSSxJQUFJLEtBQUssS0FBSyxRQUFRLElBQUksQ0FBQyxLQUFLLFNBQVMsQ0FBQyxNQUFNLEdBQUcsQ0FBQyxFQUFFO29CQUN2RCxXQUFXLENBQUMsTUFBTSxHQUFHLENBQUMsV0FBVyxDQUFDLE1BQU0sQ0FBQztpQkFDNUM7YUFDSjtpQkFDSSxJQUFJLE9BQU8sV0FBVyxDQUFDLFVBQVUsS0FBSyxXQUFXLElBQUksQ0FBQyxLQUFLLFNBQVMsQ0FBQyxNQUFNLEdBQUcsQ0FBQyxFQUFFO2dCQUNsRixXQUFXLENBQUMsVUFBVSxHQUFHLEtBQUssQ0FBQzthQUNsQztTQUNKO0lBQ0wsQ0FBQztJQUdPLGVBQWUsQ0FBQyxTQUFxQixFQUFFLE9BQWdCO1FBQzNELEtBQUssSUFBSSxDQUFDLEdBQVcsQ0FBQyxFQUFFLENBQUMsR0FBRyxTQUFTLENBQUMsTUFBTSxFQUFFLENBQUMsRUFBRSxFQUFFO1lBQy9DLElBQUksTUFBTSxHQUFXLElBQUksQ0FBQyxZQUFZLENBQUMsQ0FBQyxFQUFFLE9BQU8sQ0FBQyxDQUFDO1lBQ25ELFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsR0FBRyxNQUFNLENBQUM7WUFDaEMsSUFBSSxDQUFDLGFBQWEsQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLEVBQUUsTUFBTSxDQUFDLENBQUM7U0FDNUM7SUFDTCxDQUFDO0lBRU8sYUFBYSxDQUFDLEtBQVUsRUFBRSxPQUFnQjtRQUM5QyxJQUFJLE9BQU8sS0FBSyxDQUFDLElBQUksS0FBSyxXQUFXLEVBQUU7WUFDbkMsS0FBSyxDQUFDLE1BQU0sR0FBRyxLQUFLLENBQUM7WUFDckIsSUFBSSxDQUFDLGVBQWUsQ0FBQyxLQUFLLENBQUMsSUFBSSxFQUFFLE9BQU8sQ0FBQyxDQUFDO1NBQzdDO2FBQ0k7WUFDRCxLQUFLLENBQUMsVUFBVSxHQUFHLEtBQUssQ0FBQztZQUN6QixJQUFJLE9BQU8sS0FBSyxDQUFDLFFBQVEsS0FBSyxXQUFXLEVBQUU7Z0JBQ3ZDLEtBQUssQ0FBQyxRQUFRLEdBQUcsS0FBSyxDQUFDLElBQUksQ0FBQzthQUMvQjtTQUNKO0lBQ0wsQ0FBQztJQUVPLFlBQVksQ0FBQyxPQUFlLEVBQUUsT0FBZ0I7UUFDbEQsSUFBSSxNQUFNLEdBQVcsQ0FBQyxPQUFPLE9BQU8sS0FBSyxXQUFXLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUM7UUFDeEUsSUFBSSxZQUFZLEdBQUcsTUFBTSxDQUFDO1FBQzFCLFlBQVksSUFBSSxHQUFHLEdBQUcsT0FBTyxDQUFDLFFBQVEsRUFBRSxDQUFDO1FBQ3pDLE9BQU8sWUFBWSxDQUFDO0lBQ3hCLENBQUM7SUFHRCxvQkFBb0I7SUFFYixpQkFBaUI7UUFDcEIsT0FBTyxJQUFJLENBQUMsV0FBVyxDQUFDLEVBQUUsQ0FBTSwyQkFBMkIsQ0FBQyxDQUFDO0lBQ2pFLENBQUM7SUFFTSxlQUFlLENBQUMsS0FBVTtRQUM3QixJQUFJLENBQUMsV0FBVyxDQUFDLFNBQVMsQ0FBQywyQkFBMkIsQ0FBQyxDQUFDO0lBQzVELENBQUM7OztZQXhKSixVQUFVOzs7WUFIRixhQUFhIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgSW5qZWN0YWJsZSB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xyXG5pbXBvcnQgeyBLZEJyb2FkY2FzdGVyIH0gZnJvbSAnLi4va2QtY29tbW9uL2luZGV4JztcclxuaW1wb3J0IHsgT2JzZXJ2YWJsZSB9IGZyb20gJ3J4anMnO1xyXG5cclxuQEluamVjdGFibGUoKVxyXG5leHBvcnQgY2xhc3MgS2RMZWZ0bWVudVN2YyB7XHJcbiAgICBjb25zdHJ1Y3Rvcihwcml2YXRlIGJyb2FkY2FzdGVyOiBLZEJyb2FkY2FzdGVyKSB7IH1cclxuXHJcbiAgICAvLyBzZXQgaXNPcGVuIHByb3BlcnR5IHRvIG9iamVjdHMgd2l0aCBsaXN0IChsdjEsIGx2MiwgbHYzKSAtIG5lc3RlZCBuYXZzXHJcbiAgICBwdWJsaWMgc2V0SXNPcGVuKF9zaWRlQ29uZmlnOiBBcnJheTxhbnk+KTogQXJyYXk8YW55PiB7XHJcbiAgICAgICAgaWYgKHR5cGVvZiBfc2lkZUNvbmZpZyA9PT0gJ3VuZGVmaW5lZCcpIHJldHVybiBbXTtcclxuXHJcbiAgICAgICAgbGV0IHVwZGF0ZVJlc3VsdDogQXJyYXk8YW55PiA9IF9zaWRlQ29uZmlnLnNsaWNlKCk7XHJcbiAgICAgICAgdGhpcy5fcHJvY2Vzc05hdkl0ZW0odXBkYXRlUmVzdWx0KTtcclxuXHJcbiAgICAgICAgcmV0dXJuIHVwZGF0ZVJlc3VsdDtcclxuICAgIH1cclxuXHJcbiAgICBwdWJsaWMgaXNBcnJheUVxdWFsKGN1cnJlbnRJdGVtOiBBcnJheTxudW1iZXI+LCBwcmV2aW91c0l0ZW06IEFycmF5PG51bWJlcj4pOiBib29sZWFuIHtcclxuICAgICAgICBpZiAoY3VycmVudEl0ZW0ubGVuZ3RoICE9PSBwcmV2aW91c0l0ZW0ubGVuZ3RoKSB7XHJcbiAgICAgICAgICAgIHJldHVybiBmYWxzZTtcclxuICAgICAgICB9XHJcbiAgICAgICAgZm9yIChsZXQgaTogbnVtYmVyID0gMDsgaSA8IGN1cnJlbnRJdGVtLmxlbmd0aDsgaSsrKSB7XHJcbiAgICAgICAgICAgIGlmIChjdXJyZW50SXRlbVtpXSAhPT0gcHJldmlvdXNJdGVtW2ldKSB7XHJcbiAgICAgICAgICAgICAgICByZXR1cm4gZmFsc2U7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICAgICAgcmV0dXJuIHRydWU7XHJcbiAgICB9XHJcblxyXG5cclxuICAgIHB1YmxpYyBnZXRJZChpdGVtOiBhbnkgfCBzdHJpbmcpOiBBcnJheTxudW1iZXI+IHtcclxuICAgICAgICBsZXQgbmF2X2lkOiBzdHJpbmcgPSAodHlwZW9mIGl0ZW0gPT09ICdzdHJpbmcnKSA/IGl0ZW0gOiBpdGVtLm5hdl9pZDtcclxuICAgICAgICBsZXQgY3VycmVudElkOiBBcnJheTxhbnk+ID0gbmF2X2lkLnNwbGl0KCctJyk7XHJcbiAgICAgICAgY3VycmVudElkLnNwbGljZSgwLCAxKTtcclxuXHJcbiAgICAgICAgZm9yIChsZXQgaTogbnVtYmVyID0gMDsgaSA8IGN1cnJlbnRJZC5sZW5ndGg7IGkrKykge1xyXG4gICAgICAgICAgICBjdXJyZW50SWRbaV0gPSArY3VycmVudElkW2ldO1xyXG4gICAgICAgIH1cclxuICAgICAgICByZXR1cm4gY3VycmVudElkO1xyXG4gICAgfVxyXG5cclxuICAgIHB1YmxpYyBjbG9zZURpZmZlcmVudChjdXJyZW50SXRlbTogQXJyYXk8bnVtYmVyPiwgcHJldmlvdXNJdGVtOiBBcnJheTxudW1iZXI+LCBfbmF2SXRlbXM6IEFycmF5PGFueT4pOiB2b2lkIHtcclxuICAgICAgICBsZXQgY3VycmVudE5vZGU6IGFueSA9IHt9O1xyXG4gICAgICAgIGxldCBwcmV2aW91c0N1cnJlbnROb2RlOiBhbnkgPSB7fTtcclxuICAgICAgICBsZXQgcHJldmlvdXNOb2RlOiBhbnk7XHJcbiAgICAgICAgbGV0IGRpZmZCcmFuY2g6IGJvb2xlYW4gPSBmYWxzZTtcclxuXHJcbiAgICAgICAgZm9yIChsZXQgaTogbnVtYmVyID0gMDsgaSA8IHByZXZpb3VzSXRlbS5sZW5ndGg7IGkrKykge1xyXG4gICAgICAgICAgICBpZiAoaSA9PT0gMCkge1xyXG4gICAgICAgICAgICAgICAgcHJldmlvdXNDdXJyZW50Tm9kZSA9IF9uYXZJdGVtc1twcmV2aW91c0l0ZW1baV1dO1xyXG4gICAgICAgICAgICAgICAgY3VycmVudE5vZGUgPSBfbmF2SXRlbXNbY3VycmVudEl0ZW1baV1dO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgcHJldmlvdXNDdXJyZW50Tm9kZSA9IHByZXZpb3VzQ3VycmVudE5vZGUubGlzdFtwcmV2aW91c0l0ZW1baV1dO1xyXG4gICAgICAgICAgICAgICAgaWYgKHR5cGVvZiBjdXJyZW50SXRlbVtpXSAhPT0gJ3VuZGVmaW5lZCcpIHtcclxuICAgICAgICAgICAgICAgICAgICBjdXJyZW50Tm9kZSA9IGN1cnJlbnROb2RlLmxpc3RbY3VycmVudEl0ZW1baV1dO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgZWxzZSB7XHJcbiAgICAgICAgICAgICAgICAgICAgY3VycmVudE5vZGUgPSB1bmRlZmluZWQ7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgIC8qKioqKioqKioqc2V0IHRoZSBwcmV2aW91cyBub2RlIHRvIHRydWUgb25seSB3aGVuIHRoZXJlIGlzIG5leHQgbm9kZSoqKioqKioqKioqKioqKioqKipcclxuICAgICAgICAgICAgZS5nLlxyXG4gICAgICAgICAgICAgIHByZXZpb3VzIG5vZGUgb3BlbiAtICAgIDAgMCAwICAgICAgICAgIHByZXZpb3VzIG5vZGUgb3BlbiAtICAwIDAgMFxyXG4gICAgICAgICAgICAgIGN1cnJlbnQgbm9kZSBvcGVuICAtICAgIDAgICAgICAgICAgICAgIGN1cnJlbnQgbm9kZSBvcGVuICAtICAwIDBcclxuICAgICAgICAgICAgICBjdXJyZW50IG5vZGUgc2hvdWxkIGJlIGNsb3NlZCAgICAgICAgICBjdXJyZW50IG5vZGUgYXQgaW5kZXggMCBpcyBvcGVuLCBpbmRleCAxIGlzIGNsb3NlZFxyXG4gICAgICAgICAgICAqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKiovXHJcblxyXG5cclxuICAgICAgICAgICAgaWYgKHByZXZpb3VzQ3VycmVudE5vZGUuaGFzT3duUHJvcGVydHkoJ2lzT3BlbicpKSB7XHJcbiAgICAgICAgICAgICAgICBpZiAodHlwZW9mIHByZXZpb3VzTm9kZSAhPT0gJ3VuZGVmaW5lZCcgJiYgdHlwZW9mIGN1cnJlbnRJdGVtW2ldICE9PSAndW5kZWZpbmVkJykge1xyXG4gICAgICAgICAgICAgICAgICAgIHByZXZpb3VzTm9kZS5pc09wZW4gPSB0cnVlO1xyXG4gICAgICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgICAgIGlmIChjdXJyZW50SXRlbVtpXSA9PT0gcHJldmlvdXNJdGVtW2ldICYmIGRpZmZCcmFuY2ggPT09IGZhbHNlKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgcHJldmlvdXNOb2RlID0gcHJldmlvdXNDdXJyZW50Tm9kZTtcclxuICAgICAgICAgICAgICAgICAgICBwcmV2aW91c0N1cnJlbnROb2RlLmlzT3BlbiA9IGZhbHNlO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgZWxzZSB7XHJcbiAgICAgICAgICAgICAgICAgICAgZGlmZkJyYW5jaCA9IHRydWU7XHJcbiAgICAgICAgICAgICAgICAgICAgcHJldmlvdXNDdXJyZW50Tm9kZS5pc09wZW4gPSBmYWxzZTtcclxuICAgICAgICAgICAgICAgICAgICBpZiAodHlwZW9mIGN1cnJlbnROb2RlICE9PSAndW5kZWZpbmVkJykge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAodHlwZW9mIGN1cnJlbnROb2RlLmlzT3BlbiAhPT0gJ3VuZGVmaW5lZCcpIGN1cnJlbnROb2RlLmlzT3BlbiA9IHRydWU7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGVsc2UgY3VycmVudE5vZGUuaXNTZWxlY3RlZCA9IHRydWU7XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIHB1YmxpYyB0b2dnbGVTdGF0ZShjdXJyZW50SWQ6IEFycmF5PGFueT4sIHN0YXRlOiBzdHJpbmcsIF9uYXZJdGVtczogQXJyYXk8YW55Pik6IHZvaWQge1xyXG4gICAgICAgIGxldCBjdXJyZW50Tm9kZTogYW55ID0ge307XHJcbiAgICAgICAgZm9yIChsZXQgaTogbnVtYmVyID0gMDsgaSA8IGN1cnJlbnRJZC5sZW5ndGg7IGkrKykge1xyXG5cclxuICAgICAgICAgICAgY3VycmVudE5vZGUgPSAoaSA9PT0gMCkgPyBfbmF2SXRlbXNbY3VycmVudElkW2ldXSA6IGN1cnJlbnROb2RlLmxpc3RbY3VycmVudElkW2ldXTtcclxuXHJcblxyXG4gICAgICAgICAgICBpZiAodHlwZW9mIGN1cnJlbnROb2RlLmlzT3BlbiAhPT0gJ3VuZGVmaW5lZCcpIHtcclxuICAgICAgICAgICAgICAgIGlmIChzdGF0ZSA9PT0gJ29wZW4nKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgY3VycmVudE5vZGUuaXNPcGVuID0gdHJ1ZTtcclxuICAgICAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgICAgICBlbHNlIGlmIChzdGF0ZSA9PT0gJ2Nsb3NlJykge1xyXG4gICAgICAgICAgICAgICAgICAgIGN1cnJlbnROb2RlLmlzT3BlbiA9IGZhbHNlO1xyXG4gICAgICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgICAgIGVsc2UgaWYgKHN0YXRlID09PSAndG9nZ2xlJyAmJiBpID09PSBjdXJyZW50SWQubGVuZ3RoIC0gMSkge1xyXG4gICAgICAgICAgICAgICAgICAgIGN1cnJlbnROb2RlLmlzT3BlbiA9ICFjdXJyZW50Tm9kZS5pc09wZW47XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgZWxzZSBpZiAodHlwZW9mIGN1cnJlbnROb2RlLmlzU2VsZWN0ZWQgIT09ICd1bmRlZmluZWQnICYmIGkgPT09IGN1cnJlbnRJZC5sZW5ndGggLSAxKSB7XHJcbiAgICAgICAgICAgICAgICBjdXJyZW50Tm9kZS5pc1NlbGVjdGVkID0gZmFsc2U7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG5cclxuICAgIHByaXZhdGUgX3Byb2Nlc3NOYXZJdGVtKF9uYXZJdGVtczogQXJyYXk8YW55PiwgX3ByZWZpeD86IHN0cmluZyk6IHZvaWQge1xyXG4gICAgICAgIGZvciAobGV0IGk6IG51bWJlciA9IDA7IGkgPCBfbmF2SXRlbXMubGVuZ3RoOyBpKyspIHtcclxuICAgICAgICAgICAgbGV0IGl0ZW1JZDogc3RyaW5nID0gdGhpcy5faWRGb3JtYXR0ZXIoaSwgX3ByZWZpeCk7XHJcbiAgICAgICAgICAgIF9uYXZJdGVtc1tpXVsnbmF2X2lkJ10gPSBpdGVtSWQ7XHJcbiAgICAgICAgICAgIHRoaXMuX2NoZWNrTmF2SXRlbShfbmF2SXRlbXNbaV0sIGl0ZW1JZCk7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX2NoZWNrTmF2SXRlbShfaXRlbTogYW55LCBfcHJlZml4Pzogc3RyaW5nKTogdm9pZCB7XHJcbiAgICAgICAgaWYgKHR5cGVvZiBfaXRlbS5saXN0ICE9PSAndW5kZWZpbmVkJykge1xyXG4gICAgICAgICAgICBfaXRlbS5pc09wZW4gPSBmYWxzZTtcclxuICAgICAgICAgICAgdGhpcy5fcHJvY2Vzc05hdkl0ZW0oX2l0ZW0ubGlzdCwgX3ByZWZpeCk7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICBfaXRlbS5pc1NlbGVjdGVkID0gZmFsc2U7XHJcbiAgICAgICAgICAgIGlmICh0eXBlb2YgX2l0ZW0uYmFzZVBhdGggPT09ICd1bmRlZmluZWQnKSB7XHJcbiAgICAgICAgICAgICAgICBfaXRlbS5iYXNlUGF0aCA9IF9pdGVtLnBhdGg7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfaWRGb3JtYXR0ZXIoX251bWJlcjogbnVtYmVyLCBfcHJlZml4Pzogc3RyaW5nKTogc3RyaW5nIHtcclxuICAgICAgICBsZXQgcHJlZml4OiBzdHJpbmcgPSAodHlwZW9mIF9wcmVmaXggPT09ICd1bmRlZmluZWQnKSA/ICduYXYnIDogX3ByZWZpeDtcclxuICAgICAgICBsZXQgZm9ybWF0U3RyaW5nID0gcHJlZml4O1xyXG4gICAgICAgIGZvcm1hdFN0cmluZyArPSAnLScgKyBfbnVtYmVyLnRvU3RyaW5nKCk7XHJcbiAgICAgICAgcmV0dXJuIGZvcm1hdFN0cmluZztcclxuICAgIH1cclxuXHJcblxyXG4gICAgLyogRm9yIEFQSSBVc2FnZSAgKi9cclxuXHJcbiAgICBwdWJsaWMgb25NZW51SXRlbUNsaWNrZWQoKTogT2JzZXJ2YWJsZTxhbnk+IHtcclxuICAgICAgICByZXR1cm4gdGhpcy5icm9hZGNhc3Rlci5vbjxhbnk+KCdLZEdyaWRzdGVyRXZlbnRfb25SZW1vdmVkJyk7XHJcbiAgICB9XHJcblxyXG4gICAgcHVibGljIG1lbnVJdGVtQ2xpY2tlZChfaXRlbTogYW55KTogdm9pZCB7XHJcbiAgICAgICAgdGhpcy5icm9hZGNhc3Rlci5icm9hZGNhc3QoJ0tkR3JpZHN0ZXJFdmVudF9vblJlbW92ZWQnKTtcclxuICAgIH1cclxufVxyXG4iXX0=