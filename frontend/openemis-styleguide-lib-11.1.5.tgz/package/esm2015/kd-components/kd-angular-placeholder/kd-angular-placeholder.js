import { Component, ViewEncapsulation, HostBinding, Input } from '@angular/core';
// import { Http, Response } from '@angular/http';
import { HttpClient } from '@angular/common/http';
import { map } from 'rxjs/operators';
import { KdModalEvent } from '../kd-angular-modal/kd-modal-event';
export class KdPlaceholder {
    constructor(_http, _modalEvent) {
        this._http = _http;
        this._modalEvent = _modalEvent;
        this.imageSrc = '';
        this.modalConfig = {
            title: '',
            button: [],
            id: ''
        };
        this.fontSize = 80;
        this.placeholder = 'placeholder-wrapper';
    }
    ngOnInit() {
        // console.log('-- KdPlaceholder OnInit --');
        this._processImageConfig();
        if (typeof this.src !== 'undefined') {
            this.imageSrc = this.src;
        }
        if (typeof this.value !== 'undefined' && (typeof this.src === 'undefined' || this.src === '')) {
            this._processImageValue();
        }
    }
    ngOnChanges(_simpleChanges) {
        // console.log('-- KdPlaceholder OnChanges -- ', _simpleChanges);
        if (_simpleChanges.hasOwnProperty('config') && !_simpleChanges['config'].firstChange) {
            this._processImageConfig();
        }
        if (_simpleChanges.hasOwnProperty('src') && !_simpleChanges['src'].firstChange) {
            this.imageSrc = this.src;
        }
        if (_simpleChanges.hasOwnProperty('value') && !_simpleChanges['value'].firstChange) {
            this._processImageValue();
        }
    }
    ngOnDestroy() {
        this._unsubscribeHttp();
    }
    imgClick(_event) {
        if (!this.config.isExpandable)
            return;
        this._modalEvent.toggleOpen(this.config.id);
    }
    /******************* Process config ***********************/
    _processImageConfig() {
        let defaultConfig = {
            width: 150,
            height: 150,
            icon: 'kd-openemis',
            isExpandable: false,
            borderType: 'box',
            id: Date.now().toString()
        };
        this.config = Object.assign({}, defaultConfig, this.config);
        this.modalConfig.id = this.config.id;
        // Font size checking standardize as width of image / 2 + 5
        this.fontSize = this.config.width / 2 + 5;
    }
    _processImageTitle() {
        let modalTitle = (typeof this.value.filename !== 'undefined') ? this.value.filename : '';
        this.modalConfig.title = modalTitle;
    }
    _processImageValue() {
        var _a, _b, _c, _d;
        this._processImageTitle();
        if (typeof this.value.src !== 'undefined') {
            this.imageSrc = this.value.src;
        }
        else if (typeof this.value.data !== 'undefined' && typeof this.value.extension !== 'undefined') {
            this.imageSrc = this._convertDataExtensionToSrc();
        }
        else if (typeof this.value.link !== 'undefined') {
            this._unsubscribeHttp();
            this._httpSubscription = this._convertLinkToSrc().subscribe((_response) => {
                this.imageSrc = _response;
            }, (_error) => {
                console.error('KdPlaceholder error - Error retrieving data for image.', _error);
            });
        }
        else if (typeof ((_b = (_a = this.value) === null || _a === void 0 ? void 0 : _a.newLink) === null || _b === void 0 ? void 0 : _b.srcData) !== undefined) {
            this.imageSrc = (_d = (_c = this.value) === null || _c === void 0 ? void 0 : _c.newLink) === null || _d === void 0 ? void 0 : _d.srcData;
        }
        else {
            this.imageSrc = '';
        }
    }
    /******************** Convert data ************************/
    _convertDataExtensionToSrc() {
        let dataPrefix = 'data:image/' + this.value.extension + ';base64,';
        return dataPrefix + this.value.data;
    }
    _convertLinkToSrc() {
        return this._http.get(this.value.link.url)
            .pipe(map((_response) => {
            let response = {};
            try {
                // let tempRes: any = _response.json();
                let imageKey = (typeof this.value.link.key !== 'undefined') ? this.value.link.key : 'image';
                if (_response.hasOwnProperty(imageKey)) {
                    response = _response[imageKey];
                }
            }
            catch (err) {
                console.error('KdPlaceholder error - Error in retrieving image src from url. ', err);
            }
            return response;
        }));
    }
    /******************** Convert data ************************/
    _unsubscribeHttp() {
        if (typeof this._httpSubscription !== 'undefined') {
            this._httpSubscription.unsubscribe();
        }
    }
}
KdPlaceholder.decorators = [
    { type: Component, args: [{
                selector: 'kd-placeholder',
                template: `
        <kd-modal *ngIf='true' [config]='modalConfig'>
            <img [src]='imageSrc' [style.width]='"100%"' [style.height]='"100%"'/>
        </kd-modal>
        <div
            [ngClass]='{"image-border": (config.borderType == "box"), "image-border-round": (config.borderType == "circle")}'
            [style.width.px]='config.width'
            [style.height.px]='config.height'
        >
            <img
                *ngIf='imageSrc'
                [src]='imageSrc'
                (click)='imgClick($event)'
            />
            <i
                *ngIf='!imageSrc'
                [ngClass]='config.icon'
                [style.fontSize.px]='fontSize'
            ></i>
        </div>
    `,
                encapsulation: ViewEncapsulation.None,
                providers: [KdModalEvent]
            },] }
];
KdPlaceholder.ctorParameters = () => [
    { type: HttpClient },
    { type: KdModalEvent }
];
KdPlaceholder.propDecorators = {
    config: [{ type: Input }],
    value: [{ type: Input }],
    src: [{ type: Input }],
    placeholder: [{ type: HostBinding, args: ['class',] }]
};
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoia2QtYW5ndWxhci1wbGFjZWhvbGRlci5qcyIsInNvdXJjZVJvb3QiOiJDOi94YW1wcC9odGRvY3MvU3R5bGVndWlkZS9pb3N0Zy1vcGVuZW1pcy1zdHlsZWd1aWRlL3Byb2plY3RzL29wZW5lbWlzLXN0eWxlZ3VpZGUtbGliL3NyYy8iLCJzb3VyY2VzIjpbImtkLWNvbXBvbmVudHMva2QtYW5ndWxhci1wbGFjZWhvbGRlci9rZC1hbmd1bGFyLXBsYWNlaG9sZGVyLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBLE9BQU8sRUFDSCxTQUFTLEVBS1QsaUJBQWlCLEVBQ2pCLFdBQVcsRUFDWCxLQUFLLEVBQ1IsTUFBTSxlQUFlLENBQUM7QUFDdkIsa0RBQWtEO0FBQ2xELE9BQU8sRUFBcUIsVUFBVSxFQUFnQixNQUFNLHNCQUFzQixDQUFDO0FBRW5GLE9BQU8sRUFBRSxHQUFHLEVBQUUsTUFBTSxnQkFBZ0IsQ0FBQztBQUNyQyxPQUFPLEVBQUUsWUFBWSxFQUFFLE1BQU0sb0NBQW9DLENBQUM7QUE4QmxFLE1BQU0sT0FBTyxhQUFhO0lBZ0J0QixZQUNZLEtBQWlCLEVBQ2pCLFdBQXlCO1FBRHpCLFVBQUssR0FBTCxLQUFLLENBQVk7UUFDakIsZ0JBQVcsR0FBWCxXQUFXLENBQWM7UUFqQjlCLGFBQVEsR0FBVyxFQUFFLENBQUM7UUFDdEIsZ0JBQVcsR0FBb0Q7WUFDbEUsS0FBSyxFQUFFLEVBQUU7WUFDVCxNQUFNLEVBQUUsRUFBRTtZQUNWLEVBQUUsRUFBRSxFQUFFO1NBQ1QsQ0FBQztRQUNLLGFBQVEsR0FBVyxFQUFFLENBQUM7UUFPUCxnQkFBVyxHQUFHLHFCQUFxQixDQUFDO0lBS3RELENBQUM7SUFHTCxRQUFRO1FBQ0osNkNBQTZDO1FBRTdDLElBQUksQ0FBQyxtQkFBbUIsRUFBRSxDQUFDO1FBRTNCLElBQUksT0FBTyxJQUFJLENBQUMsR0FBRyxLQUFLLFdBQVcsRUFBRTtZQUNqQyxJQUFJLENBQUMsUUFBUSxHQUFHLElBQUksQ0FBQyxHQUFHLENBQUM7U0FDNUI7UUFFRCxJQUFJLE9BQU8sSUFBSSxDQUFDLEtBQUssS0FBSyxXQUFXLElBQUksQ0FBQyxPQUFPLElBQUksQ0FBQyxHQUFHLEtBQUssV0FBVyxJQUFJLElBQUksQ0FBQyxHQUFHLEtBQUssRUFBRSxDQUFDLEVBQUU7WUFDM0YsSUFBSSxDQUFDLGtCQUFrQixFQUFFLENBQUM7U0FDN0I7SUFDTCxDQUFDO0lBRUQsV0FBVyxDQUFDLGNBQTZCO1FBQ3JDLGlFQUFpRTtRQUVqRSxJQUFJLGNBQWMsQ0FBQyxjQUFjLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxjQUFjLENBQUMsUUFBUSxDQUFDLENBQUMsV0FBVyxFQUFFO1lBQ2xGLElBQUksQ0FBQyxtQkFBbUIsRUFBRSxDQUFDO1NBQzlCO1FBRUQsSUFBSSxjQUFjLENBQUMsY0FBYyxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsY0FBYyxDQUFDLEtBQUssQ0FBQyxDQUFDLFdBQVcsRUFBRTtZQUM1RSxJQUFJLENBQUMsUUFBUSxHQUFHLElBQUksQ0FBQyxHQUFHLENBQUM7U0FDNUI7UUFFRCxJQUFJLGNBQWMsQ0FBQyxjQUFjLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxjQUFjLENBQUMsT0FBTyxDQUFDLENBQUMsV0FBVyxFQUFFO1lBQ2hGLElBQUksQ0FBQyxrQkFBa0IsRUFBRSxDQUFDO1NBQzdCO0lBQ0wsQ0FBQztJQUVELFdBQVc7UUFDUCxJQUFJLENBQUMsZ0JBQWdCLEVBQUUsQ0FBQztJQUM1QixDQUFDO0lBRU0sUUFBUSxDQUFDLE1BQWE7UUFDekIsSUFBSSxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsWUFBWTtZQUFFLE9BQU87UUFFdEMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxVQUFVLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxFQUFFLENBQUMsQ0FBQztJQUNoRCxDQUFDO0lBRUQsNERBQTREO0lBQ3BELG1CQUFtQjtRQUN2QixJQUFJLGFBQWEsR0FBdUI7WUFDcEMsS0FBSyxFQUFFLEdBQUc7WUFDVixNQUFNLEVBQUUsR0FBRztZQUNYLElBQUksRUFBRSxhQUFhO1lBQ25CLFlBQVksRUFBRSxLQUFLO1lBQ25CLFVBQVUsRUFBRSxLQUFLO1lBQ2pCLEVBQUUsRUFBRSxJQUFJLENBQUMsR0FBRyxFQUFFLENBQUMsUUFBUSxFQUFFO1NBQzVCLENBQUM7UUFFRixJQUFJLENBQUMsTUFBTSxHQUFHLE1BQU0sQ0FBQyxNQUFNLENBQUMsRUFBRSxFQUFFLGFBQWEsRUFBRSxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUM7UUFDNUQsSUFBSSxDQUFDLFdBQVcsQ0FBQyxFQUFFLEdBQUcsSUFBSSxDQUFDLE1BQU0sQ0FBQyxFQUFFLENBQUM7UUFDckMsMkRBQTJEO1FBQzNELElBQUksQ0FBQyxRQUFRLEdBQUcsSUFBSSxDQUFDLE1BQU0sQ0FBQyxLQUFLLEdBQUcsQ0FBQyxHQUFHLENBQUMsQ0FBQztJQUM5QyxDQUFDO0lBRU8sa0JBQWtCO1FBQ3RCLElBQUksVUFBVSxHQUFXLENBQUMsT0FBTyxJQUFJLENBQUMsS0FBSyxDQUFDLFFBQVEsS0FBSyxXQUFXLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQztRQUNqRyxJQUFJLENBQUMsV0FBVyxDQUFDLEtBQUssR0FBRyxVQUFVLENBQUM7SUFDeEMsQ0FBQztJQUVPLGtCQUFrQjs7UUFDdEIsSUFBSSxDQUFDLGtCQUFrQixFQUFFLENBQUM7UUFFMUIsSUFBSSxPQUFPLElBQUksQ0FBQyxLQUFLLENBQUMsR0FBRyxLQUFLLFdBQVcsRUFBRTtZQUN2QyxJQUFJLENBQUMsUUFBUSxHQUFHLElBQUksQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDO1NBQ2xDO2FBQ0ksSUFBSSxPQUFPLElBQUksQ0FBQyxLQUFLLENBQUMsSUFBSSxLQUFLLFdBQVcsSUFBSSxPQUFPLElBQUksQ0FBQyxLQUFLLENBQUMsU0FBUyxLQUFLLFdBQVcsRUFBRTtZQUM1RixJQUFJLENBQUMsUUFBUSxHQUFHLElBQUksQ0FBQywwQkFBMEIsRUFBRSxDQUFDO1NBQ3JEO2FBQ0ksSUFBSSxPQUFPLElBQUksQ0FBQyxLQUFLLENBQUMsSUFBSSxLQUFLLFdBQVcsRUFBRTtZQUM3QyxJQUFJLENBQUMsZ0JBQWdCLEVBQUUsQ0FBQztZQUV4QixJQUFJLENBQUMsaUJBQWlCLEdBQUcsSUFBSSxDQUFDLGlCQUFpQixFQUFFLENBQUMsU0FBUyxDQUN2RCxDQUFDLFNBQWMsRUFBUSxFQUFFO2dCQUNyQixJQUFJLENBQUMsUUFBUSxHQUFHLFNBQVMsQ0FBQztZQUM5QixDQUFDLEVBQ0QsQ0FBQyxNQUF5QixFQUFRLEVBQUU7Z0JBQ2hDLE9BQU8sQ0FBQyxLQUFLLENBQUMsd0RBQXdELEVBQUUsTUFBTSxDQUFDLENBQUM7WUFDcEYsQ0FBQyxDQUNKLENBQUM7U0FDTDthQUNJLElBQUksb0JBQU8sSUFBSSxDQUFDLEtBQUssMENBQUUsT0FBTywwQ0FBRSxPQUFPLENBQUEsS0FBSyxTQUFTLEVBQUM7WUFDdkQsSUFBSSxDQUFDLFFBQVEsZUFBRyxJQUFJLENBQUMsS0FBSywwQ0FBRSxPQUFPLDBDQUFFLE9BQU8sQ0FBQztTQUNoRDthQUFNO1lBQ0gsSUFBSSxDQUFDLFFBQVEsR0FBRyxFQUFFLENBQUE7U0FDckI7SUFFTCxDQUFDO0lBRUQsNERBQTREO0lBQ3BELDBCQUEwQjtRQUM5QixJQUFJLFVBQVUsR0FBVyxhQUFhLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQyxTQUFTLEdBQUcsVUFBVSxDQUFDO1FBQzNFLE9BQU8sVUFBVSxHQUFHLElBQUksQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDO0lBQ3hDLENBQUM7SUFFTyxpQkFBaUI7UUFDckIsT0FBTyxJQUFJLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUM7YUFDckMsSUFBSSxDQUNELEdBQUcsQ0FBQyxDQUFDLFNBQTRCLEVBQU8sRUFBRTtZQUN0QyxJQUFJLFFBQVEsR0FBUSxFQUFFLENBQUM7WUFFdkIsSUFBSTtnQkFDQSx1Q0FBdUM7Z0JBQ3ZDLElBQUksUUFBUSxHQUFXLENBQUMsT0FBTyxJQUFJLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxHQUFHLEtBQUssV0FBVyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDO2dCQUNwRyxJQUFJLFNBQVMsQ0FBQyxjQUFjLENBQUMsUUFBUSxDQUFDLEVBQUU7b0JBQ3BDLFFBQVEsR0FBRyxTQUFTLENBQUMsUUFBUSxDQUFDLENBQUM7aUJBQ2xDO2FBQ0o7WUFBQyxPQUFPLEdBQUcsRUFBRTtnQkFDVixPQUFPLENBQUMsS0FBSyxDQUFDLGdFQUFnRSxFQUFFLEdBQUcsQ0FBQyxDQUFDO2FBQ3hGO1lBQ0QsT0FBTyxRQUFRLENBQUM7UUFDcEIsQ0FBQyxDQUFDLENBQ0wsQ0FBQztJQUNWLENBQUM7SUFFRCw0REFBNEQ7SUFDcEQsZ0JBQWdCO1FBQ3BCLElBQUksT0FBTyxJQUFJLENBQUMsaUJBQWlCLEtBQUssV0FBVyxFQUFFO1lBQy9DLElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxXQUFXLEVBQUUsQ0FBQztTQUN4QztJQUNMLENBQUM7OztZQTNLSixTQUFTLFNBQUM7Z0JBQ1AsUUFBUSxFQUFFLGdCQUFnQjtnQkFDMUIsUUFBUSxFQUFFOzs7Ozs7Ozs7Ozs7Ozs7Ozs7OztLQW9CVDtnQkFDRCxhQUFhLEVBQUUsaUJBQWlCLENBQUMsSUFBSTtnQkFDckMsU0FBUyxFQUFFLENBQUMsWUFBWSxDQUFDO2FBQzVCOzs7WUEvQjJCLFVBQVU7WUFHN0IsWUFBWTs7O3FCQXlDaEIsS0FBSztvQkFDTCxLQUFLO2tCQUNMLEtBQUs7MEJBQ0wsV0FBVyxTQUFDLE9BQU8iLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQge1xyXG4gICAgQ29tcG9uZW50LFxyXG4gICAgT25Jbml0LFxyXG4gICAgT25DaGFuZ2VzLFxyXG4gICAgT25EZXN0cm95LFxyXG4gICAgU2ltcGxlQ2hhbmdlcyxcclxuICAgIFZpZXdFbmNhcHN1bGF0aW9uLFxyXG4gICAgSG9zdEJpbmRpbmcsXHJcbiAgICBJbnB1dFxyXG59IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xyXG4vLyBpbXBvcnQgeyBIdHRwLCBSZXNwb25zZSB9IGZyb20gJ0Bhbmd1bGFyL2h0dHAnO1xyXG5pbXBvcnQgeyBIdHRwRXJyb3JSZXNwb25zZSwgSHR0cENsaWVudCwgSHR0cFJlc3BvbnNlIH0gZnJvbSAnQGFuZ3VsYXIvY29tbW9uL2h0dHAnO1xyXG5pbXBvcnQgeyBPYnNlcnZhYmxlICwgIFN1YnNjcmlwdGlvbiB9IGZyb20gJ3J4anMnO1xyXG5pbXBvcnQgeyBtYXAgfSBmcm9tICdyeGpzL29wZXJhdG9ycyc7XHJcbmltcG9ydCB7IEtkTW9kYWxFdmVudCB9IGZyb20gJy4uL2tkLWFuZ3VsYXItbW9kYWwva2QtbW9kYWwtZXZlbnQnO1xyXG5pbXBvcnQge0lQbGFjZWhvbGRlckNvbmZpZywgSVBsYWNlaG9sZGVyTGluaywgSVBsYWNlaG9sZGVyVmFsdWUgfSBmcm9tICcuL2tkLWFuZ3VsYXItcGxhY2Vob2xkZXItaW50ZXJmYWNlJztcclxuXHJcbkBDb21wb25lbnQoe1xyXG4gICAgc2VsZWN0b3I6ICdrZC1wbGFjZWhvbGRlcicsXHJcbiAgICB0ZW1wbGF0ZTogYFxyXG4gICAgICAgIDxrZC1tb2RhbCAqbmdJZj0ndHJ1ZScgW2NvbmZpZ109J21vZGFsQ29uZmlnJz5cclxuICAgICAgICAgICAgPGltZyBbc3JjXT0naW1hZ2VTcmMnIFtzdHlsZS53aWR0aF09J1wiMTAwJVwiJyBbc3R5bGUuaGVpZ2h0XT0nXCIxMDAlXCInLz5cclxuICAgICAgICA8L2tkLW1vZGFsPlxyXG4gICAgICAgIDxkaXZcclxuICAgICAgICAgICAgW25nQ2xhc3NdPSd7XCJpbWFnZS1ib3JkZXJcIjogKGNvbmZpZy5ib3JkZXJUeXBlID09IFwiYm94XCIpLCBcImltYWdlLWJvcmRlci1yb3VuZFwiOiAoY29uZmlnLmJvcmRlclR5cGUgPT0gXCJjaXJjbGVcIil9J1xyXG4gICAgICAgICAgICBbc3R5bGUud2lkdGgucHhdPSdjb25maWcud2lkdGgnXHJcbiAgICAgICAgICAgIFtzdHlsZS5oZWlnaHQucHhdPSdjb25maWcuaGVpZ2h0J1xyXG4gICAgICAgID5cclxuICAgICAgICAgICAgPGltZ1xyXG4gICAgICAgICAgICAgICAgKm5nSWY9J2ltYWdlU3JjJ1xyXG4gICAgICAgICAgICAgICAgW3NyY109J2ltYWdlU3JjJ1xyXG4gICAgICAgICAgICAgICAgKGNsaWNrKT0naW1nQ2xpY2soJGV2ZW50KSdcclxuICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgPGlcclxuICAgICAgICAgICAgICAgICpuZ0lmPSchaW1hZ2VTcmMnXHJcbiAgICAgICAgICAgICAgICBbbmdDbGFzc109J2NvbmZpZy5pY29uJ1xyXG4gICAgICAgICAgICAgICAgW3N0eWxlLmZvbnRTaXplLnB4XT0nZm9udFNpemUnXHJcbiAgICAgICAgICAgID48L2k+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICBgLFxyXG4gICAgZW5jYXBzdWxhdGlvbjogVmlld0VuY2Fwc3VsYXRpb24uTm9uZSxcclxuICAgIHByb3ZpZGVyczogW0tkTW9kYWxFdmVudF1cclxufSlcclxuXHJcbmV4cG9ydCBjbGFzcyBLZFBsYWNlaG9sZGVyIGltcGxlbWVudHMgT25Jbml0LCBPbkNoYW5nZXMsIE9uRGVzdHJveSB7XHJcbiAgICBwdWJsaWMgaW1hZ2VTcmM6IHN0cmluZyA9ICcnO1xyXG4gICAgcHVibGljIG1vZGFsQ29uZmlnOiB7dGl0bGU6IHN0cmluZywgYnV0dG9uOiBBcnJheTxhbnk+LCBpZDogc3RyaW5nfSA9IHtcclxuICAgICAgICB0aXRsZTogJycsXHJcbiAgICAgICAgYnV0dG9uOiBbXSxcclxuICAgICAgICBpZDogJydcclxuICAgIH07XHJcbiAgICBwdWJsaWMgZm9udFNpemU6IG51bWJlciA9IDgwO1xyXG5cclxuICAgIHByaXZhdGUgX2h0dHBTdWJzY3JpcHRpb246IFN1YnNjcmlwdGlvbjtcclxuXHJcbiAgICBASW5wdXQoKSBjb25maWc6IElQbGFjZWhvbGRlckNvbmZpZztcclxuICAgIEBJbnB1dCgpIHZhbHVlOiBJUGxhY2Vob2xkZXJWYWx1ZTtcclxuICAgIEBJbnB1dCgpIHNyYzogc3RyaW5nO1xyXG4gICAgQEhvc3RCaW5kaW5nKCdjbGFzcycpIHBsYWNlaG9sZGVyID0gJ3BsYWNlaG9sZGVyLXdyYXBwZXInO1xyXG5cclxuICAgIGNvbnN0cnVjdG9yKFxyXG4gICAgICAgIHByaXZhdGUgX2h0dHA6IEh0dHBDbGllbnQsXHJcbiAgICAgICAgcHJpdmF0ZSBfbW9kYWxFdmVudDogS2RNb2RhbEV2ZW50XHJcbiAgICApIHsgfVxyXG5cclxuXHJcbiAgICBuZ09uSW5pdCgpOiB2b2lkIHtcclxuICAgICAgICAvLyBjb25zb2xlLmxvZygnLS0gS2RQbGFjZWhvbGRlciBPbkluaXQgLS0nKTtcclxuXHJcbiAgICAgICAgdGhpcy5fcHJvY2Vzc0ltYWdlQ29uZmlnKCk7XHJcblxyXG4gICAgICAgIGlmICh0eXBlb2YgdGhpcy5zcmMgIT09ICd1bmRlZmluZWQnKSB7XHJcbiAgICAgICAgICAgIHRoaXMuaW1hZ2VTcmMgPSB0aGlzLnNyYztcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIGlmICh0eXBlb2YgdGhpcy52YWx1ZSAhPT0gJ3VuZGVmaW5lZCcgJiYgKHR5cGVvZiB0aGlzLnNyYyA9PT0gJ3VuZGVmaW5lZCcgfHwgdGhpcy5zcmMgPT09ICcnKSkge1xyXG4gICAgICAgICAgICB0aGlzLl9wcm9jZXNzSW1hZ2VWYWx1ZSgpO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICBuZ09uQ2hhbmdlcyhfc2ltcGxlQ2hhbmdlczogU2ltcGxlQ2hhbmdlcyk6IHZvaWQge1xyXG4gICAgICAgIC8vIGNvbnNvbGUubG9nKCctLSBLZFBsYWNlaG9sZGVyIE9uQ2hhbmdlcyAtLSAnLCBfc2ltcGxlQ2hhbmdlcyk7XHJcblxyXG4gICAgICAgIGlmIChfc2ltcGxlQ2hhbmdlcy5oYXNPd25Qcm9wZXJ0eSgnY29uZmlnJykgJiYgIV9zaW1wbGVDaGFuZ2VzWydjb25maWcnXS5maXJzdENoYW5nZSkge1xyXG4gICAgICAgICAgICB0aGlzLl9wcm9jZXNzSW1hZ2VDb25maWcoKTtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIGlmIChfc2ltcGxlQ2hhbmdlcy5oYXNPd25Qcm9wZXJ0eSgnc3JjJykgJiYgIV9zaW1wbGVDaGFuZ2VzWydzcmMnXS5maXJzdENoYW5nZSkge1xyXG4gICAgICAgICAgICB0aGlzLmltYWdlU3JjID0gdGhpcy5zcmM7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICBpZiAoX3NpbXBsZUNoYW5nZXMuaGFzT3duUHJvcGVydHkoJ3ZhbHVlJykgJiYgIV9zaW1wbGVDaGFuZ2VzWyd2YWx1ZSddLmZpcnN0Q2hhbmdlKSB7XHJcbiAgICAgICAgICAgIHRoaXMuX3Byb2Nlc3NJbWFnZVZhbHVlKCk7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIG5nT25EZXN0cm95KCk6IHZvaWQge1xyXG4gICAgICAgIHRoaXMuX3Vuc3Vic2NyaWJlSHR0cCgpO1xyXG4gICAgfVxyXG5cclxuICAgIHB1YmxpYyBpbWdDbGljayhfZXZlbnQ6IEV2ZW50KTogdm9pZCB7XHJcbiAgICAgICAgaWYgKCF0aGlzLmNvbmZpZy5pc0V4cGFuZGFibGUpIHJldHVybjtcclxuXHJcbiAgICAgICAgdGhpcy5fbW9kYWxFdmVudC50b2dnbGVPcGVuKHRoaXMuY29uZmlnLmlkKTtcclxuICAgIH1cclxuXHJcbiAgICAvKioqKioqKioqKioqKioqKioqKiBQcm9jZXNzIGNvbmZpZyAqKioqKioqKioqKioqKioqKioqKioqKi9cclxuICAgIHByaXZhdGUgX3Byb2Nlc3NJbWFnZUNvbmZpZygpOiB2b2lkIHtcclxuICAgICAgICBsZXQgZGVmYXVsdENvbmZpZzogSVBsYWNlaG9sZGVyQ29uZmlnID0ge1xyXG4gICAgICAgICAgICB3aWR0aDogMTUwLFxyXG4gICAgICAgICAgICBoZWlnaHQ6IDE1MCxcclxuICAgICAgICAgICAgaWNvbjogJ2tkLW9wZW5lbWlzJyxcclxuICAgICAgICAgICAgaXNFeHBhbmRhYmxlOiBmYWxzZSxcclxuICAgICAgICAgICAgYm9yZGVyVHlwZTogJ2JveCcsXHJcbiAgICAgICAgICAgIGlkOiBEYXRlLm5vdygpLnRvU3RyaW5nKClcclxuICAgICAgICB9O1xyXG5cclxuICAgICAgICB0aGlzLmNvbmZpZyA9IE9iamVjdC5hc3NpZ24oe30sIGRlZmF1bHRDb25maWcsIHRoaXMuY29uZmlnKTtcclxuICAgICAgICB0aGlzLm1vZGFsQ29uZmlnLmlkID0gdGhpcy5jb25maWcuaWQ7XHJcbiAgICAgICAgLy8gRm9udCBzaXplIGNoZWNraW5nIHN0YW5kYXJkaXplIGFzIHdpZHRoIG9mIGltYWdlIC8gMiArIDVcclxuICAgICAgICB0aGlzLmZvbnRTaXplID0gdGhpcy5jb25maWcud2lkdGggLyAyICsgNTtcclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF9wcm9jZXNzSW1hZ2VUaXRsZSgpOiB2b2lkIHtcclxuICAgICAgICBsZXQgbW9kYWxUaXRsZTogc3RyaW5nID0gKHR5cGVvZiB0aGlzLnZhbHVlLmZpbGVuYW1lICE9PSAndW5kZWZpbmVkJykgPyB0aGlzLnZhbHVlLmZpbGVuYW1lIDogJyc7XHJcbiAgICAgICAgdGhpcy5tb2RhbENvbmZpZy50aXRsZSA9IG1vZGFsVGl0bGU7XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfcHJvY2Vzc0ltYWdlVmFsdWUoKTogdm9pZCB7XHJcbiAgICAgICAgdGhpcy5fcHJvY2Vzc0ltYWdlVGl0bGUoKTtcclxuXHJcbiAgICAgICAgaWYgKHR5cGVvZiB0aGlzLnZhbHVlLnNyYyAhPT0gJ3VuZGVmaW5lZCcpIHtcclxuICAgICAgICAgICAgdGhpcy5pbWFnZVNyYyA9IHRoaXMudmFsdWUuc3JjO1xyXG4gICAgICAgIH1cclxuICAgICAgICBlbHNlIGlmICh0eXBlb2YgdGhpcy52YWx1ZS5kYXRhICE9PSAndW5kZWZpbmVkJyAmJiB0eXBlb2YgdGhpcy52YWx1ZS5leHRlbnNpb24gIT09ICd1bmRlZmluZWQnKSB7XHJcbiAgICAgICAgICAgIHRoaXMuaW1hZ2VTcmMgPSB0aGlzLl9jb252ZXJ0RGF0YUV4dGVuc2lvblRvU3JjKCk7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGVsc2UgaWYgKHR5cGVvZiB0aGlzLnZhbHVlLmxpbmsgIT09ICd1bmRlZmluZWQnKSB7XHJcbiAgICAgICAgICAgIHRoaXMuX3Vuc3Vic2NyaWJlSHR0cCgpO1xyXG5cclxuICAgICAgICAgICAgdGhpcy5faHR0cFN1YnNjcmlwdGlvbiA9IHRoaXMuX2NvbnZlcnRMaW5rVG9TcmMoKS5zdWJzY3JpYmUoXHJcbiAgICAgICAgICAgICAgICAoX3Jlc3BvbnNlOiBhbnkpOiB2b2lkID0+IHtcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLmltYWdlU3JjID0gX3Jlc3BvbnNlO1xyXG4gICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICAgIChfZXJyb3I6IEh0dHBFcnJvclJlc3BvbnNlKTogdm9pZCA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgY29uc29sZS5lcnJvcignS2RQbGFjZWhvbGRlciBlcnJvciAtIEVycm9yIHJldHJpZXZpbmcgZGF0YSBmb3IgaW1hZ2UuJywgX2Vycm9yKTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgKTtcclxuICAgICAgICB9XHJcbiAgICAgICAgZWxzZSBpZiAodHlwZW9mIHRoaXMudmFsdWU/Lm5ld0xpbms/LnNyY0RhdGEgIT09IHVuZGVmaW5lZCl7XHJcbiAgICAgICAgICAgIHRoaXMuaW1hZ2VTcmMgPSB0aGlzLnZhbHVlPy5uZXdMaW5rPy5zcmNEYXRhO1xyXG4gICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgIHRoaXMuaW1hZ2VTcmMgPSAnJ1xyXG4gICAgICAgIH1cclxuXHJcbiAgICB9XHJcblxyXG4gICAgLyoqKioqKioqKioqKioqKioqKioqIENvbnZlcnQgZGF0YSAqKioqKioqKioqKioqKioqKioqKioqKiovXHJcbiAgICBwcml2YXRlIF9jb252ZXJ0RGF0YUV4dGVuc2lvblRvU3JjKCk6IHN0cmluZyB7XHJcbiAgICAgICAgbGV0IGRhdGFQcmVmaXg6IHN0cmluZyA9ICdkYXRhOmltYWdlLycgKyB0aGlzLnZhbHVlLmV4dGVuc2lvbiArICc7YmFzZTY0LCc7XHJcbiAgICAgICAgcmV0dXJuIGRhdGFQcmVmaXggKyB0aGlzLnZhbHVlLmRhdGE7XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfY29udmVydExpbmtUb1NyYygpOiBPYnNlcnZhYmxlPEh0dHBSZXNwb25zZTxhbnk+PiB7XHJcbiAgICAgICAgcmV0dXJuIHRoaXMuX2h0dHAuZ2V0KHRoaXMudmFsdWUubGluay51cmwpXHJcbiAgICAgICAgICAgIC5waXBlKFxyXG4gICAgICAgICAgICAgICAgbWFwKChfcmVzcG9uc2U6IEh0dHBSZXNwb25zZTxhbnk+KTogYW55ID0+IHtcclxuICAgICAgICAgICAgICAgICAgICBsZXQgcmVzcG9uc2U6IGFueSA9IHt9O1xyXG5cclxuICAgICAgICAgICAgICAgICAgICB0cnkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAvLyBsZXQgdGVtcFJlczogYW55ID0gX3Jlc3BvbnNlLmpzb24oKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgbGV0IGltYWdlS2V5OiBzdHJpbmcgPSAodHlwZW9mIHRoaXMudmFsdWUubGluay5rZXkgIT09ICd1bmRlZmluZWQnKSA/IHRoaXMudmFsdWUubGluay5rZXkgOiAnaW1hZ2UnO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAoX3Jlc3BvbnNlLmhhc093blByb3BlcnR5KGltYWdlS2V5KSkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcmVzcG9uc2UgPSBfcmVzcG9uc2VbaW1hZ2VLZXldO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgfSBjYXRjaCAoZXJyKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbnNvbGUuZXJyb3IoJ0tkUGxhY2Vob2xkZXIgZXJyb3IgLSBFcnJvciBpbiByZXRyaWV2aW5nIGltYWdlIHNyYyBmcm9tIHVybC4gJywgZXJyKTtcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIHJlc3BvbnNlO1xyXG4gICAgICAgICAgICAgICAgfSlcclxuICAgICAgICAgICAgKTtcclxuICAgIH1cclxuXHJcbiAgICAvKioqKioqKioqKioqKioqKioqKiogQ29udmVydCBkYXRhICoqKioqKioqKioqKioqKioqKioqKioqKi9cclxuICAgIHByaXZhdGUgX3Vuc3Vic2NyaWJlSHR0cCgpOiB2b2lkIHtcclxuICAgICAgICBpZiAodHlwZW9mIHRoaXMuX2h0dHBTdWJzY3JpcHRpb24gIT09ICd1bmRlZmluZWQnKSB7XHJcbiAgICAgICAgICAgIHRoaXMuX2h0dHBTdWJzY3JpcHRpb24udW5zdWJzY3JpYmUoKTtcclxuICAgICAgICB9XHJcbiAgICB9XHJcbn1cclxuIl19