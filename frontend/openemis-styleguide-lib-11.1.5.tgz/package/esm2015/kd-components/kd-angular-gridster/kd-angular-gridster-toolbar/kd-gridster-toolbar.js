import { Component, ViewEncapsulation, Input } from '@angular/core';
export class KdGridsterToolbar {
    constructor() {
        this.leftButtons = [];
    }
    ngOnInit() {
        let buttonList = (this.item.buttons && this.item.buttons.length > 0) ? this.item.buttons : this.config.buttons;
        this.getGridItemToolbarButtons(buttonList);
    }
    getGridItemToolbarButtons(_buttonList) {
        this.rightButtons = _buttonList.filter((button, index) => {
            if (button.position === 'left') {
                this.leftButtons.push(button);
                return false;
            }
            return true;
        });
    }
}
KdGridsterToolbar.decorators = [
    { type: Component, args: [{
                selector: 'kd-gridster-toolbar',
                providers: [],
                encapsulation: ViewEncapsulation.None,
                template: "<div class=\"kdx-item-buttons-right\" [ngClass]=\"{'no-drag': !item.enableContentDrag}\" *ngIf=\"!config.hideCustomButton\">\r\n    <button *ngFor=\"let button of rightButtons\" (mousedown)=\"button.callback(button, item)\" class=\"kdx-item-buttons kdx-item-edit btn-outline rounded-circle {{button.position}}\" [ngClass]=\"{'btn hidden': !button.visible, 'btn disabled': button.disabled}\" [kd-tooltip-dir]=\"button.name\" tooltipPosition=\"bottom\" tooltipStyleClass=\"kdx-tooltip-default\" [tooltipDisabled]=\"button.disabled\" [disabled]=\"button.disabled\">\r\n        <i class=\"{{button.icon}}\"></i>\r\n    </button>\r\n</div>\r\n<div class=\"kdx-item-buttons-left\" [ngClass]=\"{'no-drag': !item.enableContentDrag}\" *ngIf=\"!config.hideCustomButton\">\r\n    <button *ngFor=\"let button of leftButtons\" (mousedown)=\"button.callback(button, item)\" class=\"kdx-item-buttons kdx-item-edit btn-outline rounded-circle {{button.position}}\" [ngClass]=\"{'btn hidden': !button.visible, 'btn disabled': button.disabled}\" [kd-tooltip-dir]=\"button.name\" tooltipPosition=\"bottom\" tooltipStyleClass=\"kdx-tooltip-default\" [tooltipDisabled]=\"button.disabled\" [disabled]=\"button.disabled\">\r\n        <i class=\"{{button.icon}}\"></i>\r\n    </button>\r\n</div>\r\n<button  *ngIf=\"(!config.hideDragButton && config.draggable.enabled) || (config.hideDragButton && config.draggable.enabled && !item.enableContentDrag)\" class=\"kdx-item-buttons kdx-item-drag btn-outline rounded-circle drag-handler\" [kd-tooltip-dir]=\"'Drag'\" tooltipPosition=\"bottom\" tooltipStyleClass=\"kdx-tooltip-default\">\r\n        <i class=\"fa fa-arrows\"></i>\r\n    </button>",
                host: { 'class': 'kdx-gridster-toolbar' }
            },] }
];
KdGridsterToolbar.ctorParameters = () => [];
KdGridsterToolbar.propDecorators = {
    item: [{ type: Input }],
    config: [{ type: Input }]
};
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoia2QtZ3JpZHN0ZXItdG9vbGJhci5qcyIsInNvdXJjZVJvb3QiOiJDOi94YW1wcC9odGRvY3MvU3R5bGVndWlkZS9pb3N0Zy1vcGVuZW1pcy1zdHlsZWd1aWRlL3Byb2plY3RzL29wZW5lbWlzLXN0eWxlZ3VpZGUtbGliL3NyYy8iLCJzb3VyY2VzIjpbImtkLWNvbXBvbmVudHMva2QtYW5ndWxhci1ncmlkc3Rlci9rZC1hbmd1bGFyLWdyaWRzdGVyLXRvb2xiYXIva2QtZ3JpZHN0ZXItdG9vbGJhci50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQSxPQUFPLEVBQ0gsU0FBUyxFQUNULGlCQUFpQixFQUVqQixLQUFLLEVBQ1IsTUFBTSxlQUFlLENBQUM7QUFnQnZCLE1BQU0sT0FBTyxpQkFBaUI7SUFRMUI7UUFITyxnQkFBVyxHQUEyQixFQUFFLENBQUM7SUFJNUMsQ0FBQztJQUVMLFFBQVE7UUFDSixJQUFJLFVBQVUsR0FBMkIsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLE9BQU8sSUFBSSxJQUFJLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxNQUFNLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLE9BQU8sQ0FBQztRQUN2SSxJQUFJLENBQUMseUJBQXlCLENBQUMsVUFBVSxDQUFDLENBQUM7SUFDL0MsQ0FBQztJQUVPLHlCQUF5QixDQUFDLFdBQW1DO1FBQ2pFLElBQUksQ0FBQyxZQUFZLEdBQUcsV0FBVyxDQUFDLE1BQU0sQ0FBQyxDQUFDLE1BQU0sRUFBRSxLQUFLLEVBQUUsRUFBRTtZQUNyRCxJQUFJLE1BQU0sQ0FBQyxRQUFRLEtBQUssTUFBTSxFQUFFO2dCQUM1QixJQUFJLENBQUMsV0FBVyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQztnQkFDOUIsT0FBTyxLQUFLLENBQUM7YUFDaEI7WUFDRCxPQUFPLElBQUksQ0FBQztRQUNoQixDQUFDLENBQUMsQ0FBQztJQUNQLENBQUM7OztZQWhDSixTQUFTLFNBQUM7Z0JBQ1AsUUFBUSxFQUFFLHFCQUFxQjtnQkFDL0IsU0FBUyxFQUFFLEVBQUU7Z0JBQ2IsYUFBYSxFQUFFLGlCQUFpQixDQUFDLElBQUk7Z0JBQ3JDLDZvREFBeUM7Z0JBQ3pDLElBQUksRUFBRSxFQUFFLE9BQU8sRUFBRSxzQkFBc0IsRUFBRTthQUM1Qzs7OzttQkFJSSxLQUFLO3FCQUNMLEtBQUsiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQge1xyXG4gICAgQ29tcG9uZW50LFxyXG4gICAgVmlld0VuY2Fwc3VsYXRpb24sXHJcbiAgICBPbkluaXQsXHJcbiAgICBJbnB1dFxyXG59IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xyXG5cclxuaW1wb3J0IHtcclxuICAgIElHcmlkc3Rlckl0ZW0sXHJcbiAgICBJR3JpZHN0ZXJDb25maWcsXHJcbiAgICBJR3JpZHN0ZXJCdXR0b25cclxufSBmcm9tICcuLi9rZC1ncmlkc3Rlci1pbnRlcmZhY2UnO1xyXG5cclxuQENvbXBvbmVudCh7XHJcbiAgICBzZWxlY3RvcjogJ2tkLWdyaWRzdGVyLXRvb2xiYXInLFxyXG4gICAgcHJvdmlkZXJzOiBbXSxcclxuICAgIGVuY2Fwc3VsYXRpb246IFZpZXdFbmNhcHN1bGF0aW9uLk5vbmUsXHJcbiAgICB0ZW1wbGF0ZVVybDogJy4va2QtZ3JpZHN0ZXItdG9vbGJhci5odG1sJyxcclxuICAgIGhvc3Q6IHsgJ2NsYXNzJzogJ2tkeC1ncmlkc3Rlci10b29sYmFyJyB9XHJcbn0pXHJcblxyXG5leHBvcnQgY2xhc3MgS2RHcmlkc3RlclRvb2xiYXIgaW1wbGVtZW50cyBPbkluaXQge1xyXG5cclxuICAgIEBJbnB1dCgpIGl0ZW06IElHcmlkc3Rlckl0ZW07XHJcbiAgICBASW5wdXQoKSBjb25maWc6IElHcmlkc3RlckNvbmZpZztcclxuXHJcbiAgICBwdWJsaWMgbGVmdEJ1dHRvbnM6IEFycmF5PElHcmlkc3RlckJ1dHRvbj4gPSBbXTtcclxuICAgIHB1YmxpYyByaWdodEJ1dHRvbnM6IEFycmF5PElHcmlkc3RlckJ1dHRvbj47XHJcblxyXG4gICAgY29uc3RydWN0b3IoXHJcbiAgICApIHsgfVxyXG5cclxuICAgIG5nT25Jbml0KCk6IHZvaWQge1xyXG4gICAgICAgIGxldCBidXR0b25MaXN0OiBBcnJheTxJR3JpZHN0ZXJCdXR0b24+ID0gKHRoaXMuaXRlbS5idXR0b25zICYmIHRoaXMuaXRlbS5idXR0b25zLmxlbmd0aCA+IDApID8gdGhpcy5pdGVtLmJ1dHRvbnMgOiB0aGlzLmNvbmZpZy5idXR0b25zO1xyXG4gICAgICAgIHRoaXMuZ2V0R3JpZEl0ZW1Ub29sYmFyQnV0dG9ucyhidXR0b25MaXN0KTtcclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIGdldEdyaWRJdGVtVG9vbGJhckJ1dHRvbnMoX2J1dHRvbkxpc3Q6IEFycmF5PElHcmlkc3RlckJ1dHRvbj4pOiB2b2lkIHtcclxuICAgICAgICB0aGlzLnJpZ2h0QnV0dG9ucyA9IF9idXR0b25MaXN0LmZpbHRlcigoYnV0dG9uLCBpbmRleCkgPT4ge1xyXG4gICAgICAgICAgICBpZiAoYnV0dG9uLnBvc2l0aW9uID09PSAnbGVmdCcpIHtcclxuICAgICAgICAgICAgICAgIHRoaXMubGVmdEJ1dHRvbnMucHVzaChidXR0b24pO1xyXG4gICAgICAgICAgICAgICAgcmV0dXJuIGZhbHNlO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIHJldHVybiB0cnVlO1xyXG4gICAgICAgIH0pO1xyXG4gICAgfVxyXG59XHJcbiJdfQ==