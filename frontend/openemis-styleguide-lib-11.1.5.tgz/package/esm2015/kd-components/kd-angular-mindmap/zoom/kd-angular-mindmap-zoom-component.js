import { Component, ViewEncapsulation, Input } from '@angular/core';
export class KdMindmapZoomButton {
    constructor() {
        this.iconType = 'plus';
    }
    ngOnInit() {
        this.iconType = this.action === 'zoom_in' ? 'plus' : 'minus';
    }
    onClick(_event) {
        _event.stopPropagation();
        if (typeof this.internalApi !== 'undefined') {
            this.internalApi.zoom(this.action);
        }
    }
}
KdMindmapZoomButton.decorators = [
    { type: Component, args: [{
                selector: '[zoomButton]',
                template: `
        <svg:rect
            class="kdx-mindmap-zoom-button-wrapper kdx-mindmap-zoom-in"
            x="0"
            y="0"
            rx="2"
            ry="2"
            [attr.width]="config.size"
            [attr.height]="config.size"
        ></svg:rect>
        <svg [attr.width]="config.iconSize"
             [attr.height]="config.iconSize"
             [attr.x]="config.size/2 - config.iconSize/2"
             [attr.y]="config.size/2 - config.iconSize/2">
            <use class="kdx-mindmap-zoom-button-icon"
                 [attr.href]="config.iconLinkPath + iconType" ></use>
        </svg>
    `,
                encapsulation: ViewEncapsulation.None,
                host: {
                    'class': 'kdx-mindmap-zoom-button',
                    '(click)': 'onClick($event)',
                }
            },] }
];
KdMindmapZoomButton.propDecorators = {
    config: [{ type: Input }],
    action: [{ type: Input, args: ['zoomButton',] }],
    internalApi: [{ type: Input, args: ['api',] }]
};
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoia2QtYW5ndWxhci1taW5kbWFwLXpvb20tY29tcG9uZW50LmpzIiwic291cmNlUm9vdCI6IkM6L3hhbXBwL2h0ZG9jcy9TdHlsZWd1aWRlL2lvc3RnLW9wZW5lbWlzLXN0eWxlZ3VpZGUvcHJvamVjdHMvb3BlbmVtaXMtc3R5bGVndWlkZS1saWIvc3JjLyIsInNvdXJjZXMiOlsia2QtY29tcG9uZW50cy9rZC1hbmd1bGFyLW1pbmRtYXAvem9vbS9rZC1hbmd1bGFyLW1pbmRtYXAtem9vbS1jb21wb25lbnQudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsT0FBTyxFQUNILFNBQVMsRUFDVCxpQkFBaUIsRUFDakIsS0FBSyxFQUVSLE1BQU0sZUFBZSxDQUFDO0FBOEJ2QixNQUFNLE9BQU8sbUJBQW1CO0lBM0JoQztRQTRCVyxhQUFRLEdBQVcsTUFBTSxDQUFDO0lBZXJDLENBQUM7SUFWRyxRQUFRO1FBQ0osSUFBSSxDQUFDLFFBQVEsR0FBRyxJQUFJLENBQUMsTUFBTSxLQUFLLFNBQVMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUM7SUFDakUsQ0FBQztJQUVNLE9BQU8sQ0FBQyxNQUFhO1FBQ3hCLE1BQU0sQ0FBQyxlQUFlLEVBQUUsQ0FBQztRQUN6QixJQUFJLE9BQU8sSUFBSSxDQUFDLFdBQVcsS0FBSyxXQUFXLEVBQUU7WUFDekMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDO1NBQ3RDO0lBQ0wsQ0FBQzs7O1lBMUNKLFNBQVMsU0FBQztnQkFDUCxRQUFRLEVBQUUsY0FBYztnQkFDeEIsUUFBUSxFQUFFOzs7Ozs7Ozs7Ozs7Ozs7OztLQWlCVDtnQkFDRCxhQUFhLEVBQUUsaUJBQWlCLENBQUMsSUFBSTtnQkFDckMsSUFBSSxFQUFFO29CQUNGLE9BQU8sRUFBRSx5QkFBeUI7b0JBQ2xDLFNBQVMsRUFBRSxpQkFBaUI7aUJBQy9CO2FBQ0o7OztxQkFJSSxLQUFLO3FCQUNMLEtBQUssU0FBQyxZQUFZOzBCQUNsQixLQUFLLFNBQUMsS0FBSyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7XHJcbiAgICBDb21wb25lbnQsXHJcbiAgICBWaWV3RW5jYXBzdWxhdGlvbixcclxuICAgIElucHV0LFxyXG4gICAgT25Jbml0XHJcbn0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XHJcbmltcG9ydCB7IElab29tQnV0dG9uQ29uZmlnLCBJTWluZG1hcEludGVybmFsQXBpIH0gZnJvbSAnLi4va2QtYW5ndWxhci1taW5kbWFwLWludGVyZmFjZSc7XHJcblxyXG5AQ29tcG9uZW50KHtcclxuICAgIHNlbGVjdG9yOiAnW3pvb21CdXR0b25dJyxcclxuICAgIHRlbXBsYXRlOiBgXHJcbiAgICAgICAgPHN2ZzpyZWN0XHJcbiAgICAgICAgICAgIGNsYXNzPVwia2R4LW1pbmRtYXAtem9vbS1idXR0b24td3JhcHBlciBrZHgtbWluZG1hcC16b29tLWluXCJcclxuICAgICAgICAgICAgeD1cIjBcIlxyXG4gICAgICAgICAgICB5PVwiMFwiXHJcbiAgICAgICAgICAgIHJ4PVwiMlwiXHJcbiAgICAgICAgICAgIHJ5PVwiMlwiXHJcbiAgICAgICAgICAgIFthdHRyLndpZHRoXT1cImNvbmZpZy5zaXplXCJcclxuICAgICAgICAgICAgW2F0dHIuaGVpZ2h0XT1cImNvbmZpZy5zaXplXCJcclxuICAgICAgICA+PC9zdmc6cmVjdD5cclxuICAgICAgICA8c3ZnIFthdHRyLndpZHRoXT1cImNvbmZpZy5pY29uU2l6ZVwiXHJcbiAgICAgICAgICAgICBbYXR0ci5oZWlnaHRdPVwiY29uZmlnLmljb25TaXplXCJcclxuICAgICAgICAgICAgIFthdHRyLnhdPVwiY29uZmlnLnNpemUvMiAtIGNvbmZpZy5pY29uU2l6ZS8yXCJcclxuICAgICAgICAgICAgIFthdHRyLnldPVwiY29uZmlnLnNpemUvMiAtIGNvbmZpZy5pY29uU2l6ZS8yXCI+XHJcbiAgICAgICAgICAgIDx1c2UgY2xhc3M9XCJrZHgtbWluZG1hcC16b29tLWJ1dHRvbi1pY29uXCJcclxuICAgICAgICAgICAgICAgICBbYXR0ci5ocmVmXT1cImNvbmZpZy5pY29uTGlua1BhdGggKyBpY29uVHlwZVwiID48L3VzZT5cclxuICAgICAgICA8L3N2Zz5cclxuICAgIGAsXHJcbiAgICBlbmNhcHN1bGF0aW9uOiBWaWV3RW5jYXBzdWxhdGlvbi5Ob25lLFxyXG4gICAgaG9zdDoge1xyXG4gICAgICAgICdjbGFzcyc6ICdrZHgtbWluZG1hcC16b29tLWJ1dHRvbicsXHJcbiAgICAgICAgJyhjbGljayknOiAnb25DbGljaygkZXZlbnQpJyxcclxuICAgIH1cclxufSlcclxuXHJcbmV4cG9ydCBjbGFzcyBLZE1pbmRtYXBab29tQnV0dG9uIGltcGxlbWVudHMgT25Jbml0IHtcclxuICAgIHB1YmxpYyBpY29uVHlwZTogc3RyaW5nID0gJ3BsdXMnO1xyXG4gICAgQElucHV0KCkgY29uZmlnOiBJWm9vbUJ1dHRvbkNvbmZpZztcclxuICAgIEBJbnB1dCgnem9vbUJ1dHRvbicpIGFjdGlvbjogc3RyaW5nO1xyXG4gICAgQElucHV0KCdhcGknKSBpbnRlcm5hbEFwaTogSU1pbmRtYXBJbnRlcm5hbEFwaTtcclxuXHJcbiAgICBuZ09uSW5pdCgpOiB2b2lkIHtcclxuICAgICAgICB0aGlzLmljb25UeXBlID0gdGhpcy5hY3Rpb24gPT09ICd6b29tX2luJyA/ICdwbHVzJyA6ICdtaW51cyc7XHJcbiAgICB9XHJcblxyXG4gICAgcHVibGljIG9uQ2xpY2soX2V2ZW50OiBFdmVudCk6IHZvaWQge1xyXG4gICAgICAgIF9ldmVudC5zdG9wUHJvcGFnYXRpb24oKTtcclxuICAgICAgICBpZiAodHlwZW9mIHRoaXMuaW50ZXJuYWxBcGkgIT09ICd1bmRlZmluZWQnKSB7XHJcbiAgICAgICAgICAgIHRoaXMuaW50ZXJuYWxBcGkuem9vbSh0aGlzLmFjdGlvbik7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG59XHJcbiJdfQ==