import { Injectable } from '@angular/core';
import * as d3 from 'd3';
import { ForceDirectedGraph } from './kd-angular-mindmap-force-logic';
import { ZoomClass } from './zoom/kd-angular-mindmap-zoom-logic';
export class KdMindmapSvc {
    constructor() {
        this._dataMessagingInfo = {
            highestCount: 1,
            count: 1,
            linksStored: {}
        };
        this._nodesObj = {};
        this._newLinks = [];
    }
    /**
     * A method to bind a draggable behaviour to an svg element
     *          element [element to attach drag behaviour]
     *        node    [node info]
     *  graph   [object connecting to d3 force logic]
     */
    applyDraggableBehaviour(element, node, graph) {
        const d3element = d3.select(element);
        function started() {
            /** Preventing propagation of dragstart to parent elements */
            d3.event.sourceEvent.stopPropagation();
            if (!d3.event.active) {
                graph.simulation.alphaTarget(0.3).restart();
            }
            d3.event.on('drag', dragged).on('end', ended);
            function dragged() {
                node.fx = d3.event.x;
                node.fy = d3.event.y;
            }
            function ended() {
                if (!d3.event.active) {
                    graph.simulation.alphaTarget(0);
                }
                node.fx = null;
                node.fy = null;
            }
        }
        d3element.call(d3.drag()
            .on('start', started));
    }
    /**
     * [getZoomClass returns the zoom class]
     *   _svg       [the main svg element]
     *  _container [the g tag that contains the nodes and links]
     *               [zoom class contains d3 codes and stores the _svg and _container variables for d3 zooming]
     */
    getZoomClass(_svg, _container) {
        const zoomClass = new ZoomClass(_svg, _container);
        return zoomClass;
    }
    /**
     * [getForceDirectedGraph The interactable graph we will simulate in this article. This method does not interact with the document, purely physical calculations with d3]
     *      nodes   [description]
     *      links   [description]
     *     options [contains info of width, height of main svg container and levelPosition]
     *          [ForceDirectedGraph class]
     */
    getForceDirectedGraph(nodes, links, options) {
        const sg = new ForceDirectedGraph(nodes, links, options);
        return sg;
    }
    /**
     * textWrap handles text wrapping in svg
     *  _text   text to display
     *     _config [description]
     *          total text height
     */
    textWrap(_text, _class, _config) {
        let textElement = d3.select('.' + _class.replace(/ /g, '.')), words = _text.split(' ').reverse(), word, line = [], lineNumber = 0, lineHeight = _config.fontSize + 2, // in px
        y = textElement.attr('y'), x = textElement.attr('x'), dy = parseFloat(textElement.attr('dy')), tspan = textElement.text(null).append('tspan').attr('x', x).attr('y', y).attr('dy', dy);
        while (word = words.pop()) {
            line.push(word);
            tspan.text(line.join(' '));
            if (tspan.node().getComputedTextLength() > (_config.width - 2 * _config.textPadding)) {
                line.pop();
                tspan.text(line.join(' '));
                line = [word];
                tspan = textElement.append('tspan')
                    .attr('x', x)
                    .attr('y', y)
                    .attr('dy', ++lineNumber * lineHeight + dy)
                    .text(word);
            }
        }
        return (lineNumber + 1) * lineHeight + dy;
    }
    /**
     * [set height of node's title wrapper and node wrapper's height.
     *  Note: title's height have to be calculated and updated to html first
     *  before appending the description text]
     *  _config [node's Config]
     *               _type   [for title or node]
     *                       [height of title or node]
     */
    setSVGContainerHeight(_config, _type) {
        if (_type === 'title') {
            return _config.title.textHeight + _config.title.paddingTop + _config.title.paddingBottom;
        }
        if (_type === 'node') {
            return _config.description.textHeight + _config.title.height + _config.icon.size + _config.icon.marginBottom + _config.icon.marginTop + _config.description.marginBottom + _config.description.marginTop;
        }
    }
    /**
     * [setData appending index, pushing nodes to Array for d3, calling recursive loop this._setLinksAndLevel]
     * } _nodes [description]
     *   [height of title or node]
     */
    setData(_nodes) {
        this._nodesObj = {};
        let newNodes = [], index = 0, haveLoner = false;
        // appending a new key called index to each node.
        // d3 v4 requires link source and target to point to index of node in nodeArr.
        // Hence the below for loop will (1) create a clean copy of object (2) append index to each node
        for (let key in _nodes) {
            if (_nodes.hasOwnProperty(key)) {
                this._nodesObj[key] = Object.assign({}, _nodes[key]);
                this._nodesObj[key].index = index;
                newNodes.push(this._nodesObj[key]);
                index++;
            }
        }
        // this for loop will look for ONLY nodes that have no parents (ie. ancestor nodes and loner nodes)
        // using these nodes as starting points, we start 'walking the branch' via this._setLinksAndLevel to update the links with the relationships of the nodes
        // at this stage, index of all nodes must be defined within the node obj so that the links can be set up correctly
        for (let key in this._nodesObj) {
            if (typeof this._nodesObj[key].parents === 'undefined' || this._nodesObj[key].parents.length === 0) {
                this._setLinksAndLevel(this._nodesObj[key], key);
                // this._setLinksAndLevel did not set level of these starting nodes
                // manually setting their levels now
                this._nodesObj[key].level = 1;
                if (typeof this._nodesObj[key].childs === 'undefined' || this._nodesObj[key].childs.length === 0) {
                    this._nodesObj[key].level = 0;
                    haveLoner = true;
                }
            }
        }
        return {
            nodes: newNodes,
            links: this._newLinks,
            highestCount: this._dataMessagingInfo.highestCount,
            haveLoner: haveLoner
        };
    }
    /**
     * [setFx will set fx coordinate of each node]
     *         _nodes
     * }   position      [fx coordinate of each level]
     *                    _haveLoner     [whether there exist loner in the graph]
     *        _nodes        [nodes with fx value]
     */
    setFx(_nodes, _position, _haveLoner) {
        for (let i = 0; i < _nodes.length; ++i) {
            _nodes[i].fx = _haveLoner ? _position[_nodes[i].level] : _position[_nodes[i].level - 1];
        }
        return _nodes;
    }
    /**
     * [translateSvgToXPos translate node to center, right edge or left edge of main svg container]
     * }   _config      [widths of main svg, node and padding]
     *  _nodeToFocus
     *  _placement
     *                     [x-coordinate for ]
     */
    translateSvgToXPos(_config, _nodeToFocus, _placement) {
        let xPos = 0;
        if (_placement === 'right') {
            xPos = _config.svgWidth;
            return xPos - _nodeToFocus.fx - _config.nodeWidth / 2 - _config.padding;
        }
        if (_placement === 'center') {
            xPos = _config.svgWidth / 2;
            return xPos - _nodeToFocus.fx;
        }
        if (_placement === 'left') {
            return -_nodeToFocus.fx + _config.nodeWidth / 2 + _config.padding;
        }
    }
    /**
     * [setLinkSpreadDistance calculate offset needed for links to spread evenly across height of node]
     *    _links
     *  _node       [node that have finished height calculation. (these nodes must have parents)]
     *        _nodeHeight [Height of node]
     *                     [return index of link and offset value]
     */
    setLinkSpreadDistance(_links, _node, _nodeHeight) {
        let noOfParents = _node.parents.length;
        if (noOfParents === 1)
            return [];
        let dist = (_nodeHeight - 20) / (noOfParents - 1);
        let affectedLinks = [];
        for (let i = 0; i < _links.length; ++i) {
            if (_links[i].target.id === _node.id) {
                affectedLinks.push({ index: _links[i].index });
            }
        }
        for (let i = 0; i < affectedLinks.length; ++i) {
            affectedLinks[i].offset = -_nodeHeight / 2 + i * dist + 10;
        }
        return affectedLinks;
    }
    foundSelectedNode(_nodes, _selectOnLoadId) {
        return _nodes[_selectOnLoadId] !== null && _nodes[_selectOnLoadId] !== undefined;
    }
    /**
     * [_setLinksAndLevel is to generate the level, level's record highestCount, links Array, parents array]
     *  _node [Object containing all info of a node, to be passed to component kd-mindmap-node]
     *        key   [key of the node object in the master object]
     */
    _setLinksAndLevel(_node, key) {
        // if node have no child, do not run the following
        if (!_node.childs || _node.childs.length === 0)
            return;
        this._dataMessagingInfo.count++;
        for (let i = 0; i < _node.childs.length; i++) {
            let linkString = '(' + key + ',' + _node.childs[i] + ')';
            if (!this._dataMessagingInfo.linksStored.hasOwnProperty(linkString)) {
                this._dataMessagingInfo.linksStored[linkString] = '';
                this._newLinks.push({ source: _node.index, target: this._nodesObj[_node.childs[i]].index });
            }
            if (this._nodesObj[_node.childs[i]].level > this._dataMessagingInfo.count)
                continue;
            if (this._dataMessagingInfo.count === 1) {
                this._nodesObj[_node.childs[i]].level = _node.level + 1 || 2;
                this._dataMessagingInfo.count = _node.level + 1 || 2;
            }
            else {
                this._nodesObj[_node.childs[i]].level = this._dataMessagingInfo.count;
                if (this._dataMessagingInfo.highestCount < this._dataMessagingInfo.count) {
                    this._dataMessagingInfo.highestCount = this._dataMessagingInfo.count;
                }
            }
            // if node have grandchild, continue the loop and set node of next cycle to be current node's child
            this._setLinksAndLevel(this._nodesObj[_node.childs[i]], _node.childs[i]);
        }
        this._dataMessagingInfo.count = 1;
    }
}
KdMindmapSvc.decorators = [
    { type: Injectable }
];
KdMindmapSvc.ctorParameters = () => [];
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoia2QtYW5ndWxhci1taW5kbWFwLXN2Yy5qcyIsInNvdXJjZVJvb3QiOiJDOi94YW1wcC9odGRvY3MvU3R5bGVndWlkZS9pb3N0Zy1vcGVuZW1pcy1zdHlsZWd1aWRlL3Byb2plY3RzL29wZW5lbWlzLXN0eWxlZ3VpZGUtbGliL3NyYy8iLCJzb3VyY2VzIjpbImtkLWNvbXBvbmVudHMva2QtYW5ndWxhci1taW5kbWFwL2tkLWFuZ3VsYXItbWluZG1hcC1zdmMudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsT0FBTyxFQUFFLFVBQVUsRUFBYyxNQUFNLGVBQWUsQ0FBQztBQUN2RCxPQUFPLEtBQUssRUFBRSxNQUFNLElBQUksQ0FBQztBQUN6QixPQUFPLEVBQUUsa0JBQWtCLEVBQUUsTUFBTSxrQ0FBa0MsQ0FBQztBQUN0RSxPQUFPLEVBQUUsU0FBUyxFQUFFLE1BQU0sc0NBQXNDLENBQUM7QUFTakUsTUFBTSxPQUFPLFlBQVk7SUFVckI7UUFSUSx1QkFBa0IsR0FBb0Y7WUFDMUcsWUFBWSxFQUFFLENBQUM7WUFDZixLQUFLLEVBQUUsQ0FBQztZQUNSLFdBQVcsRUFBRSxFQUFFO1NBQ2xCLENBQUM7UUFDTSxjQUFTLEdBQW9DLEVBQUUsQ0FBQztRQUNoRCxjQUFTLEdBQXdCLEVBQUUsQ0FBQztJQUU1QixDQUFDO0lBQ2pCOzs7OztPQUtHO0lBQ0ksdUJBQXVCLENBQUMsT0FBbUIsRUFBRSxJQUFrQixFQUFFLEtBQXlCO1FBQzdGLE1BQU0sU0FBUyxHQUFHLEVBQUUsQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDLENBQUM7UUFFckMsU0FBUyxPQUFPO1lBQ1osNkRBQTZEO1lBQzdELEVBQUUsQ0FBQyxLQUFLLENBQUMsV0FBVyxDQUFDLGVBQWUsRUFBRSxDQUFDO1lBRXZDLElBQUksQ0FBQyxFQUFFLENBQUMsS0FBSyxDQUFDLE1BQU0sRUFBRTtnQkFDbEIsS0FBSyxDQUFDLFVBQVUsQ0FBQyxXQUFXLENBQUMsR0FBRyxDQUFDLENBQUMsT0FBTyxFQUFFLENBQUM7YUFDL0M7WUFFRCxFQUFFLENBQUMsS0FBSyxDQUFDLEVBQUUsQ0FBQyxNQUFNLEVBQUUsT0FBTyxDQUFDLENBQUMsRUFBRSxDQUFDLEtBQUssRUFBRSxLQUFLLENBQUMsQ0FBQztZQUU5QyxTQUFTLE9BQU87Z0JBQ1osSUFBSSxDQUFDLEVBQUUsR0FBRyxFQUFFLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQztnQkFDckIsSUFBSSxDQUFDLEVBQUUsR0FBRyxFQUFFLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQztZQUN6QixDQUFDO1lBRUQsU0FBUyxLQUFLO2dCQUNWLElBQUksQ0FBQyxFQUFFLENBQUMsS0FBSyxDQUFDLE1BQU0sRUFBRTtvQkFDbEIsS0FBSyxDQUFDLFVBQVUsQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDLENBQUM7aUJBQ25DO2dCQUVELElBQUksQ0FBQyxFQUFFLEdBQUcsSUFBSSxDQUFDO2dCQUNmLElBQUksQ0FBQyxFQUFFLEdBQUcsSUFBSSxDQUFDO1lBQ25CLENBQUM7UUFDTCxDQUFDO1FBRUQsU0FBUyxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsSUFBSSxFQUFFO2FBQ25CLEVBQUUsQ0FBQyxPQUFPLEVBQUUsT0FBTyxDQUFDLENBQUMsQ0FBQztJQUMvQixDQUFDO0lBRUQ7Ozs7O09BS0c7SUFDSSxZQUFZLENBQUMsSUFBZ0IsRUFBRSxVQUF1QjtRQUN6RCxNQUFNLFNBQVMsR0FBRyxJQUFJLFNBQVMsQ0FBQyxJQUFJLEVBQUUsVUFBVSxDQUFDLENBQUM7UUFDbEQsT0FBTyxTQUFTLENBQUM7SUFDckIsQ0FBQztJQUVEOzs7Ozs7T0FNRztJQUNJLHFCQUFxQixDQUFDLEtBQXFCLEVBQUUsS0FBcUIsRUFBRSxPQUF3QjtRQUMvRixNQUFNLEVBQUUsR0FBRyxJQUFJLGtCQUFrQixDQUFDLEtBQUssRUFBRSxLQUFLLEVBQUUsT0FBTyxDQUFDLENBQUM7UUFDekQsT0FBTyxFQUFFLENBQUM7SUFDZCxDQUFDO0lBRUQ7Ozs7O09BS0c7SUFDSSxRQUFRLENBQUMsS0FBYSxFQUFFLE1BQWMsRUFBRSxPQUE0QjtRQUN2RSxJQUFJLFdBQVcsR0FBRyxFQUFFLENBQUMsTUFBTSxDQUFDLEdBQUcsR0FBRyxNQUFNLENBQUMsT0FBTyxDQUFDLElBQUksRUFBRSxHQUFHLENBQUMsQ0FBQyxFQUN4RCxLQUFLLEdBQUcsS0FBSyxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FBQyxPQUFPLEVBQUUsRUFDbEMsSUFBSSxFQUNKLElBQUksR0FBRyxFQUFFLEVBQ1QsVUFBVSxHQUFHLENBQUMsRUFDZCxVQUFVLEdBQUcsT0FBTyxDQUFDLFFBQVEsR0FBRyxDQUFDLEVBQUUsUUFBUTtRQUMzQyxDQUFDLEdBQUcsV0FBVyxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsRUFDekIsQ0FBQyxHQUFHLFdBQVcsQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLEVBQ3pCLEVBQUUsR0FBRyxVQUFVLENBQUMsV0FBVyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQyxFQUN2QyxLQUFLLEdBQUcsV0FBVyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDLENBQUMsSUFBSSxDQUFDLEdBQUcsRUFBRSxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsR0FBRyxFQUFFLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxJQUFJLEVBQUUsRUFBRSxDQUFDLENBQUM7UUFFNUYsT0FBTyxJQUFJLEdBQUcsS0FBSyxDQUFDLEdBQUcsRUFBRSxFQUFFO1lBQ3ZCLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUM7WUFDaEIsS0FBSyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUM7WUFDM0IsSUFBSSxLQUFLLENBQUMsSUFBSSxFQUFFLENBQUMscUJBQXFCLEVBQUUsR0FBRyxDQUFDLE9BQU8sQ0FBQyxLQUFLLEdBQUcsQ0FBQyxHQUFHLE9BQU8sQ0FBQyxXQUFXLENBQUMsRUFBRTtnQkFDbEYsSUFBSSxDQUFDLEdBQUcsRUFBRSxDQUFDO2dCQUNYLEtBQUssQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDO2dCQUMzQixJQUFJLEdBQUcsQ0FBQyxJQUFJLENBQUMsQ0FBQztnQkFDZCxLQUFLLEdBQUcsV0FBVyxDQUFDLE1BQU0sQ0FBQyxPQUFPLENBQUM7cUJBQzlCLElBQUksQ0FBQyxHQUFHLEVBQUUsQ0FBQyxDQUFDO3FCQUNaLElBQUksQ0FBQyxHQUFHLEVBQUUsQ0FBQyxDQUFDO3FCQUNaLElBQUksQ0FBQyxJQUFJLEVBQUUsRUFBRSxVQUFVLEdBQUcsVUFBVSxHQUFHLEVBQUUsQ0FBQztxQkFDMUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDO2FBQ25CO1NBQ0o7UUFDRCxPQUFPLENBQUMsVUFBVSxHQUFHLENBQUMsQ0FBQyxHQUFHLFVBQVUsR0FBRyxFQUFFLENBQUM7SUFDOUMsQ0FBQztJQUVEOzs7Ozs7O09BT0c7SUFDSSxxQkFBcUIsQ0FBQyxPQUE0QixFQUFFLEtBQWE7UUFDcEUsSUFBSSxLQUFLLEtBQUssT0FBTyxFQUFFO1lBQ25CLE9BQU8sT0FBTyxDQUFDLEtBQUssQ0FBQyxVQUFVLEdBQUcsT0FBTyxDQUFDLEtBQUssQ0FBQyxVQUFVLEdBQUcsT0FBTyxDQUFDLEtBQUssQ0FBQyxhQUFhLENBQUM7U0FDNUY7UUFDRCxJQUFJLEtBQUssS0FBSyxNQUFNLEVBQUU7WUFDbEIsT0FBTyxPQUFPLENBQUMsV0FBVyxDQUFDLFVBQVUsR0FBRyxPQUFPLENBQUMsS0FBSyxDQUFDLE1BQU0sR0FBRyxPQUFPLENBQUMsSUFBSSxDQUFDLElBQUksR0FBRyxPQUFPLENBQUMsSUFBSSxDQUFDLFlBQVksR0FBRyxPQUFPLENBQUMsSUFBSSxDQUFDLFNBQVMsR0FBRyxPQUFPLENBQUMsV0FBVyxDQUFDLFlBQVksR0FBRyxPQUFPLENBQUMsV0FBVyxDQUFDLFNBQVMsQ0FBQztTQUM1TTtJQUNMLENBQUM7SUFFRDs7OztPQUlHO0lBQ0ksT0FBTyxDQUFDLE1BQXVDO1FBTWxELElBQUksQ0FBQyxTQUFTLEdBQUcsRUFBRSxDQUFDO1FBQ3BCLElBQUksUUFBUSxHQUFHLEVBQUUsRUFBRSxLQUFLLEdBQUcsQ0FBQyxFQUFFLFNBQVMsR0FBRyxLQUFLLENBQUM7UUFFaEQsaURBQWlEO1FBQ2pELDhFQUE4RTtRQUM5RSxnR0FBZ0c7UUFDaEcsS0FBSyxJQUFJLEdBQUcsSUFBSSxNQUFNLEVBQUU7WUFDcEIsSUFBSSxNQUFNLENBQUMsY0FBYyxDQUFDLEdBQUcsQ0FBQyxFQUFFO2dCQUM1QixJQUFJLENBQUMsU0FBUyxDQUFDLEdBQUcsQ0FBQyxHQUFHLE1BQU0sQ0FBQyxNQUFNLENBQUMsRUFBRSxFQUFFLE1BQU0sQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDO2dCQUNyRCxJQUFJLENBQUMsU0FBUyxDQUFDLEdBQUcsQ0FBQyxDQUFDLEtBQUssR0FBRyxLQUFLLENBQUM7Z0JBQ2xDLFFBQVEsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDO2dCQUNuQyxLQUFLLEVBQUUsQ0FBQzthQUNYO1NBQ0o7UUFFRCxtR0FBbUc7UUFDbkcseUpBQXlKO1FBQ3pKLGtIQUFrSDtRQUNsSCxLQUFLLElBQUksR0FBRyxJQUFJLElBQUksQ0FBQyxTQUFTLEVBQUU7WUFDNUIsSUFBSSxPQUFPLElBQUksQ0FBQyxTQUFTLENBQUMsR0FBRyxDQUFDLENBQUMsT0FBTyxLQUFLLFdBQVcsSUFBSSxJQUFJLENBQUMsU0FBUyxDQUFDLEdBQUcsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxNQUFNLEtBQUssQ0FBQyxFQUFFO2dCQUNoRyxJQUFJLENBQUMsaUJBQWlCLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxHQUFHLENBQUMsRUFBRSxHQUFHLENBQUMsQ0FBQztnQkFFakQsbUVBQW1FO2dCQUNuRSxvQ0FBb0M7Z0JBQ3BDLElBQUksQ0FBQyxTQUFTLENBQUMsR0FBRyxDQUFDLENBQUMsS0FBSyxHQUFHLENBQUMsQ0FBQztnQkFDOUIsSUFBSSxPQUFPLElBQUksQ0FBQyxTQUFTLENBQUMsR0FBRyxDQUFDLENBQUMsTUFBTSxLQUFLLFdBQVcsSUFBSSxJQUFJLENBQUMsU0FBUyxDQUFDLEdBQUcsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxNQUFNLEtBQUssQ0FBQyxFQUFFO29CQUM5RixJQUFJLENBQUMsU0FBUyxDQUFDLEdBQUcsQ0FBQyxDQUFDLEtBQUssR0FBRyxDQUFDLENBQUM7b0JBQzlCLFNBQVMsR0FBRyxJQUFJLENBQUM7aUJBQ3BCO2FBQ0o7U0FDSjtRQUVELE9BQU87WUFDSCxLQUFLLEVBQUUsUUFBUTtZQUNmLEtBQUssRUFBRSxJQUFJLENBQUMsU0FBUztZQUNyQixZQUFZLEVBQUUsSUFBSSxDQUFDLGtCQUFrQixDQUFDLFlBQVk7WUFDbEQsU0FBUyxFQUFFLFNBQVM7U0FDdkIsQ0FBQztJQUNOLENBQUM7SUFFRDs7Ozs7O09BTUc7SUFDSSxLQUFLLENBQUMsTUFBMkIsRUFBRSxTQUFvQyxFQUFFLFVBQW1CO1FBQy9GLEtBQUssSUFBSSxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsR0FBRyxNQUFNLENBQUMsTUFBTSxFQUFFLEVBQUUsQ0FBQyxFQUFFO1lBQ3BDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLEdBQUcsVUFBVSxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssR0FBRyxDQUFDLENBQUMsQ0FBQztTQUMzRjtRQUNELE9BQU8sTUFBTSxDQUFDO0lBQ2xCLENBQUM7SUFFRDs7Ozs7O09BTUc7SUFDSSxrQkFBa0IsQ0FBQyxPQUFpRSxFQUFFLFlBQTBCLEVBQUUsVUFBdUM7UUFDNUosSUFBSSxJQUFJLEdBQVcsQ0FBQyxDQUFDO1FBQ3JCLElBQUksVUFBVSxLQUFLLE9BQU8sRUFBRTtZQUN4QixJQUFJLEdBQUcsT0FBTyxDQUFDLFFBQVEsQ0FBQztZQUN4QixPQUFPLElBQUksR0FBRyxZQUFZLENBQUMsRUFBRSxHQUFHLE9BQU8sQ0FBQyxTQUFTLEdBQUcsQ0FBQyxHQUFHLE9BQU8sQ0FBQyxPQUFPLENBQUM7U0FDM0U7UUFDRCxJQUFJLFVBQVUsS0FBSyxRQUFRLEVBQUU7WUFDekIsSUFBSSxHQUFHLE9BQU8sQ0FBQyxRQUFRLEdBQUcsQ0FBQyxDQUFDO1lBQzVCLE9BQU8sSUFBSSxHQUFHLFlBQVksQ0FBQyxFQUFFLENBQUM7U0FDakM7UUFDRCxJQUFJLFVBQVUsS0FBSyxNQUFNLEVBQUU7WUFDdkIsT0FBTyxDQUFFLFlBQVksQ0FBQyxFQUFFLEdBQUcsT0FBTyxDQUFDLFNBQVMsR0FBRyxDQUFDLEdBQUcsT0FBTyxDQUFDLE9BQU8sQ0FBQztTQUN0RTtJQUNMLENBQUM7SUFFRDs7Ozs7O09BTUc7SUFDSSxxQkFBcUIsQ0FBQyxNQUFrQixFQUFFLEtBQW1CLEVBQUUsV0FBbUI7UUFDckYsSUFBSSxXQUFXLEdBQVcsS0FBSyxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUM7UUFDL0MsSUFBSSxXQUFXLEtBQUssQ0FBQztZQUFFLE9BQU8sRUFBRSxDQUFDO1FBQ2pDLElBQUksSUFBSSxHQUFXLENBQUMsV0FBVyxHQUFHLEVBQUUsQ0FBQyxHQUFHLENBQUMsV0FBVyxHQUFHLENBQUMsQ0FBQyxDQUFDO1FBQzFELElBQUksYUFBYSxHQUFHLEVBQUUsQ0FBQztRQUV2QixLQUFLLElBQUksQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLEdBQUcsTUFBTSxDQUFDLE1BQU0sRUFBRSxFQUFFLENBQUMsRUFBRTtZQUNwQyxJQUFJLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsRUFBRSxLQUFLLEtBQUssQ0FBQyxFQUFFLEVBQUU7Z0JBQ2xDLGFBQWEsQ0FBQyxJQUFJLENBQUMsRUFBRSxLQUFLLEVBQUUsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssRUFBRSxDQUFDLENBQUM7YUFDbEQ7U0FDSjtRQUNELEtBQUssSUFBSSxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsR0FBRyxhQUFhLENBQUMsTUFBTSxFQUFFLEVBQUUsQ0FBQyxFQUFFO1lBQzNDLGFBQWEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLEdBQUcsQ0FBQyxXQUFXLEdBQUcsQ0FBQyxHQUFHLENBQUMsR0FBRyxJQUFJLEdBQUcsRUFBRSxDQUFDO1NBQzlEO1FBQ0QsT0FBTyxhQUFhLENBQUM7SUFDekIsQ0FBQztJQUVNLGlCQUFpQixDQUFDLE1BQXNCLEVBQUUsZUFBdUI7UUFDcEUsT0FBTyxNQUFNLENBQUMsZUFBZSxDQUFDLEtBQUssSUFBSSxJQUFJLE1BQU0sQ0FBQyxlQUFlLENBQUMsS0FBSyxTQUFTLENBQUM7SUFDckYsQ0FBQztJQUVEOzs7O09BSUc7SUFDSyxpQkFBaUIsQ0FBQyxLQUFtQixFQUFFLEdBQVc7UUFDdEQsa0RBQWtEO1FBQ2xELElBQUksQ0FBQyxLQUFLLENBQUMsTUFBTSxJQUFJLEtBQUssQ0FBQyxNQUFNLENBQUMsTUFBTSxLQUFLLENBQUM7WUFBRSxPQUFPO1FBQ3ZELElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxLQUFLLEVBQUUsQ0FBQztRQUVoQyxLQUFLLElBQUksQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLEdBQUcsS0FBSyxDQUFDLE1BQU0sQ0FBQyxNQUFNLEVBQUUsQ0FBQyxFQUFFLEVBQUU7WUFFMUMsSUFBSSxVQUFVLEdBQVcsR0FBRyxHQUFHLEdBQUcsR0FBRyxHQUFHLEdBQUcsS0FBSyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsR0FBRyxHQUFHLENBQUM7WUFDakUsSUFBSSxDQUFDLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxXQUFXLENBQUMsY0FBYyxDQUFDLFVBQVUsQ0FBQyxFQUFFO2dCQUNqRSxJQUFJLENBQUMsa0JBQWtCLENBQUMsV0FBVyxDQUFDLFVBQVUsQ0FBQyxHQUFHLEVBQUUsQ0FBQztnQkFDckQsSUFBSSxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsRUFBRSxNQUFNLEVBQUUsS0FBSyxDQUFDLEtBQUssRUFBRSxNQUFNLEVBQUUsSUFBSSxDQUFDLFNBQVMsQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxFQUFFLENBQUMsQ0FBQzthQUMvRjtZQUVELElBQUksSUFBSSxDQUFDLFNBQVMsQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxHQUFHLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxLQUFLO2dCQUFFLFNBQVM7WUFFcEYsSUFBSSxJQUFJLENBQUMsa0JBQWtCLENBQUMsS0FBSyxLQUFLLENBQUMsRUFBRTtnQkFDckMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxHQUFHLEtBQUssQ0FBQyxLQUFLLEdBQUcsQ0FBQyxJQUFJLENBQUMsQ0FBQztnQkFDN0QsSUFBSSxDQUFDLGtCQUFrQixDQUFDLEtBQUssR0FBRyxLQUFLLENBQUMsS0FBSyxHQUFHLENBQUMsSUFBSSxDQUFDLENBQUM7YUFDeEQ7aUJBQU07Z0JBQ0gsSUFBSSxDQUFDLFNBQVMsQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxHQUFHLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxLQUFLLENBQUM7Z0JBQ3RFLElBQUksSUFBSSxDQUFDLGtCQUFrQixDQUFDLFlBQVksR0FBRyxJQUFJLENBQUMsa0JBQWtCLENBQUMsS0FBSyxFQUFFO29CQUN0RSxJQUFJLENBQUMsa0JBQWtCLENBQUMsWUFBWSxHQUFHLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxLQUFLLENBQUM7aUJBQ3hFO2FBQ0o7WUFFRCxtR0FBbUc7WUFDbkcsSUFBSSxDQUFDLGlCQUFpQixDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLEtBQUssQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztTQUM1RTtRQUVELElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxLQUFLLEdBQUcsQ0FBQyxDQUFDO0lBQ3RDLENBQUM7OztZQW5SSixVQUFVIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgSW5qZWN0YWJsZSwgRWxlbWVudFJlZiB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xyXG5pbXBvcnQgKiBhcyBkMyBmcm9tICdkMyc7XHJcbmltcG9ydCB7IEZvcmNlRGlyZWN0ZWRHcmFwaCB9IGZyb20gJy4va2QtYW5ndWxhci1taW5kbWFwLWZvcmNlLWxvZ2ljJztcclxuaW1wb3J0IHsgWm9vbUNsYXNzIH0gZnJvbSAnLi96b29tL2tkLWFuZ3VsYXItbWluZG1hcC16b29tLWxvZ2ljJztcclxuaW1wb3J0IHsgXHJcbiAgICBJTWluZG1hcExpbmssIFxyXG4gICAgSU1pbmRtYXBOb2RlICwgXHJcbiAgICBJSW50ZXJuYWxOb2RlQ29uZmlnLCBcclxuICAgIElNaW5kbWFwT3B0aW9ucyBcclxufSBmcm9tICcuL2tkLWFuZ3VsYXItbWluZG1hcC1pbnRlcmZhY2UnO1xyXG5cclxuQEluamVjdGFibGUoKVxyXG5leHBvcnQgY2xhc3MgS2RNaW5kbWFwU3ZjIHtcclxuXHJcbiAgICBwcml2YXRlIF9kYXRhTWVzc2FnaW5nSW5mbzogeyBoaWdoZXN0Q291bnQ6IG51bWJlciwgY291bnQ6IG51bWJlciwgbGlua3NTdG9yZWQ6IHsgW2tleTogc3RyaW5nXTogc3RyaW5nIH0gfSA9IHtcclxuICAgICAgICBoaWdoZXN0Q291bnQ6IDEsXHJcbiAgICAgICAgY291bnQ6IDEsXHJcbiAgICAgICAgbGlua3NTdG9yZWQ6IHt9XHJcbiAgICB9O1xyXG4gICAgcHJpdmF0ZSBfbm9kZXNPYmo6IHsgW2tleTogc3RyaW5nXTogSU1pbmRtYXBOb2RlIH0gPSB7fTtcclxuICAgIHByaXZhdGUgX25ld0xpbmtzOiBBcnJheTxJTWluZG1hcExpbms+ID0gW107XHJcblxyXG4gICAgY29uc3RydWN0b3IoKSB7IH1cclxuICAgIC8qKlxyXG4gICAgICogQSBtZXRob2QgdG8gYmluZCBhIGRyYWdnYWJsZSBiZWhhdmlvdXIgdG8gYW4gc3ZnIGVsZW1lbnRcclxuICAgICAqICAgICAgICAgIGVsZW1lbnQgW2VsZW1lbnQgdG8gYXR0YWNoIGRyYWcgYmVoYXZpb3VyXVxyXG4gICAgICogICAgICAgIG5vZGUgICAgW25vZGUgaW5mb11cclxuICAgICAqICBncmFwaCAgIFtvYmplY3QgY29ubmVjdGluZyB0byBkMyBmb3JjZSBsb2dpY11cclxuICAgICAqL1xyXG4gICAgcHVibGljIGFwcGx5RHJhZ2dhYmxlQmVoYXZpb3VyKGVsZW1lbnQ6IEVsZW1lbnRSZWYsIG5vZGU6IElNaW5kbWFwTm9kZSwgZ3JhcGg6IEZvcmNlRGlyZWN0ZWRHcmFwaCk6IHZvaWQge1xyXG4gICAgICAgIGNvbnN0IGQzZWxlbWVudCA9IGQzLnNlbGVjdChlbGVtZW50KTtcclxuXHJcbiAgICAgICAgZnVuY3Rpb24gc3RhcnRlZCgpIHtcclxuICAgICAgICAgICAgLyoqIFByZXZlbnRpbmcgcHJvcGFnYXRpb24gb2YgZHJhZ3N0YXJ0IHRvIHBhcmVudCBlbGVtZW50cyAqL1xyXG4gICAgICAgICAgICBkMy5ldmVudC5zb3VyY2VFdmVudC5zdG9wUHJvcGFnYXRpb24oKTtcclxuXHJcbiAgICAgICAgICAgIGlmICghZDMuZXZlbnQuYWN0aXZlKSB7XHJcbiAgICAgICAgICAgICAgICBncmFwaC5zaW11bGF0aW9uLmFscGhhVGFyZ2V0KDAuMykucmVzdGFydCgpO1xyXG4gICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICBkMy5ldmVudC5vbignZHJhZycsIGRyYWdnZWQpLm9uKCdlbmQnLCBlbmRlZCk7XHJcblxyXG4gICAgICAgICAgICBmdW5jdGlvbiBkcmFnZ2VkKCkge1xyXG4gICAgICAgICAgICAgICAgbm9kZS5meCA9IGQzLmV2ZW50Lng7XHJcbiAgICAgICAgICAgICAgICBub2RlLmZ5ID0gZDMuZXZlbnQueTtcclxuICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgZnVuY3Rpb24gZW5kZWQoKSB7XHJcbiAgICAgICAgICAgICAgICBpZiAoIWQzLmV2ZW50LmFjdGl2ZSkge1xyXG4gICAgICAgICAgICAgICAgICAgIGdyYXBoLnNpbXVsYXRpb24uYWxwaGFUYXJnZXQoMCk7XHJcbiAgICAgICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICAgICAgbm9kZS5meCA9IG51bGw7XHJcbiAgICAgICAgICAgICAgICBub2RlLmZ5ID0gbnVsbDtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgZDNlbGVtZW50LmNhbGwoZDMuZHJhZygpXHJcbiAgICAgICAgICAgIC5vbignc3RhcnQnLCBzdGFydGVkKSk7XHJcbiAgICB9XHJcblxyXG4gICAgLyoqXHJcbiAgICAgKiBbZ2V0Wm9vbUNsYXNzIHJldHVybnMgdGhlIHpvb20gY2xhc3NdXHJcbiAgICAgKiAgIF9zdmcgICAgICAgW3RoZSBtYWluIHN2ZyBlbGVtZW50XVxyXG4gICAgICogIF9jb250YWluZXIgW3RoZSBnIHRhZyB0aGF0IGNvbnRhaW5zIHRoZSBub2RlcyBhbmQgbGlua3NdXHJcbiAgICAgKiAgICAgICAgICAgICAgIFt6b29tIGNsYXNzIGNvbnRhaW5zIGQzIGNvZGVzIGFuZCBzdG9yZXMgdGhlIF9zdmcgYW5kIF9jb250YWluZXIgdmFyaWFibGVzIGZvciBkMyB6b29taW5nXVxyXG4gICAgICovXHJcbiAgICBwdWJsaWMgZ2V0Wm9vbUNsYXNzKF9zdmc6IEVsZW1lbnRSZWYsIF9jb250YWluZXI6IEhUTUxFbGVtZW50KTogWm9vbUNsYXNzIHtcclxuICAgICAgICBjb25zdCB6b29tQ2xhc3MgPSBuZXcgWm9vbUNsYXNzKF9zdmcsIF9jb250YWluZXIpO1xyXG4gICAgICAgIHJldHVybiB6b29tQ2xhc3M7XHJcbiAgICB9XHJcblxyXG4gICAgLyoqXHJcbiAgICAgKiBbZ2V0Rm9yY2VEaXJlY3RlZEdyYXBoIFRoZSBpbnRlcmFjdGFibGUgZ3JhcGggd2Ugd2lsbCBzaW11bGF0ZSBpbiB0aGlzIGFydGljbGUuIFRoaXMgbWV0aG9kIGRvZXMgbm90IGludGVyYWN0IHdpdGggdGhlIGRvY3VtZW50LCBwdXJlbHkgcGh5c2ljYWwgY2FsY3VsYXRpb25zIHdpdGggZDNdXHJcbiAgICAgKiAgICAgIG5vZGVzICAgW2Rlc2NyaXB0aW9uXVxyXG4gICAgICogICAgICBsaW5rcyAgIFtkZXNjcmlwdGlvbl1cclxuICAgICAqICAgICBvcHRpb25zIFtjb250YWlucyBpbmZvIG9mIHdpZHRoLCBoZWlnaHQgb2YgbWFpbiBzdmcgY29udGFpbmVyIGFuZCBsZXZlbFBvc2l0aW9uXVxyXG4gICAgICogICAgICAgICAgW0ZvcmNlRGlyZWN0ZWRHcmFwaCBjbGFzc11cclxuICAgICAqL1xyXG4gICAgcHVibGljIGdldEZvcmNlRGlyZWN0ZWRHcmFwaChub2RlczogSU1pbmRtYXBOb2RlW10sIGxpbmtzOiBJTWluZG1hcExpbmtbXSwgb3B0aW9uczogSU1pbmRtYXBPcHRpb25zKTogRm9yY2VEaXJlY3RlZEdyYXBoIHtcclxuICAgICAgICBjb25zdCBzZyA9IG5ldyBGb3JjZURpcmVjdGVkR3JhcGgobm9kZXMsIGxpbmtzLCBvcHRpb25zKTtcclxuICAgICAgICByZXR1cm4gc2c7XHJcbiAgICB9XHJcblxyXG4gICAgLyoqXHJcbiAgICAgKiB0ZXh0V3JhcCBoYW5kbGVzIHRleHQgd3JhcHBpbmcgaW4gc3ZnXHJcbiAgICAgKiAgX3RleHQgICB0ZXh0IHRvIGRpc3BsYXlcclxuICAgICAqICAgICBfY29uZmlnIFtkZXNjcmlwdGlvbl1cclxuICAgICAqICAgICAgICAgIHRvdGFsIHRleHQgaGVpZ2h0XHJcbiAgICAgKi9cclxuICAgIHB1YmxpYyB0ZXh0V3JhcChfdGV4dDogc3RyaW5nLCBfY2xhc3M6IHN0cmluZywgX2NvbmZpZzogSUludGVybmFsTm9kZUNvbmZpZyk6IG51bWJlciB7XHJcbiAgICAgICAgbGV0IHRleHRFbGVtZW50ID0gZDMuc2VsZWN0KCcuJyArIF9jbGFzcy5yZXBsYWNlKC8gL2csICcuJykpLFxyXG4gICAgICAgICAgICB3b3JkcyA9IF90ZXh0LnNwbGl0KCcgJykucmV2ZXJzZSgpLFxyXG4gICAgICAgICAgICB3b3JkLFxyXG4gICAgICAgICAgICBsaW5lID0gW10sXHJcbiAgICAgICAgICAgIGxpbmVOdW1iZXIgPSAwLFxyXG4gICAgICAgICAgICBsaW5lSGVpZ2h0ID0gX2NvbmZpZy5mb250U2l6ZSArIDIsIC8vIGluIHB4XHJcbiAgICAgICAgICAgIHkgPSB0ZXh0RWxlbWVudC5hdHRyKCd5JyksXHJcbiAgICAgICAgICAgIHggPSB0ZXh0RWxlbWVudC5hdHRyKCd4JyksXHJcbiAgICAgICAgICAgIGR5ID0gcGFyc2VGbG9hdCh0ZXh0RWxlbWVudC5hdHRyKCdkeScpKSxcclxuICAgICAgICAgICAgdHNwYW4gPSB0ZXh0RWxlbWVudC50ZXh0KG51bGwpLmFwcGVuZCgndHNwYW4nKS5hdHRyKCd4JywgeCkuYXR0cigneScsIHkpLmF0dHIoJ2R5JywgZHkpO1xyXG5cclxuICAgICAgICB3aGlsZSAod29yZCA9IHdvcmRzLnBvcCgpKSB7XHJcbiAgICAgICAgICAgIGxpbmUucHVzaCh3b3JkKTtcclxuICAgICAgICAgICAgdHNwYW4udGV4dChsaW5lLmpvaW4oJyAnKSk7XHJcbiAgICAgICAgICAgIGlmICh0c3Bhbi5ub2RlKCkuZ2V0Q29tcHV0ZWRUZXh0TGVuZ3RoKCkgPiAoX2NvbmZpZy53aWR0aCAtIDIgKiBfY29uZmlnLnRleHRQYWRkaW5nKSkge1xyXG4gICAgICAgICAgICAgICAgbGluZS5wb3AoKTtcclxuICAgICAgICAgICAgICAgIHRzcGFuLnRleHQobGluZS5qb2luKCcgJykpO1xyXG4gICAgICAgICAgICAgICAgbGluZSA9IFt3b3JkXTtcclxuICAgICAgICAgICAgICAgIHRzcGFuID0gdGV4dEVsZW1lbnQuYXBwZW5kKCd0c3BhbicpXHJcbiAgICAgICAgICAgICAgICAgICAgLmF0dHIoJ3gnLCB4KVxyXG4gICAgICAgICAgICAgICAgICAgIC5hdHRyKCd5JywgeSlcclxuICAgICAgICAgICAgICAgICAgICAuYXR0cignZHknLCArK2xpbmVOdW1iZXIgKiBsaW5lSGVpZ2h0ICsgZHkpXHJcbiAgICAgICAgICAgICAgICAgICAgLnRleHQod29yZCk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICAgICAgcmV0dXJuIChsaW5lTnVtYmVyICsgMSkgKiBsaW5lSGVpZ2h0ICsgZHk7XHJcbiAgICB9XHJcblxyXG4gICAgLyoqXHJcbiAgICAgKiBbc2V0IGhlaWdodCBvZiBub2RlJ3MgdGl0bGUgd3JhcHBlciBhbmQgbm9kZSB3cmFwcGVyJ3MgaGVpZ2h0LlxyXG4gICAgICogIE5vdGU6IHRpdGxlJ3MgaGVpZ2h0IGhhdmUgdG8gYmUgY2FsY3VsYXRlZCBhbmQgdXBkYXRlZCB0byBodG1sIGZpcnN0XHJcbiAgICAgKiAgYmVmb3JlIGFwcGVuZGluZyB0aGUgZGVzY3JpcHRpb24gdGV4dF1cclxuICAgICAqICBfY29uZmlnIFtub2RlJ3MgQ29uZmlnXVxyXG4gICAgICogICAgICAgICAgICAgICBfdHlwZSAgIFtmb3IgdGl0bGUgb3Igbm9kZV1cclxuICAgICAqICAgICAgICAgICAgICAgICAgICAgICBbaGVpZ2h0IG9mIHRpdGxlIG9yIG5vZGVdXHJcbiAgICAgKi9cclxuICAgIHB1YmxpYyBzZXRTVkdDb250YWluZXJIZWlnaHQoX2NvbmZpZzogSUludGVybmFsTm9kZUNvbmZpZywgX3R5cGU6IHN0cmluZyk6IG51bWJlciB7XHJcbiAgICAgICAgaWYgKF90eXBlID09PSAndGl0bGUnKSB7XHJcbiAgICAgICAgICAgIHJldHVybiBfY29uZmlnLnRpdGxlLnRleHRIZWlnaHQgKyBfY29uZmlnLnRpdGxlLnBhZGRpbmdUb3AgKyBfY29uZmlnLnRpdGxlLnBhZGRpbmdCb3R0b207XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGlmIChfdHlwZSA9PT0gJ25vZGUnKSB7XHJcbiAgICAgICAgICAgIHJldHVybiBfY29uZmlnLmRlc2NyaXB0aW9uLnRleHRIZWlnaHQgKyBfY29uZmlnLnRpdGxlLmhlaWdodCArIF9jb25maWcuaWNvbi5zaXplICsgX2NvbmZpZy5pY29uLm1hcmdpbkJvdHRvbSArIF9jb25maWcuaWNvbi5tYXJnaW5Ub3AgKyBfY29uZmlnLmRlc2NyaXB0aW9uLm1hcmdpbkJvdHRvbSArIF9jb25maWcuZGVzY3JpcHRpb24ubWFyZ2luVG9wO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICAvKipcclxuICAgICAqIFtzZXREYXRhIGFwcGVuZGluZyBpbmRleCwgcHVzaGluZyBub2RlcyB0byBBcnJheSBmb3IgZDMsIGNhbGxpbmcgcmVjdXJzaXZlIGxvb3AgdGhpcy5fc2V0TGlua3NBbmRMZXZlbF1cclxuICAgICAqIH0gX25vZGVzIFtkZXNjcmlwdGlvbl1cclxuICAgICAqICAgW2hlaWdodCBvZiB0aXRsZSBvciBub2RlXVxyXG4gICAgICovXHJcbiAgICBwdWJsaWMgc2V0RGF0YShfbm9kZXM6IHsgW2tleTogc3RyaW5nXTogSU1pbmRtYXBOb2RlIH0pOiB7XHJcbiAgICAgICAgbm9kZXM6IEFycmF5PElNaW5kbWFwTm9kZT4sXHJcbiAgICAgICAgbGlua3M6IEFycmF5PElNaW5kbWFwTGluaz4sXHJcbiAgICAgICAgaGlnaGVzdENvdW50OiBudW1iZXIsXHJcbiAgICAgICAgaGF2ZUxvbmVyOiBib29sZWFuXHJcbiAgICB9IHtcclxuICAgICAgICB0aGlzLl9ub2Rlc09iaiA9IHt9O1xyXG4gICAgICAgIGxldCBuZXdOb2RlcyA9IFtdLCBpbmRleCA9IDAsIGhhdmVMb25lciA9IGZhbHNlO1xyXG5cclxuICAgICAgICAvLyBhcHBlbmRpbmcgYSBuZXcga2V5IGNhbGxlZCBpbmRleCB0byBlYWNoIG5vZGUuXHJcbiAgICAgICAgLy8gZDMgdjQgcmVxdWlyZXMgbGluayBzb3VyY2UgYW5kIHRhcmdldCB0byBwb2ludCB0byBpbmRleCBvZiBub2RlIGluIG5vZGVBcnIuXHJcbiAgICAgICAgLy8gSGVuY2UgdGhlIGJlbG93IGZvciBsb29wIHdpbGwgKDEpIGNyZWF0ZSBhIGNsZWFuIGNvcHkgb2Ygb2JqZWN0ICgyKSBhcHBlbmQgaW5kZXggdG8gZWFjaCBub2RlXHJcbiAgICAgICAgZm9yIChsZXQga2V5IGluIF9ub2Rlcykge1xyXG4gICAgICAgICAgICBpZiAoX25vZGVzLmhhc093blByb3BlcnR5KGtleSkpIHtcclxuICAgICAgICAgICAgICAgIHRoaXMuX25vZGVzT2JqW2tleV0gPSBPYmplY3QuYXNzaWduKHt9LCBfbm9kZXNba2V5XSk7XHJcbiAgICAgICAgICAgICAgICB0aGlzLl9ub2Rlc09ialtrZXldLmluZGV4ID0gaW5kZXg7XHJcbiAgICAgICAgICAgICAgICBuZXdOb2Rlcy5wdXNoKHRoaXMuX25vZGVzT2JqW2tleV0pO1xyXG4gICAgICAgICAgICAgICAgaW5kZXgrKztcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgLy8gdGhpcyBmb3IgbG9vcCB3aWxsIGxvb2sgZm9yIE9OTFkgbm9kZXMgdGhhdCBoYXZlIG5vIHBhcmVudHMgKGllLiBhbmNlc3RvciBub2RlcyBhbmQgbG9uZXIgbm9kZXMpXHJcbiAgICAgICAgLy8gdXNpbmcgdGhlc2Ugbm9kZXMgYXMgc3RhcnRpbmcgcG9pbnRzLCB3ZSBzdGFydCAnd2Fsa2luZyB0aGUgYnJhbmNoJyB2aWEgdGhpcy5fc2V0TGlua3NBbmRMZXZlbCB0byB1cGRhdGUgdGhlIGxpbmtzIHdpdGggdGhlIHJlbGF0aW9uc2hpcHMgb2YgdGhlIG5vZGVzXHJcbiAgICAgICAgLy8gYXQgdGhpcyBzdGFnZSwgaW5kZXggb2YgYWxsIG5vZGVzIG11c3QgYmUgZGVmaW5lZCB3aXRoaW4gdGhlIG5vZGUgb2JqIHNvIHRoYXQgdGhlIGxpbmtzIGNhbiBiZSBzZXQgdXAgY29ycmVjdGx5XHJcbiAgICAgICAgZm9yIChsZXQga2V5IGluIHRoaXMuX25vZGVzT2JqKSB7XHJcbiAgICAgICAgICAgIGlmICh0eXBlb2YgdGhpcy5fbm9kZXNPYmpba2V5XS5wYXJlbnRzID09PSAndW5kZWZpbmVkJyB8fCB0aGlzLl9ub2Rlc09ialtrZXldLnBhcmVudHMubGVuZ3RoID09PSAwKSB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLl9zZXRMaW5rc0FuZExldmVsKHRoaXMuX25vZGVzT2JqW2tleV0sIGtleSk7XHJcblxyXG4gICAgICAgICAgICAgICAgLy8gdGhpcy5fc2V0TGlua3NBbmRMZXZlbCBkaWQgbm90IHNldCBsZXZlbCBvZiB0aGVzZSBzdGFydGluZyBub2Rlc1xyXG4gICAgICAgICAgICAgICAgLy8gbWFudWFsbHkgc2V0dGluZyB0aGVpciBsZXZlbHMgbm93XHJcbiAgICAgICAgICAgICAgICB0aGlzLl9ub2Rlc09ialtrZXldLmxldmVsID0gMTtcclxuICAgICAgICAgICAgICAgIGlmICh0eXBlb2YgdGhpcy5fbm9kZXNPYmpba2V5XS5jaGlsZHMgPT09ICd1bmRlZmluZWQnIHx8IHRoaXMuX25vZGVzT2JqW2tleV0uY2hpbGRzLmxlbmd0aCA9PT0gMCkge1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuX25vZGVzT2JqW2tleV0ubGV2ZWwgPSAwO1xyXG4gICAgICAgICAgICAgICAgICAgIGhhdmVMb25lciA9IHRydWU7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIHJldHVybiB7XHJcbiAgICAgICAgICAgIG5vZGVzOiBuZXdOb2RlcyxcclxuICAgICAgICAgICAgbGlua3M6IHRoaXMuX25ld0xpbmtzLFxyXG4gICAgICAgICAgICBoaWdoZXN0Q291bnQ6IHRoaXMuX2RhdGFNZXNzYWdpbmdJbmZvLmhpZ2hlc3RDb3VudCxcclxuICAgICAgICAgICAgaGF2ZUxvbmVyOiBoYXZlTG9uZXJcclxuICAgICAgICB9O1xyXG4gICAgfVxyXG5cclxuICAgIC8qKlxyXG4gICAgICogW3NldEZ4IHdpbGwgc2V0IGZ4IGNvb3JkaW5hdGUgb2YgZWFjaCBub2RlXVxyXG4gICAgICogICAgICAgICBfbm9kZXNcclxuICAgICAqIH0gICBwb3NpdGlvbiAgICAgIFtmeCBjb29yZGluYXRlIG9mIGVhY2ggbGV2ZWxdXHJcbiAgICAgKiAgICAgICAgICAgICAgICAgICAgX2hhdmVMb25lciAgICAgW3doZXRoZXIgdGhlcmUgZXhpc3QgbG9uZXIgaW4gdGhlIGdyYXBoXVxyXG4gICAgICogICAgICAgIF9ub2RlcyAgICAgICAgW25vZGVzIHdpdGggZnggdmFsdWVdXHJcbiAgICAgKi9cclxuICAgIHB1YmxpYyBzZXRGeChfbm9kZXM6IEFycmF5PElNaW5kbWFwTm9kZT4sIF9wb3NpdGlvbjogeyBba2V5OiBzdHJpbmddOiBudW1iZXIgfSwgX2hhdmVMb25lcjogYm9vbGVhbik6IEFycmF5PElNaW5kbWFwTm9kZT4ge1xyXG4gICAgICAgIGZvciAobGV0IGkgPSAwOyBpIDwgX25vZGVzLmxlbmd0aDsgKytpKSB7XHJcbiAgICAgICAgICAgIF9ub2Rlc1tpXS5meCA9IF9oYXZlTG9uZXIgPyBfcG9zaXRpb25bX25vZGVzW2ldLmxldmVsXSA6IF9wb3NpdGlvbltfbm9kZXNbaV0ubGV2ZWwgLSAxXTtcclxuICAgICAgICB9XHJcbiAgICAgICAgcmV0dXJuIF9ub2RlcztcclxuICAgIH1cclxuXHJcbiAgICAvKipcclxuICAgICAqIFt0cmFuc2xhdGVTdmdUb1hQb3MgdHJhbnNsYXRlIG5vZGUgdG8gY2VudGVyLCByaWdodCBlZGdlIG9yIGxlZnQgZWRnZSBvZiBtYWluIHN2ZyBjb250YWluZXJdXHJcbiAgICAgKiB9ICAgX2NvbmZpZyAgICAgIFt3aWR0aHMgb2YgbWFpbiBzdmcsIG5vZGUgYW5kIHBhZGRpbmddXHJcbiAgICAgKiAgX25vZGVUb0ZvY3VzXHJcbiAgICAgKiAgX3BsYWNlbWVudFxyXG4gICAgICogICAgICAgICAgICAgICAgICAgICBbeC1jb29yZGluYXRlIGZvciBdXHJcbiAgICAgKi9cclxuICAgIHB1YmxpYyB0cmFuc2xhdGVTdmdUb1hQb3MoX2NvbmZpZzogeyBzdmdXaWR0aDogbnVtYmVyLCBub2RlV2lkdGg6IG51bWJlciwgcGFkZGluZzogbnVtYmVyIH0sIF9ub2RlVG9Gb2N1czogSU1pbmRtYXBOb2RlLCBfcGxhY2VtZW50OiAnY2VudGVyJyB8ICdyaWdodCcgfCAnbGVmdCcpOiBudW1iZXIge1xyXG4gICAgICAgIGxldCB4UG9zOiBudW1iZXIgPSAwO1xyXG4gICAgICAgIGlmIChfcGxhY2VtZW50ID09PSAncmlnaHQnKSB7XHJcbiAgICAgICAgICAgIHhQb3MgPSBfY29uZmlnLnN2Z1dpZHRoO1xyXG4gICAgICAgICAgICByZXR1cm4geFBvcyAtIF9ub2RlVG9Gb2N1cy5meCAtIF9jb25maWcubm9kZVdpZHRoIC8gMiAtIF9jb25maWcucGFkZGluZztcclxuICAgICAgICB9XHJcbiAgICAgICAgaWYgKF9wbGFjZW1lbnQgPT09ICdjZW50ZXInKSB7XHJcbiAgICAgICAgICAgIHhQb3MgPSBfY29uZmlnLnN2Z1dpZHRoIC8gMjtcclxuICAgICAgICAgICAgcmV0dXJuIHhQb3MgLSBfbm9kZVRvRm9jdXMuZng7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGlmIChfcGxhY2VtZW50ID09PSAnbGVmdCcpIHtcclxuICAgICAgICAgICAgcmV0dXJuIC0gX25vZGVUb0ZvY3VzLmZ4ICsgX2NvbmZpZy5ub2RlV2lkdGggLyAyICsgX2NvbmZpZy5wYWRkaW5nO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICAvKipcclxuICAgICAqIFtzZXRMaW5rU3ByZWFkRGlzdGFuY2UgY2FsY3VsYXRlIG9mZnNldCBuZWVkZWQgZm9yIGxpbmtzIHRvIHNwcmVhZCBldmVubHkgYWNyb3NzIGhlaWdodCBvZiBub2RlXVxyXG4gICAgICogICAgX2xpbmtzXHJcbiAgICAgKiAgX25vZGUgICAgICAgW25vZGUgdGhhdCBoYXZlIGZpbmlzaGVkIGhlaWdodCBjYWxjdWxhdGlvbi4gKHRoZXNlIG5vZGVzIG11c3QgaGF2ZSBwYXJlbnRzKV1cclxuICAgICAqICAgICAgICBfbm9kZUhlaWdodCBbSGVpZ2h0IG9mIG5vZGVdXHJcbiAgICAgKiAgICAgICAgICAgICAgICAgICAgIFtyZXR1cm4gaW5kZXggb2YgbGluayBhbmQgb2Zmc2V0IHZhbHVlXVxyXG4gICAgICovXHJcbiAgICBwdWJsaWMgc2V0TGlua1NwcmVhZERpc3RhbmNlKF9saW5rczogQXJyYXk8YW55PiwgX25vZGU6IElNaW5kbWFwTm9kZSwgX25vZGVIZWlnaHQ6IG51bWJlcik6IEFycmF5PHsgaW5kZXg/OiBudW1iZXIsIG9mZnNldD86IG51bWJlciB9PiB7XHJcbiAgICAgICAgbGV0IG5vT2ZQYXJlbnRzOiBudW1iZXIgPSBfbm9kZS5wYXJlbnRzLmxlbmd0aDtcclxuICAgICAgICBpZiAobm9PZlBhcmVudHMgPT09IDEpIHJldHVybiBbXTtcclxuICAgICAgICBsZXQgZGlzdDogbnVtYmVyID0gKF9ub2RlSGVpZ2h0IC0gMjApIC8gKG5vT2ZQYXJlbnRzIC0gMSk7XHJcbiAgICAgICAgbGV0IGFmZmVjdGVkTGlua3MgPSBbXTtcclxuXHJcbiAgICAgICAgZm9yIChsZXQgaSA9IDA7IGkgPCBfbGlua3MubGVuZ3RoOyArK2kpIHtcclxuICAgICAgICAgICAgaWYgKF9saW5rc1tpXS50YXJnZXQuaWQgPT09IF9ub2RlLmlkKSB7XHJcbiAgICAgICAgICAgICAgICBhZmZlY3RlZExpbmtzLnB1c2goeyBpbmRleDogX2xpbmtzW2ldLmluZGV4IH0pO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGZvciAobGV0IGkgPSAwOyBpIDwgYWZmZWN0ZWRMaW5rcy5sZW5ndGg7ICsraSkge1xyXG4gICAgICAgICAgICBhZmZlY3RlZExpbmtzW2ldLm9mZnNldCA9IC1fbm9kZUhlaWdodCAvIDIgKyBpICogZGlzdCArIDEwO1xyXG4gICAgICAgIH1cclxuICAgICAgICByZXR1cm4gYWZmZWN0ZWRMaW5rcztcclxuICAgIH1cclxuXHJcbiAgICBwdWJsaWMgZm91bmRTZWxlY3RlZE5vZGUoX25vZGVzOiBJTWluZG1hcE5vZGVbXSwgX3NlbGVjdE9uTG9hZElkOiBudW1iZXIpIHtcclxuICAgICAgICByZXR1cm4gX25vZGVzW19zZWxlY3RPbkxvYWRJZF0gIT09IG51bGwgJiYgX25vZGVzW19zZWxlY3RPbkxvYWRJZF0gIT09IHVuZGVmaW5lZDtcclxuICAgIH1cclxuXHJcbiAgICAvKipcclxuICAgICAqIFtfc2V0TGlua3NBbmRMZXZlbCBpcyB0byBnZW5lcmF0ZSB0aGUgbGV2ZWwsIGxldmVsJ3MgcmVjb3JkIGhpZ2hlc3RDb3VudCwgbGlua3MgQXJyYXksIHBhcmVudHMgYXJyYXldXHJcbiAgICAgKiAgX25vZGUgW09iamVjdCBjb250YWluaW5nIGFsbCBpbmZvIG9mIGEgbm9kZSwgdG8gYmUgcGFzc2VkIHRvIGNvbXBvbmVudCBrZC1taW5kbWFwLW5vZGVdXHJcbiAgICAgKiAgICAgICAga2V5ICAgW2tleSBvZiB0aGUgbm9kZSBvYmplY3QgaW4gdGhlIG1hc3RlciBvYmplY3RdXHJcbiAgICAgKi9cclxuICAgIHByaXZhdGUgX3NldExpbmtzQW5kTGV2ZWwoX25vZGU6IElNaW5kbWFwTm9kZSwga2V5OiBzdHJpbmcpOiB2b2lkIHtcclxuICAgICAgICAvLyBpZiBub2RlIGhhdmUgbm8gY2hpbGQsIGRvIG5vdCBydW4gdGhlIGZvbGxvd2luZ1xyXG4gICAgICAgIGlmICghX25vZGUuY2hpbGRzIHx8IF9ub2RlLmNoaWxkcy5sZW5ndGggPT09IDApIHJldHVybjtcclxuICAgICAgICB0aGlzLl9kYXRhTWVzc2FnaW5nSW5mby5jb3VudCsrO1xyXG5cclxuICAgICAgICBmb3IgKGxldCBpID0gMDsgaSA8IF9ub2RlLmNoaWxkcy5sZW5ndGg7IGkrKykge1xyXG5cclxuICAgICAgICAgICAgbGV0IGxpbmtTdHJpbmc6IHN0cmluZyA9ICcoJyArIGtleSArICcsJyArIF9ub2RlLmNoaWxkc1tpXSArICcpJztcclxuICAgICAgICAgICAgaWYgKCF0aGlzLl9kYXRhTWVzc2FnaW5nSW5mby5saW5rc1N0b3JlZC5oYXNPd25Qcm9wZXJ0eShsaW5rU3RyaW5nKSkge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5fZGF0YU1lc3NhZ2luZ0luZm8ubGlua3NTdG9yZWRbbGlua1N0cmluZ10gPSAnJztcclxuICAgICAgICAgICAgICAgIHRoaXMuX25ld0xpbmtzLnB1c2goeyBzb3VyY2U6IF9ub2RlLmluZGV4LCB0YXJnZXQ6IHRoaXMuX25vZGVzT2JqW19ub2RlLmNoaWxkc1tpXV0uaW5kZXggfSk7XHJcbiAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgIGlmICh0aGlzLl9ub2Rlc09ialtfbm9kZS5jaGlsZHNbaV1dLmxldmVsID4gdGhpcy5fZGF0YU1lc3NhZ2luZ0luZm8uY291bnQpIGNvbnRpbnVlO1xyXG5cclxuICAgICAgICAgICAgaWYgKHRoaXMuX2RhdGFNZXNzYWdpbmdJbmZvLmNvdW50ID09PSAxKSB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLl9ub2Rlc09ialtfbm9kZS5jaGlsZHNbaV1dLmxldmVsID0gX25vZGUubGV2ZWwgKyAxIHx8IDI7XHJcbiAgICAgICAgICAgICAgICB0aGlzLl9kYXRhTWVzc2FnaW5nSW5mby5jb3VudCA9IF9ub2RlLmxldmVsICsgMSB8fCAyO1xyXG4gICAgICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5fbm9kZXNPYmpbX25vZGUuY2hpbGRzW2ldXS5sZXZlbCA9IHRoaXMuX2RhdGFNZXNzYWdpbmdJbmZvLmNvdW50O1xyXG4gICAgICAgICAgICAgICAgaWYgKHRoaXMuX2RhdGFNZXNzYWdpbmdJbmZvLmhpZ2hlc3RDb3VudCA8IHRoaXMuX2RhdGFNZXNzYWdpbmdJbmZvLmNvdW50KSB7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5fZGF0YU1lc3NhZ2luZ0luZm8uaGlnaGVzdENvdW50ID0gdGhpcy5fZGF0YU1lc3NhZ2luZ0luZm8uY291bnQ7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgIC8vIGlmIG5vZGUgaGF2ZSBncmFuZGNoaWxkLCBjb250aW51ZSB0aGUgbG9vcCBhbmQgc2V0IG5vZGUgb2YgbmV4dCBjeWNsZSB0byBiZSBjdXJyZW50IG5vZGUncyBjaGlsZFxyXG4gICAgICAgICAgICB0aGlzLl9zZXRMaW5rc0FuZExldmVsKHRoaXMuX25vZGVzT2JqW19ub2RlLmNoaWxkc1tpXV0sIF9ub2RlLmNoaWxkc1tpXSk7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICB0aGlzLl9kYXRhTWVzc2FnaW5nSW5mby5jb3VudCA9IDE7XHJcbiAgICB9XHJcbn1cclxuIl19