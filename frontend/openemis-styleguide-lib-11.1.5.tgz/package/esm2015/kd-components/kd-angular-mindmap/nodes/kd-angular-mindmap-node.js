import { Component, Input, Output, ViewEncapsulation, ElementRef, EventEmitter } from '@angular/core';
import { KdDomElemSvc } from '../../kd-common/index';
import { KdMindmapSvc } from '../kd-angular-mindmap-svc';
import { KdMindmapEvent } from '../kd-angular-mindmap-event';
export class KdMindmapNode {
    constructor(_mindmapSvc, _mindmapEvent, _elemRef, _domSvc) {
        this._mindmapSvc = _mindmapSvc;
        this._mindmapEvent = _mindmapEvent;
        this._elemRef = _elemRef;
        this._domSvc = _domSvc;
        this.config = {};
        this._nodeActive = false;
        this.selectedNodeEmitter = new EventEmitter();
    }
    ngOnInit() {
        this._setConfig(this.nodeConfig, this.node);
        this._setActiveNode();
        this._nodeSelectedSub = this._mindmapEvent
            .onNodeSelected(this.mindmapId)
            .subscribe((_node) => this._clearNodeSelection(_node));
    }
    ngAfterViewInit() {
        setTimeout(() => this._setHeight());
    }
    ngOnChanges(_simpleChanges) {
        if ((_simpleChanges.hasOwnProperty('node') && !_simpleChanges['node'].firstChange) ||
            (_simpleChanges.hasOwnProperty('nodeConfig') && !_simpleChanges['nodeConfig'].firstChange)) {
            this._setConfig(this.nodeConfig, this.node);
            this._setActiveNode();
        }
    }
    ngOnDestroy() {
        this._nodeSelectedSub.unsubscribe();
    }
    onClick() {
        this._nodeSelected();
    }
    _nodeSelected() {
        if (this._nodeActive)
            return;
        this._domSvc.addClass(this._elemRef.nativeElement, this.config.activeClass);
        this._mindmapEvent.nodeSelected(this.mindmapId, this.node);
        this.selectedNodeEmitter.emit(this.node);
        this._nodeActive = true;
    }
    _clearNodeSelection(_nodeToClear) {
        if (this._nodeActive) {
            this._domSvc.removeClass(this._elemRef.nativeElement, this.config.activeClass);
            this._nodeActive = false;
        }
    }
    _setConfig(_config, _node) {
        this.config = Object.assign({}, _config);
        this.config.icon = Object.assign({}, _config.icon);
        this.config.title = Object.assign({}, _config.title);
        this.config.description = Object.assign({}, _config.description);
        if (this.config.class)
            this._domSvc.addClass(this._elemRef.nativeElement, this.config.class);
        this.config.title.textClass += ' ' + 'node-' + _node.index;
        this.config.description.textClass += ' ' + 'node-' + _node.index;
        if (!_config.typeConfig || !this.node.type) {
            this.config.icon.size = 0;
            return;
        }
        if (_config.typeConfig.hasOwnProperty(_node.type)) {
            let typeConfig = _config.typeConfig[_node.type];
            if (typeConfig.hasOwnProperty('class'))
                this._domSvc.addClass(this._elemRef.nativeElement, typeConfig.class);
            if (typeConfig.hasOwnProperty('iconType')) {
                this._setIcon(typeConfig.iconType, typeConfig.icon, typeConfig.iconClass);
            }
            else {
                this.config.icon.size = 0;
            }
        }
    }
    _setActiveNode() {
        if (this.config.hasOwnProperty('selectOnLoadId') && this.config['selectOnLoadId'] === this.node.index) {
            this._nodeSelected();
        }
    }
    _setIcon(_type, _icon, _iconClass) {
        this.config.icon.type = _type;
        if (_type === 'icon')
            this.config.icon.link += _icon;
        if (_type === 'image')
            this.config.icon.link = _icon;
    }
    _setHeight() {
        this.config.title.textHeight = this._mindmapSvc.textWrap(this.node.title, this.config.title.textClass, this.config);
        this.config.title.height = this._mindmapSvc.setSVGContainerHeight(this.config, 'title');
        if (this.node.description)
            this.config.description.textHeight = this._mindmapSvc.textWrap(this.node.description, this.config.description.textClass, this.config);
        this.config.height = this._mindmapSvc.setSVGContainerHeight(this.config, 'node');
        if (typeof this.node.parents !== 'undefined')
            this.internalApi.setNodeHeight(this.node, this.config.height);
    }
}
KdMindmapNode.decorators = [
    { type: Component, args: [{
                selector: '[kdx-mindmap-node]',
                template: "<svg:g \r\n    [attr.transform]=\"'translate(' + (node.x - config.width/2)+ ',' + (node.y - config.height/2)+ ')'\"\r\n    [attr.node-x]=\"node.x\"\r\n    [attr.node-y]=\"node.y\">\r\n    <svg:rect #nodeWrapper\r\n        class=\"kdx-mindmap-node-wrapper\"\r\n        id=\"rectALeftResize\"\r\n        rx=\"1\"\r\n        ry=\"1\"\r\n        x=\"0\"\r\n        y=\"0\"\r\n        [attr.width]=\"config.width\"\r\n        [attr.height]=\"config.height\"\r\n        stroke=\"black\"\r\n        stroke-width=\"0.25\">\r\n    </svg:rect>\r\n    <svg:g>\r\n        <svg:rect\r\n            class=\"kdx-mindmap-node-title-container\"\r\n            rx=\"1\"\r\n            ry=\"1\"\r\n            x=\"0\"\r\n            y=\"0\"\r\n            [attr.width]=\"config.width\"\r\n            [attr.height]=\"config.title.height\">\r\n        </svg:rect>\r\n        <svg:line\r\n            class=\"kdx-mindmap-node-title-bottom-border\"\r\n            x1=\"0\"\r\n            [attr.x2]=\"config.width\"\r\n            [attr.y1]=\"config.title.height\"\r\n            [attr.y2]=\"config.title.height\">\r\n        </svg:line>\r\n        <svg:text \r\n            [attr.class]=\"config.title.textClass\"\r\n            text-anchor=\"middle\"\r\n            dy=\"0\"\r\n            [attr.font-size]=\"config.fontSize\"\r\n            [attr.x]=\"config.width/2\"\r\n            [attr.y]=\"config.title.paddingTop + config.fontSize\">\r\n        </svg:text>\r\n    </svg:g>\r\n    <svg *ngIf=\"config.icon.type\"\r\n        [attr.width]=\"config.icon.size\" \r\n        [attr.height]=\"config.icon.size\" \r\n        [attr.x]=\"config.width/2 - config.icon.size/2\" \r\n        [attr.y]=\"config.title.height + config.icon.marginTop\">\r\n        <use *ngIf=\"config.icon.type === 'icon'\"\r\n            class=\"kdx-mindmap-node-icon\" \r\n            [attr.href]=\"config.icon.link\" ></use>\r\n        <svg:image *ngIf=\"config.icon.type === 'image'\" \r\n            class=\"kdx-mindmap-node-image\" \r\n            [attr.href]=\"config.icon.link\" \r\n            [attr.width]=\"config.icon.size\" \r\n            [attr.height]=\"config.icon.size\" ></svg:image>\r\n    \r\n    </svg>\r\n    <svg:text *ngIf=\"node.description\" \r\n        [attr.class]=\"config.description.textClass\"\r\n        dy=\"0\"\r\n        text-anchor=\"middle\"\r\n        [attr.font-size]=\"config.fontSize\"\r\n        [attr.x]=\"config.width/2\"\r\n        [attr.y]=\"config.title.height + config.icon.size + config.icon.marginTop + config.icon.marginBottom + config.description.marginTop + config.fontSize\">\r\n    </svg:text>\r\n</svg:g>\r\n",
                encapsulation: ViewEncapsulation.None,
                providers: [KdMindmapSvc, KdMindmapEvent, KdDomElemSvc],
                host: {
                    'class': 'kdx-mindmap-node',
                    '(click)': 'onClick()',
                }
            },] }
];
KdMindmapNode.ctorParameters = () => [
    { type: KdMindmapSvc },
    { type: KdMindmapEvent },
    { type: ElementRef },
    { type: KdDomElemSvc }
];
KdMindmapNode.propDecorators = {
    mindmapId: [{ type: Input }],
    node: [{ type: Input, args: ['kdx-mindmap-node',] }],
    nodeConfig: [{ type: Input, args: ['config',] }],
    internalApi: [{ type: Input, args: ['api',] }],
    selectedNodeEmitter: [{ type: Output }]
};
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoia2QtYW5ndWxhci1taW5kbWFwLW5vZGUuanMiLCJzb3VyY2VSb290IjoiQzoveGFtcHAvaHRkb2NzL1N0eWxlZ3VpZGUvaW9zdGctb3BlbmVtaXMtc3R5bGVndWlkZS9wcm9qZWN0cy9vcGVuZW1pcy1zdHlsZWd1aWRlLWxpYi9zcmMvIiwic291cmNlcyI6WyJrZC1jb21wb25lbnRzL2tkLWFuZ3VsYXItbWluZG1hcC9ub2Rlcy9rZC1hbmd1bGFyLW1pbmRtYXAtbm9kZS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQSxPQUFPLEVBQ0gsU0FBUyxFQUNULEtBQUssRUFDTCxNQUFNLEVBSU4saUJBQWlCLEVBQ2pCLFVBQVUsRUFHVixZQUFZLEVBQ2YsTUFBTSxlQUFlLENBQUM7QUFFdkIsT0FBTyxFQUFFLFlBQVksRUFBRSxNQUFNLHVCQUF1QixDQUFDO0FBQ3JELE9BQU8sRUFBRSxZQUFZLEVBQUUsTUFBTSwyQkFBMkIsQ0FBQztBQUN6RCxPQUFPLEVBQUUsY0FBYyxFQUFFLE1BQU0sNkJBQTZCLENBQUM7QUFpQjdELE1BQU0sT0FBTyxhQUFhO0lBWXRCLFlBQ1ksV0FBeUIsRUFDekIsYUFBNkIsRUFDN0IsUUFBb0IsRUFDcEIsT0FBcUI7UUFIckIsZ0JBQVcsR0FBWCxXQUFXLENBQWM7UUFDekIsa0JBQWEsR0FBYixhQUFhLENBQWdCO1FBQzdCLGFBQVEsR0FBUixRQUFRLENBQVk7UUFDcEIsWUFBTyxHQUFQLE9BQU8sQ0FBYztRQWQxQixXQUFNLEdBQXdCLEVBQUUsQ0FBQztRQUVoQyxnQkFBVyxHQUFZLEtBQUssQ0FBQztRQU0zQix3QkFBbUIsR0FBK0IsSUFBSSxZQUFZLEVBQUUsQ0FBQztJQU8zRSxDQUFDO0lBRUwsUUFBUTtRQUNKLElBQUksQ0FBQyxVQUFVLENBQUMsSUFBSSxDQUFDLFVBQVUsRUFBRSxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUM7UUFDNUMsSUFBSSxDQUFDLGNBQWMsRUFBRSxDQUFDO1FBQ3RCLElBQUksQ0FBQyxnQkFBZ0IsR0FBRyxJQUFJLENBQUMsYUFBYTthQUNyQyxjQUFjLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQzthQUM5QixTQUFTLENBQUMsQ0FBQyxLQUFtQixFQUFRLEVBQUUsQ0FBQyxJQUFJLENBQUMsbUJBQW1CLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQztJQUNuRixDQUFDO0lBRUQsZUFBZTtRQUNYLFVBQVUsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxJQUFJLENBQUMsVUFBVSxFQUFFLENBQUMsQ0FBQztJQUN4QyxDQUFDO0lBRUQsV0FBVyxDQUFDLGNBQTZCO1FBQ3JDLElBQUksQ0FBQyxjQUFjLENBQUMsY0FBYyxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsY0FBYyxDQUFDLE1BQU0sQ0FBQyxDQUFDLFdBQVcsQ0FBQztZQUM5RSxDQUFDLGNBQWMsQ0FBQyxjQUFjLENBQUMsWUFBWSxDQUFDLElBQUksQ0FBQyxjQUFjLENBQUMsWUFBWSxDQUFDLENBQUMsV0FBVyxDQUFDLEVBQUU7WUFDNUYsSUFBSSxDQUFDLFVBQVUsQ0FBQyxJQUFJLENBQUMsVUFBVSxFQUFFLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQztZQUM1QyxJQUFJLENBQUMsY0FBYyxFQUFFLENBQUM7U0FDekI7SUFDTCxDQUFDO0lBRUQsV0FBVztRQUNQLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxXQUFXLEVBQUUsQ0FBQztJQUN4QyxDQUFDO0lBRU0sT0FBTztRQUNWLElBQUksQ0FBQyxhQUFhLEVBQUUsQ0FBQztJQUN6QixDQUFDO0lBRU8sYUFBYTtRQUNqQixJQUFJLElBQUksQ0FBQyxXQUFXO1lBQUUsT0FBTztRQUM3QixJQUFJLENBQUMsT0FBTyxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLGFBQWEsRUFBRSxJQUFJLENBQUMsTUFBTSxDQUFDLFdBQVcsQ0FBQyxDQUFDO1FBQzVFLElBQUksQ0FBQyxhQUFhLENBQUMsWUFBWSxDQUFDLElBQUksQ0FBQyxTQUFTLEVBQUUsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDO1FBQzNELElBQUksQ0FBQyxtQkFBbUIsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDO1FBQ3pDLElBQUksQ0FBQyxXQUFXLEdBQUcsSUFBSSxDQUFDO0lBQzVCLENBQUM7SUFFTyxtQkFBbUIsQ0FBQyxZQUEwQjtRQUNsRCxJQUFJLElBQUksQ0FBQyxXQUFXLEVBQUU7WUFDbEIsSUFBSSxDQUFDLE9BQU8sQ0FBQyxXQUFXLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxhQUFhLEVBQUUsSUFBSSxDQUFDLE1BQU0sQ0FBQyxXQUFXLENBQUMsQ0FBQztZQUMvRSxJQUFJLENBQUMsV0FBVyxHQUFHLEtBQUssQ0FBQztTQUM1QjtJQUNMLENBQUM7SUFFTyxVQUFVLENBQUMsT0FBNEIsRUFBRSxLQUFtQjtRQUNoRSxJQUFJLENBQUMsTUFBTSxHQUFHLE1BQU0sQ0FBQyxNQUFNLENBQUMsRUFBRSxFQUFFLE9BQU8sQ0FBQyxDQUFDO1FBQ3pDLElBQUksQ0FBQyxNQUFNLENBQUMsSUFBSSxHQUFHLE1BQU0sQ0FBQyxNQUFNLENBQUMsRUFBRSxFQUFFLE9BQU8sQ0FBQyxJQUFJLENBQUMsQ0FBQztRQUNuRCxJQUFJLENBQUMsTUFBTSxDQUFDLEtBQUssR0FBRyxNQUFNLENBQUMsTUFBTSxDQUFDLEVBQUUsRUFBRSxPQUFPLENBQUMsS0FBSyxDQUFDLENBQUM7UUFDckQsSUFBSSxDQUFDLE1BQU0sQ0FBQyxXQUFXLEdBQUcsTUFBTSxDQUFDLE1BQU0sQ0FBQyxFQUFFLEVBQUUsT0FBTyxDQUFDLFdBQVcsQ0FBQyxDQUFDO1FBRWpFLElBQUksSUFBSSxDQUFDLE1BQU0sQ0FBQyxLQUFLO1lBQUUsSUFBSSxDQUFDLE9BQU8sQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxhQUFhLEVBQUUsSUFBSSxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsQ0FBQztRQUU3RixJQUFJLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxTQUFTLElBQUksR0FBRyxHQUFHLE9BQU8sR0FBRyxLQUFLLENBQUMsS0FBSyxDQUFDO1FBQzNELElBQUksQ0FBQyxNQUFNLENBQUMsV0FBVyxDQUFDLFNBQVMsSUFBSSxHQUFHLEdBQUcsT0FBTyxHQUFHLEtBQUssQ0FBQyxLQUFLLENBQUM7UUFFakUsSUFBSSxDQUFDLE9BQU8sQ0FBQyxVQUFVLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksRUFBRTtZQUN4QyxJQUFJLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxJQUFJLEdBQUcsQ0FBQyxDQUFDO1lBQzFCLE9BQU87U0FDVjtRQUVELElBQUksT0FBTyxDQUFDLFVBQVUsQ0FBQyxjQUFjLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxFQUFFO1lBQy9DLElBQUksVUFBVSxHQUFHLE9BQU8sQ0FBQyxVQUFVLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxDQUFDO1lBRWhELElBQUksVUFBVSxDQUFDLGNBQWMsQ0FBQyxPQUFPLENBQUM7Z0JBQUUsSUFBSSxDQUFDLE9BQU8sQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxhQUFhLEVBQUUsVUFBVSxDQUFDLEtBQUssQ0FBQyxDQUFDO1lBQzdHLElBQUksVUFBVSxDQUFDLGNBQWMsQ0FBQyxVQUFVLENBQUMsRUFBRTtnQkFDdkMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxVQUFVLENBQUMsUUFBUSxFQUFFLFVBQVUsQ0FBQyxJQUFJLEVBQUUsVUFBVSxDQUFDLFNBQVMsQ0FBQyxDQUFDO2FBQzdFO2lCQUFNO2dCQUNILElBQUksQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLElBQUksR0FBRyxDQUFDLENBQUM7YUFDN0I7U0FDSjtJQUNMLENBQUM7SUFFTyxjQUFjO1FBQ2xCLElBQUksSUFBSSxDQUFDLE1BQU0sQ0FBQyxjQUFjLENBQUMsZ0JBQWdCLENBQUMsSUFBSSxJQUFJLENBQUMsTUFBTSxDQUFDLGdCQUFnQixDQUFDLEtBQUssSUFBSSxDQUFDLElBQUksQ0FBQyxLQUFLLEVBQUU7WUFDbkcsSUFBSSxDQUFDLGFBQWEsRUFBRSxDQUFDO1NBQ3hCO0lBQ0wsQ0FBQztJQUVPLFFBQVEsQ0FBQyxLQUF1QixFQUFFLEtBQWEsRUFBRSxVQUFrQjtRQUN2RSxJQUFJLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxJQUFJLEdBQUcsS0FBSyxDQUFDO1FBQzlCLElBQUksS0FBSyxLQUFLLE1BQU07WUFBRSxJQUFJLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxJQUFJLElBQUksS0FBSyxDQUFDO1FBQ3JELElBQUksS0FBSyxLQUFLLE9BQU87WUFBRSxJQUFJLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxJQUFJLEdBQUcsS0FBSyxDQUFDO0lBQ3pELENBQUM7SUFFTyxVQUFVO1FBQ2QsSUFBSSxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsVUFBVSxHQUFHLElBQUksQ0FBQyxXQUFXLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsS0FBSyxFQUFFLElBQUksQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLFNBQVMsRUFBRSxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUM7UUFDcEgsSUFBSSxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsTUFBTSxHQUFHLElBQUksQ0FBQyxXQUFXLENBQUMscUJBQXFCLENBQUMsSUFBSSxDQUFDLE1BQU0sRUFBRSxPQUFPLENBQUMsQ0FBQztRQUN4RixJQUFJLElBQUksQ0FBQyxJQUFJLENBQUMsV0FBVztZQUFFLElBQUksQ0FBQyxNQUFNLENBQUMsV0FBVyxDQUFDLFVBQVUsR0FBRyxJQUFJLENBQUMsV0FBVyxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLFdBQVcsRUFBRSxJQUFJLENBQUMsTUFBTSxDQUFDLFdBQVcsQ0FBQyxTQUFTLEVBQUUsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDO1FBQ2pLLElBQUksQ0FBQyxNQUFNLENBQUMsTUFBTSxHQUFHLElBQUksQ0FBQyxXQUFXLENBQUMscUJBQXFCLENBQUMsSUFBSSxDQUFDLE1BQU0sRUFBRSxNQUFNLENBQUMsQ0FBQztRQUNqRixJQUFJLE9BQU8sSUFBSSxDQUFDLElBQUksQ0FBQyxPQUFPLEtBQUssV0FBVztZQUFFLElBQUksQ0FBQyxXQUFXLENBQUMsYUFBYSxDQUFDLElBQUksQ0FBQyxJQUFJLEVBQUUsSUFBSSxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsQ0FBQztJQUNoSCxDQUFDOzs7WUF0SEosU0FBUyxTQUFDO2dCQUNQLFFBQVEsRUFBRSxvQkFBb0I7Z0JBQzlCLG9rRkFBNkM7Z0JBQzdDLGFBQWEsRUFBRSxpQkFBaUIsQ0FBQyxJQUFJO2dCQUNyQyxTQUFTLEVBQUUsQ0FBQyxZQUFZLEVBQUUsY0FBYyxFQUFFLFlBQVksQ0FBQztnQkFDdkQsSUFBSSxFQUFFO29CQUNGLE9BQU8sRUFBRSxrQkFBa0I7b0JBQzNCLFNBQVMsRUFBRSxXQUFXO2lCQUN6QjthQUNKOzs7WUFqQlEsWUFBWTtZQUNaLGNBQWM7WUFSbkIsVUFBVTtZQU1MLFlBQVk7Ozt3QkF5QmhCLEtBQUs7bUJBQ0wsS0FBSyxTQUFDLGtCQUFrQjt5QkFDeEIsS0FBSyxTQUFDLFFBQVE7MEJBQ2QsS0FBSyxTQUFDLEtBQUs7a0NBQ1gsTUFBTSIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7XHJcbiAgICBDb21wb25lbnQsXHJcbiAgICBJbnB1dCxcclxuICAgIE91dHB1dCxcclxuICAgIE9uSW5pdCxcclxuICAgIE9uQ2hhbmdlcyxcclxuICAgIEFmdGVyVmlld0luaXQsXHJcbiAgICBWaWV3RW5jYXBzdWxhdGlvbixcclxuICAgIEVsZW1lbnRSZWYsXHJcbiAgICBTaW1wbGVDaGFuZ2VzLFxyXG4gICAgT25EZXN0cm95LFxyXG4gICAgRXZlbnRFbWl0dGVyXHJcbn0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XHJcbmltcG9ydCB7IFN1YnNjcmlwdGlvbiB9IGZyb20gJ3J4anMnO1xyXG5pbXBvcnQgeyBLZERvbUVsZW1TdmMgfSBmcm9tICcuLi8uLi9rZC1jb21tb24vaW5kZXgnO1xyXG5pbXBvcnQgeyBLZE1pbmRtYXBTdmMgfSBmcm9tICcuLi9rZC1hbmd1bGFyLW1pbmRtYXAtc3ZjJztcclxuaW1wb3J0IHsgS2RNaW5kbWFwRXZlbnQgfSBmcm9tICcuLi9rZC1hbmd1bGFyLW1pbmRtYXAtZXZlbnQnO1xyXG5pbXBvcnQgeyBcclxuICAgIElNaW5kbWFwSW50ZXJuYWxBcGksXHJcbiAgICBJSW50ZXJuYWxOb2RlQ29uZmlnLCBcclxuICAgIElNaW5kbWFwTm9kZSBcclxufSBmcm9tICcuLi9rZC1hbmd1bGFyLW1pbmRtYXAtaW50ZXJmYWNlJztcclxuXHJcbkBDb21wb25lbnQoe1xyXG4gICAgc2VsZWN0b3I6ICdba2R4LW1pbmRtYXAtbm9kZV0nLFxyXG4gICAgdGVtcGxhdGVVcmw6ICcuL2tkLWFuZ3VsYXItbWluZG1hcC1ub2RlLmh0bWwnLFxyXG4gICAgZW5jYXBzdWxhdGlvbjogVmlld0VuY2Fwc3VsYXRpb24uTm9uZSxcclxuICAgIHByb3ZpZGVyczogW0tkTWluZG1hcFN2YywgS2RNaW5kbWFwRXZlbnQsIEtkRG9tRWxlbVN2Y10sXHJcbiAgICBob3N0OiB7XHJcbiAgICAgICAgJ2NsYXNzJzogJ2tkeC1taW5kbWFwLW5vZGUnLFxyXG4gICAgICAgICcoY2xpY2spJzogJ29uQ2xpY2soKScsXHJcbiAgICB9XHJcbn0pXHJcbmV4cG9ydCBjbGFzcyBLZE1pbmRtYXBOb2RlIGltcGxlbWVudHMgT25Jbml0LCBBZnRlclZpZXdJbml0LCBPbkNoYW5nZXMsIE9uRGVzdHJveSB7XHJcblxyXG4gICAgcHVibGljIGNvbmZpZzogSUludGVybmFsTm9kZUNvbmZpZyA9IHt9O1xyXG4gICAgcHJpdmF0ZSBfbm9kZVNlbGVjdGVkU3ViOiBTdWJzY3JpcHRpb247XHJcbiAgICBwcml2YXRlIF9ub2RlQWN0aXZlOiBib29sZWFuID0gZmFsc2U7XHJcblxyXG4gICAgQElucHV0KCkgbWluZG1hcElkOiBzdHJpbmc7XHJcbiAgICBASW5wdXQoJ2tkeC1taW5kbWFwLW5vZGUnKSBub2RlOiBJTWluZG1hcE5vZGU7XHJcbiAgICBASW5wdXQoJ2NvbmZpZycpIG5vZGVDb25maWc6IElJbnRlcm5hbE5vZGVDb25maWc7XHJcbiAgICBASW5wdXQoJ2FwaScpIGludGVybmFsQXBpOiBJTWluZG1hcEludGVybmFsQXBpO1xyXG4gICAgQE91dHB1dCgpIHNlbGVjdGVkTm9kZUVtaXR0ZXI6IEV2ZW50RW1pdHRlcjxJTWluZG1hcE5vZGU+ID0gbmV3IEV2ZW50RW1pdHRlcigpO1xyXG5cclxuICAgIGNvbnN0cnVjdG9yKFxyXG4gICAgICAgIHByaXZhdGUgX21pbmRtYXBTdmM6IEtkTWluZG1hcFN2YyxcclxuICAgICAgICBwcml2YXRlIF9taW5kbWFwRXZlbnQ6IEtkTWluZG1hcEV2ZW50LFxyXG4gICAgICAgIHByaXZhdGUgX2VsZW1SZWY6IEVsZW1lbnRSZWYsXHJcbiAgICAgICAgcHJpdmF0ZSBfZG9tU3ZjOiBLZERvbUVsZW1TdmNcclxuICAgICkgeyB9XHJcblxyXG4gICAgbmdPbkluaXQoKTogdm9pZCB7XHJcbiAgICAgICAgdGhpcy5fc2V0Q29uZmlnKHRoaXMubm9kZUNvbmZpZywgdGhpcy5ub2RlKTtcclxuICAgICAgICB0aGlzLl9zZXRBY3RpdmVOb2RlKCk7XHJcbiAgICAgICAgdGhpcy5fbm9kZVNlbGVjdGVkU3ViID0gdGhpcy5fbWluZG1hcEV2ZW50XHJcbiAgICAgICAgICAgIC5vbk5vZGVTZWxlY3RlZCh0aGlzLm1pbmRtYXBJZClcclxuICAgICAgICAgICAgLnN1YnNjcmliZSgoX25vZGU6IElNaW5kbWFwTm9kZSk6IHZvaWQgPT4gdGhpcy5fY2xlYXJOb2RlU2VsZWN0aW9uKF9ub2RlKSk7XHJcbiAgICB9XHJcblxyXG4gICAgbmdBZnRlclZpZXdJbml0KCk6IHZvaWQge1xyXG4gICAgICAgIHNldFRpbWVvdXQoKCkgPT4gdGhpcy5fc2V0SGVpZ2h0KCkpO1xyXG4gICAgfVxyXG5cclxuICAgIG5nT25DaGFuZ2VzKF9zaW1wbGVDaGFuZ2VzOiBTaW1wbGVDaGFuZ2VzKTogdm9pZCB7XHJcbiAgICAgICAgaWYgKChfc2ltcGxlQ2hhbmdlcy5oYXNPd25Qcm9wZXJ0eSgnbm9kZScpICYmICFfc2ltcGxlQ2hhbmdlc1snbm9kZSddLmZpcnN0Q2hhbmdlKSB8fFxyXG4gICAgICAgICAgICAoX3NpbXBsZUNoYW5nZXMuaGFzT3duUHJvcGVydHkoJ25vZGVDb25maWcnKSAmJiAhX3NpbXBsZUNoYW5nZXNbJ25vZGVDb25maWcnXS5maXJzdENoYW5nZSkpIHtcclxuICAgICAgICAgICAgdGhpcy5fc2V0Q29uZmlnKHRoaXMubm9kZUNvbmZpZywgdGhpcy5ub2RlKTtcclxuICAgICAgICAgICAgdGhpcy5fc2V0QWN0aXZlTm9kZSgpO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICBuZ09uRGVzdHJveSgpOiB2b2lkIHtcclxuICAgICAgICB0aGlzLl9ub2RlU2VsZWN0ZWRTdWIudW5zdWJzY3JpYmUoKTtcclxuICAgIH1cclxuXHJcbiAgICBwdWJsaWMgb25DbGljaygpOiB2b2lkIHtcclxuICAgICAgICB0aGlzLl9ub2RlU2VsZWN0ZWQoKTtcclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF9ub2RlU2VsZWN0ZWQoKTogdm9pZCB7XHJcbiAgICAgICAgaWYgKHRoaXMuX25vZGVBY3RpdmUpIHJldHVybjtcclxuICAgICAgICB0aGlzLl9kb21TdmMuYWRkQ2xhc3ModGhpcy5fZWxlbVJlZi5uYXRpdmVFbGVtZW50LCB0aGlzLmNvbmZpZy5hY3RpdmVDbGFzcyk7XHJcbiAgICAgICAgdGhpcy5fbWluZG1hcEV2ZW50Lm5vZGVTZWxlY3RlZCh0aGlzLm1pbmRtYXBJZCwgdGhpcy5ub2RlKTtcclxuICAgICAgICB0aGlzLnNlbGVjdGVkTm9kZUVtaXR0ZXIuZW1pdCh0aGlzLm5vZGUpO1xyXG4gICAgICAgIHRoaXMuX25vZGVBY3RpdmUgPSB0cnVlO1xyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX2NsZWFyTm9kZVNlbGVjdGlvbihfbm9kZVRvQ2xlYXI6IElNaW5kbWFwTm9kZSk6IHZvaWQge1xyXG4gICAgICAgIGlmICh0aGlzLl9ub2RlQWN0aXZlKSB7XHJcbiAgICAgICAgICAgIHRoaXMuX2RvbVN2Yy5yZW1vdmVDbGFzcyh0aGlzLl9lbGVtUmVmLm5hdGl2ZUVsZW1lbnQsIHRoaXMuY29uZmlnLmFjdGl2ZUNsYXNzKTtcclxuICAgICAgICAgICAgdGhpcy5fbm9kZUFjdGl2ZSA9IGZhbHNlO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF9zZXRDb25maWcoX2NvbmZpZzogSUludGVybmFsTm9kZUNvbmZpZywgX25vZGU6IElNaW5kbWFwTm9kZSk6IHZvaWQge1xyXG4gICAgICAgIHRoaXMuY29uZmlnID0gT2JqZWN0LmFzc2lnbih7fSwgX2NvbmZpZyk7XHJcbiAgICAgICAgdGhpcy5jb25maWcuaWNvbiA9IE9iamVjdC5hc3NpZ24oe30sIF9jb25maWcuaWNvbik7XHJcbiAgICAgICAgdGhpcy5jb25maWcudGl0bGUgPSBPYmplY3QuYXNzaWduKHt9LCBfY29uZmlnLnRpdGxlKTtcclxuICAgICAgICB0aGlzLmNvbmZpZy5kZXNjcmlwdGlvbiA9IE9iamVjdC5hc3NpZ24oe30sIF9jb25maWcuZGVzY3JpcHRpb24pO1xyXG5cclxuICAgICAgICBpZiAodGhpcy5jb25maWcuY2xhc3MpIHRoaXMuX2RvbVN2Yy5hZGRDbGFzcyh0aGlzLl9lbGVtUmVmLm5hdGl2ZUVsZW1lbnQsIHRoaXMuY29uZmlnLmNsYXNzKTtcclxuXHJcbiAgICAgICAgdGhpcy5jb25maWcudGl0bGUudGV4dENsYXNzICs9ICcgJyArICdub2RlLScgKyBfbm9kZS5pbmRleDtcclxuICAgICAgICB0aGlzLmNvbmZpZy5kZXNjcmlwdGlvbi50ZXh0Q2xhc3MgKz0gJyAnICsgJ25vZGUtJyArIF9ub2RlLmluZGV4O1xyXG5cclxuICAgICAgICBpZiAoIV9jb25maWcudHlwZUNvbmZpZyB8fCAhdGhpcy5ub2RlLnR5cGUpIHtcclxuICAgICAgICAgICAgdGhpcy5jb25maWcuaWNvbi5zaXplID0gMDtcclxuICAgICAgICAgICAgcmV0dXJuO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgaWYgKF9jb25maWcudHlwZUNvbmZpZy5oYXNPd25Qcm9wZXJ0eShfbm9kZS50eXBlKSkge1xyXG4gICAgICAgICAgICBsZXQgdHlwZUNvbmZpZyA9IF9jb25maWcudHlwZUNvbmZpZ1tfbm9kZS50eXBlXTtcclxuXHJcbiAgICAgICAgICAgIGlmICh0eXBlQ29uZmlnLmhhc093blByb3BlcnR5KCdjbGFzcycpKSB0aGlzLl9kb21TdmMuYWRkQ2xhc3ModGhpcy5fZWxlbVJlZi5uYXRpdmVFbGVtZW50LCB0eXBlQ29uZmlnLmNsYXNzKTtcclxuICAgICAgICAgICAgaWYgKHR5cGVDb25maWcuaGFzT3duUHJvcGVydHkoJ2ljb25UeXBlJykpIHtcclxuICAgICAgICAgICAgICAgIHRoaXMuX3NldEljb24odHlwZUNvbmZpZy5pY29uVHlwZSwgdHlwZUNvbmZpZy5pY29uLCB0eXBlQ29uZmlnLmljb25DbGFzcyk7XHJcbiAgICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLmNvbmZpZy5pY29uLnNpemUgPSAwO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX3NldEFjdGl2ZU5vZGUoKTogdm9pZCB7XHJcbiAgICAgICAgaWYgKHRoaXMuY29uZmlnLmhhc093blByb3BlcnR5KCdzZWxlY3RPbkxvYWRJZCcpICYmIHRoaXMuY29uZmlnWydzZWxlY3RPbkxvYWRJZCddID09PSB0aGlzLm5vZGUuaW5kZXgpIHtcclxuICAgICAgICAgICAgdGhpcy5fbm9kZVNlbGVjdGVkKCk7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX3NldEljb24oX3R5cGU6ICdpY29uJyB8ICdpbWFnZScsIF9pY29uOiBzdHJpbmcsIF9pY29uQ2xhc3M6IHN0cmluZyk6IHZvaWQge1xyXG4gICAgICAgIHRoaXMuY29uZmlnLmljb24udHlwZSA9IF90eXBlO1xyXG4gICAgICAgIGlmIChfdHlwZSA9PT0gJ2ljb24nKSB0aGlzLmNvbmZpZy5pY29uLmxpbmsgKz0gX2ljb247XHJcbiAgICAgICAgaWYgKF90eXBlID09PSAnaW1hZ2UnKSB0aGlzLmNvbmZpZy5pY29uLmxpbmsgPSBfaWNvbjtcclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF9zZXRIZWlnaHQoKTogdm9pZCB7XHJcbiAgICAgICAgdGhpcy5jb25maWcudGl0bGUudGV4dEhlaWdodCA9IHRoaXMuX21pbmRtYXBTdmMudGV4dFdyYXAodGhpcy5ub2RlLnRpdGxlLCB0aGlzLmNvbmZpZy50aXRsZS50ZXh0Q2xhc3MsIHRoaXMuY29uZmlnKTtcclxuICAgICAgICB0aGlzLmNvbmZpZy50aXRsZS5oZWlnaHQgPSB0aGlzLl9taW5kbWFwU3ZjLnNldFNWR0NvbnRhaW5lckhlaWdodCh0aGlzLmNvbmZpZywgJ3RpdGxlJyk7XHJcbiAgICAgICAgaWYgKHRoaXMubm9kZS5kZXNjcmlwdGlvbikgdGhpcy5jb25maWcuZGVzY3JpcHRpb24udGV4dEhlaWdodCA9IHRoaXMuX21pbmRtYXBTdmMudGV4dFdyYXAodGhpcy5ub2RlLmRlc2NyaXB0aW9uLCB0aGlzLmNvbmZpZy5kZXNjcmlwdGlvbi50ZXh0Q2xhc3MsIHRoaXMuY29uZmlnKTtcclxuICAgICAgICB0aGlzLmNvbmZpZy5oZWlnaHQgPSB0aGlzLl9taW5kbWFwU3ZjLnNldFNWR0NvbnRhaW5lckhlaWdodCh0aGlzLmNvbmZpZywgJ25vZGUnKTtcclxuICAgICAgICBpZiAodHlwZW9mIHRoaXMubm9kZS5wYXJlbnRzICE9PSAndW5kZWZpbmVkJykgdGhpcy5pbnRlcm5hbEFwaS5zZXROb2RlSGVpZ2h0KHRoaXMubm9kZSwgdGhpcy5jb25maWcuaGVpZ2h0KTtcclxuICAgIH1cclxufVxyXG4iXX0=