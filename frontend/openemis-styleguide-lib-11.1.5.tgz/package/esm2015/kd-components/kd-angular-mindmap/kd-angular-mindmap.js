import { Component, ViewEncapsulation, Input, Output, ChangeDetectorRef, ElementRef, ChangeDetectionStrategy, EventEmitter } from '@angular/core';
import { KdDataSvc } from '../kd-common/index';
import { KdMindmapSvc } from './kd-angular-mindmap-svc';
import { defaultConfig } from './kd-angular-mindmap-config';
export class KdMindmap {
    constructor(_mindmapSvc, _dataSvc, _elemRef, _ref) {
        this._mindmapSvc = _mindmapSvc;
        this._dataSvc = _dataSvc;
        this._elemRef = _elemRef;
        this._ref = _ref;
        this.internalApi = {};
        this.internalLinkApiRef = {};
        this.displayGraph = true;
        this.linkClass = '';
        this.options = { width: 0, height: 600, levelPosition: { '0': 10 } };
        this.showLoader = true;
        this.smallLoaderValue = null;
        this.buttonConfig = {
            coord: { x: 25, y: 25 },
            size: 30,
            iconSize: 20,
            marginBottom: 10,
        };
        this._simulationEnd = false;
        this._translationEnd = false;
        this._hasSelectedNode = false;
        this.selectedNodeEmitter = new EventEmitter();
    }
    ngOnInit() {
        this._setConfig(this.mainConfig);
        this._initApi();
        this._initInternalApi();
        if (typeof this.inputNodes === 'undefined' || Object.keys(this.inputNodes).length === 0) {
            this.displayGraph = false;
            return;
        }
        this._startSetDataAndGraph();
    }
    ngOnChanges(_simpleChanges) {
        if (_simpleChanges.hasOwnProperty('mainConfig') && !_simpleChanges['mainConfig'].firstChange) {
            this._setConfig(this.mainConfig);
        }
        if (_simpleChanges.hasOwnProperty('inputNodes') && !_simpleChanges['inputNodes'].firstChange && Object.keys(this.inputNodes).length !== 0) {
            if (!this.displayGraph)
                this.displayGraph = true;
            this._startSetDataAndGraph();
            this._graph.initSimulation(this.options);
            if (this._hasSelectedNode) {
                if (this.internalApi.hasOwnProperty('translate'))
                    this._setInitPosX();
                else
                    setTimeout(() => this._setInitPosX());
            }
        }
    }
    ngAfterViewInit() {
        if (typeof this.inputNodes === 'undefined' || Object.keys(this.inputNodes).length === 0)
            return;
        this._graph.initSimulation(this.options);
        if (this._hasSelectedNode)
            setTimeout(() => this._setInitPosX());
    }
    outputSelectedNode(_selectedNode) {
        this.selectedNodeEmitter.emit(_selectedNode);
    }
    _initApi() {
        if (typeof this.api !== 'undefined') {
            this.api.zoom = (_action) => this.internalApi.zoom(_action);
        }
    }
    _initInternalApi() {
        if (typeof this.internalApi !== 'undefined') {
            this.internalApi.setNodeHeight = (_node, _nodeHeight) => {
                let affectedLinks = this._mindmapSvc.setLinkSpreadDistance(this.links, _node, _nodeHeight);
                for (let i = 0; i < affectedLinks.length; ++i) {
                    this.internalApi.accessInternalLinkApi(affectedLinks[i].index.toString()).setLinkOffset(affectedLinks[i].offset);
                }
            };
            this.internalApi.accessInternalLinkApi = (_key) => this.internalLinkApiRef[_key];
        }
    }
    _setConfig(_config) {
        this.config = this._dataSvc.deepMergeObject(defaultConfig, this.mainConfig);
        this.config.node.width = this.config.node.width || 200;
        if (this.config.link.class)
            this.linkClass = this.config.link.class;
        this.buttonConfig.iconLinkPath = this.config.iconLinkPath;
        this.config.node.icon.link = this.config.iconLinkPath;
        if (this.config.node.selectOnLoadId && typeof this.config.node.selectOnLoadId === 'number')
            this._hasSelectedNode = true;
    }
    _startSetDataAndGraph() {
        this._setDataAndOptions(this.inputNodes);
        this._hasSelectedNode = this._hasSelectedNode && this._mindmapSvc.foundSelectedNode(this.nodes, this.config.node.selectOnLoadId);
        /** Receiving an initialized simulated graph from our custom d3 service */
        this._graph = this._mindmapSvc.getForceDirectedGraph(this.nodes, this.links, this.options);
        /** Binding change detection check on each tick
         * This along with an onPush change detection strategy should enforce checking only when relevant!
         * This improves scripting computation duration in a couple of tests I've made, consistently.
         * Also, it makes sense to avoid unnecessary checks when we are dealing only with simulations data binding.
         */
        this._graph.ticker.subscribe((d) => {
            this._ref.markForCheck();
        });
        this._graph.onSimulationEnd.subscribe((_flag) => {
            this.onSimulationEnd();
        });
    }
    _setDataAndOptions(_inputNodes) {
        let newData;
        newData = this._mindmapSvc.setData(_inputNodes);
        this.highestCount = newData.highestCount;
        this.links = newData.links;
        this.options.width = this._calculateWidth();
        this.options.levelPosition = this._calculateLevelPosition();
        this.nodes = this._mindmapSvc.setFx(newData.nodes, this.options.levelPosition, newData.haveLoner);
    }
    _calculateWidth() {
        return (this.config.levelRightMargin + this.config.node.width) * this.highestCount + this.config.node.width + 2 * this.config.padding;
    }
    _calculateLevelPosition() {
        let position = {};
        for (let i = 0; i < this.highestCount + 1; ++i) {
            position[i.toString()] = i * (this.config.node.width + this.config.levelRightMargin) + this.config.padding + this.config.node.width / 2;
        }
        return position;
    }
    /* _setInitPosX sometimes needs setTimeout for 2 reasons:
    * 1) on first load, getBoundingClientRect is not ready
    * 2) on subsequent load, need to make sure internalApi.translate is present (may not be present becos displayGraph was set to false)
    */
    _setInitPosX() {
        let config = {
            svgWidth: this._elemRef.nativeElement.querySelector('.kdx-mindmap #kdx-mindmap-wrapper').getBoundingClientRect().width,
            nodeWidth: this.config.node.width,
            padding: this.config.padding
        };
        let _initPosX = this._mindmapSvc.translateSvgToXPos(config, this.nodes[this.mainConfig.node.selectOnLoadId], 'right');
        this.internalApi.translate(_initPosX).on('end', () => this.onTranslationEnd());
    }
    onSimulationEnd() {
        this._simulationEnd = true;
        if (this._translationEnd || !this._hasSelectedNode)
            this.showLoader = false;
    }
    onTranslationEnd() {
        this._translationEnd = true;
        if (this._simulationEnd)
            this.showLoader = false;
    }
}
KdMindmap.decorators = [
    { type: Component, args: [{
                selector: 'kd-mindmap',
                template: "<div class=\"kdx-mindmap-outer-wrapper\">\r\n    <svg #svg id=\"kdx-mindmap-wrapper\" [attr.width]=\"config.width\" [attr.height]=\"config.height\">\r\n        <svg:defs>\r\n            <svg:marker id=\"arrowEnd\" viewBox=\"0 0 10 10\" refX=\"9\" refY=\"5\"\r\n                markerWidth=\"10\" markerHeight=\"10\" orient=\"auto\" [attr.class]=\"linkClass\">\r\n                <path d=\"M 0 0 L 10 5 L 0 10 z\" />\r\n            </svg:marker>\r\n            <svg:marker id=\"arrowStart\" viewBox=\"0 0 10 10\" refX=\"1\" refY=\"5\"\r\n                markerWidth=\"10\" markerHeight=\"10\" orient=\"auto\" [attr.class]=\"linkClass\">\r\n                <svg>\r\n                    <path transform=\"matrix(-1,0,0,1,10,0)\" d=\"M 0 0 L 10 5 L 0 10 z\" />\r\n                </svg>\r\n            </svg:marker>\r\n            <svg:marker id=\"arrowEndActive\" viewBox=\"0 0 10 10\" refX=\"9\" refY=\"5\"\r\n                markerWidth=\"10\" markerHeight=\"10\" orient=\"auto\" [attr.class]=\"config.link.activeClass\">\r\n                <path d=\"M 0 0 L 10 5 L 0 10 z\" />\r\n            </svg:marker>\r\n            <svg:marker id=\"arrowStartActive\" viewBox=\"0 0 10 10\" refX=\"1\" refY=\"5\"\r\n                markerWidth=\"10\" markerHeight=\"10\" orient=\"auto\" [attr.class]=\"config.link.activeClass\">\r\n                <svg>\r\n                    <path transform=\"matrix(-1,0,0,1,10,0)\" d=\"M 0 0 L 10 5 L 0 10 z\" />\r\n                </svg>\r\n            </svg:marker>\r\n        </svg:defs>\r\n        <svg:g class=\"kdx-mindmap-group\" *ngIf=\"displayGraph\" [zoomableOf]=\"svg\" [api]=\"internalApi\">\r\n            <svg:g class=\"kdx-mindmap-link-group\" >\r\n                <svg:g id=\"link\" *ngFor=\"let link of links\" \r\n                    [kdx-mindmap-link]=\"link\"\r\n                    [config]=\"config\" \r\n                    [mindmapId]=\"config.id\"\r\n                    [api]=\"internalLinkApiRef\"></svg:g>\r\n            </svg:g>\r\n            <svg:g class=\"kdx-mindmap-node-group\">\r\n                <svg:g *ngFor=\"let node of nodes\" \r\n                    [kdx-mindmap-node]=\"node\" \r\n                    [config]=\"config.node\" \r\n                    [mindmapId]=\"config.id\"\r\n                    [api]=\"internalApi\"\r\n                    (selectedNodeEmitter)=\"outputSelectedNode($event)\"></svg:g>\r\n            </svg:g>\r\n        </svg:g>\r\n        <svg:g *ngIf=\"config.zoomButton\" [attr.transform]=\"'translate(' + buttonConfig.coord.x + ',' + buttonConfig.coord.y + ')'\">\r\n            <svg:g [zoomButton]=\"'zoom_in'\" [config]=\"buttonConfig\" [api]=\"internalApi\"></svg:g>\r\n            <svg:g [attr.transform]=\"'translate(' + 0 + ',' + (buttonConfig.size + buttonConfig.marginBottom) + ')'\" [zoomButton]=\"'zoom_out'\" [config]=\"buttonConfig\" [api]=\"internalApi\" ></svg:g>\r\n        </svg:g>\r\n        <svg:rect *ngIf=\"config.border\"\r\n            class=\"kdx-mindmap-wrapper-border\"\r\n            x=\"0\"\r\n            y=\"0\"\r\n            rx=\"4\"\r\n            ry=\"4\"\r\n            width=\"100%\"\r\n            height=\"100%\"\r\n        ></svg:rect>\r\n    </svg>\r\n    <kd-progressloader *ngIf=\"showLoader\" configtype=\"small-spinner\" [configvalue]=\"smallLoaderValue\"></kd-progressloader>\r\n</div>\r\n",
                providers: [KdMindmapSvc, KdDataSvc],
                encapsulation: ViewEncapsulation.None,
                changeDetection: ChangeDetectionStrategy.OnPush,
                host: {
                    'class': 'kdx-mindmap',
                    '[attr.id]': 'config.id',
                }
            },] }
];
KdMindmap.ctorParameters = () => [
    { type: KdMindmapSvc },
    { type: KdDataSvc },
    { type: ElementRef },
    { type: ChangeDetectorRef }
];
KdMindmap.propDecorators = {
    inputNodes: [{ type: Input, args: ['nodes',] }],
    mainConfig: [{ type: Input, args: ['config',] }],
    api: [{ type: Input }],
    selectedNodeEmitter: [{ type: Output }]
};
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoia2QtYW5ndWxhci1taW5kbWFwLmpzIiwic291cmNlUm9vdCI6IkM6L3hhbXBwL2h0ZG9jcy9TdHlsZWd1aWRlL2lvc3RnLW9wZW5lbWlzLXN0eWxlZ3VpZGUvcHJvamVjdHMvb3BlbmVtaXMtc3R5bGVndWlkZS1saWIvc3JjLyIsInNvdXJjZXMiOlsia2QtY29tcG9uZW50cy9rZC1hbmd1bGFyLW1pbmRtYXAva2QtYW5ndWxhci1taW5kbWFwLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBLE9BQU8sRUFDSCxTQUFTLEVBQ1QsaUJBQWlCLEVBQ2pCLEtBQUssRUFDTCxNQUFNLEVBSU4saUJBQWlCLEVBQ2pCLFVBQVUsRUFDVix1QkFBdUIsRUFDdkIsWUFBWSxFQUNmLE1BQU0sZUFBZSxDQUFDO0FBQ3ZCLE9BQU8sRUFBRSxTQUFTLEVBQUUsTUFBTSxvQkFBb0IsQ0FBQztBQUUvQyxPQUFPLEVBQUUsWUFBWSxFQUFFLE1BQU0sMEJBQTBCLENBQUM7QUFZeEQsT0FBTyxFQUFFLGFBQWEsRUFBRSxNQUFNLDZCQUE2QixDQUFDO0FBYzVELE1BQU0sT0FBTyxTQUFTO0lBNkJsQixZQUNZLFdBQXlCLEVBQ3pCLFFBQW1CLEVBQ25CLFFBQW9CLEVBQ3BCLElBQXVCO1FBSHZCLGdCQUFXLEdBQVgsV0FBVyxDQUFjO1FBQ3pCLGFBQVEsR0FBUixRQUFRLENBQVc7UUFDbkIsYUFBUSxHQUFSLFFBQVEsQ0FBWTtRQUNwQixTQUFJLEdBQUosSUFBSSxDQUFtQjtRQTVCNUIsZ0JBQVcsR0FBd0IsRUFBRSxDQUFDO1FBQ3RDLHVCQUFrQixHQUErQixFQUFFLENBQUM7UUFDcEQsaUJBQVksR0FBWSxJQUFJLENBQUM7UUFDN0IsY0FBUyxHQUFXLEVBQUUsQ0FBQztRQUN2QixZQUFPLEdBQW9CLEVBQUUsS0FBSyxFQUFFLENBQUMsRUFBRSxNQUFNLEVBQUUsR0FBRyxFQUFFLGFBQWEsRUFBRSxFQUFFLEdBQUcsRUFBRSxFQUFFLEVBQUUsRUFBRSxDQUFDO1FBQ2pGLGVBQVUsR0FBWSxJQUFJLENBQUM7UUFDM0IscUJBQWdCLEdBQVEsSUFBSSxDQUFDO1FBRTdCLGlCQUFZLEdBQXNCO1lBQ3JDLEtBQUssRUFBRSxFQUFFLENBQUMsRUFBRSxFQUFFLEVBQUUsQ0FBQyxFQUFFLEVBQUUsRUFBRTtZQUN2QixJQUFJLEVBQUUsRUFBRTtZQUNSLFFBQVEsRUFBRSxFQUFFO1lBQ1osWUFBWSxFQUFFLEVBQUU7U0FDbkIsQ0FBQztRQUVNLG1CQUFjLEdBQVksS0FBSyxDQUFDO1FBQ2hDLG9CQUFlLEdBQVksS0FBSyxDQUFDO1FBQ2pDLHFCQUFnQixHQUFZLEtBQUssQ0FBQztRQUtoQyx3QkFBbUIsR0FBK0IsSUFBSSxZQUFZLEVBQUUsQ0FBQztJQU8zRSxDQUFDO0lBRUwsUUFBUTtRQUNKLElBQUksQ0FBQyxVQUFVLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxDQUFDO1FBQ2pDLElBQUksQ0FBQyxRQUFRLEVBQUUsQ0FBQztRQUNoQixJQUFJLENBQUMsZ0JBQWdCLEVBQUUsQ0FBQztRQUN4QixJQUFJLE9BQU8sSUFBSSxDQUFDLFVBQVUsS0FBSyxXQUFXLElBQUksTUFBTSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLENBQUMsTUFBTSxLQUFLLENBQUMsRUFBRTtZQUNyRixJQUFJLENBQUMsWUFBWSxHQUFHLEtBQUssQ0FBQztZQUMxQixPQUFPO1NBQ1Y7UUFDRCxJQUFJLENBQUMscUJBQXFCLEVBQUUsQ0FBQztJQUNqQyxDQUFDO0lBRUQsV0FBVyxDQUFDLGNBQTZCO1FBQ3JDLElBQUksY0FBYyxDQUFDLGNBQWMsQ0FBQyxZQUFZLENBQUMsSUFBSSxDQUFDLGNBQWMsQ0FBQyxZQUFZLENBQUMsQ0FBQyxXQUFXLEVBQUU7WUFDMUYsSUFBSSxDQUFDLFVBQVUsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLENBQUM7U0FDcEM7UUFDRCxJQUFJLGNBQWMsQ0FBQyxjQUFjLENBQUMsWUFBWSxDQUFDLElBQUksQ0FBQyxjQUFjLENBQUMsWUFBWSxDQUFDLENBQUMsV0FBVyxJQUFJLE1BQU0sQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxDQUFDLE1BQU0sS0FBSyxDQUFDLEVBQUU7WUFDdkksSUFBSSxDQUFDLElBQUksQ0FBQyxZQUFZO2dCQUFFLElBQUksQ0FBQyxZQUFZLEdBQUcsSUFBSSxDQUFDO1lBQ2pELElBQUksQ0FBQyxxQkFBcUIsRUFBRSxDQUFDO1lBQzdCLElBQUksQ0FBQyxNQUFNLENBQUMsY0FBYyxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsQ0FBQztZQUN6QyxJQUFJLElBQUksQ0FBQyxnQkFBZ0IsRUFBRTtnQkFDdkIsSUFBSSxJQUFJLENBQUMsV0FBVyxDQUFDLGNBQWMsQ0FBQyxXQUFXLENBQUM7b0JBQUUsSUFBSSxDQUFDLFlBQVksRUFBRSxDQUFDOztvQkFDakUsVUFBVSxDQUFDLEdBQUcsRUFBRSxDQUFDLElBQUksQ0FBQyxZQUFZLEVBQUUsQ0FBQyxDQUFDO2FBQzlDO1NBQ0o7SUFDTCxDQUFDO0lBRUQsZUFBZTtRQUNYLElBQUksT0FBTyxJQUFJLENBQUMsVUFBVSxLQUFLLFdBQVcsSUFBSSxNQUFNLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsQ0FBQyxNQUFNLEtBQUssQ0FBQztZQUFFLE9BQU87UUFDaEcsSUFBSSxDQUFDLE1BQU0sQ0FBQyxjQUFjLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxDQUFDO1FBQ3pDLElBQUksSUFBSSxDQUFDLGdCQUFnQjtZQUFFLFVBQVUsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxJQUFJLENBQUMsWUFBWSxFQUFFLENBQUMsQ0FBQztJQUNyRSxDQUFDO0lBRU0sa0JBQWtCLENBQUMsYUFBMkI7UUFDakQsSUFBSSxDQUFDLG1CQUFtQixDQUFDLElBQUksQ0FBQyxhQUFhLENBQUMsQ0FBQztJQUNqRCxDQUFDO0lBRU8sUUFBUTtRQUNaLElBQUksT0FBTyxJQUFJLENBQUMsR0FBRyxLQUFLLFdBQVcsRUFBRTtZQUNqQyxJQUFJLENBQUMsR0FBRyxDQUFDLElBQUksR0FBRyxDQUFDLE9BQWUsRUFBUSxFQUFFLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLENBQUM7U0FDN0U7SUFDTCxDQUFDO0lBRU8sZ0JBQWdCO1FBQ3BCLElBQUksT0FBTyxJQUFJLENBQUMsV0FBVyxLQUFLLFdBQVcsRUFBRTtZQUN6QyxJQUFJLENBQUMsV0FBVyxDQUFDLGFBQWEsR0FBRyxDQUFDLEtBQW1CLEVBQUUsV0FBbUIsRUFBUSxFQUFFO2dCQUNoRixJQUFJLGFBQWEsR0FBK0MsSUFBSSxDQUFDLFdBQVcsQ0FBQyxxQkFBcUIsQ0FBQyxJQUFJLENBQUMsS0FBSyxFQUFFLEtBQUssRUFBRSxXQUFXLENBQUMsQ0FBQztnQkFDdkksS0FBSyxJQUFJLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxHQUFHLGFBQWEsQ0FBQyxNQUFNLEVBQUUsRUFBRSxDQUFDLEVBQUU7b0JBQzNDLElBQUksQ0FBQyxXQUFXLENBQUMscUJBQXFCLENBQUMsYUFBYSxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxRQUFRLEVBQUUsQ0FBQyxDQUFDLGFBQWEsQ0FBQyxhQUFhLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUM7aUJBQ3BIO1lBQ0wsQ0FBQyxDQUFDO1lBQ0YsSUFBSSxDQUFDLFdBQVcsQ0FBQyxxQkFBcUIsR0FBRyxDQUFDLElBQVksRUFBMkIsRUFBRSxDQUFDLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxJQUFJLENBQUMsQ0FBQztTQUNySDtJQUNMLENBQUM7SUFFTyxVQUFVLENBQUMsT0FBMkI7UUFDMUMsSUFBSSxDQUFDLE1BQU0sR0FBRyxJQUFJLENBQUMsUUFBUSxDQUFDLGVBQWUsQ0FBQyxhQUFhLEVBQUUsSUFBSSxDQUFDLFVBQVUsQ0FBQyxDQUFDO1FBQzVFLElBQUksQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLEtBQUssR0FBRyxJQUFJLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxLQUFLLElBQUksR0FBRyxDQUFDO1FBQ3ZELElBQUksSUFBSSxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsS0FBSztZQUFFLElBQUksQ0FBQyxTQUFTLEdBQUcsSUFBSSxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDO1FBQ3BFLElBQUksQ0FBQyxZQUFZLENBQUMsWUFBWSxHQUFHLElBQUksQ0FBQyxNQUFNLENBQUMsWUFBWSxDQUFDO1FBQzFELElBQUksQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLEdBQUcsSUFBSSxDQUFDLE1BQU0sQ0FBQyxZQUFZLENBQUM7UUFDdEQsSUFBSSxJQUFJLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxjQUFjLElBQUksT0FBTyxJQUFJLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxjQUFjLEtBQUssUUFBUTtZQUFFLElBQUksQ0FBQyxnQkFBZ0IsR0FBRyxJQUFJLENBQUM7SUFDN0gsQ0FBQztJQUVPLHFCQUFxQjtRQUN6QixJQUFJLENBQUMsa0JBQWtCLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxDQUFDO1FBQ3pDLElBQUksQ0FBQyxnQkFBZ0IsR0FBRyxJQUFJLENBQUMsZ0JBQWdCLElBQUksSUFBSSxDQUFDLFdBQVcsQ0FBQyxpQkFBaUIsQ0FBQyxJQUFJLENBQUMsS0FBSyxFQUFFLElBQUksQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLGNBQWMsQ0FBQyxDQUFDO1FBRWpJLDBFQUEwRTtRQUMxRSxJQUFJLENBQUMsTUFBTSxHQUFHLElBQUksQ0FBQyxXQUFXLENBQUMscUJBQXFCLENBQUMsSUFBSSxDQUFDLEtBQUssRUFBRSxJQUFJLENBQUMsS0FBSyxFQUFFLElBQUksQ0FBQyxPQUFPLENBQUMsQ0FBQztRQUUzRjs7OztXQUlHO1FBQ0gsSUFBSSxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxFQUFFLEVBQUU7WUFDL0IsSUFBSSxDQUFDLElBQUksQ0FBQyxZQUFZLEVBQUUsQ0FBQztRQUM3QixDQUFDLENBQUMsQ0FBQztRQUVILElBQUksQ0FBQyxNQUFNLENBQUMsZUFBZSxDQUFDLFNBQVMsQ0FBQyxDQUFDLEtBQUssRUFBRSxFQUFFO1lBQzVDLElBQUksQ0FBQyxlQUFlLEVBQUUsQ0FBQztRQUMzQixDQUFDLENBQUMsQ0FBQztJQUNQLENBQUM7SUFFTyxrQkFBa0IsQ0FBQyxXQUE0QztRQUNuRSxJQUFJLE9BQTZHLENBQUM7UUFDbEgsT0FBTyxHQUFHLElBQUksQ0FBQyxXQUFXLENBQUMsT0FBTyxDQUFDLFdBQVcsQ0FBQyxDQUFDO1FBQ2hELElBQUksQ0FBQyxZQUFZLEdBQUcsT0FBTyxDQUFDLFlBQVksQ0FBQztRQUN6QyxJQUFJLENBQUMsS0FBSyxHQUFHLE9BQU8sQ0FBQyxLQUFLLENBQUM7UUFDM0IsSUFBSSxDQUFDLE9BQU8sQ0FBQyxLQUFLLEdBQUcsSUFBSSxDQUFDLGVBQWUsRUFBRSxDQUFDO1FBQzVDLElBQUksQ0FBQyxPQUFPLENBQUMsYUFBYSxHQUFHLElBQUksQ0FBQyx1QkFBdUIsRUFBRSxDQUFDO1FBQzVELElBQUksQ0FBQyxLQUFLLEdBQUcsSUFBSSxDQUFDLFdBQVcsQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLEtBQUssRUFBRSxJQUFJLENBQUMsT0FBTyxDQUFDLGFBQWEsRUFBRSxPQUFPLENBQUMsU0FBUyxDQUFDLENBQUM7SUFDdEcsQ0FBQztJQUVPLGVBQWU7UUFDbkIsT0FBTyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsZ0JBQWdCLEdBQUcsSUFBSSxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLEdBQUcsSUFBSSxDQUFDLFlBQVksR0FBRyxJQUFJLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxLQUFLLEdBQUcsQ0FBQyxHQUFHLElBQUksQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDO0lBQzFJLENBQUM7SUFFTyx1QkFBdUI7UUFDM0IsSUFBSSxRQUFRLEdBQThCLEVBQUUsQ0FBQztRQUM3QyxLQUFLLElBQUksQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLEdBQUcsSUFBSSxDQUFDLFlBQVksR0FBRyxDQUFDLEVBQUUsRUFBRSxDQUFDLEVBQUU7WUFDNUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxRQUFRLEVBQUUsQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLEtBQUssR0FBRyxJQUFJLENBQUMsTUFBTSxDQUFDLGdCQUFnQixDQUFDLEdBQUcsSUFBSSxDQUFDLE1BQU0sQ0FBQyxPQUFPLEdBQUcsSUFBSSxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsS0FBSyxHQUFHLENBQUMsQ0FBQztTQUMzSTtRQUNELE9BQU8sUUFBUSxDQUFDO0lBQ3BCLENBQUM7SUFFRDs7O01BR0U7SUFDTSxZQUFZO1FBQ2hCLElBQUksTUFBTSxHQUFHO1lBQ1QsUUFBUSxFQUFFLElBQUksQ0FBQyxRQUFRLENBQUMsYUFBYSxDQUFDLGFBQWEsQ0FBQyxtQ0FBbUMsQ0FBQyxDQUFDLHFCQUFxQixFQUFFLENBQUMsS0FBSztZQUN0SCxTQUFTLEVBQUUsSUFBSSxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsS0FBSztZQUNqQyxPQUFPLEVBQUUsSUFBSSxDQUFDLE1BQU0sQ0FBQyxPQUFPO1NBQy9CLENBQUM7UUFDRixJQUFJLFNBQVMsR0FBVyxJQUFJLENBQUMsV0FBVyxDQUFDLGtCQUFrQixDQUFDLE1BQU0sRUFBRSxJQUFJLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsSUFBSSxDQUFDLGNBQWMsQ0FBQyxFQUFFLE9BQU8sQ0FBQyxDQUFDO1FBQzlILElBQUksQ0FBQyxXQUFXLENBQUMsU0FBUyxDQUFDLFNBQVMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxLQUFLLEVBQUUsR0FBRyxFQUFFLENBQUMsSUFBSSxDQUFDLGdCQUFnQixFQUFFLENBQUMsQ0FBQztJQUNuRixDQUFDO0lBRU8sZUFBZTtRQUNuQixJQUFJLENBQUMsY0FBYyxHQUFHLElBQUksQ0FBQztRQUMzQixJQUFJLElBQUksQ0FBQyxlQUFlLElBQUksQ0FBQyxJQUFJLENBQUMsZ0JBQWdCO1lBQUUsSUFBSSxDQUFDLFVBQVUsR0FBRyxLQUFLLENBQUM7SUFDaEYsQ0FBQztJQUVPLGdCQUFnQjtRQUNwQixJQUFJLENBQUMsZUFBZSxHQUFHLElBQUksQ0FBQztRQUM1QixJQUFJLElBQUksQ0FBQyxjQUFjO1lBQUUsSUFBSSxDQUFDLFVBQVUsR0FBRyxLQUFLLENBQUM7SUFDckQsQ0FBQzs7O1lBaExKLFNBQVMsU0FBQztnQkFDUCxRQUFRLEVBQUUsWUFBWTtnQkFDdEIsMndHQUF3QztnQkFDeEMsU0FBUyxFQUFFLENBQUMsWUFBWSxFQUFFLFNBQVMsQ0FBQztnQkFDcEMsYUFBYSxFQUFFLGlCQUFpQixDQUFDLElBQUk7Z0JBQ3JDLGVBQWUsRUFBRSx1QkFBdUIsQ0FBQyxNQUFNO2dCQUMvQyxJQUFJLEVBQUU7b0JBQ0YsT0FBTyxFQUFFLGFBQWE7b0JBQ3RCLFdBQVcsRUFBRSxXQUFXO2lCQUMzQjthQUNKOzs7WUF4QlEsWUFBWTtZQUZaLFNBQVM7WUFKZCxVQUFVO1lBRFYsaUJBQWlCOzs7eUJBeURoQixLQUFLLFNBQUMsT0FBTzt5QkFDYixLQUFLLFNBQUMsUUFBUTtrQkFDZCxLQUFLO2tDQUNMLE1BQU0iLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQge1xyXG4gICAgQ29tcG9uZW50LFxyXG4gICAgVmlld0VuY2Fwc3VsYXRpb24sXHJcbiAgICBJbnB1dCxcclxuICAgIE91dHB1dCxcclxuICAgIE9uSW5pdCxcclxuICAgIE9uQ2hhbmdlcyxcclxuICAgIFNpbXBsZUNoYW5nZXMsXHJcbiAgICBDaGFuZ2VEZXRlY3RvclJlZixcclxuICAgIEVsZW1lbnRSZWYsXHJcbiAgICBDaGFuZ2VEZXRlY3Rpb25TdHJhdGVneSxcclxuICAgIEV2ZW50RW1pdHRlclxyXG59IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xyXG5pbXBvcnQgeyBLZERhdGFTdmMgfSBmcm9tICcuLi9rZC1jb21tb24vaW5kZXgnO1xyXG5pbXBvcnQgeyBGb3JjZURpcmVjdGVkR3JhcGggfSBmcm9tICcuL2tkLWFuZ3VsYXItbWluZG1hcC1mb3JjZS1sb2dpYyc7XHJcbmltcG9ydCB7IEtkTWluZG1hcFN2YyB9IGZyb20gJy4va2QtYW5ndWxhci1taW5kbWFwLXN2Yyc7XHJcbmltcG9ydCB7XHJcbiAgICBJTWluZG1hcE9wdGlvbnMsXHJcbiAgICBJWm9vbUJ1dHRvbkNvbmZpZyxcclxuICAgIElNaW5kbWFwSW50ZXJuYWxBcGksXHJcbiAgICBJSW50ZXJuYWxBbGxDb25maWcsXHJcbiAgICBJTWluZG1hcEludGVybmFsTGlua0FwaVJlZixcclxuICAgIElNaW5kbWFwSW50ZXJuYWxMaW5rQXBpLFxyXG4gICAgSU1pbmRtYXBOb2RlLCBcclxuICAgIElNaW5kbWFwTGluaywgXHJcbiAgICBJTWluZG1hcEFwaVxyXG59IGZyb20gJy4va2QtYW5ndWxhci1taW5kbWFwLWludGVyZmFjZSc7XHJcbmltcG9ydCB7IGRlZmF1bHRDb25maWcgfSBmcm9tICcuL2tkLWFuZ3VsYXItbWluZG1hcC1jb25maWcnO1xyXG5cclxuQENvbXBvbmVudCh7XHJcbiAgICBzZWxlY3RvcjogJ2tkLW1pbmRtYXAnLFxyXG4gICAgdGVtcGxhdGVVcmw6ICcuL2tkLWFuZ3VsYXItbWluZG1hcC5odG1sJyxcclxuICAgIHByb3ZpZGVyczogW0tkTWluZG1hcFN2YywgS2REYXRhU3ZjXSxcclxuICAgIGVuY2Fwc3VsYXRpb246IFZpZXdFbmNhcHN1bGF0aW9uLk5vbmUsXHJcbiAgICBjaGFuZ2VEZXRlY3Rpb246IENoYW5nZURldGVjdGlvblN0cmF0ZWd5Lk9uUHVzaCxcclxuICAgIGhvc3Q6IHtcclxuICAgICAgICAnY2xhc3MnOiAna2R4LW1pbmRtYXAnLFxyXG4gICAgICAgICdbYXR0ci5pZF0nOiAnY29uZmlnLmlkJyxcclxuICAgIH1cclxufSlcclxuXHJcbmV4cG9ydCBjbGFzcyBLZE1pbmRtYXAgaW1wbGVtZW50cyBPbkluaXQsIE9uQ2hhbmdlcyB7XHJcbiAgICBwdWJsaWMgY29uZmlnOiBJSW50ZXJuYWxBbGxDb25maWc7XHJcbiAgICBwdWJsaWMgbm9kZXM6IEFycmF5PElNaW5kbWFwTm9kZT47XHJcbiAgICBwdWJsaWMgbGlua3M6IEFycmF5PElNaW5kbWFwTGluaz47XHJcbiAgICBwdWJsaWMgaGlnaGVzdENvdW50OiBudW1iZXI7XHJcbiAgICBwdWJsaWMgaW50ZXJuYWxBcGk6IElNaW5kbWFwSW50ZXJuYWxBcGkgPSB7fTtcclxuICAgIHB1YmxpYyBpbnRlcm5hbExpbmtBcGlSZWY6IElNaW5kbWFwSW50ZXJuYWxMaW5rQXBpUmVmID0ge307XHJcbiAgICBwdWJsaWMgZGlzcGxheUdyYXBoOiBib29sZWFuID0gdHJ1ZTtcclxuICAgIHB1YmxpYyBsaW5rQ2xhc3M6IHN0cmluZyA9ICcnO1xyXG4gICAgcHVibGljIG9wdGlvbnM6IElNaW5kbWFwT3B0aW9ucyA9IHsgd2lkdGg6IDAsIGhlaWdodDogNjAwLCBsZXZlbFBvc2l0aW9uOiB7ICcwJzogMTAgfSB9O1xyXG4gICAgcHVibGljIHNob3dMb2FkZXI6IGJvb2xlYW4gPSB0cnVlO1xyXG4gICAgcHVibGljIHNtYWxsTG9hZGVyVmFsdWU6IGFueSA9IG51bGw7XHJcblxyXG4gICAgcHVibGljIGJ1dHRvbkNvbmZpZzogSVpvb21CdXR0b25Db25maWcgPSB7XHJcbiAgICAgICAgY29vcmQ6IHsgeDogMjUsIHk6IDI1IH0sXHJcbiAgICAgICAgc2l6ZTogMzAsXHJcbiAgICAgICAgaWNvblNpemU6IDIwLFxyXG4gICAgICAgIG1hcmdpbkJvdHRvbTogMTAsXHJcbiAgICB9O1xyXG4gICAgcHJpdmF0ZSBfZ3JhcGg6IEZvcmNlRGlyZWN0ZWRHcmFwaDtcclxuICAgIHByaXZhdGUgX3NpbXVsYXRpb25FbmQ6IGJvb2xlYW4gPSBmYWxzZTtcclxuICAgIHByaXZhdGUgX3RyYW5zbGF0aW9uRW5kOiBib29sZWFuID0gZmFsc2U7XHJcbiAgICBwcml2YXRlIF9oYXNTZWxlY3RlZE5vZGU6IGJvb2xlYW4gPSBmYWxzZTtcclxuXHJcbiAgICBASW5wdXQoJ25vZGVzJykgaW5wdXROb2RlczogYW55O1xyXG4gICAgQElucHV0KCdjb25maWcnKSBtYWluQ29uZmlnOiBhbnk7XHJcbiAgICBASW5wdXQoKSBhcGk6IElNaW5kbWFwQXBpO1xyXG4gICAgQE91dHB1dCgpIHNlbGVjdGVkTm9kZUVtaXR0ZXI6IEV2ZW50RW1pdHRlcjxJTWluZG1hcE5vZGU+ID0gbmV3IEV2ZW50RW1pdHRlcigpO1xyXG5cclxuICAgIGNvbnN0cnVjdG9yKFxyXG4gICAgICAgIHByaXZhdGUgX21pbmRtYXBTdmM6IEtkTWluZG1hcFN2YyxcclxuICAgICAgICBwcml2YXRlIF9kYXRhU3ZjOiBLZERhdGFTdmMsXHJcbiAgICAgICAgcHJpdmF0ZSBfZWxlbVJlZjogRWxlbWVudFJlZixcclxuICAgICAgICBwcml2YXRlIF9yZWY6IENoYW5nZURldGVjdG9yUmVmLFxyXG4gICAgKSB7IH1cclxuXHJcbiAgICBuZ09uSW5pdCgpOiB2b2lkIHtcclxuICAgICAgICB0aGlzLl9zZXRDb25maWcodGhpcy5tYWluQ29uZmlnKTtcclxuICAgICAgICB0aGlzLl9pbml0QXBpKCk7XHJcbiAgICAgICAgdGhpcy5faW5pdEludGVybmFsQXBpKCk7XHJcbiAgICAgICAgaWYgKHR5cGVvZiB0aGlzLmlucHV0Tm9kZXMgPT09ICd1bmRlZmluZWQnIHx8IE9iamVjdC5rZXlzKHRoaXMuaW5wdXROb2RlcykubGVuZ3RoID09PSAwKSB7XHJcbiAgICAgICAgICAgIHRoaXMuZGlzcGxheUdyYXBoID0gZmFsc2U7XHJcbiAgICAgICAgICAgIHJldHVybjtcclxuICAgICAgICB9XHJcbiAgICAgICAgdGhpcy5fc3RhcnRTZXREYXRhQW5kR3JhcGgoKTtcclxuICAgIH1cclxuXHJcbiAgICBuZ09uQ2hhbmdlcyhfc2ltcGxlQ2hhbmdlczogU2ltcGxlQ2hhbmdlcyk6IHZvaWQge1xyXG4gICAgICAgIGlmIChfc2ltcGxlQ2hhbmdlcy5oYXNPd25Qcm9wZXJ0eSgnbWFpbkNvbmZpZycpICYmICFfc2ltcGxlQ2hhbmdlc1snbWFpbkNvbmZpZyddLmZpcnN0Q2hhbmdlKSB7XHJcbiAgICAgICAgICAgIHRoaXMuX3NldENvbmZpZyh0aGlzLm1haW5Db25maWcpO1xyXG4gICAgICAgIH1cclxuICAgICAgICBpZiAoX3NpbXBsZUNoYW5nZXMuaGFzT3duUHJvcGVydHkoJ2lucHV0Tm9kZXMnKSAmJiAhX3NpbXBsZUNoYW5nZXNbJ2lucHV0Tm9kZXMnXS5maXJzdENoYW5nZSAmJiBPYmplY3Qua2V5cyh0aGlzLmlucHV0Tm9kZXMpLmxlbmd0aCAhPT0gMCkge1xyXG4gICAgICAgICAgICBpZiAoIXRoaXMuZGlzcGxheUdyYXBoKSB0aGlzLmRpc3BsYXlHcmFwaCA9IHRydWU7XHJcbiAgICAgICAgICAgIHRoaXMuX3N0YXJ0U2V0RGF0YUFuZEdyYXBoKCk7XHJcbiAgICAgICAgICAgIHRoaXMuX2dyYXBoLmluaXRTaW11bGF0aW9uKHRoaXMub3B0aW9ucyk7XHJcbiAgICAgICAgICAgIGlmICh0aGlzLl9oYXNTZWxlY3RlZE5vZGUpIHtcclxuICAgICAgICAgICAgICAgIGlmICh0aGlzLmludGVybmFsQXBpLmhhc093blByb3BlcnR5KCd0cmFuc2xhdGUnKSkgdGhpcy5fc2V0SW5pdFBvc1goKTtcclxuICAgICAgICAgICAgICAgIGVsc2Ugc2V0VGltZW91dCgoKSA9PiB0aGlzLl9zZXRJbml0UG9zWCgpKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICBuZ0FmdGVyVmlld0luaXQoKTogdm9pZCB7XHJcbiAgICAgICAgaWYgKHR5cGVvZiB0aGlzLmlucHV0Tm9kZXMgPT09ICd1bmRlZmluZWQnIHx8IE9iamVjdC5rZXlzKHRoaXMuaW5wdXROb2RlcykubGVuZ3RoID09PSAwKSByZXR1cm47XHJcbiAgICAgICAgdGhpcy5fZ3JhcGguaW5pdFNpbXVsYXRpb24odGhpcy5vcHRpb25zKTtcclxuICAgICAgICBpZiAodGhpcy5faGFzU2VsZWN0ZWROb2RlKSBzZXRUaW1lb3V0KCgpID0+IHRoaXMuX3NldEluaXRQb3NYKCkpO1xyXG4gICAgfVxyXG5cclxuICAgIHB1YmxpYyBvdXRwdXRTZWxlY3RlZE5vZGUoX3NlbGVjdGVkTm9kZTogSU1pbmRtYXBOb2RlKTogdm9pZCB7XHJcbiAgICAgICAgdGhpcy5zZWxlY3RlZE5vZGVFbWl0dGVyLmVtaXQoX3NlbGVjdGVkTm9kZSk7XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfaW5pdEFwaSgpOiB2b2lkIHtcclxuICAgICAgICBpZiAodHlwZW9mIHRoaXMuYXBpICE9PSAndW5kZWZpbmVkJykge1xyXG4gICAgICAgICAgICB0aGlzLmFwaS56b29tID0gKF9hY3Rpb246IHN0cmluZyk6IHZvaWQgPT4gdGhpcy5pbnRlcm5hbEFwaS56b29tKF9hY3Rpb24pO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF9pbml0SW50ZXJuYWxBcGkoKTogdm9pZCB7XHJcbiAgICAgICAgaWYgKHR5cGVvZiB0aGlzLmludGVybmFsQXBpICE9PSAndW5kZWZpbmVkJykge1xyXG4gICAgICAgICAgICB0aGlzLmludGVybmFsQXBpLnNldE5vZGVIZWlnaHQgPSAoX25vZGU6IElNaW5kbWFwTm9kZSwgX25vZGVIZWlnaHQ6IG51bWJlcik6IHZvaWQgPT4ge1xyXG4gICAgICAgICAgICAgICAgbGV0IGFmZmVjdGVkTGlua3M6IEFycmF5PHsgaW5kZXg/OiBudW1iZXIsIG9mZnNldD86IG51bWJlciB9PiA9IHRoaXMuX21pbmRtYXBTdmMuc2V0TGlua1NwcmVhZERpc3RhbmNlKHRoaXMubGlua3MsIF9ub2RlLCBfbm9kZUhlaWdodCk7XHJcbiAgICAgICAgICAgICAgICBmb3IgKGxldCBpID0gMDsgaSA8IGFmZmVjdGVkTGlua3MubGVuZ3RoOyArK2kpIHtcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLmludGVybmFsQXBpLmFjY2Vzc0ludGVybmFsTGlua0FwaShhZmZlY3RlZExpbmtzW2ldLmluZGV4LnRvU3RyaW5nKCkpLnNldExpbmtPZmZzZXQoYWZmZWN0ZWRMaW5rc1tpXS5vZmZzZXQpO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9O1xyXG4gICAgICAgICAgICB0aGlzLmludGVybmFsQXBpLmFjY2Vzc0ludGVybmFsTGlua0FwaSA9IChfa2V5OiBzdHJpbmcpOiBJTWluZG1hcEludGVybmFsTGlua0FwaSA9PiB0aGlzLmludGVybmFsTGlua0FwaVJlZltfa2V5XTtcclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfc2V0Q29uZmlnKF9jb25maWc6IElJbnRlcm5hbEFsbENvbmZpZyk6IHZvaWQge1xyXG4gICAgICAgIHRoaXMuY29uZmlnID0gdGhpcy5fZGF0YVN2Yy5kZWVwTWVyZ2VPYmplY3QoZGVmYXVsdENvbmZpZywgdGhpcy5tYWluQ29uZmlnKTtcclxuICAgICAgICB0aGlzLmNvbmZpZy5ub2RlLndpZHRoID0gdGhpcy5jb25maWcubm9kZS53aWR0aCB8fCAyMDA7XHJcbiAgICAgICAgaWYgKHRoaXMuY29uZmlnLmxpbmsuY2xhc3MpIHRoaXMubGlua0NsYXNzID0gdGhpcy5jb25maWcubGluay5jbGFzcztcclxuICAgICAgICB0aGlzLmJ1dHRvbkNvbmZpZy5pY29uTGlua1BhdGggPSB0aGlzLmNvbmZpZy5pY29uTGlua1BhdGg7XHJcbiAgICAgICAgdGhpcy5jb25maWcubm9kZS5pY29uLmxpbmsgPSB0aGlzLmNvbmZpZy5pY29uTGlua1BhdGg7XHJcbiAgICAgICAgaWYgKHRoaXMuY29uZmlnLm5vZGUuc2VsZWN0T25Mb2FkSWQgJiYgdHlwZW9mIHRoaXMuY29uZmlnLm5vZGUuc2VsZWN0T25Mb2FkSWQgPT09ICdudW1iZXInKSB0aGlzLl9oYXNTZWxlY3RlZE5vZGUgPSB0cnVlO1xyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX3N0YXJ0U2V0RGF0YUFuZEdyYXBoKCk6IHZvaWQge1xyXG4gICAgICAgIHRoaXMuX3NldERhdGFBbmRPcHRpb25zKHRoaXMuaW5wdXROb2Rlcyk7XHJcbiAgICAgICAgdGhpcy5faGFzU2VsZWN0ZWROb2RlID0gdGhpcy5faGFzU2VsZWN0ZWROb2RlICYmIHRoaXMuX21pbmRtYXBTdmMuZm91bmRTZWxlY3RlZE5vZGUodGhpcy5ub2RlcywgdGhpcy5jb25maWcubm9kZS5zZWxlY3RPbkxvYWRJZCk7XHJcblxyXG4gICAgICAgIC8qKiBSZWNlaXZpbmcgYW4gaW5pdGlhbGl6ZWQgc2ltdWxhdGVkIGdyYXBoIGZyb20gb3VyIGN1c3RvbSBkMyBzZXJ2aWNlICovXHJcbiAgICAgICAgdGhpcy5fZ3JhcGggPSB0aGlzLl9taW5kbWFwU3ZjLmdldEZvcmNlRGlyZWN0ZWRHcmFwaCh0aGlzLm5vZGVzLCB0aGlzLmxpbmtzLCB0aGlzLm9wdGlvbnMpO1xyXG5cclxuICAgICAgICAvKiogQmluZGluZyBjaGFuZ2UgZGV0ZWN0aW9uIGNoZWNrIG9uIGVhY2ggdGlja1xyXG4gICAgICAgICAqIFRoaXMgYWxvbmcgd2l0aCBhbiBvblB1c2ggY2hhbmdlIGRldGVjdGlvbiBzdHJhdGVneSBzaG91bGQgZW5mb3JjZSBjaGVja2luZyBvbmx5IHdoZW4gcmVsZXZhbnQhXHJcbiAgICAgICAgICogVGhpcyBpbXByb3ZlcyBzY3JpcHRpbmcgY29tcHV0YXRpb24gZHVyYXRpb24gaW4gYSBjb3VwbGUgb2YgdGVzdHMgSSd2ZSBtYWRlLCBjb25zaXN0ZW50bHkuXHJcbiAgICAgICAgICogQWxzbywgaXQgbWFrZXMgc2Vuc2UgdG8gYXZvaWQgdW5uZWNlc3NhcnkgY2hlY2tzIHdoZW4gd2UgYXJlIGRlYWxpbmcgb25seSB3aXRoIHNpbXVsYXRpb25zIGRhdGEgYmluZGluZy5cclxuICAgICAgICAgKi9cclxuICAgICAgICB0aGlzLl9ncmFwaC50aWNrZXIuc3Vic2NyaWJlKChkKSA9PiB7XHJcbiAgICAgICAgICAgIHRoaXMuX3JlZi5tYXJrRm9yQ2hlY2soKTtcclxuICAgICAgICB9KTtcclxuXHJcbiAgICAgICAgdGhpcy5fZ3JhcGgub25TaW11bGF0aW9uRW5kLnN1YnNjcmliZSgoX2ZsYWcpID0+IHtcclxuICAgICAgICAgICAgdGhpcy5vblNpbXVsYXRpb25FbmQoKTtcclxuICAgICAgICB9KTtcclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF9zZXREYXRhQW5kT3B0aW9ucyhfaW5wdXROb2RlczogeyBba2V5OiBzdHJpbmddOiBJTWluZG1hcE5vZGUgfSk6IHZvaWQge1xyXG4gICAgICAgIGxldCBuZXdEYXRhOiB7IG5vZGVzOiBBcnJheTxJTWluZG1hcE5vZGU+LCBsaW5rczogQXJyYXk8SU1pbmRtYXBMaW5rPiwgaGlnaGVzdENvdW50OiBudW1iZXIsIGhhdmVMb25lcjogYm9vbGVhbiB9O1xyXG4gICAgICAgIG5ld0RhdGEgPSB0aGlzLl9taW5kbWFwU3ZjLnNldERhdGEoX2lucHV0Tm9kZXMpO1xyXG4gICAgICAgIHRoaXMuaGlnaGVzdENvdW50ID0gbmV3RGF0YS5oaWdoZXN0Q291bnQ7XHJcbiAgICAgICAgdGhpcy5saW5rcyA9IG5ld0RhdGEubGlua3M7XHJcbiAgICAgICAgdGhpcy5vcHRpb25zLndpZHRoID0gdGhpcy5fY2FsY3VsYXRlV2lkdGgoKTtcclxuICAgICAgICB0aGlzLm9wdGlvbnMubGV2ZWxQb3NpdGlvbiA9IHRoaXMuX2NhbGN1bGF0ZUxldmVsUG9zaXRpb24oKTtcclxuICAgICAgICB0aGlzLm5vZGVzID0gdGhpcy5fbWluZG1hcFN2Yy5zZXRGeChuZXdEYXRhLm5vZGVzLCB0aGlzLm9wdGlvbnMubGV2ZWxQb3NpdGlvbiwgbmV3RGF0YS5oYXZlTG9uZXIpO1xyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX2NhbGN1bGF0ZVdpZHRoKCk6IG51bWJlciB7XHJcbiAgICAgICAgcmV0dXJuICh0aGlzLmNvbmZpZy5sZXZlbFJpZ2h0TWFyZ2luICsgdGhpcy5jb25maWcubm9kZS53aWR0aCkgKiB0aGlzLmhpZ2hlc3RDb3VudCArIHRoaXMuY29uZmlnLm5vZGUud2lkdGggKyAyICogdGhpcy5jb25maWcucGFkZGluZztcclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF9jYWxjdWxhdGVMZXZlbFBvc2l0aW9uKCk6IHsgW2tleTogc3RyaW5nXTogbnVtYmVyIH0ge1xyXG4gICAgICAgIGxldCBwb3NpdGlvbjogeyBba2V5OiBzdHJpbmddOiBudW1iZXIgfSA9IHt9O1xyXG4gICAgICAgIGZvciAobGV0IGkgPSAwOyBpIDwgdGhpcy5oaWdoZXN0Q291bnQgKyAxOyArK2kpIHtcclxuICAgICAgICAgICAgcG9zaXRpb25baS50b1N0cmluZygpXSA9IGkgKiAodGhpcy5jb25maWcubm9kZS53aWR0aCArIHRoaXMuY29uZmlnLmxldmVsUmlnaHRNYXJnaW4pICsgdGhpcy5jb25maWcucGFkZGluZyArIHRoaXMuY29uZmlnLm5vZGUud2lkdGggLyAyO1xyXG4gICAgICAgIH1cclxuICAgICAgICByZXR1cm4gcG9zaXRpb247XHJcbiAgICB9XHJcblxyXG4gICAgLyogX3NldEluaXRQb3NYIHNvbWV0aW1lcyBuZWVkcyBzZXRUaW1lb3V0IGZvciAyIHJlYXNvbnM6XHJcbiAgICAqIDEpIG9uIGZpcnN0IGxvYWQsIGdldEJvdW5kaW5nQ2xpZW50UmVjdCBpcyBub3QgcmVhZHlcclxuICAgICogMikgb24gc3Vic2VxdWVudCBsb2FkLCBuZWVkIHRvIG1ha2Ugc3VyZSBpbnRlcm5hbEFwaS50cmFuc2xhdGUgaXMgcHJlc2VudCAobWF5IG5vdCBiZSBwcmVzZW50IGJlY29zIGRpc3BsYXlHcmFwaCB3YXMgc2V0IHRvIGZhbHNlKVxyXG4gICAgKi9cclxuICAgIHByaXZhdGUgX3NldEluaXRQb3NYKCk6IHZvaWQge1xyXG4gICAgICAgIGxldCBjb25maWcgPSB7XHJcbiAgICAgICAgICAgIHN2Z1dpZHRoOiB0aGlzLl9lbGVtUmVmLm5hdGl2ZUVsZW1lbnQucXVlcnlTZWxlY3RvcignLmtkeC1taW5kbWFwICNrZHgtbWluZG1hcC13cmFwcGVyJykuZ2V0Qm91bmRpbmdDbGllbnRSZWN0KCkud2lkdGgsXHJcbiAgICAgICAgICAgIG5vZGVXaWR0aDogdGhpcy5jb25maWcubm9kZS53aWR0aCxcclxuICAgICAgICAgICAgcGFkZGluZzogdGhpcy5jb25maWcucGFkZGluZ1xyXG4gICAgICAgIH07XHJcbiAgICAgICAgbGV0IF9pbml0UG9zWDogbnVtYmVyID0gdGhpcy5fbWluZG1hcFN2Yy50cmFuc2xhdGVTdmdUb1hQb3MoY29uZmlnLCB0aGlzLm5vZGVzW3RoaXMubWFpbkNvbmZpZy5ub2RlLnNlbGVjdE9uTG9hZElkXSwgJ3JpZ2h0Jyk7XHJcbiAgICAgICAgdGhpcy5pbnRlcm5hbEFwaS50cmFuc2xhdGUoX2luaXRQb3NYKS5vbignZW5kJywgKCkgPT4gdGhpcy5vblRyYW5zbGF0aW9uRW5kKCkpO1xyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgb25TaW11bGF0aW9uRW5kKCkge1xyXG4gICAgICAgIHRoaXMuX3NpbXVsYXRpb25FbmQgPSB0cnVlO1xyXG4gICAgICAgIGlmICh0aGlzLl90cmFuc2xhdGlvbkVuZCB8fCAhdGhpcy5faGFzU2VsZWN0ZWROb2RlKSB0aGlzLnNob3dMb2FkZXIgPSBmYWxzZTtcclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIG9uVHJhbnNsYXRpb25FbmQoKSB7XHJcbiAgICAgICAgdGhpcy5fdHJhbnNsYXRpb25FbmQgPSB0cnVlO1xyXG4gICAgICAgIGlmICh0aGlzLl9zaW11bGF0aW9uRW5kKSB0aGlzLnNob3dMb2FkZXIgPSBmYWxzZTtcclxuICAgIH1cclxufVxyXG4iXX0=