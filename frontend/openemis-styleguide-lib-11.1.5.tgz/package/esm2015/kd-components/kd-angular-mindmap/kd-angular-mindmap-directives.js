import { Directive, Input, ElementRef } from '@angular/core';
import { KdMindmapSvc } from './kd-angular-mindmap-svc';
import { ForceDirectedGraph } from './kd-angular-mindmap-force-logic';
export class KdMindmapZoomDirective {
    constructor(_mindmapSvc, _element) {
        this._mindmapSvc = _mindmapSvc;
        this._element = _element;
    }
    ngOnInit() {
        this._zoomClass = this._mindmapSvc.getZoomClass(this.zoomableOf, this._element.nativeElement);
        this._zoomClass.applyZoomableBehaviour();
        this._initApi();
    }
    _initApi() {
        if (typeof this.internalApi !== 'undefined') {
            this.internalApi.zoom = (_action) => this._zoomClass.customZoom(_action);
            this.internalApi.scaleTo = (_scale) => this._zoomClass.scaleTo(_scale);
            this.internalApi.translate = (_x, _y) => this._zoomClass.translateSVG(_x, _y);
        }
    }
}
KdMindmapZoomDirective.decorators = [
    { type: Directive, args: [{
                selector: '[zoomableOf]',
            },] }
];
KdMindmapZoomDirective.ctorParameters = () => [
    { type: KdMindmapSvc },
    { type: ElementRef }
];
KdMindmapZoomDirective.propDecorators = {
    zoomableOf: [{ type: Input, args: ['zoomableOf',] }],
    internalApi: [{ type: Input, args: ['api',] }]
};
export class KdMindmapDragDirective {
    constructor(_mindmapSvc, _element) {
        this._mindmapSvc = _mindmapSvc;
        this._element = _element;
    }
    ngOnInit() {
        this._mindmapSvc.applyDraggableBehaviour(this._element.nativeElement, this.draggableNode, this.draggableInGraph);
    }
}
KdMindmapDragDirective.decorators = [
    { type: Directive, args: [{
                selector: '[draggableNode]'
            },] }
];
KdMindmapDragDirective.ctorParameters = () => [
    { type: KdMindmapSvc },
    { type: ElementRef }
];
KdMindmapDragDirective.propDecorators = {
    draggableNode: [{ type: Input, args: ['draggableNode',] }],
    draggableInGraph: [{ type: Input, args: ['draggableInGraph',] }]
};
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoia2QtYW5ndWxhci1taW5kbWFwLWRpcmVjdGl2ZXMuanMiLCJzb3VyY2VSb290IjoiQzoveGFtcHAvaHRkb2NzL1N0eWxlZ3VpZGUvaW9zdGctb3BlbmVtaXMtc3R5bGVndWlkZS9wcm9qZWN0cy9vcGVuZW1pcy1zdHlsZWd1aWRlLWxpYi9zcmMvIiwic291cmNlcyI6WyJrZC1jb21wb25lbnRzL2tkLWFuZ3VsYXItbWluZG1hcC9rZC1hbmd1bGFyLW1pbmRtYXAtZGlyZWN0aXZlcy50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQSxPQUFPLEVBQUUsU0FBUyxFQUFFLEtBQUssRUFBRSxVQUFVLEVBQVUsTUFBTSxlQUFlLENBQUM7QUFDckUsT0FBTyxFQUFFLFlBQVksRUFBRSxNQUFNLDBCQUEwQixDQUFDO0FBQ3hELE9BQU8sRUFBRSxrQkFBa0IsRUFBRSxNQUFNLGtDQUFrQyxDQUFDO0FBT3RFLE1BQU0sT0FBTyxzQkFBc0I7SUFNL0IsWUFBb0IsV0FBeUIsRUFBVSxRQUFvQjtRQUF2RCxnQkFBVyxHQUFYLFdBQVcsQ0FBYztRQUFVLGFBQVEsR0FBUixRQUFRLENBQVk7SUFBSSxDQUFDO0lBRWhGLFFBQVE7UUFDSixJQUFJLENBQUMsVUFBVSxHQUFHLElBQUksQ0FBQyxXQUFXLENBQUMsWUFBWSxDQUFDLElBQUksQ0FBQyxVQUFVLEVBQUUsSUFBSSxDQUFDLFFBQVEsQ0FBQyxhQUFhLENBQUMsQ0FBQztRQUM5RixJQUFJLENBQUMsVUFBVSxDQUFDLHNCQUFzQixFQUFFLENBQUM7UUFDekMsSUFBSSxDQUFDLFFBQVEsRUFBRSxDQUFDO0lBQ3BCLENBQUM7SUFFTyxRQUFRO1FBQ1osSUFBSSxPQUFPLElBQUksQ0FBQyxXQUFXLEtBQUssV0FBVyxFQUFFO1lBQ3pDLElBQUksQ0FBQyxXQUFXLENBQUMsSUFBSSxHQUFHLENBQUMsT0FBZSxFQUFRLEVBQUUsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLFVBQVUsQ0FBQyxPQUFPLENBQUMsQ0FBQztZQUN2RixJQUFJLENBQUMsV0FBVyxDQUFDLE9BQU8sR0FBRyxDQUFDLE1BQWMsRUFBUSxFQUFFLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLENBQUM7WUFDckYsSUFBSSxDQUFDLFdBQVcsQ0FBQyxTQUFTLEdBQUcsQ0FBQyxFQUFVLEVBQUUsRUFBVyxFQUFPLEVBQUUsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLFlBQVksQ0FBQyxFQUFFLEVBQUUsRUFBRSxDQUFDLENBQUM7U0FDdkc7SUFDTCxDQUFDOzs7WUF2QkosU0FBUyxTQUFDO2dCQUNQLFFBQVEsRUFBRSxjQUFjO2FBQzNCOzs7WUFQUSxZQUFZO1lBRE0sVUFBVTs7O3lCQVloQyxLQUFLLFNBQUMsWUFBWTswQkFDbEIsS0FBSyxTQUFDLEtBQUs7O0FBdUJoQixNQUFNLE9BQU8sc0JBQXNCO0lBSS9CLFlBQW9CLFdBQXlCLEVBQVUsUUFBb0I7UUFBdkQsZ0JBQVcsR0FBWCxXQUFXLENBQWM7UUFBVSxhQUFRLEdBQVIsUUFBUSxDQUFZO0lBQUksQ0FBQztJQUVoRixRQUFRO1FBQ0osSUFBSSxDQUFDLFdBQVcsQ0FBQyx1QkFBdUIsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLGFBQWEsRUFBRSxJQUFJLENBQUMsYUFBYSxFQUFFLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDO0lBQ3JILENBQUM7OztZQVhKLFNBQVMsU0FBQztnQkFDUCxRQUFRLEVBQUUsaUJBQWlCO2FBQzlCOzs7WUFsQ1EsWUFBWTtZQURNLFVBQVU7Ozs0QkFxQ2hDLEtBQUssU0FBQyxlQUFlOytCQUNyQixLQUFLLFNBQUMsa0JBQWtCIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgRGlyZWN0aXZlLCBJbnB1dCwgRWxlbWVudFJlZiwgT25Jbml0IH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XHJcbmltcG9ydCB7IEtkTWluZG1hcFN2YyB9IGZyb20gJy4va2QtYW5ndWxhci1taW5kbWFwLXN2Yyc7XHJcbmltcG9ydCB7IEZvcmNlRGlyZWN0ZWRHcmFwaCB9IGZyb20gJy4va2QtYW5ndWxhci1taW5kbWFwLWZvcmNlLWxvZ2ljJztcclxuaW1wb3J0IHsgWm9vbUNsYXNzIH0gZnJvbSAnLi96b29tL2tkLWFuZ3VsYXItbWluZG1hcC16b29tLWxvZ2ljJztcclxuaW1wb3J0IHsgSU1pbmRtYXBOb2RlLCBJTWluZG1hcEludGVybmFsQXBpIH0gZnJvbSAnLi9rZC1hbmd1bGFyLW1pbmRtYXAtaW50ZXJmYWNlJztcclxuXHJcbkBEaXJlY3RpdmUoe1xyXG4gICAgc2VsZWN0b3I6ICdbem9vbWFibGVPZl0nLFxyXG59KVxyXG5leHBvcnQgY2xhc3MgS2RNaW5kbWFwWm9vbURpcmVjdGl2ZSBpbXBsZW1lbnRzIE9uSW5pdCB7XHJcbiAgICBwcml2YXRlIF96b29tQ2xhc3M6IFpvb21DbGFzcztcclxuXHJcbiAgICBASW5wdXQoJ3pvb21hYmxlT2YnKSB6b29tYWJsZU9mOiBFbGVtZW50UmVmO1xyXG4gICAgQElucHV0KCdhcGknKSBpbnRlcm5hbEFwaTogSU1pbmRtYXBJbnRlcm5hbEFwaTtcclxuXHJcbiAgICBjb25zdHJ1Y3Rvcihwcml2YXRlIF9taW5kbWFwU3ZjOiBLZE1pbmRtYXBTdmMsIHByaXZhdGUgX2VsZW1lbnQ6IEVsZW1lbnRSZWYpIHsgfVxyXG5cclxuICAgIG5nT25Jbml0KCkge1xyXG4gICAgICAgIHRoaXMuX3pvb21DbGFzcyA9IHRoaXMuX21pbmRtYXBTdmMuZ2V0Wm9vbUNsYXNzKHRoaXMuem9vbWFibGVPZiwgdGhpcy5fZWxlbWVudC5uYXRpdmVFbGVtZW50KTtcclxuICAgICAgICB0aGlzLl96b29tQ2xhc3MuYXBwbHlab29tYWJsZUJlaGF2aW91cigpO1xyXG4gICAgICAgIHRoaXMuX2luaXRBcGkoKTtcclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF9pbml0QXBpKCk6IHZvaWQge1xyXG4gICAgICAgIGlmICh0eXBlb2YgdGhpcy5pbnRlcm5hbEFwaSAhPT0gJ3VuZGVmaW5lZCcpIHtcclxuICAgICAgICAgICAgdGhpcy5pbnRlcm5hbEFwaS56b29tID0gKF9hY3Rpb246IHN0cmluZyk6IHZvaWQgPT4gdGhpcy5fem9vbUNsYXNzLmN1c3RvbVpvb20oX2FjdGlvbik7XHJcbiAgICAgICAgICAgIHRoaXMuaW50ZXJuYWxBcGkuc2NhbGVUbyA9IChfc2NhbGU6IG51bWJlcik6IHZvaWQgPT4gdGhpcy5fem9vbUNsYXNzLnNjYWxlVG8oX3NjYWxlKTtcclxuICAgICAgICAgICAgdGhpcy5pbnRlcm5hbEFwaS50cmFuc2xhdGUgPSAoX3g6IG51bWJlciwgX3k/OiBudW1iZXIpOiBhbnkgPT4gdGhpcy5fem9vbUNsYXNzLnRyYW5zbGF0ZVNWRyhfeCwgX3kpO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxufVxyXG5cclxuXHJcbkBEaXJlY3RpdmUoe1xyXG4gICAgc2VsZWN0b3I6ICdbZHJhZ2dhYmxlTm9kZV0nXHJcbn0pXHJcbmV4cG9ydCBjbGFzcyBLZE1pbmRtYXBEcmFnRGlyZWN0aXZlIGltcGxlbWVudHMgT25Jbml0IHtcclxuICAgIEBJbnB1dCgnZHJhZ2dhYmxlTm9kZScpIGRyYWdnYWJsZU5vZGU6IElNaW5kbWFwTm9kZTtcclxuICAgIEBJbnB1dCgnZHJhZ2dhYmxlSW5HcmFwaCcpIGRyYWdnYWJsZUluR3JhcGg6IEZvcmNlRGlyZWN0ZWRHcmFwaDtcclxuXHJcbiAgICBjb25zdHJ1Y3Rvcihwcml2YXRlIF9taW5kbWFwU3ZjOiBLZE1pbmRtYXBTdmMsIHByaXZhdGUgX2VsZW1lbnQ6IEVsZW1lbnRSZWYpIHsgfVxyXG5cclxuICAgIG5nT25Jbml0KCkge1xyXG4gICAgICAgIHRoaXMuX21pbmRtYXBTdmMuYXBwbHlEcmFnZ2FibGVCZWhhdmlvdXIodGhpcy5fZWxlbWVudC5uYXRpdmVFbGVtZW50LCB0aGlzLmRyYWdnYWJsZU5vZGUsIHRoaXMuZHJhZ2dhYmxlSW5HcmFwaCk7XHJcbiAgICB9XHJcbn1cclxuIl19