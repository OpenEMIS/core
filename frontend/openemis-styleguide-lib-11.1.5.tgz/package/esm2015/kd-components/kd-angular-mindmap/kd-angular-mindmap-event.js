import { Injectable } from '@angular/core';
import { KdBroadcaster, } from '../kd-common/index';
import * as i0 from "@angular/core";
import * as i1 from "../kd-common/kd-broadcaster-svc";
export class KdMindmapEvent {
    constructor(_broadcaster) {
        this._broadcaster = _broadcaster;
    }
    nodeSelected(_mindmapId, _selectedNode) {
        this._broadcaster.broadcast(_mindmapId + 'kdMindmapNodeClicked', _selectedNode);
    }
    onNodeSelected(_mindmapId) {
        return this._broadcaster.on(_mindmapId + 'kdMindmapNodeClicked');
    }
}
KdMindmapEvent.ɵprov = i0.ɵɵdefineInjectable({ factory: function KdMindmapEvent_Factory() { return new KdMindmapEvent(i0.ɵɵinject(i1.KdBroadcaster)); }, token: KdMindmapEvent, providedIn: "root" });
KdMindmapEvent.decorators = [
    { type: Injectable, args: [{
                providedIn: 'root'
            },] }
];
KdMindmapEvent.ctorParameters = () => [
    { type: KdBroadcaster }
];
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoia2QtYW5ndWxhci1taW5kbWFwLWV2ZW50LmpzIiwic291cmNlUm9vdCI6IkM6L3hhbXBwL2h0ZG9jcy9TdHlsZWd1aWRlL2lvc3RnLW9wZW5lbWlzLXN0eWxlZ3VpZGUvcHJvamVjdHMvb3BlbmVtaXMtc3R5bGVndWlkZS1saWIvc3JjLyIsInNvdXJjZXMiOlsia2QtY29tcG9uZW50cy9rZC1hbmd1bGFyLW1pbmRtYXAva2QtYW5ndWxhci1taW5kbWFwLWV2ZW50LnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBLE9BQU8sRUFBRSxVQUFVLEVBQUUsTUFBTSxlQUFlLENBQUM7QUFHM0MsT0FBTyxFQUFFLGFBQWEsR0FBRyxNQUFNLG9CQUFvQixDQUFDOzs7QUFLcEQsTUFBTSxPQUFPLGNBQWM7SUFFdkIsWUFBb0IsWUFBMkI7UUFBM0IsaUJBQVksR0FBWixZQUFZLENBQWU7SUFBSSxDQUFDO0lBRTdDLFlBQVksQ0FBQyxVQUFrQixFQUFFLGFBQTRCO1FBQ2hFLElBQUksQ0FBQyxZQUFZLENBQUMsU0FBUyxDQUFDLFVBQVUsR0FBRyxzQkFBc0IsRUFBRSxhQUFhLENBQUMsQ0FBQztJQUNwRixDQUFDO0lBRU0sY0FBYyxDQUFDLFVBQWtCO1FBQ3BDLE9BQU8sSUFBSSxDQUFDLFlBQVksQ0FBQyxFQUFFLENBQU0sVUFBVSxHQUFHLHNCQUFzQixDQUFDLENBQUM7SUFDMUUsQ0FBQzs7OztZQWJKLFVBQVUsU0FBQztnQkFDUixVQUFVLEVBQUUsTUFBTTthQUNyQjs7O1lBSlEsYUFBYSIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IEluamVjdGFibGUgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcclxuaW1wb3J0IHsgT2JzZXJ2YWJsZSB9IGZyb20gJ3J4anMnO1xyXG5pbXBvcnQgeyBJTWluZG1hcE5vZGUgfSBmcm9tICcuL2tkLWFuZ3VsYXItbWluZG1hcC1pbnRlcmZhY2UnO1xyXG5pbXBvcnQgeyBLZEJyb2FkY2FzdGVyLCB9IGZyb20gJy4uL2tkLWNvbW1vbi9pbmRleCc7XHJcblxyXG5ASW5qZWN0YWJsZSh7XHJcbiAgICBwcm92aWRlZEluOiAncm9vdCdcclxufSlcclxuZXhwb3J0IGNsYXNzIEtkTWluZG1hcEV2ZW50IHtcclxuXHJcbiAgICBjb25zdHJ1Y3Rvcihwcml2YXRlIF9icm9hZGNhc3RlcjogS2RCcm9hZGNhc3RlcikgeyB9XHJcblxyXG4gICAgcHVibGljIG5vZGVTZWxlY3RlZChfbWluZG1hcElkOiBzdHJpbmcsIF9zZWxlY3RlZE5vZGU/OiBJTWluZG1hcE5vZGUpOiB2b2lkIHtcclxuICAgICAgICB0aGlzLl9icm9hZGNhc3Rlci5icm9hZGNhc3QoX21pbmRtYXBJZCArICdrZE1pbmRtYXBOb2RlQ2xpY2tlZCcsIF9zZWxlY3RlZE5vZGUpO1xyXG4gICAgfVxyXG5cclxuICAgIHB1YmxpYyBvbk5vZGVTZWxlY3RlZChfbWluZG1hcElkOiBzdHJpbmcpOiBPYnNlcnZhYmxlPGFueT4ge1xyXG4gICAgICAgIHJldHVybiB0aGlzLl9icm9hZGNhc3Rlci5vbjxhbnk+KF9taW5kbWFwSWQgKyAna2RNaW5kbWFwTm9kZUNsaWNrZWQnKTtcclxuICAgIH1cclxufVxyXG5cclxuIl19