import { Component, Input, ViewEncapsulation, ElementRef, } from '@angular/core';
import { KdDomElemSvc } from '../../kd-common/index';
import { KdMindmapEvent } from '../kd-angular-mindmap-event';
export class KdMindmapLink {
    constructor(_mindmapEvent, _domSvc, _elemRef) {
        this._mindmapEvent = _mindmapEvent;
        this._domSvc = _domSvc;
        this._elemRef = _elemRef;
        this.offset = 0;
        this._linkActive = false;
    }
    ngOnInit() {
        this._initApi();
        this._setConfig(this.allConfig);
        this._nodeSelectedSub = this._mindmapEvent
            .onNodeSelected(this.mindmapId)
            .subscribe((_node) => this._linkActiveSwitch(_node));
    }
    ngOnChanges(_simpleChanges) {
        if (_simpleChanges.hasOwnProperty('allConfig') && !_simpleChanges['allConfig'].firstChange) {
            this._setConfig(this.allConfig);
        }
    }
    ngOnDestroy() {
        this._nodeSelectedSub.unsubscribe();
    }
    _initApi() {
        if (typeof this.internalLinkApiRef !== 'undefined') {
            this.internalLinkApiRef[this.link.index] = {};
            this.internalLinkApiRef[this.link.index].setLinkOffset = (_offset) => { this.offset = _offset || 0; };
        }
    }
    _linkActiveSwitch(_node) {
        if (this.link.target.index !== _node.index && this.link.source.index !== _node.index) {
            if (this._linkActive) {
                this._domSvc.removeClass(this._elemRef.nativeElement, this.config.link.activeClass);
                if (this.config.link.type)
                    this._setMarkerType(this.config.link.type, 'url(#arrowStart)', 'url(#arrowEnd)');
                this._linkActive = false;
            }
        }
        else {
            if (!this._linkActive) {
                this._domSvc.addClass(this._elemRef.nativeElement, this.config.link.activeClass);
                if (this.config.link.type)
                    this._setMarkerType(this.config.link.type, 'url(#arrowStartActive)', 'url(#arrowEndActive)');
                this._linkActive = true;
            }
        }
    }
    _setConfig(_config) {
        this.config = Object.assign({}, _config);
        this.config.link = Object.assign({}, _config.link);
        this._setMarker();
        if (this.config.link.class)
            this._domSvc.addClass(this._elemRef.nativeElement, this.config.link.class);
    }
    /**
     * [_setMarker is setting whether the arrow heads should appear]
     */
    _setMarker() {
        if (this.link.type)
            this.config.link.type = this.link.type;
        if (!this.config.link.type)
            return;
        this._setMarkerType(this.config.link.type, 'url(#arrowStart)', 'url(#arrowEnd)');
    }
    _setMarkerType(_configType, _urlStart, _urlEnd) {
        if (_configType === 'direction' || _configType === 'two-direction') {
            this._domSvc.setAttribute(this._elemRef.nativeElement.querySelector('.kdx-mindmap-link-line'), 'marker-end', _urlEnd);
        }
        if (_configType === 'two-direction') {
            this._domSvc.setAttribute(this._elemRef.nativeElement.querySelector('.kdx-mindmap-link-line'), 'marker-start', _urlStart);
        }
    }
}
KdMindmapLink.decorators = [
    { type: Component, args: [{
                selector: '[kdx-mindmap-link]',
                template: `
        <svg:line
            class="kdx-mindmap-link-line"
            [attr.aria-source]="link.source.title"
            [attr.aria-target]="link.target.title"
            [attr.x1]="link.source.x + config.node.width/2"
            [attr.y1]="link.source.y"
            [attr.x2]="link.target.x - config.node.width/2"
            [attr.y2]="link.target.y + offset"
            [attr.stroke-dasharray]="config.link.dash || link.dash? config.link.dashArray : []"
        ></svg:line>
    `,
                encapsulation: ViewEncapsulation.None,
                providers: [KdMindmapEvent, KdDomElemSvc],
                host: {
                    'class': 'kdx-mindmap-link'
                }
            },] }
];
KdMindmapLink.ctorParameters = () => [
    { type: KdMindmapEvent },
    { type: KdDomElemSvc },
    { type: ElementRef }
];
KdMindmapLink.propDecorators = {
    mindmapId: [{ type: Input }],
    link: [{ type: Input, args: ['kdx-mindmap-link',] }],
    allConfig: [{ type: Input, args: ['config',] }],
    internalLinkApiRef: [{ type: Input, args: ['api',] }]
};
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoia2QtYW5ndWxhci1taW5kbWFwLWxpbmsuanMiLCJzb3VyY2VSb290IjoiQzoveGFtcHAvaHRkb2NzL1N0eWxlZ3VpZGUvaW9zdGctb3BlbmVtaXMtc3R5bGVndWlkZS9wcm9qZWN0cy9vcGVuZW1pcy1zdHlsZWd1aWRlLWxpYi9zcmMvIiwic291cmNlcyI6WyJrZC1jb21wb25lbnRzL2tkLWFuZ3VsYXItbWluZG1hcC9saW5rcy9rZC1hbmd1bGFyLW1pbmRtYXAtbGluay50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQSxPQUFPLEVBQ0gsU0FBUyxFQUNULEtBQUssRUFDTCxpQkFBaUIsRUFLakIsVUFBVSxHQUNiLE1BQU0sZUFBZSxDQUFDO0FBRXZCLE9BQU8sRUFBRSxZQUFZLEVBQUUsTUFBTSx1QkFBdUIsQ0FBQztBQUNyRCxPQUFPLEVBQUUsY0FBYyxFQUFFLE1BQU0sNkJBQTZCLENBQUM7QUEyQjdELE1BQU0sT0FBTyxhQUFhO0lBV3RCLFlBQ1ksYUFBNkIsRUFDN0IsT0FBcUIsRUFDckIsUUFBb0I7UUFGcEIsa0JBQWEsR0FBYixhQUFhLENBQWdCO1FBQzdCLFlBQU8sR0FBUCxPQUFPLENBQWM7UUFDckIsYUFBUSxHQUFSLFFBQVEsQ0FBWTtRQVp6QixXQUFNLEdBQVcsQ0FBQyxDQUFDO1FBRWxCLGdCQUFXLEdBQVksS0FBSyxDQUFDO0lBV2pDLENBQUM7SUFFTCxRQUFRO1FBQ0osSUFBSSxDQUFDLFFBQVEsRUFBRSxDQUFDO1FBQ2hCLElBQUksQ0FBQyxVQUFVLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDO1FBQ2hDLElBQUksQ0FBQyxnQkFBZ0IsR0FBRyxJQUFJLENBQUMsYUFBYTthQUNyQyxjQUFjLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQzthQUM5QixTQUFTLENBQUMsQ0FBQyxLQUFtQixFQUFRLEVBQUUsQ0FBQyxJQUFJLENBQUMsaUJBQWlCLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQztJQUNqRixDQUFDO0lBRUQsV0FBVyxDQUFDLGNBQTZCO1FBQ3JDLElBQUksY0FBYyxDQUFDLGNBQWMsQ0FBQyxXQUFXLENBQUMsSUFBSSxDQUFDLGNBQWMsQ0FBQyxXQUFXLENBQUMsQ0FBQyxXQUFXLEVBQUU7WUFDeEYsSUFBSSxDQUFDLFVBQVUsQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLENBQUM7U0FDbkM7SUFDTCxDQUFDO0lBRUQsV0FBVztRQUNQLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxXQUFXLEVBQUUsQ0FBQztJQUN4QyxDQUFDO0lBRU8sUUFBUTtRQUNaLElBQUksT0FBTyxJQUFJLENBQUMsa0JBQWtCLEtBQUssV0FBVyxFQUFFO1lBQ2hELElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxHQUFHLEVBQUUsQ0FBQztZQUM5QyxJQUFJLENBQUMsa0JBQWtCLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQyxhQUFhLEdBQUcsQ0FBQyxPQUFlLEVBQVEsRUFBRSxHQUFHLElBQUksQ0FBQyxNQUFNLEdBQUcsT0FBTyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztTQUN2SDtJQUNMLENBQUM7SUFFTyxpQkFBaUIsQ0FBQyxLQUFtQjtRQUN6QyxJQUFJLElBQUksQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLEtBQUssS0FBSyxLQUFLLENBQUMsS0FBSyxJQUFJLElBQUksQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLEtBQUssS0FBSyxLQUFLLENBQUMsS0FBSyxFQUFFO1lBQ2xGLElBQUksSUFBSSxDQUFDLFdBQVcsRUFBRTtnQkFDbEIsSUFBSSxDQUFDLE9BQU8sQ0FBQyxXQUFXLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxhQUFhLEVBQUUsSUFBSSxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFDLENBQUM7Z0JBQ3BGLElBQUksSUFBSSxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsSUFBSTtvQkFBRSxJQUFJLENBQUMsY0FBYyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLElBQUksRUFBRSxrQkFBa0IsRUFBRSxnQkFBZ0IsQ0FBQyxDQUFDO2dCQUM1RyxJQUFJLENBQUMsV0FBVyxHQUFHLEtBQUssQ0FBQzthQUM1QjtTQUNKO2FBQU07WUFDSCxJQUFJLENBQUMsSUFBSSxDQUFDLFdBQVcsRUFBRTtnQkFDbkIsSUFBSSxDQUFDLE9BQU8sQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxhQUFhLEVBQUUsSUFBSSxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFDLENBQUM7Z0JBQ2pGLElBQUksSUFBSSxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsSUFBSTtvQkFBRSxJQUFJLENBQUMsY0FBYyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLElBQUksRUFBRSx3QkFBd0IsRUFBRSxzQkFBc0IsQ0FBQyxDQUFDO2dCQUN4SCxJQUFJLENBQUMsV0FBVyxHQUFHLElBQUksQ0FBQzthQUMzQjtTQUNKO0lBQ0wsQ0FBQztJQUVPLFVBQVUsQ0FBQyxPQUFPO1FBQ3RCLElBQUksQ0FBQyxNQUFNLEdBQUcsTUFBTSxDQUFDLE1BQU0sQ0FBQyxFQUFFLEVBQUUsT0FBTyxDQUFDLENBQUM7UUFDekMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxJQUFJLEdBQUcsTUFBTSxDQUFDLE1BQU0sQ0FBQyxFQUFFLEVBQUUsT0FBTyxDQUFDLElBQUksQ0FBQyxDQUFDO1FBQ25ELElBQUksQ0FBQyxVQUFVLEVBQUUsQ0FBQztRQUNsQixJQUFJLElBQUksQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLEtBQUs7WUFBRSxJQUFJLENBQUMsT0FBTyxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLGFBQWEsRUFBRSxJQUFJLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQztJQUMzRyxDQUFDO0lBRUQ7O09BRUc7SUFDSyxVQUFVO1FBQ2QsSUFBSSxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUk7WUFBRSxJQUFJLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxJQUFJLEdBQUcsSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUM7UUFDM0QsSUFBSSxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLElBQUk7WUFBRSxPQUFPO1FBQ25DLElBQUksQ0FBQyxjQUFjLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsSUFBSSxFQUFFLGtCQUFrQixFQUFFLGdCQUFnQixDQUFDLENBQUM7SUFDckYsQ0FBQztJQUVPLGNBQWMsQ0FBQyxXQUFtQixFQUFFLFNBQWlCLEVBQUUsT0FBZTtRQUMxRSxJQUFJLFdBQVcsS0FBSyxXQUFXLElBQUksV0FBVyxLQUFLLGVBQWUsRUFBRTtZQUNoRSxJQUFJLENBQUMsT0FBTyxDQUFDLFlBQVksQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLGFBQWEsQ0FBQyxhQUFhLENBQUMsd0JBQXdCLENBQUMsRUFBRSxZQUFZLEVBQUUsT0FBTyxDQUFDLENBQUM7U0FDekg7UUFDRCxJQUFJLFdBQVcsS0FBSyxlQUFlLEVBQUU7WUFDakMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxZQUFZLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxhQUFhLENBQUMsYUFBYSxDQUFDLHdCQUF3QixDQUFDLEVBQUUsY0FBYyxFQUFFLFNBQVMsQ0FBQyxDQUFDO1NBQzdIO0lBQ0wsQ0FBQzs7O1lBckdKLFNBQVMsU0FBQztnQkFDUCxRQUFRLEVBQUUsb0JBQW9CO2dCQUM5QixRQUFRLEVBQUU7Ozs7Ozs7Ozs7O0tBV1Q7Z0JBQ0QsYUFBYSxFQUFFLGlCQUFpQixDQUFDLElBQUk7Z0JBQ3JDLFNBQVMsRUFBRSxDQUFDLGNBQWMsRUFBRSxZQUFZLENBQUM7Z0JBQ3pDLElBQUksRUFBRTtvQkFDRixPQUFPLEVBQUUsa0JBQWtCO2lCQUM5QjthQUNKOzs7WUExQlEsY0FBYztZQURkLFlBQVk7WUFIakIsVUFBVTs7O3dCQXFDVCxLQUFLO21CQUNMLEtBQUssU0FBQyxrQkFBa0I7d0JBQ3hCLEtBQUssU0FBQyxRQUFRO2lDQUNkLEtBQUssU0FBQyxLQUFLIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHtcclxuICAgIENvbXBvbmVudCxcclxuICAgIElucHV0LFxyXG4gICAgVmlld0VuY2Fwc3VsYXRpb24sXHJcbiAgICBPbkluaXQsXHJcbiAgICBPbkNoYW5nZXMsXHJcbiAgICBTaW1wbGVDaGFuZ2VzLFxyXG4gICAgT25EZXN0cm95LFxyXG4gICAgRWxlbWVudFJlZixcclxufSBmcm9tICdAYW5ndWxhci9jb3JlJztcclxuaW1wb3J0IHsgU3Vic2NyaXB0aW9uIH0gZnJvbSAncnhqcyc7XHJcbmltcG9ydCB7IEtkRG9tRWxlbVN2YyB9IGZyb20gJy4uLy4uL2tkLWNvbW1vbi9pbmRleCc7XHJcbmltcG9ydCB7IEtkTWluZG1hcEV2ZW50IH0gZnJvbSAnLi4va2QtYW5ndWxhci1taW5kbWFwLWV2ZW50JztcclxuaW1wb3J0IHsgXHJcbiAgICBJTWluZG1hcE5vZGUsIFxyXG4gICAgSUludGVybmFsQWxsQ29uZmlnLCBcclxuICAgIElNaW5kbWFwSW50ZXJuYWxMaW5rQXBpUmVmIFxyXG59IGZyb20gJy4uL2tkLWFuZ3VsYXItbWluZG1hcC1pbnRlcmZhY2UnO1xyXG5cclxuQENvbXBvbmVudCh7XHJcbiAgICBzZWxlY3RvcjogJ1trZHgtbWluZG1hcC1saW5rXScsXHJcbiAgICB0ZW1wbGF0ZTogYFxyXG4gICAgICAgIDxzdmc6bGluZVxyXG4gICAgICAgICAgICBjbGFzcz1cImtkeC1taW5kbWFwLWxpbmstbGluZVwiXHJcbiAgICAgICAgICAgIFthdHRyLmFyaWEtc291cmNlXT1cImxpbmsuc291cmNlLnRpdGxlXCJcclxuICAgICAgICAgICAgW2F0dHIuYXJpYS10YXJnZXRdPVwibGluay50YXJnZXQudGl0bGVcIlxyXG4gICAgICAgICAgICBbYXR0ci54MV09XCJsaW5rLnNvdXJjZS54ICsgY29uZmlnLm5vZGUud2lkdGgvMlwiXHJcbiAgICAgICAgICAgIFthdHRyLnkxXT1cImxpbmsuc291cmNlLnlcIlxyXG4gICAgICAgICAgICBbYXR0ci54Ml09XCJsaW5rLnRhcmdldC54IC0gY29uZmlnLm5vZGUud2lkdGgvMlwiXHJcbiAgICAgICAgICAgIFthdHRyLnkyXT1cImxpbmsudGFyZ2V0LnkgKyBvZmZzZXRcIlxyXG4gICAgICAgICAgICBbYXR0ci5zdHJva2UtZGFzaGFycmF5XT1cImNvbmZpZy5saW5rLmRhc2ggfHwgbGluay5kYXNoPyBjb25maWcubGluay5kYXNoQXJyYXkgOiBbXVwiXHJcbiAgICAgICAgPjwvc3ZnOmxpbmU+XHJcbiAgICBgLFxyXG4gICAgZW5jYXBzdWxhdGlvbjogVmlld0VuY2Fwc3VsYXRpb24uTm9uZSxcclxuICAgIHByb3ZpZGVyczogW0tkTWluZG1hcEV2ZW50LCBLZERvbUVsZW1TdmNdLFxyXG4gICAgaG9zdDoge1xyXG4gICAgICAgICdjbGFzcyc6ICdrZHgtbWluZG1hcC1saW5rJ1xyXG4gICAgfVxyXG59KVxyXG5leHBvcnQgY2xhc3MgS2RNaW5kbWFwTGluayBpbXBsZW1lbnRzIE9uSW5pdCwgT25DaGFuZ2VzLCBPbkRlc3Ryb3kge1xyXG4gICAgcHVibGljIGNvbmZpZzogSUludGVybmFsQWxsQ29uZmlnO1xyXG4gICAgcHVibGljIG9mZnNldDogbnVtYmVyID0gMDtcclxuICAgIHByaXZhdGUgX25vZGVTZWxlY3RlZFN1YjogU3Vic2NyaXB0aW9uO1xyXG4gICAgcHJpdmF0ZSBfbGlua0FjdGl2ZTogYm9vbGVhbiA9IGZhbHNlO1xyXG5cclxuICAgIEBJbnB1dCgpIG1pbmRtYXBJZDogc3RyaW5nO1xyXG4gICAgQElucHV0KCdrZHgtbWluZG1hcC1saW5rJykgbGluazogYW55O1xyXG4gICAgQElucHV0KCdjb25maWcnKSBhbGxDb25maWc6IElJbnRlcm5hbEFsbENvbmZpZztcclxuICAgIEBJbnB1dCgnYXBpJykgaW50ZXJuYWxMaW5rQXBpUmVmOiBJTWluZG1hcEludGVybmFsTGlua0FwaVJlZjtcclxuXHJcbiAgICBjb25zdHJ1Y3RvcihcclxuICAgICAgICBwcml2YXRlIF9taW5kbWFwRXZlbnQ6IEtkTWluZG1hcEV2ZW50LFxyXG4gICAgICAgIHByaXZhdGUgX2RvbVN2YzogS2REb21FbGVtU3ZjLFxyXG4gICAgICAgIHByaXZhdGUgX2VsZW1SZWY6IEVsZW1lbnRSZWZcclxuICAgICkgeyB9XHJcblxyXG4gICAgbmdPbkluaXQoKTogdm9pZCB7XHJcbiAgICAgICAgdGhpcy5faW5pdEFwaSgpO1xyXG4gICAgICAgIHRoaXMuX3NldENvbmZpZyh0aGlzLmFsbENvbmZpZyk7XHJcbiAgICAgICAgdGhpcy5fbm9kZVNlbGVjdGVkU3ViID0gdGhpcy5fbWluZG1hcEV2ZW50XHJcbiAgICAgICAgICAgIC5vbk5vZGVTZWxlY3RlZCh0aGlzLm1pbmRtYXBJZClcclxuICAgICAgICAgICAgLnN1YnNjcmliZSgoX25vZGU6IElNaW5kbWFwTm9kZSk6IHZvaWQgPT4gdGhpcy5fbGlua0FjdGl2ZVN3aXRjaChfbm9kZSkpO1xyXG4gICAgfVxyXG5cclxuICAgIG5nT25DaGFuZ2VzKF9zaW1wbGVDaGFuZ2VzOiBTaW1wbGVDaGFuZ2VzKTogdm9pZCB7XHJcbiAgICAgICAgaWYgKF9zaW1wbGVDaGFuZ2VzLmhhc093blByb3BlcnR5KCdhbGxDb25maWcnKSAmJiAhX3NpbXBsZUNoYW5nZXNbJ2FsbENvbmZpZyddLmZpcnN0Q2hhbmdlKSB7XHJcbiAgICAgICAgICAgIHRoaXMuX3NldENvbmZpZyh0aGlzLmFsbENvbmZpZyk7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIG5nT25EZXN0cm95KCk6IHZvaWQge1xyXG4gICAgICAgIHRoaXMuX25vZGVTZWxlY3RlZFN1Yi51bnN1YnNjcmliZSgpO1xyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX2luaXRBcGkoKTogdm9pZCB7XHJcbiAgICAgICAgaWYgKHR5cGVvZiB0aGlzLmludGVybmFsTGlua0FwaVJlZiAhPT0gJ3VuZGVmaW5lZCcpIHtcclxuICAgICAgICAgICAgdGhpcy5pbnRlcm5hbExpbmtBcGlSZWZbdGhpcy5saW5rLmluZGV4XSA9IHt9O1xyXG4gICAgICAgICAgICB0aGlzLmludGVybmFsTGlua0FwaVJlZlt0aGlzLmxpbmsuaW5kZXhdLnNldExpbmtPZmZzZXQgPSAoX29mZnNldDogbnVtYmVyKTogdm9pZCA9PiB7IHRoaXMub2Zmc2V0ID0gX29mZnNldCB8fCAwOyB9O1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF9saW5rQWN0aXZlU3dpdGNoKF9ub2RlOiBJTWluZG1hcE5vZGUpOiB2b2lkIHtcclxuICAgICAgICBpZiAodGhpcy5saW5rLnRhcmdldC5pbmRleCAhPT0gX25vZGUuaW5kZXggJiYgdGhpcy5saW5rLnNvdXJjZS5pbmRleCAhPT0gX25vZGUuaW5kZXgpIHtcclxuICAgICAgICAgICAgaWYgKHRoaXMuX2xpbmtBY3RpdmUpIHtcclxuICAgICAgICAgICAgICAgIHRoaXMuX2RvbVN2Yy5yZW1vdmVDbGFzcyh0aGlzLl9lbGVtUmVmLm5hdGl2ZUVsZW1lbnQsIHRoaXMuY29uZmlnLmxpbmsuYWN0aXZlQ2xhc3MpO1xyXG4gICAgICAgICAgICAgICAgaWYgKHRoaXMuY29uZmlnLmxpbmsudHlwZSkgdGhpcy5fc2V0TWFya2VyVHlwZSh0aGlzLmNvbmZpZy5saW5rLnR5cGUsICd1cmwoI2Fycm93U3RhcnQpJywgJ3VybCgjYXJyb3dFbmQpJyk7XHJcbiAgICAgICAgICAgICAgICB0aGlzLl9saW5rQWN0aXZlID0gZmFsc2U7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICBpZiAoIXRoaXMuX2xpbmtBY3RpdmUpIHtcclxuICAgICAgICAgICAgICAgIHRoaXMuX2RvbVN2Yy5hZGRDbGFzcyh0aGlzLl9lbGVtUmVmLm5hdGl2ZUVsZW1lbnQsIHRoaXMuY29uZmlnLmxpbmsuYWN0aXZlQ2xhc3MpO1xyXG4gICAgICAgICAgICAgICAgaWYgKHRoaXMuY29uZmlnLmxpbmsudHlwZSkgdGhpcy5fc2V0TWFya2VyVHlwZSh0aGlzLmNvbmZpZy5saW5rLnR5cGUsICd1cmwoI2Fycm93U3RhcnRBY3RpdmUpJywgJ3VybCgjYXJyb3dFbmRBY3RpdmUpJyk7XHJcbiAgICAgICAgICAgICAgICB0aGlzLl9saW5rQWN0aXZlID0gdHJ1ZTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF9zZXRDb25maWcoX2NvbmZpZyk6IHZvaWQge1xyXG4gICAgICAgIHRoaXMuY29uZmlnID0gT2JqZWN0LmFzc2lnbih7fSwgX2NvbmZpZyk7XHJcbiAgICAgICAgdGhpcy5jb25maWcubGluayA9IE9iamVjdC5hc3NpZ24oe30sIF9jb25maWcubGluayk7XHJcbiAgICAgICAgdGhpcy5fc2V0TWFya2VyKCk7XHJcbiAgICAgICAgaWYgKHRoaXMuY29uZmlnLmxpbmsuY2xhc3MpIHRoaXMuX2RvbVN2Yy5hZGRDbGFzcyh0aGlzLl9lbGVtUmVmLm5hdGl2ZUVsZW1lbnQsIHRoaXMuY29uZmlnLmxpbmsuY2xhc3MpO1xyXG4gICAgfVxyXG5cclxuICAgIC8qKlxyXG4gICAgICogW19zZXRNYXJrZXIgaXMgc2V0dGluZyB3aGV0aGVyIHRoZSBhcnJvdyBoZWFkcyBzaG91bGQgYXBwZWFyXVxyXG4gICAgICovXHJcbiAgICBwcml2YXRlIF9zZXRNYXJrZXIoKTogdm9pZCB7XHJcbiAgICAgICAgaWYgKHRoaXMubGluay50eXBlKSB0aGlzLmNvbmZpZy5saW5rLnR5cGUgPSB0aGlzLmxpbmsudHlwZTtcclxuICAgICAgICBpZiAoIXRoaXMuY29uZmlnLmxpbmsudHlwZSkgcmV0dXJuO1xyXG4gICAgICAgIHRoaXMuX3NldE1hcmtlclR5cGUodGhpcy5jb25maWcubGluay50eXBlLCAndXJsKCNhcnJvd1N0YXJ0KScsICd1cmwoI2Fycm93RW5kKScpO1xyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX3NldE1hcmtlclR5cGUoX2NvbmZpZ1R5cGU6IHN0cmluZywgX3VybFN0YXJ0OiBzdHJpbmcsIF91cmxFbmQ6IHN0cmluZyk6IHZvaWQge1xyXG4gICAgICAgIGlmIChfY29uZmlnVHlwZSA9PT0gJ2RpcmVjdGlvbicgfHwgX2NvbmZpZ1R5cGUgPT09ICd0d28tZGlyZWN0aW9uJykge1xyXG4gICAgICAgICAgICB0aGlzLl9kb21TdmMuc2V0QXR0cmlidXRlKHRoaXMuX2VsZW1SZWYubmF0aXZlRWxlbWVudC5xdWVyeVNlbGVjdG9yKCcua2R4LW1pbmRtYXAtbGluay1saW5lJyksICdtYXJrZXItZW5kJywgX3VybEVuZCk7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGlmIChfY29uZmlnVHlwZSA9PT0gJ3R3by1kaXJlY3Rpb24nKSB7XHJcbiAgICAgICAgICAgIHRoaXMuX2RvbVN2Yy5zZXRBdHRyaWJ1dGUodGhpcy5fZWxlbVJlZi5uYXRpdmVFbGVtZW50LnF1ZXJ5U2VsZWN0b3IoJy5rZHgtbWluZG1hcC1saW5rLWxpbmUnKSwgJ21hcmtlci1zdGFydCcsIF91cmxTdGFydCk7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG59XHJcbiJdfQ==