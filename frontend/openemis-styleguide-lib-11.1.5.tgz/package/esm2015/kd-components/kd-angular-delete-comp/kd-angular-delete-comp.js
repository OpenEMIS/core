import { Component, Input, Output, EventEmitter, ViewEncapsulation, ViewChild } from '@angular/core';
import { KdView } from '../kd-angular-view/index';
export class KdDelete {
    constructor() {
        this._questionData = [];
        this._defaultBtn = [{
                type: 'submit',
                name: 'Delete',
                icon: 'kd-trash',
                class: 'btn-text',
                disabled: false
            }, {
                type: 'cancel',
                name: 'Cancel',
                class: 'btn-outline',
                icon: 'kd-cross',
                disabled: false
            }];
        this._sectionHeader = {
            key: 'SectionHeader',
            label: 'Are you sure you want to delete this?',
            controlType: 'section',
            visible: true,
            required: false
        };
        this.buttonCancelEvent = new EventEmitter();
        this.buttonDeleteEvent = new EventEmitter();
    }
    ngOnInit() {
        if (typeof this.question !== 'undefined' && this.question.length > 0)
            this._questionData = this.question;
        this._questionData.unshift(this._sectionHeader);
    }
    btnClick(_button) {
        this.buttonCancelEvent.emit();
    }
    submitClick(_formVal) {
        this.buttonDeleteEvent.emit(_formVal);
    }
    setDeleteDisabled(_toDisable) {
        this.kdViewComponent.setButtonDisabled('submit', _toDisable);
    }
}
KdDelete.decorators = [
    { type: Component, args: [{
                selector: 'kd-delete',
                template: `<kd-view displayType='form' [inputData]='_questionData' [button]='_defaultBtn' (buttonEvent)='btnClick($event)' (submitEvent)='submitClick($event)'></kd-view>`,
                encapsulation: ViewEncapsulation.None
            },] }
];
KdDelete.propDecorators = {
    question: [{ type: Input }],
    buttonCancelEvent: [{ type: Output }],
    buttonDeleteEvent: [{ type: Output }],
    kdViewComponent: [{ type: ViewChild, args: [KdView, { static: true },] }]
};
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoia2QtYW5ndWxhci1kZWxldGUtY29tcC5qcyIsInNvdXJjZVJvb3QiOiJDOi94YW1wcC9odGRvY3MvU3R5bGVndWlkZS9pb3N0Zy1vcGVuZW1pcy1zdHlsZWd1aWRlL3Byb2plY3RzL29wZW5lbWlzLXN0eWxlZ3VpZGUtbGliL3NyYy8iLCJzb3VyY2VzIjpbImtkLWNvbXBvbmVudHMva2QtYW5ndWxhci1kZWxldGUtY29tcC9rZC1hbmd1bGFyLWRlbGV0ZS1jb21wLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBLE9BQU8sRUFDSCxTQUFTLEVBQ1QsS0FBSyxFQUNMLE1BQU0sRUFDTixZQUFZLEVBQ1osaUJBQWlCLEVBRWpCLFNBQVMsRUFDWixNQUFNLGVBQWUsQ0FBQztBQUN2QixPQUFPLEVBQUUsTUFBTSxFQUFFLE1BQU0sMEJBQTBCLENBQUM7QUFRbEQsTUFBTSxPQUFPLFFBQVE7SUFOckI7UUFPVyxrQkFBYSxHQUFlLEVBQUUsQ0FBQztRQUMvQixnQkFBVyxHQUFlLENBQUM7Z0JBQzlCLElBQUksRUFBRSxRQUFRO2dCQUNkLElBQUksRUFBRSxRQUFRO2dCQUNkLElBQUksRUFBRSxVQUFVO2dCQUNoQixLQUFLLEVBQUUsVUFBVTtnQkFDakIsUUFBUSxFQUFFLEtBQUs7YUFDbEIsRUFBRTtnQkFDQyxJQUFJLEVBQUUsUUFBUTtnQkFDZCxJQUFJLEVBQUUsUUFBUTtnQkFDZCxLQUFLLEVBQUUsYUFBYTtnQkFDcEIsSUFBSSxFQUFFLFVBQVU7Z0JBQ2hCLFFBQVEsRUFBRSxLQUFLO2FBQ2xCLENBQUMsQ0FBQztRQUVLLG1CQUFjLEdBQVE7WUFDMUIsR0FBRyxFQUFFLGVBQWU7WUFDcEIsS0FBSyxFQUFFLHVDQUF1QztZQUM5QyxXQUFXLEVBQUUsU0FBUztZQUN0QixPQUFPLEVBQUUsSUFBSTtZQUNiLFFBQVEsRUFBRSxLQUFLO1NBQ2xCLENBQUM7UUFHUSxzQkFBaUIsR0FBc0IsSUFBSSxZQUFZLEVBQUUsQ0FBQztRQUMxRCxzQkFBaUIsR0FBc0IsSUFBSSxZQUFZLEVBQUUsQ0FBQztJQW1CeEUsQ0FBQztJQWhCRyxRQUFRO1FBQ0osSUFBSSxPQUFPLElBQUksQ0FBQyxRQUFRLEtBQUssV0FBVyxJQUFJLElBQUksQ0FBQyxRQUFRLENBQUMsTUFBTSxHQUFHLENBQUM7WUFBRSxJQUFJLENBQUMsYUFBYSxHQUFHLElBQUksQ0FBQyxRQUFRLENBQUM7UUFDekcsSUFBSSxDQUFDLGFBQWEsQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLGNBQWMsQ0FBQyxDQUFDO0lBQ3BELENBQUM7SUFFRCxRQUFRLENBQUMsT0FBWTtRQUNqQixJQUFJLENBQUMsaUJBQWlCLENBQUMsSUFBSSxFQUFFLENBQUM7SUFDbEMsQ0FBQztJQUVELFdBQVcsQ0FBQyxRQUFhO1FBQ3JCLElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLENBQUM7SUFDMUMsQ0FBQztJQUVNLGlCQUFpQixDQUFDLFVBQW1CO1FBQ3hDLElBQUksQ0FBQyxlQUFlLENBQUMsaUJBQWlCLENBQUMsUUFBUSxFQUFFLFVBQVUsQ0FBQyxDQUFDO0lBQ2pFLENBQUM7OztZQWxESixTQUFTLFNBQUM7Z0JBQ1AsUUFBUSxFQUFFLFdBQVc7Z0JBQ3JCLFFBQVEsRUFBRSxnS0FBZ0s7Z0JBQzFLLGFBQWEsRUFBRSxpQkFBaUIsQ0FBQyxJQUFJO2FBQ3hDOzs7dUJBMEJJLEtBQUs7Z0NBQ0wsTUFBTTtnQ0FDTixNQUFNOzhCQUNOLFNBQVMsU0FBQyxNQUFNLEVBQUUsRUFBRSxNQUFNLEVBQUUsSUFBSSxFQUFFIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHtcclxuICAgIENvbXBvbmVudCxcclxuICAgIElucHV0LFxyXG4gICAgT3V0cHV0LFxyXG4gICAgRXZlbnRFbWl0dGVyLFxyXG4gICAgVmlld0VuY2Fwc3VsYXRpb24sXHJcbiAgICBPbkluaXQsXHJcbiAgICBWaWV3Q2hpbGRcclxufSBmcm9tICdAYW5ndWxhci9jb3JlJztcclxuaW1wb3J0IHsgS2RWaWV3IH0gZnJvbSAnLi4va2QtYW5ndWxhci12aWV3L2luZGV4JztcclxuXHJcbkBDb21wb25lbnQoe1xyXG4gICAgc2VsZWN0b3I6ICdrZC1kZWxldGUnLFxyXG4gICAgdGVtcGxhdGU6IGA8a2QtdmlldyBkaXNwbGF5VHlwZT0nZm9ybScgW2lucHV0RGF0YV09J19xdWVzdGlvbkRhdGEnIFtidXR0b25dPSdfZGVmYXVsdEJ0bicgKGJ1dHRvbkV2ZW50KT0nYnRuQ2xpY2soJGV2ZW50KScgKHN1Ym1pdEV2ZW50KT0nc3VibWl0Q2xpY2soJGV2ZW50KSc+PC9rZC12aWV3PmAsXHJcbiAgICBlbmNhcHN1bGF0aW9uOiBWaWV3RW5jYXBzdWxhdGlvbi5Ob25lXHJcbn0pXHJcblxyXG5leHBvcnQgY2xhc3MgS2REZWxldGUgaW1wbGVtZW50cyBPbkluaXQge1xyXG4gICAgcHVibGljIF9xdWVzdGlvbkRhdGE6IEFycmF5PGFueT4gPSBbXTtcclxuICAgIHB1YmxpYyBfZGVmYXVsdEJ0bjogQXJyYXk8YW55PiA9IFt7XHJcbiAgICAgICAgdHlwZTogJ3N1Ym1pdCcsXHJcbiAgICAgICAgbmFtZTogJ0RlbGV0ZScsXHJcbiAgICAgICAgaWNvbjogJ2tkLXRyYXNoJyxcclxuICAgICAgICBjbGFzczogJ2J0bi10ZXh0JyxcclxuICAgICAgICBkaXNhYmxlZDogZmFsc2VcclxuICAgIH0sIHtcclxuICAgICAgICB0eXBlOiAnY2FuY2VsJyxcclxuICAgICAgICBuYW1lOiAnQ2FuY2VsJyxcclxuICAgICAgICBjbGFzczogJ2J0bi1vdXRsaW5lJyxcclxuICAgICAgICBpY29uOiAna2QtY3Jvc3MnLFxyXG4gICAgICAgIGRpc2FibGVkOiBmYWxzZVxyXG4gICAgfV07XHJcblxyXG4gICAgcHJpdmF0ZSBfc2VjdGlvbkhlYWRlcjogYW55ID0ge1xyXG4gICAgICAgIGtleTogJ1NlY3Rpb25IZWFkZXInLFxyXG4gICAgICAgIGxhYmVsOiAnQXJlIHlvdSBzdXJlIHlvdSB3YW50IHRvIGRlbGV0ZSB0aGlzPycsXHJcbiAgICAgICAgY29udHJvbFR5cGU6ICdzZWN0aW9uJyxcclxuICAgICAgICB2aXNpYmxlOiB0cnVlLFxyXG4gICAgICAgIHJlcXVpcmVkOiBmYWxzZVxyXG4gICAgfTtcclxuXHJcbiAgICBASW5wdXQoKSBxdWVzdGlvbjogQXJyYXk8YW55PjtcclxuICAgIEBPdXRwdXQoKSBidXR0b25DYW5jZWxFdmVudDogRXZlbnRFbWl0dGVyPGFueT4gPSBuZXcgRXZlbnRFbWl0dGVyKCk7XHJcbiAgICBAT3V0cHV0KCkgYnV0dG9uRGVsZXRlRXZlbnQ6IEV2ZW50RW1pdHRlcjxhbnk+ID0gbmV3IEV2ZW50RW1pdHRlcigpO1xyXG4gICAgQFZpZXdDaGlsZChLZFZpZXcsIHsgc3RhdGljOiB0cnVlIH0pIGtkVmlld0NvbXBvbmVudDogS2RWaWV3O1xyXG5cclxuICAgIG5nT25Jbml0KCk6IHZvaWQge1xyXG4gICAgICAgIGlmICh0eXBlb2YgdGhpcy5xdWVzdGlvbiAhPT0gJ3VuZGVmaW5lZCcgJiYgdGhpcy5xdWVzdGlvbi5sZW5ndGggPiAwKSB0aGlzLl9xdWVzdGlvbkRhdGEgPSB0aGlzLnF1ZXN0aW9uO1xyXG4gICAgICAgIHRoaXMuX3F1ZXN0aW9uRGF0YS51bnNoaWZ0KHRoaXMuX3NlY3Rpb25IZWFkZXIpO1xyXG4gICAgfVxyXG5cclxuICAgIGJ0bkNsaWNrKF9idXR0b246IGFueSk6IHZvaWQge1xyXG4gICAgICAgIHRoaXMuYnV0dG9uQ2FuY2VsRXZlbnQuZW1pdCgpO1xyXG4gICAgfVxyXG5cclxuICAgIHN1Ym1pdENsaWNrKF9mb3JtVmFsOiBhbnkpOiB2b2lkIHtcclxuICAgICAgICB0aGlzLmJ1dHRvbkRlbGV0ZUV2ZW50LmVtaXQoX2Zvcm1WYWwpO1xyXG4gICAgfVxyXG5cclxuICAgIHB1YmxpYyBzZXREZWxldGVEaXNhYmxlZChfdG9EaXNhYmxlOiBib29sZWFuKTogdm9pZCB7XHJcbiAgICAgICAgdGhpcy5rZFZpZXdDb21wb25lbnQuc2V0QnV0dG9uRGlzYWJsZWQoJ3N1Ym1pdCcsIF90b0Rpc2FibGUpO1xyXG4gICAgfVxyXG59XHJcbiJdfQ==