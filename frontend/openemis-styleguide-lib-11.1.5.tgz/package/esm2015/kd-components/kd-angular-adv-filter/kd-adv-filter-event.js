import { Injectable } from '@angular/core';
import { KdBroadcaster } from '../kd-common/index';
import * as i0 from "@angular/core";
import * as i1 from "../kd-common/kd-broadcaster-svc";
export class KdIntAdvFilterEvent {
    constructor(_broadcaster) {
        this._broadcaster = _broadcaster;
    }
    onToggleAdvSearch() {
        return this._broadcaster.on('KDToggleAdvSearch');
    }
    onSendData() {
        return this._broadcaster.on('KdFormValue');
    }
    sendAdvSearchStatus(data) {
        this._broadcaster.broadcast('KdSendShowStatus', data);
    }
}
KdIntAdvFilterEvent.decorators = [
    { type: Injectable }
];
KdIntAdvFilterEvent.ctorParameters = () => [
    { type: KdBroadcaster }
];
export class KdAdvFilterEvent {
    constructor(_broadcaster) {
        this._broadcaster = _broadcaster;
    }
    toggleAdvSearch(data) {
        this._broadcaster.broadcast('KDToggleAdvSearch', data);
    }
    sendData(data) {
        this._broadcaster.broadcast('KdFormValue', data);
    }
    onSendAdvSearchStatus(data) {
        return this._broadcaster.on('KdSendShowStatus');
    }
}
KdAdvFilterEvent.ɵprov = i0.ɵɵdefineInjectable({ factory: function KdAdvFilterEvent_Factory() { return new KdAdvFilterEvent(i0.ɵɵinject(i1.KdBroadcaster)); }, token: KdAdvFilterEvent, providedIn: "root" });
KdAdvFilterEvent.decorators = [
    { type: Injectable, args: [{
                providedIn: 'root'
            },] }
];
KdAdvFilterEvent.ctorParameters = () => [
    { type: KdBroadcaster }
];
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoia2QtYWR2LWZpbHRlci1ldmVudC5qcyIsInNvdXJjZVJvb3QiOiJDOi94YW1wcC9odGRvY3MvU3R5bGVndWlkZS9pb3N0Zy1vcGVuZW1pcy1zdHlsZWd1aWRlL3Byb2plY3RzL29wZW5lbWlzLXN0eWxlZ3VpZGUtbGliL3NyYy8iLCJzb3VyY2VzIjpbImtkLWNvbXBvbmVudHMva2QtYW5ndWxhci1hZHYtZmlsdGVyL2tkLWFkdi1maWx0ZXItZXZlbnQudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsT0FBTyxFQUFFLFVBQVUsRUFBRSxNQUFNLGVBQWUsQ0FBQztBQUUzQyxPQUFPLEVBQUUsYUFBYSxFQUFFLE1BQU0sb0JBQW9CLENBQUM7OztBQUduRCxNQUFNLE9BQU8sbUJBQW1CO0lBQzVCLFlBQW9CLFlBQTJCO1FBQTNCLGlCQUFZLEdBQVosWUFBWSxDQUFlO0lBQUksQ0FBQztJQUVwRCxpQkFBaUI7UUFDYixPQUFPLElBQUksQ0FBQyxZQUFZLENBQUMsRUFBRSxDQUFNLG1CQUFtQixDQUFDLENBQUM7SUFDMUQsQ0FBQztJQUVELFVBQVU7UUFDTixPQUFPLElBQUksQ0FBQyxZQUFZLENBQUMsRUFBRSxDQUFNLGFBQWEsQ0FBQyxDQUFDO0lBQ3BELENBQUM7SUFFRCxtQkFBbUIsQ0FBQyxJQUFVO1FBQzFCLElBQUksQ0FBQyxZQUFZLENBQUMsU0FBUyxDQUFDLGtCQUFrQixFQUFFLElBQUksQ0FBQyxDQUFDO0lBQzFELENBQUM7OztZQWRKLFVBQVU7OztZQUZGLGFBQWE7O0FBc0J0QixNQUFNLE9BQU8sZ0JBQWdCO0lBQ3pCLFlBQW9CLFlBQTJCO1FBQTNCLGlCQUFZLEdBQVosWUFBWSxDQUFlO0lBQUksQ0FBQztJQUVwRCxlQUFlLENBQUMsSUFBVTtRQUN0QixJQUFJLENBQUMsWUFBWSxDQUFDLFNBQVMsQ0FBQyxtQkFBbUIsRUFBRSxJQUFJLENBQUMsQ0FBQztJQUMzRCxDQUFDO0lBRUQsUUFBUSxDQUFDLElBQVU7UUFDZixJQUFJLENBQUMsWUFBWSxDQUFDLFNBQVMsQ0FBQyxhQUFhLEVBQUUsSUFBSSxDQUFDLENBQUM7SUFDckQsQ0FBQztJQUVELHFCQUFxQixDQUFDLElBQVU7UUFDNUIsT0FBTyxJQUFJLENBQUMsWUFBWSxDQUFDLEVBQUUsQ0FBTSxrQkFBa0IsQ0FBQyxDQUFDO0lBQ3pELENBQUM7Ozs7WUFoQkosVUFBVSxTQUFDO2dCQUNSLFVBQVUsRUFBRSxNQUFNO2FBQ3JCOzs7WUFyQlEsYUFBYSIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IEluamVjdGFibGUgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcclxuaW1wb3J0IHsgT2JzZXJ2YWJsZSB9IGZyb20gJ3J4anMnO1xyXG5pbXBvcnQgeyBLZEJyb2FkY2FzdGVyIH0gZnJvbSAnLi4va2QtY29tbW9uL2luZGV4JztcclxuXHJcbkBJbmplY3RhYmxlKClcclxuZXhwb3J0IGNsYXNzIEtkSW50QWR2RmlsdGVyRXZlbnQge1xyXG4gICAgY29uc3RydWN0b3IocHJpdmF0ZSBfYnJvYWRjYXN0ZXI6IEtkQnJvYWRjYXN0ZXIpIHsgfVxyXG5cclxuICAgIG9uVG9nZ2xlQWR2U2VhcmNoKCk6IE9ic2VydmFibGU8YW55PiB7XHJcbiAgICAgICAgcmV0dXJuIHRoaXMuX2Jyb2FkY2FzdGVyLm9uPGFueT4oJ0tEVG9nZ2xlQWR2U2VhcmNoJyk7XHJcbiAgICB9XHJcblxyXG4gICAgb25TZW5kRGF0YSgpOiBPYnNlcnZhYmxlPGFueT4ge1xyXG4gICAgICAgIHJldHVybiB0aGlzLl9icm9hZGNhc3Rlci5vbjxhbnk+KCdLZEZvcm1WYWx1ZScpO1xyXG4gICAgfVxyXG5cclxuICAgIHNlbmRBZHZTZWFyY2hTdGF0dXMoZGF0YT86IGFueSk6IHZvaWQge1xyXG4gICAgICAgIHRoaXMuX2Jyb2FkY2FzdGVyLmJyb2FkY2FzdCgnS2RTZW5kU2hvd1N0YXR1cycsIGRhdGEpO1xyXG4gICAgfVxyXG59XHJcblxyXG5ASW5qZWN0YWJsZSh7XHJcbiAgICBwcm92aWRlZEluOiAncm9vdCdcclxufSlcclxuZXhwb3J0IGNsYXNzIEtkQWR2RmlsdGVyRXZlbnQge1xyXG4gICAgY29uc3RydWN0b3IocHJpdmF0ZSBfYnJvYWRjYXN0ZXI6IEtkQnJvYWRjYXN0ZXIpIHsgfVxyXG5cclxuICAgIHRvZ2dsZUFkdlNlYXJjaChkYXRhPzogYW55KTogdm9pZCB7XHJcbiAgICAgICAgdGhpcy5fYnJvYWRjYXN0ZXIuYnJvYWRjYXN0KCdLRFRvZ2dsZUFkdlNlYXJjaCcsIGRhdGEpO1xyXG4gICAgfVxyXG5cclxuICAgIHNlbmREYXRhKGRhdGE/OiBhbnkpOiB2b2lkIHtcclxuICAgICAgICB0aGlzLl9icm9hZGNhc3Rlci5icm9hZGNhc3QoJ0tkRm9ybVZhbHVlJywgZGF0YSk7XHJcbiAgICB9XHJcblxyXG4gICAgb25TZW5kQWR2U2VhcmNoU3RhdHVzKGRhdGE/OiBhbnkpOiBPYnNlcnZhYmxlPGFueT4ge1xyXG4gICAgICAgIHJldHVybiB0aGlzLl9icm9hZGNhc3Rlci5vbjxhbnk+KCdLZFNlbmRTaG93U3RhdHVzJyk7XHJcbiAgICB9XHJcbn1cclxuIl19