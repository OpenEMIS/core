import { Component, Input, Output, EventEmitter, ViewEncapsulation, ViewContainerRef, HostBinding } from '@angular/core';
import { Router, NavigationEnd } from '@angular/router';
import { timer } from 'rxjs';
import { KdDomElemSvc } from '../kd-common/index';
import { KdAdvFilterEvent, KdIntAdvFilterEvent } from './kd-adv-filter-event';
export class KdAdvFilter {
    constructor(_intAdvSearchEvent, _advSearchEvent, _domSvc, _vcr, _router) {
        this._intAdvSearchEvent = _intAdvSearchEvent;
        this._advSearchEvent = _advSearchEvent;
        this._domSvc = _domSvc;
        this._vcr = _vcr;
        this._router = _router;
        this.showSearch = false;
        this.api = {};
        this._formButtons = [
            {
                type: 'submit',
                name: 'Search',
                icon: 'kd-check',
                class: 'btn-text'
            },
            {
                type: 'reset',
                name: 'Reset',
                icon: 'kd-close',
                class: 'btn-outline'
            }
        ];
        this._toShow = false;
        this.fieldValue = new EventEmitter();
        this.formValue = new EventEmitter();
        this._classShow = false;
        this._classKdxAdvSearch = true;
    }
    ngOnInit() {
        this._toggleSub = this._intAdvSearchEvent.onToggleAdvSearch().subscribe(val => {
            this._toShow = (typeof val !== 'undefined') ? val : !this._toShow;
            this._startAnimation(this._toShow);
            this._intAdvSearchEvent.sendAdvSearchStatus(this._toShow);
        });
        this._routerSub = this._router.events.subscribe(event => {
            if (event instanceof NavigationEnd) {
                this._advSearchEvent.toggleAdvSearch(false);
            }
        });
    }
    ngOnDestroy() {
        this._toggleSub.unsubscribe();
        this._routerSub.unsubscribe();
    }
    closeSearch() {
        this._advSearchEvent.toggleAdvSearch(false);
    }
    getTriggerInput(data) {
        this.fieldValue.emit(data);
    }
    getValue(fieldVal) {
        this._searchQuery = fieldVal;
    }
    formSubmitVal(formVal) {
        this.formValue.emit(formVal);
    }
    _startAnimation(isShow) {
        /*
            hide -> show
                - bring z-index up (_classShow)
                - animation right/left position via keyframe (_showSearch)

            show -> hide
                - animation right/left position via keyframe (_showSearch)
                - bring z-index down (_classShow)
         */
        if (isShow) {
            this._classShow = isShow;
            timer(200).subscribe(() => {
                this.showSearch = isShow;
            });
        }
        else {
            this.showSearch = isShow;
            timer(300).subscribe(() => {
                this._classShow = isShow;
                let scrollBackTop = this._vcr.element.nativeElement.querySelector('.kdx-adv-search-body');
                scrollBackTop.scrollTop = 0;
            });
        }
        if (this._domSvc.isMobile())
            this._checkMainWrapperOverflow(isShow);
    }
    _checkMainWrapperOverflow(_isShow) {
        let toOverflow = (_isShow) ? 'hidden' : 'auto';
        let mainWrapperEle = document.body.querySelector('.main-wrapper');
        this._domSvc.setElementStyle(mainWrapperEle, 'overflow', toOverflow);
    }
}
KdAdvFilter.decorators = [
    { type: Component, args: [{
                selector: 'kd-adv-search',
                template: "<div [ngClass]=\"{'kdx-hide-adv': !showSearch, 'kdx-show-adv': showSearch}\" class=\"kdx-adv-search-wrapper\">\r\n    <div class=\"kdx-white-bg\">\r\n    </div>\r\n    <div class=\"kdx-adv-search-content\">\r\n        <div class=\"kdx-adv-search-header\">\r\n            <i class=\"fa fa-search-plus\"></i>\r\n            <h3>Advance Search</h3>\r\n            <button class=\"btn btn-icon btn-outline\" type=\"button\" (click)=\"closeSearch()\">\r\n                <i class=\"kd-close-round\"></i>\r\n            </button> s\r\n        </div>\r\n        <div class=\"kdx-adv-search-body\">\r\n            <kd-view \r\n            displayType=\"form\" \r\n            id=\"advance-search\" \r\n            [inputData]=\"formData\" \r\n            [button]=\"_formButtons\" \r\n            [api]=\"api\" \r\n            (detectFrom)=\"getTriggerInput($event)\" \r\n            (submitEvent)=\"formSubmitVal($event)\"></kd-view>\r\n        </div>\r\n    </div>\r\n</div>\r\n",
                encapsulation: ViewEncapsulation.None,
                providers: [KdIntAdvFilterEvent, KdAdvFilterEvent]
            },] }
];
KdAdvFilter.ctorParameters = () => [
    { type: KdIntAdvFilterEvent },
    { type: KdAdvFilterEvent },
    { type: KdDomElemSvc },
    { type: ViewContainerRef },
    { type: Router }
];
KdAdvFilter.propDecorators = {
    formData: [{ type: Input }],
    fieldValue: [{ type: Output }],
    formValue: [{ type: Output }],
    _classShow: [{ type: HostBinding, args: ['class.show',] }],
    _classKdxAdvSearch: [{ type: HostBinding, args: ['class.kdx-adv-search',] }]
};
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoia2QtYW5ndWxhci1hZHYtZmlsdGVyLmpzIiwic291cmNlUm9vdCI6IkM6L3hhbXBwL2h0ZG9jcy9TdHlsZWd1aWRlL2lvc3RnLW9wZW5lbWlzLXN0eWxlZ3VpZGUvcHJvamVjdHMvb3BlbmVtaXMtc3R5bGVndWlkZS1saWIvc3JjLyIsInNvdXJjZXMiOlsia2QtY29tcG9uZW50cy9rZC1hbmd1bGFyLWFkdi1maWx0ZXIva2QtYW5ndWxhci1hZHYtZmlsdGVyLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBLE9BQU8sRUFDSCxTQUFTLEVBQ1QsS0FBSyxFQUNMLE1BQU0sRUFDTixZQUFZLEVBQ1osaUJBQWlCLEVBQ2pCLGdCQUFnQixFQUNoQixXQUFXLEVBR2QsTUFBTSxlQUFlLENBQUM7QUFDdkIsT0FBTyxFQUFFLE1BQU0sRUFBRSxhQUFhLEVBQUUsTUFBTSxpQkFBaUIsQ0FBQztBQUN4RCxPQUFPLEVBQUUsS0FBSyxFQUFrQixNQUFNLE1BQU0sQ0FBQztBQUU3QyxPQUFPLEVBQUUsWUFBWSxFQUFFLE1BQU0sb0JBQW9CLENBQUM7QUFDbEQsT0FBTyxFQUFFLGdCQUFnQixFQUFFLG1CQUFtQixFQUFFLE1BQU0sdUJBQXVCLENBQUM7QUFROUUsTUFBTSxPQUFPLFdBQVc7SUE2QnBCLFlBQ1ksa0JBQXVDLEVBQ3ZDLGVBQWlDLEVBQ2pDLE9BQXFCLEVBQ3JCLElBQXNCLEVBQ3RCLE9BQWU7UUFKZix1QkFBa0IsR0FBbEIsa0JBQWtCLENBQXFCO1FBQ3ZDLG9CQUFlLEdBQWYsZUFBZSxDQUFrQjtRQUNqQyxZQUFPLEdBQVAsT0FBTyxDQUFjO1FBQ3JCLFNBQUksR0FBSixJQUFJLENBQWtCO1FBQ3RCLFlBQU8sR0FBUCxPQUFPLENBQVE7UUFqQ3BCLGVBQVUsR0FBWSxLQUFLLENBQUM7UUFDNUIsUUFBRyxHQUFvQixFQUFFLENBQUM7UUFDMUIsaUJBQVksR0FBZTtZQUM5QjtnQkFDSSxJQUFJLEVBQUUsUUFBUTtnQkFDZCxJQUFJLEVBQUUsUUFBUTtnQkFDZCxJQUFJLEVBQUUsVUFBVTtnQkFDaEIsS0FBSyxFQUFFLFVBQVU7YUFDcEI7WUFDRDtnQkFDSSxJQUFJLEVBQUUsT0FBTztnQkFDYixJQUFJLEVBQUUsT0FBTztnQkFDYixJQUFJLEVBQUUsVUFBVTtnQkFDaEIsS0FBSyxFQUFFLGFBQWE7YUFDdkI7U0FDSixDQUFDO1FBRU0sWUFBTyxHQUFZLEtBQUssQ0FBQztRQU12QixlQUFVLEdBQXNCLElBQUksWUFBWSxFQUFFLENBQUM7UUFDbkQsY0FBUyxHQUFzQixJQUFJLFlBQVksRUFBRSxDQUFDO1FBQ2pDLGVBQVUsR0FBWSxLQUFLLENBQUM7UUFDbEIsdUJBQWtCLEdBQVksSUFBSSxDQUFDO0lBUXBFLENBQUM7SUFFTCxRQUFRO1FBQ0osSUFBSSxDQUFDLFVBQVUsR0FBRyxJQUFJLENBQUMsa0JBQWtCLENBQUMsaUJBQWlCLEVBQUUsQ0FBQyxTQUFTLENBQUMsR0FBRyxDQUFDLEVBQUU7WUFDMUUsSUFBSSxDQUFDLE9BQU8sR0FBRyxDQUFDLE9BQU8sR0FBRyxLQUFLLFdBQVcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQztZQUNsRSxJQUFJLENBQUMsZUFBZSxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsQ0FBQztZQUVuQyxJQUFJLENBQUMsa0JBQWtCLENBQUMsbUJBQW1CLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxDQUFDO1FBQzlELENBQUMsQ0FBQyxDQUFDO1FBRUgsSUFBSSxDQUFDLFVBQVUsR0FBRyxJQUFJLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxTQUFTLENBQUMsS0FBSyxDQUFDLEVBQUU7WUFDcEQsSUFBSSxLQUFLLFlBQVksYUFBYSxFQUFFO2dCQUNoQyxJQUFJLENBQUMsZUFBZSxDQUFDLGVBQWUsQ0FBQyxLQUFLLENBQUMsQ0FBQzthQUMvQztRQUNMLENBQUMsQ0FBQyxDQUFDO0lBQ1AsQ0FBQztJQUVELFdBQVc7UUFDUCxJQUFJLENBQUMsVUFBVSxDQUFDLFdBQVcsRUFBRSxDQUFDO1FBQzlCLElBQUksQ0FBQyxVQUFVLENBQUMsV0FBVyxFQUFFLENBQUM7SUFDbEMsQ0FBQztJQUVELFdBQVc7UUFDUCxJQUFJLENBQUMsZUFBZSxDQUFDLGVBQWUsQ0FBQyxLQUFLLENBQUMsQ0FBQztJQUNoRCxDQUFDO0lBRUQsZUFBZSxDQUFDLElBQVM7UUFDckIsSUFBSSxDQUFDLFVBQVUsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUM7SUFDL0IsQ0FBQztJQUVELFFBQVEsQ0FBQyxRQUFhO1FBQ2xCLElBQUksQ0FBQyxZQUFZLEdBQUcsUUFBUSxDQUFDO0lBQ2pDLENBQUM7SUFFRCxhQUFhLENBQUMsT0FBWTtRQUN0QixJQUFJLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsQ0FBQztJQUNqQyxDQUFDO0lBRU8sZUFBZSxDQUFDLE1BQWU7UUFDbkM7Ozs7Ozs7O1dBUUc7UUFDSCxJQUFJLE1BQU0sRUFBRTtZQUNSLElBQUksQ0FBQyxVQUFVLEdBQUcsTUFBTSxDQUFDO1lBQ3pCLEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FBQyxTQUFTLENBQUMsR0FBUyxFQUFFO2dCQUM1QixJQUFJLENBQUMsVUFBVSxHQUFHLE1BQU0sQ0FBQztZQUM3QixDQUFDLENBQUMsQ0FBQztTQUNOO2FBQ0k7WUFDRCxJQUFJLENBQUMsVUFBVSxHQUFHLE1BQU0sQ0FBQztZQUN6QixLQUFLLENBQUMsR0FBRyxDQUFDLENBQUMsU0FBUyxDQUFDLEdBQVMsRUFBRTtnQkFDNUIsSUFBSSxDQUFDLFVBQVUsR0FBRyxNQUFNLENBQUM7Z0JBRXpCLElBQUksYUFBYSxHQUFZLElBQUksQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLGFBQWEsQ0FBQyxhQUFhLENBQUMsc0JBQXNCLENBQUMsQ0FBQztnQkFDbkcsYUFBYSxDQUFDLFNBQVMsR0FBRyxDQUFDLENBQUM7WUFDaEMsQ0FBQyxDQUFDLENBQUM7U0FDTjtRQUVELElBQUksSUFBSSxDQUFDLE9BQU8sQ0FBQyxRQUFRLEVBQUU7WUFBRSxJQUFJLENBQUMseUJBQXlCLENBQUMsTUFBTSxDQUFDLENBQUM7SUFDeEUsQ0FBQztJQUVPLHlCQUF5QixDQUFDLE9BQWdCO1FBQzlDLElBQUksVUFBVSxHQUFXLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDO1FBQ3ZELElBQUksY0FBYyxHQUFZLFFBQVEsQ0FBQyxJQUFJLENBQUMsYUFBYSxDQUFDLGVBQWUsQ0FBQyxDQUFDO1FBQzNFLElBQUksQ0FBQyxPQUFPLENBQUMsZUFBZSxDQUFDLGNBQWMsRUFBRSxVQUFVLEVBQUUsVUFBVSxDQUFDLENBQUM7SUFDekUsQ0FBQzs7O1lBaEhKLFNBQVMsU0FBQztnQkFDUCxRQUFRLEVBQUUsZUFBZTtnQkFDekIsdzlCQUEyQztnQkFDM0MsYUFBYSxFQUFFLGlCQUFpQixDQUFDLElBQUk7Z0JBQ3JDLFNBQVMsRUFBRSxDQUFDLG1CQUFtQixFQUFFLGdCQUFnQixDQUFDO2FBQ3JEOzs7WUFQMEIsbUJBQW1CO1lBQXJDLGdCQUFnQjtZQURoQixZQUFZO1lBUmpCLGdCQUFnQjtZQUtYLE1BQU07Ozt1QkFtQ1YsS0FBSzt5QkFDTCxNQUFNO3dCQUNOLE1BQU07eUJBQ04sV0FBVyxTQUFDLFlBQVk7aUNBQ3hCLFdBQVcsU0FBQyxzQkFBc0IiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQge1xyXG4gICAgQ29tcG9uZW50LFxyXG4gICAgSW5wdXQsXHJcbiAgICBPdXRwdXQsXHJcbiAgICBFdmVudEVtaXR0ZXIsXHJcbiAgICBWaWV3RW5jYXBzdWxhdGlvbixcclxuICAgIFZpZXdDb250YWluZXJSZWYsXHJcbiAgICBIb3N0QmluZGluZyxcclxuICAgIE9uSW5pdCxcclxuICAgIE9uRGVzdHJveVxyXG59IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xyXG5pbXBvcnQgeyBSb3V0ZXIsIE5hdmlnYXRpb25FbmQgfSBmcm9tICdAYW5ndWxhci9yb3V0ZXInO1xyXG5pbXBvcnQgeyB0aW1lciAsICBTdWJzY3JpcHRpb24gfSBmcm9tICdyeGpzJztcclxuaW1wb3J0IHsgSUR5bmFtaWNGb3JtQXBpIH0gZnJvbSAnLi4va2QtYW5ndWxhci12aWV3L2luZGV4JztcclxuaW1wb3J0IHsgS2REb21FbGVtU3ZjIH0gZnJvbSAnLi4va2QtY29tbW9uL2luZGV4JztcclxuaW1wb3J0IHsgS2RBZHZGaWx0ZXJFdmVudCwgS2RJbnRBZHZGaWx0ZXJFdmVudCB9IGZyb20gJy4va2QtYWR2LWZpbHRlci1ldmVudCc7XHJcblxyXG5AQ29tcG9uZW50KHtcclxuICAgIHNlbGVjdG9yOiAna2QtYWR2LXNlYXJjaCcsXHJcbiAgICB0ZW1wbGF0ZVVybDogJy4va2QtYW5ndWxhci1hZHYtZmlsdGVyLmh0bWwnLFxyXG4gICAgZW5jYXBzdWxhdGlvbjogVmlld0VuY2Fwc3VsYXRpb24uTm9uZSxcclxuICAgIHByb3ZpZGVyczogW0tkSW50QWR2RmlsdGVyRXZlbnQsIEtkQWR2RmlsdGVyRXZlbnRdXHJcbn0pXHJcbmV4cG9ydCBjbGFzcyBLZEFkdkZpbHRlciBpbXBsZW1lbnRzIE9uSW5pdCwgT25EZXN0cm95IHtcclxuICAgIHB1YmxpYyBzaG93U2VhcmNoOiBib29sZWFuID0gZmFsc2U7XHJcbiAgICBwdWJsaWMgYXBpOiBJRHluYW1pY0Zvcm1BcGkgPSB7fTtcclxuICAgIHB1YmxpYyBfZm9ybUJ1dHRvbnM6IEFycmF5PGFueT4gPSBbXHJcbiAgICAgICAge1xyXG4gICAgICAgICAgICB0eXBlOiAnc3VibWl0JyxcclxuICAgICAgICAgICAgbmFtZTogJ1NlYXJjaCcsXHJcbiAgICAgICAgICAgIGljb246ICdrZC1jaGVjaycsXHJcbiAgICAgICAgICAgIGNsYXNzOiAnYnRuLXRleHQnXHJcbiAgICAgICAgfSxcclxuICAgICAgICB7XHJcbiAgICAgICAgICAgIHR5cGU6ICdyZXNldCcsXHJcbiAgICAgICAgICAgIG5hbWU6ICdSZXNldCcsXHJcbiAgICAgICAgICAgIGljb246ICdrZC1jbG9zZScsXHJcbiAgICAgICAgICAgIGNsYXNzOiAnYnRuLW91dGxpbmUnXHJcbiAgICAgICAgfVxyXG4gICAgXTtcclxuXHJcbiAgICBwcml2YXRlIF90b1Nob3c6IGJvb2xlYW4gPSBmYWxzZTtcclxuICAgIHByaXZhdGUgX3NlYXJjaFF1ZXJ5OiBhbnk7XHJcbiAgICBwcml2YXRlIF90b2dnbGVTdWI6IFN1YnNjcmlwdGlvbjtcclxuICAgIHByaXZhdGUgX3JvdXRlclN1YjogU3Vic2NyaXB0aW9uO1xyXG5cclxuICAgIEBJbnB1dCgpIGZvcm1EYXRhOiBBcnJheTxhbnk+O1xyXG4gICAgQE91dHB1dCgpIGZpZWxkVmFsdWU6IEV2ZW50RW1pdHRlcjxhbnk+ID0gbmV3IEV2ZW50RW1pdHRlcigpO1xyXG4gICAgQE91dHB1dCgpIGZvcm1WYWx1ZTogRXZlbnRFbWl0dGVyPGFueT4gPSBuZXcgRXZlbnRFbWl0dGVyKCk7XHJcbiAgICBASG9zdEJpbmRpbmcoJ2NsYXNzLnNob3cnKSBfY2xhc3NTaG93OiBib29sZWFuID0gZmFsc2U7XHJcbiAgICBASG9zdEJpbmRpbmcoJ2NsYXNzLmtkeC1hZHYtc2VhcmNoJykgX2NsYXNzS2R4QWR2U2VhcmNoOiBib29sZWFuID0gdHJ1ZTtcclxuXHJcbiAgICBjb25zdHJ1Y3RvcihcclxuICAgICAgICBwcml2YXRlIF9pbnRBZHZTZWFyY2hFdmVudDogS2RJbnRBZHZGaWx0ZXJFdmVudCxcclxuICAgICAgICBwcml2YXRlIF9hZHZTZWFyY2hFdmVudDogS2RBZHZGaWx0ZXJFdmVudCxcclxuICAgICAgICBwcml2YXRlIF9kb21TdmM6IEtkRG9tRWxlbVN2YyxcclxuICAgICAgICBwcml2YXRlIF92Y3I6IFZpZXdDb250YWluZXJSZWYsXHJcbiAgICAgICAgcHJpdmF0ZSBfcm91dGVyOiBSb3V0ZXJcclxuICAgICkgeyB9XHJcblxyXG4gICAgbmdPbkluaXQoKTogdm9pZCB7XHJcbiAgICAgICAgdGhpcy5fdG9nZ2xlU3ViID0gdGhpcy5faW50QWR2U2VhcmNoRXZlbnQub25Ub2dnbGVBZHZTZWFyY2goKS5zdWJzY3JpYmUodmFsID0+IHtcclxuICAgICAgICAgICAgdGhpcy5fdG9TaG93ID0gKHR5cGVvZiB2YWwgIT09ICd1bmRlZmluZWQnKSA/IHZhbCA6ICF0aGlzLl90b1Nob3c7XHJcbiAgICAgICAgICAgIHRoaXMuX3N0YXJ0QW5pbWF0aW9uKHRoaXMuX3RvU2hvdyk7XHJcblxyXG4gICAgICAgICAgICB0aGlzLl9pbnRBZHZTZWFyY2hFdmVudC5zZW5kQWR2U2VhcmNoU3RhdHVzKHRoaXMuX3RvU2hvdyk7XHJcbiAgICAgICAgfSk7XHJcblxyXG4gICAgICAgIHRoaXMuX3JvdXRlclN1YiA9IHRoaXMuX3JvdXRlci5ldmVudHMuc3Vic2NyaWJlKGV2ZW50ID0+IHtcclxuICAgICAgICAgICAgaWYgKGV2ZW50IGluc3RhbmNlb2YgTmF2aWdhdGlvbkVuZCkge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5fYWR2U2VhcmNoRXZlbnQudG9nZ2xlQWR2U2VhcmNoKGZhbHNlKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH0pO1xyXG4gICAgfVxyXG5cclxuICAgIG5nT25EZXN0cm95KCk6IHZvaWQge1xyXG4gICAgICAgIHRoaXMuX3RvZ2dsZVN1Yi51bnN1YnNjcmliZSgpO1xyXG4gICAgICAgIHRoaXMuX3JvdXRlclN1Yi51bnN1YnNjcmliZSgpO1xyXG4gICAgfVxyXG5cclxuICAgIGNsb3NlU2VhcmNoKCk6IHZvaWQge1xyXG4gICAgICAgIHRoaXMuX2FkdlNlYXJjaEV2ZW50LnRvZ2dsZUFkdlNlYXJjaChmYWxzZSk7XHJcbiAgICB9XHJcblxyXG4gICAgZ2V0VHJpZ2dlcklucHV0KGRhdGE6IGFueSk6IHZvaWQge1xyXG4gICAgICAgIHRoaXMuZmllbGRWYWx1ZS5lbWl0KGRhdGEpO1xyXG4gICAgfVxyXG5cclxuICAgIGdldFZhbHVlKGZpZWxkVmFsOiBhbnkpOiB2b2lkIHtcclxuICAgICAgICB0aGlzLl9zZWFyY2hRdWVyeSA9IGZpZWxkVmFsO1xyXG4gICAgfVxyXG5cclxuICAgIGZvcm1TdWJtaXRWYWwoZm9ybVZhbDogYW55KTogdm9pZCB7XHJcbiAgICAgICAgdGhpcy5mb3JtVmFsdWUuZW1pdChmb3JtVmFsKTtcclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF9zdGFydEFuaW1hdGlvbihpc1Nob3c6IGJvb2xlYW4pOiB2b2lkIHtcclxuICAgICAgICAvKlxyXG4gICAgICAgICAgICBoaWRlIC0+IHNob3dcclxuICAgICAgICAgICAgICAgIC0gYnJpbmcgei1pbmRleCB1cCAoX2NsYXNzU2hvdylcclxuICAgICAgICAgICAgICAgIC0gYW5pbWF0aW9uIHJpZ2h0L2xlZnQgcG9zaXRpb24gdmlhIGtleWZyYW1lIChfc2hvd1NlYXJjaClcclxuXHJcbiAgICAgICAgICAgIHNob3cgLT4gaGlkZVxyXG4gICAgICAgICAgICAgICAgLSBhbmltYXRpb24gcmlnaHQvbGVmdCBwb3NpdGlvbiB2aWEga2V5ZnJhbWUgKF9zaG93U2VhcmNoKVxyXG4gICAgICAgICAgICAgICAgLSBicmluZyB6LWluZGV4IGRvd24gKF9jbGFzc1Nob3cpXHJcbiAgICAgICAgICovXHJcbiAgICAgICAgaWYgKGlzU2hvdykge1xyXG4gICAgICAgICAgICB0aGlzLl9jbGFzc1Nob3cgPSBpc1Nob3c7XHJcbiAgICAgICAgICAgIHRpbWVyKDIwMCkuc3Vic2NyaWJlKCgpOiB2b2lkID0+IHtcclxuICAgICAgICAgICAgICAgIHRoaXMuc2hvd1NlYXJjaCA9IGlzU2hvdztcclxuICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICB0aGlzLnNob3dTZWFyY2ggPSBpc1Nob3c7XHJcbiAgICAgICAgICAgIHRpbWVyKDMwMCkuc3Vic2NyaWJlKCgpOiB2b2lkID0+IHtcclxuICAgICAgICAgICAgICAgIHRoaXMuX2NsYXNzU2hvdyA9IGlzU2hvdztcclxuXHJcbiAgICAgICAgICAgICAgICBsZXQgc2Nyb2xsQmFja1RvcDogRWxlbWVudCA9IHRoaXMuX3Zjci5lbGVtZW50Lm5hdGl2ZUVsZW1lbnQucXVlcnlTZWxlY3RvcignLmtkeC1hZHYtc2VhcmNoLWJvZHknKTtcclxuICAgICAgICAgICAgICAgIHNjcm9sbEJhY2tUb3Auc2Nyb2xsVG9wID0gMDtcclxuICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICBpZiAodGhpcy5fZG9tU3ZjLmlzTW9iaWxlKCkpIHRoaXMuX2NoZWNrTWFpbldyYXBwZXJPdmVyZmxvdyhpc1Nob3cpO1xyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX2NoZWNrTWFpbldyYXBwZXJPdmVyZmxvdyhfaXNTaG93OiBib29sZWFuKTogdm9pZCB7XHJcbiAgICAgICAgbGV0IHRvT3ZlcmZsb3c6IHN0cmluZyA9IChfaXNTaG93KSA/ICdoaWRkZW4nIDogJ2F1dG8nO1xyXG4gICAgICAgIGxldCBtYWluV3JhcHBlckVsZTogRWxlbWVudCA9IGRvY3VtZW50LmJvZHkucXVlcnlTZWxlY3RvcignLm1haW4td3JhcHBlcicpO1xyXG4gICAgICAgIHRoaXMuX2RvbVN2Yy5zZXRFbGVtZW50U3R5bGUobWFpbldyYXBwZXJFbGUsICdvdmVyZmxvdycsIHRvT3ZlcmZsb3cpO1xyXG4gICAgfVxyXG59XHJcbiJdfQ==