import { Injectable } from '@angular/core';
import { KdBroadcaster } from '../kd-common/index';
import * as i0 from "@angular/core";
import * as i1 from "../kd-common/kd-broadcaster-svc";
export class KdWizardEvent {
    constructor(_broadcaster) {
        this._broadcaster = _broadcaster;
    }
    actionClicked(_wizardId, _event) {
        this._broadcaster.broadcast(_wizardId + 'KdWizardActionClicked', _event);
    }
    onActionClicked(_wizardId) {
        return this._broadcaster.on(_wizardId + 'KdWizardActionClicked');
    }
    nextClickedWhenLastStep(_wizardId, _event) {
        this._broadcaster.broadcast(_wizardId + 'KdWizardLastStepReached', _event);
    }
    onNextClickedWhenLastStep(_wizardId) {
        return this._broadcaster.on(_wizardId + 'KdWizardLastStepReached');
    }
}
KdWizardEvent.ɵprov = i0.ɵɵdefineInjectable({ factory: function KdWizardEvent_Factory() { return new KdWizardEvent(i0.ɵɵinject(i1.KdBroadcaster)); }, token: KdWizardEvent, providedIn: "root" });
KdWizardEvent.decorators = [
    { type: Injectable, args: [{
                providedIn: 'root'
            },] }
];
KdWizardEvent.ctorParameters = () => [
    { type: KdBroadcaster }
];
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoia2QtYW5ndWxhci13aXphcmQtZXZlbnQuanMiLCJzb3VyY2VSb290IjoiQzoveGFtcHAvaHRkb2NzL1N0eWxlZ3VpZGUvaW9zdGctb3BlbmVtaXMtc3R5bGVndWlkZS9wcm9qZWN0cy9vcGVuZW1pcy1zdHlsZWd1aWRlLWxpYi9zcmMvIiwic291cmNlcyI6WyJrZC1jb21wb25lbnRzL2tkLWFuZ3VsYXItd2l6YXJkL2tkLWFuZ3VsYXItd2l6YXJkLWV2ZW50LnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBLE9BQU8sRUFBRSxVQUFVLEVBQUUsTUFBTSxlQUFlLENBQUM7QUFHM0MsT0FBTyxFQUFFLGFBQWEsRUFBRSxNQUFNLG9CQUFvQixDQUFDOzs7QUFLbkQsTUFBTSxPQUFPLGFBQWE7SUFDdEIsWUFDWSxZQUEyQjtRQUEzQixpQkFBWSxHQUFaLFlBQVksQ0FBZTtJQUNuQyxDQUFDO0lBRUUsYUFBYSxDQUFDLFNBQWlCLEVBQUUsTUFBWTtRQUNoRCxJQUFJLENBQUMsWUFBWSxDQUFDLFNBQVMsQ0FBQyxTQUFTLEdBQUcsdUJBQXVCLEVBQUUsTUFBTSxDQUFDLENBQUM7SUFDN0UsQ0FBQztJQUVNLGVBQWUsQ0FBQyxTQUFpQjtRQUNwQyxPQUFPLElBQUksQ0FBQyxZQUFZLENBQUMsRUFBRSxDQUFNLFNBQVMsR0FBRyx1QkFBdUIsQ0FBQyxDQUFDO0lBQzFFLENBQUM7SUFFTSx1QkFBdUIsQ0FBQyxTQUFpQixFQUFFLE1BQVk7UUFDMUQsSUFBSSxDQUFDLFlBQVksQ0FBQyxTQUFTLENBQUMsU0FBUyxHQUFHLHlCQUF5QixFQUFFLE1BQU0sQ0FBQyxDQUFDO0lBQy9FLENBQUM7SUFFTSx5QkFBeUIsQ0FBQyxTQUFpQjtRQUM5QyxPQUFPLElBQUksQ0FBQyxZQUFZLENBQUMsRUFBRSxDQUFNLFNBQVMsR0FBRyx5QkFBeUIsQ0FBQyxDQUFDO0lBQzVFLENBQUM7Ozs7WUF0QkosVUFBVSxTQUFDO2dCQUNSLFVBQVUsRUFBRSxNQUFNO2FBQ3JCOzs7WUFKUSxhQUFhIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgSW5qZWN0YWJsZSB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xyXG5pbXBvcnQgeyBPYnNlcnZhYmxlIH0gZnJvbSAncnhqcyc7XHJcblxyXG5pbXBvcnQgeyBLZEJyb2FkY2FzdGVyIH0gZnJvbSAnLi4va2QtY29tbW9uL2luZGV4JztcclxuXHJcbkBJbmplY3RhYmxlKHtcclxuICAgIHByb3ZpZGVkSW46ICdyb290J1xyXG59KVxyXG5leHBvcnQgY2xhc3MgS2RXaXphcmRFdmVudCB7XHJcbiAgICBjb25zdHJ1Y3RvcihcclxuICAgICAgICBwcml2YXRlIF9icm9hZGNhc3RlcjogS2RCcm9hZGNhc3RlclxyXG4gICAgKSB7IH1cclxuXHJcbiAgICBwdWJsaWMgYWN0aW9uQ2xpY2tlZChfd2l6YXJkSWQ6IHN0cmluZywgX2V2ZW50PzogYW55KTogdm9pZCB7XHJcbiAgICAgICAgdGhpcy5fYnJvYWRjYXN0ZXIuYnJvYWRjYXN0KF93aXphcmRJZCArICdLZFdpemFyZEFjdGlvbkNsaWNrZWQnLCBfZXZlbnQpO1xyXG4gICAgfVxyXG5cclxuICAgIHB1YmxpYyBvbkFjdGlvbkNsaWNrZWQoX3dpemFyZElkOiBzdHJpbmcpOiBPYnNlcnZhYmxlPGFueT4ge1xyXG4gICAgICAgIHJldHVybiB0aGlzLl9icm9hZGNhc3Rlci5vbjxhbnk+KF93aXphcmRJZCArICdLZFdpemFyZEFjdGlvbkNsaWNrZWQnKTtcclxuICAgIH1cclxuXHJcbiAgICBwdWJsaWMgbmV4dENsaWNrZWRXaGVuTGFzdFN0ZXAoX3dpemFyZElkOiBzdHJpbmcsIF9ldmVudD86IGFueSk6IHZvaWQge1xyXG4gICAgICAgIHRoaXMuX2Jyb2FkY2FzdGVyLmJyb2FkY2FzdChfd2l6YXJkSWQgKyAnS2RXaXphcmRMYXN0U3RlcFJlYWNoZWQnLCBfZXZlbnQpO1xyXG4gICAgfVxyXG5cclxuICAgIHB1YmxpYyBvbk5leHRDbGlja2VkV2hlbkxhc3RTdGVwKF93aXphcmRJZDogc3RyaW5nKTogT2JzZXJ2YWJsZTxhbnk+IHtcclxuICAgICAgICByZXR1cm4gdGhpcy5fYnJvYWRjYXN0ZXIub248YW55Pihfd2l6YXJkSWQgKyAnS2RXaXphcmRMYXN0U3RlcFJlYWNoZWQnKTtcclxuICAgIH1cclxufVxyXG4iXX0=