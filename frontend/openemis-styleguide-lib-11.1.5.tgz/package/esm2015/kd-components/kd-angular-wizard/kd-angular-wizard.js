import { Component, ViewEncapsulation, Input, HostListener, Output, EventEmitter, } from '@angular/core';
import { timer } from 'rxjs';
import { debounceTime } from 'rxjs/operators';
import { Router } from '@angular/router';
import { KdWizardEvent } from './kd-angular-wizard-event';
import { KdWizardSvc } from './kd-angular-wizard-svc';
import { KdDomElemSvc } from '../kd-common/index';
import { KdSplitterEvent } from '../kd-angular-splitter/index';
export class KdWizard {
    constructor(_router, _kdWizardEvent, _kdWizardSvc, _kdDomSvc, _kdSplitterEvent) {
        this._router = _router;
        this._kdWizardEvent = _kdWizardEvent;
        this._kdWizardSvc = _kdWizardSvc;
        this._kdDomSvc = _kdDomSvc;
        this.steps = [];
        this.isButtonHidden = false;
        this.isPreviousDisabled = true;
        this.isNextDisabled = false;
        this.tooltipDisabled = false;
        this._tooltipNotDisplayed = false;
        this.activeStepEmitter = new EventEmitter();
        this._dragMenuSub = _kdSplitterEvent.onDrag()
            .pipe(debounceTime(100))
            .subscribe(() => {
            this._handleTranslateAndTooltip();
        });
        this._toggleMenuSub = _kdSplitterEvent.onToggleMenu().subscribe(() => {
            timer(500).subscribe(() => {
                this._handleTranslateAndTooltip();
            });
        });
    }
    onResize(event) {
        timer(200).subscribe(() => {
            this._handleTranslateAndTooltip();
        });
    }
    ngOnInit() {
        this.id = typeof this.wizardId === 'undefined' ? 'wizard' : this.wizardId;
        this.steps = this._kdWizardSvc.setItem(this.config.steps);
        this._initApi();
        this.nextButtonText = this.config.next || 'Next';
        this.activeStep = this.steps[0];
        this._emitStep(this.steps[0].content);
        this.isMobileDevice = this._kdDomSvc.isMobileDevice();
        if (this.isMobileDevice || window.innerWidth < 481) {
            this.tooltipDisabled = true;
            this._tooltipNotDisplayed = true;
        }
    }
    ngAfterViewInit() {
        this._kdWizardSvc.direction = this._kdDomSvc.getDocumentDirection(true) || 'left';
        this._kdWizardSvc.totalSteps = this.steps.length;
        this._kdWizardSvc.setContainerAndStepElement(this.id);
    }
    ngOnDestroy() {
        this._dragMenuSub.unsubscribe();
        this._toggleMenuSub.unsubscribe();
    }
    /* user clicks and goes back to past steps */
    selectedStep(_step, e) {
        e.preventDefault();
        if (!_step.isDisabled) {
            // make clicked step active
            this.steps[_step.id].isActive = true;
            // disable all future steps
            for (let i = _step.id + 1; i < this.steps.length; ++i) {
                this.steps[i].isDisabled = true;
                if (this.steps[i].isActive)
                    this.steps[i].isActive = false;
            }
            this.activeStep = _step;
            this._kdWizardSvc.translateViewToClickedElem(this.activeStep);
            // update button's text. disable 'previous' button if first step, and change text of 'next' button for last step
            this._updateButton();
            // emit current step to parent component's DOM to render required content
            this._emitStep(_step.content);
        }
    }
    actionClicked(_action, e) {
        e.preventDefault();
        // emit click event to outside of component, provides action type (next or previous), current step and whether this is last step
        this._kdWizardEvent.actionClicked(this.id, {
            action: _action,
            step: this.activeStep,
            isLast: this.activeStep.id === this.steps.length - 1
        });
    }
    openToottip(e) {
        e.preventDefault();
        if (this._tooltipNotDisplayed)
            return;
        if (this._kdWizardSvc.isStepOutOfBounds(e)) {
            this.tooltipDisabled = true;
        }
        else {
            this.tooltipDisabled = false;
        }
    }
    _initApi() {
        if (typeof this.api !== 'undefined') {
            this.api.updateSteps = (_action) => this._updateSteps(_action);
            this.api.enableButton = (_type) => this._enableButton(_type);
            this.api.disableButton = (_type) => this._disableButton(_type);
            this.api.getActiveStep = () => this.activeStep;
            this.api.hideButton = () => { this.isButtonHidden = true; };
            this.api.showButton = () => { this.isButtonHidden = false; };
        }
    }
    /* update Steps when validation (done by application via api) is done */
    _updateSteps(_action) {
        // broadcast 'next' button is clicked when at last step and when validation (done by application) is done
        if (this.activeStep.id === this.steps.length - 1 && _action === 'next') {
            this._kdWizardEvent.nextClickedWhenLastStep(this.id);
            return;
        }
        let index = this.activeStep.id;
        switch (_action) {
            case 'previous':
                if (index !== 0) {
                    this.steps[index - 1].isActive = true;
                    this.steps[index].isDisabled = true;
                    this.steps[index].isActive = false;
                    this.activeStep = this.steps[this.activeStep.id - 1];
                }
                break;
            case 'next':
                if (index !== this.steps.length - 1) {
                    this.steps[index].isActive = false;
                    this.steps[index + 1].isActive = true;
                    this.steps[index + 1].isDisabled = false;
                    this.activeStep = this.steps[this.activeStep.id + 1];
                }
                break;
            default:
                break;
        }
        this._kdWizardSvc.translateViewToClickedElem(this.activeStep);
        this._updateButton();
        this._emitStep(this.activeStep.content);
    }
    _emitStep(_content) {
        if (this.contentType === 'html')
            this.activeStepEmitter.emit(_content);
        if (this.contentType === 'router')
            this._router.navigateByUrl(_content);
    }
    _handleTranslateAndTooltip() {
        this._kdWizardSvc.translateViewToClickedElem(this.activeStep);
        if (!this.isMobileDevice) {
            this.tooltipDisabled = window.innerWidth > 480 ? false : true;
            this._tooltipNotDisplayed = this.tooltipDisabled;
        }
    }
    /* set the text of next and previous buttons depending on which step */
    _updateButton() {
        // disable first step's previous button
        this.isPreviousDisabled = this.activeStep.id === 0 ? true : false;
        // change text of last step's next button to 'complete'
        this.nextButtonText = this.activeStep.id === this.steps.length - 1 ? this.config.complete || 'Complete' : this.config.next || 'Next';
    }
    /* enable external components to enable or disable next and previous buttons */
    _enableButton(_type) {
        if (_type === 'previous')
            this.isPreviousDisabled = false;
        if (_type === 'next')
            this.isNextDisabled = false;
    }
    _disableButton(_type) {
        if (_type === 'previous')
            this.isPreviousDisabled = true;
        if (_type === 'next')
            this.isNextDisabled = true;
    }
}
KdWizard.decorators = [
    { type: Component, args: [{
                selector: 'kd-wizard',
                template: "<div class=\"kdx kdx-wizard\" [id]=\"id\">\r\n    <div class=\"kdx-wizard-steps-container\">\r\n        <div class=\"kdx-wizard-inner-wrapper\">\r\n            <ul>\r\n                <li [ngClass]='{\"kdx-wizard-step-selected\": step.isActive, \"step-disabled\": step.isDisabled, \"step-enabled\": !step.isDisabled}' *ngFor=\"let step of steps; let isFirst = first; let isLast = last; \">\r\n                    <a (click)='selectedStep(step, $event)' class='kdx-step-container' data-step=\"i\">\r\n                        <div class=\"kdx-step-progress-and-icon\" [ngClass]='{\"kdx-bar-hide-first\": isFirst, \"kdx-bar-hide-last\": isLast }'>\r\n                            <div class=\"kdx-step-icon\">\r\n                                <i class=\"{{step.icon}}\" *ngIf=\"step.iconType === 'icon'\"></i>\r\n                                <div class=\"kdx-step-icon-string\" *ngIf=\"step.iconType === 'number'\">{{step.icon}}</div>\r\n                            </div>\r\n                        </div>\r\n                        <div class=\"kdx-step-text\" [kd-tooltip-dir]=\"step.tooltipString\" tooltipPosition=\"bottom\" tooltipStyleClass=\"tooltip-wizard\" tooltipEvent=\"hover\" [tooltipDisabled]=\"tooltipDisabled\" [escape]=\"false\" (mouseenter)='openToottip($event)'>\r\n                            <div class=\"step-label ellipsis-wizard\" >\r\n                                {{step.label}}\r\n                            </div>\r\n                            <div class=\"step-description ellipsis-wizard\" *ngIf=\"step.description && !isMobileDevice\">\r\n                                {{step.description}}\r\n                            </div>\r\n                        </div>\r\n                    </a>\r\n                </li>\r\n            </ul>\r\n        </div>\r\n    </div>\r\n    <div class=\"steps-content\">\r\n        <div class=\"step-text-mobile\">\r\n            <div class=\"step-label-mobile\" >\r\n                {{activeStep.label}}\r\n            </div>\r\n            <div class=\"step-description-mobile\" *ngIf=\"activeStep.description\">\r\n                {{activeStep.description}}\r\n            </div>\r\n        </div>\r\n        <ng-template [ngIf]='contentType === \"text\"'>\r\n            <div class='step-content'>\r\n                <div class='step-pane'>{{activeStep.content}}</div>\r\n            </div>\r\n        </ng-template>\r\n        <ng-template [ngIf]='contentType === \"html\"'>\r\n            <ng-content></ng-content>\r\n        </ng-template>\r\n        <ng-template [ngIf]='contentType === \"router\"'>\r\n            <router-outlet></router-outlet>\r\n        </ng-template>\r\n    </div>\r\n    <div class=\"steps-bottom\">\r\n        <div class=\"actions-bottom\" [ngClass]='{\"actions-hide\": isButtonHidden}'>\r\n            <button class=\"btn previous-button\" [disabled]=\"isPreviousDisabled\" (click)=\"actionClicked('previous', $event)\">\r\n                <i class=\"fa fa-caret-left previous-icon icon\"></i>\r\n                {{config.previous || 'Previous'}}\r\n            </button>\r\n            <button class=\"btn next-button\" [disabled]=\"isNextDisabled\" (click)=\"actionClicked('next', $event)\">\r\n                <i class=\"fa fa-caret-right next-icon icon\"></i>\r\n                {{nextButtonText}}\r\n            </button>\r\n        </div>\r\n    </div>\r\n</div>",
                encapsulation: ViewEncapsulation.None,
                providers: [KdWizardSvc, KdDomElemSvc]
            },] }
];
KdWizard.ctorParameters = () => [
    { type: Router },
    { type: KdWizardEvent },
    { type: KdWizardSvc },
    { type: KdDomElemSvc },
    { type: KdSplitterEvent }
];
KdWizard.propDecorators = {
    wizardId: [{ type: Input, args: ['id',] }],
    config: [{ type: Input }],
    contentType: [{ type: Input, args: ['type',] }],
    api: [{ type: Input }],
    activeStepEmitter: [{ type: Output }],
    onResize: [{ type: HostListener, args: ['window:resize', ['$event'],] }]
};
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoia2QtYW5ndWxhci13aXphcmQuanMiLCJzb3VyY2VSb290IjoiQzoveGFtcHAvaHRkb2NzL1N0eWxlZ3VpZGUvaW9zdGctb3BlbmVtaXMtc3R5bGVndWlkZS9wcm9qZWN0cy9vcGVuZW1pcy1zdHlsZWd1aWRlLWxpYi9zcmMvIiwic291cmNlcyI6WyJrZC1jb21wb25lbnRzL2tkLWFuZ3VsYXItd2l6YXJkL2tkLWFuZ3VsYXItd2l6YXJkLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBLE9BQU8sRUFDSCxTQUFTLEVBQ1QsaUJBQWlCLEVBQ2pCLEtBQUssRUFHTCxZQUFZLEVBQ1osTUFBTSxFQUNOLFlBQVksR0FFZixNQUFNLGVBQWUsQ0FBQztBQUN2QixPQUFPLEVBQWtCLEtBQUssRUFBRSxNQUFNLE1BQU0sQ0FBQztBQUM3QyxPQUFPLEVBQUUsWUFBWSxFQUFFLE1BQU0sZ0JBQWdCLENBQUM7QUFDOUMsT0FBTyxFQUFFLE1BQU0sRUFBRSxNQUFNLGlCQUFpQixDQUFDO0FBQ3pDLE9BQU8sRUFBRSxhQUFhLEVBQUUsTUFBTSwyQkFBMkIsQ0FBQztBQUMxRCxPQUFPLEVBQUUsV0FBVyxFQUFFLE1BQU0seUJBQXlCLENBQUM7QUFDdEQsT0FBTyxFQUFFLFlBQVksRUFBRSxNQUFNLG9CQUFvQixDQUFDO0FBQ2xELE9BQU8sRUFBRSxlQUFlLEVBQUUsTUFBTSw4QkFBOEIsQ0FBQztBQThCL0QsTUFBTSxPQUFPLFFBQVE7SUFxQmpCLFlBQ1ksT0FBZSxFQUNmLGNBQTZCLEVBQzdCLFlBQXlCLEVBQ3pCLFNBQXVCLEVBQy9CLGdCQUFpQztRQUp6QixZQUFPLEdBQVAsT0FBTyxDQUFRO1FBQ2YsbUJBQWMsR0FBZCxjQUFjLENBQWU7UUFDN0IsaUJBQVksR0FBWixZQUFZLENBQWE7UUFDekIsY0FBUyxHQUFULFNBQVMsQ0FBYztRQXZCNUIsVUFBSyxHQUFpQixFQUFFLENBQUM7UUFDekIsbUJBQWMsR0FBWSxLQUFLLENBQUM7UUFDaEMsdUJBQWtCLEdBQVksSUFBSSxDQUFDO1FBQ25DLG1CQUFjLEdBQVksS0FBSyxDQUFDO1FBR2hDLG9CQUFlLEdBQVksS0FBSyxDQUFDO1FBS2hDLHlCQUFvQixHQUFZLEtBQUssQ0FBQztRQU1wQyxzQkFBaUIsR0FBcUIsSUFBSSxZQUFZLEVBQUUsQ0FBQztRQVMvRCxJQUFJLENBQUMsWUFBWSxHQUFHLGdCQUFnQixDQUFDLE1BQU0sRUFBRTthQUN4QyxJQUFJLENBQ0QsWUFBWSxDQUFDLEdBQUcsQ0FBQyxDQUNwQjthQUNBLFNBQVMsQ0FBQyxHQUFTLEVBQUU7WUFDbEIsSUFBSSxDQUFDLDBCQUEwQixFQUFFLENBQUM7UUFDdEMsQ0FBQyxDQUFDLENBQUM7UUFFUCxJQUFJLENBQUMsY0FBYyxHQUFHLGdCQUFnQixDQUFDLFlBQVksRUFBRSxDQUFDLFNBQVMsQ0FBQyxHQUFTLEVBQUU7WUFDdkUsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxHQUFTLEVBQUU7Z0JBQzVCLElBQUksQ0FBQywwQkFBMEIsRUFBRSxDQUFDO1lBQ3RDLENBQUMsQ0FBQyxDQUFDO1FBQ1AsQ0FBQyxDQUFDLENBQUM7SUFDUCxDQUFDO0lBR0QsUUFBUSxDQUFDLEtBQVU7UUFDZixLQUFLLENBQUMsR0FBRyxDQUFDLENBQUMsU0FBUyxDQUFDLEdBQVMsRUFBRTtZQUM1QixJQUFJLENBQUMsMEJBQTBCLEVBQUUsQ0FBQztRQUN0QyxDQUFDLENBQUMsQ0FBQztJQUNQLENBQUM7SUFFRCxRQUFRO1FBQ0osSUFBSSxDQUFDLEVBQUUsR0FBRyxPQUFPLElBQUksQ0FBQyxRQUFRLEtBQUssV0FBVyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUM7UUFDMUUsSUFBSSxDQUFDLEtBQUssR0FBRyxJQUFJLENBQUMsWUFBWSxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxDQUFDO1FBQzFELElBQUksQ0FBQyxRQUFRLEVBQUUsQ0FBQztRQUNoQixJQUFJLENBQUMsY0FBYyxHQUFHLElBQUksQ0FBQyxNQUFNLENBQUMsSUFBSSxJQUFJLE1BQU0sQ0FBQztRQUNqRCxJQUFJLENBQUMsVUFBVSxHQUFHLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUM7UUFDaEMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDO1FBQ3RDLElBQUksQ0FBQyxjQUFjLEdBQUcsSUFBSSxDQUFDLFNBQVMsQ0FBQyxjQUFjLEVBQUUsQ0FBQztRQUN0RCxJQUFJLElBQUksQ0FBQyxjQUFjLElBQUksTUFBTSxDQUFDLFVBQVUsR0FBRyxHQUFHLEVBQUU7WUFDaEQsSUFBSSxDQUFDLGVBQWUsR0FBRyxJQUFJLENBQUM7WUFDNUIsSUFBSSxDQUFDLG9CQUFvQixHQUFHLElBQUksQ0FBQztTQUNwQztJQUNMLENBQUM7SUFFRCxlQUFlO1FBQ1gsSUFBSSxDQUFDLFlBQVksQ0FBQyxTQUFTLEdBQUcsSUFBSSxDQUFDLFNBQVMsQ0FBQyxvQkFBb0IsQ0FBQyxJQUFJLENBQUMsSUFBSSxNQUFNLENBQUM7UUFDbEYsSUFBSSxDQUFDLFlBQVksQ0FBQyxVQUFVLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUM7UUFDakQsSUFBSSxDQUFDLFlBQVksQ0FBQywwQkFBMEIsQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDLENBQUM7SUFDMUQsQ0FBQztJQUVELFdBQVc7UUFDUCxJQUFJLENBQUMsWUFBWSxDQUFDLFdBQVcsRUFBRSxDQUFDO1FBQ2hDLElBQUksQ0FBQyxjQUFjLENBQUMsV0FBVyxFQUFFLENBQUM7SUFDdEMsQ0FBQztJQUVELDZDQUE2QztJQUN0QyxZQUFZLENBQUMsS0FBWSxFQUFFLENBQVE7UUFDdEMsQ0FBQyxDQUFDLGNBQWMsRUFBRSxDQUFDO1FBQ25CLElBQUksQ0FBQyxLQUFLLENBQUMsVUFBVSxFQUFFO1lBQ25CLDJCQUEyQjtZQUMzQixJQUFJLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxFQUFFLENBQUMsQ0FBQyxRQUFRLEdBQUcsSUFBSSxDQUFDO1lBQ3JDLDJCQUEyQjtZQUMzQixLQUFLLElBQUksQ0FBQyxHQUFHLEtBQUssQ0FBQyxFQUFFLEdBQUcsQ0FBQyxFQUFFLENBQUMsR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDLE1BQU0sRUFBRSxFQUFFLENBQUMsRUFBRTtnQkFDbkQsSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxVQUFVLEdBQUcsSUFBSSxDQUFDO2dCQUNoQyxJQUFJLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUTtvQkFBRSxJQUFJLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsR0FBRyxLQUFLLENBQUM7YUFDOUQ7WUFDRCxJQUFJLENBQUMsVUFBVSxHQUFHLEtBQUssQ0FBQztZQUN4QixJQUFJLENBQUMsWUFBWSxDQUFDLDBCQUEwQixDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsQ0FBQztZQUM5RCxnSEFBZ0g7WUFDaEgsSUFBSSxDQUFDLGFBQWEsRUFBRSxDQUFDO1lBQ3JCLHlFQUF5RTtZQUN6RSxJQUFJLENBQUMsU0FBUyxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsQ0FBQztTQUNqQztJQUNMLENBQUM7SUFFTSxhQUFhLENBQUMsT0FBZSxFQUFFLENBQVE7UUFDMUMsQ0FBQyxDQUFDLGNBQWMsRUFBRSxDQUFDO1FBQ25CLGdJQUFnSTtRQUNoSSxJQUFJLENBQUMsY0FBYyxDQUFDLGFBQWEsQ0FDN0IsSUFBSSxDQUFDLEVBQUUsRUFDUDtZQUNJLE1BQU0sRUFBRSxPQUFPO1lBQ2YsSUFBSSxFQUFFLElBQUksQ0FBQyxVQUFVO1lBQ3JCLE1BQU0sRUFBRSxJQUFJLENBQUMsVUFBVSxDQUFDLEVBQUUsS0FBSyxJQUFJLENBQUMsS0FBSyxDQUFDLE1BQU0sR0FBRyxDQUFDO1NBQ3ZELENBQ0osQ0FBQztJQUNOLENBQUM7SUFFTSxXQUFXLENBQUMsQ0FBUTtRQUN2QixDQUFDLENBQUMsY0FBYyxFQUFFLENBQUM7UUFDbkIsSUFBSSxJQUFJLENBQUMsb0JBQW9CO1lBQUUsT0FBTztRQUN0QyxJQUFJLElBQUksQ0FBQyxZQUFZLENBQUMsaUJBQWlCLENBQUMsQ0FBQyxDQUFDLEVBQUU7WUFDeEMsSUFBSSxDQUFDLGVBQWUsR0FBRyxJQUFJLENBQUM7U0FDL0I7YUFBTTtZQUNILElBQUksQ0FBQyxlQUFlLEdBQUcsS0FBSyxDQUFDO1NBQ2hDO0lBQ0wsQ0FBQztJQUVPLFFBQVE7UUFDWixJQUFJLE9BQU8sSUFBSSxDQUFDLEdBQUcsS0FBSyxXQUFXLEVBQUU7WUFDakMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxXQUFXLEdBQUcsQ0FBQyxPQUFlLEVBQVEsRUFBRSxDQUFDLElBQUksQ0FBQyxZQUFZLENBQUMsT0FBTyxDQUFDLENBQUM7WUFDN0UsSUFBSSxDQUFDLEdBQUcsQ0FBQyxZQUFZLEdBQUcsQ0FBQyxLQUFhLEVBQVEsRUFBRSxDQUFDLElBQUksQ0FBQyxhQUFhLENBQUMsS0FBSyxDQUFDLENBQUM7WUFDM0UsSUFBSSxDQUFDLEdBQUcsQ0FBQyxhQUFhLEdBQUcsQ0FBQyxLQUFhLEVBQVEsRUFBRSxDQUFDLElBQUksQ0FBQyxjQUFjLENBQUMsS0FBSyxDQUFDLENBQUM7WUFDN0UsSUFBSSxDQUFDLEdBQUcsQ0FBQyxhQUFhLEdBQUcsR0FBVSxFQUFFLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQztZQUN0RCxJQUFJLENBQUMsR0FBRyxDQUFDLFVBQVUsR0FBRyxHQUFTLEVBQUUsR0FBRyxJQUFJLENBQUMsY0FBYyxHQUFHLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQztZQUNsRSxJQUFJLENBQUMsR0FBRyxDQUFDLFVBQVUsR0FBRyxHQUFTLEVBQUUsR0FBRyxJQUFJLENBQUMsY0FBYyxHQUFHLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQztTQUN0RTtJQUNMLENBQUM7SUFFRCx3RUFBd0U7SUFDaEUsWUFBWSxDQUFDLE9BQWU7UUFDaEMseUdBQXlHO1FBQ3pHLElBQUksSUFBSSxDQUFDLFVBQVUsQ0FBQyxFQUFFLEtBQUssSUFBSSxDQUFDLEtBQUssQ0FBQyxNQUFNLEdBQUcsQ0FBQyxJQUFJLE9BQU8sS0FBSyxNQUFNLEVBQUU7WUFDcEUsSUFBSSxDQUFDLGNBQWMsQ0FBQyx1QkFBdUIsQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDLENBQUM7WUFDckQsT0FBTztTQUNWO1FBQ0QsSUFBSSxLQUFLLEdBQVcsSUFBSSxDQUFDLFVBQVUsQ0FBQyxFQUFFLENBQUM7UUFDdkMsUUFBUSxPQUFPLEVBQUU7WUFDYixLQUFLLFVBQVU7Z0JBQ1gsSUFBSSxLQUFLLEtBQUssQ0FBQyxFQUFFO29CQUNiLElBQUksQ0FBQyxLQUFLLENBQUMsS0FBSyxHQUFHLENBQUMsQ0FBQyxDQUFDLFFBQVEsR0FBRyxJQUFJLENBQUM7b0JBQ3RDLElBQUksQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLENBQUMsVUFBVSxHQUFHLElBQUksQ0FBQztvQkFDcEMsSUFBSSxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsQ0FBQyxRQUFRLEdBQUcsS0FBSyxDQUFDO29CQUNuQyxJQUFJLENBQUMsVUFBVSxHQUFHLElBQUksQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxFQUFFLEdBQUcsQ0FBQyxDQUFDLENBQUM7aUJBQ3hEO2dCQUNELE1BQU07WUFDVixLQUFLLE1BQU07Z0JBQ1AsSUFBSSxLQUFLLEtBQUssSUFBSSxDQUFDLEtBQUssQ0FBQyxNQUFNLEdBQUcsQ0FBQyxFQUFFO29CQUNqQyxJQUFJLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxDQUFDLFFBQVEsR0FBRyxLQUFLLENBQUM7b0JBQ25DLElBQUksQ0FBQyxLQUFLLENBQUMsS0FBSyxHQUFHLENBQUMsQ0FBQyxDQUFDLFFBQVEsR0FBRyxJQUFJLENBQUM7b0JBQ3RDLElBQUksQ0FBQyxLQUFLLENBQUMsS0FBSyxHQUFHLENBQUMsQ0FBQyxDQUFDLFVBQVUsR0FBRyxLQUFLLENBQUM7b0JBQ3pDLElBQUksQ0FBQyxVQUFVLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLEVBQUUsR0FBRyxDQUFDLENBQUMsQ0FBQztpQkFDeEQ7Z0JBQ0QsTUFBTTtZQUNWO2dCQUNJLE1BQU07U0FDYjtRQUNELElBQUksQ0FBQyxZQUFZLENBQUMsMEJBQTBCLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxDQUFDO1FBQzlELElBQUksQ0FBQyxhQUFhLEVBQUUsQ0FBQztRQUNyQixJQUFJLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsT0FBTyxDQUFDLENBQUM7SUFDNUMsQ0FBQztJQUVPLFNBQVMsQ0FBQyxRQUFRO1FBQ3RCLElBQUksSUFBSSxDQUFDLFdBQVcsS0FBSyxNQUFNO1lBQUUsSUFBSSxDQUFDLGlCQUFpQixDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsQ0FBQztRQUN2RSxJQUFJLElBQUksQ0FBQyxXQUFXLEtBQUssUUFBUTtZQUFFLElBQUksQ0FBQyxPQUFPLENBQUMsYUFBYSxDQUFDLFFBQVEsQ0FBQyxDQUFDO0lBQzVFLENBQUM7SUFFTywwQkFBMEI7UUFDOUIsSUFBSSxDQUFDLFlBQVksQ0FBQywwQkFBMEIsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLENBQUM7UUFDOUQsSUFBSSxDQUFDLElBQUksQ0FBQyxjQUFjLEVBQUU7WUFDdEIsSUFBSSxDQUFDLGVBQWUsR0FBRyxNQUFNLENBQUMsVUFBVSxHQUFHLEdBQUcsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUM7WUFDOUQsSUFBSSxDQUFDLG9CQUFvQixHQUFHLElBQUksQ0FBQyxlQUFlLENBQUM7U0FDcEQ7SUFDTCxDQUFDO0lBRUQsdUVBQXVFO0lBQy9ELGFBQWE7UUFDakIsdUNBQXVDO1FBQ3ZDLElBQUksQ0FBQyxrQkFBa0IsR0FBRyxJQUFJLENBQUMsVUFBVSxDQUFDLEVBQUUsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDO1FBRWxFLHVEQUF1RDtRQUN2RCxJQUFJLENBQUMsY0FBYyxHQUFHLElBQUksQ0FBQyxVQUFVLENBQUMsRUFBRSxLQUFLLElBQUksQ0FBQyxLQUFLLENBQUMsTUFBTSxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxRQUFRLElBQUksVUFBVSxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLElBQUksSUFBSSxNQUFNLENBQUM7SUFDekksQ0FBQztJQUVELCtFQUErRTtJQUN2RSxhQUFhLENBQUMsS0FBYTtRQUMvQixJQUFJLEtBQUssS0FBSyxVQUFVO1lBQUUsSUFBSSxDQUFDLGtCQUFrQixHQUFHLEtBQUssQ0FBQztRQUMxRCxJQUFJLEtBQUssS0FBSyxNQUFNO1lBQUUsSUFBSSxDQUFDLGNBQWMsR0FBRyxLQUFLLENBQUM7SUFDdEQsQ0FBQztJQUVPLGNBQWMsQ0FBQyxLQUFhO1FBQ2hDLElBQUksS0FBSyxLQUFLLFVBQVU7WUFBRSxJQUFJLENBQUMsa0JBQWtCLEdBQUcsSUFBSSxDQUFDO1FBQ3pELElBQUksS0FBSyxLQUFLLE1BQU07WUFBRSxJQUFJLENBQUMsY0FBYyxHQUFHLElBQUksQ0FBQztJQUNyRCxDQUFDOzs7WUF4TUosU0FBUyxTQUFDO2dCQUNQLFFBQVEsRUFBRSxXQUFXO2dCQUNyQiwwekdBQXVDO2dCQUN2QyxhQUFhLEVBQUUsaUJBQWlCLENBQUMsSUFBSTtnQkFDckMsU0FBUyxFQUFFLENBQUMsV0FBVyxFQUFFLFlBQVksQ0FBQzthQUN6Qzs7O1lBaENRLE1BQU07WUFDTixhQUFhO1lBQ2IsV0FBVztZQUNYLFlBQVk7WUFDWixlQUFlOzs7dUJBNkNuQixLQUFLLFNBQUMsSUFBSTtxQkFDVixLQUFLOzBCQUNMLEtBQUssU0FBQyxNQUFNO2tCQUNaLEtBQUs7Z0NBQ0wsTUFBTTt1QkF3Qk4sWUFBWSxTQUFDLGVBQWUsRUFBRSxDQUFDLFFBQVEsQ0FBQyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7XHJcbiAgICBDb21wb25lbnQsXHJcbiAgICBWaWV3RW5jYXBzdWxhdGlvbixcclxuICAgIElucHV0LFxyXG4gICAgT25Jbml0LFxyXG4gICAgT25EZXN0cm95LFxyXG4gICAgSG9zdExpc3RlbmVyLFxyXG4gICAgT3V0cHV0LFxyXG4gICAgRXZlbnRFbWl0dGVyLFxyXG4gICAgQWZ0ZXJWaWV3SW5pdCxcclxufSBmcm9tICdAYW5ndWxhci9jb3JlJztcclxuaW1wb3J0IHsgU3Vic2NyaXB0aW9uICwgIHRpbWVyIH0gZnJvbSAncnhqcyc7XHJcbmltcG9ydCB7IGRlYm91bmNlVGltZSB9IGZyb20gJ3J4anMvb3BlcmF0b3JzJztcclxuaW1wb3J0IHsgUm91dGVyIH0gZnJvbSAnQGFuZ3VsYXIvcm91dGVyJztcclxuaW1wb3J0IHsgS2RXaXphcmRFdmVudCB9IGZyb20gJy4va2QtYW5ndWxhci13aXphcmQtZXZlbnQnO1xyXG5pbXBvcnQgeyBLZFdpemFyZFN2YyB9IGZyb20gJy4va2QtYW5ndWxhci13aXphcmQtc3ZjJztcclxuaW1wb3J0IHsgS2REb21FbGVtU3ZjIH0gZnJvbSAnLi4va2QtY29tbW9uL2luZGV4JztcclxuaW1wb3J0IHsgS2RTcGxpdHRlckV2ZW50IH0gZnJvbSAnLi4va2QtYW5ndWxhci1zcGxpdHRlci9pbmRleCc7XHJcblxyXG5leHBvcnQgaW50ZXJmYWNlIElTdGVwIHtcclxuICAgIGlkOiBudW1iZXI7XHJcbiAgICBsYWJlbDogc3RyaW5nO1xyXG4gICAgY29udGVudDogc3RyaW5nO1xyXG4gICAgZGVzY3JpcHRpb24/OiBzdHJpbmc7XHJcbiAgICBpY29uOiBzdHJpbmc7XHJcbiAgICBpY29uVHlwZTogc3RyaW5nO1xyXG4gICAgaXNBY3RpdmU6IGJvb2xlYW47XHJcbiAgICBpc0Rpc2FibGVkOiBib29sZWFuO1xyXG4gICAgdG9vbHRpcFN0cmluZzogc3RyaW5nO1xyXG59XHJcblxyXG5leHBvcnQgaW50ZXJmYWNlIElXaXphcmRBcGkge1xyXG4gICAgdXBkYXRlU3RlcHM/OiAoX2FjdGlvbjogc3RyaW5nKSA9PiB2b2lkO1xyXG4gICAgZW5hYmxlQnV0dG9uPzogKF90eXBlOiBzdHJpbmcpID0+IHZvaWQ7XHJcbiAgICBkaXNhYmxlQnV0dG9uPzogKF90eXBlOiBzdHJpbmcpID0+IHZvaWQ7XHJcbiAgICBnZXRBY3RpdmVTdGVwPzogKCkgPT4gSVN0ZXA7XHJcbiAgICBoaWRlQnV0dG9uPzogKCkgPT4gdm9pZDtcclxuICAgIHNob3dCdXR0b24/OiAoKSA9PiB2b2lkO1xyXG59XHJcblxyXG5AQ29tcG9uZW50KHtcclxuICAgIHNlbGVjdG9yOiAna2Qtd2l6YXJkJyxcclxuICAgIHRlbXBsYXRlVXJsOiAnLi9rZC1hbmd1bGFyLXdpemFyZC5odG1sJyxcclxuICAgIGVuY2Fwc3VsYXRpb246IFZpZXdFbmNhcHN1bGF0aW9uLk5vbmUsXHJcbiAgICBwcm92aWRlcnM6IFtLZFdpemFyZFN2YywgS2REb21FbGVtU3ZjXVxyXG59KVxyXG5cclxuZXhwb3J0IGNsYXNzIEtkV2l6YXJkIGltcGxlbWVudHMgT25Jbml0LCBBZnRlclZpZXdJbml0LCBPbkRlc3Ryb3kge1xyXG4gICAgcHVibGljIGlkOiBzdHJpbmc7XHJcbiAgICBwdWJsaWMgc3RlcHM6IEFycmF5PElTdGVwPiA9IFtdO1xyXG4gICAgcHVibGljIGlzQnV0dG9uSGlkZGVuOiBib29sZWFuID0gZmFsc2U7XHJcbiAgICBwdWJsaWMgaXNQcmV2aW91c0Rpc2FibGVkOiBib29sZWFuID0gdHJ1ZTtcclxuICAgIHB1YmxpYyBpc05leHREaXNhYmxlZDogYm9vbGVhbiA9IGZhbHNlO1xyXG4gICAgcHVibGljIG5leHRCdXR0b25UZXh0OiBzdHJpbmc7XHJcbiAgICBwdWJsaWMgYWN0aXZlU3RlcDogSVN0ZXA7XHJcbiAgICBwdWJsaWMgdG9vbHRpcERpc2FibGVkOiBib29sZWFuID0gZmFsc2U7XHJcbiAgICBwdWJsaWMgaXNNb2JpbGVEZXZpY2U6IGJvb2xlYW47XHJcblxyXG4gICAgcHJpdmF0ZSBfZHJhZ01lbnVTdWI6IFN1YnNjcmlwdGlvbjtcclxuICAgIHByaXZhdGUgX3RvZ2dsZU1lbnVTdWI6IFN1YnNjcmlwdGlvbjtcclxuICAgIHByaXZhdGUgX3Rvb2x0aXBOb3REaXNwbGF5ZWQ6IGJvb2xlYW4gPSBmYWxzZTtcclxuXHJcbiAgICBASW5wdXQoJ2lkJykgd2l6YXJkSWQ6IHN0cmluZztcclxuICAgIEBJbnB1dCgpIGNvbmZpZzogYW55O1xyXG4gICAgQElucHV0KCd0eXBlJykgY29udGVudFR5cGU6IHN0cmluZztcclxuICAgIEBJbnB1dCgpIGFwaTogSVdpemFyZEFwaTtcclxuICAgIEBPdXRwdXQoKSBhY3RpdmVTdGVwRW1pdHRlcjogRXZlbnRFbWl0dGVyPHt9PiA9IG5ldyBFdmVudEVtaXR0ZXIoKTtcclxuXHJcbiAgICBjb25zdHJ1Y3RvcihcclxuICAgICAgICBwcml2YXRlIF9yb3V0ZXI6IFJvdXRlcixcclxuICAgICAgICBwcml2YXRlIF9rZFdpemFyZEV2ZW50OiBLZFdpemFyZEV2ZW50LFxyXG4gICAgICAgIHByaXZhdGUgX2tkV2l6YXJkU3ZjOiBLZFdpemFyZFN2YyxcclxuICAgICAgICBwcml2YXRlIF9rZERvbVN2YzogS2REb21FbGVtU3ZjLFxyXG4gICAgICAgIF9rZFNwbGl0dGVyRXZlbnQ6IEtkU3BsaXR0ZXJFdmVudCxcclxuICAgICkge1xyXG4gICAgICAgIHRoaXMuX2RyYWdNZW51U3ViID0gX2tkU3BsaXR0ZXJFdmVudC5vbkRyYWcoKVxyXG4gICAgICAgICAgICAucGlwZShcclxuICAgICAgICAgICAgICAgIGRlYm91bmNlVGltZSgxMDApXHJcbiAgICAgICAgICAgIClcclxuICAgICAgICAgICAgLnN1YnNjcmliZSgoKTogdm9pZCA9PiB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLl9oYW5kbGVUcmFuc2xhdGVBbmRUb29sdGlwKCk7XHJcbiAgICAgICAgICAgIH0pO1xyXG5cclxuICAgICAgICB0aGlzLl90b2dnbGVNZW51U3ViID0gX2tkU3BsaXR0ZXJFdmVudC5vblRvZ2dsZU1lbnUoKS5zdWJzY3JpYmUoKCk6IHZvaWQgPT4ge1xyXG4gICAgICAgICAgICB0aW1lcig1MDApLnN1YnNjcmliZSgoKTogdm9pZCA9PiB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLl9oYW5kbGVUcmFuc2xhdGVBbmRUb29sdGlwKCk7XHJcbiAgICAgICAgICAgIH0pO1xyXG4gICAgICAgIH0pO1xyXG4gICAgfVxyXG5cclxuICAgIEBIb3N0TGlzdGVuZXIoJ3dpbmRvdzpyZXNpemUnLCBbJyRldmVudCddKVxyXG4gICAgb25SZXNpemUoZXZlbnQ6IGFueSk6IHZvaWQge1xyXG4gICAgICAgIHRpbWVyKDIwMCkuc3Vic2NyaWJlKCgpOiB2b2lkID0+IHtcclxuICAgICAgICAgICAgdGhpcy5faGFuZGxlVHJhbnNsYXRlQW5kVG9vbHRpcCgpO1xyXG4gICAgICAgIH0pO1xyXG4gICAgfVxyXG5cclxuICAgIG5nT25Jbml0KCk6IHZvaWQge1xyXG4gICAgICAgIHRoaXMuaWQgPSB0eXBlb2YgdGhpcy53aXphcmRJZCA9PT0gJ3VuZGVmaW5lZCcgPyAnd2l6YXJkJyA6IHRoaXMud2l6YXJkSWQ7XHJcbiAgICAgICAgdGhpcy5zdGVwcyA9IHRoaXMuX2tkV2l6YXJkU3ZjLnNldEl0ZW0odGhpcy5jb25maWcuc3RlcHMpO1xyXG4gICAgICAgIHRoaXMuX2luaXRBcGkoKTtcclxuICAgICAgICB0aGlzLm5leHRCdXR0b25UZXh0ID0gdGhpcy5jb25maWcubmV4dCB8fCAnTmV4dCc7XHJcbiAgICAgICAgdGhpcy5hY3RpdmVTdGVwID0gdGhpcy5zdGVwc1swXTtcclxuICAgICAgICB0aGlzLl9lbWl0U3RlcCh0aGlzLnN0ZXBzWzBdLmNvbnRlbnQpO1xyXG4gICAgICAgIHRoaXMuaXNNb2JpbGVEZXZpY2UgPSB0aGlzLl9rZERvbVN2Yy5pc01vYmlsZURldmljZSgpO1xyXG4gICAgICAgIGlmICh0aGlzLmlzTW9iaWxlRGV2aWNlIHx8IHdpbmRvdy5pbm5lcldpZHRoIDwgNDgxKSB7XHJcbiAgICAgICAgICAgIHRoaXMudG9vbHRpcERpc2FibGVkID0gdHJ1ZTtcclxuICAgICAgICAgICAgdGhpcy5fdG9vbHRpcE5vdERpc3BsYXllZCA9IHRydWU7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIG5nQWZ0ZXJWaWV3SW5pdCgpOiB2b2lkIHtcclxuICAgICAgICB0aGlzLl9rZFdpemFyZFN2Yy5kaXJlY3Rpb24gPSB0aGlzLl9rZERvbVN2Yy5nZXREb2N1bWVudERpcmVjdGlvbih0cnVlKSB8fCAnbGVmdCc7XHJcbiAgICAgICAgdGhpcy5fa2RXaXphcmRTdmMudG90YWxTdGVwcyA9IHRoaXMuc3RlcHMubGVuZ3RoO1xyXG4gICAgICAgIHRoaXMuX2tkV2l6YXJkU3ZjLnNldENvbnRhaW5lckFuZFN0ZXBFbGVtZW50KHRoaXMuaWQpO1xyXG4gICAgfVxyXG5cclxuICAgIG5nT25EZXN0cm95KCk6IHZvaWQge1xyXG4gICAgICAgIHRoaXMuX2RyYWdNZW51U3ViLnVuc3Vic2NyaWJlKCk7XHJcbiAgICAgICAgdGhpcy5fdG9nZ2xlTWVudVN1Yi51bnN1YnNjcmliZSgpO1xyXG4gICAgfVxyXG5cclxuICAgIC8qIHVzZXIgY2xpY2tzIGFuZCBnb2VzIGJhY2sgdG8gcGFzdCBzdGVwcyAqL1xyXG4gICAgcHVibGljIHNlbGVjdGVkU3RlcChfc3RlcDogSVN0ZXAsIGU6IEV2ZW50KTogdm9pZCB7XHJcbiAgICAgICAgZS5wcmV2ZW50RGVmYXVsdCgpO1xyXG4gICAgICAgIGlmICghX3N0ZXAuaXNEaXNhYmxlZCkge1xyXG4gICAgICAgICAgICAvLyBtYWtlIGNsaWNrZWQgc3RlcCBhY3RpdmVcclxuICAgICAgICAgICAgdGhpcy5zdGVwc1tfc3RlcC5pZF0uaXNBY3RpdmUgPSB0cnVlO1xyXG4gICAgICAgICAgICAvLyBkaXNhYmxlIGFsbCBmdXR1cmUgc3RlcHNcclxuICAgICAgICAgICAgZm9yIChsZXQgaSA9IF9zdGVwLmlkICsgMTsgaSA8IHRoaXMuc3RlcHMubGVuZ3RoOyArK2kpIHtcclxuICAgICAgICAgICAgICAgIHRoaXMuc3RlcHNbaV0uaXNEaXNhYmxlZCA9IHRydWU7XHJcbiAgICAgICAgICAgICAgICBpZiAodGhpcy5zdGVwc1tpXS5pc0FjdGl2ZSkgdGhpcy5zdGVwc1tpXS5pc0FjdGl2ZSA9IGZhbHNlO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIHRoaXMuYWN0aXZlU3RlcCA9IF9zdGVwO1xyXG4gICAgICAgICAgICB0aGlzLl9rZFdpemFyZFN2Yy50cmFuc2xhdGVWaWV3VG9DbGlja2VkRWxlbSh0aGlzLmFjdGl2ZVN0ZXApO1xyXG4gICAgICAgICAgICAvLyB1cGRhdGUgYnV0dG9uJ3MgdGV4dC4gZGlzYWJsZSAncHJldmlvdXMnIGJ1dHRvbiBpZiBmaXJzdCBzdGVwLCBhbmQgY2hhbmdlIHRleHQgb2YgJ25leHQnIGJ1dHRvbiBmb3IgbGFzdCBzdGVwXHJcbiAgICAgICAgICAgIHRoaXMuX3VwZGF0ZUJ1dHRvbigpO1xyXG4gICAgICAgICAgICAvLyBlbWl0IGN1cnJlbnQgc3RlcCB0byBwYXJlbnQgY29tcG9uZW50J3MgRE9NIHRvIHJlbmRlciByZXF1aXJlZCBjb250ZW50XHJcbiAgICAgICAgICAgIHRoaXMuX2VtaXRTdGVwKF9zdGVwLmNvbnRlbnQpO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICBwdWJsaWMgYWN0aW9uQ2xpY2tlZChfYWN0aW9uOiBzdHJpbmcsIGU6IEV2ZW50KTogdm9pZCB7XHJcbiAgICAgICAgZS5wcmV2ZW50RGVmYXVsdCgpO1xyXG4gICAgICAgIC8vIGVtaXQgY2xpY2sgZXZlbnQgdG8gb3V0c2lkZSBvZiBjb21wb25lbnQsIHByb3ZpZGVzIGFjdGlvbiB0eXBlIChuZXh0IG9yIHByZXZpb3VzKSwgY3VycmVudCBzdGVwIGFuZCB3aGV0aGVyIHRoaXMgaXMgbGFzdCBzdGVwXHJcbiAgICAgICAgdGhpcy5fa2RXaXphcmRFdmVudC5hY3Rpb25DbGlja2VkKFxyXG4gICAgICAgICAgICB0aGlzLmlkLFxyXG4gICAgICAgICAgICB7XHJcbiAgICAgICAgICAgICAgICBhY3Rpb246IF9hY3Rpb24sXHJcbiAgICAgICAgICAgICAgICBzdGVwOiB0aGlzLmFjdGl2ZVN0ZXAsXHJcbiAgICAgICAgICAgICAgICBpc0xhc3Q6IHRoaXMuYWN0aXZlU3RlcC5pZCA9PT0gdGhpcy5zdGVwcy5sZW5ndGggLSAxXHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICApO1xyXG4gICAgfVxyXG5cclxuICAgIHB1YmxpYyBvcGVuVG9vdHRpcChlOiBFdmVudCk6IHZvaWQge1xyXG4gICAgICAgIGUucHJldmVudERlZmF1bHQoKTtcclxuICAgICAgICBpZiAodGhpcy5fdG9vbHRpcE5vdERpc3BsYXllZCkgcmV0dXJuO1xyXG4gICAgICAgIGlmICh0aGlzLl9rZFdpemFyZFN2Yy5pc1N0ZXBPdXRPZkJvdW5kcyhlKSkge1xyXG4gICAgICAgICAgICB0aGlzLnRvb2x0aXBEaXNhYmxlZCA9IHRydWU7XHJcbiAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgdGhpcy50b29sdGlwRGlzYWJsZWQgPSBmYWxzZTtcclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfaW5pdEFwaSgpOiB2b2lkIHtcclxuICAgICAgICBpZiAodHlwZW9mIHRoaXMuYXBpICE9PSAndW5kZWZpbmVkJykge1xyXG4gICAgICAgICAgICB0aGlzLmFwaS51cGRhdGVTdGVwcyA9IChfYWN0aW9uOiBzdHJpbmcpOiB2b2lkID0+IHRoaXMuX3VwZGF0ZVN0ZXBzKF9hY3Rpb24pO1xyXG4gICAgICAgICAgICB0aGlzLmFwaS5lbmFibGVCdXR0b24gPSAoX3R5cGU6IHN0cmluZyk6IHZvaWQgPT4gdGhpcy5fZW5hYmxlQnV0dG9uKF90eXBlKTtcclxuICAgICAgICAgICAgdGhpcy5hcGkuZGlzYWJsZUJ1dHRvbiA9IChfdHlwZTogc3RyaW5nKTogdm9pZCA9PiB0aGlzLl9kaXNhYmxlQnV0dG9uKF90eXBlKTtcclxuICAgICAgICAgICAgdGhpcy5hcGkuZ2V0QWN0aXZlU3RlcCA9ICgpOiBJU3RlcCA9PiB0aGlzLmFjdGl2ZVN0ZXA7XHJcbiAgICAgICAgICAgIHRoaXMuYXBpLmhpZGVCdXR0b24gPSAoKTogdm9pZCA9PiB7IHRoaXMuaXNCdXR0b25IaWRkZW4gPSB0cnVlOyB9O1xyXG4gICAgICAgICAgICB0aGlzLmFwaS5zaG93QnV0dG9uID0gKCk6IHZvaWQgPT4geyB0aGlzLmlzQnV0dG9uSGlkZGVuID0gZmFsc2U7IH07XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIC8qIHVwZGF0ZSBTdGVwcyB3aGVuIHZhbGlkYXRpb24gKGRvbmUgYnkgYXBwbGljYXRpb24gdmlhIGFwaSkgaXMgZG9uZSAqL1xyXG4gICAgcHJpdmF0ZSBfdXBkYXRlU3RlcHMoX2FjdGlvbjogc3RyaW5nKTogdm9pZCB7XHJcbiAgICAgICAgLy8gYnJvYWRjYXN0ICduZXh0JyBidXR0b24gaXMgY2xpY2tlZCB3aGVuIGF0IGxhc3Qgc3RlcCBhbmQgd2hlbiB2YWxpZGF0aW9uIChkb25lIGJ5IGFwcGxpY2F0aW9uKSBpcyBkb25lXHJcbiAgICAgICAgaWYgKHRoaXMuYWN0aXZlU3RlcC5pZCA9PT0gdGhpcy5zdGVwcy5sZW5ndGggLSAxICYmIF9hY3Rpb24gPT09ICduZXh0Jykge1xyXG4gICAgICAgICAgICB0aGlzLl9rZFdpemFyZEV2ZW50Lm5leHRDbGlja2VkV2hlbkxhc3RTdGVwKHRoaXMuaWQpO1xyXG4gICAgICAgICAgICByZXR1cm47XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGxldCBpbmRleDogbnVtYmVyID0gdGhpcy5hY3RpdmVTdGVwLmlkO1xyXG4gICAgICAgIHN3aXRjaCAoX2FjdGlvbikge1xyXG4gICAgICAgICAgICBjYXNlICdwcmV2aW91cyc6XHJcbiAgICAgICAgICAgICAgICBpZiAoaW5kZXggIT09IDApIHtcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLnN0ZXBzW2luZGV4IC0gMV0uaXNBY3RpdmUgPSB0cnVlO1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuc3RlcHNbaW5kZXhdLmlzRGlzYWJsZWQgPSB0cnVlO1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuc3RlcHNbaW5kZXhdLmlzQWN0aXZlID0gZmFsc2U7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5hY3RpdmVTdGVwID0gdGhpcy5zdGVwc1t0aGlzLmFjdGl2ZVN0ZXAuaWQgLSAxXTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgICAgICBjYXNlICduZXh0JzpcclxuICAgICAgICAgICAgICAgIGlmIChpbmRleCAhPT0gdGhpcy5zdGVwcy5sZW5ndGggLSAxKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5zdGVwc1tpbmRleF0uaXNBY3RpdmUgPSBmYWxzZTtcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLnN0ZXBzW2luZGV4ICsgMV0uaXNBY3RpdmUgPSB0cnVlO1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuc3RlcHNbaW5kZXggKyAxXS5pc0Rpc2FibGVkID0gZmFsc2U7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5hY3RpdmVTdGVwID0gdGhpcy5zdGVwc1t0aGlzLmFjdGl2ZVN0ZXAuaWQgKyAxXTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgICAgICBkZWZhdWx0OlxyXG4gICAgICAgICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIHRoaXMuX2tkV2l6YXJkU3ZjLnRyYW5zbGF0ZVZpZXdUb0NsaWNrZWRFbGVtKHRoaXMuYWN0aXZlU3RlcCk7XHJcbiAgICAgICAgdGhpcy5fdXBkYXRlQnV0dG9uKCk7XHJcbiAgICAgICAgdGhpcy5fZW1pdFN0ZXAodGhpcy5hY3RpdmVTdGVwLmNvbnRlbnQpO1xyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX2VtaXRTdGVwKF9jb250ZW50KTogdm9pZCB7XHJcbiAgICAgICAgaWYgKHRoaXMuY29udGVudFR5cGUgPT09ICdodG1sJykgdGhpcy5hY3RpdmVTdGVwRW1pdHRlci5lbWl0KF9jb250ZW50KTtcclxuICAgICAgICBpZiAodGhpcy5jb250ZW50VHlwZSA9PT0gJ3JvdXRlcicpIHRoaXMuX3JvdXRlci5uYXZpZ2F0ZUJ5VXJsKF9jb250ZW50KTtcclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF9oYW5kbGVUcmFuc2xhdGVBbmRUb29sdGlwKCk6IHZvaWQge1xyXG4gICAgICAgIHRoaXMuX2tkV2l6YXJkU3ZjLnRyYW5zbGF0ZVZpZXdUb0NsaWNrZWRFbGVtKHRoaXMuYWN0aXZlU3RlcCk7XHJcbiAgICAgICAgaWYgKCF0aGlzLmlzTW9iaWxlRGV2aWNlKSB7XHJcbiAgICAgICAgICAgIHRoaXMudG9vbHRpcERpc2FibGVkID0gd2luZG93LmlubmVyV2lkdGggPiA0ODAgPyBmYWxzZSA6IHRydWU7XHJcbiAgICAgICAgICAgIHRoaXMuX3Rvb2x0aXBOb3REaXNwbGF5ZWQgPSB0aGlzLnRvb2x0aXBEaXNhYmxlZDtcclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgLyogc2V0IHRoZSB0ZXh0IG9mIG5leHQgYW5kIHByZXZpb3VzIGJ1dHRvbnMgZGVwZW5kaW5nIG9uIHdoaWNoIHN0ZXAgKi9cclxuICAgIHByaXZhdGUgX3VwZGF0ZUJ1dHRvbigpOiB2b2lkIHtcclxuICAgICAgICAvLyBkaXNhYmxlIGZpcnN0IHN0ZXAncyBwcmV2aW91cyBidXR0b25cclxuICAgICAgICB0aGlzLmlzUHJldmlvdXNEaXNhYmxlZCA9IHRoaXMuYWN0aXZlU3RlcC5pZCA9PT0gMCA/IHRydWUgOiBmYWxzZTtcclxuXHJcbiAgICAgICAgLy8gY2hhbmdlIHRleHQgb2YgbGFzdCBzdGVwJ3MgbmV4dCBidXR0b24gdG8gJ2NvbXBsZXRlJ1xyXG4gICAgICAgIHRoaXMubmV4dEJ1dHRvblRleHQgPSB0aGlzLmFjdGl2ZVN0ZXAuaWQgPT09IHRoaXMuc3RlcHMubGVuZ3RoIC0gMSA/IHRoaXMuY29uZmlnLmNvbXBsZXRlIHx8ICdDb21wbGV0ZScgOiB0aGlzLmNvbmZpZy5uZXh0IHx8ICdOZXh0JztcclxuICAgIH1cclxuXHJcbiAgICAvKiBlbmFibGUgZXh0ZXJuYWwgY29tcG9uZW50cyB0byBlbmFibGUgb3IgZGlzYWJsZSBuZXh0IGFuZCBwcmV2aW91cyBidXR0b25zICovXHJcbiAgICBwcml2YXRlIF9lbmFibGVCdXR0b24oX3R5cGU6IHN0cmluZyk6IHZvaWQge1xyXG4gICAgICAgIGlmIChfdHlwZSA9PT0gJ3ByZXZpb3VzJykgdGhpcy5pc1ByZXZpb3VzRGlzYWJsZWQgPSBmYWxzZTtcclxuICAgICAgICBpZiAoX3R5cGUgPT09ICduZXh0JykgdGhpcy5pc05leHREaXNhYmxlZCA9IGZhbHNlO1xyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX2Rpc2FibGVCdXR0b24oX3R5cGU6IHN0cmluZyk6IHZvaWQge1xyXG4gICAgICAgIGlmIChfdHlwZSA9PT0gJ3ByZXZpb3VzJykgdGhpcy5pc1ByZXZpb3VzRGlzYWJsZWQgPSB0cnVlO1xyXG4gICAgICAgIGlmIChfdHlwZSA9PT0gJ25leHQnKSB0aGlzLmlzTmV4dERpc2FibGVkID0gdHJ1ZTtcclxuICAgIH1cclxufVxyXG4iXX0=