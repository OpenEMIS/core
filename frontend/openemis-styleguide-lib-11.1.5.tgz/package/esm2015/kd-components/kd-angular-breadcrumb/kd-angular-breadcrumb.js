import { Component, Input, ViewEncapsulation, ViewContainerRef, } from '@angular/core';
import { timer, fromEvent } from 'rxjs';
import { debounceTime } from 'rxjs/operators';
import { KdBreadcrumbSvc } from './kd-angular-breadcrumb-svc';
import { KdDomElemSvc } from '../kd-common/index';
export class KdBreadcrumb {
    constructor(_vcr, _breadcrumbSvc) {
        this._vcr = _vcr;
        this._breadcrumbSvc = _breadcrumbSvc;
        this.breadcrumbResult = [];
    }
    ngOnInit() {
        this.resizeSub = fromEvent(window, 'resize')
            .pipe(debounceTime(500))
            .subscribe(e => {
            this.breadcrumbResult = this._breadcrumbSvc.renderBreadcrumbView(this._vcr, this.breadcrumbConfig);
        });
        this._initApi();
    }
    ngOnChanges(_simpleChanges) {
        if (_simpleChanges.hasOwnProperty('breadcrumbConfig')) {
            timer().subscribe(() => {
                this.breadcrumbResult = this._breadcrumbSvc.renderBreadcrumbView(this._vcr, this.breadcrumbConfig);
            });
        }
    }
    ngAfterViewInit() { }
    _initApi() {
        if (!this.api)
            return;
        this.api.addBreadcrumb = (_item) => {
            this.breadcrumbConfig.list.push(_item);
            this.breadcrumbResult = this._breadcrumbSvc.renderBreadcrumbView(this._vcr, this.breadcrumbConfig);
        };
        this.api.updateBreadcrumb = (_pos, _item) => {
            this.breadcrumbConfig.list[_pos - 1] = _item;
            this.breadcrumbResult = this._breadcrumbSvc.renderBreadcrumbView(this._vcr, this.breadcrumbConfig);
        };
        this.api.getBreadcrumbs = () => {
            return this.breadcrumbConfig;
        };
    }
}
KdBreadcrumb.decorators = [
    { type: Component, args: [{
                selector: 'kd-breadcrumb',
                template: `
        <ul class="breadcrumb panel-breadcrumb">
            <ng-template ngFor let-crumb [ngForOf]="breadcrumbResult">
                <li *ngIf="crumb.toEllipsis">
                    <i class="fa kd-ellipsis ellipsis fa-rotate-90"></i>
                </li>
                <li *ngIf="!crumb.toEllipsis" [class.list-hide]="!crumb.toRender" >
                    <a  *ngIf="crumb.path && crumb.path !== ''" [routerLink]="crumb.path">
                        <i *ngIf="crumb.icon && crumb.icon !=''" class="{{crumb.icon}}"></i>
                        <span *ngIf="crumb.name && crumb.name !== ''">{{crumb.name}}</span>
                    </a>
                    <a *ngIf="crumb.url && crumb.url !== ''" [href]="crumb.url">
                        <i *ngIf="crumb.icon && crumb.icon !=''" class="{{crumb.icon}}"></i>
                        <span *ngIf="crumb.name && crumb.name !== ''">{{crumb.name}}</span>
                    </a>
                    <div *ngIf="(!crumb.path || crumb.path=='') && (crumb.url=='' || !crumb.url)">
                        <i *ngIf="crumb.icon && crumb.icon !=''" class="{{crumb.icon}}"></i>
                        <span *ngIf="crumb.name && crumb.name !== ''">{{crumb.name}}</span>
                    </div>
                </li>
            </ng-template>
        </ul>
    `,
                encapsulation: ViewEncapsulation.None,
                providers: [KdBreadcrumbSvc, KdDomElemSvc],
                host: { 'class': 'kdx-breadcrumb' }
            },] }
];
KdBreadcrumb.ctorParameters = () => [
    { type: ViewContainerRef },
    { type: KdBreadcrumbSvc }
];
KdBreadcrumb.propDecorators = {
    breadcrumbConfig: [{ type: Input, args: ['config',] }],
    api: [{ type: Input }]
};
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoia2QtYW5ndWxhci1icmVhZGNydW1iLmpzIiwic291cmNlUm9vdCI6IkM6L3hhbXBwL2h0ZG9jcy9TdHlsZWd1aWRlL2lvc3RnLW9wZW5lbWlzLXN0eWxlZ3VpZGUvcHJvamVjdHMvb3BlbmVtaXMtc3R5bGVndWlkZS1saWIvc3JjLyIsInNvdXJjZXMiOlsia2QtY29tcG9uZW50cy9rZC1hbmd1bGFyLWJyZWFkY3J1bWIva2QtYW5ndWxhci1icmVhZGNydW1iLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBLE9BQU8sRUFDSCxTQUFTLEVBQ1QsS0FBSyxFQUNMLGlCQUFpQixFQUlqQixnQkFBZ0IsR0FFbkIsTUFBTSxlQUFlLENBQUM7QUFDdkIsT0FBTyxFQUFFLEtBQUssRUFBZ0IsU0FBUyxFQUFFLE1BQU0sTUFBTSxDQUFDO0FBQ3RELE9BQU8sRUFBRSxZQUFZLEVBQUUsTUFBTSxnQkFBZ0IsQ0FBQztBQUM5QyxPQUFPLEVBQUUsZUFBZSxFQUFFLE1BQU0sNkJBQTZCLENBQUM7QUFDOUQsT0FBTyxFQUFFLFlBQVksRUFBRSxNQUFNLG9CQUFvQixDQUFDO0FBaUNsRCxNQUFNLE9BQU8sWUFBWTtJQU1yQixZQUNZLElBQXNCLEVBQ3RCLGNBQStCO1FBRC9CLFNBQUksR0FBSixJQUFJLENBQWtCO1FBQ3RCLG1CQUFjLEdBQWQsY0FBYyxDQUFpQjtRQVBwQyxxQkFBZ0IsR0FBK0IsRUFBRSxDQUFDO0lBUXJELENBQUM7SUFFTCxRQUFRO1FBQ0osSUFBSSxDQUFDLFNBQVMsR0FBRyxTQUFTLENBQUMsTUFBTSxFQUFFLFFBQVEsQ0FBQzthQUN2QyxJQUFJLENBQ0QsWUFBWSxDQUFDLEdBQUcsQ0FBQyxDQUNwQjthQUNBLFNBQVMsQ0FBQyxDQUFDLENBQUMsRUFBRTtZQUNYLElBQUksQ0FBQyxnQkFBZ0IsR0FBRyxJQUFJLENBQUMsY0FBYyxDQUFDLG9CQUFvQixDQUFDLElBQUksQ0FBQyxJQUFJLEVBQUUsSUFBSSxDQUFDLGdCQUFnQixDQUFDLENBQUM7UUFDdkcsQ0FBQyxDQUFDLENBQUM7UUFFUCxJQUFJLENBQUMsUUFBUSxFQUFFLENBQUM7SUFDcEIsQ0FBQztJQUVELFdBQVcsQ0FBQyxjQUE2QjtRQUNyQyxJQUFJLGNBQWMsQ0FBQyxjQUFjLENBQUMsa0JBQWtCLENBQUMsRUFBRTtZQUNuRCxLQUFLLEVBQUUsQ0FBQyxTQUFTLENBQUMsR0FBUyxFQUFFO2dCQUN6QixJQUFJLENBQUMsZ0JBQWdCLEdBQUcsSUFBSSxDQUFDLGNBQWMsQ0FBQyxvQkFBb0IsQ0FBQyxJQUFJLENBQUMsSUFBSSxFQUFFLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDO1lBQ3ZHLENBQUMsQ0FBQyxDQUFDO1NBQ047SUFDTCxDQUFDO0lBRUQsZUFBZSxLQUFXLENBQUM7SUFFbkIsUUFBUTtRQUNaLElBQUksQ0FBQyxJQUFJLENBQUMsR0FBRztZQUFFLE9BQU87UUFFdEIsSUFBSSxDQUFDLEdBQUcsQ0FBQyxhQUFhLEdBQUcsQ0FBQyxLQUFrQixFQUFFLEVBQUU7WUFDNUMsSUFBSSxDQUFDLGdCQUFnQixDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLENBQUM7WUFDdkMsSUFBSSxDQUFDLGdCQUFnQixHQUFHLElBQUksQ0FBQyxjQUFjLENBQUMsb0JBQW9CLENBQUMsSUFBSSxDQUFDLElBQUksRUFBRSxJQUFJLENBQUMsZ0JBQWdCLENBQUMsQ0FBQztRQUN2RyxDQUFDLENBQUM7UUFFRixJQUFJLENBQUMsR0FBRyxDQUFDLGdCQUFnQixHQUFHLENBQUMsSUFBWSxFQUFFLEtBQWtCLEVBQUUsRUFBRTtZQUM3RCxJQUFJLENBQUMsZ0JBQWdCLENBQUMsSUFBSSxDQUFDLElBQUksR0FBRyxDQUFDLENBQUMsR0FBRyxLQUFLLENBQUM7WUFDN0MsSUFBSSxDQUFDLGdCQUFnQixHQUFHLElBQUksQ0FBQyxjQUFjLENBQUMsb0JBQW9CLENBQUMsSUFBSSxDQUFDLElBQUksRUFBRSxJQUFJLENBQUMsZ0JBQWdCLENBQUMsQ0FBQztRQUN2RyxDQUFDLENBQUM7UUFFRixJQUFJLENBQUMsR0FBRyxDQUFDLGNBQWMsR0FBRyxHQUFzQixFQUFFO1lBQzlDLE9BQU8sSUFBSSxDQUFDLGdCQUFnQixDQUFDO1FBQ2pDLENBQUMsQ0FBQztJQUNOLENBQUM7OztZQS9FSixTQUFTLFNBQUM7Z0JBQ1AsUUFBUSxFQUFFLGVBQWU7Z0JBQ3pCLFFBQVEsRUFBRTs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztLQXNCVDtnQkFDRCxhQUFhLEVBQUUsaUJBQWlCLENBQUMsSUFBSTtnQkFDckMsU0FBUyxFQUFFLENBQUMsZUFBZSxFQUFFLFlBQVksQ0FBQztnQkFDMUMsSUFBSSxFQUFFLEVBQUUsT0FBTyxFQUFFLGdCQUFnQixFQUFFO2FBQ3RDOzs7WUFyQ0csZ0JBQWdCO1lBS1gsZUFBZTs7OytCQXFDbkIsS0FBSyxTQUFDLFFBQVE7a0JBQ2QsS0FBSyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7XHJcbiAgICBDb21wb25lbnQsXHJcbiAgICBJbnB1dCxcclxuICAgIFZpZXdFbmNhcHN1bGF0aW9uLFxyXG4gICAgT25Jbml0LFxyXG4gICAgT25DaGFuZ2VzLFxyXG4gICAgQWZ0ZXJWaWV3SW5pdCxcclxuICAgIFZpZXdDb250YWluZXJSZWYsXHJcbiAgICBTaW1wbGVDaGFuZ2VzLFxyXG59IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xyXG5pbXBvcnQgeyB0aW1lciwgU3Vic2NyaXB0aW9uLCBmcm9tRXZlbnQgfSBmcm9tICdyeGpzJztcclxuaW1wb3J0IHsgZGVib3VuY2VUaW1lIH0gZnJvbSAncnhqcy9vcGVyYXRvcnMnO1xyXG5pbXBvcnQgeyBLZEJyZWFkY3J1bWJTdmMgfSBmcm9tICcuL2tkLWFuZ3VsYXItYnJlYWRjcnVtYi1zdmMnO1xyXG5pbXBvcnQgeyBLZERvbUVsZW1TdmMgfSBmcm9tICcuLi9rZC1jb21tb24vaW5kZXgnO1xyXG5pbXBvcnQgeyBJQnJlYWRjcnVtYiwgSUJyZWFkY3J1bWJJbnRlcm5hbCwgSUJyZWFkY3J1bWJDb25maWcgfSBmcm9tICcuL2tkLWFuZ3VsYXItYnJlYWRjcnVtYi1pbnRlcmZhY2UnO1xyXG5cclxuQENvbXBvbmVudCh7XHJcbiAgICBzZWxlY3RvcjogJ2tkLWJyZWFkY3J1bWInLFxyXG4gICAgdGVtcGxhdGU6IGBcclxuICAgICAgICA8dWwgY2xhc3M9XCJicmVhZGNydW1iIHBhbmVsLWJyZWFkY3J1bWJcIj5cclxuICAgICAgICAgICAgPG5nLXRlbXBsYXRlIG5nRm9yIGxldC1jcnVtYiBbbmdGb3JPZl09XCJicmVhZGNydW1iUmVzdWx0XCI+XHJcbiAgICAgICAgICAgICAgICA8bGkgKm5nSWY9XCJjcnVtYi50b0VsbGlwc2lzXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPGkgY2xhc3M9XCJmYSBrZC1lbGxpcHNpcyBlbGxpcHNpcyBmYS1yb3RhdGUtOTBcIj48L2k+XHJcbiAgICAgICAgICAgICAgICA8L2xpPlxyXG4gICAgICAgICAgICAgICAgPGxpICpuZ0lmPVwiIWNydW1iLnRvRWxsaXBzaXNcIiBbY2xhc3MubGlzdC1oaWRlXT1cIiFjcnVtYi50b1JlbmRlclwiID5cclxuICAgICAgICAgICAgICAgICAgICA8YSAgKm5nSWY9XCJjcnVtYi5wYXRoICYmIGNydW1iLnBhdGggIT09ICcnXCIgW3JvdXRlckxpbmtdPVwiY3J1bWIucGF0aFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8aSAqbmdJZj1cImNydW1iLmljb24gJiYgY3J1bWIuaWNvbiAhPScnXCIgY2xhc3M9XCJ7e2NydW1iLmljb259fVwiPjwvaT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gKm5nSWY9XCJjcnVtYi5uYW1lICYmIGNydW1iLm5hbWUgIT09ICcnXCI+e3tjcnVtYi5uYW1lfX08L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9hPlxyXG4gICAgICAgICAgICAgICAgICAgIDxhICpuZ0lmPVwiY3J1bWIudXJsICYmIGNydW1iLnVybCAhPT0gJydcIiBbaHJlZl09XCJjcnVtYi51cmxcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGkgKm5nSWY9XCJjcnVtYi5pY29uICYmIGNydW1iLmljb24gIT0nJ1wiIGNsYXNzPVwie3tjcnVtYi5pY29ufX1cIj48L2k+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuICpuZ0lmPVwiY3J1bWIubmFtZSAmJiBjcnVtYi5uYW1lICE9PSAnJ1wiPnt7Y3J1bWIubmFtZX19PC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvYT5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2ICpuZ0lmPVwiKCFjcnVtYi5wYXRoIHx8IGNydW1iLnBhdGg9PScnKSAmJiAoY3J1bWIudXJsPT0nJyB8fCAhY3J1bWIudXJsKVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8aSAqbmdJZj1cImNydW1iLmljb24gJiYgY3J1bWIuaWNvbiAhPScnXCIgY2xhc3M9XCJ7e2NydW1iLmljb259fVwiPjwvaT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gKm5nSWY9XCJjcnVtYi5uYW1lICYmIGNydW1iLm5hbWUgIT09ICcnXCI+e3tjcnVtYi5uYW1lfX08L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8L2xpPlxyXG4gICAgICAgICAgICA8L25nLXRlbXBsYXRlPlxyXG4gICAgICAgIDwvdWw+XHJcbiAgICBgLFxyXG4gICAgZW5jYXBzdWxhdGlvbjogVmlld0VuY2Fwc3VsYXRpb24uTm9uZSxcclxuICAgIHByb3ZpZGVyczogW0tkQnJlYWRjcnVtYlN2YywgS2REb21FbGVtU3ZjXSxcclxuICAgIGhvc3Q6IHsgJ2NsYXNzJzogJ2tkeC1icmVhZGNydW1iJyB9XHJcbn0pXHJcblxyXG5leHBvcnQgY2xhc3MgS2RCcmVhZGNydW1iIGltcGxlbWVudHMgT25Jbml0LCBPbkNoYW5nZXMsIEFmdGVyVmlld0luaXQge1xyXG4gICAgcHVibGljIGJyZWFkY3J1bWJSZXN1bHQ6IEFycmF5PElCcmVhZGNydW1iSW50ZXJuYWw+ID0gW107XHJcbiAgICBwcml2YXRlIHJlc2l6ZVN1YjogU3Vic2NyaXB0aW9uO1xyXG4gICAgQElucHV0KCdjb25maWcnKSBicmVhZGNydW1iQ29uZmlnOiBJQnJlYWRjcnVtYkNvbmZpZztcclxuICAgIEBJbnB1dCgpIGFwaTogYW55O1xyXG5cclxuICAgIGNvbnN0cnVjdG9yKFxyXG4gICAgICAgIHByaXZhdGUgX3ZjcjogVmlld0NvbnRhaW5lclJlZixcclxuICAgICAgICBwcml2YXRlIF9icmVhZGNydW1iU3ZjOiBLZEJyZWFkY3J1bWJTdmNcclxuICAgICkgeyB9XHJcblxyXG4gICAgbmdPbkluaXQoKTogdm9pZCB7XHJcbiAgICAgICAgdGhpcy5yZXNpemVTdWIgPSBmcm9tRXZlbnQod2luZG93LCAncmVzaXplJylcclxuICAgICAgICAgICAgLnBpcGUoXHJcbiAgICAgICAgICAgICAgICBkZWJvdW5jZVRpbWUoNTAwKVxyXG4gICAgICAgICAgICApXHJcbiAgICAgICAgICAgIC5zdWJzY3JpYmUoZSA9PiB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLmJyZWFkY3J1bWJSZXN1bHQgPSB0aGlzLl9icmVhZGNydW1iU3ZjLnJlbmRlckJyZWFkY3J1bWJWaWV3KHRoaXMuX3ZjciwgdGhpcy5icmVhZGNydW1iQ29uZmlnKTtcclxuICAgICAgICAgICAgfSk7XHJcblxyXG4gICAgICAgIHRoaXMuX2luaXRBcGkoKTtcclxuICAgIH1cclxuXHJcbiAgICBuZ09uQ2hhbmdlcyhfc2ltcGxlQ2hhbmdlczogU2ltcGxlQ2hhbmdlcyk6IHZvaWQge1xyXG4gICAgICAgIGlmIChfc2ltcGxlQ2hhbmdlcy5oYXNPd25Qcm9wZXJ0eSgnYnJlYWRjcnVtYkNvbmZpZycpKSB7XHJcbiAgICAgICAgICAgIHRpbWVyKCkuc3Vic2NyaWJlKCgpOiB2b2lkID0+IHtcclxuICAgICAgICAgICAgICAgIHRoaXMuYnJlYWRjcnVtYlJlc3VsdCA9IHRoaXMuX2JyZWFkY3J1bWJTdmMucmVuZGVyQnJlYWRjcnVtYlZpZXcodGhpcy5fdmNyLCB0aGlzLmJyZWFkY3J1bWJDb25maWcpO1xyXG4gICAgICAgICAgICB9KTtcclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgbmdBZnRlclZpZXdJbml0KCk6IHZvaWQgeyB9XHJcblxyXG4gICAgcHJpdmF0ZSBfaW5pdEFwaSgpOiB2b2lkIHtcclxuICAgICAgICBpZiAoIXRoaXMuYXBpKSByZXR1cm47XHJcblxyXG4gICAgICAgIHRoaXMuYXBpLmFkZEJyZWFkY3J1bWIgPSAoX2l0ZW06IElCcmVhZGNydW1iKSA9PiB7XHJcbiAgICAgICAgICAgIHRoaXMuYnJlYWRjcnVtYkNvbmZpZy5saXN0LnB1c2goX2l0ZW0pO1xyXG4gICAgICAgICAgICB0aGlzLmJyZWFkY3J1bWJSZXN1bHQgPSB0aGlzLl9icmVhZGNydW1iU3ZjLnJlbmRlckJyZWFkY3J1bWJWaWV3KHRoaXMuX3ZjciwgdGhpcy5icmVhZGNydW1iQ29uZmlnKTtcclxuICAgICAgICB9O1xyXG5cclxuICAgICAgICB0aGlzLmFwaS51cGRhdGVCcmVhZGNydW1iID0gKF9wb3M6IG51bWJlciwgX2l0ZW06IElCcmVhZGNydW1iKSA9PiB7XHJcbiAgICAgICAgICAgIHRoaXMuYnJlYWRjcnVtYkNvbmZpZy5saXN0W19wb3MgLSAxXSA9IF9pdGVtO1xyXG4gICAgICAgICAgICB0aGlzLmJyZWFkY3J1bWJSZXN1bHQgPSB0aGlzLl9icmVhZGNydW1iU3ZjLnJlbmRlckJyZWFkY3J1bWJWaWV3KHRoaXMuX3ZjciwgdGhpcy5icmVhZGNydW1iQ29uZmlnKTtcclxuICAgICAgICB9O1xyXG5cclxuICAgICAgICB0aGlzLmFwaS5nZXRCcmVhZGNydW1icyA9ICgpOiBJQnJlYWRjcnVtYkNvbmZpZyA9PiB7XHJcbiAgICAgICAgICAgIHJldHVybiB0aGlzLmJyZWFkY3J1bWJDb25maWc7XHJcbiAgICAgICAgfTtcclxuICAgIH1cclxufVxyXG4iXX0=