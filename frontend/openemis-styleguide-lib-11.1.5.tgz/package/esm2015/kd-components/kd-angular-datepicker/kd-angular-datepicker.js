import { Component, ViewEncapsulation, Input, Output, EventEmitter } from '@angular/core';
export class KdDatepicker {
    constructor() {
        this._defaultConfig = {
            firstDayOfWeek: 7
        };
        this._emitVal = {};
        this.dateConfig = new EventEmitter();
    }
    ngOnInit() {
        this._updatedConfig = Object.assign(this._defaultConfig, this.config);
        this._assignSetting(this.inputVal, 'value');
        this._assignSetting(this.minDate, 'minDate');
        this._assignSetting(this.maxDate, 'maxDate');
        this._popupPlacement = document.dir === 'rtl' ? 'bottom-left' : 'bottom-right';
    }
    ngOnChanges(_simpleChanges) {
        if (_simpleChanges.hasOwnProperty('inputVal') && !_simpleChanges['inputVal'].firstChange) {
            this._assignSetting(_simpleChanges['inputVal'].currentValue, 'value');
        }
        if (_simpleChanges.hasOwnProperty('minDate') && !_simpleChanges['minDate'].firstChange) {
            this._assignSetting(_simpleChanges['minDate'].currentValue, 'minDate');
        }
        if (_simpleChanges.hasOwnProperty('maxDate') && !_simpleChanges['maxDate'].firstChange) {
            this._assignSetting(_simpleChanges['maxDate'].currentValue, 'maxDate');
        }
    }
    emitValue() {
        let newModel = Object.assign({}, this._model);
        this._emitVal = {};
        this._emitVal.text = this._formatDate(newModel);
        this._emitVal.obj = newModel;
        this.dateConfig.emit(this._emitVal);
    }
    _assignSetting(_value, _model) {
        let updateValue = this._getNgbDateStruct(_value);
        if (typeof updateValue !== 'undefined' && _model === 'value') {
            this._model = Object.assign({}, updateValue);
            this.emitValue();
        }
        else if (_model === 'minDate') {
            this._minDate = Object.assign({}, updateValue);
        }
        else if (_model === 'maxDate') {
            this._maxDate = Object.assign({}, updateValue);
        }
    }
    _getNgbDateStruct(_value) {
        if (typeof _value !== 'undefined' && _value !== '' && _value !== null) {
            if (_value instanceof Object && _value.hasOwnProperty('month') && _value.hasOwnProperty('year') && _value.hasOwnProperty('day'))
                return _value;
            else if (typeof _value === 'string')
                return this._parseDate(_value);
        }
        return undefined;
    }
    // to be removed and use native api
    _parseDate(_textDate) {
        let splitDate = _textDate.split('-');
        let updateDate = {
            year: parseInt(splitDate[0]),
            month: parseInt(splitDate[1]),
            day: parseInt(splitDate[2])
        };
        return updateDate;
    }
    _formatDate(_objDate) {
        let date = 'undefined-undefined-undefined';
        if (_objDate !== null)
            date = _objDate.year + '-' + _objDate.month + '-' + _objDate.day;
        return date;
    }
}
KdDatepicker.decorators = [
    { type: Component, args: [{
                selector: 'kd-datepicker',
                template: "<div class=\"kdx-datepicker-wrapper\">\r\n\t<input class=\"kdx-datepicker-input\" \r\n\t\t\tplaceholder=\"yyyy-mm-dd\" \r\n\t\t\tngbDatepicker #d=\"ngbDatepicker\" \r\n\t\t\tnavigation= \"select\"\r\n\t\t\tcontainer=\"body\"\r\n\t\t\tplacement=\"{{_popupPlacement}}\"\r\n\t\t\t[minDate]=\"_minDate\"\r\n\t\t\t[maxDate]=\"_maxDate\"\r\n\t\t\t[firstDayOfWeek]=\"_updatedConfig.firstDayOfWeek\"\r\n\t\t\t[(ngModel)]=\"_model\" \r\n\t\t\t(ngModelChange)=\"emitValue()\"/>\r\n\t<ng-content></ng-content>\r\n\t<button class=\"btn btn-icon btn-input\" (click)=\"d.toggle()\" type=\"button\">\r\n\t\t<i class=\"fa fa-calendar fa-lg\" aria-hidden=\"true\"></i>\r\n\t</button>\r\n</div>",
                encapsulation: ViewEncapsulation.None,
                host: { 'class': 'kdx kdx-datepicker' }
            },] }
];
KdDatepicker.propDecorators = {
    inputVal: [{ type: Input }],
    config: [{ type: Input }],
    minDate: [{ type: Input }],
    maxDate: [{ type: Input }],
    dateConfig: [{ type: Output }]
};
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoia2QtYW5ndWxhci1kYXRlcGlja2VyLmpzIiwic291cmNlUm9vdCI6IkM6L3hhbXBwL2h0ZG9jcy9TdHlsZWd1aWRlL2lvc3RnLW9wZW5lbWlzLXN0eWxlZ3VpZGUvcHJvamVjdHMvb3BlbmVtaXMtc3R5bGVndWlkZS1saWIvc3JjLyIsInNvdXJjZXMiOlsia2QtY29tcG9uZW50cy9rZC1hbmd1bGFyLWRhdGVwaWNrZXIva2QtYW5ndWxhci1kYXRlcGlja2VyLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBLE9BQU8sRUFDSCxTQUFTLEVBQ1QsaUJBQWlCLEVBQ2pCLEtBQUssRUFJTCxNQUFNLEVBQ04sWUFBWSxFQUNmLE1BQU0sZUFBZSxDQUFDO0FBVXZCLE1BQU0sT0FBTyxZQUFZO0lBUHpCO1FBY1ksbUJBQWMsR0FBUTtZQUMxQixjQUFjLEVBQUUsQ0FBQztTQUNwQixDQUFDO1FBQ00sYUFBUSxHQUFRLEVBQUUsQ0FBQztRQU1qQixlQUFVLEdBQXNCLElBQUksWUFBWSxFQUFFLENBQUM7SUFxRWpFLENBQUM7SUFuRUcsUUFBUTtRQUNKLElBQUksQ0FBQyxjQUFjLEdBQUcsTUFBTSxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsY0FBYyxFQUFFLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQztRQUN0RSxJQUFJLENBQUMsY0FBYyxDQUFDLElBQUksQ0FBQyxRQUFRLEVBQUUsT0FBTyxDQUFDLENBQUM7UUFDNUMsSUFBSSxDQUFDLGNBQWMsQ0FBQyxJQUFJLENBQUMsT0FBTyxFQUFFLFNBQVMsQ0FBQyxDQUFDO1FBQzdDLElBQUksQ0FBQyxjQUFjLENBQUMsSUFBSSxDQUFDLE9BQU8sRUFBRSxTQUFTLENBQUMsQ0FBQztRQUU3QyxJQUFJLENBQUMsZUFBZSxHQUFHLFFBQVEsQ0FBQyxHQUFHLEtBQUssS0FBSyxDQUFDLENBQUMsQ0FBQyxhQUFhLENBQUMsQ0FBQyxDQUFDLGNBQWMsQ0FBQztJQUNuRixDQUFDO0lBRUQsV0FBVyxDQUFDLGNBQTZCO1FBQ3JDLElBQUksY0FBYyxDQUFDLGNBQWMsQ0FBQyxVQUFVLENBQUMsSUFBSSxDQUFDLGNBQWMsQ0FBQyxVQUFVLENBQUMsQ0FBQyxXQUFXLEVBQUU7WUFDdEYsSUFBSSxDQUFDLGNBQWMsQ0FBQyxjQUFjLENBQUMsVUFBVSxDQUFDLENBQUMsWUFBWSxFQUFFLE9BQU8sQ0FBQyxDQUFDO1NBQ3pFO1FBQ0QsSUFBSSxjQUFjLENBQUMsY0FBYyxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsY0FBYyxDQUFDLFNBQVMsQ0FBQyxDQUFDLFdBQVcsRUFBRTtZQUNwRixJQUFJLENBQUMsY0FBYyxDQUFDLGNBQWMsQ0FBQyxTQUFTLENBQUMsQ0FBQyxZQUFZLEVBQUUsU0FBUyxDQUFDLENBQUM7U0FDMUU7UUFDRCxJQUFJLGNBQWMsQ0FBQyxjQUFjLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQyxjQUFjLENBQUMsU0FBUyxDQUFDLENBQUMsV0FBVyxFQUFFO1lBQ3BGLElBQUksQ0FBQyxjQUFjLENBQUMsY0FBYyxDQUFDLFNBQVMsQ0FBQyxDQUFDLFlBQVksRUFBRSxTQUFTLENBQUMsQ0FBQztTQUMxRTtJQUNMLENBQUM7SUFFTSxTQUFTO1FBQ1osSUFBSSxRQUFRLEdBQVEsTUFBTSxDQUFDLE1BQU0sQ0FBQyxFQUFFLEVBQUUsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDO1FBQ25ELElBQUksQ0FBQyxRQUFRLEdBQUcsRUFBRSxDQUFDO1FBQ25CLElBQUksQ0FBQyxRQUFRLENBQUMsSUFBSSxHQUFHLElBQUksQ0FBQyxXQUFXLENBQUMsUUFBUSxDQUFDLENBQUM7UUFDaEQsSUFBSSxDQUFDLFFBQVEsQ0FBQyxHQUFHLEdBQUcsUUFBUSxDQUFDO1FBQzdCLElBQUksQ0FBQyxVQUFVLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsQ0FBQztJQUN4QyxDQUFDO0lBRU8sY0FBYyxDQUFDLE1BQVcsRUFBRSxNQUFjO1FBQzlDLElBQUksV0FBVyxHQUFRLElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxNQUFNLENBQUMsQ0FBQztRQUN0RCxJQUFJLE9BQU8sV0FBVyxLQUFLLFdBQVcsSUFBSSxNQUFNLEtBQUssT0FBTyxFQUFFO1lBQzFELElBQUksQ0FBQyxNQUFNLEdBQUcsTUFBTSxDQUFDLE1BQU0sQ0FBQyxFQUFFLEVBQUUsV0FBVyxDQUFDLENBQUM7WUFDN0MsSUFBSSxDQUFDLFNBQVMsRUFBRSxDQUFDO1NBQ3BCO2FBQ0ksSUFBSSxNQUFNLEtBQUssU0FBUyxFQUFFO1lBQzNCLElBQUksQ0FBQyxRQUFRLEdBQUcsTUFBTSxDQUFDLE1BQU0sQ0FBQyxFQUFFLEVBQUUsV0FBVyxDQUFDLENBQUM7U0FDbEQ7YUFDSSxJQUFJLE1BQU0sS0FBSyxTQUFTLEVBQUU7WUFDM0IsSUFBSSxDQUFDLFFBQVEsR0FBRyxNQUFNLENBQUMsTUFBTSxDQUFDLEVBQUUsRUFBRSxXQUFXLENBQUMsQ0FBQztTQUNsRDtJQUNMLENBQUM7SUFFTyxpQkFBaUIsQ0FBQyxNQUFXO1FBQ2pDLElBQUksT0FBTyxNQUFNLEtBQUssV0FBVyxJQUFJLE1BQU0sS0FBSyxFQUFFLElBQUksTUFBTSxLQUFLLElBQUksRUFBRTtZQUNuRSxJQUFJLE1BQU0sWUFBWSxNQUFNLElBQUksTUFBTSxDQUFDLGNBQWMsQ0FBQyxPQUFPLENBQUMsSUFBSSxNQUFNLENBQUMsY0FBYyxDQUFDLE1BQU0sQ0FBQyxJQUFJLE1BQU0sQ0FBQyxjQUFjLENBQUMsS0FBSyxDQUFDO2dCQUFFLE9BQU8sTUFBTSxDQUFDO2lCQUMxSSxJQUFJLE9BQU8sTUFBTSxLQUFLLFFBQVE7Z0JBQUUsT0FBTyxJQUFJLENBQUMsVUFBVSxDQUFDLE1BQU0sQ0FBQyxDQUFDO1NBQ3ZFO1FBQ0QsT0FBTyxTQUFTLENBQUM7SUFDckIsQ0FBQztJQUVELG1DQUFtQztJQUMzQixVQUFVLENBQUMsU0FBaUI7UUFDaEMsSUFBSSxTQUFTLEdBQWUsU0FBUyxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FBQztRQUNqRCxJQUFJLFVBQVUsR0FBUTtZQUNsQixJQUFJLEVBQUUsUUFBUSxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQztZQUM1QixLQUFLLEVBQUUsUUFBUSxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQztZQUM3QixHQUFHLEVBQUUsUUFBUSxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQztTQUM5QixDQUFDO1FBQ0YsT0FBTyxVQUFVLENBQUM7SUFDdEIsQ0FBQztJQUVPLFdBQVcsQ0FBQyxRQUFhO1FBQzdCLElBQUksSUFBSSxHQUFXLCtCQUErQixDQUFDO1FBQ25ELElBQUksUUFBUSxLQUFLLElBQUk7WUFBRSxJQUFJLEdBQUcsUUFBUSxDQUFDLElBQUksR0FBRyxHQUFHLEdBQUcsUUFBUSxDQUFDLEtBQUssR0FBRyxHQUFHLEdBQUcsUUFBUSxDQUFDLEdBQUcsQ0FBQztRQUN4RixPQUFPLElBQUksQ0FBQztJQUNoQixDQUFDOzs7WUEzRkosU0FBUyxTQUFDO2dCQUNQLFFBQVEsRUFBRSxlQUFlO2dCQUN6QixnckJBQTJDO2dCQUMzQyxhQUFhLEVBQUUsaUJBQWlCLENBQUMsSUFBSTtnQkFDckMsSUFBSSxFQUFHLEVBQUUsT0FBTyxFQUFHLG9CQUFvQixFQUFFO2FBQzVDOzs7dUJBY0ksS0FBSztxQkFDTCxLQUFLO3NCQUNMLEtBQUs7c0JBQ0wsS0FBSzt5QkFDTCxNQUFNIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHtcclxuICAgIENvbXBvbmVudCxcclxuICAgIFZpZXdFbmNhcHN1bGF0aW9uLFxyXG4gICAgSW5wdXQsXHJcbiAgICBPbkluaXQsXHJcbiAgICBPbkNoYW5nZXMsXHJcbiAgICBTaW1wbGVDaGFuZ2VzLFxyXG4gICAgT3V0cHV0LFxyXG4gICAgRXZlbnRFbWl0dGVyXHJcbn0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XHJcbmltcG9ydCB7IE5nYkRhdGVTdHJ1Y3QgfSBmcm9tICdAbmctYm9vdHN0cmFwL25nLWJvb3RzdHJhcCc7XHJcblxyXG5AQ29tcG9uZW50KHtcclxuICAgIHNlbGVjdG9yOiAna2QtZGF0ZXBpY2tlcicsXHJcbiAgICB0ZW1wbGF0ZVVybDogJy4va2QtYW5ndWxhci1kYXRlcGlja2VyLmh0bWwnLFxyXG4gICAgZW5jYXBzdWxhdGlvbjogVmlld0VuY2Fwc3VsYXRpb24uTm9uZSxcclxuICAgIGhvc3QgOiB7ICdjbGFzcycgOiAna2R4IGtkeC1kYXRlcGlja2VyJyB9XHJcbn0pXHJcblxyXG5leHBvcnQgY2xhc3MgS2REYXRlcGlja2VyIGltcGxlbWVudHMgT25Jbml0LCBPbkNoYW5nZXMge1xyXG4gICAgcHVibGljIF91cGRhdGVkQ29uZmlnOiBhbnk7XHJcbiAgICBwdWJsaWMgX21pbkRhdGU6IE5nYkRhdGVTdHJ1Y3Q7XHJcbiAgICBwdWJsaWMgX21heERhdGU6IE5nYkRhdGVTdHJ1Y3Q7XHJcbiAgICBwdWJsaWMgX21vZGVsOiBhbnk7XHJcbiAgICBwdWJsaWMgX3BvcHVwUGxhY2VtZW50OiBzdHJpbmc7XHJcblxyXG4gICAgcHJpdmF0ZSBfZGVmYXVsdENvbmZpZzogYW55ID0ge1xyXG4gICAgICAgIGZpcnN0RGF5T2ZXZWVrOiA3XHJcbiAgICB9O1xyXG4gICAgcHJpdmF0ZSBfZW1pdFZhbDogYW55ID0ge307XHJcblxyXG4gICAgQElucHV0KCkgaW5wdXRWYWw6IGFueTtcclxuICAgIEBJbnB1dCgpIGNvbmZpZzogYW55O1xyXG4gICAgQElucHV0KCkgbWluRGF0ZTogYW55O1xyXG4gICAgQElucHV0KCkgbWF4RGF0ZTogYW55O1xyXG4gICAgQE91dHB1dCgpIGRhdGVDb25maWc6IEV2ZW50RW1pdHRlcjxhbnk+ID0gbmV3IEV2ZW50RW1pdHRlcigpO1xyXG5cclxuICAgIG5nT25Jbml0KCk6IHZvaWQge1xyXG4gICAgICAgIHRoaXMuX3VwZGF0ZWRDb25maWcgPSBPYmplY3QuYXNzaWduKHRoaXMuX2RlZmF1bHRDb25maWcsIHRoaXMuY29uZmlnKTtcclxuICAgICAgICB0aGlzLl9hc3NpZ25TZXR0aW5nKHRoaXMuaW5wdXRWYWwsICd2YWx1ZScpO1xyXG4gICAgICAgIHRoaXMuX2Fzc2lnblNldHRpbmcodGhpcy5taW5EYXRlLCAnbWluRGF0ZScpO1xyXG4gICAgICAgIHRoaXMuX2Fzc2lnblNldHRpbmcodGhpcy5tYXhEYXRlLCAnbWF4RGF0ZScpO1xyXG5cclxuICAgICAgICB0aGlzLl9wb3B1cFBsYWNlbWVudCA9IGRvY3VtZW50LmRpciA9PT0gJ3J0bCcgPyAnYm90dG9tLWxlZnQnIDogJ2JvdHRvbS1yaWdodCc7XHJcbiAgICB9XHJcblxyXG4gICAgbmdPbkNoYW5nZXMoX3NpbXBsZUNoYW5nZXM6IFNpbXBsZUNoYW5nZXMpIHtcclxuICAgICAgICBpZiAoX3NpbXBsZUNoYW5nZXMuaGFzT3duUHJvcGVydHkoJ2lucHV0VmFsJykgJiYgIV9zaW1wbGVDaGFuZ2VzWydpbnB1dFZhbCddLmZpcnN0Q2hhbmdlKSB7XHJcbiAgICAgICAgICAgIHRoaXMuX2Fzc2lnblNldHRpbmcoX3NpbXBsZUNoYW5nZXNbJ2lucHV0VmFsJ10uY3VycmVudFZhbHVlLCAndmFsdWUnKTtcclxuICAgICAgICB9XHJcbiAgICAgICAgaWYgKF9zaW1wbGVDaGFuZ2VzLmhhc093blByb3BlcnR5KCdtaW5EYXRlJykgJiYgIV9zaW1wbGVDaGFuZ2VzWydtaW5EYXRlJ10uZmlyc3RDaGFuZ2UpIHtcclxuICAgICAgICAgICAgdGhpcy5fYXNzaWduU2V0dGluZyhfc2ltcGxlQ2hhbmdlc1snbWluRGF0ZSddLmN1cnJlbnRWYWx1ZSwgJ21pbkRhdGUnKTtcclxuICAgICAgICB9XHJcbiAgICAgICAgaWYgKF9zaW1wbGVDaGFuZ2VzLmhhc093blByb3BlcnR5KCdtYXhEYXRlJykgJiYgIV9zaW1wbGVDaGFuZ2VzWydtYXhEYXRlJ10uZmlyc3RDaGFuZ2UpIHtcclxuICAgICAgICAgICAgdGhpcy5fYXNzaWduU2V0dGluZyhfc2ltcGxlQ2hhbmdlc1snbWF4RGF0ZSddLmN1cnJlbnRWYWx1ZSwgJ21heERhdGUnKTtcclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgcHVibGljIGVtaXRWYWx1ZSgpOiB2b2lkIHtcclxuICAgICAgICBsZXQgbmV3TW9kZWw6IGFueSA9IE9iamVjdC5hc3NpZ24oe30sIHRoaXMuX21vZGVsKTtcclxuICAgICAgICB0aGlzLl9lbWl0VmFsID0ge307XHJcbiAgICAgICAgdGhpcy5fZW1pdFZhbC50ZXh0ID0gdGhpcy5fZm9ybWF0RGF0ZShuZXdNb2RlbCk7XHJcbiAgICAgICAgdGhpcy5fZW1pdFZhbC5vYmogPSBuZXdNb2RlbDtcclxuICAgICAgICB0aGlzLmRhdGVDb25maWcuZW1pdCh0aGlzLl9lbWl0VmFsKTtcclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF9hc3NpZ25TZXR0aW5nKF92YWx1ZTogYW55LCBfbW9kZWw6IHN0cmluZyk6IHZvaWQge1xyXG4gICAgICAgIGxldCB1cGRhdGVWYWx1ZTogYW55ID0gdGhpcy5fZ2V0TmdiRGF0ZVN0cnVjdChfdmFsdWUpO1xyXG4gICAgICAgIGlmICh0eXBlb2YgdXBkYXRlVmFsdWUgIT09ICd1bmRlZmluZWQnICYmIF9tb2RlbCA9PT0gJ3ZhbHVlJykge1xyXG4gICAgICAgICAgICB0aGlzLl9tb2RlbCA9IE9iamVjdC5hc3NpZ24oe30sIHVwZGF0ZVZhbHVlKTtcclxuICAgICAgICAgICAgdGhpcy5lbWl0VmFsdWUoKTtcclxuICAgICAgICB9XHJcbiAgICAgICAgZWxzZSBpZiAoX21vZGVsID09PSAnbWluRGF0ZScpIHtcclxuICAgICAgICAgICAgdGhpcy5fbWluRGF0ZSA9IE9iamVjdC5hc3NpZ24oe30sIHVwZGF0ZVZhbHVlKTtcclxuICAgICAgICB9XHJcbiAgICAgICAgZWxzZSBpZiAoX21vZGVsID09PSAnbWF4RGF0ZScpIHtcclxuICAgICAgICAgICAgdGhpcy5fbWF4RGF0ZSA9IE9iamVjdC5hc3NpZ24oe30sIHVwZGF0ZVZhbHVlKTtcclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfZ2V0TmdiRGF0ZVN0cnVjdChfdmFsdWU6IGFueSk6IGFueSB7XHJcbiAgICAgICAgaWYgKHR5cGVvZiBfdmFsdWUgIT09ICd1bmRlZmluZWQnICYmIF92YWx1ZSAhPT0gJycgJiYgX3ZhbHVlICE9PSBudWxsKSB7XHJcbiAgICAgICAgICAgIGlmIChfdmFsdWUgaW5zdGFuY2VvZiBPYmplY3QgJiYgX3ZhbHVlLmhhc093blByb3BlcnR5KCdtb250aCcpICYmIF92YWx1ZS5oYXNPd25Qcm9wZXJ0eSgneWVhcicpICYmIF92YWx1ZS5oYXNPd25Qcm9wZXJ0eSgnZGF5JykpIHJldHVybiBfdmFsdWU7XHJcbiAgICAgICAgICAgIGVsc2UgaWYgKHR5cGVvZiBfdmFsdWUgPT09ICdzdHJpbmcnKSByZXR1cm4gdGhpcy5fcGFyc2VEYXRlKF92YWx1ZSk7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIHJldHVybiB1bmRlZmluZWQ7XHJcbiAgICB9XHJcblxyXG4gICAgLy8gdG8gYmUgcmVtb3ZlZCBhbmQgdXNlIG5hdGl2ZSBhcGlcclxuICAgIHByaXZhdGUgX3BhcnNlRGF0ZShfdGV4dERhdGU6IHN0cmluZyk6IGFueSB7XHJcbiAgICAgICAgbGV0IHNwbGl0RGF0ZTogQXJyYXk8YW55PiA9IF90ZXh0RGF0ZS5zcGxpdCgnLScpO1xyXG4gICAgICAgIGxldCB1cGRhdGVEYXRlOiBhbnkgPSB7XHJcbiAgICAgICAgICAgIHllYXI6IHBhcnNlSW50KHNwbGl0RGF0ZVswXSksXHJcbiAgICAgICAgICAgIG1vbnRoOiBwYXJzZUludChzcGxpdERhdGVbMV0pLFxyXG4gICAgICAgICAgICBkYXk6IHBhcnNlSW50KHNwbGl0RGF0ZVsyXSlcclxuICAgICAgICB9O1xyXG4gICAgICAgIHJldHVybiB1cGRhdGVEYXRlO1xyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX2Zvcm1hdERhdGUoX29iakRhdGU6IGFueSk6IHN0cmluZyB7XHJcbiAgICAgICAgbGV0IGRhdGU6IHN0cmluZyA9ICd1bmRlZmluZWQtdW5kZWZpbmVkLXVuZGVmaW5lZCc7XHJcbiAgICAgICAgaWYgKF9vYmpEYXRlICE9PSBudWxsKSBkYXRlID0gX29iakRhdGUueWVhciArICctJyArIF9vYmpEYXRlLm1vbnRoICsgJy0nICsgX29iakRhdGUuZGF5O1xyXG4gICAgICAgIHJldHVybiBkYXRlO1xyXG4gICAgfVxyXG59XHJcbiJdfQ==