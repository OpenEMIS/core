import { Component, ViewEncapsulation, ViewChild, Input, ElementRef, Renderer2, HostListener, } from '@angular/core';
import { UIChart } from 'primeng/chart';
import { KdMiniDashboardSvc } from './kd-angular-mini-dashboard-svc';
import { KdSplitterEvent } from '../kd-angular-splitter/index';
export class KdMiniDashboardChart {
    constructor(_kdMiniDashboardSvc, _elementRef, _renderer, _kdSplitterEvent) {
        this._kdMiniDashboardSvc = _kdMiniDashboardSvc;
        this._elementRef = _elementRef;
        this._renderer = _renderer;
        this.threeItemLegend = false;
        this.placement = 'bottom-left';
        this._isWidthChanged = { legend: false, canvas: false };
        this._isFirstLoad = true;
        this._pChartsFunction = _kdMiniDashboardSvc.pcharts(_elementRef, _renderer);
        _kdSplitterEvent.onDrag().subscribe(_type => {
            this._pChartsFunction.setTooltipPlacementFlag(true);
        });
        _kdSplitterEvent.onToggleMenu().subscribe(_type => {
            this._pChartsFunction.setTooltipPlacementFlag(true);
        });
    }
    onResize(event) {
        this._pChartsFunction.setTooltipPlacementFlag(true);
        this._pChartsFunction.processTooltipToCanvasSize(this._canvas, this.chart);
        if (this.itemLength === 3) {
            this._resizeLegend();
            this._resizeCanvas();
        }
    }
    ngOnInit() {
        this._isFirstLoad = false;
        this._tooltipElement = this.tooltip._elementRef.nativeElement;
        this._chartLegendElement = this.chartLegend.nativeElement;
    }
    ngOnChanges(_simpleChanges) {
        if (_simpleChanges.hasOwnProperty('itemLength') && _simpleChanges.itemLength.currentValue === 3) {
            this._resizeLegend();
        }
        if (!this._isFirstLoad && this.itemLength === 3)
            this._resizeCanvas();
        if (_simpleChanges.hasOwnProperty('direction') && this.direction === 'right')
            this.placement = 'bottom-right';
    }
    ngAfterViewInit() {
        this._canvas = this.chart.getCanvas();
        this._pChartElement = this._elementRef.nativeElement.querySelector('.kdx-mini-dashboard .kdx-mini-dashboard-chart p-chart');
        if (this.itemLength === 3)
            this._resizeCanvas();
        this._setLegend();
        this._pChartsFunction.processTooltipToCanvasSize(this._canvas, this.chart);
    }
    ngOnDestroy() {
        this._kdMiniDashboardSvc.removeChildren(this._chartLegendElement);
    }
    _setLegend() {
        if (!this.isLegendDisplayed)
            return;
        this._chartLegendElement.innerHTML = this.chart.chart.generateLegend() || '';
        this._setLegendLabelElement();
        this._pChartsFunction.attachLegendListener(this._legendLabelElement, { uiChart: this.chart, legendElement: this._chartLegendElement }, { method: this.tooltip, element: this._tooltipElement }, this.direction);
    }
    _setLegendLabelElement() {
        this._legendLabelElement = this._elementRef.nativeElement.querySelectorAll('.kdx-mini-dashboard .kdx-elem-item .chart-legend ul li .chart-legend-label');
    }
    _resizeLegend() {
        if (480 < window.innerWidth && window.innerWidth < 650) {
            if (this._isWidthChanged.legend === false) {
                this.threeItemLegend = true;
                this._isWidthChanged.legend = true;
            }
        }
        else {
            if (this._isWidthChanged.legend === true) {
                this.threeItemLegend = false;
                this._isWidthChanged.legend = false;
            }
        }
    }
    _resizeCanvas() {
        if (480 < window.innerWidth && window.innerWidth < 650) {
            if (this._isWidthChanged.canvas === false) {
                this._pChartsFunction.setCanvasStyle('80', this._canvas);
                this._isWidthChanged.canvas = true;
                this._renderer.setStyle(this._pChartElement, 'width', '80px');
                this._renderer.setStyle(this._pChartElement, 'height', '80px');
            }
        }
        else if (window.innerWidth > 650 || window.innerWidth === 650) {
            if (this._isWidthChanged.canvas === true) {
                this._pChartsFunction.setCanvasStyle('100', this._canvas);
                this._isWidthChanged.canvas = false;
                this._renderer.setStyle(this._pChartElement, 'width', '100px');
                this._renderer.setStyle(this._pChartElement, 'height', '100px');
            }
        }
    }
}
KdMiniDashboardChart.decorators = [
    { type: Component, args: [{
                selector: 'kd-mini-dashboard-chart',
                template: `
        <div class="kdx-elem-item">
            <p-chart class="chart-main" type="doughnut" [data]="data" [options]="options" ></p-chart>
            <div class="chart-legend"
                 #chartLegend
                 [attr.kd-mini-dashboard-chart-index]="data.chartIndex"
                 [ngClass]="{'three-item-chart-legend' : threeItemLegend }">
            </div>
            <div class="kdx-mini-dashboard-tooltip" [placement]="placement" ngbTooltip="" triggers="manual" #t="ngbTooltip"></div>
        </div>`,
                encapsulation: ViewEncapsulation.None,
                providers: [KdMiniDashboardSvc],
                host: { class: 'kdx-mini-dashboard-chart' }
            },] }
];
KdMiniDashboardChart.ctorParameters = () => [
    { type: KdMiniDashboardSvc },
    { type: ElementRef },
    { type: Renderer2 },
    { type: KdSplitterEvent }
];
KdMiniDashboardChart.propDecorators = {
    data: [{ type: Input }],
    options: [{ type: Input }],
    isLegendDisplayed: [{ type: Input }],
    itemLength: [{ type: Input }],
    direction: [{ type: Input }],
    chart: [{ type: ViewChild, args: [UIChart, { static: true },] }],
    tooltip: [{ type: ViewChild, args: ['t', { static: true },] }],
    chartLegend: [{ type: ViewChild, args: ['chartLegend', { static: true },] }],
    onResize: [{ type: HostListener, args: ['window:resize', ['$event'],] }]
};
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoia2QtYW5ndWxhci1taW5pLWRhc2hib2FyZC1jaGFydC5qcyIsInNvdXJjZVJvb3QiOiJDOi94YW1wcC9odGRvY3MvU3R5bGVndWlkZS9pb3N0Zy1vcGVuZW1pcy1zdHlsZWd1aWRlL3Byb2plY3RzL29wZW5lbWlzLXN0eWxlZ3VpZGUtbGliL3NyYy8iLCJzb3VyY2VzIjpbImtkLWNvbXBvbmVudHMva2QtYW5ndWxhci1taW5pLWRhc2hib2FyZC9rZC1hbmd1bGFyLW1pbmktZGFzaGJvYXJkLWNoYXJ0LnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBLE9BQU8sRUFDSCxTQUFTLEVBQ1QsaUJBQWlCLEVBQ2pCLFNBQVMsRUFDVCxLQUFLLEVBTUwsVUFBVSxFQUNWLFNBQVMsRUFDVCxZQUFZLEdBQ2YsTUFBTSxlQUFlLENBQUM7QUFDdkIsT0FBTyxFQUFFLE9BQU8sRUFBRSxNQUFNLGVBQWUsQ0FBQztBQUV4QyxPQUFPLEVBQUUsa0JBQWtCLEVBQUUsTUFBTSxpQ0FBaUMsQ0FBQztBQUNyRSxPQUFPLEVBQUUsZUFBZSxFQUFFLE1BQU0sOEJBQThCLENBQUM7QUFtQi9ELE1BQU0sT0FBTyxvQkFBb0I7SUF1QjdCLFlBQ1ksbUJBQXVDLEVBQ3ZDLFdBQXVCLEVBQ3ZCLFNBQW9CLEVBQzVCLGdCQUFpQztRQUh6Qix3QkFBbUIsR0FBbkIsbUJBQW1CLENBQW9CO1FBQ3ZDLGdCQUFXLEdBQVgsV0FBVyxDQUFZO1FBQ3ZCLGNBQVMsR0FBVCxTQUFTLENBQVc7UUF6QnpCLG9CQUFlLEdBQVksS0FBSyxDQUFDO1FBQ2pDLGNBQVMsR0FBVyxhQUFhLENBQUM7UUFPakMsb0JBQWUsR0FBeUMsRUFBRSxNQUFNLEVBQUUsS0FBSyxFQUFFLE1BQU0sRUFBRSxLQUFLLEVBQUUsQ0FBQztRQUN6RixpQkFBWSxHQUFZLElBQUksQ0FBQztRQW1CakMsSUFBSSxDQUFDLGdCQUFnQixHQUFHLG1CQUFtQixDQUFDLE9BQU8sQ0FBQyxXQUFXLEVBQUUsU0FBUyxDQUFDLENBQUM7UUFDNUUsZ0JBQWdCLENBQUMsTUFBTSxFQUFFLENBQUMsU0FBUyxDQUFDLEtBQUssQ0FBQyxFQUFFO1lBQ3hDLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyx1QkFBdUIsQ0FBQyxJQUFJLENBQUMsQ0FBQztRQUN4RCxDQUFDLENBQUMsQ0FBQztRQUNILGdCQUFnQixDQUFDLFlBQVksRUFBRSxDQUFDLFNBQVMsQ0FBQyxLQUFLLENBQUMsRUFBRTtZQUM5QyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsdUJBQXVCLENBQUMsSUFBSSxDQUFDLENBQUM7UUFDeEQsQ0FBQyxDQUFDLENBQUM7SUFDUCxDQUFDO0lBR0QsUUFBUSxDQUFDLEtBQVU7UUFDZixJQUFJLENBQUMsZ0JBQWdCLENBQUMsdUJBQXVCLENBQUMsSUFBSSxDQUFDLENBQUM7UUFDcEQsSUFBSSxDQUFDLGdCQUFnQixDQUFDLDBCQUEwQixDQUFDLElBQUksQ0FBQyxPQUFPLEVBQUUsSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFDO1FBQzNFLElBQUksSUFBSSxDQUFDLFVBQVUsS0FBSyxDQUFDLEVBQUU7WUFDdkIsSUFBSSxDQUFDLGFBQWEsRUFBRSxDQUFDO1lBQ3JCLElBQUksQ0FBQyxhQUFhLEVBQUUsQ0FBQztTQUN4QjtJQUNMLENBQUM7SUFFRCxRQUFRO1FBQ0osSUFBSSxDQUFDLFlBQVksR0FBRyxLQUFLLENBQUM7UUFDMUIsSUFBSSxDQUFDLGVBQWUsR0FBRyxJQUFJLENBQUMsT0FBTyxDQUFDLFdBQVcsQ0FBQyxhQUFhLENBQUM7UUFDOUQsSUFBSSxDQUFDLG1CQUFtQixHQUFHLElBQUksQ0FBQyxXQUFXLENBQUMsYUFBYSxDQUFDO0lBQzlELENBQUM7SUFFRCxXQUFXLENBQUMsY0FBNkI7UUFDckMsSUFBSSxjQUFjLENBQUMsY0FBYyxDQUFDLFlBQVksQ0FBQyxJQUFJLGNBQWMsQ0FBQyxVQUFVLENBQUMsWUFBWSxLQUFLLENBQUMsRUFBRTtZQUM3RixJQUFJLENBQUMsYUFBYSxFQUFFLENBQUM7U0FDeEI7UUFDRCxJQUFJLENBQUMsSUFBSSxDQUFDLFlBQVksSUFBSSxJQUFJLENBQUMsVUFBVSxLQUFLLENBQUM7WUFBRSxJQUFJLENBQUMsYUFBYSxFQUFFLENBQUM7UUFDdEUsSUFBSSxjQUFjLENBQUMsY0FBYyxDQUFDLFdBQVcsQ0FBQyxJQUFJLElBQUksQ0FBQyxTQUFTLEtBQUssT0FBTztZQUFFLElBQUksQ0FBQyxTQUFTLEdBQUcsY0FBYyxDQUFDO0lBQ2xILENBQUM7SUFFRCxlQUFlO1FBQ1gsSUFBSSxDQUFDLE9BQU8sR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDLFNBQVMsRUFBRSxDQUFDO1FBQ3RDLElBQUksQ0FBQyxjQUFjLEdBQUcsSUFBSSxDQUFDLFdBQVcsQ0FBQyxhQUFhLENBQUMsYUFBYSxDQUFDLHVEQUF1RCxDQUFDLENBQUM7UUFDNUgsSUFBSSxJQUFJLENBQUMsVUFBVSxLQUFLLENBQUM7WUFBRSxJQUFJLENBQUMsYUFBYSxFQUFFLENBQUM7UUFDaEQsSUFBSSxDQUFDLFVBQVUsRUFBRSxDQUFDO1FBQ2xCLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQywwQkFBMEIsQ0FBQyxJQUFJLENBQUMsT0FBTyxFQUFFLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQztJQUMvRSxDQUFDO0lBRUQsV0FBVztRQUNQLElBQUksQ0FBQyxtQkFBbUIsQ0FBQyxjQUFjLENBQUMsSUFBSSxDQUFDLG1CQUFtQixDQUFDLENBQUM7SUFDdEUsQ0FBQztJQUVPLFVBQVU7UUFDZCxJQUFJLENBQUMsSUFBSSxDQUFDLGlCQUFpQjtZQUFFLE9BQU87UUFDcEMsSUFBSSxDQUFDLG1CQUFtQixDQUFDLFNBQVMsR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxjQUFjLEVBQUUsSUFBSSxFQUFFLENBQUM7UUFDN0UsSUFBSSxDQUFDLHNCQUFzQixFQUFFLENBQUM7UUFDOUIsSUFBSSxDQUFDLGdCQUFnQixDQUFDLG9CQUFvQixDQUN0QyxJQUFJLENBQUMsbUJBQW1CLEVBQ3hCLEVBQUUsT0FBTyxFQUFFLElBQUksQ0FBQyxLQUFLLEVBQUUsYUFBYSxFQUFFLElBQUksQ0FBQyxtQkFBbUIsRUFBRSxFQUNoRSxFQUFFLE1BQU0sRUFBRSxJQUFJLENBQUMsT0FBTyxFQUFFLE9BQU8sRUFBRSxJQUFJLENBQUMsZUFBZSxFQUFFLEVBQ3ZELElBQUksQ0FBQyxTQUFTLENBQ2pCLENBQUM7SUFDTixDQUFDO0lBRU8sc0JBQXNCO1FBQzFCLElBQUksQ0FBQyxtQkFBbUIsR0FBRyxJQUFJLENBQUMsV0FBVyxDQUFDLGFBQWEsQ0FBQyxnQkFBZ0IsQ0FBQyw0RUFBNEUsQ0FBQyxDQUFDO0lBQzdKLENBQUM7SUFFTyxhQUFhO1FBQ2pCLElBQUksR0FBRyxHQUFHLE1BQU0sQ0FBQyxVQUFVLElBQUksTUFBTSxDQUFDLFVBQVUsR0FBRyxHQUFHLEVBQUU7WUFDcEQsSUFBSSxJQUFJLENBQUMsZUFBZSxDQUFDLE1BQU0sS0FBSyxLQUFLLEVBQUU7Z0JBQ3ZDLElBQUksQ0FBQyxlQUFlLEdBQUcsSUFBSSxDQUFDO2dCQUM1QixJQUFJLENBQUMsZUFBZSxDQUFDLE1BQU0sR0FBRyxJQUFJLENBQUM7YUFDdEM7U0FDSjthQUFNO1lBQ0gsSUFBSSxJQUFJLENBQUMsZUFBZSxDQUFDLE1BQU0sS0FBSyxJQUFJLEVBQUU7Z0JBQ3RDLElBQUksQ0FBQyxlQUFlLEdBQUcsS0FBSyxDQUFDO2dCQUM3QixJQUFJLENBQUMsZUFBZSxDQUFDLE1BQU0sR0FBRyxLQUFLLENBQUM7YUFDdkM7U0FDSjtJQUNMLENBQUM7SUFFTyxhQUFhO1FBQ2pCLElBQUksR0FBRyxHQUFHLE1BQU0sQ0FBQyxVQUFVLElBQUksTUFBTSxDQUFDLFVBQVUsR0FBRyxHQUFHLEVBQUU7WUFDcEQsSUFBSSxJQUFJLENBQUMsZUFBZSxDQUFDLE1BQU0sS0FBSyxLQUFLLEVBQUU7Z0JBQ3ZDLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxjQUFjLENBQUMsSUFBSSxFQUFFLElBQUksQ0FBQyxPQUFPLENBQUMsQ0FBQztnQkFDekQsSUFBSSxDQUFDLGVBQWUsQ0FBQyxNQUFNLEdBQUcsSUFBSSxDQUFDO2dCQUNuQyxJQUFJLENBQUMsU0FBUyxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsY0FBYyxFQUFFLE9BQU8sRUFBRSxNQUFNLENBQUMsQ0FBQztnQkFDOUQsSUFBSSxDQUFDLFNBQVMsQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLGNBQWMsRUFBRSxRQUFRLEVBQUUsTUFBTSxDQUFDLENBQUM7YUFDbEU7U0FDSjthQUFNLElBQUksTUFBTSxDQUFDLFVBQVUsR0FBRyxHQUFHLElBQUksTUFBTSxDQUFDLFVBQVUsS0FBSyxHQUFHLEVBQUU7WUFDN0QsSUFBSSxJQUFJLENBQUMsZUFBZSxDQUFDLE1BQU0sS0FBSyxJQUFJLEVBQUU7Z0JBQ3RDLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxjQUFjLENBQUMsS0FBSyxFQUFFLElBQUksQ0FBQyxPQUFPLENBQUMsQ0FBQztnQkFDMUQsSUFBSSxDQUFDLGVBQWUsQ0FBQyxNQUFNLEdBQUcsS0FBSyxDQUFDO2dCQUNwQyxJQUFJLENBQUMsU0FBUyxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsY0FBYyxFQUFFLE9BQU8sRUFBRSxPQUFPLENBQUMsQ0FBQztnQkFDL0QsSUFBSSxDQUFDLFNBQVMsQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLGNBQWMsRUFBRSxRQUFRLEVBQUUsT0FBTyxDQUFDLENBQUM7YUFDbkU7U0FDSjtJQUNMLENBQUM7OztZQXpJSixTQUFTLFNBQUM7Z0JBQ1AsUUFBUSxFQUFFLHlCQUF5QjtnQkFDbkMsUUFBUSxFQUFFOzs7Ozs7Ozs7ZUFTQztnQkFDWCxhQUFhLEVBQUUsaUJBQWlCLENBQUMsSUFBSTtnQkFDckMsU0FBUyxFQUFFLENBQUMsa0JBQWtCLENBQUM7Z0JBQy9CLElBQUksRUFBRSxFQUFFLEtBQUssRUFBRSwwQkFBMEIsRUFBQzthQUM3Qzs7O1lBbEJRLGtCQUFrQjtZQU52QixVQUFVO1lBQ1YsU0FBUztZQU1KLGVBQWU7OzttQkFnQ25CLEtBQUs7c0JBQ0wsS0FBSztnQ0FDTCxLQUFLO3lCQUNMLEtBQUs7d0JBQ0wsS0FBSztvQkFFTCxTQUFTLFNBQUMsT0FBTyxFQUFFLEVBQUUsTUFBTSxFQUFFLElBQUksRUFBRTtzQkFDbkMsU0FBUyxTQUFDLEdBQUcsRUFBRSxFQUFFLE1BQU0sRUFBRSxJQUFJLEVBQUU7MEJBQy9CLFNBQVMsU0FBQyxhQUFhLEVBQUUsRUFBRSxNQUFNLEVBQUUsSUFBSSxFQUFFO3VCQWlCekMsWUFBWSxTQUFDLGVBQWUsRUFBRSxDQUFDLFFBQVEsQ0FBQyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7XHJcbiAgICBDb21wb25lbnQsXHJcbiAgICBWaWV3RW5jYXBzdWxhdGlvbixcclxuICAgIFZpZXdDaGlsZCxcclxuICAgIElucHV0LFxyXG4gICAgT25Jbml0LFxyXG4gICAgT25DaGFuZ2VzLFxyXG4gICAgU2ltcGxlQ2hhbmdlcyxcclxuICAgIEFmdGVyVmlld0luaXQsXHJcbiAgICBPbkRlc3Ryb3ksXHJcbiAgICBFbGVtZW50UmVmLFxyXG4gICAgUmVuZGVyZXIyLFxyXG4gICAgSG9zdExpc3RlbmVyLFxyXG59IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xyXG5pbXBvcnQgeyBVSUNoYXJ0IH0gZnJvbSAncHJpbWVuZy9jaGFydCc7XHJcbmltcG9ydCAqIGFzIHR5cGVzIGZyb20gJy4va2QtYW5ndWxhci1taW5pLWRhc2hib2FyZC1pbnRlcmZhY2UnO1xyXG5pbXBvcnQgeyBLZE1pbmlEYXNoYm9hcmRTdmMgfSBmcm9tICcuL2tkLWFuZ3VsYXItbWluaS1kYXNoYm9hcmQtc3ZjJztcclxuaW1wb3J0IHsgS2RTcGxpdHRlckV2ZW50IH0gZnJvbSAnLi4va2QtYW5ndWxhci1zcGxpdHRlci9pbmRleCc7XHJcblxyXG5AQ29tcG9uZW50KHtcclxuICAgIHNlbGVjdG9yOiAna2QtbWluaS1kYXNoYm9hcmQtY2hhcnQnLFxyXG4gICAgdGVtcGxhdGU6IGBcclxuICAgICAgICA8ZGl2IGNsYXNzPVwia2R4LWVsZW0taXRlbVwiPlxyXG4gICAgICAgICAgICA8cC1jaGFydCBjbGFzcz1cImNoYXJ0LW1haW5cIiB0eXBlPVwiZG91Z2hudXRcIiBbZGF0YV09XCJkYXRhXCIgW29wdGlvbnNdPVwib3B0aW9uc1wiID48L3AtY2hhcnQ+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJjaGFydC1sZWdlbmRcIlxyXG4gICAgICAgICAgICAgICAgICNjaGFydExlZ2VuZFxyXG4gICAgICAgICAgICAgICAgIFthdHRyLmtkLW1pbmktZGFzaGJvYXJkLWNoYXJ0LWluZGV4XT1cImRhdGEuY2hhcnRJbmRleFwiXHJcbiAgICAgICAgICAgICAgICAgW25nQ2xhc3NdPVwieyd0aHJlZS1pdGVtLWNoYXJ0LWxlZ2VuZCcgOiB0aHJlZUl0ZW1MZWdlbmQgfVwiPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPGRpdiBjbGFzcz1cImtkeC1taW5pLWRhc2hib2FyZC10b29sdGlwXCIgW3BsYWNlbWVudF09XCJwbGFjZW1lbnRcIiBuZ2JUb29sdGlwPVwiXCIgdHJpZ2dlcnM9XCJtYW51YWxcIiAjdD1cIm5nYlRvb2x0aXBcIj48L2Rpdj5cclxuICAgICAgICA8L2Rpdj5gLFxyXG4gICAgZW5jYXBzdWxhdGlvbjogVmlld0VuY2Fwc3VsYXRpb24uTm9uZSxcclxuICAgIHByb3ZpZGVyczogW0tkTWluaURhc2hib2FyZFN2Y10sXHJcbiAgICBob3N0OiB7IGNsYXNzOiAna2R4LW1pbmktZGFzaGJvYXJkLWNoYXJ0J31cclxufSlcclxuXHJcbmV4cG9ydCBjbGFzcyBLZE1pbmlEYXNoYm9hcmRDaGFydCBpbXBsZW1lbnRzIE9uSW5pdCwgT25DaGFuZ2VzLCBBZnRlclZpZXdJbml0LCBPbkRlc3Ryb3kge1xyXG4gICAgcHVibGljIHRocmVlSXRlbUxlZ2VuZDogYm9vbGVhbiA9IGZhbHNlO1xyXG4gICAgcHVibGljIHBsYWNlbWVudDogc3RyaW5nID0gJ2JvdHRvbS1sZWZ0JztcclxuXHJcbiAgICBwcml2YXRlIF9jYW52YXM6IEVsZW1lbnQ7XHJcbiAgICBwcml2YXRlIF9jaGFydExlZ2VuZEVsZW1lbnQ6IEVsZW1lbnQ7XHJcbiAgICBwcml2YXRlIF9sZWdlbmRMYWJlbEVsZW1lbnQ6IEVsZW1lbnQ7XHJcbiAgICBwcml2YXRlIF90b29sdGlwRWxlbWVudDogRWxlbWVudDtcclxuICAgIHByaXZhdGUgX3BDaGFydHNGdW5jdGlvbjogdHlwZXMuSUNoYXJ0RnVuY3Rpb25zO1xyXG4gICAgcHJpdmF0ZSBfaXNXaWR0aENoYW5nZWQ6IHsgbGVnZW5kOiBib29sZWFuLCBjYW52YXM6IGJvb2xlYW4gfSA9IHsgbGVnZW5kOiBmYWxzZSwgY2FudmFzOiBmYWxzZSB9O1xyXG4gICAgcHJpdmF0ZSBfaXNGaXJzdExvYWQ6IGJvb2xlYW4gPSB0cnVlO1xyXG4gICAgcHJpdmF0ZSBfcENoYXJ0RWxlbWVudDogYW55O1xyXG5cclxuICAgIEBJbnB1dCgpIGRhdGE6IGFueTtcclxuICAgIEBJbnB1dCgpIG9wdGlvbnM6IGFueTtcclxuICAgIEBJbnB1dCgpIGlzTGVnZW5kRGlzcGxheWVkOiBib29sZWFuO1xyXG4gICAgQElucHV0KCkgaXRlbUxlbmd0aDogbnVtYmVyO1xyXG4gICAgQElucHV0KCkgZGlyZWN0aW9uOiBzdHJpbmc7XHJcblxyXG4gICAgQFZpZXdDaGlsZChVSUNoYXJ0LCB7IHN0YXRpYzogdHJ1ZSB9KSBjaGFydDogVUlDaGFydDtcclxuICAgIEBWaWV3Q2hpbGQoJ3QnLCB7IHN0YXRpYzogdHJ1ZSB9KSB0b29sdGlwOiBhbnk7XHJcbiAgICBAVmlld0NoaWxkKCdjaGFydExlZ2VuZCcsIHsgc3RhdGljOiB0cnVlIH0pIGNoYXJ0TGVnZW5kOiBhbnk7XHJcblxyXG4gICAgY29uc3RydWN0b3IoXHJcbiAgICAgICAgcHJpdmF0ZSBfa2RNaW5pRGFzaGJvYXJkU3ZjOiBLZE1pbmlEYXNoYm9hcmRTdmMsXHJcbiAgICAgICAgcHJpdmF0ZSBfZWxlbWVudFJlZjogRWxlbWVudFJlZixcclxuICAgICAgICBwcml2YXRlIF9yZW5kZXJlcjogUmVuZGVyZXIyLFxyXG4gICAgICAgIF9rZFNwbGl0dGVyRXZlbnQ6IEtkU3BsaXR0ZXJFdmVudFxyXG4gICAgKSB7XHJcbiAgICAgICAgdGhpcy5fcENoYXJ0c0Z1bmN0aW9uID0gX2tkTWluaURhc2hib2FyZFN2Yy5wY2hhcnRzKF9lbGVtZW50UmVmLCBfcmVuZGVyZXIpO1xyXG4gICAgICAgIF9rZFNwbGl0dGVyRXZlbnQub25EcmFnKCkuc3Vic2NyaWJlKF90eXBlID0+IHtcclxuICAgICAgICAgICAgdGhpcy5fcENoYXJ0c0Z1bmN0aW9uLnNldFRvb2x0aXBQbGFjZW1lbnRGbGFnKHRydWUpO1xyXG4gICAgICAgIH0pO1xyXG4gICAgICAgIF9rZFNwbGl0dGVyRXZlbnQub25Ub2dnbGVNZW51KCkuc3Vic2NyaWJlKF90eXBlID0+IHtcclxuICAgICAgICAgICAgdGhpcy5fcENoYXJ0c0Z1bmN0aW9uLnNldFRvb2x0aXBQbGFjZW1lbnRGbGFnKHRydWUpO1xyXG4gICAgICAgIH0pO1xyXG4gICAgfVxyXG5cclxuICAgIEBIb3N0TGlzdGVuZXIoJ3dpbmRvdzpyZXNpemUnLCBbJyRldmVudCddKVxyXG4gICAgb25SZXNpemUoZXZlbnQ6IGFueSk6IHZvaWQge1xyXG4gICAgICAgIHRoaXMuX3BDaGFydHNGdW5jdGlvbi5zZXRUb29sdGlwUGxhY2VtZW50RmxhZyh0cnVlKTtcclxuICAgICAgICB0aGlzLl9wQ2hhcnRzRnVuY3Rpb24ucHJvY2Vzc1Rvb2x0aXBUb0NhbnZhc1NpemUodGhpcy5fY2FudmFzLCB0aGlzLmNoYXJ0KTtcclxuICAgICAgICBpZiAodGhpcy5pdGVtTGVuZ3RoID09PSAzKSB7XHJcbiAgICAgICAgICAgIHRoaXMuX3Jlc2l6ZUxlZ2VuZCgpO1xyXG4gICAgICAgICAgICB0aGlzLl9yZXNpemVDYW52YXMoKTtcclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgbmdPbkluaXQoKTogdm9pZCB7XHJcbiAgICAgICAgdGhpcy5faXNGaXJzdExvYWQgPSBmYWxzZTtcclxuICAgICAgICB0aGlzLl90b29sdGlwRWxlbWVudCA9IHRoaXMudG9vbHRpcC5fZWxlbWVudFJlZi5uYXRpdmVFbGVtZW50O1xyXG4gICAgICAgIHRoaXMuX2NoYXJ0TGVnZW5kRWxlbWVudCA9IHRoaXMuY2hhcnRMZWdlbmQubmF0aXZlRWxlbWVudDtcclxuICAgIH1cclxuXHJcbiAgICBuZ09uQ2hhbmdlcyhfc2ltcGxlQ2hhbmdlczogU2ltcGxlQ2hhbmdlcyk6IHZvaWQge1xyXG4gICAgICAgIGlmIChfc2ltcGxlQ2hhbmdlcy5oYXNPd25Qcm9wZXJ0eSgnaXRlbUxlbmd0aCcpICYmIF9zaW1wbGVDaGFuZ2VzLml0ZW1MZW5ndGguY3VycmVudFZhbHVlID09PSAzKSB7XHJcbiAgICAgICAgICAgIHRoaXMuX3Jlc2l6ZUxlZ2VuZCgpO1xyXG4gICAgICAgIH1cclxuICAgICAgICBpZiAoIXRoaXMuX2lzRmlyc3RMb2FkICYmIHRoaXMuaXRlbUxlbmd0aCA9PT0gMykgdGhpcy5fcmVzaXplQ2FudmFzKCk7XHJcbiAgICAgICAgaWYgKF9zaW1wbGVDaGFuZ2VzLmhhc093blByb3BlcnR5KCdkaXJlY3Rpb24nKSAmJiB0aGlzLmRpcmVjdGlvbiA9PT0gJ3JpZ2h0JykgdGhpcy5wbGFjZW1lbnQgPSAnYm90dG9tLXJpZ2h0JztcclxuICAgIH1cclxuXHJcbiAgICBuZ0FmdGVyVmlld0luaXQoKTogdm9pZCB7XHJcbiAgICAgICAgdGhpcy5fY2FudmFzID0gdGhpcy5jaGFydC5nZXRDYW52YXMoKTtcclxuICAgICAgICB0aGlzLl9wQ2hhcnRFbGVtZW50ID0gdGhpcy5fZWxlbWVudFJlZi5uYXRpdmVFbGVtZW50LnF1ZXJ5U2VsZWN0b3IoJy5rZHgtbWluaS1kYXNoYm9hcmQgLmtkeC1taW5pLWRhc2hib2FyZC1jaGFydCBwLWNoYXJ0Jyk7XHJcbiAgICAgICAgaWYgKHRoaXMuaXRlbUxlbmd0aCA9PT0gMykgdGhpcy5fcmVzaXplQ2FudmFzKCk7XHJcbiAgICAgICAgdGhpcy5fc2V0TGVnZW5kKCk7XHJcbiAgICAgICAgdGhpcy5fcENoYXJ0c0Z1bmN0aW9uLnByb2Nlc3NUb29sdGlwVG9DYW52YXNTaXplKHRoaXMuX2NhbnZhcywgdGhpcy5jaGFydCk7XHJcbiAgICB9XHJcblxyXG4gICAgbmdPbkRlc3Ryb3koKTogdm9pZCB7XHJcbiAgICAgICAgdGhpcy5fa2RNaW5pRGFzaGJvYXJkU3ZjLnJlbW92ZUNoaWxkcmVuKHRoaXMuX2NoYXJ0TGVnZW5kRWxlbWVudCk7XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfc2V0TGVnZW5kKCk6IHZvaWQge1xyXG4gICAgICAgIGlmICghdGhpcy5pc0xlZ2VuZERpc3BsYXllZCkgcmV0dXJuO1xyXG4gICAgICAgIHRoaXMuX2NoYXJ0TGVnZW5kRWxlbWVudC5pbm5lckhUTUwgPSB0aGlzLmNoYXJ0LmNoYXJ0LmdlbmVyYXRlTGVnZW5kKCkgfHwgJyc7XHJcbiAgICAgICAgdGhpcy5fc2V0TGVnZW5kTGFiZWxFbGVtZW50KCk7XHJcbiAgICAgICAgdGhpcy5fcENoYXJ0c0Z1bmN0aW9uLmF0dGFjaExlZ2VuZExpc3RlbmVyKFxyXG4gICAgICAgICAgICB0aGlzLl9sZWdlbmRMYWJlbEVsZW1lbnQsXHJcbiAgICAgICAgICAgIHsgdWlDaGFydDogdGhpcy5jaGFydCwgbGVnZW5kRWxlbWVudDogdGhpcy5fY2hhcnRMZWdlbmRFbGVtZW50IH0sXHJcbiAgICAgICAgICAgIHsgbWV0aG9kOiB0aGlzLnRvb2x0aXAsIGVsZW1lbnQ6IHRoaXMuX3Rvb2x0aXBFbGVtZW50IH0sXHJcbiAgICAgICAgICAgIHRoaXMuZGlyZWN0aW9uXHJcbiAgICAgICAgKTtcclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF9zZXRMZWdlbmRMYWJlbEVsZW1lbnQoKTogdm9pZCB7XHJcbiAgICAgICAgdGhpcy5fbGVnZW5kTGFiZWxFbGVtZW50ID0gdGhpcy5fZWxlbWVudFJlZi5uYXRpdmVFbGVtZW50LnF1ZXJ5U2VsZWN0b3JBbGwoJy5rZHgtbWluaS1kYXNoYm9hcmQgLmtkeC1lbGVtLWl0ZW0gLmNoYXJ0LWxlZ2VuZCB1bCBsaSAuY2hhcnQtbGVnZW5kLWxhYmVsJyk7XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfcmVzaXplTGVnZW5kKCk6IHZvaWQge1xyXG4gICAgICAgIGlmICg0ODAgPCB3aW5kb3cuaW5uZXJXaWR0aCAmJiB3aW5kb3cuaW5uZXJXaWR0aCA8IDY1MCkge1xyXG4gICAgICAgICAgICBpZiAodGhpcy5faXNXaWR0aENoYW5nZWQubGVnZW5kID09PSBmYWxzZSkge1xyXG4gICAgICAgICAgICAgICAgdGhpcy50aHJlZUl0ZW1MZWdlbmQgPSB0cnVlO1xyXG4gICAgICAgICAgICAgICAgdGhpcy5faXNXaWR0aENoYW5nZWQubGVnZW5kID0gdHJ1ZTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgIGlmICh0aGlzLl9pc1dpZHRoQ2hhbmdlZC5sZWdlbmQgPT09IHRydWUpIHtcclxuICAgICAgICAgICAgICAgIHRoaXMudGhyZWVJdGVtTGVnZW5kID0gZmFsc2U7XHJcbiAgICAgICAgICAgICAgICB0aGlzLl9pc1dpZHRoQ2hhbmdlZC5sZWdlbmQgPSBmYWxzZTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF9yZXNpemVDYW52YXMoKTogdm9pZCB7XHJcbiAgICAgICAgaWYgKDQ4MCA8IHdpbmRvdy5pbm5lcldpZHRoICYmIHdpbmRvdy5pbm5lcldpZHRoIDwgNjUwKSB7XHJcbiAgICAgICAgICAgIGlmICh0aGlzLl9pc1dpZHRoQ2hhbmdlZC5jYW52YXMgPT09IGZhbHNlKSB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLl9wQ2hhcnRzRnVuY3Rpb24uc2V0Q2FudmFzU3R5bGUoJzgwJywgdGhpcy5fY2FudmFzKTtcclxuICAgICAgICAgICAgICAgIHRoaXMuX2lzV2lkdGhDaGFuZ2VkLmNhbnZhcyA9IHRydWU7XHJcbiAgICAgICAgICAgICAgICB0aGlzLl9yZW5kZXJlci5zZXRTdHlsZSh0aGlzLl9wQ2hhcnRFbGVtZW50LCAnd2lkdGgnLCAnODBweCcpO1xyXG4gICAgICAgICAgICAgICAgdGhpcy5fcmVuZGVyZXIuc2V0U3R5bGUodGhpcy5fcENoYXJ0RWxlbWVudCwgJ2hlaWdodCcsICc4MHB4Jyk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9IGVsc2UgaWYgKHdpbmRvdy5pbm5lcldpZHRoID4gNjUwIHx8IHdpbmRvdy5pbm5lcldpZHRoID09PSA2NTApIHtcclxuICAgICAgICAgICAgaWYgKHRoaXMuX2lzV2lkdGhDaGFuZ2VkLmNhbnZhcyA9PT0gdHJ1ZSkge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5fcENoYXJ0c0Z1bmN0aW9uLnNldENhbnZhc1N0eWxlKCcxMDAnLCB0aGlzLl9jYW52YXMpO1xyXG4gICAgICAgICAgICAgICAgdGhpcy5faXNXaWR0aENoYW5nZWQuY2FudmFzID0gZmFsc2U7XHJcbiAgICAgICAgICAgICAgICB0aGlzLl9yZW5kZXJlci5zZXRTdHlsZSh0aGlzLl9wQ2hhcnRFbGVtZW50LCAnd2lkdGgnLCAnMTAwcHgnKTtcclxuICAgICAgICAgICAgICAgIHRoaXMuX3JlbmRlcmVyLnNldFN0eWxlKHRoaXMuX3BDaGFydEVsZW1lbnQsICdoZWlnaHQnLCAnMTAwcHgnKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgIH1cclxufVxyXG4iXX0=