import { Component, ViewEncapsulation, Input, ElementRef, Renderer2, } from '@angular/core';
import { KdDomElemSvc, KdDataSvc } from '../kd-common/index';
import * as types from './kd-angular-mini-dashboard-interface';
import { KdMiniDashboardSvc } from './kd-angular-mini-dashboard-svc';
export class KdMiniDashboard {
    constructor(_kdDomElemSvc, _elementRef, _renderer, _kdMiniDashboardSvc) {
        this._kdMiniDashboardSvc = _kdMiniDashboardSvc;
        this.isOpen = true;
        this.isThreeItem = false;
        this.updatedConfig = {};
        this.direction = 'left';
        this._defaultConfig = {
            closeButtonDisabled: false,
            reopen: true,
        };
        this._item = [];
        this._firstLoad = true;
        this._isWidthChanged = { rowContainer: false };
        this._pChartsFunction = _kdMiniDashboardSvc.pcharts(_elementRef, _renderer);
        this.direction = _kdDomElemSvc.getDocumentDirection(true);
    }
    ngOnInit() {
        this.updatedConfig = Object.assign(this._defaultConfig, this.config);
        this._firstLoad = false;
    }
    ngOnChanges(_simpleChanges) {
        if (_simpleChanges.hasOwnProperty('input'))
            this._item = this._setData(_simpleChanges.input.currentValue);
        if (this._item.length === 3) {
            this._setRowContainerWidthWhenThreeItems();
            this.isThreeItem = true;
        }
        else {
            this.isThreeItem = false;
        }
        if (!this._firstLoad) {
            if (_simpleChanges.hasOwnProperty('config'))
                this.updatedConfig = Object.assign(this.config, _simpleChanges.config.currentValue);
        }
    }
    miniDashboardSwitch() {
        this.isOpen = this.isOpen ? false : true;
    }
    _setData(_item) {
        let processedData = [];
        let noOfLoop = Math.min(_item.length, 4);
        for (let i = 0; i < noOfLoop; i++) {
            if (_item[i].type === 'chart' && _item[i].value) {
                if (!Array.isArray(_item[i].value)) {
                    console.error('value of type: chart must be array');
                    continue;
                }
                let chart = this._pChartsFunction.setChart(_item[i].value, _item[i].config, _item[i].label);
                let final = Object.assign({}, { type: 'chart', isLegendDisplayed: _item[i].config.legend.display }, chart);
                processedData.push(final);
            }
            else if (_item[i].type === 'text') {
                if (typeof _item[i].value !== 'string' && typeof _item[i].value !== 'number') {
                    console.error('value of type: text must be string or number');
                    continue;
                }
                let final = Object.assign({}, _item[i], { value: this._kdMiniDashboardSvc.addThousandSeparator(_item[i].value) });
                processedData.push(final);
            }
        }
        this.itemLength = noOfLoop;
        return processedData;
    }
    _setRowContainerWidthWhenThreeItems() {
        if (480 < window.innerWidth) {
            if (this._isWidthChanged.rowContainer === false) {
                this.isThreeItem = true;
                this._isWidthChanged.rowContainer = true;
            }
        }
        else {
            if (this._isWidthChanged.rowContainer === true) {
                this.isThreeItem = false;
                this._isWidthChanged.rowContainer = false;
            }
        }
    }
}
KdMiniDashboard.decorators = [
    { type: Component, args: [{
                selector: 'kd-mini-dashboard',
                template: "<div *ngIf=\"isOpen\" class=\"kdx-mini-dashboard\" #test>\r\n    <div class=\"kdx-row-container\" *ngFor=\"let item of _item; let i = index \" [ngClass]=\"{'three-item' : isThreeItem }\">\r\n        <ng-container [ngSwitch]=\"item.type\">\r\n            <div class=\"kdx-elem-item chart\" *ngSwitchCase=\"'text'\">\r\n                <div class=\"kdx-item-icon\" *ngIf=\"item.icon\">\r\n                    <i class=\"{{item.icon}}\"></i>\r\n                </div>\r\n                <div class=\"kdx-item-content\">\r\n                    <div class=\"kdx-mini-dashboard-ellipsis item-label\">{{ item.label }}</div>\r\n                    <div class=\"kdx-mini-dashboard-ellipsis item-value\" style=\"margin-top: 20px;font-weight: 400;\">{{ item.value || \"nil\" }}</div>\r\n                </div>\r\n            </div>\r\n            <kd-mini-dashboard-chart \r\n                *ngSwitchCase=\"'chart'\"\r\n                [data]=\"item.data\" \r\n                [options]=\"item.options\" \r\n                [isLegendDisplayed]=\"item.isLegendDisplayed\" \r\n                [itemLength]=\"itemLength\"\r\n                [direction]=\"direction\"\r\n                class=\"kdx-mini-dashboard-chart\"\r\n                >\r\n            </kd-mini-dashboard-chart>\r\n        </ng-container>\r\n    </div>\r\n    <div class=\"kdx-mini-dashboard-button \" *ngIf=\"!updatedConfig.closeButtonDisabled\">\r\n        <button type=\"button\" class=\"kdx-close-mini-dashboard\" (click)=\"miniDashboardSwitch()\"> <i class=\"fa fa-times\"></i> </button>\r\n    </div>\r\n                     \r\n</div>\r\n<button class=\"btn btn-text\" *ngIf=\"!isOpen && updatedConfig.reopen\" (click)=\"miniDashboardSwitch()\"> Open Mini Dashboard</button>\r\n",
                encapsulation: ViewEncapsulation.None,
                providers: [KdMiniDashboardSvc, KdDomElemSvc, KdDataSvc]
            },] }
];
KdMiniDashboard.ctorParameters = () => [
    { type: KdDomElemSvc },
    { type: ElementRef },
    { type: Renderer2 },
    { type: KdMiniDashboardSvc }
];
KdMiniDashboard.propDecorators = {
    config: [{ type: Input }],
    input: [{ type: Input }]
};
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoia2QtYW5ndWxhci1taW5pLWRhc2hib2FyZC5qcyIsInNvdXJjZVJvb3QiOiJDOi94YW1wcC9odGRvY3MvU3R5bGVndWlkZS9pb3N0Zy1vcGVuZW1pcy1zdHlsZWd1aWRlL3Byb2plY3RzL29wZW5lbWlzLXN0eWxlZ3VpZGUtbGliL3NyYy8iLCJzb3VyY2VzIjpbImtkLWNvbXBvbmVudHMva2QtYW5ndWxhci1taW5pLWRhc2hib2FyZC9rZC1hbmd1bGFyLW1pbmktZGFzaGJvYXJkLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBLE9BQU8sRUFDSCxTQUFTLEVBQ1QsaUJBQWlCLEVBQ2pCLEtBQUssRUFJTCxVQUFVLEVBQ1YsU0FBUyxHQUNaLE1BQU0sZUFBZSxDQUFDO0FBQ3ZCLE9BQU8sRUFBRSxZQUFZLEVBQUUsU0FBUyxFQUFFLE1BQU0sb0JBQW9CLENBQUM7QUFDN0QsT0FBTyxLQUFLLEtBQUssTUFBTSx1Q0FBdUMsQ0FBQztBQUMvRCxPQUFPLEVBQUUsa0JBQWtCLEVBQUUsTUFBTSxpQ0FBaUMsQ0FBQztBQVNyRSxNQUFNLE9BQU8sZUFBZTtJQW1CeEIsWUFDSSxhQUEyQixFQUMzQixXQUF1QixFQUN2QixTQUFvQixFQUNaLG1CQUF1QztRQUF2Qyx3QkFBbUIsR0FBbkIsbUJBQW1CLENBQW9CO1FBdEI1QyxXQUFNLEdBQVksSUFBSSxDQUFDO1FBQ3ZCLGdCQUFXLEdBQVksS0FBSyxDQUFDO1FBQzdCLGtCQUFhLEdBQStCLEVBQUUsQ0FBQztRQUMvQyxjQUFTLEdBQVcsTUFBTSxDQUFDO1FBRzFCLG1CQUFjLEdBQStCO1lBQ2pELG1CQUFtQixFQUFFLEtBQUs7WUFDMUIsTUFBTSxFQUFFLElBQUk7U0FDZixDQUFDO1FBQ0ssVUFBSyxHQUFRLEVBQUUsQ0FBQztRQUNmLGVBQVUsR0FBWSxJQUFJLENBQUM7UUFFM0Isb0JBQWUsR0FBOEIsRUFBRSxZQUFZLEVBQUUsS0FBSyxFQUFFLENBQUM7UUFXekUsSUFBSSxDQUFDLGdCQUFnQixHQUFHLG1CQUFtQixDQUFDLE9BQU8sQ0FBQyxXQUFXLEVBQUUsU0FBUyxDQUFDLENBQUM7UUFDNUUsSUFBSSxDQUFDLFNBQVMsR0FBRyxhQUFhLENBQUMsb0JBQW9CLENBQUMsSUFBSSxDQUFDLENBQUM7SUFDOUQsQ0FBQztJQUVELFFBQVE7UUFDSixJQUFJLENBQUMsYUFBYSxHQUFHLE1BQU0sQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLGNBQWMsRUFBRSxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUM7UUFDckUsSUFBSSxDQUFDLFVBQVUsR0FBRyxLQUFLLENBQUM7SUFDNUIsQ0FBQztJQUVELFdBQVcsQ0FBQyxjQUE2QjtRQUNyQyxJQUFJLGNBQWMsQ0FBQyxjQUFjLENBQUMsT0FBTyxDQUFDO1lBQUUsSUFBSSxDQUFDLEtBQUssR0FBRyxJQUFJLENBQUMsUUFBUSxDQUFDLGNBQWMsQ0FBQyxLQUFLLENBQUMsWUFBWSxDQUFDLENBQUM7UUFDMUcsSUFBSSxJQUFJLENBQUMsS0FBSyxDQUFDLE1BQU0sS0FBSyxDQUFDLEVBQUU7WUFDekIsSUFBSSxDQUFDLG1DQUFtQyxFQUFFLENBQUM7WUFDM0MsSUFBSSxDQUFDLFdBQVcsR0FBRyxJQUFJLENBQUM7U0FDM0I7YUFBTTtZQUFFLElBQUksQ0FBQyxXQUFXLEdBQUcsS0FBSyxDQUFDO1NBQUU7UUFFcEMsSUFBSSxDQUFDLElBQUksQ0FBQyxVQUFVLEVBQUU7WUFDbEIsSUFBSSxjQUFjLENBQUMsY0FBYyxDQUFDLFFBQVEsQ0FBQztnQkFBRSxJQUFJLENBQUMsYUFBYSxHQUFHLE1BQU0sQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLE1BQU0sRUFBRSxjQUFjLENBQUMsTUFBTSxDQUFDLFlBQVksQ0FBQyxDQUFDO1NBQ3BJO0lBQ0wsQ0FBQztJQUVNLG1CQUFtQjtRQUN0QixJQUFJLENBQUMsTUFBTSxHQUFHLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDO0lBQzdDLENBQUM7SUFFTyxRQUFRLENBQUMsS0FBc0M7UUFDbkQsSUFBSSxhQUFhLEdBQW9DLEVBQUUsQ0FBQztRQUN4RCxJQUFJLFFBQVEsR0FBVyxJQUFJLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxNQUFNLEVBQUUsQ0FBQyxDQUFDLENBQUM7UUFFakQsS0FBSyxJQUFJLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxHQUFHLFFBQVEsRUFBRSxDQUFDLEVBQUUsRUFBRTtZQUMvQixJQUFJLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLEtBQUssT0FBTyxJQUFJLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLEVBQUU7Z0JBQzdDLElBQUksQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsRUFBRTtvQkFDaEMsT0FBTyxDQUFDLEtBQUssQ0FBQyxvQ0FBb0MsQ0FBQyxDQUFDO29CQUNwRCxTQUFTO2lCQUNaO2dCQUVELElBQUksS0FBSyxHQUFHLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxRQUFRLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssRUFBRSxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxFQUFFLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQztnQkFDNUYsSUFBSSxLQUFLLEdBQUcsTUFBTSxDQUFDLE1BQU0sQ0FBQyxFQUFFLEVBQUUsRUFBRSxJQUFJLEVBQUUsT0FBTyxFQUFFLGlCQUFpQixFQUFFLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLE9BQU8sRUFBRSxFQUFFLEtBQUssQ0FBQyxDQUFDO2dCQUMzRyxhQUFhLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFDO2FBQzdCO2lCQUNJLElBQUksS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksS0FBSyxNQUFNLEVBQUU7Z0JBQy9CLElBQUksT0FBTyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxLQUFLLFFBQVEsSUFBSSxPQUFPLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLEtBQUssUUFBUSxFQUFFO29CQUMxRSxPQUFPLENBQUMsS0FBSyxDQUFDLDhDQUE4QyxDQUFDLENBQUM7b0JBQzlELFNBQVM7aUJBQ1o7Z0JBQ0QsSUFBSSxLQUFLLEdBQUcsTUFBTSxDQUFDLE1BQU0sQ0FBQyxFQUFFLEVBQUUsS0FBSyxDQUFDLENBQUMsQ0FBQyxFQUFFLEVBQUUsS0FBSyxFQUFFLElBQUksQ0FBQyxtQkFBbUIsQ0FBQyxvQkFBb0IsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLEVBQUUsQ0FBQyxDQUFDO2dCQUNsSCxhQUFhLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFDO2FBQzdCO1NBQ0o7UUFDRCxJQUFJLENBQUMsVUFBVSxHQUFHLFFBQVEsQ0FBQztRQUMzQixPQUFPLGFBQWEsQ0FBQztJQUN6QixDQUFDO0lBRU8sbUNBQW1DO1FBQ3ZDLElBQUksR0FBRyxHQUFHLE1BQU0sQ0FBQyxVQUFVLEVBQUU7WUFDekIsSUFBSSxJQUFJLENBQUMsZUFBZSxDQUFDLFlBQVksS0FBSyxLQUFLLEVBQUU7Z0JBQzdDLElBQUksQ0FBQyxXQUFXLEdBQUcsSUFBSSxDQUFDO2dCQUN4QixJQUFJLENBQUMsZUFBZSxDQUFDLFlBQVksR0FBRyxJQUFJLENBQUM7YUFDNUM7U0FDSjthQUFNO1lBQ0gsSUFBSSxJQUFJLENBQUMsZUFBZSxDQUFDLFlBQVksS0FBSyxJQUFJLEVBQUU7Z0JBQzVDLElBQUksQ0FBQyxXQUFXLEdBQUcsS0FBSyxDQUFDO2dCQUN6QixJQUFJLENBQUMsZUFBZSxDQUFDLFlBQVksR0FBRyxLQUFLLENBQUM7YUFDN0M7U0FDSjtJQUNMLENBQUM7OztZQWpHSixTQUFTLFNBQUM7Z0JBQ1AsUUFBUSxFQUFFLG1CQUFtQjtnQkFDN0IsNHREQUErQztnQkFDL0MsYUFBYSxFQUFFLGlCQUFpQixDQUFDLElBQUk7Z0JBQ3JDLFNBQVMsRUFBRSxDQUFDLGtCQUFrQixFQUFFLFlBQVksRUFBRSxTQUFTLENBQUM7YUFDM0Q7OztZQVRRLFlBQVk7WUFIakIsVUFBVTtZQUNWLFNBQVM7WUFJSixrQkFBa0I7OztxQkF5QnRCLEtBQUs7b0JBQ0wsS0FBSyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7XHJcbiAgICBDb21wb25lbnQsXHJcbiAgICBWaWV3RW5jYXBzdWxhdGlvbixcclxuICAgIElucHV0LFxyXG4gICAgT25Jbml0LFxyXG4gICAgT25DaGFuZ2VzLFxyXG4gICAgU2ltcGxlQ2hhbmdlcyxcclxuICAgIEVsZW1lbnRSZWYsXHJcbiAgICBSZW5kZXJlcjIsXHJcbn0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XHJcbmltcG9ydCB7IEtkRG9tRWxlbVN2YywgS2REYXRhU3ZjIH0gZnJvbSAnLi4va2QtY29tbW9uL2luZGV4JztcclxuaW1wb3J0ICogYXMgdHlwZXMgZnJvbSAnLi9rZC1hbmd1bGFyLW1pbmktZGFzaGJvYXJkLWludGVyZmFjZSc7XHJcbmltcG9ydCB7IEtkTWluaURhc2hib2FyZFN2YyB9IGZyb20gJy4va2QtYW5ndWxhci1taW5pLWRhc2hib2FyZC1zdmMnO1xyXG5cclxuQENvbXBvbmVudCh7XHJcbiAgICBzZWxlY3RvcjogJ2tkLW1pbmktZGFzaGJvYXJkJyxcclxuICAgIHRlbXBsYXRlVXJsOiAnLi9rZC1hbmd1bGFyLW1pbmktZGFzaGJvYXJkLmh0bWwnLFxyXG4gICAgZW5jYXBzdWxhdGlvbjogVmlld0VuY2Fwc3VsYXRpb24uTm9uZSxcclxuICAgIHByb3ZpZGVyczogW0tkTWluaURhc2hib2FyZFN2YywgS2REb21FbGVtU3ZjLCBLZERhdGFTdmNdLFxyXG59KVxyXG5cclxuZXhwb3J0IGNsYXNzIEtkTWluaURhc2hib2FyZCBpbXBsZW1lbnRzIE9uSW5pdCwgT25DaGFuZ2VzIHtcclxuICAgIHB1YmxpYyBpc09wZW46IGJvb2xlYW4gPSB0cnVlO1xyXG4gICAgcHVibGljIGlzVGhyZWVJdGVtOiBib29sZWFuID0gZmFsc2U7XHJcbiAgICBwdWJsaWMgdXBkYXRlZENvbmZpZzogdHlwZXMuSU1pbmlEYXNoYm9hcmRDb25maWcgPSB7fTtcclxuICAgIHB1YmxpYyBkaXJlY3Rpb246IHN0cmluZyA9ICdsZWZ0JztcclxuICAgIHB1YmxpYyBpdGVtTGVuZ3RoOiBudW1iZXI7XHJcblxyXG4gICAgcHJpdmF0ZSBfZGVmYXVsdENvbmZpZzogdHlwZXMuSU1pbmlEYXNoYm9hcmRDb25maWcgPSB7XHJcbiAgICAgICAgY2xvc2VCdXR0b25EaXNhYmxlZDogZmFsc2UsXHJcbiAgICAgICAgcmVvcGVuOiB0cnVlLFxyXG4gICAgfTtcclxuICAgIHB1YmxpYyBfaXRlbTogYW55ID0gW107XHJcbiAgICBwcml2YXRlIF9maXJzdExvYWQ6IGJvb2xlYW4gPSB0cnVlO1xyXG4gICAgcHJpdmF0ZSBfcENoYXJ0c0Z1bmN0aW9uOiB0eXBlcy5JQ2hhcnRGdW5jdGlvbnM7XHJcbiAgICBwcml2YXRlIF9pc1dpZHRoQ2hhbmdlZDogeyByb3dDb250YWluZXI6IGJvb2xlYW4gfSA9IHsgcm93Q29udGFpbmVyOiBmYWxzZSB9O1xyXG5cclxuICAgIEBJbnB1dCgpIGNvbmZpZzogdHlwZXMuSU1pbmlEYXNoYm9hcmRDb25maWc7XHJcbiAgICBASW5wdXQoKSBpbnB1dDogQXJyYXk8dHlwZXMuSU1pbmlEYXNoYm9hcmRJdGVtPjtcclxuXHJcbiAgICBjb25zdHJ1Y3RvcihcclxuICAgICAgICBfa2REb21FbGVtU3ZjOiBLZERvbUVsZW1TdmMsXHJcbiAgICAgICAgX2VsZW1lbnRSZWY6IEVsZW1lbnRSZWYsXHJcbiAgICAgICAgX3JlbmRlcmVyOiBSZW5kZXJlcjIsXHJcbiAgICAgICAgcHJpdmF0ZSBfa2RNaW5pRGFzaGJvYXJkU3ZjOiBLZE1pbmlEYXNoYm9hcmRTdmMsXHJcbiAgICApIHtcclxuICAgICAgICB0aGlzLl9wQ2hhcnRzRnVuY3Rpb24gPSBfa2RNaW5pRGFzaGJvYXJkU3ZjLnBjaGFydHMoX2VsZW1lbnRSZWYsIF9yZW5kZXJlcik7XHJcbiAgICAgICAgdGhpcy5kaXJlY3Rpb24gPSBfa2REb21FbGVtU3ZjLmdldERvY3VtZW50RGlyZWN0aW9uKHRydWUpO1xyXG4gICAgfVxyXG5cclxuICAgIG5nT25Jbml0KCk6IHZvaWQge1xyXG4gICAgICAgIHRoaXMudXBkYXRlZENvbmZpZyA9IE9iamVjdC5hc3NpZ24odGhpcy5fZGVmYXVsdENvbmZpZywgdGhpcy5jb25maWcpO1xyXG4gICAgICAgIHRoaXMuX2ZpcnN0TG9hZCA9IGZhbHNlO1xyXG4gICAgfVxyXG5cclxuICAgIG5nT25DaGFuZ2VzKF9zaW1wbGVDaGFuZ2VzOiBTaW1wbGVDaGFuZ2VzKTogdm9pZCB7XHJcbiAgICAgICAgaWYgKF9zaW1wbGVDaGFuZ2VzLmhhc093blByb3BlcnR5KCdpbnB1dCcpKSB0aGlzLl9pdGVtID0gdGhpcy5fc2V0RGF0YShfc2ltcGxlQ2hhbmdlcy5pbnB1dC5jdXJyZW50VmFsdWUpO1xyXG4gICAgICAgIGlmICh0aGlzLl9pdGVtLmxlbmd0aCA9PT0gMykge1xyXG4gICAgICAgICAgICB0aGlzLl9zZXRSb3dDb250YWluZXJXaWR0aFdoZW5UaHJlZUl0ZW1zKCk7XHJcbiAgICAgICAgICAgIHRoaXMuaXNUaHJlZUl0ZW0gPSB0cnVlO1xyXG4gICAgICAgIH0gZWxzZSB7IHRoaXMuaXNUaHJlZUl0ZW0gPSBmYWxzZTsgfVxyXG5cclxuICAgICAgICBpZiAoIXRoaXMuX2ZpcnN0TG9hZCkge1xyXG4gICAgICAgICAgICBpZiAoX3NpbXBsZUNoYW5nZXMuaGFzT3duUHJvcGVydHkoJ2NvbmZpZycpKSB0aGlzLnVwZGF0ZWRDb25maWcgPSBPYmplY3QuYXNzaWduKHRoaXMuY29uZmlnLCBfc2ltcGxlQ2hhbmdlcy5jb25maWcuY3VycmVudFZhbHVlKTtcclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgcHVibGljIG1pbmlEYXNoYm9hcmRTd2l0Y2goKTogdm9pZCB7XHJcbiAgICAgICAgdGhpcy5pc09wZW4gPSB0aGlzLmlzT3BlbiA/IGZhbHNlIDogdHJ1ZTtcclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF9zZXREYXRhKF9pdGVtOiBBcnJheTx0eXBlcy5JTWluaURhc2hib2FyZEl0ZW0+KTogQXJyYXk8dHlwZXMuSU1pbmlEYXNoYm9hcmRJdGVtPiB7XHJcbiAgICAgICAgbGV0IHByb2Nlc3NlZERhdGE6IEFycmF5PHR5cGVzLklNaW5pRGFzaGJvYXJkSXRlbT4gPSBbXTtcclxuICAgICAgICBsZXQgbm9PZkxvb3A6IG51bWJlciA9IE1hdGgubWluKF9pdGVtLmxlbmd0aCwgNCk7XHJcblxyXG4gICAgICAgIGZvciAobGV0IGkgPSAwOyBpIDwgbm9PZkxvb3A7IGkrKykge1xyXG4gICAgICAgICAgICBpZiAoX2l0ZW1baV0udHlwZSA9PT0gJ2NoYXJ0JyAmJiBfaXRlbVtpXS52YWx1ZSkge1xyXG4gICAgICAgICAgICAgICAgaWYgKCFBcnJheS5pc0FycmF5KF9pdGVtW2ldLnZhbHVlKSkge1xyXG4gICAgICAgICAgICAgICAgICAgIGNvbnNvbGUuZXJyb3IoJ3ZhbHVlIG9mIHR5cGU6IGNoYXJ0IG11c3QgYmUgYXJyYXknKTtcclxuICAgICAgICAgICAgICAgICAgICBjb250aW51ZTtcclxuICAgICAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgICAgICBsZXQgY2hhcnQgPSB0aGlzLl9wQ2hhcnRzRnVuY3Rpb24uc2V0Q2hhcnQoX2l0ZW1baV0udmFsdWUsIF9pdGVtW2ldLmNvbmZpZywgX2l0ZW1baV0ubGFiZWwpO1xyXG4gICAgICAgICAgICAgICAgbGV0IGZpbmFsID0gT2JqZWN0LmFzc2lnbih7fSwgeyB0eXBlOiAnY2hhcnQnLCBpc0xlZ2VuZERpc3BsYXllZDogX2l0ZW1baV0uY29uZmlnLmxlZ2VuZC5kaXNwbGF5IH0sIGNoYXJ0KTtcclxuICAgICAgICAgICAgICAgIHByb2Nlc3NlZERhdGEucHVzaChmaW5hbCk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgZWxzZSBpZiAoX2l0ZW1baV0udHlwZSA9PT0gJ3RleHQnKSB7XHJcbiAgICAgICAgICAgICAgICBpZiAodHlwZW9mIF9pdGVtW2ldLnZhbHVlICE9PSAnc3RyaW5nJyAmJiB0eXBlb2YgX2l0ZW1baV0udmFsdWUgIT09ICdudW1iZXInKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgY29uc29sZS5lcnJvcigndmFsdWUgb2YgdHlwZTogdGV4dCBtdXN0IGJlIHN0cmluZyBvciBudW1iZXInKTtcclxuICAgICAgICAgICAgICAgICAgICBjb250aW51ZTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIGxldCBmaW5hbCA9IE9iamVjdC5hc3NpZ24oe30sIF9pdGVtW2ldLCB7IHZhbHVlOiB0aGlzLl9rZE1pbmlEYXNoYm9hcmRTdmMuYWRkVGhvdXNhbmRTZXBhcmF0b3IoX2l0ZW1baV0udmFsdWUpIH0pO1xyXG4gICAgICAgICAgICAgICAgcHJvY2Vzc2VkRGF0YS5wdXNoKGZpbmFsKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgICAgICB0aGlzLml0ZW1MZW5ndGggPSBub09mTG9vcDtcclxuICAgICAgICByZXR1cm4gcHJvY2Vzc2VkRGF0YTtcclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF9zZXRSb3dDb250YWluZXJXaWR0aFdoZW5UaHJlZUl0ZW1zKCk6IHZvaWQge1xyXG4gICAgICAgIGlmICg0ODAgPCB3aW5kb3cuaW5uZXJXaWR0aCkge1xyXG4gICAgICAgICAgICBpZiAodGhpcy5faXNXaWR0aENoYW5nZWQucm93Q29udGFpbmVyID09PSBmYWxzZSkge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5pc1RocmVlSXRlbSA9IHRydWU7XHJcbiAgICAgICAgICAgICAgICB0aGlzLl9pc1dpZHRoQ2hhbmdlZC5yb3dDb250YWluZXIgPSB0cnVlO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgaWYgKHRoaXMuX2lzV2lkdGhDaGFuZ2VkLnJvd0NvbnRhaW5lciA9PT0gdHJ1ZSkge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5pc1RocmVlSXRlbSA9IGZhbHNlO1xyXG4gICAgICAgICAgICAgICAgdGhpcy5faXNXaWR0aENoYW5nZWQucm93Q29udGFpbmVyID0gZmFsc2U7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICB9XHJcbn1cclxuIl19