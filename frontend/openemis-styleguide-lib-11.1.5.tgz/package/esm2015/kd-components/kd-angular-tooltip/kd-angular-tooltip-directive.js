import { Directive, ElementRef, Input, Renderer2, NgZone, } from '@angular/core';
import { KdDomElemSvc } from '../kd-common/index';
import { DomHandler } from 'primeng/dom';
import { Tooltip } from 'primeng/tooltip';
import { KdSplitterEvent } from '../kd-angular-splitter/index';
export class KdTooltipDirective extends Tooltip {
    // constructor is fully new
    constructor(_el, _zone, _domHandler, _renderer, _kdDomSvc, _kdSplitterEvent) {
        // super(_el, _domHandler, _zone);
        super(_el, _zone);
        this._el = _el;
        this._domHandler = _domHandler;
        this._renderer = _renderer;
        this._isOutOfBounds = false;
        this._deactivateHostListener = false;
        this._offset = { x: 0, y: 0 };
        this._defaultOffset = 10;
        this._isMobile = _kdDomSvc.isMobileDevice();
        this._dragMenuSub = _kdSplitterEvent.onDrag().subscribe(() => {
            super.hide();
        });
        this._toggleMenuSub = _kdSplitterEvent.onToggleMenu().subscribe(() => {
            super.hide();
        });
    }
    ngOnInit() {
        this._initApi();
    }
    onMouseEnter(e) {
        // added extra condition !this._isMobile to if statement
        if (!this._isMobile && !this._deactivateHostListener) {
            if (this.hideTimeout) {
                clearTimeout(this.hideTimeout);
                this.remove();
            }
            super.activate();
        }
    }
    onMouseLeave(e) {
        // added extra condition !this._isMobile to if statement
        if (!this._isMobile && !this._deactivateHostListener) {
            super.deactivate();
        }
    }
    onClick(e) {
        if (!this._deactivateHostListener) {
            // when mobile device, click will activate the tooltip. when web, click will deactivate the tooltip
            if (!this._isMobile) {
                super.deactivate();
            }
            else {
                if (this.hideTimeout) {
                    clearTimeout(this.hideTimeout);
                    this.remove();
                }
                super.activate();
            }
        }
    }
    // changed Input param to 'kd-tooltip-dir' (old input was: pTooltip)
    set Text(text) {
        this._text = text;
        if (this.active) {
            if (this._text) {
                if (this.container && this.container.offsetParent) {
                    super.updateText();
                }
                else {
                    this.show();
                }
            }
            else {
                super.hide();
            }
        }
    }
    show() {
        if (!this._text || this.disabled) {
            return;
        }
        super.create();
        this.align();
        DomHandler.fadeIn(this.container, 250);
        if (this.tooltipZIndex === 'auto') {
            this.container.style.zIndex = ++DomHandler.zindex;
        }
        else {
            this.container.style.zIndex = this.tooltipZIndex;
        }
        if (!this._deactivateHostListener) {
            super.bindDocumentResizeListener();
            // added 1 line. _bindDocumentTouchStartListener()
            if (this._isMobile)
                this._bindDocumentTouchStartListener();
        }
    }
    align() {
        let position = this.tooltipPosition;
        this._widthOutsideViewport = null;
        switch (position) {
            case 'top':
                this.alignTop();
                // added 1 line. _widthOutsideViewport
                // this._isOutofBounds is used instead of super.OutofBounds
                if (this._isOutOfBounds) {
                    this.alignTopRight();
                    if (this._isOutOfBounds) {
                        this.alignTopLeft();
                        if (this._isOutOfBounds) {
                            this._widthOutsideViewport = this._calculateWidthOut();
                            this.alignBottom(this._widthOutsideViewport);
                        }
                    }
                }
                break;
            case 'top-right':
                this.alignTopRight();
                // added 1 line. _widthOutsideViewport
                if (this._isOutOfBounds) {
                    this.alignTop();
                    if (this._isOutOfBounds) {
                        this.alignTopLeft();
                        if (this._isOutOfBounds) {
                            this._widthOutsideViewport = this._calculateWidthOut();
                            this.alignBottom(this._widthOutsideViewport);
                        }
                    }
                }
                break;
            case 'top-left':
                this.alignTopLeft();
                // added 1 line. _widthOutsideViewport
                if (this._isOutOfBounds) {
                    this.alignTop();
                    if (this._isOutOfBounds) {
                        this.alignTopRight();
                        if (this._isOutOfBounds) {
                            this._widthOutsideViewport = this._calculateWidthOut();
                            this.alignBottom(this._widthOutsideViewport);
                        }
                    }
                }
                break;
            case 'bottom':
                this.alignBottom();
                // added 1 line. _widthOutsideViewport
                if (this._isOutOfBounds) {
                    this.alignBottomRight();
                    if (this._isOutOfBounds) {
                        this.alignBottomLeft();
                        if (this._isOutOfBounds) {
                            // added 1 line. edited alignTop with param
                            this._widthOutsideViewport = this._calculateWidthOut();
                            this.alignTop(this._widthOutsideViewport);
                        }
                    }
                }
                break;
            case 'bottom-right':
                this.alignBottomRight();
                // added 1 line. _widthOutsideViewport
                if (this._isOutOfBounds) {
                    this.alignBottom();
                    if (this._isOutOfBounds) {
                        this.alignBottomLeft();
                        if (this._isOutOfBounds) {
                            // added 1 line. edited alignTop with param
                            this._widthOutsideViewport = this._calculateWidthOut();
                            this.alignTop(this._widthOutsideViewport);
                        }
                    }
                }
                break;
            case 'bottom-left':
                this.alignBottomLeft();
                // added 1 line. _widthOutsideViewport
                if (this._isOutOfBounds) {
                    this.alignBottom();
                    if (this._isOutOfBounds) {
                        this.alignBottomRight();
                        if (this._isOutOfBounds) {
                            // added 1 line. edited alignTop with param
                            this._widthOutsideViewport = this._calculateWidthOut();
                            this.alignTop(this._widthOutsideViewport);
                        }
                    }
                }
                break;
            case 'left':
                this.alignLeft();
                if (this._isOutOfBounds) {
                    this.alignRight();
                    if (this._isOutOfBounds) {
                        this.alignTop();
                        if (this._isOutOfBounds) {
                            // added 1 line. edited alignBottom with param
                            this._widthOutsideViewport = this._calculateWidthOut();
                            this.alignBottom(this._calculateWidthOut());
                        }
                    }
                }
                break;
            case 'right':
                this.alignRight();
                if (this._isOutOfBounds) {
                    this.alignLeft();
                    if (this._isOutOfBounds) {
                        this.alignTop();
                        if (this._isOutOfBounds) {
                            // added 1 line. edited alignBottom with param
                            this.alignBottom(this._calculateWidthOut());
                        }
                    }
                }
                break;
        }
    }
    alignRight() {
        // added 1 line. edited preAlign with param
        this.preAlign('right');
        let hostOffset = super.getHostOffset();
        let width = DomHandler.getOuterWidth(this.container);
        let height = DomHandler.getOuterHeight(this.container);
        let left = hostOffset.left + DomHandler.getOuterWidth(this._el.nativeElement) + this._offset.x;
        let top = hostOffset.top + (DomHandler.getOuterHeight(this._el.nativeElement) - DomHandler.getOuterHeight(this.container)) / 2 - 1 + this._offset.y;
        this._isOutOfBounds = this._checkOutOfBounds(left, top, width, height);
        this.container.style.left = left + 'px';
        this.container.style.top = top + 'px';
    }
    alignLeft() {
        // added 1 line. edited preAlign with param
        this.preAlign('left');
        let hostOffset = super.getHostOffset();
        let width = DomHandler.getOuterWidth(this.container);
        let height = DomHandler.getOuterHeight(this.container);
        let left = hostOffset.left - DomHandler.getOuterWidth(this.container) + this._offset.x;
        let top = hostOffset.top + (DomHandler.getOuterHeight(this._el.nativeElement) - DomHandler.getOuterHeight(this.container)) / 2 + this._offset.y;
        this._isOutOfBounds = this._checkOutOfBounds(left, top, width, height);
        this.container.style.left = left + 'px';
        this.container.style.top = top + 'px';
    }
    alignTop(widthOut) {
        // added 2 line. edited preAlign with param and widthOut
        this.preAlign('top');
        if (widthOut !== 0 && typeof widthOut !== 'undefined') {
            this.container.style.maxWidth = (DomHandler.getOuterWidth(this.container) - widthOut * 2).toString() + 'px';
        }
        let hostOffset = super.getHostOffset();
        let width = DomHandler.getOuterWidth(this.container);
        let height = DomHandler.getOuterHeight(this.container);
        let left = hostOffset.left + (DomHandler.getOuterWidth(this._el.nativeElement) - DomHandler.getOuterWidth(this.container)) / 2 + this._offset.x;
        let top = hostOffset.top - DomHandler.getOuterHeight(this.container) + this._offset.y;
        this._isOutOfBounds = this._checkOutOfBounds(left, top, width, height);
        this.container.style.left = left + 'px';
        this.container.style.top = top + 'px';
    }
    // new direction
    alignTopRight(widthOut) {
        this.preAlign('top ui-tooltip-top-right');
        if (widthOut !== 0 && typeof widthOut !== 'undefined')
            this.container.style.maxWidth = (DomHandler.getOuterWidth(this.container) - widthOut * 2).toString() + 'px';
        let hostOffset = super.getHostOffset();
        let width = DomHandler.getOuterWidth(this.container);
        let height = DomHandler.getOuterHeight(this.container);
        let left = hostOffset.left + DomHandler.getOuterWidth(this._el.nativeElement) / 2 - this._defaultOffset + this._offset.x;
        let top = hostOffset.top - DomHandler.getOuterHeight(this.container) + this._offset.y;
        this._isOutOfBounds = this._checkOutOfBounds(left, top, width, height);
        this.container.style.left = left + 'px';
        this.container.style.top = top + 'px';
    }
    // new direction
    alignTopLeft(widthOut) {
        this.preAlign('top ui-tooltip-top-left');
        if (widthOut !== 0 && typeof widthOut !== 'undefined')
            this.container.style.maxWidth = (DomHandler.getOuterWidth(this.container) - widthOut * 2).toString() + 'px';
        let hostOffset = super.getHostOffset();
        let width = DomHandler.getOuterWidth(this.container);
        let height = DomHandler.getOuterHeight(this.container);
        let left = hostOffset.left + DomHandler.getOuterWidth(this._el.nativeElement) / 2 - DomHandler.getOuterWidth(this.container) + this._defaultOffset + this._offset.x;
        let top = hostOffset.top - DomHandler.getOuterHeight(this.container) + this._offset.y;
        this._isOutOfBounds = this._checkOutOfBounds(left, top, width, height);
        this.container.style.left = left + 'px';
        this.container.style.top = top + 'px';
    }
    alignBottom(widthOut) {
        // added 2 line. edited preAlign with param and widthOut
        this.preAlign('bottom');
        if (widthOut !== 0 && typeof widthOut !== 'undefined')
            this.container.style.maxWidth = (DomHandler.getOuterWidth(this.container) - widthOut * 2).toString() + 'px';
        let hostOffset = super.getHostOffset();
        let width = DomHandler.getOuterWidth(this.container);
        let height = DomHandler.getOuterHeight(this.container);
        let left = hostOffset.left + (DomHandler.getOuterWidth(this._el.nativeElement) - DomHandler.getOuterWidth(this.container)) / 2 + this._offset.x;
        let top = hostOffset.top + DomHandler.getOuterHeight(this._el.nativeElement) + this._offset.y;
        this._isOutOfBounds = this._checkOutOfBounds(left, top, width, height);
        this.container.style.left = left + 'px';
        this.container.style.top = top + 'px';
    }
    // new direction
    alignBottomRight(widthOut) {
        this.preAlign('bottom ui-tooltip-bottom-right');
        if (widthOut !== 0 && typeof widthOut !== 'undefined')
            this.container.style.maxWidth = (DomHandler.getOuterWidth(this.container) - widthOut * 2).toString() + 'px';
        let hostOffset = super.getHostOffset();
        let width = DomHandler.getOuterWidth(this.container);
        let height = DomHandler.getOuterHeight(this.container);
        let left = hostOffset.left + DomHandler.getOuterWidth(this._el.nativeElement) / 2 - this._defaultOffset + this._offset.x;
        let top = hostOffset.top + DomHandler.getOuterHeight(this._el.nativeElement) + this._offset.y;
        this._isOutOfBounds = this._checkOutOfBounds(left, top, width, height);
        this.container.style.left = left + 'px';
        this.container.style.top = top + 'px';
    }
    // new direction
    alignBottomLeft(widthOut) {
        this.preAlign('bottom ui-tooltip-bottom-left');
        if (widthOut !== 0 && typeof widthOut !== 'undefined')
            this.container.style.maxWidth = (DomHandler.getOuterWidth(this.container) - widthOut * 2).toString() + 'px';
        let hostOffset = super.getHostOffset();
        let width = DomHandler.getOuterWidth(this.container);
        let height = DomHandler.getOuterHeight(this.container);
        let left = hostOffset.left + DomHandler.getOuterWidth(this._el.nativeElement) / 2 - DomHandler.getOuterWidth(this.container) + this._defaultOffset + this._offset.x;
        let top = hostOffset.top + DomHandler.getOuterHeight(this._el.nativeElement) + this._offset.y;
        this._isOutOfBounds = this._checkOutOfBounds(left, top, width, height);
        this.container.style.left = left + 'px';
        this.container.style.top = top + 'px';
    }
    preAlign(_position) {
        this.container.style.left = -999 + 'px';
        this.container.style.top = -999 + 'px';
        // added 2 line. defaultClassName and container.className
        let defaultClassName = 'ui-tooltip ui-widget ui-tooltip-' + _position;
        this.container.className = this.tooltipStyleClass ? defaultClassName + ' ' + this.tooltipStyleClass : defaultClassName;
    }
    // temp fix: checking out of bounds should happen before wordwrap changes the size on tooltip
    _checkOutOfBounds(_left, _top, _width, _height) {
        let viewport = DomHandler.getViewport();
        return (_left + _width > viewport.width) || (_left < 0) || (_top < 0) || (_top + _height > viewport.height);
    }
    remove() {
        if (!this._deactivateHostListener) {
            // added one line, _unbindDocumentTouchStartListner()
            if (this._isMobile)
                this._unbindDocumentTouchStartListner();
        }
        if (this.container && this.container.parentElement) {
            if (this.appendTo === 'body') {
                document.body.removeChild(this.container);
            }
            else if (this.appendTo === 'target') {
                this._el.nativeElement.removeChild(this.container);
            }
            else {
                DomHandler.removeChild(this.container, this.appendTo);
            }
        }
        this.container = null;
    }
    /********New Functions***********/
    _initApi() {
        if (typeof this.api !== 'undefined') {
            this.api.showTooltip = () => super.activate();
            this.api.hideTooltip = () => super.deactivate();
            this.api.deactivateHostListener = () => { this._deactivateHostListener = true; };
            this.api.activateHostListener = () => { this._deactivateHostListener = false; };
            this.api.align = () => {
                if (!this.container)
                    return;
                this.align();
            };
            this.api.setOffset = (_offset) => { this._offset = _offset; };
        }
    }
    _calculateWidthOut() {
        let offset = this.container.getBoundingClientRect();
        let targetLeft = offset.left;
        let width = DomHandler.getOuterWidth(this.container);
        let viewport = DomHandler.getViewport();
        if (targetLeft + width - viewport.width > 0)
            return targetLeft + width - viewport.width;
        if (targetLeft < 0)
            return targetLeft * -1;
        return 0;
    }
    _bindDocumentTouchStartListener() {
        this._documentTouchStartListener = this._renderer.listen('document', 'touchstart', event => {
            super.hide();
        });
    }
    _unbindDocumentTouchStartListner() {
        if (this._documentTouchStartListener) {
            this._documentTouchStartListener();
            this._documentTouchStartListener = null;
        }
    }
    ngOnDestroy() {
        // super.unbindEvents();
        this.remove();
        // added 2 line. unsubscription
        this._dragMenuSub.unsubscribe();
        this._toggleMenuSub.unsubscribe();
    }
}
KdTooltipDirective.decorators = [
    { type: Directive, args: [{
                selector: '[kd-tooltip-dir]',
                providers: [DomHandler, KdDomElemSvc, KdSplitterEvent],
            },] }
];
KdTooltipDirective.ctorParameters = () => [
    { type: ElementRef },
    { type: NgZone },
    { type: DomHandler },
    { type: Renderer2 },
    { type: KdDomElemSvc },
    { type: KdSplitterEvent }
];
KdTooltipDirective.propDecorators = {
    api: [{ type: Input }],
    Text: [{ type: Input, args: ['kd-tooltip-dir',] }]
};
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoia2QtYW5ndWxhci10b29sdGlwLWRpcmVjdGl2ZS5qcyIsInNvdXJjZVJvb3QiOiJDOi94YW1wcC9odGRvY3MvU3R5bGVndWlkZS9pb3N0Zy1vcGVuZW1pcy1zdHlsZWd1aWRlL3Byb2plY3RzL29wZW5lbWlzLXN0eWxlZ3VpZGUtbGliL3NyYy8iLCJzb3VyY2VzIjpbImtkLWNvbXBvbmVudHMva2QtYW5ndWxhci10b29sdGlwL2tkLWFuZ3VsYXItdG9vbHRpcC1kaXJlY3RpdmUudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsT0FBTyxFQUNILFNBQVMsRUFDVCxVQUFVLEVBR1YsS0FBSyxFQUNMLFNBQVMsRUFDVCxNQUFNLEdBQ1QsTUFBTSxlQUFlLENBQUM7QUFDdkIsT0FBTyxFQUFFLFlBQVksRUFBRSxNQUFNLG9CQUFvQixDQUFDO0FBQ2xELE9BQU8sRUFBQyxVQUFVLEVBQUMsTUFBTSxhQUFhLENBQUM7QUFDdkMsT0FBTyxFQUFFLE9BQU8sRUFBRSxNQUFNLGlCQUFpQixDQUFDO0FBQzFDLE9BQU8sRUFBRSxlQUFlLEVBQUUsTUFBTSw4QkFBOEIsQ0FBQztBQWdCL0QsTUFBTSxPQUFPLGtCQUFtQixTQUFRLE9BQU87SUFlM0MsMkJBQTJCO0lBQzNCLFlBQ1ksR0FBZSxFQUN2QixLQUFhLEVBQ0wsV0FBdUIsRUFDdkIsU0FBb0IsRUFDNUIsU0FBdUIsRUFDdkIsZ0JBQWlDO1FBRWpDLGtDQUFrQztRQUNsQyxLQUFLLENBQUMsR0FBRyxFQUFFLEtBQUssQ0FBQyxDQUFDO1FBUlYsUUFBRyxHQUFILEdBQUcsQ0FBWTtRQUVmLGdCQUFXLEdBQVgsV0FBVyxDQUFZO1FBQ3ZCLGNBQVMsR0FBVCxTQUFTLENBQVc7UUFkeEIsbUJBQWMsR0FBWSxLQUFLLENBQUM7UUFHaEMsNEJBQXVCLEdBQVksS0FBSyxDQUFDO1FBQ3pDLFlBQU8sR0FBNkIsRUFBRSxDQUFDLEVBQUUsQ0FBQyxFQUFFLENBQUMsRUFBRSxDQUFDLEVBQUUsQ0FBQztRQUNuRCxtQkFBYyxHQUFXLEVBQUUsQ0FBQztRQWdCaEMsSUFBSSxDQUFDLFNBQVMsR0FBRyxTQUFTLENBQUMsY0FBYyxFQUFFLENBQUM7UUFDNUMsSUFBSSxDQUFDLFlBQVksR0FBRyxnQkFBZ0IsQ0FBQyxNQUFNLEVBQUUsQ0FBQyxTQUFTLENBQUMsR0FBUyxFQUFFO1lBQy9ELEtBQUssQ0FBQyxJQUFJLEVBQUUsQ0FBQztRQUNqQixDQUFDLENBQUMsQ0FBQztRQUNILElBQUksQ0FBQyxjQUFjLEdBQUcsZ0JBQWdCLENBQUMsWUFBWSxFQUFFLENBQUMsU0FBUyxDQUFDLEdBQVMsRUFBRTtZQUN2RSxLQUFLLENBQUMsSUFBSSxFQUFFLENBQUM7UUFDakIsQ0FBQyxDQUFDLENBQUM7SUFDUCxDQUFDO0lBRUQsUUFBUTtRQUNKLElBQUksQ0FBQyxRQUFRLEVBQUUsQ0FBQztJQUNwQixDQUFDO0lBRUQsWUFBWSxDQUFDLENBQVE7UUFDakIsd0RBQXdEO1FBQ3hELElBQUksQ0FBQyxJQUFJLENBQUMsU0FBUyxJQUFJLENBQUMsSUFBSSxDQUFDLHVCQUF1QixFQUFFO1lBQ2xELElBQUksSUFBSSxDQUFDLFdBQVcsRUFBRTtnQkFDbEIsWUFBWSxDQUFDLElBQUksQ0FBQyxXQUFXLENBQUMsQ0FBQztnQkFDL0IsSUFBSSxDQUFDLE1BQU0sRUFBRSxDQUFDO2FBQ2pCO1lBQ0QsS0FBSyxDQUFDLFFBQVEsRUFBRSxDQUFDO1NBQ3BCO0lBQ0wsQ0FBQztJQUVELFlBQVksQ0FBQyxDQUFRO1FBQ2pCLHdEQUF3RDtRQUN4RCxJQUFJLENBQUMsSUFBSSxDQUFDLFNBQVMsSUFBSSxDQUFDLElBQUksQ0FBQyx1QkFBdUIsRUFBRTtZQUNsRCxLQUFLLENBQUMsVUFBVSxFQUFFLENBQUM7U0FDdEI7SUFDTCxDQUFDO0lBRUQsT0FBTyxDQUFDLENBQVE7UUFDWixJQUFJLENBQUMsSUFBSSxDQUFDLHVCQUF1QixFQUFFO1lBQy9CLG1HQUFtRztZQUNuRyxJQUFJLENBQUMsSUFBSSxDQUFDLFNBQVMsRUFBRTtnQkFDakIsS0FBSyxDQUFDLFVBQVUsRUFBRSxDQUFDO2FBQ3RCO2lCQUFNO2dCQUNILElBQUksSUFBSSxDQUFDLFdBQVcsRUFBRTtvQkFDbEIsWUFBWSxDQUFDLElBQUksQ0FBQyxXQUFXLENBQUMsQ0FBQztvQkFDL0IsSUFBSSxDQUFDLE1BQU0sRUFBRSxDQUFDO2lCQUNqQjtnQkFFRCxLQUFLLENBQUMsUUFBUSxFQUFFLENBQUM7YUFDcEI7U0FDSjtJQUNMLENBQUM7SUFFRCxvRUFBb0U7SUFDcEUsSUFBNkIsSUFBSSxDQUFDLElBQVk7UUFDMUMsSUFBSSxDQUFDLEtBQUssR0FBRyxJQUFJLENBQUM7UUFDbEIsSUFBSSxJQUFJLENBQUMsTUFBTSxFQUFFO1lBQ2IsSUFBSSxJQUFJLENBQUMsS0FBSyxFQUFFO2dCQUNaLElBQUksSUFBSSxDQUFDLFNBQVMsSUFBSSxJQUFJLENBQUMsU0FBUyxDQUFDLFlBQVksRUFBRTtvQkFDL0MsS0FBSyxDQUFDLFVBQVUsRUFBRSxDQUFDO2lCQUN0QjtxQkFBTTtvQkFDSCxJQUFJLENBQUMsSUFBSSxFQUFFLENBQUM7aUJBQ2Y7YUFDSjtpQkFDSTtnQkFDRCxLQUFLLENBQUMsSUFBSSxFQUFFLENBQUM7YUFDaEI7U0FDSjtJQUNMLENBQUM7SUFFTSxJQUFJO1FBQ1AsSUFBSSxDQUFDLElBQUksQ0FBQyxLQUFLLElBQUksSUFBSSxDQUFDLFFBQVEsRUFBRTtZQUM5QixPQUFPO1NBQ1Y7UUFDRCxLQUFLLENBQUMsTUFBTSxFQUFFLENBQUM7UUFDZixJQUFJLENBQUMsS0FBSyxFQUFFLENBQUM7UUFFYixVQUFVLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxTQUFTLEVBQUUsR0FBRyxDQUFDLENBQUM7UUFDdkMsSUFBSSxJQUFJLENBQUMsYUFBYSxLQUFLLE1BQU0sRUFBRTtZQUMvQixJQUFJLENBQUMsU0FBUyxDQUFDLEtBQUssQ0FBQyxNQUFNLEdBQUcsRUFBRSxVQUFVLENBQUMsTUFBTSxDQUFDO1NBQ3JEO2FBQU07WUFDSCxJQUFJLENBQUMsU0FBUyxDQUFDLEtBQUssQ0FBQyxNQUFNLEdBQUcsSUFBSSxDQUFDLGFBQWEsQ0FBQztTQUNwRDtRQUNELElBQUksQ0FBQyxJQUFJLENBQUMsdUJBQXVCLEVBQUU7WUFDL0IsS0FBSyxDQUFDLDBCQUEwQixFQUFFLENBQUM7WUFDbkMsa0RBQWtEO1lBQ2xELElBQUksSUFBSSxDQUFDLFNBQVM7Z0JBQUUsSUFBSSxDQUFDLCtCQUErQixFQUFFLENBQUM7U0FDOUQ7SUFDTCxDQUFDO0lBRU0sS0FBSztRQUNSLElBQUksUUFBUSxHQUFXLElBQUksQ0FBQyxlQUFlLENBQUM7UUFDNUMsSUFBSSxDQUFDLHFCQUFxQixHQUFHLElBQUksQ0FBQztRQUVsQyxRQUFRLFFBQVEsRUFBRTtZQUNkLEtBQUssS0FBSztnQkFDTixJQUFJLENBQUMsUUFBUSxFQUFFLENBQUM7Z0JBQ2hCLHNDQUFzQztnQkFDdEMsMkRBQTJEO2dCQUMzRCxJQUFJLElBQUksQ0FBQyxjQUFjLEVBQUU7b0JBQ3JCLElBQUksQ0FBQyxhQUFhLEVBQUUsQ0FBQztvQkFFckIsSUFBSSxJQUFJLENBQUMsY0FBYyxFQUFFO3dCQUNyQixJQUFJLENBQUMsWUFBWSxFQUFFLENBQUM7d0JBRXBCLElBQUksSUFBSSxDQUFDLGNBQWMsRUFBRTs0QkFDckIsSUFBSSxDQUFDLHFCQUFxQixHQUFHLElBQUksQ0FBQyxrQkFBa0IsRUFBRSxDQUFDOzRCQUN2RCxJQUFJLENBQUMsV0FBVyxDQUFDLElBQUksQ0FBQyxxQkFBcUIsQ0FBQyxDQUFDO3lCQUNoRDtxQkFDSjtpQkFDSjtnQkFDRCxNQUFNO1lBRVYsS0FBSyxXQUFXO2dCQUNaLElBQUksQ0FBQyxhQUFhLEVBQUUsQ0FBQztnQkFDckIsc0NBQXNDO2dCQUN0QyxJQUFJLElBQUksQ0FBQyxjQUFjLEVBQUU7b0JBQ3JCLElBQUksQ0FBQyxRQUFRLEVBQUUsQ0FBQztvQkFFaEIsSUFBSSxJQUFJLENBQUMsY0FBYyxFQUFFO3dCQUNyQixJQUFJLENBQUMsWUFBWSxFQUFFLENBQUM7d0JBRXBCLElBQUksSUFBSSxDQUFDLGNBQWMsRUFBRTs0QkFDckIsSUFBSSxDQUFDLHFCQUFxQixHQUFHLElBQUksQ0FBQyxrQkFBa0IsRUFBRSxDQUFDOzRCQUN2RCxJQUFJLENBQUMsV0FBVyxDQUFDLElBQUksQ0FBQyxxQkFBcUIsQ0FBQyxDQUFDO3lCQUNoRDtxQkFDSjtpQkFDSjtnQkFDRCxNQUFNO1lBRVYsS0FBSyxVQUFVO2dCQUNYLElBQUksQ0FBQyxZQUFZLEVBQUUsQ0FBQztnQkFDcEIsc0NBQXNDO2dCQUN0QyxJQUFJLElBQUksQ0FBQyxjQUFjLEVBQUU7b0JBQ3JCLElBQUksQ0FBQyxRQUFRLEVBQUUsQ0FBQztvQkFFaEIsSUFBSSxJQUFJLENBQUMsY0FBYyxFQUFFO3dCQUNyQixJQUFJLENBQUMsYUFBYSxFQUFFLENBQUM7d0JBRXJCLElBQUksSUFBSSxDQUFDLGNBQWMsRUFBRTs0QkFDckIsSUFBSSxDQUFDLHFCQUFxQixHQUFHLElBQUksQ0FBQyxrQkFBa0IsRUFBRSxDQUFDOzRCQUN2RCxJQUFJLENBQUMsV0FBVyxDQUFDLElBQUksQ0FBQyxxQkFBcUIsQ0FBQyxDQUFDO3lCQUNoRDtxQkFDSjtpQkFDSjtnQkFDRCxNQUFNO1lBRVYsS0FBSyxRQUFRO2dCQUNULElBQUksQ0FBQyxXQUFXLEVBQUUsQ0FBQztnQkFDbkIsc0NBQXNDO2dCQUN0QyxJQUFJLElBQUksQ0FBQyxjQUFjLEVBQUU7b0JBQ3JCLElBQUksQ0FBQyxnQkFBZ0IsRUFBRSxDQUFDO29CQUV4QixJQUFJLElBQUksQ0FBQyxjQUFjLEVBQUU7d0JBQ3JCLElBQUksQ0FBQyxlQUFlLEVBQUUsQ0FBQzt3QkFFdkIsSUFBSSxJQUFJLENBQUMsY0FBYyxFQUFFOzRCQUNyQiwyQ0FBMkM7NEJBQzNDLElBQUksQ0FBQyxxQkFBcUIsR0FBRyxJQUFJLENBQUMsa0JBQWtCLEVBQUUsQ0FBQzs0QkFDdkQsSUFBSSxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMscUJBQXFCLENBQUMsQ0FBQzt5QkFDN0M7cUJBQ0o7aUJBQ0o7Z0JBQ0QsTUFBTTtZQUVWLEtBQUssY0FBYztnQkFDZixJQUFJLENBQUMsZ0JBQWdCLEVBQUUsQ0FBQztnQkFDeEIsc0NBQXNDO2dCQUN0QyxJQUFJLElBQUksQ0FBQyxjQUFjLEVBQUU7b0JBQ3JCLElBQUksQ0FBQyxXQUFXLEVBQUUsQ0FBQztvQkFFbkIsSUFBSSxJQUFJLENBQUMsY0FBYyxFQUFFO3dCQUNyQixJQUFJLENBQUMsZUFBZSxFQUFFLENBQUM7d0JBRXZCLElBQUksSUFBSSxDQUFDLGNBQWMsRUFBRTs0QkFDckIsMkNBQTJDOzRCQUMzQyxJQUFJLENBQUMscUJBQXFCLEdBQUcsSUFBSSxDQUFDLGtCQUFrQixFQUFFLENBQUM7NEJBQ3ZELElBQUksQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLHFCQUFxQixDQUFDLENBQUM7eUJBQzdDO3FCQUNKO2lCQUNKO2dCQUNELE1BQU07WUFFVixLQUFLLGFBQWE7Z0JBQ2QsSUFBSSxDQUFDLGVBQWUsRUFBRSxDQUFDO2dCQUN2QixzQ0FBc0M7Z0JBQ3RDLElBQUksSUFBSSxDQUFDLGNBQWMsRUFBRTtvQkFDckIsSUFBSSxDQUFDLFdBQVcsRUFBRSxDQUFDO29CQUVuQixJQUFJLElBQUksQ0FBQyxjQUFjLEVBQUU7d0JBQ3JCLElBQUksQ0FBQyxnQkFBZ0IsRUFBRSxDQUFDO3dCQUV4QixJQUFJLElBQUksQ0FBQyxjQUFjLEVBQUU7NEJBQ3JCLDJDQUEyQzs0QkFDM0MsSUFBSSxDQUFDLHFCQUFxQixHQUFHLElBQUksQ0FBQyxrQkFBa0IsRUFBRSxDQUFDOzRCQUN2RCxJQUFJLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxxQkFBcUIsQ0FBQyxDQUFDO3lCQUM3QztxQkFDSjtpQkFDSjtnQkFDRCxNQUFNO1lBRVYsS0FBSyxNQUFNO2dCQUNQLElBQUksQ0FBQyxTQUFTLEVBQUUsQ0FBQztnQkFDakIsSUFBSSxJQUFJLENBQUMsY0FBYyxFQUFFO29CQUNyQixJQUFJLENBQUMsVUFBVSxFQUFFLENBQUM7b0JBRWxCLElBQUksSUFBSSxDQUFDLGNBQWMsRUFBRTt3QkFDckIsSUFBSSxDQUFDLFFBQVEsRUFBRSxDQUFDO3dCQUVoQixJQUFJLElBQUksQ0FBQyxjQUFjLEVBQUU7NEJBQ3JCLDhDQUE4Qzs0QkFDOUMsSUFBSSxDQUFDLHFCQUFxQixHQUFHLElBQUksQ0FBQyxrQkFBa0IsRUFBRSxDQUFDOzRCQUN2RCxJQUFJLENBQUMsV0FBVyxDQUFDLElBQUksQ0FBQyxrQkFBa0IsRUFBRSxDQUFDLENBQUM7eUJBQy9DO3FCQUNKO2lCQUNKO2dCQUNELE1BQU07WUFFVixLQUFLLE9BQU87Z0JBQ1IsSUFBSSxDQUFDLFVBQVUsRUFBRSxDQUFDO2dCQUNsQixJQUFJLElBQUksQ0FBQyxjQUFjLEVBQUU7b0JBQ3JCLElBQUksQ0FBQyxTQUFTLEVBQUUsQ0FBQztvQkFFakIsSUFBSSxJQUFJLENBQUMsY0FBYyxFQUFFO3dCQUNyQixJQUFJLENBQUMsUUFBUSxFQUFFLENBQUM7d0JBRWhCLElBQUksSUFBSSxDQUFDLGNBQWMsRUFBRTs0QkFDckIsOENBQThDOzRCQUM5QyxJQUFJLENBQUMsV0FBVyxDQUFDLElBQUksQ0FBQyxrQkFBa0IsRUFBRSxDQUFDLENBQUM7eUJBQy9DO3FCQUNKO2lCQUNKO2dCQUNELE1BQU07U0FDYjtJQUNMLENBQUM7SUFFTSxVQUFVO1FBQ2IsMkNBQTJDO1FBQzNDLElBQUksQ0FBQyxRQUFRLENBQUMsT0FBTyxDQUFDLENBQUM7UUFDdkIsSUFBSSxVQUFVLEdBQWtDLEtBQUssQ0FBQyxhQUFhLEVBQUUsQ0FBQztRQUN0RSxJQUFJLEtBQUssR0FBVyxVQUFVLENBQUMsYUFBYSxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsQ0FBQztRQUM3RCxJQUFJLE1BQU0sR0FBVyxVQUFVLENBQUMsY0FBYyxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsQ0FBQztRQUMvRCxJQUFJLElBQUksR0FBVyxVQUFVLENBQUMsSUFBSSxHQUFHLFVBQVUsQ0FBQyxhQUFhLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxhQUFhLENBQUMsR0FBRyxJQUFJLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQztRQUN2RyxJQUFJLEdBQUcsR0FBVyxVQUFVLENBQUMsR0FBRyxHQUFHLENBQUMsVUFBVSxDQUFDLGNBQWMsQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLGFBQWEsQ0FBQyxHQUFHLFVBQVUsQ0FBQyxjQUFjLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUMsR0FBRyxJQUFJLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQztRQUU1SixJQUFJLENBQUMsY0FBYyxHQUFHLElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxJQUFJLEVBQUUsR0FBRyxFQUFFLEtBQUssRUFBRSxNQUFNLENBQUMsQ0FBQztRQUN2RSxJQUFJLENBQUMsU0FBUyxDQUFDLEtBQUssQ0FBQyxJQUFJLEdBQUcsSUFBSSxHQUFHLElBQUksQ0FBQztRQUN4QyxJQUFJLENBQUMsU0FBUyxDQUFDLEtBQUssQ0FBQyxHQUFHLEdBQUcsR0FBRyxHQUFHLElBQUksQ0FBQztJQUMxQyxDQUFDO0lBRU0sU0FBUztRQUNaLDJDQUEyQztRQUMzQyxJQUFJLENBQUMsUUFBUSxDQUFDLE1BQU0sQ0FBQyxDQUFDO1FBQ3RCLElBQUksVUFBVSxHQUFrQyxLQUFLLENBQUMsYUFBYSxFQUFFLENBQUM7UUFDdEUsSUFBSSxLQUFLLEdBQVcsVUFBVSxDQUFDLGFBQWEsQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLENBQUM7UUFDN0QsSUFBSSxNQUFNLEdBQVcsVUFBVSxDQUFDLGNBQWMsQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLENBQUM7UUFDL0QsSUFBSSxJQUFJLEdBQVcsVUFBVSxDQUFDLElBQUksR0FBRyxVQUFVLENBQUMsYUFBYSxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsR0FBRyxJQUFJLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQztRQUMvRixJQUFJLEdBQUcsR0FBVyxVQUFVLENBQUMsR0FBRyxHQUFHLENBQUMsVUFBVSxDQUFDLGNBQWMsQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLGFBQWEsQ0FBQyxHQUFHLFVBQVUsQ0FBQyxjQUFjLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxHQUFHLElBQUksQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDO1FBRXhKLElBQUksQ0FBQyxjQUFjLEdBQUcsSUFBSSxDQUFDLGlCQUFpQixDQUFDLElBQUksRUFBRSxHQUFHLEVBQUUsS0FBSyxFQUFFLE1BQU0sQ0FBQyxDQUFDO1FBQ3ZFLElBQUksQ0FBQyxTQUFTLENBQUMsS0FBSyxDQUFDLElBQUksR0FBRyxJQUFJLEdBQUcsSUFBSSxDQUFDO1FBQ3hDLElBQUksQ0FBQyxTQUFTLENBQUMsS0FBSyxDQUFDLEdBQUcsR0FBRyxHQUFHLEdBQUcsSUFBSSxDQUFDO0lBQzFDLENBQUM7SUFFTSxRQUFRLENBQUMsUUFBaUI7UUFDN0Isd0RBQXdEO1FBQ3hELElBQUksQ0FBQyxRQUFRLENBQUMsS0FBSyxDQUFDLENBQUM7UUFDckIsSUFBSSxRQUFRLEtBQUssQ0FBQyxJQUFJLE9BQU8sUUFBUSxLQUFLLFdBQVcsRUFBRTtZQUNuRCxJQUFJLENBQUMsU0FBUyxDQUFDLEtBQUssQ0FBQyxRQUFRLEdBQUcsQ0FBQyxVQUFVLENBQUMsYUFBYSxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsR0FBRyxRQUFRLEdBQUcsQ0FBQyxDQUFDLENBQUMsUUFBUSxFQUFFLEdBQUcsSUFBSSxDQUFDO1NBQy9HO1FBQ0QsSUFBSSxVQUFVLEdBQWtDLEtBQUssQ0FBQyxhQUFhLEVBQUUsQ0FBQztRQUN0RSxJQUFJLEtBQUssR0FBVyxVQUFVLENBQUMsYUFBYSxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsQ0FBQztRQUM3RCxJQUFJLE1BQU0sR0FBVyxVQUFVLENBQUMsY0FBYyxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsQ0FBQztRQUMvRCxJQUFJLElBQUksR0FBVyxVQUFVLENBQUMsSUFBSSxHQUFHLENBQUMsVUFBVSxDQUFDLGFBQWEsQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLGFBQWEsQ0FBQyxHQUFHLFVBQVUsQ0FBQyxhQUFhLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxHQUFHLElBQUksQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDO1FBQ3hKLElBQUksR0FBRyxHQUFXLFVBQVUsQ0FBQyxHQUFHLEdBQUcsVUFBVSxDQUFDLGNBQWMsQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLEdBQUcsSUFBSSxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUM7UUFFOUYsSUFBSSxDQUFDLGNBQWMsR0FBRyxJQUFJLENBQUMsaUJBQWlCLENBQUMsSUFBSSxFQUFFLEdBQUcsRUFBRSxLQUFLLEVBQUUsTUFBTSxDQUFDLENBQUM7UUFDdkUsSUFBSSxDQUFDLFNBQVMsQ0FBQyxLQUFLLENBQUMsSUFBSSxHQUFHLElBQUksR0FBRyxJQUFJLENBQUM7UUFDeEMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxLQUFLLENBQUMsR0FBRyxHQUFHLEdBQUcsR0FBRyxJQUFJLENBQUM7SUFDMUMsQ0FBQztJQUVELGdCQUFnQjtJQUNULGFBQWEsQ0FBQyxRQUFpQjtRQUNsQyxJQUFJLENBQUMsUUFBUSxDQUFDLDBCQUEwQixDQUFDLENBQUM7UUFDMUMsSUFBSSxRQUFRLEtBQUssQ0FBQyxJQUFJLE9BQU8sUUFBUSxLQUFLLFdBQVc7WUFBRSxJQUFJLENBQUMsU0FBUyxDQUFDLEtBQUssQ0FBQyxRQUFRLEdBQUcsQ0FBQyxVQUFVLENBQUMsYUFBYSxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsR0FBRyxRQUFRLEdBQUcsQ0FBQyxDQUFDLENBQUMsUUFBUSxFQUFFLEdBQUcsSUFBSSxDQUFDO1FBRW5LLElBQUksVUFBVSxHQUFrQyxLQUFLLENBQUMsYUFBYSxFQUFFLENBQUM7UUFDdEUsSUFBSSxLQUFLLEdBQVcsVUFBVSxDQUFDLGFBQWEsQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLENBQUM7UUFDN0QsSUFBSSxNQUFNLEdBQVcsVUFBVSxDQUFDLGNBQWMsQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLENBQUM7UUFDL0QsSUFBSSxJQUFJLEdBQVcsVUFBVSxDQUFDLElBQUksR0FBRyxVQUFVLENBQUMsYUFBYSxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsYUFBYSxDQUFDLEdBQUcsQ0FBQyxHQUFHLElBQUksQ0FBQyxjQUFjLEdBQUcsSUFBSSxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUM7UUFDakksSUFBSSxHQUFHLEdBQVcsVUFBVSxDQUFDLEdBQUcsR0FBRyxVQUFVLENBQUMsY0FBYyxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsR0FBRyxJQUFJLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQztRQUU5RixJQUFJLENBQUMsY0FBYyxHQUFHLElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxJQUFJLEVBQUUsR0FBRyxFQUFFLEtBQUssRUFBRSxNQUFNLENBQUMsQ0FBQztRQUN2RSxJQUFJLENBQUMsU0FBUyxDQUFDLEtBQUssQ0FBQyxJQUFJLEdBQUcsSUFBSSxHQUFHLElBQUksQ0FBQztRQUN4QyxJQUFJLENBQUMsU0FBUyxDQUFDLEtBQUssQ0FBQyxHQUFHLEdBQUcsR0FBRyxHQUFHLElBQUksQ0FBQztJQUMxQyxDQUFDO0lBRUQsZ0JBQWdCO0lBQ1QsWUFBWSxDQUFDLFFBQWlCO1FBQ2pDLElBQUksQ0FBQyxRQUFRLENBQUMseUJBQXlCLENBQUMsQ0FBQztRQUN6QyxJQUFJLFFBQVEsS0FBSyxDQUFDLElBQUksT0FBTyxRQUFRLEtBQUssV0FBVztZQUFFLElBQUksQ0FBQyxTQUFTLENBQUMsS0FBSyxDQUFDLFFBQVEsR0FBRyxDQUFDLFVBQVUsQ0FBQyxhQUFhLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxHQUFHLFFBQVEsR0FBRyxDQUFDLENBQUMsQ0FBQyxRQUFRLEVBQUUsR0FBRyxJQUFJLENBQUM7UUFFbkssSUFBSSxVQUFVLEdBQWtDLEtBQUssQ0FBQyxhQUFhLEVBQUUsQ0FBQztRQUN0RSxJQUFJLEtBQUssR0FBVyxVQUFVLENBQUMsYUFBYSxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsQ0FBQztRQUM3RCxJQUFJLE1BQU0sR0FBVyxVQUFVLENBQUMsY0FBYyxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsQ0FBQztRQUMvRCxJQUFJLElBQUksR0FBVyxVQUFVLENBQUMsSUFBSSxHQUFHLFVBQVUsQ0FBQyxhQUFhLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxhQUFhLENBQUMsR0FBRyxDQUFDLEdBQUcsVUFBVSxDQUFDLGFBQWEsQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLEdBQUcsSUFBSSxDQUFDLGNBQWMsR0FBRyxJQUFJLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQztRQUM1SyxJQUFJLEdBQUcsR0FBVyxVQUFVLENBQUMsR0FBRyxHQUFHLFVBQVUsQ0FBQyxjQUFjLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxHQUFHLElBQUksQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDO1FBRTlGLElBQUksQ0FBQyxjQUFjLEdBQUcsSUFBSSxDQUFDLGlCQUFpQixDQUFDLElBQUksRUFBRSxHQUFHLEVBQUUsS0FBSyxFQUFFLE1BQU0sQ0FBQyxDQUFDO1FBQ3ZFLElBQUksQ0FBQyxTQUFTLENBQUMsS0FBSyxDQUFDLElBQUksR0FBRyxJQUFJLEdBQUcsSUFBSSxDQUFDO1FBQ3hDLElBQUksQ0FBQyxTQUFTLENBQUMsS0FBSyxDQUFDLEdBQUcsR0FBRyxHQUFHLEdBQUcsSUFBSSxDQUFDO0lBQzFDLENBQUM7SUFHTSxXQUFXLENBQUMsUUFBaUI7UUFDaEMsd0RBQXdEO1FBQ3hELElBQUksQ0FBQyxRQUFRLENBQUMsUUFBUSxDQUFDLENBQUM7UUFDeEIsSUFBSSxRQUFRLEtBQUssQ0FBQyxJQUFJLE9BQU8sUUFBUSxLQUFLLFdBQVc7WUFBRSxJQUFJLENBQUMsU0FBUyxDQUFDLEtBQUssQ0FBQyxRQUFRLEdBQUcsQ0FBQyxVQUFVLENBQUMsYUFBYSxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsR0FBRyxRQUFRLEdBQUcsQ0FBQyxDQUFDLENBQUMsUUFBUSxFQUFFLEdBQUcsSUFBSSxDQUFDO1FBRW5LLElBQUksVUFBVSxHQUFrQyxLQUFLLENBQUMsYUFBYSxFQUFFLENBQUM7UUFDdEUsSUFBSSxLQUFLLEdBQVcsVUFBVSxDQUFDLGFBQWEsQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLENBQUM7UUFDN0QsSUFBSSxNQUFNLEdBQVcsVUFBVSxDQUFDLGNBQWMsQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLENBQUM7UUFDL0QsSUFBSSxJQUFJLEdBQVcsVUFBVSxDQUFDLElBQUksR0FBRyxDQUFDLFVBQVUsQ0FBQyxhQUFhLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxhQUFhLENBQUMsR0FBRyxVQUFVLENBQUMsYUFBYSxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsQ0FBQyxHQUFHLENBQUMsR0FBRyxJQUFJLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQztRQUN4SixJQUFJLEdBQUcsR0FBVyxVQUFVLENBQUMsR0FBRyxHQUFHLFVBQVUsQ0FBQyxjQUFjLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxhQUFhLENBQUMsR0FBRyxJQUFJLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQztRQUV0RyxJQUFJLENBQUMsY0FBYyxHQUFHLElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxJQUFJLEVBQUUsR0FBRyxFQUFFLEtBQUssRUFBRSxNQUFNLENBQUMsQ0FBQztRQUN2RSxJQUFJLENBQUMsU0FBUyxDQUFDLEtBQUssQ0FBQyxJQUFJLEdBQUcsSUFBSSxHQUFHLElBQUksQ0FBQztRQUN4QyxJQUFJLENBQUMsU0FBUyxDQUFDLEtBQUssQ0FBQyxHQUFHLEdBQUcsR0FBRyxHQUFHLElBQUksQ0FBQztJQUMxQyxDQUFDO0lBRUQsZ0JBQWdCO0lBQ1QsZ0JBQWdCLENBQUMsUUFBaUI7UUFDckMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxnQ0FBZ0MsQ0FBQyxDQUFDO1FBQ2hELElBQUksUUFBUSxLQUFLLENBQUMsSUFBSSxPQUFPLFFBQVEsS0FBSyxXQUFXO1lBQUUsSUFBSSxDQUFDLFNBQVMsQ0FBQyxLQUFLLENBQUMsUUFBUSxHQUFHLENBQUMsVUFBVSxDQUFDLGFBQWEsQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLEdBQUcsUUFBUSxHQUFHLENBQUMsQ0FBQyxDQUFDLFFBQVEsRUFBRSxHQUFHLElBQUksQ0FBQztRQUVuSyxJQUFJLFVBQVUsR0FBa0MsS0FBSyxDQUFDLGFBQWEsRUFBRSxDQUFDO1FBQ3RFLElBQUksS0FBSyxHQUFXLFVBQVUsQ0FBQyxhQUFhLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDO1FBQzdELElBQUksTUFBTSxHQUFXLFVBQVUsQ0FBQyxjQUFjLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDO1FBQy9ELElBQUksSUFBSSxHQUFXLFVBQVUsQ0FBQyxJQUFJLEdBQUcsVUFBVSxDQUFDLGFBQWEsQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLGFBQWEsQ0FBQyxHQUFHLENBQUMsR0FBRyxJQUFJLENBQUMsY0FBYyxHQUFHLElBQUksQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDO1FBQ2pJLElBQUksR0FBRyxHQUFXLFVBQVUsQ0FBQyxHQUFHLEdBQUcsVUFBVSxDQUFDLGNBQWMsQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLGFBQWEsQ0FBQyxHQUFHLElBQUksQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDO1FBRXRHLElBQUksQ0FBQyxjQUFjLEdBQUcsSUFBSSxDQUFDLGlCQUFpQixDQUFDLElBQUksRUFBRSxHQUFHLEVBQUUsS0FBSyxFQUFFLE1BQU0sQ0FBQyxDQUFDO1FBQ3ZFLElBQUksQ0FBQyxTQUFTLENBQUMsS0FBSyxDQUFDLElBQUksR0FBRyxJQUFJLEdBQUcsSUFBSSxDQUFDO1FBQ3hDLElBQUksQ0FBQyxTQUFTLENBQUMsS0FBSyxDQUFDLEdBQUcsR0FBRyxHQUFHLEdBQUcsSUFBSSxDQUFDO0lBQzFDLENBQUM7SUFFRCxnQkFBZ0I7SUFDVCxlQUFlLENBQUMsUUFBaUI7UUFDcEMsSUFBSSxDQUFDLFFBQVEsQ0FBQywrQkFBK0IsQ0FBQyxDQUFDO1FBQy9DLElBQUksUUFBUSxLQUFLLENBQUMsSUFBSSxPQUFPLFFBQVEsS0FBSyxXQUFXO1lBQUUsSUFBSSxDQUFDLFNBQVMsQ0FBQyxLQUFLLENBQUMsUUFBUSxHQUFHLENBQUMsVUFBVSxDQUFDLGFBQWEsQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLEdBQUcsUUFBUSxHQUFHLENBQUMsQ0FBQyxDQUFDLFFBQVEsRUFBRSxHQUFHLElBQUksQ0FBQztRQUVuSyxJQUFJLFVBQVUsR0FBa0MsS0FBSyxDQUFDLGFBQWEsRUFBRSxDQUFDO1FBQ3RFLElBQUksS0FBSyxHQUFXLFVBQVUsQ0FBQyxhQUFhLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDO1FBQzdELElBQUksTUFBTSxHQUFXLFVBQVUsQ0FBQyxjQUFjLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDO1FBQy9ELElBQUksSUFBSSxHQUFXLFVBQVUsQ0FBQyxJQUFJLEdBQUcsVUFBVSxDQUFDLGFBQWEsQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLGFBQWEsQ0FBQyxHQUFHLENBQUMsR0FBRyxVQUFVLENBQUMsYUFBYSxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsR0FBRyxJQUFJLENBQUMsY0FBYyxHQUFHLElBQUksQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDO1FBQzVLLElBQUksR0FBRyxHQUFXLFVBQVUsQ0FBQyxHQUFHLEdBQUcsVUFBVSxDQUFDLGNBQWMsQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLGFBQWEsQ0FBQyxHQUFHLElBQUksQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDO1FBRXRHLElBQUksQ0FBQyxjQUFjLEdBQUcsSUFBSSxDQUFDLGlCQUFpQixDQUFDLElBQUksRUFBRSxHQUFHLEVBQUUsS0FBSyxFQUFFLE1BQU0sQ0FBQyxDQUFDO1FBQ3ZFLElBQUksQ0FBQyxTQUFTLENBQUMsS0FBSyxDQUFDLElBQUksR0FBRyxJQUFJLEdBQUcsSUFBSSxDQUFDO1FBQ3hDLElBQUksQ0FBQyxTQUFTLENBQUMsS0FBSyxDQUFDLEdBQUcsR0FBRyxHQUFHLEdBQUcsSUFBSSxDQUFDO0lBQzFDLENBQUM7SUFFTSxRQUFRLENBQUMsU0FBa0I7UUFDOUIsSUFBSSxDQUFDLFNBQVMsQ0FBQyxLQUFLLENBQUMsSUFBSSxHQUFHLENBQUMsR0FBRyxHQUFHLElBQUksQ0FBQztRQUN4QyxJQUFJLENBQUMsU0FBUyxDQUFDLEtBQUssQ0FBQyxHQUFHLEdBQUcsQ0FBQyxHQUFHLEdBQUcsSUFBSSxDQUFDO1FBRXZDLHlEQUF5RDtRQUN6RCxJQUFJLGdCQUFnQixHQUFXLGtDQUFrQyxHQUFHLFNBQVMsQ0FBQztRQUM5RSxJQUFJLENBQUMsU0FBUyxDQUFDLFNBQVMsR0FBRyxJQUFJLENBQUMsaUJBQWlCLENBQUMsQ0FBQyxDQUFDLGdCQUFnQixHQUFHLEdBQUcsR0FBRyxJQUFJLENBQUMsaUJBQWlCLENBQUMsQ0FBQyxDQUFDLGdCQUFnQixDQUFDO0lBQzNILENBQUM7SUFFRCw2RkFBNkY7SUFDckYsaUJBQWlCLENBQUMsS0FBYSxFQUFFLElBQVksRUFBRSxNQUFjLEVBQUUsT0FBZTtRQUNsRixJQUFJLFFBQVEsR0FBRyxVQUFVLENBQUMsV0FBVyxFQUFFLENBQUM7UUFDeEMsT0FBTyxDQUFDLEtBQUssR0FBRyxNQUFNLEdBQUcsUUFBUSxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsS0FBSyxHQUFHLENBQUMsQ0FBQyxJQUFJLENBQUMsSUFBSSxHQUFHLENBQUMsQ0FBQyxJQUFJLENBQUMsSUFBSSxHQUFHLE9BQU8sR0FBRyxRQUFRLENBQUMsTUFBTSxDQUFDLENBQUM7SUFDaEgsQ0FBQztJQUVNLE1BQU07UUFDVCxJQUFJLENBQUMsSUFBSSxDQUFDLHVCQUF1QixFQUFFO1lBQy9CLHFEQUFxRDtZQUNyRCxJQUFJLElBQUksQ0FBQyxTQUFTO2dCQUFFLElBQUksQ0FBQyxnQ0FBZ0MsRUFBRSxDQUFDO1NBQy9EO1FBQ0QsSUFBSSxJQUFJLENBQUMsU0FBUyxJQUFJLElBQUksQ0FBQyxTQUFTLENBQUMsYUFBYSxFQUFFO1lBQ2hELElBQUksSUFBSSxDQUFDLFFBQVEsS0FBSyxNQUFNLEVBQUU7Z0JBQzFCLFFBQVEsQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsQ0FBQzthQUM3QztpQkFBTSxJQUFJLElBQUksQ0FBQyxRQUFRLEtBQUssUUFBUSxFQUFFO2dCQUNuQyxJQUFJLENBQUMsR0FBRyxDQUFDLGFBQWEsQ0FBQyxXQUFXLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDO2FBQ3REO2lCQUFNO2dCQUNILFVBQVUsQ0FBQyxXQUFXLENBQUMsSUFBSSxDQUFDLFNBQVMsRUFBRSxJQUFJLENBQUMsUUFBUSxDQUFDLENBQUM7YUFDekQ7U0FDSjtRQUNELElBQUksQ0FBQyxTQUFTLEdBQUcsSUFBSSxDQUFDO0lBQzFCLENBQUM7SUFFRCxrQ0FBa0M7SUFDMUIsUUFBUTtRQUNaLElBQUksT0FBTyxJQUFJLENBQUMsR0FBRyxLQUFLLFdBQVcsRUFBRTtZQUNqQyxJQUFJLENBQUMsR0FBRyxDQUFDLFdBQVcsR0FBRyxHQUFTLEVBQUUsQ0FBQyxLQUFLLENBQUMsUUFBUSxFQUFFLENBQUM7WUFDcEQsSUFBSSxDQUFDLEdBQUcsQ0FBQyxXQUFXLEdBQUcsR0FBUyxFQUFFLENBQUMsS0FBSyxDQUFDLFVBQVUsRUFBRSxDQUFDO1lBQ3RELElBQUksQ0FBQyxHQUFHLENBQUMsc0JBQXNCLEdBQUcsR0FBUyxFQUFFLEdBQUcsSUFBSSxDQUFDLHVCQUF1QixHQUFHLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQztZQUN2RixJQUFJLENBQUMsR0FBRyxDQUFDLG9CQUFvQixHQUFHLEdBQVMsRUFBRSxHQUFHLElBQUksQ0FBQyx1QkFBdUIsR0FBRyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUM7WUFDdEYsSUFBSSxDQUFDLEdBQUcsQ0FBQyxLQUFLLEdBQUcsR0FBUyxFQUFFO2dCQUN4QixJQUFJLENBQUMsSUFBSSxDQUFDLFNBQVM7b0JBQUUsT0FBTztnQkFDNUIsSUFBSSxDQUFDLEtBQUssRUFBRSxDQUFDO1lBQ2pCLENBQUMsQ0FBQztZQUNGLElBQUksQ0FBQyxHQUFHLENBQUMsU0FBUyxHQUFHLENBQUMsT0FBaUMsRUFBUSxFQUFFLEdBQUcsSUFBSSxDQUFDLE9BQU8sR0FBRyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUM7U0FDakc7SUFDTCxDQUFDO0lBRU8sa0JBQWtCO1FBQ3RCLElBQUksTUFBTSxHQUFlLElBQUksQ0FBQyxTQUFTLENBQUMscUJBQXFCLEVBQUUsQ0FBQztRQUNoRSxJQUFJLFVBQVUsR0FBVyxNQUFNLENBQUMsSUFBSSxDQUFDO1FBQ3JDLElBQUksS0FBSyxHQUFXLFVBQVUsQ0FBQyxhQUFhLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDO1FBQzdELElBQUksUUFBUSxHQUFRLFVBQVUsQ0FBQyxXQUFXLEVBQUUsQ0FBQztRQUU3QyxJQUFJLFVBQVUsR0FBRyxLQUFLLEdBQUcsUUFBUSxDQUFDLEtBQUssR0FBRyxDQUFDO1lBQUUsT0FBTyxVQUFVLEdBQUcsS0FBSyxHQUFHLFFBQVEsQ0FBQyxLQUFLLENBQUM7UUFDeEYsSUFBSSxVQUFVLEdBQUcsQ0FBQztZQUFFLE9BQU8sVUFBVSxHQUFHLENBQUMsQ0FBQyxDQUFDO1FBRTNDLE9BQU8sQ0FBQyxDQUFDO0lBQ2IsQ0FBQztJQUVPLCtCQUErQjtRQUNuQyxJQUFJLENBQUMsMkJBQTJCLEdBQUcsSUFBSSxDQUFDLFNBQVMsQ0FBQyxNQUFNLENBQ3BELFVBQVUsRUFDVixZQUFZLEVBQ1osS0FBSyxDQUFDLEVBQUU7WUFDSixLQUFLLENBQUMsSUFBSSxFQUFFLENBQUM7UUFDakIsQ0FBQyxDQUNKLENBQUM7SUFDTixDQUFDO0lBRU8sZ0NBQWdDO1FBQ3BDLElBQUksSUFBSSxDQUFDLDJCQUEyQixFQUFFO1lBQ2xDLElBQUksQ0FBQywyQkFBMkIsRUFBRSxDQUFDO1lBQ25DLElBQUksQ0FBQywyQkFBMkIsR0FBRyxJQUFJLENBQUM7U0FDM0M7SUFDTCxDQUFDO0lBRUQsV0FBVztRQUNQLHdCQUF3QjtRQUN4QixJQUFJLENBQUMsTUFBTSxFQUFFLENBQUM7UUFDZCwrQkFBK0I7UUFDL0IsSUFBSSxDQUFDLFlBQVksQ0FBQyxXQUFXLEVBQUUsQ0FBQztRQUNoQyxJQUFJLENBQUMsY0FBYyxDQUFDLFdBQVcsRUFBRSxDQUFDO0lBQ3RDLENBQUM7OztZQXJkSixTQUFTLFNBQUM7Z0JBQ1AsUUFBUSxFQUFFLGtCQUFrQjtnQkFDNUIsU0FBUyxFQUFFLENBQUMsVUFBVSxFQUFFLFlBQVksRUFBRSxlQUFlLENBQUM7YUFDekQ7OztZQXpCRyxVQUFVO1lBS1YsTUFBTTtZQUdGLFVBQVU7WUFKZCxTQUFTO1lBR0osWUFBWTtZQUdaLGVBQWU7OztrQkE2Qm5CLEtBQUs7bUJBOERMLEtBQUssU0FBQyxnQkFBZ0IiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQge1xyXG4gICAgRGlyZWN0aXZlLFxyXG4gICAgRWxlbWVudFJlZixcclxuICAgIE9uSW5pdCxcclxuICAgIE9uRGVzdHJveSxcclxuICAgIElucHV0LFxyXG4gICAgUmVuZGVyZXIyLFxyXG4gICAgTmdab25lLFxyXG59IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xyXG5pbXBvcnQgeyBLZERvbUVsZW1TdmMgfSBmcm9tICcuLi9rZC1jb21tb24vaW5kZXgnO1xyXG5pbXBvcnQge0RvbUhhbmRsZXJ9IGZyb20gJ3ByaW1lbmcvZG9tJztcclxuaW1wb3J0IHsgVG9vbHRpcCB9IGZyb20gJ3ByaW1lbmcvdG9vbHRpcCc7XHJcbmltcG9ydCB7IEtkU3BsaXR0ZXJFdmVudCB9IGZyb20gJy4uL2tkLWFuZ3VsYXItc3BsaXR0ZXIvaW5kZXgnO1xyXG5pbXBvcnQgeyBTdWJzY3JpcHRpb24gfSBmcm9tICdyeGpzJztcclxuXHJcbmV4cG9ydCBpbnRlcmZhY2UgSVRvb2x0aXBBcGkge1xyXG4gICAgc2hvd1Rvb2x0aXA/OiAoKSA9PiB2b2lkO1xyXG4gICAgaGlkZVRvb2x0aXA/OiAoKSA9PiB2b2lkO1xyXG4gICAgZGVhY3RpdmF0ZUhvc3RMaXN0ZW5lcj86ICgpID0+IHZvaWQ7XHJcbiAgICBhY3RpdmF0ZUhvc3RMaXN0ZW5lcj86ICgpID0+IHZvaWQ7XHJcbiAgICBhbGlnbj86ICgpID0+IHZvaWQ7XHJcbiAgICBzZXRPZmZzZXQ/OiAoX29mZnNldDogeyB4OiBudW1iZXIsIHk6IG51bWJlciB9KSA9PiB2b2lkO1xyXG59XHJcblxyXG5ARGlyZWN0aXZlKHtcclxuICAgIHNlbGVjdG9yOiAnW2tkLXRvb2x0aXAtZGlyXScsXHJcbiAgICBwcm92aWRlcnM6IFtEb21IYW5kbGVyLCBLZERvbUVsZW1TdmMsIEtkU3BsaXR0ZXJFdmVudF0sXHJcbn0pXHJcbmV4cG9ydCBjbGFzcyBLZFRvb2x0aXBEaXJlY3RpdmUgZXh0ZW5kcyBUb29sdGlwIGltcGxlbWVudHMgT25Jbml0LCBPbkRlc3Ryb3kge1xyXG5cclxuICAgIHByaXZhdGUgX2lzTW9iaWxlOiBib29sZWFuO1xyXG4gICAgcHJpdmF0ZSBfd2lkdGhPdXRzaWRlVmlld3BvcnQ6IG51bWJlcjtcclxuICAgIHByaXZhdGUgX2RyYWdNZW51U3ViOiBTdWJzY3JpcHRpb247XHJcbiAgICBwcml2YXRlIF90b2dnbGVNZW51U3ViOiBTdWJzY3JpcHRpb247XHJcbiAgICBwcml2YXRlIF9pc091dE9mQm91bmRzOiBib29sZWFuID0gZmFsc2U7XHJcblxyXG4gICAgcHJpdmF0ZSBfZG9jdW1lbnRUb3VjaFN0YXJ0TGlzdGVuZXI6IGFueTtcclxuICAgIHByaXZhdGUgX2RlYWN0aXZhdGVIb3N0TGlzdGVuZXI6IGJvb2xlYW4gPSBmYWxzZTtcclxuICAgIHByaXZhdGUgX29mZnNldDogeyB4OiBudW1iZXIsIHk6IG51bWJlciB9ID0geyB4OiAwLCB5OiAwIH07XHJcbiAgICBwcml2YXRlIF9kZWZhdWx0T2Zmc2V0OiBudW1iZXIgPSAxMDtcclxuXHJcbiAgICBASW5wdXQoKSBhcGk6IElUb29sdGlwQXBpO1xyXG5cclxuICAgIC8vIGNvbnN0cnVjdG9yIGlzIGZ1bGx5IG5ld1xyXG4gICAgY29uc3RydWN0b3IoXHJcbiAgICAgICAgcHJpdmF0ZSBfZWw6IEVsZW1lbnRSZWYsXHJcbiAgICAgICAgX3pvbmU6IE5nWm9uZSxcclxuICAgICAgICBwcml2YXRlIF9kb21IYW5kbGVyOiBEb21IYW5kbGVyLFxyXG4gICAgICAgIHByaXZhdGUgX3JlbmRlcmVyOiBSZW5kZXJlcjIsXHJcbiAgICAgICAgX2tkRG9tU3ZjOiBLZERvbUVsZW1TdmMsXHJcbiAgICAgICAgX2tkU3BsaXR0ZXJFdmVudDogS2RTcGxpdHRlckV2ZW50LFxyXG4gICAgKSB7XHJcbiAgICAgICAgLy8gc3VwZXIoX2VsLCBfZG9tSGFuZGxlciwgX3pvbmUpO1xyXG4gICAgICAgIHN1cGVyKF9lbCwgX3pvbmUpO1xyXG5cclxuICAgICAgICB0aGlzLl9pc01vYmlsZSA9IF9rZERvbVN2Yy5pc01vYmlsZURldmljZSgpO1xyXG4gICAgICAgIHRoaXMuX2RyYWdNZW51U3ViID0gX2tkU3BsaXR0ZXJFdmVudC5vbkRyYWcoKS5zdWJzY3JpYmUoKCk6IHZvaWQgPT4ge1xyXG4gICAgICAgICAgICBzdXBlci5oaWRlKCk7XHJcbiAgICAgICAgfSk7XHJcbiAgICAgICAgdGhpcy5fdG9nZ2xlTWVudVN1YiA9IF9rZFNwbGl0dGVyRXZlbnQub25Ub2dnbGVNZW51KCkuc3Vic2NyaWJlKCgpOiB2b2lkID0+IHtcclxuICAgICAgICAgICAgc3VwZXIuaGlkZSgpO1xyXG4gICAgICAgIH0pO1xyXG4gICAgfVxyXG5cclxuICAgIG5nT25Jbml0KCk6IHZvaWQge1xyXG4gICAgICAgIHRoaXMuX2luaXRBcGkoKTtcclxuICAgIH1cclxuXHJcbiAgICBvbk1vdXNlRW50ZXIoZTogRXZlbnQpOiB2b2lkIHtcclxuICAgICAgICAvLyBhZGRlZCBleHRyYSBjb25kaXRpb24gIXRoaXMuX2lzTW9iaWxlIHRvIGlmIHN0YXRlbWVudFxyXG4gICAgICAgIGlmICghdGhpcy5faXNNb2JpbGUgJiYgIXRoaXMuX2RlYWN0aXZhdGVIb3N0TGlzdGVuZXIpIHtcclxuICAgICAgICAgICAgaWYgKHRoaXMuaGlkZVRpbWVvdXQpIHtcclxuICAgICAgICAgICAgICAgIGNsZWFyVGltZW91dCh0aGlzLmhpZGVUaW1lb3V0KTtcclxuICAgICAgICAgICAgICAgIHRoaXMucmVtb3ZlKCk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgc3VwZXIuYWN0aXZhdGUoKTtcclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgb25Nb3VzZUxlYXZlKGU6IEV2ZW50KTogdm9pZCB7XHJcbiAgICAgICAgLy8gYWRkZWQgZXh0cmEgY29uZGl0aW9uICF0aGlzLl9pc01vYmlsZSB0byBpZiBzdGF0ZW1lbnRcclxuICAgICAgICBpZiAoIXRoaXMuX2lzTW9iaWxlICYmICF0aGlzLl9kZWFjdGl2YXRlSG9zdExpc3RlbmVyKSB7XHJcbiAgICAgICAgICAgIHN1cGVyLmRlYWN0aXZhdGUoKTtcclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgb25DbGljayhlOiBFdmVudCk6IHZvaWQge1xyXG4gICAgICAgIGlmICghdGhpcy5fZGVhY3RpdmF0ZUhvc3RMaXN0ZW5lcikge1xyXG4gICAgICAgICAgICAvLyB3aGVuIG1vYmlsZSBkZXZpY2UsIGNsaWNrIHdpbGwgYWN0aXZhdGUgdGhlIHRvb2x0aXAuIHdoZW4gd2ViLCBjbGljayB3aWxsIGRlYWN0aXZhdGUgdGhlIHRvb2x0aXBcclxuICAgICAgICAgICAgaWYgKCF0aGlzLl9pc01vYmlsZSkge1xyXG4gICAgICAgICAgICAgICAgc3VwZXIuZGVhY3RpdmF0ZSgpO1xyXG4gICAgICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgaWYgKHRoaXMuaGlkZVRpbWVvdXQpIHtcclxuICAgICAgICAgICAgICAgICAgICBjbGVhclRpbWVvdXQodGhpcy5oaWRlVGltZW91dCk7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5yZW1vdmUoKTtcclxuICAgICAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgICAgICBzdXBlci5hY3RpdmF0ZSgpO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIC8vIGNoYW5nZWQgSW5wdXQgcGFyYW0gdG8gJ2tkLXRvb2x0aXAtZGlyJyAob2xkIGlucHV0IHdhczogcFRvb2x0aXApXHJcbiAgICBASW5wdXQoJ2tkLXRvb2x0aXAtZGlyJykgc2V0IFRleHQodGV4dDogc3RyaW5nKSB7XHJcbiAgICAgICAgdGhpcy5fdGV4dCA9IHRleHQ7XHJcbiAgICAgICAgaWYgKHRoaXMuYWN0aXZlKSB7XHJcbiAgICAgICAgICAgIGlmICh0aGlzLl90ZXh0KSB7XHJcbiAgICAgICAgICAgICAgICBpZiAodGhpcy5jb250YWluZXIgJiYgdGhpcy5jb250YWluZXIub2Zmc2V0UGFyZW50KSB7XHJcbiAgICAgICAgICAgICAgICAgICAgc3VwZXIudXBkYXRlVGV4dCgpO1xyXG4gICAgICAgICAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLnNob3coKTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfSBcclxuICAgICAgICAgICAgZWxzZSB7XHJcbiAgICAgICAgICAgICAgICBzdXBlci5oaWRlKCk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgcHVibGljIHNob3coKTogdm9pZCB7XHJcbiAgICAgICAgaWYgKCF0aGlzLl90ZXh0IHx8IHRoaXMuZGlzYWJsZWQpIHtcclxuICAgICAgICAgICAgcmV0dXJuO1xyXG4gICAgICAgIH1cclxuICAgICAgICBzdXBlci5jcmVhdGUoKTtcclxuICAgICAgICB0aGlzLmFsaWduKCk7XHJcblxyXG4gICAgICAgIERvbUhhbmRsZXIuZmFkZUluKHRoaXMuY29udGFpbmVyLCAyNTApO1xyXG4gICAgICAgIGlmICh0aGlzLnRvb2x0aXBaSW5kZXggPT09ICdhdXRvJykge1xyXG4gICAgICAgICAgICB0aGlzLmNvbnRhaW5lci5zdHlsZS56SW5kZXggPSArK0RvbUhhbmRsZXIuemluZGV4O1xyXG4gICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgIHRoaXMuY29udGFpbmVyLnN0eWxlLnpJbmRleCA9IHRoaXMudG9vbHRpcFpJbmRleDtcclxuICAgICAgICB9XHJcbiAgICAgICAgaWYgKCF0aGlzLl9kZWFjdGl2YXRlSG9zdExpc3RlbmVyKSB7XHJcbiAgICAgICAgICAgIHN1cGVyLmJpbmREb2N1bWVudFJlc2l6ZUxpc3RlbmVyKCk7XHJcbiAgICAgICAgICAgIC8vIGFkZGVkIDEgbGluZS4gX2JpbmREb2N1bWVudFRvdWNoU3RhcnRMaXN0ZW5lcigpXHJcbiAgICAgICAgICAgIGlmICh0aGlzLl9pc01vYmlsZSkgdGhpcy5fYmluZERvY3VtZW50VG91Y2hTdGFydExpc3RlbmVyKCk7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIHB1YmxpYyBhbGlnbigpOiB2b2lkIHtcclxuICAgICAgICBsZXQgcG9zaXRpb246IHN0cmluZyA9IHRoaXMudG9vbHRpcFBvc2l0aW9uO1xyXG4gICAgICAgIHRoaXMuX3dpZHRoT3V0c2lkZVZpZXdwb3J0ID0gbnVsbDtcclxuXHJcbiAgICAgICAgc3dpdGNoIChwb3NpdGlvbikge1xyXG4gICAgICAgICAgICBjYXNlICd0b3AnOlxyXG4gICAgICAgICAgICAgICAgdGhpcy5hbGlnblRvcCgpO1xyXG4gICAgICAgICAgICAgICAgLy8gYWRkZWQgMSBsaW5lLiBfd2lkdGhPdXRzaWRlVmlld3BvcnRcclxuICAgICAgICAgICAgICAgIC8vIHRoaXMuX2lzT3V0b2ZCb3VuZHMgaXMgdXNlZCBpbnN0ZWFkIG9mIHN1cGVyLk91dG9mQm91bmRzXHJcbiAgICAgICAgICAgICAgICBpZiAodGhpcy5faXNPdXRPZkJvdW5kcykge1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuYWxpZ25Ub3BSaWdodCgpO1xyXG5cclxuICAgICAgICAgICAgICAgICAgICBpZiAodGhpcy5faXNPdXRPZkJvdW5kcykge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLmFsaWduVG9wTGVmdCgpO1xyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgaWYgKHRoaXMuX2lzT3V0T2ZCb3VuZHMpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuX3dpZHRoT3V0c2lkZVZpZXdwb3J0ID0gdGhpcy5fY2FsY3VsYXRlV2lkdGhPdXQoKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuYWxpZ25Cb3R0b20odGhpcy5fd2lkdGhPdXRzaWRlVmlld3BvcnQpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgYnJlYWs7XHJcblxyXG4gICAgICAgICAgICBjYXNlICd0b3AtcmlnaHQnOlxyXG4gICAgICAgICAgICAgICAgdGhpcy5hbGlnblRvcFJpZ2h0KCk7XHJcbiAgICAgICAgICAgICAgICAvLyBhZGRlZCAxIGxpbmUuIF93aWR0aE91dHNpZGVWaWV3cG9ydFxyXG4gICAgICAgICAgICAgICAgaWYgKHRoaXMuX2lzT3V0T2ZCb3VuZHMpIHtcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLmFsaWduVG9wKCk7XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIGlmICh0aGlzLl9pc091dE9mQm91bmRzKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuYWxpZ25Ub3BMZWZ0KCk7XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAodGhpcy5faXNPdXRPZkJvdW5kcykge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5fd2lkdGhPdXRzaWRlVmlld3BvcnQgPSB0aGlzLl9jYWxjdWxhdGVXaWR0aE91dCgpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5hbGlnbkJvdHRvbSh0aGlzLl93aWR0aE91dHNpZGVWaWV3cG9ydCk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICBicmVhaztcclxuXHJcbiAgICAgICAgICAgIGNhc2UgJ3RvcC1sZWZ0JzpcclxuICAgICAgICAgICAgICAgIHRoaXMuYWxpZ25Ub3BMZWZ0KCk7XHJcbiAgICAgICAgICAgICAgICAvLyBhZGRlZCAxIGxpbmUuIF93aWR0aE91dHNpZGVWaWV3cG9ydFxyXG4gICAgICAgICAgICAgICAgaWYgKHRoaXMuX2lzT3V0T2ZCb3VuZHMpIHtcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLmFsaWduVG9wKCk7XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIGlmICh0aGlzLl9pc091dE9mQm91bmRzKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuYWxpZ25Ub3BSaWdodCgpO1xyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgaWYgKHRoaXMuX2lzT3V0T2ZCb3VuZHMpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuX3dpZHRoT3V0c2lkZVZpZXdwb3J0ID0gdGhpcy5fY2FsY3VsYXRlV2lkdGhPdXQoKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuYWxpZ25Cb3R0b20odGhpcy5fd2lkdGhPdXRzaWRlVmlld3BvcnQpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgYnJlYWs7XHJcblxyXG4gICAgICAgICAgICBjYXNlICdib3R0b20nOlxyXG4gICAgICAgICAgICAgICAgdGhpcy5hbGlnbkJvdHRvbSgpO1xyXG4gICAgICAgICAgICAgICAgLy8gYWRkZWQgMSBsaW5lLiBfd2lkdGhPdXRzaWRlVmlld3BvcnRcclxuICAgICAgICAgICAgICAgIGlmICh0aGlzLl9pc091dE9mQm91bmRzKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5hbGlnbkJvdHRvbVJpZ2h0KCk7XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIGlmICh0aGlzLl9pc091dE9mQm91bmRzKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuYWxpZ25Cb3R0b21MZWZ0KCk7XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAodGhpcy5faXNPdXRPZkJvdW5kcykge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gYWRkZWQgMSBsaW5lLiBlZGl0ZWQgYWxpZ25Ub3Agd2l0aCBwYXJhbVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5fd2lkdGhPdXRzaWRlVmlld3BvcnQgPSB0aGlzLl9jYWxjdWxhdGVXaWR0aE91dCgpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5hbGlnblRvcCh0aGlzLl93aWR0aE91dHNpZGVWaWV3cG9ydCk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICBicmVhaztcclxuXHJcbiAgICAgICAgICAgIGNhc2UgJ2JvdHRvbS1yaWdodCc6XHJcbiAgICAgICAgICAgICAgICB0aGlzLmFsaWduQm90dG9tUmlnaHQoKTtcclxuICAgICAgICAgICAgICAgIC8vIGFkZGVkIDEgbGluZS4gX3dpZHRoT3V0c2lkZVZpZXdwb3J0XHJcbiAgICAgICAgICAgICAgICBpZiAodGhpcy5faXNPdXRPZkJvdW5kcykge1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuYWxpZ25Cb3R0b20oKTtcclxuXHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKHRoaXMuX2lzT3V0T2ZCb3VuZHMpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5hbGlnbkJvdHRvbUxlZnQoKTtcclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGlmICh0aGlzLl9pc091dE9mQm91bmRzKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyBhZGRlZCAxIGxpbmUuIGVkaXRlZCBhbGlnblRvcCB3aXRoIHBhcmFtXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0aGlzLl93aWR0aE91dHNpZGVWaWV3cG9ydCA9IHRoaXMuX2NhbGN1bGF0ZVdpZHRoT3V0KCk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0aGlzLmFsaWduVG9wKHRoaXMuX3dpZHRoT3V0c2lkZVZpZXdwb3J0KTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIGJyZWFrO1xyXG5cclxuICAgICAgICAgICAgY2FzZSAnYm90dG9tLWxlZnQnOlxyXG4gICAgICAgICAgICAgICAgdGhpcy5hbGlnbkJvdHRvbUxlZnQoKTtcclxuICAgICAgICAgICAgICAgIC8vIGFkZGVkIDEgbGluZS4gX3dpZHRoT3V0c2lkZVZpZXdwb3J0XHJcbiAgICAgICAgICAgICAgICBpZiAodGhpcy5faXNPdXRPZkJvdW5kcykge1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuYWxpZ25Cb3R0b20oKTtcclxuXHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKHRoaXMuX2lzT3V0T2ZCb3VuZHMpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5hbGlnbkJvdHRvbVJpZ2h0KCk7XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAodGhpcy5faXNPdXRPZkJvdW5kcykge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gYWRkZWQgMSBsaW5lLiBlZGl0ZWQgYWxpZ25Ub3Agd2l0aCBwYXJhbVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5fd2lkdGhPdXRzaWRlVmlld3BvcnQgPSB0aGlzLl9jYWxjdWxhdGVXaWR0aE91dCgpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5hbGlnblRvcCh0aGlzLl93aWR0aE91dHNpZGVWaWV3cG9ydCk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICBicmVhaztcclxuXHJcbiAgICAgICAgICAgIGNhc2UgJ2xlZnQnOlxyXG4gICAgICAgICAgICAgICAgdGhpcy5hbGlnbkxlZnQoKTtcclxuICAgICAgICAgICAgICAgIGlmICh0aGlzLl9pc091dE9mQm91bmRzKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5hbGlnblJpZ2h0KCk7XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIGlmICh0aGlzLl9pc091dE9mQm91bmRzKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuYWxpZ25Ub3AoKTtcclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGlmICh0aGlzLl9pc091dE9mQm91bmRzKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyBhZGRlZCAxIGxpbmUuIGVkaXRlZCBhbGlnbkJvdHRvbSB3aXRoIHBhcmFtXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0aGlzLl93aWR0aE91dHNpZGVWaWV3cG9ydCA9IHRoaXMuX2NhbGN1bGF0ZVdpZHRoT3V0KCk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0aGlzLmFsaWduQm90dG9tKHRoaXMuX2NhbGN1bGF0ZVdpZHRoT3V0KCkpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgYnJlYWs7XHJcblxyXG4gICAgICAgICAgICBjYXNlICdyaWdodCc6XHJcbiAgICAgICAgICAgICAgICB0aGlzLmFsaWduUmlnaHQoKTtcclxuICAgICAgICAgICAgICAgIGlmICh0aGlzLl9pc091dE9mQm91bmRzKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5hbGlnbkxlZnQoKTtcclxuXHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKHRoaXMuX2lzT3V0T2ZCb3VuZHMpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5hbGlnblRvcCgpO1xyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgaWYgKHRoaXMuX2lzT3V0T2ZCb3VuZHMpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIGFkZGVkIDEgbGluZS4gZWRpdGVkIGFsaWduQm90dG9tIHdpdGggcGFyYW1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuYWxpZ25Cb3R0b20odGhpcy5fY2FsY3VsYXRlV2lkdGhPdXQoKSk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICBicmVhaztcclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgcHVibGljIGFsaWduUmlnaHQoKSB7XHJcbiAgICAgICAgLy8gYWRkZWQgMSBsaW5lLiBlZGl0ZWQgcHJlQWxpZ24gd2l0aCBwYXJhbVxyXG4gICAgICAgIHRoaXMucHJlQWxpZ24oJ3JpZ2h0Jyk7XHJcbiAgICAgICAgbGV0IGhvc3RPZmZzZXQ6IHsgbGVmdDogbnVtYmVyLCB0b3A6IG51bWJlciB9ID0gc3VwZXIuZ2V0SG9zdE9mZnNldCgpO1xyXG4gICAgICAgIGxldCB3aWR0aDogbnVtYmVyID0gRG9tSGFuZGxlci5nZXRPdXRlcldpZHRoKHRoaXMuY29udGFpbmVyKTtcclxuICAgICAgICBsZXQgaGVpZ2h0OiBudW1iZXIgPSBEb21IYW5kbGVyLmdldE91dGVySGVpZ2h0KHRoaXMuY29udGFpbmVyKTtcclxuICAgICAgICBsZXQgbGVmdDogbnVtYmVyID0gaG9zdE9mZnNldC5sZWZ0ICsgRG9tSGFuZGxlci5nZXRPdXRlcldpZHRoKHRoaXMuX2VsLm5hdGl2ZUVsZW1lbnQpICsgdGhpcy5fb2Zmc2V0Lng7XHJcbiAgICAgICAgbGV0IHRvcDogbnVtYmVyID0gaG9zdE9mZnNldC50b3AgKyAoRG9tSGFuZGxlci5nZXRPdXRlckhlaWdodCh0aGlzLl9lbC5uYXRpdmVFbGVtZW50KSAtIERvbUhhbmRsZXIuZ2V0T3V0ZXJIZWlnaHQodGhpcy5jb250YWluZXIpKSAvIDIgLSAxICsgdGhpcy5fb2Zmc2V0Lnk7XHJcblxyXG4gICAgICAgIHRoaXMuX2lzT3V0T2ZCb3VuZHMgPSB0aGlzLl9jaGVja091dE9mQm91bmRzKGxlZnQsIHRvcCwgd2lkdGgsIGhlaWdodCk7XHJcbiAgICAgICAgdGhpcy5jb250YWluZXIuc3R5bGUubGVmdCA9IGxlZnQgKyAncHgnO1xyXG4gICAgICAgIHRoaXMuY29udGFpbmVyLnN0eWxlLnRvcCA9IHRvcCArICdweCc7XHJcbiAgICB9XHJcblxyXG4gICAgcHVibGljIGFsaWduTGVmdCgpIHtcclxuICAgICAgICAvLyBhZGRlZCAxIGxpbmUuIGVkaXRlZCBwcmVBbGlnbiB3aXRoIHBhcmFtXHJcbiAgICAgICAgdGhpcy5wcmVBbGlnbignbGVmdCcpO1xyXG4gICAgICAgIGxldCBob3N0T2Zmc2V0OiB7IGxlZnQ6IG51bWJlciwgdG9wOiBudW1iZXIgfSA9IHN1cGVyLmdldEhvc3RPZmZzZXQoKTtcclxuICAgICAgICBsZXQgd2lkdGg6IG51bWJlciA9IERvbUhhbmRsZXIuZ2V0T3V0ZXJXaWR0aCh0aGlzLmNvbnRhaW5lcik7XHJcbiAgICAgICAgbGV0IGhlaWdodDogbnVtYmVyID0gRG9tSGFuZGxlci5nZXRPdXRlckhlaWdodCh0aGlzLmNvbnRhaW5lcik7XHJcbiAgICAgICAgbGV0IGxlZnQ6IG51bWJlciA9IGhvc3RPZmZzZXQubGVmdCAtIERvbUhhbmRsZXIuZ2V0T3V0ZXJXaWR0aCh0aGlzLmNvbnRhaW5lcikgKyB0aGlzLl9vZmZzZXQueDtcclxuICAgICAgICBsZXQgdG9wOiBudW1iZXIgPSBob3N0T2Zmc2V0LnRvcCArIChEb21IYW5kbGVyLmdldE91dGVySGVpZ2h0KHRoaXMuX2VsLm5hdGl2ZUVsZW1lbnQpIC0gRG9tSGFuZGxlci5nZXRPdXRlckhlaWdodCh0aGlzLmNvbnRhaW5lcikpIC8gMiArIHRoaXMuX29mZnNldC55O1xyXG5cclxuICAgICAgICB0aGlzLl9pc091dE9mQm91bmRzID0gdGhpcy5fY2hlY2tPdXRPZkJvdW5kcyhsZWZ0LCB0b3AsIHdpZHRoLCBoZWlnaHQpO1xyXG4gICAgICAgIHRoaXMuY29udGFpbmVyLnN0eWxlLmxlZnQgPSBsZWZ0ICsgJ3B4JztcclxuICAgICAgICB0aGlzLmNvbnRhaW5lci5zdHlsZS50b3AgPSB0b3AgKyAncHgnO1xyXG4gICAgfVxyXG5cclxuICAgIHB1YmxpYyBhbGlnblRvcCh3aWR0aE91dD86IG51bWJlcik6IHZvaWQge1xyXG4gICAgICAgIC8vIGFkZGVkIDIgbGluZS4gZWRpdGVkIHByZUFsaWduIHdpdGggcGFyYW0gYW5kIHdpZHRoT3V0XHJcbiAgICAgICAgdGhpcy5wcmVBbGlnbigndG9wJyk7XHJcbiAgICAgICAgaWYgKHdpZHRoT3V0ICE9PSAwICYmIHR5cGVvZiB3aWR0aE91dCAhPT0gJ3VuZGVmaW5lZCcpIHtcclxuICAgICAgICAgICAgdGhpcy5jb250YWluZXIuc3R5bGUubWF4V2lkdGggPSAoRG9tSGFuZGxlci5nZXRPdXRlcldpZHRoKHRoaXMuY29udGFpbmVyKSAtIHdpZHRoT3V0ICogMikudG9TdHJpbmcoKSArICdweCc7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGxldCBob3N0T2Zmc2V0OiB7IGxlZnQ6IG51bWJlciwgdG9wOiBudW1iZXIgfSA9IHN1cGVyLmdldEhvc3RPZmZzZXQoKTtcclxuICAgICAgICBsZXQgd2lkdGg6IG51bWJlciA9IERvbUhhbmRsZXIuZ2V0T3V0ZXJXaWR0aCh0aGlzLmNvbnRhaW5lcik7XHJcbiAgICAgICAgbGV0IGhlaWdodDogbnVtYmVyID0gRG9tSGFuZGxlci5nZXRPdXRlckhlaWdodCh0aGlzLmNvbnRhaW5lcik7XHJcbiAgICAgICAgbGV0IGxlZnQ6IG51bWJlciA9IGhvc3RPZmZzZXQubGVmdCArIChEb21IYW5kbGVyLmdldE91dGVyV2lkdGgodGhpcy5fZWwubmF0aXZlRWxlbWVudCkgLSBEb21IYW5kbGVyLmdldE91dGVyV2lkdGgodGhpcy5jb250YWluZXIpKSAvIDIgKyB0aGlzLl9vZmZzZXQueDtcclxuICAgICAgICBsZXQgdG9wOiBudW1iZXIgPSBob3N0T2Zmc2V0LnRvcCAtIERvbUhhbmRsZXIuZ2V0T3V0ZXJIZWlnaHQodGhpcy5jb250YWluZXIpICsgdGhpcy5fb2Zmc2V0Lnk7XHJcblxyXG4gICAgICAgIHRoaXMuX2lzT3V0T2ZCb3VuZHMgPSB0aGlzLl9jaGVja091dE9mQm91bmRzKGxlZnQsIHRvcCwgd2lkdGgsIGhlaWdodCk7XHJcbiAgICAgICAgdGhpcy5jb250YWluZXIuc3R5bGUubGVmdCA9IGxlZnQgKyAncHgnO1xyXG4gICAgICAgIHRoaXMuY29udGFpbmVyLnN0eWxlLnRvcCA9IHRvcCArICdweCc7XHJcbiAgICB9XHJcblxyXG4gICAgLy8gbmV3IGRpcmVjdGlvblxyXG4gICAgcHVibGljIGFsaWduVG9wUmlnaHQod2lkdGhPdXQ/OiBudW1iZXIpOiB2b2lkIHtcclxuICAgICAgICB0aGlzLnByZUFsaWduKCd0b3AgdWktdG9vbHRpcC10b3AtcmlnaHQnKTtcclxuICAgICAgICBpZiAod2lkdGhPdXQgIT09IDAgJiYgdHlwZW9mIHdpZHRoT3V0ICE9PSAndW5kZWZpbmVkJykgdGhpcy5jb250YWluZXIuc3R5bGUubWF4V2lkdGggPSAoRG9tSGFuZGxlci5nZXRPdXRlcldpZHRoKHRoaXMuY29udGFpbmVyKSAtIHdpZHRoT3V0ICogMikudG9TdHJpbmcoKSArICdweCc7XHJcblxyXG4gICAgICAgIGxldCBob3N0T2Zmc2V0OiB7IGxlZnQ6IG51bWJlciwgdG9wOiBudW1iZXIgfSA9IHN1cGVyLmdldEhvc3RPZmZzZXQoKTtcclxuICAgICAgICBsZXQgd2lkdGg6IG51bWJlciA9IERvbUhhbmRsZXIuZ2V0T3V0ZXJXaWR0aCh0aGlzLmNvbnRhaW5lcik7XHJcbiAgICAgICAgbGV0IGhlaWdodDogbnVtYmVyID0gRG9tSGFuZGxlci5nZXRPdXRlckhlaWdodCh0aGlzLmNvbnRhaW5lcik7XHJcbiAgICAgICAgbGV0IGxlZnQ6IG51bWJlciA9IGhvc3RPZmZzZXQubGVmdCArIERvbUhhbmRsZXIuZ2V0T3V0ZXJXaWR0aCh0aGlzLl9lbC5uYXRpdmVFbGVtZW50KSAvIDIgLSB0aGlzLl9kZWZhdWx0T2Zmc2V0ICsgdGhpcy5fb2Zmc2V0Lng7XHJcbiAgICAgICAgbGV0IHRvcDogbnVtYmVyID0gaG9zdE9mZnNldC50b3AgLSBEb21IYW5kbGVyLmdldE91dGVySGVpZ2h0KHRoaXMuY29udGFpbmVyKSArIHRoaXMuX29mZnNldC55O1xyXG5cclxuICAgICAgICB0aGlzLl9pc091dE9mQm91bmRzID0gdGhpcy5fY2hlY2tPdXRPZkJvdW5kcyhsZWZ0LCB0b3AsIHdpZHRoLCBoZWlnaHQpO1xyXG4gICAgICAgIHRoaXMuY29udGFpbmVyLnN0eWxlLmxlZnQgPSBsZWZ0ICsgJ3B4JztcclxuICAgICAgICB0aGlzLmNvbnRhaW5lci5zdHlsZS50b3AgPSB0b3AgKyAncHgnO1xyXG4gICAgfVxyXG5cclxuICAgIC8vIG5ldyBkaXJlY3Rpb25cclxuICAgIHB1YmxpYyBhbGlnblRvcExlZnQod2lkdGhPdXQ/OiBudW1iZXIpOiB2b2lkIHtcclxuICAgICAgICB0aGlzLnByZUFsaWduKCd0b3AgdWktdG9vbHRpcC10b3AtbGVmdCcpO1xyXG4gICAgICAgIGlmICh3aWR0aE91dCAhPT0gMCAmJiB0eXBlb2Ygd2lkdGhPdXQgIT09ICd1bmRlZmluZWQnKSB0aGlzLmNvbnRhaW5lci5zdHlsZS5tYXhXaWR0aCA9IChEb21IYW5kbGVyLmdldE91dGVyV2lkdGgodGhpcy5jb250YWluZXIpIC0gd2lkdGhPdXQgKiAyKS50b1N0cmluZygpICsgJ3B4JztcclxuXHJcbiAgICAgICAgbGV0IGhvc3RPZmZzZXQ6IHsgbGVmdDogbnVtYmVyLCB0b3A6IG51bWJlciB9ID0gc3VwZXIuZ2V0SG9zdE9mZnNldCgpO1xyXG4gICAgICAgIGxldCB3aWR0aDogbnVtYmVyID0gRG9tSGFuZGxlci5nZXRPdXRlcldpZHRoKHRoaXMuY29udGFpbmVyKTtcclxuICAgICAgICBsZXQgaGVpZ2h0OiBudW1iZXIgPSBEb21IYW5kbGVyLmdldE91dGVySGVpZ2h0KHRoaXMuY29udGFpbmVyKTtcclxuICAgICAgICBsZXQgbGVmdDogbnVtYmVyID0gaG9zdE9mZnNldC5sZWZ0ICsgRG9tSGFuZGxlci5nZXRPdXRlcldpZHRoKHRoaXMuX2VsLm5hdGl2ZUVsZW1lbnQpIC8gMiAtIERvbUhhbmRsZXIuZ2V0T3V0ZXJXaWR0aCh0aGlzLmNvbnRhaW5lcikgKyB0aGlzLl9kZWZhdWx0T2Zmc2V0ICsgdGhpcy5fb2Zmc2V0Lng7XHJcbiAgICAgICAgbGV0IHRvcDogbnVtYmVyID0gaG9zdE9mZnNldC50b3AgLSBEb21IYW5kbGVyLmdldE91dGVySGVpZ2h0KHRoaXMuY29udGFpbmVyKSArIHRoaXMuX29mZnNldC55O1xyXG5cclxuICAgICAgICB0aGlzLl9pc091dE9mQm91bmRzID0gdGhpcy5fY2hlY2tPdXRPZkJvdW5kcyhsZWZ0LCB0b3AsIHdpZHRoLCBoZWlnaHQpO1xyXG4gICAgICAgIHRoaXMuY29udGFpbmVyLnN0eWxlLmxlZnQgPSBsZWZ0ICsgJ3B4JztcclxuICAgICAgICB0aGlzLmNvbnRhaW5lci5zdHlsZS50b3AgPSB0b3AgKyAncHgnO1xyXG4gICAgfVxyXG5cclxuXHJcbiAgICBwdWJsaWMgYWxpZ25Cb3R0b20od2lkdGhPdXQ/OiBudW1iZXIpOiB2b2lkIHtcclxuICAgICAgICAvLyBhZGRlZCAyIGxpbmUuIGVkaXRlZCBwcmVBbGlnbiB3aXRoIHBhcmFtIGFuZCB3aWR0aE91dFxyXG4gICAgICAgIHRoaXMucHJlQWxpZ24oJ2JvdHRvbScpO1xyXG4gICAgICAgIGlmICh3aWR0aE91dCAhPT0gMCAmJiB0eXBlb2Ygd2lkdGhPdXQgIT09ICd1bmRlZmluZWQnKSB0aGlzLmNvbnRhaW5lci5zdHlsZS5tYXhXaWR0aCA9IChEb21IYW5kbGVyLmdldE91dGVyV2lkdGgodGhpcy5jb250YWluZXIpIC0gd2lkdGhPdXQgKiAyKS50b1N0cmluZygpICsgJ3B4JztcclxuXHJcbiAgICAgICAgbGV0IGhvc3RPZmZzZXQ6IHsgbGVmdDogbnVtYmVyLCB0b3A6IG51bWJlciB9ID0gc3VwZXIuZ2V0SG9zdE9mZnNldCgpO1xyXG4gICAgICAgIGxldCB3aWR0aDogbnVtYmVyID0gRG9tSGFuZGxlci5nZXRPdXRlcldpZHRoKHRoaXMuY29udGFpbmVyKTtcclxuICAgICAgICBsZXQgaGVpZ2h0OiBudW1iZXIgPSBEb21IYW5kbGVyLmdldE91dGVySGVpZ2h0KHRoaXMuY29udGFpbmVyKTtcclxuICAgICAgICBsZXQgbGVmdDogbnVtYmVyID0gaG9zdE9mZnNldC5sZWZ0ICsgKERvbUhhbmRsZXIuZ2V0T3V0ZXJXaWR0aCh0aGlzLl9lbC5uYXRpdmVFbGVtZW50KSAtIERvbUhhbmRsZXIuZ2V0T3V0ZXJXaWR0aCh0aGlzLmNvbnRhaW5lcikpIC8gMiArIHRoaXMuX29mZnNldC54O1xyXG4gICAgICAgIGxldCB0b3A6IG51bWJlciA9IGhvc3RPZmZzZXQudG9wICsgRG9tSGFuZGxlci5nZXRPdXRlckhlaWdodCh0aGlzLl9lbC5uYXRpdmVFbGVtZW50KSArIHRoaXMuX29mZnNldC55O1xyXG5cclxuICAgICAgICB0aGlzLl9pc091dE9mQm91bmRzID0gdGhpcy5fY2hlY2tPdXRPZkJvdW5kcyhsZWZ0LCB0b3AsIHdpZHRoLCBoZWlnaHQpO1xyXG4gICAgICAgIHRoaXMuY29udGFpbmVyLnN0eWxlLmxlZnQgPSBsZWZ0ICsgJ3B4JztcclxuICAgICAgICB0aGlzLmNvbnRhaW5lci5zdHlsZS50b3AgPSB0b3AgKyAncHgnO1xyXG4gICAgfVxyXG5cclxuICAgIC8vIG5ldyBkaXJlY3Rpb25cclxuICAgIHB1YmxpYyBhbGlnbkJvdHRvbVJpZ2h0KHdpZHRoT3V0PzogbnVtYmVyKTogdm9pZCB7XHJcbiAgICAgICAgdGhpcy5wcmVBbGlnbignYm90dG9tIHVpLXRvb2x0aXAtYm90dG9tLXJpZ2h0Jyk7XHJcbiAgICAgICAgaWYgKHdpZHRoT3V0ICE9PSAwICYmIHR5cGVvZiB3aWR0aE91dCAhPT0gJ3VuZGVmaW5lZCcpIHRoaXMuY29udGFpbmVyLnN0eWxlLm1heFdpZHRoID0gKERvbUhhbmRsZXIuZ2V0T3V0ZXJXaWR0aCh0aGlzLmNvbnRhaW5lcikgLSB3aWR0aE91dCAqIDIpLnRvU3RyaW5nKCkgKyAncHgnO1xyXG5cclxuICAgICAgICBsZXQgaG9zdE9mZnNldDogeyBsZWZ0OiBudW1iZXIsIHRvcDogbnVtYmVyIH0gPSBzdXBlci5nZXRIb3N0T2Zmc2V0KCk7XHJcbiAgICAgICAgbGV0IHdpZHRoOiBudW1iZXIgPSBEb21IYW5kbGVyLmdldE91dGVyV2lkdGgodGhpcy5jb250YWluZXIpO1xyXG4gICAgICAgIGxldCBoZWlnaHQ6IG51bWJlciA9IERvbUhhbmRsZXIuZ2V0T3V0ZXJIZWlnaHQodGhpcy5jb250YWluZXIpO1xyXG4gICAgICAgIGxldCBsZWZ0OiBudW1iZXIgPSBob3N0T2Zmc2V0LmxlZnQgKyBEb21IYW5kbGVyLmdldE91dGVyV2lkdGgodGhpcy5fZWwubmF0aXZlRWxlbWVudCkgLyAyIC0gdGhpcy5fZGVmYXVsdE9mZnNldCArIHRoaXMuX29mZnNldC54O1xyXG4gICAgICAgIGxldCB0b3A6IG51bWJlciA9IGhvc3RPZmZzZXQudG9wICsgRG9tSGFuZGxlci5nZXRPdXRlckhlaWdodCh0aGlzLl9lbC5uYXRpdmVFbGVtZW50KSArIHRoaXMuX29mZnNldC55O1xyXG5cclxuICAgICAgICB0aGlzLl9pc091dE9mQm91bmRzID0gdGhpcy5fY2hlY2tPdXRPZkJvdW5kcyhsZWZ0LCB0b3AsIHdpZHRoLCBoZWlnaHQpO1xyXG4gICAgICAgIHRoaXMuY29udGFpbmVyLnN0eWxlLmxlZnQgPSBsZWZ0ICsgJ3B4JztcclxuICAgICAgICB0aGlzLmNvbnRhaW5lci5zdHlsZS50b3AgPSB0b3AgKyAncHgnO1xyXG4gICAgfVxyXG5cclxuICAgIC8vIG5ldyBkaXJlY3Rpb25cclxuICAgIHB1YmxpYyBhbGlnbkJvdHRvbUxlZnQod2lkdGhPdXQ/OiBudW1iZXIpOiB2b2lkIHtcclxuICAgICAgICB0aGlzLnByZUFsaWduKCdib3R0b20gdWktdG9vbHRpcC1ib3R0b20tbGVmdCcpO1xyXG4gICAgICAgIGlmICh3aWR0aE91dCAhPT0gMCAmJiB0eXBlb2Ygd2lkdGhPdXQgIT09ICd1bmRlZmluZWQnKSB0aGlzLmNvbnRhaW5lci5zdHlsZS5tYXhXaWR0aCA9IChEb21IYW5kbGVyLmdldE91dGVyV2lkdGgodGhpcy5jb250YWluZXIpIC0gd2lkdGhPdXQgKiAyKS50b1N0cmluZygpICsgJ3B4JztcclxuXHJcbiAgICAgICAgbGV0IGhvc3RPZmZzZXQ6IHsgbGVmdDogbnVtYmVyLCB0b3A6IG51bWJlciB9ID0gc3VwZXIuZ2V0SG9zdE9mZnNldCgpO1xyXG4gICAgICAgIGxldCB3aWR0aDogbnVtYmVyID0gRG9tSGFuZGxlci5nZXRPdXRlcldpZHRoKHRoaXMuY29udGFpbmVyKTtcclxuICAgICAgICBsZXQgaGVpZ2h0OiBudW1iZXIgPSBEb21IYW5kbGVyLmdldE91dGVySGVpZ2h0KHRoaXMuY29udGFpbmVyKTtcclxuICAgICAgICBsZXQgbGVmdDogbnVtYmVyID0gaG9zdE9mZnNldC5sZWZ0ICsgRG9tSGFuZGxlci5nZXRPdXRlcldpZHRoKHRoaXMuX2VsLm5hdGl2ZUVsZW1lbnQpIC8gMiAtIERvbUhhbmRsZXIuZ2V0T3V0ZXJXaWR0aCh0aGlzLmNvbnRhaW5lcikgKyB0aGlzLl9kZWZhdWx0T2Zmc2V0ICsgdGhpcy5fb2Zmc2V0Lng7XHJcbiAgICAgICAgbGV0IHRvcDogbnVtYmVyID0gaG9zdE9mZnNldC50b3AgKyBEb21IYW5kbGVyLmdldE91dGVySGVpZ2h0KHRoaXMuX2VsLm5hdGl2ZUVsZW1lbnQpICsgdGhpcy5fb2Zmc2V0Lnk7XHJcblxyXG4gICAgICAgIHRoaXMuX2lzT3V0T2ZCb3VuZHMgPSB0aGlzLl9jaGVja091dE9mQm91bmRzKGxlZnQsIHRvcCwgd2lkdGgsIGhlaWdodCk7XHJcbiAgICAgICAgdGhpcy5jb250YWluZXIuc3R5bGUubGVmdCA9IGxlZnQgKyAncHgnO1xyXG4gICAgICAgIHRoaXMuY29udGFpbmVyLnN0eWxlLnRvcCA9IHRvcCArICdweCc7XHJcbiAgICB9XHJcblxyXG4gICAgcHVibGljIHByZUFsaWduKF9wb3NpdGlvbj86IHN0cmluZyk6IHZvaWQge1xyXG4gICAgICAgIHRoaXMuY29udGFpbmVyLnN0eWxlLmxlZnQgPSAtOTk5ICsgJ3B4JztcclxuICAgICAgICB0aGlzLmNvbnRhaW5lci5zdHlsZS50b3AgPSAtOTk5ICsgJ3B4JztcclxuXHJcbiAgICAgICAgLy8gYWRkZWQgMiBsaW5lLiBkZWZhdWx0Q2xhc3NOYW1lIGFuZCBjb250YWluZXIuY2xhc3NOYW1lXHJcbiAgICAgICAgbGV0IGRlZmF1bHRDbGFzc05hbWU6IHN0cmluZyA9ICd1aS10b29sdGlwIHVpLXdpZGdldCB1aS10b29sdGlwLScgKyBfcG9zaXRpb247XHJcbiAgICAgICAgdGhpcy5jb250YWluZXIuY2xhc3NOYW1lID0gdGhpcy50b29sdGlwU3R5bGVDbGFzcyA/IGRlZmF1bHRDbGFzc05hbWUgKyAnICcgKyB0aGlzLnRvb2x0aXBTdHlsZUNsYXNzIDogZGVmYXVsdENsYXNzTmFtZTtcclxuICAgIH1cclxuXHJcbiAgICAvLyB0ZW1wIGZpeDogY2hlY2tpbmcgb3V0IG9mIGJvdW5kcyBzaG91bGQgaGFwcGVuIGJlZm9yZSB3b3Jkd3JhcCBjaGFuZ2VzIHRoZSBzaXplIG9uIHRvb2x0aXBcclxuICAgIHByaXZhdGUgX2NoZWNrT3V0T2ZCb3VuZHMoX2xlZnQ6IG51bWJlciwgX3RvcDogbnVtYmVyLCBfd2lkdGg6IG51bWJlciwgX2hlaWdodDogbnVtYmVyKSB7XHJcbiAgICAgICAgbGV0IHZpZXdwb3J0ID0gRG9tSGFuZGxlci5nZXRWaWV3cG9ydCgpO1xyXG4gICAgICAgIHJldHVybiAoX2xlZnQgKyBfd2lkdGggPiB2aWV3cG9ydC53aWR0aCkgfHwgKF9sZWZ0IDwgMCkgfHwgKF90b3AgPCAwKSB8fCAoX3RvcCArIF9oZWlnaHQgPiB2aWV3cG9ydC5oZWlnaHQpO1xyXG4gICAgfVxyXG5cclxuICAgIHB1YmxpYyByZW1vdmUoKTogdm9pZCB7XHJcbiAgICAgICAgaWYgKCF0aGlzLl9kZWFjdGl2YXRlSG9zdExpc3RlbmVyKSB7XHJcbiAgICAgICAgICAgIC8vIGFkZGVkIG9uZSBsaW5lLCBfdW5iaW5kRG9jdW1lbnRUb3VjaFN0YXJ0TGlzdG5lcigpXHJcbiAgICAgICAgICAgIGlmICh0aGlzLl9pc01vYmlsZSkgdGhpcy5fdW5iaW5kRG9jdW1lbnRUb3VjaFN0YXJ0TGlzdG5lcigpO1xyXG4gICAgICAgIH1cclxuICAgICAgICBpZiAodGhpcy5jb250YWluZXIgJiYgdGhpcy5jb250YWluZXIucGFyZW50RWxlbWVudCkge1xyXG4gICAgICAgICAgICBpZiAodGhpcy5hcHBlbmRUbyA9PT0gJ2JvZHknKSB7XHJcbiAgICAgICAgICAgICAgICBkb2N1bWVudC5ib2R5LnJlbW92ZUNoaWxkKHRoaXMuY29udGFpbmVyKTtcclxuICAgICAgICAgICAgfSBlbHNlIGlmICh0aGlzLmFwcGVuZFRvID09PSAndGFyZ2V0Jykge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5fZWwubmF0aXZlRWxlbWVudC5yZW1vdmVDaGlsZCh0aGlzLmNvbnRhaW5lcik7XHJcbiAgICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgICAgICBEb21IYW5kbGVyLnJlbW92ZUNoaWxkKHRoaXMuY29udGFpbmVyLCB0aGlzLmFwcGVuZFRvKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgICAgICB0aGlzLmNvbnRhaW5lciA9IG51bGw7XHJcbiAgICB9XHJcblxyXG4gICAgLyoqKioqKioqTmV3IEZ1bmN0aW9ucyoqKioqKioqKioqL1xyXG4gICAgcHJpdmF0ZSBfaW5pdEFwaSgpOiB2b2lkIHtcclxuICAgICAgICBpZiAodHlwZW9mIHRoaXMuYXBpICE9PSAndW5kZWZpbmVkJykge1xyXG4gICAgICAgICAgICB0aGlzLmFwaS5zaG93VG9vbHRpcCA9ICgpOiB2b2lkID0+IHN1cGVyLmFjdGl2YXRlKCk7XHJcbiAgICAgICAgICAgIHRoaXMuYXBpLmhpZGVUb29sdGlwID0gKCk6IHZvaWQgPT4gc3VwZXIuZGVhY3RpdmF0ZSgpO1xyXG4gICAgICAgICAgICB0aGlzLmFwaS5kZWFjdGl2YXRlSG9zdExpc3RlbmVyID0gKCk6IHZvaWQgPT4geyB0aGlzLl9kZWFjdGl2YXRlSG9zdExpc3RlbmVyID0gdHJ1ZTsgfTtcclxuICAgICAgICAgICAgdGhpcy5hcGkuYWN0aXZhdGVIb3N0TGlzdGVuZXIgPSAoKTogdm9pZCA9PiB7IHRoaXMuX2RlYWN0aXZhdGVIb3N0TGlzdGVuZXIgPSBmYWxzZTsgfTtcclxuICAgICAgICAgICAgdGhpcy5hcGkuYWxpZ24gPSAoKTogdm9pZCA9PiB7XHJcbiAgICAgICAgICAgICAgICBpZiAoIXRoaXMuY29udGFpbmVyKSByZXR1cm47XHJcbiAgICAgICAgICAgICAgICB0aGlzLmFsaWduKCk7XHJcbiAgICAgICAgICAgIH07XHJcbiAgICAgICAgICAgIHRoaXMuYXBpLnNldE9mZnNldCA9IChfb2Zmc2V0OiB7IHg6IG51bWJlciwgeTogbnVtYmVyIH0pOiB2b2lkID0+IHsgdGhpcy5fb2Zmc2V0ID0gX29mZnNldDsgfTtcclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfY2FsY3VsYXRlV2lkdGhPdXQoKTogbnVtYmVyIHtcclxuICAgICAgICBsZXQgb2Zmc2V0OiBDbGllbnRSZWN0ID0gdGhpcy5jb250YWluZXIuZ2V0Qm91bmRpbmdDbGllbnRSZWN0KCk7XHJcbiAgICAgICAgbGV0IHRhcmdldExlZnQ6IG51bWJlciA9IG9mZnNldC5sZWZ0O1xyXG4gICAgICAgIGxldCB3aWR0aDogbnVtYmVyID0gRG9tSGFuZGxlci5nZXRPdXRlcldpZHRoKHRoaXMuY29udGFpbmVyKTtcclxuICAgICAgICBsZXQgdmlld3BvcnQ6IGFueSA9IERvbUhhbmRsZXIuZ2V0Vmlld3BvcnQoKTtcclxuXHJcbiAgICAgICAgaWYgKHRhcmdldExlZnQgKyB3aWR0aCAtIHZpZXdwb3J0LndpZHRoID4gMCkgcmV0dXJuIHRhcmdldExlZnQgKyB3aWR0aCAtIHZpZXdwb3J0LndpZHRoO1xyXG4gICAgICAgIGlmICh0YXJnZXRMZWZ0IDwgMCkgcmV0dXJuIHRhcmdldExlZnQgKiAtMTtcclxuXHJcbiAgICAgICAgcmV0dXJuIDA7XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfYmluZERvY3VtZW50VG91Y2hTdGFydExpc3RlbmVyKCk6IHZvaWQge1xyXG4gICAgICAgIHRoaXMuX2RvY3VtZW50VG91Y2hTdGFydExpc3RlbmVyID0gdGhpcy5fcmVuZGVyZXIubGlzdGVuKFxyXG4gICAgICAgICAgICAnZG9jdW1lbnQnLFxyXG4gICAgICAgICAgICAndG91Y2hzdGFydCcsXHJcbiAgICAgICAgICAgIGV2ZW50ID0+IHtcclxuICAgICAgICAgICAgICAgIHN1cGVyLmhpZGUoKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICk7XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfdW5iaW5kRG9jdW1lbnRUb3VjaFN0YXJ0TGlzdG5lcigpOiB2b2lkIHtcclxuICAgICAgICBpZiAodGhpcy5fZG9jdW1lbnRUb3VjaFN0YXJ0TGlzdGVuZXIpIHtcclxuICAgICAgICAgICAgdGhpcy5fZG9jdW1lbnRUb3VjaFN0YXJ0TGlzdGVuZXIoKTtcclxuICAgICAgICAgICAgdGhpcy5fZG9jdW1lbnRUb3VjaFN0YXJ0TGlzdGVuZXIgPSBudWxsO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICBuZ09uRGVzdHJveSgpOiB2b2lkIHtcclxuICAgICAgICAvLyBzdXBlci51bmJpbmRFdmVudHMoKTtcclxuICAgICAgICB0aGlzLnJlbW92ZSgpO1xyXG4gICAgICAgIC8vIGFkZGVkIDIgbGluZS4gdW5zdWJzY3JpcHRpb25cclxuICAgICAgICB0aGlzLl9kcmFnTWVudVN1Yi51bnN1YnNjcmliZSgpO1xyXG4gICAgICAgIHRoaXMuX3RvZ2dsZU1lbnVTdWIudW5zdWJzY3JpYmUoKTtcclxuICAgIH1cclxufVxyXG4iXX0=