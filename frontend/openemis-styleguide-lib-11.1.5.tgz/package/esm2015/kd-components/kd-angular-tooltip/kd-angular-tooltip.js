import { Component, Input, ViewEncapsulation, } from '@angular/core';
/**
 * plugin: primeng tooltip
 *
 * note: if type is custom, in [config]
 *         - description is HTML string
 *         - customise icon used using iconClass
 *         - customise class appended to primeng tooltip using typeClass
 */
export class KdTooltip {
    constructor() {
        this.description = '';
        this.placement = '';
        this.typeClass = '';
        this.tooltipIconClass = '';
        this._type = '';
    }
    ngOnInit() {
        /* if type is custom, take description (HTML string) and pass to primeng directly */
        this.description = this.config.type === 'custom' ? this.config.description : this._checkDescription(this.config.description);
        this.placement = (typeof this.config.placement !== 'undefined') ? this.config.placement : 'right';
        this._type = (typeof this.config.type !== 'undefined') ? this.config.type : 'info';
        switch (this._type) {
            case 'error':
                this.typeClass = 'kdx-tooltip-error';
                this.tooltipIconClass = 'fa fa-lg fa-exclamation-circle ' + this.typeClass;
                break;
            case 'warning':
                this.typeClass = 'kdx-tooltip-warning';
                this.tooltipIconClass = 'fa fa-lg fa-question-circle ' + this.typeClass;
                break;
            case 'info':
                this.typeClass = 'kdx-tooltip-info';
                this.tooltipIconClass = 'fa fa-lg fa-info-circle ' + this.typeClass;
                break;
            case 'custom':
                this.typeClass = this.config.typeClass || 'kdx-tooltip-custom';
                this.tooltipIconClass = ((this.config.iconClass + ' ') || 'fa fa-lg fa-exclamation-circle ') + this.typeClass;
                break;
            default:
                this.typeClass = 'kdx-tooltip-info';
                this.tooltipIconClass = 'fa fa-lg fa-info-circle ' + this.typeClass;
                break;
        }
    }
    ngOnChanges() {
        this.description = this.config.type === 'custom' ? this.config.description : this._checkDescription(this.config.description);
    }
    /******* temp fix by Grace (13 Dec 2017) *********/
    /* temp fix due to event listerner of primeng - mouseenter and mouseleave and click are triggered tgt in one touch of mobile device */
    // public _mouseenter(e:Event): void {
    //     if(this._kdDomSvc.isMobileDevice()) {
    //         console.log('if reached')
    //         // disable click
    //         // let tooltipIcon: any = e.target;
    //         // tooltipIcon.style.pointerEvents = 'none';
    //         this.tooltipIcon.nativeElement.style.pointerEvents = 'none';
    //         let removeTooltip = function () {
    //             console.log('touchstart')
    //             let tooltipEle: any = document.querySelector('.ui-tooltip');
    //             if (tooltipEle) tooltipEle.remove();
    //             // tooltipIcon.style.pointerEvents = 'auto';
    //             document.removeEventListener('touchstart',removeTooltip);
    //         }
    //         // when user touch/pan/swipe/scrolls, tooltip is removed to prevent misalignment
    //         document.addEventListener('touchstart', removeTooltip);
    //         Observable.timer(1000).subscribe((): void => {
    //             this.tooltipIcon.nativeElement.style.pointerEvents = 'auto';
    //         })
    //     }
    //     this._renderer.listen(document,'touchstart',()=>{
    //         console.log('ontouchstart')
    //     })
    // }
    /****** temp fix end ******/
    _checkDescription(_description) {
        if (_description === '' || (_description instanceof Array && _description.length === 0))
            return '';
        // if (typeof _description === 'string') return '<div class="kd-tooltip-text">' + _description + '</div>';
        if (typeof _description === 'string')
            return '<div class="tooltip-text">' + _description + '</div>';
        if (_description instanceof Array) {
            if (_description.length === 1)
                return '<div class="tooltip-text">' + _description[0] + '</div>';
            let newString = '<ul class="tooltip-list">';
            for (let i = 0; i < _description.length; i++) {
                newString += '<li>' + _description[i] + '</li>';
            }
            newString += '</ul>';
            return newString;
        }
    }
}
KdTooltip.decorators = [
    { type: Component, args: [{
                selector: 'kd-tooltip',
                template: "<!-- <i *ngIf=\"_description != ''\" [ngClass]=\"_tooltipClass\" [placement]=\"_placement\" [ngbTooltip]=\"_description\"></i> -->\r\n<!-- <i *ngIf=\"_description == ''\" [ngClass]=\"_tooltipClass\" [placement]=\"_placement\" [ngbTooltip]=\"ngContent\"></i> -->\r\n<!--NgContent if there is no user input for description-->\r\n<!-- <template #ngContent>\r\n    <ng-content></ng-content>\r\n</template>\r\n -->\r\n\r\n\t<i [kd-tooltip-dir]=\"description\" tooltipEvent=\"hover\" [tooltipPosition]=\"placement\" [ngClass]=\"tooltipIconClass\" [tooltipStyleClass]=\"typeClass\" [escape]=\"false\"\r\n\t></i>\r\n",
                encapsulation: ViewEncapsulation.None,
                host: { 'class': 'kdx-tooltip' }
            },] }
];
KdTooltip.propDecorators = {
    config: [{ type: Input }]
};
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoia2QtYW5ndWxhci10b29sdGlwLmpzIiwic291cmNlUm9vdCI6IkM6L3hhbXBwL2h0ZG9jcy9TdHlsZWd1aWRlL2lvc3RnLW9wZW5lbWlzLXN0eWxlZ3VpZGUvcHJvamVjdHMvb3BlbmVtaXMtc3R5bGVndWlkZS1saWIvc3JjLyIsInNvdXJjZXMiOlsia2QtY29tcG9uZW50cy9rZC1hbmd1bGFyLXRvb2x0aXAva2QtYW5ndWxhci10b29sdGlwLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBLE9BQU8sRUFDSCxTQUFTLEVBQ1QsS0FBSyxFQUdMLGlCQUFpQixHQUNwQixNQUFNLGVBQWUsQ0FBQztBQVN2Qjs7Ozs7OztHQU9HO0FBRUgsTUFBTSxPQUFPLFNBQVM7SUFoQnRCO1FBa0JXLGdCQUFXLEdBQVcsRUFBRSxDQUFDO1FBQ3pCLGNBQVMsR0FBVyxFQUFFLENBQUM7UUFDdkIsY0FBUyxHQUFXLEVBQUUsQ0FBQztRQUN2QixxQkFBZ0IsR0FBVyxFQUFFLENBQUM7UUFFN0IsVUFBSyxHQUFXLEVBQUUsQ0FBQztJQXdGL0IsQ0FBQztJQXBGRyxRQUFRO1FBQ0osb0ZBQW9GO1FBQ3BGLElBQUksQ0FBQyxXQUFXLEdBQUcsSUFBSSxDQUFDLE1BQU0sQ0FBQyxJQUFJLEtBQUssUUFBUSxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLGlCQUFpQixDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsV0FBVyxDQUFDLENBQUM7UUFDN0gsSUFBSSxDQUFDLFNBQVMsR0FBRyxDQUFDLE9BQU8sSUFBSSxDQUFDLE1BQU0sQ0FBQyxTQUFTLEtBQUssV0FBVyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUM7UUFDbEcsSUFBSSxDQUFDLEtBQUssR0FBRyxDQUFDLE9BQU8sSUFBSSxDQUFDLE1BQU0sQ0FBQyxJQUFJLEtBQUssV0FBVyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUM7UUFFbkYsUUFBUSxJQUFJLENBQUMsS0FBSyxFQUFFO1lBQ2hCLEtBQUssT0FBTztnQkFDUixJQUFJLENBQUMsU0FBUyxHQUFHLG1CQUFtQixDQUFDO2dCQUNyQyxJQUFJLENBQUMsZ0JBQWdCLEdBQUcsaUNBQWlDLEdBQUcsSUFBSSxDQUFDLFNBQVMsQ0FBQztnQkFDM0UsTUFBTTtZQUNWLEtBQUssU0FBUztnQkFDVixJQUFJLENBQUMsU0FBUyxHQUFHLHFCQUFxQixDQUFDO2dCQUN2QyxJQUFJLENBQUMsZ0JBQWdCLEdBQUcsOEJBQThCLEdBQUcsSUFBSSxDQUFDLFNBQVMsQ0FBQztnQkFDeEUsTUFBTTtZQUNWLEtBQUssTUFBTTtnQkFDUCxJQUFJLENBQUMsU0FBUyxHQUFHLGtCQUFrQixDQUFDO2dCQUNwQyxJQUFJLENBQUMsZ0JBQWdCLEdBQUcsMEJBQTBCLEdBQUcsSUFBSSxDQUFDLFNBQVMsQ0FBQztnQkFDcEUsTUFBTTtZQUNWLEtBQUssUUFBUTtnQkFDVCxJQUFJLENBQUMsU0FBUyxHQUFHLElBQUksQ0FBQyxNQUFNLENBQUMsU0FBUyxJQUFJLG9CQUFvQixDQUFDO2dCQUMvRCxJQUFJLENBQUMsZ0JBQWdCLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsU0FBUyxHQUFHLEdBQUcsQ0FBQyxJQUFJLGlDQUFpQyxDQUFDLEdBQUcsSUFBSSxDQUFDLFNBQVMsQ0FBQztnQkFDOUcsTUFBTTtZQUNWO2dCQUNJLElBQUksQ0FBQyxTQUFTLEdBQUcsa0JBQWtCLENBQUM7Z0JBQ3BDLElBQUksQ0FBQyxnQkFBZ0IsR0FBRywwQkFBMEIsR0FBRyxJQUFJLENBQUMsU0FBUyxDQUFDO2dCQUNwRSxNQUFNO1NBQ2I7SUFDTCxDQUFDO0lBRUQsV0FBVztRQUNQLElBQUksQ0FBQyxXQUFXLEdBQUcsSUFBSSxDQUFDLE1BQU0sQ0FBQyxJQUFJLEtBQUssUUFBUSxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLGlCQUFpQixDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsV0FBVyxDQUFDLENBQUM7SUFDakksQ0FBQztJQUVELG1EQUFtRDtJQUNuRCxzSUFBc0k7SUFDdEksc0NBQXNDO0lBRXRDLDRDQUE0QztJQUM1QyxvQ0FBb0M7SUFDcEMsMkJBQTJCO0lBQzNCLDhDQUE4QztJQUM5Qyx1REFBdUQ7SUFDdkQsdUVBQXVFO0lBRXZFLDRDQUE0QztJQUM1Qyx3Q0FBd0M7SUFDeEMsMkVBQTJFO0lBQzNFLG1EQUFtRDtJQUNuRCwyREFBMkQ7SUFDM0Qsd0VBQXdFO0lBQ3hFLFlBQVk7SUFFWiwyRkFBMkY7SUFDM0Ysa0VBQWtFO0lBRWxFLHlEQUF5RDtJQUN6RCwyRUFBMkU7SUFDM0UsYUFBYTtJQUNiLFFBQVE7SUFDUix3REFBd0Q7SUFDeEQsc0NBQXNDO0lBQ3RDLFNBQVM7SUFDVCxJQUFJO0lBQ0osNEJBQTRCO0lBRXBCLGlCQUFpQixDQUFDLFlBQWlCO1FBQ3ZDLElBQUksWUFBWSxLQUFLLEVBQUUsSUFBSSxDQUFDLFlBQVksWUFBWSxLQUFLLElBQUksWUFBWSxDQUFDLE1BQU0sS0FBSyxDQUFDLENBQUM7WUFBRSxPQUFPLEVBQUUsQ0FBQztRQUVuRywwR0FBMEc7UUFDMUcsSUFBSSxPQUFPLFlBQVksS0FBSyxRQUFRO1lBQUUsT0FBTyw0QkFBNEIsR0FBRyxZQUFZLEdBQUcsUUFBUSxDQUFDO1FBRXBHLElBQUksWUFBWSxZQUFZLEtBQUssRUFBRTtZQUMvQixJQUFJLFlBQVksQ0FBQyxNQUFNLEtBQUssQ0FBQztnQkFBRSxPQUFPLDRCQUE0QixHQUFHLFlBQVksQ0FBQyxDQUFDLENBQUMsR0FBRyxRQUFRLENBQUM7WUFFaEcsSUFBSSxTQUFTLEdBQVcsMkJBQTJCLENBQUM7WUFDcEQsS0FBSyxJQUFJLENBQUMsR0FBVyxDQUFDLEVBQUUsQ0FBQyxHQUFHLFlBQVksQ0FBQyxNQUFNLEVBQUUsQ0FBQyxFQUFFLEVBQUU7Z0JBQ2xELFNBQVMsSUFBSSxNQUFNLEdBQUcsWUFBWSxDQUFDLENBQUMsQ0FBQyxHQUFHLE9BQU8sQ0FBQzthQUNuRDtZQUNELFNBQVMsSUFBSSxPQUFPLENBQUM7WUFFckIsT0FBTyxTQUFTLENBQUM7U0FDcEI7SUFDTCxDQUFDOzs7WUE5R0osU0FBUyxTQUFDO2dCQUNQLFFBQVEsRUFBRSxZQUFZO2dCQUN0Qiw0bUJBQXdDO2dCQUN4QyxhQUFhLEVBQUUsaUJBQWlCLENBQUMsSUFBSTtnQkFDckMsSUFBSSxFQUFHLEVBQUUsT0FBTyxFQUFHLGFBQWEsRUFBRTthQUNyQzs7O3FCQW9CSSxLQUFLIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHtcclxuICAgIENvbXBvbmVudCxcclxuICAgIElucHV0LFxyXG4gICAgT25Jbml0LFxyXG4gICAgT25DaGFuZ2VzLFxyXG4gICAgVmlld0VuY2Fwc3VsYXRpb24sXHJcbn0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XHJcblxyXG5AQ29tcG9uZW50KHtcclxuICAgIHNlbGVjdG9yOiAna2QtdG9vbHRpcCcsXHJcbiAgICB0ZW1wbGF0ZVVybDogJy4va2QtYW5ndWxhci10b29sdGlwLmh0bWwnLFxyXG4gICAgZW5jYXBzdWxhdGlvbjogVmlld0VuY2Fwc3VsYXRpb24uTm9uZSxcclxuICAgIGhvc3QgOiB7ICdjbGFzcycgOiAna2R4LXRvb2x0aXAnIH1cclxufSlcclxuXHJcbi8qKlxyXG4gKiBwbHVnaW46IHByaW1lbmcgdG9vbHRpcFxyXG4gKlxyXG4gKiBub3RlOiBpZiB0eXBlIGlzIGN1c3RvbSwgaW4gW2NvbmZpZ11cclxuICogICAgICAgICAtIGRlc2NyaXB0aW9uIGlzIEhUTUwgc3RyaW5nXHJcbiAqICAgICAgICAgLSBjdXN0b21pc2UgaWNvbiB1c2VkIHVzaW5nIGljb25DbGFzc1xyXG4gKiAgICAgICAgIC0gY3VzdG9taXNlIGNsYXNzIGFwcGVuZGVkIHRvIHByaW1lbmcgdG9vbHRpcCB1c2luZyB0eXBlQ2xhc3NcclxuICovXHJcblxyXG5leHBvcnQgY2xhc3MgS2RUb29sdGlwIGltcGxlbWVudHMgT25Jbml0LCBPbkNoYW5nZXMge1xyXG5cclxuICAgIHB1YmxpYyBkZXNjcmlwdGlvbjogc3RyaW5nID0gJyc7XHJcbiAgICBwdWJsaWMgcGxhY2VtZW50OiBzdHJpbmcgPSAnJztcclxuICAgIHB1YmxpYyB0eXBlQ2xhc3M6IHN0cmluZyA9ICcnO1xyXG4gICAgcHVibGljIHRvb2x0aXBJY29uQ2xhc3M6IHN0cmluZyA9ICcnO1xyXG5cclxuICAgIHByaXZhdGUgX3R5cGU6IHN0cmluZyA9ICcnO1xyXG5cclxuICAgIEBJbnB1dCgpIGNvbmZpZzogYW55O1xyXG5cclxuICAgIG5nT25Jbml0KCk6IHZvaWQge1xyXG4gICAgICAgIC8qIGlmIHR5cGUgaXMgY3VzdG9tLCB0YWtlIGRlc2NyaXB0aW9uIChIVE1MIHN0cmluZykgYW5kIHBhc3MgdG8gcHJpbWVuZyBkaXJlY3RseSAqL1xyXG4gICAgICAgIHRoaXMuZGVzY3JpcHRpb24gPSB0aGlzLmNvbmZpZy50eXBlID09PSAnY3VzdG9tJyA/IHRoaXMuY29uZmlnLmRlc2NyaXB0aW9uIDogdGhpcy5fY2hlY2tEZXNjcmlwdGlvbih0aGlzLmNvbmZpZy5kZXNjcmlwdGlvbik7XHJcbiAgICAgICAgdGhpcy5wbGFjZW1lbnQgPSAodHlwZW9mIHRoaXMuY29uZmlnLnBsYWNlbWVudCAhPT0gJ3VuZGVmaW5lZCcpID8gdGhpcy5jb25maWcucGxhY2VtZW50IDogJ3JpZ2h0JztcclxuICAgICAgICB0aGlzLl90eXBlID0gKHR5cGVvZiB0aGlzLmNvbmZpZy50eXBlICE9PSAndW5kZWZpbmVkJykgPyB0aGlzLmNvbmZpZy50eXBlIDogJ2luZm8nO1xyXG5cclxuICAgICAgICBzd2l0Y2ggKHRoaXMuX3R5cGUpIHtcclxuICAgICAgICAgICAgY2FzZSAnZXJyb3InOlxyXG4gICAgICAgICAgICAgICAgdGhpcy50eXBlQ2xhc3MgPSAna2R4LXRvb2x0aXAtZXJyb3InO1xyXG4gICAgICAgICAgICAgICAgdGhpcy50b29sdGlwSWNvbkNsYXNzID0gJ2ZhIGZhLWxnIGZhLWV4Y2xhbWF0aW9uLWNpcmNsZSAnICsgdGhpcy50eXBlQ2xhc3M7XHJcbiAgICAgICAgICAgICAgICBicmVhaztcclxuICAgICAgICAgICAgY2FzZSAnd2FybmluZyc6XHJcbiAgICAgICAgICAgICAgICB0aGlzLnR5cGVDbGFzcyA9ICdrZHgtdG9vbHRpcC13YXJuaW5nJztcclxuICAgICAgICAgICAgICAgIHRoaXMudG9vbHRpcEljb25DbGFzcyA9ICdmYSBmYS1sZyBmYS1xdWVzdGlvbi1jaXJjbGUgJyArIHRoaXMudHlwZUNsYXNzO1xyXG4gICAgICAgICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgICAgIGNhc2UgJ2luZm8nOlxyXG4gICAgICAgICAgICAgICAgdGhpcy50eXBlQ2xhc3MgPSAna2R4LXRvb2x0aXAtaW5mbyc7XHJcbiAgICAgICAgICAgICAgICB0aGlzLnRvb2x0aXBJY29uQ2xhc3MgPSAnZmEgZmEtbGcgZmEtaW5mby1jaXJjbGUgJyArIHRoaXMudHlwZUNsYXNzO1xyXG4gICAgICAgICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgICAgIGNhc2UgJ2N1c3RvbSc6XHJcbiAgICAgICAgICAgICAgICB0aGlzLnR5cGVDbGFzcyA9IHRoaXMuY29uZmlnLnR5cGVDbGFzcyB8fCAna2R4LXRvb2x0aXAtY3VzdG9tJztcclxuICAgICAgICAgICAgICAgIHRoaXMudG9vbHRpcEljb25DbGFzcyA9ICgodGhpcy5jb25maWcuaWNvbkNsYXNzICsgJyAnKSB8fCAnZmEgZmEtbGcgZmEtZXhjbGFtYXRpb24tY2lyY2xlICcpICsgdGhpcy50eXBlQ2xhc3M7XHJcbiAgICAgICAgICAgICAgICBicmVhaztcclxuICAgICAgICAgICAgZGVmYXVsdDpcclxuICAgICAgICAgICAgICAgIHRoaXMudHlwZUNsYXNzID0gJ2tkeC10b29sdGlwLWluZm8nO1xyXG4gICAgICAgICAgICAgICAgdGhpcy50b29sdGlwSWNvbkNsYXNzID0gJ2ZhIGZhLWxnIGZhLWluZm8tY2lyY2xlICcgKyB0aGlzLnR5cGVDbGFzcztcclxuICAgICAgICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICBuZ09uQ2hhbmdlcygpOiB2b2lkIHtcclxuICAgICAgICB0aGlzLmRlc2NyaXB0aW9uID0gdGhpcy5jb25maWcudHlwZSA9PT0gJ2N1c3RvbScgPyB0aGlzLmNvbmZpZy5kZXNjcmlwdGlvbiA6IHRoaXMuX2NoZWNrRGVzY3JpcHRpb24odGhpcy5jb25maWcuZGVzY3JpcHRpb24pO1xyXG4gICAgfVxyXG5cclxuICAgIC8qKioqKioqIHRlbXAgZml4IGJ5IEdyYWNlICgxMyBEZWMgMjAxNykgKioqKioqKioqL1xyXG4gICAgLyogdGVtcCBmaXggZHVlIHRvIGV2ZW50IGxpc3Rlcm5lciBvZiBwcmltZW5nIC0gbW91c2VlbnRlciBhbmQgbW91c2VsZWF2ZSBhbmQgY2xpY2sgYXJlIHRyaWdnZXJlZCB0Z3QgaW4gb25lIHRvdWNoIG9mIG1vYmlsZSBkZXZpY2UgKi9cclxuICAgIC8vIHB1YmxpYyBfbW91c2VlbnRlcihlOkV2ZW50KTogdm9pZCB7XHJcblxyXG4gICAgLy8gICAgIGlmKHRoaXMuX2tkRG9tU3ZjLmlzTW9iaWxlRGV2aWNlKCkpIHtcclxuICAgIC8vICAgICAgICAgY29uc29sZS5sb2coJ2lmIHJlYWNoZWQnKVxyXG4gICAgLy8gICAgICAgICAvLyBkaXNhYmxlIGNsaWNrXHJcbiAgICAvLyAgICAgICAgIC8vIGxldCB0b29sdGlwSWNvbjogYW55ID0gZS50YXJnZXQ7XHJcbiAgICAvLyAgICAgICAgIC8vIHRvb2x0aXBJY29uLnN0eWxlLnBvaW50ZXJFdmVudHMgPSAnbm9uZSc7XHJcbiAgICAvLyAgICAgICAgIHRoaXMudG9vbHRpcEljb24ubmF0aXZlRWxlbWVudC5zdHlsZS5wb2ludGVyRXZlbnRzID0gJ25vbmUnO1xyXG5cclxuICAgIC8vICAgICAgICAgbGV0IHJlbW92ZVRvb2x0aXAgPSBmdW5jdGlvbiAoKSB7XHJcbiAgICAvLyAgICAgICAgICAgICBjb25zb2xlLmxvZygndG91Y2hzdGFydCcpXHJcbiAgICAvLyAgICAgICAgICAgICBsZXQgdG9vbHRpcEVsZTogYW55ID0gZG9jdW1lbnQucXVlcnlTZWxlY3RvcignLnVpLXRvb2x0aXAnKTtcclxuICAgIC8vICAgICAgICAgICAgIGlmICh0b29sdGlwRWxlKSB0b29sdGlwRWxlLnJlbW92ZSgpO1xyXG4gICAgLy8gICAgICAgICAgICAgLy8gdG9vbHRpcEljb24uc3R5bGUucG9pbnRlckV2ZW50cyA9ICdhdXRvJztcclxuICAgIC8vICAgICAgICAgICAgIGRvY3VtZW50LnJlbW92ZUV2ZW50TGlzdGVuZXIoJ3RvdWNoc3RhcnQnLHJlbW92ZVRvb2x0aXApO1xyXG4gICAgLy8gICAgICAgICB9XHJcblxyXG4gICAgLy8gICAgICAgICAvLyB3aGVuIHVzZXIgdG91Y2gvcGFuL3N3aXBlL3Njcm9sbHMsIHRvb2x0aXAgaXMgcmVtb3ZlZCB0byBwcmV2ZW50IG1pc2FsaWdubWVudFxyXG4gICAgLy8gICAgICAgICBkb2N1bWVudC5hZGRFdmVudExpc3RlbmVyKCd0b3VjaHN0YXJ0JywgcmVtb3ZlVG9vbHRpcCk7XHJcblxyXG4gICAgLy8gICAgICAgICBPYnNlcnZhYmxlLnRpbWVyKDEwMDApLnN1YnNjcmliZSgoKTogdm9pZCA9PiB7XHJcbiAgICAvLyAgICAgICAgICAgICB0aGlzLnRvb2x0aXBJY29uLm5hdGl2ZUVsZW1lbnQuc3R5bGUucG9pbnRlckV2ZW50cyA9ICdhdXRvJztcclxuICAgIC8vICAgICAgICAgfSlcclxuICAgIC8vICAgICB9XHJcbiAgICAvLyAgICAgdGhpcy5fcmVuZGVyZXIubGlzdGVuKGRvY3VtZW50LCd0b3VjaHN0YXJ0JywoKT0+e1xyXG4gICAgLy8gICAgICAgICBjb25zb2xlLmxvZygnb250b3VjaHN0YXJ0JylcclxuICAgIC8vICAgICB9KVxyXG4gICAgLy8gfVxyXG4gICAgLyoqKioqKiB0ZW1wIGZpeCBlbmQgKioqKioqL1xyXG5cclxuICAgIHByaXZhdGUgX2NoZWNrRGVzY3JpcHRpb24oX2Rlc2NyaXB0aW9uOiBhbnkpOiBzdHJpbmcge1xyXG4gICAgICAgIGlmIChfZGVzY3JpcHRpb24gPT09ICcnIHx8IChfZGVzY3JpcHRpb24gaW5zdGFuY2VvZiBBcnJheSAmJiBfZGVzY3JpcHRpb24ubGVuZ3RoID09PSAwKSkgcmV0dXJuICcnO1xyXG5cclxuICAgICAgICAvLyBpZiAodHlwZW9mIF9kZXNjcmlwdGlvbiA9PT0gJ3N0cmluZycpIHJldHVybiAnPGRpdiBjbGFzcz1cImtkLXRvb2x0aXAtdGV4dFwiPicgKyBfZGVzY3JpcHRpb24gKyAnPC9kaXY+JztcclxuICAgICAgICBpZiAodHlwZW9mIF9kZXNjcmlwdGlvbiA9PT0gJ3N0cmluZycpIHJldHVybiAnPGRpdiBjbGFzcz1cInRvb2x0aXAtdGV4dFwiPicgKyBfZGVzY3JpcHRpb24gKyAnPC9kaXY+JztcclxuXHJcbiAgICAgICAgaWYgKF9kZXNjcmlwdGlvbiBpbnN0YW5jZW9mIEFycmF5KSB7XHJcbiAgICAgICAgICAgIGlmIChfZGVzY3JpcHRpb24ubGVuZ3RoID09PSAxKSByZXR1cm4gJzxkaXYgY2xhc3M9XCJ0b29sdGlwLXRleHRcIj4nICsgX2Rlc2NyaXB0aW9uWzBdICsgJzwvZGl2Pic7XHJcblxyXG4gICAgICAgICAgICBsZXQgbmV3U3RyaW5nOiBzdHJpbmcgPSAnPHVsIGNsYXNzPVwidG9vbHRpcC1saXN0XCI+JztcclxuICAgICAgICAgICAgZm9yIChsZXQgaTogbnVtYmVyID0gMDsgaSA8IF9kZXNjcmlwdGlvbi5sZW5ndGg7IGkrKykge1xyXG4gICAgICAgICAgICAgICAgbmV3U3RyaW5nICs9ICc8bGk+JyArIF9kZXNjcmlwdGlvbltpXSArICc8L2xpPic7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgbmV3U3RyaW5nICs9ICc8L3VsPic7XHJcblxyXG4gICAgICAgICAgICByZXR1cm4gbmV3U3RyaW5nO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxufVxyXG4iXX0=