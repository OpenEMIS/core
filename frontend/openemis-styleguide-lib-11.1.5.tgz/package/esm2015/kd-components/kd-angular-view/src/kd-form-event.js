import { Injectable } from '@angular/core';
import { KdBroadcaster } from '../../kd-common/index';
import * as i0 from "@angular/core";
import * as i1 from "../../kd-common/kd-broadcaster-svc";
export class KdFormEvent {
    constructor(_broadcaster) {
        this._broadcaster = _broadcaster;
    }
    setDropdownList(data) {
        this._broadcaster.broadcast('KdSetDropdownList', data);
    }
    onSetDropdownList() {
        return this._broadcaster.on('KdSetDropdownList');
    }
    setVisiableInput(data) {
        this._broadcaster.broadcast('KdSetVisiableInput', data);
    }
    onSetVisiableInput() {
        return this._broadcaster.on('KdSetVisiableInput');
    }
}
KdFormEvent.ɵprov = i0.ɵɵdefineInjectable({ factory: function KdFormEvent_Factory() { return new KdFormEvent(i0.ɵɵinject(i1.KdBroadcaster)); }, token: KdFormEvent, providedIn: "root" });
KdFormEvent.decorators = [
    { type: Injectable, args: [{
                providedIn: 'root'
            },] }
];
KdFormEvent.ctorParameters = () => [
    { type: KdBroadcaster }
];
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoia2QtZm9ybS1ldmVudC5qcyIsInNvdXJjZVJvb3QiOiJDOi94YW1wcC9odGRvY3MvU3R5bGVndWlkZS9pb3N0Zy1vcGVuZW1pcy1zdHlsZWd1aWRlL3Byb2plY3RzL29wZW5lbWlzLXN0eWxlZ3VpZGUtbGliL3NyYy8iLCJzb3VyY2VzIjpbImtkLWNvbXBvbmVudHMva2QtYW5ndWxhci12aWV3L3NyYy9rZC1mb3JtLWV2ZW50LnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBLE9BQU8sRUFBRSxVQUFVLEVBQUUsTUFBTSxlQUFlLENBQUM7QUFFM0MsT0FBTyxFQUFFLGFBQWEsRUFBRSxNQUFNLHVCQUF1QixDQUFDOzs7QUFLdEQsTUFBTSxPQUFPLFdBQVc7SUFDcEIsWUFBb0IsWUFBMkI7UUFBM0IsaUJBQVksR0FBWixZQUFZLENBQWU7SUFBSSxDQUFDO0lBRXBELGVBQWUsQ0FBQyxJQUFVO1FBQ3RCLElBQUksQ0FBQyxZQUFZLENBQUMsU0FBUyxDQUFDLG1CQUFtQixFQUFFLElBQUksQ0FBQyxDQUFDO0lBQzNELENBQUM7SUFFRCxpQkFBaUI7UUFDYixPQUFPLElBQUksQ0FBQyxZQUFZLENBQUMsRUFBRSxDQUFNLG1CQUFtQixDQUFDLENBQUM7SUFDMUQsQ0FBQztJQUVELGdCQUFnQixDQUFDLElBQVU7UUFDdkIsSUFBSSxDQUFDLFlBQVksQ0FBQyxTQUFTLENBQUMsb0JBQW9CLEVBQUUsSUFBSSxDQUFDLENBQUM7SUFDNUQsQ0FBQztJQUVELGtCQUFrQjtRQUNkLE9BQU8sSUFBSSxDQUFDLFlBQVksQ0FBQyxFQUFFLENBQU0sb0JBQW9CLENBQUMsQ0FBQztJQUMzRCxDQUFDOzs7O1lBcEJKLFVBQVUsU0FBQztnQkFDUixVQUFVLEVBQUUsTUFBTTthQUNyQjs7O1lBSlEsYUFBYSIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IEluamVjdGFibGUgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcclxuaW1wb3J0IHsgT2JzZXJ2YWJsZSB9IGZyb20gJ3J4anMnO1xyXG5pbXBvcnQgeyBLZEJyb2FkY2FzdGVyIH0gZnJvbSAnLi4vLi4va2QtY29tbW9uL2luZGV4JztcclxuXHJcbkBJbmplY3RhYmxlKHtcclxuICAgIHByb3ZpZGVkSW46ICdyb290J1xyXG59KVxyXG5leHBvcnQgY2xhc3MgS2RGb3JtRXZlbnQge1xyXG4gICAgY29uc3RydWN0b3IocHJpdmF0ZSBfYnJvYWRjYXN0ZXI6IEtkQnJvYWRjYXN0ZXIpIHsgfVxyXG5cclxuICAgIHNldERyb3Bkb3duTGlzdChkYXRhPzogYW55KTogdm9pZCB7XHJcbiAgICAgICAgdGhpcy5fYnJvYWRjYXN0ZXIuYnJvYWRjYXN0KCdLZFNldERyb3Bkb3duTGlzdCcsIGRhdGEpO1xyXG4gICAgfVxyXG5cclxuICAgIG9uU2V0RHJvcGRvd25MaXN0KCk6IE9ic2VydmFibGU8YW55PiB7XHJcbiAgICAgICAgcmV0dXJuIHRoaXMuX2Jyb2FkY2FzdGVyLm9uPGFueT4oJ0tkU2V0RHJvcGRvd25MaXN0Jyk7XHJcbiAgICB9XHJcblxyXG4gICAgc2V0VmlzaWFibGVJbnB1dChkYXRhPzogYW55KTogdm9pZCB7XHJcbiAgICAgICAgdGhpcy5fYnJvYWRjYXN0ZXIuYnJvYWRjYXN0KCdLZFNldFZpc2lhYmxlSW5wdXQnLCBkYXRhKTtcclxuICAgIH1cclxuXHJcbiAgICBvblNldFZpc2lhYmxlSW5wdXQoKTogT2JzZXJ2YWJsZTxhbnk+IHtcclxuICAgICAgICByZXR1cm4gdGhpcy5fYnJvYWRjYXN0ZXIub248YW55PignS2RTZXRWaXNpYWJsZUlucHV0Jyk7XHJcbiAgICB9XHJcbn1cclxuIl19