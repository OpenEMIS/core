import { Injectable } from '@angular/core';
import { KdInputCheckbox, KdInputDate, 
// KdInputDisabled,
KdInputDropdown, KdInputFileinput, KdInputFloat, KdInputHidden, KdInputInteger, KdInputPassword, KdInputRadio, KdInputText, KdInputTextarea, KdInputTime, 
// KdInputReadOnly,
KdInputTreeDropdown, KdInputSlider, KdInputMultiSelectTable, KdInputSection, KdInputSymbol, KdInputTable, KdInputButtonGroup } from '../kd-angular-input/src/kd-input-extensions';
export class KdViewSvc {
    convertDataType(_inputData, _convertSvc) {
        let updateDfQuestion = [];
        if (typeof _inputData !== 'undefined') {
            for (let i = 0; i < _inputData.length; i++) {
                let newItem = _convertSvc.createNewObject(_inputData[i]);
                updateDfQuestion.push(this._convertItem(newItem));
            }
        }
        // else{
        //     console.log('KdViewSvc > convertDataType() > ', _inputData);
        // }
        return updateDfQuestion;
    }
    _convertItem(_item) {
        switch (_item.controlType) {
            case 'integer':
                return new KdInputInteger(_item);
            case 'decimal':
                return new KdInputFloat(_item);
            case 'date':
                return new KdInputDate(_item);
            case 'time':
                return new KdInputTime(_item);
            case 'password':
                return new KdInputPassword(_item);
            case 'textarea':
                return new KdInputTextarea(_item);
            case 'hidden':
                return new KdInputHidden(_item);
            // case 'disabled':
            //     return new KdInputDisabled(_item);
            // case 'readonly':
            //     return new KdInputReadOnly(_item);
            case 'file-input':
                return new KdInputFileinput(_item);
            case 'dropdown':
                return new KdInputDropdown(_item);
            case 'radio':
                return new KdInputRadio(_item);
            case 'checkbox':
                return new KdInputCheckbox(_item);
            case 'tree':
                return new KdInputTreeDropdown(_item);
            case 'slider':
                return new KdInputSlider(_item);
            case 'multi-table':
                return new KdInputMultiSelectTable(_item);
            case 'section':
                return new KdInputSection(_item);
            case 'symbol':
                return new KdInputSymbol(_item);
            case 'table':
                return new KdInputTable(_item);
            case 'button-group':
                return new KdInputButtonGroup(_item);
            default:
                return new KdInputText(_item);
        }
    }
}
KdViewSvc.decorators = [
    { type: Injectable }
];
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoia2QtYW5ndWxhci12aWV3LXN2Yy5qcyIsInNvdXJjZVJvb3QiOiJDOi94YW1wcC9odGRvY3MvU3R5bGVndWlkZS9pb3N0Zy1vcGVuZW1pcy1zdHlsZWd1aWRlL3Byb2plY3RzL29wZW5lbWlzLXN0eWxlZ3VpZGUtbGliL3NyYy8iLCJzb3VyY2VzIjpbImtkLWNvbXBvbmVudHMva2QtYW5ndWxhci12aWV3L2tkLWFuZ3VsYXItdmlldy1zdmMudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsT0FBTyxFQUFFLFVBQVUsRUFBRSxNQUFNLGVBQWUsQ0FBQztBQUUzQyxPQUFPLEVBQ0gsZUFBZSxFQUNmLFdBQVc7QUFDWCxtQkFBbUI7QUFDbkIsZUFBZSxFQUNmLGdCQUFnQixFQUNoQixZQUFZLEVBQ1osYUFBYSxFQUNiLGNBQWMsRUFDZCxlQUFlLEVBQ2YsWUFBWSxFQUNaLFdBQVcsRUFDWCxlQUFlLEVBQ2YsV0FBVztBQUNYLG1CQUFtQjtBQUNuQixtQkFBbUIsRUFDbkIsYUFBYSxFQUNiLHVCQUF1QixFQUN2QixjQUFjLEVBQ2QsYUFBYSxFQUNiLFlBQVksRUFDWixrQkFBa0IsRUFDckIsTUFBTSw2Q0FBNkMsQ0FBQztBQUdyRCxNQUFNLE9BQU8sU0FBUztJQUNsQixlQUFlLENBQUMsVUFBc0IsRUFBRSxXQUE0QjtRQUNoRSxJQUFJLGdCQUFnQixHQUFlLEVBQUUsQ0FBQztRQUN0QyxJQUFJLE9BQU8sVUFBVSxLQUFLLFdBQVcsRUFBRTtZQUNuQyxLQUFLLElBQUksQ0FBQyxHQUFXLENBQUMsRUFBRSxDQUFDLEdBQUcsVUFBVSxDQUFDLE1BQU0sRUFBRSxDQUFDLEVBQUUsRUFBRTtnQkFDaEQsSUFBSSxPQUFPLEdBQVEsV0FBVyxDQUFDLGVBQWUsQ0FBQyxVQUFVLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztnQkFDOUQsZ0JBQWdCLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxZQUFZLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQzthQUNyRDtTQUNKO1FBQ0QsUUFBUTtRQUNSLG1FQUFtRTtRQUNuRSxJQUFJO1FBRUosT0FBTyxnQkFBZ0IsQ0FBQztJQUM1QixDQUFDO0lBRU8sWUFBWSxDQUFDLEtBQVU7UUFDM0IsUUFBUSxLQUFLLENBQUMsV0FBVyxFQUFFO1lBQ3ZCLEtBQUssU0FBUztnQkFDVixPQUFPLElBQUksY0FBYyxDQUFDLEtBQUssQ0FBQyxDQUFDO1lBQ3JDLEtBQUssU0FBUztnQkFDVixPQUFPLElBQUksWUFBWSxDQUFDLEtBQUssQ0FBQyxDQUFDO1lBQ25DLEtBQUssTUFBTTtnQkFDUCxPQUFPLElBQUksV0FBVyxDQUFDLEtBQUssQ0FBQyxDQUFDO1lBQ2xDLEtBQUssTUFBTTtnQkFDUCxPQUFPLElBQUksV0FBVyxDQUFDLEtBQUssQ0FBQyxDQUFDO1lBQ2xDLEtBQUssVUFBVTtnQkFDWCxPQUFPLElBQUksZUFBZSxDQUFDLEtBQUssQ0FBQyxDQUFDO1lBQ3RDLEtBQUssVUFBVTtnQkFDWCxPQUFPLElBQUksZUFBZSxDQUFDLEtBQUssQ0FBQyxDQUFDO1lBQ3RDLEtBQUssUUFBUTtnQkFDVCxPQUFPLElBQUksYUFBYSxDQUFDLEtBQUssQ0FBQyxDQUFDO1lBQ3BDLG1CQUFtQjtZQUNuQix5Q0FBeUM7WUFDekMsbUJBQW1CO1lBQ25CLHlDQUF5QztZQUN6QyxLQUFLLFlBQVk7Z0JBQ2IsT0FBTyxJQUFJLGdCQUFnQixDQUFDLEtBQUssQ0FBQyxDQUFDO1lBQ3ZDLEtBQUssVUFBVTtnQkFDWCxPQUFPLElBQUksZUFBZSxDQUFDLEtBQUssQ0FBQyxDQUFDO1lBQ3RDLEtBQUssT0FBTztnQkFDUixPQUFPLElBQUksWUFBWSxDQUFDLEtBQUssQ0FBQyxDQUFDO1lBQ25DLEtBQUssVUFBVTtnQkFDWCxPQUFPLElBQUksZUFBZSxDQUFDLEtBQUssQ0FBQyxDQUFDO1lBQ3RDLEtBQUssTUFBTTtnQkFDUCxPQUFPLElBQUksbUJBQW1CLENBQUMsS0FBSyxDQUFDLENBQUM7WUFDMUMsS0FBSyxRQUFRO2dCQUNULE9BQU8sSUFBSSxhQUFhLENBQUMsS0FBSyxDQUFDLENBQUM7WUFDcEMsS0FBSyxhQUFhO2dCQUNkLE9BQU8sSUFBSSx1QkFBdUIsQ0FBQyxLQUFLLENBQUMsQ0FBQztZQUM5QyxLQUFLLFNBQVM7Z0JBQ1YsT0FBTyxJQUFJLGNBQWMsQ0FBQyxLQUFLLENBQUMsQ0FBQztZQUNyQyxLQUFLLFFBQVE7Z0JBQ1QsT0FBTyxJQUFJLGFBQWEsQ0FBQyxLQUFLLENBQUMsQ0FBQztZQUNwQyxLQUFLLE9BQU87Z0JBQ1IsT0FBTyxJQUFJLFlBQVksQ0FBQyxLQUFLLENBQUMsQ0FBQztZQUNuQyxLQUFLLGNBQWM7Z0JBQ2YsT0FBTyxJQUFJLGtCQUFrQixDQUFDLEtBQUssQ0FBQyxDQUFDO1lBQ3pDO2dCQUNJLE9BQU8sSUFBSSxXQUFXLENBQUMsS0FBSyxDQUFDLENBQUM7U0FDckM7SUFDTCxDQUFDOzs7WUE5REosVUFBVSIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IEluamVjdGFibGUgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcclxuaW1wb3J0IHsgS2RDb252ZXJ0aW9uU3ZjIH0gZnJvbSAnLi4va2QtY29tbW9uJztcclxuaW1wb3J0IHtcclxuICAgIEtkSW5wdXRDaGVja2JveCxcclxuICAgIEtkSW5wdXREYXRlLFxyXG4gICAgLy8gS2RJbnB1dERpc2FibGVkLFxyXG4gICAgS2RJbnB1dERyb3Bkb3duLFxyXG4gICAgS2RJbnB1dEZpbGVpbnB1dCxcclxuICAgIEtkSW5wdXRGbG9hdCxcclxuICAgIEtkSW5wdXRIaWRkZW4sXHJcbiAgICBLZElucHV0SW50ZWdlcixcclxuICAgIEtkSW5wdXRQYXNzd29yZCxcclxuICAgIEtkSW5wdXRSYWRpbyxcclxuICAgIEtkSW5wdXRUZXh0LFxyXG4gICAgS2RJbnB1dFRleHRhcmVhLFxyXG4gICAgS2RJbnB1dFRpbWUsXHJcbiAgICAvLyBLZElucHV0UmVhZE9ubHksXHJcbiAgICBLZElucHV0VHJlZURyb3Bkb3duLFxyXG4gICAgS2RJbnB1dFNsaWRlcixcclxuICAgIEtkSW5wdXRNdWx0aVNlbGVjdFRhYmxlLFxyXG4gICAgS2RJbnB1dFNlY3Rpb24sXHJcbiAgICBLZElucHV0U3ltYm9sLFxyXG4gICAgS2RJbnB1dFRhYmxlLFxyXG4gICAgS2RJbnB1dEJ1dHRvbkdyb3VwXHJcbn0gZnJvbSAnLi4va2QtYW5ndWxhci1pbnB1dC9zcmMva2QtaW5wdXQtZXh0ZW5zaW9ucyc7XHJcblxyXG5ASW5qZWN0YWJsZSgpXHJcbmV4cG9ydCBjbGFzcyBLZFZpZXdTdmMge1xyXG4gICAgY29udmVydERhdGFUeXBlKF9pbnB1dERhdGE6IEFycmF5PGFueT4sIF9jb252ZXJ0U3ZjOiBLZENvbnZlcnRpb25TdmMpOiBBcnJheTxhbnk+IHtcclxuICAgICAgICBsZXQgdXBkYXRlRGZRdWVzdGlvbjogQXJyYXk8YW55PiA9IFtdO1xyXG4gICAgICAgIGlmICh0eXBlb2YgX2lucHV0RGF0YSAhPT0gJ3VuZGVmaW5lZCcpIHtcclxuICAgICAgICAgICAgZm9yIChsZXQgaTogbnVtYmVyID0gMDsgaSA8IF9pbnB1dERhdGEubGVuZ3RoOyBpKyspIHtcclxuICAgICAgICAgICAgICAgIGxldCBuZXdJdGVtOiBhbnkgPSBfY29udmVydFN2Yy5jcmVhdGVOZXdPYmplY3QoX2lucHV0RGF0YVtpXSk7XHJcbiAgICAgICAgICAgICAgICB1cGRhdGVEZlF1ZXN0aW9uLnB1c2godGhpcy5fY29udmVydEl0ZW0obmV3SXRlbSkpO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgICAgIC8vIGVsc2V7XHJcbiAgICAgICAgLy8gICAgIGNvbnNvbGUubG9nKCdLZFZpZXdTdmMgPiBjb252ZXJ0RGF0YVR5cGUoKSA+ICcsIF9pbnB1dERhdGEpO1xyXG4gICAgICAgIC8vIH1cclxuXHJcbiAgICAgICAgcmV0dXJuIHVwZGF0ZURmUXVlc3Rpb247XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfY29udmVydEl0ZW0oX2l0ZW06IGFueSk6IGFueSB7XHJcbiAgICAgICAgc3dpdGNoIChfaXRlbS5jb250cm9sVHlwZSkge1xyXG4gICAgICAgICAgICBjYXNlICdpbnRlZ2VyJzpcclxuICAgICAgICAgICAgICAgIHJldHVybiBuZXcgS2RJbnB1dEludGVnZXIoX2l0ZW0pO1xyXG4gICAgICAgICAgICBjYXNlICdkZWNpbWFsJzpcclxuICAgICAgICAgICAgICAgIHJldHVybiBuZXcgS2RJbnB1dEZsb2F0KF9pdGVtKTtcclxuICAgICAgICAgICAgY2FzZSAnZGF0ZSc6XHJcbiAgICAgICAgICAgICAgICByZXR1cm4gbmV3IEtkSW5wdXREYXRlKF9pdGVtKTtcclxuICAgICAgICAgICAgY2FzZSAndGltZSc6XHJcbiAgICAgICAgICAgICAgICByZXR1cm4gbmV3IEtkSW5wdXRUaW1lKF9pdGVtKTtcclxuICAgICAgICAgICAgY2FzZSAncGFzc3dvcmQnOlxyXG4gICAgICAgICAgICAgICAgcmV0dXJuIG5ldyBLZElucHV0UGFzc3dvcmQoX2l0ZW0pO1xyXG4gICAgICAgICAgICBjYXNlICd0ZXh0YXJlYSc6XHJcbiAgICAgICAgICAgICAgICByZXR1cm4gbmV3IEtkSW5wdXRUZXh0YXJlYShfaXRlbSk7XHJcbiAgICAgICAgICAgIGNhc2UgJ2hpZGRlbic6XHJcbiAgICAgICAgICAgICAgICByZXR1cm4gbmV3IEtkSW5wdXRIaWRkZW4oX2l0ZW0pO1xyXG4gICAgICAgICAgICAvLyBjYXNlICdkaXNhYmxlZCc6XHJcbiAgICAgICAgICAgIC8vICAgICByZXR1cm4gbmV3IEtkSW5wdXREaXNhYmxlZChfaXRlbSk7XHJcbiAgICAgICAgICAgIC8vIGNhc2UgJ3JlYWRvbmx5JzpcclxuICAgICAgICAgICAgLy8gICAgIHJldHVybiBuZXcgS2RJbnB1dFJlYWRPbmx5KF9pdGVtKTtcclxuICAgICAgICAgICAgY2FzZSAnZmlsZS1pbnB1dCc6XHJcbiAgICAgICAgICAgICAgICByZXR1cm4gbmV3IEtkSW5wdXRGaWxlaW5wdXQoX2l0ZW0pO1xyXG4gICAgICAgICAgICBjYXNlICdkcm9wZG93bic6XHJcbiAgICAgICAgICAgICAgICByZXR1cm4gbmV3IEtkSW5wdXREcm9wZG93bihfaXRlbSk7XHJcbiAgICAgICAgICAgIGNhc2UgJ3JhZGlvJzpcclxuICAgICAgICAgICAgICAgIHJldHVybiBuZXcgS2RJbnB1dFJhZGlvKF9pdGVtKTtcclxuICAgICAgICAgICAgY2FzZSAnY2hlY2tib3gnOlxyXG4gICAgICAgICAgICAgICAgcmV0dXJuIG5ldyBLZElucHV0Q2hlY2tib3goX2l0ZW0pO1xyXG4gICAgICAgICAgICBjYXNlICd0cmVlJzpcclxuICAgICAgICAgICAgICAgIHJldHVybiBuZXcgS2RJbnB1dFRyZWVEcm9wZG93bihfaXRlbSk7XHJcbiAgICAgICAgICAgIGNhc2UgJ3NsaWRlcic6XHJcbiAgICAgICAgICAgICAgICByZXR1cm4gbmV3IEtkSW5wdXRTbGlkZXIoX2l0ZW0pO1xyXG4gICAgICAgICAgICBjYXNlICdtdWx0aS10YWJsZSc6XHJcbiAgICAgICAgICAgICAgICByZXR1cm4gbmV3IEtkSW5wdXRNdWx0aVNlbGVjdFRhYmxlKF9pdGVtKTtcclxuICAgICAgICAgICAgY2FzZSAnc2VjdGlvbic6XHJcbiAgICAgICAgICAgICAgICByZXR1cm4gbmV3IEtkSW5wdXRTZWN0aW9uKF9pdGVtKTtcclxuICAgICAgICAgICAgY2FzZSAnc3ltYm9sJzpcclxuICAgICAgICAgICAgICAgIHJldHVybiBuZXcgS2RJbnB1dFN5bWJvbChfaXRlbSk7XHJcbiAgICAgICAgICAgIGNhc2UgJ3RhYmxlJzpcclxuICAgICAgICAgICAgICAgIHJldHVybiBuZXcgS2RJbnB1dFRhYmxlKF9pdGVtKTtcclxuICAgICAgICAgICAgY2FzZSAnYnV0dG9uLWdyb3VwJzpcclxuICAgICAgICAgICAgICAgIHJldHVybiBuZXcgS2RJbnB1dEJ1dHRvbkdyb3VwKF9pdGVtKTtcclxuICAgICAgICAgICAgZGVmYXVsdDpcclxuICAgICAgICAgICAgICAgIHJldHVybiBuZXcgS2RJbnB1dFRleHQoX2l0ZW0pO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxufVxyXG4iXX0=