import { Component, Input, Output, EventEmitter, ViewChildren, ElementRef } from '@angular/core';
import { timer } from 'rxjs';
import { KdInput } from '../kd-angular-input/kd-angular-input';
import { KdInputControlService } from '../kd-angular-input/src/kd-angular-form.control';
import { KdFormEvent } from './src/kd-form-event';
import { KdDomElemSvc, KdConvertionSvc } from '../kd-common/index';
import { KdViewSvc } from './kd-angular-view-svc';
export class KdView {
    constructor(_dfControl, _formEvent, _domSvc, _kdViewSvc, _convertSvc, _elementRef) {
        this._dfControl = _dfControl;
        this._formEvent = _formEvent;
        this._domSvc = _domSvc;
        this._kdViewSvc = _kdViewSvc;
        this._convertSvc = _convertSvc;
        this._elementRef = _elementRef;
        this._dfQuestions = [];
        this._formBtn = [];
        this._firstLoad = true;
        this.detectFrom = new EventEmitter();
        this.detectGridQuestion = new EventEmitter();
        this.submitEvent = new EventEmitter();
        this.resetEvent = new EventEmitter();
        this.buttonEvent = new EventEmitter();
        this.gridCellChanged = new EventEmitter();
        this.gridButtonClicked = new EventEmitter();
    }
    ngOnInit() {
        this._displayType = this.displayType; // (typeof this.displayType !== 'undefined') ? this.displayType : 'view';
        this.isStackedFrom = this._displayType === 'stacked-form';
        this._setQuestions();
        this._setButtons();
        this._updateFormApi();
        this._formVisibleSub = this._formEvent.onSetVisiableInput().subscribe(val => {
            for (let i = 0; i < this._dfQuestions.length; i++) {
                if (this._dfQuestions[i].key === val.key) {
                    this._dfQuestions[i].setVisible(val.visible);
                    break;
                }
            }
        });
        this._formDropdownSub = this._formEvent.onSetDropdownList().subscribe(val => {
            for (let i = 0; i < this._dfQuestions.length; i++) {
                if (this._dfQuestions[i].key === val.key) {
                    this._dfQuestions[i].setOptions(val.options);
                    break;
                }
            }
        });
        this._firstLoad = false;
        // console.log('KdView - this is the view just initialized', this.inputData);
    }
    ngOnChanges() {
        if (!this._firstLoad) {
            // console.log('KdView - this is the view change event', this.inputData);
            this._displayType = (typeof this.displayType !== 'undefined') ? this.displayType : 'view';
            this._setQuestions();
            this._setButtons();
        }
    }
    ngOnDestroy() {
        if (this._formVisibleSub)
            this._formVisibleSub.unsubscribe();
        if (this._formDropdownSub)
            this._formDropdownSub.unsubscribe();
    }
    getInputProperty(key, propertyName) {
        for (let i = 0; i < this._dfQuestions.length; i++) {
            if (this._dfQuestions[i].getProperty('key') === key)
                return this._dfQuestions[i].getProperty(propertyName);
        }
    }
    setInputProperty(key, propertyName, data) {
        for (let i = 0; i < this._dfQuestions.length; i++) {
            if (this._dfQuestions[i].getProperty('key') === key) {
                if (propertyName !== 'visible') {
                    this._dfQuestions[i].setProperty(propertyName, data);
                }
                else {
                    this._dfQuestions[i].setVisible(data);
                }
                break;
            }
        }
    }
    resetGridHeight(_gridId) {
        this.inputComponent.forEach((item) => {
            if (_gridId === item.question.getProperty('key')) {
                item.resetHeight();
            }
        });
    }
    ///// Table controltype
    updateTableCell(_questionKey, _cellParams) {
        this.inputComponent.forEach((item) => {
            if (_questionKey === item.question.getProperty('key')) {
                item.setTableCellData(_cellParams);
            }
        });
    }
    updateTableCellProperty(_questionKey, _cellParams) {
        this.inputComponent.forEach((item) => {
            if (_questionKey === item.question.getProperty('key')) {
                item.setTableCellQuestionProperty(_cellParams);
            }
        });
    }
    //////// till here
    setButtonDisabled(_type, _disabled) {
        for (let i = 0; i < this._formBtn.length; i++) {
            if (_type === this._formBtn[i].type) {
                this._formBtn[i].disabled = _disabled;
                this._formBtn = this._formBtn.slice();
            }
        }
    }
    isFormOrStackedForm() {
        if (this._displayType === 'form' || this._displayType === 'stacked-form') {
            return this._displayType;
        }
        else {
            return '-';
        }
    }
    // change to public due to lint
    changeDetectForm(_question) {
        this.detectFrom.emit(_question);
    }
    // change to public due to lint
    changeDetectFromGrid(_gridCellQuestion) {
        this.detectGridQuestion.emit(_gridCellQuestion);
    }
    /************************ Dynamic Form API updates *************************/
    _updateFormApi() {
        if (typeof this.api === 'undefined') {
            console.warn('KdView warning: No api object is passed in. No API will be initialize');
            return;
        }
        this.api.submitForm = () => {
            this._submitClick();
        };
        this.api.setProperty = (_questionKey, _property, _data) => {
            for (let i = 0; i < this._dfQuestions.length; i++) {
                if (this._dfQuestions[i].getProperty('key') === _questionKey) {
                    this._dfQuestions[i].setProperty(_property, _data);
                    break;
                }
            }
        };
        this.api.getProperty = (_questionKey, _property) => {
            for (let i = 0; i < this._dfQuestions.length; i++) {
                if (this._dfQuestions[i].getProperty('key') === _questionKey) {
                    return this._dfQuestions[i].getProperty(_property);
                }
            }
        };
        this.api.table = (_questionKey) => {
            let tableApi;
            for (let i = 0; i < this._dfQuestions.length; ++i) {
                if (this._dfQuestions[i].getProperty('key') === _questionKey) {
                    tableApi = this._dfQuestions[i].getProperty('api');
                    break;
                }
            }
            return {
                setTableCellInputProperty: (_formParams) => {
                    tableApi.dynamicForm.setProperty(_formParams);
                },
                updateTableCellProperty: (_cellParams) => {
                    tableApi.general.updateCell(_cellParams);
                },
                getTableCellInputProperty: (_formParams) => {
                    tableApi.dynamicForm.getProperty(_formParams);
                },
                addRow: (_rows, _scrollToVisible = false) => {
                    tableApi.general.addRows(_rows, _scrollToVisible);
                },
                deleteRows: (_id) => {
                    tableApi.general.deleteRows(_id);
                },
                clearError: () => {
                    tableApi.dynamicForm.clearAllError();
                },
                setButtonDisabled: (_buttonType, _toDisabled) => {
                    tableApi.general.setButtonDisabled(_buttonType, _toDisabled);
                }
            };
        };
        this.api.treedropdown = (_questionKey) => {
            let treeApi;
            for (let i = 0; i < this._dfQuestions.length; ++i) {
                if (this._dfQuestions[i].getProperty('key') === _questionKey) {
                    treeApi = this._dfQuestions[i].getProperty('api');
                    break;
                }
            }
            return treeApi;
        };
        this.api.sliderApi = (_questionKey) => {
            let sliderApi;
            for (let i = 0; i < this._dfQuestions.length; ++i) {
                if (this._dfQuestions[i].getProperty('key') === _questionKey) {
                    sliderApi = this._dfQuestions[i].getProperty('api');
                    break;
                }
            }
            return sliderApi;
        };
    }
    _btnClick(_btn) {
        if (_btn.type === 'reset')
            this._resetForm();
        else if (_btn.type !== 'submit')
            this.buttonEvent.emit(_btn);
        // if(typeof _btn.callback === 'function') _btn.callback(this._form.value);
        // else if(typeof _btn.callback === 'undefined' && _btn.type !== 'submit') console.error('Please provide callback');
    }
    _resetError() {
        for (let i = 0; i < this._dfQuestions.length; ++i) {
            this._dfQuestions[i].setProperty('errors', []);
        }
    }
    _getFormValidationError() {
        for (let i = 0; i < this._dfQuestions.length; ++i) {
            this._dfQuestions[i].setProperty('errors', []);
            let errorArr = [];
            const errors = this._form.get(this._dfQuestions[i].getProperty('key')).errors;
            if (errors !== null) {
                for (let key in errors) {
                    if (errors.hasOwnProperty(key)) {
                        errorArr.push(errors[key]);
                    }
                }
                this._dfQuestions[i].setProperty('errors', errorArr);
            }
        }
    }
    _submitClick() {
        let updatedForm = this._updateFormValue(this._dfQuestions, this._form.value);
        if (this._form.valid) {
            this.submitEvent.emit(updatedForm);
            this._resetError();
        }
        else {
            this._getFormValidationError();
        }
    }
    // private _submitClick(): void {
    //     let updatedForm: any = this._updateFormValue(this._dfQuestions, this._form.value);
    //     this.submitEvent.emit(updatedForm);
    // }
    _resetForm() {
        this._setQuestions();
        let contentBody = (this._domSvc.isMobile()) ? document.body.querySelector('.main-wrapper') : document.body.querySelector('.content-area');
        contentBody.scrollTop = 0;
        this.resetEvent.emit();
    }
    _setQuestions() {
        this._form = this._dfControl.emptyFormGroup();
        timer(50).subscribe(() => {
            this._dfQuestions = this._kdViewSvc.convertDataType(this.inputData, this._convertSvc);
            this._form = this._dfControl.toFormGroup(this._dfQuestions);
        });
    }
    _setButtons() {
        this._formBtn = (typeof this.button === 'undefined') ? this._setDefaultBtn() : this._setCustomBtn(this.button);
    }
    _setDefaultBtn() {
        let defaultBtn = [{
                type: 'submit',
                name: 'Submit',
                icon: 'kd-check',
                class: 'btn-text',
                disabled: false
            }, {
                type: 'reset',
                name: 'Reset',
                class: 'btn-outline',
                icon: 'kd-cross',
                disabled: false
            }];
        return defaultBtn;
    }
    _setCustomBtn(_btn) {
        let updatedBtn = [];
        let buttonLength = (this.button.length > 4) ? 4 : this.button.length;
        for (let i = 0; i < buttonLength; i++) {
            let item = _btn[i];
            if (typeof item.name === 'undefined')
                item.name = 'Undefined';
            if (typeof item.class === 'undefined')
                item.class = 'btn btn-text';
            if (typeof item.type === 'undefined')
                item.type = 'button';
            if (typeof item.disabled === 'undefined')
                item.disabled = false;
            if (item.type === 'reset') {
                item.callback = () => {
                    this._resetForm();
                };
            }
            updatedBtn.push(item);
        }
        return updatedBtn;
    }
    _updateFormValue(_question, _formValue) {
        let updatedFormVal = Object.assign({}, _formValue);
        for (let i = 0; i < _question.length; i++) {
            if (_question[i].controlType === 'section' && updatedFormVal && typeof updatedFormVal[_question[i].key] !== 'undefined') {
                delete updatedFormVal[_question[i].key];
            }
            else if (typeof _question[i].disabled !== 'undefined' && _question[i].disabled) {
                delete updatedFormVal[_question[i].key];
            }
        }
        return updatedFormVal;
    }
    /// table controltype
    _gridCellValueChanged(_emitParams) {
        this.gridCellChanged.emit(_emitParams);
    }
    _gridButtonClicked(_emitParams) {
        this.gridButtonClicked.emit(_emitParams);
    }
}
KdView.decorators = [
    { type: Component, args: [{
                selector: 'kd-view',
                template: "<div class='section-header'>{{_displayType}}</div>\r\n<ng-container [ngSwitch]=\"_displayType\">\r\n\r\n    <ng-container *ngSwitchCase=\"isFormOrStackedForm()\" >\r\n        <form class=\"form-vertical kdx\" [class.stacked]='isStackedFrom' *ngIf=\"_dfQuestions.length>0\" [formGroup]=\"_form\" (ngSubmit)=\"_submitClick()\">\r\n            <div *ngFor=\"let question of _dfQuestions\" class=\"form-row\" [class.section-header]=\"question.controlType == 'section'\">\r\n\r\n                <kd-input \r\n                    [question]=\"question\" \r\n                    [form]=\"_form\" \r\n                    (changeDetectFromQuestion)=\"changeDetectForm($event)\" \r\n                    (changeDetectFromGrid)=\"changeDetectFromGrid($event)\" \r\n                    (gridCellValueChanged)=\"_gridCellValueChanged($event)\"\r\n                    (gridButtonClicked)=\"_gridButtonClicked($event)\"\r\n                ></kd-input>\r\n            </div>\r\n            <div *ngIf=\"_formBtn.length>0\" class=\"form-buttons\">\r\n                <div class=\"button-label\"></div>\r\n                <button *ngFor=\"let btn of _formBtn\" [type]=\"(btn.type=='submit')?'submit':'button'\" class=\"btn btn-icon\" [ngClass]=\"btn.class\" (click)=\"_btnClick(btn)\" [disabled]=\"btn.disabled\">\r\n                    <i [class]=\"btn.icon\"></i>\r\n                    <span>{{btn.name}}</span>\r\n                </button>\r\n            </div>\r\n        </form>\r\n    </ng-container>\r\n\r\n    <ng-container *ngSwitchCase=\"'horizontal-form'\">\r\n        <div *ngIf=\"_dfQuestions.length>0\" class=\"form-horizontal-wrapper\">\r\n            <form class=\"form-horizontal\" [formGroup]=\"_form\">\r\n                <div *ngFor=\"let question of _dfQuestions\" class=\"form-row\">\r\n                    <kd-input [question]=\"question\" [form]=\"_form\" [horizontal]=\"true\" (changeDetectFromQuestion)=\"changeDetectForm($event)\"></kd-input>\r\n                </div>\r\n            </form>\r\n        </div>\r\n    </ng-container>\r\n\r\n    <ng-container *ngSwitchDefault> \r\n        <!-- View -->\r\n        <div [ngClass]=\"item.controlType!='section' ? 'kdx-view-list':'section-header' \" *ngFor=\"let item of _dfQuestions\">\r\n    <!-- <div class=\"view-list\" *ngFor=\"let item of _dfQuestions\"> -->\r\n            <h6 *ngIf=\"item.controlType=='section'\" >{{item.label}}</h6>\r\n            \r\n            <div *ngIf=\"item.visible && item.controlType!='section'\">\r\n                <div class=\"kdx-view-label\">{{item.label}}</div>\r\n                <div class=\"view-data\"  [ngSwitch]=\"item.controlType\">\r\n                    <div *ngSwitchCase=\"'file-input'\">\r\n                        <kd-placeholder \r\n                            *ngIf=\"item.config.fileType == 'image' && item.config.preview\"\r\n                            [config]='item.config.imageConfig'\r\n                            [value]='item.value'\r\n                        ></kd-placeholder>\r\n                        <div *ngIf=\"item.config.fileType != 'image' || !item.config.preview\">\r\n                            <a [href]=\"item.value.src\" style=\"text-decoration: none;\" placement=\"right\" ngbTooltip=\"Download\" container=\"body\" target=\"_blank\"> \r\n                                <i class=\"fa fa-paperclip\"></i>\r\n                                {{item.value.filename}}\r\n                            </a>\r\n                        </div>\r\n                    </div>\r\n                    <div *ngSwitchCase=\"'table'\" class=\"kdx-input-table-wrapper\">\r\n                        <kd-table [config]='item.config' [row]='item.row' [column]='item.column'></kd-table>\r\n                    </div>\r\n                    <div *ngSwitchCase=\"'symbol'\">\r\n                        <i [ngClass]=\"item.value\"></i>\r\n                    </div>\r\n                    <div *ngSwitchDefault [class]=\"item.class\">{{item.value}}</div>\r\n                    <i [class]=\"item.class\"></i>\r\n                </div>\r\n            </div>\r\n        </div>\r\n    </ng-container>\r\n\r\n</ng-container>\r\n\r\n<!-- \r\n<div *ngIf=\"_displayType!='form' && _displayType !='horizontal-form'\">\r\n    <div [ngClass]=\"item.controlType!='section' ? 'kdx-view-list':'section-header' \" *ngFor=\"let item of _dfQuestions\">\r\n        <h6 *ngIf=\"item.controlType=='section'\" >{{item.label}}</h6>\r\n        \r\n        <div *ngIf=\"item.visible && item.controlType!='section'\">\r\n            <div class=\"kdx-view-label\">{{item.label}}</div>\r\n            <div class=\"view-data\"  [ngSwitch]=\"item.controlType\">\r\n                <div *ngSwitchCase=\"'file-input'\">\r\n                    <kd-placeholder \r\n                        *ngIf=\"item.config.fileType == 'image' && item.config.preview\"\r\n                        [config]='item.config.imageConfig'\r\n                        [value]='item.value'\r\n                    ></kd-placeholder>\r\n                    <div *ngIf=\"item.config.fileType != 'image' || !item.config.preview\">\r\n                        <a [href]=\"item.value.src\" style=\"text-decoration: none;\" placement=\"right\" ngbTooltip=\"Download\" container=\"body\" target=\"_blank\"> \r\n                            <i class=\"fa fa-paperclip\"></i>\r\n                            {{item.value.filename}}\r\n                        </a>\r\n                    </div>\r\n                </div>\r\n                <div *ngSwitchCase=\"'table'\" class=\"kdx-input-table-wrapper\">\r\n                    <kd-table [config]='item.config' [row]='item.row' [column]='item.column'></kd-table>\r\n                </div>\r\n                <div *ngSwitchCase=\"'symbol'\">\r\n                    <i [ngClass]=\"item.value\"></i>\r\n                </div>\r\n                <div *ngSwitchDefault [class]=\"item.class\">{{item.value}}</div>\r\n                <i [class]=\"item.class\"></i>\r\n            </div>\r\n        </div>\r\n    </div>\r\n</div>\r\n\r\n<form class=\"form-vertical kdx\" *ngIf=\"_displayType=='form' && _dfQuestions.length>0\" [formGroup]=\"_form\" (ngSubmit)=\"_submitClick()\">\r\n    <div *ngFor=\"let question of _dfQuestions\" class=\"form-row\" [class.section-header]=\"question.controlType == 'section'\">\r\n\r\n        <kd-input \r\n            [question]=\"question\" \r\n            [form]=\"_form\" \r\n            (changeDetectFromQuestion)=\"changeDetectForm($event)\" \r\n            (changeDetectFromGrid)=\"changeDetectFromGrid($event)\" \r\n            (gridCellValueChanged)=\"_gridCellValueChanged($event)\"\r\n            (gridButtonClicked)=\"_gridButtonClicked($event)\"\r\n        ></kd-input>\r\n    </div>\r\n    <div *ngIf=\"_formBtn.length>0\" class=\"form-buttons\">\r\n        <div class=\"button-label\"></div>\r\n        <button *ngFor=\"let btn of _formBtn\" [type]=\"(btn.type=='submit')?'submit':'button'\" class=\"btn btn-icon\" [ngClass]=\"btn.class\" (click)=\"_btnClick(btn)\" [disabled]=\"btn.disabled\">\r\n            <i [class]=\"btn.icon\"></i>\r\n            <span>{{btn.name}}</span>\r\n        </button>\r\n    </div>\r\n</form>\r\n\r\n<div *ngIf=\"_displayType=='horizontal-form' && _dfQuestions.length>0\" class=\"form-horizontal-wrapper\">\r\n    <form class=\"form-horizontal\" [formGroup]=\"_form\">\r\n        <div *ngFor=\"let question of _dfQuestions\" class=\"form-row\">\r\n            <kd-input [question]=\"question\" [form]=\"_form\" [horizontal]=\"true\" (changeDetectFromQuestion)=\"changeDetectForm($event)\"></kd-input>\r\n        </div>\r\n    </form>\r\n</div>\r\n -->",
                providers: [KdInputControlService, KdFormEvent, KdDomElemSvc, KdViewSvc, KdConvertionSvc],
                host: {
                    'class': 'kdx-view'
                }
            },] }
];
KdView.ctorParameters = () => [
    { type: KdInputControlService },
    { type: KdFormEvent },
    { type: KdDomElemSvc },
    { type: KdViewSvc },
    { type: KdConvertionSvc },
    { type: ElementRef }
];
KdView.propDecorators = {
    inputData: [{ type: Input }],
    button: [{ type: Input }],
    displayType: [{ type: Input }],
    api: [{ type: Input }],
    detectFrom: [{ type: Output }],
    detectGridQuestion: [{ type: Output }],
    submitEvent: [{ type: Output }],
    resetEvent: [{ type: Output }],
    buttonEvent: [{ type: Output }],
    inputComponent: [{ type: ViewChildren, args: [KdInput,] }],
    gridCellChanged: [{ type: Output }],
    gridButtonClicked: [{ type: Output }]
};
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoia2QtYW5ndWxhci12aWV3LmpzIiwic291cmNlUm9vdCI6IkM6L3hhbXBwL2h0ZG9jcy9TdHlsZWd1aWRlL2lvc3RnLW9wZW5lbWlzLXN0eWxlZ3VpZGUvcHJvamVjdHMvb3BlbmVtaXMtc3R5bGVndWlkZS1saWIvc3JjLyIsInNvdXJjZXMiOlsia2QtY29tcG9uZW50cy9rZC1hbmd1bGFyLXZpZXcva2QtYW5ndWxhci12aWV3LnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBLE9BQU8sRUFDSCxTQUFTLEVBQ1QsS0FBSyxFQUNMLE1BQU0sRUFDTixZQUFZLEVBSVosWUFBWSxFQUNaLFVBQVUsRUFDYixNQUFNLGVBQWUsQ0FBQztBQUN2QixPQUFPLEVBQUUsS0FBSyxFQUFrQixNQUFNLE1BQU0sQ0FBQztBQUU3QyxPQUFPLEVBQUUsT0FBTyxFQUFFLE1BQU0sc0NBQXNDLENBQUM7QUFFL0QsT0FBTyxFQUFFLHFCQUFxQixFQUFFLE1BQU0saURBQWlELENBQUM7QUFDeEYsT0FBTyxFQUFFLFdBQVcsRUFBRSxNQUFNLHFCQUFxQixDQUFDO0FBQ2xELE9BQU8sRUFBRSxZQUFZLEVBQUUsZUFBZSxFQUFFLE1BQU0sb0JBQW9CLENBQUM7QUFDbkUsT0FBTyxFQUFFLFNBQVMsRUFBRSxNQUFNLHVCQUF1QixDQUFDO0FBdUJsRCxNQUFNLE9BQU8sTUFBTTtJQXlCZixZQUNZLFVBQWlDLEVBQ2pDLFVBQXVCLEVBQ3ZCLE9BQXFCLEVBQ3JCLFVBQXFCLEVBQ3JCLFdBQTRCLEVBQzVCLFdBQXVCO1FBTHZCLGVBQVUsR0FBVixVQUFVLENBQXVCO1FBQ2pDLGVBQVUsR0FBVixVQUFVLENBQWE7UUFDdkIsWUFBTyxHQUFQLE9BQU8sQ0FBYztRQUNyQixlQUFVLEdBQVYsVUFBVSxDQUFXO1FBQ3JCLGdCQUFXLEdBQVgsV0FBVyxDQUFpQjtRQUM1QixnQkFBVyxHQUFYLFdBQVcsQ0FBWTtRQTlCNUIsaUJBQVksR0FBZSxFQUFFLENBQUM7UUFLOUIsYUFBUSxHQUFlLEVBQUUsQ0FBQztRQUN6QixlQUFVLEdBQVksSUFBSSxDQUFDO1FBUXpCLGVBQVUsR0FBc0IsSUFBSSxZQUFZLEVBQUUsQ0FBQztRQUNuRCx1QkFBa0IsR0FBc0IsSUFBSSxZQUFZLEVBQUUsQ0FBQztRQUMzRCxnQkFBVyxHQUFzQixJQUFJLFlBQVksRUFBRSxDQUFDO1FBQ3BELGVBQVUsR0FBc0IsSUFBSSxZQUFZLEVBQUUsQ0FBQztRQUNuRCxnQkFBVyxHQUFzQixJQUFJLFlBQVksRUFBRSxDQUFDO1FBR3BELG9CQUFlLEdBQXVFLElBQUksWUFBWSxFQUFFLENBQUM7UUFDekcsc0JBQWlCLEdBQWtFLElBQUksWUFBWSxFQUFFLENBQUM7SUFTNUcsQ0FBQztJQUVMLFFBQVE7UUFFSixJQUFJLENBQUMsWUFBWSxHQUFHLElBQUksQ0FBQyxXQUFXLENBQUMsQ0FBQyx5RUFBeUU7UUFDL0csSUFBSSxDQUFDLGFBQWEsR0FBRyxJQUFJLENBQUMsWUFBWSxLQUFLLGNBQWMsQ0FBQztRQUUxRCxJQUFJLENBQUMsYUFBYSxFQUFFLENBQUM7UUFDckIsSUFBSSxDQUFDLFdBQVcsRUFBRSxDQUFDO1FBQ25CLElBQUksQ0FBQyxjQUFjLEVBQUUsQ0FBQztRQUV0QixJQUFJLENBQUMsZUFBZSxHQUFHLElBQUksQ0FBQyxVQUFVLENBQUMsa0JBQWtCLEVBQUUsQ0FBQyxTQUFTLENBQUMsR0FBRyxDQUFDLEVBQUU7WUFDeEUsS0FBSyxJQUFJLENBQUMsR0FBVyxDQUFDLEVBQUUsQ0FBQyxHQUFHLElBQUksQ0FBQyxZQUFZLENBQUMsTUFBTSxFQUFFLENBQUMsRUFBRSxFQUFFO2dCQUN2RCxJQUFJLElBQUksQ0FBQyxZQUFZLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxLQUFLLEdBQUcsQ0FBQyxHQUFHLEVBQUU7b0JBQ3RDLElBQUksQ0FBQyxZQUFZLENBQUMsQ0FBQyxDQUFDLENBQUMsVUFBVSxDQUFDLEdBQUcsQ0FBQyxPQUFPLENBQUMsQ0FBQztvQkFDN0MsTUFBTTtpQkFDVDthQUNKO1FBQ0wsQ0FBQyxDQUFDLENBQUM7UUFFSCxJQUFJLENBQUMsZ0JBQWdCLEdBQUcsSUFBSSxDQUFDLFVBQVUsQ0FBQyxpQkFBaUIsRUFBRSxDQUFDLFNBQVMsQ0FBQyxHQUFHLENBQUMsRUFBRTtZQUN4RSxLQUFLLElBQUksQ0FBQyxHQUFXLENBQUMsRUFBRSxDQUFDLEdBQUcsSUFBSSxDQUFDLFlBQVksQ0FBQyxNQUFNLEVBQUUsQ0FBQyxFQUFFLEVBQUU7Z0JBQ3ZELElBQUksSUFBSSxDQUFDLFlBQVksQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLEtBQUssR0FBRyxDQUFDLEdBQUcsRUFBRTtvQkFDdEMsSUFBSSxDQUFDLFlBQVksQ0FBQyxDQUFDLENBQUMsQ0FBQyxVQUFVLENBQUMsR0FBRyxDQUFDLE9BQU8sQ0FBQyxDQUFDO29CQUM3QyxNQUFNO2lCQUNUO2FBQ0o7UUFDTCxDQUFDLENBQUMsQ0FBQztRQUVILElBQUksQ0FBQyxVQUFVLEdBQUcsS0FBSyxDQUFDO1FBQ3hCLDZFQUE2RTtJQUNqRixDQUFDO0lBRUQsV0FBVztRQUNQLElBQUksQ0FBQyxJQUFJLENBQUMsVUFBVSxFQUFFO1lBQ2xCLHlFQUF5RTtZQUN6RSxJQUFJLENBQUMsWUFBWSxHQUFHLENBQUMsT0FBTyxJQUFJLENBQUMsV0FBVyxLQUFLLFdBQVcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUM7WUFDMUYsSUFBSSxDQUFDLGFBQWEsRUFBRSxDQUFDO1lBQ3JCLElBQUksQ0FBQyxXQUFXLEVBQUUsQ0FBQztTQUN0QjtJQUNMLENBQUM7SUFFRCxXQUFXO1FBQ1AsSUFBRyxJQUFJLENBQUMsZUFBZTtZQUFFLElBQUksQ0FBQyxlQUFlLENBQUMsV0FBVyxFQUFFLENBQUM7UUFDNUQsSUFBRyxJQUFJLENBQUMsZ0JBQWdCO1lBQUUsSUFBSSxDQUFDLGdCQUFnQixDQUFDLFdBQVcsRUFBRSxDQUFDO0lBQ2xFLENBQUM7SUFFTSxnQkFBZ0IsQ0FBQyxHQUFXLEVBQUUsWUFBb0I7UUFDckQsS0FBSyxJQUFJLENBQUMsR0FBVyxDQUFDLEVBQUUsQ0FBQyxHQUFHLElBQUksQ0FBQyxZQUFZLENBQUMsTUFBTSxFQUFFLENBQUMsRUFBRSxFQUFFO1lBQ3ZELElBQUksSUFBSSxDQUFDLFlBQVksQ0FBQyxDQUFDLENBQUMsQ0FBQyxXQUFXLENBQUMsS0FBSyxDQUFDLEtBQUssR0FBRztnQkFBRSxPQUFPLElBQUksQ0FBQyxZQUFZLENBQUMsQ0FBQyxDQUFDLENBQUMsV0FBVyxDQUFDLFlBQVksQ0FBQyxDQUFDO1NBQzlHO0lBQ0wsQ0FBQztJQUVNLGdCQUFnQixDQUFDLEdBQVcsRUFBRSxZQUFvQixFQUFFLElBQVM7UUFDaEUsS0FBSyxJQUFJLENBQUMsR0FBVyxDQUFDLEVBQUUsQ0FBQyxHQUFHLElBQUksQ0FBQyxZQUFZLENBQUMsTUFBTSxFQUFFLENBQUMsRUFBRSxFQUFFO1lBQ3ZELElBQUksSUFBSSxDQUFDLFlBQVksQ0FBQyxDQUFDLENBQUMsQ0FBQyxXQUFXLENBQUMsS0FBSyxDQUFDLEtBQUssR0FBRyxFQUFFO2dCQUNqRCxJQUFJLFlBQVksS0FBSyxTQUFTLEVBQUU7b0JBQzVCLElBQUksQ0FBQyxZQUFZLENBQUMsQ0FBQyxDQUFDLENBQUMsV0FBVyxDQUFDLFlBQVksRUFBRSxJQUFJLENBQUMsQ0FBQztpQkFDeEQ7cUJBQ0k7b0JBQ0QsSUFBSSxDQUFDLFlBQVksQ0FBQyxDQUFDLENBQUMsQ0FBQyxVQUFVLENBQUMsSUFBSSxDQUFDLENBQUM7aUJBQ3pDO2dCQUNELE1BQU07YUFDVDtTQUNKO0lBQ0wsQ0FBQztJQUVNLGVBQWUsQ0FBQyxPQUFlO1FBQ2xDLElBQUksQ0FBQyxjQUFjLENBQUMsT0FBTyxDQUFDLENBQUMsSUFBYSxFQUFRLEVBQUU7WUFDaEQsSUFBSSxPQUFPLEtBQUssSUFBSSxDQUFDLFFBQVEsQ0FBQyxXQUFXLENBQUMsS0FBSyxDQUFDLEVBQUU7Z0JBQzlDLElBQUksQ0FBQyxXQUFXLEVBQUUsQ0FBQzthQUN0QjtRQUNMLENBQUMsQ0FBQyxDQUFDO0lBQ1AsQ0FBQztJQUVELHVCQUF1QjtJQUNoQixlQUFlLENBQUMsWUFBb0IsRUFBRSxXQUE2QjtRQUN0RSxJQUFJLENBQUMsY0FBYyxDQUFDLE9BQU8sQ0FBQyxDQUFDLElBQWEsRUFBUSxFQUFFO1lBQ2hELElBQUksWUFBWSxLQUFLLElBQUksQ0FBQyxRQUFRLENBQUMsV0FBVyxDQUFDLEtBQUssQ0FBQyxFQUFFO2dCQUNuRCxJQUFJLENBQUMsZ0JBQWdCLENBQUMsV0FBVyxDQUFDLENBQUM7YUFDdEM7UUFDTCxDQUFDLENBQUMsQ0FBQztJQUNQLENBQUM7SUFFTSx1QkFBdUIsQ0FBQyxZQUFvQixFQUFFLFdBQW1DO1FBQ3BGLElBQUksQ0FBQyxjQUFjLENBQUMsT0FBTyxDQUFDLENBQUMsSUFBYSxFQUFRLEVBQUU7WUFDaEQsSUFBSSxZQUFZLEtBQUssSUFBSSxDQUFDLFFBQVEsQ0FBQyxXQUFXLENBQUMsS0FBSyxDQUFDLEVBQUU7Z0JBQ25ELElBQUksQ0FBQyw0QkFBNEIsQ0FBQyxXQUFXLENBQUMsQ0FBQzthQUNsRDtRQUNMLENBQUMsQ0FBQyxDQUFDO0lBQ1AsQ0FBQztJQUNELGtCQUFrQjtJQUVYLGlCQUFpQixDQUFDLEtBQWEsRUFBRSxTQUFrQjtRQUN0RCxLQUFLLElBQUksQ0FBQyxHQUFXLENBQUMsRUFBRSxDQUFDLEdBQUcsSUFBSSxDQUFDLFFBQVEsQ0FBQyxNQUFNLEVBQUUsQ0FBQyxFQUFFLEVBQUU7WUFDbkQsSUFBSSxLQUFLLEtBQUssSUFBSSxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLEVBQUU7Z0JBQ2pDLElBQUksQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxHQUFHLFNBQVMsQ0FBQztnQkFDdEMsSUFBSSxDQUFDLFFBQVEsR0FBRyxJQUFJLENBQUMsUUFBUSxDQUFDLEtBQUssRUFBRSxDQUFDO2FBQ3pDO1NBQ0o7SUFDTCxDQUFDO0lBRU0sbUJBQW1CO1FBQ3RCLElBQUksSUFBSSxDQUFDLFlBQVksS0FBSyxNQUFNLElBQUksSUFBSSxDQUFDLFlBQVksS0FBSyxjQUFjLEVBQUU7WUFDdEUsT0FBTyxJQUFJLENBQUMsWUFBWSxDQUFDO1NBQzVCO2FBQU07WUFDSCxPQUFPLEdBQUcsQ0FBQztTQUNkO0lBQ0wsQ0FBQztJQUVELCtCQUErQjtJQUN4QixnQkFBZ0IsQ0FBQyxTQUF5QjtRQUM3QyxJQUFJLENBQUMsVUFBVSxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsQ0FBQztJQUNwQyxDQUFDO0lBRUQsK0JBQStCO0lBQ3hCLG9CQUFvQixDQUFDLGlCQUFzQjtRQUM5QyxJQUFJLENBQUMsa0JBQWtCLENBQUMsSUFBSSxDQUFDLGlCQUFpQixDQUFDLENBQUM7SUFDcEQsQ0FBQztJQUVELDZFQUE2RTtJQUNyRSxjQUFjO1FBQ2xCLElBQUksT0FBTyxJQUFJLENBQUMsR0FBRyxLQUFLLFdBQVcsRUFBRTtZQUNqQyxPQUFPLENBQUMsSUFBSSxDQUFDLHVFQUF1RSxDQUFDLENBQUM7WUFDdEYsT0FBTztTQUNWO1FBRUQsSUFBSSxDQUFDLEdBQUcsQ0FBQyxVQUFVLEdBQUcsR0FBUyxFQUFFO1lBQzdCLElBQUksQ0FBQyxZQUFZLEVBQUUsQ0FBQztRQUN4QixDQUFDLENBQUM7UUFFRixJQUFJLENBQUMsR0FBRyxDQUFDLFdBQVcsR0FBRyxDQUFDLFlBQW9CLEVBQUUsU0FBaUIsRUFBRSxLQUFVLEVBQVEsRUFBRTtZQUNqRixLQUFLLElBQUksQ0FBQyxHQUFXLENBQUMsRUFBRSxDQUFDLEdBQUcsSUFBSSxDQUFDLFlBQVksQ0FBQyxNQUFNLEVBQUUsQ0FBQyxFQUFFLEVBQUU7Z0JBQ3ZELElBQUksSUFBSSxDQUFDLFlBQVksQ0FBQyxDQUFDLENBQUMsQ0FBQyxXQUFXLENBQUMsS0FBSyxDQUFDLEtBQUssWUFBWSxFQUFFO29CQUMxRCxJQUFJLENBQUMsWUFBWSxDQUFDLENBQUMsQ0FBQyxDQUFDLFdBQVcsQ0FBQyxTQUFTLEVBQUUsS0FBSyxDQUFDLENBQUM7b0JBQ25ELE1BQU07aUJBQ1Q7YUFDSjtRQUNMLENBQUMsQ0FBQztRQUVGLElBQUksQ0FBQyxHQUFHLENBQUMsV0FBVyxHQUFHLENBQUMsWUFBb0IsRUFBRSxTQUFpQixFQUFPLEVBQUU7WUFDcEUsS0FBSyxJQUFJLENBQUMsR0FBVyxDQUFDLEVBQUUsQ0FBQyxHQUFHLElBQUksQ0FBQyxZQUFZLENBQUMsTUFBTSxFQUFFLENBQUMsRUFBRSxFQUFFO2dCQUN2RCxJQUFJLElBQUksQ0FBQyxZQUFZLENBQUMsQ0FBQyxDQUFDLENBQUMsV0FBVyxDQUFDLEtBQUssQ0FBQyxLQUFLLFlBQVksRUFBRTtvQkFDMUQsT0FBTyxJQUFJLENBQUMsWUFBWSxDQUFDLENBQUMsQ0FBQyxDQUFDLFdBQVcsQ0FBQyxTQUFTLENBQUMsQ0FBQztpQkFDdEQ7YUFDSjtRQUNMLENBQUMsQ0FBQztRQUVGLElBQUksQ0FBQyxHQUFHLENBQUMsS0FBSyxHQUFHLENBQUMsWUFBb0IsRUFBd0IsRUFBRTtZQUM1RCxJQUFJLFFBQW1CLENBQUM7WUFFeEIsS0FBSyxJQUFJLENBQUMsR0FBVyxDQUFDLEVBQUUsQ0FBQyxHQUFHLElBQUksQ0FBQyxZQUFZLENBQUMsTUFBTSxFQUFFLEVBQUUsQ0FBQyxFQUFFO2dCQUN2RCxJQUFJLElBQUksQ0FBQyxZQUFZLENBQUMsQ0FBQyxDQUFDLENBQUMsV0FBVyxDQUFDLEtBQUssQ0FBQyxLQUFLLFlBQVksRUFBRTtvQkFDMUQsUUFBUSxHQUFHLElBQUksQ0FBQyxZQUFZLENBQUMsQ0FBQyxDQUFDLENBQUMsV0FBVyxDQUFDLEtBQUssQ0FBQyxDQUFDO29CQUNuRCxNQUFNO2lCQUNUO2FBQ0o7WUFFRCxPQUFPO2dCQUNILHlCQUF5QixFQUFFLENBQUMsV0FBbUMsRUFBUSxFQUFFO29CQUNyRSxRQUFRLENBQUMsV0FBVyxDQUFDLFdBQVcsQ0FBQyxXQUFXLENBQUMsQ0FBQztnQkFDbEQsQ0FBQztnQkFDRCx1QkFBdUIsRUFBRSxDQUFDLFdBQTZCLEVBQVEsRUFBRTtvQkFDN0QsUUFBUSxDQUFDLE9BQU8sQ0FBQyxVQUFVLENBQUMsV0FBVyxDQUFDLENBQUM7Z0JBQzdDLENBQUM7Z0JBQ0QseUJBQXlCLEVBQUUsQ0FBQyxXQUFtQyxFQUFRLEVBQUU7b0JBQ3JFLFFBQVEsQ0FBQyxXQUFXLENBQUMsV0FBVyxDQUFDLFdBQVcsQ0FBQyxDQUFDO2dCQUNsRCxDQUFDO2dCQUNELE1BQU0sRUFBRSxDQUFDLEtBQWlCLEVBQUUsbUJBQTRCLEtBQUssRUFBUSxFQUFFO29CQUNuRSxRQUFRLENBQUMsT0FBTyxDQUFDLE9BQU8sQ0FBQyxLQUFLLEVBQUUsZ0JBQWdCLENBQUMsQ0FBQztnQkFDdEQsQ0FBQztnQkFDRCxVQUFVLEVBQUUsQ0FBQyxHQUE2QyxFQUFRLEVBQUU7b0JBQ2hFLFFBQVEsQ0FBQyxPQUFPLENBQUMsVUFBVSxDQUFDLEdBQUcsQ0FBQyxDQUFDO2dCQUNyQyxDQUFDO2dCQUNELFVBQVUsRUFBRSxHQUFTLEVBQUU7b0JBQ25CLFFBQVEsQ0FBQyxXQUFXLENBQUMsYUFBYSxFQUFFLENBQUM7Z0JBQ3pDLENBQUM7Z0JBQ0QsaUJBQWlCLEVBQUUsQ0FBQyxXQUFtQixFQUFFLFdBQW9CLEVBQVEsRUFBRTtvQkFDbkUsUUFBUSxDQUFDLE9BQU8sQ0FBQyxpQkFBaUIsQ0FBQyxXQUFXLEVBQUUsV0FBVyxDQUFDLENBQUM7Z0JBQ2pFLENBQUM7YUFDSixDQUFDO1FBQ04sQ0FBQyxDQUFDO1FBRUYsSUFBSSxDQUFDLEdBQUcsQ0FBQyxZQUFZLEdBQUcsQ0FBQyxZQUFvQixFQUFZLEVBQUU7WUFDdkQsSUFBSSxPQUFpQixDQUFDO1lBQ3RCLEtBQUssSUFBSSxDQUFDLEdBQVcsQ0FBQyxFQUFFLENBQUMsR0FBRyxJQUFJLENBQUMsWUFBWSxDQUFDLE1BQU0sRUFBRSxFQUFFLENBQUMsRUFBRTtnQkFDdkQsSUFBSSxJQUFJLENBQUMsWUFBWSxDQUFDLENBQUMsQ0FBQyxDQUFDLFdBQVcsQ0FBQyxLQUFLLENBQUMsS0FBSyxZQUFZLEVBQUU7b0JBQzFELE9BQU8sR0FBRyxJQUFJLENBQUMsWUFBWSxDQUFDLENBQUMsQ0FBQyxDQUFDLFdBQVcsQ0FBQyxLQUFLLENBQUMsQ0FBQztvQkFDbEQsTUFBTTtpQkFDVDthQUNKO1lBQ0QsT0FBTyxPQUFPLENBQUM7UUFDbkIsQ0FBQyxDQUFDO1FBRUYsSUFBSSxDQUFDLEdBQUcsQ0FBQyxTQUFTLEdBQUcsQ0FBQyxZQUFvQixFQUFjLEVBQUU7WUFDdEQsSUFBSSxTQUFxQixDQUFDO1lBRTFCLEtBQUssSUFBSSxDQUFDLEdBQVcsQ0FBQyxFQUFFLENBQUMsR0FBRyxJQUFJLENBQUMsWUFBWSxDQUFDLE1BQU0sRUFBRSxFQUFFLENBQUMsRUFBRTtnQkFDdkQsSUFBSSxJQUFJLENBQUMsWUFBWSxDQUFDLENBQUMsQ0FBQyxDQUFDLFdBQVcsQ0FBQyxLQUFLLENBQUMsS0FBSyxZQUFZLEVBQUU7b0JBQzFELFNBQVMsR0FBRyxJQUFJLENBQUMsWUFBWSxDQUFDLENBQUMsQ0FBQyxDQUFDLFdBQVcsQ0FBQyxLQUFLLENBQUMsQ0FBQztvQkFDcEQsTUFBTTtpQkFDVDthQUNKO1lBRUQsT0FBTyxTQUFTLENBQUM7UUFDckIsQ0FBQyxDQUFDO0lBQ04sQ0FBQztJQUdNLFNBQVMsQ0FBQyxJQUFTO1FBQ3RCLElBQUksSUFBSSxDQUFDLElBQUksS0FBSyxPQUFPO1lBQUUsSUFBSSxDQUFDLFVBQVUsRUFBRSxDQUFDO2FBQ3hDLElBQUksSUFBSSxDQUFDLElBQUksS0FBSyxRQUFRO1lBQUUsSUFBSSxDQUFDLFdBQVcsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUM7UUFDN0QsMkVBQTJFO1FBQzNFLG9IQUFvSDtJQUN4SCxDQUFDO0lBRU8sV0FBVztRQUNmLEtBQUssSUFBSSxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsR0FBRyxJQUFJLENBQUMsWUFBWSxDQUFDLE1BQU0sRUFBRSxFQUFFLENBQUMsRUFBRTtZQUMvQyxJQUFJLENBQUMsWUFBWSxDQUFDLENBQUMsQ0FBQyxDQUFDLFdBQVcsQ0FBQyxRQUFRLEVBQUUsRUFBRSxDQUFDLENBQUM7U0FDbEQ7SUFDTCxDQUFDO0lBRU8sdUJBQXVCO1FBQzNCLEtBQUssSUFBSSxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsR0FBRyxJQUFJLENBQUMsWUFBWSxDQUFDLE1BQU0sRUFBRSxFQUFFLENBQUMsRUFBRTtZQUMvQyxJQUFJLENBQUMsWUFBWSxDQUFDLENBQUMsQ0FBQyxDQUFDLFdBQVcsQ0FBQyxRQUFRLEVBQUUsRUFBRSxDQUFDLENBQUM7WUFDL0MsSUFBSSxRQUFRLEdBQWtCLEVBQUUsQ0FBQztZQUNqQyxNQUFNLE1BQU0sR0FBTyxJQUFJLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsWUFBWSxDQUFDLENBQUMsQ0FBQyxDQUFDLFdBQVcsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQztZQUNsRixJQUFJLE1BQU0sS0FBSyxJQUFJLEVBQUU7Z0JBQ2pCLEtBQUssSUFBSSxHQUFHLElBQUksTUFBTSxFQUFFO29CQUNwQixJQUFJLE1BQU0sQ0FBQyxjQUFjLENBQUMsR0FBRyxDQUFDLEVBQUU7d0JBQzVCLFFBQVEsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUM7cUJBQzlCO2lCQUNKO2dCQUNELElBQUksQ0FBQyxZQUFZLENBQUMsQ0FBQyxDQUFDLENBQUMsV0FBVyxDQUFDLFFBQVEsRUFBRSxRQUFRLENBQUMsQ0FBQzthQUN4RDtTQUNKO0lBQ0wsQ0FBQztJQUVNLFlBQVk7UUFDZixJQUFJLFdBQVcsR0FBUSxJQUFJLENBQUMsZ0JBQWdCLENBQUMsSUFBSSxDQUFDLFlBQVksRUFBRSxJQUFJLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxDQUFDO1FBQ2xGLElBQUksSUFBSSxDQUFDLEtBQUssQ0FBQyxLQUFLLEVBQUU7WUFDbEIsSUFBSSxDQUFDLFdBQVcsQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFDLENBQUM7WUFDbkMsSUFBSSxDQUFDLFdBQVcsRUFBRSxDQUFDO1NBQ3RCO2FBQU07WUFDSCxJQUFJLENBQUMsdUJBQXVCLEVBQUUsQ0FBQztTQUNsQztJQUNMLENBQUM7SUFFRCxpQ0FBaUM7SUFDakMseUZBQXlGO0lBQ3pGLDBDQUEwQztJQUMxQyxJQUFJO0lBRUksVUFBVTtRQUNkLElBQUksQ0FBQyxhQUFhLEVBQUUsQ0FBQztRQUNyQixJQUFJLFdBQVcsR0FBWSxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsUUFBUSxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxhQUFhLENBQUMsZUFBZSxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsYUFBYSxDQUFDLGVBQWUsQ0FBQyxDQUFDO1FBQ25KLFdBQVcsQ0FBQyxTQUFTLEdBQUcsQ0FBQyxDQUFDO1FBQzFCLElBQUksQ0FBQyxVQUFVLENBQUMsSUFBSSxFQUFFLENBQUM7SUFDM0IsQ0FBQztJQUVPLGFBQWE7UUFDakIsSUFBSSxDQUFDLEtBQUssR0FBRyxJQUFJLENBQUMsVUFBVSxDQUFDLGNBQWMsRUFBRSxDQUFDO1FBQzlDLEtBQUssQ0FBQyxFQUFFLENBQUMsQ0FBQyxTQUFTLENBQUMsR0FBUyxFQUFFO1lBQzNCLElBQUksQ0FBQyxZQUFZLEdBQUcsSUFBSSxDQUFDLFVBQVUsQ0FBQyxlQUFlLENBQUMsSUFBSSxDQUFDLFNBQVMsRUFBRSxJQUFJLENBQUMsV0FBVyxDQUFDLENBQUM7WUFDdEYsSUFBSSxDQUFDLEtBQUssR0FBRyxJQUFJLENBQUMsVUFBVSxDQUFDLFdBQVcsQ0FBQyxJQUFJLENBQUMsWUFBWSxDQUFDLENBQUM7UUFDaEUsQ0FBQyxDQUFDLENBQUM7SUFDUCxDQUFDO0lBRU8sV0FBVztRQUNmLElBQUksQ0FBQyxRQUFRLEdBQUcsQ0FBQyxPQUFPLElBQUksQ0FBQyxNQUFNLEtBQUssV0FBVyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxjQUFjLEVBQUUsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLGFBQWEsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUM7SUFDbkgsQ0FBQztJQUVPLGNBQWM7UUFDbEIsSUFBSSxVQUFVLEdBQWUsQ0FBQztnQkFDMUIsSUFBSSxFQUFFLFFBQVE7Z0JBQ2QsSUFBSSxFQUFFLFFBQVE7Z0JBQ2QsSUFBSSxFQUFFLFVBQVU7Z0JBQ2hCLEtBQUssRUFBRSxVQUFVO2dCQUNqQixRQUFRLEVBQUUsS0FBSzthQUNsQixFQUFFO2dCQUNDLElBQUksRUFBRSxPQUFPO2dCQUNiLElBQUksRUFBRSxPQUFPO2dCQUNiLEtBQUssRUFBRSxhQUFhO2dCQUNwQixJQUFJLEVBQUUsVUFBVTtnQkFDaEIsUUFBUSxFQUFFLEtBQUs7YUFDbEIsQ0FBQyxDQUFDO1FBQ0gsT0FBTyxVQUFVLENBQUM7SUFDdEIsQ0FBQztJQUVPLGFBQWEsQ0FBQyxJQUFnQjtRQUNsQyxJQUFJLFVBQVUsR0FBZSxFQUFFLENBQUM7UUFDaEMsSUFBSSxZQUFZLEdBQVcsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLE1BQU0sR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQztRQUM3RSxLQUFLLElBQUksQ0FBQyxHQUFXLENBQUMsRUFBRSxDQUFDLEdBQUcsWUFBWSxFQUFFLENBQUMsRUFBRSxFQUFFO1lBQzNDLElBQUksSUFBSSxHQUFRLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQztZQUN4QixJQUFJLE9BQU8sSUFBSSxDQUFDLElBQUksS0FBSyxXQUFXO2dCQUFFLElBQUksQ0FBQyxJQUFJLEdBQUcsV0FBVyxDQUFDO1lBQzlELElBQUksT0FBTyxJQUFJLENBQUMsS0FBSyxLQUFLLFdBQVc7Z0JBQUUsSUFBSSxDQUFDLEtBQUssR0FBRyxjQUFjLENBQUM7WUFDbkUsSUFBSSxPQUFPLElBQUksQ0FBQyxJQUFJLEtBQUssV0FBVztnQkFBRSxJQUFJLENBQUMsSUFBSSxHQUFHLFFBQVEsQ0FBQztZQUMzRCxJQUFJLE9BQU8sSUFBSSxDQUFDLFFBQVEsS0FBSyxXQUFXO2dCQUFFLElBQUksQ0FBQyxRQUFRLEdBQUcsS0FBSyxDQUFDO1lBQ2hFLElBQUksSUFBSSxDQUFDLElBQUksS0FBSyxPQUFPLEVBQUU7Z0JBQ3ZCLElBQUksQ0FBQyxRQUFRLEdBQUcsR0FBUyxFQUFFO29CQUN2QixJQUFJLENBQUMsVUFBVSxFQUFFLENBQUM7Z0JBQ3RCLENBQUMsQ0FBQzthQUNMO1lBQ0QsVUFBVSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQztTQUN6QjtRQUNELE9BQU8sVUFBVSxDQUFDO0lBQ3RCLENBQUM7SUFFTyxnQkFBZ0IsQ0FBQyxTQUFxQixFQUFFLFVBQWU7UUFDM0QsSUFBSSxjQUFjLEdBQVEsTUFBTSxDQUFDLE1BQU0sQ0FBQyxFQUFFLEVBQUUsVUFBVSxDQUFDLENBQUM7UUFDeEQsS0FBSyxJQUFJLENBQUMsR0FBVyxDQUFDLEVBQUUsQ0FBQyxHQUFHLFNBQVMsQ0FBQyxNQUFNLEVBQUUsQ0FBQyxFQUFFLEVBQUU7WUFDL0MsSUFBSSxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsV0FBVyxLQUFLLFNBQVMsSUFBSSxjQUFjLElBQUksT0FBTyxjQUFjLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxLQUFLLFdBQVcsRUFBRTtnQkFDckgsT0FBTyxjQUFjLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDO2FBQzNDO2lCQUNJLElBQUksT0FBTyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxLQUFLLFdBQVcsSUFBSSxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxFQUFFO2dCQUM1RSxPQUFPLGNBQWMsQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUM7YUFDM0M7U0FDSjtRQUNELE9BQU8sY0FBYyxDQUFDO0lBQzFCLENBQUM7SUFFRCxxQkFBcUI7SUFDZCxxQkFBcUIsQ0FBQyxXQUFnQjtRQUN6QyxJQUFJLENBQUMsZUFBZSxDQUFDLElBQUksQ0FBQyxXQUFXLENBQUMsQ0FBQztJQUMzQyxDQUFDO0lBRU0sa0JBQWtCLENBQUMsV0FBZ0I7UUFDdEMsSUFBSSxDQUFDLGlCQUFpQixDQUFDLElBQUksQ0FBQyxXQUFXLENBQUMsQ0FBQztJQUM3QyxDQUFDOzs7WUFqWEosU0FBUyxTQUFDO2dCQUNQLFFBQVEsRUFBRSxTQUFTO2dCQUNuQixnOU9BQXFDO2dCQUNyQyxTQUFTLEVBQUUsQ0FBQyxxQkFBcUIsRUFBRSxXQUFXLEVBQUUsWUFBWSxFQUFFLFNBQVMsRUFBRSxlQUFlLENBQUM7Z0JBQ3pGLElBQUksRUFBRTtvQkFDRixPQUFPLEVBQUUsVUFBVTtpQkFDdEI7YUFDSjs7O1lBeEJRLHFCQUFxQjtZQUNyQixXQUFXO1lBQ1gsWUFBWTtZQUNaLFNBQVM7WUFESyxlQUFlO1lBUmxDLFVBQVU7Ozt3QkEyQ1QsS0FBSztxQkFDTCxLQUFLOzBCQUNMLEtBQUs7a0JBQ0wsS0FBSzt5QkFDTCxNQUFNO2lDQUNOLE1BQU07MEJBQ04sTUFBTTt5QkFDTixNQUFNOzBCQUNOLE1BQU07NkJBQ04sWUFBWSxTQUFDLE9BQU87OEJBRXBCLE1BQU07Z0NBQ04sTUFBTSIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7XHJcbiAgICBDb21wb25lbnQsXHJcbiAgICBJbnB1dCxcclxuICAgIE91dHB1dCxcclxuICAgIEV2ZW50RW1pdHRlcixcclxuICAgIE9uSW5pdCxcclxuICAgIE9uRGVzdHJveSxcclxuICAgIE9uQ2hhbmdlcyxcclxuICAgIFZpZXdDaGlsZHJlbixcclxuICAgIEVsZW1lbnRSZWZcclxufSBmcm9tICdAYW5ndWxhci9jb3JlJztcclxuaW1wb3J0IHsgdGltZXIgLCAgU3Vic2NyaXB0aW9uIH0gZnJvbSAncnhqcyc7XHJcbmltcG9ydCB7IEZvcm1Hcm91cCB9IGZyb20gJ0Bhbmd1bGFyL2Zvcm1zJztcclxuaW1wb3J0IHsgS2RJbnB1dCB9IGZyb20gJy4uL2tkLWFuZ3VsYXItaW5wdXQva2QtYW5ndWxhci1pbnB1dCc7XHJcbmltcG9ydCB7IElucHV0QmFzZSB9IGZyb20gJy4uL2tkLWFuZ3VsYXItaW5wdXQvc3JjL2tkLWlucHV0LWJhc2UnO1xyXG5pbXBvcnQgeyBLZElucHV0Q29udHJvbFNlcnZpY2UgfSBmcm9tICcuLi9rZC1hbmd1bGFyLWlucHV0L3NyYy9rZC1hbmd1bGFyLWZvcm0uY29udHJvbCc7XHJcbmltcG9ydCB7IEtkRm9ybUV2ZW50IH0gZnJvbSAnLi9zcmMva2QtZm9ybS1ldmVudCc7XHJcbmltcG9ydCB7IEtkRG9tRWxlbVN2YywgS2RDb252ZXJ0aW9uU3ZjIH0gZnJvbSAnLi4va2QtY29tbW9uL2luZGV4JztcclxuaW1wb3J0IHsgS2RWaWV3U3ZjIH0gZnJvbSAnLi9rZC1hbmd1bGFyLXZpZXctc3ZjJztcclxuaW1wb3J0IHsgSVRyZWVBcGkgfSBmcm9tICcuLi9rZC1hbmd1bGFyLXRyZWVkcm9wZG93bi9rZC10cmVlZHJvcGRvd24taW50ZXJmYWNlJztcclxuaW1wb3J0IHsgSUR5bmFtaWNGb3JtQXBpLCBJRHluYW1pY0Zvcm1UYWJsZUFwaSB9IGZyb20gJy4va2QtYW5ndWxhci12aWV3LWludGVyZmFjZSc7XHJcblxyXG5pbXBvcnQge1xyXG4gICAgSVRhYmxlQXBpLFxyXG4gICAgSVRhYmxlQ2VsbFBhcmFtcyxcclxuICAgIEtkVGFibGVJbnB1dFVwZGF0ZUV2ZW50LFxyXG4gICAgS2RUYWJsZUJ1dHRvbkV2ZW50LFxyXG4gICAgSVRhYmxlRm9ybVVwZGF0ZVBhcmFtcyxcclxufSBmcm9tICcuLi9rZC1hbmd1bGFyLXRhYmxlL2luZGV4JztcclxuXHJcbmltcG9ydCB7IElTbGlkZXJBcGkgfSBmcm9tICcuLi9rZC1hbmd1bGFyLXNsaWRlci9pbmRleCc7XHJcblxyXG5AQ29tcG9uZW50KHtcclxuICAgIHNlbGVjdG9yOiAna2QtdmlldycsXHJcbiAgICB0ZW1wbGF0ZVVybDogJy4va2QtYW5ndWxhci12aWV3Lmh0bWwnLFxyXG4gICAgcHJvdmlkZXJzOiBbS2RJbnB1dENvbnRyb2xTZXJ2aWNlLCBLZEZvcm1FdmVudCwgS2REb21FbGVtU3ZjLCBLZFZpZXdTdmMsIEtkQ29udmVydGlvblN2Y10sXHJcbiAgICBob3N0OiB7XHJcbiAgICAgICAgJ2NsYXNzJzogJ2tkeC12aWV3J1xyXG4gICAgfVxyXG59KVxyXG5cclxuZXhwb3J0IGNsYXNzIEtkVmlldyBpbXBsZW1lbnRzIE9uSW5pdCwgT25EZXN0cm95LCBPbkNoYW5nZXMge1xyXG4gICAgcHVibGljIF9kZlF1ZXN0aW9uczogQXJyYXk8YW55PiA9IFtdO1xyXG4gICAgcHVibGljIF9kaXNwbGF5VHlwZTogc3RyaW5nO1xyXG4gICAgcHVibGljIGlzU3RhY2tlZEZyb206IGJvb2xlYW47XHJcblxyXG4gICAgcHVibGljIF9mb3JtOiBGb3JtR3JvdXA7XHJcbiAgICBwdWJsaWMgX2Zvcm1CdG46IEFycmF5PGFueT4gPSBbXTtcclxuICAgIHByaXZhdGUgX2ZpcnN0TG9hZDogYm9vbGVhbiA9IHRydWU7XHJcbiAgICBwcml2YXRlIF9mb3JtRHJvcGRvd25TdWI6IFN1YnNjcmlwdGlvbjtcclxuICAgIHByaXZhdGUgX2Zvcm1WaXNpYmxlU3ViOiBTdWJzY3JpcHRpb247XHJcblxyXG4gICAgQElucHV0KCkgaW5wdXREYXRhOiBBcnJheTxhbnk+O1xyXG4gICAgQElucHV0KCkgYnV0dG9uOiBBcnJheTxhbnk+O1xyXG4gICAgQElucHV0KCkgZGlzcGxheVR5cGU6IHN0cmluZztcclxuICAgIEBJbnB1dCgpIGFwaTogSUR5bmFtaWNGb3JtQXBpO1xyXG4gICAgQE91dHB1dCgpIGRldGVjdEZyb206IEV2ZW50RW1pdHRlcjxhbnk+ID0gbmV3IEV2ZW50RW1pdHRlcigpO1xyXG4gICAgQE91dHB1dCgpIGRldGVjdEdyaWRRdWVzdGlvbjogRXZlbnRFbWl0dGVyPGFueT4gPSBuZXcgRXZlbnRFbWl0dGVyKCk7XHJcbiAgICBAT3V0cHV0KCkgc3VibWl0RXZlbnQ6IEV2ZW50RW1pdHRlcjxhbnk+ID0gbmV3IEV2ZW50RW1pdHRlcigpO1xyXG4gICAgQE91dHB1dCgpIHJlc2V0RXZlbnQ6IEV2ZW50RW1pdHRlcjxhbnk+ID0gbmV3IEV2ZW50RW1pdHRlcigpO1xyXG4gICAgQE91dHB1dCgpIGJ1dHRvbkV2ZW50OiBFdmVudEVtaXR0ZXI8YW55PiA9IG5ldyBFdmVudEVtaXR0ZXIoKTtcclxuICAgIEBWaWV3Q2hpbGRyZW4oS2RJbnB1dCkgaW5wdXRDb21wb25lbnQ6IEFycmF5PEtkSW5wdXQ+O1xyXG5cclxuICAgIEBPdXRwdXQoKSBncmlkQ2VsbENoYW5nZWQ6IEV2ZW50RW1pdHRlcjx7IGZvcm1LZXk6IHN0cmluZywgcGFyYW1zOiBLZFRhYmxlSW5wdXRVcGRhdGVFdmVudCB9PiA9IG5ldyBFdmVudEVtaXR0ZXIoKTtcclxuICAgIEBPdXRwdXQoKSBncmlkQnV0dG9uQ2xpY2tlZDogRXZlbnRFbWl0dGVyPHsgZm9ybUtleTogc3RyaW5nLCBwYXJhbXM6IEtkVGFibGVCdXR0b25FdmVudCB9PiA9IG5ldyBFdmVudEVtaXR0ZXIoKTtcclxuXHJcbiAgICBjb25zdHJ1Y3RvcihcclxuICAgICAgICBwcml2YXRlIF9kZkNvbnRyb2w6IEtkSW5wdXRDb250cm9sU2VydmljZSxcclxuICAgICAgICBwcml2YXRlIF9mb3JtRXZlbnQ6IEtkRm9ybUV2ZW50LFxyXG4gICAgICAgIHByaXZhdGUgX2RvbVN2YzogS2REb21FbGVtU3ZjLFxyXG4gICAgICAgIHByaXZhdGUgX2tkVmlld1N2YzogS2RWaWV3U3ZjLFxyXG4gICAgICAgIHByaXZhdGUgX2NvbnZlcnRTdmM6IEtkQ29udmVydGlvblN2YyxcclxuICAgICAgICBwcml2YXRlIF9lbGVtZW50UmVmOiBFbGVtZW50UmVmXHJcbiAgICApIHsgfVxyXG5cclxuICAgIG5nT25Jbml0KCk6IHZvaWQge1xyXG5cclxuICAgICAgICB0aGlzLl9kaXNwbGF5VHlwZSA9IHRoaXMuZGlzcGxheVR5cGU7IC8vICh0eXBlb2YgdGhpcy5kaXNwbGF5VHlwZSAhPT0gJ3VuZGVmaW5lZCcpID8gdGhpcy5kaXNwbGF5VHlwZSA6ICd2aWV3JztcclxuICAgICAgICB0aGlzLmlzU3RhY2tlZEZyb20gPSB0aGlzLl9kaXNwbGF5VHlwZSA9PT0gJ3N0YWNrZWQtZm9ybSc7XHJcblxyXG4gICAgICAgIHRoaXMuX3NldFF1ZXN0aW9ucygpO1xyXG4gICAgICAgIHRoaXMuX3NldEJ1dHRvbnMoKTtcclxuICAgICAgICB0aGlzLl91cGRhdGVGb3JtQXBpKCk7XHJcblxyXG4gICAgICAgIHRoaXMuX2Zvcm1WaXNpYmxlU3ViID0gdGhpcy5fZm9ybUV2ZW50Lm9uU2V0VmlzaWFibGVJbnB1dCgpLnN1YnNjcmliZSh2YWwgPT4ge1xyXG4gICAgICAgICAgICBmb3IgKGxldCBpOiBudW1iZXIgPSAwOyBpIDwgdGhpcy5fZGZRdWVzdGlvbnMubGVuZ3RoOyBpKyspIHtcclxuICAgICAgICAgICAgICAgIGlmICh0aGlzLl9kZlF1ZXN0aW9uc1tpXS5rZXkgPT09IHZhbC5rZXkpIHtcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLl9kZlF1ZXN0aW9uc1tpXS5zZXRWaXNpYmxlKHZhbC52aXNpYmxlKTtcclxuICAgICAgICAgICAgICAgICAgICBicmVhaztcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH0pO1xyXG5cclxuICAgICAgICB0aGlzLl9mb3JtRHJvcGRvd25TdWIgPSB0aGlzLl9mb3JtRXZlbnQub25TZXREcm9wZG93bkxpc3QoKS5zdWJzY3JpYmUodmFsID0+IHtcclxuICAgICAgICAgICAgZm9yIChsZXQgaTogbnVtYmVyID0gMDsgaSA8IHRoaXMuX2RmUXVlc3Rpb25zLmxlbmd0aDsgaSsrKSB7XHJcbiAgICAgICAgICAgICAgICBpZiAodGhpcy5fZGZRdWVzdGlvbnNbaV0ua2V5ID09PSB2YWwua2V5KSB7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5fZGZRdWVzdGlvbnNbaV0uc2V0T3B0aW9ucyh2YWwub3B0aW9ucyk7XHJcbiAgICAgICAgICAgICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9KTtcclxuXHJcbiAgICAgICAgdGhpcy5fZmlyc3RMb2FkID0gZmFsc2U7XHJcbiAgICAgICAgLy8gY29uc29sZS5sb2coJ0tkVmlldyAtIHRoaXMgaXMgdGhlIHZpZXcganVzdCBpbml0aWFsaXplZCcsIHRoaXMuaW5wdXREYXRhKTtcclxuICAgIH1cclxuXHJcbiAgICBuZ09uQ2hhbmdlcygpOiB2b2lkIHtcclxuICAgICAgICBpZiAoIXRoaXMuX2ZpcnN0TG9hZCkge1xyXG4gICAgICAgICAgICAvLyBjb25zb2xlLmxvZygnS2RWaWV3IC0gdGhpcyBpcyB0aGUgdmlldyBjaGFuZ2UgZXZlbnQnLCB0aGlzLmlucHV0RGF0YSk7XHJcbiAgICAgICAgICAgIHRoaXMuX2Rpc3BsYXlUeXBlID0gKHR5cGVvZiB0aGlzLmRpc3BsYXlUeXBlICE9PSAndW5kZWZpbmVkJykgPyB0aGlzLmRpc3BsYXlUeXBlIDogJ3ZpZXcnO1xyXG4gICAgICAgICAgICB0aGlzLl9zZXRRdWVzdGlvbnMoKTtcclxuICAgICAgICAgICAgdGhpcy5fc2V0QnV0dG9ucygpO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICBuZ09uRGVzdHJveSgpOiB2b2lkIHtcclxuICAgICAgICBpZih0aGlzLl9mb3JtVmlzaWJsZVN1YikgdGhpcy5fZm9ybVZpc2libGVTdWIudW5zdWJzY3JpYmUoKTtcclxuICAgICAgICBpZih0aGlzLl9mb3JtRHJvcGRvd25TdWIpIHRoaXMuX2Zvcm1Ecm9wZG93blN1Yi51bnN1YnNjcmliZSgpO1xyXG4gICAgfVxyXG5cclxuICAgIHB1YmxpYyBnZXRJbnB1dFByb3BlcnR5KGtleTogc3RyaW5nLCBwcm9wZXJ0eU5hbWU6IHN0cmluZyk6IGFueSB7XHJcbiAgICAgICAgZm9yIChsZXQgaTogbnVtYmVyID0gMDsgaSA8IHRoaXMuX2RmUXVlc3Rpb25zLmxlbmd0aDsgaSsrKSB7XHJcbiAgICAgICAgICAgIGlmICh0aGlzLl9kZlF1ZXN0aW9uc1tpXS5nZXRQcm9wZXJ0eSgna2V5JykgPT09IGtleSkgcmV0dXJuIHRoaXMuX2RmUXVlc3Rpb25zW2ldLmdldFByb3BlcnR5KHByb3BlcnR5TmFtZSk7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIHB1YmxpYyBzZXRJbnB1dFByb3BlcnR5KGtleTogc3RyaW5nLCBwcm9wZXJ0eU5hbWU6IHN0cmluZywgZGF0YTogYW55KTogdm9pZCB7XHJcbiAgICAgICAgZm9yIChsZXQgaTogbnVtYmVyID0gMDsgaSA8IHRoaXMuX2RmUXVlc3Rpb25zLmxlbmd0aDsgaSsrKSB7XHJcbiAgICAgICAgICAgIGlmICh0aGlzLl9kZlF1ZXN0aW9uc1tpXS5nZXRQcm9wZXJ0eSgna2V5JykgPT09IGtleSkge1xyXG4gICAgICAgICAgICAgICAgaWYgKHByb3BlcnR5TmFtZSAhPT0gJ3Zpc2libGUnKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5fZGZRdWVzdGlvbnNbaV0uc2V0UHJvcGVydHkocHJvcGVydHlOYW1lLCBkYXRhKTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuX2RmUXVlc3Rpb25zW2ldLnNldFZpc2libGUoZGF0YSk7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICBicmVhaztcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICBwdWJsaWMgcmVzZXRHcmlkSGVpZ2h0KF9ncmlkSWQ6IHN0cmluZyk6IHZvaWQge1xyXG4gICAgICAgIHRoaXMuaW5wdXRDb21wb25lbnQuZm9yRWFjaCgoaXRlbTogS2RJbnB1dCk6IHZvaWQgPT4ge1xyXG4gICAgICAgICAgICBpZiAoX2dyaWRJZCA9PT0gaXRlbS5xdWVzdGlvbi5nZXRQcm9wZXJ0eSgna2V5JykpIHtcclxuICAgICAgICAgICAgICAgIGl0ZW0ucmVzZXRIZWlnaHQoKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH0pO1xyXG4gICAgfVxyXG5cclxuICAgIC8vLy8vIFRhYmxlIGNvbnRyb2x0eXBlXHJcbiAgICBwdWJsaWMgdXBkYXRlVGFibGVDZWxsKF9xdWVzdGlvbktleTogc3RyaW5nLCBfY2VsbFBhcmFtczogSVRhYmxlQ2VsbFBhcmFtcyk6IHZvaWQge1xyXG4gICAgICAgIHRoaXMuaW5wdXRDb21wb25lbnQuZm9yRWFjaCgoaXRlbTogS2RJbnB1dCk6IHZvaWQgPT4ge1xyXG4gICAgICAgICAgICBpZiAoX3F1ZXN0aW9uS2V5ID09PSBpdGVtLnF1ZXN0aW9uLmdldFByb3BlcnR5KCdrZXknKSkge1xyXG4gICAgICAgICAgICAgICAgaXRlbS5zZXRUYWJsZUNlbGxEYXRhKF9jZWxsUGFyYW1zKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH0pO1xyXG4gICAgfVxyXG5cclxuICAgIHB1YmxpYyB1cGRhdGVUYWJsZUNlbGxQcm9wZXJ0eShfcXVlc3Rpb25LZXk6IHN0cmluZywgX2NlbGxQYXJhbXM6IElUYWJsZUZvcm1VcGRhdGVQYXJhbXMpOiB2b2lkIHtcclxuICAgICAgICB0aGlzLmlucHV0Q29tcG9uZW50LmZvckVhY2goKGl0ZW06IEtkSW5wdXQpOiB2b2lkID0+IHtcclxuICAgICAgICAgICAgaWYgKF9xdWVzdGlvbktleSA9PT0gaXRlbS5xdWVzdGlvbi5nZXRQcm9wZXJ0eSgna2V5JykpIHtcclxuICAgICAgICAgICAgICAgIGl0ZW0uc2V0VGFibGVDZWxsUXVlc3Rpb25Qcm9wZXJ0eShfY2VsbFBhcmFtcyk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9KTtcclxuICAgIH1cclxuICAgIC8vLy8vLy8vIHRpbGwgaGVyZVxyXG5cclxuICAgIHB1YmxpYyBzZXRCdXR0b25EaXNhYmxlZChfdHlwZTogc3RyaW5nLCBfZGlzYWJsZWQ6IGJvb2xlYW4pOiB2b2lkIHtcclxuICAgICAgICBmb3IgKGxldCBpOiBudW1iZXIgPSAwOyBpIDwgdGhpcy5fZm9ybUJ0bi5sZW5ndGg7IGkrKykge1xyXG4gICAgICAgICAgICBpZiAoX3R5cGUgPT09IHRoaXMuX2Zvcm1CdG5baV0udHlwZSkge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5fZm9ybUJ0bltpXS5kaXNhYmxlZCA9IF9kaXNhYmxlZDtcclxuICAgICAgICAgICAgICAgIHRoaXMuX2Zvcm1CdG4gPSB0aGlzLl9mb3JtQnRuLnNsaWNlKCk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgcHVibGljIGlzRm9ybU9yU3RhY2tlZEZvcm0oKTogc3RyaW5nIHtcclxuICAgICAgICBpZiAodGhpcy5fZGlzcGxheVR5cGUgPT09ICdmb3JtJyB8fCB0aGlzLl9kaXNwbGF5VHlwZSA9PT0gJ3N0YWNrZWQtZm9ybScpIHtcclxuICAgICAgICAgICAgcmV0dXJuIHRoaXMuX2Rpc3BsYXlUeXBlO1xyXG4gICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgIHJldHVybiAnLSc7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIC8vIGNoYW5nZSB0byBwdWJsaWMgZHVlIHRvIGxpbnRcclxuICAgIHB1YmxpYyBjaGFuZ2VEZXRlY3RGb3JtKF9xdWVzdGlvbjogSW5wdXRCYXNlPGFueT4pOiB2b2lkIHtcclxuICAgICAgICB0aGlzLmRldGVjdEZyb20uZW1pdChfcXVlc3Rpb24pO1xyXG4gICAgfVxyXG5cclxuICAgIC8vIGNoYW5nZSB0byBwdWJsaWMgZHVlIHRvIGxpbnRcclxuICAgIHB1YmxpYyBjaGFuZ2VEZXRlY3RGcm9tR3JpZChfZ3JpZENlbGxRdWVzdGlvbjogYW55KTogdm9pZCB7XHJcbiAgICAgICAgdGhpcy5kZXRlY3RHcmlkUXVlc3Rpb24uZW1pdChfZ3JpZENlbGxRdWVzdGlvbik7XHJcbiAgICB9XHJcblxyXG4gICAgLyoqKioqKioqKioqKioqKioqKioqKioqKiBEeW5hbWljIEZvcm0gQVBJIHVwZGF0ZXMgKioqKioqKioqKioqKioqKioqKioqKioqKi9cclxuICAgIHByaXZhdGUgX3VwZGF0ZUZvcm1BcGkoKTogdm9pZCB7XHJcbiAgICAgICAgaWYgKHR5cGVvZiB0aGlzLmFwaSA9PT0gJ3VuZGVmaW5lZCcpIHtcclxuICAgICAgICAgICAgY29uc29sZS53YXJuKCdLZFZpZXcgd2FybmluZzogTm8gYXBpIG9iamVjdCBpcyBwYXNzZWQgaW4uIE5vIEFQSSB3aWxsIGJlIGluaXRpYWxpemUnKTtcclxuICAgICAgICAgICAgcmV0dXJuO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgdGhpcy5hcGkuc3VibWl0Rm9ybSA9ICgpOiB2b2lkID0+IHtcclxuICAgICAgICAgICAgdGhpcy5fc3VibWl0Q2xpY2soKTtcclxuICAgICAgICB9O1xyXG5cclxuICAgICAgICB0aGlzLmFwaS5zZXRQcm9wZXJ0eSA9IChfcXVlc3Rpb25LZXk6IHN0cmluZywgX3Byb3BlcnR5OiBzdHJpbmcsIF9kYXRhOiBhbnkpOiB2b2lkID0+IHtcclxuICAgICAgICAgICAgZm9yIChsZXQgaTogbnVtYmVyID0gMDsgaSA8IHRoaXMuX2RmUXVlc3Rpb25zLmxlbmd0aDsgaSsrKSB7XHJcbiAgICAgICAgICAgICAgICBpZiAodGhpcy5fZGZRdWVzdGlvbnNbaV0uZ2V0UHJvcGVydHkoJ2tleScpID09PSBfcXVlc3Rpb25LZXkpIHtcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLl9kZlF1ZXN0aW9uc1tpXS5zZXRQcm9wZXJ0eShfcHJvcGVydHksIF9kYXRhKTtcclxuICAgICAgICAgICAgICAgICAgICBicmVhaztcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH07XHJcblxyXG4gICAgICAgIHRoaXMuYXBpLmdldFByb3BlcnR5ID0gKF9xdWVzdGlvbktleTogc3RyaW5nLCBfcHJvcGVydHk6IHN0cmluZyk6IGFueSA9PiB7XHJcbiAgICAgICAgICAgIGZvciAobGV0IGk6IG51bWJlciA9IDA7IGkgPCB0aGlzLl9kZlF1ZXN0aW9ucy5sZW5ndGg7IGkrKykge1xyXG4gICAgICAgICAgICAgICAgaWYgKHRoaXMuX2RmUXVlc3Rpb25zW2ldLmdldFByb3BlcnR5KCdrZXknKSA9PT0gX3F1ZXN0aW9uS2V5KSB7XHJcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIHRoaXMuX2RmUXVlc3Rpb25zW2ldLmdldFByb3BlcnR5KF9wcm9wZXJ0eSk7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9O1xyXG5cclxuICAgICAgICB0aGlzLmFwaS50YWJsZSA9IChfcXVlc3Rpb25LZXk6IHN0cmluZyk6IElEeW5hbWljRm9ybVRhYmxlQXBpID0+IHtcclxuICAgICAgICAgICAgbGV0IHRhYmxlQXBpOiBJVGFibGVBcGk7XHJcblxyXG4gICAgICAgICAgICBmb3IgKGxldCBpOiBudW1iZXIgPSAwOyBpIDwgdGhpcy5fZGZRdWVzdGlvbnMubGVuZ3RoOyArK2kpIHtcclxuICAgICAgICAgICAgICAgIGlmICh0aGlzLl9kZlF1ZXN0aW9uc1tpXS5nZXRQcm9wZXJ0eSgna2V5JykgPT09IF9xdWVzdGlvbktleSkge1xyXG4gICAgICAgICAgICAgICAgICAgIHRhYmxlQXBpID0gdGhpcy5fZGZRdWVzdGlvbnNbaV0uZ2V0UHJvcGVydHkoJ2FwaScpO1xyXG4gICAgICAgICAgICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICByZXR1cm4ge1xyXG4gICAgICAgICAgICAgICAgc2V0VGFibGVDZWxsSW5wdXRQcm9wZXJ0eTogKF9mb3JtUGFyYW1zOiBJVGFibGVGb3JtVXBkYXRlUGFyYW1zKTogdm9pZCA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgdGFibGVBcGkuZHluYW1pY0Zvcm0uc2V0UHJvcGVydHkoX2Zvcm1QYXJhbXMpO1xyXG4gICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICAgIHVwZGF0ZVRhYmxlQ2VsbFByb3BlcnR5OiAoX2NlbGxQYXJhbXM6IElUYWJsZUNlbGxQYXJhbXMpOiB2b2lkID0+IHtcclxuICAgICAgICAgICAgICAgICAgICB0YWJsZUFwaS5nZW5lcmFsLnVwZGF0ZUNlbGwoX2NlbGxQYXJhbXMpO1xyXG4gICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICAgIGdldFRhYmxlQ2VsbElucHV0UHJvcGVydHk6IChfZm9ybVBhcmFtczogSVRhYmxlRm9ybVVwZGF0ZVBhcmFtcyk6IHZvaWQgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgIHRhYmxlQXBpLmR5bmFtaWNGb3JtLmdldFByb3BlcnR5KF9mb3JtUGFyYW1zKTtcclxuICAgICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICAgICBhZGRSb3c6IChfcm93czogQXJyYXk8YW55PiwgX3Njcm9sbFRvVmlzaWJsZTogYm9vbGVhbiA9IGZhbHNlKTogdm9pZCA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgdGFibGVBcGkuZ2VuZXJhbC5hZGRSb3dzKF9yb3dzLCBfc2Nyb2xsVG9WaXNpYmxlKTtcclxuICAgICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICAgICBkZWxldGVSb3dzOiAoX2lkOiBBcnJheTxzdHJpbmcgfCBudW1iZXI+IHwgbnVtYmVyIHwgc3RyaW5nKTogdm9pZCA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgdGFibGVBcGkuZ2VuZXJhbC5kZWxldGVSb3dzKF9pZCk7XHJcbiAgICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgICAgY2xlYXJFcnJvcjogKCk6IHZvaWQgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgIHRhYmxlQXBpLmR5bmFtaWNGb3JtLmNsZWFyQWxsRXJyb3IoKTtcclxuICAgICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICAgICBzZXRCdXR0b25EaXNhYmxlZDogKF9idXR0b25UeXBlOiBzdHJpbmcsIF90b0Rpc2FibGVkOiBib29sZWFuKTogdm9pZCA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgdGFibGVBcGkuZ2VuZXJhbC5zZXRCdXR0b25EaXNhYmxlZChfYnV0dG9uVHlwZSwgX3RvRGlzYWJsZWQpO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9O1xyXG4gICAgICAgIH07XHJcblxyXG4gICAgICAgIHRoaXMuYXBpLnRyZWVkcm9wZG93biA9IChfcXVlc3Rpb25LZXk6IHN0cmluZyk6IElUcmVlQXBpID0+IHtcclxuICAgICAgICAgICAgbGV0IHRyZWVBcGk6IElUcmVlQXBpO1xyXG4gICAgICAgICAgICBmb3IgKGxldCBpOiBudW1iZXIgPSAwOyBpIDwgdGhpcy5fZGZRdWVzdGlvbnMubGVuZ3RoOyArK2kpIHtcclxuICAgICAgICAgICAgICAgIGlmICh0aGlzLl9kZlF1ZXN0aW9uc1tpXS5nZXRQcm9wZXJ0eSgna2V5JykgPT09IF9xdWVzdGlvbktleSkge1xyXG4gICAgICAgICAgICAgICAgICAgIHRyZWVBcGkgPSB0aGlzLl9kZlF1ZXN0aW9uc1tpXS5nZXRQcm9wZXJ0eSgnYXBpJyk7XHJcbiAgICAgICAgICAgICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgcmV0dXJuIHRyZWVBcGk7XHJcbiAgICAgICAgfTtcclxuXHJcbiAgICAgICAgdGhpcy5hcGkuc2xpZGVyQXBpID0gKF9xdWVzdGlvbktleTogc3RyaW5nKTogSVNsaWRlckFwaSA9PiB7XHJcbiAgICAgICAgICAgIGxldCBzbGlkZXJBcGk6IElTbGlkZXJBcGk7XHJcblxyXG4gICAgICAgICAgICBmb3IgKGxldCBpOiBudW1iZXIgPSAwOyBpIDwgdGhpcy5fZGZRdWVzdGlvbnMubGVuZ3RoOyArK2kpIHtcclxuICAgICAgICAgICAgICAgIGlmICh0aGlzLl9kZlF1ZXN0aW9uc1tpXS5nZXRQcm9wZXJ0eSgna2V5JykgPT09IF9xdWVzdGlvbktleSkge1xyXG4gICAgICAgICAgICAgICAgICAgIHNsaWRlckFwaSA9IHRoaXMuX2RmUXVlc3Rpb25zW2ldLmdldFByb3BlcnR5KCdhcGknKTtcclxuICAgICAgICAgICAgICAgICAgICBicmVhaztcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgcmV0dXJuIHNsaWRlckFwaTtcclxuICAgICAgICB9O1xyXG4gICAgfVxyXG5cclxuXHJcbiAgICBwdWJsaWMgX2J0bkNsaWNrKF9idG46IGFueSk6IHZvaWQge1xyXG4gICAgICAgIGlmIChfYnRuLnR5cGUgPT09ICdyZXNldCcpIHRoaXMuX3Jlc2V0Rm9ybSgpO1xyXG4gICAgICAgIGVsc2UgaWYgKF9idG4udHlwZSAhPT0gJ3N1Ym1pdCcpIHRoaXMuYnV0dG9uRXZlbnQuZW1pdChfYnRuKTtcclxuICAgICAgICAvLyBpZih0eXBlb2YgX2J0bi5jYWxsYmFjayA9PT0gJ2Z1bmN0aW9uJykgX2J0bi5jYWxsYmFjayh0aGlzLl9mb3JtLnZhbHVlKTtcclxuICAgICAgICAvLyBlbHNlIGlmKHR5cGVvZiBfYnRuLmNhbGxiYWNrID09PSAndW5kZWZpbmVkJyAmJiBfYnRuLnR5cGUgIT09ICdzdWJtaXQnKSBjb25zb2xlLmVycm9yKCdQbGVhc2UgcHJvdmlkZSBjYWxsYmFjaycpO1xyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX3Jlc2V0RXJyb3IoKTogdm9pZCB7XHJcbiAgICAgICAgZm9yIChsZXQgaSA9IDA7IGkgPCB0aGlzLl9kZlF1ZXN0aW9ucy5sZW5ndGg7ICsraSkge1xyXG4gICAgICAgICAgICB0aGlzLl9kZlF1ZXN0aW9uc1tpXS5zZXRQcm9wZXJ0eSgnZXJyb3JzJywgW10pO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF9nZXRGb3JtVmFsaWRhdGlvbkVycm9yKCk6IHZvaWQge1xyXG4gICAgICAgIGZvciAobGV0IGkgPSAwOyBpIDwgdGhpcy5fZGZRdWVzdGlvbnMubGVuZ3RoOyArK2kpIHtcclxuICAgICAgICAgICAgdGhpcy5fZGZRdWVzdGlvbnNbaV0uc2V0UHJvcGVydHkoJ2Vycm9ycycsIFtdKTtcclxuICAgICAgICAgICAgbGV0IGVycm9yQXJyOiBBcnJheTxzdHJpbmc+ID0gW107XHJcbiAgICAgICAgICAgIGNvbnN0IGVycm9yczoge30gPSB0aGlzLl9mb3JtLmdldCh0aGlzLl9kZlF1ZXN0aW9uc1tpXS5nZXRQcm9wZXJ0eSgna2V5JykpLmVycm9ycztcclxuICAgICAgICAgICAgaWYgKGVycm9ycyAhPT0gbnVsbCkge1xyXG4gICAgICAgICAgICAgICAgZm9yIChsZXQga2V5IGluIGVycm9ycykge1xyXG4gICAgICAgICAgICAgICAgICAgIGlmIChlcnJvcnMuaGFzT3duUHJvcGVydHkoa2V5KSkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBlcnJvckFyci5wdXNoKGVycm9yc1trZXldKTtcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICB0aGlzLl9kZlF1ZXN0aW9uc1tpXS5zZXRQcm9wZXJ0eSgnZXJyb3JzJywgZXJyb3JBcnIpO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIHB1YmxpYyBfc3VibWl0Q2xpY2soKTogdm9pZCB7XHJcbiAgICAgICAgbGV0IHVwZGF0ZWRGb3JtOiBhbnkgPSB0aGlzLl91cGRhdGVGb3JtVmFsdWUodGhpcy5fZGZRdWVzdGlvbnMsIHRoaXMuX2Zvcm0udmFsdWUpO1xyXG4gICAgICAgIGlmICh0aGlzLl9mb3JtLnZhbGlkKSB7XHJcbiAgICAgICAgICAgIHRoaXMuc3VibWl0RXZlbnQuZW1pdCh1cGRhdGVkRm9ybSk7XHJcbiAgICAgICAgICAgIHRoaXMuX3Jlc2V0RXJyb3IoKTtcclxuICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICB0aGlzLl9nZXRGb3JtVmFsaWRhdGlvbkVycm9yKCk7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIC8vIHByaXZhdGUgX3N1Ym1pdENsaWNrKCk6IHZvaWQge1xyXG4gICAgLy8gICAgIGxldCB1cGRhdGVkRm9ybTogYW55ID0gdGhpcy5fdXBkYXRlRm9ybVZhbHVlKHRoaXMuX2RmUXVlc3Rpb25zLCB0aGlzLl9mb3JtLnZhbHVlKTtcclxuICAgIC8vICAgICB0aGlzLnN1Ym1pdEV2ZW50LmVtaXQodXBkYXRlZEZvcm0pO1xyXG4gICAgLy8gfVxyXG5cclxuICAgIHByaXZhdGUgX3Jlc2V0Rm9ybSgpOiB2b2lkIHtcclxuICAgICAgICB0aGlzLl9zZXRRdWVzdGlvbnMoKTtcclxuICAgICAgICBsZXQgY29udGVudEJvZHk6IEVsZW1lbnQgPSAodGhpcy5fZG9tU3ZjLmlzTW9iaWxlKCkpID8gZG9jdW1lbnQuYm9keS5xdWVyeVNlbGVjdG9yKCcubWFpbi13cmFwcGVyJykgOiBkb2N1bWVudC5ib2R5LnF1ZXJ5U2VsZWN0b3IoJy5jb250ZW50LWFyZWEnKTtcclxuICAgICAgICBjb250ZW50Qm9keS5zY3JvbGxUb3AgPSAwO1xyXG4gICAgICAgIHRoaXMucmVzZXRFdmVudC5lbWl0KCk7XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfc2V0UXVlc3Rpb25zKCk6IHZvaWQge1xyXG4gICAgICAgIHRoaXMuX2Zvcm0gPSB0aGlzLl9kZkNvbnRyb2wuZW1wdHlGb3JtR3JvdXAoKTtcclxuICAgICAgICB0aW1lcig1MCkuc3Vic2NyaWJlKCgpOiB2b2lkID0+IHtcclxuICAgICAgICAgICAgdGhpcy5fZGZRdWVzdGlvbnMgPSB0aGlzLl9rZFZpZXdTdmMuY29udmVydERhdGFUeXBlKHRoaXMuaW5wdXREYXRhLCB0aGlzLl9jb252ZXJ0U3ZjKTtcclxuICAgICAgICAgICAgdGhpcy5fZm9ybSA9IHRoaXMuX2RmQ29udHJvbC50b0Zvcm1Hcm91cCh0aGlzLl9kZlF1ZXN0aW9ucyk7XHJcbiAgICAgICAgfSk7XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfc2V0QnV0dG9ucygpOiB2b2lkIHtcclxuICAgICAgICB0aGlzLl9mb3JtQnRuID0gKHR5cGVvZiB0aGlzLmJ1dHRvbiA9PT0gJ3VuZGVmaW5lZCcpID8gdGhpcy5fc2V0RGVmYXVsdEJ0bigpIDogdGhpcy5fc2V0Q3VzdG9tQnRuKHRoaXMuYnV0dG9uKTtcclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF9zZXREZWZhdWx0QnRuKCk6IEFycmF5PGFueT4ge1xyXG4gICAgICAgIGxldCBkZWZhdWx0QnRuOiBBcnJheTxhbnk+ID0gW3tcclxuICAgICAgICAgICAgdHlwZTogJ3N1Ym1pdCcsXHJcbiAgICAgICAgICAgIG5hbWU6ICdTdWJtaXQnLFxyXG4gICAgICAgICAgICBpY29uOiAna2QtY2hlY2snLFxyXG4gICAgICAgICAgICBjbGFzczogJ2J0bi10ZXh0JyxcclxuICAgICAgICAgICAgZGlzYWJsZWQ6IGZhbHNlXHJcbiAgICAgICAgfSwge1xyXG4gICAgICAgICAgICB0eXBlOiAncmVzZXQnLFxyXG4gICAgICAgICAgICBuYW1lOiAnUmVzZXQnLFxyXG4gICAgICAgICAgICBjbGFzczogJ2J0bi1vdXRsaW5lJyxcclxuICAgICAgICAgICAgaWNvbjogJ2tkLWNyb3NzJyxcclxuICAgICAgICAgICAgZGlzYWJsZWQ6IGZhbHNlXHJcbiAgICAgICAgfV07XHJcbiAgICAgICAgcmV0dXJuIGRlZmF1bHRCdG47XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfc2V0Q3VzdG9tQnRuKF9idG46IEFycmF5PGFueT4pOiBBcnJheTxhbnk+IHtcclxuICAgICAgICBsZXQgdXBkYXRlZEJ0bjogQXJyYXk8YW55PiA9IFtdO1xyXG4gICAgICAgIGxldCBidXR0b25MZW5ndGg6IG51bWJlciA9ICh0aGlzLmJ1dHRvbi5sZW5ndGggPiA0KSA/IDQgOiB0aGlzLmJ1dHRvbi5sZW5ndGg7XHJcbiAgICAgICAgZm9yIChsZXQgaTogbnVtYmVyID0gMDsgaSA8IGJ1dHRvbkxlbmd0aDsgaSsrKSB7XHJcbiAgICAgICAgICAgIGxldCBpdGVtOiBhbnkgPSBfYnRuW2ldO1xyXG4gICAgICAgICAgICBpZiAodHlwZW9mIGl0ZW0ubmFtZSA9PT0gJ3VuZGVmaW5lZCcpIGl0ZW0ubmFtZSA9ICdVbmRlZmluZWQnO1xyXG4gICAgICAgICAgICBpZiAodHlwZW9mIGl0ZW0uY2xhc3MgPT09ICd1bmRlZmluZWQnKSBpdGVtLmNsYXNzID0gJ2J0biBidG4tdGV4dCc7XHJcbiAgICAgICAgICAgIGlmICh0eXBlb2YgaXRlbS50eXBlID09PSAndW5kZWZpbmVkJykgaXRlbS50eXBlID0gJ2J1dHRvbic7XHJcbiAgICAgICAgICAgIGlmICh0eXBlb2YgaXRlbS5kaXNhYmxlZCA9PT0gJ3VuZGVmaW5lZCcpIGl0ZW0uZGlzYWJsZWQgPSBmYWxzZTtcclxuICAgICAgICAgICAgaWYgKGl0ZW0udHlwZSA9PT0gJ3Jlc2V0Jykge1xyXG4gICAgICAgICAgICAgICAgaXRlbS5jYWxsYmFjayA9ICgpOiB2b2lkID0+IHtcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLl9yZXNldEZvcm0oKTtcclxuICAgICAgICAgICAgICAgIH07XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgdXBkYXRlZEJ0bi5wdXNoKGl0ZW0pO1xyXG4gICAgICAgIH1cclxuICAgICAgICByZXR1cm4gdXBkYXRlZEJ0bjtcclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF91cGRhdGVGb3JtVmFsdWUoX3F1ZXN0aW9uOiBBcnJheTxhbnk+LCBfZm9ybVZhbHVlOiBhbnkpOiBhbnkge1xyXG4gICAgICAgIGxldCB1cGRhdGVkRm9ybVZhbDogYW55ID0gT2JqZWN0LmFzc2lnbih7fSwgX2Zvcm1WYWx1ZSk7XHJcbiAgICAgICAgZm9yIChsZXQgaTogbnVtYmVyID0gMDsgaSA8IF9xdWVzdGlvbi5sZW5ndGg7IGkrKykge1xyXG4gICAgICAgICAgICBpZiAoX3F1ZXN0aW9uW2ldLmNvbnRyb2xUeXBlID09PSAnc2VjdGlvbicgJiYgdXBkYXRlZEZvcm1WYWwgJiYgdHlwZW9mIHVwZGF0ZWRGb3JtVmFsW19xdWVzdGlvbltpXS5rZXldICE9PSAndW5kZWZpbmVkJykge1xyXG4gICAgICAgICAgICAgICAgZGVsZXRlIHVwZGF0ZWRGb3JtVmFsW19xdWVzdGlvbltpXS5rZXldO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIGVsc2UgaWYgKHR5cGVvZiBfcXVlc3Rpb25baV0uZGlzYWJsZWQgIT09ICd1bmRlZmluZWQnICYmIF9xdWVzdGlvbltpXS5kaXNhYmxlZCkge1xyXG4gICAgICAgICAgICAgICAgZGVsZXRlIHVwZGF0ZWRGb3JtVmFsW19xdWVzdGlvbltpXS5rZXldO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgICAgIHJldHVybiB1cGRhdGVkRm9ybVZhbDtcclxuICAgIH1cclxuXHJcbiAgICAvLy8gdGFibGUgY29udHJvbHR5cGVcclxuICAgIHB1YmxpYyBfZ3JpZENlbGxWYWx1ZUNoYW5nZWQoX2VtaXRQYXJhbXM6IGFueSk6IHZvaWQge1xyXG4gICAgICAgIHRoaXMuZ3JpZENlbGxDaGFuZ2VkLmVtaXQoX2VtaXRQYXJhbXMpO1xyXG4gICAgfVxyXG5cclxuICAgIHB1YmxpYyBfZ3JpZEJ1dHRvbkNsaWNrZWQoX2VtaXRQYXJhbXM6IGFueSk6IHZvaWQge1xyXG4gICAgICAgIHRoaXMuZ3JpZEJ1dHRvbkNsaWNrZWQuZW1pdChfZW1pdFBhcmFtcyk7XHJcbiAgICB9XHJcbn1cclxuIl19