import { Component, ViewEncapsulation, Input } from '@angular/core';
import { KdDomElemSvc } from '../kd-common/index';
export class KdProgressloader {
    constructor(_kdDomElemSvc) {
        this._kdDomElemSvc = _kdDomElemSvc;
    }
    ngOnInit() {
        this.configDefaults();
        // console.log(this.value);
    }
    ngOnChanges() {
        // console.log(this.value);
        // console.log(this.configvalue);
        this.value = this.configvalue;
        if (this.value >= 100) {
            this.value = 100;
        }
    }
    configDefaults() {
        this.message = (typeof this.configmessage !== 'undefined') ? this.configmessage : '';
        this.value = (typeof this.configvalue !== 'undefined' || this.configvalue !== null) ? this.configvalue : null;
        if (typeof this.configtype !== 'undefined') {
            this.type = this.configtype;
            if (this.type === 'wholepagespinner') {
                this.createLoadpage();
            }
        }
        else {
            this.type = 'progressbar';
        }
    }
    createLoadpage() {
        let loadingText = 'Loading...';
        let body = document.body;
        let newDiv = this._kdDomElemSvc.createElement(body, 'kdx-load-page');
        let loaderWrapper = this._kdDomElemSvc.createElement(newDiv, 'kdx-loader-wrapper');
        let newSpinnerContainer = this._kdDomElemSvc.createElement(loaderWrapper, 'kdx-loader-container');
        this._kdDomElemSvc.createElement(newSpinnerContainer, 'kdx-loader kdx-rotating');
        this._kdDomElemSvc.createElement(newSpinnerContainer, 'fa kd-openemis openemis-icon', 'i');
        let loaderTextWrapper = this._kdDomElemSvc.createElement(loaderWrapper, 'kdx-loader-text-wrapper');
        let newLoadingText = this._kdDomElemSvc.createElement(loaderTextWrapper, 'kdx-loader-text-loading', 'div');
        newLoadingText.innerHTML = loadingText + '0%';
        if (this.message) {
            let newMessage = this._kdDomElemSvc.createElement(loaderTextWrapper, 'loader-new-message', 'p');
            newMessage.innerHTML = this.message;
        }
        let thisIntervalId = setInterval(() => {
            if (this.value <= 100) {
                newLoadingText.innerHTML = (loadingText + this.value + '%').trim();
                // newLoadingPercent.innerHTML = this.value + '%';
            }
            else {
                clearInterval(thisIntervalId);
            }
        }, 500);
    }
}
KdProgressloader.decorators = [
    { type: Component, args: [{
                selector: 'kd-progressloader',
                encapsulation: ViewEncapsulation.None,
                template: `
        <div [ngSwitch]="type">

            <div *ngSwitchCase = "'progressbar'" class="progressbar-wrapper">
                <div class="progress-bar" [style.width.%]="value"></div>
            </div>

            <div *ngSwitchCase="'small-spinner'" class="kdx-load-page kdx-small-spinner">
                <div class="kdx-loader-wrapper">
                    <div class="kdx-loader-container">
                        <div class="kdx-loader kdx-rotating"></div>
                        <span  *ngIf="value !== null" class="kdx-loader-spinner-center-text">{{value}}%</span>
                    </div>
                    <div class="kdx-loader-text-wrapper">
                        <div class="kdx-loader-text-loading">Loading...</div>
                    </div>
                </div>
            </div>
        </div>
    `,
                providers: [KdDomElemSvc],
                host: { 'class': 'kdx-progressloader' }
            },] }
];
KdProgressloader.ctorParameters = () => [
    { type: KdDomElemSvc }
];
KdProgressloader.propDecorators = {
    configtype: [{ type: Input }],
    configvalue: [{ type: Input }],
    configmessage: [{ type: Input }]
};
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoia2QtYW5ndWxhci1wcm9ncmVzc2xvYWRlci5qcyIsInNvdXJjZVJvb3QiOiJDOi94YW1wcC9odGRvY3MvU3R5bGVndWlkZS9pb3N0Zy1vcGVuZW1pcy1zdHlsZWd1aWRlL3Byb2plY3RzL29wZW5lbWlzLXN0eWxlZ3VpZGUtbGliL3NyYy8iLCJzb3VyY2VzIjpbImtkLWNvbXBvbmVudHMva2QtYW5ndWxhci1wcm9ncmVzc2xvYWRlci9rZC1hbmd1bGFyLXByb2dyZXNzbG9hZGVyLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBLE9BQU8sRUFDSCxTQUFTLEVBQ1QsaUJBQWlCLEVBQ2pCLEtBQUssRUFFUixNQUFNLGVBQWUsQ0FBQztBQUV2QixPQUFPLEVBQUUsWUFBWSxFQUFFLE1BQU0sb0JBQW9CLENBQUM7QUE2QmxELE1BQU0sT0FBTyxnQkFBZ0I7SUFTekIsWUFDWSxhQUEyQjtRQUEzQixrQkFBYSxHQUFiLGFBQWEsQ0FBYztJQUNuQyxDQUFDO0lBRUwsUUFBUTtRQUNKLElBQUksQ0FBQyxjQUFjLEVBQUUsQ0FBQztRQUN0QiwyQkFBMkI7SUFDL0IsQ0FBQztJQUVELFdBQVc7UUFDUCwyQkFBMkI7UUFDM0IsaUNBQWlDO1FBRWpDLElBQUksQ0FBQyxLQUFLLEdBQUcsSUFBSSxDQUFDLFdBQVcsQ0FBQztRQUU5QixJQUFJLElBQUksQ0FBQyxLQUFLLElBQUksR0FBRyxFQUFFO1lBQ25CLElBQUksQ0FBQyxLQUFLLEdBQUcsR0FBRyxDQUFDO1NBQ3BCO0lBQ0wsQ0FBQztJQUVPLGNBQWM7UUFDbEIsSUFBSSxDQUFDLE9BQU8sR0FBRyxDQUFDLE9BQU8sSUFBSSxDQUFDLGFBQWEsS0FBSyxXQUFXLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLGFBQWEsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDO1FBQ3JGLElBQUksQ0FBQyxLQUFLLEdBQUcsQ0FBQyxPQUFPLElBQUksQ0FBQyxXQUFXLEtBQUssV0FBVyxJQUFJLElBQUksQ0FBQyxXQUFXLEtBQUssSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQztRQUU5RyxJQUFJLE9BQU8sSUFBSSxDQUFDLFVBQVUsS0FBSyxXQUFXLEVBQUU7WUFDeEMsSUFBSSxDQUFDLElBQUksR0FBRyxJQUFJLENBQUMsVUFBVSxDQUFDO1lBRTVCLElBQUksSUFBSSxDQUFDLElBQUksS0FBSyxrQkFBa0IsRUFBRTtnQkFDbEMsSUFBSSxDQUFDLGNBQWMsRUFBRSxDQUFDO2FBQ3pCO1NBRUo7YUFBTTtZQUNILElBQUksQ0FBQyxJQUFJLEdBQUcsYUFBYSxDQUFDO1NBQzdCO0lBQ0wsQ0FBQztJQUVPLGNBQWM7UUFDbEIsSUFBSSxXQUFXLEdBQUcsWUFBWSxDQUFDO1FBQy9CLElBQUksSUFBSSxHQUFHLFFBQVEsQ0FBQyxJQUFJLENBQUM7UUFDekIsSUFBSSxNQUFNLEdBQUcsSUFBSSxDQUFDLGFBQWEsQ0FBQyxhQUFhLENBQUMsSUFBSSxFQUFFLGVBQWUsQ0FBQyxDQUFDO1FBQ3JFLElBQUksYUFBYSxHQUFHLElBQUksQ0FBQyxhQUFhLENBQUMsYUFBYSxDQUFDLE1BQU0sRUFBRSxvQkFBb0IsQ0FBQyxDQUFDO1FBRW5GLElBQUksbUJBQW1CLEdBQUcsSUFBSSxDQUFDLGFBQWEsQ0FBQyxhQUFhLENBQUMsYUFBYSxFQUFFLHNCQUFzQixDQUFDLENBQUM7UUFDbEcsSUFBSSxDQUFDLGFBQWEsQ0FBQyxhQUFhLENBQUMsbUJBQW1CLEVBQUUseUJBQXlCLENBQUMsQ0FBQztRQUNqRixJQUFJLENBQUMsYUFBYSxDQUFDLGFBQWEsQ0FBQyxtQkFBbUIsRUFBRSw4QkFBOEIsRUFBRSxHQUFHLENBQUMsQ0FBQztRQUUzRixJQUFJLGlCQUFpQixHQUFHLElBQUksQ0FBQyxhQUFhLENBQUMsYUFBYSxDQUFDLGFBQWEsRUFBRSx5QkFBeUIsQ0FBQyxDQUFDO1FBQ25HLElBQUksY0FBYyxHQUFHLElBQUksQ0FBQyxhQUFhLENBQUMsYUFBYSxDQUFDLGlCQUFpQixFQUFFLHlCQUF5QixFQUFFLEtBQUssQ0FBQyxDQUFDO1FBQzNHLGNBQWMsQ0FBQyxTQUFTLEdBQUcsV0FBVyxHQUFHLElBQUksQ0FBQztRQUU5QyxJQUFJLElBQUksQ0FBQyxPQUFPLEVBQUU7WUFDZCxJQUFJLFVBQVUsR0FBRyxJQUFJLENBQUMsYUFBYSxDQUFDLGFBQWEsQ0FBQyxpQkFBaUIsRUFBRSxvQkFBb0IsRUFBRSxHQUFHLENBQUMsQ0FBQztZQUNoRyxVQUFVLENBQUMsU0FBUyxHQUFHLElBQUksQ0FBQyxPQUFPLENBQUM7U0FDdkM7UUFFRCxJQUFJLGNBQWMsR0FBRyxXQUFXLENBQUMsR0FBUyxFQUFFO1lBQ3hDLElBQUksSUFBSSxDQUFDLEtBQUssSUFBSSxHQUFHLEVBQUU7Z0JBQ25CLGNBQWMsQ0FBQyxTQUFTLEdBQUcsQ0FBQyxXQUFXLEdBQUcsSUFBSSxDQUFDLEtBQUssR0FBRyxHQUFHLENBQUMsQ0FBQyxJQUFJLEVBQUUsQ0FBQztnQkFDbkUsa0RBQWtEO2FBQ3JEO2lCQUFNO2dCQUNILGFBQWEsQ0FBQyxjQUFjLENBQUMsQ0FBQzthQUNqQztRQUNMLENBQUMsRUFBRSxHQUFHLENBQUMsQ0FBQztJQUNaLENBQUM7OztZQW5HSixTQUFTLFNBQUM7Z0JBQ1AsUUFBUSxFQUFFLG1CQUFtQjtnQkFDN0IsYUFBYSxFQUFFLGlCQUFpQixDQUFDLElBQUk7Z0JBQ3JDLFFBQVEsRUFBRTs7Ozs7Ozs7Ozs7Ozs7Ozs7OztLQW1CVDtnQkFDRCxTQUFTLEVBQUUsQ0FBQyxZQUFZLENBQUM7Z0JBQ3pCLElBQUksRUFBRyxFQUFFLE9BQU8sRUFBRyxvQkFBb0IsRUFBRTthQUM1Qzs7O1lBM0JRLFlBQVk7Ozt5QkFrQ2hCLEtBQUs7MEJBQ0wsS0FBSzs0QkFDTCxLQUFLIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHtcclxuICAgIENvbXBvbmVudCxcclxuICAgIFZpZXdFbmNhcHN1bGF0aW9uLFxyXG4gICAgSW5wdXQsXHJcbiAgICBPbkluaXRcclxufSBmcm9tICdAYW5ndWxhci9jb3JlJztcclxuXHJcbmltcG9ydCB7IEtkRG9tRWxlbVN2YyB9IGZyb20gJy4uL2tkLWNvbW1vbi9pbmRleCc7XHJcblxyXG5AQ29tcG9uZW50KHtcclxuICAgIHNlbGVjdG9yOiAna2QtcHJvZ3Jlc3Nsb2FkZXInLFxyXG4gICAgZW5jYXBzdWxhdGlvbjogVmlld0VuY2Fwc3VsYXRpb24uTm9uZSxcclxuICAgIHRlbXBsYXRlOiBgXHJcbiAgICAgICAgPGRpdiBbbmdTd2l0Y2hdPVwidHlwZVwiPlxyXG5cclxuICAgICAgICAgICAgPGRpdiAqbmdTd2l0Y2hDYXNlID0gXCIncHJvZ3Jlc3NiYXInXCIgY2xhc3M9XCJwcm9ncmVzc2Jhci13cmFwcGVyXCI+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwicHJvZ3Jlc3MtYmFyXCIgW3N0eWxlLndpZHRoLiVdPVwidmFsdWVcIj48L2Rpdj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICA8ZGl2ICpuZ1N3aXRjaENhc2U9XCInc21hbGwtc3Bpbm5lcidcIiBjbGFzcz1cImtkeC1sb2FkLXBhZ2Uga2R4LXNtYWxsLXNwaW5uZXJcIj5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJrZHgtbG9hZGVyLXdyYXBwZXJcIj5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwia2R4LWxvYWRlci1jb250YWluZXJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cImtkeC1sb2FkZXIga2R4LXJvdGF0aW5nXCI+PC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuICAqbmdJZj1cInZhbHVlICE9PSBudWxsXCIgY2xhc3M9XCJrZHgtbG9hZGVyLXNwaW5uZXItY2VudGVyLXRleHRcIj57e3ZhbHVlfX0lPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJrZHgtbG9hZGVyLXRleHQtd3JhcHBlclwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwia2R4LWxvYWRlci10ZXh0LWxvYWRpbmdcIj5Mb2FkaW5nLi4uPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICBgLFxyXG4gICAgcHJvdmlkZXJzOiBbS2REb21FbGVtU3ZjXSxcclxuICAgIGhvc3QgOiB7ICdjbGFzcycgOiAna2R4LXByb2dyZXNzbG9hZGVyJyB9XHJcbn0pXHJcblxyXG5leHBvcnQgY2xhc3MgS2RQcm9ncmVzc2xvYWRlciBpbXBsZW1lbnRzIE9uSW5pdCB7XHJcbiAgICBwdWJsaWMgdHlwZTogc3RyaW5nO1xyXG4gICAgcHVibGljIHZhbHVlOiBudW1iZXI7XHJcbiAgICBwcml2YXRlIG1lc3NhZ2U6IHN0cmluZztcclxuXHJcbiAgICBASW5wdXQoKSBjb25maWd0eXBlOiBzdHJpbmc7XHJcbiAgICBASW5wdXQoKSBjb25maWd2YWx1ZTogbnVtYmVyO1xyXG4gICAgQElucHV0KCkgY29uZmlnbWVzc2FnZTogc3RyaW5nO1xyXG5cclxuICAgIGNvbnN0cnVjdG9yKFxyXG4gICAgICAgIHByaXZhdGUgX2tkRG9tRWxlbVN2YzogS2REb21FbGVtU3ZjXHJcbiAgICApIHsgfVxyXG5cclxuICAgIG5nT25Jbml0KCk6IHZvaWQge1xyXG4gICAgICAgIHRoaXMuY29uZmlnRGVmYXVsdHMoKTtcclxuICAgICAgICAvLyBjb25zb2xlLmxvZyh0aGlzLnZhbHVlKTtcclxuICAgIH1cclxuXHJcbiAgICBuZ09uQ2hhbmdlcygpOiB2b2lkIHtcclxuICAgICAgICAvLyBjb25zb2xlLmxvZyh0aGlzLnZhbHVlKTtcclxuICAgICAgICAvLyBjb25zb2xlLmxvZyh0aGlzLmNvbmZpZ3ZhbHVlKTtcclxuXHJcbiAgICAgICAgdGhpcy52YWx1ZSA9IHRoaXMuY29uZmlndmFsdWU7XHJcblxyXG4gICAgICAgIGlmICh0aGlzLnZhbHVlID49IDEwMCkge1xyXG4gICAgICAgICAgICB0aGlzLnZhbHVlID0gMTAwO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIGNvbmZpZ0RlZmF1bHRzKCkge1xyXG4gICAgICAgIHRoaXMubWVzc2FnZSA9ICh0eXBlb2YgdGhpcy5jb25maWdtZXNzYWdlICE9PSAndW5kZWZpbmVkJykgPyB0aGlzLmNvbmZpZ21lc3NhZ2UgOiAnJztcclxuICAgICAgICB0aGlzLnZhbHVlID0gKHR5cGVvZiB0aGlzLmNvbmZpZ3ZhbHVlICE9PSAndW5kZWZpbmVkJyB8fCB0aGlzLmNvbmZpZ3ZhbHVlICE9PSBudWxsKSA/IHRoaXMuY29uZmlndmFsdWUgOiBudWxsO1xyXG5cclxuICAgICAgICBpZiAodHlwZW9mIHRoaXMuY29uZmlndHlwZSAhPT0gJ3VuZGVmaW5lZCcpIHtcclxuICAgICAgICAgICAgdGhpcy50eXBlID0gdGhpcy5jb25maWd0eXBlO1xyXG5cclxuICAgICAgICAgICAgaWYgKHRoaXMudHlwZSA9PT0gJ3dob2xlcGFnZXNwaW5uZXInKSB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLmNyZWF0ZUxvYWRwYWdlKCk7XHJcbiAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgdGhpcy50eXBlID0gJ3Byb2dyZXNzYmFyJztcclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBjcmVhdGVMb2FkcGFnZSgpIHtcclxuICAgICAgICBsZXQgbG9hZGluZ1RleHQgPSAnTG9hZGluZy4uLic7XHJcbiAgICAgICAgbGV0IGJvZHkgPSBkb2N1bWVudC5ib2R5O1xyXG4gICAgICAgIGxldCBuZXdEaXYgPSB0aGlzLl9rZERvbUVsZW1TdmMuY3JlYXRlRWxlbWVudChib2R5LCAna2R4LWxvYWQtcGFnZScpO1xyXG4gICAgICAgIGxldCBsb2FkZXJXcmFwcGVyID0gdGhpcy5fa2REb21FbGVtU3ZjLmNyZWF0ZUVsZW1lbnQobmV3RGl2LCAna2R4LWxvYWRlci13cmFwcGVyJyk7XHJcblxyXG4gICAgICAgIGxldCBuZXdTcGlubmVyQ29udGFpbmVyID0gdGhpcy5fa2REb21FbGVtU3ZjLmNyZWF0ZUVsZW1lbnQobG9hZGVyV3JhcHBlciwgJ2tkeC1sb2FkZXItY29udGFpbmVyJyk7XHJcbiAgICAgICAgdGhpcy5fa2REb21FbGVtU3ZjLmNyZWF0ZUVsZW1lbnQobmV3U3Bpbm5lckNvbnRhaW5lciwgJ2tkeC1sb2FkZXIga2R4LXJvdGF0aW5nJyk7XHJcbiAgICAgICAgdGhpcy5fa2REb21FbGVtU3ZjLmNyZWF0ZUVsZW1lbnQobmV3U3Bpbm5lckNvbnRhaW5lciwgJ2ZhIGtkLW9wZW5lbWlzIG9wZW5lbWlzLWljb24nLCAnaScpO1xyXG5cclxuICAgICAgICBsZXQgbG9hZGVyVGV4dFdyYXBwZXIgPSB0aGlzLl9rZERvbUVsZW1TdmMuY3JlYXRlRWxlbWVudChsb2FkZXJXcmFwcGVyLCAna2R4LWxvYWRlci10ZXh0LXdyYXBwZXInKTtcclxuICAgICAgICBsZXQgbmV3TG9hZGluZ1RleHQgPSB0aGlzLl9rZERvbUVsZW1TdmMuY3JlYXRlRWxlbWVudChsb2FkZXJUZXh0V3JhcHBlciwgJ2tkeC1sb2FkZXItdGV4dC1sb2FkaW5nJywgJ2RpdicpO1xyXG4gICAgICAgIG5ld0xvYWRpbmdUZXh0LmlubmVySFRNTCA9IGxvYWRpbmdUZXh0ICsgJzAlJztcclxuXHJcbiAgICAgICAgaWYgKHRoaXMubWVzc2FnZSkge1xyXG4gICAgICAgICAgICBsZXQgbmV3TWVzc2FnZSA9IHRoaXMuX2tkRG9tRWxlbVN2Yy5jcmVhdGVFbGVtZW50KGxvYWRlclRleHRXcmFwcGVyLCAnbG9hZGVyLW5ldy1tZXNzYWdlJywgJ3AnKTtcclxuICAgICAgICAgICAgbmV3TWVzc2FnZS5pbm5lckhUTUwgPSB0aGlzLm1lc3NhZ2U7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICBsZXQgdGhpc0ludGVydmFsSWQgPSBzZXRJbnRlcnZhbCgoKTogdm9pZCA9PiB7XHJcbiAgICAgICAgICAgIGlmICh0aGlzLnZhbHVlIDw9IDEwMCkge1xyXG4gICAgICAgICAgICAgICAgbmV3TG9hZGluZ1RleHQuaW5uZXJIVE1MID0gKGxvYWRpbmdUZXh0ICsgdGhpcy52YWx1ZSArICclJykudHJpbSgpO1xyXG4gICAgICAgICAgICAgICAgLy8gbmV3TG9hZGluZ1BlcmNlbnQuaW5uZXJIVE1MID0gdGhpcy52YWx1ZSArICclJztcclxuICAgICAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgICAgIGNsZWFySW50ZXJ2YWwodGhpc0ludGVydmFsSWQpO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfSwgNTAwKTtcclxuICAgIH1cclxufVxyXG4iXX0=