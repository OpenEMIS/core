import { Component, Input } from '@angular/core';
import { KdDataSvc } from '../kd-common/index';
export class KdTemplateLayout {
    constructor(
    // private _pageEvent: KdPageBaseEvent,
    // private _router: Router,
    _dataSvc) {
        this._dataSvc = _dataSvc;
        this.localApi = {
            header: {},
            pageHeader: {},
            breadcrumbs: {},
            navigation: {}
        };
    }
    ngOnInit() {
        this._initApi();
    }
    ngOnDestroy() {
    }
    changeDetectFrom(question) {
        // console.log('Adv search component change detect from: ', question);
    }
    submittedFormValue(formVal) {
        // console.log('Adv search form submit data: ', formVal);
    }
    _initApi() {
        if (!this.api)
            return;
        // this.api = this.localApi;
        this._dataSvc.deepCombineObject(this.api, this.localApi);
        // this._cdr.detectChanges();
        // console.log('set to api', this.api);
    }
}
KdTemplateLayout.decorators = [
    { type: Component, args: [{
                selector: 'kd-template-layout',
                template: `
        <kd-splitter class='has-header has-footer main'>
            <kd-pane size='10%' max='30%' min='2%'>
                <kd-leftmenu [config]='leftNavConfig' [api]='localApi.navigation'></kd-leftmenu>
            </kd-pane>
            <kd-pane>
                <ng-template ngbModalContainer></ng-template>
                <kd-alert></kd-alert>
                <kd-header [config]='headerConfig' [api]='localApi.header'></kd-header>
                <div class='main-wrapper'>
                    <div class='content-wrapper'>
                        <kd-breadcrumb [config]='breadcrumbConfig' [api]='localApi.breadcrumbs'></kd-breadcrumb>
                        <kd-pageheader [config]='pageHeaderConfig' [api]='localApi.pageHeader'></kd-pageheader>
                        <div class='content-area'>
                            <div class='content'>
                                <router-outlet></router-outlet>
                            </div>
                            <kd-footer enableFloat='true'></kd-footer>
                        </div>
                        <!-- <kd-adv-search [formData]='searchFormData' (fieldValue)='changeDetectFrom($event)' (formValue)='submittedFormValue($event)'></kd-adv-search> -->
                    </div>
                </div>
            </kd-pane>
        </kd-splitter>
    `,
                providers: [
                    KdDataSvc
                    // KdPageBaseEvent
                ]
            },] }
];
KdTemplateLayout.ctorParameters = () => [
    { type: KdDataSvc }
];
KdTemplateLayout.propDecorators = {
    leftNavConfig: [{ type: Input, args: ['navigation',] }],
    headerConfig: [{ type: Input, args: ['header',] }],
    pageHeaderConfig: [{ type: Input, args: ['pageheader',] }],
    breadcrumbConfig: [{ type: Input, args: ['breadcrumbs',] }],
    searchFormData: [{ type: Input, args: ['search',] }],
    api: [{ type: Input }]
};
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoia2QtYW5ndWxhci10ZW1wbGF0ZS1sYXlvdXQuanMiLCJzb3VyY2VSb290IjoiQzoveGFtcHAvaHRkb2NzL1N0eWxlZ3VpZGUvaW9zdGctb3BlbmVtaXMtc3R5bGVndWlkZS9wcm9qZWN0cy9vcGVuZW1pcy1zdHlsZWd1aWRlLWxpYi9zcmMvIiwic291cmNlcyI6WyJrZC1jb21wb25lbnRzL2tkLWFuZ3VsYXItdGVtcGxhdGUtbGF5b3V0L2tkLWFuZ3VsYXItdGVtcGxhdGUtbGF5b3V0LnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBLE9BQU8sRUFDSCxTQUFTLEVBR1QsS0FBSyxFQUNSLE1BQU0sZUFBZSxDQUFDO0FBT3ZCLE9BQU8sRUFBRSxTQUFTLEVBQUUsTUFBTSxvQkFBb0IsQ0FBQztBQXVDL0MsTUFBTSxPQUFPLGdCQUFnQjtJQWtCekI7SUFDSSx1Q0FBdUM7SUFDdkMsMkJBQTJCO0lBQ25CLFFBQW1CO1FBQW5CLGFBQVEsR0FBUixRQUFRLENBQVc7UUFwQnhCLGFBQVEsR0FBdUI7WUFDbEMsTUFBTSxFQUFFLEVBQUU7WUFDVixVQUFVLEVBQUUsRUFBRTtZQUNkLFdBQVcsRUFBRSxFQUFFO1lBQ2YsVUFBVSxFQUFFLEVBQUU7U0FDakIsQ0FBQztJQWtCRixDQUFDO0lBRUQsUUFBUTtRQUNKLElBQUksQ0FBQyxRQUFRLEVBQUUsQ0FBQztJQUNwQixDQUFDO0lBRUQsV0FBVztJQUVYLENBQUM7SUFFTSxnQkFBZ0IsQ0FBQyxRQUFhO1FBQ2pDLHNFQUFzRTtJQUMxRSxDQUFDO0lBRU0sa0JBQWtCLENBQUMsT0FBWTtRQUNsQyx5REFBeUQ7SUFDN0QsQ0FBQztJQUVPLFFBQVE7UUFDWixJQUFJLENBQUMsSUFBSSxDQUFDLEdBQUc7WUFBRSxPQUFPO1FBRXRCLDRCQUE0QjtRQUM1QixJQUFJLENBQUMsUUFBUSxDQUFDLGlCQUFpQixDQUFDLElBQUksQ0FBQyxHQUFHLEVBQUUsSUFBSSxDQUFDLFFBQVEsQ0FBQyxDQUFDO1FBRXpELDZCQUE2QjtRQUM3Qix1Q0FBdUM7SUFDM0MsQ0FBQzs7O1lBcEZKLFNBQVMsU0FBQztnQkFDUCxRQUFRLEVBQUUsb0JBQW9CO2dCQUM5QixRQUFRLEVBQUU7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztLQXdCVDtnQkFDRCxTQUFTLEVBQUU7b0JBQ1AsU0FBUztvQkFDVCxrQkFBa0I7aUJBQ3JCO2FBQ0o7OztZQXBDUSxTQUFTOzs7NEJBa0RiLEtBQUssU0FBQyxZQUFZOzJCQUNsQixLQUFLLFNBQUMsUUFBUTsrQkFDZCxLQUFLLFNBQUMsWUFBWTsrQkFDbEIsS0FBSyxTQUFDLGFBQWE7NkJBQ25CLEtBQUssU0FBQyxRQUFRO2tCQUNkLEtBQUsiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQge1xyXG4gICAgQ29tcG9uZW50LFxyXG4gICAgT25Jbml0LFxyXG4gICAgT25EZXN0cm95LFxyXG4gICAgSW5wdXRcclxufSBmcm9tICdAYW5ndWxhci9jb3JlJztcclxuLy8gaW1wb3J0IHsgU3Vic2NyaXB0aW9uIH0gZnJvbSAncnhqcy9TdWJzY3JpcHRpb24nO1xyXG4vLyBpbXBvcnQgeyBSb3V0ZXIgfSBmcm9tICdAYW5ndWxhci9yb3V0ZXInO1xyXG4vLyBpbXBvcnQgeyBLZFRlbXBsYXRlTGF5b3V0U3ZjIH0gZnJvbSAnLi9rZC1hbmd1bGFyLXRlbXBsYXRlLWxheW91dC1zdmMnO1xyXG5pbXBvcnQgeyBJVGVtcGxhdGVMYXlvdXRBUEkgfSBmcm9tICcuL2tkLWFuZ3VsYXItdGVtcGxhdGUtbGF5b3V0LWludGVyZmFjZSc7XHJcbmltcG9ydCB7IC8qSUhlYWRlckFQSSwqLyBJSGVhZGVyQ29uZmlnIH0gZnJvbSAnLi4va2QtYW5ndWxhci1oZWFkZXIvaW5kZXgnO1xyXG5pbXBvcnQgeyBJQnJlYWRjcnVtYkNvbmZpZyB9IGZyb20gJy4uL2tkLWFuZ3VsYXItYnJlYWRjcnVtYi9pbmRleCc7XHJcbmltcG9ydCB7IEtkRGF0YVN2YyB9IGZyb20gJy4uL2tkLWNvbW1vbi9pbmRleCc7XHJcblxyXG5pbXBvcnQgeyAvKklQYWdlaGVhZGVyQXBpLCovIElQYWdlaGVhZGVyQ29uZmlnIH0gZnJvbSAnLi4va2QtYW5ndWxhci1wYWdlaGVhZGVyL2luZGV4JztcclxuXHJcblxyXG5AQ29tcG9uZW50KHtcclxuICAgIHNlbGVjdG9yOiAna2QtdGVtcGxhdGUtbGF5b3V0JyxcclxuICAgIHRlbXBsYXRlOiBgXHJcbiAgICAgICAgPGtkLXNwbGl0dGVyIGNsYXNzPSdoYXMtaGVhZGVyIGhhcy1mb290ZXIgbWFpbic+XHJcbiAgICAgICAgICAgIDxrZC1wYW5lIHNpemU9JzEwJScgbWF4PSczMCUnIG1pbj0nMiUnPlxyXG4gICAgICAgICAgICAgICAgPGtkLWxlZnRtZW51IFtjb25maWddPSdsZWZ0TmF2Q29uZmlnJyBbYXBpXT0nbG9jYWxBcGkubmF2aWdhdGlvbic+PC9rZC1sZWZ0bWVudT5cclxuICAgICAgICAgICAgPC9rZC1wYW5lPlxyXG4gICAgICAgICAgICA8a2QtcGFuZT5cclxuICAgICAgICAgICAgICAgIDxuZy10ZW1wbGF0ZSBuZ2JNb2RhbENvbnRhaW5lcj48L25nLXRlbXBsYXRlPlxyXG4gICAgICAgICAgICAgICAgPGtkLWFsZXJ0Pjwva2QtYWxlcnQ+XHJcbiAgICAgICAgICAgICAgICA8a2QtaGVhZGVyIFtjb25maWddPSdoZWFkZXJDb25maWcnIFthcGldPSdsb2NhbEFwaS5oZWFkZXInPjwva2QtaGVhZGVyPlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzcz0nbWFpbi13cmFwcGVyJz5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzPSdjb250ZW50LXdyYXBwZXInPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8a2QtYnJlYWRjcnVtYiBbY29uZmlnXT0nYnJlYWRjcnVtYkNvbmZpZycgW2FwaV09J2xvY2FsQXBpLmJyZWFkY3J1bWJzJz48L2tkLWJyZWFkY3J1bWI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxrZC1wYWdlaGVhZGVyIFtjb25maWddPSdwYWdlSGVhZGVyQ29uZmlnJyBbYXBpXT0nbG9jYWxBcGkucGFnZUhlYWRlcic+PC9rZC1wYWdlaGVhZGVyPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzPSdjb250ZW50LWFyZWEnPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzcz0nY29udGVudCc+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHJvdXRlci1vdXRsZXQ+PC9yb3V0ZXItb3V0bGV0PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8a2QtZm9vdGVyIGVuYWJsZUZsb2F0PSd0cnVlJz48L2tkLWZvb3Rlcj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwhLS0gPGtkLWFkdi1zZWFyY2ggW2Zvcm1EYXRhXT0nc2VhcmNoRm9ybURhdGEnIChmaWVsZFZhbHVlKT0nY2hhbmdlRGV0ZWN0RnJvbSgkZXZlbnQpJyAoZm9ybVZhbHVlKT0nc3VibWl0dGVkRm9ybVZhbHVlKCRldmVudCknPjwva2QtYWR2LXNlYXJjaD4gLS0+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPC9rZC1wYW5lPlxyXG4gICAgICAgIDwva2Qtc3BsaXR0ZXI+XHJcbiAgICBgLFxyXG4gICAgcHJvdmlkZXJzOiBbXHJcbiAgICAgICAgS2REYXRhU3ZjXHJcbiAgICAgICAgLy8gS2RQYWdlQmFzZUV2ZW50XHJcbiAgICBdXHJcbn0pXHJcblxyXG5cclxuZXhwb3J0IGNsYXNzIEtkVGVtcGxhdGVMYXlvdXQgaW1wbGVtZW50cyBPbkluaXQsIE9uRGVzdHJveSB7XHJcbiAgICBwdWJsaWMgbG9jYWxBcGk6IElUZW1wbGF0ZUxheW91dEFQSSA9IHtcclxuICAgICAgICBoZWFkZXI6IHt9LFxyXG4gICAgICAgIHBhZ2VIZWFkZXI6IHt9LFxyXG4gICAgICAgIGJyZWFkY3J1bWJzOiB7fSxcclxuICAgICAgICBuYXZpZ2F0aW9uOiB7fVxyXG4gICAgfTtcclxuXHJcbiAgICAvLyBwcml2YXRlIF9wYWdlaGVhZGVyU3ViOiBTdWJzY3JpcHRpb247XHJcbiAgICAvLyBwcml2YXRlIF9icmVhZGNydW1iU3ViOiBTdWJzY3JpcHRpb247XHJcblxyXG4gICAgQElucHV0KCduYXZpZ2F0aW9uJykgbGVmdE5hdkNvbmZpZzogYW55O1xyXG4gICAgQElucHV0KCdoZWFkZXInKSBoZWFkZXJDb25maWc6IElIZWFkZXJDb25maWc7XHJcbiAgICBASW5wdXQoJ3BhZ2VoZWFkZXInKSBwYWdlSGVhZGVyQ29uZmlnOiBJUGFnZWhlYWRlckNvbmZpZztcclxuICAgIEBJbnB1dCgnYnJlYWRjcnVtYnMnKSBicmVhZGNydW1iQ29uZmlnOiBJQnJlYWRjcnVtYkNvbmZpZztcclxuICAgIEBJbnB1dCgnc2VhcmNoJykgc2VhcmNoRm9ybURhdGE6IGFueTtcclxuICAgIEBJbnB1dCgpIGFwaTogYW55O1xyXG5cclxuICAgIGNvbnN0cnVjdG9yKFxyXG4gICAgICAgIC8vIHByaXZhdGUgX3BhZ2VFdmVudDogS2RQYWdlQmFzZUV2ZW50LFxyXG4gICAgICAgIC8vIHByaXZhdGUgX3JvdXRlcjogUm91dGVyLFxyXG4gICAgICAgIHByaXZhdGUgX2RhdGFTdmM6IEtkRGF0YVN2YyxcclxuICAgICkge1xyXG5cclxuICAgIH1cclxuXHJcbiAgICBuZ09uSW5pdCgpOiB2b2lkIHtcclxuICAgICAgICB0aGlzLl9pbml0QXBpKCk7XHJcbiAgICB9XHJcblxyXG4gICAgbmdPbkRlc3Ryb3koKTogdm9pZCB7XHJcblxyXG4gICAgfVxyXG5cclxuICAgIHB1YmxpYyBjaGFuZ2VEZXRlY3RGcm9tKHF1ZXN0aW9uOiBhbnkpOiB2b2lkIHtcclxuICAgICAgICAvLyBjb25zb2xlLmxvZygnQWR2IHNlYXJjaCBjb21wb25lbnQgY2hhbmdlIGRldGVjdCBmcm9tOiAnLCBxdWVzdGlvbik7XHJcbiAgICB9XHJcblxyXG4gICAgcHVibGljIHN1Ym1pdHRlZEZvcm1WYWx1ZShmb3JtVmFsOiBhbnkpOiB2b2lkIHtcclxuICAgICAgICAvLyBjb25zb2xlLmxvZygnQWR2IHNlYXJjaCBmb3JtIHN1Ym1pdCBkYXRhOiAnLCBmb3JtVmFsKTtcclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF9pbml0QXBpKCkge1xyXG4gICAgICAgIGlmICghdGhpcy5hcGkpIHJldHVybjtcclxuXHJcbiAgICAgICAgLy8gdGhpcy5hcGkgPSB0aGlzLmxvY2FsQXBpO1xyXG4gICAgICAgIHRoaXMuX2RhdGFTdmMuZGVlcENvbWJpbmVPYmplY3QodGhpcy5hcGksIHRoaXMubG9jYWxBcGkpO1xyXG5cclxuICAgICAgICAvLyB0aGlzLl9jZHIuZGV0ZWN0Q2hhbmdlcygpO1xyXG4gICAgICAgIC8vIGNvbnNvbGUubG9nKCdzZXQgdG8gYXBpJywgdGhpcy5hcGkpO1xyXG4gICAgfVxyXG59XHJcbiJdfQ==