import { Injectable } from '@angular/core';
import * as i0 from "@angular/core";
export class KdTemplateLayoutSvc {
    constructor() {
        this._api = {};
    }
    setApi(_name, _api) {
        if (typeof _name !== undefined && _name !== '' && typeof _api !== undefined) {
            this._api[_name] = _api;
        }
    }
    getApi(_name) {
        if (typeof _name === undefined || _name === '' || !this._api.hasOwnProperty(_name))
            return undefined;
        return this._api[_name];
    }
}
KdTemplateLayoutSvc.ɵprov = i0.ɵɵdefineInjectable({ factory: function KdTemplateLayoutSvc_Factory() { return new KdTemplateLayoutSvc(); }, token: KdTemplateLayoutSvc, providedIn: "root" });
KdTemplateLayoutSvc.decorators = [
    { type: Injectable, args: [{
                providedIn: 'root'
            },] }
];
KdTemplateLayoutSvc.ctorParameters = () => [];
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoia2QtYW5ndWxhci10ZW1wbGF0ZS1sYXlvdXQtc3ZjLmpzIiwic291cmNlUm9vdCI6IkM6L3hhbXBwL2h0ZG9jcy9TdHlsZWd1aWRlL2lvc3RnLW9wZW5lbWlzLXN0eWxlZ3VpZGUvcHJvamVjdHMvb3BlbmVtaXMtc3R5bGVndWlkZS1saWIvc3JjLyIsInNvdXJjZXMiOlsia2QtY29tcG9uZW50cy9rZC1hbmd1bGFyLXRlbXBsYXRlLWxheW91dC9rZC1hbmd1bGFyLXRlbXBsYXRlLWxheW91dC1zdmMudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsT0FBTyxFQUFFLFVBQVUsRUFBRSxNQUFNLGVBQWUsQ0FBQzs7QUFLM0MsTUFBTSxPQUFPLG1CQUFtQjtJQUc1QjtRQUZRLFNBQUksR0FBUSxFQUFFLENBQUM7SUFFUCxDQUFDO0lBRVYsTUFBTSxDQUFDLEtBQWEsRUFBRSxJQUFTO1FBQ2xDLElBQUksT0FBTyxLQUFLLEtBQUssU0FBUyxJQUFJLEtBQUssS0FBSyxFQUFFLElBQUksT0FBTyxJQUFJLEtBQUssU0FBUyxFQUFFO1lBQ3pFLElBQUksQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLEdBQUcsSUFBSSxDQUFDO1NBQzNCO0lBQ0wsQ0FBQztJQUVNLE1BQU0sQ0FBQyxLQUFhO1FBQ3ZCLElBQUksT0FBTyxLQUFLLEtBQUssU0FBUyxJQUFJLEtBQUssS0FBSyxFQUFFLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLGNBQWMsQ0FBQyxLQUFLLENBQUM7WUFBRSxPQUFPLFNBQVMsQ0FBQztRQUNyRyxPQUFPLElBQUksQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLENBQUM7SUFDNUIsQ0FBQzs7OztZQWpCSixVQUFVLFNBQUM7Z0JBQ1IsVUFBVSxFQUFFLE1BQU07YUFDckIiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBJbmplY3RhYmxlIH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XHJcblxyXG5ASW5qZWN0YWJsZSh7XHJcbiAgICBwcm92aWRlZEluOiAncm9vdCdcclxufSlcclxuZXhwb3J0IGNsYXNzIEtkVGVtcGxhdGVMYXlvdXRTdmMge1xyXG4gICAgcHJpdmF0ZSBfYXBpOiBhbnkgPSB7fTtcclxuXHJcbiAgICBjb25zdHJ1Y3RvcigpIHsgfVxyXG5cclxuICAgIHB1YmxpYyBzZXRBcGkoX25hbWU6IHN0cmluZywgX2FwaTogYW55KTogdm9pZCB7XHJcbiAgICAgICAgaWYgKHR5cGVvZiBfbmFtZSAhPT0gdW5kZWZpbmVkICYmIF9uYW1lICE9PSAnJyAmJiB0eXBlb2YgX2FwaSAhPT0gdW5kZWZpbmVkKSB7XHJcbiAgICAgICAgICAgIHRoaXMuX2FwaVtfbmFtZV0gPSBfYXBpO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICBwdWJsaWMgZ2V0QXBpKF9uYW1lOiBzdHJpbmcpOiBhbnkge1xyXG4gICAgICAgIGlmICh0eXBlb2YgX25hbWUgPT09IHVuZGVmaW5lZCB8fCBfbmFtZSA9PT0gJycgfHwgIXRoaXMuX2FwaS5oYXNPd25Qcm9wZXJ0eShfbmFtZSkpIHJldHVybiB1bmRlZmluZWQ7XHJcbiAgICAgICAgcmV0dXJuIHRoaXMuX2FwaVtfbmFtZV07XHJcbiAgICB9XHJcbn1cclxuIl19