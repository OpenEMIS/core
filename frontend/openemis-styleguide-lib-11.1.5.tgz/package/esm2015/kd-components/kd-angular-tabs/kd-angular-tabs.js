import { Component, Input, Output, EventEmitter, ViewEncapsulation, ViewContainerRef, HostListener, ChangeDetectorRef, Renderer2 } from '@angular/core';
import { timer } from 'rxjs';
import { Router, ActivatedRoute } from '@angular/router';
import { KdTabsSvc } from './kd-angular-tabs-svc';
import { KdDomElemSvc } from '../kd-common/index';
import { KdSplitterEvent } from '../kd-angular-splitter/index';
export class KdTabs {
    constructor(_vcr, _renderer, _cd, _tabSvc, _router, _activeRoute, _domEle, _splitterEvent) {
        this._vcr = _vcr;
        this._renderer = _renderer;
        this._cd = _cd;
        this._tabSvc = _tabSvc;
        this._router = _router;
        this._domEle = _domEle;
        this._splitterEvent = _splitterEvent;
        this._result = [];
        this._hasArray = false;
        this._scrollBtn = false;
        this._disableLeft = false;
        this._disableRight = false;
        this._left = 0;
        this._maxLeft = 0;
        this._ulWidth = 0;
        this._ulMargin = 0;
        this._parentPadding = 30;
        this.activeState = new EventEmitter();
    }
    onResize(event) {
        this._checkWidth();
        this._checkScrollable();
    }
    ngOnInit() {
        this._id = (typeof this.inputId !== 'undefined') ? this.inputId : 'tabs';
        this._result = this._tabSvc.setResult(this.tabsConfig, this.tabType);
        this._hasArray = this._tabSvc.checkHasArray(this._result);
        if (typeof this._result !== 'undefined') {
            for (let i = 0; i < this._result.length; i++) {
                if (this._result[i].isActive === true) {
                    this._previousItem = this._result[i];
                    this.activeState.emit(this._previousItem.tabId);
                    // if (this._previousItem.tabType === 'router') {
                    //     this._router.navigate(['./' + this._previousItem.routerPath], { relativeTo: this._route });
                    // }
                    break;
                }
            }
        }
        this._splitterEvent.onDrag()
            .subscribe(_type => {
            this._checkWidth();
            this._checkScrollable();
        });
        this._splitterEvent.onToggleMenu()
            .subscribe(_type => {
            timer(500).subscribe(() => {
                this._checkWidth();
                this._checkScrollable();
            });
        });
    }
    ngOnChanges() {
        this._result = this._tabSvc.setResult(this.tabsConfig, this.tabType);
        this._hasArray = this._tabSvc.checkHasArray(this._result);
        if (typeof this._result !== 'undefined') {
            for (let i = 0; i < this._result.length; i++) {
                if (this._result[i].isActive === true) {
                    this._previousItem = this._result[i];
                    this.activeState.emit(this._previousItem.tabId);
                    if (this._previousItem.tabType === 'router') {
                        // console.log('Kd-angular-tab - Need to relook this section', this._previousItem.routerPath, this._route );
                        // this._router.navigate(['./' + this._previousItem.routerPath], { relativeTo: this._route });
                        /* Change the navigation on first load to use full router path to match all the path */
                        this._router.navigateByUrl(this._previousItem.routerPath);
                    }
                    break;
                }
            }
        }
        timer(50).subscribe(() => {
            this._checkWidth();
            this._checkScrollable();
        });
    }
    ngAfterViewInit() {
        // this._direction = this._tabSvc.checkDirection();
        this._direction = this._domEle.getDocumentDirection(true);
        this._checkWidth();
        this._cd.detach();
        this._checkScrollable();
        this._cd.detectChanges();
        this._cd.reattach();
    }
    selectTab(item, e) {
        e.preventDefault();
        if (typeof item.disabled !== 'undefined' && item.disabled)
            return;
        if (typeof this._previousItem !== 'undefined' && this._previousItem !== item) {
            this._previousItem.isActive = false;
        }
        if (item.tabType === 'router' && item.isActive === false) {
            this._router.navigateByUrl(item.routerPath);
        }
        item.isActive = true;
        this._previousItem = item;
        this.activeState.emit(this._previousItem.tabId);
        this._setSelected();
    }
    scroll(direction) {
        let offsetX = 200;
        this._left = (direction === 'right') ? this._left - offsetX : this._left + offsetX;
        this._setLeft();
    }
    _checkWidth() {
        this._ulWidth = 0;
        let ulList = this._vcr.element.nativeElement.querySelectorAll('#' + this._id + ' .nav-item');
        // console.log(ulList);
        // console.log(this._result);
        if (typeof ulList !== 'undefined' && ulList.length > 1) {
            if (this._direction === 'left') {
                this._ulMargin = ulList[1].getBoundingClientRect().left - ulList[0].getBoundingClientRect().right;
            }
            else {
                this._ulMargin = ulList[0].getBoundingClientRect().left - ulList[1].getBoundingClientRect().right;
            }
        }
        if (typeof this._result !== 'undefined') {
            for (let i = 0; i < ulList.length; i++) {
                if (typeof this._result[i] === 'undefined')
                    continue;
                this._result[i].width = Math.round(ulList[i].getBoundingClientRect().width);
                if (i !== 0) {
                    this._result[i].width = Math.round(this._result[i].width + this._ulMargin);
                }
                this._ulWidth += this._result[i].width;
            }
        }
    }
    _checkScrollable() {
        let parentWidth = this._vcr.element.nativeElement.parentElement.getBoundingClientRect().width;
        let ulElement = this._vcr.element.nativeElement.querySelector('#' + this._id + ' .nav-tabs');
        this._scrollBtn = (this._ulWidth > parentWidth) ? true : false;
        this._scrollBtn ? this._renderer.addClass(ulElement, 'scrollable') : this._renderer.removeClass(ulElement, 'scrollable');
        timer(100).subscribe(() => {
            if (ulElement.clientWidth < this._ulWidth) {
                if (this._direction === 'left') {
                    this._maxLeft = ulElement.clientWidth - this._ulWidth;
                }
                else {
                    this._maxLeft = this._ulWidth - ulElement.clientWidth;
                }
            }
            if (!this._scrollBtn) {
                this._left = 0;
                this._setLeft();
            }
            else {
                this._setSelected();
            }
        });
    }
    _setSelected() {
        let parentWidth = this._vcr.element.nativeElement.querySelector('#' + this._id + ' .nav-tabs').clientWidth - this._parentPadding;
        let middle = parentWidth / 2;
        let width = 0;
        if (this._scrollBtn) {
            // if (this._direction === 'left') {
            for (let i = 0; i < this._result.length; i++) {
                if (this._previousItem !== this._result[i]) {
                    width += this._result[i].width;
                }
                else {
                    width += (this._result[i].width / 2);
                    if (this._direction === 'left') {
                        this._left = middle - width;
                    }
                    else {
                        this._left = width - middle;
                    }
                    break;
                }
            }
            // }
            // else {
            //     for (let i: number = this._result.length - 1; i >= 0; i--) {
            //         if (this._previousItem !== this._result[i]) {
            //             width += this._result[i].width;
            //         }
            //         else {
            //             width += (this._result[i].width / 2);
            //             this._left = width - middle;
            //             break;
            //         }
            //     }
            // }
        }
        else {
            this._left = 0;
        }
        this._setLeft();
    }
    _setLeft() {
        let item = this._vcr.element.nativeElement.querySelectorAll('#' + this._id + ' .nav-item');
        if (this._direction === 'left') {
            if (this._left < this._maxLeft) {
                this._left = this._maxLeft;
            }
            else if (this._left >= 0) {
                this._left = 0;
            }
            this._disableLeft = (this._left === 0) ? true : false;
            this._disableRight = (this._left === this._maxLeft) ? true : false;
        }
        else {
            if (this._left < 0) {
                this._left = 0;
            }
            else if (this._left > this._maxLeft) {
                this._left = this._maxLeft;
            }
            this._disableLeft = (this._left === this._maxLeft) ? true : false;
            this._disableRight = (this._left === 0) ? true : false;
        }
        let move = this._left + 'px';
        for (let i = 0; i < item.length; i++) {
            this._renderer.setStyle(item[i], 'left', move);
        }
    }
}
KdTabs.decorators = [
    { type: Component, args: [{
                selector: 'kd-tabs',
                template: `
        <div class='nav-bar' [hidden]='!_hasArray' [id]='_id'>
            <button *ngIf='_scrollBtn' (click)='scroll("left")' class='scroll-left' [disabled]='_disableLeft'><</button>
            <ul class='nav nav-tabs'>
                <ng-template ngFor let-item [ngForOf]='_result'>
                    <li class='nav-item' style='left:0px' [ngClass]='{"tab-selected": item.isActive, "tab-disabled": item.disabled}'>
                        <a (click)='selectTab(item, $event)' class='nav-link'>{{item.tabName}}</a>
                        <!-- <a *ngIf='item.tabType !== "router"' (click)='selectTab(item, $event)' class='nav-link'>{{item.tabName}}</a>
                        <a *ngIf='item.tabType === "router"' (click)='selectTab(item, $event)' class='nav-link' [routerLink]='item.routerPath'>{{item.tabName}}</a> -->
                    </li>
                </ng-template>
            </ul>
            <button *ngIf='_scrollBtn' (click)='scroll("right")' class='scroll-right' [disabled]='_disableRight'>></button>
            <div class='tab-divider'></div>
         </div>

        <ng-template [ngIf]='_previousItem && _previousItem.tabType === "content"'>
            <div class='tab-content'>
                <div class='tab-pane' [ngClass]='{"active": _previousItem.isActive}'>{{_previousItem.tabContent}}</div>
            </div>
        </ng-template>

        <ng-template [ngIf]='tabType === "router" || tabType === "html"'>
            <ng-content></ng-content>
        </ng-template>

        <div class='tab-bottom-divider'></div>
    `,
                encapsulation: ViewEncapsulation.None,
                providers: [KdTabsSvc, KdDomElemSvc],
                host: {
                    'class': 'kdx-tabs',
                },
                styles: [`
        .angular-tabs .nav-tabs .nav-item.tab-disabled > a.nav-link:hover {
            color: #333 !important;
            border: 1px solid #DDD !important;
            cursor: not-allowed !important;
            background-color: transparent !important;
        }
    `]
            },] }
];
KdTabs.ctorParameters = () => [
    { type: ViewContainerRef },
    { type: Renderer2 },
    { type: ChangeDetectorRef },
    { type: KdTabsSvc },
    { type: Router },
    { type: ActivatedRoute },
    { type: KdDomElemSvc },
    { type: KdSplitterEvent }
];
KdTabs.propDecorators = {
    inputId: [{ type: Input }],
    tabsConfig: [{ type: Input, args: ['config',] }],
    tabType: [{ type: Input, args: ['type',] }],
    activeState: [{ type: Output }],
    onResize: [{ type: HostListener, args: ['window:resize', ['$event'],] }]
};
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoia2QtYW5ndWxhci10YWJzLmpzIiwic291cmNlUm9vdCI6IkM6L3hhbXBwL2h0ZG9jcy9TdHlsZWd1aWRlL2lvc3RnLW9wZW5lbWlzLXN0eWxlZ3VpZGUvcHJvamVjdHMvb3BlbmVtaXMtc3R5bGVndWlkZS1saWIvc3JjLyIsInNvdXJjZXMiOlsia2QtY29tcG9uZW50cy9rZC1hbmd1bGFyLXRhYnMva2QtYW5ndWxhci10YWJzLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBLE9BQU8sRUFBRSxTQUFTLEVBQUUsS0FBSyxFQUFFLE1BQU0sRUFBRSxZQUFZLEVBQUUsaUJBQWlCLEVBQW9DLGdCQUFnQixFQUFFLFlBQVksRUFBRSxpQkFBaUIsRUFBRSxTQUFTLEVBQUUsTUFBTSxlQUFlLENBQUM7QUFDMUwsT0FBTyxFQUFFLEtBQUssRUFBRSxNQUFNLE1BQU0sQ0FBQztBQUM3QixPQUFPLEVBQUUsTUFBTSxFQUFFLGNBQWMsRUFBRSxNQUFNLGlCQUFpQixDQUFDO0FBQ3pELE9BQU8sRUFBRSxTQUFTLEVBQUUsTUFBTSx1QkFBdUIsQ0FBQztBQUNsRCxPQUFPLEVBQUUsWUFBWSxFQUFFLE1BQU0sb0JBQW9CLENBQUM7QUFDbEQsT0FBTyxFQUFFLGVBQWUsRUFBRSxNQUFNLDhCQUE4QixDQUFDO0FBZ0QvRCxNQUFNLE9BQU8sTUFBTTtJQXFCZixZQUNZLElBQXNCLEVBQ3RCLFNBQW9CLEVBQ3BCLEdBQXNCLEVBQ3RCLE9BQWtCLEVBQ2xCLE9BQWUsRUFDdkIsWUFBNEIsRUFDcEIsT0FBcUIsRUFDckIsY0FBK0I7UUFQL0IsU0FBSSxHQUFKLElBQUksQ0FBa0I7UUFDdEIsY0FBUyxHQUFULFNBQVMsQ0FBVztRQUNwQixRQUFHLEdBQUgsR0FBRyxDQUFtQjtRQUN0QixZQUFPLEdBQVAsT0FBTyxDQUFXO1FBQ2xCLFlBQU8sR0FBUCxPQUFPLENBQVE7UUFFZixZQUFPLEdBQVAsT0FBTyxDQUFjO1FBQ3JCLG1CQUFjLEdBQWQsY0FBYyxDQUFpQjtRQTNCcEMsWUFBTyxHQUFlLEVBQUUsQ0FBQztRQUN6QixjQUFTLEdBQVksS0FBSyxDQUFDO1FBQzNCLGVBQVUsR0FBWSxLQUFLLENBQUM7UUFFNUIsaUJBQVksR0FBWSxLQUFLLENBQUM7UUFDOUIsa0JBQWEsR0FBWSxLQUFLLENBQUM7UUFFOUIsVUFBSyxHQUFXLENBQUMsQ0FBQztRQUNsQixhQUFRLEdBQVcsQ0FBQyxDQUFDO1FBQ3JCLGFBQVEsR0FBVyxDQUFDLENBQUM7UUFDckIsY0FBUyxHQUFXLENBQUMsQ0FBQztRQUV0QixtQkFBYyxHQUFXLEVBQUUsQ0FBQztRQUsxQixnQkFBVyxHQUFxQixJQUFJLFlBQVksRUFBRSxDQUFDO0lBVWQsQ0FBQztJQUdoRCxRQUFRLENBQUMsS0FBVTtRQUNmLElBQUksQ0FBQyxXQUFXLEVBQUUsQ0FBQztRQUNuQixJQUFJLENBQUMsZ0JBQWdCLEVBQUUsQ0FBQztJQUM1QixDQUFDO0lBRUQsUUFBUTtRQUNKLElBQUksQ0FBQyxHQUFHLEdBQUcsQ0FBQyxPQUFPLElBQUksQ0FBQyxPQUFPLEtBQUssV0FBVyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQztRQUN6RSxJQUFJLENBQUMsT0FBTyxHQUFHLElBQUksQ0FBQyxPQUFPLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQyxVQUFVLEVBQUUsSUFBSSxDQUFDLE9BQU8sQ0FBQyxDQUFDO1FBRXJFLElBQUksQ0FBQyxTQUFTLEdBQUcsSUFBSSxDQUFDLE9BQU8sQ0FBQyxhQUFhLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxDQUFDO1FBRTFELElBQUksT0FBTyxJQUFJLENBQUMsT0FBTyxLQUFLLFdBQVcsRUFBRTtZQUNyQyxLQUFLLElBQUksQ0FBQyxHQUFXLENBQUMsRUFBRSxDQUFDLEdBQUcsSUFBSSxDQUFDLE9BQU8sQ0FBQyxNQUFNLEVBQUUsQ0FBQyxFQUFFLEVBQUU7Z0JBQ2xELElBQUksSUFBSSxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLEtBQUssSUFBSSxFQUFFO29CQUNuQyxJQUFJLENBQUMsYUFBYSxHQUFHLElBQUksQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUM7b0JBQ3JDLElBQUksQ0FBQyxXQUFXLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxhQUFhLENBQUMsS0FBSyxDQUFDLENBQUM7b0JBRWhELGlEQUFpRDtvQkFDakQsa0dBQWtHO29CQUNsRyxJQUFJO29CQUNKLE1BQU07aUJBQ1Q7YUFDSjtTQUNKO1FBRUQsSUFBSSxDQUFDLGNBQWMsQ0FBQyxNQUFNLEVBQUU7YUFDdkIsU0FBUyxDQUFDLEtBQUssQ0FBQyxFQUFFO1lBQ2YsSUFBSSxDQUFDLFdBQVcsRUFBRSxDQUFDO1lBQ25CLElBQUksQ0FBQyxnQkFBZ0IsRUFBRSxDQUFDO1FBQzVCLENBQUMsQ0FBQyxDQUFDO1FBRVAsSUFBSSxDQUFDLGNBQWMsQ0FBQyxZQUFZLEVBQUU7YUFDN0IsU0FBUyxDQUFDLEtBQUssQ0FBQyxFQUFFO1lBQ2YsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxHQUFTLEVBQUU7Z0JBQzVCLElBQUksQ0FBQyxXQUFXLEVBQUUsQ0FBQztnQkFDbkIsSUFBSSxDQUFDLGdCQUFnQixFQUFFLENBQUM7WUFDNUIsQ0FBQyxDQUFDLENBQUM7UUFDUCxDQUFDLENBQUMsQ0FBQztJQUNYLENBQUM7SUFFRCxXQUFXO1FBQ1AsSUFBSSxDQUFDLE9BQU8sR0FBRyxJQUFJLENBQUMsT0FBTyxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsVUFBVSxFQUFFLElBQUksQ0FBQyxPQUFPLENBQUMsQ0FBQztRQUNyRSxJQUFJLENBQUMsU0FBUyxHQUFHLElBQUksQ0FBQyxPQUFPLENBQUMsYUFBYSxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsQ0FBQztRQUUxRCxJQUFJLE9BQU8sSUFBSSxDQUFDLE9BQU8sS0FBSyxXQUFXLEVBQUU7WUFDckMsS0FBSyxJQUFJLENBQUMsR0FBVyxDQUFDLEVBQUUsQ0FBQyxHQUFHLElBQUksQ0FBQyxPQUFPLENBQUMsTUFBTSxFQUFFLENBQUMsRUFBRSxFQUFFO2dCQUNsRCxJQUFJLElBQUksQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxLQUFLLElBQUksRUFBRTtvQkFDbkMsSUFBSSxDQUFDLGFBQWEsR0FBRyxJQUFJLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDO29CQUNyQyxJQUFJLENBQUMsV0FBVyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsYUFBYSxDQUFDLEtBQUssQ0FBQyxDQUFDO29CQUVoRCxJQUFJLElBQUksQ0FBQyxhQUFhLENBQUMsT0FBTyxLQUFLLFFBQVEsRUFBRTt3QkFDekMsNEdBQTRHO3dCQUM1Ryw4RkFBOEY7d0JBQzlGLHVGQUF1Rjt3QkFDdkYsSUFBSSxDQUFDLE9BQU8sQ0FBQyxhQUFhLENBQUMsSUFBSSxDQUFDLGFBQWEsQ0FBQyxVQUFVLENBQUMsQ0FBQztxQkFDN0Q7b0JBQ0QsTUFBTTtpQkFDVDthQUNKO1NBQ0o7UUFFRCxLQUFLLENBQUMsRUFBRSxDQUFDLENBQUMsU0FBUyxDQUFDLEdBQVMsRUFBRTtZQUMzQixJQUFJLENBQUMsV0FBVyxFQUFFLENBQUM7WUFDbkIsSUFBSSxDQUFDLGdCQUFnQixFQUFFLENBQUM7UUFDNUIsQ0FBQyxDQUFDLENBQUM7SUFFUCxDQUFDO0lBRUQsZUFBZTtRQUNYLG1EQUFtRDtRQUNuRCxJQUFJLENBQUMsVUFBVSxHQUFHLElBQUksQ0FBQyxPQUFPLENBQUMsb0JBQW9CLENBQUMsSUFBSSxDQUFDLENBQUM7UUFDMUQsSUFBSSxDQUFDLFdBQVcsRUFBRSxDQUFDO1FBRW5CLElBQUksQ0FBQyxHQUFHLENBQUMsTUFBTSxFQUFFLENBQUM7UUFDbEIsSUFBSSxDQUFDLGdCQUFnQixFQUFFLENBQUM7UUFDeEIsSUFBSSxDQUFDLEdBQUcsQ0FBQyxhQUFhLEVBQUUsQ0FBQztRQUN6QixJQUFJLENBQUMsR0FBRyxDQUFDLFFBQVEsRUFBRSxDQUFDO0lBQ3hCLENBQUM7SUFFTSxTQUFTLENBQUMsSUFBUyxFQUFFLENBQVE7UUFDaEMsQ0FBQyxDQUFDLGNBQWMsRUFBRSxDQUFDO1FBQ25CLElBQUksT0FBTyxJQUFJLENBQUMsUUFBUSxLQUFLLFdBQVcsSUFBSSxJQUFJLENBQUMsUUFBUTtZQUFFLE9BQU87UUFFbEUsSUFBSSxPQUFPLElBQUksQ0FBQyxhQUFhLEtBQUssV0FBVyxJQUFJLElBQUksQ0FBQyxhQUFhLEtBQUssSUFBSSxFQUFFO1lBQzFFLElBQUksQ0FBQyxhQUFhLENBQUMsUUFBUSxHQUFHLEtBQUssQ0FBQztTQUN2QztRQUVELElBQUksSUFBSSxDQUFDLE9BQU8sS0FBSyxRQUFRLElBQUksSUFBSSxDQUFDLFFBQVEsS0FBSyxLQUFLLEVBQUU7WUFDdEQsSUFBSSxDQUFDLE9BQU8sQ0FBQyxhQUFhLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxDQUFDO1NBQy9DO1FBRUQsSUFBSSxDQUFDLFFBQVEsR0FBRyxJQUFJLENBQUM7UUFDckIsSUFBSSxDQUFDLGFBQWEsR0FBRyxJQUFJLENBQUM7UUFDMUIsSUFBSSxDQUFDLFdBQVcsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLGFBQWEsQ0FBQyxLQUFLLENBQUMsQ0FBQztRQUNoRCxJQUFJLENBQUMsWUFBWSxFQUFFLENBQUM7SUFDeEIsQ0FBQztJQUVNLE1BQU0sQ0FBQyxTQUFpQjtRQUMzQixJQUFJLE9BQU8sR0FBVyxHQUFHLENBQUM7UUFDMUIsSUFBSSxDQUFDLEtBQUssR0FBRyxDQUFDLFNBQVMsS0FBSyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLEtBQUssR0FBRyxPQUFPLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxLQUFLLEdBQUcsT0FBTyxDQUFDO1FBQ25GLElBQUksQ0FBQyxRQUFRLEVBQUUsQ0FBQztJQUNwQixDQUFDO0lBRU8sV0FBVztRQUNmLElBQUksQ0FBQyxRQUFRLEdBQUcsQ0FBQyxDQUFDO1FBQ2xCLElBQUksTUFBTSxHQUF1QixJQUFJLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxhQUFhLENBQUMsZ0JBQWdCLENBQUMsR0FBRyxHQUFHLElBQUksQ0FBQyxHQUFHLEdBQUcsWUFBWSxDQUFDLENBQUM7UUFDakgsdUJBQXVCO1FBQ3ZCLDZCQUE2QjtRQUM3QixJQUFJLE9BQU8sTUFBTSxLQUFLLFdBQVcsSUFBSSxNQUFNLENBQUMsTUFBTSxHQUFHLENBQUMsRUFBRTtZQUNwRCxJQUFJLElBQUksQ0FBQyxVQUFVLEtBQUssTUFBTSxFQUFFO2dCQUM1QixJQUFJLENBQUMsU0FBUyxHQUFHLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxxQkFBcUIsRUFBRSxDQUFDLElBQUksR0FBRyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMscUJBQXFCLEVBQUUsQ0FBQyxLQUFLLENBQUM7YUFDckc7aUJBQ0k7Z0JBQ0QsSUFBSSxDQUFDLFNBQVMsR0FBRyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMscUJBQXFCLEVBQUUsQ0FBQyxJQUFJLEdBQUcsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLHFCQUFxQixFQUFFLENBQUMsS0FBSyxDQUFDO2FBQ3JHO1NBQ0o7UUFFRCxJQUFJLE9BQU8sSUFBSSxDQUFDLE9BQU8sS0FBSyxXQUFXLEVBQUU7WUFDckMsS0FBSyxJQUFJLENBQUMsR0FBVyxDQUFDLEVBQUUsQ0FBQyxHQUFHLE1BQU0sQ0FBQyxNQUFNLEVBQUUsQ0FBQyxFQUFFLEVBQUU7Z0JBQzVDLElBQUksT0FBTyxJQUFJLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxLQUFLLFdBQVc7b0JBQUUsU0FBUztnQkFFckQsSUFBSSxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMscUJBQXFCLEVBQUUsQ0FBQyxLQUFLLENBQUMsQ0FBQztnQkFFNUUsSUFBSSxDQUFDLEtBQUssQ0FBQyxFQUFFO29CQUNULElBQUksQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxHQUFHLElBQUksQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLEdBQUcsSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDO2lCQUM5RTtnQkFDRCxJQUFJLENBQUMsUUFBUSxJQUFJLElBQUksQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDO2FBQzFDO1NBQ0o7SUFFTCxDQUFDO0lBRU8sZ0JBQWdCO1FBQ3BCLElBQUksV0FBVyxHQUFXLElBQUksQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLGFBQWEsQ0FBQyxhQUFhLENBQUMscUJBQXFCLEVBQUUsQ0FBQyxLQUFLLENBQUM7UUFDdEcsSUFBSSxTQUFTLEdBQWdCLElBQUksQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLGFBQWEsQ0FBQyxhQUFhLENBQUMsR0FBRyxHQUFHLElBQUksQ0FBQyxHQUFHLEdBQUcsWUFBWSxDQUFDLENBQUM7UUFDMUcsSUFBSSxDQUFDLFVBQVUsR0FBRyxDQUFDLElBQUksQ0FBQyxRQUFRLEdBQUcsV0FBVyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDO1FBQy9ELElBQUksQ0FBQyxVQUFVLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsUUFBUSxDQUFDLFNBQVMsRUFBRSxZQUFZLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxXQUFXLENBQUMsU0FBUyxFQUFFLFlBQVksQ0FBQyxDQUFDO1FBRXpILEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FBQyxTQUFTLENBQUMsR0FBUyxFQUFFO1lBQzVCLElBQUksU0FBUyxDQUFDLFdBQVcsR0FBRyxJQUFJLENBQUMsUUFBUSxFQUFFO2dCQUN2QyxJQUFJLElBQUksQ0FBQyxVQUFVLEtBQUssTUFBTSxFQUFFO29CQUM1QixJQUFJLENBQUMsUUFBUSxHQUFHLFNBQVMsQ0FBQyxXQUFXLEdBQUcsSUFBSSxDQUFDLFFBQVEsQ0FBQztpQkFDekQ7cUJBQ0k7b0JBQ0QsSUFBSSxDQUFDLFFBQVEsR0FBRyxJQUFJLENBQUMsUUFBUSxHQUFHLFNBQVMsQ0FBQyxXQUFXLENBQUM7aUJBQ3pEO2FBQ0o7WUFFRCxJQUFJLENBQUMsSUFBSSxDQUFDLFVBQVUsRUFBRTtnQkFDbEIsSUFBSSxDQUFDLEtBQUssR0FBRyxDQUFDLENBQUM7Z0JBQ2YsSUFBSSxDQUFDLFFBQVEsRUFBRSxDQUFDO2FBQ25CO2lCQUNJO2dCQUNELElBQUksQ0FBQyxZQUFZLEVBQUUsQ0FBQzthQUN2QjtRQUNMLENBQUMsQ0FBQyxDQUFDO0lBQ1AsQ0FBQztJQUVPLFlBQVk7UUFDaEIsSUFBSSxXQUFXLEdBQVcsSUFBSSxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsYUFBYSxDQUFDLGFBQWEsQ0FBQyxHQUFHLEdBQUcsSUFBSSxDQUFDLEdBQUcsR0FBRyxZQUFZLENBQUMsQ0FBQyxXQUFXLEdBQUcsSUFBSSxDQUFDLGNBQWMsQ0FBQztRQUN6SSxJQUFJLE1BQU0sR0FBRyxXQUFXLEdBQUcsQ0FBQyxDQUFDO1FBQzdCLElBQUksS0FBSyxHQUFHLENBQUMsQ0FBQztRQUVkLElBQUksSUFBSSxDQUFDLFVBQVUsRUFBRTtZQUNqQixvQ0FBb0M7WUFDcEMsS0FBSyxJQUFJLENBQUMsR0FBVyxDQUFDLEVBQUUsQ0FBQyxHQUFHLElBQUksQ0FBQyxPQUFPLENBQUMsTUFBTSxFQUFFLENBQUMsRUFBRSxFQUFFO2dCQUNsRCxJQUFJLElBQUksQ0FBQyxhQUFhLEtBQUssSUFBSSxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsRUFBRTtvQkFDeEMsS0FBSyxJQUFJLElBQUksQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDO2lCQUNsQztxQkFDSTtvQkFDRCxLQUFLLElBQUksQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssR0FBRyxDQUFDLENBQUMsQ0FBQztvQkFFckMsSUFBSSxJQUFJLENBQUMsVUFBVSxLQUFLLE1BQU0sRUFBRTt3QkFDNUIsSUFBSSxDQUFDLEtBQUssR0FBRyxNQUFNLEdBQUcsS0FBSyxDQUFDO3FCQUMvQjt5QkFDSTt3QkFDRCxJQUFJLENBQUMsS0FBSyxHQUFHLEtBQUssR0FBRyxNQUFNLENBQUM7cUJBQy9CO29CQUNELE1BQU07aUJBQ1Q7YUFDSjtZQUNELElBQUk7WUFFSixTQUFTO1lBQ1QsbUVBQW1FO1lBQ25FLHdEQUF3RDtZQUN4RCw4Q0FBOEM7WUFDOUMsWUFBWTtZQUNaLGlCQUFpQjtZQUNqQixvREFBb0Q7WUFDcEQsMkNBQTJDO1lBQzNDLHFCQUFxQjtZQUNyQixZQUFZO1lBQ1osUUFBUTtZQUNSLElBQUk7U0FDUDthQUNJO1lBQ0QsSUFBSSxDQUFDLEtBQUssR0FBRyxDQUFDLENBQUM7U0FDbEI7UUFDRCxJQUFJLENBQUMsUUFBUSxFQUFFLENBQUM7SUFDcEIsQ0FBQztJQUVPLFFBQVE7UUFDWixJQUFJLElBQUksR0FBdUIsSUFBSSxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsYUFBYSxDQUFDLGdCQUFnQixDQUFDLEdBQUcsR0FBRyxJQUFJLENBQUMsR0FBRyxHQUFHLFlBQVksQ0FBQyxDQUFDO1FBRS9HLElBQUksSUFBSSxDQUFDLFVBQVUsS0FBSyxNQUFNLEVBQUU7WUFDNUIsSUFBSSxJQUFJLENBQUMsS0FBSyxHQUFHLElBQUksQ0FBQyxRQUFRLEVBQUU7Z0JBQzVCLElBQUksQ0FBQyxLQUFLLEdBQUcsSUFBSSxDQUFDLFFBQVEsQ0FBQzthQUU5QjtpQkFDSSxJQUFJLElBQUksQ0FBQyxLQUFLLElBQUksQ0FBQyxFQUFFO2dCQUN0QixJQUFJLENBQUMsS0FBSyxHQUFHLENBQUMsQ0FBQzthQUNsQjtZQUVELElBQUksQ0FBQyxZQUFZLEdBQUcsQ0FBQyxJQUFJLENBQUMsS0FBSyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQztZQUN0RCxJQUFJLENBQUMsYUFBYSxHQUFHLENBQUMsSUFBSSxDQUFDLEtBQUssS0FBSyxJQUFJLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDO1NBQ3RFO2FBQ0k7WUFDRCxJQUFJLElBQUksQ0FBQyxLQUFLLEdBQUcsQ0FBQyxFQUFFO2dCQUNoQixJQUFJLENBQUMsS0FBSyxHQUFHLENBQUMsQ0FBQzthQUNsQjtpQkFDSSxJQUFJLElBQUksQ0FBQyxLQUFLLEdBQUcsSUFBSSxDQUFDLFFBQVEsRUFBRTtnQkFDakMsSUFBSSxDQUFDLEtBQUssR0FBRyxJQUFJLENBQUMsUUFBUSxDQUFDO2FBQzlCO1lBRUQsSUFBSSxDQUFDLFlBQVksR0FBRyxDQUFDLElBQUksQ0FBQyxLQUFLLEtBQUssSUFBSSxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQztZQUNsRSxJQUFJLENBQUMsYUFBYSxHQUFHLENBQUMsSUFBSSxDQUFDLEtBQUssS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUM7U0FDMUQ7UUFHRCxJQUFJLElBQUksR0FBRyxJQUFJLENBQUMsS0FBSyxHQUFHLElBQUksQ0FBQztRQUU3QixLQUFLLElBQUksQ0FBQyxHQUFXLENBQUMsRUFBRSxDQUFDLEdBQUcsSUFBSSxDQUFDLE1BQU0sRUFBRSxDQUFDLEVBQUUsRUFBRTtZQUMxQyxJQUFJLENBQUMsU0FBUyxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLEVBQUUsTUFBTSxFQUFFLElBQUksQ0FBQyxDQUFDO1NBQ2xEO0lBQ0wsQ0FBQzs7O1lBelRKLFNBQVMsU0FBQztnQkFDUCxRQUFRLEVBQUUsU0FBUztnQkFDZixRQUFRLEVBQUU7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztLQTJCYjtnQkFDRCxhQUFhLEVBQUUsaUJBQWlCLENBQUMsSUFBSTtnQkFDckMsU0FBUyxFQUFFLENBQUMsU0FBUyxFQUFFLFlBQVksQ0FBQztnQkFDcEMsSUFBSSxFQUFFO29CQUNGLE9BQU8sRUFBRSxVQUFVO2lCQUN0Qjt5QkFFUTs7Ozs7OztLQU9SO2FBQ0o7OztZQW5EcUcsZ0JBQWdCO1lBQW1DLFNBQVM7WUFBNUIsaUJBQWlCO1lBRzlJLFNBQVM7WUFEVCxNQUFNO1lBQUUsY0FBYztZQUV0QixZQUFZO1lBQ1osZUFBZTs7O3NCQWdFbkIsS0FBSzt5QkFDTCxLQUFLLFNBQUMsUUFBUTtzQkFDZCxLQUFLLFNBQUMsTUFBTTswQkFDWixNQUFNO3VCQVlOLFlBQVksU0FBQyxlQUFlLEVBQUUsQ0FBQyxRQUFRLENBQUMiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBDb21wb25lbnQsIElucHV0LCBPdXRwdXQsIEV2ZW50RW1pdHRlciwgVmlld0VuY2Fwc3VsYXRpb24sIE9uSW5pdCwgT25DaGFuZ2VzLCBBZnRlclZpZXdJbml0LCBWaWV3Q29udGFpbmVyUmVmLCBIb3N0TGlzdGVuZXIsIENoYW5nZURldGVjdG9yUmVmLCBSZW5kZXJlcjIgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcclxuaW1wb3J0IHsgdGltZXIgfSBmcm9tICdyeGpzJztcclxuaW1wb3J0IHsgUm91dGVyLCBBY3RpdmF0ZWRSb3V0ZSB9IGZyb20gJ0Bhbmd1bGFyL3JvdXRlcic7XHJcbmltcG9ydCB7IEtkVGFic1N2YyB9IGZyb20gJy4va2QtYW5ndWxhci10YWJzLXN2Yyc7XHJcbmltcG9ydCB7IEtkRG9tRWxlbVN2YyB9IGZyb20gJy4uL2tkLWNvbW1vbi9pbmRleCc7XHJcbmltcG9ydCB7IEtkU3BsaXR0ZXJFdmVudCB9IGZyb20gJy4uL2tkLWFuZ3VsYXItc3BsaXR0ZXIvaW5kZXgnO1xyXG5cclxuQENvbXBvbmVudCh7XHJcbiAgICBzZWxlY3RvcjogJ2tkLXRhYnMnLFxyXG4gICAgICAgIHRlbXBsYXRlOiBgXHJcbiAgICAgICAgPGRpdiBjbGFzcz0nbmF2LWJhcicgW2hpZGRlbl09JyFfaGFzQXJyYXknIFtpZF09J19pZCc+XHJcbiAgICAgICAgICAgIDxidXR0b24gKm5nSWY9J19zY3JvbGxCdG4nIChjbGljayk9J3Njcm9sbChcImxlZnRcIiknIGNsYXNzPSdzY3JvbGwtbGVmdCcgW2Rpc2FibGVkXT0nX2Rpc2FibGVMZWZ0Jz48PC9idXR0b24+XHJcbiAgICAgICAgICAgIDx1bCBjbGFzcz0nbmF2IG5hdi10YWJzJz5cclxuICAgICAgICAgICAgICAgIDxuZy10ZW1wbGF0ZSBuZ0ZvciBsZXQtaXRlbSBbbmdGb3JPZl09J19yZXN1bHQnPlxyXG4gICAgICAgICAgICAgICAgICAgIDxsaSBjbGFzcz0nbmF2LWl0ZW0nIHN0eWxlPSdsZWZ0OjBweCcgW25nQ2xhc3NdPSd7XCJ0YWItc2VsZWN0ZWRcIjogaXRlbS5pc0FjdGl2ZSwgXCJ0YWItZGlzYWJsZWRcIjogaXRlbS5kaXNhYmxlZH0nPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8YSAoY2xpY2spPSdzZWxlY3RUYWIoaXRlbSwgJGV2ZW50KScgY2xhc3M9J25hdi1saW5rJz57e2l0ZW0udGFiTmFtZX19PC9hPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8IS0tIDxhICpuZ0lmPSdpdGVtLnRhYlR5cGUgIT09IFwicm91dGVyXCInIChjbGljayk9J3NlbGVjdFRhYihpdGVtLCAkZXZlbnQpJyBjbGFzcz0nbmF2LWxpbmsnPnt7aXRlbS50YWJOYW1lfX08L2E+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxhICpuZ0lmPSdpdGVtLnRhYlR5cGUgPT09IFwicm91dGVyXCInIChjbGljayk9J3NlbGVjdFRhYihpdGVtLCAkZXZlbnQpJyBjbGFzcz0nbmF2LWxpbmsnIFtyb3V0ZXJMaW5rXT0naXRlbS5yb3V0ZXJQYXRoJz57e2l0ZW0udGFiTmFtZX19PC9hPiAtLT5cclxuICAgICAgICAgICAgICAgICAgICA8L2xpPlxyXG4gICAgICAgICAgICAgICAgPC9uZy10ZW1wbGF0ZT5cclxuICAgICAgICAgICAgPC91bD5cclxuICAgICAgICAgICAgPGJ1dHRvbiAqbmdJZj0nX3Njcm9sbEJ0bicgKGNsaWNrKT0nc2Nyb2xsKFwicmlnaHRcIiknIGNsYXNzPSdzY3JvbGwtcmlnaHQnIFtkaXNhYmxlZF09J19kaXNhYmxlUmlnaHQnPj48L2J1dHRvbj5cclxuICAgICAgICAgICAgPGRpdiBjbGFzcz0ndGFiLWRpdmlkZXInPjwvZGl2PlxyXG4gICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgPG5nLXRlbXBsYXRlIFtuZ0lmXT0nX3ByZXZpb3VzSXRlbSAmJiBfcHJldmlvdXNJdGVtLnRhYlR5cGUgPT09IFwiY29udGVudFwiJz5cclxuICAgICAgICAgICAgPGRpdiBjbGFzcz0ndGFiLWNvbnRlbnQnPlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzcz0ndGFiLXBhbmUnIFtuZ0NsYXNzXT0ne1wiYWN0aXZlXCI6IF9wcmV2aW91c0l0ZW0uaXNBY3RpdmV9Jz57e19wcmV2aW91c0l0ZW0udGFiQ29udGVudH19PC9kaXY+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDwvbmctdGVtcGxhdGU+XHJcblxyXG4gICAgICAgIDxuZy10ZW1wbGF0ZSBbbmdJZl09J3RhYlR5cGUgPT09IFwicm91dGVyXCIgfHwgdGFiVHlwZSA9PT0gXCJodG1sXCInPlxyXG4gICAgICAgICAgICA8bmctY29udGVudD48L25nLWNvbnRlbnQ+XHJcbiAgICAgICAgPC9uZy10ZW1wbGF0ZT5cclxuXHJcbiAgICAgICAgPGRpdiBjbGFzcz0ndGFiLWJvdHRvbS1kaXZpZGVyJz48L2Rpdj5cclxuICAgIGAsXHJcbiAgICBlbmNhcHN1bGF0aW9uOiBWaWV3RW5jYXBzdWxhdGlvbi5Ob25lLFxyXG4gICAgcHJvdmlkZXJzOiBbS2RUYWJzU3ZjLCBLZERvbUVsZW1TdmNdLFxyXG4gICAgaG9zdDoge1xyXG4gICAgICAgICdjbGFzcyc6ICdrZHgtdGFicycsXHJcbiAgICB9LFxyXG4gICAgLy8gVGVtcCBzY2hvb2wgb3ZlcndyaXRlcyBmb3Igc3R5bGluZyBmb3IgZGlzYWJsZWQgYXR0cmlidXRlIGZvciBPcGVuRU1JUyBTY2hvb2wgb25seSAtIFRvIHByb3BlciB1cGRhdGVzIHN0eWxlIGNsYXNzZXMgaW4gc3R5bGVndWlkZSB0byBoYXZlIHRoZSBkaXNhYmxlZCBjbGFzcyBzdHlsaW5nXHJcbiAgICBzdHlsZXM6IFtgXHJcbiAgICAgICAgLmFuZ3VsYXItdGFicyAubmF2LXRhYnMgLm5hdi1pdGVtLnRhYi1kaXNhYmxlZCA+IGEubmF2LWxpbms6aG92ZXIge1xyXG4gICAgICAgICAgICBjb2xvcjogIzMzMyAhaW1wb3J0YW50O1xyXG4gICAgICAgICAgICBib3JkZXI6IDFweCBzb2xpZCAjREREICFpbXBvcnRhbnQ7XHJcbiAgICAgICAgICAgIGN1cnNvcjogbm90LWFsbG93ZWQgIWltcG9ydGFudDtcclxuICAgICAgICAgICAgYmFja2dyb3VuZC1jb2xvcjogdHJhbnNwYXJlbnQgIWltcG9ydGFudDtcclxuICAgICAgICB9XHJcbiAgICBgXVxyXG59KVxyXG5cclxuZXhwb3J0IGNsYXNzIEtkVGFicyBpbXBsZW1lbnRzIE9uSW5pdCwgT25DaGFuZ2VzLCBBZnRlclZpZXdJbml0IHtcclxuICAgIHB1YmxpYyBfaWQ6IHN0cmluZztcclxuICAgIHB1YmxpYyBfcmVzdWx0OiBBcnJheTxhbnk+ID0gW107XHJcbiAgICBwdWJsaWMgX2hhc0FycmF5OiBib29sZWFuID0gZmFsc2U7XHJcbiAgICBwdWJsaWMgX3Njcm9sbEJ0bjogYm9vbGVhbiA9IGZhbHNlO1xyXG4gICAgcHVibGljIF9wcmV2aW91c0l0ZW06IGFueTtcclxuICAgIHB1YmxpYyBfZGlzYWJsZUxlZnQ6IGJvb2xlYW4gPSBmYWxzZTtcclxuICAgIHB1YmxpYyBfZGlzYWJsZVJpZ2h0OiBib29sZWFuID0gZmFsc2U7XHJcblxyXG4gICAgcHJpdmF0ZSBfbGVmdDogbnVtYmVyID0gMDtcclxuICAgIHByaXZhdGUgX21heExlZnQ6IG51bWJlciA9IDA7XHJcbiAgICBwcml2YXRlIF91bFdpZHRoOiBudW1iZXIgPSAwO1xyXG4gICAgcHJpdmF0ZSBfdWxNYXJnaW46IG51bWJlciA9IDA7XHJcbiAgICBwcml2YXRlIF9kaXJlY3Rpb246IGFueTtcclxuICAgIHByaXZhdGUgX3BhcmVudFBhZGRpbmc6IG51bWJlciA9IDMwO1xyXG5cclxuICAgIEBJbnB1dCgpIGlucHV0SWQ6IHN0cmluZztcclxuICAgIEBJbnB1dCgnY29uZmlnJykgdGFic0NvbmZpZzogYW55O1xyXG4gICAgQElucHV0KCd0eXBlJykgdGFiVHlwZTogc3RyaW5nO1xyXG4gICAgQE91dHB1dCgpIGFjdGl2ZVN0YXRlOiBFdmVudEVtaXR0ZXI8e30+ID0gbmV3IEV2ZW50RW1pdHRlcigpO1xyXG5cclxuICAgIGNvbnN0cnVjdG9yKFxyXG4gICAgICAgIHByaXZhdGUgX3ZjcjogVmlld0NvbnRhaW5lclJlZixcclxuICAgICAgICBwcml2YXRlIF9yZW5kZXJlcjogUmVuZGVyZXIyLFxyXG4gICAgICAgIHByaXZhdGUgX2NkOiBDaGFuZ2VEZXRlY3RvclJlZixcclxuICAgICAgICBwcml2YXRlIF90YWJTdmM6IEtkVGFic1N2YyxcclxuICAgICAgICBwcml2YXRlIF9yb3V0ZXI6IFJvdXRlcixcclxuICAgICAgICBfYWN0aXZlUm91dGU6IEFjdGl2YXRlZFJvdXRlLFxyXG4gICAgICAgIHByaXZhdGUgX2RvbUVsZTogS2REb21FbGVtU3ZjLFxyXG4gICAgICAgIHByaXZhdGUgX3NwbGl0dGVyRXZlbnQ6IEtkU3BsaXR0ZXJFdmVudCkgeyB9XHJcblxyXG4gICAgQEhvc3RMaXN0ZW5lcignd2luZG93OnJlc2l6ZScsIFsnJGV2ZW50J10pXHJcbiAgICBvblJlc2l6ZShldmVudDogYW55KTogdm9pZCB7XHJcbiAgICAgICAgdGhpcy5fY2hlY2tXaWR0aCgpO1xyXG4gICAgICAgIHRoaXMuX2NoZWNrU2Nyb2xsYWJsZSgpO1xyXG4gICAgfVxyXG5cclxuICAgIG5nT25Jbml0KCk6IHZvaWQge1xyXG4gICAgICAgIHRoaXMuX2lkID0gKHR5cGVvZiB0aGlzLmlucHV0SWQgIT09ICd1bmRlZmluZWQnKSA/IHRoaXMuaW5wdXRJZCA6ICd0YWJzJztcclxuICAgICAgICB0aGlzLl9yZXN1bHQgPSB0aGlzLl90YWJTdmMuc2V0UmVzdWx0KHRoaXMudGFic0NvbmZpZywgdGhpcy50YWJUeXBlKTtcclxuXHJcbiAgICAgICAgdGhpcy5faGFzQXJyYXkgPSB0aGlzLl90YWJTdmMuY2hlY2tIYXNBcnJheSh0aGlzLl9yZXN1bHQpO1xyXG5cclxuICAgICAgICBpZiAodHlwZW9mIHRoaXMuX3Jlc3VsdCAhPT0gJ3VuZGVmaW5lZCcpIHtcclxuICAgICAgICAgICAgZm9yIChsZXQgaTogbnVtYmVyID0gMDsgaSA8IHRoaXMuX3Jlc3VsdC5sZW5ndGg7IGkrKykge1xyXG4gICAgICAgICAgICAgICAgaWYgKHRoaXMuX3Jlc3VsdFtpXS5pc0FjdGl2ZSA9PT0gdHJ1ZSkge1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuX3ByZXZpb3VzSXRlbSA9IHRoaXMuX3Jlc3VsdFtpXTtcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLmFjdGl2ZVN0YXRlLmVtaXQodGhpcy5fcHJldmlvdXNJdGVtLnRhYklkKTtcclxuXHJcbiAgICAgICAgICAgICAgICAgICAgLy8gaWYgKHRoaXMuX3ByZXZpb3VzSXRlbS50YWJUeXBlID09PSAncm91dGVyJykge1xyXG4gICAgICAgICAgICAgICAgICAgIC8vICAgICB0aGlzLl9yb3V0ZXIubmF2aWdhdGUoWycuLycgKyB0aGlzLl9wcmV2aW91c0l0ZW0ucm91dGVyUGF0aF0sIHsgcmVsYXRpdmVUbzogdGhpcy5fcm91dGUgfSk7XHJcbiAgICAgICAgICAgICAgICAgICAgLy8gfVxyXG4gICAgICAgICAgICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICB0aGlzLl9zcGxpdHRlckV2ZW50Lm9uRHJhZygpXHJcbiAgICAgICAgICAgIC5zdWJzY3JpYmUoX3R5cGUgPT4ge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5fY2hlY2tXaWR0aCgpO1xyXG4gICAgICAgICAgICAgICAgdGhpcy5fY2hlY2tTY3JvbGxhYmxlKCk7XHJcbiAgICAgICAgICAgIH0pO1xyXG5cclxuICAgICAgICB0aGlzLl9zcGxpdHRlckV2ZW50Lm9uVG9nZ2xlTWVudSgpXHJcbiAgICAgICAgICAgIC5zdWJzY3JpYmUoX3R5cGUgPT4ge1xyXG4gICAgICAgICAgICAgICAgdGltZXIoNTAwKS5zdWJzY3JpYmUoKCk6IHZvaWQgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuX2NoZWNrV2lkdGgoKTtcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLl9jaGVja1Njcm9sbGFibGUoKTtcclxuICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICB9KTtcclxuICAgIH1cclxuXHJcbiAgICBuZ09uQ2hhbmdlcygpOiB2b2lkIHtcclxuICAgICAgICB0aGlzLl9yZXN1bHQgPSB0aGlzLl90YWJTdmMuc2V0UmVzdWx0KHRoaXMudGFic0NvbmZpZywgdGhpcy50YWJUeXBlKTtcclxuICAgICAgICB0aGlzLl9oYXNBcnJheSA9IHRoaXMuX3RhYlN2Yy5jaGVja0hhc0FycmF5KHRoaXMuX3Jlc3VsdCk7XHJcblxyXG4gICAgICAgIGlmICh0eXBlb2YgdGhpcy5fcmVzdWx0ICE9PSAndW5kZWZpbmVkJykge1xyXG4gICAgICAgICAgICBmb3IgKGxldCBpOiBudW1iZXIgPSAwOyBpIDwgdGhpcy5fcmVzdWx0Lmxlbmd0aDsgaSsrKSB7XHJcbiAgICAgICAgICAgICAgICBpZiAodGhpcy5fcmVzdWx0W2ldLmlzQWN0aXZlID09PSB0cnVlKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5fcHJldmlvdXNJdGVtID0gdGhpcy5fcmVzdWx0W2ldO1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuYWN0aXZlU3RhdGUuZW1pdCh0aGlzLl9wcmV2aW91c0l0ZW0udGFiSWQpO1xyXG5cclxuICAgICAgICAgICAgICAgICAgICBpZiAodGhpcy5fcHJldmlvdXNJdGVtLnRhYlR5cGUgPT09ICdyb3V0ZXInKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC8vIGNvbnNvbGUubG9nKCdLZC1hbmd1bGFyLXRhYiAtIE5lZWQgdG8gcmVsb29rIHRoaXMgc2VjdGlvbicsIHRoaXMuX3ByZXZpb3VzSXRlbS5yb3V0ZXJQYXRoLCB0aGlzLl9yb3V0ZSApO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAvLyB0aGlzLl9yb3V0ZXIubmF2aWdhdGUoWycuLycgKyB0aGlzLl9wcmV2aW91c0l0ZW0ucm91dGVyUGF0aF0sIHsgcmVsYXRpdmVUbzogdGhpcy5fcm91dGUgfSk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC8qIENoYW5nZSB0aGUgbmF2aWdhdGlvbiBvbiBmaXJzdCBsb2FkIHRvIHVzZSBmdWxsIHJvdXRlciBwYXRoIHRvIG1hdGNoIGFsbCB0aGUgcGF0aCAqL1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLl9yb3V0ZXIubmF2aWdhdGVCeVVybCh0aGlzLl9wcmV2aW91c0l0ZW0ucm91dGVyUGF0aCk7XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICB0aW1lcig1MCkuc3Vic2NyaWJlKCgpOiB2b2lkID0+IHtcclxuICAgICAgICAgICAgdGhpcy5fY2hlY2tXaWR0aCgpO1xyXG4gICAgICAgICAgICB0aGlzLl9jaGVja1Njcm9sbGFibGUoKTtcclxuICAgICAgICB9KTtcclxuXHJcbiAgICB9XHJcblxyXG4gICAgbmdBZnRlclZpZXdJbml0KCk6IHZvaWQge1xyXG4gICAgICAgIC8vIHRoaXMuX2RpcmVjdGlvbiA9IHRoaXMuX3RhYlN2Yy5jaGVja0RpcmVjdGlvbigpO1xyXG4gICAgICAgIHRoaXMuX2RpcmVjdGlvbiA9IHRoaXMuX2RvbUVsZS5nZXREb2N1bWVudERpcmVjdGlvbih0cnVlKTtcclxuICAgICAgICB0aGlzLl9jaGVja1dpZHRoKCk7XHJcblxyXG4gICAgICAgIHRoaXMuX2NkLmRldGFjaCgpO1xyXG4gICAgICAgIHRoaXMuX2NoZWNrU2Nyb2xsYWJsZSgpO1xyXG4gICAgICAgIHRoaXMuX2NkLmRldGVjdENoYW5nZXMoKTtcclxuICAgICAgICB0aGlzLl9jZC5yZWF0dGFjaCgpO1xyXG4gICAgfVxyXG5cclxuICAgIHB1YmxpYyBzZWxlY3RUYWIoaXRlbTogYW55LCBlOiBFdmVudCk6IHZvaWQge1xyXG4gICAgICAgIGUucHJldmVudERlZmF1bHQoKTtcclxuICAgICAgICBpZiAodHlwZW9mIGl0ZW0uZGlzYWJsZWQgIT09ICd1bmRlZmluZWQnICYmIGl0ZW0uZGlzYWJsZWQpIHJldHVybjtcclxuXHJcbiAgICAgICAgaWYgKHR5cGVvZiB0aGlzLl9wcmV2aW91c0l0ZW0gIT09ICd1bmRlZmluZWQnICYmIHRoaXMuX3ByZXZpb3VzSXRlbSAhPT0gaXRlbSkge1xyXG4gICAgICAgICAgICB0aGlzLl9wcmV2aW91c0l0ZW0uaXNBY3RpdmUgPSBmYWxzZTtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIGlmIChpdGVtLnRhYlR5cGUgPT09ICdyb3V0ZXInICYmIGl0ZW0uaXNBY3RpdmUgPT09IGZhbHNlKSB7XHJcbiAgICAgICAgICAgIHRoaXMuX3JvdXRlci5uYXZpZ2F0ZUJ5VXJsKGl0ZW0ucm91dGVyUGF0aCk7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICBpdGVtLmlzQWN0aXZlID0gdHJ1ZTtcclxuICAgICAgICB0aGlzLl9wcmV2aW91c0l0ZW0gPSBpdGVtO1xyXG4gICAgICAgIHRoaXMuYWN0aXZlU3RhdGUuZW1pdCh0aGlzLl9wcmV2aW91c0l0ZW0udGFiSWQpO1xyXG4gICAgICAgIHRoaXMuX3NldFNlbGVjdGVkKCk7XHJcbiAgICB9XHJcblxyXG4gICAgcHVibGljIHNjcm9sbChkaXJlY3Rpb246IHN0cmluZyk6IHZvaWQge1xyXG4gICAgICAgIGxldCBvZmZzZXRYOiBudW1iZXIgPSAyMDA7XHJcbiAgICAgICAgdGhpcy5fbGVmdCA9IChkaXJlY3Rpb24gPT09ICdyaWdodCcpID8gdGhpcy5fbGVmdCAtIG9mZnNldFggOiB0aGlzLl9sZWZ0ICsgb2Zmc2V0WDtcclxuICAgICAgICB0aGlzLl9zZXRMZWZ0KCk7XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfY2hlY2tXaWR0aCgpOiB2b2lkIHtcclxuICAgICAgICB0aGlzLl91bFdpZHRoID0gMDtcclxuICAgICAgICBsZXQgdWxMaXN0OiBBcnJheTxIVE1MRWxlbWVudD4gPSB0aGlzLl92Y3IuZWxlbWVudC5uYXRpdmVFbGVtZW50LnF1ZXJ5U2VsZWN0b3JBbGwoJyMnICsgdGhpcy5faWQgKyAnIC5uYXYtaXRlbScpO1xyXG4gICAgICAgIC8vIGNvbnNvbGUubG9nKHVsTGlzdCk7XHJcbiAgICAgICAgLy8gY29uc29sZS5sb2codGhpcy5fcmVzdWx0KTtcclxuICAgICAgICBpZiAodHlwZW9mIHVsTGlzdCAhPT0gJ3VuZGVmaW5lZCcgJiYgdWxMaXN0Lmxlbmd0aCA+IDEpIHtcclxuICAgICAgICAgICAgaWYgKHRoaXMuX2RpcmVjdGlvbiA9PT0gJ2xlZnQnKSB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLl91bE1hcmdpbiA9IHVsTGlzdFsxXS5nZXRCb3VuZGluZ0NsaWVudFJlY3QoKS5sZWZ0IC0gdWxMaXN0WzBdLmdldEJvdW5kaW5nQ2xpZW50UmVjdCgpLnJpZ2h0O1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5fdWxNYXJnaW4gPSB1bExpc3RbMF0uZ2V0Qm91bmRpbmdDbGllbnRSZWN0KCkubGVmdCAtIHVsTGlzdFsxXS5nZXRCb3VuZGluZ0NsaWVudFJlY3QoKS5yaWdodDtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgaWYgKHR5cGVvZiB0aGlzLl9yZXN1bHQgIT09ICd1bmRlZmluZWQnKSB7XHJcbiAgICAgICAgICAgIGZvciAobGV0IGk6IG51bWJlciA9IDA7IGkgPCB1bExpc3QubGVuZ3RoOyBpKyspIHtcclxuICAgICAgICAgICAgICAgIGlmICh0eXBlb2YgdGhpcy5fcmVzdWx0W2ldID09PSAndW5kZWZpbmVkJykgY29udGludWU7XHJcblxyXG4gICAgICAgICAgICAgICAgdGhpcy5fcmVzdWx0W2ldLndpZHRoID0gTWF0aC5yb3VuZCh1bExpc3RbaV0uZ2V0Qm91bmRpbmdDbGllbnRSZWN0KCkud2lkdGgpO1xyXG5cclxuICAgICAgICAgICAgICAgIGlmIChpICE9PSAwKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5fcmVzdWx0W2ldLndpZHRoID0gTWF0aC5yb3VuZCh0aGlzLl9yZXN1bHRbaV0ud2lkdGggKyB0aGlzLl91bE1hcmdpbik7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICB0aGlzLl91bFdpZHRoICs9IHRoaXMuX3Jlc3VsdFtpXS53aWR0aDtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuXHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfY2hlY2tTY3JvbGxhYmxlKCk6IHZvaWQge1xyXG4gICAgICAgIGxldCBwYXJlbnRXaWR0aDogbnVtYmVyID0gdGhpcy5fdmNyLmVsZW1lbnQubmF0aXZlRWxlbWVudC5wYXJlbnRFbGVtZW50LmdldEJvdW5kaW5nQ2xpZW50UmVjdCgpLndpZHRoO1xyXG4gICAgICAgIGxldCB1bEVsZW1lbnQ6IEhUTUxFbGVtZW50ID0gdGhpcy5fdmNyLmVsZW1lbnQubmF0aXZlRWxlbWVudC5xdWVyeVNlbGVjdG9yKCcjJyArIHRoaXMuX2lkICsgJyAubmF2LXRhYnMnKTtcclxuICAgICAgICB0aGlzLl9zY3JvbGxCdG4gPSAodGhpcy5fdWxXaWR0aCA+IHBhcmVudFdpZHRoKSA/IHRydWUgOiBmYWxzZTtcclxuICAgICAgICB0aGlzLl9zY3JvbGxCdG4gPyB0aGlzLl9yZW5kZXJlci5hZGRDbGFzcyh1bEVsZW1lbnQsICdzY3JvbGxhYmxlJykgOiB0aGlzLl9yZW5kZXJlci5yZW1vdmVDbGFzcyh1bEVsZW1lbnQsICdzY3JvbGxhYmxlJyk7XHJcblxyXG4gICAgICAgIHRpbWVyKDEwMCkuc3Vic2NyaWJlKCgpOiB2b2lkID0+IHtcclxuICAgICAgICAgICAgaWYgKHVsRWxlbWVudC5jbGllbnRXaWR0aCA8IHRoaXMuX3VsV2lkdGgpIHtcclxuICAgICAgICAgICAgICAgIGlmICh0aGlzLl9kaXJlY3Rpb24gPT09ICdsZWZ0Jykge1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuX21heExlZnQgPSB1bEVsZW1lbnQuY2xpZW50V2lkdGggLSB0aGlzLl91bFdpZHRoO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgZWxzZSB7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5fbWF4TGVmdCA9IHRoaXMuX3VsV2lkdGggLSB1bEVsZW1lbnQuY2xpZW50V2lkdGg7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgIGlmICghdGhpcy5fc2Nyb2xsQnRuKSB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLl9sZWZ0ID0gMDtcclxuICAgICAgICAgICAgICAgIHRoaXMuX3NldExlZnQoKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgICAgIHRoaXMuX3NldFNlbGVjdGVkKCk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9KTtcclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF9zZXRTZWxlY3RlZCgpOiB2b2lkIHtcclxuICAgICAgICBsZXQgcGFyZW50V2lkdGg6IG51bWJlciA9IHRoaXMuX3Zjci5lbGVtZW50Lm5hdGl2ZUVsZW1lbnQucXVlcnlTZWxlY3RvcignIycgKyB0aGlzLl9pZCArICcgLm5hdi10YWJzJykuY2xpZW50V2lkdGggLSB0aGlzLl9wYXJlbnRQYWRkaW5nO1xyXG4gICAgICAgIGxldCBtaWRkbGUgPSBwYXJlbnRXaWR0aCAvIDI7XHJcbiAgICAgICAgbGV0IHdpZHRoID0gMDtcclxuXHJcbiAgICAgICAgaWYgKHRoaXMuX3Njcm9sbEJ0bikge1xyXG4gICAgICAgICAgICAvLyBpZiAodGhpcy5fZGlyZWN0aW9uID09PSAnbGVmdCcpIHtcclxuICAgICAgICAgICAgZm9yIChsZXQgaTogbnVtYmVyID0gMDsgaSA8IHRoaXMuX3Jlc3VsdC5sZW5ndGg7IGkrKykge1xyXG4gICAgICAgICAgICAgICAgaWYgKHRoaXMuX3ByZXZpb3VzSXRlbSAhPT0gdGhpcy5fcmVzdWx0W2ldKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgd2lkdGggKz0gdGhpcy5fcmVzdWx0W2ldLndpZHRoO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgZWxzZSB7XHJcbiAgICAgICAgICAgICAgICAgICAgd2lkdGggKz0gKHRoaXMuX3Jlc3VsdFtpXS53aWR0aCAvIDIpO1xyXG5cclxuICAgICAgICAgICAgICAgICAgICBpZiAodGhpcy5fZGlyZWN0aW9uID09PSAnbGVmdCcpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5fbGVmdCA9IG1pZGRsZSAtIHdpZHRoO1xyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5fbGVmdCA9IHdpZHRoIC0gbWlkZGxlO1xyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICBicmVhaztcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAvLyB9XHJcblxyXG4gICAgICAgICAgICAvLyBlbHNlIHtcclxuICAgICAgICAgICAgLy8gICAgIGZvciAobGV0IGk6IG51bWJlciA9IHRoaXMuX3Jlc3VsdC5sZW5ndGggLSAxOyBpID49IDA7IGktLSkge1xyXG4gICAgICAgICAgICAvLyAgICAgICAgIGlmICh0aGlzLl9wcmV2aW91c0l0ZW0gIT09IHRoaXMuX3Jlc3VsdFtpXSkge1xyXG4gICAgICAgICAgICAvLyAgICAgICAgICAgICB3aWR0aCArPSB0aGlzLl9yZXN1bHRbaV0ud2lkdGg7XHJcbiAgICAgICAgICAgIC8vICAgICAgICAgfVxyXG4gICAgICAgICAgICAvLyAgICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICAvLyAgICAgICAgICAgICB3aWR0aCArPSAodGhpcy5fcmVzdWx0W2ldLndpZHRoIC8gMik7XHJcbiAgICAgICAgICAgIC8vICAgICAgICAgICAgIHRoaXMuX2xlZnQgPSB3aWR0aCAtIG1pZGRsZTtcclxuICAgICAgICAgICAgLy8gICAgICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgICAgIC8vICAgICAgICAgfVxyXG4gICAgICAgICAgICAvLyAgICAgfVxyXG4gICAgICAgICAgICAvLyB9XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICB0aGlzLl9sZWZ0ID0gMDtcclxuICAgICAgICB9XHJcbiAgICAgICAgdGhpcy5fc2V0TGVmdCgpO1xyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX3NldExlZnQoKTogdm9pZCB7XHJcbiAgICAgICAgbGV0IGl0ZW06IEFycmF5PEhUTUxFbGVtZW50PiA9IHRoaXMuX3Zjci5lbGVtZW50Lm5hdGl2ZUVsZW1lbnQucXVlcnlTZWxlY3RvckFsbCgnIycgKyB0aGlzLl9pZCArICcgLm5hdi1pdGVtJyk7XHJcblxyXG4gICAgICAgIGlmICh0aGlzLl9kaXJlY3Rpb24gPT09ICdsZWZ0Jykge1xyXG4gICAgICAgICAgICBpZiAodGhpcy5fbGVmdCA8IHRoaXMuX21heExlZnQpIHtcclxuICAgICAgICAgICAgICAgIHRoaXMuX2xlZnQgPSB0aGlzLl9tYXhMZWZ0O1xyXG5cclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBlbHNlIGlmICh0aGlzLl9sZWZ0ID49IDApIHtcclxuICAgICAgICAgICAgICAgIHRoaXMuX2xlZnQgPSAwO1xyXG4gICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICB0aGlzLl9kaXNhYmxlTGVmdCA9ICh0aGlzLl9sZWZ0ID09PSAwKSA/IHRydWUgOiBmYWxzZTtcclxuICAgICAgICAgICAgdGhpcy5fZGlzYWJsZVJpZ2h0ID0gKHRoaXMuX2xlZnQgPT09IHRoaXMuX21heExlZnQpID8gdHJ1ZSA6IGZhbHNlO1xyXG4gICAgICAgIH1cclxuICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgaWYgKHRoaXMuX2xlZnQgPCAwKSB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLl9sZWZ0ID0gMDtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBlbHNlIGlmICh0aGlzLl9sZWZ0ID4gdGhpcy5fbWF4TGVmdCkge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5fbGVmdCA9IHRoaXMuX21heExlZnQ7XHJcbiAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgIHRoaXMuX2Rpc2FibGVMZWZ0ID0gKHRoaXMuX2xlZnQgPT09IHRoaXMuX21heExlZnQpID8gdHJ1ZSA6IGZhbHNlO1xyXG4gICAgICAgICAgICB0aGlzLl9kaXNhYmxlUmlnaHQgPSAodGhpcy5fbGVmdCA9PT0gMCkgPyB0cnVlIDogZmFsc2U7XHJcbiAgICAgICAgfVxyXG5cclxuXHJcbiAgICAgICAgbGV0IG1vdmUgPSB0aGlzLl9sZWZ0ICsgJ3B4JztcclxuXHJcbiAgICAgICAgZm9yIChsZXQgaTogbnVtYmVyID0gMDsgaSA8IGl0ZW0ubGVuZ3RoOyBpKyspIHtcclxuICAgICAgICAgICAgdGhpcy5fcmVuZGVyZXIuc2V0U3R5bGUoaXRlbVtpXSwgJ2xlZnQnLCBtb3ZlKTtcclxuICAgICAgICB9XHJcbiAgICB9XHJcbn1cclxuIl19