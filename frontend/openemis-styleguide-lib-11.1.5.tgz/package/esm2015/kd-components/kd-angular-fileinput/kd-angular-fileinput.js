import { Component, Input, Output, EventEmitter, ViewContainerRef } from '@angular/core';
export class KdFileInput {
    constructor(_vcr) {
        this._vcr = _vcr;
        this._fileResult = {
            src: '',
            filename: '',
            extension: '',
            data: ''
        };
        this.result = new EventEmitter();
    }
    ngOnInit() {
        this._setFileType();
        this._setLeftBtn();
        this._checkInitFile();
    }
    handleFileSelect(event) {
        let files = event.target.files;
        let file = files[0];
        if (typeof this.config.fileName === 'undefined' || this.config.fileName === '') {
            this.config.fileName = file.name;
        }
        // if (files && file) {
        if (typeof files !== 'undefined' && typeof file !== 'undefined') {
            let reader = new FileReader();
            reader.onload = () => {
                let dataUrl = reader.result;
                // console.log('dataUrl - ', dataUrl);
                let findExtension = file.name.split('.');
                this._fileResult = {
                    src: dataUrl,
                    data: file,
                    filename: file.name,
                    extension: findExtension[findExtension.length - 1]
                };
                this.result.emit(this._fileResult.data);
            };
            reader.readAsDataURL(file);
        }
    }
    // public handleFileSelect(event: any): void {
    //     let files = event.target.files;
    //     let file = files[0];
    //     if (typeof this.config.fileName === 'undefined' || this.config.fileName === '') {
    //         this.config.fileName = file.name;
    //     }
    //     // if (files && file) {
    //     if (typeof files !== 'undefined' && typeof file !== 'undefined') {
    //         let reader = new FileReader();
    //         reader.onload = (): void => {
    //             // check the file type in format --> data:image/png;base64,
    //             // this._dataUri = 'data:' + file.type + ';base64,';
    //             let binaryString: string = reader.result;
    //             this._fileResult = this._getResult(binaryString, file);
    //             this.result.emit(this._fileResult);
    //         }
    //         reader.readAsBinaryString(file);
    //     }
    // }
    removeFile(_event) {
        _event.preventDefault();
        let fileinput = this._vcr.element.nativeElement.querySelector('#filePicker');
        fileinput.value = '';
        this._fileResult = {
            data: '',
            extension: '',
            filename: '',
            src: ''
        };
        // this._fileResult.data = '';
        // this._fileResult.extension = '';
        // this._fileResult.filename = '';
        // this._fileResult.src = '';
        this.result.emit(this._fileResult);
    }
    buttonCallback(_event, _button) {
        _event.preventDefault();
        if (typeof _button.callback === 'function') {
            _button.callback(_event, _button);
        }
    }
    _checkInitFile() {
        if (typeof this.value !== 'undefined') {
            this._fileResult.data = this.value.data;
            this._fileResult.extension = this.value.extension;
            this._fileResult.filename = this.value.filename;
            this._fileResult.src = this.value.src;
        }
    }
    // private _getResult(binaryString: string, file: any): IFileResult {
    //     let dataUri: string = 'data:' + file.type + ';base64,';
    //     let base64String: string = btoa(binaryString);
    //     let findExtension: Array<string> = file.name.split('.');
    //     // let newResult: IFileResult =
    //     // newResult.data = base64String;
    //     // newResult.src = dataUri + base64String;
    //     // newResult.filename = file.name;
    //     // newResult.extension = findExtension[findExtension.length - 1];
    //     return {
    //         data: base64String,
    //         src: dataUri + base64String,
    //         filename: file.name,
    //         extension: findExtension[findExtension.length - 1],
    //     };
    // }
    _setFileType() {
        if (typeof this.config !== 'undefined' && typeof this.config.fileType === 'undefined') {
            this.config['fileType'] = 'file_extension, media_type';
        }
        else if (this.config.fileType === 'image') {
            this.config.fileType = 'image/*';
        }
        else if (this.config.fileType === 'media') {
            this.config.fileType = 'audio/*, video/*';
        }
        else if (this.config.fileType === 'text') {
            this.config.fileType = '.csv, .pdf, .xl, .xla, .xlb, .xlc, .xld, .xlk, .xll, .xlm, .xls, .xlt, .xlv, .xlw, .doc, .dot';
        }
    }
    _setLeftBtn() {
        if (typeof this.config.leftButton !== 'undefined' && this.config.leftToolbar === true) {
            if (this.config.leftButton.length === 1) {
                this._leftButton = 'input-single-btn';
            }
            else {
                this._leftButton = 'input-double-btn';
            }
        }
    }
}
KdFileInput.decorators = [
    { type: Component, args: [{
                selector: 'kd-fileinput',
                template: "<div class=\"kdx-fileinput-wrapper\">\r\n    <div class=\"kdx-file-preview\" *ngIf=\"config.preview\">\r\n        <kd-placeholder [config]='config.imageConfig' [value]='_fileResult'></kd-placeholder>\r\n    </div>\r\n\r\n    <label class=\"kdx-wrapper\">\r\n        <input type=\"file\" class=\"hidden\" id=\"filePicker\" accept=\"{{config.fileType}}\" (change)=\"handleFileSelect($event)\">\r\n        <ng-content></ng-content>\r\n        <div class=\"btn btn-icon btn-browse\" placement=\"bottom\" ngbTooltip=\"Browse\">\r\n            <i class=\"fa fa-folder\"></i>\r\n        </div>\r\n        <div *ngIf=\"config.leftToolbar\" class=\"{{_leftButton}}\">\r\n            <button *ngFor=\"let button of config.leftButton | slice:0:2;\" class=\"btn btn-icon\" placement=\"bottom\" ngbTooltip=\"{{button.label}}\" (click)=\"buttonCallback($event, button)\" type=\"button\">\r\n                <i class=\"fa {{button.icon}}\"></i>\r\n            </button>\r\n        </div>\r\n         <div *ngIf=\"_fileResult.filename\" class=\"kdx-input-text\">\r\n            <i class=\"fa fa-file-o\"></i>\r\n            <p>{{_fileResult.filename}}</p>\r\n        </div>\r\n        <button *ngIf=\"_fileResult.filename\" class=\"btn btn-remove\" (click)=\"removeFile($event)\" placement=\"bottom\" ngbTooltip=\"Remove\" type=\"button\">\r\n            <i class=\"kd-close-round\"></i>\r\n        </button>\r\n    </label>\r\n        \r\n    <div *ngIf=\"config.infoText\" class=\"kdx-fileinput-text\">\r\n    \t<div *ngFor=\"let list of config.infoText | slice:0:3;\">* {{list.text}}</div>\r\n    </div>\r\n</div>"
            },] }
];
KdFileInput.ctorParameters = () => [
    { type: ViewContainerRef }
];
KdFileInput.propDecorators = {
    config: [{ type: Input }],
    value: [{ type: Input }],
    result: [{ type: Output }]
};
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoia2QtYW5ndWxhci1maWxlaW5wdXQuanMiLCJzb3VyY2VSb290IjoiQzoveGFtcHAvaHRkb2NzL1N0eWxlZ3VpZGUvaW9zdGctb3BlbmVtaXMtc3R5bGVndWlkZS9wcm9qZWN0cy9vcGVuZW1pcy1zdHlsZWd1aWRlLWxpYi9zcmMvIiwic291cmNlcyI6WyJrZC1jb21wb25lbnRzL2tkLWFuZ3VsYXItZmlsZWlucHV0L2tkLWFuZ3VsYXItZmlsZWlucHV0LnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBLE9BQU8sRUFDSCxTQUFTLEVBRVQsS0FBSyxFQUNMLE1BQU0sRUFDTixZQUFZLEVBQ1osZ0JBQWdCLEVBQ25CLE1BQU0sZUFBZSxDQUFDO0FBU3ZCLE1BQU0sT0FBTyxXQUFXO0lBY3BCLFlBQ1ksSUFBc0I7UUFBdEIsU0FBSSxHQUFKLElBQUksQ0FBa0I7UUFiM0IsZ0JBQVcsR0FBZ0I7WUFDOUIsR0FBRyxFQUFFLEVBQUU7WUFDUCxRQUFRLEVBQUUsRUFBRTtZQUNaLFNBQVMsRUFBRSxFQUFFO1lBQ2IsSUFBSSxFQUFFLEVBQUU7U0FDWCxDQUFDO1FBS1EsV0FBTSxHQUFHLElBQUksWUFBWSxFQUFFLENBQUM7SUFJbEMsQ0FBQztJQUVMLFFBQVE7UUFDSixJQUFJLENBQUMsWUFBWSxFQUFFLENBQUM7UUFDcEIsSUFBSSxDQUFDLFdBQVcsRUFBRSxDQUFDO1FBQ25CLElBQUksQ0FBQyxjQUFjLEVBQUUsQ0FBQztJQUMxQixDQUFDO0lBRU0sZ0JBQWdCLENBQUMsS0FBVTtRQUM5QixJQUFJLEtBQUssR0FBYSxLQUFLLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQztRQUN6QyxJQUFJLElBQUksR0FBUyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUM7UUFFMUIsSUFBSSxPQUFPLElBQUksQ0FBQyxNQUFNLENBQUMsUUFBUSxLQUFLLFdBQVcsSUFBSSxJQUFJLENBQUMsTUFBTSxDQUFDLFFBQVEsS0FBSyxFQUFFLEVBQUU7WUFDNUUsSUFBSSxDQUFDLE1BQU0sQ0FBQyxRQUFRLEdBQUcsSUFBSSxDQUFDLElBQUksQ0FBQztTQUNwQztRQUVELHVCQUF1QjtRQUN2QixJQUFJLE9BQU8sS0FBSyxLQUFLLFdBQVcsSUFBSSxPQUFPLElBQUksS0FBSyxXQUFXLEVBQUU7WUFDN0QsSUFBSSxNQUFNLEdBQWUsSUFBSSxVQUFVLEVBQUUsQ0FBQztZQUUxQyxNQUFNLENBQUMsTUFBTSxHQUFHLEdBQUcsRUFBRTtnQkFDakIsSUFBSSxPQUFPLEdBQVcsTUFBTSxDQUFDLE1BQWdCLENBQUM7Z0JBQzlDLHNDQUFzQztnQkFDdEMsSUFBSSxhQUFhLEdBQWtCLElBQUksQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDO2dCQUN4RCxJQUFJLENBQUMsV0FBVyxHQUFHO29CQUNmLEdBQUcsRUFBRSxPQUFPO29CQUNaLElBQUksRUFBRSxJQUFJO29CQUNWLFFBQVEsRUFBRSxJQUFJLENBQUMsSUFBSTtvQkFDbkIsU0FBUyxFQUFFLGFBQWEsQ0FBQyxhQUFhLENBQUMsTUFBTSxHQUFHLENBQUMsQ0FBQztpQkFDckQsQ0FBQztnQkFDRixJQUFJLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFDLElBQUksQ0FBQyxDQUFDO1lBQzVDLENBQUMsQ0FBQztZQUVGLE1BQU0sQ0FBQyxhQUFhLENBQUMsSUFBSSxDQUFDLENBQUM7U0FDOUI7SUFDTCxDQUFDO0lBRUQsOENBQThDO0lBQzlDLHNDQUFzQztJQUN0QywyQkFBMkI7SUFFM0Isd0ZBQXdGO0lBQ3hGLDRDQUE0QztJQUM1QyxRQUFRO0lBRVIsOEJBQThCO0lBQzlCLHlFQUF5RTtJQUN6RSx5Q0FBeUM7SUFFekMsd0NBQXdDO0lBQ3hDLDBFQUEwRTtJQUMxRSxtRUFBbUU7SUFFbkUsd0RBQXdEO0lBQ3hELHNFQUFzRTtJQUN0RSxrREFBa0Q7SUFDbEQsWUFBWTtJQUVaLDJDQUEyQztJQUMzQyxRQUFRO0lBQ1IsSUFBSTtJQUVHLFVBQVUsQ0FBQyxNQUFhO1FBQzNCLE1BQU0sQ0FBQyxjQUFjLEVBQUUsQ0FBQztRQUV4QixJQUFJLFNBQVMsR0FBRyxJQUFJLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxhQUFhLENBQUMsYUFBYSxDQUFDLGFBQWEsQ0FBQyxDQUFDO1FBQzdFLFNBQVMsQ0FBQyxLQUFLLEdBQUcsRUFBRSxDQUFDO1FBRXJCLElBQUksQ0FBQyxXQUFXLEdBQUc7WUFDZixJQUFJLEVBQUUsRUFBRTtZQUNSLFNBQVMsRUFBRSxFQUFFO1lBQ2IsUUFBUSxFQUFFLEVBQUU7WUFDWixHQUFHLEVBQUUsRUFBRTtTQUNWLENBQUM7UUFFRiw4QkFBOEI7UUFDOUIsbUNBQW1DO1FBQ25DLGtDQUFrQztRQUNsQyw2QkFBNkI7UUFDN0IsSUFBSSxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxDQUFDO0lBQ3ZDLENBQUM7SUFFTSxjQUFjLENBQUMsTUFBYSxFQUFFLE9BQVk7UUFDN0MsTUFBTSxDQUFDLGNBQWMsRUFBRSxDQUFDO1FBQ3hCLElBQUksT0FBTyxPQUFPLENBQUMsUUFBUSxLQUFLLFVBQVUsRUFBRTtZQUN4QyxPQUFPLENBQUMsUUFBUSxDQUFDLE1BQU0sRUFBRSxPQUFPLENBQUMsQ0FBQztTQUNyQztJQUNMLENBQUM7SUFFTyxjQUFjO1FBQ2xCLElBQUksT0FBTyxJQUFJLENBQUMsS0FBSyxLQUFLLFdBQVcsRUFBRTtZQUNuQyxJQUFJLENBQUMsV0FBVyxDQUFDLElBQUksR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQztZQUN4QyxJQUFJLENBQUMsV0FBVyxDQUFDLFNBQVMsR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDLFNBQVMsQ0FBQztZQUNsRCxJQUFJLENBQUMsV0FBVyxDQUFDLFFBQVEsR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDLFFBQVEsQ0FBQztZQUNoRCxJQUFJLENBQUMsV0FBVyxDQUFDLEdBQUcsR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQztTQUN6QztJQUNMLENBQUM7SUFFRCxxRUFBcUU7SUFDckUsOERBQThEO0lBQzlELHFEQUFxRDtJQUNyRCwrREFBK0Q7SUFFL0Qsc0NBQXNDO0lBRXRDLHdDQUF3QztJQUN4QyxpREFBaUQ7SUFDakQseUNBQXlDO0lBQ3pDLHdFQUF3RTtJQUN4RSxlQUFlO0lBQ2YsOEJBQThCO0lBQzlCLHVDQUF1QztJQUN2QywrQkFBK0I7SUFDL0IsOERBQThEO0lBQzlELFNBQVM7SUFDVCxJQUFJO0lBRUksWUFBWTtRQUNoQixJQUFJLE9BQU8sSUFBSSxDQUFDLE1BQU0sS0FBSyxXQUFXLElBQUksT0FBTyxJQUFJLENBQUMsTUFBTSxDQUFDLFFBQVEsS0FBSyxXQUFXLEVBQUU7WUFDbkYsSUFBSSxDQUFDLE1BQU0sQ0FBQyxVQUFVLENBQUMsR0FBRyw0QkFBNEIsQ0FBQztTQUMxRDthQUNJLElBQUksSUFBSSxDQUFDLE1BQU0sQ0FBQyxRQUFRLEtBQUssT0FBTyxFQUFFO1lBQ3ZDLElBQUksQ0FBQyxNQUFNLENBQUMsUUFBUSxHQUFHLFNBQVMsQ0FBQztTQUNwQzthQUNJLElBQUksSUFBSSxDQUFDLE1BQU0sQ0FBQyxRQUFRLEtBQUssT0FBTyxFQUFFO1lBQ3ZDLElBQUksQ0FBQyxNQUFNLENBQUMsUUFBUSxHQUFHLGtCQUFrQixDQUFDO1NBQzdDO2FBQ0ksSUFBSSxJQUFJLENBQUMsTUFBTSxDQUFDLFFBQVEsS0FBSyxNQUFNLEVBQUU7WUFDdEMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxRQUFRLEdBQUcsK0ZBQStGLENBQUM7U0FDMUg7SUFDTCxDQUFDO0lBRU8sV0FBVztRQUNmLElBQUksT0FBTyxJQUFJLENBQUMsTUFBTSxDQUFDLFVBQVUsS0FBSyxXQUFXLElBQUksSUFBSSxDQUFDLE1BQU0sQ0FBQyxXQUFXLEtBQUssSUFBSSxFQUFFO1lBQ25GLElBQUksSUFBSSxDQUFDLE1BQU0sQ0FBQyxVQUFVLENBQUMsTUFBTSxLQUFLLENBQUMsRUFBRTtnQkFDckMsSUFBSSxDQUFDLFdBQVcsR0FBRyxrQkFBa0IsQ0FBQzthQUN6QztpQkFDSTtnQkFDRCxJQUFJLENBQUMsV0FBVyxHQUFHLGtCQUFrQixDQUFDO2FBQ3pDO1NBQ0o7SUFDTCxDQUFDOzs7WUFsS0osU0FBUyxTQUFDO2dCQUNQLFFBQVEsRUFBRSxjQUFjO2dCQUN4Qiw0a0RBQTBDO2FBQzdDOzs7WUFSRyxnQkFBZ0I7OztxQkFvQmYsS0FBSztvQkFDTCxLQUFLO3FCQUNMLE1BQU0iLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQge1xyXG4gICAgQ29tcG9uZW50LFxyXG4gICAgT25Jbml0LFxyXG4gICAgSW5wdXQsXHJcbiAgICBPdXRwdXQsXHJcbiAgICBFdmVudEVtaXR0ZXIsXHJcbiAgICBWaWV3Q29udGFpbmVyUmVmXHJcbn0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XHJcblxyXG5pbXBvcnQgeyBJRmlsZVJlc3VsdCB9IGZyb20gJy4va2QtZmlsZWlucHV0LWludGVyZmFjZSc7XHJcblxyXG5AQ29tcG9uZW50KHtcclxuICAgIHNlbGVjdG9yOiAna2QtZmlsZWlucHV0JyxcclxuICAgIHRlbXBsYXRlVXJsOiAnLi9rZC1hbmd1bGFyLWZpbGVpbnB1dC5odG1sJ1xyXG59KVxyXG5cclxuZXhwb3J0IGNsYXNzIEtkRmlsZUlucHV0IGltcGxlbWVudHMgT25Jbml0IHtcclxuICAgIHB1YmxpYyBfbGVmdEJ1dHRvbjogc3RyaW5nO1xyXG4gICAgcHVibGljIF9maWxlUmVzdWx0OiBJRmlsZVJlc3VsdCA9IHtcclxuICAgICAgICBzcmM6ICcnLFxyXG4gICAgICAgIGZpbGVuYW1lOiAnJyxcclxuICAgICAgICBleHRlbnNpb246ICcnLFxyXG4gICAgICAgIGRhdGE6ICcnXHJcbiAgICB9O1xyXG5cclxuXHJcbiAgICBASW5wdXQoKSBjb25maWc6IGFueTtcclxuICAgIEBJbnB1dCgpIHZhbHVlOiBhbnk7XHJcbiAgICBAT3V0cHV0KCkgcmVzdWx0ID0gbmV3IEV2ZW50RW1pdHRlcigpO1xyXG5cclxuICAgIGNvbnN0cnVjdG9yKFxyXG4gICAgICAgIHByaXZhdGUgX3ZjcjogVmlld0NvbnRhaW5lclJlZlxyXG4gICAgKSB7IH1cclxuXHJcbiAgICBuZ09uSW5pdCgpOiB2b2lkIHtcclxuICAgICAgICB0aGlzLl9zZXRGaWxlVHlwZSgpO1xyXG4gICAgICAgIHRoaXMuX3NldExlZnRCdG4oKTtcclxuICAgICAgICB0aGlzLl9jaGVja0luaXRGaWxlKCk7XHJcbiAgICB9XHJcblxyXG4gICAgcHVibGljIGhhbmRsZUZpbGVTZWxlY3QoZXZlbnQ6IGFueSk6IHZvaWQge1xyXG4gICAgICAgIGxldCBmaWxlczogRmlsZUxpc3QgPSBldmVudC50YXJnZXQuZmlsZXM7XHJcbiAgICAgICAgbGV0IGZpbGU6IEZpbGUgPSBmaWxlc1swXTtcclxuXHJcbiAgICAgICAgaWYgKHR5cGVvZiB0aGlzLmNvbmZpZy5maWxlTmFtZSA9PT0gJ3VuZGVmaW5lZCcgfHwgdGhpcy5jb25maWcuZmlsZU5hbWUgPT09ICcnKSB7XHJcbiAgICAgICAgICAgIHRoaXMuY29uZmlnLmZpbGVOYW1lID0gZmlsZS5uYW1lO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgLy8gaWYgKGZpbGVzICYmIGZpbGUpIHtcclxuICAgICAgICBpZiAodHlwZW9mIGZpbGVzICE9PSAndW5kZWZpbmVkJyAmJiB0eXBlb2YgZmlsZSAhPT0gJ3VuZGVmaW5lZCcpIHtcclxuICAgICAgICAgICAgbGV0IHJlYWRlcjogRmlsZVJlYWRlciA9IG5ldyBGaWxlUmVhZGVyKCk7XHJcblxyXG4gICAgICAgICAgICByZWFkZXIub25sb2FkID0gKCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgbGV0IGRhdGFVcmw6IHN0cmluZyA9IHJlYWRlci5yZXN1bHQgYXMgc3RyaW5nO1xyXG4gICAgICAgICAgICAgICAgLy8gY29uc29sZS5sb2coJ2RhdGFVcmwgLSAnLCBkYXRhVXJsKTtcclxuICAgICAgICAgICAgICAgIGxldCBmaW5kRXh0ZW5zaW9uOiBBcnJheTxzdHJpbmc+ID0gZmlsZS5uYW1lLnNwbGl0KCcuJyk7XHJcbiAgICAgICAgICAgICAgICB0aGlzLl9maWxlUmVzdWx0ID0ge1xyXG4gICAgICAgICAgICAgICAgICAgIHNyYzogZGF0YVVybCxcclxuICAgICAgICAgICAgICAgICAgICBkYXRhOiBmaWxlLFxyXG4gICAgICAgICAgICAgICAgICAgIGZpbGVuYW1lOiBmaWxlLm5hbWUsXHJcbiAgICAgICAgICAgICAgICAgICAgZXh0ZW5zaW9uOiBmaW5kRXh0ZW5zaW9uW2ZpbmRFeHRlbnNpb24ubGVuZ3RoIC0gMV1cclxuICAgICAgICAgICAgICAgIH07XHJcbiAgICAgICAgICAgICAgICB0aGlzLnJlc3VsdC5lbWl0KHRoaXMuX2ZpbGVSZXN1bHQuZGF0YSk7XHJcbiAgICAgICAgICAgIH07XHJcblxyXG4gICAgICAgICAgICByZWFkZXIucmVhZEFzRGF0YVVSTChmaWxlKTtcclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgLy8gcHVibGljIGhhbmRsZUZpbGVTZWxlY3QoZXZlbnQ6IGFueSk6IHZvaWQge1xyXG4gICAgLy8gICAgIGxldCBmaWxlcyA9IGV2ZW50LnRhcmdldC5maWxlcztcclxuICAgIC8vICAgICBsZXQgZmlsZSA9IGZpbGVzWzBdO1xyXG5cclxuICAgIC8vICAgICBpZiAodHlwZW9mIHRoaXMuY29uZmlnLmZpbGVOYW1lID09PSAndW5kZWZpbmVkJyB8fCB0aGlzLmNvbmZpZy5maWxlTmFtZSA9PT0gJycpIHtcclxuICAgIC8vICAgICAgICAgdGhpcy5jb25maWcuZmlsZU5hbWUgPSBmaWxlLm5hbWU7XHJcbiAgICAvLyAgICAgfVxyXG5cclxuICAgIC8vICAgICAvLyBpZiAoZmlsZXMgJiYgZmlsZSkge1xyXG4gICAgLy8gICAgIGlmICh0eXBlb2YgZmlsZXMgIT09ICd1bmRlZmluZWQnICYmIHR5cGVvZiBmaWxlICE9PSAndW5kZWZpbmVkJykge1xyXG4gICAgLy8gICAgICAgICBsZXQgcmVhZGVyID0gbmV3IEZpbGVSZWFkZXIoKTtcclxuXHJcbiAgICAvLyAgICAgICAgIHJlYWRlci5vbmxvYWQgPSAoKTogdm9pZCA9PiB7XHJcbiAgICAvLyAgICAgICAgICAgICAvLyBjaGVjayB0aGUgZmlsZSB0eXBlIGluIGZvcm1hdCAtLT4gZGF0YTppbWFnZS9wbmc7YmFzZTY0LFxyXG4gICAgLy8gICAgICAgICAgICAgLy8gdGhpcy5fZGF0YVVyaSA9ICdkYXRhOicgKyBmaWxlLnR5cGUgKyAnO2Jhc2U2NCwnO1xyXG5cclxuICAgIC8vICAgICAgICAgICAgIGxldCBiaW5hcnlTdHJpbmc6IHN0cmluZyA9IHJlYWRlci5yZXN1bHQ7XHJcbiAgICAvLyAgICAgICAgICAgICB0aGlzLl9maWxlUmVzdWx0ID0gdGhpcy5fZ2V0UmVzdWx0KGJpbmFyeVN0cmluZywgZmlsZSk7XHJcbiAgICAvLyAgICAgICAgICAgICB0aGlzLnJlc3VsdC5lbWl0KHRoaXMuX2ZpbGVSZXN1bHQpO1xyXG4gICAgLy8gICAgICAgICB9XHJcblxyXG4gICAgLy8gICAgICAgICByZWFkZXIucmVhZEFzQmluYXJ5U3RyaW5nKGZpbGUpO1xyXG4gICAgLy8gICAgIH1cclxuICAgIC8vIH1cclxuXHJcbiAgICBwdWJsaWMgcmVtb3ZlRmlsZShfZXZlbnQ6IEV2ZW50KTogdm9pZCB7XHJcbiAgICAgICAgX2V2ZW50LnByZXZlbnREZWZhdWx0KCk7XHJcblxyXG4gICAgICAgIGxldCBmaWxlaW5wdXQgPSB0aGlzLl92Y3IuZWxlbWVudC5uYXRpdmVFbGVtZW50LnF1ZXJ5U2VsZWN0b3IoJyNmaWxlUGlja2VyJyk7XHJcbiAgICAgICAgZmlsZWlucHV0LnZhbHVlID0gJyc7XHJcblxyXG4gICAgICAgIHRoaXMuX2ZpbGVSZXN1bHQgPSB7XHJcbiAgICAgICAgICAgIGRhdGE6ICcnLFxyXG4gICAgICAgICAgICBleHRlbnNpb246ICcnLFxyXG4gICAgICAgICAgICBmaWxlbmFtZTogJycsXHJcbiAgICAgICAgICAgIHNyYzogJydcclxuICAgICAgICB9O1xyXG5cclxuICAgICAgICAvLyB0aGlzLl9maWxlUmVzdWx0LmRhdGEgPSAnJztcclxuICAgICAgICAvLyB0aGlzLl9maWxlUmVzdWx0LmV4dGVuc2lvbiA9ICcnO1xyXG4gICAgICAgIC8vIHRoaXMuX2ZpbGVSZXN1bHQuZmlsZW5hbWUgPSAnJztcclxuICAgICAgICAvLyB0aGlzLl9maWxlUmVzdWx0LnNyYyA9ICcnO1xyXG4gICAgICAgIHRoaXMucmVzdWx0LmVtaXQodGhpcy5fZmlsZVJlc3VsdCk7XHJcbiAgICB9XHJcblxyXG4gICAgcHVibGljIGJ1dHRvbkNhbGxiYWNrKF9ldmVudDogRXZlbnQsIF9idXR0b246IGFueSk6IHZvaWQge1xyXG4gICAgICAgIF9ldmVudC5wcmV2ZW50RGVmYXVsdCgpO1xyXG4gICAgICAgIGlmICh0eXBlb2YgX2J1dHRvbi5jYWxsYmFjayA9PT0gJ2Z1bmN0aW9uJykge1xyXG4gICAgICAgICAgICBfYnV0dG9uLmNhbGxiYWNrKF9ldmVudCwgX2J1dHRvbik7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX2NoZWNrSW5pdEZpbGUoKTogdm9pZCB7XHJcbiAgICAgICAgaWYgKHR5cGVvZiB0aGlzLnZhbHVlICE9PSAndW5kZWZpbmVkJykge1xyXG4gICAgICAgICAgICB0aGlzLl9maWxlUmVzdWx0LmRhdGEgPSB0aGlzLnZhbHVlLmRhdGE7XHJcbiAgICAgICAgICAgIHRoaXMuX2ZpbGVSZXN1bHQuZXh0ZW5zaW9uID0gdGhpcy52YWx1ZS5leHRlbnNpb247XHJcbiAgICAgICAgICAgIHRoaXMuX2ZpbGVSZXN1bHQuZmlsZW5hbWUgPSB0aGlzLnZhbHVlLmZpbGVuYW1lO1xyXG4gICAgICAgICAgICB0aGlzLl9maWxlUmVzdWx0LnNyYyA9IHRoaXMudmFsdWUuc3JjO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICAvLyBwcml2YXRlIF9nZXRSZXN1bHQoYmluYXJ5U3RyaW5nOiBzdHJpbmcsIGZpbGU6IGFueSk6IElGaWxlUmVzdWx0IHtcclxuICAgIC8vICAgICBsZXQgZGF0YVVyaTogc3RyaW5nID0gJ2RhdGE6JyArIGZpbGUudHlwZSArICc7YmFzZTY0LCc7XHJcbiAgICAvLyAgICAgbGV0IGJhc2U2NFN0cmluZzogc3RyaW5nID0gYnRvYShiaW5hcnlTdHJpbmcpO1xyXG4gICAgLy8gICAgIGxldCBmaW5kRXh0ZW5zaW9uOiBBcnJheTxzdHJpbmc+ID0gZmlsZS5uYW1lLnNwbGl0KCcuJyk7XHJcblxyXG4gICAgLy8gICAgIC8vIGxldCBuZXdSZXN1bHQ6IElGaWxlUmVzdWx0ID1cclxuXHJcbiAgICAvLyAgICAgLy8gbmV3UmVzdWx0LmRhdGEgPSBiYXNlNjRTdHJpbmc7XHJcbiAgICAvLyAgICAgLy8gbmV3UmVzdWx0LnNyYyA9IGRhdGFVcmkgKyBiYXNlNjRTdHJpbmc7XHJcbiAgICAvLyAgICAgLy8gbmV3UmVzdWx0LmZpbGVuYW1lID0gZmlsZS5uYW1lO1xyXG4gICAgLy8gICAgIC8vIG5ld1Jlc3VsdC5leHRlbnNpb24gPSBmaW5kRXh0ZW5zaW9uW2ZpbmRFeHRlbnNpb24ubGVuZ3RoIC0gMV07XHJcbiAgICAvLyAgICAgcmV0dXJuIHtcclxuICAgIC8vICAgICAgICAgZGF0YTogYmFzZTY0U3RyaW5nLFxyXG4gICAgLy8gICAgICAgICBzcmM6IGRhdGFVcmkgKyBiYXNlNjRTdHJpbmcsXHJcbiAgICAvLyAgICAgICAgIGZpbGVuYW1lOiBmaWxlLm5hbWUsXHJcbiAgICAvLyAgICAgICAgIGV4dGVuc2lvbjogZmluZEV4dGVuc2lvbltmaW5kRXh0ZW5zaW9uLmxlbmd0aCAtIDFdLFxyXG4gICAgLy8gICAgIH07XHJcbiAgICAvLyB9XHJcblxyXG4gICAgcHJpdmF0ZSBfc2V0RmlsZVR5cGUoKSB7XHJcbiAgICAgICAgaWYgKHR5cGVvZiB0aGlzLmNvbmZpZyAhPT0gJ3VuZGVmaW5lZCcgJiYgdHlwZW9mIHRoaXMuY29uZmlnLmZpbGVUeXBlID09PSAndW5kZWZpbmVkJykge1xyXG4gICAgICAgICAgICB0aGlzLmNvbmZpZ1snZmlsZVR5cGUnXSA9ICdmaWxlX2V4dGVuc2lvbiwgbWVkaWFfdHlwZSc7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGVsc2UgaWYgKHRoaXMuY29uZmlnLmZpbGVUeXBlID09PSAnaW1hZ2UnKSB7XHJcbiAgICAgICAgICAgIHRoaXMuY29uZmlnLmZpbGVUeXBlID0gJ2ltYWdlLyonO1xyXG4gICAgICAgIH1cclxuICAgICAgICBlbHNlIGlmICh0aGlzLmNvbmZpZy5maWxlVHlwZSA9PT0gJ21lZGlhJykge1xyXG4gICAgICAgICAgICB0aGlzLmNvbmZpZy5maWxlVHlwZSA9ICdhdWRpby8qLCB2aWRlby8qJztcclxuICAgICAgICB9XHJcbiAgICAgICAgZWxzZSBpZiAodGhpcy5jb25maWcuZmlsZVR5cGUgPT09ICd0ZXh0Jykge1xyXG4gICAgICAgICAgICB0aGlzLmNvbmZpZy5maWxlVHlwZSA9ICcuY3N2LCAucGRmLCAueGwsIC54bGEsIC54bGIsIC54bGMsIC54bGQsIC54bGssIC54bGwsIC54bG0sIC54bHMsIC54bHQsIC54bHYsIC54bHcsIC5kb2MsIC5kb3QnO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF9zZXRMZWZ0QnRuKCkge1xyXG4gICAgICAgIGlmICh0eXBlb2YgdGhpcy5jb25maWcubGVmdEJ1dHRvbiAhPT0gJ3VuZGVmaW5lZCcgJiYgdGhpcy5jb25maWcubGVmdFRvb2xiYXIgPT09IHRydWUpIHtcclxuICAgICAgICAgICAgaWYgKHRoaXMuY29uZmlnLmxlZnRCdXR0b24ubGVuZ3RoID09PSAxKSB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLl9sZWZ0QnV0dG9uID0gJ2lucHV0LXNpbmdsZS1idG4nO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5fbGVmdEJ1dHRvbiA9ICdpbnB1dC1kb3VibGUtYnRuJztcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgIH1cclxufVxyXG4iXX0=