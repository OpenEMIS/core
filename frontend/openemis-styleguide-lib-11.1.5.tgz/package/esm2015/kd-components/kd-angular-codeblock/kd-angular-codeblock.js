import { Component, Input } from '@angular/core';
// import { Response } from '@angular/http';
import { HttpClient } from '@angular/common/http';
import { DomSanitizer } from '@angular/platform-browser';
export class KdCodeblock {
    // trustHTMLcode: SafeUrl;
    constructor(_sanitizer, _http) {
        this._sanitizer = _sanitizer;
        this._http = _http;
        this.Prism = require('prismjs');
        this.code = null;
    }
    ngOnInit() {
        // let tempStr = this.code;
        // let regex = new RegExp(this._getSpaces(tempStr), 'g');
        // // tempStr = tempStr.replace(/  +/g, '').trim();
        // tempStr = tempStr.replace(regex, '').trim();
        // tempStr = this.Prism.highlight(tempStr, this._getType(this.language));
        // this._sanitizer.bypassSecurityTrustHtml(tempStr);
        // this.code = tempStr;
        let tempStr;
        if (typeof this.path !== 'undefined') {
            try {
                this._httpSub = this._http.get(this.path)
                    // .pipe(
                    //     map((respond: Response): any => respond.text())
                    // )
                    .subscribe((data) => {
                    console.log('Codeblock', data);
                    tempStr = data.trim();
                    this._updateCodeblock(tempStr);
                }, (error) => { }, () => { });
            }
            catch (err) { }
        }
        else {
            tempStr = this.code;
            this._updateCodeblock(tempStr);
        }
    }
    _updateCodeblock(tempStr) {
        let regex = new RegExp(this._getSpaces(tempStr), 'g');
        tempStr = tempStr.replace(regex, '').trim();
        tempStr = this.Prism.highlight(tempStr, this._getType(this.language));
        this._sanitizer.bypassSecurityTrustHtml(tempStr);
        this._updatedCode = tempStr;
    }
    _getSpaces(_text) {
        let spacesArr = _text.match(/[^\S\n\t]+/g);
        let removeSpace = null;
        if (spacesArr !== null) {
            for (let i = 0; i < spacesArr.length; i++) {
                if (removeSpace === null && spacesArr[i].length > 1) {
                    removeSpace = spacesArr[i];
                }
                else if (spacesArr[i].length > 1 && removeSpace.length > spacesArr[i].length) {
                    removeSpace = spacesArr[i];
                }
            }
        }
        return removeSpace;
    }
    _getType(_type) {
        if (_type === 'javascript' || _type === 'js' || _type === 'typescript') {
            return this.Prism.languages.javascript;
        }
        else if (_type === 'html') {
            return this.Prism.languages.html;
        }
        else if (_type === 'css') {
            return this.Prism.languages.css;
        }
        else {
            return this.Prism.languages.markup;
        }
    }
}
KdCodeblock.decorators = [
    { type: Component, args: [{
                selector: 'kd-codeblock',
                template: `
            <pre class='language-javascript' style='font-size: 12px'><code class='language-javascript' [innerHtml]='_updatedCode'></code></pre>
    `
            },] }
];
KdCodeblock.ctorParameters = () => [
    { type: DomSanitizer },
    { type: HttpClient }
];
KdCodeblock.propDecorators = {
    code: [{ type: Input }],
    path: [{ type: Input }],
    language: [{ type: Input }]
};
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoia2QtYW5ndWxhci1jb2RlYmxvY2suanMiLCJzb3VyY2VSb290IjoiQzoveGFtcHAvaHRkb2NzL1N0eWxlZ3VpZGUvaW9zdGctb3BlbmVtaXMtc3R5bGVndWlkZS9wcm9qZWN0cy9vcGVuZW1pcy1zdHlsZWd1aWRlLWxpYi9zcmMvIiwic291cmNlcyI6WyJrZC1jb21wb25lbnRzL2tkLWFuZ3VsYXItY29kZWJsb2NrL2tkLWFuZ3VsYXItY29kZWJsb2NrLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBLE9BQU8sRUFDSCxTQUFTLEVBQ1QsS0FBSyxFQUVSLE1BQU0sZUFBZSxDQUFDO0FBQ3ZCLDRDQUE0QztBQUM1QyxPQUFPLEVBQUUsVUFBVSxFQUFDLE1BQU0sc0JBQXNCLENBQUM7QUFHakQsT0FBTyxFQUFFLFlBQVksRUFBRSxNQUFNLDJCQUEyQixDQUFDO0FBV3pELE1BQU0sT0FBTyxXQUFXO0lBU3BCLDBCQUEwQjtJQUMxQixZQUFvQixVQUF3QixFQUFVLEtBQWlCO1FBQW5ELGVBQVUsR0FBVixVQUFVLENBQWM7UUFBVSxVQUFLLEdBQUwsS0FBSyxDQUFZO1FBUi9ELFVBQUssR0FBRyxPQUFPLENBQUMsU0FBUyxDQUFDLENBQUM7UUFHMUIsU0FBSSxHQUFXLElBQUksQ0FBQztJQUs4QyxDQUFDO0lBRTVFLFFBQVE7UUFDSiwyQkFBMkI7UUFDM0IseURBQXlEO1FBQ3pELG1EQUFtRDtRQUNuRCwrQ0FBK0M7UUFDL0MseUVBQXlFO1FBQ3pFLG9EQUFvRDtRQUNwRCx1QkFBdUI7UUFFdkIsSUFBSSxPQUFlLENBQUM7UUFDcEIsSUFBSSxPQUFPLElBQUksQ0FBQyxJQUFJLEtBQUssV0FBVyxFQUFFO1lBQ2xDLElBQUk7Z0JBQ0EsSUFBSSxDQUFDLFFBQVEsR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDO29CQUNyQyxTQUFTO29CQUNULHNEQUFzRDtvQkFDdEQsSUFBSTtxQkFDSCxTQUFTLENBQ04sQ0FBQyxJQUFTLEVBQVEsRUFBRTtvQkFDaEIsT0FBTyxDQUFDLEdBQUcsQ0FBQyxXQUFXLEVBQUMsSUFBSSxDQUFDLENBQUM7b0JBQzlCLE9BQU8sR0FBRyxJQUFJLENBQUMsSUFBSSxFQUFFLENBQUM7b0JBQ3RCLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxPQUFPLENBQUMsQ0FBQztnQkFDbkMsQ0FBQyxFQUNELENBQUMsS0FBVSxFQUFRLEVBQUUsR0FBRyxDQUFDLEVBQ3pCLEdBQVMsRUFBRSxHQUFHLENBQUMsQ0FDbEIsQ0FBQzthQUNUO1lBQUMsT0FBTyxHQUFHLEVBQUUsR0FBRztTQUNwQjthQUNJO1lBQ0QsT0FBTyxHQUFHLElBQUksQ0FBQyxJQUFJLENBQUM7WUFDcEIsSUFBSSxDQUFDLGdCQUFnQixDQUFDLE9BQU8sQ0FBQyxDQUFDO1NBQ2xDO0lBRUwsQ0FBQztJQUVPLGdCQUFnQixDQUFDLE9BQWU7UUFDcEMsSUFBSSxLQUFLLEdBQUcsSUFBSSxNQUFNLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxPQUFPLENBQUMsRUFBRSxHQUFHLENBQUMsQ0FBQztRQUN0RCxPQUFPLEdBQUcsT0FBTyxDQUFDLE9BQU8sQ0FBQyxLQUFLLEVBQUUsRUFBRSxDQUFDLENBQUMsSUFBSSxFQUFFLENBQUM7UUFDNUMsT0FBTyxHQUFHLElBQUksQ0FBQyxLQUFLLENBQUMsU0FBUyxDQUFDLE9BQU8sRUFBRSxJQUFJLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDO1FBQ3RFLElBQUksQ0FBQyxVQUFVLENBQUMsdUJBQXVCLENBQUMsT0FBTyxDQUFDLENBQUM7UUFDakQsSUFBSSxDQUFDLFlBQVksR0FBRyxPQUFPLENBQUM7SUFDaEMsQ0FBQztJQUVPLFVBQVUsQ0FBQyxLQUFhO1FBQzVCLElBQUksU0FBUyxHQUFHLEtBQUssQ0FBQyxLQUFLLENBQUMsYUFBYSxDQUFDLENBQUM7UUFDM0MsSUFBSSxXQUFXLEdBQUcsSUFBSSxDQUFDO1FBQ3ZCLElBQUksU0FBUyxLQUFLLElBQUksRUFBRTtZQUNwQixLQUFLLElBQUksQ0FBQyxHQUFXLENBQUMsRUFBRSxDQUFDLEdBQUcsU0FBUyxDQUFDLE1BQU0sRUFBRSxDQUFDLEVBQUUsRUFBRTtnQkFDL0MsSUFBSSxXQUFXLEtBQUssSUFBSSxJQUFJLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLEdBQUcsQ0FBQyxFQUFFO29CQUNqRCxXQUFXLEdBQUcsU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDO2lCQUM5QjtxQkFDSSxJQUFJLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLEdBQUcsQ0FBQyxJQUFJLFdBQVcsQ0FBQyxNQUFNLEdBQUcsU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sRUFBRTtvQkFDMUUsV0FBVyxHQUFHLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQztpQkFDOUI7YUFDSjtTQUNKO1FBQ0QsT0FBTyxXQUFXLENBQUM7SUFDdkIsQ0FBQztJQUVPLFFBQVEsQ0FBQyxLQUFhO1FBQzFCLElBQUksS0FBSyxLQUFLLFlBQVksSUFBSSxLQUFLLEtBQUssSUFBSSxJQUFJLEtBQUssS0FBSyxZQUFZLEVBQUU7WUFDcEUsT0FBTyxJQUFJLENBQUMsS0FBSyxDQUFDLFNBQVMsQ0FBQyxVQUFVLENBQUM7U0FDMUM7YUFDSSxJQUFJLEtBQUssS0FBSyxNQUFNLEVBQUU7WUFDdkIsT0FBTyxJQUFJLENBQUMsS0FBSyxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUM7U0FDcEM7YUFDSSxJQUFJLEtBQUssS0FBSyxLQUFLLEVBQUU7WUFDdEIsT0FBTyxJQUFJLENBQUMsS0FBSyxDQUFDLFNBQVMsQ0FBQyxHQUFHLENBQUM7U0FDbkM7YUFDSTtZQUNELE9BQU8sSUFBSSxDQUFDLEtBQUssQ0FBQyxTQUFTLENBQUMsTUFBTSxDQUFDO1NBQ3RDO0lBQ0wsQ0FBQzs7O1lBMUZKLFNBQVMsU0FBQztnQkFDUCxRQUFRLEVBQUUsY0FBYztnQkFDeEIsUUFBUSxFQUFFOztLQUVUO2FBQ0o7OztZQVRRLFlBQVk7WUFIWixVQUFVOzs7bUJBbUJkLEtBQUs7bUJBQ0wsS0FBSzt1QkFDTCxLQUFLIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHtcclxuICAgIENvbXBvbmVudCxcclxuICAgIElucHV0LFxyXG4gICAgT25Jbml0XHJcbn0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XHJcbi8vIGltcG9ydCB7IFJlc3BvbnNlIH0gZnJvbSAnQGFuZ3VsYXIvaHR0cCc7XHJcbmltcG9ydCB7IEh0dHBDbGllbnR9IGZyb20gJ0Bhbmd1bGFyL2NvbW1vbi9odHRwJztcclxuaW1wb3J0IHsgU3Vic2NyaXB0aW9uIH0gZnJvbSAncnhqcyc7XHJcbmltcG9ydCB7IG1hcCB9IGZyb20gJ3J4anMvb3BlcmF0b3JzJztcclxuaW1wb3J0IHsgRG9tU2FuaXRpemVyIH0gZnJvbSAnQGFuZ3VsYXIvcGxhdGZvcm0tYnJvd3Nlcic7XHJcblxyXG5kZWNsYXJlIHZhciByZXF1aXJlOiBhbnk7XHJcblxyXG5AQ29tcG9uZW50KHtcclxuICAgIHNlbGVjdG9yOiAna2QtY29kZWJsb2NrJyxcclxuICAgIHRlbXBsYXRlOiBgXHJcbiAgICAgICAgICAgIDxwcmUgY2xhc3M9J2xhbmd1YWdlLWphdmFzY3JpcHQnIHN0eWxlPSdmb250LXNpemU6IDEycHgnPjxjb2RlIGNsYXNzPSdsYW5ndWFnZS1qYXZhc2NyaXB0JyBbaW5uZXJIdG1sXT0nX3VwZGF0ZWRDb2RlJz48L2NvZGU+PC9wcmU+XHJcbiAgICBgLFxyXG59KVxyXG5cclxuZXhwb3J0IGNsYXNzIEtkQ29kZWJsb2NrIGltcGxlbWVudHMgT25Jbml0IHtcclxuICAgIHB1YmxpYyBfdXBkYXRlZENvZGU6IHN0cmluZztcclxuICAgIHByaXZhdGUgUHJpc20gPSByZXF1aXJlKCdwcmlzbWpzJyk7XHJcbiAgICBwcml2YXRlIF9odHRwU3ViOiBTdWJzY3JpcHRpb247XHJcblxyXG4gICAgQElucHV0KCkgY29kZTogc3RyaW5nID0gbnVsbDtcclxuICAgIEBJbnB1dCgpIHBhdGg6IHN0cmluZztcclxuICAgIEBJbnB1dCgpIGxhbmd1YWdlOiBzdHJpbmc7XHJcblxyXG4gICAgLy8gdHJ1c3RIVE1MY29kZTogU2FmZVVybDtcclxuICAgIGNvbnN0cnVjdG9yKHByaXZhdGUgX3Nhbml0aXplcjogRG9tU2FuaXRpemVyLCBwcml2YXRlIF9odHRwOiBIdHRwQ2xpZW50KSB7IH1cclxuXHJcbiAgICBuZ09uSW5pdCgpOiB2b2lkIHtcclxuICAgICAgICAvLyBsZXQgdGVtcFN0ciA9IHRoaXMuY29kZTtcclxuICAgICAgICAvLyBsZXQgcmVnZXggPSBuZXcgUmVnRXhwKHRoaXMuX2dldFNwYWNlcyh0ZW1wU3RyKSwgJ2cnKTtcclxuICAgICAgICAvLyAvLyB0ZW1wU3RyID0gdGVtcFN0ci5yZXBsYWNlKC8gICsvZywgJycpLnRyaW0oKTtcclxuICAgICAgICAvLyB0ZW1wU3RyID0gdGVtcFN0ci5yZXBsYWNlKHJlZ2V4LCAnJykudHJpbSgpO1xyXG4gICAgICAgIC8vIHRlbXBTdHIgPSB0aGlzLlByaXNtLmhpZ2hsaWdodCh0ZW1wU3RyLCB0aGlzLl9nZXRUeXBlKHRoaXMubGFuZ3VhZ2UpKTtcclxuICAgICAgICAvLyB0aGlzLl9zYW5pdGl6ZXIuYnlwYXNzU2VjdXJpdHlUcnVzdEh0bWwodGVtcFN0cik7XHJcbiAgICAgICAgLy8gdGhpcy5jb2RlID0gdGVtcFN0cjtcclxuXHJcbiAgICAgICAgbGV0IHRlbXBTdHI6IHN0cmluZztcclxuICAgICAgICBpZiAodHlwZW9mIHRoaXMucGF0aCAhPT0gJ3VuZGVmaW5lZCcpIHtcclxuICAgICAgICAgICAgdHJ5IHtcclxuICAgICAgICAgICAgICAgIHRoaXMuX2h0dHBTdWIgPSB0aGlzLl9odHRwLmdldCh0aGlzLnBhdGgpXHJcbiAgICAgICAgICAgICAgICAgICAgLy8gLnBpcGUoXHJcbiAgICAgICAgICAgICAgICAgICAgLy8gICAgIG1hcCgocmVzcG9uZDogUmVzcG9uc2UpOiBhbnkgPT4gcmVzcG9uZC50ZXh0KCkpXHJcbiAgICAgICAgICAgICAgICAgICAgLy8gKVxyXG4gICAgICAgICAgICAgICAgICAgIC5zdWJzY3JpYmUoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIChkYXRhOiBhbnkpOiB2b2lkID0+IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKCdDb2RlYmxvY2snLGRhdGEpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdGVtcFN0ciA9IGRhdGEudHJpbSgpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5fdXBkYXRlQ29kZWJsb2NrKHRlbXBTdHIpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAoZXJyb3I6IGFueSk6IHZvaWQgPT4geyB9LFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAoKTogdm9pZCA9PiB7IH1cclxuICAgICAgICAgICAgICAgICAgICApO1xyXG4gICAgICAgICAgICB9IGNhdGNoIChlcnIpIHsgfVxyXG4gICAgICAgIH1cclxuICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgdGVtcFN0ciA9IHRoaXMuY29kZTtcclxuICAgICAgICAgICAgdGhpcy5fdXBkYXRlQ29kZWJsb2NrKHRlbXBTdHIpO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfdXBkYXRlQ29kZWJsb2NrKHRlbXBTdHI6IHN0cmluZyk6IHZvaWQge1xyXG4gICAgICAgIGxldCByZWdleCA9IG5ldyBSZWdFeHAodGhpcy5fZ2V0U3BhY2VzKHRlbXBTdHIpLCAnZycpO1xyXG4gICAgICAgIHRlbXBTdHIgPSB0ZW1wU3RyLnJlcGxhY2UocmVnZXgsICcnKS50cmltKCk7XHJcbiAgICAgICAgdGVtcFN0ciA9IHRoaXMuUHJpc20uaGlnaGxpZ2h0KHRlbXBTdHIsIHRoaXMuX2dldFR5cGUodGhpcy5sYW5ndWFnZSkpO1xyXG4gICAgICAgIHRoaXMuX3Nhbml0aXplci5ieXBhc3NTZWN1cml0eVRydXN0SHRtbCh0ZW1wU3RyKTtcclxuICAgICAgICB0aGlzLl91cGRhdGVkQ29kZSA9IHRlbXBTdHI7XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfZ2V0U3BhY2VzKF90ZXh0OiBzdHJpbmcpOiBzdHJpbmcge1xyXG4gICAgICAgIGxldCBzcGFjZXNBcnIgPSBfdGV4dC5tYXRjaCgvW15cXFNcXG5cXHRdKy9nKTtcclxuICAgICAgICBsZXQgcmVtb3ZlU3BhY2UgPSBudWxsO1xyXG4gICAgICAgIGlmIChzcGFjZXNBcnIgIT09IG51bGwpIHtcclxuICAgICAgICAgICAgZm9yIChsZXQgaTogbnVtYmVyID0gMDsgaSA8IHNwYWNlc0Fyci5sZW5ndGg7IGkrKykge1xyXG4gICAgICAgICAgICAgICAgaWYgKHJlbW92ZVNwYWNlID09PSBudWxsICYmIHNwYWNlc0FycltpXS5sZW5ndGggPiAxKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgcmVtb3ZlU3BhY2UgPSBzcGFjZXNBcnJbaV07XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICBlbHNlIGlmIChzcGFjZXNBcnJbaV0ubGVuZ3RoID4gMSAmJiByZW1vdmVTcGFjZS5sZW5ndGggPiBzcGFjZXNBcnJbaV0ubGVuZ3RoKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgcmVtb3ZlU3BhY2UgPSBzcGFjZXNBcnJbaV07XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICAgICAgcmV0dXJuIHJlbW92ZVNwYWNlO1xyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX2dldFR5cGUoX3R5cGU6IHN0cmluZyk6IGFueSB7XHJcbiAgICAgICAgaWYgKF90eXBlID09PSAnamF2YXNjcmlwdCcgfHwgX3R5cGUgPT09ICdqcycgfHwgX3R5cGUgPT09ICd0eXBlc2NyaXB0Jykge1xyXG4gICAgICAgICAgICByZXR1cm4gdGhpcy5QcmlzbS5sYW5ndWFnZXMuamF2YXNjcmlwdDtcclxuICAgICAgICB9XHJcbiAgICAgICAgZWxzZSBpZiAoX3R5cGUgPT09ICdodG1sJykge1xyXG4gICAgICAgICAgICByZXR1cm4gdGhpcy5QcmlzbS5sYW5ndWFnZXMuaHRtbDtcclxuICAgICAgICB9XHJcbiAgICAgICAgZWxzZSBpZiAoX3R5cGUgPT09ICdjc3MnKSB7XHJcbiAgICAgICAgICAgIHJldHVybiB0aGlzLlByaXNtLmxhbmd1YWdlcy5jc3M7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICByZXR1cm4gdGhpcy5QcmlzbS5sYW5ndWFnZXMubWFya3VwO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxufVxyXG4iXX0=