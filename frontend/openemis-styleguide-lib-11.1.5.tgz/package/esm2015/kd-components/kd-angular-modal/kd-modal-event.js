import { Injectable } from '@angular/core';
import { KdBroadcaster } from '../kd-common/index';
import * as i0 from "@angular/core";
import * as i1 from "../kd-common/kd-broadcaster-svc";
export class KdModalEvent {
    constructor(_broadcaster) {
        this._broadcaster = _broadcaster;
    }
    toggleOpen(data) {
        this._broadcaster.broadcast('ModalOpen', data);
    }
    onToggleOpen() {
        return this._broadcaster.on('ModalOpen');
    }
    toggleClose(data) {
        this._broadcaster.broadcast('ModalClose', data);
    }
    onToggleClose() {
        return this._broadcaster.on('ModalClose');
    }
}
KdModalEvent.ɵprov = i0.ɵɵdefineInjectable({ factory: function KdModalEvent_Factory() { return new KdModalEvent(i0.ɵɵinject(i1.KdBroadcaster)); }, token: KdModalEvent, providedIn: "root" });
KdModalEvent.decorators = [
    { type: Injectable, args: [{
                providedIn: 'root'
            },] }
];
KdModalEvent.ctorParameters = () => [
    { type: KdBroadcaster }
];
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoia2QtbW9kYWwtZXZlbnQuanMiLCJzb3VyY2VSb290IjoiQzoveGFtcHAvaHRkb2NzL1N0eWxlZ3VpZGUvaW9zdGctb3BlbmVtaXMtc3R5bGVndWlkZS9wcm9qZWN0cy9vcGVuZW1pcy1zdHlsZWd1aWRlLWxpYi9zcmMvIiwic291cmNlcyI6WyJrZC1jb21wb25lbnRzL2tkLWFuZ3VsYXItbW9kYWwva2QtbW9kYWwtZXZlbnQudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsT0FBTyxFQUFFLFVBQVUsRUFBRSxNQUFNLGVBQWUsQ0FBQztBQUUzQyxPQUFPLEVBQUUsYUFBYSxFQUFFLE1BQU0sb0JBQW9CLENBQUM7OztBQUtuRCxNQUFNLE9BQU8sWUFBWTtJQUNyQixZQUFvQixZQUEyQjtRQUEzQixpQkFBWSxHQUFaLFlBQVksQ0FBZTtJQUFJLENBQUM7SUFFcEQsVUFBVSxDQUFDLElBQVU7UUFDakIsSUFBSSxDQUFDLFlBQVksQ0FBQyxTQUFTLENBQUMsV0FBVyxFQUFFLElBQUksQ0FBQyxDQUFDO0lBQ25ELENBQUM7SUFFRCxZQUFZO1FBQ1IsT0FBTyxJQUFJLENBQUMsWUFBWSxDQUFDLEVBQUUsQ0FBTSxXQUFXLENBQUMsQ0FBQztJQUNsRCxDQUFDO0lBRUQsV0FBVyxDQUFDLElBQVU7UUFDbEIsSUFBSSxDQUFDLFlBQVksQ0FBQyxTQUFTLENBQUMsWUFBWSxFQUFFLElBQUksQ0FBQyxDQUFDO0lBQ3BELENBQUM7SUFFRCxhQUFhO1FBQ1QsT0FBTyxJQUFJLENBQUMsWUFBWSxDQUFDLEVBQUUsQ0FBTSxZQUFZLENBQUMsQ0FBQztJQUNuRCxDQUFDOzs7O1lBcEJKLFVBQVUsU0FBQztnQkFDUixVQUFVLEVBQUUsTUFBTTthQUNyQjs7O1lBSlEsYUFBYSIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IEluamVjdGFibGUgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcclxuaW1wb3J0IHsgT2JzZXJ2YWJsZSB9IGZyb20gJ3J4anMnO1xyXG5pbXBvcnQgeyBLZEJyb2FkY2FzdGVyIH0gZnJvbSAnLi4va2QtY29tbW9uL2luZGV4JztcclxuXHJcbkBJbmplY3RhYmxlKHtcclxuICAgIHByb3ZpZGVkSW46ICdyb290J1xyXG59KVxyXG5leHBvcnQgY2xhc3MgS2RNb2RhbEV2ZW50IHtcclxuICAgIGNvbnN0cnVjdG9yKHByaXZhdGUgX2Jyb2FkY2FzdGVyOiBLZEJyb2FkY2FzdGVyKSB7IH1cclxuXHJcbiAgICB0b2dnbGVPcGVuKGRhdGE/OiBhbnkpOiB2b2lkIHtcclxuICAgICAgICB0aGlzLl9icm9hZGNhc3Rlci5icm9hZGNhc3QoJ01vZGFsT3BlbicsIGRhdGEpO1xyXG4gICAgfVxyXG5cclxuICAgIG9uVG9nZ2xlT3BlbigpOiBPYnNlcnZhYmxlPGFueT4ge1xyXG4gICAgICAgIHJldHVybiB0aGlzLl9icm9hZGNhc3Rlci5vbjxhbnk+KCdNb2RhbE9wZW4nKTtcclxuICAgIH1cclxuXHJcbiAgICB0b2dnbGVDbG9zZShkYXRhPzogYW55KTogdm9pZCB7XHJcbiAgICAgICAgdGhpcy5fYnJvYWRjYXN0ZXIuYnJvYWRjYXN0KCdNb2RhbENsb3NlJywgZGF0YSk7XHJcbiAgICB9XHJcblxyXG4gICAgb25Ub2dnbGVDbG9zZSgpOiBPYnNlcnZhYmxlPGFueT4ge1xyXG4gICAgICAgIHJldHVybiB0aGlzLl9icm9hZGNhc3Rlci5vbjxhbnk+KCdNb2RhbENsb3NlJyk7XHJcbiAgICB9XHJcbn1cclxuIl19