import { Component, Input, ViewChild } from '@angular/core';
import { NgbModal, ModalDismissReasons, NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { KdModalEvent } from './kd-modal-event';
export { KdModalEvent } from './kd-modal-event';
export class KdModal {
    constructor(_ngbModal, _modalEvent) {
        this._ngbModal = _ngbModal;
        this._modalEvent = _modalEvent;
        this._isBodyExist = false;
        this._modalDefault = {
            suspendClose: false,
            title: 'Modal Title',
            body: 'Modal Body Text.',
            button: [
                {
                    text: 'Cancel',
                    class: 'btn-outline',
                    callback: () => { }
                }
            ]
        };
    }
    ngOnInit() {
        this.defaultConfig();
        this._modalOpenSub = this._modalEvent.onToggleOpen().subscribe(val => {
            if (typeof val === 'undefined' || this.config.id === val) {
                this._curModal = this._ngbModal.open(this.contentRef);
                // console.log(this._curModal.close);
                // console.log('am i modal loaded', val);
                // if (typeof this.config.id === 'undefined') this.open(this.contentRef);
                // else if (val === this.config.id) this.open(this.contentRef);
                this._curModal.result.then((_result) => {
                    this.closeResult = `Closed with: ${_result}`;
                    // console.log('_result : ', this.closeResult);
                }, (_reason) => {
                    this.closeResult = `Dismissed ${this._getDismissReason(_reason)}`;
                    // console.log('_reason : ', this.closeResult);
                });
            }
        });
        this._modalCloseSub = this._modalEvent.onToggleClose().subscribe(val => {
            if (typeof val === 'undefined' || this.config.id === val) {
                this._curModal.close();
            }
        });
    }
    ngOnChanges() {
        this.defaultConfig();
    }
    ngOnDestroy() {
        this._modalOpenSub.unsubscribe();
    }
    defaultConfig() {
        if (typeof this.config !== 'undefined') {
            this._modalDefault = this.config;
            if (typeof this._modalDefault.button !== 'undefined') {
                for (let i = 0; i < this._modalDefault.button.length; i++) {
                    if (typeof this.config !== 'undefined')
                        this._modalDefault.button[i] = this.config.button[i];
                }
            }
            if (typeof this.config.body !== 'undefined' && this.config.body !== '')
                this._isBodyExist = true;
        }
    }
    callback(event, btn) {
        if (typeof btn.callback === 'function')
            btn.callback(event, btn);
    }
    _getDismissReason(reason) {
        if (reason === ModalDismissReasons.ESC)
            return 'by pressing ESC';
        else if (reason === ModalDismissReasons.BACKDROP_CLICK)
            return 'by clicking on a backdrop';
        else
            return `with: ${reason}`;
    }
}
KdModal.decorators = [
    { type: Component, args: [{
                selector: 'kd-modal',
                template: "<ng-template ngbModalContainer #content let-c=\"close\" let-d=\"dismiss\">\r\n    <div class=\"kdx-modal-dialog-wrapper\">\r\n        <div class=\"modal-header\">\r\n            <h4 class=\"modal-title\">{{_modalDefault.title}}</h4>\r\n            <button  *ngIf=\"!_modalDefault.suspendClose\" type=\"button\" class=\"close\" aria-label=\"Close\" (click)=\"d('Cross click')\">\r\n              <i class=\"kd-close-round\" aria-hidden=\"true\"></i>\r\n            </button>\r\n        </div>\r\n        <div class=\"modal-body\">\r\n            <p *ngIf=\"_isBodyExist\">{{_modalDefault.body}}</p>\r\n            <ng-content *ngIf=\"!_isBodyExist\"></ng-content>\r\n        </div>\r\n        <div class=\"modal-footer\">\r\n            <button type=\"button\" class=\"btn\" ngClass=\"{{btn.class}}\" *ngFor=\"let btn of _modalDefault.button\" (click)=\"callback($event, btn)\">\r\n                {{btn.text}}\r\n            </button>\r\n            <!-- <button type=\"button\" class=\"btn {{btn.class}}\" (click)=\"c('Close click')\">{{btn.text}}</button> -->\r\n        </div>\r\n    </div>\r\n</ng-template>\r\n<!-- <pre>{{closeResult}}</pre> -->\r\n",
                providers: [KdModalEvent, NgbActiveModal]
            },] }
];
KdModal.ctorParameters = () => [
    { type: NgbModal },
    { type: KdModalEvent }
];
KdModal.propDecorators = {
    config: [{ type: Input }],
    contentRef: [{ type: ViewChild, args: ['content', { static: true },] }]
};
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoia2QtYW5ndWxhci1tb2RhbC5qcyIsInNvdXJjZVJvb3QiOiJDOi94YW1wcC9odGRvY3MvU3R5bGVndWlkZS9pb3N0Zy1vcGVuZW1pcy1zdHlsZWd1aWRlL3Byb2plY3RzL29wZW5lbWlzLXN0eWxlZ3VpZGUtbGliL3NyYy8iLCJzb3VyY2VzIjpbImtkLWNvbXBvbmVudHMva2QtYW5ndWxhci1tb2RhbC9rZC1hbmd1bGFyLW1vZGFsLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBLE9BQU8sRUFDSCxTQUFTLEVBQ1QsS0FBSyxFQUVMLFNBQVMsRUFFWixNQUFNLGVBQWUsQ0FBQztBQUV2QixPQUFPLEVBQUUsUUFBUSxFQUFFLG1CQUFtQixFQUFFLGNBQWMsRUFBZSxNQUFNLDRCQUE0QixDQUFDO0FBQ3hHLE9BQU8sRUFBRSxZQUFZLEVBQUUsTUFBTSxrQkFBa0IsQ0FBQztBQUdoRCxPQUFPLEVBQUUsWUFBWSxFQUFFLE1BQU0sa0JBQWtCLENBQUM7QUFRaEQsTUFBTSxPQUFPLE9BQU87SUFzQmhCLFlBQ1ksU0FBbUIsRUFDbkIsV0FBeUI7UUFEekIsY0FBUyxHQUFULFNBQVMsQ0FBVTtRQUNuQixnQkFBVyxHQUFYLFdBQVcsQ0FBYztRQXRCOUIsaUJBQVksR0FBWSxLQUFLLENBQUM7UUFLckMsa0JBQWEsR0FBUTtZQUNqQixZQUFZLEVBQUUsS0FBSztZQUNuQixLQUFLLEVBQUUsYUFBYTtZQUNwQixJQUFJLEVBQUUsa0JBQWtCO1lBQ3hCLE1BQU0sRUFBRTtnQkFDSjtvQkFDSSxJQUFJLEVBQUUsUUFBUTtvQkFDZCxLQUFLLEVBQUUsYUFBYTtvQkFDcEIsUUFBUSxFQUFFLEdBQVMsRUFBRSxHQUFHLENBQUM7aUJBQzVCO2FBQUM7U0FDVCxDQUFDO0lBUUUsQ0FBQztJQUVMLFFBQVE7UUFDSixJQUFJLENBQUMsYUFBYSxFQUFFLENBQUM7UUFDckIsSUFBSSxDQUFDLGFBQWEsR0FBRyxJQUFJLENBQUMsV0FBVyxDQUFDLFlBQVksRUFBRSxDQUFDLFNBQVMsQ0FBQyxHQUFHLENBQUMsRUFBRTtZQUNqRSxJQUFJLE9BQU8sR0FBRyxLQUFLLFdBQVcsSUFBSSxJQUFJLENBQUMsTUFBTSxDQUFDLEVBQUUsS0FBSyxHQUFHLEVBQUU7Z0JBQ3RELElBQUksQ0FBQyxTQUFTLEdBQUcsSUFBSSxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxDQUFDO2dCQUN0RCxxQ0FBcUM7Z0JBQ3JDLHlDQUF5QztnQkFDekMseUVBQXlFO2dCQUN6RSwrREFBK0Q7Z0JBQy9ELElBQUksQ0FBQyxTQUFTLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxDQUFDLE9BQU8sRUFBUSxFQUFFO29CQUN6QyxJQUFJLENBQUMsV0FBVyxHQUFHLGdCQUFnQixPQUFPLEVBQUUsQ0FBQztvQkFDN0MsK0NBQStDO2dCQUNuRCxDQUFDLEVBQUUsQ0FBQyxPQUFPLEVBQVEsRUFBRTtvQkFDakIsSUFBSSxDQUFDLFdBQVcsR0FBRyxhQUFhLElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxPQUFPLENBQUMsRUFBRSxDQUFDO29CQUNsRSwrQ0FBK0M7Z0JBQ25ELENBQUMsQ0FBQyxDQUFDO2FBQ047UUFDTCxDQUFDLENBQUMsQ0FBQztRQUVILElBQUksQ0FBQyxjQUFjLEdBQUcsSUFBSSxDQUFDLFdBQVcsQ0FBQyxhQUFhLEVBQUUsQ0FBQyxTQUFTLENBQUMsR0FBRyxDQUFDLEVBQUU7WUFDbkUsSUFBSSxPQUFPLEdBQUcsS0FBSyxXQUFXLElBQUksSUFBSSxDQUFDLE1BQU0sQ0FBQyxFQUFFLEtBQUssR0FBRyxFQUFFO2dCQUN0RCxJQUFJLENBQUMsU0FBUyxDQUFDLEtBQUssRUFBRSxDQUFDO2FBQzFCO1FBQ0wsQ0FBQyxDQUFDLENBQUM7SUFDUCxDQUFDO0lBRUQsV0FBVztRQUNQLElBQUksQ0FBQyxhQUFhLEVBQUUsQ0FBQztJQUN6QixDQUFDO0lBRUQsV0FBVztRQUNQLElBQUksQ0FBQyxhQUFhLENBQUMsV0FBVyxFQUFFLENBQUM7SUFDckMsQ0FBQztJQUVELGFBQWE7UUFDVCxJQUFJLE9BQU8sSUFBSSxDQUFDLE1BQU0sS0FBSyxXQUFXLEVBQUU7WUFDcEMsSUFBSSxDQUFDLGFBQWEsR0FBRyxJQUFJLENBQUMsTUFBTSxDQUFDO1lBQ2pDLElBQUksT0FBTyxJQUFJLENBQUMsYUFBYSxDQUFDLE1BQU0sS0FBSyxXQUFXLEVBQUU7Z0JBQ2xELEtBQUssSUFBSSxDQUFDLEdBQVcsQ0FBQyxFQUFFLENBQUMsR0FBRyxJQUFJLENBQUMsYUFBYSxDQUFDLE1BQU0sQ0FBQyxNQUFNLEVBQUUsQ0FBQyxFQUFFLEVBQUU7b0JBQy9ELElBQUksT0FBTyxJQUFJLENBQUMsTUFBTSxLQUFLLFdBQVc7d0JBQUUsSUFBSSxDQUFDLGFBQWEsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLEdBQUcsSUFBSSxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUM7aUJBQ2hHO2FBQ0o7WUFDRCxJQUFJLE9BQU8sSUFBSSxDQUFDLE1BQU0sQ0FBQyxJQUFJLEtBQUssV0FBVyxJQUFJLElBQUksQ0FBQyxNQUFNLENBQUMsSUFBSSxLQUFLLEVBQUU7Z0JBQUUsSUFBSSxDQUFDLFlBQVksR0FBRyxJQUFJLENBQUM7U0FDcEc7SUFDTCxDQUFDO0lBRU0sUUFBUSxDQUFDLEtBQVUsRUFBRSxHQUFRO1FBQ2hDLElBQUksT0FBTyxHQUFHLENBQUMsUUFBUSxLQUFLLFVBQVU7WUFBRSxHQUFHLENBQUMsUUFBUSxDQUFDLEtBQUssRUFBRSxHQUFHLENBQUMsQ0FBQztJQUNyRSxDQUFDO0lBRU8saUJBQWlCLENBQUMsTUFBVztRQUNqQyxJQUFJLE1BQU0sS0FBSyxtQkFBbUIsQ0FBQyxHQUFHO1lBQUUsT0FBTyxpQkFBaUIsQ0FBQzthQUM1RCxJQUFJLE1BQU0sS0FBSyxtQkFBbUIsQ0FBQyxjQUFjO1lBQUUsT0FBTywyQkFBMkIsQ0FBQzs7WUFDdEYsT0FBTyxTQUFTLE1BQU0sRUFBRSxDQUFDO0lBQ2xDLENBQUM7OztZQXZGSixTQUFTLFNBQUM7Z0JBQ1AsUUFBUSxFQUFFLFVBQVU7Z0JBQ3BCLDhvQ0FBc0M7Z0JBQ3RDLFNBQVMsRUFBRSxDQUFDLFlBQVksRUFBRSxjQUFjLENBQUM7YUFDNUM7OztZQVZRLFFBQVE7WUFDUixZQUFZOzs7cUJBOEJoQixLQUFLO3lCQUNMLFNBQVMsU0FBQyxTQUFTLEVBQUUsRUFBRSxNQUFNLEVBQUUsSUFBSSxFQUFFIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHtcclxuICAgIENvbXBvbmVudCxcclxuICAgIElucHV0LFxyXG4gICAgT25Jbml0LFxyXG4gICAgVmlld0NoaWxkLFxyXG4gICAgT25EZXN0cm95XHJcbn0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XHJcblxyXG5pbXBvcnQgeyBOZ2JNb2RhbCwgTW9kYWxEaXNtaXNzUmVhc29ucywgTmdiQWN0aXZlTW9kYWwsIE5nYk1vZGFsUmVmIH0gZnJvbSAnQG5nLWJvb3RzdHJhcC9uZy1ib290c3RyYXAnO1xyXG5pbXBvcnQgeyBLZE1vZGFsRXZlbnQgfSBmcm9tICcuL2tkLW1vZGFsLWV2ZW50JztcclxuaW1wb3J0IHsgU3Vic2NyaXB0aW9uIH0gZnJvbSAncnhqcyc7XHJcblxyXG5leHBvcnQgeyBLZE1vZGFsRXZlbnQgfSBmcm9tICcuL2tkLW1vZGFsLWV2ZW50JztcclxuXHJcbkBDb21wb25lbnQoe1xyXG4gICAgc2VsZWN0b3I6ICdrZC1tb2RhbCcsXHJcbiAgICB0ZW1wbGF0ZVVybDogJy4va2QtYW5ndWxhci1tb2RhbC5odG1sJyxcclxuICAgIHByb3ZpZGVyczogW0tkTW9kYWxFdmVudCwgTmdiQWN0aXZlTW9kYWxdXHJcbn0pXHJcblxyXG5leHBvcnQgY2xhc3MgS2RNb2RhbCBpbXBsZW1lbnRzIE9uSW5pdCwgT25EZXN0cm95IHtcclxuICAgIHByaXZhdGUgX2N1ck1vZGFsOiBOZ2JNb2RhbFJlZjtcclxuICAgIHB1YmxpYyBfaXNCb2R5RXhpc3Q6IGJvb2xlYW4gPSBmYWxzZTtcclxuICAgIHByaXZhdGUgX21vZGFsT3BlblN1YjogU3Vic2NyaXB0aW9uO1xyXG4gICAgcHJpdmF0ZSBfbW9kYWxDbG9zZVN1YjogU3Vic2NyaXB0aW9uO1xyXG4gICAgY2xvc2VSZXN1bHQ6IHN0cmluZztcclxuXHJcbiAgICBfbW9kYWxEZWZhdWx0OiBhbnkgPSB7XHJcbiAgICAgICAgc3VzcGVuZENsb3NlOiBmYWxzZSxcclxuICAgICAgICB0aXRsZTogJ01vZGFsIFRpdGxlJyxcclxuICAgICAgICBib2R5OiAnTW9kYWwgQm9keSBUZXh0LicsXHJcbiAgICAgICAgYnV0dG9uOiBbXHJcbiAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICAgIHRleHQ6ICdDYW5jZWwnLFxyXG4gICAgICAgICAgICAgICAgY2xhc3M6ICdidG4tb3V0bGluZScsXHJcbiAgICAgICAgICAgICAgICBjYWxsYmFjazogKCk6IHZvaWQgPT4geyB9XHJcbiAgICAgICAgICAgIH1dXHJcbiAgICB9O1xyXG5cclxuICAgIEBJbnB1dCgpIGNvbmZpZzogYW55O1xyXG4gICAgQFZpZXdDaGlsZCgnY29udGVudCcsIHsgc3RhdGljOiB0cnVlIH0pIGNvbnRlbnRSZWY6IGFueTtcclxuXHJcbiAgICBjb25zdHJ1Y3RvcihcclxuICAgICAgICBwcml2YXRlIF9uZ2JNb2RhbDogTmdiTW9kYWwsXHJcbiAgICAgICAgcHJpdmF0ZSBfbW9kYWxFdmVudDogS2RNb2RhbEV2ZW50XHJcbiAgICApIHsgfVxyXG5cclxuICAgIG5nT25Jbml0KCk6IHZvaWQge1xyXG4gICAgICAgIHRoaXMuZGVmYXVsdENvbmZpZygpO1xyXG4gICAgICAgIHRoaXMuX21vZGFsT3BlblN1YiA9IHRoaXMuX21vZGFsRXZlbnQub25Ub2dnbGVPcGVuKCkuc3Vic2NyaWJlKHZhbCA9PiB7XHJcbiAgICAgICAgICAgIGlmICh0eXBlb2YgdmFsID09PSAndW5kZWZpbmVkJyB8fCB0aGlzLmNvbmZpZy5pZCA9PT0gdmFsKSB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLl9jdXJNb2RhbCA9IHRoaXMuX25nYk1vZGFsLm9wZW4odGhpcy5jb250ZW50UmVmKTtcclxuICAgICAgICAgICAgICAgIC8vIGNvbnNvbGUubG9nKHRoaXMuX2N1ck1vZGFsLmNsb3NlKTtcclxuICAgICAgICAgICAgICAgIC8vIGNvbnNvbGUubG9nKCdhbSBpIG1vZGFsIGxvYWRlZCcsIHZhbCk7XHJcbiAgICAgICAgICAgICAgICAvLyBpZiAodHlwZW9mIHRoaXMuY29uZmlnLmlkID09PSAndW5kZWZpbmVkJykgdGhpcy5vcGVuKHRoaXMuY29udGVudFJlZik7XHJcbiAgICAgICAgICAgICAgICAvLyBlbHNlIGlmICh2YWwgPT09IHRoaXMuY29uZmlnLmlkKSB0aGlzLm9wZW4odGhpcy5jb250ZW50UmVmKTtcclxuICAgICAgICAgICAgICAgIHRoaXMuX2N1ck1vZGFsLnJlc3VsdC50aGVuKChfcmVzdWx0KTogdm9pZCA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5jbG9zZVJlc3VsdCA9IGBDbG9zZWQgd2l0aDogJHtfcmVzdWx0fWA7XHJcbiAgICAgICAgICAgICAgICAgICAgLy8gY29uc29sZS5sb2coJ19yZXN1bHQgOiAnLCB0aGlzLmNsb3NlUmVzdWx0KTtcclxuICAgICAgICAgICAgICAgIH0sIChfcmVhc29uKTogdm9pZCA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5jbG9zZVJlc3VsdCA9IGBEaXNtaXNzZWQgJHt0aGlzLl9nZXREaXNtaXNzUmVhc29uKF9yZWFzb24pfWA7XHJcbiAgICAgICAgICAgICAgICAgICAgLy8gY29uc29sZS5sb2coJ19yZWFzb24gOiAnLCB0aGlzLmNsb3NlUmVzdWx0KTtcclxuICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfSk7XHJcblxyXG4gICAgICAgIHRoaXMuX21vZGFsQ2xvc2VTdWIgPSB0aGlzLl9tb2RhbEV2ZW50Lm9uVG9nZ2xlQ2xvc2UoKS5zdWJzY3JpYmUodmFsID0+IHtcclxuICAgICAgICAgICAgaWYgKHR5cGVvZiB2YWwgPT09ICd1bmRlZmluZWQnIHx8IHRoaXMuY29uZmlnLmlkID09PSB2YWwpIHtcclxuICAgICAgICAgICAgICAgIHRoaXMuX2N1ck1vZGFsLmNsb3NlKCk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9KTtcclxuICAgIH1cclxuXHJcbiAgICBuZ09uQ2hhbmdlcygpOiB2b2lkIHtcclxuICAgICAgICB0aGlzLmRlZmF1bHRDb25maWcoKTtcclxuICAgIH1cclxuXHJcbiAgICBuZ09uRGVzdHJveSgpOiB2b2lkIHtcclxuICAgICAgICB0aGlzLl9tb2RhbE9wZW5TdWIudW5zdWJzY3JpYmUoKTtcclxuICAgIH1cclxuXHJcbiAgICBkZWZhdWx0Q29uZmlnKCkge1xyXG4gICAgICAgIGlmICh0eXBlb2YgdGhpcy5jb25maWcgIT09ICd1bmRlZmluZWQnKSB7XHJcbiAgICAgICAgICAgIHRoaXMuX21vZGFsRGVmYXVsdCA9IHRoaXMuY29uZmlnO1xyXG4gICAgICAgICAgICBpZiAodHlwZW9mIHRoaXMuX21vZGFsRGVmYXVsdC5idXR0b24gIT09ICd1bmRlZmluZWQnKSB7XHJcbiAgICAgICAgICAgICAgICBmb3IgKGxldCBpOiBudW1iZXIgPSAwOyBpIDwgdGhpcy5fbW9kYWxEZWZhdWx0LmJ1dHRvbi5sZW5ndGg7IGkrKykge1xyXG4gICAgICAgICAgICAgICAgICAgIGlmICh0eXBlb2YgdGhpcy5jb25maWcgIT09ICd1bmRlZmluZWQnKSB0aGlzLl9tb2RhbERlZmF1bHQuYnV0dG9uW2ldID0gdGhpcy5jb25maWcuYnV0dG9uW2ldO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIGlmICh0eXBlb2YgdGhpcy5jb25maWcuYm9keSAhPT0gJ3VuZGVmaW5lZCcgJiYgdGhpcy5jb25maWcuYm9keSAhPT0gJycpIHRoaXMuX2lzQm9keUV4aXN0ID0gdHJ1ZTtcclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgcHVibGljIGNhbGxiYWNrKGV2ZW50OiBhbnksIGJ0bjogYW55KTogdm9pZCB7XHJcbiAgICAgICAgaWYgKHR5cGVvZiBidG4uY2FsbGJhY2sgPT09ICdmdW5jdGlvbicpIGJ0bi5jYWxsYmFjayhldmVudCwgYnRuKTtcclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF9nZXREaXNtaXNzUmVhc29uKHJlYXNvbjogYW55KTogc3RyaW5nIHtcclxuICAgICAgICBpZiAocmVhc29uID09PSBNb2RhbERpc21pc3NSZWFzb25zLkVTQykgcmV0dXJuICdieSBwcmVzc2luZyBFU0MnO1xyXG4gICAgICAgIGVsc2UgaWYgKHJlYXNvbiA9PT0gTW9kYWxEaXNtaXNzUmVhc29ucy5CQUNLRFJPUF9DTElDSykgcmV0dXJuICdieSBjbGlja2luZyBvbiBhIGJhY2tkcm9wJztcclxuICAgICAgICBlbHNlIHJldHVybiBgd2l0aDogJHtyZWFzb259YDtcclxuICAgIH1cclxufVxyXG4iXX0=