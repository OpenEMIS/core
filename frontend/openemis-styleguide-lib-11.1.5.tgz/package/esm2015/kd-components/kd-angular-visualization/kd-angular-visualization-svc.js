import { Injectable } from '@angular/core';
import { KdDomElemSvc } from '../kd-common/index';
export class KdVisualizationSvc {
    constructor(_domElemSvc) {
        this._domElemSvc = _domElemSvc;
    }
    set visualizationElem(_element) { this._visualizationElem = _element; }
    // table within chart does not allow image or input type columns
    filterColumns(_colDefArr) {
        // kd-table config is defined in the following way (9 May 2018)
        // text: does not require the key 'type'
        // input or image: puts type === image || input
        return _colDefArr.filter(column => !column.type).map(column => Object.assign({}, column));
    }
    getImmutableMenuArr(_defaultMenuArr) {
        return _defaultMenuArr.map(item => {
            if (item.expanded)
                this.getImmutableMenuArr(item.expanded);
            return Object.assign({}, item);
        });
    }
    setMenuItemVisibility(_type, _string, _isHide, _menuArr) {
        for (let i = 0; i < _menuArr.length; ++i) {
            if (_menuArr[i][_type] === _string) {
                _menuArr[i].hidden = _isHide;
                if (_type === 'id')
                    break;
            }
            else if (_menuArr[i].hasOwnProperty('expanded')) {
                this.setMenuItemVisibility(_type, _string, _isHide, _menuArr[i].expanded);
            }
        }
    }
    setMenuTranslation(_menuArr, _translationCallback) {
        if (!_menuArr && !_translationCallback)
            return;
        let menuArr = [];
        for (let i = 0; i < _menuArr.length; ++i) {
            let item = Object.assign({}, _menuArr[i]);
            if (item.hasOwnProperty('text') && typeof item.text === 'string') {
                item.text = _translationCallback(item.text) || item.text;
            }
            if (item.hasOwnProperty('expanded'))
                item.expanded = this.setMenuTranslation(item.expanded, _translationCallback);
            menuArr.push(item);
        }
        return menuArr;
    }
    getBtnAlignment(_btnConfig) {
        return (_btnConfig || 'bottom-left').split('-').map(el => 'kdx-visualization-' + el).join(' ');
    }
    // ================================= Export ==================================
    /**
     * before exporting, the html need to be changed
     * 1) remove all dummy labels
     * 2) remove class name '.legend-scroll' in order to display all legend
     *  _parentElem [description]
     */
    // public prepareHTML(_parentElem: HTMLElement): void {
    //     this._removeDummy(_parentElem);
    //     this._removeLegendScroll(_parentElem);
    //     _parentElem.style.height = 'auto';
    // }
    removeDummy(_parentElem) {
        let dummyElementArr = _parentElem.querySelectorAll('.kdx-charts-dummy');
        for (let i = 0; i < dummyElementArr.length; ++i) {
            dummyElementArr[i].remove();
        }
    }
    removeLegendScroll(_parentElem) {
        let legendElem = _parentElem.querySelector('.kdx-legend.legend-scroll');
        this._domElemSvc.removeClass(legendElem, 'legend-scroll');
    }
    // ================================= Table ==================================
    processViewTable(_tableConfig) {
        // when ag-grid is in small screen, render all rows and there will be no inner-scroll
        // this logic is for mobile device, because when using mobile device, a large table should be fully displayed to prevent scrolling confusion (swiping page up might end up scrolling the table)
        // hence we will set parent's height to be 100% of content
        if (this._domElemSvc.isMobile()) {
            // when change to table, store parent's height for chart
            this._parentHeight = window.getComputedStyle(this._visualizationElem.parentNode).height;
            // if mobile, set parent height to 100% so that bottom content will be pushed down
            this.setParentHeight('table');
        }
        // temp fix. table does not follow parent height
        this._setTableHeight(_tableConfig, this._visualizationElem);
    }
    setParentHeight(_type) {
        if (!this._domElemSvc.isMobile())
            return;
        switch (_type) {
            case 'chart':
                // when change to chart, use back the stored parent's height
                // note: chart requires parent to provide a definite height value (cannot use 100% of children)
                this._visualizationElem.parentNode.style.height = this._parentHeight;
                break;
            case 'table':
            default:
                this._visualizationElem.parentNode.style.height = '100%';
                break;
        }
    }
    _setTableHeight(_tableConfig, _element) {
        _tableConfig['gridHeight'] = _element.getBoundingClientRect().height;
    }
}
KdVisualizationSvc.decorators = [
    { type: Injectable }
];
KdVisualizationSvc.ctorParameters = () => [
    { type: KdDomElemSvc }
];
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoia2QtYW5ndWxhci12aXN1YWxpemF0aW9uLXN2Yy5qcyIsInNvdXJjZVJvb3QiOiJDOi94YW1wcC9odGRvY3MvU3R5bGVndWlkZS9pb3N0Zy1vcGVuZW1pcy1zdHlsZWd1aWRlL3Byb2plY3RzL29wZW5lbWlzLXN0eWxlZ3VpZGUtbGliL3NyYy8iLCJzb3VyY2VzIjpbImtkLWNvbXBvbmVudHMva2QtYW5ndWxhci12aXN1YWxpemF0aW9uL2tkLWFuZ3VsYXItdmlzdWFsaXphdGlvbi1zdmMudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsT0FBTyxFQUFFLFVBQVUsRUFBRSxNQUFNLGVBQWUsQ0FBQztBQUUzQyxPQUFPLEVBQUUsWUFBWSxFQUFFLE1BQU0sb0JBQW9CLENBQUM7QUFJbEQsTUFBTSxPQUFPLGtCQUFrQjtJQVEzQixZQUFvQixXQUF5QjtRQUF6QixnQkFBVyxHQUFYLFdBQVcsQ0FBYztJQUFJLENBQUM7SUFGbEQsSUFBSSxpQkFBaUIsQ0FBQyxRQUFRLElBQUksSUFBSSxDQUFDLGtCQUFrQixHQUFHLFFBQVEsQ0FBQyxDQUFDLENBQUM7SUFJdkUsZ0VBQWdFO0lBQ3pELGFBQWEsQ0FBQyxVQUEwQjtRQUMzQywrREFBK0Q7UUFDL0Qsd0NBQXdDO1FBQ3hDLCtDQUErQztRQUMvQyxPQUFPLFVBQVUsQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLEVBQUUsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsQ0FBQyxHQUFHLENBQUMsTUFBTSxDQUFDLEVBQUUsQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLEVBQUUsRUFBRSxNQUFNLENBQUMsQ0FBQyxDQUFDO0lBQzlGLENBQUM7SUFFTSxtQkFBbUIsQ0FBQyxlQUFlO1FBQ3RDLE9BQU8sZUFBZSxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsRUFBRTtZQUM5QixJQUFJLElBQUksQ0FBQyxRQUFRO2dCQUFFLElBQUksQ0FBQyxtQkFBbUIsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLENBQUM7WUFDM0QsT0FBTyxNQUFNLENBQUMsTUFBTSxDQUFDLEVBQUUsRUFBRSxJQUFJLENBQUMsQ0FBQztRQUNuQyxDQUFDLENBQUMsQ0FBQztJQUNQLENBQUM7SUFFTSxxQkFBcUIsQ0FBQyxLQUFzQixFQUFFLE9BQWUsRUFBRSxPQUFnQixFQUFFLFFBQXFCO1FBQ3pHLEtBQUssSUFBSSxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsR0FBRyxRQUFRLENBQUMsTUFBTSxFQUFFLEVBQUUsQ0FBQyxFQUFFO1lBQ3RDLElBQUksUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxLQUFLLE9BQU8sRUFBRTtnQkFDaEMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sR0FBRyxPQUFPLENBQUM7Z0JBQzdCLElBQUksS0FBSyxLQUFLLElBQUk7b0JBQUUsTUFBTTthQUM3QjtpQkFBTSxJQUFJLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxjQUFjLENBQUMsVUFBVSxDQUFDLEVBQUU7Z0JBQy9DLElBQUksQ0FBQyxxQkFBcUIsQ0FBQyxLQUFLLEVBQUUsT0FBTyxFQUFFLE9BQU8sRUFBRSxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUM7YUFDN0U7U0FDSjtJQUNMLENBQUM7SUFFTSxrQkFBa0IsQ0FBQyxRQUFxQixFQUFFLG9CQUFvQjtRQUNqRSxJQUFJLENBQUMsUUFBUSxJQUFJLENBQUMsb0JBQW9CO1lBQUUsT0FBTztRQUUvQyxJQUFJLE9BQU8sR0FBRyxFQUFFLENBQUM7UUFDakIsS0FBSyxJQUFJLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxHQUFHLFFBQVEsQ0FBQyxNQUFNLEVBQUUsRUFBRSxDQUFDLEVBQUU7WUFDdEMsSUFBSSxJQUFJLEdBQUcsTUFBTSxDQUFDLE1BQU0sQ0FBQyxFQUFFLEVBQUUsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7WUFDMUMsSUFBSSxJQUFJLENBQUMsY0FBYyxDQUFDLE1BQU0sQ0FBQyxJQUFJLE9BQU8sSUFBSSxDQUFDLElBQUksS0FBSyxRQUFRLEVBQUU7Z0JBQzlELElBQUksQ0FBQyxJQUFJLEdBQUcsb0JBQW9CLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLElBQUksQ0FBQyxJQUFJLENBQUM7YUFDNUQ7WUFDRCxJQUFJLElBQUksQ0FBQyxjQUFjLENBQUMsVUFBVSxDQUFDO2dCQUFFLElBQUksQ0FBQyxRQUFRLEdBQUcsSUFBSSxDQUFDLGtCQUFrQixDQUFDLElBQUksQ0FBQyxRQUFRLEVBQUUsb0JBQW9CLENBQUMsQ0FBQztZQUNsSCxPQUFPLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDO1NBQ3RCO1FBQ0QsT0FBTyxPQUFPLENBQUM7SUFDbkIsQ0FBQztJQUVNLGVBQWUsQ0FBQyxVQUFxRTtRQUN4RixPQUFPLENBQUMsVUFBVSxJQUFJLGFBQWEsQ0FBQyxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLEVBQUUsQ0FBQyxvQkFBb0IsR0FBRyxFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUM7SUFDbkcsQ0FBQztJQUVELDhFQUE4RTtJQUU5RTs7Ozs7T0FLRztJQUNILHVEQUF1RDtJQUN2RCxzQ0FBc0M7SUFDdEMsNkNBQTZDO0lBQzdDLHlDQUF5QztJQUN6QyxJQUFJO0lBRUcsV0FBVyxDQUFDLFdBQW9CO1FBQ25DLElBQUksZUFBZSxHQUFRLFdBQVcsQ0FBQyxnQkFBZ0IsQ0FBQyxtQkFBbUIsQ0FBQyxDQUFDO1FBQzdFLEtBQUssSUFBSSxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsR0FBRyxlQUFlLENBQUMsTUFBTSxFQUFFLEVBQUUsQ0FBQyxFQUFFO1lBQzdDLGVBQWUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLEVBQUUsQ0FBQztTQUMvQjtJQUNMLENBQUM7SUFFTSxrQkFBa0IsQ0FBQyxXQUFvQjtRQUMxQyxJQUFJLFVBQVUsR0FBRyxXQUFXLENBQUMsYUFBYSxDQUFDLDJCQUEyQixDQUFDLENBQUM7UUFDeEUsSUFBSSxDQUFDLFdBQVcsQ0FBQyxXQUFXLENBQUMsVUFBVSxFQUFFLGVBQWUsQ0FBQyxDQUFDO0lBQzlELENBQUM7SUFFRCw2RUFBNkU7SUFFdEUsZ0JBQWdCLENBQUMsWUFBWTtRQUVoQyxxRkFBcUY7UUFDckYsK0xBQStMO1FBQy9MLDBEQUEwRDtRQUMxRCxJQUFJLElBQUksQ0FBQyxXQUFXLENBQUMsUUFBUSxFQUFFLEVBQUU7WUFDN0Isd0RBQXdEO1lBQ3hELElBQUksQ0FBQyxhQUFhLEdBQUcsTUFBTSxDQUFDLGdCQUFnQixDQUFDLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxVQUFVLENBQUMsQ0FBQyxNQUFNLENBQUM7WUFFeEYsa0ZBQWtGO1lBQ2xGLElBQUksQ0FBQyxlQUFlLENBQUMsT0FBTyxDQUFDLENBQUM7U0FDakM7UUFFRCxnREFBZ0Q7UUFDaEQsSUFBSSxDQUFDLGVBQWUsQ0FBQyxZQUFZLEVBQUUsSUFBSSxDQUFDLGtCQUFrQixDQUFDLENBQUM7SUFDaEUsQ0FBQztJQUVNLGVBQWUsQ0FBQyxLQUFLO1FBQ3hCLElBQUksQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFDLFFBQVEsRUFBRTtZQUFFLE9BQU87UUFFekMsUUFBUSxLQUFLLEVBQUU7WUFDWCxLQUFLLE9BQU87Z0JBQ1IsNERBQTREO2dCQUM1RCwrRkFBK0Y7Z0JBQy9GLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxVQUFVLENBQUMsS0FBSyxDQUFDLE1BQU0sR0FBRyxJQUFJLENBQUMsYUFBYSxDQUFDO2dCQUNyRSxNQUFNO1lBQ1YsS0FBSyxPQUFPLENBQUM7WUFDYjtnQkFDSSxJQUFJLENBQUMsa0JBQWtCLENBQUMsVUFBVSxDQUFDLEtBQUssQ0FBQyxNQUFNLEdBQUcsTUFBTSxDQUFDO2dCQUN6RCxNQUFNO1NBQ2I7SUFDTCxDQUFDO0lBRU8sZUFBZSxDQUFDLFlBQTBCLEVBQUUsUUFBUTtRQUN4RCxZQUFZLENBQUMsWUFBWSxDQUFDLEdBQUcsUUFBUSxDQUFDLHFCQUFxQixFQUFFLENBQUMsTUFBTSxDQUFDO0lBQ3pFLENBQUM7OztZQXZISixVQUFVOzs7WUFIRixZQUFZIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgSW5qZWN0YWJsZSB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xyXG5pbXBvcnQgeyBJTWVudUl0ZW0gfSBmcm9tICcuLi9rZC1hbmd1bGFyLWNoYXJ0cy9rZC1hbmd1bGFyLWNoYXJ0cy1pbnRlcmZhY2UnO1xyXG5pbXBvcnQgeyBLZERvbUVsZW1TdmMgfSBmcm9tICcuLi9rZC1jb21tb24vaW5kZXgnO1xyXG5pbXBvcnQgeyBJVGFibGVDb25maWcsIElUYWJsZUNvbHVtbiB9IGZyb20gJy4va2QtYW5ndWxhci12aXN1YWxpemF0aW9uLWludGVyZmFjZSc7XHJcblxyXG5ASW5qZWN0YWJsZSgpXHJcbmV4cG9ydCBjbGFzcyBLZFZpc3VhbGl6YXRpb25TdmMge1xyXG5cclxuICAgIHByaXZhdGUgX3BhcmVudEhlaWdodDogc3RyaW5nO1xyXG5cclxuICAgIHByaXZhdGUgX3Zpc3VhbGl6YXRpb25FbGVtOiBhbnk7XHJcblxyXG4gICAgc2V0IHZpc3VhbGl6YXRpb25FbGVtKF9lbGVtZW50KSB7IHRoaXMuX3Zpc3VhbGl6YXRpb25FbGVtID0gX2VsZW1lbnQ7IH1cclxuXHJcbiAgICBjb25zdHJ1Y3Rvcihwcml2YXRlIF9kb21FbGVtU3ZjOiBLZERvbUVsZW1TdmMpIHsgfVxyXG5cclxuICAgIC8vIHRhYmxlIHdpdGhpbiBjaGFydCBkb2VzIG5vdCBhbGxvdyBpbWFnZSBvciBpbnB1dCB0eXBlIGNvbHVtbnNcclxuICAgIHB1YmxpYyBmaWx0ZXJDb2x1bW5zKF9jb2xEZWZBcnI6IElUYWJsZUNvbHVtbltdKTogSVRhYmxlQ29sdW1uW10ge1xyXG4gICAgICAgIC8vIGtkLXRhYmxlIGNvbmZpZyBpcyBkZWZpbmVkIGluIHRoZSBmb2xsb3dpbmcgd2F5ICg5IE1heSAyMDE4KVxyXG4gICAgICAgIC8vIHRleHQ6IGRvZXMgbm90IHJlcXVpcmUgdGhlIGtleSAndHlwZSdcclxuICAgICAgICAvLyBpbnB1dCBvciBpbWFnZTogcHV0cyB0eXBlID09PSBpbWFnZSB8fCBpbnB1dFxyXG4gICAgICAgIHJldHVybiBfY29sRGVmQXJyLmZpbHRlcihjb2x1bW4gPT4gIWNvbHVtbi50eXBlKS5tYXAoY29sdW1uID0+IE9iamVjdC5hc3NpZ24oe30sIGNvbHVtbikpO1xyXG4gICAgfVxyXG5cclxuICAgIHB1YmxpYyBnZXRJbW11dGFibGVNZW51QXJyKF9kZWZhdWx0TWVudUFycikge1xyXG4gICAgICAgIHJldHVybiBfZGVmYXVsdE1lbnVBcnIubWFwKGl0ZW0gPT4ge1xyXG4gICAgICAgICAgICBpZiAoaXRlbS5leHBhbmRlZCkgdGhpcy5nZXRJbW11dGFibGVNZW51QXJyKGl0ZW0uZXhwYW5kZWQpO1xyXG4gICAgICAgICAgICByZXR1cm4gT2JqZWN0LmFzc2lnbih7fSwgaXRlbSk7XHJcbiAgICAgICAgfSk7XHJcbiAgICB9XHJcblxyXG4gICAgcHVibGljIHNldE1lbnVJdGVtVmlzaWJpbGl0eShfdHlwZTogJ2lkJyB8ICdhY3Rpb24nLCBfc3RyaW5nOiBzdHJpbmcsIF9pc0hpZGU6IGJvb2xlYW4sIF9tZW51QXJyOiBJTWVudUl0ZW1bXSk6IHZvaWQge1xyXG4gICAgICAgIGZvciAobGV0IGkgPSAwOyBpIDwgX21lbnVBcnIubGVuZ3RoOyArK2kpIHtcclxuICAgICAgICAgICAgaWYgKF9tZW51QXJyW2ldW190eXBlXSA9PT0gX3N0cmluZykge1xyXG4gICAgICAgICAgICAgICAgX21lbnVBcnJbaV0uaGlkZGVuID0gX2lzSGlkZTtcclxuICAgICAgICAgICAgICAgIGlmIChfdHlwZSA9PT0gJ2lkJykgYnJlYWs7XHJcbiAgICAgICAgICAgIH0gZWxzZSBpZiAoX21lbnVBcnJbaV0uaGFzT3duUHJvcGVydHkoJ2V4cGFuZGVkJykpIHtcclxuICAgICAgICAgICAgICAgIHRoaXMuc2V0TWVudUl0ZW1WaXNpYmlsaXR5KF90eXBlLCBfc3RyaW5nLCBfaXNIaWRlLCBfbWVudUFycltpXS5leHBhbmRlZCk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgcHVibGljIHNldE1lbnVUcmFuc2xhdGlvbihfbWVudUFycjogSU1lbnVJdGVtW10sIF90cmFuc2xhdGlvbkNhbGxiYWNrKTogSU1lbnVJdGVtW10ge1xyXG4gICAgICAgIGlmICghX21lbnVBcnIgJiYgIV90cmFuc2xhdGlvbkNhbGxiYWNrKSByZXR1cm47XHJcblxyXG4gICAgICAgIGxldCBtZW51QXJyID0gW107XHJcbiAgICAgICAgZm9yIChsZXQgaSA9IDA7IGkgPCBfbWVudUFyci5sZW5ndGg7ICsraSkge1xyXG4gICAgICAgICAgICBsZXQgaXRlbSA9IE9iamVjdC5hc3NpZ24oe30sIF9tZW51QXJyW2ldKTtcclxuICAgICAgICAgICAgaWYgKGl0ZW0uaGFzT3duUHJvcGVydHkoJ3RleHQnKSAmJiB0eXBlb2YgaXRlbS50ZXh0ID09PSAnc3RyaW5nJykge1xyXG4gICAgICAgICAgICAgICAgaXRlbS50ZXh0ID0gX3RyYW5zbGF0aW9uQ2FsbGJhY2soaXRlbS50ZXh0KSB8fCBpdGVtLnRleHQ7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgaWYgKGl0ZW0uaGFzT3duUHJvcGVydHkoJ2V4cGFuZGVkJykpIGl0ZW0uZXhwYW5kZWQgPSB0aGlzLnNldE1lbnVUcmFuc2xhdGlvbihpdGVtLmV4cGFuZGVkLCBfdHJhbnNsYXRpb25DYWxsYmFjayk7XHJcbiAgICAgICAgICAgIG1lbnVBcnIucHVzaChpdGVtKTtcclxuICAgICAgICB9XHJcbiAgICAgICAgcmV0dXJuIG1lbnVBcnI7XHJcbiAgICB9XHJcblxyXG4gICAgcHVibGljIGdldEJ0bkFsaWdubWVudChfYnRuQ29uZmlnOiAndG9wLWxlZnQnIHwgJ3RvcC1yaWdodCcgfCAnYm90dG9tLWxlZnQnIHwgJ2JvdHRvbS1yaWdodCcpOiBzdHJpbmcge1xyXG4gICAgICAgIHJldHVybiAoX2J0bkNvbmZpZyB8fCAnYm90dG9tLWxlZnQnKS5zcGxpdCgnLScpLm1hcChlbCA9PiAna2R4LXZpc3VhbGl6YXRpb24tJyArIGVsKS5qb2luKCcgJyk7XHJcbiAgICB9XHJcblxyXG4gICAgLy8gPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09IEV4cG9ydCA9PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09XHJcblxyXG4gICAgLyoqXHJcbiAgICAgKiBiZWZvcmUgZXhwb3J0aW5nLCB0aGUgaHRtbCBuZWVkIHRvIGJlIGNoYW5nZWRcclxuICAgICAqIDEpIHJlbW92ZSBhbGwgZHVtbXkgbGFiZWxzXHJcbiAgICAgKiAyKSByZW1vdmUgY2xhc3MgbmFtZSAnLmxlZ2VuZC1zY3JvbGwnIGluIG9yZGVyIHRvIGRpc3BsYXkgYWxsIGxlZ2VuZFxyXG4gICAgICogIF9wYXJlbnRFbGVtIFtkZXNjcmlwdGlvbl1cclxuICAgICAqL1xyXG4gICAgLy8gcHVibGljIHByZXBhcmVIVE1MKF9wYXJlbnRFbGVtOiBIVE1MRWxlbWVudCk6IHZvaWQge1xyXG4gICAgLy8gICAgIHRoaXMuX3JlbW92ZUR1bW15KF9wYXJlbnRFbGVtKTtcclxuICAgIC8vICAgICB0aGlzLl9yZW1vdmVMZWdlbmRTY3JvbGwoX3BhcmVudEVsZW0pO1xyXG4gICAgLy8gICAgIF9wYXJlbnRFbGVtLnN0eWxlLmhlaWdodCA9ICdhdXRvJztcclxuICAgIC8vIH1cclxuXHJcbiAgICBwdWJsaWMgcmVtb3ZlRHVtbXkoX3BhcmVudEVsZW06IEVsZW1lbnQpOiB2b2lkIHtcclxuICAgICAgICBsZXQgZHVtbXlFbGVtZW50QXJyOiBhbnkgPSBfcGFyZW50RWxlbS5xdWVyeVNlbGVjdG9yQWxsKCcua2R4LWNoYXJ0cy1kdW1teScpO1xyXG4gICAgICAgIGZvciAobGV0IGkgPSAwOyBpIDwgZHVtbXlFbGVtZW50QXJyLmxlbmd0aDsgKytpKSB7XHJcbiAgICAgICAgICAgIGR1bW15RWxlbWVudEFycltpXS5yZW1vdmUoKTtcclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgcHVibGljIHJlbW92ZUxlZ2VuZFNjcm9sbChfcGFyZW50RWxlbTogRWxlbWVudCkge1xyXG4gICAgICAgIGxldCBsZWdlbmRFbGVtID0gX3BhcmVudEVsZW0ucXVlcnlTZWxlY3RvcignLmtkeC1sZWdlbmQubGVnZW5kLXNjcm9sbCcpO1xyXG4gICAgICAgIHRoaXMuX2RvbUVsZW1TdmMucmVtb3ZlQ2xhc3MobGVnZW5kRWxlbSwgJ2xlZ2VuZC1zY3JvbGwnKTtcclxuICAgIH1cclxuXHJcbiAgICAvLyA9PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT0gVGFibGUgPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PVxyXG5cclxuICAgIHB1YmxpYyBwcm9jZXNzVmlld1RhYmxlKF90YWJsZUNvbmZpZykge1xyXG5cclxuICAgICAgICAvLyB3aGVuIGFnLWdyaWQgaXMgaW4gc21hbGwgc2NyZWVuLCByZW5kZXIgYWxsIHJvd3MgYW5kIHRoZXJlIHdpbGwgYmUgbm8gaW5uZXItc2Nyb2xsXHJcbiAgICAgICAgLy8gdGhpcyBsb2dpYyBpcyBmb3IgbW9iaWxlIGRldmljZSwgYmVjYXVzZSB3aGVuIHVzaW5nIG1vYmlsZSBkZXZpY2UsIGEgbGFyZ2UgdGFibGUgc2hvdWxkIGJlIGZ1bGx5IGRpc3BsYXllZCB0byBwcmV2ZW50IHNjcm9sbGluZyBjb25mdXNpb24gKHN3aXBpbmcgcGFnZSB1cCBtaWdodCBlbmQgdXAgc2Nyb2xsaW5nIHRoZSB0YWJsZSlcclxuICAgICAgICAvLyBoZW5jZSB3ZSB3aWxsIHNldCBwYXJlbnQncyBoZWlnaHQgdG8gYmUgMTAwJSBvZiBjb250ZW50XHJcbiAgICAgICAgaWYgKHRoaXMuX2RvbUVsZW1TdmMuaXNNb2JpbGUoKSkge1xyXG4gICAgICAgICAgICAvLyB3aGVuIGNoYW5nZSB0byB0YWJsZSwgc3RvcmUgcGFyZW50J3MgaGVpZ2h0IGZvciBjaGFydFxyXG4gICAgICAgICAgICB0aGlzLl9wYXJlbnRIZWlnaHQgPSB3aW5kb3cuZ2V0Q29tcHV0ZWRTdHlsZSh0aGlzLl92aXN1YWxpemF0aW9uRWxlbS5wYXJlbnROb2RlKS5oZWlnaHQ7XHJcblxyXG4gICAgICAgICAgICAvLyBpZiBtb2JpbGUsIHNldCBwYXJlbnQgaGVpZ2h0IHRvIDEwMCUgc28gdGhhdCBib3R0b20gY29udGVudCB3aWxsIGJlIHB1c2hlZCBkb3duXHJcbiAgICAgICAgICAgIHRoaXMuc2V0UGFyZW50SGVpZ2h0KCd0YWJsZScpO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgLy8gdGVtcCBmaXguIHRhYmxlIGRvZXMgbm90IGZvbGxvdyBwYXJlbnQgaGVpZ2h0XHJcbiAgICAgICAgdGhpcy5fc2V0VGFibGVIZWlnaHQoX3RhYmxlQ29uZmlnLCB0aGlzLl92aXN1YWxpemF0aW9uRWxlbSk7XHJcbiAgICB9XHJcblxyXG4gICAgcHVibGljIHNldFBhcmVudEhlaWdodChfdHlwZSkge1xyXG4gICAgICAgIGlmICghdGhpcy5fZG9tRWxlbVN2Yy5pc01vYmlsZSgpKSByZXR1cm47XHJcblxyXG4gICAgICAgIHN3aXRjaCAoX3R5cGUpIHtcclxuICAgICAgICAgICAgY2FzZSAnY2hhcnQnOlxyXG4gICAgICAgICAgICAgICAgLy8gd2hlbiBjaGFuZ2UgdG8gY2hhcnQsIHVzZSBiYWNrIHRoZSBzdG9yZWQgcGFyZW50J3MgaGVpZ2h0XHJcbiAgICAgICAgICAgICAgICAvLyBub3RlOiBjaGFydCByZXF1aXJlcyBwYXJlbnQgdG8gcHJvdmlkZSBhIGRlZmluaXRlIGhlaWdodCB2YWx1ZSAoY2Fubm90IHVzZSAxMDAlIG9mIGNoaWxkcmVuKVxyXG4gICAgICAgICAgICAgICAgdGhpcy5fdmlzdWFsaXphdGlvbkVsZW0ucGFyZW50Tm9kZS5zdHlsZS5oZWlnaHQgPSB0aGlzLl9wYXJlbnRIZWlnaHQ7XHJcbiAgICAgICAgICAgICAgICBicmVhaztcclxuICAgICAgICAgICAgY2FzZSAndGFibGUnOlxyXG4gICAgICAgICAgICBkZWZhdWx0OlxyXG4gICAgICAgICAgICAgICAgdGhpcy5fdmlzdWFsaXphdGlvbkVsZW0ucGFyZW50Tm9kZS5zdHlsZS5oZWlnaHQgPSAnMTAwJSc7XHJcbiAgICAgICAgICAgICAgICBicmVhaztcclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfc2V0VGFibGVIZWlnaHQoX3RhYmxlQ29uZmlnOiBJVGFibGVDb25maWcsIF9lbGVtZW50KTogdm9pZCB7XHJcbiAgICAgICAgX3RhYmxlQ29uZmlnWydncmlkSGVpZ2h0J10gPSBfZWxlbWVudC5nZXRCb3VuZGluZ0NsaWVudFJlY3QoKS5oZWlnaHQ7XHJcbiAgICB9XHJcblxyXG59XHJcbiJdfQ==