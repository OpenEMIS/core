import { Component, ViewEncapsulation, Input, Output, EventEmitter, ElementRef, ChangeDetectorRef, ViewChild } from '@angular/core';
import { Observable } from 'rxjs';
import { trigger, style, transition, animate } from '@angular/animations';
import { defaultMenuArr } from './kd-angular-visualization-interface';
import { KdVisualizationSvc } from './kd-angular-visualization-svc';
import { KdVisualizationExport } from './kd-angular-visualization-export';
import { KdDomElemSvc } from '../kd-common/index';
import { KdCharts } from '../kd-angular-charts/index';
export class KdVisualization {
    constructor(_elemRef, _visualizationSvc, cdr) {
        this._elemRef = _elemRef;
        this._visualizationSvc = _visualizationSvc;
        this.cdr = cdr;
        /* menu */
        this.isExportEnabled = false;
        this.isMenuOpen = false;
        this.menuFlag = 'closed'; // can be 'opened' | 'closed' | 'expanded' | 'viewed'
        this.menuDisplayArr = [];
        this._menuArr = [];
        this.menuBtnIconClass = 'fa-chevron-up';
        this._menuBtnList = {
            closed: 'fa-chevron-up',
            opened: 'fa-close',
            viewed: 'fa-close',
            expanded: 'fa-chevron-left'
        };
        /* invisible chart */
        this.exportNow = false;
        /* initial load of invisible chart should not start drawing. need to wait for setLegendData, then draw in one go */
        this.dataForInvisibleChart = null;
        this.configForInvisiblechart = null;
        this.invisibleChartClass = 'kdx-visualization-chart-invisible';
        this._defaultChartWidth = '1024px';
        /* view */
        this.contentState = 'chart'; // currently only have chart | table
        this.exportTable = false;
        this._timeoutTiming = 1000;
        this.outputLegendData = new EventEmitter();
        this.errorMsg = new EventEmitter();
        this.outputArea = new EventEmitter();
        this._export = new KdVisualizationExport();
        this._visualizationSvc.visualizationElem = this._elemRef.nativeElement;
    }
    ngOnInit() {
        this._initApi();
    }
    ngOnChanges(_simpleChanges) {
        if (_simpleChanges.hasOwnProperty('config') && _simpleChanges.config.currentValue) {
            this._setConfig(_simpleChanges.config.currentValue.export);
        }
        if (_simpleChanges.hasOwnProperty('rawData') && _simpleChanges.rawData.currentValue) {
            this.columnAfterFilter = this._visualizationSvc.filterColumns(_simpleChanges.rawData.currentValue.column);
        }
    }
    getOutputData(_data) {
        this.dataAfterMassage = _data;
    }
    getOutputLegendData(_legendData) {
        this.outputLegendData.emit(_legendData);
        this.legendDataAfterMassage = _legendData;
    }
    setArea(_data) {
        this.outputArea.emit(_data);
    }
    onExportExcelPossible() {
        if (this.exportTable) {
            this.rawData.api.general.exportToExcel({ fileName: this._fileName });
            this.exportTable = false;
        }
    }
    // ================================= Config ==================================
    _setConfig(_config) {
        // whenever config changes, set back to default values
        this.contentState = 'chart';
        this.menuFlag = 'closed';
        this.isMenuOpen = false;
        this.isExportEnabled = _config && _config.enabled;
        if (!this.isExportEnabled)
            return;
        this._setInitMenu(_config.menu);
        this.invisibleChartStyle = { 'width': _config.width || this._defaultChartWidth };
        this.btnAlignment = this._visualizationSvc.getBtnAlignment(_config.btn);
        this._setInitBtnClass(_config.btn);
    }
    _setInitBtnClass(_btnConfig) {
        if (_btnConfig && _btnConfig.split('-')[0] === 'top') {
            this.menuBtnIconClass = 'fa-chevron-down';
            this._menuBtnList.closed = 'fa-chevron-down';
        }
        else {
            this.menuBtnIconClass = 'fa-chevron-up';
            this._menuBtnList.closed = 'fa-chevron-up';
        }
    }
    _setInitMenu(_menu) {
        let menuArr = this._visualizationSvc.getImmutableMenuArr(defaultMenuArr);
        // translationCallback should take english string and return translated string
        if (this.api && this.api.hasOwnProperty('translationCallback')) {
            menuArr = this._visualizationSvc.setMenuTranslation(menuArr, this.api.translationCallback);
        }
        this._menuArr = menuArr.concat(_menu || []);
        if (!this.rawData)
            this._menuArr = this._menuArr.filter(item => item.id !== 'viewData' && item.id !== 'excel');
        this.menuDisplayArr = this._menuArr;
    }
    // ================================= INIT API and Sub ==================================
    _initApi() {
        if (!this.api)
            return;
        this.api.addMenuItem = (_menuItemArr) => {
            this._menuArr = this._menuArr.concat(_menuItemArr);
            this.cdr.detectChanges();
        };
        this.api.hideMenuItemById = (_id, _isHide = true) => {
            this._visualizationSvc.setMenuItemVisibility('id', _id, _isHide, this._menuArr);
            this.cdr.detectChanges();
        };
        this.api.hideMenuItemByAction = (_action, _isHide = true) => {
            this._visualizationSvc.setMenuItemVisibility('action', _action, _isHide, this._menuArr);
            this.cdr.detectChanges();
        };
        this.api.getDataUrl = (_style, _options, _isRemoveLegendScroll) => {
            return new Observable((_observer) => {
                let originalStyle = {};
                if (_style) {
                    originalStyle = Object.assign({}, this.invisibleChartStyle);
                    this.invisibleChartStyle = _style;
                }
                this._prepExportChart('imageUrl', _options, _isRemoveLegendScroll).subscribe((_response) => {
                    if (_style)
                        this.invisibleChartStyle = originalStyle;
                    _observer.next(_response);
                    _observer.complete();
                });
            });
        };
        this.api.toggleTable = (_showTable, rawData) => {
            rawData.config = Object.assign({}, this.rawData.config, rawData.config);
            this.rawData = Object.assign({}, rawData);
            this.columnAfterFilter = this._visualizationSvc.filterColumns(rawData.column);
            if (_showTable) {
                this._tempState = this.contentState;
                if (this.contentState !== 'table') {
                    this.contentState = 'table';
                    this._callPlugins('view.table');
                }
                this.isExportEnabled = false;
            }
            else {
                this.isExportEnabled = typeof this.config !== 'undefined' && this.config.export.enabled;
                this._visualizationSvc.setParentHeight('chart');
                this.contentState = this._tempState ? this._tempState : 'chart';
            }
        };
    }
    // ================================= Menu Clicked ==================================
    toggleMenu(_item) {
        let haveOperation = _item && _item.operation;
        let haveCallback = _item && _item.callback;
        if (haveOperation)
            this._callPlugins(_item.operation);
        if (haveCallback)
            _item.callback();
        this._toggleMenuFlag(this.menuFlag, _item, haveOperation || haveCallback);
        this.menuBtnIconClass = this._menuBtnList[this.menuFlag];
        this.isMenuOpen = this.menuFlag === 'opened' || this.menuFlag === 'expanded';
    }
    _toggleMenuFlag(_flag, _item, _closeExpand) {
        switch (_flag) {
            case 'closed':
            default:
                this.menuFlag = 'opened';
                break;
            case 'opened':
                let isExpand = _item && _item.expanded;
                if (isExpand) {
                    this.menuDisplayArr = _item.expanded;
                    this.menuFlag = 'expanded';
                    return;
                }
                let isView = false;
                if (_item && _item.hasOwnProperty('operation')) {
                    isView = _item && _item.operation.indexOf('view') > -1;
                    if (isView)
                        this.contentState = _item.operation.split('.')[1];
                }
                this.menuFlag = isView ? 'viewed' : 'closed';
                break;
            case 'expanded':
                this.menuFlag = _closeExpand ? 'closed' : 'opened';
                this.menuDisplayArr = this._menuArr;
                break;
            case 'viewed':
                this._visualizationSvc.setParentHeight('chart');
                this.menuFlag = 'closed';
                this.contentState = 'chart';
                break;
        }
    }
    _callPlugins(_operation) {
        // operations are separated by .
        let operationArr = _operation.split('.');
        if (operationArr[0] === 'view' && operationArr[1] === 'table') {
            this._visualizationSvc.processViewTable(this.rawData.config);
            return;
        }
        if (operationArr[0] !== 'export')
            return;
        if (this.config.title.text)
            this._fileName = this.config.title.text.replace(/\s/g, '_');
        if (operationArr[1] === 'excel') {
            this.exportTable = true;
        }
        else {
            this._prepExportChart(operationArr[1]).subscribe(() => { });
        }
    }
    _prepExportChart(_operation, _options = {}, _isRemoveLegendScroll = true) {
        return new Observable((_observer) => {
            if (!this._export.isExportCompatible()) {
                this.errorMsg.emit(this._export.getErrorMessage(_operation));
                _observer.error(this._export.getErrorMessage(_operation));
                _observer.complete();
            }
            else {
                // chart for exporting should skip massage and not have animation
                this.configForInvisiblechart = Object.assign({}, this.config, { id: 'export-chart', animation: false, skipMassage: true });
                this.exportNow = true;
                // ViewChild requires setTimeout (Angular 5)
                setTimeout(() => {
                    // set Legend Data so that this info does not have to be regenerated by invisible chart
                    this.invisibleChart.setLegendData(this.legendDataAfterMassage);
                    // trigger chart to draw once legend data is set
                    this.dataForInvisibleChart = this.dataAfterMassage;
                });
                let options = Object.assign({}, _options);
                if (this._fileName)
                    options['fileName'] = this._fileName;
                setTimeout(() => {
                    let chartElement = this._elemRef.nativeElement.querySelector('.' + this.invisibleChartClass + '.kdx-charts');
                    // before exporting, the html needs to be changed
                    this._visualizationSvc.removeDummy(chartElement);
                    if (_isRemoveLegendScroll)
                        this._visualizationSvc.removeLegendScroll(chartElement);
                    chartElement.style.height = 'auto';
                    options['width'] = chartElement.getBoundingClientRect().width + 1;
                    options['height'] = chartElement.getBoundingClientRect().height + 1;
                    let result = this._export.exportElement(chartElement, _operation, options);
                    // once export is done, remove the invisible chart from DOM
                    this.exportNow = false;
                    this.dataForInvisibleChart = null;
                    if (result) {
                        result.then(dataUrl => {
                            _observer.next(dataUrl);
                            _observer.complete();
                        });
                    }
                    else {
                        _observer.complete();
                    }
                }, this._timeoutTiming);
            }
        });
    }
}
KdVisualization.decorators = [
    { type: Component, args: [{
                selector: 'kd-visualization',
                template: "<div class=\"kdx-visualization-chart-wrapper\" [ngClass]=\"{'kdx-visualization-invisible-wrapper': contentState !== 'chart'}\">\r\n    <kd-charts [data]=\"data\"\r\n               [config]=\"config\" \r\n               [api]=\"api\"\r\n               [xThreshold]=\"xThreshold\"\r\n               [seriesThreshold]=\"seriesThreshold\"\r\n               (outputData)=\"getOutputData($event)\" \r\n               (outputLegendData)=\"getOutputLegendData($event)\" (outputArea)=\"setArea($event)\"></kd-charts>\r\n    <div class=\"kdx-visualization-invisible-wrapper\">\r\n      <kd-charts *ngIf=\"exportNow\"\r\n                  id=\"export-chart\"\r\n                  #invisibleChart\r\n                  [data]=\"dataForInvisibleChart\" \r\n                  [config]=\"configForInvisiblechart\" \r\n                  [xThreshold]=\"xThreshold\"\r\n                  [seriesThreshold]=\"seriesThreshold\"\r\n                  [ngClass]=\"invisibleChartClass\"\r\n                  [ngStyle]=\"invisibleChartStyle\"></kd-charts>\r\n    </div>\r\n</div>\r\n\r\n<kd-table  *ngIf=\"rawData && (exportTable || contentState == 'table')\"\r\n        [ngClass]=\"{'kdx-visualization-invisible-wrapper': exportTable}\"\r\n        [row]=\"rawData.row\"\r\n        [column]=\"columnAfterFilter\"\r\n        [config]=\"rawData.config\"\r\n        [api]=\"rawData.api\"\r\n        (onExportPossible)=\"onExportExcelPossible()\"></kd-table>\r\n\r\n<div *ngIf=\"isExportEnabled && isMenuOpen\" class=\"kdx-visualization-menu-container\">\r\n    <div *ngFor=\"let item of menuDisplayArr; let i = index \" class=\"kdx-visualization-menu-item-wrapper kdx-visualization-menu-item-{{i}}\" [ngClass]=\"{'menu-item-hide': item.hidden}\" (click)=\"toggleMenu(item)\" [@itemAnim]>\r\n        <i *ngIf=\"item.iconStart\" class=\"kdx-visualization-icon-start fa {{item.iconStart}}\"></i>\r\n        <span *ngIf=\"item.text\">{{item.text}}</span>\r\n        <i *ngIf=\"item.iconEnd\" class=\"kdx-visualization-icon-end fa {{item.iconEnd}}\" [ngClass]=\"{'have-expand-arrow': item.expanded !== undefined }\"></i>\r\n    </div>\r\n</div>\r\n<div *ngIf=\"isExportEnabled\" class=\"kdx-visualization-menu-btn-wrapper\">\r\n    <div class=\"kdx-visualization-menu-btn-container {{btnAlignment}}\">\r\n        <button class=\"kdx-visualization-menu-btn btn-outline\" (click)=\"toggleMenu()\">\r\n            <i class=\"fa {{menuBtnIconClass}} {{menuFlag}}\"></i>\r\n        </button>\r\n    </div>\r\n</div>\r\n",
                encapsulation: ViewEncapsulation.None,
                providers: [KdVisualizationSvc, KdDomElemSvc],
                host: {
                    'class': 'kdx-visualization',
                },
                animations: [
                    trigger('itemAnim', [
                        transition(':enter', [
                            style({ transform: 'translateY(100%)' }),
                            animate('0.2s 0.2s ease-in')
                        ]),
                    ])
                ]
            },] }
];
KdVisualization.ctorParameters = () => [
    { type: ElementRef },
    { type: KdVisualizationSvc },
    { type: ChangeDetectorRef }
];
KdVisualization.propDecorators = {
    data: [{ type: Input, args: ['data',] }],
    rawData: [{ type: Input, args: ['rawData',] }],
    config: [{ type: Input, args: ['config',] }],
    xThreshold: [{ type: Input }],
    seriesThreshold: [{ type: Input }],
    api: [{ type: Input }],
    outputLegendData: [{ type: Output }],
    errorMsg: [{ type: Output }],
    outputArea: [{ type: Output }],
    invisibleChart: [{ type: ViewChild, args: ['invisibleChart',] }]
};
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoia2QtYW5ndWxhci12aXN1YWxpemF0aW9uLmpzIiwic291cmNlUm9vdCI6IkM6L3hhbXBwL2h0ZG9jcy9TdHlsZWd1aWRlL2lvc3RnLW9wZW5lbWlzLXN0eWxlZ3VpZGUvcHJvamVjdHMvb3BlbmVtaXMtc3R5bGVndWlkZS1saWIvc3JjLyIsInNvdXJjZXMiOlsia2QtY29tcG9uZW50cy9rZC1hbmd1bGFyLXZpc3VhbGl6YXRpb24va2QtYW5ndWxhci12aXN1YWxpemF0aW9uLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBLE9BQU8sRUFDSCxTQUFTLEVBQ1QsaUJBQWlCLEVBQ2pCLEtBQUssRUFFTCxNQUFNLEVBR04sWUFBWSxFQUNaLFVBQVUsRUFDVixpQkFBaUIsRUFDakIsU0FBUyxFQUNaLE1BQU0sZUFBZSxDQUFDO0FBQ3ZCLE9BQU8sRUFBRSxVQUFVLEVBQVksTUFBTSxNQUFNLENBQUM7QUFDNUMsT0FBTyxFQUFFLE9BQU8sRUFBRSxLQUFLLEVBQUUsVUFBVSxFQUFFLE9BQU8sRUFBRSxNQUFNLHFCQUFxQixDQUFDO0FBQzFFLE9BQU8sRUFBRSxjQUFjLEVBQXNDLE1BQU0sc0NBQXNDLENBQUM7QUFFMUcsT0FBTyxFQUFFLGtCQUFrQixFQUFFLE1BQU0sZ0NBQWdDLENBQUM7QUFDcEUsT0FBTyxFQUFFLHFCQUFxQixFQUFFLE1BQU0sbUNBQW1DLENBQUM7QUFDMUUsT0FBTyxFQUFFLFlBQVksRUFBRSxNQUFNLG9CQUFvQixDQUFDO0FBQ2xELE9BQU8sRUFBRSxRQUFRLEVBQUUsTUFBTSw0QkFBNEIsQ0FBQztBQW9CdEQsTUFBTSxPQUFPLGVBQWU7SUF3RHhCLFlBQ1ksUUFBb0IsRUFDcEIsaUJBQXFDLEVBQ3JDLEdBQXNCO1FBRnRCLGFBQVEsR0FBUixRQUFRLENBQVk7UUFDcEIsc0JBQWlCLEdBQWpCLGlCQUFpQixDQUFvQjtRQUNyQyxRQUFHLEdBQUgsR0FBRyxDQUFtQjtRQTFEbEMsVUFBVTtRQUNILG9CQUFlLEdBQVksS0FBSyxDQUFDO1FBQ2pDLGVBQVUsR0FBWSxLQUFLLENBQUM7UUFDNUIsYUFBUSxHQUFnRCxRQUFRLENBQUMsQ0FBQyxxREFBcUQ7UUFDdkgsbUJBQWMsR0FBRyxFQUFFLENBQUM7UUFDbkIsYUFBUSxHQUFnQixFQUFFLENBQUM7UUFJNUIscUJBQWdCLEdBQVcsZUFBZSxDQUFDO1FBQzFDLGlCQUFZLEdBQXlFO1lBQ3pGLE1BQU0sRUFBRSxlQUFlO1lBQ3ZCLE1BQU0sRUFBRSxVQUFVO1lBQ2xCLE1BQU0sRUFBRSxVQUFVO1lBQ2xCLFFBQVEsRUFBRSxpQkFBaUI7U0FDOUIsQ0FBQztRQUVGLHFCQUFxQjtRQUNkLGNBQVMsR0FBWSxLQUFLLENBQUM7UUFDbEMsbUhBQW1IO1FBQzVHLDBCQUFxQixHQUFZLElBQUksQ0FBQztRQUN0Qyw0QkFBdUIsR0FBaUIsSUFBSSxDQUFDO1FBSTdDLHdCQUFtQixHQUFXLG1DQUFtQyxDQUFDO1FBQ2pFLHVCQUFrQixHQUFXLFFBQVEsQ0FBQztRQUU5QyxVQUFVO1FBQ0gsaUJBQVksR0FBVyxPQUFPLENBQUMsQ0FBQyxvQ0FBb0M7UUFFcEUsZ0JBQVcsR0FBWSxLQUFLLENBQUM7UUFVNUIsbUJBQWMsR0FBVyxJQUFJLENBQUM7UUFRNUIscUJBQWdCLEdBQWlELElBQUksWUFBWSxFQUFFLENBQUM7UUFDcEYsYUFBUSxHQUF5QixJQUFJLFlBQVksRUFBRSxDQUFDO1FBQ3BELGVBQVUsR0FBMEIsSUFBSSxZQUFZLEVBQUUsQ0FBQztRQVM3RCxJQUFJLENBQUMsT0FBTyxHQUFHLElBQUkscUJBQXFCLEVBQUUsQ0FBQztRQUMzQyxJQUFJLENBQUMsaUJBQWlCLENBQUMsaUJBQWlCLEdBQUcsSUFBSSxDQUFDLFFBQVEsQ0FBQyxhQUFhLENBQUM7SUFDM0UsQ0FBQztJQUVELFFBQVE7UUFDSixJQUFJLENBQUMsUUFBUSxFQUFFLENBQUM7SUFDcEIsQ0FBQztJQUVELFdBQVcsQ0FBQyxjQUE2QjtRQUNyQyxJQUFJLGNBQWMsQ0FBQyxjQUFjLENBQUMsUUFBUSxDQUFDLElBQUksY0FBYyxDQUFDLE1BQU0sQ0FBQyxZQUFZLEVBQUU7WUFDL0UsSUFBSSxDQUFDLFVBQVUsQ0FBQyxjQUFjLENBQUMsTUFBTSxDQUFDLFlBQVksQ0FBQyxNQUFNLENBQUMsQ0FBQztTQUM5RDtRQUVELElBQUksY0FBYyxDQUFDLGNBQWMsQ0FBQyxTQUFTLENBQUMsSUFBSSxjQUFjLENBQUMsT0FBTyxDQUFDLFlBQVksRUFBRTtZQUNqRixJQUFJLENBQUMsaUJBQWlCLEdBQUcsSUFBSSxDQUFDLGlCQUFpQixDQUFDLGFBQWEsQ0FBQyxjQUFjLENBQUMsT0FBTyxDQUFDLFlBQVksQ0FBQyxNQUFNLENBQUMsQ0FBQztTQUM3RztJQUNMLENBQUM7SUFFTSxhQUFhLENBQUMsS0FBYztRQUMvQixJQUFJLENBQUMsZ0JBQWdCLEdBQUcsS0FBSyxDQUFDO0lBQ2xDLENBQUM7SUFFTSxtQkFBbUIsQ0FBQyxXQUEyQztRQUNsRSxJQUFJLENBQUMsZ0JBQWdCLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxDQUFDO1FBQ3hDLElBQUksQ0FBQyxzQkFBc0IsR0FBRyxXQUFXLENBQUM7SUFDOUMsQ0FBQztJQUVNLE9BQU8sQ0FBQyxLQUFLO1FBQ2hCLElBQUksQ0FBQyxVQUFVLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFDO0lBQ2hDLENBQUM7SUFFTSxxQkFBcUI7UUFDeEIsSUFBSSxJQUFJLENBQUMsV0FBVyxFQUFFO1lBQ2xCLElBQUksQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLE9BQU8sQ0FBQyxhQUFhLENBQUMsRUFBRSxRQUFRLEVBQUUsSUFBSSxDQUFDLFNBQVMsRUFBRSxDQUFDLENBQUM7WUFDckUsSUFBSSxDQUFDLFdBQVcsR0FBRyxLQUFLLENBQUM7U0FDNUI7SUFDTCxDQUFDO0lBRUQsOEVBQThFO0lBRXRFLFVBQVUsQ0FBQyxPQUFxQjtRQUNwQyxzREFBc0Q7UUFDdEQsSUFBSSxDQUFDLFlBQVksR0FBRyxPQUFPLENBQUM7UUFDNUIsSUFBSSxDQUFDLFFBQVEsR0FBRyxRQUFRLENBQUM7UUFDekIsSUFBSSxDQUFDLFVBQVUsR0FBRyxLQUFLLENBQUM7UUFFeEIsSUFBSSxDQUFDLGVBQWUsR0FBRyxPQUFPLElBQUksT0FBTyxDQUFDLE9BQU8sQ0FBQztRQUVsRCxJQUFJLENBQUMsSUFBSSxDQUFDLGVBQWU7WUFBRSxPQUFPO1FBRWxDLElBQUksQ0FBQyxZQUFZLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxDQUFDO1FBRWhDLElBQUksQ0FBQyxtQkFBbUIsR0FBRyxFQUFFLE9BQU8sRUFBRSxPQUFPLENBQUMsS0FBSyxJQUFJLElBQUksQ0FBQyxrQkFBa0IsRUFBRSxDQUFDO1FBQ2pGLElBQUksQ0FBQyxZQUFZLEdBQUcsSUFBSSxDQUFDLGlCQUFpQixDQUFDLGVBQWUsQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLENBQUM7UUFFeEUsSUFBSSxDQUFDLGdCQUFnQixDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsQ0FBQztJQUN2QyxDQUFDO0lBRU8sZ0JBQWdCLENBQUMsVUFBcUU7UUFDMUYsSUFBSSxVQUFVLElBQUksVUFBVSxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxLQUFLLEVBQUU7WUFDbEQsSUFBSSxDQUFDLGdCQUFnQixHQUFHLGlCQUFpQixDQUFDO1lBQzFDLElBQUksQ0FBQyxZQUFZLENBQUMsTUFBTSxHQUFHLGlCQUFpQixDQUFDO1NBQ2hEO2FBQU07WUFDSCxJQUFJLENBQUMsZ0JBQWdCLEdBQUcsZUFBZSxDQUFDO1lBQ3hDLElBQUksQ0FBQyxZQUFZLENBQUMsTUFBTSxHQUFHLGVBQWUsQ0FBQztTQUM5QztJQUNMLENBQUM7SUFFTyxZQUFZLENBQUMsS0FBa0I7UUFDbkMsSUFBSSxPQUFPLEdBQUcsSUFBSSxDQUFDLGlCQUFpQixDQUFDLG1CQUFtQixDQUFDLGNBQWMsQ0FBQyxDQUFDO1FBRXpFLDhFQUE4RTtRQUM5RSxJQUFJLElBQUksQ0FBQyxHQUFHLElBQUksSUFBSSxDQUFDLEdBQUcsQ0FBQyxjQUFjLENBQUMscUJBQXFCLENBQUMsRUFBRTtZQUM1RCxPQUFPLEdBQUcsSUFBSSxDQUFDLGlCQUFpQixDQUFDLGtCQUFrQixDQUFDLE9BQU8sRUFBRSxJQUFJLENBQUMsR0FBRyxDQUFDLG1CQUFtQixDQUFDLENBQUM7U0FDOUY7UUFFRCxJQUFJLENBQUMsUUFBUSxHQUFHLE9BQU8sQ0FBQyxNQUFNLENBQUMsS0FBSyxJQUFJLEVBQUUsQ0FBQyxDQUFDO1FBQzVDLElBQUksQ0FBQyxJQUFJLENBQUMsT0FBTztZQUFFLElBQUksQ0FBQyxRQUFRLEdBQUcsSUFBSSxDQUFDLFFBQVEsQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxJQUFJLENBQUMsRUFBRSxLQUFLLFVBQVUsSUFBSSxJQUFJLENBQUMsRUFBRSxLQUFLLE9BQU8sQ0FBQyxDQUFDO1FBQy9HLElBQUksQ0FBQyxjQUFjLEdBQUcsSUFBSSxDQUFDLFFBQVEsQ0FBQztJQUN4QyxDQUFDO0lBRUQsd0ZBQXdGO0lBRWhGLFFBQVE7UUFDWixJQUFJLENBQUMsSUFBSSxDQUFDLEdBQUc7WUFBRSxPQUFPO1FBRXRCLElBQUksQ0FBQyxHQUFHLENBQUMsV0FBVyxHQUFHLENBQUMsWUFBeUIsRUFBUSxFQUFFO1lBQ3ZELElBQUksQ0FBQyxRQUFRLEdBQUcsSUFBSSxDQUFDLFFBQVEsQ0FBQyxNQUFNLENBQUMsWUFBWSxDQUFDLENBQUM7WUFDbkQsSUFBSSxDQUFDLEdBQUcsQ0FBQyxhQUFhLEVBQUUsQ0FBQztRQUM3QixDQUFDLENBQUM7UUFDRixJQUFJLENBQUMsR0FBRyxDQUFDLGdCQUFnQixHQUFHLENBQUMsR0FBVyxFQUFFLFVBQW1CLElBQUksRUFBUSxFQUFFO1lBQ3ZFLElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxxQkFBcUIsQ0FBQyxJQUFJLEVBQUUsR0FBRyxFQUFFLE9BQU8sRUFBRSxJQUFJLENBQUMsUUFBUSxDQUFDLENBQUM7WUFDaEYsSUFBSSxDQUFDLEdBQUcsQ0FBQyxhQUFhLEVBQUUsQ0FBQztRQUM3QixDQUFDLENBQUM7UUFDRixJQUFJLENBQUMsR0FBRyxDQUFDLG9CQUFvQixHQUFHLENBQUMsT0FBZSxFQUFFLFVBQW1CLElBQUksRUFBUSxFQUFFO1lBQy9FLElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxxQkFBcUIsQ0FBQyxRQUFRLEVBQUUsT0FBTyxFQUFFLE9BQU8sRUFBRSxJQUFJLENBQUMsUUFBUSxDQUFDLENBQUM7WUFDeEYsSUFBSSxDQUFDLEdBQUcsQ0FBQyxhQUFhLEVBQUUsQ0FBQztRQUM3QixDQUFDLENBQUM7UUFDRixJQUFJLENBQUMsR0FBRyxDQUFDLFVBQVUsR0FBRyxDQUFDLE1BQWUsRUFBRSxRQUFtQixFQUFFLHFCQUErQixFQUFzQixFQUFFO1lBQ2hILE9BQU8sSUFBSSxVQUFVLENBQVMsQ0FBQyxTQUEyQixFQUFFLEVBQUU7Z0JBQzFELElBQUksYUFBYSxHQUFXLEVBQUUsQ0FBQztnQkFDL0IsSUFBSSxNQUFNLEVBQUU7b0JBQ1IsYUFBYSxHQUFHLE1BQU0sQ0FBQyxNQUFNLENBQUMsRUFBRSxFQUFFLElBQUksQ0FBQyxtQkFBbUIsQ0FBQyxDQUFDO29CQUM1RCxJQUFJLENBQUMsbUJBQW1CLEdBQUcsTUFBTSxDQUFDO2lCQUNyQztnQkFDRCxJQUFJLENBQUMsZ0JBQWdCLENBQUMsVUFBVSxFQUFFLFFBQVEsRUFBRSxxQkFBcUIsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxDQUFDLFNBQVMsRUFBRSxFQUFFO29CQUN2RixJQUFHLE1BQU07d0JBQUUsSUFBSSxDQUFDLG1CQUFtQixHQUFHLGFBQWEsQ0FBQztvQkFDcEQsU0FBUyxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsQ0FBQztvQkFDMUIsU0FBUyxDQUFDLFFBQVEsRUFBRSxDQUFDO2dCQUN6QixDQUFDLENBQUMsQ0FBQztZQUNQLENBQUMsQ0FBQyxDQUFDO1FBQ1AsQ0FBQyxDQUFDO1FBRUYsSUFBSSxDQUFDLEdBQUcsQ0FBQyxXQUFXLEdBQUcsQ0FBQyxVQUFtQixFQUFFLE9BQW1CLEVBQVEsRUFBRTtZQUN0RSxPQUFPLENBQUMsTUFBTSxHQUFHLE1BQU0sQ0FBQyxNQUFNLENBQUMsRUFBRSxFQUFFLElBQUksQ0FBQyxPQUFPLENBQUMsTUFBTSxFQUFFLE9BQU8sQ0FBQyxNQUFNLENBQUMsQ0FBQztZQUN4RSxJQUFJLENBQUMsT0FBTyxHQUFHLE1BQU0sQ0FBQyxNQUFNLENBQUMsRUFBRSxFQUFFLE9BQU8sQ0FBQyxDQUFDO1lBQzFDLElBQUksQ0FBQyxpQkFBaUIsR0FBRyxJQUFJLENBQUMsaUJBQWlCLENBQUMsYUFBYSxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsQ0FBQztZQUM5RSxJQUFJLFVBQVUsRUFBRTtnQkFDWixJQUFJLENBQUMsVUFBVSxHQUFHLElBQUksQ0FBQyxZQUFZLENBQUM7Z0JBQ3BDLElBQUksSUFBSSxDQUFDLFlBQVksS0FBSyxPQUFPLEVBQUU7b0JBQy9CLElBQUksQ0FBQyxZQUFZLEdBQUcsT0FBTyxDQUFDO29CQUM1QixJQUFJLENBQUMsWUFBWSxDQUFDLFlBQVksQ0FBQyxDQUFDO2lCQUNuQztnQkFFRCxJQUFJLENBQUMsZUFBZSxHQUFHLEtBQUssQ0FBQzthQUNoQztpQkFBTTtnQkFDSCxJQUFJLENBQUMsZUFBZSxHQUFHLE9BQU8sSUFBSSxDQUFDLE1BQU0sS0FBSyxXQUFXLElBQUksSUFBSSxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDO2dCQUN4RixJQUFJLENBQUMsaUJBQWlCLENBQUMsZUFBZSxDQUFDLE9BQU8sQ0FBQyxDQUFDO2dCQUNoRCxJQUFJLENBQUMsWUFBWSxHQUFHLElBQUksQ0FBQyxVQUFVLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQzthQUNuRTtRQUNMLENBQUMsQ0FBQTtJQUNMLENBQUM7SUFFRCxvRkFBb0Y7SUFFN0UsVUFBVSxDQUFDLEtBQVc7UUFDekIsSUFBSSxhQUFhLEdBQVksS0FBSyxJQUFJLEtBQUssQ0FBQyxTQUFTLENBQUM7UUFDdEQsSUFBSSxZQUFZLEdBQVksS0FBSyxJQUFJLEtBQUssQ0FBQyxRQUFRLENBQUM7UUFFcEQsSUFBSSxhQUFhO1lBQUUsSUFBSSxDQUFDLFlBQVksQ0FBQyxLQUFLLENBQUMsU0FBUyxDQUFDLENBQUM7UUFDdEQsSUFBSSxZQUFZO1lBQUUsS0FBSyxDQUFDLFFBQVEsRUFBRSxDQUFDO1FBRW5DLElBQUksQ0FBQyxlQUFlLENBQUMsSUFBSSxDQUFDLFFBQVEsRUFBRSxLQUFLLEVBQUUsYUFBYSxJQUFJLFlBQVksQ0FBQyxDQUFDO1FBRTFFLElBQUksQ0FBQyxnQkFBZ0IsR0FBRyxJQUFJLENBQUMsWUFBWSxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsQ0FBQztRQUV6RCxJQUFJLENBQUMsVUFBVSxHQUFHLElBQUksQ0FBQyxRQUFRLEtBQUssUUFBUSxJQUFJLElBQUksQ0FBQyxRQUFRLEtBQUssVUFBVSxDQUFDO0lBQ2pGLENBQUM7SUFFTyxlQUFlLENBQUMsS0FBYSxFQUFFLEtBQVcsRUFBRSxZQUFzQjtRQUN0RSxRQUFRLEtBQUssRUFBRTtZQUNYLEtBQUssUUFBUSxDQUFDO1lBQ2Q7Z0JBQ0ksSUFBSSxDQUFDLFFBQVEsR0FBRyxRQUFRLENBQUM7Z0JBQ3pCLE1BQU07WUFDVixLQUFLLFFBQVE7Z0JBQ1QsSUFBSSxRQUFRLEdBQVksS0FBSyxJQUFJLEtBQUssQ0FBQyxRQUFRLENBQUM7Z0JBQ2hELElBQUksUUFBUSxFQUFFO29CQUNWLElBQUksQ0FBQyxjQUFjLEdBQUcsS0FBSyxDQUFDLFFBQVEsQ0FBQztvQkFDckMsSUFBSSxDQUFDLFFBQVEsR0FBRyxVQUFVLENBQUM7b0JBQzNCLE9BQU87aUJBQ1Y7Z0JBQ0QsSUFBSSxNQUFNLEdBQVksS0FBSyxDQUFDO2dCQUM1QixJQUFJLEtBQUssSUFBSSxLQUFLLENBQUMsY0FBYyxDQUFDLFdBQVcsQ0FBQyxFQUFFO29CQUM1QyxNQUFNLEdBQUcsS0FBSyxJQUFJLEtBQUssQ0FBQyxTQUFTLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDO29CQUN2RCxJQUFJLE1BQU07d0JBQUUsSUFBSSxDQUFDLFlBQVksR0FBRyxLQUFLLENBQUMsU0FBUyxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztpQkFDakU7Z0JBQ0QsSUFBSSxDQUFDLFFBQVEsR0FBRyxNQUFNLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDO2dCQUM3QyxNQUFNO1lBQ1YsS0FBSyxVQUFVO2dCQUNYLElBQUksQ0FBQyxRQUFRLEdBQUcsWUFBWSxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQztnQkFDbkQsSUFBSSxDQUFDLGNBQWMsR0FBRyxJQUFJLENBQUMsUUFBUSxDQUFDO2dCQUNwQyxNQUFNO1lBQ1YsS0FBSyxRQUFRO2dCQUNULElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxlQUFlLENBQUMsT0FBTyxDQUFDLENBQUM7Z0JBQ2hELElBQUksQ0FBQyxRQUFRLEdBQUcsUUFBUSxDQUFDO2dCQUN6QixJQUFJLENBQUMsWUFBWSxHQUFHLE9BQU8sQ0FBQztnQkFDNUIsTUFBTTtTQUNiO0lBQ0wsQ0FBQztJQUVPLFlBQVksQ0FBQyxVQUFrQjtRQUVuQyxnQ0FBZ0M7UUFDaEMsSUFBSSxZQUFZLEdBQUcsVUFBVSxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FBQztRQUV6QyxJQUFJLFlBQVksQ0FBQyxDQUFDLENBQUMsS0FBSyxNQUFNLElBQUksWUFBWSxDQUFDLENBQUMsQ0FBQyxLQUFLLE9BQU8sRUFBRTtZQUMzRCxJQUFJLENBQUMsaUJBQWlCLENBQUMsZ0JBQWdCLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsQ0FBQztZQUM3RCxPQUFPO1NBQ1Y7UUFFRCxJQUFJLFlBQVksQ0FBQyxDQUFDLENBQUMsS0FBSyxRQUFRO1lBQUUsT0FBTztRQUV6QyxJQUFJLElBQUksQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLElBQUk7WUFBRSxJQUFJLENBQUMsU0FBUyxHQUFHLElBQUksQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsS0FBSyxFQUFFLEdBQUcsQ0FBQyxDQUFDO1FBRXhGLElBQUksWUFBWSxDQUFDLENBQUMsQ0FBQyxLQUFLLE9BQU8sRUFBRTtZQUM3QixJQUFJLENBQUMsV0FBVyxHQUFHLElBQUksQ0FBQztTQUMzQjthQUFNO1lBQ0gsSUFBSSxDQUFDLGdCQUFnQixDQUFDLFlBQVksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxHQUFFLEVBQUUsR0FBQyxDQUFDLENBQUMsQ0FBQztTQUM1RDtJQUNMLENBQUM7SUFFTyxnQkFBZ0IsQ0FBQyxVQUFrQixFQUFFLFdBQXFCLEVBQUUsRUFBRSx3QkFBaUMsSUFBSTtRQUN2RyxPQUFPLElBQUksVUFBVSxDQUFTLENBQUMsU0FBMkIsRUFBRSxFQUFFO1lBQzFELElBQUksQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLGtCQUFrQixFQUFFLEVBQUU7Z0JBQ3BDLElBQUksQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsZUFBZSxDQUFDLFVBQVUsQ0FBQyxDQUFDLENBQUM7Z0JBQzdELFNBQVMsQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxlQUFlLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQztnQkFDMUQsU0FBUyxDQUFDLFFBQVEsRUFBRSxDQUFDO2FBQ3hCO2lCQUFNO2dCQUNILGlFQUFpRTtnQkFDakUsSUFBSSxDQUFDLHVCQUF1QixHQUFHLE1BQU0sQ0FBQyxNQUFNLENBQUMsRUFBRSxFQUFFLElBQUksQ0FBQyxNQUFNLEVBQUUsRUFBRSxFQUFFLEVBQUUsY0FBYyxFQUFFLFNBQVMsRUFBRSxLQUFLLEVBQUUsV0FBVyxFQUFFLElBQUksRUFBRSxDQUFDLENBQUM7Z0JBQzNILElBQUksQ0FBQyxTQUFTLEdBQUcsSUFBSSxDQUFDO2dCQUV0Qiw0Q0FBNEM7Z0JBQzVDLFVBQVUsQ0FBQyxHQUFHLEVBQUU7b0JBQ1osdUZBQXVGO29CQUN2RixJQUFJLENBQUMsY0FBYyxDQUFDLGFBQWEsQ0FBQyxJQUFJLENBQUMsc0JBQXNCLENBQUMsQ0FBQztvQkFDL0QsZ0RBQWdEO29CQUNoRCxJQUFJLENBQUMscUJBQXFCLEdBQUcsSUFBSSxDQUFDLGdCQUFnQixDQUFDO2dCQUN2RCxDQUFDLENBQUMsQ0FBQztnQkFFSCxJQUFJLE9BQU8sR0FBYSxNQUFNLENBQUMsTUFBTSxDQUFDLEVBQUUsRUFBRSxRQUFRLENBQUMsQ0FBQztnQkFDcEQsSUFBSSxJQUFJLENBQUMsU0FBUztvQkFBRSxPQUFPLENBQUMsVUFBVSxDQUFDLEdBQUcsSUFBSSxDQUFDLFNBQVMsQ0FBQztnQkFFekQsVUFBVSxDQUFDLEdBQUcsRUFBRTtvQkFDWixJQUFJLFlBQVksR0FBRyxJQUFJLENBQUMsUUFBUSxDQUFDLGFBQWEsQ0FBQyxhQUFhLENBQUMsR0FBRyxHQUFHLElBQUksQ0FBQyxtQkFBbUIsR0FBRyxhQUFhLENBQUMsQ0FBQztvQkFFN0csaURBQWlEO29CQUNqRCxJQUFJLENBQUMsaUJBQWlCLENBQUMsV0FBVyxDQUFDLFlBQVksQ0FBQyxDQUFDO29CQUNqRCxJQUFJLHFCQUFxQjt3QkFBRSxJQUFJLENBQUMsaUJBQWlCLENBQUMsa0JBQWtCLENBQUMsWUFBWSxDQUFDLENBQUM7b0JBQ25GLFlBQVksQ0FBQyxLQUFLLENBQUMsTUFBTSxHQUFHLE1BQU0sQ0FBQztvQkFFbkMsT0FBTyxDQUFDLE9BQU8sQ0FBQyxHQUFHLFlBQVksQ0FBQyxxQkFBcUIsRUFBRSxDQUFDLEtBQUssR0FBRyxDQUFDLENBQUM7b0JBQ2xFLE9BQU8sQ0FBQyxRQUFRLENBQUMsR0FBRyxZQUFZLENBQUMscUJBQXFCLEVBQUUsQ0FBQyxNQUFNLEdBQUcsQ0FBQyxDQUFDO29CQUVwRSxJQUFJLE1BQU0sR0FBRyxJQUFJLENBQUMsT0FBTyxDQUFDLGFBQWEsQ0FBQyxZQUFZLEVBQUUsVUFBVSxFQUFFLE9BQU8sQ0FBQyxDQUFDO29CQUUzRSwyREFBMkQ7b0JBQzNELElBQUksQ0FBQyxTQUFTLEdBQUcsS0FBSyxDQUFDO29CQUN2QixJQUFJLENBQUMscUJBQXFCLEdBQUcsSUFBSSxDQUFDO29CQUVsQyxJQUFJLE1BQU0sRUFBRTt3QkFDUixNQUFNLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxFQUFFOzRCQUNsQixTQUFTLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxDQUFDOzRCQUN4QixTQUFTLENBQUMsUUFBUSxFQUFFLENBQUM7d0JBQ3pCLENBQUMsQ0FBQyxDQUFBO3FCQUNMO3lCQUFNO3dCQUNILFNBQVMsQ0FBQyxRQUFRLEVBQUUsQ0FBQztxQkFDeEI7Z0JBQ0wsQ0FBQyxFQUFFLElBQUksQ0FBQyxjQUFjLENBQUMsQ0FBQzthQUMzQjtRQUNMLENBQUMsQ0FBQyxDQUFDO0lBRVAsQ0FBQzs7O1lBNVVKLFNBQVMsU0FBQztnQkFDUCxRQUFRLEVBQUUsa0JBQWtCO2dCQUM1Qiw0N0VBQTRDO2dCQUM1QyxhQUFhLEVBQUUsaUJBQWlCLENBQUMsSUFBSTtnQkFDckMsU0FBUyxFQUFFLENBQUMsa0JBQWtCLEVBQUUsWUFBWSxDQUFDO2dCQUM3QyxJQUFJLEVBQUU7b0JBQ0YsT0FBTyxFQUFFLG1CQUFtQjtpQkFDL0I7Z0JBQ0QsVUFBVSxFQUFFO29CQUNSLE9BQU8sQ0FBQyxVQUFVLEVBQUU7d0JBQ2hCLFVBQVUsQ0FBQyxRQUFRLEVBQUU7NEJBQ2pCLEtBQUssQ0FBQyxFQUFFLFNBQVMsRUFBRSxrQkFBa0IsRUFBRSxDQUFDOzRCQUN4QyxPQUFPLENBQUMsbUJBQW1CLENBQUM7eUJBQy9CLENBQUM7cUJBQ0wsQ0FBQztpQkFDTDthQUNKOzs7WUE3QkcsVUFBVTtZQVFMLGtCQUFrQjtZQVB2QixpQkFBaUI7OzttQkEwRWhCLEtBQUssU0FBQyxNQUFNO3NCQUNaLEtBQUssU0FBQyxTQUFTO3FCQUNmLEtBQUssU0FBQyxRQUFRO3lCQUNkLEtBQUs7OEJBQ0wsS0FBSztrQkFDTCxLQUFLOytCQUNMLE1BQU07dUJBQ04sTUFBTTt5QkFDTixNQUFNOzZCQUVOLFNBQVMsU0FBQyxnQkFBZ0IiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQge1xyXG4gICAgQ29tcG9uZW50LFxyXG4gICAgVmlld0VuY2Fwc3VsYXRpb24sXHJcbiAgICBJbnB1dCxcclxuICAgIE9uSW5pdCxcclxuICAgIE91dHB1dCxcclxuICAgIE9uQ2hhbmdlcyxcclxuICAgIFNpbXBsZUNoYW5nZXMsXHJcbiAgICBFdmVudEVtaXR0ZXIsXHJcbiAgICBFbGVtZW50UmVmLFxyXG4gICAgQ2hhbmdlRGV0ZWN0b3JSZWYsXHJcbiAgICBWaWV3Q2hpbGRcclxufSBmcm9tICdAYW5ndWxhci9jb3JlJztcclxuaW1wb3J0IHsgT2JzZXJ2YWJsZSwgT2JzZXJ2ZXIgfSBmcm9tICdyeGpzJztcclxuaW1wb3J0IHsgdHJpZ2dlciwgc3R5bGUsIHRyYW5zaXRpb24sIGFuaW1hdGUgfSBmcm9tICdAYW5ndWxhci9hbmltYXRpb25zJztcclxuaW1wb3J0IHsgZGVmYXVsdE1lbnVBcnIsIElPcHRpb25zLCBJVGFibGVEYXRhLCBJVGFibGVDb2x1bW4gfSBmcm9tICcuL2tkLWFuZ3VsYXItdmlzdWFsaXphdGlvbi1pbnRlcmZhY2UnO1xyXG5pbXBvcnQgeyBJQ2hhcnRFeHBvcnQsIElEM0RhdGEsIElDaGFydENvbmZpZywgSU1lbnVJdGVtLCBJTGVnZW5kRGF0YSwgSUNoYXJ0RGF0YSB9IGZyb20gJy4uL2tkLWFuZ3VsYXItY2hhcnRzL2tkLWFuZ3VsYXItY2hhcnRzLWludGVyZmFjZSc7XHJcbmltcG9ydCB7IEtkVmlzdWFsaXphdGlvblN2YyB9IGZyb20gJy4va2QtYW5ndWxhci12aXN1YWxpemF0aW9uLXN2Yyc7XHJcbmltcG9ydCB7IEtkVmlzdWFsaXphdGlvbkV4cG9ydCB9IGZyb20gJy4va2QtYW5ndWxhci12aXN1YWxpemF0aW9uLWV4cG9ydCc7XHJcbmltcG9ydCB7IEtkRG9tRWxlbVN2YyB9IGZyb20gJy4uL2tkLWNvbW1vbi9pbmRleCc7XHJcbmltcG9ydCB7IEtkQ2hhcnRzIH0gZnJvbSAnLi4va2QtYW5ndWxhci1jaGFydHMvaW5kZXgnO1xyXG5cclxuQENvbXBvbmVudCh7XHJcbiAgICBzZWxlY3RvcjogJ2tkLXZpc3VhbGl6YXRpb24nLFxyXG4gICAgdGVtcGxhdGVVcmw6ICdrZC1hbmd1bGFyLXZpc3VhbGl6YXRpb24uaHRtbCcsXHJcbiAgICBlbmNhcHN1bGF0aW9uOiBWaWV3RW5jYXBzdWxhdGlvbi5Ob25lLFxyXG4gICAgcHJvdmlkZXJzOiBbS2RWaXN1YWxpemF0aW9uU3ZjLCBLZERvbUVsZW1TdmNdLFxyXG4gICAgaG9zdDoge1xyXG4gICAgICAgICdjbGFzcyc6ICdrZHgtdmlzdWFsaXphdGlvbicsXHJcbiAgICB9LFxyXG4gICAgYW5pbWF0aW9uczogW1xyXG4gICAgICAgIHRyaWdnZXIoJ2l0ZW1BbmltJywgW1xyXG4gICAgICAgICAgICB0cmFuc2l0aW9uKCc6ZW50ZXInLCBbXHJcbiAgICAgICAgICAgICAgICBzdHlsZSh7IHRyYW5zZm9ybTogJ3RyYW5zbGF0ZVkoMTAwJSknIH0pLFxyXG4gICAgICAgICAgICAgICAgYW5pbWF0ZSgnMC4ycyAwLjJzIGVhc2UtaW4nKVxyXG4gICAgICAgICAgICBdKSxcclxuICAgICAgICBdKVxyXG4gICAgXVxyXG59KVxyXG5cclxuZXhwb3J0IGNsYXNzIEtkVmlzdWFsaXphdGlvbiBpbXBsZW1lbnRzIE9uSW5pdCwgT25DaGFuZ2VzIHtcclxuICAgIC8qIG1lbnUgKi9cclxuICAgIHB1YmxpYyBpc0V4cG9ydEVuYWJsZWQ6IGJvb2xlYW4gPSBmYWxzZTtcclxuICAgIHB1YmxpYyBpc01lbnVPcGVuOiBib29sZWFuID0gZmFsc2U7XHJcbiAgICBwdWJsaWMgbWVudUZsYWc6ICdvcGVuZWQnIHwgJ2Nsb3NlZCcgfCAnZXhwYW5kZWQnIHwgJ3ZpZXdlZCcgPSAnY2xvc2VkJzsgLy8gY2FuIGJlICdvcGVuZWQnIHwgJ2Nsb3NlZCcgfCAnZXhwYW5kZWQnIHwgJ3ZpZXdlZCdcclxuICAgIHB1YmxpYyBtZW51RGlzcGxheUFyciA9IFtdO1xyXG4gICAgcHJpdmF0ZSBfbWVudUFycjogSU1lbnVJdGVtW10gPSBbXTtcclxuXHJcbiAgICAvKiBtZW51IGJ0biB2YXJpYWJsZXMgKi9cclxuICAgIHB1YmxpYyBidG5BbGlnbm1lbnQ6IHN0cmluZztcclxuICAgIHB1YmxpYyBtZW51QnRuSWNvbkNsYXNzOiBzdHJpbmcgPSAnZmEtY2hldnJvbi11cCc7XHJcbiAgICBwcml2YXRlIF9tZW51QnRuTGlzdDogeyBjbG9zZWQ6IHN0cmluZywgb3BlbmVkOiBzdHJpbmcsIGV4cGFuZGVkOiBzdHJpbmcsIHZpZXdlZDogc3RyaW5nIH0gPSB7XHJcbiAgICAgICAgY2xvc2VkOiAnZmEtY2hldnJvbi11cCcsXHJcbiAgICAgICAgb3BlbmVkOiAnZmEtY2xvc2UnLFxyXG4gICAgICAgIHZpZXdlZDogJ2ZhLWNsb3NlJyxcclxuICAgICAgICBleHBhbmRlZDogJ2ZhLWNoZXZyb24tbGVmdCdcclxuICAgIH07XHJcblxyXG4gICAgLyogaW52aXNpYmxlIGNoYXJ0ICovXHJcbiAgICBwdWJsaWMgZXhwb3J0Tm93OiBib29sZWFuID0gZmFsc2U7XHJcbiAgICAvKiBpbml0aWFsIGxvYWQgb2YgaW52aXNpYmxlIGNoYXJ0IHNob3VsZCBub3Qgc3RhcnQgZHJhd2luZy4gbmVlZCB0byB3YWl0IGZvciBzZXRMZWdlbmREYXRhLCB0aGVuIGRyYXcgaW4gb25lIGdvICovXHJcbiAgICBwdWJsaWMgZGF0YUZvckludmlzaWJsZUNoYXJ0OiBJRDNEYXRhID0gbnVsbDtcclxuICAgIHB1YmxpYyBjb25maWdGb3JJbnZpc2libGVjaGFydDogSUNoYXJ0Q29uZmlnID0gbnVsbDtcclxuICAgIHB1YmxpYyBkYXRhQWZ0ZXJNYXNzYWdlOiBJRDNEYXRhO1xyXG4gICAgcHVibGljIGxlZ2VuZERhdGFBZnRlck1hc3NhZ2U6IGFueTtcclxuICAgIHB1YmxpYyBpbnZpc2libGVDaGFydFN0eWxlOiBvYmplY3Q7XHJcbiAgICBwdWJsaWMgaW52aXNpYmxlQ2hhcnRDbGFzczogc3RyaW5nID0gJ2tkeC12aXN1YWxpemF0aW9uLWNoYXJ0LWludmlzaWJsZSc7XHJcbiAgICBwcml2YXRlIF9kZWZhdWx0Q2hhcnRXaWR0aDogc3RyaW5nID0gJzEwMjRweCc7XHJcblxyXG4gICAgLyogdmlldyAqL1xyXG4gICAgcHVibGljIGNvbnRlbnRTdGF0ZTogc3RyaW5nID0gJ2NoYXJ0JzsgLy8gY3VycmVudGx5IG9ubHkgaGF2ZSBjaGFydCB8IHRhYmxlXHJcbiAgICBwdWJsaWMgY29sdW1uQWZ0ZXJGaWx0ZXI6IElUYWJsZUNvbHVtbltdO1xyXG4gICAgcHVibGljIGV4cG9ydFRhYmxlOiBib29sZWFuID0gZmFsc2U7XHJcbiAgICBwcml2YXRlIF9maWxlTmFtZTogc3RyaW5nO1xyXG5cclxuICAgIHByaXZhdGUgX3RlbXBTdGF0ZTogc3RyaW5nO1xyXG5cclxuICAgIC8qKlxyXG4gICAgICogRXhwb3J0IENsYXNzXHJcbiAgICAgKiBcclxuICAgICAqL1xyXG4gICAgcHJpdmF0ZSBfZXhwb3J0OiBLZFZpc3VhbGl6YXRpb25FeHBvcnQ7XHJcbiAgICBwcml2YXRlIF90aW1lb3V0VGltaW5nOiBudW1iZXIgPSAxMDAwO1xyXG5cclxuICAgIEBJbnB1dCgnZGF0YScpIGRhdGE6IElDaGFydERhdGE7XHJcbiAgICBASW5wdXQoJ3Jhd0RhdGEnKSByYXdEYXRhOiBJVGFibGVEYXRhO1xyXG4gICAgQElucHV0KCdjb25maWcnKSBjb25maWc6IElDaGFydENvbmZpZztcclxuICAgIEBJbnB1dCgpIHhUaHJlc2hvbGQ6IG51bWJlcjtcclxuICAgIEBJbnB1dCgpIHNlcmllc1RocmVzaG9sZDogbnVtYmVyO1xyXG4gICAgQElucHV0KCkgYXBpOiBhbnk7XHJcbiAgICBAT3V0cHV0KCkgb3V0cHV0TGVnZW5kRGF0YTogRXZlbnRFbWl0dGVyPHsgW2tleTogc3RyaW5nXTogSUxlZ2VuZERhdGEgfT4gPSBuZXcgRXZlbnRFbWl0dGVyKCk7XHJcbiAgICBAT3V0cHV0KCkgZXJyb3JNc2c6IEV2ZW50RW1pdHRlcjxzdHJpbmc+ID0gbmV3IEV2ZW50RW1pdHRlcigpO1xyXG4gICAgQE91dHB1dCgpIG91dHB1dEFyZWE6IEV2ZW50RW1pdHRlcjxJRDNEYXRhPiA9IG5ldyBFdmVudEVtaXR0ZXIoKTtcclxuXHJcbiAgICBAVmlld0NoaWxkKCdpbnZpc2libGVDaGFydCcpIGludmlzaWJsZUNoYXJ0OiBLZENoYXJ0cztcclxuXHJcbiAgICBjb25zdHJ1Y3RvcihcclxuICAgICAgICBwcml2YXRlIF9lbGVtUmVmOiBFbGVtZW50UmVmLFxyXG4gICAgICAgIHByaXZhdGUgX3Zpc3VhbGl6YXRpb25TdmM6IEtkVmlzdWFsaXphdGlvblN2YyxcclxuICAgICAgICBwcml2YXRlIGNkcjogQ2hhbmdlRGV0ZWN0b3JSZWZcclxuICAgICkge1xyXG4gICAgICAgIHRoaXMuX2V4cG9ydCA9IG5ldyBLZFZpc3VhbGl6YXRpb25FeHBvcnQoKTtcclxuICAgICAgICB0aGlzLl92aXN1YWxpemF0aW9uU3ZjLnZpc3VhbGl6YXRpb25FbGVtID0gdGhpcy5fZWxlbVJlZi5uYXRpdmVFbGVtZW50O1xyXG4gICAgfVxyXG5cclxuICAgIG5nT25Jbml0KCk6IHZvaWQge1xyXG4gICAgICAgIHRoaXMuX2luaXRBcGkoKTtcclxuICAgIH1cclxuXHJcbiAgICBuZ09uQ2hhbmdlcyhfc2ltcGxlQ2hhbmdlczogU2ltcGxlQ2hhbmdlcyk6IHZvaWQge1xyXG4gICAgICAgIGlmIChfc2ltcGxlQ2hhbmdlcy5oYXNPd25Qcm9wZXJ0eSgnY29uZmlnJykgJiYgX3NpbXBsZUNoYW5nZXMuY29uZmlnLmN1cnJlbnRWYWx1ZSkge1xyXG4gICAgICAgICAgICB0aGlzLl9zZXRDb25maWcoX3NpbXBsZUNoYW5nZXMuY29uZmlnLmN1cnJlbnRWYWx1ZS5leHBvcnQpO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgaWYgKF9zaW1wbGVDaGFuZ2VzLmhhc093blByb3BlcnR5KCdyYXdEYXRhJykgJiYgX3NpbXBsZUNoYW5nZXMucmF3RGF0YS5jdXJyZW50VmFsdWUpIHtcclxuICAgICAgICAgICAgdGhpcy5jb2x1bW5BZnRlckZpbHRlciA9IHRoaXMuX3Zpc3VhbGl6YXRpb25TdmMuZmlsdGVyQ29sdW1ucyhfc2ltcGxlQ2hhbmdlcy5yYXdEYXRhLmN1cnJlbnRWYWx1ZS5jb2x1bW4pO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICBwdWJsaWMgZ2V0T3V0cHV0RGF0YShfZGF0YTogSUQzRGF0YSk6IHZvaWQge1xyXG4gICAgICAgIHRoaXMuZGF0YUFmdGVyTWFzc2FnZSA9IF9kYXRhO1xyXG4gICAgfVxyXG5cclxuICAgIHB1YmxpYyBnZXRPdXRwdXRMZWdlbmREYXRhKF9sZWdlbmREYXRhOiB7IFtrZXk6IHN0cmluZ106IElMZWdlbmREYXRhIH0pOiB2b2lkIHtcclxuICAgICAgICB0aGlzLm91dHB1dExlZ2VuZERhdGEuZW1pdChfbGVnZW5kRGF0YSk7XHJcbiAgICAgICAgdGhpcy5sZWdlbmREYXRhQWZ0ZXJNYXNzYWdlID0gX2xlZ2VuZERhdGE7XHJcbiAgICB9XHJcblxyXG4gICAgcHVibGljIHNldEFyZWEoX2RhdGEpOiB2b2lkIHtcclxuICAgICAgICB0aGlzLm91dHB1dEFyZWEuZW1pdChfZGF0YSk7XHJcbiAgICB9XHJcblxyXG4gICAgcHVibGljIG9uRXhwb3J0RXhjZWxQb3NzaWJsZSgpOiB2b2lkIHtcclxuICAgICAgICBpZiAodGhpcy5leHBvcnRUYWJsZSkge1xyXG4gICAgICAgICAgICB0aGlzLnJhd0RhdGEuYXBpLmdlbmVyYWwuZXhwb3J0VG9FeGNlbCh7IGZpbGVOYW1lOiB0aGlzLl9maWxlTmFtZSB9KTtcclxuICAgICAgICAgICAgdGhpcy5leHBvcnRUYWJsZSA9IGZhbHNlO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICAvLyA9PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT0gQ29uZmlnID09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT1cclxuXHJcbiAgICBwcml2YXRlIF9zZXRDb25maWcoX2NvbmZpZzogSUNoYXJ0RXhwb3J0KTogdm9pZCB7XHJcbiAgICAgICAgLy8gd2hlbmV2ZXIgY29uZmlnIGNoYW5nZXMsIHNldCBiYWNrIHRvIGRlZmF1bHQgdmFsdWVzXHJcbiAgICAgICAgdGhpcy5jb250ZW50U3RhdGUgPSAnY2hhcnQnO1xyXG4gICAgICAgIHRoaXMubWVudUZsYWcgPSAnY2xvc2VkJztcclxuICAgICAgICB0aGlzLmlzTWVudU9wZW4gPSBmYWxzZTtcclxuXHJcbiAgICAgICAgdGhpcy5pc0V4cG9ydEVuYWJsZWQgPSBfY29uZmlnICYmIF9jb25maWcuZW5hYmxlZDtcclxuXHJcbiAgICAgICAgaWYgKCF0aGlzLmlzRXhwb3J0RW5hYmxlZCkgcmV0dXJuO1xyXG5cclxuICAgICAgICB0aGlzLl9zZXRJbml0TWVudShfY29uZmlnLm1lbnUpO1xyXG5cclxuICAgICAgICB0aGlzLmludmlzaWJsZUNoYXJ0U3R5bGUgPSB7ICd3aWR0aCc6IF9jb25maWcud2lkdGggfHwgdGhpcy5fZGVmYXVsdENoYXJ0V2lkdGggfTtcclxuICAgICAgICB0aGlzLmJ0bkFsaWdubWVudCA9IHRoaXMuX3Zpc3VhbGl6YXRpb25TdmMuZ2V0QnRuQWxpZ25tZW50KF9jb25maWcuYnRuKTtcclxuXHJcbiAgICAgICAgdGhpcy5fc2V0SW5pdEJ0bkNsYXNzKF9jb25maWcuYnRuKTtcclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF9zZXRJbml0QnRuQ2xhc3MoX2J0bkNvbmZpZzogJ3RvcC1sZWZ0JyB8ICd0b3AtcmlnaHQnIHwgJ2JvdHRvbS1sZWZ0JyB8ICdib3R0b20tcmlnaHQnKTogdm9pZCB7XHJcbiAgICAgICAgaWYgKF9idG5Db25maWcgJiYgX2J0bkNvbmZpZy5zcGxpdCgnLScpWzBdID09PSAndG9wJykge1xyXG4gICAgICAgICAgICB0aGlzLm1lbnVCdG5JY29uQ2xhc3MgPSAnZmEtY2hldnJvbi1kb3duJztcclxuICAgICAgICAgICAgdGhpcy5fbWVudUJ0bkxpc3QuY2xvc2VkID0gJ2ZhLWNoZXZyb24tZG93bic7XHJcbiAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgdGhpcy5tZW51QnRuSWNvbkNsYXNzID0gJ2ZhLWNoZXZyb24tdXAnO1xyXG4gICAgICAgICAgICB0aGlzLl9tZW51QnRuTGlzdC5jbG9zZWQgPSAnZmEtY2hldnJvbi11cCc7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX3NldEluaXRNZW51KF9tZW51OiBJTWVudUl0ZW1bXSk6IHZvaWQge1xyXG4gICAgICAgIGxldCBtZW51QXJyID0gdGhpcy5fdmlzdWFsaXphdGlvblN2Yy5nZXRJbW11dGFibGVNZW51QXJyKGRlZmF1bHRNZW51QXJyKTtcclxuXHJcbiAgICAgICAgLy8gdHJhbnNsYXRpb25DYWxsYmFjayBzaG91bGQgdGFrZSBlbmdsaXNoIHN0cmluZyBhbmQgcmV0dXJuIHRyYW5zbGF0ZWQgc3RyaW5nXHJcbiAgICAgICAgaWYgKHRoaXMuYXBpICYmIHRoaXMuYXBpLmhhc093blByb3BlcnR5KCd0cmFuc2xhdGlvbkNhbGxiYWNrJykpIHtcclxuICAgICAgICAgICAgbWVudUFyciA9IHRoaXMuX3Zpc3VhbGl6YXRpb25TdmMuc2V0TWVudVRyYW5zbGF0aW9uKG1lbnVBcnIsIHRoaXMuYXBpLnRyYW5zbGF0aW9uQ2FsbGJhY2spO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgdGhpcy5fbWVudUFyciA9IG1lbnVBcnIuY29uY2F0KF9tZW51IHx8IFtdKTtcclxuICAgICAgICBpZiAoIXRoaXMucmF3RGF0YSkgdGhpcy5fbWVudUFyciA9IHRoaXMuX21lbnVBcnIuZmlsdGVyKGl0ZW0gPT4gaXRlbS5pZCAhPT0gJ3ZpZXdEYXRhJyAmJiBpdGVtLmlkICE9PSAnZXhjZWwnKTtcclxuICAgICAgICB0aGlzLm1lbnVEaXNwbGF5QXJyID0gdGhpcy5fbWVudUFycjtcclxuICAgIH1cclxuXHJcbiAgICAvLyA9PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT0gSU5JVCBBUEkgYW5kIFN1YiA9PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09XHJcblxyXG4gICAgcHJpdmF0ZSBfaW5pdEFwaSgpIHtcclxuICAgICAgICBpZiAoIXRoaXMuYXBpKSByZXR1cm47XHJcblxyXG4gICAgICAgIHRoaXMuYXBpLmFkZE1lbnVJdGVtID0gKF9tZW51SXRlbUFycjogSU1lbnVJdGVtW10pOiB2b2lkID0+IHtcclxuICAgICAgICAgICAgdGhpcy5fbWVudUFyciA9IHRoaXMuX21lbnVBcnIuY29uY2F0KF9tZW51SXRlbUFycik7XHJcbiAgICAgICAgICAgIHRoaXMuY2RyLmRldGVjdENoYW5nZXMoKTtcclxuICAgICAgICB9O1xyXG4gICAgICAgIHRoaXMuYXBpLmhpZGVNZW51SXRlbUJ5SWQgPSAoX2lkOiBzdHJpbmcsIF9pc0hpZGU6IGJvb2xlYW4gPSB0cnVlKTogdm9pZCA9PiB7XHJcbiAgICAgICAgICAgIHRoaXMuX3Zpc3VhbGl6YXRpb25TdmMuc2V0TWVudUl0ZW1WaXNpYmlsaXR5KCdpZCcsIF9pZCwgX2lzSGlkZSwgdGhpcy5fbWVudUFycik7XHJcbiAgICAgICAgICAgIHRoaXMuY2RyLmRldGVjdENoYW5nZXMoKTtcclxuICAgICAgICB9O1xyXG4gICAgICAgIHRoaXMuYXBpLmhpZGVNZW51SXRlbUJ5QWN0aW9uID0gKF9hY3Rpb246IHN0cmluZywgX2lzSGlkZTogYm9vbGVhbiA9IHRydWUpOiB2b2lkID0+IHtcclxuICAgICAgICAgICAgdGhpcy5fdmlzdWFsaXphdGlvblN2Yy5zZXRNZW51SXRlbVZpc2liaWxpdHkoJ2FjdGlvbicsIF9hY3Rpb24sIF9pc0hpZGUsIHRoaXMuX21lbnVBcnIpO1xyXG4gICAgICAgICAgICB0aGlzLmNkci5kZXRlY3RDaGFuZ2VzKCk7XHJcbiAgICAgICAgfTtcclxuICAgICAgICB0aGlzLmFwaS5nZXREYXRhVXJsID0gKF9zdHlsZT86IG9iamVjdCwgX29wdGlvbnM/OiBJT3B0aW9ucywgX2lzUmVtb3ZlTGVnZW5kU2Nyb2xsPzogYm9vbGVhbik6IE9ic2VydmFibGU8c3RyaW5nPiA9PiB7XHJcbiAgICAgICAgICAgIHJldHVybiBuZXcgT2JzZXJ2YWJsZTxzdHJpbmc+KChfb2JzZXJ2ZXI6IE9ic2VydmVyPHN0cmluZz4pID0+IHtcclxuICAgICAgICAgICAgICAgIGxldCBvcmlnaW5hbFN0eWxlOiBvYmplY3QgPSB7fTtcclxuICAgICAgICAgICAgICAgIGlmIChfc3R5bGUpIHtcclxuICAgICAgICAgICAgICAgICAgICBvcmlnaW5hbFN0eWxlID0gT2JqZWN0LmFzc2lnbih7fSwgdGhpcy5pbnZpc2libGVDaGFydFN0eWxlKTtcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLmludmlzaWJsZUNoYXJ0U3R5bGUgPSBfc3R5bGU7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICB0aGlzLl9wcmVwRXhwb3J0Q2hhcnQoJ2ltYWdlVXJsJywgX29wdGlvbnMsIF9pc1JlbW92ZUxlZ2VuZFNjcm9sbCkuc3Vic2NyaWJlKChfcmVzcG9uc2UpID0+IHtcclxuICAgICAgICAgICAgICAgICAgICBpZihfc3R5bGUpIHRoaXMuaW52aXNpYmxlQ2hhcnRTdHlsZSA9IG9yaWdpbmFsU3R5bGU7XHJcbiAgICAgICAgICAgICAgICAgICAgX29ic2VydmVyLm5leHQoX3Jlc3BvbnNlKTtcclxuICAgICAgICAgICAgICAgICAgICBfb2JzZXJ2ZXIuY29tcGxldGUoKTtcclxuICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICB9KTtcclxuICAgICAgICB9O1xyXG5cclxuICAgICAgICB0aGlzLmFwaS50b2dnbGVUYWJsZSA9IChfc2hvd1RhYmxlOiBib29sZWFuLCByYXdEYXRhOiBJVGFibGVEYXRhKTogdm9pZCA9PiB7XHJcbiAgICAgICAgICAgIHJhd0RhdGEuY29uZmlnID0gT2JqZWN0LmFzc2lnbih7fSwgdGhpcy5yYXdEYXRhLmNvbmZpZywgcmF3RGF0YS5jb25maWcpO1xyXG4gICAgICAgICAgICB0aGlzLnJhd0RhdGEgPSBPYmplY3QuYXNzaWduKHt9LCByYXdEYXRhKTtcclxuICAgICAgICAgICAgdGhpcy5jb2x1bW5BZnRlckZpbHRlciA9IHRoaXMuX3Zpc3VhbGl6YXRpb25TdmMuZmlsdGVyQ29sdW1ucyhyYXdEYXRhLmNvbHVtbik7XHJcbiAgICAgICAgICAgIGlmIChfc2hvd1RhYmxlKSB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLl90ZW1wU3RhdGUgPSB0aGlzLmNvbnRlbnRTdGF0ZTtcclxuICAgICAgICAgICAgICAgIGlmICh0aGlzLmNvbnRlbnRTdGF0ZSAhPT0gJ3RhYmxlJykge1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuY29udGVudFN0YXRlID0gJ3RhYmxlJztcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLl9jYWxsUGx1Z2lucygndmlldy50YWJsZScpO1xyXG4gICAgICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgICAgIHRoaXMuaXNFeHBvcnRFbmFibGVkID0gZmFsc2U7XHJcbiAgICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLmlzRXhwb3J0RW5hYmxlZCA9IHR5cGVvZiB0aGlzLmNvbmZpZyAhPT0gJ3VuZGVmaW5lZCcgJiYgdGhpcy5jb25maWcuZXhwb3J0LmVuYWJsZWQ7XHJcbiAgICAgICAgICAgICAgICB0aGlzLl92aXN1YWxpemF0aW9uU3ZjLnNldFBhcmVudEhlaWdodCgnY2hhcnQnKTtcclxuICAgICAgICAgICAgICAgIHRoaXMuY29udGVudFN0YXRlID0gdGhpcy5fdGVtcFN0YXRlID8gdGhpcy5fdGVtcFN0YXRlIDogJ2NoYXJ0JztcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICAvLyA9PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT0gTWVudSBDbGlja2VkID09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT1cclxuXHJcbiAgICBwdWJsaWMgdG9nZ2xlTWVudShfaXRlbT86IGFueSk6IHZvaWQge1xyXG4gICAgICAgIGxldCBoYXZlT3BlcmF0aW9uOiBib29sZWFuID0gX2l0ZW0gJiYgX2l0ZW0ub3BlcmF0aW9uO1xyXG4gICAgICAgIGxldCBoYXZlQ2FsbGJhY2s6IGJvb2xlYW4gPSBfaXRlbSAmJiBfaXRlbS5jYWxsYmFjaztcclxuXHJcbiAgICAgICAgaWYgKGhhdmVPcGVyYXRpb24pIHRoaXMuX2NhbGxQbHVnaW5zKF9pdGVtLm9wZXJhdGlvbik7XHJcbiAgICAgICAgaWYgKGhhdmVDYWxsYmFjaykgX2l0ZW0uY2FsbGJhY2soKTtcclxuXHJcbiAgICAgICAgdGhpcy5fdG9nZ2xlTWVudUZsYWcodGhpcy5tZW51RmxhZywgX2l0ZW0sIGhhdmVPcGVyYXRpb24gfHwgaGF2ZUNhbGxiYWNrKTtcclxuXHJcbiAgICAgICAgdGhpcy5tZW51QnRuSWNvbkNsYXNzID0gdGhpcy5fbWVudUJ0bkxpc3RbdGhpcy5tZW51RmxhZ107XHJcblxyXG4gICAgICAgIHRoaXMuaXNNZW51T3BlbiA9IHRoaXMubWVudUZsYWcgPT09ICdvcGVuZWQnIHx8IHRoaXMubWVudUZsYWcgPT09ICdleHBhbmRlZCc7XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfdG9nZ2xlTWVudUZsYWcoX2ZsYWc6IHN0cmluZywgX2l0ZW0/OiBhbnksIF9jbG9zZUV4cGFuZD86IGJvb2xlYW4pOiB2b2lkIHtcclxuICAgICAgICBzd2l0Y2ggKF9mbGFnKSB7XHJcbiAgICAgICAgICAgIGNhc2UgJ2Nsb3NlZCc6XHJcbiAgICAgICAgICAgIGRlZmF1bHQ6XHJcbiAgICAgICAgICAgICAgICB0aGlzLm1lbnVGbGFnID0gJ29wZW5lZCc7XHJcbiAgICAgICAgICAgICAgICBicmVhaztcclxuICAgICAgICAgICAgY2FzZSAnb3BlbmVkJzpcclxuICAgICAgICAgICAgICAgIGxldCBpc0V4cGFuZDogYm9vbGVhbiA9IF9pdGVtICYmIF9pdGVtLmV4cGFuZGVkO1xyXG4gICAgICAgICAgICAgICAgaWYgKGlzRXhwYW5kKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5tZW51RGlzcGxheUFyciA9IF9pdGVtLmV4cGFuZGVkO1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMubWVudUZsYWcgPSAnZXhwYW5kZWQnO1xyXG4gICAgICAgICAgICAgICAgICAgIHJldHVybjtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIGxldCBpc1ZpZXc6IGJvb2xlYW4gPSBmYWxzZTtcclxuICAgICAgICAgICAgICAgIGlmIChfaXRlbSAmJiBfaXRlbS5oYXNPd25Qcm9wZXJ0eSgnb3BlcmF0aW9uJykpIHtcclxuICAgICAgICAgICAgICAgICAgICBpc1ZpZXcgPSBfaXRlbSAmJiBfaXRlbS5vcGVyYXRpb24uaW5kZXhPZigndmlldycpID4gLTE7XHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKGlzVmlldykgdGhpcy5jb250ZW50U3RhdGUgPSBfaXRlbS5vcGVyYXRpb24uc3BsaXQoJy4nKVsxXTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIHRoaXMubWVudUZsYWcgPSBpc1ZpZXcgPyAndmlld2VkJyA6ICdjbG9zZWQnO1xyXG4gICAgICAgICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgICAgIGNhc2UgJ2V4cGFuZGVkJzpcclxuICAgICAgICAgICAgICAgIHRoaXMubWVudUZsYWcgPSBfY2xvc2VFeHBhbmQgPyAnY2xvc2VkJyA6ICdvcGVuZWQnO1xyXG4gICAgICAgICAgICAgICAgdGhpcy5tZW51RGlzcGxheUFyciA9IHRoaXMuX21lbnVBcnI7XHJcbiAgICAgICAgICAgICAgICBicmVhaztcclxuICAgICAgICAgICAgY2FzZSAndmlld2VkJzpcclxuICAgICAgICAgICAgICAgIHRoaXMuX3Zpc3VhbGl6YXRpb25TdmMuc2V0UGFyZW50SGVpZ2h0KCdjaGFydCcpO1xyXG4gICAgICAgICAgICAgICAgdGhpcy5tZW51RmxhZyA9ICdjbG9zZWQnO1xyXG4gICAgICAgICAgICAgICAgdGhpcy5jb250ZW50U3RhdGUgPSAnY2hhcnQnO1xyXG4gICAgICAgICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX2NhbGxQbHVnaW5zKF9vcGVyYXRpb246IHN0cmluZyk6IHZvaWQge1xyXG5cclxuICAgICAgICAvLyBvcGVyYXRpb25zIGFyZSBzZXBhcmF0ZWQgYnkgLlxyXG4gICAgICAgIGxldCBvcGVyYXRpb25BcnIgPSBfb3BlcmF0aW9uLnNwbGl0KCcuJyk7XHJcblxyXG4gICAgICAgIGlmIChvcGVyYXRpb25BcnJbMF0gPT09ICd2aWV3JyAmJiBvcGVyYXRpb25BcnJbMV0gPT09ICd0YWJsZScpIHtcclxuICAgICAgICAgICAgdGhpcy5fdmlzdWFsaXphdGlvblN2Yy5wcm9jZXNzVmlld1RhYmxlKHRoaXMucmF3RGF0YS5jb25maWcpO1xyXG4gICAgICAgICAgICByZXR1cm47XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICBpZiAob3BlcmF0aW9uQXJyWzBdICE9PSAnZXhwb3J0JykgcmV0dXJuO1xyXG5cclxuICAgICAgICBpZiAodGhpcy5jb25maWcudGl0bGUudGV4dCkgdGhpcy5fZmlsZU5hbWUgPSB0aGlzLmNvbmZpZy50aXRsZS50ZXh0LnJlcGxhY2UoL1xccy9nLCAnXycpO1xyXG5cclxuICAgICAgICBpZiAob3BlcmF0aW9uQXJyWzFdID09PSAnZXhjZWwnKSB7XHJcbiAgICAgICAgICAgIHRoaXMuZXhwb3J0VGFibGUgPSB0cnVlO1xyXG4gICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgIHRoaXMuX3ByZXBFeHBvcnRDaGFydChvcGVyYXRpb25BcnJbMV0pLnN1YnNjcmliZSgoKT0+e30pO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF9wcmVwRXhwb3J0Q2hhcnQoX29wZXJhdGlvbjogc3RyaW5nLCBfb3B0aW9uczogSU9wdGlvbnMgPSB7fSwgX2lzUmVtb3ZlTGVnZW5kU2Nyb2xsOiBib29sZWFuID0gdHJ1ZSk6IE9ic2VydmFibGU8c3RyaW5nPiB7XHJcbiAgICAgICAgcmV0dXJuIG5ldyBPYnNlcnZhYmxlPHN0cmluZz4oKF9vYnNlcnZlcjogT2JzZXJ2ZXI8c3RyaW5nPikgPT4ge1xyXG4gICAgICAgICAgICBpZiAoIXRoaXMuX2V4cG9ydC5pc0V4cG9ydENvbXBhdGlibGUoKSkge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5lcnJvck1zZy5lbWl0KHRoaXMuX2V4cG9ydC5nZXRFcnJvck1lc3NhZ2UoX29wZXJhdGlvbikpO1xyXG4gICAgICAgICAgICAgICAgX29ic2VydmVyLmVycm9yKHRoaXMuX2V4cG9ydC5nZXRFcnJvck1lc3NhZ2UoX29wZXJhdGlvbikpO1xyXG4gICAgICAgICAgICAgICAgX29ic2VydmVyLmNvbXBsZXRlKCk7XHJcbiAgICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgICAgICAvLyBjaGFydCBmb3IgZXhwb3J0aW5nIHNob3VsZCBza2lwIG1hc3NhZ2UgYW5kIG5vdCBoYXZlIGFuaW1hdGlvblxyXG4gICAgICAgICAgICAgICAgdGhpcy5jb25maWdGb3JJbnZpc2libGVjaGFydCA9IE9iamVjdC5hc3NpZ24oe30sIHRoaXMuY29uZmlnLCB7IGlkOiAnZXhwb3J0LWNoYXJ0JywgYW5pbWF0aW9uOiBmYWxzZSwgc2tpcE1hc3NhZ2U6IHRydWUgfSk7XHJcbiAgICAgICAgICAgICAgICB0aGlzLmV4cG9ydE5vdyA9IHRydWU7XHJcblxyXG4gICAgICAgICAgICAgICAgLy8gVmlld0NoaWxkIHJlcXVpcmVzIHNldFRpbWVvdXQgKEFuZ3VsYXIgNSlcclxuICAgICAgICAgICAgICAgIHNldFRpbWVvdXQoKCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgIC8vIHNldCBMZWdlbmQgRGF0YSBzbyB0aGF0IHRoaXMgaW5mbyBkb2VzIG5vdCBoYXZlIHRvIGJlIHJlZ2VuZXJhdGVkIGJ5IGludmlzaWJsZSBjaGFydFxyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuaW52aXNpYmxlQ2hhcnQuc2V0TGVnZW5kRGF0YSh0aGlzLmxlZ2VuZERhdGFBZnRlck1hc3NhZ2UpO1xyXG4gICAgICAgICAgICAgICAgICAgIC8vIHRyaWdnZXIgY2hhcnQgdG8gZHJhdyBvbmNlIGxlZ2VuZCBkYXRhIGlzIHNldFxyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuZGF0YUZvckludmlzaWJsZUNoYXJ0ID0gdGhpcy5kYXRhQWZ0ZXJNYXNzYWdlO1xyXG4gICAgICAgICAgICAgICAgfSk7XHJcblxyXG4gICAgICAgICAgICAgICAgbGV0IG9wdGlvbnM6IElPcHRpb25zID0gT2JqZWN0LmFzc2lnbih7fSwgX29wdGlvbnMpO1xyXG4gICAgICAgICAgICAgICAgaWYgKHRoaXMuX2ZpbGVOYW1lKSBvcHRpb25zWydmaWxlTmFtZSddID0gdGhpcy5fZmlsZU5hbWU7XHJcblxyXG4gICAgICAgICAgICAgICAgc2V0VGltZW91dCgoKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgbGV0IGNoYXJ0RWxlbWVudCA9IHRoaXMuX2VsZW1SZWYubmF0aXZlRWxlbWVudC5xdWVyeVNlbGVjdG9yKCcuJyArIHRoaXMuaW52aXNpYmxlQ2hhcnRDbGFzcyArICcua2R4LWNoYXJ0cycpO1xyXG5cclxuICAgICAgICAgICAgICAgICAgICAvLyBiZWZvcmUgZXhwb3J0aW5nLCB0aGUgaHRtbCBuZWVkcyB0byBiZSBjaGFuZ2VkXHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5fdmlzdWFsaXphdGlvblN2Yy5yZW1vdmVEdW1teShjaGFydEVsZW1lbnQpO1xyXG4gICAgICAgICAgICAgICAgICAgIGlmIChfaXNSZW1vdmVMZWdlbmRTY3JvbGwpIHRoaXMuX3Zpc3VhbGl6YXRpb25TdmMucmVtb3ZlTGVnZW5kU2Nyb2xsKGNoYXJ0RWxlbWVudCk7XHJcbiAgICAgICAgICAgICAgICAgICAgY2hhcnRFbGVtZW50LnN0eWxlLmhlaWdodCA9ICdhdXRvJztcclxuXHJcbiAgICAgICAgICAgICAgICAgICAgb3B0aW9uc1snd2lkdGgnXSA9IGNoYXJ0RWxlbWVudC5nZXRCb3VuZGluZ0NsaWVudFJlY3QoKS53aWR0aCArIDE7XHJcbiAgICAgICAgICAgICAgICAgICAgb3B0aW9uc1snaGVpZ2h0J10gPSBjaGFydEVsZW1lbnQuZ2V0Qm91bmRpbmdDbGllbnRSZWN0KCkuaGVpZ2h0ICsgMTtcclxuXHJcbiAgICAgICAgICAgICAgICAgICAgbGV0IHJlc3VsdCA9IHRoaXMuX2V4cG9ydC5leHBvcnRFbGVtZW50KGNoYXJ0RWxlbWVudCwgX29wZXJhdGlvbiwgb3B0aW9ucyk7XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIC8vIG9uY2UgZXhwb3J0IGlzIGRvbmUsIHJlbW92ZSB0aGUgaW52aXNpYmxlIGNoYXJ0IGZyb20gRE9NXHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5leHBvcnROb3cgPSBmYWxzZTtcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLmRhdGFGb3JJbnZpc2libGVDaGFydCA9IG51bGw7XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIGlmIChyZXN1bHQpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgcmVzdWx0LnRoZW4oZGF0YVVybCA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBfb2JzZXJ2ZXIubmV4dChkYXRhVXJsKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIF9vYnNlcnZlci5jb21wbGV0ZSgpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB9KVxyXG4gICAgICAgICAgICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIF9vYnNlcnZlci5jb21wbGV0ZSgpO1xyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIH0sIHRoaXMuX3RpbWVvdXRUaW1pbmcpO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfSk7XHJcblxyXG4gICAgfVxyXG5cclxufVxyXG4iXX0=