import { Injectable } from '@angular/core';
export class KdTreeDropdownSvc {
    /**
     * change config to primeng readable tree data
     *
     * config      : [data pass from example]
     * mode        : [mode of the dropdown checkbox/multiple or radio/single]
     * isChildData : [for lazy load. as we need to convert child data from example to be TreeNode readable by primeng tree
     *                     plugin, we will need a flag to decide which data to be convert. whether it is the config.list (for
     *                     config) or just config (for child data)]
     *
     */
    getUpdateNode(config, mode, isChildData) {
        let tempData = [];
        if (typeof config !== 'undefined' && typeof config.list !== 'undefined')
            tempData = this._cloneNewArray(config.list);
        else if (typeof isChildData !== 'undefined' && isChildData)
            tempData = this._cloneNewArray(config);
        else
            return tempData;
        let updatedData = [];
        if (mode === 'multiple')
            updatedData = this._getExpandedBool(tempData, mode);
        else
            updatedData = this._getExpandedBool(tempData, mode, false);
        return updatedData;
    }
    /**
     * get the treedropdown input type whether it is checkbox or radio
     *
     * config    : [data pass from example]
     *
     */
    getMode(config) {
        if (typeof config === 'undefined' ||
            typeof config.selectionMode === 'undefined' ||
            (config.selectionMode === 'multiple' || config.selectionMode === 'single'))
            return config.selectionMode;
        return 'single';
    }
    /**
     * get the selected value. if it is checkbox, add in the selected data, if it is radio, replace the selected data
     *
     * currentSelected    : [previously selected data]
     * selectNode         : [selected node primeng data]
     * mode               : [checkbox/radio | multiple/single]
     * return format      : [{ id, name, selected: true }]
     */
    updateSelectedNodes(currentSelected, selectNode, mode) {
        let updateArray = [];
        if (mode === 'multiple')
            updateArray = this._checkCheckbox(currentSelected, selectNode);
        else if (selectNode.data.selected)
            updateArray.push(selectNode.data);
        return updateArray;
    }
    /**
     * if selected, add data into selected array, else remove from array
     *
     * currentSelected    : [selected data: { id, name, selected: true }]
     * selectNode         : [selected node (primeng node)]
     *
     */
    _checkCheckbox(currentSelected, selectNode) {
        let updatedArray = currentSelected.slice(0) || [];
        if (selectNode.data.selected)
            updatedArray.push(selectNode.data);
        else {
            for (let i = 0; i < currentSelected.length; i++) {
                if (selectNode.data.id === currentSelected[i].id) {
                    updatedArray.splice(i, 1);
                    break;
                }
            }
        }
        return updatedArray;
    }
    /**
     * Update the selected data
     *
     * currentData    : [all data]
     * mode           : [checkbox/radio | multiple/single]
     *
     */
    updateInitSelected(currentData, mode) {
        let updatedData = [];
        if (mode === 'multiple')
            updatedData = this.getInitSelected(updatedData, currentData);
        else
            updatedData = this.getInitSelected(updatedData, currentData, false);
        return updatedData;
    }
    /**
     * Change dropdown label. Either "Please select" or number of item selected
     *
     * selectedNodes    : [selected data]
     *
     */
    updateSelectedString(selectedNodes) {
        if (typeof selectedNodes === 'undefined' || selectedNodes.length === 0)
            return 'Please select';
        else if (selectedNodes.length === 1)
            return selectedNodes[0].name;
        else
            return selectedNodes.length + ' items selected';
    }
    /**
     * check if the mouse/touch is within the dropdown list (option list) box
     *
     * state         : [blur: click or scroll]
     * position      : [position of the mouse/touch]
     * id            : [tree id]
     * currentEle    : [dropdown list]
     *
     */
    checkWithinBoundingBox(state, position, id, currentEle) {
        let queryString = '.' + id + '.kdx-popover-window';
        let popoverWindow = document.querySelector(queryString);
        let popoverWindowRect = popoverWindow.getBoundingClientRect();
        if (popoverWindow === null)
            return false;
        let boundingRect = {
            top: (state === 'blur') ? currentEle.getBoundingClientRect().top : popoverWindowRect.top,
            bottom: popoverWindowRect.bottom,
            right: popoverWindowRect.right,
            left: popoverWindowRect.left
        };
        if (position.x > boundingRect.left && position.x < boundingRect.right &&
            position.y > boundingRect.top && position.y < boundingRect.bottom)
            return true;
        return false;
    }
    /**
     * get position for the mouse/touch  in x and y
     *
     * e    : [mouse/touch event]
     *
     */
    getTouchPosition(e) {
        let position = { x: 0, y: 0 };
        try {
            position.x = e.touches[0].clientX;
            position.y = e.touches[0].clientY;
        }
        catch (err) {
            position.x = e.targetTouches[0].clientX;
            position.y = e.targetTouches[0].clientY;
        }
        return position;
    }
    /**
     * When first load, get the selected data. if mode is radio, only return the first data that is selected in the current Array.
     * Previous selected data or the following selected data will be removed.
     *
     * selectedArray    : [selected array either empty or array of data for multiple selection mode]
     * currentArray     : [all data]
     * isSingleFound    : [if radio/single mode, true else undefined]
     */
    getInitSelected(selectedArray, currentArray, isSingleFound) {
        let updatedArray = selectedArray.slice(0);
        let loopSingleFound = undefined;
        if (typeof isSingleFound !== 'undefined')
            loopSingleFound = isSingleFound;
        for (let i = 0; i < currentArray.length; i++) {
            if (loopSingleFound)
                break;
            if (currentArray[i].data.selected) {
                updatedArray.push(currentArray[i].data);
                if (typeof isSingleFound !== 'undefined')
                    loopSingleFound = true;
            }
            if (typeof currentArray[i].children !== 'undefined')
                updatedArray = this.getInitSelected(updatedArray, currentArray[i].children, loopSingleFound);
        }
        return updatedArray;
    }
    /**
     * do a copy of array
     *
     * oldArray    : [array that you would like to copy]
     *
     */
    _cloneNewArray(oldArray) {
        let newArray = [];
        for (let i = 0; i < oldArray.length; i++) {
            let item = Object.assign({}, oldArray[i]);
            item.data = Object.assign({}, oldArray[i].data);
            if (typeof oldArray[i].children !== 'undefined')
                item.children = this._cloneNewArray(oldArray[i].children);
            newArray.push(item);
        }
        return newArray;
    }
    /**
     * set all data as not expanded and convert all data into primeng tree plugin readable data
     *
     * _currentData      : [all data]
     * _mode             : [checkbox/radio | single/multiple ]
     * _isSingleSelected :
     *
     */
    _getExpandedBool(_currentData, _mode, _isSingleSelected) {
        let isSingleFound = _isSingleSelected;
        let updatedData = _currentData.slice(0);
        for (let i = 0; i < updatedData.length; i++) {
            updatedData[i].label = _currentData[i].data.name;
            if (typeof updatedData[i].children !== 'undefined') {
                updatedData[i].expanded = false;
                updatedData[i].children = this._getExpandedBool(updatedData[i].children, _mode, isSingleFound);
            }
            updatedData[i].type = (_mode === 'multiple') ? 'checkbox' : 'radio';
            if (typeof updatedData[i].data.selected === 'undefined')
                updatedData[i].data.selected = false;
            else if (updatedData[i].data.selected && typeof isSingleFound !== 'undefined') {
                if (!isSingleFound)
                    isSingleFound = true;
                else
                    updatedData[i].data.selected = false;
            }
        }
        return updatedData;
    }
    /**
     * error prevention set false if data passed in is undefined. leave the data as it is if it is not undefined
     *
     * config     : [config]
     * setting    : [any setting. can be mode, can be expandSelected or expandAll]
     *
     */
    getSetting(config, setting) {
        if (typeof config === 'undefined' ||
            typeof config[setting] === 'undefined')
            return false;
        return config[setting];
    }
    /**
     * for expandAll. expand the data as long as there is a child data
     *
     * _list    : [config list]
     */
    _expandList(_list) {
        let vm = this;
        _list.forEach(function (item) {
            item.expanded = true;
            if (item.children) {
                vm._expandList(item.children);
            }
        });
    }
    /**
     * only expand the parent data if the child value is selected
     *
     * _list : [config list]
     */
    _expandSelected(_list) {
        let isChildSelected;
        for (let i = 0; i < _list.length; i++) {
            let item = _list[i];
            isChildSelected = false;
            if (item.children) {
                isChildSelected = this._expandChildList(item.children);
                item.expanded = isChildSelected;
            }
            else {
                continue;
            }
        }
    }
    /**
     * main purpose is to return true if there is a selected data. this loop should loop
     * through all the way until the last child item at the same time, every single loop,
     * it should set the layer above the current child list to expand true if the current
     * child list is selected
     *
     * _list :
     *
     */
    _expandChildList(_list) {
        for (let x = 0; x < _list.length; x++) {
            let childItem = _list[x];
            if (childItem.children) {
                let isChildSelected = this._expandChildList(childItem.children);
                childItem.expanded = isChildSelected;
                return isChildSelected;
            }
            else if (childItem.data.selected) {
                return childItem.data.selected;
            }
        }
        return false;
    }
    /**
     * main function to check and trigger whether to expand all or expand selected
     *
     * _config      : [config]
     * _updatedData : [primeng tree data]
     */
    autoExpandList(_config, _updatedData) {
        let _expandAll = this.getSetting(_config, 'expandAll');
        let _expandSelected = this.getSetting(_config, 'expandSelected');
        if (typeof _expandAll !== 'undefined' || typeof _expandSelected !== 'undefined') {
            if (_expandAll === 'true' || _expandAll) {
                this._expandList(_updatedData);
            }
            else if (_expandSelected === 'true' || _expandSelected) {
                this._expandSelected(_updatedData);
            }
        }
    }
    /**
     * used when adding child data manually during child data lazy load. when user click to expand child list
     * the example will pass in child data which is not to the primeng tree plugin readable data
     *
     * _id             :
     * _childData      :
     * _updatedData    :
     * mode            :
     *
     */
    updateConfig(_id, _childData, _updatedData, mode) {
        for (let i = 0; i < _updatedData.length; i++) {
            let configList = _updatedData[i];
            if (configList.data.id === _id) {
                if (typeof configList.children === 'undefined') {
                    configList.children = [];
                }
                configList.children = this.getUpdateNode(_childData, mode, true);
                break;
            }
            else {
                if (configList.hasOwnProperty('children')) {
                    this.updateConfig(_id, _childData, configList.children, mode);
                }
            }
        }
        return this.updateInitSelected(_updatedData, mode);
    }
}
KdTreeDropdownSvc.decorators = [
    { type: Injectable }
];
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoia2QtdHJlZWRyb3Bkb3duLXN2Yy5qcyIsInNvdXJjZVJvb3QiOiJDOi94YW1wcC9odGRvY3MvU3R5bGVndWlkZS9pb3N0Zy1vcGVuZW1pcy1zdHlsZWd1aWRlL3Byb2plY3RzL29wZW5lbWlzLXN0eWxlZ3VpZGUtbGliL3NyYy8iLCJzb3VyY2VzIjpbImtkLWNvbXBvbmVudHMva2QtYW5ndWxhci10cmVlZHJvcGRvd24va2QtdHJlZWRyb3Bkb3duLXN2Yy50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQSxPQUFPLEVBQUUsVUFBVSxFQUFFLE1BQU0sZUFBZSxDQUFDO0FBSTNDLE1BQU0sT0FBTyxpQkFBaUI7SUFDMUI7Ozs7Ozs7OztPQVNHO0lBQ0gsYUFBYSxDQUFDLE1BQVcsRUFBRSxJQUFZLEVBQUUsV0FBcUI7UUFDMUQsSUFBSSxRQUFRLEdBQW9CLEVBQUUsQ0FBQztRQUNuQyxJQUFJLE9BQU8sTUFBTSxLQUFLLFdBQVcsSUFBSSxPQUFPLE1BQU0sQ0FBQyxJQUFJLEtBQUssV0FBVztZQUFFLFFBQVEsR0FBRyxJQUFJLENBQUMsY0FBYyxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsQ0FBQzthQUNoSCxJQUFJLE9BQU8sV0FBVyxLQUFLLFdBQVcsSUFBSSxXQUFXO1lBQUUsUUFBUSxHQUFHLElBQUksQ0FBQyxjQUFjLENBQUMsTUFBTSxDQUFDLENBQUM7O1lBQzlGLE9BQU8sUUFBUSxDQUFDO1FBRXJCLElBQUksV0FBVyxHQUFlLEVBQUUsQ0FBQztRQUNqQyxJQUFJLElBQUksS0FBSyxVQUFVO1lBQUUsV0FBVyxHQUFHLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxRQUFRLEVBQUUsSUFBSSxDQUFDLENBQUM7O1lBQ3hFLFdBQVcsR0FBRyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsUUFBUSxFQUFFLElBQUksRUFBRSxLQUFLLENBQUMsQ0FBQztRQUNoRSxPQUFPLFdBQVcsQ0FBQztJQUN2QixDQUFDO0lBRUQ7Ozs7O09BS0c7SUFDSCxPQUFPLENBQUMsTUFBVztRQUNmLElBQ0ksT0FBTyxNQUFNLEtBQUssV0FBVztZQUM3QixPQUFPLE1BQU0sQ0FBQyxhQUFhLEtBQUssV0FBVztZQUMzQyxDQUFDLE1BQU0sQ0FBQyxhQUFhLEtBQUssVUFBVSxJQUFJLE1BQU0sQ0FBQyxhQUFhLEtBQUssUUFBUSxDQUFDO1lBQzVFLE9BQU8sTUFBTSxDQUFDLGFBQWEsQ0FBQztRQUM5QixPQUFPLFFBQVEsQ0FBQztJQUNwQixDQUFDO0lBRUQ7Ozs7Ozs7T0FPRztJQUNILG1CQUFtQixDQUFDLGVBQTJCLEVBQUUsVUFBZSxFQUFFLElBQVk7UUFDMUUsSUFBSSxXQUFXLEdBQWUsRUFBRSxDQUFDO1FBQ2pDLElBQUksSUFBSSxLQUFLLFVBQVU7WUFBRSxXQUFXLEdBQUcsSUFBSSxDQUFDLGNBQWMsQ0FBQyxlQUFlLEVBQUUsVUFBVSxDQUFDLENBQUM7YUFDbkYsSUFBSSxVQUFVLENBQUMsSUFBSSxDQUFDLFFBQVE7WUFBRSxXQUFXLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxJQUFJLENBQUMsQ0FBQztRQUNyRSxPQUFPLFdBQVcsQ0FBQztJQUN2QixDQUFDO0lBRUQ7Ozs7OztPQU1HO0lBQ0ssY0FBYyxDQUFDLGVBQTJCLEVBQUUsVUFBZTtRQUMvRCxJQUFJLFlBQVksR0FBZSxlQUFlLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxJQUFJLEVBQUUsQ0FBQztRQUM5RCxJQUFJLFVBQVUsQ0FBQyxJQUFJLENBQUMsUUFBUTtZQUFFLFlBQVksQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLElBQUksQ0FBQyxDQUFDO2FBQzVEO1lBQ0QsS0FBSyxJQUFJLENBQUMsR0FBVyxDQUFDLEVBQUUsQ0FBQyxHQUFHLGVBQWUsQ0FBQyxNQUFNLEVBQUUsQ0FBQyxFQUFFLEVBQUU7Z0JBQ3JELElBQUksVUFBVSxDQUFDLElBQUksQ0FBQyxFQUFFLEtBQUssZUFBZSxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsRUFBRTtvQkFDOUMsWUFBWSxDQUFDLE1BQU0sQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUM7b0JBQzFCLE1BQU07aUJBQ1Q7YUFDSjtTQUNKO1FBQ0QsT0FBTyxZQUFZLENBQUM7SUFDeEIsQ0FBQztJQUVEOzs7Ozs7T0FNRztJQUNILGtCQUFrQixDQUFDLFdBQXVCLEVBQUUsSUFBWTtRQUNwRCxJQUFJLFdBQVcsR0FBZSxFQUFFLENBQUM7UUFDakMsSUFBSSxJQUFJLEtBQUssVUFBVTtZQUFFLFdBQVcsR0FBRyxJQUFJLENBQUMsZUFBZSxDQUFDLFdBQVcsRUFBRSxXQUFXLENBQUMsQ0FBQzs7WUFDakYsV0FBVyxHQUFHLElBQUksQ0FBQyxlQUFlLENBQUMsV0FBVyxFQUFFLFdBQVcsRUFBRSxLQUFLLENBQUMsQ0FBQztRQUN6RSxPQUFPLFdBQVcsQ0FBQztJQUN2QixDQUFDO0lBRUQ7Ozs7O09BS0c7SUFDSCxvQkFBb0IsQ0FBQyxhQUF5QjtRQUMxQyxJQUFJLE9BQU8sYUFBYSxLQUFLLFdBQVcsSUFBSSxhQUFhLENBQUMsTUFBTSxLQUFLLENBQUM7WUFBRSxPQUFPLGVBQWUsQ0FBQzthQUMxRixJQUFJLGFBQWEsQ0FBQyxNQUFNLEtBQUssQ0FBQztZQUFFLE9BQU8sYUFBYSxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQzs7WUFDN0QsT0FBTyxhQUFhLENBQUMsTUFBTSxHQUFHLGlCQUFpQixDQUFDO0lBQ3pELENBQUM7SUFFRDs7Ozs7Ozs7T0FRRztJQUNILHNCQUFzQixDQUFDLEtBQWEsRUFBRSxRQUFhLEVBQUUsRUFBVSxFQUFFLFVBQXdCO1FBQ3JGLElBQUksV0FBVyxHQUFXLEdBQUcsR0FBRyxFQUFFLEdBQUcscUJBQXFCLENBQUM7UUFDM0QsSUFBSSxhQUFhLEdBQVksUUFBUSxDQUFDLGFBQWEsQ0FBQyxXQUFXLENBQUMsQ0FBQztRQUNqRSxJQUFJLGlCQUFpQixHQUFlLGFBQWEsQ0FBQyxxQkFBcUIsRUFBRSxDQUFDO1FBQzFFLElBQUksYUFBYSxLQUFLLElBQUk7WUFBRSxPQUFPLEtBQUssQ0FBQztRQUN6QyxJQUFJLFlBQVksR0FBUTtZQUNwQixHQUFHLEVBQUUsQ0FBQyxLQUFLLEtBQUssTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLFVBQVUsQ0FBQyxxQkFBcUIsRUFBRSxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsaUJBQWlCLENBQUMsR0FBRztZQUN4RixNQUFNLEVBQUUsaUJBQWlCLENBQUMsTUFBTTtZQUNoQyxLQUFLLEVBQUUsaUJBQWlCLENBQUMsS0FBSztZQUM5QixJQUFJLEVBQUUsaUJBQWlCLENBQUMsSUFBSTtTQUMvQixDQUFDO1FBQ0YsSUFBSSxRQUFRLENBQUMsQ0FBQyxHQUFHLFlBQVksQ0FBQyxJQUFJLElBQUksUUFBUSxDQUFDLENBQUMsR0FBRyxZQUFZLENBQUMsS0FBSztZQUNqRSxRQUFRLENBQUMsQ0FBQyxHQUFHLFlBQVksQ0FBQyxHQUFHLElBQUksUUFBUSxDQUFDLENBQUMsR0FBRyxZQUFZLENBQUMsTUFBTTtZQUFFLE9BQU8sSUFBSSxDQUFDO1FBQ25GLE9BQU8sS0FBSyxDQUFDO0lBQ2pCLENBQUM7SUFFRDs7Ozs7T0FLRztJQUNILGdCQUFnQixDQUFDLENBQWE7UUFDMUIsSUFBSSxRQUFRLEdBQVEsRUFBRSxDQUFDLEVBQUUsQ0FBQyxFQUFFLENBQUMsRUFBRSxDQUFDLEVBQUUsQ0FBQztRQUNuQyxJQUFJO1lBQ0EsUUFBUSxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQztZQUNsQyxRQUFRLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDO1NBQ3JDO1FBQUMsT0FBTyxHQUFHLEVBQUU7WUFDVixRQUFRLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxhQUFhLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDO1lBQ3hDLFFBQVEsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLGFBQWEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUM7U0FDM0M7UUFDRCxPQUFPLFFBQVEsQ0FBQztJQUNwQixDQUFDO0lBRUQ7Ozs7Ozs7T0FPRztJQUNLLGVBQWUsQ0FBQyxhQUF5QixFQUFFLFlBQXdCLEVBQUUsYUFBdUI7UUFDaEcsSUFBSSxZQUFZLEdBQWUsYUFBYSxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQztRQUN0RCxJQUFJLGVBQWUsR0FBWSxTQUFTLENBQUM7UUFDekMsSUFBSSxPQUFPLGFBQWEsS0FBSyxXQUFXO1lBQUUsZUFBZSxHQUFHLGFBQWEsQ0FBQztRQUMxRSxLQUFLLElBQUksQ0FBQyxHQUFXLENBQUMsRUFBRSxDQUFDLEdBQUcsWUFBWSxDQUFDLE1BQU0sRUFBRSxDQUFDLEVBQUUsRUFBRTtZQUNsRCxJQUFJLGVBQWU7Z0JBQUUsTUFBTTtZQUMzQixJQUFJLFlBQVksQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsUUFBUSxFQUFFO2dCQUMvQixZQUFZLENBQUMsSUFBSSxDQUFDLFlBQVksQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQztnQkFDeEMsSUFBSSxPQUFPLGFBQWEsS0FBSyxXQUFXO29CQUFFLGVBQWUsR0FBRyxJQUFJLENBQUM7YUFDcEU7WUFDRCxJQUFJLE9BQU8sWUFBWSxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsS0FBSyxXQUFXO2dCQUFFLFlBQVksR0FBRyxJQUFJLENBQUMsZUFBZSxDQUFDLFlBQVksRUFBRSxZQUFZLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxFQUFFLGVBQWUsQ0FBQyxDQUFDO1NBQ3JKO1FBQ0QsT0FBTyxZQUFZLENBQUM7SUFDeEIsQ0FBQztJQUVEOzs7OztPQUtHO0lBQ0ssY0FBYyxDQUFDLFFBQXlCO1FBQzVDLElBQUksUUFBUSxHQUFvQixFQUFFLENBQUM7UUFDbkMsS0FBSyxJQUFJLENBQUMsR0FBVyxDQUFDLEVBQUUsQ0FBQyxHQUFHLFFBQVEsQ0FBQyxNQUFNLEVBQUUsQ0FBQyxFQUFFLEVBQUU7WUFDOUMsSUFBSSxJQUFJLEdBQWEsTUFBTSxDQUFDLE1BQU0sQ0FBQyxFQUFFLEVBQUUsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7WUFDcEQsSUFBSSxDQUFDLElBQUksR0FBRyxNQUFNLENBQUMsTUFBTSxDQUFDLEVBQUUsRUFBRSxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUM7WUFDaEQsSUFBSSxPQUFPLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLEtBQUssV0FBVztnQkFBRSxJQUFJLENBQUMsUUFBUSxHQUFHLElBQUksQ0FBQyxjQUFjLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDO1lBQzNHLFFBQVEsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUM7U0FDdkI7UUFDRCxPQUFPLFFBQVEsQ0FBQztJQUNwQixDQUFDO0lBRUQ7Ozs7Ozs7T0FPRztJQUNLLGdCQUFnQixDQUFDLFlBQTZCLEVBQUUsS0FBYSxFQUFFLGlCQUEyQjtRQUM5RixJQUFJLGFBQWEsR0FBWSxpQkFBaUIsQ0FBQztRQUMvQyxJQUFJLFdBQVcsR0FBb0IsWUFBWSxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQztRQUN6RCxLQUFLLElBQUksQ0FBQyxHQUFXLENBQUMsRUFBRSxDQUFDLEdBQUcsV0FBVyxDQUFDLE1BQU0sRUFBRSxDQUFDLEVBQUUsRUFBRTtZQUNqRCxXQUFXLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxHQUFHLFlBQVksQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDO1lBQ2pELElBQUksT0FBTyxXQUFXLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxLQUFLLFdBQVcsRUFBRTtnQkFDaEQsV0FBVyxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsR0FBRyxLQUFLLENBQUM7Z0JBQ2hDLFdBQVcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLEdBQUcsSUFBSSxDQUFDLGdCQUFnQixDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLEVBQUUsS0FBSyxFQUFFLGFBQWEsQ0FBQyxDQUFDO2FBQ2xHO1lBQ0QsV0FBVyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksR0FBRyxDQUFDLEtBQUssS0FBSyxVQUFVLENBQUMsQ0FBQyxDQUFDLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUM7WUFDcEUsSUFBSSxPQUFPLFdBQVcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsUUFBUSxLQUFLLFdBQVc7Z0JBQUUsV0FBVyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxRQUFRLEdBQUcsS0FBSyxDQUFDO2lCQUN6RixJQUFJLFdBQVcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsUUFBUSxJQUFJLE9BQU8sYUFBYSxLQUFLLFdBQVcsRUFBRTtnQkFDM0UsSUFBSSxDQUFDLGFBQWE7b0JBQUUsYUFBYSxHQUFHLElBQUksQ0FBQzs7b0JBQ3BDLFdBQVcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsUUFBUSxHQUFHLEtBQUssQ0FBQzthQUM3QztTQUNKO1FBQ0QsT0FBTyxXQUFXLENBQUM7SUFDdkIsQ0FBQztJQUdEOzs7Ozs7T0FNRztJQUNILFVBQVUsQ0FBQyxNQUFXLEVBQUUsT0FBZTtRQUNuQyxJQUNJLE9BQU8sTUFBTSxLQUFLLFdBQVc7WUFDN0IsT0FBTyxNQUFNLENBQUMsT0FBTyxDQUFDLEtBQUssV0FBVztZQUN4QyxPQUFPLEtBQUssQ0FBQztRQUNmLE9BQU8sTUFBTSxDQUFDLE9BQU8sQ0FBQyxDQUFDO0lBQzNCLENBQUM7SUFFRDs7OztPQUlHO0lBQ0ssV0FBVyxDQUFDLEtBQWlCO1FBQ2pDLElBQUksRUFBRSxHQUFzQixJQUFJLENBQUM7UUFDakMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxVQUFTLElBQUk7WUFDdkIsSUFBSSxDQUFDLFFBQVEsR0FBRyxJQUFJLENBQUM7WUFDckIsSUFBSSxJQUFJLENBQUMsUUFBUSxFQUFFO2dCQUNmLEVBQUUsQ0FBQyxXQUFXLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxDQUFDO2FBQ2pDO1FBQ0wsQ0FBQyxDQUFDLENBQUM7SUFDUCxDQUFDO0lBRUQ7Ozs7T0FJRztJQUNLLGVBQWUsQ0FBQyxLQUFpQjtRQUNyQyxJQUFJLGVBQXdCLENBQUM7UUFDN0IsS0FBSyxJQUFJLENBQUMsR0FBVyxDQUFDLEVBQUUsQ0FBQyxHQUFHLEtBQUssQ0FBQyxNQUFNLEVBQUUsQ0FBQyxFQUFFLEVBQUU7WUFDM0MsSUFBSSxJQUFJLEdBQWEsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDO1lBQzlCLGVBQWUsR0FBRyxLQUFLLENBQUM7WUFDeEIsSUFBSSxJQUFJLENBQUMsUUFBUSxFQUFFO2dCQUNmLGVBQWUsR0FBRyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxDQUFDO2dCQUN2RCxJQUFJLENBQUMsUUFBUSxHQUFHLGVBQWUsQ0FBQzthQUNuQztpQkFBTTtnQkFDSCxTQUFTO2FBQ1o7U0FDSjtJQUNMLENBQUM7SUFFRDs7Ozs7Ozs7T0FRRztJQUNLLGdCQUFnQixDQUFDLEtBQWlCO1FBQ3RDLEtBQUssSUFBSSxDQUFDLEdBQVcsQ0FBQyxFQUFFLENBQUMsR0FBRyxLQUFLLENBQUMsTUFBTSxFQUFFLENBQUMsRUFBRSxFQUFFO1lBQzNDLElBQUksU0FBUyxHQUFhLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQztZQUNuQyxJQUFJLFNBQVMsQ0FBQyxRQUFRLEVBQUU7Z0JBQ3BCLElBQUksZUFBZSxHQUFZLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxTQUFTLENBQUMsUUFBUSxDQUFDLENBQUM7Z0JBQ3pFLFNBQVMsQ0FBQyxRQUFRLEdBQUcsZUFBZSxDQUFDO2dCQUNyQyxPQUFPLGVBQWUsQ0FBQzthQUMxQjtpQkFBTSxJQUFJLFNBQVMsQ0FBQyxJQUFJLENBQUMsUUFBUSxFQUFFO2dCQUNoQyxPQUFPLFNBQVMsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDO2FBQ2xDO1NBQ0o7UUFDRCxPQUFPLEtBQUssQ0FBQztJQUNqQixDQUFDO0lBRUQ7Ozs7O09BS0c7SUFDSCxjQUFjLENBQUMsT0FBWSxFQUFFLFlBQXdCO1FBQ2pELElBQUksVUFBVSxHQUFtQixJQUFJLENBQUMsVUFBVSxDQUFDLE9BQU8sRUFBRSxXQUFXLENBQUMsQ0FBQztRQUN2RSxJQUFJLGVBQWUsR0FBbUIsSUFBSSxDQUFDLFVBQVUsQ0FBQyxPQUFPLEVBQUUsZ0JBQWdCLENBQUMsQ0FBQztRQUNqRixJQUFJLE9BQU8sVUFBVSxLQUFLLFdBQVcsSUFBSSxPQUFPLGVBQWUsS0FBSyxXQUFXLEVBQUU7WUFDN0UsSUFBSSxVQUFVLEtBQUssTUFBTSxJQUFJLFVBQVUsRUFBRTtnQkFDckMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxZQUFZLENBQUMsQ0FBQzthQUNsQztpQkFBTSxJQUFJLGVBQWUsS0FBSyxNQUFNLElBQUksZUFBZSxFQUFFO2dCQUN0RCxJQUFJLENBQUMsZUFBZSxDQUFDLFlBQVksQ0FBQyxDQUFDO2FBQ3RDO1NBQ0o7SUFDTCxDQUFDO0lBRUQ7Ozs7Ozs7OztPQVNHO0lBQ0gsWUFBWSxDQUFDLEdBQVcsRUFBRSxVQUF5QixFQUFFLFlBQXdCLEVBQUUsSUFBWTtRQUV2RixLQUFLLElBQUksQ0FBQyxHQUFXLENBQUMsRUFBRSxDQUFDLEdBQUcsWUFBWSxDQUFDLE1BQU0sRUFBRSxDQUFDLEVBQUUsRUFBRTtZQUVsRCxJQUFJLFVBQVUsR0FBYSxZQUFZLENBQUMsQ0FBQyxDQUFDLENBQUM7WUFDM0MsSUFBSSxVQUFVLENBQUMsSUFBSSxDQUFDLEVBQUUsS0FBSyxHQUFHLEVBQUU7Z0JBQzVCLElBQUksT0FBTyxVQUFVLENBQUMsUUFBUSxLQUFLLFdBQVcsRUFBRTtvQkFDNUMsVUFBVSxDQUFDLFFBQVEsR0FBRyxFQUFFLENBQUM7aUJBQzVCO2dCQUNELFVBQVUsQ0FBQyxRQUFRLEdBQUcsSUFBSSxDQUFDLGFBQWEsQ0FBQyxVQUFVLEVBQUUsSUFBSSxFQUFFLElBQUksQ0FBQyxDQUFDO2dCQUNqRSxNQUFNO2FBQ1Q7aUJBQU07Z0JBQ0gsSUFBSSxVQUFVLENBQUMsY0FBYyxDQUFDLFVBQVUsQ0FBQyxFQUFFO29CQUN2QyxJQUFJLENBQUMsWUFBWSxDQUFDLEdBQUcsRUFBRSxVQUFVLEVBQUUsVUFBVSxDQUFDLFFBQVEsRUFBRSxJQUFJLENBQUMsQ0FBQztpQkFDakU7YUFDSjtTQUVKO1FBQ0QsT0FBTyxJQUFJLENBQUMsa0JBQWtCLENBQUMsWUFBWSxFQUFFLElBQUksQ0FBQyxDQUFDO0lBQ3ZELENBQUM7OztZQTNVSixVQUFVIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgSW5qZWN0YWJsZSB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xyXG5pbXBvcnQgeyBUcmVlTm9kZSB9IGZyb20gJ3ByaW1lbmcvcHJpbWVuZyc7XHJcblxyXG5ASW5qZWN0YWJsZSgpXHJcbmV4cG9ydCBjbGFzcyBLZFRyZWVEcm9wZG93blN2YyB7XHJcbiAgICAvKipcclxuICAgICAqIGNoYW5nZSBjb25maWcgdG8gcHJpbWVuZyByZWFkYWJsZSB0cmVlIGRhdGFcclxuICAgICAqXHJcbiAgICAgKiBjb25maWcgICAgICA6IFtkYXRhIHBhc3MgZnJvbSBleGFtcGxlXVxyXG4gICAgICogbW9kZSAgICAgICAgOiBbbW9kZSBvZiB0aGUgZHJvcGRvd24gY2hlY2tib3gvbXVsdGlwbGUgb3IgcmFkaW8vc2luZ2xlXVxyXG4gICAgICogaXNDaGlsZERhdGEgOiBbZm9yIGxhenkgbG9hZC4gYXMgd2UgbmVlZCB0byBjb252ZXJ0IGNoaWxkIGRhdGEgZnJvbSBleGFtcGxlIHRvIGJlIFRyZWVOb2RlIHJlYWRhYmxlIGJ5IHByaW1lbmcgdHJlZVxyXG4gICAgICogICAgICAgICAgICAgICAgICAgICBwbHVnaW4sIHdlIHdpbGwgbmVlZCBhIGZsYWcgdG8gZGVjaWRlIHdoaWNoIGRhdGEgdG8gYmUgY29udmVydC4gd2hldGhlciBpdCBpcyB0aGUgY29uZmlnLmxpc3QgKGZvclxyXG4gICAgICogICAgICAgICAgICAgICAgICAgICBjb25maWcpIG9yIGp1c3QgY29uZmlnIChmb3IgY2hpbGQgZGF0YSldXHJcbiAgICAgKiBcclxuICAgICAqL1xyXG4gICAgZ2V0VXBkYXRlTm9kZShjb25maWc6IGFueSwgbW9kZTogc3RyaW5nLCBpc0NoaWxkRGF0YT86IGJvb2xlYW4pOiBBcnJheTxUcmVlTm9kZT4ge1xyXG4gICAgICAgIGxldCB0ZW1wRGF0YTogQXJyYXk8VHJlZU5vZGU+ID0gW107XHJcbiAgICAgICAgaWYgKHR5cGVvZiBjb25maWcgIT09ICd1bmRlZmluZWQnICYmIHR5cGVvZiBjb25maWcubGlzdCAhPT0gJ3VuZGVmaW5lZCcpIHRlbXBEYXRhID0gdGhpcy5fY2xvbmVOZXdBcnJheShjb25maWcubGlzdCk7XHJcbiAgICAgICAgZWxzZSBpZiAodHlwZW9mIGlzQ2hpbGREYXRhICE9PSAndW5kZWZpbmVkJyAmJiBpc0NoaWxkRGF0YSkgdGVtcERhdGEgPSB0aGlzLl9jbG9uZU5ld0FycmF5KGNvbmZpZyk7XHJcbiAgICAgICAgZWxzZSByZXR1cm4gdGVtcERhdGE7XHJcblxyXG4gICAgICAgIGxldCB1cGRhdGVkRGF0YTogQXJyYXk8YW55PiA9IFtdO1xyXG4gICAgICAgIGlmIChtb2RlID09PSAnbXVsdGlwbGUnKSB1cGRhdGVkRGF0YSA9IHRoaXMuX2dldEV4cGFuZGVkQm9vbCh0ZW1wRGF0YSwgbW9kZSk7XHJcbiAgICAgICAgZWxzZSB1cGRhdGVkRGF0YSA9IHRoaXMuX2dldEV4cGFuZGVkQm9vbCh0ZW1wRGF0YSwgbW9kZSwgZmFsc2UpO1xyXG4gICAgICAgIHJldHVybiB1cGRhdGVkRGF0YTtcclxuICAgIH1cclxuXHJcbiAgICAvKipcclxuICAgICAqIGdldCB0aGUgdHJlZWRyb3Bkb3duIGlucHV0IHR5cGUgd2hldGhlciBpdCBpcyBjaGVja2JveCBvciByYWRpb1xyXG4gICAgICpcclxuICAgICAqIGNvbmZpZyAgICA6IFtkYXRhIHBhc3MgZnJvbSBleGFtcGxlXVxyXG4gICAgICogXHJcbiAgICAgKi9cclxuICAgIGdldE1vZGUoY29uZmlnOiBhbnkpOiBzdHJpbmcge1xyXG4gICAgICAgIGlmIChcclxuICAgICAgICAgICAgdHlwZW9mIGNvbmZpZyA9PT0gJ3VuZGVmaW5lZCcgfHxcclxuICAgICAgICAgICAgdHlwZW9mIGNvbmZpZy5zZWxlY3Rpb25Nb2RlID09PSAndW5kZWZpbmVkJyB8fFxyXG4gICAgICAgICAgICAoY29uZmlnLnNlbGVjdGlvbk1vZGUgPT09ICdtdWx0aXBsZScgfHwgY29uZmlnLnNlbGVjdGlvbk1vZGUgPT09ICdzaW5nbGUnKVxyXG4gICAgICAgICkgcmV0dXJuIGNvbmZpZy5zZWxlY3Rpb25Nb2RlO1xyXG4gICAgICAgIHJldHVybiAnc2luZ2xlJztcclxuICAgIH1cclxuXHJcbiAgICAvKipcclxuICAgICAqIGdldCB0aGUgc2VsZWN0ZWQgdmFsdWUuIGlmIGl0IGlzIGNoZWNrYm94LCBhZGQgaW4gdGhlIHNlbGVjdGVkIGRhdGEsIGlmIGl0IGlzIHJhZGlvLCByZXBsYWNlIHRoZSBzZWxlY3RlZCBkYXRhXHJcbiAgICAgKlxyXG4gICAgICogY3VycmVudFNlbGVjdGVkICAgIDogW3ByZXZpb3VzbHkgc2VsZWN0ZWQgZGF0YV1cclxuICAgICAqIHNlbGVjdE5vZGUgICAgICAgICA6IFtzZWxlY3RlZCBub2RlIHByaW1lbmcgZGF0YV1cclxuICAgICAqIG1vZGUgICAgICAgICAgICAgICA6IFtjaGVja2JveC9yYWRpbyB8IG11bHRpcGxlL3NpbmdsZV1cclxuICAgICAqIHJldHVybiBmb3JtYXQgICAgICA6IFt7IGlkLCBuYW1lLCBzZWxlY3RlZDogdHJ1ZSB9XVxyXG4gICAgICovXHJcbiAgICB1cGRhdGVTZWxlY3RlZE5vZGVzKGN1cnJlbnRTZWxlY3RlZDogQXJyYXk8YW55Piwgc2VsZWN0Tm9kZTogYW55LCBtb2RlOiBzdHJpbmcpOiBBcnJheTxhbnk+IHtcclxuICAgICAgICBsZXQgdXBkYXRlQXJyYXk6IEFycmF5PGFueT4gPSBbXTtcclxuICAgICAgICBpZiAobW9kZSA9PT0gJ211bHRpcGxlJykgdXBkYXRlQXJyYXkgPSB0aGlzLl9jaGVja0NoZWNrYm94KGN1cnJlbnRTZWxlY3RlZCwgc2VsZWN0Tm9kZSk7XHJcbiAgICAgICAgZWxzZSBpZiAoc2VsZWN0Tm9kZS5kYXRhLnNlbGVjdGVkKSB1cGRhdGVBcnJheS5wdXNoKHNlbGVjdE5vZGUuZGF0YSk7XHJcbiAgICAgICAgcmV0dXJuIHVwZGF0ZUFycmF5O1xyXG4gICAgfVxyXG5cclxuICAgIC8qKlxyXG4gICAgICogaWYgc2VsZWN0ZWQsIGFkZCBkYXRhIGludG8gc2VsZWN0ZWQgYXJyYXksIGVsc2UgcmVtb3ZlIGZyb20gYXJyYXlcclxuICAgICAqXHJcbiAgICAgKiBjdXJyZW50U2VsZWN0ZWQgICAgOiBbc2VsZWN0ZWQgZGF0YTogeyBpZCwgbmFtZSwgc2VsZWN0ZWQ6IHRydWUgfV1cclxuICAgICAqIHNlbGVjdE5vZGUgICAgICAgICA6IFtzZWxlY3RlZCBub2RlIChwcmltZW5nIG5vZGUpXVxyXG4gICAgICogXHJcbiAgICAgKi9cclxuICAgIHByaXZhdGUgX2NoZWNrQ2hlY2tib3goY3VycmVudFNlbGVjdGVkOiBBcnJheTxhbnk+LCBzZWxlY3ROb2RlOiBhbnkpOiBBcnJheTxhbnk+IHtcclxuICAgICAgICBsZXQgdXBkYXRlZEFycmF5OiBBcnJheTxhbnk+ID0gY3VycmVudFNlbGVjdGVkLnNsaWNlKDApIHx8IFtdO1xyXG4gICAgICAgIGlmIChzZWxlY3ROb2RlLmRhdGEuc2VsZWN0ZWQpIHVwZGF0ZWRBcnJheS5wdXNoKHNlbGVjdE5vZGUuZGF0YSk7XHJcbiAgICAgICAgZWxzZSB7XHJcbiAgICAgICAgICAgIGZvciAobGV0IGk6IG51bWJlciA9IDA7IGkgPCBjdXJyZW50U2VsZWN0ZWQubGVuZ3RoOyBpKyspIHtcclxuICAgICAgICAgICAgICAgIGlmIChzZWxlY3ROb2RlLmRhdGEuaWQgPT09IGN1cnJlbnRTZWxlY3RlZFtpXS5pZCkge1xyXG4gICAgICAgICAgICAgICAgICAgIHVwZGF0ZWRBcnJheS5zcGxpY2UoaSwgMSk7XHJcbiAgICAgICAgICAgICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICAgICAgcmV0dXJuIHVwZGF0ZWRBcnJheTtcclxuICAgIH1cclxuXHJcbiAgICAvKipcclxuICAgICAqIFVwZGF0ZSB0aGUgc2VsZWN0ZWQgZGF0YVxyXG4gICAgICpcclxuICAgICAqIGN1cnJlbnREYXRhICAgIDogW2FsbCBkYXRhXVxyXG4gICAgICogbW9kZSAgICAgICAgICAgOiBbY2hlY2tib3gvcmFkaW8gfCBtdWx0aXBsZS9zaW5nbGVdXHJcbiAgICAgKiBcclxuICAgICAqL1xyXG4gICAgdXBkYXRlSW5pdFNlbGVjdGVkKGN1cnJlbnREYXRhOiBBcnJheTxhbnk+LCBtb2RlOiBzdHJpbmcpOiBBcnJheTxhbnk+IHtcclxuICAgICAgICBsZXQgdXBkYXRlZERhdGE6IEFycmF5PGFueT4gPSBbXTtcclxuICAgICAgICBpZiAobW9kZSA9PT0gJ211bHRpcGxlJykgdXBkYXRlZERhdGEgPSB0aGlzLmdldEluaXRTZWxlY3RlZCh1cGRhdGVkRGF0YSwgY3VycmVudERhdGEpO1xyXG4gICAgICAgIGVsc2UgdXBkYXRlZERhdGEgPSB0aGlzLmdldEluaXRTZWxlY3RlZCh1cGRhdGVkRGF0YSwgY3VycmVudERhdGEsIGZhbHNlKTtcclxuICAgICAgICByZXR1cm4gdXBkYXRlZERhdGE7XHJcbiAgICB9XHJcblxyXG4gICAgLyoqXHJcbiAgICAgKiBDaGFuZ2UgZHJvcGRvd24gbGFiZWwuIEVpdGhlciBcIlBsZWFzZSBzZWxlY3RcIiBvciBudW1iZXIgb2YgaXRlbSBzZWxlY3RlZFxyXG4gICAgICpcclxuICAgICAqIHNlbGVjdGVkTm9kZXMgICAgOiBbc2VsZWN0ZWQgZGF0YV1cclxuICAgICAqIFxyXG4gICAgICovXHJcbiAgICB1cGRhdGVTZWxlY3RlZFN0cmluZyhzZWxlY3RlZE5vZGVzOiBBcnJheTxhbnk+KTogc3RyaW5nIHtcclxuICAgICAgICBpZiAodHlwZW9mIHNlbGVjdGVkTm9kZXMgPT09ICd1bmRlZmluZWQnIHx8IHNlbGVjdGVkTm9kZXMubGVuZ3RoID09PSAwKSByZXR1cm4gJ1BsZWFzZSBzZWxlY3QnO1xyXG4gICAgICAgIGVsc2UgaWYgKHNlbGVjdGVkTm9kZXMubGVuZ3RoID09PSAxKSByZXR1cm4gc2VsZWN0ZWROb2Rlc1swXS5uYW1lO1xyXG4gICAgICAgIGVsc2UgcmV0dXJuIHNlbGVjdGVkTm9kZXMubGVuZ3RoICsgJyBpdGVtcyBzZWxlY3RlZCc7XHJcbiAgICB9XHJcblxyXG4gICAgLyoqXHJcbiAgICAgKiBjaGVjayBpZiB0aGUgbW91c2UvdG91Y2ggaXMgd2l0aGluIHRoZSBkcm9wZG93biBsaXN0IChvcHRpb24gbGlzdCkgYm94XHJcbiAgICAgKlxyXG4gICAgICogc3RhdGUgICAgICAgICA6IFtibHVyOiBjbGljayBvciBzY3JvbGxdXHJcbiAgICAgKiBwb3NpdGlvbiAgICAgIDogW3Bvc2l0aW9uIG9mIHRoZSBtb3VzZS90b3VjaF1cclxuICAgICAqIGlkICAgICAgICAgICAgOiBbdHJlZSBpZF1cclxuICAgICAqIGN1cnJlbnRFbGUgICAgOiBbZHJvcGRvd24gbGlzdF1cclxuICAgICAqIFxyXG4gICAgICovXHJcbiAgICBjaGVja1dpdGhpbkJvdW5kaW5nQm94KHN0YXRlOiBzdHJpbmcsIHBvc2l0aW9uOiBhbnksIGlkOiBzdHJpbmcsIGN1cnJlbnRFbGU/OiBIVE1MRWxlbWVudCk6IGJvb2xlYW4ge1xyXG4gICAgICAgIGxldCBxdWVyeVN0cmluZzogc3RyaW5nID0gJy4nICsgaWQgKyAnLmtkeC1wb3BvdmVyLXdpbmRvdyc7XHJcbiAgICAgICAgbGV0IHBvcG92ZXJXaW5kb3c6IEVsZW1lbnQgPSBkb2N1bWVudC5xdWVyeVNlbGVjdG9yKHF1ZXJ5U3RyaW5nKTtcclxuICAgICAgICBsZXQgcG9wb3ZlcldpbmRvd1JlY3Q6IENsaWVudFJlY3QgPSBwb3BvdmVyV2luZG93LmdldEJvdW5kaW5nQ2xpZW50UmVjdCgpO1xyXG4gICAgICAgIGlmIChwb3BvdmVyV2luZG93ID09PSBudWxsKSByZXR1cm4gZmFsc2U7XHJcbiAgICAgICAgbGV0IGJvdW5kaW5nUmVjdDogYW55ID0ge1xyXG4gICAgICAgICAgICB0b3A6IChzdGF0ZSA9PT0gJ2JsdXInKSA/IGN1cnJlbnRFbGUuZ2V0Qm91bmRpbmdDbGllbnRSZWN0KCkudG9wIDogcG9wb3ZlcldpbmRvd1JlY3QudG9wLFxyXG4gICAgICAgICAgICBib3R0b206IHBvcG92ZXJXaW5kb3dSZWN0LmJvdHRvbSxcclxuICAgICAgICAgICAgcmlnaHQ6IHBvcG92ZXJXaW5kb3dSZWN0LnJpZ2h0LFxyXG4gICAgICAgICAgICBsZWZ0OiBwb3BvdmVyV2luZG93UmVjdC5sZWZ0XHJcbiAgICAgICAgfTtcclxuICAgICAgICBpZiAocG9zaXRpb24ueCA+IGJvdW5kaW5nUmVjdC5sZWZ0ICYmIHBvc2l0aW9uLnggPCBib3VuZGluZ1JlY3QucmlnaHQgJiZcclxuICAgICAgICAgICAgcG9zaXRpb24ueSA+IGJvdW5kaW5nUmVjdC50b3AgJiYgcG9zaXRpb24ueSA8IGJvdW5kaW5nUmVjdC5ib3R0b20pIHJldHVybiB0cnVlO1xyXG4gICAgICAgIHJldHVybiBmYWxzZTtcclxuICAgIH1cclxuXHJcbiAgICAvKipcclxuICAgICAqIGdldCBwb3NpdGlvbiBmb3IgdGhlIG1vdXNlL3RvdWNoICBpbiB4IGFuZCB5XHJcbiAgICAgKlxyXG4gICAgICogZSAgICA6IFttb3VzZS90b3VjaCBldmVudF1cclxuICAgICAqIFxyXG4gICAgICovXHJcbiAgICBnZXRUb3VjaFBvc2l0aW9uKGU6IFRvdWNoRXZlbnQpOiBhbnkge1xyXG4gICAgICAgIGxldCBwb3NpdGlvbjogYW55ID0geyB4OiAwLCB5OiAwIH07XHJcbiAgICAgICAgdHJ5IHtcclxuICAgICAgICAgICAgcG9zaXRpb24ueCA9IGUudG91Y2hlc1swXS5jbGllbnRYO1xyXG4gICAgICAgICAgICBwb3NpdGlvbi55ID0gZS50b3VjaGVzWzBdLmNsaWVudFk7XHJcbiAgICAgICAgfSBjYXRjaCAoZXJyKSB7XHJcbiAgICAgICAgICAgIHBvc2l0aW9uLnggPSBlLnRhcmdldFRvdWNoZXNbMF0uY2xpZW50WDtcclxuICAgICAgICAgICAgcG9zaXRpb24ueSA9IGUudGFyZ2V0VG91Y2hlc1swXS5jbGllbnRZO1xyXG4gICAgICAgIH1cclxuICAgICAgICByZXR1cm4gcG9zaXRpb247XHJcbiAgICB9XHJcblxyXG4gICAgLyoqXHJcbiAgICAgKiBXaGVuIGZpcnN0IGxvYWQsIGdldCB0aGUgc2VsZWN0ZWQgZGF0YS4gaWYgbW9kZSBpcyByYWRpbywgb25seSByZXR1cm4gdGhlIGZpcnN0IGRhdGEgdGhhdCBpcyBzZWxlY3RlZCBpbiB0aGUgY3VycmVudCBBcnJheS5cclxuICAgICAqIFByZXZpb3VzIHNlbGVjdGVkIGRhdGEgb3IgdGhlIGZvbGxvd2luZyBzZWxlY3RlZCBkYXRhIHdpbGwgYmUgcmVtb3ZlZC5cclxuICAgICAqXHJcbiAgICAgKiBzZWxlY3RlZEFycmF5ICAgIDogW3NlbGVjdGVkIGFycmF5IGVpdGhlciBlbXB0eSBvciBhcnJheSBvZiBkYXRhIGZvciBtdWx0aXBsZSBzZWxlY3Rpb24gbW9kZV1cclxuICAgICAqIGN1cnJlbnRBcnJheSAgICAgOiBbYWxsIGRhdGFdXHJcbiAgICAgKiBpc1NpbmdsZUZvdW5kICAgIDogW2lmIHJhZGlvL3NpbmdsZSBtb2RlLCB0cnVlIGVsc2UgdW5kZWZpbmVkXVxyXG4gICAgICovXHJcbiAgICBwcml2YXRlIGdldEluaXRTZWxlY3RlZChzZWxlY3RlZEFycmF5OiBBcnJheTxhbnk+LCBjdXJyZW50QXJyYXk6IEFycmF5PGFueT4sIGlzU2luZ2xlRm91bmQ/OiBib29sZWFuKTogQXJyYXk8YW55PiB7XHJcbiAgICAgICAgbGV0IHVwZGF0ZWRBcnJheTogQXJyYXk8YW55PiA9IHNlbGVjdGVkQXJyYXkuc2xpY2UoMCk7XHJcbiAgICAgICAgbGV0IGxvb3BTaW5nbGVGb3VuZDogYm9vbGVhbiA9IHVuZGVmaW5lZDtcclxuICAgICAgICBpZiAodHlwZW9mIGlzU2luZ2xlRm91bmQgIT09ICd1bmRlZmluZWQnKSBsb29wU2luZ2xlRm91bmQgPSBpc1NpbmdsZUZvdW5kO1xyXG4gICAgICAgIGZvciAobGV0IGk6IG51bWJlciA9IDA7IGkgPCBjdXJyZW50QXJyYXkubGVuZ3RoOyBpKyspIHtcclxuICAgICAgICAgICAgaWYgKGxvb3BTaW5nbGVGb3VuZCkgYnJlYWs7XHJcbiAgICAgICAgICAgIGlmIChjdXJyZW50QXJyYXlbaV0uZGF0YS5zZWxlY3RlZCkge1xyXG4gICAgICAgICAgICAgICAgdXBkYXRlZEFycmF5LnB1c2goY3VycmVudEFycmF5W2ldLmRhdGEpO1xyXG4gICAgICAgICAgICAgICAgaWYgKHR5cGVvZiBpc1NpbmdsZUZvdW5kICE9PSAndW5kZWZpbmVkJykgbG9vcFNpbmdsZUZvdW5kID0gdHJ1ZTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBpZiAodHlwZW9mIGN1cnJlbnRBcnJheVtpXS5jaGlsZHJlbiAhPT0gJ3VuZGVmaW5lZCcpIHVwZGF0ZWRBcnJheSA9IHRoaXMuZ2V0SW5pdFNlbGVjdGVkKHVwZGF0ZWRBcnJheSwgY3VycmVudEFycmF5W2ldLmNoaWxkcmVuLCBsb29wU2luZ2xlRm91bmQpO1xyXG4gICAgICAgIH1cclxuICAgICAgICByZXR1cm4gdXBkYXRlZEFycmF5O1xyXG4gICAgfVxyXG5cclxuICAgIC8qKlxyXG4gICAgICogZG8gYSBjb3B5IG9mIGFycmF5XHJcbiAgICAgKlxyXG4gICAgICogb2xkQXJyYXkgICAgOiBbYXJyYXkgdGhhdCB5b3Ugd291bGQgbGlrZSB0byBjb3B5XVxyXG4gICAgICogXHJcbiAgICAgKi9cclxuICAgIHByaXZhdGUgX2Nsb25lTmV3QXJyYXkob2xkQXJyYXk6IEFycmF5PFRyZWVOb2RlPik6IEFycmF5PFRyZWVOb2RlPiB7XHJcbiAgICAgICAgbGV0IG5ld0FycmF5OiBBcnJheTxUcmVlTm9kZT4gPSBbXTtcclxuICAgICAgICBmb3IgKGxldCBpOiBudW1iZXIgPSAwOyBpIDwgb2xkQXJyYXkubGVuZ3RoOyBpKyspIHtcclxuICAgICAgICAgICAgbGV0IGl0ZW06IFRyZWVOb2RlID0gT2JqZWN0LmFzc2lnbih7fSwgb2xkQXJyYXlbaV0pO1xyXG4gICAgICAgICAgICBpdGVtLmRhdGEgPSBPYmplY3QuYXNzaWduKHt9LCBvbGRBcnJheVtpXS5kYXRhKTtcclxuICAgICAgICAgICAgaWYgKHR5cGVvZiBvbGRBcnJheVtpXS5jaGlsZHJlbiAhPT0gJ3VuZGVmaW5lZCcpIGl0ZW0uY2hpbGRyZW4gPSB0aGlzLl9jbG9uZU5ld0FycmF5KG9sZEFycmF5W2ldLmNoaWxkcmVuKTtcclxuICAgICAgICAgICAgbmV3QXJyYXkucHVzaChpdGVtKTtcclxuICAgICAgICB9XHJcbiAgICAgICAgcmV0dXJuIG5ld0FycmF5O1xyXG4gICAgfVxyXG5cclxuICAgIC8qKlxyXG4gICAgICogc2V0IGFsbCBkYXRhIGFzIG5vdCBleHBhbmRlZCBhbmQgY29udmVydCBhbGwgZGF0YSBpbnRvIHByaW1lbmcgdHJlZSBwbHVnaW4gcmVhZGFibGUgZGF0YVxyXG4gICAgICpcclxuICAgICAqIF9jdXJyZW50RGF0YSAgICAgIDogW2FsbCBkYXRhXVxyXG4gICAgICogX21vZGUgICAgICAgICAgICAgOiBbY2hlY2tib3gvcmFkaW8gfCBzaW5nbGUvbXVsdGlwbGUgXVxyXG4gICAgICogX2lzU2luZ2xlU2VsZWN0ZWQgOlxyXG4gICAgICogXHJcbiAgICAgKi9cclxuICAgIHByaXZhdGUgX2dldEV4cGFuZGVkQm9vbChfY3VycmVudERhdGE6IEFycmF5PFRyZWVOb2RlPiwgX21vZGU6IHN0cmluZywgX2lzU2luZ2xlU2VsZWN0ZWQ/OiBib29sZWFuKTogQXJyYXk8VHJlZU5vZGU+IHtcclxuICAgICAgICBsZXQgaXNTaW5nbGVGb3VuZDogYm9vbGVhbiA9IF9pc1NpbmdsZVNlbGVjdGVkO1xyXG4gICAgICAgIGxldCB1cGRhdGVkRGF0YTogQXJyYXk8VHJlZU5vZGU+ID0gX2N1cnJlbnREYXRhLnNsaWNlKDApO1xyXG4gICAgICAgIGZvciAobGV0IGk6IG51bWJlciA9IDA7IGkgPCB1cGRhdGVkRGF0YS5sZW5ndGg7IGkrKykge1xyXG4gICAgICAgICAgICB1cGRhdGVkRGF0YVtpXS5sYWJlbCA9IF9jdXJyZW50RGF0YVtpXS5kYXRhLm5hbWU7XHJcbiAgICAgICAgICAgIGlmICh0eXBlb2YgdXBkYXRlZERhdGFbaV0uY2hpbGRyZW4gIT09ICd1bmRlZmluZWQnKSB7XHJcbiAgICAgICAgICAgICAgICB1cGRhdGVkRGF0YVtpXS5leHBhbmRlZCA9IGZhbHNlO1xyXG4gICAgICAgICAgICAgICAgdXBkYXRlZERhdGFbaV0uY2hpbGRyZW4gPSB0aGlzLl9nZXRFeHBhbmRlZEJvb2wodXBkYXRlZERhdGFbaV0uY2hpbGRyZW4sIF9tb2RlLCBpc1NpbmdsZUZvdW5kKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB1cGRhdGVkRGF0YVtpXS50eXBlID0gKF9tb2RlID09PSAnbXVsdGlwbGUnKSA/ICdjaGVja2JveCcgOiAncmFkaW8nO1xyXG4gICAgICAgICAgICBpZiAodHlwZW9mIHVwZGF0ZWREYXRhW2ldLmRhdGEuc2VsZWN0ZWQgPT09ICd1bmRlZmluZWQnKSB1cGRhdGVkRGF0YVtpXS5kYXRhLnNlbGVjdGVkID0gZmFsc2U7XHJcbiAgICAgICAgICAgIGVsc2UgaWYgKHVwZGF0ZWREYXRhW2ldLmRhdGEuc2VsZWN0ZWQgJiYgdHlwZW9mIGlzU2luZ2xlRm91bmQgIT09ICd1bmRlZmluZWQnKSB7XHJcbiAgICAgICAgICAgICAgICBpZiAoIWlzU2luZ2xlRm91bmQpIGlzU2luZ2xlRm91bmQgPSB0cnVlO1xyXG4gICAgICAgICAgICAgICAgZWxzZSB1cGRhdGVkRGF0YVtpXS5kYXRhLnNlbGVjdGVkID0gZmFsc2U7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICAgICAgcmV0dXJuIHVwZGF0ZWREYXRhO1xyXG4gICAgfVxyXG5cclxuXHJcbiAgICAvKipcclxuICAgICAqIGVycm9yIHByZXZlbnRpb24gc2V0IGZhbHNlIGlmIGRhdGEgcGFzc2VkIGluIGlzIHVuZGVmaW5lZC4gbGVhdmUgdGhlIGRhdGEgYXMgaXQgaXMgaWYgaXQgaXMgbm90IHVuZGVmaW5lZFxyXG4gICAgICpcclxuICAgICAqIGNvbmZpZyAgICAgOiBbY29uZmlnXVxyXG4gICAgICogc2V0dGluZyAgICA6IFthbnkgc2V0dGluZy4gY2FuIGJlIG1vZGUsIGNhbiBiZSBleHBhbmRTZWxlY3RlZCBvciBleHBhbmRBbGxdXHJcbiAgICAgKiBcclxuICAgICAqL1xyXG4gICAgZ2V0U2V0dGluZyhjb25maWc6IGFueSwgc2V0dGluZzogc3RyaW5nKTogKGJvb2xlYW58c3RyaW5nKSB7XHJcbiAgICAgICAgaWYgKFxyXG4gICAgICAgICAgICB0eXBlb2YgY29uZmlnID09PSAndW5kZWZpbmVkJyB8fFxyXG4gICAgICAgICAgICB0eXBlb2YgY29uZmlnW3NldHRpbmddID09PSAndW5kZWZpbmVkJ1xyXG4gICAgICAgICkgcmV0dXJuIGZhbHNlO1xyXG4gICAgICAgIHJldHVybiBjb25maWdbc2V0dGluZ107XHJcbiAgICB9XHJcblxyXG4gICAgLyoqXHJcbiAgICAgKiBmb3IgZXhwYW5kQWxsLiBleHBhbmQgdGhlIGRhdGEgYXMgbG9uZyBhcyB0aGVyZSBpcyBhIGNoaWxkIGRhdGFcclxuICAgICAqXHJcbiAgICAgKiBfbGlzdCAgICA6IFtjb25maWcgbGlzdF1cclxuICAgICAqL1xyXG4gICAgcHJpdmF0ZSBfZXhwYW5kTGlzdChfbGlzdDogVHJlZU5vZGVbXSk6IHZvaWQge1xyXG4gICAgICAgIGxldCB2bTogS2RUcmVlRHJvcGRvd25TdmMgPSB0aGlzO1xyXG4gICAgICAgIF9saXN0LmZvckVhY2goZnVuY3Rpb24oaXRlbSkge1xyXG4gICAgICAgICAgICBpdGVtLmV4cGFuZGVkID0gdHJ1ZTtcclxuICAgICAgICAgICAgaWYgKGl0ZW0uY2hpbGRyZW4pIHtcclxuICAgICAgICAgICAgICAgIHZtLl9leHBhbmRMaXN0KGl0ZW0uY2hpbGRyZW4pO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfSk7XHJcbiAgICB9XHJcblxyXG4gICAgLyoqXHJcbiAgICAgKiBvbmx5IGV4cGFuZCB0aGUgcGFyZW50IGRhdGEgaWYgdGhlIGNoaWxkIHZhbHVlIGlzIHNlbGVjdGVkXHJcbiAgICAgKlxyXG4gICAgICogX2xpc3QgOiBbY29uZmlnIGxpc3RdXHJcbiAgICAgKi9cclxuICAgIHByaXZhdGUgX2V4cGFuZFNlbGVjdGVkKF9saXN0OiBUcmVlTm9kZVtdKTogdm9pZCB7XHJcbiAgICAgICAgbGV0IGlzQ2hpbGRTZWxlY3RlZDogYm9vbGVhbjtcclxuICAgICAgICBmb3IgKGxldCBpOiBudW1iZXIgPSAwOyBpIDwgX2xpc3QubGVuZ3RoOyBpKyspIHtcclxuICAgICAgICAgICAgbGV0IGl0ZW06IFRyZWVOb2RlID0gX2xpc3RbaV07XHJcbiAgICAgICAgICAgIGlzQ2hpbGRTZWxlY3RlZCA9IGZhbHNlO1xyXG4gICAgICAgICAgICBpZiAoaXRlbS5jaGlsZHJlbikge1xyXG4gICAgICAgICAgICAgICAgaXNDaGlsZFNlbGVjdGVkID0gdGhpcy5fZXhwYW5kQ2hpbGRMaXN0KGl0ZW0uY2hpbGRyZW4pO1xyXG4gICAgICAgICAgICAgICAgaXRlbS5leHBhbmRlZCA9IGlzQ2hpbGRTZWxlY3RlZDtcclxuICAgICAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgICAgIGNvbnRpbnVlO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIC8qKlxyXG4gICAgICogbWFpbiBwdXJwb3NlIGlzIHRvIHJldHVybiB0cnVlIGlmIHRoZXJlIGlzIGEgc2VsZWN0ZWQgZGF0YS4gdGhpcyBsb29wIHNob3VsZCBsb29wXHJcbiAgICAgKiB0aHJvdWdoIGFsbCB0aGUgd2F5IHVudGlsIHRoZSBsYXN0IGNoaWxkIGl0ZW0gYXQgdGhlIHNhbWUgdGltZSwgZXZlcnkgc2luZ2xlIGxvb3AsXHJcbiAgICAgKiBpdCBzaG91bGQgc2V0IHRoZSBsYXllciBhYm92ZSB0aGUgY3VycmVudCBjaGlsZCBsaXN0IHRvIGV4cGFuZCB0cnVlIGlmIHRoZSBjdXJyZW50XHJcbiAgICAgKiBjaGlsZCBsaXN0IGlzIHNlbGVjdGVkXHJcbiAgICAgKlxyXG4gICAgICogX2xpc3QgOlxyXG4gICAgICogXHJcbiAgICAgKi9cclxuICAgIHByaXZhdGUgX2V4cGFuZENoaWxkTGlzdChfbGlzdDogVHJlZU5vZGVbXSk6IGJvb2xlYW4ge1xyXG4gICAgICAgIGZvciAobGV0IHg6IG51bWJlciA9IDA7IHggPCBfbGlzdC5sZW5ndGg7IHgrKykge1xyXG4gICAgICAgICAgICBsZXQgY2hpbGRJdGVtOiBUcmVlTm9kZSA9IF9saXN0W3hdO1xyXG4gICAgICAgICAgICBpZiAoY2hpbGRJdGVtLmNoaWxkcmVuKSB7XHJcbiAgICAgICAgICAgICAgICBsZXQgaXNDaGlsZFNlbGVjdGVkOiBib29sZWFuID0gdGhpcy5fZXhwYW5kQ2hpbGRMaXN0KGNoaWxkSXRlbS5jaGlsZHJlbik7XHJcbiAgICAgICAgICAgICAgICBjaGlsZEl0ZW0uZXhwYW5kZWQgPSBpc0NoaWxkU2VsZWN0ZWQ7XHJcbiAgICAgICAgICAgICAgICByZXR1cm4gaXNDaGlsZFNlbGVjdGVkO1xyXG4gICAgICAgICAgICB9IGVsc2UgaWYgKGNoaWxkSXRlbS5kYXRhLnNlbGVjdGVkKSB7XHJcbiAgICAgICAgICAgICAgICByZXR1cm4gY2hpbGRJdGVtLmRhdGEuc2VsZWN0ZWQ7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICAgICAgcmV0dXJuIGZhbHNlO1xyXG4gICAgfVxyXG5cclxuICAgIC8qKlxyXG4gICAgICogbWFpbiBmdW5jdGlvbiB0byBjaGVjayBhbmQgdHJpZ2dlciB3aGV0aGVyIHRvIGV4cGFuZCBhbGwgb3IgZXhwYW5kIHNlbGVjdGVkXHJcbiAgICAgKlxyXG4gICAgICogX2NvbmZpZyAgICAgIDogW2NvbmZpZ11cclxuICAgICAqIF91cGRhdGVkRGF0YSA6IFtwcmltZW5nIHRyZWUgZGF0YV1cclxuICAgICAqL1xyXG4gICAgYXV0b0V4cGFuZExpc3QoX2NvbmZpZzogYW55LCBfdXBkYXRlZERhdGE6IFRyZWVOb2RlW10pOiB2b2lkIHtcclxuICAgICAgICBsZXQgX2V4cGFuZEFsbDogYm9vbGVhbnxzdHJpbmcgPSB0aGlzLmdldFNldHRpbmcoX2NvbmZpZywgJ2V4cGFuZEFsbCcpO1xyXG4gICAgICAgIGxldCBfZXhwYW5kU2VsZWN0ZWQ6IGJvb2xlYW58c3RyaW5nID0gdGhpcy5nZXRTZXR0aW5nKF9jb25maWcsICdleHBhbmRTZWxlY3RlZCcpO1xyXG4gICAgICAgIGlmICh0eXBlb2YgX2V4cGFuZEFsbCAhPT0gJ3VuZGVmaW5lZCcgfHwgdHlwZW9mIF9leHBhbmRTZWxlY3RlZCAhPT0gJ3VuZGVmaW5lZCcpIHtcclxuICAgICAgICAgICAgaWYgKF9leHBhbmRBbGwgPT09ICd0cnVlJyB8fCBfZXhwYW5kQWxsKSB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLl9leHBhbmRMaXN0KF91cGRhdGVkRGF0YSk7XHJcbiAgICAgICAgICAgIH0gZWxzZSBpZiAoX2V4cGFuZFNlbGVjdGVkID09PSAndHJ1ZScgfHwgX2V4cGFuZFNlbGVjdGVkKSB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLl9leHBhbmRTZWxlY3RlZChfdXBkYXRlZERhdGEpO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIC8qKlxyXG4gICAgICogdXNlZCB3aGVuIGFkZGluZyBjaGlsZCBkYXRhIG1hbnVhbGx5IGR1cmluZyBjaGlsZCBkYXRhIGxhenkgbG9hZC4gd2hlbiB1c2VyIGNsaWNrIHRvIGV4cGFuZCBjaGlsZCBsaXN0XHJcbiAgICAgKiB0aGUgZXhhbXBsZSB3aWxsIHBhc3MgaW4gY2hpbGQgZGF0YSB3aGljaCBpcyBub3QgdG8gdGhlIHByaW1lbmcgdHJlZSBwbHVnaW4gcmVhZGFibGUgZGF0YVxyXG4gICAgICpcclxuICAgICAqIF9pZCAgICAgICAgICAgICA6XHJcbiAgICAgKiBfY2hpbGREYXRhICAgICAgOlxyXG4gICAgICogX3VwZGF0ZWREYXRhICAgIDpcclxuICAgICAqIG1vZGUgICAgICAgICAgICA6XHJcbiAgICAgKiBcclxuICAgICAqL1xyXG4gICAgdXBkYXRlQ29uZmlnKF9pZDogc3RyaW5nLCBfY2hpbGREYXRhOiBBcnJheTxvYmplY3Q+LCBfdXBkYXRlZERhdGE6IFRyZWVOb2RlW10sIG1vZGU6IHN0cmluZyk6IEFycmF5PFRyZWVOb2RlPiB7XHJcblxyXG4gICAgICAgIGZvciAobGV0IGk6IG51bWJlciA9IDA7IGkgPCBfdXBkYXRlZERhdGEubGVuZ3RoOyBpKyspIHtcclxuXHJcbiAgICAgICAgICAgIGxldCBjb25maWdMaXN0OiBUcmVlTm9kZSA9IF91cGRhdGVkRGF0YVtpXTtcclxuICAgICAgICAgICAgaWYgKGNvbmZpZ0xpc3QuZGF0YS5pZCA9PT0gX2lkKSB7XHJcbiAgICAgICAgICAgICAgICBpZiAodHlwZW9mIGNvbmZpZ0xpc3QuY2hpbGRyZW4gPT09ICd1bmRlZmluZWQnKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgY29uZmlnTGlzdC5jaGlsZHJlbiA9IFtdO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgY29uZmlnTGlzdC5jaGlsZHJlbiA9IHRoaXMuZ2V0VXBkYXRlTm9kZShfY2hpbGREYXRhLCBtb2RlLCB0cnVlKTtcclxuICAgICAgICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgaWYgKGNvbmZpZ0xpc3QuaGFzT3duUHJvcGVydHkoJ2NoaWxkcmVuJykpIHtcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLnVwZGF0ZUNvbmZpZyhfaWQsIF9jaGlsZERhdGEsIGNvbmZpZ0xpc3QuY2hpbGRyZW4sIG1vZGUpO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9XHJcblxyXG4gICAgICAgIH1cclxuICAgICAgICByZXR1cm4gdGhpcy51cGRhdGVJbml0U2VsZWN0ZWQoX3VwZGF0ZWREYXRhLCBtb2RlKTtcclxuICAgIH1cclxufVxyXG4iXX0=