import { Component, ViewContainerRef, Input, Output, EventEmitter, ViewEncapsulation, HostListener, Renderer2 } from '@angular/core';
import { timer } from 'rxjs';
import { KdTreeDropdownSvc } from './kd-treedropdown-svc';
import { KdDomElemSvc } from '../kd-common/index';
import { KdTreeDropdownEvent } from './kd-treedropdown-event';
export class KdTreeDropdown {
    constructor(_tddSvc, _vcr, _domSvc, _renderer, _treeDropdownEvent) {
        this._tddSvc = _tddSvc;
        this._vcr = _vcr;
        this._domSvc = _domSvc;
        this._renderer = _renderer;
        this._treeDropdownEvent = _treeDropdownEvent;
        this._updatedData = [];
        this._treeId = '';
        this._hide = true;
        this.selectedString = '';
        this.selectionMode = '';
        this._selectedNodes = [];
        this._wheelEvt = null;
        this._loadingIconList = {};
        this.eventSelectedNodes = new EventEmitter();
    }
    onResize() {
        this._hide = true;
        this._setPopWidthHeight();
    }
    onDocClick(docClickEvent) {
        this._setToggle(false, 'blur', docClickEvent);
    }
    onWheel(winMouseEvent) {
        if (this._wheelEvt === null) {
            this._wheelEvt = winMouseEvent;
        }
        let position = { x: this._wheelEvt.clientX, y: this._wheelEvt.clientY };
        if (this._tddSvc.checkWithinBoundingBox('notblur', position, this._treeId)) {
            clearTimeout(this._timer);
            this._timer = setTimeout(() => {
                this._setToggle(false, 'scroll', this._wheelEvt);
                this._wheelEvt = null;
            }, 50);
        }
        else {
            this._hide = true;
            this._wheelEvt = null;
        }
    }
    ngOnInit() {
        this._treeId = (typeof this.config.id !== 'undefined') ? this.config.id : 'tree-class';
        this.selectionMode = this._tddSvc.getMode(this.config);
        if (typeof this.config.list === 'undefined') {
            this.config.list = [];
        }
        // let tempData: Array<any> = this._tddSvc.getUpdateNode(this.config, this.selectionMode);
        this._updatedData = this._tddSvc.getUpdateNode(this.config, this.selectionMode);
        // this._updatedData = JSON.parse(JSON.stringify(tempData));
        this._setTouchListenerAndFF();
        this._selectedNodes = this._tddSvc.updateInitSelected(this._updatedData, this.selectionMode);
        timer().subscribe(() => {
            this._updateAndEmit();
        });
    }
    ngAfterViewInit() {
        this._setBodyPosition(true);
    }
    ngOnDestroy() {
        clearTimeout(this._timer);
        let queryString = '.' + this._treeId + '.kdx-popover-window';
        this._domSvc.removeElementByClass(queryString);
        this._touchendEvent();
        this._touchmoveEvent();
        this._firefoxMouseEvent();
    }
    nodeSelect(_data) {
        if (this.selectionMode === 'multiple')
            _data.node.data.selected = !_data.node.data.selected;
        else {
            if (typeof this._singleSelectionPrevious !== 'undefined')
                this._singleSelectionPrevious.node.data.selected = false;
            _data.node.data.selected = true;
            this._singleSelectionPrevious = _data;
        }
        this._selectedNodes = this._tddSvc.updateSelectedNodes(this._selectedNodes, _data.node, this.selectionMode);
        this._updateAndEmit();
    }
    loadNode(_event) {
        if (!_event.node.children || _event.node.children.length <= 0) {
            this._showLoadingIcon(_event.originalEvent.target, true);
            if (_event.node) {
                this._initChildApi(_event.node.data.id, _event.originalEvent.target);
            }
        }
    }
    showPop() {
        this._hide = !this._hide;
        this._setBodyPosition(false);
        this._setPopWidthHeight();
        this._tddSvc.autoExpandList(this.config, this._updatedData);
        if (this.config.list.length === 0) {
            let loadingIcon = this._vcr.element.nativeElement.parentNode;
            this._showLoadingIcon(loadingIcon, true, true);
            this._initParentApi(loadingIcon);
        }
    }
    _initParentApi(_loadingIcon) {
        this._loadingIconList[this._treeId] = _loadingIcon;
        let vm = this;
        this.api.updateList = (_treeId, _listData) => {
            vm._showLoadingIcon(vm._loadingIconList[_treeId], false);
            vm.config.list = _listData;
            vm._updatedData = vm._tddSvc.getUpdateNode(vm.config, vm.selectionMode);
            vm._selectedNodes = vm._tddSvc.updateInitSelected(vm._updatedData, vm.selectionMode);
            vm._updateAndEmit();
        };
        this._treeDropdownEvent.loadList(this._treeId);
    }
    _initChildApi(_id, _loadingIcon) {
        this._loadingIconList[_id] = _loadingIcon;
        let vm = this;
        this.api.updateChildNode = (_parentId, _returnData) => {
            vm._showLoadingIcon(vm._loadingIconList[_parentId], false);
            vm._selectedNodes = vm._tddSvc.updateConfig(_parentId, _returnData, vm._updatedData, vm.selectionMode);
            vm._updateAndEmit();
        };
        this._treeDropdownEvent.childExpand(_id);
    }
    _showLoadingIcon(_element, _showLoading, _isListNode) {
        if (_showLoading) {
            this._renderer.addClass(_element, 'kdx-loading-class');
            if (typeof _isListNode === 'undefined' || (typeof _isListNode === 'boolean' && !_isListNode)) {
                this._renderer.addClass(_element, 'fa-spinner');
                this._renderer.addClass(_element, 'fa-pulse');
                this._renderer.addClass(_element, 'fa-lg');
            }
        }
        else {
            _element.className = _element.className.replace(/(?:^|\s)kdx-loading-class(?!\S)/g, '');
            if (typeof _isListNode === 'undefined' || (typeof _isListNode === 'boolean' && !_isListNode)) {
                _element.className = _element.className.replace(/(?:^|\s)fa-spinner(?!\S)/g, '');
                _element.className = _element.className.replace(/(?:^|\s)fa-pulse(?!\S)/g, '');
                _element.className = _element.className.replace(/(?:^|\s)fa-lg(?!\S)/g, '');
            }
        }
    }
    _updateAndEmit() {
        this.selectedString = this._tddSvc.updateSelectedString(this._selectedNodes);
        this.eventSelectedNodes.emit(this._selectedNodes);
    }
    _setPopWidthHeight() {
        let queryString = '.' + this._treeId + '.kdx-popover-window';
        let popoverWindow = document.querySelector(queryString);
        this._setPopoverWidth(popoverWindow);
        this._setPopoverMaxHeight(popoverWindow);
    }
    _setPopoverWidth(_popoverWindow) {
        let selectionEle = this._vcr.element.nativeElement;
        let width = selectionEle.getBoundingClientRect().width + 'px';
        this._domSvc.setElementStyle(_popoverWindow, 'max-width', width);
        this._domSvc.setElementStyle(_popoverWindow, 'min-width', width);
    }
    _setPopoverMaxHeight(_popoverWindow) {
        let dropdown = this._vcr.element.nativeElement.parentNode;
        let usableHeight = window.innerHeight - dropdown.getBoundingClientRect().bottom - 5;
        let maxHeight = (usableHeight > 300) ? 300 : usableHeight;
        let maxHeightPx = maxHeight + 'px';
        let tree = _popoverWindow.querySelector('.ui-tree .ui-tree-container');
        if (tree !== null)
            this._domSvc.setElementStyle(tree, 'max-height', maxHeightPx);
    }
    _setToggle(_isTouch, _checkType, _eventObj) {
        let position = (_isTouch) ? this._tddSvc.getTouchPosition(_eventObj) : { x: _eventObj.clientX, y: _eventObj.clientY };
        let toggle = (_checkType === 'blur') ? this._tddSvc.checkWithinBoundingBox(_checkType, position, this._treeId, this._vcr.element.nativeElement.parentNode) : this._tddSvc.checkWithinBoundingBox(_checkType, position, this._treeId);
        if (!toggle)
            this._hide = true;
    }
    _setTouchListenerAndFF() {
        this._firefoxMouseEvent = this._renderer.listen('document', 'DOMMouseScroll', (ffMouseEvent) => {
            this._setToggle(false, 'scroll', ffMouseEvent);
        });
        this._touchmoveEvent = this._renderer.listen('document', 'touchmove', (touchEvent) => {
            this._setToggle(true, 'scroll', touchEvent);
        });
        this._touchendEvent = this._renderer.listen('document', 'touchstart', (touchEvent) => {
            this._setToggle(true, 'blur', touchEvent);
        });
    }
    _setBodyPosition(_isFirstCheck) {
        let mainEle = this._vcr.element.nativeElement.getBoundingClientRect();
        let queryString = '.' + this._treeId + '.kdx-popover-window';
        let toBody = (_isFirstCheck) ? this._vcr.element.nativeElement.querySelector(queryString) : document.querySelector(queryString);
        let topPos = (mainEle.bottom + 8) + 'px';
        let leftPos = mainEle.left + 'px';
        this._domSvc.setElementStyle(toBody, 'top', topPos);
        this._domSvc.setElementStyle(toBody, 'left', leftPos);
        if (_isFirstCheck)
            document.body.appendChild(toBody);
    }
}
KdTreeDropdown.decorators = [
    { type: Component, args: [{
                selector: 'kd-tree-dropdown',
                template: "<div class=\"popover popover-bottom kdx-popover-window\" [ngClass]=\"_treeId\" [hidden]=\"_hide\" style=\"position: relative;\">\r\n    <h3 class=\"popover-title\"></h3>\r\n    <div class=\"popover-content\">\r\n\t\t<p-tree class=\"kdx-p-tree\"\r\n\t\t[value]=\"_updatedData\" \r\n\t\tselectionMode=\"selectionMode\" \r\n\t\t(onNodeSelect)=\"nodeSelect($event)\"\r\n\t\t(onNodeExpand)=\"loadNode($event)\"\r\n\t\t>\r\n\t\t\t<ng-template let-node pTemplate=\"checkbox\">\r\n\t\t\t<div class=\"input-selection\">\r\n\t\t\t\t<div class=\"input\">\r\n\t\t\t\t\t<input [ngClass]=\"['dropdown', node.data.id]\" [kd-checkbox-radio]=\"node.label\" type='checkbox' [checked]=\"node.data.selected\"/>\r\n\t\t\t\t</div>\r\n\t\t\t</div>\r\n\t\t\t</ng-template>\r\n\t\t\t<ng-template let-node pTemplate=\"radio\">\r\n\t\t\t<div class=\"input-selection\">\r\n\t\t\t\t<div class=\"input\">\r\n\t\t\t\t\t<input [ngClass]=\"['dropdown', node.data.id]\" [kd-checkbox-radio]=\"node.label\" type='radio' name=\"radio\" [checked]=\"node.data.selected\"/>\r\n\t\t\t\t</div>\r\n\t\t\t</div>\r\n\t\t\t</ng-template>\r\n\t\t</p-tree>\r\n    </div>\r\n</div>\r\n\r\n<a class=\"kdx-treedropdown-input\" (click)=\"showPop()\">{{selectedString}}</a>",
                encapsulation: ViewEncapsulation.None,
                providers: [KdTreeDropdownSvc, KdDomElemSvc],
                host: { 'class': 'kdx-tree-dropdown' }
            },] }
];
KdTreeDropdown.ctorParameters = () => [
    { type: KdTreeDropdownSvc },
    { type: ViewContainerRef },
    { type: KdDomElemSvc },
    { type: Renderer2 },
    { type: KdTreeDropdownEvent }
];
KdTreeDropdown.propDecorators = {
    config: [{ type: Input }],
    api: [{ type: Input }],
    eventSelectedNodes: [{ type: Output }],
    onResize: [{ type: HostListener, args: ['window:resize', [],] }],
    onDocClick: [{ type: HostListener, args: ['document:mouseup', ['$event'],] }],
    onWheel: [{ type: HostListener, args: ['window:mousewheel', ['$event'],] }]
};
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoia2QtYW5ndWxhci10cmVlZHJvcGRvd24uanMiLCJzb3VyY2VSb290IjoiQzoveGFtcHAvaHRkb2NzL1N0eWxlZ3VpZGUvaW9zdGctb3BlbmVtaXMtc3R5bGVndWlkZS9wcm9qZWN0cy9vcGVuZW1pcy1zdHlsZWd1aWRlLWxpYi9zcmMvIiwic291cmNlcyI6WyJrZC1jb21wb25lbnRzL2tkLWFuZ3VsYXItdHJlZWRyb3Bkb3duL2tkLWFuZ3VsYXItdHJlZWRyb3Bkb3duLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBLE9BQU8sRUFBRSxTQUFTLEVBQW9DLGdCQUFnQixFQUFFLEtBQUssRUFBRSxNQUFNLEVBQUUsWUFBWSxFQUFFLGlCQUFpQixFQUFFLFlBQVksRUFBRSxTQUFTLEVBQUUsTUFBTSxlQUFlLENBQUM7QUFDdkssT0FBTyxFQUFFLEtBQUssRUFBRSxNQUFNLE1BQU0sQ0FBQztBQUU3QixPQUFPLEVBQUUsaUJBQWlCLEVBQUUsTUFBTSx1QkFBdUIsQ0FBQztBQUMxRCxPQUFPLEVBQUUsWUFBWSxFQUFFLE1BQU0sb0JBQW9CLENBQUM7QUFDbEQsT0FBTyxFQUFFLG1CQUFtQixFQUFFLE1BQU0seUJBQXlCLENBQUM7QUFXOUQsTUFBTSxPQUFPLGNBQWM7SUFxQnZCLFlBQ1ksT0FBMEIsRUFDMUIsSUFBc0IsRUFDdEIsT0FBcUIsRUFDckIsU0FBb0IsRUFDcEIsa0JBQXVDO1FBSnZDLFlBQU8sR0FBUCxPQUFPLENBQW1CO1FBQzFCLFNBQUksR0FBSixJQUFJLENBQWtCO1FBQ3RCLFlBQU8sR0FBUCxPQUFPLENBQWM7UUFDckIsY0FBUyxHQUFULFNBQVMsQ0FBVztRQUNwQix1QkFBa0IsR0FBbEIsa0JBQWtCLENBQXFCO1FBekI1QyxpQkFBWSxHQUFvQixFQUFFLENBQUM7UUFDbkMsWUFBTyxHQUFXLEVBQUUsQ0FBQztRQUNyQixVQUFLLEdBQVksSUFBSSxDQUFDO1FBQ3RCLG1CQUFjLEdBQVcsRUFBRSxDQUFDO1FBQzVCLGtCQUFhLEdBQVcsRUFBRSxDQUFDO1FBRTFCLG1CQUFjLEdBQWUsRUFBRSxDQUFDO1FBS2hDLGNBQVMsR0FBUSxJQUFJLENBQUM7UUFFdEIscUJBQWdCLEdBQVcsRUFBRSxDQUFDO1FBSzVCLHVCQUFrQixHQUFzQixJQUFJLFlBQVksRUFBRSxDQUFDO0lBUWxFLENBQUM7SUFHSixRQUFRO1FBQ0osSUFBSSxDQUFDLEtBQUssR0FBRyxJQUFJLENBQUM7UUFDbEIsSUFBSSxDQUFDLGtCQUFrQixFQUFFLENBQUM7SUFDOUIsQ0FBQztJQUdELFVBQVUsQ0FBQyxhQUF5QjtRQUNoQyxJQUFJLENBQUMsVUFBVSxDQUFDLEtBQUssRUFBRSxNQUFNLEVBQUUsYUFBYSxDQUFDLENBQUM7SUFDbEQsQ0FBQztJQUdELE9BQU8sQ0FBQyxhQUF5QjtRQUM3QixJQUFJLElBQUksQ0FBQyxTQUFTLEtBQUssSUFBSSxFQUFFO1lBQ3pCLElBQUksQ0FBQyxTQUFTLEdBQUcsYUFBYSxDQUFDO1NBQ2xDO1FBRUQsSUFBSSxRQUFRLEdBQVEsRUFBQyxDQUFDLEVBQUUsSUFBSSxDQUFDLFNBQVMsQ0FBQyxPQUFPLEVBQUUsQ0FBQyxFQUFFLElBQUksQ0FBQyxTQUFTLENBQUMsT0FBTyxFQUFDLENBQUM7UUFDM0UsSUFBSSxJQUFJLENBQUMsT0FBTyxDQUFDLHNCQUFzQixDQUFDLFNBQVMsRUFBRSxRQUFRLEVBQUUsSUFBSSxDQUFDLE9BQU8sQ0FBQyxFQUFFO1lBQ3hFLFlBQVksQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUM7WUFFMUIsSUFBSSxDQUFDLE1BQU0sR0FBRyxVQUFVLENBQUMsR0FBUyxFQUFFO2dCQUNoQyxJQUFJLENBQUMsVUFBVSxDQUFDLEtBQUssRUFBRSxRQUFRLEVBQUUsSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDO2dCQUNqRCxJQUFJLENBQUMsU0FBUyxHQUFHLElBQUksQ0FBQztZQUMxQixDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUM7U0FDVjthQUNJO1lBQ0QsSUFBSSxDQUFDLEtBQUssR0FBRyxJQUFJLENBQUM7WUFDbEIsSUFBSSxDQUFDLFNBQVMsR0FBRyxJQUFJLENBQUM7U0FDekI7SUFDTCxDQUFDO0lBRUQsUUFBUTtRQUVKLElBQUksQ0FBQyxPQUFPLEdBQUcsQ0FBQyxPQUFPLElBQUksQ0FBQyxNQUFNLENBQUMsRUFBRSxLQUFLLFdBQVcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsWUFBWSxDQUFDO1FBQ3ZGLElBQUksQ0FBQyxhQUFhLEdBQUcsSUFBSSxDQUFDLE9BQU8sQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDO1FBRXZELElBQUksT0FBTyxJQUFJLENBQUMsTUFBTSxDQUFDLElBQUksS0FBSyxXQUFXLEVBQUU7WUFDekMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxJQUFJLEdBQUcsRUFBRSxDQUFDO1NBQ3pCO1FBRUQsMEZBQTBGO1FBQzFGLElBQUksQ0FBQyxZQUFZLEdBQUcsSUFBSSxDQUFDLE9BQU8sQ0FBQyxhQUFhLENBQUMsSUFBSSxDQUFDLE1BQU0sRUFBRSxJQUFJLENBQUMsYUFBYSxDQUFDLENBQUM7UUFDaEYsNERBQTREO1FBQzVELElBQUksQ0FBQyxzQkFBc0IsRUFBRSxDQUFDO1FBQzlCLElBQUksQ0FBQyxjQUFjLEdBQUcsSUFBSSxDQUFDLE9BQU8sQ0FBQyxrQkFBa0IsQ0FBQyxJQUFJLENBQUMsWUFBWSxFQUFFLElBQUksQ0FBQyxhQUFhLENBQUMsQ0FBQztRQUU3RixLQUFLLEVBQUUsQ0FBQyxTQUFTLENBQUMsR0FBUyxFQUFFO1lBQ3pCLElBQUksQ0FBQyxjQUFjLEVBQUUsQ0FBQztRQUMxQixDQUFDLENBQUMsQ0FBQztJQUNQLENBQUM7SUFFRCxlQUFlO1FBQ1gsSUFBSSxDQUFDLGdCQUFnQixDQUFDLElBQUksQ0FBQyxDQUFDO0lBQ2hDLENBQUM7SUFFRCxXQUFXO1FBQ1AsWUFBWSxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQztRQUMxQixJQUFJLFdBQVcsR0FBVyxHQUFHLEdBQUcsSUFBSSxDQUFDLE9BQU8sR0FBRyxxQkFBcUIsQ0FBQztRQUNyRSxJQUFJLENBQUMsT0FBTyxDQUFDLG9CQUFvQixDQUFDLFdBQVcsQ0FBQyxDQUFDO1FBQy9DLElBQUksQ0FBQyxjQUFjLEVBQUUsQ0FBQztRQUN0QixJQUFJLENBQUMsZUFBZSxFQUFFLENBQUM7UUFDdkIsSUFBSSxDQUFDLGtCQUFrQixFQUFFLENBQUM7SUFDOUIsQ0FBQztJQUVELFVBQVUsQ0FBQyxLQUFVO1FBQ2pCLElBQUksSUFBSSxDQUFDLGFBQWEsS0FBSyxVQUFVO1lBQUUsS0FBSyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsUUFBUSxHQUFHLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDO2FBQ3ZGO1lBQ0QsSUFBSSxPQUFPLElBQUksQ0FBQyx3QkFBd0IsS0FBSyxXQUFXO2dCQUFFLElBQUksQ0FBQyx3QkFBd0IsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLFFBQVEsR0FBRyxLQUFLLENBQUM7WUFDbkgsS0FBSyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsUUFBUSxHQUFHLElBQUksQ0FBQztZQUNoQyxJQUFJLENBQUMsd0JBQXdCLEdBQUcsS0FBSyxDQUFDO1NBQ3pDO1FBQ0QsSUFBSSxDQUFDLGNBQWMsR0FBRyxJQUFJLENBQUMsT0FBTyxDQUFDLG1CQUFtQixDQUFDLElBQUksQ0FBQyxjQUFjLEVBQUUsS0FBSyxDQUFDLElBQUksRUFBRSxJQUFJLENBQUMsYUFBYSxDQUFDLENBQUM7UUFDNUcsSUFBSSxDQUFDLGNBQWMsRUFBRSxDQUFDO0lBQzFCLENBQUM7SUFFRCxRQUFRLENBQUMsTUFBVztRQUVoQixJQUFJLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxRQUFRLElBQUksTUFBTSxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsTUFBTSxJQUFJLENBQUMsRUFBRTtZQUMzRCxJQUFJLENBQUMsZ0JBQWdCLENBQUMsTUFBTSxDQUFDLGFBQWEsQ0FBQyxNQUFNLEVBQUUsSUFBSSxDQUFDLENBQUM7WUFFekQsSUFBSSxNQUFNLENBQUMsSUFBSSxFQUFFO2dCQUNiLElBQUksQ0FBQyxhQUFhLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsRUFBRSxFQUFFLE1BQU0sQ0FBQyxhQUFhLENBQUMsTUFBTSxDQUFDLENBQUM7YUFDeEU7U0FDSjtJQUNMLENBQUM7SUFFRCxPQUFPO1FBQ0gsSUFBSSxDQUFDLEtBQUssR0FBRyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUM7UUFDekIsSUFBSSxDQUFDLGdCQUFnQixDQUFDLEtBQUssQ0FBQyxDQUFDO1FBQzdCLElBQUksQ0FBQyxrQkFBa0IsRUFBRSxDQUFDO1FBRTFCLElBQUksQ0FBQyxPQUFPLENBQUMsY0FBYyxDQUFDLElBQUksQ0FBQyxNQUFNLEVBQUUsSUFBSSxDQUFDLFlBQVksQ0FBQyxDQUFDO1FBQzVELElBQUksSUFBSSxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsTUFBTSxLQUFLLENBQUMsRUFBRTtZQUUvQixJQUFJLFdBQVcsR0FBWSxJQUFJLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxhQUFhLENBQUMsVUFBVSxDQUFDO1lBQ3RFLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxXQUFXLEVBQUUsSUFBSSxFQUFFLElBQUksQ0FBQyxDQUFDO1lBRS9DLElBQUksQ0FBQyxjQUFjLENBQUMsV0FBVyxDQUFDLENBQUM7U0FDcEM7SUFDTCxDQUFDO0lBRU8sY0FBYyxDQUFDLFlBQXFCO1FBQ3hDLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLEdBQUcsWUFBWSxDQUFDO1FBRW5ELElBQUksRUFBRSxHQUFtQixJQUFJLENBQUM7UUFDOUIsSUFBSSxDQUFDLEdBQUcsQ0FBQyxVQUFVLEdBQUcsQ0FBQyxPQUFlLEVBQUUsU0FBcUIsRUFBRSxFQUFFO1lBQzdELEVBQUUsQ0FBQyxnQkFBZ0IsQ0FBQyxFQUFFLENBQUMsZ0JBQWdCLENBQUMsT0FBTyxDQUFDLEVBQUUsS0FBSyxDQUFDLENBQUM7WUFDekQsRUFBRSxDQUFDLE1BQU0sQ0FBQyxJQUFJLEdBQUcsU0FBUyxDQUFDO1lBQzNCLEVBQUUsQ0FBQyxZQUFZLEdBQUcsRUFBRSxDQUFDLE9BQU8sQ0FBQyxhQUFhLENBQUMsRUFBRSxDQUFDLE1BQU0sRUFBRSxFQUFFLENBQUMsYUFBYSxDQUFDLENBQUM7WUFDeEUsRUFBRSxDQUFDLGNBQWMsR0FBRyxFQUFFLENBQUMsT0FBTyxDQUFDLGtCQUFrQixDQUFDLEVBQUUsQ0FBQyxZQUFZLEVBQUUsRUFBRSxDQUFDLGFBQWEsQ0FBQyxDQUFDO1lBQ3JGLEVBQUUsQ0FBQyxjQUFjLEVBQUUsQ0FBQztRQUN4QixDQUFDLENBQUM7UUFFRixJQUFJLENBQUMsa0JBQWtCLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsQ0FBQztJQUNuRCxDQUFDO0lBRU8sYUFBYSxDQUFDLEdBQVcsRUFBRSxZQUFxQjtRQUNwRCxJQUFJLENBQUMsZ0JBQWdCLENBQUMsR0FBRyxDQUFDLEdBQUcsWUFBWSxDQUFDO1FBRTFDLElBQUksRUFBRSxHQUFtQixJQUFJLENBQUM7UUFDOUIsSUFBSSxDQUFDLEdBQUcsQ0FBQyxlQUFlLEdBQUcsQ0FBQyxTQUFpQixFQUFFLFdBQTBCLEVBQUUsRUFBRTtZQUN6RSxFQUFFLENBQUMsZ0JBQWdCLENBQUMsRUFBRSxDQUFDLGdCQUFnQixDQUFDLFNBQVMsQ0FBQyxFQUFFLEtBQUssQ0FBQyxDQUFDO1lBQzNELEVBQUUsQ0FBQyxjQUFjLEdBQUcsRUFBRSxDQUFDLE9BQU8sQ0FBQyxZQUFZLENBQUMsU0FBUyxFQUFFLFdBQVcsRUFBRSxFQUFFLENBQUMsWUFBWSxFQUFFLEVBQUUsQ0FBQyxhQUFhLENBQUMsQ0FBQztZQUN2RyxFQUFFLENBQUMsY0FBYyxFQUFFLENBQUM7UUFDeEIsQ0FBQyxDQUFDO1FBRUYsSUFBSSxDQUFDLGtCQUFrQixDQUFDLFdBQVcsQ0FBQyxHQUFHLENBQUMsQ0FBQztJQUM3QyxDQUFDO0lBRU8sZ0JBQWdCLENBQUMsUUFBaUIsRUFBRSxZQUFxQixFQUFFLFdBQXFCO1FBRXBGLElBQUksWUFBWSxFQUFFO1lBQ2QsSUFBSSxDQUFDLFNBQVMsQ0FBQyxRQUFRLENBQUMsUUFBUSxFQUFFLG1CQUFtQixDQUFDLENBQUM7WUFDdkQsSUFBSSxPQUFPLFdBQVcsS0FBSyxXQUFXLElBQUksQ0FBQyxPQUFPLFdBQVcsS0FBSyxTQUFTLElBQUksQ0FBQyxXQUFXLENBQUMsRUFBRTtnQkFDMUYsSUFBSSxDQUFDLFNBQVMsQ0FBQyxRQUFRLENBQUMsUUFBUSxFQUFFLFlBQVksQ0FBQyxDQUFDO2dCQUNoRCxJQUFJLENBQUMsU0FBUyxDQUFDLFFBQVEsQ0FBQyxRQUFRLEVBQUUsVUFBVSxDQUFDLENBQUM7Z0JBQzlDLElBQUksQ0FBQyxTQUFTLENBQUMsUUFBUSxDQUFDLFFBQVEsRUFBRSxPQUFPLENBQUMsQ0FBQzthQUM5QztTQUNKO2FBQU07WUFDSCxRQUFRLENBQUMsU0FBUyxHQUFHLFFBQVEsQ0FBQyxTQUFTLENBQUMsT0FBTyxDQUFDLGtDQUFrQyxFQUFFLEVBQUUsQ0FBQyxDQUFDO1lBQ3hGLElBQUksT0FBTyxXQUFXLEtBQUssV0FBVyxJQUFJLENBQUMsT0FBTyxXQUFXLEtBQUssU0FBUyxJQUFJLENBQUMsV0FBVyxDQUFDLEVBQUU7Z0JBQzFGLFFBQVEsQ0FBQyxTQUFTLEdBQUcsUUFBUSxDQUFDLFNBQVMsQ0FBQyxPQUFPLENBQUMsMkJBQTJCLEVBQUUsRUFBRSxDQUFDLENBQUM7Z0JBQ2pGLFFBQVEsQ0FBQyxTQUFTLEdBQUcsUUFBUSxDQUFDLFNBQVMsQ0FBQyxPQUFPLENBQUMseUJBQXlCLEVBQUUsRUFBRSxDQUFDLENBQUM7Z0JBQy9FLFFBQVEsQ0FBQyxTQUFTLEdBQUcsUUFBUSxDQUFDLFNBQVMsQ0FBQyxPQUFPLENBQUMsc0JBQXNCLEVBQUUsRUFBRSxDQUFDLENBQUM7YUFDL0U7U0FDSjtJQUVMLENBQUM7SUFFTyxjQUFjO1FBQ2xCLElBQUksQ0FBQyxjQUFjLEdBQUcsSUFBSSxDQUFDLE9BQU8sQ0FBQyxvQkFBb0IsQ0FBQyxJQUFJLENBQUMsY0FBYyxDQUFDLENBQUM7UUFDN0UsSUFBSSxDQUFDLGtCQUFrQixDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsY0FBYyxDQUFDLENBQUM7SUFDdEQsQ0FBQztJQUVPLGtCQUFrQjtRQUN0QixJQUFJLFdBQVcsR0FBVyxHQUFHLEdBQUcsSUFBSSxDQUFDLE9BQU8sR0FBRyxxQkFBcUIsQ0FBQztRQUNyRSxJQUFJLGFBQWEsR0FBWSxRQUFRLENBQUMsYUFBYSxDQUFDLFdBQVcsQ0FBQyxDQUFDO1FBQ2pFLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxhQUFhLENBQUMsQ0FBQztRQUNyQyxJQUFJLENBQUMsb0JBQW9CLENBQUMsYUFBYSxDQUFDLENBQUM7SUFDN0MsQ0FBQztJQUVPLGdCQUFnQixDQUFDLGNBQXVCO1FBQzVDLElBQUksWUFBWSxHQUFnQixJQUFJLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxhQUFhLENBQUM7UUFDaEUsSUFBSSxLQUFLLEdBQVcsWUFBWSxDQUFDLHFCQUFxQixFQUFFLENBQUMsS0FBSyxHQUFHLElBQUksQ0FBQztRQUN0RSxJQUFJLENBQUMsT0FBTyxDQUFDLGVBQWUsQ0FBQyxjQUFjLEVBQUUsV0FBVyxFQUFFLEtBQUssQ0FBQyxDQUFDO1FBQ2pFLElBQUksQ0FBQyxPQUFPLENBQUMsZUFBZSxDQUFDLGNBQWMsRUFBRSxXQUFXLEVBQUUsS0FBSyxDQUFDLENBQUM7SUFDckUsQ0FBQztJQUVPLG9CQUFvQixDQUFDLGNBQXVCO1FBQ2hELElBQUksUUFBUSxHQUFZLElBQUksQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLGFBQWEsQ0FBQyxVQUFVLENBQUM7UUFDbkUsSUFBSSxZQUFZLEdBQVcsTUFBTSxDQUFDLFdBQVcsR0FBRyxRQUFRLENBQUMscUJBQXFCLEVBQUUsQ0FBQyxNQUFNLEdBQUcsQ0FBQyxDQUFDO1FBQzVGLElBQUksU0FBUyxHQUFXLENBQUMsWUFBWSxHQUFHLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLFlBQVksQ0FBQztRQUNsRSxJQUFJLFdBQVcsR0FBVyxTQUFTLEdBQUcsSUFBSSxDQUFDO1FBQzNDLElBQUksSUFBSSxHQUFZLGNBQWMsQ0FBQyxhQUFhLENBQUMsNkJBQTZCLENBQUMsQ0FBQztRQUNoRixJQUFJLElBQUksS0FBSyxJQUFJO1lBQUUsSUFBSSxDQUFDLE9BQU8sQ0FBQyxlQUFlLENBQUMsSUFBSSxFQUFFLFlBQVksRUFBRSxXQUFXLENBQUMsQ0FBQztJQUNyRixDQUFDO0lBRU8sVUFBVSxDQUFDLFFBQWlCLEVBQUUsVUFBa0IsRUFBRSxTQUFjO1FBRXBFLElBQUksUUFBUSxHQUFRLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsZ0JBQWdCLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLFNBQVMsQ0FBQyxPQUFPLEVBQUUsQ0FBQyxFQUFFLFNBQVMsQ0FBQyxPQUFPLEVBQUUsQ0FBQztRQUMzSCxJQUFJLE1BQU0sR0FBWSxDQUFDLFVBQVUsS0FBSyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxzQkFBc0IsQ0FBQyxVQUFVLEVBQUUsUUFBUSxFQUFFLElBQUksQ0FBQyxPQUFPLEVBQUUsSUFBSSxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsYUFBYSxDQUFDLFVBQVUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLHNCQUFzQixDQUFDLFVBQVUsRUFBRSxRQUFRLEVBQUUsSUFBSSxDQUFDLE9BQU8sQ0FBQyxDQUFDO1FBQzlPLElBQUksQ0FBQyxNQUFNO1lBQUUsSUFBSSxDQUFDLEtBQUssR0FBRyxJQUFJLENBQUM7SUFDbkMsQ0FBQztJQUVPLHNCQUFzQjtRQUMxQixJQUFJLENBQUMsa0JBQWtCLEdBQUcsSUFBSSxDQUFDLFNBQVMsQ0FBQyxNQUFNLENBQUMsVUFBVSxFQUFFLGdCQUFnQixFQUFFLENBQUMsWUFBd0IsRUFBUSxFQUFFO1lBQ3JILElBQUksQ0FBQyxVQUFVLENBQUMsS0FBSyxFQUFFLFFBQVEsRUFBRSxZQUFZLENBQUMsQ0FBQztRQUNuRCxDQUFDLENBQUMsQ0FBQztRQUNLLElBQUksQ0FBQyxlQUFlLEdBQUcsSUFBSSxDQUFDLFNBQVMsQ0FBQyxNQUFNLENBQUMsVUFBVSxFQUFFLFdBQVcsRUFBRSxDQUFDLFVBQXNCLEVBQVEsRUFBRTtZQUMzRyxJQUFJLENBQUMsVUFBVSxDQUFDLElBQUksRUFBRSxRQUFRLEVBQUUsVUFBVSxDQUFDLENBQUM7UUFDaEQsQ0FBQyxDQUFDLENBQUM7UUFDSyxJQUFJLENBQUMsY0FBYyxHQUFHLElBQUksQ0FBQyxTQUFTLENBQUMsTUFBTSxDQUFDLFVBQVUsRUFBRSxZQUFZLEVBQUUsQ0FBQyxVQUFzQixFQUFRLEVBQUU7WUFDM0csSUFBSSxDQUFDLFVBQVUsQ0FBQyxJQUFJLEVBQUUsTUFBTSxFQUFFLFVBQVUsQ0FBQyxDQUFDO1FBQzlDLENBQUMsQ0FBQyxDQUFDO0lBQ0MsQ0FBQztJQUVPLGdCQUFnQixDQUFDLGFBQXNCO1FBQzNDLElBQUksT0FBTyxHQUFlLElBQUksQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLGFBQWEsQ0FBQyxxQkFBcUIsRUFBRSxDQUFDO1FBQ2xGLElBQUksV0FBVyxHQUFXLEdBQUcsR0FBRyxJQUFJLENBQUMsT0FBTyxHQUFHLHFCQUFxQixDQUFDO1FBQ3JFLElBQUksTUFBTSxHQUFZLENBQUMsYUFBYSxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLGFBQWEsQ0FBQyxhQUFhLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxhQUFhLENBQUMsV0FBVyxDQUFDLENBQUM7UUFDekksSUFBSSxNQUFNLEdBQVcsQ0FBQyxPQUFPLENBQUMsTUFBTSxHQUFHLENBQUMsQ0FBQyxHQUFHLElBQUksQ0FBQztRQUNqRCxJQUFJLE9BQU8sR0FBVyxPQUFPLENBQUMsSUFBSSxHQUFHLElBQUksQ0FBQztRQUMxQyxJQUFJLENBQUMsT0FBTyxDQUFDLGVBQWUsQ0FBQyxNQUFNLEVBQUUsS0FBSyxFQUFFLE1BQU0sQ0FBQyxDQUFDO1FBQ3BELElBQUksQ0FBQyxPQUFPLENBQUMsZUFBZSxDQUFDLE1BQU0sRUFBRSxNQUFNLEVBQUUsT0FBTyxDQUFDLENBQUM7UUFDdEQsSUFBSSxhQUFhO1lBQUUsUUFBUSxDQUFDLElBQUksQ0FBQyxXQUFXLENBQUMsTUFBTSxDQUFDLENBQUM7SUFDekQsQ0FBQzs7O1lBblBKLFNBQVMsU0FBQztnQkFDUCxRQUFRLEVBQUUsa0JBQWtCO2dCQUM1QixndENBQTZDO2dCQUM3QyxhQUFhLEVBQUUsaUJBQWlCLENBQUMsSUFBSTtnQkFDckMsU0FBUyxFQUFFLENBQUMsaUJBQWlCLEVBQUUsWUFBWSxDQUFDO2dCQUM1QyxJQUFJLEVBQUcsRUFBRSxPQUFPLEVBQUcsbUJBQW1CLEVBQUU7YUFDM0M7OztZQVhRLGlCQUFpQjtZQUg0QixnQkFBZ0I7WUFJN0QsWUFBWTtZQUppSCxTQUFTO1lBS3RJLG1CQUFtQjs7O3FCQTJCdkIsS0FBSztrQkFDTCxLQUFLO2lDQUVMLE1BQU07dUJBVU4sWUFBWSxTQUFDLGVBQWUsRUFBRSxFQUFFO3lCQU1oQyxZQUFZLFNBQUMsa0JBQWtCLEVBQUUsQ0FBQyxRQUFRLENBQUM7c0JBSzNDLFlBQVksU0FBQyxtQkFBbUIsRUFBRSxDQUFDLFFBQVEsQ0FBQyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IENvbXBvbmVudCwgT25Jbml0LCBBZnRlclZpZXdJbml0LCBPbkRlc3Ryb3ksIFZpZXdDb250YWluZXJSZWYsIElucHV0LCBPdXRwdXQsIEV2ZW50RW1pdHRlciwgVmlld0VuY2Fwc3VsYXRpb24sIEhvc3RMaXN0ZW5lciwgUmVuZGVyZXIyIH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XHJcbmltcG9ydCB7IHRpbWVyIH0gZnJvbSAncnhqcyc7XHJcbmltcG9ydCB7IFRyZWVOb2RlIH0gZnJvbSAncHJpbWVuZy9wcmltZW5nJztcclxuaW1wb3J0IHsgS2RUcmVlRHJvcGRvd25TdmMgfSBmcm9tICcuL2tkLXRyZWVkcm9wZG93bi1zdmMnO1xyXG5pbXBvcnQgeyBLZERvbUVsZW1TdmMgfSBmcm9tICcuLi9rZC1jb21tb24vaW5kZXgnO1xyXG5pbXBvcnQgeyBLZFRyZWVEcm9wZG93bkV2ZW50IH0gZnJvbSAnLi9rZC10cmVlZHJvcGRvd24tZXZlbnQnO1xyXG5pbXBvcnQgeyBJVHJlZUFwaSB9IGZyb20gJy4va2QtdHJlZWRyb3Bkb3duLWludGVyZmFjZSc7XHJcblxyXG5AQ29tcG9uZW50KHtcclxuICAgIHNlbGVjdG9yOiAna2QtdHJlZS1kcm9wZG93bicsXHJcbiAgICB0ZW1wbGF0ZVVybDogJy4va2QtYW5ndWxhci10cmVlZHJvcGRvd24uaHRtbCcsXHJcbiAgICBlbmNhcHN1bGF0aW9uOiBWaWV3RW5jYXBzdWxhdGlvbi5Ob25lLFxyXG4gICAgcHJvdmlkZXJzOiBbS2RUcmVlRHJvcGRvd25TdmMsIEtkRG9tRWxlbVN2Y10sXHJcbiAgICBob3N0IDogeyAnY2xhc3MnIDogJ2tkeC10cmVlLWRyb3Bkb3duJyB9XHJcbn0pXHJcblxyXG5leHBvcnQgY2xhc3MgS2RUcmVlRHJvcGRvd24gaW1wbGVtZW50cyBPbkluaXQsIEFmdGVyVmlld0luaXQsIE9uRGVzdHJveSB7XHJcbiAgICBwdWJsaWMgX3VwZGF0ZWREYXRhOiBBcnJheTxUcmVlTm9kZT4gPSBbXTtcclxuICAgIHB1YmxpYyBfdHJlZUlkOiBzdHJpbmcgPSAnJztcclxuICAgIHB1YmxpYyBfaGlkZTogYm9vbGVhbiA9IHRydWU7XHJcbiAgICBwdWJsaWMgc2VsZWN0ZWRTdHJpbmc6IHN0cmluZyA9ICcnO1xyXG4gICAgcHVibGljIHNlbGVjdGlvbk1vZGU6IHN0cmluZyA9ICcnO1xyXG5cclxuICAgIHByaXZhdGUgX3NlbGVjdGVkTm9kZXM6IEFycmF5PGFueT4gPSBbXTtcclxuICAgIHByaXZhdGUgX3NpbmdsZVNlbGVjdGlvblByZXZpb3VzOiBhbnk7XHJcbiAgICBwcml2YXRlIF90b3VjaG1vdmVFdmVudDogRnVuY3Rpb247XHJcbiAgICBwcml2YXRlIF90b3VjaGVuZEV2ZW50OiBGdW5jdGlvbjtcclxuICAgIHByaXZhdGUgX2ZpcmVmb3hNb3VzZUV2ZW50OiBGdW5jdGlvbjtcclxuICAgIHByaXZhdGUgX3doZWVsRXZ0OiBhbnkgPSBudWxsO1xyXG4gICAgcHJpdmF0ZSBfdGltZXI6IGFueTtcclxuICAgIHByaXZhdGUgX2xvYWRpbmdJY29uTGlzdDogb2JqZWN0ID0ge307XHJcblxyXG4gICAgQElucHV0KCkgY29uZmlnOiBhbnk7XHJcbiAgICBASW5wdXQoKSBhcGk6IElUcmVlQXBpO1xyXG5cclxuICAgIEBPdXRwdXQoKSBldmVudFNlbGVjdGVkTm9kZXM6IEV2ZW50RW1pdHRlcjxhbnk+ID0gbmV3IEV2ZW50RW1pdHRlcigpO1xyXG5cclxuICAgIGNvbnN0cnVjdG9yKFxyXG4gICAgICAgIHByaXZhdGUgX3RkZFN2YzogS2RUcmVlRHJvcGRvd25TdmMsXHJcbiAgICAgICAgcHJpdmF0ZSBfdmNyOiBWaWV3Q29udGFpbmVyUmVmLFxyXG4gICAgICAgIHByaXZhdGUgX2RvbVN2YzogS2REb21FbGVtU3ZjLFxyXG4gICAgICAgIHByaXZhdGUgX3JlbmRlcmVyOiBSZW5kZXJlcjIsXHJcbiAgICAgICAgcHJpdmF0ZSBfdHJlZURyb3Bkb3duRXZlbnQ6IEtkVHJlZURyb3Bkb3duRXZlbnRcclxuICAgICkge31cclxuXHJcbiAgICBASG9zdExpc3RlbmVyKCd3aW5kb3c6cmVzaXplJywgW10pXHJcbiAgICBvblJlc2l6ZSgpIHtcclxuICAgICAgICB0aGlzLl9oaWRlID0gdHJ1ZTtcclxuICAgICAgICB0aGlzLl9zZXRQb3BXaWR0aEhlaWdodCgpO1xyXG4gICAgfVxyXG5cclxuICAgIEBIb3N0TGlzdGVuZXIoJ2RvY3VtZW50Om1vdXNldXAnLCBbJyRldmVudCddKVxyXG4gICAgb25Eb2NDbGljayhkb2NDbGlja0V2ZW50OiBNb3VzZUV2ZW50KSB7XHJcbiAgICAgICAgdGhpcy5fc2V0VG9nZ2xlKGZhbHNlLCAnYmx1cicsIGRvY0NsaWNrRXZlbnQpO1xyXG4gICAgfVxyXG5cclxuICAgIEBIb3N0TGlzdGVuZXIoJ3dpbmRvdzptb3VzZXdoZWVsJywgWyckZXZlbnQnXSlcclxuICAgIG9uV2hlZWwod2luTW91c2VFdmVudDogTW91c2VFdmVudCkge1xyXG4gICAgICAgIGlmICh0aGlzLl93aGVlbEV2dCA9PT0gbnVsbCkge1xyXG4gICAgICAgICAgICB0aGlzLl93aGVlbEV2dCA9IHdpbk1vdXNlRXZlbnQ7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICBsZXQgcG9zaXRpb246IGFueSA9IHt4OiB0aGlzLl93aGVlbEV2dC5jbGllbnRYLCB5OiB0aGlzLl93aGVlbEV2dC5jbGllbnRZfTtcclxuICAgICAgICBpZiAodGhpcy5fdGRkU3ZjLmNoZWNrV2l0aGluQm91bmRpbmdCb3goJ25vdGJsdXInLCBwb3NpdGlvbiwgdGhpcy5fdHJlZUlkKSkge1xyXG4gICAgICAgICAgICBjbGVhclRpbWVvdXQodGhpcy5fdGltZXIpO1xyXG5cclxuICAgICAgICAgICAgdGhpcy5fdGltZXIgPSBzZXRUaW1lb3V0KCgpOiB2b2lkID0+IHtcclxuICAgICAgICAgICAgICAgIHRoaXMuX3NldFRvZ2dsZShmYWxzZSwgJ3Njcm9sbCcsIHRoaXMuX3doZWVsRXZ0KTtcclxuICAgICAgICAgICAgICAgIHRoaXMuX3doZWVsRXZ0ID0gbnVsbDtcclxuICAgICAgICAgICAgfSwgNTApO1xyXG4gICAgICAgIH1cclxuICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgdGhpcy5faGlkZSA9IHRydWU7XHJcbiAgICAgICAgICAgIHRoaXMuX3doZWVsRXZ0ID0gbnVsbDtcclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgbmdPbkluaXQoKTogdm9pZCB7XHJcblxyXG4gICAgICAgIHRoaXMuX3RyZWVJZCA9ICh0eXBlb2YgdGhpcy5jb25maWcuaWQgIT09ICd1bmRlZmluZWQnKSA/IHRoaXMuY29uZmlnLmlkIDogJ3RyZWUtY2xhc3MnO1xyXG4gICAgICAgIHRoaXMuc2VsZWN0aW9uTW9kZSA9IHRoaXMuX3RkZFN2Yy5nZXRNb2RlKHRoaXMuY29uZmlnKTtcclxuXHJcbiAgICAgICAgaWYgKHR5cGVvZiB0aGlzLmNvbmZpZy5saXN0ID09PSAndW5kZWZpbmVkJykge1xyXG4gICAgICAgICAgICB0aGlzLmNvbmZpZy5saXN0ID0gW107XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICAvLyBsZXQgdGVtcERhdGE6IEFycmF5PGFueT4gPSB0aGlzLl90ZGRTdmMuZ2V0VXBkYXRlTm9kZSh0aGlzLmNvbmZpZywgdGhpcy5zZWxlY3Rpb25Nb2RlKTtcclxuICAgICAgICB0aGlzLl91cGRhdGVkRGF0YSA9IHRoaXMuX3RkZFN2Yy5nZXRVcGRhdGVOb2RlKHRoaXMuY29uZmlnLCB0aGlzLnNlbGVjdGlvbk1vZGUpO1xyXG4gICAgICAgIC8vIHRoaXMuX3VwZGF0ZWREYXRhID0gSlNPTi5wYXJzZShKU09OLnN0cmluZ2lmeSh0ZW1wRGF0YSkpO1xyXG4gICAgICAgIHRoaXMuX3NldFRvdWNoTGlzdGVuZXJBbmRGRigpO1xyXG4gICAgICAgIHRoaXMuX3NlbGVjdGVkTm9kZXMgPSB0aGlzLl90ZGRTdmMudXBkYXRlSW5pdFNlbGVjdGVkKHRoaXMuX3VwZGF0ZWREYXRhLCB0aGlzLnNlbGVjdGlvbk1vZGUpO1xyXG5cclxuICAgICAgICB0aW1lcigpLnN1YnNjcmliZSgoKTogdm9pZCA9PiB7XHJcbiAgICAgICAgICAgIHRoaXMuX3VwZGF0ZUFuZEVtaXQoKTtcclxuICAgICAgICB9KTtcclxuICAgIH1cclxuXHJcbiAgICBuZ0FmdGVyVmlld0luaXQoKTogdm9pZCB7XHJcbiAgICAgICAgdGhpcy5fc2V0Qm9keVBvc2l0aW9uKHRydWUpO1xyXG4gICAgfVxyXG5cclxuICAgIG5nT25EZXN0cm95KCk6IHZvaWQge1xyXG4gICAgICAgIGNsZWFyVGltZW91dCh0aGlzLl90aW1lcik7XHJcbiAgICAgICAgbGV0IHF1ZXJ5U3RyaW5nOiBzdHJpbmcgPSAnLicgKyB0aGlzLl90cmVlSWQgKyAnLmtkeC1wb3BvdmVyLXdpbmRvdyc7XHJcbiAgICAgICAgdGhpcy5fZG9tU3ZjLnJlbW92ZUVsZW1lbnRCeUNsYXNzKHF1ZXJ5U3RyaW5nKTtcclxuICAgICAgICB0aGlzLl90b3VjaGVuZEV2ZW50KCk7XHJcbiAgICAgICAgdGhpcy5fdG91Y2htb3ZlRXZlbnQoKTtcclxuICAgICAgICB0aGlzLl9maXJlZm94TW91c2VFdmVudCgpO1xyXG4gICAgfVxyXG5cclxuICAgIG5vZGVTZWxlY3QoX2RhdGE6IGFueSk6IHZvaWQge1xyXG4gICAgICAgIGlmICh0aGlzLnNlbGVjdGlvbk1vZGUgPT09ICdtdWx0aXBsZScpIF9kYXRhLm5vZGUuZGF0YS5zZWxlY3RlZCA9ICFfZGF0YS5ub2RlLmRhdGEuc2VsZWN0ZWQ7XHJcbiAgICAgICAgZWxzZSB7XHJcbiAgICAgICAgICAgIGlmICh0eXBlb2YgdGhpcy5fc2luZ2xlU2VsZWN0aW9uUHJldmlvdXMgIT09ICd1bmRlZmluZWQnKSB0aGlzLl9zaW5nbGVTZWxlY3Rpb25QcmV2aW91cy5ub2RlLmRhdGEuc2VsZWN0ZWQgPSBmYWxzZTtcclxuICAgICAgICAgICAgX2RhdGEubm9kZS5kYXRhLnNlbGVjdGVkID0gdHJ1ZTtcclxuICAgICAgICAgICAgdGhpcy5fc2luZ2xlU2VsZWN0aW9uUHJldmlvdXMgPSBfZGF0YTtcclxuICAgICAgICB9XHJcbiAgICAgICAgdGhpcy5fc2VsZWN0ZWROb2RlcyA9IHRoaXMuX3RkZFN2Yy51cGRhdGVTZWxlY3RlZE5vZGVzKHRoaXMuX3NlbGVjdGVkTm9kZXMsIF9kYXRhLm5vZGUsIHRoaXMuc2VsZWN0aW9uTW9kZSk7XHJcbiAgICAgICAgdGhpcy5fdXBkYXRlQW5kRW1pdCgpO1xyXG4gICAgfVxyXG5cclxuICAgIGxvYWROb2RlKF9ldmVudDogYW55KTogdm9pZCB7XHJcblxyXG4gICAgICAgIGlmICghX2V2ZW50Lm5vZGUuY2hpbGRyZW4gfHwgX2V2ZW50Lm5vZGUuY2hpbGRyZW4ubGVuZ3RoIDw9IDApIHtcclxuICAgICAgICAgICAgdGhpcy5fc2hvd0xvYWRpbmdJY29uKF9ldmVudC5vcmlnaW5hbEV2ZW50LnRhcmdldCwgdHJ1ZSk7XHJcblxyXG4gICAgICAgICAgICBpZiAoX2V2ZW50Lm5vZGUpIHtcclxuICAgICAgICAgICAgICAgIHRoaXMuX2luaXRDaGlsZEFwaShfZXZlbnQubm9kZS5kYXRhLmlkLCBfZXZlbnQub3JpZ2luYWxFdmVudC50YXJnZXQpO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIHNob3dQb3AoKTogdm9pZCB7XHJcbiAgICAgICAgdGhpcy5faGlkZSA9ICF0aGlzLl9oaWRlO1xyXG4gICAgICAgIHRoaXMuX3NldEJvZHlQb3NpdGlvbihmYWxzZSk7XHJcbiAgICAgICAgdGhpcy5fc2V0UG9wV2lkdGhIZWlnaHQoKTtcclxuXHJcbiAgICAgICAgdGhpcy5fdGRkU3ZjLmF1dG9FeHBhbmRMaXN0KHRoaXMuY29uZmlnLCB0aGlzLl91cGRhdGVkRGF0YSk7XHJcbiAgICAgICAgaWYgKHRoaXMuY29uZmlnLmxpc3QubGVuZ3RoID09PSAwKSB7XHJcblxyXG4gICAgICAgICAgICBsZXQgbG9hZGluZ0ljb246IEVsZW1lbnQgPSB0aGlzLl92Y3IuZWxlbWVudC5uYXRpdmVFbGVtZW50LnBhcmVudE5vZGU7XHJcbiAgICAgICAgICAgIHRoaXMuX3Nob3dMb2FkaW5nSWNvbihsb2FkaW5nSWNvbiwgdHJ1ZSwgdHJ1ZSk7XHJcblxyXG4gICAgICAgICAgICB0aGlzLl9pbml0UGFyZW50QXBpKGxvYWRpbmdJY29uKTtcclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfaW5pdFBhcmVudEFwaShfbG9hZGluZ0ljb246IEVsZW1lbnQpOiB2b2lkIHtcclxuICAgICAgICB0aGlzLl9sb2FkaW5nSWNvbkxpc3RbdGhpcy5fdHJlZUlkXSA9IF9sb2FkaW5nSWNvbjtcclxuXHJcbiAgICAgICAgbGV0IHZtOiBLZFRyZWVEcm9wZG93biA9IHRoaXM7XHJcbiAgICAgICAgdGhpcy5hcGkudXBkYXRlTGlzdCA9IChfdHJlZUlkOiBzdHJpbmcsIF9saXN0RGF0YTogQXJyYXk8YW55PikgPT4ge1xyXG4gICAgICAgICAgICB2bS5fc2hvd0xvYWRpbmdJY29uKHZtLl9sb2FkaW5nSWNvbkxpc3RbX3RyZWVJZF0sIGZhbHNlKTtcclxuICAgICAgICAgICAgdm0uY29uZmlnLmxpc3QgPSBfbGlzdERhdGE7XHJcbiAgICAgICAgICAgIHZtLl91cGRhdGVkRGF0YSA9IHZtLl90ZGRTdmMuZ2V0VXBkYXRlTm9kZSh2bS5jb25maWcsIHZtLnNlbGVjdGlvbk1vZGUpO1xyXG4gICAgICAgICAgICB2bS5fc2VsZWN0ZWROb2RlcyA9IHZtLl90ZGRTdmMudXBkYXRlSW5pdFNlbGVjdGVkKHZtLl91cGRhdGVkRGF0YSwgdm0uc2VsZWN0aW9uTW9kZSk7XHJcbiAgICAgICAgICAgIHZtLl91cGRhdGVBbmRFbWl0KCk7XHJcbiAgICAgICAgfTtcclxuXHJcbiAgICAgICAgdGhpcy5fdHJlZURyb3Bkb3duRXZlbnQubG9hZExpc3QodGhpcy5fdHJlZUlkKTtcclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF9pbml0Q2hpbGRBcGkoX2lkOiBzdHJpbmcsIF9sb2FkaW5nSWNvbjogRWxlbWVudCk6IHZvaWQge1xyXG4gICAgICAgIHRoaXMuX2xvYWRpbmdJY29uTGlzdFtfaWRdID0gX2xvYWRpbmdJY29uO1xyXG5cclxuICAgICAgICBsZXQgdm06IEtkVHJlZURyb3Bkb3duID0gdGhpcztcclxuICAgICAgICB0aGlzLmFwaS51cGRhdGVDaGlsZE5vZGUgPSAoX3BhcmVudElkOiBzdHJpbmcsIF9yZXR1cm5EYXRhOiBBcnJheTxvYmplY3Q+KSA9PiB7XHJcbiAgICAgICAgICAgIHZtLl9zaG93TG9hZGluZ0ljb24odm0uX2xvYWRpbmdJY29uTGlzdFtfcGFyZW50SWRdLCBmYWxzZSk7XHJcbiAgICAgICAgICAgIHZtLl9zZWxlY3RlZE5vZGVzID0gdm0uX3RkZFN2Yy51cGRhdGVDb25maWcoX3BhcmVudElkLCBfcmV0dXJuRGF0YSwgdm0uX3VwZGF0ZWREYXRhLCB2bS5zZWxlY3Rpb25Nb2RlKTtcclxuICAgICAgICAgICAgdm0uX3VwZGF0ZUFuZEVtaXQoKTtcclxuICAgICAgICB9O1xyXG5cclxuICAgICAgICB0aGlzLl90cmVlRHJvcGRvd25FdmVudC5jaGlsZEV4cGFuZChfaWQpO1xyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX3Nob3dMb2FkaW5nSWNvbihfZWxlbWVudDogRWxlbWVudCwgX3Nob3dMb2FkaW5nOiBib29sZWFuLCBfaXNMaXN0Tm9kZT86IGJvb2xlYW4pOiB2b2lkIHtcclxuXHJcbiAgICAgICAgaWYgKF9zaG93TG9hZGluZykge1xyXG4gICAgICAgICAgICB0aGlzLl9yZW5kZXJlci5hZGRDbGFzcyhfZWxlbWVudCwgJ2tkeC1sb2FkaW5nLWNsYXNzJyk7XHJcbiAgICAgICAgICAgIGlmICh0eXBlb2YgX2lzTGlzdE5vZGUgPT09ICd1bmRlZmluZWQnIHx8ICh0eXBlb2YgX2lzTGlzdE5vZGUgPT09ICdib29sZWFuJyAmJiAhX2lzTGlzdE5vZGUpKSB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLl9yZW5kZXJlci5hZGRDbGFzcyhfZWxlbWVudCwgJ2ZhLXNwaW5uZXInKTtcclxuICAgICAgICAgICAgICAgIHRoaXMuX3JlbmRlcmVyLmFkZENsYXNzKF9lbGVtZW50LCAnZmEtcHVsc2UnKTtcclxuICAgICAgICAgICAgICAgIHRoaXMuX3JlbmRlcmVyLmFkZENsYXNzKF9lbGVtZW50LCAnZmEtbGcnKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgIF9lbGVtZW50LmNsYXNzTmFtZSA9IF9lbGVtZW50LmNsYXNzTmFtZS5yZXBsYWNlKC8oPzpefFxccylrZHgtbG9hZGluZy1jbGFzcyg/IVxcUykvZywgJycpO1xyXG4gICAgICAgICAgICBpZiAodHlwZW9mIF9pc0xpc3ROb2RlID09PSAndW5kZWZpbmVkJyB8fCAodHlwZW9mIF9pc0xpc3ROb2RlID09PSAnYm9vbGVhbicgJiYgIV9pc0xpc3ROb2RlKSkge1xyXG4gICAgICAgICAgICAgICAgX2VsZW1lbnQuY2xhc3NOYW1lID0gX2VsZW1lbnQuY2xhc3NOYW1lLnJlcGxhY2UoLyg/Ol58XFxzKWZhLXNwaW5uZXIoPyFcXFMpL2csICcnKTtcclxuICAgICAgICAgICAgICAgIF9lbGVtZW50LmNsYXNzTmFtZSA9IF9lbGVtZW50LmNsYXNzTmFtZS5yZXBsYWNlKC8oPzpefFxccylmYS1wdWxzZSg/IVxcUykvZywgJycpO1xyXG4gICAgICAgICAgICAgICAgX2VsZW1lbnQuY2xhc3NOYW1lID0gX2VsZW1lbnQuY2xhc3NOYW1lLnJlcGxhY2UoLyg/Ol58XFxzKWZhLWxnKD8hXFxTKS9nLCAnJyk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcblxyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX3VwZGF0ZUFuZEVtaXQoKTogdm9pZCB7XHJcbiAgICAgICAgdGhpcy5zZWxlY3RlZFN0cmluZyA9IHRoaXMuX3RkZFN2Yy51cGRhdGVTZWxlY3RlZFN0cmluZyh0aGlzLl9zZWxlY3RlZE5vZGVzKTtcclxuICAgICAgICB0aGlzLmV2ZW50U2VsZWN0ZWROb2Rlcy5lbWl0KHRoaXMuX3NlbGVjdGVkTm9kZXMpO1xyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX3NldFBvcFdpZHRoSGVpZ2h0KCk6IHZvaWQge1xyXG4gICAgICAgIGxldCBxdWVyeVN0cmluZzogc3RyaW5nID0gJy4nICsgdGhpcy5fdHJlZUlkICsgJy5rZHgtcG9wb3Zlci13aW5kb3cnO1xyXG4gICAgICAgIGxldCBwb3BvdmVyV2luZG93OiBFbGVtZW50ID0gZG9jdW1lbnQucXVlcnlTZWxlY3RvcihxdWVyeVN0cmluZyk7XHJcbiAgICAgICAgdGhpcy5fc2V0UG9wb3ZlcldpZHRoKHBvcG92ZXJXaW5kb3cpO1xyXG4gICAgICAgIHRoaXMuX3NldFBvcG92ZXJNYXhIZWlnaHQocG9wb3ZlcldpbmRvdyk7XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfc2V0UG9wb3ZlcldpZHRoKF9wb3BvdmVyV2luZG93OiBFbGVtZW50KTogdm9pZCB7XHJcbiAgICAgICAgbGV0IHNlbGVjdGlvbkVsZTogSFRNTEVsZW1lbnQgPSB0aGlzLl92Y3IuZWxlbWVudC5uYXRpdmVFbGVtZW50O1xyXG4gICAgICAgIGxldCB3aWR0aDogc3RyaW5nID0gc2VsZWN0aW9uRWxlLmdldEJvdW5kaW5nQ2xpZW50UmVjdCgpLndpZHRoICsgJ3B4JztcclxuICAgICAgICB0aGlzLl9kb21TdmMuc2V0RWxlbWVudFN0eWxlKF9wb3BvdmVyV2luZG93LCAnbWF4LXdpZHRoJywgd2lkdGgpO1xyXG4gICAgICAgIHRoaXMuX2RvbVN2Yy5zZXRFbGVtZW50U3R5bGUoX3BvcG92ZXJXaW5kb3csICdtaW4td2lkdGgnLCB3aWR0aCk7XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfc2V0UG9wb3Zlck1heEhlaWdodChfcG9wb3ZlcldpbmRvdzogRWxlbWVudCk6IHZvaWQge1xyXG4gICAgICAgIGxldCBkcm9wZG93bjogRWxlbWVudCA9IHRoaXMuX3Zjci5lbGVtZW50Lm5hdGl2ZUVsZW1lbnQucGFyZW50Tm9kZTtcclxuICAgICAgICBsZXQgdXNhYmxlSGVpZ2h0OiBudW1iZXIgPSB3aW5kb3cuaW5uZXJIZWlnaHQgLSBkcm9wZG93bi5nZXRCb3VuZGluZ0NsaWVudFJlY3QoKS5ib3R0b20gLSA1O1xyXG4gICAgICAgIGxldCBtYXhIZWlnaHQ6IG51bWJlciA9ICh1c2FibGVIZWlnaHQgPiAzMDApID8gMzAwIDogdXNhYmxlSGVpZ2h0O1xyXG4gICAgICAgIGxldCBtYXhIZWlnaHRQeDogc3RyaW5nID0gbWF4SGVpZ2h0ICsgJ3B4JztcclxuICAgICAgICBsZXQgdHJlZTogRWxlbWVudCA9IF9wb3BvdmVyV2luZG93LnF1ZXJ5U2VsZWN0b3IoJy51aS10cmVlIC51aS10cmVlLWNvbnRhaW5lcicpO1xyXG4gICAgICAgIGlmICh0cmVlICE9PSBudWxsKSB0aGlzLl9kb21TdmMuc2V0RWxlbWVudFN0eWxlKHRyZWUsICdtYXgtaGVpZ2h0JywgbWF4SGVpZ2h0UHgpO1xyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX3NldFRvZ2dsZShfaXNUb3VjaDogYm9vbGVhbiwgX2NoZWNrVHlwZTogc3RyaW5nLCBfZXZlbnRPYmo6IGFueSk6IHZvaWQge1xyXG5cclxuICAgICAgICBsZXQgcG9zaXRpb246IGFueSA9IChfaXNUb3VjaCkgPyB0aGlzLl90ZGRTdmMuZ2V0VG91Y2hQb3NpdGlvbihfZXZlbnRPYmopIDogeyB4OiBfZXZlbnRPYmouY2xpZW50WCwgeTogX2V2ZW50T2JqLmNsaWVudFkgfTtcclxuICAgICAgICBsZXQgdG9nZ2xlOiBib29sZWFuID0gKF9jaGVja1R5cGUgPT09ICdibHVyJykgPyB0aGlzLl90ZGRTdmMuY2hlY2tXaXRoaW5Cb3VuZGluZ0JveChfY2hlY2tUeXBlLCBwb3NpdGlvbiwgdGhpcy5fdHJlZUlkLCB0aGlzLl92Y3IuZWxlbWVudC5uYXRpdmVFbGVtZW50LnBhcmVudE5vZGUpIDogdGhpcy5fdGRkU3ZjLmNoZWNrV2l0aGluQm91bmRpbmdCb3goX2NoZWNrVHlwZSwgcG9zaXRpb24sIHRoaXMuX3RyZWVJZCk7XHJcbiAgICAgICAgaWYgKCF0b2dnbGUpIHRoaXMuX2hpZGUgPSB0cnVlO1xyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX3NldFRvdWNoTGlzdGVuZXJBbmRGRigpOiB2b2lkIHtcclxuICAgICAgICB0aGlzLl9maXJlZm94TW91c2VFdmVudCA9IHRoaXMuX3JlbmRlcmVyLmxpc3RlbignZG9jdW1lbnQnLCAnRE9NTW91c2VTY3JvbGwnLCAoZmZNb3VzZUV2ZW50OiBNb3VzZUV2ZW50KTogdm9pZCA9PiB7XHJcbiAgICB0aGlzLl9zZXRUb2dnbGUoZmFsc2UsICdzY3JvbGwnLCBmZk1vdXNlRXZlbnQpO1xyXG59KTtcclxuICAgICAgICB0aGlzLl90b3VjaG1vdmVFdmVudCA9IHRoaXMuX3JlbmRlcmVyLmxpc3RlbignZG9jdW1lbnQnLCAndG91Y2htb3ZlJywgKHRvdWNoRXZlbnQ6IFRvdWNoRXZlbnQpOiB2b2lkID0+IHtcclxuICAgIHRoaXMuX3NldFRvZ2dsZSh0cnVlLCAnc2Nyb2xsJywgdG91Y2hFdmVudCk7XHJcbn0pO1xyXG4gICAgICAgIHRoaXMuX3RvdWNoZW5kRXZlbnQgPSB0aGlzLl9yZW5kZXJlci5saXN0ZW4oJ2RvY3VtZW50JywgJ3RvdWNoc3RhcnQnLCAodG91Y2hFdmVudDogVG91Y2hFdmVudCk6IHZvaWQgPT4ge1xyXG4gICAgdGhpcy5fc2V0VG9nZ2xlKHRydWUsICdibHVyJywgdG91Y2hFdmVudCk7XHJcbn0pO1xyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX3NldEJvZHlQb3NpdGlvbihfaXNGaXJzdENoZWNrOiBib29sZWFuKTogdm9pZCB7XHJcbiAgICAgICAgbGV0IG1haW5FbGU6IENsaWVudFJlY3QgPSB0aGlzLl92Y3IuZWxlbWVudC5uYXRpdmVFbGVtZW50LmdldEJvdW5kaW5nQ2xpZW50UmVjdCgpO1xyXG4gICAgICAgIGxldCBxdWVyeVN0cmluZzogc3RyaW5nID0gJy4nICsgdGhpcy5fdHJlZUlkICsgJy5rZHgtcG9wb3Zlci13aW5kb3cnO1xyXG4gICAgICAgIGxldCB0b0JvZHk6IEVsZW1lbnQgPSAoX2lzRmlyc3RDaGVjaykgPyB0aGlzLl92Y3IuZWxlbWVudC5uYXRpdmVFbGVtZW50LnF1ZXJ5U2VsZWN0b3IocXVlcnlTdHJpbmcpIDogZG9jdW1lbnQucXVlcnlTZWxlY3RvcihxdWVyeVN0cmluZyk7XHJcbiAgICAgICAgbGV0IHRvcFBvczogc3RyaW5nID0gKG1haW5FbGUuYm90dG9tICsgOCkgKyAncHgnO1xyXG4gICAgICAgIGxldCBsZWZ0UG9zOiBzdHJpbmcgPSBtYWluRWxlLmxlZnQgKyAncHgnO1xyXG4gICAgICAgIHRoaXMuX2RvbVN2Yy5zZXRFbGVtZW50U3R5bGUodG9Cb2R5LCAndG9wJywgdG9wUG9zKTtcclxuICAgICAgICB0aGlzLl9kb21TdmMuc2V0RWxlbWVudFN0eWxlKHRvQm9keSwgJ2xlZnQnLCBsZWZ0UG9zKTtcclxuICAgICAgICBpZiAoX2lzRmlyc3RDaGVjaykgZG9jdW1lbnQuYm9keS5hcHBlbmRDaGlsZCh0b0JvZHkpO1xyXG4gICAgfVxyXG59XHJcbiJdfQ==