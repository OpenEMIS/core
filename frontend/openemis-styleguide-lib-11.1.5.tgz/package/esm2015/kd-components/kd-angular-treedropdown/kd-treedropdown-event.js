import { Injectable } from '@angular/core';
import { KdBroadcaster } from '../kd-common/index';
import * as i0 from "@angular/core";
import * as i1 from "../kd-common/kd-broadcaster-svc";
export class KdTreeDropdownEvent {
    constructor(_broadcaster) {
        this._broadcaster = _broadcaster;
    }
    childExpand(data) {
        this._broadcaster.broadcast('KDTreeDropdown_ChildData', data);
    }
    onChildNodeExpand() {
        return this._broadcaster.on('KDTreeDropdown_ChildData');
    }
    loadList(data) {
        this._broadcaster.broadcast('KDTreeDropdown_ParentData', data);
    }
    onLoadList() {
        return this._broadcaster.on('KDTreeDropdown_ParentData');
    }
}
KdTreeDropdownEvent.ɵprov = i0.ɵɵdefineInjectable({ factory: function KdTreeDropdownEvent_Factory() { return new KdTreeDropdownEvent(i0.ɵɵinject(i1.KdBroadcaster)); }, token: KdTreeDropdownEvent, providedIn: "root" });
KdTreeDropdownEvent.decorators = [
    { type: Injectable, args: [{
                providedIn: 'root'
            },] }
];
KdTreeDropdownEvent.ctorParameters = () => [
    { type: KdBroadcaster }
];
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoia2QtdHJlZWRyb3Bkb3duLWV2ZW50LmpzIiwic291cmNlUm9vdCI6IkM6L3hhbXBwL2h0ZG9jcy9TdHlsZWd1aWRlL2lvc3RnLW9wZW5lbWlzLXN0eWxlZ3VpZGUvcHJvamVjdHMvb3BlbmVtaXMtc3R5bGVndWlkZS1saWIvc3JjLyIsInNvdXJjZXMiOlsia2QtY29tcG9uZW50cy9rZC1hbmd1bGFyLXRyZWVkcm9wZG93bi9rZC10cmVlZHJvcGRvd24tZXZlbnQudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsT0FBTyxFQUFFLFVBQVUsRUFBRSxNQUFNLGVBQWUsQ0FBQztBQUUzQyxPQUFPLEVBQUUsYUFBYSxFQUFFLE1BQU0sb0JBQW9CLENBQUM7OztBQUtuRCxNQUFNLE9BQU8sbUJBQW1CO0lBQzVCLFlBQW9CLFlBQTJCO1FBQTNCLGlCQUFZLEdBQVosWUFBWSxDQUFlO0lBQUksQ0FBQztJQUVwRCxXQUFXLENBQUMsSUFBUztRQUNqQixJQUFJLENBQUMsWUFBWSxDQUFDLFNBQVMsQ0FBQywwQkFBMEIsRUFBRSxJQUFJLENBQUMsQ0FBQztJQUNsRSxDQUFDO0lBRUQsaUJBQWlCO1FBQ2IsT0FBTyxJQUFJLENBQUMsWUFBWSxDQUFDLEVBQUUsQ0FBTSwwQkFBMEIsQ0FBQyxDQUFDO0lBQ2pFLENBQUM7SUFFRCxRQUFRLENBQUMsSUFBUztRQUNkLElBQUksQ0FBQyxZQUFZLENBQUMsU0FBUyxDQUFDLDJCQUEyQixFQUFFLElBQUksQ0FBQyxDQUFDO0lBQ25FLENBQUM7SUFFRCxVQUFVO1FBQ04sT0FBTyxJQUFJLENBQUMsWUFBWSxDQUFDLEVBQUUsQ0FBTSwyQkFBMkIsQ0FBQyxDQUFDO0lBQ2xFLENBQUM7Ozs7WUFwQkosVUFBVSxTQUFDO2dCQUNSLFVBQVUsRUFBRSxNQUFNO2FBQ3JCOzs7WUFKUSxhQUFhIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgSW5qZWN0YWJsZSB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xyXG5pbXBvcnQgeyBPYnNlcnZhYmxlIH0gZnJvbSAncnhqcyc7XHJcbmltcG9ydCB7IEtkQnJvYWRjYXN0ZXIgfSBmcm9tICcuLi9rZC1jb21tb24vaW5kZXgnO1xyXG5cclxuQEluamVjdGFibGUoe1xyXG4gICAgcHJvdmlkZWRJbjogJ3Jvb3QnXHJcbn0pXHJcbmV4cG9ydCBjbGFzcyBLZFRyZWVEcm9wZG93bkV2ZW50IHtcclxuICAgIGNvbnN0cnVjdG9yKHByaXZhdGUgX2Jyb2FkY2FzdGVyOiBLZEJyb2FkY2FzdGVyKSB7IH1cclxuXHJcbiAgICBjaGlsZEV4cGFuZChkYXRhOiBhbnkpOiB2b2lkIHtcclxuICAgICAgICB0aGlzLl9icm9hZGNhc3Rlci5icm9hZGNhc3QoJ0tEVHJlZURyb3Bkb3duX0NoaWxkRGF0YScsIGRhdGEpO1xyXG4gICAgfVxyXG5cclxuICAgIG9uQ2hpbGROb2RlRXhwYW5kKCk6IE9ic2VydmFibGU8YW55PiB7XHJcbiAgICAgICAgcmV0dXJuIHRoaXMuX2Jyb2FkY2FzdGVyLm9uPGFueT4oJ0tEVHJlZURyb3Bkb3duX0NoaWxkRGF0YScpO1xyXG4gICAgfVxyXG5cclxuICAgIGxvYWRMaXN0KGRhdGE6IGFueSk6IHZvaWQge1xyXG4gICAgICAgIHRoaXMuX2Jyb2FkY2FzdGVyLmJyb2FkY2FzdCgnS0RUcmVlRHJvcGRvd25fUGFyZW50RGF0YScsIGRhdGEpO1xyXG4gICAgfVxyXG5cclxuICAgIG9uTG9hZExpc3QoKTogT2JzZXJ2YWJsZTxhbnk+IHtcclxuICAgICAgICByZXR1cm4gdGhpcy5fYnJvYWRjYXN0ZXIub248YW55PignS0RUcmVlRHJvcGRvd25fUGFyZW50RGF0YScpO1xyXG4gICAgfVxyXG59XHJcbiJdfQ==