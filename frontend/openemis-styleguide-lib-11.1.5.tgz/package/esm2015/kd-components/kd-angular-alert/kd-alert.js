import { Component, ViewEncapsulation } from '@angular/core';
import { ToasterService, ToasterConfig } from 'angular2-toaster';
import { KdAlertEvent } from './kd-alert-event';
export class KdAlert {
    constructor(_toasterService, _kdAlertEvent) {
        this._toasterService = _toasterService;
        this._kdAlertEvent = _kdAlertEvent;
        this._toasterDefaultConfig = {
            showCloseButton: true,
            tapToDismiss: false,
            timeout: -1,
            limit: 5,
            positionClass: 'toast-top-right'
        };
    }
    ngOnInit() {
        this.registerAlertBroadcast();
    }
    registerAlertBroadcast() {
        this._kdAlertEvent.on()
            .subscribe(_toast => {
            this._config = Object.assign({}, this._toasterDefaultConfig, _toast);
            this._toasterconfig = new ToasterConfig(this._config);
            this._toasterService.pop(_toast);
            // this._toasterService.pop('success', 'Args Title', 'Args Body');;
        });
    }
}
KdAlert.decorators = [
    { type: Component, args: [{
                selector: 'kd-alert',
                providers: [ToasterService, KdAlertEvent],
                encapsulation: ViewEncapsulation.None,
                template: `
        <toaster-container [toasterconfig]='_toasterconfig'>
        </toaster-container>
       `
            },] }
];
KdAlert.ctorParameters = () => [
    { type: ToasterService },
    { type: KdAlertEvent }
];
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoia2QtYWxlcnQuanMiLCJzb3VyY2VSb290IjoiQzoveGFtcHAvaHRkb2NzL1N0eWxlZ3VpZGUvaW9zdGctb3BlbmVtaXMtc3R5bGVndWlkZS9wcm9qZWN0cy9vcGVuZW1pcy1zdHlsZWd1aWRlLWxpYi9zcmMvIiwic291cmNlcyI6WyJrZC1jb21wb25lbnRzL2tkLWFuZ3VsYXItYWxlcnQva2QtYWxlcnQudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsT0FBTyxFQUFFLFNBQVMsRUFBRSxpQkFBaUIsRUFBVSxNQUFNLGVBQWUsQ0FBQztBQUNyRSxPQUFPLEVBQUUsY0FBYyxFQUFFLGFBQWEsRUFBQyxNQUFNLGtCQUFrQixDQUFDO0FBQ2hFLE9BQU8sRUFBRSxZQUFZLEVBQUUsTUFBTSxrQkFBa0IsQ0FBQztBQVloRCxNQUFNLE9BQU8sT0FBTztJQVdoQixZQUNZLGVBQStCLEVBQy9CLGFBQTJCO1FBRDNCLG9CQUFlLEdBQWYsZUFBZSxDQUFnQjtRQUMvQixrQkFBYSxHQUFiLGFBQWEsQ0FBYztRQVYvQiwwQkFBcUIsR0FBUTtZQUNqQyxlQUFlLEVBQUUsSUFBSTtZQUNyQixZQUFZLEVBQUUsS0FBSztZQUNuQixPQUFPLEVBQUUsQ0FBQyxDQUFDO1lBQ1gsS0FBSyxFQUFFLENBQUM7WUFDUixhQUFhLEVBQUUsaUJBQWlCO1NBQ25DLENBQUM7SUFLRSxDQUFDO0lBRUwsUUFBUTtRQUNKLElBQUksQ0FBQyxzQkFBc0IsRUFBRSxDQUFDO0lBQ2xDLENBQUM7SUFFRCxzQkFBc0I7UUFDbEIsSUFBSSxDQUFDLGFBQWEsQ0FBQyxFQUFFLEVBQUU7YUFDbEIsU0FBUyxDQUFDLE1BQU0sQ0FBQyxFQUFFO1lBQ2hCLElBQUksQ0FBQyxPQUFPLEdBQUcsTUFBTSxDQUFDLE1BQU0sQ0FBQyxFQUFFLEVBQUUsSUFBSSxDQUFDLHFCQUFxQixFQUFFLE1BQU0sQ0FBQyxDQUFDO1lBQ3JFLElBQUksQ0FBQyxjQUFjLEdBQUcsSUFBSSxhQUFhLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxDQUFDO1lBQ3RELElBQUksQ0FBQyxlQUFlLENBQUMsR0FBRyxDQUFDLE1BQU0sQ0FBQyxDQUFDO1lBQ2pDLG1FQUFtRTtRQUN2RSxDQUFDLENBQUMsQ0FBQztJQUNYLENBQUM7OztZQXRDSixTQUFTLFNBQUM7Z0JBQ1AsUUFBUSxFQUFFLFVBQVU7Z0JBQ3BCLFNBQVMsRUFBRSxDQUFDLGNBQWMsRUFBRSxZQUFZLENBQUM7Z0JBQ3pDLGFBQWEsRUFBRSxpQkFBaUIsQ0FBQyxJQUFJO2dCQUNyQyxRQUFRLEVBQUU7OztRQUdOO2FBQ1A7OztZQVhRLGNBQWM7WUFDZCxZQUFZIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgQ29tcG9uZW50LCBWaWV3RW5jYXBzdWxhdGlvbiwgT25Jbml0IH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XHJcbmltcG9ydCB7IFRvYXN0ZXJTZXJ2aWNlLCBUb2FzdGVyQ29uZmlnfSBmcm9tICdhbmd1bGFyMi10b2FzdGVyJztcclxuaW1wb3J0IHsgS2RBbGVydEV2ZW50IH0gZnJvbSAnLi9rZC1hbGVydC1ldmVudCc7XHJcblxyXG5AQ29tcG9uZW50KHtcclxuICAgIHNlbGVjdG9yOiAna2QtYWxlcnQnLFxyXG4gICAgcHJvdmlkZXJzOiBbVG9hc3RlclNlcnZpY2UsIEtkQWxlcnRFdmVudF0sXHJcbiAgICBlbmNhcHN1bGF0aW9uOiBWaWV3RW5jYXBzdWxhdGlvbi5Ob25lLFxyXG4gICAgdGVtcGxhdGU6IGBcclxuICAgICAgICA8dG9hc3Rlci1jb250YWluZXIgW3RvYXN0ZXJjb25maWddPSdfdG9hc3RlcmNvbmZpZyc+XHJcbiAgICAgICAgPC90b2FzdGVyLWNvbnRhaW5lcj5cclxuICAgICAgIGAsXHJcbn0pXHJcblxyXG5leHBvcnQgY2xhc3MgS2RBbGVydCBpbXBsZW1lbnRzIE9uSW5pdCB7XHJcbiAgICBwdWJsaWMgX3RvYXN0ZXJjb25maWc6IFRvYXN0ZXJDb25maWc7XHJcbiAgICBwcml2YXRlIF9jb25maWc6IGFueTtcclxuICAgIHByaXZhdGUgX3RvYXN0ZXJEZWZhdWx0Q29uZmlnOiBhbnkgPSB7XHJcbiAgICAgICAgc2hvd0Nsb3NlQnV0dG9uOiB0cnVlLFxyXG4gICAgICAgIHRhcFRvRGlzbWlzczogZmFsc2UsXHJcbiAgICAgICAgdGltZW91dDogLTEsXHJcbiAgICAgICAgbGltaXQ6IDUsXHJcbiAgICAgICAgcG9zaXRpb25DbGFzczogJ3RvYXN0LXRvcC1yaWdodCdcclxuICAgIH07XHJcblxyXG4gICAgY29uc3RydWN0b3IoXHJcbiAgICAgICAgcHJpdmF0ZSBfdG9hc3RlclNlcnZpY2U6IFRvYXN0ZXJTZXJ2aWNlLFxyXG4gICAgICAgIHByaXZhdGUgX2tkQWxlcnRFdmVudDogS2RBbGVydEV2ZW50XHJcbiAgICApIHsgfVxyXG5cclxuICAgIG5nT25Jbml0KCk6IHZvaWQge1xyXG4gICAgICAgIHRoaXMucmVnaXN0ZXJBbGVydEJyb2FkY2FzdCgpO1xyXG4gICAgfVxyXG5cclxuICAgIHJlZ2lzdGVyQWxlcnRCcm9hZGNhc3QoKTogdm9pZCB7XHJcbiAgICAgICAgdGhpcy5fa2RBbGVydEV2ZW50Lm9uKClcclxuICAgICAgICAgICAgLnN1YnNjcmliZShfdG9hc3QgPT4ge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5fY29uZmlnID0gT2JqZWN0LmFzc2lnbih7fSwgdGhpcy5fdG9hc3RlckRlZmF1bHRDb25maWcsIF90b2FzdCk7XHJcbiAgICAgICAgICAgICAgICB0aGlzLl90b2FzdGVyY29uZmlnID0gbmV3IFRvYXN0ZXJDb25maWcodGhpcy5fY29uZmlnKTtcclxuICAgICAgICAgICAgICAgIHRoaXMuX3RvYXN0ZXJTZXJ2aWNlLnBvcChfdG9hc3QpO1xyXG4gICAgICAgICAgICAgICAgLy8gdGhpcy5fdG9hc3RlclNlcnZpY2UucG9wKCdzdWNjZXNzJywgJ0FyZ3MgVGl0bGUnLCAnQXJncyBCb2R5Jyk7O1xyXG4gICAgICAgICAgICB9KTtcclxuICAgIH1cclxuXHJcbn1cclxuIl19