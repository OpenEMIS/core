import { Injectable } from '@angular/core';
import { KdBroadcaster } from '../kd-common/index';
import * as i0 from "@angular/core";
import * as i1 from "../kd-common/kd-broadcaster-svc";
export class KdAlertEvent {
    constructor(broadcaster) {
        this.broadcaster = broadcaster;
    }
    show(data) {
        this.broadcaster.broadcast(KdAlertEvent, data);
    }
    success(data) {
        data = Object.assign({}, data, { type: 'success' });
        this.broadcaster.broadcast(KdAlertEvent, data);
    }
    error(data) {
        data = Object.assign({}, data, { type: 'error', /*timeout: -1,*/ showCloseButton: true });
        this.broadcaster.broadcast(KdAlertEvent, data);
    }
    info(data) {
        data = Object.assign({}, data, { type: 'info' });
        this.broadcaster.broadcast(KdAlertEvent, data);
    }
    warn(data) {
        data = Object.assign({}, data, { type: 'warning', /*timeout: -1,*/ showCloseButton: true });
        this.broadcaster.broadcast(KdAlertEvent, data);
    }
    on() {
        return this.broadcaster.on(KdAlertEvent);
    }
}
KdAlertEvent.ɵprov = i0.ɵɵdefineInjectable({ factory: function KdAlertEvent_Factory() { return new KdAlertEvent(i0.ɵɵinject(i1.KdBroadcaster)); }, token: KdAlertEvent, providedIn: "root" });
KdAlertEvent.decorators = [
    { type: Injectable, args: [{
                providedIn: 'root'
            },] }
];
KdAlertEvent.ctorParameters = () => [
    { type: KdBroadcaster }
];
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoia2QtYWxlcnQtZXZlbnQuanMiLCJzb3VyY2VSb290IjoiQzoveGFtcHAvaHRkb2NzL1N0eWxlZ3VpZGUvaW9zdGctb3BlbmVtaXMtc3R5bGVndWlkZS9wcm9qZWN0cy9vcGVuZW1pcy1zdHlsZWd1aWRlLWxpYi9zcmMvIiwic291cmNlcyI6WyJrZC1jb21wb25lbnRzL2tkLWFuZ3VsYXItYWxlcnQva2QtYWxlcnQtZXZlbnQudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsT0FBTyxFQUFFLFVBQVUsRUFBRSxNQUFNLGVBQWUsQ0FBQztBQUUzQyxPQUFPLEVBQUUsYUFBYSxFQUFFLE1BQU0sb0JBQW9CLENBQUM7OztBQUtuRCxNQUFNLE9BQU8sWUFBWTtJQUNyQixZQUFvQixXQUEwQjtRQUExQixnQkFBVyxHQUFYLFdBQVcsQ0FBZTtJQUFJLENBQUM7SUFFbkQsSUFBSSxDQUFDLElBQVM7UUFDVixJQUFJLENBQUMsV0FBVyxDQUFDLFNBQVMsQ0FBQyxZQUFZLEVBQUUsSUFBSSxDQUFDLENBQUM7SUFDbkQsQ0FBQztJQUVELE9BQU8sQ0FBQyxJQUFTO1FBQ2IsSUFBSSxHQUFHLE1BQU0sQ0FBQyxNQUFNLENBQUMsRUFBRSxFQUFFLElBQUksRUFBRSxFQUFFLElBQUksRUFBRSxTQUFTLEVBQUUsQ0FBQyxDQUFDO1FBQ3BELElBQUksQ0FBQyxXQUFXLENBQUMsU0FBUyxDQUFDLFlBQVksRUFBRSxJQUFJLENBQUMsQ0FBQztJQUNuRCxDQUFDO0lBRUQsS0FBSyxDQUFDLElBQVM7UUFDWCxJQUFJLEdBQUcsTUFBTSxDQUFDLE1BQU0sQ0FBQyxFQUFFLEVBQUUsSUFBSSxFQUFFLEVBQUUsSUFBSSxFQUFFLE9BQU8sRUFBRSxnQkFBZ0IsQ0FBQyxlQUFlLEVBQUUsSUFBSSxFQUFFLENBQUMsQ0FBQztRQUMxRixJQUFJLENBQUMsV0FBVyxDQUFDLFNBQVMsQ0FBQyxZQUFZLEVBQUUsSUFBSSxDQUFDLENBQUM7SUFDbkQsQ0FBQztJQUVELElBQUksQ0FBQyxJQUFTO1FBQ1YsSUFBSSxHQUFHLE1BQU0sQ0FBQyxNQUFNLENBQUMsRUFBRSxFQUFFLElBQUksRUFBRSxFQUFFLElBQUksRUFBRSxNQUFNLEVBQUUsQ0FBQyxDQUFDO1FBQ2pELElBQUksQ0FBQyxXQUFXLENBQUMsU0FBUyxDQUFDLFlBQVksRUFBRSxJQUFJLENBQUMsQ0FBQztJQUNuRCxDQUFDO0lBRUQsSUFBSSxDQUFDLElBQVM7UUFDVixJQUFJLEdBQUcsTUFBTSxDQUFDLE1BQU0sQ0FBQyxFQUFFLEVBQUUsSUFBSSxFQUFFLEVBQUUsSUFBSSxFQUFFLFNBQVMsRUFBRSxnQkFBZ0IsQ0FBQyxlQUFlLEVBQUUsSUFBSSxFQUFFLENBQUMsQ0FBQztRQUM1RixJQUFJLENBQUMsV0FBVyxDQUFDLFNBQVMsQ0FBQyxZQUFZLEVBQUUsSUFBSSxDQUFDLENBQUM7SUFDbkQsQ0FBQztJQUVELEVBQUU7UUFDRSxPQUFPLElBQUksQ0FBQyxXQUFXLENBQUMsRUFBRSxDQUFNLFlBQVksQ0FBQyxDQUFDO0lBQ2xELENBQUM7Ozs7WUFoQ0osVUFBVSxTQUFFO2dCQUNSLFVBQVUsRUFBRSxNQUFNO2FBQ3RCOzs7WUFKUSxhQUFhIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgSW5qZWN0YWJsZSB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xyXG5pbXBvcnQgeyBPYnNlcnZhYmxlIH0gZnJvbSAncnhqcyc7XHJcbmltcG9ydCB7IEtkQnJvYWRjYXN0ZXIgfSBmcm9tICcuLi9rZC1jb21tb24vaW5kZXgnO1xyXG5cclxuQEluamVjdGFibGUoIHtcclxuICAgICBwcm92aWRlZEluOiAncm9vdCdcclxufSApXHJcbmV4cG9ydCBjbGFzcyBLZEFsZXJ0RXZlbnQge1xyXG4gICAgY29uc3RydWN0b3IocHJpdmF0ZSBicm9hZGNhc3RlcjogS2RCcm9hZGNhc3RlcikgeyB9XHJcblxyXG4gICAgc2hvdyhkYXRhOiBhbnkpOiB2b2lkIHtcclxuICAgICAgICB0aGlzLmJyb2FkY2FzdGVyLmJyb2FkY2FzdChLZEFsZXJ0RXZlbnQsIGRhdGEpO1xyXG4gICAgfVxyXG5cclxuICAgIHN1Y2Nlc3MoZGF0YTogYW55KTogdm9pZCB7XHJcbiAgICAgICAgZGF0YSA9IE9iamVjdC5hc3NpZ24oe30sIGRhdGEsIHsgdHlwZTogJ3N1Y2Nlc3MnIH0pO1xyXG4gICAgICAgIHRoaXMuYnJvYWRjYXN0ZXIuYnJvYWRjYXN0KEtkQWxlcnRFdmVudCwgZGF0YSk7XHJcbiAgICB9XHJcblxyXG4gICAgZXJyb3IoZGF0YTogYW55KTogdm9pZCB7XHJcbiAgICAgICAgZGF0YSA9IE9iamVjdC5hc3NpZ24oe30sIGRhdGEsIHsgdHlwZTogJ2Vycm9yJywgLyp0aW1lb3V0OiAtMSwqLyBzaG93Q2xvc2VCdXR0b246IHRydWUgfSk7XHJcbiAgICAgICAgdGhpcy5icm9hZGNhc3Rlci5icm9hZGNhc3QoS2RBbGVydEV2ZW50LCBkYXRhKTtcclxuICAgIH1cclxuXHJcbiAgICBpbmZvKGRhdGE6IGFueSk6IHZvaWQge1xyXG4gICAgICAgIGRhdGEgPSBPYmplY3QuYXNzaWduKHt9LCBkYXRhLCB7IHR5cGU6ICdpbmZvJyB9KTtcclxuICAgICAgICB0aGlzLmJyb2FkY2FzdGVyLmJyb2FkY2FzdChLZEFsZXJ0RXZlbnQsIGRhdGEpO1xyXG4gICAgfVxyXG5cclxuICAgIHdhcm4oZGF0YTogYW55KTogdm9pZCB7XHJcbiAgICAgICAgZGF0YSA9IE9iamVjdC5hc3NpZ24oe30sIGRhdGEsIHsgdHlwZTogJ3dhcm5pbmcnLCAvKnRpbWVvdXQ6IC0xLCovIHNob3dDbG9zZUJ1dHRvbjogdHJ1ZSB9KTtcclxuICAgICAgICB0aGlzLmJyb2FkY2FzdGVyLmJyb2FkY2FzdChLZEFsZXJ0RXZlbnQsIGRhdGEpO1xyXG4gICAgfVxyXG5cclxuICAgIG9uKCk6IE9ic2VydmFibGU8YW55PiB7XHJcbiAgICAgICAgcmV0dXJuIHRoaXMuYnJvYWRjYXN0ZXIub248YW55PihLZEFsZXJ0RXZlbnQpO1xyXG4gICAgfVxyXG59XHJcbiJdfQ==