import { Component, Input, Output, ViewContainerRef, EventEmitter, HostListener, Renderer2 } from '@angular/core';
import { timer } from 'rxjs';
import { Router, NavigationEnd } from '@angular/router';
import { KdDomElemSvc } from '../kd-common/index';
export class KdFooter {
    constructor(_vcr, _router, _renderer, _domSvc) {
        this._vcr = _vcr;
        this._router = _router;
        this._renderer = _renderer;
        this._domSvc = _domSvc;
        this._currentYear = new Date().getFullYear();
        this.checkFloat = new EventEmitter();
        this._el = this._vcr.element;
    }
    onResize(event) {
        this.onMobileView();
    }
    ngOnInit() {
        this._float = (typeof this.enableFloat !== 'undefined' && this.enableFloat === 'false') ? false : true;
        this._setVersioning();
    }
    ngAfterViewInit() {
        this._router.events.subscribe(event => {
            if (event instanceof NavigationEnd) {
                timer(200).subscribe(() => {
                    this.onMobileView();
                });
            }
        });
    }
    onMobileView() {
        // let windowSize: number = window.innerWidth;
        let contentArea = this._el.nativeElement.previousElementSibling;
        let contentHeight = contentArea.getBoundingClientRect().height;
        let spliterWrapper = document.querySelector('kd-splitter.main');
        // console.log(spliterWrapper);
        if (spliterWrapper === null)
            return false;
        // let contentWrapperHeight = this._el.nativeElement.parentElement.parentElement.getBoundingClientRect().height;
        // let kdPaneHeight = this._el.nativeElement.parentElement.parentElement.parentElement.parentElement.getBoundingClientRect().height;
        let kdPaneHeight = spliterWrapper.querySelector('.pane-2').getBoundingClientRect().height;
        // let wrapperElement = this._el.nativeElement.parentElement.parentElement.parentElement;
        let wrapperElement = spliterWrapper.querySelector('.main-wrapper');
        // let contentWrapperHeight: number = spliterWrapper.querySelector('.content-wrapper').getBoundingClientRect().height;
        // console.log(spliterWrapper.querySelector('.pane-2'));
        // console.log(this._el.nativeElement.parentElement.parentElement.parentElement);
        // console.log('Content Height,' + contentHeight);
        // console.log('contentWrapperHeight,' + contentWrapperHeight);
        // console.log(this._el.nativeElement.parentElement.parentElement);
        if (contentArea !== undefined) {
            if (this._domSvc.isMobile()) {
                if (contentHeight < kdPaneHeight) {
                    this.checkFloat.emit('absolute');
                    this._renderer.setStyle(this._el.nativeElement, 'position', 'absolute');
                    // this._renderer.setElementStyle(wrapperElement, 'height', '100%');
                    // this._renderer.setElementClass(this._el.nativeElement.parentElement.parentElement.parentElement, 'has-footer', true);
                    // this._renderer.setElementStyle(wrapperElement, 'height', '100%');
                    // this._renderer.setElementClass(this._el.nativeElement.parentElement.parentElement.parentElement, 'has-footer', true);
                    this._renderer.addClass(wrapperElement, 'has-footer');
                }
                else {
                    if (this._float) {
                        this.checkFloat.emit('float');
                        this._renderer.setStyle(this._el.nativeElement, 'position', 'relative');
                        // this._renderer.setElementStyle(wrapperElement, 'height', 'auto');
                        // this._renderer.setElementClass(this._el.nativeElement.parentElement.parentElement.parentElement, 'has-footer', false);
                        // this._renderer.setElementStyle(wrapperElement, 'height', 'auto');
                        // this._renderer.setElementClass(this._el.nativeElement.parentElement.parentElement.parentElement, 'has-footer', false);
                        this._renderer.removeClass(wrapperElement, 'has-footer');
                    }
                }
            }
            else {
                this.checkFloat.emit('fixed');
                this._renderer.setStyle(this._el.nativeElement, 'position', 'fixed');
                // this._renderer.setElementClass(this._el.nativeElement.parentElement.parentElement.parentElement, 'has-footer', true);
                // this._renderer.setElementClass(this._el.nativeElement.parentElement.parentElement.parentElement, 'has-footer', true);
                this._renderer.addClass(wrapperElement, 'has-footer');
            }
        }
        return true;
    }
    _setVersioning() {
        try {
            // console.log('in try');
            this._latestVersion = app_version;
        }
        catch (err) {
            // console.log(err);
            this._latestVersion = (typeof this.version !== 'undefined') ? this.version : '1.0.0';
        }
    }
}
KdFooter.decorators = [
    { type: Component, args: [{
                selector: 'kd-footer',
                template: `
        <footer>
            <p *ngIf="!enableCustom">Copyright © {{_currentYear}} OpenEMIS. All rights reserved. | Version {{_latestVersion}}</p>
            <p *ngIf="enableCustom">{{customMessage}} | Version {{_latestVersion}}</p>
        </footer>
    `,
                providers: [KdDomElemSvc],
                host: { 'class': 'kdx-footer' }
            },] }
];
KdFooter.ctorParameters = () => [
    { type: ViewContainerRef },
    { type: Router },
    { type: Renderer2 },
    { type: KdDomElemSvc }
];
KdFooter.propDecorators = {
    version: [{ type: Input }],
    enableCustom: [{ type: Input }],
    customMessage: [{ type: Input }],
    enableFloat: [{ type: Input }],
    checkFloat: [{ type: Output }],
    onResize: [{ type: HostListener, args: ['window:resize', ['$event'],] }]
};
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoia2QtYW5ndWxhci1mb290ZXIuanMiLCJzb3VyY2VSb290IjoiQzoveGFtcHAvaHRkb2NzL1N0eWxlZ3VpZGUvaW9zdGctb3BlbmVtaXMtc3R5bGVndWlkZS9wcm9qZWN0cy9vcGVuZW1pcy1zdHlsZWd1aWRlLWxpYi9zcmMvIiwic291cmNlcyI6WyJrZC1jb21wb25lbnRzL2tkLWFuZ3VsYXItZm9vdGVyL2tkLWFuZ3VsYXItZm9vdGVyLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBLE9BQU8sRUFBRSxTQUFTLEVBQUUsS0FBSyxFQUFFLE1BQU0sRUFBRSxnQkFBZ0IsRUFBcUMsWUFBWSxFQUFFLFlBQVksRUFBRSxTQUFTLEVBQUUsTUFBTSxlQUFlLENBQUM7QUFDckosT0FBTyxFQUFFLEtBQUssRUFBRSxNQUFNLE1BQU0sQ0FBQztBQUM3QixPQUFPLEVBQUUsTUFBTSxFQUFFLGFBQWEsRUFBRSxNQUFNLGlCQUFpQixDQUFDO0FBQ3hELE9BQU8sRUFBRSxZQUFZLEVBQUUsTUFBTSxvQkFBb0IsQ0FBQztBQWdCbEQsTUFBTSxPQUFPLFFBQVE7SUFhakIsWUFDWSxJQUFzQixFQUN0QixPQUFlLEVBQ2YsU0FBb0IsRUFDcEIsT0FBcUI7UUFIckIsU0FBSSxHQUFKLElBQUksQ0FBa0I7UUFDdEIsWUFBTyxHQUFQLE9BQU8sQ0FBUTtRQUNmLGNBQVMsR0FBVCxTQUFTLENBQVc7UUFDcEIsWUFBTyxHQUFQLE9BQU8sQ0FBYztRQWhCMUIsaUJBQVksR0FBVyxJQUFJLElBQUksRUFBRSxDQUFDLFdBQVcsRUFBRSxDQUFDO1FBVTdDLGVBQVUsR0FBRyxJQUFJLFlBQVksRUFBRSxDQUFDO1FBT3RDLElBQUksQ0FBQyxHQUFHLEdBQUcsSUFBSSxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUM7SUFDakMsQ0FBQztJQUdELFFBQVEsQ0FBQyxLQUFVO1FBQ2YsSUFBSSxDQUFDLFlBQVksRUFBRSxDQUFDO0lBQ3hCLENBQUM7SUFFRCxRQUFRO1FBQ0osSUFBSSxDQUFDLE1BQU0sR0FBRyxDQUFDLE9BQU8sSUFBSSxDQUFDLFdBQVcsS0FBSyxXQUFXLElBQUksSUFBSSxDQUFDLFdBQVcsS0FBSyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUM7UUFDdkcsSUFBSSxDQUFDLGNBQWMsRUFBRSxDQUFDO0lBQzFCLENBQUM7SUFFRCxlQUFlO1FBQ1gsSUFBSSxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsU0FBUyxDQUFDLEtBQUssQ0FBQyxFQUFFO1lBQ2xDLElBQUksS0FBSyxZQUFZLGFBQWEsRUFBRTtnQkFDaEMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxHQUFTLEVBQUU7b0JBQzVCLElBQUksQ0FBQyxZQUFZLEVBQUUsQ0FBQztnQkFDeEIsQ0FBQyxDQUFDLENBQUM7YUFDTjtRQUNMLENBQUMsQ0FBQyxDQUFDO0lBQ1AsQ0FBQztJQUVELFlBQVk7UUFDUiw4Q0FBOEM7UUFDOUMsSUFBSSxXQUFXLEdBQVksSUFBSSxDQUFDLEdBQUcsQ0FBQyxhQUFhLENBQUMsc0JBQXNCLENBQUM7UUFDekUsSUFBSSxhQUFhLEdBQVcsV0FBVyxDQUFDLHFCQUFxQixFQUFFLENBQUMsTUFBTSxDQUFDO1FBQ3ZFLElBQUksY0FBYyxHQUFZLFFBQVEsQ0FBQyxhQUFhLENBQUMsa0JBQWtCLENBQUMsQ0FBQztRQUN6RSwrQkFBK0I7UUFDL0IsSUFBSSxjQUFjLEtBQUssSUFBSTtZQUFFLE9BQU8sS0FBSyxDQUFDO1FBQzFDLGdIQUFnSDtRQUNoSCxvSUFBb0k7UUFDcEksSUFBSSxZQUFZLEdBQVcsY0FBYyxDQUFDLGFBQWEsQ0FBQyxTQUFTLENBQUMsQ0FBQyxxQkFBcUIsRUFBRSxDQUFDLE1BQU0sQ0FBQztRQUNsRyx5RkFBeUY7UUFDekYsSUFBSSxjQUFjLEdBQVksY0FBYyxDQUFDLGFBQWEsQ0FBQyxlQUFlLENBQUMsQ0FBQztRQUM1RSxzSEFBc0g7UUFDdEgsd0RBQXdEO1FBQ3hELGlGQUFpRjtRQUNqRixrREFBa0Q7UUFDbEQsK0RBQStEO1FBQy9ELG1FQUFtRTtRQUNuRSxJQUFJLFdBQVcsS0FBSyxTQUFTLEVBQUU7WUFDM0IsSUFBSSxJQUFJLENBQUMsT0FBTyxDQUFDLFFBQVEsRUFBRSxFQUFFO2dCQUN6QixJQUFJLGFBQWEsR0FBRyxZQUFZLEVBQUU7b0JBQzlCLElBQUksQ0FBQyxVQUFVLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxDQUFDO29CQUVqQyxJQUFJLENBQUMsU0FBUyxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLGFBQWEsRUFBRSxVQUFVLEVBQUUsVUFBVSxDQUFDLENBQUM7b0JBQ3hFLG9FQUFvRTtvQkFDcEUsd0hBQXdIO29CQUN4SCxvRUFBb0U7b0JBQ3hGLHdIQUF3SDtvQkFDeEgsSUFBSSxDQUFDLFNBQVMsQ0FBQyxRQUFRLENBQUMsY0FBYyxFQUFFLFlBQVksQ0FBQyxDQUFDO2lCQUNyQztxQkFBTTtvQkFDSCxJQUFJLElBQUksQ0FBQyxNQUFNLEVBQUU7d0JBQ2IsSUFBSSxDQUFDLFVBQVUsQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLENBQUM7d0JBRTlCLElBQUksQ0FBQyxTQUFTLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsYUFBYSxFQUFFLFVBQVUsRUFBRSxVQUFVLENBQUMsQ0FBQzt3QkFDeEUsb0VBQW9FO3dCQUNwRSx5SEFBeUg7d0JBQ3pILG9FQUFvRTt3QkFDNUYseUhBQXlIO3dCQUN6SCxJQUFJLENBQUMsU0FBUyxDQUFDLFdBQVcsQ0FBQyxjQUFjLEVBQUUsWUFBWSxDQUFDLENBQUM7cUJBQ3BDO2lCQUNKO2FBQ0o7aUJBQU07Z0JBQ0gsSUFBSSxDQUFDLFVBQVUsQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLENBQUM7Z0JBRTlCLElBQUksQ0FBQyxTQUFTLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsYUFBYSxFQUFFLFVBQVUsRUFBRSxPQUFPLENBQUMsQ0FBQztnQkFDckUsd0hBQXdIO2dCQUN4SCx3SEFBd0g7Z0JBQ3hJLElBQUksQ0FBQyxTQUFTLENBQUMsUUFBUSxDQUFDLGNBQWMsRUFBRSxZQUFZLENBQUMsQ0FBQzthQUV6QztTQUNKO1FBRUQsT0FBTyxJQUFJLENBQUM7SUFDaEIsQ0FBQztJQUVPLGNBQWM7UUFDbEIsSUFBSTtZQUNBLHlCQUF5QjtZQUN6QixJQUFJLENBQUMsY0FBYyxHQUFHLFdBQVcsQ0FBQztTQUVyQztRQUFDLE9BQU8sR0FBRyxFQUFFO1lBQ1Ysb0JBQW9CO1lBQ3BCLElBQUksQ0FBQyxjQUFjLEdBQUcsQ0FBQyxPQUFPLElBQUksQ0FBQyxPQUFPLEtBQUssV0FBVyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQztTQUN4RjtJQUNMLENBQUM7OztZQXJISixTQUFTLFNBQUM7Z0JBQ1AsUUFBUSxFQUFFLFdBQVc7Z0JBQ3JCLFFBQVEsRUFBRTs7Ozs7S0FLVDtnQkFDRCxTQUFTLEVBQUUsQ0FBQyxZQUFZLENBQUM7Z0JBQ3pCLElBQUksRUFBRyxFQUFFLE9BQU8sRUFBRyxZQUFZLEVBQUU7YUFDcEM7OztZQWpCa0MsZ0JBQWdCO1lBRTFDLE1BQU07WUFGcUcsU0FBUztZQUdwSCxZQUFZOzs7c0JBdUJoQixLQUFLOzJCQUNMLEtBQUs7NEJBQ0wsS0FBSzswQkFDTCxLQUFLO3lCQUNMLE1BQU07dUJBVU4sWUFBWSxTQUFDLGVBQWUsRUFBRSxDQUFDLFFBQVEsQ0FBQyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IENvbXBvbmVudCwgSW5wdXQsIE91dHB1dCwgVmlld0NvbnRhaW5lclJlZiwgRWxlbWVudFJlZiwgT25Jbml0LCBBZnRlclZpZXdJbml0LCBFdmVudEVtaXR0ZXIsIEhvc3RMaXN0ZW5lciwgUmVuZGVyZXIyIH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XHJcbmltcG9ydCB7IHRpbWVyIH0gZnJvbSAncnhqcyc7XHJcbmltcG9ydCB7IFJvdXRlciwgTmF2aWdhdGlvbkVuZCB9IGZyb20gJ0Bhbmd1bGFyL3JvdXRlcic7XHJcbmltcG9ydCB7IEtkRG9tRWxlbVN2YyB9IGZyb20gJy4uL2tkLWNvbW1vbi9pbmRleCc7XHJcblxyXG5kZWNsYXJlIGxldCBhcHBfdmVyc2lvbjogc3RyaW5nO1xyXG5cclxuQENvbXBvbmVudCh7XHJcbiAgICBzZWxlY3RvcjogJ2tkLWZvb3RlcicsXHJcbiAgICB0ZW1wbGF0ZTogYFxyXG4gICAgICAgIDxmb290ZXI+XHJcbiAgICAgICAgICAgIDxwICpuZ0lmPVwiIWVuYWJsZUN1c3RvbVwiPkNvcHlyaWdodCDCqSB7e19jdXJyZW50WWVhcn19IE9wZW5FTUlTLiBBbGwgcmlnaHRzIHJlc2VydmVkLiB8IFZlcnNpb24ge3tfbGF0ZXN0VmVyc2lvbn19PC9wPlxyXG4gICAgICAgICAgICA8cCAqbmdJZj1cImVuYWJsZUN1c3RvbVwiPnt7Y3VzdG9tTWVzc2FnZX19IHwgVmVyc2lvbiB7e19sYXRlc3RWZXJzaW9ufX08L3A+XHJcbiAgICAgICAgPC9mb290ZXI+XHJcbiAgICBgLFxyXG4gICAgcHJvdmlkZXJzOiBbS2REb21FbGVtU3ZjXSxcclxuICAgIGhvc3QgOiB7ICdjbGFzcycgOiAna2R4LWZvb3RlcicgfVxyXG59KVxyXG5cclxuZXhwb3J0IGNsYXNzIEtkRm9vdGVyIGltcGxlbWVudHMgT25Jbml0LCBBZnRlclZpZXdJbml0IHtcclxuICAgIHB1YmxpYyBfY3VycmVudFllYXI6IG51bWJlciA9IG5ldyBEYXRlKCkuZ2V0RnVsbFllYXIoKTtcclxuICAgIHB1YmxpYyBfbGF0ZXN0VmVyc2lvbjogc3RyaW5nO1xyXG5cclxuICAgIHByaXZhdGUgX2VsOiBFbGVtZW50UmVmO1xyXG4gICAgcHJpdmF0ZSBfZmxvYXQ6IGJvb2xlYW47XHJcblxyXG4gICAgQElucHV0KCkgdmVyc2lvbjogc3RyaW5nO1xyXG4gICAgQElucHV0KCkgZW5hYmxlQ3VzdG9tOiBib29sZWFuO1xyXG4gICAgQElucHV0KCkgY3VzdG9tTWVzc2FnZTogc3RyaW5nO1xyXG4gICAgQElucHV0KCkgZW5hYmxlRmxvYXQ6IHN0cmluZztcclxuICAgIEBPdXRwdXQoKSBjaGVja0Zsb2F0ID0gbmV3IEV2ZW50RW1pdHRlcigpO1xyXG5cclxuICAgIGNvbnN0cnVjdG9yKFxyXG4gICAgICAgIHByaXZhdGUgX3ZjcjogVmlld0NvbnRhaW5lclJlZixcclxuICAgICAgICBwcml2YXRlIF9yb3V0ZXI6IFJvdXRlcixcclxuICAgICAgICBwcml2YXRlIF9yZW5kZXJlcjogUmVuZGVyZXIyLFxyXG4gICAgICAgIHByaXZhdGUgX2RvbVN2YzogS2REb21FbGVtU3ZjKSB7XHJcbiAgICAgICAgdGhpcy5fZWwgPSB0aGlzLl92Y3IuZWxlbWVudDtcclxuICAgIH1cclxuXHJcbiAgICBASG9zdExpc3RlbmVyKCd3aW5kb3c6cmVzaXplJywgWyckZXZlbnQnXSlcclxuICAgIG9uUmVzaXplKGV2ZW50OiBhbnkpIHtcclxuICAgICAgICB0aGlzLm9uTW9iaWxlVmlldygpO1xyXG4gICAgfVxyXG5cclxuICAgIG5nT25Jbml0KCk6IHZvaWQge1xyXG4gICAgICAgIHRoaXMuX2Zsb2F0ID0gKHR5cGVvZiB0aGlzLmVuYWJsZUZsb2F0ICE9PSAndW5kZWZpbmVkJyAmJiB0aGlzLmVuYWJsZUZsb2F0ID09PSAnZmFsc2UnKSA/IGZhbHNlIDogdHJ1ZTtcclxuICAgICAgICB0aGlzLl9zZXRWZXJzaW9uaW5nKCk7XHJcbiAgICB9XHJcblxyXG4gICAgbmdBZnRlclZpZXdJbml0KCk6IHZvaWQge1xyXG4gICAgICAgIHRoaXMuX3JvdXRlci5ldmVudHMuc3Vic2NyaWJlKGV2ZW50ID0+IHtcclxuICAgICAgICAgICAgaWYgKGV2ZW50IGluc3RhbmNlb2YgTmF2aWdhdGlvbkVuZCkge1xyXG4gICAgICAgICAgICAgICAgdGltZXIoMjAwKS5zdWJzY3JpYmUoKCk6IHZvaWQgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMub25Nb2JpbGVWaWV3KCk7XHJcbiAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH0pO1xyXG4gICAgfVxyXG5cclxuICAgIG9uTW9iaWxlVmlldygpOiBib29sZWFuIHtcclxuICAgICAgICAvLyBsZXQgd2luZG93U2l6ZTogbnVtYmVyID0gd2luZG93LmlubmVyV2lkdGg7XHJcbiAgICAgICAgbGV0IGNvbnRlbnRBcmVhOiBFbGVtZW50ID0gdGhpcy5fZWwubmF0aXZlRWxlbWVudC5wcmV2aW91c0VsZW1lbnRTaWJsaW5nO1xyXG4gICAgICAgIGxldCBjb250ZW50SGVpZ2h0OiBudW1iZXIgPSBjb250ZW50QXJlYS5nZXRCb3VuZGluZ0NsaWVudFJlY3QoKS5oZWlnaHQ7XHJcbiAgICAgICAgbGV0IHNwbGl0ZXJXcmFwcGVyOiBFbGVtZW50ID0gZG9jdW1lbnQucXVlcnlTZWxlY3Rvcigna2Qtc3BsaXR0ZXIubWFpbicpO1xyXG4gICAgICAgIC8vIGNvbnNvbGUubG9nKHNwbGl0ZXJXcmFwcGVyKTtcclxuICAgICAgICBpZiAoc3BsaXRlcldyYXBwZXIgPT09IG51bGwpIHJldHVybiBmYWxzZTtcclxuICAgICAgICAvLyBsZXQgY29udGVudFdyYXBwZXJIZWlnaHQgPSB0aGlzLl9lbC5uYXRpdmVFbGVtZW50LnBhcmVudEVsZW1lbnQucGFyZW50RWxlbWVudC5nZXRCb3VuZGluZ0NsaWVudFJlY3QoKS5oZWlnaHQ7XHJcbiAgICAgICAgLy8gbGV0IGtkUGFuZUhlaWdodCA9IHRoaXMuX2VsLm5hdGl2ZUVsZW1lbnQucGFyZW50RWxlbWVudC5wYXJlbnRFbGVtZW50LnBhcmVudEVsZW1lbnQucGFyZW50RWxlbWVudC5nZXRCb3VuZGluZ0NsaWVudFJlY3QoKS5oZWlnaHQ7XHJcbiAgICAgICAgbGV0IGtkUGFuZUhlaWdodDogbnVtYmVyID0gc3BsaXRlcldyYXBwZXIucXVlcnlTZWxlY3RvcignLnBhbmUtMicpLmdldEJvdW5kaW5nQ2xpZW50UmVjdCgpLmhlaWdodDtcclxuICAgICAgICAvLyBsZXQgd3JhcHBlckVsZW1lbnQgPSB0aGlzLl9lbC5uYXRpdmVFbGVtZW50LnBhcmVudEVsZW1lbnQucGFyZW50RWxlbWVudC5wYXJlbnRFbGVtZW50O1xyXG4gICAgICAgIGxldCB3cmFwcGVyRWxlbWVudDogRWxlbWVudCA9IHNwbGl0ZXJXcmFwcGVyLnF1ZXJ5U2VsZWN0b3IoJy5tYWluLXdyYXBwZXInKTtcclxuICAgICAgICAvLyBsZXQgY29udGVudFdyYXBwZXJIZWlnaHQ6IG51bWJlciA9IHNwbGl0ZXJXcmFwcGVyLnF1ZXJ5U2VsZWN0b3IoJy5jb250ZW50LXdyYXBwZXInKS5nZXRCb3VuZGluZ0NsaWVudFJlY3QoKS5oZWlnaHQ7XHJcbiAgICAgICAgLy8gY29uc29sZS5sb2coc3BsaXRlcldyYXBwZXIucXVlcnlTZWxlY3RvcignLnBhbmUtMicpKTtcclxuICAgICAgICAvLyBjb25zb2xlLmxvZyh0aGlzLl9lbC5uYXRpdmVFbGVtZW50LnBhcmVudEVsZW1lbnQucGFyZW50RWxlbWVudC5wYXJlbnRFbGVtZW50KTtcclxuICAgICAgICAvLyBjb25zb2xlLmxvZygnQ29udGVudCBIZWlnaHQsJyArIGNvbnRlbnRIZWlnaHQpO1xyXG4gICAgICAgIC8vIGNvbnNvbGUubG9nKCdjb250ZW50V3JhcHBlckhlaWdodCwnICsgY29udGVudFdyYXBwZXJIZWlnaHQpO1xyXG4gICAgICAgIC8vIGNvbnNvbGUubG9nKHRoaXMuX2VsLm5hdGl2ZUVsZW1lbnQucGFyZW50RWxlbWVudC5wYXJlbnRFbGVtZW50KTtcclxuICAgICAgICBpZiAoY29udGVudEFyZWEgIT09IHVuZGVmaW5lZCkge1xyXG4gICAgICAgICAgICBpZiAodGhpcy5fZG9tU3ZjLmlzTW9iaWxlKCkpIHtcclxuICAgICAgICAgICAgICAgIGlmIChjb250ZW50SGVpZ2h0IDwga2RQYW5lSGVpZ2h0KSB7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5jaGVja0Zsb2F0LmVtaXQoJ2Fic29sdXRlJyk7XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuX3JlbmRlcmVyLnNldFN0eWxlKHRoaXMuX2VsLm5hdGl2ZUVsZW1lbnQsICdwb3NpdGlvbicsICdhYnNvbHV0ZScpO1xyXG4gICAgICAgICAgICAgICAgICAgIC8vIHRoaXMuX3JlbmRlcmVyLnNldEVsZW1lbnRTdHlsZSh3cmFwcGVyRWxlbWVudCwgJ2hlaWdodCcsICcxMDAlJyk7XHJcbiAgICAgICAgICAgICAgICAgICAgLy8gdGhpcy5fcmVuZGVyZXIuc2V0RWxlbWVudENsYXNzKHRoaXMuX2VsLm5hdGl2ZUVsZW1lbnQucGFyZW50RWxlbWVudC5wYXJlbnRFbGVtZW50LnBhcmVudEVsZW1lbnQsICdoYXMtZm9vdGVyJywgdHJ1ZSk7XHJcbiAgICAgICAgICAgICAgICAgICAgLy8gdGhpcy5fcmVuZGVyZXIuc2V0RWxlbWVudFN0eWxlKHdyYXBwZXJFbGVtZW50LCAnaGVpZ2h0JywgJzEwMCUnKTtcclxuLy8gdGhpcy5fcmVuZGVyZXIuc2V0RWxlbWVudENsYXNzKHRoaXMuX2VsLm5hdGl2ZUVsZW1lbnQucGFyZW50RWxlbWVudC5wYXJlbnRFbGVtZW50LnBhcmVudEVsZW1lbnQsICdoYXMtZm9vdGVyJywgdHJ1ZSk7XHJcbnRoaXMuX3JlbmRlcmVyLmFkZENsYXNzKHdyYXBwZXJFbGVtZW50LCAnaGFzLWZvb3RlcicpO1xyXG4gICAgICAgICAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgICAgICAgICBpZiAodGhpcy5fZmxvYXQpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5jaGVja0Zsb2F0LmVtaXQoJ2Zsb2F0Jyk7XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLl9yZW5kZXJlci5zZXRTdHlsZSh0aGlzLl9lbC5uYXRpdmVFbGVtZW50LCAncG9zaXRpb24nLCAncmVsYXRpdmUnKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgLy8gdGhpcy5fcmVuZGVyZXIuc2V0RWxlbWVudFN0eWxlKHdyYXBwZXJFbGVtZW50LCAnaGVpZ2h0JywgJ2F1dG8nKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgLy8gdGhpcy5fcmVuZGVyZXIuc2V0RWxlbWVudENsYXNzKHRoaXMuX2VsLm5hdGl2ZUVsZW1lbnQucGFyZW50RWxlbWVudC5wYXJlbnRFbGVtZW50LnBhcmVudEVsZW1lbnQsICdoYXMtZm9vdGVyJywgZmFsc2UpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAvLyB0aGlzLl9yZW5kZXJlci5zZXRFbGVtZW50U3R5bGUod3JhcHBlckVsZW1lbnQsICdoZWlnaHQnLCAnYXV0bycpO1xyXG4vLyB0aGlzLl9yZW5kZXJlci5zZXRFbGVtZW50Q2xhc3ModGhpcy5fZWwubmF0aXZlRWxlbWVudC5wYXJlbnRFbGVtZW50LnBhcmVudEVsZW1lbnQucGFyZW50RWxlbWVudCwgJ2hhcy1mb290ZXInLCBmYWxzZSk7XHJcbnRoaXMuX3JlbmRlcmVyLnJlbW92ZUNsYXNzKHdyYXBwZXJFbGVtZW50LCAnaGFzLWZvb3RlcicpO1xyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgICAgIHRoaXMuY2hlY2tGbG9hdC5lbWl0KCdmaXhlZCcpO1xyXG5cclxuICAgICAgICAgICAgICAgIHRoaXMuX3JlbmRlcmVyLnNldFN0eWxlKHRoaXMuX2VsLm5hdGl2ZUVsZW1lbnQsICdwb3NpdGlvbicsICdmaXhlZCcpO1xyXG4gICAgICAgICAgICAgICAgLy8gdGhpcy5fcmVuZGVyZXIuc2V0RWxlbWVudENsYXNzKHRoaXMuX2VsLm5hdGl2ZUVsZW1lbnQucGFyZW50RWxlbWVudC5wYXJlbnRFbGVtZW50LnBhcmVudEVsZW1lbnQsICdoYXMtZm9vdGVyJywgdHJ1ZSk7XHJcbiAgICAgICAgICAgICAgICAvLyB0aGlzLl9yZW5kZXJlci5zZXRFbGVtZW50Q2xhc3ModGhpcy5fZWwubmF0aXZlRWxlbWVudC5wYXJlbnRFbGVtZW50LnBhcmVudEVsZW1lbnQucGFyZW50RWxlbWVudCwgJ2hhcy1mb290ZXInLCB0cnVlKTtcclxudGhpcy5fcmVuZGVyZXIuYWRkQ2xhc3Mod3JhcHBlckVsZW1lbnQsICdoYXMtZm9vdGVyJyk7XHJcblxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICByZXR1cm4gdHJ1ZTtcclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF9zZXRWZXJzaW9uaW5nKCk6IHZvaWQge1xyXG4gICAgICAgIHRyeSB7XHJcbiAgICAgICAgICAgIC8vIGNvbnNvbGUubG9nKCdpbiB0cnknKTtcclxuICAgICAgICAgICAgdGhpcy5fbGF0ZXN0VmVyc2lvbiA9IGFwcF92ZXJzaW9uO1xyXG5cclxuICAgICAgICB9IGNhdGNoIChlcnIpIHtcclxuICAgICAgICAgICAgLy8gY29uc29sZS5sb2coZXJyKTtcclxuICAgICAgICAgICAgdGhpcy5fbGF0ZXN0VmVyc2lvbiA9ICh0eXBlb2YgdGhpcy52ZXJzaW9uICE9PSAndW5kZWZpbmVkJykgPyB0aGlzLnZlcnNpb24gOiAnMS4wLjAnO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxufVxyXG4iXX0=