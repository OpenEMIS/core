import { Injectable } from '@angular/core';
import { KdBroadcaster } from '../../kd-common/index';
import * as i0 from "@angular/core";
import * as i1 from "../../kd-common/kd-broadcaster-svc";
export class KdSplitterEvent {
    constructor(broadcaster) {
        this.broadcaster = broadcaster;
    }
    fire(data) {
        this.broadcaster.broadcast('KdSplitterEvent_SideMenu', data);
    }
    on() {
        return this.broadcaster.on('KdSplitterEvent_SideMenu');
    }
    drag(data) {
        this.broadcaster.broadcast('KdSplitterEvent_Drag', data);
    }
    onDrag() {
        return this.broadcaster.on('KdSplitterEvent_Drag');
    }
    toggleMenu(data) {
        this.broadcaster.broadcast('KdSplitterEvent_ToggleMenu', data);
    }
    onToggleMenu() {
        return this.broadcaster.on('KdSplitterEvent_ToggleMenu');
    }
    toggleSubPane(data) {
        this.broadcaster.broadcast('KdSplitterEvent_ToggleSubPane', data);
    }
    onToggleSubPane() {
        return this.broadcaster.on('KdSplitterEvent_ToggleSubPane');
    }
    toggleAnimationSubPaneEnd(data) {
        this.broadcaster.broadcast('KdSplitterEvent_AnimationSubPaneEnd', data);
    }
    onToggleAnimationSubPaneEnd() {
        return this.broadcaster.on('KdSplitterEvent_AnimationSubPaneEnd');
    }
}
KdSplitterEvent.ɵprov = i0.ɵɵdefineInjectable({ factory: function KdSplitterEvent_Factory() { return new KdSplitterEvent(i0.ɵɵinject(i1.KdBroadcaster)); }, token: KdSplitterEvent, providedIn: "root" });
KdSplitterEvent.decorators = [
    { type: Injectable, args: [{
                providedIn: 'root'
            },] }
];
KdSplitterEvent.ctorParameters = () => [
    { type: KdBroadcaster }
];
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoia2Qtc3BsaXR0ZXItZXZlbnQuanMiLCJzb3VyY2VSb290IjoiQzoveGFtcHAvaHRkb2NzL1N0eWxlZ3VpZGUvaW9zdGctb3BlbmVtaXMtc3R5bGVndWlkZS9wcm9qZWN0cy9vcGVuZW1pcy1zdHlsZWd1aWRlLWxpYi9zcmMvIiwic291cmNlcyI6WyJrZC1jb21wb25lbnRzL2tkLWFuZ3VsYXItc3BsaXR0ZXIvc3JjL2tkLXNwbGl0dGVyLWV2ZW50LnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBLE9BQU8sRUFBRSxVQUFVLEVBQUUsTUFBTSxlQUFlLENBQUM7QUFFM0MsT0FBTyxFQUFFLGFBQWEsRUFBRSxNQUFNLHVCQUF1QixDQUFDOzs7QUFLdEQsTUFBTSxPQUFPLGVBQWU7SUFDeEIsWUFBb0IsV0FBMEI7UUFBMUIsZ0JBQVcsR0FBWCxXQUFXLENBQWU7SUFBSSxDQUFDO0lBRW5ELElBQUksQ0FBQyxJQUFhO1FBQ2QsSUFBSSxDQUFDLFdBQVcsQ0FBQyxTQUFTLENBQUMsMEJBQTBCLEVBQUUsSUFBSSxDQUFDLENBQUM7SUFDakUsQ0FBQztJQUVELEVBQUU7UUFDRSxPQUFPLElBQUksQ0FBQyxXQUFXLENBQUMsRUFBRSxDQUFTLDBCQUEwQixDQUFDLENBQUM7SUFDbkUsQ0FBQztJQUVELElBQUksQ0FBQyxJQUFZO1FBQ2IsSUFBSSxDQUFDLFdBQVcsQ0FBQyxTQUFTLENBQUMsc0JBQXNCLEVBQUUsSUFBSSxDQUFDLENBQUM7SUFDN0QsQ0FBQztJQUVELE1BQU07UUFDRixPQUFPLElBQUksQ0FBQyxXQUFXLENBQUMsRUFBRSxDQUFTLHNCQUFzQixDQUFDLENBQUM7SUFDL0QsQ0FBQztJQUVELFVBQVUsQ0FBQyxJQUFVO1FBQ2pCLElBQUksQ0FBQyxXQUFXLENBQUMsU0FBUyxDQUFDLDRCQUE0QixFQUFFLElBQUksQ0FBQyxDQUFDO0lBQ25FLENBQUM7SUFFRCxZQUFZO1FBQ1IsT0FBTyxJQUFJLENBQUMsV0FBVyxDQUFDLEVBQUUsQ0FBTSw0QkFBNEIsQ0FBQyxDQUFDO0lBQ2xFLENBQUM7SUFFRCxhQUFhLENBQUMsSUFBYTtRQUN2QixJQUFJLENBQUMsV0FBVyxDQUFDLFNBQVMsQ0FBQywrQkFBK0IsRUFBRSxJQUFJLENBQUMsQ0FBQztJQUN0RSxDQUFDO0lBRUQsZUFBZTtRQUNYLE9BQU8sSUFBSSxDQUFDLFdBQVcsQ0FBQyxFQUFFLENBQVUsK0JBQStCLENBQUMsQ0FBQztJQUN6RSxDQUFDO0lBRUQseUJBQXlCLENBQUMsSUFBYztRQUNwQyxJQUFJLENBQUMsV0FBVyxDQUFDLFNBQVMsQ0FBQyxxQ0FBcUMsRUFBRSxJQUFJLENBQUMsQ0FBQztJQUM1RSxDQUFDO0lBRUQsMkJBQTJCO1FBQ3ZCLE9BQU8sSUFBSSxDQUFDLFdBQVcsQ0FBQyxFQUFFLENBQVUscUNBQXFDLENBQUMsQ0FBQztJQUMvRSxDQUFDOzs7O1lBNUNKLFVBQVUsU0FBQztnQkFDUixVQUFVLEVBQUUsTUFBTTthQUNyQjs7O1lBSlEsYUFBYSIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IEluamVjdGFibGUgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcclxuaW1wb3J0IHsgT2JzZXJ2YWJsZSB9IGZyb20gJ3J4anMnO1xyXG5pbXBvcnQgeyBLZEJyb2FkY2FzdGVyIH0gZnJvbSAnLi4vLi4va2QtY29tbW9uL2luZGV4JztcclxuXHJcbkBJbmplY3RhYmxlKHtcclxuICAgIHByb3ZpZGVkSW46ICdyb290J1xyXG59KVxyXG5leHBvcnQgY2xhc3MgS2RTcGxpdHRlckV2ZW50IHtcclxuICAgIGNvbnN0cnVjdG9yKHByaXZhdGUgYnJvYWRjYXN0ZXI6IEtkQnJvYWRjYXN0ZXIpIHsgfVxyXG5cclxuICAgIGZpcmUoZGF0YT86IHN0cmluZyk6IHZvaWQge1xyXG4gICAgICAgIHRoaXMuYnJvYWRjYXN0ZXIuYnJvYWRjYXN0KCdLZFNwbGl0dGVyRXZlbnRfU2lkZU1lbnUnLCBkYXRhKTtcclxuICAgIH1cclxuXHJcbiAgICBvbigpOiBPYnNlcnZhYmxlPHN0cmluZz4ge1xyXG4gICAgICAgIHJldHVybiB0aGlzLmJyb2FkY2FzdGVyLm9uPHN0cmluZz4oJ0tkU3BsaXR0ZXJFdmVudF9TaWRlTWVudScpO1xyXG4gICAgfVxyXG5cclxuICAgIGRyYWcoZGF0YTogc3RyaW5nKTogdm9pZCB7XHJcbiAgICAgICAgdGhpcy5icm9hZGNhc3Rlci5icm9hZGNhc3QoJ0tkU3BsaXR0ZXJFdmVudF9EcmFnJywgZGF0YSk7XHJcbiAgICB9XHJcblxyXG4gICAgb25EcmFnKCk6IE9ic2VydmFibGU8c3RyaW5nPiB7XHJcbiAgICAgICAgcmV0dXJuIHRoaXMuYnJvYWRjYXN0ZXIub248c3RyaW5nPignS2RTcGxpdHRlckV2ZW50X0RyYWcnKTtcclxuICAgIH1cclxuXHJcbiAgICB0b2dnbGVNZW51KGRhdGE/OiBhbnkpOiB2b2lkIHtcclxuICAgICAgICB0aGlzLmJyb2FkY2FzdGVyLmJyb2FkY2FzdCgnS2RTcGxpdHRlckV2ZW50X1RvZ2dsZU1lbnUnLCBkYXRhKTtcclxuICAgIH1cclxuXHJcbiAgICBvblRvZ2dsZU1lbnUoKTogT2JzZXJ2YWJsZTxhbnk+IHtcclxuICAgICAgICByZXR1cm4gdGhpcy5icm9hZGNhc3Rlci5vbjxhbnk+KCdLZFNwbGl0dGVyRXZlbnRfVG9nZ2xlTWVudScpO1xyXG4gICAgfVxyXG5cclxuICAgIHRvZ2dsZVN1YlBhbmUoZGF0YTogYm9vbGVhbik6IHZvaWQge1xyXG4gICAgICAgIHRoaXMuYnJvYWRjYXN0ZXIuYnJvYWRjYXN0KCdLZFNwbGl0dGVyRXZlbnRfVG9nZ2xlU3ViUGFuZScsIGRhdGEpO1xyXG4gICAgfVxyXG5cclxuICAgIG9uVG9nZ2xlU3ViUGFuZSgpOiBPYnNlcnZhYmxlPGJvb2xlYW4+IHtcclxuICAgICAgICByZXR1cm4gdGhpcy5icm9hZGNhc3Rlci5vbjxib29sZWFuPignS2RTcGxpdHRlckV2ZW50X1RvZ2dsZVN1YlBhbmUnKTtcclxuICAgIH1cclxuXHJcbiAgICB0b2dnbGVBbmltYXRpb25TdWJQYW5lRW5kKGRhdGE/OiBib29sZWFuKTogdm9pZCB7XHJcbiAgICAgICAgdGhpcy5icm9hZGNhc3Rlci5icm9hZGNhc3QoJ0tkU3BsaXR0ZXJFdmVudF9BbmltYXRpb25TdWJQYW5lRW5kJywgZGF0YSk7XHJcbiAgICB9XHJcblxyXG4gICAgb25Ub2dnbGVBbmltYXRpb25TdWJQYW5lRW5kKCk6IE9ic2VydmFibGU8Ym9vbGVhbj4ge1xyXG4gICAgICAgIHJldHVybiB0aGlzLmJyb2FkY2FzdGVyLm9uPGJvb2xlYW4+KCdLZFNwbGl0dGVyRXZlbnRfQW5pbWF0aW9uU3ViUGFuZUVuZCcpO1xyXG4gICAgfVxyXG59XHJcbiJdfQ==