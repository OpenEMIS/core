import { Component, Input, HostListener, ViewEncapsulation, ViewContainerRef, Renderer2 } from '@angular/core';
import { Router, NavigationEnd } from '@angular/router';
import { timer } from 'rxjs';
import { KdConvertionSvc, KdDomElemSvc } from '../../kd-common/index';
import { KdSplitterSvc } from './kd-splitter-svc';
import { KdSplitterEvent } from './kd-splitter-event';
export class KdSplitter {
    constructor(_vcr, _renderer, _splitterSvc, _convertionSvc, _domElemSvc, _splitterEvent, _router) {
        this._vcr = _vcr;
        this._renderer = _renderer;
        this._splitterSvc = _splitterSvc;
        this._convertionSvc = _convertionSvc;
        this._domElemSvc = _domElemSvc;
        this._splitterEvent = _splitterEvent;
        this._router = _router;
        this._isDrag = false;
        this._disableDrag = false;
        this._panesDefaultConfig = {};
        this._panes = [];
        // private _localStorage: number;
        this._isMainPaneCollapse = false;
        this._splitterLevel = '';
        this._enableFloatBtn = false;
        this._enableSubPaneCollapse = false;
        this._prevIsMobile = false;
        this._isSubPaneOpen = false;
        this._sessionPrefix = '';
        this._sessionName = 'splitter';
        this._isFirstSwitchViewPort = true;
        this._prevWidthState = 0;
        this._isMenuOpen = false;
        this.el = this._vcr.element;
    }
    onMousemove(event) {
        // this.mousemove.emit(event);
        this._onDrag(event);
    }
    onMouseup(event) {
        // this.mouseup.emit(event);
        this._isDrag = false;
    }
    onResize(event) {
        // console.log('resize');
        this._onResize(event);
    }
    ngOnInit() {
        this._prevIsMobile = this._domElemSvc.isMobile();
        this._enableFloatBtn = this._convertionSvc.strToBool(this.floatbtn);
        this._enableSubPaneCollapse = this._convertionSvc.strToBool(this.collapsible);
        // this._panesDefaultConfig = this._splitterSvc.initPanesDefaultConfig(this._panes);
        // console.log(this._panesDefaultConfig);
    }
    ngAfterViewInit() {
        this._panesDefaultConfig = this._splitterSvc.initPanesDefaultConfig(this._panes);
        this._disableDrag = this._splitterSvc.toDisableDrag();
        if (this._splitterSvc.isSubPane(this.el.nativeElement)) {
            // console.log('this is the sub pane');
            this._splitterLevel = 'sub';
            let leftPane = this._panes[0].element.nativeElement;
            this._prevWidthState = leftPane.getBoundingClientRect().width;
        }
        else {
            // console.log('this is the main pane');
            this._splitterLevel = 'main';
            this._registerMenuBroadcast();
            this._setTint(false);
        }
        // this._splitterEvent.onDrag()
        // .subscribe(_type => {
        //     console.log(_type);
        // });
        // isSubSplitter/
        this._sessionPrefix = this._convertionSvc.camelCase(this._domElemSvc.getDocumentTheme(), '-') + '_splitter_' + this._splitterLevel;
        this._setDefaultPaneSize();
        this._setupSplitterHandler();
        this._toggleCollapseSubPane();
        this._isFirstSwitchViewPort = false;
        this._router.events.subscribe(event => {
            if (event instanceof NavigationEnd) {
                // console.log(event.url);
                for (let key in this._panes) {
                    if (this._panes.hasOwnProperty(key)) {
                        let pane = this._panes[key];
                        pane.element.nativeElement.scrollTop = 0;
                    }
                }
            }
        });
    }
    addGroup(pane) {
        this._panes.push(pane);
        return this._panes.length;
    }
    paneOnChange(_type) {
        this._panesDefaultConfig = this._splitterSvc.initPanesDefaultConfig(this._panes);
        if (_type === 'size') {
            // changing element width before animation of panes start
            this._setDefaultPaneSize(false);
            let boundingRect = this.el.nativeElement.getBoundingClientRect();
            if (boundingRect) {
                // affects animation of left pane. 
                this._prevWidthState = this._panesDefaultConfig.Pane1.size * boundingRect.width;
            }
        }
    }
    _registerMenuBroadcast() {
        this._splitterEvent.on()
            .subscribe(respone => {
            // console.log(respone);
            let direction = this._domElemSvc.getDocumentDirection(true);
            let oppDirection = direction === 'left' ? 'right' : 'left';
            let className = 'push-content-' + oppDirection;
            let isMobile = this._domElemSvc.isMobile();
            let count = 0;
            for (let key in this._panes) {
                if (this._panes.hasOwnProperty(key)) {
                    let pane = this._panes[key];
                    this._domElemSvc.setElementClass(pane.element.nativeElement, 'animation', isMobile);
                    if (count !== 0) {
                        if (!isMobile) {
                            this._domElemSvc.removeClass(pane.element.nativeElement, className);
                        }
                        else {
                            this._isMenuOpen = !this._isMenuOpen;
                            if (this._splitterLevel === 'main') {
                                // console.log('append class ' + className + ' into main pane');
                                this._domElemSvc.setElementClass(pane.element.nativeElement, className, this._isMenuOpen);
                                this._setTint(this._isMenuOpen);
                            }
                        }
                    }
                    else {
                        if (isMobile && this._splitterLevel === 'sub') {
                            // console.log('sub main');
                        }
                    }
                    count++;
                }
            }
        });
    }
    _setupSplitterHandler() {
        for (let i = 1; i < this._panes.length; i++) {
            let count = i + 1;
            let className = 'sh-' + count;
            let newEl = this._domElemSvc.createElement(this._panes[i].element.nativeElement, 'splitter-handler ' + className);
            this._domElemSvc.setElementClass(newEl, 'disabled', this._disableDrag);
            // setup OnMouseDownEvent
            // setup OnMouseDownEvent
            this._renderer.listen(newEl, 'mousedown', (event) => {
                this._selectedElem = event.target.parentElement;
                this._selectedPrevSiblingElem = this._selectedElem.previousElementSibling;
                this._isDrag = true;
            });
            if (this._splitterLevel === 'main') {
                this._setupCollapseButton(this._panes[i], count);
            }
        }
    }
    _setupCollapseButton(_pane, _count) {
        let className = 'mb-' + _count;
        let newBtn = this._domElemSvc.createElement(_pane.element.nativeElement, 'menu-btn ' + className);
        // Setup icon
        this._domElemSvc.createElement(newBtn, 'fa', 'i');
        this._setCollapseIcon(this._isMainPaneCollapse);
        // setup OnMouseDownEvent
        // setup OnMouseDownEvent
        this._renderer.listen(newBtn, 'click', (event) => {
            // console.log(event);
            this._isDrag = false;
            this._toggleCollapseMenu(_pane);
        });
    }
    _setDefaultPaneSize(_useLocalStorage = true) {
        let count = 0;
        let offsetX = 0;
        let direction = this._domElemSvc.getDocumentDirection(true);
        let oppDirection = direction === 'left' ? 'right' : 'left';
        let mobileConfig = this._splitterSvc.getMobileConfig(this._splitterLevel, direction);
        let isMobile = this._domElemSvc.isMobile();
        let localStorage = JSON.parse(window.sessionStorage.getItem(this._sessionPrefix + this._sessionName));
        // console.log(localStorage);
        // console.log('sessionStorge = '+window.sessionStorage.getItem(this._sessionPrefix+this._sessionName));
        for (let key in this._panesDefaultConfig) {
            if (this._panesDefaultConfig.hasOwnProperty(key)) {
                let pane = this._panes[count];
                let paneConfig = {
                    width: (this._panesDefaultConfig[key].size > 100) ? 100 : this._panesDefaultConfig[key].size,
                };
                paneConfig[direction] = offsetX;
                if (isMobile) {
                    paneConfig = Object.assign({}, paneConfig, mobileConfig[key]);
                    this._isMenuOpen = false;
                    if (count === 0) {
                        // console.log('show button');
                        this._setupFloatMenuBtn(pane, count);
                    }
                    // console.log("this is mobile view");
                }
                else {
                    if (localStorage !== null && _useLocalStorage) {
                        let tempName = 'Pane' + (count + 1);
                        paneConfig = Object.assign({}, paneConfig, localStorage[tempName]);
                    }
                    // console.log(paneConfig);
                    this._removeFloatMenuBtn();
                    this._domElemSvc.removeClass(pane.element.nativeElement, 'push-content-' + oppDirection);
                    if (this._splitterLevel === 'sub' && count === 1 && this._isFirstSwitchViewPort) {
                        let isSubPaneShow = (this._panesDefaultConfig[key].show !== undefined) ? this._panesDefaultConfig[key].show : true;
                        this._processToggleCollapseSubPane(isSubPaneShow, false);
                    }
                }
                for (let cKey in paneConfig) {
                    if (paneConfig.hasOwnProperty(cKey)) {
                        this._domElemSvc.setElementStyle(pane.element.nativeElement, cKey, paneConfig[cKey] + '%');
                    }
                }
                count++;
                offsetX += paneConfig.width;
            }
        }
    }
    _updateSplitPaneSize(_posX, _boundSize) {
        if (this._domElemSvc.isMobile())
            return;
        if (!this._isDrag)
            return;
        let direction = this._domElemSvc.getDocumentDirection(true);
        let dimention = (this.orientation === 'vertical') ? 'height' : 'width';
        let selectedElemBounds = this._selectedElem.getBoundingClientRect();
        let selectedPrevElemBounds = this._selectedPrevSiblingElem.getBoundingClientRect();
        selectedElemBounds = (this.orientation === 'vertical') ? selectedElemBounds.height : selectedElemBounds.width;
        selectedPrevElemBounds = (this.orientation === 'vertical') ? selectedPrevElemBounds.height : selectedPrevElemBounds.width;
        let total2ElemSize = Math.round(this._convertionSvc.convertPxToPercent(selectedPrevElemBounds + selectedElemBounds, _boundSize));
        let moveX = this._splitterSvc.validatePercentValue(_posX);
        total2ElemSize = this._splitterSvc.validatePercentValue(total2ElemSize);
        let selectedPrevPaneKey = this._convertionSvc.camelCase(this._selectedPrevSiblingElem.classList[1], '-');
        moveX = this._splitterSvc.validatePaneSize(this._panesDefaultConfig, selectedPrevPaneKey, moveX);
        let curPane = total2ElemSize - moveX;
        let splitterFinalConfig = {
            Pane1: {},
            Pane2: {}
        };
        splitterFinalConfig['Pane1'][dimention] = moveX;
        splitterFinalConfig['Pane2'][direction] = moveX;
        splitterFinalConfig['Pane2'][dimention] = curPane;
        window.sessionStorage.setItem(this._sessionPrefix + this._sessionName, JSON.stringify(splitterFinalConfig));
        this._domElemSvc.setElementStyle(this._selectedPrevSiblingElem, dimention, moveX + '%');
        this._domElemSvc.setElementStyle(this._selectedElem, direction, moveX + '%');
        this._domElemSvc.setElementStyle(this._selectedElem, dimention, curPane + '%');
    }
    _toggleCollapseMenu(_pane) {
        let direction = this._domElemSvc.getDocumentDirection(true);
        this._isMainPaneCollapse = !this._isMainPaneCollapse;
        this._domElemSvc.addClass(_pane.element.nativeElement, 'animation');
        this._domElemSvc.setElementClass(_pane.element.nativeElement, 'push-content-' + direction, this._isMainPaneCollapse);
        this._setCollapseIcon(this._isMainPaneCollapse);
        this._splitterEvent.toggleMenu();
    }
    _removeFloatMenuBtn() {
        this._domElemSvc.removeElementByClass('.fm-btn', this.el.nativeElement);
    }
    _setupFloatMenuBtn(_pane, _count) {
        let isMobile = this._domElemSvc.isMobile();
        let floatBtn = this.el.nativeElement.querySelector('.fm-btn');
        if (isMobile && this._splitterLevel === 'sub' && floatBtn === null && this._enableFloatBtn) {
            // console.log('sub main');
            // let classNames: string = 'fmb-' + _count;
            let className = 'fm-btn';
            let newBtn = this._domElemSvc.createElement(this.el.nativeElement, 'btn btn-float-bottom-right btn-circle btn-color ' + className);
            // //Setup icon
            HTMLElement = this._domElemSvc.createElement(newBtn, 'fa', 'i');
            this._setFloatIcon(this._isSubPaneOpen);
            // //setup OnMouseDownEvent
            // //setup OnMouseDownEvent
            this._renderer.listen(newBtn, 'click', (event) => {
                this._isSubPaneOpen = !this._isSubPaneOpen;
                this._splitterEvent.toggleSubPane(this._isSubPaneOpen);
            });
        }
    }
    _toggleCollapseSubPane() {
        if (this._splitterLevel === 'sub') {
            this._splitterEvent.onToggleSubPane()
                .subscribe(isSubPaneOpen => {
                this._processToggleCollapseSubPane(isSubPaneOpen);
            });
        }
    }
    _processToggleCollapseSubPane(isSubPaneOpen, _animate) {
        // console.log('in this function?')
        _animate = (typeof _animate === 'undefined') ? true : _animate;
        let rightPane = this._panes[1].element.nativeElement;
        let leftPane = this._panes[0].element.nativeElement;
        let isMobile = this._domElemSvc.isMobile();
        let isSameState = (this._isSubPaneOpen === isSubPaneOpen) ? true : false;
        this._isSubPaneOpen = isSubPaneOpen;
        if (_animate) {
            this._domElemSvc.addClass(rightPane, 'animation');
            this._domElemSvc.addClass(leftPane, 'animation');
        }
        if (isMobile || this._enableSubPaneCollapse) {
            // console.log('am i in?');
            let animateDirection = (isMobile) ? 'in' : 'out';
            let direction = this._domElemSvc.getDocumentDirection(true);
            let oppDirection = (direction === 'left') ? 'right' : 'left';
            let addClass = (isMobile) ? isSubPaneOpen : !isSubPaneOpen;
            let widthConfig = [{}];
            if (addClass) {
                this._prevWidthState = leftPane.getBoundingClientRect().width;
                widthConfig = [
                    { 'width': this._prevWidthState + 'px' },
                    { 'width': '100%' }
                ];
            }
            else {
                widthConfig = [
                    { 'width': '100%' },
                    { 'width': this._prevWidthState + 'px' }
                ];
            }
            this._setFloatIcon(isSubPaneOpen);
            this._domElemSvc.setElementClass(leftPane, 'full-width', addClass);
            this._domElemSvc.setElementClass(rightPane, 'push-subcontent-' + oppDirection + '-' + animateDirection, addClass);
            if (_animate && !isSameState) {
                this._domElemSvc.invokeElementMethod(leftPane, 'animate', [widthConfig, 500]);
                timer(500).subscribe(() => {
                    // need fixing in the future. this event is being triggered twice. another time is in kd-example
                    this._splitterEvent.toggleSubPane(isSubPaneOpen);
                    // this._splitterEvent.toggleAnimationSubPaneEnd(isSubPaneOpen);
                });
            }
        }
    }
    _setFloatIcon(_isOpen) {
        let btnIcon = this.el.nativeElement.querySelector('.fm-btn i');
        if (this._splitterLevel === 'sub' && btnIcon !== null) {
            this._domElemSvc.setElementClass(btnIcon, 'kd-lists', !_isOpen);
            this._domElemSvc.setElementClass(btnIcon, 'kd-close-round', _isOpen);
        }
    }
    _setCollapseIcon(_isOpen) {
        let direction = this._domElemSvc.getDocumentDirection(true);
        let oppDirection = (direction === 'left') ? 'right' : 'left';
        let btnIcon = this.el.nativeElement.querySelector('.menu-btn i');
        if (this._splitterLevel === 'main' && btnIcon !== null) {
            this._domElemSvc.setElementClass(btnIcon, 'fa-angle-' + direction, !_isOpen);
            this._domElemSvc.setElementClass(btnIcon, 'fa-angle-' + oppDirection, _isOpen);
        }
    }
    _setTint(_add) {
        let isMobile = this._domElemSvc.isMobile();
        let overlayDiv = this._panes[1].element.nativeElement.querySelector('.content-overlay');
        if (overlayDiv === null) {
            overlayDiv = this._domElemSvc.createElement(this._panes[1].element.nativeElement, 'content-overlay');
            this._renderer.listen(overlayDiv, 'click', (event) => {
                this._splitterEvent.fire();
            });
        }
        if (isMobile) {
            this._domElemSvc.setElementClass(overlayDiv, 'show', _add);
            if (this._splitterLevel === 'main') {
                let contentArea = this._panes[1].element.nativeElement.querySelector('.main-wrapper');
                // console.log(contentArea);
                if (contentArea) {
                    let contentAreaHeight = contentArea.getBoundingClientRect().height;
                    let paneHeight = this._panes[1].element.nativeElement.getBoundingClientRect().height;
                    // console.log(paneHeight);
                    // console.log(contentAreaHeight);
                    if (contentAreaHeight > paneHeight) {
                        this._domElemSvc.setElementStyle(overlayDiv, 'bottom', 'auto');
                        this._domElemSvc.setElementStyle(overlayDiv, 'height', contentAreaHeight + 'px');
                    }
                }
                this._domElemSvc.setElementClass(this._panes[1].element.nativeElement, 'no-overflow', _add);
            }
        }
    }
    _onDrag(event) {
        if (this._disableDrag)
            return;
        if (!this._isDrag)
            return;
        let direction = this._domElemSvc.getDocumentDirection(true);
        // let selectedPaneBounds: any = this._selectedElem.getBoundingClientRect();
        let splitterBounds = this.el.nativeElement.getBoundingClientRect();
        let moveX = Math.abs(event.clientX - splitterBounds[direction]);
        // console.log(moveX);
        // let newWidth: number = selectedPaneBounds.width - moveX;
        // console.log(newWidth);
        let newSize = this._convertionSvc.convertPxToPercent(moveX, splitterBounds.width);
        // console.log('newSize = '+newSize);
        this._domElemSvc.removeClass(this._selectedElem, 'animation');
        this._updateSplitPaneSize(newSize, splitterBounds.width);
        this._splitterEvent.drag(this._splitterLevel);
    }
    _onResize(event) {
        let isMobile = this._domElemSvc.isMobile();
        if (isMobile !== this._prevIsMobile) {
            this._isFirstSwitchViewPort = true;
            this._prevIsMobile = isMobile;
            this._isSubPaneOpen = false;
        }
        this._setDefaultPaneSize();
        this._isFirstSwitchViewPort = false;
    }
}
KdSplitter.decorators = [
    { type: Component, args: [{
                selector: 'kd-splitter',
                template: `<div class='split-container {{orientation}}'><ng-content></ng-content></div>`,
                encapsulation: ViewEncapsulation.None,
                providers: [KdSplitterSvc, KdSplitterEvent, KdConvertionSvc, KdDomElemSvc],
                host: { 'class': 'kdx-split-panes' }
            },] }
];
KdSplitter.ctorParameters = () => [
    { type: ViewContainerRef },
    { type: Renderer2 },
    { type: KdSplitterSvc },
    { type: KdConvertionSvc },
    { type: KdDomElemSvc },
    { type: KdSplitterEvent },
    { type: Router }
];
KdSplitter.propDecorators = {
    orientation: [{ type: Input }],
    floatbtn: [{ type: Input }],
    collapsible: [{ type: Input }],
    onMousemove: [{ type: HostListener, args: ['document:mousemove', ['$event'],] }],
    onMouseup: [{ type: HostListener, args: ['document:mouseup', ['$event'],] }],
    onResize: [{ type: HostListener, args: ['window:resize', ['$event'],] }]
};
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoia2Qtc3BsaXR0ZXIuanMiLCJzb3VyY2VSb290IjoiQzoveGFtcHAvaHRkb2NzL1N0eWxlZ3VpZGUvaW9zdGctb3BlbmVtaXMtc3R5bGVndWlkZS9wcm9qZWN0cy9vcGVuZW1pcy1zdHlsZWd1aWRlLWxpYi9zcmMvIiwic291cmNlcyI6WyJrZC1jb21wb25lbnRzL2tkLWFuZ3VsYXItc3BsaXR0ZXIvc3JjL2tkLXNwbGl0dGVyLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBLE9BQU8sRUFBRSxTQUFTLEVBQUUsS0FBSyxFQUFVLFlBQVksRUFBRSxpQkFBaUIsRUFBRSxnQkFBZ0IsRUFBNkIsU0FBUyxFQUFFLE1BQU0sZUFBZSxDQUFDO0FBQ2xKLE9BQU8sRUFBRSxNQUFNLEVBQUUsYUFBYSxFQUFFLE1BQU0saUJBQWlCLENBQUM7QUFDeEQsT0FBTyxFQUFFLEtBQUssRUFBRSxNQUFNLE1BQU0sQ0FBQztBQUU3QixPQUFPLEVBQUUsZUFBZSxFQUFFLFlBQVksRUFBRSxNQUFNLHVCQUF1QixDQUFDO0FBQ3RFLE9BQU8sRUFBRSxhQUFhLEVBQUUsTUFBTSxtQkFBbUIsQ0FBQztBQUNsRCxPQUFPLEVBQUUsZUFBZSxFQUFFLE1BQU0scUJBQXFCLENBQUM7QUFVdEQsTUFBTSxPQUFPLFVBQVU7SUEwQm5CLFlBQ1ksSUFBc0IsRUFDdEIsU0FBb0IsRUFDcEIsWUFBMkIsRUFDM0IsY0FBK0IsRUFDL0IsV0FBeUIsRUFDekIsY0FBK0IsRUFDL0IsT0FBZTtRQU5mLFNBQUksR0FBSixJQUFJLENBQWtCO1FBQ3RCLGNBQVMsR0FBVCxTQUFTLENBQVc7UUFDcEIsaUJBQVksR0FBWixZQUFZLENBQWU7UUFDM0IsbUJBQWMsR0FBZCxjQUFjLENBQWlCO1FBQy9CLGdCQUFXLEdBQVgsV0FBVyxDQUFjO1FBQ3pCLG1CQUFjLEdBQWQsY0FBYyxDQUFpQjtRQUMvQixZQUFPLEdBQVAsT0FBTyxDQUFRO1FBOUJuQixZQUFPLEdBQVksS0FBSyxDQUFDO1FBQ3pCLGlCQUFZLEdBQVksS0FBSyxDQUFDO1FBQzlCLHdCQUFtQixHQUFRLEVBQUUsQ0FBQztRQUM5QixXQUFNLEdBQWtCLEVBQUUsQ0FBQztRQUduQyxpQ0FBaUM7UUFDekIsd0JBQW1CLEdBQVksS0FBSyxDQUFDO1FBQ3JDLG1CQUFjLEdBQVcsRUFBRSxDQUFDO1FBQzVCLG9CQUFlLEdBQVksS0FBSyxDQUFDO1FBQ2pDLDJCQUFzQixHQUFZLEtBQUssQ0FBQztRQUN4QyxrQkFBYSxHQUFZLEtBQUssQ0FBQztRQUMvQixtQkFBYyxHQUFZLEtBQUssQ0FBQztRQUNoQyxtQkFBYyxHQUFXLEVBQUUsQ0FBQztRQUM1QixpQkFBWSxHQUFXLFVBQVUsQ0FBQztRQUNsQywyQkFBc0IsR0FBWSxJQUFJLENBQUM7UUFDdkMsb0JBQWUsR0FBVyxDQUFDLENBQUM7UUFDNUIsZ0JBQVcsR0FBWSxLQUFLLENBQUM7UUFlakMsSUFBSSxDQUFDLEVBQUUsR0FBRyxJQUFJLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQztJQUNoQyxDQUFDO0lBR0QsV0FBVyxDQUFDLEtBQVU7UUFDbEIsOEJBQThCO1FBQzlCLElBQUksQ0FBQyxPQUFPLENBQUMsS0FBSyxDQUFDLENBQUM7SUFFeEIsQ0FBQztJQUdELFNBQVMsQ0FBQyxLQUFVO1FBQ2hCLDRCQUE0QjtRQUM1QixJQUFJLENBQUMsT0FBTyxHQUFHLEtBQUssQ0FBQztJQUN6QixDQUFDO0lBR0QsUUFBUSxDQUFDLEtBQVU7UUFDZix5QkFBeUI7UUFDekIsSUFBSSxDQUFDLFNBQVMsQ0FBQyxLQUFLLENBQUMsQ0FBQztJQUMxQixDQUFDO0lBRUQsUUFBUTtRQUNKLElBQUksQ0FBQyxhQUFhLEdBQUcsSUFBSSxDQUFDLFdBQVcsQ0FBQyxRQUFRLEVBQUUsQ0FBQztRQUNqRCxJQUFJLENBQUMsZUFBZSxHQUFHLElBQUksQ0FBQyxjQUFjLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsQ0FBQztRQUNwRSxJQUFJLENBQUMsc0JBQXNCLEdBQUcsSUFBSSxDQUFDLGNBQWMsQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxDQUFDO1FBQzlFLG9GQUFvRjtRQUNwRix5Q0FBeUM7SUFDN0MsQ0FBQztJQUVELGVBQWU7UUFDWCxJQUFJLENBQUMsbUJBQW1CLEdBQUcsSUFBSSxDQUFDLFlBQVksQ0FBQyxzQkFBc0IsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUM7UUFDakYsSUFBSSxDQUFDLFlBQVksR0FBRyxJQUFJLENBQUMsWUFBWSxDQUFDLGFBQWEsRUFBRSxDQUFDO1FBRXRELElBQUksSUFBSSxDQUFDLFlBQVksQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxhQUFhLENBQUMsRUFBRTtZQUNwRCx1Q0FBdUM7WUFDdkMsSUFBSSxDQUFDLGNBQWMsR0FBRyxLQUFLLENBQUM7WUFDNUIsSUFBSSxRQUFRLEdBQWdCLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLGFBQWEsQ0FBQztZQUNqRSxJQUFJLENBQUMsZUFBZSxHQUFHLFFBQVEsQ0FBQyxxQkFBcUIsRUFBRSxDQUFDLEtBQUssQ0FBQztTQUNqRTthQUNJO1lBQ0Qsd0NBQXdDO1lBQ3hDLElBQUksQ0FBQyxjQUFjLEdBQUcsTUFBTSxDQUFDO1lBRTdCLElBQUksQ0FBQyxzQkFBc0IsRUFBRSxDQUFDO1lBQzlCLElBQUksQ0FBQyxRQUFRLENBQUMsS0FBSyxDQUFDLENBQUM7U0FDeEI7UUFDRCwrQkFBK0I7UUFDL0Isd0JBQXdCO1FBQ3hCLDBCQUEwQjtRQUMxQixNQUFNO1FBQ04saUJBQWlCO1FBQ2pCLElBQUksQ0FBQyxjQUFjLEdBQUcsSUFBSSxDQUFDLGNBQWMsQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxnQkFBZ0IsRUFBRSxFQUFFLEdBQUcsQ0FBQyxHQUFHLFlBQVksR0FBRyxJQUFJLENBQUMsY0FBYyxDQUFDO1FBRW5JLElBQUksQ0FBQyxtQkFBbUIsRUFBRSxDQUFDO1FBQzNCLElBQUksQ0FBQyxxQkFBcUIsRUFBRSxDQUFDO1FBQzdCLElBQUksQ0FBQyxzQkFBc0IsRUFBRSxDQUFDO1FBRTlCLElBQUksQ0FBQyxzQkFBc0IsR0FBRyxLQUFLLENBQUM7UUFFcEMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsU0FBUyxDQUFDLEtBQUssQ0FBQyxFQUFFO1lBQ2xDLElBQUksS0FBSyxZQUFZLGFBQWEsRUFBRTtnQkFDaEMsMEJBQTBCO2dCQUMxQixLQUFLLElBQUksR0FBRyxJQUFJLElBQUksQ0FBQyxNQUFNLEVBQUU7b0JBQ3pCLElBQUksSUFBSSxDQUFDLE1BQU0sQ0FBQyxjQUFjLENBQUMsR0FBRyxDQUFDLEVBQUU7d0JBQ2pDLElBQUksSUFBSSxHQUFXLElBQUksQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLENBQUM7d0JBQ3BDLElBQUksQ0FBQyxPQUFPLENBQUMsYUFBYSxDQUFDLFNBQVMsR0FBRyxDQUFDLENBQUM7cUJBQzVDO2lCQUNKO2FBQ0o7UUFDTCxDQUFDLENBQUMsQ0FBQztJQUNQLENBQUM7SUFFRCxRQUFRLENBQUMsSUFBWTtRQUNqQixJQUFJLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQztRQUN2QixPQUFPLElBQUksQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDO0lBQzlCLENBQUM7SUFFRCxZQUFZLENBQUMsS0FBYTtRQUN0QixJQUFJLENBQUMsbUJBQW1CLEdBQUcsSUFBSSxDQUFDLFlBQVksQ0FBQyxzQkFBc0IsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUM7UUFDakYsSUFBSSxLQUFLLEtBQUssTUFBTSxFQUFFO1lBQ2xCLHlEQUF5RDtZQUN6RCxJQUFJLENBQUMsbUJBQW1CLENBQUMsS0FBSyxDQUFDLENBQUM7WUFDaEMsSUFBSSxZQUFZLEdBQUcsSUFBSSxDQUFDLEVBQUUsQ0FBQyxhQUFhLENBQUMscUJBQXFCLEVBQUUsQ0FBQztZQUNqRSxJQUFJLFlBQVksRUFBRTtnQkFDZCxtQ0FBbUM7Z0JBQ25DLElBQUksQ0FBQyxlQUFlLEdBQUcsSUFBSSxDQUFDLG1CQUFtQixDQUFDLEtBQUssQ0FBQyxJQUFJLEdBQUcsWUFBWSxDQUFDLEtBQUssQ0FBQzthQUNuRjtTQUNKO0lBQ0wsQ0FBQztJQUVPLHNCQUFzQjtRQUMxQixJQUFJLENBQUMsY0FBYyxDQUFDLEVBQUUsRUFBRTthQUNuQixTQUFTLENBQUMsT0FBTyxDQUFDLEVBQUU7WUFDakIsd0JBQXdCO1lBQ3hCLElBQUksU0FBUyxHQUFXLElBQUksQ0FBQyxXQUFXLENBQUMsb0JBQW9CLENBQUMsSUFBSSxDQUFDLENBQUM7WUFDcEUsSUFBSSxZQUFZLEdBQVcsU0FBUyxLQUFLLE1BQU0sQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUM7WUFDbkUsSUFBSSxTQUFTLEdBQVcsZUFBZSxHQUFHLFlBQVksQ0FBQztZQUN2RCxJQUFJLFFBQVEsR0FBWSxJQUFJLENBQUMsV0FBVyxDQUFDLFFBQVEsRUFBRSxDQUFDO1lBQ3BELElBQUksS0FBSyxHQUFXLENBQUMsQ0FBQztZQUV0QixLQUFLLElBQUksR0FBRyxJQUFJLElBQUksQ0FBQyxNQUFNLEVBQUU7Z0JBQ3pCLElBQUksSUFBSSxDQUFDLE1BQU0sQ0FBQyxjQUFjLENBQUMsR0FBRyxDQUFDLEVBQUU7b0JBQ2pDLElBQUksSUFBSSxHQUFXLElBQUksQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLENBQUM7b0JBQ3BDLElBQUksQ0FBQyxXQUFXLENBQUMsZUFBZSxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsYUFBYSxFQUFFLFdBQVcsRUFBRSxRQUFRLENBQUMsQ0FBQztvQkFFcEYsSUFBSSxLQUFLLEtBQUssQ0FBQyxFQUFFO3dCQUNiLElBQUksQ0FBQyxRQUFRLEVBQUU7NEJBQ1gsSUFBSSxDQUFDLFdBQVcsQ0FBQyxXQUFXLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxhQUFhLEVBQUUsU0FBUyxDQUFDLENBQUM7eUJBQ3ZFOzZCQUNJOzRCQUNELElBQUksQ0FBQyxXQUFXLEdBQUcsQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFDOzRCQUNyQyxJQUFJLElBQUksQ0FBQyxjQUFjLEtBQUssTUFBTSxFQUFFO2dDQUNoQyxnRUFBZ0U7Z0NBQ2hFLElBQUksQ0FBQyxXQUFXLENBQUMsZUFBZSxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsYUFBYSxFQUFFLFNBQVMsRUFBRSxJQUFJLENBQUMsV0FBVyxDQUFDLENBQUM7Z0NBQzFGLElBQUksQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxDQUFDOzZCQUNuQzt5QkFDSjtxQkFDSjt5QkFDSTt3QkFDRCxJQUFJLFFBQVEsSUFBSSxJQUFJLENBQUMsY0FBYyxLQUFLLEtBQUssRUFBRTs0QkFDM0MsMkJBQTJCO3lCQUM5QjtxQkFDSjtvQkFDRCxLQUFLLEVBQUUsQ0FBQztpQkFDWDthQUNKO1FBQ0wsQ0FBQyxDQUFDLENBQUM7SUFDWCxDQUFDO0lBRU8scUJBQXFCO1FBQ3pCLEtBQUssSUFBSSxDQUFDLEdBQVcsQ0FBQyxFQUFFLENBQUMsR0FBRyxJQUFJLENBQUMsTUFBTSxDQUFDLE1BQU0sRUFBRSxDQUFDLEVBQUUsRUFBRTtZQUNqRCxJQUFJLEtBQUssR0FBVyxDQUFDLEdBQUcsQ0FBQyxDQUFDO1lBQzFCLElBQUksU0FBUyxHQUFXLEtBQUssR0FBRyxLQUFLLENBQUM7WUFFdEMsSUFBSSxLQUFLLEdBQWdCLElBQUksQ0FBQyxXQUFXLENBQUMsYUFBYSxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLGFBQWEsRUFBRSxtQkFBbUIsR0FBRyxTQUFTLENBQUMsQ0FBQztZQUMvSCxJQUFJLENBQUMsV0FBVyxDQUFDLGVBQWUsQ0FBQyxLQUFLLEVBQUUsVUFBVSxFQUFFLElBQUksQ0FBQyxZQUFZLENBQUMsQ0FBQztZQUV2RSx5QkFBeUI7WUFDekIseUJBQXlCO1lBQ3JDLElBQUksQ0FBQyxTQUFTLENBQUMsTUFBTSxDQUFDLEtBQUssRUFBRSxXQUFXLEVBQUUsQ0FBQyxLQUFVLEVBQVEsRUFBRTtnQkFDM0QsSUFBSSxDQUFDLGFBQWEsR0FBRyxLQUFLLENBQUMsTUFBTSxDQUFDLGFBQWEsQ0FBQztnQkFDaEQsSUFBSSxDQUFDLHdCQUF3QixHQUFHLElBQUksQ0FBQyxhQUFhLENBQUMsc0JBQXNCLENBQUM7Z0JBQzFFLElBQUksQ0FBQyxPQUFPLEdBQUcsSUFBSSxDQUFDO1lBQ3hCLENBQUMsQ0FBQyxDQUFDO1lBRVMsSUFBSSxJQUFJLENBQUMsY0FBYyxLQUFLLE1BQU0sRUFBRTtnQkFDaEMsSUFBSSxDQUFDLG9CQUFvQixDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLEVBQUUsS0FBSyxDQUFDLENBQUM7YUFDcEQ7U0FDSjtJQUNMLENBQUM7SUFFTyxvQkFBb0IsQ0FBQyxLQUFhLEVBQUUsTUFBYztRQUN0RCxJQUFJLFNBQVMsR0FBVyxLQUFLLEdBQUcsTUFBTSxDQUFDO1FBQ3ZDLElBQUksTUFBTSxHQUFnQixJQUFJLENBQUMsV0FBVyxDQUFDLGFBQWEsQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLGFBQWEsRUFBRSxXQUFXLEdBQUcsU0FBUyxDQUFDLENBQUM7UUFFL0csYUFBYTtRQUNiLElBQUksQ0FBQyxXQUFXLENBQUMsYUFBYSxDQUFDLE1BQU0sRUFBRSxJQUFJLEVBQUUsR0FBRyxDQUFDLENBQUM7UUFDbEQsSUFBSSxDQUFDLGdCQUFnQixDQUFDLElBQUksQ0FBQyxtQkFBbUIsQ0FBQyxDQUFDO1FBQ2hELHlCQUF5QjtRQUN6Qix5QkFBeUI7UUFDakMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxNQUFNLENBQUMsTUFBTSxFQUFFLE9BQU8sRUFBRSxDQUFDLEtBQVUsRUFBUSxFQUFFO1lBQ3hELHNCQUFzQjtZQUN0QixJQUFJLENBQUMsT0FBTyxHQUFHLEtBQUssQ0FBQztZQUNyQixJQUFJLENBQUMsbUJBQW1CLENBQUMsS0FBSyxDQUFDLENBQUM7UUFDcEMsQ0FBQyxDQUFDLENBQUM7SUFDQyxDQUFDO0lBRU8sbUJBQW1CLENBQUMsbUJBQTRCLElBQUk7UUFDeEQsSUFBSSxLQUFLLEdBQVcsQ0FBQyxDQUFDO1FBQ3RCLElBQUksT0FBTyxHQUFXLENBQUMsQ0FBQztRQUN4QixJQUFJLFNBQVMsR0FBVyxJQUFJLENBQUMsV0FBVyxDQUFDLG9CQUFvQixDQUFDLElBQUksQ0FBQyxDQUFDO1FBQ3BFLElBQUksWUFBWSxHQUFXLFNBQVMsS0FBSyxNQUFNLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDO1FBQ25FLElBQUksWUFBWSxHQUFRLElBQUksQ0FBQyxZQUFZLENBQUMsZUFBZSxDQUFDLElBQUksQ0FBQyxjQUFjLEVBQUUsU0FBUyxDQUFDLENBQUM7UUFDMUYsSUFBSSxRQUFRLEdBQVksSUFBSSxDQUFDLFdBQVcsQ0FBQyxRQUFRLEVBQUUsQ0FBQztRQUNwRCxJQUFJLFlBQVksR0FBUSxJQUFJLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxjQUFjLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxjQUFjLEdBQUcsSUFBSSxDQUFDLFlBQVksQ0FBQyxDQUFDLENBQUM7UUFDM0csNkJBQTZCO1FBQzdCLHdHQUF3RztRQUN4RyxLQUFLLElBQUksR0FBRyxJQUFJLElBQUksQ0FBQyxtQkFBbUIsRUFBRTtZQUN0QyxJQUFJLElBQUksQ0FBQyxtQkFBbUIsQ0FBQyxjQUFjLENBQUMsR0FBRyxDQUFDLEVBQUU7Z0JBQzlDLElBQUksSUFBSSxHQUFXLElBQUksQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLENBQUM7Z0JBQ3RDLElBQUksVUFBVSxHQUFRO29CQUNsQixLQUFLLEVBQUUsQ0FBQyxJQUFJLENBQUMsbUJBQW1CLENBQUMsR0FBRyxDQUFDLENBQUMsSUFBSSxHQUFHLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxtQkFBbUIsQ0FBQyxHQUFHLENBQUMsQ0FBQyxJQUFJO2lCQUMvRixDQUFDO2dCQUNGLFVBQVUsQ0FBQyxTQUFTLENBQUMsR0FBRyxPQUFPLENBQUM7Z0JBRWhDLElBQUksUUFBUSxFQUFFO29CQUNWLFVBQVUsR0FBRyxNQUFNLENBQUMsTUFBTSxDQUFDLEVBQUUsRUFBRSxVQUFVLEVBQUUsWUFBWSxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUM7b0JBQzlELElBQUksQ0FBQyxXQUFXLEdBQUcsS0FBSyxDQUFDO29CQUN6QixJQUFJLEtBQUssS0FBSyxDQUFDLEVBQUU7d0JBQ2IsOEJBQThCO3dCQUM5QixJQUFJLENBQUMsa0JBQWtCLENBQUMsSUFBSSxFQUFFLEtBQUssQ0FBQyxDQUFDO3FCQUN4QztvQkFDRCxzQ0FBc0M7aUJBQ3pDO3FCQUNJO29CQUNELElBQUksWUFBWSxLQUFLLElBQUksSUFBSSxnQkFBZ0IsRUFBRTt3QkFDM0MsSUFBSSxRQUFRLEdBQVcsTUFBTSxHQUFHLENBQUMsS0FBSyxHQUFHLENBQUMsQ0FBQyxDQUFDO3dCQUM1QyxVQUFVLEdBQUcsTUFBTSxDQUFDLE1BQU0sQ0FBQyxFQUFFLEVBQUUsVUFBVSxFQUFFLFlBQVksQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDO3FCQUN0RTtvQkFDRCwyQkFBMkI7b0JBQzNCLElBQUksQ0FBQyxtQkFBbUIsRUFBRSxDQUFDO29CQUUzQixJQUFJLENBQUMsV0FBVyxDQUFDLFdBQVcsQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLGFBQWEsRUFBRSxlQUFlLEdBQUcsWUFBWSxDQUFDLENBQUM7b0JBRXpGLElBQUksSUFBSSxDQUFDLGNBQWMsS0FBSyxLQUFLLElBQUksS0FBSyxLQUFLLENBQUMsSUFBSSxJQUFJLENBQUMsc0JBQXNCLEVBQUU7d0JBQzdFLElBQUksYUFBYSxHQUFZLENBQUMsSUFBSSxDQUFDLG1CQUFtQixDQUFDLEdBQUcsQ0FBQyxDQUFDLElBQUksS0FBSyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLG1CQUFtQixDQUFDLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDO3dCQUM1SCxJQUFJLENBQUMsNkJBQTZCLENBQUMsYUFBYSxFQUFFLEtBQUssQ0FBQyxDQUFDO3FCQUM1RDtpQkFDSjtnQkFFRCxLQUFLLElBQUksSUFBSSxJQUFJLFVBQVUsRUFBRTtvQkFDekIsSUFBSSxVQUFVLENBQUMsY0FBYyxDQUFDLElBQUksQ0FBQyxFQUFFO3dCQUNqQyxJQUFJLENBQUMsV0FBVyxDQUFDLGVBQWUsQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLGFBQWEsRUFBRSxJQUFJLEVBQUUsVUFBVSxDQUFDLElBQUksQ0FBQyxHQUFHLEdBQUcsQ0FBQyxDQUFDO3FCQUM5RjtpQkFDSjtnQkFDRCxLQUFLLEVBQUUsQ0FBQztnQkFDUixPQUFPLElBQUksVUFBVSxDQUFDLEtBQUssQ0FBQzthQUMvQjtTQUNKO0lBQ0wsQ0FBQztJQUVPLG9CQUFvQixDQUFDLEtBQWEsRUFBRSxVQUFrQjtRQUMxRCxJQUFJLElBQUksQ0FBQyxXQUFXLENBQUMsUUFBUSxFQUFFO1lBQUUsT0FBTztRQUN4QyxJQUFJLENBQUMsSUFBSSxDQUFDLE9BQU87WUFBRSxPQUFPO1FBRTFCLElBQUksU0FBUyxHQUFXLElBQUksQ0FBQyxXQUFXLENBQUMsb0JBQW9CLENBQUMsSUFBSSxDQUFDLENBQUM7UUFDcEUsSUFBSSxTQUFTLEdBQVcsQ0FBQyxJQUFJLENBQUMsV0FBVyxLQUFLLFVBQVUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQztRQUMvRSxJQUFJLGtCQUFrQixHQUFRLElBQUksQ0FBQyxhQUFhLENBQUMscUJBQXFCLEVBQUUsQ0FBQztRQUN6RSxJQUFJLHNCQUFzQixHQUFRLElBQUksQ0FBQyx3QkFBd0IsQ0FBQyxxQkFBcUIsRUFBRSxDQUFDO1FBRXhGLGtCQUFrQixHQUFHLENBQUMsSUFBSSxDQUFDLFdBQVcsS0FBSyxVQUFVLENBQUMsQ0FBQyxDQUFDLENBQUMsa0JBQWtCLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxrQkFBa0IsQ0FBQyxLQUFLLENBQUM7UUFDOUcsc0JBQXNCLEdBQUcsQ0FBQyxJQUFJLENBQUMsV0FBVyxLQUFLLFVBQVUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxzQkFBc0IsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLHNCQUFzQixDQUFDLEtBQUssQ0FBQztRQUUxSCxJQUFJLGNBQWMsR0FBVyxJQUFJLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxjQUFjLENBQUMsa0JBQWtCLENBQUMsc0JBQXNCLEdBQUcsa0JBQWtCLEVBQUUsVUFBVSxDQUFDLENBQUMsQ0FBQztRQUV6SSxJQUFJLEtBQUssR0FBVyxJQUFJLENBQUMsWUFBWSxDQUFDLG9CQUFvQixDQUFDLEtBQUssQ0FBQyxDQUFDO1FBQ2xFLGNBQWMsR0FBRyxJQUFJLENBQUMsWUFBWSxDQUFDLG9CQUFvQixDQUFDLGNBQWMsQ0FBQyxDQUFDO1FBRXhFLElBQUksbUJBQW1CLEdBQVcsSUFBSSxDQUFDLGNBQWMsQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDLHdCQUF3QixDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsRUFBRSxHQUFHLENBQUMsQ0FBQztRQUNqSCxLQUFLLEdBQUcsSUFBSSxDQUFDLFlBQVksQ0FBQyxnQkFBZ0IsQ0FBQyxJQUFJLENBQUMsbUJBQW1CLEVBQUUsbUJBQW1CLEVBQUUsS0FBSyxDQUFDLENBQUM7UUFFakcsSUFBSSxPQUFPLEdBQVcsY0FBYyxHQUFHLEtBQUssQ0FBQztRQUU3QyxJQUFJLG1CQUFtQixHQUFRO1lBQzNCLEtBQUssRUFBRSxFQUFFO1lBQ1QsS0FBSyxFQUFFLEVBQUU7U0FDWixDQUFDO1FBQ0YsbUJBQW1CLENBQUMsT0FBTyxDQUFDLENBQUMsU0FBUyxDQUFDLEdBQUcsS0FBSyxDQUFDO1FBQ2hELG1CQUFtQixDQUFDLE9BQU8sQ0FBQyxDQUFDLFNBQVMsQ0FBQyxHQUFHLEtBQUssQ0FBQztRQUNoRCxtQkFBbUIsQ0FBQyxPQUFPLENBQUMsQ0FBQyxTQUFTLENBQUMsR0FBRyxPQUFPLENBQUM7UUFDbEQsTUFBTSxDQUFDLGNBQWMsQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLGNBQWMsR0FBRyxJQUFJLENBQUMsWUFBWSxFQUFFLElBQUksQ0FBQyxTQUFTLENBQUMsbUJBQW1CLENBQUMsQ0FBQyxDQUFDO1FBRTVHLElBQUksQ0FBQyxXQUFXLENBQUMsZUFBZSxDQUFDLElBQUksQ0FBQyx3QkFBd0IsRUFBRSxTQUFTLEVBQUUsS0FBSyxHQUFHLEdBQUcsQ0FBQyxDQUFDO1FBQ3hGLElBQUksQ0FBQyxXQUFXLENBQUMsZUFBZSxDQUFDLElBQUksQ0FBQyxhQUFhLEVBQUUsU0FBUyxFQUFFLEtBQUssR0FBRyxHQUFHLENBQUMsQ0FBQztRQUM3RSxJQUFJLENBQUMsV0FBVyxDQUFDLGVBQWUsQ0FBQyxJQUFJLENBQUMsYUFBYSxFQUFFLFNBQVMsRUFBRSxPQUFPLEdBQUcsR0FBRyxDQUFDLENBQUM7SUFFbkYsQ0FBQztJQUVPLG1CQUFtQixDQUFDLEtBQWE7UUFDckMsSUFBSSxTQUFTLEdBQVcsSUFBSSxDQUFDLFdBQVcsQ0FBQyxvQkFBb0IsQ0FBQyxJQUFJLENBQUMsQ0FBQztRQUNwRSxJQUFJLENBQUMsbUJBQW1CLEdBQUcsQ0FBQyxJQUFJLENBQUMsbUJBQW1CLENBQUM7UUFFckQsSUFBSSxDQUFDLFdBQVcsQ0FBQyxRQUFRLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxhQUFhLEVBQUUsV0FBVyxDQUFDLENBQUM7UUFDcEUsSUFBSSxDQUFDLFdBQVcsQ0FBQyxlQUFlLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxhQUFhLEVBQUUsZUFBZSxHQUFHLFNBQVMsRUFBRSxJQUFJLENBQUMsbUJBQW1CLENBQUMsQ0FBQztRQUNySCxJQUFJLENBQUMsZ0JBQWdCLENBQUMsSUFBSSxDQUFDLG1CQUFtQixDQUFDLENBQUM7UUFDaEQsSUFBSSxDQUFDLGNBQWMsQ0FBQyxVQUFVLEVBQUUsQ0FBQztJQUNyQyxDQUFDO0lBRU8sbUJBQW1CO1FBQ3ZCLElBQUksQ0FBQyxXQUFXLENBQUMsb0JBQW9CLENBQUMsU0FBUyxFQUFFLElBQUksQ0FBQyxFQUFFLENBQUMsYUFBYSxDQUFDLENBQUM7SUFDNUUsQ0FBQztJQUVPLGtCQUFrQixDQUFDLEtBQWEsRUFBRSxNQUFjO1FBQ3BELElBQUksUUFBUSxHQUFZLElBQUksQ0FBQyxXQUFXLENBQUMsUUFBUSxFQUFFLENBQUM7UUFDcEQsSUFBSSxRQUFRLEdBQWdCLElBQUksQ0FBQyxFQUFFLENBQUMsYUFBYSxDQUFDLGFBQWEsQ0FBQyxTQUFTLENBQUMsQ0FBQztRQUMzRSxJQUFJLFFBQVEsSUFBSSxJQUFJLENBQUMsY0FBYyxLQUFLLEtBQUssSUFBSSxRQUFRLEtBQUssSUFBSSxJQUFJLElBQUksQ0FBQyxlQUFlLEVBQUU7WUFDeEYsMkJBQTJCO1lBQzNCLDRDQUE0QztZQUM1QyxJQUFJLFNBQVMsR0FBVyxRQUFRLENBQUM7WUFFakMsSUFBSSxNQUFNLEdBQWdCLElBQUksQ0FBQyxXQUFXLENBQUMsYUFBYSxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsYUFBYSxFQUFFLGtEQUFrRCxHQUFHLFNBQVMsQ0FBQyxDQUFDO1lBRWhKLGVBQWU7WUFDZixXQUFXLEdBQUcsSUFBSSxDQUFDLFdBQVcsQ0FBQyxhQUFhLENBQUMsTUFBTSxFQUFFLElBQUksRUFBRSxHQUFHLENBQUMsQ0FBQztZQUNoRSxJQUFJLENBQUMsYUFBYSxDQUFDLElBQUksQ0FBQyxjQUFjLENBQUMsQ0FBQztZQUV4QywyQkFBMkI7WUFDM0IsMkJBQTJCO1lBQ3ZDLElBQUksQ0FBQyxTQUFTLENBQUMsTUFBTSxDQUFDLE1BQU0sRUFBRSxPQUFPLEVBQUUsQ0FBQyxLQUFVLEVBQVEsRUFBRTtnQkFDeEQsSUFBSSxDQUFDLGNBQWMsR0FBRyxDQUFDLElBQUksQ0FBQyxjQUFjLENBQUM7Z0JBQzNDLElBQUksQ0FBQyxjQUFjLENBQUMsYUFBYSxDQUFDLElBQUksQ0FBQyxjQUFjLENBQUMsQ0FBQztZQUMzRCxDQUFDLENBQUMsQ0FBQztTQUNNO0lBQ0wsQ0FBQztJQUVPLHNCQUFzQjtRQUMxQixJQUFJLElBQUksQ0FBQyxjQUFjLEtBQUssS0FBSyxFQUFFO1lBQy9CLElBQUksQ0FBQyxjQUFjLENBQUMsZUFBZSxFQUFFO2lCQUNoQyxTQUFTLENBQUMsYUFBYSxDQUFDLEVBQUU7Z0JBQ3ZCLElBQUksQ0FBQyw2QkFBNkIsQ0FBQyxhQUFhLENBQUMsQ0FBQztZQUN0RCxDQUFDLENBQUMsQ0FBQztTQUNWO0lBQ0wsQ0FBQztJQUVPLDZCQUE2QixDQUFDLGFBQXNCLEVBQUUsUUFBa0I7UUFDNUUsbUNBQW1DO1FBQ25DLFFBQVEsR0FBRyxDQUFDLE9BQU8sUUFBUSxLQUFLLFdBQVcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQztRQUMvRCxJQUFJLFNBQVMsR0FBZ0IsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsYUFBYSxDQUFDO1FBQ2xFLElBQUksUUFBUSxHQUFnQixJQUFJLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxhQUFhLENBQUM7UUFDakUsSUFBSSxRQUFRLEdBQVksSUFBSSxDQUFDLFdBQVcsQ0FBQyxRQUFRLEVBQUUsQ0FBQztRQUNwRCxJQUFJLFdBQVcsR0FBWSxDQUFDLElBQUksQ0FBQyxjQUFjLEtBQUssYUFBYSxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDO1FBQ2xGLElBQUksQ0FBQyxjQUFjLEdBQUcsYUFBYSxDQUFDO1FBQ3BDLElBQUksUUFBUSxFQUFFO1lBQ1YsSUFBSSxDQUFDLFdBQVcsQ0FBQyxRQUFRLENBQUMsU0FBUyxFQUFFLFdBQVcsQ0FBQyxDQUFDO1lBQ2xELElBQUksQ0FBQyxXQUFXLENBQUMsUUFBUSxDQUFDLFFBQVEsRUFBRSxXQUFXLENBQUMsQ0FBQztTQUNwRDtRQUVELElBQUksUUFBUSxJQUFJLElBQUksQ0FBQyxzQkFBc0IsRUFBRTtZQUN6QywyQkFBMkI7WUFDM0IsSUFBSSxnQkFBZ0IsR0FBVyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQztZQUN6RCxJQUFJLFNBQVMsR0FBVyxJQUFJLENBQUMsV0FBVyxDQUFDLG9CQUFvQixDQUFDLElBQUksQ0FBQyxDQUFDO1lBQ3BFLElBQUksWUFBWSxHQUFXLENBQUMsU0FBUyxLQUFLLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQztZQUNyRSxJQUFJLFFBQVEsR0FBWSxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxhQUFhLENBQUMsQ0FBQyxDQUFDLENBQUMsYUFBYSxDQUFDO1lBRXBFLElBQUksV0FBVyxHQUFlLENBQUMsRUFBRSxDQUFDLENBQUM7WUFDbkMsSUFBSSxRQUFRLEVBQUU7Z0JBQ1YsSUFBSSxDQUFDLGVBQWUsR0FBRyxRQUFRLENBQUMscUJBQXFCLEVBQUUsQ0FBQyxLQUFLLENBQUM7Z0JBQzlELFdBQVcsR0FBRztvQkFDVixFQUFFLE9BQU8sRUFBRSxJQUFJLENBQUMsZUFBZSxHQUFHLElBQUksRUFBRTtvQkFDeEMsRUFBRSxPQUFPLEVBQUUsTUFBTSxFQUFFO2lCQUN0QixDQUFDO2FBQ0w7aUJBQ0k7Z0JBQ0QsV0FBVyxHQUFHO29CQUNWLEVBQUUsT0FBTyxFQUFFLE1BQU0sRUFBRTtvQkFDbkIsRUFBRSxPQUFPLEVBQUUsSUFBSSxDQUFDLGVBQWUsR0FBRyxJQUFJLEVBQUU7aUJBQzNDLENBQUM7YUFDTDtZQUNELElBQUksQ0FBQyxhQUFhLENBQUMsYUFBYSxDQUFDLENBQUM7WUFDbEMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxlQUFlLENBQUMsUUFBUSxFQUFFLFlBQVksRUFBRSxRQUFRLENBQUMsQ0FBQztZQUNuRSxJQUFJLENBQUMsV0FBVyxDQUFDLGVBQWUsQ0FBQyxTQUFTLEVBQUUsa0JBQWtCLEdBQUcsWUFBWSxHQUFHLEdBQUcsR0FBRyxnQkFBZ0IsRUFBRSxRQUFRLENBQUMsQ0FBQztZQUVsSCxJQUFJLFFBQVEsSUFBSSxDQUFDLFdBQVcsRUFBRTtnQkFDMUIsSUFBSSxDQUFDLFdBQVcsQ0FBQyxtQkFBbUIsQ0FDaEMsUUFBUSxFQUNSLFNBQVMsRUFDVCxDQUFDLFdBQVcsRUFBRSxHQUFHLENBQUMsQ0FDckIsQ0FBQztnQkFFRixLQUFLLENBQUMsR0FBRyxDQUFDLENBQUMsU0FBUyxDQUFDLEdBQVMsRUFBRTtvQkFDNUIsZ0dBQWdHO29CQUNoRyxJQUFJLENBQUMsY0FBYyxDQUFDLGFBQWEsQ0FBQyxhQUFhLENBQUMsQ0FBQztvQkFDakQsZ0VBQWdFO2dCQUNwRSxDQUFDLENBQUMsQ0FBQzthQUNOO1NBQ0o7SUFDTCxDQUFDO0lBRU8sYUFBYSxDQUFDLE9BQWdCO1FBQ2xDLElBQUksT0FBTyxHQUFnQixJQUFJLENBQUMsRUFBRSxDQUFDLGFBQWEsQ0FBQyxhQUFhLENBQUMsV0FBVyxDQUFDLENBQUM7UUFDNUUsSUFBSSxJQUFJLENBQUMsY0FBYyxLQUFLLEtBQUssSUFBSSxPQUFPLEtBQUssSUFBSSxFQUFFO1lBQ25ELElBQUksQ0FBQyxXQUFXLENBQUMsZUFBZSxDQUFDLE9BQU8sRUFBRSxVQUFVLEVBQUUsQ0FBQyxPQUFPLENBQUMsQ0FBQztZQUNoRSxJQUFJLENBQUMsV0FBVyxDQUFDLGVBQWUsQ0FBQyxPQUFPLEVBQUUsZ0JBQWdCLEVBQUUsT0FBTyxDQUFDLENBQUM7U0FDeEU7SUFDTCxDQUFDO0lBRU8sZ0JBQWdCLENBQUMsT0FBZ0I7UUFDckMsSUFBSSxTQUFTLEdBQVcsSUFBSSxDQUFDLFdBQVcsQ0FBQyxvQkFBb0IsQ0FBQyxJQUFJLENBQUMsQ0FBQztRQUNwRSxJQUFJLFlBQVksR0FBVyxDQUFDLFNBQVMsS0FBSyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUM7UUFDckUsSUFBSSxPQUFPLEdBQWdCLElBQUksQ0FBQyxFQUFFLENBQUMsYUFBYSxDQUFDLGFBQWEsQ0FBQyxhQUFhLENBQUMsQ0FBQztRQUU5RSxJQUFJLElBQUksQ0FBQyxjQUFjLEtBQUssTUFBTSxJQUFJLE9BQU8sS0FBSyxJQUFJLEVBQUU7WUFDcEQsSUFBSSxDQUFDLFdBQVcsQ0FBQyxlQUFlLENBQUMsT0FBTyxFQUFFLFdBQVcsR0FBRyxTQUFTLEVBQUUsQ0FBQyxPQUFPLENBQUMsQ0FBQztZQUM3RSxJQUFJLENBQUMsV0FBVyxDQUFDLGVBQWUsQ0FBQyxPQUFPLEVBQUUsV0FBVyxHQUFHLFlBQVksRUFBRSxPQUFPLENBQUMsQ0FBQztTQUNsRjtJQUNMLENBQUM7SUFFTyxRQUFRLENBQUMsSUFBYTtRQUMxQixJQUFJLFFBQVEsR0FBWSxJQUFJLENBQUMsV0FBVyxDQUFDLFFBQVEsRUFBRSxDQUFDO1FBQ3BELElBQUksVUFBVSxHQUFnQixJQUFJLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxhQUFhLENBQUMsYUFBYSxDQUFDLGtCQUFrQixDQUFDLENBQUM7UUFDckcsSUFBSSxVQUFVLEtBQUssSUFBSSxFQUFFO1lBQ3JCLFVBQVUsR0FBRyxJQUFJLENBQUMsV0FBVyxDQUFDLGFBQWEsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxhQUFhLEVBQUUsaUJBQWlCLENBQUMsQ0FBQztZQUVyRyxJQUFJLENBQUMsU0FBUyxDQUFDLE1BQU0sQ0FBQyxVQUFVLEVBQUUsT0FBTyxFQUFFLENBQUMsS0FBVSxFQUFRLEVBQUU7Z0JBQ3hFLElBQUksQ0FBQyxjQUFjLENBQUMsSUFBSSxFQUFFLENBQUM7WUFDL0IsQ0FBQyxDQUFDLENBQUM7U0FDTTtRQUVELElBQUksUUFBUSxFQUFFO1lBQ1YsSUFBSSxDQUFDLFdBQVcsQ0FBQyxlQUFlLENBQUMsVUFBVSxFQUFFLE1BQU0sRUFBRSxJQUFJLENBQUMsQ0FBQztZQUMzRCxJQUFJLElBQUksQ0FBQyxjQUFjLEtBQUssTUFBTSxFQUFFO2dCQUNoQyxJQUFJLFdBQVcsR0FBRyxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxhQUFhLENBQUMsYUFBYSxDQUFDLGVBQWUsQ0FBQyxDQUFDO2dCQUN0Riw0QkFBNEI7Z0JBQzVCLElBQUksV0FBVyxFQUFFO29CQUNiLElBQUksaUJBQWlCLEdBQUcsV0FBVyxDQUFDLHFCQUFxQixFQUFFLENBQUMsTUFBTSxDQUFDO29CQUNuRSxJQUFJLFVBQVUsR0FBVyxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxhQUFhLENBQUMscUJBQXFCLEVBQUUsQ0FBQyxNQUFNLENBQUM7b0JBQzdGLDJCQUEyQjtvQkFDM0Isa0NBQWtDO29CQUNsQyxJQUFJLGlCQUFpQixHQUFHLFVBQVUsRUFBRTt3QkFDaEMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxlQUFlLENBQUMsVUFBVSxFQUFFLFFBQVEsRUFBRSxNQUFNLENBQUMsQ0FBQzt3QkFDL0QsSUFBSSxDQUFDLFdBQVcsQ0FBQyxlQUFlLENBQUMsVUFBVSxFQUFFLFFBQVEsRUFBRSxpQkFBaUIsR0FBRyxJQUFJLENBQUMsQ0FBQztxQkFDcEY7aUJBQ0o7Z0JBQ0QsSUFBSSxDQUFDLFdBQVcsQ0FBQyxlQUFlLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsYUFBYSxFQUFFLGFBQWEsRUFBRSxJQUFJLENBQUMsQ0FBQzthQUMvRjtTQUNKO0lBQ0wsQ0FBQztJQUVPLE9BQU8sQ0FBQyxLQUFVO1FBQ3RCLElBQUksSUFBSSxDQUFDLFlBQVk7WUFBRSxPQUFPO1FBQzlCLElBQUksQ0FBQyxJQUFJLENBQUMsT0FBTztZQUFFLE9BQU87UUFFMUIsSUFBSSxTQUFTLEdBQVcsSUFBSSxDQUFDLFdBQVcsQ0FBQyxvQkFBb0IsQ0FBQyxJQUFJLENBQUMsQ0FBQztRQUNwRSw0RUFBNEU7UUFDNUUsSUFBSSxjQUFjLEdBQVEsSUFBSSxDQUFDLEVBQUUsQ0FBQyxhQUFhLENBQUMscUJBQXFCLEVBQUUsQ0FBQztRQUV4RSxJQUFJLEtBQUssR0FBRyxJQUFJLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxPQUFPLEdBQUcsY0FBYyxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUM7UUFDaEUsc0JBQXNCO1FBQ3RCLDJEQUEyRDtRQUMzRCx5QkFBeUI7UUFDekIsSUFBSSxPQUFPLEdBQUcsSUFBSSxDQUFDLGNBQWMsQ0FBQyxrQkFBa0IsQ0FBQyxLQUFLLEVBQUUsY0FBYyxDQUFDLEtBQUssQ0FBQyxDQUFDO1FBQ2xGLHFDQUFxQztRQUVyQyxJQUFJLENBQUMsV0FBVyxDQUFDLFdBQVcsQ0FBQyxJQUFJLENBQUMsYUFBYSxFQUFFLFdBQVcsQ0FBQyxDQUFDO1FBQzlELElBQUksQ0FBQyxvQkFBb0IsQ0FBQyxPQUFPLEVBQUUsY0FBYyxDQUFDLEtBQUssQ0FBQyxDQUFDO1FBQ3pELElBQUksQ0FBQyxjQUFjLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxjQUFjLENBQUMsQ0FBQztJQUNsRCxDQUFDO0lBRU8sU0FBUyxDQUFDLEtBQVU7UUFDeEIsSUFBSSxRQUFRLEdBQVksSUFBSSxDQUFDLFdBQVcsQ0FBQyxRQUFRLEVBQUUsQ0FBQztRQUNwRCxJQUFJLFFBQVEsS0FBSyxJQUFJLENBQUMsYUFBYSxFQUFFO1lBQ2pDLElBQUksQ0FBQyxzQkFBc0IsR0FBRyxJQUFJLENBQUM7WUFDbkMsSUFBSSxDQUFDLGFBQWEsR0FBRyxRQUFRLENBQUM7WUFDOUIsSUFBSSxDQUFDLGNBQWMsR0FBRyxLQUFLLENBQUM7U0FDL0I7UUFDRCxJQUFJLENBQUMsbUJBQW1CLEVBQUUsQ0FBQztRQUMzQixJQUFJLENBQUMsc0JBQXNCLEdBQUcsS0FBSyxDQUFDO0lBQ3hDLENBQUM7OztZQWplSixTQUFTLFNBQUM7Z0JBQ1AsUUFBUSxFQUFFLGFBQWE7Z0JBQ3ZCLFFBQVEsRUFBRSw4RUFBOEU7Z0JBQ3hGLGFBQWEsRUFBRSxpQkFBaUIsQ0FBQyxJQUFJO2dCQUNyQyxTQUFTLEVBQUUsQ0FBQyxhQUFhLEVBQUUsZUFBZSxFQUFFLGVBQWUsRUFBRSxZQUFZLENBQUM7Z0JBQzFFLElBQUksRUFBRSxFQUFFLE9BQU8sRUFBRSxpQkFBaUIsRUFBRTthQUN2Qzs7O1lBZG1FLGdCQUFnQjtZQUE2QixTQUFTO1lBS2pILGFBQWE7WUFEYixlQUFlO1lBQUUsWUFBWTtZQUU3QixlQUFlO1lBTGYsTUFBTTs7OzBCQXFDVixLQUFLO3VCQUNMLEtBQUs7MEJBQ0wsS0FBSzswQkFjTCxZQUFZLFNBQUMsb0JBQW9CLEVBQUUsQ0FBQyxRQUFRLENBQUM7d0JBTzdDLFlBQVksU0FBQyxrQkFBa0IsRUFBRSxDQUFDLFFBQVEsQ0FBQzt1QkFNM0MsWUFBWSxTQUFDLGVBQWUsRUFBRSxDQUFDLFFBQVEsQ0FBQyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IENvbXBvbmVudCwgSW5wdXQsIE9uSW5pdCwgSG9zdExpc3RlbmVyLCBWaWV3RW5jYXBzdWxhdGlvbiwgVmlld0NvbnRhaW5lclJlZiwgQWZ0ZXJWaWV3SW5pdCwgRWxlbWVudFJlZiwgUmVuZGVyZXIyIH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XHJcbmltcG9ydCB7IFJvdXRlciwgTmF2aWdhdGlvbkVuZCB9IGZyb20gJ0Bhbmd1bGFyL3JvdXRlcic7XHJcbmltcG9ydCB7IHRpbWVyIH0gZnJvbSAncnhqcyc7XHJcbmltcG9ydCB7IEtkUGFuZSB9IGZyb20gJy4va2QtcGFuZSc7XHJcbmltcG9ydCB7IEtkQ29udmVydGlvblN2YywgS2REb21FbGVtU3ZjIH0gZnJvbSAnLi4vLi4va2QtY29tbW9uL2luZGV4JztcclxuaW1wb3J0IHsgS2RTcGxpdHRlclN2YyB9IGZyb20gJy4va2Qtc3BsaXR0ZXItc3ZjJztcclxuaW1wb3J0IHsgS2RTcGxpdHRlckV2ZW50IH0gZnJvbSAnLi9rZC1zcGxpdHRlci1ldmVudCc7XHJcblxyXG5AQ29tcG9uZW50KHtcclxuICAgIHNlbGVjdG9yOiAna2Qtc3BsaXR0ZXInLFxyXG4gICAgdGVtcGxhdGU6IGA8ZGl2IGNsYXNzPSdzcGxpdC1jb250YWluZXIge3tvcmllbnRhdGlvbn19Jz48bmctY29udGVudD48L25nLWNvbnRlbnQ+PC9kaXY+YCxcclxuICAgIGVuY2Fwc3VsYXRpb246IFZpZXdFbmNhcHN1bGF0aW9uLk5vbmUsXHJcbiAgICBwcm92aWRlcnM6IFtLZFNwbGl0dGVyU3ZjLCBLZFNwbGl0dGVyRXZlbnQsIEtkQ29udmVydGlvblN2YywgS2REb21FbGVtU3ZjXSxcclxuICAgIGhvc3Q6IHsgJ2NsYXNzJzogJ2tkeC1zcGxpdC1wYW5lcycgfVxyXG59KVxyXG5cclxuZXhwb3J0IGNsYXNzIEtkU3BsaXR0ZXIgaW1wbGVtZW50cyBPbkluaXQsIEFmdGVyVmlld0luaXQge1xyXG5cclxuICAgIHByaXZhdGUgZWw6IEVsZW1lbnRSZWY7XHJcbiAgICBwcml2YXRlIF9pc0RyYWc6IGJvb2xlYW4gPSBmYWxzZTtcclxuICAgIHByaXZhdGUgX2Rpc2FibGVEcmFnOiBib29sZWFuID0gZmFsc2U7XHJcbiAgICBwcml2YXRlIF9wYW5lc0RlZmF1bHRDb25maWc6IGFueSA9IHt9O1xyXG4gICAgcHJpdmF0ZSBfcGFuZXM6IEFycmF5PEtkUGFuZT4gPSBbXTtcclxuICAgIHByaXZhdGUgX3NlbGVjdGVkRWxlbTogRWxlbWVudDtcclxuICAgIHByaXZhdGUgX3NlbGVjdGVkUHJldlNpYmxpbmdFbGVtOiBFbGVtZW50O1xyXG4gICAgLy8gcHJpdmF0ZSBfbG9jYWxTdG9yYWdlOiBudW1iZXI7XHJcbiAgICBwcml2YXRlIF9pc01haW5QYW5lQ29sbGFwc2U6IGJvb2xlYW4gPSBmYWxzZTtcclxuICAgIHByaXZhdGUgX3NwbGl0dGVyTGV2ZWw6IHN0cmluZyA9ICcnO1xyXG4gICAgcHJpdmF0ZSBfZW5hYmxlRmxvYXRCdG46IGJvb2xlYW4gPSBmYWxzZTtcclxuICAgIHByaXZhdGUgX2VuYWJsZVN1YlBhbmVDb2xsYXBzZTogYm9vbGVhbiA9IGZhbHNlO1xyXG4gICAgcHJpdmF0ZSBfcHJldklzTW9iaWxlOiBib29sZWFuID0gZmFsc2U7XHJcbiAgICBwcml2YXRlIF9pc1N1YlBhbmVPcGVuOiBib29sZWFuID0gZmFsc2U7XHJcbiAgICBwcml2YXRlIF9zZXNzaW9uUHJlZml4OiBzdHJpbmcgPSAnJztcclxuICAgIHByaXZhdGUgX3Nlc3Npb25OYW1lOiBzdHJpbmcgPSAnc3BsaXR0ZXInO1xyXG4gICAgcHJpdmF0ZSBfaXNGaXJzdFN3aXRjaFZpZXdQb3J0OiBib29sZWFuID0gdHJ1ZTtcclxuICAgIHByaXZhdGUgX3ByZXZXaWR0aFN0YXRlOiBudW1iZXIgPSAwO1xyXG4gICAgcHJpdmF0ZSBfaXNNZW51T3BlbjogYm9vbGVhbiA9IGZhbHNlO1xyXG5cclxuICAgIEBJbnB1dCgpIG9yaWVudGF0aW9uOiBzdHJpbmc7XHJcbiAgICBASW5wdXQoKSBmbG9hdGJ0bjogc3RyaW5nO1xyXG4gICAgQElucHV0KCkgY29sbGFwc2libGU6IHN0cmluZztcclxuXHJcbiAgICBjb25zdHJ1Y3RvcihcclxuICAgICAgICBwcml2YXRlIF92Y3I6IFZpZXdDb250YWluZXJSZWYsXHJcbiAgICAgICAgcHJpdmF0ZSBfcmVuZGVyZXI6IFJlbmRlcmVyMixcclxuICAgICAgICBwcml2YXRlIF9zcGxpdHRlclN2YzogS2RTcGxpdHRlclN2YyxcclxuICAgICAgICBwcml2YXRlIF9jb252ZXJ0aW9uU3ZjOiBLZENvbnZlcnRpb25TdmMsXHJcbiAgICAgICAgcHJpdmF0ZSBfZG9tRWxlbVN2YzogS2REb21FbGVtU3ZjLFxyXG4gICAgICAgIHByaXZhdGUgX3NwbGl0dGVyRXZlbnQ6IEtkU3BsaXR0ZXJFdmVudCxcclxuICAgICAgICBwcml2YXRlIF9yb3V0ZXI6IFJvdXRlclxyXG4gICAgKSB7XHJcbiAgICAgICAgdGhpcy5lbCA9IHRoaXMuX3Zjci5lbGVtZW50O1xyXG4gICAgfVxyXG5cclxuICAgIEBIb3N0TGlzdGVuZXIoJ2RvY3VtZW50Om1vdXNlbW92ZScsIFsnJGV2ZW50J10pXHJcbiAgICBvbk1vdXNlbW92ZShldmVudDogYW55KTogdm9pZCB7XHJcbiAgICAgICAgLy8gdGhpcy5tb3VzZW1vdmUuZW1pdChldmVudCk7XHJcbiAgICAgICAgdGhpcy5fb25EcmFnKGV2ZW50KTtcclxuXHJcbiAgICB9XHJcblxyXG4gICAgQEhvc3RMaXN0ZW5lcignZG9jdW1lbnQ6bW91c2V1cCcsIFsnJGV2ZW50J10pXHJcbiAgICBvbk1vdXNldXAoZXZlbnQ6IGFueSk6IHZvaWQge1xyXG4gICAgICAgIC8vIHRoaXMubW91c2V1cC5lbWl0KGV2ZW50KTtcclxuICAgICAgICB0aGlzLl9pc0RyYWcgPSBmYWxzZTtcclxuICAgIH1cclxuXHJcbiAgICBASG9zdExpc3RlbmVyKCd3aW5kb3c6cmVzaXplJywgWyckZXZlbnQnXSlcclxuICAgIG9uUmVzaXplKGV2ZW50OiBhbnkpOiB2b2lkIHtcclxuICAgICAgICAvLyBjb25zb2xlLmxvZygncmVzaXplJyk7XHJcbiAgICAgICAgdGhpcy5fb25SZXNpemUoZXZlbnQpO1xyXG4gICAgfVxyXG5cclxuICAgIG5nT25Jbml0KCk6IHZvaWQge1xyXG4gICAgICAgIHRoaXMuX3ByZXZJc01vYmlsZSA9IHRoaXMuX2RvbUVsZW1TdmMuaXNNb2JpbGUoKTtcclxuICAgICAgICB0aGlzLl9lbmFibGVGbG9hdEJ0biA9IHRoaXMuX2NvbnZlcnRpb25TdmMuc3RyVG9Cb29sKHRoaXMuZmxvYXRidG4pO1xyXG4gICAgICAgIHRoaXMuX2VuYWJsZVN1YlBhbmVDb2xsYXBzZSA9IHRoaXMuX2NvbnZlcnRpb25TdmMuc3RyVG9Cb29sKHRoaXMuY29sbGFwc2libGUpO1xyXG4gICAgICAgIC8vIHRoaXMuX3BhbmVzRGVmYXVsdENvbmZpZyA9IHRoaXMuX3NwbGl0dGVyU3ZjLmluaXRQYW5lc0RlZmF1bHRDb25maWcodGhpcy5fcGFuZXMpO1xyXG4gICAgICAgIC8vIGNvbnNvbGUubG9nKHRoaXMuX3BhbmVzRGVmYXVsdENvbmZpZyk7XHJcbiAgICB9XHJcblxyXG4gICAgbmdBZnRlclZpZXdJbml0KCk6IHZvaWQge1xyXG4gICAgICAgIHRoaXMuX3BhbmVzRGVmYXVsdENvbmZpZyA9IHRoaXMuX3NwbGl0dGVyU3ZjLmluaXRQYW5lc0RlZmF1bHRDb25maWcodGhpcy5fcGFuZXMpO1xyXG4gICAgICAgIHRoaXMuX2Rpc2FibGVEcmFnID0gdGhpcy5fc3BsaXR0ZXJTdmMudG9EaXNhYmxlRHJhZygpO1xyXG5cclxuICAgICAgICBpZiAodGhpcy5fc3BsaXR0ZXJTdmMuaXNTdWJQYW5lKHRoaXMuZWwubmF0aXZlRWxlbWVudCkpIHtcclxuICAgICAgICAgICAgLy8gY29uc29sZS5sb2coJ3RoaXMgaXMgdGhlIHN1YiBwYW5lJyk7XHJcbiAgICAgICAgICAgIHRoaXMuX3NwbGl0dGVyTGV2ZWwgPSAnc3ViJztcclxuICAgICAgICAgICAgbGV0IGxlZnRQYW5lOiBIVE1MRWxlbWVudCA9IHRoaXMuX3BhbmVzWzBdLmVsZW1lbnQubmF0aXZlRWxlbWVudDtcclxuICAgICAgICAgICAgdGhpcy5fcHJldldpZHRoU3RhdGUgPSBsZWZ0UGFuZS5nZXRCb3VuZGluZ0NsaWVudFJlY3QoKS53aWR0aDtcclxuICAgICAgICB9XHJcbiAgICAgICAgZWxzZSB7XHJcbiAgICAgICAgICAgIC8vIGNvbnNvbGUubG9nKCd0aGlzIGlzIHRoZSBtYWluIHBhbmUnKTtcclxuICAgICAgICAgICAgdGhpcy5fc3BsaXR0ZXJMZXZlbCA9ICdtYWluJztcclxuXHJcbiAgICAgICAgICAgIHRoaXMuX3JlZ2lzdGVyTWVudUJyb2FkY2FzdCgpO1xyXG4gICAgICAgICAgICB0aGlzLl9zZXRUaW50KGZhbHNlKTtcclxuICAgICAgICB9XHJcbiAgICAgICAgLy8gdGhpcy5fc3BsaXR0ZXJFdmVudC5vbkRyYWcoKVxyXG4gICAgICAgIC8vIC5zdWJzY3JpYmUoX3R5cGUgPT4ge1xyXG4gICAgICAgIC8vICAgICBjb25zb2xlLmxvZyhfdHlwZSk7XHJcbiAgICAgICAgLy8gfSk7XHJcbiAgICAgICAgLy8gaXNTdWJTcGxpdHRlci9cclxuICAgICAgICB0aGlzLl9zZXNzaW9uUHJlZml4ID0gdGhpcy5fY29udmVydGlvblN2Yy5jYW1lbENhc2UodGhpcy5fZG9tRWxlbVN2Yy5nZXREb2N1bWVudFRoZW1lKCksICctJykgKyAnX3NwbGl0dGVyXycgKyB0aGlzLl9zcGxpdHRlckxldmVsO1xyXG5cclxuICAgICAgICB0aGlzLl9zZXREZWZhdWx0UGFuZVNpemUoKTtcclxuICAgICAgICB0aGlzLl9zZXR1cFNwbGl0dGVySGFuZGxlcigpO1xyXG4gICAgICAgIHRoaXMuX3RvZ2dsZUNvbGxhcHNlU3ViUGFuZSgpO1xyXG5cclxuICAgICAgICB0aGlzLl9pc0ZpcnN0U3dpdGNoVmlld1BvcnQgPSBmYWxzZTtcclxuXHJcbiAgICAgICAgdGhpcy5fcm91dGVyLmV2ZW50cy5zdWJzY3JpYmUoZXZlbnQgPT4ge1xyXG4gICAgICAgICAgICBpZiAoZXZlbnQgaW5zdGFuY2VvZiBOYXZpZ2F0aW9uRW5kKSB7XHJcbiAgICAgICAgICAgICAgICAvLyBjb25zb2xlLmxvZyhldmVudC51cmwpO1xyXG4gICAgICAgICAgICAgICAgZm9yIChsZXQga2V5IGluIHRoaXMuX3BhbmVzKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKHRoaXMuX3BhbmVzLmhhc093blByb3BlcnR5KGtleSkpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgbGV0IHBhbmU6IEtkUGFuZSA9IHRoaXMuX3BhbmVzW2tleV07XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHBhbmUuZWxlbWVudC5uYXRpdmVFbGVtZW50LnNjcm9sbFRvcCA9IDA7XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfSk7XHJcbiAgICB9XHJcblxyXG4gICAgYWRkR3JvdXAocGFuZTogS2RQYW5lKTogbnVtYmVyIHtcclxuICAgICAgICB0aGlzLl9wYW5lcy5wdXNoKHBhbmUpO1xyXG4gICAgICAgIHJldHVybiB0aGlzLl9wYW5lcy5sZW5ndGg7XHJcbiAgICB9XHJcblxyXG4gICAgcGFuZU9uQ2hhbmdlKF90eXBlOiBzdHJpbmcpOiB2b2lkIHtcclxuICAgICAgICB0aGlzLl9wYW5lc0RlZmF1bHRDb25maWcgPSB0aGlzLl9zcGxpdHRlclN2Yy5pbml0UGFuZXNEZWZhdWx0Q29uZmlnKHRoaXMuX3BhbmVzKTtcclxuICAgICAgICBpZiAoX3R5cGUgPT09ICdzaXplJykge1xyXG4gICAgICAgICAgICAvLyBjaGFuZ2luZyBlbGVtZW50IHdpZHRoIGJlZm9yZSBhbmltYXRpb24gb2YgcGFuZXMgc3RhcnRcclxuICAgICAgICAgICAgdGhpcy5fc2V0RGVmYXVsdFBhbmVTaXplKGZhbHNlKTtcclxuICAgICAgICAgICAgbGV0IGJvdW5kaW5nUmVjdCA9IHRoaXMuZWwubmF0aXZlRWxlbWVudC5nZXRCb3VuZGluZ0NsaWVudFJlY3QoKTtcclxuICAgICAgICAgICAgaWYgKGJvdW5kaW5nUmVjdCkge1xyXG4gICAgICAgICAgICAgICAgLy8gYWZmZWN0cyBhbmltYXRpb24gb2YgbGVmdCBwYW5lLiBcclxuICAgICAgICAgICAgICAgIHRoaXMuX3ByZXZXaWR0aFN0YXRlID0gdGhpcy5fcGFuZXNEZWZhdWx0Q29uZmlnLlBhbmUxLnNpemUgKiBib3VuZGluZ1JlY3Qud2lkdGg7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfcmVnaXN0ZXJNZW51QnJvYWRjYXN0KCkge1xyXG4gICAgICAgIHRoaXMuX3NwbGl0dGVyRXZlbnQub24oKVxyXG4gICAgICAgICAgICAuc3Vic2NyaWJlKHJlc3BvbmUgPT4ge1xyXG4gICAgICAgICAgICAgICAgLy8gY29uc29sZS5sb2cocmVzcG9uZSk7XHJcbiAgICAgICAgICAgICAgICBsZXQgZGlyZWN0aW9uOiBzdHJpbmcgPSB0aGlzLl9kb21FbGVtU3ZjLmdldERvY3VtZW50RGlyZWN0aW9uKHRydWUpO1xyXG4gICAgICAgICAgICAgICAgbGV0IG9wcERpcmVjdGlvbjogc3RyaW5nID0gZGlyZWN0aW9uID09PSAnbGVmdCcgPyAncmlnaHQnIDogJ2xlZnQnO1xyXG4gICAgICAgICAgICAgICAgbGV0IGNsYXNzTmFtZTogc3RyaW5nID0gJ3B1c2gtY29udGVudC0nICsgb3BwRGlyZWN0aW9uO1xyXG4gICAgICAgICAgICAgICAgbGV0IGlzTW9iaWxlOiBib29sZWFuID0gdGhpcy5fZG9tRWxlbVN2Yy5pc01vYmlsZSgpO1xyXG4gICAgICAgICAgICAgICAgbGV0IGNvdW50OiBudW1iZXIgPSAwO1xyXG5cclxuICAgICAgICAgICAgICAgIGZvciAobGV0IGtleSBpbiB0aGlzLl9wYW5lcykge1xyXG4gICAgICAgICAgICAgICAgICAgIGlmICh0aGlzLl9wYW5lcy5oYXNPd25Qcm9wZXJ0eShrZXkpKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGxldCBwYW5lOiBLZFBhbmUgPSB0aGlzLl9wYW5lc1trZXldO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLl9kb21FbGVtU3ZjLnNldEVsZW1lbnRDbGFzcyhwYW5lLmVsZW1lbnQubmF0aXZlRWxlbWVudCwgJ2FuaW1hdGlvbicsIGlzTW9iaWxlKTtcclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGlmIChjb3VudCAhPT0gMCkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKCFpc01vYmlsZSkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuX2RvbUVsZW1TdmMucmVtb3ZlQ2xhc3MocGFuZS5lbGVtZW50Lm5hdGl2ZUVsZW1lbnQsIGNsYXNzTmFtZSk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0aGlzLl9pc01lbnVPcGVuID0gIXRoaXMuX2lzTWVudU9wZW47XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKHRoaXMuX3NwbGl0dGVyTGV2ZWwgPT09ICdtYWluJykge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyBjb25zb2xlLmxvZygnYXBwZW5kIGNsYXNzICcgKyBjbGFzc05hbWUgKyAnIGludG8gbWFpbiBwYW5lJyk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuX2RvbUVsZW1TdmMuc2V0RWxlbWVudENsYXNzKHBhbmUuZWxlbWVudC5uYXRpdmVFbGVtZW50LCBjbGFzc05hbWUsIHRoaXMuX2lzTWVudU9wZW4pO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0aGlzLl9zZXRUaW50KHRoaXMuX2lzTWVudU9wZW4pO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmIChpc01vYmlsZSAmJiB0aGlzLl9zcGxpdHRlckxldmVsID09PSAnc3ViJykge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIGNvbnNvbGUubG9nKCdzdWIgbWFpbicpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvdW50Kys7XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9KTtcclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF9zZXR1cFNwbGl0dGVySGFuZGxlcigpOiB2b2lkIHtcclxuICAgICAgICBmb3IgKGxldCBpOiBudW1iZXIgPSAxOyBpIDwgdGhpcy5fcGFuZXMubGVuZ3RoOyBpKyspIHtcclxuICAgICAgICAgICAgbGV0IGNvdW50OiBudW1iZXIgPSBpICsgMTtcclxuICAgICAgICAgICAgbGV0IGNsYXNzTmFtZTogc3RyaW5nID0gJ3NoLScgKyBjb3VudDtcclxuXHJcbiAgICAgICAgICAgIGxldCBuZXdFbDogSFRNTEVsZW1lbnQgPSB0aGlzLl9kb21FbGVtU3ZjLmNyZWF0ZUVsZW1lbnQodGhpcy5fcGFuZXNbaV0uZWxlbWVudC5uYXRpdmVFbGVtZW50LCAnc3BsaXR0ZXItaGFuZGxlciAnICsgY2xhc3NOYW1lKTtcclxuICAgICAgICAgICAgdGhpcy5fZG9tRWxlbVN2Yy5zZXRFbGVtZW50Q2xhc3MobmV3RWwsICdkaXNhYmxlZCcsIHRoaXMuX2Rpc2FibGVEcmFnKTtcclxuXHJcbiAgICAgICAgICAgIC8vIHNldHVwIE9uTW91c2VEb3duRXZlbnRcclxuICAgICAgICAgICAgLy8gc2V0dXAgT25Nb3VzZURvd25FdmVudFxyXG50aGlzLl9yZW5kZXJlci5saXN0ZW4obmV3RWwsICdtb3VzZWRvd24nLCAoZXZlbnQ6IGFueSk6IHZvaWQgPT4ge1xyXG4gICAgdGhpcy5fc2VsZWN0ZWRFbGVtID0gZXZlbnQudGFyZ2V0LnBhcmVudEVsZW1lbnQ7XHJcbiAgICB0aGlzLl9zZWxlY3RlZFByZXZTaWJsaW5nRWxlbSA9IHRoaXMuX3NlbGVjdGVkRWxlbS5wcmV2aW91c0VsZW1lbnRTaWJsaW5nO1xyXG4gICAgdGhpcy5faXNEcmFnID0gdHJ1ZTtcclxufSk7XHJcblxyXG4gICAgICAgICAgICBpZiAodGhpcy5fc3BsaXR0ZXJMZXZlbCA9PT0gJ21haW4nKSB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLl9zZXR1cENvbGxhcHNlQnV0dG9uKHRoaXMuX3BhbmVzW2ldLCBjb3VudCk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfc2V0dXBDb2xsYXBzZUJ1dHRvbihfcGFuZTogS2RQYW5lLCBfY291bnQ6IG51bWJlcik6IHZvaWQge1xyXG4gICAgICAgIGxldCBjbGFzc05hbWU6IHN0cmluZyA9ICdtYi0nICsgX2NvdW50O1xyXG4gICAgICAgIGxldCBuZXdCdG46IEhUTUxFbGVtZW50ID0gdGhpcy5fZG9tRWxlbVN2Yy5jcmVhdGVFbGVtZW50KF9wYW5lLmVsZW1lbnQubmF0aXZlRWxlbWVudCwgJ21lbnUtYnRuICcgKyBjbGFzc05hbWUpO1xyXG5cclxuICAgICAgICAvLyBTZXR1cCBpY29uXHJcbiAgICAgICAgdGhpcy5fZG9tRWxlbVN2Yy5jcmVhdGVFbGVtZW50KG5ld0J0biwgJ2ZhJywgJ2knKTtcclxuICAgICAgICB0aGlzLl9zZXRDb2xsYXBzZUljb24odGhpcy5faXNNYWluUGFuZUNvbGxhcHNlKTtcclxuICAgICAgICAvLyBzZXR1cCBPbk1vdXNlRG93bkV2ZW50XHJcbiAgICAgICAgLy8gc2V0dXAgT25Nb3VzZURvd25FdmVudFxyXG50aGlzLl9yZW5kZXJlci5saXN0ZW4obmV3QnRuLCAnY2xpY2snLCAoZXZlbnQ6IGFueSk6IHZvaWQgPT4ge1xyXG4gICAgLy8gY29uc29sZS5sb2coZXZlbnQpO1xyXG4gICAgdGhpcy5faXNEcmFnID0gZmFsc2U7XHJcbiAgICB0aGlzLl90b2dnbGVDb2xsYXBzZU1lbnUoX3BhbmUpO1xyXG59KTtcclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF9zZXREZWZhdWx0UGFuZVNpemUoX3VzZUxvY2FsU3RvcmFnZTogYm9vbGVhbiA9IHRydWUpOiB2b2lkIHtcclxuICAgICAgICBsZXQgY291bnQ6IG51bWJlciA9IDA7XHJcbiAgICAgICAgbGV0IG9mZnNldFg6IG51bWJlciA9IDA7XHJcbiAgICAgICAgbGV0IGRpcmVjdGlvbjogc3RyaW5nID0gdGhpcy5fZG9tRWxlbVN2Yy5nZXREb2N1bWVudERpcmVjdGlvbih0cnVlKTtcclxuICAgICAgICBsZXQgb3BwRGlyZWN0aW9uOiBzdHJpbmcgPSBkaXJlY3Rpb24gPT09ICdsZWZ0JyA/ICdyaWdodCcgOiAnbGVmdCc7XHJcbiAgICAgICAgbGV0IG1vYmlsZUNvbmZpZzogYW55ID0gdGhpcy5fc3BsaXR0ZXJTdmMuZ2V0TW9iaWxlQ29uZmlnKHRoaXMuX3NwbGl0dGVyTGV2ZWwsIGRpcmVjdGlvbik7XHJcbiAgICAgICAgbGV0IGlzTW9iaWxlOiBib29sZWFuID0gdGhpcy5fZG9tRWxlbVN2Yy5pc01vYmlsZSgpO1xyXG4gICAgICAgIGxldCBsb2NhbFN0b3JhZ2U6IGFueSA9IEpTT04ucGFyc2Uod2luZG93LnNlc3Npb25TdG9yYWdlLmdldEl0ZW0odGhpcy5fc2Vzc2lvblByZWZpeCArIHRoaXMuX3Nlc3Npb25OYW1lKSk7XHJcbiAgICAgICAgLy8gY29uc29sZS5sb2cobG9jYWxTdG9yYWdlKTtcclxuICAgICAgICAvLyBjb25zb2xlLmxvZygnc2Vzc2lvblN0b3JnZSA9ICcrd2luZG93LnNlc3Npb25TdG9yYWdlLmdldEl0ZW0odGhpcy5fc2Vzc2lvblByZWZpeCt0aGlzLl9zZXNzaW9uTmFtZSkpO1xyXG4gICAgICAgIGZvciAobGV0IGtleSBpbiB0aGlzLl9wYW5lc0RlZmF1bHRDb25maWcpIHtcclxuICAgICAgICAgICAgaWYgKHRoaXMuX3BhbmVzRGVmYXVsdENvbmZpZy5oYXNPd25Qcm9wZXJ0eShrZXkpKSB7XHJcbiAgICAgICAgICAgICAgICBsZXQgcGFuZTogS2RQYW5lID0gdGhpcy5fcGFuZXNbY291bnRdO1xyXG4gICAgICAgICAgICAgICAgbGV0IHBhbmVDb25maWc6IGFueSA9IHtcclxuICAgICAgICAgICAgICAgICAgICB3aWR0aDogKHRoaXMuX3BhbmVzRGVmYXVsdENvbmZpZ1trZXldLnNpemUgPiAxMDApID8gMTAwIDogdGhpcy5fcGFuZXNEZWZhdWx0Q29uZmlnW2tleV0uc2l6ZSxcclxuICAgICAgICAgICAgICAgIH07XHJcbiAgICAgICAgICAgICAgICBwYW5lQ29uZmlnW2RpcmVjdGlvbl0gPSBvZmZzZXRYO1xyXG5cclxuICAgICAgICAgICAgICAgIGlmIChpc01vYmlsZSkge1xyXG4gICAgICAgICAgICAgICAgICAgIHBhbmVDb25maWcgPSBPYmplY3QuYXNzaWduKHt9LCBwYW5lQ29uZmlnLCBtb2JpbGVDb25maWdba2V5XSk7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5faXNNZW51T3BlbiA9IGZhbHNlO1xyXG4gICAgICAgICAgICAgICAgICAgIGlmIChjb3VudCA9PT0gMCkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAvLyBjb25zb2xlLmxvZygnc2hvdyBidXR0b24nKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5fc2V0dXBGbG9hdE1lbnVCdG4ocGFuZSwgY291bnQpO1xyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAvLyBjb25zb2xlLmxvZyhcInRoaXMgaXMgbW9iaWxlIHZpZXdcIik7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgICAgICAgICBpZiAobG9jYWxTdG9yYWdlICE9PSBudWxsICYmIF91c2VMb2NhbFN0b3JhZ2UpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgbGV0IHRlbXBOYW1lOiBzdHJpbmcgPSAnUGFuZScgKyAoY291bnQgKyAxKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgcGFuZUNvbmZpZyA9IE9iamVjdC5hc3NpZ24oe30sIHBhbmVDb25maWcsIGxvY2FsU3RvcmFnZVt0ZW1wTmFtZV0pO1xyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAvLyBjb25zb2xlLmxvZyhwYW5lQ29uZmlnKTtcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLl9yZW1vdmVGbG9hdE1lbnVCdG4oKTtcclxuXHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5fZG9tRWxlbVN2Yy5yZW1vdmVDbGFzcyhwYW5lLmVsZW1lbnQubmF0aXZlRWxlbWVudCwgJ3B1c2gtY29udGVudC0nICsgb3BwRGlyZWN0aW9uKTtcclxuXHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKHRoaXMuX3NwbGl0dGVyTGV2ZWwgPT09ICdzdWInICYmIGNvdW50ID09PSAxICYmIHRoaXMuX2lzRmlyc3RTd2l0Y2hWaWV3UG9ydCkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBsZXQgaXNTdWJQYW5lU2hvdzogYm9vbGVhbiA9ICh0aGlzLl9wYW5lc0RlZmF1bHRDb25maWdba2V5XS5zaG93ICE9PSB1bmRlZmluZWQpID8gdGhpcy5fcGFuZXNEZWZhdWx0Q29uZmlnW2tleV0uc2hvdyA6IHRydWU7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuX3Byb2Nlc3NUb2dnbGVDb2xsYXBzZVN1YlBhbmUoaXNTdWJQYW5lU2hvdywgZmFsc2UpO1xyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgICAgICBmb3IgKGxldCBjS2V5IGluIHBhbmVDb25maWcpIHtcclxuICAgICAgICAgICAgICAgICAgICBpZiAocGFuZUNvbmZpZy5oYXNPd25Qcm9wZXJ0eShjS2V5KSkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLl9kb21FbGVtU3ZjLnNldEVsZW1lbnRTdHlsZShwYW5lLmVsZW1lbnQubmF0aXZlRWxlbWVudCwgY0tleSwgcGFuZUNvbmZpZ1tjS2V5XSArICclJyk7XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgY291bnQrKztcclxuICAgICAgICAgICAgICAgIG9mZnNldFggKz0gcGFuZUNvbmZpZy53aWR0aDtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF91cGRhdGVTcGxpdFBhbmVTaXplKF9wb3NYOiBudW1iZXIsIF9ib3VuZFNpemU6IG51bWJlcikge1xyXG4gICAgICAgIGlmICh0aGlzLl9kb21FbGVtU3ZjLmlzTW9iaWxlKCkpIHJldHVybjtcclxuICAgICAgICBpZiAoIXRoaXMuX2lzRHJhZykgcmV0dXJuO1xyXG5cclxuICAgICAgICBsZXQgZGlyZWN0aW9uOiBzdHJpbmcgPSB0aGlzLl9kb21FbGVtU3ZjLmdldERvY3VtZW50RGlyZWN0aW9uKHRydWUpO1xyXG4gICAgICAgIGxldCBkaW1lbnRpb246IHN0cmluZyA9ICh0aGlzLm9yaWVudGF0aW9uID09PSAndmVydGljYWwnKSA/ICdoZWlnaHQnIDogJ3dpZHRoJztcclxuICAgICAgICBsZXQgc2VsZWN0ZWRFbGVtQm91bmRzOiBhbnkgPSB0aGlzLl9zZWxlY3RlZEVsZW0uZ2V0Qm91bmRpbmdDbGllbnRSZWN0KCk7XHJcbiAgICAgICAgbGV0IHNlbGVjdGVkUHJldkVsZW1Cb3VuZHM6IGFueSA9IHRoaXMuX3NlbGVjdGVkUHJldlNpYmxpbmdFbGVtLmdldEJvdW5kaW5nQ2xpZW50UmVjdCgpO1xyXG5cclxuICAgICAgICBzZWxlY3RlZEVsZW1Cb3VuZHMgPSAodGhpcy5vcmllbnRhdGlvbiA9PT0gJ3ZlcnRpY2FsJykgPyBzZWxlY3RlZEVsZW1Cb3VuZHMuaGVpZ2h0IDogc2VsZWN0ZWRFbGVtQm91bmRzLndpZHRoO1xyXG4gICAgICAgIHNlbGVjdGVkUHJldkVsZW1Cb3VuZHMgPSAodGhpcy5vcmllbnRhdGlvbiA9PT0gJ3ZlcnRpY2FsJykgPyBzZWxlY3RlZFByZXZFbGVtQm91bmRzLmhlaWdodCA6IHNlbGVjdGVkUHJldkVsZW1Cb3VuZHMud2lkdGg7XHJcblxyXG4gICAgICAgIGxldCB0b3RhbDJFbGVtU2l6ZTogbnVtYmVyID0gTWF0aC5yb3VuZCh0aGlzLl9jb252ZXJ0aW9uU3ZjLmNvbnZlcnRQeFRvUGVyY2VudChzZWxlY3RlZFByZXZFbGVtQm91bmRzICsgc2VsZWN0ZWRFbGVtQm91bmRzLCBfYm91bmRTaXplKSk7XHJcblxyXG4gICAgICAgIGxldCBtb3ZlWDogbnVtYmVyID0gdGhpcy5fc3BsaXR0ZXJTdmMudmFsaWRhdGVQZXJjZW50VmFsdWUoX3Bvc1gpO1xyXG4gICAgICAgIHRvdGFsMkVsZW1TaXplID0gdGhpcy5fc3BsaXR0ZXJTdmMudmFsaWRhdGVQZXJjZW50VmFsdWUodG90YWwyRWxlbVNpemUpO1xyXG5cclxuICAgICAgICBsZXQgc2VsZWN0ZWRQcmV2UGFuZUtleTogc3RyaW5nID0gdGhpcy5fY29udmVydGlvblN2Yy5jYW1lbENhc2UodGhpcy5fc2VsZWN0ZWRQcmV2U2libGluZ0VsZW0uY2xhc3NMaXN0WzFdLCAnLScpO1xyXG4gICAgICAgIG1vdmVYID0gdGhpcy5fc3BsaXR0ZXJTdmMudmFsaWRhdGVQYW5lU2l6ZSh0aGlzLl9wYW5lc0RlZmF1bHRDb25maWcsIHNlbGVjdGVkUHJldlBhbmVLZXksIG1vdmVYKTtcclxuXHJcbiAgICAgICAgbGV0IGN1clBhbmU6IG51bWJlciA9IHRvdGFsMkVsZW1TaXplIC0gbW92ZVg7XHJcblxyXG4gICAgICAgIGxldCBzcGxpdHRlckZpbmFsQ29uZmlnOiBhbnkgPSB7XHJcbiAgICAgICAgICAgIFBhbmUxOiB7fSxcclxuICAgICAgICAgICAgUGFuZTI6IHt9XHJcbiAgICAgICAgfTtcclxuICAgICAgICBzcGxpdHRlckZpbmFsQ29uZmlnWydQYW5lMSddW2RpbWVudGlvbl0gPSBtb3ZlWDtcclxuICAgICAgICBzcGxpdHRlckZpbmFsQ29uZmlnWydQYW5lMiddW2RpcmVjdGlvbl0gPSBtb3ZlWDtcclxuICAgICAgICBzcGxpdHRlckZpbmFsQ29uZmlnWydQYW5lMiddW2RpbWVudGlvbl0gPSBjdXJQYW5lO1xyXG4gICAgICAgIHdpbmRvdy5zZXNzaW9uU3RvcmFnZS5zZXRJdGVtKHRoaXMuX3Nlc3Npb25QcmVmaXggKyB0aGlzLl9zZXNzaW9uTmFtZSwgSlNPTi5zdHJpbmdpZnkoc3BsaXR0ZXJGaW5hbENvbmZpZykpO1xyXG5cclxuICAgICAgICB0aGlzLl9kb21FbGVtU3ZjLnNldEVsZW1lbnRTdHlsZSh0aGlzLl9zZWxlY3RlZFByZXZTaWJsaW5nRWxlbSwgZGltZW50aW9uLCBtb3ZlWCArICclJyk7XHJcbiAgICAgICAgdGhpcy5fZG9tRWxlbVN2Yy5zZXRFbGVtZW50U3R5bGUodGhpcy5fc2VsZWN0ZWRFbGVtLCBkaXJlY3Rpb24sIG1vdmVYICsgJyUnKTtcclxuICAgICAgICB0aGlzLl9kb21FbGVtU3ZjLnNldEVsZW1lbnRTdHlsZSh0aGlzLl9zZWxlY3RlZEVsZW0sIGRpbWVudGlvbiwgY3VyUGFuZSArICclJyk7XHJcblxyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX3RvZ2dsZUNvbGxhcHNlTWVudShfcGFuZTogS2RQYW5lKSB7XHJcbiAgICAgICAgbGV0IGRpcmVjdGlvbjogc3RyaW5nID0gdGhpcy5fZG9tRWxlbVN2Yy5nZXREb2N1bWVudERpcmVjdGlvbih0cnVlKTtcclxuICAgICAgICB0aGlzLl9pc01haW5QYW5lQ29sbGFwc2UgPSAhdGhpcy5faXNNYWluUGFuZUNvbGxhcHNlO1xyXG5cclxuICAgICAgICB0aGlzLl9kb21FbGVtU3ZjLmFkZENsYXNzKF9wYW5lLmVsZW1lbnQubmF0aXZlRWxlbWVudCwgJ2FuaW1hdGlvbicpO1xyXG4gICAgICAgIHRoaXMuX2RvbUVsZW1TdmMuc2V0RWxlbWVudENsYXNzKF9wYW5lLmVsZW1lbnQubmF0aXZlRWxlbWVudCwgJ3B1c2gtY29udGVudC0nICsgZGlyZWN0aW9uLCB0aGlzLl9pc01haW5QYW5lQ29sbGFwc2UpO1xyXG4gICAgICAgIHRoaXMuX3NldENvbGxhcHNlSWNvbih0aGlzLl9pc01haW5QYW5lQ29sbGFwc2UpO1xyXG4gICAgICAgIHRoaXMuX3NwbGl0dGVyRXZlbnQudG9nZ2xlTWVudSgpO1xyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX3JlbW92ZUZsb2F0TWVudUJ0bigpOiB2b2lkIHtcclxuICAgICAgICB0aGlzLl9kb21FbGVtU3ZjLnJlbW92ZUVsZW1lbnRCeUNsYXNzKCcuZm0tYnRuJywgdGhpcy5lbC5uYXRpdmVFbGVtZW50KTtcclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF9zZXR1cEZsb2F0TWVudUJ0bihfcGFuZTogS2RQYW5lLCBfY291bnQ6IG51bWJlcik6IHZvaWQge1xyXG4gICAgICAgIGxldCBpc01vYmlsZTogYm9vbGVhbiA9IHRoaXMuX2RvbUVsZW1TdmMuaXNNb2JpbGUoKTtcclxuICAgICAgICBsZXQgZmxvYXRCdG46IEhUTUxFbGVtZW50ID0gdGhpcy5lbC5uYXRpdmVFbGVtZW50LnF1ZXJ5U2VsZWN0b3IoJy5mbS1idG4nKTtcclxuICAgICAgICBpZiAoaXNNb2JpbGUgJiYgdGhpcy5fc3BsaXR0ZXJMZXZlbCA9PT0gJ3N1YicgJiYgZmxvYXRCdG4gPT09IG51bGwgJiYgdGhpcy5fZW5hYmxlRmxvYXRCdG4pIHtcclxuICAgICAgICAgICAgLy8gY29uc29sZS5sb2coJ3N1YiBtYWluJyk7XHJcbiAgICAgICAgICAgIC8vIGxldCBjbGFzc05hbWVzOiBzdHJpbmcgPSAnZm1iLScgKyBfY291bnQ7XHJcbiAgICAgICAgICAgIGxldCBjbGFzc05hbWU6IHN0cmluZyA9ICdmbS1idG4nO1xyXG5cclxuICAgICAgICAgICAgbGV0IG5ld0J0bjogSFRNTEVsZW1lbnQgPSB0aGlzLl9kb21FbGVtU3ZjLmNyZWF0ZUVsZW1lbnQodGhpcy5lbC5uYXRpdmVFbGVtZW50LCAnYnRuIGJ0bi1mbG9hdC1ib3R0b20tcmlnaHQgYnRuLWNpcmNsZSBidG4tY29sb3IgJyArIGNsYXNzTmFtZSk7XHJcblxyXG4gICAgICAgICAgICAvLyAvL1NldHVwIGljb25cclxuICAgICAgICAgICAgSFRNTEVsZW1lbnQgPSB0aGlzLl9kb21FbGVtU3ZjLmNyZWF0ZUVsZW1lbnQobmV3QnRuLCAnZmEnLCAnaScpO1xyXG4gICAgICAgICAgICB0aGlzLl9zZXRGbG9hdEljb24odGhpcy5faXNTdWJQYW5lT3Blbik7XHJcblxyXG4gICAgICAgICAgICAvLyAvL3NldHVwIE9uTW91c2VEb3duRXZlbnRcclxuICAgICAgICAgICAgLy8gLy9zZXR1cCBPbk1vdXNlRG93bkV2ZW50XHJcbnRoaXMuX3JlbmRlcmVyLmxpc3RlbihuZXdCdG4sICdjbGljaycsIChldmVudDogYW55KTogdm9pZCA9PiB7XHJcbiAgICB0aGlzLl9pc1N1YlBhbmVPcGVuID0gIXRoaXMuX2lzU3ViUGFuZU9wZW47XHJcbiAgICB0aGlzLl9zcGxpdHRlckV2ZW50LnRvZ2dsZVN1YlBhbmUodGhpcy5faXNTdWJQYW5lT3Blbik7XHJcbn0pO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF90b2dnbGVDb2xsYXBzZVN1YlBhbmUoKSB7XHJcbiAgICAgICAgaWYgKHRoaXMuX3NwbGl0dGVyTGV2ZWwgPT09ICdzdWInKSB7XHJcbiAgICAgICAgICAgIHRoaXMuX3NwbGl0dGVyRXZlbnQub25Ub2dnbGVTdWJQYW5lKClcclxuICAgICAgICAgICAgICAgIC5zdWJzY3JpYmUoaXNTdWJQYW5lT3BlbiA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5fcHJvY2Vzc1RvZ2dsZUNvbGxhcHNlU3ViUGFuZShpc1N1YlBhbmVPcGVuKTtcclxuICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF9wcm9jZXNzVG9nZ2xlQ29sbGFwc2VTdWJQYW5lKGlzU3ViUGFuZU9wZW46IGJvb2xlYW4sIF9hbmltYXRlPzogYm9vbGVhbikge1xyXG4gICAgICAgIC8vIGNvbnNvbGUubG9nKCdpbiB0aGlzIGZ1bmN0aW9uPycpXHJcbiAgICAgICAgX2FuaW1hdGUgPSAodHlwZW9mIF9hbmltYXRlID09PSAndW5kZWZpbmVkJykgPyB0cnVlIDogX2FuaW1hdGU7XHJcbiAgICAgICAgbGV0IHJpZ2h0UGFuZTogSFRNTEVsZW1lbnQgPSB0aGlzLl9wYW5lc1sxXS5lbGVtZW50Lm5hdGl2ZUVsZW1lbnQ7XHJcbiAgICAgICAgbGV0IGxlZnRQYW5lOiBIVE1MRWxlbWVudCA9IHRoaXMuX3BhbmVzWzBdLmVsZW1lbnQubmF0aXZlRWxlbWVudDtcclxuICAgICAgICBsZXQgaXNNb2JpbGU6IGJvb2xlYW4gPSB0aGlzLl9kb21FbGVtU3ZjLmlzTW9iaWxlKCk7XHJcbiAgICAgICAgbGV0IGlzU2FtZVN0YXRlOiBib29sZWFuID0gKHRoaXMuX2lzU3ViUGFuZU9wZW4gPT09IGlzU3ViUGFuZU9wZW4pID8gdHJ1ZSA6IGZhbHNlO1xyXG4gICAgICAgIHRoaXMuX2lzU3ViUGFuZU9wZW4gPSBpc1N1YlBhbmVPcGVuO1xyXG4gICAgICAgIGlmIChfYW5pbWF0ZSkge1xyXG4gICAgICAgICAgICB0aGlzLl9kb21FbGVtU3ZjLmFkZENsYXNzKHJpZ2h0UGFuZSwgJ2FuaW1hdGlvbicpO1xyXG4gICAgICAgICAgICB0aGlzLl9kb21FbGVtU3ZjLmFkZENsYXNzKGxlZnRQYW5lLCAnYW5pbWF0aW9uJyk7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICBpZiAoaXNNb2JpbGUgfHwgdGhpcy5fZW5hYmxlU3ViUGFuZUNvbGxhcHNlKSB7XHJcbiAgICAgICAgICAgIC8vIGNvbnNvbGUubG9nKCdhbSBpIGluPycpO1xyXG4gICAgICAgICAgICBsZXQgYW5pbWF0ZURpcmVjdGlvbjogc3RyaW5nID0gKGlzTW9iaWxlKSA/ICdpbicgOiAnb3V0JztcclxuICAgICAgICAgICAgbGV0IGRpcmVjdGlvbjogc3RyaW5nID0gdGhpcy5fZG9tRWxlbVN2Yy5nZXREb2N1bWVudERpcmVjdGlvbih0cnVlKTtcclxuICAgICAgICAgICAgbGV0IG9wcERpcmVjdGlvbjogc3RyaW5nID0gKGRpcmVjdGlvbiA9PT0gJ2xlZnQnKSA/ICdyaWdodCcgOiAnbGVmdCc7XHJcbiAgICAgICAgICAgIGxldCBhZGRDbGFzczogYm9vbGVhbiA9IChpc01vYmlsZSkgPyBpc1N1YlBhbmVPcGVuIDogIWlzU3ViUGFuZU9wZW47XHJcblxyXG4gICAgICAgICAgICBsZXQgd2lkdGhDb25maWc6IEFycmF5PGFueT4gPSBbe31dO1xyXG4gICAgICAgICAgICBpZiAoYWRkQ2xhc3MpIHtcclxuICAgICAgICAgICAgICAgIHRoaXMuX3ByZXZXaWR0aFN0YXRlID0gbGVmdFBhbmUuZ2V0Qm91bmRpbmdDbGllbnRSZWN0KCkud2lkdGg7XHJcbiAgICAgICAgICAgICAgICB3aWR0aENvbmZpZyA9IFtcclxuICAgICAgICAgICAgICAgICAgICB7ICd3aWR0aCc6IHRoaXMuX3ByZXZXaWR0aFN0YXRlICsgJ3B4JyB9LFxyXG4gICAgICAgICAgICAgICAgICAgIHsgJ3dpZHRoJzogJzEwMCUnIH1cclxuICAgICAgICAgICAgICAgIF07XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgZWxzZSB7XHJcbiAgICAgICAgICAgICAgICB3aWR0aENvbmZpZyA9IFtcclxuICAgICAgICAgICAgICAgICAgICB7ICd3aWR0aCc6ICcxMDAlJyB9LFxyXG4gICAgICAgICAgICAgICAgICAgIHsgJ3dpZHRoJzogdGhpcy5fcHJldldpZHRoU3RhdGUgKyAncHgnIH1cclxuICAgICAgICAgICAgICAgIF07XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgdGhpcy5fc2V0RmxvYXRJY29uKGlzU3ViUGFuZU9wZW4pO1xyXG4gICAgICAgICAgICB0aGlzLl9kb21FbGVtU3ZjLnNldEVsZW1lbnRDbGFzcyhsZWZ0UGFuZSwgJ2Z1bGwtd2lkdGgnLCBhZGRDbGFzcyk7XHJcbiAgICAgICAgICAgIHRoaXMuX2RvbUVsZW1TdmMuc2V0RWxlbWVudENsYXNzKHJpZ2h0UGFuZSwgJ3B1c2gtc3ViY29udGVudC0nICsgb3BwRGlyZWN0aW9uICsgJy0nICsgYW5pbWF0ZURpcmVjdGlvbiwgYWRkQ2xhc3MpO1xyXG5cclxuICAgICAgICAgICAgaWYgKF9hbmltYXRlICYmICFpc1NhbWVTdGF0ZSkge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5fZG9tRWxlbVN2Yy5pbnZva2VFbGVtZW50TWV0aG9kKFxyXG4gICAgICAgICAgICAgICAgICAgIGxlZnRQYW5lLFxyXG4gICAgICAgICAgICAgICAgICAgICdhbmltYXRlJyxcclxuICAgICAgICAgICAgICAgICAgICBbd2lkdGhDb25maWcsIDUwMF1cclxuICAgICAgICAgICAgICAgICk7XHJcblxyXG4gICAgICAgICAgICAgICAgdGltZXIoNTAwKS5zdWJzY3JpYmUoKCk6IHZvaWQgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgIC8vIG5lZWQgZml4aW5nIGluIHRoZSBmdXR1cmUuIHRoaXMgZXZlbnQgaXMgYmVpbmcgdHJpZ2dlcmVkIHR3aWNlLiBhbm90aGVyIHRpbWUgaXMgaW4ga2QtZXhhbXBsZVxyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuX3NwbGl0dGVyRXZlbnQudG9nZ2xlU3ViUGFuZShpc1N1YlBhbmVPcGVuKTtcclxuICAgICAgICAgICAgICAgICAgICAvLyB0aGlzLl9zcGxpdHRlckV2ZW50LnRvZ2dsZUFuaW1hdGlvblN1YlBhbmVFbmQoaXNTdWJQYW5lT3Blbik7XHJcbiAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF9zZXRGbG9hdEljb24oX2lzT3BlbjogYm9vbGVhbikge1xyXG4gICAgICAgIGxldCBidG5JY29uOiBIVE1MRWxlbWVudCA9IHRoaXMuZWwubmF0aXZlRWxlbWVudC5xdWVyeVNlbGVjdG9yKCcuZm0tYnRuIGknKTtcclxuICAgICAgICBpZiAodGhpcy5fc3BsaXR0ZXJMZXZlbCA9PT0gJ3N1YicgJiYgYnRuSWNvbiAhPT0gbnVsbCkge1xyXG4gICAgICAgICAgICB0aGlzLl9kb21FbGVtU3ZjLnNldEVsZW1lbnRDbGFzcyhidG5JY29uLCAna2QtbGlzdHMnLCAhX2lzT3Blbik7XHJcbiAgICAgICAgICAgIHRoaXMuX2RvbUVsZW1TdmMuc2V0RWxlbWVudENsYXNzKGJ0bkljb24sICdrZC1jbG9zZS1yb3VuZCcsIF9pc09wZW4pO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF9zZXRDb2xsYXBzZUljb24oX2lzT3BlbjogYm9vbGVhbikge1xyXG4gICAgICAgIGxldCBkaXJlY3Rpb246IHN0cmluZyA9IHRoaXMuX2RvbUVsZW1TdmMuZ2V0RG9jdW1lbnREaXJlY3Rpb24odHJ1ZSk7XHJcbiAgICAgICAgbGV0IG9wcERpcmVjdGlvbjogc3RyaW5nID0gKGRpcmVjdGlvbiA9PT0gJ2xlZnQnKSA/ICdyaWdodCcgOiAnbGVmdCc7XHJcbiAgICAgICAgbGV0IGJ0bkljb246IEhUTUxFbGVtZW50ID0gdGhpcy5lbC5uYXRpdmVFbGVtZW50LnF1ZXJ5U2VsZWN0b3IoJy5tZW51LWJ0biBpJyk7XHJcblxyXG4gICAgICAgIGlmICh0aGlzLl9zcGxpdHRlckxldmVsID09PSAnbWFpbicgJiYgYnRuSWNvbiAhPT0gbnVsbCkge1xyXG4gICAgICAgICAgICB0aGlzLl9kb21FbGVtU3ZjLnNldEVsZW1lbnRDbGFzcyhidG5JY29uLCAnZmEtYW5nbGUtJyArIGRpcmVjdGlvbiwgIV9pc09wZW4pO1xyXG4gICAgICAgICAgICB0aGlzLl9kb21FbGVtU3ZjLnNldEVsZW1lbnRDbGFzcyhidG5JY29uLCAnZmEtYW5nbGUtJyArIG9wcERpcmVjdGlvbiwgX2lzT3Blbik7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX3NldFRpbnQoX2FkZDogYm9vbGVhbikge1xyXG4gICAgICAgIGxldCBpc01vYmlsZTogYm9vbGVhbiA9IHRoaXMuX2RvbUVsZW1TdmMuaXNNb2JpbGUoKTtcclxuICAgICAgICBsZXQgb3ZlcmxheURpdjogSFRNTEVsZW1lbnQgPSB0aGlzLl9wYW5lc1sxXS5lbGVtZW50Lm5hdGl2ZUVsZW1lbnQucXVlcnlTZWxlY3RvcignLmNvbnRlbnQtb3ZlcmxheScpO1xyXG4gICAgICAgIGlmIChvdmVybGF5RGl2ID09PSBudWxsKSB7XHJcbiAgICAgICAgICAgIG92ZXJsYXlEaXYgPSB0aGlzLl9kb21FbGVtU3ZjLmNyZWF0ZUVsZW1lbnQodGhpcy5fcGFuZXNbMV0uZWxlbWVudC5uYXRpdmVFbGVtZW50LCAnY29udGVudC1vdmVybGF5Jyk7XHJcblxyXG4gICAgICAgICAgICB0aGlzLl9yZW5kZXJlci5saXN0ZW4ob3ZlcmxheURpdiwgJ2NsaWNrJywgKGV2ZW50OiBhbnkpOiB2b2lkID0+IHtcclxuICAgIHRoaXMuX3NwbGl0dGVyRXZlbnQuZmlyZSgpO1xyXG59KTtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIGlmIChpc01vYmlsZSkge1xyXG4gICAgICAgICAgICB0aGlzLl9kb21FbGVtU3ZjLnNldEVsZW1lbnRDbGFzcyhvdmVybGF5RGl2LCAnc2hvdycsIF9hZGQpO1xyXG4gICAgICAgICAgICBpZiAodGhpcy5fc3BsaXR0ZXJMZXZlbCA9PT0gJ21haW4nKSB7XHJcbiAgICAgICAgICAgICAgICBsZXQgY29udGVudEFyZWEgPSB0aGlzLl9wYW5lc1sxXS5lbGVtZW50Lm5hdGl2ZUVsZW1lbnQucXVlcnlTZWxlY3RvcignLm1haW4td3JhcHBlcicpO1xyXG4gICAgICAgICAgICAgICAgLy8gY29uc29sZS5sb2coY29udGVudEFyZWEpO1xyXG4gICAgICAgICAgICAgICAgaWYgKGNvbnRlbnRBcmVhKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgbGV0IGNvbnRlbnRBcmVhSGVpZ2h0ID0gY29udGVudEFyZWEuZ2V0Qm91bmRpbmdDbGllbnRSZWN0KCkuaGVpZ2h0O1xyXG4gICAgICAgICAgICAgICAgICAgIGxldCBwYW5lSGVpZ2h0OiBudW1iZXIgPSB0aGlzLl9wYW5lc1sxXS5lbGVtZW50Lm5hdGl2ZUVsZW1lbnQuZ2V0Qm91bmRpbmdDbGllbnRSZWN0KCkuaGVpZ2h0O1xyXG4gICAgICAgICAgICAgICAgICAgIC8vIGNvbnNvbGUubG9nKHBhbmVIZWlnaHQpO1xyXG4gICAgICAgICAgICAgICAgICAgIC8vIGNvbnNvbGUubG9nKGNvbnRlbnRBcmVhSGVpZ2h0KTtcclxuICAgICAgICAgICAgICAgICAgICBpZiAoY29udGVudEFyZWFIZWlnaHQgPiBwYW5lSGVpZ2h0KSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuX2RvbUVsZW1TdmMuc2V0RWxlbWVudFN0eWxlKG92ZXJsYXlEaXYsICdib3R0b20nLCAnYXV0bycpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLl9kb21FbGVtU3ZjLnNldEVsZW1lbnRTdHlsZShvdmVybGF5RGl2LCAnaGVpZ2h0JywgY29udGVudEFyZWFIZWlnaHQgKyAncHgnKTtcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICB0aGlzLl9kb21FbGVtU3ZjLnNldEVsZW1lbnRDbGFzcyh0aGlzLl9wYW5lc1sxXS5lbGVtZW50Lm5hdGl2ZUVsZW1lbnQsICduby1vdmVyZmxvdycsIF9hZGQpO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX29uRHJhZyhldmVudDogYW55KTogdm9pZCB7XHJcbiAgICAgICAgaWYgKHRoaXMuX2Rpc2FibGVEcmFnKSByZXR1cm47XHJcbiAgICAgICAgaWYgKCF0aGlzLl9pc0RyYWcpIHJldHVybjtcclxuXHJcbiAgICAgICAgbGV0IGRpcmVjdGlvbjogc3RyaW5nID0gdGhpcy5fZG9tRWxlbVN2Yy5nZXREb2N1bWVudERpcmVjdGlvbih0cnVlKTtcclxuICAgICAgICAvLyBsZXQgc2VsZWN0ZWRQYW5lQm91bmRzOiBhbnkgPSB0aGlzLl9zZWxlY3RlZEVsZW0uZ2V0Qm91bmRpbmdDbGllbnRSZWN0KCk7XHJcbiAgICAgICAgbGV0IHNwbGl0dGVyQm91bmRzOiBhbnkgPSB0aGlzLmVsLm5hdGl2ZUVsZW1lbnQuZ2V0Qm91bmRpbmdDbGllbnRSZWN0KCk7XHJcblxyXG4gICAgICAgIGxldCBtb3ZlWCA9IE1hdGguYWJzKGV2ZW50LmNsaWVudFggLSBzcGxpdHRlckJvdW5kc1tkaXJlY3Rpb25dKTtcclxuICAgICAgICAvLyBjb25zb2xlLmxvZyhtb3ZlWCk7XHJcbiAgICAgICAgLy8gbGV0IG5ld1dpZHRoOiBudW1iZXIgPSBzZWxlY3RlZFBhbmVCb3VuZHMud2lkdGggLSBtb3ZlWDtcclxuICAgICAgICAvLyBjb25zb2xlLmxvZyhuZXdXaWR0aCk7XHJcbiAgICAgICAgbGV0IG5ld1NpemUgPSB0aGlzLl9jb252ZXJ0aW9uU3ZjLmNvbnZlcnRQeFRvUGVyY2VudChtb3ZlWCwgc3BsaXR0ZXJCb3VuZHMud2lkdGgpO1xyXG4gICAgICAgIC8vIGNvbnNvbGUubG9nKCduZXdTaXplID0gJytuZXdTaXplKTtcclxuXHJcbiAgICAgICAgdGhpcy5fZG9tRWxlbVN2Yy5yZW1vdmVDbGFzcyh0aGlzLl9zZWxlY3RlZEVsZW0sICdhbmltYXRpb24nKTtcclxuICAgICAgICB0aGlzLl91cGRhdGVTcGxpdFBhbmVTaXplKG5ld1NpemUsIHNwbGl0dGVyQm91bmRzLndpZHRoKTtcclxuICAgICAgICB0aGlzLl9zcGxpdHRlckV2ZW50LmRyYWcodGhpcy5fc3BsaXR0ZXJMZXZlbCk7XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfb25SZXNpemUoZXZlbnQ6IGFueSk6IHZvaWQge1xyXG4gICAgICAgIGxldCBpc01vYmlsZTogYm9vbGVhbiA9IHRoaXMuX2RvbUVsZW1TdmMuaXNNb2JpbGUoKTtcclxuICAgICAgICBpZiAoaXNNb2JpbGUgIT09IHRoaXMuX3ByZXZJc01vYmlsZSkge1xyXG4gICAgICAgICAgICB0aGlzLl9pc0ZpcnN0U3dpdGNoVmlld1BvcnQgPSB0cnVlO1xyXG4gICAgICAgICAgICB0aGlzLl9wcmV2SXNNb2JpbGUgPSBpc01vYmlsZTtcclxuICAgICAgICAgICAgdGhpcy5faXNTdWJQYW5lT3BlbiA9IGZhbHNlO1xyXG4gICAgICAgIH1cclxuICAgICAgICB0aGlzLl9zZXREZWZhdWx0UGFuZVNpemUoKTtcclxuICAgICAgICB0aGlzLl9pc0ZpcnN0U3dpdGNoVmlld1BvcnQgPSBmYWxzZTtcclxuICAgIH1cclxufVxyXG4iXX0=