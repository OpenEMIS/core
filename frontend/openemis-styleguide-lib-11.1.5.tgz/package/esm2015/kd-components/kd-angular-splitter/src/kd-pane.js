import { Component, HostBinding, ViewContainerRef, Input } from '@angular/core';
import { KdSplitter } from './kd-splitter';
export class KdPane {
    constructor(splitterContainer, _vcr) {
        this.splitterContainer = splitterContainer;
        this._vcr = _vcr;
        // @Input() size: String;
        this.classes = 'pane';
        this.index = this.splitterContainer.addGroup(this);
        this.classes += ' pane-' + this.index;
        this.element = this._vcr.element;
        let elemAttr = this._vcr.element.nativeElement.attributes;
        let elemAttrKeys = Object.keys(this._vcr.element.nativeElement.attributes);
        // console.log(elemAttr);
        // for(let i: number = 0; i < elemAttr.length; i++){
        //     console.log(elemAttr[i]);
        // }
        elemAttrKeys.forEach((key) => {
            this[elemAttr[key].name] = elemAttr[key].value;
            if (this.index < 1 && key === 'hidden') {
                delete this[elemAttr[key].name];
            }
        });
    }
    ngOnChanges(_simpleChanges) {
        if (_simpleChanges.hasOwnProperty('size') && !_simpleChanges['size'].firstChange) {
            this.splitterContainer.paneOnChange('size');
        }
        if (_simpleChanges.hasOwnProperty('max') && !_simpleChanges['max'].firstChange) {
            this.splitterContainer.paneOnChange('max');
        }
        if (_simpleChanges.hasOwnProperty('min') && !_simpleChanges['min'].firstChange) {
            this.splitterContainer.paneOnChange('min');
        }
    }
    ngAfterViewInit() {
        // console.log('on after view init');
        //        console.log(this.childrenSplitter);
    }
}
KdPane.decorators = [
    { type: Component, args: [{
                selector: 'kd-pane',
                // template: `<div *ngIf='index > 1' class='splitter-handler sh-{{index}}'></div>
                //           <ng-content></ng-content>`,
                template: `<ng-content></ng-content>`
            },] }
];
KdPane.ctorParameters = () => [
    { type: KdSplitter },
    { type: ViewContainerRef }
];
KdPane.propDecorators = {
    classes: [{ type: HostBinding, args: ['class',] }],
    size: [{ type: Input }],
    max: [{ type: Input }],
    min: [{ type: Input }],
    show: [{ type: Input }]
};
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoia2QtcGFuZS5qcyIsInNvdXJjZVJvb3QiOiJDOi94YW1wcC9odGRvY3MvU3R5bGVndWlkZS9pb3N0Zy1vcGVuZW1pcy1zdHlsZWd1aWRlL3Byb2plY3RzL29wZW5lbWlzLXN0eWxlZ3VpZGUtbGliL3NyYy8iLCJzb3VyY2VzIjpbImtkLWNvbXBvbmVudHMva2QtYW5ndWxhci1zcGxpdHRlci9zcmMva2QtcGFuZS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQSxPQUFPLEVBQ0gsU0FBUyxFQUNULFdBQVcsRUFDWCxnQkFBZ0IsRUFPaEIsS0FBSyxFQUNSLE1BQU0sZUFBZSxDQUFDO0FBRXZCLE9BQU8sRUFBRSxVQUFVLEVBQUUsTUFBTSxlQUFlLENBQUM7QUFVM0MsTUFBTSxPQUFPLE1BQU07SUFlZixZQUFvQixpQkFBNkIsRUFBVSxJQUFzQjtRQUE3RCxzQkFBaUIsR0FBakIsaUJBQWlCLENBQVk7UUFBVSxTQUFJLEdBQUosSUFBSSxDQUFrQjtRQWRqRix5QkFBeUI7UUFDSCxZQUFPLEdBQUcsTUFBTSxDQUFDO1FBY25DLElBQUksQ0FBQyxLQUFLLEdBQUcsSUFBSSxDQUFDLGlCQUFpQixDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsQ0FBQztRQUNuRCxJQUFJLENBQUMsT0FBTyxJQUFJLFFBQVEsR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDO1FBQ3RDLElBQUksQ0FBQyxPQUFPLEdBQUcsSUFBSSxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUM7UUFFakMsSUFBSSxRQUFRLEdBQUcsSUFBSSxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsYUFBYSxDQUFDLFVBQVUsQ0FBQztRQUMxRCxJQUFJLFlBQVksR0FBRyxNQUFNLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLGFBQWEsQ0FBQyxVQUFVLENBQUMsQ0FBQztRQUMzRSx5QkFBeUI7UUFDekIsb0RBQW9EO1FBQ3BELGdDQUFnQztRQUNoQyxJQUFJO1FBRUosWUFBWSxDQUFDLE9BQU8sQ0FBQyxDQUFDLEdBQVEsRUFBUSxFQUFFO1lBQ3BDLElBQUksQ0FBQyxRQUFRLENBQUMsR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDLEdBQUcsUUFBUSxDQUFDLEdBQUcsQ0FBQyxDQUFDLEtBQUssQ0FBQztZQUMvQyxJQUFJLElBQUksQ0FBQyxLQUFLLEdBQUcsQ0FBQyxJQUFJLEdBQUcsS0FBSyxRQUFRLEVBQUU7Z0JBQ3BDLE9BQU8sSUFBSSxDQUFDLFFBQVEsQ0FBQyxHQUFHLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQzthQUNuQztRQUNMLENBQUMsQ0FBQyxDQUFDO0lBQ1AsQ0FBQztJQUVELFdBQVcsQ0FBQyxjQUE2QjtRQUNyQyxJQUFJLGNBQWMsQ0FBQyxjQUFjLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxjQUFjLENBQUMsTUFBTSxDQUFDLENBQUMsV0FBVyxFQUFFO1lBQzlFLElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxZQUFZLENBQUMsTUFBTSxDQUFDLENBQUM7U0FDL0M7UUFDRCxJQUFJLGNBQWMsQ0FBQyxjQUFjLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxjQUFjLENBQUMsS0FBSyxDQUFDLENBQUMsV0FBVyxFQUFFO1lBQzVFLElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxZQUFZLENBQUMsS0FBSyxDQUFDLENBQUM7U0FDOUM7UUFDRCxJQUFJLGNBQWMsQ0FBQyxjQUFjLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxjQUFjLENBQUMsS0FBSyxDQUFDLENBQUMsV0FBVyxFQUFFO1lBQzVFLElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxZQUFZLENBQUMsS0FBSyxDQUFDLENBQUM7U0FDOUM7SUFDTCxDQUFDO0lBRUQsZUFBZTtRQUNYLHFDQUFxQztRQUNyQyw2Q0FBNkM7SUFFakQsQ0FBQzs7O1lBMURKLFNBQVMsU0FBQztnQkFDUCxRQUFRLEVBQUUsU0FBUztnQkFDbkIsaUZBQWlGO2dCQUNqRix3Q0FBd0M7Z0JBQ3hDLFFBQVEsRUFBRSwyQkFBMkI7YUFDeEM7OztZQVJRLFVBQVU7WUFWZixnQkFBZ0I7OztzQkFzQmYsV0FBVyxTQUFDLE9BQU87bUJBSW5CLEtBQUs7a0JBQ0wsS0FBSztrQkFDTCxLQUFLO21CQUNMLEtBQUsiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQge1xyXG4gICAgQ29tcG9uZW50LFxyXG4gICAgSG9zdEJpbmRpbmcsXHJcbiAgICBWaWV3Q29udGFpbmVyUmVmLFxyXG4gICAgRWxlbWVudFJlZixcclxuICAgIC8vIENvbnRlbnRDaGlsZHJlbixcclxuICAgIC8vIFF1ZXJ5TGlzdCxcclxuICAgIEFmdGVyVmlld0luaXQsXHJcbiAgICBPbkNoYW5nZXMsXHJcbiAgICBTaW1wbGVDaGFuZ2VzLFxyXG4gICAgSW5wdXRcclxufSBmcm9tICdAYW5ndWxhci9jb3JlJztcclxuXHJcbmltcG9ydCB7IEtkU3BsaXR0ZXIgfSBmcm9tICcuL2tkLXNwbGl0dGVyJztcclxuXHJcblxyXG5AQ29tcG9uZW50KHtcclxuICAgIHNlbGVjdG9yOiAna2QtcGFuZScsXHJcbiAgICAvLyB0ZW1wbGF0ZTogYDxkaXYgKm5nSWY9J2luZGV4ID4gMScgY2xhc3M9J3NwbGl0dGVyLWhhbmRsZXIgc2gte3tpbmRleH19Jz48L2Rpdj5cclxuICAgIC8vICAgICAgICAgICA8bmctY29udGVudD48L25nLWNvbnRlbnQ+YCxcclxuICAgIHRlbXBsYXRlOiBgPG5nLWNvbnRlbnQ+PC9uZy1jb250ZW50PmAsXHJcbn0pXHJcblxyXG5leHBvcnQgY2xhc3MgS2RQYW5lIGltcGxlbWVudHMgT25DaGFuZ2VzLCBBZnRlclZpZXdJbml0IHtcclxuICAgIC8vIEBJbnB1dCgpIHNpemU6IFN0cmluZztcclxuICAgIEBIb3N0QmluZGluZygnY2xhc3MnKSBjbGFzc2VzID0gJ3BhbmUnO1xyXG4gICAgLy8gQENvbnRlbnRDaGlsZHJlbihLZFNwbGl0dGVyKSBjaGlsZHJlblNwbGl0dGVyOiBRdWVyeUxpc3Q8S2RTcGxpdHRlcj47XHJcblxyXG4gICAgaW5kZXg6IG51bWJlcjtcclxuICAgIEBJbnB1dCgpIHNpemU6IHN0cmluZztcclxuICAgIEBJbnB1dCgpIG1heDogc3RyaW5nO1xyXG4gICAgQElucHV0KCkgbWluOiBzdHJpbmc7XHJcbiAgICBASW5wdXQoKSBzaG93OiBzdHJpbmc7XHJcbiAgICAvLyAgICAgc2l6ZTogc3RyaW5nO1xyXG4gICAgLy8gbWF4OiBzdHJpbmc7XHJcbiAgICAvLyBtaW46IHN0cmluZztcclxuICAgIGhpZGRlbjogYm9vbGVhbjtcclxuICAgIGVsZW1lbnQ6IEVsZW1lbnRSZWY7XHJcbiAgICBjb25zdHJ1Y3Rvcihwcml2YXRlIHNwbGl0dGVyQ29udGFpbmVyOiBLZFNwbGl0dGVyLCBwcml2YXRlIF92Y3I6IFZpZXdDb250YWluZXJSZWYpIHtcclxuICAgICAgICB0aGlzLmluZGV4ID0gdGhpcy5zcGxpdHRlckNvbnRhaW5lci5hZGRHcm91cCh0aGlzKTtcclxuICAgICAgICB0aGlzLmNsYXNzZXMgKz0gJyBwYW5lLScgKyB0aGlzLmluZGV4O1xyXG4gICAgICAgIHRoaXMuZWxlbWVudCA9IHRoaXMuX3Zjci5lbGVtZW50O1xyXG5cclxuICAgICAgICBsZXQgZWxlbUF0dHIgPSB0aGlzLl92Y3IuZWxlbWVudC5uYXRpdmVFbGVtZW50LmF0dHJpYnV0ZXM7XHJcbiAgICAgICAgbGV0IGVsZW1BdHRyS2V5cyA9IE9iamVjdC5rZXlzKHRoaXMuX3Zjci5lbGVtZW50Lm5hdGl2ZUVsZW1lbnQuYXR0cmlidXRlcyk7XHJcbiAgICAgICAgLy8gY29uc29sZS5sb2coZWxlbUF0dHIpO1xyXG4gICAgICAgIC8vIGZvcihsZXQgaTogbnVtYmVyID0gMDsgaSA8IGVsZW1BdHRyLmxlbmd0aDsgaSsrKXtcclxuICAgICAgICAvLyAgICAgY29uc29sZS5sb2coZWxlbUF0dHJbaV0pO1xyXG4gICAgICAgIC8vIH1cclxuXHJcbiAgICAgICAgZWxlbUF0dHJLZXlzLmZvckVhY2goKGtleTogYW55KTogdm9pZCA9PiB7XHJcbiAgICAgICAgICAgIHRoaXNbZWxlbUF0dHJba2V5XS5uYW1lXSA9IGVsZW1BdHRyW2tleV0udmFsdWU7XHJcbiAgICAgICAgICAgIGlmICh0aGlzLmluZGV4IDwgMSAmJiBrZXkgPT09ICdoaWRkZW4nKSB7XHJcbiAgICAgICAgICAgICAgICBkZWxldGUgdGhpc1tlbGVtQXR0cltrZXldLm5hbWVdO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfSk7XHJcbiAgICB9XHJcblxyXG4gICAgbmdPbkNoYW5nZXMoX3NpbXBsZUNoYW5nZXM6IFNpbXBsZUNoYW5nZXMpIHtcclxuICAgICAgICBpZiAoX3NpbXBsZUNoYW5nZXMuaGFzT3duUHJvcGVydHkoJ3NpemUnKSAmJiAhX3NpbXBsZUNoYW5nZXNbJ3NpemUnXS5maXJzdENoYW5nZSkge1xyXG4gICAgICAgICAgICB0aGlzLnNwbGl0dGVyQ29udGFpbmVyLnBhbmVPbkNoYW5nZSgnc2l6ZScpO1xyXG4gICAgICAgIH1cclxuICAgICAgICBpZiAoX3NpbXBsZUNoYW5nZXMuaGFzT3duUHJvcGVydHkoJ21heCcpICYmICFfc2ltcGxlQ2hhbmdlc1snbWF4J10uZmlyc3RDaGFuZ2UpIHtcclxuICAgICAgICAgICAgdGhpcy5zcGxpdHRlckNvbnRhaW5lci5wYW5lT25DaGFuZ2UoJ21heCcpO1xyXG4gICAgICAgIH1cclxuICAgICAgICBpZiAoX3NpbXBsZUNoYW5nZXMuaGFzT3duUHJvcGVydHkoJ21pbicpICYmICFfc2ltcGxlQ2hhbmdlc1snbWluJ10uZmlyc3RDaGFuZ2UpIHtcclxuICAgICAgICAgICAgdGhpcy5zcGxpdHRlckNvbnRhaW5lci5wYW5lT25DaGFuZ2UoJ21pbicpO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICBuZ0FmdGVyVmlld0luaXQoKTogdm9pZCB7XHJcbiAgICAgICAgLy8gY29uc29sZS5sb2coJ29uIGFmdGVyIHZpZXcgaW5pdCcpO1xyXG4gICAgICAgIC8vICAgICAgICBjb25zb2xlLmxvZyh0aGlzLmNoaWxkcmVuU3BsaXR0ZXIpO1xyXG5cclxuICAgIH1cclxufVxyXG4iXX0=