import { Component } from '@angular/core';
import { KdIntTableEvent } from '../kd-angular-table-event';
export class KdTableInput {
    constructor(_kdIntTableEvent) {
        this._kdIntTableEvent = _kdIntTableEvent;
        this.inputData = [];
        this._subscriptionObj = {};
        this._firstRun = true;
        this.DELIMITER = '~';
    }
    /********************* Component Life cycles functions *************************/
    agInit(_params) {
        // console.log('_params here - ', _params);
        this._params = _params;
        this._cellNode = _params.node;
        this._gridApi = _params.api;
        this._gridInputContext = _params.context[this._params.params.contextKey];
        this._contextKey = this._generateContextKey(this._params.params.gridId, this._params.colDef.colId, this._cellNode.id);
        this._updateTooltipDirection();
        this._processInputData(this._gridInputContext[this._contextKey]);
    }
    ngAfterViewInit() {
        this._firstRun = false;
    }
    refresh() {
        return false;
    }
    ngOnDestroy() {
        for (let item in this._subscriptionObj) {
            if (this._subscriptionObj.hasOwnProperty(item)) {
                this._subscriptionObj[item].unsubscribe();
            }
        }
    }
    /*********************** Component template functions **************************/
    valueUpdate(_question, _value) {
        if (this._firstRun)
            return;
        if (typeof _value !== 'undefined') {
            _question.value = _value;
        }
        this._updateContextValue(_question);
        this._updateCellNodeValue(_question);
        let broadcastParams = {
            colId: this._params.colDef.colId,
            rowId: this._cellNode.id,
            questionKey: _question.key,
            question: _question,
            data: _question.value
        };
        this._broadcastQuestionChange(broadcastParams);
    }
    /************************* Input question functions ****************************/
    _processInputData(_data) {
        for (let item in _data) {
            if (_data.hasOwnProperty(item)) {
                this.inputData.push(_data[item]);
            }
        }
    }
    _updateCellNodeValue(_question) {
        this._cellNode.data[this._params.colDef.colId][_question.key] = _question.value;
    }
    _updateContextValue(_question) {
        this._gridInputContext[this._contextKey][_question.key]['value'] = _question.value;
    }
    /*********************** Private broadcast functions ***************************/
    _broadcastQuestionChange(_broadcastParams) {
        this._kdIntTableEvent.inputChanged(this._params.params.gridId, _broadcastParams);
    }
    /***************************** Misc functions **********************************/
    _generateContextKey(_gridId, _colId, _rowId) {
        return _gridId + this.DELIMITER + _colId + this.DELIMITER + _rowId;
    }
    _updateTooltipDirection() {
        let htmlEle = document.querySelector('html');
        if (htmlEle !== null && htmlEle['dir'] !== '' && htmlEle['dir'] === 'rtl') {
            this.tooltipDirection = 'left';
        }
        else {
            this.tooltipDirection = 'right';
        }
    }
}
KdTableInput.decorators = [
    { type: Component, args: [{
                selector: 'kd-table-input',
                template: `
        <ng-template ngFor let-item [ngForOf]='inputData'>
            <div *ngIf='item.visible' class='kdx table-input-wrapper'>
                <div [ngSwitch]='item.controlType'>

                    <input *ngSwitchCase="'text'"
                        type='text'
                        [id]='item.key'
                        [placeholder]='item.placeholder ? item.placeholder : ""'
                        [(ngModel)]='item.value'
                        (ngModelChange)='valueUpdate(item)'
                    />

                    <input *ngSwitchCase="'number'"
                        type='number'
                        [id]='item.key'
                        [min]='item.min'
                        [max]='item.max'
                        [step]='item.step'
                        [placeholder]='item.placeholder ? item.placeholder : ""'
                        [(ngModel)]='item.value'
                        (ngModelChange)='valueUpdate(item)'
                    />

                    <textarea *ngSwitchCase="'textarea'"
                        [id]='item.key'
                        [placeholder]='item.placeholder ? item.placeholder : ""'
                        [(ngModel)]='item.value'
                        (ngModelChange)='valueUpdate(item)'
                    ></textarea>

                    <div *ngSwitchCase="'dropdown'" class='kdx-input-select-wrapper'>
                        <select
                            [id]='item.key'
                            [(ngModel)]='item.value'
                            (ngModelChange)='valueUpdate(item)'
                        >
                            <option *ngFor='let option of item.options' [value]='option.key'>
                                {{option.value}}
                            </option>
                        </select>
                    </div>

                    <kd-datepicker *ngSwitchCase="'date'"
                        [id]="item.key"
                        [config]='item.config'
                        [inputVal]='item.value'
                        [minDate]='item.minDate'
                        [maxDate]='item.maxDate'
                        (dateConfig)='valueUpdate(item, $event)'
                    ></kd-datepicker>

                    <kd-timepicker *ngSwitchCase="'time'"
                        [id]='item.key'
                        [config]='item.config'
                        [inputVal]='item.value'
                        (timeConfig)='valueUpdate(item, $event)'
                    ></kd-timepicker>

                    <kd-slider *ngSwitchCase="'slider'"
                        [id]='item.key'
                        [config]='item.config'
                        [value]='item.value'
                        [api]='item.api'
                        (result)='valueUpdate(item, $event)'
                    ></kd-slider>

                </div>

                <kd-tooltip
                    *ngIf='item.errors && item.errors.length > 0'
                    [config]="{ type: 'error', placement: tooltipDirection, description: item.errors }"
                ></kd-tooltip>
            </div>
        </ng-template>
    `,
                host: { 'class': 'kdx-table-input' }
            },] }
];
KdTableInput.ctorParameters = () => [
    { type: KdIntTableEvent }
];
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoia2QtdGFibGUtaW5wdXQuanMiLCJzb3VyY2VSb290IjoiRDovb3BlbkVNSVMvc3R5bGVndWlkZS9pb3N0Zy1vcGVuZW1pcy1zdHlsZWd1aWRlL3Byb2plY3RzL29wZW5lbWlzLXN0eWxlZ3VpZGUtbGliL3NyYy8iLCJzb3VyY2VzIjpbImtkLWNvbXBvbmVudHMva2QtYW5ndWxhci10YWJsZS90YWJsZS1jb21wb25lbnRzL2tkLXRhYmxlLWlucHV0LnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBLE9BQU8sRUFBRSxTQUFTLEVBQTRCLE1BQU0sZUFBZSxDQUFDO0FBSXBFLE9BQU8sRUFBRSxlQUFlLEVBQUUsTUFBTSwyQkFBMkIsQ0FBQztBQXNHNUQsTUFBTSxPQUFPLFlBQVk7SUFjckIsWUFDWSxnQkFBaUM7UUFBakMscUJBQWdCLEdBQWhCLGdCQUFnQixDQUFpQjtRQWR0QyxjQUFTLEdBQXVCLEVBQUUsQ0FBQztRQVFsQyxxQkFBZ0IsR0FBa0MsRUFBRSxDQUFDO1FBQ3JELGNBQVMsR0FBWSxJQUFJLENBQUM7UUFFekIsY0FBUyxHQUFXLEdBQUcsQ0FBQztJQUk5QixDQUFDO0lBRUosaUZBQWlGO0lBQzFFLE1BQU0sQ0FBQyxPQUE0QjtRQUN0QywyQ0FBMkM7UUFDM0MsSUFBSSxDQUFDLE9BQU8sR0FBRyxPQUFPLENBQUM7UUFDdkIsSUFBSSxDQUFDLFNBQVMsR0FBRyxPQUFPLENBQUMsSUFBSSxDQUFDO1FBQzlCLElBQUksQ0FBQyxRQUFRLEdBQUcsT0FBTyxDQUFDLEdBQUcsQ0FBQztRQUM1QixJQUFJLENBQUMsaUJBQWlCLEdBQUcsT0FBTyxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxVQUFVLENBQUMsQ0FBQztRQUN6RSxJQUFJLENBQUMsV0FBVyxHQUFHLElBQUksQ0FBQyxtQkFBbUIsQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxNQUFNLEVBQUUsSUFBSSxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsS0FBSyxFQUFFLElBQUksQ0FBQyxTQUFTLENBQUMsRUFBRSxDQUFDLENBQUM7UUFFdEgsSUFBSSxDQUFDLHVCQUF1QixFQUFFLENBQUM7UUFDL0IsSUFBSSxDQUFDLGlCQUFpQixDQUFDLElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQztJQUNyRSxDQUFDO0lBRU0sZUFBZTtRQUNsQixJQUFJLENBQUMsU0FBUyxHQUFHLEtBQUssQ0FBQztJQUMzQixDQUFDO0lBRU0sT0FBTztRQUNWLE9BQU8sS0FBSyxDQUFDO0lBQ2pCLENBQUM7SUFFTSxXQUFXO1FBQ2QsS0FBSyxJQUFJLElBQUksSUFBSSxJQUFJLENBQUMsZ0JBQWdCLEVBQUU7WUFDcEMsSUFBSSxJQUFJLENBQUMsZ0JBQWdCLENBQUMsY0FBYyxDQUFDLElBQUksQ0FBQyxFQUFFO2dCQUM1QyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsSUFBSSxDQUFDLENBQUMsV0FBVyxFQUFFLENBQUM7YUFDN0M7U0FDSjtJQUNMLENBQUM7SUFFRCxpRkFBaUY7SUFDMUUsV0FBVyxDQUFDLFNBQXdCLEVBQUUsTUFBWTtRQUNyRCxJQUFJLElBQUksQ0FBQyxTQUFTO1lBQUUsT0FBTztRQUUzQixJQUFJLE9BQU8sTUFBTSxLQUFLLFdBQVcsRUFBRTtZQUMvQixTQUFTLENBQUMsS0FBSyxHQUFHLE1BQU0sQ0FBQztTQUM1QjtRQUVELElBQUksQ0FBQyxtQkFBbUIsQ0FBQyxTQUFTLENBQUMsQ0FBQztRQUNwQyxJQUFJLENBQUMsb0JBQW9CLENBQUMsU0FBUyxDQUFDLENBQUM7UUFFckMsSUFBSSxlQUFlLEdBQXlCO1lBQ3hDLEtBQUssRUFBRSxJQUFJLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxLQUFLO1lBQ2hDLEtBQUssRUFBRSxJQUFJLENBQUMsU0FBUyxDQUFDLEVBQUU7WUFDeEIsV0FBVyxFQUFFLFNBQVMsQ0FBQyxHQUFHO1lBQzFCLFFBQVEsRUFBRSxTQUFTO1lBQ25CLElBQUksRUFBRSxTQUFTLENBQUMsS0FBSztTQUN4QixDQUFDO1FBRUYsSUFBSSxDQUFDLHdCQUF3QixDQUFDLGVBQWUsQ0FBQyxDQUFDO0lBQ25ELENBQUM7SUFFRCxpRkFBaUY7SUFDekUsaUJBQWlCLENBQUMsS0FBbUM7UUFDekQsS0FBSyxJQUFJLElBQUksSUFBSSxLQUFLLEVBQUU7WUFDcEIsSUFBSSxLQUFLLENBQUMsY0FBYyxDQUFDLElBQUksQ0FBQyxFQUFFO2dCQUM1QixJQUFJLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQzthQUNwQztTQUNKO0lBQ0wsQ0FBQztJQUVPLG9CQUFvQixDQUFDLFNBQXdCO1FBQ2pELElBQUksQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxDQUFDLFNBQVMsQ0FBQyxHQUFHLENBQUMsR0FBRyxTQUFTLENBQUMsS0FBSyxDQUFDO0lBQ3BGLENBQUM7SUFFTyxtQkFBbUIsQ0FBQyxTQUF3QjtRQUNoRCxJQUFJLENBQUMsaUJBQWlCLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxPQUFPLENBQUMsR0FBRyxTQUFTLENBQUMsS0FBSyxDQUFDO0lBQ3ZGLENBQUM7SUFFRCxpRkFBaUY7SUFDekUsd0JBQXdCLENBQUMsZ0JBQXNDO1FBQ25FLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxZQUFZLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsTUFBTSxFQUFFLGdCQUFnQixDQUFDLENBQUM7SUFDckYsQ0FBQztJQUVELGlGQUFpRjtJQUN6RSxtQkFBbUIsQ0FBQyxPQUFlLEVBQUUsTUFBYyxFQUFFLE1BQWM7UUFDdkUsT0FBTyxPQUFPLEdBQUcsSUFBSSxDQUFDLFNBQVMsR0FBRyxNQUFNLEdBQUcsSUFBSSxDQUFDLFNBQVMsR0FBRyxNQUFNLENBQUM7SUFDdkUsQ0FBQztJQUVPLHVCQUF1QjtRQUMzQixJQUFJLE9BQU8sR0FBWSxRQUFRLENBQUMsYUFBYSxDQUFDLE1BQU0sQ0FBQyxDQUFDO1FBRXRELElBQUksT0FBTyxLQUFLLElBQUksSUFBSSxPQUFPLENBQUMsS0FBSyxDQUFDLEtBQUssRUFBRSxJQUFJLE9BQU8sQ0FBQyxLQUFLLENBQUMsS0FBSyxLQUFLLEVBQUU7WUFDdkUsSUFBSSxDQUFDLGdCQUFnQixHQUFJLE1BQU0sQ0FBQztTQUNuQzthQUNJO1lBQ0QsSUFBSSxDQUFDLGdCQUFnQixHQUFJLE9BQU8sQ0FBQztTQUNwQztJQUNMLENBQUM7OztZQTFMSixTQUFTLFNBQUM7Z0JBQ1AsUUFBUSxFQUFFLGdCQUFnQjtnQkFDMUIsUUFBUSxFQUFFOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7S0EyRVQ7Z0JBQ0QsSUFBSSxFQUFHLEVBQUUsT0FBTyxFQUFHLGlCQUFpQixFQUFFO2FBQ3pDOzs7WUFwR1EsZUFBZSIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IENvbXBvbmVudCwgQWZ0ZXJWaWV3SW5pdCwgT25EZXN0cm95IH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XHJcbmltcG9ydCB7IFN1YnNjcmlwdGlvbiB9IGZyb20gJ3J4anMnO1xyXG5pbXBvcnQgeyBSb3dOb2RlLCBHcmlkQXBpLCBJQ2VsbFJlbmRlcmVyUGFyYW1zIH0gZnJvbSAnYWctZ3JpZC1jb21tdW5pdHknO1xyXG5pbXBvcnQgeyBJQ2VsbFJlbmRlcmVyQW5ndWxhckNvbXAgfSBmcm9tICdhZy1ncmlkLWFuZ3VsYXInO1xyXG5pbXBvcnQgeyBLZEludFRhYmxlRXZlbnQgfSBmcm9tICcuLi9rZC1hbmd1bGFyLXRhYmxlLWV2ZW50JztcclxuaW1wb3J0IHsgSVRhYmxlSW5wdXQsIElUYWJsZUZvcm1FbWl0UGFyYW1zIH0gZnJvbSAnLi4vaW5kZXgnO1xyXG5cclxuZXhwb3J0IGludGVyZmFjZSBJS2RUYWJsZUlucHV0UGFyYW1zIGV4dGVuZHMgSUNlbGxSZW5kZXJlclBhcmFtcyB7XHJcbiAgICBwYXJhbXM/OiB7XHJcbiAgICAgICAgZ3JpZElkPzogc3RyaW5nLFxyXG4gICAgICAgIGNvbnRleHRLZXk/OiBzdHJpbmcsXHJcbiAgICAgICAgaW5wdXRDb25maWc/OiB7XHJcbiAgICAgICAgICAgIGRhdGE/OiBBcnJheTxhbnk+IHwgYW55XHJcbiAgICAgICAgfVxyXG4gICAgfTtcclxufVxyXG5cclxuZXhwb3J0IGludGVyZmFjZSBJS2RUYWJsZUlucHV0IHtcclxuICAgIFtrZXk6IHN0cmluZ106IGFueTtcclxuICAgIGNvbnRyb2xUeXBlOiBzdHJpbmc7XHJcbiAgICB2YWx1ZTogYW55O1xyXG4gICAga2V5OiBzdHJpbmc7XHJcbiAgICB2aXNpYmxlOiBib29sZWFuO1xyXG59XHJcblxyXG5AQ29tcG9uZW50KHtcclxuICAgIHNlbGVjdG9yOiAna2QtdGFibGUtaW5wdXQnLFxyXG4gICAgdGVtcGxhdGU6IGBcclxuICAgICAgICA8bmctdGVtcGxhdGUgbmdGb3IgbGV0LWl0ZW0gW25nRm9yT2ZdPSdpbnB1dERhdGEnPlxyXG4gICAgICAgICAgICA8ZGl2ICpuZ0lmPSdpdGVtLnZpc2libGUnIGNsYXNzPSdrZHggdGFibGUtaW5wdXQtd3JhcHBlcic+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IFtuZ1N3aXRjaF09J2l0ZW0uY29udHJvbFR5cGUnPlxyXG5cclxuICAgICAgICAgICAgICAgICAgICA8aW5wdXQgKm5nU3dpdGNoQ2FzZT1cIid0ZXh0J1wiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9J3RleHQnXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIFtpZF09J2l0ZW0ua2V5J1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBbcGxhY2Vob2xkZXJdPSdpdGVtLnBsYWNlaG9sZGVyID8gaXRlbS5wbGFjZWhvbGRlciA6IFwiXCInXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIFsobmdNb2RlbCldPSdpdGVtLnZhbHVlJ1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAobmdNb2RlbENoYW5nZSk9J3ZhbHVlVXBkYXRlKGl0ZW0pJ1xyXG4gICAgICAgICAgICAgICAgICAgIC8+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIDxpbnB1dCAqbmdTd2l0Y2hDYXNlPVwiJ251bWJlcidcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB0eXBlPSdudW1iZXInXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIFtpZF09J2l0ZW0ua2V5J1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBbbWluXT0naXRlbS5taW4nXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIFttYXhdPSdpdGVtLm1heCdcclxuICAgICAgICAgICAgICAgICAgICAgICAgW3N0ZXBdPSdpdGVtLnN0ZXAnXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIFtwbGFjZWhvbGRlcl09J2l0ZW0ucGxhY2Vob2xkZXIgPyBpdGVtLnBsYWNlaG9sZGVyIDogXCJcIidcclxuICAgICAgICAgICAgICAgICAgICAgICAgWyhuZ01vZGVsKV09J2l0ZW0udmFsdWUnXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIChuZ01vZGVsQ2hhbmdlKT0ndmFsdWVVcGRhdGUoaXRlbSknXHJcbiAgICAgICAgICAgICAgICAgICAgLz5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgPHRleHRhcmVhICpuZ1N3aXRjaENhc2U9XCIndGV4dGFyZWEnXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgW2lkXT0naXRlbS5rZXknXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIFtwbGFjZWhvbGRlcl09J2l0ZW0ucGxhY2Vob2xkZXIgPyBpdGVtLnBsYWNlaG9sZGVyIDogXCJcIidcclxuICAgICAgICAgICAgICAgICAgICAgICAgWyhuZ01vZGVsKV09J2l0ZW0udmFsdWUnXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIChuZ01vZGVsQ2hhbmdlKT0ndmFsdWVVcGRhdGUoaXRlbSknXHJcbiAgICAgICAgICAgICAgICAgICAgPjwvdGV4dGFyZWE+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgKm5nU3dpdGNoQ2FzZT1cIidkcm9wZG93bidcIiBjbGFzcz0na2R4LWlucHV0LXNlbGVjdC13cmFwcGVyJz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPHNlbGVjdFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgW2lkXT0naXRlbS5rZXknXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBbKG5nTW9kZWwpXT0naXRlbS52YWx1ZSdcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIChuZ01vZGVsQ2hhbmdlKT0ndmFsdWVVcGRhdGUoaXRlbSknXHJcbiAgICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24gKm5nRm9yPSdsZXQgb3B0aW9uIG9mIGl0ZW0ub3B0aW9ucycgW3ZhbHVlXT0nb3B0aW9uLmtleSc+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge3tvcHRpb24udmFsdWV9fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9vcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvc2VsZWN0PlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgICAgICA8a2QtZGF0ZXBpY2tlciAqbmdTd2l0Y2hDYXNlPVwiJ2RhdGUnXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgW2lkXT1cIml0ZW0ua2V5XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgW2NvbmZpZ109J2l0ZW0uY29uZmlnJ1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBbaW5wdXRWYWxdPSdpdGVtLnZhbHVlJ1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBbbWluRGF0ZV09J2l0ZW0ubWluRGF0ZSdcclxuICAgICAgICAgICAgICAgICAgICAgICAgW21heERhdGVdPSdpdGVtLm1heERhdGUnXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIChkYXRlQ29uZmlnKT0ndmFsdWVVcGRhdGUoaXRlbSwgJGV2ZW50KSdcclxuICAgICAgICAgICAgICAgICAgICA+PC9rZC1kYXRlcGlja2VyPlxyXG5cclxuICAgICAgICAgICAgICAgICAgICA8a2QtdGltZXBpY2tlciAqbmdTd2l0Y2hDYXNlPVwiJ3RpbWUnXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgW2lkXT0naXRlbS5rZXknXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIFtjb25maWddPSdpdGVtLmNvbmZpZydcclxuICAgICAgICAgICAgICAgICAgICAgICAgW2lucHV0VmFsXT0naXRlbS52YWx1ZSdcclxuICAgICAgICAgICAgICAgICAgICAgICAgKHRpbWVDb25maWcpPSd2YWx1ZVVwZGF0ZShpdGVtLCAkZXZlbnQpJ1xyXG4gICAgICAgICAgICAgICAgICAgID48L2tkLXRpbWVwaWNrZXI+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIDxrZC1zbGlkZXIgKm5nU3dpdGNoQ2FzZT1cIidzbGlkZXInXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgW2lkXT0naXRlbS5rZXknXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIFtjb25maWddPSdpdGVtLmNvbmZpZydcclxuICAgICAgICAgICAgICAgICAgICAgICAgW3ZhbHVlXT0naXRlbS52YWx1ZSdcclxuICAgICAgICAgICAgICAgICAgICAgICAgW2FwaV09J2l0ZW0uYXBpJ1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAocmVzdWx0KT0ndmFsdWVVcGRhdGUoaXRlbSwgJGV2ZW50KSdcclxuICAgICAgICAgICAgICAgICAgICA+PC9rZC1zbGlkZXI+XHJcblxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgPGtkLXRvb2x0aXBcclxuICAgICAgICAgICAgICAgICAgICAqbmdJZj0naXRlbS5lcnJvcnMgJiYgaXRlbS5lcnJvcnMubGVuZ3RoID4gMCdcclxuICAgICAgICAgICAgICAgICAgICBbY29uZmlnXT1cInsgdHlwZTogJ2Vycm9yJywgcGxhY2VtZW50OiB0b29sdGlwRGlyZWN0aW9uLCBkZXNjcmlwdGlvbjogaXRlbS5lcnJvcnMgfVwiXHJcbiAgICAgICAgICAgICAgICA+PC9rZC10b29sdGlwPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8L25nLXRlbXBsYXRlPlxyXG4gICAgYCxcclxuICAgIGhvc3QgOiB7ICdjbGFzcycgOiAna2R4LXRhYmxlLWlucHV0JyB9XHJcbn0pXHJcblxyXG5leHBvcnQgY2xhc3MgS2RUYWJsZUlucHV0IGltcGxlbWVudHMgSUNlbGxSZW5kZXJlckFuZ3VsYXJDb21wLCBBZnRlclZpZXdJbml0LCBPbkRlc3Ryb3kge1xyXG4gICAgcHVibGljIGlucHV0RGF0YTogQXJyYXk8SVRhYmxlSW5wdXQ+ID0gW107XHJcbiAgICBwdWJsaWMgdG9vbHRpcERpcmVjdGlvbjogJ2xlZnQnIHwgJ3JpZ2h0JztcclxuXHJcbiAgICBwcml2YXRlIF9wYXJhbXM6IElLZFRhYmxlSW5wdXRQYXJhbXM7XHJcbiAgICBwcml2YXRlIF9jZWxsTm9kZTogUm93Tm9kZTtcclxuICAgIHByaXZhdGUgX2dyaWRBcGk6IEdyaWRBcGk7XHJcbiAgICBwcml2YXRlIF9ncmlkSW5wdXRDb250ZXh0OiBhbnk7XHJcbiAgICBwcml2YXRlIF9jb250ZXh0S2V5OiBzdHJpbmc7XHJcbiAgICBwcml2YXRlIF9zdWJzY3JpcHRpb25PYmo6IHtba2V5OiBzdHJpbmddOiBTdWJzY3JpcHRpb259ID0ge307XHJcbiAgICBwcml2YXRlIF9maXJzdFJ1bjogYm9vbGVhbiA9IHRydWU7XHJcblxyXG4gICAgcmVhZG9ubHkgREVMSU1JVEVSOiBzdHJpbmcgPSAnfic7XHJcblxyXG4gICAgY29uc3RydWN0b3IoXHJcbiAgICAgICAgcHJpdmF0ZSBfa2RJbnRUYWJsZUV2ZW50OiBLZEludFRhYmxlRXZlbnRcclxuICAgICkge31cclxuXHJcbiAgICAvKioqKioqKioqKioqKioqKioqKioqIENvbXBvbmVudCBMaWZlIGN5Y2xlcyBmdW5jdGlvbnMgKioqKioqKioqKioqKioqKioqKioqKioqKi9cclxuICAgIHB1YmxpYyBhZ0luaXQoX3BhcmFtczogSUtkVGFibGVJbnB1dFBhcmFtcyk6IHZvaWQge1xyXG4gICAgICAgIC8vIGNvbnNvbGUubG9nKCdfcGFyYW1zIGhlcmUgLSAnLCBfcGFyYW1zKTtcclxuICAgICAgICB0aGlzLl9wYXJhbXMgPSBfcGFyYW1zO1xyXG4gICAgICAgIHRoaXMuX2NlbGxOb2RlID0gX3BhcmFtcy5ub2RlO1xyXG4gICAgICAgIHRoaXMuX2dyaWRBcGkgPSBfcGFyYW1zLmFwaTtcclxuICAgICAgICB0aGlzLl9ncmlkSW5wdXRDb250ZXh0ID0gX3BhcmFtcy5jb250ZXh0W3RoaXMuX3BhcmFtcy5wYXJhbXMuY29udGV4dEtleV07XHJcbiAgICAgICAgdGhpcy5fY29udGV4dEtleSA9IHRoaXMuX2dlbmVyYXRlQ29udGV4dEtleSh0aGlzLl9wYXJhbXMucGFyYW1zLmdyaWRJZCwgdGhpcy5fcGFyYW1zLmNvbERlZi5jb2xJZCwgdGhpcy5fY2VsbE5vZGUuaWQpO1xyXG5cclxuICAgICAgICB0aGlzLl91cGRhdGVUb29sdGlwRGlyZWN0aW9uKCk7XHJcbiAgICAgICAgdGhpcy5fcHJvY2Vzc0lucHV0RGF0YSh0aGlzLl9ncmlkSW5wdXRDb250ZXh0W3RoaXMuX2NvbnRleHRLZXldKTtcclxuICAgIH1cclxuXHJcbiAgICBwdWJsaWMgbmdBZnRlclZpZXdJbml0KCk6IHZvaWQge1xyXG4gICAgICAgIHRoaXMuX2ZpcnN0UnVuID0gZmFsc2U7XHJcbiAgICB9XHJcblxyXG4gICAgcHVibGljIHJlZnJlc2goKTogYm9vbGVhbiB7XHJcbiAgICAgICAgcmV0dXJuIGZhbHNlO1xyXG4gICAgfVxyXG5cclxuICAgIHB1YmxpYyBuZ09uRGVzdHJveSgpOiB2b2lkIHtcclxuICAgICAgICBmb3IgKGxldCBpdGVtIGluIHRoaXMuX3N1YnNjcmlwdGlvbk9iaikge1xyXG4gICAgICAgICAgICBpZiAodGhpcy5fc3Vic2NyaXB0aW9uT2JqLmhhc093blByb3BlcnR5KGl0ZW0pKSB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLl9zdWJzY3JpcHRpb25PYmpbaXRlbV0udW5zdWJzY3JpYmUoKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICAvKioqKioqKioqKioqKioqKioqKioqKiogQ29tcG9uZW50IHRlbXBsYXRlIGZ1bmN0aW9ucyAqKioqKioqKioqKioqKioqKioqKioqKioqKi9cclxuICAgIHB1YmxpYyB2YWx1ZVVwZGF0ZShfcXVlc3Rpb246IElLZFRhYmxlSW5wdXQsIF92YWx1ZT86IGFueSk6IHZvaWQge1xyXG4gICAgICAgIGlmICh0aGlzLl9maXJzdFJ1bikgcmV0dXJuO1xyXG5cclxuICAgICAgICBpZiAodHlwZW9mIF92YWx1ZSAhPT0gJ3VuZGVmaW5lZCcpIHtcclxuICAgICAgICAgICAgX3F1ZXN0aW9uLnZhbHVlID0gX3ZhbHVlO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgdGhpcy5fdXBkYXRlQ29udGV4dFZhbHVlKF9xdWVzdGlvbik7XHJcbiAgICAgICAgdGhpcy5fdXBkYXRlQ2VsbE5vZGVWYWx1ZShfcXVlc3Rpb24pO1xyXG5cclxuICAgICAgICBsZXQgYnJvYWRjYXN0UGFyYW1zOiBJVGFibGVGb3JtRW1pdFBhcmFtcyA9IHtcclxuICAgICAgICAgICAgY29sSWQ6IHRoaXMuX3BhcmFtcy5jb2xEZWYuY29sSWQsXHJcbiAgICAgICAgICAgIHJvd0lkOiB0aGlzLl9jZWxsTm9kZS5pZCxcclxuICAgICAgICAgICAgcXVlc3Rpb25LZXk6IF9xdWVzdGlvbi5rZXksXHJcbiAgICAgICAgICAgIHF1ZXN0aW9uOiBfcXVlc3Rpb24sXHJcbiAgICAgICAgICAgIGRhdGE6IF9xdWVzdGlvbi52YWx1ZVxyXG4gICAgICAgIH07XHJcblxyXG4gICAgICAgIHRoaXMuX2Jyb2FkY2FzdFF1ZXN0aW9uQ2hhbmdlKGJyb2FkY2FzdFBhcmFtcyk7XHJcbiAgICB9XHJcblxyXG4gICAgLyoqKioqKioqKioqKioqKioqKioqKioqKiogSW5wdXQgcXVlc3Rpb24gZnVuY3Rpb25zICoqKioqKioqKioqKioqKioqKioqKioqKioqKiovXHJcbiAgICBwcml2YXRlIF9wcm9jZXNzSW5wdXREYXRhKF9kYXRhOiB7W2tleTogc3RyaW5nXTogSVRhYmxlSW5wdXR9KTogdm9pZCB7XHJcbiAgICAgICAgZm9yIChsZXQgaXRlbSBpbiBfZGF0YSkge1xyXG4gICAgICAgICAgICBpZiAoX2RhdGEuaGFzT3duUHJvcGVydHkoaXRlbSkpIHtcclxuICAgICAgICAgICAgICAgIHRoaXMuaW5wdXREYXRhLnB1c2goX2RhdGFbaXRlbV0pO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX3VwZGF0ZUNlbGxOb2RlVmFsdWUoX3F1ZXN0aW9uOiBJS2RUYWJsZUlucHV0KTogdm9pZCB7XHJcbiAgICAgICAgdGhpcy5fY2VsbE5vZGUuZGF0YVt0aGlzLl9wYXJhbXMuY29sRGVmLmNvbElkXVtfcXVlc3Rpb24ua2V5XSA9IF9xdWVzdGlvbi52YWx1ZTtcclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF91cGRhdGVDb250ZXh0VmFsdWUoX3F1ZXN0aW9uOiBJS2RUYWJsZUlucHV0KTogdm9pZCB7XHJcbiAgICAgICAgdGhpcy5fZ3JpZElucHV0Q29udGV4dFt0aGlzLl9jb250ZXh0S2V5XVtfcXVlc3Rpb24ua2V5XVsndmFsdWUnXSA9IF9xdWVzdGlvbi52YWx1ZTtcclxuICAgIH1cclxuXHJcbiAgICAvKioqKioqKioqKioqKioqKioqKioqKiogUHJpdmF0ZSBicm9hZGNhc3QgZnVuY3Rpb25zICoqKioqKioqKioqKioqKioqKioqKioqKioqKi9cclxuICAgIHByaXZhdGUgX2Jyb2FkY2FzdFF1ZXN0aW9uQ2hhbmdlKF9icm9hZGNhc3RQYXJhbXM6IElUYWJsZUZvcm1FbWl0UGFyYW1zKTogdm9pZCB7XHJcbiAgICAgICAgdGhpcy5fa2RJbnRUYWJsZUV2ZW50LmlucHV0Q2hhbmdlZCh0aGlzLl9wYXJhbXMucGFyYW1zLmdyaWRJZCwgX2Jyb2FkY2FzdFBhcmFtcyk7XHJcbiAgICB9XHJcblxyXG4gICAgLyoqKioqKioqKioqKioqKioqKioqKioqKioqKioqIE1pc2MgZnVuY3Rpb25zICoqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKiovXHJcbiAgICBwcml2YXRlIF9nZW5lcmF0ZUNvbnRleHRLZXkoX2dyaWRJZDogc3RyaW5nLCBfY29sSWQ6IHN0cmluZywgX3Jvd0lkOiBzdHJpbmcpOiBzdHJpbmcge1xyXG4gICAgICAgIHJldHVybiBfZ3JpZElkICsgdGhpcy5ERUxJTUlURVIgKyBfY29sSWQgKyB0aGlzLkRFTElNSVRFUiArIF9yb3dJZDtcclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF91cGRhdGVUb29sdGlwRGlyZWN0aW9uKCk6IHZvaWQge1xyXG4gICAgICAgIGxldCBodG1sRWxlOiBFbGVtZW50ID0gZG9jdW1lbnQucXVlcnlTZWxlY3RvcignaHRtbCcpO1xyXG5cclxuICAgICAgICBpZiAoaHRtbEVsZSAhPT0gbnVsbCAmJiBodG1sRWxlWydkaXInXSAhPT0gJycgJiYgaHRtbEVsZVsnZGlyJ10gPT09ICdydGwnKSB7XHJcbiAgICAgICAgICAgIHRoaXMudG9vbHRpcERpcmVjdGlvbiA9ICAnbGVmdCc7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICB0aGlzLnRvb2x0aXBEaXJlY3Rpb24gPSAgJ3JpZ2h0JztcclxuICAgICAgICB9XHJcbiAgICB9XHJcbn1cclxuIl19