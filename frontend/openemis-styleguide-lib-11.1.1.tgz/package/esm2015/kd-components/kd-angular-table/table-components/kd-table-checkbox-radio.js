import { Component } from '@angular/core';
import { KdIntTableEvent } from '../kd-angular-table-event';
export class KdTableCheckboxRadio {
    constructor(_kdIntTableEvent) {
        this._kdIntTableEvent = _kdIntTableEvent;
        this._inputType = 'checkbox';
        this._isHeader = false;
        this._selectAll = false;
        this._paramsDefault = [];
        this._paramGridId = 'kd-table-grid';
        this._subscriptionObj = {};
    }
    /********************* Component Life cycles functions *************************/
    agInit(_params) {
        // console.log("-- Grid state: Checkbox/Radio agInit --", _params);
        this._params = _params;
        this._paramsApi = this._params.api;
        this._paramGridId = this._params.params.gridId;
        this._isHeader = typeof this._params.rowIndex === 'undefined';
        this._getDefaultSelection();
        this._updateInputType();
        if (!this._isHeader) {
            this._paramNode = this._params.node;
            this._updateInitialSelection();
        }
        this._setupSubscriptionEvents();
    }
    refresh(_params) {
        return false;
    }
    ngOnDestroy() {
        for (let item in this._subscriptionObj) {
            if (this._subscriptionObj.hasOwnProperty(item)) {
                this._subscriptionObj[item].unsubscribe();
            }
        }
    }
    _updateCheckbox(_event) {
        // console.log("-- Grid state: Checkbox/Radio checked --")
        let inputTarget = event.target;
        this._updateSelection(inputTarget.checked);
    }
    /**************************** Private functions ********************************/
    ///////////////////////////////////////////////////////////////////////////////////////////////
    /// Update functions
    ///////////////////////////////////////////////////////////////////////////////////////////////
    _updateSelection(_isChecked) {
        if (this._isHeader) {
            this._selectAll = _isChecked;
            this._updateAllCheckbox();
        }
        else {
            if (this._inputType === 'checkbox') {
                this._paramNode.selectThisNode(_isChecked);
                this._updateDefaultValue(this._paramNode.id, _isChecked);
            }
            else {
                this._paramsApi.deselectAll();
                this._paramNode.selectThisNode(true);
                this._updateDefaultValue(this._paramNode.id, true, true);
            }
        }
        this._emitSelectionChanged();
    }
    ///////////////////////////////////////////////////////////////////////////////////////////////
    /// Checkbox / Checkbox all functions
    ///////////////////////////////////////////////////////////////////////////////////////////////
    // private _updateAllCheckbox(): void {
    //     let currentModel = this._getCurrentRowModel();
    //     if (currentModel !== null) {
    //         currentModel.forEachNode((_rowNode: RowNode): void => {
    //             _rowNode.selectThisNode(this._selectAll);
    //             this._updateDefaultValue(_rowNode.data.id, this._selectAll);
    //         });
    //     }
    // }
    // Select is working properly 
    _updateAllCheckbox() {
        let currentModel = this._getCurrentRowModel();
        if (currentModel !== null) {
            if (currentModel && currentModel.rowsToDisplay && currentModel.rowsToDisplay.length) {
                currentModel.rowsToDisplay.forEach((_rowNode) => {
                    _rowNode.selectThisNode(this._selectAll);
                    this._updateDefaultValue(_rowNode.id, this._selectAll);
                });
            }
            else {
                currentModel.forEachNode((_rowNode) => {
                    _rowNode.selectThisNode(this._selectAll);
                    this._updateDefaultValue(_rowNode.data.id, this._selectAll);
                });
            }
        }
    }
    _checkSelectAll() {
        let currentModel = this._getCurrentRowModel();
        let selectAll = true;
        if (currentModel !== null) {
            if (currentModel.getRowCount() === 0) {
                selectAll = false;
            }
            else {
                currentModel.forEachNode((_rowNode) => {
                    if (selectAll && !_rowNode.isSelected()) {
                        selectAll = false;
                    }
                });
            }
        }
        this._selectAll = selectAll;
    }
    ///////////////////////////////////////////////////////////////////////////////////////////////
    /// Default value functions
    ///////////////////////////////////////////////////////////////////////////////////////////////
    _updateInitialSelection() {
        let isSelected = false;
        if (typeof this._paramsDefault !== 'undefined') {
            for (let i = 0; i < this._paramsDefault.length; ++i) {
                if (this._paramsDefault[i].toString() === this._paramNode.id) {
                    isSelected = true;
                    break;
                }
            }
        }
        this._paramNode.selectThisNode(isSelected);
    }
    _getDefaultSelection() {
        if (typeof this._params.params !== 'undefined' &&
            typeof this._params.params.default !== 'undefined') {
            this._paramsDefault = this._params.params.default;
        }
    }
    _updateDefaultValue(_id, _isSelected, _toEmptyDefault) {
        if (_toEmptyDefault) {
            this._paramsDefault.splice(0, this._paramsDefault.length);
        }
        if (_isSelected && this._paramsDefault.indexOf(_id) < 0) {
            this._paramsDefault.push(_id);
        }
        else if (!_isSelected && this._paramsDefault.indexOf(_id) > -1) {
            this._paramsDefault.splice(this._paramsDefault.indexOf(_id), 1);
        }
        this._sortDefaultValue();
    }
    ///////////////////////////////////////////////////////////////////////////////////////////////
    /// Events - Subscriber / On functions
    ///////////////////////////////////////////////////////////////////////////////////////////////
    _emitSelectionChanged() {
        this._kdIntTableEvent.selectionChanged(this._paramGridId, this._paramNode);
    }
    _setupSubscriptionEvents() {
        if (this._isHeader) {
            this._subscriptionObj.headerCheckboxSub = this._kdIntTableEvent.onModelChanged(this._paramGridId).subscribe(() => {
                this._checkSelectAll();
            });
            this._subscriptionObj.selectedChangeSub = this._kdIntTableEvent.onSelectionChanged(this._paramGridId).subscribe(() => {
                this._checkSelectAll();
            });
        }
    }
    ///////////////////////////////////////////////////////////////////////////////////////////////
    /// Misc functions
    ///////////////////////////////////////////////////////////////////////////////////////////////
    _updateInputType() {
        if (typeof this._params.params !== 'undefined') {
            this._inputType = this._params.params.inputType;
        }
        else {
            this._inputType = 'checkbox';
        }
    }
    _getCurrentRowModel() {
        if (typeof this._paramsApi !== 'undefined') {
            return this._paramsApi.getModel();
        }
        return null;
    }
    _sortDefaultValue() {
        this._paramsDefault.sort((_a, _b) => {
            if (_a > _b)
                return 1;
            else if (_a < _b)
                return -1;
            return 0;
        });
    }
}
KdTableCheckboxRadio.decorators = [
    { type: Component, args: [{
                selector: 'ag-checkbox-radio',
                template: `
        <div class="selection-wrapper">
            <input *ngIf="_isHeader" class="checkbox-radio-input"
                type="checkbox"
                [checked]="_selectAll"
                (change)="_updateCheckbox($event)"
            />

            <input *ngIf="!_isHeader" class="checkbox-radio-input"
                [type]="_inputType"
                [attr.name]="_inputType"
                [checked]="(_paramNode) ? _paramNode.isSelected() : false"
                (change)="_updateCheckbox($event)"
            />
            <label></label>
        </div>
    `,
                host: { class: 'kdx-ag-checkbox-radio' }
            },] }
];
KdTableCheckboxRadio.ctorParameters = () => [
    { type: KdIntTableEvent }
];
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoia2QtdGFibGUtY2hlY2tib3gtcmFkaW8uanMiLCJzb3VyY2VSb290IjoiRDovb3BlbkVNSVMvc3R5bGVndWlkZS9pb3N0Zy1vcGVuZW1pcy1zdHlsZWd1aWRlL3Byb2plY3RzL29wZW5lbWlzLXN0eWxlZ3VpZGUtbGliL3NyYy8iLCJzb3VyY2VzIjpbImtkLWNvbXBvbmVudHMva2QtYW5ndWxhci10YWJsZS90YWJsZS1jb21wb25lbnRzL2tkLXRhYmxlLWNoZWNrYm94LXJhZGlvLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBLE9BQU8sRUFBRSxTQUFTLEVBQWEsTUFBTSxlQUFlLENBQUM7QUFXckQsT0FBTyxFQUFFLGVBQWUsRUFBRSxNQUFNLDJCQUEyQixDQUFDO0FBZ0M1RCxNQUFNLE9BQU8sb0JBQW9CO0lBWTdCLFlBQ1ksZ0JBQWlDO1FBQWpDLHFCQUFnQixHQUFoQixnQkFBZ0IsQ0FBaUI7UUFadEMsZUFBVSxHQUFXLFVBQVUsQ0FBQztRQUNoQyxjQUFTLEdBQVksS0FBSyxDQUFDO1FBRTNCLGVBQVUsR0FBWSxLQUFLLENBQUM7UUFJM0IsbUJBQWMsR0FBMkIsRUFBRSxDQUFDO1FBQzVDLGlCQUFZLEdBQVcsZUFBZSxDQUFDO1FBQ3ZDLHFCQUFnQixHQUFrQyxFQUFFLENBQUM7SUFJekQsQ0FBQztJQUVMLGlGQUFpRjtJQUNqRixNQUFNLENBQUMsT0FBWTtRQUNmLG1FQUFtRTtRQUNuRSxJQUFJLENBQUMsT0FBTyxHQUFHLE9BQU8sQ0FBQztRQUN2QixJQUFJLENBQUMsVUFBVSxHQUFHLElBQUksQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDO1FBQ25DLElBQUksQ0FBQyxZQUFZLEdBQUcsSUFBSSxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDO1FBQy9DLElBQUksQ0FBQyxTQUFTLEdBQUcsT0FBTyxJQUFJLENBQUMsT0FBTyxDQUFDLFFBQVEsS0FBSyxXQUFXLENBQUM7UUFFOUQsSUFBSSxDQUFDLG9CQUFvQixFQUFFLENBQUM7UUFDNUIsSUFBSSxDQUFDLGdCQUFnQixFQUFFLENBQUM7UUFFeEIsSUFBSSxDQUFDLElBQUksQ0FBQyxTQUFTLEVBQUU7WUFDakIsSUFBSSxDQUFDLFVBQVUsR0FBRyxJQUFJLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQztZQUNwQyxJQUFJLENBQUMsdUJBQXVCLEVBQUUsQ0FBQztTQUNsQztRQUVELElBQUksQ0FBQyx3QkFBd0IsRUFBRSxDQUFDO0lBQ3BDLENBQUM7SUFFRCxPQUFPLENBQUMsT0FBWTtRQUNoQixPQUFPLEtBQUssQ0FBQztJQUNqQixDQUFDO0lBRUQsV0FBVztRQUNQLEtBQUssSUFBSSxJQUFJLElBQUksSUFBSSxDQUFDLGdCQUFnQixFQUFFO1lBQ3BDLElBQUksSUFBSSxDQUFDLGdCQUFnQixDQUFDLGNBQWMsQ0FBQyxJQUFJLENBQUMsRUFBRTtnQkFDNUMsSUFBSSxDQUFDLGdCQUFnQixDQUFDLElBQUksQ0FBQyxDQUFDLFdBQVcsRUFBRSxDQUFDO2FBQzdDO1NBQ0o7SUFDTCxDQUFDO0lBRU0sZUFBZSxDQUFDLE1BQVc7UUFDOUIsMERBQTBEO1FBQzFELElBQUksV0FBVyxHQUF1QyxLQUFLLENBQUMsTUFBTSxDQUFDO1FBQ25FLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxXQUFXLENBQUMsT0FBTyxDQUFDLENBQUM7SUFDL0MsQ0FBQztJQUVELGlGQUFpRjtJQUNqRiwrRkFBK0Y7SUFDL0Ysb0JBQW9CO0lBQ3BCLCtGQUErRjtJQUN2RixnQkFBZ0IsQ0FBQyxVQUFtQjtRQUN4QyxJQUFJLElBQUksQ0FBQyxTQUFTLEVBQUU7WUFDaEIsSUFBSSxDQUFDLFVBQVUsR0FBRyxVQUFVLENBQUM7WUFDN0IsSUFBSSxDQUFDLGtCQUFrQixFQUFFLENBQUM7U0FFN0I7YUFDSTtZQUNELElBQUksSUFBSSxDQUFDLFVBQVUsS0FBSyxVQUFVLEVBQUU7Z0JBQ2hDLElBQUksQ0FBQyxVQUFVLENBQUMsY0FBYyxDQUFDLFVBQVUsQ0FBQyxDQUFDO2dCQUMzQyxJQUFJLENBQUMsbUJBQW1CLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxFQUFFLEVBQUUsVUFBVSxDQUFDLENBQUM7YUFDNUQ7aUJBQ0k7Z0JBQ0QsSUFBSSxDQUFDLFVBQVUsQ0FBQyxXQUFXLEVBQUUsQ0FBQztnQkFDOUIsSUFBSSxDQUFDLFVBQVUsQ0FBQyxjQUFjLENBQUMsSUFBSSxDQUFDLENBQUM7Z0JBQ3JDLElBQUksQ0FBQyxtQkFBbUIsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLEVBQUUsRUFBRSxJQUFJLEVBQUUsSUFBSSxDQUFDLENBQUM7YUFDNUQ7U0FDSjtRQUVELElBQUksQ0FBQyxxQkFBcUIsRUFBRSxDQUFDO0lBQ2pDLENBQUM7SUFFRCwrRkFBK0Y7SUFDL0YscUNBQXFDO0lBQ3JDLCtGQUErRjtJQUMvRix1Q0FBdUM7SUFDdkMscURBQXFEO0lBRXJELG1DQUFtQztJQUNuQyxrRUFBa0U7SUFDbEUsd0RBQXdEO0lBQ3hELDJFQUEyRTtJQUMzRSxjQUFjO0lBQ2QsUUFBUTtJQUNSLElBQUk7SUFFSiw4QkFBOEI7SUFDdEIsa0JBQWtCO1FBQ3RCLElBQUksWUFBWSxHQUFRLElBQUksQ0FBQyxtQkFBbUIsRUFBRSxDQUFDO1FBQ25ELElBQUksWUFBWSxLQUFLLElBQUksRUFBRTtZQUN2QixJQUFHLFlBQVksSUFBSSxZQUFZLENBQUMsYUFBYSxJQUFJLFlBQVksQ0FBQyxhQUFhLENBQUMsTUFBTSxFQUNsRjtnQkFDSSxZQUFZLENBQUMsYUFBYSxDQUFDLE9BQU8sQ0FBQyxDQUFDLFFBQVEsRUFBQyxFQUFFO29CQUMzQyxRQUFRLENBQUMsY0FBYyxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsQ0FBQztvQkFDekMsSUFBSSxDQUFDLG1CQUFtQixDQUFDLFFBQVEsQ0FBQyxFQUFFLEVBQUUsSUFBSSxDQUFDLFVBQVUsQ0FBQyxDQUFDO2dCQUMzRCxDQUFDLENBQUMsQ0FBQTthQUNMO2lCQUFJO2dCQUNELFlBQVksQ0FBQyxXQUFXLENBQUMsQ0FBQyxRQUFpQixFQUFRLEVBQUU7b0JBQ3JELFFBQVEsQ0FBQyxjQUFjLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxDQUFDO29CQUN6QyxJQUFJLENBQUMsbUJBQW1CLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxFQUFFLEVBQUUsSUFBSSxDQUFDLFVBQVUsQ0FBQyxDQUFDO2dCQUNoRSxDQUFDLENBQUMsQ0FBQzthQUNGO1NBRUo7SUFDTCxDQUFDO0lBRU8sZUFBZTtRQUNuQixJQUFJLFlBQVksR0FBRyxJQUFJLENBQUMsbUJBQW1CLEVBQUUsQ0FBQztRQUM5QyxJQUFJLFNBQVMsR0FBWSxJQUFJLENBQUM7UUFDOUIsSUFBSSxZQUFZLEtBQUssSUFBSSxFQUFFO1lBQ3ZCLElBQUksWUFBWSxDQUFDLFdBQVcsRUFBRSxLQUFLLENBQUMsRUFBRTtnQkFDbEMsU0FBUyxHQUFHLEtBQUssQ0FBQzthQUNyQjtpQkFDSTtnQkFDRCxZQUFZLENBQUMsV0FBVyxDQUFDLENBQUMsUUFBaUIsRUFBUSxFQUFFO29CQUNqRCxJQUFJLFNBQVMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxVQUFVLEVBQUUsRUFBRTt3QkFDckMsU0FBUyxHQUFHLEtBQUssQ0FBQztxQkFDckI7Z0JBQ0wsQ0FBQyxDQUFDLENBQUM7YUFDTjtTQUNKO1FBQ0QsSUFBSSxDQUFDLFVBQVUsR0FBRyxTQUFTLENBQUM7SUFDaEMsQ0FBQztJQUNELCtGQUErRjtJQUMvRiwyQkFBMkI7SUFDM0IsK0ZBQStGO0lBQ3ZGLHVCQUF1QjtRQUMzQixJQUFJLFVBQVUsR0FBWSxLQUFLLENBQUM7UUFFaEMsSUFBSSxPQUFPLElBQUksQ0FBQyxjQUFjLEtBQUssV0FBVyxFQUFFO1lBQzVDLEtBQUssSUFBSSxDQUFDLEdBQVcsQ0FBQyxFQUFFLENBQUMsR0FBRyxJQUFJLENBQUMsY0FBYyxDQUFDLE1BQU0sRUFBRSxFQUFFLENBQUMsRUFBRTtnQkFDekQsSUFBSSxJQUFJLENBQUMsY0FBYyxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsRUFBRSxLQUFLLElBQUksQ0FBQyxVQUFVLENBQUMsRUFBRSxFQUFFO29CQUMxRCxVQUFVLEdBQUcsSUFBSSxDQUFDO29CQUNsQixNQUFNO2lCQUNUO2FBQ0o7U0FDSjtRQUVELElBQUksQ0FBQyxVQUFVLENBQUMsY0FBYyxDQUFDLFVBQVUsQ0FBQyxDQUFDO0lBQy9DLENBQUM7SUFFTyxvQkFBb0I7UUFDeEIsSUFBSSxPQUFPLElBQUksQ0FBQyxPQUFPLENBQUMsTUFBTSxLQUFLLFdBQVc7WUFDMUMsT0FBTyxJQUFJLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxPQUFPLEtBQUssV0FBVyxFQUFFO1lBQ2hELElBQUksQ0FBQyxjQUFjLEdBQUcsSUFBSSxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDO1NBQ3pEO0lBQ0wsQ0FBQztJQUVPLG1CQUFtQixDQUFDLEdBQW9CLEVBQUUsV0FBb0IsRUFBRSxlQUF5QjtRQUM3RixJQUFJLGVBQWUsRUFBRTtZQUNqQixJQUFJLENBQUMsY0FBYyxDQUFDLE1BQU0sQ0FBQyxDQUFDLEVBQUUsSUFBSSxDQUFDLGNBQWMsQ0FBQyxNQUFNLENBQUMsQ0FBQztTQUM3RDtRQUVELElBQUksV0FBVyxJQUFJLElBQUksQ0FBQyxjQUFjLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUMsRUFBRTtZQUNyRCxJQUFJLENBQUMsY0FBYyxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQztTQUNqQzthQUNJLElBQUksQ0FBQyxXQUFXLElBQUksSUFBSSxDQUFDLGNBQWMsQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxDQUFDLEVBQUU7WUFDNUQsSUFBSSxDQUFDLGNBQWMsQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLGNBQWMsQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUM7U0FDbkU7UUFDRCxJQUFJLENBQUMsaUJBQWlCLEVBQUUsQ0FBQztJQUM3QixDQUFDO0lBRUQsK0ZBQStGO0lBQy9GLHNDQUFzQztJQUN0QywrRkFBK0Y7SUFDdkYscUJBQXFCO1FBQ3pCLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxnQkFBZ0IsQ0FBQyxJQUFJLENBQUMsWUFBWSxFQUFFLElBQUksQ0FBQyxVQUFVLENBQUMsQ0FBQztJQUMvRSxDQUFDO0lBRU8sd0JBQXdCO1FBQzVCLElBQUksSUFBSSxDQUFDLFNBQVMsRUFBRTtZQUNoQixJQUFJLENBQUMsZ0JBQWdCLENBQUMsaUJBQWlCLEdBQUcsSUFBSSxDQUFDLGdCQUFnQixDQUFDLGNBQWMsQ0FBQyxJQUFJLENBQUMsWUFBWSxDQUFDLENBQUMsU0FBUyxDQUFDLEdBQVMsRUFBRTtnQkFDbkgsSUFBSSxDQUFDLGVBQWUsRUFBRSxDQUFDO1lBQzNCLENBQUMsQ0FBQyxDQUFDO1lBRUgsSUFBSSxDQUFDLGdCQUFnQixDQUFDLGlCQUFpQixHQUFHLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxrQkFBa0IsQ0FBQyxJQUFJLENBQUMsWUFBWSxDQUFDLENBQUMsU0FBUyxDQUFDLEdBQVMsRUFBRTtnQkFDdkgsSUFBSSxDQUFDLGVBQWUsRUFBRSxDQUFDO1lBQzNCLENBQUMsQ0FBQyxDQUFDO1NBQ047SUFDTCxDQUFDO0lBRUQsK0ZBQStGO0lBQy9GLGtCQUFrQjtJQUNsQiwrRkFBK0Y7SUFDdkYsZ0JBQWdCO1FBQ3BCLElBQUksT0FBTyxJQUFJLENBQUMsT0FBTyxDQUFDLE1BQU0sS0FBSyxXQUFXLEVBQUU7WUFDNUMsSUFBSSxDQUFDLFVBQVUsR0FBRyxJQUFJLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxTQUFTLENBQUM7U0FDbkQ7YUFDSTtZQUNELElBQUksQ0FBQyxVQUFVLEdBQUcsVUFBVSxDQUFDO1NBQ2hDO0lBQ0wsQ0FBQztJQUVPLG1CQUFtQjtRQUN2QixJQUFJLE9BQU8sSUFBSSxDQUFDLFVBQVUsS0FBSyxXQUFXLEVBQUU7WUFDeEMsT0FBTyxJQUFJLENBQUMsVUFBVSxDQUFDLFFBQVEsRUFBRSxDQUFDO1NBQ3JDO1FBQ0QsT0FBTyxJQUFJLENBQUM7SUFDaEIsQ0FBQztJQUVPLGlCQUFpQjtRQUNyQixJQUFJLENBQUMsY0FBYyxDQUFDLElBQUksQ0FBQyxDQUFDLEVBQU8sRUFBRSxFQUFPLEVBQVUsRUFBRTtZQUNsRCxJQUFJLEVBQUUsR0FBRyxFQUFFO2dCQUFFLE9BQU8sQ0FBQyxDQUFDO2lCQUNqQixJQUFJLEVBQUUsR0FBRyxFQUFFO2dCQUFFLE9BQU8sQ0FBQyxDQUFDLENBQUM7WUFDNUIsT0FBTyxDQUFDLENBQUM7UUFDYixDQUFDLENBQUMsQ0FBQztJQUNQLENBQUM7OztZQTFPSixTQUFTLFNBQUM7Z0JBQ1AsUUFBUSxFQUFFLG1CQUFtQjtnQkFDN0IsUUFBUSxFQUFFOzs7Ozs7Ozs7Ozs7Ozs7O0tBZ0JUO2dCQUNELElBQUksRUFBRSxFQUFFLEtBQUssRUFBRyx1QkFBdUIsRUFBRTthQUM1Qzs7O1lBOUJRLGVBQWUiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBDb21wb25lbnQsIE9uRGVzdHJveSB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xyXG5pbXBvcnQgeyBTdWJzY3JpcHRpb24gfSBmcm9tICdyeGpzJztcclxuaW1wb3J0IHsgQWdSZW5kZXJlckNvbXBvbmVudCB9IGZyb20gJ2FnLWdyaWQtYW5ndWxhcic7XHJcbmltcG9ydCB7XHJcbiAgICBSb3dOb2RlLFxyXG4gICAgR3JpZEFwaSxcclxuICAgIC8vIElFbnRlcnByaXNlUm93TW9kZWwsXHJcbiAgICBJQ2VsbFJlbmRlcmVyUGFyYW1zXHJcbn0gZnJvbSAnYWctZ3JpZC1jb21tdW5pdHknO1xyXG5cclxuXHJcbmltcG9ydCB7IEtkSW50VGFibGVFdmVudCB9IGZyb20gJy4uL2tkLWFuZ3VsYXItdGFibGUtZXZlbnQnO1xyXG5cclxuaW50ZXJmYWNlIElLZFRhYmxlU2VsZWN0aW9uUGFyYW1zIGV4dGVuZHMgSUNlbGxSZW5kZXJlclBhcmFtcyB7XHJcbiAgICBwYXJhbXM6IHtcclxuICAgICAgICBpbnB1dFR5cGU/OiAncmFkaW8nIHwgJ2NoZWNrYm94JyxcclxuICAgICAgICBkZWZhdWx0PzogQXJyYXk8YW55PixcclxuICAgICAgICBncmlkSWQ/OiBzdHJpbmdcclxuICAgIH07XHJcbn1cclxuXHJcbkBDb21wb25lbnQoe1xyXG4gICAgc2VsZWN0b3I6ICdhZy1jaGVja2JveC1yYWRpbycsXHJcbiAgICB0ZW1wbGF0ZTogYFxyXG4gICAgICAgIDxkaXYgY2xhc3M9XCJzZWxlY3Rpb24td3JhcHBlclwiPlxyXG4gICAgICAgICAgICA8aW5wdXQgKm5nSWY9XCJfaXNIZWFkZXJcIiBjbGFzcz1cImNoZWNrYm94LXJhZGlvLWlucHV0XCJcclxuICAgICAgICAgICAgICAgIHR5cGU9XCJjaGVja2JveFwiXHJcbiAgICAgICAgICAgICAgICBbY2hlY2tlZF09XCJfc2VsZWN0QWxsXCJcclxuICAgICAgICAgICAgICAgIChjaGFuZ2UpPVwiX3VwZGF0ZUNoZWNrYm94KCRldmVudClcIlxyXG4gICAgICAgICAgICAvPlxyXG5cclxuICAgICAgICAgICAgPGlucHV0ICpuZ0lmPVwiIV9pc0hlYWRlclwiIGNsYXNzPVwiY2hlY2tib3gtcmFkaW8taW5wdXRcIlxyXG4gICAgICAgICAgICAgICAgW3R5cGVdPVwiX2lucHV0VHlwZVwiXHJcbiAgICAgICAgICAgICAgICBbYXR0ci5uYW1lXT1cIl9pbnB1dFR5cGVcIlxyXG4gICAgICAgICAgICAgICAgW2NoZWNrZWRdPVwiKF9wYXJhbU5vZGUpID8gX3BhcmFtTm9kZS5pc1NlbGVjdGVkKCkgOiBmYWxzZVwiXHJcbiAgICAgICAgICAgICAgICAoY2hhbmdlKT1cIl91cGRhdGVDaGVja2JveCgkZXZlbnQpXCJcclxuICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgPGxhYmVsPjwvbGFiZWw+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICBgLFxyXG4gICAgaG9zdDogeyBjbGFzcyA6ICdrZHgtYWctY2hlY2tib3gtcmFkaW8nIH1cclxufSlcclxuXHJcbmV4cG9ydCBjbGFzcyBLZFRhYmxlQ2hlY2tib3hSYWRpbyBpbXBsZW1lbnRzIEFnUmVuZGVyZXJDb21wb25lbnQsIE9uRGVzdHJveSB7XHJcbiAgICBwdWJsaWMgX2lucHV0VHlwZTogc3RyaW5nID0gJ2NoZWNrYm94JztcclxuICAgIHB1YmxpYyBfaXNIZWFkZXI6IGJvb2xlYW4gPSBmYWxzZTtcclxuICAgIHB1YmxpYyBfcGFyYW1Ob2RlOiBSb3dOb2RlO1xyXG4gICAgcHVibGljIF9zZWxlY3RBbGw6IGJvb2xlYW4gPSBmYWxzZTtcclxuXHJcbiAgICBwcml2YXRlIF9wYXJhbXM6IElLZFRhYmxlU2VsZWN0aW9uUGFyYW1zO1xyXG4gICAgcHJpdmF0ZSBfcGFyYW1zQXBpOiBHcmlkQXBpO1xyXG4gICAgcHJpdmF0ZSBfcGFyYW1zRGVmYXVsdDogQXJyYXk8c3RyaW5nIHwgbnVtYmVyPiA9IFtdO1xyXG4gICAgcHJpdmF0ZSBfcGFyYW1HcmlkSWQ6IHN0cmluZyA9ICdrZC10YWJsZS1ncmlkJztcclxuICAgIHByaXZhdGUgX3N1YnNjcmlwdGlvbk9iajoge1trZXk6IHN0cmluZ106IFN1YnNjcmlwdGlvbn0gPSB7fTtcclxuXHJcbiAgICBjb25zdHJ1Y3RvcihcclxuICAgICAgICBwcml2YXRlIF9rZEludFRhYmxlRXZlbnQ6IEtkSW50VGFibGVFdmVudFxyXG4gICAgKSB7IH1cclxuXHJcbiAgICAvKioqKioqKioqKioqKioqKioqKioqIENvbXBvbmVudCBMaWZlIGN5Y2xlcyBmdW5jdGlvbnMgKioqKioqKioqKioqKioqKioqKioqKioqKi9cclxuICAgIGFnSW5pdChfcGFyYW1zOiBhbnkpOiB2b2lkIHtcclxuICAgICAgICAvLyBjb25zb2xlLmxvZyhcIi0tIEdyaWQgc3RhdGU6IENoZWNrYm94L1JhZGlvIGFnSW5pdCAtLVwiLCBfcGFyYW1zKTtcclxuICAgICAgICB0aGlzLl9wYXJhbXMgPSBfcGFyYW1zO1xyXG4gICAgICAgIHRoaXMuX3BhcmFtc0FwaSA9IHRoaXMuX3BhcmFtcy5hcGk7XHJcbiAgICAgICAgdGhpcy5fcGFyYW1HcmlkSWQgPSB0aGlzLl9wYXJhbXMucGFyYW1zLmdyaWRJZDtcclxuICAgICAgICB0aGlzLl9pc0hlYWRlciA9IHR5cGVvZiB0aGlzLl9wYXJhbXMucm93SW5kZXggPT09ICd1bmRlZmluZWQnO1xyXG5cclxuICAgICAgICB0aGlzLl9nZXREZWZhdWx0U2VsZWN0aW9uKCk7XHJcbiAgICAgICAgdGhpcy5fdXBkYXRlSW5wdXRUeXBlKCk7XHJcblxyXG4gICAgICAgIGlmICghdGhpcy5faXNIZWFkZXIpIHtcclxuICAgICAgICAgICAgdGhpcy5fcGFyYW1Ob2RlID0gdGhpcy5fcGFyYW1zLm5vZGU7XHJcbiAgICAgICAgICAgIHRoaXMuX3VwZGF0ZUluaXRpYWxTZWxlY3Rpb24oKTtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIHRoaXMuX3NldHVwU3Vic2NyaXB0aW9uRXZlbnRzKCk7XHJcbiAgICB9XHJcblxyXG4gICAgcmVmcmVzaChfcGFyYW1zOiBhbnkpOiBib29sZWFuIHtcclxuICAgICAgICByZXR1cm4gZmFsc2U7XHJcbiAgICB9XHJcblxyXG4gICAgbmdPbkRlc3Ryb3koKTogdm9pZCB7XHJcbiAgICAgICAgZm9yIChsZXQgaXRlbSBpbiB0aGlzLl9zdWJzY3JpcHRpb25PYmopIHtcclxuICAgICAgICAgICAgaWYgKHRoaXMuX3N1YnNjcmlwdGlvbk9iai5oYXNPd25Qcm9wZXJ0eShpdGVtKSkge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5fc3Vic2NyaXB0aW9uT2JqW2l0ZW1dLnVuc3Vic2NyaWJlKCk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgcHVibGljIF91cGRhdGVDaGVja2JveChfZXZlbnQ6IGFueSk6IHZvaWQge1xyXG4gICAgICAgIC8vIGNvbnNvbGUubG9nKFwiLS0gR3JpZCBzdGF0ZTogQ2hlY2tib3gvUmFkaW8gY2hlY2tlZCAtLVwiKVxyXG4gICAgICAgIGxldCBpbnB1dFRhcmdldDogSFRNTElucHV0RWxlbWVudCA9IDxIVE1MSW5wdXRFbGVtZW50PmV2ZW50LnRhcmdldDtcclxuICAgICAgICB0aGlzLl91cGRhdGVTZWxlY3Rpb24oaW5wdXRUYXJnZXQuY2hlY2tlZCk7XHJcbiAgICB9XHJcblxyXG4gICAgLyoqKioqKioqKioqKioqKioqKioqKioqKioqKiogUHJpdmF0ZSBmdW5jdGlvbnMgKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKiovXHJcbiAgICAvLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vL1xyXG4gICAgLy8vIFVwZGF0ZSBmdW5jdGlvbnNcclxuICAgIC8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vXHJcbiAgICBwcml2YXRlIF91cGRhdGVTZWxlY3Rpb24oX2lzQ2hlY2tlZDogYm9vbGVhbik6IHZvaWQge1xyXG4gICAgICAgIGlmICh0aGlzLl9pc0hlYWRlcikge1xyXG4gICAgICAgICAgICB0aGlzLl9zZWxlY3RBbGwgPSBfaXNDaGVja2VkO1xyXG4gICAgICAgICAgICB0aGlzLl91cGRhdGVBbGxDaGVja2JveCgpO1xyXG5cclxuICAgICAgICB9XHJcbiAgICAgICAgZWxzZSB7XHJcbiAgICAgICAgICAgIGlmICh0aGlzLl9pbnB1dFR5cGUgPT09ICdjaGVja2JveCcpIHtcclxuICAgICAgICAgICAgICAgIHRoaXMuX3BhcmFtTm9kZS5zZWxlY3RUaGlzTm9kZShfaXNDaGVja2VkKTtcclxuICAgICAgICAgICAgICAgIHRoaXMuX3VwZGF0ZURlZmF1bHRWYWx1ZSh0aGlzLl9wYXJhbU5vZGUuaWQsIF9pc0NoZWNrZWQpO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5fcGFyYW1zQXBpLmRlc2VsZWN0QWxsKCk7XHJcbiAgICAgICAgICAgICAgICB0aGlzLl9wYXJhbU5vZGUuc2VsZWN0VGhpc05vZGUodHJ1ZSk7XHJcbiAgICAgICAgICAgICAgICB0aGlzLl91cGRhdGVEZWZhdWx0VmFsdWUodGhpcy5fcGFyYW1Ob2RlLmlkLCB0cnVlLCB0cnVlKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgdGhpcy5fZW1pdFNlbGVjdGlvbkNoYW5nZWQoKTtcclxuICAgIH1cclxuXHJcbiAgICAvLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vL1xyXG4gICAgLy8vIENoZWNrYm94IC8gQ2hlY2tib3ggYWxsIGZ1bmN0aW9uc1xyXG4gICAgLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy9cclxuICAgIC8vIHByaXZhdGUgX3VwZGF0ZUFsbENoZWNrYm94KCk6IHZvaWQge1xyXG4gICAgLy8gICAgIGxldCBjdXJyZW50TW9kZWwgPSB0aGlzLl9nZXRDdXJyZW50Um93TW9kZWwoKTtcclxuXHJcbiAgICAvLyAgICAgaWYgKGN1cnJlbnRNb2RlbCAhPT0gbnVsbCkge1xyXG4gICAgLy8gICAgICAgICBjdXJyZW50TW9kZWwuZm9yRWFjaE5vZGUoKF9yb3dOb2RlOiBSb3dOb2RlKTogdm9pZCA9PiB7XHJcbiAgICAvLyAgICAgICAgICAgICBfcm93Tm9kZS5zZWxlY3RUaGlzTm9kZSh0aGlzLl9zZWxlY3RBbGwpO1xyXG4gICAgLy8gICAgICAgICAgICAgdGhpcy5fdXBkYXRlRGVmYXVsdFZhbHVlKF9yb3dOb2RlLmRhdGEuaWQsIHRoaXMuX3NlbGVjdEFsbCk7XHJcbiAgICAvLyAgICAgICAgIH0pO1xyXG4gICAgLy8gICAgIH1cclxuICAgIC8vIH1cclxuXHJcbiAgICAvLyBTZWxlY3QgaXMgd29ya2luZyBwcm9wZXJseSBcclxuICAgIHByaXZhdGUgX3VwZGF0ZUFsbENoZWNrYm94KCk6IHZvaWQge1xyXG4gICAgICAgIGxldCBjdXJyZW50TW9kZWw6IGFueSA9IHRoaXMuX2dldEN1cnJlbnRSb3dNb2RlbCgpO1xyXG4gICAgICAgIGlmIChjdXJyZW50TW9kZWwgIT09IG51bGwpIHtcclxuICAgICAgICAgICAgaWYoY3VycmVudE1vZGVsICYmIGN1cnJlbnRNb2RlbC5yb3dzVG9EaXNwbGF5ICYmIGN1cnJlbnRNb2RlbC5yb3dzVG9EaXNwbGF5Lmxlbmd0aClcclxuICAgICAgICAgICAge1xyXG4gICAgICAgICAgICAgICAgY3VycmVudE1vZGVsLnJvd3NUb0Rpc3BsYXkuZm9yRWFjaCgoX3Jvd05vZGUpPT57XHJcbiAgICAgICAgICAgICAgICAgICAgX3Jvd05vZGUuc2VsZWN0VGhpc05vZGUodGhpcy5fc2VsZWN0QWxsKTtcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLl91cGRhdGVEZWZhdWx0VmFsdWUoX3Jvd05vZGUuaWQsIHRoaXMuX3NlbGVjdEFsbCk7XHJcbiAgICAgICAgICAgICAgICB9KSBcclxuICAgICAgICAgICAgfWVsc2V7XHJcbiAgICAgICAgICAgICAgICBjdXJyZW50TW9kZWwuZm9yRWFjaE5vZGUoKF9yb3dOb2RlOiBSb3dOb2RlKTogdm9pZCA9PiB7XHJcbiAgICAgICAgICAgICAgICBfcm93Tm9kZS5zZWxlY3RUaGlzTm9kZSh0aGlzLl9zZWxlY3RBbGwpO1xyXG4gICAgICAgICAgICAgICAgdGhpcy5fdXBkYXRlRGVmYXVsdFZhbHVlKF9yb3dOb2RlLmRhdGEuaWQsIHRoaXMuX3NlbGVjdEFsbCk7XHJcbiAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgXHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX2NoZWNrU2VsZWN0QWxsKCk6IHZvaWQge1xyXG4gICAgICAgIGxldCBjdXJyZW50TW9kZWwgPSB0aGlzLl9nZXRDdXJyZW50Um93TW9kZWwoKTtcclxuICAgICAgICBsZXQgc2VsZWN0QWxsOiBib29sZWFuID0gdHJ1ZTtcclxuICAgICAgICBpZiAoY3VycmVudE1vZGVsICE9PSBudWxsKSB7XHJcbiAgICAgICAgICAgIGlmIChjdXJyZW50TW9kZWwuZ2V0Um93Q291bnQoKSA9PT0gMCkge1xyXG4gICAgICAgICAgICAgICAgc2VsZWN0QWxsID0gZmFsc2U7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgZWxzZSB7XHJcbiAgICAgICAgICAgICAgICBjdXJyZW50TW9kZWwuZm9yRWFjaE5vZGUoKF9yb3dOb2RlOiBSb3dOb2RlKTogdm9pZCA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKHNlbGVjdEFsbCAmJiAhX3Jvd05vZGUuaXNTZWxlY3RlZCgpKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHNlbGVjdEFsbCA9IGZhbHNlO1xyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgICAgIHRoaXMuX3NlbGVjdEFsbCA9IHNlbGVjdEFsbDtcclxuICAgIH1cclxuICAgIC8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vXHJcbiAgICAvLy8gRGVmYXVsdCB2YWx1ZSBmdW5jdGlvbnNcclxuICAgIC8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vXHJcbiAgICBwcml2YXRlIF91cGRhdGVJbml0aWFsU2VsZWN0aW9uKCk6IHZvaWQge1xyXG4gICAgICAgIGxldCBpc1NlbGVjdGVkOiBib29sZWFuID0gZmFsc2U7XHJcblxyXG4gICAgICAgIGlmICh0eXBlb2YgdGhpcy5fcGFyYW1zRGVmYXVsdCAhPT0gJ3VuZGVmaW5lZCcpIHtcclxuICAgICAgICAgICAgZm9yIChsZXQgaTogbnVtYmVyID0gMDsgaSA8IHRoaXMuX3BhcmFtc0RlZmF1bHQubGVuZ3RoOyArK2kpIHtcclxuICAgICAgICAgICAgICAgIGlmICh0aGlzLl9wYXJhbXNEZWZhdWx0W2ldLnRvU3RyaW5nKCkgPT09IHRoaXMuX3BhcmFtTm9kZS5pZCkge1xyXG4gICAgICAgICAgICAgICAgICAgIGlzU2VsZWN0ZWQgPSB0cnVlO1xyXG4gICAgICAgICAgICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICB0aGlzLl9wYXJhbU5vZGUuc2VsZWN0VGhpc05vZGUoaXNTZWxlY3RlZCk7XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfZ2V0RGVmYXVsdFNlbGVjdGlvbigpOiB2b2lkIHtcclxuICAgICAgICBpZiAodHlwZW9mIHRoaXMuX3BhcmFtcy5wYXJhbXMgIT09ICd1bmRlZmluZWQnICYmXHJcbiAgICAgICAgICAgIHR5cGVvZiB0aGlzLl9wYXJhbXMucGFyYW1zLmRlZmF1bHQgIT09ICd1bmRlZmluZWQnKSB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLl9wYXJhbXNEZWZhdWx0ID0gdGhpcy5fcGFyYW1zLnBhcmFtcy5kZWZhdWx0O1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF91cGRhdGVEZWZhdWx0VmFsdWUoX2lkOiBudW1iZXIgfCBzdHJpbmcsIF9pc1NlbGVjdGVkOiBib29sZWFuLCBfdG9FbXB0eURlZmF1bHQ/OiBib29sZWFuKTogdm9pZCB7XHJcbiAgICAgICAgaWYgKF90b0VtcHR5RGVmYXVsdCkge1xyXG4gICAgICAgICAgICB0aGlzLl9wYXJhbXNEZWZhdWx0LnNwbGljZSgwLCB0aGlzLl9wYXJhbXNEZWZhdWx0Lmxlbmd0aCk7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICBpZiAoX2lzU2VsZWN0ZWQgJiYgdGhpcy5fcGFyYW1zRGVmYXVsdC5pbmRleE9mKF9pZCkgPCAwKSB7XHJcbiAgICAgICAgICAgIHRoaXMuX3BhcmFtc0RlZmF1bHQucHVzaChfaWQpO1xyXG4gICAgICAgIH1cclxuICAgICAgICBlbHNlIGlmICghX2lzU2VsZWN0ZWQgJiYgdGhpcy5fcGFyYW1zRGVmYXVsdC5pbmRleE9mKF9pZCkgPiAtMSkge1xyXG4gICAgICAgICAgICB0aGlzLl9wYXJhbXNEZWZhdWx0LnNwbGljZSh0aGlzLl9wYXJhbXNEZWZhdWx0LmluZGV4T2YoX2lkKSwgMSk7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIHRoaXMuX3NvcnREZWZhdWx0VmFsdWUoKTtcclxuICAgIH1cclxuXHJcbiAgICAvLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vL1xyXG4gICAgLy8vIEV2ZW50cyAtIFN1YnNjcmliZXIgLyBPbiBmdW5jdGlvbnNcclxuICAgIC8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vXHJcbiAgICBwcml2YXRlIF9lbWl0U2VsZWN0aW9uQ2hhbmdlZCgpOiB2b2lkIHtcclxuICAgICAgICB0aGlzLl9rZEludFRhYmxlRXZlbnQuc2VsZWN0aW9uQ2hhbmdlZCh0aGlzLl9wYXJhbUdyaWRJZCwgdGhpcy5fcGFyYW1Ob2RlKTtcclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF9zZXR1cFN1YnNjcmlwdGlvbkV2ZW50cygpOiB2b2lkIHtcclxuICAgICAgICBpZiAodGhpcy5faXNIZWFkZXIpIHtcclxuICAgICAgICAgICAgdGhpcy5fc3Vic2NyaXB0aW9uT2JqLmhlYWRlckNoZWNrYm94U3ViID0gdGhpcy5fa2RJbnRUYWJsZUV2ZW50Lm9uTW9kZWxDaGFuZ2VkKHRoaXMuX3BhcmFtR3JpZElkKS5zdWJzY3JpYmUoKCk6IHZvaWQgPT4ge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5fY2hlY2tTZWxlY3RBbGwoKTtcclxuICAgICAgICAgICAgfSk7XHJcblxyXG4gICAgICAgICAgICB0aGlzLl9zdWJzY3JpcHRpb25PYmouc2VsZWN0ZWRDaGFuZ2VTdWIgPSB0aGlzLl9rZEludFRhYmxlRXZlbnQub25TZWxlY3Rpb25DaGFuZ2VkKHRoaXMuX3BhcmFtR3JpZElkKS5zdWJzY3JpYmUoKCk6IHZvaWQgPT4ge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5fY2hlY2tTZWxlY3RBbGwoKTtcclxuICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIC8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vXHJcbiAgICAvLy8gTWlzYyBmdW5jdGlvbnNcclxuICAgIC8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vXHJcbiAgICBwcml2YXRlIF91cGRhdGVJbnB1dFR5cGUoKTogdm9pZCB7XHJcbiAgICAgICAgaWYgKHR5cGVvZiB0aGlzLl9wYXJhbXMucGFyYW1zICE9PSAndW5kZWZpbmVkJykge1xyXG4gICAgICAgICAgICB0aGlzLl9pbnB1dFR5cGUgPSB0aGlzLl9wYXJhbXMucGFyYW1zLmlucHV0VHlwZTtcclxuICAgICAgICB9XHJcbiAgICAgICAgZWxzZSB7XHJcbiAgICAgICAgICAgIHRoaXMuX2lucHV0VHlwZSA9ICdjaGVja2JveCc7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX2dldEN1cnJlbnRSb3dNb2RlbCgpIHtcclxuICAgICAgICBpZiAodHlwZW9mIHRoaXMuX3BhcmFtc0FwaSAhPT0gJ3VuZGVmaW5lZCcpIHtcclxuICAgICAgICAgICAgcmV0dXJuIHRoaXMuX3BhcmFtc0FwaS5nZXRNb2RlbCgpO1xyXG4gICAgICAgIH1cclxuICAgICAgICByZXR1cm4gbnVsbDtcclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF9zb3J0RGVmYXVsdFZhbHVlKCk6IHZvaWQge1xyXG4gICAgICAgIHRoaXMuX3BhcmFtc0RlZmF1bHQuc29ydCgoX2E6IGFueSwgX2I6IGFueSk6IG51bWJlciA9PiB7XHJcbiAgICAgICAgICAgIGlmIChfYSA+IF9iKSByZXR1cm4gMTtcclxuICAgICAgICAgICAgZWxzZSBpZiAoX2EgPCBfYikgcmV0dXJuIC0xO1xyXG4gICAgICAgICAgICByZXR1cm4gMDtcclxuICAgICAgICB9KTtcclxuICAgIH1cclxufVxyXG4iXX0=