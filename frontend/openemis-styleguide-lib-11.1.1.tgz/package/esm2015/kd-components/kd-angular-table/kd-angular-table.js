import { Component, ViewEncapsulation, Input, HostBinding, HostListener, ViewContainerRef, EventEmitter, Output } from '@angular/core';
import { Router } from '@angular/router';
import { Observable, timer } from 'rxjs';
import 'ag-grid-enterprise';
import * as XLSX from 'xlsx';
import { saveAs } from 'file-saver';
import { KdTableDatasourceEvent, KdTableSelectionUpdateEvent, KdTableInputUpdateEvent, KdTableButtonEvent } from './kd-angular-table-interface';
import { KdIntTableEvent } from './kd-angular-table-event';
import { KdTableNormalSvc } from './table-services/kd-table-normal-svc';
import { KdTableEnterpriseSvc } from './table-services/kd-table-enterprise-svc';
// import { KdSplitterEvent } from '../';
import { KdDomElemSvc, AG_GRID_KEY } from '../kd-common/index';
import { LicenseManager } from "ag-grid-enterprise";
/**
 * -- Documentation for kd-angular-table.ts (kd-table)
 *
 * - HostListener
 *     - onResize
 *
 * - Life cycles:
 *     - ngOnInit
 *     - ngOnChanges
 *     - ngOnDestroy

 * - ag-Grid events function:
 *     - onGridReady
 *     - onModelUpdated
 *     - onRowClicked
 *
 * - kd-table button function:
 *     - onButtonClicekd
 *
 * - Private functions:
 *     - Display / DOM functions:
 *         - _resizeColumn
 *         - _showLoadingOverlay
 *         - _updateParentNodeCSS
 *         - _setHeight
 *         - _setMobileHeight (flatten table)
 *         - _setWebHeighr (user configuration)
 *         - _isClickValid (click configuration)
 *
 *     - Grid Cycles:
 *         - _gridInitCycle
 *         - _gridReadyCycle
 *         - _gridReadyEnterpriseCycle
 *         - _gridReadyDOMCycle
 *         - _gridSelectionCycle
 *         - _gridSetRowCycle
 *         - _gridClickNavigateCycle
 *
 *     - Column / Row / Config generations/processing:
 *         - _setGridOptions
 *         - _setColumnDef
 *         - _setRowData
 *
 *     - Event functions:
 *         - _processEventParams<T>
 *         - _broadcastEventParams
 *         - _broadcastModelChanged
 *         - _setupSubscriptionEvents
 *
 *     - Selection functions:
 *         - _updateSelectionNodes
 *         - _processInitialSelection
 *
 *     - Input functions:
 *         - _processInputChanged
 *         - _emitInputUpdateEvent
 *         - _deleteNodeFromRowData
 *
 *     - Datasource functions:
 *         - _clearDatasource
 *         - _generateEnterpriseDatasource
 *         - _generateDatasourceRows
 *
 *     - API generations:
 *         - _initITableApi (TODO: update api setting all to table service)
 *
 *     - Misc functions:
 *         - _initGridService
 *         - _updateGridConfig
 */
export class KdTable {
    constructor(_vcr, _router, _domSvc, 
    // private _splitterEvent: KdSplitterEvent,
    _tableIntEvent) {
        this._vcr = _vcr;
        this._router = _router;
        this._domSvc = _domSvc;
        this._tableIntEvent = _tableIntEvent;
        this.gridId = '';
        this.displayLoading = true;
        this._singleClickEdit = false;
        this._enterprise = require('ag-grid-enterprise');
        this._subscriptionObj = {};
        this._currentState = {
            columnState: [],
            pivotMode: false,
            groupState: []
        };
        this._isChangingState = false;
        this._pivotElement = {
            'pivot': null,
            'column-drop': null
        };
        this._suppressMovableColumns = true;
        this._direction = 'ltr';
        this.onExportPossible = new EventEmitter();
        this._classKdxTable = true;
        this.editingModeEnabled = false;
        LicenseManager.setLicenseKey(AG_GRID_KEY.value);
    }
    onResize(_event) {
        this._setHeight();
    }
    /************************* Life cycles functions *****************************/
    ngOnInit() {
        // console.log("-- Grid state: Init --", this.row, this.column, this.config, this.api);
        this._showLoadingOverlay(true);
        this._gridInitCycle();
    }
    ngOnChanges(_simpleChanges) {
        this._showLoadingOverlay(true);
        console.log("-- Grid state: Change -- ", _simpleChanges);
        if (typeof _simpleChanges.column !== 'undefined' &&
            !_simpleChanges.column.firstChange) {
            this._setColumnDef(_simpleChanges.column.currentValue);
            this._showLoadingOverlay(false);
        }
        if (typeof _simpleChanges.row !== 'undefined' &&
            !_simpleChanges.row.firstChange) {
            this._setRowData(_simpleChanges.row.currentValue);
            this._showLoadingOverlay(false);
        }
        if (typeof _simpleChanges.config !== 'undefined') {
            this._showLoadingOverlay(false);
            this.updateStyle(_simpleChanges.config.currentValue);
            timer(100).subscribe(() => {
                this._configurePivotDisplay();
                if (typeof this.config.suppressMovableColumns !== 'undefined') {
                    if (this.config.suppressMovableColumns !== this._suppressMovableColumns)
                        this._enableColumnMovable(this.config.suppressMovableColumns);
                }
                else {
                    this.config.suppressMovableColumns = this._suppressMovableColumns;
                }
            });
        }
    }
    ngOnDestroy() {
        // console.log("-- Grid state: Destroying --");
        for (let item in this._subscriptionObj) {
            if (typeof this._subscriptionObj[item] !== 'undefined') {
                this._subscriptionObj[item].unsubscribe();
            }
        }
    }
    setAttendance(displayEditTable, _config) {
        // let allColumns = this.gridOptions.columnApi.getAllColumns()
        // allColumns.forEach((column, index) => {
        //     let currentColumnDef = column.getColDef()
        //     console.log(`column ${index+1}`, currentColumnDef)
        // })
        if (displayEditTable) {
            this.gridOptions.context.mode = 'edit';
            _config.context.mode = 'edit';
            _config.rowContentHeight = 120;
        }
        else {
            this.gridOptions.context.mode = 'view';
            _config.context.mode = 'view';
        }
        let _columns = this.gridOptions.columnApi.getAllDisplayedColumns();
        // let colDef = _columns[2].getColDef()
        // console.log(colDef);
        // colDef.cellRendererParams = '<p>Hello</p>'
        // let newData = []
        // newData.push(colDef)
        this.gridOptions.columnApi.setValueColumns(_columns);
    }
    toggleEdits(data) {
        if (this.editTable && !this.displayEditable) {
            this.editingModeEnabled = !this.editingModeEnabled;
            this._singleClickEdit = !this._singleClickEdit;
            let _columns = this.gridOptions.columnApi.getAllDisplayedColumns();
            let newColumnData = [];
            _columns.forEach((column) => {
                let columnDef = column === null || column === void 0 ? void 0 : column.getColDef();
                if (columnDef.canEdit == true) {
                    columnDef.cellStyle = function (params) {
                        if (!isNaN(parseFloat(params.value)) && parseFloat(params.value) < 50) {
                            return { color: '#CC5C5C' };
                        }
                        else {
                            return { color: '#333' };
                        }
                    },
                        columnDef.cellClassRules = {
                            'oe-cell-highlight': function (params) {
                                return 1;
                            },
                            'oe-cell-error': function (params) {
                                // return params.data.save_error[params.colDef.field];
                            }
                        },
                        columnDef.cellRendererParams = {
                            shouldBeEditing: () => this.editingModeEnabled,
                        },
                        columnDef.editable = (params) => {
                            var name = params.node.data.name;
                            params.data.name = params.node.data.name;
                            return name;
                        },
                        columnDef.newValueHandler = (params) => {
                            if (data == 'text') {
                                let valueAsFloat = params.newValue;
                                params.data[params.colDef.field] = valueAsFloat;
                            }
                            else {
                                let valueAsFloat = parseFloat(params.newValue);
                                console.log(valueAsFloat, "valueAsFloat");
                                if (valueAsFloat <= 100) {
                                    params.data[params.colDef.field] = valueAsFloat;
                                }
                            }
                            console.log(params.data[params.colDef.field], "params.data[params.colDef.field]");
                            // return true;
                        };
                }
                newColumnData.push(columnDef);
            });
            this.gridOptions.columnApi.setValueColumns(newColumnData);
        }
        else if (this.displayEditable) {
            this.editingModeEnabled = !this.editingModeEnabled;
            this._singleClickEdit = !this._singleClickEdit;
            let _columns = this.gridOptions.columnApi.getAllDisplayedColumns();
            let newColumnData = [];
            _columns.forEach((column) => {
                let columnDef = column === null || column === void 0 ? void 0 : column.getColDef();
                if (columnDef.canEdit == true) {
                    columnDef.valueGetter = function (params) {
                        var value = params.data[params.colDef.field];
                        if (data == 'text') {
                            return value;
                        }
                        else {
                            if (!isNaN(parseFloat(value))) {
                                return value;
                            }
                            else {
                                return '';
                            }
                        }
                    },
                        columnDef.cellClassRules = {},
                        columnDef.cellRendererParams = {
                            shouldBeEditing: () => this.editingModeEnabled,
                        },
                        columnDef.editable = (params) => {
                            return false;
                        };
                }
                newColumnData.push(columnDef);
            });
            this.gridOptions.columnApi.setValueColumns(newColumnData);
        }
    }
    setAttendanceStaff(displayEditTable) {
        if (displayEditTable) {
            this.gridOptions.context.action = 'edit';
        }
        else {
            this.gridOptions.context.action = 'view';
        }
        let _columns = this.gridOptions.columnApi.getAllDisplayedColumns();
        this.gridOptions.columnApi.setValueColumns(_columns);
        this._showLoadingOverlay(false);
    }
    setStudentMeal(displayEditTable) {
        if (displayEditTable) {
            this.gridOptions.context.mode = 'edit';
        }
        else {
            this.gridOptions.context.mode = 'view';
        }
        let _columns = this.gridOptions.columnApi.getAllDisplayedColumns();
        this.gridOptions.columnApi.setValueColumns(_columns);
        this._showLoadingOverlay(false);
    }
    /******************************* Grid events *********************************/
    onGridReady(_params) {
        // console.log('-- Grid state: Ready --', this.gridOptions);
        this._gridReadyCycle();
    }
    onModelUpdated(_event) {
        /// For select all checkbox checking on change pagination/update row data
        if (this._tableService.hasSelectionAll(this.config)) {
            this._broadcastModelChangedEvent();
        }
        if (this._isMobileView) {
            let gridElement = document.querySelector('#' + this.gridId + '.stg-theme');
            if (gridElement !== null) {
                this._setMobileHeight(gridElement);
            }
        }
    }
    onRowClicked(_params) {
        // console.log("-- Grid state: Row clicked --", _params);
        if (this._isClickValid(_params.event) && typeof this.config.click !== 'undefined' && !this.editTable) {
            switch (this.config.click.type) {
                case 'selection':
                    this._gridSelectionCycle(_params.node);
                    break;
                case 'router':
                    this._gridClickNavigateCycle(_params.node);
                    break;
                default:
                    break;
            }
            if (typeof this.config.click.callback !== 'undefined') {
                this.config.click.callback();
            }
        }
    }
    /***************************** Button functions ******************************/
    onButtonClicked(_button) {
        let buttonEvent = new KdTableButtonEvent(_button);
        this._processEventParams('button', buttonEvent);
    }
    /**************************** Private functions ******************************/
    ////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// Grid cycles
    ////////////////////////////////////////////////////////////////////////////////////////////////////////
    _gridInitCycle() {
        if (typeof this.config !== 'undefined') {
            this._initGridService(this.config.loadType);
            this._updateGridConfig(this.config);
            this._setGridOptions(this.config);
            this._setupSubscriptionEvents();
        }
        if (typeof this.column !== 'undefined') {
            this._setColumnDef(this.column);
        }
        if (typeof this.row !== 'undefined') {
            this._setRowData(this.row);
        }
    }
    _gridReadyCycle() {
        this._initITableApi();
        if (this._tableService.isEnterpriseModel(this.config.loadType)) {
            this._gridReadyEnterpriseCycle();
        }
        this._gridReadyDOMCycle();
    }
    _gridReadyEnterpriseCycle() {
        this._clearDatasource();
        this._generateEnterpriseDatasource();
    }
    _gridReadyDOMCycle() {
        this._updateParentNodeCSS();
        this._setHeight();
        this._resizeColumn();
    }
    _gridSelectionCycle(_rowNode) {
        if (typeof this.config.selection === 'undefined') {
            console.error('KdTable error: User have set click type to be selection but no selection is defined. Do you mean click type to router?');
        }
        else if (this.config.selection.type === 'single') {
            if (this.config.selection.value.indexOf(_rowNode.id) < 0) {
                this.gridOptions.api.deselectAll();
                _rowNode.selectThisNode(true);
                this.config.selection.value.splice(0, this.config.selection.value.length);
                this.config.selection.value.push(_rowNode.data.id);
                this._broadcastModelChangedEvent();
                this._updateSelectionNodes(_rowNode);
            }
        }
        else {
            let selection = !_rowNode.isSelected();
            _rowNode.selectThisNode(selection);
            this._broadcastModelChangedEvent();
            if (selection) {
                this.config.selection.value.push(_rowNode.data.id);
            }
            else {
                this.config.selection.value.splice(this.config.selection.value.indexOf(_rowNode.data.id), 1);
            }
            this._updateSelectionNodes(_rowNode);
        }
    }
    _gridSetRowCycle() {
        if (typeof this.config.selection !== 'undefined' && typeof this.config.selection.type !== 'undefined') {
            this._processInitialSelection();
        }
        else if (this._tableService.hasInputType(this.column, 'input')) {
            this._emitInputUpdateEvent();
        }
    }
    _gridClickNavigateCycle(_rowNode) {
        if (typeof this.config.click.pathMap !== 'undefined') {
            if (typeof this.config.action !== 'undefined' &&
                typeof this.config.action.list !== 'undefined') {
                let routerPath = '';
                for (let i = 0; i < this.config.action.list.length; ++i) {
                    let actionItem = this.config.action.list[i];
                    if (actionItem.type.toLowerCase() === this.config.click.pathMap.toLowerCase()) {
                        routerPath = this._tableService.getRouterPlaceholderPath(_rowNode, actionItem.path);
                        break;
                    }
                }
                if (routerPath !== '') {
                    this._router.navigate([routerPath]);
                }
                else {
                    console.warn('KdTable warning: Table router pathMap not found. pathMap set to:', this.config.click.pathMap);
                }
            }
            else {
                console.error('KdTable error: Table click event set to router pathMap but no action list is defined. Do you mean path property instead of pathMap property?');
            }
        }
        else if (typeof this.config.click.path !== 'undefined') {
            this._router.navigate([this.config.click.path]);
        }
        else {
            console.error('KdTable error: Table click event type set at router but no path / pathMap is provided. Do you mean click type selection / none?');
        }
    }
    ////////////////////////////////////////////////////////////////////////////////////////////////////////
    // Display / DOM function
    ////////////////////////////////////////////////////////////////////////////////////////////////////////
    _showLoadingOverlay(_toggle) {
        this.displayLoading = _toggle;
    }
    _updateParentNodeCSS() {
        this._vcr.element.nativeElement.parentNode.className += ' has-aggrid';
        if (this._direction === 'rtl')
            document.querySelector('body').style.cssText += '--kdtable-header-text-align: right;';
    }
    _setHeight() {
        let domEleQuery = '#' + this.gridId + '.stg-theme';
        let gridElement = this._vcr.element.nativeElement.querySelector(domEleQuery);
        if (gridElement !== null) {
            let windowsWidth = document.body.clientWidth;
            if (windowsWidth <= 1024) {
                if (typeof this._isMobileView === 'undefined' || !this._isMobileView) {
                    this._showLoadingOverlay(true);
                    this._isMobileView = true;
                    this._setMobileHeight(gridElement);
                }
            }
            else if (windowsWidth > 1024) {
                if (typeof this._isMobileView === 'undefined' || this._isMobileView) {
                    this._showLoadingOverlay(true);
                    this._isMobileView = false;
                    this._setWebGridHeight(gridElement, this.config.gridHeight);
                }
                else {
                    this.gridOptions.api.sizeColumnsToFit();
                }
            }
        }
    }
    /**
     * add border bottom dynamically so that when the row is lesser than body-container, there wont be any hanging border bottom
     * when the row is more than container, there will be a border-bottom
     */
    _setTableBorderBottom() {
        let containerEleQuery = ' .ag-body-container';
        let containerEle = this._vcr.element.nativeElement.querySelector(containerEleQuery);
        if (containerEle === null)
            return;
        let viewportEleQuery = ' .ag-body-viewport';
        let viewportEle = this._vcr.element.nativeElement.querySelector(viewportEleQuery);
        if (containerEle.clientHeight > viewportEle.clientHeight &&
            viewportEle.className &&
            viewportEle.className.indexOf('has-border-bottom') === -1) {
            viewportEle.className += ' has-border-bottom';
        }
        else if (containerEle.clientHeight < viewportEle.clientHeight) {
            viewportEle.className = viewportEle.className.replace(/has-border-bottom/gi, '');
        }
    }
    _setMobileHeight(_gridElement) {
        let newHeight = 0;
        if (this.config.loadType !== 'infinite') {
            let agHeaderEle = this._vcr.element.nativeElement.querySelector('.ag-header');
            let agBodyEle = this._vcr.element.nativeElement.querySelector('.ag-body-container');
            let agPagePanelEle = this._vcr.element.nativeElement.querySelector('div[ref="south"]');
            newHeight = 25;
            if (agHeaderEle !== null) {
                newHeight += agHeaderEle.clientHeight;
            }
            if (agBodyEle !== null) {
                newHeight += agBodyEle.clientHeight;
            }
            if (agPagePanelEle !== null) {
                newHeight += agPagePanelEle.clientHeight;
            }
        }
        else {
            newHeight = 400;
        }
        this._domSvc.setElementStyle(_gridElement, 'height', newHeight + 'px');
        timer(10).subscribe(() => {
            this.gridOptions.api.sizeColumnsToFit();
            this._showLoadingOverlay(false);
        });
    }
    /**
     * [_setWebGridHeight number for pixel or string "auto"]
     *  _configHeight [description]
     */
    _setWebGridHeight(_gridElement, _configHeight) {
        if (typeof _configHeight === 'number') {
            let gridHeight = 600;
            if (typeof _configHeight !== 'undefined') {
                gridHeight = _configHeight;
            }
            this._domSvc.setElementStyle(_gridElement, 'height', gridHeight + 'px');
        }
        else if (_configHeight === 'auto') {
            this.displayFull = true;
        }
        // else if (_configHeight === 'rowHeight') {
        //     this.gridOptions.domLayout = 'autoHeight';
        //     delete this.gridOptions.rowHeight;
        //     delete this.gridOptions.getRowHeight;
        // }
        timer().subscribe(() => {
            this.gridOptions.api.sizeColumnsToFit();
            this._showLoadingOverlay(false);
        });
    }
    _isClickValid(_event) {
        let targetElement = _event.target;
        let invalidList = ['action-btn', 'checkbox-radio-input', 'fa-chevron-down'];
        for (let i = 0; i < invalidList.length; i++) {
            if (targetElement.classList.contains(invalidList[i])) {
                return false;
            }
        }
        return true;
    }
    _resizeColumn(_isResizeToContent = false) {
        if (this._tableService.isApiReady(this.gridOptions)) {
            timer(10).subscribe(() => {
                (_isResizeToContent) ? this._resizeColumnToContent() : this.gridOptions.api.sizeColumnsToFit();
                this.onExportPossible.emit(true);
                this._showLoadingOverlay(false);
            });
        }
    }
    /**
     * resize column to colDef width
     */
    _resizeColumnToContent() {
        let allColumnIds = [];
        this.gridOptions.columnApi.getAllDisplayedColumns().forEach((column) => {
            allColumnIds.push(column.getColId());
        });
        this.gridOptions.columnApi.autoSizeColumns(allColumnIds);
    }
    /**
     * populate dynamic styling value
     * param {ITableConfig} _config: tableConfig
     */
    updateStyle(_config) {
        if (!_config || !_config.config) {
            document.querySelector('body').style.cssText = '';
            return;
        }
        let config = _config.config;
        let bodyCss = '';
        bodyCss += this._updateHeaderStyle(config);
        if (config.body) {
            if (config.body.alternateRow === true) {
                if (config.body.odd && config.body.odd.backgroundColor) {
                    bodyCss += '--kdtable-row-odd-background: ' + config.body.odd.backgroundColor + ';';
                }
                if (config.body.even && config.body.even.backgroundColor) {
                    bodyCss += '--kdtable-row-even-background: ' + config.body.even.backgroundColor + ';';
                }
            }
            if (config.body.style) {
                if (config.body.style.borderWidth) {
                    bodyCss += '--kdtable-body-border-width: ' + config.body.style.borderWidth + ';';
                    bodyCss += '--kdtable-header-border-width: ' + config.body.style.borderWidth + ';';
                }
                if (config.body.style.borderColor) {
                    bodyCss += '--kdtable-body-border-color: ' + config.body.style.borderColor + ';';
                    bodyCss += '--kdtable-header-border-color: ' + config.body.style.borderColor + ';';
                }
                if (config.body.style.borderStyle) {
                    bodyCss += '--kdtable-body-border-style: ' + config.body.style.borderStyle + ';';
                    bodyCss += '--kdtable-header-border-style: ' + config.body.style.borderStyle + ';';
                }
            }
        }
        document.querySelector('body').style.cssText = bodyCss;
    }
    _updateHeaderStyle(_config) {
        if (!_config.header || !_config.header.style)
            return '';
        let bodyCss = '';
        let styleNames = [
            'backgroundColor',
            'textAlign',
            'verticalAlign',
            'color',
            'fontFamily',
            'fontSize',
            'fontWeight',
            'fontStyle',
            'textDecoration',
            // 'borderWidth',
            // 'borderColor',
            // 'borderStyle',
            'opacity'
        ];
        for (let i = 0; i < styleNames.length; ++i) {
            let styleName = styleNames[i];
            let value = _config.header.style[styleName];
            if (styleName === 'verticalAlign')
                value = this._getAlignItem(value);
            styleName = (styleName === 'backgroundColor') ? 'background' : styleName.replace(/([a-z])([A-Z])/g, '$1-$2').toLowerCase();
            if (typeof value !== 'undefined') {
                if (styleName === 'borderWidth' &&
                    (typeof value !== 'string' || value.indexOf('px') === -1))
                    value += 'px';
                bodyCss += '--kdtable-header-' + styleName + ': ' + value + ';';
            }
        }
        return bodyCss;
    }
    /**
     * convert text align into flex-box item align
     * param {string} _verticalAlign: text verticalAlign
     */
    _getAlignItem(_verticalAlign) {
        if (_verticalAlign === 'baseline' || _verticalAlign === 'bottom') {
            return 'flex-end';
        }
        else if (_verticalAlign === 'top') {
            return 'flex-start';
        }
        else { // including invalid input
            if (_verticalAlign !== 'middle' && _verticalAlign !== undefined) {
                console.warn('ERROR: the vertical align value of ' + _verticalAlign + ' is not yet recognised by KdTable. Please only use either top, center or bottom');
            }
            return 'center';
        }
    }
    // private _refreshTable(_tableCellParams?: ITableCellParams): void {
    //     if (this._tableService && this._tableService.isApiReady && this._tableService.isApiReady(this.gridOptions)) {
    //         let toUpdateNode: Array<RowNode> = [];
    //         let allColumnIds: Array<string> = [];
    //         if (!_tableCellParams) {
    //             this.gridOptions.columnApi.getAllDisplayedColumns().forEach((column) => {
    //                 allColumnIds.push(column.getColId());
    //             });
    //         }
    //         this.gridOptions.api.forEachNode((_rowNode: RowNode): void => {
    //             if (_tableCellParams && typeof _rowNode.id !== 'undefined' && _rowNode.id === _tableCellParams.rowId) {
    //                 _rowNode.data[_tableCellParams.colId] = _tableCellParams.data;
    //                 toUpdateNode.push(_rowNode);
    //             } else {
    //                 toUpdateNode.push(_rowNode);
    //             }
    //         });
    //         let refreshParams: { rowNodes: Array<RowNode>, columns: Array<any> } = {
    //             rowNodes: toUpdateNode,
    //             columns: (_tableCellParams) ? [_tableCellParams.colId] : allColumnIds
    //         };
    //         this.gridOptions.api.refreshCells(refreshParams);
    //     }
    // }
    ////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// Pivot Function
    ////////////////////////////////////////////////////////////////////////////////////////////////////////
    _isToolpanelTypeChanged() {
        let isTypeChanged = true;
        if (this._previousToolpanelType) {
            if (typeExist(this.config)) {
                isTypeChanged = this._previousToolpanelType !== this.config.pivot.toolpanel.type;
            }
        }
        else {
            if (typeExist(this.config)) {
                this._previousToolpanelType = this.config.pivot.toolpanel.type;
            }
        }
        return isTypeChanged;
        function typeExist(_config) {
            return _config && _config.pivot && _config.pivot.toolpanel && _config.pivot.toolpanel.type;
        }
    }
    _configurePivotDisplay() {
        let isStateChanged = true;
        if (this.config && this.config.pivot && this.config.pivot.state && this.config.pivot.state.columnState) {
            isStateChanged = this.config.pivot.state.columnState.length !== this._currentState.columnState.length;
        }
        if (this.config.loadType !== 'normal' || (this._isToolpanelTypeChanged() === false && isStateChanged === false))
            return;
        let showToolPanel = false;
        let showPivotMode = false;
        if (this.config.pivot && this.config.pivot.toolpanel) {
            showToolPanel = this.config.pivot.toolpanel.type !== 'none';
            showPivotMode = this.config.pivot.toolpanel.type === 'pivot';
        }
        this._showToolPanel(showToolPanel);
        this._showPivotMode(showPivotMode);
    }
    /**
     * resize column to fit table container if the width of the content column is smaller than container
     */
    _pivotResize() {
        let container = this._vcr.element.nativeElement.querySelector('.ag-header-container');
        let header = this._vcr.element.nativeElement.querySelector('.ag-header-container .ag-header-row');
        this._resizeColumn(header.getBoundingClientRect().width > container.getBoundingClientRect().width);
    }
    _resetPivotColumn() {
        this.gridOptions.columnApi.setRowGroupColumns([]);
        this.gridOptions.columnApi.setPivotColumns([]);
        this.gridOptions.columnApi.setValueColumns([]);
        this.gridOptions.columnApi.setSecondaryColumns([]);
    }
    /**
     * pass state to application.
     * (if setState was triggered before), wait until setState has done processing
     * return {ITablePivotState} [description]
     */
    _getPivotState() {
        // if state is changing, wait until state has been updated then get the most updated state
        let getState = () => {
            this._currentState.columnState = this.gridOptions.columnApi.getColumnState();
            this._currentState.pivotMode = this.gridOptions.columnApi.isPivotMode();
            this._currentState.groupState = this.gridOptions.columnApi.getColumnGroupState();
            return this._currentState;
        };
        let check = () => {
            return this._isChangingState === false;
        };
        return this.wait(check, getState);
    }
    /**
     * replace current state if a state is given, expandGroup base on config
     * should wait until column is present.
     * param {ITablePivotState} _state
     */
    _setPivotState(_state) {
        if (typeof (_state) === 'undefined' || !_state.hasOwnProperty('columnState'))
            return;
        let setState = () => {
            this._isChangingState = true;
            if (_state.columnState.length === 0) {
                this._isChangingState = false;
                this._pivotResize();
                return;
            }
            this._currentState = Object.assign(this._currentState, _state);
            this.gridOptions.columnApi.setColumnState(_state.columnState);
            this.gridOptions.columnApi.setPivotMode(_state.pivotMode || false);
            this.gridOptions.columnApi.setColumnGroupState(_state.groupState || []);
            this._isChangingState = false;
            timer(100).subscribe(() => {
                this._setPivotColumns();
                this._expandGroup();
            });
        };
        let check = () => {
            return this.column && this.column.length > 0;
        };
        this.wait(check, setState);
    }
    /**
     * wait for something to finish then do something, breaks at 100th to prevent infinite loop
     * param {ITablePivotState} _state
     * return {any}
     */
    wait(_check, _do, _limitCounter = 0) {
        if ((_check() && this._tableService.isApiReady(this.gridOptions)) || _limitCounter === 100) {
            if (_limitCounter === 100)
                console.log('Timeout: check fails. running', _do);
            return _do();
        }
        else {
            timer(10).subscribe(() => {
                _limitCounter++;
                this.wait(_check, _do, _limitCounter);
            });
        }
    }
    _isPivotElmExist(_pivotElement) {
        return (typeof _pivotElement['pivot'] !== 'undefined' &&
            _pivotElement['pivot'] !== null &&
            typeof _pivotElement['column-drop'] !== 'undefined' &&
            _pivotElement['column-drop'] !== null);
    }
    /**
     * show pivot mode checkbox and label.
     * when pivot mode is hidden, all pivot data has to be reset.
     * param {boolean = true} _show: true to show, false to hide
     */
    _showPivotMode(_show = true) {
        let setPivotMode = () => {
            if (_show === true) {
                this._pivotElement['pivot'].className = this._pivotElement['pivot'].className.replace(/ hidden/gi, '');
                for (let i = 0; i < this._pivotElement['column-drop'].length; ++i) {
                    this._pivotElement['column-drop'][i].className = this._pivotElement['column-drop'][i].className.replace(/ hidden/gi, '');
                }
                this._setPivotState(this.config.pivot && this.config.pivot.state ? this.config.pivot.state : {});
                return;
            }
            if (this._pivotElement['pivot'] &&
                this._pivotElement['pivot'].className &&
                this._pivotElement['pivot'].className.indexOf('hidden') === -1) {
                this._pivotElement['pivot'].className += ' hidden';
                for (let j = 0; j < this._pivotElement['column-drop'].length; ++j) {
                    this._pivotElement['column-drop'][j].className += ' hidden';
                }
            }
            this._enabledPivotMode(false);
            this._setPivotState({
                'columnState': [],
                'pivotMode': false,
                'groupState': []
            });
            this._resetPivotColumn();
        };
        let check = () => {
            // if (this.config.pivot.toolpanel.type === 'none' || !this.config.pivot || !this.config.pivot.toolpanel) return true;
            if (this.config.pivot &&
                this.config.pivot.toolpanel &&
                this.config.pivot.toolpanel.type &&
                this.config.pivot.toolpanel.type !== 'none') {
                let isPivotElmExist = this._isPivotElmExist(this._pivotElement);
                if (isPivotElmExist === true)
                    return isPivotElmExist;
                let domEleQuery = '#' + this.gridId + '.stg-theme .ag-side-bar';
                this._pivotElement['pivot'] = this._vcr.element.nativeElement.querySelector(domEleQuery + ' .ag-pivot-mode-panel');
                this._pivotElement['column-drop'] = this._vcr.element.nativeElement.querySelectorAll(domEleQuery + ' .ag-column-drop');
                return this._isPivotElmExist(this._pivotElement);
            }
            else {
                return true;
            }
        };
        this.wait(check, setPivotMode);
    }
    /**
     * hide and show toolpanel (pivot mode panel)
     * param {boolean} _show: true to show, false to hide
     */
    _showToolPanel(_show) {
        if (this._tableService.isApiReady(this.gridOptions)) {
            timer(10).subscribe(() => {
                this.gridOptions.api.showToolPanel(_show);
            });
        }
    }
    /**
     * expand row group base on the status that passed in
     * param {boolean} _expand: true to expand, false to collapse
     */
    _expandGroup(_expand) {
        if (typeof _expand === 'undefined') {
            _expand = false;
            if (this.config.pivot && this.config.pivot.state && this.config.pivot.state.expandGroup) {
                _expand = this.config.pivot.state.expandGroup;
            }
        }
        if (this._tableService.isApiReady(this.gridOptions)) {
            timer(10).subscribe(() => {
                (_expand) ? this.gridOptions.api.expandAll() : this.gridOptions.api.collapseAll();
                this._pivotResize();
            });
        }
    }
    /**
     * turn on and off pivot mode
     * If on, 'Column Label' will appear
     * If on, tick column name on toolpanel will assign column to 'Row Group' / 'Values' depends on colDef
     * If off, tick column name on toolpanel will trigger column hide and show
     * param {boolean = false} _enabled: true to check, false to uncheck
     */
    _enabledPivotMode(_enabled = false) {
        this.gridOptions.columnApi.setPivotMode(_enabled);
    }
    // TODO: to be revisit
    /**
     * suppressMovableColumns on pivotColumns and rowGroupColumns
     * columns on pivot mode does not listen to colDef.suppressMovableColumns = true
     * hence we need to access their private variable lockPosition and lockPinned to suppress the column movement
     * param {any} _columns [either passed in from gridEvent: column or will getAllDisplayedColumns]
     */
    _setPivotColumns(_columns) {
        let isPinned = false;
        if (!_columns)
            _columns = this.gridOptions.columnApi.getAllDisplayedColumns();
        _columns.forEach((column) => {
            this._setColumn(column);
            let columnDef = column.getColDef();
            if (columnDef.pivotValueColumn) {
                this._setColumn(columnDef.pivotValueColumn);
            }
            else {
                if (column.parent) {
                    isPinned = true;
                    this._setColumn(column.parent, false);
                    column.parent.pinned = 'left';
                    column.pinned = 'left';
                    columnDef.pinned = 'left';
                }
            }
        });
        if (isPinned)
            this._resizeColumn(true);
    }
    _setColumn(_column, _isSetColDef = true) {
        if (_isSetColDef) {
            let columnDef = _column.getColDef();
            columnDef.suppressMovable = this._suppressMovableColumns;
            columnDef.lockPosition = this._suppressMovableColumns;
            columnDef.lockPinned = this._suppressMovableColumns;
        }
        if (_column.setMoving) {
            _column.setMoving(!this._suppressMovableColumns);
        }
        else {
            _column.moving = !this._suppressMovableColumns;
        }
        _column.lockPosition = this._suppressMovableColumns;
        _column.lockPinned = this._suppressMovableColumns;
    }
    // TODO: to be revisit
    ////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// Column/Row/Configuration Generation
    ////////////////////////////////////////////////////////////////////////////////////////////////////////
    _setGridOptions(_tableConfig) {
        if (_tableConfig.hasOwnProperty('suppressMovableColumns'))
            this._suppressMovableColumns = _tableConfig.suppressMovableColumns;
        this._direction = this._domSvc.getDocumentDirection();
        this.gridOptions = this._tableService.generateGridOptions(_tableConfig, this._direction);
        this.gridOptions.context['gridId'] = this.gridId;
        this.gridOptions.suppressMovableColumns = false;
        this.gridOptions.onColumnRowGroupChanged = (params) => {
            this._setPivotColumns(params.columns);
            this._expandGroup();
        };
        this._tableService.setGridOptions(this.gridOptions);
    }
    _setColumnDef(_colDefConfig) {
        this._tableService.setColumnDef(_colDefConfig, this.config, this._suppressMovableColumns);
        this._resizeColumn();
    }
    _enableColumnMovable(_enabled = true) {
        if (this._tableService.isApiReady(this.gridOptions)) {
            this._suppressMovableColumns = _enabled;
            this._setColumnDef(this.column);
            if (this.config.loadType === 'normal' && this.config.pivot.toolpanel.type === 'pivot') {
                this._setPivotState(this._currentState);
            }
            this._pivotResize();
        }
    }
    _setRowData(_rowData, _setToGridOptions = true) {
        // this._tableService.updateRowDataWithColumnConfig(_rowData, this.column, this.gridId);
        this._tableService.updateRowDataWithColumn(_rowData, this.column, this.gridId, this.gridOptions);
        if (_setToGridOptions) {
            this._tableService.setRowData(_rowData);
        }
        if (this._tableService.isEnterpriseModel(this.config.loadType) && this._tableService.isApiReady(this.gridOptions)) {
            this._gridReadyEnterpriseCycle();
        }
        timer().subscribe(() => {
            this._gridSetRowCycle();
            this._setTableBorderBottom();
        });
    }
    ////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// Events - Subscriber / On functions
    ////////////////////////////////////////////////////////////////////////////////////////////////////////
    _processEventParams(_fromEvent, _additionalParams) {
        switch (_fromEvent) {
            case 'datasource':
            case 'selection':
            case 'input':
            case 'button':
                this._broadcastEventParams(_additionalParams);
                break;
            default:
                console.error('KdTable warning: No such event found for: ', _fromEvent);
        }
    }
    _broadcastEventParams(_params) {
        this._tableIntEvent.kdTableEventList(this.config.id, _params);
    }
    _broadcastModelChangedEvent() {
        this._tableIntEvent.modelChanged(this.config.id);
    }
    _setupSubscriptionEvents() {
        this._subscriptionObj.selectNodesSub = this._tableIntEvent.onSelectionChanged(this.config.id).subscribe((_rowNode) => {
            this._updateSelectionNodes(_rowNode);
        });
        this._subscriptionObj.gridQuestionSub = this._tableIntEvent.onInputChanged(this.config.id).subscribe((_formParams) => {
            this._processInputChanged(_formParams);
        });
        this._subscriptionObj.updateEmitRow = this._tableIntEvent.onUpdateEmitRowNodes(this.config.id).subscribe((_data) => {
            if (_data.action === 'delete') {
                let rowKey = (typeof this.config.rowIdKey !== 'undefined') ? this.config.rowIdKey : 'id';
                this._deleteNodeFromRowData([_data.rowData[rowKey]]);
                this._emitInputUpdateEvent();
            }
        });
    }
    ////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// Selection - Checkbox / Radio functions
    ////////////////////////////////////////////////////////////////////////////////////////////////////////
    _updateSelectionNodes(_rowNode, _isInitial) {
        let triggerNode = (typeof _isInitial !== 'undefined' && _isInitial) ? 'initial' : 'all';
        if (typeof _rowNode !== 'undefined') {
            triggerNode = _rowNode.data.id;
        }
        let selectionParams = new KdTableSelectionUpdateEvent();
        selectionParams.triggerNode = triggerNode;
        selectionParams.selectedNodes = this._tableService.updateSelectionValues(this.gridOptions.rowData, this.config.selection.value, this.config.selection.returnKey, this.config.loadType);
        // selectionParams.selection = (_rowNode.isSelected()) ? 'selected' : 'unselected';
        this._processEventParams('selection', selectionParams);
    }
    _processInitialSelection() {
        this._updateSelectionNodes(undefined, true);
    }
    ////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// Input functions
    ////////////////////////////////////////////////////////////////////////////////////////////////////////
    _processInputChanged(_formParams) {
        let inputParams = new KdTableInputUpdateEvent();
        inputParams.colId = _formParams.colId;
        inputParams.rowId = _formParams.rowId;
        inputParams.questionKey = _formParams.questionKey;
        inputParams.question = _formParams.question;
        inputParams.value = _formParams.data;
        this._processEventParams('input', inputParams);
    }
    _emitInputUpdateEvent() {
        let inputParams = new KdTableInputUpdateEvent();
        this._processEventParams('input', inputParams);
    }
    _deleteNodeFromRowData(_dataList) {
        let rowIdKey = (typeof this.config.rowIdKey !== 'undefined') ? this.config.rowIdKey : 'id';
        for (let i = 0; i < _dataList.length; ++i) {
            for (let j = 0; j < this.row.length; ++j) {
                if (_dataList[i].toString() === this.row[j][rowIdKey].toString()) {
                    this.row.splice(j, 1);
                    break;
                }
            }
        }
    }
    ////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// Enterprise datasource functions
    ////////////////////////////////////////////////////////////////////////////////////////////////////////
    _clearDatasource() {
        if (this._tableService.isApiReady(this.gridOptions)) {
            this.gridOptions.api.setEnterpriseDatasource(null);
            this.gridOptions.api.setFilterModel(null);
            this.gridOptions.api.setSortModel(null);
            if (typeof this._subscriptionObj.datasourceSub !== 'undefined') {
                this._subscriptionObj.datasourceSub.unsubscribe();
            }
        }
    }
    _generateEnterpriseDatasource() {
        let datasource = {
            getRows: (_params) => {
                this._showLoadingOverlay(true);
                if (typeof this._subscriptionObj.datasourceSub !== 'undefined') {
                    this._subscriptionObj.datasourceSub.unsubscribe();
                }
                this._subscriptionObj.datasourceSub = this._generateDatasourceRows(_params).subscribe((_response) => {
                    _params.successCallback(_response.rows, _response.total);
                    this._showLoadingOverlay(false);
                });
            }
        };
        this.gridOptions.api.setEnterpriseDatasource(datasource);
    }
    _generateDatasourceRows(_datasourceParams) {
        return new Observable((_observer) => {
            switch (this.config.loadType) {
                case 'infinite':
                case 'oneshot':
                    this._tableService.generateDatasourceRows(_datasourceParams.request, this.gridOptions.rowData.slice()).subscribe((_response) => {
                        _observer.next(_response);
                        _observer.complete();
                    });
                    break;
                case 'server':
                    let serverParams = new KdTableDatasourceEvent(_datasourceParams.request, _observer);
                    this._processEventParams('datasource', serverParams);
                    break;
                default:
                    console.error('KdTable warning: No such loadType find for: ', this.config.loadType);
                    _observer.complete();
            }
        });
    }
    ////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// API functions
    ////////////////////////////////////////////////////////////////////////////////////////////////////////
    _initITableApi() {
        if (typeof this.api !== 'undefined') {
            let apiParams = {
                // gridOptions: this.gridOptions,
                event: this._tableIntEvent,
                id: this.config.id,
                rows: this.row,
                columns: this.column
            };
            this._tableService.generatedApiFunctions(this.api, apiParams);
            /// Temp fix to access loading variable //
            /********* General API **********/
            this.api.general.showLoading = (_toggle) => {
                this.displayLoading = _toggle;
            };
            this.api.general.updateCell = (_tableCellParams) => {
                let toUpdateNode = [];
                this.gridOptions.api.forEachNode((_rowNode) => {
                    if (typeof _rowNode.id !== 'undefined' && _rowNode.id === _tableCellParams.rowId) {
                        _rowNode.data[_tableCellParams.colId] = _tableCellParams.data;
                        toUpdateNode.push(_rowNode);
                    }
                });
                let refreshParams = {
                    rowNodes: toUpdateNode,
                    columns: [_tableCellParams.colId]
                };
                this.gridOptions.api.refreshCells(refreshParams);
            };
            this.api.general.searchRow = (_searchText) => {
                if (this.config.loadType === 'normal') {
                    this.gridOptions.api.setQuickFilter(_searchText);
                }
                else {
                    console.warn('KdTable warning: Quick filtering of data is not supported for oneshot/server/infinite loadType.');
                }
            };
            this.api.general.addRows = (_rows, _scrollToVisible = false) => {
                /*
                    ag-Grid did not export RowDataTransaction interface. Interface as:
                        {
                            add: [],
                            remove: [],
                            update: []
                        }
                 */
                if (typeof this.config.loadType === 'undefined' || this.config.loadType === 'normal') {
                    let rowKey = (typeof this.config.rowIdKey !== 'undefined') ? this.config.rowIdKey : 'id';
                    for (let i = 0; i < _rows.length; ++i) {
                        this.row.push(_rows[i]);
                    }
                    this._setRowData(this.row, false);
                    this.gridOptions.api.updateRowData({ add: _rows.slice() });
                    if (_scrollToVisible) {
                        this.gridOptions.api.ensureIndexVisible(this.gridOptions.api.getRowNode(_rows[0][rowKey].toString()).rowIndex);
                    }
                }
                else {
                    console.warn('KdTable warning: API function: addRows() can only be used for normal loadType.');
                }
            };
            this.api.general.deleteRows = (_id) => {
                if (typeof this.config.loadType === 'undefined' || this.config.loadType === 'normal') {
                    let deleteIdList = [];
                    if (typeof _id === 'string' || typeof _id === 'number') {
                        deleteIdList.push(_id.toString());
                    }
                    else {
                        for (let i = 0; i < _id.length; ++i) {
                            deleteIdList.push(_id.toString());
                        }
                    }
                    this._deleteNodeFromRowData(deleteIdList);
                    let key = typeof this.config.rowIdKey === 'undefined' ? 'id' : this.config.rowIdKey;
                    let deleteRows = [];
                    for (let i = 0; i < deleteIdList.length; ++i) {
                        deleteRows.push({ [key]: deleteIdList[i] });
                    }
                    /*
                        ag-Grid did not export RowDataTransaction interface. Interface as:
                            {
                                add: [],
                                remove: [],
                                update: []
                            }
                     */
                    let transactionObj = {
                        remove: deleteRows
                    };
                    this.gridOptions.api.updateRowData(transactionObj);
                    this._emitInputUpdateEvent();
                }
                else {
                    console.warn('KdTable warning: API function: addRows() can only be used for normal loadType.');
                }
            };
            this.api.general.setButtonDisabled = (_buttonType, _toDisabled) => {
                for (let i = 0; i < this.config.button.length; ++i) {
                    if (this.config.button[i].type === _buttonType) {
                        this.config.button[i].disabled = _toDisabled;
                    }
                }
            };
            this.api.general.exportToExcel = (_params) => {
                let defaultParams = {
                    fileName: 'file',
                    allColumns: true,
                    suppressTextAsCDATA: true,
                };
                // xlsx only allow sheet name to be 31 characters long;
                if (_params.hasOwnProperty('sheetName'))
                    _params.sheetName = _params.sheetName.slice(0, 31);
                let params = Object.assign({}, defaultParams, _params);
                let content = this.gridOptions.api.getDataAsExcel(params);
                let workbook = XLSX.read(content, { type: 'binary' });
                let xlsxContent = XLSX.write(workbook, { bookType: 'xlsx', type: 'base64' });
                let blobObject = this._tableService.b64toBlob(xlsxContent, 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
                saveAs(blobObject, params.fileName + '.xlsx');
            };
            this.api.general.resizeColumn = (_isResizeToContent = false) => {
                this._resizeColumn(_isResizeToContent);
            };
            this.api.general.enableColumnMovable = (_enabled) => {
                this._enableColumnMovable(_enabled);
            };
            /********* Pivot API **********/
            if (typeof (this.api.pivot) === 'undefined')
                this.api.pivot = {};
            this.api.pivot.autoResize = () => {
                this._pivotResize();
            };
            this.api.pivot.showToolPanel = (_show) => {
                this._showToolPanel(_show);
            };
            this.api.pivot.expandGroup = (_expand) => {
                this._expandGroup(_expand);
            };
            this.api.pivot.getPivotState = () => {
                return this._getPivotState();
            };
            this.api.pivot.setPivotState = (_state) => {
                this._setColumnDef(this.column);
                this._setPivotState(_state);
            };
            this.api.pivot.enabledPivotMode = (_enabled) => {
                this._enabledPivotMode(_enabled);
            };
            this.api.pivot.showPivotMode = (_show) => {
                this._showPivotMode(_show);
            };
            /********* Input API **********/
            this.api.dynamicForm.clearAllError = () => {
                let tableContext = this.gridOptions.context[this._tableService.getTableContextKey()];
                for (let item in tableContext) {
                    if (tableContext.hasOwnProperty(item)) {
                        let contextItem = tableContext[item];
                        for (let question in contextItem) {
                            if (contextItem.hasOwnProperty(question)) {
                                if (typeof contextItem[question].errors === 'undefined') {
                                    contextItem[question].errors = [];
                                }
                                contextItem[question].errors.length = 0;
                            }
                        }
                    }
                }
            };
        }
        else {
            console.warn('KdTable warning: No api property / undefined api property is passed in.');
        }
    }
    ////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// Misc functions
    ////////////////////////////////////////////////////////////////////////////////////////////////////////
    _initGridService(_loadType) {
        if (typeof _loadType === 'undefined' || _loadType === 'normal') {
            this._tableService = new KdTableNormalSvc();
        }
        else {
            this._tableService = new KdTableEnterpriseSvc();
        }
    }
    _updateGridConfig(_gridConfig) {
        this.gridId = this._tableService.getGridId(_gridConfig);
        this._tableService.updateGridButtons(_gridConfig);
        this._tableService.updateSelectDefaultValue(_gridConfig);
    }
}
KdTable.decorators = [
    { type: Component, args: [{
                selector: 'kd-table',
                template: "<div class=\"kdx kdx-ag-grid-wrapper\">\r\n    <!-- <kd-progressloader *ngIf=\"displayLoading\" configtype=\"small-spinner\" [configvalue]=\"null\"></kd-progressloader> -->\r\n    <div *ngIf=\"config?.button?.length > 0\" class=\"gird-btn-wrapper\">\r\n        <button *ngFor=\"let item of config.button\" class=\"btn btn-icon\" type='button' [disabled]=\"item.disabled\" (click)=\"onButtonClicked(item)\">\r\n            <i [ngClass]=\"item.icon\"></i>\r\n            <span>{{item.label}}</span>\r\n        </button>\r\n    </div>\r\n    <ag-grid-angular\r\n    \t#agGrid\r\n    \tid=\"{{gridId}}\"\r\n    \tclass=\"stg-theme\"\r\n    \t[ngClass]=\"{'ag-row-clickable': config.click}\"\r\n        [gridOptions]=\"gridOptions\"\r\n        [rowDragManaged]=\"true\"\r\n        [singleClickEdit]=\"_singleClickEdit\"\r\n        (gridReady)=\"onGridReady($event)\"\r\n        (modelUpdated)=\"onModelUpdated($event)\"\r\n        (rowClicked)=\"onRowClicked($event)\"\r\n    ></ag-grid-angular>\r\n</div>",
                encapsulation: ViewEncapsulation.None,
                providers: [KdDomElemSvc, KdIntTableEvent, KdTableNormalSvc, KdTableEnterpriseSvc],
                host: { 'class': 'kdx-table' }
            },] }
];
KdTable.ctorParameters = () => [
    { type: ViewContainerRef },
    { type: Router },
    { type: KdDomElemSvc },
    { type: KdIntTableEvent }
];
KdTable.propDecorators = {
    row: [{ type: Input }],
    column: [{ type: Input }],
    config: [{ type: Input }],
    api: [{ type: Input }],
    editTable: [{ type: Input }],
    displayEditable: [{ type: Input }],
    onExportPossible: [{ type: Output }],
    displayFull: [{ type: HostBinding, args: ['class.full-grid',] }],
    _classKdxTable: [{ type: HostBinding, args: ['class.kdx-table',] }],
    onResize: [{ type: HostListener, args: ['window:resize', ['$event'],] }]
};
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoia2QtYW5ndWxhci10YWJsZS5qcyIsInNvdXJjZVJvb3QiOiJEOi9vcGVuRU1JUy9zdHlsZWd1aWRlL2lvc3RnLW9wZW5lbWlzLXN0eWxlZ3VpZGUvcHJvamVjdHMvb3BlbmVtaXMtc3R5bGVndWlkZS1saWIvc3JjLyIsInNvdXJjZXMiOlsia2QtY29tcG9uZW50cy9rZC1hbmd1bGFyLXRhYmxlL2tkLWFuZ3VsYXItdGFibGUudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsT0FBTyxFQUNILFNBQVMsRUFLVCxpQkFBaUIsRUFDakIsS0FBSyxFQUNMLFdBQVcsRUFDWCxZQUFZLEVBQ1osZ0JBQWdCLEVBQ2hCLFlBQVksRUFDWixNQUFNLEVBQ1QsTUFBTSxlQUFlLENBQUM7QUFDdkIsT0FBTyxFQUFFLE1BQU0sRUFBRSxNQUFNLGlCQUFpQixDQUFDO0FBQ3pDLE9BQU8sRUFBRSxVQUFVLEVBQUUsS0FBSyxFQUE0QixNQUFNLE1BQU0sQ0FBQztBQW9CbkUsT0FBTyxvQkFBb0IsQ0FBQztBQUM1QixPQUFPLEtBQUssSUFBSSxNQUFNLE1BQU0sQ0FBQztBQUM3QixPQUFPLEVBQUUsTUFBTSxFQUFFLE1BQU0sWUFBWSxDQUFDO0FBRXBDLE9BQU8sRUFXSCxzQkFBc0IsRUFDdEIsMkJBQTJCLEVBQzNCLHVCQUF1QixFQUN2QixrQkFBa0IsRUFDckIsTUFBTSw4QkFBOEIsQ0FBQztBQUV0QyxPQUFPLEVBQUUsZUFBZSxFQUFFLE1BQU0sMEJBQTBCLENBQUM7QUFDM0QsT0FBTyxFQUFFLGdCQUFnQixFQUFFLE1BQU0sc0NBQXNDLENBQUM7QUFDeEUsT0FBTyxFQUFFLG9CQUFvQixFQUFFLE1BQU0sMENBQTBDLENBQUM7QUFDaEYseUNBQXlDO0FBQ3pDLE9BQU8sRUFBRSxZQUFZLEVBQUUsV0FBVyxFQUFFLE1BQU0sb0JBQW9CLENBQUM7QUFDL0QsT0FBTyxFQUFFLGNBQWMsRUFBRSxNQUFNLG9CQUFvQixDQUFDO0FBSXBEOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7R0FxRUc7QUFZSCxNQUFNLE9BQU8sT0FBTztJQXdDaEIsWUFDWSxJQUFzQixFQUN0QixPQUFlLEVBQ2YsT0FBcUI7SUFDN0IsMkNBQTJDO0lBQ25DLGNBQStCO1FBSi9CLFNBQUksR0FBSixJQUFJLENBQWtCO1FBQ3RCLFlBQU8sR0FBUCxPQUFPLENBQVE7UUFDZixZQUFPLEdBQVAsT0FBTyxDQUFjO1FBRXJCLG1CQUFjLEdBQWQsY0FBYyxDQUFpQjtRQTVDcEMsV0FBTSxHQUFXLEVBQUUsQ0FBQztRQUdwQixtQkFBYyxHQUFZLElBQUksQ0FBQztRQUMvQixxQkFBZ0IsR0FBWSxLQUFLLENBQUM7UUFDakMsZ0JBQVcsR0FBRyxPQUFPLENBQUMsb0JBQW9CLENBQUMsQ0FBQztRQUc1QyxxQkFBZ0IsR0FBb0MsRUFBRSxDQUFDO1FBRXZELGtCQUFhLEdBQXFCO1lBQ3RDLFdBQVcsRUFBRSxFQUFFO1lBQ2YsU0FBUyxFQUFFLEtBQUs7WUFDaEIsVUFBVSxFQUFFLEVBQUU7U0FDakIsQ0FBQztRQUNNLHFCQUFnQixHQUFZLEtBQUssQ0FBQztRQUNsQyxrQkFBYSxHQUEyQjtZQUM1QyxPQUFPLEVBQUUsSUFBSTtZQUNiLGFBQWEsRUFBRSxJQUFJO1NBQ3RCLENBQUM7UUFFTSw0QkFBdUIsR0FBWSxJQUFJLENBQUM7UUFFeEMsZUFBVSxHQUFrQixLQUFLLENBQUM7UUFVaEMscUJBQWdCLEdBQTBCLElBQUksWUFBWSxFQUFFLENBQUM7UUFFdkMsbUJBQWMsR0FBWSxJQUFJLENBQUM7UUFHeEQsdUJBQWtCLEdBQVksS0FBSyxDQUFDO1FBUXZDLGNBQWMsQ0FBQyxhQUFhLENBQUMsV0FBVyxDQUFDLEtBQUssQ0FBQyxDQUFDO0lBQ3BELENBQUM7SUFHRCxRQUFRLENBQUMsTUFBYTtRQUNsQixJQUFJLENBQUMsVUFBVSxFQUFFLENBQUM7SUFDdEIsQ0FBQztJQUVELCtFQUErRTtJQUMvRSxRQUFRO1FBQ0osdUZBQXVGO1FBQ3ZGLElBQUksQ0FBQyxtQkFBbUIsQ0FBQyxJQUFJLENBQUMsQ0FBQztRQUMvQixJQUFJLENBQUMsY0FBYyxFQUFFLENBQUM7SUFDMUIsQ0FBQztJQUVELFdBQVcsQ0FBQyxjQUE2QjtRQUNyQyxJQUFJLENBQUMsbUJBQW1CLENBQUMsSUFBSSxDQUFDLENBQUM7UUFDL0IsT0FBTyxDQUFDLEdBQUcsQ0FBQywyQkFBMkIsRUFBRSxjQUFjLENBQUMsQ0FBQztRQUV6RCxJQUFJLE9BQU8sY0FBYyxDQUFDLE1BQU0sS0FBSyxXQUFXO1lBQzVDLENBQUMsY0FBYyxDQUFDLE1BQU0sQ0FBQyxXQUFXLEVBQ3BDO1lBQ0UsSUFBSSxDQUFDLGFBQWEsQ0FBQyxjQUFjLENBQUMsTUFBTSxDQUFDLFlBQVksQ0FBQyxDQUFDO1lBQ3ZELElBQUksQ0FBQyxtQkFBbUIsQ0FBQyxLQUFLLENBQUMsQ0FBQztTQUNuQztRQUVELElBQUksT0FBTyxjQUFjLENBQUMsR0FBRyxLQUFLLFdBQVc7WUFDekMsQ0FBQyxjQUFjLENBQUMsR0FBRyxDQUFDLFdBQVcsRUFDakM7WUFDRSxJQUFJLENBQUMsV0FBVyxDQUFDLGNBQWMsQ0FBQyxHQUFHLENBQUMsWUFBWSxDQUFDLENBQUM7WUFDbEQsSUFBSSxDQUFDLG1CQUFtQixDQUFDLEtBQUssQ0FBQyxDQUFDO1NBQ25DO1FBRUQsSUFBSSxPQUFPLGNBQWMsQ0FBQyxNQUFNLEtBQUssV0FBVyxFQUFFO1lBQzlDLElBQUksQ0FBQyxtQkFBbUIsQ0FBQyxLQUFLLENBQUMsQ0FBQztZQUNoQyxJQUFJLENBQUMsV0FBVyxDQUFDLGNBQWMsQ0FBQyxNQUFNLENBQUMsWUFBWSxDQUFDLENBQUM7WUFFckQsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxHQUFTLEVBQUU7Z0JBQzVCLElBQUksQ0FBQyxzQkFBc0IsRUFBRSxDQUFDO2dCQUU5QixJQUFJLE9BQU8sSUFBSSxDQUFDLE1BQU0sQ0FBQyxzQkFBc0IsS0FBSyxXQUFXLEVBQzNEO29CQUNFLElBQUksSUFBSSxDQUFDLE1BQU0sQ0FBQyxzQkFBc0IsS0FBSyxJQUFJLENBQUMsdUJBQXVCO3dCQUNuRSxJQUFJLENBQUMsb0JBQW9CLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxzQkFBc0IsQ0FBQyxDQUFDO2lCQUNyRTtxQkFBTTtvQkFDSCxJQUFJLENBQUMsTUFBTSxDQUFDLHNCQUFzQixHQUFHLElBQUksQ0FBQyx1QkFBdUIsQ0FBQztpQkFDckU7WUFDTCxDQUFDLENBQUMsQ0FBQztTQUNOO0lBQ0wsQ0FBQztJQUVELFdBQVc7UUFDUCwrQ0FBK0M7UUFDL0MsS0FBSyxJQUFJLElBQUksSUFBSSxJQUFJLENBQUMsZ0JBQWdCLEVBQUU7WUFDcEMsSUFBSSxPQUFPLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxJQUFJLENBQUMsS0FBSyxXQUFXLEVBQUU7Z0JBQ3BELElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxJQUFJLENBQUMsQ0FBQyxXQUFXLEVBQUUsQ0FBQzthQUM3QztTQUNKO0lBQ0wsQ0FBQztJQUVELGFBQWEsQ0FBQyxnQkFBZ0IsRUFBRSxPQUFxQjtRQUNqRCw4REFBOEQ7UUFFOUQsMENBQTBDO1FBQzFDLGdEQUFnRDtRQUNoRCx5REFBeUQ7UUFDekQsS0FBSztRQUNMLElBQUksZ0JBQWdCLEVBQUU7WUFDbEIsSUFBSSxDQUFDLFdBQVcsQ0FBQyxPQUFPLENBQUMsSUFBSSxHQUFHLE1BQU0sQ0FBQTtZQUN0QyxPQUFPLENBQUMsT0FBTyxDQUFDLElBQUksR0FBRyxNQUFNLENBQUM7WUFDOUIsT0FBTyxDQUFDLGdCQUFnQixHQUFHLEdBQUcsQ0FBQTtTQUNqQzthQUFNO1lBQ0gsSUFBSSxDQUFDLFdBQVcsQ0FBQyxPQUFPLENBQUMsSUFBSSxHQUFHLE1BQU0sQ0FBQTtZQUN0QyxPQUFPLENBQUMsT0FBTyxDQUFDLElBQUksR0FBRyxNQUFNLENBQUM7U0FDakM7UUFFRCxJQUFJLFFBQVEsR0FBRyxJQUFJLENBQUMsV0FBVyxDQUFDLFNBQVMsQ0FBQyxzQkFBc0IsRUFBRSxDQUFDO1FBQ25FLHVDQUF1QztRQUN2Qyx1QkFBdUI7UUFDdkIsNkNBQTZDO1FBQzdDLG1CQUFtQjtRQUNuQix1QkFBdUI7UUFDdkIsSUFBSSxDQUFDLFdBQVcsQ0FBQyxTQUFTLENBQUMsZUFBZSxDQUFDLFFBQVEsQ0FBQyxDQUFBO0lBQ3hELENBQUM7SUFFRCxXQUFXLENBQUMsSUFBSTtRQUNaLElBQUksSUFBSSxDQUFDLFNBQVMsSUFBSSxDQUFDLElBQUksQ0FBQyxlQUFlLEVBQUU7WUFDekMsSUFBSSxDQUFDLGtCQUFrQixHQUFHLENBQUMsSUFBSSxDQUFDLGtCQUFrQixDQUFDO1lBQ25ELElBQUksQ0FBQyxnQkFBZ0IsR0FBRyxDQUFDLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQztZQUMvQyxJQUFJLFFBQVEsR0FBRyxJQUFJLENBQUMsV0FBVyxDQUFDLFNBQVMsQ0FBQyxzQkFBc0IsRUFBRSxDQUFDO1lBQ25FLElBQUksYUFBYSxHQUFHLEVBQUUsQ0FBQztZQUN2QixRQUFRLENBQUMsT0FBTyxDQUFDLENBQUMsTUFBVyxFQUFFLEVBQUU7Z0JBQzdCLElBQUksU0FBUyxHQUFHLE1BQU0sYUFBTixNQUFNLHVCQUFOLE1BQU0sQ0FBRSxTQUFTLEVBQUUsQ0FBQztnQkFDcEMsSUFBSSxTQUFTLENBQUMsT0FBTyxJQUFJLElBQUksRUFBRTtvQkFDM0IsU0FBUyxDQUFDLFNBQVMsR0FBRyxVQUFVLE1BQVc7d0JBQ3ZDLElBQUksQ0FBQyxLQUFLLENBQUMsVUFBVSxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsQ0FBQyxJQUFJLFVBQVUsQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLEdBQUcsRUFBRSxFQUFFOzRCQUNuRSxPQUFPLEVBQUUsS0FBSyxFQUFFLFNBQVMsRUFBRSxDQUFDO3lCQUMvQjs2QkFBTTs0QkFDSCxPQUFPLEVBQUUsS0FBSyxFQUFFLE1BQU0sRUFBRSxDQUFDO3lCQUM1QjtvQkFDTCxDQUFDO3dCQUNHLFNBQVMsQ0FBQyxjQUFjLEdBQUc7NEJBQ3ZCLG1CQUFtQixFQUFFLFVBQVUsTUFBTTtnQ0FDakMsT0FBTyxDQUFDLENBQUM7NEJBQ2IsQ0FBQzs0QkFDRCxlQUFlLEVBQUUsVUFBVSxNQUFNO2dDQUM3QixzREFBc0Q7NEJBQzFELENBQUM7eUJBQ0o7d0JBQ0QsU0FBUyxDQUFDLGtCQUFrQixHQUFHOzRCQUMzQixlQUFlLEVBQUUsR0FBRyxFQUFFLENBQUMsSUFBSSxDQUFDLGtCQUFrQjt5QkFDakQ7d0JBQ0QsU0FBUyxDQUFDLFFBQVEsR0FBRyxDQUFDLE1BQVcsRUFBRSxFQUFFOzRCQUNqQyxJQUFJLElBQUksR0FBRyxNQUFNLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUM7NEJBQ2pDLE1BQU0sQ0FBQyxJQUFJLENBQUMsSUFBSSxHQUFHLE1BQU0sQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQzs0QkFDekMsT0FBTyxJQUFJLENBQUM7d0JBRWhCLENBQUM7d0JBQ0QsU0FBUyxDQUFDLGVBQWUsR0FBRyxDQUFDLE1BQVcsRUFBRSxFQUFFOzRCQUV4QyxJQUFJLElBQUksSUFBSSxNQUFNLEVBQUU7Z0NBQ2hCLElBQUksWUFBWSxHQUFHLE1BQU0sQ0FBQyxRQUFRLENBQUM7Z0NBQ25DLE1BQU0sQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsR0FBRyxZQUFZLENBQUM7NkJBQ25EO2lDQUFNO2dDQUNILElBQUksWUFBWSxHQUFHLFVBQVUsQ0FBQyxNQUFNLENBQUMsUUFBUSxDQUFDLENBQUM7Z0NBQy9DLE9BQU8sQ0FBQyxHQUFHLENBQUMsWUFBWSxFQUFFLGNBQWMsQ0FBQyxDQUFDO2dDQUMxQyxJQUFJLFlBQVksSUFBSSxHQUFHLEVBQUU7b0NBQ3JCLE1BQU0sQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsR0FBRyxZQUFZLENBQUM7aUNBQ25EOzZCQUNKOzRCQUNELE9BQU8sQ0FBQyxHQUFHLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxFQUFFLGtDQUFrQyxDQUFDLENBQUM7NEJBRWxGLGVBQWU7d0JBQ25CLENBQUMsQ0FBQTtpQkFDUjtnQkFDRCxhQUFhLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDO1lBQ2xDLENBQUMsQ0FBQyxDQUFDO1lBQ0gsSUFBSSxDQUFDLFdBQVcsQ0FBQyxTQUFTLENBQUMsZUFBZSxDQUFDLGFBQWEsQ0FBQyxDQUFDO1NBQzdEO2FBQU0sSUFBSSxJQUFJLENBQUMsZUFBZSxFQUFFO1lBQzdCLElBQUksQ0FBQyxrQkFBa0IsR0FBRyxDQUFDLElBQUksQ0FBQyxrQkFBa0IsQ0FBQztZQUNuRCxJQUFJLENBQUMsZ0JBQWdCLEdBQUcsQ0FBQyxJQUFJLENBQUMsZ0JBQWdCLENBQUM7WUFDL0MsSUFBSSxRQUFRLEdBQUcsSUFBSSxDQUFDLFdBQVcsQ0FBQyxTQUFTLENBQUMsc0JBQXNCLEVBQUUsQ0FBQztZQUNuRSxJQUFJLGFBQWEsR0FBRyxFQUFFLENBQUM7WUFDdkIsUUFBUSxDQUFDLE9BQU8sQ0FBQyxDQUFDLE1BQVcsRUFBRSxFQUFFO2dCQUM3QixJQUFJLFNBQVMsR0FBRyxNQUFNLGFBQU4sTUFBTSx1QkFBTixNQUFNLENBQUUsU0FBUyxFQUFFLENBQUM7Z0JBQ3BDLElBQUksU0FBUyxDQUFDLE9BQU8sSUFBSSxJQUFJLEVBQUU7b0JBQzNCLFNBQVMsQ0FBQyxXQUFXLEdBQUcsVUFBVSxNQUFNO3dCQUNwQyxJQUFJLEtBQUssR0FBRyxNQUFNLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLENBQUM7d0JBQzdDLElBQUksSUFBSSxJQUFJLE1BQU0sRUFBRTs0QkFDaEIsT0FBTyxLQUFLLENBQUM7eUJBQ2hCOzZCQUFNOzRCQUNILElBQUksQ0FBQyxLQUFLLENBQUMsVUFBVSxDQUFDLEtBQUssQ0FBQyxDQUFDLEVBQUU7Z0NBQzNCLE9BQU8sS0FBSyxDQUFDOzZCQUNoQjtpQ0FBTTtnQ0FDSCxPQUFPLEVBQUUsQ0FBQzs2QkFDYjt5QkFDSjtvQkFDTCxDQUFDO3dCQUNHLFNBQVMsQ0FBQyxjQUFjLEdBQUcsRUFBRTt3QkFDN0IsU0FBUyxDQUFDLGtCQUFrQixHQUFHOzRCQUMzQixlQUFlLEVBQUUsR0FBRyxFQUFFLENBQUMsSUFBSSxDQUFDLGtCQUFrQjt5QkFDakQ7d0JBQ0QsU0FBUyxDQUFDLFFBQVEsR0FBRyxDQUFDLE1BQVcsRUFBRSxFQUFFOzRCQUNqQyxPQUFPLEtBQUssQ0FBQzt3QkFDakIsQ0FBQyxDQUFBO2lCQUNSO2dCQUNELGFBQWEsQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLENBQUM7WUFDbEMsQ0FBQyxDQUFDLENBQUM7WUFDSCxJQUFJLENBQUMsV0FBVyxDQUFDLFNBQVMsQ0FBQyxlQUFlLENBQUMsYUFBYSxDQUFDLENBQUM7U0FDN0Q7SUFDTCxDQUFDO0lBRUQsa0JBQWtCLENBQUMsZ0JBQWdCO1FBQy9CLElBQUksZ0JBQWdCLEVBQUU7WUFDbEIsSUFBSSxDQUFDLFdBQVcsQ0FBQyxPQUFPLENBQUMsTUFBTSxHQUFHLE1BQU0sQ0FBQztTQUM1QzthQUFNO1lBQ0gsSUFBSSxDQUFDLFdBQVcsQ0FBQyxPQUFPLENBQUMsTUFBTSxHQUFHLE1BQU0sQ0FBQztTQUM1QztRQUNELElBQUksUUFBUSxHQUFHLElBQUksQ0FBQyxXQUFXLENBQUMsU0FBUyxDQUFDLHNCQUFzQixFQUFFLENBQUM7UUFDbkUsSUFBSSxDQUFDLFdBQVcsQ0FBQyxTQUFTLENBQUMsZUFBZSxDQUFDLFFBQVEsQ0FBQyxDQUFDO1FBQ3JELElBQUksQ0FBQyxtQkFBbUIsQ0FBQyxLQUFLLENBQUMsQ0FBQztJQUNwQyxDQUFDO0lBRUQsY0FBYyxDQUFDLGdCQUFnQjtRQUMzQixJQUFJLGdCQUFnQixFQUFFO1lBQ2xCLElBQUksQ0FBQyxXQUFXLENBQUMsT0FBTyxDQUFDLElBQUksR0FBRyxNQUFNLENBQUM7U0FDMUM7YUFBTTtZQUNILElBQUksQ0FBQyxXQUFXLENBQUMsT0FBTyxDQUFDLElBQUksR0FBRyxNQUFNLENBQUM7U0FDMUM7UUFDRCxJQUFJLFFBQVEsR0FBRyxJQUFJLENBQUMsV0FBVyxDQUFDLFNBQVMsQ0FBQyxzQkFBc0IsRUFBRSxDQUFDO1FBQ25FLElBQUksQ0FBQyxXQUFXLENBQUMsU0FBUyxDQUFDLGVBQWUsQ0FBQyxRQUFRLENBQUMsQ0FBQztRQUNyRCxJQUFJLENBQUMsbUJBQW1CLENBQUMsS0FBSyxDQUFDLENBQUM7SUFDcEMsQ0FBQztJQUVELCtFQUErRTtJQUN4RSxXQUFXLENBQUMsT0FBWTtRQUMzQiw0REFBNEQ7UUFDNUQsSUFBSSxDQUFDLGVBQWUsRUFBRSxDQUFDO0lBQzNCLENBQUM7SUFFTSxjQUFjLENBQUMsTUFBeUI7UUFDM0MseUVBQXlFO1FBQ3pFLElBQUksSUFBSSxDQUFDLGFBQWEsQ0FBQyxlQUFlLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxFQUFFO1lBQ2pELElBQUksQ0FBQywyQkFBMkIsRUFBRSxDQUFDO1NBQ3RDO1FBRUQsSUFBSSxJQUFJLENBQUMsYUFBYSxFQUFFO1lBQ3BCLElBQUksV0FBVyxHQUFZLFFBQVEsQ0FBQyxhQUFhLENBQUMsR0FBRyxHQUFHLElBQUksQ0FBQyxNQUFNLEdBQUcsWUFBWSxDQUFDLENBQUM7WUFFcEYsSUFBSSxXQUFXLEtBQUssSUFBSSxFQUFFO2dCQUN0QixJQUFJLENBQUMsZ0JBQWdCLENBQUMsV0FBVyxDQUFDLENBQUM7YUFDdEM7U0FDSjtJQUNMLENBQUM7SUFFTSxZQUFZLENBQUMsT0FBaUI7UUFDakMseURBQXlEO1FBQ3pELElBQUksSUFBSSxDQUFDLGFBQWEsQ0FBQyxPQUFPLENBQUMsS0FBSyxDQUFDLElBQUksT0FBTyxJQUFJLENBQUMsTUFBTSxDQUFDLEtBQUssS0FBSyxXQUFXLElBQUksQ0FBQyxJQUFJLENBQUMsU0FBUyxFQUFFO1lBQ2xHLFFBQVEsSUFBSSxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsSUFBSSxFQUFFO2dCQUM1QixLQUFLLFdBQVc7b0JBQ1osSUFBSSxDQUFDLG1CQUFtQixDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsQ0FBQztvQkFDdkMsTUFBTTtnQkFDVixLQUFLLFFBQVE7b0JBQ1QsSUFBSSxDQUFDLHVCQUF1QixDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsQ0FBQztvQkFDM0MsTUFBTTtnQkFDVjtvQkFDSSxNQUFNO2FBQ2I7WUFFRCxJQUFJLE9BQU8sSUFBSSxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsUUFBUSxLQUFLLFdBQVcsRUFBRTtnQkFDbkQsSUFBSSxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsUUFBUSxFQUFFLENBQUM7YUFDaEM7U0FDSjtJQUNMLENBQUM7SUFFRCwrRUFBK0U7SUFDeEUsZUFBZSxDQUFDLE9BQXFCO1FBQ3hDLElBQUksV0FBVyxHQUF1QixJQUFJLGtCQUFrQixDQUFDLE9BQU8sQ0FBQyxDQUFDO1FBQ3RFLElBQUksQ0FBQyxtQkFBbUIsQ0FBcUIsUUFBUSxFQUFFLFdBQVcsQ0FBQyxDQUFDO0lBQ3hFLENBQUM7SUFFRCwrRUFBK0U7SUFDL0Usd0dBQXdHO0lBQ3hHLGVBQWU7SUFDZix3R0FBd0c7SUFDaEcsY0FBYztRQUNsQixJQUFJLE9BQU8sSUFBSSxDQUFDLE1BQU0sS0FBSyxXQUFXLEVBQUU7WUFDcEMsSUFBSSxDQUFDLGdCQUFnQixDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsUUFBUSxDQUFDLENBQUM7WUFDNUMsSUFBSSxDQUFDLGlCQUFpQixDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQztZQUNwQyxJQUFJLENBQUMsZUFBZSxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQztZQUNsQyxJQUFJLENBQUMsd0JBQXdCLEVBQUUsQ0FBQztTQUNuQztRQUVELElBQUksT0FBTyxJQUFJLENBQUMsTUFBTSxLQUFLLFdBQVcsRUFBRTtZQUNwQyxJQUFJLENBQUMsYUFBYSxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQztTQUNuQztRQUVELElBQUksT0FBTyxJQUFJLENBQUMsR0FBRyxLQUFLLFdBQVcsRUFBRTtZQUNqQyxJQUFJLENBQUMsV0FBVyxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQztTQUM5QjtJQUNMLENBQUM7SUFFTyxlQUFlO1FBQ25CLElBQUksQ0FBQyxjQUFjLEVBQUUsQ0FBQztRQUV0QixJQUFJLElBQUksQ0FBQyxhQUFhLENBQUMsaUJBQWlCLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxRQUFRLENBQUMsRUFBRTtZQUM1RCxJQUFJLENBQUMseUJBQXlCLEVBQUUsQ0FBQztTQUNwQztRQUVELElBQUksQ0FBQyxrQkFBa0IsRUFBRSxDQUFDO0lBQzlCLENBQUM7SUFFTyx5QkFBeUI7UUFDN0IsSUFBSSxDQUFDLGdCQUFnQixFQUFFLENBQUM7UUFDeEIsSUFBSSxDQUFDLDZCQUE2QixFQUFFLENBQUM7SUFDekMsQ0FBQztJQUVPLGtCQUFrQjtRQUN0QixJQUFJLENBQUMsb0JBQW9CLEVBQUUsQ0FBQztRQUM1QixJQUFJLENBQUMsVUFBVSxFQUFFLENBQUM7UUFDbEIsSUFBSSxDQUFDLGFBQWEsRUFBRSxDQUFDO0lBQ3pCLENBQUM7SUFFTyxtQkFBbUIsQ0FBQyxRQUFpQjtRQUN6QyxJQUFJLE9BQU8sSUFBSSxDQUFDLE1BQU0sQ0FBQyxTQUFTLEtBQUssV0FBVyxFQUFFO1lBQzlDLE9BQU8sQ0FBQyxLQUFLLENBQUMsd0hBQXdILENBQUMsQ0FBQztTQUMzSTthQUNJLElBQUksSUFBSSxDQUFDLE1BQU0sQ0FBQyxTQUFTLENBQUMsSUFBSSxLQUFLLFFBQVEsRUFBRTtZQUM5QyxJQUFJLElBQUksQ0FBQyxNQUFNLENBQUMsU0FBUyxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsUUFBUSxDQUFDLEVBQUUsQ0FBQyxHQUFHLENBQUMsRUFBRTtnQkFDdEQsSUFBSSxDQUFDLFdBQVcsQ0FBQyxHQUFHLENBQUMsV0FBVyxFQUFFLENBQUM7Z0JBQ25DLFFBQVEsQ0FBQyxjQUFjLENBQUMsSUFBSSxDQUFDLENBQUM7Z0JBRTlCLElBQUksQ0FBQyxNQUFNLENBQUMsU0FBUyxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsQ0FBQyxFQUFFLElBQUksQ0FBQyxNQUFNLENBQUMsU0FBUyxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsQ0FBQztnQkFDMUUsSUFBSSxDQUFDLE1BQU0sQ0FBQyxTQUFTLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxDQUFDO2dCQUVuRCxJQUFJLENBQUMsMkJBQTJCLEVBQUUsQ0FBQztnQkFDbkMsSUFBSSxDQUFDLHFCQUFxQixDQUFDLFFBQVEsQ0FBQyxDQUFDO2FBQ3hDO1NBQ0o7YUFDSTtZQUNELElBQUksU0FBUyxHQUFZLENBQUMsUUFBUSxDQUFDLFVBQVUsRUFBRSxDQUFDO1lBQ2hELFFBQVEsQ0FBQyxjQUFjLENBQUMsU0FBUyxDQUFDLENBQUM7WUFFbkMsSUFBSSxDQUFDLDJCQUEyQixFQUFFLENBQUM7WUFFbkMsSUFBSSxTQUFTLEVBQUU7Z0JBQ1gsSUFBSSxDQUFDLE1BQU0sQ0FBQyxTQUFTLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxDQUFDO2FBQ3REO2lCQUNJO2dCQUNELElBQUksQ0FBQyxNQUFNLENBQUMsU0FBUyxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxTQUFTLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDO2FBQ2hHO1lBRUQsSUFBSSxDQUFDLHFCQUFxQixDQUFDLFFBQVEsQ0FBQyxDQUFDO1NBQ3hDO0lBQ0wsQ0FBQztJQUVPLGdCQUFnQjtRQUNwQixJQUFJLE9BQU8sSUFBSSxDQUFDLE1BQU0sQ0FBQyxTQUFTLEtBQUssV0FBVyxJQUFJLE9BQU8sSUFBSSxDQUFDLE1BQU0sQ0FBQyxTQUFTLENBQUMsSUFBSSxLQUFLLFdBQVcsRUFBRTtZQUNuRyxJQUFJLENBQUMsd0JBQXdCLEVBQUUsQ0FBQztTQUNuQzthQUVJLElBQUksSUFBSSxDQUFDLGFBQWEsQ0FBQyxZQUFZLENBQUMsSUFBSSxDQUFDLE1BQU0sRUFBRSxPQUFPLENBQUMsRUFBRTtZQUM1RCxJQUFJLENBQUMscUJBQXFCLEVBQUUsQ0FBQztTQUNoQztJQUNMLENBQUM7SUFFTyx1QkFBdUIsQ0FBQyxRQUFpQjtRQUM3QyxJQUFJLE9BQU8sSUFBSSxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsT0FBTyxLQUFLLFdBQVcsRUFBRTtZQUNsRCxJQUFJLE9BQU8sSUFBSSxDQUFDLE1BQU0sQ0FBQyxNQUFNLEtBQUssV0FBVztnQkFDekMsT0FBTyxJQUFJLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxJQUFJLEtBQUssV0FBVyxFQUFFO2dCQUNoRCxJQUFJLFVBQVUsR0FBVyxFQUFFLENBQUM7Z0JBRTVCLEtBQUssSUFBSSxDQUFDLEdBQVcsQ0FBQyxFQUFFLENBQUMsR0FBRyxJQUFJLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsTUFBTSxFQUFFLEVBQUUsQ0FBQyxFQUFFO29CQUM3RCxJQUFJLFVBQVUsR0FBeUIsSUFBSSxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDO29CQUVsRSxJQUFJLFVBQVUsQ0FBQyxJQUFJLENBQUMsV0FBVyxFQUFFLEtBQUssSUFBSSxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLFdBQVcsRUFBRSxFQUFFO3dCQUMzRSxVQUFVLEdBQUcsSUFBSSxDQUFDLGFBQWEsQ0FBQyx3QkFBd0IsQ0FBQyxRQUFRLEVBQUUsVUFBVSxDQUFDLElBQUksQ0FBQyxDQUFDO3dCQUNwRixNQUFNO3FCQUNUO2lCQUNKO2dCQUVELElBQUksVUFBVSxLQUFLLEVBQUUsRUFBRTtvQkFDbkIsSUFBSSxDQUFDLE9BQU8sQ0FBQyxRQUFRLENBQUMsQ0FBQyxVQUFVLENBQUMsQ0FBQyxDQUFDO2lCQUN2QztxQkFDSTtvQkFDRCxPQUFPLENBQUMsSUFBSSxDQUFDLGtFQUFrRSxFQUFFLElBQUksQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxDQUFDO2lCQUMvRzthQUNKO2lCQUNJO2dCQUNELE9BQU8sQ0FBQyxLQUFLLENBQUMsOElBQThJLENBQUMsQ0FBQzthQUNqSztTQUVKO2FBQ0ksSUFBSSxPQUFPLElBQUksQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLElBQUksS0FBSyxXQUFXLEVBQUU7WUFDcEQsSUFBSSxDQUFDLE9BQU8sQ0FBQyxRQUFRLENBQUMsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDO1NBQ25EO2FBQ0k7WUFDRCxPQUFPLENBQUMsS0FBSyxDQUFDLGlJQUFpSSxDQUFDLENBQUM7U0FDcEo7SUFDTCxDQUFDO0lBRUQsd0dBQXdHO0lBQ3hHLHlCQUF5QjtJQUN6Qix3R0FBd0c7SUFFaEcsbUJBQW1CLENBQUMsT0FBZ0I7UUFDeEMsSUFBSSxDQUFDLGNBQWMsR0FBRyxPQUFPLENBQUM7SUFDbEMsQ0FBQztJQUVPLG9CQUFvQjtRQUN4QixJQUFJLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxhQUFhLENBQUMsVUFBVSxDQUFDLFNBQVMsSUFBSSxhQUFhLENBQUM7UUFDdEUsSUFBSSxJQUFJLENBQUMsVUFBVSxLQUFLLEtBQUs7WUFBRSxRQUFRLENBQUMsYUFBYSxDQUFDLE1BQU0sQ0FBQyxDQUFDLEtBQUssQ0FBQyxPQUFPLElBQUkscUNBQXFDLENBQUM7SUFDekgsQ0FBQztJQUVPLFVBQVU7UUFDZCxJQUFJLFdBQVcsR0FBVyxHQUFHLEdBQUcsSUFBSSxDQUFDLE1BQU0sR0FBRyxZQUFZLENBQUM7UUFDM0QsSUFBSSxXQUFXLEdBQVksSUFBSSxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsYUFBYSxDQUFDLGFBQWEsQ0FBQyxXQUFXLENBQUMsQ0FBQztRQUV0RixJQUFJLFdBQVcsS0FBSyxJQUFJLEVBQUU7WUFDdEIsSUFBSSxZQUFZLEdBQVcsUUFBUSxDQUFDLElBQUksQ0FBQyxXQUFXLENBQUM7WUFFckQsSUFBSSxZQUFZLElBQUksSUFBSSxFQUFFO2dCQUN0QixJQUFJLE9BQU8sSUFBSSxDQUFDLGFBQWEsS0FBSyxXQUFXLElBQUksQ0FBQyxJQUFJLENBQUMsYUFBYSxFQUFFO29CQUNsRSxJQUFJLENBQUMsbUJBQW1CLENBQUMsSUFBSSxDQUFDLENBQUM7b0JBQy9CLElBQUksQ0FBQyxhQUFhLEdBQUcsSUFBSSxDQUFDO29CQUMxQixJQUFJLENBQUMsZ0JBQWdCLENBQUMsV0FBVyxDQUFDLENBQUM7aUJBQ3RDO2FBQ0o7aUJBQ0ksSUFBSSxZQUFZLEdBQUcsSUFBSSxFQUFFO2dCQUMxQixJQUFJLE9BQU8sSUFBSSxDQUFDLGFBQWEsS0FBSyxXQUFXLElBQUksSUFBSSxDQUFDLGFBQWEsRUFBRTtvQkFDakUsSUFBSSxDQUFDLG1CQUFtQixDQUFDLElBQUksQ0FBQyxDQUFDO29CQUMvQixJQUFJLENBQUMsYUFBYSxHQUFHLEtBQUssQ0FBQztvQkFDM0IsSUFBSSxDQUFDLGlCQUFpQixDQUFDLFdBQVcsRUFBRSxJQUFJLENBQUMsTUFBTSxDQUFDLFVBQVUsQ0FBQyxDQUFDO2lCQUMvRDtxQkFDSTtvQkFDRCxJQUFJLENBQUMsV0FBVyxDQUFDLEdBQUcsQ0FBQyxnQkFBZ0IsRUFBRSxDQUFDO2lCQUMzQzthQUNKO1NBQ0o7SUFDTCxDQUFDO0lBRUQ7OztPQUdHO0lBQ0sscUJBQXFCO1FBQ3pCLElBQUksaUJBQWlCLEdBQVcscUJBQXFCLENBQUM7UUFDdEQsSUFBSSxZQUFZLEdBQVksSUFBSSxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsYUFBYSxDQUFDLGFBQWEsQ0FBQyxpQkFBaUIsQ0FBQyxDQUFDO1FBQzdGLElBQUksWUFBWSxLQUFLLElBQUk7WUFBRSxPQUFPO1FBRWxDLElBQUksZ0JBQWdCLEdBQVcsb0JBQW9CLENBQUM7UUFDcEQsSUFBSSxXQUFXLEdBQVksSUFBSSxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsYUFBYSxDQUFDLGFBQWEsQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDO1FBRTNGLElBQUksWUFBWSxDQUFDLFlBQVksR0FBRyxXQUFXLENBQUMsWUFBWTtZQUNwRCxXQUFXLENBQUMsU0FBUztZQUNyQixXQUFXLENBQUMsU0FBUyxDQUFDLE9BQU8sQ0FBQyxtQkFBbUIsQ0FBQyxLQUFLLENBQUMsQ0FBQyxFQUMzRDtZQUNFLFdBQVcsQ0FBQyxTQUFTLElBQUksb0JBQW9CLENBQUM7U0FDakQ7YUFBTSxJQUFJLFlBQVksQ0FBQyxZQUFZLEdBQUcsV0FBVyxDQUFDLFlBQVksRUFBRTtZQUM3RCxXQUFXLENBQUMsU0FBUyxHQUFHLFdBQVcsQ0FBQyxTQUFTLENBQUMsT0FBTyxDQUFDLHFCQUFxQixFQUFFLEVBQUUsQ0FBQyxDQUFDO1NBQ3BGO0lBQ0wsQ0FBQztJQUVPLGdCQUFnQixDQUFDLFlBQXFCO1FBQzFDLElBQUksU0FBUyxHQUFXLENBQUMsQ0FBQztRQUUxQixJQUFJLElBQUksQ0FBQyxNQUFNLENBQUMsUUFBUSxLQUFLLFVBQVUsRUFBRTtZQUNyQyxJQUFJLFdBQVcsR0FBWSxJQUFJLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxhQUFhLENBQUMsYUFBYSxDQUFDLFlBQVksQ0FBQyxDQUFDO1lBQ3ZGLElBQUksU0FBUyxHQUFZLElBQUksQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLGFBQWEsQ0FBQyxhQUFhLENBQUMsb0JBQW9CLENBQUMsQ0FBQztZQUM3RixJQUFJLGNBQWMsR0FBWSxJQUFJLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxhQUFhLENBQUMsYUFBYSxDQUFDLGtCQUFrQixDQUFDLENBQUM7WUFDaEcsU0FBUyxHQUFHLEVBQUUsQ0FBQztZQUVmLElBQUksV0FBVyxLQUFLLElBQUksRUFBRTtnQkFDdEIsU0FBUyxJQUFJLFdBQVcsQ0FBQyxZQUFZLENBQUM7YUFDekM7WUFFRCxJQUFJLFNBQVMsS0FBSyxJQUFJLEVBQUU7Z0JBQ3BCLFNBQVMsSUFBSSxTQUFTLENBQUMsWUFBWSxDQUFDO2FBQ3ZDO1lBRUQsSUFBSSxjQUFjLEtBQUssSUFBSSxFQUFFO2dCQUN6QixTQUFTLElBQUksY0FBYyxDQUFDLFlBQVksQ0FBQzthQUM1QztTQUNKO2FBQ0k7WUFDRCxTQUFTLEdBQUcsR0FBRyxDQUFDO1NBQ25CO1FBR0QsSUFBSSxDQUFDLE9BQU8sQ0FBQyxlQUFlLENBQUMsWUFBWSxFQUFFLFFBQVEsRUFBRSxTQUFTLEdBQUcsSUFBSSxDQUFDLENBQUM7UUFFdkUsS0FBSyxDQUFDLEVBQUUsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxHQUFTLEVBQUU7WUFDM0IsSUFBSSxDQUFDLFdBQVcsQ0FBQyxHQUFHLENBQUMsZ0JBQWdCLEVBQUUsQ0FBQztZQUN4QyxJQUFJLENBQUMsbUJBQW1CLENBQUMsS0FBSyxDQUFDLENBQUM7UUFDcEMsQ0FBQyxDQUFDLENBQUM7SUFDUCxDQUFDO0lBRUQ7OztPQUdHO0lBQ0ssaUJBQWlCLENBQUMsWUFBcUIsRUFBRSxhQUE4QjtRQUMzRSxJQUFJLE9BQU8sYUFBYSxLQUFLLFFBQVEsRUFBRTtZQUNuQyxJQUFJLFVBQVUsR0FBVyxHQUFHLENBQUM7WUFFN0IsSUFBSSxPQUFPLGFBQWEsS0FBSyxXQUFXLEVBQUU7Z0JBQ3RDLFVBQVUsR0FBRyxhQUFhLENBQUM7YUFDOUI7WUFFRCxJQUFJLENBQUMsT0FBTyxDQUFDLGVBQWUsQ0FBQyxZQUFZLEVBQUUsUUFBUSxFQUFFLFVBQVUsR0FBRyxJQUFJLENBQUMsQ0FBQztTQUMzRTthQUNJLElBQUksYUFBYSxLQUFLLE1BQU0sRUFBRTtZQUMvQixJQUFJLENBQUMsV0FBVyxHQUFHLElBQUksQ0FBQztTQUMzQjtRQUNELDRDQUE0QztRQUM1QyxpREFBaUQ7UUFDakQseUNBQXlDO1FBQ3pDLDRDQUE0QztRQUM1QyxJQUFJO1FBRUosS0FBSyxFQUFFLENBQUMsU0FBUyxDQUFDLEdBQVMsRUFBRTtZQUN6QixJQUFJLENBQUMsV0FBVyxDQUFDLEdBQUcsQ0FBQyxnQkFBZ0IsRUFBRSxDQUFDO1lBQ3hDLElBQUksQ0FBQyxtQkFBbUIsQ0FBQyxLQUFLLENBQUMsQ0FBQztRQUNwQyxDQUFDLENBQUMsQ0FBQztJQUNQLENBQUM7SUFFTyxhQUFhLENBQUMsTUFBYTtRQUMvQixJQUFJLGFBQWEsR0FBNkIsTUFBTSxDQUFDLE1BQU0sQ0FBQztRQUM1RCxJQUFJLFdBQVcsR0FBa0IsQ0FBQyxZQUFZLEVBQUUsc0JBQXNCLEVBQUUsaUJBQWlCLENBQUMsQ0FBQztRQUUzRixLQUFLLElBQUksQ0FBQyxHQUFXLENBQUMsRUFBRSxDQUFDLEdBQUcsV0FBVyxDQUFDLE1BQU0sRUFBRSxDQUFDLEVBQUUsRUFBRTtZQUNqRCxJQUFJLGFBQWEsQ0FBQyxTQUFTLENBQUMsUUFBUSxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFO2dCQUNsRCxPQUFPLEtBQUssQ0FBQzthQUNoQjtTQUNKO1FBRUQsT0FBTyxJQUFJLENBQUM7SUFDaEIsQ0FBQztJQUVPLGFBQWEsQ0FBQyxxQkFBOEIsS0FBSztRQUNyRCxJQUFJLElBQUksQ0FBQyxhQUFhLENBQUMsVUFBVSxDQUFDLElBQUksQ0FBQyxXQUFXLENBQUMsRUFBRTtZQUNqRCxLQUFLLENBQUMsRUFBRSxDQUFDLENBQUMsU0FBUyxDQUFDLEdBQVMsRUFBRTtnQkFDM0IsQ0FBQyxrQkFBa0IsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsc0JBQXNCLEVBQUUsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxHQUFHLENBQUMsZ0JBQWdCLEVBQUUsQ0FBQztnQkFDL0YsSUFBSSxDQUFDLGdCQUFnQixDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQztnQkFDakMsSUFBSSxDQUFDLG1CQUFtQixDQUFDLEtBQUssQ0FBQyxDQUFDO1lBQ3BDLENBQUMsQ0FBQyxDQUFDO1NBQ047SUFDTCxDQUFDO0lBRUQ7O09BRUc7SUFDSyxzQkFBc0I7UUFDMUIsSUFBSSxZQUFZLEdBQWtCLEVBQUUsQ0FBQztRQUNyQyxJQUFJLENBQUMsV0FBVyxDQUFDLFNBQVMsQ0FBQyxzQkFBc0IsRUFBRSxDQUFDLE9BQU8sQ0FBQyxDQUFDLE1BQWMsRUFBRSxFQUFFO1lBQzNFLFlBQVksQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLFFBQVEsRUFBRSxDQUFDLENBQUM7UUFDekMsQ0FBQyxDQUFDLENBQUM7UUFDSCxJQUFJLENBQUMsV0FBVyxDQUFDLFNBQVMsQ0FBQyxlQUFlLENBQUMsWUFBWSxDQUFDLENBQUM7SUFDN0QsQ0FBQztJQUVEOzs7T0FHRztJQUNJLFdBQVcsQ0FBQyxPQUFxQjtRQUNwQyxJQUFJLENBQUMsT0FBTyxJQUFJLENBQUMsT0FBTyxDQUFDLE1BQU0sRUFBRTtZQUM3QixRQUFRLENBQUMsYUFBYSxDQUFDLE1BQU0sQ0FBQyxDQUFDLEtBQUssQ0FBQyxPQUFPLEdBQUcsRUFBRSxDQUFDO1lBQ2xELE9BQU87U0FDVjtRQUNELElBQUksTUFBTSxHQUFtQixPQUFPLENBQUMsTUFBTSxDQUFDO1FBRTVDLElBQUksT0FBTyxHQUFXLEVBQUUsQ0FBQztRQUV6QixPQUFPLElBQUksSUFBSSxDQUFDLGtCQUFrQixDQUFDLE1BQU0sQ0FBQyxDQUFDO1FBRTNDLElBQUksTUFBTSxDQUFDLElBQUksRUFBRTtZQUNiLElBQUksTUFBTSxDQUFDLElBQUksQ0FBQyxZQUFZLEtBQUssSUFBSSxFQUFFO2dCQUNuQyxJQUFJLE1BQU0sQ0FBQyxJQUFJLENBQUMsR0FBRyxJQUFJLE1BQU0sQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLGVBQWUsRUFBRTtvQkFDcEQsT0FBTyxJQUFJLGdDQUFnQyxHQUFHLE1BQU0sQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLGVBQWUsR0FBRyxHQUFHLENBQUM7aUJBQ3ZGO2dCQUNELElBQUksTUFBTSxDQUFDLElBQUksQ0FBQyxJQUFJLElBQUksTUFBTSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsZUFBZSxFQUFFO29CQUN0RCxPQUFPLElBQUksaUNBQWlDLEdBQUcsTUFBTSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsZUFBZSxHQUFHLEdBQUcsQ0FBQztpQkFDekY7YUFDSjtZQUNELElBQUksTUFBTSxDQUFDLElBQUksQ0FBQyxLQUFLLEVBQUU7Z0JBQ25CLElBQUksTUFBTSxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsV0FBVyxFQUFFO29CQUMvQixPQUFPLElBQUksK0JBQStCLEdBQUcsTUFBTSxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsV0FBVyxHQUFHLEdBQUcsQ0FBQztvQkFDakYsT0FBTyxJQUFJLGlDQUFpQyxHQUFHLE1BQU0sQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLFdBQVcsR0FBRyxHQUFHLENBQUM7aUJBQ3RGO2dCQUNELElBQUksTUFBTSxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsV0FBVyxFQUFFO29CQUMvQixPQUFPLElBQUksK0JBQStCLEdBQUcsTUFBTSxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsV0FBVyxHQUFHLEdBQUcsQ0FBQztvQkFDakYsT0FBTyxJQUFJLGlDQUFpQyxHQUFHLE1BQU0sQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLFdBQVcsR0FBRyxHQUFHLENBQUM7aUJBQ3RGO2dCQUNELElBQUksTUFBTSxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsV0FBVyxFQUFFO29CQUMvQixPQUFPLElBQUksK0JBQStCLEdBQUcsTUFBTSxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsV0FBVyxHQUFHLEdBQUcsQ0FBQztvQkFDakYsT0FBTyxJQUFJLGlDQUFpQyxHQUFHLE1BQU0sQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLFdBQVcsR0FBRyxHQUFHLENBQUM7aUJBQ3RGO2FBQ0o7U0FDSjtRQUVELFFBQVEsQ0FBQyxhQUFhLENBQUMsTUFBTSxDQUFDLENBQUMsS0FBSyxDQUFDLE9BQU8sR0FBRyxPQUFPLENBQUM7SUFDM0QsQ0FBQztJQUVPLGtCQUFrQixDQUFDLE9BQXVCO1FBQzlDLElBQUksQ0FBQyxPQUFPLENBQUMsTUFBTSxJQUFJLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxLQUFLO1lBQUUsT0FBTyxFQUFFLENBQUM7UUFFeEQsSUFBSSxPQUFPLEdBQVcsRUFBRSxDQUFDO1FBQ3pCLElBQUksVUFBVSxHQUFrQjtZQUM1QixpQkFBaUI7WUFDakIsV0FBVztZQUNYLGVBQWU7WUFDZixPQUFPO1lBQ1AsWUFBWTtZQUNaLFVBQVU7WUFDVixZQUFZO1lBQ1osV0FBVztZQUNYLGdCQUFnQjtZQUNoQixpQkFBaUI7WUFDakIsaUJBQWlCO1lBQ2pCLGlCQUFpQjtZQUNqQixTQUFTO1NBQ1osQ0FBQztRQUNGLEtBQUssSUFBSSxDQUFDLEdBQVcsQ0FBQyxFQUFFLENBQUMsR0FBRyxVQUFVLENBQUMsTUFBTSxFQUFFLEVBQUUsQ0FBQyxFQUFFO1lBQ2hELElBQUksU0FBUyxHQUFXLFVBQVUsQ0FBQyxDQUFDLENBQUMsQ0FBQztZQUN0QyxJQUFJLEtBQUssR0FBVyxPQUFPLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxTQUFTLENBQUMsQ0FBQztZQUNwRCxJQUFJLFNBQVMsS0FBSyxlQUFlO2dCQUFFLEtBQUssR0FBRyxJQUFJLENBQUMsYUFBYSxDQUFDLEtBQUssQ0FBQyxDQUFDO1lBQ3JFLFNBQVMsR0FBRyxDQUFDLFNBQVMsS0FBSyxpQkFBaUIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxZQUFZLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxPQUFPLENBQUMsaUJBQWlCLEVBQUUsT0FBTyxDQUFDLENBQUMsV0FBVyxFQUFFLENBQUM7WUFDM0gsSUFBSSxPQUFPLEtBQUssS0FBSyxXQUFXLEVBQUU7Z0JBQzlCLElBQUksU0FBUyxLQUFLLGFBQWE7b0JBQzNCLENBQUMsT0FBTyxLQUFLLEtBQUssUUFBUSxJQUFJLEtBQUssQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUM7b0JBQzNELEtBQUssSUFBSSxJQUFJLENBQUM7Z0JBQ2hCLE9BQU8sSUFBSSxtQkFBbUIsR0FBRyxTQUFTLEdBQUcsSUFBSSxHQUFHLEtBQUssR0FBRyxHQUFHLENBQUM7YUFDbkU7U0FDSjtRQUNELE9BQU8sT0FBTyxDQUFDO0lBQ25CLENBQUM7SUFFRDs7O09BR0c7SUFDSyxhQUFhLENBQUMsY0FBc0I7UUFDeEMsSUFBSSxjQUFjLEtBQUssVUFBVSxJQUFJLGNBQWMsS0FBSyxRQUFRLEVBQUU7WUFDOUQsT0FBTyxVQUFVLENBQUM7U0FDckI7YUFBTSxJQUFJLGNBQWMsS0FBSyxLQUFLLEVBQUU7WUFDakMsT0FBTyxZQUFZLENBQUM7U0FDdkI7YUFBTSxFQUFFLDBCQUEwQjtZQUMvQixJQUFJLGNBQWMsS0FBSyxRQUFRLElBQUksY0FBYyxLQUFLLFNBQVMsRUFBRTtnQkFDN0QsT0FBTyxDQUFDLElBQUksQ0FBQyxxQ0FBcUMsR0FBRyxjQUFjLEdBQUcsaUZBQWlGLENBQUMsQ0FBQzthQUM1SjtZQUNELE9BQU8sUUFBUSxDQUFDO1NBQ25CO0lBQ0wsQ0FBQztJQUVELHFFQUFxRTtJQUNyRSxvSEFBb0g7SUFDcEgsaURBQWlEO0lBQ2pELGdEQUFnRDtJQUVoRCxtQ0FBbUM7SUFDbkMsd0ZBQXdGO0lBQ3hGLHdEQUF3RDtJQUN4RCxrQkFBa0I7SUFDbEIsWUFBWTtJQUVaLDBFQUEwRTtJQUMxRSxzSEFBc0g7SUFDdEgsaUZBQWlGO0lBQ2pGLCtDQUErQztJQUMvQyx1QkFBdUI7SUFDdkIsK0NBQStDO0lBQy9DLGdCQUFnQjtJQUNoQixjQUFjO0lBRWQsbUZBQW1GO0lBQ25GLHNDQUFzQztJQUN0QyxvRkFBb0Y7SUFDcEYsYUFBYTtJQUViLDREQUE0RDtJQUM1RCxRQUFRO0lBQ1IsSUFBSTtJQUVKLHdHQUF3RztJQUN4RyxrQkFBa0I7SUFDbEIsd0dBQXdHO0lBQ2hHLHVCQUF1QjtRQUMzQixJQUFJLGFBQWEsR0FBWSxJQUFJLENBQUM7UUFDbEMsSUFBSSxJQUFJLENBQUMsc0JBQXNCLEVBQUU7WUFDN0IsSUFBSSxTQUFTLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxFQUFFO2dCQUN4QixhQUFhLEdBQUcsSUFBSSxDQUFDLHNCQUFzQixLQUFLLElBQUksQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUM7YUFDcEY7U0FDSjthQUFNO1lBQ0gsSUFBSSxTQUFTLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxFQUFFO2dCQUN4QixJQUFJLENBQUMsc0JBQXNCLEdBQUcsSUFBSSxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQzthQUNsRTtTQUNKO1FBQ0QsT0FBTyxhQUFhLENBQUM7UUFFckIsU0FBUyxTQUFTLENBQUMsT0FBTztZQUN0QixPQUFPLE9BQU8sSUFBSSxPQUFPLENBQUMsS0FBSyxJQUFJLE9BQU8sQ0FBQyxLQUFLLENBQUMsU0FBUyxJQUFJLE9BQU8sQ0FBQyxLQUFLLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQTtRQUM5RixDQUFDO0lBQ0wsQ0FBQztJQUVPLHNCQUFzQjtRQUMxQixJQUFJLGNBQWMsR0FBWSxJQUFJLENBQUM7UUFDbkMsSUFBSSxJQUFJLENBQUMsTUFBTSxJQUFJLElBQUksQ0FBQyxNQUFNLENBQUMsS0FBSyxJQUFJLElBQUksQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLEtBQUssSUFBSSxJQUFJLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsV0FBVyxFQUFFO1lBQ3BHLGNBQWMsR0FBRyxJQUFJLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsV0FBVyxDQUFDLE1BQU0sS0FBSyxJQUFJLENBQUMsYUFBYSxDQUFDLFdBQVcsQ0FBQyxNQUFNLENBQUM7U0FDekc7UUFDRCxJQUFJLElBQUksQ0FBQyxNQUFNLENBQUMsUUFBUSxLQUFLLFFBQVEsSUFBSSxDQUFDLElBQUksQ0FBQyx1QkFBdUIsRUFBRSxLQUFLLEtBQUssSUFBSSxjQUFjLEtBQUssS0FBSyxDQUFDO1lBQUUsT0FBTztRQUV4SCxJQUFJLGFBQWEsR0FBWSxLQUFLLENBQUM7UUFDbkMsSUFBSSxhQUFhLEdBQVksS0FBSyxDQUFDO1FBQ25DLElBQUksSUFBSSxDQUFDLE1BQU0sQ0FBQyxLQUFLLElBQUksSUFBSSxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsU0FBUyxFQUFFO1lBQ2xELGFBQWEsR0FBRyxJQUFJLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxTQUFTLENBQUMsSUFBSSxLQUFLLE1BQU0sQ0FBQztZQUM1RCxhQUFhLEdBQUcsSUFBSSxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsU0FBUyxDQUFDLElBQUksS0FBSyxPQUFPLENBQUM7U0FDaEU7UUFDRCxJQUFJLENBQUMsY0FBYyxDQUFDLGFBQWEsQ0FBQyxDQUFDO1FBQ25DLElBQUksQ0FBQyxjQUFjLENBQUMsYUFBYSxDQUFDLENBQUM7SUFDdkMsQ0FBQztJQUVEOztPQUVHO0lBQ0ssWUFBWTtRQUNoQixJQUFJLFNBQVMsR0FBWSxJQUFJLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxhQUFhLENBQUMsYUFBYSxDQUFDLHNCQUFzQixDQUFDLENBQUM7UUFDL0YsSUFBSSxNQUFNLEdBQVksSUFBSSxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsYUFBYSxDQUFDLGFBQWEsQ0FBQyxxQ0FBcUMsQ0FBQyxDQUFDO1FBRTNHLElBQUksQ0FBQyxhQUFhLENBQUMsTUFBTSxDQUFDLHFCQUFxQixFQUFFLENBQUMsS0FBSyxHQUFHLFNBQVMsQ0FBQyxxQkFBcUIsRUFBRSxDQUFDLEtBQUssQ0FBQyxDQUFDO0lBQ3ZHLENBQUM7SUFFTyxpQkFBaUI7UUFDckIsSUFBSSxDQUFDLFdBQVcsQ0FBQyxTQUFTLENBQUMsa0JBQWtCLENBQUMsRUFBRSxDQUFDLENBQUM7UUFDbEQsSUFBSSxDQUFDLFdBQVcsQ0FBQyxTQUFTLENBQUMsZUFBZSxDQUFDLEVBQUUsQ0FBQyxDQUFDO1FBQy9DLElBQUksQ0FBQyxXQUFXLENBQUMsU0FBUyxDQUFDLGVBQWUsQ0FBQyxFQUFFLENBQUMsQ0FBQztRQUMvQyxJQUFJLENBQUMsV0FBVyxDQUFDLFNBQVMsQ0FBQyxtQkFBbUIsQ0FBQyxFQUFFLENBQUMsQ0FBQztJQUN2RCxDQUFDO0lBRUQ7Ozs7T0FJRztJQUNLLGNBQWM7UUFDbEIsMEZBQTBGO1FBQzFGLElBQUksUUFBUSxHQUFHLEdBQVEsRUFBRTtZQUNyQixJQUFJLENBQUMsYUFBYSxDQUFDLFdBQVcsR0FBRyxJQUFJLENBQUMsV0FBVyxDQUFDLFNBQVMsQ0FBQyxjQUFjLEVBQUUsQ0FBQztZQUM3RSxJQUFJLENBQUMsYUFBYSxDQUFDLFNBQVMsR0FBRyxJQUFJLENBQUMsV0FBVyxDQUFDLFNBQVMsQ0FBQyxXQUFXLEVBQUUsQ0FBQztZQUN4RSxJQUFJLENBQUMsYUFBYSxDQUFDLFVBQVUsR0FBRyxJQUFJLENBQUMsV0FBVyxDQUFDLFNBQVMsQ0FBQyxtQkFBbUIsRUFBRSxDQUFDO1lBQ2pGLE9BQU8sSUFBSSxDQUFDLGFBQWEsQ0FBQztRQUM5QixDQUFDLENBQUM7UUFDRixJQUFJLEtBQUssR0FBRyxHQUFZLEVBQUU7WUFDdEIsT0FBTyxJQUFJLENBQUMsZ0JBQWdCLEtBQUssS0FBSyxDQUFDO1FBQzNDLENBQUMsQ0FBQztRQUNGLE9BQU8sSUFBSSxDQUFDLElBQUksQ0FBQyxLQUFLLEVBQUUsUUFBUSxDQUFDLENBQUM7SUFDdEMsQ0FBQztJQUVEOzs7O09BSUc7SUFDSyxjQUFjLENBQUMsTUFBd0I7UUFDM0MsSUFBSSxPQUFPLENBQUMsTUFBTSxDQUFDLEtBQUssV0FBVyxJQUFJLENBQUMsTUFBTSxDQUFDLGNBQWMsQ0FBQyxhQUFhLENBQUM7WUFBRSxPQUFPO1FBRXJGLElBQUksUUFBUSxHQUFHLEdBQVMsRUFBRTtZQUN0QixJQUFJLENBQUMsZ0JBQWdCLEdBQUcsSUFBSSxDQUFDO1lBQzdCLElBQUksTUFBTSxDQUFDLFdBQVcsQ0FBQyxNQUFNLEtBQUssQ0FBQyxFQUFFO2dCQUNqQyxJQUFJLENBQUMsZ0JBQWdCLEdBQUcsS0FBSyxDQUFDO2dCQUM5QixJQUFJLENBQUMsWUFBWSxFQUFFLENBQUM7Z0JBQ3BCLE9BQU87YUFDVjtZQUNELElBQUksQ0FBQyxhQUFhLEdBQUcsTUFBTSxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsYUFBYSxFQUFFLE1BQU0sQ0FBQyxDQUFDO1lBQy9ELElBQUksQ0FBQyxXQUFXLENBQUMsU0FBUyxDQUFDLGNBQWMsQ0FBQyxNQUFNLENBQUMsV0FBVyxDQUFDLENBQUM7WUFDOUQsSUFBSSxDQUFDLFdBQVcsQ0FBQyxTQUFTLENBQUMsWUFBWSxDQUFDLE1BQU0sQ0FBQyxTQUFTLElBQUksS0FBSyxDQUFDLENBQUM7WUFDbkUsSUFBSSxDQUFDLFdBQVcsQ0FBQyxTQUFTLENBQUMsbUJBQW1CLENBQUMsTUFBTSxDQUFDLFVBQVUsSUFBSSxFQUFFLENBQUMsQ0FBQztZQUN4RSxJQUFJLENBQUMsZ0JBQWdCLEdBQUcsS0FBSyxDQUFDO1lBRTlCLEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FBQyxTQUFTLENBQUMsR0FBUyxFQUFFO2dCQUM1QixJQUFJLENBQUMsZ0JBQWdCLEVBQUUsQ0FBQztnQkFDeEIsSUFBSSxDQUFDLFlBQVksRUFBRSxDQUFDO1lBQ3hCLENBQUMsQ0FBQyxDQUFDO1FBQ1AsQ0FBQyxDQUFDO1FBQ0YsSUFBSSxLQUFLLEdBQUcsR0FBWSxFQUFFO1lBQ3RCLE9BQU8sSUFBSSxDQUFDLE1BQU0sSUFBSSxJQUFJLENBQUMsTUFBTSxDQUFDLE1BQU0sR0FBRyxDQUFDLENBQUM7UUFDakQsQ0FBQyxDQUFDO1FBQ0YsSUFBSSxDQUFDLElBQUksQ0FBQyxLQUFLLEVBQUUsUUFBUSxDQUFDLENBQUM7SUFDL0IsQ0FBQztJQUVEOzs7O09BSUc7SUFDSyxJQUFJLENBQUMsTUFBZ0IsRUFBRSxHQUFhLEVBQUUsYUFBYSxHQUFHLENBQUM7UUFDM0QsSUFBSSxDQUFDLE1BQU0sRUFBRSxJQUFJLElBQUksQ0FBQyxhQUFhLENBQUMsVUFBVSxDQUFDLElBQUksQ0FBQyxXQUFXLENBQUMsQ0FBQyxJQUFJLGFBQWEsS0FBSyxHQUFHLEVBQUU7WUFDeEYsSUFBSSxhQUFhLEtBQUssR0FBRztnQkFBRSxPQUFPLENBQUMsR0FBRyxDQUFDLCtCQUErQixFQUFFLEdBQUcsQ0FBQyxDQUFDO1lBQzdFLE9BQU8sR0FBRyxFQUFFLENBQUM7U0FDaEI7YUFBTTtZQUNILEtBQUssQ0FBQyxFQUFFLENBQUMsQ0FBQyxTQUFTLENBQUMsR0FBUyxFQUFFO2dCQUMzQixhQUFhLEVBQUUsQ0FBQztnQkFDaEIsSUFBSSxDQUFDLElBQUksQ0FBQyxNQUFNLEVBQUUsR0FBRyxFQUFFLGFBQWEsQ0FBQyxDQUFDO1lBQzFDLENBQUMsQ0FBQyxDQUFDO1NBQ047SUFDTCxDQUFDO0lBRU8sZ0JBQWdCLENBQUMsYUFBYTtRQUNsQyxPQUFPLENBQ0gsT0FBTyxhQUFhLENBQUMsT0FBTyxDQUFDLEtBQUssV0FBVztZQUM3QyxhQUFhLENBQUMsT0FBTyxDQUFDLEtBQUssSUFBSTtZQUMvQixPQUFPLGFBQWEsQ0FBQyxhQUFhLENBQUMsS0FBSyxXQUFXO1lBQ25ELGFBQWEsQ0FBQyxhQUFhLENBQUMsS0FBSyxJQUFJLENBQ3hDLENBQUM7SUFDTixDQUFDO0lBRUQ7Ozs7T0FJRztJQUNLLGNBQWMsQ0FBQyxRQUFpQixJQUFJO1FBQ3hDLElBQUksWUFBWSxHQUFHLEdBQVMsRUFBRTtZQUMxQixJQUFJLEtBQUssS0FBSyxJQUFJLEVBQUU7Z0JBQ2hCLElBQUksQ0FBQyxhQUFhLENBQUMsT0FBTyxDQUFDLENBQUMsU0FBUyxHQUFHLElBQUksQ0FBQyxhQUFhLENBQUMsT0FBTyxDQUFDLENBQUMsU0FBUyxDQUFDLE9BQU8sQ0FBQyxXQUFXLEVBQUUsRUFBRSxDQUFDLENBQUM7Z0JBQ3ZHLEtBQUssSUFBSSxDQUFDLEdBQVcsQ0FBQyxFQUFFLENBQUMsR0FBRyxJQUFJLENBQUMsYUFBYSxDQUFDLGFBQWEsQ0FBQyxDQUFDLE1BQU0sRUFBRSxFQUFFLENBQUMsRUFBRTtvQkFDdkUsSUFBSSxDQUFDLGFBQWEsQ0FBQyxhQUFhLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxTQUFTLEdBQUcsSUFBSSxDQUFDLGFBQWEsQ0FBQyxhQUFhLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUMsT0FBTyxDQUFDLFdBQVcsRUFBRSxFQUFFLENBQUMsQ0FBQztpQkFDNUg7Z0JBQ0QsSUFBSSxDQUFDLGNBQWMsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLEtBQUssSUFBSSxJQUFJLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUM7Z0JBQ2pHLE9BQU87YUFDVjtZQUVELElBQUksSUFBSSxDQUFDLGFBQWEsQ0FBQyxPQUFPLENBQUM7Z0JBQzNCLElBQUksQ0FBQyxhQUFhLENBQUMsT0FBTyxDQUFDLENBQUMsU0FBUztnQkFDckMsSUFBSSxDQUFDLGFBQWEsQ0FBQyxPQUFPLENBQUMsQ0FBQyxTQUFTLENBQUMsT0FBTyxDQUFDLFFBQVEsQ0FBQyxLQUFLLENBQUMsQ0FBQyxFQUNoRTtnQkFDRSxJQUFJLENBQUMsYUFBYSxDQUFDLE9BQU8sQ0FBQyxDQUFDLFNBQVMsSUFBSSxTQUFTLENBQUM7Z0JBQ25ELEtBQUssSUFBSSxDQUFDLEdBQVcsQ0FBQyxFQUFFLENBQUMsR0FBRyxJQUFJLENBQUMsYUFBYSxDQUFDLGFBQWEsQ0FBQyxDQUFDLE1BQU0sRUFBRSxFQUFFLENBQUMsRUFBRTtvQkFDdkUsSUFBSSxDQUFDLGFBQWEsQ0FBQyxhQUFhLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxTQUFTLElBQUksU0FBUyxDQUFDO2lCQUMvRDthQUNKO1lBQ0QsSUFBSSxDQUFDLGlCQUFpQixDQUFDLEtBQUssQ0FBQyxDQUFDO1lBRTlCLElBQUksQ0FBQyxjQUFjLENBQUM7Z0JBQ2hCLGFBQWEsRUFBRSxFQUFFO2dCQUNqQixXQUFXLEVBQUUsS0FBSztnQkFDbEIsWUFBWSxFQUFFLEVBQUU7YUFDbkIsQ0FBQyxDQUFDO1lBQ0gsSUFBSSxDQUFDLGlCQUFpQixFQUFFLENBQUM7UUFDN0IsQ0FBQyxDQUFDO1FBQ0YsSUFBSSxLQUFLLEdBQUcsR0FBWSxFQUFFO1lBQ3RCLHNIQUFzSDtZQUN0SCxJQUFJLElBQUksQ0FBQyxNQUFNLENBQUMsS0FBSztnQkFDakIsSUFBSSxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsU0FBUztnQkFDM0IsSUFBSSxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsU0FBUyxDQUFDLElBQUk7Z0JBQ2hDLElBQUksQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLFNBQVMsQ0FBQyxJQUFJLEtBQUssTUFBTSxFQUM3QztnQkFDRSxJQUFJLGVBQWUsR0FBWSxJQUFJLENBQUMsZ0JBQWdCLENBQUMsSUFBSSxDQUFDLGFBQWEsQ0FBQyxDQUFDO2dCQUN6RSxJQUFJLGVBQWUsS0FBSyxJQUFJO29CQUFFLE9BQU8sZUFBZSxDQUFDO2dCQUVyRCxJQUFJLFdBQVcsR0FBVyxHQUFHLEdBQUcsSUFBSSxDQUFDLE1BQU0sR0FBRyx5QkFBeUIsQ0FBQztnQkFDeEUsSUFBSSxDQUFDLGFBQWEsQ0FBQyxPQUFPLENBQUMsR0FBRyxJQUFJLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxhQUFhLENBQUMsYUFBYSxDQUFDLFdBQVcsR0FBRyx1QkFBdUIsQ0FBQyxDQUFDO2dCQUNuSCxJQUFJLENBQUMsYUFBYSxDQUFDLGFBQWEsQ0FBQyxHQUFHLElBQUksQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLGFBQWEsQ0FBQyxnQkFBZ0IsQ0FBQyxXQUFXLEdBQUcsa0JBQWtCLENBQUMsQ0FBQztnQkFDdkgsT0FBTyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsSUFBSSxDQUFDLGFBQWEsQ0FBQyxDQUFDO2FBQ3BEO2lCQUFNO2dCQUNILE9BQU8sSUFBSSxDQUFDO2FBQ2Y7UUFDTCxDQUFDLENBQUM7UUFDRixJQUFJLENBQUMsSUFBSSxDQUFDLEtBQUssRUFBRSxZQUFZLENBQUMsQ0FBQztJQUNuQyxDQUFDO0lBR0Q7OztPQUdHO0lBQ0ssY0FBYyxDQUFDLEtBQWM7UUFDakMsSUFBSSxJQUFJLENBQUMsYUFBYSxDQUFDLFVBQVUsQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFDLEVBQUU7WUFDakQsS0FBSyxDQUFDLEVBQUUsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxHQUFTLEVBQUU7Z0JBQzNCLElBQUksQ0FBQyxXQUFXLENBQUMsR0FBRyxDQUFDLGFBQWEsQ0FBQyxLQUFLLENBQUMsQ0FBQztZQUM5QyxDQUFDLENBQUMsQ0FBQztTQUNOO0lBQ0wsQ0FBQztJQUVEOzs7T0FHRztJQUNLLFlBQVksQ0FBQyxPQUFpQjtRQUNsQyxJQUFJLE9BQU8sT0FBTyxLQUFLLFdBQVcsRUFBRTtZQUNoQyxPQUFPLEdBQUcsS0FBSyxDQUFDO1lBQ2hCLElBQUksSUFBSSxDQUFDLE1BQU0sQ0FBQyxLQUFLLElBQUksSUFBSSxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsS0FBSyxJQUFJLElBQUksQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxXQUFXLEVBQUU7Z0JBQ3JGLE9BQU8sR0FBRyxJQUFJLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsV0FBVyxDQUFDO2FBQ2pEO1NBQ0o7UUFDRCxJQUFJLElBQUksQ0FBQyxhQUFhLENBQUMsVUFBVSxDQUFDLElBQUksQ0FBQyxXQUFXLENBQUMsRUFBRTtZQUNqRCxLQUFLLENBQUMsRUFBRSxDQUFDLENBQUMsU0FBUyxDQUFDLEdBQVMsRUFBRTtnQkFDM0IsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxHQUFHLENBQUMsU0FBUyxFQUFFLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxXQUFXLENBQUMsR0FBRyxDQUFDLFdBQVcsRUFBRSxDQUFDO2dCQUNsRixJQUFJLENBQUMsWUFBWSxFQUFFLENBQUM7WUFDeEIsQ0FBQyxDQUFDLENBQUM7U0FDTjtJQUNMLENBQUM7SUFFRDs7Ozs7O09BTUc7SUFDSyxpQkFBaUIsQ0FBQyxXQUFvQixLQUFLO1FBQy9DLElBQUksQ0FBQyxXQUFXLENBQUMsU0FBUyxDQUFDLFlBQVksQ0FBQyxRQUFRLENBQUMsQ0FBQztJQUN0RCxDQUFDO0lBRUQsc0JBQXNCO0lBQ3RCOzs7OztPQUtHO0lBQ0ssZ0JBQWdCLENBQUMsUUFBYztRQUNuQyxJQUFJLFFBQVEsR0FBWSxLQUFLLENBQUM7UUFDOUIsSUFBSSxDQUFDLFFBQVE7WUFBRSxRQUFRLEdBQUcsSUFBSSxDQUFDLFdBQVcsQ0FBQyxTQUFTLENBQUMsc0JBQXNCLEVBQUUsQ0FBQztRQUM5RSxRQUFRLENBQUMsT0FBTyxDQUFDLENBQUMsTUFBVyxFQUFFLEVBQUU7WUFDN0IsSUFBSSxDQUFDLFVBQVUsQ0FBQyxNQUFNLENBQUMsQ0FBQztZQUN4QixJQUFJLFNBQVMsR0FBRyxNQUFNLENBQUMsU0FBUyxFQUFFLENBQUM7WUFDbkMsSUFBSSxTQUFTLENBQUMsZ0JBQWdCLEVBQUU7Z0JBQzVCLElBQUksQ0FBQyxVQUFVLENBQUMsU0FBUyxDQUFDLGdCQUFnQixDQUFDLENBQUE7YUFDOUM7aUJBQU07Z0JBQ0gsSUFBSSxNQUFNLENBQUMsTUFBTSxFQUFFO29CQUNmLFFBQVEsR0FBRyxJQUFJLENBQUM7b0JBQ2hCLElBQUksQ0FBQyxVQUFVLENBQUMsTUFBTSxDQUFDLE1BQU0sRUFBRSxLQUFLLENBQUMsQ0FBQztvQkFDdEMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxNQUFNLEdBQUcsTUFBTSxDQUFDO29CQUM5QixNQUFNLENBQUMsTUFBTSxHQUFHLE1BQU0sQ0FBQztvQkFDdkIsU0FBUyxDQUFDLE1BQU0sR0FBRyxNQUFNLENBQUM7aUJBQzdCO2FBQ0o7UUFDTCxDQUFDLENBQUMsQ0FBQztRQUNILElBQUksUUFBUTtZQUFFLElBQUksQ0FBQyxhQUFhLENBQUMsSUFBSSxDQUFDLENBQUM7SUFDM0MsQ0FBQztJQUVPLFVBQVUsQ0FBQyxPQUFZLEVBQUUsZUFBd0IsSUFBSTtRQUN6RCxJQUFJLFlBQVksRUFBRTtZQUNkLElBQUksU0FBUyxHQUFHLE9BQU8sQ0FBQyxTQUFTLEVBQUUsQ0FBQztZQUNwQyxTQUFTLENBQUMsZUFBZSxHQUFHLElBQUksQ0FBQyx1QkFBdUIsQ0FBQztZQUN6RCxTQUFTLENBQUMsWUFBWSxHQUFHLElBQUksQ0FBQyx1QkFBdUIsQ0FBQztZQUN0RCxTQUFTLENBQUMsVUFBVSxHQUFHLElBQUksQ0FBQyx1QkFBdUIsQ0FBQztTQUN2RDtRQUNELElBQUksT0FBTyxDQUFDLFNBQVMsRUFBRTtZQUNuQixPQUFPLENBQUMsU0FBUyxDQUFDLENBQUMsSUFBSSxDQUFDLHVCQUF1QixDQUFDLENBQUM7U0FDcEQ7YUFBTTtZQUNILE9BQU8sQ0FBQyxNQUFNLEdBQUcsQ0FBQyxJQUFJLENBQUMsdUJBQXVCLENBQUM7U0FDbEQ7UUFDRCxPQUFPLENBQUMsWUFBWSxHQUFHLElBQUksQ0FBQyx1QkFBdUIsQ0FBQztRQUNwRCxPQUFPLENBQUMsVUFBVSxHQUFHLElBQUksQ0FBQyx1QkFBdUIsQ0FBQztJQUN0RCxDQUFDO0lBQ0Qsc0JBQXNCO0lBRXRCLHdHQUF3RztJQUN4Ryx1Q0FBdUM7SUFDdkMsd0dBQXdHO0lBQ2hHLGVBQWUsQ0FBQyxZQUEwQjtRQUM5QyxJQUFJLFlBQVksQ0FBQyxjQUFjLENBQUMsd0JBQXdCLENBQUM7WUFBRSxJQUFJLENBQUMsdUJBQXVCLEdBQUcsWUFBWSxDQUFDLHNCQUFzQixDQUFDO1FBQzlILElBQUksQ0FBQyxVQUFVLEdBQWtCLElBQUksQ0FBQyxPQUFPLENBQUMsb0JBQW9CLEVBQUUsQ0FBQztRQUVyRSxJQUFJLENBQUMsV0FBVyxHQUFHLElBQUksQ0FBQyxhQUFhLENBQUMsbUJBQW1CLENBQUMsWUFBWSxFQUFFLElBQUksQ0FBQyxVQUFVLENBQUMsQ0FBQztRQUN6RixJQUFJLENBQUMsV0FBVyxDQUFDLE9BQU8sQ0FBQyxRQUFRLENBQUMsR0FBRyxJQUFJLENBQUMsTUFBTSxDQUFDO1FBQ2pELElBQUksQ0FBQyxXQUFXLENBQUMsc0JBQXNCLEdBQUcsS0FBSyxDQUFDO1FBQ2hELElBQUksQ0FBQyxXQUFXLENBQUMsdUJBQXVCLEdBQUcsQ0FBQyxNQUFXLEVBQVEsRUFBRTtZQUM3RCxJQUFJLENBQUMsZ0JBQWdCLENBQUMsTUFBTSxDQUFDLE9BQU8sQ0FBQyxDQUFDO1lBQ3RDLElBQUksQ0FBQyxZQUFZLEVBQUUsQ0FBQztRQUN4QixDQUFDLENBQUE7UUFDRCxJQUFJLENBQUMsYUFBYSxDQUFDLGNBQWMsQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFDLENBQUM7SUFDeEQsQ0FBQztJQUVPLGFBQWEsQ0FBQyxhQUFrQztRQUNwRCxJQUFJLENBQUMsYUFBYSxDQUFDLFlBQVksQ0FBQyxhQUFhLEVBQUUsSUFBSSxDQUFDLE1BQU0sRUFBRSxJQUFJLENBQUMsdUJBQXVCLENBQUMsQ0FBQztRQUMxRixJQUFJLENBQUMsYUFBYSxFQUFFLENBQUM7SUFDekIsQ0FBQztJQUVPLG9CQUFvQixDQUFDLFdBQW9CLElBQUk7UUFDakQsSUFBSSxJQUFJLENBQUMsYUFBYSxDQUFDLFVBQVUsQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFDLEVBQUU7WUFDakQsSUFBSSxDQUFDLHVCQUF1QixHQUFHLFFBQVEsQ0FBQztZQUV4QyxJQUFJLENBQUMsYUFBYSxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQztZQUNoQyxJQUFJLElBQUksQ0FBQyxNQUFNLENBQUMsUUFBUSxLQUFLLFFBQVEsSUFBSSxJQUFJLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxTQUFTLENBQUMsSUFBSSxLQUFLLE9BQU8sRUFBRTtnQkFDbkYsSUFBSSxDQUFDLGNBQWMsQ0FBQyxJQUFJLENBQUMsYUFBYSxDQUFDLENBQUM7YUFDM0M7WUFFRCxJQUFJLENBQUMsWUFBWSxFQUFFLENBQUM7U0FDdkI7SUFDTCxDQUFDO0lBRU8sV0FBVyxDQUFDLFFBQW9CLEVBQUUsb0JBQTZCLElBQUk7UUFDdkUsd0ZBQXdGO1FBQ3hGLElBQUksQ0FBQyxhQUFhLENBQUMsdUJBQXVCLENBQUMsUUFBUSxFQUFFLElBQUksQ0FBQyxNQUFNLEVBQUUsSUFBSSxDQUFDLE1BQU0sRUFBRSxJQUFJLENBQUMsV0FBVyxDQUFDLENBQUM7UUFFakcsSUFBSSxpQkFBaUIsRUFBRTtZQUNuQixJQUFJLENBQUMsYUFBYSxDQUFDLFVBQVUsQ0FBQyxRQUFRLENBQUMsQ0FBQztTQUMzQztRQUVELElBQUksSUFBSSxDQUFDLGFBQWEsQ0FBQyxpQkFBaUIsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLFFBQVEsQ0FBQyxJQUFJLElBQUksQ0FBQyxhQUFhLENBQUMsVUFBVSxDQUFDLElBQUksQ0FBQyxXQUFXLENBQUMsRUFBRTtZQUMvRyxJQUFJLENBQUMseUJBQXlCLEVBQUUsQ0FBQztTQUNwQztRQUVELEtBQUssRUFBRSxDQUFDLFNBQVMsQ0FBQyxHQUFTLEVBQUU7WUFDekIsSUFBSSxDQUFDLGdCQUFnQixFQUFFLENBQUM7WUFDeEIsSUFBSSxDQUFDLHFCQUFxQixFQUFFLENBQUM7UUFDakMsQ0FBQyxDQUFDLENBQUM7SUFDUCxDQUFDO0lBRUQsd0dBQXdHO0lBQ3hHLHNDQUFzQztJQUN0Qyx3R0FBd0c7SUFDaEcsbUJBQW1CLENBQUksVUFBa0IsRUFBRSxpQkFBb0I7UUFDbkUsUUFBUSxVQUFVLEVBQUU7WUFDaEIsS0FBSyxZQUFZLENBQUM7WUFDbEIsS0FBSyxXQUFXLENBQUM7WUFDakIsS0FBSyxPQUFPLENBQUM7WUFDYixLQUFLLFFBQVE7Z0JBQ1QsSUFBSSxDQUFDLHFCQUFxQixDQUFJLGlCQUFpQixDQUFDLENBQUM7Z0JBQ2pELE1BQU07WUFDVjtnQkFDSSxPQUFPLENBQUMsS0FBSyxDQUFDLDRDQUE0QyxFQUFFLFVBQVUsQ0FBQyxDQUFDO1NBQy9FO0lBQ0wsQ0FBQztJQUVPLHFCQUFxQixDQUFJLE9BQVU7UUFDdkMsSUFBSSxDQUFDLGNBQWMsQ0FBQyxnQkFBZ0IsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLEVBQUUsRUFBRSxPQUFPLENBQUMsQ0FBQztJQUNsRSxDQUFDO0lBRU8sMkJBQTJCO1FBQy9CLElBQUksQ0FBQyxjQUFjLENBQUMsWUFBWSxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsRUFBRSxDQUFDLENBQUM7SUFDckQsQ0FBQztJQUVPLHdCQUF3QjtRQUM1QixJQUFJLENBQUMsZ0JBQWdCLENBQUMsY0FBYyxHQUFHLElBQUksQ0FBQyxjQUFjLENBQUMsa0JBQWtCLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxFQUFFLENBQUMsQ0FBQyxTQUFTLENBQUMsQ0FBQyxRQUFpQixFQUFRLEVBQUU7WUFDaEksSUFBSSxDQUFDLHFCQUFxQixDQUFDLFFBQVEsQ0FBQyxDQUFDO1FBQ3pDLENBQUMsQ0FBQyxDQUFDO1FBRUgsSUFBSSxDQUFDLGdCQUFnQixDQUFDLGVBQWUsR0FBRyxJQUFJLENBQUMsY0FBYyxDQUFDLGNBQWMsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLEVBQUUsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxDQUFDLFdBQWlDLEVBQVEsRUFBRTtZQUM3SSxJQUFJLENBQUMsb0JBQW9CLENBQUMsV0FBVyxDQUFDLENBQUM7UUFDM0MsQ0FBQyxDQUFDLENBQUM7UUFFSCxJQUFJLENBQUMsZ0JBQWdCLENBQUMsYUFBYSxHQUFHLElBQUksQ0FBQyxjQUFjLENBQUMsb0JBQW9CLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxFQUFFLENBQUMsQ0FBQyxTQUFTLENBQUMsQ0FBQyxLQUF1QyxFQUFRLEVBQUU7WUFDdkosSUFBSSxLQUFLLENBQUMsTUFBTSxLQUFLLFFBQVEsRUFBRTtnQkFDM0IsSUFBSSxNQUFNLEdBQVcsQ0FBQyxPQUFPLElBQUksQ0FBQyxNQUFNLENBQUMsUUFBUSxLQUFLLFdBQVcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDO2dCQUNqRyxJQUFJLENBQUMsc0JBQXNCLENBQUMsQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQztnQkFDckQsSUFBSSxDQUFDLHFCQUFxQixFQUFFLENBQUM7YUFDaEM7UUFDTCxDQUFDLENBQUMsQ0FBQztJQUNQLENBQUM7SUFFRCx3R0FBd0c7SUFDeEcsMENBQTBDO0lBQzFDLHdHQUF3RztJQUNoRyxxQkFBcUIsQ0FBQyxRQUFpQixFQUFFLFVBQW9CO1FBQ2pFLElBQUksV0FBVyxHQUFXLENBQUMsT0FBTyxVQUFVLEtBQUssV0FBVyxJQUFJLFVBQVUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQztRQUNoRyxJQUFJLE9BQU8sUUFBUSxLQUFLLFdBQVcsRUFBRTtZQUNqQyxXQUFXLEdBQUcsUUFBUSxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUM7U0FDbEM7UUFFRCxJQUFJLGVBQWUsR0FBZ0MsSUFBSSwyQkFBMkIsRUFBRSxDQUFDO1FBRXJGLGVBQWUsQ0FBQyxXQUFXLEdBQUcsV0FBVyxDQUFDO1FBQzFDLGVBQWUsQ0FBQyxhQUFhLEdBQUcsSUFBSSxDQUFDLGFBQWEsQ0FBQyxxQkFBcUIsQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFDLE9BQU8sRUFBRSxJQUFJLENBQUMsTUFBTSxDQUFDLFNBQVMsQ0FBQyxLQUFLLEVBQUUsSUFBSSxDQUFDLE1BQU0sQ0FBQyxTQUFTLENBQUMsU0FBUyxFQUFFLElBQUksQ0FBQyxNQUFNLENBQUMsUUFBUSxDQUFDLENBQUM7UUFDdkwsbUZBQW1GO1FBRW5GLElBQUksQ0FBQyxtQkFBbUIsQ0FBOEIsV0FBVyxFQUFFLGVBQWUsQ0FBQyxDQUFDO0lBQ3hGLENBQUM7SUFFTyx3QkFBd0I7UUFDNUIsSUFBSSxDQUFDLHFCQUFxQixDQUFDLFNBQVMsRUFBRSxJQUFJLENBQUMsQ0FBQztJQUNoRCxDQUFDO0lBRUQsd0dBQXdHO0lBQ3hHLG1CQUFtQjtJQUNuQix3R0FBd0c7SUFDaEcsb0JBQW9CLENBQUMsV0FBaUM7UUFDMUQsSUFBSSxXQUFXLEdBQTRCLElBQUksdUJBQXVCLEVBQUUsQ0FBQztRQUV6RSxXQUFXLENBQUMsS0FBSyxHQUFHLFdBQVcsQ0FBQyxLQUFLLENBQUM7UUFDdEMsV0FBVyxDQUFDLEtBQUssR0FBRyxXQUFXLENBQUMsS0FBSyxDQUFDO1FBQ3RDLFdBQVcsQ0FBQyxXQUFXLEdBQUcsV0FBVyxDQUFDLFdBQVcsQ0FBQztRQUNsRCxXQUFXLENBQUMsUUFBUSxHQUFHLFdBQVcsQ0FBQyxRQUFRLENBQUM7UUFDNUMsV0FBVyxDQUFDLEtBQUssR0FBRyxXQUFXLENBQUMsSUFBSSxDQUFDO1FBRXJDLElBQUksQ0FBQyxtQkFBbUIsQ0FBMEIsT0FBTyxFQUFFLFdBQVcsQ0FBQyxDQUFDO0lBQzVFLENBQUM7SUFFTyxxQkFBcUI7UUFDekIsSUFBSSxXQUFXLEdBQTRCLElBQUksdUJBQXVCLEVBQUUsQ0FBQztRQUN6RSxJQUFJLENBQUMsbUJBQW1CLENBQTBCLE9BQU8sRUFBRSxXQUFXLENBQUMsQ0FBQztJQUM1RSxDQUFDO0lBRU8sc0JBQXNCLENBQUMsU0FBd0I7UUFDbkQsSUFBSSxRQUFRLEdBQVcsQ0FBQyxPQUFPLElBQUksQ0FBQyxNQUFNLENBQUMsUUFBUSxLQUFLLFdBQVcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDO1FBRW5HLEtBQUssSUFBSSxDQUFDLEdBQVcsQ0FBQyxFQUFFLENBQUMsR0FBRyxTQUFTLENBQUMsTUFBTSxFQUFFLEVBQUUsQ0FBQyxFQUFFO1lBQy9DLEtBQUssSUFBSSxDQUFDLEdBQVcsQ0FBQyxFQUFFLENBQUMsR0FBRyxJQUFJLENBQUMsR0FBRyxDQUFDLE1BQU0sRUFBRSxFQUFFLENBQUMsRUFBRTtnQkFDOUMsSUFBSSxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxFQUFFLEtBQUssSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxRQUFRLEVBQUUsRUFBRTtvQkFDOUQsSUFBSSxDQUFDLEdBQUcsQ0FBQyxNQUFNLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDO29CQUN0QixNQUFNO2lCQUNUO2FBQ0o7U0FDSjtJQUNMLENBQUM7SUFFRCx3R0FBd0c7SUFDeEcsbUNBQW1DO0lBQ25DLHdHQUF3RztJQUNoRyxnQkFBZ0I7UUFDcEIsSUFBSSxJQUFJLENBQUMsYUFBYSxDQUFDLFVBQVUsQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFDLEVBQUU7WUFDakQsSUFBSSxDQUFDLFdBQVcsQ0FBQyxHQUFHLENBQUMsdUJBQXVCLENBQUMsSUFBSSxDQUFDLENBQUM7WUFDbkQsSUFBSSxDQUFDLFdBQVcsQ0FBQyxHQUFHLENBQUMsY0FBYyxDQUFDLElBQUksQ0FBQyxDQUFDO1lBQzFDLElBQUksQ0FBQyxXQUFXLENBQUMsR0FBRyxDQUFDLFlBQVksQ0FBQyxJQUFJLENBQUMsQ0FBQztZQUV4QyxJQUFJLE9BQU8sSUFBSSxDQUFDLGdCQUFnQixDQUFDLGFBQWEsS0FBSyxXQUFXLEVBQUU7Z0JBQzVELElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxhQUFhLENBQUMsV0FBVyxFQUFFLENBQUM7YUFDckQ7U0FDSjtJQUNMLENBQUM7SUFFTyw2QkFBNkI7UUFDakMsSUFBSSxVQUFVLEdBQTBCO1lBQ3BDLE9BQU8sRUFBRSxDQUFDLE9BQWlDLEVBQVEsRUFBRTtnQkFDakQsSUFBSSxDQUFDLG1CQUFtQixDQUFDLElBQUksQ0FBQyxDQUFDO2dCQUUvQixJQUFJLE9BQU8sSUFBSSxDQUFDLGdCQUFnQixDQUFDLGFBQWEsS0FBSyxXQUFXLEVBQUU7b0JBQzVELElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxhQUFhLENBQUMsV0FBVyxFQUFFLENBQUM7aUJBQ3JEO2dCQUNELElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxhQUFhLEdBQUcsSUFBSSxDQUFDLHVCQUF1QixDQUFDLE9BQU8sQ0FBQyxDQUFDLFNBQVMsQ0FBQyxDQUFDLFNBQWlDLEVBQVEsRUFBRTtvQkFDOUgsT0FBTyxDQUFDLGVBQWUsQ0FBQyxTQUFTLENBQUMsSUFBSSxFQUFFLFNBQVMsQ0FBQyxLQUFLLENBQUMsQ0FBQztvQkFDekQsSUFBSSxDQUFDLG1CQUFtQixDQUFDLEtBQUssQ0FBQyxDQUFDO2dCQUNwQyxDQUFDLENBQUMsQ0FBQztZQUNQLENBQUM7U0FDSixDQUFDO1FBRUYsSUFBSSxDQUFDLFdBQVcsQ0FBQyxHQUFHLENBQUMsdUJBQXVCLENBQUMsVUFBVSxDQUFDLENBQUM7SUFDN0QsQ0FBQztJQUVPLHVCQUF1QixDQUFDLGlCQUEyQztRQUN2RSxPQUFPLElBQUksVUFBVSxDQUF5QixDQUFDLFNBQTZDLEVBQVEsRUFBRTtZQUNsRyxRQUFRLElBQUksQ0FBQyxNQUFNLENBQUMsUUFBUSxFQUFFO2dCQUMxQixLQUFLLFVBQVUsQ0FBQztnQkFDaEIsS0FBSyxTQUFTO29CQUNhLElBQUksQ0FBQyxhQUFjLENBQUMsc0JBQXNCLENBQUMsaUJBQWlCLENBQUMsT0FBTyxFQUFFLElBQUksQ0FBQyxXQUFXLENBQUMsT0FBTyxDQUFDLEtBQUssRUFBRSxDQUFDLENBQUMsU0FBUyxDQUFDLENBQUMsU0FBaUMsRUFBUSxFQUFFO3dCQUNqTCxTQUFTLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDO3dCQUMxQixTQUFTLENBQUMsUUFBUSxFQUFFLENBQUM7b0JBQ3pCLENBQUMsQ0FBQyxDQUFDO29CQUVILE1BQU07Z0JBQ1YsS0FBSyxRQUFRO29CQUNULElBQUksWUFBWSxHQUEyQixJQUFJLHNCQUFzQixDQUFDLGlCQUFpQixDQUFDLE9BQU8sRUFBRSxTQUFTLENBQUMsQ0FBQztvQkFDNUcsSUFBSSxDQUFDLG1CQUFtQixDQUF5QixZQUFZLEVBQUUsWUFBWSxDQUFDLENBQUM7b0JBRTdFLE1BQU07Z0JBQ1Y7b0JBQ0ksT0FBTyxDQUFDLEtBQUssQ0FBQyw4Q0FBOEMsRUFBRSxJQUFJLENBQUMsTUFBTSxDQUFDLFFBQVEsQ0FBQyxDQUFDO29CQUNwRixTQUFTLENBQUMsUUFBUSxFQUFFLENBQUM7YUFDNUI7UUFDTCxDQUFDLENBQUMsQ0FBQztJQUNQLENBQUM7SUFFRCx3R0FBd0c7SUFDeEcsaUJBQWlCO0lBQ2pCLHdHQUF3RztJQUNoRyxjQUFjO1FBQ2xCLElBQUksT0FBTyxJQUFJLENBQUMsR0FBRyxLQUFLLFdBQVcsRUFBRTtZQUNqQyxJQUFJLFNBQVMsR0FBUTtnQkFDakIsaUNBQWlDO2dCQUNqQyxLQUFLLEVBQUUsSUFBSSxDQUFDLGNBQWM7Z0JBQzFCLEVBQUUsRUFBRSxJQUFJLENBQUMsTUFBTSxDQUFDLEVBQUU7Z0JBQ2xCLElBQUksRUFBRSxJQUFJLENBQUMsR0FBRztnQkFDZCxPQUFPLEVBQUUsSUFBSSxDQUFDLE1BQU07YUFDdkIsQ0FBQztZQUVGLElBQUksQ0FBQyxhQUFhLENBQUMscUJBQXFCLENBQUMsSUFBSSxDQUFDLEdBQUcsRUFBRSxTQUFTLENBQUMsQ0FBQztZQUU5RCwwQ0FBMEM7WUFDMUMsa0NBQWtDO1lBQ2xDLElBQUksQ0FBQyxHQUFHLENBQUMsT0FBTyxDQUFDLFdBQVcsR0FBRyxDQUFDLE9BQWdCLEVBQVEsRUFBRTtnQkFDdEQsSUFBSSxDQUFDLGNBQWMsR0FBRyxPQUFPLENBQUM7WUFDbEMsQ0FBQyxDQUFDO1lBRUYsSUFBSSxDQUFDLEdBQUcsQ0FBQyxPQUFPLENBQUMsVUFBVSxHQUFHLENBQUMsZ0JBQWtDLEVBQVEsRUFBRTtnQkFDdkUsSUFBSSxZQUFZLEdBQW1CLEVBQUUsQ0FBQztnQkFFdEMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxHQUFHLENBQUMsV0FBVyxDQUFDLENBQUMsUUFBaUIsRUFBUSxFQUFFO29CQUN6RCxJQUFJLE9BQU8sUUFBUSxDQUFDLEVBQUUsS0FBSyxXQUFXLElBQUksUUFBUSxDQUFDLEVBQUUsS0FBSyxnQkFBZ0IsQ0FBQyxLQUFLLEVBQUU7d0JBQzlFLFFBQVEsQ0FBQyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsS0FBSyxDQUFDLEdBQUcsZ0JBQWdCLENBQUMsSUFBSSxDQUFDO3dCQUM5RCxZQUFZLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxDQUFDO3FCQUMvQjtnQkFDTCxDQUFDLENBQUMsQ0FBQztnQkFFSCxJQUFJLGFBQWEsR0FBc0Q7b0JBQ25FLFFBQVEsRUFBRSxZQUFZO29CQUN0QixPQUFPLEVBQUUsQ0FBQyxnQkFBZ0IsQ0FBQyxLQUFLLENBQUM7aUJBQ3BDLENBQUM7Z0JBRUYsSUFBSSxDQUFDLFdBQVcsQ0FBQyxHQUFHLENBQUMsWUFBWSxDQUFDLGFBQWEsQ0FBQyxDQUFDO1lBQ3JELENBQUMsQ0FBQztZQUVGLElBQUksQ0FBQyxHQUFHLENBQUMsT0FBTyxDQUFDLFNBQVMsR0FBRyxDQUFDLFdBQW1CLEVBQVEsRUFBRTtnQkFDdkQsSUFBSSxJQUFJLENBQUMsTUFBTSxDQUFDLFFBQVEsS0FBSyxRQUFRLEVBQUU7b0JBQ25DLElBQUksQ0FBQyxXQUFXLENBQUMsR0FBRyxDQUFDLGNBQWMsQ0FBQyxXQUFXLENBQUMsQ0FBQztpQkFDcEQ7cUJBQ0k7b0JBQ0QsT0FBTyxDQUFDLElBQUksQ0FBQyxpR0FBaUcsQ0FBQyxDQUFDO2lCQUNuSDtZQUNMLENBQUMsQ0FBQztZQUVGLElBQUksQ0FBQyxHQUFHLENBQUMsT0FBTyxDQUFDLE9BQU8sR0FBRyxDQUFDLEtBQWlCLEVBQUUsbUJBQTRCLEtBQUssRUFBUSxFQUFFO2dCQUN0Rjs7Ozs7OzttQkFPRztnQkFDSCxJQUFJLE9BQU8sSUFBSSxDQUFDLE1BQU0sQ0FBQyxRQUFRLEtBQUssV0FBVyxJQUFJLElBQUksQ0FBQyxNQUFNLENBQUMsUUFBUSxLQUFLLFFBQVEsRUFBRTtvQkFDbEYsSUFBSSxNQUFNLEdBQVcsQ0FBQyxPQUFPLElBQUksQ0FBQyxNQUFNLENBQUMsUUFBUSxLQUFLLFdBQVcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDO29CQUVqRyxLQUFLLElBQUksQ0FBQyxHQUFXLENBQUMsRUFBRSxDQUFDLEdBQUcsS0FBSyxDQUFDLE1BQU0sRUFBRSxFQUFFLENBQUMsRUFBRTt3QkFDM0MsSUFBSSxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7cUJBQzNCO29CQUVELElBQUksQ0FBQyxXQUFXLENBQUMsSUFBSSxDQUFDLEdBQUcsRUFBRSxLQUFLLENBQUMsQ0FBQztvQkFDbEMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxHQUFHLENBQUMsYUFBYSxDQUFDLEVBQUUsR0FBRyxFQUFFLEtBQUssQ0FBQyxLQUFLLEVBQUUsRUFBRSxDQUFDLENBQUM7b0JBRTNELElBQUksZ0JBQWdCLEVBQUU7d0JBQ2xCLElBQUksQ0FBQyxXQUFXLENBQUMsR0FBRyxDQUFDLGtCQUFrQixDQUFDLElBQUksQ0FBQyxXQUFXLENBQUMsR0FBRyxDQUFDLFVBQVUsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsUUFBUSxFQUFFLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQztxQkFDbEg7aUJBQ0o7cUJBQ0k7b0JBQ0QsT0FBTyxDQUFDLElBQUksQ0FBQyxnRkFBZ0YsQ0FBQyxDQUFDO2lCQUNsRztZQUNMLENBQUMsQ0FBQztZQUVGLElBQUksQ0FBQyxHQUFHLENBQUMsT0FBTyxDQUFDLFVBQVUsR0FBRyxDQUFDLEdBQTZDLEVBQVEsRUFBRTtnQkFDbEYsSUFBSSxPQUFPLElBQUksQ0FBQyxNQUFNLENBQUMsUUFBUSxLQUFLLFdBQVcsSUFBSSxJQUFJLENBQUMsTUFBTSxDQUFDLFFBQVEsS0FBSyxRQUFRLEVBQUU7b0JBQ2xGLElBQUksWUFBWSxHQUFrQixFQUFFLENBQUM7b0JBRXJDLElBQUksT0FBTyxHQUFHLEtBQUssUUFBUSxJQUFJLE9BQU8sR0FBRyxLQUFLLFFBQVEsRUFBRTt3QkFDcEQsWUFBWSxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsUUFBUSxFQUFFLENBQUMsQ0FBQztxQkFDckM7eUJBQ0k7d0JBQ0QsS0FBSyxJQUFJLENBQUMsR0FBVyxDQUFDLEVBQUUsQ0FBQyxHQUFHLEdBQUcsQ0FBQyxNQUFNLEVBQUUsRUFBRSxDQUFDLEVBQUU7NEJBQ3pDLFlBQVksQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLFFBQVEsRUFBRSxDQUFDLENBQUM7eUJBQ3JDO3FCQUNKO29CQUVELElBQUksQ0FBQyxzQkFBc0IsQ0FBQyxZQUFZLENBQUMsQ0FBQztvQkFFMUMsSUFBSSxHQUFHLEdBQVcsT0FBTyxJQUFJLENBQUMsTUFBTSxDQUFDLFFBQVEsS0FBSyxXQUFXLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxRQUFRLENBQUM7b0JBQzVGLElBQUksVUFBVSxHQUFlLEVBQUUsQ0FBQztvQkFFaEMsS0FBSyxJQUFJLENBQUMsR0FBVyxDQUFDLEVBQUUsQ0FBQyxHQUFHLFlBQVksQ0FBQyxNQUFNLEVBQUUsRUFBRSxDQUFDLEVBQUU7d0JBQ2xELFVBQVUsQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDLEdBQUcsQ0FBQyxFQUFFLFlBQVksQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUM7cUJBQy9DO29CQUVEOzs7Ozs7O3VCQU9HO29CQUVILElBQUksY0FBYyxHQUFtRTt3QkFDakYsTUFBTSxFQUFFLFVBQVU7cUJBQ3JCLENBQUM7b0JBRUYsSUFBSSxDQUFDLFdBQVcsQ0FBQyxHQUFHLENBQUMsYUFBYSxDQUFDLGNBQWMsQ0FBQyxDQUFDO29CQUNuRCxJQUFJLENBQUMscUJBQXFCLEVBQUUsQ0FBQztpQkFDaEM7cUJBQ0k7b0JBQ0QsT0FBTyxDQUFDLElBQUksQ0FBQyxnRkFBZ0YsQ0FBQyxDQUFDO2lCQUNsRztZQUNMLENBQUMsQ0FBQztZQUVGLElBQUksQ0FBQyxHQUFHLENBQUMsT0FBTyxDQUFDLGlCQUFpQixHQUFHLENBQUMsV0FBbUIsRUFBRSxXQUFvQixFQUFFLEVBQUU7Z0JBQy9FLEtBQUssSUFBSSxDQUFDLEdBQVcsQ0FBQyxFQUFFLENBQUMsR0FBRyxJQUFJLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxNQUFNLEVBQUUsRUFBRSxDQUFDLEVBQUU7b0JBQ3hELElBQUksSUFBSSxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxLQUFLLFdBQVcsRUFBRTt3QkFDNUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxHQUFHLFdBQVcsQ0FBQztxQkFDaEQ7aUJBQ0o7WUFDTCxDQUFDLENBQUM7WUFFRixJQUFJLENBQUMsR0FBRyxDQUFDLE9BQU8sQ0FBQyxhQUFhLEdBQUcsQ0FBQyxPQUEwQixFQUFRLEVBQUU7Z0JBQ2xFLElBQUksYUFBYSxHQUFzQjtvQkFDbkMsUUFBUSxFQUFFLE1BQU07b0JBQ2hCLFVBQVUsRUFBRSxJQUFJO29CQUNoQixtQkFBbUIsRUFBRSxJQUFJO2lCQUM1QixDQUFDO2dCQUNGLHVEQUF1RDtnQkFDdkQsSUFBSSxPQUFPLENBQUMsY0FBYyxDQUFDLFdBQVcsQ0FBQztvQkFBRSxPQUFPLENBQUMsU0FBUyxHQUFHLE9BQU8sQ0FBQyxTQUFTLENBQUMsS0FBSyxDQUFDLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQztnQkFDNUYsSUFBSSxNQUFNLEdBQXNCLE1BQU0sQ0FBQyxNQUFNLENBQUMsRUFBRSxFQUFFLGFBQWEsRUFBRSxPQUFPLENBQUMsQ0FBQztnQkFDMUUsSUFBSSxPQUFPLEdBQVEsSUFBSSxDQUFDLFdBQVcsQ0FBQyxHQUFHLENBQUMsY0FBYyxDQUFDLE1BQU0sQ0FBQyxDQUFDO2dCQUMvRCxJQUFJLFFBQVEsR0FBUSxJQUFJLENBQUMsSUFBSSxDQUFDLE9BQU8sRUFBRSxFQUFFLElBQUksRUFBRSxRQUFRLEVBQUUsQ0FBQyxDQUFDO2dCQUMzRCxJQUFJLFdBQVcsR0FBUSxJQUFJLENBQUMsS0FBSyxDQUFDLFFBQVEsRUFBRSxFQUFFLFFBQVEsRUFBRSxNQUFNLEVBQUUsSUFBSSxFQUFFLFFBQVEsRUFBRSxDQUFDLENBQUM7Z0JBQ2xGLElBQUksVUFBVSxHQUFTLElBQUksQ0FBQyxhQUFhLENBQUMsU0FBUyxDQUFDLFdBQVcsRUFBRSxtRUFBbUUsQ0FBQyxDQUFDO2dCQUN0SSxNQUFNLENBQUMsVUFBVSxFQUFFLE1BQU0sQ0FBQyxRQUFRLEdBQUcsT0FBTyxDQUFDLENBQUM7WUFDbEQsQ0FBQyxDQUFDO1lBRUYsSUFBSSxDQUFDLEdBQUcsQ0FBQyxPQUFPLENBQUMsWUFBWSxHQUFHLENBQUMscUJBQThCLEtBQUssRUFBUSxFQUFFO2dCQUMxRSxJQUFJLENBQUMsYUFBYSxDQUFDLGtCQUFrQixDQUFDLENBQUM7WUFDM0MsQ0FBQyxDQUFDO1lBRUYsSUFBSSxDQUFDLEdBQUcsQ0FBQyxPQUFPLENBQUMsbUJBQW1CLEdBQUcsQ0FBQyxRQUFpQixFQUFRLEVBQUU7Z0JBQy9ELElBQUksQ0FBQyxvQkFBb0IsQ0FBQyxRQUFRLENBQUMsQ0FBQztZQUN4QyxDQUFDLENBQUM7WUFFRixnQ0FBZ0M7WUFDaEMsSUFBSSxPQUFPLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsS0FBSyxXQUFXO2dCQUFFLElBQUksQ0FBQyxHQUFHLENBQUMsS0FBSyxHQUFHLEVBQUUsQ0FBQztZQUNqRSxJQUFJLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxVQUFVLEdBQUcsR0FBUyxFQUFFO2dCQUNuQyxJQUFJLENBQUMsWUFBWSxFQUFFLENBQUM7WUFDeEIsQ0FBQyxDQUFDO1lBRUYsSUFBSSxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsYUFBYSxHQUFHLENBQUMsS0FBYyxFQUFRLEVBQUU7Z0JBQ3BELElBQUksQ0FBQyxjQUFjLENBQUMsS0FBSyxDQUFDLENBQUM7WUFDL0IsQ0FBQyxDQUFDO1lBRUYsSUFBSSxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsV0FBVyxHQUFHLENBQUMsT0FBZ0IsRUFBUSxFQUFFO2dCQUNwRCxJQUFJLENBQUMsWUFBWSxDQUFDLE9BQU8sQ0FBQyxDQUFDO1lBQy9CLENBQUMsQ0FBQztZQUVGLElBQUksQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLGFBQWEsR0FBRyxHQUFxQixFQUFFO2dCQUNsRCxPQUFPLElBQUksQ0FBQyxjQUFjLEVBQUUsQ0FBQztZQUNqQyxDQUFDLENBQUM7WUFFRixJQUFJLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxhQUFhLEdBQUcsQ0FBQyxNQUF3QixFQUFRLEVBQUU7Z0JBQzlELElBQUksQ0FBQyxhQUFhLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDO2dCQUNoQyxJQUFJLENBQUMsY0FBYyxDQUFDLE1BQU0sQ0FBQyxDQUFDO1lBQ2hDLENBQUMsQ0FBQztZQUVGLElBQUksQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLGdCQUFnQixHQUFHLENBQUMsUUFBaUIsRUFBUSxFQUFFO2dCQUMxRCxJQUFJLENBQUMsaUJBQWlCLENBQUMsUUFBUSxDQUFDLENBQUM7WUFDckMsQ0FBQyxDQUFDO1lBRUYsSUFBSSxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsYUFBYSxHQUFHLENBQUMsS0FBYyxFQUFRLEVBQUU7Z0JBQ3BELElBQUksQ0FBQyxjQUFjLENBQUMsS0FBSyxDQUFDLENBQUM7WUFDL0IsQ0FBQyxDQUFDO1lBRUYsZ0NBQWdDO1lBQ2hDLElBQUksQ0FBQyxHQUFHLENBQUMsV0FBVyxDQUFDLGFBQWEsR0FBRyxHQUFTLEVBQUU7Z0JBQzVDLElBQUksWUFBWSxHQUEyQixJQUFJLENBQUMsV0FBVyxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsYUFBYSxDQUFDLGtCQUFrQixFQUFFLENBQUMsQ0FBQztnQkFFN0csS0FBSyxJQUFJLElBQUksSUFBSSxZQUFZLEVBQUU7b0JBQzNCLElBQUksWUFBWSxDQUFDLGNBQWMsQ0FBQyxJQUFJLENBQUMsRUFBRTt3QkFDbkMsSUFBSSxXQUFXLEdBQVEsWUFBWSxDQUFDLElBQUksQ0FBQyxDQUFDO3dCQUUxQyxLQUFLLElBQUksUUFBUSxJQUFJLFdBQVcsRUFBRTs0QkFDOUIsSUFBSSxXQUFXLENBQUMsY0FBYyxDQUFDLFFBQVEsQ0FBQyxFQUFFO2dDQUN0QyxJQUFJLE9BQU8sV0FBVyxDQUFDLFFBQVEsQ0FBQyxDQUFDLE1BQU0sS0FBSyxXQUFXLEVBQUU7b0NBQ3JELFdBQVcsQ0FBQyxRQUFRLENBQUMsQ0FBQyxNQUFNLEdBQUcsRUFBRSxDQUFDO2lDQUNyQztnQ0FFRCxXQUFXLENBQUMsUUFBUSxDQUFDLENBQUMsTUFBTSxDQUFDLE1BQU0sR0FBRyxDQUFDLENBQUM7NkJBQzNDO3lCQUNKO3FCQUNKO2lCQUNKO1lBQ0wsQ0FBQyxDQUFDO1NBQ0w7YUFDSTtZQUNELE9BQU8sQ0FBQyxJQUFJLENBQUMseUVBQXlFLENBQUMsQ0FBQztTQUMzRjtJQUNMLENBQUM7SUFFRCx3R0FBd0c7SUFDeEcsa0JBQWtCO0lBQ2xCLHdHQUF3RztJQUNoRyxnQkFBZ0IsQ0FBQyxTQUFpQjtRQUN0QyxJQUFJLE9BQU8sU0FBUyxLQUFLLFdBQVcsSUFBSSxTQUFTLEtBQUssUUFBUSxFQUFFO1lBQzVELElBQUksQ0FBQyxhQUFhLEdBQUcsSUFBSSxnQkFBZ0IsRUFBRSxDQUFDO1NBQy9DO2FBQ0k7WUFDRCxJQUFJLENBQUMsYUFBYSxHQUFHLElBQUksb0JBQW9CLEVBQUUsQ0FBQztTQUNuRDtJQUNMLENBQUM7SUFFTyxpQkFBaUIsQ0FBQyxXQUF5QjtRQUMvQyxJQUFJLENBQUMsTUFBTSxHQUFHLElBQUksQ0FBQyxhQUFhLENBQUMsU0FBUyxDQUFDLFdBQVcsQ0FBQyxDQUFDO1FBRXhELElBQUksQ0FBQyxhQUFhLENBQUMsaUJBQWlCLENBQUMsV0FBVyxDQUFDLENBQUM7UUFDbEQsSUFBSSxDQUFDLGFBQWEsQ0FBQyx3QkFBd0IsQ0FBQyxXQUFXLENBQUMsQ0FBQztJQUM3RCxDQUFDOzs7WUE1M0NKLFNBQVMsU0FBQztnQkFDUCxRQUFRLEVBQUUsVUFBVTtnQkFDcEIsby9CQUFzQztnQkFDdEMsYUFBYSxFQUFFLGlCQUFpQixDQUFDLElBQUk7Z0JBQ3JDLFNBQVMsRUFBRSxDQUFDLFlBQVksRUFBRSxlQUFlLEVBQUUsZ0JBQWdCLEVBQUUsb0JBQW9CLENBQUM7Z0JBQ2xGLElBQUksRUFBRSxFQUFFLE9BQU8sRUFBRSxXQUFXLEVBQUU7YUFDakM7OztZQXRJRyxnQkFBZ0I7WUFJWCxNQUFNO1lBOENOLFlBQVk7WUFKWixlQUFlOzs7a0JBb0huQixLQUFLO3FCQUNMLEtBQUs7cUJBQ0wsS0FBSztrQkFDTCxLQUFLO3dCQUdMLEtBQUs7OEJBQ0wsS0FBSzsrQkFDTCxNQUFNOzBCQUNOLFdBQVcsU0FBQyxpQkFBaUI7NkJBQzdCLFdBQVcsU0FBQyxpQkFBaUI7dUJBYzdCLFlBQVksU0FBQyxlQUFlLEVBQUUsQ0FBQyxRQUFRLENBQUMiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQge1xyXG4gICAgQ29tcG9uZW50LFxyXG4gICAgT25Jbml0LFxyXG4gICAgT25DaGFuZ2VzLFxyXG4gICAgT25EZXN0cm95LFxyXG4gICAgU2ltcGxlQ2hhbmdlcyxcclxuICAgIFZpZXdFbmNhcHN1bGF0aW9uLFxyXG4gICAgSW5wdXQsXHJcbiAgICBIb3N0QmluZGluZyxcclxuICAgIEhvc3RMaXN0ZW5lcixcclxuICAgIFZpZXdDb250YWluZXJSZWYsXHJcbiAgICBFdmVudEVtaXR0ZXIsXHJcbiAgICBPdXRwdXRcclxufSBmcm9tICdAYW5ndWxhci9jb3JlJztcclxuaW1wb3J0IHsgUm91dGVyIH0gZnJvbSAnQGFuZ3VsYXIvcm91dGVyJztcclxuaW1wb3J0IHsgT2JzZXJ2YWJsZSwgdGltZXIsIFN1YnNjcmlwdGlvbiwgU3Vic2NyaWJlciB9IGZyb20gJ3J4anMnO1xyXG5pbXBvcnQge1xyXG4gICAgR3JpZE9wdGlvbnMsXHJcbiAgICBSb3dOb2RlLFxyXG4gICAgUm93RXZlbnQsXHJcbiAgICBNb2RlbFVwZGF0ZWRFdmVudCxcclxuICAgIEV4Y2VsRXhwb3J0UGFyYW1zLFxyXG4gICAgQ29sdW1uLFxyXG4gICAgR3JpZEFwaSxcclxuICAgIENvbnRleHQsXHJcbiAgICBDb2xEZWYsXHJcbiAgICBWYWx1ZVNldHRlclBhcmFtcyxcclxuICAgIC8vIENvbERlZixcclxuICAgIC8vIElFbnRlcnByaXNlRGF0YXNvdXJjZSxcclxuICAgIC8vIElFbnRlcnByaXNlR2V0Um93c1BhcmFtcyxcclxufSBmcm9tICdhZy1ncmlkLWNvbW11bml0eSc7XHJcbmltcG9ydCB7XHJcbiAgICBJRW50ZXJwcmlzZURhdGFzb3VyY2UsXHJcbiAgICBJRW50ZXJwcmlzZUdldFJvd3NQYXJhbXMsXHJcbn0gZnJvbSAnLi9lbnRlcnByaXNlLWRhdGFzb3VyY2UnO1xyXG5pbXBvcnQgJ2FnLWdyaWQtZW50ZXJwcmlzZSc7XHJcbmltcG9ydCAqIGFzIFhMU1ggZnJvbSAneGxzeCc7XHJcbmltcG9ydCB7IHNhdmVBcyB9IGZyb20gJ2ZpbGUtc2F2ZXInO1xyXG5cclxuaW1wb3J0IHtcclxuICAgIElUYWJsZUNvbHVtbixcclxuICAgIElUYWJsZUNvbmZpZyxcclxuICAgIElTdHlsaW5nQ29uZmlnLFxyXG4gICAgSVRhYmxlUGl2b3RTdGF0ZSxcclxuICAgIElUYWJsZUJ1dHRvbixcclxuICAgIElUYWJsZUNlbGxQYXJhbXMsXHJcbiAgICBJVGFibGVGb3JtRW1pdFBhcmFtcyxcclxuICAgIElUYWJsZURhdGFzb3VyY2VQYXJhbXMsXHJcbiAgICBJVGFibGVBcGksXHJcbiAgICBJVGFibGVEcm9wZG93bkFjdGlvbixcclxuICAgIEtkVGFibGVEYXRhc291cmNlRXZlbnQsXHJcbiAgICBLZFRhYmxlU2VsZWN0aW9uVXBkYXRlRXZlbnQsXHJcbiAgICBLZFRhYmxlSW5wdXRVcGRhdGVFdmVudCxcclxuICAgIEtkVGFibGVCdXR0b25FdmVudFxyXG59IGZyb20gJy4va2QtYW5ndWxhci10YWJsZS1pbnRlcmZhY2UnO1xyXG5cclxuaW1wb3J0IHsgS2RJbnRUYWJsZUV2ZW50IH0gZnJvbSAnLi9rZC1hbmd1bGFyLXRhYmxlLWV2ZW50JztcclxuaW1wb3J0IHsgS2RUYWJsZU5vcm1hbFN2YyB9IGZyb20gJy4vdGFibGUtc2VydmljZXMva2QtdGFibGUtbm9ybWFsLXN2Yyc7XHJcbmltcG9ydCB7IEtkVGFibGVFbnRlcnByaXNlU3ZjIH0gZnJvbSAnLi90YWJsZS1zZXJ2aWNlcy9rZC10YWJsZS1lbnRlcnByaXNlLXN2Yyc7XHJcbi8vIGltcG9ydCB7IEtkU3BsaXR0ZXJFdmVudCB9IGZyb20gJy4uLyc7XHJcbmltcG9ydCB7IEtkRG9tRWxlbVN2YywgQUdfR1JJRF9LRVkgfSBmcm9tICcuLi9rZC1jb21tb24vaW5kZXgnO1xyXG5pbXBvcnQgeyBMaWNlbnNlTWFuYWdlciB9IGZyb20gXCJhZy1ncmlkLWVudGVycHJpc2VcIjtcclxuXHJcbmRlY2xhcmUgdmFyIHJlcXVpcmU6IGFueTtcclxuXHJcbi8qKlxyXG4gKiAtLSBEb2N1bWVudGF0aW9uIGZvciBrZC1hbmd1bGFyLXRhYmxlLnRzIChrZC10YWJsZSlcclxuICpcclxuICogLSBIb3N0TGlzdGVuZXJcclxuICogICAgIC0gb25SZXNpemVcclxuICpcclxuICogLSBMaWZlIGN5Y2xlczpcclxuICogICAgIC0gbmdPbkluaXRcclxuICogICAgIC0gbmdPbkNoYW5nZXNcclxuICogICAgIC0gbmdPbkRlc3Ryb3lcclxuXHJcbiAqIC0gYWctR3JpZCBldmVudHMgZnVuY3Rpb246XHJcbiAqICAgICAtIG9uR3JpZFJlYWR5XHJcbiAqICAgICAtIG9uTW9kZWxVcGRhdGVkXHJcbiAqICAgICAtIG9uUm93Q2xpY2tlZFxyXG4gKlxyXG4gKiAtIGtkLXRhYmxlIGJ1dHRvbiBmdW5jdGlvbjpcclxuICogICAgIC0gb25CdXR0b25DbGljZWtkXHJcbiAqXHJcbiAqIC0gUHJpdmF0ZSBmdW5jdGlvbnM6XHJcbiAqICAgICAtIERpc3BsYXkgLyBET00gZnVuY3Rpb25zOlxyXG4gKiAgICAgICAgIC0gX3Jlc2l6ZUNvbHVtblxyXG4gKiAgICAgICAgIC0gX3Nob3dMb2FkaW5nT3ZlcmxheVxyXG4gKiAgICAgICAgIC0gX3VwZGF0ZVBhcmVudE5vZGVDU1NcclxuICogICAgICAgICAtIF9zZXRIZWlnaHRcclxuICogICAgICAgICAtIF9zZXRNb2JpbGVIZWlnaHQgKGZsYXR0ZW4gdGFibGUpXHJcbiAqICAgICAgICAgLSBfc2V0V2ViSGVpZ2hyICh1c2VyIGNvbmZpZ3VyYXRpb24pXHJcbiAqICAgICAgICAgLSBfaXNDbGlja1ZhbGlkIChjbGljayBjb25maWd1cmF0aW9uKVxyXG4gKlxyXG4gKiAgICAgLSBHcmlkIEN5Y2xlczpcclxuICogICAgICAgICAtIF9ncmlkSW5pdEN5Y2xlXHJcbiAqICAgICAgICAgLSBfZ3JpZFJlYWR5Q3ljbGVcclxuICogICAgICAgICAtIF9ncmlkUmVhZHlFbnRlcnByaXNlQ3ljbGVcclxuICogICAgICAgICAtIF9ncmlkUmVhZHlET01DeWNsZVxyXG4gKiAgICAgICAgIC0gX2dyaWRTZWxlY3Rpb25DeWNsZVxyXG4gKiAgICAgICAgIC0gX2dyaWRTZXRSb3dDeWNsZVxyXG4gKiAgICAgICAgIC0gX2dyaWRDbGlja05hdmlnYXRlQ3ljbGVcclxuICpcclxuICogICAgIC0gQ29sdW1uIC8gUm93IC8gQ29uZmlnIGdlbmVyYXRpb25zL3Byb2Nlc3Npbmc6XHJcbiAqICAgICAgICAgLSBfc2V0R3JpZE9wdGlvbnNcclxuICogICAgICAgICAtIF9zZXRDb2x1bW5EZWZcclxuICogICAgICAgICAtIF9zZXRSb3dEYXRhXHJcbiAqXHJcbiAqICAgICAtIEV2ZW50IGZ1bmN0aW9uczpcclxuICogICAgICAgICAtIF9wcm9jZXNzRXZlbnRQYXJhbXM8VD5cclxuICogICAgICAgICAtIF9icm9hZGNhc3RFdmVudFBhcmFtc1xyXG4gKiAgICAgICAgIC0gX2Jyb2FkY2FzdE1vZGVsQ2hhbmdlZFxyXG4gKiAgICAgICAgIC0gX3NldHVwU3Vic2NyaXB0aW9uRXZlbnRzXHJcbiAqXHJcbiAqICAgICAtIFNlbGVjdGlvbiBmdW5jdGlvbnM6XHJcbiAqICAgICAgICAgLSBfdXBkYXRlU2VsZWN0aW9uTm9kZXNcclxuICogICAgICAgICAtIF9wcm9jZXNzSW5pdGlhbFNlbGVjdGlvblxyXG4gKlxyXG4gKiAgICAgLSBJbnB1dCBmdW5jdGlvbnM6XHJcbiAqICAgICAgICAgLSBfcHJvY2Vzc0lucHV0Q2hhbmdlZFxyXG4gKiAgICAgICAgIC0gX2VtaXRJbnB1dFVwZGF0ZUV2ZW50XHJcbiAqICAgICAgICAgLSBfZGVsZXRlTm9kZUZyb21Sb3dEYXRhXHJcbiAqXHJcbiAqICAgICAtIERhdGFzb3VyY2UgZnVuY3Rpb25zOlxyXG4gKiAgICAgICAgIC0gX2NsZWFyRGF0YXNvdXJjZVxyXG4gKiAgICAgICAgIC0gX2dlbmVyYXRlRW50ZXJwcmlzZURhdGFzb3VyY2VcclxuICogICAgICAgICAtIF9nZW5lcmF0ZURhdGFzb3VyY2VSb3dzXHJcbiAqXHJcbiAqICAgICAtIEFQSSBnZW5lcmF0aW9uczpcclxuICogICAgICAgICAtIF9pbml0SVRhYmxlQXBpIChUT0RPOiB1cGRhdGUgYXBpIHNldHRpbmcgYWxsIHRvIHRhYmxlIHNlcnZpY2UpXHJcbiAqXHJcbiAqICAgICAtIE1pc2MgZnVuY3Rpb25zOlxyXG4gKiAgICAgICAgIC0gX2luaXRHcmlkU2VydmljZVxyXG4gKiAgICAgICAgIC0gX3VwZGF0ZUdyaWRDb25maWdcclxuICovXHJcblxyXG5cclxuXHJcbkBDb21wb25lbnQoe1xyXG4gICAgc2VsZWN0b3I6ICdrZC10YWJsZScsXHJcbiAgICB0ZW1wbGF0ZVVybDogJy4va2QtYW5ndWxhci10YWJsZS5odG1sJyxcclxuICAgIGVuY2Fwc3VsYXRpb246IFZpZXdFbmNhcHN1bGF0aW9uLk5vbmUsXHJcbiAgICBwcm92aWRlcnM6IFtLZERvbUVsZW1TdmMsIEtkSW50VGFibGVFdmVudCwgS2RUYWJsZU5vcm1hbFN2YywgS2RUYWJsZUVudGVycHJpc2VTdmNdLFxyXG4gICAgaG9zdDogeyAnY2xhc3MnOiAna2R4LXRhYmxlJyB9XHJcbn0pXHJcblxyXG5leHBvcnQgY2xhc3MgS2RUYWJsZSBpbXBsZW1lbnRzIE9uSW5pdCwgT25DaGFuZ2VzLCBPbkRlc3Ryb3kge1xyXG4gICAgcHVibGljIGdyaWRJZDogc3RyaW5nID0gJyc7XHJcbiAgICBwdWJsaWMgZ3JpZE9wdGlvbnM6IEdyaWRPcHRpb25zO1xyXG4gICAgcHVibGljIGdyaWRBcGk6IEdyaWRBcGk7XHJcbiAgICBwdWJsaWMgZGlzcGxheUxvYWRpbmc6IGJvb2xlYW4gPSB0cnVlO1xyXG4gICAgcHVibGljIF9zaW5nbGVDbGlja0VkaXQ6IGJvb2xlYW4gPSBmYWxzZTtcclxuICAgIHByaXZhdGUgX2VudGVycHJpc2UgPSByZXF1aXJlKCdhZy1ncmlkLWVudGVycHJpc2UnKTtcclxuICAgIHByaXZhdGUgX2lzTW9iaWxlVmlldzogYm9vbGVhbjtcclxuICAgIHByaXZhdGUgX3RhYmxlU2VydmljZTogS2RUYWJsZU5vcm1hbFN2YyB8IEtkVGFibGVFbnRlcnByaXNlU3ZjO1xyXG4gICAgcHJpdmF0ZSBfc3Vic2NyaXB0aW9uT2JqOiB7IFtrZXk6IHN0cmluZ106IFN1YnNjcmlwdGlvbiB9ID0ge307XHJcblxyXG4gICAgcHJpdmF0ZSBfY3VycmVudFN0YXRlOiBJVGFibGVQaXZvdFN0YXRlID0ge1xyXG4gICAgICAgIGNvbHVtblN0YXRlOiBbXSxcclxuICAgICAgICBwaXZvdE1vZGU6IGZhbHNlLFxyXG4gICAgICAgIGdyb3VwU3RhdGU6IFtdXHJcbiAgICB9O1xyXG4gICAgcHJpdmF0ZSBfaXNDaGFuZ2luZ1N0YXRlOiBib29sZWFuID0gZmFsc2U7XHJcbiAgICBwcml2YXRlIF9waXZvdEVsZW1lbnQ6IHsgW2tleTogc3RyaW5nXTogYW55IH0gPSB7XHJcbiAgICAgICAgJ3Bpdm90JzogbnVsbCxcclxuICAgICAgICAnY29sdW1uLWRyb3AnOiBudWxsXHJcbiAgICB9O1xyXG4gICAgcHJpdmF0ZSBfcHJldmlvdXNUb29scGFuZWxUeXBlOiAnbm9uZScgfCAnY29sdW1ucycgfCAncGl2b3QnO1xyXG4gICAgcHJpdmF0ZSBfc3VwcHJlc3NNb3ZhYmxlQ29sdW1uczogYm9vbGVhbiA9IHRydWU7XHJcblxyXG4gICAgcHJpdmF0ZSBfZGlyZWN0aW9uOiAnbHRyJyB8ICdydGwnID0gJ2x0cic7XHJcblxyXG4gICAgQElucHV0KCkgcm93OiBBcnJheTxhbnk+O1xyXG4gICAgQElucHV0KCkgY29sdW1uOiBBcnJheTxJVGFibGVDb2x1bW4+O1xyXG4gICAgQElucHV0KCkgY29uZmlnOiBJVGFibGVDb25maWc7XHJcbiAgICBASW5wdXQoKSBhcGk6IElUYWJsZUFwaTtcclxuICAgIC8vIEBJbnB1dCgpIGNvbnRleHQ6IENvbnRleHQ7XHJcbiAgICAvLyBASW5wdXQoKSBncmlkT3B0aW9uOiBHcmlkT3B0aW9ucztcclxuICAgIEBJbnB1dCgpIGVkaXRUYWJsZTogYm9vbGVhbjtcclxuICAgIEBJbnB1dCgpIGRpc3BsYXlFZGl0YWJsZTogYm9vbGVhbjtcclxuICAgIEBPdXRwdXQoKSBvbkV4cG9ydFBvc3NpYmxlOiBFdmVudEVtaXR0ZXI8Ym9vbGVhbj4gPSBuZXcgRXZlbnRFbWl0dGVyKCk7XHJcbiAgICBASG9zdEJpbmRpbmcoJ2NsYXNzLmZ1bGwtZ3JpZCcpIGRpc3BsYXlGdWxsOiBib29sZWFuO1xyXG4gICAgQEhvc3RCaW5kaW5nKCdjbGFzcy5rZHgtdGFibGUnKSBfY2xhc3NLZHhUYWJsZTogYm9vbGVhbiA9IHRydWU7XHJcblxyXG4gICAgcHVibGljIGRlZmF1bHRDb2xEZWY6IENvbERlZjtcclxuICAgIHB1YmxpYyBlZGl0aW5nTW9kZUVuYWJsZWQ6IGJvb2xlYW4gPSBmYWxzZTtcclxuICAgIGNvbnN0cnVjdG9yKFxyXG4gICAgICAgIHByaXZhdGUgX3ZjcjogVmlld0NvbnRhaW5lclJlZixcclxuICAgICAgICBwcml2YXRlIF9yb3V0ZXI6IFJvdXRlcixcclxuICAgICAgICBwcml2YXRlIF9kb21TdmM6IEtkRG9tRWxlbVN2YyxcclxuICAgICAgICAvLyBwcml2YXRlIF9zcGxpdHRlckV2ZW50OiBLZFNwbGl0dGVyRXZlbnQsXHJcbiAgICAgICAgcHJpdmF0ZSBfdGFibGVJbnRFdmVudDogS2RJbnRUYWJsZUV2ZW50LFxyXG4gICAgKSB7XHJcbiAgICAgICAgTGljZW5zZU1hbmFnZXIuc2V0TGljZW5zZUtleShBR19HUklEX0tFWS52YWx1ZSk7XHJcbiAgICB9XHJcblxyXG4gICAgQEhvc3RMaXN0ZW5lcignd2luZG93OnJlc2l6ZScsIFsnJGV2ZW50J10pXHJcbiAgICBvblJlc2l6ZShfZXZlbnQ6IEV2ZW50KTogdm9pZCB7XHJcbiAgICAgICAgdGhpcy5fc2V0SGVpZ2h0KCk7XHJcbiAgICB9XHJcblxyXG4gICAgLyoqKioqKioqKioqKioqKioqKioqKioqKiogTGlmZSBjeWNsZXMgZnVuY3Rpb25zICoqKioqKioqKioqKioqKioqKioqKioqKioqKioqL1xyXG4gICAgbmdPbkluaXQoKTogdm9pZCB7XHJcbiAgICAgICAgLy8gY29uc29sZS5sb2coXCItLSBHcmlkIHN0YXRlOiBJbml0IC0tXCIsIHRoaXMucm93LCB0aGlzLmNvbHVtbiwgdGhpcy5jb25maWcsIHRoaXMuYXBpKTtcclxuICAgICAgICB0aGlzLl9zaG93TG9hZGluZ092ZXJsYXkodHJ1ZSk7XHJcbiAgICAgICAgdGhpcy5fZ3JpZEluaXRDeWNsZSgpO1xyXG4gICAgfVxyXG5cclxuICAgIG5nT25DaGFuZ2VzKF9zaW1wbGVDaGFuZ2VzOiBTaW1wbGVDaGFuZ2VzKTogdm9pZCB7XHJcbiAgICAgICAgdGhpcy5fc2hvd0xvYWRpbmdPdmVybGF5KHRydWUpO1xyXG4gICAgICAgIGNvbnNvbGUubG9nKFwiLS0gR3JpZCBzdGF0ZTogQ2hhbmdlIC0tIFwiLCBfc2ltcGxlQ2hhbmdlcyk7XHJcblxyXG4gICAgICAgIGlmICh0eXBlb2YgX3NpbXBsZUNoYW5nZXMuY29sdW1uICE9PSAndW5kZWZpbmVkJyAmJlxyXG4gICAgICAgICAgICAhX3NpbXBsZUNoYW5nZXMuY29sdW1uLmZpcnN0Q2hhbmdlXHJcbiAgICAgICAgKSB7XHJcbiAgICAgICAgICAgIHRoaXMuX3NldENvbHVtbkRlZihfc2ltcGxlQ2hhbmdlcy5jb2x1bW4uY3VycmVudFZhbHVlKTtcclxuICAgICAgICAgICAgdGhpcy5fc2hvd0xvYWRpbmdPdmVybGF5KGZhbHNlKTtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIGlmICh0eXBlb2YgX3NpbXBsZUNoYW5nZXMucm93ICE9PSAndW5kZWZpbmVkJyAmJlxyXG4gICAgICAgICAgICAhX3NpbXBsZUNoYW5nZXMucm93LmZpcnN0Q2hhbmdlXHJcbiAgICAgICAgKSB7XHJcbiAgICAgICAgICAgIHRoaXMuX3NldFJvd0RhdGEoX3NpbXBsZUNoYW5nZXMucm93LmN1cnJlbnRWYWx1ZSk7XHJcbiAgICAgICAgICAgIHRoaXMuX3Nob3dMb2FkaW5nT3ZlcmxheShmYWxzZSk7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICBpZiAodHlwZW9mIF9zaW1wbGVDaGFuZ2VzLmNvbmZpZyAhPT0gJ3VuZGVmaW5lZCcpIHtcclxuICAgICAgICAgICAgdGhpcy5fc2hvd0xvYWRpbmdPdmVybGF5KGZhbHNlKTtcclxuICAgICAgICAgICAgdGhpcy51cGRhdGVTdHlsZShfc2ltcGxlQ2hhbmdlcy5jb25maWcuY3VycmVudFZhbHVlKTtcclxuXHJcbiAgICAgICAgICAgIHRpbWVyKDEwMCkuc3Vic2NyaWJlKCgpOiB2b2lkID0+IHtcclxuICAgICAgICAgICAgICAgIHRoaXMuX2NvbmZpZ3VyZVBpdm90RGlzcGxheSgpO1xyXG5cclxuICAgICAgICAgICAgICAgIGlmICh0eXBlb2YgdGhpcy5jb25maWcuc3VwcHJlc3NNb3ZhYmxlQ29sdW1ucyAhPT0gJ3VuZGVmaW5lZCdcclxuICAgICAgICAgICAgICAgICkge1xyXG4gICAgICAgICAgICAgICAgICAgIGlmICh0aGlzLmNvbmZpZy5zdXBwcmVzc01vdmFibGVDb2x1bW5zICE9PSB0aGlzLl9zdXBwcmVzc01vdmFibGVDb2x1bW5zKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLl9lbmFibGVDb2x1bW5Nb3ZhYmxlKHRoaXMuY29uZmlnLnN1cHByZXNzTW92YWJsZUNvbHVtbnMpO1xyXG4gICAgICAgICAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLmNvbmZpZy5zdXBwcmVzc01vdmFibGVDb2x1bW5zID0gdGhpcy5fc3VwcHJlc3NNb3ZhYmxlQ29sdW1ucztcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIG5nT25EZXN0cm95KCk6IHZvaWQge1xyXG4gICAgICAgIC8vIGNvbnNvbGUubG9nKFwiLS0gR3JpZCBzdGF0ZTogRGVzdHJveWluZyAtLVwiKTtcclxuICAgICAgICBmb3IgKGxldCBpdGVtIGluIHRoaXMuX3N1YnNjcmlwdGlvbk9iaikge1xyXG4gICAgICAgICAgICBpZiAodHlwZW9mIHRoaXMuX3N1YnNjcmlwdGlvbk9ialtpdGVtXSAhPT0gJ3VuZGVmaW5lZCcpIHtcclxuICAgICAgICAgICAgICAgIHRoaXMuX3N1YnNjcmlwdGlvbk9ialtpdGVtXS51bnN1YnNjcmliZSgpO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIHNldEF0dGVuZGFuY2UoZGlzcGxheUVkaXRUYWJsZSwgX2NvbmZpZzogSVRhYmxlQ29uZmlnKSB7XHJcbiAgICAgICAgLy8gbGV0IGFsbENvbHVtbnMgPSB0aGlzLmdyaWRPcHRpb25zLmNvbHVtbkFwaS5nZXRBbGxDb2x1bW5zKClcclxuXHJcbiAgICAgICAgLy8gYWxsQ29sdW1ucy5mb3JFYWNoKChjb2x1bW4sIGluZGV4KSA9PiB7XHJcbiAgICAgICAgLy8gICAgIGxldCBjdXJyZW50Q29sdW1uRGVmID0gY29sdW1uLmdldENvbERlZigpXHJcbiAgICAgICAgLy8gICAgIGNvbnNvbGUubG9nKGBjb2x1bW4gJHtpbmRleCsxfWAsIGN1cnJlbnRDb2x1bW5EZWYpXHJcbiAgICAgICAgLy8gfSlcclxuICAgICAgICBpZiAoZGlzcGxheUVkaXRUYWJsZSkge1xyXG4gICAgICAgICAgICB0aGlzLmdyaWRPcHRpb25zLmNvbnRleHQubW9kZSA9ICdlZGl0J1xyXG4gICAgICAgICAgICBfY29uZmlnLmNvbnRleHQubW9kZSA9ICdlZGl0JztcclxuICAgICAgICAgICAgX2NvbmZpZy5yb3dDb250ZW50SGVpZ2h0ID0gMTIwXHJcbiAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgdGhpcy5ncmlkT3B0aW9ucy5jb250ZXh0Lm1vZGUgPSAndmlldydcclxuICAgICAgICAgICAgX2NvbmZpZy5jb250ZXh0Lm1vZGUgPSAndmlldyc7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICBsZXQgX2NvbHVtbnMgPSB0aGlzLmdyaWRPcHRpb25zLmNvbHVtbkFwaS5nZXRBbGxEaXNwbGF5ZWRDb2x1bW5zKCk7XHJcbiAgICAgICAgLy8gbGV0IGNvbERlZiA9IF9jb2x1bW5zWzJdLmdldENvbERlZigpXHJcbiAgICAgICAgLy8gY29uc29sZS5sb2coY29sRGVmKTtcclxuICAgICAgICAvLyBjb2xEZWYuY2VsbFJlbmRlcmVyUGFyYW1zID0gJzxwPkhlbGxvPC9wPidcclxuICAgICAgICAvLyBsZXQgbmV3RGF0YSA9IFtdXHJcbiAgICAgICAgLy8gbmV3RGF0YS5wdXNoKGNvbERlZilcclxuICAgICAgICB0aGlzLmdyaWRPcHRpb25zLmNvbHVtbkFwaS5zZXRWYWx1ZUNvbHVtbnMoX2NvbHVtbnMpXHJcbiAgICB9XHJcblxyXG4gICAgdG9nZ2xlRWRpdHMoZGF0YSkge1xyXG4gICAgICAgIGlmICh0aGlzLmVkaXRUYWJsZSAmJiAhdGhpcy5kaXNwbGF5RWRpdGFibGUpIHtcclxuICAgICAgICAgICAgdGhpcy5lZGl0aW5nTW9kZUVuYWJsZWQgPSAhdGhpcy5lZGl0aW5nTW9kZUVuYWJsZWQ7XHJcbiAgICAgICAgICAgIHRoaXMuX3NpbmdsZUNsaWNrRWRpdCA9ICF0aGlzLl9zaW5nbGVDbGlja0VkaXQ7XHJcbiAgICAgICAgICAgIGxldCBfY29sdW1ucyA9IHRoaXMuZ3JpZE9wdGlvbnMuY29sdW1uQXBpLmdldEFsbERpc3BsYXllZENvbHVtbnMoKTtcclxuICAgICAgICAgICAgbGV0IG5ld0NvbHVtbkRhdGEgPSBbXTtcclxuICAgICAgICAgICAgX2NvbHVtbnMuZm9yRWFjaCgoY29sdW1uOiBhbnkpID0+IHtcclxuICAgICAgICAgICAgICAgIGxldCBjb2x1bW5EZWYgPSBjb2x1bW4/LmdldENvbERlZigpO1xyXG4gICAgICAgICAgICAgICAgaWYgKGNvbHVtbkRlZi5jYW5FZGl0ID09IHRydWUpIHtcclxuICAgICAgICAgICAgICAgICAgICBjb2x1bW5EZWYuY2VsbFN0eWxlID0gZnVuY3Rpb24gKHBhcmFtczogYW55KSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGlmICghaXNOYU4ocGFyc2VGbG9hdChwYXJhbXMudmFsdWUpKSAmJiBwYXJzZUZsb2F0KHBhcmFtcy52YWx1ZSkgPCA1MCkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIHsgY29sb3I6ICcjQ0M1QzVDJyB9O1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIHsgY29sb3I6ICcjMzMzJyB9O1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgY29sdW1uRGVmLmNlbGxDbGFzc1J1bGVzID0ge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgJ29lLWNlbGwtaGlnaGxpZ2h0JzogZnVuY3Rpb24gKHBhcmFtcykge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiAxO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICdvZS1jZWxsLWVycm9yJzogZnVuY3Rpb24gKHBhcmFtcykge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIHJldHVybiBwYXJhbXMuZGF0YS5zYXZlX2Vycm9yW3BhcmFtcy5jb2xEZWYuZmllbGRdO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBjb2x1bW5EZWYuY2VsbFJlbmRlcmVyUGFyYW1zID0ge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgc2hvdWxkQmVFZGl0aW5nOiAoKSA9PiB0aGlzLmVkaXRpbmdNb2RlRW5hYmxlZCxcclxuICAgICAgICAgICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgY29sdW1uRGVmLmVkaXRhYmxlID0gKHBhcmFtczogYW55KSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YXIgbmFtZSA9IHBhcmFtcy5ub2RlLmRhdGEubmFtZTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHBhcmFtcy5kYXRhLm5hbWUgPSBwYXJhbXMubm9kZS5kYXRhLm5hbWU7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gbmFtZTtcclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbHVtbkRlZi5uZXdWYWx1ZUhhbmRsZXIgPSAocGFyYW1zOiBhbnkpID0+IHtcclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAoZGF0YSA9PSAndGV4dCcpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBsZXQgdmFsdWVBc0Zsb2F0ID0gcGFyYW1zLm5ld1ZhbHVlO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHBhcmFtcy5kYXRhW3BhcmFtcy5jb2xEZWYuZmllbGRdID0gdmFsdWVBc0Zsb2F0O1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBsZXQgdmFsdWVBc0Zsb2F0ID0gcGFyc2VGbG9hdChwYXJhbXMubmV3VmFsdWUpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKHZhbHVlQXNGbG9hdCwgXCJ2YWx1ZUFzRmxvYXRcIik7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKHZhbHVlQXNGbG9hdCA8PSAxMDApIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcGFyYW1zLmRhdGFbcGFyYW1zLmNvbERlZi5maWVsZF0gPSB2YWx1ZUFzRmxvYXQ7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc29sZS5sb2cocGFyYW1zLmRhdGFbcGFyYW1zLmNvbERlZi5maWVsZF0sIFwicGFyYW1zLmRhdGFbcGFyYW1zLmNvbERlZi5maWVsZF1cIik7XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gcmV0dXJuIHRydWU7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIG5ld0NvbHVtbkRhdGEucHVzaChjb2x1bW5EZWYpO1xyXG4gICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgdGhpcy5ncmlkT3B0aW9ucy5jb2x1bW5BcGkuc2V0VmFsdWVDb2x1bW5zKG5ld0NvbHVtbkRhdGEpO1xyXG4gICAgICAgIH0gZWxzZSBpZiAodGhpcy5kaXNwbGF5RWRpdGFibGUpIHtcclxuICAgICAgICAgICAgdGhpcy5lZGl0aW5nTW9kZUVuYWJsZWQgPSAhdGhpcy5lZGl0aW5nTW9kZUVuYWJsZWQ7XHJcbiAgICAgICAgICAgIHRoaXMuX3NpbmdsZUNsaWNrRWRpdCA9ICF0aGlzLl9zaW5nbGVDbGlja0VkaXQ7XHJcbiAgICAgICAgICAgIGxldCBfY29sdW1ucyA9IHRoaXMuZ3JpZE9wdGlvbnMuY29sdW1uQXBpLmdldEFsbERpc3BsYXllZENvbHVtbnMoKTtcclxuICAgICAgICAgICAgbGV0IG5ld0NvbHVtbkRhdGEgPSBbXTtcclxuICAgICAgICAgICAgX2NvbHVtbnMuZm9yRWFjaCgoY29sdW1uOiBhbnkpID0+IHtcclxuICAgICAgICAgICAgICAgIGxldCBjb2x1bW5EZWYgPSBjb2x1bW4/LmdldENvbERlZigpO1xyXG4gICAgICAgICAgICAgICAgaWYgKGNvbHVtbkRlZi5jYW5FZGl0ID09IHRydWUpIHtcclxuICAgICAgICAgICAgICAgICAgICBjb2x1bW5EZWYudmFsdWVHZXR0ZXIgPSBmdW5jdGlvbiAocGFyYW1zKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHZhciB2YWx1ZSA9IHBhcmFtcy5kYXRhW3BhcmFtcy5jb2xEZWYuZmllbGRdO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAoZGF0YSA9PSAndGV4dCcpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiB2YWx1ZTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmICghaXNOYU4ocGFyc2VGbG9hdCh2YWx1ZSkpKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIHZhbHVlO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gJyc7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBjb2x1bW5EZWYuY2VsbENsYXNzUnVsZXMgPSB7fSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgY29sdW1uRGVmLmNlbGxSZW5kZXJlclBhcmFtcyA9IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNob3VsZEJlRWRpdGluZzogKCkgPT4gdGhpcy5lZGl0aW5nTW9kZUVuYWJsZWQsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbHVtbkRlZi5lZGl0YWJsZSA9IChwYXJhbXM6IGFueSkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIGZhbHNlO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICBuZXdDb2x1bW5EYXRhLnB1c2goY29sdW1uRGVmKTtcclxuICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgIHRoaXMuZ3JpZE9wdGlvbnMuY29sdW1uQXBpLnNldFZhbHVlQ29sdW1ucyhuZXdDb2x1bW5EYXRhKTtcclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgc2V0QXR0ZW5kYW5jZVN0YWZmKGRpc3BsYXlFZGl0VGFibGUpIHtcclxuICAgICAgICBpZiAoZGlzcGxheUVkaXRUYWJsZSkge1xyXG4gICAgICAgICAgICB0aGlzLmdyaWRPcHRpb25zLmNvbnRleHQuYWN0aW9uID0gJ2VkaXQnO1xyXG4gICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgIHRoaXMuZ3JpZE9wdGlvbnMuY29udGV4dC5hY3Rpb24gPSAndmlldyc7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGxldCBfY29sdW1ucyA9IHRoaXMuZ3JpZE9wdGlvbnMuY29sdW1uQXBpLmdldEFsbERpc3BsYXllZENvbHVtbnMoKTtcclxuICAgICAgICB0aGlzLmdyaWRPcHRpb25zLmNvbHVtbkFwaS5zZXRWYWx1ZUNvbHVtbnMoX2NvbHVtbnMpO1xyXG4gICAgICAgIHRoaXMuX3Nob3dMb2FkaW5nT3ZlcmxheShmYWxzZSk7XHJcbiAgICB9XHJcblxyXG4gICAgc2V0U3R1ZGVudE1lYWwoZGlzcGxheUVkaXRUYWJsZSkge1xyXG4gICAgICAgIGlmIChkaXNwbGF5RWRpdFRhYmxlKSB7XHJcbiAgICAgICAgICAgIHRoaXMuZ3JpZE9wdGlvbnMuY29udGV4dC5tb2RlID0gJ2VkaXQnO1xyXG4gICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgIHRoaXMuZ3JpZE9wdGlvbnMuY29udGV4dC5tb2RlID0gJ3ZpZXcnO1xyXG4gICAgICAgIH1cclxuICAgICAgICBsZXQgX2NvbHVtbnMgPSB0aGlzLmdyaWRPcHRpb25zLmNvbHVtbkFwaS5nZXRBbGxEaXNwbGF5ZWRDb2x1bW5zKCk7XHJcbiAgICAgICAgdGhpcy5ncmlkT3B0aW9ucy5jb2x1bW5BcGkuc2V0VmFsdWVDb2x1bW5zKF9jb2x1bW5zKTtcclxuICAgICAgICB0aGlzLl9zaG93TG9hZGluZ092ZXJsYXkoZmFsc2UpO1xyXG4gICAgfVxyXG5cclxuICAgIC8qKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqIEdyaWQgZXZlbnRzICoqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKi9cclxuICAgIHB1YmxpYyBvbkdyaWRSZWFkeShfcGFyYW1zOiBhbnkpOiB2b2lkIHtcclxuICAgICAgICAvLyBjb25zb2xlLmxvZygnLS0gR3JpZCBzdGF0ZTogUmVhZHkgLS0nLCB0aGlzLmdyaWRPcHRpb25zKTtcclxuICAgICAgICB0aGlzLl9ncmlkUmVhZHlDeWNsZSgpO1xyXG4gICAgfVxyXG5cclxuICAgIHB1YmxpYyBvbk1vZGVsVXBkYXRlZChfZXZlbnQ6IE1vZGVsVXBkYXRlZEV2ZW50KTogdm9pZCB7XHJcbiAgICAgICAgLy8vIEZvciBzZWxlY3QgYWxsIGNoZWNrYm94IGNoZWNraW5nIG9uIGNoYW5nZSBwYWdpbmF0aW9uL3VwZGF0ZSByb3cgZGF0YVxyXG4gICAgICAgIGlmICh0aGlzLl90YWJsZVNlcnZpY2UuaGFzU2VsZWN0aW9uQWxsKHRoaXMuY29uZmlnKSkge1xyXG4gICAgICAgICAgICB0aGlzLl9icm9hZGNhc3RNb2RlbENoYW5nZWRFdmVudCgpO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgaWYgKHRoaXMuX2lzTW9iaWxlVmlldykge1xyXG4gICAgICAgICAgICBsZXQgZ3JpZEVsZW1lbnQ6IEVsZW1lbnQgPSBkb2N1bWVudC5xdWVyeVNlbGVjdG9yKCcjJyArIHRoaXMuZ3JpZElkICsgJy5zdGctdGhlbWUnKTtcclxuXHJcbiAgICAgICAgICAgIGlmIChncmlkRWxlbWVudCAhPT0gbnVsbCkge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5fc2V0TW9iaWxlSGVpZ2h0KGdyaWRFbGVtZW50KTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICBwdWJsaWMgb25Sb3dDbGlja2VkKF9wYXJhbXM6IFJvd0V2ZW50KTogdm9pZCB7XHJcbiAgICAgICAgLy8gY29uc29sZS5sb2coXCItLSBHcmlkIHN0YXRlOiBSb3cgY2xpY2tlZCAtLVwiLCBfcGFyYW1zKTtcclxuICAgICAgICBpZiAodGhpcy5faXNDbGlja1ZhbGlkKF9wYXJhbXMuZXZlbnQpICYmIHR5cGVvZiB0aGlzLmNvbmZpZy5jbGljayAhPT0gJ3VuZGVmaW5lZCcgJiYgIXRoaXMuZWRpdFRhYmxlKSB7XHJcbiAgICAgICAgICAgIHN3aXRjaCAodGhpcy5jb25maWcuY2xpY2sudHlwZSkge1xyXG4gICAgICAgICAgICAgICAgY2FzZSAnc2VsZWN0aW9uJzpcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLl9ncmlkU2VsZWN0aW9uQ3ljbGUoX3BhcmFtcy5ub2RlKTtcclxuICAgICAgICAgICAgICAgICAgICBicmVhaztcclxuICAgICAgICAgICAgICAgIGNhc2UgJ3JvdXRlcic6XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5fZ3JpZENsaWNrTmF2aWdhdGVDeWNsZShfcGFyYW1zLm5vZGUpO1xyXG4gICAgICAgICAgICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgICAgICAgICAgZGVmYXVsdDpcclxuICAgICAgICAgICAgICAgICAgICBicmVhaztcclxuICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgaWYgKHR5cGVvZiB0aGlzLmNvbmZpZy5jbGljay5jYWxsYmFjayAhPT0gJ3VuZGVmaW5lZCcpIHtcclxuICAgICAgICAgICAgICAgIHRoaXMuY29uZmlnLmNsaWNrLmNhbGxiYWNrKCk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgLyoqKioqKioqKioqKioqKioqKioqKioqKioqKioqIEJ1dHRvbiBmdW5jdGlvbnMgKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqL1xyXG4gICAgcHVibGljIG9uQnV0dG9uQ2xpY2tlZChfYnV0dG9uOiBJVGFibGVCdXR0b24pOiB2b2lkIHtcclxuICAgICAgICBsZXQgYnV0dG9uRXZlbnQ6IEtkVGFibGVCdXR0b25FdmVudCA9IG5ldyBLZFRhYmxlQnV0dG9uRXZlbnQoX2J1dHRvbik7XHJcbiAgICAgICAgdGhpcy5fcHJvY2Vzc0V2ZW50UGFyYW1zPEtkVGFibGVCdXR0b25FdmVudD4oJ2J1dHRvbicsIGJ1dHRvbkV2ZW50KTtcclxuICAgIH1cclxuXHJcbiAgICAvKioqKioqKioqKioqKioqKioqKioqKioqKioqKiBQcml2YXRlIGZ1bmN0aW9ucyAqKioqKioqKioqKioqKioqKioqKioqKioqKioqKiovXHJcbiAgICAvLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vL1xyXG4gICAgLy8vIEdyaWQgY3ljbGVzXHJcbiAgICAvLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vL1xyXG4gICAgcHJpdmF0ZSBfZ3JpZEluaXRDeWNsZSgpOiB2b2lkIHtcclxuICAgICAgICBpZiAodHlwZW9mIHRoaXMuY29uZmlnICE9PSAndW5kZWZpbmVkJykge1xyXG4gICAgICAgICAgICB0aGlzLl9pbml0R3JpZFNlcnZpY2UodGhpcy5jb25maWcubG9hZFR5cGUpO1xyXG4gICAgICAgICAgICB0aGlzLl91cGRhdGVHcmlkQ29uZmlnKHRoaXMuY29uZmlnKTtcclxuICAgICAgICAgICAgdGhpcy5fc2V0R3JpZE9wdGlvbnModGhpcy5jb25maWcpO1xyXG4gICAgICAgICAgICB0aGlzLl9zZXR1cFN1YnNjcmlwdGlvbkV2ZW50cygpO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgaWYgKHR5cGVvZiB0aGlzLmNvbHVtbiAhPT0gJ3VuZGVmaW5lZCcpIHtcclxuICAgICAgICAgICAgdGhpcy5fc2V0Q29sdW1uRGVmKHRoaXMuY29sdW1uKTtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIGlmICh0eXBlb2YgdGhpcy5yb3cgIT09ICd1bmRlZmluZWQnKSB7XHJcbiAgICAgICAgICAgIHRoaXMuX3NldFJvd0RhdGEodGhpcy5yb3cpO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF9ncmlkUmVhZHlDeWNsZSgpOiB2b2lkIHtcclxuICAgICAgICB0aGlzLl9pbml0SVRhYmxlQXBpKCk7XHJcblxyXG4gICAgICAgIGlmICh0aGlzLl90YWJsZVNlcnZpY2UuaXNFbnRlcnByaXNlTW9kZWwodGhpcy5jb25maWcubG9hZFR5cGUpKSB7XHJcbiAgICAgICAgICAgIHRoaXMuX2dyaWRSZWFkeUVudGVycHJpc2VDeWNsZSgpO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgdGhpcy5fZ3JpZFJlYWR5RE9NQ3ljbGUoKTtcclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF9ncmlkUmVhZHlFbnRlcnByaXNlQ3ljbGUoKTogdm9pZCB7XHJcbiAgICAgICAgdGhpcy5fY2xlYXJEYXRhc291cmNlKCk7XHJcbiAgICAgICAgdGhpcy5fZ2VuZXJhdGVFbnRlcnByaXNlRGF0YXNvdXJjZSgpO1xyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX2dyaWRSZWFkeURPTUN5Y2xlKCk6IHZvaWQge1xyXG4gICAgICAgIHRoaXMuX3VwZGF0ZVBhcmVudE5vZGVDU1MoKTtcclxuICAgICAgICB0aGlzLl9zZXRIZWlnaHQoKTtcclxuICAgICAgICB0aGlzLl9yZXNpemVDb2x1bW4oKTtcclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF9ncmlkU2VsZWN0aW9uQ3ljbGUoX3Jvd05vZGU6IFJvd05vZGUpOiB2b2lkIHtcclxuICAgICAgICBpZiAodHlwZW9mIHRoaXMuY29uZmlnLnNlbGVjdGlvbiA9PT0gJ3VuZGVmaW5lZCcpIHtcclxuICAgICAgICAgICAgY29uc29sZS5lcnJvcignS2RUYWJsZSBlcnJvcjogVXNlciBoYXZlIHNldCBjbGljayB0eXBlIHRvIGJlIHNlbGVjdGlvbiBidXQgbm8gc2VsZWN0aW9uIGlzIGRlZmluZWQuIERvIHlvdSBtZWFuIGNsaWNrIHR5cGUgdG8gcm91dGVyPycpO1xyXG4gICAgICAgIH1cclxuICAgICAgICBlbHNlIGlmICh0aGlzLmNvbmZpZy5zZWxlY3Rpb24udHlwZSA9PT0gJ3NpbmdsZScpIHtcclxuICAgICAgICAgICAgaWYgKHRoaXMuY29uZmlnLnNlbGVjdGlvbi52YWx1ZS5pbmRleE9mKF9yb3dOb2RlLmlkKSA8IDApIHtcclxuICAgICAgICAgICAgICAgIHRoaXMuZ3JpZE9wdGlvbnMuYXBpLmRlc2VsZWN0QWxsKCk7XHJcbiAgICAgICAgICAgICAgICBfcm93Tm9kZS5zZWxlY3RUaGlzTm9kZSh0cnVlKTtcclxuXHJcbiAgICAgICAgICAgICAgICB0aGlzLmNvbmZpZy5zZWxlY3Rpb24udmFsdWUuc3BsaWNlKDAsIHRoaXMuY29uZmlnLnNlbGVjdGlvbi52YWx1ZS5sZW5ndGgpO1xyXG4gICAgICAgICAgICAgICAgdGhpcy5jb25maWcuc2VsZWN0aW9uLnZhbHVlLnB1c2goX3Jvd05vZGUuZGF0YS5pZCk7XHJcblxyXG4gICAgICAgICAgICAgICAgdGhpcy5fYnJvYWRjYXN0TW9kZWxDaGFuZ2VkRXZlbnQoKTtcclxuICAgICAgICAgICAgICAgIHRoaXMuX3VwZGF0ZVNlbGVjdGlvbk5vZGVzKF9yb3dOb2RlKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgbGV0IHNlbGVjdGlvbjogYm9vbGVhbiA9ICFfcm93Tm9kZS5pc1NlbGVjdGVkKCk7XHJcbiAgICAgICAgICAgIF9yb3dOb2RlLnNlbGVjdFRoaXNOb2RlKHNlbGVjdGlvbik7XHJcblxyXG4gICAgICAgICAgICB0aGlzLl9icm9hZGNhc3RNb2RlbENoYW5nZWRFdmVudCgpO1xyXG5cclxuICAgICAgICAgICAgaWYgKHNlbGVjdGlvbikge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5jb25maWcuc2VsZWN0aW9uLnZhbHVlLnB1c2goX3Jvd05vZGUuZGF0YS5pZCk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgZWxzZSB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLmNvbmZpZy5zZWxlY3Rpb24udmFsdWUuc3BsaWNlKHRoaXMuY29uZmlnLnNlbGVjdGlvbi52YWx1ZS5pbmRleE9mKF9yb3dOb2RlLmRhdGEuaWQpLCAxKTtcclxuICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgdGhpcy5fdXBkYXRlU2VsZWN0aW9uTm9kZXMoX3Jvd05vZGUpO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF9ncmlkU2V0Um93Q3ljbGUoKTogdm9pZCB7XHJcbiAgICAgICAgaWYgKHR5cGVvZiB0aGlzLmNvbmZpZy5zZWxlY3Rpb24gIT09ICd1bmRlZmluZWQnICYmIHR5cGVvZiB0aGlzLmNvbmZpZy5zZWxlY3Rpb24udHlwZSAhPT0gJ3VuZGVmaW5lZCcpIHtcclxuICAgICAgICAgICAgdGhpcy5fcHJvY2Vzc0luaXRpYWxTZWxlY3Rpb24oKTtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIGVsc2UgaWYgKHRoaXMuX3RhYmxlU2VydmljZS5oYXNJbnB1dFR5cGUodGhpcy5jb2x1bW4sICdpbnB1dCcpKSB7XHJcbiAgICAgICAgICAgIHRoaXMuX2VtaXRJbnB1dFVwZGF0ZUV2ZW50KCk7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX2dyaWRDbGlja05hdmlnYXRlQ3ljbGUoX3Jvd05vZGU6IFJvd05vZGUpOiB2b2lkIHtcclxuICAgICAgICBpZiAodHlwZW9mIHRoaXMuY29uZmlnLmNsaWNrLnBhdGhNYXAgIT09ICd1bmRlZmluZWQnKSB7XHJcbiAgICAgICAgICAgIGlmICh0eXBlb2YgdGhpcy5jb25maWcuYWN0aW9uICE9PSAndW5kZWZpbmVkJyAmJlxyXG4gICAgICAgICAgICAgICAgdHlwZW9mIHRoaXMuY29uZmlnLmFjdGlvbi5saXN0ICE9PSAndW5kZWZpbmVkJykge1xyXG4gICAgICAgICAgICAgICAgbGV0IHJvdXRlclBhdGg6IHN0cmluZyA9ICcnO1xyXG5cclxuICAgICAgICAgICAgICAgIGZvciAobGV0IGk6IG51bWJlciA9IDA7IGkgPCB0aGlzLmNvbmZpZy5hY3Rpb24ubGlzdC5sZW5ndGg7ICsraSkge1xyXG4gICAgICAgICAgICAgICAgICAgIGxldCBhY3Rpb25JdGVtOiBJVGFibGVEcm9wZG93bkFjdGlvbiA9IHRoaXMuY29uZmlnLmFjdGlvbi5saXN0W2ldO1xyXG5cclxuICAgICAgICAgICAgICAgICAgICBpZiAoYWN0aW9uSXRlbS50eXBlLnRvTG93ZXJDYXNlKCkgPT09IHRoaXMuY29uZmlnLmNsaWNrLnBhdGhNYXAudG9Mb3dlckNhc2UoKSkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICByb3V0ZXJQYXRoID0gdGhpcy5fdGFibGVTZXJ2aWNlLmdldFJvdXRlclBsYWNlaG9sZGVyUGF0aChfcm93Tm9kZSwgYWN0aW9uSXRlbS5wYXRoKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgICAgIGlmIChyb3V0ZXJQYXRoICE9PSAnJykge1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuX3JvdXRlci5uYXZpZ2F0ZShbcm91dGVyUGF0aF0pO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgZWxzZSB7XHJcbiAgICAgICAgICAgICAgICAgICAgY29uc29sZS53YXJuKCdLZFRhYmxlIHdhcm5pbmc6IFRhYmxlIHJvdXRlciBwYXRoTWFwIG5vdCBmb3VuZC4gcGF0aE1hcCBzZXQgdG86JywgdGhpcy5jb25maWcuY2xpY2sucGF0aE1hcCk7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgZWxzZSB7XHJcbiAgICAgICAgICAgICAgICBjb25zb2xlLmVycm9yKCdLZFRhYmxlIGVycm9yOiBUYWJsZSBjbGljayBldmVudCBzZXQgdG8gcm91dGVyIHBhdGhNYXAgYnV0IG5vIGFjdGlvbiBsaXN0IGlzIGRlZmluZWQuIERvIHlvdSBtZWFuIHBhdGggcHJvcGVydHkgaW5zdGVhZCBvZiBwYXRoTWFwIHByb3BlcnR5PycpO1xyXG4gICAgICAgICAgICB9XHJcblxyXG4gICAgICAgIH1cclxuICAgICAgICBlbHNlIGlmICh0eXBlb2YgdGhpcy5jb25maWcuY2xpY2sucGF0aCAhPT0gJ3VuZGVmaW5lZCcpIHtcclxuICAgICAgICAgICAgdGhpcy5fcm91dGVyLm5hdmlnYXRlKFt0aGlzLmNvbmZpZy5jbGljay5wYXRoXSk7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICBjb25zb2xlLmVycm9yKCdLZFRhYmxlIGVycm9yOiBUYWJsZSBjbGljayBldmVudCB0eXBlIHNldCBhdCByb3V0ZXIgYnV0IG5vIHBhdGggLyBwYXRoTWFwIGlzIHByb3ZpZGVkLiBEbyB5b3UgbWVhbiBjbGljayB0eXBlIHNlbGVjdGlvbiAvIG5vbmU/Jyk7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIC8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vXHJcbiAgICAvLyBEaXNwbGF5IC8gRE9NIGZ1bmN0aW9uXHJcbiAgICAvLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vL1xyXG5cclxuICAgIHByaXZhdGUgX3Nob3dMb2FkaW5nT3ZlcmxheShfdG9nZ2xlOiBib29sZWFuKTogdm9pZCB7XHJcbiAgICAgICAgdGhpcy5kaXNwbGF5TG9hZGluZyA9IF90b2dnbGU7XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfdXBkYXRlUGFyZW50Tm9kZUNTUygpOiB2b2lkIHtcclxuICAgICAgICB0aGlzLl92Y3IuZWxlbWVudC5uYXRpdmVFbGVtZW50LnBhcmVudE5vZGUuY2xhc3NOYW1lICs9ICcgaGFzLWFnZ3JpZCc7XHJcbiAgICAgICAgaWYgKHRoaXMuX2RpcmVjdGlvbiA9PT0gJ3J0bCcpIGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3IoJ2JvZHknKS5zdHlsZS5jc3NUZXh0ICs9ICctLWtkdGFibGUtaGVhZGVyLXRleHQtYWxpZ246IHJpZ2h0Oyc7XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfc2V0SGVpZ2h0KCk6IHZvaWQge1xyXG4gICAgICAgIGxldCBkb21FbGVRdWVyeTogc3RyaW5nID0gJyMnICsgdGhpcy5ncmlkSWQgKyAnLnN0Zy10aGVtZSc7XHJcbiAgICAgICAgbGV0IGdyaWRFbGVtZW50OiBFbGVtZW50ID0gdGhpcy5fdmNyLmVsZW1lbnQubmF0aXZlRWxlbWVudC5xdWVyeVNlbGVjdG9yKGRvbUVsZVF1ZXJ5KTtcclxuXHJcbiAgICAgICAgaWYgKGdyaWRFbGVtZW50ICE9PSBudWxsKSB7XHJcbiAgICAgICAgICAgIGxldCB3aW5kb3dzV2lkdGg6IG51bWJlciA9IGRvY3VtZW50LmJvZHkuY2xpZW50V2lkdGg7XHJcblxyXG4gICAgICAgICAgICBpZiAod2luZG93c1dpZHRoIDw9IDEwMjQpIHtcclxuICAgICAgICAgICAgICAgIGlmICh0eXBlb2YgdGhpcy5faXNNb2JpbGVWaWV3ID09PSAndW5kZWZpbmVkJyB8fCAhdGhpcy5faXNNb2JpbGVWaWV3KSB7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5fc2hvd0xvYWRpbmdPdmVybGF5KHRydWUpO1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuX2lzTW9iaWxlVmlldyA9IHRydWU7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5fc2V0TW9iaWxlSGVpZ2h0KGdyaWRFbGVtZW50KTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBlbHNlIGlmICh3aW5kb3dzV2lkdGggPiAxMDI0KSB7XHJcbiAgICAgICAgICAgICAgICBpZiAodHlwZW9mIHRoaXMuX2lzTW9iaWxlVmlldyA9PT0gJ3VuZGVmaW5lZCcgfHwgdGhpcy5faXNNb2JpbGVWaWV3KSB7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5fc2hvd0xvYWRpbmdPdmVybGF5KHRydWUpO1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuX2lzTW9iaWxlVmlldyA9IGZhbHNlO1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuX3NldFdlYkdyaWRIZWlnaHQoZ3JpZEVsZW1lbnQsIHRoaXMuY29uZmlnLmdyaWRIZWlnaHQpO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgZWxzZSB7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5ncmlkT3B0aW9ucy5hcGkuc2l6ZUNvbHVtbnNUb0ZpdCgpO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIC8qKlxyXG4gICAgICogYWRkIGJvcmRlciBib3R0b20gZHluYW1pY2FsbHkgc28gdGhhdCB3aGVuIHRoZSByb3cgaXMgbGVzc2VyIHRoYW4gYm9keS1jb250YWluZXIsIHRoZXJlIHdvbnQgYmUgYW55IGhhbmdpbmcgYm9yZGVyIGJvdHRvbVxyXG4gICAgICogd2hlbiB0aGUgcm93IGlzIG1vcmUgdGhhbiBjb250YWluZXIsIHRoZXJlIHdpbGwgYmUgYSBib3JkZXItYm90dG9tXHJcbiAgICAgKi9cclxuICAgIHByaXZhdGUgX3NldFRhYmxlQm9yZGVyQm90dG9tKCk6IHZvaWQge1xyXG4gICAgICAgIGxldCBjb250YWluZXJFbGVRdWVyeTogc3RyaW5nID0gJyAuYWctYm9keS1jb250YWluZXInO1xyXG4gICAgICAgIGxldCBjb250YWluZXJFbGU6IEVsZW1lbnQgPSB0aGlzLl92Y3IuZWxlbWVudC5uYXRpdmVFbGVtZW50LnF1ZXJ5U2VsZWN0b3IoY29udGFpbmVyRWxlUXVlcnkpO1xyXG4gICAgICAgIGlmIChjb250YWluZXJFbGUgPT09IG51bGwpIHJldHVybjtcclxuXHJcbiAgICAgICAgbGV0IHZpZXdwb3J0RWxlUXVlcnk6IHN0cmluZyA9ICcgLmFnLWJvZHktdmlld3BvcnQnO1xyXG4gICAgICAgIGxldCB2aWV3cG9ydEVsZTogRWxlbWVudCA9IHRoaXMuX3Zjci5lbGVtZW50Lm5hdGl2ZUVsZW1lbnQucXVlcnlTZWxlY3Rvcih2aWV3cG9ydEVsZVF1ZXJ5KTtcclxuXHJcbiAgICAgICAgaWYgKGNvbnRhaW5lckVsZS5jbGllbnRIZWlnaHQgPiB2aWV3cG9ydEVsZS5jbGllbnRIZWlnaHQgJiZcclxuICAgICAgICAgICAgdmlld3BvcnRFbGUuY2xhc3NOYW1lICYmXHJcbiAgICAgICAgICAgIHZpZXdwb3J0RWxlLmNsYXNzTmFtZS5pbmRleE9mKCdoYXMtYm9yZGVyLWJvdHRvbScpID09PSAtMVxyXG4gICAgICAgICkge1xyXG4gICAgICAgICAgICB2aWV3cG9ydEVsZS5jbGFzc05hbWUgKz0gJyBoYXMtYm9yZGVyLWJvdHRvbSc7XHJcbiAgICAgICAgfSBlbHNlIGlmIChjb250YWluZXJFbGUuY2xpZW50SGVpZ2h0IDwgdmlld3BvcnRFbGUuY2xpZW50SGVpZ2h0KSB7XHJcbiAgICAgICAgICAgIHZpZXdwb3J0RWxlLmNsYXNzTmFtZSA9IHZpZXdwb3J0RWxlLmNsYXNzTmFtZS5yZXBsYWNlKC9oYXMtYm9yZGVyLWJvdHRvbS9naSwgJycpO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF9zZXRNb2JpbGVIZWlnaHQoX2dyaWRFbGVtZW50OiBFbGVtZW50KTogdm9pZCB7XHJcbiAgICAgICAgbGV0IG5ld0hlaWdodDogbnVtYmVyID0gMDtcclxuXHJcbiAgICAgICAgaWYgKHRoaXMuY29uZmlnLmxvYWRUeXBlICE9PSAnaW5maW5pdGUnKSB7XHJcbiAgICAgICAgICAgIGxldCBhZ0hlYWRlckVsZTogRWxlbWVudCA9IHRoaXMuX3Zjci5lbGVtZW50Lm5hdGl2ZUVsZW1lbnQucXVlcnlTZWxlY3RvcignLmFnLWhlYWRlcicpO1xyXG4gICAgICAgICAgICBsZXQgYWdCb2R5RWxlOiBFbGVtZW50ID0gdGhpcy5fdmNyLmVsZW1lbnQubmF0aXZlRWxlbWVudC5xdWVyeVNlbGVjdG9yKCcuYWctYm9keS1jb250YWluZXInKTtcclxuICAgICAgICAgICAgbGV0IGFnUGFnZVBhbmVsRWxlOiBFbGVtZW50ID0gdGhpcy5fdmNyLmVsZW1lbnQubmF0aXZlRWxlbWVudC5xdWVyeVNlbGVjdG9yKCdkaXZbcmVmPVwic291dGhcIl0nKTtcclxuICAgICAgICAgICAgbmV3SGVpZ2h0ID0gMjU7XHJcblxyXG4gICAgICAgICAgICBpZiAoYWdIZWFkZXJFbGUgIT09IG51bGwpIHtcclxuICAgICAgICAgICAgICAgIG5ld0hlaWdodCArPSBhZ0hlYWRlckVsZS5jbGllbnRIZWlnaHQ7XHJcbiAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgIGlmIChhZ0JvZHlFbGUgIT09IG51bGwpIHtcclxuICAgICAgICAgICAgICAgIG5ld0hlaWdodCArPSBhZ0JvZHlFbGUuY2xpZW50SGVpZ2h0O1xyXG4gICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICBpZiAoYWdQYWdlUGFuZWxFbGUgIT09IG51bGwpIHtcclxuICAgICAgICAgICAgICAgIG5ld0hlaWdodCArPSBhZ1BhZ2VQYW5lbEVsZS5jbGllbnRIZWlnaHQ7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICAgICAgZWxzZSB7XHJcbiAgICAgICAgICAgIG5ld0hlaWdodCA9IDQwMDtcclxuICAgICAgICB9XHJcblxyXG5cclxuICAgICAgICB0aGlzLl9kb21TdmMuc2V0RWxlbWVudFN0eWxlKF9ncmlkRWxlbWVudCwgJ2hlaWdodCcsIG5ld0hlaWdodCArICdweCcpO1xyXG5cclxuICAgICAgICB0aW1lcigxMCkuc3Vic2NyaWJlKCgpOiB2b2lkID0+IHtcclxuICAgICAgICAgICAgdGhpcy5ncmlkT3B0aW9ucy5hcGkuc2l6ZUNvbHVtbnNUb0ZpdCgpO1xyXG4gICAgICAgICAgICB0aGlzLl9zaG93TG9hZGluZ092ZXJsYXkoZmFsc2UpO1xyXG4gICAgICAgIH0pO1xyXG4gICAgfVxyXG5cclxuICAgIC8qKlxyXG4gICAgICogW19zZXRXZWJHcmlkSGVpZ2h0IG51bWJlciBmb3IgcGl4ZWwgb3Igc3RyaW5nIFwiYXV0b1wiXVxyXG4gICAgICogIF9jb25maWdIZWlnaHQgW2Rlc2NyaXB0aW9uXVxyXG4gICAgICovXHJcbiAgICBwcml2YXRlIF9zZXRXZWJHcmlkSGVpZ2h0KF9ncmlkRWxlbWVudDogRWxlbWVudCwgX2NvbmZpZ0hlaWdodDogbnVtYmVyIHwgc3RyaW5nKTogdm9pZCB7XHJcbiAgICAgICAgaWYgKHR5cGVvZiBfY29uZmlnSGVpZ2h0ID09PSAnbnVtYmVyJykge1xyXG4gICAgICAgICAgICBsZXQgZ3JpZEhlaWdodDogbnVtYmVyID0gNjAwO1xyXG5cclxuICAgICAgICAgICAgaWYgKHR5cGVvZiBfY29uZmlnSGVpZ2h0ICE9PSAndW5kZWZpbmVkJykge1xyXG4gICAgICAgICAgICAgICAgZ3JpZEhlaWdodCA9IF9jb25maWdIZWlnaHQ7XHJcbiAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgIHRoaXMuX2RvbVN2Yy5zZXRFbGVtZW50U3R5bGUoX2dyaWRFbGVtZW50LCAnaGVpZ2h0JywgZ3JpZEhlaWdodCArICdweCcpO1xyXG4gICAgICAgIH1cclxuICAgICAgICBlbHNlIGlmIChfY29uZmlnSGVpZ2h0ID09PSAnYXV0bycpIHtcclxuICAgICAgICAgICAgdGhpcy5kaXNwbGF5RnVsbCA9IHRydWU7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIC8vIGVsc2UgaWYgKF9jb25maWdIZWlnaHQgPT09ICdyb3dIZWlnaHQnKSB7XHJcbiAgICAgICAgLy8gICAgIHRoaXMuZ3JpZE9wdGlvbnMuZG9tTGF5b3V0ID0gJ2F1dG9IZWlnaHQnO1xyXG4gICAgICAgIC8vICAgICBkZWxldGUgdGhpcy5ncmlkT3B0aW9ucy5yb3dIZWlnaHQ7XHJcbiAgICAgICAgLy8gICAgIGRlbGV0ZSB0aGlzLmdyaWRPcHRpb25zLmdldFJvd0hlaWdodDtcclxuICAgICAgICAvLyB9XHJcblxyXG4gICAgICAgIHRpbWVyKCkuc3Vic2NyaWJlKCgpOiB2b2lkID0+IHtcclxuICAgICAgICAgICAgdGhpcy5ncmlkT3B0aW9ucy5hcGkuc2l6ZUNvbHVtbnNUb0ZpdCgpO1xyXG4gICAgICAgICAgICB0aGlzLl9zaG93TG9hZGluZ092ZXJsYXkoZmFsc2UpO1xyXG4gICAgICAgIH0pO1xyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX2lzQ2xpY2tWYWxpZChfZXZlbnQ6IEV2ZW50KTogYm9vbGVhbiB7XHJcbiAgICAgICAgbGV0IHRhcmdldEVsZW1lbnQ6IEhUTUxFbGVtZW50ID0gPEhUTUxFbGVtZW50Pl9ldmVudC50YXJnZXQ7XHJcbiAgICAgICAgbGV0IGludmFsaWRMaXN0OiBBcnJheTxzdHJpbmc+ID0gWydhY3Rpb24tYnRuJywgJ2NoZWNrYm94LXJhZGlvLWlucHV0JywgJ2ZhLWNoZXZyb24tZG93biddO1xyXG5cclxuICAgICAgICBmb3IgKGxldCBpOiBudW1iZXIgPSAwOyBpIDwgaW52YWxpZExpc3QubGVuZ3RoOyBpKyspIHtcclxuICAgICAgICAgICAgaWYgKHRhcmdldEVsZW1lbnQuY2xhc3NMaXN0LmNvbnRhaW5zKGludmFsaWRMaXN0W2ldKSkge1xyXG4gICAgICAgICAgICAgICAgcmV0dXJuIGZhbHNlO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICByZXR1cm4gdHJ1ZTtcclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF9yZXNpemVDb2x1bW4oX2lzUmVzaXplVG9Db250ZW50OiBib29sZWFuID0gZmFsc2UpOiB2b2lkIHtcclxuICAgICAgICBpZiAodGhpcy5fdGFibGVTZXJ2aWNlLmlzQXBpUmVhZHkodGhpcy5ncmlkT3B0aW9ucykpIHtcclxuICAgICAgICAgICAgdGltZXIoMTApLnN1YnNjcmliZSgoKTogdm9pZCA9PiB7XHJcbiAgICAgICAgICAgICAgICAoX2lzUmVzaXplVG9Db250ZW50KSA/IHRoaXMuX3Jlc2l6ZUNvbHVtblRvQ29udGVudCgpIDogdGhpcy5ncmlkT3B0aW9ucy5hcGkuc2l6ZUNvbHVtbnNUb0ZpdCgpO1xyXG4gICAgICAgICAgICAgICAgdGhpcy5vbkV4cG9ydFBvc3NpYmxlLmVtaXQodHJ1ZSk7XHJcbiAgICAgICAgICAgICAgICB0aGlzLl9zaG93TG9hZGluZ092ZXJsYXkoZmFsc2UpO1xyXG4gICAgICAgICAgICB9KTtcclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgLyoqXHJcbiAgICAgKiByZXNpemUgY29sdW1uIHRvIGNvbERlZiB3aWR0aFxyXG4gICAgICovXHJcbiAgICBwcml2YXRlIF9yZXNpemVDb2x1bW5Ub0NvbnRlbnQoKTogdm9pZCB7XHJcbiAgICAgICAgbGV0IGFsbENvbHVtbklkczogQXJyYXk8c3RyaW5nPiA9IFtdO1xyXG4gICAgICAgIHRoaXMuZ3JpZE9wdGlvbnMuY29sdW1uQXBpLmdldEFsbERpc3BsYXllZENvbHVtbnMoKS5mb3JFYWNoKChjb2x1bW46IENvbHVtbikgPT4ge1xyXG4gICAgICAgICAgICBhbGxDb2x1bW5JZHMucHVzaChjb2x1bW4uZ2V0Q29sSWQoKSk7XHJcbiAgICAgICAgfSk7XHJcbiAgICAgICAgdGhpcy5ncmlkT3B0aW9ucy5jb2x1bW5BcGkuYXV0b1NpemVDb2x1bW5zKGFsbENvbHVtbklkcyk7XHJcbiAgICB9XHJcblxyXG4gICAgLyoqXHJcbiAgICAgKiBwb3B1bGF0ZSBkeW5hbWljIHN0eWxpbmcgdmFsdWVcclxuICAgICAqIHBhcmFtIHtJVGFibGVDb25maWd9IF9jb25maWc6IHRhYmxlQ29uZmlnXHJcbiAgICAgKi9cclxuICAgIHB1YmxpYyB1cGRhdGVTdHlsZShfY29uZmlnOiBJVGFibGVDb25maWcpOiB2b2lkIHtcclxuICAgICAgICBpZiAoIV9jb25maWcgfHwgIV9jb25maWcuY29uZmlnKSB7XHJcbiAgICAgICAgICAgIGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3IoJ2JvZHknKS5zdHlsZS5jc3NUZXh0ID0gJyc7XHJcbiAgICAgICAgICAgIHJldHVybjtcclxuICAgICAgICB9XHJcbiAgICAgICAgbGV0IGNvbmZpZzogSVN0eWxpbmdDb25maWcgPSBfY29uZmlnLmNvbmZpZztcclxuXHJcbiAgICAgICAgbGV0IGJvZHlDc3M6IHN0cmluZyA9ICcnO1xyXG5cclxuICAgICAgICBib2R5Q3NzICs9IHRoaXMuX3VwZGF0ZUhlYWRlclN0eWxlKGNvbmZpZyk7XHJcblxyXG4gICAgICAgIGlmIChjb25maWcuYm9keSkge1xyXG4gICAgICAgICAgICBpZiAoY29uZmlnLmJvZHkuYWx0ZXJuYXRlUm93ID09PSB0cnVlKSB7XHJcbiAgICAgICAgICAgICAgICBpZiAoY29uZmlnLmJvZHkub2RkICYmIGNvbmZpZy5ib2R5Lm9kZC5iYWNrZ3JvdW5kQ29sb3IpIHtcclxuICAgICAgICAgICAgICAgICAgICBib2R5Q3NzICs9ICctLWtkdGFibGUtcm93LW9kZC1iYWNrZ3JvdW5kOiAnICsgY29uZmlnLmJvZHkub2RkLmJhY2tncm91bmRDb2xvciArICc7JztcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIGlmIChjb25maWcuYm9keS5ldmVuICYmIGNvbmZpZy5ib2R5LmV2ZW4uYmFja2dyb3VuZENvbG9yKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgYm9keUNzcyArPSAnLS1rZHRhYmxlLXJvdy1ldmVuLWJhY2tncm91bmQ6ICcgKyBjb25maWcuYm9keS5ldmVuLmJhY2tncm91bmRDb2xvciArICc7JztcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBpZiAoY29uZmlnLmJvZHkuc3R5bGUpIHtcclxuICAgICAgICAgICAgICAgIGlmIChjb25maWcuYm9keS5zdHlsZS5ib3JkZXJXaWR0aCkge1xyXG4gICAgICAgICAgICAgICAgICAgIGJvZHlDc3MgKz0gJy0ta2R0YWJsZS1ib2R5LWJvcmRlci13aWR0aDogJyArIGNvbmZpZy5ib2R5LnN0eWxlLmJvcmRlcldpZHRoICsgJzsnO1xyXG4gICAgICAgICAgICAgICAgICAgIGJvZHlDc3MgKz0gJy0ta2R0YWJsZS1oZWFkZXItYm9yZGVyLXdpZHRoOiAnICsgY29uZmlnLmJvZHkuc3R5bGUuYm9yZGVyV2lkdGggKyAnOyc7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICBpZiAoY29uZmlnLmJvZHkuc3R5bGUuYm9yZGVyQ29sb3IpIHtcclxuICAgICAgICAgICAgICAgICAgICBib2R5Q3NzICs9ICctLWtkdGFibGUtYm9keS1ib3JkZXItY29sb3I6ICcgKyBjb25maWcuYm9keS5zdHlsZS5ib3JkZXJDb2xvciArICc7JztcclxuICAgICAgICAgICAgICAgICAgICBib2R5Q3NzICs9ICctLWtkdGFibGUtaGVhZGVyLWJvcmRlci1jb2xvcjogJyArIGNvbmZpZy5ib2R5LnN0eWxlLmJvcmRlckNvbG9yICsgJzsnO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgaWYgKGNvbmZpZy5ib2R5LnN0eWxlLmJvcmRlclN0eWxlKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgYm9keUNzcyArPSAnLS1rZHRhYmxlLWJvZHktYm9yZGVyLXN0eWxlOiAnICsgY29uZmlnLmJvZHkuc3R5bGUuYm9yZGVyU3R5bGUgKyAnOyc7XHJcbiAgICAgICAgICAgICAgICAgICAgYm9keUNzcyArPSAnLS1rZHRhYmxlLWhlYWRlci1ib3JkZXItc3R5bGU6ICcgKyBjb25maWcuYm9keS5zdHlsZS5ib3JkZXJTdHlsZSArICc7JztcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgZG9jdW1lbnQucXVlcnlTZWxlY3RvcignYm9keScpLnN0eWxlLmNzc1RleHQgPSBib2R5Q3NzO1xyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX3VwZGF0ZUhlYWRlclN0eWxlKF9jb25maWc6IElTdHlsaW5nQ29uZmlnKTogc3RyaW5nIHtcclxuICAgICAgICBpZiAoIV9jb25maWcuaGVhZGVyIHx8ICFfY29uZmlnLmhlYWRlci5zdHlsZSkgcmV0dXJuICcnO1xyXG5cclxuICAgICAgICBsZXQgYm9keUNzczogc3RyaW5nID0gJyc7XHJcbiAgICAgICAgbGV0IHN0eWxlTmFtZXM6IEFycmF5PHN0cmluZz4gPSBbXHJcbiAgICAgICAgICAgICdiYWNrZ3JvdW5kQ29sb3InLFxyXG4gICAgICAgICAgICAndGV4dEFsaWduJyxcclxuICAgICAgICAgICAgJ3ZlcnRpY2FsQWxpZ24nLFxyXG4gICAgICAgICAgICAnY29sb3InLFxyXG4gICAgICAgICAgICAnZm9udEZhbWlseScsXHJcbiAgICAgICAgICAgICdmb250U2l6ZScsXHJcbiAgICAgICAgICAgICdmb250V2VpZ2h0JyxcclxuICAgICAgICAgICAgJ2ZvbnRTdHlsZScsXHJcbiAgICAgICAgICAgICd0ZXh0RGVjb3JhdGlvbicsXHJcbiAgICAgICAgICAgIC8vICdib3JkZXJXaWR0aCcsXHJcbiAgICAgICAgICAgIC8vICdib3JkZXJDb2xvcicsXHJcbiAgICAgICAgICAgIC8vICdib3JkZXJTdHlsZScsXHJcbiAgICAgICAgICAgICdvcGFjaXR5J1xyXG4gICAgICAgIF07XHJcbiAgICAgICAgZm9yIChsZXQgaTogbnVtYmVyID0gMDsgaSA8IHN0eWxlTmFtZXMubGVuZ3RoOyArK2kpIHtcclxuICAgICAgICAgICAgbGV0IHN0eWxlTmFtZTogc3RyaW5nID0gc3R5bGVOYW1lc1tpXTtcclxuICAgICAgICAgICAgbGV0IHZhbHVlOiBzdHJpbmcgPSBfY29uZmlnLmhlYWRlci5zdHlsZVtzdHlsZU5hbWVdO1xyXG4gICAgICAgICAgICBpZiAoc3R5bGVOYW1lID09PSAndmVydGljYWxBbGlnbicpIHZhbHVlID0gdGhpcy5fZ2V0QWxpZ25JdGVtKHZhbHVlKTtcclxuICAgICAgICAgICAgc3R5bGVOYW1lID0gKHN0eWxlTmFtZSA9PT0gJ2JhY2tncm91bmRDb2xvcicpID8gJ2JhY2tncm91bmQnIDogc3R5bGVOYW1lLnJlcGxhY2UoLyhbYS16XSkoW0EtWl0pL2csICckMS0kMicpLnRvTG93ZXJDYXNlKCk7XHJcbiAgICAgICAgICAgIGlmICh0eXBlb2YgdmFsdWUgIT09ICd1bmRlZmluZWQnKSB7XHJcbiAgICAgICAgICAgICAgICBpZiAoc3R5bGVOYW1lID09PSAnYm9yZGVyV2lkdGgnICYmXHJcbiAgICAgICAgICAgICAgICAgICAgKHR5cGVvZiB2YWx1ZSAhPT0gJ3N0cmluZycgfHwgdmFsdWUuaW5kZXhPZigncHgnKSA9PT0gLTEpXHJcbiAgICAgICAgICAgICAgICApIHZhbHVlICs9ICdweCc7XHJcbiAgICAgICAgICAgICAgICBib2R5Q3NzICs9ICctLWtkdGFibGUtaGVhZGVyLScgKyBzdHlsZU5hbWUgKyAnOiAnICsgdmFsdWUgKyAnOyc7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICAgICAgcmV0dXJuIGJvZHlDc3M7XHJcbiAgICB9XHJcblxyXG4gICAgLyoqXHJcbiAgICAgKiBjb252ZXJ0IHRleHQgYWxpZ24gaW50byBmbGV4LWJveCBpdGVtIGFsaWduXHJcbiAgICAgKiBwYXJhbSB7c3RyaW5nfSBfdmVydGljYWxBbGlnbjogdGV4dCB2ZXJ0aWNhbEFsaWduXHJcbiAgICAgKi9cclxuICAgIHByaXZhdGUgX2dldEFsaWduSXRlbShfdmVydGljYWxBbGlnbjogc3RyaW5nKTogc3RyaW5nIHtcclxuICAgICAgICBpZiAoX3ZlcnRpY2FsQWxpZ24gPT09ICdiYXNlbGluZScgfHwgX3ZlcnRpY2FsQWxpZ24gPT09ICdib3R0b20nKSB7XHJcbiAgICAgICAgICAgIHJldHVybiAnZmxleC1lbmQnO1xyXG4gICAgICAgIH0gZWxzZSBpZiAoX3ZlcnRpY2FsQWxpZ24gPT09ICd0b3AnKSB7XHJcbiAgICAgICAgICAgIHJldHVybiAnZmxleC1zdGFydCc7XHJcbiAgICAgICAgfSBlbHNlIHsgLy8gaW5jbHVkaW5nIGludmFsaWQgaW5wdXRcclxuICAgICAgICAgICAgaWYgKF92ZXJ0aWNhbEFsaWduICE9PSAnbWlkZGxlJyAmJiBfdmVydGljYWxBbGlnbiAhPT0gdW5kZWZpbmVkKSB7XHJcbiAgICAgICAgICAgICAgICBjb25zb2xlLndhcm4oJ0VSUk9SOiB0aGUgdmVydGljYWwgYWxpZ24gdmFsdWUgb2YgJyArIF92ZXJ0aWNhbEFsaWduICsgJyBpcyBub3QgeWV0IHJlY29nbmlzZWQgYnkgS2RUYWJsZS4gUGxlYXNlIG9ubHkgdXNlIGVpdGhlciB0b3AsIGNlbnRlciBvciBib3R0b20nKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICByZXR1cm4gJ2NlbnRlcic7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIC8vIHByaXZhdGUgX3JlZnJlc2hUYWJsZShfdGFibGVDZWxsUGFyYW1zPzogSVRhYmxlQ2VsbFBhcmFtcyk6IHZvaWQge1xyXG4gICAgLy8gICAgIGlmICh0aGlzLl90YWJsZVNlcnZpY2UgJiYgdGhpcy5fdGFibGVTZXJ2aWNlLmlzQXBpUmVhZHkgJiYgdGhpcy5fdGFibGVTZXJ2aWNlLmlzQXBpUmVhZHkodGhpcy5ncmlkT3B0aW9ucykpIHtcclxuICAgIC8vICAgICAgICAgbGV0IHRvVXBkYXRlTm9kZTogQXJyYXk8Um93Tm9kZT4gPSBbXTtcclxuICAgIC8vICAgICAgICAgbGV0IGFsbENvbHVtbklkczogQXJyYXk8c3RyaW5nPiA9IFtdO1xyXG5cclxuICAgIC8vICAgICAgICAgaWYgKCFfdGFibGVDZWxsUGFyYW1zKSB7XHJcbiAgICAvLyAgICAgICAgICAgICB0aGlzLmdyaWRPcHRpb25zLmNvbHVtbkFwaS5nZXRBbGxEaXNwbGF5ZWRDb2x1bW5zKCkuZm9yRWFjaCgoY29sdW1uKSA9PiB7XHJcbiAgICAvLyAgICAgICAgICAgICAgICAgYWxsQ29sdW1uSWRzLnB1c2goY29sdW1uLmdldENvbElkKCkpO1xyXG4gICAgLy8gICAgICAgICAgICAgfSk7XHJcbiAgICAvLyAgICAgICAgIH1cclxuXHJcbiAgICAvLyAgICAgICAgIHRoaXMuZ3JpZE9wdGlvbnMuYXBpLmZvckVhY2hOb2RlKChfcm93Tm9kZTogUm93Tm9kZSk6IHZvaWQgPT4ge1xyXG4gICAgLy8gICAgICAgICAgICAgaWYgKF90YWJsZUNlbGxQYXJhbXMgJiYgdHlwZW9mIF9yb3dOb2RlLmlkICE9PSAndW5kZWZpbmVkJyAmJiBfcm93Tm9kZS5pZCA9PT0gX3RhYmxlQ2VsbFBhcmFtcy5yb3dJZCkge1xyXG4gICAgLy8gICAgICAgICAgICAgICAgIF9yb3dOb2RlLmRhdGFbX3RhYmxlQ2VsbFBhcmFtcy5jb2xJZF0gPSBfdGFibGVDZWxsUGFyYW1zLmRhdGE7XHJcbiAgICAvLyAgICAgICAgICAgICAgICAgdG9VcGRhdGVOb2RlLnB1c2goX3Jvd05vZGUpO1xyXG4gICAgLy8gICAgICAgICAgICAgfSBlbHNlIHtcclxuICAgIC8vICAgICAgICAgICAgICAgICB0b1VwZGF0ZU5vZGUucHVzaChfcm93Tm9kZSk7XHJcbiAgICAvLyAgICAgICAgICAgICB9XHJcbiAgICAvLyAgICAgICAgIH0pO1xyXG5cclxuICAgIC8vICAgICAgICAgbGV0IHJlZnJlc2hQYXJhbXM6IHsgcm93Tm9kZXM6IEFycmF5PFJvd05vZGU+LCBjb2x1bW5zOiBBcnJheTxhbnk+IH0gPSB7XHJcbiAgICAvLyAgICAgICAgICAgICByb3dOb2RlczogdG9VcGRhdGVOb2RlLFxyXG4gICAgLy8gICAgICAgICAgICAgY29sdW1uczogKF90YWJsZUNlbGxQYXJhbXMpID8gW190YWJsZUNlbGxQYXJhbXMuY29sSWRdIDogYWxsQ29sdW1uSWRzXHJcbiAgICAvLyAgICAgICAgIH07XHJcblxyXG4gICAgLy8gICAgICAgICB0aGlzLmdyaWRPcHRpb25zLmFwaS5yZWZyZXNoQ2VsbHMocmVmcmVzaFBhcmFtcyk7XHJcbiAgICAvLyAgICAgfVxyXG4gICAgLy8gfVxyXG5cclxuICAgIC8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vXHJcbiAgICAvLy8gUGl2b3QgRnVuY3Rpb25cclxuICAgIC8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vXHJcbiAgICBwcml2YXRlIF9pc1Rvb2xwYW5lbFR5cGVDaGFuZ2VkKCk6IGJvb2xlYW4ge1xyXG4gICAgICAgIGxldCBpc1R5cGVDaGFuZ2VkOiBib29sZWFuID0gdHJ1ZTtcclxuICAgICAgICBpZiAodGhpcy5fcHJldmlvdXNUb29scGFuZWxUeXBlKSB7XHJcbiAgICAgICAgICAgIGlmICh0eXBlRXhpc3QodGhpcy5jb25maWcpKSB7XHJcbiAgICAgICAgICAgICAgICBpc1R5cGVDaGFuZ2VkID0gdGhpcy5fcHJldmlvdXNUb29scGFuZWxUeXBlICE9PSB0aGlzLmNvbmZpZy5waXZvdC50b29scGFuZWwudHlwZTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgIGlmICh0eXBlRXhpc3QodGhpcy5jb25maWcpKSB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLl9wcmV2aW91c1Rvb2xwYW5lbFR5cGUgPSB0aGlzLmNvbmZpZy5waXZvdC50b29scGFuZWwudHlwZTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgICAgICByZXR1cm4gaXNUeXBlQ2hhbmdlZDtcclxuXHJcbiAgICAgICAgZnVuY3Rpb24gdHlwZUV4aXN0KF9jb25maWcpIHtcclxuICAgICAgICAgICAgcmV0dXJuIF9jb25maWcgJiYgX2NvbmZpZy5waXZvdCAmJiBfY29uZmlnLnBpdm90LnRvb2xwYW5lbCAmJiBfY29uZmlnLnBpdm90LnRvb2xwYW5lbC50eXBlXHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX2NvbmZpZ3VyZVBpdm90RGlzcGxheSgpOiB2b2lkIHtcclxuICAgICAgICBsZXQgaXNTdGF0ZUNoYW5nZWQ6IGJvb2xlYW4gPSB0cnVlO1xyXG4gICAgICAgIGlmICh0aGlzLmNvbmZpZyAmJiB0aGlzLmNvbmZpZy5waXZvdCAmJiB0aGlzLmNvbmZpZy5waXZvdC5zdGF0ZSAmJiB0aGlzLmNvbmZpZy5waXZvdC5zdGF0ZS5jb2x1bW5TdGF0ZSkge1xyXG4gICAgICAgICAgICBpc1N0YXRlQ2hhbmdlZCA9IHRoaXMuY29uZmlnLnBpdm90LnN0YXRlLmNvbHVtblN0YXRlLmxlbmd0aCAhPT0gdGhpcy5fY3VycmVudFN0YXRlLmNvbHVtblN0YXRlLmxlbmd0aDtcclxuICAgICAgICB9XHJcbiAgICAgICAgaWYgKHRoaXMuY29uZmlnLmxvYWRUeXBlICE9PSAnbm9ybWFsJyB8fCAodGhpcy5faXNUb29scGFuZWxUeXBlQ2hhbmdlZCgpID09PSBmYWxzZSAmJiBpc1N0YXRlQ2hhbmdlZCA9PT0gZmFsc2UpKSByZXR1cm47XHJcblxyXG4gICAgICAgIGxldCBzaG93VG9vbFBhbmVsOiBib29sZWFuID0gZmFsc2U7XHJcbiAgICAgICAgbGV0IHNob3dQaXZvdE1vZGU6IGJvb2xlYW4gPSBmYWxzZTtcclxuICAgICAgICBpZiAodGhpcy5jb25maWcucGl2b3QgJiYgdGhpcy5jb25maWcucGl2b3QudG9vbHBhbmVsKSB7XHJcbiAgICAgICAgICAgIHNob3dUb29sUGFuZWwgPSB0aGlzLmNvbmZpZy5waXZvdC50b29scGFuZWwudHlwZSAhPT0gJ25vbmUnO1xyXG4gICAgICAgICAgICBzaG93UGl2b3RNb2RlID0gdGhpcy5jb25maWcucGl2b3QudG9vbHBhbmVsLnR5cGUgPT09ICdwaXZvdCc7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIHRoaXMuX3Nob3dUb29sUGFuZWwoc2hvd1Rvb2xQYW5lbCk7XHJcbiAgICAgICAgdGhpcy5fc2hvd1Bpdm90TW9kZShzaG93UGl2b3RNb2RlKTtcclxuICAgIH1cclxuXHJcbiAgICAvKipcclxuICAgICAqIHJlc2l6ZSBjb2x1bW4gdG8gZml0IHRhYmxlIGNvbnRhaW5lciBpZiB0aGUgd2lkdGggb2YgdGhlIGNvbnRlbnQgY29sdW1uIGlzIHNtYWxsZXIgdGhhbiBjb250YWluZXJcclxuICAgICAqL1xyXG4gICAgcHJpdmF0ZSBfcGl2b3RSZXNpemUoKTogdm9pZCB7XHJcbiAgICAgICAgbGV0IGNvbnRhaW5lcjogRWxlbWVudCA9IHRoaXMuX3Zjci5lbGVtZW50Lm5hdGl2ZUVsZW1lbnQucXVlcnlTZWxlY3RvcignLmFnLWhlYWRlci1jb250YWluZXInKTtcclxuICAgICAgICBsZXQgaGVhZGVyOiBFbGVtZW50ID0gdGhpcy5fdmNyLmVsZW1lbnQubmF0aXZlRWxlbWVudC5xdWVyeVNlbGVjdG9yKCcuYWctaGVhZGVyLWNvbnRhaW5lciAuYWctaGVhZGVyLXJvdycpO1xyXG5cclxuICAgICAgICB0aGlzLl9yZXNpemVDb2x1bW4oaGVhZGVyLmdldEJvdW5kaW5nQ2xpZW50UmVjdCgpLndpZHRoID4gY29udGFpbmVyLmdldEJvdW5kaW5nQ2xpZW50UmVjdCgpLndpZHRoKTtcclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF9yZXNldFBpdm90Q29sdW1uKCk6IHZvaWQge1xyXG4gICAgICAgIHRoaXMuZ3JpZE9wdGlvbnMuY29sdW1uQXBpLnNldFJvd0dyb3VwQ29sdW1ucyhbXSk7XHJcbiAgICAgICAgdGhpcy5ncmlkT3B0aW9ucy5jb2x1bW5BcGkuc2V0UGl2b3RDb2x1bW5zKFtdKTtcclxuICAgICAgICB0aGlzLmdyaWRPcHRpb25zLmNvbHVtbkFwaS5zZXRWYWx1ZUNvbHVtbnMoW10pO1xyXG4gICAgICAgIHRoaXMuZ3JpZE9wdGlvbnMuY29sdW1uQXBpLnNldFNlY29uZGFyeUNvbHVtbnMoW10pO1xyXG4gICAgfVxyXG5cclxuICAgIC8qKlxyXG4gICAgICogcGFzcyBzdGF0ZSB0byBhcHBsaWNhdGlvbi5cclxuICAgICAqIChpZiBzZXRTdGF0ZSB3YXMgdHJpZ2dlcmVkIGJlZm9yZSksIHdhaXQgdW50aWwgc2V0U3RhdGUgaGFzIGRvbmUgcHJvY2Vzc2luZ1xyXG4gICAgICogcmV0dXJuIHtJVGFibGVQaXZvdFN0YXRlfSBbZGVzY3JpcHRpb25dXHJcbiAgICAgKi9cclxuICAgIHByaXZhdGUgX2dldFBpdm90U3RhdGUoKTogSVRhYmxlUGl2b3RTdGF0ZSB7XHJcbiAgICAgICAgLy8gaWYgc3RhdGUgaXMgY2hhbmdpbmcsIHdhaXQgdW50aWwgc3RhdGUgaGFzIGJlZW4gdXBkYXRlZCB0aGVuIGdldCB0aGUgbW9zdCB1cGRhdGVkIHN0YXRlXHJcbiAgICAgICAgbGV0IGdldFN0YXRlID0gKCk6IGFueSA9PiB7XHJcbiAgICAgICAgICAgIHRoaXMuX2N1cnJlbnRTdGF0ZS5jb2x1bW5TdGF0ZSA9IHRoaXMuZ3JpZE9wdGlvbnMuY29sdW1uQXBpLmdldENvbHVtblN0YXRlKCk7XHJcbiAgICAgICAgICAgIHRoaXMuX2N1cnJlbnRTdGF0ZS5waXZvdE1vZGUgPSB0aGlzLmdyaWRPcHRpb25zLmNvbHVtbkFwaS5pc1Bpdm90TW9kZSgpO1xyXG4gICAgICAgICAgICB0aGlzLl9jdXJyZW50U3RhdGUuZ3JvdXBTdGF0ZSA9IHRoaXMuZ3JpZE9wdGlvbnMuY29sdW1uQXBpLmdldENvbHVtbkdyb3VwU3RhdGUoKTtcclxuICAgICAgICAgICAgcmV0dXJuIHRoaXMuX2N1cnJlbnRTdGF0ZTtcclxuICAgICAgICB9O1xyXG4gICAgICAgIGxldCBjaGVjayA9ICgpOiBib29sZWFuID0+IHtcclxuICAgICAgICAgICAgcmV0dXJuIHRoaXMuX2lzQ2hhbmdpbmdTdGF0ZSA9PT0gZmFsc2U7XHJcbiAgICAgICAgfTtcclxuICAgICAgICByZXR1cm4gdGhpcy53YWl0KGNoZWNrLCBnZXRTdGF0ZSk7XHJcbiAgICB9XHJcblxyXG4gICAgLyoqXHJcbiAgICAgKiByZXBsYWNlIGN1cnJlbnQgc3RhdGUgaWYgYSBzdGF0ZSBpcyBnaXZlbiwgZXhwYW5kR3JvdXAgYmFzZSBvbiBjb25maWdcclxuICAgICAqIHNob3VsZCB3YWl0IHVudGlsIGNvbHVtbiBpcyBwcmVzZW50LlxyXG4gICAgICogcGFyYW0ge0lUYWJsZVBpdm90U3RhdGV9IF9zdGF0ZVxyXG4gICAgICovXHJcbiAgICBwcml2YXRlIF9zZXRQaXZvdFN0YXRlKF9zdGF0ZTogSVRhYmxlUGl2b3RTdGF0ZSk6IHZvaWQge1xyXG4gICAgICAgIGlmICh0eXBlb2YgKF9zdGF0ZSkgPT09ICd1bmRlZmluZWQnIHx8ICFfc3RhdGUuaGFzT3duUHJvcGVydHkoJ2NvbHVtblN0YXRlJykpIHJldHVybjtcclxuXHJcbiAgICAgICAgbGV0IHNldFN0YXRlID0gKCk6IHZvaWQgPT4ge1xyXG4gICAgICAgICAgICB0aGlzLl9pc0NoYW5naW5nU3RhdGUgPSB0cnVlO1xyXG4gICAgICAgICAgICBpZiAoX3N0YXRlLmNvbHVtblN0YXRlLmxlbmd0aCA9PT0gMCkge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5faXNDaGFuZ2luZ1N0YXRlID0gZmFsc2U7XHJcbiAgICAgICAgICAgICAgICB0aGlzLl9waXZvdFJlc2l6ZSgpO1xyXG4gICAgICAgICAgICAgICAgcmV0dXJuO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIHRoaXMuX2N1cnJlbnRTdGF0ZSA9IE9iamVjdC5hc3NpZ24odGhpcy5fY3VycmVudFN0YXRlLCBfc3RhdGUpO1xyXG4gICAgICAgICAgICB0aGlzLmdyaWRPcHRpb25zLmNvbHVtbkFwaS5zZXRDb2x1bW5TdGF0ZShfc3RhdGUuY29sdW1uU3RhdGUpO1xyXG4gICAgICAgICAgICB0aGlzLmdyaWRPcHRpb25zLmNvbHVtbkFwaS5zZXRQaXZvdE1vZGUoX3N0YXRlLnBpdm90TW9kZSB8fCBmYWxzZSk7XHJcbiAgICAgICAgICAgIHRoaXMuZ3JpZE9wdGlvbnMuY29sdW1uQXBpLnNldENvbHVtbkdyb3VwU3RhdGUoX3N0YXRlLmdyb3VwU3RhdGUgfHwgW10pO1xyXG4gICAgICAgICAgICB0aGlzLl9pc0NoYW5naW5nU3RhdGUgPSBmYWxzZTtcclxuXHJcbiAgICAgICAgICAgIHRpbWVyKDEwMCkuc3Vic2NyaWJlKCgpOiB2b2lkID0+IHtcclxuICAgICAgICAgICAgICAgIHRoaXMuX3NldFBpdm90Q29sdW1ucygpO1xyXG4gICAgICAgICAgICAgICAgdGhpcy5fZXhwYW5kR3JvdXAoKTtcclxuICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgfTtcclxuICAgICAgICBsZXQgY2hlY2sgPSAoKTogYm9vbGVhbiA9PiB7XHJcbiAgICAgICAgICAgIHJldHVybiB0aGlzLmNvbHVtbiAmJiB0aGlzLmNvbHVtbi5sZW5ndGggPiAwO1xyXG4gICAgICAgIH07XHJcbiAgICAgICAgdGhpcy53YWl0KGNoZWNrLCBzZXRTdGF0ZSk7XHJcbiAgICB9XHJcblxyXG4gICAgLyoqXHJcbiAgICAgKiB3YWl0IGZvciBzb21ldGhpbmcgdG8gZmluaXNoIHRoZW4gZG8gc29tZXRoaW5nLCBicmVha3MgYXQgMTAwdGggdG8gcHJldmVudCBpbmZpbml0ZSBsb29wXHJcbiAgICAgKiBwYXJhbSB7SVRhYmxlUGl2b3RTdGF0ZX0gX3N0YXRlXHJcbiAgICAgKiByZXR1cm4ge2FueX1cclxuICAgICAqL1xyXG4gICAgcHJpdmF0ZSB3YWl0KF9jaGVjazogRnVuY3Rpb24sIF9kbzogRnVuY3Rpb24sIF9saW1pdENvdW50ZXIgPSAwKTogYW55IHtcclxuICAgICAgICBpZiAoKF9jaGVjaygpICYmIHRoaXMuX3RhYmxlU2VydmljZS5pc0FwaVJlYWR5KHRoaXMuZ3JpZE9wdGlvbnMpKSB8fCBfbGltaXRDb3VudGVyID09PSAxMDApIHtcclxuICAgICAgICAgICAgaWYgKF9saW1pdENvdW50ZXIgPT09IDEwMCkgY29uc29sZS5sb2coJ1RpbWVvdXQ6IGNoZWNrIGZhaWxzLiBydW5uaW5nJywgX2RvKTtcclxuICAgICAgICAgICAgcmV0dXJuIF9kbygpO1xyXG4gICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgIHRpbWVyKDEwKS5zdWJzY3JpYmUoKCk6IHZvaWQgPT4ge1xyXG4gICAgICAgICAgICAgICAgX2xpbWl0Q291bnRlcisrO1xyXG4gICAgICAgICAgICAgICAgdGhpcy53YWl0KF9jaGVjaywgX2RvLCBfbGltaXRDb3VudGVyKTtcclxuICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX2lzUGl2b3RFbG1FeGlzdChfcGl2b3RFbGVtZW50KTogYm9vbGVhbiB7XHJcbiAgICAgICAgcmV0dXJuIChcclxuICAgICAgICAgICAgdHlwZW9mIF9waXZvdEVsZW1lbnRbJ3Bpdm90J10gIT09ICd1bmRlZmluZWQnICYmXHJcbiAgICAgICAgICAgIF9waXZvdEVsZW1lbnRbJ3Bpdm90J10gIT09IG51bGwgJiZcclxuICAgICAgICAgICAgdHlwZW9mIF9waXZvdEVsZW1lbnRbJ2NvbHVtbi1kcm9wJ10gIT09ICd1bmRlZmluZWQnICYmXHJcbiAgICAgICAgICAgIF9waXZvdEVsZW1lbnRbJ2NvbHVtbi1kcm9wJ10gIT09IG51bGxcclxuICAgICAgICApO1xyXG4gICAgfVxyXG5cclxuICAgIC8qKlxyXG4gICAgICogc2hvdyBwaXZvdCBtb2RlIGNoZWNrYm94IGFuZCBsYWJlbC5cclxuICAgICAqIHdoZW4gcGl2b3QgbW9kZSBpcyBoaWRkZW4sIGFsbCBwaXZvdCBkYXRhIGhhcyB0byBiZSByZXNldC5cclxuICAgICAqIHBhcmFtIHtib29sZWFuID0gdHJ1ZX0gX3Nob3c6IHRydWUgdG8gc2hvdywgZmFsc2UgdG8gaGlkZVxyXG4gICAgICovXHJcbiAgICBwcml2YXRlIF9zaG93UGl2b3RNb2RlKF9zaG93OiBib29sZWFuID0gdHJ1ZSk6IHZvaWQge1xyXG4gICAgICAgIGxldCBzZXRQaXZvdE1vZGUgPSAoKTogdm9pZCA9PiB7XHJcbiAgICAgICAgICAgIGlmIChfc2hvdyA9PT0gdHJ1ZSkge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5fcGl2b3RFbGVtZW50WydwaXZvdCddLmNsYXNzTmFtZSA9IHRoaXMuX3Bpdm90RWxlbWVudFsncGl2b3QnXS5jbGFzc05hbWUucmVwbGFjZSgvIGhpZGRlbi9naSwgJycpO1xyXG4gICAgICAgICAgICAgICAgZm9yIChsZXQgaTogbnVtYmVyID0gMDsgaSA8IHRoaXMuX3Bpdm90RWxlbWVudFsnY29sdW1uLWRyb3AnXS5sZW5ndGg7ICsraSkge1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuX3Bpdm90RWxlbWVudFsnY29sdW1uLWRyb3AnXVtpXS5jbGFzc05hbWUgPSB0aGlzLl9waXZvdEVsZW1lbnRbJ2NvbHVtbi1kcm9wJ11baV0uY2xhc3NOYW1lLnJlcGxhY2UoLyBoaWRkZW4vZ2ksICcnKTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIHRoaXMuX3NldFBpdm90U3RhdGUodGhpcy5jb25maWcucGl2b3QgJiYgdGhpcy5jb25maWcucGl2b3Quc3RhdGUgPyB0aGlzLmNvbmZpZy5waXZvdC5zdGF0ZSA6IHt9KTtcclxuICAgICAgICAgICAgICAgIHJldHVybjtcclxuICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgaWYgKHRoaXMuX3Bpdm90RWxlbWVudFsncGl2b3QnXSAmJlxyXG4gICAgICAgICAgICAgICAgdGhpcy5fcGl2b3RFbGVtZW50WydwaXZvdCddLmNsYXNzTmFtZSAmJlxyXG4gICAgICAgICAgICAgICAgdGhpcy5fcGl2b3RFbGVtZW50WydwaXZvdCddLmNsYXNzTmFtZS5pbmRleE9mKCdoaWRkZW4nKSA9PT0gLTFcclxuICAgICAgICAgICAgKSB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLl9waXZvdEVsZW1lbnRbJ3Bpdm90J10uY2xhc3NOYW1lICs9ICcgaGlkZGVuJztcclxuICAgICAgICAgICAgICAgIGZvciAobGV0IGo6IG51bWJlciA9IDA7IGogPCB0aGlzLl9waXZvdEVsZW1lbnRbJ2NvbHVtbi1kcm9wJ10ubGVuZ3RoOyArK2opIHtcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLl9waXZvdEVsZW1lbnRbJ2NvbHVtbi1kcm9wJ11bal0uY2xhc3NOYW1lICs9ICcgaGlkZGVuJztcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB0aGlzLl9lbmFibGVkUGl2b3RNb2RlKGZhbHNlKTtcclxuXHJcbiAgICAgICAgICAgIHRoaXMuX3NldFBpdm90U3RhdGUoe1xyXG4gICAgICAgICAgICAgICAgJ2NvbHVtblN0YXRlJzogW10sXHJcbiAgICAgICAgICAgICAgICAncGl2b3RNb2RlJzogZmFsc2UsXHJcbiAgICAgICAgICAgICAgICAnZ3JvdXBTdGF0ZSc6IFtdXHJcbiAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICB0aGlzLl9yZXNldFBpdm90Q29sdW1uKCk7XHJcbiAgICAgICAgfTtcclxuICAgICAgICBsZXQgY2hlY2sgPSAoKTogYm9vbGVhbiA9PiB7XHJcbiAgICAgICAgICAgIC8vIGlmICh0aGlzLmNvbmZpZy5waXZvdC50b29scGFuZWwudHlwZSA9PT0gJ25vbmUnIHx8ICF0aGlzLmNvbmZpZy5waXZvdCB8fCAhdGhpcy5jb25maWcucGl2b3QudG9vbHBhbmVsKSByZXR1cm4gdHJ1ZTtcclxuICAgICAgICAgICAgaWYgKHRoaXMuY29uZmlnLnBpdm90ICYmXHJcbiAgICAgICAgICAgICAgICB0aGlzLmNvbmZpZy5waXZvdC50b29scGFuZWwgJiZcclxuICAgICAgICAgICAgICAgIHRoaXMuY29uZmlnLnBpdm90LnRvb2xwYW5lbC50eXBlICYmXHJcbiAgICAgICAgICAgICAgICB0aGlzLmNvbmZpZy5waXZvdC50b29scGFuZWwudHlwZSAhPT0gJ25vbmUnXHJcbiAgICAgICAgICAgICkge1xyXG4gICAgICAgICAgICAgICAgbGV0IGlzUGl2b3RFbG1FeGlzdDogYm9vbGVhbiA9IHRoaXMuX2lzUGl2b3RFbG1FeGlzdCh0aGlzLl9waXZvdEVsZW1lbnQpO1xyXG4gICAgICAgICAgICAgICAgaWYgKGlzUGl2b3RFbG1FeGlzdCA9PT0gdHJ1ZSkgcmV0dXJuIGlzUGl2b3RFbG1FeGlzdDtcclxuXHJcbiAgICAgICAgICAgICAgICBsZXQgZG9tRWxlUXVlcnk6IHN0cmluZyA9ICcjJyArIHRoaXMuZ3JpZElkICsgJy5zdGctdGhlbWUgLmFnLXNpZGUtYmFyJztcclxuICAgICAgICAgICAgICAgIHRoaXMuX3Bpdm90RWxlbWVudFsncGl2b3QnXSA9IHRoaXMuX3Zjci5lbGVtZW50Lm5hdGl2ZUVsZW1lbnQucXVlcnlTZWxlY3Rvcihkb21FbGVRdWVyeSArICcgLmFnLXBpdm90LW1vZGUtcGFuZWwnKTtcclxuICAgICAgICAgICAgICAgIHRoaXMuX3Bpdm90RWxlbWVudFsnY29sdW1uLWRyb3AnXSA9IHRoaXMuX3Zjci5lbGVtZW50Lm5hdGl2ZUVsZW1lbnQucXVlcnlTZWxlY3RvckFsbChkb21FbGVRdWVyeSArICcgLmFnLWNvbHVtbi1kcm9wJyk7XHJcbiAgICAgICAgICAgICAgICByZXR1cm4gdGhpcy5faXNQaXZvdEVsbUV4aXN0KHRoaXMuX3Bpdm90RWxlbWVudCk7XHJcbiAgICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgICAgICByZXR1cm4gdHJ1ZTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH07XHJcbiAgICAgICAgdGhpcy53YWl0KGNoZWNrLCBzZXRQaXZvdE1vZGUpO1xyXG4gICAgfVxyXG5cclxuXHJcbiAgICAvKipcclxuICAgICAqIGhpZGUgYW5kIHNob3cgdG9vbHBhbmVsIChwaXZvdCBtb2RlIHBhbmVsKVxyXG4gICAgICogcGFyYW0ge2Jvb2xlYW59IF9zaG93OiB0cnVlIHRvIHNob3csIGZhbHNlIHRvIGhpZGVcclxuICAgICAqL1xyXG4gICAgcHJpdmF0ZSBfc2hvd1Rvb2xQYW5lbChfc2hvdzogYm9vbGVhbik6IHZvaWQge1xyXG4gICAgICAgIGlmICh0aGlzLl90YWJsZVNlcnZpY2UuaXNBcGlSZWFkeSh0aGlzLmdyaWRPcHRpb25zKSkge1xyXG4gICAgICAgICAgICB0aW1lcigxMCkuc3Vic2NyaWJlKCgpOiB2b2lkID0+IHtcclxuICAgICAgICAgICAgICAgIHRoaXMuZ3JpZE9wdGlvbnMuYXBpLnNob3dUb29sUGFuZWwoX3Nob3cpO1xyXG4gICAgICAgICAgICB9KTtcclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgLyoqXHJcbiAgICAgKiBleHBhbmQgcm93IGdyb3VwIGJhc2Ugb24gdGhlIHN0YXR1cyB0aGF0IHBhc3NlZCBpblxyXG4gICAgICogcGFyYW0ge2Jvb2xlYW59IF9leHBhbmQ6IHRydWUgdG8gZXhwYW5kLCBmYWxzZSB0byBjb2xsYXBzZVxyXG4gICAgICovXHJcbiAgICBwcml2YXRlIF9leHBhbmRHcm91cChfZXhwYW5kPzogYm9vbGVhbik6IHZvaWQge1xyXG4gICAgICAgIGlmICh0eXBlb2YgX2V4cGFuZCA9PT0gJ3VuZGVmaW5lZCcpIHtcclxuICAgICAgICAgICAgX2V4cGFuZCA9IGZhbHNlO1xyXG4gICAgICAgICAgICBpZiAodGhpcy5jb25maWcucGl2b3QgJiYgdGhpcy5jb25maWcucGl2b3Quc3RhdGUgJiYgdGhpcy5jb25maWcucGl2b3Quc3RhdGUuZXhwYW5kR3JvdXApIHtcclxuICAgICAgICAgICAgICAgIF9leHBhbmQgPSB0aGlzLmNvbmZpZy5waXZvdC5zdGF0ZS5leHBhbmRHcm91cDtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgICAgICBpZiAodGhpcy5fdGFibGVTZXJ2aWNlLmlzQXBpUmVhZHkodGhpcy5ncmlkT3B0aW9ucykpIHtcclxuICAgICAgICAgICAgdGltZXIoMTApLnN1YnNjcmliZSgoKTogdm9pZCA9PiB7XHJcbiAgICAgICAgICAgICAgICAoX2V4cGFuZCkgPyB0aGlzLmdyaWRPcHRpb25zLmFwaS5leHBhbmRBbGwoKSA6IHRoaXMuZ3JpZE9wdGlvbnMuYXBpLmNvbGxhcHNlQWxsKCk7XHJcbiAgICAgICAgICAgICAgICB0aGlzLl9waXZvdFJlc2l6ZSgpO1xyXG4gICAgICAgICAgICB9KTtcclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgLyoqXHJcbiAgICAgKiB0dXJuIG9uIGFuZCBvZmYgcGl2b3QgbW9kZVxyXG4gICAgICogSWYgb24sICdDb2x1bW4gTGFiZWwnIHdpbGwgYXBwZWFyXHJcbiAgICAgKiBJZiBvbiwgdGljayBjb2x1bW4gbmFtZSBvbiB0b29scGFuZWwgd2lsbCBhc3NpZ24gY29sdW1uIHRvICdSb3cgR3JvdXAnIC8gJ1ZhbHVlcycgZGVwZW5kcyBvbiBjb2xEZWZcclxuICAgICAqIElmIG9mZiwgdGljayBjb2x1bW4gbmFtZSBvbiB0b29scGFuZWwgd2lsbCB0cmlnZ2VyIGNvbHVtbiBoaWRlIGFuZCBzaG93XHJcbiAgICAgKiBwYXJhbSB7Ym9vbGVhbiA9IGZhbHNlfSBfZW5hYmxlZDogdHJ1ZSB0byBjaGVjaywgZmFsc2UgdG8gdW5jaGVja1xyXG4gICAgICovXHJcbiAgICBwcml2YXRlIF9lbmFibGVkUGl2b3RNb2RlKF9lbmFibGVkOiBib29sZWFuID0gZmFsc2UpOiB2b2lkIHtcclxuICAgICAgICB0aGlzLmdyaWRPcHRpb25zLmNvbHVtbkFwaS5zZXRQaXZvdE1vZGUoX2VuYWJsZWQpO1xyXG4gICAgfVxyXG5cclxuICAgIC8vIFRPRE86IHRvIGJlIHJldmlzaXRcclxuICAgIC8qKlxyXG4gICAgICogc3VwcHJlc3NNb3ZhYmxlQ29sdW1ucyBvbiBwaXZvdENvbHVtbnMgYW5kIHJvd0dyb3VwQ29sdW1uc1xyXG4gICAgICogY29sdW1ucyBvbiBwaXZvdCBtb2RlIGRvZXMgbm90IGxpc3RlbiB0byBjb2xEZWYuc3VwcHJlc3NNb3ZhYmxlQ29sdW1ucyA9IHRydWVcclxuICAgICAqIGhlbmNlIHdlIG5lZWQgdG8gYWNjZXNzIHRoZWlyIHByaXZhdGUgdmFyaWFibGUgbG9ja1Bvc2l0aW9uIGFuZCBsb2NrUGlubmVkIHRvIHN1cHByZXNzIHRoZSBjb2x1bW4gbW92ZW1lbnRcclxuICAgICAqIHBhcmFtIHthbnl9IF9jb2x1bW5zIFtlaXRoZXIgcGFzc2VkIGluIGZyb20gZ3JpZEV2ZW50OiBjb2x1bW4gb3Igd2lsbCBnZXRBbGxEaXNwbGF5ZWRDb2x1bW5zXVxyXG4gICAgICovXHJcbiAgICBwcml2YXRlIF9zZXRQaXZvdENvbHVtbnMoX2NvbHVtbnM/OiBhbnkpOiB2b2lkIHtcclxuICAgICAgICBsZXQgaXNQaW5uZWQ6IGJvb2xlYW4gPSBmYWxzZTtcclxuICAgICAgICBpZiAoIV9jb2x1bW5zKSBfY29sdW1ucyA9IHRoaXMuZ3JpZE9wdGlvbnMuY29sdW1uQXBpLmdldEFsbERpc3BsYXllZENvbHVtbnMoKTtcclxuICAgICAgICBfY29sdW1ucy5mb3JFYWNoKChjb2x1bW46IGFueSkgPT4ge1xyXG4gICAgICAgICAgICB0aGlzLl9zZXRDb2x1bW4oY29sdW1uKTtcclxuICAgICAgICAgICAgbGV0IGNvbHVtbkRlZiA9IGNvbHVtbi5nZXRDb2xEZWYoKTtcclxuICAgICAgICAgICAgaWYgKGNvbHVtbkRlZi5waXZvdFZhbHVlQ29sdW1uKSB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLl9zZXRDb2x1bW4oY29sdW1uRGVmLnBpdm90VmFsdWVDb2x1bW4pXHJcbiAgICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgICAgICBpZiAoY29sdW1uLnBhcmVudCkge1xyXG4gICAgICAgICAgICAgICAgICAgIGlzUGlubmVkID0gdHJ1ZTtcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLl9zZXRDb2x1bW4oY29sdW1uLnBhcmVudCwgZmFsc2UpO1xyXG4gICAgICAgICAgICAgICAgICAgIGNvbHVtbi5wYXJlbnQucGlubmVkID0gJ2xlZnQnO1xyXG4gICAgICAgICAgICAgICAgICAgIGNvbHVtbi5waW5uZWQgPSAnbGVmdCc7XHJcbiAgICAgICAgICAgICAgICAgICAgY29sdW1uRGVmLnBpbm5lZCA9ICdsZWZ0JztcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH0pO1xyXG4gICAgICAgIGlmIChpc1Bpbm5lZCkgdGhpcy5fcmVzaXplQ29sdW1uKHRydWUpO1xyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX3NldENvbHVtbihfY29sdW1uOiBhbnksIF9pc1NldENvbERlZjogYm9vbGVhbiA9IHRydWUpOiB2b2lkIHtcclxuICAgICAgICBpZiAoX2lzU2V0Q29sRGVmKSB7XHJcbiAgICAgICAgICAgIGxldCBjb2x1bW5EZWYgPSBfY29sdW1uLmdldENvbERlZigpO1xyXG4gICAgICAgICAgICBjb2x1bW5EZWYuc3VwcHJlc3NNb3ZhYmxlID0gdGhpcy5fc3VwcHJlc3NNb3ZhYmxlQ29sdW1ucztcclxuICAgICAgICAgICAgY29sdW1uRGVmLmxvY2tQb3NpdGlvbiA9IHRoaXMuX3N1cHByZXNzTW92YWJsZUNvbHVtbnM7XHJcbiAgICAgICAgICAgIGNvbHVtbkRlZi5sb2NrUGlubmVkID0gdGhpcy5fc3VwcHJlc3NNb3ZhYmxlQ29sdW1ucztcclxuICAgICAgICB9XHJcbiAgICAgICAgaWYgKF9jb2x1bW4uc2V0TW92aW5nKSB7XHJcbiAgICAgICAgICAgIF9jb2x1bW4uc2V0TW92aW5nKCF0aGlzLl9zdXBwcmVzc01vdmFibGVDb2x1bW5zKTtcclxuICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICBfY29sdW1uLm1vdmluZyA9ICF0aGlzLl9zdXBwcmVzc01vdmFibGVDb2x1bW5zO1xyXG4gICAgICAgIH1cclxuICAgICAgICBfY29sdW1uLmxvY2tQb3NpdGlvbiA9IHRoaXMuX3N1cHByZXNzTW92YWJsZUNvbHVtbnM7XHJcbiAgICAgICAgX2NvbHVtbi5sb2NrUGlubmVkID0gdGhpcy5fc3VwcHJlc3NNb3ZhYmxlQ29sdW1ucztcclxuICAgIH1cclxuICAgIC8vIFRPRE86IHRvIGJlIHJldmlzaXRcclxuXHJcbiAgICAvLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vL1xyXG4gICAgLy8vIENvbHVtbi9Sb3cvQ29uZmlndXJhdGlvbiBHZW5lcmF0aW9uXHJcbiAgICAvLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vL1xyXG4gICAgcHJpdmF0ZSBfc2V0R3JpZE9wdGlvbnMoX3RhYmxlQ29uZmlnOiBJVGFibGVDb25maWcpOiB2b2lkIHtcclxuICAgICAgICBpZiAoX3RhYmxlQ29uZmlnLmhhc093blByb3BlcnR5KCdzdXBwcmVzc01vdmFibGVDb2x1bW5zJykpIHRoaXMuX3N1cHByZXNzTW92YWJsZUNvbHVtbnMgPSBfdGFibGVDb25maWcuc3VwcHJlc3NNb3ZhYmxlQ29sdW1ucztcclxuICAgICAgICB0aGlzLl9kaXJlY3Rpb24gPSA8J3J0bCcgfCAnbHRyJz50aGlzLl9kb21TdmMuZ2V0RG9jdW1lbnREaXJlY3Rpb24oKTtcclxuXHJcbiAgICAgICAgdGhpcy5ncmlkT3B0aW9ucyA9IHRoaXMuX3RhYmxlU2VydmljZS5nZW5lcmF0ZUdyaWRPcHRpb25zKF90YWJsZUNvbmZpZywgdGhpcy5fZGlyZWN0aW9uKTtcclxuICAgICAgICB0aGlzLmdyaWRPcHRpb25zLmNvbnRleHRbJ2dyaWRJZCddID0gdGhpcy5ncmlkSWQ7XHJcbiAgICAgICAgdGhpcy5ncmlkT3B0aW9ucy5zdXBwcmVzc01vdmFibGVDb2x1bW5zID0gZmFsc2U7XHJcbiAgICAgICAgdGhpcy5ncmlkT3B0aW9ucy5vbkNvbHVtblJvd0dyb3VwQ2hhbmdlZCA9IChwYXJhbXM6IGFueSk6IHZvaWQgPT4ge1xyXG4gICAgICAgICAgICB0aGlzLl9zZXRQaXZvdENvbHVtbnMocGFyYW1zLmNvbHVtbnMpO1xyXG4gICAgICAgICAgICB0aGlzLl9leHBhbmRHcm91cCgpO1xyXG4gICAgICAgIH1cclxuICAgICAgICB0aGlzLl90YWJsZVNlcnZpY2Uuc2V0R3JpZE9wdGlvbnModGhpcy5ncmlkT3B0aW9ucyk7XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfc2V0Q29sdW1uRGVmKF9jb2xEZWZDb25maWc6IEFycmF5PElUYWJsZUNvbHVtbj4pOiB2b2lkIHtcclxuICAgICAgICB0aGlzLl90YWJsZVNlcnZpY2Uuc2V0Q29sdW1uRGVmKF9jb2xEZWZDb25maWcsIHRoaXMuY29uZmlnLCB0aGlzLl9zdXBwcmVzc01vdmFibGVDb2x1bW5zKTtcclxuICAgICAgICB0aGlzLl9yZXNpemVDb2x1bW4oKTtcclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF9lbmFibGVDb2x1bW5Nb3ZhYmxlKF9lbmFibGVkOiBib29sZWFuID0gdHJ1ZSk6IHZvaWQge1xyXG4gICAgICAgIGlmICh0aGlzLl90YWJsZVNlcnZpY2UuaXNBcGlSZWFkeSh0aGlzLmdyaWRPcHRpb25zKSkge1xyXG4gICAgICAgICAgICB0aGlzLl9zdXBwcmVzc01vdmFibGVDb2x1bW5zID0gX2VuYWJsZWQ7XHJcblxyXG4gICAgICAgICAgICB0aGlzLl9zZXRDb2x1bW5EZWYodGhpcy5jb2x1bW4pO1xyXG4gICAgICAgICAgICBpZiAodGhpcy5jb25maWcubG9hZFR5cGUgPT09ICdub3JtYWwnICYmIHRoaXMuY29uZmlnLnBpdm90LnRvb2xwYW5lbC50eXBlID09PSAncGl2b3QnKSB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLl9zZXRQaXZvdFN0YXRlKHRoaXMuX2N1cnJlbnRTdGF0ZSk7XHJcbiAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgIHRoaXMuX3Bpdm90UmVzaXplKCk7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX3NldFJvd0RhdGEoX3Jvd0RhdGE6IEFycmF5PGFueT4sIF9zZXRUb0dyaWRPcHRpb25zOiBib29sZWFuID0gdHJ1ZSk6IHZvaWQge1xyXG4gICAgICAgIC8vIHRoaXMuX3RhYmxlU2VydmljZS51cGRhdGVSb3dEYXRhV2l0aENvbHVtbkNvbmZpZyhfcm93RGF0YSwgdGhpcy5jb2x1bW4sIHRoaXMuZ3JpZElkKTtcclxuICAgICAgICB0aGlzLl90YWJsZVNlcnZpY2UudXBkYXRlUm93RGF0YVdpdGhDb2x1bW4oX3Jvd0RhdGEsIHRoaXMuY29sdW1uLCB0aGlzLmdyaWRJZCwgdGhpcy5ncmlkT3B0aW9ucyk7XHJcblxyXG4gICAgICAgIGlmIChfc2V0VG9HcmlkT3B0aW9ucykge1xyXG4gICAgICAgICAgICB0aGlzLl90YWJsZVNlcnZpY2Uuc2V0Um93RGF0YShfcm93RGF0YSk7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICBpZiAodGhpcy5fdGFibGVTZXJ2aWNlLmlzRW50ZXJwcmlzZU1vZGVsKHRoaXMuY29uZmlnLmxvYWRUeXBlKSAmJiB0aGlzLl90YWJsZVNlcnZpY2UuaXNBcGlSZWFkeSh0aGlzLmdyaWRPcHRpb25zKSkge1xyXG4gICAgICAgICAgICB0aGlzLl9ncmlkUmVhZHlFbnRlcnByaXNlQ3ljbGUoKTtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIHRpbWVyKCkuc3Vic2NyaWJlKCgpOiB2b2lkID0+IHtcclxuICAgICAgICAgICAgdGhpcy5fZ3JpZFNldFJvd0N5Y2xlKCk7XHJcbiAgICAgICAgICAgIHRoaXMuX3NldFRhYmxlQm9yZGVyQm90dG9tKCk7XHJcbiAgICAgICAgfSk7XHJcbiAgICB9XHJcblxyXG4gICAgLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy9cclxuICAgIC8vLyBFdmVudHMgLSBTdWJzY3JpYmVyIC8gT24gZnVuY3Rpb25zXHJcbiAgICAvLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vL1xyXG4gICAgcHJpdmF0ZSBfcHJvY2Vzc0V2ZW50UGFyYW1zPFQ+KF9mcm9tRXZlbnQ6IHN0cmluZywgX2FkZGl0aW9uYWxQYXJhbXM6IFQpOiB2b2lkIHtcclxuICAgICAgICBzd2l0Y2ggKF9mcm9tRXZlbnQpIHtcclxuICAgICAgICAgICAgY2FzZSAnZGF0YXNvdXJjZSc6XHJcbiAgICAgICAgICAgIGNhc2UgJ3NlbGVjdGlvbic6XHJcbiAgICAgICAgICAgIGNhc2UgJ2lucHV0JzpcclxuICAgICAgICAgICAgY2FzZSAnYnV0dG9uJzpcclxuICAgICAgICAgICAgICAgIHRoaXMuX2Jyb2FkY2FzdEV2ZW50UGFyYW1zPFQ+KF9hZGRpdGlvbmFsUGFyYW1zKTtcclxuICAgICAgICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgICAgICBkZWZhdWx0OlxyXG4gICAgICAgICAgICAgICAgY29uc29sZS5lcnJvcignS2RUYWJsZSB3YXJuaW5nOiBObyBzdWNoIGV2ZW50IGZvdW5kIGZvcjogJywgX2Zyb21FdmVudCk7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX2Jyb2FkY2FzdEV2ZW50UGFyYW1zPFQ+KF9wYXJhbXM6IFQpOiB2b2lkIHtcclxuICAgICAgICB0aGlzLl90YWJsZUludEV2ZW50LmtkVGFibGVFdmVudExpc3QodGhpcy5jb25maWcuaWQsIF9wYXJhbXMpO1xyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX2Jyb2FkY2FzdE1vZGVsQ2hhbmdlZEV2ZW50KCk6IHZvaWQge1xyXG4gICAgICAgIHRoaXMuX3RhYmxlSW50RXZlbnQubW9kZWxDaGFuZ2VkKHRoaXMuY29uZmlnLmlkKTtcclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF9zZXR1cFN1YnNjcmlwdGlvbkV2ZW50cygpIHtcclxuICAgICAgICB0aGlzLl9zdWJzY3JpcHRpb25PYmouc2VsZWN0Tm9kZXNTdWIgPSB0aGlzLl90YWJsZUludEV2ZW50Lm9uU2VsZWN0aW9uQ2hhbmdlZCh0aGlzLmNvbmZpZy5pZCkuc3Vic2NyaWJlKChfcm93Tm9kZTogUm93Tm9kZSk6IHZvaWQgPT4ge1xyXG4gICAgICAgICAgICB0aGlzLl91cGRhdGVTZWxlY3Rpb25Ob2Rlcyhfcm93Tm9kZSk7XHJcbiAgICAgICAgfSk7XHJcblxyXG4gICAgICAgIHRoaXMuX3N1YnNjcmlwdGlvbk9iai5ncmlkUXVlc3Rpb25TdWIgPSB0aGlzLl90YWJsZUludEV2ZW50Lm9uSW5wdXRDaGFuZ2VkKHRoaXMuY29uZmlnLmlkKS5zdWJzY3JpYmUoKF9mb3JtUGFyYW1zOiBJVGFibGVGb3JtRW1pdFBhcmFtcyk6IHZvaWQgPT4ge1xyXG4gICAgICAgICAgICB0aGlzLl9wcm9jZXNzSW5wdXRDaGFuZ2VkKF9mb3JtUGFyYW1zKTtcclxuICAgICAgICB9KTtcclxuXHJcbiAgICAgICAgdGhpcy5fc3Vic2NyaXB0aW9uT2JqLnVwZGF0ZUVtaXRSb3cgPSB0aGlzLl90YWJsZUludEV2ZW50Lm9uVXBkYXRlRW1pdFJvd05vZGVzKHRoaXMuY29uZmlnLmlkKS5zdWJzY3JpYmUoKF9kYXRhOiB7IGFjdGlvbjogc3RyaW5nLCByb3dEYXRhOiBhbnkgfSk6IHZvaWQgPT4ge1xyXG4gICAgICAgICAgICBpZiAoX2RhdGEuYWN0aW9uID09PSAnZGVsZXRlJykge1xyXG4gICAgICAgICAgICAgICAgbGV0IHJvd0tleTogc3RyaW5nID0gKHR5cGVvZiB0aGlzLmNvbmZpZy5yb3dJZEtleSAhPT0gJ3VuZGVmaW5lZCcpID8gdGhpcy5jb25maWcucm93SWRLZXkgOiAnaWQnO1xyXG4gICAgICAgICAgICAgICAgdGhpcy5fZGVsZXRlTm9kZUZyb21Sb3dEYXRhKFtfZGF0YS5yb3dEYXRhW3Jvd0tleV1dKTtcclxuICAgICAgICAgICAgICAgIHRoaXMuX2VtaXRJbnB1dFVwZGF0ZUV2ZW50KCk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9KTtcclxuICAgIH1cclxuXHJcbiAgICAvLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vL1xyXG4gICAgLy8vIFNlbGVjdGlvbiAtIENoZWNrYm94IC8gUmFkaW8gZnVuY3Rpb25zXHJcbiAgICAvLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vL1xyXG4gICAgcHJpdmF0ZSBfdXBkYXRlU2VsZWN0aW9uTm9kZXMoX3Jvd05vZGU6IFJvd05vZGUsIF9pc0luaXRpYWw/OiBib29sZWFuKTogdm9pZCB7XHJcbiAgICAgICAgbGV0IHRyaWdnZXJOb2RlOiBzdHJpbmcgPSAodHlwZW9mIF9pc0luaXRpYWwgIT09ICd1bmRlZmluZWQnICYmIF9pc0luaXRpYWwpID8gJ2luaXRpYWwnIDogJ2FsbCc7XHJcbiAgICAgICAgaWYgKHR5cGVvZiBfcm93Tm9kZSAhPT0gJ3VuZGVmaW5lZCcpIHtcclxuICAgICAgICAgICAgdHJpZ2dlck5vZGUgPSBfcm93Tm9kZS5kYXRhLmlkO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgbGV0IHNlbGVjdGlvblBhcmFtczogS2RUYWJsZVNlbGVjdGlvblVwZGF0ZUV2ZW50ID0gbmV3IEtkVGFibGVTZWxlY3Rpb25VcGRhdGVFdmVudCgpO1xyXG5cclxuICAgICAgICBzZWxlY3Rpb25QYXJhbXMudHJpZ2dlck5vZGUgPSB0cmlnZ2VyTm9kZTtcclxuICAgICAgICBzZWxlY3Rpb25QYXJhbXMuc2VsZWN0ZWROb2RlcyA9IHRoaXMuX3RhYmxlU2VydmljZS51cGRhdGVTZWxlY3Rpb25WYWx1ZXModGhpcy5ncmlkT3B0aW9ucy5yb3dEYXRhLCB0aGlzLmNvbmZpZy5zZWxlY3Rpb24udmFsdWUsIHRoaXMuY29uZmlnLnNlbGVjdGlvbi5yZXR1cm5LZXksIHRoaXMuY29uZmlnLmxvYWRUeXBlKTtcclxuICAgICAgICAvLyBzZWxlY3Rpb25QYXJhbXMuc2VsZWN0aW9uID0gKF9yb3dOb2RlLmlzU2VsZWN0ZWQoKSkgPyAnc2VsZWN0ZWQnIDogJ3Vuc2VsZWN0ZWQnO1xyXG5cclxuICAgICAgICB0aGlzLl9wcm9jZXNzRXZlbnRQYXJhbXM8S2RUYWJsZVNlbGVjdGlvblVwZGF0ZUV2ZW50Pignc2VsZWN0aW9uJywgc2VsZWN0aW9uUGFyYW1zKTtcclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF9wcm9jZXNzSW5pdGlhbFNlbGVjdGlvbigpOiB2b2lkIHtcclxuICAgICAgICB0aGlzLl91cGRhdGVTZWxlY3Rpb25Ob2Rlcyh1bmRlZmluZWQsIHRydWUpO1xyXG4gICAgfVxyXG5cclxuICAgIC8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vXHJcbiAgICAvLy8gSW5wdXQgZnVuY3Rpb25zXHJcbiAgICAvLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vL1xyXG4gICAgcHJpdmF0ZSBfcHJvY2Vzc0lucHV0Q2hhbmdlZChfZm9ybVBhcmFtczogSVRhYmxlRm9ybUVtaXRQYXJhbXMpOiB2b2lkIHtcclxuICAgICAgICBsZXQgaW5wdXRQYXJhbXM6IEtkVGFibGVJbnB1dFVwZGF0ZUV2ZW50ID0gbmV3IEtkVGFibGVJbnB1dFVwZGF0ZUV2ZW50KCk7XHJcblxyXG4gICAgICAgIGlucHV0UGFyYW1zLmNvbElkID0gX2Zvcm1QYXJhbXMuY29sSWQ7XHJcbiAgICAgICAgaW5wdXRQYXJhbXMucm93SWQgPSBfZm9ybVBhcmFtcy5yb3dJZDtcclxuICAgICAgICBpbnB1dFBhcmFtcy5xdWVzdGlvbktleSA9IF9mb3JtUGFyYW1zLnF1ZXN0aW9uS2V5O1xyXG4gICAgICAgIGlucHV0UGFyYW1zLnF1ZXN0aW9uID0gX2Zvcm1QYXJhbXMucXVlc3Rpb247XHJcbiAgICAgICAgaW5wdXRQYXJhbXMudmFsdWUgPSBfZm9ybVBhcmFtcy5kYXRhO1xyXG5cclxuICAgICAgICB0aGlzLl9wcm9jZXNzRXZlbnRQYXJhbXM8S2RUYWJsZUlucHV0VXBkYXRlRXZlbnQ+KCdpbnB1dCcsIGlucHV0UGFyYW1zKTtcclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF9lbWl0SW5wdXRVcGRhdGVFdmVudCgpOiB2b2lkIHtcclxuICAgICAgICBsZXQgaW5wdXRQYXJhbXM6IEtkVGFibGVJbnB1dFVwZGF0ZUV2ZW50ID0gbmV3IEtkVGFibGVJbnB1dFVwZGF0ZUV2ZW50KCk7XHJcbiAgICAgICAgdGhpcy5fcHJvY2Vzc0V2ZW50UGFyYW1zPEtkVGFibGVJbnB1dFVwZGF0ZUV2ZW50PignaW5wdXQnLCBpbnB1dFBhcmFtcyk7XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfZGVsZXRlTm9kZUZyb21Sb3dEYXRhKF9kYXRhTGlzdDogQXJyYXk8c3RyaW5nPik6IHZvaWQge1xyXG4gICAgICAgIGxldCByb3dJZEtleTogc3RyaW5nID0gKHR5cGVvZiB0aGlzLmNvbmZpZy5yb3dJZEtleSAhPT0gJ3VuZGVmaW5lZCcpID8gdGhpcy5jb25maWcucm93SWRLZXkgOiAnaWQnO1xyXG5cclxuICAgICAgICBmb3IgKGxldCBpOiBudW1iZXIgPSAwOyBpIDwgX2RhdGFMaXN0Lmxlbmd0aDsgKytpKSB7XHJcbiAgICAgICAgICAgIGZvciAobGV0IGo6IG51bWJlciA9IDA7IGogPCB0aGlzLnJvdy5sZW5ndGg7ICsraikge1xyXG4gICAgICAgICAgICAgICAgaWYgKF9kYXRhTGlzdFtpXS50b1N0cmluZygpID09PSB0aGlzLnJvd1tqXVtyb3dJZEtleV0udG9TdHJpbmcoKSkge1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMucm93LnNwbGljZShqLCAxKTtcclxuICAgICAgICAgICAgICAgICAgICBicmVhaztcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICAvLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vL1xyXG4gICAgLy8vIEVudGVycHJpc2UgZGF0YXNvdXJjZSBmdW5jdGlvbnNcclxuICAgIC8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vXHJcbiAgICBwcml2YXRlIF9jbGVhckRhdGFzb3VyY2UoKTogdm9pZCB7XHJcbiAgICAgICAgaWYgKHRoaXMuX3RhYmxlU2VydmljZS5pc0FwaVJlYWR5KHRoaXMuZ3JpZE9wdGlvbnMpKSB7XHJcbiAgICAgICAgICAgIHRoaXMuZ3JpZE9wdGlvbnMuYXBpLnNldEVudGVycHJpc2VEYXRhc291cmNlKG51bGwpO1xyXG4gICAgICAgICAgICB0aGlzLmdyaWRPcHRpb25zLmFwaS5zZXRGaWx0ZXJNb2RlbChudWxsKTtcclxuICAgICAgICAgICAgdGhpcy5ncmlkT3B0aW9ucy5hcGkuc2V0U29ydE1vZGVsKG51bGwpO1xyXG5cclxuICAgICAgICAgICAgaWYgKHR5cGVvZiB0aGlzLl9zdWJzY3JpcHRpb25PYmouZGF0YXNvdXJjZVN1YiAhPT0gJ3VuZGVmaW5lZCcpIHtcclxuICAgICAgICAgICAgICAgIHRoaXMuX3N1YnNjcmlwdGlvbk9iai5kYXRhc291cmNlU3ViLnVuc3Vic2NyaWJlKCk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfZ2VuZXJhdGVFbnRlcnByaXNlRGF0YXNvdXJjZSgpOiB2b2lkIHtcclxuICAgICAgICBsZXQgZGF0YXNvdXJjZTogSUVudGVycHJpc2VEYXRhc291cmNlID0ge1xyXG4gICAgICAgICAgICBnZXRSb3dzOiAoX3BhcmFtczogSUVudGVycHJpc2VHZXRSb3dzUGFyYW1zKTogdm9pZCA9PiB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLl9zaG93TG9hZGluZ092ZXJsYXkodHJ1ZSk7XHJcblxyXG4gICAgICAgICAgICAgICAgaWYgKHR5cGVvZiB0aGlzLl9zdWJzY3JpcHRpb25PYmouZGF0YXNvdXJjZVN1YiAhPT0gJ3VuZGVmaW5lZCcpIHtcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLl9zdWJzY3JpcHRpb25PYmouZGF0YXNvdXJjZVN1Yi51bnN1YnNjcmliZSgpO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgdGhpcy5fc3Vic2NyaXB0aW9uT2JqLmRhdGFzb3VyY2VTdWIgPSB0aGlzLl9nZW5lcmF0ZURhdGFzb3VyY2VSb3dzKF9wYXJhbXMpLnN1YnNjcmliZSgoX3Jlc3BvbnNlOiBJVGFibGVEYXRhc291cmNlUGFyYW1zKTogdm9pZCA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgX3BhcmFtcy5zdWNjZXNzQ2FsbGJhY2soX3Jlc3BvbnNlLnJvd3MsIF9yZXNwb25zZS50b3RhbCk7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5fc2hvd0xvYWRpbmdPdmVybGF5KGZhbHNlKTtcclxuICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfTtcclxuXHJcbiAgICAgICAgdGhpcy5ncmlkT3B0aW9ucy5hcGkuc2V0RW50ZXJwcmlzZURhdGFzb3VyY2UoZGF0YXNvdXJjZSk7XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfZ2VuZXJhdGVEYXRhc291cmNlUm93cyhfZGF0YXNvdXJjZVBhcmFtczogSUVudGVycHJpc2VHZXRSb3dzUGFyYW1zKTogT2JzZXJ2YWJsZTxJVGFibGVEYXRhc291cmNlUGFyYW1zPiB7XHJcbiAgICAgICAgcmV0dXJuIG5ldyBPYnNlcnZhYmxlPElUYWJsZURhdGFzb3VyY2VQYXJhbXM+KChfb2JzZXJ2ZXI6IFN1YnNjcmliZXI8SVRhYmxlRGF0YXNvdXJjZVBhcmFtcz4pOiB2b2lkID0+IHtcclxuICAgICAgICAgICAgc3dpdGNoICh0aGlzLmNvbmZpZy5sb2FkVHlwZSkge1xyXG4gICAgICAgICAgICAgICAgY2FzZSAnaW5maW5pdGUnOlxyXG4gICAgICAgICAgICAgICAgY2FzZSAnb25lc2hvdCc6XHJcbiAgICAgICAgICAgICAgICAgICAgKDxLZFRhYmxlRW50ZXJwcmlzZVN2Yz50aGlzLl90YWJsZVNlcnZpY2UpLmdlbmVyYXRlRGF0YXNvdXJjZVJvd3MoX2RhdGFzb3VyY2VQYXJhbXMucmVxdWVzdCwgdGhpcy5ncmlkT3B0aW9ucy5yb3dEYXRhLnNsaWNlKCkpLnN1YnNjcmliZSgoX3Jlc3BvbnNlOiBJVGFibGVEYXRhc291cmNlUGFyYW1zKTogdm9pZCA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIF9vYnNlcnZlci5uZXh0KF9yZXNwb25zZSk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIF9vYnNlcnZlci5jb21wbGV0ZSgpO1xyXG4gICAgICAgICAgICAgICAgICAgIH0pO1xyXG5cclxuICAgICAgICAgICAgICAgICAgICBicmVhaztcclxuICAgICAgICAgICAgICAgIGNhc2UgJ3NlcnZlcic6XHJcbiAgICAgICAgICAgICAgICAgICAgbGV0IHNlcnZlclBhcmFtczogS2RUYWJsZURhdGFzb3VyY2VFdmVudCA9IG5ldyBLZFRhYmxlRGF0YXNvdXJjZUV2ZW50KF9kYXRhc291cmNlUGFyYW1zLnJlcXVlc3QsIF9vYnNlcnZlcik7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5fcHJvY2Vzc0V2ZW50UGFyYW1zPEtkVGFibGVEYXRhc291cmNlRXZlbnQ+KCdkYXRhc291cmNlJywgc2VydmVyUGFyYW1zKTtcclxuXHJcbiAgICAgICAgICAgICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgICAgICAgICBkZWZhdWx0OlxyXG4gICAgICAgICAgICAgICAgICAgIGNvbnNvbGUuZXJyb3IoJ0tkVGFibGUgd2FybmluZzogTm8gc3VjaCBsb2FkVHlwZSBmaW5kIGZvcjogJywgdGhpcy5jb25maWcubG9hZFR5cGUpO1xyXG4gICAgICAgICAgICAgICAgICAgIF9vYnNlcnZlci5jb21wbGV0ZSgpO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfSk7XHJcbiAgICB9XHJcblxyXG4gICAgLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy9cclxuICAgIC8vLyBBUEkgZnVuY3Rpb25zXHJcbiAgICAvLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vL1xyXG4gICAgcHJpdmF0ZSBfaW5pdElUYWJsZUFwaSgpOiB2b2lkIHtcclxuICAgICAgICBpZiAodHlwZW9mIHRoaXMuYXBpICE9PSAndW5kZWZpbmVkJykge1xyXG4gICAgICAgICAgICBsZXQgYXBpUGFyYW1zOiBhbnkgPSB7XHJcbiAgICAgICAgICAgICAgICAvLyBncmlkT3B0aW9uczogdGhpcy5ncmlkT3B0aW9ucyxcclxuICAgICAgICAgICAgICAgIGV2ZW50OiB0aGlzLl90YWJsZUludEV2ZW50LFxyXG4gICAgICAgICAgICAgICAgaWQ6IHRoaXMuY29uZmlnLmlkLFxyXG4gICAgICAgICAgICAgICAgcm93czogdGhpcy5yb3csXHJcbiAgICAgICAgICAgICAgICBjb2x1bW5zOiB0aGlzLmNvbHVtblxyXG4gICAgICAgICAgICB9O1xyXG5cclxuICAgICAgICAgICAgdGhpcy5fdGFibGVTZXJ2aWNlLmdlbmVyYXRlZEFwaUZ1bmN0aW9ucyh0aGlzLmFwaSwgYXBpUGFyYW1zKTtcclxuXHJcbiAgICAgICAgICAgIC8vLyBUZW1wIGZpeCB0byBhY2Nlc3MgbG9hZGluZyB2YXJpYWJsZSAvL1xyXG4gICAgICAgICAgICAvKioqKioqKioqIEdlbmVyYWwgQVBJICoqKioqKioqKiovXHJcbiAgICAgICAgICAgIHRoaXMuYXBpLmdlbmVyYWwuc2hvd0xvYWRpbmcgPSAoX3RvZ2dsZTogYm9vbGVhbik6IHZvaWQgPT4ge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5kaXNwbGF5TG9hZGluZyA9IF90b2dnbGU7XHJcbiAgICAgICAgICAgIH07XHJcblxyXG4gICAgICAgICAgICB0aGlzLmFwaS5nZW5lcmFsLnVwZGF0ZUNlbGwgPSAoX3RhYmxlQ2VsbFBhcmFtczogSVRhYmxlQ2VsbFBhcmFtcyk6IHZvaWQgPT4ge1xyXG4gICAgICAgICAgICAgICAgbGV0IHRvVXBkYXRlTm9kZTogQXJyYXk8Um93Tm9kZT4gPSBbXTtcclxuXHJcbiAgICAgICAgICAgICAgICB0aGlzLmdyaWRPcHRpb25zLmFwaS5mb3JFYWNoTm9kZSgoX3Jvd05vZGU6IFJvd05vZGUpOiB2b2lkID0+IHtcclxuICAgICAgICAgICAgICAgICAgICBpZiAodHlwZW9mIF9yb3dOb2RlLmlkICE9PSAndW5kZWZpbmVkJyAmJiBfcm93Tm9kZS5pZCA9PT0gX3RhYmxlQ2VsbFBhcmFtcy5yb3dJZCkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBfcm93Tm9kZS5kYXRhW190YWJsZUNlbGxQYXJhbXMuY29sSWRdID0gX3RhYmxlQ2VsbFBhcmFtcy5kYXRhO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB0b1VwZGF0ZU5vZGUucHVzaChfcm93Tm9kZSk7XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgfSk7XHJcblxyXG4gICAgICAgICAgICAgICAgbGV0IHJlZnJlc2hQYXJhbXM6IHsgcm93Tm9kZXM6IEFycmF5PFJvd05vZGU+LCBjb2x1bW5zOiBBcnJheTxhbnk+IH0gPSB7XHJcbiAgICAgICAgICAgICAgICAgICAgcm93Tm9kZXM6IHRvVXBkYXRlTm9kZSxcclxuICAgICAgICAgICAgICAgICAgICBjb2x1bW5zOiBbX3RhYmxlQ2VsbFBhcmFtcy5jb2xJZF1cclxuICAgICAgICAgICAgICAgIH07XHJcblxyXG4gICAgICAgICAgICAgICAgdGhpcy5ncmlkT3B0aW9ucy5hcGkucmVmcmVzaENlbGxzKHJlZnJlc2hQYXJhbXMpO1xyXG4gICAgICAgICAgICB9O1xyXG5cclxuICAgICAgICAgICAgdGhpcy5hcGkuZ2VuZXJhbC5zZWFyY2hSb3cgPSAoX3NlYXJjaFRleHQ6IHN0cmluZyk6IHZvaWQgPT4ge1xyXG4gICAgICAgICAgICAgICAgaWYgKHRoaXMuY29uZmlnLmxvYWRUeXBlID09PSAnbm9ybWFsJykge1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuZ3JpZE9wdGlvbnMuYXBpLnNldFF1aWNrRmlsdGVyKF9zZWFyY2hUZXh0KTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgICAgIGNvbnNvbGUud2FybignS2RUYWJsZSB3YXJuaW5nOiBRdWljayBmaWx0ZXJpbmcgb2YgZGF0YSBpcyBub3Qgc3VwcG9ydGVkIGZvciBvbmVzaG90L3NlcnZlci9pbmZpbml0ZSBsb2FkVHlwZS4nKTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfTtcclxuXHJcbiAgICAgICAgICAgIHRoaXMuYXBpLmdlbmVyYWwuYWRkUm93cyA9IChfcm93czogQXJyYXk8YW55PiwgX3Njcm9sbFRvVmlzaWJsZTogYm9vbGVhbiA9IGZhbHNlKTogdm9pZCA9PiB7XHJcbiAgICAgICAgICAgICAgICAvKlxyXG4gICAgICAgICAgICAgICAgICAgIGFnLUdyaWQgZGlkIG5vdCBleHBvcnQgUm93RGF0YVRyYW5zYWN0aW9uIGludGVyZmFjZS4gSW50ZXJmYWNlIGFzOlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBhZGQ6IFtdLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcmVtb3ZlOiBbXSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHVwZGF0ZTogW11cclxuICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICovXHJcbiAgICAgICAgICAgICAgICBpZiAodHlwZW9mIHRoaXMuY29uZmlnLmxvYWRUeXBlID09PSAndW5kZWZpbmVkJyB8fCB0aGlzLmNvbmZpZy5sb2FkVHlwZSA9PT0gJ25vcm1hbCcpIHtcclxuICAgICAgICAgICAgICAgICAgICBsZXQgcm93S2V5OiBzdHJpbmcgPSAodHlwZW9mIHRoaXMuY29uZmlnLnJvd0lkS2V5ICE9PSAndW5kZWZpbmVkJykgPyB0aGlzLmNvbmZpZy5yb3dJZEtleSA6ICdpZCc7XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIGZvciAobGV0IGk6IG51bWJlciA9IDA7IGkgPCBfcm93cy5sZW5ndGg7ICsraSkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLnJvdy5wdXNoKF9yb3dzW2ldKTtcclxuICAgICAgICAgICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuX3NldFJvd0RhdGEodGhpcy5yb3csIGZhbHNlKTtcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLmdyaWRPcHRpb25zLmFwaS51cGRhdGVSb3dEYXRhKHsgYWRkOiBfcm93cy5zbGljZSgpIH0pO1xyXG5cclxuICAgICAgICAgICAgICAgICAgICBpZiAoX3Njcm9sbFRvVmlzaWJsZSkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLmdyaWRPcHRpb25zLmFwaS5lbnN1cmVJbmRleFZpc2libGUodGhpcy5ncmlkT3B0aW9ucy5hcGkuZ2V0Um93Tm9kZShfcm93c1swXVtyb3dLZXldLnRvU3RyaW5nKCkpLnJvd0luZGV4KTtcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgICAgICAgICBjb25zb2xlLndhcm4oJ0tkVGFibGUgd2FybmluZzogQVBJIGZ1bmN0aW9uOiBhZGRSb3dzKCkgY2FuIG9ubHkgYmUgdXNlZCBmb3Igbm9ybWFsIGxvYWRUeXBlLicpO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9O1xyXG5cclxuICAgICAgICAgICAgdGhpcy5hcGkuZ2VuZXJhbC5kZWxldGVSb3dzID0gKF9pZDogQXJyYXk8c3RyaW5nIHwgbnVtYmVyPiB8IHN0cmluZyB8IG51bWJlcik6IHZvaWQgPT4ge1xyXG4gICAgICAgICAgICAgICAgaWYgKHR5cGVvZiB0aGlzLmNvbmZpZy5sb2FkVHlwZSA9PT0gJ3VuZGVmaW5lZCcgfHwgdGhpcy5jb25maWcubG9hZFR5cGUgPT09ICdub3JtYWwnKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgbGV0IGRlbGV0ZUlkTGlzdDogQXJyYXk8c3RyaW5nPiA9IFtdO1xyXG5cclxuICAgICAgICAgICAgICAgICAgICBpZiAodHlwZW9mIF9pZCA9PT0gJ3N0cmluZycgfHwgdHlwZW9mIF9pZCA9PT0gJ251bWJlcicpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgZGVsZXRlSWRMaXN0LnB1c2goX2lkLnRvU3RyaW5nKCkpO1xyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgZm9yIChsZXQgaTogbnVtYmVyID0gMDsgaSA8IF9pZC5sZW5ndGg7ICsraSkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgZGVsZXRlSWRMaXN0LnB1c2goX2lkLnRvU3RyaW5nKCkpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgICAgICAgICB0aGlzLl9kZWxldGVOb2RlRnJvbVJvd0RhdGEoZGVsZXRlSWRMaXN0KTtcclxuXHJcbiAgICAgICAgICAgICAgICAgICAgbGV0IGtleTogc3RyaW5nID0gdHlwZW9mIHRoaXMuY29uZmlnLnJvd0lkS2V5ID09PSAndW5kZWZpbmVkJyA/ICdpZCcgOiB0aGlzLmNvbmZpZy5yb3dJZEtleTtcclxuICAgICAgICAgICAgICAgICAgICBsZXQgZGVsZXRlUm93czogQXJyYXk8YW55PiA9IFtdO1xyXG5cclxuICAgICAgICAgICAgICAgICAgICBmb3IgKGxldCBpOiBudW1iZXIgPSAwOyBpIDwgZGVsZXRlSWRMaXN0Lmxlbmd0aDsgKytpKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGRlbGV0ZVJvd3MucHVzaCh7IFtrZXldOiBkZWxldGVJZExpc3RbaV0gfSk7XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgICAgICAgICAvKlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBhZy1HcmlkIGRpZCBub3QgZXhwb3J0IFJvd0RhdGFUcmFuc2FjdGlvbiBpbnRlcmZhY2UuIEludGVyZmFjZSBhczpcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBhZGQ6IFtdLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJlbW92ZTogW10sXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdXBkYXRlOiBbXVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAqL1xyXG5cclxuICAgICAgICAgICAgICAgICAgICBsZXQgdHJhbnNhY3Rpb25PYmo6IHsgYWRkPzogQXJyYXk8YW55PiwgcmVtb3ZlPzogQXJyYXk8YW55PiwgdXBkYXRlPzogQXJyYXk8YW55PiB9ID0ge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICByZW1vdmU6IGRlbGV0ZVJvd3NcclxuICAgICAgICAgICAgICAgICAgICB9O1xyXG5cclxuICAgICAgICAgICAgICAgICAgICB0aGlzLmdyaWRPcHRpb25zLmFwaS51cGRhdGVSb3dEYXRhKHRyYW5zYWN0aW9uT2JqKTtcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLl9lbWl0SW5wdXRVcGRhdGVFdmVudCgpO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgZWxzZSB7XHJcbiAgICAgICAgICAgICAgICAgICAgY29uc29sZS53YXJuKCdLZFRhYmxlIHdhcm5pbmc6IEFQSSBmdW5jdGlvbjogYWRkUm93cygpIGNhbiBvbmx5IGJlIHVzZWQgZm9yIG5vcm1hbCBsb2FkVHlwZS4nKTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfTtcclxuXHJcbiAgICAgICAgICAgIHRoaXMuYXBpLmdlbmVyYWwuc2V0QnV0dG9uRGlzYWJsZWQgPSAoX2J1dHRvblR5cGU6IHN0cmluZywgX3RvRGlzYWJsZWQ6IGJvb2xlYW4pID0+IHtcclxuICAgICAgICAgICAgICAgIGZvciAobGV0IGk6IG51bWJlciA9IDA7IGkgPCB0aGlzLmNvbmZpZy5idXR0b24ubGVuZ3RoOyArK2kpIHtcclxuICAgICAgICAgICAgICAgICAgICBpZiAodGhpcy5jb25maWcuYnV0dG9uW2ldLnR5cGUgPT09IF9idXR0b25UeXBlKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuY29uZmlnLmJ1dHRvbltpXS5kaXNhYmxlZCA9IF90b0Rpc2FibGVkO1xyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfTtcclxuXHJcbiAgICAgICAgICAgIHRoaXMuYXBpLmdlbmVyYWwuZXhwb3J0VG9FeGNlbCA9IChfcGFyYW1zOiBFeGNlbEV4cG9ydFBhcmFtcyk6IHZvaWQgPT4ge1xyXG4gICAgICAgICAgICAgICAgbGV0IGRlZmF1bHRQYXJhbXM6IEV4Y2VsRXhwb3J0UGFyYW1zID0ge1xyXG4gICAgICAgICAgICAgICAgICAgIGZpbGVOYW1lOiAnZmlsZScsXHJcbiAgICAgICAgICAgICAgICAgICAgYWxsQ29sdW1uczogdHJ1ZSxcclxuICAgICAgICAgICAgICAgICAgICBzdXBwcmVzc1RleHRBc0NEQVRBOiB0cnVlLFxyXG4gICAgICAgICAgICAgICAgfTtcclxuICAgICAgICAgICAgICAgIC8vIHhsc3ggb25seSBhbGxvdyBzaGVldCBuYW1lIHRvIGJlIDMxIGNoYXJhY3RlcnMgbG9uZztcclxuICAgICAgICAgICAgICAgIGlmIChfcGFyYW1zLmhhc093blByb3BlcnR5KCdzaGVldE5hbWUnKSkgX3BhcmFtcy5zaGVldE5hbWUgPSBfcGFyYW1zLnNoZWV0TmFtZS5zbGljZSgwLCAzMSk7XHJcbiAgICAgICAgICAgICAgICBsZXQgcGFyYW1zOiBFeGNlbEV4cG9ydFBhcmFtcyA9IE9iamVjdC5hc3NpZ24oe30sIGRlZmF1bHRQYXJhbXMsIF9wYXJhbXMpO1xyXG4gICAgICAgICAgICAgICAgbGV0IGNvbnRlbnQ6IGFueSA9IHRoaXMuZ3JpZE9wdGlvbnMuYXBpLmdldERhdGFBc0V4Y2VsKHBhcmFtcyk7XHJcbiAgICAgICAgICAgICAgICBsZXQgd29ya2Jvb2s6IGFueSA9IFhMU1gucmVhZChjb250ZW50LCB7IHR5cGU6ICdiaW5hcnknIH0pO1xyXG4gICAgICAgICAgICAgICAgbGV0IHhsc3hDb250ZW50OiBhbnkgPSBYTFNYLndyaXRlKHdvcmtib29rLCB7IGJvb2tUeXBlOiAneGxzeCcsIHR5cGU6ICdiYXNlNjQnIH0pO1xyXG4gICAgICAgICAgICAgICAgbGV0IGJsb2JPYmplY3Q6IEJsb2IgPSB0aGlzLl90YWJsZVNlcnZpY2UuYjY0dG9CbG9iKHhsc3hDb250ZW50LCAnYXBwbGljYXRpb24vdm5kLm9wZW54bWxmb3JtYXRzLW9mZmljZWRvY3VtZW50LnNwcmVhZHNoZWV0bWwuc2hlZXQnKTtcclxuICAgICAgICAgICAgICAgIHNhdmVBcyhibG9iT2JqZWN0LCBwYXJhbXMuZmlsZU5hbWUgKyAnLnhsc3gnKTtcclxuICAgICAgICAgICAgfTtcclxuXHJcbiAgICAgICAgICAgIHRoaXMuYXBpLmdlbmVyYWwucmVzaXplQ29sdW1uID0gKF9pc1Jlc2l6ZVRvQ29udGVudDogYm9vbGVhbiA9IGZhbHNlKTogdm9pZCA9PiB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLl9yZXNpemVDb2x1bW4oX2lzUmVzaXplVG9Db250ZW50KTtcclxuICAgICAgICAgICAgfTtcclxuXHJcbiAgICAgICAgICAgIHRoaXMuYXBpLmdlbmVyYWwuZW5hYmxlQ29sdW1uTW92YWJsZSA9IChfZW5hYmxlZDogYm9vbGVhbik6IHZvaWQgPT4ge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5fZW5hYmxlQ29sdW1uTW92YWJsZShfZW5hYmxlZCk7XHJcbiAgICAgICAgICAgIH07XHJcblxyXG4gICAgICAgICAgICAvKioqKioqKioqIFBpdm90IEFQSSAqKioqKioqKioqL1xyXG4gICAgICAgICAgICBpZiAodHlwZW9mICh0aGlzLmFwaS5waXZvdCkgPT09ICd1bmRlZmluZWQnKSB0aGlzLmFwaS5waXZvdCA9IHt9O1xyXG4gICAgICAgICAgICB0aGlzLmFwaS5waXZvdC5hdXRvUmVzaXplID0gKCk6IHZvaWQgPT4ge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5fcGl2b3RSZXNpemUoKTtcclxuICAgICAgICAgICAgfTtcclxuXHJcbiAgICAgICAgICAgIHRoaXMuYXBpLnBpdm90LnNob3dUb29sUGFuZWwgPSAoX3Nob3c6IGJvb2xlYW4pOiB2b2lkID0+IHtcclxuICAgICAgICAgICAgICAgIHRoaXMuX3Nob3dUb29sUGFuZWwoX3Nob3cpO1xyXG4gICAgICAgICAgICB9O1xyXG5cclxuICAgICAgICAgICAgdGhpcy5hcGkucGl2b3QuZXhwYW5kR3JvdXAgPSAoX2V4cGFuZDogYm9vbGVhbik6IHZvaWQgPT4ge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5fZXhwYW5kR3JvdXAoX2V4cGFuZCk7XHJcbiAgICAgICAgICAgIH07XHJcblxyXG4gICAgICAgICAgICB0aGlzLmFwaS5waXZvdC5nZXRQaXZvdFN0YXRlID0gKCk6IElUYWJsZVBpdm90U3RhdGUgPT4ge1xyXG4gICAgICAgICAgICAgICAgcmV0dXJuIHRoaXMuX2dldFBpdm90U3RhdGUoKTtcclxuICAgICAgICAgICAgfTtcclxuXHJcbiAgICAgICAgICAgIHRoaXMuYXBpLnBpdm90LnNldFBpdm90U3RhdGUgPSAoX3N0YXRlOiBJVGFibGVQaXZvdFN0YXRlKTogdm9pZCA9PiB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLl9zZXRDb2x1bW5EZWYodGhpcy5jb2x1bW4pO1xyXG4gICAgICAgICAgICAgICAgdGhpcy5fc2V0UGl2b3RTdGF0ZShfc3RhdGUpO1xyXG4gICAgICAgICAgICB9O1xyXG5cclxuICAgICAgICAgICAgdGhpcy5hcGkucGl2b3QuZW5hYmxlZFBpdm90TW9kZSA9IChfZW5hYmxlZDogYm9vbGVhbik6IHZvaWQgPT4ge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5fZW5hYmxlZFBpdm90TW9kZShfZW5hYmxlZCk7XHJcbiAgICAgICAgICAgIH07XHJcblxyXG4gICAgICAgICAgICB0aGlzLmFwaS5waXZvdC5zaG93UGl2b3RNb2RlID0gKF9zaG93OiBib29sZWFuKTogdm9pZCA9PiB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLl9zaG93UGl2b3RNb2RlKF9zaG93KTtcclxuICAgICAgICAgICAgfTtcclxuXHJcbiAgICAgICAgICAgIC8qKioqKioqKiogSW5wdXQgQVBJICoqKioqKioqKiovXHJcbiAgICAgICAgICAgIHRoaXMuYXBpLmR5bmFtaWNGb3JtLmNsZWFyQWxsRXJyb3IgPSAoKTogdm9pZCA9PiB7XHJcbiAgICAgICAgICAgICAgICBsZXQgdGFibGVDb250ZXh0OiB7IFtrZXk6IHN0cmluZ106IGFueSB9ID0gdGhpcy5ncmlkT3B0aW9ucy5jb250ZXh0W3RoaXMuX3RhYmxlU2VydmljZS5nZXRUYWJsZUNvbnRleHRLZXkoKV07XHJcblxyXG4gICAgICAgICAgICAgICAgZm9yIChsZXQgaXRlbSBpbiB0YWJsZUNvbnRleHQpIHtcclxuICAgICAgICAgICAgICAgICAgICBpZiAodGFibGVDb250ZXh0Lmhhc093blByb3BlcnR5KGl0ZW0pKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGxldCBjb250ZXh0SXRlbTogYW55ID0gdGFibGVDb250ZXh0W2l0ZW1dO1xyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgZm9yIChsZXQgcXVlc3Rpb24gaW4gY29udGV4dEl0ZW0pIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmIChjb250ZXh0SXRlbS5oYXNPd25Qcm9wZXJ0eShxdWVzdGlvbikpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAodHlwZW9mIGNvbnRleHRJdGVtW3F1ZXN0aW9uXS5lcnJvcnMgPT09ICd1bmRlZmluZWQnKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnRleHRJdGVtW3F1ZXN0aW9uXS5lcnJvcnMgPSBbXTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnRleHRJdGVtW3F1ZXN0aW9uXS5lcnJvcnMubGVuZ3RoID0gMDtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfTtcclxuICAgICAgICB9XHJcbiAgICAgICAgZWxzZSB7XHJcbiAgICAgICAgICAgIGNvbnNvbGUud2FybignS2RUYWJsZSB3YXJuaW5nOiBObyBhcGkgcHJvcGVydHkgLyB1bmRlZmluZWQgYXBpIHByb3BlcnR5IGlzIHBhc3NlZCBpbi4nKTtcclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy9cclxuICAgIC8vLyBNaXNjIGZ1bmN0aW9uc1xyXG4gICAgLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy9cclxuICAgIHByaXZhdGUgX2luaXRHcmlkU2VydmljZShfbG9hZFR5cGU6IHN0cmluZyk6IHZvaWQge1xyXG4gICAgICAgIGlmICh0eXBlb2YgX2xvYWRUeXBlID09PSAndW5kZWZpbmVkJyB8fCBfbG9hZFR5cGUgPT09ICdub3JtYWwnKSB7XHJcbiAgICAgICAgICAgIHRoaXMuX3RhYmxlU2VydmljZSA9IG5ldyBLZFRhYmxlTm9ybWFsU3ZjKCk7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICB0aGlzLl90YWJsZVNlcnZpY2UgPSBuZXcgS2RUYWJsZUVudGVycHJpc2VTdmMoKTtcclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfdXBkYXRlR3JpZENvbmZpZyhfZ3JpZENvbmZpZzogSVRhYmxlQ29uZmlnKTogdm9pZCB7XHJcbiAgICAgICAgdGhpcy5ncmlkSWQgPSB0aGlzLl90YWJsZVNlcnZpY2UuZ2V0R3JpZElkKF9ncmlkQ29uZmlnKTtcclxuXHJcbiAgICAgICAgdGhpcy5fdGFibGVTZXJ2aWNlLnVwZGF0ZUdyaWRCdXR0b25zKF9ncmlkQ29uZmlnKTtcclxuICAgICAgICB0aGlzLl90YWJsZVNlcnZpY2UudXBkYXRlU2VsZWN0RGVmYXVsdFZhbHVlKF9ncmlkQ29uZmlnKTtcclxuICAgIH1cclxufVxyXG4iXX0=