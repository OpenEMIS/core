import { Injectable } from '@angular/core';
import { KdTableSvcBase } from './kd-table-svc';
/**
 * -- Documentation for kd-table-normal-svc.ts --
 *
 * Public function:
 *     - Grid Options function
 *         - generateGridOptions (GridOption generation with gridConfig)
 *         - setGridOptions
 *     - Column definition functions
 *         - setColumnDef (Column Definitions based on columnConfig and gridConfig)
 *         - generateColumnDefinitions
 *     - Row data functions
 *         - setRowData (Set the rowData to the grid)
 *
 * Private functions:
 *     - Grid Options function
 *         - _generateConfigOptions (additional GridOption from table config)
 *     - Row height functions
 *         - _getRowHeight
 *         - _calculateRowHeight
 *         - _getQuestionHeight
 */
export class KdTableNormalSvc extends KdTableSvcBase {
    constructor() {
        super(...arguments);
        this._movableColumn = false;
        /************************* End of private functions **************************/
    }
    /***************************** Public functions ******************************/
    ////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// Grid options functions
    ////////////////////////////////////////////////////////////////////////////////////////////////////////
    generateGridOptions(_gridConfig, _direction) {
        let tempGridOptions = super.getDefaultGridOptions(_direction, _gridConfig.rowContentHeight);
        delete tempGridOptions.rowHeight;
        let configOptions = this._generateConfigOptions(_gridConfig);
        Object.assign(tempGridOptions, configOptions);
        return tempGridOptions;
    }
    setGridOptions(_gridOptions) {
        this.gridOptions = _gridOptions;
    }
    ////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// Column definition functions
    ////////////////////////////////////////////////////////////////////////////////////////////////////////
    setColumnDef(_colDefConfig, _gridConfig, _suppressMovableColumns = true) {
        let updatedColumn = this.generateColumnDefinitions(_colDefConfig, _gridConfig, _suppressMovableColumns);
        this.gridOptions.columnDefs = updatedColumn;
        if (super.isApiReady(this.gridOptions)) {
            this.gridOptions.api.setColumnDefs(updatedColumn);
        }
    }
    generateColumnDefinitions(_colDefConfig, _gridConfig, _suppressMovableColumns = true) {
        return super.generateColumnDefinitions(_colDefConfig, _gridConfig, _suppressMovableColumns);
    }
    ////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// Row Data functions
    ////////////////////////////////////////////////////////////////////////////////////////////////////////
    setRowData(_rowData) {
        this.gridOptions.rowData = _rowData;
        if (super.isApiReady(this.gridOptions)) {
            this.gridOptions.api.setRowData(_rowData);
        }
    }
    /************ End of public functions / Start of private functions ***********/
    ////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// Grid options functions
    ////////////////////////////////////////////////////////////////////////////////////////////////////////
    _generateConfigOptions(_config) {
        let sidebarValue = false;
        if ('pivot' in _config) {
            sidebarValue = _config.pivot.state.pivotMode;
        }
        let configOptions = {
            rowModelType: 'clientSide',
            enableSorting: true,
            enableFilter: true,
            getRowHeight: (_params) => {
                return this._getRowHeight(_params);
            },
            sideBar: sidebarValue,
            context: _config.context
        };
        if (typeof _config.rowIdKey !== 'undefined') {
            this.rowKey = _config.rowIdKey;
            configOptions.getRowNodeId = (_data) => {
                if (_data.hasOwnProperty(_config.rowIdKey)) {
                    let id = _data[_config.rowIdKey];
                    if (typeof _data[_config.rowIdKey] === 'number') {
                        id = id.toString();
                    }
                    return id;
                }
                else if (_data.hasOwnProperty('data')) {
                    let id = _data.data[_config.rowIdKey];
                    if (typeof _data.data[_config.rowIdKey] === 'number') {
                        id = id.toString();
                    }
                    return id;
                }
                return '';
            };
        }
        return configOptions;
    }
    ////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// Row Height functions
    ////////////////////////////////////////////////////////////////////////////////////////////////////////
    _getRowHeight(_params) {
        let maxHeight = this.ROW_HEIGHT;
        let allColumns = _params.node.columnApi.getAllColumns();
        let columnHeight = 0;
        for (let i = 0; i < allColumns.length; ++i) {
            columnHeight = this.ROW_HEIGHT;
            if (super.isColDefOfType(allColumns[i].getColDef(), this.GIRD_PARAMS_KEY.input)) {
                let contextKey = super.generateContextKey(_params.context.gridId, allColumns[i].getColDef().colId, _params.node.id);
                if (_params.context[this.TABLE_INPUT_CONTEXT_KEY].hasOwnProperty(contextKey)) {
                    columnHeight = this._calculateRowHeight(_params.context[this.TABLE_INPUT_CONTEXT_KEY][contextKey]);
                }
            }
            if (super.isColDefOfType(allColumns[i].getColDef(), this.GIRD_PARAMS_KEY.image)) {
                const defaultColHeight = 150;
                if (typeof allColumns[i].getColDef().cellRendererParams.params.imageConfig.height !== 'undefined') {
                    columnHeight = allColumns[i].getColDef().cellRendererParams.params.imageConfig.height + this.IMAGE_PADDING;
                }
                else {
                    columnHeight = defaultColHeight + this.IMAGE_PADDING;
                }
            }
            if (columnHeight > maxHeight) {
                maxHeight = columnHeight;
            }
        }
        return maxHeight;
    }
    _calculateRowHeight(_contextData) {
        let height = 0;
        for (let item in _contextData) {
            if (_contextData.hasOwnProperty(item)) {
                height += this._getQuestionHeight(_contextData[item]);
            }
        }
        return height;
    }
    _getQuestionHeight(_tableDataItem) {
        let height = 0;
        if (_tableDataItem.visible) {
            height += 50;
        }
        if (_tableDataItem.visible && _tableDataItem.controlType === 'textarea') {
            height += 70;
        }
        return height;
    }
}
KdTableNormalSvc.decorators = [
    { type: Injectable }
];
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoia2QtdGFibGUtbm9ybWFsLXN2Yy5qcyIsInNvdXJjZVJvb3QiOiJEOi9vcGVuRU1JUy9zdHlsZWd1aWRlL2lvc3RnLW9wZW5lbWlzLXN0eWxlZ3VpZGUvcHJvamVjdHMvb3BlbmVtaXMtc3R5bGVndWlkZS1saWIvc3JjLyIsInNvdXJjZXMiOlsia2QtY29tcG9uZW50cy9rZC1hbmd1bGFyLXRhYmxlL3RhYmxlLXNlcnZpY2VzL2tkLXRhYmxlLW5vcm1hbC1zdmMudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsT0FBTyxFQUFFLFVBQVUsRUFBRSxNQUFNLGVBQWUsQ0FBQztBQVkzQyxPQUFPLEVBQUUsY0FBYyxFQUFFLE1BQU0sZ0JBQWdCLENBQUM7QUFFaEQ7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0dBb0JHO0FBR0gsTUFBTSxPQUFPLGdCQUFpQixTQUFRLGNBQWM7SUFEcEQ7O1FBRVksbUJBQWMsR0FBWSxLQUFLLENBQUM7UUFnS3hDLCtFQUErRTtJQUNuRixDQUFDO0lBaEtHLCtFQUErRTtJQUMvRSx3R0FBd0c7SUFDeEcsMEJBQTBCO0lBQzFCLHdHQUF3RztJQUNqRyxtQkFBbUIsQ0FBQyxXQUF5QixFQUFFLFVBQXlCO1FBQzNFLElBQUksZUFBZSxHQUFnQixLQUFLLENBQUMscUJBQXFCLENBQUMsVUFBVSxFQUFFLFdBQVcsQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDO1FBRXpHLE9BQU8sZUFBZSxDQUFDLFNBQVMsQ0FBQztRQUNqQyxJQUFJLGFBQWEsR0FBZ0IsSUFBSSxDQUFDLHNCQUFzQixDQUFDLFdBQVcsQ0FBQyxDQUFDO1FBRXBFLE1BQU8sQ0FBQyxNQUFNLENBQUMsZUFBZSxFQUFFLGFBQWEsQ0FBQyxDQUFDO1FBRXJELE9BQU8sZUFBZSxDQUFDO0lBQzNCLENBQUM7SUFFTSxjQUFjLENBQUMsWUFBeUI7UUFDM0MsSUFBSSxDQUFDLFdBQVcsR0FBRyxZQUFZLENBQUM7SUFDcEMsQ0FBQztJQUVELHdHQUF3RztJQUN4RywrQkFBK0I7SUFDL0Isd0dBQXdHO0lBQ2pHLFlBQVksQ0FBQyxhQUFrQyxFQUFFLFdBQXlCLEVBQUUsMEJBQW1DLElBQUk7UUFDdEgsSUFBSSxhQUFhLEdBQWtCLElBQUksQ0FBQyx5QkFBeUIsQ0FBQyxhQUFhLEVBQUUsV0FBVyxFQUFFLHVCQUF1QixDQUFDLENBQUM7UUFFdkgsSUFBSSxDQUFDLFdBQVcsQ0FBQyxVQUFVLEdBQUcsYUFBYSxDQUFDO1FBRTVDLElBQUksS0FBSyxDQUFDLFVBQVUsQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFDLEVBQUU7WUFDcEMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxHQUFHLENBQUMsYUFBYSxDQUFDLGFBQWEsQ0FBQyxDQUFDO1NBQ3JEO0lBQ0wsQ0FBQztJQUVNLHlCQUF5QixDQUFDLGFBQWtDLEVBQUUsV0FBeUIsRUFBRSwwQkFBbUMsSUFBSTtRQUNuSSxPQUFPLEtBQUssQ0FBQyx5QkFBeUIsQ0FBQyxhQUFhLEVBQUUsV0FBVyxFQUFFLHVCQUF1QixDQUFDLENBQUM7SUFDaEcsQ0FBQztJQUVELHdHQUF3RztJQUN4RyxzQkFBc0I7SUFDdEIsd0dBQXdHO0lBQ2pHLFVBQVUsQ0FBQyxRQUFvQjtRQUNsQyxJQUFJLENBQUMsV0FBVyxDQUFDLE9BQU8sR0FBRyxRQUFRLENBQUM7UUFDcEMsSUFBSSxLQUFLLENBQUMsVUFBVSxDQUFDLElBQUksQ0FBQyxXQUFXLENBQUMsRUFBRTtZQUNwQyxJQUFJLENBQUMsV0FBVyxDQUFDLEdBQUcsQ0FBQyxVQUFVLENBQUMsUUFBUSxDQUFDLENBQUM7U0FDN0M7SUFDTCxDQUFDO0lBRUQsK0VBQStFO0lBQy9FLHdHQUF3RztJQUN4RywwQkFBMEI7SUFDMUIsd0dBQXdHO0lBQ2hHLHNCQUFzQixDQUFDLE9BQXFCO1FBQ2hELElBQUksWUFBWSxHQUFHLEtBQUssQ0FBQztRQUN6QixJQUFHLE9BQU8sSUFBSSxPQUFPLEVBQUU7WUFDbkIsWUFBWSxHQUFHLE9BQU8sQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLFNBQVMsQ0FBQztTQUNoRDtRQUNELElBQUksYUFBYSxHQUFnQjtZQUM3QixZQUFZLEVBQUUsWUFBWTtZQUMxQixhQUFhLEVBQUUsSUFBSTtZQUNuQixZQUFZLEVBQUUsSUFBSTtZQUNsQixZQUFZLEVBQUUsQ0FBQyxPQUFZLEVBQVUsRUFBRTtnQkFDbkMsT0FBTyxJQUFJLENBQUMsYUFBYSxDQUFDLE9BQU8sQ0FBQyxDQUFDO1lBQ3ZDLENBQUM7WUFDRCxPQUFPLEVBQUcsWUFBWTtZQUN0QixPQUFPLEVBQUUsT0FBTyxDQUFDLE9BQU87U0FDM0IsQ0FBQztRQUVGLElBQUksT0FBTyxPQUFPLENBQUMsUUFBUSxLQUFLLFdBQVcsRUFBRTtZQUN6QyxJQUFJLENBQUMsTUFBTSxHQUFHLE9BQU8sQ0FBQyxRQUFRLENBQUM7WUFFL0IsYUFBYSxDQUFDLFlBQVksR0FBRyxDQUFDLEtBQVUsRUFBVSxFQUFFO2dCQUNoRCxJQUFJLEtBQUssQ0FBQyxjQUFjLENBQUMsT0FBTyxDQUFDLFFBQVEsQ0FBQyxFQUFFO29CQUN4QyxJQUFJLEVBQUUsR0FBVyxLQUFLLENBQUMsT0FBTyxDQUFDLFFBQVEsQ0FBQyxDQUFDO29CQUV6QyxJQUFJLE9BQU8sS0FBSyxDQUFDLE9BQU8sQ0FBQyxRQUFRLENBQUMsS0FBSyxRQUFRLEVBQUU7d0JBQzdDLEVBQUUsR0FBRyxFQUFFLENBQUMsUUFBUSxFQUFFLENBQUM7cUJBQ3RCO29CQUVELE9BQU8sRUFBRSxDQUFDO2lCQUNiO3FCQUFLLElBQUcsS0FBSyxDQUFDLGNBQWMsQ0FBQyxNQUFNLENBQUMsRUFBQztvQkFDbEMsSUFBSSxFQUFFLEdBQVcsS0FBSyxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsUUFBUSxDQUFDLENBQUM7b0JBRTlDLElBQUksT0FBTyxLQUFLLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxRQUFRLENBQUMsS0FBSyxRQUFRLEVBQUU7d0JBQ2xELEVBQUUsR0FBRyxFQUFFLENBQUMsUUFBUSxFQUFFLENBQUM7cUJBQ3RCO29CQUVELE9BQU8sRUFBRSxDQUFDO2lCQUNiO2dCQUVELE9BQU8sRUFBRSxDQUFDO1lBQ2QsQ0FBQyxDQUFDO1NBQ0w7UUFFRCxPQUFPLGFBQWEsQ0FBQztJQUN6QixDQUFDO0lBRUQsd0dBQXdHO0lBQ3hHLHdCQUF3QjtJQUN4Qix3R0FBd0c7SUFDaEcsYUFBYSxDQUFDLE9BQStEO1FBQ2pGLElBQUksU0FBUyxHQUFXLElBQUksQ0FBQyxVQUFVLENBQUM7UUFDeEMsSUFBSSxVQUFVLEdBQXdCLE9BQU8sQ0FBQyxJQUFLLENBQUMsU0FBUyxDQUFDLGFBQWEsRUFBRSxDQUFDO1FBQzlFLElBQUksWUFBWSxHQUFXLENBQUMsQ0FBQztRQUU3QixLQUFLLElBQUksQ0FBQyxHQUFXLENBQUMsRUFBRSxDQUFDLEdBQUcsVUFBVSxDQUFDLE1BQU0sRUFBRSxFQUFFLENBQUMsRUFBRTtZQUNoRCxZQUFZLEdBQUcsSUFBSSxDQUFDLFVBQVUsQ0FBQztZQUUvQixJQUFJLEtBQUssQ0FBQyxjQUFjLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQyxDQUFDLFNBQVMsRUFBRSxFQUFFLElBQUksQ0FBQyxlQUFlLENBQUMsS0FBSyxDQUFDLEVBQUU7Z0JBQzdFLElBQUksVUFBVSxHQUFXLEtBQUssQ0FBQyxrQkFBa0IsQ0FBQyxPQUFPLENBQUMsT0FBTyxDQUFDLE1BQU0sRUFBRSxVQUFVLENBQUMsQ0FBQyxDQUFDLENBQUMsU0FBUyxFQUFFLENBQUMsS0FBSyxFQUFFLE9BQU8sQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDLENBQUM7Z0JBRTVILElBQUksT0FBTyxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsdUJBQXVCLENBQUMsQ0FBQyxjQUFjLENBQUMsVUFBVSxDQUFDLEVBQUU7b0JBQzFFLFlBQVksR0FBRyxJQUFJLENBQUMsbUJBQW1CLENBQUMsT0FBTyxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsdUJBQXVCLENBQUMsQ0FBQyxVQUFVLENBQUMsQ0FBQyxDQUFDO2lCQUN0RzthQUNKO1lBRUQsSUFBSSxLQUFLLENBQUMsY0FBYyxDQUFDLFVBQVUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxTQUFTLEVBQUUsRUFBRSxJQUFJLENBQUMsZUFBZSxDQUFDLEtBQUssQ0FBQyxFQUFFO2dCQUM3RSxNQUFNLGdCQUFnQixHQUFXLEdBQUcsQ0FBQztnQkFFckMsSUFBSSxPQUFPLFVBQVUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxTQUFTLEVBQUUsQ0FBQyxrQkFBa0IsQ0FBQyxNQUFNLENBQUMsV0FBVyxDQUFDLE1BQU0sS0FBSyxXQUFXLEVBQUU7b0JBQy9GLFlBQVksR0FBRyxVQUFVLENBQUMsQ0FBQyxDQUFDLENBQUMsU0FBUyxFQUFFLENBQUMsa0JBQWtCLENBQUMsTUFBTSxDQUFDLFdBQVcsQ0FBQyxNQUFNLEdBQUcsSUFBSSxDQUFDLGFBQWEsQ0FBQztpQkFDOUc7cUJBQ0k7b0JBQ0QsWUFBWSxHQUFHLGdCQUFnQixHQUFHLElBQUksQ0FBQyxhQUFhLENBQUM7aUJBQ3hEO2FBQ0o7WUFFRCxJQUFJLFlBQVksR0FBRyxTQUFTLEVBQUU7Z0JBQzFCLFNBQVMsR0FBRyxZQUFZLENBQUM7YUFDNUI7U0FDSjtRQUVELE9BQU8sU0FBUyxDQUFDO0lBQ3JCLENBQUM7SUFFTyxtQkFBbUIsQ0FBQyxZQUFpQjtRQUN6QyxJQUFJLE1BQU0sR0FBVyxDQUFDLENBQUM7UUFFdkIsS0FBSyxJQUFJLElBQUksSUFBSSxZQUFZLEVBQUU7WUFDM0IsSUFBSSxZQUFZLENBQUMsY0FBYyxDQUFDLElBQUksQ0FBQyxFQUFFO2dCQUNuQyxNQUFNLElBQUksSUFBSSxDQUFDLGtCQUFrQixDQUFDLFlBQVksQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDO2FBQ3pEO1NBQ0o7UUFFRCxPQUFPLE1BQU0sQ0FBQztJQUNsQixDQUFDO0lBRU8sa0JBQWtCLENBQUMsY0FBbUI7UUFDMUMsSUFBSSxNQUFNLEdBQVcsQ0FBQyxDQUFDO1FBRXZCLElBQUksY0FBYyxDQUFDLE9BQU8sRUFBRTtZQUN4QixNQUFNLElBQUksRUFBRSxDQUFDO1NBQ2hCO1FBRUQsSUFBSSxjQUFjLENBQUMsT0FBTyxJQUFJLGNBQWMsQ0FBQyxXQUFXLEtBQUssVUFBVSxFQUFFO1lBQ3JFLE1BQU0sSUFBSSxFQUFFLENBQUM7U0FDaEI7UUFFRCxPQUFPLE1BQU0sQ0FBQztJQUNsQixDQUFDOzs7WUFoS0osVUFBVSIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IEluamVjdGFibGUgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcclxuaW1wb3J0IHtcclxuICAgIEdyaWRPcHRpb25zLFxyXG4gICAgQ29sRGVmLFxyXG4gICAgQ29sdW1uLFxyXG4gICAgUm93Tm9kZSxcclxuICAgIEdyaWRBcGlcclxufSBmcm9tICdhZy1ncmlkLWNvbW11bml0eSc7XHJcbmltcG9ydCB7XHJcbiAgICBJVGFibGVDb2x1bW4sXHJcbiAgICBJVGFibGVDb25maWdcclxufSBmcm9tICcuLi9rZC1hbmd1bGFyLXRhYmxlLWludGVyZmFjZSc7XHJcbmltcG9ydCB7IEtkVGFibGVTdmNCYXNlIH0gZnJvbSAnLi9rZC10YWJsZS1zdmMnO1xyXG5cclxuLyoqXHJcbiAqIC0tIERvY3VtZW50YXRpb24gZm9yIGtkLXRhYmxlLW5vcm1hbC1zdmMudHMgLS1cclxuICpcclxuICogUHVibGljIGZ1bmN0aW9uOlxyXG4gKiAgICAgLSBHcmlkIE9wdGlvbnMgZnVuY3Rpb25cclxuICogICAgICAgICAtIGdlbmVyYXRlR3JpZE9wdGlvbnMgKEdyaWRPcHRpb24gZ2VuZXJhdGlvbiB3aXRoIGdyaWRDb25maWcpXHJcbiAqICAgICAgICAgLSBzZXRHcmlkT3B0aW9uc1xyXG4gKiAgICAgLSBDb2x1bW4gZGVmaW5pdGlvbiBmdW5jdGlvbnNcclxuICogICAgICAgICAtIHNldENvbHVtbkRlZiAoQ29sdW1uIERlZmluaXRpb25zIGJhc2VkIG9uIGNvbHVtbkNvbmZpZyBhbmQgZ3JpZENvbmZpZylcclxuICogICAgICAgICAtIGdlbmVyYXRlQ29sdW1uRGVmaW5pdGlvbnNcclxuICogICAgIC0gUm93IGRhdGEgZnVuY3Rpb25zXHJcbiAqICAgICAgICAgLSBzZXRSb3dEYXRhIChTZXQgdGhlIHJvd0RhdGEgdG8gdGhlIGdyaWQpXHJcbiAqXHJcbiAqIFByaXZhdGUgZnVuY3Rpb25zOlxyXG4gKiAgICAgLSBHcmlkIE9wdGlvbnMgZnVuY3Rpb25cclxuICogICAgICAgICAtIF9nZW5lcmF0ZUNvbmZpZ09wdGlvbnMgKGFkZGl0aW9uYWwgR3JpZE9wdGlvbiBmcm9tIHRhYmxlIGNvbmZpZylcclxuICogICAgIC0gUm93IGhlaWdodCBmdW5jdGlvbnNcclxuICogICAgICAgICAtIF9nZXRSb3dIZWlnaHRcclxuICogICAgICAgICAtIF9jYWxjdWxhdGVSb3dIZWlnaHRcclxuICogICAgICAgICAtIF9nZXRRdWVzdGlvbkhlaWdodFxyXG4gKi9cclxuXHJcbkBJbmplY3RhYmxlKClcclxuZXhwb3J0IGNsYXNzIEtkVGFibGVOb3JtYWxTdmMgZXh0ZW5kcyBLZFRhYmxlU3ZjQmFzZSB7XHJcbiAgICBwcml2YXRlIF9tb3ZhYmxlQ29sdW1uOiBib29sZWFuID0gZmFsc2U7XHJcbiAgICAvKioqKioqKioqKioqKioqKioqKioqKioqKioqKiogUHVibGljIGZ1bmN0aW9ucyAqKioqKioqKioqKioqKioqKioqKioqKioqKioqKiovXHJcbiAgICAvLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vL1xyXG4gICAgLy8vIEdyaWQgb3B0aW9ucyBmdW5jdGlvbnNcclxuICAgIC8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vXHJcbiAgICBwdWJsaWMgZ2VuZXJhdGVHcmlkT3B0aW9ucyhfZ3JpZENvbmZpZzogSVRhYmxlQ29uZmlnLCBfZGlyZWN0aW9uOiAnbHRyJyB8ICdydGwnKTogR3JpZE9wdGlvbnMge1xyXG4gICAgICAgIGxldCB0ZW1wR3JpZE9wdGlvbnM6IEdyaWRPcHRpb25zID0gc3VwZXIuZ2V0RGVmYXVsdEdyaWRPcHRpb25zKF9kaXJlY3Rpb24sIF9ncmlkQ29uZmlnLnJvd0NvbnRlbnRIZWlnaHQpO1xyXG5cclxuICAgICAgICBkZWxldGUgdGVtcEdyaWRPcHRpb25zLnJvd0hlaWdodDtcclxuICAgICAgICBsZXQgY29uZmlnT3B0aW9uczogR3JpZE9wdGlvbnMgPSB0aGlzLl9nZW5lcmF0ZUNvbmZpZ09wdGlvbnMoX2dyaWRDb25maWcpO1xyXG5cclxuICAgICAgICAoPGFueT5PYmplY3QpLmFzc2lnbih0ZW1wR3JpZE9wdGlvbnMsIGNvbmZpZ09wdGlvbnMpO1xyXG5cclxuICAgICAgICByZXR1cm4gdGVtcEdyaWRPcHRpb25zO1xyXG4gICAgfVxyXG5cclxuICAgIHB1YmxpYyBzZXRHcmlkT3B0aW9ucyhfZ3JpZE9wdGlvbnM6IEdyaWRPcHRpb25zKTogdm9pZCB7XHJcbiAgICAgICAgdGhpcy5ncmlkT3B0aW9ucyA9IF9ncmlkT3B0aW9ucztcclxuICAgIH1cclxuXHJcbiAgICAvLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vL1xyXG4gICAgLy8vIENvbHVtbiBkZWZpbml0aW9uIGZ1bmN0aW9uc1xyXG4gICAgLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy9cclxuICAgIHB1YmxpYyBzZXRDb2x1bW5EZWYoX2NvbERlZkNvbmZpZzogQXJyYXk8SVRhYmxlQ29sdW1uPiwgX2dyaWRDb25maWc6IElUYWJsZUNvbmZpZywgX3N1cHByZXNzTW92YWJsZUNvbHVtbnM6IGJvb2xlYW4gPSB0cnVlKTogdm9pZCB7XHJcbiAgICAgICAgbGV0IHVwZGF0ZWRDb2x1bW46IEFycmF5PENvbERlZj4gPSB0aGlzLmdlbmVyYXRlQ29sdW1uRGVmaW5pdGlvbnMoX2NvbERlZkNvbmZpZywgX2dyaWRDb25maWcsIF9zdXBwcmVzc01vdmFibGVDb2x1bW5zKTtcclxuXHJcbiAgICAgICAgdGhpcy5ncmlkT3B0aW9ucy5jb2x1bW5EZWZzID0gdXBkYXRlZENvbHVtbjtcclxuXHJcbiAgICAgICAgaWYgKHN1cGVyLmlzQXBpUmVhZHkodGhpcy5ncmlkT3B0aW9ucykpIHtcclxuICAgICAgICAgICAgdGhpcy5ncmlkT3B0aW9ucy5hcGkuc2V0Q29sdW1uRGVmcyh1cGRhdGVkQ29sdW1uKTtcclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgcHVibGljIGdlbmVyYXRlQ29sdW1uRGVmaW5pdGlvbnMoX2NvbERlZkNvbmZpZzogQXJyYXk8SVRhYmxlQ29sdW1uPiwgX2dyaWRDb25maWc6IElUYWJsZUNvbmZpZywgX3N1cHByZXNzTW92YWJsZUNvbHVtbnM6IGJvb2xlYW4gPSB0cnVlKTogQXJyYXk8Q29sRGVmPiB7XHJcbiAgICAgICAgcmV0dXJuIHN1cGVyLmdlbmVyYXRlQ29sdW1uRGVmaW5pdGlvbnMoX2NvbERlZkNvbmZpZywgX2dyaWRDb25maWcsIF9zdXBwcmVzc01vdmFibGVDb2x1bW5zKTtcclxuICAgIH1cclxuXHJcbiAgICAvLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vL1xyXG4gICAgLy8vIFJvdyBEYXRhIGZ1bmN0aW9uc1xyXG4gICAgLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy9cclxuICAgIHB1YmxpYyBzZXRSb3dEYXRhKF9yb3dEYXRhOiBBcnJheTxhbnk+KTogdm9pZCB7XHJcbiAgICAgICAgdGhpcy5ncmlkT3B0aW9ucy5yb3dEYXRhID0gX3Jvd0RhdGE7XHJcbiAgICAgICAgaWYgKHN1cGVyLmlzQXBpUmVhZHkodGhpcy5ncmlkT3B0aW9ucykpIHtcclxuICAgICAgICAgICAgdGhpcy5ncmlkT3B0aW9ucy5hcGkuc2V0Um93RGF0YShfcm93RGF0YSk7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIC8qKioqKioqKioqKiogRW5kIG9mIHB1YmxpYyBmdW5jdGlvbnMgLyBTdGFydCBvZiBwcml2YXRlIGZ1bmN0aW9ucyAqKioqKioqKioqKi9cclxuICAgIC8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vXHJcbiAgICAvLy8gR3JpZCBvcHRpb25zIGZ1bmN0aW9uc1xyXG4gICAgLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy9cclxuICAgIHByaXZhdGUgX2dlbmVyYXRlQ29uZmlnT3B0aW9ucyhfY29uZmlnOiBJVGFibGVDb25maWcpOiBHcmlkT3B0aW9ucyB7XHJcbiAgICAgICAgbGV0IHNpZGViYXJWYWx1ZSA9IGZhbHNlO1xyXG4gICAgICAgIGlmKCdwaXZvdCcgaW4gX2NvbmZpZykge1xyXG4gICAgICAgICAgICBzaWRlYmFyVmFsdWUgPSBfY29uZmlnLnBpdm90LnN0YXRlLnBpdm90TW9kZTtcclxuICAgICAgICB9XHJcbiAgICAgICAgbGV0IGNvbmZpZ09wdGlvbnM6IEdyaWRPcHRpb25zID0ge1xyXG4gICAgICAgICAgICByb3dNb2RlbFR5cGU6ICdjbGllbnRTaWRlJyxcclxuICAgICAgICAgICAgZW5hYmxlU29ydGluZzogdHJ1ZSxcclxuICAgICAgICAgICAgZW5hYmxlRmlsdGVyOiB0cnVlLFxyXG4gICAgICAgICAgICBnZXRSb3dIZWlnaHQ6IChfcGFyYW1zOiBhbnkpOiBudW1iZXIgPT4ge1xyXG4gICAgICAgICAgICAgICAgcmV0dXJuIHRoaXMuX2dldFJvd0hlaWdodChfcGFyYW1zKTtcclxuICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgc2lkZUJhciA6IHNpZGViYXJWYWx1ZSxcclxuICAgICAgICAgICAgY29udGV4dDogX2NvbmZpZy5jb250ZXh0XHJcbiAgICAgICAgfTtcclxuXHJcbiAgICAgICAgaWYgKHR5cGVvZiBfY29uZmlnLnJvd0lkS2V5ICE9PSAndW5kZWZpbmVkJykge1xyXG4gICAgICAgICAgICB0aGlzLnJvd0tleSA9IF9jb25maWcucm93SWRLZXk7XHJcblxyXG4gICAgICAgICAgICBjb25maWdPcHRpb25zLmdldFJvd05vZGVJZCA9IChfZGF0YTogYW55KTogc3RyaW5nID0+IHtcclxuICAgICAgICAgICAgICAgIGlmIChfZGF0YS5oYXNPd25Qcm9wZXJ0eShfY29uZmlnLnJvd0lkS2V5KSkge1xyXG4gICAgICAgICAgICAgICAgICAgIGxldCBpZDogc3RyaW5nID0gX2RhdGFbX2NvbmZpZy5yb3dJZEtleV07XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIGlmICh0eXBlb2YgX2RhdGFbX2NvbmZpZy5yb3dJZEtleV0gPT09ICdudW1iZXInKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGlkID0gaWQudG9TdHJpbmcoKTtcclxuICAgICAgICAgICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBpZDtcclxuICAgICAgICAgICAgICAgIH1lbHNlIGlmKF9kYXRhLmhhc093blByb3BlcnR5KCdkYXRhJykpe1xyXG4gICAgICAgICAgICAgICAgICAgIGxldCBpZDogc3RyaW5nID0gX2RhdGEuZGF0YVtfY29uZmlnLnJvd0lkS2V5XTtcclxuXHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKHR5cGVvZiBfZGF0YS5kYXRhW19jb25maWcucm93SWRLZXldID09PSAnbnVtYmVyJykge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBpZCA9IGlkLnRvU3RyaW5nKCk7XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgICAgICAgICByZXR1cm4gaWQ7XHJcbiAgICAgICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICAgICAgcmV0dXJuICcnO1xyXG4gICAgICAgICAgICB9O1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgcmV0dXJuIGNvbmZpZ09wdGlvbnM7XHJcbiAgICB9XHJcblxyXG4gICAgLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy9cclxuICAgIC8vLyBSb3cgSGVpZ2h0IGZ1bmN0aW9uc1xyXG4gICAgLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy9cclxuICAgIHByaXZhdGUgX2dldFJvd0hlaWdodChfcGFyYW1zOiB7bm9kZTogUm93Tm9kZSwgZGF0YTogYW55LCBhcGk6IEdyaWRBcGksIGNvbnRleHQ6IGFueX0pOiBudW1iZXIge1xyXG4gICAgICAgIGxldCBtYXhIZWlnaHQ6IG51bWJlciA9IHRoaXMuUk9XX0hFSUdIVDtcclxuICAgICAgICBsZXQgYWxsQ29sdW1uczogQXJyYXk8Q29sdW1uPiA9ICg8YW55Pl9wYXJhbXMubm9kZSkuY29sdW1uQXBpLmdldEFsbENvbHVtbnMoKTtcclxuICAgICAgICBsZXQgY29sdW1uSGVpZ2h0OiBudW1iZXIgPSAwO1xyXG5cclxuICAgICAgICBmb3IgKGxldCBpOiBudW1iZXIgPSAwOyBpIDwgYWxsQ29sdW1ucy5sZW5ndGg7ICsraSkge1xyXG4gICAgICAgICAgICBjb2x1bW5IZWlnaHQgPSB0aGlzLlJPV19IRUlHSFQ7XHJcblxyXG4gICAgICAgICAgICBpZiAoc3VwZXIuaXNDb2xEZWZPZlR5cGUoYWxsQ29sdW1uc1tpXS5nZXRDb2xEZWYoKSwgdGhpcy5HSVJEX1BBUkFNU19LRVkuaW5wdXQpKSB7XHJcbiAgICAgICAgICAgICAgICBsZXQgY29udGV4dEtleTogc3RyaW5nID0gc3VwZXIuZ2VuZXJhdGVDb250ZXh0S2V5KF9wYXJhbXMuY29udGV4dC5ncmlkSWQsIGFsbENvbHVtbnNbaV0uZ2V0Q29sRGVmKCkuY29sSWQsIF9wYXJhbXMubm9kZS5pZCk7XHJcblxyXG4gICAgICAgICAgICAgICAgaWYgKF9wYXJhbXMuY29udGV4dFt0aGlzLlRBQkxFX0lOUFVUX0NPTlRFWFRfS0VZXS5oYXNPd25Qcm9wZXJ0eShjb250ZXh0S2V5KSkge1xyXG4gICAgICAgICAgICAgICAgICAgIGNvbHVtbkhlaWdodCA9IHRoaXMuX2NhbGN1bGF0ZVJvd0hlaWdodChfcGFyYW1zLmNvbnRleHRbdGhpcy5UQUJMRV9JTlBVVF9DT05URVhUX0tFWV1bY29udGV4dEtleV0pO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICBpZiAoc3VwZXIuaXNDb2xEZWZPZlR5cGUoYWxsQ29sdW1uc1tpXS5nZXRDb2xEZWYoKSwgdGhpcy5HSVJEX1BBUkFNU19LRVkuaW1hZ2UpKSB7XHJcbiAgICAgICAgICAgICAgICBjb25zdCBkZWZhdWx0Q29sSGVpZ2h0OiBudW1iZXIgPSAxNTA7XHJcblxyXG4gICAgICAgICAgICAgICAgaWYgKHR5cGVvZiBhbGxDb2x1bW5zW2ldLmdldENvbERlZigpLmNlbGxSZW5kZXJlclBhcmFtcy5wYXJhbXMuaW1hZ2VDb25maWcuaGVpZ2h0ICE9PSAndW5kZWZpbmVkJykge1xyXG4gICAgICAgICAgICAgICAgICAgIGNvbHVtbkhlaWdodCA9IGFsbENvbHVtbnNbaV0uZ2V0Q29sRGVmKCkuY2VsbFJlbmRlcmVyUGFyYW1zLnBhcmFtcy5pbWFnZUNvbmZpZy5oZWlnaHQgKyB0aGlzLklNQUdFX1BBRERJTkc7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgICAgICAgICBjb2x1bW5IZWlnaHQgPSBkZWZhdWx0Q29sSGVpZ2h0ICsgdGhpcy5JTUFHRV9QQURESU5HO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICBpZiAoY29sdW1uSGVpZ2h0ID4gbWF4SGVpZ2h0KSB7XHJcbiAgICAgICAgICAgICAgICBtYXhIZWlnaHQgPSBjb2x1bW5IZWlnaHQ7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIHJldHVybiBtYXhIZWlnaHQ7XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfY2FsY3VsYXRlUm93SGVpZ2h0KF9jb250ZXh0RGF0YTogYW55KTogbnVtYmVyIHtcclxuICAgICAgICBsZXQgaGVpZ2h0OiBudW1iZXIgPSAwO1xyXG5cclxuICAgICAgICBmb3IgKGxldCBpdGVtIGluIF9jb250ZXh0RGF0YSkge1xyXG4gICAgICAgICAgICBpZiAoX2NvbnRleHREYXRhLmhhc093blByb3BlcnR5KGl0ZW0pKSB7XHJcbiAgICAgICAgICAgICAgICBoZWlnaHQgKz0gdGhpcy5fZ2V0UXVlc3Rpb25IZWlnaHQoX2NvbnRleHREYXRhW2l0ZW1dKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgcmV0dXJuIGhlaWdodDtcclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF9nZXRRdWVzdGlvbkhlaWdodChfdGFibGVEYXRhSXRlbTogYW55KTogbnVtYmVyIHtcclxuICAgICAgICBsZXQgaGVpZ2h0OiBudW1iZXIgPSAwO1xyXG5cclxuICAgICAgICBpZiAoX3RhYmxlRGF0YUl0ZW0udmlzaWJsZSkge1xyXG4gICAgICAgICAgICBoZWlnaHQgKz0gNTA7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICBpZiAoX3RhYmxlRGF0YUl0ZW0udmlzaWJsZSAmJiBfdGFibGVEYXRhSXRlbS5jb250cm9sVHlwZSA9PT0gJ3RleHRhcmVhJykge1xyXG4gICAgICAgICAgICBoZWlnaHQgKz0gNzA7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICByZXR1cm4gaGVpZ2h0O1xyXG4gICAgfVxyXG5cclxuICAgIC8qKioqKioqKioqKioqKioqKioqKioqKioqIEVuZCBvZiBwcml2YXRlIGZ1bmN0aW9ucyAqKioqKioqKioqKioqKioqKioqKioqKioqKi9cclxufVxyXG4iXX0=