import { Injectable } from '@angular/core';
import { KdTableAction } from '../table-components/kd-table-action';
import { KdTableCheckboxRadio } from '../table-components/kd-table-checkbox-radio';
import { KdTableInput } from '../table-components/kd-table-input';
import { KdTableImage } from '../table-components/kd-table-image';
import { KdDataSvc } from '../../kd-common/index';
/**
 * -- Documentation for kd-table-svc.ts
 *
 * - Public functions (Usable by both extended services):
 *     - Checking functions
 *         - isApiReady
 *         - hasSelectionAll
 *         - hasInputType
 *         - isInputType
 *         - isEnterpriseModel
 *     - Update functions
 *         - updateSelectDefaultValue
 *         - updateSelectionValues
 *         - updateGridButtons
 *         - updateRowDataWithColumn (Generations of input context in gridOptions.context if input exist)
 *         - generatedApiFunctions (Generation of APIs)
 *     - Misc function
 *         - getGridId
 *         - getImageSizeBy
 *         - getTableContextKey
 *         - getRouterPlaceholderPath (For pathMap of click type router)
 *         - b64toBlob
 *
 * - Protected function:
 *     - Grid Options function
 *         - getDefaultGridOptions
 *     - Column definition functions
 *         - generateColumnDefinitions
 *         - isColDefOfType
 *     - API generation function
 *     - Misc functions
 *         - generateGridId
 *         - generateContextKey
 *         - getImageSizeBy
 *
 * - Private functions:
 *     - Column definition functions
 *         - _generateColDefsFromColConfig (ColDef generation based on column config - checks normal columns, input column and image columns)
 *         - _generateColDefsFromConfig (ColDef generation based on grid config - checks action column and selection column)
 *         - _generateActionColDef (Action)
 *         - _generateCheckboxRadioColDef (Selection)
 *         - _generateImageColDef (Image)
 *         - _generateInputColDef (Input)
 *     - API generation functions
 *         - _generateInputApi (api.dynamicForms)
 *         - _generateGeneralApi (api.general)
 *     - Table input functions
 *         - _generateTableInputContext (Loop all columns and rows and each of the question to generate the context for input columns)
 *     - Selection functions
 *         - _convertDataValueToObject (set to object if config consist of return keys)
 *         - _appendDataValueKey
 *     - Misc functions
 *         - _updateFilterColDef
 *         - _getDefaultColumnConfig
 */
export class KdTableSvcBase {
    constructor() {
        /******************************** Variables *********************************/
        this.ROW_HEIGHT = 150;
        this.CONTEXT_DELIMITER = '~';
        this.TABLE_INPUT_CONTEXT_KEY = 'tableInputContext';
        this.DEFAULT_PAGESIZE = 25;
        this.IMAGE_PADDING = 20;
        this.DEFAULT_GRIDID = 'kd-table-grid';
        this.GIRD_PARAMS_KEY = {
            input: 'inputConfig',
            image: 'imageConfig'
        };
        this.dataSvc = new KdDataSvc();
        this.rowKey = 'id';
        /************************* End of private functions **************************/
    }
    /*************** Public functions (shared for both services) ****************/
    ////////////////////////////////////////////////////////
    /// Checking functions
    ////////////////////////////////////////////////////////
    isApiReady(_gridOptions) {
        if (typeof _gridOptions !== 'undefined' &&
            _gridOptions !== null &&
            typeof _gridOptions.api !== 'undefined') {
            return true;
        }
        return false;
    }
    hasSelectionAll(_gridConfig) {
        if (typeof _gridConfig !== 'undefined' &&
            typeof _gridConfig.selection !== 'undefined' &&
            typeof _gridConfig.selection.type !== 'undefined' &&
            _gridConfig.selection.type === 'all' &&
            _gridConfig.loadType !== 'infinite') {
            return true;
        }
        return false;
    }
    hasInputType(_tableColumn, _type) {
        if (typeof _tableColumn !== 'undefined') {
            for (let i = 0; i < _tableColumn.length; ++i) {
                if (this.isInputType(_tableColumn[i], _type)) {
                    return true;
                }
            }
        }
        return false;
    }
    isInputType(_column, _type) {
        return (typeof _column.type !== 'undefined' && _column.type === _type);
    }
    isEnterpriseModel(_loadType) {
        return (_loadType === 'oneshot' || _loadType === 'infinite' || _loadType === 'server');
    }
    ////////////////////////////////////////////////////////
    /// Selection functions
    ////////////////////////////////////////////////////////
    updateSelectDefaultValue(_gridConfig) {
        if (typeof _gridConfig.selection !== 'undefined') {
            if (typeof _gridConfig.selection.value === 'undefined') {
                _gridConfig.selection.value = [];
            }
            else if (_gridConfig.selection.type === 'single' && _gridConfig.selection.value.length > 1) {
                console.warn('KdTable warning: Single selection type contains more than 1 default values.');
                _gridConfig.selection.value = _gridConfig.selection.value.slice(0, 1);
            }
        }
    }
    /**
     * [updateSelectionValues() - Returns the selected nodes based on the returnKey specify.
     *  If is not specify, array of ids will be return on selection.
     *  Only works for normal, infinite and oneshot loadType.
     *     - Not specify - Return [ 1, 2, 3 ];
     *     - Specify     - Return [ {id: 1, grade: "1" }, {id: 2, grade: "1"}, {id: 3, grade: "2"}]
     * ]
     * _rowData       : [Current provided rowData]
     * _selectedIds   : [Current selected rowData ids]
     * _returnKey     : [List of property keys to return with id]
     * [Generated selection by returnKey]
     */
    updateSelectionValues(_rowData, _selectedIds, _returnKey, _loadType) {
        if (typeof _returnKey === 'undefined' ||
            _returnKey === null ||
            _returnKey.length === 0) {
            return _selectedIds;
        }
        let generatedSelection = [];
        for (let i = 0; i < _rowData.length; i++) {
            let dataItem = _rowData[i];
            let oneItem = {};
            if (_selectedIds.indexOf(dataItem[this.rowKey]) > -1) {
                oneItem[this.rowKey] = dataItem[this.rowKey];
                for (let j = 0; j < _returnKey.length; j++) {
                    if (dataItem.hasOwnProperty(_returnKey[j])) {
                        oneItem[_returnKey[j]] = dataItem[_returnKey[j]];
                    }
                    else if (_returnKey[j].indexOf('.') > 0) {
                        let returnVal = this.dataSvc.getDataValue(dataItem, _returnKey[j]);
                        if (returnVal !== null) {
                            let newItem = Object.assign({}, oneItem);
                            oneItem = this._convertDataValueToObject(newItem, _returnKey[j], returnVal);
                        }
                    }
                }
                generatedSelection.push(oneItem);
            }
        }
        return generatedSelection;
    }
    ////////////////////////////////////////////////////////
    /// Grid Button functions
    ////////////////////////////////////////////////////////
    updateGridButtons(_gridConfig) {
        if (typeof _gridConfig.button === 'undefined') {
            _gridConfig.button = [];
        }
        else if (_gridConfig.button.length > 4) {
            console.warn('KdTable warning: Max 4 buttons for table. Slicing to 4.');
            _gridConfig.button = _gridConfig.button.slice(0, 4);
        }
    }
    ////////////////////////////////////////////////////////
    /// Table Input functions
    ////////////////////////////////////////////////////////
    updateRowDataWithColumn(_rowData, _columnConfig, _gridId, _gridOptions) {
        if (this.hasInputType(_columnConfig, 'input')) {
            if (typeof _gridOptions.context[this.TABLE_INPUT_CONTEXT_KEY] === 'undefined') {
                _gridOptions.context[this.TABLE_INPUT_CONTEXT_KEY] = {};
            }
            let inputContext = this._generateTableInputContext(_columnConfig, _rowData, _gridId);
            _gridOptions.context[this.TABLE_INPUT_CONTEXT_KEY] = Object.assign(_gridOptions.context[this.TABLE_INPUT_CONTEXT_KEY], inputContext);
        }
    }
    ////////////////////////////////////////////////////////
    /// API Generation function
    ////////////////////////////////////////////////////////
    generatedApiFunctions(_gridApi, _apiParams) {
        _gridApi.dynamicForm = this._generateInputApi(_apiParams.id, _apiParams.event);
        _gridApi.general = this._generateGeneralApi(_apiParams.rows);
    }
    ////////////////////////////////////////////////////////
    /// Misc function
    ////////////////////////////////////////////////////////
    getGridId(_gridConfig) {
        if (typeof _gridConfig.id === 'undefined') {
            _gridConfig.id = this.DEFAULT_GRIDID;
        }
        return _gridConfig.id;
    }
    getImageSizeBy(_tableColumn, _dimension) {
        // Default placeholder width 150 + 20 gap
        let width = 150 + this.IMAGE_PADDING;
        if (typeof _tableColumn.config !== 'undefined' &&
            typeof _tableColumn.config.image !== 'undefined' &&
            typeof _tableColumn.config.image[_dimension] !== 'undefined') {
            width = _tableColumn.config.image[_dimension] + this.IMAGE_PADDING;
        }
        return width;
    }
    getTableContextKey() {
        return this.TABLE_INPUT_CONTEXT_KEY;
    }
    getRouterPlaceholderPath(_rowNode, _path) {
        return this.dataSvc.getPlaceholder(_rowNode.data, _path);
    }
    b64toBlob(b64Data, contentType) {
        let sliceSize = 512;
        let byteCharacters = atob(b64Data);
        let byteArrays = [];
        for (let offset = 0; offset < byteCharacters.length; offset += sliceSize) {
            let slice = byteCharacters.slice(offset, offset + sliceSize);
            let byteNumbers = new Array(slice.length);
            for (let i = 0; i < slice.length; i++) {
                byteNumbers[i] = slice.charCodeAt(i);
            }
            let byteArray = new Uint8Array(byteNumbers);
            byteArrays.push(byteArray);
        }
        let blob = new Blob(byteArrays, { type: contentType });
        return blob;
    }
    /********** End of public functions / Start of protected functions **********/
    ////////////////////////////////////////////////////////
    /// Grid Options functions
    ////////////////////////////////////////////////////////
    getDefaultGridOptions(_direction, _rowHeight) {
        this.direction = _direction;
        return {
            rowData: [],
            columnDefs: [],
            enableRtl: _direction === 'rtl',
            headerHeight: 38,
            rowHeight: (typeof _rowHeight !== 'undefined') ? _rowHeight + 20 : this.ROW_HEIGHT,
            // suppressMovableColumns: true,
            suppressDragLeaveHidesColumns: true,
            enableColResize: true,
            suppressContextMenu: true,
            suppressMenuHide: true,
            ensureDomOrder: true,
            suppressPropertyNamesCheck: true,
            // suppressColumnVirtualisation: true,
            animateRows: false,
            rowBuffer: 5,
            getRowNodeId: (_data) => {
                let id = _data.id;
                if (typeof _data.id === 'number') {
                    id = id.toString();
                }
                return id;
            },
            unSortIcon: true,
            icons: {
                filter: '<i class="fa fa-filter"/>',
                sortAscending: '<i class="fa fa-caret-down"/>',
                sortDescending: '<i class="fa fa-caret-up"/>',
                sortUnSort: '<i class="fa fa-sort"/>',
                // groupExpanded: '<i class="fa fa-minus-circle"/>',
                // groupContracted: '<i class="fa fa-plus-circle"/>',
                groupExpanded: '<i class="fa fa-angle-down"/>',
                groupContracted: '<i class="fa fa-angle-right"/>',
                menu: '<i class="fa fa-bars"/>'
            },
            autoGroupColumnDef: {
                icons: {
                    menu: '<i class="fa fa-bar" style="display:none"/>',
                }
            },
            context: {},
            overlayNoRowsTemplate: '<span class="ag-custom-overlay"><i class="fa fa-info-circle fa-lg margin-right10"></i>No record found</span>'
        };
    }
    ////////////////////////////////////////////////////////
    /// Column Definition functions
    ////////////////////////////////////////////////////////
    generateColumnDefinitions(_columnConfig, _gridConfig, _suppressMovableColumns = true) {
        let columnDef = this._generateColDefsFromColConfig(_columnConfig, _gridConfig, _suppressMovableColumns);
        let columnObjects = this._generateColDefsFromConfig(_gridConfig);
        if (columnObjects.hasOwnProperty('action')) {
            columnDef.push(columnObjects.action);
        }
        if (columnObjects.hasOwnProperty('selection')) {
            columnDef.unshift(columnObjects.selection);
        }
        return columnDef;
    }
    isColDefOfType(_colDef, _type) {
        if (typeof _colDef.cellRendererParams !== 'undefined' &&
            typeof _colDef.cellRendererParams.params !== 'undefined' &&
            typeof _colDef.cellRendererParams.params[_type] !== 'undefined') {
            return true;
        }
        return false;
    }
    ////////////////////////////////////////////////////////
    /// Misc function
    ////////////////////////////////////////////////////////
    generateContextKey(_gridId, _columnId, _rowId) {
        return _gridId + this.CONTEXT_DELIMITER + _columnId + this.CONTEXT_DELIMITER + _rowId;
    }
    /********** End of protected functions / Start of private functions **********/
    ////////////////////////////////////////////////////////
    /// ColDef - Column definition functions
    ////////////////////////////////////////////////////////
    _generateColDefsFromColConfig(_columnConfig, _gridConfig, _suppressMovableColumns = true) {
        let columnDef = [];
        for (let i = 0; i < _columnConfig.length; i++) {
            let column = {};
            if (typeof _columnConfig[i] !== 'undefined') {
                let tempColumn = Object.assign(this._getDefaultColumnConfig(), _columnConfig[i]);
                tempColumn.suppressMovable = _suppressMovableColumns;
                switch (tempColumn.type) {
                    case 'input':
                        column = this._generateInputColDef(tempColumn, _gridConfig.id);
                        break;
                    case 'image':
                        column = this._generateImageColDef(tempColumn);
                        break;
                    default:
                        // TEMP fix for pivot
                        // value assignment instead of object direct assignment so to allow application to pass in other coldef
                        column = tempColumn;
                        column.headerName = tempColumn.headerName;
                        column.colId = tempColumn.field;
                        column.field = tempColumn.field;
                        column.cellClass = 'normal-cell ' + tempColumn.class;
                        column.hide = !tempColumn.visible;
                        column.suppressMenu = !tempColumn.filterable;
                        column.suppressSorting = !tempColumn.sortable;
                        column.minWidth = 100;
                        column.suppressMovable = tempColumn.suppressMovable;
                }
                if (tempColumn.filterable) {
                    this._updateFilterColDef(column, tempColumn.filterValue);
                }
            }
            columnDef.push(column);
        }
        return columnDef;
    }
    _generateColDefsFromConfig(_config) {
        let colDefObject = {};
        if (typeof _config !== 'undefined' &&
            typeof _config.action !== 'undefined' &&
            _config.action.enabled) {
            colDefObject.action = this._generateActionColDef(_config.id, _config.action.list, _config.action.name);
        }
        if (typeof _config !== 'undefined' &&
            typeof _config.selection !== 'undefined' &&
            typeof _config.selection.type !== 'undefined') {
            colDefObject.selection = this._generateCheckboxRadioColDef(_config.selection, _config.id);
        }
        return colDefObject;
    }
    ////////////////////////////////////////////////////////
    /// ColDef - Action dropdown functions
    ////////////////////////////////////////////////////////
    _generateActionColDef(_id, _list, _name) {
        return {
            headerName: (typeof _name !== 'undefined') ? _name : 'Action',
            suppressSorting: true,
            suppressFilter: true,
            suppressSizeToFit: true,
            suppressResize: true,
            suppressMenu: true,
            width: 120,
            minWidth: 120,
            maxWidth: 120,
            cellClass: 'dropdown-action',
            colId: 'ag-action',
            cellRendererFramework: KdTableAction,
            cellRendererParams: {
                params: _list,
                gridId: _id
            },
            suppressMovable: true
        };
    }
    ////////////////////////////////////////////////////////
    /// ColDef - Checkbox / Radio functions
    ////////////////////////////////////////////////////////
    _generateCheckboxRadioColDef(_selectionObj, _gridId) {
        /// Have to set the type any as setting as ColDef will has issues
        /// on headerComponentFramework type is wrongly used.
        let checkboxRadioDirection = this.direction === 'ltr' ? 'left' : 'right';
        let tempColDef = {
            suppressSorting: true,
            suppressFilter: true,
            suppressSizeToFit: true,
            suppressMenu: true,
            suppressResize: true,
            width: 50,
            minWidth: 50,
            maxWidth: 50,
            cellClass: 'ag-default ag-checkbox-radio',
            pinned: checkboxRadioDirection,
            colId: (_selectionObj.type === 'single') ? 'radio' : 'checkbox',
            cellRendererFramework: KdTableCheckboxRadio,
            cellRendererParams: {
                params: {
                    inputType: (_selectionObj.type === 'single') ? 'radio' : 'checkbox',
                    default: _selectionObj.value,
                    gridId: _gridId
                }
            },
            suppressMovable: true
        };
        if (_selectionObj.type === 'all') {
            tempColDef.headerComponentFramework = KdTableCheckboxRadio;
            tempColDef.headerComponentParams = {
                params: {
                    default: _selectionObj.value,
                    gridId: _gridId
                }
            };
        }
        return tempColDef;
    }
    ////////////////////////////////////////////////////////
    /// ColDef - Table Image functions
    ////////////////////////////////////////////////////////
    _generateImageColDef(_tempColumn) {
        let width = this.getImageSizeBy(_tempColumn, 'width');
        return {
            headerName: _tempColumn.headerName,
            field: _tempColumn.field,
            colId: _tempColumn.field,
            suppressSorting: true,
            suppressFilter: true,
            suppressMenu: true,
            suppressResize: true,
            hide: !_tempColumn.visible,
            minWidth: width,
            maxWidth: width,
            cellClass: _tempColumn.class,
            cellRendererFramework: KdTableImage,
            cellRendererParams: {
                params: {
                    [this.GIRD_PARAMS_KEY.image]: _tempColumn.config.image,
                }
            },
            suppressMovable: _tempColumn.suppressMovable
        };
    }
    ////////////////////////////////////////////////////////
    /// ColDef - Table Input functions
    ////////////////////////////////////////////////////////
    _generateInputColDef(_tempColumn, _gridId) {
        return {
            headerName: _tempColumn.headerName,
            field: _tempColumn.field,
            suppressSorting: true,
            suppressFilter: true,
            suppressMenu: true,
            minWidth: 250,
            hide: !_tempColumn.visible,
            cellClass: _tempColumn.class,
            colId: _tempColumn.field,
            cellRendererFramework: KdTableInput,
            cellRendererParams: {
                params: {
                    [this.GIRD_PARAMS_KEY.input]: _tempColumn.config,
                    gridId: _gridId,
                    contextKey: this.TABLE_INPUT_CONTEXT_KEY
                }
            },
            suppressMovable: _tempColumn.suppressMovable
        };
    }
    ////////////////////////////////////////////////////////
    /// API generation functions
    ////////////////////////////////////////////////////////
    _generateInputApi(_gridId, _kdTableIntEvent) {
        return {
            getProperty: (_tableParams) => {
                let eventString = this.generateContextKey(_gridId, _tableParams.colId, _tableParams.rowId);
                return this.gridOptions.context.tableIndexContext[eventString][_tableParams.questionKey][_tableParams.property];
            },
            setProperty: (_tableParams) => {
                let eventString = this.generateContextKey(_gridId, _tableParams.colId, _tableParams.rowId);
                if (typeof this.gridOptions.context.tableInputContext[eventString] !== 'undefined') {
                    this.gridOptions.context.tableInputContext[eventString][_tableParams.questionKey][_tableParams.property] = _tableParams.data;
                }
                let rowNode = this.gridOptions.api.getRowNode(_tableParams.rowId.toString());
                if (_tableParams.property === 'visible') {
                    rowNode.setRowHeight(undefined);
                    /// Issues - Calling this api onRowHeightChanged causing the current input cell to lose focus
                    this.gridOptions.api.onRowHeightChanged();
                }
                if (_tableParams.property === 'value') {
                    rowNode.data[_tableParams.colId][_tableParams.questionKey] = _tableParams.data;
                }
            }
        };
    }
    _generateGeneralApi(_row) {
        return {
            getCurrentRows: () => {
                return _row.slice();
            },
            resetRowHeight: () => {
                this.gridOptions.api.resetRowHeights();
            },
            setColumnVisible: (_colId, _visible) => {
                this.gridOptions.columnApi.setColumnVisible(_colId, _visible);
            }
        };
    }
    ////////////////////////////////////////////////////////
    /// Table Input functions
    ////////////////////////////////////////////////////////
    /**
     * [_generateTableInputContext
     *     Generate the input configurations and values to the context of the gridOptions.
     *     All input configurations will be stored in tableInputContext (gridOptions.context.tableInputContext)
     *     Structure is as follows:
     *         delimiter: ~
     *         contextKey: [gridId][delimiter][columnId][delimiter][rowId]
     *             (e.g. tableForm~inputColumn~1)
     *         question: {
     *             questionKey: question configurations,
     *             questionKey: question configurations
     *         }
     *             (e.g. {
     *                 inputKey: {
     *                     controlType: 'text',
     *                     key: 'inputKey',
     *                     visible: true,
     *                     disabled: false,
     *                     value: 'Text'
     *                 },
     *                 dropdownKey: {
     *                     controlType: 'dropdown',
     *                     key: 'dropdownKey',
     *                     visible: true,
     *                     value: '1',
     *                     options: [
     *                         {
     *                             key: '',
     *                             value: '-- Please select --'
     *                         },
     *                         {
     *                             key: '1',
     *                             value: 'Female'
     *                         },
     *                         {
     *                             key: '2',
     *                             value: 'Male'
     *                         }
     *                     ]
     *                 }
     *             })
     *
     *
     *         context.tableInputContext[contextKey] = question
     * ]
     * _column    : [Column configurations]
     * _row       : [Row data]
     * _gridId    : [Grid ID]
     */
    _generateTableInputContext(_column, _row, _gridId) {
        let tableInputContext = {};
        for (let i = 0; i < _column.length; ++i) {
            if (this.isInputType(_column[i], 'input')) {
                let currentColumn = _column[i];
                let currentColumnId = currentColumn.field;
                for (let j = 0; j < _row.length; ++j) {
                    if (typeof _row[j][this.rowKey] !== 'undefined') {
                        let contextObject = {};
                        // console.log('-------------------------------------------');
                        // console.log('currentColumn - ', currentColumn);
                        // console.log('currentColumnId - ', currentColumnId);
                        // console.log('_row[j] - ', _row[j]);
                        // Set the row data with the column key if is not defined
                        if (typeof _row[j][currentColumnId] === 'undefined') {
                            _row[j][currentColumnId] = {};
                        }
                        // Set the input to the contextObject
                        if (typeof currentColumn.config !== 'undefined' && typeof currentColumn.config.input !== 'undefined') {
                            let processInputData = (currentColumn.config.input instanceof Array) ? currentColumn.config.input : [currentColumn.config.input];
                            let rowColumnData = _row[j][currentColumnId];
                            for (let k = 0; k < processInputData.length; ++k) {
                                // Set the row data input key value if no input key of the column is defined
                                if (typeof rowColumnData[processInputData[k].key] === 'undefined') {
                                    rowColumnData[processInputData[k].key] = '';
                                }
                                contextObject[processInputData[k].key] = Object.assign({}, processInputData[k]);
                                contextObject[processInputData[k].key].value = rowColumnData[processInputData[k].key];
                            }
                        }
                        else {
                            console.error('KdTable error - Column specify as input but no config passed in. No input will be generated.');
                        }
                        let contextKey = this.generateContextKey(_gridId, currentColumnId, _row[j][this.rowKey]);
                        tableInputContext[contextKey] = Object.assign({}, contextObject);
                    }
                    else {
                        console.error('KdTable error - Row passed in with no rowKey (' + this.rowKey + '). Input cell component requires rowKey to generate.');
                    }
                }
            }
        }
        return tableInputContext;
    }
    ////////////////////////////////////////////////////////
    /// Selection function - Return value functions
    ////////////////////////////////////////////////////////
    /**
     * [_convertDataValueToObject - Convert return from dot separated to object value. Example:
     *     - From: "instutition_id.instutition_name": "Anderson Primary School";
     *     - To  : instutition_id: {
     *                 instutition_name:"Anderson Primary School"
     *             };
     * ]
     * _currentItem    : [Current selection key]
     * _objKey         : [Dot separated object keys]
     * _value          : [Data value for the object]
     *
     */
    _convertDataValueToObject(_currentItem, _objKey, _value, _separator = '.') {
        let objectKeyArr = _objKey.split(_separator);
        return this._appendDataValueKey(objectKeyArr, _currentItem, _value);
    }
    _appendDataValueKey(_key, _currentObj, _value) {
        if (_key.length > 0) {
            let currentKey = _key[0];
            if (typeof _currentObj[currentKey] === 'undefined') {
                _currentObj[currentKey] = {};
            }
            _key.shift();
            _currentObj[currentKey] = this._appendDataValueKey(_key, _currentObj[currentKey], _value);
        }
        else {
            _currentObj = _value;
        }
        return _currentObj;
    }
    ////////////////////////////////////////////////////////
    /// Misc functions
    ////////////////////////////////////////////////////////
    _updateFilterColDef(_colDef, _filterVal) {
        _colDef.menuTabs = ['filterMenuTab'];
        _colDef.filter = 'agSetColumnFilter';
        _colDef.filterParams = {
            newRowsAction: 'keep',
            cellHeight: 30,
            selectAllOnMiniFilter: true
        };
        if (typeof _filterVal !== 'undefined') {
            _colDef.filterParams.values = _filterVal;
        }
    }
    _getDefaultColumnConfig() {
        return {
            sortable: false,
            filterable: false,
            visible: true,
        };
    }
}
KdTableSvcBase.decorators = [
    { type: Injectable }
];
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoia2QtdGFibGUtc3ZjLmpzIiwic291cmNlUm9vdCI6IkQ6L29wZW5FTUlTL3N0eWxlZ3VpZGUvaW9zdGctb3BlbmVtaXMtc3R5bGVndWlkZS9wcm9qZWN0cy9vcGVuZW1pcy1zdHlsZWd1aWRlLWxpYi9zcmMvIiwic291cmNlcyI6WyJrZC1jb21wb25lbnRzL2tkLWFuZ3VsYXItdGFibGUvdGFibGUtc2VydmljZXMva2QtdGFibGUtc3ZjLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBLE9BQU8sRUFBRSxVQUFVLEVBQUUsTUFBTSxlQUFlLENBQUM7QUFtQjNDLE9BQU8sRUFBRSxhQUFhLEVBQUUsTUFBTSxxQ0FBcUMsQ0FBQztBQUNwRSxPQUFPLEVBQUUsb0JBQW9CLEVBQUUsTUFBTSw2Q0FBNkMsQ0FBQztBQUNuRixPQUFPLEVBQUUsWUFBWSxFQUFFLE1BQU0sb0NBQW9DLENBQUM7QUFDbEUsT0FBTyxFQUFFLFlBQVksRUFBRSxNQUFNLG9DQUFvQyxDQUFDO0FBSWxFLE9BQU8sRUFBRSxTQUFTLEVBQUUsTUFBTSx1QkFBdUIsQ0FBQztBQUVsRDs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0dBc0RHO0FBR0gsTUFBTSxPQUFnQixjQUFjO0lBRHBDO1FBRUksOEVBQThFO1FBQ3JFLGVBQVUsR0FBVyxHQUFHLENBQUM7UUFDekIsc0JBQWlCLEdBQVcsR0FBRyxDQUFDO1FBQ2hDLDRCQUF1QixHQUFXLG1CQUFtQixDQUFDO1FBQ3RELHFCQUFnQixHQUFXLEVBQUUsQ0FBQztRQUM5QixrQkFBYSxHQUFXLEVBQUUsQ0FBQztRQUMzQixtQkFBYyxHQUFXLGVBQWUsQ0FBQztRQUN6QyxvQkFBZSxHQUE4QjtZQUNsRCxLQUFLLEVBQUUsYUFBYTtZQUNwQixLQUFLLEVBQUUsYUFBYTtTQUN2QixDQUFDO1FBRVEsWUFBTyxHQUFjLElBQUksU0FBUyxFQUFFLENBQUM7UUFHckMsV0FBTSxHQUFXLElBQUksQ0FBQztRQStyQmhDLCtFQUErRTtJQUNuRixDQUFDO0lBOXJCRyw4RUFBOEU7SUFDOUUsd0RBQXdEO0lBQ3hELHNCQUFzQjtJQUN0Qix3REFBd0Q7SUFDakQsVUFBVSxDQUFDLFlBQXlCO1FBQ3ZDLElBQUksT0FBTyxZQUFZLEtBQUssV0FBVztZQUNuQyxZQUFZLEtBQUssSUFBSTtZQUNyQixPQUFPLFlBQVksQ0FBQyxHQUFHLEtBQUssV0FBVyxFQUFFO1lBQ3pDLE9BQU8sSUFBSSxDQUFDO1NBQ2Y7UUFDRCxPQUFPLEtBQUssQ0FBQztJQUNqQixDQUFDO0lBRU0sZUFBZSxDQUFDLFdBQXlCO1FBQzVDLElBQUksT0FBTyxXQUFXLEtBQUssV0FBVztZQUNsQyxPQUFPLFdBQVcsQ0FBQyxTQUFTLEtBQUssV0FBVztZQUM1QyxPQUFPLFdBQVcsQ0FBQyxTQUFTLENBQUMsSUFBSSxLQUFLLFdBQVc7WUFDakQsV0FBVyxDQUFDLFNBQVMsQ0FBQyxJQUFJLEtBQUssS0FBSztZQUNwQyxXQUFXLENBQUMsUUFBUSxLQUFLLFVBQVUsRUFBRTtZQUNyQyxPQUFPLElBQUksQ0FBQztTQUNmO1FBRUQsT0FBTyxLQUFLLENBQUM7SUFDakIsQ0FBQztJQUVNLFlBQVksQ0FBQyxZQUFpQyxFQUFFLEtBQWE7UUFDaEUsSUFBSSxPQUFPLFlBQVksS0FBSyxXQUFXLEVBQUU7WUFDckMsS0FBSyxJQUFJLENBQUMsR0FBVyxDQUFDLEVBQUUsQ0FBQyxHQUFHLFlBQVksQ0FBQyxNQUFNLEVBQUUsRUFBRSxDQUFDLEVBQUU7Z0JBQ2xELElBQUksSUFBSSxDQUFDLFdBQVcsQ0FBQyxZQUFZLENBQUMsQ0FBQyxDQUFDLEVBQUUsS0FBSyxDQUFDLEVBQUU7b0JBQzFDLE9BQU8sSUFBSSxDQUFDO2lCQUNmO2FBQ0o7U0FDSjtRQUVELE9BQU8sS0FBSyxDQUFDO0lBQ2pCLENBQUM7SUFFTSxXQUFXLENBQUMsT0FBcUIsRUFBRSxLQUFhO1FBQ25ELE9BQU8sQ0FBQyxPQUFPLE9BQU8sQ0FBQyxJQUFJLEtBQUssV0FBVyxJQUFJLE9BQU8sQ0FBQyxJQUFJLEtBQUssS0FBSyxDQUFDLENBQUM7SUFDM0UsQ0FBQztJQUVNLGlCQUFpQixDQUFDLFNBQWlCO1FBQ3RDLE9BQU8sQ0FBQyxTQUFTLEtBQUssU0FBUyxJQUFJLFNBQVMsS0FBSyxVQUFVLElBQUksU0FBUyxLQUFLLFFBQVEsQ0FBQyxDQUFDO0lBQzNGLENBQUM7SUFFRCx3REFBd0Q7SUFDeEQsdUJBQXVCO0lBQ3ZCLHdEQUF3RDtJQUNqRCx3QkFBd0IsQ0FBQyxXQUF5QjtRQUNyRCxJQUFJLE9BQU8sV0FBVyxDQUFDLFNBQVMsS0FBSyxXQUFXLEVBQUU7WUFDOUMsSUFBSSxPQUFPLFdBQVcsQ0FBQyxTQUFTLENBQUMsS0FBSyxLQUFLLFdBQVcsRUFBRTtnQkFDcEQsV0FBVyxDQUFDLFNBQVMsQ0FBQyxLQUFLLEdBQUcsRUFBRSxDQUFDO2FBQ3BDO2lCQUNJLElBQUksV0FBVyxDQUFDLFNBQVMsQ0FBQyxJQUFJLEtBQUssUUFBUSxJQUFJLFdBQVcsQ0FBQyxTQUFTLENBQUMsS0FBSyxDQUFDLE1BQU0sR0FBRyxDQUFDLEVBQUU7Z0JBQ3hGLE9BQU8sQ0FBQyxJQUFJLENBQUMsNkVBQTZFLENBQUMsQ0FBQztnQkFDNUYsV0FBVyxDQUFDLFNBQVMsQ0FBQyxLQUFLLEdBQUcsV0FBVyxDQUFDLFNBQVMsQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQzthQUN6RTtTQUNKO0lBQ0wsQ0FBQztJQUVEOzs7Ozs7Ozs7OztPQVdHO0lBQ0kscUJBQXFCLENBQUMsUUFBb0IsRUFBRSxZQUFvQyxFQUFFLFVBQXlCLEVBQUUsU0FBa0I7UUFDbEksSUFBSSxPQUFPLFVBQVUsS0FBSyxXQUFXO1lBQ2pDLFVBQVUsS0FBSyxJQUFJO1lBQ25CLFVBQVUsQ0FBQyxNQUFNLEtBQUssQ0FBQyxFQUFFO1lBQ3pCLE9BQU8sWUFBWSxDQUFDO1NBQ3ZCO1FBRUQsSUFBSSxrQkFBa0IsR0FBZSxFQUFFLENBQUM7UUFFeEMsS0FBSyxJQUFJLENBQUMsR0FBVyxDQUFDLEVBQUUsQ0FBQyxHQUFHLFFBQVEsQ0FBQyxNQUFNLEVBQUUsQ0FBQyxFQUFFLEVBQUU7WUFDOUMsSUFBSSxRQUFRLEdBQVEsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDO1lBQ2hDLElBQUksT0FBTyxHQUFRLEVBQUUsQ0FBQztZQUV0QixJQUFJLFlBQVksQ0FBQyxPQUFPLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxFQUFFO2dCQUNsRCxPQUFPLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxHQUFHLFFBQVEsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUM7Z0JBRTdDLEtBQUssSUFBSSxDQUFDLEdBQVcsQ0FBQyxFQUFFLENBQUMsR0FBRyxVQUFVLENBQUMsTUFBTSxFQUFFLENBQUMsRUFBRSxFQUFFO29CQUNoRCxJQUFJLFFBQVEsQ0FBQyxjQUFjLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUU7d0JBQ3hDLE9BQU8sQ0FBQyxVQUFVLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxRQUFRLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7cUJBQ3BEO3lCQUNJLElBQUksVUFBVSxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDLEVBQUU7d0JBQ3JDLElBQUksU0FBUyxHQUFRLElBQUksQ0FBQyxPQUFPLENBQUMsWUFBWSxDQUFDLFFBQVEsRUFBRSxVQUFVLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQzt3QkFFeEUsSUFBSSxTQUFTLEtBQUssSUFBSSxFQUFFOzRCQUNwQixJQUFJLE9BQU8sR0FBYyxNQUFPLENBQUMsTUFBTSxDQUFDLEVBQUUsRUFBRSxPQUFPLENBQUMsQ0FBQzs0QkFDckQsT0FBTyxHQUFHLElBQUksQ0FBQyx5QkFBeUIsQ0FBQyxPQUFPLEVBQUUsVUFBVSxDQUFDLENBQUMsQ0FBQyxFQUFFLFNBQVMsQ0FBQyxDQUFDO3lCQUMvRTtxQkFDSjtpQkFDSjtnQkFFRCxrQkFBa0IsQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLENBQUM7YUFDcEM7U0FDSjtRQUVELE9BQU8sa0JBQWtCLENBQUM7SUFDOUIsQ0FBQztJQUVELHdEQUF3RDtJQUN4RCx5QkFBeUI7SUFDekIsd0RBQXdEO0lBQ2pELGlCQUFpQixDQUFDLFdBQXlCO1FBQzlDLElBQUksT0FBTyxXQUFXLENBQUMsTUFBTSxLQUFLLFdBQVcsRUFBRTtZQUMzQyxXQUFXLENBQUMsTUFBTSxHQUFHLEVBQUUsQ0FBQztTQUMzQjthQUNJLElBQUksV0FBVyxDQUFDLE1BQU0sQ0FBQyxNQUFNLEdBQUcsQ0FBQyxFQUFFO1lBQ3BDLE9BQU8sQ0FBQyxJQUFJLENBQUMseURBQXlELENBQUMsQ0FBQztZQUN4RSxXQUFXLENBQUMsTUFBTSxHQUFHLFdBQVcsQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQztTQUN2RDtJQUNMLENBQUM7SUFFRCx3REFBd0Q7SUFDeEQseUJBQXlCO0lBQ3pCLHdEQUF3RDtJQUNqRCx1QkFBdUIsQ0FBQyxRQUFvQixFQUFFLGFBQWtDLEVBQUUsT0FBZSxFQUFFLFlBQXlCO1FBQy9ILElBQUksSUFBSSxDQUFDLFlBQVksQ0FBQyxhQUFhLEVBQUUsT0FBTyxDQUFDLEVBQUU7WUFDM0MsSUFBSSxPQUFPLFlBQVksQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLHVCQUF1QixDQUFDLEtBQUssV0FBVyxFQUFFO2dCQUMzRSxZQUFZLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyx1QkFBdUIsQ0FBQyxHQUFHLEVBQUUsQ0FBQzthQUMzRDtZQUVELElBQUksWUFBWSxHQUFRLElBQUksQ0FBQywwQkFBMEIsQ0FBQyxhQUFhLEVBQUUsUUFBUSxFQUFFLE9BQU8sQ0FBQyxDQUFDO1lBQzFGLFlBQVksQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLHVCQUF1QixDQUFDLEdBQVMsTUFBTyxDQUFDLE1BQU0sQ0FBQyxZQUFZLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyx1QkFBdUIsQ0FBQyxFQUFFLFlBQVksQ0FBQyxDQUFDO1NBQy9JO0lBQ0wsQ0FBQztJQUVELHdEQUF3RDtJQUN4RCwyQkFBMkI7SUFDM0Isd0RBQXdEO0lBQ2pELHFCQUFxQixDQUFDLFFBQW1CLEVBQUUsVUFBZTtRQUM3RCxRQUFRLENBQUMsV0FBVyxHQUFHLElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxVQUFVLENBQUMsRUFBRSxFQUFFLFVBQVUsQ0FBQyxLQUFLLENBQUMsQ0FBQztRQUMvRSxRQUFRLENBQUMsT0FBTyxHQUFHLElBQUksQ0FBQyxtQkFBbUIsQ0FBQyxVQUFVLENBQUMsSUFBSSxDQUFDLENBQUM7SUFDakUsQ0FBQztJQUVELHdEQUF3RDtJQUN4RCxpQkFBaUI7SUFDakIsd0RBQXdEO0lBQ2pELFNBQVMsQ0FBQyxXQUF5QjtRQUN0QyxJQUFJLE9BQU8sV0FBVyxDQUFDLEVBQUUsS0FBSyxXQUFXLEVBQUU7WUFDdkMsV0FBVyxDQUFDLEVBQUUsR0FBRyxJQUFJLENBQUMsY0FBYyxDQUFDO1NBQ3hDO1FBRUQsT0FBTyxXQUFXLENBQUMsRUFBRSxDQUFDO0lBQzFCLENBQUM7SUFFTSxjQUFjLENBQUMsWUFBMEIsRUFBRSxVQUE4QjtRQUM1RSx5Q0FBeUM7UUFDekMsSUFBSSxLQUFLLEdBQVcsR0FBRyxHQUFHLElBQUksQ0FBQyxhQUFhLENBQUM7UUFFN0MsSUFBSSxPQUFPLFlBQVksQ0FBQyxNQUFNLEtBQUssV0FBVztZQUMxQyxPQUFPLFlBQVksQ0FBQyxNQUFNLENBQUMsS0FBSyxLQUFLLFdBQVc7WUFDaEQsT0FBTyxZQUFZLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxVQUFVLENBQUMsS0FBSyxXQUFXLEVBQUU7WUFDOUQsS0FBSyxHQUFHLFlBQVksQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLFVBQVUsQ0FBQyxHQUFHLElBQUksQ0FBQyxhQUFhLENBQUM7U0FDdEU7UUFFRCxPQUFPLEtBQUssQ0FBQztJQUNqQixDQUFDO0lBRU0sa0JBQWtCO1FBQ3JCLE9BQU8sSUFBSSxDQUFDLHVCQUF1QixDQUFDO0lBQ3hDLENBQUM7SUFFTSx3QkFBd0IsQ0FBQyxRQUFpQixFQUFFLEtBQWE7UUFDNUQsT0FBTyxJQUFJLENBQUMsT0FBTyxDQUFDLGNBQWMsQ0FBQyxRQUFRLENBQUMsSUFBSSxFQUFFLEtBQUssQ0FBQyxDQUFDO0lBQzdELENBQUM7SUFFTSxTQUFTLENBQUMsT0FBWSxFQUFFLFdBQW1CO1FBQzlDLElBQUksU0FBUyxHQUFXLEdBQUcsQ0FBQztRQUU1QixJQUFJLGNBQWMsR0FBUSxJQUFJLENBQUMsT0FBTyxDQUFDLENBQUM7UUFDeEMsSUFBSSxVQUFVLEdBQVUsRUFBRSxDQUFDO1FBRTNCLEtBQUssSUFBSSxNQUFNLEdBQUcsQ0FBQyxFQUFFLE1BQU0sR0FBRyxjQUFjLENBQUMsTUFBTSxFQUFFLE1BQU0sSUFBSSxTQUFTLEVBQUU7WUFDdEUsSUFBSSxLQUFLLEdBQVEsY0FBYyxDQUFDLEtBQUssQ0FBQyxNQUFNLEVBQUUsTUFBTSxHQUFHLFNBQVMsQ0FBQyxDQUFDO1lBRWxFLElBQUksV0FBVyxHQUFVLElBQUksS0FBSyxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsQ0FBQztZQUNqRCxLQUFLLElBQUksQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLEdBQUcsS0FBSyxDQUFDLE1BQU0sRUFBRSxDQUFDLEVBQUUsRUFBRTtnQkFDbkMsV0FBVyxDQUFDLENBQUMsQ0FBQyxHQUFHLEtBQUssQ0FBQyxVQUFVLENBQUMsQ0FBQyxDQUFDLENBQUM7YUFDeEM7WUFFRCxJQUFJLFNBQVMsR0FBZSxJQUFJLFVBQVUsQ0FBQyxXQUFXLENBQUMsQ0FBQztZQUV4RCxVQUFVLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDO1NBQzlCO1FBRUQsSUFBSSxJQUFJLEdBQVMsSUFBSSxJQUFJLENBQUMsVUFBVSxFQUFFLEVBQUUsSUFBSSxFQUFFLFdBQVcsRUFBRSxDQUFDLENBQUM7UUFDN0QsT0FBTyxJQUFJLENBQUM7SUFDaEIsQ0FBQztJQUVELDhFQUE4RTtJQUM5RSx3REFBd0Q7SUFDeEQsMEJBQTBCO0lBQzFCLHdEQUF3RDtJQUM5QyxxQkFBcUIsQ0FBQyxVQUF5QixFQUFFLFVBQWtCO1FBQ3pFLElBQUksQ0FBQyxTQUFTLEdBQUcsVUFBVSxDQUFDO1FBRTVCLE9BQU87WUFDSCxPQUFPLEVBQUUsRUFBRTtZQUNYLFVBQVUsRUFBRSxFQUFFO1lBQ2QsU0FBUyxFQUFFLFVBQVUsS0FBSyxLQUFLO1lBRS9CLFlBQVksRUFBRSxFQUFFO1lBQ2hCLFNBQVMsRUFBRSxDQUFDLE9BQU8sVUFBVSxLQUFLLFdBQVcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxVQUFVLEdBQUcsRUFBRSxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsVUFBVTtZQUVsRixnQ0FBZ0M7WUFDaEMsNkJBQTZCLEVBQUUsSUFBSTtZQUNuQyxlQUFlLEVBQUUsSUFBSTtZQUVyQixtQkFBbUIsRUFBRSxJQUFJO1lBQ3pCLGdCQUFnQixFQUFFLElBQUk7WUFDdEIsY0FBYyxFQUFFLElBQUk7WUFFcEIsMEJBQTBCLEVBQUUsSUFBSTtZQUVoQyxzQ0FBc0M7WUFFdEMsV0FBVyxFQUFFLEtBQUs7WUFDbEIsU0FBUyxFQUFFLENBQUM7WUFFWixZQUFZLEVBQUUsQ0FBQyxLQUFVLEVBQVUsRUFBRTtnQkFDakMsSUFBSSxFQUFFLEdBQVcsS0FBSyxDQUFDLEVBQUUsQ0FBQztnQkFFMUIsSUFBSSxPQUFPLEtBQUssQ0FBQyxFQUFFLEtBQUssUUFBUSxFQUFFO29CQUM5QixFQUFFLEdBQUcsRUFBRSxDQUFDLFFBQVEsRUFBRSxDQUFDO2lCQUN0QjtnQkFFRCxPQUFPLEVBQUUsQ0FBQztZQUNkLENBQUM7WUFFRCxVQUFVLEVBQUUsSUFBSTtZQUNoQixLQUFLLEVBQUU7Z0JBQ0gsTUFBTSxFQUFFLDJCQUEyQjtnQkFDbkMsYUFBYSxFQUFFLCtCQUErQjtnQkFDOUMsY0FBYyxFQUFFLDZCQUE2QjtnQkFDN0MsVUFBVSxFQUFFLHlCQUF5QjtnQkFDckMsb0RBQW9EO2dCQUNwRCxxREFBcUQ7Z0JBQ3JELGFBQWEsRUFBRSwrQkFBK0I7Z0JBQzlDLGVBQWUsRUFBRSxnQ0FBZ0M7Z0JBRWpELElBQUksRUFBRSx5QkFBeUI7YUFDbEM7WUFDRCxrQkFBa0IsRUFBRTtnQkFDaEIsS0FBSyxFQUFFO29CQUNILElBQUksRUFBRSw2Q0FBNkM7aUJBQ3REO2FBQ0o7WUFDRCxPQUFPLEVBQUUsRUFBRTtZQUNYLHFCQUFxQixFQUFFLDhHQUE4RztTQUN4SSxDQUFDO0lBQ04sQ0FBQztJQUVELHdEQUF3RDtJQUN4RCwrQkFBK0I7SUFDL0Isd0RBQXdEO0lBQzlDLHlCQUF5QixDQUFDLGFBQWtDLEVBQUUsV0FBeUIsRUFBRSwwQkFBa0MsSUFBSTtRQUNySSxJQUFJLFNBQVMsR0FBa0IsSUFBSSxDQUFDLDZCQUE2QixDQUFDLGFBQWEsRUFBRSxXQUFXLEVBQUUsdUJBQXVCLENBQUMsQ0FBQztRQUN2SCxJQUFJLGFBQWEsR0FBOEIsSUFBSSxDQUFDLDBCQUEwQixDQUFDLFdBQVcsQ0FBQyxDQUFDO1FBRTVGLElBQUksYUFBYSxDQUFDLGNBQWMsQ0FBQyxRQUFRLENBQUMsRUFBRTtZQUN4QyxTQUFTLENBQUMsSUFBSSxDQUFDLGFBQWEsQ0FBQyxNQUFNLENBQUMsQ0FBQztTQUN4QztRQUVELElBQUksYUFBYSxDQUFDLGNBQWMsQ0FBQyxXQUFXLENBQUMsRUFBRTtZQUMzQyxTQUFTLENBQUMsT0FBTyxDQUFDLGFBQWEsQ0FBQyxTQUFTLENBQUMsQ0FBQztTQUM5QztRQUVELE9BQU8sU0FBUyxDQUFDO0lBQ3JCLENBQUM7SUFFUyxjQUFjLENBQUMsT0FBZSxFQUFFLEtBQWE7UUFDbkQsSUFBSSxPQUFPLE9BQU8sQ0FBQyxrQkFBa0IsS0FBSyxXQUFXO1lBQ2pELE9BQU8sT0FBTyxDQUFDLGtCQUFrQixDQUFDLE1BQU0sS0FBSyxXQUFXO1lBQ3hELE9BQU8sT0FBTyxDQUFDLGtCQUFrQixDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsS0FBSyxXQUFXLEVBQUU7WUFDakUsT0FBTyxJQUFJLENBQUM7U0FDZjtRQUVELE9BQU8sS0FBSyxDQUFDO0lBQ2pCLENBQUM7SUFFRCx3REFBd0Q7SUFDeEQsaUJBQWlCO0lBQ2pCLHdEQUF3RDtJQUM5QyxrQkFBa0IsQ0FBQyxPQUFlLEVBQUUsU0FBaUIsRUFBRSxNQUF1QjtRQUNwRixPQUFPLE9BQU8sR0FBRyxJQUFJLENBQUMsaUJBQWlCLEdBQUcsU0FBUyxHQUFHLElBQUksQ0FBQyxpQkFBaUIsR0FBRyxNQUFNLENBQUM7SUFDMUYsQ0FBQztJQUVELCtFQUErRTtJQUMvRSx3REFBd0Q7SUFDeEQsd0NBQXdDO0lBQ3hDLHdEQUF3RDtJQUNoRCw2QkFBNkIsQ0FBQyxhQUFrQyxFQUFFLFdBQXlCLEVBQUUsMEJBQW1DLElBQUk7UUFDeEksSUFBSSxTQUFTLEdBQWtCLEVBQUUsQ0FBQztRQUVsQyxLQUFLLElBQUksQ0FBQyxHQUFXLENBQUMsRUFBRSxDQUFDLEdBQUcsYUFBYSxDQUFDLE1BQU0sRUFBRSxDQUFDLEVBQUUsRUFBRTtZQUNuRCxJQUFJLE1BQU0sR0FBVyxFQUFFLENBQUM7WUFFeEIsSUFBSSxPQUFPLGFBQWEsQ0FBQyxDQUFDLENBQUMsS0FBSyxXQUFXLEVBQUU7Z0JBQ3pDLElBQUksVUFBVSxHQUF1QixNQUFPLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyx1QkFBdUIsRUFBRSxFQUFFLGFBQWEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO2dCQUN0RyxVQUFVLENBQUMsZUFBZSxHQUFHLHVCQUF1QixDQUFDO2dCQUVyRCxRQUFRLFVBQVUsQ0FBQyxJQUFJLEVBQUU7b0JBQ3JCLEtBQUssT0FBTzt3QkFDUixNQUFNLEdBQUcsSUFBSSxDQUFDLG9CQUFvQixDQUFDLFVBQVUsRUFBRSxXQUFXLENBQUMsRUFBRSxDQUFDLENBQUM7d0JBQy9ELE1BQU07b0JBQ1YsS0FBSyxPQUFPO3dCQUNSLE1BQU0sR0FBRyxJQUFJLENBQUMsb0JBQW9CLENBQUMsVUFBVSxDQUFDLENBQUM7d0JBQy9DLE1BQU07b0JBQ1Y7d0JBQ0kscUJBQXFCO3dCQUNyQix1R0FBdUc7d0JBQ3ZHLE1BQU0sR0FBRyxVQUFVLENBQUM7d0JBQ3BCLE1BQU0sQ0FBQyxVQUFVLEdBQUcsVUFBVSxDQUFDLFVBQVUsQ0FBQzt3QkFDMUMsTUFBTSxDQUFDLEtBQUssR0FBRyxVQUFVLENBQUMsS0FBSyxDQUFDO3dCQUNoQyxNQUFNLENBQUMsS0FBSyxHQUFHLFVBQVUsQ0FBQyxLQUFLLENBQUM7d0JBQ2hDLE1BQU0sQ0FBQyxTQUFTLEdBQUcsY0FBYyxHQUFHLFVBQVUsQ0FBQyxLQUFLLENBQUM7d0JBQ3JELE1BQU0sQ0FBQyxJQUFJLEdBQUcsQ0FBQyxVQUFVLENBQUMsT0FBTyxDQUFDO3dCQUNsQyxNQUFNLENBQUMsWUFBWSxHQUFHLENBQUMsVUFBVSxDQUFDLFVBQVUsQ0FBQzt3QkFDN0MsTUFBTSxDQUFDLGVBQWUsR0FBRyxDQUFDLFVBQVUsQ0FBQyxRQUFRLENBQUM7d0JBQzlDLE1BQU0sQ0FBQyxRQUFRLEdBQUcsR0FBRyxDQUFDO3dCQUN0QixNQUFNLENBQUMsZUFBZSxHQUFHLFVBQVUsQ0FBQyxlQUFlLENBQUM7aUJBQzNEO2dCQUVELElBQUksVUFBVSxDQUFDLFVBQVUsRUFBRTtvQkFDdkIsSUFBSSxDQUFDLG1CQUFtQixDQUFDLE1BQU0sRUFBRSxVQUFVLENBQUMsV0FBVyxDQUFDLENBQUM7aUJBQzVEO2FBQ0o7WUFDRCxTQUFTLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDO1NBQzFCO1FBRUQsT0FBTyxTQUFTLENBQUM7SUFDckIsQ0FBQztJQUVPLDBCQUEwQixDQUFDLE9BQXFCO1FBQ3BELElBQUksWUFBWSxHQUE4QixFQUFFLENBQUM7UUFFakQsSUFBSSxPQUFPLE9BQU8sS0FBSyxXQUFXO1lBQzlCLE9BQU8sT0FBTyxDQUFDLE1BQU0sS0FBSyxXQUFXO1lBQ3JDLE9BQU8sQ0FBQyxNQUFNLENBQUMsT0FBTyxFQUFFO1lBQ3hCLFlBQVksQ0FBQyxNQUFNLEdBQUcsSUFBSSxDQUFDLHFCQUFxQixDQUFDLE9BQU8sQ0FBQyxFQUFFLEVBQUUsT0FBTyxDQUFDLE1BQU0sQ0FBQyxJQUFJLEVBQUUsT0FBTyxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsQ0FBQztTQUMxRztRQUVELElBQUksT0FBTyxPQUFPLEtBQUssV0FBVztZQUM5QixPQUFPLE9BQU8sQ0FBQyxTQUFTLEtBQUssV0FBVztZQUN4QyxPQUFPLE9BQU8sQ0FBQyxTQUFTLENBQUMsSUFBSSxLQUFLLFdBQVcsRUFBRTtZQUMvQyxZQUFZLENBQUMsU0FBUyxHQUFHLElBQUksQ0FBQyw0QkFBNEIsQ0FBQyxPQUFPLENBQUMsU0FBUyxFQUFFLE9BQU8sQ0FBQyxFQUFFLENBQUMsQ0FBQztTQUM3RjtRQUVELE9BQU8sWUFBWSxDQUFDO0lBQ3hCLENBQUM7SUFFRCx3REFBd0Q7SUFDeEQsc0NBQXNDO0lBQ3RDLHdEQUF3RDtJQUNoRCxxQkFBcUIsQ0FBQyxHQUFXLEVBQUUsS0FBa0MsRUFBRSxLQUFjO1FBQ3pGLE9BQU87WUFDSCxVQUFVLEVBQUUsQ0FBQyxPQUFPLEtBQUssS0FBSyxXQUFXLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxRQUFRO1lBQzdELGVBQWUsRUFBRSxJQUFJO1lBQ3JCLGNBQWMsRUFBRSxJQUFJO1lBQ3BCLGlCQUFpQixFQUFFLElBQUk7WUFDdkIsY0FBYyxFQUFFLElBQUk7WUFDcEIsWUFBWSxFQUFFLElBQUk7WUFDbEIsS0FBSyxFQUFFLEdBQUc7WUFDVixRQUFRLEVBQUUsR0FBRztZQUNiLFFBQVEsRUFBRSxHQUFHO1lBQ2IsU0FBUyxFQUFFLGlCQUFpQjtZQUM1QixLQUFLLEVBQUUsV0FBVztZQUNsQixxQkFBcUIsRUFBRSxhQUFhO1lBQ3BDLGtCQUFrQixFQUFFO2dCQUNoQixNQUFNLEVBQUUsS0FBSztnQkFDYixNQUFNLEVBQUUsR0FBRzthQUNkO1lBQ0QsZUFBZSxFQUFFLElBQUk7U0FDeEIsQ0FBQztJQUNOLENBQUM7SUFFRCx3REFBd0Q7SUFDeEQsdUNBQXVDO0lBQ3ZDLHdEQUF3RDtJQUNoRCw0QkFBNEIsQ0FBQyxhQUFrQixFQUFFLE9BQWU7UUFDcEUsaUVBQWlFO1FBQ2pFLHFEQUFxRDtRQUVyRCxJQUFJLHNCQUFzQixHQUFXLElBQUksQ0FBQyxTQUFTLEtBQUssS0FBSyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQztRQUVqRixJQUFJLFVBQVUsR0FBUTtZQUNsQixlQUFlLEVBQUUsSUFBSTtZQUNyQixjQUFjLEVBQUUsSUFBSTtZQUNwQixpQkFBaUIsRUFBRSxJQUFJO1lBQ3ZCLFlBQVksRUFBRSxJQUFJO1lBQ2xCLGNBQWMsRUFBRSxJQUFJO1lBQ3BCLEtBQUssRUFBRSxFQUFFO1lBQ1QsUUFBUSxFQUFFLEVBQUU7WUFDWixRQUFRLEVBQUUsRUFBRTtZQUNaLFNBQVMsRUFBRSw4QkFBOEI7WUFDekMsTUFBTSxFQUFFLHNCQUFzQjtZQUM5QixLQUFLLEVBQUUsQ0FBQyxhQUFhLENBQUMsSUFBSSxLQUFLLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLFVBQVU7WUFDL0QscUJBQXFCLEVBQUUsb0JBQW9CO1lBQzNDLGtCQUFrQixFQUFFO2dCQUNoQixNQUFNLEVBQUU7b0JBQ0osU0FBUyxFQUFFLENBQUMsYUFBYSxDQUFDLElBQUksS0FBSyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxVQUFVO29CQUNuRSxPQUFPLEVBQUUsYUFBYSxDQUFDLEtBQUs7b0JBQzVCLE1BQU0sRUFBRSxPQUFPO2lCQUNsQjthQUNKO1lBQ0QsZUFBZSxFQUFFLElBQUk7U0FDeEIsQ0FBQztRQUVGLElBQUksYUFBYSxDQUFDLElBQUksS0FBSyxLQUFLLEVBQUU7WUFDOUIsVUFBVSxDQUFDLHdCQUF3QixHQUFHLG9CQUFvQixDQUFDO1lBQzNELFVBQVUsQ0FBQyxxQkFBcUIsR0FBRztnQkFDL0IsTUFBTSxFQUFFO29CQUNKLE9BQU8sRUFBRSxhQUFhLENBQUMsS0FBSztvQkFDNUIsTUFBTSxFQUFFLE9BQU87aUJBQ2xCO2FBQ0osQ0FBQztTQUNMO1FBRUQsT0FBTyxVQUFVLENBQUM7SUFDdEIsQ0FBQztJQUVELHdEQUF3RDtJQUN4RCxrQ0FBa0M7SUFDbEMsd0RBQXdEO0lBQ2hELG9CQUFvQixDQUFDLFdBQXlCO1FBQ2xELElBQUksS0FBSyxHQUFXLElBQUksQ0FBQyxjQUFjLENBQUMsV0FBVyxFQUFFLE9BQU8sQ0FBQyxDQUFDO1FBRTlELE9BQU87WUFDSCxVQUFVLEVBQUUsV0FBVyxDQUFDLFVBQVU7WUFDbEMsS0FBSyxFQUFFLFdBQVcsQ0FBQyxLQUFLO1lBQ3hCLEtBQUssRUFBRSxXQUFXLENBQUMsS0FBSztZQUN4QixlQUFlLEVBQUUsSUFBSTtZQUNyQixjQUFjLEVBQUUsSUFBSTtZQUNwQixZQUFZLEVBQUUsSUFBSTtZQUNsQixjQUFjLEVBQUUsSUFBSTtZQUNwQixJQUFJLEVBQUUsQ0FBQyxXQUFXLENBQUMsT0FBTztZQUMxQixRQUFRLEVBQUUsS0FBSztZQUNmLFFBQVEsRUFBRSxLQUFLO1lBQ2YsU0FBUyxFQUFFLFdBQVcsQ0FBQyxLQUFLO1lBQzVCLHFCQUFxQixFQUFFLFlBQVk7WUFDbkMsa0JBQWtCLEVBQUU7Z0JBQ2hCLE1BQU0sRUFBRTtvQkFDSixDQUFDLElBQUksQ0FBQyxlQUFlLENBQUMsS0FBSyxDQUFDLEVBQUUsV0FBVyxDQUFDLE1BQU0sQ0FBQyxLQUFLO2lCQUN6RDthQUNKO1lBQ0QsZUFBZSxFQUFFLFdBQVcsQ0FBQyxlQUFlO1NBQy9DLENBQUM7SUFDTixDQUFDO0lBRUQsd0RBQXdEO0lBQ3hELGtDQUFrQztJQUNsQyx3REFBd0Q7SUFDaEQsb0JBQW9CLENBQUMsV0FBeUIsRUFBRSxPQUFlO1FBQ25FLE9BQU87WUFDSCxVQUFVLEVBQUUsV0FBVyxDQUFDLFVBQVU7WUFDbEMsS0FBSyxFQUFFLFdBQVcsQ0FBQyxLQUFLO1lBQ3hCLGVBQWUsRUFBRSxJQUFJO1lBQ3JCLGNBQWMsRUFBRSxJQUFJO1lBQ3BCLFlBQVksRUFBRSxJQUFJO1lBQ2xCLFFBQVEsRUFBRSxHQUFHO1lBQ2IsSUFBSSxFQUFFLENBQUMsV0FBVyxDQUFDLE9BQU87WUFDMUIsU0FBUyxFQUFFLFdBQVcsQ0FBQyxLQUFLO1lBQzVCLEtBQUssRUFBRSxXQUFXLENBQUMsS0FBSztZQUN4QixxQkFBcUIsRUFBRSxZQUFZO1lBQ25DLGtCQUFrQixFQUFFO2dCQUNoQixNQUFNLEVBQUU7b0JBQ0osQ0FBQyxJQUFJLENBQUMsZUFBZSxDQUFDLEtBQUssQ0FBQyxFQUFFLFdBQVcsQ0FBQyxNQUFNO29CQUNoRCxNQUFNLEVBQUUsT0FBTztvQkFDZixVQUFVLEVBQUUsSUFBSSxDQUFDLHVCQUF1QjtpQkFDM0M7YUFDSjtZQUNELGVBQWUsRUFBRSxXQUFXLENBQUMsZUFBZTtTQUMvQyxDQUFDO0lBQ04sQ0FBQztJQUVELHdEQUF3RDtJQUN4RCw0QkFBNEI7SUFDNUIsd0RBQXdEO0lBQ2hELGlCQUFpQixDQUFDLE9BQWUsRUFBRSxnQkFBaUM7UUFDeEUsT0FBTztZQUNILFdBQVcsRUFBRSxDQUFDLFlBQW9DLEVBQU8sRUFBRTtnQkFDdkQsSUFBSSxXQUFXLEdBQUcsSUFBSSxDQUFDLGtCQUFrQixDQUFDLE9BQU8sRUFBRSxZQUFZLENBQUMsS0FBSyxFQUFFLFlBQVksQ0FBQyxLQUFLLENBQUMsQ0FBQztnQkFDM0YsT0FBTyxJQUFJLENBQUMsV0FBVyxDQUFDLE9BQU8sQ0FBQyxpQkFBaUIsQ0FBQyxXQUFXLENBQUMsQ0FBQyxZQUFZLENBQUMsV0FBVyxDQUFDLENBQUMsWUFBWSxDQUFDLFFBQVEsQ0FBQyxDQUFDO1lBQ3BILENBQUM7WUFDRCxXQUFXLEVBQUUsQ0FBQyxZQUFvQyxFQUFRLEVBQUU7Z0JBQ3hELElBQUksV0FBVyxHQUFHLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxPQUFPLEVBQUUsWUFBWSxDQUFDLEtBQUssRUFBRSxZQUFZLENBQUMsS0FBSyxDQUFDLENBQUM7Z0JBRTNGLElBQUksT0FBTyxJQUFJLENBQUMsV0FBVyxDQUFDLE9BQU8sQ0FBQyxpQkFBaUIsQ0FBQyxXQUFXLENBQUMsS0FBSyxXQUFXLEVBQUU7b0JBQ2hGLElBQUksQ0FBQyxXQUFXLENBQUMsT0FBTyxDQUFDLGlCQUFpQixDQUFDLFdBQVcsQ0FBQyxDQUFDLFlBQVksQ0FBQyxXQUFXLENBQUMsQ0FBQyxZQUFZLENBQUMsUUFBUSxDQUFDLEdBQUcsWUFBWSxDQUFDLElBQUksQ0FBQztpQkFDaEk7Z0JBRUQsSUFBSSxPQUFPLEdBQVksSUFBSSxDQUFDLFdBQVcsQ0FBQyxHQUFHLENBQUMsVUFBVSxDQUFDLFlBQVksQ0FBQyxLQUFLLENBQUMsUUFBUSxFQUFFLENBQUMsQ0FBQztnQkFFdEYsSUFBSSxZQUFZLENBQUMsUUFBUSxLQUFLLFNBQVMsRUFBRTtvQkFDckMsT0FBTyxDQUFDLFlBQVksQ0FBQyxTQUFTLENBQUMsQ0FBQztvQkFDaEMsNkZBQTZGO29CQUM3RixJQUFJLENBQUMsV0FBVyxDQUFDLEdBQUcsQ0FBQyxrQkFBa0IsRUFBRSxDQUFDO2lCQUM3QztnQkFFRCxJQUFJLFlBQVksQ0FBQyxRQUFRLEtBQUssT0FBTyxFQUFFO29CQUNuQyxPQUFPLENBQUMsSUFBSSxDQUFDLFlBQVksQ0FBQyxLQUFLLENBQUMsQ0FBQyxZQUFZLENBQUMsV0FBVyxDQUFDLEdBQUcsWUFBWSxDQUFDLElBQUksQ0FBQztpQkFDbEY7WUFDTCxDQUFDO1NBQ0osQ0FBQztJQUNOLENBQUM7SUFFTyxtQkFBbUIsQ0FBQyxJQUFnQjtRQUN4QyxPQUFPO1lBQ0gsY0FBYyxFQUFFLEdBQWUsRUFBRTtnQkFDN0IsT0FBTyxJQUFJLENBQUMsS0FBSyxFQUFFLENBQUM7WUFDeEIsQ0FBQztZQUVELGNBQWMsRUFBRSxHQUFTLEVBQUU7Z0JBQ3ZCLElBQUksQ0FBQyxXQUFXLENBQUMsR0FBRyxDQUFDLGVBQWUsRUFBRSxDQUFDO1lBQzNDLENBQUM7WUFFRCxnQkFBZ0IsRUFBRSxDQUFDLE1BQWMsRUFBRSxRQUFpQixFQUFRLEVBQUU7Z0JBQzFELElBQUksQ0FBQyxXQUFXLENBQUMsU0FBUyxDQUFDLGdCQUFnQixDQUFDLE1BQU0sRUFBRSxRQUFRLENBQUMsQ0FBQztZQUNsRSxDQUFDO1NBQ0osQ0FBQztJQUNOLENBQUM7SUFFRCx3REFBd0Q7SUFDeEQseUJBQXlCO0lBQ3pCLHdEQUF3RDtJQUN4RDs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O09BZ0RHO0lBQ0ssMEJBQTBCLENBQUMsT0FBNEIsRUFBRSxJQUFnQixFQUFFLE9BQWU7UUFDOUYsSUFBSSxpQkFBaUIsR0FBUSxFQUFFLENBQUM7UUFFaEMsS0FBSyxJQUFJLENBQUMsR0FBVyxDQUFDLEVBQUUsQ0FBQyxHQUFHLE9BQU8sQ0FBQyxNQUFNLEVBQUUsRUFBRSxDQUFDLEVBQUU7WUFDN0MsSUFBSSxJQUFJLENBQUMsV0FBVyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsRUFBRSxPQUFPLENBQUMsRUFBRTtnQkFDdkMsSUFBSSxhQUFhLEdBQWlCLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQztnQkFDN0MsSUFBSSxlQUFlLEdBQVcsYUFBYSxDQUFDLEtBQUssQ0FBQztnQkFFbEQsS0FBSyxJQUFJLENBQUMsR0FBVyxDQUFDLEVBQUUsQ0FBQyxHQUFHLElBQUksQ0FBQyxNQUFNLEVBQUUsRUFBRSxDQUFDLEVBQUU7b0JBQzFDLElBQUksT0FBTyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxLQUFLLFdBQVcsRUFBRTt3QkFDN0MsSUFBSSxhQUFhLEdBQVEsRUFBRSxDQUFDO3dCQUU1Qiw4REFBOEQ7d0JBQzlELGtEQUFrRDt3QkFDbEQsc0RBQXNEO3dCQUN0RCxzQ0FBc0M7d0JBRXRDLHlEQUF5RDt3QkFDekQsSUFBSSxPQUFPLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxlQUFlLENBQUMsS0FBSyxXQUFXLEVBQUU7NEJBQ2pELElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxlQUFlLENBQUMsR0FBRyxFQUFFLENBQUM7eUJBQ2pDO3dCQUVELHFDQUFxQzt3QkFDckMsSUFBSSxPQUFPLGFBQWEsQ0FBQyxNQUFNLEtBQUssV0FBVyxJQUFJLE9BQU8sYUFBYSxDQUFDLE1BQU0sQ0FBQyxLQUFLLEtBQUssV0FBVyxFQUFFOzRCQUNsRyxJQUFJLGdCQUFnQixHQUEyQixDQUFDLGFBQWEsQ0FBQyxNQUFNLENBQUMsS0FBSyxZQUFZLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxhQUFhLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxhQUFhLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxDQUFDOzRCQUN6SixJQUFJLGFBQWEsR0FBUSxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsZUFBZSxDQUFDLENBQUM7NEJBRWxELEtBQUssSUFBSSxDQUFDLEdBQVcsQ0FBQyxFQUFFLENBQUMsR0FBRyxnQkFBZ0IsQ0FBQyxNQUFNLEVBQUUsRUFBRSxDQUFDLEVBQUU7Z0NBQ3RELDRFQUE0RTtnQ0FDNUUsSUFBSSxPQUFPLGFBQWEsQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsS0FBSyxXQUFXLEVBQUU7b0NBQy9ELGFBQWEsQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsR0FBRyxFQUFFLENBQUM7aUNBQy9DO2dDQUVELGFBQWEsQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsR0FBUyxNQUFPLENBQUMsTUFBTSxDQUFDLEVBQUUsRUFBRSxnQkFBZ0IsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO2dDQUN2RixhQUFhLENBQUMsZ0JBQWdCLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsS0FBSyxHQUFHLGFBQWEsQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQzs2QkFDekY7eUJBQ0o7NkJBQ0k7NEJBQ0QsT0FBTyxDQUFDLEtBQUssQ0FBQyw4RkFBOEYsQ0FBQyxDQUFDO3lCQUNqSDt3QkFFRCxJQUFJLFVBQVUsR0FBVyxJQUFJLENBQUMsa0JBQWtCLENBQUMsT0FBTyxFQUFFLGVBQWUsRUFBRSxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUM7d0JBQ2pHLGlCQUFpQixDQUFDLFVBQVUsQ0FBQyxHQUFTLE1BQU8sQ0FBQyxNQUFNLENBQUMsRUFBRSxFQUFFLGFBQWEsQ0FBQyxDQUFDO3FCQUMzRTt5QkFDSTt3QkFDRCxPQUFPLENBQUMsS0FBSyxDQUFDLGdEQUFnRCxHQUFHLElBQUksQ0FBQyxNQUFNLEdBQUcsc0RBQXNELENBQUMsQ0FBQztxQkFDMUk7aUJBQ0o7YUFDSjtTQUNKO1FBRUQsT0FBTyxpQkFBaUIsQ0FBQztJQUM3QixDQUFDO0lBRUQsd0RBQXdEO0lBQ3hELCtDQUErQztJQUMvQyx3REFBd0Q7SUFDeEQ7Ozs7Ozs7Ozs7O09BV0c7SUFDSyx5QkFBeUIsQ0FBQyxZQUFpQixFQUFFLE9BQWUsRUFBRSxNQUFXLEVBQUUsYUFBcUIsR0FBRztRQUN2RyxJQUFJLFlBQVksR0FBa0IsT0FBTyxDQUFDLEtBQUssQ0FBQyxVQUFVLENBQUMsQ0FBQztRQUM1RCxPQUFPLElBQUksQ0FBQyxtQkFBbUIsQ0FBQyxZQUFZLEVBQUUsWUFBWSxFQUFFLE1BQU0sQ0FBQyxDQUFDO0lBQ3hFLENBQUM7SUFFTyxtQkFBbUIsQ0FBQyxJQUFtQixFQUFFLFdBQWdCLEVBQUUsTUFBVztRQUMxRSxJQUFJLElBQUksQ0FBQyxNQUFNLEdBQUcsQ0FBQyxFQUFFO1lBQ2pCLElBQUksVUFBVSxHQUFXLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQztZQUVqQyxJQUFJLE9BQU8sV0FBVyxDQUFDLFVBQVUsQ0FBQyxLQUFLLFdBQVcsRUFBRTtnQkFDaEQsV0FBVyxDQUFDLFVBQVUsQ0FBQyxHQUFHLEVBQUUsQ0FBQzthQUNoQztZQUVELElBQUksQ0FBQyxLQUFLLEVBQUUsQ0FBQztZQUNiLFdBQVcsQ0FBQyxVQUFVLENBQUMsR0FBRyxJQUFJLENBQUMsbUJBQW1CLENBQUMsSUFBSSxFQUFFLFdBQVcsQ0FBQyxVQUFVLENBQUMsRUFBRSxNQUFNLENBQUMsQ0FBQztTQUM3RjthQUNJO1lBQ0QsV0FBVyxHQUFHLE1BQU0sQ0FBQztTQUN4QjtRQUVELE9BQU8sV0FBVyxDQUFDO0lBQ3ZCLENBQUM7SUFFRCx3REFBd0Q7SUFDeEQsa0JBQWtCO0lBQ2xCLHdEQUF3RDtJQUNoRCxtQkFBbUIsQ0FBQyxPQUFlLEVBQUUsVUFBMEI7UUFDbkUsT0FBTyxDQUFDLFFBQVEsR0FBRyxDQUFDLGVBQWUsQ0FBQyxDQUFDO1FBQ3JDLE9BQU8sQ0FBQyxNQUFNLEdBQUcsbUJBQW1CLENBQUM7UUFDckMsT0FBTyxDQUFDLFlBQVksR0FBRztZQUNuQixhQUFhLEVBQUUsTUFBTTtZQUNyQixVQUFVLEVBQUUsRUFBRTtZQUNkLHFCQUFxQixFQUFFLElBQUk7U0FDOUIsQ0FBQztRQUVGLElBQUksT0FBTyxVQUFVLEtBQUssV0FBVyxFQUFFO1lBQ25DLE9BQU8sQ0FBQyxZQUFZLENBQUMsTUFBTSxHQUFHLFVBQVUsQ0FBQztTQUM1QztJQUNMLENBQUM7SUFFTyx1QkFBdUI7UUFDM0IsT0FBTztZQUNILFFBQVEsRUFBRSxLQUFLO1lBQ2YsVUFBVSxFQUFFLEtBQUs7WUFDakIsT0FBTyxFQUFFLElBQUk7U0FDaEIsQ0FBQztJQUNOLENBQUM7OztZQTlzQkosVUFBVSIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IEluamVjdGFibGUgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcclxuaW1wb3J0IHtcclxuICAgIEdyaWRPcHRpb25zLFxyXG4gICAgQ29sRGVmLFxyXG4gICAgUm93Tm9kZVxyXG59IGZyb20gJ2FnLWdyaWQtY29tbXVuaXR5JztcclxuXHJcbmltcG9ydCB7XHJcbiAgICBJVGFibGVDb2x1bW4sXHJcbiAgICBJVGFibGVDb25maWcsXHJcbiAgICBJVGFibGVGb3JtSW5wdXQsXHJcbiAgICBJVGFibGVBcGksXHJcbiAgICBJVGFibGVEeW5hbWljRm9ybUFwaSxcclxuICAgIElUYWJsZUdlbmVyYWxBcGksXHJcblxyXG4gICAgSVRhYmxlRHJvcGRvd25BY3Rpb24sXHJcbiAgICBJVGFibGVGb3JtVXBkYXRlUGFyYW1zXHJcbn0gZnJvbSAnLi4va2QtYW5ndWxhci10YWJsZS1pbnRlcmZhY2UnO1xyXG5cclxuaW1wb3J0IHsgS2RUYWJsZUFjdGlvbiB9IGZyb20gJy4uL3RhYmxlLWNvbXBvbmVudHMva2QtdGFibGUtYWN0aW9uJztcclxuaW1wb3J0IHsgS2RUYWJsZUNoZWNrYm94UmFkaW8gfSBmcm9tICcuLi90YWJsZS1jb21wb25lbnRzL2tkLXRhYmxlLWNoZWNrYm94LXJhZGlvJztcclxuaW1wb3J0IHsgS2RUYWJsZUlucHV0IH0gZnJvbSAnLi4vdGFibGUtY29tcG9uZW50cy9rZC10YWJsZS1pbnB1dCc7XHJcbmltcG9ydCB7IEtkVGFibGVJbWFnZSB9IGZyb20gJy4uL3RhYmxlLWNvbXBvbmVudHMva2QtdGFibGUtaW1hZ2UnO1xyXG5cclxuXHJcbmltcG9ydCB7IEtkSW50VGFibGVFdmVudCB9IGZyb20gJy4uL2tkLWFuZ3VsYXItdGFibGUtZXZlbnQnO1xyXG5pbXBvcnQgeyBLZERhdGFTdmMgfSBmcm9tICcuLi8uLi9rZC1jb21tb24vaW5kZXgnO1xyXG5cclxuLyoqXHJcbiAqIC0tIERvY3VtZW50YXRpb24gZm9yIGtkLXRhYmxlLXN2Yy50c1xyXG4gKlxyXG4gKiAtIFB1YmxpYyBmdW5jdGlvbnMgKFVzYWJsZSBieSBib3RoIGV4dGVuZGVkIHNlcnZpY2VzKTpcclxuICogICAgIC0gQ2hlY2tpbmcgZnVuY3Rpb25zXHJcbiAqICAgICAgICAgLSBpc0FwaVJlYWR5XHJcbiAqICAgICAgICAgLSBoYXNTZWxlY3Rpb25BbGxcclxuICogICAgICAgICAtIGhhc0lucHV0VHlwZVxyXG4gKiAgICAgICAgIC0gaXNJbnB1dFR5cGVcclxuICogICAgICAgICAtIGlzRW50ZXJwcmlzZU1vZGVsXHJcbiAqICAgICAtIFVwZGF0ZSBmdW5jdGlvbnNcclxuICogICAgICAgICAtIHVwZGF0ZVNlbGVjdERlZmF1bHRWYWx1ZVxyXG4gKiAgICAgICAgIC0gdXBkYXRlU2VsZWN0aW9uVmFsdWVzXHJcbiAqICAgICAgICAgLSB1cGRhdGVHcmlkQnV0dG9uc1xyXG4gKiAgICAgICAgIC0gdXBkYXRlUm93RGF0YVdpdGhDb2x1bW4gKEdlbmVyYXRpb25zIG9mIGlucHV0IGNvbnRleHQgaW4gZ3JpZE9wdGlvbnMuY29udGV4dCBpZiBpbnB1dCBleGlzdClcclxuICogICAgICAgICAtIGdlbmVyYXRlZEFwaUZ1bmN0aW9ucyAoR2VuZXJhdGlvbiBvZiBBUElzKVxyXG4gKiAgICAgLSBNaXNjIGZ1bmN0aW9uXHJcbiAqICAgICAgICAgLSBnZXRHcmlkSWRcclxuICogICAgICAgICAtIGdldEltYWdlU2l6ZUJ5XHJcbiAqICAgICAgICAgLSBnZXRUYWJsZUNvbnRleHRLZXlcclxuICogICAgICAgICAtIGdldFJvdXRlclBsYWNlaG9sZGVyUGF0aCAoRm9yIHBhdGhNYXAgb2YgY2xpY2sgdHlwZSByb3V0ZXIpXHJcbiAqICAgICAgICAgLSBiNjR0b0Jsb2JcclxuICpcclxuICogLSBQcm90ZWN0ZWQgZnVuY3Rpb246XHJcbiAqICAgICAtIEdyaWQgT3B0aW9ucyBmdW5jdGlvblxyXG4gKiAgICAgICAgIC0gZ2V0RGVmYXVsdEdyaWRPcHRpb25zXHJcbiAqICAgICAtIENvbHVtbiBkZWZpbml0aW9uIGZ1bmN0aW9uc1xyXG4gKiAgICAgICAgIC0gZ2VuZXJhdGVDb2x1bW5EZWZpbml0aW9uc1xyXG4gKiAgICAgICAgIC0gaXNDb2xEZWZPZlR5cGVcclxuICogICAgIC0gQVBJIGdlbmVyYXRpb24gZnVuY3Rpb25cclxuICogICAgIC0gTWlzYyBmdW5jdGlvbnNcclxuICogICAgICAgICAtIGdlbmVyYXRlR3JpZElkXHJcbiAqICAgICAgICAgLSBnZW5lcmF0ZUNvbnRleHRLZXlcclxuICogICAgICAgICAtIGdldEltYWdlU2l6ZUJ5XHJcbiAqXHJcbiAqIC0gUHJpdmF0ZSBmdW5jdGlvbnM6XHJcbiAqICAgICAtIENvbHVtbiBkZWZpbml0aW9uIGZ1bmN0aW9uc1xyXG4gKiAgICAgICAgIC0gX2dlbmVyYXRlQ29sRGVmc0Zyb21Db2xDb25maWcgKENvbERlZiBnZW5lcmF0aW9uIGJhc2VkIG9uIGNvbHVtbiBjb25maWcgLSBjaGVja3Mgbm9ybWFsIGNvbHVtbnMsIGlucHV0IGNvbHVtbiBhbmQgaW1hZ2UgY29sdW1ucylcclxuICogICAgICAgICAtIF9nZW5lcmF0ZUNvbERlZnNGcm9tQ29uZmlnIChDb2xEZWYgZ2VuZXJhdGlvbiBiYXNlZCBvbiBncmlkIGNvbmZpZyAtIGNoZWNrcyBhY3Rpb24gY29sdW1uIGFuZCBzZWxlY3Rpb24gY29sdW1uKVxyXG4gKiAgICAgICAgIC0gX2dlbmVyYXRlQWN0aW9uQ29sRGVmIChBY3Rpb24pXHJcbiAqICAgICAgICAgLSBfZ2VuZXJhdGVDaGVja2JveFJhZGlvQ29sRGVmIChTZWxlY3Rpb24pXHJcbiAqICAgICAgICAgLSBfZ2VuZXJhdGVJbWFnZUNvbERlZiAoSW1hZ2UpXHJcbiAqICAgICAgICAgLSBfZ2VuZXJhdGVJbnB1dENvbERlZiAoSW5wdXQpXHJcbiAqICAgICAtIEFQSSBnZW5lcmF0aW9uIGZ1bmN0aW9uc1xyXG4gKiAgICAgICAgIC0gX2dlbmVyYXRlSW5wdXRBcGkgKGFwaS5keW5hbWljRm9ybXMpXHJcbiAqICAgICAgICAgLSBfZ2VuZXJhdGVHZW5lcmFsQXBpIChhcGkuZ2VuZXJhbClcclxuICogICAgIC0gVGFibGUgaW5wdXQgZnVuY3Rpb25zXHJcbiAqICAgICAgICAgLSBfZ2VuZXJhdGVUYWJsZUlucHV0Q29udGV4dCAoTG9vcCBhbGwgY29sdW1ucyBhbmQgcm93cyBhbmQgZWFjaCBvZiB0aGUgcXVlc3Rpb24gdG8gZ2VuZXJhdGUgdGhlIGNvbnRleHQgZm9yIGlucHV0IGNvbHVtbnMpXHJcbiAqICAgICAtIFNlbGVjdGlvbiBmdW5jdGlvbnNcclxuICogICAgICAgICAtIF9jb252ZXJ0RGF0YVZhbHVlVG9PYmplY3QgKHNldCB0byBvYmplY3QgaWYgY29uZmlnIGNvbnNpc3Qgb2YgcmV0dXJuIGtleXMpXHJcbiAqICAgICAgICAgLSBfYXBwZW5kRGF0YVZhbHVlS2V5XHJcbiAqICAgICAtIE1pc2MgZnVuY3Rpb25zXHJcbiAqICAgICAgICAgLSBfdXBkYXRlRmlsdGVyQ29sRGVmXHJcbiAqICAgICAgICAgLSBfZ2V0RGVmYXVsdENvbHVtbkNvbmZpZ1xyXG4gKi9cclxuXHJcbkBJbmplY3RhYmxlKClcclxuZXhwb3J0IGFic3RyYWN0IGNsYXNzIEtkVGFibGVTdmNCYXNlIHtcclxuICAgIC8qKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKiBWYXJpYWJsZXMgKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqL1xyXG4gICAgcmVhZG9ubHkgUk9XX0hFSUdIVDogbnVtYmVyID0gMTUwO1xyXG4gICAgcmVhZG9ubHkgQ09OVEVYVF9ERUxJTUlURVI6IHN0cmluZyA9ICd+JztcclxuICAgIHJlYWRvbmx5IFRBQkxFX0lOUFVUX0NPTlRFWFRfS0VZOiBzdHJpbmcgPSAndGFibGVJbnB1dENvbnRleHQnO1xyXG4gICAgcmVhZG9ubHkgREVGQVVMVF9QQUdFU0laRTogbnVtYmVyID0gMjU7XHJcbiAgICByZWFkb25seSBJTUFHRV9QQURESU5HOiBudW1iZXIgPSAyMDtcclxuICAgIHJlYWRvbmx5IERFRkFVTFRfR1JJRElEOiBzdHJpbmcgPSAna2QtdGFibGUtZ3JpZCc7XHJcbiAgICByZWFkb25seSBHSVJEX1BBUkFNU19LRVk6IHsgW2tleTogc3RyaW5nXTogc3RyaW5nIH0gPSB7XHJcbiAgICAgICAgaW5wdXQ6ICdpbnB1dENvbmZpZycsXHJcbiAgICAgICAgaW1hZ2U6ICdpbWFnZUNvbmZpZydcclxuICAgIH07XHJcblxyXG4gICAgcHJvdGVjdGVkIGRhdGFTdmM6IEtkRGF0YVN2YyA9IG5ldyBLZERhdGFTdmMoKTtcclxuICAgIHByb3RlY3RlZCBncmlkT3B0aW9uczogR3JpZE9wdGlvbnM7XHJcbiAgICBwcm90ZWN0ZWQgZGlyZWN0aW9uOiAnbHRyJyB8ICdydGwnO1xyXG4gICAgcHJvdGVjdGVkIHJvd0tleTogc3RyaW5nID0gJ2lkJztcclxuXHJcbiAgICAvKioqKioqKioqKioqKioqIFB1YmxpYyBmdW5jdGlvbnMgKHNoYXJlZCBmb3IgYm90aCBzZXJ2aWNlcykgKioqKioqKioqKioqKioqKi9cclxuICAgIC8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vXHJcbiAgICAvLy8gQ2hlY2tpbmcgZnVuY3Rpb25zXHJcbiAgICAvLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vL1xyXG4gICAgcHVibGljIGlzQXBpUmVhZHkoX2dyaWRPcHRpb25zOiBHcmlkT3B0aW9ucyk6IGJvb2xlYW4ge1xyXG4gICAgICAgIGlmICh0eXBlb2YgX2dyaWRPcHRpb25zICE9PSAndW5kZWZpbmVkJyAmJlxyXG4gICAgICAgICAgICBfZ3JpZE9wdGlvbnMgIT09IG51bGwgJiZcclxuICAgICAgICAgICAgdHlwZW9mIF9ncmlkT3B0aW9ucy5hcGkgIT09ICd1bmRlZmluZWQnKSB7XHJcbiAgICAgICAgICAgIHJldHVybiB0cnVlO1xyXG4gICAgICAgIH1cclxuICAgICAgICByZXR1cm4gZmFsc2U7XHJcbiAgICB9XHJcblxyXG4gICAgcHVibGljIGhhc1NlbGVjdGlvbkFsbChfZ3JpZENvbmZpZzogSVRhYmxlQ29uZmlnKTogYm9vbGVhbiB7XHJcbiAgICAgICAgaWYgKHR5cGVvZiBfZ3JpZENvbmZpZyAhPT0gJ3VuZGVmaW5lZCcgJiZcclxuICAgICAgICAgICAgdHlwZW9mIF9ncmlkQ29uZmlnLnNlbGVjdGlvbiAhPT0gJ3VuZGVmaW5lZCcgJiZcclxuICAgICAgICAgICAgdHlwZW9mIF9ncmlkQ29uZmlnLnNlbGVjdGlvbi50eXBlICE9PSAndW5kZWZpbmVkJyAmJlxyXG4gICAgICAgICAgICBfZ3JpZENvbmZpZy5zZWxlY3Rpb24udHlwZSA9PT0gJ2FsbCcgJiZcclxuICAgICAgICAgICAgX2dyaWRDb25maWcubG9hZFR5cGUgIT09ICdpbmZpbml0ZScpIHtcclxuICAgICAgICAgICAgcmV0dXJuIHRydWU7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICByZXR1cm4gZmFsc2U7XHJcbiAgICB9XHJcblxyXG4gICAgcHVibGljIGhhc0lucHV0VHlwZShfdGFibGVDb2x1bW46IEFycmF5PElUYWJsZUNvbHVtbj4sIF90eXBlOiBzdHJpbmcpOiBib29sZWFuIHtcclxuICAgICAgICBpZiAodHlwZW9mIF90YWJsZUNvbHVtbiAhPT0gJ3VuZGVmaW5lZCcpIHtcclxuICAgICAgICAgICAgZm9yIChsZXQgaTogbnVtYmVyID0gMDsgaSA8IF90YWJsZUNvbHVtbi5sZW5ndGg7ICsraSkge1xyXG4gICAgICAgICAgICAgICAgaWYgKHRoaXMuaXNJbnB1dFR5cGUoX3RhYmxlQ29sdW1uW2ldLCBfdHlwZSkpIHtcclxuICAgICAgICAgICAgICAgICAgICByZXR1cm4gdHJ1ZTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgcmV0dXJuIGZhbHNlO1xyXG4gICAgfVxyXG5cclxuICAgIHB1YmxpYyBpc0lucHV0VHlwZShfY29sdW1uOiBJVGFibGVDb2x1bW4sIF90eXBlOiBzdHJpbmcpOiBib29sZWFuIHtcclxuICAgICAgICByZXR1cm4gKHR5cGVvZiBfY29sdW1uLnR5cGUgIT09ICd1bmRlZmluZWQnICYmIF9jb2x1bW4udHlwZSA9PT0gX3R5cGUpO1xyXG4gICAgfVxyXG5cclxuICAgIHB1YmxpYyBpc0VudGVycHJpc2VNb2RlbChfbG9hZFR5cGU6IHN0cmluZyk6IGJvb2xlYW4ge1xyXG4gICAgICAgIHJldHVybiAoX2xvYWRUeXBlID09PSAnb25lc2hvdCcgfHwgX2xvYWRUeXBlID09PSAnaW5maW5pdGUnIHx8IF9sb2FkVHlwZSA9PT0gJ3NlcnZlcicpO1xyXG4gICAgfVxyXG5cclxuICAgIC8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vXHJcbiAgICAvLy8gU2VsZWN0aW9uIGZ1bmN0aW9uc1xyXG4gICAgLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy9cclxuICAgIHB1YmxpYyB1cGRhdGVTZWxlY3REZWZhdWx0VmFsdWUoX2dyaWRDb25maWc6IElUYWJsZUNvbmZpZyk6IHZvaWQge1xyXG4gICAgICAgIGlmICh0eXBlb2YgX2dyaWRDb25maWcuc2VsZWN0aW9uICE9PSAndW5kZWZpbmVkJykge1xyXG4gICAgICAgICAgICBpZiAodHlwZW9mIF9ncmlkQ29uZmlnLnNlbGVjdGlvbi52YWx1ZSA9PT0gJ3VuZGVmaW5lZCcpIHtcclxuICAgICAgICAgICAgICAgIF9ncmlkQ29uZmlnLnNlbGVjdGlvbi52YWx1ZSA9IFtdO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIGVsc2UgaWYgKF9ncmlkQ29uZmlnLnNlbGVjdGlvbi50eXBlID09PSAnc2luZ2xlJyAmJiBfZ3JpZENvbmZpZy5zZWxlY3Rpb24udmFsdWUubGVuZ3RoID4gMSkge1xyXG4gICAgICAgICAgICAgICAgY29uc29sZS53YXJuKCdLZFRhYmxlIHdhcm5pbmc6IFNpbmdsZSBzZWxlY3Rpb24gdHlwZSBjb250YWlucyBtb3JlIHRoYW4gMSBkZWZhdWx0IHZhbHVlcy4nKTtcclxuICAgICAgICAgICAgICAgIF9ncmlkQ29uZmlnLnNlbGVjdGlvbi52YWx1ZSA9IF9ncmlkQ29uZmlnLnNlbGVjdGlvbi52YWx1ZS5zbGljZSgwLCAxKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICAvKipcclxuICAgICAqIFt1cGRhdGVTZWxlY3Rpb25WYWx1ZXMoKSAtIFJldHVybnMgdGhlIHNlbGVjdGVkIG5vZGVzIGJhc2VkIG9uIHRoZSByZXR1cm5LZXkgc3BlY2lmeS5cclxuICAgICAqICBJZiBpcyBub3Qgc3BlY2lmeSwgYXJyYXkgb2YgaWRzIHdpbGwgYmUgcmV0dXJuIG9uIHNlbGVjdGlvbi5cclxuICAgICAqICBPbmx5IHdvcmtzIGZvciBub3JtYWwsIGluZmluaXRlIGFuZCBvbmVzaG90IGxvYWRUeXBlLlxyXG4gICAgICogICAgIC0gTm90IHNwZWNpZnkgLSBSZXR1cm4gWyAxLCAyLCAzIF07XHJcbiAgICAgKiAgICAgLSBTcGVjaWZ5ICAgICAtIFJldHVybiBbIHtpZDogMSwgZ3JhZGU6IFwiMVwiIH0sIHtpZDogMiwgZ3JhZGU6IFwiMVwifSwge2lkOiAzLCBncmFkZTogXCIyXCJ9XVxyXG4gICAgICogXVxyXG4gICAgICogX3Jvd0RhdGEgICAgICAgOiBbQ3VycmVudCBwcm92aWRlZCByb3dEYXRhXVxyXG4gICAgICogX3NlbGVjdGVkSWRzICAgOiBbQ3VycmVudCBzZWxlY3RlZCByb3dEYXRhIGlkc11cclxuICAgICAqIF9yZXR1cm5LZXkgICAgIDogW0xpc3Qgb2YgcHJvcGVydHkga2V5cyB0byByZXR1cm4gd2l0aCBpZF1cclxuICAgICAqIFtHZW5lcmF0ZWQgc2VsZWN0aW9uIGJ5IHJldHVybktleV1cclxuICAgICAqL1xyXG4gICAgcHVibGljIHVwZGF0ZVNlbGVjdGlvblZhbHVlcyhfcm93RGF0YTogQXJyYXk8YW55PiwgX3NlbGVjdGVkSWRzOiBBcnJheTxzdHJpbmcgfCBudW1iZXI+LCBfcmV0dXJuS2V5OiBBcnJheTxzdHJpbmc+LCBfbG9hZFR5cGU/OiBzdHJpbmcpOiBBcnJheTxhbnk+IHtcclxuICAgICAgICBpZiAodHlwZW9mIF9yZXR1cm5LZXkgPT09ICd1bmRlZmluZWQnIHx8XHJcbiAgICAgICAgICAgIF9yZXR1cm5LZXkgPT09IG51bGwgfHxcclxuICAgICAgICAgICAgX3JldHVybktleS5sZW5ndGggPT09IDApIHtcclxuICAgICAgICAgICAgcmV0dXJuIF9zZWxlY3RlZElkcztcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIGxldCBnZW5lcmF0ZWRTZWxlY3Rpb246IEFycmF5PGFueT4gPSBbXTtcclxuXHJcbiAgICAgICAgZm9yIChsZXQgaTogbnVtYmVyID0gMDsgaSA8IF9yb3dEYXRhLmxlbmd0aDsgaSsrKSB7XHJcbiAgICAgICAgICAgIGxldCBkYXRhSXRlbTogYW55ID0gX3Jvd0RhdGFbaV07XHJcbiAgICAgICAgICAgIGxldCBvbmVJdGVtOiBhbnkgPSB7fTtcclxuXHJcbiAgICAgICAgICAgIGlmIChfc2VsZWN0ZWRJZHMuaW5kZXhPZihkYXRhSXRlbVt0aGlzLnJvd0tleV0pID4gLTEpIHtcclxuICAgICAgICAgICAgICAgIG9uZUl0ZW1bdGhpcy5yb3dLZXldID0gZGF0YUl0ZW1bdGhpcy5yb3dLZXldO1xyXG5cclxuICAgICAgICAgICAgICAgIGZvciAobGV0IGo6IG51bWJlciA9IDA7IGogPCBfcmV0dXJuS2V5Lmxlbmd0aDsgaisrKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKGRhdGFJdGVtLmhhc093blByb3BlcnR5KF9yZXR1cm5LZXlbal0pKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG9uZUl0ZW1bX3JldHVybktleVtqXV0gPSBkYXRhSXRlbVtfcmV0dXJuS2V5W2pdXTtcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgZWxzZSBpZiAoX3JldHVybktleVtqXS5pbmRleE9mKCcuJykgPiAwKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGxldCByZXR1cm5WYWw6IGFueSA9IHRoaXMuZGF0YVN2Yy5nZXREYXRhVmFsdWUoZGF0YUl0ZW0sIF9yZXR1cm5LZXlbal0pO1xyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgaWYgKHJldHVyblZhbCAhPT0gbnVsbCkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgbGV0IG5ld0l0ZW06IGFueSA9ICg8YW55Pk9iamVjdCkuYXNzaWduKHt9LCBvbmVJdGVtKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uZUl0ZW0gPSB0aGlzLl9jb252ZXJ0RGF0YVZhbHVlVG9PYmplY3QobmV3SXRlbSwgX3JldHVybktleVtqXSwgcmV0dXJuVmFsKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgICAgICBnZW5lcmF0ZWRTZWxlY3Rpb24ucHVzaChvbmVJdGVtKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgcmV0dXJuIGdlbmVyYXRlZFNlbGVjdGlvbjtcclxuICAgIH1cclxuXHJcbiAgICAvLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vL1xyXG4gICAgLy8vIEdyaWQgQnV0dG9uIGZ1bmN0aW9uc1xyXG4gICAgLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy9cclxuICAgIHB1YmxpYyB1cGRhdGVHcmlkQnV0dG9ucyhfZ3JpZENvbmZpZzogSVRhYmxlQ29uZmlnKTogdm9pZCB7XHJcbiAgICAgICAgaWYgKHR5cGVvZiBfZ3JpZENvbmZpZy5idXR0b24gPT09ICd1bmRlZmluZWQnKSB7XHJcbiAgICAgICAgICAgIF9ncmlkQ29uZmlnLmJ1dHRvbiA9IFtdO1xyXG4gICAgICAgIH1cclxuICAgICAgICBlbHNlIGlmIChfZ3JpZENvbmZpZy5idXR0b24ubGVuZ3RoID4gNCkge1xyXG4gICAgICAgICAgICBjb25zb2xlLndhcm4oJ0tkVGFibGUgd2FybmluZzogTWF4IDQgYnV0dG9ucyBmb3IgdGFibGUuIFNsaWNpbmcgdG8gNC4nKTtcclxuICAgICAgICAgICAgX2dyaWRDb25maWcuYnV0dG9uID0gX2dyaWRDb25maWcuYnV0dG9uLnNsaWNlKDAsIDQpO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICAvLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vL1xyXG4gICAgLy8vIFRhYmxlIElucHV0IGZ1bmN0aW9uc1xyXG4gICAgLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy9cclxuICAgIHB1YmxpYyB1cGRhdGVSb3dEYXRhV2l0aENvbHVtbihfcm93RGF0YTogQXJyYXk8YW55PiwgX2NvbHVtbkNvbmZpZzogQXJyYXk8SVRhYmxlQ29sdW1uPiwgX2dyaWRJZDogc3RyaW5nLCBfZ3JpZE9wdGlvbnM6IEdyaWRPcHRpb25zKTogdm9pZCB7XHJcbiAgICAgICAgaWYgKHRoaXMuaGFzSW5wdXRUeXBlKF9jb2x1bW5Db25maWcsICdpbnB1dCcpKSB7XHJcbiAgICAgICAgICAgIGlmICh0eXBlb2YgX2dyaWRPcHRpb25zLmNvbnRleHRbdGhpcy5UQUJMRV9JTlBVVF9DT05URVhUX0tFWV0gPT09ICd1bmRlZmluZWQnKSB7XHJcbiAgICAgICAgICAgICAgICBfZ3JpZE9wdGlvbnMuY29udGV4dFt0aGlzLlRBQkxFX0lOUFVUX0NPTlRFWFRfS0VZXSA9IHt9O1xyXG4gICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICBsZXQgaW5wdXRDb250ZXh0OiBhbnkgPSB0aGlzLl9nZW5lcmF0ZVRhYmxlSW5wdXRDb250ZXh0KF9jb2x1bW5Db25maWcsIF9yb3dEYXRhLCBfZ3JpZElkKTtcclxuICAgICAgICAgICAgX2dyaWRPcHRpb25zLmNvbnRleHRbdGhpcy5UQUJMRV9JTlBVVF9DT05URVhUX0tFWV0gPSAoPGFueT5PYmplY3QpLmFzc2lnbihfZ3JpZE9wdGlvbnMuY29udGV4dFt0aGlzLlRBQkxFX0lOUFVUX0NPTlRFWFRfS0VZXSwgaW5wdXRDb250ZXh0KTtcclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy9cclxuICAgIC8vLyBBUEkgR2VuZXJhdGlvbiBmdW5jdGlvblxyXG4gICAgLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy9cclxuICAgIHB1YmxpYyBnZW5lcmF0ZWRBcGlGdW5jdGlvbnMoX2dyaWRBcGk6IElUYWJsZUFwaSwgX2FwaVBhcmFtczogYW55KTogdm9pZCB7XHJcbiAgICAgICAgX2dyaWRBcGkuZHluYW1pY0Zvcm0gPSB0aGlzLl9nZW5lcmF0ZUlucHV0QXBpKF9hcGlQYXJhbXMuaWQsIF9hcGlQYXJhbXMuZXZlbnQpO1xyXG4gICAgICAgIF9ncmlkQXBpLmdlbmVyYWwgPSB0aGlzLl9nZW5lcmF0ZUdlbmVyYWxBcGkoX2FwaVBhcmFtcy5yb3dzKTtcclxuICAgIH1cclxuXHJcbiAgICAvLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vL1xyXG4gICAgLy8vIE1pc2MgZnVuY3Rpb25cclxuICAgIC8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vXHJcbiAgICBwdWJsaWMgZ2V0R3JpZElkKF9ncmlkQ29uZmlnOiBJVGFibGVDb25maWcpOiBzdHJpbmcge1xyXG4gICAgICAgIGlmICh0eXBlb2YgX2dyaWRDb25maWcuaWQgPT09ICd1bmRlZmluZWQnKSB7XHJcbiAgICAgICAgICAgIF9ncmlkQ29uZmlnLmlkID0gdGhpcy5ERUZBVUxUX0dSSURJRDtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIHJldHVybiBfZ3JpZENvbmZpZy5pZDtcclxuICAgIH1cclxuXHJcbiAgICBwdWJsaWMgZ2V0SW1hZ2VTaXplQnkoX3RhYmxlQ29sdW1uOiBJVGFibGVDb2x1bW4sIF9kaW1lbnNpb246ICd3aWR0aCcgfCAnaGVpZ2h0Jyk6IG51bWJlciB7XHJcbiAgICAgICAgLy8gRGVmYXVsdCBwbGFjZWhvbGRlciB3aWR0aCAxNTAgKyAyMCBnYXBcclxuICAgICAgICBsZXQgd2lkdGg6IG51bWJlciA9IDE1MCArIHRoaXMuSU1BR0VfUEFERElORztcclxuXHJcbiAgICAgICAgaWYgKHR5cGVvZiBfdGFibGVDb2x1bW4uY29uZmlnICE9PSAndW5kZWZpbmVkJyAmJlxyXG4gICAgICAgICAgICB0eXBlb2YgX3RhYmxlQ29sdW1uLmNvbmZpZy5pbWFnZSAhPT0gJ3VuZGVmaW5lZCcgJiZcclxuICAgICAgICAgICAgdHlwZW9mIF90YWJsZUNvbHVtbi5jb25maWcuaW1hZ2VbX2RpbWVuc2lvbl0gIT09ICd1bmRlZmluZWQnKSB7XHJcbiAgICAgICAgICAgIHdpZHRoID0gX3RhYmxlQ29sdW1uLmNvbmZpZy5pbWFnZVtfZGltZW5zaW9uXSArIHRoaXMuSU1BR0VfUEFERElORztcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIHJldHVybiB3aWR0aDtcclxuICAgIH1cclxuXHJcbiAgICBwdWJsaWMgZ2V0VGFibGVDb250ZXh0S2V5KCk6IHN0cmluZyB7XHJcbiAgICAgICAgcmV0dXJuIHRoaXMuVEFCTEVfSU5QVVRfQ09OVEVYVF9LRVk7XHJcbiAgICB9XHJcblxyXG4gICAgcHVibGljIGdldFJvdXRlclBsYWNlaG9sZGVyUGF0aChfcm93Tm9kZTogUm93Tm9kZSwgX3BhdGg6IHN0cmluZyk6IHN0cmluZyB7XHJcbiAgICAgICAgcmV0dXJuIHRoaXMuZGF0YVN2Yy5nZXRQbGFjZWhvbGRlcihfcm93Tm9kZS5kYXRhLCBfcGF0aCk7XHJcbiAgICB9XHJcblxyXG4gICAgcHVibGljIGI2NHRvQmxvYihiNjREYXRhOiBhbnksIGNvbnRlbnRUeXBlOiBzdHJpbmcpOiBCbG9iIHtcclxuICAgICAgICBsZXQgc2xpY2VTaXplOiBudW1iZXIgPSA1MTI7XHJcblxyXG4gICAgICAgIGxldCBieXRlQ2hhcmFjdGVyczogYW55ID0gYXRvYihiNjREYXRhKTtcclxuICAgICAgICBsZXQgYnl0ZUFycmF5czogYW55W10gPSBbXTtcclxuXHJcbiAgICAgICAgZm9yIChsZXQgb2Zmc2V0ID0gMDsgb2Zmc2V0IDwgYnl0ZUNoYXJhY3RlcnMubGVuZ3RoOyBvZmZzZXQgKz0gc2xpY2VTaXplKSB7XHJcbiAgICAgICAgICAgIGxldCBzbGljZTogYW55ID0gYnl0ZUNoYXJhY3RlcnMuc2xpY2Uob2Zmc2V0LCBvZmZzZXQgKyBzbGljZVNpemUpO1xyXG5cclxuICAgICAgICAgICAgbGV0IGJ5dGVOdW1iZXJzOiBhbnlbXSA9IG5ldyBBcnJheShzbGljZS5sZW5ndGgpO1xyXG4gICAgICAgICAgICBmb3IgKGxldCBpID0gMDsgaSA8IHNsaWNlLmxlbmd0aDsgaSsrKSB7XHJcbiAgICAgICAgICAgICAgICBieXRlTnVtYmVyc1tpXSA9IHNsaWNlLmNoYXJDb2RlQXQoaSk7XHJcbiAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgIGxldCBieXRlQXJyYXk6IFVpbnQ4QXJyYXkgPSBuZXcgVWludDhBcnJheShieXRlTnVtYmVycyk7XHJcblxyXG4gICAgICAgICAgICBieXRlQXJyYXlzLnB1c2goYnl0ZUFycmF5KTtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIGxldCBibG9iOiBCbG9iID0gbmV3IEJsb2IoYnl0ZUFycmF5cywgeyB0eXBlOiBjb250ZW50VHlwZSB9KTtcclxuICAgICAgICByZXR1cm4gYmxvYjtcclxuICAgIH1cclxuXHJcbiAgICAvKioqKioqKioqKiBFbmQgb2YgcHVibGljIGZ1bmN0aW9ucyAvIFN0YXJ0IG9mIHByb3RlY3RlZCBmdW5jdGlvbnMgKioqKioqKioqKi9cclxuICAgIC8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vXHJcbiAgICAvLy8gR3JpZCBPcHRpb25zIGZ1bmN0aW9uc1xyXG4gICAgLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy9cclxuICAgIHByb3RlY3RlZCBnZXREZWZhdWx0R3JpZE9wdGlvbnMoX2RpcmVjdGlvbjogJ2x0cicgfCAncnRsJywgX3Jvd0hlaWdodDogbnVtYmVyKTogR3JpZE9wdGlvbnMge1xyXG4gICAgICAgIHRoaXMuZGlyZWN0aW9uID0gX2RpcmVjdGlvbjtcclxuXHJcbiAgICAgICAgcmV0dXJuIHtcclxuICAgICAgICAgICAgcm93RGF0YTogW10sXHJcbiAgICAgICAgICAgIGNvbHVtbkRlZnM6IFtdLFxyXG4gICAgICAgICAgICBlbmFibGVSdGw6IF9kaXJlY3Rpb24gPT09ICdydGwnLFxyXG5cclxuICAgICAgICAgICAgaGVhZGVySGVpZ2h0OiAzOCxcclxuICAgICAgICAgICAgcm93SGVpZ2h0OiAodHlwZW9mIF9yb3dIZWlnaHQgIT09ICd1bmRlZmluZWQnKSA/IF9yb3dIZWlnaHQgKyAyMCA6IHRoaXMuUk9XX0hFSUdIVCxcclxuXHJcbiAgICAgICAgICAgIC8vIHN1cHByZXNzTW92YWJsZUNvbHVtbnM6IHRydWUsXHJcbiAgICAgICAgICAgIHN1cHByZXNzRHJhZ0xlYXZlSGlkZXNDb2x1bW5zOiB0cnVlLFxyXG4gICAgICAgICAgICBlbmFibGVDb2xSZXNpemU6IHRydWUsXHJcblxyXG4gICAgICAgICAgICBzdXBwcmVzc0NvbnRleHRNZW51OiB0cnVlLFxyXG4gICAgICAgICAgICBzdXBwcmVzc01lbnVIaWRlOiB0cnVlLFxyXG4gICAgICAgICAgICBlbnN1cmVEb21PcmRlcjogdHJ1ZSxcclxuXHJcbiAgICAgICAgICAgIHN1cHByZXNzUHJvcGVydHlOYW1lc0NoZWNrOiB0cnVlLFxyXG5cclxuICAgICAgICAgICAgLy8gc3VwcHJlc3NDb2x1bW5WaXJ0dWFsaXNhdGlvbjogdHJ1ZSxcclxuXHJcbiAgICAgICAgICAgIGFuaW1hdGVSb3dzOiBmYWxzZSxcclxuICAgICAgICAgICAgcm93QnVmZmVyOiA1LFxyXG5cclxuICAgICAgICAgICAgZ2V0Um93Tm9kZUlkOiAoX2RhdGE6IGFueSk6IHN0cmluZyA9PiB7XHJcbiAgICAgICAgICAgICAgICBsZXQgaWQ6IHN0cmluZyA9IF9kYXRhLmlkO1xyXG5cclxuICAgICAgICAgICAgICAgIGlmICh0eXBlb2YgX2RhdGEuaWQgPT09ICdudW1iZXInKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgaWQgPSBpZC50b1N0cmluZygpO1xyXG4gICAgICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgICAgIHJldHVybiBpZDtcclxuICAgICAgICAgICAgfSxcclxuXHJcbiAgICAgICAgICAgIHVuU29ydEljb246IHRydWUsXHJcbiAgICAgICAgICAgIGljb25zOiB7XHJcbiAgICAgICAgICAgICAgICBmaWx0ZXI6ICc8aSBjbGFzcz1cImZhIGZhLWZpbHRlclwiLz4nLFxyXG4gICAgICAgICAgICAgICAgc29ydEFzY2VuZGluZzogJzxpIGNsYXNzPVwiZmEgZmEtY2FyZXQtZG93blwiLz4nLFxyXG4gICAgICAgICAgICAgICAgc29ydERlc2NlbmRpbmc6ICc8aSBjbGFzcz1cImZhIGZhLWNhcmV0LXVwXCIvPicsXHJcbiAgICAgICAgICAgICAgICBzb3J0VW5Tb3J0OiAnPGkgY2xhc3M9XCJmYSBmYS1zb3J0XCIvPicsXHJcbiAgICAgICAgICAgICAgICAvLyBncm91cEV4cGFuZGVkOiAnPGkgY2xhc3M9XCJmYSBmYS1taW51cy1jaXJjbGVcIi8+JyxcclxuICAgICAgICAgICAgICAgIC8vIGdyb3VwQ29udHJhY3RlZDogJzxpIGNsYXNzPVwiZmEgZmEtcGx1cy1jaXJjbGVcIi8+JyxcclxuICAgICAgICAgICAgICAgIGdyb3VwRXhwYW5kZWQ6ICc8aSBjbGFzcz1cImZhIGZhLWFuZ2xlLWRvd25cIi8+JyxcclxuICAgICAgICAgICAgICAgIGdyb3VwQ29udHJhY3RlZDogJzxpIGNsYXNzPVwiZmEgZmEtYW5nbGUtcmlnaHRcIi8+JyxcclxuXHJcbiAgICAgICAgICAgICAgICBtZW51OiAnPGkgY2xhc3M9XCJmYSBmYS1iYXJzXCIvPidcclxuICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgYXV0b0dyb3VwQ29sdW1uRGVmOiB7XHJcbiAgICAgICAgICAgICAgICBpY29uczoge1xyXG4gICAgICAgICAgICAgICAgICAgIG1lbnU6ICc8aSBjbGFzcz1cImZhIGZhLWJhclwiIHN0eWxlPVwiZGlzcGxheTpub25lXCIvPicsXHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgIGNvbnRleHQ6IHt9LFxyXG4gICAgICAgICAgICBvdmVybGF5Tm9Sb3dzVGVtcGxhdGU6ICc8c3BhbiBjbGFzcz1cImFnLWN1c3RvbS1vdmVybGF5XCI+PGkgY2xhc3M9XCJmYSBmYS1pbmZvLWNpcmNsZSBmYS1sZyBtYXJnaW4tcmlnaHQxMFwiPjwvaT5ObyByZWNvcmQgZm91bmQ8L3NwYW4+J1xyXG4gICAgICAgIH07XHJcbiAgICB9XHJcblxyXG4gICAgLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy9cclxuICAgIC8vLyBDb2x1bW4gRGVmaW5pdGlvbiBmdW5jdGlvbnNcclxuICAgIC8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vXHJcbiAgICBwcm90ZWN0ZWQgZ2VuZXJhdGVDb2x1bW5EZWZpbml0aW9ucyhfY29sdW1uQ29uZmlnOiBBcnJheTxJVGFibGVDb2x1bW4+LCBfZ3JpZENvbmZpZzogSVRhYmxlQ29uZmlnLCBfc3VwcHJlc3NNb3ZhYmxlQ29sdW1uczogYm9vbGVhbj0gdHJ1ZSk6IEFycmF5PENvbERlZj4ge1xyXG4gICAgICAgIGxldCBjb2x1bW5EZWY6IEFycmF5PENvbERlZj4gPSB0aGlzLl9nZW5lcmF0ZUNvbERlZnNGcm9tQ29sQ29uZmlnKF9jb2x1bW5Db25maWcsIF9ncmlkQ29uZmlnLCBfc3VwcHJlc3NNb3ZhYmxlQ29sdW1ucyk7XHJcbiAgICAgICAgbGV0IGNvbHVtbk9iamVjdHM6IHsgW2tleTogc3RyaW5nXTogQ29sRGVmIH0gPSB0aGlzLl9nZW5lcmF0ZUNvbERlZnNGcm9tQ29uZmlnKF9ncmlkQ29uZmlnKTtcclxuXHJcbiAgICAgICAgaWYgKGNvbHVtbk9iamVjdHMuaGFzT3duUHJvcGVydHkoJ2FjdGlvbicpKSB7XHJcbiAgICAgICAgICAgIGNvbHVtbkRlZi5wdXNoKGNvbHVtbk9iamVjdHMuYWN0aW9uKTtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIGlmIChjb2x1bW5PYmplY3RzLmhhc093blByb3BlcnR5KCdzZWxlY3Rpb24nKSkge1xyXG4gICAgICAgICAgICBjb2x1bW5EZWYudW5zaGlmdChjb2x1bW5PYmplY3RzLnNlbGVjdGlvbik7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICByZXR1cm4gY29sdW1uRGVmO1xyXG4gICAgfVxyXG5cclxuICAgIHByb3RlY3RlZCBpc0NvbERlZk9mVHlwZShfY29sRGVmOiBDb2xEZWYsIF90eXBlOiBzdHJpbmcpOiBib29sZWFuIHtcclxuICAgICAgICBpZiAodHlwZW9mIF9jb2xEZWYuY2VsbFJlbmRlcmVyUGFyYW1zICE9PSAndW5kZWZpbmVkJyAmJlxyXG4gICAgICAgICAgICB0eXBlb2YgX2NvbERlZi5jZWxsUmVuZGVyZXJQYXJhbXMucGFyYW1zICE9PSAndW5kZWZpbmVkJyAmJlxyXG4gICAgICAgICAgICB0eXBlb2YgX2NvbERlZi5jZWxsUmVuZGVyZXJQYXJhbXMucGFyYW1zW190eXBlXSAhPT0gJ3VuZGVmaW5lZCcpIHtcclxuICAgICAgICAgICAgcmV0dXJuIHRydWU7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICByZXR1cm4gZmFsc2U7XHJcbiAgICB9XHJcblxyXG4gICAgLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy9cclxuICAgIC8vLyBNaXNjIGZ1bmN0aW9uXHJcbiAgICAvLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vL1xyXG4gICAgcHJvdGVjdGVkIGdlbmVyYXRlQ29udGV4dEtleShfZ3JpZElkOiBzdHJpbmcsIF9jb2x1bW5JZDogc3RyaW5nLCBfcm93SWQ6IHN0cmluZyB8IG51bWJlcik6IHN0cmluZyB7XHJcbiAgICAgICAgcmV0dXJuIF9ncmlkSWQgKyB0aGlzLkNPTlRFWFRfREVMSU1JVEVSICsgX2NvbHVtbklkICsgdGhpcy5DT05URVhUX0RFTElNSVRFUiArIF9yb3dJZDtcclxuICAgIH1cclxuXHJcbiAgICAvKioqKioqKioqKiBFbmQgb2YgcHJvdGVjdGVkIGZ1bmN0aW9ucyAvIFN0YXJ0IG9mIHByaXZhdGUgZnVuY3Rpb25zICoqKioqKioqKiovXHJcbiAgICAvLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vL1xyXG4gICAgLy8vIENvbERlZiAtIENvbHVtbiBkZWZpbml0aW9uIGZ1bmN0aW9uc1xyXG4gICAgLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy9cclxuICAgIHByaXZhdGUgX2dlbmVyYXRlQ29sRGVmc0Zyb21Db2xDb25maWcoX2NvbHVtbkNvbmZpZzogQXJyYXk8SVRhYmxlQ29sdW1uPiwgX2dyaWRDb25maWc6IElUYWJsZUNvbmZpZywgX3N1cHByZXNzTW92YWJsZUNvbHVtbnM6IGJvb2xlYW4gPSB0cnVlKTogQXJyYXk8Q29sRGVmPiB7XHJcbiAgICAgICAgbGV0IGNvbHVtbkRlZjogQXJyYXk8Q29sRGVmPiA9IFtdO1xyXG5cclxuICAgICAgICBmb3IgKGxldCBpOiBudW1iZXIgPSAwOyBpIDwgX2NvbHVtbkNvbmZpZy5sZW5ndGg7IGkrKykge1xyXG4gICAgICAgICAgICBsZXQgY29sdW1uOiBDb2xEZWYgPSB7fTtcclxuXHJcbiAgICAgICAgICAgIGlmICh0eXBlb2YgX2NvbHVtbkNvbmZpZ1tpXSAhPT0gJ3VuZGVmaW5lZCcpIHtcclxuICAgICAgICAgICAgICAgIGxldCB0ZW1wQ29sdW1uOiBJVGFibGVDb2x1bW4gPSAoPGFueT5PYmplY3QpLmFzc2lnbih0aGlzLl9nZXREZWZhdWx0Q29sdW1uQ29uZmlnKCksIF9jb2x1bW5Db25maWdbaV0pO1xyXG4gICAgICAgICAgICAgICAgdGVtcENvbHVtbi5zdXBwcmVzc01vdmFibGUgPSBfc3VwcHJlc3NNb3ZhYmxlQ29sdW1ucztcclxuXHJcbiAgICAgICAgICAgICAgICBzd2l0Y2ggKHRlbXBDb2x1bW4udHlwZSkge1xyXG4gICAgICAgICAgICAgICAgICAgIGNhc2UgJ2lucHV0JzpcclxuICAgICAgICAgICAgICAgICAgICAgICAgY29sdW1uID0gdGhpcy5fZ2VuZXJhdGVJbnB1dENvbERlZih0ZW1wQ29sdW1uLCBfZ3JpZENvbmZpZy5pZCk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgICAgICAgICAgICAgIGNhc2UgJ2ltYWdlJzpcclxuICAgICAgICAgICAgICAgICAgICAgICAgY29sdW1uID0gdGhpcy5fZ2VuZXJhdGVJbWFnZUNvbERlZih0ZW1wQ29sdW1uKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgICAgICAgICAgICAgZGVmYXVsdDpcclxuICAgICAgICAgICAgICAgICAgICAgICAgLy8gVEVNUCBmaXggZm9yIHBpdm90XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC8vIHZhbHVlIGFzc2lnbm1lbnQgaW5zdGVhZCBvZiBvYmplY3QgZGlyZWN0IGFzc2lnbm1lbnQgc28gdG8gYWxsb3cgYXBwbGljYXRpb24gdG8gcGFzcyBpbiBvdGhlciBjb2xkZWZcclxuICAgICAgICAgICAgICAgICAgICAgICAgY29sdW1uID0gdGVtcENvbHVtbjtcclxuICAgICAgICAgICAgICAgICAgICAgICAgY29sdW1uLmhlYWRlck5hbWUgPSB0ZW1wQ29sdW1uLmhlYWRlck5hbWU7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbHVtbi5jb2xJZCA9IHRlbXBDb2x1bW4uZmllbGQ7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbHVtbi5maWVsZCA9IHRlbXBDb2x1bW4uZmllbGQ7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbHVtbi5jZWxsQ2xhc3MgPSAnbm9ybWFsLWNlbGwgJyArIHRlbXBDb2x1bW4uY2xhc3M7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbHVtbi5oaWRlID0gIXRlbXBDb2x1bW4udmlzaWJsZTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgY29sdW1uLnN1cHByZXNzTWVudSA9ICF0ZW1wQ29sdW1uLmZpbHRlcmFibGU7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbHVtbi5zdXBwcmVzc1NvcnRpbmcgPSAhdGVtcENvbHVtbi5zb3J0YWJsZTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgY29sdW1uLm1pbldpZHRoID0gMTAwO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBjb2x1bW4uc3VwcHJlc3NNb3ZhYmxlID0gdGVtcENvbHVtbi5zdXBwcmVzc01vdmFibGU7XHJcbiAgICAgICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICAgICAgaWYgKHRlbXBDb2x1bW4uZmlsdGVyYWJsZSkge1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuX3VwZGF0ZUZpbHRlckNvbERlZihjb2x1bW4sIHRlbXBDb2x1bW4uZmlsdGVyVmFsdWUpO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIGNvbHVtbkRlZi5wdXNoKGNvbHVtbik7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICByZXR1cm4gY29sdW1uRGVmO1xyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX2dlbmVyYXRlQ29sRGVmc0Zyb21Db25maWcoX2NvbmZpZzogSVRhYmxlQ29uZmlnKTogeyBba2V5OiBzdHJpbmddOiBDb2xEZWYgfSB7XHJcbiAgICAgICAgbGV0IGNvbERlZk9iamVjdDogeyBba2V5OiBzdHJpbmddOiBDb2xEZWYgfSA9IHt9O1xyXG5cclxuICAgICAgICBpZiAodHlwZW9mIF9jb25maWcgIT09ICd1bmRlZmluZWQnICYmXHJcbiAgICAgICAgICAgIHR5cGVvZiBfY29uZmlnLmFjdGlvbiAhPT0gJ3VuZGVmaW5lZCcgJiZcclxuICAgICAgICAgICAgX2NvbmZpZy5hY3Rpb24uZW5hYmxlZCkge1xyXG4gICAgICAgICAgICBjb2xEZWZPYmplY3QuYWN0aW9uID0gdGhpcy5fZ2VuZXJhdGVBY3Rpb25Db2xEZWYoX2NvbmZpZy5pZCwgX2NvbmZpZy5hY3Rpb24ubGlzdCwgX2NvbmZpZy5hY3Rpb24ubmFtZSk7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICBpZiAodHlwZW9mIF9jb25maWcgIT09ICd1bmRlZmluZWQnICYmXHJcbiAgICAgICAgICAgIHR5cGVvZiBfY29uZmlnLnNlbGVjdGlvbiAhPT0gJ3VuZGVmaW5lZCcgJiZcclxuICAgICAgICAgICAgdHlwZW9mIF9jb25maWcuc2VsZWN0aW9uLnR5cGUgIT09ICd1bmRlZmluZWQnKSB7XHJcbiAgICAgICAgICAgIGNvbERlZk9iamVjdC5zZWxlY3Rpb24gPSB0aGlzLl9nZW5lcmF0ZUNoZWNrYm94UmFkaW9Db2xEZWYoX2NvbmZpZy5zZWxlY3Rpb24sIF9jb25maWcuaWQpO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgcmV0dXJuIGNvbERlZk9iamVjdDtcclxuICAgIH1cclxuXHJcbiAgICAvLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vL1xyXG4gICAgLy8vIENvbERlZiAtIEFjdGlvbiBkcm9wZG93biBmdW5jdGlvbnNcclxuICAgIC8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vXHJcbiAgICBwcml2YXRlIF9nZW5lcmF0ZUFjdGlvbkNvbERlZihfaWQ6IHN0cmluZywgX2xpc3Q6IEFycmF5PElUYWJsZURyb3Bkb3duQWN0aW9uPiwgX25hbWU/OiBzdHJpbmcpOiBDb2xEZWYge1xyXG4gICAgICAgIHJldHVybiB7XHJcbiAgICAgICAgICAgIGhlYWRlck5hbWU6ICh0eXBlb2YgX25hbWUgIT09ICd1bmRlZmluZWQnKSA/IF9uYW1lIDogJ0FjdGlvbicsXHJcbiAgICAgICAgICAgIHN1cHByZXNzU29ydGluZzogdHJ1ZSxcclxuICAgICAgICAgICAgc3VwcHJlc3NGaWx0ZXI6IHRydWUsXHJcbiAgICAgICAgICAgIHN1cHByZXNzU2l6ZVRvRml0OiB0cnVlLFxyXG4gICAgICAgICAgICBzdXBwcmVzc1Jlc2l6ZTogdHJ1ZSxcclxuICAgICAgICAgICAgc3VwcHJlc3NNZW51OiB0cnVlLFxyXG4gICAgICAgICAgICB3aWR0aDogMTIwLFxyXG4gICAgICAgICAgICBtaW5XaWR0aDogMTIwLFxyXG4gICAgICAgICAgICBtYXhXaWR0aDogMTIwLFxyXG4gICAgICAgICAgICBjZWxsQ2xhc3M6ICdkcm9wZG93bi1hY3Rpb24nLFxyXG4gICAgICAgICAgICBjb2xJZDogJ2FnLWFjdGlvbicsXHJcbiAgICAgICAgICAgIGNlbGxSZW5kZXJlckZyYW1ld29yazogS2RUYWJsZUFjdGlvbixcclxuICAgICAgICAgICAgY2VsbFJlbmRlcmVyUGFyYW1zOiB7XHJcbiAgICAgICAgICAgICAgICBwYXJhbXM6IF9saXN0LFxyXG4gICAgICAgICAgICAgICAgZ3JpZElkOiBfaWRcclxuICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgc3VwcHJlc3NNb3ZhYmxlOiB0cnVlXHJcbiAgICAgICAgfTsgXHJcbiAgICB9XHJcblxyXG4gICAgLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy9cclxuICAgIC8vLyBDb2xEZWYgLSBDaGVja2JveCAvIFJhZGlvIGZ1bmN0aW9uc1xyXG4gICAgLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy9cclxuICAgIHByaXZhdGUgX2dlbmVyYXRlQ2hlY2tib3hSYWRpb0NvbERlZihfc2VsZWN0aW9uT2JqOiBhbnksIF9ncmlkSWQ6IHN0cmluZyk6IENvbERlZiB7XHJcbiAgICAgICAgLy8vIEhhdmUgdG8gc2V0IHRoZSB0eXBlIGFueSBhcyBzZXR0aW5nIGFzIENvbERlZiB3aWxsIGhhcyBpc3N1ZXNcclxuICAgICAgICAvLy8gb24gaGVhZGVyQ29tcG9uZW50RnJhbWV3b3JrIHR5cGUgaXMgd3JvbmdseSB1c2VkLlxyXG5cclxuICAgICAgICBsZXQgY2hlY2tib3hSYWRpb0RpcmVjdGlvbjogc3RyaW5nID0gdGhpcy5kaXJlY3Rpb24gPT09ICdsdHInID8gJ2xlZnQnIDogJ3JpZ2h0JztcclxuXHJcbiAgICAgICAgbGV0IHRlbXBDb2xEZWY6IGFueSA9IHtcclxuICAgICAgICAgICAgc3VwcHJlc3NTb3J0aW5nOiB0cnVlLFxyXG4gICAgICAgICAgICBzdXBwcmVzc0ZpbHRlcjogdHJ1ZSxcclxuICAgICAgICAgICAgc3VwcHJlc3NTaXplVG9GaXQ6IHRydWUsXHJcbiAgICAgICAgICAgIHN1cHByZXNzTWVudTogdHJ1ZSxcclxuICAgICAgICAgICAgc3VwcHJlc3NSZXNpemU6IHRydWUsXHJcbiAgICAgICAgICAgIHdpZHRoOiA1MCxcclxuICAgICAgICAgICAgbWluV2lkdGg6IDUwLFxyXG4gICAgICAgICAgICBtYXhXaWR0aDogNTAsXHJcbiAgICAgICAgICAgIGNlbGxDbGFzczogJ2FnLWRlZmF1bHQgYWctY2hlY2tib3gtcmFkaW8nLFxyXG4gICAgICAgICAgICBwaW5uZWQ6IGNoZWNrYm94UmFkaW9EaXJlY3Rpb24sXHJcbiAgICAgICAgICAgIGNvbElkOiAoX3NlbGVjdGlvbk9iai50eXBlID09PSAnc2luZ2xlJykgPyAncmFkaW8nIDogJ2NoZWNrYm94JyxcclxuICAgICAgICAgICAgY2VsbFJlbmRlcmVyRnJhbWV3b3JrOiBLZFRhYmxlQ2hlY2tib3hSYWRpbyxcclxuICAgICAgICAgICAgY2VsbFJlbmRlcmVyUGFyYW1zOiB7XHJcbiAgICAgICAgICAgICAgICBwYXJhbXM6IHtcclxuICAgICAgICAgICAgICAgICAgICBpbnB1dFR5cGU6IChfc2VsZWN0aW9uT2JqLnR5cGUgPT09ICdzaW5nbGUnKSA/ICdyYWRpbycgOiAnY2hlY2tib3gnLFxyXG4gICAgICAgICAgICAgICAgICAgIGRlZmF1bHQ6IF9zZWxlY3Rpb25PYmoudmFsdWUsXHJcbiAgICAgICAgICAgICAgICAgICAgZ3JpZElkOiBfZ3JpZElkXHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgIHN1cHByZXNzTW92YWJsZTogdHJ1ZVxyXG4gICAgICAgIH07XHJcblxyXG4gICAgICAgIGlmIChfc2VsZWN0aW9uT2JqLnR5cGUgPT09ICdhbGwnKSB7XHJcbiAgICAgICAgICAgIHRlbXBDb2xEZWYuaGVhZGVyQ29tcG9uZW50RnJhbWV3b3JrID0gS2RUYWJsZUNoZWNrYm94UmFkaW87XHJcbiAgICAgICAgICAgIHRlbXBDb2xEZWYuaGVhZGVyQ29tcG9uZW50UGFyYW1zID0ge1xyXG4gICAgICAgICAgICAgICAgcGFyYW1zOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgZGVmYXVsdDogX3NlbGVjdGlvbk9iai52YWx1ZSxcclxuICAgICAgICAgICAgICAgICAgICBncmlkSWQ6IF9ncmlkSWRcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfTtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIHJldHVybiB0ZW1wQ29sRGVmO1xyXG4gICAgfVxyXG5cclxuICAgIC8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vXHJcbiAgICAvLy8gQ29sRGVmIC0gVGFibGUgSW1hZ2UgZnVuY3Rpb25zXHJcbiAgICAvLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vL1xyXG4gICAgcHJpdmF0ZSBfZ2VuZXJhdGVJbWFnZUNvbERlZihfdGVtcENvbHVtbjogSVRhYmxlQ29sdW1uKTogQ29sRGVmIHtcclxuICAgICAgICBsZXQgd2lkdGg6IG51bWJlciA9IHRoaXMuZ2V0SW1hZ2VTaXplQnkoX3RlbXBDb2x1bW4sICd3aWR0aCcpO1xyXG5cclxuICAgICAgICByZXR1cm4ge1xyXG4gICAgICAgICAgICBoZWFkZXJOYW1lOiBfdGVtcENvbHVtbi5oZWFkZXJOYW1lLFxyXG4gICAgICAgICAgICBmaWVsZDogX3RlbXBDb2x1bW4uZmllbGQsXHJcbiAgICAgICAgICAgIGNvbElkOiBfdGVtcENvbHVtbi5maWVsZCxcclxuICAgICAgICAgICAgc3VwcHJlc3NTb3J0aW5nOiB0cnVlLFxyXG4gICAgICAgICAgICBzdXBwcmVzc0ZpbHRlcjogdHJ1ZSxcclxuICAgICAgICAgICAgc3VwcHJlc3NNZW51OiB0cnVlLFxyXG4gICAgICAgICAgICBzdXBwcmVzc1Jlc2l6ZTogdHJ1ZSxcclxuICAgICAgICAgICAgaGlkZTogIV90ZW1wQ29sdW1uLnZpc2libGUsXHJcbiAgICAgICAgICAgIG1pbldpZHRoOiB3aWR0aCxcclxuICAgICAgICAgICAgbWF4V2lkdGg6IHdpZHRoLFxyXG4gICAgICAgICAgICBjZWxsQ2xhc3M6IF90ZW1wQ29sdW1uLmNsYXNzLFxyXG4gICAgICAgICAgICBjZWxsUmVuZGVyZXJGcmFtZXdvcms6IEtkVGFibGVJbWFnZSxcclxuICAgICAgICAgICAgY2VsbFJlbmRlcmVyUGFyYW1zOiB7XHJcbiAgICAgICAgICAgICAgICBwYXJhbXM6IHtcclxuICAgICAgICAgICAgICAgICAgICBbdGhpcy5HSVJEX1BBUkFNU19LRVkuaW1hZ2VdOiBfdGVtcENvbHVtbi5jb25maWcuaW1hZ2UsXHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgIHN1cHByZXNzTW92YWJsZTogX3RlbXBDb2x1bW4uc3VwcHJlc3NNb3ZhYmxlXHJcbiAgICAgICAgfTtcclxuICAgIH1cclxuXHJcbiAgICAvLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vL1xyXG4gICAgLy8vIENvbERlZiAtIFRhYmxlIElucHV0IGZ1bmN0aW9uc1xyXG4gICAgLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy9cclxuICAgIHByaXZhdGUgX2dlbmVyYXRlSW5wdXRDb2xEZWYoX3RlbXBDb2x1bW46IElUYWJsZUNvbHVtbiwgX2dyaWRJZDogc3RyaW5nKTogQ29sRGVmIHtcclxuICAgICAgICByZXR1cm4ge1xyXG4gICAgICAgICAgICBoZWFkZXJOYW1lOiBfdGVtcENvbHVtbi5oZWFkZXJOYW1lLFxyXG4gICAgICAgICAgICBmaWVsZDogX3RlbXBDb2x1bW4uZmllbGQsXHJcbiAgICAgICAgICAgIHN1cHByZXNzU29ydGluZzogdHJ1ZSxcclxuICAgICAgICAgICAgc3VwcHJlc3NGaWx0ZXI6IHRydWUsXHJcbiAgICAgICAgICAgIHN1cHByZXNzTWVudTogdHJ1ZSxcclxuICAgICAgICAgICAgbWluV2lkdGg6IDI1MCxcclxuICAgICAgICAgICAgaGlkZTogIV90ZW1wQ29sdW1uLnZpc2libGUsXHJcbiAgICAgICAgICAgIGNlbGxDbGFzczogX3RlbXBDb2x1bW4uY2xhc3MsXHJcbiAgICAgICAgICAgIGNvbElkOiBfdGVtcENvbHVtbi5maWVsZCxcclxuICAgICAgICAgICAgY2VsbFJlbmRlcmVyRnJhbWV3b3JrOiBLZFRhYmxlSW5wdXQsXHJcbiAgICAgICAgICAgIGNlbGxSZW5kZXJlclBhcmFtczoge1xyXG4gICAgICAgICAgICAgICAgcGFyYW1zOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgW3RoaXMuR0lSRF9QQVJBTVNfS0VZLmlucHV0XTogX3RlbXBDb2x1bW4uY29uZmlnLFxyXG4gICAgICAgICAgICAgICAgICAgIGdyaWRJZDogX2dyaWRJZCxcclxuICAgICAgICAgICAgICAgICAgICBjb250ZXh0S2V5OiB0aGlzLlRBQkxFX0lOUFVUX0NPTlRFWFRfS0VZXHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgIHN1cHByZXNzTW92YWJsZTogX3RlbXBDb2x1bW4uc3VwcHJlc3NNb3ZhYmxlXHJcbiAgICAgICAgfTtcclxuICAgIH1cclxuXHJcbiAgICAvLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vL1xyXG4gICAgLy8vIEFQSSBnZW5lcmF0aW9uIGZ1bmN0aW9uc1xyXG4gICAgLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy9cclxuICAgIHByaXZhdGUgX2dlbmVyYXRlSW5wdXRBcGkoX2dyaWRJZDogc3RyaW5nLCBfa2RUYWJsZUludEV2ZW50OiBLZEludFRhYmxlRXZlbnQpOiBJVGFibGVEeW5hbWljRm9ybUFwaSB7XHJcbiAgICAgICAgcmV0dXJuIHtcclxuICAgICAgICAgICAgZ2V0UHJvcGVydHk6IChfdGFibGVQYXJhbXM6IElUYWJsZUZvcm1VcGRhdGVQYXJhbXMpOiBhbnkgPT4ge1xyXG4gICAgICAgICAgICAgICAgbGV0IGV2ZW50U3RyaW5nID0gdGhpcy5nZW5lcmF0ZUNvbnRleHRLZXkoX2dyaWRJZCwgX3RhYmxlUGFyYW1zLmNvbElkLCBfdGFibGVQYXJhbXMucm93SWQpO1xyXG4gICAgICAgICAgICAgICAgcmV0dXJuIHRoaXMuZ3JpZE9wdGlvbnMuY29udGV4dC50YWJsZUluZGV4Q29udGV4dFtldmVudFN0cmluZ11bX3RhYmxlUGFyYW1zLnF1ZXN0aW9uS2V5XVtfdGFibGVQYXJhbXMucHJvcGVydHldO1xyXG4gICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICBzZXRQcm9wZXJ0eTogKF90YWJsZVBhcmFtczogSVRhYmxlRm9ybVVwZGF0ZVBhcmFtcyk6IHZvaWQgPT4ge1xyXG4gICAgICAgICAgICAgICAgbGV0IGV2ZW50U3RyaW5nID0gdGhpcy5nZW5lcmF0ZUNvbnRleHRLZXkoX2dyaWRJZCwgX3RhYmxlUGFyYW1zLmNvbElkLCBfdGFibGVQYXJhbXMucm93SWQpO1xyXG5cclxuICAgICAgICAgICAgICAgIGlmICh0eXBlb2YgdGhpcy5ncmlkT3B0aW9ucy5jb250ZXh0LnRhYmxlSW5wdXRDb250ZXh0W2V2ZW50U3RyaW5nXSAhPT0gJ3VuZGVmaW5lZCcpIHtcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLmdyaWRPcHRpb25zLmNvbnRleHQudGFibGVJbnB1dENvbnRleHRbZXZlbnRTdHJpbmddW190YWJsZVBhcmFtcy5xdWVzdGlvbktleV1bX3RhYmxlUGFyYW1zLnByb3BlcnR5XSA9IF90YWJsZVBhcmFtcy5kYXRhO1xyXG4gICAgICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgICAgIGxldCByb3dOb2RlOiBSb3dOb2RlID0gdGhpcy5ncmlkT3B0aW9ucy5hcGkuZ2V0Um93Tm9kZShfdGFibGVQYXJhbXMucm93SWQudG9TdHJpbmcoKSk7XHJcblxyXG4gICAgICAgICAgICAgICAgaWYgKF90YWJsZVBhcmFtcy5wcm9wZXJ0eSA9PT0gJ3Zpc2libGUnKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgcm93Tm9kZS5zZXRSb3dIZWlnaHQodW5kZWZpbmVkKTtcclxuICAgICAgICAgICAgICAgICAgICAvLy8gSXNzdWVzIC0gQ2FsbGluZyB0aGlzIGFwaSBvblJvd0hlaWdodENoYW5nZWQgY2F1c2luZyB0aGUgY3VycmVudCBpbnB1dCBjZWxsIHRvIGxvc2UgZm9jdXNcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLmdyaWRPcHRpb25zLmFwaS5vblJvd0hlaWdodENoYW5nZWQoKTtcclxuICAgICAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgICAgICBpZiAoX3RhYmxlUGFyYW1zLnByb3BlcnR5ID09PSAndmFsdWUnKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgcm93Tm9kZS5kYXRhW190YWJsZVBhcmFtcy5jb2xJZF1bX3RhYmxlUGFyYW1zLnF1ZXN0aW9uS2V5XSA9IF90YWJsZVBhcmFtcy5kYXRhO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfTtcclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF9nZW5lcmF0ZUdlbmVyYWxBcGkoX3JvdzogQXJyYXk8YW55Pik6IElUYWJsZUdlbmVyYWxBcGkge1xyXG4gICAgICAgIHJldHVybiB7XHJcbiAgICAgICAgICAgIGdldEN1cnJlbnRSb3dzOiAoKTogQXJyYXk8YW55PiA9PiB7XHJcbiAgICAgICAgICAgICAgICByZXR1cm4gX3Jvdy5zbGljZSgpO1xyXG4gICAgICAgICAgICB9LFxyXG5cclxuICAgICAgICAgICAgcmVzZXRSb3dIZWlnaHQ6ICgpOiB2b2lkID0+IHtcclxuICAgICAgICAgICAgICAgIHRoaXMuZ3JpZE9wdGlvbnMuYXBpLnJlc2V0Um93SGVpZ2h0cygpO1xyXG4gICAgICAgICAgICB9LFxyXG5cclxuICAgICAgICAgICAgc2V0Q29sdW1uVmlzaWJsZTogKF9jb2xJZDogc3RyaW5nLCBfdmlzaWJsZTogYm9vbGVhbik6IHZvaWQgPT4ge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5ncmlkT3B0aW9ucy5jb2x1bW5BcGkuc2V0Q29sdW1uVmlzaWJsZShfY29sSWQsIF92aXNpYmxlKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH07XHJcbiAgICB9XHJcblxyXG4gICAgLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy9cclxuICAgIC8vLyBUYWJsZSBJbnB1dCBmdW5jdGlvbnNcclxuICAgIC8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vXHJcbiAgICAvKipcclxuICAgICAqIFtfZ2VuZXJhdGVUYWJsZUlucHV0Q29udGV4dFxyXG4gICAgICogICAgIEdlbmVyYXRlIHRoZSBpbnB1dCBjb25maWd1cmF0aW9ucyBhbmQgdmFsdWVzIHRvIHRoZSBjb250ZXh0IG9mIHRoZSBncmlkT3B0aW9ucy5cclxuICAgICAqICAgICBBbGwgaW5wdXQgY29uZmlndXJhdGlvbnMgd2lsbCBiZSBzdG9yZWQgaW4gdGFibGVJbnB1dENvbnRleHQgKGdyaWRPcHRpb25zLmNvbnRleHQudGFibGVJbnB1dENvbnRleHQpXHJcbiAgICAgKiAgICAgU3RydWN0dXJlIGlzIGFzIGZvbGxvd3M6XHJcbiAgICAgKiAgICAgICAgIGRlbGltaXRlcjogflxyXG4gICAgICogICAgICAgICBjb250ZXh0S2V5OiBbZ3JpZElkXVtkZWxpbWl0ZXJdW2NvbHVtbklkXVtkZWxpbWl0ZXJdW3Jvd0lkXVxyXG4gICAgICogICAgICAgICAgICAgKGUuZy4gdGFibGVGb3JtfmlucHV0Q29sdW1ufjEpXHJcbiAgICAgKiAgICAgICAgIHF1ZXN0aW9uOiB7XHJcbiAgICAgKiAgICAgICAgICAgICBxdWVzdGlvbktleTogcXVlc3Rpb24gY29uZmlndXJhdGlvbnMsXHJcbiAgICAgKiAgICAgICAgICAgICBxdWVzdGlvbktleTogcXVlc3Rpb24gY29uZmlndXJhdGlvbnNcclxuICAgICAqICAgICAgICAgfVxyXG4gICAgICogICAgICAgICAgICAgKGUuZy4ge1xyXG4gICAgICogICAgICAgICAgICAgICAgIGlucHV0S2V5OiB7XHJcbiAgICAgKiAgICAgICAgICAgICAgICAgICAgIGNvbnRyb2xUeXBlOiAndGV4dCcsXHJcbiAgICAgKiAgICAgICAgICAgICAgICAgICAgIGtleTogJ2lucHV0S2V5JyxcclxuICAgICAqICAgICAgICAgICAgICAgICAgICAgdmlzaWJsZTogdHJ1ZSxcclxuICAgICAqICAgICAgICAgICAgICAgICAgICAgZGlzYWJsZWQ6IGZhbHNlLFxyXG4gICAgICogICAgICAgICAgICAgICAgICAgICB2YWx1ZTogJ1RleHQnXHJcbiAgICAgKiAgICAgICAgICAgICAgICAgfSxcclxuICAgICAqICAgICAgICAgICAgICAgICBkcm9wZG93bktleToge1xyXG4gICAgICogICAgICAgICAgICAgICAgICAgICBjb250cm9sVHlwZTogJ2Ryb3Bkb3duJyxcclxuICAgICAqICAgICAgICAgICAgICAgICAgICAga2V5OiAnZHJvcGRvd25LZXknLFxyXG4gICAgICogICAgICAgICAgICAgICAgICAgICB2aXNpYmxlOiB0cnVlLFxyXG4gICAgICogICAgICAgICAgICAgICAgICAgICB2YWx1ZTogJzEnLFxyXG4gICAgICogICAgICAgICAgICAgICAgICAgICBvcHRpb25zOiBbXHJcbiAgICAgKiAgICAgICAgICAgICAgICAgICAgICAgICB7XHJcbiAgICAgKiAgICAgICAgICAgICAgICAgICAgICAgICAgICAga2V5OiAnJyxcclxuICAgICAqICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZTogJy0tIFBsZWFzZSBzZWxlY3QgLS0nXHJcbiAgICAgKiAgICAgICAgICAgICAgICAgICAgICAgICB9LFxyXG4gICAgICogICAgICAgICAgICAgICAgICAgICAgICAge1xyXG4gICAgICogICAgICAgICAgICAgICAgICAgICAgICAgICAgIGtleTogJzEnLFxyXG4gICAgICogICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlOiAnRmVtYWxlJ1xyXG4gICAgICogICAgICAgICAgICAgICAgICAgICAgICAgfSxcclxuICAgICAqICAgICAgICAgICAgICAgICAgICAgICAgIHtcclxuICAgICAqICAgICAgICAgICAgICAgICAgICAgICAgICAgICBrZXk6ICcyJyxcclxuICAgICAqICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZTogJ01hbGUnXHJcbiAgICAgKiAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgKiAgICAgICAgICAgICAgICAgICAgIF1cclxuICAgICAqICAgICAgICAgICAgICAgICB9XHJcbiAgICAgKiAgICAgICAgICAgICB9KVxyXG4gICAgICpcclxuICAgICAqXHJcbiAgICAgKiAgICAgICAgIGNvbnRleHQudGFibGVJbnB1dENvbnRleHRbY29udGV4dEtleV0gPSBxdWVzdGlvblxyXG4gICAgICogXVxyXG4gICAgICogX2NvbHVtbiAgICA6IFtDb2x1bW4gY29uZmlndXJhdGlvbnNdXHJcbiAgICAgKiBfcm93ICAgICAgIDogW1JvdyBkYXRhXVxyXG4gICAgICogX2dyaWRJZCAgICA6IFtHcmlkIElEXVxyXG4gICAgICovXHJcbiAgICBwcml2YXRlIF9nZW5lcmF0ZVRhYmxlSW5wdXRDb250ZXh0KF9jb2x1bW46IEFycmF5PElUYWJsZUNvbHVtbj4sIF9yb3c6IEFycmF5PGFueT4sIF9ncmlkSWQ6IHN0cmluZyk6IHsgW2tleTogc3RyaW5nXTogYW55IH0ge1xyXG4gICAgICAgIGxldCB0YWJsZUlucHV0Q29udGV4dDogYW55ID0ge307XHJcblxyXG4gICAgICAgIGZvciAobGV0IGk6IG51bWJlciA9IDA7IGkgPCBfY29sdW1uLmxlbmd0aDsgKytpKSB7XHJcbiAgICAgICAgICAgIGlmICh0aGlzLmlzSW5wdXRUeXBlKF9jb2x1bW5baV0sICdpbnB1dCcpKSB7XHJcbiAgICAgICAgICAgICAgICBsZXQgY3VycmVudENvbHVtbjogSVRhYmxlQ29sdW1uID0gX2NvbHVtbltpXTtcclxuICAgICAgICAgICAgICAgIGxldCBjdXJyZW50Q29sdW1uSWQ6IHN0cmluZyA9IGN1cnJlbnRDb2x1bW4uZmllbGQ7XHJcblxyXG4gICAgICAgICAgICAgICAgZm9yIChsZXQgajogbnVtYmVyID0gMDsgaiA8IF9yb3cubGVuZ3RoOyArK2opIHtcclxuICAgICAgICAgICAgICAgICAgICBpZiAodHlwZW9mIF9yb3dbal1bdGhpcy5yb3dLZXldICE9PSAndW5kZWZpbmVkJykge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBsZXQgY29udGV4dE9iamVjdDogYW55ID0ge307XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAvLyBjb25zb2xlLmxvZygnLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLScpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAvLyBjb25zb2xlLmxvZygnY3VycmVudENvbHVtbiAtICcsIGN1cnJlbnRDb2x1bW4pO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAvLyBjb25zb2xlLmxvZygnY3VycmVudENvbHVtbklkIC0gJywgY3VycmVudENvbHVtbklkKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgLy8gY29uc29sZS5sb2coJ19yb3dbal0gLSAnLCBfcm93W2pdKTtcclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC8vIFNldCB0aGUgcm93IGRhdGEgd2l0aCB0aGUgY29sdW1uIGtleSBpZiBpcyBub3QgZGVmaW5lZFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAodHlwZW9mIF9yb3dbal1bY3VycmVudENvbHVtbklkXSA9PT0gJ3VuZGVmaW5lZCcpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIF9yb3dbal1bY3VycmVudENvbHVtbklkXSA9IHt9O1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAvLyBTZXQgdGhlIGlucHV0IHRvIHRoZSBjb250ZXh0T2JqZWN0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGlmICh0eXBlb2YgY3VycmVudENvbHVtbi5jb25maWcgIT09ICd1bmRlZmluZWQnICYmIHR5cGVvZiBjdXJyZW50Q29sdW1uLmNvbmZpZy5pbnB1dCAhPT0gJ3VuZGVmaW5lZCcpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxldCBwcm9jZXNzSW5wdXREYXRhOiBBcnJheTxJVGFibGVGb3JtSW5wdXQ+ID0gKGN1cnJlbnRDb2x1bW4uY29uZmlnLmlucHV0IGluc3RhbmNlb2YgQXJyYXkpID8gY3VycmVudENvbHVtbi5jb25maWcuaW5wdXQgOiBbY3VycmVudENvbHVtbi5jb25maWcuaW5wdXRdO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgbGV0IHJvd0NvbHVtbkRhdGE6IGFueSA9IF9yb3dbal1bY3VycmVudENvbHVtbklkXTtcclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBmb3IgKGxldCBrOiBudW1iZXIgPSAwOyBrIDwgcHJvY2Vzc0lucHV0RGF0YS5sZW5ndGg7ICsraykge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIFNldCB0aGUgcm93IGRhdGEgaW5wdXQga2V5IHZhbHVlIGlmIG5vIGlucHV0IGtleSBvZiB0aGUgY29sdW1uIGlzIGRlZmluZWRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAodHlwZW9mIHJvd0NvbHVtbkRhdGFbcHJvY2Vzc0lucHV0RGF0YVtrXS5rZXldID09PSAndW5kZWZpbmVkJykge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICByb3dDb2x1bW5EYXRhW3Byb2Nlc3NJbnB1dERhdGFba10ua2V5XSA9ICcnO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29udGV4dE9iamVjdFtwcm9jZXNzSW5wdXREYXRhW2tdLmtleV0gPSAoPGFueT5PYmplY3QpLmFzc2lnbih7fSwgcHJvY2Vzc0lucHV0RGF0YVtrXSk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29udGV4dE9iamVjdFtwcm9jZXNzSW5wdXREYXRhW2tdLmtleV0udmFsdWUgPSByb3dDb2x1bW5EYXRhW3Byb2Nlc3NJbnB1dERhdGFba10ua2V5XTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnNvbGUuZXJyb3IoJ0tkVGFibGUgZXJyb3IgLSBDb2x1bW4gc3BlY2lmeSBhcyBpbnB1dCBidXQgbm8gY29uZmlnIHBhc3NlZCBpbi4gTm8gaW5wdXQgd2lsbCBiZSBnZW5lcmF0ZWQuJyk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGxldCBjb250ZXh0S2V5OiBzdHJpbmcgPSB0aGlzLmdlbmVyYXRlQ29udGV4dEtleShfZ3JpZElkLCBjdXJyZW50Q29sdW1uSWQsIF9yb3dbal1bdGhpcy5yb3dLZXldKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgdGFibGVJbnB1dENvbnRleHRbY29udGV4dEtleV0gPSAoPGFueT5PYmplY3QpLmFzc2lnbih7fSwgY29udGV4dE9iamVjdCk7XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBjb25zb2xlLmVycm9yKCdLZFRhYmxlIGVycm9yIC0gUm93IHBhc3NlZCBpbiB3aXRoIG5vIHJvd0tleSAoJyArIHRoaXMucm93S2V5ICsgJykuIElucHV0IGNlbGwgY29tcG9uZW50IHJlcXVpcmVzIHJvd0tleSB0byBnZW5lcmF0ZS4nKTtcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIHJldHVybiB0YWJsZUlucHV0Q29udGV4dDtcclxuICAgIH1cclxuXHJcbiAgICAvLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vL1xyXG4gICAgLy8vIFNlbGVjdGlvbiBmdW5jdGlvbiAtIFJldHVybiB2YWx1ZSBmdW5jdGlvbnNcclxuICAgIC8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vXHJcbiAgICAvKipcclxuICAgICAqIFtfY29udmVydERhdGFWYWx1ZVRvT2JqZWN0IC0gQ29udmVydCByZXR1cm4gZnJvbSBkb3Qgc2VwYXJhdGVkIHRvIG9iamVjdCB2YWx1ZS4gRXhhbXBsZTpcclxuICAgICAqICAgICAtIEZyb206IFwiaW5zdHV0aXRpb25faWQuaW5zdHV0aXRpb25fbmFtZVwiOiBcIkFuZGVyc29uIFByaW1hcnkgU2Nob29sXCI7XHJcbiAgICAgKiAgICAgLSBUbyAgOiBpbnN0dXRpdGlvbl9pZDoge1xyXG4gICAgICogICAgICAgICAgICAgICAgIGluc3R1dGl0aW9uX25hbWU6XCJBbmRlcnNvbiBQcmltYXJ5IFNjaG9vbFwiXHJcbiAgICAgKiAgICAgICAgICAgICB9O1xyXG4gICAgICogXVxyXG4gICAgICogX2N1cnJlbnRJdGVtICAgIDogW0N1cnJlbnQgc2VsZWN0aW9uIGtleV1cclxuICAgICAqIF9vYmpLZXkgICAgICAgICA6IFtEb3Qgc2VwYXJhdGVkIG9iamVjdCBrZXlzXVxyXG4gICAgICogX3ZhbHVlICAgICAgICAgIDogW0RhdGEgdmFsdWUgZm9yIHRoZSBvYmplY3RdXHJcbiAgICAgKlxyXG4gICAgICovXHJcbiAgICBwcml2YXRlIF9jb252ZXJ0RGF0YVZhbHVlVG9PYmplY3QoX2N1cnJlbnRJdGVtOiBhbnksIF9vYmpLZXk6IHN0cmluZywgX3ZhbHVlOiBhbnksIF9zZXBhcmF0b3I6IHN0cmluZyA9ICcuJyk6IGFueSB7XHJcbiAgICAgICAgbGV0IG9iamVjdEtleUFycjogQXJyYXk8c3RyaW5nPiA9IF9vYmpLZXkuc3BsaXQoX3NlcGFyYXRvcik7XHJcbiAgICAgICAgcmV0dXJuIHRoaXMuX2FwcGVuZERhdGFWYWx1ZUtleShvYmplY3RLZXlBcnIsIF9jdXJyZW50SXRlbSwgX3ZhbHVlKTtcclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF9hcHBlbmREYXRhVmFsdWVLZXkoX2tleTogQXJyYXk8c3RyaW5nPiwgX2N1cnJlbnRPYmo6IGFueSwgX3ZhbHVlOiBhbnkpOiBhbnkge1xyXG4gICAgICAgIGlmIChfa2V5Lmxlbmd0aCA+IDApIHtcclxuICAgICAgICAgICAgbGV0IGN1cnJlbnRLZXk6IHN0cmluZyA9IF9rZXlbMF07XHJcblxyXG4gICAgICAgICAgICBpZiAodHlwZW9mIF9jdXJyZW50T2JqW2N1cnJlbnRLZXldID09PSAndW5kZWZpbmVkJykge1xyXG4gICAgICAgICAgICAgICAgX2N1cnJlbnRPYmpbY3VycmVudEtleV0gPSB7fTtcclxuICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgX2tleS5zaGlmdCgpO1xyXG4gICAgICAgICAgICBfY3VycmVudE9ialtjdXJyZW50S2V5XSA9IHRoaXMuX2FwcGVuZERhdGFWYWx1ZUtleShfa2V5LCBfY3VycmVudE9ialtjdXJyZW50S2V5XSwgX3ZhbHVlKTtcclxuICAgICAgICB9XHJcbiAgICAgICAgZWxzZSB7XHJcbiAgICAgICAgICAgIF9jdXJyZW50T2JqID0gX3ZhbHVlO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgcmV0dXJuIF9jdXJyZW50T2JqO1xyXG4gICAgfVxyXG5cclxuICAgIC8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vXHJcbiAgICAvLy8gTWlzYyBmdW5jdGlvbnNcclxuICAgIC8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vXHJcbiAgICBwcml2YXRlIF91cGRhdGVGaWx0ZXJDb2xEZWYoX2NvbERlZjogQ29sRGVmLCBfZmlsdGVyVmFsPzogQXJyYXk8c3RyaW5nPik6IHZvaWQge1xyXG4gICAgICAgIF9jb2xEZWYubWVudVRhYnMgPSBbJ2ZpbHRlck1lbnVUYWInXTtcclxuICAgICAgICBfY29sRGVmLmZpbHRlciA9ICdhZ1NldENvbHVtbkZpbHRlcic7XHJcbiAgICAgICAgX2NvbERlZi5maWx0ZXJQYXJhbXMgPSB7XHJcbiAgICAgICAgICAgIG5ld1Jvd3NBY3Rpb246ICdrZWVwJyxcclxuICAgICAgICAgICAgY2VsbEhlaWdodDogMzAsXHJcbiAgICAgICAgICAgIHNlbGVjdEFsbE9uTWluaUZpbHRlcjogdHJ1ZVxyXG4gICAgICAgIH07XHJcblxyXG4gICAgICAgIGlmICh0eXBlb2YgX2ZpbHRlclZhbCAhPT0gJ3VuZGVmaW5lZCcpIHtcclxuICAgICAgICAgICAgX2NvbERlZi5maWx0ZXJQYXJhbXMudmFsdWVzID0gX2ZpbHRlclZhbDtcclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfZ2V0RGVmYXVsdENvbHVtbkNvbmZpZygpOiBJVGFibGVDb2x1bW4ge1xyXG4gICAgICAgIHJldHVybiB7XHJcbiAgICAgICAgICAgIHNvcnRhYmxlOiBmYWxzZSxcclxuICAgICAgICAgICAgZmlsdGVyYWJsZTogZmFsc2UsXHJcbiAgICAgICAgICAgIHZpc2libGU6IHRydWUsXHJcbiAgICAgICAgfTtcclxuICAgIH1cclxuXHJcbiAgICAvKioqKioqKioqKioqKioqKioqKioqKioqKiBFbmQgb2YgcHJpdmF0ZSBmdW5jdGlvbnMgKioqKioqKioqKioqKioqKioqKioqKioqKiovXHJcbn1cclxuIl19