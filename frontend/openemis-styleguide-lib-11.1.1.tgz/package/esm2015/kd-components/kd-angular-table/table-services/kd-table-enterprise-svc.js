import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { KdTableSvcBase } from './kd-table-svc';
/**
 * -- Documentation for kd-table-enterprise-svc.ts --
 *
 * Public function:
 *     - Grid Options function
 *         - generateGridOptions (GridOption generation with gridConfig)
 *         - setGridOptions
 *     - Column definition functions
 *         - setColumnDef (Column Definitions based on columnConfig and gridConfig)
 *         - generateColumnDefinitions
 *     - Row data functions
 *         - setRowData (Set the rowData to the grid)
 *     - Datasource function
 *         - generateDatasourceRows (manual sorting / filtering of the datasource - For oneshot and infinite loadType)
 *
 * Public functions (from parent) - Overrides:
 *     - updateSelectionValues
 *
 * Private functions:
 *     - Grid Options function
 *         - _generateConfigOptions (additional GridOption from table config)
 *     - Column definition functions
 *         - _checkCheckboxSelectionType (Checking for selection type all - Infinite loadType not able to load)
 *         - _updateColDefConfig  (NOTE: Removing input columns here)
 *         - _checkColDefFilterableVal
 *     - Datasource function
 *         - _datasourceSortRow
 *         - _datasourceRowSortFormula
 *         - _datasourceFilterRow
 *     - Misc functions
 *         - _retrievePagesize
 */
export class KdTableEnterpriseSvc extends KdTableSvcBase {
    /***************************** Public functions ******************************/
    ////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// Grid options functions
    ////////////////////////////////////////////////////////////////////////////////////////////////////////
    generateGridOptions(_gridConfig, _direction) {
        let tempGridOptions = super.getDefaultGridOptions(_direction, _gridConfig.rowContentHeight);
        let configOptions = this._generateConfigOptions(_gridConfig);
        Object.assign(tempGridOptions, configOptions);
        return tempGridOptions;
    }
    setGridOptions(_gridOptions) {
        this.gridOptions = _gridOptions;
    }
    ////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// Column definitions functions
    ////////////////////////////////////////////////////////////////////////////////////////////////////////
    setColumnDef(_colDefConfig, _gridConfig, _suppressMovableColumns = true) {
        let updatedColumn = this.generateColumnDefinitions(_colDefConfig, _gridConfig, _suppressMovableColumns);
        this.gridOptions.columnDefs = updatedColumn;
        if (super.isApiReady(this.gridOptions)) {
            this.gridOptions.api.setColumnDefs(updatedColumn);
        }
        // if (super.hasInputType(_colDefConfig, 'image')) {
        //     this._updateRowHeightForImg(_colDefConfig);
        // }
    }
    generateColumnDefinitions(_colDefConfig, _gridConfig, _suppressMovableColumns = true) {
        let updatedColDefConfig = this._updateColDefConfig(_colDefConfig);
        let generatedColDef = super.generateColumnDefinitions(updatedColDefConfig, _gridConfig, _suppressMovableColumns);
        this._checkCheckboxSelectionType(_gridConfig, generatedColDef);
        return generatedColDef;
    }
    ////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// Row Data functions
    ////////////////////////////////////////////////////////////////////////////////////////////////////////
    setRowData(_rowData) {
        this.gridOptions.rowData = _rowData;
    }
    ////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// Datasource functions
    ////////////////////////////////////////////////////////////////////////////////////////////////////////
    generateDatasourceRows(_datasourceRequest, _rowData) {
        return new Observable((_observer) => {
            // console.log('-- Grid state: generate Datasource rows --', _datasourceRequest);
            let tempRowModel = this._datasourceFilterRow(_datasourceRequest.filterModel, _rowData);
            this._datasourceSortRow(_datasourceRequest.sortModel, tempRowModel);
            let requestObj = {
                rows: tempRowModel.slice(_datasourceRequest.startRow, _datasourceRequest.endRow),
                total: tempRowModel.length
            };
            _observer.next(requestObj);
            _observer.complete();
        });
    }
    /************************ Public functions from parent ***********************/
    ////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// Overrides
    ////////////////////////////////////////////////////////////////////////////////////////////////////////
    updateSelectionValues(_rowData, _selectedId, _returnKey, _loadType) {
        if (_loadType === 'server' && typeof _returnKey !== 'undefined' && _returnKey.length > 0) {
            console.warn('KdTable warning: Selection value not able to return as objects specify in the returnKey property as there might have unknown data values for server loadType.');
            return _selectedId;
        }
        return super.updateSelectionValues(_rowData, _selectedId, _returnKey);
    }
    /************ End of public functions / Start of private functions ***********/
    ////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// Grid options functions
    ////////////////////////////////////////////////////////////////////////////////////////////////////////
    _generateConfigOptions(_config) {
        let pagesize = this._retrievePagesize(_config.paginationConfig);
        let configOptions = {
            rowModelType: 'enterprise',
            enableServerSideFilter: true,
            enableServerSideSorting: true,
            maxConcurrentDatasourceRequests: 2,
            cacheOverflowSize: 1,
            rowGroupPanelShow: 'never',
            toolPanelSuppressPivotMode: true,
            toolPanelSuppressValues: true,
            cacheBlockSize: pagesize
        };
        if (typeof _config.rowIdKey !== 'undefined') {
            this.rowKey = _config.rowIdKey;
            configOptions.getRowNodeId = (_data) => {
                if (_data.hasOwnProperty(_config.rowIdKey)) {
                    let id = _data[_config.rowIdKey];
                    if (typeof _data[_config.rowIdKey] === 'number') {
                        id = id.toString();
                    }
                    return id;
                }
                return '';
            };
        }
        if (typeof _config !== 'undefined' && typeof _config.loadType !== 'undefined') {
            if (_config.loadType !== 'infinite') {
                configOptions.pagination = true;
                configOptions.maxBlocksInCache = 0;
                configOptions.paginationPageSize = pagesize;
            }
            else {
                // Auto height takes a lot of height, will cause infinite retrieving issue
                configOptions.maxBlocksInCache = 5;
            }
            if (_config.loadType == 'normal') {
                configOptions.sideBar = true;
            }
            else {
                configOptions.sideBar = false;
            }
        }
        return configOptions;
    }
    ////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// Column definitions functions
    ////////////////////////////////////////////////////////////////////////////////////////////////////////
    _checkCheckboxSelectionType(_gridConfig, _colDefs) {
        if (typeof _gridConfig.selection !== 'undefined' &&
            typeof _gridConfig.selection.type !== 'undefined' &&
            typeof _gridConfig.loadType !== 'undefined' &&
            _gridConfig.selection.type === 'all' &&
            _gridConfig.loadType === 'infinite') {
            console.warn('KdTable warning: Infinite loadType not able to support all selectionType.');
            delete _colDefs[0].headerComponentFramework;
        }
    }
    _updateColDefConfig(_colDefConfig) {
        let updatedColDefConfig = [];
        for (let i = 0; i < _colDefConfig.length; i++) {
            if (super.isInputType(_colDefConfig[i], 'input')) {
                console.error('KdTable error: input column type is only valid for normal loadType table. Removing columns with input type.');
            }
            else {
                this._checkColDefFilterableVal(_colDefConfig[i]);
                updatedColDefConfig.push(_colDefConfig[i]);
            }
        }
        return updatedColDefConfig;
    }
    _checkColDefFilterableVal(_colDefItem) {
        if (typeof _colDefItem.filterable !== 'undefined' && _colDefItem.filterable &&
            (typeof _colDefItem.filterValue === 'undefined' || _colDefItem.filterValue === null || _colDefItem.filterValue.length === 0)) {
            console.error('KdTable error: Filter value for ' + _colDefItem.field + ' field is empty. Using filter for loadType oneshot/infinite/server requires to provide filterValue. Suppressing filtering menu.');
            _colDefItem.filterable = false;
        }
    }
    // private _updateRowHeightForImg(_colDefConfig: Array<ITableColumn>): void {
    //     let maxHeight: number = 50;
    //     for (let i: number = 0; i < _colDefConfig.length; ++i) {
    //         if (super.isInputType(_colDefConfig[i], 'image')) {
    //             let tempHeight: number = super.getImageSizeBy(_colDefConfig[i], 'height');
    //             if (tempHeight > maxHeight) {
    //                 maxHeight = tempHeight;
    //             }
    //         }
    //     }
    //     console.log('row height max: ', maxHeight);
    //     this.gridOptions.rowHeight = maxHeight;
    // }
    ////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// Datasource sort / filter functions
    ////////////////////////////////////////////////////////////////////////////////////////////////////////
    _datasourceSortRow(_sortModel, _rowData) {
        if (_sortModel.length > 0) {
            let sortOptions = _sortModel[0];
            let returnCondition = (sortOptions.sort === 'asc') ? 1 : -1;
            _rowData.sort((_a, _b) => {
                return this._datasourceRowSortFormula(_a, _b, sortOptions.colId, returnCondition);
            });
        }
    }
    _datasourceRowSortFormula(_a, _b, _dotDisplayFrom, _returnVal) {
        if (typeof _a !== 'undefined' && typeof _b !== 'undefined') {
            let aVal = this.dataSvc.getDataValue(_a, _dotDisplayFrom);
            let bVal = this.dataSvc.getDataValue(_b, _dotDisplayFrom);
            if (aVal > bVal)
                return _returnVal;
            else if (aVal < bVal)
                return -(_returnVal);
            return 0;
        }
        return 0;
    }
    _datasourceFilterRow(_filterModel, _rowData) {
        let tempRowModel = [];
        if (Object.keys(_filterModel).length > 0) {
            for (let item in _filterModel) {
                if (_filterModel.hasOwnProperty(item)) {
                    let dataKey = item;
                    let filterModelItem = _filterModel[item].values;
                    if (filterModelItem.length > 0) {
                        for (let i = 0; i < _rowData.length; i++) {
                            let rowItem = _rowData[i];
                            if (rowItem.hasOwnProperty(dataKey) && filterModelItem.indexOf(rowItem[dataKey]) > -1) {
                                tempRowModel.push(rowItem);
                            }
                        }
                    }
                    else {
                        tempRowModel = [];
                        break;
                    }
                }
            }
        }
        else {
            tempRowModel = _rowData.slice();
        }
        return tempRowModel;
    }
    ////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// Misc functions
    ////////////////////////////////////////////////////////////////////////////////////////////////////////
    _retrievePagesize(_paginationConfig) {
        if (typeof _paginationConfig !== 'undefined' &&
            typeof _paginationConfig.pagesize !== 'undefined') {
            return _paginationConfig.pagesize;
        }
        _paginationConfig.pagesize = this.DEFAULT_PAGESIZE;
        return this.DEFAULT_PAGESIZE;
    }
}
KdTableEnterpriseSvc.decorators = [
    { type: Injectable }
];
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoia2QtdGFibGUtZW50ZXJwcmlzZS1zdmMuanMiLCJzb3VyY2VSb290IjoiRDovb3BlbkVNSVMvc3R5bGVndWlkZS9pb3N0Zy1vcGVuZW1pcy1zdHlsZWd1aWRlL3Byb2plY3RzL29wZW5lbWlzLXN0eWxlZ3VpZGUtbGliL3NyYy8iLCJzb3VyY2VzIjpbImtkLWNvbXBvbmVudHMva2QtYW5ndWxhci10YWJsZS90YWJsZS1zZXJ2aWNlcy9rZC10YWJsZS1lbnRlcnByaXNlLXN2Yy50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQSxPQUFPLEVBQUUsVUFBVSxFQUFFLE1BQU0sZUFBZSxDQUFDO0FBQzNDLE9BQU8sRUFBRSxVQUFVLEVBQWdCLE1BQU0sTUFBTSxDQUFDO0FBY2hELE9BQU8sRUFBRSxjQUFjLEVBQUUsTUFBTSxnQkFBZ0IsQ0FBQztBQUVoRDs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztHQStCRztBQUdILE1BQU0sT0FBTyxvQkFBcUIsU0FBUSxjQUFjO0lBQ3BELCtFQUErRTtJQUMvRSx3R0FBd0c7SUFDeEcsMEJBQTBCO0lBQzFCLHdHQUF3RztJQUNqRyxtQkFBbUIsQ0FBQyxXQUF5QixFQUFFLFVBQXlCO1FBQzNFLElBQUksZUFBZSxHQUFnQixLQUFLLENBQUMscUJBQXFCLENBQUMsVUFBVSxFQUFFLFdBQVcsQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDO1FBQ3pHLElBQUksYUFBYSxHQUFnQixJQUFJLENBQUMsc0JBQXNCLENBQUMsV0FBVyxDQUFDLENBQUM7UUFFcEUsTUFBTyxDQUFDLE1BQU0sQ0FBQyxlQUFlLEVBQUUsYUFBYSxDQUFDLENBQUM7UUFFckQsT0FBTyxlQUFlLENBQUM7SUFDM0IsQ0FBQztJQUVNLGNBQWMsQ0FBQyxZQUF5QjtRQUMzQyxJQUFJLENBQUMsV0FBVyxHQUFHLFlBQVksQ0FBQztJQUNwQyxDQUFDO0lBRUQsd0dBQXdHO0lBQ3hHLGdDQUFnQztJQUNoQyx3R0FBd0c7SUFDakcsWUFBWSxDQUFDLGFBQWtDLEVBQUUsV0FBeUIsRUFBRSwwQkFBbUMsSUFBSTtRQUN0SCxJQUFJLGFBQWEsR0FBa0IsSUFBSSxDQUFDLHlCQUF5QixDQUFDLGFBQWEsRUFBRSxXQUFXLEVBQUUsdUJBQXVCLENBQUMsQ0FBQztRQUV2SCxJQUFJLENBQUMsV0FBVyxDQUFDLFVBQVUsR0FBRyxhQUFhLENBQUM7UUFDNUMsSUFBSSxLQUFLLENBQUMsVUFBVSxDQUFDLElBQUksQ0FBQyxXQUFXLENBQUMsRUFBRTtZQUNwQyxJQUFJLENBQUMsV0FBVyxDQUFDLEdBQUcsQ0FBQyxhQUFhLENBQUMsYUFBYSxDQUFDLENBQUM7U0FDckQ7UUFFRCxvREFBb0Q7UUFDcEQsa0RBQWtEO1FBQ2xELElBQUk7SUFDUixDQUFDO0lBRU0seUJBQXlCLENBQUMsYUFBa0MsRUFBRSxXQUF5QixFQUFFLDBCQUFtQyxJQUFJO1FBQ25JLElBQUksbUJBQW1CLEdBQXdCLElBQUksQ0FBQyxtQkFBbUIsQ0FBQyxhQUFhLENBQUMsQ0FBQztRQUV2RixJQUFJLGVBQWUsR0FBa0IsS0FBSyxDQUFDLHlCQUF5QixDQUFDLG1CQUFtQixFQUFFLFdBQVcsRUFBRSx1QkFBdUIsQ0FBQyxDQUFDO1FBQ2hJLElBQUksQ0FBQywyQkFBMkIsQ0FBQyxXQUFXLEVBQUUsZUFBZSxDQUFDLENBQUM7UUFFL0QsT0FBUSxlQUFlLENBQUM7SUFDNUIsQ0FBQztJQUVELHdHQUF3RztJQUN4RyxzQkFBc0I7SUFDdEIsd0dBQXdHO0lBQ2pHLFVBQVUsQ0FBQyxRQUFvQjtRQUNsQyxJQUFJLENBQUMsV0FBVyxDQUFDLE9BQU8sR0FBRyxRQUFRLENBQUM7SUFDeEMsQ0FBQztJQUVELHdHQUF3RztJQUN4Ryx3QkFBd0I7SUFDeEIsd0dBQXdHO0lBQ2pHLHNCQUFzQixDQUFDLGtCQUE2QyxFQUFFLFFBQW9CO1FBQzdGLE9BQU8sSUFBSSxVQUFVLENBQU0sQ0FBQyxTQUEwQixFQUFRLEVBQUU7WUFDNUQsaUZBQWlGO1lBRWpGLElBQUksWUFBWSxHQUFlLElBQUksQ0FBQyxvQkFBb0IsQ0FBQyxrQkFBa0IsQ0FBQyxXQUFXLEVBQUUsUUFBUSxDQUFDLENBQUM7WUFDbkcsSUFBSSxDQUFDLGtCQUFrQixDQUFDLGtCQUFrQixDQUFDLFNBQVMsRUFBRSxZQUFZLENBQUMsQ0FBQztZQUVwRSxJQUFJLFVBQVUsR0FBc0M7Z0JBQ2hELElBQUksRUFBRSxZQUFZLENBQUMsS0FBSyxDQUFDLGtCQUFrQixDQUFDLFFBQVEsRUFBRSxrQkFBa0IsQ0FBQyxNQUFNLENBQUM7Z0JBQ2hGLEtBQUssRUFBRSxZQUFZLENBQUMsTUFBTTthQUM3QixDQUFDO1lBRUYsU0FBUyxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsQ0FBQztZQUMzQixTQUFTLENBQUMsUUFBUSxFQUFFLENBQUM7UUFDekIsQ0FBQyxDQUFDLENBQUM7SUFDUCxDQUFDO0lBRUQsK0VBQStFO0lBQy9FLHdHQUF3RztJQUN4RyxhQUFhO0lBQ2Isd0dBQXdHO0lBQ2pHLHFCQUFxQixDQUFDLFFBQW9CLEVBQUUsV0FBbUMsRUFBRSxVQUF5QixFQUFFLFNBQWlCO1FBQ2hJLElBQUksU0FBUyxLQUFLLFFBQVEsSUFBSSxPQUFPLFVBQVUsS0FBSyxXQUFXLElBQUksVUFBVSxDQUFDLE1BQU0sR0FBRyxDQUFDLEVBQUU7WUFDdEYsT0FBTyxDQUFDLElBQUksQ0FBQywrSkFBK0osQ0FBQyxDQUFDO1lBQzlLLE9BQU8sV0FBVyxDQUFDO1NBQ3RCO1FBQ0QsT0FBTyxLQUFLLENBQUMscUJBQXFCLENBQUMsUUFBUSxFQUFFLFdBQVcsRUFBRSxVQUFVLENBQUMsQ0FBQztJQUMxRSxDQUFDO0lBRUQsK0VBQStFO0lBQy9FLHdHQUF3RztJQUN4RywwQkFBMEI7SUFDMUIsd0dBQXdHO0lBQ2hHLHNCQUFzQixDQUFDLE9BQXFCO1FBQ2hELElBQUksUUFBUSxHQUFXLElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxPQUFPLENBQUMsZ0JBQWdCLENBQUMsQ0FBQztRQUV4RSxJQUFJLGFBQWEsR0FBZ0I7WUFDN0IsWUFBWSxFQUFFLFlBQVk7WUFDMUIsc0JBQXNCLEVBQUUsSUFBSTtZQUM1Qix1QkFBdUIsRUFBRSxJQUFJO1lBRTdCLCtCQUErQixFQUFFLENBQUM7WUFDbEMsaUJBQWlCLEVBQUUsQ0FBQztZQUVwQixpQkFBaUIsRUFBRSxPQUFPO1lBQzFCLDBCQUEwQixFQUFFLElBQUk7WUFDaEMsdUJBQXVCLEVBQUUsSUFBSTtZQUU3QixjQUFjLEVBQUUsUUFBUTtTQUMzQixDQUFDO1FBRUYsSUFBSSxPQUFPLE9BQU8sQ0FBQyxRQUFRLEtBQUssV0FBVyxFQUFFO1lBQ3pDLElBQUksQ0FBQyxNQUFNLEdBQUcsT0FBTyxDQUFDLFFBQVEsQ0FBQztZQUUvQixhQUFhLENBQUMsWUFBWSxHQUFHLENBQUMsS0FBVSxFQUFVLEVBQUU7Z0JBQ2hELElBQUksS0FBSyxDQUFDLGNBQWMsQ0FBQyxPQUFPLENBQUMsUUFBUSxDQUFDLEVBQUU7b0JBQ3hDLElBQUksRUFBRSxHQUFXLEtBQUssQ0FBQyxPQUFPLENBQUMsUUFBUSxDQUFDLENBQUM7b0JBRXpDLElBQUksT0FBTyxLQUFLLENBQUMsT0FBTyxDQUFDLFFBQVEsQ0FBQyxLQUFLLFFBQVEsRUFBRTt3QkFDN0MsRUFBRSxHQUFHLEVBQUUsQ0FBQyxRQUFRLEVBQUUsQ0FBQztxQkFDdEI7b0JBRUQsT0FBTyxFQUFFLENBQUM7aUJBQ2I7Z0JBRUQsT0FBTyxFQUFFLENBQUM7WUFDZCxDQUFDLENBQUM7U0FDTDtRQUVELElBQUksT0FBTyxPQUFPLEtBQUssV0FBVyxJQUFJLE9BQU8sT0FBTyxDQUFDLFFBQVEsS0FBSyxXQUFXLEVBQUU7WUFDM0UsSUFBSSxPQUFPLENBQUMsUUFBUSxLQUFLLFVBQVUsRUFBRTtnQkFDakMsYUFBYSxDQUFDLFVBQVUsR0FBRyxJQUFJLENBQUM7Z0JBQ2hDLGFBQWEsQ0FBQyxnQkFBZ0IsR0FBRyxDQUFDLENBQUM7Z0JBRW5DLGFBQWEsQ0FBQyxrQkFBa0IsR0FBRyxRQUFRLENBQUM7YUFDL0M7aUJBQ0k7Z0JBQ0QsMEVBQTBFO2dCQUMxRSxhQUFhLENBQUMsZ0JBQWdCLEdBQUcsQ0FBQyxDQUFDO2FBQ3RDO1lBQ0QsSUFBSSxPQUFPLENBQUMsUUFBUSxJQUFJLFFBQVEsRUFBRTtnQkFDOUIsYUFBYSxDQUFDLE9BQU8sR0FBSSxJQUFJLENBQUM7YUFDakM7aUJBQU07Z0JBQ0gsYUFBYSxDQUFDLE9BQU8sR0FBSSxLQUFLLENBQUM7YUFDbEM7U0FDSjtRQUVELE9BQU8sYUFBYSxDQUFDO0lBQ3pCLENBQUM7SUFFRCx3R0FBd0c7SUFDeEcsZ0NBQWdDO0lBQ2hDLHdHQUF3RztJQUNoRywyQkFBMkIsQ0FBQyxXQUF5QixFQUFFLFFBQXVCO1FBQ2xGLElBQUksT0FBTyxXQUFXLENBQUMsU0FBUyxLQUFLLFdBQVc7WUFDNUMsT0FBTyxXQUFXLENBQUMsU0FBUyxDQUFDLElBQUksS0FBSyxXQUFXO1lBQ2pELE9BQU8sV0FBVyxDQUFDLFFBQVEsS0FBSyxXQUFXO1lBQzNDLFdBQVcsQ0FBQyxTQUFTLENBQUMsSUFBSSxLQUFLLEtBQUs7WUFDcEMsV0FBVyxDQUFDLFFBQVEsS0FBSyxVQUFVLEVBQUU7WUFDakMsT0FBTyxDQUFDLElBQUksQ0FBQywyRUFBMkUsQ0FBQyxDQUFDO1lBQzFGLE9BQU8sUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLHdCQUF3QixDQUFDO1NBQ25EO0lBQ0wsQ0FBQztJQUVPLG1CQUFtQixDQUFDLGFBQWtDO1FBQzFELElBQUksbUJBQW1CLEdBQXdCLEVBQUUsQ0FBQztRQUVsRCxLQUFLLElBQUksQ0FBQyxHQUFXLENBQUMsRUFBRSxDQUFDLEdBQUcsYUFBYSxDQUFDLE1BQU0sRUFBRSxDQUFDLEVBQUUsRUFBRTtZQUNuRCxJQUFJLEtBQUssQ0FBQyxXQUFXLENBQUMsYUFBYSxDQUFDLENBQUMsQ0FBQyxFQUFFLE9BQU8sQ0FBQyxFQUFFO2dCQUM5QyxPQUFPLENBQUMsS0FBSyxDQUFDLDZHQUE2RyxDQUFDLENBQUM7YUFDaEk7aUJBQ0k7Z0JBQ0QsSUFBSSxDQUFDLHlCQUF5QixDQUFDLGFBQWEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO2dCQUNqRCxtQkFBbUIsQ0FBQyxJQUFJLENBQUMsYUFBYSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7YUFDOUM7U0FDSjtRQUVELE9BQU8sbUJBQW1CLENBQUM7SUFDL0IsQ0FBQztJQUVPLHlCQUF5QixDQUFDLFdBQXlCO1FBQ3ZELElBQUksT0FBTyxXQUFXLENBQUMsVUFBVSxLQUFLLFdBQVcsSUFBSSxXQUFXLENBQUMsVUFBVTtZQUN2RSxDQUFDLE9BQU8sV0FBVyxDQUFDLFdBQVcsS0FBSyxXQUFXLElBQUksV0FBVyxDQUFDLFdBQVcsS0FBSyxJQUFJLElBQUksV0FBVyxDQUFDLFdBQVcsQ0FBQyxNQUFNLEtBQUssQ0FBQyxDQUFFLEVBQUU7WUFDM0gsT0FBTyxDQUFDLEtBQUssQ0FBQyxrQ0FBa0MsR0FBRyxXQUFXLENBQUMsS0FBSyxHQUFHLGlJQUFpSSxDQUFDLENBQUM7WUFDMU0sV0FBVyxDQUFDLFVBQVUsR0FBRyxLQUFLLENBQUM7U0FDdEM7SUFDTCxDQUFDO0lBRUQsNkVBQTZFO0lBQzdFLGtDQUFrQztJQUNsQywrREFBK0Q7SUFDL0QsOERBQThEO0lBQzlELHlGQUF5RjtJQUV6Riw0Q0FBNEM7SUFDNUMsMENBQTBDO0lBQzFDLGdCQUFnQjtJQUNoQixZQUFZO0lBQ1osUUFBUTtJQUNSLGtEQUFrRDtJQUNsRCw4Q0FBOEM7SUFDOUMsSUFBSTtJQUVKLHdHQUF3RztJQUN4RyxzQ0FBc0M7SUFDdEMsd0dBQXdHO0lBQ2hHLGtCQUFrQixDQUFDLFVBQXdELEVBQUUsUUFBb0I7UUFDckcsSUFBSSxVQUFVLENBQUMsTUFBTSxHQUFHLENBQUMsRUFBRTtZQUN2QixJQUFJLFdBQVcsR0FBMEMsVUFBVSxDQUFDLENBQUMsQ0FBQyxDQUFDO1lBQ3ZFLElBQUksZUFBZSxHQUFXLENBQUMsV0FBVyxDQUFDLElBQUksS0FBSyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztZQUVwRSxRQUFRLENBQUMsSUFBSSxDQUFDLENBQUMsRUFBTyxFQUFFLEVBQU8sRUFBVSxFQUFFO2dCQUN2QyxPQUFPLElBQUksQ0FBQyx5QkFBeUIsQ0FBQyxFQUFFLEVBQUUsRUFBRSxFQUFFLFdBQVcsQ0FBQyxLQUFLLEVBQUUsZUFBZSxDQUFDLENBQUM7WUFDdEYsQ0FBQyxDQUFDLENBQUM7U0FDTjtJQUNMLENBQUM7SUFFTyx5QkFBeUIsQ0FBQyxFQUFPLEVBQUUsRUFBTyxFQUFFLGVBQXVCLEVBQUUsVUFBa0I7UUFDM0YsSUFBSSxPQUFPLEVBQUUsS0FBSyxXQUFXLElBQUksT0FBTyxFQUFFLEtBQUssV0FBVyxFQUFFO1lBQ3hELElBQUksSUFBSSxHQUFRLElBQUksQ0FBQyxPQUFPLENBQUMsWUFBWSxDQUFDLEVBQUUsRUFBRSxlQUFlLENBQUMsQ0FBQztZQUMvRCxJQUFJLElBQUksR0FBUSxJQUFJLENBQUMsT0FBTyxDQUFDLFlBQVksQ0FBQyxFQUFFLEVBQUUsZUFBZSxDQUFDLENBQUM7WUFFL0QsSUFBSSxJQUFJLEdBQUcsSUFBSTtnQkFBRSxPQUFPLFVBQVUsQ0FBQztpQkFDOUIsSUFBSSxJQUFJLEdBQUcsSUFBSTtnQkFBRSxPQUFPLENBQUMsQ0FBQyxVQUFVLENBQUMsQ0FBQztZQUMzQyxPQUFPLENBQUMsQ0FBQztTQUNaO1FBQ0QsT0FBTyxDQUFDLENBQUM7SUFDYixDQUFDO0lBRU8sb0JBQW9CLENBQUMsWUFBaUIsRUFBRSxRQUFvQjtRQUNoRSxJQUFJLFlBQVksR0FBZSxFQUFFLENBQUM7UUFFbEMsSUFBSSxNQUFNLENBQUMsSUFBSSxDQUFDLFlBQVksQ0FBQyxDQUFDLE1BQU0sR0FBRyxDQUFDLEVBQUU7WUFDdEMsS0FBSyxJQUFJLElBQUksSUFBSSxZQUFZLEVBQUU7Z0JBQzNCLElBQUksWUFBWSxDQUFDLGNBQWMsQ0FBQyxJQUFJLENBQUMsRUFBRTtvQkFDbkMsSUFBSSxPQUFPLEdBQVcsSUFBSSxDQUFDO29CQUMzQixJQUFJLGVBQWUsR0FBMkIsWUFBWSxDQUFDLElBQUksQ0FBQyxDQUFDLE1BQU0sQ0FBQztvQkFFeEUsSUFBSSxlQUFlLENBQUMsTUFBTSxHQUFHLENBQUMsRUFBRTt3QkFDNUIsS0FBSyxJQUFJLENBQUMsR0FBVyxDQUFDLEVBQUUsQ0FBQyxHQUFHLFFBQVEsQ0FBQyxNQUFNLEVBQUUsQ0FBQyxFQUFFLEVBQUU7NEJBQzlDLElBQUksT0FBTyxHQUFRLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQzs0QkFFL0IsSUFBSSxPQUFPLENBQUMsY0FBYyxDQUFDLE9BQU8sQ0FBQyxJQUFJLGVBQWUsQ0FBQyxPQUFPLENBQUMsT0FBTyxDQUFDLE9BQU8sQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLEVBQUU7Z0NBQ25GLFlBQVksQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLENBQUM7NkJBQzlCO3lCQUNKO3FCQUNKO3lCQUNJO3dCQUNELFlBQVksR0FBRyxFQUFFLENBQUM7d0JBQ2xCLE1BQU07cUJBQ1Q7aUJBQ0o7YUFDSjtTQUNKO2FBQ0k7WUFDRCxZQUFZLEdBQUcsUUFBUSxDQUFDLEtBQUssRUFBRSxDQUFDO1NBQ25DO1FBRUQsT0FBTyxZQUFZLENBQUM7SUFDeEIsQ0FBQztJQUVELHdHQUF3RztJQUN4RyxrQkFBa0I7SUFDbEIsd0dBQXdHO0lBQ2hHLGlCQUFpQixDQUFDLGlCQUFzQjtRQUM1QyxJQUFJLE9BQU8saUJBQWlCLEtBQUssV0FBVztZQUN4QyxPQUFPLGlCQUFpQixDQUFDLFFBQVEsS0FBSyxXQUFXLEVBQUU7WUFDL0MsT0FBTyxpQkFBaUIsQ0FBQyxRQUFRLENBQUM7U0FDekM7UUFDRCxpQkFBaUIsQ0FBQyxRQUFRLEdBQUcsSUFBSSxDQUFDLGdCQUFnQixDQUFDO1FBQ25ELE9BQU8sSUFBSSxDQUFDLGdCQUFnQixDQUFDO0lBQ2pDLENBQUM7OztZQXpRSixVQUFVIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgSW5qZWN0YWJsZSB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xyXG5pbXBvcnQgeyBPYnNlcnZhYmxlICwgIFN1YnNjcmliZXIgfSBmcm9tICdyeGpzJztcclxuaW1wb3J0IHtcclxuICAgIEdyaWRPcHRpb25zLFxyXG4gICAgQ29sRGVmLFxyXG4gICAgLy8gSUVudGVycHJpc2VHZXRSb3dzUmVxdWVzdFxyXG59IGZyb20gJ2FnLWdyaWQtY29tbXVuaXR5JztcclxuXHJcbmltcG9ydCB7XHJcbiAgICAgSUVudGVycHJpc2VHZXRSb3dzUmVxdWVzdFxyXG59IGZyb20gJy4uL2VudGVycHJpc2UtZGF0YXNvdXJjZSc7XHJcbmltcG9ydCB7XHJcbiAgICBJVGFibGVDb2x1bW4sXHJcbiAgICBJVGFibGVDb25maWdcclxufSBmcm9tICcuLi9rZC1hbmd1bGFyLXRhYmxlLWludGVyZmFjZSc7XHJcbmltcG9ydCB7IEtkVGFibGVTdmNCYXNlIH0gZnJvbSAnLi9rZC10YWJsZS1zdmMnO1xyXG5cclxuLyoqXHJcbiAqIC0tIERvY3VtZW50YXRpb24gZm9yIGtkLXRhYmxlLWVudGVycHJpc2Utc3ZjLnRzIC0tXHJcbiAqXHJcbiAqIFB1YmxpYyBmdW5jdGlvbjpcclxuICogICAgIC0gR3JpZCBPcHRpb25zIGZ1bmN0aW9uXHJcbiAqICAgICAgICAgLSBnZW5lcmF0ZUdyaWRPcHRpb25zIChHcmlkT3B0aW9uIGdlbmVyYXRpb24gd2l0aCBncmlkQ29uZmlnKVxyXG4gKiAgICAgICAgIC0gc2V0R3JpZE9wdGlvbnNcclxuICogICAgIC0gQ29sdW1uIGRlZmluaXRpb24gZnVuY3Rpb25zXHJcbiAqICAgICAgICAgLSBzZXRDb2x1bW5EZWYgKENvbHVtbiBEZWZpbml0aW9ucyBiYXNlZCBvbiBjb2x1bW5Db25maWcgYW5kIGdyaWRDb25maWcpXHJcbiAqICAgICAgICAgLSBnZW5lcmF0ZUNvbHVtbkRlZmluaXRpb25zXHJcbiAqICAgICAtIFJvdyBkYXRhIGZ1bmN0aW9uc1xyXG4gKiAgICAgICAgIC0gc2V0Um93RGF0YSAoU2V0IHRoZSByb3dEYXRhIHRvIHRoZSBncmlkKVxyXG4gKiAgICAgLSBEYXRhc291cmNlIGZ1bmN0aW9uXHJcbiAqICAgICAgICAgLSBnZW5lcmF0ZURhdGFzb3VyY2VSb3dzIChtYW51YWwgc29ydGluZyAvIGZpbHRlcmluZyBvZiB0aGUgZGF0YXNvdXJjZSAtIEZvciBvbmVzaG90IGFuZCBpbmZpbml0ZSBsb2FkVHlwZSlcclxuICpcclxuICogUHVibGljIGZ1bmN0aW9ucyAoZnJvbSBwYXJlbnQpIC0gT3ZlcnJpZGVzOlxyXG4gKiAgICAgLSB1cGRhdGVTZWxlY3Rpb25WYWx1ZXNcclxuICpcclxuICogUHJpdmF0ZSBmdW5jdGlvbnM6XHJcbiAqICAgICAtIEdyaWQgT3B0aW9ucyBmdW5jdGlvblxyXG4gKiAgICAgICAgIC0gX2dlbmVyYXRlQ29uZmlnT3B0aW9ucyAoYWRkaXRpb25hbCBHcmlkT3B0aW9uIGZyb20gdGFibGUgY29uZmlnKVxyXG4gKiAgICAgLSBDb2x1bW4gZGVmaW5pdGlvbiBmdW5jdGlvbnNcclxuICogICAgICAgICAtIF9jaGVja0NoZWNrYm94U2VsZWN0aW9uVHlwZSAoQ2hlY2tpbmcgZm9yIHNlbGVjdGlvbiB0eXBlIGFsbCAtIEluZmluaXRlIGxvYWRUeXBlIG5vdCBhYmxlIHRvIGxvYWQpXHJcbiAqICAgICAgICAgLSBfdXBkYXRlQ29sRGVmQ29uZmlnICAoTk9URTogUmVtb3ZpbmcgaW5wdXQgY29sdW1ucyBoZXJlKVxyXG4gKiAgICAgICAgIC0gX2NoZWNrQ29sRGVmRmlsdGVyYWJsZVZhbFxyXG4gKiAgICAgLSBEYXRhc291cmNlIGZ1bmN0aW9uXHJcbiAqICAgICAgICAgLSBfZGF0YXNvdXJjZVNvcnRSb3dcclxuICogICAgICAgICAtIF9kYXRhc291cmNlUm93U29ydEZvcm11bGFcclxuICogICAgICAgICAtIF9kYXRhc291cmNlRmlsdGVyUm93XHJcbiAqICAgICAtIE1pc2MgZnVuY3Rpb25zXHJcbiAqICAgICAgICAgLSBfcmV0cmlldmVQYWdlc2l6ZVxyXG4gKi9cclxuXHJcbkBJbmplY3RhYmxlKClcclxuZXhwb3J0IGNsYXNzIEtkVGFibGVFbnRlcnByaXNlU3ZjIGV4dGVuZHMgS2RUYWJsZVN2Y0Jhc2Uge1xyXG4gICAgLyoqKioqKioqKioqKioqKioqKioqKioqKioqKioqIFB1YmxpYyBmdW5jdGlvbnMgKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqL1xyXG4gICAgLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy9cclxuICAgIC8vLyBHcmlkIG9wdGlvbnMgZnVuY3Rpb25zXHJcbiAgICAvLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vL1xyXG4gICAgcHVibGljIGdlbmVyYXRlR3JpZE9wdGlvbnMoX2dyaWRDb25maWc6IElUYWJsZUNvbmZpZywgX2RpcmVjdGlvbjogJ2x0cicgfCAncnRsJyk6IEdyaWRPcHRpb25zIHtcclxuICAgICAgICBsZXQgdGVtcEdyaWRPcHRpb25zOiBHcmlkT3B0aW9ucyA9IHN1cGVyLmdldERlZmF1bHRHcmlkT3B0aW9ucyhfZGlyZWN0aW9uLCBfZ3JpZENvbmZpZy5yb3dDb250ZW50SGVpZ2h0KTtcclxuICAgICAgICBsZXQgY29uZmlnT3B0aW9uczogR3JpZE9wdGlvbnMgPSB0aGlzLl9nZW5lcmF0ZUNvbmZpZ09wdGlvbnMoX2dyaWRDb25maWcpO1xyXG5cclxuICAgICAgICAoPGFueT5PYmplY3QpLmFzc2lnbih0ZW1wR3JpZE9wdGlvbnMsIGNvbmZpZ09wdGlvbnMpO1xyXG5cclxuICAgICAgICByZXR1cm4gdGVtcEdyaWRPcHRpb25zO1xyXG4gICAgfVxyXG5cclxuICAgIHB1YmxpYyBzZXRHcmlkT3B0aW9ucyhfZ3JpZE9wdGlvbnM6IEdyaWRPcHRpb25zKTogdm9pZCB7XHJcbiAgICAgICAgdGhpcy5ncmlkT3B0aW9ucyA9IF9ncmlkT3B0aW9ucztcclxuICAgIH1cclxuXHJcbiAgICAvLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vL1xyXG4gICAgLy8vIENvbHVtbiBkZWZpbml0aW9ucyBmdW5jdGlvbnNcclxuICAgIC8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vXHJcbiAgICBwdWJsaWMgc2V0Q29sdW1uRGVmKF9jb2xEZWZDb25maWc6IEFycmF5PElUYWJsZUNvbHVtbj4sIF9ncmlkQ29uZmlnOiBJVGFibGVDb25maWcsIF9zdXBwcmVzc01vdmFibGVDb2x1bW5zOiBib29sZWFuID0gdHJ1ZSk6IHZvaWQge1xyXG4gICAgICAgIGxldCB1cGRhdGVkQ29sdW1uOiBBcnJheTxDb2xEZWY+ID0gdGhpcy5nZW5lcmF0ZUNvbHVtbkRlZmluaXRpb25zKF9jb2xEZWZDb25maWcsIF9ncmlkQ29uZmlnLCBfc3VwcHJlc3NNb3ZhYmxlQ29sdW1ucyk7XHJcblxyXG4gICAgICAgIHRoaXMuZ3JpZE9wdGlvbnMuY29sdW1uRGVmcyA9IHVwZGF0ZWRDb2x1bW47XHJcbiAgICAgICAgaWYgKHN1cGVyLmlzQXBpUmVhZHkodGhpcy5ncmlkT3B0aW9ucykpIHtcclxuICAgICAgICAgICAgdGhpcy5ncmlkT3B0aW9ucy5hcGkuc2V0Q29sdW1uRGVmcyh1cGRhdGVkQ29sdW1uKTtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIC8vIGlmIChzdXBlci5oYXNJbnB1dFR5cGUoX2NvbERlZkNvbmZpZywgJ2ltYWdlJykpIHtcclxuICAgICAgICAvLyAgICAgdGhpcy5fdXBkYXRlUm93SGVpZ2h0Rm9ySW1nKF9jb2xEZWZDb25maWcpO1xyXG4gICAgICAgIC8vIH1cclxuICAgIH1cclxuXHJcbiAgICBwdWJsaWMgZ2VuZXJhdGVDb2x1bW5EZWZpbml0aW9ucyhfY29sRGVmQ29uZmlnOiBBcnJheTxJVGFibGVDb2x1bW4+LCBfZ3JpZENvbmZpZzogSVRhYmxlQ29uZmlnLCBfc3VwcHJlc3NNb3ZhYmxlQ29sdW1uczogYm9vbGVhbiA9IHRydWUpOiBBcnJheTxDb2xEZWY+IHtcclxuICAgICAgICBsZXQgdXBkYXRlZENvbERlZkNvbmZpZzogQXJyYXk8SVRhYmxlQ29sdW1uPiA9IHRoaXMuX3VwZGF0ZUNvbERlZkNvbmZpZyhfY29sRGVmQ29uZmlnKTtcclxuXHJcbiAgICAgICAgbGV0IGdlbmVyYXRlZENvbERlZjogQXJyYXk8Q29sRGVmPiA9IHN1cGVyLmdlbmVyYXRlQ29sdW1uRGVmaW5pdGlvbnModXBkYXRlZENvbERlZkNvbmZpZywgX2dyaWRDb25maWcsIF9zdXBwcmVzc01vdmFibGVDb2x1bW5zKTtcclxuICAgICAgICB0aGlzLl9jaGVja0NoZWNrYm94U2VsZWN0aW9uVHlwZShfZ3JpZENvbmZpZywgZ2VuZXJhdGVkQ29sRGVmKTtcclxuXHJcbiAgICAgICAgcmV0dXJuICBnZW5lcmF0ZWRDb2xEZWY7XHJcbiAgICB9XHJcblxyXG4gICAgLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy9cclxuICAgIC8vLyBSb3cgRGF0YSBmdW5jdGlvbnNcclxuICAgIC8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vXHJcbiAgICBwdWJsaWMgc2V0Um93RGF0YShfcm93RGF0YTogQXJyYXk8YW55Pik6IHZvaWQge1xyXG4gICAgICAgIHRoaXMuZ3JpZE9wdGlvbnMucm93RGF0YSA9IF9yb3dEYXRhO1xyXG4gICAgfVxyXG5cclxuICAgIC8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vXHJcbiAgICAvLy8gRGF0YXNvdXJjZSBmdW5jdGlvbnNcclxuICAgIC8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vXHJcbiAgICBwdWJsaWMgZ2VuZXJhdGVEYXRhc291cmNlUm93cyhfZGF0YXNvdXJjZVJlcXVlc3Q6IElFbnRlcnByaXNlR2V0Um93c1JlcXVlc3QsIF9yb3dEYXRhOiBBcnJheTxhbnk+KTogT2JzZXJ2YWJsZTxhbnk+IHtcclxuICAgICAgICByZXR1cm4gbmV3IE9ic2VydmFibGU8YW55PigoX29ic2VydmVyOiBTdWJzY3JpYmVyPGFueT4pOiB2b2lkID0+IHtcclxuICAgICAgICAgICAgLy8gY29uc29sZS5sb2coJy0tIEdyaWQgc3RhdGU6IGdlbmVyYXRlIERhdGFzb3VyY2Ugcm93cyAtLScsIF9kYXRhc291cmNlUmVxdWVzdCk7XHJcblxyXG4gICAgICAgICAgICBsZXQgdGVtcFJvd01vZGVsOiBBcnJheTxhbnk+ID0gdGhpcy5fZGF0YXNvdXJjZUZpbHRlclJvdyhfZGF0YXNvdXJjZVJlcXVlc3QuZmlsdGVyTW9kZWwsIF9yb3dEYXRhKTtcclxuICAgICAgICAgICAgdGhpcy5fZGF0YXNvdXJjZVNvcnRSb3coX2RhdGFzb3VyY2VSZXF1ZXN0LnNvcnRNb2RlbCwgdGVtcFJvd01vZGVsKTtcclxuXHJcbiAgICAgICAgICAgIGxldCByZXF1ZXN0T2JqOiB7cm93czogQXJyYXk8YW55PiwgdG90YWw6IG51bWJlcn0gPSB7XHJcbiAgICAgICAgICAgICAgICByb3dzOiB0ZW1wUm93TW9kZWwuc2xpY2UoX2RhdGFzb3VyY2VSZXF1ZXN0LnN0YXJ0Um93LCBfZGF0YXNvdXJjZVJlcXVlc3QuZW5kUm93KSxcclxuICAgICAgICAgICAgICAgIHRvdGFsOiB0ZW1wUm93TW9kZWwubGVuZ3RoXHJcbiAgICAgICAgICAgIH07XHJcblxyXG4gICAgICAgICAgICBfb2JzZXJ2ZXIubmV4dChyZXF1ZXN0T2JqKTtcclxuICAgICAgICAgICAgX29ic2VydmVyLmNvbXBsZXRlKCk7XHJcbiAgICAgICAgfSk7XHJcbiAgICB9XHJcblxyXG4gICAgLyoqKioqKioqKioqKioqKioqKioqKioqKiBQdWJsaWMgZnVuY3Rpb25zIGZyb20gcGFyZW50ICoqKioqKioqKioqKioqKioqKioqKioqL1xyXG4gICAgLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy9cclxuICAgIC8vLyBPdmVycmlkZXNcclxuICAgIC8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vXHJcbiAgICBwdWJsaWMgdXBkYXRlU2VsZWN0aW9uVmFsdWVzKF9yb3dEYXRhOiBBcnJheTxhbnk+LCBfc2VsZWN0ZWRJZDogQXJyYXk8c3RyaW5nIHwgbnVtYmVyPiwgX3JldHVybktleTogQXJyYXk8c3RyaW5nPiwgX2xvYWRUeXBlOiBzdHJpbmcpOiBBcnJheTxhbnk+IHtcclxuICAgICAgICBpZiAoX2xvYWRUeXBlID09PSAnc2VydmVyJyAmJiB0eXBlb2YgX3JldHVybktleSAhPT0gJ3VuZGVmaW5lZCcgJiYgX3JldHVybktleS5sZW5ndGggPiAwKSB7XHJcbiAgICAgICAgICAgIGNvbnNvbGUud2FybignS2RUYWJsZSB3YXJuaW5nOiBTZWxlY3Rpb24gdmFsdWUgbm90IGFibGUgdG8gcmV0dXJuIGFzIG9iamVjdHMgc3BlY2lmeSBpbiB0aGUgcmV0dXJuS2V5IHByb3BlcnR5IGFzIHRoZXJlIG1pZ2h0IGhhdmUgdW5rbm93biBkYXRhIHZhbHVlcyBmb3Igc2VydmVyIGxvYWRUeXBlLicpO1xyXG4gICAgICAgICAgICByZXR1cm4gX3NlbGVjdGVkSWQ7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIHJldHVybiBzdXBlci51cGRhdGVTZWxlY3Rpb25WYWx1ZXMoX3Jvd0RhdGEsIF9zZWxlY3RlZElkLCBfcmV0dXJuS2V5KTtcclxuICAgIH1cclxuXHJcbiAgICAvKioqKioqKioqKioqIEVuZCBvZiBwdWJsaWMgZnVuY3Rpb25zIC8gU3RhcnQgb2YgcHJpdmF0ZSBmdW5jdGlvbnMgKioqKioqKioqKiovXHJcbiAgICAvLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vL1xyXG4gICAgLy8vIEdyaWQgb3B0aW9ucyBmdW5jdGlvbnNcclxuICAgIC8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vXHJcbiAgICBwcml2YXRlIF9nZW5lcmF0ZUNvbmZpZ09wdGlvbnMoX2NvbmZpZzogSVRhYmxlQ29uZmlnKTogR3JpZE9wdGlvbnMge1xyXG4gICAgICAgIGxldCBwYWdlc2l6ZTogbnVtYmVyID0gdGhpcy5fcmV0cmlldmVQYWdlc2l6ZShfY29uZmlnLnBhZ2luYXRpb25Db25maWcpO1xyXG5cclxuICAgICAgICBsZXQgY29uZmlnT3B0aW9uczogR3JpZE9wdGlvbnMgPSB7XHJcbiAgICAgICAgICAgIHJvd01vZGVsVHlwZTogJ2VudGVycHJpc2UnLFxyXG4gICAgICAgICAgICBlbmFibGVTZXJ2ZXJTaWRlRmlsdGVyOiB0cnVlLFxyXG4gICAgICAgICAgICBlbmFibGVTZXJ2ZXJTaWRlU29ydGluZzogdHJ1ZSxcclxuXHJcbiAgICAgICAgICAgIG1heENvbmN1cnJlbnREYXRhc291cmNlUmVxdWVzdHM6IDIsXHJcbiAgICAgICAgICAgIGNhY2hlT3ZlcmZsb3dTaXplOiAxLFxyXG5cclxuICAgICAgICAgICAgcm93R3JvdXBQYW5lbFNob3c6ICduZXZlcicsXHJcbiAgICAgICAgICAgIHRvb2xQYW5lbFN1cHByZXNzUGl2b3RNb2RlOiB0cnVlLFxyXG4gICAgICAgICAgICB0b29sUGFuZWxTdXBwcmVzc1ZhbHVlczogdHJ1ZSxcclxuXHJcbiAgICAgICAgICAgIGNhY2hlQmxvY2tTaXplOiBwYWdlc2l6ZVxyXG4gICAgICAgIH07XHJcblxyXG4gICAgICAgIGlmICh0eXBlb2YgX2NvbmZpZy5yb3dJZEtleSAhPT0gJ3VuZGVmaW5lZCcpIHtcclxuICAgICAgICAgICAgdGhpcy5yb3dLZXkgPSBfY29uZmlnLnJvd0lkS2V5O1xyXG5cclxuICAgICAgICAgICAgY29uZmlnT3B0aW9ucy5nZXRSb3dOb2RlSWQgPSAoX2RhdGE6IGFueSk6IHN0cmluZyA9PiB7XHJcbiAgICAgICAgICAgICAgICBpZiAoX2RhdGEuaGFzT3duUHJvcGVydHkoX2NvbmZpZy5yb3dJZEtleSkpIHtcclxuICAgICAgICAgICAgICAgICAgICBsZXQgaWQ6IHN0cmluZyA9IF9kYXRhW19jb25maWcucm93SWRLZXldO1xyXG5cclxuICAgICAgICAgICAgICAgICAgICBpZiAodHlwZW9mIF9kYXRhW19jb25maWcucm93SWRLZXldID09PSAnbnVtYmVyJykge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBpZCA9IGlkLnRvU3RyaW5nKCk7XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgICAgICAgICByZXR1cm4gaWQ7XHJcbiAgICAgICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICAgICAgcmV0dXJuICcnO1xyXG4gICAgICAgICAgICB9O1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgaWYgKHR5cGVvZiBfY29uZmlnICE9PSAndW5kZWZpbmVkJyAmJiB0eXBlb2YgX2NvbmZpZy5sb2FkVHlwZSAhPT0gJ3VuZGVmaW5lZCcpIHtcclxuICAgICAgICAgICAgaWYgKF9jb25maWcubG9hZFR5cGUgIT09ICdpbmZpbml0ZScpIHtcclxuICAgICAgICAgICAgICAgIGNvbmZpZ09wdGlvbnMucGFnaW5hdGlvbiA9IHRydWU7XHJcbiAgICAgICAgICAgICAgICBjb25maWdPcHRpb25zLm1heEJsb2Nrc0luQ2FjaGUgPSAwO1xyXG5cclxuICAgICAgICAgICAgICAgIGNvbmZpZ09wdGlvbnMucGFnaW5hdGlvblBhZ2VTaXplID0gcGFnZXNpemU7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgZWxzZSB7XHJcbiAgICAgICAgICAgICAgICAvLyBBdXRvIGhlaWdodCB0YWtlcyBhIGxvdCBvZiBoZWlnaHQsIHdpbGwgY2F1c2UgaW5maW5pdGUgcmV0cmlldmluZyBpc3N1ZVxyXG4gICAgICAgICAgICAgICAgY29uZmlnT3B0aW9ucy5tYXhCbG9ja3NJbkNhY2hlID0gNTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBpZiAoX2NvbmZpZy5sb2FkVHlwZSA9PSAnbm9ybWFsJykge1xyXG4gICAgICAgICAgICAgICAgY29uZmlnT3B0aW9ucy5zaWRlQmFyID0gIHRydWU7XHJcbiAgICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgICAgICBjb25maWdPcHRpb25zLnNpZGVCYXIgPSAgZmFsc2U7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIHJldHVybiBjb25maWdPcHRpb25zO1xyXG4gICAgfVxyXG5cclxuICAgIC8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vXHJcbiAgICAvLy8gQ29sdW1uIGRlZmluaXRpb25zIGZ1bmN0aW9uc1xyXG4gICAgLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy9cclxuICAgIHByaXZhdGUgX2NoZWNrQ2hlY2tib3hTZWxlY3Rpb25UeXBlKF9ncmlkQ29uZmlnOiBJVGFibGVDb25maWcsIF9jb2xEZWZzOiBBcnJheTxDb2xEZWY+KTogdm9pZCB7XHJcbiAgICAgICAgaWYgKHR5cGVvZiBfZ3JpZENvbmZpZy5zZWxlY3Rpb24gIT09ICd1bmRlZmluZWQnICYmXHJcbiAgICAgICAgICAgIHR5cGVvZiBfZ3JpZENvbmZpZy5zZWxlY3Rpb24udHlwZSAhPT0gJ3VuZGVmaW5lZCcgJiZcclxuICAgICAgICAgICAgdHlwZW9mIF9ncmlkQ29uZmlnLmxvYWRUeXBlICE9PSAndW5kZWZpbmVkJyAmJlxyXG4gICAgICAgICAgICBfZ3JpZENvbmZpZy5zZWxlY3Rpb24udHlwZSA9PT0gJ2FsbCcgJiZcclxuICAgICAgICAgICAgX2dyaWRDb25maWcubG9hZFR5cGUgPT09ICdpbmZpbml0ZScpIHtcclxuICAgICAgICAgICAgICAgIGNvbnNvbGUud2FybignS2RUYWJsZSB3YXJuaW5nOiBJbmZpbml0ZSBsb2FkVHlwZSBub3QgYWJsZSB0byBzdXBwb3J0IGFsbCBzZWxlY3Rpb25UeXBlLicpO1xyXG4gICAgICAgICAgICAgICAgZGVsZXRlIF9jb2xEZWZzWzBdLmhlYWRlckNvbXBvbmVudEZyYW1ld29yaztcclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfdXBkYXRlQ29sRGVmQ29uZmlnKF9jb2xEZWZDb25maWc6IEFycmF5PElUYWJsZUNvbHVtbj4pOiBBcnJheTxJVGFibGVDb2x1bW4+IHtcclxuICAgICAgICBsZXQgdXBkYXRlZENvbERlZkNvbmZpZzogQXJyYXk8SVRhYmxlQ29sdW1uPiA9IFtdO1xyXG5cclxuICAgICAgICBmb3IgKGxldCBpOiBudW1iZXIgPSAwOyBpIDwgX2NvbERlZkNvbmZpZy5sZW5ndGg7IGkrKykge1xyXG4gICAgICAgICAgICBpZiAoc3VwZXIuaXNJbnB1dFR5cGUoX2NvbERlZkNvbmZpZ1tpXSwgJ2lucHV0JykpIHtcclxuICAgICAgICAgICAgICAgIGNvbnNvbGUuZXJyb3IoJ0tkVGFibGUgZXJyb3I6IGlucHV0IGNvbHVtbiB0eXBlIGlzIG9ubHkgdmFsaWQgZm9yIG5vcm1hbCBsb2FkVHlwZSB0YWJsZS4gUmVtb3ZpbmcgY29sdW1ucyB3aXRoIGlucHV0IHR5cGUuJyk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgZWxzZSB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLl9jaGVja0NvbERlZkZpbHRlcmFibGVWYWwoX2NvbERlZkNvbmZpZ1tpXSk7XHJcbiAgICAgICAgICAgICAgICB1cGRhdGVkQ29sRGVmQ29uZmlnLnB1c2goX2NvbERlZkNvbmZpZ1tpXSk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIHJldHVybiB1cGRhdGVkQ29sRGVmQ29uZmlnO1xyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX2NoZWNrQ29sRGVmRmlsdGVyYWJsZVZhbChfY29sRGVmSXRlbTogSVRhYmxlQ29sdW1uKTogdm9pZCB7XHJcbiAgICAgICAgaWYgKHR5cGVvZiBfY29sRGVmSXRlbS5maWx0ZXJhYmxlICE9PSAndW5kZWZpbmVkJyAmJiBfY29sRGVmSXRlbS5maWx0ZXJhYmxlICYmXHJcbiAgICAgICAgICAgICh0eXBlb2YgX2NvbERlZkl0ZW0uZmlsdGVyVmFsdWUgPT09ICd1bmRlZmluZWQnIHx8IF9jb2xEZWZJdGVtLmZpbHRlclZhbHVlID09PSBudWxsIHx8IF9jb2xEZWZJdGVtLmZpbHRlclZhbHVlLmxlbmd0aCA9PT0gMCApKSB7XHJcbiAgICAgICAgICAgICAgICBjb25zb2xlLmVycm9yKCdLZFRhYmxlIGVycm9yOiBGaWx0ZXIgdmFsdWUgZm9yICcgKyBfY29sRGVmSXRlbS5maWVsZCArICcgZmllbGQgaXMgZW1wdHkuIFVzaW5nIGZpbHRlciBmb3IgbG9hZFR5cGUgb25lc2hvdC9pbmZpbml0ZS9zZXJ2ZXIgcmVxdWlyZXMgdG8gcHJvdmlkZSBmaWx0ZXJWYWx1ZS4gU3VwcHJlc3NpbmcgZmlsdGVyaW5nIG1lbnUuJyk7XHJcbiAgICAgICAgICAgICAgICBfY29sRGVmSXRlbS5maWx0ZXJhYmxlID0gZmFsc2U7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIC8vIHByaXZhdGUgX3VwZGF0ZVJvd0hlaWdodEZvckltZyhfY29sRGVmQ29uZmlnOiBBcnJheTxJVGFibGVDb2x1bW4+KTogdm9pZCB7XHJcbiAgICAvLyAgICAgbGV0IG1heEhlaWdodDogbnVtYmVyID0gNTA7XHJcbiAgICAvLyAgICAgZm9yIChsZXQgaTogbnVtYmVyID0gMDsgaSA8IF9jb2xEZWZDb25maWcubGVuZ3RoOyArK2kpIHtcclxuICAgIC8vICAgICAgICAgaWYgKHN1cGVyLmlzSW5wdXRUeXBlKF9jb2xEZWZDb25maWdbaV0sICdpbWFnZScpKSB7XHJcbiAgICAvLyAgICAgICAgICAgICBsZXQgdGVtcEhlaWdodDogbnVtYmVyID0gc3VwZXIuZ2V0SW1hZ2VTaXplQnkoX2NvbERlZkNvbmZpZ1tpXSwgJ2hlaWdodCcpO1xyXG5cclxuICAgIC8vICAgICAgICAgICAgIGlmICh0ZW1wSGVpZ2h0ID4gbWF4SGVpZ2h0KSB7XHJcbiAgICAvLyAgICAgICAgICAgICAgICAgbWF4SGVpZ2h0ID0gdGVtcEhlaWdodDtcclxuICAgIC8vICAgICAgICAgICAgIH1cclxuICAgIC8vICAgICAgICAgfVxyXG4gICAgLy8gICAgIH1cclxuICAgIC8vICAgICBjb25zb2xlLmxvZygncm93IGhlaWdodCBtYXg6ICcsIG1heEhlaWdodCk7XHJcbiAgICAvLyAgICAgdGhpcy5ncmlkT3B0aW9ucy5yb3dIZWlnaHQgPSBtYXhIZWlnaHQ7XHJcbiAgICAvLyB9XHJcblxyXG4gICAgLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy9cclxuICAgIC8vLyBEYXRhc291cmNlIHNvcnQgLyBmaWx0ZXIgZnVuY3Rpb25zXHJcbiAgICAvLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vL1xyXG4gICAgcHJpdmF0ZSBfZGF0YXNvdXJjZVNvcnRSb3coX3NvcnRNb2RlbDogQXJyYXk8e2NvbElkOiBzdHJpbmcsIHNvcnQ6ICdhc2MnIHwgJ2Rlc2MnfT4sIF9yb3dEYXRhOiBBcnJheTxhbnk+KTogdm9pZCB7XHJcbiAgICAgICAgaWYgKF9zb3J0TW9kZWwubGVuZ3RoID4gMCkge1xyXG4gICAgICAgICAgICBsZXQgc29ydE9wdGlvbnM6IHtjb2xJZDogc3RyaW5nLCBzb3J0OiAnYXNjJyB8ICdkZXNjJ30gPSBfc29ydE1vZGVsWzBdO1xyXG4gICAgICAgICAgICBsZXQgcmV0dXJuQ29uZGl0aW9uOiBudW1iZXIgPSAoc29ydE9wdGlvbnMuc29ydCA9PT0gJ2FzYycpID8gMSA6IC0xO1xyXG5cclxuICAgICAgICAgICAgX3Jvd0RhdGEuc29ydCgoX2E6IGFueSwgX2I6IGFueSk6IG51bWJlciA9PiB7XHJcbiAgICAgICAgICAgICAgICByZXR1cm4gdGhpcy5fZGF0YXNvdXJjZVJvd1NvcnRGb3JtdWxhKF9hLCBfYiwgc29ydE9wdGlvbnMuY29sSWQsIHJldHVybkNvbmRpdGlvbik7XHJcbiAgICAgICAgICAgIH0pO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF9kYXRhc291cmNlUm93U29ydEZvcm11bGEoX2E6IGFueSwgX2I6IGFueSwgX2RvdERpc3BsYXlGcm9tOiBzdHJpbmcsIF9yZXR1cm5WYWw6IG51bWJlcik6IG51bWJlciB7XHJcbiAgICAgICAgaWYgKHR5cGVvZiBfYSAhPT0gJ3VuZGVmaW5lZCcgJiYgdHlwZW9mIF9iICE9PSAndW5kZWZpbmVkJykge1xyXG4gICAgICAgICAgICBsZXQgYVZhbDogYW55ID0gdGhpcy5kYXRhU3ZjLmdldERhdGFWYWx1ZShfYSwgX2RvdERpc3BsYXlGcm9tKTtcclxuICAgICAgICAgICAgbGV0IGJWYWw6IGFueSA9IHRoaXMuZGF0YVN2Yy5nZXREYXRhVmFsdWUoX2IsIF9kb3REaXNwbGF5RnJvbSk7XHJcblxyXG4gICAgICAgICAgICBpZiAoYVZhbCA+IGJWYWwpIHJldHVybiBfcmV0dXJuVmFsO1xyXG4gICAgICAgICAgICBlbHNlIGlmIChhVmFsIDwgYlZhbCkgcmV0dXJuIC0oX3JldHVyblZhbCk7XHJcbiAgICAgICAgICAgIHJldHVybiAwO1xyXG4gICAgICAgIH1cclxuICAgICAgICByZXR1cm4gMDtcclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF9kYXRhc291cmNlRmlsdGVyUm93KF9maWx0ZXJNb2RlbDogYW55LCBfcm93RGF0YTogQXJyYXk8YW55Pik6IEFycmF5PGFueT4ge1xyXG4gICAgICAgIGxldCB0ZW1wUm93TW9kZWw6IEFycmF5PGFueT4gPSBbXTtcclxuXHJcbiAgICAgICAgaWYgKE9iamVjdC5rZXlzKF9maWx0ZXJNb2RlbCkubGVuZ3RoID4gMCkge1xyXG4gICAgICAgICAgICBmb3IgKGxldCBpdGVtIGluIF9maWx0ZXJNb2RlbCkge1xyXG4gICAgICAgICAgICAgICAgaWYgKF9maWx0ZXJNb2RlbC5oYXNPd25Qcm9wZXJ0eShpdGVtKSkge1xyXG4gICAgICAgICAgICAgICAgICAgIGxldCBkYXRhS2V5OiBzdHJpbmcgPSBpdGVtO1xyXG4gICAgICAgICAgICAgICAgICAgIGxldCBmaWx0ZXJNb2RlbEl0ZW06IEFycmF5PHN0cmluZyB8IG51bWJlcj4gPSBfZmlsdGVyTW9kZWxbaXRlbV0udmFsdWVzO1xyXG5cclxuICAgICAgICAgICAgICAgICAgICBpZiAoZmlsdGVyTW9kZWxJdGVtLmxlbmd0aCA+IDApIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgZm9yIChsZXQgaTogbnVtYmVyID0gMDsgaSA8IF9yb3dEYXRhLmxlbmd0aDsgaSsrKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBsZXQgcm93SXRlbTogYW55ID0gX3Jvd0RhdGFbaV07XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKHJvd0l0ZW0uaGFzT3duUHJvcGVydHkoZGF0YUtleSkgJiYgZmlsdGVyTW9kZWxJdGVtLmluZGV4T2Yocm93SXRlbVtkYXRhS2V5XSkgPiAtMSkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRlbXBSb3dNb2RlbC5wdXNoKHJvd0l0ZW0pO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB0ZW1wUm93TW9kZWwgPSBbXTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICB0ZW1wUm93TW9kZWwgPSBfcm93RGF0YS5zbGljZSgpO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgcmV0dXJuIHRlbXBSb3dNb2RlbDtcclxuICAgIH1cclxuXHJcbiAgICAvLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vL1xyXG4gICAgLy8vIE1pc2MgZnVuY3Rpb25zXHJcbiAgICAvLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vL1xyXG4gICAgcHJpdmF0ZSBfcmV0cmlldmVQYWdlc2l6ZShfcGFnaW5hdGlvbkNvbmZpZzogYW55KTogbnVtYmVyIHtcclxuICAgICAgICBpZiAodHlwZW9mIF9wYWdpbmF0aW9uQ29uZmlnICE9PSAndW5kZWZpbmVkJyAmJlxyXG4gICAgICAgICAgICB0eXBlb2YgX3BhZ2luYXRpb25Db25maWcucGFnZXNpemUgIT09ICd1bmRlZmluZWQnKSB7XHJcbiAgICAgICAgICAgICAgICByZXR1cm4gX3BhZ2luYXRpb25Db25maWcucGFnZXNpemU7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIF9wYWdpbmF0aW9uQ29uZmlnLnBhZ2VzaXplID0gdGhpcy5ERUZBVUxUX1BBR0VTSVpFO1xyXG4gICAgICAgIHJldHVybiB0aGlzLkRFRkFVTFRfUEFHRVNJWkU7XHJcbiAgICB9XHJcblxyXG4gICAgLyoqKioqKioqKioqKioqKioqKioqKioqKiogRW5kIG9mIHByaXZhdGUgZnVuY3Rpb25zICoqKioqKioqKioqKioqKioqKioqKioqKioqL1xyXG59XHJcbiJdfQ==