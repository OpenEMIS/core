import { Component, Input, ViewEncapsulation, ViewContainerRef, ChangeDetectorRef, Renderer2 } from '@angular/core';
import { timer } from 'rxjs';
import { Router, NavigationEnd } from '@angular/router';
import { KdDomElemSvc } from '../kd-common/index';
import { KdLeftmenuSvc } from './kd-angular-leftmenu-svc';
export class KdLeftMenu {
    constructor(_renderer, _vcr, _leftmenuSvc, _router, _cdf, _domSvc) {
        this._renderer = _renderer;
        this._vcr = _vcr;
        this._leftmenuSvc = _leftmenuSvc;
        this._router = _router;
        this._cdf = _cdf;
        this._domSvc = _domSvc;
        this.list = [];
        this._previousId = [];
        this._previousItem = {};
        this._activeIdFound = false;
        this._firstRouteCheck = true;
        this._currentRoute = '';
        this._routerSub = _router.events.subscribe(event => {
            if (event instanceof NavigationEnd) {
                this._currentRoute = event.urlAfterRedirects;
                if (!this._firstRouteCheck) {
                    this._setInitOpen(event.urlAfterRedirects);
                    // close the previous item if current clicked path do not much any path in the sidemenu
                    if (!this._activeIdFound && typeof this._previousItem.nav_id !== 'undefined') {
                        let close = this._leftmenuSvc.getId(this._previousItem);
                        this._leftmenuSvc.toggleState(close, 'close', this.list);
                        this._previousId = [];
                        this._previousItem = {};
                    }
                }
            }
        });
    }
    ngOnInit() {
        this._initApi();
    }
    ngOnChanges(_simpleChanges) {
        if (_simpleChanges.hasOwnProperty('sideConfig')) {
            this.list = this._leftmenuSvc.setIsOpen(this.sideConfig);
            if (_simpleChanges.sideConfig.isFirstChange) {
                this._setAlpha(true);
                timer(500).subscribe(() => {
                    this._setInitOpen(this._router.url);
                    this._setAlpha(false);
                    this._firstRouteCheck = false;
                });
            }
        }
    }
    ngAfterViewInit() { }
    ngOnDestroy() {
        if (typeof this._routerSub !== 'undefined') {
            this._routerSub.unsubscribe();
        }
    }
    clickToggle(item) {
        this._checkToggle(item);
        if (typeof item.list === 'undefined') {
            this._checkPathAndNavigate(item);
        }
        // triggers click event when api is initialised
        if (this.api)
            this._leftmenuSvc.menuItemClicked(item);
    }
    getPaddingSize(_itemId) {
        let size = 10;
        let navLevels = _itemId.split('-');
        if (navLevels.length > 2) {
            size += (17 * (navLevels.length - 2));
        }
        // console.log(_itemId);
        if (this._domSvc.getDocumentDirection().toLowerCase() === 'ltr')
            return '10px 25px 10px ' + size + 'px';
        else
            return '10px ' + size + 'px 10px 25px';
    }
    getItemOrder(_item) {
        return (typeof _item.order === 'undefined') ? 1 : _item.order;
    }
    _checkPathAndNavigate(item) {
        if (typeof item.path !== 'undefined') {
            this._router.navigate([item.path]);
        }
        else {
            this._router.navigate(['/']);
        }
    }
    _setAlpha(bool) {
        let ulList = this._vcr.element.nativeElement.querySelector('ul.nav.root-nav');
        bool ? this._renderer.addClass(ulList, 'alpha-0') : this._renderer.removeClass(ulList, 'alpha-0');
    }
    _setInitOpen(rawUrl) {
        this._activeIdFound = false;
        let url = rawUrl.split('/');
        let testUrl = [];
        let joinUrl = '';
        for (let i = url.length - 1; i >= 0; i--) {
            testUrl = [];
            //  console.log('----> round ' + i);
            for (let j = 0; j <= i; j++) {
                testUrl.push(url[j]);
            }
            joinUrl = testUrl.join('/').substring(1);
            if (this._activeIdFound === false) {
                // this._cdf.detach();
                this._checkPath(joinUrl, this.list);
                this._cdf.detectChanges();
                // this._cdf.reattach();
            }
        }
    }
    _checkPath(url, itemList) {
        let resultPath = '';
        for (let i = 0; i < itemList.length; i++) {
            if (typeof itemList[i].list !== 'undefined') {
                this._checkPath(url, itemList[i].list);
            }
            resultPath = (typeof itemList[i].basePath !== 'undefined' && itemList[i].basePath[0] === '/') ? itemList[i].basePath.substring(1) : itemList[i].basePath;
            if (resultPath === url) {
                this._itemSelected(itemList[i]);
                this._activeIdFound = true;
                break;
            }
        }
    }
    _itemSelected(item) {
        this._checkToggle(item);
        this._previousItem.isSelected = false;
        this._previousItem = item;
        item.isSelected = true;
    }
    _checkToggle(item) {
        let currentId = this._leftmenuSvc.getId(item);
        // if user clicked the same, toggle state
        if (this._leftmenuSvc.isArrayEqual(currentId, this._previousId) && item.hasOwnProperty('isOpen')) {
            this._leftmenuSvc.toggleState(currentId, 'toggle', this.list);
        }
        // if user clicked on something more on the surface, check
        else if (this._previousId.length > currentId.length) {
            //  this._closeDifferent(currentId, this._previousId);
            this._leftmenuSvc.closeDifferent(currentId, this._previousId, this.list);
        }
        // if user clicked on something deeper, close previous and open current
        else {
            //  if (item.hasOwnProperty('isOpen')) {
            if (this._previousId.length > 0) {
                this._leftmenuSvc.toggleState(this._previousId, 'close', this.list);
            }
            //  }
            this._leftmenuSvc.toggleState(currentId, 'open', this.list);
        }
        this._previousId = currentId;
    }
    _initApi() {
        if (!this.api)
            return;
        this.api.onMenuItemClicked = this._leftmenuSvc.onMenuItemClicked();
        this.api.updateMenuList = (_nav_id, _list) => {
            let navPos = this._leftmenuSvc.getId(_nav_id);
            let selectedItem = {};
            if (navPos.length > 0) {
                selectedItem = this.list[navPos[0]];
                for (let i = 1; i < navPos.length; i++) {
                    selectedItem = selectedItem.list[navPos[i]];
                }
                if (typeof _list !== 'undefined') {
                    selectedItem['list'] = _list;
                    this.list = this._leftmenuSvc.setIsOpen(this.list);
                    this._setInitOpen(this._currentRoute);
                }
            }
        };
    }
}
KdLeftMenu.decorators = [
    { type: Component, args: [{
                selector: 'kd-leftmenu',
                template: "<div class=\"kdx-left-menu\">\r\n    <div class=\"panel-group\">\r\n        <ul class=\"nav root-nav\">\r\n            <ng-template #recursiveList let-list>\r\n                <li *ngFor=\"let item of list\" [style.order]=\"getItemOrder(item)\">\r\n                    <a [ngClass]=\"{'selected': item.isSelected, 'accordion-toggle': item.list, 'expand': item.isOpen}\" \r\n                    [hidden]=\"item.selected\" \r\n                    [attr.id]=\"item.nav_id\" \r\n                    (click)=\"clickToggle(item)\" \r\n                    [style.padding]=\"getPaddingSize(item.nav_id)\">\r\n                        <i *ngIf=\"item.icon\" class=\"{{item.icon}}\"></i><span>{{item.header}}</span>\r\n                    </a>\r\n                    <ul *ngIf=\"item.list\" class=\"nav\" [ngClass]=\"{'toggle': item.isOpen, 'untoggle': !item.isOpen}\">\r\n                        <ng-container *ngTemplateOutlet=\"recursiveList; context:{ $implicit: item.list }\"></ng-container>\r\n                    </ul>\r\n                </li>\r\n            </ng-template>\r\n            <ng-container *ngTemplateOutlet=\"recursiveList; context:{ $implicit: list }\"></ng-container>\r\n        </ul>\r\n    </div>\r\n</div>\r\n",
                encapsulation: ViewEncapsulation.None,
                providers: [KdLeftmenuSvc, KdDomElemSvc],
                styles: [`
        .alpha-0{
            opacity: 0;
        }
    `]
            },] }
];
KdLeftMenu.ctorParameters = () => [
    { type: Renderer2 },
    { type: ViewContainerRef },
    { type: KdLeftmenuSvc },
    { type: Router },
    { type: ChangeDetectorRef },
    { type: KdDomElemSvc }
];
KdLeftMenu.propDecorators = {
    sideConfig: [{ type: Input, args: ['config',] }],
    api: [{ type: Input }]
};
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoia2QtYW5ndWxhci1sZWZ0bWVudS5qcyIsInNvdXJjZVJvb3QiOiJEOi9vcGVuRU1JUy9zdHlsZWd1aWRlL2lvc3RnLW9wZW5lbWlzLXN0eWxlZ3VpZGUvcHJvamVjdHMvb3BlbmVtaXMtc3R5bGVndWlkZS1saWIvc3JjLyIsInNvdXJjZXMiOlsia2QtY29tcG9uZW50cy9rZC1hbmd1bGFyLWxlZnRtZW51L2tkLWFuZ3VsYXItbGVmdG1lbnUudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsT0FBTyxFQUFFLFNBQVMsRUFBRSxLQUFLLEVBQXlCLGlCQUFpQixFQUFFLGdCQUFnQixFQUFFLGlCQUFpQixFQUFpQixTQUFTLEVBQUUsTUFBTSxlQUFlLENBQUM7QUFDMUosT0FBTyxFQUFFLEtBQUssRUFBZ0IsTUFBTSxNQUFNLENBQUM7QUFDM0MsT0FBTyxFQUFFLE1BQU0sRUFBRSxhQUFhLEVBQUUsTUFBTSxpQkFBaUIsQ0FBQztBQUN4RCxPQUFPLEVBQUUsWUFBWSxFQUFFLE1BQU0sb0JBQW9CLENBQUM7QUFDbEQsT0FBTyxFQUFFLGFBQWEsRUFBRSxNQUFNLDJCQUEyQixDQUFDO0FBYzFELE1BQU0sT0FBTyxVQUFVO0lBWW5CLFlBQ1ksU0FBb0IsRUFDcEIsSUFBc0IsRUFDdEIsWUFBMkIsRUFDM0IsT0FBZSxFQUNmLElBQXVCLEVBQ3ZCLE9BQXFCO1FBTHJCLGNBQVMsR0FBVCxTQUFTLENBQVc7UUFDcEIsU0FBSSxHQUFKLElBQUksQ0FBa0I7UUFDdEIsaUJBQVksR0FBWixZQUFZLENBQWU7UUFDM0IsWUFBTyxHQUFQLE9BQU8sQ0FBUTtRQUNmLFNBQUksR0FBSixJQUFJLENBQW1CO1FBQ3ZCLFlBQU8sR0FBUCxPQUFPLENBQWM7UUFqQjFCLFNBQUksR0FBZSxFQUFFLENBQUM7UUFDckIsZ0JBQVcsR0FBa0IsRUFBRSxDQUFDO1FBQ2hDLGtCQUFhLEdBQVEsRUFBRSxDQUFDO1FBQ3hCLG1CQUFjLEdBQVksS0FBSyxDQUFDO1FBQ2hDLHFCQUFnQixHQUFZLElBQUksQ0FBQztRQUVqQyxrQkFBYSxHQUFXLEVBQUUsQ0FBQztRQWEvQixJQUFJLENBQUMsVUFBVSxHQUFHLE9BQU8sQ0FBQyxNQUFNLENBQUMsU0FBUyxDQUFDLEtBQUssQ0FBQyxFQUFFO1lBQy9DLElBQUksS0FBSyxZQUFZLGFBQWEsRUFBRTtnQkFDaEMsSUFBSSxDQUFDLGFBQWEsR0FBRyxLQUFLLENBQUMsaUJBQWlCLENBQUM7Z0JBQzdDLElBQUksQ0FBQyxJQUFJLENBQUMsZ0JBQWdCLEVBQUU7b0JBQ3hCLElBQUksQ0FBQyxZQUFZLENBQUMsS0FBSyxDQUFDLGlCQUFpQixDQUFDLENBQUM7b0JBQzNDLHVGQUF1RjtvQkFDdkYsSUFBSSxDQUFDLElBQUksQ0FBQyxjQUFjLElBQUksT0FBTyxJQUFJLENBQUMsYUFBYSxDQUFDLE1BQU0sS0FBSyxXQUFXLEVBQUU7d0JBQzFFLElBQUksS0FBSyxHQUFlLElBQUksQ0FBQyxZQUFZLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxhQUFhLENBQUMsQ0FBQzt3QkFDcEUsSUFBSSxDQUFDLFlBQVksQ0FBQyxXQUFXLENBQUMsS0FBSyxFQUFFLE9BQU8sRUFBRSxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUM7d0JBQ3pELElBQUksQ0FBQyxXQUFXLEdBQUcsRUFBRSxDQUFDO3dCQUN0QixJQUFJLENBQUMsYUFBYSxHQUFHLEVBQUUsQ0FBQztxQkFDM0I7aUJBQ0o7YUFDSjtRQUNMLENBQUMsQ0FBQyxDQUFDO0lBQ1AsQ0FBQztJQUVELFFBQVE7UUFDSixJQUFJLENBQUMsUUFBUSxFQUFFLENBQUM7SUFDcEIsQ0FBQztJQUVELFdBQVcsQ0FBQyxjQUE2QjtRQUNyQyxJQUFJLGNBQWMsQ0FBQyxjQUFjLENBQUMsWUFBWSxDQUFDLEVBQUU7WUFDN0MsSUFBSSxDQUFDLElBQUksR0FBRyxJQUFJLENBQUMsWUFBWSxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLENBQUM7WUFFekQsSUFBSSxjQUFjLENBQUMsVUFBVSxDQUFDLGFBQWEsRUFBRTtnQkFDekMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsQ0FBQztnQkFFckIsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxHQUFHLEVBQUU7b0JBQ3RCLElBQUksQ0FBQyxZQUFZLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsQ0FBQztvQkFDcEMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxLQUFLLENBQUMsQ0FBQztvQkFDdEIsSUFBSSxDQUFDLGdCQUFnQixHQUFHLEtBQUssQ0FBQztnQkFDbEMsQ0FBQyxDQUFDLENBQUM7YUFDTjtTQUNKO0lBQ0wsQ0FBQztJQUVELGVBQWUsS0FBVyxDQUFDO0lBRTNCLFdBQVc7UUFDUCxJQUFJLE9BQU8sSUFBSSxDQUFDLFVBQVUsS0FBSyxXQUFXLEVBQUU7WUFDeEMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxXQUFXLEVBQUUsQ0FBQztTQUNqQztJQUNMLENBQUM7SUFFTSxXQUFXLENBQUMsSUFBUztRQUN4QixJQUFJLENBQUMsWUFBWSxDQUFDLElBQUksQ0FBQyxDQUFDO1FBRXhCLElBQUksT0FBTyxJQUFJLENBQUMsSUFBSSxLQUFLLFdBQVcsRUFBRTtZQUNsQyxJQUFJLENBQUMscUJBQXFCLENBQUMsSUFBSSxDQUFDLENBQUM7U0FDcEM7UUFFRCwrQ0FBK0M7UUFDL0MsSUFBSSxJQUFJLENBQUMsR0FBRztZQUFFLElBQUksQ0FBQyxZQUFZLENBQUMsZUFBZSxDQUFDLElBQUksQ0FBQyxDQUFDO0lBQzFELENBQUM7SUFFTSxjQUFjLENBQUMsT0FBZTtRQUNqQyxJQUFJLElBQUksR0FBVyxFQUFFLENBQUM7UUFDdEIsSUFBSSxTQUFTLEdBQWtCLE9BQU8sQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLENBQUM7UUFFbEQsSUFBSSxTQUFTLENBQUMsTUFBTSxHQUFHLENBQUMsRUFBRTtZQUN0QixJQUFJLElBQUksQ0FBQyxFQUFFLEdBQUcsQ0FBQyxTQUFTLENBQUMsTUFBTSxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUM7U0FDekM7UUFDRCx3QkFBd0I7UUFDeEIsSUFBSSxJQUFJLENBQUMsT0FBTyxDQUFDLG9CQUFvQixFQUFFLENBQUMsV0FBVyxFQUFFLEtBQUssS0FBSztZQUFFLE9BQU8saUJBQWlCLEdBQUcsSUFBSSxHQUFHLElBQUksQ0FBQzs7WUFDbkcsT0FBTyxPQUFPLEdBQUcsSUFBSSxHQUFHLGNBQWMsQ0FBQztJQUNoRCxDQUFDO0lBRU0sWUFBWSxDQUFDLEtBQVU7UUFDMUIsT0FBTyxDQUFDLE9BQU8sS0FBSyxDQUFDLEtBQUssS0FBSyxXQUFXLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDO0lBQ2xFLENBQUM7SUFFTyxxQkFBcUIsQ0FBQyxJQUFTO1FBQ25DLElBQUksT0FBTyxJQUFJLENBQUMsSUFBSSxLQUFLLFdBQVcsRUFBRTtZQUNsQyxJQUFJLENBQUMsT0FBTyxDQUFDLFFBQVEsQ0FBQyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDO1NBQ3RDO2FBQ0k7WUFDRCxJQUFJLENBQUMsT0FBTyxDQUFDLFFBQVEsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUM7U0FDaEM7SUFDTCxDQUFDO0lBRU8sU0FBUyxDQUFDLElBQWE7UUFDM0IsSUFBSSxNQUFNLEdBQUcsSUFBSSxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsYUFBYSxDQUFDLGFBQWEsQ0FBQyxpQkFBaUIsQ0FBQyxDQUFDO1FBQzlFLElBQUksQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxRQUFRLENBQUMsTUFBTSxFQUFFLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLFdBQVcsQ0FBQyxNQUFNLEVBQUUsU0FBUyxDQUFDLENBQUM7SUFDdEcsQ0FBQztJQUVPLFlBQVksQ0FBQyxNQUFjO1FBQy9CLElBQUksQ0FBQyxjQUFjLEdBQUcsS0FBSyxDQUFDO1FBQzVCLElBQUksR0FBRyxHQUFlLE1BQU0sQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLENBQUM7UUFDeEMsSUFBSSxPQUFPLEdBQWUsRUFBRSxDQUFDO1FBQzdCLElBQUksT0FBTyxHQUFXLEVBQUUsQ0FBQztRQUV6QixLQUFLLElBQUksQ0FBQyxHQUFXLEdBQUcsQ0FBQyxNQUFNLEdBQUcsQ0FBQyxFQUFFLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxFQUFFLEVBQUU7WUFDOUMsT0FBTyxHQUFHLEVBQUUsQ0FBQztZQUNiLG9DQUFvQztZQUNwQyxLQUFLLElBQUksQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFO2dCQUN6QixPQUFPLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO2FBQ3hCO1lBRUQsT0FBTyxHQUFHLE9BQU8sQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDO1lBQ3pDLElBQUksSUFBSSxDQUFDLGNBQWMsS0FBSyxLQUFLLEVBQUU7Z0JBQy9CLHNCQUFzQjtnQkFDdEIsSUFBSSxDQUFDLFVBQVUsQ0FBQyxPQUFPLEVBQUUsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDO2dCQUNwQyxJQUFJLENBQUMsSUFBSSxDQUFDLGFBQWEsRUFBRSxDQUFDO2dCQUMxQix3QkFBd0I7YUFDM0I7U0FDSjtJQUNMLENBQUM7SUFFTyxVQUFVLENBQUMsR0FBVyxFQUFFLFFBQW9CO1FBQ2hELElBQUksVUFBVSxHQUFXLEVBQUUsQ0FBQztRQUU1QixLQUFLLElBQUksQ0FBQyxHQUFXLENBQUMsRUFBRSxDQUFDLEdBQUcsUUFBUSxDQUFDLE1BQU0sRUFBRSxDQUFDLEVBQUUsRUFBRTtZQUM5QyxJQUFJLE9BQU8sUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksS0FBSyxXQUFXLEVBQUU7Z0JBQ3pDLElBQUksQ0FBQyxVQUFVLENBQUMsR0FBRyxFQUFFLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQzthQUMxQztZQUVELFVBQVUsR0FBRyxDQUFDLE9BQU8sUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsS0FBSyxXQUFXLElBQUksUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsS0FBSyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUM7WUFFekosSUFBSSxVQUFVLEtBQUssR0FBRyxFQUFFO2dCQUNwQixJQUFJLENBQUMsYUFBYSxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO2dCQUNoQyxJQUFJLENBQUMsY0FBYyxHQUFHLElBQUksQ0FBQztnQkFDM0IsTUFBTTthQUNUO1NBQ0o7SUFDTCxDQUFDO0lBRU8sYUFBYSxDQUFDLElBQVM7UUFDM0IsSUFBSSxDQUFDLFlBQVksQ0FBQyxJQUFJLENBQUMsQ0FBQztRQUN4QixJQUFJLENBQUMsYUFBYSxDQUFDLFVBQVUsR0FBRyxLQUFLLENBQUM7UUFDdEMsSUFBSSxDQUFDLGFBQWEsR0FBRyxJQUFJLENBQUM7UUFDMUIsSUFBSSxDQUFDLFVBQVUsR0FBRyxJQUFJLENBQUM7SUFDM0IsQ0FBQztJQUVPLFlBQVksQ0FBQyxJQUFTO1FBQzFCLElBQUksU0FBUyxHQUFHLElBQUksQ0FBQyxZQUFZLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxDQUFDO1FBRTlDLHlDQUF5QztRQUN6QyxJQUFJLElBQUksQ0FBQyxZQUFZLENBQUMsWUFBWSxDQUFDLFNBQVMsRUFBRSxJQUFJLENBQUMsV0FBVyxDQUFDLElBQUksSUFBSSxDQUFDLGNBQWMsQ0FBQyxRQUFRLENBQUMsRUFBRTtZQUM5RixJQUFJLENBQUMsWUFBWSxDQUFDLFdBQVcsQ0FBQyxTQUFTLEVBQUUsUUFBUSxFQUFFLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQztTQUNqRTtRQUVELDBEQUEwRDthQUNyRCxJQUFJLElBQUksQ0FBQyxXQUFXLENBQUMsTUFBTSxHQUFHLFNBQVMsQ0FBQyxNQUFNLEVBQUU7WUFDakQsc0RBQXNEO1lBQ3RELElBQUksQ0FBQyxZQUFZLENBQUMsY0FBYyxDQUFDLFNBQVMsRUFBRSxJQUFJLENBQUMsV0FBVyxFQUFFLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQztTQUM1RTtRQUVELHVFQUF1RTthQUNsRTtZQUNELHdDQUF3QztZQUN4QyxJQUFJLElBQUksQ0FBQyxXQUFXLENBQUMsTUFBTSxHQUFHLENBQUMsRUFBRTtnQkFDN0IsSUFBSSxDQUFDLFlBQVksQ0FBQyxXQUFXLENBQUMsSUFBSSxDQUFDLFdBQVcsRUFBRSxPQUFPLEVBQUUsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDO2FBQ3ZFO1lBQ0QsS0FBSztZQUNMLElBQUksQ0FBQyxZQUFZLENBQUMsV0FBVyxDQUFDLFNBQVMsRUFBRSxNQUFNLEVBQUUsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDO1NBQy9EO1FBQ0QsSUFBSSxDQUFDLFdBQVcsR0FBRyxTQUFTLENBQUM7SUFDakMsQ0FBQztJQUVPLFFBQVE7UUFDWixJQUFJLENBQUMsSUFBSSxDQUFDLEdBQUc7WUFBRSxPQUFPO1FBRXRCLElBQUksQ0FBQyxHQUFHLENBQUMsaUJBQWlCLEdBQUcsSUFBSSxDQUFDLFlBQVksQ0FBQyxpQkFBaUIsRUFBRSxDQUFDO1FBRW5FLElBQUksQ0FBQyxHQUFHLENBQUMsY0FBYyxHQUFHLENBQUMsT0FBZSxFQUFFLEtBQWtCLEVBQUUsRUFBRTtZQUM5RCxJQUFJLE1BQU0sR0FBa0IsSUFBSSxDQUFDLFlBQVksQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLENBQUM7WUFDN0QsSUFBSSxZQUFZLEdBQVEsRUFBRSxDQUFDO1lBQzNCLElBQUksTUFBTSxDQUFDLE1BQU0sR0FBRyxDQUFDLEVBQUU7Z0JBQ25CLFlBQVksR0FBRyxJQUFJLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO2dCQUNwQyxLQUFLLElBQUksQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLEdBQUcsTUFBTSxDQUFDLE1BQU0sRUFBRSxDQUFDLEVBQUUsRUFBRTtvQkFDcEMsWUFBWSxHQUFHLFlBQVksQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7aUJBQy9DO2dCQUVELElBQUksT0FBTyxLQUFLLEtBQUssV0FBVyxFQUFFO29CQUM5QixZQUFZLENBQUMsTUFBTSxDQUFDLEdBQUcsS0FBSyxDQUFDO29CQUM3QixJQUFJLENBQUMsSUFBSSxHQUFHLElBQUksQ0FBQyxZQUFZLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQztvQkFDbkQsSUFBSSxDQUFDLFlBQVksQ0FBQyxJQUFJLENBQUMsYUFBYSxDQUFDLENBQUM7aUJBQ3pDO2FBQ0o7UUFDTCxDQUFDLENBQUM7SUFDTixDQUFDOzs7WUFyTkosU0FBUyxTQUFDO2dCQUNQLFFBQVEsRUFBRSxhQUFhO2dCQUN2QixvdENBQXlDO2dCQU16QyxhQUFhLEVBQUUsaUJBQWlCLENBQUMsSUFBSTtnQkFDckMsU0FBUyxFQUFFLENBQUMsYUFBYSxFQUFFLFlBQVksQ0FBQzt5QkFOL0I7Ozs7S0FJUjthQUdKOzs7WUFoQndILFNBQVM7WUFBN0QsZ0JBQWdCO1lBSTVFLGFBQWE7WUFGYixNQUFNO1lBRndFLGlCQUFpQjtZQUcvRixZQUFZOzs7eUJBd0JoQixLQUFLLFNBQUMsUUFBUTtrQkFDZCxLQUFLIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgQ29tcG9uZW50LCBJbnB1dCwgT25Jbml0LCBBZnRlclZpZXdJbml0LCBWaWV3RW5jYXBzdWxhdGlvbiwgVmlld0NvbnRhaW5lclJlZiwgQ2hhbmdlRGV0ZWN0b3JSZWYsIFNpbXBsZUNoYW5nZXMsIFJlbmRlcmVyMiB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xyXG5pbXBvcnQgeyB0aW1lciwgU3Vic2NyaXB0aW9uIH0gZnJvbSAncnhqcyc7XHJcbmltcG9ydCB7IFJvdXRlciwgTmF2aWdhdGlvbkVuZCB9IGZyb20gJ0Bhbmd1bGFyL3JvdXRlcic7XHJcbmltcG9ydCB7IEtkRG9tRWxlbVN2YyB9IGZyb20gJy4uL2tkLWNvbW1vbi9pbmRleCc7XHJcbmltcG9ydCB7IEtkTGVmdG1lbnVTdmMgfSBmcm9tICcuL2tkLWFuZ3VsYXItbGVmdG1lbnUtc3ZjJztcclxuXHJcbkBDb21wb25lbnQoe1xyXG4gICAgc2VsZWN0b3I6ICdrZC1sZWZ0bWVudScsXHJcbiAgICB0ZW1wbGF0ZVVybDogJy4va2QtYW5ndWxhci1sZWZ0bWVudS5odG1sJyxcclxuICAgIHN0eWxlczogW2BcclxuICAgICAgICAuYWxwaGEtMHtcclxuICAgICAgICAgICAgb3BhY2l0eTogMDtcclxuICAgICAgICB9XHJcbiAgICBgXSxcclxuICAgIGVuY2Fwc3VsYXRpb246IFZpZXdFbmNhcHN1bGF0aW9uLk5vbmUsXHJcbiAgICBwcm92aWRlcnM6IFtLZExlZnRtZW51U3ZjLCBLZERvbUVsZW1TdmNdXHJcbn0pXHJcblxyXG5leHBvcnQgY2xhc3MgS2RMZWZ0TWVudSBpbXBsZW1lbnRzIE9uSW5pdCwgQWZ0ZXJWaWV3SW5pdCB7XHJcbiAgICBwdWJsaWMgbGlzdDogQXJyYXk8YW55PiA9IFtdO1xyXG4gICAgcHJpdmF0ZSBfcHJldmlvdXNJZDogQXJyYXk8bnVtYmVyPiA9IFtdO1xyXG4gICAgcHJpdmF0ZSBfcHJldmlvdXNJdGVtOiBhbnkgPSB7fTtcclxuICAgIHByaXZhdGUgX2FjdGl2ZUlkRm91bmQ6IGJvb2xlYW4gPSBmYWxzZTtcclxuICAgIHByaXZhdGUgX2ZpcnN0Um91dGVDaGVjazogYm9vbGVhbiA9IHRydWU7XHJcbiAgICBwcml2YXRlIF9yb3V0ZXJTdWI6IFN1YnNjcmlwdGlvbjtcclxuICAgIHByaXZhdGUgX2N1cnJlbnRSb3V0ZTogc3RyaW5nID0gJyc7XHJcblxyXG4gICAgQElucHV0KCdjb25maWcnKSBzaWRlQ29uZmlnOiBBcnJheTxhbnk+O1xyXG4gICAgQElucHV0KCkgYXBpOiBhbnk7XHJcblxyXG4gICAgY29uc3RydWN0b3IoXHJcbiAgICAgICAgcHJpdmF0ZSBfcmVuZGVyZXI6IFJlbmRlcmVyMixcclxuICAgICAgICBwcml2YXRlIF92Y3I6IFZpZXdDb250YWluZXJSZWYsXHJcbiAgICAgICAgcHJpdmF0ZSBfbGVmdG1lbnVTdmM6IEtkTGVmdG1lbnVTdmMsXHJcbiAgICAgICAgcHJpdmF0ZSBfcm91dGVyOiBSb3V0ZXIsXHJcbiAgICAgICAgcHJpdmF0ZSBfY2RmOiBDaGFuZ2VEZXRlY3RvclJlZixcclxuICAgICAgICBwcml2YXRlIF9kb21TdmM6IEtkRG9tRWxlbVN2Y1xyXG4gICAgKSB7XHJcbiAgICAgICAgdGhpcy5fcm91dGVyU3ViID0gX3JvdXRlci5ldmVudHMuc3Vic2NyaWJlKGV2ZW50ID0+IHtcclxuICAgICAgICAgICAgaWYgKGV2ZW50IGluc3RhbmNlb2YgTmF2aWdhdGlvbkVuZCkge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5fY3VycmVudFJvdXRlID0gZXZlbnQudXJsQWZ0ZXJSZWRpcmVjdHM7XHJcbiAgICAgICAgICAgICAgICBpZiAoIXRoaXMuX2ZpcnN0Um91dGVDaGVjaykge1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuX3NldEluaXRPcGVuKGV2ZW50LnVybEFmdGVyUmVkaXJlY3RzKTtcclxuICAgICAgICAgICAgICAgICAgICAvLyBjbG9zZSB0aGUgcHJldmlvdXMgaXRlbSBpZiBjdXJyZW50IGNsaWNrZWQgcGF0aCBkbyBub3QgbXVjaCBhbnkgcGF0aCBpbiB0aGUgc2lkZW1lbnVcclxuICAgICAgICAgICAgICAgICAgICBpZiAoIXRoaXMuX2FjdGl2ZUlkRm91bmQgJiYgdHlwZW9mIHRoaXMuX3ByZXZpb3VzSXRlbS5uYXZfaWQgIT09ICd1bmRlZmluZWQnKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGxldCBjbG9zZTogQXJyYXk8YW55PiA9IHRoaXMuX2xlZnRtZW51U3ZjLmdldElkKHRoaXMuX3ByZXZpb3VzSXRlbSk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuX2xlZnRtZW51U3ZjLnRvZ2dsZVN0YXRlKGNsb3NlLCAnY2xvc2UnLCB0aGlzLmxpc3QpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLl9wcmV2aW91c0lkID0gW107XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuX3ByZXZpb3VzSXRlbSA9IHt9O1xyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH0pO1xyXG4gICAgfVxyXG5cclxuICAgIG5nT25Jbml0KCk6IHZvaWQge1xyXG4gICAgICAgIHRoaXMuX2luaXRBcGkoKTtcclxuICAgIH1cclxuXHJcbiAgICBuZ09uQ2hhbmdlcyhfc2ltcGxlQ2hhbmdlczogU2ltcGxlQ2hhbmdlcyk6IHZvaWQge1xyXG4gICAgICAgIGlmIChfc2ltcGxlQ2hhbmdlcy5oYXNPd25Qcm9wZXJ0eSgnc2lkZUNvbmZpZycpKSB7XHJcbiAgICAgICAgICAgIHRoaXMubGlzdCA9IHRoaXMuX2xlZnRtZW51U3ZjLnNldElzT3Blbih0aGlzLnNpZGVDb25maWcpO1xyXG5cclxuICAgICAgICAgICAgaWYgKF9zaW1wbGVDaGFuZ2VzLnNpZGVDb25maWcuaXNGaXJzdENoYW5nZSkge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5fc2V0QWxwaGEodHJ1ZSk7XHJcblxyXG4gICAgICAgICAgICAgICAgdGltZXIoNTAwKS5zdWJzY3JpYmUoKCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuX3NldEluaXRPcGVuKHRoaXMuX3JvdXRlci51cmwpO1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuX3NldEFscGhhKGZhbHNlKTtcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLl9maXJzdFJvdXRlQ2hlY2sgPSBmYWxzZTtcclxuICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIG5nQWZ0ZXJWaWV3SW5pdCgpOiB2b2lkIHsgfVxyXG5cclxuICAgIG5nT25EZXN0cm95KCk6IHZvaWQge1xyXG4gICAgICAgIGlmICh0eXBlb2YgdGhpcy5fcm91dGVyU3ViICE9PSAndW5kZWZpbmVkJykge1xyXG4gICAgICAgICAgICB0aGlzLl9yb3V0ZXJTdWIudW5zdWJzY3JpYmUoKTtcclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgcHVibGljIGNsaWNrVG9nZ2xlKGl0ZW06IGFueSk6IHZvaWQge1xyXG4gICAgICAgIHRoaXMuX2NoZWNrVG9nZ2xlKGl0ZW0pO1xyXG5cclxuICAgICAgICBpZiAodHlwZW9mIGl0ZW0ubGlzdCA9PT0gJ3VuZGVmaW5lZCcpIHtcclxuICAgICAgICAgICAgdGhpcy5fY2hlY2tQYXRoQW5kTmF2aWdhdGUoaXRlbSk7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICAvLyB0cmlnZ2VycyBjbGljayBldmVudCB3aGVuIGFwaSBpcyBpbml0aWFsaXNlZFxyXG4gICAgICAgIGlmICh0aGlzLmFwaSkgdGhpcy5fbGVmdG1lbnVTdmMubWVudUl0ZW1DbGlja2VkKGl0ZW0pO1xyXG4gICAgfVxyXG5cclxuICAgIHB1YmxpYyBnZXRQYWRkaW5nU2l6ZShfaXRlbUlkOiBzdHJpbmcpOiBzdHJpbmcge1xyXG4gICAgICAgIGxldCBzaXplOiBudW1iZXIgPSAxMDtcclxuICAgICAgICBsZXQgbmF2TGV2ZWxzOiBBcnJheTxzdHJpbmc+ID0gX2l0ZW1JZC5zcGxpdCgnLScpO1xyXG5cclxuICAgICAgICBpZiAobmF2TGV2ZWxzLmxlbmd0aCA+IDIpIHtcclxuICAgICAgICAgICAgc2l6ZSArPSAoMTcgKiAobmF2TGV2ZWxzLmxlbmd0aCAtIDIpKTtcclxuICAgICAgICB9XHJcbiAgICAgICAgLy8gY29uc29sZS5sb2coX2l0ZW1JZCk7XHJcbiAgICAgICAgaWYgKHRoaXMuX2RvbVN2Yy5nZXREb2N1bWVudERpcmVjdGlvbigpLnRvTG93ZXJDYXNlKCkgPT09ICdsdHInKSByZXR1cm4gJzEwcHggMjVweCAxMHB4ICcgKyBzaXplICsgJ3B4JztcclxuICAgICAgICBlbHNlIHJldHVybiAnMTBweCAnICsgc2l6ZSArICdweCAxMHB4IDI1cHgnO1xyXG4gICAgfVxyXG5cclxuICAgIHB1YmxpYyBnZXRJdGVtT3JkZXIoX2l0ZW06IGFueSk6IG51bWJlciB7XHJcbiAgICAgICAgcmV0dXJuICh0eXBlb2YgX2l0ZW0ub3JkZXIgPT09ICd1bmRlZmluZWQnKSA/IDEgOiBfaXRlbS5vcmRlcjtcclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF9jaGVja1BhdGhBbmROYXZpZ2F0ZShpdGVtOiBhbnkpOiB2b2lkIHtcclxuICAgICAgICBpZiAodHlwZW9mIGl0ZW0ucGF0aCAhPT0gJ3VuZGVmaW5lZCcpIHtcclxuICAgICAgICAgICAgdGhpcy5fcm91dGVyLm5hdmlnYXRlKFtpdGVtLnBhdGhdKTtcclxuICAgICAgICB9XHJcbiAgICAgICAgZWxzZSB7XHJcbiAgICAgICAgICAgIHRoaXMuX3JvdXRlci5uYXZpZ2F0ZShbJy8nXSk7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX3NldEFscGhhKGJvb2w6IGJvb2xlYW4pOiB2b2lkIHtcclxuICAgICAgICBsZXQgdWxMaXN0ID0gdGhpcy5fdmNyLmVsZW1lbnQubmF0aXZlRWxlbWVudC5xdWVyeVNlbGVjdG9yKCd1bC5uYXYucm9vdC1uYXYnKTtcclxuICAgICAgICBib29sID8gdGhpcy5fcmVuZGVyZXIuYWRkQ2xhc3ModWxMaXN0LCAnYWxwaGEtMCcpIDogdGhpcy5fcmVuZGVyZXIucmVtb3ZlQ2xhc3ModWxMaXN0LCAnYWxwaGEtMCcpO1xyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX3NldEluaXRPcGVuKHJhd1VybDogc3RyaW5nKTogdm9pZCB7XHJcbiAgICAgICAgdGhpcy5fYWN0aXZlSWRGb3VuZCA9IGZhbHNlO1xyXG4gICAgICAgIGxldCB1cmw6IEFycmF5PGFueT4gPSByYXdVcmwuc3BsaXQoJy8nKTtcclxuICAgICAgICBsZXQgdGVzdFVybDogQXJyYXk8YW55PiA9IFtdO1xyXG4gICAgICAgIGxldCBqb2luVXJsOiBzdHJpbmcgPSAnJztcclxuXHJcbiAgICAgICAgZm9yIChsZXQgaTogbnVtYmVyID0gdXJsLmxlbmd0aCAtIDE7IGkgPj0gMDsgaS0tKSB7XHJcbiAgICAgICAgICAgIHRlc3RVcmwgPSBbXTtcclxuICAgICAgICAgICAgLy8gIGNvbnNvbGUubG9nKCctLS0tPiByb3VuZCAnICsgaSk7XHJcbiAgICAgICAgICAgIGZvciAobGV0IGogPSAwOyBqIDw9IGk7IGorKykge1xyXG4gICAgICAgICAgICAgICAgdGVzdFVybC5wdXNoKHVybFtqXSk7XHJcbiAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgIGpvaW5VcmwgPSB0ZXN0VXJsLmpvaW4oJy8nKS5zdWJzdHJpbmcoMSk7XHJcbiAgICAgICAgICAgIGlmICh0aGlzLl9hY3RpdmVJZEZvdW5kID09PSBmYWxzZSkge1xyXG4gICAgICAgICAgICAgICAgLy8gdGhpcy5fY2RmLmRldGFjaCgpO1xyXG4gICAgICAgICAgICAgICAgdGhpcy5fY2hlY2tQYXRoKGpvaW5VcmwsIHRoaXMubGlzdCk7XHJcbiAgICAgICAgICAgICAgICB0aGlzLl9jZGYuZGV0ZWN0Q2hhbmdlcygpO1xyXG4gICAgICAgICAgICAgICAgLy8gdGhpcy5fY2RmLnJlYXR0YWNoKCk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfY2hlY2tQYXRoKHVybDogc3RyaW5nLCBpdGVtTGlzdDogQXJyYXk8YW55Pik6IHZvaWQge1xyXG4gICAgICAgIGxldCByZXN1bHRQYXRoOiBzdHJpbmcgPSAnJztcclxuXHJcbiAgICAgICAgZm9yIChsZXQgaTogbnVtYmVyID0gMDsgaSA8IGl0ZW1MaXN0Lmxlbmd0aDsgaSsrKSB7XHJcbiAgICAgICAgICAgIGlmICh0eXBlb2YgaXRlbUxpc3RbaV0ubGlzdCAhPT0gJ3VuZGVmaW5lZCcpIHtcclxuICAgICAgICAgICAgICAgIHRoaXMuX2NoZWNrUGF0aCh1cmwsIGl0ZW1MaXN0W2ldLmxpc3QpO1xyXG4gICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICByZXN1bHRQYXRoID0gKHR5cGVvZiBpdGVtTGlzdFtpXS5iYXNlUGF0aCAhPT0gJ3VuZGVmaW5lZCcgJiYgaXRlbUxpc3RbaV0uYmFzZVBhdGhbMF0gPT09ICcvJykgPyBpdGVtTGlzdFtpXS5iYXNlUGF0aC5zdWJzdHJpbmcoMSkgOiBpdGVtTGlzdFtpXS5iYXNlUGF0aDtcclxuXHJcbiAgICAgICAgICAgIGlmIChyZXN1bHRQYXRoID09PSB1cmwpIHtcclxuICAgICAgICAgICAgICAgIHRoaXMuX2l0ZW1TZWxlY3RlZChpdGVtTGlzdFtpXSk7XHJcbiAgICAgICAgICAgICAgICB0aGlzLl9hY3RpdmVJZEZvdW5kID0gdHJ1ZTtcclxuICAgICAgICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX2l0ZW1TZWxlY3RlZChpdGVtOiBhbnkpOiB2b2lkIHtcclxuICAgICAgICB0aGlzLl9jaGVja1RvZ2dsZShpdGVtKTtcclxuICAgICAgICB0aGlzLl9wcmV2aW91c0l0ZW0uaXNTZWxlY3RlZCA9IGZhbHNlO1xyXG4gICAgICAgIHRoaXMuX3ByZXZpb3VzSXRlbSA9IGl0ZW07XHJcbiAgICAgICAgaXRlbS5pc1NlbGVjdGVkID0gdHJ1ZTtcclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF9jaGVja1RvZ2dsZShpdGVtOiBhbnkpOiB2b2lkIHtcclxuICAgICAgICBsZXQgY3VycmVudElkID0gdGhpcy5fbGVmdG1lbnVTdmMuZ2V0SWQoaXRlbSk7XHJcblxyXG4gICAgICAgIC8vIGlmIHVzZXIgY2xpY2tlZCB0aGUgc2FtZSwgdG9nZ2xlIHN0YXRlXHJcbiAgICAgICAgaWYgKHRoaXMuX2xlZnRtZW51U3ZjLmlzQXJyYXlFcXVhbChjdXJyZW50SWQsIHRoaXMuX3ByZXZpb3VzSWQpICYmIGl0ZW0uaGFzT3duUHJvcGVydHkoJ2lzT3BlbicpKSB7XHJcbiAgICAgICAgICAgIHRoaXMuX2xlZnRtZW51U3ZjLnRvZ2dsZVN0YXRlKGN1cnJlbnRJZCwgJ3RvZ2dsZScsIHRoaXMubGlzdCk7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICAvLyBpZiB1c2VyIGNsaWNrZWQgb24gc29tZXRoaW5nIG1vcmUgb24gdGhlIHN1cmZhY2UsIGNoZWNrXHJcbiAgICAgICAgZWxzZSBpZiAodGhpcy5fcHJldmlvdXNJZC5sZW5ndGggPiBjdXJyZW50SWQubGVuZ3RoKSB7XHJcbiAgICAgICAgICAgIC8vICB0aGlzLl9jbG9zZURpZmZlcmVudChjdXJyZW50SWQsIHRoaXMuX3ByZXZpb3VzSWQpO1xyXG4gICAgICAgICAgICB0aGlzLl9sZWZ0bWVudVN2Yy5jbG9zZURpZmZlcmVudChjdXJyZW50SWQsIHRoaXMuX3ByZXZpb3VzSWQsIHRoaXMubGlzdCk7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICAvLyBpZiB1c2VyIGNsaWNrZWQgb24gc29tZXRoaW5nIGRlZXBlciwgY2xvc2UgcHJldmlvdXMgYW5kIG9wZW4gY3VycmVudFxyXG4gICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICAvLyAgaWYgKGl0ZW0uaGFzT3duUHJvcGVydHkoJ2lzT3BlbicpKSB7XHJcbiAgICAgICAgICAgIGlmICh0aGlzLl9wcmV2aW91c0lkLmxlbmd0aCA+IDApIHtcclxuICAgICAgICAgICAgICAgIHRoaXMuX2xlZnRtZW51U3ZjLnRvZ2dsZVN0YXRlKHRoaXMuX3ByZXZpb3VzSWQsICdjbG9zZScsIHRoaXMubGlzdCk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgLy8gIH1cclxuICAgICAgICAgICAgdGhpcy5fbGVmdG1lbnVTdmMudG9nZ2xlU3RhdGUoY3VycmVudElkLCAnb3BlbicsIHRoaXMubGlzdCk7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIHRoaXMuX3ByZXZpb3VzSWQgPSBjdXJyZW50SWQ7XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfaW5pdEFwaSgpOiB2b2lkIHtcclxuICAgICAgICBpZiAoIXRoaXMuYXBpKSByZXR1cm47XHJcblxyXG4gICAgICAgIHRoaXMuYXBpLm9uTWVudUl0ZW1DbGlja2VkID0gdGhpcy5fbGVmdG1lbnVTdmMub25NZW51SXRlbUNsaWNrZWQoKTtcclxuXHJcbiAgICAgICAgdGhpcy5hcGkudXBkYXRlTWVudUxpc3QgPSAoX25hdl9pZDogc3RyaW5nLCBfbGlzdD86IEFycmF5PGFueT4pID0+IHtcclxuICAgICAgICAgICAgbGV0IG5hdlBvczogQXJyYXk8bnVtYmVyPiA9IHRoaXMuX2xlZnRtZW51U3ZjLmdldElkKF9uYXZfaWQpO1xyXG4gICAgICAgICAgICBsZXQgc2VsZWN0ZWRJdGVtOiBhbnkgPSB7fTtcclxuICAgICAgICAgICAgaWYgKG5hdlBvcy5sZW5ndGggPiAwKSB7XHJcbiAgICAgICAgICAgICAgICBzZWxlY3RlZEl0ZW0gPSB0aGlzLmxpc3RbbmF2UG9zWzBdXTtcclxuICAgICAgICAgICAgICAgIGZvciAobGV0IGkgPSAxOyBpIDwgbmF2UG9zLmxlbmd0aDsgaSsrKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgc2VsZWN0ZWRJdGVtID0gc2VsZWN0ZWRJdGVtLmxpc3RbbmF2UG9zW2ldXTtcclxuICAgICAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgICAgICBpZiAodHlwZW9mIF9saXN0ICE9PSAndW5kZWZpbmVkJykge1xyXG4gICAgICAgICAgICAgICAgICAgIHNlbGVjdGVkSXRlbVsnbGlzdCddID0gX2xpc3Q7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5saXN0ID0gdGhpcy5fbGVmdG1lbnVTdmMuc2V0SXNPcGVuKHRoaXMubGlzdCk7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5fc2V0SW5pdE9wZW4odGhpcy5fY3VycmVudFJvdXRlKTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH07XHJcbiAgICB9XHJcbn1cclxuIl19