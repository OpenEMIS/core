import { Component, ViewEncapsulation, HostBinding, Input } from '@angular/core';
// import { Http, Response } from '@angular/http';
import { HttpClient } from '@angular/common/http';
import { map } from 'rxjs/operators';
import { KdModalEvent } from '../kd-angular-modal/kd-modal-event';
export class KdPlaceholder {
    constructor(_http, _modalEvent) {
        this._http = _http;
        this._modalEvent = _modalEvent;
        this.imageSrc = '';
        this.modalConfig = {
            title: '',
            button: [],
            id: ''
        };
        this.fontSize = 80;
        this.placeholder = 'placeholder-wrapper';
    }
    ngOnInit() {
        // console.log('-- KdPlaceholder OnInit --');
        this._processImageConfig();
        if (typeof this.src !== 'undefined') {
            this.imageSrc = this.src;
        }
        if (typeof this.value !== 'undefined' && (typeof this.src === 'undefined' || this.src === '')) {
            this._processImageValue();
        }
    }
    ngOnChanges(_simpleChanges) {
        // console.log('-- KdPlaceholder OnChanges -- ', _simpleChanges);
        if (_simpleChanges.hasOwnProperty('config') && !_simpleChanges['config'].firstChange) {
            this._processImageConfig();
        }
        if (_simpleChanges.hasOwnProperty('src') && !_simpleChanges['src'].firstChange) {
            this.imageSrc = this.src;
        }
        if (_simpleChanges.hasOwnProperty('value') && !_simpleChanges['value'].firstChange) {
            this._processImageValue();
        }
    }
    ngOnDestroy() {
        this._unsubscribeHttp();
    }
    imgClick(_event) {
        if (!this.config.isExpandable)
            return;
        this._modalEvent.toggleOpen(this.config.id);
    }
    /******************* Process config ***********************/
    _processImageConfig() {
        let defaultConfig = {
            width: 150,
            height: 150,
            icon: 'kd-openemis',
            isExpandable: false,
            borderType: 'box',
            id: Date.now().toString()
        };
        this.config = Object.assign({}, defaultConfig, this.config);
        this.modalConfig.id = this.config.id;
        // Font size checking standardize as width of image / 2 + 5
        this.fontSize = this.config.width / 2 + 5;
    }
    _processImageTitle() {
        let modalTitle = (typeof this.value.filename !== 'undefined') ? this.value.filename : '';
        this.modalConfig.title = modalTitle;
    }
    _processImageValue() {
        var _a, _b, _c, _d;
        this._processImageTitle();
        if (typeof this.value.src !== 'undefined') {
            this.imageSrc = this.value.src;
        }
        else if (typeof this.value.data !== 'undefined' && typeof this.value.extension !== 'undefined') {
            this.imageSrc = this._convertDataExtensionToSrc();
        }
        else if (typeof this.value.link !== 'undefined') {
            this._unsubscribeHttp();
            this._httpSubscription = this._convertLinkToSrc().subscribe((_response) => {
                this.imageSrc = _response;
            }, (_error) => {
                console.error('KdPlaceholder error - Error retrieving data for image.', _error);
            });
        }
        else if (typeof ((_b = (_a = this.value) === null || _a === void 0 ? void 0 : _a.newLink) === null || _b === void 0 ? void 0 : _b.srcData) !== undefined) {
            this.imageSrc = (_d = (_c = this.value) === null || _c === void 0 ? void 0 : _c.newLink) === null || _d === void 0 ? void 0 : _d.srcData;
        }
        else {
            this.imageSrc = '';
        }
    }
    /******************** Convert data ************************/
    _convertDataExtensionToSrc() {
        let dataPrefix = 'data:image/' + this.value.extension + ';base64,';
        return dataPrefix + this.value.data;
    }
    _convertLinkToSrc() {
        return this._http.get(this.value.link.url)
            .pipe(map((_response) => {
            let response = {};
            try {
                // let tempRes: any = _response.json();
                let imageKey = (typeof this.value.link.key !== 'undefined') ? this.value.link.key : 'image';
                if (_response.hasOwnProperty(imageKey)) {
                    response = _response[imageKey];
                }
            }
            catch (err) {
                console.error('KdPlaceholder error - Error in retrieving image src from url. ', err);
            }
            return response;
        }));
    }
    /******************** Convert data ************************/
    _unsubscribeHttp() {
        if (typeof this._httpSubscription !== 'undefined') {
            this._httpSubscription.unsubscribe();
        }
    }
}
KdPlaceholder.decorators = [
    { type: Component, args: [{
                selector: 'kd-placeholder',
                template: `
        <kd-modal *ngIf='true' [config]='modalConfig'>
            <img [src]='imageSrc' [style.width]='"100%"' [style.height]='"100%"'/>
        </kd-modal>
        <div
            [ngClass]='{"image-border": (config.borderType == "box"), "image-border-round": (config.borderType == "circle")}'
            [style.width.px]='config.width'
            [style.height.px]='config.height'
        >
            <img
                *ngIf='imageSrc'
                [src]='imageSrc'
                (click)='imgClick($event)'
            />
            <i
                *ngIf='!imageSrc'
                [ngClass]='config.icon'
                [style.fontSize.px]='fontSize'
            ></i>
        </div>
    `,
                encapsulation: ViewEncapsulation.None,
                providers: [KdModalEvent]
            },] }
];
KdPlaceholder.ctorParameters = () => [
    { type: HttpClient },
    { type: KdModalEvent }
];
KdPlaceholder.propDecorators = {
    config: [{ type: Input }],
    value: [{ type: Input }],
    src: [{ type: Input }],
    placeholder: [{ type: HostBinding, args: ['class',] }]
};
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoia2QtYW5ndWxhci1wbGFjZWhvbGRlci5qcyIsInNvdXJjZVJvb3QiOiJEOi9vcGVuRU1JUy9zdHlsZWd1aWRlL2lvc3RnLW9wZW5lbWlzLXN0eWxlZ3VpZGUvcHJvamVjdHMvb3BlbmVtaXMtc3R5bGVndWlkZS1saWIvc3JjLyIsInNvdXJjZXMiOlsia2QtY29tcG9uZW50cy9rZC1hbmd1bGFyLXBsYWNlaG9sZGVyL2tkLWFuZ3VsYXItcGxhY2Vob2xkZXIudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsT0FBTyxFQUNILFNBQVMsRUFLVCxpQkFBaUIsRUFDakIsV0FBVyxFQUNYLEtBQUssRUFDUixNQUFNLGVBQWUsQ0FBQztBQUN2QixrREFBa0Q7QUFDbEQsT0FBTyxFQUFxQixVQUFVLEVBQWdCLE1BQU0sc0JBQXNCLENBQUM7QUFFbkYsT0FBTyxFQUFFLEdBQUcsRUFBRSxNQUFNLGdCQUFnQixDQUFDO0FBQ3JDLE9BQU8sRUFBRSxZQUFZLEVBQUUsTUFBTSxvQ0FBb0MsQ0FBQztBQThCbEUsTUFBTSxPQUFPLGFBQWE7SUFnQnRCLFlBQ1ksS0FBaUIsRUFDakIsV0FBeUI7UUFEekIsVUFBSyxHQUFMLEtBQUssQ0FBWTtRQUNqQixnQkFBVyxHQUFYLFdBQVcsQ0FBYztRQWpCOUIsYUFBUSxHQUFXLEVBQUUsQ0FBQztRQUN0QixnQkFBVyxHQUFvRDtZQUNsRSxLQUFLLEVBQUUsRUFBRTtZQUNULE1BQU0sRUFBRSxFQUFFO1lBQ1YsRUFBRSxFQUFFLEVBQUU7U0FDVCxDQUFDO1FBQ0ssYUFBUSxHQUFXLEVBQUUsQ0FBQztRQU9QLGdCQUFXLEdBQUcscUJBQXFCLENBQUM7SUFLdEQsQ0FBQztJQUdMLFFBQVE7UUFDSiw2Q0FBNkM7UUFFN0MsSUFBSSxDQUFDLG1CQUFtQixFQUFFLENBQUM7UUFFM0IsSUFBSSxPQUFPLElBQUksQ0FBQyxHQUFHLEtBQUssV0FBVyxFQUFFO1lBQ2pDLElBQUksQ0FBQyxRQUFRLEdBQUcsSUFBSSxDQUFDLEdBQUcsQ0FBQztTQUM1QjtRQUVELElBQUksT0FBTyxJQUFJLENBQUMsS0FBSyxLQUFLLFdBQVcsSUFBSSxDQUFDLE9BQU8sSUFBSSxDQUFDLEdBQUcsS0FBSyxXQUFXLElBQUksSUFBSSxDQUFDLEdBQUcsS0FBSyxFQUFFLENBQUMsRUFBRTtZQUMzRixJQUFJLENBQUMsa0JBQWtCLEVBQUUsQ0FBQztTQUM3QjtJQUNMLENBQUM7SUFFRCxXQUFXLENBQUMsY0FBNkI7UUFDckMsaUVBQWlFO1FBRWpFLElBQUksY0FBYyxDQUFDLGNBQWMsQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLGNBQWMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxXQUFXLEVBQUU7WUFDbEYsSUFBSSxDQUFDLG1CQUFtQixFQUFFLENBQUM7U0FDOUI7UUFFRCxJQUFJLGNBQWMsQ0FBQyxjQUFjLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxjQUFjLENBQUMsS0FBSyxDQUFDLENBQUMsV0FBVyxFQUFFO1lBQzVFLElBQUksQ0FBQyxRQUFRLEdBQUcsSUFBSSxDQUFDLEdBQUcsQ0FBQztTQUM1QjtRQUVELElBQUksY0FBYyxDQUFDLGNBQWMsQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLGNBQWMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxXQUFXLEVBQUU7WUFDaEYsSUFBSSxDQUFDLGtCQUFrQixFQUFFLENBQUM7U0FDN0I7SUFDTCxDQUFDO0lBRUQsV0FBVztRQUNQLElBQUksQ0FBQyxnQkFBZ0IsRUFBRSxDQUFDO0lBQzVCLENBQUM7SUFFTSxRQUFRLENBQUMsTUFBYTtRQUN6QixJQUFJLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxZQUFZO1lBQUUsT0FBTztRQUV0QyxJQUFJLENBQUMsV0FBVyxDQUFDLFVBQVUsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLEVBQUUsQ0FBQyxDQUFDO0lBQ2hELENBQUM7SUFFRCw0REFBNEQ7SUFDcEQsbUJBQW1CO1FBQ3ZCLElBQUksYUFBYSxHQUF1QjtZQUNwQyxLQUFLLEVBQUUsR0FBRztZQUNWLE1BQU0sRUFBRSxHQUFHO1lBQ1gsSUFBSSxFQUFFLGFBQWE7WUFDbkIsWUFBWSxFQUFFLEtBQUs7WUFDbkIsVUFBVSxFQUFFLEtBQUs7WUFDakIsRUFBRSxFQUFFLElBQUksQ0FBQyxHQUFHLEVBQUUsQ0FBQyxRQUFRLEVBQUU7U0FDNUIsQ0FBQztRQUVGLElBQUksQ0FBQyxNQUFNLEdBQUcsTUFBTSxDQUFDLE1BQU0sQ0FBQyxFQUFFLEVBQUUsYUFBYSxFQUFFLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQztRQUM1RCxJQUFJLENBQUMsV0FBVyxDQUFDLEVBQUUsR0FBRyxJQUFJLENBQUMsTUFBTSxDQUFDLEVBQUUsQ0FBQztRQUNyQywyREFBMkQ7UUFDM0QsSUFBSSxDQUFDLFFBQVEsR0FBRyxJQUFJLENBQUMsTUFBTSxDQUFDLEtBQUssR0FBRyxDQUFDLEdBQUcsQ0FBQyxDQUFDO0lBQzlDLENBQUM7SUFFTyxrQkFBa0I7UUFDdEIsSUFBSSxVQUFVLEdBQVcsQ0FBQyxPQUFPLElBQUksQ0FBQyxLQUFLLENBQUMsUUFBUSxLQUFLLFdBQVcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDO1FBQ2pHLElBQUksQ0FBQyxXQUFXLENBQUMsS0FBSyxHQUFHLFVBQVUsQ0FBQztJQUN4QyxDQUFDO0lBRU8sa0JBQWtCOztRQUN0QixJQUFJLENBQUMsa0JBQWtCLEVBQUUsQ0FBQztRQUUxQixJQUFJLE9BQU8sSUFBSSxDQUFDLEtBQUssQ0FBQyxHQUFHLEtBQUssV0FBVyxFQUFFO1lBQ3ZDLElBQUksQ0FBQyxRQUFRLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUM7U0FDbEM7YUFDSSxJQUFJLE9BQU8sSUFBSSxDQUFDLEtBQUssQ0FBQyxJQUFJLEtBQUssV0FBVyxJQUFJLE9BQU8sSUFBSSxDQUFDLEtBQUssQ0FBQyxTQUFTLEtBQUssV0FBVyxFQUFFO1lBQzVGLElBQUksQ0FBQyxRQUFRLEdBQUcsSUFBSSxDQUFDLDBCQUEwQixFQUFFLENBQUM7U0FDckQ7YUFDSSxJQUFJLE9BQU8sSUFBSSxDQUFDLEtBQUssQ0FBQyxJQUFJLEtBQUssV0FBVyxFQUFFO1lBQzdDLElBQUksQ0FBQyxnQkFBZ0IsRUFBRSxDQUFDO1lBRXhCLElBQUksQ0FBQyxpQkFBaUIsR0FBRyxJQUFJLENBQUMsaUJBQWlCLEVBQUUsQ0FBQyxTQUFTLENBQ3ZELENBQUMsU0FBYyxFQUFRLEVBQUU7Z0JBQ3JCLElBQUksQ0FBQyxRQUFRLEdBQUcsU0FBUyxDQUFDO1lBQzlCLENBQUMsRUFDRCxDQUFDLE1BQXlCLEVBQVEsRUFBRTtnQkFDaEMsT0FBTyxDQUFDLEtBQUssQ0FBQyx3REFBd0QsRUFBRSxNQUFNLENBQUMsQ0FBQztZQUNwRixDQUFDLENBQ0osQ0FBQztTQUNMO2FBQ0ksSUFBSSxvQkFBTyxJQUFJLENBQUMsS0FBSywwQ0FBRSxPQUFPLDBDQUFFLE9BQU8sQ0FBQSxLQUFLLFNBQVMsRUFBQztZQUN2RCxJQUFJLENBQUMsUUFBUSxlQUFHLElBQUksQ0FBQyxLQUFLLDBDQUFFLE9BQU8sMENBQUUsT0FBTyxDQUFDO1NBQ2hEO2FBQU07WUFDSCxJQUFJLENBQUMsUUFBUSxHQUFHLEVBQUUsQ0FBQTtTQUNyQjtJQUVMLENBQUM7SUFFRCw0REFBNEQ7SUFDcEQsMEJBQTBCO1FBQzlCLElBQUksVUFBVSxHQUFXLGFBQWEsR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDLFNBQVMsR0FBRyxVQUFVLENBQUM7UUFDM0UsT0FBTyxVQUFVLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUM7SUFDeEMsQ0FBQztJQUVPLGlCQUFpQjtRQUNyQixPQUFPLElBQUksQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQzthQUNyQyxJQUFJLENBQ0QsR0FBRyxDQUFDLENBQUMsU0FBNEIsRUFBTyxFQUFFO1lBQ3RDLElBQUksUUFBUSxHQUFRLEVBQUUsQ0FBQztZQUV2QixJQUFJO2dCQUNBLHVDQUF1QztnQkFDdkMsSUFBSSxRQUFRLEdBQVcsQ0FBQyxPQUFPLElBQUksQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLEdBQUcsS0FBSyxXQUFXLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUM7Z0JBQ3BHLElBQUksU0FBUyxDQUFDLGNBQWMsQ0FBQyxRQUFRLENBQUMsRUFBRTtvQkFDcEMsUUFBUSxHQUFHLFNBQVMsQ0FBQyxRQUFRLENBQUMsQ0FBQztpQkFDbEM7YUFDSjtZQUFDLE9BQU8sR0FBRyxFQUFFO2dCQUNWLE9BQU8sQ0FBQyxLQUFLLENBQUMsZ0VBQWdFLEVBQUUsR0FBRyxDQUFDLENBQUM7YUFDeEY7WUFDRCxPQUFPLFFBQVEsQ0FBQztRQUNwQixDQUFDLENBQUMsQ0FDTCxDQUFDO0lBQ1YsQ0FBQztJQUVELDREQUE0RDtJQUNwRCxnQkFBZ0I7UUFDcEIsSUFBSSxPQUFPLElBQUksQ0FBQyxpQkFBaUIsS0FBSyxXQUFXLEVBQUU7WUFDL0MsSUFBSSxDQUFDLGlCQUFpQixDQUFDLFdBQVcsRUFBRSxDQUFDO1NBQ3hDO0lBQ0wsQ0FBQzs7O1lBM0tKLFNBQVMsU0FBQztnQkFDUCxRQUFRLEVBQUUsZ0JBQWdCO2dCQUMxQixRQUFRLEVBQUU7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0tBb0JUO2dCQUNELGFBQWEsRUFBRSxpQkFBaUIsQ0FBQyxJQUFJO2dCQUNyQyxTQUFTLEVBQUUsQ0FBQyxZQUFZLENBQUM7YUFDNUI7OztZQS9CMkIsVUFBVTtZQUc3QixZQUFZOzs7cUJBeUNoQixLQUFLO29CQUNMLEtBQUs7a0JBQ0wsS0FBSzswQkFDTCxXQUFXLFNBQUMsT0FBTyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7XHJcbiAgICBDb21wb25lbnQsXHJcbiAgICBPbkluaXQsXHJcbiAgICBPbkNoYW5nZXMsXHJcbiAgICBPbkRlc3Ryb3ksXHJcbiAgICBTaW1wbGVDaGFuZ2VzLFxyXG4gICAgVmlld0VuY2Fwc3VsYXRpb24sXHJcbiAgICBIb3N0QmluZGluZyxcclxuICAgIElucHV0XHJcbn0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XHJcbi8vIGltcG9ydCB7IEh0dHAsIFJlc3BvbnNlIH0gZnJvbSAnQGFuZ3VsYXIvaHR0cCc7XHJcbmltcG9ydCB7IEh0dHBFcnJvclJlc3BvbnNlLCBIdHRwQ2xpZW50LCBIdHRwUmVzcG9uc2UgfSBmcm9tICdAYW5ndWxhci9jb21tb24vaHR0cCc7XHJcbmltcG9ydCB7IE9ic2VydmFibGUgLCAgU3Vic2NyaXB0aW9uIH0gZnJvbSAncnhqcyc7XHJcbmltcG9ydCB7IG1hcCB9IGZyb20gJ3J4anMvb3BlcmF0b3JzJztcclxuaW1wb3J0IHsgS2RNb2RhbEV2ZW50IH0gZnJvbSAnLi4va2QtYW5ndWxhci1tb2RhbC9rZC1tb2RhbC1ldmVudCc7XHJcbmltcG9ydCB7SVBsYWNlaG9sZGVyQ29uZmlnLCBJUGxhY2Vob2xkZXJMaW5rLCBJUGxhY2Vob2xkZXJWYWx1ZSB9IGZyb20gJy4va2QtYW5ndWxhci1wbGFjZWhvbGRlci1pbnRlcmZhY2UnO1xyXG5cclxuQENvbXBvbmVudCh7XHJcbiAgICBzZWxlY3RvcjogJ2tkLXBsYWNlaG9sZGVyJyxcclxuICAgIHRlbXBsYXRlOiBgXHJcbiAgICAgICAgPGtkLW1vZGFsICpuZ0lmPSd0cnVlJyBbY29uZmlnXT0nbW9kYWxDb25maWcnPlxyXG4gICAgICAgICAgICA8aW1nIFtzcmNdPSdpbWFnZVNyYycgW3N0eWxlLndpZHRoXT0nXCIxMDAlXCInIFtzdHlsZS5oZWlnaHRdPSdcIjEwMCVcIicvPlxyXG4gICAgICAgIDwva2QtbW9kYWw+XHJcbiAgICAgICAgPGRpdlxyXG4gICAgICAgICAgICBbbmdDbGFzc109J3tcImltYWdlLWJvcmRlclwiOiAoY29uZmlnLmJvcmRlclR5cGUgPT0gXCJib3hcIiksIFwiaW1hZ2UtYm9yZGVyLXJvdW5kXCI6IChjb25maWcuYm9yZGVyVHlwZSA9PSBcImNpcmNsZVwiKX0nXHJcbiAgICAgICAgICAgIFtzdHlsZS53aWR0aC5weF09J2NvbmZpZy53aWR0aCdcclxuICAgICAgICAgICAgW3N0eWxlLmhlaWdodC5weF09J2NvbmZpZy5oZWlnaHQnXHJcbiAgICAgICAgPlxyXG4gICAgICAgICAgICA8aW1nXHJcbiAgICAgICAgICAgICAgICAqbmdJZj0naW1hZ2VTcmMnXHJcbiAgICAgICAgICAgICAgICBbc3JjXT0naW1hZ2VTcmMnXHJcbiAgICAgICAgICAgICAgICAoY2xpY2spPSdpbWdDbGljaygkZXZlbnQpJ1xyXG4gICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICA8aVxyXG4gICAgICAgICAgICAgICAgKm5nSWY9JyFpbWFnZVNyYydcclxuICAgICAgICAgICAgICAgIFtuZ0NsYXNzXT0nY29uZmlnLmljb24nXHJcbiAgICAgICAgICAgICAgICBbc3R5bGUuZm9udFNpemUucHhdPSdmb250U2l6ZSdcclxuICAgICAgICAgICAgPjwvaT5cclxuICAgICAgICA8L2Rpdj5cclxuICAgIGAsXHJcbiAgICBlbmNhcHN1bGF0aW9uOiBWaWV3RW5jYXBzdWxhdGlvbi5Ob25lLFxyXG4gICAgcHJvdmlkZXJzOiBbS2RNb2RhbEV2ZW50XVxyXG59KVxyXG5cclxuZXhwb3J0IGNsYXNzIEtkUGxhY2Vob2xkZXIgaW1wbGVtZW50cyBPbkluaXQsIE9uQ2hhbmdlcywgT25EZXN0cm95IHtcclxuICAgIHB1YmxpYyBpbWFnZVNyYzogc3RyaW5nID0gJyc7XHJcbiAgICBwdWJsaWMgbW9kYWxDb25maWc6IHt0aXRsZTogc3RyaW5nLCBidXR0b246IEFycmF5PGFueT4sIGlkOiBzdHJpbmd9ID0ge1xyXG4gICAgICAgIHRpdGxlOiAnJyxcclxuICAgICAgICBidXR0b246IFtdLFxyXG4gICAgICAgIGlkOiAnJ1xyXG4gICAgfTtcclxuICAgIHB1YmxpYyBmb250U2l6ZTogbnVtYmVyID0gODA7XHJcblxyXG4gICAgcHJpdmF0ZSBfaHR0cFN1YnNjcmlwdGlvbjogU3Vic2NyaXB0aW9uO1xyXG5cclxuICAgIEBJbnB1dCgpIGNvbmZpZzogSVBsYWNlaG9sZGVyQ29uZmlnO1xyXG4gICAgQElucHV0KCkgdmFsdWU6IElQbGFjZWhvbGRlclZhbHVlO1xyXG4gICAgQElucHV0KCkgc3JjOiBzdHJpbmc7XHJcbiAgICBASG9zdEJpbmRpbmcoJ2NsYXNzJykgcGxhY2Vob2xkZXIgPSAncGxhY2Vob2xkZXItd3JhcHBlcic7XHJcblxyXG4gICAgY29uc3RydWN0b3IoXHJcbiAgICAgICAgcHJpdmF0ZSBfaHR0cDogSHR0cENsaWVudCxcclxuICAgICAgICBwcml2YXRlIF9tb2RhbEV2ZW50OiBLZE1vZGFsRXZlbnRcclxuICAgICkgeyB9XHJcblxyXG5cclxuICAgIG5nT25Jbml0KCk6IHZvaWQge1xyXG4gICAgICAgIC8vIGNvbnNvbGUubG9nKCctLSBLZFBsYWNlaG9sZGVyIE9uSW5pdCAtLScpO1xyXG5cclxuICAgICAgICB0aGlzLl9wcm9jZXNzSW1hZ2VDb25maWcoKTtcclxuXHJcbiAgICAgICAgaWYgKHR5cGVvZiB0aGlzLnNyYyAhPT0gJ3VuZGVmaW5lZCcpIHtcclxuICAgICAgICAgICAgdGhpcy5pbWFnZVNyYyA9IHRoaXMuc3JjO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgaWYgKHR5cGVvZiB0aGlzLnZhbHVlICE9PSAndW5kZWZpbmVkJyAmJiAodHlwZW9mIHRoaXMuc3JjID09PSAndW5kZWZpbmVkJyB8fCB0aGlzLnNyYyA9PT0gJycpKSB7XHJcbiAgICAgICAgICAgIHRoaXMuX3Byb2Nlc3NJbWFnZVZhbHVlKCk7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIG5nT25DaGFuZ2VzKF9zaW1wbGVDaGFuZ2VzOiBTaW1wbGVDaGFuZ2VzKTogdm9pZCB7XHJcbiAgICAgICAgLy8gY29uc29sZS5sb2coJy0tIEtkUGxhY2Vob2xkZXIgT25DaGFuZ2VzIC0tICcsIF9zaW1wbGVDaGFuZ2VzKTtcclxuXHJcbiAgICAgICAgaWYgKF9zaW1wbGVDaGFuZ2VzLmhhc093blByb3BlcnR5KCdjb25maWcnKSAmJiAhX3NpbXBsZUNoYW5nZXNbJ2NvbmZpZyddLmZpcnN0Q2hhbmdlKSB7XHJcbiAgICAgICAgICAgIHRoaXMuX3Byb2Nlc3NJbWFnZUNvbmZpZygpO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgaWYgKF9zaW1wbGVDaGFuZ2VzLmhhc093blByb3BlcnR5KCdzcmMnKSAmJiAhX3NpbXBsZUNoYW5nZXNbJ3NyYyddLmZpcnN0Q2hhbmdlKSB7XHJcbiAgICAgICAgICAgIHRoaXMuaW1hZ2VTcmMgPSB0aGlzLnNyYztcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIGlmIChfc2ltcGxlQ2hhbmdlcy5oYXNPd25Qcm9wZXJ0eSgndmFsdWUnKSAmJiAhX3NpbXBsZUNoYW5nZXNbJ3ZhbHVlJ10uZmlyc3RDaGFuZ2UpIHtcclxuICAgICAgICAgICAgdGhpcy5fcHJvY2Vzc0ltYWdlVmFsdWUoKTtcclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgbmdPbkRlc3Ryb3koKTogdm9pZCB7XHJcbiAgICAgICAgdGhpcy5fdW5zdWJzY3JpYmVIdHRwKCk7XHJcbiAgICB9XHJcblxyXG4gICAgcHVibGljIGltZ0NsaWNrKF9ldmVudDogRXZlbnQpOiB2b2lkIHtcclxuICAgICAgICBpZiAoIXRoaXMuY29uZmlnLmlzRXhwYW5kYWJsZSkgcmV0dXJuO1xyXG5cclxuICAgICAgICB0aGlzLl9tb2RhbEV2ZW50LnRvZ2dsZU9wZW4odGhpcy5jb25maWcuaWQpO1xyXG4gICAgfVxyXG5cclxuICAgIC8qKioqKioqKioqKioqKioqKioqIFByb2Nlc3MgY29uZmlnICoqKioqKioqKioqKioqKioqKioqKioqL1xyXG4gICAgcHJpdmF0ZSBfcHJvY2Vzc0ltYWdlQ29uZmlnKCk6IHZvaWQge1xyXG4gICAgICAgIGxldCBkZWZhdWx0Q29uZmlnOiBJUGxhY2Vob2xkZXJDb25maWcgPSB7XHJcbiAgICAgICAgICAgIHdpZHRoOiAxNTAsXHJcbiAgICAgICAgICAgIGhlaWdodDogMTUwLFxyXG4gICAgICAgICAgICBpY29uOiAna2Qtb3BlbmVtaXMnLFxyXG4gICAgICAgICAgICBpc0V4cGFuZGFibGU6IGZhbHNlLFxyXG4gICAgICAgICAgICBib3JkZXJUeXBlOiAnYm94JyxcclxuICAgICAgICAgICAgaWQ6IERhdGUubm93KCkudG9TdHJpbmcoKVxyXG4gICAgICAgIH07XHJcblxyXG4gICAgICAgIHRoaXMuY29uZmlnID0gT2JqZWN0LmFzc2lnbih7fSwgZGVmYXVsdENvbmZpZywgdGhpcy5jb25maWcpO1xyXG4gICAgICAgIHRoaXMubW9kYWxDb25maWcuaWQgPSB0aGlzLmNvbmZpZy5pZDtcclxuICAgICAgICAvLyBGb250IHNpemUgY2hlY2tpbmcgc3RhbmRhcmRpemUgYXMgd2lkdGggb2YgaW1hZ2UgLyAyICsgNVxyXG4gICAgICAgIHRoaXMuZm9udFNpemUgPSB0aGlzLmNvbmZpZy53aWR0aCAvIDIgKyA1O1xyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX3Byb2Nlc3NJbWFnZVRpdGxlKCk6IHZvaWQge1xyXG4gICAgICAgIGxldCBtb2RhbFRpdGxlOiBzdHJpbmcgPSAodHlwZW9mIHRoaXMudmFsdWUuZmlsZW5hbWUgIT09ICd1bmRlZmluZWQnKSA/IHRoaXMudmFsdWUuZmlsZW5hbWUgOiAnJztcclxuICAgICAgICB0aGlzLm1vZGFsQ29uZmlnLnRpdGxlID0gbW9kYWxUaXRsZTtcclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF9wcm9jZXNzSW1hZ2VWYWx1ZSgpOiB2b2lkIHtcclxuICAgICAgICB0aGlzLl9wcm9jZXNzSW1hZ2VUaXRsZSgpO1xyXG5cclxuICAgICAgICBpZiAodHlwZW9mIHRoaXMudmFsdWUuc3JjICE9PSAndW5kZWZpbmVkJykge1xyXG4gICAgICAgICAgICB0aGlzLmltYWdlU3JjID0gdGhpcy52YWx1ZS5zcmM7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGVsc2UgaWYgKHR5cGVvZiB0aGlzLnZhbHVlLmRhdGEgIT09ICd1bmRlZmluZWQnICYmIHR5cGVvZiB0aGlzLnZhbHVlLmV4dGVuc2lvbiAhPT0gJ3VuZGVmaW5lZCcpIHtcclxuICAgICAgICAgICAgdGhpcy5pbWFnZVNyYyA9IHRoaXMuX2NvbnZlcnREYXRhRXh0ZW5zaW9uVG9TcmMoKTtcclxuICAgICAgICB9XHJcbiAgICAgICAgZWxzZSBpZiAodHlwZW9mIHRoaXMudmFsdWUubGluayAhPT0gJ3VuZGVmaW5lZCcpIHtcclxuICAgICAgICAgICAgdGhpcy5fdW5zdWJzY3JpYmVIdHRwKCk7XHJcblxyXG4gICAgICAgICAgICB0aGlzLl9odHRwU3Vic2NyaXB0aW9uID0gdGhpcy5fY29udmVydExpbmtUb1NyYygpLnN1YnNjcmliZShcclxuICAgICAgICAgICAgICAgIChfcmVzcG9uc2U6IGFueSk6IHZvaWQgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuaW1hZ2VTcmMgPSBfcmVzcG9uc2U7XHJcbiAgICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgICAgKF9lcnJvcjogSHR0cEVycm9yUmVzcG9uc2UpOiB2b2lkID0+IHtcclxuICAgICAgICAgICAgICAgICAgICBjb25zb2xlLmVycm9yKCdLZFBsYWNlaG9sZGVyIGVycm9yIC0gRXJyb3IgcmV0cmlldmluZyBkYXRhIGZvciBpbWFnZS4nLCBfZXJyb3IpO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICApO1xyXG4gICAgICAgIH1cclxuICAgICAgICBlbHNlIGlmICh0eXBlb2YgdGhpcy52YWx1ZT8ubmV3TGluaz8uc3JjRGF0YSAhPT0gdW5kZWZpbmVkKXtcclxuICAgICAgICAgICAgdGhpcy5pbWFnZVNyYyA9IHRoaXMudmFsdWU/Lm5ld0xpbms/LnNyY0RhdGE7XHJcbiAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgdGhpcy5pbWFnZVNyYyA9ICcnXHJcbiAgICAgICAgfVxyXG5cclxuICAgIH1cclxuXHJcbiAgICAvKioqKioqKioqKioqKioqKioqKiogQ29udmVydCBkYXRhICoqKioqKioqKioqKioqKioqKioqKioqKi9cclxuICAgIHByaXZhdGUgX2NvbnZlcnREYXRhRXh0ZW5zaW9uVG9TcmMoKTogc3RyaW5nIHtcclxuICAgICAgICBsZXQgZGF0YVByZWZpeDogc3RyaW5nID0gJ2RhdGE6aW1hZ2UvJyArIHRoaXMudmFsdWUuZXh0ZW5zaW9uICsgJztiYXNlNjQsJztcclxuICAgICAgICByZXR1cm4gZGF0YVByZWZpeCArIHRoaXMudmFsdWUuZGF0YTtcclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF9jb252ZXJ0TGlua1RvU3JjKCk6IE9ic2VydmFibGU8SHR0cFJlc3BvbnNlPGFueT4+IHtcclxuICAgICAgICByZXR1cm4gdGhpcy5faHR0cC5nZXQodGhpcy52YWx1ZS5saW5rLnVybClcclxuICAgICAgICAgICAgLnBpcGUoXHJcbiAgICAgICAgICAgICAgICBtYXAoKF9yZXNwb25zZTogSHR0cFJlc3BvbnNlPGFueT4pOiBhbnkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgIGxldCByZXNwb25zZTogYW55ID0ge307XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIHRyeSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC8vIGxldCB0ZW1wUmVzOiBhbnkgPSBfcmVzcG9uc2UuanNvbigpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBsZXQgaW1hZ2VLZXk6IHN0cmluZyA9ICh0eXBlb2YgdGhpcy52YWx1ZS5saW5rLmtleSAhPT0gJ3VuZGVmaW5lZCcpID8gdGhpcy52YWx1ZS5saW5rLmtleSA6ICdpbWFnZSc7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGlmIChfcmVzcG9uc2UuaGFzT3duUHJvcGVydHkoaW1hZ2VLZXkpKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXNwb25zZSA9IF9yZXNwb25zZVtpbWFnZUtleV07XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICB9IGNhdGNoIChlcnIpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgY29uc29sZS5lcnJvcignS2RQbGFjZWhvbGRlciBlcnJvciAtIEVycm9yIGluIHJldHJpZXZpbmcgaW1hZ2Ugc3JjIGZyb20gdXJsLiAnLCBlcnIpO1xyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICByZXR1cm4gcmVzcG9uc2U7XHJcbiAgICAgICAgICAgICAgICB9KVxyXG4gICAgICAgICAgICApO1xyXG4gICAgfVxyXG5cclxuICAgIC8qKioqKioqKioqKioqKioqKioqKiBDb252ZXJ0IGRhdGEgKioqKioqKioqKioqKioqKioqKioqKioqL1xyXG4gICAgcHJpdmF0ZSBfdW5zdWJzY3JpYmVIdHRwKCk6IHZvaWQge1xyXG4gICAgICAgIGlmICh0eXBlb2YgdGhpcy5faHR0cFN1YnNjcmlwdGlvbiAhPT0gJ3VuZGVmaW5lZCcpIHtcclxuICAgICAgICAgICAgdGhpcy5faHR0cFN1YnNjcmlwdGlvbi51bnN1YnNjcmliZSgpO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxufVxyXG4iXX0=