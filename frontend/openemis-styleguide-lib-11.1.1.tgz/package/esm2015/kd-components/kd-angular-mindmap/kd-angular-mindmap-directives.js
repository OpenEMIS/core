import { Directive, Input, ElementRef } from '@angular/core';
import { KdMindmapSvc } from './kd-angular-mindmap-svc';
import { ForceDirectedGraph } from './kd-angular-mindmap-force-logic';
export class KdMindmapZoomDirective {
    constructor(_mindmapSvc, _element) {
        this._mindmapSvc = _mindmapSvc;
        this._element = _element;
    }
    ngOnInit() {
        this._zoomClass = this._mindmapSvc.getZoomClass(this.zoomableOf, this._element.nativeElement);
        this._zoomClass.applyZoomableBehaviour();
        this._initApi();
    }
    _initApi() {
        if (typeof this.internalApi !== 'undefined') {
            this.internalApi.zoom = (_action) => this._zoomClass.customZoom(_action);
            this.internalApi.scaleTo = (_scale) => this._zoomClass.scaleTo(_scale);
            this.internalApi.translate = (_x, _y) => this._zoomClass.translateSVG(_x, _y);
        }
    }
}
KdMindmapZoomDirective.decorators = [
    { type: Directive, args: [{
                selector: '[zoomableOf]',
            },] }
];
KdMindmapZoomDirective.ctorParameters = () => [
    { type: KdMindmapSvc },
    { type: ElementRef }
];
KdMindmapZoomDirective.propDecorators = {
    zoomableOf: [{ type: Input, args: ['zoomableOf',] }],
    internalApi: [{ type: Input, args: ['api',] }]
};
export class KdMindmapDragDirective {
    constructor(_mindmapSvc, _element) {
        this._mindmapSvc = _mindmapSvc;
        this._element = _element;
    }
    ngOnInit() {
        this._mindmapSvc.applyDraggableBehaviour(this._element.nativeElement, this.draggableNode, this.draggableInGraph);
    }
}
KdMindmapDragDirective.decorators = [
    { type: Directive, args: [{
                selector: '[draggableNode]'
            },] }
];
KdMindmapDragDirective.ctorParameters = () => [
    { type: KdMindmapSvc },
    { type: ElementRef }
];
KdMindmapDragDirective.propDecorators = {
    draggableNode: [{ type: Input, args: ['draggableNode',] }],
    draggableInGraph: [{ type: Input, args: ['draggableInGraph',] }]
};
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoia2QtYW5ndWxhci1taW5kbWFwLWRpcmVjdGl2ZXMuanMiLCJzb3VyY2VSb290IjoiRDovb3BlbkVNSVMvc3R5bGVndWlkZS9pb3N0Zy1vcGVuZW1pcy1zdHlsZWd1aWRlL3Byb2plY3RzL29wZW5lbWlzLXN0eWxlZ3VpZGUtbGliL3NyYy8iLCJzb3VyY2VzIjpbImtkLWNvbXBvbmVudHMva2QtYW5ndWxhci1taW5kbWFwL2tkLWFuZ3VsYXItbWluZG1hcC1kaXJlY3RpdmVzLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBLE9BQU8sRUFBRSxTQUFTLEVBQUUsS0FBSyxFQUFFLFVBQVUsRUFBVSxNQUFNLGVBQWUsQ0FBQztBQUNyRSxPQUFPLEVBQUUsWUFBWSxFQUFFLE1BQU0sMEJBQTBCLENBQUM7QUFDeEQsT0FBTyxFQUFFLGtCQUFrQixFQUFFLE1BQU0sa0NBQWtDLENBQUM7QUFPdEUsTUFBTSxPQUFPLHNCQUFzQjtJQU0vQixZQUFvQixXQUF5QixFQUFVLFFBQW9CO1FBQXZELGdCQUFXLEdBQVgsV0FBVyxDQUFjO1FBQVUsYUFBUSxHQUFSLFFBQVEsQ0FBWTtJQUFJLENBQUM7SUFFaEYsUUFBUTtRQUNKLElBQUksQ0FBQyxVQUFVLEdBQUcsSUFBSSxDQUFDLFdBQVcsQ0FBQyxZQUFZLENBQUMsSUFBSSxDQUFDLFVBQVUsRUFBRSxJQUFJLENBQUMsUUFBUSxDQUFDLGFBQWEsQ0FBQyxDQUFDO1FBQzlGLElBQUksQ0FBQyxVQUFVLENBQUMsc0JBQXNCLEVBQUUsQ0FBQztRQUN6QyxJQUFJLENBQUMsUUFBUSxFQUFFLENBQUM7SUFDcEIsQ0FBQztJQUVPLFFBQVE7UUFDWixJQUFJLE9BQU8sSUFBSSxDQUFDLFdBQVcsS0FBSyxXQUFXLEVBQUU7WUFDekMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxJQUFJLEdBQUcsQ0FBQyxPQUFlLEVBQVEsRUFBRSxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsVUFBVSxDQUFDLE9BQU8sQ0FBQyxDQUFDO1lBQ3ZGLElBQUksQ0FBQyxXQUFXLENBQUMsT0FBTyxHQUFHLENBQUMsTUFBYyxFQUFRLEVBQUUsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsQ0FBQztZQUNyRixJQUFJLENBQUMsV0FBVyxDQUFDLFNBQVMsR0FBRyxDQUFDLEVBQVUsRUFBRSxFQUFXLEVBQU8sRUFBRSxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsWUFBWSxDQUFDLEVBQUUsRUFBRSxFQUFFLENBQUMsQ0FBQztTQUN2RztJQUNMLENBQUM7OztZQXZCSixTQUFTLFNBQUM7Z0JBQ1AsUUFBUSxFQUFFLGNBQWM7YUFDM0I7OztZQVBRLFlBQVk7WUFETSxVQUFVOzs7eUJBWWhDLEtBQUssU0FBQyxZQUFZOzBCQUNsQixLQUFLLFNBQUMsS0FBSzs7QUF1QmhCLE1BQU0sT0FBTyxzQkFBc0I7SUFJL0IsWUFBb0IsV0FBeUIsRUFBVSxRQUFvQjtRQUF2RCxnQkFBVyxHQUFYLFdBQVcsQ0FBYztRQUFVLGFBQVEsR0FBUixRQUFRLENBQVk7SUFBSSxDQUFDO0lBRWhGLFFBQVE7UUFDSixJQUFJLENBQUMsV0FBVyxDQUFDLHVCQUF1QixDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsYUFBYSxFQUFFLElBQUksQ0FBQyxhQUFhLEVBQUUsSUFBSSxDQUFDLGdCQUFnQixDQUFDLENBQUM7SUFDckgsQ0FBQzs7O1lBWEosU0FBUyxTQUFDO2dCQUNQLFFBQVEsRUFBRSxpQkFBaUI7YUFDOUI7OztZQWxDUSxZQUFZO1lBRE0sVUFBVTs7OzRCQXFDaEMsS0FBSyxTQUFDLGVBQWU7K0JBQ3JCLEtBQUssU0FBQyxrQkFBa0IiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBEaXJlY3RpdmUsIElucHV0LCBFbGVtZW50UmVmLCBPbkluaXQgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcclxuaW1wb3J0IHsgS2RNaW5kbWFwU3ZjIH0gZnJvbSAnLi9rZC1hbmd1bGFyLW1pbmRtYXAtc3ZjJztcclxuaW1wb3J0IHsgRm9yY2VEaXJlY3RlZEdyYXBoIH0gZnJvbSAnLi9rZC1hbmd1bGFyLW1pbmRtYXAtZm9yY2UtbG9naWMnO1xyXG5pbXBvcnQgeyBab29tQ2xhc3MgfSBmcm9tICcuL3pvb20va2QtYW5ndWxhci1taW5kbWFwLXpvb20tbG9naWMnO1xyXG5pbXBvcnQgeyBJTWluZG1hcE5vZGUsIElNaW5kbWFwSW50ZXJuYWxBcGkgfSBmcm9tICcuL2tkLWFuZ3VsYXItbWluZG1hcC1pbnRlcmZhY2UnO1xyXG5cclxuQERpcmVjdGl2ZSh7XHJcbiAgICBzZWxlY3RvcjogJ1t6b29tYWJsZU9mXScsXHJcbn0pXHJcbmV4cG9ydCBjbGFzcyBLZE1pbmRtYXBab29tRGlyZWN0aXZlIGltcGxlbWVudHMgT25Jbml0IHtcclxuICAgIHByaXZhdGUgX3pvb21DbGFzczogWm9vbUNsYXNzO1xyXG5cclxuICAgIEBJbnB1dCgnem9vbWFibGVPZicpIHpvb21hYmxlT2Y6IEVsZW1lbnRSZWY7XHJcbiAgICBASW5wdXQoJ2FwaScpIGludGVybmFsQXBpOiBJTWluZG1hcEludGVybmFsQXBpO1xyXG5cclxuICAgIGNvbnN0cnVjdG9yKHByaXZhdGUgX21pbmRtYXBTdmM6IEtkTWluZG1hcFN2YywgcHJpdmF0ZSBfZWxlbWVudDogRWxlbWVudFJlZikgeyB9XHJcblxyXG4gICAgbmdPbkluaXQoKSB7XHJcbiAgICAgICAgdGhpcy5fem9vbUNsYXNzID0gdGhpcy5fbWluZG1hcFN2Yy5nZXRab29tQ2xhc3ModGhpcy56b29tYWJsZU9mLCB0aGlzLl9lbGVtZW50Lm5hdGl2ZUVsZW1lbnQpO1xyXG4gICAgICAgIHRoaXMuX3pvb21DbGFzcy5hcHBseVpvb21hYmxlQmVoYXZpb3VyKCk7XHJcbiAgICAgICAgdGhpcy5faW5pdEFwaSgpO1xyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX2luaXRBcGkoKTogdm9pZCB7XHJcbiAgICAgICAgaWYgKHR5cGVvZiB0aGlzLmludGVybmFsQXBpICE9PSAndW5kZWZpbmVkJykge1xyXG4gICAgICAgICAgICB0aGlzLmludGVybmFsQXBpLnpvb20gPSAoX2FjdGlvbjogc3RyaW5nKTogdm9pZCA9PiB0aGlzLl96b29tQ2xhc3MuY3VzdG9tWm9vbShfYWN0aW9uKTtcclxuICAgICAgICAgICAgdGhpcy5pbnRlcm5hbEFwaS5zY2FsZVRvID0gKF9zY2FsZTogbnVtYmVyKTogdm9pZCA9PiB0aGlzLl96b29tQ2xhc3Muc2NhbGVUbyhfc2NhbGUpO1xyXG4gICAgICAgICAgICB0aGlzLmludGVybmFsQXBpLnRyYW5zbGF0ZSA9IChfeDogbnVtYmVyLCBfeT86IG51bWJlcik6IGFueSA9PiB0aGlzLl96b29tQ2xhc3MudHJhbnNsYXRlU1ZHKF94LCBfeSk7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG59XHJcblxyXG5cclxuQERpcmVjdGl2ZSh7XHJcbiAgICBzZWxlY3RvcjogJ1tkcmFnZ2FibGVOb2RlXSdcclxufSlcclxuZXhwb3J0IGNsYXNzIEtkTWluZG1hcERyYWdEaXJlY3RpdmUgaW1wbGVtZW50cyBPbkluaXQge1xyXG4gICAgQElucHV0KCdkcmFnZ2FibGVOb2RlJykgZHJhZ2dhYmxlTm9kZTogSU1pbmRtYXBOb2RlO1xyXG4gICAgQElucHV0KCdkcmFnZ2FibGVJbkdyYXBoJykgZHJhZ2dhYmxlSW5HcmFwaDogRm9yY2VEaXJlY3RlZEdyYXBoO1xyXG5cclxuICAgIGNvbnN0cnVjdG9yKHByaXZhdGUgX21pbmRtYXBTdmM6IEtkTWluZG1hcFN2YywgcHJpdmF0ZSBfZWxlbWVudDogRWxlbWVudFJlZikgeyB9XHJcblxyXG4gICAgbmdPbkluaXQoKSB7XHJcbiAgICAgICAgdGhpcy5fbWluZG1hcFN2Yy5hcHBseURyYWdnYWJsZUJlaGF2aW91cih0aGlzLl9lbGVtZW50Lm5hdGl2ZUVsZW1lbnQsIHRoaXMuZHJhZ2dhYmxlTm9kZSwgdGhpcy5kcmFnZ2FibGVJbkdyYXBoKTtcclxuICAgIH1cclxufVxyXG4iXX0=