import { Component, ViewEncapsulation, Input } from '@angular/core';
export class KdMindmapZoomButton {
    constructor() {
        this.iconType = 'plus';
    }
    ngOnInit() {
        this.iconType = this.action === 'zoom_in' ? 'plus' : 'minus';
    }
    onClick(_event) {
        _event.stopPropagation();
        if (typeof this.internalApi !== 'undefined') {
            this.internalApi.zoom(this.action);
        }
    }
}
KdMindmapZoomButton.decorators = [
    { type: Component, args: [{
                selector: '[zoomButton]',
                template: `
        <svg:rect
            class="kdx-mindmap-zoom-button-wrapper kdx-mindmap-zoom-in"
            x="0"
            y="0"
            rx="2"
            ry="2"
            [attr.width]="config.size"
            [attr.height]="config.size"
        ></svg:rect>
        <svg [attr.width]="config.iconSize"
             [attr.height]="config.iconSize"
             [attr.x]="config.size/2 - config.iconSize/2"
             [attr.y]="config.size/2 - config.iconSize/2">
            <use class="kdx-mindmap-zoom-button-icon"
                 [attr.href]="config.iconLinkPath + iconType" ></use>
        </svg>
    `,
                encapsulation: ViewEncapsulation.None,
                host: {
                    'class': 'kdx-mindmap-zoom-button',
                    '(click)': 'onClick($event)',
                }
            },] }
];
KdMindmapZoomButton.propDecorators = {
    config: [{ type: Input }],
    action: [{ type: Input, args: ['zoomButton',] }],
    internalApi: [{ type: Input, args: ['api',] }]
};
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoia2QtYW5ndWxhci1taW5kbWFwLXpvb20tY29tcG9uZW50LmpzIiwic291cmNlUm9vdCI6IkQ6L29wZW5FTUlTL3N0eWxlZ3VpZGUvaW9zdGctb3BlbmVtaXMtc3R5bGVndWlkZS9wcm9qZWN0cy9vcGVuZW1pcy1zdHlsZWd1aWRlLWxpYi9zcmMvIiwic291cmNlcyI6WyJrZC1jb21wb25lbnRzL2tkLWFuZ3VsYXItbWluZG1hcC96b29tL2tkLWFuZ3VsYXItbWluZG1hcC16b29tLWNvbXBvbmVudC50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQSxPQUFPLEVBQ0gsU0FBUyxFQUNULGlCQUFpQixFQUNqQixLQUFLLEVBRVIsTUFBTSxlQUFlLENBQUM7QUE4QnZCLE1BQU0sT0FBTyxtQkFBbUI7SUEzQmhDO1FBNEJXLGFBQVEsR0FBVyxNQUFNLENBQUM7SUFlckMsQ0FBQztJQVZHLFFBQVE7UUFDSixJQUFJLENBQUMsUUFBUSxHQUFHLElBQUksQ0FBQyxNQUFNLEtBQUssU0FBUyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQztJQUNqRSxDQUFDO0lBRU0sT0FBTyxDQUFDLE1BQWE7UUFDeEIsTUFBTSxDQUFDLGVBQWUsRUFBRSxDQUFDO1FBQ3pCLElBQUksT0FBTyxJQUFJLENBQUMsV0FBVyxLQUFLLFdBQVcsRUFBRTtZQUN6QyxJQUFJLENBQUMsV0FBVyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUM7U0FDdEM7SUFDTCxDQUFDOzs7WUExQ0osU0FBUyxTQUFDO2dCQUNQLFFBQVEsRUFBRSxjQUFjO2dCQUN4QixRQUFRLEVBQUU7Ozs7Ozs7Ozs7Ozs7Ozs7O0tBaUJUO2dCQUNELGFBQWEsRUFBRSxpQkFBaUIsQ0FBQyxJQUFJO2dCQUNyQyxJQUFJLEVBQUU7b0JBQ0YsT0FBTyxFQUFFLHlCQUF5QjtvQkFDbEMsU0FBUyxFQUFFLGlCQUFpQjtpQkFDL0I7YUFDSjs7O3FCQUlJLEtBQUs7cUJBQ0wsS0FBSyxTQUFDLFlBQVk7MEJBQ2xCLEtBQUssU0FBQyxLQUFLIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHtcclxuICAgIENvbXBvbmVudCxcclxuICAgIFZpZXdFbmNhcHN1bGF0aW9uLFxyXG4gICAgSW5wdXQsXHJcbiAgICBPbkluaXRcclxufSBmcm9tICdAYW5ndWxhci9jb3JlJztcclxuaW1wb3J0IHsgSVpvb21CdXR0b25Db25maWcsIElNaW5kbWFwSW50ZXJuYWxBcGkgfSBmcm9tICcuLi9rZC1hbmd1bGFyLW1pbmRtYXAtaW50ZXJmYWNlJztcclxuXHJcbkBDb21wb25lbnQoe1xyXG4gICAgc2VsZWN0b3I6ICdbem9vbUJ1dHRvbl0nLFxyXG4gICAgdGVtcGxhdGU6IGBcclxuICAgICAgICA8c3ZnOnJlY3RcclxuICAgICAgICAgICAgY2xhc3M9XCJrZHgtbWluZG1hcC16b29tLWJ1dHRvbi13cmFwcGVyIGtkeC1taW5kbWFwLXpvb20taW5cIlxyXG4gICAgICAgICAgICB4PVwiMFwiXHJcbiAgICAgICAgICAgIHk9XCIwXCJcclxuICAgICAgICAgICAgcng9XCIyXCJcclxuICAgICAgICAgICAgcnk9XCIyXCJcclxuICAgICAgICAgICAgW2F0dHIud2lkdGhdPVwiY29uZmlnLnNpemVcIlxyXG4gICAgICAgICAgICBbYXR0ci5oZWlnaHRdPVwiY29uZmlnLnNpemVcIlxyXG4gICAgICAgID48L3N2ZzpyZWN0PlxyXG4gICAgICAgIDxzdmcgW2F0dHIud2lkdGhdPVwiY29uZmlnLmljb25TaXplXCJcclxuICAgICAgICAgICAgIFthdHRyLmhlaWdodF09XCJjb25maWcuaWNvblNpemVcIlxyXG4gICAgICAgICAgICAgW2F0dHIueF09XCJjb25maWcuc2l6ZS8yIC0gY29uZmlnLmljb25TaXplLzJcIlxyXG4gICAgICAgICAgICAgW2F0dHIueV09XCJjb25maWcuc2l6ZS8yIC0gY29uZmlnLmljb25TaXplLzJcIj5cclxuICAgICAgICAgICAgPHVzZSBjbGFzcz1cImtkeC1taW5kbWFwLXpvb20tYnV0dG9uLWljb25cIlxyXG4gICAgICAgICAgICAgICAgIFthdHRyLmhyZWZdPVwiY29uZmlnLmljb25MaW5rUGF0aCArIGljb25UeXBlXCIgPjwvdXNlPlxyXG4gICAgICAgIDwvc3ZnPlxyXG4gICAgYCxcclxuICAgIGVuY2Fwc3VsYXRpb246IFZpZXdFbmNhcHN1bGF0aW9uLk5vbmUsXHJcbiAgICBob3N0OiB7XHJcbiAgICAgICAgJ2NsYXNzJzogJ2tkeC1taW5kbWFwLXpvb20tYnV0dG9uJyxcclxuICAgICAgICAnKGNsaWNrKSc6ICdvbkNsaWNrKCRldmVudCknLFxyXG4gICAgfVxyXG59KVxyXG5cclxuZXhwb3J0IGNsYXNzIEtkTWluZG1hcFpvb21CdXR0b24gaW1wbGVtZW50cyBPbkluaXQge1xyXG4gICAgcHVibGljIGljb25UeXBlOiBzdHJpbmcgPSAncGx1cyc7XHJcbiAgICBASW5wdXQoKSBjb25maWc6IElab29tQnV0dG9uQ29uZmlnO1xyXG4gICAgQElucHV0KCd6b29tQnV0dG9uJykgYWN0aW9uOiBzdHJpbmc7XHJcbiAgICBASW5wdXQoJ2FwaScpIGludGVybmFsQXBpOiBJTWluZG1hcEludGVybmFsQXBpO1xyXG5cclxuICAgIG5nT25Jbml0KCk6IHZvaWQge1xyXG4gICAgICAgIHRoaXMuaWNvblR5cGUgPSB0aGlzLmFjdGlvbiA9PT0gJ3pvb21faW4nID8gJ3BsdXMnIDogJ21pbnVzJztcclxuICAgIH1cclxuXHJcbiAgICBwdWJsaWMgb25DbGljayhfZXZlbnQ6IEV2ZW50KTogdm9pZCB7XHJcbiAgICAgICAgX2V2ZW50LnN0b3BQcm9wYWdhdGlvbigpO1xyXG4gICAgICAgIGlmICh0eXBlb2YgdGhpcy5pbnRlcm5hbEFwaSAhPT0gJ3VuZGVmaW5lZCcpIHtcclxuICAgICAgICAgICAgdGhpcy5pbnRlcm5hbEFwaS56b29tKHRoaXMuYWN0aW9uKTtcclxuICAgICAgICB9XHJcbiAgICB9XHJcbn1cclxuIl19