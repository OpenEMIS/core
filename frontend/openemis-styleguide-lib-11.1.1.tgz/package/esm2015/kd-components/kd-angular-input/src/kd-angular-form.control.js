import { Injectable } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
export class KdInputControlService {
    constructor() { }
    toFormGroup(inputs) {
        let group = {};
        for (let i = 0; i < inputs.length; i++) {
            let validatorArr = [];
            // Grace -- 7 Nov 2017 --
            // testing generate validator function by passing validation logic as string but load speed will become very slow
            // if(inputs[i].getProperty('required')){
            //     validatorArr.push(this._generalValidatorFnGenerator({
            //         target: 'control.value',
            //         compare: '',
            //         logic: 'return a !== b? false: true'
            //     }, 'this field cannot be empty' ))
            // }
            if (inputs[i].getProperty('controlType') === 'file-input') {
                const config = inputs[i].getProperty('config');
                validatorArr.push(this._fileSizeValidator(config.maxFileSize, config.errorMessage));
            }
            // if (inputs[i].getProperty('required')) {
            //     validatorArr.push(this._requiredValidator('This field should not be empty'));
            // }
            group[inputs[i].getProperty('key')] = new FormControl(inputs[i].getProperty('value') || '', Validators.compose(validatorArr));
        }
        return new FormGroup(group);
    }
    emptyFormGroup() {
        return new FormGroup({});
    }
    _fileSizeValidator(maxFileSize, errorMessage) {
        return (control) => {
            let sizeExceed = false;
            if (typeof control !== 'undefined' &&
                typeof control.value !== 'undefined' &&
                typeof control.value.size !== 'undefined') {
                sizeExceed = control.value.size > maxFileSize;
            }
            return sizeExceed ? { [new Date().toISOString()]: errorMessage } : null;
        };
    }
}
KdInputControlService.decorators = [
    { type: Injectable }
];
KdInputControlService.ctorParameters = () => [];
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoia2QtYW5ndWxhci1mb3JtLmNvbnRyb2wuanMiLCJzb3VyY2VSb290IjoiRDovb3BlbkVNSVMvc3R5bGVndWlkZS9pb3N0Zy1vcGVuZW1pcy1zdHlsZWd1aWRlL3Byb2plY3RzL29wZW5lbWlzLXN0eWxlZ3VpZGUtbGliL3NyYy8iLCJzb3VyY2VzIjpbImtkLWNvbXBvbmVudHMva2QtYW5ndWxhci1pbnB1dC9zcmMva2QtYW5ndWxhci1mb3JtLmNvbnRyb2wudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsT0FBTyxFQUFFLFVBQVUsRUFBRSxNQUFNLGVBQWUsQ0FBQztBQUMzQyxPQUFPLEVBQUUsV0FBVyxFQUFFLFNBQVMsRUFBRSxVQUFVLEVBQWdDLE1BQU0sZ0JBQWdCLENBQUM7QUFLbEcsTUFBTSxPQUFPLHFCQUFxQjtJQUM5QixnQkFBZ0IsQ0FBQztJQUVqQixXQUFXLENBQUMsTUFBd0I7UUFDaEMsSUFBSSxLQUFLLEdBQVEsRUFBRSxDQUFDO1FBRXBCLEtBQUssSUFBSSxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsR0FBRyxNQUFNLENBQUMsTUFBTSxFQUFFLENBQUMsRUFBRSxFQUFFO1lBQ3BDLElBQUksWUFBWSxHQUF1QixFQUFFLENBQUM7WUFHMUMseUJBQXlCO1lBQ3pCLGlIQUFpSDtZQUNqSCx5Q0FBeUM7WUFDekMsNERBQTREO1lBQzVELG1DQUFtQztZQUNuQyx1QkFBdUI7WUFDdkIsK0NBQStDO1lBQy9DLHlDQUF5QztZQUN6QyxJQUFJO1lBRUosSUFBSSxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsV0FBVyxDQUFDLGFBQWEsQ0FBQyxLQUFLLFlBQVksRUFBRTtnQkFDdkQsTUFBTSxNQUFNLEdBQUcsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLFdBQVcsQ0FBQyxRQUFRLENBQUMsQ0FBQztnQkFDL0MsWUFBWSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsa0JBQWtCLENBQUMsTUFBTSxDQUFDLFdBQVcsRUFBRSxNQUFNLENBQUMsWUFBWSxDQUFDLENBQUMsQ0FBQzthQUN2RjtZQUVELDJDQUEyQztZQUMzQyxvRkFBb0Y7WUFDcEYsSUFBSTtZQUVKLEtBQUssQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsV0FBVyxDQUFDLEtBQUssQ0FBQyxDQUFDLEdBQUcsSUFBSSxXQUFXLENBQ2pELE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxXQUFXLENBQUMsT0FBTyxDQUFDLElBQUksRUFBRSxFQUNwQyxVQUFVLENBQUMsT0FBTyxDQUFDLFlBQVksQ0FBQyxDQUNuQyxDQUFDO1NBQ0w7UUFDRCxPQUFPLElBQUksU0FBUyxDQUFDLEtBQUssQ0FBQyxDQUFDO0lBQ2hDLENBQUM7SUFFRCxjQUFjO1FBQ1YsT0FBTyxJQUFJLFNBQVMsQ0FBQyxFQUFFLENBQUMsQ0FBQztJQUM3QixDQUFDO0lBRU8sa0JBQWtCLENBQUMsV0FBbUIsRUFBRSxZQUFvQjtRQUNoRSxPQUFPLENBQUMsT0FBd0IsRUFBMEIsRUFBRTtZQUN4RCxJQUFJLFVBQVUsR0FBWSxLQUFLLENBQUM7WUFFaEMsSUFBSSxPQUFPLE9BQU8sS0FBSyxXQUFXO2dCQUM5QixPQUFPLE9BQU8sQ0FBQyxLQUFLLEtBQUssV0FBVztnQkFDcEMsT0FBTyxPQUFPLENBQUMsS0FBSyxDQUFDLElBQUksS0FBSyxXQUFXLEVBQUU7Z0JBQ3ZDLFVBQVUsR0FBRyxPQUFPLENBQUMsS0FBSyxDQUFDLElBQUksR0FBRyxXQUFXLENBQUM7YUFDckQ7WUFDRCxPQUFPLFVBQVUsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLElBQUksSUFBSSxFQUFFLENBQUMsV0FBVyxFQUFFLENBQUMsRUFBRSxZQUFZLEVBQUUsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDO1FBQzVFLENBQUMsQ0FBQztJQUNOLENBQUM7OztZQXJESixVQUFVIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgSW5qZWN0YWJsZSB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xyXG5pbXBvcnQgeyBGb3JtQ29udHJvbCwgRm9ybUdyb3VwLCBWYWxpZGF0b3JzLCBWYWxpZGF0b3JGbiwgQWJzdHJhY3RDb250cm9sIH0gZnJvbSAnQGFuZ3VsYXIvZm9ybXMnO1xyXG5cclxuaW1wb3J0IHsgSW5wdXRCYXNlIH0gZnJvbSAnLi9rZC1pbnB1dC1iYXNlJztcclxuXHJcbkBJbmplY3RhYmxlKClcclxuZXhwb3J0IGNsYXNzIEtkSW5wdXRDb250cm9sU2VydmljZSB7XHJcbiAgICBjb25zdHJ1Y3RvcigpIHsgfVxyXG5cclxuICAgIHRvRm9ybUdyb3VwKGlucHV0czogSW5wdXRCYXNlPGFueT5bXSk6IEZvcm1Hcm91cCB7XHJcbiAgICAgICAgbGV0IGdyb3VwOiBhbnkgPSB7fTtcclxuXHJcbiAgICAgICAgZm9yIChsZXQgaSA9IDA7IGkgPCBpbnB1dHMubGVuZ3RoOyBpKyspIHtcclxuICAgICAgICAgICAgbGV0IHZhbGlkYXRvckFycjogQXJyYXk8VmFsaWRhdG9yRm4+ID0gW107XHJcblxyXG5cclxuICAgICAgICAgICAgLy8gR3JhY2UgLS0gNyBOb3YgMjAxNyAtLVxyXG4gICAgICAgICAgICAvLyB0ZXN0aW5nIGdlbmVyYXRlIHZhbGlkYXRvciBmdW5jdGlvbiBieSBwYXNzaW5nIHZhbGlkYXRpb24gbG9naWMgYXMgc3RyaW5nIGJ1dCBsb2FkIHNwZWVkIHdpbGwgYmVjb21lIHZlcnkgc2xvd1xyXG4gICAgICAgICAgICAvLyBpZihpbnB1dHNbaV0uZ2V0UHJvcGVydHkoJ3JlcXVpcmVkJykpe1xyXG4gICAgICAgICAgICAvLyAgICAgdmFsaWRhdG9yQXJyLnB1c2godGhpcy5fZ2VuZXJhbFZhbGlkYXRvckZuR2VuZXJhdG9yKHtcclxuICAgICAgICAgICAgLy8gICAgICAgICB0YXJnZXQ6ICdjb250cm9sLnZhbHVlJyxcclxuICAgICAgICAgICAgLy8gICAgICAgICBjb21wYXJlOiAnJyxcclxuICAgICAgICAgICAgLy8gICAgICAgICBsb2dpYzogJ3JldHVybiBhICE9PSBiPyBmYWxzZTogdHJ1ZSdcclxuICAgICAgICAgICAgLy8gICAgIH0sICd0aGlzIGZpZWxkIGNhbm5vdCBiZSBlbXB0eScgKSlcclxuICAgICAgICAgICAgLy8gfVxyXG5cclxuICAgICAgICAgICAgaWYgKGlucHV0c1tpXS5nZXRQcm9wZXJ0eSgnY29udHJvbFR5cGUnKSA9PT0gJ2ZpbGUtaW5wdXQnKSB7XHJcbiAgICAgICAgICAgICAgICBjb25zdCBjb25maWcgPSBpbnB1dHNbaV0uZ2V0UHJvcGVydHkoJ2NvbmZpZycpO1xyXG4gICAgICAgICAgICAgICAgdmFsaWRhdG9yQXJyLnB1c2godGhpcy5fZmlsZVNpemVWYWxpZGF0b3IoY29uZmlnLm1heEZpbGVTaXplLCBjb25maWcuZXJyb3JNZXNzYWdlKSk7XHJcbiAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgIC8vIGlmIChpbnB1dHNbaV0uZ2V0UHJvcGVydHkoJ3JlcXVpcmVkJykpIHtcclxuICAgICAgICAgICAgLy8gICAgIHZhbGlkYXRvckFyci5wdXNoKHRoaXMuX3JlcXVpcmVkVmFsaWRhdG9yKCdUaGlzIGZpZWxkIHNob3VsZCBub3QgYmUgZW1wdHknKSk7XHJcbiAgICAgICAgICAgIC8vIH1cclxuXHJcbiAgICAgICAgICAgIGdyb3VwW2lucHV0c1tpXS5nZXRQcm9wZXJ0eSgna2V5JyldID0gbmV3IEZvcm1Db250cm9sKFxyXG4gICAgICAgICAgICAgICAgaW5wdXRzW2ldLmdldFByb3BlcnR5KCd2YWx1ZScpIHx8ICcnLFxyXG4gICAgICAgICAgICAgICAgVmFsaWRhdG9ycy5jb21wb3NlKHZhbGlkYXRvckFycilcclxuICAgICAgICAgICAgKTtcclxuICAgICAgICB9XHJcbiAgICAgICAgcmV0dXJuIG5ldyBGb3JtR3JvdXAoZ3JvdXApO1xyXG4gICAgfVxyXG5cclxuICAgIGVtcHR5Rm9ybUdyb3VwKCk6IEZvcm1Hcm91cCB7XHJcbiAgICAgICAgcmV0dXJuIG5ldyBGb3JtR3JvdXAoe30pO1xyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX2ZpbGVTaXplVmFsaWRhdG9yKG1heEZpbGVTaXplOiBudW1iZXIsIGVycm9yTWVzc2FnZTogc3RyaW5nKTogVmFsaWRhdG9yRm4ge1xyXG4gICAgICAgIHJldHVybiAoY29udHJvbDogQWJzdHJhY3RDb250cm9sKTogeyBba2V5OiBzdHJpbmddOiBhbnkgfSA9PiB7XHJcbiAgICAgICAgICAgIGxldCBzaXplRXhjZWVkOiBib29sZWFuID0gZmFsc2U7XHJcblxyXG4gICAgICAgICAgICBpZiAodHlwZW9mIGNvbnRyb2wgIT09ICd1bmRlZmluZWQnICYmXHJcbiAgICAgICAgICAgICAgICB0eXBlb2YgY29udHJvbC52YWx1ZSAhPT0gJ3VuZGVmaW5lZCcgJiZcclxuICAgICAgICAgICAgICAgIHR5cGVvZiBjb250cm9sLnZhbHVlLnNpemUgIT09ICd1bmRlZmluZWQnKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgc2l6ZUV4Y2VlZCA9IGNvbnRyb2wudmFsdWUuc2l6ZSA+IG1heEZpbGVTaXplO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIHJldHVybiBzaXplRXhjZWVkID8geyBbbmV3IERhdGUoKS50b0lTT1N0cmluZygpXTogZXJyb3JNZXNzYWdlIH0gOiBudWxsO1xyXG4gICAgICAgIH07XHJcbiAgICB9XHJcblxyXG4gICAgLy8gcHJpdmF0ZSBfcmVxdWlyZWRWYWxpZGF0b3IoZXJyb3JNZXNzYWdlOiBzdHJpbmcpOiBWYWxpZGF0b3JGbiB7XHJcbiAgICAvLyAgICAgcmV0dXJuIChjb250cm9sOiBBYnN0cmFjdENvbnRyb2wpOiB7W2tleTogc3RyaW5nXTogYW55fSA9PiB7XHJcbiAgICAvLyAgICAgICAgIGlmICh0eXBlb2YgY29udHJvbC52YWx1ZSAhPT0gJ3VuZGVmaW5lZCcpIHtcclxuICAgIC8vICAgICAgICAgICAgIGNvbnN0IGVycm9yOiBib29sZWFuID0gY29udHJvbC52YWx1ZSA9PT0gJycgPyB0cnVlIDogZmFsc2U7XHJcbiAgICAvLyAgICAgICAgICAgICByZXR1cm4gZXJyb3IgPyB7W25ldyBEYXRlKCkudG9JU09TdHJpbmcgKCldOiBlcnJvck1lc3NhZ2V9IDogbnVsbDtcclxuICAgIC8vICAgICAgICAgfVxyXG4gICAgLy8gICAgIH07XHJcbiAgICAvLyB9XHJcblxyXG4gICAgLy8gR3JhY2UgLS0gNyBOb3YgMjAxNyAtLSBnZW5lcmFsIHZhbGlkYXRvciBmdW5jdGlvbiBnZW5lcmF0b3JcclxuICAgIC8vIHByaXZhdGUgX2dlbmVyYWxWYWxpZGF0b3JGbkdlbmVyYXRvcihsb2dpY1RvVGVzdDpvYmplY3QsIGVycm9yTWVzc2FnZTogc3RyaW5nKTpWYWxpZGF0b3JGbiB7XHJcbiAgICAvLyAgICAgcmV0dXJuIChjb250cm9sOiBBYnN0cmFjdENvbnRyb2wpOiB7W2tleTogc3RyaW5nXTogYW55fSA9PiB7XHJcbiAgICAvLyAgICAgbGV0IGxvZ2ljRnVuY3Rpb24gPSBuZXcgRnVuY3Rpb24oJ2EnLCdiJywgbG9naWNUb1Rlc3QubG9naWMpXHJcbiAgICAvLyAgICAgbGV0IGVycm9yID0gbG9naWNGdW5jdGlvbihldmFsKGxvZ2ljVG9UZXN0LnRhcmdldCksbG9naWNUb1Rlc3QuY29tcGFyZSk7XHJcbiAgICAvLyAgICAgcmV0dXJuIGVycm9yID8geyBbbmV3IERhdGUoKS50b0lTT1N0cmluZyAoKV0gOiBlcnJvck1lc3NhZ2V9IDogbnVsbDtcclxuICAgIC8vICAgfTtcclxuICAgIC8vIH1cclxufVxyXG4iXX0=