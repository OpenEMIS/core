import { Subject, AsyncSubject } from 'rxjs';
import { Injectable } from '@angular/core';
import { map, filter } from 'rxjs/operators';
import * as i0 from "@angular/core";
export class KdBroadcaster {
    constructor() {
        this._eventBus = new Subject();
        // this._eventReplayBus = new ReplaySubject<KdBroadcastEvent>();
        this._eventAsyncBus = new AsyncSubject();
    }
    broadcast(key, data) {
        this._eventBus.next({ key, data });
    }
    on(key) {
        return this._eventBus.asObservable()
            .pipe(filter((event) => event.key === key), map((event) => event.data));
    }
    // broadcastReplay(key: any, data?: any) {
    //     this._eventReplayBus.next({ key, data });
    // }
    // onReplay<T>(key: any): Observable<T> {
    //     return this._eventReplayBus.asObservable()
    //         .pipe(
    //             filter((event: any): boolean => event.key === key),
    //             map((event: any): T => <T>event.data)
    //         );
    // }
    broadcastAsync(key, data) {
        this._eventAsyncBus.next({ key, data });
    }
    onAsync(key) {
        return this._eventAsyncBus.asObservable()
            .pipe(filter((event) => event.key === key), map((event) => event.data));
    }
    completeAsync(key) {
        this._eventAsyncBus.complete();
    }
}
KdBroadcaster.ɵprov = i0.ɵɵdefineInjectable({ factory: function KdBroadcaster_Factory() { return new KdBroadcaster(); }, token: KdBroadcaster, providedIn: "root" });
KdBroadcaster.decorators = [
    { type: Injectable, args: [{
                providedIn: 'root'
            },] }
];
KdBroadcaster.ctorParameters = () => [];
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoia2QtYnJvYWRjYXN0ZXItc3ZjLmpzIiwic291cmNlUm9vdCI6IkQ6L29wZW5FTUlTL3N0eWxlZ3VpZGUvaW9zdGctb3BlbmVtaXMtc3R5bGVndWlkZS9wcm9qZWN0cy9vcGVuZW1pcy1zdHlsZWd1aWRlLWxpYi9zcmMvIiwic291cmNlcyI6WyJrZC1jb21wb25lbnRzL2tkLWNvbW1vbi9rZC1icm9hZGNhc3Rlci1zdmMudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsT0FBTyxFQUFFLE9BQU8sRUFBSSxZQUFZLEVBQWdCLE1BQU0sTUFBTSxDQUFDO0FBQzdELE9BQU8sRUFBRSxVQUFVLEVBQUUsTUFBTSxlQUFlLENBQUM7QUFDM0MsT0FBTyxFQUFFLEdBQUcsRUFBRSxNQUFNLEVBQUUsTUFBTSxnQkFBZ0IsQ0FBQzs7QUFVN0MsTUFBTSxPQUFPLGFBQWE7SUFLdEI7UUFDSSxJQUFJLENBQUMsU0FBUyxHQUFHLElBQUksT0FBTyxFQUFvQixDQUFDO1FBQ2pELGdFQUFnRTtRQUNoRSxJQUFJLENBQUMsY0FBYyxHQUFHLElBQUksWUFBWSxFQUFvQixDQUFDO0lBQy9ELENBQUM7SUFFRCxTQUFTLENBQUMsR0FBUSxFQUFFLElBQVU7UUFDMUIsSUFBSSxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsRUFBRSxHQUFHLEVBQUUsSUFBSSxFQUFFLENBQUMsQ0FBQztJQUN2QyxDQUFDO0lBRUQsRUFBRSxDQUFJLEdBQVE7UUFDVixPQUFPLElBQUksQ0FBQyxTQUFTLENBQUMsWUFBWSxFQUFFO2FBQy9CLElBQUksQ0FDRCxNQUFNLENBQUMsQ0FBQyxLQUFVLEVBQVcsRUFBRSxDQUFDLEtBQUssQ0FBQyxHQUFHLEtBQUssR0FBRyxDQUFDLEVBQ2xELEdBQUcsQ0FBQyxDQUFDLEtBQVUsRUFBSyxFQUFFLENBQUksS0FBSyxDQUFDLElBQUksQ0FBQyxDQUN4QyxDQUFDO0lBQ1YsQ0FBQztJQUVELDBDQUEwQztJQUMxQyxnREFBZ0Q7SUFDaEQsSUFBSTtJQUVKLHlDQUF5QztJQUN6QyxpREFBaUQ7SUFDakQsaUJBQWlCO0lBQ2pCLGtFQUFrRTtJQUNsRSxvREFBb0Q7SUFDcEQsYUFBYTtJQUNiLElBQUk7SUFFSixjQUFjLENBQUMsR0FBUSxFQUFFLElBQVU7UUFDL0IsSUFBSSxDQUFDLGNBQWMsQ0FBQyxJQUFJLENBQUMsRUFBRSxHQUFHLEVBQUUsSUFBSSxFQUFFLENBQUMsQ0FBQztJQUM1QyxDQUFDO0lBRUQsT0FBTyxDQUFJLEdBQVE7UUFDZixPQUFPLElBQUksQ0FBQyxjQUFjLENBQUMsWUFBWSxFQUFFO2FBQ3BDLElBQUksQ0FDRCxNQUFNLENBQUMsQ0FBQyxLQUFVLEVBQVcsRUFBRSxDQUFDLEtBQUssQ0FBQyxHQUFHLEtBQUssR0FBRyxDQUFDLEVBQ2xELEdBQUcsQ0FBQyxDQUFDLEtBQVUsRUFBSyxFQUFFLENBQUksS0FBSyxDQUFDLElBQUksQ0FBQyxDQUN4QyxDQUFDO0lBQ1YsQ0FBQztJQUVELGFBQWEsQ0FBQyxHQUFRO1FBQ2xCLElBQUksQ0FBQyxjQUFjLENBQUMsUUFBUSxFQUFFLENBQUM7SUFDbkMsQ0FBQzs7OztZQXBESixVQUFVLFNBQUM7Z0JBQ1IsVUFBVSxFQUFFLE1BQU07YUFDckIiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBTdWJqZWN0ICwgIEFzeW5jU3ViamVjdCAsICBPYnNlcnZhYmxlIH0gZnJvbSAncnhqcyc7XHJcbmltcG9ydCB7IEluamVjdGFibGUgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcclxuaW1wb3J0IHsgbWFwLCBmaWx0ZXIgfSBmcm9tICdyeGpzL29wZXJhdG9ycyc7XHJcblxyXG5pbnRlcmZhY2UgS2RCcm9hZGNhc3RFdmVudCB7XHJcbiAgICBrZXk6IGFueTtcclxuICAgIGRhdGE/OiBhbnk7XHJcbn1cclxuXHJcbkBJbmplY3RhYmxlKHtcclxuICAgIHByb3ZpZGVkSW46ICdyb290J1xyXG59KVxyXG5leHBvcnQgY2xhc3MgS2RCcm9hZGNhc3RlciB7XHJcbiAgICBwcml2YXRlIF9ldmVudEJ1czogU3ViamVjdDxLZEJyb2FkY2FzdEV2ZW50PjtcclxuICAgIC8vIHByaXZhdGUgX2V2ZW50UmVwbGF5QnVzOiBSZXBsYXlTdWJqZWN0PEtkQnJvYWRjYXN0RXZlbnQ+O1xyXG4gICAgcHJpdmF0ZSBfZXZlbnRBc3luY0J1czogQXN5bmNTdWJqZWN0PEtkQnJvYWRjYXN0RXZlbnQ+O1xyXG5cclxuICAgIGNvbnN0cnVjdG9yKCkge1xyXG4gICAgICAgIHRoaXMuX2V2ZW50QnVzID0gbmV3IFN1YmplY3Q8S2RCcm9hZGNhc3RFdmVudD4oKTtcclxuICAgICAgICAvLyB0aGlzLl9ldmVudFJlcGxheUJ1cyA9IG5ldyBSZXBsYXlTdWJqZWN0PEtkQnJvYWRjYXN0RXZlbnQ+KCk7XHJcbiAgICAgICAgdGhpcy5fZXZlbnRBc3luY0J1cyA9IG5ldyBBc3luY1N1YmplY3Q8S2RCcm9hZGNhc3RFdmVudD4oKTtcclxuICAgIH1cclxuXHJcbiAgICBicm9hZGNhc3Qoa2V5OiBhbnksIGRhdGE/OiBhbnkpIHtcclxuICAgICAgICB0aGlzLl9ldmVudEJ1cy5uZXh0KHsga2V5LCBkYXRhIH0pO1xyXG4gICAgfVxyXG5cclxuICAgIG9uPFQ+KGtleTogYW55KTogT2JzZXJ2YWJsZTxUPiB7XHJcbiAgICAgICAgcmV0dXJuIHRoaXMuX2V2ZW50QnVzLmFzT2JzZXJ2YWJsZSgpXHJcbiAgICAgICAgICAgIC5waXBlKFxyXG4gICAgICAgICAgICAgICAgZmlsdGVyKChldmVudDogYW55KTogYm9vbGVhbiA9PiBldmVudC5rZXkgPT09IGtleSksXHJcbiAgICAgICAgICAgICAgICBtYXAoKGV2ZW50OiBhbnkpOiBUID0+IDxUPmV2ZW50LmRhdGEpXHJcbiAgICAgICAgICAgICk7XHJcbiAgICB9XHJcblxyXG4gICAgLy8gYnJvYWRjYXN0UmVwbGF5KGtleTogYW55LCBkYXRhPzogYW55KSB7XHJcbiAgICAvLyAgICAgdGhpcy5fZXZlbnRSZXBsYXlCdXMubmV4dCh7IGtleSwgZGF0YSB9KTtcclxuICAgIC8vIH1cclxuXHJcbiAgICAvLyBvblJlcGxheTxUPihrZXk6IGFueSk6IE9ic2VydmFibGU8VD4ge1xyXG4gICAgLy8gICAgIHJldHVybiB0aGlzLl9ldmVudFJlcGxheUJ1cy5hc09ic2VydmFibGUoKVxyXG4gICAgLy8gICAgICAgICAucGlwZShcclxuICAgIC8vICAgICAgICAgICAgIGZpbHRlcigoZXZlbnQ6IGFueSk6IGJvb2xlYW4gPT4gZXZlbnQua2V5ID09PSBrZXkpLFxyXG4gICAgLy8gICAgICAgICAgICAgbWFwKChldmVudDogYW55KTogVCA9PiA8VD5ldmVudC5kYXRhKVxyXG4gICAgLy8gICAgICAgICApO1xyXG4gICAgLy8gfVxyXG5cclxuICAgIGJyb2FkY2FzdEFzeW5jKGtleTogYW55LCBkYXRhPzogYW55KTogdm9pZCB7XHJcbiAgICAgICAgdGhpcy5fZXZlbnRBc3luY0J1cy5uZXh0KHsga2V5LCBkYXRhIH0pO1xyXG4gICAgfVxyXG5cclxuICAgIG9uQXN5bmM8VD4oa2V5OiBhbnkpOiBPYnNlcnZhYmxlPFQ+IHtcclxuICAgICAgICByZXR1cm4gdGhpcy5fZXZlbnRBc3luY0J1cy5hc09ic2VydmFibGUoKVxyXG4gICAgICAgICAgICAucGlwZShcclxuICAgICAgICAgICAgICAgIGZpbHRlcigoZXZlbnQ6IGFueSk6IGJvb2xlYW4gPT4gZXZlbnQua2V5ID09PSBrZXkpLFxyXG4gICAgICAgICAgICAgICAgbWFwKChldmVudDogYW55KTogVCA9PiA8VD5ldmVudC5kYXRhKVxyXG4gICAgICAgICAgICApO1xyXG4gICAgfVxyXG5cclxuICAgIGNvbXBsZXRlQXN5bmMoa2V5OiBhbnkpOiB2b2lkIHtcclxuICAgICAgICB0aGlzLl9ldmVudEFzeW5jQnVzLmNvbXBsZXRlKCk7XHJcbiAgICB9XHJcbn1cclxuIl19