import { Component, ViewEncapsulation, Input } from '@angular/core';
import { KdDomElemSvc } from '../kd-common/index';
export class KdProgressloader {
    constructor(_kdDomElemSvc) {
        this._kdDomElemSvc = _kdDomElemSvc;
    }
    ngOnInit() {
        this.configDefaults();
        // console.log(this.value);
    }
    ngOnChanges() {
        // console.log(this.value);
        // console.log(this.configvalue);
        this.value = this.configvalue;
        if (this.value >= 100) {
            this.value = 100;
        }
    }
    configDefaults() {
        this.message = (typeof this.configmessage !== 'undefined') ? this.configmessage : '';
        this.value = (typeof this.configvalue !== 'undefined' || this.configvalue !== null) ? this.configvalue : null;
        if (typeof this.configtype !== 'undefined') {
            this.type = this.configtype;
            if (this.type === 'wholepagespinner') {
                this.createLoadpage();
            }
        }
        else {
            this.type = 'progressbar';
        }
    }
    createLoadpage() {
        let loadingText = 'Loading...';
        let body = document.body;
        let newDiv = this._kdDomElemSvc.createElement(body, 'kdx-load-page');
        let loaderWrapper = this._kdDomElemSvc.createElement(newDiv, 'kdx-loader-wrapper');
        let newSpinnerContainer = this._kdDomElemSvc.createElement(loaderWrapper, 'kdx-loader-container');
        this._kdDomElemSvc.createElement(newSpinnerContainer, 'kdx-loader kdx-rotating');
        this._kdDomElemSvc.createElement(newSpinnerContainer, 'fa kd-openemis openemis-icon', 'i');
        let loaderTextWrapper = this._kdDomElemSvc.createElement(loaderWrapper, 'kdx-loader-text-wrapper');
        let newLoadingText = this._kdDomElemSvc.createElement(loaderTextWrapper, 'kdx-loader-text-loading', 'div');
        newLoadingText.innerHTML = loadingText + '0%';
        if (this.message) {
            let newMessage = this._kdDomElemSvc.createElement(loaderTextWrapper, 'loader-new-message', 'p');
            newMessage.innerHTML = this.message;
        }
        let thisIntervalId = setInterval(() => {
            if (this.value <= 100) {
                newLoadingText.innerHTML = (loadingText + this.value + '%').trim();
                // newLoadingPercent.innerHTML = this.value + '%';
            }
            else {
                clearInterval(thisIntervalId);
            }
        }, 500);
    }
}
KdProgressloader.decorators = [
    { type: Component, args: [{
                selector: 'kd-progressloader',
                encapsulation: ViewEncapsulation.None,
                template: `
        <div [ngSwitch]="type">

            <div *ngSwitchCase = "'progressbar'" class="progressbar-wrapper">
                <div class="progress-bar" [style.width.%]="value"></div>
            </div>

            <div *ngSwitchCase="'small-spinner'" class="kdx-load-page kdx-small-spinner">
                <div class="kdx-loader-wrapper">
                    <div class="kdx-loader-container">
                        <div class="kdx-loader kdx-rotating"></div>
                        <span  *ngIf="value !== null" class="kdx-loader-spinner-center-text">{{value}}%</span>
                    </div>
                    <div class="kdx-loader-text-wrapper">
                        <div class="kdx-loader-text-loading">Loading...</div>
                    </div>
                </div>
            </div>
        </div>
    `,
                providers: [KdDomElemSvc],
                host: { 'class': 'kdx-progressloader' }
            },] }
];
KdProgressloader.ctorParameters = () => [
    { type: KdDomElemSvc }
];
KdProgressloader.propDecorators = {
    configtype: [{ type: Input }],
    configvalue: [{ type: Input }],
    configmessage: [{ type: Input }]
};
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoia2QtYW5ndWxhci1wcm9ncmVzc2xvYWRlci5qcyIsInNvdXJjZVJvb3QiOiJEOi9vcGVuRU1JUy9zdHlsZWd1aWRlL2lvc3RnLW9wZW5lbWlzLXN0eWxlZ3VpZGUvcHJvamVjdHMvb3BlbmVtaXMtc3R5bGVndWlkZS1saWIvc3JjLyIsInNvdXJjZXMiOlsia2QtY29tcG9uZW50cy9rZC1hbmd1bGFyLXByb2dyZXNzbG9hZGVyL2tkLWFuZ3VsYXItcHJvZ3Jlc3Nsb2FkZXIudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsT0FBTyxFQUNILFNBQVMsRUFDVCxpQkFBaUIsRUFDakIsS0FBSyxFQUVSLE1BQU0sZUFBZSxDQUFDO0FBRXZCLE9BQU8sRUFBRSxZQUFZLEVBQUUsTUFBTSxvQkFBb0IsQ0FBQztBQTZCbEQsTUFBTSxPQUFPLGdCQUFnQjtJQVN6QixZQUNZLGFBQTJCO1FBQTNCLGtCQUFhLEdBQWIsYUFBYSxDQUFjO0lBQ25DLENBQUM7SUFFTCxRQUFRO1FBQ0osSUFBSSxDQUFDLGNBQWMsRUFBRSxDQUFDO1FBQ3RCLDJCQUEyQjtJQUMvQixDQUFDO0lBRUQsV0FBVztRQUNQLDJCQUEyQjtRQUMzQixpQ0FBaUM7UUFFakMsSUFBSSxDQUFDLEtBQUssR0FBRyxJQUFJLENBQUMsV0FBVyxDQUFDO1FBRTlCLElBQUksSUFBSSxDQUFDLEtBQUssSUFBSSxHQUFHLEVBQUU7WUFDbkIsSUFBSSxDQUFDLEtBQUssR0FBRyxHQUFHLENBQUM7U0FDcEI7SUFDTCxDQUFDO0lBRU8sY0FBYztRQUNsQixJQUFJLENBQUMsT0FBTyxHQUFHLENBQUMsT0FBTyxJQUFJLENBQUMsYUFBYSxLQUFLLFdBQVcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsYUFBYSxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUM7UUFDckYsSUFBSSxDQUFDLEtBQUssR0FBRyxDQUFDLE9BQU8sSUFBSSxDQUFDLFdBQVcsS0FBSyxXQUFXLElBQUksSUFBSSxDQUFDLFdBQVcsS0FBSyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDO1FBRTlHLElBQUksT0FBTyxJQUFJLENBQUMsVUFBVSxLQUFLLFdBQVcsRUFBRTtZQUN4QyxJQUFJLENBQUMsSUFBSSxHQUFHLElBQUksQ0FBQyxVQUFVLENBQUM7WUFFNUIsSUFBSSxJQUFJLENBQUMsSUFBSSxLQUFLLGtCQUFrQixFQUFFO2dCQUNsQyxJQUFJLENBQUMsY0FBYyxFQUFFLENBQUM7YUFDekI7U0FFSjthQUFNO1lBQ0gsSUFBSSxDQUFDLElBQUksR0FBRyxhQUFhLENBQUM7U0FDN0I7SUFDTCxDQUFDO0lBRU8sY0FBYztRQUNsQixJQUFJLFdBQVcsR0FBRyxZQUFZLENBQUM7UUFDL0IsSUFBSSxJQUFJLEdBQUcsUUFBUSxDQUFDLElBQUksQ0FBQztRQUN6QixJQUFJLE1BQU0sR0FBRyxJQUFJLENBQUMsYUFBYSxDQUFDLGFBQWEsQ0FBQyxJQUFJLEVBQUUsZUFBZSxDQUFDLENBQUM7UUFDckUsSUFBSSxhQUFhLEdBQUcsSUFBSSxDQUFDLGFBQWEsQ0FBQyxhQUFhLENBQUMsTUFBTSxFQUFFLG9CQUFvQixDQUFDLENBQUM7UUFFbkYsSUFBSSxtQkFBbUIsR0FBRyxJQUFJLENBQUMsYUFBYSxDQUFDLGFBQWEsQ0FBQyxhQUFhLEVBQUUsc0JBQXNCLENBQUMsQ0FBQztRQUNsRyxJQUFJLENBQUMsYUFBYSxDQUFDLGFBQWEsQ0FBQyxtQkFBbUIsRUFBRSx5QkFBeUIsQ0FBQyxDQUFDO1FBQ2pGLElBQUksQ0FBQyxhQUFhLENBQUMsYUFBYSxDQUFDLG1CQUFtQixFQUFFLDhCQUE4QixFQUFFLEdBQUcsQ0FBQyxDQUFDO1FBRTNGLElBQUksaUJBQWlCLEdBQUcsSUFBSSxDQUFDLGFBQWEsQ0FBQyxhQUFhLENBQUMsYUFBYSxFQUFFLHlCQUF5QixDQUFDLENBQUM7UUFDbkcsSUFBSSxjQUFjLEdBQUcsSUFBSSxDQUFDLGFBQWEsQ0FBQyxhQUFhLENBQUMsaUJBQWlCLEVBQUUseUJBQXlCLEVBQUUsS0FBSyxDQUFDLENBQUM7UUFDM0csY0FBYyxDQUFDLFNBQVMsR0FBRyxXQUFXLEdBQUcsSUFBSSxDQUFDO1FBRTlDLElBQUksSUFBSSxDQUFDLE9BQU8sRUFBRTtZQUNkLElBQUksVUFBVSxHQUFHLElBQUksQ0FBQyxhQUFhLENBQUMsYUFBYSxDQUFDLGlCQUFpQixFQUFFLG9CQUFvQixFQUFFLEdBQUcsQ0FBQyxDQUFDO1lBQ2hHLFVBQVUsQ0FBQyxTQUFTLEdBQUcsSUFBSSxDQUFDLE9BQU8sQ0FBQztTQUN2QztRQUVELElBQUksY0FBYyxHQUFHLFdBQVcsQ0FBQyxHQUFTLEVBQUU7WUFDeEMsSUFBSSxJQUFJLENBQUMsS0FBSyxJQUFJLEdBQUcsRUFBRTtnQkFDbkIsY0FBYyxDQUFDLFNBQVMsR0FBRyxDQUFDLFdBQVcsR0FBRyxJQUFJLENBQUMsS0FBSyxHQUFHLEdBQUcsQ0FBQyxDQUFDLElBQUksRUFBRSxDQUFDO2dCQUNuRSxrREFBa0Q7YUFDckQ7aUJBQU07Z0JBQ0gsYUFBYSxDQUFDLGNBQWMsQ0FBQyxDQUFDO2FBQ2pDO1FBQ0wsQ0FBQyxFQUFFLEdBQUcsQ0FBQyxDQUFDO0lBQ1osQ0FBQzs7O1lBbkdKLFNBQVMsU0FBQztnQkFDUCxRQUFRLEVBQUUsbUJBQW1CO2dCQUM3QixhQUFhLEVBQUUsaUJBQWlCLENBQUMsSUFBSTtnQkFDckMsUUFBUSxFQUFFOzs7Ozs7Ozs7Ozs7Ozs7Ozs7O0tBbUJUO2dCQUNELFNBQVMsRUFBRSxDQUFDLFlBQVksQ0FBQztnQkFDekIsSUFBSSxFQUFHLEVBQUUsT0FBTyxFQUFHLG9CQUFvQixFQUFFO2FBQzVDOzs7WUEzQlEsWUFBWTs7O3lCQWtDaEIsS0FBSzswQkFDTCxLQUFLOzRCQUNMLEtBQUsiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQge1xyXG4gICAgQ29tcG9uZW50LFxyXG4gICAgVmlld0VuY2Fwc3VsYXRpb24sXHJcbiAgICBJbnB1dCxcclxuICAgIE9uSW5pdFxyXG59IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xyXG5cclxuaW1wb3J0IHsgS2REb21FbGVtU3ZjIH0gZnJvbSAnLi4va2QtY29tbW9uL2luZGV4JztcclxuXHJcbkBDb21wb25lbnQoe1xyXG4gICAgc2VsZWN0b3I6ICdrZC1wcm9ncmVzc2xvYWRlcicsXHJcbiAgICBlbmNhcHN1bGF0aW9uOiBWaWV3RW5jYXBzdWxhdGlvbi5Ob25lLFxyXG4gICAgdGVtcGxhdGU6IGBcclxuICAgICAgICA8ZGl2IFtuZ1N3aXRjaF09XCJ0eXBlXCI+XHJcblxyXG4gICAgICAgICAgICA8ZGl2ICpuZ1N3aXRjaENhc2UgPSBcIidwcm9ncmVzc2JhcidcIiBjbGFzcz1cInByb2dyZXNzYmFyLXdyYXBwZXJcIj5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJwcm9ncmVzcy1iYXJcIiBbc3R5bGUud2lkdGguJV09XCJ2YWx1ZVwiPjwvZGl2PlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgIDxkaXYgKm5nU3dpdGNoQ2FzZT1cIidzbWFsbC1zcGlubmVyJ1wiIGNsYXNzPVwia2R4LWxvYWQtcGFnZSBrZHgtc21hbGwtc3Bpbm5lclwiPlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cImtkeC1sb2FkZXItd3JhcHBlclwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJrZHgtbG9hZGVyLWNvbnRhaW5lclwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwia2R4LWxvYWRlciBrZHgtcm90YXRpbmdcIj48L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gICpuZ0lmPVwidmFsdWUgIT09IG51bGxcIiBjbGFzcz1cImtkeC1sb2FkZXItc3Bpbm5lci1jZW50ZXItdGV4dFwiPnt7dmFsdWV9fSU8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cImtkeC1sb2FkZXItdGV4dC13cmFwcGVyXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJrZHgtbG9hZGVyLXRleHQtbG9hZGluZ1wiPkxvYWRpbmcuLi48L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8L2Rpdj5cclxuICAgIGAsXHJcbiAgICBwcm92aWRlcnM6IFtLZERvbUVsZW1TdmNdLFxyXG4gICAgaG9zdCA6IHsgJ2NsYXNzJyA6ICdrZHgtcHJvZ3Jlc3Nsb2FkZXInIH1cclxufSlcclxuXHJcbmV4cG9ydCBjbGFzcyBLZFByb2dyZXNzbG9hZGVyIGltcGxlbWVudHMgT25Jbml0IHtcclxuICAgIHB1YmxpYyB0eXBlOiBzdHJpbmc7XHJcbiAgICBwdWJsaWMgdmFsdWU6IG51bWJlcjtcclxuICAgIHByaXZhdGUgbWVzc2FnZTogc3RyaW5nO1xyXG5cclxuICAgIEBJbnB1dCgpIGNvbmZpZ3R5cGU6IHN0cmluZztcclxuICAgIEBJbnB1dCgpIGNvbmZpZ3ZhbHVlOiBudW1iZXI7XHJcbiAgICBASW5wdXQoKSBjb25maWdtZXNzYWdlOiBzdHJpbmc7XHJcblxyXG4gICAgY29uc3RydWN0b3IoXHJcbiAgICAgICAgcHJpdmF0ZSBfa2REb21FbGVtU3ZjOiBLZERvbUVsZW1TdmNcclxuICAgICkgeyB9XHJcblxyXG4gICAgbmdPbkluaXQoKTogdm9pZCB7XHJcbiAgICAgICAgdGhpcy5jb25maWdEZWZhdWx0cygpO1xyXG4gICAgICAgIC8vIGNvbnNvbGUubG9nKHRoaXMudmFsdWUpO1xyXG4gICAgfVxyXG5cclxuICAgIG5nT25DaGFuZ2VzKCk6IHZvaWQge1xyXG4gICAgICAgIC8vIGNvbnNvbGUubG9nKHRoaXMudmFsdWUpO1xyXG4gICAgICAgIC8vIGNvbnNvbGUubG9nKHRoaXMuY29uZmlndmFsdWUpO1xyXG5cclxuICAgICAgICB0aGlzLnZhbHVlID0gdGhpcy5jb25maWd2YWx1ZTtcclxuXHJcbiAgICAgICAgaWYgKHRoaXMudmFsdWUgPj0gMTAwKSB7XHJcbiAgICAgICAgICAgIHRoaXMudmFsdWUgPSAxMDA7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgY29uZmlnRGVmYXVsdHMoKSB7XHJcbiAgICAgICAgdGhpcy5tZXNzYWdlID0gKHR5cGVvZiB0aGlzLmNvbmZpZ21lc3NhZ2UgIT09ICd1bmRlZmluZWQnKSA/IHRoaXMuY29uZmlnbWVzc2FnZSA6ICcnO1xyXG4gICAgICAgIHRoaXMudmFsdWUgPSAodHlwZW9mIHRoaXMuY29uZmlndmFsdWUgIT09ICd1bmRlZmluZWQnIHx8IHRoaXMuY29uZmlndmFsdWUgIT09IG51bGwpID8gdGhpcy5jb25maWd2YWx1ZSA6IG51bGw7XHJcblxyXG4gICAgICAgIGlmICh0eXBlb2YgdGhpcy5jb25maWd0eXBlICE9PSAndW5kZWZpbmVkJykge1xyXG4gICAgICAgICAgICB0aGlzLnR5cGUgPSB0aGlzLmNvbmZpZ3R5cGU7XHJcblxyXG4gICAgICAgICAgICBpZiAodGhpcy50eXBlID09PSAnd2hvbGVwYWdlc3Bpbm5lcicpIHtcclxuICAgICAgICAgICAgICAgIHRoaXMuY3JlYXRlTG9hZHBhZ2UoKTtcclxuICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICB0aGlzLnR5cGUgPSAncHJvZ3Jlc3NiYXInO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIGNyZWF0ZUxvYWRwYWdlKCkge1xyXG4gICAgICAgIGxldCBsb2FkaW5nVGV4dCA9ICdMb2FkaW5nLi4uJztcclxuICAgICAgICBsZXQgYm9keSA9IGRvY3VtZW50LmJvZHk7XHJcbiAgICAgICAgbGV0IG5ld0RpdiA9IHRoaXMuX2tkRG9tRWxlbVN2Yy5jcmVhdGVFbGVtZW50KGJvZHksICdrZHgtbG9hZC1wYWdlJyk7XHJcbiAgICAgICAgbGV0IGxvYWRlcldyYXBwZXIgPSB0aGlzLl9rZERvbUVsZW1TdmMuY3JlYXRlRWxlbWVudChuZXdEaXYsICdrZHgtbG9hZGVyLXdyYXBwZXInKTtcclxuXHJcbiAgICAgICAgbGV0IG5ld1NwaW5uZXJDb250YWluZXIgPSB0aGlzLl9rZERvbUVsZW1TdmMuY3JlYXRlRWxlbWVudChsb2FkZXJXcmFwcGVyLCAna2R4LWxvYWRlci1jb250YWluZXInKTtcclxuICAgICAgICB0aGlzLl9rZERvbUVsZW1TdmMuY3JlYXRlRWxlbWVudChuZXdTcGlubmVyQ29udGFpbmVyLCAna2R4LWxvYWRlciBrZHgtcm90YXRpbmcnKTtcclxuICAgICAgICB0aGlzLl9rZERvbUVsZW1TdmMuY3JlYXRlRWxlbWVudChuZXdTcGlubmVyQ29udGFpbmVyLCAnZmEga2Qtb3BlbmVtaXMgb3BlbmVtaXMtaWNvbicsICdpJyk7XHJcblxyXG4gICAgICAgIGxldCBsb2FkZXJUZXh0V3JhcHBlciA9IHRoaXMuX2tkRG9tRWxlbVN2Yy5jcmVhdGVFbGVtZW50KGxvYWRlcldyYXBwZXIsICdrZHgtbG9hZGVyLXRleHQtd3JhcHBlcicpO1xyXG4gICAgICAgIGxldCBuZXdMb2FkaW5nVGV4dCA9IHRoaXMuX2tkRG9tRWxlbVN2Yy5jcmVhdGVFbGVtZW50KGxvYWRlclRleHRXcmFwcGVyLCAna2R4LWxvYWRlci10ZXh0LWxvYWRpbmcnLCAnZGl2Jyk7XHJcbiAgICAgICAgbmV3TG9hZGluZ1RleHQuaW5uZXJIVE1MID0gbG9hZGluZ1RleHQgKyAnMCUnO1xyXG5cclxuICAgICAgICBpZiAodGhpcy5tZXNzYWdlKSB7XHJcbiAgICAgICAgICAgIGxldCBuZXdNZXNzYWdlID0gdGhpcy5fa2REb21FbGVtU3ZjLmNyZWF0ZUVsZW1lbnQobG9hZGVyVGV4dFdyYXBwZXIsICdsb2FkZXItbmV3LW1lc3NhZ2UnLCAncCcpO1xyXG4gICAgICAgICAgICBuZXdNZXNzYWdlLmlubmVySFRNTCA9IHRoaXMubWVzc2FnZTtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIGxldCB0aGlzSW50ZXJ2YWxJZCA9IHNldEludGVydmFsKCgpOiB2b2lkID0+IHtcclxuICAgICAgICAgICAgaWYgKHRoaXMudmFsdWUgPD0gMTAwKSB7XHJcbiAgICAgICAgICAgICAgICBuZXdMb2FkaW5nVGV4dC5pbm5lckhUTUwgPSAobG9hZGluZ1RleHQgKyB0aGlzLnZhbHVlICsgJyUnKS50cmltKCk7XHJcbiAgICAgICAgICAgICAgICAvLyBuZXdMb2FkaW5nUGVyY2VudC5pbm5lckhUTUwgPSB0aGlzLnZhbHVlICsgJyUnO1xyXG4gICAgICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgY2xlYXJJbnRlcnZhbCh0aGlzSW50ZXJ2YWxJZCk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9LCA1MDApO1xyXG4gICAgfVxyXG59XHJcbiJdfQ==