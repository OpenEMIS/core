import { Component, ViewEncapsulation, ViewChild, Input, ElementRef, Renderer2, HostListener, } from '@angular/core';
import { UIChart } from 'primeng/chart';
import { KdMiniDashboardSvc } from './kd-angular-mini-dashboard-svc';
import { KdSplitterEvent } from '../kd-angular-splitter/index';
export class KdMiniDashboardChart {
    constructor(_kdMiniDashboardSvc, _elementRef, _renderer, _kdSplitterEvent) {
        this._kdMiniDashboardSvc = _kdMiniDashboardSvc;
        this._elementRef = _elementRef;
        this._renderer = _renderer;
        this.threeItemLegend = false;
        this.placement = 'bottom-left';
        this._isWidthChanged = { legend: false, canvas: false };
        this._isFirstLoad = true;
        this._pChartsFunction = _kdMiniDashboardSvc.pcharts(_elementRef, _renderer);
        _kdSplitterEvent.onDrag().subscribe(_type => {
            this._pChartsFunction.setTooltipPlacementFlag(true);
        });
        _kdSplitterEvent.onToggleMenu().subscribe(_type => {
            this._pChartsFunction.setTooltipPlacementFlag(true);
        });
    }
    onResize(event) {
        this._pChartsFunction.setTooltipPlacementFlag(true);
        this._pChartsFunction.processTooltipToCanvasSize(this._canvas, this.chart);
        if (this.itemLength === 3) {
            this._resizeLegend();
            this._resizeCanvas();
        }
    }
    ngOnInit() {
        this._isFirstLoad = false;
        this._tooltipElement = this.tooltip._elementRef.nativeElement;
        this._chartLegendElement = this.chartLegend.nativeElement;
    }
    ngOnChanges(_simpleChanges) {
        if (_simpleChanges.hasOwnProperty('itemLength') && _simpleChanges.itemLength.currentValue === 3) {
            this._resizeLegend();
        }
        if (!this._isFirstLoad && this.itemLength === 3)
            this._resizeCanvas();
        if (_simpleChanges.hasOwnProperty('direction') && this.direction === 'right')
            this.placement = 'bottom-right';
    }
    ngAfterViewInit() {
        this._canvas = this.chart.getCanvas();
        this._pChartElement = this._elementRef.nativeElement.querySelector('.kdx-mini-dashboard .kdx-mini-dashboard-chart p-chart');
        if (this.itemLength === 3)
            this._resizeCanvas();
        this._setLegend();
        this._pChartsFunction.processTooltipToCanvasSize(this._canvas, this.chart);
    }
    ngOnDestroy() {
        this._kdMiniDashboardSvc.removeChildren(this._chartLegendElement);
    }
    _setLegend() {
        if (!this.isLegendDisplayed)
            return;
        this._chartLegendElement.innerHTML = this.chart.chart.generateLegend() || '';
        this._setLegendLabelElement();
        this._pChartsFunction.attachLegendListener(this._legendLabelElement, { uiChart: this.chart, legendElement: this._chartLegendElement }, { method: this.tooltip, element: this._tooltipElement }, this.direction);
    }
    _setLegendLabelElement() {
        this._legendLabelElement = this._elementRef.nativeElement.querySelectorAll('.kdx-mini-dashboard .kdx-elem-item .chart-legend ul li .chart-legend-label');
    }
    _resizeLegend() {
        if (480 < window.innerWidth && window.innerWidth < 650) {
            if (this._isWidthChanged.legend === false) {
                this.threeItemLegend = true;
                this._isWidthChanged.legend = true;
            }
        }
        else {
            if (this._isWidthChanged.legend === true) {
                this.threeItemLegend = false;
                this._isWidthChanged.legend = false;
            }
        }
    }
    _resizeCanvas() {
        if (480 < window.innerWidth && window.innerWidth < 650) {
            if (this._isWidthChanged.canvas === false) {
                this._pChartsFunction.setCanvasStyle('80', this._canvas);
                this._isWidthChanged.canvas = true;
                this._renderer.setStyle(this._pChartElement, 'width', '80px');
                this._renderer.setStyle(this._pChartElement, 'height', '80px');
            }
        }
        else if (window.innerWidth > 650 || window.innerWidth === 650) {
            if (this._isWidthChanged.canvas === true) {
                this._pChartsFunction.setCanvasStyle('100', this._canvas);
                this._isWidthChanged.canvas = false;
                this._renderer.setStyle(this._pChartElement, 'width', '100px');
                this._renderer.setStyle(this._pChartElement, 'height', '100px');
            }
        }
    }
}
KdMiniDashboardChart.decorators = [
    { type: Component, args: [{
                selector: 'kd-mini-dashboard-chart',
                template: `
        <div class="kdx-elem-item">
            <p-chart class="chart-main" type="doughnut" [data]="data" [options]="options" ></p-chart>
            <div class="chart-legend"
                 #chartLegend
                 [attr.kd-mini-dashboard-chart-index]="data.chartIndex"
                 [ngClass]="{'three-item-chart-legend' : threeItemLegend }">
            </div>
            <div class="kdx-mini-dashboard-tooltip" [placement]="placement" ngbTooltip="" triggers="manual" #t="ngbTooltip"></div>
        </div>`,
                encapsulation: ViewEncapsulation.None,
                providers: [KdMiniDashboardSvc],
                host: { class: 'kdx-mini-dashboard-chart' }
            },] }
];
KdMiniDashboardChart.ctorParameters = () => [
    { type: KdMiniDashboardSvc },
    { type: ElementRef },
    { type: Renderer2 },
    { type: KdSplitterEvent }
];
KdMiniDashboardChart.propDecorators = {
    data: [{ type: Input }],
    options: [{ type: Input }],
    isLegendDisplayed: [{ type: Input }],
    itemLength: [{ type: Input }],
    direction: [{ type: Input }],
    chart: [{ type: ViewChild, args: [UIChart, { static: true },] }],
    tooltip: [{ type: ViewChild, args: ['t', { static: true },] }],
    chartLegend: [{ type: ViewChild, args: ['chartLegend', { static: true },] }],
    onResize: [{ type: HostListener, args: ['window:resize', ['$event'],] }]
};
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoia2QtYW5ndWxhci1taW5pLWRhc2hib2FyZC1jaGFydC5qcyIsInNvdXJjZVJvb3QiOiJEOi9vcGVuRU1JUy9zdHlsZWd1aWRlL2lvc3RnLW9wZW5lbWlzLXN0eWxlZ3VpZGUvcHJvamVjdHMvb3BlbmVtaXMtc3R5bGVndWlkZS1saWIvc3JjLyIsInNvdXJjZXMiOlsia2QtY29tcG9uZW50cy9rZC1hbmd1bGFyLW1pbmktZGFzaGJvYXJkL2tkLWFuZ3VsYXItbWluaS1kYXNoYm9hcmQtY2hhcnQudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsT0FBTyxFQUNILFNBQVMsRUFDVCxpQkFBaUIsRUFDakIsU0FBUyxFQUNULEtBQUssRUFNTCxVQUFVLEVBQ1YsU0FBUyxFQUNULFlBQVksR0FDZixNQUFNLGVBQWUsQ0FBQztBQUN2QixPQUFPLEVBQUUsT0FBTyxFQUFFLE1BQU0sZUFBZSxDQUFDO0FBRXhDLE9BQU8sRUFBRSxrQkFBa0IsRUFBRSxNQUFNLGlDQUFpQyxDQUFDO0FBQ3JFLE9BQU8sRUFBRSxlQUFlLEVBQUUsTUFBTSw4QkFBOEIsQ0FBQztBQW1CL0QsTUFBTSxPQUFPLG9CQUFvQjtJQXVCN0IsWUFDWSxtQkFBdUMsRUFDdkMsV0FBdUIsRUFDdkIsU0FBb0IsRUFDNUIsZ0JBQWlDO1FBSHpCLHdCQUFtQixHQUFuQixtQkFBbUIsQ0FBb0I7UUFDdkMsZ0JBQVcsR0FBWCxXQUFXLENBQVk7UUFDdkIsY0FBUyxHQUFULFNBQVMsQ0FBVztRQXpCekIsb0JBQWUsR0FBWSxLQUFLLENBQUM7UUFDakMsY0FBUyxHQUFXLGFBQWEsQ0FBQztRQU9qQyxvQkFBZSxHQUF5QyxFQUFFLE1BQU0sRUFBRSxLQUFLLEVBQUUsTUFBTSxFQUFFLEtBQUssRUFBRSxDQUFDO1FBQ3pGLGlCQUFZLEdBQVksSUFBSSxDQUFDO1FBbUJqQyxJQUFJLENBQUMsZ0JBQWdCLEdBQUcsbUJBQW1CLENBQUMsT0FBTyxDQUFDLFdBQVcsRUFBRSxTQUFTLENBQUMsQ0FBQztRQUM1RSxnQkFBZ0IsQ0FBQyxNQUFNLEVBQUUsQ0FBQyxTQUFTLENBQUMsS0FBSyxDQUFDLEVBQUU7WUFDeEMsSUFBSSxDQUFDLGdCQUFnQixDQUFDLHVCQUF1QixDQUFDLElBQUksQ0FBQyxDQUFDO1FBQ3hELENBQUMsQ0FBQyxDQUFDO1FBQ0gsZ0JBQWdCLENBQUMsWUFBWSxFQUFFLENBQUMsU0FBUyxDQUFDLEtBQUssQ0FBQyxFQUFFO1lBQzlDLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyx1QkFBdUIsQ0FBQyxJQUFJLENBQUMsQ0FBQztRQUN4RCxDQUFDLENBQUMsQ0FBQztJQUNQLENBQUM7SUFHRCxRQUFRLENBQUMsS0FBVTtRQUNmLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyx1QkFBdUIsQ0FBQyxJQUFJLENBQUMsQ0FBQztRQUNwRCxJQUFJLENBQUMsZ0JBQWdCLENBQUMsMEJBQTBCLENBQUMsSUFBSSxDQUFDLE9BQU8sRUFBRSxJQUFJLENBQUMsS0FBSyxDQUFDLENBQUM7UUFDM0UsSUFBSSxJQUFJLENBQUMsVUFBVSxLQUFLLENBQUMsRUFBRTtZQUN2QixJQUFJLENBQUMsYUFBYSxFQUFFLENBQUM7WUFDckIsSUFBSSxDQUFDLGFBQWEsRUFBRSxDQUFDO1NBQ3hCO0lBQ0wsQ0FBQztJQUVELFFBQVE7UUFDSixJQUFJLENBQUMsWUFBWSxHQUFHLEtBQUssQ0FBQztRQUMxQixJQUFJLENBQUMsZUFBZSxHQUFHLElBQUksQ0FBQyxPQUFPLENBQUMsV0FBVyxDQUFDLGFBQWEsQ0FBQztRQUM5RCxJQUFJLENBQUMsbUJBQW1CLEdBQUcsSUFBSSxDQUFDLFdBQVcsQ0FBQyxhQUFhLENBQUM7SUFDOUQsQ0FBQztJQUVELFdBQVcsQ0FBQyxjQUE2QjtRQUNyQyxJQUFJLGNBQWMsQ0FBQyxjQUFjLENBQUMsWUFBWSxDQUFDLElBQUksY0FBYyxDQUFDLFVBQVUsQ0FBQyxZQUFZLEtBQUssQ0FBQyxFQUFFO1lBQzdGLElBQUksQ0FBQyxhQUFhLEVBQUUsQ0FBQztTQUN4QjtRQUNELElBQUksQ0FBQyxJQUFJLENBQUMsWUFBWSxJQUFJLElBQUksQ0FBQyxVQUFVLEtBQUssQ0FBQztZQUFFLElBQUksQ0FBQyxhQUFhLEVBQUUsQ0FBQztRQUN0RSxJQUFJLGNBQWMsQ0FBQyxjQUFjLENBQUMsV0FBVyxDQUFDLElBQUksSUFBSSxDQUFDLFNBQVMsS0FBSyxPQUFPO1lBQUUsSUFBSSxDQUFDLFNBQVMsR0FBRyxjQUFjLENBQUM7SUFDbEgsQ0FBQztJQUVELGVBQWU7UUFDWCxJQUFJLENBQUMsT0FBTyxHQUFHLElBQUksQ0FBQyxLQUFLLENBQUMsU0FBUyxFQUFFLENBQUM7UUFDdEMsSUFBSSxDQUFDLGNBQWMsR0FBRyxJQUFJLENBQUMsV0FBVyxDQUFDLGFBQWEsQ0FBQyxhQUFhLENBQUMsdURBQXVELENBQUMsQ0FBQztRQUM1SCxJQUFJLElBQUksQ0FBQyxVQUFVLEtBQUssQ0FBQztZQUFFLElBQUksQ0FBQyxhQUFhLEVBQUUsQ0FBQztRQUNoRCxJQUFJLENBQUMsVUFBVSxFQUFFLENBQUM7UUFDbEIsSUFBSSxDQUFDLGdCQUFnQixDQUFDLDBCQUEwQixDQUFDLElBQUksQ0FBQyxPQUFPLEVBQUUsSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFDO0lBQy9FLENBQUM7SUFFRCxXQUFXO1FBQ1AsSUFBSSxDQUFDLG1CQUFtQixDQUFDLGNBQWMsQ0FBQyxJQUFJLENBQUMsbUJBQW1CLENBQUMsQ0FBQztJQUN0RSxDQUFDO0lBRU8sVUFBVTtRQUNkLElBQUksQ0FBQyxJQUFJLENBQUMsaUJBQWlCO1lBQUUsT0FBTztRQUNwQyxJQUFJLENBQUMsbUJBQW1CLENBQUMsU0FBUyxHQUFHLElBQUksQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLGNBQWMsRUFBRSxJQUFJLEVBQUUsQ0FBQztRQUM3RSxJQUFJLENBQUMsc0JBQXNCLEVBQUUsQ0FBQztRQUM5QixJQUFJLENBQUMsZ0JBQWdCLENBQUMsb0JBQW9CLENBQ3RDLElBQUksQ0FBQyxtQkFBbUIsRUFDeEIsRUFBRSxPQUFPLEVBQUUsSUFBSSxDQUFDLEtBQUssRUFBRSxhQUFhLEVBQUUsSUFBSSxDQUFDLG1CQUFtQixFQUFFLEVBQ2hFLEVBQUUsTUFBTSxFQUFFLElBQUksQ0FBQyxPQUFPLEVBQUUsT0FBTyxFQUFFLElBQUksQ0FBQyxlQUFlLEVBQUUsRUFDdkQsSUFBSSxDQUFDLFNBQVMsQ0FDakIsQ0FBQztJQUNOLENBQUM7SUFFTyxzQkFBc0I7UUFDMUIsSUFBSSxDQUFDLG1CQUFtQixHQUFHLElBQUksQ0FBQyxXQUFXLENBQUMsYUFBYSxDQUFDLGdCQUFnQixDQUFDLDRFQUE0RSxDQUFDLENBQUM7SUFDN0osQ0FBQztJQUVPLGFBQWE7UUFDakIsSUFBSSxHQUFHLEdBQUcsTUFBTSxDQUFDLFVBQVUsSUFBSSxNQUFNLENBQUMsVUFBVSxHQUFHLEdBQUcsRUFBRTtZQUNwRCxJQUFJLElBQUksQ0FBQyxlQUFlLENBQUMsTUFBTSxLQUFLLEtBQUssRUFBRTtnQkFDdkMsSUFBSSxDQUFDLGVBQWUsR0FBRyxJQUFJLENBQUM7Z0JBQzVCLElBQUksQ0FBQyxlQUFlLENBQUMsTUFBTSxHQUFHLElBQUksQ0FBQzthQUN0QztTQUNKO2FBQU07WUFDSCxJQUFJLElBQUksQ0FBQyxlQUFlLENBQUMsTUFBTSxLQUFLLElBQUksRUFBRTtnQkFDdEMsSUFBSSxDQUFDLGVBQWUsR0FBRyxLQUFLLENBQUM7Z0JBQzdCLElBQUksQ0FBQyxlQUFlLENBQUMsTUFBTSxHQUFHLEtBQUssQ0FBQzthQUN2QztTQUNKO0lBQ0wsQ0FBQztJQUVPLGFBQWE7UUFDakIsSUFBSSxHQUFHLEdBQUcsTUFBTSxDQUFDLFVBQVUsSUFBSSxNQUFNLENBQUMsVUFBVSxHQUFHLEdBQUcsRUFBRTtZQUNwRCxJQUFJLElBQUksQ0FBQyxlQUFlLENBQUMsTUFBTSxLQUFLLEtBQUssRUFBRTtnQkFDdkMsSUFBSSxDQUFDLGdCQUFnQixDQUFDLGNBQWMsQ0FBQyxJQUFJLEVBQUUsSUFBSSxDQUFDLE9BQU8sQ0FBQyxDQUFDO2dCQUN6RCxJQUFJLENBQUMsZUFBZSxDQUFDLE1BQU0sR0FBRyxJQUFJLENBQUM7Z0JBQ25DLElBQUksQ0FBQyxTQUFTLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxjQUFjLEVBQUUsT0FBTyxFQUFFLE1BQU0sQ0FBQyxDQUFDO2dCQUM5RCxJQUFJLENBQUMsU0FBUyxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsY0FBYyxFQUFFLFFBQVEsRUFBRSxNQUFNLENBQUMsQ0FBQzthQUNsRTtTQUNKO2FBQU0sSUFBSSxNQUFNLENBQUMsVUFBVSxHQUFHLEdBQUcsSUFBSSxNQUFNLENBQUMsVUFBVSxLQUFLLEdBQUcsRUFBRTtZQUM3RCxJQUFJLElBQUksQ0FBQyxlQUFlLENBQUMsTUFBTSxLQUFLLElBQUksRUFBRTtnQkFDdEMsSUFBSSxDQUFDLGdCQUFnQixDQUFDLGNBQWMsQ0FBQyxLQUFLLEVBQUUsSUFBSSxDQUFDLE9BQU8sQ0FBQyxDQUFDO2dCQUMxRCxJQUFJLENBQUMsZUFBZSxDQUFDLE1BQU0sR0FBRyxLQUFLLENBQUM7Z0JBQ3BDLElBQUksQ0FBQyxTQUFTLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxjQUFjLEVBQUUsT0FBTyxFQUFFLE9BQU8sQ0FBQyxDQUFDO2dCQUMvRCxJQUFJLENBQUMsU0FBUyxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsY0FBYyxFQUFFLFFBQVEsRUFBRSxPQUFPLENBQUMsQ0FBQzthQUNuRTtTQUNKO0lBQ0wsQ0FBQzs7O1lBeklKLFNBQVMsU0FBQztnQkFDUCxRQUFRLEVBQUUseUJBQXlCO2dCQUNuQyxRQUFRLEVBQUU7Ozs7Ozs7OztlQVNDO2dCQUNYLGFBQWEsRUFBRSxpQkFBaUIsQ0FBQyxJQUFJO2dCQUNyQyxTQUFTLEVBQUUsQ0FBQyxrQkFBa0IsQ0FBQztnQkFDL0IsSUFBSSxFQUFFLEVBQUUsS0FBSyxFQUFFLDBCQUEwQixFQUFDO2FBQzdDOzs7WUFsQlEsa0JBQWtCO1lBTnZCLFVBQVU7WUFDVixTQUFTO1lBTUosZUFBZTs7O21CQWdDbkIsS0FBSztzQkFDTCxLQUFLO2dDQUNMLEtBQUs7eUJBQ0wsS0FBSzt3QkFDTCxLQUFLO29CQUVMLFNBQVMsU0FBQyxPQUFPLEVBQUUsRUFBRSxNQUFNLEVBQUUsSUFBSSxFQUFFO3NCQUNuQyxTQUFTLFNBQUMsR0FBRyxFQUFFLEVBQUUsTUFBTSxFQUFFLElBQUksRUFBRTswQkFDL0IsU0FBUyxTQUFDLGFBQWEsRUFBRSxFQUFFLE1BQU0sRUFBRSxJQUFJLEVBQUU7dUJBaUJ6QyxZQUFZLFNBQUMsZUFBZSxFQUFFLENBQUMsUUFBUSxDQUFDIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHtcclxuICAgIENvbXBvbmVudCxcclxuICAgIFZpZXdFbmNhcHN1bGF0aW9uLFxyXG4gICAgVmlld0NoaWxkLFxyXG4gICAgSW5wdXQsXHJcbiAgICBPbkluaXQsXHJcbiAgICBPbkNoYW5nZXMsXHJcbiAgICBTaW1wbGVDaGFuZ2VzLFxyXG4gICAgQWZ0ZXJWaWV3SW5pdCxcclxuICAgIE9uRGVzdHJveSxcclxuICAgIEVsZW1lbnRSZWYsXHJcbiAgICBSZW5kZXJlcjIsXHJcbiAgICBIb3N0TGlzdGVuZXIsXHJcbn0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XHJcbmltcG9ydCB7IFVJQ2hhcnQgfSBmcm9tICdwcmltZW5nL2NoYXJ0JztcclxuaW1wb3J0ICogYXMgdHlwZXMgZnJvbSAnLi9rZC1hbmd1bGFyLW1pbmktZGFzaGJvYXJkLWludGVyZmFjZSc7XHJcbmltcG9ydCB7IEtkTWluaURhc2hib2FyZFN2YyB9IGZyb20gJy4va2QtYW5ndWxhci1taW5pLWRhc2hib2FyZC1zdmMnO1xyXG5pbXBvcnQgeyBLZFNwbGl0dGVyRXZlbnQgfSBmcm9tICcuLi9rZC1hbmd1bGFyLXNwbGl0dGVyL2luZGV4JztcclxuXHJcbkBDb21wb25lbnQoe1xyXG4gICAgc2VsZWN0b3I6ICdrZC1taW5pLWRhc2hib2FyZC1jaGFydCcsXHJcbiAgICB0ZW1wbGF0ZTogYFxyXG4gICAgICAgIDxkaXYgY2xhc3M9XCJrZHgtZWxlbS1pdGVtXCI+XHJcbiAgICAgICAgICAgIDxwLWNoYXJ0IGNsYXNzPVwiY2hhcnQtbWFpblwiIHR5cGU9XCJkb3VnaG51dFwiIFtkYXRhXT1cImRhdGFcIiBbb3B0aW9uc109XCJvcHRpb25zXCIgPjwvcC1jaGFydD5cclxuICAgICAgICAgICAgPGRpdiBjbGFzcz1cImNoYXJ0LWxlZ2VuZFwiXHJcbiAgICAgICAgICAgICAgICAgI2NoYXJ0TGVnZW5kXHJcbiAgICAgICAgICAgICAgICAgW2F0dHIua2QtbWluaS1kYXNoYm9hcmQtY2hhcnQtaW5kZXhdPVwiZGF0YS5jaGFydEluZGV4XCJcclxuICAgICAgICAgICAgICAgICBbbmdDbGFzc109XCJ7J3RocmVlLWl0ZW0tY2hhcnQtbGVnZW5kJyA6IHRocmVlSXRlbUxlZ2VuZCB9XCI+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzPVwia2R4LW1pbmktZGFzaGJvYXJkLXRvb2x0aXBcIiBbcGxhY2VtZW50XT1cInBsYWNlbWVudFwiIG5nYlRvb2x0aXA9XCJcIiB0cmlnZ2Vycz1cIm1hbnVhbFwiICN0PVwibmdiVG9vbHRpcFwiPjwvZGl2PlxyXG4gICAgICAgIDwvZGl2PmAsXHJcbiAgICBlbmNhcHN1bGF0aW9uOiBWaWV3RW5jYXBzdWxhdGlvbi5Ob25lLFxyXG4gICAgcHJvdmlkZXJzOiBbS2RNaW5pRGFzaGJvYXJkU3ZjXSxcclxuICAgIGhvc3Q6IHsgY2xhc3M6ICdrZHgtbWluaS1kYXNoYm9hcmQtY2hhcnQnfVxyXG59KVxyXG5cclxuZXhwb3J0IGNsYXNzIEtkTWluaURhc2hib2FyZENoYXJ0IGltcGxlbWVudHMgT25Jbml0LCBPbkNoYW5nZXMsIEFmdGVyVmlld0luaXQsIE9uRGVzdHJveSB7XHJcbiAgICBwdWJsaWMgdGhyZWVJdGVtTGVnZW5kOiBib29sZWFuID0gZmFsc2U7XHJcbiAgICBwdWJsaWMgcGxhY2VtZW50OiBzdHJpbmcgPSAnYm90dG9tLWxlZnQnO1xyXG5cclxuICAgIHByaXZhdGUgX2NhbnZhczogRWxlbWVudDtcclxuICAgIHByaXZhdGUgX2NoYXJ0TGVnZW5kRWxlbWVudDogRWxlbWVudDtcclxuICAgIHByaXZhdGUgX2xlZ2VuZExhYmVsRWxlbWVudDogRWxlbWVudDtcclxuICAgIHByaXZhdGUgX3Rvb2x0aXBFbGVtZW50OiBFbGVtZW50O1xyXG4gICAgcHJpdmF0ZSBfcENoYXJ0c0Z1bmN0aW9uOiB0eXBlcy5JQ2hhcnRGdW5jdGlvbnM7XHJcbiAgICBwcml2YXRlIF9pc1dpZHRoQ2hhbmdlZDogeyBsZWdlbmQ6IGJvb2xlYW4sIGNhbnZhczogYm9vbGVhbiB9ID0geyBsZWdlbmQ6IGZhbHNlLCBjYW52YXM6IGZhbHNlIH07XHJcbiAgICBwcml2YXRlIF9pc0ZpcnN0TG9hZDogYm9vbGVhbiA9IHRydWU7XHJcbiAgICBwcml2YXRlIF9wQ2hhcnRFbGVtZW50OiBhbnk7XHJcblxyXG4gICAgQElucHV0KCkgZGF0YTogYW55O1xyXG4gICAgQElucHV0KCkgb3B0aW9uczogYW55O1xyXG4gICAgQElucHV0KCkgaXNMZWdlbmREaXNwbGF5ZWQ6IGJvb2xlYW47XHJcbiAgICBASW5wdXQoKSBpdGVtTGVuZ3RoOiBudW1iZXI7XHJcbiAgICBASW5wdXQoKSBkaXJlY3Rpb246IHN0cmluZztcclxuXHJcbiAgICBAVmlld0NoaWxkKFVJQ2hhcnQsIHsgc3RhdGljOiB0cnVlIH0pIGNoYXJ0OiBVSUNoYXJ0O1xyXG4gICAgQFZpZXdDaGlsZCgndCcsIHsgc3RhdGljOiB0cnVlIH0pIHRvb2x0aXA6IGFueTtcclxuICAgIEBWaWV3Q2hpbGQoJ2NoYXJ0TGVnZW5kJywgeyBzdGF0aWM6IHRydWUgfSkgY2hhcnRMZWdlbmQ6IGFueTtcclxuXHJcbiAgICBjb25zdHJ1Y3RvcihcclxuICAgICAgICBwcml2YXRlIF9rZE1pbmlEYXNoYm9hcmRTdmM6IEtkTWluaURhc2hib2FyZFN2YyxcclxuICAgICAgICBwcml2YXRlIF9lbGVtZW50UmVmOiBFbGVtZW50UmVmLFxyXG4gICAgICAgIHByaXZhdGUgX3JlbmRlcmVyOiBSZW5kZXJlcjIsXHJcbiAgICAgICAgX2tkU3BsaXR0ZXJFdmVudDogS2RTcGxpdHRlckV2ZW50XHJcbiAgICApIHtcclxuICAgICAgICB0aGlzLl9wQ2hhcnRzRnVuY3Rpb24gPSBfa2RNaW5pRGFzaGJvYXJkU3ZjLnBjaGFydHMoX2VsZW1lbnRSZWYsIF9yZW5kZXJlcik7XHJcbiAgICAgICAgX2tkU3BsaXR0ZXJFdmVudC5vbkRyYWcoKS5zdWJzY3JpYmUoX3R5cGUgPT4ge1xyXG4gICAgICAgICAgICB0aGlzLl9wQ2hhcnRzRnVuY3Rpb24uc2V0VG9vbHRpcFBsYWNlbWVudEZsYWcodHJ1ZSk7XHJcbiAgICAgICAgfSk7XHJcbiAgICAgICAgX2tkU3BsaXR0ZXJFdmVudC5vblRvZ2dsZU1lbnUoKS5zdWJzY3JpYmUoX3R5cGUgPT4ge1xyXG4gICAgICAgICAgICB0aGlzLl9wQ2hhcnRzRnVuY3Rpb24uc2V0VG9vbHRpcFBsYWNlbWVudEZsYWcodHJ1ZSk7XHJcbiAgICAgICAgfSk7XHJcbiAgICB9XHJcblxyXG4gICAgQEhvc3RMaXN0ZW5lcignd2luZG93OnJlc2l6ZScsIFsnJGV2ZW50J10pXHJcbiAgICBvblJlc2l6ZShldmVudDogYW55KTogdm9pZCB7XHJcbiAgICAgICAgdGhpcy5fcENoYXJ0c0Z1bmN0aW9uLnNldFRvb2x0aXBQbGFjZW1lbnRGbGFnKHRydWUpO1xyXG4gICAgICAgIHRoaXMuX3BDaGFydHNGdW5jdGlvbi5wcm9jZXNzVG9vbHRpcFRvQ2FudmFzU2l6ZSh0aGlzLl9jYW52YXMsIHRoaXMuY2hhcnQpO1xyXG4gICAgICAgIGlmICh0aGlzLml0ZW1MZW5ndGggPT09IDMpIHtcclxuICAgICAgICAgICAgdGhpcy5fcmVzaXplTGVnZW5kKCk7XHJcbiAgICAgICAgICAgIHRoaXMuX3Jlc2l6ZUNhbnZhcygpO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICBuZ09uSW5pdCgpOiB2b2lkIHtcclxuICAgICAgICB0aGlzLl9pc0ZpcnN0TG9hZCA9IGZhbHNlO1xyXG4gICAgICAgIHRoaXMuX3Rvb2x0aXBFbGVtZW50ID0gdGhpcy50b29sdGlwLl9lbGVtZW50UmVmLm5hdGl2ZUVsZW1lbnQ7XHJcbiAgICAgICAgdGhpcy5fY2hhcnRMZWdlbmRFbGVtZW50ID0gdGhpcy5jaGFydExlZ2VuZC5uYXRpdmVFbGVtZW50O1xyXG4gICAgfVxyXG5cclxuICAgIG5nT25DaGFuZ2VzKF9zaW1wbGVDaGFuZ2VzOiBTaW1wbGVDaGFuZ2VzKTogdm9pZCB7XHJcbiAgICAgICAgaWYgKF9zaW1wbGVDaGFuZ2VzLmhhc093blByb3BlcnR5KCdpdGVtTGVuZ3RoJykgJiYgX3NpbXBsZUNoYW5nZXMuaXRlbUxlbmd0aC5jdXJyZW50VmFsdWUgPT09IDMpIHtcclxuICAgICAgICAgICAgdGhpcy5fcmVzaXplTGVnZW5kKCk7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGlmICghdGhpcy5faXNGaXJzdExvYWQgJiYgdGhpcy5pdGVtTGVuZ3RoID09PSAzKSB0aGlzLl9yZXNpemVDYW52YXMoKTtcclxuICAgICAgICBpZiAoX3NpbXBsZUNoYW5nZXMuaGFzT3duUHJvcGVydHkoJ2RpcmVjdGlvbicpICYmIHRoaXMuZGlyZWN0aW9uID09PSAncmlnaHQnKSB0aGlzLnBsYWNlbWVudCA9ICdib3R0b20tcmlnaHQnO1xyXG4gICAgfVxyXG5cclxuICAgIG5nQWZ0ZXJWaWV3SW5pdCgpOiB2b2lkIHtcclxuICAgICAgICB0aGlzLl9jYW52YXMgPSB0aGlzLmNoYXJ0LmdldENhbnZhcygpO1xyXG4gICAgICAgIHRoaXMuX3BDaGFydEVsZW1lbnQgPSB0aGlzLl9lbGVtZW50UmVmLm5hdGl2ZUVsZW1lbnQucXVlcnlTZWxlY3RvcignLmtkeC1taW5pLWRhc2hib2FyZCAua2R4LW1pbmktZGFzaGJvYXJkLWNoYXJ0IHAtY2hhcnQnKTtcclxuICAgICAgICBpZiAodGhpcy5pdGVtTGVuZ3RoID09PSAzKSB0aGlzLl9yZXNpemVDYW52YXMoKTtcclxuICAgICAgICB0aGlzLl9zZXRMZWdlbmQoKTtcclxuICAgICAgICB0aGlzLl9wQ2hhcnRzRnVuY3Rpb24ucHJvY2Vzc1Rvb2x0aXBUb0NhbnZhc1NpemUodGhpcy5fY2FudmFzLCB0aGlzLmNoYXJ0KTtcclxuICAgIH1cclxuXHJcbiAgICBuZ09uRGVzdHJveSgpOiB2b2lkIHtcclxuICAgICAgICB0aGlzLl9rZE1pbmlEYXNoYm9hcmRTdmMucmVtb3ZlQ2hpbGRyZW4odGhpcy5fY2hhcnRMZWdlbmRFbGVtZW50KTtcclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF9zZXRMZWdlbmQoKTogdm9pZCB7XHJcbiAgICAgICAgaWYgKCF0aGlzLmlzTGVnZW5kRGlzcGxheWVkKSByZXR1cm47XHJcbiAgICAgICAgdGhpcy5fY2hhcnRMZWdlbmRFbGVtZW50LmlubmVySFRNTCA9IHRoaXMuY2hhcnQuY2hhcnQuZ2VuZXJhdGVMZWdlbmQoKSB8fCAnJztcclxuICAgICAgICB0aGlzLl9zZXRMZWdlbmRMYWJlbEVsZW1lbnQoKTtcclxuICAgICAgICB0aGlzLl9wQ2hhcnRzRnVuY3Rpb24uYXR0YWNoTGVnZW5kTGlzdGVuZXIoXHJcbiAgICAgICAgICAgIHRoaXMuX2xlZ2VuZExhYmVsRWxlbWVudCxcclxuICAgICAgICAgICAgeyB1aUNoYXJ0OiB0aGlzLmNoYXJ0LCBsZWdlbmRFbGVtZW50OiB0aGlzLl9jaGFydExlZ2VuZEVsZW1lbnQgfSxcclxuICAgICAgICAgICAgeyBtZXRob2Q6IHRoaXMudG9vbHRpcCwgZWxlbWVudDogdGhpcy5fdG9vbHRpcEVsZW1lbnQgfSxcclxuICAgICAgICAgICAgdGhpcy5kaXJlY3Rpb25cclxuICAgICAgICApO1xyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX3NldExlZ2VuZExhYmVsRWxlbWVudCgpOiB2b2lkIHtcclxuICAgICAgICB0aGlzLl9sZWdlbmRMYWJlbEVsZW1lbnQgPSB0aGlzLl9lbGVtZW50UmVmLm5hdGl2ZUVsZW1lbnQucXVlcnlTZWxlY3RvckFsbCgnLmtkeC1taW5pLWRhc2hib2FyZCAua2R4LWVsZW0taXRlbSAuY2hhcnQtbGVnZW5kIHVsIGxpIC5jaGFydC1sZWdlbmQtbGFiZWwnKTtcclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF9yZXNpemVMZWdlbmQoKTogdm9pZCB7XHJcbiAgICAgICAgaWYgKDQ4MCA8IHdpbmRvdy5pbm5lcldpZHRoICYmIHdpbmRvdy5pbm5lcldpZHRoIDwgNjUwKSB7XHJcbiAgICAgICAgICAgIGlmICh0aGlzLl9pc1dpZHRoQ2hhbmdlZC5sZWdlbmQgPT09IGZhbHNlKSB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLnRocmVlSXRlbUxlZ2VuZCA9IHRydWU7XHJcbiAgICAgICAgICAgICAgICB0aGlzLl9pc1dpZHRoQ2hhbmdlZC5sZWdlbmQgPSB0cnVlO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgaWYgKHRoaXMuX2lzV2lkdGhDaGFuZ2VkLmxlZ2VuZCA9PT0gdHJ1ZSkge1xyXG4gICAgICAgICAgICAgICAgdGhpcy50aHJlZUl0ZW1MZWdlbmQgPSBmYWxzZTtcclxuICAgICAgICAgICAgICAgIHRoaXMuX2lzV2lkdGhDaGFuZ2VkLmxlZ2VuZCA9IGZhbHNlO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX3Jlc2l6ZUNhbnZhcygpOiB2b2lkIHtcclxuICAgICAgICBpZiAoNDgwIDwgd2luZG93LmlubmVyV2lkdGggJiYgd2luZG93LmlubmVyV2lkdGggPCA2NTApIHtcclxuICAgICAgICAgICAgaWYgKHRoaXMuX2lzV2lkdGhDaGFuZ2VkLmNhbnZhcyA9PT0gZmFsc2UpIHtcclxuICAgICAgICAgICAgICAgIHRoaXMuX3BDaGFydHNGdW5jdGlvbi5zZXRDYW52YXNTdHlsZSgnODAnLCB0aGlzLl9jYW52YXMpO1xyXG4gICAgICAgICAgICAgICAgdGhpcy5faXNXaWR0aENoYW5nZWQuY2FudmFzID0gdHJ1ZTtcclxuICAgICAgICAgICAgICAgIHRoaXMuX3JlbmRlcmVyLnNldFN0eWxlKHRoaXMuX3BDaGFydEVsZW1lbnQsICd3aWR0aCcsICc4MHB4Jyk7XHJcbiAgICAgICAgICAgICAgICB0aGlzLl9yZW5kZXJlci5zZXRTdHlsZSh0aGlzLl9wQ2hhcnRFbGVtZW50LCAnaGVpZ2h0JywgJzgwcHgnKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH0gZWxzZSBpZiAod2luZG93LmlubmVyV2lkdGggPiA2NTAgfHwgd2luZG93LmlubmVyV2lkdGggPT09IDY1MCkge1xyXG4gICAgICAgICAgICBpZiAodGhpcy5faXNXaWR0aENoYW5nZWQuY2FudmFzID09PSB0cnVlKSB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLl9wQ2hhcnRzRnVuY3Rpb24uc2V0Q2FudmFzU3R5bGUoJzEwMCcsIHRoaXMuX2NhbnZhcyk7XHJcbiAgICAgICAgICAgICAgICB0aGlzLl9pc1dpZHRoQ2hhbmdlZC5jYW52YXMgPSBmYWxzZTtcclxuICAgICAgICAgICAgICAgIHRoaXMuX3JlbmRlcmVyLnNldFN0eWxlKHRoaXMuX3BDaGFydEVsZW1lbnQsICd3aWR0aCcsICcxMDBweCcpO1xyXG4gICAgICAgICAgICAgICAgdGhpcy5fcmVuZGVyZXIuc2V0U3R5bGUodGhpcy5fcENoYXJ0RWxlbWVudCwgJ2hlaWdodCcsICcxMDBweCcpO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG59XHJcbiJdfQ==