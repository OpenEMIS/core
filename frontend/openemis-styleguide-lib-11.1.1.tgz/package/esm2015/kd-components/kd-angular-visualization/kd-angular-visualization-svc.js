import { Injectable } from '@angular/core';
import { KdDomElemSvc } from '../kd-common/index';
export class KdVisualizationSvc {
    constructor(_domElemSvc) {
        this._domElemSvc = _domElemSvc;
    }
    set visualizationElem(_element) { this._visualizationElem = _element; }
    // table within chart does not allow image or input type columns
    filterColumns(_colDefArr) {
        // kd-table config is defined in the following way (9 May 2018)
        // text: does not require the key 'type'
        // input or image: puts type === image || input
        return _colDefArr.filter(column => !column.type).map(column => Object.assign({}, column));
    }
    getImmutableMenuArr(_defaultMenuArr) {
        return _defaultMenuArr.map(item => {
            if (item.expanded)
                this.getImmutableMenuArr(item.expanded);
            return Object.assign({}, item);
        });
    }
    setMenuItemVisibility(_type, _string, _isHide, _menuArr) {
        for (let i = 0; i < _menuArr.length; ++i) {
            if (_menuArr[i][_type] === _string) {
                _menuArr[i].hidden = _isHide;
                if (_type === 'id')
                    break;
            }
            else if (_menuArr[i].hasOwnProperty('expanded')) {
                this.setMenuItemVisibility(_type, _string, _isHide, _menuArr[i].expanded);
            }
        }
    }
    setMenuTranslation(_menuArr, _translationCallback) {
        if (!_menuArr && !_translationCallback)
            return;
        let menuArr = [];
        for (let i = 0; i < _menuArr.length; ++i) {
            let item = Object.assign({}, _menuArr[i]);
            if (item.hasOwnProperty('text') && typeof item.text === 'string') {
                item.text = _translationCallback(item.text) || item.text;
            }
            if (item.hasOwnProperty('expanded'))
                item.expanded = this.setMenuTranslation(item.expanded, _translationCallback);
            menuArr.push(item);
        }
        return menuArr;
    }
    getBtnAlignment(_btnConfig) {
        return (_btnConfig || 'bottom-left').split('-').map(el => 'kdx-visualization-' + el).join(' ');
    }
    // ================================= Export ==================================
    /**
     * before exporting, the html need to be changed
     * 1) remove all dummy labels
     * 2) remove class name '.legend-scroll' in order to display all legend
     *  _parentElem [description]
     */
    // public prepareHTML(_parentElem: HTMLElement): void {
    //     this._removeDummy(_parentElem);
    //     this._removeLegendScroll(_parentElem);
    //     _parentElem.style.height = 'auto';
    // }
    removeDummy(_parentElem) {
        let dummyElementArr = _parentElem.querySelectorAll('.kdx-charts-dummy');
        for (let i = 0; i < dummyElementArr.length; ++i) {
            dummyElementArr[i].remove();
        }
    }
    removeLegendScroll(_parentElem) {
        let legendElem = _parentElem.querySelector('.kdx-legend.legend-scroll');
        this._domElemSvc.removeClass(legendElem, 'legend-scroll');
    }
    // ================================= Table ==================================
    processViewTable(_tableConfig) {
        // when ag-grid is in small screen, render all rows and there will be no inner-scroll
        // this logic is for mobile device, because when using mobile device, a large table should be fully displayed to prevent scrolling confusion (swiping page up might end up scrolling the table)
        // hence we will set parent's height to be 100% of content
        if (this._domElemSvc.isMobile()) {
            // when change to table, store parent's height for chart
            this._parentHeight = window.getComputedStyle(this._visualizationElem.parentNode).height;
            // if mobile, set parent height to 100% so that bottom content will be pushed down
            this.setParentHeight('table');
        }
        // temp fix. table does not follow parent height
        this._setTableHeight(_tableConfig, this._visualizationElem);
    }
    setParentHeight(_type) {
        if (!this._domElemSvc.isMobile())
            return;
        switch (_type) {
            case 'chart':
                // when change to chart, use back the stored parent's height
                // note: chart requires parent to provide a definite height value (cannot use 100% of children)
                this._visualizationElem.parentNode.style.height = this._parentHeight;
                break;
            case 'table':
            default:
                this._visualizationElem.parentNode.style.height = '100%';
                break;
        }
    }
    _setTableHeight(_tableConfig, _element) {
        _tableConfig['gridHeight'] = _element.getBoundingClientRect().height;
    }
}
KdVisualizationSvc.decorators = [
    { type: Injectable }
];
KdVisualizationSvc.ctorParameters = () => [
    { type: KdDomElemSvc }
];
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoia2QtYW5ndWxhci12aXN1YWxpemF0aW9uLXN2Yy5qcyIsInNvdXJjZVJvb3QiOiJEOi9vcGVuRU1JUy9zdHlsZWd1aWRlL2lvc3RnLW9wZW5lbWlzLXN0eWxlZ3VpZGUvcHJvamVjdHMvb3BlbmVtaXMtc3R5bGVndWlkZS1saWIvc3JjLyIsInNvdXJjZXMiOlsia2QtY29tcG9uZW50cy9rZC1hbmd1bGFyLXZpc3VhbGl6YXRpb24va2QtYW5ndWxhci12aXN1YWxpemF0aW9uLXN2Yy50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQSxPQUFPLEVBQUUsVUFBVSxFQUFFLE1BQU0sZUFBZSxDQUFDO0FBRTNDLE9BQU8sRUFBRSxZQUFZLEVBQUUsTUFBTSxvQkFBb0IsQ0FBQztBQUlsRCxNQUFNLE9BQU8sa0JBQWtCO0lBUTNCLFlBQW9CLFdBQXlCO1FBQXpCLGdCQUFXLEdBQVgsV0FBVyxDQUFjO0lBQUksQ0FBQztJQUZsRCxJQUFJLGlCQUFpQixDQUFDLFFBQVEsSUFBSSxJQUFJLENBQUMsa0JBQWtCLEdBQUcsUUFBUSxDQUFDLENBQUMsQ0FBQztJQUl2RSxnRUFBZ0U7SUFDekQsYUFBYSxDQUFDLFVBQTBCO1FBQzNDLCtEQUErRDtRQUMvRCx3Q0FBd0M7UUFDeEMsK0NBQStDO1FBQy9DLE9BQU8sVUFBVSxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsRUFBRSxDQUFDLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxDQUFDLEdBQUcsQ0FBQyxNQUFNLENBQUMsRUFBRSxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsRUFBRSxFQUFFLE1BQU0sQ0FBQyxDQUFDLENBQUM7SUFDOUYsQ0FBQztJQUVNLG1CQUFtQixDQUFDLGVBQWU7UUFDdEMsT0FBTyxlQUFlLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxFQUFFO1lBQzlCLElBQUksSUFBSSxDQUFDLFFBQVE7Z0JBQUUsSUFBSSxDQUFDLG1CQUFtQixDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsQ0FBQztZQUMzRCxPQUFPLE1BQU0sQ0FBQyxNQUFNLENBQUMsRUFBRSxFQUFFLElBQUksQ0FBQyxDQUFDO1FBQ25DLENBQUMsQ0FBQyxDQUFDO0lBQ1AsQ0FBQztJQUVNLHFCQUFxQixDQUFDLEtBQXNCLEVBQUUsT0FBZSxFQUFFLE9BQWdCLEVBQUUsUUFBcUI7UUFDekcsS0FBSyxJQUFJLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxHQUFHLFFBQVEsQ0FBQyxNQUFNLEVBQUUsRUFBRSxDQUFDLEVBQUU7WUFDdEMsSUFBSSxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLEtBQUssT0FBTyxFQUFFO2dCQUNoQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxHQUFHLE9BQU8sQ0FBQztnQkFDN0IsSUFBSSxLQUFLLEtBQUssSUFBSTtvQkFBRSxNQUFNO2FBQzdCO2lCQUFNLElBQUksUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLGNBQWMsQ0FBQyxVQUFVLENBQUMsRUFBRTtnQkFDL0MsSUFBSSxDQUFDLHFCQUFxQixDQUFDLEtBQUssRUFBRSxPQUFPLEVBQUUsT0FBTyxFQUFFLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQzthQUM3RTtTQUNKO0lBQ0wsQ0FBQztJQUVNLGtCQUFrQixDQUFDLFFBQXFCLEVBQUUsb0JBQW9CO1FBQ2pFLElBQUksQ0FBQyxRQUFRLElBQUksQ0FBQyxvQkFBb0I7WUFBRSxPQUFPO1FBRS9DLElBQUksT0FBTyxHQUFHLEVBQUUsQ0FBQztRQUNqQixLQUFLLElBQUksQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLEdBQUcsUUFBUSxDQUFDLE1BQU0sRUFBRSxFQUFFLENBQUMsRUFBRTtZQUN0QyxJQUFJLElBQUksR0FBRyxNQUFNLENBQUMsTUFBTSxDQUFDLEVBQUUsRUFBRSxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztZQUMxQyxJQUFJLElBQUksQ0FBQyxjQUFjLENBQUMsTUFBTSxDQUFDLElBQUksT0FBTyxJQUFJLENBQUMsSUFBSSxLQUFLLFFBQVEsRUFBRTtnQkFDOUQsSUFBSSxDQUFDLElBQUksR0FBRyxvQkFBb0IsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksSUFBSSxDQUFDLElBQUksQ0FBQzthQUM1RDtZQUNELElBQUksSUFBSSxDQUFDLGNBQWMsQ0FBQyxVQUFVLENBQUM7Z0JBQUUsSUFBSSxDQUFDLFFBQVEsR0FBRyxJQUFJLENBQUMsa0JBQWtCLENBQUMsSUFBSSxDQUFDLFFBQVEsRUFBRSxvQkFBb0IsQ0FBQyxDQUFDO1lBQ2xILE9BQU8sQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUM7U0FDdEI7UUFDRCxPQUFPLE9BQU8sQ0FBQztJQUNuQixDQUFDO0lBRU0sZUFBZSxDQUFDLFVBQXFFO1FBQ3hGLE9BQU8sQ0FBQyxVQUFVLElBQUksYUFBYSxDQUFDLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsRUFBRSxDQUFDLG9CQUFvQixHQUFHLEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQztJQUNuRyxDQUFDO0lBRUQsOEVBQThFO0lBRTlFOzs7OztPQUtHO0lBQ0gsdURBQXVEO0lBQ3ZELHNDQUFzQztJQUN0Qyw2Q0FBNkM7SUFDN0MseUNBQXlDO0lBQ3pDLElBQUk7SUFFRyxXQUFXLENBQUMsV0FBb0I7UUFDbkMsSUFBSSxlQUFlLEdBQVEsV0FBVyxDQUFDLGdCQUFnQixDQUFDLG1CQUFtQixDQUFDLENBQUM7UUFDN0UsS0FBSyxJQUFJLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxHQUFHLGVBQWUsQ0FBQyxNQUFNLEVBQUUsRUFBRSxDQUFDLEVBQUU7WUFDN0MsZUFBZSxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sRUFBRSxDQUFDO1NBQy9CO0lBQ0wsQ0FBQztJQUVNLGtCQUFrQixDQUFDLFdBQW9CO1FBQzFDLElBQUksVUFBVSxHQUFHLFdBQVcsQ0FBQyxhQUFhLENBQUMsMkJBQTJCLENBQUMsQ0FBQztRQUN4RSxJQUFJLENBQUMsV0FBVyxDQUFDLFdBQVcsQ0FBQyxVQUFVLEVBQUUsZUFBZSxDQUFDLENBQUM7SUFDOUQsQ0FBQztJQUVELDZFQUE2RTtJQUV0RSxnQkFBZ0IsQ0FBQyxZQUFZO1FBRWhDLHFGQUFxRjtRQUNyRiwrTEFBK0w7UUFDL0wsMERBQTBEO1FBQzFELElBQUksSUFBSSxDQUFDLFdBQVcsQ0FBQyxRQUFRLEVBQUUsRUFBRTtZQUM3Qix3REFBd0Q7WUFDeEQsSUFBSSxDQUFDLGFBQWEsR0FBRyxNQUFNLENBQUMsZ0JBQWdCLENBQUMsSUFBSSxDQUFDLGtCQUFrQixDQUFDLFVBQVUsQ0FBQyxDQUFDLE1BQU0sQ0FBQztZQUV4RixrRkFBa0Y7WUFDbEYsSUFBSSxDQUFDLGVBQWUsQ0FBQyxPQUFPLENBQUMsQ0FBQztTQUNqQztRQUVELGdEQUFnRDtRQUNoRCxJQUFJLENBQUMsZUFBZSxDQUFDLFlBQVksRUFBRSxJQUFJLENBQUMsa0JBQWtCLENBQUMsQ0FBQztJQUNoRSxDQUFDO0lBRU0sZUFBZSxDQUFDLEtBQUs7UUFDeEIsSUFBSSxDQUFDLElBQUksQ0FBQyxXQUFXLENBQUMsUUFBUSxFQUFFO1lBQUUsT0FBTztRQUV6QyxRQUFRLEtBQUssRUFBRTtZQUNYLEtBQUssT0FBTztnQkFDUiw0REFBNEQ7Z0JBQzVELCtGQUErRjtnQkFDL0YsSUFBSSxDQUFDLGtCQUFrQixDQUFDLFVBQVUsQ0FBQyxLQUFLLENBQUMsTUFBTSxHQUFHLElBQUksQ0FBQyxhQUFhLENBQUM7Z0JBQ3JFLE1BQU07WUFDVixLQUFLLE9BQU8sQ0FBQztZQUNiO2dCQUNJLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxVQUFVLENBQUMsS0FBSyxDQUFDLE1BQU0sR0FBRyxNQUFNLENBQUM7Z0JBQ3pELE1BQU07U0FDYjtJQUNMLENBQUM7SUFFTyxlQUFlLENBQUMsWUFBMEIsRUFBRSxRQUFRO1FBQ3hELFlBQVksQ0FBQyxZQUFZLENBQUMsR0FBRyxRQUFRLENBQUMscUJBQXFCLEVBQUUsQ0FBQyxNQUFNLENBQUM7SUFDekUsQ0FBQzs7O1lBdkhKLFVBQVU7OztZQUhGLFlBQVkiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBJbmplY3RhYmxlIH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XHJcbmltcG9ydCB7IElNZW51SXRlbSB9IGZyb20gJy4uL2tkLWFuZ3VsYXItY2hhcnRzL2tkLWFuZ3VsYXItY2hhcnRzLWludGVyZmFjZSc7XHJcbmltcG9ydCB7IEtkRG9tRWxlbVN2YyB9IGZyb20gJy4uL2tkLWNvbW1vbi9pbmRleCc7XHJcbmltcG9ydCB7IElUYWJsZUNvbmZpZywgSVRhYmxlQ29sdW1uIH0gZnJvbSAnLi9rZC1hbmd1bGFyLXZpc3VhbGl6YXRpb24taW50ZXJmYWNlJztcclxuXHJcbkBJbmplY3RhYmxlKClcclxuZXhwb3J0IGNsYXNzIEtkVmlzdWFsaXphdGlvblN2YyB7XHJcblxyXG4gICAgcHJpdmF0ZSBfcGFyZW50SGVpZ2h0OiBzdHJpbmc7XHJcblxyXG4gICAgcHJpdmF0ZSBfdmlzdWFsaXphdGlvbkVsZW06IGFueTtcclxuXHJcbiAgICBzZXQgdmlzdWFsaXphdGlvbkVsZW0oX2VsZW1lbnQpIHsgdGhpcy5fdmlzdWFsaXphdGlvbkVsZW0gPSBfZWxlbWVudDsgfVxyXG5cclxuICAgIGNvbnN0cnVjdG9yKHByaXZhdGUgX2RvbUVsZW1TdmM6IEtkRG9tRWxlbVN2YykgeyB9XHJcblxyXG4gICAgLy8gdGFibGUgd2l0aGluIGNoYXJ0IGRvZXMgbm90IGFsbG93IGltYWdlIG9yIGlucHV0IHR5cGUgY29sdW1uc1xyXG4gICAgcHVibGljIGZpbHRlckNvbHVtbnMoX2NvbERlZkFycjogSVRhYmxlQ29sdW1uW10pOiBJVGFibGVDb2x1bW5bXSB7XHJcbiAgICAgICAgLy8ga2QtdGFibGUgY29uZmlnIGlzIGRlZmluZWQgaW4gdGhlIGZvbGxvd2luZyB3YXkgKDkgTWF5IDIwMTgpXHJcbiAgICAgICAgLy8gdGV4dDogZG9lcyBub3QgcmVxdWlyZSB0aGUga2V5ICd0eXBlJ1xyXG4gICAgICAgIC8vIGlucHV0IG9yIGltYWdlOiBwdXRzIHR5cGUgPT09IGltYWdlIHx8IGlucHV0XHJcbiAgICAgICAgcmV0dXJuIF9jb2xEZWZBcnIuZmlsdGVyKGNvbHVtbiA9PiAhY29sdW1uLnR5cGUpLm1hcChjb2x1bW4gPT4gT2JqZWN0LmFzc2lnbih7fSwgY29sdW1uKSk7XHJcbiAgICB9XHJcblxyXG4gICAgcHVibGljIGdldEltbXV0YWJsZU1lbnVBcnIoX2RlZmF1bHRNZW51QXJyKSB7XHJcbiAgICAgICAgcmV0dXJuIF9kZWZhdWx0TWVudUFyci5tYXAoaXRlbSA9PiB7XHJcbiAgICAgICAgICAgIGlmIChpdGVtLmV4cGFuZGVkKSB0aGlzLmdldEltbXV0YWJsZU1lbnVBcnIoaXRlbS5leHBhbmRlZCk7XHJcbiAgICAgICAgICAgIHJldHVybiBPYmplY3QuYXNzaWduKHt9LCBpdGVtKTtcclxuICAgICAgICB9KTtcclxuICAgIH1cclxuXHJcbiAgICBwdWJsaWMgc2V0TWVudUl0ZW1WaXNpYmlsaXR5KF90eXBlOiAnaWQnIHwgJ2FjdGlvbicsIF9zdHJpbmc6IHN0cmluZywgX2lzSGlkZTogYm9vbGVhbiwgX21lbnVBcnI6IElNZW51SXRlbVtdKTogdm9pZCB7XHJcbiAgICAgICAgZm9yIChsZXQgaSA9IDA7IGkgPCBfbWVudUFyci5sZW5ndGg7ICsraSkge1xyXG4gICAgICAgICAgICBpZiAoX21lbnVBcnJbaV1bX3R5cGVdID09PSBfc3RyaW5nKSB7XHJcbiAgICAgICAgICAgICAgICBfbWVudUFycltpXS5oaWRkZW4gPSBfaXNIaWRlO1xyXG4gICAgICAgICAgICAgICAgaWYgKF90eXBlID09PSAnaWQnKSBicmVhaztcclxuICAgICAgICAgICAgfSBlbHNlIGlmIChfbWVudUFycltpXS5oYXNPd25Qcm9wZXJ0eSgnZXhwYW5kZWQnKSkge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5zZXRNZW51SXRlbVZpc2liaWxpdHkoX3R5cGUsIF9zdHJpbmcsIF9pc0hpZGUsIF9tZW51QXJyW2ldLmV4cGFuZGVkKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICBwdWJsaWMgc2V0TWVudVRyYW5zbGF0aW9uKF9tZW51QXJyOiBJTWVudUl0ZW1bXSwgX3RyYW5zbGF0aW9uQ2FsbGJhY2spOiBJTWVudUl0ZW1bXSB7XHJcbiAgICAgICAgaWYgKCFfbWVudUFyciAmJiAhX3RyYW5zbGF0aW9uQ2FsbGJhY2spIHJldHVybjtcclxuXHJcbiAgICAgICAgbGV0IG1lbnVBcnIgPSBbXTtcclxuICAgICAgICBmb3IgKGxldCBpID0gMDsgaSA8IF9tZW51QXJyLmxlbmd0aDsgKytpKSB7XHJcbiAgICAgICAgICAgIGxldCBpdGVtID0gT2JqZWN0LmFzc2lnbih7fSwgX21lbnVBcnJbaV0pO1xyXG4gICAgICAgICAgICBpZiAoaXRlbS5oYXNPd25Qcm9wZXJ0eSgndGV4dCcpICYmIHR5cGVvZiBpdGVtLnRleHQgPT09ICdzdHJpbmcnKSB7XHJcbiAgICAgICAgICAgICAgICBpdGVtLnRleHQgPSBfdHJhbnNsYXRpb25DYWxsYmFjayhpdGVtLnRleHQpIHx8IGl0ZW0udGV4dDtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBpZiAoaXRlbS5oYXNPd25Qcm9wZXJ0eSgnZXhwYW5kZWQnKSkgaXRlbS5leHBhbmRlZCA9IHRoaXMuc2V0TWVudVRyYW5zbGF0aW9uKGl0ZW0uZXhwYW5kZWQsIF90cmFuc2xhdGlvbkNhbGxiYWNrKTtcclxuICAgICAgICAgICAgbWVudUFyci5wdXNoKGl0ZW0pO1xyXG4gICAgICAgIH1cclxuICAgICAgICByZXR1cm4gbWVudUFycjtcclxuICAgIH1cclxuXHJcbiAgICBwdWJsaWMgZ2V0QnRuQWxpZ25tZW50KF9idG5Db25maWc6ICd0b3AtbGVmdCcgfCAndG9wLXJpZ2h0JyB8ICdib3R0b20tbGVmdCcgfCAnYm90dG9tLXJpZ2h0Jyk6IHN0cmluZyB7XHJcbiAgICAgICAgcmV0dXJuIChfYnRuQ29uZmlnIHx8ICdib3R0b20tbGVmdCcpLnNwbGl0KCctJykubWFwKGVsID0+ICdrZHgtdmlzdWFsaXphdGlvbi0nICsgZWwpLmpvaW4oJyAnKTtcclxuICAgIH1cclxuXHJcbiAgICAvLyA9PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT0gRXhwb3J0ID09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT1cclxuXHJcbiAgICAvKipcclxuICAgICAqIGJlZm9yZSBleHBvcnRpbmcsIHRoZSBodG1sIG5lZWQgdG8gYmUgY2hhbmdlZFxyXG4gICAgICogMSkgcmVtb3ZlIGFsbCBkdW1teSBsYWJlbHNcclxuICAgICAqIDIpIHJlbW92ZSBjbGFzcyBuYW1lICcubGVnZW5kLXNjcm9sbCcgaW4gb3JkZXIgdG8gZGlzcGxheSBhbGwgbGVnZW5kXHJcbiAgICAgKiAgX3BhcmVudEVsZW0gW2Rlc2NyaXB0aW9uXVxyXG4gICAgICovXHJcbiAgICAvLyBwdWJsaWMgcHJlcGFyZUhUTUwoX3BhcmVudEVsZW06IEhUTUxFbGVtZW50KTogdm9pZCB7XHJcbiAgICAvLyAgICAgdGhpcy5fcmVtb3ZlRHVtbXkoX3BhcmVudEVsZW0pO1xyXG4gICAgLy8gICAgIHRoaXMuX3JlbW92ZUxlZ2VuZFNjcm9sbChfcGFyZW50RWxlbSk7XHJcbiAgICAvLyAgICAgX3BhcmVudEVsZW0uc3R5bGUuaGVpZ2h0ID0gJ2F1dG8nO1xyXG4gICAgLy8gfVxyXG5cclxuICAgIHB1YmxpYyByZW1vdmVEdW1teShfcGFyZW50RWxlbTogRWxlbWVudCk6IHZvaWQge1xyXG4gICAgICAgIGxldCBkdW1teUVsZW1lbnRBcnI6IGFueSA9IF9wYXJlbnRFbGVtLnF1ZXJ5U2VsZWN0b3JBbGwoJy5rZHgtY2hhcnRzLWR1bW15Jyk7XHJcbiAgICAgICAgZm9yIChsZXQgaSA9IDA7IGkgPCBkdW1teUVsZW1lbnRBcnIubGVuZ3RoOyArK2kpIHtcclxuICAgICAgICAgICAgZHVtbXlFbGVtZW50QXJyW2ldLnJlbW92ZSgpO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICBwdWJsaWMgcmVtb3ZlTGVnZW5kU2Nyb2xsKF9wYXJlbnRFbGVtOiBFbGVtZW50KSB7XHJcbiAgICAgICAgbGV0IGxlZ2VuZEVsZW0gPSBfcGFyZW50RWxlbS5xdWVyeVNlbGVjdG9yKCcua2R4LWxlZ2VuZC5sZWdlbmQtc2Nyb2xsJyk7XHJcbiAgICAgICAgdGhpcy5fZG9tRWxlbVN2Yy5yZW1vdmVDbGFzcyhsZWdlbmRFbGVtLCAnbGVnZW5kLXNjcm9sbCcpO1xyXG4gICAgfVxyXG5cclxuICAgIC8vID09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PSBUYWJsZSA9PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09XHJcblxyXG4gICAgcHVibGljIHByb2Nlc3NWaWV3VGFibGUoX3RhYmxlQ29uZmlnKSB7XHJcblxyXG4gICAgICAgIC8vIHdoZW4gYWctZ3JpZCBpcyBpbiBzbWFsbCBzY3JlZW4sIHJlbmRlciBhbGwgcm93cyBhbmQgdGhlcmUgd2lsbCBiZSBubyBpbm5lci1zY3JvbGxcclxuICAgICAgICAvLyB0aGlzIGxvZ2ljIGlzIGZvciBtb2JpbGUgZGV2aWNlLCBiZWNhdXNlIHdoZW4gdXNpbmcgbW9iaWxlIGRldmljZSwgYSBsYXJnZSB0YWJsZSBzaG91bGQgYmUgZnVsbHkgZGlzcGxheWVkIHRvIHByZXZlbnQgc2Nyb2xsaW5nIGNvbmZ1c2lvbiAoc3dpcGluZyBwYWdlIHVwIG1pZ2h0IGVuZCB1cCBzY3JvbGxpbmcgdGhlIHRhYmxlKVxyXG4gICAgICAgIC8vIGhlbmNlIHdlIHdpbGwgc2V0IHBhcmVudCdzIGhlaWdodCB0byBiZSAxMDAlIG9mIGNvbnRlbnRcclxuICAgICAgICBpZiAodGhpcy5fZG9tRWxlbVN2Yy5pc01vYmlsZSgpKSB7XHJcbiAgICAgICAgICAgIC8vIHdoZW4gY2hhbmdlIHRvIHRhYmxlLCBzdG9yZSBwYXJlbnQncyBoZWlnaHQgZm9yIGNoYXJ0XHJcbiAgICAgICAgICAgIHRoaXMuX3BhcmVudEhlaWdodCA9IHdpbmRvdy5nZXRDb21wdXRlZFN0eWxlKHRoaXMuX3Zpc3VhbGl6YXRpb25FbGVtLnBhcmVudE5vZGUpLmhlaWdodDtcclxuXHJcbiAgICAgICAgICAgIC8vIGlmIG1vYmlsZSwgc2V0IHBhcmVudCBoZWlnaHQgdG8gMTAwJSBzbyB0aGF0IGJvdHRvbSBjb250ZW50IHdpbGwgYmUgcHVzaGVkIGRvd25cclxuICAgICAgICAgICAgdGhpcy5zZXRQYXJlbnRIZWlnaHQoJ3RhYmxlJyk7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICAvLyB0ZW1wIGZpeC4gdGFibGUgZG9lcyBub3QgZm9sbG93IHBhcmVudCBoZWlnaHRcclxuICAgICAgICB0aGlzLl9zZXRUYWJsZUhlaWdodChfdGFibGVDb25maWcsIHRoaXMuX3Zpc3VhbGl6YXRpb25FbGVtKTtcclxuICAgIH1cclxuXHJcbiAgICBwdWJsaWMgc2V0UGFyZW50SGVpZ2h0KF90eXBlKSB7XHJcbiAgICAgICAgaWYgKCF0aGlzLl9kb21FbGVtU3ZjLmlzTW9iaWxlKCkpIHJldHVybjtcclxuXHJcbiAgICAgICAgc3dpdGNoIChfdHlwZSkge1xyXG4gICAgICAgICAgICBjYXNlICdjaGFydCc6XHJcbiAgICAgICAgICAgICAgICAvLyB3aGVuIGNoYW5nZSB0byBjaGFydCwgdXNlIGJhY2sgdGhlIHN0b3JlZCBwYXJlbnQncyBoZWlnaHRcclxuICAgICAgICAgICAgICAgIC8vIG5vdGU6IGNoYXJ0IHJlcXVpcmVzIHBhcmVudCB0byBwcm92aWRlIGEgZGVmaW5pdGUgaGVpZ2h0IHZhbHVlIChjYW5ub3QgdXNlIDEwMCUgb2YgY2hpbGRyZW4pXHJcbiAgICAgICAgICAgICAgICB0aGlzLl92aXN1YWxpemF0aW9uRWxlbS5wYXJlbnROb2RlLnN0eWxlLmhlaWdodCA9IHRoaXMuX3BhcmVudEhlaWdodDtcclxuICAgICAgICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgICAgICBjYXNlICd0YWJsZSc6XHJcbiAgICAgICAgICAgIGRlZmF1bHQ6XHJcbiAgICAgICAgICAgICAgICB0aGlzLl92aXN1YWxpemF0aW9uRWxlbS5wYXJlbnROb2RlLnN0eWxlLmhlaWdodCA9ICcxMDAlJztcclxuICAgICAgICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF9zZXRUYWJsZUhlaWdodChfdGFibGVDb25maWc6IElUYWJsZUNvbmZpZywgX2VsZW1lbnQpOiB2b2lkIHtcclxuICAgICAgICBfdGFibGVDb25maWdbJ2dyaWRIZWlnaHQnXSA9IF9lbGVtZW50LmdldEJvdW5kaW5nQ2xpZW50UmVjdCgpLmhlaWdodDtcclxuICAgIH1cclxuXHJcbn1cclxuIl19