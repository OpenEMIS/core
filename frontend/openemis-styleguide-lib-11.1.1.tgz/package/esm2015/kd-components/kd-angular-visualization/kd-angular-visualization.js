import { Component, ViewEncapsulation, Input, Output, EventEmitter, ElementRef, ChangeDetectorRef, ViewChild } from '@angular/core';
import { Observable } from 'rxjs';
import { trigger, style, transition, animate } from '@angular/animations';
import { defaultMenuArr } from './kd-angular-visualization-interface';
import { KdVisualizationSvc } from './kd-angular-visualization-svc';
import { KdVisualizationExport } from './kd-angular-visualization-export';
import { KdDomElemSvc } from '../kd-common/index';
import { KdCharts } from '../kd-angular-charts/index';
export class KdVisualization {
    constructor(_elemRef, _visualizationSvc, cdr) {
        this._elemRef = _elemRef;
        this._visualizationSvc = _visualizationSvc;
        this.cdr = cdr;
        /* menu */
        this.isExportEnabled = false;
        this.isMenuOpen = false;
        this.menuFlag = 'closed'; // can be 'opened' | 'closed' | 'expanded' | 'viewed'
        this.menuDisplayArr = [];
        this._menuArr = [];
        this.menuBtnIconClass = 'fa-chevron-up';
        this._menuBtnList = {
            closed: 'fa-chevron-up',
            opened: 'fa-close',
            viewed: 'fa-close',
            expanded: 'fa-chevron-left'
        };
        /* invisible chart */
        this.exportNow = false;
        /* initial load of invisible chart should not start drawing. need to wait for setLegendData, then draw in one go */
        this.dataForInvisibleChart = null;
        this.configForInvisiblechart = null;
        this.invisibleChartClass = 'kdx-visualization-chart-invisible';
        this._defaultChartWidth = '1024px';
        /* view */
        this.contentState = 'chart'; // currently only have chart | table
        this.exportTable = false;
        this._timeoutTiming = 1000;
        this.outputLegendData = new EventEmitter();
        this.errorMsg = new EventEmitter();
        this.outputArea = new EventEmitter();
        this._export = new KdVisualizationExport();
        this._visualizationSvc.visualizationElem = this._elemRef.nativeElement;
    }
    ngOnInit() {
        this._initApi();
    }
    ngOnChanges(_simpleChanges) {
        if (_simpleChanges.hasOwnProperty('config') && _simpleChanges.config.currentValue) {
            this._setConfig(_simpleChanges.config.currentValue.export);
        }
        if (_simpleChanges.hasOwnProperty('rawData') && _simpleChanges.rawData.currentValue) {
            this.columnAfterFilter = this._visualizationSvc.filterColumns(_simpleChanges.rawData.currentValue.column);
        }
    }
    getOutputData(_data) {
        this.dataAfterMassage = _data;
    }
    getOutputLegendData(_legendData) {
        this.outputLegendData.emit(_legendData);
        this.legendDataAfterMassage = _legendData;
    }
    setArea(_data) {
        this.outputArea.emit(_data);
    }
    onExportExcelPossible() {
        if (this.exportTable) {
            this.rawData.api.general.exportToExcel({ fileName: this._fileName });
            this.exportTable = false;
        }
    }
    // ================================= Config ==================================
    _setConfig(_config) {
        // whenever config changes, set back to default values
        this.contentState = 'chart';
        this.menuFlag = 'closed';
        this.isMenuOpen = false;
        this.isExportEnabled = _config && _config.enabled;
        if (!this.isExportEnabled)
            return;
        this._setInitMenu(_config.menu);
        this.invisibleChartStyle = { 'width': _config.width || this._defaultChartWidth };
        this.btnAlignment = this._visualizationSvc.getBtnAlignment(_config.btn);
        this._setInitBtnClass(_config.btn);
    }
    _setInitBtnClass(_btnConfig) {
        if (_btnConfig && _btnConfig.split('-')[0] === 'top') {
            this.menuBtnIconClass = 'fa-chevron-down';
            this._menuBtnList.closed = 'fa-chevron-down';
        }
        else {
            this.menuBtnIconClass = 'fa-chevron-up';
            this._menuBtnList.closed = 'fa-chevron-up';
        }
    }
    _setInitMenu(_menu) {
        let menuArr = this._visualizationSvc.getImmutableMenuArr(defaultMenuArr);
        // translationCallback should take english string and return translated string
        if (this.api && this.api.hasOwnProperty('translationCallback')) {
            menuArr = this._visualizationSvc.setMenuTranslation(menuArr, this.api.translationCallback);
        }
        this._menuArr = menuArr.concat(_menu || []);
        if (!this.rawData)
            this._menuArr = this._menuArr.filter(item => item.id !== 'viewData' && item.id !== 'excel');
        this.menuDisplayArr = this._menuArr;
    }
    // ================================= INIT API and Sub ==================================
    _initApi() {
        if (!this.api)
            return;
        this.api.addMenuItem = (_menuItemArr) => {
            this._menuArr = this._menuArr.concat(_menuItemArr);
            this.cdr.detectChanges();
        };
        this.api.hideMenuItemById = (_id, _isHide = true) => {
            this._visualizationSvc.setMenuItemVisibility('id', _id, _isHide, this._menuArr);
            this.cdr.detectChanges();
        };
        this.api.hideMenuItemByAction = (_action, _isHide = true) => {
            this._visualizationSvc.setMenuItemVisibility('action', _action, _isHide, this._menuArr);
            this.cdr.detectChanges();
        };
        this.api.getDataUrl = (_style, _options, _isRemoveLegendScroll) => {
            return new Observable((_observer) => {
                let originalStyle = {};
                if (_style) {
                    originalStyle = Object.assign({}, this.invisibleChartStyle);
                    this.invisibleChartStyle = _style;
                }
                this._prepExportChart('imageUrl', _options, _isRemoveLegendScroll).subscribe((_response) => {
                    if (_style)
                        this.invisibleChartStyle = originalStyle;
                    _observer.next(_response);
                    _observer.complete();
                });
            });
        };
        this.api.toggleTable = (_showTable, rawData) => {
            rawData.config = Object.assign({}, this.rawData.config, rawData.config);
            this.rawData = Object.assign({}, rawData);
            this.columnAfterFilter = this._visualizationSvc.filterColumns(rawData.column);
            if (_showTable) {
                this._tempState = this.contentState;
                if (this.contentState !== 'table') {
                    this.contentState = 'table';
                    this._callPlugins('view.table');
                }
                this.isExportEnabled = false;
            }
            else {
                this.isExportEnabled = typeof this.config !== 'undefined' && this.config.export.enabled;
                this._visualizationSvc.setParentHeight('chart');
                this.contentState = this._tempState ? this._tempState : 'chart';
            }
        };
    }
    // ================================= Menu Clicked ==================================
    toggleMenu(_item) {
        let haveOperation = _item && _item.operation;
        let haveCallback = _item && _item.callback;
        if (haveOperation)
            this._callPlugins(_item.operation);
        if (haveCallback)
            _item.callback();
        this._toggleMenuFlag(this.menuFlag, _item, haveOperation || haveCallback);
        this.menuBtnIconClass = this._menuBtnList[this.menuFlag];
        this.isMenuOpen = this.menuFlag === 'opened' || this.menuFlag === 'expanded';
    }
    _toggleMenuFlag(_flag, _item, _closeExpand) {
        switch (_flag) {
            case 'closed':
            default:
                this.menuFlag = 'opened';
                break;
            case 'opened':
                let isExpand = _item && _item.expanded;
                if (isExpand) {
                    this.menuDisplayArr = _item.expanded;
                    this.menuFlag = 'expanded';
                    return;
                }
                let isView = false;
                if (_item && _item.hasOwnProperty('operation')) {
                    isView = _item && _item.operation.indexOf('view') > -1;
                    if (isView)
                        this.contentState = _item.operation.split('.')[1];
                }
                this.menuFlag = isView ? 'viewed' : 'closed';
                break;
            case 'expanded':
                this.menuFlag = _closeExpand ? 'closed' : 'opened';
                this.menuDisplayArr = this._menuArr;
                break;
            case 'viewed':
                this._visualizationSvc.setParentHeight('chart');
                this.menuFlag = 'closed';
                this.contentState = 'chart';
                break;
        }
    }
    _callPlugins(_operation) {
        // operations are separated by .
        let operationArr = _operation.split('.');
        if (operationArr[0] === 'view' && operationArr[1] === 'table') {
            this._visualizationSvc.processViewTable(this.rawData.config);
            return;
        }
        if (operationArr[0] !== 'export')
            return;
        if (this.config.title.text)
            this._fileName = this.config.title.text.replace(/\s/g, '_');
        if (operationArr[1] === 'excel') {
            this.exportTable = true;
        }
        else {
            this._prepExportChart(operationArr[1]).subscribe(() => { });
        }
    }
    _prepExportChart(_operation, _options = {}, _isRemoveLegendScroll = true) {
        return new Observable((_observer) => {
            if (!this._export.isExportCompatible()) {
                this.errorMsg.emit(this._export.getErrorMessage(_operation));
                _observer.error(this._export.getErrorMessage(_operation));
                _observer.complete();
            }
            else {
                // chart for exporting should skip massage and not have animation
                this.configForInvisiblechart = Object.assign({}, this.config, { id: 'export-chart', animation: false, skipMassage: true });
                this.exportNow = true;
                // ViewChild requires setTimeout (Angular 5)
                setTimeout(() => {
                    // set Legend Data so that this info does not have to be regenerated by invisible chart
                    this.invisibleChart.setLegendData(this.legendDataAfterMassage);
                    // trigger chart to draw once legend data is set
                    this.dataForInvisibleChart = this.dataAfterMassage;
                });
                let options = Object.assign({}, _options);
                if (this._fileName)
                    options['fileName'] = this._fileName;
                setTimeout(() => {
                    let chartElement = this._elemRef.nativeElement.querySelector('.' + this.invisibleChartClass + '.kdx-charts');
                    // before exporting, the html needs to be changed
                    this._visualizationSvc.removeDummy(chartElement);
                    if (_isRemoveLegendScroll)
                        this._visualizationSvc.removeLegendScroll(chartElement);
                    chartElement.style.height = 'auto';
                    options['width'] = chartElement.getBoundingClientRect().width + 1;
                    options['height'] = chartElement.getBoundingClientRect().height + 1;
                    let result = this._export.exportElement(chartElement, _operation, options);
                    // once export is done, remove the invisible chart from DOM
                    this.exportNow = false;
                    this.dataForInvisibleChart = null;
                    if (result) {
                        result.then(dataUrl => {
                            _observer.next(dataUrl);
                            _observer.complete();
                        });
                    }
                    else {
                        _observer.complete();
                    }
                }, this._timeoutTiming);
            }
        });
    }
}
KdVisualization.decorators = [
    { type: Component, args: [{
                selector: 'kd-visualization',
                template: "<div class=\"kdx-visualization-chart-wrapper\" [ngClass]=\"{'kdx-visualization-invisible-wrapper': contentState !== 'chart'}\">\r\n    <kd-charts [data]=\"data\"\r\n               [config]=\"config\" \r\n               [api]=\"api\"\r\n               [xThreshold]=\"xThreshold\"\r\n               [seriesThreshold]=\"seriesThreshold\"\r\n               (outputData)=\"getOutputData($event)\" \r\n               (outputLegendData)=\"getOutputLegendData($event)\" (outputArea)=\"setArea($event)\"></kd-charts>\r\n    <div class=\"kdx-visualization-invisible-wrapper\">\r\n      <kd-charts *ngIf=\"exportNow\"\r\n                  id=\"export-chart\"\r\n                  #invisibleChart\r\n                  [data]=\"dataForInvisibleChart\" \r\n                  [config]=\"configForInvisiblechart\" \r\n                  [xThreshold]=\"xThreshold\"\r\n                  [seriesThreshold]=\"seriesThreshold\"\r\n                  [ngClass]=\"invisibleChartClass\"\r\n                  [ngStyle]=\"invisibleChartStyle\"></kd-charts>\r\n    </div>\r\n</div>\r\n\r\n<kd-table  *ngIf=\"rawData && (exportTable || contentState == 'table')\"\r\n        [ngClass]=\"{'kdx-visualization-invisible-wrapper': exportTable}\"\r\n        [row]=\"rawData.row\"\r\n        [column]=\"columnAfterFilter\"\r\n        [config]=\"rawData.config\"\r\n        [api]=\"rawData.api\"\r\n        (onExportPossible)=\"onExportExcelPossible()\"></kd-table>\r\n\r\n<div *ngIf=\"isExportEnabled && isMenuOpen\" class=\"kdx-visualization-menu-container\">\r\n    <div *ngFor=\"let item of menuDisplayArr; let i = index \" class=\"kdx-visualization-menu-item-wrapper kdx-visualization-menu-item-{{i}}\" [ngClass]=\"{'menu-item-hide': item.hidden}\" (click)=\"toggleMenu(item)\" [@itemAnim]>\r\n        <i *ngIf=\"item.iconStart\" class=\"kdx-visualization-icon-start fa {{item.iconStart}}\"></i>\r\n        <span *ngIf=\"item.text\">{{item.text}}</span>\r\n        <i *ngIf=\"item.iconEnd\" class=\"kdx-visualization-icon-end fa {{item.iconEnd}}\" [ngClass]=\"{'have-expand-arrow': item.expanded !== undefined }\"></i>\r\n    </div>\r\n</div>\r\n<div *ngIf=\"isExportEnabled\" class=\"kdx-visualization-menu-btn-wrapper\">\r\n    <div class=\"kdx-visualization-menu-btn-container {{btnAlignment}}\">\r\n        <button class=\"kdx-visualization-menu-btn btn-outline\" (click)=\"toggleMenu()\">\r\n            <i class=\"fa {{menuBtnIconClass}} {{menuFlag}}\"></i>\r\n        </button>\r\n    </div>\r\n</div>\r\n",
                encapsulation: ViewEncapsulation.None,
                providers: [KdVisualizationSvc, KdDomElemSvc],
                host: {
                    'class': 'kdx-visualization',
                },
                animations: [
                    trigger('itemAnim', [
                        transition(':enter', [
                            style({ transform: 'translateY(100%)' }),
                            animate('0.2s 0.2s ease-in')
                        ]),
                    ])
                ]
            },] }
];
KdVisualization.ctorParameters = () => [
    { type: ElementRef },
    { type: KdVisualizationSvc },
    { type: ChangeDetectorRef }
];
KdVisualization.propDecorators = {
    data: [{ type: Input, args: ['data',] }],
    rawData: [{ type: Input, args: ['rawData',] }],
    config: [{ type: Input, args: ['config',] }],
    xThreshold: [{ type: Input }],
    seriesThreshold: [{ type: Input }],
    api: [{ type: Input }],
    outputLegendData: [{ type: Output }],
    errorMsg: [{ type: Output }],
    outputArea: [{ type: Output }],
    invisibleChart: [{ type: ViewChild, args: ['invisibleChart',] }]
};
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoia2QtYW5ndWxhci12aXN1YWxpemF0aW9uLmpzIiwic291cmNlUm9vdCI6IkQ6L29wZW5FTUlTL3N0eWxlZ3VpZGUvaW9zdGctb3BlbmVtaXMtc3R5bGVndWlkZS9wcm9qZWN0cy9vcGVuZW1pcy1zdHlsZWd1aWRlLWxpYi9zcmMvIiwic291cmNlcyI6WyJrZC1jb21wb25lbnRzL2tkLWFuZ3VsYXItdmlzdWFsaXphdGlvbi9rZC1hbmd1bGFyLXZpc3VhbGl6YXRpb24udHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsT0FBTyxFQUNILFNBQVMsRUFDVCxpQkFBaUIsRUFDakIsS0FBSyxFQUVMLE1BQU0sRUFHTixZQUFZLEVBQ1osVUFBVSxFQUNWLGlCQUFpQixFQUNqQixTQUFTLEVBQ1osTUFBTSxlQUFlLENBQUM7QUFDdkIsT0FBTyxFQUFFLFVBQVUsRUFBWSxNQUFNLE1BQU0sQ0FBQztBQUM1QyxPQUFPLEVBQUUsT0FBTyxFQUFFLEtBQUssRUFBRSxVQUFVLEVBQUUsT0FBTyxFQUFFLE1BQU0scUJBQXFCLENBQUM7QUFDMUUsT0FBTyxFQUFFLGNBQWMsRUFBc0MsTUFBTSxzQ0FBc0MsQ0FBQztBQUUxRyxPQUFPLEVBQUUsa0JBQWtCLEVBQUUsTUFBTSxnQ0FBZ0MsQ0FBQztBQUNwRSxPQUFPLEVBQUUscUJBQXFCLEVBQUUsTUFBTSxtQ0FBbUMsQ0FBQztBQUMxRSxPQUFPLEVBQUUsWUFBWSxFQUFFLE1BQU0sb0JBQW9CLENBQUM7QUFDbEQsT0FBTyxFQUFFLFFBQVEsRUFBRSxNQUFNLDRCQUE0QixDQUFDO0FBb0J0RCxNQUFNLE9BQU8sZUFBZTtJQXdEeEIsWUFDWSxRQUFvQixFQUNwQixpQkFBcUMsRUFDckMsR0FBc0I7UUFGdEIsYUFBUSxHQUFSLFFBQVEsQ0FBWTtRQUNwQixzQkFBaUIsR0FBakIsaUJBQWlCLENBQW9CO1FBQ3JDLFFBQUcsR0FBSCxHQUFHLENBQW1CO1FBMURsQyxVQUFVO1FBQ0gsb0JBQWUsR0FBWSxLQUFLLENBQUM7UUFDakMsZUFBVSxHQUFZLEtBQUssQ0FBQztRQUM1QixhQUFRLEdBQWdELFFBQVEsQ0FBQyxDQUFDLHFEQUFxRDtRQUN2SCxtQkFBYyxHQUFHLEVBQUUsQ0FBQztRQUNuQixhQUFRLEdBQWdCLEVBQUUsQ0FBQztRQUk1QixxQkFBZ0IsR0FBVyxlQUFlLENBQUM7UUFDMUMsaUJBQVksR0FBeUU7WUFDekYsTUFBTSxFQUFFLGVBQWU7WUFDdkIsTUFBTSxFQUFFLFVBQVU7WUFDbEIsTUFBTSxFQUFFLFVBQVU7WUFDbEIsUUFBUSxFQUFFLGlCQUFpQjtTQUM5QixDQUFDO1FBRUYscUJBQXFCO1FBQ2QsY0FBUyxHQUFZLEtBQUssQ0FBQztRQUNsQyxtSEFBbUg7UUFDNUcsMEJBQXFCLEdBQVksSUFBSSxDQUFDO1FBQ3RDLDRCQUF1QixHQUFpQixJQUFJLENBQUM7UUFJN0Msd0JBQW1CLEdBQVcsbUNBQW1DLENBQUM7UUFDakUsdUJBQWtCLEdBQVcsUUFBUSxDQUFDO1FBRTlDLFVBQVU7UUFDSCxpQkFBWSxHQUFXLE9BQU8sQ0FBQyxDQUFDLG9DQUFvQztRQUVwRSxnQkFBVyxHQUFZLEtBQUssQ0FBQztRQVU1QixtQkFBYyxHQUFXLElBQUksQ0FBQztRQVE1QixxQkFBZ0IsR0FBaUQsSUFBSSxZQUFZLEVBQUUsQ0FBQztRQUNwRixhQUFRLEdBQXlCLElBQUksWUFBWSxFQUFFLENBQUM7UUFDcEQsZUFBVSxHQUEwQixJQUFJLFlBQVksRUFBRSxDQUFDO1FBUzdELElBQUksQ0FBQyxPQUFPLEdBQUcsSUFBSSxxQkFBcUIsRUFBRSxDQUFDO1FBQzNDLElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxpQkFBaUIsR0FBRyxJQUFJLENBQUMsUUFBUSxDQUFDLGFBQWEsQ0FBQztJQUMzRSxDQUFDO0lBRUQsUUFBUTtRQUNKLElBQUksQ0FBQyxRQUFRLEVBQUUsQ0FBQztJQUNwQixDQUFDO0lBRUQsV0FBVyxDQUFDLGNBQTZCO1FBQ3JDLElBQUksY0FBYyxDQUFDLGNBQWMsQ0FBQyxRQUFRLENBQUMsSUFBSSxjQUFjLENBQUMsTUFBTSxDQUFDLFlBQVksRUFBRTtZQUMvRSxJQUFJLENBQUMsVUFBVSxDQUFDLGNBQWMsQ0FBQyxNQUFNLENBQUMsWUFBWSxDQUFDLE1BQU0sQ0FBQyxDQUFDO1NBQzlEO1FBRUQsSUFBSSxjQUFjLENBQUMsY0FBYyxDQUFDLFNBQVMsQ0FBQyxJQUFJLGNBQWMsQ0FBQyxPQUFPLENBQUMsWUFBWSxFQUFFO1lBQ2pGLElBQUksQ0FBQyxpQkFBaUIsR0FBRyxJQUFJLENBQUMsaUJBQWlCLENBQUMsYUFBYSxDQUFDLGNBQWMsQ0FBQyxPQUFPLENBQUMsWUFBWSxDQUFDLE1BQU0sQ0FBQyxDQUFDO1NBQzdHO0lBQ0wsQ0FBQztJQUVNLGFBQWEsQ0FBQyxLQUFjO1FBQy9CLElBQUksQ0FBQyxnQkFBZ0IsR0FBRyxLQUFLLENBQUM7SUFDbEMsQ0FBQztJQUVNLG1CQUFtQixDQUFDLFdBQTJDO1FBQ2xFLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFDLENBQUM7UUFDeEMsSUFBSSxDQUFDLHNCQUFzQixHQUFHLFdBQVcsQ0FBQztJQUM5QyxDQUFDO0lBRU0sT0FBTyxDQUFDLEtBQUs7UUFDaEIsSUFBSSxDQUFDLFVBQVUsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLENBQUM7SUFDaEMsQ0FBQztJQUVNLHFCQUFxQjtRQUN4QixJQUFJLElBQUksQ0FBQyxXQUFXLEVBQUU7WUFDbEIsSUFBSSxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsT0FBTyxDQUFDLGFBQWEsQ0FBQyxFQUFFLFFBQVEsRUFBRSxJQUFJLENBQUMsU0FBUyxFQUFFLENBQUMsQ0FBQztZQUNyRSxJQUFJLENBQUMsV0FBVyxHQUFHLEtBQUssQ0FBQztTQUM1QjtJQUNMLENBQUM7SUFFRCw4RUFBOEU7SUFFdEUsVUFBVSxDQUFDLE9BQXFCO1FBQ3BDLHNEQUFzRDtRQUN0RCxJQUFJLENBQUMsWUFBWSxHQUFHLE9BQU8sQ0FBQztRQUM1QixJQUFJLENBQUMsUUFBUSxHQUFHLFFBQVEsQ0FBQztRQUN6QixJQUFJLENBQUMsVUFBVSxHQUFHLEtBQUssQ0FBQztRQUV4QixJQUFJLENBQUMsZUFBZSxHQUFHLE9BQU8sSUFBSSxPQUFPLENBQUMsT0FBTyxDQUFDO1FBRWxELElBQUksQ0FBQyxJQUFJLENBQUMsZUFBZTtZQUFFLE9BQU87UUFFbEMsSUFBSSxDQUFDLFlBQVksQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLENBQUM7UUFFaEMsSUFBSSxDQUFDLG1CQUFtQixHQUFHLEVBQUUsT0FBTyxFQUFFLE9BQU8sQ0FBQyxLQUFLLElBQUksSUFBSSxDQUFDLGtCQUFrQixFQUFFLENBQUM7UUFDakYsSUFBSSxDQUFDLFlBQVksR0FBRyxJQUFJLENBQUMsaUJBQWlCLENBQUMsZUFBZSxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsQ0FBQztRQUV4RSxJQUFJLENBQUMsZ0JBQWdCLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxDQUFDO0lBQ3ZDLENBQUM7SUFFTyxnQkFBZ0IsQ0FBQyxVQUFxRTtRQUMxRixJQUFJLFVBQVUsSUFBSSxVQUFVLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLEtBQUssRUFBRTtZQUNsRCxJQUFJLENBQUMsZ0JBQWdCLEdBQUcsaUJBQWlCLENBQUM7WUFDMUMsSUFBSSxDQUFDLFlBQVksQ0FBQyxNQUFNLEdBQUcsaUJBQWlCLENBQUM7U0FDaEQ7YUFBTTtZQUNILElBQUksQ0FBQyxnQkFBZ0IsR0FBRyxlQUFlLENBQUM7WUFDeEMsSUFBSSxDQUFDLFlBQVksQ0FBQyxNQUFNLEdBQUcsZUFBZSxDQUFDO1NBQzlDO0lBQ0wsQ0FBQztJQUVPLFlBQVksQ0FBQyxLQUFrQjtRQUNuQyxJQUFJLE9BQU8sR0FBRyxJQUFJLENBQUMsaUJBQWlCLENBQUMsbUJBQW1CLENBQUMsY0FBYyxDQUFDLENBQUM7UUFFekUsOEVBQThFO1FBQzlFLElBQUksSUFBSSxDQUFDLEdBQUcsSUFBSSxJQUFJLENBQUMsR0FBRyxDQUFDLGNBQWMsQ0FBQyxxQkFBcUIsQ0FBQyxFQUFFO1lBQzVELE9BQU8sR0FBRyxJQUFJLENBQUMsaUJBQWlCLENBQUMsa0JBQWtCLENBQUMsT0FBTyxFQUFFLElBQUksQ0FBQyxHQUFHLENBQUMsbUJBQW1CLENBQUMsQ0FBQztTQUM5RjtRQUVELElBQUksQ0FBQyxRQUFRLEdBQUcsT0FBTyxDQUFDLE1BQU0sQ0FBQyxLQUFLLElBQUksRUFBRSxDQUFDLENBQUM7UUFDNUMsSUFBSSxDQUFDLElBQUksQ0FBQyxPQUFPO1lBQUUsSUFBSSxDQUFDLFFBQVEsR0FBRyxJQUFJLENBQUMsUUFBUSxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDLElBQUksQ0FBQyxFQUFFLEtBQUssVUFBVSxJQUFJLElBQUksQ0FBQyxFQUFFLEtBQUssT0FBTyxDQUFDLENBQUM7UUFDL0csSUFBSSxDQUFDLGNBQWMsR0FBRyxJQUFJLENBQUMsUUFBUSxDQUFDO0lBQ3hDLENBQUM7SUFFRCx3RkFBd0Y7SUFFaEYsUUFBUTtRQUNaLElBQUksQ0FBQyxJQUFJLENBQUMsR0FBRztZQUFFLE9BQU87UUFFdEIsSUFBSSxDQUFDLEdBQUcsQ0FBQyxXQUFXLEdBQUcsQ0FBQyxZQUF5QixFQUFRLEVBQUU7WUFDdkQsSUFBSSxDQUFDLFFBQVEsR0FBRyxJQUFJLENBQUMsUUFBUSxDQUFDLE1BQU0sQ0FBQyxZQUFZLENBQUMsQ0FBQztZQUNuRCxJQUFJLENBQUMsR0FBRyxDQUFDLGFBQWEsRUFBRSxDQUFDO1FBQzdCLENBQUMsQ0FBQztRQUNGLElBQUksQ0FBQyxHQUFHLENBQUMsZ0JBQWdCLEdBQUcsQ0FBQyxHQUFXLEVBQUUsVUFBbUIsSUFBSSxFQUFRLEVBQUU7WUFDdkUsSUFBSSxDQUFDLGlCQUFpQixDQUFDLHFCQUFxQixDQUFDLElBQUksRUFBRSxHQUFHLEVBQUUsT0FBTyxFQUFFLElBQUksQ0FBQyxRQUFRLENBQUMsQ0FBQztZQUNoRixJQUFJLENBQUMsR0FBRyxDQUFDLGFBQWEsRUFBRSxDQUFDO1FBQzdCLENBQUMsQ0FBQztRQUNGLElBQUksQ0FBQyxHQUFHLENBQUMsb0JBQW9CLEdBQUcsQ0FBQyxPQUFlLEVBQUUsVUFBbUIsSUFBSSxFQUFRLEVBQUU7WUFDL0UsSUFBSSxDQUFDLGlCQUFpQixDQUFDLHFCQUFxQixDQUFDLFFBQVEsRUFBRSxPQUFPLEVBQUUsT0FBTyxFQUFFLElBQUksQ0FBQyxRQUFRLENBQUMsQ0FBQztZQUN4RixJQUFJLENBQUMsR0FBRyxDQUFDLGFBQWEsRUFBRSxDQUFDO1FBQzdCLENBQUMsQ0FBQztRQUNGLElBQUksQ0FBQyxHQUFHLENBQUMsVUFBVSxHQUFHLENBQUMsTUFBZSxFQUFFLFFBQW1CLEVBQUUscUJBQStCLEVBQXNCLEVBQUU7WUFDaEgsT0FBTyxJQUFJLFVBQVUsQ0FBUyxDQUFDLFNBQTJCLEVBQUUsRUFBRTtnQkFDMUQsSUFBSSxhQUFhLEdBQVcsRUFBRSxDQUFDO2dCQUMvQixJQUFJLE1BQU0sRUFBRTtvQkFDUixhQUFhLEdBQUcsTUFBTSxDQUFDLE1BQU0sQ0FBQyxFQUFFLEVBQUUsSUFBSSxDQUFDLG1CQUFtQixDQUFDLENBQUM7b0JBQzVELElBQUksQ0FBQyxtQkFBbUIsR0FBRyxNQUFNLENBQUM7aUJBQ3JDO2dCQUNELElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxVQUFVLEVBQUUsUUFBUSxFQUFFLHFCQUFxQixDQUFDLENBQUMsU0FBUyxDQUFDLENBQUMsU0FBUyxFQUFFLEVBQUU7b0JBQ3ZGLElBQUcsTUFBTTt3QkFBRSxJQUFJLENBQUMsbUJBQW1CLEdBQUcsYUFBYSxDQUFDO29CQUNwRCxTQUFTLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDO29CQUMxQixTQUFTLENBQUMsUUFBUSxFQUFFLENBQUM7Z0JBQ3pCLENBQUMsQ0FBQyxDQUFDO1lBQ1AsQ0FBQyxDQUFDLENBQUM7UUFDUCxDQUFDLENBQUM7UUFFRixJQUFJLENBQUMsR0FBRyxDQUFDLFdBQVcsR0FBRyxDQUFDLFVBQW1CLEVBQUUsT0FBbUIsRUFBUSxFQUFFO1lBQ3RFLE9BQU8sQ0FBQyxNQUFNLEdBQUcsTUFBTSxDQUFDLE1BQU0sQ0FBQyxFQUFFLEVBQUUsSUFBSSxDQUFDLE9BQU8sQ0FBQyxNQUFNLEVBQUUsT0FBTyxDQUFDLE1BQU0sQ0FBQyxDQUFDO1lBQ3hFLElBQUksQ0FBQyxPQUFPLEdBQUcsTUFBTSxDQUFDLE1BQU0sQ0FBQyxFQUFFLEVBQUUsT0FBTyxDQUFDLENBQUM7WUFDMUMsSUFBSSxDQUFDLGlCQUFpQixHQUFHLElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxhQUFhLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxDQUFDO1lBQzlFLElBQUksVUFBVSxFQUFFO2dCQUNaLElBQUksQ0FBQyxVQUFVLEdBQUcsSUFBSSxDQUFDLFlBQVksQ0FBQztnQkFDcEMsSUFBSSxJQUFJLENBQUMsWUFBWSxLQUFLLE9BQU8sRUFBRTtvQkFDL0IsSUFBSSxDQUFDLFlBQVksR0FBRyxPQUFPLENBQUM7b0JBQzVCLElBQUksQ0FBQyxZQUFZLENBQUMsWUFBWSxDQUFDLENBQUM7aUJBQ25DO2dCQUVELElBQUksQ0FBQyxlQUFlLEdBQUcsS0FBSyxDQUFDO2FBQ2hDO2lCQUFNO2dCQUNILElBQUksQ0FBQyxlQUFlLEdBQUcsT0FBTyxJQUFJLENBQUMsTUFBTSxLQUFLLFdBQVcsSUFBSSxJQUFJLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxPQUFPLENBQUM7Z0JBQ3hGLElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxlQUFlLENBQUMsT0FBTyxDQUFDLENBQUM7Z0JBQ2hELElBQUksQ0FBQyxZQUFZLEdBQUcsSUFBSSxDQUFDLFVBQVUsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDO2FBQ25FO1FBQ0wsQ0FBQyxDQUFBO0lBQ0wsQ0FBQztJQUVELG9GQUFvRjtJQUU3RSxVQUFVLENBQUMsS0FBVztRQUN6QixJQUFJLGFBQWEsR0FBWSxLQUFLLElBQUksS0FBSyxDQUFDLFNBQVMsQ0FBQztRQUN0RCxJQUFJLFlBQVksR0FBWSxLQUFLLElBQUksS0FBSyxDQUFDLFFBQVEsQ0FBQztRQUVwRCxJQUFJLGFBQWE7WUFBRSxJQUFJLENBQUMsWUFBWSxDQUFDLEtBQUssQ0FBQyxTQUFTLENBQUMsQ0FBQztRQUN0RCxJQUFJLFlBQVk7WUFBRSxLQUFLLENBQUMsUUFBUSxFQUFFLENBQUM7UUFFbkMsSUFBSSxDQUFDLGVBQWUsQ0FBQyxJQUFJLENBQUMsUUFBUSxFQUFFLEtBQUssRUFBRSxhQUFhLElBQUksWUFBWSxDQUFDLENBQUM7UUFFMUUsSUFBSSxDQUFDLGdCQUFnQixHQUFHLElBQUksQ0FBQyxZQUFZLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxDQUFDO1FBRXpELElBQUksQ0FBQyxVQUFVLEdBQUcsSUFBSSxDQUFDLFFBQVEsS0FBSyxRQUFRLElBQUksSUFBSSxDQUFDLFFBQVEsS0FBSyxVQUFVLENBQUM7SUFDakYsQ0FBQztJQUVPLGVBQWUsQ0FBQyxLQUFhLEVBQUUsS0FBVyxFQUFFLFlBQXNCO1FBQ3RFLFFBQVEsS0FBSyxFQUFFO1lBQ1gsS0FBSyxRQUFRLENBQUM7WUFDZDtnQkFDSSxJQUFJLENBQUMsUUFBUSxHQUFHLFFBQVEsQ0FBQztnQkFDekIsTUFBTTtZQUNWLEtBQUssUUFBUTtnQkFDVCxJQUFJLFFBQVEsR0FBWSxLQUFLLElBQUksS0FBSyxDQUFDLFFBQVEsQ0FBQztnQkFDaEQsSUFBSSxRQUFRLEVBQUU7b0JBQ1YsSUFBSSxDQUFDLGNBQWMsR0FBRyxLQUFLLENBQUMsUUFBUSxDQUFDO29CQUNyQyxJQUFJLENBQUMsUUFBUSxHQUFHLFVBQVUsQ0FBQztvQkFDM0IsT0FBTztpQkFDVjtnQkFDRCxJQUFJLE1BQU0sR0FBWSxLQUFLLENBQUM7Z0JBQzVCLElBQUksS0FBSyxJQUFJLEtBQUssQ0FBQyxjQUFjLENBQUMsV0FBVyxDQUFDLEVBQUU7b0JBQzVDLE1BQU0sR0FBRyxLQUFLLElBQUksS0FBSyxDQUFDLFNBQVMsQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUM7b0JBQ3ZELElBQUksTUFBTTt3QkFBRSxJQUFJLENBQUMsWUFBWSxHQUFHLEtBQUssQ0FBQyxTQUFTLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO2lCQUNqRTtnQkFDRCxJQUFJLENBQUMsUUFBUSxHQUFHLE1BQU0sQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUM7Z0JBQzdDLE1BQU07WUFDVixLQUFLLFVBQVU7Z0JBQ1gsSUFBSSxDQUFDLFFBQVEsR0FBRyxZQUFZLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDO2dCQUNuRCxJQUFJLENBQUMsY0FBYyxHQUFHLElBQUksQ0FBQyxRQUFRLENBQUM7Z0JBQ3BDLE1BQU07WUFDVixLQUFLLFFBQVE7Z0JBQ1QsSUFBSSxDQUFDLGlCQUFpQixDQUFDLGVBQWUsQ0FBQyxPQUFPLENBQUMsQ0FBQztnQkFDaEQsSUFBSSxDQUFDLFFBQVEsR0FBRyxRQUFRLENBQUM7Z0JBQ3pCLElBQUksQ0FBQyxZQUFZLEdBQUcsT0FBTyxDQUFDO2dCQUM1QixNQUFNO1NBQ2I7SUFDTCxDQUFDO0lBRU8sWUFBWSxDQUFDLFVBQWtCO1FBRW5DLGdDQUFnQztRQUNoQyxJQUFJLFlBQVksR0FBRyxVQUFVLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDO1FBRXpDLElBQUksWUFBWSxDQUFDLENBQUMsQ0FBQyxLQUFLLE1BQU0sSUFBSSxZQUFZLENBQUMsQ0FBQyxDQUFDLEtBQUssT0FBTyxFQUFFO1lBQzNELElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxnQkFBZ0IsQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxDQUFDO1lBQzdELE9BQU87U0FDVjtRQUVELElBQUksWUFBWSxDQUFDLENBQUMsQ0FBQyxLQUFLLFFBQVE7WUFBRSxPQUFPO1FBRXpDLElBQUksSUFBSSxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsSUFBSTtZQUFFLElBQUksQ0FBQyxTQUFTLEdBQUcsSUFBSSxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxLQUFLLEVBQUUsR0FBRyxDQUFDLENBQUM7UUFFeEYsSUFBSSxZQUFZLENBQUMsQ0FBQyxDQUFDLEtBQUssT0FBTyxFQUFFO1lBQzdCLElBQUksQ0FBQyxXQUFXLEdBQUcsSUFBSSxDQUFDO1NBQzNCO2FBQU07WUFDSCxJQUFJLENBQUMsZ0JBQWdCLENBQUMsWUFBWSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDLEdBQUUsRUFBRSxHQUFDLENBQUMsQ0FBQyxDQUFDO1NBQzVEO0lBQ0wsQ0FBQztJQUVPLGdCQUFnQixDQUFDLFVBQWtCLEVBQUUsV0FBcUIsRUFBRSxFQUFFLHdCQUFpQyxJQUFJO1FBQ3ZHLE9BQU8sSUFBSSxVQUFVLENBQVMsQ0FBQyxTQUEyQixFQUFFLEVBQUU7WUFDMUQsSUFBSSxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsa0JBQWtCLEVBQUUsRUFBRTtnQkFDcEMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxlQUFlLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQztnQkFDN0QsU0FBUyxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLGVBQWUsQ0FBQyxVQUFVLENBQUMsQ0FBQyxDQUFDO2dCQUMxRCxTQUFTLENBQUMsUUFBUSxFQUFFLENBQUM7YUFDeEI7aUJBQU07Z0JBQ0gsaUVBQWlFO2dCQUNqRSxJQUFJLENBQUMsdUJBQXVCLEdBQUcsTUFBTSxDQUFDLE1BQU0sQ0FBQyxFQUFFLEVBQUUsSUFBSSxDQUFDLE1BQU0sRUFBRSxFQUFFLEVBQUUsRUFBRSxjQUFjLEVBQUUsU0FBUyxFQUFFLEtBQUssRUFBRSxXQUFXLEVBQUUsSUFBSSxFQUFFLENBQUMsQ0FBQztnQkFDM0gsSUFBSSxDQUFDLFNBQVMsR0FBRyxJQUFJLENBQUM7Z0JBRXRCLDRDQUE0QztnQkFDNUMsVUFBVSxDQUFDLEdBQUcsRUFBRTtvQkFDWix1RkFBdUY7b0JBQ3ZGLElBQUksQ0FBQyxjQUFjLENBQUMsYUFBYSxDQUFDLElBQUksQ0FBQyxzQkFBc0IsQ0FBQyxDQUFDO29CQUMvRCxnREFBZ0Q7b0JBQ2hELElBQUksQ0FBQyxxQkFBcUIsR0FBRyxJQUFJLENBQUMsZ0JBQWdCLENBQUM7Z0JBQ3ZELENBQUMsQ0FBQyxDQUFDO2dCQUVILElBQUksT0FBTyxHQUFhLE1BQU0sQ0FBQyxNQUFNLENBQUMsRUFBRSxFQUFFLFFBQVEsQ0FBQyxDQUFDO2dCQUNwRCxJQUFJLElBQUksQ0FBQyxTQUFTO29CQUFFLE9BQU8sQ0FBQyxVQUFVLENBQUMsR0FBRyxJQUFJLENBQUMsU0FBUyxDQUFDO2dCQUV6RCxVQUFVLENBQUMsR0FBRyxFQUFFO29CQUNaLElBQUksWUFBWSxHQUFHLElBQUksQ0FBQyxRQUFRLENBQUMsYUFBYSxDQUFDLGFBQWEsQ0FBQyxHQUFHLEdBQUcsSUFBSSxDQUFDLG1CQUFtQixHQUFHLGFBQWEsQ0FBQyxDQUFDO29CQUU3RyxpREFBaUQ7b0JBQ2pELElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxXQUFXLENBQUMsWUFBWSxDQUFDLENBQUM7b0JBQ2pELElBQUkscUJBQXFCO3dCQUFFLElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxrQkFBa0IsQ0FBQyxZQUFZLENBQUMsQ0FBQztvQkFDbkYsWUFBWSxDQUFDLEtBQUssQ0FBQyxNQUFNLEdBQUcsTUFBTSxDQUFDO29CQUVuQyxPQUFPLENBQUMsT0FBTyxDQUFDLEdBQUcsWUFBWSxDQUFDLHFCQUFxQixFQUFFLENBQUMsS0FBSyxHQUFHLENBQUMsQ0FBQztvQkFDbEUsT0FBTyxDQUFDLFFBQVEsQ0FBQyxHQUFHLFlBQVksQ0FBQyxxQkFBcUIsRUFBRSxDQUFDLE1BQU0sR0FBRyxDQUFDLENBQUM7b0JBRXBFLElBQUksTUFBTSxHQUFHLElBQUksQ0FBQyxPQUFPLENBQUMsYUFBYSxDQUFDLFlBQVksRUFBRSxVQUFVLEVBQUUsT0FBTyxDQUFDLENBQUM7b0JBRTNFLDJEQUEyRDtvQkFDM0QsSUFBSSxDQUFDLFNBQVMsR0FBRyxLQUFLLENBQUM7b0JBQ3ZCLElBQUksQ0FBQyxxQkFBcUIsR0FBRyxJQUFJLENBQUM7b0JBRWxDLElBQUksTUFBTSxFQUFFO3dCQUNSLE1BQU0sQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLEVBQUU7NEJBQ2xCLFNBQVMsQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLENBQUM7NEJBQ3hCLFNBQVMsQ0FBQyxRQUFRLEVBQUUsQ0FBQzt3QkFDekIsQ0FBQyxDQUFDLENBQUE7cUJBQ0w7eUJBQU07d0JBQ0gsU0FBUyxDQUFDLFFBQVEsRUFBRSxDQUFDO3FCQUN4QjtnQkFDTCxDQUFDLEVBQUUsSUFBSSxDQUFDLGNBQWMsQ0FBQyxDQUFDO2FBQzNCO1FBQ0wsQ0FBQyxDQUFDLENBQUM7SUFFUCxDQUFDOzs7WUE1VUosU0FBUyxTQUFDO2dCQUNQLFFBQVEsRUFBRSxrQkFBa0I7Z0JBQzVCLDQ3RUFBNEM7Z0JBQzVDLGFBQWEsRUFBRSxpQkFBaUIsQ0FBQyxJQUFJO2dCQUNyQyxTQUFTLEVBQUUsQ0FBQyxrQkFBa0IsRUFBRSxZQUFZLENBQUM7Z0JBQzdDLElBQUksRUFBRTtvQkFDRixPQUFPLEVBQUUsbUJBQW1CO2lCQUMvQjtnQkFDRCxVQUFVLEVBQUU7b0JBQ1IsT0FBTyxDQUFDLFVBQVUsRUFBRTt3QkFDaEIsVUFBVSxDQUFDLFFBQVEsRUFBRTs0QkFDakIsS0FBSyxDQUFDLEVBQUUsU0FBUyxFQUFFLGtCQUFrQixFQUFFLENBQUM7NEJBQ3hDLE9BQU8sQ0FBQyxtQkFBbUIsQ0FBQzt5QkFDL0IsQ0FBQztxQkFDTCxDQUFDO2lCQUNMO2FBQ0o7OztZQTdCRyxVQUFVO1lBUUwsa0JBQWtCO1lBUHZCLGlCQUFpQjs7O21CQTBFaEIsS0FBSyxTQUFDLE1BQU07c0JBQ1osS0FBSyxTQUFDLFNBQVM7cUJBQ2YsS0FBSyxTQUFDLFFBQVE7eUJBQ2QsS0FBSzs4QkFDTCxLQUFLO2tCQUNMLEtBQUs7K0JBQ0wsTUFBTTt1QkFDTixNQUFNO3lCQUNOLE1BQU07NkJBRU4sU0FBUyxTQUFDLGdCQUFnQiIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7XHJcbiAgICBDb21wb25lbnQsXHJcbiAgICBWaWV3RW5jYXBzdWxhdGlvbixcclxuICAgIElucHV0LFxyXG4gICAgT25Jbml0LFxyXG4gICAgT3V0cHV0LFxyXG4gICAgT25DaGFuZ2VzLFxyXG4gICAgU2ltcGxlQ2hhbmdlcyxcclxuICAgIEV2ZW50RW1pdHRlcixcclxuICAgIEVsZW1lbnRSZWYsXHJcbiAgICBDaGFuZ2VEZXRlY3RvclJlZixcclxuICAgIFZpZXdDaGlsZFxyXG59IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xyXG5pbXBvcnQgeyBPYnNlcnZhYmxlLCBPYnNlcnZlciB9IGZyb20gJ3J4anMnO1xyXG5pbXBvcnQgeyB0cmlnZ2VyLCBzdHlsZSwgdHJhbnNpdGlvbiwgYW5pbWF0ZSB9IGZyb20gJ0Bhbmd1bGFyL2FuaW1hdGlvbnMnO1xyXG5pbXBvcnQgeyBkZWZhdWx0TWVudUFyciwgSU9wdGlvbnMsIElUYWJsZURhdGEsIElUYWJsZUNvbHVtbiB9IGZyb20gJy4va2QtYW5ndWxhci12aXN1YWxpemF0aW9uLWludGVyZmFjZSc7XHJcbmltcG9ydCB7IElDaGFydEV4cG9ydCwgSUQzRGF0YSwgSUNoYXJ0Q29uZmlnLCBJTWVudUl0ZW0sIElMZWdlbmREYXRhLCBJQ2hhcnREYXRhIH0gZnJvbSAnLi4va2QtYW5ndWxhci1jaGFydHMva2QtYW5ndWxhci1jaGFydHMtaW50ZXJmYWNlJztcclxuaW1wb3J0IHsgS2RWaXN1YWxpemF0aW9uU3ZjIH0gZnJvbSAnLi9rZC1hbmd1bGFyLXZpc3VhbGl6YXRpb24tc3ZjJztcclxuaW1wb3J0IHsgS2RWaXN1YWxpemF0aW9uRXhwb3J0IH0gZnJvbSAnLi9rZC1hbmd1bGFyLXZpc3VhbGl6YXRpb24tZXhwb3J0JztcclxuaW1wb3J0IHsgS2REb21FbGVtU3ZjIH0gZnJvbSAnLi4va2QtY29tbW9uL2luZGV4JztcclxuaW1wb3J0IHsgS2RDaGFydHMgfSBmcm9tICcuLi9rZC1hbmd1bGFyLWNoYXJ0cy9pbmRleCc7XHJcblxyXG5AQ29tcG9uZW50KHtcclxuICAgIHNlbGVjdG9yOiAna2QtdmlzdWFsaXphdGlvbicsXHJcbiAgICB0ZW1wbGF0ZVVybDogJ2tkLWFuZ3VsYXItdmlzdWFsaXphdGlvbi5odG1sJyxcclxuICAgIGVuY2Fwc3VsYXRpb246IFZpZXdFbmNhcHN1bGF0aW9uLk5vbmUsXHJcbiAgICBwcm92aWRlcnM6IFtLZFZpc3VhbGl6YXRpb25TdmMsIEtkRG9tRWxlbVN2Y10sXHJcbiAgICBob3N0OiB7XHJcbiAgICAgICAgJ2NsYXNzJzogJ2tkeC12aXN1YWxpemF0aW9uJyxcclxuICAgIH0sXHJcbiAgICBhbmltYXRpb25zOiBbXHJcbiAgICAgICAgdHJpZ2dlcignaXRlbUFuaW0nLCBbXHJcbiAgICAgICAgICAgIHRyYW5zaXRpb24oJzplbnRlcicsIFtcclxuICAgICAgICAgICAgICAgIHN0eWxlKHsgdHJhbnNmb3JtOiAndHJhbnNsYXRlWSgxMDAlKScgfSksXHJcbiAgICAgICAgICAgICAgICBhbmltYXRlKCcwLjJzIDAuMnMgZWFzZS1pbicpXHJcbiAgICAgICAgICAgIF0pLFxyXG4gICAgICAgIF0pXHJcbiAgICBdXHJcbn0pXHJcblxyXG5leHBvcnQgY2xhc3MgS2RWaXN1YWxpemF0aW9uIGltcGxlbWVudHMgT25Jbml0LCBPbkNoYW5nZXMge1xyXG4gICAgLyogbWVudSAqL1xyXG4gICAgcHVibGljIGlzRXhwb3J0RW5hYmxlZDogYm9vbGVhbiA9IGZhbHNlO1xyXG4gICAgcHVibGljIGlzTWVudU9wZW46IGJvb2xlYW4gPSBmYWxzZTtcclxuICAgIHB1YmxpYyBtZW51RmxhZzogJ29wZW5lZCcgfCAnY2xvc2VkJyB8ICdleHBhbmRlZCcgfCAndmlld2VkJyA9ICdjbG9zZWQnOyAvLyBjYW4gYmUgJ29wZW5lZCcgfCAnY2xvc2VkJyB8ICdleHBhbmRlZCcgfCAndmlld2VkJ1xyXG4gICAgcHVibGljIG1lbnVEaXNwbGF5QXJyID0gW107XHJcbiAgICBwcml2YXRlIF9tZW51QXJyOiBJTWVudUl0ZW1bXSA9IFtdO1xyXG5cclxuICAgIC8qIG1lbnUgYnRuIHZhcmlhYmxlcyAqL1xyXG4gICAgcHVibGljIGJ0bkFsaWdubWVudDogc3RyaW5nO1xyXG4gICAgcHVibGljIG1lbnVCdG5JY29uQ2xhc3M6IHN0cmluZyA9ICdmYS1jaGV2cm9uLXVwJztcclxuICAgIHByaXZhdGUgX21lbnVCdG5MaXN0OiB7IGNsb3NlZDogc3RyaW5nLCBvcGVuZWQ6IHN0cmluZywgZXhwYW5kZWQ6IHN0cmluZywgdmlld2VkOiBzdHJpbmcgfSA9IHtcclxuICAgICAgICBjbG9zZWQ6ICdmYS1jaGV2cm9uLXVwJyxcclxuICAgICAgICBvcGVuZWQ6ICdmYS1jbG9zZScsXHJcbiAgICAgICAgdmlld2VkOiAnZmEtY2xvc2UnLFxyXG4gICAgICAgIGV4cGFuZGVkOiAnZmEtY2hldnJvbi1sZWZ0J1xyXG4gICAgfTtcclxuXHJcbiAgICAvKiBpbnZpc2libGUgY2hhcnQgKi9cclxuICAgIHB1YmxpYyBleHBvcnROb3c6IGJvb2xlYW4gPSBmYWxzZTtcclxuICAgIC8qIGluaXRpYWwgbG9hZCBvZiBpbnZpc2libGUgY2hhcnQgc2hvdWxkIG5vdCBzdGFydCBkcmF3aW5nLiBuZWVkIHRvIHdhaXQgZm9yIHNldExlZ2VuZERhdGEsIHRoZW4gZHJhdyBpbiBvbmUgZ28gKi9cclxuICAgIHB1YmxpYyBkYXRhRm9ySW52aXNpYmxlQ2hhcnQ6IElEM0RhdGEgPSBudWxsO1xyXG4gICAgcHVibGljIGNvbmZpZ0ZvckludmlzaWJsZWNoYXJ0OiBJQ2hhcnRDb25maWcgPSBudWxsO1xyXG4gICAgcHVibGljIGRhdGFBZnRlck1hc3NhZ2U6IElEM0RhdGE7XHJcbiAgICBwdWJsaWMgbGVnZW5kRGF0YUFmdGVyTWFzc2FnZTogYW55O1xyXG4gICAgcHVibGljIGludmlzaWJsZUNoYXJ0U3R5bGU6IG9iamVjdDtcclxuICAgIHB1YmxpYyBpbnZpc2libGVDaGFydENsYXNzOiBzdHJpbmcgPSAna2R4LXZpc3VhbGl6YXRpb24tY2hhcnQtaW52aXNpYmxlJztcclxuICAgIHByaXZhdGUgX2RlZmF1bHRDaGFydFdpZHRoOiBzdHJpbmcgPSAnMTAyNHB4JztcclxuXHJcbiAgICAvKiB2aWV3ICovXHJcbiAgICBwdWJsaWMgY29udGVudFN0YXRlOiBzdHJpbmcgPSAnY2hhcnQnOyAvLyBjdXJyZW50bHkgb25seSBoYXZlIGNoYXJ0IHwgdGFibGVcclxuICAgIHB1YmxpYyBjb2x1bW5BZnRlckZpbHRlcjogSVRhYmxlQ29sdW1uW107XHJcbiAgICBwdWJsaWMgZXhwb3J0VGFibGU6IGJvb2xlYW4gPSBmYWxzZTtcclxuICAgIHByaXZhdGUgX2ZpbGVOYW1lOiBzdHJpbmc7XHJcblxyXG4gICAgcHJpdmF0ZSBfdGVtcFN0YXRlOiBzdHJpbmc7XHJcblxyXG4gICAgLyoqXHJcbiAgICAgKiBFeHBvcnQgQ2xhc3NcclxuICAgICAqIFxyXG4gICAgICovXHJcbiAgICBwcml2YXRlIF9leHBvcnQ6IEtkVmlzdWFsaXphdGlvbkV4cG9ydDtcclxuICAgIHByaXZhdGUgX3RpbWVvdXRUaW1pbmc6IG51bWJlciA9IDEwMDA7XHJcblxyXG4gICAgQElucHV0KCdkYXRhJykgZGF0YTogSUNoYXJ0RGF0YTtcclxuICAgIEBJbnB1dCgncmF3RGF0YScpIHJhd0RhdGE6IElUYWJsZURhdGE7XHJcbiAgICBASW5wdXQoJ2NvbmZpZycpIGNvbmZpZzogSUNoYXJ0Q29uZmlnO1xyXG4gICAgQElucHV0KCkgeFRocmVzaG9sZDogbnVtYmVyO1xyXG4gICAgQElucHV0KCkgc2VyaWVzVGhyZXNob2xkOiBudW1iZXI7XHJcbiAgICBASW5wdXQoKSBhcGk6IGFueTtcclxuICAgIEBPdXRwdXQoKSBvdXRwdXRMZWdlbmREYXRhOiBFdmVudEVtaXR0ZXI8eyBba2V5OiBzdHJpbmddOiBJTGVnZW5kRGF0YSB9PiA9IG5ldyBFdmVudEVtaXR0ZXIoKTtcclxuICAgIEBPdXRwdXQoKSBlcnJvck1zZzogRXZlbnRFbWl0dGVyPHN0cmluZz4gPSBuZXcgRXZlbnRFbWl0dGVyKCk7XHJcbiAgICBAT3V0cHV0KCkgb3V0cHV0QXJlYTogRXZlbnRFbWl0dGVyPElEM0RhdGE+ID0gbmV3IEV2ZW50RW1pdHRlcigpO1xyXG5cclxuICAgIEBWaWV3Q2hpbGQoJ2ludmlzaWJsZUNoYXJ0JykgaW52aXNpYmxlQ2hhcnQ6IEtkQ2hhcnRzO1xyXG5cclxuICAgIGNvbnN0cnVjdG9yKFxyXG4gICAgICAgIHByaXZhdGUgX2VsZW1SZWY6IEVsZW1lbnRSZWYsXHJcbiAgICAgICAgcHJpdmF0ZSBfdmlzdWFsaXphdGlvblN2YzogS2RWaXN1YWxpemF0aW9uU3ZjLFxyXG4gICAgICAgIHByaXZhdGUgY2RyOiBDaGFuZ2VEZXRlY3RvclJlZlxyXG4gICAgKSB7XHJcbiAgICAgICAgdGhpcy5fZXhwb3J0ID0gbmV3IEtkVmlzdWFsaXphdGlvbkV4cG9ydCgpO1xyXG4gICAgICAgIHRoaXMuX3Zpc3VhbGl6YXRpb25TdmMudmlzdWFsaXphdGlvbkVsZW0gPSB0aGlzLl9lbGVtUmVmLm5hdGl2ZUVsZW1lbnQ7XHJcbiAgICB9XHJcblxyXG4gICAgbmdPbkluaXQoKTogdm9pZCB7XHJcbiAgICAgICAgdGhpcy5faW5pdEFwaSgpO1xyXG4gICAgfVxyXG5cclxuICAgIG5nT25DaGFuZ2VzKF9zaW1wbGVDaGFuZ2VzOiBTaW1wbGVDaGFuZ2VzKTogdm9pZCB7XHJcbiAgICAgICAgaWYgKF9zaW1wbGVDaGFuZ2VzLmhhc093blByb3BlcnR5KCdjb25maWcnKSAmJiBfc2ltcGxlQ2hhbmdlcy5jb25maWcuY3VycmVudFZhbHVlKSB7XHJcbiAgICAgICAgICAgIHRoaXMuX3NldENvbmZpZyhfc2ltcGxlQ2hhbmdlcy5jb25maWcuY3VycmVudFZhbHVlLmV4cG9ydCk7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICBpZiAoX3NpbXBsZUNoYW5nZXMuaGFzT3duUHJvcGVydHkoJ3Jhd0RhdGEnKSAmJiBfc2ltcGxlQ2hhbmdlcy5yYXdEYXRhLmN1cnJlbnRWYWx1ZSkge1xyXG4gICAgICAgICAgICB0aGlzLmNvbHVtbkFmdGVyRmlsdGVyID0gdGhpcy5fdmlzdWFsaXphdGlvblN2Yy5maWx0ZXJDb2x1bW5zKF9zaW1wbGVDaGFuZ2VzLnJhd0RhdGEuY3VycmVudFZhbHVlLmNvbHVtbik7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIHB1YmxpYyBnZXRPdXRwdXREYXRhKF9kYXRhOiBJRDNEYXRhKTogdm9pZCB7XHJcbiAgICAgICAgdGhpcy5kYXRhQWZ0ZXJNYXNzYWdlID0gX2RhdGE7XHJcbiAgICB9XHJcblxyXG4gICAgcHVibGljIGdldE91dHB1dExlZ2VuZERhdGEoX2xlZ2VuZERhdGE6IHsgW2tleTogc3RyaW5nXTogSUxlZ2VuZERhdGEgfSk6IHZvaWQge1xyXG4gICAgICAgIHRoaXMub3V0cHV0TGVnZW5kRGF0YS5lbWl0KF9sZWdlbmREYXRhKTtcclxuICAgICAgICB0aGlzLmxlZ2VuZERhdGFBZnRlck1hc3NhZ2UgPSBfbGVnZW5kRGF0YTtcclxuICAgIH1cclxuXHJcbiAgICBwdWJsaWMgc2V0QXJlYShfZGF0YSk6IHZvaWQge1xyXG4gICAgICAgIHRoaXMub3V0cHV0QXJlYS5lbWl0KF9kYXRhKTtcclxuICAgIH1cclxuXHJcbiAgICBwdWJsaWMgb25FeHBvcnRFeGNlbFBvc3NpYmxlKCk6IHZvaWQge1xyXG4gICAgICAgIGlmICh0aGlzLmV4cG9ydFRhYmxlKSB7XHJcbiAgICAgICAgICAgIHRoaXMucmF3RGF0YS5hcGkuZ2VuZXJhbC5leHBvcnRUb0V4Y2VsKHsgZmlsZU5hbWU6IHRoaXMuX2ZpbGVOYW1lIH0pO1xyXG4gICAgICAgICAgICB0aGlzLmV4cG9ydFRhYmxlID0gZmFsc2U7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIC8vID09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PSBDb25maWcgPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PVxyXG5cclxuICAgIHByaXZhdGUgX3NldENvbmZpZyhfY29uZmlnOiBJQ2hhcnRFeHBvcnQpOiB2b2lkIHtcclxuICAgICAgICAvLyB3aGVuZXZlciBjb25maWcgY2hhbmdlcywgc2V0IGJhY2sgdG8gZGVmYXVsdCB2YWx1ZXNcclxuICAgICAgICB0aGlzLmNvbnRlbnRTdGF0ZSA9ICdjaGFydCc7XHJcbiAgICAgICAgdGhpcy5tZW51RmxhZyA9ICdjbG9zZWQnO1xyXG4gICAgICAgIHRoaXMuaXNNZW51T3BlbiA9IGZhbHNlO1xyXG5cclxuICAgICAgICB0aGlzLmlzRXhwb3J0RW5hYmxlZCA9IF9jb25maWcgJiYgX2NvbmZpZy5lbmFibGVkO1xyXG5cclxuICAgICAgICBpZiAoIXRoaXMuaXNFeHBvcnRFbmFibGVkKSByZXR1cm47XHJcblxyXG4gICAgICAgIHRoaXMuX3NldEluaXRNZW51KF9jb25maWcubWVudSk7XHJcblxyXG4gICAgICAgIHRoaXMuaW52aXNpYmxlQ2hhcnRTdHlsZSA9IHsgJ3dpZHRoJzogX2NvbmZpZy53aWR0aCB8fCB0aGlzLl9kZWZhdWx0Q2hhcnRXaWR0aCB9O1xyXG4gICAgICAgIHRoaXMuYnRuQWxpZ25tZW50ID0gdGhpcy5fdmlzdWFsaXphdGlvblN2Yy5nZXRCdG5BbGlnbm1lbnQoX2NvbmZpZy5idG4pO1xyXG5cclxuICAgICAgICB0aGlzLl9zZXRJbml0QnRuQ2xhc3MoX2NvbmZpZy5idG4pO1xyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX3NldEluaXRCdG5DbGFzcyhfYnRuQ29uZmlnOiAndG9wLWxlZnQnIHwgJ3RvcC1yaWdodCcgfCAnYm90dG9tLWxlZnQnIHwgJ2JvdHRvbS1yaWdodCcpOiB2b2lkIHtcclxuICAgICAgICBpZiAoX2J0bkNvbmZpZyAmJiBfYnRuQ29uZmlnLnNwbGl0KCctJylbMF0gPT09ICd0b3AnKSB7XHJcbiAgICAgICAgICAgIHRoaXMubWVudUJ0bkljb25DbGFzcyA9ICdmYS1jaGV2cm9uLWRvd24nO1xyXG4gICAgICAgICAgICB0aGlzLl9tZW51QnRuTGlzdC5jbG9zZWQgPSAnZmEtY2hldnJvbi1kb3duJztcclxuICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICB0aGlzLm1lbnVCdG5JY29uQ2xhc3MgPSAnZmEtY2hldnJvbi11cCc7XHJcbiAgICAgICAgICAgIHRoaXMuX21lbnVCdG5MaXN0LmNsb3NlZCA9ICdmYS1jaGV2cm9uLXVwJztcclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfc2V0SW5pdE1lbnUoX21lbnU6IElNZW51SXRlbVtdKTogdm9pZCB7XHJcbiAgICAgICAgbGV0IG1lbnVBcnIgPSB0aGlzLl92aXN1YWxpemF0aW9uU3ZjLmdldEltbXV0YWJsZU1lbnVBcnIoZGVmYXVsdE1lbnVBcnIpO1xyXG5cclxuICAgICAgICAvLyB0cmFuc2xhdGlvbkNhbGxiYWNrIHNob3VsZCB0YWtlIGVuZ2xpc2ggc3RyaW5nIGFuZCByZXR1cm4gdHJhbnNsYXRlZCBzdHJpbmdcclxuICAgICAgICBpZiAodGhpcy5hcGkgJiYgdGhpcy5hcGkuaGFzT3duUHJvcGVydHkoJ3RyYW5zbGF0aW9uQ2FsbGJhY2snKSkge1xyXG4gICAgICAgICAgICBtZW51QXJyID0gdGhpcy5fdmlzdWFsaXphdGlvblN2Yy5zZXRNZW51VHJhbnNsYXRpb24obWVudUFyciwgdGhpcy5hcGkudHJhbnNsYXRpb25DYWxsYmFjayk7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICB0aGlzLl9tZW51QXJyID0gbWVudUFyci5jb25jYXQoX21lbnUgfHwgW10pO1xyXG4gICAgICAgIGlmICghdGhpcy5yYXdEYXRhKSB0aGlzLl9tZW51QXJyID0gdGhpcy5fbWVudUFyci5maWx0ZXIoaXRlbSA9PiBpdGVtLmlkICE9PSAndmlld0RhdGEnICYmIGl0ZW0uaWQgIT09ICdleGNlbCcpO1xyXG4gICAgICAgIHRoaXMubWVudURpc3BsYXlBcnIgPSB0aGlzLl9tZW51QXJyO1xyXG4gICAgfVxyXG5cclxuICAgIC8vID09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PSBJTklUIEFQSSBhbmQgU3ViID09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT1cclxuXHJcbiAgICBwcml2YXRlIF9pbml0QXBpKCkge1xyXG4gICAgICAgIGlmICghdGhpcy5hcGkpIHJldHVybjtcclxuXHJcbiAgICAgICAgdGhpcy5hcGkuYWRkTWVudUl0ZW0gPSAoX21lbnVJdGVtQXJyOiBJTWVudUl0ZW1bXSk6IHZvaWQgPT4ge1xyXG4gICAgICAgICAgICB0aGlzLl9tZW51QXJyID0gdGhpcy5fbWVudUFyci5jb25jYXQoX21lbnVJdGVtQXJyKTtcclxuICAgICAgICAgICAgdGhpcy5jZHIuZGV0ZWN0Q2hhbmdlcygpO1xyXG4gICAgICAgIH07XHJcbiAgICAgICAgdGhpcy5hcGkuaGlkZU1lbnVJdGVtQnlJZCA9IChfaWQ6IHN0cmluZywgX2lzSGlkZTogYm9vbGVhbiA9IHRydWUpOiB2b2lkID0+IHtcclxuICAgICAgICAgICAgdGhpcy5fdmlzdWFsaXphdGlvblN2Yy5zZXRNZW51SXRlbVZpc2liaWxpdHkoJ2lkJywgX2lkLCBfaXNIaWRlLCB0aGlzLl9tZW51QXJyKTtcclxuICAgICAgICAgICAgdGhpcy5jZHIuZGV0ZWN0Q2hhbmdlcygpO1xyXG4gICAgICAgIH07XHJcbiAgICAgICAgdGhpcy5hcGkuaGlkZU1lbnVJdGVtQnlBY3Rpb24gPSAoX2FjdGlvbjogc3RyaW5nLCBfaXNIaWRlOiBib29sZWFuID0gdHJ1ZSk6IHZvaWQgPT4ge1xyXG4gICAgICAgICAgICB0aGlzLl92aXN1YWxpemF0aW9uU3ZjLnNldE1lbnVJdGVtVmlzaWJpbGl0eSgnYWN0aW9uJywgX2FjdGlvbiwgX2lzSGlkZSwgdGhpcy5fbWVudUFycik7XHJcbiAgICAgICAgICAgIHRoaXMuY2RyLmRldGVjdENoYW5nZXMoKTtcclxuICAgICAgICB9O1xyXG4gICAgICAgIHRoaXMuYXBpLmdldERhdGFVcmwgPSAoX3N0eWxlPzogb2JqZWN0LCBfb3B0aW9ucz86IElPcHRpb25zLCBfaXNSZW1vdmVMZWdlbmRTY3JvbGw/OiBib29sZWFuKTogT2JzZXJ2YWJsZTxzdHJpbmc+ID0+IHtcclxuICAgICAgICAgICAgcmV0dXJuIG5ldyBPYnNlcnZhYmxlPHN0cmluZz4oKF9vYnNlcnZlcjogT2JzZXJ2ZXI8c3RyaW5nPikgPT4ge1xyXG4gICAgICAgICAgICAgICAgbGV0IG9yaWdpbmFsU3R5bGU6IG9iamVjdCA9IHt9O1xyXG4gICAgICAgICAgICAgICAgaWYgKF9zdHlsZSkge1xyXG4gICAgICAgICAgICAgICAgICAgIG9yaWdpbmFsU3R5bGUgPSBPYmplY3QuYXNzaWduKHt9LCB0aGlzLmludmlzaWJsZUNoYXJ0U3R5bGUpO1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuaW52aXNpYmxlQ2hhcnRTdHlsZSA9IF9zdHlsZTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIHRoaXMuX3ByZXBFeHBvcnRDaGFydCgnaW1hZ2VVcmwnLCBfb3B0aW9ucywgX2lzUmVtb3ZlTGVnZW5kU2Nyb2xsKS5zdWJzY3JpYmUoKF9yZXNwb25zZSkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgIGlmKF9zdHlsZSkgdGhpcy5pbnZpc2libGVDaGFydFN0eWxlID0gb3JpZ2luYWxTdHlsZTtcclxuICAgICAgICAgICAgICAgICAgICBfb2JzZXJ2ZXIubmV4dChfcmVzcG9uc2UpO1xyXG4gICAgICAgICAgICAgICAgICAgIF9vYnNlcnZlci5jb21wbGV0ZSgpO1xyXG4gICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgIH0pO1xyXG4gICAgICAgIH07XHJcblxyXG4gICAgICAgIHRoaXMuYXBpLnRvZ2dsZVRhYmxlID0gKF9zaG93VGFibGU6IGJvb2xlYW4sIHJhd0RhdGE6IElUYWJsZURhdGEpOiB2b2lkID0+IHtcclxuICAgICAgICAgICAgcmF3RGF0YS5jb25maWcgPSBPYmplY3QuYXNzaWduKHt9LCB0aGlzLnJhd0RhdGEuY29uZmlnLCByYXdEYXRhLmNvbmZpZyk7XHJcbiAgICAgICAgICAgIHRoaXMucmF3RGF0YSA9IE9iamVjdC5hc3NpZ24oe30sIHJhd0RhdGEpO1xyXG4gICAgICAgICAgICB0aGlzLmNvbHVtbkFmdGVyRmlsdGVyID0gdGhpcy5fdmlzdWFsaXphdGlvblN2Yy5maWx0ZXJDb2x1bW5zKHJhd0RhdGEuY29sdW1uKTtcclxuICAgICAgICAgICAgaWYgKF9zaG93VGFibGUpIHtcclxuICAgICAgICAgICAgICAgIHRoaXMuX3RlbXBTdGF0ZSA9IHRoaXMuY29udGVudFN0YXRlO1xyXG4gICAgICAgICAgICAgICAgaWYgKHRoaXMuY29udGVudFN0YXRlICE9PSAndGFibGUnKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5jb250ZW50U3RhdGUgPSAndGFibGUnO1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuX2NhbGxQbHVnaW5zKCd2aWV3LnRhYmxlJyk7XHJcbiAgICAgICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICAgICAgdGhpcy5pc0V4cG9ydEVuYWJsZWQgPSBmYWxzZTtcclxuICAgICAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgICAgIHRoaXMuaXNFeHBvcnRFbmFibGVkID0gdHlwZW9mIHRoaXMuY29uZmlnICE9PSAndW5kZWZpbmVkJyAmJiB0aGlzLmNvbmZpZy5leHBvcnQuZW5hYmxlZDtcclxuICAgICAgICAgICAgICAgIHRoaXMuX3Zpc3VhbGl6YXRpb25TdmMuc2V0UGFyZW50SGVpZ2h0KCdjaGFydCcpO1xyXG4gICAgICAgICAgICAgICAgdGhpcy5jb250ZW50U3RhdGUgPSB0aGlzLl90ZW1wU3RhdGUgPyB0aGlzLl90ZW1wU3RhdGUgOiAnY2hhcnQnO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIC8vID09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PSBNZW51IENsaWNrZWQgPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PVxyXG5cclxuICAgIHB1YmxpYyB0b2dnbGVNZW51KF9pdGVtPzogYW55KTogdm9pZCB7XHJcbiAgICAgICAgbGV0IGhhdmVPcGVyYXRpb246IGJvb2xlYW4gPSBfaXRlbSAmJiBfaXRlbS5vcGVyYXRpb247XHJcbiAgICAgICAgbGV0IGhhdmVDYWxsYmFjazogYm9vbGVhbiA9IF9pdGVtICYmIF9pdGVtLmNhbGxiYWNrO1xyXG5cclxuICAgICAgICBpZiAoaGF2ZU9wZXJhdGlvbikgdGhpcy5fY2FsbFBsdWdpbnMoX2l0ZW0ub3BlcmF0aW9uKTtcclxuICAgICAgICBpZiAoaGF2ZUNhbGxiYWNrKSBfaXRlbS5jYWxsYmFjaygpO1xyXG5cclxuICAgICAgICB0aGlzLl90b2dnbGVNZW51RmxhZyh0aGlzLm1lbnVGbGFnLCBfaXRlbSwgaGF2ZU9wZXJhdGlvbiB8fCBoYXZlQ2FsbGJhY2spO1xyXG5cclxuICAgICAgICB0aGlzLm1lbnVCdG5JY29uQ2xhc3MgPSB0aGlzLl9tZW51QnRuTGlzdFt0aGlzLm1lbnVGbGFnXTtcclxuXHJcbiAgICAgICAgdGhpcy5pc01lbnVPcGVuID0gdGhpcy5tZW51RmxhZyA9PT0gJ29wZW5lZCcgfHwgdGhpcy5tZW51RmxhZyA9PT0gJ2V4cGFuZGVkJztcclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF90b2dnbGVNZW51RmxhZyhfZmxhZzogc3RyaW5nLCBfaXRlbT86IGFueSwgX2Nsb3NlRXhwYW5kPzogYm9vbGVhbik6IHZvaWQge1xyXG4gICAgICAgIHN3aXRjaCAoX2ZsYWcpIHtcclxuICAgICAgICAgICAgY2FzZSAnY2xvc2VkJzpcclxuICAgICAgICAgICAgZGVmYXVsdDpcclxuICAgICAgICAgICAgICAgIHRoaXMubWVudUZsYWcgPSAnb3BlbmVkJztcclxuICAgICAgICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgICAgICBjYXNlICdvcGVuZWQnOlxyXG4gICAgICAgICAgICAgICAgbGV0IGlzRXhwYW5kOiBib29sZWFuID0gX2l0ZW0gJiYgX2l0ZW0uZXhwYW5kZWQ7XHJcbiAgICAgICAgICAgICAgICBpZiAoaXNFeHBhbmQpIHtcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLm1lbnVEaXNwbGF5QXJyID0gX2l0ZW0uZXhwYW5kZWQ7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5tZW51RmxhZyA9ICdleHBhbmRlZCc7XHJcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgbGV0IGlzVmlldzogYm9vbGVhbiA9IGZhbHNlO1xyXG4gICAgICAgICAgICAgICAgaWYgKF9pdGVtICYmIF9pdGVtLmhhc093blByb3BlcnR5KCdvcGVyYXRpb24nKSkge1xyXG4gICAgICAgICAgICAgICAgICAgIGlzVmlldyA9IF9pdGVtICYmIF9pdGVtLm9wZXJhdGlvbi5pbmRleE9mKCd2aWV3JykgPiAtMTtcclxuICAgICAgICAgICAgICAgICAgICBpZiAoaXNWaWV3KSB0aGlzLmNvbnRlbnRTdGF0ZSA9IF9pdGVtLm9wZXJhdGlvbi5zcGxpdCgnLicpWzFdO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgdGhpcy5tZW51RmxhZyA9IGlzVmlldyA/ICd2aWV3ZWQnIDogJ2Nsb3NlZCc7XHJcbiAgICAgICAgICAgICAgICBicmVhaztcclxuICAgICAgICAgICAgY2FzZSAnZXhwYW5kZWQnOlxyXG4gICAgICAgICAgICAgICAgdGhpcy5tZW51RmxhZyA9IF9jbG9zZUV4cGFuZCA/ICdjbG9zZWQnIDogJ29wZW5lZCc7XHJcbiAgICAgICAgICAgICAgICB0aGlzLm1lbnVEaXNwbGF5QXJyID0gdGhpcy5fbWVudUFycjtcclxuICAgICAgICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgICAgICBjYXNlICd2aWV3ZWQnOlxyXG4gICAgICAgICAgICAgICAgdGhpcy5fdmlzdWFsaXphdGlvblN2Yy5zZXRQYXJlbnRIZWlnaHQoJ2NoYXJ0Jyk7XHJcbiAgICAgICAgICAgICAgICB0aGlzLm1lbnVGbGFnID0gJ2Nsb3NlZCc7XHJcbiAgICAgICAgICAgICAgICB0aGlzLmNvbnRlbnRTdGF0ZSA9ICdjaGFydCc7XHJcbiAgICAgICAgICAgICAgICBicmVhaztcclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfY2FsbFBsdWdpbnMoX29wZXJhdGlvbjogc3RyaW5nKTogdm9pZCB7XHJcblxyXG4gICAgICAgIC8vIG9wZXJhdGlvbnMgYXJlIHNlcGFyYXRlZCBieSAuXHJcbiAgICAgICAgbGV0IG9wZXJhdGlvbkFyciA9IF9vcGVyYXRpb24uc3BsaXQoJy4nKTtcclxuXHJcbiAgICAgICAgaWYgKG9wZXJhdGlvbkFyclswXSA9PT0gJ3ZpZXcnICYmIG9wZXJhdGlvbkFyclsxXSA9PT0gJ3RhYmxlJykge1xyXG4gICAgICAgICAgICB0aGlzLl92aXN1YWxpemF0aW9uU3ZjLnByb2Nlc3NWaWV3VGFibGUodGhpcy5yYXdEYXRhLmNvbmZpZyk7XHJcbiAgICAgICAgICAgIHJldHVybjtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIGlmIChvcGVyYXRpb25BcnJbMF0gIT09ICdleHBvcnQnKSByZXR1cm47XHJcblxyXG4gICAgICAgIGlmICh0aGlzLmNvbmZpZy50aXRsZS50ZXh0KSB0aGlzLl9maWxlTmFtZSA9IHRoaXMuY29uZmlnLnRpdGxlLnRleHQucmVwbGFjZSgvXFxzL2csICdfJyk7XHJcblxyXG4gICAgICAgIGlmIChvcGVyYXRpb25BcnJbMV0gPT09ICdleGNlbCcpIHtcclxuICAgICAgICAgICAgdGhpcy5leHBvcnRUYWJsZSA9IHRydWU7XHJcbiAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgdGhpcy5fcHJlcEV4cG9ydENoYXJ0KG9wZXJhdGlvbkFyclsxXSkuc3Vic2NyaWJlKCgpPT57fSk7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX3ByZXBFeHBvcnRDaGFydChfb3BlcmF0aW9uOiBzdHJpbmcsIF9vcHRpb25zOiBJT3B0aW9ucyA9IHt9LCBfaXNSZW1vdmVMZWdlbmRTY3JvbGw6IGJvb2xlYW4gPSB0cnVlKTogT2JzZXJ2YWJsZTxzdHJpbmc+IHtcclxuICAgICAgICByZXR1cm4gbmV3IE9ic2VydmFibGU8c3RyaW5nPigoX29ic2VydmVyOiBPYnNlcnZlcjxzdHJpbmc+KSA9PiB7XHJcbiAgICAgICAgICAgIGlmICghdGhpcy5fZXhwb3J0LmlzRXhwb3J0Q29tcGF0aWJsZSgpKSB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLmVycm9yTXNnLmVtaXQodGhpcy5fZXhwb3J0LmdldEVycm9yTWVzc2FnZShfb3BlcmF0aW9uKSk7XHJcbiAgICAgICAgICAgICAgICBfb2JzZXJ2ZXIuZXJyb3IodGhpcy5fZXhwb3J0LmdldEVycm9yTWVzc2FnZShfb3BlcmF0aW9uKSk7XHJcbiAgICAgICAgICAgICAgICBfb2JzZXJ2ZXIuY29tcGxldGUoKTtcclxuICAgICAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgICAgIC8vIGNoYXJ0IGZvciBleHBvcnRpbmcgc2hvdWxkIHNraXAgbWFzc2FnZSBhbmQgbm90IGhhdmUgYW5pbWF0aW9uXHJcbiAgICAgICAgICAgICAgICB0aGlzLmNvbmZpZ0ZvckludmlzaWJsZWNoYXJ0ID0gT2JqZWN0LmFzc2lnbih7fSwgdGhpcy5jb25maWcsIHsgaWQ6ICdleHBvcnQtY2hhcnQnLCBhbmltYXRpb246IGZhbHNlLCBza2lwTWFzc2FnZTogdHJ1ZSB9KTtcclxuICAgICAgICAgICAgICAgIHRoaXMuZXhwb3J0Tm93ID0gdHJ1ZTtcclxuXHJcbiAgICAgICAgICAgICAgICAvLyBWaWV3Q2hpbGQgcmVxdWlyZXMgc2V0VGltZW91dCAoQW5ndWxhciA1KVxyXG4gICAgICAgICAgICAgICAgc2V0VGltZW91dCgoKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgLy8gc2V0IExlZ2VuZCBEYXRhIHNvIHRoYXQgdGhpcyBpbmZvIGRvZXMgbm90IGhhdmUgdG8gYmUgcmVnZW5lcmF0ZWQgYnkgaW52aXNpYmxlIGNoYXJ0XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5pbnZpc2libGVDaGFydC5zZXRMZWdlbmREYXRhKHRoaXMubGVnZW5kRGF0YUFmdGVyTWFzc2FnZSk7XHJcbiAgICAgICAgICAgICAgICAgICAgLy8gdHJpZ2dlciBjaGFydCB0byBkcmF3IG9uY2UgbGVnZW5kIGRhdGEgaXMgc2V0XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5kYXRhRm9ySW52aXNpYmxlQ2hhcnQgPSB0aGlzLmRhdGFBZnRlck1hc3NhZ2U7XHJcbiAgICAgICAgICAgICAgICB9KTtcclxuXHJcbiAgICAgICAgICAgICAgICBsZXQgb3B0aW9uczogSU9wdGlvbnMgPSBPYmplY3QuYXNzaWduKHt9LCBfb3B0aW9ucyk7XHJcbiAgICAgICAgICAgICAgICBpZiAodGhpcy5fZmlsZU5hbWUpIG9wdGlvbnNbJ2ZpbGVOYW1lJ10gPSB0aGlzLl9maWxlTmFtZTtcclxuXHJcbiAgICAgICAgICAgICAgICBzZXRUaW1lb3V0KCgpID0+IHtcclxuICAgICAgICAgICAgICAgICAgICBsZXQgY2hhcnRFbGVtZW50ID0gdGhpcy5fZWxlbVJlZi5uYXRpdmVFbGVtZW50LnF1ZXJ5U2VsZWN0b3IoJy4nICsgdGhpcy5pbnZpc2libGVDaGFydENsYXNzICsgJy5rZHgtY2hhcnRzJyk7XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIC8vIGJlZm9yZSBleHBvcnRpbmcsIHRoZSBodG1sIG5lZWRzIHRvIGJlIGNoYW5nZWRcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLl92aXN1YWxpemF0aW9uU3ZjLnJlbW92ZUR1bW15KGNoYXJ0RWxlbWVudCk7XHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKF9pc1JlbW92ZUxlZ2VuZFNjcm9sbCkgdGhpcy5fdmlzdWFsaXphdGlvblN2Yy5yZW1vdmVMZWdlbmRTY3JvbGwoY2hhcnRFbGVtZW50KTtcclxuICAgICAgICAgICAgICAgICAgICBjaGFydEVsZW1lbnQuc3R5bGUuaGVpZ2h0ID0gJ2F1dG8nO1xyXG5cclxuICAgICAgICAgICAgICAgICAgICBvcHRpb25zWyd3aWR0aCddID0gY2hhcnRFbGVtZW50LmdldEJvdW5kaW5nQ2xpZW50UmVjdCgpLndpZHRoICsgMTtcclxuICAgICAgICAgICAgICAgICAgICBvcHRpb25zWydoZWlnaHQnXSA9IGNoYXJ0RWxlbWVudC5nZXRCb3VuZGluZ0NsaWVudFJlY3QoKS5oZWlnaHQgKyAxO1xyXG5cclxuICAgICAgICAgICAgICAgICAgICBsZXQgcmVzdWx0ID0gdGhpcy5fZXhwb3J0LmV4cG9ydEVsZW1lbnQoY2hhcnRFbGVtZW50LCBfb3BlcmF0aW9uLCBvcHRpb25zKTtcclxuXHJcbiAgICAgICAgICAgICAgICAgICAgLy8gb25jZSBleHBvcnQgaXMgZG9uZSwgcmVtb3ZlIHRoZSBpbnZpc2libGUgY2hhcnQgZnJvbSBET01cclxuICAgICAgICAgICAgICAgICAgICB0aGlzLmV4cG9ydE5vdyA9IGZhbHNlO1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuZGF0YUZvckludmlzaWJsZUNoYXJ0ID0gbnVsbDtcclxuXHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKHJlc3VsdCkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICByZXN1bHQudGhlbihkYXRhVXJsID0+IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIF9vYnNlcnZlci5uZXh0KGRhdGFVcmwpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgX29ic2VydmVyLmNvbXBsZXRlKCk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH0pXHJcbiAgICAgICAgICAgICAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgX29ic2VydmVyLmNvbXBsZXRlKCk7XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgfSwgdGhpcy5fdGltZW91dFRpbWluZyk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9KTtcclxuXHJcbiAgICB9XHJcblxyXG59XHJcbiJdfQ==