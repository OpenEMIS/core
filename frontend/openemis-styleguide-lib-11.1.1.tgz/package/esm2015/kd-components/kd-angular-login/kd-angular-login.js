import { Component, Input, Output, EventEmitter, ViewEncapsulation, ViewContainerRef, Inject, Renderer2 } from '@angular/core';
import { KdLoginSvc } from './kd-angular-login-svc';
import { KdDomElemSvc } from '../kd-common/index';
import { SESSION_STORAGE } from 'ngx-webstorage-service';
export class KdLogin {
    constructor(_loginSvc, _renderer, _vcr, 
    //private _alertSvc: KdLoginErrorEvent,
    // private _http: Http,
    _domSvc, storage) {
        this._loginSvc = _loginSvc;
        this._renderer = _renderer;
        this._vcr = _vcr;
        this._domSvc = _domSvc;
        this.storage = storage;
        this.headerConfig = {};
        this.alertMessage = '';
        this.alertStatus = '';
        this.logoSize = '';
        this.buttonTitle = '';
        this._langVal = '';
        this.enableCstmFtr = false;
        this.outputLangIndex = new EventEmitter();
        // if (_productInfo) {
        //     this.headerConfig.icon = _productInfo.brandLogo.src;
        //     this.headerConfig.title = _productInfo.brandLogo.name;
        // }
    }
    ngOnChanges(_simpleChanges) {
        // console.log
        // if (_simpleChanges.hasOwnProperty('alert')) {
        //     this._formAlert = this._loginSvc.getFormAlerts(this.config, this.config.type);
        // }
    }
    ngOnInit() {
        this._initApi();
        //console.log('The session is: ' + this.storage.get('STORAGE_KEY') || 'This storage is empty');
        this._selectedLangIndex = this.storage.get('STORAGE_KEY') || '';
        this.headerConfig = this._loginSvc.getHeaderConfigValues(this.config, this.headerConfig);
        if (this.config.footer) {
            this.enableCstmFtr = true;
            this.customFooter = this.config.footer;
        }
        if (this.config.type === 'login') {
            this._langVal = this._loginSvc.getLangageDefaultValue(this.config);
            if (this._selectedLangIndex !== '') {
                this._langVal = this._selectedLangIndex;
                //console.log("Enter into this condition with the value: "+this._selectedLangIndex);
            }
            let langConfig = {
                options: this._loginSvc.getLanguageConfigValues(this.config),
                value: this._langVal
            };
            this.defaultedIndex = langConfig.value;
            this.dir = this._loginSvc.checkLanguageDir(langConfig.options, this.defaultedIndex);
            this.formInputs = this._loginSvc.getFormInputs(this.config.type, langConfig);
        }
        else if (this.config.type === 'only-otp') {
            let langConfig = {
                value: this.emailData
            };
            this.formInputs = this._loginSvc.getFormInputs(this.config.type, langConfig);
        }
        else {
            let langConfig;
            this.formInputs = this._loginSvc.getFormInputs(this.config.type, langConfig);
        }
        this.formLinks = this._loginSvc.getFormLinks(this.config, this.config.type);
        this.buttonTitle = this._loginSvc.getButtonLabel(this.config.type, this.config.button.label);
        // this._formAlert = this._loginSvc.getFormAlerts(this.config, this.config.type);
        // this._alertSub = this._alertSvc.onSetAlertStatus().subscribe((_value: any): void => {
        //    if (this._formAlert !== false) {
        //        this.alertMessage = this._loginSvc.setAlertMessage(_value, this._formAlert);
        //         this.alertStatus = _value;
        //     }
        // });
        // console.log('OnInit(): ' + this.dir);
        this._updateHTMLDirection(this.dir);
    }
    ngAfterViewInit() {
        // this.defaultedIndex;
        if (this._vcr.element.nativeElement.querySelector('#username') !== null) {
            this._vcr.element.nativeElement.querySelector('#username').focus();
        }
    }
    // ngOnDestroy(): void {
    //     this._alertSub.unsubscribe();
    //     this.storage.remove('STORAGE_KEY');
    //     this._httpSub.unsubscribe();
    // }
    close() {
        this.alertMessage = '';
    }
    onFormSubmit(_formData) {
        if (this.config.hasOwnProperty('button') && this.config.button.hasOwnProperty('callback')) {
            this.config.button.callback(_formData);
        }
    }
    onLanguageChange(_selectedIndex) {
        // console.log('Parent receive: ' + _selectedIndex);
        if (typeof _selectedIndex === 'undefined') {
            _selectedIndex = this.defaultedIndex;
        }
        this.dir = this._loginSvc.updateLanguageDir(this.config, _selectedIndex);
        this._updateHTMLDirection(this.dir);
        this.outputLangIndex.emit(_selectedIndex);
    }
    _initApi() {
        if (!this.api)
            return;
        this.api.setAlertMessage = (_type, _msg) => {
            // if(_type === 'danger'){
            //     this.config.alert.errorMsg = _msg;
            this.alertMessage = _msg;
            this.alertStatus = _type;
            // }else{
            //     this.config.alert.successMsg = _msg;
            // }
        };
    }
    _updateHTMLDirection(_dir) {
        let htmlTag = document.querySelector('html');
        let removeClass;
        if (typeof _dir === 'undefined') {
            // console.log('do nothing!');
        }
        else {
            if (_dir === 'rtl') {
                removeClass = 'ltr';
            }
            else {
                removeClass = 'rtl';
            }
            __ngRendererSetElementAttributeHelper(this._renderer, htmlTag, 'dir', _dir);
            __ngRendererSetElementAttributeHelper(this._renderer, htmlTag, 'lang', _dir);
            this._domSvc.removeClass(htmlTag, removeClass);
            this._domSvc.addClass(htmlTag, _dir);
        }
    }
}
KdLogin.decorators = [
    { type: Component, args: [{
                selector: 'kd-login',
                template: "<div class=\"kdx-body-wrapper\">\r\n\t<div class=\"kdx-login-container\">\t\r\n\t\t<div class=\"kdx-black-tint\"></div>\r\n\t\t<div class=\"kdx-login-content\">\r\n\t\t\t<div class=\"kdx-title\">\r\n\t\t\t\t<div class=\"kdx-login-table\">\r\n\t\t\t\t\t<div class=\"kdx-logo-wrapper\" [ngClass]=\"logoSize\">\r\n\t\t\t\t\t\t<i *ngIf=\"headerConfig.icon\" [ngClass]=\"headerConfig.icon\"></i>\r\n\t\t\t\t\t\t<div *ngIf=\"headerConfig.img\" class=\"kdx-image-wrapper\">\r\n\t\t\t\t\t\t\t<img [src]=\"headerConfig.img\"/>\r\n\t\t\t\t\t\t</div>\r\n\t\t\t\t\t</div>\r\n\t\t\t\t\t<h1 *ngIf=\"headerConfig.title\">{{headerConfig.title}}</h1>\r\n\t\t\t\t</div>\r\n\t\t\t</div>\r\n\r\n\t\t\t<div *ngIf=\"alertMessage != ''\" class=\"kdx-alert {{alertStatus}}\">\r\n\t\t\t\t<span>{{alertMessage}}</span>\r\n\t\t\t\t<a class=\"close\" (click)=\"close()\">\u00D7</a>\r\n\t\t\t</div>\r\n\r\n\t\t\t<div class=\"kdx kdx-login-form\">\r\n\t\t\t\t<div *ngIf=\"headerConfig.headerMsg\" class=\"header-msg\">{{headerConfig.headerMsg}}</div>\r\n\r\n\t\t\t\t<!-- Original Code -->\r\n \t\t\t\t<!--<div class=\"input text\">\r\n\t\t\t\t\t<input type=\"text\" name=\"username\" placeholder=\"Username\" id=\"username\" [(ngModel)]=\"inputInfo.user\">\r\n\t\t\t\t</div>\r\n\t\t\t\t<div class=\"input password\">\r\n\t\t\t\t\t<input type=\"password\" name=\"password\" placeholder=\"Password\" id=\"password\" [(ngModel)]=\"inputInfo.pass\">\r\n\t\t\t\t</div>\r\n\r\n\t\t\t\t<div class=\"kdx-input-select-wrapper\" *ngIf=\"languageConfig.show\">\r\n\t\t\t\t\t<select name=\"System[language]\" id=\"system-language\" [(ngModel)]=\"_selectedIndex\" (ngModelChange)=\"updateLanguage()\">\r\n\t\t\t\t\t\t<option *ngFor=\"let item of languageConfig.list; let i = index\" [selected]=\"\" [value]=\"i\">{{item.name}}</option>\r\n\t\t\t\t\t</select>\r\n\t\t\t\t</div>-->\r\n\t\t\t\t<!-- With Dyanmic Form -->\r\n\t\t\t\t<!--<div *ngFor=\"let loginForm of loginForms\">\r\n      \t\t\t\t\t<div [formGroup]=\"form\">\r\n\r\n      \t\t\t\t\t\t<div [ngSwitch]=\"loginForm.controlType\">\r\n      \t\t\t\t\t\t\t<div [class]=\"loginForm.class\">\r\n        \t\t\t\t\t\t<input *ngSwitchCase=\"'textbox'\" [placeholder]=\"loginForm.label\" [formControlName]=\"loginForm.key\" [id]=\"loginForm.key\" [type]=\"loginForm.type\">\r\n\r\n        \t\t\t\t\t\t<div class=\"kdx-input-select-wrapper icon-class\" *ngSwitchCase=\"'dropdown'\">\r\n    \t\t\t\t\t\t\t\t<select [id]=\"loginForm.key\" *ngSwitchCase=\"'dropdown'\" [formControlName]=\"loginForm.key\">\r\n      \t\t\t\t\t\t\t\t\t<option *ngFor=\"let opt of loginForm.options\" [value]=\"opt.key\">{{opt.value}}</option>\r\n    \t\t\t\t\t\t\t\t</select>\r\n    \t\t\t\t\t\t\t</div>\r\n    \t\t\t\t\t\t\t</div>\r\n      \t\t\t\t\t\t</div>\r\n      \t\t\t\t\t</div>\r\n    \t\t\t</div>-->\r\n\t\t\t\t<!-- With Dynamic form as a Component on its own -->\r\n\t\t\t\t<kd-loginform [formData]= 'formInputs' [buttonTitle]='buttonTitle' [defaultLangVal]='defaultedIndex' (onFormSubmit)='onFormSubmit($event)' (onLanguageChange)='onLanguageChange($event)'></kd-loginform>\r\n\r\n\t\t\t\t<div class=\"kdx-forget-password\" >\r\n\t\t\t\t\t<a *ngFor=\"let item of formLinks;\" [routerLink]=\"item.path\">{{item.label}}</a>\r\n\t\t\t\t</div>\r\n\r\n\t\t\t</div>\t\r\n\r\n\r\n\t\t</div>\r\n\t</div>\r\n</div>\r\n<kd-footer enableFloat='true' [enableCustom]='enableCstmFtr' [customMessage]='customFooter'></kd-footer>\r\n\r\n\r\n\r\n\r\n\r\n\r\n",
                encapsulation: ViewEncapsulation.None,
                providers: [
                    KdLoginSvc,
                    // KdLoginErrorEvent,
                    KdDomElemSvc
                    // KdHeaderInfo
                ],
                host: { 'class': 'kdx-login' }
            },] }
];
KdLogin.ctorParameters = () => [
    { type: KdLoginSvc },
    { type: Renderer2 },
    { type: ViewContainerRef },
    { type: KdDomElemSvc },
    { type: undefined, decorators: [{ type: Inject, args: [SESSION_STORAGE,] }] }
];
KdLogin.propDecorators = {
    config: [{ type: Input }],
    api: [{ type: Input }],
    emailData: [{ type: Input }],
    outputLangIndex: [{ type: Output }]
};
function __ngRendererSplitNamespaceHelper(name) {
    if (name[0] === ":") {
        const match = name.match(/^:([^:]+):(.+)$/);
        return [match[1], match[2]];
    }
    return ["", name];
}
function __ngRendererSetElementAttributeHelper(renderer, element, namespaceAndName, value) {
    const [namespace, name] = __ngRendererSplitNamespaceHelper(namespaceAndName);
    if (value != null) {
        renderer.setAttribute(element, name, value, namespace);
    }
    else {
        renderer.removeAttribute(element, name, namespace);
    }
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoia2QtYW5ndWxhci1sb2dpbi5qcyIsInNvdXJjZVJvb3QiOiJEOi9vcGVuRU1JUy9zdHlsZWd1aWRlL2lvc3RnLW9wZW5lbWlzLXN0eWxlZ3VpZGUvcHJvamVjdHMvb3BlbmVtaXMtc3R5bGVndWlkZS1saWIvc3JjLyIsInNvdXJjZXMiOlsia2QtY29tcG9uZW50cy9rZC1hbmd1bGFyLWxvZ2luL2tkLWFuZ3VsYXItbG9naW4udHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsT0FBTyxFQUFFLFNBQVMsRUFBRSxLQUFLLEVBQUUsTUFBTSxFQUFFLFlBQVksRUFBRSxpQkFBaUIsRUFBRSxnQkFBZ0IsRUFBNEQsTUFBTSxFQUE2QixTQUFTLEVBQUUsTUFBTSxlQUFlLENBQUM7QUFHcE4sT0FBTyxFQUFFLFVBQVUsRUFBRSxNQUFNLHdCQUF3QixDQUFDO0FBRXBELE9BQU8sRUFBRSxZQUFZLEVBQUUsTUFBTSxvQkFBb0IsQ0FBQztBQVdsRCxPQUFPLEVBQUUsZUFBZSxFQUFrQixNQUFNLHdCQUF3QixDQUFDO0FBaUJ6RSxNQUFNLE9BQU8sT0FBTztJQTBCaEIsWUFDWSxTQUFxQixFQUNyQixTQUFvQixFQUNwQixJQUFzQjtJQUM5Qix1Q0FBdUM7SUFDdkMsdUJBQXVCO0lBQ2YsT0FBcUIsRUFFSSxPQUF1QjtRQVBoRCxjQUFTLEdBQVQsU0FBUyxDQUFZO1FBQ3JCLGNBQVMsR0FBVCxTQUFTLENBQVc7UUFDcEIsU0FBSSxHQUFKLElBQUksQ0FBa0I7UUFHdEIsWUFBTyxHQUFQLE9BQU8sQ0FBYztRQUVJLFlBQU8sR0FBUCxPQUFPLENBQWdCO1FBakNyRCxpQkFBWSxHQUFrQixFQUFFLENBQUM7UUFHakMsaUJBQVksR0FBVyxFQUFFLENBQUM7UUFDMUIsZ0JBQVcsR0FBVyxFQUFFLENBQUM7UUFFekIsYUFBUSxHQUFXLEVBQUUsQ0FBQztRQUN0QixnQkFBVyxHQUFXLEVBQUUsQ0FBQztRQVN4QixhQUFRLEdBQVcsRUFBRSxDQUFDO1FBQ3ZCLGtCQUFhLEdBQUcsS0FBSyxDQUFDO1FBTW5CLG9CQUFlLEdBQXNCLElBQUksWUFBWSxFQUFFLENBQUM7UUFhOUQsc0JBQXNCO1FBQ3RCLDJEQUEyRDtRQUMzRCw2REFBNkQ7UUFDN0QsSUFBSTtJQUNSLENBQUM7SUFFRCxXQUFXLENBQUMsY0FBNkI7UUFDckMsY0FBYztRQUNkLGdEQUFnRDtRQUNoRCxxRkFBcUY7UUFDckYsSUFBSTtJQUNSLENBQUM7SUFFRCxRQUFRO1FBQ0osSUFBSSxDQUFDLFFBQVEsRUFBRSxDQUFDO1FBQ2hCLCtGQUErRjtRQUMvRixJQUFJLENBQUMsa0JBQWtCLEdBQUcsSUFBSSxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsYUFBYSxDQUFDLElBQUksRUFBRSxDQUFDO1FBRWhFLElBQUksQ0FBQyxZQUFZLEdBQUcsSUFBSSxDQUFDLFNBQVMsQ0FBQyxxQkFBcUIsQ0FBQyxJQUFJLENBQUMsTUFBTSxFQUFFLElBQUksQ0FBQyxZQUFZLENBQUMsQ0FBQztRQUV6RixJQUFHLElBQUksQ0FBQyxNQUFNLENBQUMsTUFBTSxFQUFDO1lBQ2xCLElBQUksQ0FBQyxhQUFhLEdBQUcsSUFBSSxDQUFDO1lBQzFCLElBQUksQ0FBQyxZQUFZLEdBQUcsSUFBSSxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUM7U0FDMUM7UUFFRCxJQUFJLElBQUksQ0FBQyxNQUFNLENBQUMsSUFBSSxLQUFLLE9BQU8sRUFBRTtZQUU5QixJQUFJLENBQUMsUUFBUSxHQUFHLElBQUksQ0FBQyxTQUFTLENBQUMsc0JBQXNCLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDO1lBRW5FLElBQUksSUFBSSxDQUFDLGtCQUFrQixLQUFLLEVBQUUsRUFBRTtnQkFDaEMsSUFBSSxDQUFDLFFBQVEsR0FBRyxJQUFJLENBQUMsa0JBQWtCLENBQUM7Z0JBQ3hDLG9GQUFvRjthQUN2RjtZQUVELElBQUksVUFBVSxHQUFRO2dCQUNsQixPQUFPLEVBQUUsSUFBSSxDQUFDLFNBQVMsQ0FBQyx1QkFBdUIsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDO2dCQUM1RCxLQUFLLEVBQUUsSUFBSSxDQUFDLFFBQVE7YUFDdkIsQ0FBQztZQUVGLElBQUksQ0FBQyxjQUFjLEdBQUcsVUFBVSxDQUFDLEtBQUssQ0FBQztZQUN2QyxJQUFJLENBQUMsR0FBRyxHQUFHLElBQUksQ0FBQyxTQUFTLENBQUMsZ0JBQWdCLENBQUMsVUFBVSxDQUFDLE9BQU8sRUFBRSxJQUFJLENBQUMsY0FBYyxDQUFDLENBQUM7WUFDcEYsSUFBSSxDQUFDLFVBQVUsR0FBRyxJQUFJLENBQUMsU0FBUyxDQUFDLGFBQWEsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLElBQUksRUFBRSxVQUFVLENBQUMsQ0FBQztTQUVoRjthQUFNLElBQUcsSUFBSSxDQUFDLE1BQU0sQ0FBQyxJQUFJLEtBQUssVUFBVSxFQUFDO1lBQ3RDLElBQUksVUFBVSxHQUFRO2dCQUNsQixLQUFLLEVBQUUsSUFBSSxDQUFDLFNBQVM7YUFDeEIsQ0FBQztZQUNGLElBQUksQ0FBQyxVQUFVLEdBQUcsSUFBSSxDQUFDLFNBQVMsQ0FBQyxhQUFhLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxJQUFJLEVBQUUsVUFBVSxDQUFDLENBQUM7U0FDaEY7YUFBTTtZQUNILElBQUksVUFBZSxDQUFDO1lBQ3BCLElBQUksQ0FBQyxVQUFVLEdBQUcsSUFBSSxDQUFDLFNBQVMsQ0FBQyxhQUFhLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxJQUFJLEVBQUUsVUFBVSxDQUFDLENBQUM7U0FDaEY7UUFFRCxJQUFJLENBQUMsU0FBUyxHQUFHLElBQUksQ0FBQyxTQUFTLENBQUMsWUFBWSxDQUFDLElBQUksQ0FBQyxNQUFNLEVBQUUsSUFBSSxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsQ0FBQztRQUM1RSxJQUFJLENBQUMsV0FBVyxHQUFHLElBQUksQ0FBQyxTQUFTLENBQUMsY0FBYyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsSUFBSSxFQUFFLElBQUksQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxDQUFDO1FBRTdGLGlGQUFpRjtRQUVqRix3RkFBd0Y7UUFDeEYsc0NBQXNDO1FBQ3RDLHNGQUFzRjtRQUN0RixxQ0FBcUM7UUFDckMsUUFBUTtRQUNSLE1BQU07UUFFTix3Q0FBd0M7UUFDeEMsSUFBSSxDQUFDLG9CQUFvQixDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQztJQUV4QyxDQUFDO0lBRUQsZUFBZTtRQUNYLHVCQUF1QjtRQUV2QixJQUFJLElBQUksQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLGFBQWEsQ0FBQyxhQUFhLENBQUMsV0FBVyxDQUFDLEtBQUssSUFBSSxFQUFFO1lBQ3JFLElBQUksQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLGFBQWEsQ0FBQyxhQUFhLENBQUMsV0FBVyxDQUFDLENBQUMsS0FBSyxFQUFFLENBQUM7U0FDdEU7SUFDTCxDQUFDO0lBRUQsd0JBQXdCO0lBQ3hCLG9DQUFvQztJQUNwQywwQ0FBMEM7SUFDMUMsbUNBQW1DO0lBQ25DLElBQUk7SUFFSixLQUFLO1FBQ0QsSUFBSSxDQUFDLFlBQVksR0FBRyxFQUFFLENBQUM7SUFDM0IsQ0FBQztJQUdNLFlBQVksQ0FBQyxTQUFjO1FBQzlCLElBQUksSUFBSSxDQUFDLE1BQU0sQ0FBQyxjQUFjLENBQUMsUUFBUSxDQUFDLElBQUksSUFBSSxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsY0FBYyxDQUFDLFVBQVUsQ0FBQyxFQUFFO1lBQ3ZGLElBQUksQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLFFBQVEsQ0FBQyxTQUFTLENBQUMsQ0FBQztTQUMxQztJQUNMLENBQUM7SUFFTSxnQkFBZ0IsQ0FBQyxjQUFzQjtRQUMxQyxvREFBb0Q7UUFDcEQsSUFBSSxPQUFPLGNBQWMsS0FBSyxXQUFXLEVBQUU7WUFDdkMsY0FBYyxHQUFHLElBQUksQ0FBQyxjQUFjLENBQUM7U0FDeEM7UUFDRCxJQUFJLENBQUMsR0FBRyxHQUFHLElBQUksQ0FBQyxTQUFTLENBQUMsaUJBQWlCLENBQUMsSUFBSSxDQUFDLE1BQU0sRUFBRSxjQUFjLENBQUMsQ0FBQztRQUV6RSxJQUFJLENBQUMsb0JBQW9CLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFDO1FBQ3BDLElBQUksQ0FBQyxlQUFlLENBQUMsSUFBSSxDQUFDLGNBQWMsQ0FBQyxDQUFDO0lBQzlDLENBQUM7SUFFTyxRQUFRO1FBQ1osSUFBSSxDQUFDLElBQUksQ0FBQyxHQUFHO1lBQUUsT0FBTztRQUV0QixJQUFJLENBQUMsR0FBRyxDQUFDLGVBQWUsR0FBSSxDQUFDLEtBQVksRUFBRSxJQUFZLEVBQUUsRUFBRTtZQUN2RCwwQkFBMEI7WUFDMUIseUNBQXlDO1lBQ3JDLElBQUksQ0FBQyxZQUFZLEdBQUcsSUFBSSxDQUFDO1lBQ3pCLElBQUksQ0FBQyxXQUFXLEdBQUcsS0FBSyxDQUFDO1lBQzdCLFNBQVM7WUFDVCwyQ0FBMkM7WUFFM0MsSUFBSTtRQUNSLENBQUMsQ0FBQTtJQUNMLENBQUM7SUFFTyxvQkFBb0IsQ0FBQyxJQUFZO1FBRXJDLElBQUksT0FBTyxHQUFnQixRQUFRLENBQUMsYUFBYSxDQUFDLE1BQU0sQ0FBQyxDQUFDO1FBQzFELElBQUksV0FBbUIsQ0FBQztRQUV4QixJQUFJLE9BQU8sSUFBSSxLQUFLLFdBQVcsRUFBRTtZQUM3Qiw4QkFBOEI7U0FDakM7YUFBTTtZQUNILElBQUksSUFBSSxLQUFLLEtBQUssRUFBRTtnQkFDaEIsV0FBVyxHQUFHLEtBQUssQ0FBQzthQUN2QjtpQkFDSTtnQkFDRCxXQUFXLEdBQUcsS0FBSyxDQUFDO2FBQ3ZCO1lBQ0QscUNBQXFDLENBQUMsSUFBSSxDQUFDLFNBQVMsRUFBRSxPQUFPLEVBQUUsS0FBSyxFQUFFLElBQUksQ0FBQyxDQUFDO1lBQzVFLHFDQUFxQyxDQUFDLElBQUksQ0FBQyxTQUFTLEVBQUUsT0FBTyxFQUFFLE1BQU0sRUFBRSxJQUFJLENBQUMsQ0FBQztZQUU3RSxJQUFJLENBQUMsT0FBTyxDQUFDLFdBQVcsQ0FBQyxPQUFPLEVBQUUsV0FBVyxDQUFDLENBQUM7WUFDL0MsSUFBSSxDQUFDLE9BQU8sQ0FBQyxRQUFRLENBQUMsT0FBTyxFQUFFLElBQUksQ0FBQyxDQUFDO1NBQ3hDO0lBQ0wsQ0FBQzs7O1lBaE1KLFNBQVMsU0FBQztnQkFDUCxRQUFRLEVBQUUsVUFBVTtnQkFDcEIsMjNHQUFzQztnQkFDdEMsYUFBYSxFQUFFLGlCQUFpQixDQUFDLElBQUk7Z0JBQ3JDLFNBQVMsRUFBRTtvQkFDUCxVQUFVO29CQUNWLHFCQUFxQjtvQkFDckIsWUFBWTtvQkFDWixlQUFlO2lCQUNsQjtnQkFDRCxJQUFJLEVBQUUsRUFBRSxPQUFPLEVBQUUsV0FBVyxFQUFFO2FBRWpDOzs7WUE1QlEsVUFBVTtZQUhnSyxTQUFTO1lBQXhILGdCQUFnQjtZQUszRSxZQUFZOzRDQThEWixNQUFNLFNBQUMsZUFBZTs7O3FCQWIxQixLQUFLO2tCQUNMLEtBQUs7d0JBQ0wsS0FBSzs4QkFDTCxNQUFNOztBQWdLWCxTQUFTLGdDQUFnQyxDQUFDLElBQWdDO0lBQ3RFLElBQUksSUFBSSxDQUFDLENBQUMsQ0FBQyxLQUFLLEdBQUcsRUFBRTtRQUNqQixNQUFNLEtBQUssR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDLGlCQUFpQixDQUFDLENBQUM7UUFDNUMsT0FBTyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsRUFBRSxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztLQUMvQjtJQUNELE9BQU8sQ0FBQyxFQUFFLEVBQUUsSUFBSSxDQUFDLENBQUM7QUFDdEIsQ0FBQztBQUVELFNBQVMscUNBQXFDLENBQUMsUUFBb0MsRUFBRSxPQUFtQyxFQUFFLGdCQUE0QyxFQUFFLEtBQWtDO0lBQ3RNLE1BQU0sQ0FBQyxTQUFTLEVBQUUsSUFBSSxDQUFDLEdBQUcsZ0NBQWdDLENBQUMsZ0JBQWdCLENBQUMsQ0FBQztJQUM3RSxJQUFJLEtBQUssSUFBSSxJQUFJLEVBQUU7UUFDZixRQUFRLENBQUMsWUFBWSxDQUFDLE9BQU8sRUFBRSxJQUFJLEVBQUUsS0FBSyxFQUFFLFNBQVMsQ0FBQyxDQUFDO0tBQzFEO1NBQ0k7UUFDRCxRQUFRLENBQUMsZUFBZSxDQUFDLE9BQU8sRUFBRSxJQUFJLEVBQUUsU0FBUyxDQUFDLENBQUM7S0FDdEQ7QUFDTCxDQUFDIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgQ29tcG9uZW50LCBJbnB1dCwgT3V0cHV0LCBFdmVudEVtaXR0ZXIsIFZpZXdFbmNhcHN1bGF0aW9uLCBWaWV3Q29udGFpbmVyUmVmLCBIb3N0TGlzdGVuZXIsIE9uSW5pdCwgQWZ0ZXJWaWV3SW5pdCwgT25EZXN0cm95LCBPcHRpb25hbCwgSW5qZWN0LCBJbmplY3RhYmxlLCBTaW1wbGVDaGFuZ2VzLCBSZW5kZXJlcjIgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcclxuaW1wb3J0IHsgRm9ybUdyb3VwIH0gZnJvbSAnQGFuZ3VsYXIvZm9ybXMnO1xyXG5pbXBvcnQgeyBTdWJzY3JpcHRpb24gfSBmcm9tICdyeGpzJztcclxuaW1wb3J0IHsgS2RMb2dpblN2YyB9IGZyb20gJy4va2QtYW5ndWxhci1sb2dpbi1zdmMnO1xyXG5pbXBvcnQgeyBLZExvZ2luRXJyb3JFdmVudCB9IGZyb20gJy4va2QtbG9naW4tZXZlbnQnO1xyXG5pbXBvcnQgeyBLZERvbUVsZW1TdmMgfSBmcm9tICcuLi9rZC1jb21tb24vaW5kZXgnO1xyXG4vLyBpbXBvcnQgeyBLZEhlYWRlckluZm8gfSBmcm9tICcuLi9rZC1hbmd1bGFyLWhlYWRlci9rZC1hbmd1bGFyLWhlYWRlcic7XHJcbmltcG9ydCB7XHJcbiAgICBJTG9naW5BcGksXHJcbiAgICBJTG9naW5Db25maWcsXHJcbiAgICBJSGVhZGVyQ29uZmlnLFxyXG4gICAgSUxhbmd1YWdlQ29uZmlnLFxyXG4gICAgSUZvcm1MaW5rQ29uZmlnLFxyXG4gICAgSUZvcm1BbGVydENvbmZpZ1xyXG59IGZyb20gJy4va2QtYW5ndWxhci1sb2dpbi1pbnRlcmZhY2UnO1xyXG5cclxuaW1wb3J0IHsgU0VTU0lPTl9TVE9SQUdFLCBTdG9yYWdlU2VydmljZSB9IGZyb20gJ25neC13ZWJzdG9yYWdlLXNlcnZpY2UnO1xyXG5cclxuXHJcbkBDb21wb25lbnQoe1xyXG4gICAgc2VsZWN0b3I6ICdrZC1sb2dpbicsXHJcbiAgICB0ZW1wbGF0ZVVybDogJy4va2QtYW5ndWxhci1sb2dpbi5odG1sJyxcclxuICAgIGVuY2Fwc3VsYXRpb246IFZpZXdFbmNhcHN1bGF0aW9uLk5vbmUsXHJcbiAgICBwcm92aWRlcnM6IFtcclxuICAgICAgICBLZExvZ2luU3ZjLFxyXG4gICAgICAgIC8vIEtkTG9naW5FcnJvckV2ZW50LFxyXG4gICAgICAgIEtkRG9tRWxlbVN2Y1xyXG4gICAgICAgIC8vIEtkSGVhZGVySW5mb1xyXG4gICAgXSxcclxuICAgIGhvc3Q6IHsgJ2NsYXNzJzogJ2tkeC1sb2dpbicgfVxyXG5cclxufSlcclxuXHJcbmV4cG9ydCBjbGFzcyBLZExvZ2luIGltcGxlbWVudHMgT25Jbml0LCBBZnRlclZpZXdJbml0IHtcclxuICAgIHB1YmxpYyBoZWFkZXJDb25maWc6IElIZWFkZXJDb25maWcgPSB7fTtcclxuICAgIHB1YmxpYyBkaXI6IHN0cmluZztcclxuXHJcbiAgICBwdWJsaWMgYWxlcnRNZXNzYWdlOiBzdHJpbmcgPSAnJztcclxuICAgIHB1YmxpYyBhbGVydFN0YXR1czogc3RyaW5nID0gJyc7XHJcblxyXG4gICAgcHVibGljIGxvZ29TaXplOiBzdHJpbmcgPSAnJztcclxuICAgIHB1YmxpYyBidXR0b25UaXRsZTogc3RyaW5nID0gJyc7XHJcblxyXG4gICAgcHVibGljIGZvcm1JbnB1dHM6IEFycmF5PGFueT47XHJcbiAgICBwdWJsaWMgZm9ybUxpbmtzOiBBcnJheTxhbnk+O1xyXG5cclxuICAgIHByaXZhdGUgX2Zvcm1BbGVydDogSUZvcm1BbGVydENvbmZpZyB8IGJvb2xlYW47XHJcbiAgICBwdWJsaWMgZGVmYXVsdGVkSW5kZXg6IHN0cmluZztcclxuICAgIHByaXZhdGUgX2FsZXJ0U3ViOiBTdWJzY3JpcHRpb247XHJcbiAgICBwcml2YXRlIF9zZWxlY3RlZExhbmdJbmRleDogc3RyaW5nO1xyXG4gICAgcHJpdmF0ZSBfbGFuZ1ZhbDogc3RyaW5nID0gJyc7XHJcbiAgICBwdWJsaWMgZW5hYmxlQ3N0bUZ0ciA9IGZhbHNlO1xyXG4gICAgcHVibGljIGN1c3RvbUZvb3Rlcjogc3RyaW5nO1xyXG5cclxuICAgIEBJbnB1dCgpIGNvbmZpZzogSUxvZ2luQ29uZmlnO1xyXG4gICAgQElucHV0KCkgYXBpPzogSUxvZ2luQXBpO1xyXG4gICAgQElucHV0KCkgZW1haWxEYXRhPzogc3RyaW5nO1xyXG4gICAgQE91dHB1dCgpIG91dHB1dExhbmdJbmRleDogRXZlbnRFbWl0dGVyPGFueT4gPSBuZXcgRXZlbnRFbWl0dGVyKCk7XHJcblxyXG4gICAgY29uc3RydWN0b3IoXHJcbiAgICAgICAgcHJpdmF0ZSBfbG9naW5TdmM6IEtkTG9naW5TdmMsXHJcbiAgICAgICAgcHJpdmF0ZSBfcmVuZGVyZXI6IFJlbmRlcmVyMixcclxuICAgICAgICBwcml2YXRlIF92Y3I6IFZpZXdDb250YWluZXJSZWYsXHJcbiAgICAgICAgLy9wcml2YXRlIF9hbGVydFN2YzogS2RMb2dpbkVycm9yRXZlbnQsXHJcbiAgICAgICAgLy8gcHJpdmF0ZSBfaHR0cDogSHR0cCxcclxuICAgICAgICBwcml2YXRlIF9kb21TdmM6IEtkRG9tRWxlbVN2YyxcclxuXHJcbiAgICAgICAgQEluamVjdChTRVNTSU9OX1NUT1JBR0UpIHByaXZhdGUgc3RvcmFnZTogU3RvcmFnZVNlcnZpY2UsXHJcbiAgICAgICAgLy8gQE9wdGlvbmFsKCkgX3Byb2R1Y3RJbmZvOiBLZEhlYWRlckluZm9cclxuICAgICkge1xyXG4gICAgICAgIC8vIGlmIChfcHJvZHVjdEluZm8pIHtcclxuICAgICAgICAvLyAgICAgdGhpcy5oZWFkZXJDb25maWcuaWNvbiA9IF9wcm9kdWN0SW5mby5icmFuZExvZ28uc3JjO1xyXG4gICAgICAgIC8vICAgICB0aGlzLmhlYWRlckNvbmZpZy50aXRsZSA9IF9wcm9kdWN0SW5mby5icmFuZExvZ28ubmFtZTtcclxuICAgICAgICAvLyB9XHJcbiAgICB9XHJcblxyXG4gICAgbmdPbkNoYW5nZXMoX3NpbXBsZUNoYW5nZXM6IFNpbXBsZUNoYW5nZXMpOiB2b2lkIHtcclxuICAgICAgICAvLyBjb25zb2xlLmxvZ1xyXG4gICAgICAgIC8vIGlmIChfc2ltcGxlQ2hhbmdlcy5oYXNPd25Qcm9wZXJ0eSgnYWxlcnQnKSkge1xyXG4gICAgICAgIC8vICAgICB0aGlzLl9mb3JtQWxlcnQgPSB0aGlzLl9sb2dpblN2Yy5nZXRGb3JtQWxlcnRzKHRoaXMuY29uZmlnLCB0aGlzLmNvbmZpZy50eXBlKTtcclxuICAgICAgICAvLyB9XHJcbiAgICB9XHJcblxyXG4gICAgbmdPbkluaXQoKTogdm9pZCB7XHJcbiAgICAgICAgdGhpcy5faW5pdEFwaSgpO1xyXG4gICAgICAgIC8vY29uc29sZS5sb2coJ1RoZSBzZXNzaW9uIGlzOiAnICsgdGhpcy5zdG9yYWdlLmdldCgnU1RPUkFHRV9LRVknKSB8fCAnVGhpcyBzdG9yYWdlIGlzIGVtcHR5Jyk7XHJcbiAgICAgICAgdGhpcy5fc2VsZWN0ZWRMYW5nSW5kZXggPSB0aGlzLnN0b3JhZ2UuZ2V0KCdTVE9SQUdFX0tFWScpIHx8ICcnO1xyXG5cclxuICAgICAgICB0aGlzLmhlYWRlckNvbmZpZyA9IHRoaXMuX2xvZ2luU3ZjLmdldEhlYWRlckNvbmZpZ1ZhbHVlcyh0aGlzLmNvbmZpZywgdGhpcy5oZWFkZXJDb25maWcpO1xyXG4gICAgICAgIFxyXG4gICAgICAgIGlmKHRoaXMuY29uZmlnLmZvb3Rlcil7XHJcbiAgICAgICAgICAgIHRoaXMuZW5hYmxlQ3N0bUZ0ciA9IHRydWU7XHJcbiAgICAgICAgICAgIHRoaXMuY3VzdG9tRm9vdGVyID0gdGhpcy5jb25maWcuZm9vdGVyO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgaWYgKHRoaXMuY29uZmlnLnR5cGUgPT09ICdsb2dpbicpIHtcclxuXHJcbiAgICAgICAgICAgIHRoaXMuX2xhbmdWYWwgPSB0aGlzLl9sb2dpblN2Yy5nZXRMYW5nYWdlRGVmYXVsdFZhbHVlKHRoaXMuY29uZmlnKTtcclxuXHJcbiAgICAgICAgICAgIGlmICh0aGlzLl9zZWxlY3RlZExhbmdJbmRleCAhPT0gJycpIHtcclxuICAgICAgICAgICAgICAgIHRoaXMuX2xhbmdWYWwgPSB0aGlzLl9zZWxlY3RlZExhbmdJbmRleDtcclxuICAgICAgICAgICAgICAgIC8vY29uc29sZS5sb2coXCJFbnRlciBpbnRvIHRoaXMgY29uZGl0aW9uIHdpdGggdGhlIHZhbHVlOiBcIit0aGlzLl9zZWxlY3RlZExhbmdJbmRleCk7XHJcbiAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgIGxldCBsYW5nQ29uZmlnOiBhbnkgPSB7XHJcbiAgICAgICAgICAgICAgICBvcHRpb25zOiB0aGlzLl9sb2dpblN2Yy5nZXRMYW5ndWFnZUNvbmZpZ1ZhbHVlcyh0aGlzLmNvbmZpZyksXHJcbiAgICAgICAgICAgICAgICB2YWx1ZTogdGhpcy5fbGFuZ1ZhbFxyXG4gICAgICAgICAgICB9O1xyXG4gICAgICAgICAgICBcclxuICAgICAgICAgICAgdGhpcy5kZWZhdWx0ZWRJbmRleCA9IGxhbmdDb25maWcudmFsdWU7XHJcbiAgICAgICAgICAgIHRoaXMuZGlyID0gdGhpcy5fbG9naW5TdmMuY2hlY2tMYW5ndWFnZURpcihsYW5nQ29uZmlnLm9wdGlvbnMsIHRoaXMuZGVmYXVsdGVkSW5kZXgpO1xyXG4gICAgICAgICAgICB0aGlzLmZvcm1JbnB1dHMgPSB0aGlzLl9sb2dpblN2Yy5nZXRGb3JtSW5wdXRzKHRoaXMuY29uZmlnLnR5cGUsIGxhbmdDb25maWcpO1xyXG5cclxuICAgICAgICB9IGVsc2UgaWYodGhpcy5jb25maWcudHlwZSA9PT0gJ29ubHktb3RwJyl7XHJcbiAgICAgICAgICAgIGxldCBsYW5nQ29uZmlnOiBhbnkgPSB7XHJcbiAgICAgICAgICAgICAgICB2YWx1ZTogdGhpcy5lbWFpbERhdGFcclxuICAgICAgICAgICAgfTtcclxuICAgICAgICAgICAgdGhpcy5mb3JtSW5wdXRzID0gdGhpcy5fbG9naW5TdmMuZ2V0Rm9ybUlucHV0cyh0aGlzLmNvbmZpZy50eXBlLCBsYW5nQ29uZmlnKTtcclxuICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICBsZXQgbGFuZ0NvbmZpZzogYW55O1xyXG4gICAgICAgICAgICB0aGlzLmZvcm1JbnB1dHMgPSB0aGlzLl9sb2dpblN2Yy5nZXRGb3JtSW5wdXRzKHRoaXMuY29uZmlnLnR5cGUsIGxhbmdDb25maWcpO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgdGhpcy5mb3JtTGlua3MgPSB0aGlzLl9sb2dpblN2Yy5nZXRGb3JtTGlua3ModGhpcy5jb25maWcsIHRoaXMuY29uZmlnLnR5cGUpO1xyXG4gICAgICAgIHRoaXMuYnV0dG9uVGl0bGUgPSB0aGlzLl9sb2dpblN2Yy5nZXRCdXR0b25MYWJlbCh0aGlzLmNvbmZpZy50eXBlLCB0aGlzLmNvbmZpZy5idXR0b24ubGFiZWwpO1xyXG5cclxuICAgICAgICAvLyB0aGlzLl9mb3JtQWxlcnQgPSB0aGlzLl9sb2dpblN2Yy5nZXRGb3JtQWxlcnRzKHRoaXMuY29uZmlnLCB0aGlzLmNvbmZpZy50eXBlKTtcclxuICAgICAgICBcclxuICAgICAgICAvLyB0aGlzLl9hbGVydFN1YiA9IHRoaXMuX2FsZXJ0U3ZjLm9uU2V0QWxlcnRTdGF0dXMoKS5zdWJzY3JpYmUoKF92YWx1ZTogYW55KTogdm9pZCA9PiB7XHJcbiAgICAgICAgLy8gICAgaWYgKHRoaXMuX2Zvcm1BbGVydCAhPT0gZmFsc2UpIHtcclxuICAgICAgICAvLyAgICAgICAgdGhpcy5hbGVydE1lc3NhZ2UgPSB0aGlzLl9sb2dpblN2Yy5zZXRBbGVydE1lc3NhZ2UoX3ZhbHVlLCB0aGlzLl9mb3JtQWxlcnQpO1xyXG4gICAgICAgIC8vICAgICAgICAgdGhpcy5hbGVydFN0YXR1cyA9IF92YWx1ZTtcclxuICAgICAgICAvLyAgICAgfVxyXG4gICAgICAgIC8vIH0pO1xyXG5cclxuICAgICAgICAvLyBjb25zb2xlLmxvZygnT25Jbml0KCk6ICcgKyB0aGlzLmRpcik7XHJcbiAgICAgICAgdGhpcy5fdXBkYXRlSFRNTERpcmVjdGlvbih0aGlzLmRpcik7XHJcblxyXG4gICAgfVxyXG5cclxuICAgIG5nQWZ0ZXJWaWV3SW5pdCgpOiB2b2lkIHtcclxuICAgICAgICAvLyB0aGlzLmRlZmF1bHRlZEluZGV4O1xyXG5cclxuICAgICAgICBpZiAodGhpcy5fdmNyLmVsZW1lbnQubmF0aXZlRWxlbWVudC5xdWVyeVNlbGVjdG9yKCcjdXNlcm5hbWUnKSAhPT0gbnVsbCkge1xyXG4gICAgICAgICAgICB0aGlzLl92Y3IuZWxlbWVudC5uYXRpdmVFbGVtZW50LnF1ZXJ5U2VsZWN0b3IoJyN1c2VybmFtZScpLmZvY3VzKCk7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIC8vIG5nT25EZXN0cm95KCk6IHZvaWQge1xyXG4gICAgLy8gICAgIHRoaXMuX2FsZXJ0U3ViLnVuc3Vic2NyaWJlKCk7XHJcbiAgICAvLyAgICAgdGhpcy5zdG9yYWdlLnJlbW92ZSgnU1RPUkFHRV9LRVknKTtcclxuICAgIC8vICAgICB0aGlzLl9odHRwU3ViLnVuc3Vic2NyaWJlKCk7XHJcbiAgICAvLyB9XHJcblxyXG4gICAgY2xvc2UoKTogdm9pZCB7XHJcbiAgICAgICAgdGhpcy5hbGVydE1lc3NhZ2UgPSAnJztcclxuICAgIH1cclxuXHJcblxyXG4gICAgcHVibGljIG9uRm9ybVN1Ym1pdChfZm9ybURhdGE6IGFueSk6IHZvaWQge1xyXG4gICAgICAgIGlmICh0aGlzLmNvbmZpZy5oYXNPd25Qcm9wZXJ0eSgnYnV0dG9uJykgJiYgdGhpcy5jb25maWcuYnV0dG9uLmhhc093blByb3BlcnR5KCdjYWxsYmFjaycpKSB7XHJcbiAgICAgICAgICAgIHRoaXMuY29uZmlnLmJ1dHRvbi5jYWxsYmFjayhfZm9ybURhdGEpO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICBwdWJsaWMgb25MYW5ndWFnZUNoYW5nZShfc2VsZWN0ZWRJbmRleDogc3RyaW5nKTogdm9pZCB7XHJcbiAgICAgICAgLy8gY29uc29sZS5sb2coJ1BhcmVudCByZWNlaXZlOiAnICsgX3NlbGVjdGVkSW5kZXgpO1xyXG4gICAgICAgIGlmICh0eXBlb2YgX3NlbGVjdGVkSW5kZXggPT09ICd1bmRlZmluZWQnKSB7XHJcbiAgICAgICAgICAgIF9zZWxlY3RlZEluZGV4ID0gdGhpcy5kZWZhdWx0ZWRJbmRleDtcclxuICAgICAgICB9XHJcbiAgICAgICAgdGhpcy5kaXIgPSB0aGlzLl9sb2dpblN2Yy51cGRhdGVMYW5ndWFnZURpcih0aGlzLmNvbmZpZywgX3NlbGVjdGVkSW5kZXgpO1xyXG5cclxuICAgICAgICB0aGlzLl91cGRhdGVIVE1MRGlyZWN0aW9uKHRoaXMuZGlyKTtcclxuICAgICAgICB0aGlzLm91dHB1dExhbmdJbmRleC5lbWl0KF9zZWxlY3RlZEluZGV4KTtcclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF9pbml0QXBpKCk6IHZvaWQge1xyXG4gICAgICAgIGlmICghdGhpcy5hcGkpIHJldHVybjtcclxuXHJcbiAgICAgICAgdGhpcy5hcGkuc2V0QWxlcnRNZXNzYWdlID0gIChfdHlwZTpzdHJpbmcsIF9tc2c6IHN0cmluZykgPT4ge1xyXG4gICAgICAgICAgICAvLyBpZihfdHlwZSA9PT0gJ2Rhbmdlcicpe1xyXG4gICAgICAgICAgICAvLyAgICAgdGhpcy5jb25maWcuYWxlcnQuZXJyb3JNc2cgPSBfbXNnO1xyXG4gICAgICAgICAgICAgICAgdGhpcy5hbGVydE1lc3NhZ2UgPSBfbXNnO1xyXG4gICAgICAgICAgICAgICAgdGhpcy5hbGVydFN0YXR1cyA9IF90eXBlO1xyXG4gICAgICAgICAgICAvLyB9ZWxzZXtcclxuICAgICAgICAgICAgLy8gICAgIHRoaXMuY29uZmlnLmFsZXJ0LnN1Y2Nlc3NNc2cgPSBfbXNnO1xyXG5cclxuICAgICAgICAgICAgLy8gfVxyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF91cGRhdGVIVE1MRGlyZWN0aW9uKF9kaXI6IHN0cmluZyk6IHZvaWQge1xyXG5cclxuICAgICAgICBsZXQgaHRtbFRhZzogSFRNTEVsZW1lbnQgPSBkb2N1bWVudC5xdWVyeVNlbGVjdG9yKCdodG1sJyk7XHJcbiAgICAgICAgbGV0IHJlbW92ZUNsYXNzOiBzdHJpbmc7XHJcblxyXG4gICAgICAgIGlmICh0eXBlb2YgX2RpciA9PT0gJ3VuZGVmaW5lZCcpIHtcclxuICAgICAgICAgICAgLy8gY29uc29sZS5sb2coJ2RvIG5vdGhpbmchJyk7XHJcbiAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgaWYgKF9kaXIgPT09ICdydGwnKSB7XHJcbiAgICAgICAgICAgICAgICByZW1vdmVDbGFzcyA9ICdsdHInO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgcmVtb3ZlQ2xhc3MgPSAncnRsJztcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBfX25nUmVuZGVyZXJTZXRFbGVtZW50QXR0cmlidXRlSGVscGVyKHRoaXMuX3JlbmRlcmVyLCBodG1sVGFnLCAnZGlyJywgX2Rpcik7XHJcbiAgICAgICAgICAgIF9fbmdSZW5kZXJlclNldEVsZW1lbnRBdHRyaWJ1dGVIZWxwZXIodGhpcy5fcmVuZGVyZXIsIGh0bWxUYWcsICdsYW5nJywgX2Rpcik7XHJcblxyXG4gICAgICAgICAgICB0aGlzLl9kb21TdmMucmVtb3ZlQ2xhc3MoaHRtbFRhZywgcmVtb3ZlQ2xhc3MpO1xyXG4gICAgICAgICAgICB0aGlzLl9kb21TdmMuYWRkQ2xhc3MoaHRtbFRhZywgX2Rpcik7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxufVxyXG5cclxudHlwZSBBbnlEdXJpbmdSZW5kZXJlck1pZ3JhdGlvbiA9IGFueTtcclxuXHJcbmZ1bmN0aW9uIF9fbmdSZW5kZXJlclNwbGl0TmFtZXNwYWNlSGVscGVyKG5hbWU6IEFueUR1cmluZ1JlbmRlcmVyTWlncmF0aW9uKSB7XHJcbiAgICBpZiAobmFtZVswXSA9PT0gXCI6XCIpIHtcclxuICAgICAgICBjb25zdCBtYXRjaCA9IG5hbWUubWF0Y2goL146KFteOl0rKTooLispJC8pO1xyXG4gICAgICAgIHJldHVybiBbbWF0Y2hbMV0sIG1hdGNoWzJdXTtcclxuICAgIH1cclxuICAgIHJldHVybiBbXCJcIiwgbmFtZV07XHJcbn1cclxuXHJcbmZ1bmN0aW9uIF9fbmdSZW5kZXJlclNldEVsZW1lbnRBdHRyaWJ1dGVIZWxwZXIocmVuZGVyZXI6IEFueUR1cmluZ1JlbmRlcmVyTWlncmF0aW9uLCBlbGVtZW50OiBBbnlEdXJpbmdSZW5kZXJlck1pZ3JhdGlvbiwgbmFtZXNwYWNlQW5kTmFtZTogQW55RHVyaW5nUmVuZGVyZXJNaWdyYXRpb24sIHZhbHVlPzogQW55RHVyaW5nUmVuZGVyZXJNaWdyYXRpb24pIHtcclxuICAgIGNvbnN0IFtuYW1lc3BhY2UsIG5hbWVdID0gX19uZ1JlbmRlcmVyU3BsaXROYW1lc3BhY2VIZWxwZXIobmFtZXNwYWNlQW5kTmFtZSk7XHJcbiAgICBpZiAodmFsdWUgIT0gbnVsbCkge1xyXG4gICAgICAgIHJlbmRlcmVyLnNldEF0dHJpYnV0ZShlbGVtZW50LCBuYW1lLCB2YWx1ZSwgbmFtZXNwYWNlKTtcclxuICAgIH1cclxuICAgIGVsc2Uge1xyXG4gICAgICAgIHJlbmRlcmVyLnJlbW92ZUF0dHJpYnV0ZShlbGVtZW50LCBuYW1lLCBuYW1lc3BhY2UpO1xyXG4gICAgfVxyXG59XHJcbiJdfQ==