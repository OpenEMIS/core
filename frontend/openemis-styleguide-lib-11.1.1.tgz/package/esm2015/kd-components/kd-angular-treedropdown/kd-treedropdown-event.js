import { Injectable } from '@angular/core';
import { KdBroadcaster } from '../kd-common/index';
import * as i0 from "@angular/core";
import * as i1 from "../kd-common/kd-broadcaster-svc";
export class KdTreeDropdownEvent {
    constructor(_broadcaster) {
        this._broadcaster = _broadcaster;
    }
    childExpand(data) {
        this._broadcaster.broadcast('KDTreeDropdown_ChildData', data);
    }
    onChildNodeExpand() {
        return this._broadcaster.on('KDTreeDropdown_ChildData');
    }
    loadList(data) {
        this._broadcaster.broadcast('KDTreeDropdown_ParentData', data);
    }
    onLoadList() {
        return this._broadcaster.on('KDTreeDropdown_ParentData');
    }
}
KdTreeDropdownEvent.ɵprov = i0.ɵɵdefineInjectable({ factory: function KdTreeDropdownEvent_Factory() { return new KdTreeDropdownEvent(i0.ɵɵinject(i1.KdBroadcaster)); }, token: KdTreeDropdownEvent, providedIn: "root" });
KdTreeDropdownEvent.decorators = [
    { type: Injectable, args: [{
                providedIn: 'root'
            },] }
];
KdTreeDropdownEvent.ctorParameters = () => [
    { type: KdBroadcaster }
];
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoia2QtdHJlZWRyb3Bkb3duLWV2ZW50LmpzIiwic291cmNlUm9vdCI6IkQ6L29wZW5FTUlTL3N0eWxlZ3VpZGUvaW9zdGctb3BlbmVtaXMtc3R5bGVndWlkZS9wcm9qZWN0cy9vcGVuZW1pcy1zdHlsZWd1aWRlLWxpYi9zcmMvIiwic291cmNlcyI6WyJrZC1jb21wb25lbnRzL2tkLWFuZ3VsYXItdHJlZWRyb3Bkb3duL2tkLXRyZWVkcm9wZG93bi1ldmVudC50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQSxPQUFPLEVBQUUsVUFBVSxFQUFFLE1BQU0sZUFBZSxDQUFDO0FBRTNDLE9BQU8sRUFBRSxhQUFhLEVBQUUsTUFBTSxvQkFBb0IsQ0FBQzs7O0FBS25ELE1BQU0sT0FBTyxtQkFBbUI7SUFDNUIsWUFBb0IsWUFBMkI7UUFBM0IsaUJBQVksR0FBWixZQUFZLENBQWU7SUFBSSxDQUFDO0lBRXBELFdBQVcsQ0FBQyxJQUFTO1FBQ2pCLElBQUksQ0FBQyxZQUFZLENBQUMsU0FBUyxDQUFDLDBCQUEwQixFQUFFLElBQUksQ0FBQyxDQUFDO0lBQ2xFLENBQUM7SUFFRCxpQkFBaUI7UUFDYixPQUFPLElBQUksQ0FBQyxZQUFZLENBQUMsRUFBRSxDQUFNLDBCQUEwQixDQUFDLENBQUM7SUFDakUsQ0FBQztJQUVELFFBQVEsQ0FBQyxJQUFTO1FBQ2QsSUFBSSxDQUFDLFlBQVksQ0FBQyxTQUFTLENBQUMsMkJBQTJCLEVBQUUsSUFBSSxDQUFDLENBQUM7SUFDbkUsQ0FBQztJQUVELFVBQVU7UUFDTixPQUFPLElBQUksQ0FBQyxZQUFZLENBQUMsRUFBRSxDQUFNLDJCQUEyQixDQUFDLENBQUM7SUFDbEUsQ0FBQzs7OztZQXBCSixVQUFVLFNBQUM7Z0JBQ1IsVUFBVSxFQUFFLE1BQU07YUFDckI7OztZQUpRLGFBQWEiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBJbmplY3RhYmxlIH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XHJcbmltcG9ydCB7IE9ic2VydmFibGUgfSBmcm9tICdyeGpzJztcclxuaW1wb3J0IHsgS2RCcm9hZGNhc3RlciB9IGZyb20gJy4uL2tkLWNvbW1vbi9pbmRleCc7XHJcblxyXG5ASW5qZWN0YWJsZSh7XHJcbiAgICBwcm92aWRlZEluOiAncm9vdCdcclxufSlcclxuZXhwb3J0IGNsYXNzIEtkVHJlZURyb3Bkb3duRXZlbnQge1xyXG4gICAgY29uc3RydWN0b3IocHJpdmF0ZSBfYnJvYWRjYXN0ZXI6IEtkQnJvYWRjYXN0ZXIpIHsgfVxyXG5cclxuICAgIGNoaWxkRXhwYW5kKGRhdGE6IGFueSk6IHZvaWQge1xyXG4gICAgICAgIHRoaXMuX2Jyb2FkY2FzdGVyLmJyb2FkY2FzdCgnS0RUcmVlRHJvcGRvd25fQ2hpbGREYXRhJywgZGF0YSk7XHJcbiAgICB9XHJcblxyXG4gICAgb25DaGlsZE5vZGVFeHBhbmQoKTogT2JzZXJ2YWJsZTxhbnk+IHtcclxuICAgICAgICByZXR1cm4gdGhpcy5fYnJvYWRjYXN0ZXIub248YW55PignS0RUcmVlRHJvcGRvd25fQ2hpbGREYXRhJyk7XHJcbiAgICB9XHJcblxyXG4gICAgbG9hZExpc3QoZGF0YTogYW55KTogdm9pZCB7XHJcbiAgICAgICAgdGhpcy5fYnJvYWRjYXN0ZXIuYnJvYWRjYXN0KCdLRFRyZWVEcm9wZG93bl9QYXJlbnREYXRhJywgZGF0YSk7XHJcbiAgICB9XHJcblxyXG4gICAgb25Mb2FkTGlzdCgpOiBPYnNlcnZhYmxlPGFueT4ge1xyXG4gICAgICAgIHJldHVybiB0aGlzLl9icm9hZGNhc3Rlci5vbjxhbnk+KCdLRFRyZWVEcm9wZG93bl9QYXJlbnREYXRhJyk7XHJcbiAgICB9XHJcbn1cclxuIl19