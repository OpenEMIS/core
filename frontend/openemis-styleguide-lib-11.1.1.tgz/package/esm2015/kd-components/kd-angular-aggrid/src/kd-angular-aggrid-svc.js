import { Injectable } from '@angular/core';
// import {
//     KdAGDropdown,
//     KdAGPhoto,
//     KdAGForm,
//     KdAGCheckboxRadio
// } from './ag-grid-components/kd-aggrid-components';
export class KdAggridSvc {
    constructor() {
        this._resizeableCol = 0;
    }
    // private _dataSvc: KdDataSvc = new KdDataSvc();
    getGridOptions() {
        let options = {
            rowData: [],
            columnDefs: [],
            // debug: true,
            headerHeight: 38,
            getRowHeight: this._getRowHeight,
            // animateRows: true,
            // rowBuffer: 5,
            suppressContextMenu: true,
            // suppressMenuMainPanel: true,
            // suppressMenuColumnPanel: true,
            suppressMovableColumns: true,
            suppressMenuHide: true,
            suppressColumnVirtualisation: true,
            unSortIcon: true,
            icons: {
                filter: '<i class="fa fa-filter"/>',
                sortAscending: '<i class="fa fa-caret-down"/>',
                sortDescending: '<i class="fa fa-caret-up"/>',
                sortUnSort: '<i class="fa fa-sort"/>',
                groupExpanded: '<i class="fa fa-minus-circle"/>',
                groupContracted: '<i class="fa fa-plus-circle"/>',
            },
            overlayNoRowsTemplate: '<span class="ag-custom-overlay"><i class="fa fa-info-circle fa-lg margin-right10"></i>No student record found</span>'
        };
        return options;
    }
    setResult(_config) {
        let updateResult = {};
        updateResult.id = (typeof _config !== 'undefined' && typeof _config.id !== 'undefined') ? _config.id : 'kd-grid';
        updateResult.gridHeight = this._checkGridHeight(_config);
        updateResult.checkbox = (typeof _config !== 'undefined' && typeof _config.checkbox !== 'undefined') ? _config.checkbox : false;
        updateResult.radio = (typeof _config !== 'undefined' && typeof _config.radio !== 'undefined') ? _config.radio : false;
        updateResult.externalFilter = (typeof _config !== 'undefined' && typeof _config.externalFilter !== 'undefined') ? _config.externalFilter : false;
        updateResult.loadType = this._checkLoadType(_config);
        updateResult.paginationType = this._checkPaginationType(updateResult.loadType);
        updateResult.pagesize = this._checkPagesize(_config, updateResult.loadType);
        updateResult.totalData = (typeof _config !== 'undefined' && typeof _config.totalData !== 'undefined') ? _config.totalData : -1;
        updateResult.button = (typeof _config !== 'undefined' && typeof _config.button !== 'undefined') ? _config.button : false;
        updateResult.buttonConfig = (typeof _config !== 'undefined' && typeof _config.buttonConfig !== 'undefined') ? this._checkBtnConfig(_config.buttonConfig) : null;
        updateResult.alignment = (typeof _config !== 'undefined' && typeof _config.alignment !== 'undefined') ? _config.alignment : 'middle';
        updateResult.suppressHeightResize = (typeof _config !== 'undefined' && typeof _config.suppressHeightResize !== 'undefined') ? _config.suppressHeightResize : true;
        updateResult.rowClickable = (typeof _config !== 'undefined' && typeof _config.rowClickable !== 'undefined') ? _config.rowClickable : false;
        updateResult.rowMapActionType = (typeof _config !== 'undefined' && typeof _config.rowMapActionType !== 'undefined') ? _config.rowMapActionType : null;
        if (updateResult.radio && updateResult.checkbox)
            updateResult.radio = false;
        return updateResult;
    }
    setRowResult(_rowData) {
        let tableData = (typeof _rowData !== 'undefined') ? _rowData : [];
        return tableData;
    }
    setColDefs(_colDef, _gridOptions, /*_dataSvc: KdDataSvc, */ _router, _isRecursive = false) {
        let colDefConfig = { editMode: false, updatedColDef: [] };
        let tableColumn = {};
        for (let key in _colDef) {
            if (_colDef.hasOwnProperty(key)) {
                this._resizeableCol++;
                tableColumn = {
                    headerName: _colDef[key].headerName,
                    field: (typeof _colDef[key].config !== 'undefined' && typeof _colDef[key].config.map !== 'undefined') ? _colDef[key].config.map : key,
                    editable: false,
                    suppressMenu: (typeof _colDef[key].filterable !== 'undefined') ? !_colDef[key].filterable : true,
                    suppressSorting: (typeof _colDef[key].sortable !== 'undefined') ? !_colDef[key].sortable : true,
                    colId: key,
                    config: (typeof _colDef[key].config !== 'undefined') ? _colDef[key].config : undefined,
                    // cellRenderer: (_params: any): any => {
                    //     if (typeof _params.value === 'number') {
                    //         return _params.value.toString();
                    //     }
                    //     else if (_params.value instanceof Array) {
                    //         JSON.stringify(_params.value);
                    //     }
                    //     return _params.value;
                    // },
                    hide: (typeof _colDef[key].visible !== 'undefined') ? !(_colDef[key].visible) : false,
                    cellClass: 'ag-default'
                };
                if (!tableColumn.suppressMenu) {
                    tableColumn['menuTabs'] = ['filterMenuTab'];
                    tableColumn.filterParams = {
                        newRowsAction: 'keep',
                        cellHeight: 30,
                        selectAllOnMiniFilter: true,
                        values: (typeof _colDef[key].filterVal !== 'undefined' && _colDef[key].filterVal.length > 0) ? _colDef[key].filterVal : undefined
                    };
                }
                if (typeof _colDef[key].config !== 'undefined') {
                    if (typeof _colDef[key].config.input !== 'undefined' && _colDef[key].config.input) {
                        colDefConfig.editMode = true;
                    }
                    tableColumn = this._setColumnConfig(tableColumn, _colDef[key].config, /*_dataSvc,*/ _router);
                    if (tableColumn.hasOwnProperty('cellRendererFramework')) {
                        delete tableColumn.cellRenderer;
                    }
                }
                if (typeof tableColumn.config !== 'undefined' && ((typeof tableColumn.config.checkbox !== 'undefined' && tableColumn.config.checkbox) ||
                    (typeof tableColumn.config.radio !== 'undefined' && tableColumn.config.radio))) {
                    colDefConfig.updatedColDef.unshift(tableColumn);
                }
                else {
                    colDefConfig.updatedColDef.push(tableColumn);
                }
            }
        }
        return colDefConfig;
    }
    setFilterAndSortOptions(params) {
        let updatedOptions = params.gridOptions;
        if (params.loadType === 'server-pagination' || params.loadType === 'oneshot-pagination') {
            updatedOptions.enableServerSideFilter = true;
            updatedOptions.enableServerSideSorting = true;
            updatedOptions.paginationPageSize = params.pagesize;
        }
        else if (params.loadType === 'virtual') {
            updatedOptions.enableServerSideFilter = true;
            updatedOptions.enableServerSideSorting = true;
            updatedOptions.paginationPageSize = params.pagesize;
            updatedOptions.maxPagesInCache = 3;
            updatedOptions.maxConcurrentDatasourceRequests = 2;
            updatedOptions.overflowSize = 30;
        }
        else {
            updatedOptions.enableFilter = true;
            updatedOptions.enableSorting = true;
        }
        if (params.loadType === 'server-pagination' || params.loadType === 'oneshot-pagination') {
            updatedOptions.pagination = true;
        }
        else {
            updatedOptions.rowModelType = params.paginationType;
        }
        return updatedOptions;
    }
    calcColWidth(_gridOptions) {
        let columns = _gridOptions.columnApi.getAllColumns();
        let updatedWidth = [];
        for (let i = 0; i < columns.length; i++) {
            let columnDef = columns[i].getColDef();
            let colWidth = -1;
            if (columnDef.cellClass.indexOf('ag-checkbox-radio') !== -1) {
                colWidth = 50;
                _gridOptions.columnApi.setColumnWidth(columns[i], colWidth);
            }
            else if (typeof columnDef.config !== 'undefined' && typeof columnDef.config.action !== 'undefined' && columnDef.config.action) {
                colWidth = 120;
                _gridOptions.columnApi.setColumnWidth(columns[i], colWidth);
            }
            else if (typeof columnDef.config !== 'undefined' && typeof columnDef.config.photo !== 'undefined' && columnDef.config.photo) {
                colWidth = 100;
                _gridOptions.columnApi.setColumnWidth(columns[i], colWidth);
            }
            else if (typeof columnDef.config !== 'undefined' && typeof columnDef.config.input !== 'undefined' && columnDef.config.input) {
                colWidth = 280;
            }
            else {
                colWidth = columns[i].getActualWidth() + 30;
            }
            updatedWidth.push({ width: colWidth, id: columnDef.colId });
        }
        return updatedWidth;
    }
    colTotalWidth(_colArray, column) {
        let total = 0;
        for (let i = 0; i < _colArray.length; i++) {
            if (column[i].isVisible()) {
                total += _colArray[i].width;
            }
        }
        return total;
    }
    calcUsableWidth(_vcr) {
        let agGridEle = _vcr.element.nativeElement.querySelector('.stg-theme');
        let parentWidth = Math.round(agGridEle.getBoundingClientRect().width);
        let computedStyle = window.getComputedStyle(agGridEle);
        let borderLeft = (computedStyle.borderLeft !== '') ? parseInt(computedStyle.borderLeft) : 0;
        let borderRight = (computedStyle.borderRight !== '') ? parseInt(computedStyle.borderRight) : 0;
        let borderLeftRight = borderLeft + borderRight;
        return parentWidth - borderLeftRight;
    }
    calcResizeableCol(_columns) {
        let resizeableCol = this._resizeableCol;
        for (let i = 0; i < _columns.length; i++) {
            let colDef = _columns[i].getColDef();
            if (typeof colDef.config === 'undefined' && !_columns[i].isVisible()) {
                --resizeableCol;
            }
            // more checks to implement
        }
        return resizeableCol;
    }
    calcGridHeightWeb(_gridHeight, _model, _vcr) {
        let actualHeight = 38 + 8;
        let idSouth = _vcr.element.nativeElement.querySelector('#south');
        if (idSouth !== null) {
            actualHeight += idSouth.getBoundingClientRect().height;
        }
        for (let i = 0; i < _model.getRowCount(); i++) {
            actualHeight += _model.getRow(i).rowHeight;
            if (actualHeight > _gridHeight) {
                break;
            }
        }
        if (actualHeight < _gridHeight) {
            return actualHeight;
        }
        return _gridHeight;
    }
    calcGridHeightMobile(_vcr) {
        let totalHeight = 0;
        let nativeEle = _vcr.element.nativeElement;
        let headerContainer = nativeEle.querySelector('.ag-header-container');
        if (nativeEle === null || headerContainer === null)
            return totalHeight;
        totalHeight += Math.ceil(headerContainer.getBoundingClientRect().height);
        totalHeight += Math.ceil(nativeEle.querySelector('.ag-body-container').getBoundingClientRect().height);
        let paginationBottom = nativeEle.querySelector('#south');
        if (paginationBottom !== null) {
            totalHeight += Math.ceil(paginationBottom.getBoundingClientRect().height);
        }
        totalHeight += 8;
        return totalHeight;
    }
    serverSortAndFilter(_data, _sortModel, _filterModel) {
        return this._serverSortData(_sortModel, this._serverFilterData(_filterModel, _data));
    }
    checkColumnDef(_colDef, _hasCheckbox, _hasRadio) {
        if (_hasCheckbox) {
            _colDef['ag-checkbox'] = {
                config: {
                    checkbox: true
                }
            };
        }
        else if (_hasRadio) {
            _colDef['ag-radio'] = {
                config: {
                    radio: true
                }
            };
        }
        return _colDef;
    }
    getActionList(_rowData, _column) {
        if (typeof _rowData.action !== 'undefined') {
            return _rowData.action;
        }
        for (let i = 0; i < _column.length; i++) {
            let colDef = _column[i].getColDef();
            if (typeof colDef.config !== 'undefined' &&
                typeof colDef.config.action !== 'undefined' &&
                colDef.config.action) {
                return colDef.config.items;
            }
        }
        return [];
    }
    checkIsTargetClickable(_rowEvent) {
        let element = _rowEvent.target;
        let checkList = ['action-btn', 'checkbox-radio-input', 'fa-chevron-down'];
        for (let i = 0; i < checkList.length; i++) {
            if (element.classList.contains(checkList[i])) {
                return false;
            }
        }
        return true;
    }
    checkIsConfigColumn(_colDef) {
        if (_colDef.cellClass.indexOf('ag-checkbox-radio') !== -1) {
            return true;
        }
        if (typeof _colDef.config !== 'undefined' &&
            ((typeof _colDef.config.photo !== 'undefined' && _colDef.config.photo) ||
                (typeof _colDef.config.action !== 'undefined' && _colDef.config.action))) {
            return true;
        }
        return false;
    }
    _setColumnConfig(_column, _config, /*_dataSvc: KdDataSvc,*/ _router) {
        let updatedColumn = Object.assign({}, _column);
        // if (typeof _config.input !== 'undefined' && _config.input) {
        //     updatedColumn.suppressMenu = true;
        //     updatedColumn.suppressSorting = true;
        //     updatedColumn.cellClass = 'ag-form';
        //     updatedColumn.cellRendererFramework = KdAGForm;
        // }
        // else if (typeof _config.action !== 'undefined' && _config.action) {
        //     updatedColumn.suppressMenu = true;
        //     updatedColumn.suppressSorting = true;
        //     updatedColumn.suppressSizeToFit = true;
        //     updatedColumn.width = 120;
        //     updatedColumn.cellClass = 'dropdown-action';
        //     updatedColumn.cellRendererFramework = KdAGDropdown;
        //     this._resizeableCol--;
        // }
        // else if (typeof _config.photo !== 'undefined' && _config.photo) {
        //     updatedColumn.suppressMenu = true;
        //     updatedColumn.suppressSorting = true;
        //     updatedColumn.suppressSizeToFit = true;
        //     updatedColumn.width = 100;
        //     updatedColumn.cellClass = 'ag-photo';
        //     updatedColumn.cellRendererFramework = KdAGPhoto;
        //     this._resizeableCol--;
        // }
        // else if (typeof _config.checkbox !== 'undefined' && _config.checkbox) {
        //     updatedColumn.suppressMenu = true;
        //     updatedColumn.suppressSorting = true;
        //     updatedColumn.suppressSizeToFit = true;
        //     updatedColumn.width = 50;
        //     updatedColumn.cellClass = 'ag-default ag-checkbox-radio';
        //     updatedColumn.colId = 'checkbox';
        //     updatedColumn.cellRendererFramework = KdAGCheckboxRadio;
        //     updatedColumn.headerComponentFramework = KdAGCheckboxRadio;
        //     this._resizeableCol--;
        // }
        // else if (typeof _config.radio !== 'undefined' && _config.radio) {
        //     updatedColumn.suppressMenu = true;
        //     updatedColumn.suppressSorting = true;
        //     updatedColumn.suppressSizeToFit = true;
        //     updatedColumn.width = 50;
        //     updatedColumn.cellClass = 'ag-default ag-checkbox-radio';
        //     updatedColumn.colId = 'radio';
        //     updatedColumn.cellRendererFramework = KdAGCheckboxRadio;
        //     updatedColumn.headerName = '';
        //     this._resizeableCol--;
        // }
        // else if (typeof _config.displayFrom !== 'undefined' && _config.displayFrom) {
        // updatedColumn.cellRenderer = (params: any): any => {
        //     if (typeof params.value !== 'undefined') {
        //         if (params.value instanceof Array) {
        //             let displayArray: Array<any> = [];
        //             for (let i: number = 0; i < params.value.length; i++) {
        //                 let display: any = this._dataSvc.getDataValue(params.value[i], _config.displayFrom);
        //                 if (display !== null) displayArray.push(display);
        //             }
        //             return displayArray;
        //         }
        //         else {
        //             let display: any = this._dataSvc.getDataValue(params.value, _config.displayFrom);
        //             if (display !== null) return display;
        //         }
        //     }
        //     return params.value;
        // }
        // }
        return updatedColumn;
    }
    _serverFilterData(_filterModel, _data) {
        let filteredData = _data.slice();
        if (typeof _filterModel === 'undefined' || Object.keys(_filterModel).length === 0) {
            return filteredData;
        }
        let updatedData = [];
        for (let key in _filterModel) {
            if (_filterModel.hasOwnProperty(key)) {
                for (let k = 0; k < _filterModel[key].length; k++) {
                    for (let j = 0; j < _data.length; j++) {
                        if (_data[j][key] === _filterModel[key][k]) {
                            updatedData.push(_data[j]);
                        }
                    }
                }
            }
        }
        return updatedData;
    }
    _serverSortData(_sortModel, _data) {
        let sortedData = _data.slice();
        if (typeof _sortModel === 'undefined' || _sortModel.length === 0) {
            return sortedData;
        }
        sortedData.sort((a, b) => {
            for (let i = 0; i < _sortModel.length; i++) {
                let sortColModel = _sortModel[i];
                let valA = a[sortColModel.colId];
                let valB = b[sortColModel.colId];
                if (valA === valB) {
                    continue;
                }
                let direction = (sortColModel.sort === 'asc') ? 1 : -1;
                if (valA > valB) {
                    return direction;
                }
                else {
                    return direction * -1;
                }
            }
            return 0;
        });
        return sortedData;
    }
    _checkGridHeight(_config) {
        let defaultHeight = 600;
        if (typeof _config === 'undefined') {
            return defaultHeight;
        }
        else if (typeof _config.gridHeight !== 'undefined' &&
            typeof _config.gridHeight === 'string' &&
            _config.gridHeight === 'auto') {
            return _config.gridHeight;
        }
        else if (typeof _config.gridHeight !== 'undefined' &&
            typeof _config.gridHeight === 'number') {
            return _config.gridHeight;
        }
        return defaultHeight;
    }
    // private _checkPaginationData(_config: any, _loadType: string): any {
    //     if (typeof _config !== 'undefined' &&
    //         typeof _config.paginationSetData !== 'undefined' &&
    //         _loadType === 'server-pagination') {
    //             return _config.paginationSetData;
    //     }
    //     else if (typeof _config !== 'undefined' &&
    //         typeof _config.paginationSetData === 'undefined' &&
    //         _loadType === 'server-pagination') {
    //             console.error('Server pagination requires callback to retrieve data. Please provide the callback function.');
    //     }
    //     return undefined;
    // }
    _checkPaginationType(_loadType) {
        if (_loadType === 'infinite')
            return 'infinite';
        if (_loadType === 'server-pagination' || _loadType === 'oneshot-pagination')
            return 'pagination';
        return '';
    }
    _checkLoadType(_config) {
        let defaultLoadType = 'normal';
        if (typeof _config === 'undefined' || typeof _config.loadType === 'undefined') {
            return defaultLoadType;
        }
        if (_config.loadType === 'normal' ||
            _config.loadType === 'server-pagination' ||
            _config.loadType === 'virtual' ||
            _config.loadType === 'oneshot-pagination') {
            return _config.loadType;
        }
        return defaultLoadType;
    }
    _checkPagesize(_config, _loadType) {
        if (_loadType === 'normal')
            return -1;
        if (typeof _config !== 'undefined' && typeof _config.pagesize !== 'undefined')
            return _config.pagesize;
        return 25;
    }
    _getRowHeight(_params) {
        let gridOptions = this;
        let colDef = gridOptions.columnDefs;
        let rowHeight = 50;
        for (let i = 0; i < colDef.length; i++) {
            if (typeof colDef[i].config !== 'undefined') {
                if (typeof colDef[i].config.photo !== 'undefined' && colDef[i].config.photo)
                    return 120;
                else if (typeof colDef[i].config.textarea !== 'undefined' && colDef[i].config.textarea)
                    return 120;
                else if (typeof colDef[i].config.input !== 'undefined' && colDef[i].config.input) {
                    if (_params.data[colDef[i].colId] instanceof Array)
                        return rowHeight * _params.data[colDef[i].colId].length;
                }
            }
        }
        return 50;
    }
    _checkBtnConfig(_buttonList) {
        let updatedBtnConfig = [];
        for (let i = 0; i < _buttonList.length; i++) {
            updatedBtnConfig.push(this._checkButton(_buttonList[i]));
        }
        return updatedBtnConfig;
    }
    _checkButton(_buttonItem) {
        let defaultButton = {
            type: null,
            label: '',
            icon: '',
            config: null,
            callback: null,
            path: null
        };
        return Object.assign(defaultButton, _buttonItem);
    }
}
KdAggridSvc.decorators = [
    { type: Injectable }
];
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoia2QtYW5ndWxhci1hZ2dyaWQtc3ZjLmpzIiwic291cmNlUm9vdCI6IkQ6L29wZW5FTUlTL3N0eWxlZ3VpZGUvaW9zdGctb3BlbmVtaXMtc3R5bGVndWlkZS9wcm9qZWN0cy9vcGVuZW1pcy1zdHlsZWd1aWRlLWxpYi9zcmMvIiwic291cmNlcyI6WyJrZC1jb21wb25lbnRzL2tkLWFuZ3VsYXItYWdncmlkL3NyYy9rZC1hbmd1bGFyLWFnZ3JpZC1zdmMudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsT0FBTyxFQUFFLFVBQVUsRUFBb0IsTUFBTSxlQUFlLENBQUM7QUFHN0QsV0FBVztBQUNYLG9CQUFvQjtBQUNwQixpQkFBaUI7QUFDakIsZ0JBQWdCO0FBQ2hCLHdCQUF3QjtBQUN4QixzREFBc0Q7QUFHdEQsTUFBTSxPQUFPLFdBQVc7SUFEeEI7UUFFWSxtQkFBYyxHQUFXLENBQUMsQ0FBQztJQXFqQnZDLENBQUM7SUFwakJHLGlEQUFpRDtJQUVqRCxjQUFjO1FBQ1YsSUFBSSxPQUFPLEdBQVE7WUFDZixPQUFPLEVBQUUsRUFBRTtZQUNYLFVBQVUsRUFBRSxFQUFFO1lBQ2QsZUFBZTtZQUNmLFlBQVksRUFBRSxFQUFFO1lBQ2hCLFlBQVksRUFBRSxJQUFJLENBQUMsYUFBYTtZQUNoQyxxQkFBcUI7WUFDckIsZ0JBQWdCO1lBQ2hCLG1CQUFtQixFQUFFLElBQUk7WUFDekIsK0JBQStCO1lBQy9CLGlDQUFpQztZQUNqQyxzQkFBc0IsRUFBRSxJQUFJO1lBQzVCLGdCQUFnQixFQUFFLElBQUk7WUFDdEIsNEJBQTRCLEVBQUUsSUFBSTtZQUNsQyxVQUFVLEVBQUUsSUFBSTtZQUNoQixLQUFLLEVBQUU7Z0JBQ0gsTUFBTSxFQUFFLDJCQUEyQjtnQkFDbkMsYUFBYSxFQUFFLCtCQUErQjtnQkFDOUMsY0FBYyxFQUFFLDZCQUE2QjtnQkFDN0MsVUFBVSxFQUFFLHlCQUF5QjtnQkFDckMsYUFBYSxFQUFFLGlDQUFpQztnQkFDaEQsZUFBZSxFQUFFLGdDQUFnQzthQUNwRDtZQUNELHFCQUFxQixFQUFFLHNIQUFzSDtTQUNoSixDQUFDO1FBQ0YsT0FBTyxPQUFPLENBQUM7SUFDbkIsQ0FBQztJQUVELFNBQVMsQ0FBQyxPQUFZO1FBQ2xCLElBQUksWUFBWSxHQUFRLEVBQUUsQ0FBQztRQUMzQixZQUFZLENBQUMsRUFBRSxHQUFHLENBQUMsT0FBTyxPQUFPLEtBQUssV0FBVyxJQUFJLE9BQU8sT0FBTyxDQUFDLEVBQUUsS0FBSyxXQUFXLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDO1FBQ2pILFlBQVksQ0FBQyxVQUFVLEdBQUcsSUFBSSxDQUFDLGdCQUFnQixDQUFDLE9BQU8sQ0FBQyxDQUFDO1FBQ3pELFlBQVksQ0FBQyxRQUFRLEdBQUcsQ0FBQyxPQUFPLE9BQU8sS0FBSyxXQUFXLElBQUksT0FBTyxPQUFPLENBQUMsUUFBUSxLQUFLLFdBQVcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUM7UUFDL0gsWUFBWSxDQUFDLEtBQUssR0FBRyxDQUFDLE9BQU8sT0FBTyxLQUFLLFdBQVcsSUFBSSxPQUFPLE9BQU8sQ0FBQyxLQUFLLEtBQUssV0FBVyxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQztRQUN0SCxZQUFZLENBQUMsY0FBYyxHQUFHLENBQUMsT0FBTyxPQUFPLEtBQUssV0FBVyxJQUFJLE9BQU8sT0FBTyxDQUFDLGNBQWMsS0FBSyxXQUFXLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLGNBQWMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDO1FBQ2pKLFlBQVksQ0FBQyxRQUFRLEdBQUcsSUFBSSxDQUFDLGNBQWMsQ0FBQyxPQUFPLENBQUMsQ0FBQztRQUNyRCxZQUFZLENBQUMsY0FBYyxHQUFHLElBQUksQ0FBQyxvQkFBb0IsQ0FBQyxZQUFZLENBQUMsUUFBUSxDQUFDLENBQUM7UUFDL0UsWUFBWSxDQUFDLFFBQVEsR0FBRyxJQUFJLENBQUMsY0FBYyxDQUFDLE9BQU8sRUFBRSxZQUFZLENBQUMsUUFBUSxDQUFDLENBQUM7UUFDNUUsWUFBWSxDQUFDLFNBQVMsR0FBRyxDQUFDLE9BQU8sT0FBTyxLQUFLLFdBQVcsSUFBSSxPQUFPLE9BQU8sQ0FBQyxTQUFTLEtBQUssV0FBVyxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO1FBQy9ILFlBQVksQ0FBQyxNQUFNLEdBQUcsQ0FBQyxPQUFPLE9BQU8sS0FBSyxXQUFXLElBQUksT0FBTyxPQUFPLENBQUMsTUFBTSxLQUFLLFdBQVcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUM7UUFDekgsWUFBWSxDQUFDLFlBQVksR0FBRyxDQUFDLE9BQU8sT0FBTyxLQUFLLFdBQVcsSUFBSSxPQUFPLE9BQU8sQ0FBQyxZQUFZLEtBQUssV0FBVyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxlQUFlLENBQUMsT0FBTyxDQUFDLFlBQVksQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUM7UUFDaEssWUFBWSxDQUFDLFNBQVMsR0FBRyxDQUFDLE9BQU8sT0FBTyxLQUFLLFdBQVcsSUFBSSxPQUFPLE9BQU8sQ0FBQyxTQUFTLEtBQUssV0FBVyxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQztRQUNySSxZQUFZLENBQUMsb0JBQW9CLEdBQUcsQ0FBQyxPQUFPLE9BQU8sS0FBSyxXQUFXLElBQUksT0FBTyxPQUFPLENBQUMsb0JBQW9CLEtBQUssV0FBVyxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxvQkFBb0IsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDO1FBQ2xLLFlBQVksQ0FBQyxZQUFZLEdBQUcsQ0FBQyxPQUFPLE9BQU8sS0FBSyxXQUFXLElBQUksT0FBTyxPQUFPLENBQUMsWUFBWSxLQUFLLFdBQVcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsWUFBWSxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUM7UUFDM0ksWUFBWSxDQUFDLGdCQUFnQixHQUFHLENBQUMsT0FBTyxPQUFPLEtBQUssV0FBVyxJQUFJLE9BQU8sT0FBTyxDQUFDLGdCQUFnQixLQUFLLFdBQVcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsZ0JBQWdCLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQztRQUV0SixJQUFJLFlBQVksQ0FBQyxLQUFLLElBQUksWUFBWSxDQUFDLFFBQVE7WUFBRSxZQUFZLENBQUMsS0FBSyxHQUFHLEtBQUssQ0FBQztRQUM1RSxPQUFPLFlBQVksQ0FBQztJQUN4QixDQUFDO0lBRUQsWUFBWSxDQUFDLFFBQW9CO1FBQzdCLElBQUksU0FBUyxHQUFlLENBQUMsT0FBTyxRQUFRLEtBQUssV0FBVyxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDO1FBQzlFLE9BQU8sU0FBUyxDQUFDO0lBQ3JCLENBQUM7SUFFRCxVQUFVLENBQUMsT0FBWSxFQUFFLFlBQXlCLEVBQUUseUJBQXlCLENBQUEsT0FBZ0IsRUFBRSxlQUF3QixLQUFLO1FBQ3hILElBQUksWUFBWSxHQUFRLEVBQUUsUUFBUSxFQUFFLEtBQUssRUFBRSxhQUFhLEVBQUUsRUFBRSxFQUFFLENBQUM7UUFDL0QsSUFBSSxXQUFXLEdBQVEsRUFBRSxDQUFDO1FBRTFCLEtBQUssSUFBSSxHQUFHLElBQUksT0FBTyxFQUFFO1lBQ3JCLElBQUksT0FBTyxDQUFDLGNBQWMsQ0FBQyxHQUFHLENBQUMsRUFBRTtnQkFDN0IsSUFBSSxDQUFDLGNBQWMsRUFBRSxDQUFDO2dCQUV0QixXQUFXLEdBQUc7b0JBQ1YsVUFBVSxFQUFFLE9BQU8sQ0FBQyxHQUFHLENBQUMsQ0FBQyxVQUFVO29CQUNuQyxLQUFLLEVBQUUsQ0FBQyxPQUFPLE9BQU8sQ0FBQyxHQUFHLENBQUMsQ0FBQyxNQUFNLEtBQUssV0FBVyxJQUFJLE9BQU8sT0FBTyxDQUFDLEdBQUcsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxHQUFHLEtBQUssV0FBVyxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxHQUFHO29CQUNySSxRQUFRLEVBQUUsS0FBSztvQkFDZixZQUFZLEVBQUUsQ0FBQyxPQUFPLE9BQU8sQ0FBQyxHQUFHLENBQUMsQ0FBQyxVQUFVLEtBQUssV0FBVyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxDQUFDLFVBQVUsQ0FBQyxDQUFDLENBQUMsSUFBSTtvQkFDaEcsZUFBZSxFQUFFLENBQUMsT0FBTyxPQUFPLENBQUMsR0FBRyxDQUFDLENBQUMsUUFBUSxLQUFLLFdBQVcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLElBQUk7b0JBQy9GLEtBQUssRUFBRSxHQUFHO29CQUNWLE1BQU0sRUFBRSxDQUFDLE9BQU8sT0FBTyxDQUFDLEdBQUcsQ0FBQyxDQUFDLE1BQU0sS0FBSyxXQUFXLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsU0FBUztvQkFDdEYseUNBQXlDO29CQUN6QywrQ0FBK0M7b0JBQy9DLDJDQUEyQztvQkFDM0MsUUFBUTtvQkFDUixpREFBaUQ7b0JBQ2pELHlDQUF5QztvQkFDekMsUUFBUTtvQkFDUiw0QkFBNEI7b0JBQzVCLEtBQUs7b0JBQ0wsSUFBSSxFQUFFLENBQUMsT0FBTyxPQUFPLENBQUMsR0FBRyxDQUFDLENBQUMsT0FBTyxLQUFLLFdBQVcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLO29CQUNyRixTQUFTLEVBQUUsWUFBWTtpQkFDMUIsQ0FBQztnQkFFRixJQUFJLENBQUMsV0FBVyxDQUFDLFlBQVksRUFBRTtvQkFDM0IsV0FBVyxDQUFDLFVBQVUsQ0FBQyxHQUFHLENBQUMsZUFBZSxDQUFDLENBQUM7b0JBQzVDLFdBQVcsQ0FBQyxZQUFZLEdBQUc7d0JBQ3ZCLGFBQWEsRUFBRSxNQUFNO3dCQUNyQixVQUFVLEVBQUUsRUFBRTt3QkFDZCxxQkFBcUIsRUFBRSxJQUFJO3dCQUMzQixNQUFNLEVBQUUsQ0FBQyxPQUFPLE9BQU8sQ0FBQyxHQUFHLENBQUMsQ0FBQyxTQUFTLEtBQUssV0FBVyxJQUFJLE9BQU8sQ0FBQyxHQUFHLENBQUMsQ0FBQyxTQUFTLENBQUMsTUFBTSxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxTQUFTO3FCQUNwSSxDQUFDO2lCQUNMO2dCQUVELElBQUksT0FBTyxPQUFPLENBQUMsR0FBRyxDQUFDLENBQUMsTUFBTSxLQUFLLFdBQVcsRUFBRTtvQkFDNUMsSUFBSSxPQUFPLE9BQU8sQ0FBQyxHQUFHLENBQUMsQ0FBQyxNQUFNLENBQUMsS0FBSyxLQUFLLFdBQVcsSUFBSSxPQUFPLENBQUMsR0FBRyxDQUFDLENBQUMsTUFBTSxDQUFDLEtBQUssRUFBRTt3QkFDL0UsWUFBWSxDQUFDLFFBQVEsR0FBRyxJQUFJLENBQUM7cUJBQ2hDO29CQUVELFdBQVcsR0FBRyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsV0FBVyxFQUFFLE9BQU8sQ0FBQyxHQUFHLENBQUMsQ0FBQyxNQUFNLEVBQUUsYUFBYSxDQUFDLE9BQU8sQ0FBQyxDQUFDO29CQUU3RixJQUFJLFdBQVcsQ0FBQyxjQUFjLENBQUMsdUJBQXVCLENBQUMsRUFBRTt3QkFDckQsT0FBTyxXQUFXLENBQUMsWUFBWSxDQUFDO3FCQUNuQztpQkFDSjtnQkFFRCxJQUFJLE9BQU8sV0FBVyxDQUFDLE1BQU0sS0FBSyxXQUFXLElBQUksQ0FDN0MsQ0FBQyxPQUFPLFdBQVcsQ0FBQyxNQUFNLENBQUMsUUFBUSxLQUFLLFdBQVcsSUFBSSxXQUFXLENBQUMsTUFBTSxDQUFDLFFBQVEsQ0FBQztvQkFDbkYsQ0FBQyxPQUFPLFdBQVcsQ0FBQyxNQUFNLENBQUMsS0FBSyxLQUFLLFdBQVcsSUFBSSxXQUFXLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxDQUFDLEVBQUU7b0JBQzVFLFlBQVksQ0FBQyxhQUFhLENBQUMsT0FBTyxDQUFDLFdBQVcsQ0FBQyxDQUFDO2lCQUN2RDtxQkFDSTtvQkFDRCxZQUFZLENBQUMsYUFBYSxDQUFDLElBQUksQ0FBQyxXQUFXLENBQUMsQ0FBQztpQkFDaEQ7YUFDSjtTQUNKO1FBRUQsT0FBTyxZQUFZLENBQUM7SUFDeEIsQ0FBQztJQUVELHVCQUF1QixDQUFDLE1BQVc7UUFDL0IsSUFBSSxjQUFjLEdBQUcsTUFBTSxDQUFDLFdBQVcsQ0FBQztRQUV4QyxJQUFJLE1BQU0sQ0FBQyxRQUFRLEtBQUssbUJBQW1CLElBQUksTUFBTSxDQUFDLFFBQVEsS0FBSyxvQkFBb0IsRUFBRTtZQUNyRixjQUFjLENBQUMsc0JBQXNCLEdBQUcsSUFBSSxDQUFDO1lBQzdDLGNBQWMsQ0FBQyx1QkFBdUIsR0FBRyxJQUFJLENBQUM7WUFDOUMsY0FBYyxDQUFDLGtCQUFrQixHQUFHLE1BQU0sQ0FBQyxRQUFRLENBQUM7U0FDdkQ7YUFDSSxJQUFJLE1BQU0sQ0FBQyxRQUFRLEtBQUssU0FBUyxFQUFFO1lBQ3BDLGNBQWMsQ0FBQyxzQkFBc0IsR0FBRyxJQUFJLENBQUM7WUFDN0MsY0FBYyxDQUFDLHVCQUF1QixHQUFHLElBQUksQ0FBQztZQUM5QyxjQUFjLENBQUMsa0JBQWtCLEdBQUcsTUFBTSxDQUFDLFFBQVEsQ0FBQztZQUNwRCxjQUFjLENBQUMsZUFBZSxHQUFHLENBQUMsQ0FBQztZQUNuQyxjQUFjLENBQUMsK0JBQStCLEdBQUcsQ0FBQyxDQUFDO1lBQ25ELGNBQWMsQ0FBQyxZQUFZLEdBQUcsRUFBRSxDQUFDO1NBQ3BDO2FBQ0k7WUFDRCxjQUFjLENBQUMsWUFBWSxHQUFHLElBQUksQ0FBQztZQUNuQyxjQUFjLENBQUMsYUFBYSxHQUFHLElBQUksQ0FBQztTQUN2QztRQUVELElBQUksTUFBTSxDQUFDLFFBQVEsS0FBSyxtQkFBbUIsSUFBSSxNQUFNLENBQUMsUUFBUSxLQUFLLG9CQUFvQixFQUFFO1lBQ3JGLGNBQWMsQ0FBQyxVQUFVLEdBQUcsSUFBSSxDQUFDO1NBQ3BDO2FBQ0k7WUFDRCxjQUFjLENBQUMsWUFBWSxHQUFHLE1BQU0sQ0FBQyxjQUFjLENBQUM7U0FDdkQ7UUFFRCxPQUFPLGNBQWMsQ0FBQztJQUMxQixDQUFDO0lBRUQsWUFBWSxDQUFDLFlBQXlCO1FBQ2xDLElBQUksT0FBTyxHQUFrQixZQUFZLENBQUMsU0FBUyxDQUFDLGFBQWEsRUFBRSxDQUFDO1FBQ3BFLElBQUksWUFBWSxHQUF1QyxFQUFFLENBQUM7UUFFMUQsS0FBSyxJQUFJLENBQUMsR0FBVyxDQUFDLEVBQUUsQ0FBQyxHQUFHLE9BQU8sQ0FBQyxNQUFNLEVBQUUsQ0FBQyxFQUFFLEVBQUU7WUFDN0MsSUFBSSxTQUFTLEdBQVEsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLFNBQVMsRUFBRSxDQUFDO1lBQzVDLElBQUksUUFBUSxHQUFXLENBQUMsQ0FBQyxDQUFDO1lBRTFCLElBQUksU0FBUyxDQUFDLFNBQVMsQ0FBQyxPQUFPLENBQUMsbUJBQW1CLENBQUMsS0FBSyxDQUFDLENBQUMsRUFBRTtnQkFDekQsUUFBUSxHQUFHLEVBQUUsQ0FBQztnQkFDZCxZQUFZLENBQUMsU0FBUyxDQUFDLGNBQWMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLEVBQUUsUUFBUSxDQUFDLENBQUM7YUFDL0Q7aUJBQ0ksSUFBSSxPQUFPLFNBQVMsQ0FBQyxNQUFNLEtBQUssV0FBVyxJQUFJLE9BQU8sU0FBUyxDQUFDLE1BQU0sQ0FBQyxNQUFNLEtBQUssV0FBVyxJQUFJLFNBQVMsQ0FBQyxNQUFNLENBQUMsTUFBTSxFQUFFO2dCQUMzSCxRQUFRLEdBQUcsR0FBRyxDQUFDO2dCQUNmLFlBQVksQ0FBQyxTQUFTLENBQUMsY0FBYyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsRUFBRSxRQUFRLENBQUMsQ0FBQzthQUMvRDtpQkFDSSxJQUFJLE9BQU8sU0FBUyxDQUFDLE1BQU0sS0FBSyxXQUFXLElBQUksT0FBTyxTQUFTLENBQUMsTUFBTSxDQUFDLEtBQUssS0FBSyxXQUFXLElBQUksU0FBUyxDQUFDLE1BQU0sQ0FBQyxLQUFLLEVBQUU7Z0JBQ3pILFFBQVEsR0FBRyxHQUFHLENBQUM7Z0JBQ2YsWUFBWSxDQUFDLFNBQVMsQ0FBQyxjQUFjLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxFQUFFLFFBQVEsQ0FBQyxDQUFDO2FBQy9EO2lCQUNJLElBQUksT0FBTyxTQUFTLENBQUMsTUFBTSxLQUFLLFdBQVcsSUFBSSxPQUFPLFNBQVMsQ0FBQyxNQUFNLENBQUMsS0FBSyxLQUFLLFdBQVcsSUFBSSxTQUFTLENBQUMsTUFBTSxDQUFDLEtBQUssRUFBRTtnQkFDekgsUUFBUSxHQUFHLEdBQUcsQ0FBQzthQUNsQjtpQkFDSTtnQkFDRCxRQUFRLEdBQUcsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLGNBQWMsRUFBRSxHQUFHLEVBQUUsQ0FBQzthQUMvQztZQUVELFlBQVksQ0FBQyxJQUFJLENBQUMsRUFBQyxLQUFLLEVBQUUsUUFBUSxFQUFFLEVBQUUsRUFBRSxTQUFTLENBQUMsS0FBSyxFQUFDLENBQUMsQ0FBQztTQUM3RDtRQUVELE9BQU8sWUFBWSxDQUFDO0lBQ3hCLENBQUM7SUFFRCxhQUFhLENBQUMsU0FBNkMsRUFBRSxNQUFxQjtRQUM5RSxJQUFJLEtBQUssR0FBVyxDQUFDLENBQUM7UUFDdEIsS0FBSyxJQUFJLENBQUMsR0FBVyxDQUFDLEVBQUUsQ0FBQyxHQUFHLFNBQVMsQ0FBQyxNQUFNLEVBQUUsQ0FBQyxFQUFFLEVBQUU7WUFDL0MsSUFBSSxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsU0FBUyxFQUFFLEVBQUU7Z0JBQ3ZCLEtBQUssSUFBSSxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDO2FBQy9CO1NBQ0o7UUFFRCxPQUFPLEtBQUssQ0FBQztJQUNqQixDQUFDO0lBRUQsZUFBZSxDQUFDLElBQXNCO1FBQ2xDLElBQUksU0FBUyxHQUFnQixJQUFJLENBQUMsT0FBTyxDQUFDLGFBQWEsQ0FBQyxhQUFhLENBQUMsWUFBWSxDQUFDLENBQUM7UUFDcEYsSUFBSSxXQUFXLEdBQVcsSUFBSSxDQUFDLEtBQUssQ0FBQyxTQUFTLENBQUMscUJBQXFCLEVBQUUsQ0FBQyxLQUFLLENBQUMsQ0FBQztRQUM5RSxJQUFJLGFBQWEsR0FBd0IsTUFBTSxDQUFDLGdCQUFnQixDQUFDLFNBQVMsQ0FBQyxDQUFDO1FBQzVFLElBQUksVUFBVSxHQUFXLENBQUMsYUFBYSxDQUFDLFVBQVUsS0FBSyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLGFBQWEsQ0FBQyxVQUFVLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO1FBQ3BHLElBQUksV0FBVyxHQUFXLENBQUMsYUFBYSxDQUFDLFdBQVcsS0FBSyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLGFBQWEsQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO1FBQ3ZHLElBQUksZUFBZSxHQUFHLFVBQVUsR0FBRyxXQUFXLENBQUM7UUFDL0MsT0FBTyxXQUFXLEdBQUcsZUFBZSxDQUFDO0lBQ3pDLENBQUM7SUFFRCxpQkFBaUIsQ0FBQyxRQUF1QjtRQUNyQyxJQUFJLGFBQWEsR0FBVyxJQUFJLENBQUMsY0FBYyxDQUFDO1FBRWhELEtBQUssSUFBSSxDQUFDLEdBQVcsQ0FBQyxFQUFFLENBQUMsR0FBRyxRQUFRLENBQUMsTUFBTSxFQUFFLENBQUMsRUFBRSxFQUFFO1lBQzlDLElBQUksTUFBTSxHQUFRLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxTQUFTLEVBQUUsQ0FBQztZQUUxQyxJQUFJLE9BQU8sTUFBTSxDQUFDLE1BQU0sS0FBSyxXQUFXLElBQUksQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsU0FBUyxFQUFFLEVBQUU7Z0JBQ2xFLEVBQUUsYUFBYSxDQUFDO2FBQ25CO1lBRUQsMkJBQTJCO1NBQzlCO1FBRUQsT0FBTyxhQUFhLENBQUM7SUFDekIsQ0FBQztJQUVELGlCQUFpQixDQUFDLFdBQWdCLEVBQUUsTUFBaUIsRUFBRSxJQUFzQjtRQUN6RSxJQUFJLFlBQVksR0FBVyxFQUFFLEdBQUcsQ0FBQyxDQUFDO1FBQ2xDLElBQUksT0FBTyxHQUFZLElBQUksQ0FBQyxPQUFPLENBQUMsYUFBYSxDQUFDLGFBQWEsQ0FBQyxRQUFRLENBQUMsQ0FBQztRQUUxRSxJQUFJLE9BQU8sS0FBSyxJQUFJLEVBQUU7WUFDbEIsWUFBWSxJQUFJLE9BQU8sQ0FBQyxxQkFBcUIsRUFBRSxDQUFDLE1BQU0sQ0FBQztTQUMxRDtRQUVELEtBQUssSUFBSSxDQUFDLEdBQVcsQ0FBQyxFQUFFLENBQUMsR0FBRyxNQUFNLENBQUMsV0FBVyxFQUFFLEVBQUUsQ0FBQyxFQUFFLEVBQUU7WUFDbkQsWUFBWSxJQUFJLE1BQU0sQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDO1lBQzNDLElBQUksWUFBWSxHQUFHLFdBQVcsRUFBRTtnQkFDNUIsTUFBTTthQUNUO1NBQ0o7UUFFRCxJQUFJLFlBQVksR0FBRyxXQUFXLEVBQUU7WUFDNUIsT0FBTyxZQUFZLENBQUM7U0FDdkI7UUFFRCxPQUFPLFdBQVcsQ0FBQztJQUN2QixDQUFDO0lBRUQsb0JBQW9CLENBQUMsSUFBc0I7UUFDdkMsSUFBSSxXQUFXLEdBQVcsQ0FBQyxDQUFDO1FBQzVCLElBQUksU0FBUyxHQUFZLElBQUksQ0FBQyxPQUFPLENBQUMsYUFBYSxDQUFDO1FBQ3BELElBQUksZUFBZSxHQUFZLFNBQVMsQ0FBQyxhQUFhLENBQUMsc0JBQXNCLENBQUMsQ0FBQztRQUMvRSxJQUFJLFNBQVMsS0FBSyxJQUFJLElBQUksZUFBZSxLQUFLLElBQUk7WUFBRSxPQUFPLFdBQVcsQ0FBQztRQUN2RSxXQUFXLElBQUksSUFBSSxDQUFDLElBQUksQ0FBQyxlQUFlLENBQUMscUJBQXFCLEVBQUUsQ0FBQyxNQUFNLENBQUMsQ0FBQztRQUN6RSxXQUFXLElBQUksSUFBSSxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsYUFBYSxDQUFDLG9CQUFvQixDQUFDLENBQUMscUJBQXFCLEVBQUUsQ0FBQyxNQUFNLENBQUMsQ0FBQztRQUV2RyxJQUFJLGdCQUFnQixHQUFZLFNBQVMsQ0FBQyxhQUFhLENBQUMsUUFBUSxDQUFDLENBQUM7UUFDbEUsSUFBSSxnQkFBZ0IsS0FBSyxJQUFJLEVBQUU7WUFDM0IsV0FBVyxJQUFJLElBQUksQ0FBQyxJQUFJLENBQUMsZ0JBQWdCLENBQUMscUJBQXFCLEVBQUUsQ0FBQyxNQUFNLENBQUMsQ0FBQztTQUM3RTtRQUNELFdBQVcsSUFBSSxDQUFDLENBQUM7UUFDakIsT0FBTyxXQUFXLENBQUM7SUFDdkIsQ0FBQztJQUVELG1CQUFtQixDQUFDLEtBQWlCLEVBQUUsVUFBc0IsRUFBRSxZQUFpQjtRQUM1RSxPQUFPLElBQUksQ0FBQyxlQUFlLENBQUMsVUFBVSxFQUFFLElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxZQUFZLEVBQUUsS0FBSyxDQUFDLENBQUMsQ0FBQztJQUN6RixDQUFDO0lBRUQsY0FBYyxDQUFDLE9BQVksRUFBRSxZQUFxQixFQUFFLFNBQWtCO1FBQ2xFLElBQUksWUFBWSxFQUFFO1lBQ2QsT0FBTyxDQUFDLGFBQWEsQ0FBQyxHQUFHO2dCQUNyQixNQUFNLEVBQUU7b0JBQ0osUUFBUSxFQUFFLElBQUk7aUJBQ2pCO2FBQ0osQ0FBQztTQUNMO2FBQ0ksSUFBSSxTQUFTLEVBQUU7WUFDaEIsT0FBTyxDQUFDLFVBQVUsQ0FBQyxHQUFHO2dCQUNsQixNQUFNLEVBQUU7b0JBQ0osS0FBSyxFQUFFLElBQUk7aUJBQ2Q7YUFDSixDQUFDO1NBQ0w7UUFFRCxPQUFPLE9BQU8sQ0FBQztJQUNuQixDQUFDO0lBRUQsYUFBYSxDQUFDLFFBQWEsRUFBRSxPQUFzQjtRQUMvQyxJQUFJLE9BQU8sUUFBUSxDQUFDLE1BQU0sS0FBSyxXQUFXLEVBQUU7WUFDeEMsT0FBTyxRQUFRLENBQUMsTUFBTSxDQUFDO1NBQzFCO1FBRUQsS0FBSyxJQUFJLENBQUMsR0FBVyxDQUFDLEVBQUUsQ0FBQyxHQUFHLE9BQU8sQ0FBQyxNQUFNLEVBQUUsQ0FBQyxFQUFFLEVBQUU7WUFDN0MsSUFBSSxNQUFNLEdBQVEsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLFNBQVMsRUFBRSxDQUFDO1lBQ3pDLElBQUksT0FBTyxNQUFNLENBQUMsTUFBTSxLQUFLLFdBQVc7Z0JBQ3BDLE9BQU8sTUFBTSxDQUFDLE1BQU0sQ0FBQyxNQUFNLEtBQUssV0FBVztnQkFDM0MsTUFBTSxDQUFDLE1BQU0sQ0FBQyxNQUFNLEVBQUU7Z0JBQ2xCLE9BQU8sTUFBTSxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUM7YUFDbEM7U0FDSjtRQUNELE9BQU8sRUFBRSxDQUFDO0lBQ2QsQ0FBQztJQUVELHNCQUFzQixDQUFDLFNBQWdCO1FBQ25DLElBQUksT0FBTyxHQUE2QixTQUFTLENBQUMsTUFBTSxDQUFDO1FBQ3pELElBQUksU0FBUyxHQUFrQixDQUFDLFlBQVksRUFBRSxzQkFBc0IsRUFBRSxpQkFBaUIsQ0FBQyxDQUFDO1FBRXpGLEtBQUssSUFBSSxDQUFDLEdBQVcsQ0FBQyxFQUFFLENBQUMsR0FBRyxTQUFTLENBQUMsTUFBTSxFQUFFLENBQUMsRUFBRSxFQUFFO1lBQy9DLElBQUksT0FBTyxDQUFDLFNBQVMsQ0FBQyxRQUFRLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUU7Z0JBQzFDLE9BQU8sS0FBSyxDQUFDO2FBQ2hCO1NBQ0o7UUFFRCxPQUFPLElBQUksQ0FBQztJQUNoQixDQUFDO0lBRUQsbUJBQW1CLENBQUMsT0FBWTtRQUM1QixJQUFJLE9BQU8sQ0FBQyxTQUFTLENBQUMsT0FBTyxDQUFDLG1CQUFtQixDQUFDLEtBQUssQ0FBQyxDQUFDLEVBQUU7WUFDdkQsT0FBTyxJQUFJLENBQUM7U0FDZjtRQUVELElBQUksT0FBTyxPQUFPLENBQUMsTUFBTSxLQUFLLFdBQVc7WUFDckMsQ0FBQyxDQUFDLE9BQU8sT0FBTyxDQUFDLE1BQU0sQ0FBQyxLQUFLLEtBQUssV0FBVyxJQUFJLE9BQU8sQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDO2dCQUNyRSxDQUFDLE9BQU8sT0FBTyxDQUFDLE1BQU0sQ0FBQyxNQUFNLEtBQUssV0FBVyxJQUFJLE9BQU8sQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLENBQUMsRUFDM0U7WUFDRSxPQUFPLElBQUksQ0FBQztTQUNmO1FBRUQsT0FBTyxLQUFLLENBQUM7SUFDakIsQ0FBQztJQUVPLGdCQUFnQixDQUFDLE9BQVksRUFBRSxPQUFZLEVBQUUsd0JBQXdCLENBQUMsT0FBZ0I7UUFDMUYsSUFBSSxhQUFhLEdBQWMsTUFBTyxDQUFDLE1BQU0sQ0FBQyxFQUFFLEVBQUUsT0FBTyxDQUFDLENBQUM7UUFFM0QsK0RBQStEO1FBQy9ELHlDQUF5QztRQUN6Qyw0Q0FBNEM7UUFDNUMsMkNBQTJDO1FBQzNDLHNEQUFzRDtRQUN0RCxJQUFJO1FBRUosc0VBQXNFO1FBQ3RFLHlDQUF5QztRQUN6Qyw0Q0FBNEM7UUFDNUMsOENBQThDO1FBQzlDLGlDQUFpQztRQUNqQyxtREFBbUQ7UUFDbkQsMERBQTBEO1FBRTFELDZCQUE2QjtRQUM3QixJQUFJO1FBRUosb0VBQW9FO1FBQ3BFLHlDQUF5QztRQUN6Qyw0Q0FBNEM7UUFDNUMsOENBQThDO1FBQzlDLGlDQUFpQztRQUNqQyw0Q0FBNEM7UUFDNUMsdURBQXVEO1FBRXZELDZCQUE2QjtRQUM3QixJQUFJO1FBRUosMEVBQTBFO1FBQzFFLHlDQUF5QztRQUN6Qyw0Q0FBNEM7UUFDNUMsOENBQThDO1FBQzlDLGdDQUFnQztRQUNoQyxnRUFBZ0U7UUFDaEUsd0NBQXdDO1FBQ3hDLCtEQUErRDtRQUMvRCxrRUFBa0U7UUFFbEUsNkJBQTZCO1FBQzdCLElBQUk7UUFFSixvRUFBb0U7UUFDcEUseUNBQXlDO1FBQ3pDLDRDQUE0QztRQUM1Qyw4Q0FBOEM7UUFDOUMsZ0NBQWdDO1FBQ2hDLGdFQUFnRTtRQUNoRSxxQ0FBcUM7UUFDckMsK0RBQStEO1FBQy9ELHFDQUFxQztRQUVyQyw2QkFBNkI7UUFDN0IsSUFBSTtRQUVKLGdGQUFnRjtRQUM1RSx1REFBdUQ7UUFDdkQsaURBQWlEO1FBQ2pELCtDQUErQztRQUMvQyxpREFBaUQ7UUFDakQsc0VBQXNFO1FBQ3RFLHVHQUF1RztRQUN2RyxvRUFBb0U7UUFDcEUsZ0JBQWdCO1FBQ2hCLG1DQUFtQztRQUNuQyxZQUFZO1FBQ1osaUJBQWlCO1FBQ2pCLGdHQUFnRztRQUNoRyxvREFBb0Q7UUFDcEQsWUFBWTtRQUNaLFFBQVE7UUFDUiwyQkFBMkI7UUFDM0IsSUFBSTtRQUNSLElBQUk7UUFFSixPQUFPLGFBQWEsQ0FBQztJQUN6QixDQUFDO0lBRU8saUJBQWlCLENBQUMsWUFBaUIsRUFBRSxLQUFpQjtRQUMxRCxJQUFJLFlBQVksR0FBZSxLQUFLLENBQUMsS0FBSyxFQUFFLENBQUM7UUFFN0MsSUFBSSxPQUFPLFlBQVksS0FBSyxXQUFXLElBQUksTUFBTSxDQUFDLElBQUksQ0FBQyxZQUFZLENBQUMsQ0FBQyxNQUFNLEtBQUssQ0FBQyxFQUFFO1lBQy9FLE9BQU8sWUFBWSxDQUFDO1NBQ3ZCO1FBRUQsSUFBSSxXQUFXLEdBQWUsRUFBRSxDQUFDO1FBQ2pDLEtBQUssSUFBSSxHQUFHLElBQUksWUFBWSxFQUFFO1lBQzFCLElBQUksWUFBWSxDQUFDLGNBQWMsQ0FBQyxHQUFHLENBQUMsRUFBRTtnQkFDbEMsS0FBSyxJQUFJLENBQUMsR0FBVyxDQUFDLEVBQUUsQ0FBQyxHQUFHLFlBQVksQ0FBQyxHQUFHLENBQUMsQ0FBQyxNQUFNLEVBQUUsQ0FBQyxFQUFFLEVBQUU7b0JBQ3ZELEtBQUssSUFBSSxDQUFDLEdBQVcsQ0FBQyxFQUFFLENBQUMsR0FBRyxLQUFLLENBQUMsTUFBTSxFQUFFLENBQUMsRUFBRSxFQUFFO3dCQUMzQyxJQUFJLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsS0FBSyxZQUFZLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUU7NEJBQ3hDLFdBQVcsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7eUJBQzlCO3FCQUNKO2lCQUNKO2FBQ0o7U0FDSjtRQUVELE9BQU8sV0FBVyxDQUFDO0lBQ3ZCLENBQUM7SUFFTyxlQUFlLENBQUMsVUFBc0IsRUFBRSxLQUFpQjtRQUM3RCxJQUFJLFVBQVUsR0FBZSxLQUFLLENBQUMsS0FBSyxFQUFFLENBQUM7UUFFM0MsSUFBSSxPQUFPLFVBQVUsS0FBSyxXQUFXLElBQUksVUFBVSxDQUFDLE1BQU0sS0FBSyxDQUFDLEVBQUU7WUFDOUQsT0FBTyxVQUFVLENBQUM7U0FDckI7UUFFRCxVQUFVLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBTSxFQUFFLENBQU0sRUFBVSxFQUFFO1lBQ3ZDLEtBQUssSUFBSSxDQUFDLEdBQVcsQ0FBQyxFQUFFLENBQUMsR0FBRyxVQUFVLENBQUMsTUFBTSxFQUFFLENBQUMsRUFBRSxFQUFFO2dCQUNoRCxJQUFJLFlBQVksR0FBUSxVQUFVLENBQUMsQ0FBQyxDQUFDLENBQUM7Z0JBQ3RDLElBQUksSUFBSSxHQUFRLENBQUMsQ0FBQyxZQUFZLENBQUMsS0FBSyxDQUFDLENBQUM7Z0JBQ3RDLElBQUksSUFBSSxHQUFRLENBQUMsQ0FBQyxZQUFZLENBQUMsS0FBSyxDQUFDLENBQUM7Z0JBRXRDLElBQUksSUFBSSxLQUFLLElBQUksRUFBRTtvQkFDZixTQUFTO2lCQUNaO2dCQUVELElBQUksU0FBUyxHQUFHLENBQUMsWUFBWSxDQUFDLElBQUksS0FBSyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztnQkFFdkQsSUFBSSxJQUFJLEdBQUcsSUFBSSxFQUFFO29CQUNiLE9BQU8sU0FBUyxDQUFDO2lCQUNwQjtxQkFDSTtvQkFDRCxPQUFPLFNBQVMsR0FBRyxDQUFDLENBQUMsQ0FBQztpQkFDekI7YUFDSDtZQUVGLE9BQU8sQ0FBQyxDQUFDO1FBQ2IsQ0FBQyxDQUFDLENBQUM7UUFDSCxPQUFPLFVBQVUsQ0FBQztJQUN0QixDQUFDO0lBRU8sZ0JBQWdCLENBQUMsT0FBWTtRQUNqQyxJQUFJLGFBQWEsR0FBVyxHQUFHLENBQUM7UUFFaEMsSUFBSSxPQUFPLE9BQU8sS0FBSyxXQUFXLEVBQUU7WUFDaEMsT0FBTyxhQUFhLENBQUM7U0FDeEI7YUFFSSxJQUFJLE9BQU8sT0FBTyxDQUFDLFVBQVUsS0FBSyxXQUFXO1lBQzlDLE9BQU8sT0FBTyxDQUFDLFVBQVUsS0FBSyxRQUFRO1lBQ3RDLE9BQU8sQ0FBQyxVQUFVLEtBQUssTUFBTSxFQUFFO1lBQzNCLE9BQU8sT0FBTyxDQUFDLFVBQVUsQ0FBQztTQUNqQzthQUNJLElBQUksT0FBTyxPQUFPLENBQUMsVUFBVSxLQUFLLFdBQVc7WUFDOUMsT0FBTyxPQUFPLENBQUMsVUFBVSxLQUFLLFFBQVEsRUFBRTtZQUNwQyxPQUFPLE9BQU8sQ0FBQyxVQUFVLENBQUM7U0FDakM7UUFFRCxPQUFPLGFBQWEsQ0FBQztJQUN6QixDQUFDO0lBRUQsdUVBQXVFO0lBQ3ZFLDRDQUE0QztJQUM1Qyw4REFBOEQ7SUFDOUQsK0NBQStDO0lBQy9DLGdEQUFnRDtJQUNoRCxRQUFRO0lBQ1IsaURBQWlEO0lBQ2pELDhEQUE4RDtJQUM5RCwrQ0FBK0M7SUFDL0MsNEhBQTRIO0lBQzVILFFBQVE7SUFFUix3QkFBd0I7SUFDeEIsSUFBSTtJQUVJLG9CQUFvQixDQUFDLFNBQWlCO1FBQzFDLElBQUksU0FBUyxLQUFLLFVBQVU7WUFBRSxPQUFPLFVBQVUsQ0FBQztRQUNoRCxJQUFJLFNBQVMsS0FBSyxtQkFBbUIsSUFBSSxTQUFTLEtBQUssb0JBQW9CO1lBQUUsT0FBTyxZQUFZLENBQUM7UUFDakcsT0FBTyxFQUFFLENBQUM7SUFDZCxDQUFDO0lBRU8sY0FBYyxDQUFDLE9BQVk7UUFDL0IsSUFBSSxlQUFlLEdBQVcsUUFBUSxDQUFDO1FBRXZDLElBQUksT0FBTyxPQUFPLEtBQUssV0FBVyxJQUFJLE9BQU8sT0FBTyxDQUFDLFFBQVEsS0FBSyxXQUFXLEVBQUU7WUFDM0UsT0FBTyxlQUFlLENBQUM7U0FDMUI7UUFFRCxJQUFJLE9BQU8sQ0FBQyxRQUFRLEtBQUssUUFBUTtZQUM3QixPQUFPLENBQUMsUUFBUSxLQUFLLG1CQUFtQjtZQUN4QyxPQUFPLENBQUMsUUFBUSxLQUFLLFNBQVM7WUFDOUIsT0FBTyxDQUFDLFFBQVEsS0FBSyxvQkFBb0IsRUFBRTtZQUN2QyxPQUFPLE9BQU8sQ0FBQyxRQUFRLENBQUM7U0FDL0I7UUFFRCxPQUFPLGVBQWUsQ0FBQztJQUMzQixDQUFDO0lBRU8sY0FBYyxDQUFDLE9BQVksRUFBRSxTQUFpQjtRQUNsRCxJQUFJLFNBQVMsS0FBSyxRQUFRO1lBQUUsT0FBTyxDQUFDLENBQUMsQ0FBQztRQUN0QyxJQUFJLE9BQU8sT0FBTyxLQUFLLFdBQVcsSUFBSSxPQUFPLE9BQU8sQ0FBQyxRQUFRLEtBQUssV0FBVztZQUFFLE9BQU8sT0FBTyxDQUFDLFFBQVEsQ0FBQztRQUN2RyxPQUFPLEVBQUUsQ0FBQztJQUNkLENBQUM7SUFFTyxhQUFhLENBQUMsT0FBWTtRQUM5QixJQUFJLFdBQVcsR0FBUSxJQUFJLENBQUM7UUFDNUIsSUFBSSxNQUFNLEdBQWUsV0FBVyxDQUFDLFVBQVUsQ0FBQztRQUNoRCxJQUFJLFNBQVMsR0FBVyxFQUFFLENBQUM7UUFDM0IsS0FBSyxJQUFJLENBQUMsR0FBVyxDQUFDLEVBQUUsQ0FBQyxHQUFHLE1BQU0sQ0FBQyxNQUFNLEVBQUUsQ0FBQyxFQUFFLEVBQUU7WUFDNUMsSUFBSSxPQUFPLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLEtBQUssV0FBVyxFQUFFO2dCQUN6QyxJQUFJLE9BQU8sTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxLQUFLLEtBQUssV0FBVyxJQUFJLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsS0FBSztvQkFBRSxPQUFPLEdBQUcsQ0FBQztxQkFDbkYsSUFBSSxPQUFPLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsUUFBUSxLQUFLLFdBQVcsSUFBSSxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLFFBQVE7b0JBQUUsT0FBTyxHQUFHLENBQUM7cUJBQzlGLElBQUksT0FBTyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLEtBQUssS0FBSyxXQUFXLElBQUksTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxLQUFLLEVBQUU7b0JBQzlFLElBQUksT0FBTyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLFlBQVksS0FBSzt3QkFBRSxPQUFPLFNBQVMsR0FBRyxPQUFPLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxNQUFNLENBQUM7aUJBQy9HO2FBQ0o7U0FDSjtRQUNELE9BQU8sRUFBRSxDQUFDO0lBQ2QsQ0FBQztJQUVPLGVBQWUsQ0FBQyxXQUF1QjtRQUMzQyxJQUFJLGdCQUFnQixHQUFlLEVBQUUsQ0FBQztRQUN0QyxLQUFLLElBQUksQ0FBQyxHQUFXLENBQUMsRUFBRSxDQUFDLEdBQUcsV0FBVyxDQUFDLE1BQU0sRUFBRSxDQUFDLEVBQUUsRUFBRTtZQUNqRCxnQkFBZ0IsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLFlBQVksQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO1NBQzVEO1FBQ0QsT0FBTyxnQkFBZ0IsQ0FBQztJQUM1QixDQUFDO0lBRU8sWUFBWSxDQUFDLFdBQWdCO1FBQ2pDLElBQUksYUFBYSxHQUFRO1lBQ3JCLElBQUksRUFBRSxJQUFJO1lBQ1YsS0FBSyxFQUFFLEVBQUU7WUFDVCxJQUFJLEVBQUUsRUFBRTtZQUNSLE1BQU0sRUFBRSxJQUFJO1lBQ1osUUFBUSxFQUFFLElBQUk7WUFDZCxJQUFJLEVBQUUsSUFBSTtTQUNiLENBQUM7UUFDRixPQUFPLE1BQU0sQ0FBQyxNQUFNLENBQUMsYUFBYSxFQUFFLFdBQVcsQ0FBQyxDQUFDO0lBQ3JELENBQUM7OztZQXRqQkosVUFBVSIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IEluamVjdGFibGUsIFZpZXdDb250YWluZXJSZWYgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcclxuaW1wb3J0IHsgUm91dGVyIH0gZnJvbSAnQGFuZ3VsYXIvcm91dGVyJztcclxuaW1wb3J0IHsgR3JpZE9wdGlvbnMsIENvbHVtbiwgSVJvd01vZGVsIH0gZnJvbSAnYWctZ3JpZC1jb21tdW5pdHknO1xyXG4vLyBpbXBvcnQge1xyXG4vLyAgICAgS2RBR0Ryb3Bkb3duLFxyXG4vLyAgICAgS2RBR1Bob3RvLFxyXG4vLyAgICAgS2RBR0Zvcm0sXHJcbi8vICAgICBLZEFHQ2hlY2tib3hSYWRpb1xyXG4vLyB9IGZyb20gJy4vYWctZ3JpZC1jb21wb25lbnRzL2tkLWFnZ3JpZC1jb21wb25lbnRzJztcclxuXHJcbkBJbmplY3RhYmxlKClcclxuZXhwb3J0IGNsYXNzIEtkQWdncmlkU3ZjIHtcclxuICAgIHByaXZhdGUgX3Jlc2l6ZWFibGVDb2w6IG51bWJlciA9IDA7XHJcbiAgICAvLyBwcml2YXRlIF9kYXRhU3ZjOiBLZERhdGFTdmMgPSBuZXcgS2REYXRhU3ZjKCk7XHJcblxyXG4gICAgZ2V0R3JpZE9wdGlvbnMoKTogYW55IHtcclxuICAgICAgICBsZXQgb3B0aW9uczogYW55ID0ge1xyXG4gICAgICAgICAgICByb3dEYXRhOiBbXSxcclxuICAgICAgICAgICAgY29sdW1uRGVmczogW10sXHJcbiAgICAgICAgICAgIC8vIGRlYnVnOiB0cnVlLFxyXG4gICAgICAgICAgICBoZWFkZXJIZWlnaHQ6IDM4LFxyXG4gICAgICAgICAgICBnZXRSb3dIZWlnaHQ6IHRoaXMuX2dldFJvd0hlaWdodCxcclxuICAgICAgICAgICAgLy8gYW5pbWF0ZVJvd3M6IHRydWUsXHJcbiAgICAgICAgICAgIC8vIHJvd0J1ZmZlcjogNSxcclxuICAgICAgICAgICAgc3VwcHJlc3NDb250ZXh0TWVudTogdHJ1ZSxcclxuICAgICAgICAgICAgLy8gc3VwcHJlc3NNZW51TWFpblBhbmVsOiB0cnVlLFxyXG4gICAgICAgICAgICAvLyBzdXBwcmVzc01lbnVDb2x1bW5QYW5lbDogdHJ1ZSxcclxuICAgICAgICAgICAgc3VwcHJlc3NNb3ZhYmxlQ29sdW1uczogdHJ1ZSxcclxuICAgICAgICAgICAgc3VwcHJlc3NNZW51SGlkZTogdHJ1ZSxcclxuICAgICAgICAgICAgc3VwcHJlc3NDb2x1bW5WaXJ0dWFsaXNhdGlvbjogdHJ1ZSxcclxuICAgICAgICAgICAgdW5Tb3J0SWNvbjogdHJ1ZSxcclxuICAgICAgICAgICAgaWNvbnM6IHtcclxuICAgICAgICAgICAgICAgIGZpbHRlcjogJzxpIGNsYXNzPVwiZmEgZmEtZmlsdGVyXCIvPicsXHJcbiAgICAgICAgICAgICAgICBzb3J0QXNjZW5kaW5nOiAnPGkgY2xhc3M9XCJmYSBmYS1jYXJldC1kb3duXCIvPicsXHJcbiAgICAgICAgICAgICAgICBzb3J0RGVzY2VuZGluZzogJzxpIGNsYXNzPVwiZmEgZmEtY2FyZXQtdXBcIi8+JyxcclxuICAgICAgICAgICAgICAgIHNvcnRVblNvcnQ6ICc8aSBjbGFzcz1cImZhIGZhLXNvcnRcIi8+JyxcclxuICAgICAgICAgICAgICAgIGdyb3VwRXhwYW5kZWQ6ICc8aSBjbGFzcz1cImZhIGZhLW1pbnVzLWNpcmNsZVwiLz4nLFxyXG4gICAgICAgICAgICAgICAgZ3JvdXBDb250cmFjdGVkOiAnPGkgY2xhc3M9XCJmYSBmYS1wbHVzLWNpcmNsZVwiLz4nLFxyXG4gICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICBvdmVybGF5Tm9Sb3dzVGVtcGxhdGU6ICc8c3BhbiBjbGFzcz1cImFnLWN1c3RvbS1vdmVybGF5XCI+PGkgY2xhc3M9XCJmYSBmYS1pbmZvLWNpcmNsZSBmYS1sZyBtYXJnaW4tcmlnaHQxMFwiPjwvaT5ObyBzdHVkZW50IHJlY29yZCBmb3VuZDwvc3Bhbj4nXHJcbiAgICAgICAgfTtcclxuICAgICAgICByZXR1cm4gb3B0aW9ucztcclxuICAgIH1cclxuXHJcbiAgICBzZXRSZXN1bHQoX2NvbmZpZzogYW55KTogYW55IHtcclxuICAgICAgICBsZXQgdXBkYXRlUmVzdWx0OiBhbnkgPSB7fTtcclxuICAgICAgICB1cGRhdGVSZXN1bHQuaWQgPSAodHlwZW9mIF9jb25maWcgIT09ICd1bmRlZmluZWQnICYmIHR5cGVvZiBfY29uZmlnLmlkICE9PSAndW5kZWZpbmVkJykgPyBfY29uZmlnLmlkIDogJ2tkLWdyaWQnO1xyXG4gICAgICAgIHVwZGF0ZVJlc3VsdC5ncmlkSGVpZ2h0ID0gdGhpcy5fY2hlY2tHcmlkSGVpZ2h0KF9jb25maWcpO1xyXG4gICAgICAgIHVwZGF0ZVJlc3VsdC5jaGVja2JveCA9ICh0eXBlb2YgX2NvbmZpZyAhPT0gJ3VuZGVmaW5lZCcgJiYgdHlwZW9mIF9jb25maWcuY2hlY2tib3ggIT09ICd1bmRlZmluZWQnKSA/IF9jb25maWcuY2hlY2tib3ggOiBmYWxzZTtcclxuICAgICAgICB1cGRhdGVSZXN1bHQucmFkaW8gPSAodHlwZW9mIF9jb25maWcgIT09ICd1bmRlZmluZWQnICYmIHR5cGVvZiBfY29uZmlnLnJhZGlvICE9PSAndW5kZWZpbmVkJykgPyBfY29uZmlnLnJhZGlvIDogZmFsc2U7XHJcbiAgICAgICAgdXBkYXRlUmVzdWx0LmV4dGVybmFsRmlsdGVyID0gKHR5cGVvZiBfY29uZmlnICE9PSAndW5kZWZpbmVkJyAmJiB0eXBlb2YgX2NvbmZpZy5leHRlcm5hbEZpbHRlciAhPT0gJ3VuZGVmaW5lZCcpID8gX2NvbmZpZy5leHRlcm5hbEZpbHRlciA6IGZhbHNlO1xyXG4gICAgICAgIHVwZGF0ZVJlc3VsdC5sb2FkVHlwZSA9IHRoaXMuX2NoZWNrTG9hZFR5cGUoX2NvbmZpZyk7XHJcbiAgICAgICAgdXBkYXRlUmVzdWx0LnBhZ2luYXRpb25UeXBlID0gdGhpcy5fY2hlY2tQYWdpbmF0aW9uVHlwZSh1cGRhdGVSZXN1bHQubG9hZFR5cGUpO1xyXG4gICAgICAgIHVwZGF0ZVJlc3VsdC5wYWdlc2l6ZSA9IHRoaXMuX2NoZWNrUGFnZXNpemUoX2NvbmZpZywgdXBkYXRlUmVzdWx0LmxvYWRUeXBlKTtcclxuICAgICAgICB1cGRhdGVSZXN1bHQudG90YWxEYXRhID0gKHR5cGVvZiBfY29uZmlnICE9PSAndW5kZWZpbmVkJyAmJiB0eXBlb2YgX2NvbmZpZy50b3RhbERhdGEgIT09ICd1bmRlZmluZWQnKSA/IF9jb25maWcudG90YWxEYXRhIDogLTE7XHJcbiAgICAgICAgdXBkYXRlUmVzdWx0LmJ1dHRvbiA9ICh0eXBlb2YgX2NvbmZpZyAhPT0gJ3VuZGVmaW5lZCcgJiYgdHlwZW9mIF9jb25maWcuYnV0dG9uICE9PSAndW5kZWZpbmVkJykgPyBfY29uZmlnLmJ1dHRvbiA6IGZhbHNlO1xyXG4gICAgICAgIHVwZGF0ZVJlc3VsdC5idXR0b25Db25maWcgPSAodHlwZW9mIF9jb25maWcgIT09ICd1bmRlZmluZWQnICYmIHR5cGVvZiBfY29uZmlnLmJ1dHRvbkNvbmZpZyAhPT0gJ3VuZGVmaW5lZCcpID8gdGhpcy5fY2hlY2tCdG5Db25maWcoX2NvbmZpZy5idXR0b25Db25maWcpIDogbnVsbDtcclxuICAgICAgICB1cGRhdGVSZXN1bHQuYWxpZ25tZW50ID0gKHR5cGVvZiBfY29uZmlnICE9PSAndW5kZWZpbmVkJyAmJiB0eXBlb2YgX2NvbmZpZy5hbGlnbm1lbnQgIT09ICd1bmRlZmluZWQnKSA/IF9jb25maWcuYWxpZ25tZW50IDogJ21pZGRsZSc7XHJcbiAgICAgICAgdXBkYXRlUmVzdWx0LnN1cHByZXNzSGVpZ2h0UmVzaXplID0gKHR5cGVvZiBfY29uZmlnICE9PSAndW5kZWZpbmVkJyAmJiB0eXBlb2YgX2NvbmZpZy5zdXBwcmVzc0hlaWdodFJlc2l6ZSAhPT0gJ3VuZGVmaW5lZCcpID8gX2NvbmZpZy5zdXBwcmVzc0hlaWdodFJlc2l6ZSA6IHRydWU7XHJcbiAgICAgICAgdXBkYXRlUmVzdWx0LnJvd0NsaWNrYWJsZSA9ICh0eXBlb2YgX2NvbmZpZyAhPT0gJ3VuZGVmaW5lZCcgJiYgdHlwZW9mIF9jb25maWcucm93Q2xpY2thYmxlICE9PSAndW5kZWZpbmVkJykgPyBfY29uZmlnLnJvd0NsaWNrYWJsZSA6IGZhbHNlO1xyXG4gICAgICAgIHVwZGF0ZVJlc3VsdC5yb3dNYXBBY3Rpb25UeXBlID0gKHR5cGVvZiBfY29uZmlnICE9PSAndW5kZWZpbmVkJyAmJiB0eXBlb2YgX2NvbmZpZy5yb3dNYXBBY3Rpb25UeXBlICE9PSAndW5kZWZpbmVkJykgPyBfY29uZmlnLnJvd01hcEFjdGlvblR5cGUgOiBudWxsO1xyXG5cclxuICAgICAgICBpZiAodXBkYXRlUmVzdWx0LnJhZGlvICYmIHVwZGF0ZVJlc3VsdC5jaGVja2JveCkgdXBkYXRlUmVzdWx0LnJhZGlvID0gZmFsc2U7XHJcbiAgICAgICAgcmV0dXJuIHVwZGF0ZVJlc3VsdDtcclxuICAgIH1cclxuXHJcbiAgICBzZXRSb3dSZXN1bHQoX3Jvd0RhdGE6IEFycmF5PGFueT4pOiBBcnJheTxhbnk+IHtcclxuICAgICAgICBsZXQgdGFibGVEYXRhOiBBcnJheTxhbnk+ID0gKHR5cGVvZiBfcm93RGF0YSAhPT0gJ3VuZGVmaW5lZCcpID8gX3Jvd0RhdGEgOiBbXTtcclxuICAgICAgICByZXR1cm4gdGFibGVEYXRhO1xyXG4gICAgfVxyXG5cclxuICAgIHNldENvbERlZnMoX2NvbERlZjogYW55LCBfZ3JpZE9wdGlvbnM6IEdyaWRPcHRpb25zLCAvKl9kYXRhU3ZjOiBLZERhdGFTdmMsICovX3JvdXRlcj86IFJvdXRlciwgX2lzUmVjdXJzaXZlOiBib29sZWFuID0gZmFsc2UpOiBhbnkge1xyXG4gICAgICAgIGxldCBjb2xEZWZDb25maWc6IGFueSA9IHsgZWRpdE1vZGU6IGZhbHNlLCB1cGRhdGVkQ29sRGVmOiBbXSB9O1xyXG4gICAgICAgIGxldCB0YWJsZUNvbHVtbjogYW55ID0ge307XHJcblxyXG4gICAgICAgIGZvciAobGV0IGtleSBpbiBfY29sRGVmKSB7XHJcbiAgICAgICAgICAgIGlmIChfY29sRGVmLmhhc093blByb3BlcnR5KGtleSkpIHtcclxuICAgICAgICAgICAgICAgIHRoaXMuX3Jlc2l6ZWFibGVDb2wrKztcclxuXHJcbiAgICAgICAgICAgICAgICB0YWJsZUNvbHVtbiA9IHtcclxuICAgICAgICAgICAgICAgICAgICBoZWFkZXJOYW1lOiBfY29sRGVmW2tleV0uaGVhZGVyTmFtZSxcclxuICAgICAgICAgICAgICAgICAgICBmaWVsZDogKHR5cGVvZiBfY29sRGVmW2tleV0uY29uZmlnICE9PSAndW5kZWZpbmVkJyAmJiB0eXBlb2YgX2NvbERlZltrZXldLmNvbmZpZy5tYXAgIT09ICd1bmRlZmluZWQnKSA/IF9jb2xEZWZba2V5XS5jb25maWcubWFwIDoga2V5LFxyXG4gICAgICAgICAgICAgICAgICAgIGVkaXRhYmxlOiBmYWxzZSwgLy8gKHR5cGVvZiBfY29sRGVmW2tleV0uZWRpdGFibGUgIT09ICd1bmRlZmluZWQnKSA/IF9jb2xEZWZba2V5XS5lZGl0YWJsZSA6IGZhbHNlLFxyXG4gICAgICAgICAgICAgICAgICAgIHN1cHByZXNzTWVudTogKHR5cGVvZiBfY29sRGVmW2tleV0uZmlsdGVyYWJsZSAhPT0gJ3VuZGVmaW5lZCcpID8gIV9jb2xEZWZba2V5XS5maWx0ZXJhYmxlIDogdHJ1ZSxcclxuICAgICAgICAgICAgICAgICAgICBzdXBwcmVzc1NvcnRpbmc6ICh0eXBlb2YgX2NvbERlZltrZXldLnNvcnRhYmxlICE9PSAndW5kZWZpbmVkJykgPyAhX2NvbERlZltrZXldLnNvcnRhYmxlIDogdHJ1ZSxcclxuICAgICAgICAgICAgICAgICAgICBjb2xJZDoga2V5LFxyXG4gICAgICAgICAgICAgICAgICAgIGNvbmZpZzogKHR5cGVvZiBfY29sRGVmW2tleV0uY29uZmlnICE9PSAndW5kZWZpbmVkJykgPyBfY29sRGVmW2tleV0uY29uZmlnIDogdW5kZWZpbmVkLFxyXG4gICAgICAgICAgICAgICAgICAgIC8vIGNlbGxSZW5kZXJlcjogKF9wYXJhbXM6IGFueSk6IGFueSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgLy8gICAgIGlmICh0eXBlb2YgX3BhcmFtcy52YWx1ZSA9PT0gJ251bWJlcicpIHtcclxuICAgICAgICAgICAgICAgICAgICAvLyAgICAgICAgIHJldHVybiBfcGFyYW1zLnZhbHVlLnRvU3RyaW5nKCk7XHJcbiAgICAgICAgICAgICAgICAgICAgLy8gICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAvLyAgICAgZWxzZSBpZiAoX3BhcmFtcy52YWx1ZSBpbnN0YW5jZW9mIEFycmF5KSB7XHJcbiAgICAgICAgICAgICAgICAgICAgLy8gICAgICAgICBKU09OLnN0cmluZ2lmeShfcGFyYW1zLnZhbHVlKTtcclxuICAgICAgICAgICAgICAgICAgICAvLyAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIC8vICAgICByZXR1cm4gX3BhcmFtcy52YWx1ZTtcclxuICAgICAgICAgICAgICAgICAgICAvLyB9LFxyXG4gICAgICAgICAgICAgICAgICAgIGhpZGU6ICh0eXBlb2YgX2NvbERlZltrZXldLnZpc2libGUgIT09ICd1bmRlZmluZWQnKSA/ICEoX2NvbERlZltrZXldLnZpc2libGUpIDogZmFsc2UsXHJcbiAgICAgICAgICAgICAgICAgICAgY2VsbENsYXNzOiAnYWctZGVmYXVsdCdcclxuICAgICAgICAgICAgICAgIH07XHJcblxyXG4gICAgICAgICAgICAgICAgaWYgKCF0YWJsZUNvbHVtbi5zdXBwcmVzc01lbnUpIHtcclxuICAgICAgICAgICAgICAgICAgICB0YWJsZUNvbHVtblsnbWVudVRhYnMnXSA9IFsnZmlsdGVyTWVudVRhYiddO1xyXG4gICAgICAgICAgICAgICAgICAgIHRhYmxlQ29sdW1uLmZpbHRlclBhcmFtcyA9IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgbmV3Um93c0FjdGlvbjogJ2tlZXAnLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBjZWxsSGVpZ2h0OiAzMCxcclxuICAgICAgICAgICAgICAgICAgICAgICAgc2VsZWN0QWxsT25NaW5pRmlsdGVyOiB0cnVlLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZXM6ICh0eXBlb2YgX2NvbERlZltrZXldLmZpbHRlclZhbCAhPT0gJ3VuZGVmaW5lZCcgJiYgX2NvbERlZltrZXldLmZpbHRlclZhbC5sZW5ndGggPiAwKSA/IF9jb2xEZWZba2V5XS5maWx0ZXJWYWwgOiB1bmRlZmluZWRcclxuICAgICAgICAgICAgICAgICAgICB9O1xyXG4gICAgICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgICAgIGlmICh0eXBlb2YgX2NvbERlZltrZXldLmNvbmZpZyAhPT0gJ3VuZGVmaW5lZCcpIHtcclxuICAgICAgICAgICAgICAgICAgICBpZiAodHlwZW9mIF9jb2xEZWZba2V5XS5jb25maWcuaW5wdXQgIT09ICd1bmRlZmluZWQnICYmIF9jb2xEZWZba2V5XS5jb25maWcuaW5wdXQpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgY29sRGVmQ29uZmlnLmVkaXRNb2RlID0gdHJ1ZTtcclxuICAgICAgICAgICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIHRhYmxlQ29sdW1uID0gdGhpcy5fc2V0Q29sdW1uQ29uZmlnKHRhYmxlQ29sdW1uLCBfY29sRGVmW2tleV0uY29uZmlnLCAvKl9kYXRhU3ZjLCovIF9yb3V0ZXIpO1xyXG5cclxuICAgICAgICAgICAgICAgICAgICBpZiAodGFibGVDb2x1bW4uaGFzT3duUHJvcGVydHkoJ2NlbGxSZW5kZXJlckZyYW1ld29yaycpKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGRlbGV0ZSB0YWJsZUNvbHVtbi5jZWxsUmVuZGVyZXI7XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgICAgIGlmICh0eXBlb2YgdGFibGVDb2x1bW4uY29uZmlnICE9PSAndW5kZWZpbmVkJyAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgKHR5cGVvZiB0YWJsZUNvbHVtbi5jb25maWcuY2hlY2tib3ggIT09ICd1bmRlZmluZWQnICYmIHRhYmxlQ29sdW1uLmNvbmZpZy5jaGVja2JveCkgfHxcclxuICAgICAgICAgICAgICAgICAgICAodHlwZW9mIHRhYmxlQ29sdW1uLmNvbmZpZy5yYWRpbyAhPT0gJ3VuZGVmaW5lZCcgJiYgdGFibGVDb2x1bW4uY29uZmlnLnJhZGlvKSkpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgY29sRGVmQ29uZmlnLnVwZGF0ZWRDb2xEZWYudW5zaGlmdCh0YWJsZUNvbHVtbik7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgICAgICAgICBjb2xEZWZDb25maWcudXBkYXRlZENvbERlZi5wdXNoKHRhYmxlQ29sdW1uKTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgcmV0dXJuIGNvbERlZkNvbmZpZztcclxuICAgIH1cclxuXHJcbiAgICBzZXRGaWx0ZXJBbmRTb3J0T3B0aW9ucyhwYXJhbXM6IGFueSk6IEdyaWRPcHRpb25zIHtcclxuICAgICAgICBsZXQgdXBkYXRlZE9wdGlvbnMgPSBwYXJhbXMuZ3JpZE9wdGlvbnM7XHJcblxyXG4gICAgICAgIGlmIChwYXJhbXMubG9hZFR5cGUgPT09ICdzZXJ2ZXItcGFnaW5hdGlvbicgfHwgcGFyYW1zLmxvYWRUeXBlID09PSAnb25lc2hvdC1wYWdpbmF0aW9uJykge1xyXG4gICAgICAgICAgICB1cGRhdGVkT3B0aW9ucy5lbmFibGVTZXJ2ZXJTaWRlRmlsdGVyID0gdHJ1ZTtcclxuICAgICAgICAgICAgdXBkYXRlZE9wdGlvbnMuZW5hYmxlU2VydmVyU2lkZVNvcnRpbmcgPSB0cnVlO1xyXG4gICAgICAgICAgICB1cGRhdGVkT3B0aW9ucy5wYWdpbmF0aW9uUGFnZVNpemUgPSBwYXJhbXMucGFnZXNpemU7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGVsc2UgaWYgKHBhcmFtcy5sb2FkVHlwZSA9PT0gJ3ZpcnR1YWwnKSB7XHJcbiAgICAgICAgICAgIHVwZGF0ZWRPcHRpb25zLmVuYWJsZVNlcnZlclNpZGVGaWx0ZXIgPSB0cnVlO1xyXG4gICAgICAgICAgICB1cGRhdGVkT3B0aW9ucy5lbmFibGVTZXJ2ZXJTaWRlU29ydGluZyA9IHRydWU7XHJcbiAgICAgICAgICAgIHVwZGF0ZWRPcHRpb25zLnBhZ2luYXRpb25QYWdlU2l6ZSA9IHBhcmFtcy5wYWdlc2l6ZTtcclxuICAgICAgICAgICAgdXBkYXRlZE9wdGlvbnMubWF4UGFnZXNJbkNhY2hlID0gMztcclxuICAgICAgICAgICAgdXBkYXRlZE9wdGlvbnMubWF4Q29uY3VycmVudERhdGFzb3VyY2VSZXF1ZXN0cyA9IDI7XHJcbiAgICAgICAgICAgIHVwZGF0ZWRPcHRpb25zLm92ZXJmbG93U2l6ZSA9IDMwO1xyXG4gICAgICAgIH1cclxuICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgdXBkYXRlZE9wdGlvbnMuZW5hYmxlRmlsdGVyID0gdHJ1ZTtcclxuICAgICAgICAgICAgdXBkYXRlZE9wdGlvbnMuZW5hYmxlU29ydGluZyA9IHRydWU7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICBpZiAocGFyYW1zLmxvYWRUeXBlID09PSAnc2VydmVyLXBhZ2luYXRpb24nIHx8IHBhcmFtcy5sb2FkVHlwZSA9PT0gJ29uZXNob3QtcGFnaW5hdGlvbicpIHtcclxuICAgICAgICAgICAgdXBkYXRlZE9wdGlvbnMucGFnaW5hdGlvbiA9IHRydWU7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICB1cGRhdGVkT3B0aW9ucy5yb3dNb2RlbFR5cGUgPSBwYXJhbXMucGFnaW5hdGlvblR5cGU7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICByZXR1cm4gdXBkYXRlZE9wdGlvbnM7XHJcbiAgICB9XHJcblxyXG4gICAgY2FsY0NvbFdpZHRoKF9ncmlkT3B0aW9uczogR3JpZE9wdGlvbnMpOiBBcnJheTx7d2lkdGg6IG51bWJlciwgaWQ6IHN0cmluZ30+IHtcclxuICAgICAgICBsZXQgY29sdW1uczogQXJyYXk8Q29sdW1uPiA9IF9ncmlkT3B0aW9ucy5jb2x1bW5BcGkuZ2V0QWxsQ29sdW1ucygpO1xyXG4gICAgICAgIGxldCB1cGRhdGVkV2lkdGg6IEFycmF5PHt3aWR0aDogbnVtYmVyLCBpZDogc3RyaW5nfT4gPSBbXTtcclxuXHJcbiAgICAgICAgZm9yIChsZXQgaTogbnVtYmVyID0gMDsgaSA8IGNvbHVtbnMubGVuZ3RoOyBpKyspIHtcclxuICAgICAgICAgICAgbGV0IGNvbHVtbkRlZjogYW55ID0gY29sdW1uc1tpXS5nZXRDb2xEZWYoKTtcclxuICAgICAgICAgICAgbGV0IGNvbFdpZHRoOiBudW1iZXIgPSAtMTtcclxuXHJcbiAgICAgICAgICAgIGlmIChjb2x1bW5EZWYuY2VsbENsYXNzLmluZGV4T2YoJ2FnLWNoZWNrYm94LXJhZGlvJykgIT09IC0xKSB7XHJcbiAgICAgICAgICAgICAgICBjb2xXaWR0aCA9IDUwO1xyXG4gICAgICAgICAgICAgICAgX2dyaWRPcHRpb25zLmNvbHVtbkFwaS5zZXRDb2x1bW5XaWR0aChjb2x1bW5zW2ldLCBjb2xXaWR0aCk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgZWxzZSBpZiAodHlwZW9mIGNvbHVtbkRlZi5jb25maWcgIT09ICd1bmRlZmluZWQnICYmIHR5cGVvZiBjb2x1bW5EZWYuY29uZmlnLmFjdGlvbiAhPT0gJ3VuZGVmaW5lZCcgJiYgY29sdW1uRGVmLmNvbmZpZy5hY3Rpb24pIHtcclxuICAgICAgICAgICAgICAgIGNvbFdpZHRoID0gMTIwO1xyXG4gICAgICAgICAgICAgICAgX2dyaWRPcHRpb25zLmNvbHVtbkFwaS5zZXRDb2x1bW5XaWR0aChjb2x1bW5zW2ldLCBjb2xXaWR0aCk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgZWxzZSBpZiAodHlwZW9mIGNvbHVtbkRlZi5jb25maWcgIT09ICd1bmRlZmluZWQnICYmIHR5cGVvZiBjb2x1bW5EZWYuY29uZmlnLnBob3RvICE9PSAndW5kZWZpbmVkJyAmJiBjb2x1bW5EZWYuY29uZmlnLnBob3RvKSB7XHJcbiAgICAgICAgICAgICAgICBjb2xXaWR0aCA9IDEwMDtcclxuICAgICAgICAgICAgICAgIF9ncmlkT3B0aW9ucy5jb2x1bW5BcGkuc2V0Q29sdW1uV2lkdGgoY29sdW1uc1tpXSwgY29sV2lkdGgpO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIGVsc2UgaWYgKHR5cGVvZiBjb2x1bW5EZWYuY29uZmlnICE9PSAndW5kZWZpbmVkJyAmJiB0eXBlb2YgY29sdW1uRGVmLmNvbmZpZy5pbnB1dCAhPT0gJ3VuZGVmaW5lZCcgJiYgY29sdW1uRGVmLmNvbmZpZy5pbnB1dCkge1xyXG4gICAgICAgICAgICAgICAgY29sV2lkdGggPSAyODA7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgZWxzZSB7XHJcbiAgICAgICAgICAgICAgICBjb2xXaWR0aCA9IGNvbHVtbnNbaV0uZ2V0QWN0dWFsV2lkdGgoKSArIDMwO1xyXG4gICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICB1cGRhdGVkV2lkdGgucHVzaCh7d2lkdGg6IGNvbFdpZHRoLCBpZDogY29sdW1uRGVmLmNvbElkfSk7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICByZXR1cm4gdXBkYXRlZFdpZHRoO1xyXG4gICAgfVxyXG5cclxuICAgIGNvbFRvdGFsV2lkdGgoX2NvbEFycmF5OiBBcnJheTx7d2lkdGg6IG51bWJlciwgaWQ6IHN0cmluZ30+LCBjb2x1bW46IEFycmF5PENvbHVtbj4pOiBudW1iZXIge1xyXG4gICAgICAgIGxldCB0b3RhbDogbnVtYmVyID0gMDtcclxuICAgICAgICBmb3IgKGxldCBpOiBudW1iZXIgPSAwOyBpIDwgX2NvbEFycmF5Lmxlbmd0aDsgaSsrKSB7XHJcbiAgICAgICAgICAgIGlmIChjb2x1bW5baV0uaXNWaXNpYmxlKCkpIHtcclxuICAgICAgICAgICAgICAgIHRvdGFsICs9IF9jb2xBcnJheVtpXS53aWR0aDtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgcmV0dXJuIHRvdGFsO1xyXG4gICAgfVxyXG5cclxuICAgIGNhbGNVc2FibGVXaWR0aChfdmNyOiBWaWV3Q29udGFpbmVyUmVmKTogbnVtYmVyIHtcclxuICAgICAgICBsZXQgYWdHcmlkRWxlOiBIVE1MRWxlbWVudCA9IF92Y3IuZWxlbWVudC5uYXRpdmVFbGVtZW50LnF1ZXJ5U2VsZWN0b3IoJy5zdGctdGhlbWUnKTtcclxuICAgICAgICBsZXQgcGFyZW50V2lkdGg6IG51bWJlciA9IE1hdGgucm91bmQoYWdHcmlkRWxlLmdldEJvdW5kaW5nQ2xpZW50UmVjdCgpLndpZHRoKTtcclxuICAgICAgICBsZXQgY29tcHV0ZWRTdHlsZTogQ1NTU3R5bGVEZWNsYXJhdGlvbiA9IHdpbmRvdy5nZXRDb21wdXRlZFN0eWxlKGFnR3JpZEVsZSk7XHJcbiAgICAgICAgbGV0IGJvcmRlckxlZnQ6IG51bWJlciA9IChjb21wdXRlZFN0eWxlLmJvcmRlckxlZnQgIT09ICcnKSA/IHBhcnNlSW50KGNvbXB1dGVkU3R5bGUuYm9yZGVyTGVmdCkgOiAwO1xyXG4gICAgICAgIGxldCBib3JkZXJSaWdodDogbnVtYmVyID0gKGNvbXB1dGVkU3R5bGUuYm9yZGVyUmlnaHQgIT09ICcnKSA/IHBhcnNlSW50KGNvbXB1dGVkU3R5bGUuYm9yZGVyUmlnaHQpIDogMDtcclxuICAgICAgICBsZXQgYm9yZGVyTGVmdFJpZ2h0ID0gYm9yZGVyTGVmdCArIGJvcmRlclJpZ2h0O1xyXG4gICAgICAgIHJldHVybiBwYXJlbnRXaWR0aCAtIGJvcmRlckxlZnRSaWdodDtcclxuICAgIH1cclxuXHJcbiAgICBjYWxjUmVzaXplYWJsZUNvbChfY29sdW1uczogQXJyYXk8Q29sdW1uPik6IG51bWJlciB7XHJcbiAgICAgICAgbGV0IHJlc2l6ZWFibGVDb2w6IG51bWJlciA9IHRoaXMuX3Jlc2l6ZWFibGVDb2w7XHJcblxyXG4gICAgICAgIGZvciAobGV0IGk6IG51bWJlciA9IDA7IGkgPCBfY29sdW1ucy5sZW5ndGg7IGkrKykge1xyXG4gICAgICAgICAgICBsZXQgY29sRGVmOiBhbnkgPSBfY29sdW1uc1tpXS5nZXRDb2xEZWYoKTtcclxuXHJcbiAgICAgICAgICAgIGlmICh0eXBlb2YgY29sRGVmLmNvbmZpZyA9PT0gJ3VuZGVmaW5lZCcgJiYgIV9jb2x1bW5zW2ldLmlzVmlzaWJsZSgpKSB7XHJcbiAgICAgICAgICAgICAgICAtLXJlc2l6ZWFibGVDb2w7XHJcbiAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgIC8vIG1vcmUgY2hlY2tzIHRvIGltcGxlbWVudFxyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgcmV0dXJuIHJlc2l6ZWFibGVDb2w7XHJcbiAgICB9XHJcblxyXG4gICAgY2FsY0dyaWRIZWlnaHRXZWIoX2dyaWRIZWlnaHQ6IGFueSwgX21vZGVsOiBJUm93TW9kZWwsIF92Y3I6IFZpZXdDb250YWluZXJSZWYpOiBudW1iZXIge1xyXG4gICAgICAgIGxldCBhY3R1YWxIZWlnaHQ6IG51bWJlciA9IDM4ICsgODtcclxuICAgICAgICBsZXQgaWRTb3V0aDogRWxlbWVudCA9IF92Y3IuZWxlbWVudC5uYXRpdmVFbGVtZW50LnF1ZXJ5U2VsZWN0b3IoJyNzb3V0aCcpO1xyXG5cclxuICAgICAgICBpZiAoaWRTb3V0aCAhPT0gbnVsbCkge1xyXG4gICAgICAgICAgICBhY3R1YWxIZWlnaHQgKz0gaWRTb3V0aC5nZXRCb3VuZGluZ0NsaWVudFJlY3QoKS5oZWlnaHQ7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICBmb3IgKGxldCBpOiBudW1iZXIgPSAwOyBpIDwgX21vZGVsLmdldFJvd0NvdW50KCk7IGkrKykge1xyXG4gICAgICAgICAgICBhY3R1YWxIZWlnaHQgKz0gX21vZGVsLmdldFJvdyhpKS5yb3dIZWlnaHQ7XHJcbiAgICAgICAgICAgIGlmIChhY3R1YWxIZWlnaHQgPiBfZ3JpZEhlaWdodCkge1xyXG4gICAgICAgICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIGlmIChhY3R1YWxIZWlnaHQgPCBfZ3JpZEhlaWdodCkge1xyXG4gICAgICAgICAgICByZXR1cm4gYWN0dWFsSGVpZ2h0O1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgcmV0dXJuIF9ncmlkSGVpZ2h0O1xyXG4gICAgfVxyXG5cclxuICAgIGNhbGNHcmlkSGVpZ2h0TW9iaWxlKF92Y3I6IFZpZXdDb250YWluZXJSZWYpOiBudW1iZXIge1xyXG4gICAgICAgIGxldCB0b3RhbEhlaWdodDogbnVtYmVyID0gMDtcclxuICAgICAgICBsZXQgbmF0aXZlRWxlOiBFbGVtZW50ID0gX3Zjci5lbGVtZW50Lm5hdGl2ZUVsZW1lbnQ7XHJcbiAgICAgICAgbGV0IGhlYWRlckNvbnRhaW5lcjogRWxlbWVudCA9IG5hdGl2ZUVsZS5xdWVyeVNlbGVjdG9yKCcuYWctaGVhZGVyLWNvbnRhaW5lcicpO1xyXG4gICAgICAgIGlmIChuYXRpdmVFbGUgPT09IG51bGwgfHwgaGVhZGVyQ29udGFpbmVyID09PSBudWxsKSByZXR1cm4gdG90YWxIZWlnaHQ7XHJcbiAgICAgICAgdG90YWxIZWlnaHQgKz0gTWF0aC5jZWlsKGhlYWRlckNvbnRhaW5lci5nZXRCb3VuZGluZ0NsaWVudFJlY3QoKS5oZWlnaHQpO1xyXG4gICAgICAgIHRvdGFsSGVpZ2h0ICs9IE1hdGguY2VpbChuYXRpdmVFbGUucXVlcnlTZWxlY3RvcignLmFnLWJvZHktY29udGFpbmVyJykuZ2V0Qm91bmRpbmdDbGllbnRSZWN0KCkuaGVpZ2h0KTtcclxuXHJcbiAgICAgICAgbGV0IHBhZ2luYXRpb25Cb3R0b206IEVsZW1lbnQgPSBuYXRpdmVFbGUucXVlcnlTZWxlY3RvcignI3NvdXRoJyk7XHJcbiAgICAgICAgaWYgKHBhZ2luYXRpb25Cb3R0b20gIT09IG51bGwpIHtcclxuICAgICAgICAgICAgdG90YWxIZWlnaHQgKz0gTWF0aC5jZWlsKHBhZ2luYXRpb25Cb3R0b20uZ2V0Qm91bmRpbmdDbGllbnRSZWN0KCkuaGVpZ2h0KTtcclxuICAgICAgICB9XHJcbiAgICAgICAgdG90YWxIZWlnaHQgKz0gODtcclxuICAgICAgICByZXR1cm4gdG90YWxIZWlnaHQ7XHJcbiAgICB9XHJcblxyXG4gICAgc2VydmVyU29ydEFuZEZpbHRlcihfZGF0YTogQXJyYXk8YW55PiwgX3NvcnRNb2RlbDogQXJyYXk8YW55PiwgX2ZpbHRlck1vZGVsOiBhbnkpIHtcclxuICAgICAgICByZXR1cm4gdGhpcy5fc2VydmVyU29ydERhdGEoX3NvcnRNb2RlbCwgdGhpcy5fc2VydmVyRmlsdGVyRGF0YShfZmlsdGVyTW9kZWwsIF9kYXRhKSk7XHJcbiAgICB9XHJcblxyXG4gICAgY2hlY2tDb2x1bW5EZWYoX2NvbERlZjogYW55LCBfaGFzQ2hlY2tib3g6IGJvb2xlYW4sIF9oYXNSYWRpbzogYm9vbGVhbik6IGFueSB7XHJcbiAgICAgICAgaWYgKF9oYXNDaGVja2JveCkge1xyXG4gICAgICAgICAgICBfY29sRGVmWydhZy1jaGVja2JveCddID0ge1xyXG4gICAgICAgICAgICAgICAgY29uZmlnOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgY2hlY2tib3g6IHRydWVcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfTtcclxuICAgICAgICB9XHJcbiAgICAgICAgZWxzZSBpZiAoX2hhc1JhZGlvKSB7XHJcbiAgICAgICAgICAgIF9jb2xEZWZbJ2FnLXJhZGlvJ10gPSB7XHJcbiAgICAgICAgICAgICAgICBjb25maWc6IHtcclxuICAgICAgICAgICAgICAgICAgICByYWRpbzogdHJ1ZVxyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9O1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgcmV0dXJuIF9jb2xEZWY7XHJcbiAgICB9XHJcblxyXG4gICAgZ2V0QWN0aW9uTGlzdChfcm93RGF0YTogYW55LCBfY29sdW1uOiBBcnJheTxDb2x1bW4+KTogQXJyYXk8YW55PiB7XHJcbiAgICAgICAgaWYgKHR5cGVvZiBfcm93RGF0YS5hY3Rpb24gIT09ICd1bmRlZmluZWQnKSB7XHJcbiAgICAgICAgICAgIHJldHVybiBfcm93RGF0YS5hY3Rpb247XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICBmb3IgKGxldCBpOiBudW1iZXIgPSAwOyBpIDwgX2NvbHVtbi5sZW5ndGg7IGkrKykge1xyXG4gICAgICAgICAgICBsZXQgY29sRGVmOiBhbnkgPSBfY29sdW1uW2ldLmdldENvbERlZigpO1xyXG4gICAgICAgICAgICBpZiAodHlwZW9mIGNvbERlZi5jb25maWcgIT09ICd1bmRlZmluZWQnICYmXHJcbiAgICAgICAgICAgICAgICB0eXBlb2YgY29sRGVmLmNvbmZpZy5hY3Rpb24gIT09ICd1bmRlZmluZWQnICYmXHJcbiAgICAgICAgICAgICAgICBjb2xEZWYuY29uZmlnLmFjdGlvbikge1xyXG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBjb2xEZWYuY29uZmlnLml0ZW1zO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgICAgIHJldHVybiBbXTtcclxuICAgIH1cclxuXHJcbiAgICBjaGVja0lzVGFyZ2V0Q2xpY2thYmxlKF9yb3dFdmVudDogRXZlbnQpOiBib29sZWFuIHtcclxuICAgICAgICBsZXQgZWxlbWVudDogSFRNTEVsZW1lbnQgPSA8SFRNTEVsZW1lbnQ+X3Jvd0V2ZW50LnRhcmdldDtcclxuICAgICAgICBsZXQgY2hlY2tMaXN0OiBBcnJheTxzdHJpbmc+ID0gWydhY3Rpb24tYnRuJywgJ2NoZWNrYm94LXJhZGlvLWlucHV0JywgJ2ZhLWNoZXZyb24tZG93biddO1xyXG5cclxuICAgICAgICBmb3IgKGxldCBpOiBudW1iZXIgPSAwOyBpIDwgY2hlY2tMaXN0Lmxlbmd0aDsgaSsrKSB7XHJcbiAgICAgICAgICAgIGlmIChlbGVtZW50LmNsYXNzTGlzdC5jb250YWlucyhjaGVja0xpc3RbaV0pKSB7XHJcbiAgICAgICAgICAgICAgICByZXR1cm4gZmFsc2U7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIHJldHVybiB0cnVlO1xyXG4gICAgfVxyXG5cclxuICAgIGNoZWNrSXNDb25maWdDb2x1bW4oX2NvbERlZjogYW55KTogYm9vbGVhbiB7XHJcbiAgICAgICAgaWYgKF9jb2xEZWYuY2VsbENsYXNzLmluZGV4T2YoJ2FnLWNoZWNrYm94LXJhZGlvJykgIT09IC0xKSB7XHJcbiAgICAgICAgICAgIHJldHVybiB0cnVlO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgaWYgKHR5cGVvZiBfY29sRGVmLmNvbmZpZyAhPT0gJ3VuZGVmaW5lZCcgJiZcclxuICAgICAgICAgICAgKCh0eXBlb2YgX2NvbERlZi5jb25maWcucGhvdG8gIT09ICd1bmRlZmluZWQnICYmIF9jb2xEZWYuY29uZmlnLnBob3RvKSB8fFxyXG4gICAgICAgICAgICAgKHR5cGVvZiBfY29sRGVmLmNvbmZpZy5hY3Rpb24gIT09ICd1bmRlZmluZWQnICYmIF9jb2xEZWYuY29uZmlnLmFjdGlvbikpXHJcbiAgICAgICAgKSB7XHJcbiAgICAgICAgICAgIHJldHVybiB0cnVlO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgcmV0dXJuIGZhbHNlO1xyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX3NldENvbHVtbkNvbmZpZyhfY29sdW1uOiBhbnksIF9jb25maWc6IGFueSwgLypfZGF0YVN2YzogS2REYXRhU3ZjLCovIF9yb3V0ZXI/OiBSb3V0ZXIpOiBhbnkge1xyXG4gICAgICAgIGxldCB1cGRhdGVkQ29sdW1uOiBhbnkgPSAoPGFueT5PYmplY3QpLmFzc2lnbih7fSwgX2NvbHVtbik7XHJcblxyXG4gICAgICAgIC8vIGlmICh0eXBlb2YgX2NvbmZpZy5pbnB1dCAhPT0gJ3VuZGVmaW5lZCcgJiYgX2NvbmZpZy5pbnB1dCkge1xyXG4gICAgICAgIC8vICAgICB1cGRhdGVkQ29sdW1uLnN1cHByZXNzTWVudSA9IHRydWU7XHJcbiAgICAgICAgLy8gICAgIHVwZGF0ZWRDb2x1bW4uc3VwcHJlc3NTb3J0aW5nID0gdHJ1ZTtcclxuICAgICAgICAvLyAgICAgdXBkYXRlZENvbHVtbi5jZWxsQ2xhc3MgPSAnYWctZm9ybSc7XHJcbiAgICAgICAgLy8gICAgIHVwZGF0ZWRDb2x1bW4uY2VsbFJlbmRlcmVyRnJhbWV3b3JrID0gS2RBR0Zvcm07XHJcbiAgICAgICAgLy8gfVxyXG5cclxuICAgICAgICAvLyBlbHNlIGlmICh0eXBlb2YgX2NvbmZpZy5hY3Rpb24gIT09ICd1bmRlZmluZWQnICYmIF9jb25maWcuYWN0aW9uKSB7XHJcbiAgICAgICAgLy8gICAgIHVwZGF0ZWRDb2x1bW4uc3VwcHJlc3NNZW51ID0gdHJ1ZTtcclxuICAgICAgICAvLyAgICAgdXBkYXRlZENvbHVtbi5zdXBwcmVzc1NvcnRpbmcgPSB0cnVlO1xyXG4gICAgICAgIC8vICAgICB1cGRhdGVkQ29sdW1uLnN1cHByZXNzU2l6ZVRvRml0ID0gdHJ1ZTtcclxuICAgICAgICAvLyAgICAgdXBkYXRlZENvbHVtbi53aWR0aCA9IDEyMDtcclxuICAgICAgICAvLyAgICAgdXBkYXRlZENvbHVtbi5jZWxsQ2xhc3MgPSAnZHJvcGRvd24tYWN0aW9uJztcclxuICAgICAgICAvLyAgICAgdXBkYXRlZENvbHVtbi5jZWxsUmVuZGVyZXJGcmFtZXdvcmsgPSBLZEFHRHJvcGRvd247XHJcblxyXG4gICAgICAgIC8vICAgICB0aGlzLl9yZXNpemVhYmxlQ29sLS07XHJcbiAgICAgICAgLy8gfVxyXG5cclxuICAgICAgICAvLyBlbHNlIGlmICh0eXBlb2YgX2NvbmZpZy5waG90byAhPT0gJ3VuZGVmaW5lZCcgJiYgX2NvbmZpZy5waG90bykge1xyXG4gICAgICAgIC8vICAgICB1cGRhdGVkQ29sdW1uLnN1cHByZXNzTWVudSA9IHRydWU7XHJcbiAgICAgICAgLy8gICAgIHVwZGF0ZWRDb2x1bW4uc3VwcHJlc3NTb3J0aW5nID0gdHJ1ZTtcclxuICAgICAgICAvLyAgICAgdXBkYXRlZENvbHVtbi5zdXBwcmVzc1NpemVUb0ZpdCA9IHRydWU7XHJcbiAgICAgICAgLy8gICAgIHVwZGF0ZWRDb2x1bW4ud2lkdGggPSAxMDA7XHJcbiAgICAgICAgLy8gICAgIHVwZGF0ZWRDb2x1bW4uY2VsbENsYXNzID0gJ2FnLXBob3RvJztcclxuICAgICAgICAvLyAgICAgdXBkYXRlZENvbHVtbi5jZWxsUmVuZGVyZXJGcmFtZXdvcmsgPSBLZEFHUGhvdG87XHJcblxyXG4gICAgICAgIC8vICAgICB0aGlzLl9yZXNpemVhYmxlQ29sLS07XHJcbiAgICAgICAgLy8gfVxyXG5cclxuICAgICAgICAvLyBlbHNlIGlmICh0eXBlb2YgX2NvbmZpZy5jaGVja2JveCAhPT0gJ3VuZGVmaW5lZCcgJiYgX2NvbmZpZy5jaGVja2JveCkge1xyXG4gICAgICAgIC8vICAgICB1cGRhdGVkQ29sdW1uLnN1cHByZXNzTWVudSA9IHRydWU7XHJcbiAgICAgICAgLy8gICAgIHVwZGF0ZWRDb2x1bW4uc3VwcHJlc3NTb3J0aW5nID0gdHJ1ZTtcclxuICAgICAgICAvLyAgICAgdXBkYXRlZENvbHVtbi5zdXBwcmVzc1NpemVUb0ZpdCA9IHRydWU7XHJcbiAgICAgICAgLy8gICAgIHVwZGF0ZWRDb2x1bW4ud2lkdGggPSA1MDtcclxuICAgICAgICAvLyAgICAgdXBkYXRlZENvbHVtbi5jZWxsQ2xhc3MgPSAnYWctZGVmYXVsdCBhZy1jaGVja2JveC1yYWRpbyc7XHJcbiAgICAgICAgLy8gICAgIHVwZGF0ZWRDb2x1bW4uY29sSWQgPSAnY2hlY2tib3gnO1xyXG4gICAgICAgIC8vICAgICB1cGRhdGVkQ29sdW1uLmNlbGxSZW5kZXJlckZyYW1ld29yayA9IEtkQUdDaGVja2JveFJhZGlvO1xyXG4gICAgICAgIC8vICAgICB1cGRhdGVkQ29sdW1uLmhlYWRlckNvbXBvbmVudEZyYW1ld29yayA9IEtkQUdDaGVja2JveFJhZGlvO1xyXG5cclxuICAgICAgICAvLyAgICAgdGhpcy5fcmVzaXplYWJsZUNvbC0tO1xyXG4gICAgICAgIC8vIH1cclxuXHJcbiAgICAgICAgLy8gZWxzZSBpZiAodHlwZW9mIF9jb25maWcucmFkaW8gIT09ICd1bmRlZmluZWQnICYmIF9jb25maWcucmFkaW8pIHtcclxuICAgICAgICAvLyAgICAgdXBkYXRlZENvbHVtbi5zdXBwcmVzc01lbnUgPSB0cnVlO1xyXG4gICAgICAgIC8vICAgICB1cGRhdGVkQ29sdW1uLnN1cHByZXNzU29ydGluZyA9IHRydWU7XHJcbiAgICAgICAgLy8gICAgIHVwZGF0ZWRDb2x1bW4uc3VwcHJlc3NTaXplVG9GaXQgPSB0cnVlO1xyXG4gICAgICAgIC8vICAgICB1cGRhdGVkQ29sdW1uLndpZHRoID0gNTA7XHJcbiAgICAgICAgLy8gICAgIHVwZGF0ZWRDb2x1bW4uY2VsbENsYXNzID0gJ2FnLWRlZmF1bHQgYWctY2hlY2tib3gtcmFkaW8nO1xyXG4gICAgICAgIC8vICAgICB1cGRhdGVkQ29sdW1uLmNvbElkID0gJ3JhZGlvJztcclxuICAgICAgICAvLyAgICAgdXBkYXRlZENvbHVtbi5jZWxsUmVuZGVyZXJGcmFtZXdvcmsgPSBLZEFHQ2hlY2tib3hSYWRpbztcclxuICAgICAgICAvLyAgICAgdXBkYXRlZENvbHVtbi5oZWFkZXJOYW1lID0gJyc7XHJcblxyXG4gICAgICAgIC8vICAgICB0aGlzLl9yZXNpemVhYmxlQ29sLS07XHJcbiAgICAgICAgLy8gfVxyXG5cclxuICAgICAgICAvLyBlbHNlIGlmICh0eXBlb2YgX2NvbmZpZy5kaXNwbGF5RnJvbSAhPT0gJ3VuZGVmaW5lZCcgJiYgX2NvbmZpZy5kaXNwbGF5RnJvbSkge1xyXG4gICAgICAgICAgICAvLyB1cGRhdGVkQ29sdW1uLmNlbGxSZW5kZXJlciA9IChwYXJhbXM6IGFueSk6IGFueSA9PiB7XHJcbiAgICAgICAgICAgIC8vICAgICBpZiAodHlwZW9mIHBhcmFtcy52YWx1ZSAhPT0gJ3VuZGVmaW5lZCcpIHtcclxuICAgICAgICAgICAgLy8gICAgICAgICBpZiAocGFyYW1zLnZhbHVlIGluc3RhbmNlb2YgQXJyYXkpIHtcclxuICAgICAgICAgICAgLy8gICAgICAgICAgICAgbGV0IGRpc3BsYXlBcnJheTogQXJyYXk8YW55PiA9IFtdO1xyXG4gICAgICAgICAgICAvLyAgICAgICAgICAgICBmb3IgKGxldCBpOiBudW1iZXIgPSAwOyBpIDwgcGFyYW1zLnZhbHVlLmxlbmd0aDsgaSsrKSB7XHJcbiAgICAgICAgICAgIC8vICAgICAgICAgICAgICAgICBsZXQgZGlzcGxheTogYW55ID0gdGhpcy5fZGF0YVN2Yy5nZXREYXRhVmFsdWUocGFyYW1zLnZhbHVlW2ldLCBfY29uZmlnLmRpc3BsYXlGcm9tKTtcclxuICAgICAgICAgICAgLy8gICAgICAgICAgICAgICAgIGlmIChkaXNwbGF5ICE9PSBudWxsKSBkaXNwbGF5QXJyYXkucHVzaChkaXNwbGF5KTtcclxuICAgICAgICAgICAgLy8gICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAvLyAgICAgICAgICAgICByZXR1cm4gZGlzcGxheUFycmF5O1xyXG4gICAgICAgICAgICAvLyAgICAgICAgIH1cclxuICAgICAgICAgICAgLy8gICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgLy8gICAgICAgICAgICAgbGV0IGRpc3BsYXk6IGFueSA9IHRoaXMuX2RhdGFTdmMuZ2V0RGF0YVZhbHVlKHBhcmFtcy52YWx1ZSwgX2NvbmZpZy5kaXNwbGF5RnJvbSk7XHJcbiAgICAgICAgICAgIC8vICAgICAgICAgICAgIGlmIChkaXNwbGF5ICE9PSBudWxsKSByZXR1cm4gZGlzcGxheTtcclxuICAgICAgICAgICAgLy8gICAgICAgICB9XHJcbiAgICAgICAgICAgIC8vICAgICB9XHJcbiAgICAgICAgICAgIC8vICAgICByZXR1cm4gcGFyYW1zLnZhbHVlO1xyXG4gICAgICAgICAgICAvLyB9XHJcbiAgICAgICAgLy8gfVxyXG5cclxuICAgICAgICByZXR1cm4gdXBkYXRlZENvbHVtbjtcclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF9zZXJ2ZXJGaWx0ZXJEYXRhKF9maWx0ZXJNb2RlbDogYW55LCBfZGF0YTogQXJyYXk8YW55Pik6IEFycmF5PGFueT4ge1xyXG4gICAgICAgIGxldCBmaWx0ZXJlZERhdGE6IEFycmF5PGFueT4gPSBfZGF0YS5zbGljZSgpO1xyXG5cclxuICAgICAgICBpZiAodHlwZW9mIF9maWx0ZXJNb2RlbCA9PT0gJ3VuZGVmaW5lZCcgfHwgT2JqZWN0LmtleXMoX2ZpbHRlck1vZGVsKS5sZW5ndGggPT09IDApIHtcclxuICAgICAgICAgICAgcmV0dXJuIGZpbHRlcmVkRGF0YTtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIGxldCB1cGRhdGVkRGF0YTogQXJyYXk8YW55PiA9IFtdO1xyXG4gICAgICAgIGZvciAobGV0IGtleSBpbiBfZmlsdGVyTW9kZWwpIHtcclxuICAgICAgICAgICAgaWYgKF9maWx0ZXJNb2RlbC5oYXNPd25Qcm9wZXJ0eShrZXkpKSB7XHJcbiAgICAgICAgICAgICAgICBmb3IgKGxldCBrOiBudW1iZXIgPSAwOyBrIDwgX2ZpbHRlck1vZGVsW2tleV0ubGVuZ3RoOyBrKyspIHtcclxuICAgICAgICAgICAgICAgICAgICBmb3IgKGxldCBqOiBudW1iZXIgPSAwOyBqIDwgX2RhdGEubGVuZ3RoOyBqKyspIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgaWYgKF9kYXRhW2pdW2tleV0gPT09IF9maWx0ZXJNb2RlbFtrZXldW2tdKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB1cGRhdGVkRGF0YS5wdXNoKF9kYXRhW2pdKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgcmV0dXJuIHVwZGF0ZWREYXRhO1xyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX3NlcnZlclNvcnREYXRhKF9zb3J0TW9kZWw6IEFycmF5PGFueT4sIF9kYXRhOiBBcnJheTxhbnk+KTogQXJyYXk8YW55PiB7XHJcbiAgICAgICAgbGV0IHNvcnRlZERhdGE6IEFycmF5PGFueT4gPSBfZGF0YS5zbGljZSgpO1xyXG5cclxuICAgICAgICBpZiAodHlwZW9mIF9zb3J0TW9kZWwgPT09ICd1bmRlZmluZWQnIHx8IF9zb3J0TW9kZWwubGVuZ3RoID09PSAwKSB7XHJcbiAgICAgICAgICAgIHJldHVybiBzb3J0ZWREYXRhO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgc29ydGVkRGF0YS5zb3J0KChhOiBhbnksIGI6IGFueSk6IG51bWJlciA9PiB7XHJcbiAgICAgICAgICAgIGZvciAobGV0IGk6IG51bWJlciA9IDA7IGkgPCBfc29ydE1vZGVsLmxlbmd0aDsgaSsrKSB7XHJcbiAgICAgICAgICAgICAgICBsZXQgc29ydENvbE1vZGVsOiBhbnkgPSBfc29ydE1vZGVsW2ldO1xyXG4gICAgICAgICAgICAgICAgbGV0IHZhbEE6IGFueSA9IGFbc29ydENvbE1vZGVsLmNvbElkXTtcclxuICAgICAgICAgICAgICAgIGxldCB2YWxCOiBhbnkgPSBiW3NvcnRDb2xNb2RlbC5jb2xJZF07XHJcblxyXG4gICAgICAgICAgICAgICAgaWYgKHZhbEEgPT09IHZhbEIpIHtcclxuICAgICAgICAgICAgICAgICAgICBjb250aW51ZTtcclxuICAgICAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgICAgICBsZXQgZGlyZWN0aW9uID0gKHNvcnRDb2xNb2RlbC5zb3J0ID09PSAnYXNjJykgPyAxIDogLTE7XHJcblxyXG4gICAgICAgICAgICAgICAgaWYgKHZhbEEgPiB2YWxCKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIGRpcmVjdGlvbjtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBkaXJlY3Rpb24gKiAtMTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgIHJldHVybiAwO1xyXG4gICAgICAgIH0pO1xyXG4gICAgICAgIHJldHVybiBzb3J0ZWREYXRhO1xyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX2NoZWNrR3JpZEhlaWdodChfY29uZmlnOiBhbnkpOiBudW1iZXIgfCBzdHJpbmcge1xyXG4gICAgICAgIGxldCBkZWZhdWx0SGVpZ2h0OiBudW1iZXIgPSA2MDA7XHJcblxyXG4gICAgICAgIGlmICh0eXBlb2YgX2NvbmZpZyA9PT0gJ3VuZGVmaW5lZCcpIHtcclxuICAgICAgICAgICAgcmV0dXJuIGRlZmF1bHRIZWlnaHQ7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICBlbHNlIGlmICh0eXBlb2YgX2NvbmZpZy5ncmlkSGVpZ2h0ICE9PSAndW5kZWZpbmVkJyAmJlxyXG4gICAgICAgICAgICB0eXBlb2YgX2NvbmZpZy5ncmlkSGVpZ2h0ID09PSAnc3RyaW5nJyAmJlxyXG4gICAgICAgICAgICBfY29uZmlnLmdyaWRIZWlnaHQgPT09ICdhdXRvJykge1xyXG4gICAgICAgICAgICAgICAgcmV0dXJuIF9jb25maWcuZ3JpZEhlaWdodDtcclxuICAgICAgICB9XHJcbiAgICAgICAgZWxzZSBpZiAodHlwZW9mIF9jb25maWcuZ3JpZEhlaWdodCAhPT0gJ3VuZGVmaW5lZCcgJiZcclxuICAgICAgICAgICAgdHlwZW9mIF9jb25maWcuZ3JpZEhlaWdodCA9PT0gJ251bWJlcicpIHtcclxuICAgICAgICAgICAgICAgIHJldHVybiBfY29uZmlnLmdyaWRIZWlnaHQ7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICByZXR1cm4gZGVmYXVsdEhlaWdodDtcclxuICAgIH1cclxuXHJcbiAgICAvLyBwcml2YXRlIF9jaGVja1BhZ2luYXRpb25EYXRhKF9jb25maWc6IGFueSwgX2xvYWRUeXBlOiBzdHJpbmcpOiBhbnkge1xyXG4gICAgLy8gICAgIGlmICh0eXBlb2YgX2NvbmZpZyAhPT0gJ3VuZGVmaW5lZCcgJiZcclxuICAgIC8vICAgICAgICAgdHlwZW9mIF9jb25maWcucGFnaW5hdGlvblNldERhdGEgIT09ICd1bmRlZmluZWQnICYmXHJcbiAgICAvLyAgICAgICAgIF9sb2FkVHlwZSA9PT0gJ3NlcnZlci1wYWdpbmF0aW9uJykge1xyXG4gICAgLy8gICAgICAgICAgICAgcmV0dXJuIF9jb25maWcucGFnaW5hdGlvblNldERhdGE7XHJcbiAgICAvLyAgICAgfVxyXG4gICAgLy8gICAgIGVsc2UgaWYgKHR5cGVvZiBfY29uZmlnICE9PSAndW5kZWZpbmVkJyAmJlxyXG4gICAgLy8gICAgICAgICB0eXBlb2YgX2NvbmZpZy5wYWdpbmF0aW9uU2V0RGF0YSA9PT0gJ3VuZGVmaW5lZCcgJiZcclxuICAgIC8vICAgICAgICAgX2xvYWRUeXBlID09PSAnc2VydmVyLXBhZ2luYXRpb24nKSB7XHJcbiAgICAvLyAgICAgICAgICAgICBjb25zb2xlLmVycm9yKCdTZXJ2ZXIgcGFnaW5hdGlvbiByZXF1aXJlcyBjYWxsYmFjayB0byByZXRyaWV2ZSBkYXRhLiBQbGVhc2UgcHJvdmlkZSB0aGUgY2FsbGJhY2sgZnVuY3Rpb24uJyk7XHJcbiAgICAvLyAgICAgfVxyXG5cclxuICAgIC8vICAgICByZXR1cm4gdW5kZWZpbmVkO1xyXG4gICAgLy8gfVxyXG5cclxuICAgIHByaXZhdGUgX2NoZWNrUGFnaW5hdGlvblR5cGUoX2xvYWRUeXBlOiBzdHJpbmcpOiBzdHJpbmcge1xyXG4gICAgICAgIGlmIChfbG9hZFR5cGUgPT09ICdpbmZpbml0ZScpIHJldHVybiAnaW5maW5pdGUnO1xyXG4gICAgICAgIGlmIChfbG9hZFR5cGUgPT09ICdzZXJ2ZXItcGFnaW5hdGlvbicgfHwgX2xvYWRUeXBlID09PSAnb25lc2hvdC1wYWdpbmF0aW9uJykgcmV0dXJuICdwYWdpbmF0aW9uJztcclxuICAgICAgICByZXR1cm4gJyc7XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfY2hlY2tMb2FkVHlwZShfY29uZmlnOiBhbnkpOiBzdHJpbmcge1xyXG4gICAgICAgIGxldCBkZWZhdWx0TG9hZFR5cGU6IHN0cmluZyA9ICdub3JtYWwnO1xyXG5cclxuICAgICAgICBpZiAodHlwZW9mIF9jb25maWcgPT09ICd1bmRlZmluZWQnIHx8IHR5cGVvZiBfY29uZmlnLmxvYWRUeXBlID09PSAndW5kZWZpbmVkJykge1xyXG4gICAgICAgICAgICByZXR1cm4gZGVmYXVsdExvYWRUeXBlO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgaWYgKF9jb25maWcubG9hZFR5cGUgPT09ICdub3JtYWwnIHx8XHJcbiAgICAgICAgICAgIF9jb25maWcubG9hZFR5cGUgPT09ICdzZXJ2ZXItcGFnaW5hdGlvbicgfHxcclxuICAgICAgICAgICAgX2NvbmZpZy5sb2FkVHlwZSA9PT0gJ3ZpcnR1YWwnIHx8XHJcbiAgICAgICAgICAgIF9jb25maWcubG9hZFR5cGUgPT09ICdvbmVzaG90LXBhZ2luYXRpb24nKSB7XHJcbiAgICAgICAgICAgICAgICByZXR1cm4gX2NvbmZpZy5sb2FkVHlwZTtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIHJldHVybiBkZWZhdWx0TG9hZFR5cGU7XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfY2hlY2tQYWdlc2l6ZShfY29uZmlnOiBhbnksIF9sb2FkVHlwZTogc3RyaW5nKTogbnVtYmVyIHtcclxuICAgICAgICBpZiAoX2xvYWRUeXBlID09PSAnbm9ybWFsJykgcmV0dXJuIC0xO1xyXG4gICAgICAgIGlmICh0eXBlb2YgX2NvbmZpZyAhPT0gJ3VuZGVmaW5lZCcgJiYgdHlwZW9mIF9jb25maWcucGFnZXNpemUgIT09ICd1bmRlZmluZWQnKSByZXR1cm4gX2NvbmZpZy5wYWdlc2l6ZTtcclxuICAgICAgICByZXR1cm4gMjU7XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfZ2V0Um93SGVpZ2h0KF9wYXJhbXM6IGFueSk6IG51bWJlciB7XHJcbiAgICAgICAgbGV0IGdyaWRPcHRpb25zOiBhbnkgPSB0aGlzO1xyXG4gICAgICAgIGxldCBjb2xEZWY6IEFycmF5PGFueT4gPSBncmlkT3B0aW9ucy5jb2x1bW5EZWZzO1xyXG4gICAgICAgIGxldCByb3dIZWlnaHQ6IG51bWJlciA9IDUwO1xyXG4gICAgICAgIGZvciAobGV0IGk6IG51bWJlciA9IDA7IGkgPCBjb2xEZWYubGVuZ3RoOyBpKyspIHtcclxuICAgICAgICAgICAgaWYgKHR5cGVvZiBjb2xEZWZbaV0uY29uZmlnICE9PSAndW5kZWZpbmVkJykge1xyXG4gICAgICAgICAgICAgICAgaWYgKHR5cGVvZiBjb2xEZWZbaV0uY29uZmlnLnBob3RvICE9PSAndW5kZWZpbmVkJyAmJiBjb2xEZWZbaV0uY29uZmlnLnBob3RvKSByZXR1cm4gMTIwO1xyXG4gICAgICAgICAgICAgICAgZWxzZSBpZiAodHlwZW9mIGNvbERlZltpXS5jb25maWcudGV4dGFyZWEgIT09ICd1bmRlZmluZWQnICYmIGNvbERlZltpXS5jb25maWcudGV4dGFyZWEpIHJldHVybiAxMjA7XHJcbiAgICAgICAgICAgICAgICBlbHNlIGlmICh0eXBlb2YgY29sRGVmW2ldLmNvbmZpZy5pbnB1dCAhPT0gJ3VuZGVmaW5lZCcgJiYgY29sRGVmW2ldLmNvbmZpZy5pbnB1dCkge1xyXG4gICAgICAgICAgICAgICAgICAgIGlmIChfcGFyYW1zLmRhdGFbY29sRGVmW2ldLmNvbElkXSBpbnN0YW5jZW9mIEFycmF5KSByZXR1cm4gcm93SGVpZ2h0ICogX3BhcmFtcy5kYXRhW2NvbERlZltpXS5jb2xJZF0ubGVuZ3RoO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgICAgIHJldHVybiA1MDtcclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF9jaGVja0J0bkNvbmZpZyhfYnV0dG9uTGlzdDogQXJyYXk8YW55Pik6IEFycmF5PGFueT4ge1xyXG4gICAgICAgIGxldCB1cGRhdGVkQnRuQ29uZmlnOiBBcnJheTxhbnk+ID0gW107XHJcbiAgICAgICAgZm9yIChsZXQgaTogbnVtYmVyID0gMDsgaSA8IF9idXR0b25MaXN0Lmxlbmd0aDsgaSsrKSB7XHJcbiAgICAgICAgICAgIHVwZGF0ZWRCdG5Db25maWcucHVzaCh0aGlzLl9jaGVja0J1dHRvbihfYnV0dG9uTGlzdFtpXSkpO1xyXG4gICAgICAgIH1cclxuICAgICAgICByZXR1cm4gdXBkYXRlZEJ0bkNvbmZpZztcclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF9jaGVja0J1dHRvbihfYnV0dG9uSXRlbTogYW55KTogYW55IHtcclxuICAgICAgICBsZXQgZGVmYXVsdEJ1dHRvbjogYW55ID0ge1xyXG4gICAgICAgICAgICB0eXBlOiBudWxsLFxyXG4gICAgICAgICAgICBsYWJlbDogJycsXHJcbiAgICAgICAgICAgIGljb246ICcnLFxyXG4gICAgICAgICAgICBjb25maWc6IG51bGwsXHJcbiAgICAgICAgICAgIGNhbGxiYWNrOiBudWxsLFxyXG4gICAgICAgICAgICBwYXRoOiBudWxsXHJcbiAgICAgICAgfTtcclxuICAgICAgICByZXR1cm4gT2JqZWN0LmFzc2lnbihkZWZhdWx0QnV0dG9uLCBfYnV0dG9uSXRlbSk7XHJcbiAgICB9XHJcbn1cclxuIl19