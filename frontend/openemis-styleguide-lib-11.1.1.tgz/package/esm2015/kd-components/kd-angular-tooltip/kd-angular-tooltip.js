import { Component, Input, ViewEncapsulation, } from '@angular/core';
/**
 * plugin: primeng tooltip
 *
 * note: if type is custom, in [config]
 *         - description is HTML string
 *         - customise icon used using iconClass
 *         - customise class appended to primeng tooltip using typeClass
 */
export class KdTooltip {
    constructor() {
        this.description = '';
        this.placement = '';
        this.typeClass = '';
        this.tooltipIconClass = '';
        this._type = '';
    }
    ngOnInit() {
        /* if type is custom, take description (HTML string) and pass to primeng directly */
        this.description = this.config.type === 'custom' ? this.config.description : this._checkDescription(this.config.description);
        this.placement = (typeof this.config.placement !== 'undefined') ? this.config.placement : 'right';
        this._type = (typeof this.config.type !== 'undefined') ? this.config.type : 'info';
        switch (this._type) {
            case 'error':
                this.typeClass = 'kdx-tooltip-error';
                this.tooltipIconClass = 'fa fa-lg fa-exclamation-circle ' + this.typeClass;
                break;
            case 'warning':
                this.typeClass = 'kdx-tooltip-warning';
                this.tooltipIconClass = 'fa fa-lg fa-question-circle ' + this.typeClass;
                break;
            case 'info':
                this.typeClass = 'kdx-tooltip-info';
                this.tooltipIconClass = 'fa fa-lg fa-info-circle ' + this.typeClass;
                break;
            case 'custom':
                this.typeClass = this.config.typeClass || 'kdx-tooltip-custom';
                this.tooltipIconClass = ((this.config.iconClass + ' ') || 'fa fa-lg fa-exclamation-circle ') + this.typeClass;
                break;
            default:
                this.typeClass = 'kdx-tooltip-info';
                this.tooltipIconClass = 'fa fa-lg fa-info-circle ' + this.typeClass;
                break;
        }
    }
    ngOnChanges() {
        this.description = this.config.type === 'custom' ? this.config.description : this._checkDescription(this.config.description);
    }
    /******* temp fix by Grace (13 Dec 2017) *********/
    /* temp fix due to event listerner of primeng - mouseenter and mouseleave and click are triggered tgt in one touch of mobile device */
    // public _mouseenter(e:Event): void {
    //     if(this._kdDomSvc.isMobileDevice()) {
    //         console.log('if reached')
    //         // disable click
    //         // let tooltipIcon: any = e.target;
    //         // tooltipIcon.style.pointerEvents = 'none';
    //         this.tooltipIcon.nativeElement.style.pointerEvents = 'none';
    //         let removeTooltip = function () {
    //             console.log('touchstart')
    //             let tooltipEle: any = document.querySelector('.ui-tooltip');
    //             if (tooltipEle) tooltipEle.remove();
    //             // tooltipIcon.style.pointerEvents = 'auto';
    //             document.removeEventListener('touchstart',removeTooltip);
    //         }
    //         // when user touch/pan/swipe/scrolls, tooltip is removed to prevent misalignment
    //         document.addEventListener('touchstart', removeTooltip);
    //         Observable.timer(1000).subscribe((): void => {
    //             this.tooltipIcon.nativeElement.style.pointerEvents = 'auto';
    //         })
    //     }
    //     this._renderer.listen(document,'touchstart',()=>{
    //         console.log('ontouchstart')
    //     })
    // }
    /****** temp fix end ******/
    _checkDescription(_description) {
        if (_description === '' || (_description instanceof Array && _description.length === 0))
            return '';
        // if (typeof _description === 'string') return '<div class="kd-tooltip-text">' + _description + '</div>';
        if (typeof _description === 'string')
            return '<div class="tooltip-text">' + _description + '</div>';
        if (_description instanceof Array) {
            if (_description.length === 1)
                return '<div class="tooltip-text">' + _description[0] + '</div>';
            let newString = '<ul class="tooltip-list">';
            for (let i = 0; i < _description.length; i++) {
                newString += '<li>' + _description[i] + '</li>';
            }
            newString += '</ul>';
            return newString;
        }
    }
}
KdTooltip.decorators = [
    { type: Component, args: [{
                selector: 'kd-tooltip',
                template: "<!-- <i *ngIf=\"_description != ''\" [ngClass]=\"_tooltipClass\" [placement]=\"_placement\" [ngbTooltip]=\"_description\"></i> -->\r\n<!-- <i *ngIf=\"_description == ''\" [ngClass]=\"_tooltipClass\" [placement]=\"_placement\" [ngbTooltip]=\"ngContent\"></i> -->\r\n<!--NgContent if there is no user input for description-->\r\n<!-- <template #ngContent>\r\n    <ng-content></ng-content>\r\n</template>\r\n -->\r\n\r\n\t<i [kd-tooltip-dir]=\"description\" tooltipEvent=\"hover\" [tooltipPosition]=\"placement\" [ngClass]=\"tooltipIconClass\" [tooltipStyleClass]=\"typeClass\" [escape]=\"false\"\r\n\t></i>\r\n",
                encapsulation: ViewEncapsulation.None,
                host: { 'class': 'kdx-tooltip' }
            },] }
];
KdTooltip.propDecorators = {
    config: [{ type: Input }]
};
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoia2QtYW5ndWxhci10b29sdGlwLmpzIiwic291cmNlUm9vdCI6IkQ6L29wZW5FTUlTL3N0eWxlZ3VpZGUvaW9zdGctb3BlbmVtaXMtc3R5bGVndWlkZS9wcm9qZWN0cy9vcGVuZW1pcy1zdHlsZWd1aWRlLWxpYi9zcmMvIiwic291cmNlcyI6WyJrZC1jb21wb25lbnRzL2tkLWFuZ3VsYXItdG9vbHRpcC9rZC1hbmd1bGFyLXRvb2x0aXAudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsT0FBTyxFQUNILFNBQVMsRUFDVCxLQUFLLEVBR0wsaUJBQWlCLEdBQ3BCLE1BQU0sZUFBZSxDQUFDO0FBU3ZCOzs7Ozs7O0dBT0c7QUFFSCxNQUFNLE9BQU8sU0FBUztJQWhCdEI7UUFrQlcsZ0JBQVcsR0FBVyxFQUFFLENBQUM7UUFDekIsY0FBUyxHQUFXLEVBQUUsQ0FBQztRQUN2QixjQUFTLEdBQVcsRUFBRSxDQUFDO1FBQ3ZCLHFCQUFnQixHQUFXLEVBQUUsQ0FBQztRQUU3QixVQUFLLEdBQVcsRUFBRSxDQUFDO0lBd0YvQixDQUFDO0lBcEZHLFFBQVE7UUFDSixvRkFBb0Y7UUFDcEYsSUFBSSxDQUFDLFdBQVcsR0FBRyxJQUFJLENBQUMsTUFBTSxDQUFDLElBQUksS0FBSyxRQUFRLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsaUJBQWlCLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxXQUFXLENBQUMsQ0FBQztRQUM3SCxJQUFJLENBQUMsU0FBUyxHQUFHLENBQUMsT0FBTyxJQUFJLENBQUMsTUFBTSxDQUFDLFNBQVMsS0FBSyxXQUFXLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQztRQUNsRyxJQUFJLENBQUMsS0FBSyxHQUFHLENBQUMsT0FBTyxJQUFJLENBQUMsTUFBTSxDQUFDLElBQUksS0FBSyxXQUFXLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQztRQUVuRixRQUFRLElBQUksQ0FBQyxLQUFLLEVBQUU7WUFDaEIsS0FBSyxPQUFPO2dCQUNSLElBQUksQ0FBQyxTQUFTLEdBQUcsbUJBQW1CLENBQUM7Z0JBQ3JDLElBQUksQ0FBQyxnQkFBZ0IsR0FBRyxpQ0FBaUMsR0FBRyxJQUFJLENBQUMsU0FBUyxDQUFDO2dCQUMzRSxNQUFNO1lBQ1YsS0FBSyxTQUFTO2dCQUNWLElBQUksQ0FBQyxTQUFTLEdBQUcscUJBQXFCLENBQUM7Z0JBQ3ZDLElBQUksQ0FBQyxnQkFBZ0IsR0FBRyw4QkFBOEIsR0FBRyxJQUFJLENBQUMsU0FBUyxDQUFDO2dCQUN4RSxNQUFNO1lBQ1YsS0FBSyxNQUFNO2dCQUNQLElBQUksQ0FBQyxTQUFTLEdBQUcsa0JBQWtCLENBQUM7Z0JBQ3BDLElBQUksQ0FBQyxnQkFBZ0IsR0FBRywwQkFBMEIsR0FBRyxJQUFJLENBQUMsU0FBUyxDQUFDO2dCQUNwRSxNQUFNO1lBQ1YsS0FBSyxRQUFRO2dCQUNULElBQUksQ0FBQyxTQUFTLEdBQUcsSUFBSSxDQUFDLE1BQU0sQ0FBQyxTQUFTLElBQUksb0JBQW9CLENBQUM7Z0JBQy9ELElBQUksQ0FBQyxnQkFBZ0IsR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxTQUFTLEdBQUcsR0FBRyxDQUFDLElBQUksaUNBQWlDLENBQUMsR0FBRyxJQUFJLENBQUMsU0FBUyxDQUFDO2dCQUM5RyxNQUFNO1lBQ1Y7Z0JBQ0ksSUFBSSxDQUFDLFNBQVMsR0FBRyxrQkFBa0IsQ0FBQztnQkFDcEMsSUFBSSxDQUFDLGdCQUFnQixHQUFHLDBCQUEwQixHQUFHLElBQUksQ0FBQyxTQUFTLENBQUM7Z0JBQ3BFLE1BQU07U0FDYjtJQUNMLENBQUM7SUFFRCxXQUFXO1FBQ1AsSUFBSSxDQUFDLFdBQVcsR0FBRyxJQUFJLENBQUMsTUFBTSxDQUFDLElBQUksS0FBSyxRQUFRLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsaUJBQWlCLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxXQUFXLENBQUMsQ0FBQztJQUNqSSxDQUFDO0lBRUQsbURBQW1EO0lBQ25ELHNJQUFzSTtJQUN0SSxzQ0FBc0M7SUFFdEMsNENBQTRDO0lBQzVDLG9DQUFvQztJQUNwQywyQkFBMkI7SUFDM0IsOENBQThDO0lBQzlDLHVEQUF1RDtJQUN2RCx1RUFBdUU7SUFFdkUsNENBQTRDO0lBQzVDLHdDQUF3QztJQUN4QywyRUFBMkU7SUFDM0UsbURBQW1EO0lBQ25ELDJEQUEyRDtJQUMzRCx3RUFBd0U7SUFDeEUsWUFBWTtJQUVaLDJGQUEyRjtJQUMzRixrRUFBa0U7SUFFbEUseURBQXlEO0lBQ3pELDJFQUEyRTtJQUMzRSxhQUFhO0lBQ2IsUUFBUTtJQUNSLHdEQUF3RDtJQUN4RCxzQ0FBc0M7SUFDdEMsU0FBUztJQUNULElBQUk7SUFDSiw0QkFBNEI7SUFFcEIsaUJBQWlCLENBQUMsWUFBaUI7UUFDdkMsSUFBSSxZQUFZLEtBQUssRUFBRSxJQUFJLENBQUMsWUFBWSxZQUFZLEtBQUssSUFBSSxZQUFZLENBQUMsTUFBTSxLQUFLLENBQUMsQ0FBQztZQUFFLE9BQU8sRUFBRSxDQUFDO1FBRW5HLDBHQUEwRztRQUMxRyxJQUFJLE9BQU8sWUFBWSxLQUFLLFFBQVE7WUFBRSxPQUFPLDRCQUE0QixHQUFHLFlBQVksR0FBRyxRQUFRLENBQUM7UUFFcEcsSUFBSSxZQUFZLFlBQVksS0FBSyxFQUFFO1lBQy9CLElBQUksWUFBWSxDQUFDLE1BQU0sS0FBSyxDQUFDO2dCQUFFLE9BQU8sNEJBQTRCLEdBQUcsWUFBWSxDQUFDLENBQUMsQ0FBQyxHQUFHLFFBQVEsQ0FBQztZQUVoRyxJQUFJLFNBQVMsR0FBVywyQkFBMkIsQ0FBQztZQUNwRCxLQUFLLElBQUksQ0FBQyxHQUFXLENBQUMsRUFBRSxDQUFDLEdBQUcsWUFBWSxDQUFDLE1BQU0sRUFBRSxDQUFDLEVBQUUsRUFBRTtnQkFDbEQsU0FBUyxJQUFJLE1BQU0sR0FBRyxZQUFZLENBQUMsQ0FBQyxDQUFDLEdBQUcsT0FBTyxDQUFDO2FBQ25EO1lBQ0QsU0FBUyxJQUFJLE9BQU8sQ0FBQztZQUVyQixPQUFPLFNBQVMsQ0FBQztTQUNwQjtJQUNMLENBQUM7OztZQTlHSixTQUFTLFNBQUM7Z0JBQ1AsUUFBUSxFQUFFLFlBQVk7Z0JBQ3RCLDRtQkFBd0M7Z0JBQ3hDLGFBQWEsRUFBRSxpQkFBaUIsQ0FBQyxJQUFJO2dCQUNyQyxJQUFJLEVBQUcsRUFBRSxPQUFPLEVBQUcsYUFBYSxFQUFFO2FBQ3JDOzs7cUJBb0JJLEtBQUsiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQge1xyXG4gICAgQ29tcG9uZW50LFxyXG4gICAgSW5wdXQsXHJcbiAgICBPbkluaXQsXHJcbiAgICBPbkNoYW5nZXMsXHJcbiAgICBWaWV3RW5jYXBzdWxhdGlvbixcclxufSBmcm9tICdAYW5ndWxhci9jb3JlJztcclxuXHJcbkBDb21wb25lbnQoe1xyXG4gICAgc2VsZWN0b3I6ICdrZC10b29sdGlwJyxcclxuICAgIHRlbXBsYXRlVXJsOiAnLi9rZC1hbmd1bGFyLXRvb2x0aXAuaHRtbCcsXHJcbiAgICBlbmNhcHN1bGF0aW9uOiBWaWV3RW5jYXBzdWxhdGlvbi5Ob25lLFxyXG4gICAgaG9zdCA6IHsgJ2NsYXNzJyA6ICdrZHgtdG9vbHRpcCcgfVxyXG59KVxyXG5cclxuLyoqXHJcbiAqIHBsdWdpbjogcHJpbWVuZyB0b29sdGlwXHJcbiAqXHJcbiAqIG5vdGU6IGlmIHR5cGUgaXMgY3VzdG9tLCBpbiBbY29uZmlnXVxyXG4gKiAgICAgICAgIC0gZGVzY3JpcHRpb24gaXMgSFRNTCBzdHJpbmdcclxuICogICAgICAgICAtIGN1c3RvbWlzZSBpY29uIHVzZWQgdXNpbmcgaWNvbkNsYXNzXHJcbiAqICAgICAgICAgLSBjdXN0b21pc2UgY2xhc3MgYXBwZW5kZWQgdG8gcHJpbWVuZyB0b29sdGlwIHVzaW5nIHR5cGVDbGFzc1xyXG4gKi9cclxuXHJcbmV4cG9ydCBjbGFzcyBLZFRvb2x0aXAgaW1wbGVtZW50cyBPbkluaXQsIE9uQ2hhbmdlcyB7XHJcblxyXG4gICAgcHVibGljIGRlc2NyaXB0aW9uOiBzdHJpbmcgPSAnJztcclxuICAgIHB1YmxpYyBwbGFjZW1lbnQ6IHN0cmluZyA9ICcnO1xyXG4gICAgcHVibGljIHR5cGVDbGFzczogc3RyaW5nID0gJyc7XHJcbiAgICBwdWJsaWMgdG9vbHRpcEljb25DbGFzczogc3RyaW5nID0gJyc7XHJcblxyXG4gICAgcHJpdmF0ZSBfdHlwZTogc3RyaW5nID0gJyc7XHJcblxyXG4gICAgQElucHV0KCkgY29uZmlnOiBhbnk7XHJcblxyXG4gICAgbmdPbkluaXQoKTogdm9pZCB7XHJcbiAgICAgICAgLyogaWYgdHlwZSBpcyBjdXN0b20sIHRha2UgZGVzY3JpcHRpb24gKEhUTUwgc3RyaW5nKSBhbmQgcGFzcyB0byBwcmltZW5nIGRpcmVjdGx5ICovXHJcbiAgICAgICAgdGhpcy5kZXNjcmlwdGlvbiA9IHRoaXMuY29uZmlnLnR5cGUgPT09ICdjdXN0b20nID8gdGhpcy5jb25maWcuZGVzY3JpcHRpb24gOiB0aGlzLl9jaGVja0Rlc2NyaXB0aW9uKHRoaXMuY29uZmlnLmRlc2NyaXB0aW9uKTtcclxuICAgICAgICB0aGlzLnBsYWNlbWVudCA9ICh0eXBlb2YgdGhpcy5jb25maWcucGxhY2VtZW50ICE9PSAndW5kZWZpbmVkJykgPyB0aGlzLmNvbmZpZy5wbGFjZW1lbnQgOiAncmlnaHQnO1xyXG4gICAgICAgIHRoaXMuX3R5cGUgPSAodHlwZW9mIHRoaXMuY29uZmlnLnR5cGUgIT09ICd1bmRlZmluZWQnKSA/IHRoaXMuY29uZmlnLnR5cGUgOiAnaW5mbyc7XHJcblxyXG4gICAgICAgIHN3aXRjaCAodGhpcy5fdHlwZSkge1xyXG4gICAgICAgICAgICBjYXNlICdlcnJvcic6XHJcbiAgICAgICAgICAgICAgICB0aGlzLnR5cGVDbGFzcyA9ICdrZHgtdG9vbHRpcC1lcnJvcic7XHJcbiAgICAgICAgICAgICAgICB0aGlzLnRvb2x0aXBJY29uQ2xhc3MgPSAnZmEgZmEtbGcgZmEtZXhjbGFtYXRpb24tY2lyY2xlICcgKyB0aGlzLnR5cGVDbGFzcztcclxuICAgICAgICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgICAgICBjYXNlICd3YXJuaW5nJzpcclxuICAgICAgICAgICAgICAgIHRoaXMudHlwZUNsYXNzID0gJ2tkeC10b29sdGlwLXdhcm5pbmcnO1xyXG4gICAgICAgICAgICAgICAgdGhpcy50b29sdGlwSWNvbkNsYXNzID0gJ2ZhIGZhLWxnIGZhLXF1ZXN0aW9uLWNpcmNsZSAnICsgdGhpcy50eXBlQ2xhc3M7XHJcbiAgICAgICAgICAgICAgICBicmVhaztcclxuICAgICAgICAgICAgY2FzZSAnaW5mbyc6XHJcbiAgICAgICAgICAgICAgICB0aGlzLnR5cGVDbGFzcyA9ICdrZHgtdG9vbHRpcC1pbmZvJztcclxuICAgICAgICAgICAgICAgIHRoaXMudG9vbHRpcEljb25DbGFzcyA9ICdmYSBmYS1sZyBmYS1pbmZvLWNpcmNsZSAnICsgdGhpcy50eXBlQ2xhc3M7XHJcbiAgICAgICAgICAgICAgICBicmVhaztcclxuICAgICAgICAgICAgY2FzZSAnY3VzdG9tJzpcclxuICAgICAgICAgICAgICAgIHRoaXMudHlwZUNsYXNzID0gdGhpcy5jb25maWcudHlwZUNsYXNzIHx8ICdrZHgtdG9vbHRpcC1jdXN0b20nO1xyXG4gICAgICAgICAgICAgICAgdGhpcy50b29sdGlwSWNvbkNsYXNzID0gKCh0aGlzLmNvbmZpZy5pY29uQ2xhc3MgKyAnICcpIHx8ICdmYSBmYS1sZyBmYS1leGNsYW1hdGlvbi1jaXJjbGUgJykgKyB0aGlzLnR5cGVDbGFzcztcclxuICAgICAgICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgICAgICBkZWZhdWx0OlxyXG4gICAgICAgICAgICAgICAgdGhpcy50eXBlQ2xhc3MgPSAna2R4LXRvb2x0aXAtaW5mbyc7XHJcbiAgICAgICAgICAgICAgICB0aGlzLnRvb2x0aXBJY29uQ2xhc3MgPSAnZmEgZmEtbGcgZmEtaW5mby1jaXJjbGUgJyArIHRoaXMudHlwZUNsYXNzO1xyXG4gICAgICAgICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIG5nT25DaGFuZ2VzKCk6IHZvaWQge1xyXG4gICAgICAgIHRoaXMuZGVzY3JpcHRpb24gPSB0aGlzLmNvbmZpZy50eXBlID09PSAnY3VzdG9tJyA/IHRoaXMuY29uZmlnLmRlc2NyaXB0aW9uIDogdGhpcy5fY2hlY2tEZXNjcmlwdGlvbih0aGlzLmNvbmZpZy5kZXNjcmlwdGlvbik7XHJcbiAgICB9XHJcblxyXG4gICAgLyoqKioqKiogdGVtcCBmaXggYnkgR3JhY2UgKDEzIERlYyAyMDE3KSAqKioqKioqKiovXHJcbiAgICAvKiB0ZW1wIGZpeCBkdWUgdG8gZXZlbnQgbGlzdGVybmVyIG9mIHByaW1lbmcgLSBtb3VzZWVudGVyIGFuZCBtb3VzZWxlYXZlIGFuZCBjbGljayBhcmUgdHJpZ2dlcmVkIHRndCBpbiBvbmUgdG91Y2ggb2YgbW9iaWxlIGRldmljZSAqL1xyXG4gICAgLy8gcHVibGljIF9tb3VzZWVudGVyKGU6RXZlbnQpOiB2b2lkIHtcclxuXHJcbiAgICAvLyAgICAgaWYodGhpcy5fa2REb21TdmMuaXNNb2JpbGVEZXZpY2UoKSkge1xyXG4gICAgLy8gICAgICAgICBjb25zb2xlLmxvZygnaWYgcmVhY2hlZCcpXHJcbiAgICAvLyAgICAgICAgIC8vIGRpc2FibGUgY2xpY2tcclxuICAgIC8vICAgICAgICAgLy8gbGV0IHRvb2x0aXBJY29uOiBhbnkgPSBlLnRhcmdldDtcclxuICAgIC8vICAgICAgICAgLy8gdG9vbHRpcEljb24uc3R5bGUucG9pbnRlckV2ZW50cyA9ICdub25lJztcclxuICAgIC8vICAgICAgICAgdGhpcy50b29sdGlwSWNvbi5uYXRpdmVFbGVtZW50LnN0eWxlLnBvaW50ZXJFdmVudHMgPSAnbm9uZSc7XHJcblxyXG4gICAgLy8gICAgICAgICBsZXQgcmVtb3ZlVG9vbHRpcCA9IGZ1bmN0aW9uICgpIHtcclxuICAgIC8vICAgICAgICAgICAgIGNvbnNvbGUubG9nKCd0b3VjaHN0YXJ0JylcclxuICAgIC8vICAgICAgICAgICAgIGxldCB0b29sdGlwRWxlOiBhbnkgPSBkb2N1bWVudC5xdWVyeVNlbGVjdG9yKCcudWktdG9vbHRpcCcpO1xyXG4gICAgLy8gICAgICAgICAgICAgaWYgKHRvb2x0aXBFbGUpIHRvb2x0aXBFbGUucmVtb3ZlKCk7XHJcbiAgICAvLyAgICAgICAgICAgICAvLyB0b29sdGlwSWNvbi5zdHlsZS5wb2ludGVyRXZlbnRzID0gJ2F1dG8nO1xyXG4gICAgLy8gICAgICAgICAgICAgZG9jdW1lbnQucmVtb3ZlRXZlbnRMaXN0ZW5lcigndG91Y2hzdGFydCcscmVtb3ZlVG9vbHRpcCk7XHJcbiAgICAvLyAgICAgICAgIH1cclxuXHJcbiAgICAvLyAgICAgICAgIC8vIHdoZW4gdXNlciB0b3VjaC9wYW4vc3dpcGUvc2Nyb2xscywgdG9vbHRpcCBpcyByZW1vdmVkIHRvIHByZXZlbnQgbWlzYWxpZ25tZW50XHJcbiAgICAvLyAgICAgICAgIGRvY3VtZW50LmFkZEV2ZW50TGlzdGVuZXIoJ3RvdWNoc3RhcnQnLCByZW1vdmVUb29sdGlwKTtcclxuXHJcbiAgICAvLyAgICAgICAgIE9ic2VydmFibGUudGltZXIoMTAwMCkuc3Vic2NyaWJlKCgpOiB2b2lkID0+IHtcclxuICAgIC8vICAgICAgICAgICAgIHRoaXMudG9vbHRpcEljb24ubmF0aXZlRWxlbWVudC5zdHlsZS5wb2ludGVyRXZlbnRzID0gJ2F1dG8nO1xyXG4gICAgLy8gICAgICAgICB9KVxyXG4gICAgLy8gICAgIH1cclxuICAgIC8vICAgICB0aGlzLl9yZW5kZXJlci5saXN0ZW4oZG9jdW1lbnQsJ3RvdWNoc3RhcnQnLCgpPT57XHJcbiAgICAvLyAgICAgICAgIGNvbnNvbGUubG9nKCdvbnRvdWNoc3RhcnQnKVxyXG4gICAgLy8gICAgIH0pXHJcbiAgICAvLyB9XHJcbiAgICAvKioqKioqIHRlbXAgZml4IGVuZCAqKioqKiovXHJcblxyXG4gICAgcHJpdmF0ZSBfY2hlY2tEZXNjcmlwdGlvbihfZGVzY3JpcHRpb246IGFueSk6IHN0cmluZyB7XHJcbiAgICAgICAgaWYgKF9kZXNjcmlwdGlvbiA9PT0gJycgfHwgKF9kZXNjcmlwdGlvbiBpbnN0YW5jZW9mIEFycmF5ICYmIF9kZXNjcmlwdGlvbi5sZW5ndGggPT09IDApKSByZXR1cm4gJyc7XHJcblxyXG4gICAgICAgIC8vIGlmICh0eXBlb2YgX2Rlc2NyaXB0aW9uID09PSAnc3RyaW5nJykgcmV0dXJuICc8ZGl2IGNsYXNzPVwia2QtdG9vbHRpcC10ZXh0XCI+JyArIF9kZXNjcmlwdGlvbiArICc8L2Rpdj4nO1xyXG4gICAgICAgIGlmICh0eXBlb2YgX2Rlc2NyaXB0aW9uID09PSAnc3RyaW5nJykgcmV0dXJuICc8ZGl2IGNsYXNzPVwidG9vbHRpcC10ZXh0XCI+JyArIF9kZXNjcmlwdGlvbiArICc8L2Rpdj4nO1xyXG5cclxuICAgICAgICBpZiAoX2Rlc2NyaXB0aW9uIGluc3RhbmNlb2YgQXJyYXkpIHtcclxuICAgICAgICAgICAgaWYgKF9kZXNjcmlwdGlvbi5sZW5ndGggPT09IDEpIHJldHVybiAnPGRpdiBjbGFzcz1cInRvb2x0aXAtdGV4dFwiPicgKyBfZGVzY3JpcHRpb25bMF0gKyAnPC9kaXY+JztcclxuXHJcbiAgICAgICAgICAgIGxldCBuZXdTdHJpbmc6IHN0cmluZyA9ICc8dWwgY2xhc3M9XCJ0b29sdGlwLWxpc3RcIj4nO1xyXG4gICAgICAgICAgICBmb3IgKGxldCBpOiBudW1iZXIgPSAwOyBpIDwgX2Rlc2NyaXB0aW9uLmxlbmd0aDsgaSsrKSB7XHJcbiAgICAgICAgICAgICAgICBuZXdTdHJpbmcgKz0gJzxsaT4nICsgX2Rlc2NyaXB0aW9uW2ldICsgJzwvbGk+JztcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBuZXdTdHJpbmcgKz0gJzwvdWw+JztcclxuXHJcbiAgICAgICAgICAgIHJldHVybiBuZXdTdHJpbmc7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG59XHJcbiJdfQ==