import { Component, Input, Output, EventEmitter, ViewEncapsulation, ViewChild } from '@angular/core';
import { KdView } from '../kd-angular-view/index';
export class KdDelete {
    constructor() {
        this._questionData = [];
        this._defaultBtn = [{
                type: 'submit',
                name: 'Delete',
                icon: 'kd-trash',
                class: 'btn-text',
                disabled: false
            }, {
                type: 'cancel',
                name: 'Cancel',
                class: 'btn-outline',
                icon: 'kd-cross',
                disabled: false
            }];
        this._sectionHeader = {
            key: 'SectionHeader',
            label: 'Are you sure you want to delete this?',
            controlType: 'section',
            visible: true,
            required: false
        };
        this.buttonCancelEvent = new EventEmitter();
        this.buttonDeleteEvent = new EventEmitter();
    }
    ngOnInit() {
        if (typeof this.question !== 'undefined' && this.question.length > 0)
            this._questionData = this.question;
        this._questionData.unshift(this._sectionHeader);
    }
    btnClick(_button) {
        this.buttonCancelEvent.emit();
    }
    submitClick(_formVal) {
        this.buttonDeleteEvent.emit(_formVal);
    }
    setDeleteDisabled(_toDisable) {
        this.kdViewComponent.setButtonDisabled('submit', _toDisable);
    }
}
KdDelete.decorators = [
    { type: Component, args: [{
                selector: 'kd-delete',
                template: `<kd-view displayType='form' [inputData]='_questionData' [button]='_defaultBtn' (buttonEvent)='btnClick($event)' (submitEvent)='submitClick($event)'></kd-view>`,
                encapsulation: ViewEncapsulation.None
            },] }
];
KdDelete.propDecorators = {
    question: [{ type: Input }],
    buttonCancelEvent: [{ type: Output }],
    buttonDeleteEvent: [{ type: Output }],
    kdViewComponent: [{ type: ViewChild, args: [KdView, { static: true },] }]
};
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoia2QtYW5ndWxhci1kZWxldGUtY29tcC5qcyIsInNvdXJjZVJvb3QiOiJEOi9vcGVuRU1JUy9zdHlsZWd1aWRlL2lvc3RnLW9wZW5lbWlzLXN0eWxlZ3VpZGUvcHJvamVjdHMvb3BlbmVtaXMtc3R5bGVndWlkZS1saWIvc3JjLyIsInNvdXJjZXMiOlsia2QtY29tcG9uZW50cy9rZC1hbmd1bGFyLWRlbGV0ZS1jb21wL2tkLWFuZ3VsYXItZGVsZXRlLWNvbXAudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsT0FBTyxFQUNILFNBQVMsRUFDVCxLQUFLLEVBQ0wsTUFBTSxFQUNOLFlBQVksRUFDWixpQkFBaUIsRUFFakIsU0FBUyxFQUNaLE1BQU0sZUFBZSxDQUFDO0FBQ3ZCLE9BQU8sRUFBRSxNQUFNLEVBQUUsTUFBTSwwQkFBMEIsQ0FBQztBQVFsRCxNQUFNLE9BQU8sUUFBUTtJQU5yQjtRQU9XLGtCQUFhLEdBQWUsRUFBRSxDQUFDO1FBQy9CLGdCQUFXLEdBQWUsQ0FBQztnQkFDOUIsSUFBSSxFQUFFLFFBQVE7Z0JBQ2QsSUFBSSxFQUFFLFFBQVE7Z0JBQ2QsSUFBSSxFQUFFLFVBQVU7Z0JBQ2hCLEtBQUssRUFBRSxVQUFVO2dCQUNqQixRQUFRLEVBQUUsS0FBSzthQUNsQixFQUFFO2dCQUNDLElBQUksRUFBRSxRQUFRO2dCQUNkLElBQUksRUFBRSxRQUFRO2dCQUNkLEtBQUssRUFBRSxhQUFhO2dCQUNwQixJQUFJLEVBQUUsVUFBVTtnQkFDaEIsUUFBUSxFQUFFLEtBQUs7YUFDbEIsQ0FBQyxDQUFDO1FBRUssbUJBQWMsR0FBUTtZQUMxQixHQUFHLEVBQUUsZUFBZTtZQUNwQixLQUFLLEVBQUUsdUNBQXVDO1lBQzlDLFdBQVcsRUFBRSxTQUFTO1lBQ3RCLE9BQU8sRUFBRSxJQUFJO1lBQ2IsUUFBUSxFQUFFLEtBQUs7U0FDbEIsQ0FBQztRQUdRLHNCQUFpQixHQUFzQixJQUFJLFlBQVksRUFBRSxDQUFDO1FBQzFELHNCQUFpQixHQUFzQixJQUFJLFlBQVksRUFBRSxDQUFDO0lBbUJ4RSxDQUFDO0lBaEJHLFFBQVE7UUFDSixJQUFJLE9BQU8sSUFBSSxDQUFDLFFBQVEsS0FBSyxXQUFXLElBQUksSUFBSSxDQUFDLFFBQVEsQ0FBQyxNQUFNLEdBQUcsQ0FBQztZQUFFLElBQUksQ0FBQyxhQUFhLEdBQUcsSUFBSSxDQUFDLFFBQVEsQ0FBQztRQUN6RyxJQUFJLENBQUMsYUFBYSxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsY0FBYyxDQUFDLENBQUM7SUFDcEQsQ0FBQztJQUVELFFBQVEsQ0FBQyxPQUFZO1FBQ2pCLElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxJQUFJLEVBQUUsQ0FBQztJQUNsQyxDQUFDO0lBRUQsV0FBVyxDQUFDLFFBQWE7UUFDckIsSUFBSSxDQUFDLGlCQUFpQixDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsQ0FBQztJQUMxQyxDQUFDO0lBRU0saUJBQWlCLENBQUMsVUFBbUI7UUFDeEMsSUFBSSxDQUFDLGVBQWUsQ0FBQyxpQkFBaUIsQ0FBQyxRQUFRLEVBQUUsVUFBVSxDQUFDLENBQUM7SUFDakUsQ0FBQzs7O1lBbERKLFNBQVMsU0FBQztnQkFDUCxRQUFRLEVBQUUsV0FBVztnQkFDckIsUUFBUSxFQUFFLGdLQUFnSztnQkFDMUssYUFBYSxFQUFFLGlCQUFpQixDQUFDLElBQUk7YUFDeEM7Ozt1QkEwQkksS0FBSztnQ0FDTCxNQUFNO2dDQUNOLE1BQU07OEJBQ04sU0FBUyxTQUFDLE1BQU0sRUFBRSxFQUFFLE1BQU0sRUFBRSxJQUFJLEVBQUUiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQge1xyXG4gICAgQ29tcG9uZW50LFxyXG4gICAgSW5wdXQsXHJcbiAgICBPdXRwdXQsXHJcbiAgICBFdmVudEVtaXR0ZXIsXHJcbiAgICBWaWV3RW5jYXBzdWxhdGlvbixcclxuICAgIE9uSW5pdCxcclxuICAgIFZpZXdDaGlsZFxyXG59IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xyXG5pbXBvcnQgeyBLZFZpZXcgfSBmcm9tICcuLi9rZC1hbmd1bGFyLXZpZXcvaW5kZXgnO1xyXG5cclxuQENvbXBvbmVudCh7XHJcbiAgICBzZWxlY3RvcjogJ2tkLWRlbGV0ZScsXHJcbiAgICB0ZW1wbGF0ZTogYDxrZC12aWV3IGRpc3BsYXlUeXBlPSdmb3JtJyBbaW5wdXREYXRhXT0nX3F1ZXN0aW9uRGF0YScgW2J1dHRvbl09J19kZWZhdWx0QnRuJyAoYnV0dG9uRXZlbnQpPSdidG5DbGljaygkZXZlbnQpJyAoc3VibWl0RXZlbnQpPSdzdWJtaXRDbGljaygkZXZlbnQpJz48L2tkLXZpZXc+YCxcclxuICAgIGVuY2Fwc3VsYXRpb246IFZpZXdFbmNhcHN1bGF0aW9uLk5vbmVcclxufSlcclxuXHJcbmV4cG9ydCBjbGFzcyBLZERlbGV0ZSBpbXBsZW1lbnRzIE9uSW5pdCB7XHJcbiAgICBwdWJsaWMgX3F1ZXN0aW9uRGF0YTogQXJyYXk8YW55PiA9IFtdO1xyXG4gICAgcHVibGljIF9kZWZhdWx0QnRuOiBBcnJheTxhbnk+ID0gW3tcclxuICAgICAgICB0eXBlOiAnc3VibWl0JyxcclxuICAgICAgICBuYW1lOiAnRGVsZXRlJyxcclxuICAgICAgICBpY29uOiAna2QtdHJhc2gnLFxyXG4gICAgICAgIGNsYXNzOiAnYnRuLXRleHQnLFxyXG4gICAgICAgIGRpc2FibGVkOiBmYWxzZVxyXG4gICAgfSwge1xyXG4gICAgICAgIHR5cGU6ICdjYW5jZWwnLFxyXG4gICAgICAgIG5hbWU6ICdDYW5jZWwnLFxyXG4gICAgICAgIGNsYXNzOiAnYnRuLW91dGxpbmUnLFxyXG4gICAgICAgIGljb246ICdrZC1jcm9zcycsXHJcbiAgICAgICAgZGlzYWJsZWQ6IGZhbHNlXHJcbiAgICB9XTtcclxuXHJcbiAgICBwcml2YXRlIF9zZWN0aW9uSGVhZGVyOiBhbnkgPSB7XHJcbiAgICAgICAga2V5OiAnU2VjdGlvbkhlYWRlcicsXHJcbiAgICAgICAgbGFiZWw6ICdBcmUgeW91IHN1cmUgeW91IHdhbnQgdG8gZGVsZXRlIHRoaXM/JyxcclxuICAgICAgICBjb250cm9sVHlwZTogJ3NlY3Rpb24nLFxyXG4gICAgICAgIHZpc2libGU6IHRydWUsXHJcbiAgICAgICAgcmVxdWlyZWQ6IGZhbHNlXHJcbiAgICB9O1xyXG5cclxuICAgIEBJbnB1dCgpIHF1ZXN0aW9uOiBBcnJheTxhbnk+O1xyXG4gICAgQE91dHB1dCgpIGJ1dHRvbkNhbmNlbEV2ZW50OiBFdmVudEVtaXR0ZXI8YW55PiA9IG5ldyBFdmVudEVtaXR0ZXIoKTtcclxuICAgIEBPdXRwdXQoKSBidXR0b25EZWxldGVFdmVudDogRXZlbnRFbWl0dGVyPGFueT4gPSBuZXcgRXZlbnRFbWl0dGVyKCk7XHJcbiAgICBAVmlld0NoaWxkKEtkVmlldywgeyBzdGF0aWM6IHRydWUgfSkga2RWaWV3Q29tcG9uZW50OiBLZFZpZXc7XHJcblxyXG4gICAgbmdPbkluaXQoKTogdm9pZCB7XHJcbiAgICAgICAgaWYgKHR5cGVvZiB0aGlzLnF1ZXN0aW9uICE9PSAndW5kZWZpbmVkJyAmJiB0aGlzLnF1ZXN0aW9uLmxlbmd0aCA+IDApIHRoaXMuX3F1ZXN0aW9uRGF0YSA9IHRoaXMucXVlc3Rpb247XHJcbiAgICAgICAgdGhpcy5fcXVlc3Rpb25EYXRhLnVuc2hpZnQodGhpcy5fc2VjdGlvbkhlYWRlcik7XHJcbiAgICB9XHJcblxyXG4gICAgYnRuQ2xpY2soX2J1dHRvbjogYW55KTogdm9pZCB7XHJcbiAgICAgICAgdGhpcy5idXR0b25DYW5jZWxFdmVudC5lbWl0KCk7XHJcbiAgICB9XHJcblxyXG4gICAgc3VibWl0Q2xpY2soX2Zvcm1WYWw6IGFueSk6IHZvaWQge1xyXG4gICAgICAgIHRoaXMuYnV0dG9uRGVsZXRlRXZlbnQuZW1pdChfZm9ybVZhbCk7XHJcbiAgICB9XHJcblxyXG4gICAgcHVibGljIHNldERlbGV0ZURpc2FibGVkKF90b0Rpc2FibGU6IGJvb2xlYW4pOiB2b2lkIHtcclxuICAgICAgICB0aGlzLmtkVmlld0NvbXBvbmVudC5zZXRCdXR0b25EaXNhYmxlZCgnc3VibWl0JywgX3RvRGlzYWJsZSk7XHJcbiAgICB9XHJcbn1cclxuIl19