import { Component, Input, ViewContainerRef, Renderer2 } from '@angular/core';
import { Router } from '@angular/router';
import { KdSplitterEvent } from '../kd-angular-splitter/index';
import { KdHeaderSvc } from './kd-angular-header-svc';
import { KdDataSvc } from '../kd-common/index';
export class KdHeader {
    constructor(_vcr, _router, _renderer, _kdsplitterEvent, _headerSvc, _dataSvc) {
        this._vcr = _vcr;
        this._router = _router;
        this._renderer = _renderer;
        this._kdsplitterEvent = _kdsplitterEvent;
        this._headerSvc = _headerSvc;
        this._dataSvc = _dataSvc;
        this._elem = _vcr.element;
    }
    ngOnInit() {
        this._initApi();
    }
    ngOnChanges(_simpleChanges) {
        this._setupHeaderConfig();
    }
    onClickHambugerMenu() {
        // console.log('open menu');
        this._kdsplitterEvent.fire('');
    }
    onClickLogo() {
        if ((typeof this.header.brandLogo.path !== 'undefined') && (typeof this.header.brandLogo.url === 'undefined')) {
            this._router.navigate([this.header.brandLogo.path]);
        }
        else if ((typeof this.header.brandLogo.url !== 'undefined') && (typeof this.header.brandLogo.path === 'undefined')) {
            window.open(this.header.brandLogo.url, this.header.brandLogo.target);
        }
        else if ((typeof this.header.brandLogo.path !== 'undefined') && (typeof this.header.brandLogo.url !== 'undefined')) {
            this._router.navigate([this.header.brandLogo.path]);
            this.header.brandLogo.url = null;
            this.header.brandLogo.target = null;
        }
    }
    onClickProfile() {
        if ((typeof this.header.userInfo.path !== 'undefined') && (typeof this.header.userInfo.url === 'undefined')) {
            this._router.navigate([this.header.userInfo.path]);
        }
        else if ((typeof this.header.userInfo.url !== 'undefined') && (typeof this.header.userInfo.path === 'undefined')) {
            window.open(this.header.userInfo.url, this.header.userInfo.target);
        }
        else if ((typeof this.header.userInfo.path !== 'undefined') && (typeof this.header.userInfo.url !== 'undefined')) {
            this._router.navigate([this.header.userInfo.path]);
            this.header.userInfo.url = null;
            this.header.userInfo.target = null;
        }
    }
    onClickHeaderButton(button) {
        if ((typeof button.callback === 'function')) {
            button.callback();
        }
        else if ((typeof button.path !== 'undefined') && (typeof button.url === 'undefined')) {
            this._router.navigate([button.path]);
        }
        else if ((typeof button.url !== 'undefined') && (typeof button.path === 'undefined')) {
            window.open(button.url, button.target);
        }
        else if ((typeof button.path !== 'undefined') && (typeof button.url !== 'undefined')) {
            this._router.navigate([this.header.userInfo.path]);
            button.url = null;
            button.target = null;
        }
    }
    onClickDropdownItem(item) {
        if ((typeof item.callback === 'function')) {
            item.callback();
        }
        else if ((typeof item.path !== 'undefined') && (typeof item.url === 'undefined')) {
            this._router.navigate([item.path]);
        }
        else if ((typeof item.url !== 'undefined') && (typeof item.path === 'undefined')) {
            window.open(item.url, item.target);
        }
        else if ((typeof item.path !== 'undefined') && (typeof item.url !== 'undefined')) {
            this._router.navigate([this.header.userInfo.path]);
            item.url = null;
            item.target = null;
        }
        if (typeof item.theme !== 'undefined') {
            __ngRendererSetElementAttributeHelper(this._renderer, this._elem.nativeElement.parentElement.parentElement.parentElement.offsetParent, 'class', item.theme);
        }
    }
    _initApi() {
        if (!this.api)
            return;
        this.api.setUserInfo = (_data) => {
            Object.assign(this.header.userInfo, _data);
            // this.cdr.detectChanges();
            if (typeof this.header.userInfo !== 'undefined' && typeof this.header.userInfo.imgSrc === 'undefined') {
                this.header.userInfo.imgType = 'icon';
                this.header.userInfo.imgSrc = 'kd-role';
            }
        };
        this.api.setGroupButton = (_index, _button) => {
            if (this.header.btnGroup.length > 0 && _index <= 2) {
                this.header.btnGroup[_index] = _button;
            }
        };
    }
    _setupHeaderConfig() {
        if (typeof this.config !== 'undefined') {
            let defaultHeader = this._headerSvc.getDefaultConfig();
            let tempHeader = this._dataSvc.deepMergeObject(defaultHeader, this.config);
            try {
                // will try to fetch APP_CONFIGS from the file.
                tempHeader.brandLogo = Object.assign(tempHeader.brandLogo, APP_CONFIGS.product);
            }
            catch (err) {
                // console.log(err);
            }
            if (typeof tempHeader.userInfo !== 'undefined' && typeof tempHeader.userInfo.imgSrc === 'undefined') {
                tempHeader.userInfo.imgType = 'icon';
                tempHeader.userInfo.imgSrc = 'kd-role';
            }
            this.header = tempHeader;
        }
    }
}
KdHeader.decorators = [
    { type: Component, args: [{
                selector: 'kd-header',
                template: "<nav class=\"kdx-navbar fixed-top\">\r\n    <div class=\"kdx-navbar-left\">\r\n        <div class=\"kdx-menu-handler\" (click)=\"onClickHambugerMenu()\">\r\n            <button class=\"kdx-menu-toggle\" type=\"button\">\r\n                <i class=\"fa fa-bars\"></i>\r\n            </button>\r\n        </div>\r\n        <div class=\"kdx-brand-logo\" (click)=\"onClickLogo()\">\r\n            <i *ngIf=\"header.brandLogo.type == 'icon'\" class=\"{{header.brandLogo.src}}\"></i>\r\n            <img *ngIf=\"header.brandLogo.type == 'image'\" src=\"{{header.brandLogo.src}}\" class=\"img-sm\">\r\n            <h1>{{header.brandLogo.name}}</h1>\r\n        </div>\r\n    </div>\r\n    <div class=\"kdx-navbar-right\">\r\n        <div class=\"kdx-header-navigation\">\r\n            <div class=\"kdx-username-wrapper\" ngbDropdown>\r\n                <a *ngIf=\"header.userInfo.showUser\" class=\"kdx-username\" ngbDropdownToggle>\r\n                    <span>{{header.userInfo.name}}</span>\r\n                    <div class=\"kdx-user-thumbnail\" *ngIf=\"header.userInfo.imgType == 'icon'\">\r\n                        <i class=\"{{header.userInfo.imgSrc}}\"></i>\r\n                    </div>\r\n                    <div class=\"kdx-user-thumbnail\" *ngIf=\"header.userInfo.imgType == 'image'\">\r\n                        <img src=\"{{header.userInfo.imgSrc}}\">\r\n                    </div>\r\n                </a>\r\n                <div ngbDropdownMenu class=\"dropdown-menu kdx-user-profile\">\r\n                    <div class=\"dropdown-arrow\">\r\n                        <i class=\"fa fa-caret-up\"></i>\r\n                    </div>\r\n                    <div class=\"dropdown-item\">\r\n                        <div class=\"kdx-user-thumbnail\" *ngIf=\"header.userInfo.imgType == 'icon'\">\r\n                            <i class=\"{{header.userInfo.imgSrc}}\"></i>\r\n                        </div>\r\n                        <div class=\"kdx-user-thumbnail\" *ngIf=\"header.userInfo.imgType == 'image'\">\r\n                            <img src=\"{{header.userInfo.imgSrc}}\">\r\n                        </div>\r\n                        <ul>\r\n                            <li><b>{{header.userInfo.name}}</b></li>\r\n                            <li>{{header.userInfo.role}}</li>\r\n                        </ul>\r\n                        <a class=\"btn\" *ngIf=\"header.userInfo.url || header.userInfo.path\" (click)=\"onClickProfile()\">\r\n                            <i class=\"fa fa-cog\"></i>\r\n                            <span>My Account</span>\r\n                        </a>\r\n                    </div>\r\n                </div>\r\n            </div>\r\n            <div class=\"kdx-btn-group-wrapper\">\r\n                <div class=\"btn-group\" *ngFor=\"let button of header.btnGroup | slice:0:5;\" [ngSwitch]=\"button.dropdownType\">\r\n                    <div *ngIf=\"button.dropdownContent && button.dropdownContent.length > 0\">\r\n                        <!-- Grid -->\r\n                        <div *ngSwitchCase=\"'grid'\" class=\"kdx-grid-btn\" ngbDropdown>\r\n                            <a type=\"button\" class=\"btn kdx-dropdown-toggle\" ngbDropdownToggle>\r\n                                <i class=\"{{button.btnIcon}}\"></i>\r\n                            </a>\r\n                            <!-- Number of item inside grid dropdown -->\r\n                            <div *ngIf=\"button.dropdownContent\" ngbDropdownMenu class=\"dropdown-menu kdx-grid-layout\">\r\n                                <div class=\"dropdown-arrow\">\r\n                                    <i class=\"fa fa-caret-up\"></i>\r\n                                </div>\r\n                                <a class=\"dropdown-item kdx-grid-item\" *ngFor=\"let item of button.dropdownContent;\" (click)=\"onClickDropdownItem(item)\">\r\n                                    <i *ngIf=\"item.icon\" class=\"{{item.icon}}\"></i>\r\n                                    <img *ngIf=\"!item.icon\" src=\"{{item.imgSrc}}\">\r\n                                    <span>{{item.text}}</span>\r\n                                </a>\r\n                            </div>\r\n                        </div>\r\n                        <!-- List -->\r\n                        <div *ngSwitchCase=\"'list'\" class=\"kdx-list-btn\" ngbDropdown>\r\n                            <a type=\"button\" class=\"btn kdx-dropdown-toggle\" ngbDropdownToggle>\r\n                                <i class=\"{{button.btnIcon}}\"></i>\r\n                            </a>\r\n                            <!-- Number of item inside list dropdown -->\r\n                            <div *ngIf=\"button.dropdownContent\" ngbDropdownMenu ngFor=\"let item of button.dropdownContent;\" class=\"dropdown-menu kdx-list-layout\">\r\n                                <div class=\"dropdown-arrow\">\r\n                                    <i class=\"fa fa-caret-up\"></i>\r\n                                </div>\r\n                                <a class=\"dropdown-item kdx-list-item\" *ngFor=\"let item of button.dropdownContent;\" (click)=\"onClickDropdownItem(item)\">\r\n                                    <i class=\"{{item.icon}}\"></i>\r\n                                    <span>{{item.text}}</span>\r\n                                </a>\r\n                            </div>\r\n                        </div>\r\n                    </div>\r\n                    <!-- Default -->\r\n                    <div *ngSwitchDefault>\r\n                        <a class=\"btn\" (click)=\"onClickHeaderButton(button)\">\r\n                            <i class=\"{{button.btnIcon}}\"></i>\r\n                        </a>\r\n                    </div>\r\n                </div>\r\n            </div>\r\n        </div>\r\n    </div>\r\n</nav>\r\n<!-- <router-outlet></router-outlet> -->\r\n",
                providers: [KdHeaderSvc, KdDataSvc]
            },] }
];
KdHeader.ctorParameters = () => [
    { type: ViewContainerRef },
    { type: Router },
    { type: Renderer2 },
    { type: KdSplitterEvent },
    { type: KdHeaderSvc },
    { type: KdDataSvc }
];
KdHeader.propDecorators = {
    config: [{ type: Input }],
    api: [{ type: Input }]
};
function __ngRendererSplitNamespaceHelper(name) {
    if (name[0] === ":") {
        const match = name.match(/^:([^:]+):(.+)$/);
        return [match[1], match[2]];
    }
    return ["", name];
}
function __ngRendererSetElementAttributeHelper(renderer, element, namespaceAndName, value) {
    const [namespace, name] = __ngRendererSplitNamespaceHelper(namespaceAndName);
    if (value != null) {
        renderer.setAttribute(element, name, value, namespace);
    }
    else {
        renderer.removeAttribute(element, name, namespace);
    }
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoia2QtYW5ndWxhci1oZWFkZXIuanMiLCJzb3VyY2VSb290IjoiRDovb3BlbkVNSVMvc3R5bGVndWlkZS9pb3N0Zy1vcGVuZW1pcy1zdHlsZWd1aWRlL3Byb2plY3RzL29wZW5lbWlzLXN0eWxlZ3VpZGUtbGliL3NyYy8iLCJzb3VyY2VzIjpbImtkLWNvbXBvbmVudHMva2QtYW5ndWxhci1oZWFkZXIva2QtYW5ndWxhci1oZWFkZXIudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsT0FBTyxFQUFFLFNBQVMsRUFBRSxLQUFLLEVBQXFCLGdCQUFnQixFQUE2QixTQUFTLEVBQUUsTUFBTSxlQUFlLENBQUM7QUFFNUgsT0FBTyxFQUFFLE1BQU0sRUFBRSxNQUFNLGlCQUFpQixDQUFDO0FBQ3pDLE9BQU8sRUFBRSxlQUFlLEVBQUUsTUFBTSw4QkFBOEIsQ0FBQztBQUMvRCxPQUFPLEVBQUUsV0FBVyxFQUFFLE1BQU0seUJBQXlCLENBQUM7QUFDdEQsT0FBTyxFQUFFLFNBQVMsRUFBRSxNQUFNLG9CQUFvQixDQUFDO0FBZ0IvQyxNQUFNLE9BQU8sUUFBUTtJQU9qQixZQUNZLElBQXNCLEVBQ3RCLE9BQWUsRUFDZixTQUFvQixFQUNwQixnQkFBaUMsRUFDakMsVUFBdUIsRUFDdkIsUUFBbUI7UUFMbkIsU0FBSSxHQUFKLElBQUksQ0FBa0I7UUFDdEIsWUFBTyxHQUFQLE9BQU8sQ0FBUTtRQUNmLGNBQVMsR0FBVCxTQUFTLENBQVc7UUFDcEIscUJBQWdCLEdBQWhCLGdCQUFnQixDQUFpQjtRQUNqQyxlQUFVLEdBQVYsVUFBVSxDQUFhO1FBQ3ZCLGFBQVEsR0FBUixRQUFRLENBQVc7UUFFM0IsSUFBSSxDQUFDLEtBQUssR0FBRyxJQUFJLENBQUMsT0FBTyxDQUFDO0lBQzlCLENBQUM7SUFFRCxRQUFRO1FBQ0osSUFBSSxDQUFDLFFBQVEsRUFBRSxDQUFDO0lBQ3BCLENBQUM7SUFFRCxXQUFXLENBQUMsY0FBNkI7UUFDckMsSUFBSSxDQUFDLGtCQUFrQixFQUFFLENBQUM7SUFDOUIsQ0FBQztJQUVNLG1CQUFtQjtRQUN0Qiw0QkFBNEI7UUFDNUIsSUFBSSxDQUFDLGdCQUFnQixDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsQ0FBQztJQUNuQyxDQUFDO0lBRU0sV0FBVztRQUNkLElBQUksQ0FBQyxPQUFPLElBQUksQ0FBQyxNQUFNLENBQUMsU0FBUyxDQUFDLElBQUksS0FBSyxXQUFXLENBQUMsSUFBSSxDQUFDLE9BQU8sSUFBSSxDQUFDLE1BQU0sQ0FBQyxTQUFTLENBQUMsR0FBRyxLQUFLLFdBQVcsQ0FBQyxFQUFFO1lBQzNHLElBQUksQ0FBQyxPQUFPLENBQUMsUUFBUSxDQUFDLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQztTQUN2RDthQUVJLElBQUksQ0FBQyxPQUFPLElBQUksQ0FBQyxNQUFNLENBQUMsU0FBUyxDQUFDLEdBQUcsS0FBSyxXQUFXLENBQUMsSUFBSSxDQUFDLE9BQU8sSUFBSSxDQUFDLE1BQU0sQ0FBQyxTQUFTLENBQUMsSUFBSSxLQUFLLFdBQVcsQ0FBQyxFQUFFO1lBQ2hILE1BQU0sQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxTQUFTLENBQUMsR0FBRyxFQUFFLElBQUksQ0FBQyxNQUFNLENBQUMsU0FBUyxDQUFDLE1BQU0sQ0FBQyxDQUFDO1NBQ3hFO2FBRUksSUFBSSxDQUFDLE9BQU8sSUFBSSxDQUFDLE1BQU0sQ0FBQyxTQUFTLENBQUMsSUFBSSxLQUFLLFdBQVcsQ0FBQyxJQUFJLENBQUMsT0FBTyxJQUFJLENBQUMsTUFBTSxDQUFDLFNBQVMsQ0FBQyxHQUFHLEtBQUssV0FBVyxDQUFDLEVBQUU7WUFDaEgsSUFBSSxDQUFDLE9BQU8sQ0FBQyxRQUFRLENBQUMsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDO1lBQ3BELElBQUksQ0FBQyxNQUFNLENBQUMsU0FBUyxDQUFDLEdBQUcsR0FBRyxJQUFJLENBQUM7WUFDakMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxTQUFTLENBQUMsTUFBTSxHQUFHLElBQUksQ0FBQztTQUN2QztJQUNMLENBQUM7SUFFTSxjQUFjO1FBQ2pCLElBQUksQ0FBQyxPQUFPLElBQUksQ0FBQyxNQUFNLENBQUMsUUFBUSxDQUFDLElBQUksS0FBSyxXQUFXLENBQUMsSUFBSSxDQUFDLE9BQU8sSUFBSSxDQUFDLE1BQU0sQ0FBQyxRQUFRLENBQUMsR0FBRyxLQUFLLFdBQVcsQ0FBQyxFQUFFO1lBQ3pHLElBQUksQ0FBQyxPQUFPLENBQUMsUUFBUSxDQUFDLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQztTQUN0RDthQUVJLElBQUksQ0FBQyxPQUFPLElBQUksQ0FBQyxNQUFNLENBQUMsUUFBUSxDQUFDLEdBQUcsS0FBSyxXQUFXLENBQUMsSUFBSSxDQUFDLE9BQU8sSUFBSSxDQUFDLE1BQU0sQ0FBQyxRQUFRLENBQUMsSUFBSSxLQUFLLFdBQVcsQ0FBQyxFQUFFO1lBQzlHLE1BQU0sQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxRQUFRLENBQUMsR0FBRyxFQUFFLElBQUksQ0FBQyxNQUFNLENBQUMsUUFBUSxDQUFDLE1BQU0sQ0FBQyxDQUFDO1NBQ3RFO2FBRUksSUFBSSxDQUFDLE9BQU8sSUFBSSxDQUFDLE1BQU0sQ0FBQyxRQUFRLENBQUMsSUFBSSxLQUFLLFdBQVcsQ0FBQyxJQUFJLENBQUMsT0FBTyxJQUFJLENBQUMsTUFBTSxDQUFDLFFBQVEsQ0FBQyxHQUFHLEtBQUssV0FBVyxDQUFDLEVBQUU7WUFDOUcsSUFBSSxDQUFDLE9BQU8sQ0FBQyxRQUFRLENBQUMsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDO1lBQ25ELElBQUksQ0FBQyxNQUFNLENBQUMsUUFBUSxDQUFDLEdBQUcsR0FBRyxJQUFJLENBQUM7WUFDaEMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxRQUFRLENBQUMsTUFBTSxHQUFHLElBQUksQ0FBQztTQUN0QztJQUNMLENBQUM7SUFFTSxtQkFBbUIsQ0FBQyxNQUFXO1FBQ2xDLElBQUksQ0FBQyxPQUFPLE1BQU0sQ0FBQyxRQUFRLEtBQUssVUFBVSxDQUFDLEVBQUU7WUFDekMsTUFBTSxDQUFDLFFBQVEsRUFBRSxDQUFDO1NBQ3JCO2FBQ0ksSUFBSSxDQUFDLE9BQU8sTUFBTSxDQUFDLElBQUksS0FBSyxXQUFXLENBQUMsSUFBSSxDQUFDLE9BQU8sTUFBTSxDQUFDLEdBQUcsS0FBSyxXQUFXLENBQUMsRUFBRTtZQUNsRixJQUFJLENBQUMsT0FBTyxDQUFDLFFBQVEsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDO1NBQ3hDO2FBRUksSUFBSSxDQUFDLE9BQU8sTUFBTSxDQUFDLEdBQUcsS0FBSyxXQUFXLENBQUMsSUFBSSxDQUFDLE9BQU8sTUFBTSxDQUFDLElBQUksS0FBSyxXQUFXLENBQUMsRUFBRTtZQUNsRixNQUFNLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxHQUFHLEVBQUUsTUFBTSxDQUFDLE1BQU0sQ0FBQyxDQUFDO1NBQzFDO2FBRUksSUFBSSxDQUFDLE9BQU8sTUFBTSxDQUFDLElBQUksS0FBSyxXQUFXLENBQUMsSUFBSSxDQUFDLE9BQU8sTUFBTSxDQUFDLEdBQUcsS0FBSyxXQUFXLENBQUMsRUFBRTtZQUNsRixJQUFJLENBQUMsT0FBTyxDQUFDLFFBQVEsQ0FBQyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUM7WUFDbkQsTUFBTSxDQUFDLEdBQUcsR0FBRyxJQUFJLENBQUM7WUFDbEIsTUFBTSxDQUFDLE1BQU0sR0FBRyxJQUFJLENBQUM7U0FDeEI7SUFDTCxDQUFDO0lBRU0sbUJBQW1CLENBQUMsSUFBUztRQUNoQyxJQUFJLENBQUMsT0FBTyxJQUFJLENBQUMsUUFBUSxLQUFLLFVBQVUsQ0FBQyxFQUFFO1lBQ3ZDLElBQUksQ0FBQyxRQUFRLEVBQUUsQ0FBQztTQUNuQjthQUFNLElBQUksQ0FBQyxPQUFPLElBQUksQ0FBQyxJQUFJLEtBQUssV0FBVyxDQUFDLElBQUksQ0FBQyxPQUFPLElBQUksQ0FBQyxHQUFHLEtBQUssV0FBVyxDQUFDLEVBQUU7WUFDaEYsSUFBSSxDQUFDLE9BQU8sQ0FBQyxRQUFRLENBQUMsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQztTQUN0QzthQUVJLElBQUksQ0FBQyxPQUFPLElBQUksQ0FBQyxHQUFHLEtBQUssV0FBVyxDQUFDLElBQUksQ0FBQyxPQUFPLElBQUksQ0FBQyxJQUFJLEtBQUssV0FBVyxDQUFDLEVBQUU7WUFDOUUsTUFBTSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsR0FBRyxFQUFFLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQztTQUN0QzthQUVJLElBQUksQ0FBQyxPQUFPLElBQUksQ0FBQyxJQUFJLEtBQUssV0FBVyxDQUFDLElBQUksQ0FBQyxPQUFPLElBQUksQ0FBQyxHQUFHLEtBQUssV0FBVyxDQUFDLEVBQUU7WUFDOUUsSUFBSSxDQUFDLE9BQU8sQ0FBQyxRQUFRLENBQUMsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDO1lBQ25ELElBQUksQ0FBQyxHQUFHLEdBQUcsSUFBSSxDQUFDO1lBQ2hCLElBQUksQ0FBQyxNQUFNLEdBQUcsSUFBSSxDQUFDO1NBQ3RCO1FBRUQsSUFBSSxPQUFPLElBQUksQ0FBQyxLQUFLLEtBQUssV0FBVyxFQUFFO1lBQ25DLHFDQUFxQyxDQUFDLElBQUksQ0FBQyxTQUFTLEVBQUUsSUFBSSxDQUFDLEtBQUssQ0FBQyxhQUFhLENBQUMsYUFBYSxDQUFDLGFBQWEsQ0FBQyxhQUFhLENBQUMsWUFBWSxFQUFFLE9BQU8sRUFBRSxJQUFJLENBQUMsS0FBSyxDQUFDLENBQUM7U0FDL0o7SUFDTCxDQUFDO0lBRU8sUUFBUTtRQUNaLElBQUksQ0FBQyxJQUFJLENBQUMsR0FBRztZQUFFLE9BQU87UUFFdEIsSUFBSSxDQUFDLEdBQUcsQ0FBQyxXQUFXLEdBQUcsQ0FBQyxLQUFzQixFQUFRLEVBQUU7WUFDOUMsTUFBTyxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLFFBQVEsRUFBRSxLQUFLLENBQUMsQ0FBQztZQUNsRCw0QkFBNEI7WUFFNUIsSUFBSSxPQUFPLElBQUksQ0FBQyxNQUFNLENBQUMsUUFBUSxLQUFLLFdBQVcsSUFBSSxPQUFPLElBQUksQ0FBQyxNQUFNLENBQUMsUUFBUSxDQUFDLE1BQU0sS0FBSyxXQUFXLEVBQUU7Z0JBQ25HLElBQUksQ0FBQyxNQUFNLENBQUMsUUFBUSxDQUFDLE9BQU8sR0FBRyxNQUFNLENBQUM7Z0JBQ3RDLElBQUksQ0FBQyxNQUFNLENBQUMsUUFBUSxDQUFDLE1BQU0sR0FBRyxTQUFTLENBQUM7YUFDM0M7UUFDTCxDQUFDLENBQUM7UUFFRixJQUFJLENBQUMsR0FBRyxDQUFDLGNBQWMsR0FBRyxDQUFDLE1BQWMsRUFBRSxPQUFzQixFQUFRLEVBQUU7WUFDdkUsSUFBSSxJQUFJLENBQUMsTUFBTSxDQUFDLFFBQVEsQ0FBQyxNQUFNLEdBQUcsQ0FBQyxJQUFJLE1BQU0sSUFBSSxDQUFDLEVBQUU7Z0JBQ2hELElBQUksQ0FBQyxNQUFNLENBQUMsUUFBUSxDQUFDLE1BQU0sQ0FBQyxHQUFHLE9BQU8sQ0FBQzthQUMxQztRQUNMLENBQUMsQ0FBQztJQUNOLENBQUM7SUFFTyxrQkFBa0I7UUFDdEIsSUFBSSxPQUFPLElBQUksQ0FBQyxNQUFNLEtBQUssV0FBVyxFQUFFO1lBQ3BDLElBQUksYUFBYSxHQUFrQixJQUFJLENBQUMsVUFBVSxDQUFDLGdCQUFnQixFQUFFLENBQUM7WUFDdEUsSUFBSSxVQUFVLEdBQWtCLElBQUksQ0FBQyxRQUFRLENBQUMsZUFBZSxDQUFDLGFBQWEsRUFBRSxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUM7WUFFMUYsSUFBSTtnQkFDQSwrQ0FBK0M7Z0JBQy9DLFVBQVUsQ0FBQyxTQUFTLEdBQVMsTUFBTyxDQUFDLE1BQU0sQ0FBQyxVQUFVLENBQUMsU0FBUyxFQUFFLFdBQVcsQ0FBQyxPQUFPLENBQUMsQ0FBQzthQUMxRjtZQUFDLE9BQU8sR0FBRyxFQUFFO2dCQUNWLG9CQUFvQjthQUN2QjtZQUVELElBQUksT0FBTyxVQUFVLENBQUMsUUFBUSxLQUFLLFdBQVcsSUFBSSxPQUFPLFVBQVUsQ0FBQyxRQUFRLENBQUMsTUFBTSxLQUFLLFdBQVcsRUFBRTtnQkFDakcsVUFBVSxDQUFDLFFBQVEsQ0FBQyxPQUFPLEdBQUcsTUFBTSxDQUFDO2dCQUNyQyxVQUFVLENBQUMsUUFBUSxDQUFDLE1BQU0sR0FBRyxTQUFTLENBQUM7YUFDMUM7WUFFRCxJQUFJLENBQUMsTUFBTSxHQUFHLFVBQVUsQ0FBQztTQUM1QjtJQUNMLENBQUM7OztZQXJKSixTQUFTLFNBQUM7Z0JBQ1AsUUFBUSxFQUFFLFdBQVc7Z0JBQ3JCLHF2TEFBdUM7Z0JBQ3ZDLFNBQVMsRUFBRSxDQUFDLFdBQVcsRUFBRSxTQUFTLENBQUM7YUFDdEM7OztZQW5CNkMsZ0JBQWdCO1lBRXJELE1BQU07WUFGNEUsU0FBUztZQUczRixlQUFlO1lBQ2YsV0FBVztZQUNYLFNBQVM7OztxQkFpQmIsS0FBSztrQkFDTCxLQUFLOztBQWtKVixTQUFTLGdDQUFnQyxDQUFDLElBQWdDO0lBQ3RFLElBQUksSUFBSSxDQUFDLENBQUMsQ0FBQyxLQUFLLEdBQUcsRUFBRTtRQUNqQixNQUFNLEtBQUssR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDLGlCQUFpQixDQUFDLENBQUM7UUFDNUMsT0FBTyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsRUFBRSxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztLQUMvQjtJQUNELE9BQU8sQ0FBQyxFQUFFLEVBQUUsSUFBSSxDQUFDLENBQUM7QUFDdEIsQ0FBQztBQUVELFNBQVMscUNBQXFDLENBQUMsUUFBb0MsRUFBRSxPQUFtQyxFQUFFLGdCQUE0QyxFQUFFLEtBQWtDO0lBQ3RNLE1BQU0sQ0FBQyxTQUFTLEVBQUUsSUFBSSxDQUFDLEdBQUcsZ0NBQWdDLENBQUMsZ0JBQWdCLENBQUMsQ0FBQztJQUM3RSxJQUFJLEtBQUssSUFBSSxJQUFJLEVBQUU7UUFDZixRQUFRLENBQUMsWUFBWSxDQUFDLE9BQU8sRUFBRSxJQUFJLEVBQUUsS0FBSyxFQUFFLFNBQVMsQ0FBQyxDQUFDO0tBQzFEO1NBQ0k7UUFDRCxRQUFRLENBQUMsZUFBZSxDQUFDLE9BQU8sRUFBRSxJQUFJLEVBQUUsU0FBUyxDQUFDLENBQUM7S0FDdEQ7QUFDTCxDQUFDIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgQ29tcG9uZW50LCBJbnB1dCwgT25Jbml0LCBPbkNoYW5nZXMsIFZpZXdDb250YWluZXJSZWYsIEVsZW1lbnRSZWYsIFNpbXBsZUNoYW5nZXMsIFJlbmRlcmVyMiB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xyXG5cclxuaW1wb3J0IHsgUm91dGVyIH0gZnJvbSAnQGFuZ3VsYXIvcm91dGVyJztcclxuaW1wb3J0IHsgS2RTcGxpdHRlckV2ZW50IH0gZnJvbSAnLi4va2QtYW5ndWxhci1zcGxpdHRlci9pbmRleCc7XHJcbmltcG9ydCB7IEtkSGVhZGVyU3ZjIH0gZnJvbSAnLi9rZC1hbmd1bGFyLWhlYWRlci1zdmMnO1xyXG5pbXBvcnQgeyBLZERhdGFTdmMgfSBmcm9tICcuLi9rZC1jb21tb24vaW5kZXgnO1xyXG5pbXBvcnQge1xyXG4gICAgSUhlYWRlckNvbmZpZyxcclxuICAgIElIZWFkZXJVc2VySW5mbyxcclxuICAgIElIZWFkZXJCdXR0b24sXHJcbiAgICAvLyBJSGVhZGVyQnJhbmRMb2dvXHJcbn0gZnJvbSAnLi9rZC1hbmd1bGFyLWhlYWRlci1pbnRlcmZhY2UnO1xyXG5cclxuZGVjbGFyZSBsZXQgQVBQX0NPTkZJR1M6IGFueTtcclxuXHJcbkBDb21wb25lbnQoe1xyXG4gICAgc2VsZWN0b3I6ICdrZC1oZWFkZXInLFxyXG4gICAgdGVtcGxhdGVVcmw6ICcuL2tkLWFuZ3VsYXItaGVhZGVyLmh0bWwnLFxyXG4gICAgcHJvdmlkZXJzOiBbS2RIZWFkZXJTdmMsIEtkRGF0YVN2Y11cclxufSlcclxuXHJcbmV4cG9ydCBjbGFzcyBLZEhlYWRlciBpbXBsZW1lbnRzIE9uSW5pdCwgT25DaGFuZ2VzIHtcclxuICAgIEBJbnB1dCgpIGNvbmZpZzogYW55O1xyXG4gICAgQElucHV0KCkgYXBpOiBhbnk7XHJcblxyXG4gICAgcHVibGljIGhlYWRlcjogSUhlYWRlckNvbmZpZztcclxuICAgIHByaXZhdGUgX2VsZW06IEVsZW1lbnRSZWY7XHJcblxyXG4gICAgY29uc3RydWN0b3IoXHJcbiAgICAgICAgcHJpdmF0ZSBfdmNyOiBWaWV3Q29udGFpbmVyUmVmLFxyXG4gICAgICAgIHByaXZhdGUgX3JvdXRlcjogUm91dGVyLFxyXG4gICAgICAgIHByaXZhdGUgX3JlbmRlcmVyOiBSZW5kZXJlcjIsXHJcbiAgICAgICAgcHJpdmF0ZSBfa2RzcGxpdHRlckV2ZW50OiBLZFNwbGl0dGVyRXZlbnQsXHJcbiAgICAgICAgcHJpdmF0ZSBfaGVhZGVyU3ZjOiBLZEhlYWRlclN2YyxcclxuICAgICAgICBwcml2YXRlIF9kYXRhU3ZjOiBLZERhdGFTdmMsXHJcbiAgICApIHtcclxuICAgICAgICB0aGlzLl9lbGVtID0gX3Zjci5lbGVtZW50O1xyXG4gICAgfVxyXG5cclxuICAgIG5nT25Jbml0KCk6IHZvaWQge1xyXG4gICAgICAgIHRoaXMuX2luaXRBcGkoKTtcclxuICAgIH1cclxuXHJcbiAgICBuZ09uQ2hhbmdlcyhfc2ltcGxlQ2hhbmdlczogU2ltcGxlQ2hhbmdlcyk6IHZvaWQge1xyXG4gICAgICAgIHRoaXMuX3NldHVwSGVhZGVyQ29uZmlnKCk7XHJcbiAgICB9XHJcblxyXG4gICAgcHVibGljIG9uQ2xpY2tIYW1idWdlck1lbnUoKTogdm9pZCB7XHJcbiAgICAgICAgLy8gY29uc29sZS5sb2coJ29wZW4gbWVudScpO1xyXG4gICAgICAgIHRoaXMuX2tkc3BsaXR0ZXJFdmVudC5maXJlKCcnKTtcclxuICAgIH1cclxuXHJcbiAgICBwdWJsaWMgb25DbGlja0xvZ28oKTogdm9pZCB7XHJcbiAgICAgICAgaWYgKCh0eXBlb2YgdGhpcy5oZWFkZXIuYnJhbmRMb2dvLnBhdGggIT09ICd1bmRlZmluZWQnKSAmJiAodHlwZW9mIHRoaXMuaGVhZGVyLmJyYW5kTG9nby51cmwgPT09ICd1bmRlZmluZWQnKSkge1xyXG4gICAgICAgICAgICB0aGlzLl9yb3V0ZXIubmF2aWdhdGUoW3RoaXMuaGVhZGVyLmJyYW5kTG9nby5wYXRoXSk7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICBlbHNlIGlmICgodHlwZW9mIHRoaXMuaGVhZGVyLmJyYW5kTG9nby51cmwgIT09ICd1bmRlZmluZWQnKSAmJiAodHlwZW9mIHRoaXMuaGVhZGVyLmJyYW5kTG9nby5wYXRoID09PSAndW5kZWZpbmVkJykpIHtcclxuICAgICAgICAgICAgd2luZG93Lm9wZW4odGhpcy5oZWFkZXIuYnJhbmRMb2dvLnVybCwgdGhpcy5oZWFkZXIuYnJhbmRMb2dvLnRhcmdldCk7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICBlbHNlIGlmICgodHlwZW9mIHRoaXMuaGVhZGVyLmJyYW5kTG9nby5wYXRoICE9PSAndW5kZWZpbmVkJykgJiYgKHR5cGVvZiB0aGlzLmhlYWRlci5icmFuZExvZ28udXJsICE9PSAndW5kZWZpbmVkJykpIHtcclxuICAgICAgICAgICAgdGhpcy5fcm91dGVyLm5hdmlnYXRlKFt0aGlzLmhlYWRlci5icmFuZExvZ28ucGF0aF0pO1xyXG4gICAgICAgICAgICB0aGlzLmhlYWRlci5icmFuZExvZ28udXJsID0gbnVsbDtcclxuICAgICAgICAgICAgdGhpcy5oZWFkZXIuYnJhbmRMb2dvLnRhcmdldCA9IG51bGw7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIHB1YmxpYyBvbkNsaWNrUHJvZmlsZSgpOiB2b2lkIHtcclxuICAgICAgICBpZiAoKHR5cGVvZiB0aGlzLmhlYWRlci51c2VySW5mby5wYXRoICE9PSAndW5kZWZpbmVkJykgJiYgKHR5cGVvZiB0aGlzLmhlYWRlci51c2VySW5mby51cmwgPT09ICd1bmRlZmluZWQnKSkge1xyXG4gICAgICAgICAgICB0aGlzLl9yb3V0ZXIubmF2aWdhdGUoW3RoaXMuaGVhZGVyLnVzZXJJbmZvLnBhdGhdKTtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIGVsc2UgaWYgKCh0eXBlb2YgdGhpcy5oZWFkZXIudXNlckluZm8udXJsICE9PSAndW5kZWZpbmVkJykgJiYgKHR5cGVvZiB0aGlzLmhlYWRlci51c2VySW5mby5wYXRoID09PSAndW5kZWZpbmVkJykpIHtcclxuICAgICAgICAgICAgd2luZG93Lm9wZW4odGhpcy5oZWFkZXIudXNlckluZm8udXJsLCB0aGlzLmhlYWRlci51c2VySW5mby50YXJnZXQpO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgZWxzZSBpZiAoKHR5cGVvZiB0aGlzLmhlYWRlci51c2VySW5mby5wYXRoICE9PSAndW5kZWZpbmVkJykgJiYgKHR5cGVvZiB0aGlzLmhlYWRlci51c2VySW5mby51cmwgIT09ICd1bmRlZmluZWQnKSkge1xyXG4gICAgICAgICAgICB0aGlzLl9yb3V0ZXIubmF2aWdhdGUoW3RoaXMuaGVhZGVyLnVzZXJJbmZvLnBhdGhdKTtcclxuICAgICAgICAgICAgdGhpcy5oZWFkZXIudXNlckluZm8udXJsID0gbnVsbDtcclxuICAgICAgICAgICAgdGhpcy5oZWFkZXIudXNlckluZm8udGFyZ2V0ID0gbnVsbDtcclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgcHVibGljIG9uQ2xpY2tIZWFkZXJCdXR0b24oYnV0dG9uOiBhbnkpOiB2b2lkIHtcclxuICAgICAgICBpZiAoKHR5cGVvZiBidXR0b24uY2FsbGJhY2sgPT09ICdmdW5jdGlvbicpKSB7XHJcbiAgICAgICAgICAgIGJ1dHRvbi5jYWxsYmFjaygpO1xyXG4gICAgICAgIH1cclxuICAgICAgICBlbHNlIGlmICgodHlwZW9mIGJ1dHRvbi5wYXRoICE9PSAndW5kZWZpbmVkJykgJiYgKHR5cGVvZiBidXR0b24udXJsID09PSAndW5kZWZpbmVkJykpIHtcclxuICAgICAgICAgICAgdGhpcy5fcm91dGVyLm5hdmlnYXRlKFtidXR0b24ucGF0aF0pO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgZWxzZSBpZiAoKHR5cGVvZiBidXR0b24udXJsICE9PSAndW5kZWZpbmVkJykgJiYgKHR5cGVvZiBidXR0b24ucGF0aCA9PT0gJ3VuZGVmaW5lZCcpKSB7XHJcbiAgICAgICAgICAgIHdpbmRvdy5vcGVuKGJ1dHRvbi51cmwsIGJ1dHRvbi50YXJnZXQpO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgZWxzZSBpZiAoKHR5cGVvZiBidXR0b24ucGF0aCAhPT0gJ3VuZGVmaW5lZCcpICYmICh0eXBlb2YgYnV0dG9uLnVybCAhPT0gJ3VuZGVmaW5lZCcpKSB7XHJcbiAgICAgICAgICAgIHRoaXMuX3JvdXRlci5uYXZpZ2F0ZShbdGhpcy5oZWFkZXIudXNlckluZm8ucGF0aF0pO1xyXG4gICAgICAgICAgICBidXR0b24udXJsID0gbnVsbDtcclxuICAgICAgICAgICAgYnV0dG9uLnRhcmdldCA9IG51bGw7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIHB1YmxpYyBvbkNsaWNrRHJvcGRvd25JdGVtKGl0ZW06IGFueSk6IHZvaWQge1xyXG4gICAgICAgIGlmICgodHlwZW9mIGl0ZW0uY2FsbGJhY2sgPT09ICdmdW5jdGlvbicpKSB7XHJcbiAgICAgICAgICAgIGl0ZW0uY2FsbGJhY2soKTtcclxuICAgICAgICB9IGVsc2UgaWYgKCh0eXBlb2YgaXRlbS5wYXRoICE9PSAndW5kZWZpbmVkJykgJiYgKHR5cGVvZiBpdGVtLnVybCA9PT0gJ3VuZGVmaW5lZCcpKSB7XHJcbiAgICAgICAgICAgIHRoaXMuX3JvdXRlci5uYXZpZ2F0ZShbaXRlbS5wYXRoXSk7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICBlbHNlIGlmICgodHlwZW9mIGl0ZW0udXJsICE9PSAndW5kZWZpbmVkJykgJiYgKHR5cGVvZiBpdGVtLnBhdGggPT09ICd1bmRlZmluZWQnKSkge1xyXG4gICAgICAgICAgICB3aW5kb3cub3BlbihpdGVtLnVybCwgaXRlbS50YXJnZXQpO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgZWxzZSBpZiAoKHR5cGVvZiBpdGVtLnBhdGggIT09ICd1bmRlZmluZWQnKSAmJiAodHlwZW9mIGl0ZW0udXJsICE9PSAndW5kZWZpbmVkJykpIHtcclxuICAgICAgICAgICAgdGhpcy5fcm91dGVyLm5hdmlnYXRlKFt0aGlzLmhlYWRlci51c2VySW5mby5wYXRoXSk7XHJcbiAgICAgICAgICAgIGl0ZW0udXJsID0gbnVsbDtcclxuICAgICAgICAgICAgaXRlbS50YXJnZXQgPSBudWxsO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgaWYgKHR5cGVvZiBpdGVtLnRoZW1lICE9PSAndW5kZWZpbmVkJykge1xyXG4gICAgICAgICAgICBfX25nUmVuZGVyZXJTZXRFbGVtZW50QXR0cmlidXRlSGVscGVyKHRoaXMuX3JlbmRlcmVyLCB0aGlzLl9lbGVtLm5hdGl2ZUVsZW1lbnQucGFyZW50RWxlbWVudC5wYXJlbnRFbGVtZW50LnBhcmVudEVsZW1lbnQub2Zmc2V0UGFyZW50LCAnY2xhc3MnLCBpdGVtLnRoZW1lKTtcclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfaW5pdEFwaSgpIHtcclxuICAgICAgICBpZiAoIXRoaXMuYXBpKSByZXR1cm47XHJcblxyXG4gICAgICAgIHRoaXMuYXBpLnNldFVzZXJJbmZvID0gKF9kYXRhOiBJSGVhZGVyVXNlckluZm8pOiB2b2lkID0+IHtcclxuICAgICAgICAgICAgKDxhbnk+T2JqZWN0KS5hc3NpZ24odGhpcy5oZWFkZXIudXNlckluZm8sIF9kYXRhKTtcclxuICAgICAgICAgICAgLy8gdGhpcy5jZHIuZGV0ZWN0Q2hhbmdlcygpO1xyXG5cclxuICAgICAgICAgICAgaWYgKHR5cGVvZiB0aGlzLmhlYWRlci51c2VySW5mbyAhPT0gJ3VuZGVmaW5lZCcgJiYgdHlwZW9mIHRoaXMuaGVhZGVyLnVzZXJJbmZvLmltZ1NyYyA9PT0gJ3VuZGVmaW5lZCcpIHtcclxuICAgICAgICAgICAgICAgIHRoaXMuaGVhZGVyLnVzZXJJbmZvLmltZ1R5cGUgPSAnaWNvbic7XHJcbiAgICAgICAgICAgICAgICB0aGlzLmhlYWRlci51c2VySW5mby5pbWdTcmMgPSAna2Qtcm9sZSc7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9O1xyXG5cclxuICAgICAgICB0aGlzLmFwaS5zZXRHcm91cEJ1dHRvbiA9IChfaW5kZXg6IG51bWJlciwgX2J1dHRvbjogSUhlYWRlckJ1dHRvbik6IHZvaWQgPT4ge1xyXG4gICAgICAgICAgICBpZiAodGhpcy5oZWFkZXIuYnRuR3JvdXAubGVuZ3RoID4gMCAmJiBfaW5kZXggPD0gMikge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5oZWFkZXIuYnRuR3JvdXBbX2luZGV4XSA9IF9idXR0b247XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9O1xyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX3NldHVwSGVhZGVyQ29uZmlnKCk6IHZvaWQge1xyXG4gICAgICAgIGlmICh0eXBlb2YgdGhpcy5jb25maWcgIT09ICd1bmRlZmluZWQnKSB7XHJcbiAgICAgICAgICAgIGxldCBkZWZhdWx0SGVhZGVyOiBJSGVhZGVyQ29uZmlnID0gdGhpcy5faGVhZGVyU3ZjLmdldERlZmF1bHRDb25maWcoKTtcclxuICAgICAgICAgICAgbGV0IHRlbXBIZWFkZXI6IElIZWFkZXJDb25maWcgPSB0aGlzLl9kYXRhU3ZjLmRlZXBNZXJnZU9iamVjdChkZWZhdWx0SGVhZGVyLCB0aGlzLmNvbmZpZyk7XHJcblxyXG4gICAgICAgICAgICB0cnkge1xyXG4gICAgICAgICAgICAgICAgLy8gd2lsbCB0cnkgdG8gZmV0Y2ggQVBQX0NPTkZJR1MgZnJvbSB0aGUgZmlsZS5cclxuICAgICAgICAgICAgICAgIHRlbXBIZWFkZXIuYnJhbmRMb2dvID0gKDxhbnk+T2JqZWN0KS5hc3NpZ24odGVtcEhlYWRlci5icmFuZExvZ28sIEFQUF9DT05GSUdTLnByb2R1Y3QpO1xyXG4gICAgICAgICAgICB9IGNhdGNoIChlcnIpIHtcclxuICAgICAgICAgICAgICAgIC8vIGNvbnNvbGUubG9nKGVycik7XHJcbiAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgIGlmICh0eXBlb2YgdGVtcEhlYWRlci51c2VySW5mbyAhPT0gJ3VuZGVmaW5lZCcgJiYgdHlwZW9mIHRlbXBIZWFkZXIudXNlckluZm8uaW1nU3JjID09PSAndW5kZWZpbmVkJykge1xyXG4gICAgICAgICAgICAgICAgdGVtcEhlYWRlci51c2VySW5mby5pbWdUeXBlID0gJ2ljb24nO1xyXG4gICAgICAgICAgICAgICAgdGVtcEhlYWRlci51c2VySW5mby5pbWdTcmMgPSAna2Qtcm9sZSc7XHJcbiAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgIHRoaXMuaGVhZGVyID0gdGVtcEhlYWRlcjtcclxuICAgICAgICB9XHJcbiAgICB9XHJcbn1cclxuXHJcbnR5cGUgQW55RHVyaW5nUmVuZGVyZXJNaWdyYXRpb24gPSBhbnk7XHJcblxyXG5mdW5jdGlvbiBfX25nUmVuZGVyZXJTcGxpdE5hbWVzcGFjZUhlbHBlcihuYW1lOiBBbnlEdXJpbmdSZW5kZXJlck1pZ3JhdGlvbikge1xyXG4gICAgaWYgKG5hbWVbMF0gPT09IFwiOlwiKSB7XHJcbiAgICAgICAgY29uc3QgbWF0Y2ggPSBuYW1lLm1hdGNoKC9eOihbXjpdKyk6KC4rKSQvKTtcclxuICAgICAgICByZXR1cm4gW21hdGNoWzFdLCBtYXRjaFsyXV07XHJcbiAgICB9XHJcbiAgICByZXR1cm4gW1wiXCIsIG5hbWVdO1xyXG59XHJcblxyXG5mdW5jdGlvbiBfX25nUmVuZGVyZXJTZXRFbGVtZW50QXR0cmlidXRlSGVscGVyKHJlbmRlcmVyOiBBbnlEdXJpbmdSZW5kZXJlck1pZ3JhdGlvbiwgZWxlbWVudDogQW55RHVyaW5nUmVuZGVyZXJNaWdyYXRpb24sIG5hbWVzcGFjZUFuZE5hbWU6IEFueUR1cmluZ1JlbmRlcmVyTWlncmF0aW9uLCB2YWx1ZT86IEFueUR1cmluZ1JlbmRlcmVyTWlncmF0aW9uKSB7XHJcbiAgICBjb25zdCBbbmFtZXNwYWNlLCBuYW1lXSA9IF9fbmdSZW5kZXJlclNwbGl0TmFtZXNwYWNlSGVscGVyKG5hbWVzcGFjZUFuZE5hbWUpO1xyXG4gICAgaWYgKHZhbHVlICE9IG51bGwpIHtcclxuICAgICAgICByZW5kZXJlci5zZXRBdHRyaWJ1dGUoZWxlbWVudCwgbmFtZSwgdmFsdWUsIG5hbWVzcGFjZSk7XHJcbiAgICB9XHJcbiAgICBlbHNlIHtcclxuICAgICAgICByZW5kZXJlci5yZW1vdmVBdHRyaWJ1dGUoZWxlbWVudCwgbmFtZSwgbmFtZXNwYWNlKTtcclxuICAgIH1cclxufVxyXG4iXX0=