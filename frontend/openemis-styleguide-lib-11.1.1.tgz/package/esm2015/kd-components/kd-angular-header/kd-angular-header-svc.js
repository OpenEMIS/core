import { Injectable } from '@angular/core';
export class KdHeaderSvc {
    getDefaultConfig() {
        return {
            brandLogo: {
                //  prefix: 'OpenEMIS',
                name: 'OpenEMIS Styleguide',
                type: 'icon',
                src: 'kd-openemis'
            },
            userInfo: {
                showUser: true,
                name: '',
                imgType: 'icon',
                imgSrc: 'kd-role',
                role: ''
            },
            btnGroup: [{
                    btnIcon: 'fa fa-home fa-lg',
                    dropdownType: 'default'
                }, {
                    btnIcon: 'kd-grid',
                    dropdownType: 'grid',
                    dropdownContent: [{
                            icon: 'kd-openemis kd-analyzer',
                            text: 'Analyzer',
                            theme: 'openemis-analyzer'
                        }, {
                            icon: 'kd-openemis kd-community',
                            text: 'Community',
                            theme: 'openemis-community'
                        }, {
                            icon: 'kd-openemis kd-connect',
                            text: 'Connect',
                            theme: 'openemis-connect'
                        }, {
                            icon: 'kd-openemis kd-core',
                            text: 'Core',
                            theme: 'openemis-core'
                        }, {
                            icon: 'kd-openemis kd-datamanager',
                            text: 'DataManager',
                            theme: 'openemis-datamanager'
                        }, {
                            icon: 'kd-openemis kd-dashboard',
                            text: 'Dashboard',
                            theme: 'openemis-dashboard'
                        }, {
                            icon: 'kd-openemis kd-exams',
                            text: 'Exams',
                            theme: 'openemis-exams'
                        }, {
                            icon: 'kd-openemis kd-identity',
                            text: 'Identity',
                            theme: 'openemis-identity'
                        }, {
                            icon: 'kd-openemis kd-insight',
                            text: 'Insight',
                            theme: 'openemis-insight'
                        }, {
                            icon: 'kd-openemis kd-integrator',
                            text: 'Integrator',
                            theme: 'openemis-integrator'
                        }, {
                            icon: 'kd-openemis kd-learning',
                            text: 'Learning',
                            theme: 'openemis-learning'
                        }, {
                            icon: 'kd-openemis kd-logistics',
                            text: 'Logistics',
                            theme: 'openemis-logistics'
                        }, {
                            icon: 'kd-openemis kd-modelling',
                            text: 'Modelling',
                            theme: 'openemis-modelling'
                        }, {
                            icon: 'kd-openemis kd-monitoring',
                            text: 'Monitoring',
                            theme: 'openemis-monitoring'
                        }, {
                            icon: 'kd-openemis kd-school',
                            text: 'School',
                            theme: 'openemis-school'
                        },
                        {
                            icon: 'kd-openemis kd-styleguide',
                            text: 'Styleguide',
                            theme: 'openemis-styleguide'
                        }]
                }, {
                    btnIcon: 'kd-ellipsis',
                    dropdownType: 'list',
                    dropdownContent: [{
                            icon: 'fa fa-user',
                            text: 'About'
                        }, {
                            icon: 'fa fa-cog',
                            text: 'Preferences'
                        }, {
                            icon: 'fa fa-question-circle',
                            text: 'Help'
                        }, {
                            icon: 'fa fa-power-off',
                            text: 'Logout'
                        }]
                }]
        };
    }
}
KdHeaderSvc.decorators = [
    { type: Injectable }
];
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoia2QtYW5ndWxhci1oZWFkZXItc3ZjLmpzIiwic291cmNlUm9vdCI6IkQ6L29wZW5FTUlTL3N0eWxlZ3VpZGUvaW9zdGctb3BlbmVtaXMtc3R5bGVndWlkZS9wcm9qZWN0cy9vcGVuZW1pcy1zdHlsZWd1aWRlLWxpYi9zcmMvIiwic291cmNlcyI6WyJrZC1jb21wb25lbnRzL2tkLWFuZ3VsYXItaGVhZGVyL2tkLWFuZ3VsYXItaGVhZGVyLXN2Yy50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQSxPQUFPLEVBQUUsVUFBVSxFQUFFLE1BQU0sZUFBZSxDQUFDO0FBWTNDLE1BQU0sT0FBTyxXQUFXO0lBRWIsZ0JBQWdCO1FBQ25CLE9BQU87WUFDSCxTQUFTLEVBQUU7Z0JBQ1AsdUJBQXVCO2dCQUN2QixJQUFJLEVBQUUscUJBQXFCO2dCQUMzQixJQUFJLEVBQUUsTUFBTTtnQkFDWixHQUFHLEVBQUUsYUFBYTthQUNyQjtZQUNELFFBQVEsRUFBRTtnQkFDTixRQUFRLEVBQUUsSUFBSTtnQkFDZCxJQUFJLEVBQUUsRUFBRTtnQkFDUixPQUFPLEVBQUUsTUFBTTtnQkFDZixNQUFNLEVBQUUsU0FBUztnQkFDakIsSUFBSSxFQUFFLEVBQUU7YUFDWDtZQUNELFFBQVEsRUFBRSxDQUFDO29CQUNQLE9BQU8sRUFBRSxrQkFBa0I7b0JBQzNCLFlBQVksRUFBRSxTQUFTO2lCQUMxQixFQUFFO29CQUNDLE9BQU8sRUFBRSxTQUFTO29CQUNsQixZQUFZLEVBQUUsTUFBTTtvQkFDcEIsZUFBZSxFQUFFLENBQUM7NEJBQ2QsSUFBSSxFQUFFLHlCQUF5Qjs0QkFDL0IsSUFBSSxFQUFFLFVBQVU7NEJBQ2hCLEtBQUssRUFBRSxtQkFBbUI7eUJBQzdCLEVBQUU7NEJBQ0MsSUFBSSxFQUFFLDBCQUEwQjs0QkFDaEMsSUFBSSxFQUFFLFdBQVc7NEJBQ2pCLEtBQUssRUFBRSxvQkFBb0I7eUJBQzlCLEVBQUU7NEJBQ0MsSUFBSSxFQUFFLHdCQUF3Qjs0QkFDOUIsSUFBSSxFQUFFLFNBQVM7NEJBQ2YsS0FBSyxFQUFFLGtCQUFrQjt5QkFDNUIsRUFBRTs0QkFDQyxJQUFJLEVBQUUscUJBQXFCOzRCQUMzQixJQUFJLEVBQUUsTUFBTTs0QkFDWixLQUFLLEVBQUUsZUFBZTt5QkFDekIsRUFBRTs0QkFDQyxJQUFJLEVBQUUsNEJBQTRCOzRCQUNsQyxJQUFJLEVBQUUsYUFBYTs0QkFDbkIsS0FBSyxFQUFFLHNCQUFzQjt5QkFDaEMsRUFBRTs0QkFDQyxJQUFJLEVBQUUsMEJBQTBCOzRCQUNoQyxJQUFJLEVBQUUsV0FBVzs0QkFDakIsS0FBSyxFQUFFLG9CQUFvQjt5QkFDOUIsRUFBRTs0QkFDQyxJQUFJLEVBQUUsc0JBQXNCOzRCQUM1QixJQUFJLEVBQUUsT0FBTzs0QkFDYixLQUFLLEVBQUUsZ0JBQWdCO3lCQUMxQixFQUFFOzRCQUNDLElBQUksRUFBRSx5QkFBeUI7NEJBQy9CLElBQUksRUFBRSxVQUFVOzRCQUNoQixLQUFLLEVBQUUsbUJBQW1CO3lCQUM3QixFQUFFOzRCQUNDLElBQUksRUFBRSx3QkFBd0I7NEJBQzlCLElBQUksRUFBRSxTQUFTOzRCQUNmLEtBQUssRUFBRSxrQkFBa0I7eUJBQzVCLEVBQUU7NEJBQ0MsSUFBSSxFQUFFLDJCQUEyQjs0QkFDakMsSUFBSSxFQUFFLFlBQVk7NEJBQ2xCLEtBQUssRUFBRSxxQkFBcUI7eUJBQy9CLEVBQUU7NEJBQ0MsSUFBSSxFQUFFLHlCQUF5Qjs0QkFDL0IsSUFBSSxFQUFFLFVBQVU7NEJBQ2hCLEtBQUssRUFBRSxtQkFBbUI7eUJBQzdCLEVBQUU7NEJBQ0MsSUFBSSxFQUFFLDBCQUEwQjs0QkFDaEMsSUFBSSxFQUFFLFdBQVc7NEJBQ2pCLEtBQUssRUFBRSxvQkFBb0I7eUJBQzlCLEVBQUU7NEJBQ0MsSUFBSSxFQUFFLDBCQUEwQjs0QkFDaEMsSUFBSSxFQUFFLFdBQVc7NEJBQ2pCLEtBQUssRUFBRSxvQkFBb0I7eUJBQzlCLEVBQUU7NEJBQ0MsSUFBSSxFQUFFLDJCQUEyQjs0QkFDakMsSUFBSSxFQUFFLFlBQVk7NEJBQ2xCLEtBQUssRUFBRSxxQkFBcUI7eUJBQy9CLEVBQUU7NEJBQ0MsSUFBSSxFQUFFLHVCQUF1Qjs0QkFDN0IsSUFBSSxFQUFFLFFBQVE7NEJBQ2QsS0FBSyxFQUFFLGlCQUFpQjt5QkFDM0I7d0JBSUk7NEJBQ0QsSUFBSSxFQUFFLDJCQUEyQjs0QkFDakMsSUFBSSxFQUFFLFlBQVk7NEJBQ2xCLEtBQUssRUFBRSxxQkFBcUI7eUJBQy9CLENBQUM7aUJBQ0wsRUFBRTtvQkFDQyxPQUFPLEVBQUUsYUFBYTtvQkFDdEIsWUFBWSxFQUFFLE1BQU07b0JBQ3BCLGVBQWUsRUFBRSxDQUFDOzRCQUNkLElBQUksRUFBRSxZQUFZOzRCQUNsQixJQUFJLEVBQUUsT0FBTzt5QkFDaEIsRUFBRTs0QkFDQyxJQUFJLEVBQUUsV0FBVzs0QkFDakIsSUFBSSxFQUFFLGFBQWE7eUJBQ3RCLEVBQUU7NEJBQ0MsSUFBSSxFQUFFLHVCQUF1Qjs0QkFDN0IsSUFBSSxFQUFFLE1BQU07eUJBQ2YsRUFBRTs0QkFDQyxJQUFJLEVBQUUsaUJBQWlCOzRCQUN2QixJQUFJLEVBQUUsUUFBUTt5QkFDakIsQ0FBQztpQkFDTCxDQUFDO1NBQ0wsQ0FBQztJQUNOLENBQUM7OztZQS9HSixVQUFVIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgSW5qZWN0YWJsZSB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xyXG5pbXBvcnQge1xyXG4gICAgLy8gSUhlYWRlckJ1dHRvbixcclxuICAgIC8vIElIZWFkZXJCcmFuZExvZ28sXHJcbiAgICAvLyBJSGVhZGVyRHJvcGRvd25JdGVtLFxyXG4gICAgLy8gSUhlYWRlclVzZXJJbmZvLFxyXG4gICAgLy8gSUhlYWRlckFQSSxcclxuICAgIElIZWFkZXJDb25maWdcclxufSBmcm9tICcuL2tkLWFuZ3VsYXItaGVhZGVyLWludGVyZmFjZSc7XHJcblxyXG5cclxuQEluamVjdGFibGUoKVxyXG5leHBvcnQgY2xhc3MgS2RIZWFkZXJTdmMge1xyXG5cclxuICAgIHB1YmxpYyBnZXREZWZhdWx0Q29uZmlnKCk6IElIZWFkZXJDb25maWcge1xyXG4gICAgICAgIHJldHVybiB7XHJcbiAgICAgICAgICAgIGJyYW5kTG9nbzoge1xyXG4gICAgICAgICAgICAgICAgLy8gIHByZWZpeDogJ09wZW5FTUlTJyxcclxuICAgICAgICAgICAgICAgIG5hbWU6ICdPcGVuRU1JUyBTdHlsZWd1aWRlJyxcclxuICAgICAgICAgICAgICAgIHR5cGU6ICdpY29uJywgLy8gaWNvbiwgaW1hZ2UsIG5vbmVcclxuICAgICAgICAgICAgICAgIHNyYzogJ2tkLW9wZW5lbWlzJ1xyXG4gICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICB1c2VySW5mbzoge1xyXG4gICAgICAgICAgICAgICAgc2hvd1VzZXI6IHRydWUsIC8vIHRydWUsIGZhbHNlXHJcbiAgICAgICAgICAgICAgICBuYW1lOiAnJyxcclxuICAgICAgICAgICAgICAgIGltZ1R5cGU6ICdpY29uJywgLy8gaWNvbiwgaW1hZ2UsIG5vbmVcclxuICAgICAgICAgICAgICAgIGltZ1NyYzogJ2tkLXJvbGUnLFxyXG4gICAgICAgICAgICAgICAgcm9sZTogJydcclxuICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgYnRuR3JvdXA6IFt7XHJcbiAgICAgICAgICAgICAgICBidG5JY29uOiAnZmEgZmEtaG9tZSBmYS1sZycsXHJcbiAgICAgICAgICAgICAgICBkcm9wZG93blR5cGU6ICdkZWZhdWx0J1xyXG4gICAgICAgICAgICB9LCB7XHJcbiAgICAgICAgICAgICAgICBidG5JY29uOiAna2QtZ3JpZCcsXHJcbiAgICAgICAgICAgICAgICBkcm9wZG93blR5cGU6ICdncmlkJyxcclxuICAgICAgICAgICAgICAgIGRyb3Bkb3duQ29udGVudDogW3tcclxuICAgICAgICAgICAgICAgICAgICBpY29uOiAna2Qtb3BlbmVtaXMga2QtYW5hbHl6ZXInLFxyXG4gICAgICAgICAgICAgICAgICAgIHRleHQ6ICdBbmFseXplcicsXHJcbiAgICAgICAgICAgICAgICAgICAgdGhlbWU6ICdvcGVuZW1pcy1hbmFseXplcidcclxuICAgICAgICAgICAgICAgIH0sIHtcclxuICAgICAgICAgICAgICAgICAgICBpY29uOiAna2Qtb3BlbmVtaXMga2QtY29tbXVuaXR5JyxcclxuICAgICAgICAgICAgICAgICAgICB0ZXh0OiAnQ29tbXVuaXR5JyxcclxuICAgICAgICAgICAgICAgICAgICB0aGVtZTogJ29wZW5lbWlzLWNvbW11bml0eSdcclxuICAgICAgICAgICAgICAgIH0sIHtcclxuICAgICAgICAgICAgICAgICAgICBpY29uOiAna2Qtb3BlbmVtaXMga2QtY29ubmVjdCcsXHJcbiAgICAgICAgICAgICAgICAgICAgdGV4dDogJ0Nvbm5lY3QnLFxyXG4gICAgICAgICAgICAgICAgICAgIHRoZW1lOiAnb3BlbmVtaXMtY29ubmVjdCdcclxuICAgICAgICAgICAgICAgIH0sIHtcclxuICAgICAgICAgICAgICAgICAgICBpY29uOiAna2Qtb3BlbmVtaXMga2QtY29yZScsXHJcbiAgICAgICAgICAgICAgICAgICAgdGV4dDogJ0NvcmUnLFxyXG4gICAgICAgICAgICAgICAgICAgIHRoZW1lOiAnb3BlbmVtaXMtY29yZSdcclxuICAgICAgICAgICAgICAgIH0sIHtcclxuICAgICAgICAgICAgICAgICAgICBpY29uOiAna2Qtb3BlbmVtaXMga2QtZGF0YW1hbmFnZXInLFxyXG4gICAgICAgICAgICAgICAgICAgIHRleHQ6ICdEYXRhTWFuYWdlcicsXHJcbiAgICAgICAgICAgICAgICAgICAgdGhlbWU6ICdvcGVuZW1pcy1kYXRhbWFuYWdlcidcclxuICAgICAgICAgICAgICAgIH0sIHtcclxuICAgICAgICAgICAgICAgICAgICBpY29uOiAna2Qtb3BlbmVtaXMga2QtZGFzaGJvYXJkJyxcclxuICAgICAgICAgICAgICAgICAgICB0ZXh0OiAnRGFzaGJvYXJkJyxcclxuICAgICAgICAgICAgICAgICAgICB0aGVtZTogJ29wZW5lbWlzLWRhc2hib2FyZCdcclxuICAgICAgICAgICAgICAgIH0sIHtcclxuICAgICAgICAgICAgICAgICAgICBpY29uOiAna2Qtb3BlbmVtaXMga2QtZXhhbXMnLFxyXG4gICAgICAgICAgICAgICAgICAgIHRleHQ6ICdFeGFtcycsXHJcbiAgICAgICAgICAgICAgICAgICAgdGhlbWU6ICdvcGVuZW1pcy1leGFtcydcclxuICAgICAgICAgICAgICAgIH0sIHtcclxuICAgICAgICAgICAgICAgICAgICBpY29uOiAna2Qtb3BlbmVtaXMga2QtaWRlbnRpdHknLFxyXG4gICAgICAgICAgICAgICAgICAgIHRleHQ6ICdJZGVudGl0eScsXHJcbiAgICAgICAgICAgICAgICAgICAgdGhlbWU6ICdvcGVuZW1pcy1pZGVudGl0eSdcclxuICAgICAgICAgICAgICAgIH0sIHtcclxuICAgICAgICAgICAgICAgICAgICBpY29uOiAna2Qtb3BlbmVtaXMga2QtaW5zaWdodCcsXHJcbiAgICAgICAgICAgICAgICAgICAgdGV4dDogJ0luc2lnaHQnLFxyXG4gICAgICAgICAgICAgICAgICAgIHRoZW1lOiAnb3BlbmVtaXMtaW5zaWdodCdcclxuICAgICAgICAgICAgICAgIH0sIHtcclxuICAgICAgICAgICAgICAgICAgICBpY29uOiAna2Qtb3BlbmVtaXMga2QtaW50ZWdyYXRvcicsXHJcbiAgICAgICAgICAgICAgICAgICAgdGV4dDogJ0ludGVncmF0b3InLFxyXG4gICAgICAgICAgICAgICAgICAgIHRoZW1lOiAnb3BlbmVtaXMtaW50ZWdyYXRvcidcclxuICAgICAgICAgICAgICAgIH0sIHtcclxuICAgICAgICAgICAgICAgICAgICBpY29uOiAna2Qtb3BlbmVtaXMga2QtbGVhcm5pbmcnLFxyXG4gICAgICAgICAgICAgICAgICAgIHRleHQ6ICdMZWFybmluZycsXHJcbiAgICAgICAgICAgICAgICAgICAgdGhlbWU6ICdvcGVuZW1pcy1sZWFybmluZydcclxuICAgICAgICAgICAgICAgIH0sIHtcclxuICAgICAgICAgICAgICAgICAgICBpY29uOiAna2Qtb3BlbmVtaXMga2QtbG9naXN0aWNzJyxcclxuICAgICAgICAgICAgICAgICAgICB0ZXh0OiAnTG9naXN0aWNzJyxcclxuICAgICAgICAgICAgICAgICAgICB0aGVtZTogJ29wZW5lbWlzLWxvZ2lzdGljcydcclxuICAgICAgICAgICAgICAgIH0sIHtcclxuICAgICAgICAgICAgICAgICAgICBpY29uOiAna2Qtb3BlbmVtaXMga2QtbW9kZWxsaW5nJyxcclxuICAgICAgICAgICAgICAgICAgICB0ZXh0OiAnTW9kZWxsaW5nJyxcclxuICAgICAgICAgICAgICAgICAgICB0aGVtZTogJ29wZW5lbWlzLW1vZGVsbGluZydcclxuICAgICAgICAgICAgICAgIH0sIHtcclxuICAgICAgICAgICAgICAgICAgICBpY29uOiAna2Qtb3BlbmVtaXMga2QtbW9uaXRvcmluZycsXHJcbiAgICAgICAgICAgICAgICAgICAgdGV4dDogJ01vbml0b3JpbmcnLFxyXG4gICAgICAgICAgICAgICAgICAgIHRoZW1lOiAnb3BlbmVtaXMtbW9uaXRvcmluZydcclxuICAgICAgICAgICAgICAgIH0sIHtcclxuICAgICAgICAgICAgICAgICAgICBpY29uOiAna2Qtb3BlbmVtaXMga2Qtc2Nob29sJyxcclxuICAgICAgICAgICAgICAgICAgICB0ZXh0OiAnU2Nob29sJyxcclxuICAgICAgICAgICAgICAgICAgICB0aGVtZTogJ29wZW5lbWlzLXNjaG9vbCdcclxuICAgICAgICAgICAgICAgIH0sIC8qe1xyXG4gICAgICAgICAgICAgICAgICAgIGljb246ICdrZC1vcGVuZW1pcyBrZC12aXN1YWxpemVyJyxcclxuICAgICAgICAgICAgICAgICAgICB0ZXh0OiAnVmlzdWFsaXplcicsXHJcbiAgICAgICAgICAgICAgICAgICAgdGhlbWU6ICdvcGVuZW1pcy12aXN1YWxpemVyJ1xyXG4gICAgICAgICAgICAgICAgfSwqLyB7XHJcbiAgICAgICAgICAgICAgICAgICAgaWNvbjogJ2tkLW9wZW5lbWlzIGtkLXN0eWxlZ3VpZGUnLFxyXG4gICAgICAgICAgICAgICAgICAgIHRleHQ6ICdTdHlsZWd1aWRlJyxcclxuICAgICAgICAgICAgICAgICAgICB0aGVtZTogJ29wZW5lbWlzLXN0eWxlZ3VpZGUnXHJcbiAgICAgICAgICAgICAgICB9XVxyXG4gICAgICAgICAgICB9LCB7XHJcbiAgICAgICAgICAgICAgICBidG5JY29uOiAna2QtZWxsaXBzaXMnLFxyXG4gICAgICAgICAgICAgICAgZHJvcGRvd25UeXBlOiAnbGlzdCcsXHJcbiAgICAgICAgICAgICAgICBkcm9wZG93bkNvbnRlbnQ6IFt7XHJcbiAgICAgICAgICAgICAgICAgICAgaWNvbjogJ2ZhIGZhLXVzZXInLFxyXG4gICAgICAgICAgICAgICAgICAgIHRleHQ6ICdBYm91dCdcclxuICAgICAgICAgICAgICAgIH0sIHtcclxuICAgICAgICAgICAgICAgICAgICBpY29uOiAnZmEgZmEtY29nJyxcclxuICAgICAgICAgICAgICAgICAgICB0ZXh0OiAnUHJlZmVyZW5jZXMnXHJcbiAgICAgICAgICAgICAgICB9LCB7XHJcbiAgICAgICAgICAgICAgICAgICAgaWNvbjogJ2ZhIGZhLXF1ZXN0aW9uLWNpcmNsZScsXHJcbiAgICAgICAgICAgICAgICAgICAgdGV4dDogJ0hlbHAnXHJcbiAgICAgICAgICAgICAgICB9LCB7XHJcbiAgICAgICAgICAgICAgICAgICAgaWNvbjogJ2ZhIGZhLXBvd2VyLW9mZicsXHJcbiAgICAgICAgICAgICAgICAgICAgdGV4dDogJ0xvZ291dCdcclxuICAgICAgICAgICAgICAgIH1dXHJcbiAgICAgICAgICAgIH1dXHJcbiAgICAgICAgfTtcclxuICAgIH1cclxufVxyXG4iXX0=