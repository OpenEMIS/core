import { Component, Input, Output, EventEmitter, ViewEncapsulation, ViewContainerRef, HostBinding } from '@angular/core';
import { Router, NavigationEnd } from '@angular/router';
import { timer } from 'rxjs';
import { KdDomElemSvc } from '../kd-common/index';
import { KdAdvFilterEvent, KdIntAdvFilterEvent } from './kd-adv-filter-event';
export class KdAdvFilter {
    constructor(_intAdvSearchEvent, _advSearchEvent, _domSvc, _vcr, _router) {
        this._intAdvSearchEvent = _intAdvSearchEvent;
        this._advSearchEvent = _advSearchEvent;
        this._domSvc = _domSvc;
        this._vcr = _vcr;
        this._router = _router;
        this.showSearch = false;
        this.api = {};
        this._formButtons = [
            {
                type: 'submit',
                name: 'Search',
                icon: 'kd-check',
                class: 'btn-text'
            },
            {
                type: 'reset',
                name: 'Reset',
                icon: 'kd-close',
                class: 'btn-outline'
            }
        ];
        this._toShow = false;
        this.fieldValue = new EventEmitter();
        this.formValue = new EventEmitter();
        this._classShow = false;
        this._classKdxAdvSearch = true;
    }
    ngOnInit() {
        this._toggleSub = this._intAdvSearchEvent.onToggleAdvSearch().subscribe(val => {
            this._toShow = (typeof val !== 'undefined') ? val : !this._toShow;
            this._startAnimation(this._toShow);
            this._intAdvSearchEvent.sendAdvSearchStatus(this._toShow);
        });
        this._routerSub = this._router.events.subscribe(event => {
            if (event instanceof NavigationEnd) {
                this._advSearchEvent.toggleAdvSearch(false);
            }
        });
    }
    ngOnDestroy() {
        this._toggleSub.unsubscribe();
        this._routerSub.unsubscribe();
    }
    closeSearch() {
        this._advSearchEvent.toggleAdvSearch(false);
    }
    getTriggerInput(data) {
        this.fieldValue.emit(data);
    }
    getValue(fieldVal) {
        this._searchQuery = fieldVal;
    }
    formSubmitVal(formVal) {
        this.formValue.emit(formVal);
    }
    _startAnimation(isShow) {
        /*
            hide -> show
                - bring z-index up (_classShow)
                - animation right/left position via keyframe (_showSearch)

            show -> hide
                - animation right/left position via keyframe (_showSearch)
                - bring z-index down (_classShow)
         */
        if (isShow) {
            this._classShow = isShow;
            timer(200).subscribe(() => {
                this.showSearch = isShow;
            });
        }
        else {
            this.showSearch = isShow;
            timer(300).subscribe(() => {
                this._classShow = isShow;
                let scrollBackTop = this._vcr.element.nativeElement.querySelector('.kdx-adv-search-body');
                scrollBackTop.scrollTop = 0;
            });
        }
        if (this._domSvc.isMobile())
            this._checkMainWrapperOverflow(isShow);
    }
    _checkMainWrapperOverflow(_isShow) {
        let toOverflow = (_isShow) ? 'hidden' : 'auto';
        let mainWrapperEle = document.body.querySelector('.main-wrapper');
        this._domSvc.setElementStyle(mainWrapperEle, 'overflow', toOverflow);
    }
}
KdAdvFilter.decorators = [
    { type: Component, args: [{
                selector: 'kd-adv-search',
                template: "<div [ngClass]=\"{'kdx-hide-adv': !showSearch, 'kdx-show-adv': showSearch}\" class=\"kdx-adv-search-wrapper\">\r\n    <div class=\"kdx-white-bg\">\r\n    </div>\r\n    <div class=\"kdx-adv-search-content\">\r\n        <div class=\"kdx-adv-search-header\">\r\n            <i class=\"fa fa-search-plus\"></i>\r\n            <h3>Advance Search</h3>\r\n            <button class=\"btn btn-icon btn-outline\" type=\"button\" (click)=\"closeSearch()\">\r\n                <i class=\"kd-close-round\"></i>\r\n            </button> s\r\n        </div>\r\n        <div class=\"kdx-adv-search-body\">\r\n            <kd-view \r\n            displayType=\"form\" \r\n            id=\"advance-search\" \r\n            [inputData]=\"formData\" \r\n            [button]=\"_formButtons\" \r\n            [api]=\"api\" \r\n            (detectFrom)=\"getTriggerInput($event)\" \r\n            (submitEvent)=\"formSubmitVal($event)\"></kd-view>\r\n        </div>\r\n    </div>\r\n</div>\r\n",
                encapsulation: ViewEncapsulation.None,
                providers: [KdIntAdvFilterEvent, KdAdvFilterEvent]
            },] }
];
KdAdvFilter.ctorParameters = () => [
    { type: KdIntAdvFilterEvent },
    { type: KdAdvFilterEvent },
    { type: KdDomElemSvc },
    { type: ViewContainerRef },
    { type: Router }
];
KdAdvFilter.propDecorators = {
    formData: [{ type: Input }],
    fieldValue: [{ type: Output }],
    formValue: [{ type: Output }],
    _classShow: [{ type: HostBinding, args: ['class.show',] }],
    _classKdxAdvSearch: [{ type: HostBinding, args: ['class.kdx-adv-search',] }]
};
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoia2QtYW5ndWxhci1hZHYtZmlsdGVyLmpzIiwic291cmNlUm9vdCI6IkQ6L29wZW5FTUlTL3N0eWxlZ3VpZGUvaW9zdGctb3BlbmVtaXMtc3R5bGVndWlkZS9wcm9qZWN0cy9vcGVuZW1pcy1zdHlsZWd1aWRlLWxpYi9zcmMvIiwic291cmNlcyI6WyJrZC1jb21wb25lbnRzL2tkLWFuZ3VsYXItYWR2LWZpbHRlci9rZC1hbmd1bGFyLWFkdi1maWx0ZXIudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsT0FBTyxFQUNILFNBQVMsRUFDVCxLQUFLLEVBQ0wsTUFBTSxFQUNOLFlBQVksRUFDWixpQkFBaUIsRUFDakIsZ0JBQWdCLEVBQ2hCLFdBQVcsRUFHZCxNQUFNLGVBQWUsQ0FBQztBQUN2QixPQUFPLEVBQUUsTUFBTSxFQUFFLGFBQWEsRUFBRSxNQUFNLGlCQUFpQixDQUFDO0FBQ3hELE9BQU8sRUFBRSxLQUFLLEVBQWtCLE1BQU0sTUFBTSxDQUFDO0FBRTdDLE9BQU8sRUFBRSxZQUFZLEVBQUUsTUFBTSxvQkFBb0IsQ0FBQztBQUNsRCxPQUFPLEVBQUUsZ0JBQWdCLEVBQUUsbUJBQW1CLEVBQUUsTUFBTSx1QkFBdUIsQ0FBQztBQVE5RSxNQUFNLE9BQU8sV0FBVztJQTZCcEIsWUFDWSxrQkFBdUMsRUFDdkMsZUFBaUMsRUFDakMsT0FBcUIsRUFDckIsSUFBc0IsRUFDdEIsT0FBZTtRQUpmLHVCQUFrQixHQUFsQixrQkFBa0IsQ0FBcUI7UUFDdkMsb0JBQWUsR0FBZixlQUFlLENBQWtCO1FBQ2pDLFlBQU8sR0FBUCxPQUFPLENBQWM7UUFDckIsU0FBSSxHQUFKLElBQUksQ0FBa0I7UUFDdEIsWUFBTyxHQUFQLE9BQU8sQ0FBUTtRQWpDcEIsZUFBVSxHQUFZLEtBQUssQ0FBQztRQUM1QixRQUFHLEdBQW9CLEVBQUUsQ0FBQztRQUMxQixpQkFBWSxHQUFlO1lBQzlCO2dCQUNJLElBQUksRUFBRSxRQUFRO2dCQUNkLElBQUksRUFBRSxRQUFRO2dCQUNkLElBQUksRUFBRSxVQUFVO2dCQUNoQixLQUFLLEVBQUUsVUFBVTthQUNwQjtZQUNEO2dCQUNJLElBQUksRUFBRSxPQUFPO2dCQUNiLElBQUksRUFBRSxPQUFPO2dCQUNiLElBQUksRUFBRSxVQUFVO2dCQUNoQixLQUFLLEVBQUUsYUFBYTthQUN2QjtTQUNKLENBQUM7UUFFTSxZQUFPLEdBQVksS0FBSyxDQUFDO1FBTXZCLGVBQVUsR0FBc0IsSUFBSSxZQUFZLEVBQUUsQ0FBQztRQUNuRCxjQUFTLEdBQXNCLElBQUksWUFBWSxFQUFFLENBQUM7UUFDakMsZUFBVSxHQUFZLEtBQUssQ0FBQztRQUNsQix1QkFBa0IsR0FBWSxJQUFJLENBQUM7SUFRcEUsQ0FBQztJQUVMLFFBQVE7UUFDSixJQUFJLENBQUMsVUFBVSxHQUFHLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxpQkFBaUIsRUFBRSxDQUFDLFNBQVMsQ0FBQyxHQUFHLENBQUMsRUFBRTtZQUMxRSxJQUFJLENBQUMsT0FBTyxHQUFHLENBQUMsT0FBTyxHQUFHLEtBQUssV0FBVyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDO1lBQ2xFLElBQUksQ0FBQyxlQUFlLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxDQUFDO1lBRW5DLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxtQkFBbUIsQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLENBQUM7UUFDOUQsQ0FBQyxDQUFDLENBQUM7UUFFSCxJQUFJLENBQUMsVUFBVSxHQUFHLElBQUksQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLFNBQVMsQ0FBQyxLQUFLLENBQUMsRUFBRTtZQUNwRCxJQUFJLEtBQUssWUFBWSxhQUFhLEVBQUU7Z0JBQ2hDLElBQUksQ0FBQyxlQUFlLENBQUMsZUFBZSxDQUFDLEtBQUssQ0FBQyxDQUFDO2FBQy9DO1FBQ0wsQ0FBQyxDQUFDLENBQUM7SUFDUCxDQUFDO0lBRUQsV0FBVztRQUNQLElBQUksQ0FBQyxVQUFVLENBQUMsV0FBVyxFQUFFLENBQUM7UUFDOUIsSUFBSSxDQUFDLFVBQVUsQ0FBQyxXQUFXLEVBQUUsQ0FBQztJQUNsQyxDQUFDO0lBRUQsV0FBVztRQUNQLElBQUksQ0FBQyxlQUFlLENBQUMsZUFBZSxDQUFDLEtBQUssQ0FBQyxDQUFDO0lBQ2hELENBQUM7SUFFRCxlQUFlLENBQUMsSUFBUztRQUNyQixJQUFJLENBQUMsVUFBVSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQztJQUMvQixDQUFDO0lBRUQsUUFBUSxDQUFDLFFBQWE7UUFDbEIsSUFBSSxDQUFDLFlBQVksR0FBRyxRQUFRLENBQUM7SUFDakMsQ0FBQztJQUVELGFBQWEsQ0FBQyxPQUFZO1FBQ3RCLElBQUksQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxDQUFDO0lBQ2pDLENBQUM7SUFFTyxlQUFlLENBQUMsTUFBZTtRQUNuQzs7Ozs7Ozs7V0FRRztRQUNILElBQUksTUFBTSxFQUFFO1lBQ1IsSUFBSSxDQUFDLFVBQVUsR0FBRyxNQUFNLENBQUM7WUFDekIsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxHQUFTLEVBQUU7Z0JBQzVCLElBQUksQ0FBQyxVQUFVLEdBQUcsTUFBTSxDQUFDO1lBQzdCLENBQUMsQ0FBQyxDQUFDO1NBQ047YUFDSTtZQUNELElBQUksQ0FBQyxVQUFVLEdBQUcsTUFBTSxDQUFDO1lBQ3pCLEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FBQyxTQUFTLENBQUMsR0FBUyxFQUFFO2dCQUM1QixJQUFJLENBQUMsVUFBVSxHQUFHLE1BQU0sQ0FBQztnQkFFekIsSUFBSSxhQUFhLEdBQVksSUFBSSxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsYUFBYSxDQUFDLGFBQWEsQ0FBQyxzQkFBc0IsQ0FBQyxDQUFDO2dCQUNuRyxhQUFhLENBQUMsU0FBUyxHQUFHLENBQUMsQ0FBQztZQUNoQyxDQUFDLENBQUMsQ0FBQztTQUNOO1FBRUQsSUFBSSxJQUFJLENBQUMsT0FBTyxDQUFDLFFBQVEsRUFBRTtZQUFFLElBQUksQ0FBQyx5QkFBeUIsQ0FBQyxNQUFNLENBQUMsQ0FBQztJQUN4RSxDQUFDO0lBRU8seUJBQXlCLENBQUMsT0FBZ0I7UUFDOUMsSUFBSSxVQUFVLEdBQVcsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUM7UUFDdkQsSUFBSSxjQUFjLEdBQVksUUFBUSxDQUFDLElBQUksQ0FBQyxhQUFhLENBQUMsZUFBZSxDQUFDLENBQUM7UUFDM0UsSUFBSSxDQUFDLE9BQU8sQ0FBQyxlQUFlLENBQUMsY0FBYyxFQUFFLFVBQVUsRUFBRSxVQUFVLENBQUMsQ0FBQztJQUN6RSxDQUFDOzs7WUFoSEosU0FBUyxTQUFDO2dCQUNQLFFBQVEsRUFBRSxlQUFlO2dCQUN6Qix3OUJBQTJDO2dCQUMzQyxhQUFhLEVBQUUsaUJBQWlCLENBQUMsSUFBSTtnQkFDckMsU0FBUyxFQUFFLENBQUMsbUJBQW1CLEVBQUUsZ0JBQWdCLENBQUM7YUFDckQ7OztZQVAwQixtQkFBbUI7WUFBckMsZ0JBQWdCO1lBRGhCLFlBQVk7WUFSakIsZ0JBQWdCO1lBS1gsTUFBTTs7O3VCQW1DVixLQUFLO3lCQUNMLE1BQU07d0JBQ04sTUFBTTt5QkFDTixXQUFXLFNBQUMsWUFBWTtpQ0FDeEIsV0FBVyxTQUFDLHNCQUFzQiIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7XHJcbiAgICBDb21wb25lbnQsXHJcbiAgICBJbnB1dCxcclxuICAgIE91dHB1dCxcclxuICAgIEV2ZW50RW1pdHRlcixcclxuICAgIFZpZXdFbmNhcHN1bGF0aW9uLFxyXG4gICAgVmlld0NvbnRhaW5lclJlZixcclxuICAgIEhvc3RCaW5kaW5nLFxyXG4gICAgT25Jbml0LFxyXG4gICAgT25EZXN0cm95XHJcbn0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XHJcbmltcG9ydCB7IFJvdXRlciwgTmF2aWdhdGlvbkVuZCB9IGZyb20gJ0Bhbmd1bGFyL3JvdXRlcic7XHJcbmltcG9ydCB7IHRpbWVyICwgIFN1YnNjcmlwdGlvbiB9IGZyb20gJ3J4anMnO1xyXG5pbXBvcnQgeyBJRHluYW1pY0Zvcm1BcGkgfSBmcm9tICcuLi9rZC1hbmd1bGFyLXZpZXcvaW5kZXgnO1xyXG5pbXBvcnQgeyBLZERvbUVsZW1TdmMgfSBmcm9tICcuLi9rZC1jb21tb24vaW5kZXgnO1xyXG5pbXBvcnQgeyBLZEFkdkZpbHRlckV2ZW50LCBLZEludEFkdkZpbHRlckV2ZW50IH0gZnJvbSAnLi9rZC1hZHYtZmlsdGVyLWV2ZW50JztcclxuXHJcbkBDb21wb25lbnQoe1xyXG4gICAgc2VsZWN0b3I6ICdrZC1hZHYtc2VhcmNoJyxcclxuICAgIHRlbXBsYXRlVXJsOiAnLi9rZC1hbmd1bGFyLWFkdi1maWx0ZXIuaHRtbCcsXHJcbiAgICBlbmNhcHN1bGF0aW9uOiBWaWV3RW5jYXBzdWxhdGlvbi5Ob25lLFxyXG4gICAgcHJvdmlkZXJzOiBbS2RJbnRBZHZGaWx0ZXJFdmVudCwgS2RBZHZGaWx0ZXJFdmVudF1cclxufSlcclxuZXhwb3J0IGNsYXNzIEtkQWR2RmlsdGVyIGltcGxlbWVudHMgT25Jbml0LCBPbkRlc3Ryb3kge1xyXG4gICAgcHVibGljIHNob3dTZWFyY2g6IGJvb2xlYW4gPSBmYWxzZTtcclxuICAgIHB1YmxpYyBhcGk6IElEeW5hbWljRm9ybUFwaSA9IHt9O1xyXG4gICAgcHVibGljIF9mb3JtQnV0dG9uczogQXJyYXk8YW55PiA9IFtcclxuICAgICAgICB7XHJcbiAgICAgICAgICAgIHR5cGU6ICdzdWJtaXQnLFxyXG4gICAgICAgICAgICBuYW1lOiAnU2VhcmNoJyxcclxuICAgICAgICAgICAgaWNvbjogJ2tkLWNoZWNrJyxcclxuICAgICAgICAgICAgY2xhc3M6ICdidG4tdGV4dCdcclxuICAgICAgICB9LFxyXG4gICAgICAgIHtcclxuICAgICAgICAgICAgdHlwZTogJ3Jlc2V0JyxcclxuICAgICAgICAgICAgbmFtZTogJ1Jlc2V0JyxcclxuICAgICAgICAgICAgaWNvbjogJ2tkLWNsb3NlJyxcclxuICAgICAgICAgICAgY2xhc3M6ICdidG4tb3V0bGluZSdcclxuICAgICAgICB9XHJcbiAgICBdO1xyXG5cclxuICAgIHByaXZhdGUgX3RvU2hvdzogYm9vbGVhbiA9IGZhbHNlO1xyXG4gICAgcHJpdmF0ZSBfc2VhcmNoUXVlcnk6IGFueTtcclxuICAgIHByaXZhdGUgX3RvZ2dsZVN1YjogU3Vic2NyaXB0aW9uO1xyXG4gICAgcHJpdmF0ZSBfcm91dGVyU3ViOiBTdWJzY3JpcHRpb247XHJcblxyXG4gICAgQElucHV0KCkgZm9ybURhdGE6IEFycmF5PGFueT47XHJcbiAgICBAT3V0cHV0KCkgZmllbGRWYWx1ZTogRXZlbnRFbWl0dGVyPGFueT4gPSBuZXcgRXZlbnRFbWl0dGVyKCk7XHJcbiAgICBAT3V0cHV0KCkgZm9ybVZhbHVlOiBFdmVudEVtaXR0ZXI8YW55PiA9IG5ldyBFdmVudEVtaXR0ZXIoKTtcclxuICAgIEBIb3N0QmluZGluZygnY2xhc3Muc2hvdycpIF9jbGFzc1Nob3c6IGJvb2xlYW4gPSBmYWxzZTtcclxuICAgIEBIb3N0QmluZGluZygnY2xhc3Mua2R4LWFkdi1zZWFyY2gnKSBfY2xhc3NLZHhBZHZTZWFyY2g6IGJvb2xlYW4gPSB0cnVlO1xyXG5cclxuICAgIGNvbnN0cnVjdG9yKFxyXG4gICAgICAgIHByaXZhdGUgX2ludEFkdlNlYXJjaEV2ZW50OiBLZEludEFkdkZpbHRlckV2ZW50LFxyXG4gICAgICAgIHByaXZhdGUgX2FkdlNlYXJjaEV2ZW50OiBLZEFkdkZpbHRlckV2ZW50LFxyXG4gICAgICAgIHByaXZhdGUgX2RvbVN2YzogS2REb21FbGVtU3ZjLFxyXG4gICAgICAgIHByaXZhdGUgX3ZjcjogVmlld0NvbnRhaW5lclJlZixcclxuICAgICAgICBwcml2YXRlIF9yb3V0ZXI6IFJvdXRlclxyXG4gICAgKSB7IH1cclxuXHJcbiAgICBuZ09uSW5pdCgpOiB2b2lkIHtcclxuICAgICAgICB0aGlzLl90b2dnbGVTdWIgPSB0aGlzLl9pbnRBZHZTZWFyY2hFdmVudC5vblRvZ2dsZUFkdlNlYXJjaCgpLnN1YnNjcmliZSh2YWwgPT4ge1xyXG4gICAgICAgICAgICB0aGlzLl90b1Nob3cgPSAodHlwZW9mIHZhbCAhPT0gJ3VuZGVmaW5lZCcpID8gdmFsIDogIXRoaXMuX3RvU2hvdztcclxuICAgICAgICAgICAgdGhpcy5fc3RhcnRBbmltYXRpb24odGhpcy5fdG9TaG93KTtcclxuXHJcbiAgICAgICAgICAgIHRoaXMuX2ludEFkdlNlYXJjaEV2ZW50LnNlbmRBZHZTZWFyY2hTdGF0dXModGhpcy5fdG9TaG93KTtcclxuICAgICAgICB9KTtcclxuXHJcbiAgICAgICAgdGhpcy5fcm91dGVyU3ViID0gdGhpcy5fcm91dGVyLmV2ZW50cy5zdWJzY3JpYmUoZXZlbnQgPT4ge1xyXG4gICAgICAgICAgICBpZiAoZXZlbnQgaW5zdGFuY2VvZiBOYXZpZ2F0aW9uRW5kKSB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLl9hZHZTZWFyY2hFdmVudC50b2dnbGVBZHZTZWFyY2goZmFsc2UpO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfSk7XHJcbiAgICB9XHJcblxyXG4gICAgbmdPbkRlc3Ryb3koKTogdm9pZCB7XHJcbiAgICAgICAgdGhpcy5fdG9nZ2xlU3ViLnVuc3Vic2NyaWJlKCk7XHJcbiAgICAgICAgdGhpcy5fcm91dGVyU3ViLnVuc3Vic2NyaWJlKCk7XHJcbiAgICB9XHJcblxyXG4gICAgY2xvc2VTZWFyY2goKTogdm9pZCB7XHJcbiAgICAgICAgdGhpcy5fYWR2U2VhcmNoRXZlbnQudG9nZ2xlQWR2U2VhcmNoKGZhbHNlKTtcclxuICAgIH1cclxuXHJcbiAgICBnZXRUcmlnZ2VySW5wdXQoZGF0YTogYW55KTogdm9pZCB7XHJcbiAgICAgICAgdGhpcy5maWVsZFZhbHVlLmVtaXQoZGF0YSk7XHJcbiAgICB9XHJcblxyXG4gICAgZ2V0VmFsdWUoZmllbGRWYWw6IGFueSk6IHZvaWQge1xyXG4gICAgICAgIHRoaXMuX3NlYXJjaFF1ZXJ5ID0gZmllbGRWYWw7XHJcbiAgICB9XHJcblxyXG4gICAgZm9ybVN1Ym1pdFZhbChmb3JtVmFsOiBhbnkpOiB2b2lkIHtcclxuICAgICAgICB0aGlzLmZvcm1WYWx1ZS5lbWl0KGZvcm1WYWwpO1xyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX3N0YXJ0QW5pbWF0aW9uKGlzU2hvdzogYm9vbGVhbik6IHZvaWQge1xyXG4gICAgICAgIC8qXHJcbiAgICAgICAgICAgIGhpZGUgLT4gc2hvd1xyXG4gICAgICAgICAgICAgICAgLSBicmluZyB6LWluZGV4IHVwIChfY2xhc3NTaG93KVxyXG4gICAgICAgICAgICAgICAgLSBhbmltYXRpb24gcmlnaHQvbGVmdCBwb3NpdGlvbiB2aWEga2V5ZnJhbWUgKF9zaG93U2VhcmNoKVxyXG5cclxuICAgICAgICAgICAgc2hvdyAtPiBoaWRlXHJcbiAgICAgICAgICAgICAgICAtIGFuaW1hdGlvbiByaWdodC9sZWZ0IHBvc2l0aW9uIHZpYSBrZXlmcmFtZSAoX3Nob3dTZWFyY2gpXHJcbiAgICAgICAgICAgICAgICAtIGJyaW5nIHotaW5kZXggZG93biAoX2NsYXNzU2hvdylcclxuICAgICAgICAgKi9cclxuICAgICAgICBpZiAoaXNTaG93KSB7XHJcbiAgICAgICAgICAgIHRoaXMuX2NsYXNzU2hvdyA9IGlzU2hvdztcclxuICAgICAgICAgICAgdGltZXIoMjAwKS5zdWJzY3JpYmUoKCk6IHZvaWQgPT4ge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5zaG93U2VhcmNoID0gaXNTaG93O1xyXG4gICAgICAgICAgICB9KTtcclxuICAgICAgICB9XHJcbiAgICAgICAgZWxzZSB7XHJcbiAgICAgICAgICAgIHRoaXMuc2hvd1NlYXJjaCA9IGlzU2hvdztcclxuICAgICAgICAgICAgdGltZXIoMzAwKS5zdWJzY3JpYmUoKCk6IHZvaWQgPT4ge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5fY2xhc3NTaG93ID0gaXNTaG93O1xyXG5cclxuICAgICAgICAgICAgICAgIGxldCBzY3JvbGxCYWNrVG9wOiBFbGVtZW50ID0gdGhpcy5fdmNyLmVsZW1lbnQubmF0aXZlRWxlbWVudC5xdWVyeVNlbGVjdG9yKCcua2R4LWFkdi1zZWFyY2gtYm9keScpO1xyXG4gICAgICAgICAgICAgICAgc2Nyb2xsQmFja1RvcC5zY3JvbGxUb3AgPSAwO1xyXG4gICAgICAgICAgICB9KTtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIGlmICh0aGlzLl9kb21TdmMuaXNNb2JpbGUoKSkgdGhpcy5fY2hlY2tNYWluV3JhcHBlck92ZXJmbG93KGlzU2hvdyk7XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfY2hlY2tNYWluV3JhcHBlck92ZXJmbG93KF9pc1Nob3c6IGJvb2xlYW4pOiB2b2lkIHtcclxuICAgICAgICBsZXQgdG9PdmVyZmxvdzogc3RyaW5nID0gKF9pc1Nob3cpID8gJ2hpZGRlbicgOiAnYXV0byc7XHJcbiAgICAgICAgbGV0IG1haW5XcmFwcGVyRWxlOiBFbGVtZW50ID0gZG9jdW1lbnQuYm9keS5xdWVyeVNlbGVjdG9yKCcubWFpbi13cmFwcGVyJyk7XHJcbiAgICAgICAgdGhpcy5fZG9tU3ZjLnNldEVsZW1lbnRTdHlsZShtYWluV3JhcHBlckVsZSwgJ292ZXJmbG93JywgdG9PdmVyZmxvdyk7XHJcbiAgICB9XHJcbn1cclxuIl19