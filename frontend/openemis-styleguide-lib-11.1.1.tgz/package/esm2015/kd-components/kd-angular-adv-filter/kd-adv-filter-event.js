import { Injectable } from '@angular/core';
import { KdBroadcaster } from '../kd-common/index';
import * as i0 from "@angular/core";
import * as i1 from "../kd-common/kd-broadcaster-svc";
export class KdIntAdvFilterEvent {
    constructor(_broadcaster) {
        this._broadcaster = _broadcaster;
    }
    onToggleAdvSearch() {
        return this._broadcaster.on('KDToggleAdvSearch');
    }
    onSendData() {
        return this._broadcaster.on('KdFormValue');
    }
    sendAdvSearchStatus(data) {
        this._broadcaster.broadcast('KdSendShowStatus', data);
    }
}
KdIntAdvFilterEvent.decorators = [
    { type: Injectable }
];
KdIntAdvFilterEvent.ctorParameters = () => [
    { type: KdBroadcaster }
];
export class KdAdvFilterEvent {
    constructor(_broadcaster) {
        this._broadcaster = _broadcaster;
    }
    toggleAdvSearch(data) {
        this._broadcaster.broadcast('KDToggleAdvSearch', data);
    }
    sendData(data) {
        this._broadcaster.broadcast('KdFormValue', data);
    }
    onSendAdvSearchStatus(data) {
        return this._broadcaster.on('KdSendShowStatus');
    }
}
KdAdvFilterEvent.ɵprov = i0.ɵɵdefineInjectable({ factory: function KdAdvFilterEvent_Factory() { return new KdAdvFilterEvent(i0.ɵɵinject(i1.KdBroadcaster)); }, token: KdAdvFilterEvent, providedIn: "root" });
KdAdvFilterEvent.decorators = [
    { type: Injectable, args: [{
                providedIn: 'root'
            },] }
];
KdAdvFilterEvent.ctorParameters = () => [
    { type: KdBroadcaster }
];
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoia2QtYWR2LWZpbHRlci1ldmVudC5qcyIsInNvdXJjZVJvb3QiOiJEOi9vcGVuRU1JUy9zdHlsZWd1aWRlL2lvc3RnLW9wZW5lbWlzLXN0eWxlZ3VpZGUvcHJvamVjdHMvb3BlbmVtaXMtc3R5bGVndWlkZS1saWIvc3JjLyIsInNvdXJjZXMiOlsia2QtY29tcG9uZW50cy9rZC1hbmd1bGFyLWFkdi1maWx0ZXIva2QtYWR2LWZpbHRlci1ldmVudC50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQSxPQUFPLEVBQUUsVUFBVSxFQUFFLE1BQU0sZUFBZSxDQUFDO0FBRTNDLE9BQU8sRUFBRSxhQUFhLEVBQUUsTUFBTSxvQkFBb0IsQ0FBQzs7O0FBR25ELE1BQU0sT0FBTyxtQkFBbUI7SUFDNUIsWUFBb0IsWUFBMkI7UUFBM0IsaUJBQVksR0FBWixZQUFZLENBQWU7SUFBSSxDQUFDO0lBRXBELGlCQUFpQjtRQUNiLE9BQU8sSUFBSSxDQUFDLFlBQVksQ0FBQyxFQUFFLENBQU0sbUJBQW1CLENBQUMsQ0FBQztJQUMxRCxDQUFDO0lBRUQsVUFBVTtRQUNOLE9BQU8sSUFBSSxDQUFDLFlBQVksQ0FBQyxFQUFFLENBQU0sYUFBYSxDQUFDLENBQUM7SUFDcEQsQ0FBQztJQUVELG1CQUFtQixDQUFDLElBQVU7UUFDMUIsSUFBSSxDQUFDLFlBQVksQ0FBQyxTQUFTLENBQUMsa0JBQWtCLEVBQUUsSUFBSSxDQUFDLENBQUM7SUFDMUQsQ0FBQzs7O1lBZEosVUFBVTs7O1lBRkYsYUFBYTs7QUFzQnRCLE1BQU0sT0FBTyxnQkFBZ0I7SUFDekIsWUFBb0IsWUFBMkI7UUFBM0IsaUJBQVksR0FBWixZQUFZLENBQWU7SUFBSSxDQUFDO0lBRXBELGVBQWUsQ0FBQyxJQUFVO1FBQ3RCLElBQUksQ0FBQyxZQUFZLENBQUMsU0FBUyxDQUFDLG1CQUFtQixFQUFFLElBQUksQ0FBQyxDQUFDO0lBQzNELENBQUM7SUFFRCxRQUFRLENBQUMsSUFBVTtRQUNmLElBQUksQ0FBQyxZQUFZLENBQUMsU0FBUyxDQUFDLGFBQWEsRUFBRSxJQUFJLENBQUMsQ0FBQztJQUNyRCxDQUFDO0lBRUQscUJBQXFCLENBQUMsSUFBVTtRQUM1QixPQUFPLElBQUksQ0FBQyxZQUFZLENBQUMsRUFBRSxDQUFNLGtCQUFrQixDQUFDLENBQUM7SUFDekQsQ0FBQzs7OztZQWhCSixVQUFVLFNBQUM7Z0JBQ1IsVUFBVSxFQUFFLE1BQU07YUFDckI7OztZQXJCUSxhQUFhIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgSW5qZWN0YWJsZSB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xyXG5pbXBvcnQgeyBPYnNlcnZhYmxlIH0gZnJvbSAncnhqcyc7XHJcbmltcG9ydCB7IEtkQnJvYWRjYXN0ZXIgfSBmcm9tICcuLi9rZC1jb21tb24vaW5kZXgnO1xyXG5cclxuQEluamVjdGFibGUoKVxyXG5leHBvcnQgY2xhc3MgS2RJbnRBZHZGaWx0ZXJFdmVudCB7XHJcbiAgICBjb25zdHJ1Y3Rvcihwcml2YXRlIF9icm9hZGNhc3RlcjogS2RCcm9hZGNhc3RlcikgeyB9XHJcblxyXG4gICAgb25Ub2dnbGVBZHZTZWFyY2goKTogT2JzZXJ2YWJsZTxhbnk+IHtcclxuICAgICAgICByZXR1cm4gdGhpcy5fYnJvYWRjYXN0ZXIub248YW55PignS0RUb2dnbGVBZHZTZWFyY2gnKTtcclxuICAgIH1cclxuXHJcbiAgICBvblNlbmREYXRhKCk6IE9ic2VydmFibGU8YW55PiB7XHJcbiAgICAgICAgcmV0dXJuIHRoaXMuX2Jyb2FkY2FzdGVyLm9uPGFueT4oJ0tkRm9ybVZhbHVlJyk7XHJcbiAgICB9XHJcblxyXG4gICAgc2VuZEFkdlNlYXJjaFN0YXR1cyhkYXRhPzogYW55KTogdm9pZCB7XHJcbiAgICAgICAgdGhpcy5fYnJvYWRjYXN0ZXIuYnJvYWRjYXN0KCdLZFNlbmRTaG93U3RhdHVzJywgZGF0YSk7XHJcbiAgICB9XHJcbn1cclxuXHJcbkBJbmplY3RhYmxlKHtcclxuICAgIHByb3ZpZGVkSW46ICdyb290J1xyXG59KVxyXG5leHBvcnQgY2xhc3MgS2RBZHZGaWx0ZXJFdmVudCB7XHJcbiAgICBjb25zdHJ1Y3Rvcihwcml2YXRlIF9icm9hZGNhc3RlcjogS2RCcm9hZGNhc3RlcikgeyB9XHJcblxyXG4gICAgdG9nZ2xlQWR2U2VhcmNoKGRhdGE/OiBhbnkpOiB2b2lkIHtcclxuICAgICAgICB0aGlzLl9icm9hZGNhc3Rlci5icm9hZGNhc3QoJ0tEVG9nZ2xlQWR2U2VhcmNoJywgZGF0YSk7XHJcbiAgICB9XHJcblxyXG4gICAgc2VuZERhdGEoZGF0YT86IGFueSk6IHZvaWQge1xyXG4gICAgICAgIHRoaXMuX2Jyb2FkY2FzdGVyLmJyb2FkY2FzdCgnS2RGb3JtVmFsdWUnLCBkYXRhKTtcclxuICAgIH1cclxuXHJcbiAgICBvblNlbmRBZHZTZWFyY2hTdGF0dXMoZGF0YT86IGFueSk6IE9ic2VydmFibGU8YW55PiB7XHJcbiAgICAgICAgcmV0dXJuIHRoaXMuX2Jyb2FkY2FzdGVyLm9uPGFueT4oJ0tkU2VuZFNob3dTdGF0dXMnKTtcclxuICAgIH1cclxufVxyXG4iXX0=