import { Injectable } from '@angular/core';
import { KdBroadcaster } from '../kd-common/index';
import * as i0 from "@angular/core";
import * as i1 from "../kd-common/kd-broadcaster-svc";
export class KdAlertEvent {
    constructor(broadcaster) {
        this.broadcaster = broadcaster;
    }
    show(data) {
        this.broadcaster.broadcast(KdAlertEvent, data);
    }
    success(data) {
        data = Object.assign({}, data, { type: 'success' });
        this.broadcaster.broadcast(KdAlertEvent, data);
    }
    error(data) {
        data = Object.assign({}, data, { type: 'error', /*timeout: -1,*/ showCloseButton: true });
        this.broadcaster.broadcast(KdAlertEvent, data);
    }
    info(data) {
        data = Object.assign({}, data, { type: 'info' });
        this.broadcaster.broadcast(KdAlertEvent, data);
    }
    warn(data) {
        data = Object.assign({}, data, { type: 'warning', /*timeout: -1,*/ showCloseButton: true });
        this.broadcaster.broadcast(KdAlertEvent, data);
    }
    on() {
        return this.broadcaster.on(KdAlertEvent);
    }
}
KdAlertEvent.ɵprov = i0.ɵɵdefineInjectable({ factory: function KdAlertEvent_Factory() { return new KdAlertEvent(i0.ɵɵinject(i1.KdBroadcaster)); }, token: KdAlertEvent, providedIn: "root" });
KdAlertEvent.decorators = [
    { type: Injectable, args: [{
                providedIn: 'root'
            },] }
];
KdAlertEvent.ctorParameters = () => [
    { type: KdBroadcaster }
];
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoia2QtYWxlcnQtZXZlbnQuanMiLCJzb3VyY2VSb290IjoiRDovb3BlbkVNSVMvc3R5bGVndWlkZS9pb3N0Zy1vcGVuZW1pcy1zdHlsZWd1aWRlL3Byb2plY3RzL29wZW5lbWlzLXN0eWxlZ3VpZGUtbGliL3NyYy8iLCJzb3VyY2VzIjpbImtkLWNvbXBvbmVudHMva2QtYW5ndWxhci1hbGVydC9rZC1hbGVydC1ldmVudC50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQSxPQUFPLEVBQUUsVUFBVSxFQUFFLE1BQU0sZUFBZSxDQUFDO0FBRTNDLE9BQU8sRUFBRSxhQUFhLEVBQUUsTUFBTSxvQkFBb0IsQ0FBQzs7O0FBS25ELE1BQU0sT0FBTyxZQUFZO0lBQ3JCLFlBQW9CLFdBQTBCO1FBQTFCLGdCQUFXLEdBQVgsV0FBVyxDQUFlO0lBQUksQ0FBQztJQUVuRCxJQUFJLENBQUMsSUFBUztRQUNWLElBQUksQ0FBQyxXQUFXLENBQUMsU0FBUyxDQUFDLFlBQVksRUFBRSxJQUFJLENBQUMsQ0FBQztJQUNuRCxDQUFDO0lBRUQsT0FBTyxDQUFDLElBQVM7UUFDYixJQUFJLEdBQUcsTUFBTSxDQUFDLE1BQU0sQ0FBQyxFQUFFLEVBQUUsSUFBSSxFQUFFLEVBQUUsSUFBSSxFQUFFLFNBQVMsRUFBRSxDQUFDLENBQUM7UUFDcEQsSUFBSSxDQUFDLFdBQVcsQ0FBQyxTQUFTLENBQUMsWUFBWSxFQUFFLElBQUksQ0FBQyxDQUFDO0lBQ25ELENBQUM7SUFFRCxLQUFLLENBQUMsSUFBUztRQUNYLElBQUksR0FBRyxNQUFNLENBQUMsTUFBTSxDQUFDLEVBQUUsRUFBRSxJQUFJLEVBQUUsRUFBRSxJQUFJLEVBQUUsT0FBTyxFQUFFLGdCQUFnQixDQUFDLGVBQWUsRUFBRSxJQUFJLEVBQUUsQ0FBQyxDQUFDO1FBQzFGLElBQUksQ0FBQyxXQUFXLENBQUMsU0FBUyxDQUFDLFlBQVksRUFBRSxJQUFJLENBQUMsQ0FBQztJQUNuRCxDQUFDO0lBRUQsSUFBSSxDQUFDLElBQVM7UUFDVixJQUFJLEdBQUcsTUFBTSxDQUFDLE1BQU0sQ0FBQyxFQUFFLEVBQUUsSUFBSSxFQUFFLEVBQUUsSUFBSSxFQUFFLE1BQU0sRUFBRSxDQUFDLENBQUM7UUFDakQsSUFBSSxDQUFDLFdBQVcsQ0FBQyxTQUFTLENBQUMsWUFBWSxFQUFFLElBQUksQ0FBQyxDQUFDO0lBQ25ELENBQUM7SUFFRCxJQUFJLENBQUMsSUFBUztRQUNWLElBQUksR0FBRyxNQUFNLENBQUMsTUFBTSxDQUFDLEVBQUUsRUFBRSxJQUFJLEVBQUUsRUFBRSxJQUFJLEVBQUUsU0FBUyxFQUFFLGdCQUFnQixDQUFDLGVBQWUsRUFBRSxJQUFJLEVBQUUsQ0FBQyxDQUFDO1FBQzVGLElBQUksQ0FBQyxXQUFXLENBQUMsU0FBUyxDQUFDLFlBQVksRUFBRSxJQUFJLENBQUMsQ0FBQztJQUNuRCxDQUFDO0lBRUQsRUFBRTtRQUNFLE9BQU8sSUFBSSxDQUFDLFdBQVcsQ0FBQyxFQUFFLENBQU0sWUFBWSxDQUFDLENBQUM7SUFDbEQsQ0FBQzs7OztZQWhDSixVQUFVLFNBQUU7Z0JBQ1IsVUFBVSxFQUFFLE1BQU07YUFDdEI7OztZQUpRLGFBQWEiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBJbmplY3RhYmxlIH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XHJcbmltcG9ydCB7IE9ic2VydmFibGUgfSBmcm9tICdyeGpzJztcclxuaW1wb3J0IHsgS2RCcm9hZGNhc3RlciB9IGZyb20gJy4uL2tkLWNvbW1vbi9pbmRleCc7XHJcblxyXG5ASW5qZWN0YWJsZSgge1xyXG4gICAgIHByb3ZpZGVkSW46ICdyb290J1xyXG59IClcclxuZXhwb3J0IGNsYXNzIEtkQWxlcnRFdmVudCB7XHJcbiAgICBjb25zdHJ1Y3Rvcihwcml2YXRlIGJyb2FkY2FzdGVyOiBLZEJyb2FkY2FzdGVyKSB7IH1cclxuXHJcbiAgICBzaG93KGRhdGE6IGFueSk6IHZvaWQge1xyXG4gICAgICAgIHRoaXMuYnJvYWRjYXN0ZXIuYnJvYWRjYXN0KEtkQWxlcnRFdmVudCwgZGF0YSk7XHJcbiAgICB9XHJcblxyXG4gICAgc3VjY2VzcyhkYXRhOiBhbnkpOiB2b2lkIHtcclxuICAgICAgICBkYXRhID0gT2JqZWN0LmFzc2lnbih7fSwgZGF0YSwgeyB0eXBlOiAnc3VjY2VzcycgfSk7XHJcbiAgICAgICAgdGhpcy5icm9hZGNhc3Rlci5icm9hZGNhc3QoS2RBbGVydEV2ZW50LCBkYXRhKTtcclxuICAgIH1cclxuXHJcbiAgICBlcnJvcihkYXRhOiBhbnkpOiB2b2lkIHtcclxuICAgICAgICBkYXRhID0gT2JqZWN0LmFzc2lnbih7fSwgZGF0YSwgeyB0eXBlOiAnZXJyb3InLCAvKnRpbWVvdXQ6IC0xLCovIHNob3dDbG9zZUJ1dHRvbjogdHJ1ZSB9KTtcclxuICAgICAgICB0aGlzLmJyb2FkY2FzdGVyLmJyb2FkY2FzdChLZEFsZXJ0RXZlbnQsIGRhdGEpO1xyXG4gICAgfVxyXG5cclxuICAgIGluZm8oZGF0YTogYW55KTogdm9pZCB7XHJcbiAgICAgICAgZGF0YSA9IE9iamVjdC5hc3NpZ24oe30sIGRhdGEsIHsgdHlwZTogJ2luZm8nIH0pO1xyXG4gICAgICAgIHRoaXMuYnJvYWRjYXN0ZXIuYnJvYWRjYXN0KEtkQWxlcnRFdmVudCwgZGF0YSk7XHJcbiAgICB9XHJcblxyXG4gICAgd2FybihkYXRhOiBhbnkpOiB2b2lkIHtcclxuICAgICAgICBkYXRhID0gT2JqZWN0LmFzc2lnbih7fSwgZGF0YSwgeyB0eXBlOiAnd2FybmluZycsIC8qdGltZW91dDogLTEsKi8gc2hvd0Nsb3NlQnV0dG9uOiB0cnVlIH0pO1xyXG4gICAgICAgIHRoaXMuYnJvYWRjYXN0ZXIuYnJvYWRjYXN0KEtkQWxlcnRFdmVudCwgZGF0YSk7XHJcbiAgICB9XHJcblxyXG4gICAgb24oKTogT2JzZXJ2YWJsZTxhbnk+IHtcclxuICAgICAgICByZXR1cm4gdGhpcy5icm9hZGNhc3Rlci5vbjxhbnk+KEtkQWxlcnRFdmVudCk7XHJcbiAgICB9XHJcbn1cclxuIl19