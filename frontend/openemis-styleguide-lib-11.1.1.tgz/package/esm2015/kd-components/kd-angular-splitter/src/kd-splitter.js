import { Component, Input, HostListener, ViewEncapsulation, ViewContainerRef, Renderer2 } from '@angular/core';
import { Router, NavigationEnd } from '@angular/router';
import { timer } from 'rxjs';
import { KdConvertionSvc, KdDomElemSvc } from '../../kd-common/index';
import { KdSplitterSvc } from './kd-splitter-svc';
import { KdSplitterEvent } from './kd-splitter-event';
export class KdSplitter {
    constructor(_vcr, _renderer, _splitterSvc, _convertionSvc, _domElemSvc, _splitterEvent, _router) {
        this._vcr = _vcr;
        this._renderer = _renderer;
        this._splitterSvc = _splitterSvc;
        this._convertionSvc = _convertionSvc;
        this._domElemSvc = _domElemSvc;
        this._splitterEvent = _splitterEvent;
        this._router = _router;
        this._isDrag = false;
        this._disableDrag = false;
        this._panesDefaultConfig = {};
        this._panes = [];
        // private _localStorage: number;
        this._isMainPaneCollapse = false;
        this._splitterLevel = '';
        this._enableFloatBtn = false;
        this._enableSubPaneCollapse = false;
        this._prevIsMobile = false;
        this._isSubPaneOpen = false;
        this._sessionPrefix = '';
        this._sessionName = 'splitter';
        this._isFirstSwitchViewPort = true;
        this._prevWidthState = 0;
        this._isMenuOpen = false;
        this.el = this._vcr.element;
    }
    onMousemove(event) {
        // this.mousemove.emit(event);
        this._onDrag(event);
    }
    onMouseup(event) {
        // this.mouseup.emit(event);
        this._isDrag = false;
    }
    onResize(event) {
        // console.log('resize');
        this._onResize(event);
    }
    ngOnInit() {
        this._prevIsMobile = this._domElemSvc.isMobile();
        this._enableFloatBtn = this._convertionSvc.strToBool(this.floatbtn);
        this._enableSubPaneCollapse = this._convertionSvc.strToBool(this.collapsible);
        // this._panesDefaultConfig = this._splitterSvc.initPanesDefaultConfig(this._panes);
        // console.log(this._panesDefaultConfig);
    }
    ngAfterViewInit() {
        this._panesDefaultConfig = this._splitterSvc.initPanesDefaultConfig(this._panes);
        this._disableDrag = this._splitterSvc.toDisableDrag();
        if (this._splitterSvc.isSubPane(this.el.nativeElement)) {
            // console.log('this is the sub pane');
            this._splitterLevel = 'sub';
            let leftPane = this._panes[0].element.nativeElement;
            this._prevWidthState = leftPane.getBoundingClientRect().width;
        }
        else {
            // console.log('this is the main pane');
            this._splitterLevel = 'main';
            this._registerMenuBroadcast();
            this._setTint(false);
        }
        // this._splitterEvent.onDrag()
        // .subscribe(_type => {
        //     console.log(_type);
        // });
        // isSubSplitter/
        this._sessionPrefix = this._convertionSvc.camelCase(this._domElemSvc.getDocumentTheme(), '-') + '_splitter_' + this._splitterLevel;
        this._setDefaultPaneSize();
        this._setupSplitterHandler();
        this._toggleCollapseSubPane();
        this._isFirstSwitchViewPort = false;
        this._router.events.subscribe(event => {
            if (event instanceof NavigationEnd) {
                // console.log(event.url);
                for (let key in this._panes) {
                    if (this._panes.hasOwnProperty(key)) {
                        let pane = this._panes[key];
                        pane.element.nativeElement.scrollTop = 0;
                    }
                }
            }
        });
    }
    addGroup(pane) {
        this._panes.push(pane);
        return this._panes.length;
    }
    paneOnChange(_type) {
        this._panesDefaultConfig = this._splitterSvc.initPanesDefaultConfig(this._panes);
        if (_type === 'size') {
            // changing element width before animation of panes start
            this._setDefaultPaneSize(false);
            let boundingRect = this.el.nativeElement.getBoundingClientRect();
            if (boundingRect) {
                // affects animation of left pane. 
                this._prevWidthState = this._panesDefaultConfig.Pane1.size * boundingRect.width;
            }
        }
    }
    _registerMenuBroadcast() {
        this._splitterEvent.on()
            .subscribe(respone => {
            // console.log(respone);
            let direction = this._domElemSvc.getDocumentDirection(true);
            let oppDirection = direction === 'left' ? 'right' : 'left';
            let className = 'push-content-' + oppDirection;
            let isMobile = this._domElemSvc.isMobile();
            let count = 0;
            for (let key in this._panes) {
                if (this._panes.hasOwnProperty(key)) {
                    let pane = this._panes[key];
                    this._domElemSvc.setElementClass(pane.element.nativeElement, 'animation', isMobile);
                    if (count !== 0) {
                        if (!isMobile) {
                            this._domElemSvc.removeClass(pane.element.nativeElement, className);
                        }
                        else {
                            this._isMenuOpen = !this._isMenuOpen;
                            if (this._splitterLevel === 'main') {
                                // console.log('append class ' + className + ' into main pane');
                                this._domElemSvc.setElementClass(pane.element.nativeElement, className, this._isMenuOpen);
                                this._setTint(this._isMenuOpen);
                            }
                        }
                    }
                    else {
                        if (isMobile && this._splitterLevel === 'sub') {
                            // console.log('sub main');
                        }
                    }
                    count++;
                }
            }
        });
    }
    _setupSplitterHandler() {
        for (let i = 1; i < this._panes.length; i++) {
            let count = i + 1;
            let className = 'sh-' + count;
            let newEl = this._domElemSvc.createElement(this._panes[i].element.nativeElement, 'splitter-handler ' + className);
            this._domElemSvc.setElementClass(newEl, 'disabled', this._disableDrag);
            // setup OnMouseDownEvent
            // setup OnMouseDownEvent
            this._renderer.listen(newEl, 'mousedown', (event) => {
                this._selectedElem = event.target.parentElement;
                this._selectedPrevSiblingElem = this._selectedElem.previousElementSibling;
                this._isDrag = true;
            });
            if (this._splitterLevel === 'main') {
                this._setupCollapseButton(this._panes[i], count);
            }
        }
    }
    _setupCollapseButton(_pane, _count) {
        let className = 'mb-' + _count;
        let newBtn = this._domElemSvc.createElement(_pane.element.nativeElement, 'menu-btn ' + className);
        // Setup icon
        this._domElemSvc.createElement(newBtn, 'fa', 'i');
        this._setCollapseIcon(this._isMainPaneCollapse);
        // setup OnMouseDownEvent
        // setup OnMouseDownEvent
        this._renderer.listen(newBtn, 'click', (event) => {
            // console.log(event);
            this._isDrag = false;
            this._toggleCollapseMenu(_pane);
        });
    }
    _setDefaultPaneSize(_useLocalStorage = true) {
        let count = 0;
        let offsetX = 0;
        let direction = this._domElemSvc.getDocumentDirection(true);
        let oppDirection = direction === 'left' ? 'right' : 'left';
        let mobileConfig = this._splitterSvc.getMobileConfig(this._splitterLevel, direction);
        let isMobile = this._domElemSvc.isMobile();
        let localStorage = JSON.parse(window.sessionStorage.getItem(this._sessionPrefix + this._sessionName));
        // console.log(localStorage);
        // console.log('sessionStorge = '+window.sessionStorage.getItem(this._sessionPrefix+this._sessionName));
        for (let key in this._panesDefaultConfig) {
            if (this._panesDefaultConfig.hasOwnProperty(key)) {
                let pane = this._panes[count];
                let paneConfig = {
                    width: (this._panesDefaultConfig[key].size > 100) ? 100 : this._panesDefaultConfig[key].size,
                };
                paneConfig[direction] = offsetX;
                if (isMobile) {
                    paneConfig = Object.assign({}, paneConfig, mobileConfig[key]);
                    this._isMenuOpen = false;
                    if (count === 0) {
                        // console.log('show button');
                        this._setupFloatMenuBtn(pane, count);
                    }
                    // console.log("this is mobile view");
                }
                else {
                    if (localStorage !== null && _useLocalStorage) {
                        let tempName = 'Pane' + (count + 1);
                        paneConfig = Object.assign({}, paneConfig, localStorage[tempName]);
                    }
                    // console.log(paneConfig);
                    this._removeFloatMenuBtn();
                    this._domElemSvc.removeClass(pane.element.nativeElement, 'push-content-' + oppDirection);
                    if (this._splitterLevel === 'sub' && count === 1 && this._isFirstSwitchViewPort) {
                        let isSubPaneShow = (this._panesDefaultConfig[key].show !== undefined) ? this._panesDefaultConfig[key].show : true;
                        this._processToggleCollapseSubPane(isSubPaneShow, false);
                    }
                }
                for (let cKey in paneConfig) {
                    if (paneConfig.hasOwnProperty(cKey)) {
                        this._domElemSvc.setElementStyle(pane.element.nativeElement, cKey, paneConfig[cKey] + '%');
                    }
                }
                count++;
                offsetX += paneConfig.width;
            }
        }
    }
    _updateSplitPaneSize(_posX, _boundSize) {
        if (this._domElemSvc.isMobile())
            return;
        if (!this._isDrag)
            return;
        let direction = this._domElemSvc.getDocumentDirection(true);
        let dimention = (this.orientation === 'vertical') ? 'height' : 'width';
        let selectedElemBounds = this._selectedElem.getBoundingClientRect();
        let selectedPrevElemBounds = this._selectedPrevSiblingElem.getBoundingClientRect();
        selectedElemBounds = (this.orientation === 'vertical') ? selectedElemBounds.height : selectedElemBounds.width;
        selectedPrevElemBounds = (this.orientation === 'vertical') ? selectedPrevElemBounds.height : selectedPrevElemBounds.width;
        let total2ElemSize = Math.round(this._convertionSvc.convertPxToPercent(selectedPrevElemBounds + selectedElemBounds, _boundSize));
        let moveX = this._splitterSvc.validatePercentValue(_posX);
        total2ElemSize = this._splitterSvc.validatePercentValue(total2ElemSize);
        let selectedPrevPaneKey = this._convertionSvc.camelCase(this._selectedPrevSiblingElem.classList[1], '-');
        moveX = this._splitterSvc.validatePaneSize(this._panesDefaultConfig, selectedPrevPaneKey, moveX);
        let curPane = total2ElemSize - moveX;
        let splitterFinalConfig = {
            Pane1: {},
            Pane2: {}
        };
        splitterFinalConfig['Pane1'][dimention] = moveX;
        splitterFinalConfig['Pane2'][direction] = moveX;
        splitterFinalConfig['Pane2'][dimention] = curPane;
        window.sessionStorage.setItem(this._sessionPrefix + this._sessionName, JSON.stringify(splitterFinalConfig));
        this._domElemSvc.setElementStyle(this._selectedPrevSiblingElem, dimention, moveX + '%');
        this._domElemSvc.setElementStyle(this._selectedElem, direction, moveX + '%');
        this._domElemSvc.setElementStyle(this._selectedElem, dimention, curPane + '%');
    }
    _toggleCollapseMenu(_pane) {
        let direction = this._domElemSvc.getDocumentDirection(true);
        this._isMainPaneCollapse = !this._isMainPaneCollapse;
        this._domElemSvc.addClass(_pane.element.nativeElement, 'animation');
        this._domElemSvc.setElementClass(_pane.element.nativeElement, 'push-content-' + direction, this._isMainPaneCollapse);
        this._setCollapseIcon(this._isMainPaneCollapse);
        this._splitterEvent.toggleMenu();
    }
    _removeFloatMenuBtn() {
        this._domElemSvc.removeElementByClass('.fm-btn', this.el.nativeElement);
    }
    _setupFloatMenuBtn(_pane, _count) {
        let isMobile = this._domElemSvc.isMobile();
        let floatBtn = this.el.nativeElement.querySelector('.fm-btn');
        if (isMobile && this._splitterLevel === 'sub' && floatBtn === null && this._enableFloatBtn) {
            // console.log('sub main');
            // let classNames: string = 'fmb-' + _count;
            let className = 'fm-btn';
            let newBtn = this._domElemSvc.createElement(this.el.nativeElement, 'btn btn-float-bottom-right btn-circle btn-color ' + className);
            // //Setup icon
            HTMLElement = this._domElemSvc.createElement(newBtn, 'fa', 'i');
            this._setFloatIcon(this._isSubPaneOpen);
            // //setup OnMouseDownEvent
            // //setup OnMouseDownEvent
            this._renderer.listen(newBtn, 'click', (event) => {
                this._isSubPaneOpen = !this._isSubPaneOpen;
                this._splitterEvent.toggleSubPane(this._isSubPaneOpen);
            });
        }
    }
    _toggleCollapseSubPane() {
        if (this._splitterLevel === 'sub') {
            this._splitterEvent.onToggleSubPane()
                .subscribe(isSubPaneOpen => {
                this._processToggleCollapseSubPane(isSubPaneOpen);
            });
        }
    }
    _processToggleCollapseSubPane(isSubPaneOpen, _animate) {
        // console.log('in this function?')
        _animate = (typeof _animate === 'undefined') ? true : _animate;
        let rightPane = this._panes[1].element.nativeElement;
        let leftPane = this._panes[0].element.nativeElement;
        let isMobile = this._domElemSvc.isMobile();
        let isSameState = (this._isSubPaneOpen === isSubPaneOpen) ? true : false;
        this._isSubPaneOpen = isSubPaneOpen;
        if (_animate) {
            this._domElemSvc.addClass(rightPane, 'animation');
            this._domElemSvc.addClass(leftPane, 'animation');
        }
        if (isMobile || this._enableSubPaneCollapse) {
            // console.log('am i in?');
            let animateDirection = (isMobile) ? 'in' : 'out';
            let direction = this._domElemSvc.getDocumentDirection(true);
            let oppDirection = (direction === 'left') ? 'right' : 'left';
            let addClass = (isMobile) ? isSubPaneOpen : !isSubPaneOpen;
            let widthConfig = [{}];
            if (addClass) {
                this._prevWidthState = leftPane.getBoundingClientRect().width;
                widthConfig = [
                    { 'width': this._prevWidthState + 'px' },
                    { 'width': '100%' }
                ];
            }
            else {
                widthConfig = [
                    { 'width': '100%' },
                    { 'width': this._prevWidthState + 'px' }
                ];
            }
            this._setFloatIcon(isSubPaneOpen);
            this._domElemSvc.setElementClass(leftPane, 'full-width', addClass);
            this._domElemSvc.setElementClass(rightPane, 'push-subcontent-' + oppDirection + '-' + animateDirection, addClass);
            if (_animate && !isSameState) {
                this._domElemSvc.invokeElementMethod(leftPane, 'animate', [widthConfig, 500]);
                timer(500).subscribe(() => {
                    // need fixing in the future. this event is being triggered twice. another time is in kd-example
                    this._splitterEvent.toggleSubPane(isSubPaneOpen);
                    // this._splitterEvent.toggleAnimationSubPaneEnd(isSubPaneOpen);
                });
            }
        }
    }
    _setFloatIcon(_isOpen) {
        let btnIcon = this.el.nativeElement.querySelector('.fm-btn i');
        if (this._splitterLevel === 'sub' && btnIcon !== null) {
            this._domElemSvc.setElementClass(btnIcon, 'kd-lists', !_isOpen);
            this._domElemSvc.setElementClass(btnIcon, 'kd-close-round', _isOpen);
        }
    }
    _setCollapseIcon(_isOpen) {
        let direction = this._domElemSvc.getDocumentDirection(true);
        let oppDirection = (direction === 'left') ? 'right' : 'left';
        let btnIcon = this.el.nativeElement.querySelector('.menu-btn i');
        if (this._splitterLevel === 'main' && btnIcon !== null) {
            this._domElemSvc.setElementClass(btnIcon, 'fa-angle-' + direction, !_isOpen);
            this._domElemSvc.setElementClass(btnIcon, 'fa-angle-' + oppDirection, _isOpen);
        }
    }
    _setTint(_add) {
        let isMobile = this._domElemSvc.isMobile();
        let overlayDiv = this._panes[1].element.nativeElement.querySelector('.content-overlay');
        if (overlayDiv === null) {
            overlayDiv = this._domElemSvc.createElement(this._panes[1].element.nativeElement, 'content-overlay');
            this._renderer.listen(overlayDiv, 'click', (event) => {
                this._splitterEvent.fire();
            });
        }
        if (isMobile) {
            this._domElemSvc.setElementClass(overlayDiv, 'show', _add);
            if (this._splitterLevel === 'main') {
                let contentArea = this._panes[1].element.nativeElement.querySelector('.main-wrapper');
                // console.log(contentArea);
                if (contentArea) {
                    let contentAreaHeight = contentArea.getBoundingClientRect().height;
                    let paneHeight = this._panes[1].element.nativeElement.getBoundingClientRect().height;
                    // console.log(paneHeight);
                    // console.log(contentAreaHeight);
                    if (contentAreaHeight > paneHeight) {
                        this._domElemSvc.setElementStyle(overlayDiv, 'bottom', 'auto');
                        this._domElemSvc.setElementStyle(overlayDiv, 'height', contentAreaHeight + 'px');
                    }
                }
                this._domElemSvc.setElementClass(this._panes[1].element.nativeElement, 'no-overflow', _add);
            }
        }
    }
    _onDrag(event) {
        if (this._disableDrag)
            return;
        if (!this._isDrag)
            return;
        let direction = this._domElemSvc.getDocumentDirection(true);
        // let selectedPaneBounds: any = this._selectedElem.getBoundingClientRect();
        let splitterBounds = this.el.nativeElement.getBoundingClientRect();
        let moveX = Math.abs(event.clientX - splitterBounds[direction]);
        // console.log(moveX);
        // let newWidth: number = selectedPaneBounds.width - moveX;
        // console.log(newWidth);
        let newSize = this._convertionSvc.convertPxToPercent(moveX, splitterBounds.width);
        // console.log('newSize = '+newSize);
        this._domElemSvc.removeClass(this._selectedElem, 'animation');
        this._updateSplitPaneSize(newSize, splitterBounds.width);
        this._splitterEvent.drag(this._splitterLevel);
    }
    _onResize(event) {
        let isMobile = this._domElemSvc.isMobile();
        if (isMobile !== this._prevIsMobile) {
            this._isFirstSwitchViewPort = true;
            this._prevIsMobile = isMobile;
            this._isSubPaneOpen = false;
        }
        this._setDefaultPaneSize();
        this._isFirstSwitchViewPort = false;
    }
}
KdSplitter.decorators = [
    { type: Component, args: [{
                selector: 'kd-splitter',
                template: `<div class='split-container {{orientation}}'><ng-content></ng-content></div>`,
                encapsulation: ViewEncapsulation.None,
                providers: [KdSplitterSvc, KdSplitterEvent, KdConvertionSvc, KdDomElemSvc],
                host: { 'class': 'kdx-split-panes' }
            },] }
];
KdSplitter.ctorParameters = () => [
    { type: ViewContainerRef },
    { type: Renderer2 },
    { type: KdSplitterSvc },
    { type: KdConvertionSvc },
    { type: KdDomElemSvc },
    { type: KdSplitterEvent },
    { type: Router }
];
KdSplitter.propDecorators = {
    orientation: [{ type: Input }],
    floatbtn: [{ type: Input }],
    collapsible: [{ type: Input }],
    onMousemove: [{ type: HostListener, args: ['document:mousemove', ['$event'],] }],
    onMouseup: [{ type: HostListener, args: ['document:mouseup', ['$event'],] }],
    onResize: [{ type: HostListener, args: ['window:resize', ['$event'],] }]
};
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoia2Qtc3BsaXR0ZXIuanMiLCJzb3VyY2VSb290IjoiRDovb3BlbkVNSVMvc3R5bGVndWlkZS9pb3N0Zy1vcGVuZW1pcy1zdHlsZWd1aWRlL3Byb2plY3RzL29wZW5lbWlzLXN0eWxlZ3VpZGUtbGliL3NyYy8iLCJzb3VyY2VzIjpbImtkLWNvbXBvbmVudHMva2QtYW5ndWxhci1zcGxpdHRlci9zcmMva2Qtc3BsaXR0ZXIudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsT0FBTyxFQUFFLFNBQVMsRUFBRSxLQUFLLEVBQVUsWUFBWSxFQUFFLGlCQUFpQixFQUFFLGdCQUFnQixFQUE2QixTQUFTLEVBQUUsTUFBTSxlQUFlLENBQUM7QUFDbEosT0FBTyxFQUFFLE1BQU0sRUFBRSxhQUFhLEVBQUUsTUFBTSxpQkFBaUIsQ0FBQztBQUN4RCxPQUFPLEVBQUUsS0FBSyxFQUFFLE1BQU0sTUFBTSxDQUFDO0FBRTdCLE9BQU8sRUFBRSxlQUFlLEVBQUUsWUFBWSxFQUFFLE1BQU0sdUJBQXVCLENBQUM7QUFDdEUsT0FBTyxFQUFFLGFBQWEsRUFBRSxNQUFNLG1CQUFtQixDQUFDO0FBQ2xELE9BQU8sRUFBRSxlQUFlLEVBQUUsTUFBTSxxQkFBcUIsQ0FBQztBQVV0RCxNQUFNLE9BQU8sVUFBVTtJQTBCbkIsWUFDWSxJQUFzQixFQUN0QixTQUFvQixFQUNwQixZQUEyQixFQUMzQixjQUErQixFQUMvQixXQUF5QixFQUN6QixjQUErQixFQUMvQixPQUFlO1FBTmYsU0FBSSxHQUFKLElBQUksQ0FBa0I7UUFDdEIsY0FBUyxHQUFULFNBQVMsQ0FBVztRQUNwQixpQkFBWSxHQUFaLFlBQVksQ0FBZTtRQUMzQixtQkFBYyxHQUFkLGNBQWMsQ0FBaUI7UUFDL0IsZ0JBQVcsR0FBWCxXQUFXLENBQWM7UUFDekIsbUJBQWMsR0FBZCxjQUFjLENBQWlCO1FBQy9CLFlBQU8sR0FBUCxPQUFPLENBQVE7UUE5Qm5CLFlBQU8sR0FBWSxLQUFLLENBQUM7UUFDekIsaUJBQVksR0FBWSxLQUFLLENBQUM7UUFDOUIsd0JBQW1CLEdBQVEsRUFBRSxDQUFDO1FBQzlCLFdBQU0sR0FBa0IsRUFBRSxDQUFDO1FBR25DLGlDQUFpQztRQUN6Qix3QkFBbUIsR0FBWSxLQUFLLENBQUM7UUFDckMsbUJBQWMsR0FBVyxFQUFFLENBQUM7UUFDNUIsb0JBQWUsR0FBWSxLQUFLLENBQUM7UUFDakMsMkJBQXNCLEdBQVksS0FBSyxDQUFDO1FBQ3hDLGtCQUFhLEdBQVksS0FBSyxDQUFDO1FBQy9CLG1CQUFjLEdBQVksS0FBSyxDQUFDO1FBQ2hDLG1CQUFjLEdBQVcsRUFBRSxDQUFDO1FBQzVCLGlCQUFZLEdBQVcsVUFBVSxDQUFDO1FBQ2xDLDJCQUFzQixHQUFZLElBQUksQ0FBQztRQUN2QyxvQkFBZSxHQUFXLENBQUMsQ0FBQztRQUM1QixnQkFBVyxHQUFZLEtBQUssQ0FBQztRQWVqQyxJQUFJLENBQUMsRUFBRSxHQUFHLElBQUksQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDO0lBQ2hDLENBQUM7SUFHRCxXQUFXLENBQUMsS0FBVTtRQUNsQiw4QkFBOEI7UUFDOUIsSUFBSSxDQUFDLE9BQU8sQ0FBQyxLQUFLLENBQUMsQ0FBQztJQUV4QixDQUFDO0lBR0QsU0FBUyxDQUFDLEtBQVU7UUFDaEIsNEJBQTRCO1FBQzVCLElBQUksQ0FBQyxPQUFPLEdBQUcsS0FBSyxDQUFDO0lBQ3pCLENBQUM7SUFHRCxRQUFRLENBQUMsS0FBVTtRQUNmLHlCQUF5QjtRQUN6QixJQUFJLENBQUMsU0FBUyxDQUFDLEtBQUssQ0FBQyxDQUFDO0lBQzFCLENBQUM7SUFFRCxRQUFRO1FBQ0osSUFBSSxDQUFDLGFBQWEsR0FBRyxJQUFJLENBQUMsV0FBVyxDQUFDLFFBQVEsRUFBRSxDQUFDO1FBQ2pELElBQUksQ0FBQyxlQUFlLEdBQUcsSUFBSSxDQUFDLGNBQWMsQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxDQUFDO1FBQ3BFLElBQUksQ0FBQyxzQkFBc0IsR0FBRyxJQUFJLENBQUMsY0FBYyxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFDLENBQUM7UUFDOUUsb0ZBQW9GO1FBQ3BGLHlDQUF5QztJQUM3QyxDQUFDO0lBRUQsZUFBZTtRQUNYLElBQUksQ0FBQyxtQkFBbUIsR0FBRyxJQUFJLENBQUMsWUFBWSxDQUFDLHNCQUFzQixDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQztRQUNqRixJQUFJLENBQUMsWUFBWSxHQUFHLElBQUksQ0FBQyxZQUFZLENBQUMsYUFBYSxFQUFFLENBQUM7UUFFdEQsSUFBSSxJQUFJLENBQUMsWUFBWSxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDLGFBQWEsQ0FBQyxFQUFFO1lBQ3BELHVDQUF1QztZQUN2QyxJQUFJLENBQUMsY0FBYyxHQUFHLEtBQUssQ0FBQztZQUM1QixJQUFJLFFBQVEsR0FBZ0IsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsYUFBYSxDQUFDO1lBQ2pFLElBQUksQ0FBQyxlQUFlLEdBQUcsUUFBUSxDQUFDLHFCQUFxQixFQUFFLENBQUMsS0FBSyxDQUFDO1NBQ2pFO2FBQ0k7WUFDRCx3Q0FBd0M7WUFDeEMsSUFBSSxDQUFDLGNBQWMsR0FBRyxNQUFNLENBQUM7WUFFN0IsSUFBSSxDQUFDLHNCQUFzQixFQUFFLENBQUM7WUFDOUIsSUFBSSxDQUFDLFFBQVEsQ0FBQyxLQUFLLENBQUMsQ0FBQztTQUN4QjtRQUNELCtCQUErQjtRQUMvQix3QkFBd0I7UUFDeEIsMEJBQTBCO1FBQzFCLE1BQU07UUFDTixpQkFBaUI7UUFDakIsSUFBSSxDQUFDLGNBQWMsR0FBRyxJQUFJLENBQUMsY0FBYyxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFDLGdCQUFnQixFQUFFLEVBQUUsR0FBRyxDQUFDLEdBQUcsWUFBWSxHQUFHLElBQUksQ0FBQyxjQUFjLENBQUM7UUFFbkksSUFBSSxDQUFDLG1CQUFtQixFQUFFLENBQUM7UUFDM0IsSUFBSSxDQUFDLHFCQUFxQixFQUFFLENBQUM7UUFDN0IsSUFBSSxDQUFDLHNCQUFzQixFQUFFLENBQUM7UUFFOUIsSUFBSSxDQUFDLHNCQUFzQixHQUFHLEtBQUssQ0FBQztRQUVwQyxJQUFJLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxTQUFTLENBQUMsS0FBSyxDQUFDLEVBQUU7WUFDbEMsSUFBSSxLQUFLLFlBQVksYUFBYSxFQUFFO2dCQUNoQywwQkFBMEI7Z0JBQzFCLEtBQUssSUFBSSxHQUFHLElBQUksSUFBSSxDQUFDLE1BQU0sRUFBRTtvQkFDekIsSUFBSSxJQUFJLENBQUMsTUFBTSxDQUFDLGNBQWMsQ0FBQyxHQUFHLENBQUMsRUFBRTt3QkFDakMsSUFBSSxJQUFJLEdBQVcsSUFBSSxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsQ0FBQzt3QkFDcEMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxhQUFhLENBQUMsU0FBUyxHQUFHLENBQUMsQ0FBQztxQkFDNUM7aUJBQ0o7YUFDSjtRQUNMLENBQUMsQ0FBQyxDQUFDO0lBQ1AsQ0FBQztJQUVELFFBQVEsQ0FBQyxJQUFZO1FBQ2pCLElBQUksQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDO1FBQ3ZCLE9BQU8sSUFBSSxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUM7SUFDOUIsQ0FBQztJQUVELFlBQVksQ0FBQyxLQUFhO1FBQ3RCLElBQUksQ0FBQyxtQkFBbUIsR0FBRyxJQUFJLENBQUMsWUFBWSxDQUFDLHNCQUFzQixDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQztRQUNqRixJQUFJLEtBQUssS0FBSyxNQUFNLEVBQUU7WUFDbEIseURBQXlEO1lBQ3pELElBQUksQ0FBQyxtQkFBbUIsQ0FBQyxLQUFLLENBQUMsQ0FBQztZQUNoQyxJQUFJLFlBQVksR0FBRyxJQUFJLENBQUMsRUFBRSxDQUFDLGFBQWEsQ0FBQyxxQkFBcUIsRUFBRSxDQUFDO1lBQ2pFLElBQUksWUFBWSxFQUFFO2dCQUNkLG1DQUFtQztnQkFDbkMsSUFBSSxDQUFDLGVBQWUsR0FBRyxJQUFJLENBQUMsbUJBQW1CLENBQUMsS0FBSyxDQUFDLElBQUksR0FBRyxZQUFZLENBQUMsS0FBSyxDQUFDO2FBQ25GO1NBQ0o7SUFDTCxDQUFDO0lBRU8sc0JBQXNCO1FBQzFCLElBQUksQ0FBQyxjQUFjLENBQUMsRUFBRSxFQUFFO2FBQ25CLFNBQVMsQ0FBQyxPQUFPLENBQUMsRUFBRTtZQUNqQix3QkFBd0I7WUFDeEIsSUFBSSxTQUFTLEdBQVcsSUFBSSxDQUFDLFdBQVcsQ0FBQyxvQkFBb0IsQ0FBQyxJQUFJLENBQUMsQ0FBQztZQUNwRSxJQUFJLFlBQVksR0FBVyxTQUFTLEtBQUssTUFBTSxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQztZQUNuRSxJQUFJLFNBQVMsR0FBVyxlQUFlLEdBQUcsWUFBWSxDQUFDO1lBQ3ZELElBQUksUUFBUSxHQUFZLElBQUksQ0FBQyxXQUFXLENBQUMsUUFBUSxFQUFFLENBQUM7WUFDcEQsSUFBSSxLQUFLLEdBQVcsQ0FBQyxDQUFDO1lBRXRCLEtBQUssSUFBSSxHQUFHLElBQUksSUFBSSxDQUFDLE1BQU0sRUFBRTtnQkFDekIsSUFBSSxJQUFJLENBQUMsTUFBTSxDQUFDLGNBQWMsQ0FBQyxHQUFHLENBQUMsRUFBRTtvQkFDakMsSUFBSSxJQUFJLEdBQVcsSUFBSSxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsQ0FBQztvQkFDcEMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxlQUFlLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxhQUFhLEVBQUUsV0FBVyxFQUFFLFFBQVEsQ0FBQyxDQUFDO29CQUVwRixJQUFJLEtBQUssS0FBSyxDQUFDLEVBQUU7d0JBQ2IsSUFBSSxDQUFDLFFBQVEsRUFBRTs0QkFDWCxJQUFJLENBQUMsV0FBVyxDQUFDLFdBQVcsQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLGFBQWEsRUFBRSxTQUFTLENBQUMsQ0FBQzt5QkFDdkU7NkJBQ0k7NEJBQ0QsSUFBSSxDQUFDLFdBQVcsR0FBRyxDQUFDLElBQUksQ0FBQyxXQUFXLENBQUM7NEJBQ3JDLElBQUksSUFBSSxDQUFDLGNBQWMsS0FBSyxNQUFNLEVBQUU7Z0NBQ2hDLGdFQUFnRTtnQ0FDaEUsSUFBSSxDQUFDLFdBQVcsQ0FBQyxlQUFlLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxhQUFhLEVBQUUsU0FBUyxFQUFFLElBQUksQ0FBQyxXQUFXLENBQUMsQ0FBQztnQ0FDMUYsSUFBSSxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFDLENBQUM7NkJBQ25DO3lCQUNKO3FCQUNKO3lCQUNJO3dCQUNELElBQUksUUFBUSxJQUFJLElBQUksQ0FBQyxjQUFjLEtBQUssS0FBSyxFQUFFOzRCQUMzQywyQkFBMkI7eUJBQzlCO3FCQUNKO29CQUNELEtBQUssRUFBRSxDQUFDO2lCQUNYO2FBQ0o7UUFDTCxDQUFDLENBQUMsQ0FBQztJQUNYLENBQUM7SUFFTyxxQkFBcUI7UUFDekIsS0FBSyxJQUFJLENBQUMsR0FBVyxDQUFDLEVBQUUsQ0FBQyxHQUFHLElBQUksQ0FBQyxNQUFNLENBQUMsTUFBTSxFQUFFLENBQUMsRUFBRSxFQUFFO1lBQ2pELElBQUksS0FBSyxHQUFXLENBQUMsR0FBRyxDQUFDLENBQUM7WUFDMUIsSUFBSSxTQUFTLEdBQVcsS0FBSyxHQUFHLEtBQUssQ0FBQztZQUV0QyxJQUFJLEtBQUssR0FBZ0IsSUFBSSxDQUFDLFdBQVcsQ0FBQyxhQUFhLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsYUFBYSxFQUFFLG1CQUFtQixHQUFHLFNBQVMsQ0FBQyxDQUFDO1lBQy9ILElBQUksQ0FBQyxXQUFXLENBQUMsZUFBZSxDQUFDLEtBQUssRUFBRSxVQUFVLEVBQUUsSUFBSSxDQUFDLFlBQVksQ0FBQyxDQUFDO1lBRXZFLHlCQUF5QjtZQUN6Qix5QkFBeUI7WUFDckMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxNQUFNLENBQUMsS0FBSyxFQUFFLFdBQVcsRUFBRSxDQUFDLEtBQVUsRUFBUSxFQUFFO2dCQUMzRCxJQUFJLENBQUMsYUFBYSxHQUFHLEtBQUssQ0FBQyxNQUFNLENBQUMsYUFBYSxDQUFDO2dCQUNoRCxJQUFJLENBQUMsd0JBQXdCLEdBQUcsSUFBSSxDQUFDLGFBQWEsQ0FBQyxzQkFBc0IsQ0FBQztnQkFDMUUsSUFBSSxDQUFDLE9BQU8sR0FBRyxJQUFJLENBQUM7WUFDeEIsQ0FBQyxDQUFDLENBQUM7WUFFUyxJQUFJLElBQUksQ0FBQyxjQUFjLEtBQUssTUFBTSxFQUFFO2dCQUNoQyxJQUFJLENBQUMsb0JBQW9CLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsRUFBRSxLQUFLLENBQUMsQ0FBQzthQUNwRDtTQUNKO0lBQ0wsQ0FBQztJQUVPLG9CQUFvQixDQUFDLEtBQWEsRUFBRSxNQUFjO1FBQ3RELElBQUksU0FBUyxHQUFXLEtBQUssR0FBRyxNQUFNLENBQUM7UUFDdkMsSUFBSSxNQUFNLEdBQWdCLElBQUksQ0FBQyxXQUFXLENBQUMsYUFBYSxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsYUFBYSxFQUFFLFdBQVcsR0FBRyxTQUFTLENBQUMsQ0FBQztRQUUvRyxhQUFhO1FBQ2IsSUFBSSxDQUFDLFdBQVcsQ0FBQyxhQUFhLENBQUMsTUFBTSxFQUFFLElBQUksRUFBRSxHQUFHLENBQUMsQ0FBQztRQUNsRCxJQUFJLENBQUMsZ0JBQWdCLENBQUMsSUFBSSxDQUFDLG1CQUFtQixDQUFDLENBQUM7UUFDaEQseUJBQXlCO1FBQ3pCLHlCQUF5QjtRQUNqQyxJQUFJLENBQUMsU0FBUyxDQUFDLE1BQU0sQ0FBQyxNQUFNLEVBQUUsT0FBTyxFQUFFLENBQUMsS0FBVSxFQUFRLEVBQUU7WUFDeEQsc0JBQXNCO1lBQ3RCLElBQUksQ0FBQyxPQUFPLEdBQUcsS0FBSyxDQUFDO1lBQ3JCLElBQUksQ0FBQyxtQkFBbUIsQ0FBQyxLQUFLLENBQUMsQ0FBQztRQUNwQyxDQUFDLENBQUMsQ0FBQztJQUNDLENBQUM7SUFFTyxtQkFBbUIsQ0FBQyxtQkFBNEIsSUFBSTtRQUN4RCxJQUFJLEtBQUssR0FBVyxDQUFDLENBQUM7UUFDdEIsSUFBSSxPQUFPLEdBQVcsQ0FBQyxDQUFDO1FBQ3hCLElBQUksU0FBUyxHQUFXLElBQUksQ0FBQyxXQUFXLENBQUMsb0JBQW9CLENBQUMsSUFBSSxDQUFDLENBQUM7UUFDcEUsSUFBSSxZQUFZLEdBQVcsU0FBUyxLQUFLLE1BQU0sQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUM7UUFDbkUsSUFBSSxZQUFZLEdBQVEsSUFBSSxDQUFDLFlBQVksQ0FBQyxlQUFlLENBQUMsSUFBSSxDQUFDLGNBQWMsRUFBRSxTQUFTLENBQUMsQ0FBQztRQUMxRixJQUFJLFFBQVEsR0FBWSxJQUFJLENBQUMsV0FBVyxDQUFDLFFBQVEsRUFBRSxDQUFDO1FBQ3BELElBQUksWUFBWSxHQUFRLElBQUksQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLGNBQWMsQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLGNBQWMsR0FBRyxJQUFJLENBQUMsWUFBWSxDQUFDLENBQUMsQ0FBQztRQUMzRyw2QkFBNkI7UUFDN0Isd0dBQXdHO1FBQ3hHLEtBQUssSUFBSSxHQUFHLElBQUksSUFBSSxDQUFDLG1CQUFtQixFQUFFO1lBQ3RDLElBQUksSUFBSSxDQUFDLG1CQUFtQixDQUFDLGNBQWMsQ0FBQyxHQUFHLENBQUMsRUFBRTtnQkFDOUMsSUFBSSxJQUFJLEdBQVcsSUFBSSxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsQ0FBQztnQkFDdEMsSUFBSSxVQUFVLEdBQVE7b0JBQ2xCLEtBQUssRUFBRSxDQUFDLElBQUksQ0FBQyxtQkFBbUIsQ0FBQyxHQUFHLENBQUMsQ0FBQyxJQUFJLEdBQUcsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLG1CQUFtQixDQUFDLEdBQUcsQ0FBQyxDQUFDLElBQUk7aUJBQy9GLENBQUM7Z0JBQ0YsVUFBVSxDQUFDLFNBQVMsQ0FBQyxHQUFHLE9BQU8sQ0FBQztnQkFFaEMsSUFBSSxRQUFRLEVBQUU7b0JBQ1YsVUFBVSxHQUFHLE1BQU0sQ0FBQyxNQUFNLENBQUMsRUFBRSxFQUFFLFVBQVUsRUFBRSxZQUFZLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQztvQkFDOUQsSUFBSSxDQUFDLFdBQVcsR0FBRyxLQUFLLENBQUM7b0JBQ3pCLElBQUksS0FBSyxLQUFLLENBQUMsRUFBRTt3QkFDYiw4QkFBOEI7d0JBQzlCLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxJQUFJLEVBQUUsS0FBSyxDQUFDLENBQUM7cUJBQ3hDO29CQUNELHNDQUFzQztpQkFDekM7cUJBQ0k7b0JBQ0QsSUFBSSxZQUFZLEtBQUssSUFBSSxJQUFJLGdCQUFnQixFQUFFO3dCQUMzQyxJQUFJLFFBQVEsR0FBVyxNQUFNLEdBQUcsQ0FBQyxLQUFLLEdBQUcsQ0FBQyxDQUFDLENBQUM7d0JBQzVDLFVBQVUsR0FBRyxNQUFNLENBQUMsTUFBTSxDQUFDLEVBQUUsRUFBRSxVQUFVLEVBQUUsWUFBWSxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUM7cUJBQ3RFO29CQUNELDJCQUEyQjtvQkFDM0IsSUFBSSxDQUFDLG1CQUFtQixFQUFFLENBQUM7b0JBRTNCLElBQUksQ0FBQyxXQUFXLENBQUMsV0FBVyxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsYUFBYSxFQUFFLGVBQWUsR0FBRyxZQUFZLENBQUMsQ0FBQztvQkFFekYsSUFBSSxJQUFJLENBQUMsY0FBYyxLQUFLLEtBQUssSUFBSSxLQUFLLEtBQUssQ0FBQyxJQUFJLElBQUksQ0FBQyxzQkFBc0IsRUFBRTt3QkFDN0UsSUFBSSxhQUFhLEdBQVksQ0FBQyxJQUFJLENBQUMsbUJBQW1CLENBQUMsR0FBRyxDQUFDLENBQUMsSUFBSSxLQUFLLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsbUJBQW1CLENBQUMsR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUM7d0JBQzVILElBQUksQ0FBQyw2QkFBNkIsQ0FBQyxhQUFhLEVBQUUsS0FBSyxDQUFDLENBQUM7cUJBQzVEO2lCQUNKO2dCQUVELEtBQUssSUFBSSxJQUFJLElBQUksVUFBVSxFQUFFO29CQUN6QixJQUFJLFVBQVUsQ0FBQyxjQUFjLENBQUMsSUFBSSxDQUFDLEVBQUU7d0JBQ2pDLElBQUksQ0FBQyxXQUFXLENBQUMsZUFBZSxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsYUFBYSxFQUFFLElBQUksRUFBRSxVQUFVLENBQUMsSUFBSSxDQUFDLEdBQUcsR0FBRyxDQUFDLENBQUM7cUJBQzlGO2lCQUNKO2dCQUNELEtBQUssRUFBRSxDQUFDO2dCQUNSLE9BQU8sSUFBSSxVQUFVLENBQUMsS0FBSyxDQUFDO2FBQy9CO1NBQ0o7SUFDTCxDQUFDO0lBRU8sb0JBQW9CLENBQUMsS0FBYSxFQUFFLFVBQWtCO1FBQzFELElBQUksSUFBSSxDQUFDLFdBQVcsQ0FBQyxRQUFRLEVBQUU7WUFBRSxPQUFPO1FBQ3hDLElBQUksQ0FBQyxJQUFJLENBQUMsT0FBTztZQUFFLE9BQU87UUFFMUIsSUFBSSxTQUFTLEdBQVcsSUFBSSxDQUFDLFdBQVcsQ0FBQyxvQkFBb0IsQ0FBQyxJQUFJLENBQUMsQ0FBQztRQUNwRSxJQUFJLFNBQVMsR0FBVyxDQUFDLElBQUksQ0FBQyxXQUFXLEtBQUssVUFBVSxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDO1FBQy9FLElBQUksa0JBQWtCLEdBQVEsSUFBSSxDQUFDLGFBQWEsQ0FBQyxxQkFBcUIsRUFBRSxDQUFDO1FBQ3pFLElBQUksc0JBQXNCLEdBQVEsSUFBSSxDQUFDLHdCQUF3QixDQUFDLHFCQUFxQixFQUFFLENBQUM7UUFFeEYsa0JBQWtCLEdBQUcsQ0FBQyxJQUFJLENBQUMsV0FBVyxLQUFLLFVBQVUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxrQkFBa0IsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLGtCQUFrQixDQUFDLEtBQUssQ0FBQztRQUM5RyxzQkFBc0IsR0FBRyxDQUFDLElBQUksQ0FBQyxXQUFXLEtBQUssVUFBVSxDQUFDLENBQUMsQ0FBQyxDQUFDLHNCQUFzQixDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsc0JBQXNCLENBQUMsS0FBSyxDQUFDO1FBRTFILElBQUksY0FBYyxHQUFXLElBQUksQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLGNBQWMsQ0FBQyxrQkFBa0IsQ0FBQyxzQkFBc0IsR0FBRyxrQkFBa0IsRUFBRSxVQUFVLENBQUMsQ0FBQyxDQUFDO1FBRXpJLElBQUksS0FBSyxHQUFXLElBQUksQ0FBQyxZQUFZLENBQUMsb0JBQW9CLENBQUMsS0FBSyxDQUFDLENBQUM7UUFDbEUsY0FBYyxHQUFHLElBQUksQ0FBQyxZQUFZLENBQUMsb0JBQW9CLENBQUMsY0FBYyxDQUFDLENBQUM7UUFFeEUsSUFBSSxtQkFBbUIsR0FBVyxJQUFJLENBQUMsY0FBYyxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsd0JBQXdCLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxFQUFFLEdBQUcsQ0FBQyxDQUFDO1FBQ2pILEtBQUssR0FBRyxJQUFJLENBQUMsWUFBWSxDQUFDLGdCQUFnQixDQUFDLElBQUksQ0FBQyxtQkFBbUIsRUFBRSxtQkFBbUIsRUFBRSxLQUFLLENBQUMsQ0FBQztRQUVqRyxJQUFJLE9BQU8sR0FBVyxjQUFjLEdBQUcsS0FBSyxDQUFDO1FBRTdDLElBQUksbUJBQW1CLEdBQVE7WUFDM0IsS0FBSyxFQUFFLEVBQUU7WUFDVCxLQUFLLEVBQUUsRUFBRTtTQUNaLENBQUM7UUFDRixtQkFBbUIsQ0FBQyxPQUFPLENBQUMsQ0FBQyxTQUFTLENBQUMsR0FBRyxLQUFLLENBQUM7UUFDaEQsbUJBQW1CLENBQUMsT0FBTyxDQUFDLENBQUMsU0FBUyxDQUFDLEdBQUcsS0FBSyxDQUFDO1FBQ2hELG1CQUFtQixDQUFDLE9BQU8sQ0FBQyxDQUFDLFNBQVMsQ0FBQyxHQUFHLE9BQU8sQ0FBQztRQUNsRCxNQUFNLENBQUMsY0FBYyxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsY0FBYyxHQUFHLElBQUksQ0FBQyxZQUFZLEVBQUUsSUFBSSxDQUFDLFNBQVMsQ0FBQyxtQkFBbUIsQ0FBQyxDQUFDLENBQUM7UUFFNUcsSUFBSSxDQUFDLFdBQVcsQ0FBQyxlQUFlLENBQUMsSUFBSSxDQUFDLHdCQUF3QixFQUFFLFNBQVMsRUFBRSxLQUFLLEdBQUcsR0FBRyxDQUFDLENBQUM7UUFDeEYsSUFBSSxDQUFDLFdBQVcsQ0FBQyxlQUFlLENBQUMsSUFBSSxDQUFDLGFBQWEsRUFBRSxTQUFTLEVBQUUsS0FBSyxHQUFHLEdBQUcsQ0FBQyxDQUFDO1FBQzdFLElBQUksQ0FBQyxXQUFXLENBQUMsZUFBZSxDQUFDLElBQUksQ0FBQyxhQUFhLEVBQUUsU0FBUyxFQUFFLE9BQU8sR0FBRyxHQUFHLENBQUMsQ0FBQztJQUVuRixDQUFDO0lBRU8sbUJBQW1CLENBQUMsS0FBYTtRQUNyQyxJQUFJLFNBQVMsR0FBVyxJQUFJLENBQUMsV0FBVyxDQUFDLG9CQUFvQixDQUFDLElBQUksQ0FBQyxDQUFDO1FBQ3BFLElBQUksQ0FBQyxtQkFBbUIsR0FBRyxDQUFDLElBQUksQ0FBQyxtQkFBbUIsQ0FBQztRQUVyRCxJQUFJLENBQUMsV0FBVyxDQUFDLFFBQVEsQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLGFBQWEsRUFBRSxXQUFXLENBQUMsQ0FBQztRQUNwRSxJQUFJLENBQUMsV0FBVyxDQUFDLGVBQWUsQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLGFBQWEsRUFBRSxlQUFlLEdBQUcsU0FBUyxFQUFFLElBQUksQ0FBQyxtQkFBbUIsQ0FBQyxDQUFDO1FBQ3JILElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxJQUFJLENBQUMsbUJBQW1CLENBQUMsQ0FBQztRQUNoRCxJQUFJLENBQUMsY0FBYyxDQUFDLFVBQVUsRUFBRSxDQUFDO0lBQ3JDLENBQUM7SUFFTyxtQkFBbUI7UUFDdkIsSUFBSSxDQUFDLFdBQVcsQ0FBQyxvQkFBb0IsQ0FBQyxTQUFTLEVBQUUsSUFBSSxDQUFDLEVBQUUsQ0FBQyxhQUFhLENBQUMsQ0FBQztJQUM1RSxDQUFDO0lBRU8sa0JBQWtCLENBQUMsS0FBYSxFQUFFLE1BQWM7UUFDcEQsSUFBSSxRQUFRLEdBQVksSUFBSSxDQUFDLFdBQVcsQ0FBQyxRQUFRLEVBQUUsQ0FBQztRQUNwRCxJQUFJLFFBQVEsR0FBZ0IsSUFBSSxDQUFDLEVBQUUsQ0FBQyxhQUFhLENBQUMsYUFBYSxDQUFDLFNBQVMsQ0FBQyxDQUFDO1FBQzNFLElBQUksUUFBUSxJQUFJLElBQUksQ0FBQyxjQUFjLEtBQUssS0FBSyxJQUFJLFFBQVEsS0FBSyxJQUFJLElBQUksSUFBSSxDQUFDLGVBQWUsRUFBRTtZQUN4RiwyQkFBMkI7WUFDM0IsNENBQTRDO1lBQzVDLElBQUksU0FBUyxHQUFXLFFBQVEsQ0FBQztZQUVqQyxJQUFJLE1BQU0sR0FBZ0IsSUFBSSxDQUFDLFdBQVcsQ0FBQyxhQUFhLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxhQUFhLEVBQUUsa0RBQWtELEdBQUcsU0FBUyxDQUFDLENBQUM7WUFFaEosZUFBZTtZQUNmLFdBQVcsR0FBRyxJQUFJLENBQUMsV0FBVyxDQUFDLGFBQWEsQ0FBQyxNQUFNLEVBQUUsSUFBSSxFQUFFLEdBQUcsQ0FBQyxDQUFDO1lBQ2hFLElBQUksQ0FBQyxhQUFhLENBQUMsSUFBSSxDQUFDLGNBQWMsQ0FBQyxDQUFDO1lBRXhDLDJCQUEyQjtZQUMzQiwyQkFBMkI7WUFDdkMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxNQUFNLENBQUMsTUFBTSxFQUFFLE9BQU8sRUFBRSxDQUFDLEtBQVUsRUFBUSxFQUFFO2dCQUN4RCxJQUFJLENBQUMsY0FBYyxHQUFHLENBQUMsSUFBSSxDQUFDLGNBQWMsQ0FBQztnQkFDM0MsSUFBSSxDQUFDLGNBQWMsQ0FBQyxhQUFhLENBQUMsSUFBSSxDQUFDLGNBQWMsQ0FBQyxDQUFDO1lBQzNELENBQUMsQ0FBQyxDQUFDO1NBQ007SUFDTCxDQUFDO0lBRU8sc0JBQXNCO1FBQzFCLElBQUksSUFBSSxDQUFDLGNBQWMsS0FBSyxLQUFLLEVBQUU7WUFDL0IsSUFBSSxDQUFDLGNBQWMsQ0FBQyxlQUFlLEVBQUU7aUJBQ2hDLFNBQVMsQ0FBQyxhQUFhLENBQUMsRUFBRTtnQkFDdkIsSUFBSSxDQUFDLDZCQUE2QixDQUFDLGFBQWEsQ0FBQyxDQUFDO1lBQ3RELENBQUMsQ0FBQyxDQUFDO1NBQ1Y7SUFDTCxDQUFDO0lBRU8sNkJBQTZCLENBQUMsYUFBc0IsRUFBRSxRQUFrQjtRQUM1RSxtQ0FBbUM7UUFDbkMsUUFBUSxHQUFHLENBQUMsT0FBTyxRQUFRLEtBQUssV0FBVyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDO1FBQy9ELElBQUksU0FBUyxHQUFnQixJQUFJLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxhQUFhLENBQUM7UUFDbEUsSUFBSSxRQUFRLEdBQWdCLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLGFBQWEsQ0FBQztRQUNqRSxJQUFJLFFBQVEsR0FBWSxJQUFJLENBQUMsV0FBVyxDQUFDLFFBQVEsRUFBRSxDQUFDO1FBQ3BELElBQUksV0FBVyxHQUFZLENBQUMsSUFBSSxDQUFDLGNBQWMsS0FBSyxhQUFhLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUM7UUFDbEYsSUFBSSxDQUFDLGNBQWMsR0FBRyxhQUFhLENBQUM7UUFDcEMsSUFBSSxRQUFRLEVBQUU7WUFDVixJQUFJLENBQUMsV0FBVyxDQUFDLFFBQVEsQ0FBQyxTQUFTLEVBQUUsV0FBVyxDQUFDLENBQUM7WUFDbEQsSUFBSSxDQUFDLFdBQVcsQ0FBQyxRQUFRLENBQUMsUUFBUSxFQUFFLFdBQVcsQ0FBQyxDQUFDO1NBQ3BEO1FBRUQsSUFBSSxRQUFRLElBQUksSUFBSSxDQUFDLHNCQUFzQixFQUFFO1lBQ3pDLDJCQUEyQjtZQUMzQixJQUFJLGdCQUFnQixHQUFXLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDO1lBQ3pELElBQUksU0FBUyxHQUFXLElBQUksQ0FBQyxXQUFXLENBQUMsb0JBQW9CLENBQUMsSUFBSSxDQUFDLENBQUM7WUFDcEUsSUFBSSxZQUFZLEdBQVcsQ0FBQyxTQUFTLEtBQUssTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDO1lBQ3JFLElBQUksUUFBUSxHQUFZLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLGFBQWEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxhQUFhLENBQUM7WUFFcEUsSUFBSSxXQUFXLEdBQWUsQ0FBQyxFQUFFLENBQUMsQ0FBQztZQUNuQyxJQUFJLFFBQVEsRUFBRTtnQkFDVixJQUFJLENBQUMsZUFBZSxHQUFHLFFBQVEsQ0FBQyxxQkFBcUIsRUFBRSxDQUFDLEtBQUssQ0FBQztnQkFDOUQsV0FBVyxHQUFHO29CQUNWLEVBQUUsT0FBTyxFQUFFLElBQUksQ0FBQyxlQUFlLEdBQUcsSUFBSSxFQUFFO29CQUN4QyxFQUFFLE9BQU8sRUFBRSxNQUFNLEVBQUU7aUJBQ3RCLENBQUM7YUFDTDtpQkFDSTtnQkFDRCxXQUFXLEdBQUc7b0JBQ1YsRUFBRSxPQUFPLEVBQUUsTUFBTSxFQUFFO29CQUNuQixFQUFFLE9BQU8sRUFBRSxJQUFJLENBQUMsZUFBZSxHQUFHLElBQUksRUFBRTtpQkFDM0MsQ0FBQzthQUNMO1lBQ0QsSUFBSSxDQUFDLGFBQWEsQ0FBQyxhQUFhLENBQUMsQ0FBQztZQUNsQyxJQUFJLENBQUMsV0FBVyxDQUFDLGVBQWUsQ0FBQyxRQUFRLEVBQUUsWUFBWSxFQUFFLFFBQVEsQ0FBQyxDQUFDO1lBQ25FLElBQUksQ0FBQyxXQUFXLENBQUMsZUFBZSxDQUFDLFNBQVMsRUFBRSxrQkFBa0IsR0FBRyxZQUFZLEdBQUcsR0FBRyxHQUFHLGdCQUFnQixFQUFFLFFBQVEsQ0FBQyxDQUFDO1lBRWxILElBQUksUUFBUSxJQUFJLENBQUMsV0FBVyxFQUFFO2dCQUMxQixJQUFJLENBQUMsV0FBVyxDQUFDLG1CQUFtQixDQUNoQyxRQUFRLEVBQ1IsU0FBUyxFQUNULENBQUMsV0FBVyxFQUFFLEdBQUcsQ0FBQyxDQUNyQixDQUFDO2dCQUVGLEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FBQyxTQUFTLENBQUMsR0FBUyxFQUFFO29CQUM1QixnR0FBZ0c7b0JBQ2hHLElBQUksQ0FBQyxjQUFjLENBQUMsYUFBYSxDQUFDLGFBQWEsQ0FBQyxDQUFDO29CQUNqRCxnRUFBZ0U7Z0JBQ3BFLENBQUMsQ0FBQyxDQUFDO2FBQ047U0FDSjtJQUNMLENBQUM7SUFFTyxhQUFhLENBQUMsT0FBZ0I7UUFDbEMsSUFBSSxPQUFPLEdBQWdCLElBQUksQ0FBQyxFQUFFLENBQUMsYUFBYSxDQUFDLGFBQWEsQ0FBQyxXQUFXLENBQUMsQ0FBQztRQUM1RSxJQUFJLElBQUksQ0FBQyxjQUFjLEtBQUssS0FBSyxJQUFJLE9BQU8sS0FBSyxJQUFJLEVBQUU7WUFDbkQsSUFBSSxDQUFDLFdBQVcsQ0FBQyxlQUFlLENBQUMsT0FBTyxFQUFFLFVBQVUsRUFBRSxDQUFDLE9BQU8sQ0FBQyxDQUFDO1lBQ2hFLElBQUksQ0FBQyxXQUFXLENBQUMsZUFBZSxDQUFDLE9BQU8sRUFBRSxnQkFBZ0IsRUFBRSxPQUFPLENBQUMsQ0FBQztTQUN4RTtJQUNMLENBQUM7SUFFTyxnQkFBZ0IsQ0FBQyxPQUFnQjtRQUNyQyxJQUFJLFNBQVMsR0FBVyxJQUFJLENBQUMsV0FBVyxDQUFDLG9CQUFvQixDQUFDLElBQUksQ0FBQyxDQUFDO1FBQ3BFLElBQUksWUFBWSxHQUFXLENBQUMsU0FBUyxLQUFLLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQztRQUNyRSxJQUFJLE9BQU8sR0FBZ0IsSUFBSSxDQUFDLEVBQUUsQ0FBQyxhQUFhLENBQUMsYUFBYSxDQUFDLGFBQWEsQ0FBQyxDQUFDO1FBRTlFLElBQUksSUFBSSxDQUFDLGNBQWMsS0FBSyxNQUFNLElBQUksT0FBTyxLQUFLLElBQUksRUFBRTtZQUNwRCxJQUFJLENBQUMsV0FBVyxDQUFDLGVBQWUsQ0FBQyxPQUFPLEVBQUUsV0FBVyxHQUFHLFNBQVMsRUFBRSxDQUFDLE9BQU8sQ0FBQyxDQUFDO1lBQzdFLElBQUksQ0FBQyxXQUFXLENBQUMsZUFBZSxDQUFDLE9BQU8sRUFBRSxXQUFXLEdBQUcsWUFBWSxFQUFFLE9BQU8sQ0FBQyxDQUFDO1NBQ2xGO0lBQ0wsQ0FBQztJQUVPLFFBQVEsQ0FBQyxJQUFhO1FBQzFCLElBQUksUUFBUSxHQUFZLElBQUksQ0FBQyxXQUFXLENBQUMsUUFBUSxFQUFFLENBQUM7UUFDcEQsSUFBSSxVQUFVLEdBQWdCLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLGFBQWEsQ0FBQyxhQUFhLENBQUMsa0JBQWtCLENBQUMsQ0FBQztRQUNyRyxJQUFJLFVBQVUsS0FBSyxJQUFJLEVBQUU7WUFDckIsVUFBVSxHQUFHLElBQUksQ0FBQyxXQUFXLENBQUMsYUFBYSxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLGFBQWEsRUFBRSxpQkFBaUIsQ0FBQyxDQUFDO1lBRXJHLElBQUksQ0FBQyxTQUFTLENBQUMsTUFBTSxDQUFDLFVBQVUsRUFBRSxPQUFPLEVBQUUsQ0FBQyxLQUFVLEVBQVEsRUFBRTtnQkFDeEUsSUFBSSxDQUFDLGNBQWMsQ0FBQyxJQUFJLEVBQUUsQ0FBQztZQUMvQixDQUFDLENBQUMsQ0FBQztTQUNNO1FBRUQsSUFBSSxRQUFRLEVBQUU7WUFDVixJQUFJLENBQUMsV0FBVyxDQUFDLGVBQWUsQ0FBQyxVQUFVLEVBQUUsTUFBTSxFQUFFLElBQUksQ0FBQyxDQUFDO1lBQzNELElBQUksSUFBSSxDQUFDLGNBQWMsS0FBSyxNQUFNLEVBQUU7Z0JBQ2hDLElBQUksV0FBVyxHQUFHLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLGFBQWEsQ0FBQyxhQUFhLENBQUMsZUFBZSxDQUFDLENBQUM7Z0JBQ3RGLDRCQUE0QjtnQkFDNUIsSUFBSSxXQUFXLEVBQUU7b0JBQ2IsSUFBSSxpQkFBaUIsR0FBRyxXQUFXLENBQUMscUJBQXFCLEVBQUUsQ0FBQyxNQUFNLENBQUM7b0JBQ25FLElBQUksVUFBVSxHQUFXLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLGFBQWEsQ0FBQyxxQkFBcUIsRUFBRSxDQUFDLE1BQU0sQ0FBQztvQkFDN0YsMkJBQTJCO29CQUMzQixrQ0FBa0M7b0JBQ2xDLElBQUksaUJBQWlCLEdBQUcsVUFBVSxFQUFFO3dCQUNoQyxJQUFJLENBQUMsV0FBVyxDQUFDLGVBQWUsQ0FBQyxVQUFVLEVBQUUsUUFBUSxFQUFFLE1BQU0sQ0FBQyxDQUFDO3dCQUMvRCxJQUFJLENBQUMsV0FBVyxDQUFDLGVBQWUsQ0FBQyxVQUFVLEVBQUUsUUFBUSxFQUFFLGlCQUFpQixHQUFHLElBQUksQ0FBQyxDQUFDO3FCQUNwRjtpQkFDSjtnQkFDRCxJQUFJLENBQUMsV0FBVyxDQUFDLGVBQWUsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxhQUFhLEVBQUUsYUFBYSxFQUFFLElBQUksQ0FBQyxDQUFDO2FBQy9GO1NBQ0o7SUFDTCxDQUFDO0lBRU8sT0FBTyxDQUFDLEtBQVU7UUFDdEIsSUFBSSxJQUFJLENBQUMsWUFBWTtZQUFFLE9BQU87UUFDOUIsSUFBSSxDQUFDLElBQUksQ0FBQyxPQUFPO1lBQUUsT0FBTztRQUUxQixJQUFJLFNBQVMsR0FBVyxJQUFJLENBQUMsV0FBVyxDQUFDLG9CQUFvQixDQUFDLElBQUksQ0FBQyxDQUFDO1FBQ3BFLDRFQUE0RTtRQUM1RSxJQUFJLGNBQWMsR0FBUSxJQUFJLENBQUMsRUFBRSxDQUFDLGFBQWEsQ0FBQyxxQkFBcUIsRUFBRSxDQUFDO1FBRXhFLElBQUksS0FBSyxHQUFHLElBQUksQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLE9BQU8sR0FBRyxjQUFjLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQztRQUNoRSxzQkFBc0I7UUFDdEIsMkRBQTJEO1FBQzNELHlCQUF5QjtRQUN6QixJQUFJLE9BQU8sR0FBRyxJQUFJLENBQUMsY0FBYyxDQUFDLGtCQUFrQixDQUFDLEtBQUssRUFBRSxjQUFjLENBQUMsS0FBSyxDQUFDLENBQUM7UUFDbEYscUNBQXFDO1FBRXJDLElBQUksQ0FBQyxXQUFXLENBQUMsV0FBVyxDQUFDLElBQUksQ0FBQyxhQUFhLEVBQUUsV0FBVyxDQUFDLENBQUM7UUFDOUQsSUFBSSxDQUFDLG9CQUFvQixDQUFDLE9BQU8sRUFBRSxjQUFjLENBQUMsS0FBSyxDQUFDLENBQUM7UUFDekQsSUFBSSxDQUFDLGNBQWMsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLGNBQWMsQ0FBQyxDQUFDO0lBQ2xELENBQUM7SUFFTyxTQUFTLENBQUMsS0FBVTtRQUN4QixJQUFJLFFBQVEsR0FBWSxJQUFJLENBQUMsV0FBVyxDQUFDLFFBQVEsRUFBRSxDQUFDO1FBQ3BELElBQUksUUFBUSxLQUFLLElBQUksQ0FBQyxhQUFhLEVBQUU7WUFDakMsSUFBSSxDQUFDLHNCQUFzQixHQUFHLElBQUksQ0FBQztZQUNuQyxJQUFJLENBQUMsYUFBYSxHQUFHLFFBQVEsQ0FBQztZQUM5QixJQUFJLENBQUMsY0FBYyxHQUFHLEtBQUssQ0FBQztTQUMvQjtRQUNELElBQUksQ0FBQyxtQkFBbUIsRUFBRSxDQUFDO1FBQzNCLElBQUksQ0FBQyxzQkFBc0IsR0FBRyxLQUFLLENBQUM7SUFDeEMsQ0FBQzs7O1lBamVKLFNBQVMsU0FBQztnQkFDUCxRQUFRLEVBQUUsYUFBYTtnQkFDdkIsUUFBUSxFQUFFLDhFQUE4RTtnQkFDeEYsYUFBYSxFQUFFLGlCQUFpQixDQUFDLElBQUk7Z0JBQ3JDLFNBQVMsRUFBRSxDQUFDLGFBQWEsRUFBRSxlQUFlLEVBQUUsZUFBZSxFQUFFLFlBQVksQ0FBQztnQkFDMUUsSUFBSSxFQUFFLEVBQUUsT0FBTyxFQUFFLGlCQUFpQixFQUFFO2FBQ3ZDOzs7WUFkbUUsZ0JBQWdCO1lBQTZCLFNBQVM7WUFLakgsYUFBYTtZQURiLGVBQWU7WUFBRSxZQUFZO1lBRTdCLGVBQWU7WUFMZixNQUFNOzs7MEJBcUNWLEtBQUs7dUJBQ0wsS0FBSzswQkFDTCxLQUFLOzBCQWNMLFlBQVksU0FBQyxvQkFBb0IsRUFBRSxDQUFDLFFBQVEsQ0FBQzt3QkFPN0MsWUFBWSxTQUFDLGtCQUFrQixFQUFFLENBQUMsUUFBUSxDQUFDO3VCQU0zQyxZQUFZLFNBQUMsZUFBZSxFQUFFLENBQUMsUUFBUSxDQUFDIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgQ29tcG9uZW50LCBJbnB1dCwgT25Jbml0LCBIb3N0TGlzdGVuZXIsIFZpZXdFbmNhcHN1bGF0aW9uLCBWaWV3Q29udGFpbmVyUmVmLCBBZnRlclZpZXdJbml0LCBFbGVtZW50UmVmLCBSZW5kZXJlcjIgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcclxuaW1wb3J0IHsgUm91dGVyLCBOYXZpZ2F0aW9uRW5kIH0gZnJvbSAnQGFuZ3VsYXIvcm91dGVyJztcclxuaW1wb3J0IHsgdGltZXIgfSBmcm9tICdyeGpzJztcclxuaW1wb3J0IHsgS2RQYW5lIH0gZnJvbSAnLi9rZC1wYW5lJztcclxuaW1wb3J0IHsgS2RDb252ZXJ0aW9uU3ZjLCBLZERvbUVsZW1TdmMgfSBmcm9tICcuLi8uLi9rZC1jb21tb24vaW5kZXgnO1xyXG5pbXBvcnQgeyBLZFNwbGl0dGVyU3ZjIH0gZnJvbSAnLi9rZC1zcGxpdHRlci1zdmMnO1xyXG5pbXBvcnQgeyBLZFNwbGl0dGVyRXZlbnQgfSBmcm9tICcuL2tkLXNwbGl0dGVyLWV2ZW50JztcclxuXHJcbkBDb21wb25lbnQoe1xyXG4gICAgc2VsZWN0b3I6ICdrZC1zcGxpdHRlcicsXHJcbiAgICB0ZW1wbGF0ZTogYDxkaXYgY2xhc3M9J3NwbGl0LWNvbnRhaW5lciB7e29yaWVudGF0aW9ufX0nPjxuZy1jb250ZW50PjwvbmctY29udGVudD48L2Rpdj5gLFxyXG4gICAgZW5jYXBzdWxhdGlvbjogVmlld0VuY2Fwc3VsYXRpb24uTm9uZSxcclxuICAgIHByb3ZpZGVyczogW0tkU3BsaXR0ZXJTdmMsIEtkU3BsaXR0ZXJFdmVudCwgS2RDb252ZXJ0aW9uU3ZjLCBLZERvbUVsZW1TdmNdLFxyXG4gICAgaG9zdDogeyAnY2xhc3MnOiAna2R4LXNwbGl0LXBhbmVzJyB9XHJcbn0pXHJcblxyXG5leHBvcnQgY2xhc3MgS2RTcGxpdHRlciBpbXBsZW1lbnRzIE9uSW5pdCwgQWZ0ZXJWaWV3SW5pdCB7XHJcblxyXG4gICAgcHJpdmF0ZSBlbDogRWxlbWVudFJlZjtcclxuICAgIHByaXZhdGUgX2lzRHJhZzogYm9vbGVhbiA9IGZhbHNlO1xyXG4gICAgcHJpdmF0ZSBfZGlzYWJsZURyYWc6IGJvb2xlYW4gPSBmYWxzZTtcclxuICAgIHByaXZhdGUgX3BhbmVzRGVmYXVsdENvbmZpZzogYW55ID0ge307XHJcbiAgICBwcml2YXRlIF9wYW5lczogQXJyYXk8S2RQYW5lPiA9IFtdO1xyXG4gICAgcHJpdmF0ZSBfc2VsZWN0ZWRFbGVtOiBFbGVtZW50O1xyXG4gICAgcHJpdmF0ZSBfc2VsZWN0ZWRQcmV2U2libGluZ0VsZW06IEVsZW1lbnQ7XHJcbiAgICAvLyBwcml2YXRlIF9sb2NhbFN0b3JhZ2U6IG51bWJlcjtcclxuICAgIHByaXZhdGUgX2lzTWFpblBhbmVDb2xsYXBzZTogYm9vbGVhbiA9IGZhbHNlO1xyXG4gICAgcHJpdmF0ZSBfc3BsaXR0ZXJMZXZlbDogc3RyaW5nID0gJyc7XHJcbiAgICBwcml2YXRlIF9lbmFibGVGbG9hdEJ0bjogYm9vbGVhbiA9IGZhbHNlO1xyXG4gICAgcHJpdmF0ZSBfZW5hYmxlU3ViUGFuZUNvbGxhcHNlOiBib29sZWFuID0gZmFsc2U7XHJcbiAgICBwcml2YXRlIF9wcmV2SXNNb2JpbGU6IGJvb2xlYW4gPSBmYWxzZTtcclxuICAgIHByaXZhdGUgX2lzU3ViUGFuZU9wZW46IGJvb2xlYW4gPSBmYWxzZTtcclxuICAgIHByaXZhdGUgX3Nlc3Npb25QcmVmaXg6IHN0cmluZyA9ICcnO1xyXG4gICAgcHJpdmF0ZSBfc2Vzc2lvbk5hbWU6IHN0cmluZyA9ICdzcGxpdHRlcic7XHJcbiAgICBwcml2YXRlIF9pc0ZpcnN0U3dpdGNoVmlld1BvcnQ6IGJvb2xlYW4gPSB0cnVlO1xyXG4gICAgcHJpdmF0ZSBfcHJldldpZHRoU3RhdGU6IG51bWJlciA9IDA7XHJcbiAgICBwcml2YXRlIF9pc01lbnVPcGVuOiBib29sZWFuID0gZmFsc2U7XHJcblxyXG4gICAgQElucHV0KCkgb3JpZW50YXRpb246IHN0cmluZztcclxuICAgIEBJbnB1dCgpIGZsb2F0YnRuOiBzdHJpbmc7XHJcbiAgICBASW5wdXQoKSBjb2xsYXBzaWJsZTogc3RyaW5nO1xyXG5cclxuICAgIGNvbnN0cnVjdG9yKFxyXG4gICAgICAgIHByaXZhdGUgX3ZjcjogVmlld0NvbnRhaW5lclJlZixcclxuICAgICAgICBwcml2YXRlIF9yZW5kZXJlcjogUmVuZGVyZXIyLFxyXG4gICAgICAgIHByaXZhdGUgX3NwbGl0dGVyU3ZjOiBLZFNwbGl0dGVyU3ZjLFxyXG4gICAgICAgIHByaXZhdGUgX2NvbnZlcnRpb25TdmM6IEtkQ29udmVydGlvblN2YyxcclxuICAgICAgICBwcml2YXRlIF9kb21FbGVtU3ZjOiBLZERvbUVsZW1TdmMsXHJcbiAgICAgICAgcHJpdmF0ZSBfc3BsaXR0ZXJFdmVudDogS2RTcGxpdHRlckV2ZW50LFxyXG4gICAgICAgIHByaXZhdGUgX3JvdXRlcjogUm91dGVyXHJcbiAgICApIHtcclxuICAgICAgICB0aGlzLmVsID0gdGhpcy5fdmNyLmVsZW1lbnQ7XHJcbiAgICB9XHJcblxyXG4gICAgQEhvc3RMaXN0ZW5lcignZG9jdW1lbnQ6bW91c2Vtb3ZlJywgWyckZXZlbnQnXSlcclxuICAgIG9uTW91c2Vtb3ZlKGV2ZW50OiBhbnkpOiB2b2lkIHtcclxuICAgICAgICAvLyB0aGlzLm1vdXNlbW92ZS5lbWl0KGV2ZW50KTtcclxuICAgICAgICB0aGlzLl9vbkRyYWcoZXZlbnQpO1xyXG5cclxuICAgIH1cclxuXHJcbiAgICBASG9zdExpc3RlbmVyKCdkb2N1bWVudDptb3VzZXVwJywgWyckZXZlbnQnXSlcclxuICAgIG9uTW91c2V1cChldmVudDogYW55KTogdm9pZCB7XHJcbiAgICAgICAgLy8gdGhpcy5tb3VzZXVwLmVtaXQoZXZlbnQpO1xyXG4gICAgICAgIHRoaXMuX2lzRHJhZyA9IGZhbHNlO1xyXG4gICAgfVxyXG5cclxuICAgIEBIb3N0TGlzdGVuZXIoJ3dpbmRvdzpyZXNpemUnLCBbJyRldmVudCddKVxyXG4gICAgb25SZXNpemUoZXZlbnQ6IGFueSk6IHZvaWQge1xyXG4gICAgICAgIC8vIGNvbnNvbGUubG9nKCdyZXNpemUnKTtcclxuICAgICAgICB0aGlzLl9vblJlc2l6ZShldmVudCk7XHJcbiAgICB9XHJcblxyXG4gICAgbmdPbkluaXQoKTogdm9pZCB7XHJcbiAgICAgICAgdGhpcy5fcHJldklzTW9iaWxlID0gdGhpcy5fZG9tRWxlbVN2Yy5pc01vYmlsZSgpO1xyXG4gICAgICAgIHRoaXMuX2VuYWJsZUZsb2F0QnRuID0gdGhpcy5fY29udmVydGlvblN2Yy5zdHJUb0Jvb2wodGhpcy5mbG9hdGJ0bik7XHJcbiAgICAgICAgdGhpcy5fZW5hYmxlU3ViUGFuZUNvbGxhcHNlID0gdGhpcy5fY29udmVydGlvblN2Yy5zdHJUb0Jvb2wodGhpcy5jb2xsYXBzaWJsZSk7XHJcbiAgICAgICAgLy8gdGhpcy5fcGFuZXNEZWZhdWx0Q29uZmlnID0gdGhpcy5fc3BsaXR0ZXJTdmMuaW5pdFBhbmVzRGVmYXVsdENvbmZpZyh0aGlzLl9wYW5lcyk7XHJcbiAgICAgICAgLy8gY29uc29sZS5sb2codGhpcy5fcGFuZXNEZWZhdWx0Q29uZmlnKTtcclxuICAgIH1cclxuXHJcbiAgICBuZ0FmdGVyVmlld0luaXQoKTogdm9pZCB7XHJcbiAgICAgICAgdGhpcy5fcGFuZXNEZWZhdWx0Q29uZmlnID0gdGhpcy5fc3BsaXR0ZXJTdmMuaW5pdFBhbmVzRGVmYXVsdENvbmZpZyh0aGlzLl9wYW5lcyk7XHJcbiAgICAgICAgdGhpcy5fZGlzYWJsZURyYWcgPSB0aGlzLl9zcGxpdHRlclN2Yy50b0Rpc2FibGVEcmFnKCk7XHJcblxyXG4gICAgICAgIGlmICh0aGlzLl9zcGxpdHRlclN2Yy5pc1N1YlBhbmUodGhpcy5lbC5uYXRpdmVFbGVtZW50KSkge1xyXG4gICAgICAgICAgICAvLyBjb25zb2xlLmxvZygndGhpcyBpcyB0aGUgc3ViIHBhbmUnKTtcclxuICAgICAgICAgICAgdGhpcy5fc3BsaXR0ZXJMZXZlbCA9ICdzdWInO1xyXG4gICAgICAgICAgICBsZXQgbGVmdFBhbmU6IEhUTUxFbGVtZW50ID0gdGhpcy5fcGFuZXNbMF0uZWxlbWVudC5uYXRpdmVFbGVtZW50O1xyXG4gICAgICAgICAgICB0aGlzLl9wcmV2V2lkdGhTdGF0ZSA9IGxlZnRQYW5lLmdldEJvdW5kaW5nQ2xpZW50UmVjdCgpLndpZHRoO1xyXG4gICAgICAgIH1cclxuICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgLy8gY29uc29sZS5sb2coJ3RoaXMgaXMgdGhlIG1haW4gcGFuZScpO1xyXG4gICAgICAgICAgICB0aGlzLl9zcGxpdHRlckxldmVsID0gJ21haW4nO1xyXG5cclxuICAgICAgICAgICAgdGhpcy5fcmVnaXN0ZXJNZW51QnJvYWRjYXN0KCk7XHJcbiAgICAgICAgICAgIHRoaXMuX3NldFRpbnQoZmFsc2UpO1xyXG4gICAgICAgIH1cclxuICAgICAgICAvLyB0aGlzLl9zcGxpdHRlckV2ZW50Lm9uRHJhZygpXHJcbiAgICAgICAgLy8gLnN1YnNjcmliZShfdHlwZSA9PiB7XHJcbiAgICAgICAgLy8gICAgIGNvbnNvbGUubG9nKF90eXBlKTtcclxuICAgICAgICAvLyB9KTtcclxuICAgICAgICAvLyBpc1N1YlNwbGl0dGVyL1xyXG4gICAgICAgIHRoaXMuX3Nlc3Npb25QcmVmaXggPSB0aGlzLl9jb252ZXJ0aW9uU3ZjLmNhbWVsQ2FzZSh0aGlzLl9kb21FbGVtU3ZjLmdldERvY3VtZW50VGhlbWUoKSwgJy0nKSArICdfc3BsaXR0ZXJfJyArIHRoaXMuX3NwbGl0dGVyTGV2ZWw7XHJcblxyXG4gICAgICAgIHRoaXMuX3NldERlZmF1bHRQYW5lU2l6ZSgpO1xyXG4gICAgICAgIHRoaXMuX3NldHVwU3BsaXR0ZXJIYW5kbGVyKCk7XHJcbiAgICAgICAgdGhpcy5fdG9nZ2xlQ29sbGFwc2VTdWJQYW5lKCk7XHJcblxyXG4gICAgICAgIHRoaXMuX2lzRmlyc3RTd2l0Y2hWaWV3UG9ydCA9IGZhbHNlO1xyXG5cclxuICAgICAgICB0aGlzLl9yb3V0ZXIuZXZlbnRzLnN1YnNjcmliZShldmVudCA9PiB7XHJcbiAgICAgICAgICAgIGlmIChldmVudCBpbnN0YW5jZW9mIE5hdmlnYXRpb25FbmQpIHtcclxuICAgICAgICAgICAgICAgIC8vIGNvbnNvbGUubG9nKGV2ZW50LnVybCk7XHJcbiAgICAgICAgICAgICAgICBmb3IgKGxldCBrZXkgaW4gdGhpcy5fcGFuZXMpIHtcclxuICAgICAgICAgICAgICAgICAgICBpZiAodGhpcy5fcGFuZXMuaGFzT3duUHJvcGVydHkoa2V5KSkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBsZXQgcGFuZTogS2RQYW5lID0gdGhpcy5fcGFuZXNba2V5XTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgcGFuZS5lbGVtZW50Lm5hdGl2ZUVsZW1lbnQuc2Nyb2xsVG9wID0gMDtcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9KTtcclxuICAgIH1cclxuXHJcbiAgICBhZGRHcm91cChwYW5lOiBLZFBhbmUpOiBudW1iZXIge1xyXG4gICAgICAgIHRoaXMuX3BhbmVzLnB1c2gocGFuZSk7XHJcbiAgICAgICAgcmV0dXJuIHRoaXMuX3BhbmVzLmxlbmd0aDtcclxuICAgIH1cclxuXHJcbiAgICBwYW5lT25DaGFuZ2UoX3R5cGU6IHN0cmluZyk6IHZvaWQge1xyXG4gICAgICAgIHRoaXMuX3BhbmVzRGVmYXVsdENvbmZpZyA9IHRoaXMuX3NwbGl0dGVyU3ZjLmluaXRQYW5lc0RlZmF1bHRDb25maWcodGhpcy5fcGFuZXMpO1xyXG4gICAgICAgIGlmIChfdHlwZSA9PT0gJ3NpemUnKSB7XHJcbiAgICAgICAgICAgIC8vIGNoYW5naW5nIGVsZW1lbnQgd2lkdGggYmVmb3JlIGFuaW1hdGlvbiBvZiBwYW5lcyBzdGFydFxyXG4gICAgICAgICAgICB0aGlzLl9zZXREZWZhdWx0UGFuZVNpemUoZmFsc2UpO1xyXG4gICAgICAgICAgICBsZXQgYm91bmRpbmdSZWN0ID0gdGhpcy5lbC5uYXRpdmVFbGVtZW50LmdldEJvdW5kaW5nQ2xpZW50UmVjdCgpO1xyXG4gICAgICAgICAgICBpZiAoYm91bmRpbmdSZWN0KSB7XHJcbiAgICAgICAgICAgICAgICAvLyBhZmZlY3RzIGFuaW1hdGlvbiBvZiBsZWZ0IHBhbmUuIFxyXG4gICAgICAgICAgICAgICAgdGhpcy5fcHJldldpZHRoU3RhdGUgPSB0aGlzLl9wYW5lc0RlZmF1bHRDb25maWcuUGFuZTEuc2l6ZSAqIGJvdW5kaW5nUmVjdC53aWR0aDtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF9yZWdpc3Rlck1lbnVCcm9hZGNhc3QoKSB7XHJcbiAgICAgICAgdGhpcy5fc3BsaXR0ZXJFdmVudC5vbigpXHJcbiAgICAgICAgICAgIC5zdWJzY3JpYmUocmVzcG9uZSA9PiB7XHJcbiAgICAgICAgICAgICAgICAvLyBjb25zb2xlLmxvZyhyZXNwb25lKTtcclxuICAgICAgICAgICAgICAgIGxldCBkaXJlY3Rpb246IHN0cmluZyA9IHRoaXMuX2RvbUVsZW1TdmMuZ2V0RG9jdW1lbnREaXJlY3Rpb24odHJ1ZSk7XHJcbiAgICAgICAgICAgICAgICBsZXQgb3BwRGlyZWN0aW9uOiBzdHJpbmcgPSBkaXJlY3Rpb24gPT09ICdsZWZ0JyA/ICdyaWdodCcgOiAnbGVmdCc7XHJcbiAgICAgICAgICAgICAgICBsZXQgY2xhc3NOYW1lOiBzdHJpbmcgPSAncHVzaC1jb250ZW50LScgKyBvcHBEaXJlY3Rpb247XHJcbiAgICAgICAgICAgICAgICBsZXQgaXNNb2JpbGU6IGJvb2xlYW4gPSB0aGlzLl9kb21FbGVtU3ZjLmlzTW9iaWxlKCk7XHJcbiAgICAgICAgICAgICAgICBsZXQgY291bnQ6IG51bWJlciA9IDA7XHJcblxyXG4gICAgICAgICAgICAgICAgZm9yIChsZXQga2V5IGluIHRoaXMuX3BhbmVzKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKHRoaXMuX3BhbmVzLmhhc093blByb3BlcnR5KGtleSkpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgbGV0IHBhbmU6IEtkUGFuZSA9IHRoaXMuX3BhbmVzW2tleV07XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuX2RvbUVsZW1TdmMuc2V0RWxlbWVudENsYXNzKHBhbmUuZWxlbWVudC5uYXRpdmVFbGVtZW50LCAnYW5pbWF0aW9uJywgaXNNb2JpbGUpO1xyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgaWYgKGNvdW50ICE9PSAwKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAoIWlzTW9iaWxlKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5fZG9tRWxlbVN2Yy5yZW1vdmVDbGFzcyhwYW5lLmVsZW1lbnQubmF0aXZlRWxlbWVudCwgY2xhc3NOYW1lKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuX2lzTWVudU9wZW4gPSAhdGhpcy5faXNNZW51T3BlbjtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAodGhpcy5fc3BsaXR0ZXJMZXZlbCA9PT0gJ21haW4nKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIGNvbnNvbGUubG9nKCdhcHBlbmQgY2xhc3MgJyArIGNsYXNzTmFtZSArICcgaW50byBtYWluIHBhbmUnKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5fZG9tRWxlbVN2Yy5zZXRFbGVtZW50Q2xhc3MocGFuZS5lbGVtZW50Lm5hdGl2ZUVsZW1lbnQsIGNsYXNzTmFtZSwgdGhpcy5faXNNZW51T3Blbik7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuX3NldFRpbnQodGhpcy5faXNNZW51T3Blbik7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKGlzTW9iaWxlICYmIHRoaXMuX3NwbGl0dGVyTGV2ZWwgPT09ICdzdWInKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gY29uc29sZS5sb2coJ3N1YiBtYWluJyk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgY291bnQrKztcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH0pO1xyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX3NldHVwU3BsaXR0ZXJIYW5kbGVyKCk6IHZvaWQge1xyXG4gICAgICAgIGZvciAobGV0IGk6IG51bWJlciA9IDE7IGkgPCB0aGlzLl9wYW5lcy5sZW5ndGg7IGkrKykge1xyXG4gICAgICAgICAgICBsZXQgY291bnQ6IG51bWJlciA9IGkgKyAxO1xyXG4gICAgICAgICAgICBsZXQgY2xhc3NOYW1lOiBzdHJpbmcgPSAnc2gtJyArIGNvdW50O1xyXG5cclxuICAgICAgICAgICAgbGV0IG5ld0VsOiBIVE1MRWxlbWVudCA9IHRoaXMuX2RvbUVsZW1TdmMuY3JlYXRlRWxlbWVudCh0aGlzLl9wYW5lc1tpXS5lbGVtZW50Lm5hdGl2ZUVsZW1lbnQsICdzcGxpdHRlci1oYW5kbGVyICcgKyBjbGFzc05hbWUpO1xyXG4gICAgICAgICAgICB0aGlzLl9kb21FbGVtU3ZjLnNldEVsZW1lbnRDbGFzcyhuZXdFbCwgJ2Rpc2FibGVkJywgdGhpcy5fZGlzYWJsZURyYWcpO1xyXG5cclxuICAgICAgICAgICAgLy8gc2V0dXAgT25Nb3VzZURvd25FdmVudFxyXG4gICAgICAgICAgICAvLyBzZXR1cCBPbk1vdXNlRG93bkV2ZW50XHJcbnRoaXMuX3JlbmRlcmVyLmxpc3RlbihuZXdFbCwgJ21vdXNlZG93bicsIChldmVudDogYW55KTogdm9pZCA9PiB7XHJcbiAgICB0aGlzLl9zZWxlY3RlZEVsZW0gPSBldmVudC50YXJnZXQucGFyZW50RWxlbWVudDtcclxuICAgIHRoaXMuX3NlbGVjdGVkUHJldlNpYmxpbmdFbGVtID0gdGhpcy5fc2VsZWN0ZWRFbGVtLnByZXZpb3VzRWxlbWVudFNpYmxpbmc7XHJcbiAgICB0aGlzLl9pc0RyYWcgPSB0cnVlO1xyXG59KTtcclxuXHJcbiAgICAgICAgICAgIGlmICh0aGlzLl9zcGxpdHRlckxldmVsID09PSAnbWFpbicpIHtcclxuICAgICAgICAgICAgICAgIHRoaXMuX3NldHVwQ29sbGFwc2VCdXR0b24odGhpcy5fcGFuZXNbaV0sIGNvdW50KTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF9zZXR1cENvbGxhcHNlQnV0dG9uKF9wYW5lOiBLZFBhbmUsIF9jb3VudDogbnVtYmVyKTogdm9pZCB7XHJcbiAgICAgICAgbGV0IGNsYXNzTmFtZTogc3RyaW5nID0gJ21iLScgKyBfY291bnQ7XHJcbiAgICAgICAgbGV0IG5ld0J0bjogSFRNTEVsZW1lbnQgPSB0aGlzLl9kb21FbGVtU3ZjLmNyZWF0ZUVsZW1lbnQoX3BhbmUuZWxlbWVudC5uYXRpdmVFbGVtZW50LCAnbWVudS1idG4gJyArIGNsYXNzTmFtZSk7XHJcblxyXG4gICAgICAgIC8vIFNldHVwIGljb25cclxuICAgICAgICB0aGlzLl9kb21FbGVtU3ZjLmNyZWF0ZUVsZW1lbnQobmV3QnRuLCAnZmEnLCAnaScpO1xyXG4gICAgICAgIHRoaXMuX3NldENvbGxhcHNlSWNvbih0aGlzLl9pc01haW5QYW5lQ29sbGFwc2UpO1xyXG4gICAgICAgIC8vIHNldHVwIE9uTW91c2VEb3duRXZlbnRcclxuICAgICAgICAvLyBzZXR1cCBPbk1vdXNlRG93bkV2ZW50XHJcbnRoaXMuX3JlbmRlcmVyLmxpc3RlbihuZXdCdG4sICdjbGljaycsIChldmVudDogYW55KTogdm9pZCA9PiB7XHJcbiAgICAvLyBjb25zb2xlLmxvZyhldmVudCk7XHJcbiAgICB0aGlzLl9pc0RyYWcgPSBmYWxzZTtcclxuICAgIHRoaXMuX3RvZ2dsZUNvbGxhcHNlTWVudShfcGFuZSk7XHJcbn0pO1xyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX3NldERlZmF1bHRQYW5lU2l6ZShfdXNlTG9jYWxTdG9yYWdlOiBib29sZWFuID0gdHJ1ZSk6IHZvaWQge1xyXG4gICAgICAgIGxldCBjb3VudDogbnVtYmVyID0gMDtcclxuICAgICAgICBsZXQgb2Zmc2V0WDogbnVtYmVyID0gMDtcclxuICAgICAgICBsZXQgZGlyZWN0aW9uOiBzdHJpbmcgPSB0aGlzLl9kb21FbGVtU3ZjLmdldERvY3VtZW50RGlyZWN0aW9uKHRydWUpO1xyXG4gICAgICAgIGxldCBvcHBEaXJlY3Rpb246IHN0cmluZyA9IGRpcmVjdGlvbiA9PT0gJ2xlZnQnID8gJ3JpZ2h0JyA6ICdsZWZ0JztcclxuICAgICAgICBsZXQgbW9iaWxlQ29uZmlnOiBhbnkgPSB0aGlzLl9zcGxpdHRlclN2Yy5nZXRNb2JpbGVDb25maWcodGhpcy5fc3BsaXR0ZXJMZXZlbCwgZGlyZWN0aW9uKTtcclxuICAgICAgICBsZXQgaXNNb2JpbGU6IGJvb2xlYW4gPSB0aGlzLl9kb21FbGVtU3ZjLmlzTW9iaWxlKCk7XHJcbiAgICAgICAgbGV0IGxvY2FsU3RvcmFnZTogYW55ID0gSlNPTi5wYXJzZSh3aW5kb3cuc2Vzc2lvblN0b3JhZ2UuZ2V0SXRlbSh0aGlzLl9zZXNzaW9uUHJlZml4ICsgdGhpcy5fc2Vzc2lvbk5hbWUpKTtcclxuICAgICAgICAvLyBjb25zb2xlLmxvZyhsb2NhbFN0b3JhZ2UpO1xyXG4gICAgICAgIC8vIGNvbnNvbGUubG9nKCdzZXNzaW9uU3RvcmdlID0gJyt3aW5kb3cuc2Vzc2lvblN0b3JhZ2UuZ2V0SXRlbSh0aGlzLl9zZXNzaW9uUHJlZml4K3RoaXMuX3Nlc3Npb25OYW1lKSk7XHJcbiAgICAgICAgZm9yIChsZXQga2V5IGluIHRoaXMuX3BhbmVzRGVmYXVsdENvbmZpZykge1xyXG4gICAgICAgICAgICBpZiAodGhpcy5fcGFuZXNEZWZhdWx0Q29uZmlnLmhhc093blByb3BlcnR5KGtleSkpIHtcclxuICAgICAgICAgICAgICAgIGxldCBwYW5lOiBLZFBhbmUgPSB0aGlzLl9wYW5lc1tjb3VudF07XHJcbiAgICAgICAgICAgICAgICBsZXQgcGFuZUNvbmZpZzogYW55ID0ge1xyXG4gICAgICAgICAgICAgICAgICAgIHdpZHRoOiAodGhpcy5fcGFuZXNEZWZhdWx0Q29uZmlnW2tleV0uc2l6ZSA+IDEwMCkgPyAxMDAgOiB0aGlzLl9wYW5lc0RlZmF1bHRDb25maWdba2V5XS5zaXplLFxyXG4gICAgICAgICAgICAgICAgfTtcclxuICAgICAgICAgICAgICAgIHBhbmVDb25maWdbZGlyZWN0aW9uXSA9IG9mZnNldFg7XHJcblxyXG4gICAgICAgICAgICAgICAgaWYgKGlzTW9iaWxlKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgcGFuZUNvbmZpZyA9IE9iamVjdC5hc3NpZ24oe30sIHBhbmVDb25maWcsIG1vYmlsZUNvbmZpZ1trZXldKTtcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLl9pc01lbnVPcGVuID0gZmFsc2U7XHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKGNvdW50ID09PSAwKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC8vIGNvbnNvbGUubG9nKCdzaG93IGJ1dHRvbicpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLl9zZXR1cEZsb2F0TWVudUJ0bihwYW5lLCBjb3VudCk7XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIC8vIGNvbnNvbGUubG9nKFwidGhpcyBpcyBtb2JpbGUgdmlld1wiKTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgICAgIGlmIChsb2NhbFN0b3JhZ2UgIT09IG51bGwgJiYgX3VzZUxvY2FsU3RvcmFnZSkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBsZXQgdGVtcE5hbWU6IHN0cmluZyA9ICdQYW5lJyArIChjb3VudCArIDEpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBwYW5lQ29uZmlnID0gT2JqZWN0LmFzc2lnbih7fSwgcGFuZUNvbmZpZywgbG9jYWxTdG9yYWdlW3RlbXBOYW1lXSk7XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIC8vIGNvbnNvbGUubG9nKHBhbmVDb25maWcpO1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuX3JlbW92ZUZsb2F0TWVudUJ0bigpO1xyXG5cclxuICAgICAgICAgICAgICAgICAgICB0aGlzLl9kb21FbGVtU3ZjLnJlbW92ZUNsYXNzKHBhbmUuZWxlbWVudC5uYXRpdmVFbGVtZW50LCAncHVzaC1jb250ZW50LScgKyBvcHBEaXJlY3Rpb24pO1xyXG5cclxuICAgICAgICAgICAgICAgICAgICBpZiAodGhpcy5fc3BsaXR0ZXJMZXZlbCA9PT0gJ3N1YicgJiYgY291bnQgPT09IDEgJiYgdGhpcy5faXNGaXJzdFN3aXRjaFZpZXdQb3J0KSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGxldCBpc1N1YlBhbmVTaG93OiBib29sZWFuID0gKHRoaXMuX3BhbmVzRGVmYXVsdENvbmZpZ1trZXldLnNob3cgIT09IHVuZGVmaW5lZCkgPyB0aGlzLl9wYW5lc0RlZmF1bHRDb25maWdba2V5XS5zaG93IDogdHJ1ZTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5fcHJvY2Vzc1RvZ2dsZUNvbGxhcHNlU3ViUGFuZShpc1N1YlBhbmVTaG93LCBmYWxzZSk7XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgICAgIGZvciAobGV0IGNLZXkgaW4gcGFuZUNvbmZpZykge1xyXG4gICAgICAgICAgICAgICAgICAgIGlmIChwYW5lQ29uZmlnLmhhc093blByb3BlcnR5KGNLZXkpKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuX2RvbUVsZW1TdmMuc2V0RWxlbWVudFN0eWxlKHBhbmUuZWxlbWVudC5uYXRpdmVFbGVtZW50LCBjS2V5LCBwYW5lQ29uZmlnW2NLZXldICsgJyUnKTtcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICBjb3VudCsrO1xyXG4gICAgICAgICAgICAgICAgb2Zmc2V0WCArPSBwYW5lQ29uZmlnLndpZHRoO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX3VwZGF0ZVNwbGl0UGFuZVNpemUoX3Bvc1g6IG51bWJlciwgX2JvdW5kU2l6ZTogbnVtYmVyKSB7XHJcbiAgICAgICAgaWYgKHRoaXMuX2RvbUVsZW1TdmMuaXNNb2JpbGUoKSkgcmV0dXJuO1xyXG4gICAgICAgIGlmICghdGhpcy5faXNEcmFnKSByZXR1cm47XHJcblxyXG4gICAgICAgIGxldCBkaXJlY3Rpb246IHN0cmluZyA9IHRoaXMuX2RvbUVsZW1TdmMuZ2V0RG9jdW1lbnREaXJlY3Rpb24odHJ1ZSk7XHJcbiAgICAgICAgbGV0IGRpbWVudGlvbjogc3RyaW5nID0gKHRoaXMub3JpZW50YXRpb24gPT09ICd2ZXJ0aWNhbCcpID8gJ2hlaWdodCcgOiAnd2lkdGgnO1xyXG4gICAgICAgIGxldCBzZWxlY3RlZEVsZW1Cb3VuZHM6IGFueSA9IHRoaXMuX3NlbGVjdGVkRWxlbS5nZXRCb3VuZGluZ0NsaWVudFJlY3QoKTtcclxuICAgICAgICBsZXQgc2VsZWN0ZWRQcmV2RWxlbUJvdW5kczogYW55ID0gdGhpcy5fc2VsZWN0ZWRQcmV2U2libGluZ0VsZW0uZ2V0Qm91bmRpbmdDbGllbnRSZWN0KCk7XHJcblxyXG4gICAgICAgIHNlbGVjdGVkRWxlbUJvdW5kcyA9ICh0aGlzLm9yaWVudGF0aW9uID09PSAndmVydGljYWwnKSA/IHNlbGVjdGVkRWxlbUJvdW5kcy5oZWlnaHQgOiBzZWxlY3RlZEVsZW1Cb3VuZHMud2lkdGg7XHJcbiAgICAgICAgc2VsZWN0ZWRQcmV2RWxlbUJvdW5kcyA9ICh0aGlzLm9yaWVudGF0aW9uID09PSAndmVydGljYWwnKSA/IHNlbGVjdGVkUHJldkVsZW1Cb3VuZHMuaGVpZ2h0IDogc2VsZWN0ZWRQcmV2RWxlbUJvdW5kcy53aWR0aDtcclxuXHJcbiAgICAgICAgbGV0IHRvdGFsMkVsZW1TaXplOiBudW1iZXIgPSBNYXRoLnJvdW5kKHRoaXMuX2NvbnZlcnRpb25TdmMuY29udmVydFB4VG9QZXJjZW50KHNlbGVjdGVkUHJldkVsZW1Cb3VuZHMgKyBzZWxlY3RlZEVsZW1Cb3VuZHMsIF9ib3VuZFNpemUpKTtcclxuXHJcbiAgICAgICAgbGV0IG1vdmVYOiBudW1iZXIgPSB0aGlzLl9zcGxpdHRlclN2Yy52YWxpZGF0ZVBlcmNlbnRWYWx1ZShfcG9zWCk7XHJcbiAgICAgICAgdG90YWwyRWxlbVNpemUgPSB0aGlzLl9zcGxpdHRlclN2Yy52YWxpZGF0ZVBlcmNlbnRWYWx1ZSh0b3RhbDJFbGVtU2l6ZSk7XHJcblxyXG4gICAgICAgIGxldCBzZWxlY3RlZFByZXZQYW5lS2V5OiBzdHJpbmcgPSB0aGlzLl9jb252ZXJ0aW9uU3ZjLmNhbWVsQ2FzZSh0aGlzLl9zZWxlY3RlZFByZXZTaWJsaW5nRWxlbS5jbGFzc0xpc3RbMV0sICctJyk7XHJcbiAgICAgICAgbW92ZVggPSB0aGlzLl9zcGxpdHRlclN2Yy52YWxpZGF0ZVBhbmVTaXplKHRoaXMuX3BhbmVzRGVmYXVsdENvbmZpZywgc2VsZWN0ZWRQcmV2UGFuZUtleSwgbW92ZVgpO1xyXG5cclxuICAgICAgICBsZXQgY3VyUGFuZTogbnVtYmVyID0gdG90YWwyRWxlbVNpemUgLSBtb3ZlWDtcclxuXHJcbiAgICAgICAgbGV0IHNwbGl0dGVyRmluYWxDb25maWc6IGFueSA9IHtcclxuICAgICAgICAgICAgUGFuZTE6IHt9LFxyXG4gICAgICAgICAgICBQYW5lMjoge31cclxuICAgICAgICB9O1xyXG4gICAgICAgIHNwbGl0dGVyRmluYWxDb25maWdbJ1BhbmUxJ11bZGltZW50aW9uXSA9IG1vdmVYO1xyXG4gICAgICAgIHNwbGl0dGVyRmluYWxDb25maWdbJ1BhbmUyJ11bZGlyZWN0aW9uXSA9IG1vdmVYO1xyXG4gICAgICAgIHNwbGl0dGVyRmluYWxDb25maWdbJ1BhbmUyJ11bZGltZW50aW9uXSA9IGN1clBhbmU7XHJcbiAgICAgICAgd2luZG93LnNlc3Npb25TdG9yYWdlLnNldEl0ZW0odGhpcy5fc2Vzc2lvblByZWZpeCArIHRoaXMuX3Nlc3Npb25OYW1lLCBKU09OLnN0cmluZ2lmeShzcGxpdHRlckZpbmFsQ29uZmlnKSk7XHJcblxyXG4gICAgICAgIHRoaXMuX2RvbUVsZW1TdmMuc2V0RWxlbWVudFN0eWxlKHRoaXMuX3NlbGVjdGVkUHJldlNpYmxpbmdFbGVtLCBkaW1lbnRpb24sIG1vdmVYICsgJyUnKTtcclxuICAgICAgICB0aGlzLl9kb21FbGVtU3ZjLnNldEVsZW1lbnRTdHlsZSh0aGlzLl9zZWxlY3RlZEVsZW0sIGRpcmVjdGlvbiwgbW92ZVggKyAnJScpO1xyXG4gICAgICAgIHRoaXMuX2RvbUVsZW1TdmMuc2V0RWxlbWVudFN0eWxlKHRoaXMuX3NlbGVjdGVkRWxlbSwgZGltZW50aW9uLCBjdXJQYW5lICsgJyUnKTtcclxuXHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfdG9nZ2xlQ29sbGFwc2VNZW51KF9wYW5lOiBLZFBhbmUpIHtcclxuICAgICAgICBsZXQgZGlyZWN0aW9uOiBzdHJpbmcgPSB0aGlzLl9kb21FbGVtU3ZjLmdldERvY3VtZW50RGlyZWN0aW9uKHRydWUpO1xyXG4gICAgICAgIHRoaXMuX2lzTWFpblBhbmVDb2xsYXBzZSA9ICF0aGlzLl9pc01haW5QYW5lQ29sbGFwc2U7XHJcblxyXG4gICAgICAgIHRoaXMuX2RvbUVsZW1TdmMuYWRkQ2xhc3MoX3BhbmUuZWxlbWVudC5uYXRpdmVFbGVtZW50LCAnYW5pbWF0aW9uJyk7XHJcbiAgICAgICAgdGhpcy5fZG9tRWxlbVN2Yy5zZXRFbGVtZW50Q2xhc3MoX3BhbmUuZWxlbWVudC5uYXRpdmVFbGVtZW50LCAncHVzaC1jb250ZW50LScgKyBkaXJlY3Rpb24sIHRoaXMuX2lzTWFpblBhbmVDb2xsYXBzZSk7XHJcbiAgICAgICAgdGhpcy5fc2V0Q29sbGFwc2VJY29uKHRoaXMuX2lzTWFpblBhbmVDb2xsYXBzZSk7XHJcbiAgICAgICAgdGhpcy5fc3BsaXR0ZXJFdmVudC50b2dnbGVNZW51KCk7XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfcmVtb3ZlRmxvYXRNZW51QnRuKCk6IHZvaWQge1xyXG4gICAgICAgIHRoaXMuX2RvbUVsZW1TdmMucmVtb3ZlRWxlbWVudEJ5Q2xhc3MoJy5mbS1idG4nLCB0aGlzLmVsLm5hdGl2ZUVsZW1lbnQpO1xyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX3NldHVwRmxvYXRNZW51QnRuKF9wYW5lOiBLZFBhbmUsIF9jb3VudDogbnVtYmVyKTogdm9pZCB7XHJcbiAgICAgICAgbGV0IGlzTW9iaWxlOiBib29sZWFuID0gdGhpcy5fZG9tRWxlbVN2Yy5pc01vYmlsZSgpO1xyXG4gICAgICAgIGxldCBmbG9hdEJ0bjogSFRNTEVsZW1lbnQgPSB0aGlzLmVsLm5hdGl2ZUVsZW1lbnQucXVlcnlTZWxlY3RvcignLmZtLWJ0bicpO1xyXG4gICAgICAgIGlmIChpc01vYmlsZSAmJiB0aGlzLl9zcGxpdHRlckxldmVsID09PSAnc3ViJyAmJiBmbG9hdEJ0biA9PT0gbnVsbCAmJiB0aGlzLl9lbmFibGVGbG9hdEJ0bikge1xyXG4gICAgICAgICAgICAvLyBjb25zb2xlLmxvZygnc3ViIG1haW4nKTtcclxuICAgICAgICAgICAgLy8gbGV0IGNsYXNzTmFtZXM6IHN0cmluZyA9ICdmbWItJyArIF9jb3VudDtcclxuICAgICAgICAgICAgbGV0IGNsYXNzTmFtZTogc3RyaW5nID0gJ2ZtLWJ0bic7XHJcblxyXG4gICAgICAgICAgICBsZXQgbmV3QnRuOiBIVE1MRWxlbWVudCA9IHRoaXMuX2RvbUVsZW1TdmMuY3JlYXRlRWxlbWVudCh0aGlzLmVsLm5hdGl2ZUVsZW1lbnQsICdidG4gYnRuLWZsb2F0LWJvdHRvbS1yaWdodCBidG4tY2lyY2xlIGJ0bi1jb2xvciAnICsgY2xhc3NOYW1lKTtcclxuXHJcbiAgICAgICAgICAgIC8vIC8vU2V0dXAgaWNvblxyXG4gICAgICAgICAgICBIVE1MRWxlbWVudCA9IHRoaXMuX2RvbUVsZW1TdmMuY3JlYXRlRWxlbWVudChuZXdCdG4sICdmYScsICdpJyk7XHJcbiAgICAgICAgICAgIHRoaXMuX3NldEZsb2F0SWNvbih0aGlzLl9pc1N1YlBhbmVPcGVuKTtcclxuXHJcbiAgICAgICAgICAgIC8vIC8vc2V0dXAgT25Nb3VzZURvd25FdmVudFxyXG4gICAgICAgICAgICAvLyAvL3NldHVwIE9uTW91c2VEb3duRXZlbnRcclxudGhpcy5fcmVuZGVyZXIubGlzdGVuKG5ld0J0biwgJ2NsaWNrJywgKGV2ZW50OiBhbnkpOiB2b2lkID0+IHtcclxuICAgIHRoaXMuX2lzU3ViUGFuZU9wZW4gPSAhdGhpcy5faXNTdWJQYW5lT3BlbjtcclxuICAgIHRoaXMuX3NwbGl0dGVyRXZlbnQudG9nZ2xlU3ViUGFuZSh0aGlzLl9pc1N1YlBhbmVPcGVuKTtcclxufSk7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX3RvZ2dsZUNvbGxhcHNlU3ViUGFuZSgpIHtcclxuICAgICAgICBpZiAodGhpcy5fc3BsaXR0ZXJMZXZlbCA9PT0gJ3N1YicpIHtcclxuICAgICAgICAgICAgdGhpcy5fc3BsaXR0ZXJFdmVudC5vblRvZ2dsZVN1YlBhbmUoKVxyXG4gICAgICAgICAgICAgICAgLnN1YnNjcmliZShpc1N1YlBhbmVPcGVuID0+IHtcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLl9wcm9jZXNzVG9nZ2xlQ29sbGFwc2VTdWJQYW5lKGlzU3ViUGFuZU9wZW4pO1xyXG4gICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX3Byb2Nlc3NUb2dnbGVDb2xsYXBzZVN1YlBhbmUoaXNTdWJQYW5lT3BlbjogYm9vbGVhbiwgX2FuaW1hdGU/OiBib29sZWFuKSB7XHJcbiAgICAgICAgLy8gY29uc29sZS5sb2coJ2luIHRoaXMgZnVuY3Rpb24/JylcclxuICAgICAgICBfYW5pbWF0ZSA9ICh0eXBlb2YgX2FuaW1hdGUgPT09ICd1bmRlZmluZWQnKSA/IHRydWUgOiBfYW5pbWF0ZTtcclxuICAgICAgICBsZXQgcmlnaHRQYW5lOiBIVE1MRWxlbWVudCA9IHRoaXMuX3BhbmVzWzFdLmVsZW1lbnQubmF0aXZlRWxlbWVudDtcclxuICAgICAgICBsZXQgbGVmdFBhbmU6IEhUTUxFbGVtZW50ID0gdGhpcy5fcGFuZXNbMF0uZWxlbWVudC5uYXRpdmVFbGVtZW50O1xyXG4gICAgICAgIGxldCBpc01vYmlsZTogYm9vbGVhbiA9IHRoaXMuX2RvbUVsZW1TdmMuaXNNb2JpbGUoKTtcclxuICAgICAgICBsZXQgaXNTYW1lU3RhdGU6IGJvb2xlYW4gPSAodGhpcy5faXNTdWJQYW5lT3BlbiA9PT0gaXNTdWJQYW5lT3BlbikgPyB0cnVlIDogZmFsc2U7XHJcbiAgICAgICAgdGhpcy5faXNTdWJQYW5lT3BlbiA9IGlzU3ViUGFuZU9wZW47XHJcbiAgICAgICAgaWYgKF9hbmltYXRlKSB7XHJcbiAgICAgICAgICAgIHRoaXMuX2RvbUVsZW1TdmMuYWRkQ2xhc3MocmlnaHRQYW5lLCAnYW5pbWF0aW9uJyk7XHJcbiAgICAgICAgICAgIHRoaXMuX2RvbUVsZW1TdmMuYWRkQ2xhc3MobGVmdFBhbmUsICdhbmltYXRpb24nKTtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIGlmIChpc01vYmlsZSB8fCB0aGlzLl9lbmFibGVTdWJQYW5lQ29sbGFwc2UpIHtcclxuICAgICAgICAgICAgLy8gY29uc29sZS5sb2coJ2FtIGkgaW4/Jyk7XHJcbiAgICAgICAgICAgIGxldCBhbmltYXRlRGlyZWN0aW9uOiBzdHJpbmcgPSAoaXNNb2JpbGUpID8gJ2luJyA6ICdvdXQnO1xyXG4gICAgICAgICAgICBsZXQgZGlyZWN0aW9uOiBzdHJpbmcgPSB0aGlzLl9kb21FbGVtU3ZjLmdldERvY3VtZW50RGlyZWN0aW9uKHRydWUpO1xyXG4gICAgICAgICAgICBsZXQgb3BwRGlyZWN0aW9uOiBzdHJpbmcgPSAoZGlyZWN0aW9uID09PSAnbGVmdCcpID8gJ3JpZ2h0JyA6ICdsZWZ0JztcclxuICAgICAgICAgICAgbGV0IGFkZENsYXNzOiBib29sZWFuID0gKGlzTW9iaWxlKSA/IGlzU3ViUGFuZU9wZW4gOiAhaXNTdWJQYW5lT3BlbjtcclxuXHJcbiAgICAgICAgICAgIGxldCB3aWR0aENvbmZpZzogQXJyYXk8YW55PiA9IFt7fV07XHJcbiAgICAgICAgICAgIGlmIChhZGRDbGFzcykge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5fcHJldldpZHRoU3RhdGUgPSBsZWZ0UGFuZS5nZXRCb3VuZGluZ0NsaWVudFJlY3QoKS53aWR0aDtcclxuICAgICAgICAgICAgICAgIHdpZHRoQ29uZmlnID0gW1xyXG4gICAgICAgICAgICAgICAgICAgIHsgJ3dpZHRoJzogdGhpcy5fcHJldldpZHRoU3RhdGUgKyAncHgnIH0sXHJcbiAgICAgICAgICAgICAgICAgICAgeyAnd2lkdGgnOiAnMTAwJScgfVxyXG4gICAgICAgICAgICAgICAgXTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgICAgIHdpZHRoQ29uZmlnID0gW1xyXG4gICAgICAgICAgICAgICAgICAgIHsgJ3dpZHRoJzogJzEwMCUnIH0sXHJcbiAgICAgICAgICAgICAgICAgICAgeyAnd2lkdGgnOiB0aGlzLl9wcmV2V2lkdGhTdGF0ZSArICdweCcgfVxyXG4gICAgICAgICAgICAgICAgXTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB0aGlzLl9zZXRGbG9hdEljb24oaXNTdWJQYW5lT3Blbik7XHJcbiAgICAgICAgICAgIHRoaXMuX2RvbUVsZW1TdmMuc2V0RWxlbWVudENsYXNzKGxlZnRQYW5lLCAnZnVsbC13aWR0aCcsIGFkZENsYXNzKTtcclxuICAgICAgICAgICAgdGhpcy5fZG9tRWxlbVN2Yy5zZXRFbGVtZW50Q2xhc3MocmlnaHRQYW5lLCAncHVzaC1zdWJjb250ZW50LScgKyBvcHBEaXJlY3Rpb24gKyAnLScgKyBhbmltYXRlRGlyZWN0aW9uLCBhZGRDbGFzcyk7XHJcblxyXG4gICAgICAgICAgICBpZiAoX2FuaW1hdGUgJiYgIWlzU2FtZVN0YXRlKSB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLl9kb21FbGVtU3ZjLmludm9rZUVsZW1lbnRNZXRob2QoXHJcbiAgICAgICAgICAgICAgICAgICAgbGVmdFBhbmUsXHJcbiAgICAgICAgICAgICAgICAgICAgJ2FuaW1hdGUnLFxyXG4gICAgICAgICAgICAgICAgICAgIFt3aWR0aENvbmZpZywgNTAwXVxyXG4gICAgICAgICAgICAgICAgKTtcclxuXHJcbiAgICAgICAgICAgICAgICB0aW1lcig1MDApLnN1YnNjcmliZSgoKTogdm9pZCA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgLy8gbmVlZCBmaXhpbmcgaW4gdGhlIGZ1dHVyZS4gdGhpcyBldmVudCBpcyBiZWluZyB0cmlnZ2VyZWQgdHdpY2UuIGFub3RoZXIgdGltZSBpcyBpbiBrZC1leGFtcGxlXHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5fc3BsaXR0ZXJFdmVudC50b2dnbGVTdWJQYW5lKGlzU3ViUGFuZU9wZW4pO1xyXG4gICAgICAgICAgICAgICAgICAgIC8vIHRoaXMuX3NwbGl0dGVyRXZlbnQudG9nZ2xlQW5pbWF0aW9uU3ViUGFuZUVuZChpc1N1YlBhbmVPcGVuKTtcclxuICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX3NldEZsb2F0SWNvbihfaXNPcGVuOiBib29sZWFuKSB7XHJcbiAgICAgICAgbGV0IGJ0bkljb246IEhUTUxFbGVtZW50ID0gdGhpcy5lbC5uYXRpdmVFbGVtZW50LnF1ZXJ5U2VsZWN0b3IoJy5mbS1idG4gaScpO1xyXG4gICAgICAgIGlmICh0aGlzLl9zcGxpdHRlckxldmVsID09PSAnc3ViJyAmJiBidG5JY29uICE9PSBudWxsKSB7XHJcbiAgICAgICAgICAgIHRoaXMuX2RvbUVsZW1TdmMuc2V0RWxlbWVudENsYXNzKGJ0bkljb24sICdrZC1saXN0cycsICFfaXNPcGVuKTtcclxuICAgICAgICAgICAgdGhpcy5fZG9tRWxlbVN2Yy5zZXRFbGVtZW50Q2xhc3MoYnRuSWNvbiwgJ2tkLWNsb3NlLXJvdW5kJywgX2lzT3Blbik7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX3NldENvbGxhcHNlSWNvbihfaXNPcGVuOiBib29sZWFuKSB7XHJcbiAgICAgICAgbGV0IGRpcmVjdGlvbjogc3RyaW5nID0gdGhpcy5fZG9tRWxlbVN2Yy5nZXREb2N1bWVudERpcmVjdGlvbih0cnVlKTtcclxuICAgICAgICBsZXQgb3BwRGlyZWN0aW9uOiBzdHJpbmcgPSAoZGlyZWN0aW9uID09PSAnbGVmdCcpID8gJ3JpZ2h0JyA6ICdsZWZ0JztcclxuICAgICAgICBsZXQgYnRuSWNvbjogSFRNTEVsZW1lbnQgPSB0aGlzLmVsLm5hdGl2ZUVsZW1lbnQucXVlcnlTZWxlY3RvcignLm1lbnUtYnRuIGknKTtcclxuXHJcbiAgICAgICAgaWYgKHRoaXMuX3NwbGl0dGVyTGV2ZWwgPT09ICdtYWluJyAmJiBidG5JY29uICE9PSBudWxsKSB7XHJcbiAgICAgICAgICAgIHRoaXMuX2RvbUVsZW1TdmMuc2V0RWxlbWVudENsYXNzKGJ0bkljb24sICdmYS1hbmdsZS0nICsgZGlyZWN0aW9uLCAhX2lzT3Blbik7XHJcbiAgICAgICAgICAgIHRoaXMuX2RvbUVsZW1TdmMuc2V0RWxlbWVudENsYXNzKGJ0bkljb24sICdmYS1hbmdsZS0nICsgb3BwRGlyZWN0aW9uLCBfaXNPcGVuKTtcclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfc2V0VGludChfYWRkOiBib29sZWFuKSB7XHJcbiAgICAgICAgbGV0IGlzTW9iaWxlOiBib29sZWFuID0gdGhpcy5fZG9tRWxlbVN2Yy5pc01vYmlsZSgpO1xyXG4gICAgICAgIGxldCBvdmVybGF5RGl2OiBIVE1MRWxlbWVudCA9IHRoaXMuX3BhbmVzWzFdLmVsZW1lbnQubmF0aXZlRWxlbWVudC5xdWVyeVNlbGVjdG9yKCcuY29udGVudC1vdmVybGF5Jyk7XHJcbiAgICAgICAgaWYgKG92ZXJsYXlEaXYgPT09IG51bGwpIHtcclxuICAgICAgICAgICAgb3ZlcmxheURpdiA9IHRoaXMuX2RvbUVsZW1TdmMuY3JlYXRlRWxlbWVudCh0aGlzLl9wYW5lc1sxXS5lbGVtZW50Lm5hdGl2ZUVsZW1lbnQsICdjb250ZW50LW92ZXJsYXknKTtcclxuXHJcbiAgICAgICAgICAgIHRoaXMuX3JlbmRlcmVyLmxpc3RlbihvdmVybGF5RGl2LCAnY2xpY2snLCAoZXZlbnQ6IGFueSk6IHZvaWQgPT4ge1xyXG4gICAgdGhpcy5fc3BsaXR0ZXJFdmVudC5maXJlKCk7XHJcbn0pO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgaWYgKGlzTW9iaWxlKSB7XHJcbiAgICAgICAgICAgIHRoaXMuX2RvbUVsZW1TdmMuc2V0RWxlbWVudENsYXNzKG92ZXJsYXlEaXYsICdzaG93JywgX2FkZCk7XHJcbiAgICAgICAgICAgIGlmICh0aGlzLl9zcGxpdHRlckxldmVsID09PSAnbWFpbicpIHtcclxuICAgICAgICAgICAgICAgIGxldCBjb250ZW50QXJlYSA9IHRoaXMuX3BhbmVzWzFdLmVsZW1lbnQubmF0aXZlRWxlbWVudC5xdWVyeVNlbGVjdG9yKCcubWFpbi13cmFwcGVyJyk7XHJcbiAgICAgICAgICAgICAgICAvLyBjb25zb2xlLmxvZyhjb250ZW50QXJlYSk7XHJcbiAgICAgICAgICAgICAgICBpZiAoY29udGVudEFyZWEpIHtcclxuICAgICAgICAgICAgICAgICAgICBsZXQgY29udGVudEFyZWFIZWlnaHQgPSBjb250ZW50QXJlYS5nZXRCb3VuZGluZ0NsaWVudFJlY3QoKS5oZWlnaHQ7XHJcbiAgICAgICAgICAgICAgICAgICAgbGV0IHBhbmVIZWlnaHQ6IG51bWJlciA9IHRoaXMuX3BhbmVzWzFdLmVsZW1lbnQubmF0aXZlRWxlbWVudC5nZXRCb3VuZGluZ0NsaWVudFJlY3QoKS5oZWlnaHQ7XHJcbiAgICAgICAgICAgICAgICAgICAgLy8gY29uc29sZS5sb2cocGFuZUhlaWdodCk7XHJcbiAgICAgICAgICAgICAgICAgICAgLy8gY29uc29sZS5sb2coY29udGVudEFyZWFIZWlnaHQpO1xyXG4gICAgICAgICAgICAgICAgICAgIGlmIChjb250ZW50QXJlYUhlaWdodCA+IHBhbmVIZWlnaHQpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5fZG9tRWxlbVN2Yy5zZXRFbGVtZW50U3R5bGUob3ZlcmxheURpdiwgJ2JvdHRvbScsICdhdXRvJyk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuX2RvbUVsZW1TdmMuc2V0RWxlbWVudFN0eWxlKG92ZXJsYXlEaXYsICdoZWlnaHQnLCBjb250ZW50QXJlYUhlaWdodCArICdweCcpO1xyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIHRoaXMuX2RvbUVsZW1TdmMuc2V0RWxlbWVudENsYXNzKHRoaXMuX3BhbmVzWzFdLmVsZW1lbnQubmF0aXZlRWxlbWVudCwgJ25vLW92ZXJmbG93JywgX2FkZCk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfb25EcmFnKGV2ZW50OiBhbnkpOiB2b2lkIHtcclxuICAgICAgICBpZiAodGhpcy5fZGlzYWJsZURyYWcpIHJldHVybjtcclxuICAgICAgICBpZiAoIXRoaXMuX2lzRHJhZykgcmV0dXJuO1xyXG5cclxuICAgICAgICBsZXQgZGlyZWN0aW9uOiBzdHJpbmcgPSB0aGlzLl9kb21FbGVtU3ZjLmdldERvY3VtZW50RGlyZWN0aW9uKHRydWUpO1xyXG4gICAgICAgIC8vIGxldCBzZWxlY3RlZFBhbmVCb3VuZHM6IGFueSA9IHRoaXMuX3NlbGVjdGVkRWxlbS5nZXRCb3VuZGluZ0NsaWVudFJlY3QoKTtcclxuICAgICAgICBsZXQgc3BsaXR0ZXJCb3VuZHM6IGFueSA9IHRoaXMuZWwubmF0aXZlRWxlbWVudC5nZXRCb3VuZGluZ0NsaWVudFJlY3QoKTtcclxuXHJcbiAgICAgICAgbGV0IG1vdmVYID0gTWF0aC5hYnMoZXZlbnQuY2xpZW50WCAtIHNwbGl0dGVyQm91bmRzW2RpcmVjdGlvbl0pO1xyXG4gICAgICAgIC8vIGNvbnNvbGUubG9nKG1vdmVYKTtcclxuICAgICAgICAvLyBsZXQgbmV3V2lkdGg6IG51bWJlciA9IHNlbGVjdGVkUGFuZUJvdW5kcy53aWR0aCAtIG1vdmVYO1xyXG4gICAgICAgIC8vIGNvbnNvbGUubG9nKG5ld1dpZHRoKTtcclxuICAgICAgICBsZXQgbmV3U2l6ZSA9IHRoaXMuX2NvbnZlcnRpb25TdmMuY29udmVydFB4VG9QZXJjZW50KG1vdmVYLCBzcGxpdHRlckJvdW5kcy53aWR0aCk7XHJcbiAgICAgICAgLy8gY29uc29sZS5sb2coJ25ld1NpemUgPSAnK25ld1NpemUpO1xyXG5cclxuICAgICAgICB0aGlzLl9kb21FbGVtU3ZjLnJlbW92ZUNsYXNzKHRoaXMuX3NlbGVjdGVkRWxlbSwgJ2FuaW1hdGlvbicpO1xyXG4gICAgICAgIHRoaXMuX3VwZGF0ZVNwbGl0UGFuZVNpemUobmV3U2l6ZSwgc3BsaXR0ZXJCb3VuZHMud2lkdGgpO1xyXG4gICAgICAgIHRoaXMuX3NwbGl0dGVyRXZlbnQuZHJhZyh0aGlzLl9zcGxpdHRlckxldmVsKTtcclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF9vblJlc2l6ZShldmVudDogYW55KTogdm9pZCB7XHJcbiAgICAgICAgbGV0IGlzTW9iaWxlOiBib29sZWFuID0gdGhpcy5fZG9tRWxlbVN2Yy5pc01vYmlsZSgpO1xyXG4gICAgICAgIGlmIChpc01vYmlsZSAhPT0gdGhpcy5fcHJldklzTW9iaWxlKSB7XHJcbiAgICAgICAgICAgIHRoaXMuX2lzRmlyc3RTd2l0Y2hWaWV3UG9ydCA9IHRydWU7XHJcbiAgICAgICAgICAgIHRoaXMuX3ByZXZJc01vYmlsZSA9IGlzTW9iaWxlO1xyXG4gICAgICAgICAgICB0aGlzLl9pc1N1YlBhbmVPcGVuID0gZmFsc2U7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIHRoaXMuX3NldERlZmF1bHRQYW5lU2l6ZSgpO1xyXG4gICAgICAgIHRoaXMuX2lzRmlyc3RTd2l0Y2hWaWV3UG9ydCA9IGZhbHNlO1xyXG4gICAgfVxyXG59XHJcbiJdfQ==