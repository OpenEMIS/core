import { Injectable } from '@angular/core';
import { KdBroadcaster } from '../../kd-common/index';
import * as i0 from "@angular/core";
import * as i1 from "../../kd-common/kd-broadcaster-svc";
export class KdSplitterEvent {
    constructor(broadcaster) {
        this.broadcaster = broadcaster;
    }
    fire(data) {
        this.broadcaster.broadcast('KdSplitterEvent_SideMenu', data);
    }
    on() {
        return this.broadcaster.on('KdSplitterEvent_SideMenu');
    }
    drag(data) {
        this.broadcaster.broadcast('KdSplitterEvent_Drag', data);
    }
    onDrag() {
        return this.broadcaster.on('KdSplitterEvent_Drag');
    }
    toggleMenu(data) {
        this.broadcaster.broadcast('KdSplitterEvent_ToggleMenu', data);
    }
    onToggleMenu() {
        return this.broadcaster.on('KdSplitterEvent_ToggleMenu');
    }
    toggleSubPane(data) {
        this.broadcaster.broadcast('KdSplitterEvent_ToggleSubPane', data);
    }
    onToggleSubPane() {
        return this.broadcaster.on('KdSplitterEvent_ToggleSubPane');
    }
    toggleAnimationSubPaneEnd(data) {
        this.broadcaster.broadcast('KdSplitterEvent_AnimationSubPaneEnd', data);
    }
    onToggleAnimationSubPaneEnd() {
        return this.broadcaster.on('KdSplitterEvent_AnimationSubPaneEnd');
    }
}
KdSplitterEvent.ɵprov = i0.ɵɵdefineInjectable({ factory: function KdSplitterEvent_Factory() { return new KdSplitterEvent(i0.ɵɵinject(i1.KdBroadcaster)); }, token: KdSplitterEvent, providedIn: "root" });
KdSplitterEvent.decorators = [
    { type: Injectable, args: [{
                providedIn: 'root'
            },] }
];
KdSplitterEvent.ctorParameters = () => [
    { type: KdBroadcaster }
];
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoia2Qtc3BsaXR0ZXItZXZlbnQuanMiLCJzb3VyY2VSb290IjoiRDovb3BlbkVNSVMvc3R5bGVndWlkZS9pb3N0Zy1vcGVuZW1pcy1zdHlsZWd1aWRlL3Byb2plY3RzL29wZW5lbWlzLXN0eWxlZ3VpZGUtbGliL3NyYy8iLCJzb3VyY2VzIjpbImtkLWNvbXBvbmVudHMva2QtYW5ndWxhci1zcGxpdHRlci9zcmMva2Qtc3BsaXR0ZXItZXZlbnQudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsT0FBTyxFQUFFLFVBQVUsRUFBRSxNQUFNLGVBQWUsQ0FBQztBQUUzQyxPQUFPLEVBQUUsYUFBYSxFQUFFLE1BQU0sdUJBQXVCLENBQUM7OztBQUt0RCxNQUFNLE9BQU8sZUFBZTtJQUN4QixZQUFvQixXQUEwQjtRQUExQixnQkFBVyxHQUFYLFdBQVcsQ0FBZTtJQUFJLENBQUM7SUFFbkQsSUFBSSxDQUFDLElBQWE7UUFDZCxJQUFJLENBQUMsV0FBVyxDQUFDLFNBQVMsQ0FBQywwQkFBMEIsRUFBRSxJQUFJLENBQUMsQ0FBQztJQUNqRSxDQUFDO0lBRUQsRUFBRTtRQUNFLE9BQU8sSUFBSSxDQUFDLFdBQVcsQ0FBQyxFQUFFLENBQVMsMEJBQTBCLENBQUMsQ0FBQztJQUNuRSxDQUFDO0lBRUQsSUFBSSxDQUFDLElBQVk7UUFDYixJQUFJLENBQUMsV0FBVyxDQUFDLFNBQVMsQ0FBQyxzQkFBc0IsRUFBRSxJQUFJLENBQUMsQ0FBQztJQUM3RCxDQUFDO0lBRUQsTUFBTTtRQUNGLE9BQU8sSUFBSSxDQUFDLFdBQVcsQ0FBQyxFQUFFLENBQVMsc0JBQXNCLENBQUMsQ0FBQztJQUMvRCxDQUFDO0lBRUQsVUFBVSxDQUFDLElBQVU7UUFDakIsSUFBSSxDQUFDLFdBQVcsQ0FBQyxTQUFTLENBQUMsNEJBQTRCLEVBQUUsSUFBSSxDQUFDLENBQUM7SUFDbkUsQ0FBQztJQUVELFlBQVk7UUFDUixPQUFPLElBQUksQ0FBQyxXQUFXLENBQUMsRUFBRSxDQUFNLDRCQUE0QixDQUFDLENBQUM7SUFDbEUsQ0FBQztJQUVELGFBQWEsQ0FBQyxJQUFhO1FBQ3ZCLElBQUksQ0FBQyxXQUFXLENBQUMsU0FBUyxDQUFDLCtCQUErQixFQUFFLElBQUksQ0FBQyxDQUFDO0lBQ3RFLENBQUM7SUFFRCxlQUFlO1FBQ1gsT0FBTyxJQUFJLENBQUMsV0FBVyxDQUFDLEVBQUUsQ0FBVSwrQkFBK0IsQ0FBQyxDQUFDO0lBQ3pFLENBQUM7SUFFRCx5QkFBeUIsQ0FBQyxJQUFjO1FBQ3BDLElBQUksQ0FBQyxXQUFXLENBQUMsU0FBUyxDQUFDLHFDQUFxQyxFQUFFLElBQUksQ0FBQyxDQUFDO0lBQzVFLENBQUM7SUFFRCwyQkFBMkI7UUFDdkIsT0FBTyxJQUFJLENBQUMsV0FBVyxDQUFDLEVBQUUsQ0FBVSxxQ0FBcUMsQ0FBQyxDQUFDO0lBQy9FLENBQUM7Ozs7WUE1Q0osVUFBVSxTQUFDO2dCQUNSLFVBQVUsRUFBRSxNQUFNO2FBQ3JCOzs7WUFKUSxhQUFhIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgSW5qZWN0YWJsZSB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xyXG5pbXBvcnQgeyBPYnNlcnZhYmxlIH0gZnJvbSAncnhqcyc7XHJcbmltcG9ydCB7IEtkQnJvYWRjYXN0ZXIgfSBmcm9tICcuLi8uLi9rZC1jb21tb24vaW5kZXgnO1xyXG5cclxuQEluamVjdGFibGUoe1xyXG4gICAgcHJvdmlkZWRJbjogJ3Jvb3QnXHJcbn0pXHJcbmV4cG9ydCBjbGFzcyBLZFNwbGl0dGVyRXZlbnQge1xyXG4gICAgY29uc3RydWN0b3IocHJpdmF0ZSBicm9hZGNhc3RlcjogS2RCcm9hZGNhc3RlcikgeyB9XHJcblxyXG4gICAgZmlyZShkYXRhPzogc3RyaW5nKTogdm9pZCB7XHJcbiAgICAgICAgdGhpcy5icm9hZGNhc3Rlci5icm9hZGNhc3QoJ0tkU3BsaXR0ZXJFdmVudF9TaWRlTWVudScsIGRhdGEpO1xyXG4gICAgfVxyXG5cclxuICAgIG9uKCk6IE9ic2VydmFibGU8c3RyaW5nPiB7XHJcbiAgICAgICAgcmV0dXJuIHRoaXMuYnJvYWRjYXN0ZXIub248c3RyaW5nPignS2RTcGxpdHRlckV2ZW50X1NpZGVNZW51Jyk7XHJcbiAgICB9XHJcblxyXG4gICAgZHJhZyhkYXRhOiBzdHJpbmcpOiB2b2lkIHtcclxuICAgICAgICB0aGlzLmJyb2FkY2FzdGVyLmJyb2FkY2FzdCgnS2RTcGxpdHRlckV2ZW50X0RyYWcnLCBkYXRhKTtcclxuICAgIH1cclxuXHJcbiAgICBvbkRyYWcoKTogT2JzZXJ2YWJsZTxzdHJpbmc+IHtcclxuICAgICAgICByZXR1cm4gdGhpcy5icm9hZGNhc3Rlci5vbjxzdHJpbmc+KCdLZFNwbGl0dGVyRXZlbnRfRHJhZycpO1xyXG4gICAgfVxyXG5cclxuICAgIHRvZ2dsZU1lbnUoZGF0YT86IGFueSk6IHZvaWQge1xyXG4gICAgICAgIHRoaXMuYnJvYWRjYXN0ZXIuYnJvYWRjYXN0KCdLZFNwbGl0dGVyRXZlbnRfVG9nZ2xlTWVudScsIGRhdGEpO1xyXG4gICAgfVxyXG5cclxuICAgIG9uVG9nZ2xlTWVudSgpOiBPYnNlcnZhYmxlPGFueT4ge1xyXG4gICAgICAgIHJldHVybiB0aGlzLmJyb2FkY2FzdGVyLm9uPGFueT4oJ0tkU3BsaXR0ZXJFdmVudF9Ub2dnbGVNZW51Jyk7XHJcbiAgICB9XHJcblxyXG4gICAgdG9nZ2xlU3ViUGFuZShkYXRhOiBib29sZWFuKTogdm9pZCB7XHJcbiAgICAgICAgdGhpcy5icm9hZGNhc3Rlci5icm9hZGNhc3QoJ0tkU3BsaXR0ZXJFdmVudF9Ub2dnbGVTdWJQYW5lJywgZGF0YSk7XHJcbiAgICB9XHJcblxyXG4gICAgb25Ub2dnbGVTdWJQYW5lKCk6IE9ic2VydmFibGU8Ym9vbGVhbj4ge1xyXG4gICAgICAgIHJldHVybiB0aGlzLmJyb2FkY2FzdGVyLm9uPGJvb2xlYW4+KCdLZFNwbGl0dGVyRXZlbnRfVG9nZ2xlU3ViUGFuZScpO1xyXG4gICAgfVxyXG5cclxuICAgIHRvZ2dsZUFuaW1hdGlvblN1YlBhbmVFbmQoZGF0YT86IGJvb2xlYW4pOiB2b2lkIHtcclxuICAgICAgICB0aGlzLmJyb2FkY2FzdGVyLmJyb2FkY2FzdCgnS2RTcGxpdHRlckV2ZW50X0FuaW1hdGlvblN1YlBhbmVFbmQnLCBkYXRhKTtcclxuICAgIH1cclxuXHJcbiAgICBvblRvZ2dsZUFuaW1hdGlvblN1YlBhbmVFbmQoKTogT2JzZXJ2YWJsZTxib29sZWFuPiB7XHJcbiAgICAgICAgcmV0dXJuIHRoaXMuYnJvYWRjYXN0ZXIub248Ym9vbGVhbj4oJ0tkU3BsaXR0ZXJFdmVudF9BbmltYXRpb25TdWJQYW5lRW5kJyk7XHJcbiAgICB9XHJcbn1cclxuIl19