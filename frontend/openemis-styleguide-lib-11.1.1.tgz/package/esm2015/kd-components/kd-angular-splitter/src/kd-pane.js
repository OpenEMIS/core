import { Component, HostBinding, ViewContainerRef, Input } from '@angular/core';
import { KdSplitter } from './kd-splitter';
export class KdPane {
    constructor(splitterContainer, _vcr) {
        this.splitterContainer = splitterContainer;
        this._vcr = _vcr;
        // @Input() size: String;
        this.classes = 'pane';
        this.index = this.splitterContainer.addGroup(this);
        this.classes += ' pane-' + this.index;
        this.element = this._vcr.element;
        let elemAttr = this._vcr.element.nativeElement.attributes;
        let elemAttrKeys = Object.keys(this._vcr.element.nativeElement.attributes);
        // console.log(elemAttr);
        // for(let i: number = 0; i < elemAttr.length; i++){
        //     console.log(elemAttr[i]);
        // }
        elemAttrKeys.forEach((key) => {
            this[elemAttr[key].name] = elemAttr[key].value;
            if (this.index < 1 && key === 'hidden') {
                delete this[elemAttr[key].name];
            }
        });
    }
    ngOnChanges(_simpleChanges) {
        if (_simpleChanges.hasOwnProperty('size') && !_simpleChanges['size'].firstChange) {
            this.splitterContainer.paneOnChange('size');
        }
        if (_simpleChanges.hasOwnProperty('max') && !_simpleChanges['max'].firstChange) {
            this.splitterContainer.paneOnChange('max');
        }
        if (_simpleChanges.hasOwnProperty('min') && !_simpleChanges['min'].firstChange) {
            this.splitterContainer.paneOnChange('min');
        }
    }
    ngAfterViewInit() {
        // console.log('on after view init');
        //        console.log(this.childrenSplitter);
    }
}
KdPane.decorators = [
    { type: Component, args: [{
                selector: 'kd-pane',
                // template: `<div *ngIf='index > 1' class='splitter-handler sh-{{index}}'></div>
                //           <ng-content></ng-content>`,
                template: `<ng-content></ng-content>`
            },] }
];
KdPane.ctorParameters = () => [
    { type: KdSplitter },
    { type: ViewContainerRef }
];
KdPane.propDecorators = {
    classes: [{ type: HostBinding, args: ['class',] }],
    size: [{ type: Input }],
    max: [{ type: Input }],
    min: [{ type: Input }],
    show: [{ type: Input }]
};
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoia2QtcGFuZS5qcyIsInNvdXJjZVJvb3QiOiJEOi9vcGVuRU1JUy9zdHlsZWd1aWRlL2lvc3RnLW9wZW5lbWlzLXN0eWxlZ3VpZGUvcHJvamVjdHMvb3BlbmVtaXMtc3R5bGVndWlkZS1saWIvc3JjLyIsInNvdXJjZXMiOlsia2QtY29tcG9uZW50cy9rZC1hbmd1bGFyLXNwbGl0dGVyL3NyYy9rZC1wYW5lLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBLE9BQU8sRUFDSCxTQUFTLEVBQ1QsV0FBVyxFQUNYLGdCQUFnQixFQU9oQixLQUFLLEVBQ1IsTUFBTSxlQUFlLENBQUM7QUFFdkIsT0FBTyxFQUFFLFVBQVUsRUFBRSxNQUFNLGVBQWUsQ0FBQztBQVUzQyxNQUFNLE9BQU8sTUFBTTtJQWVmLFlBQW9CLGlCQUE2QixFQUFVLElBQXNCO1FBQTdELHNCQUFpQixHQUFqQixpQkFBaUIsQ0FBWTtRQUFVLFNBQUksR0FBSixJQUFJLENBQWtCO1FBZGpGLHlCQUF5QjtRQUNILFlBQU8sR0FBRyxNQUFNLENBQUM7UUFjbkMsSUFBSSxDQUFDLEtBQUssR0FBRyxJQUFJLENBQUMsaUJBQWlCLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxDQUFDO1FBQ25ELElBQUksQ0FBQyxPQUFPLElBQUksUUFBUSxHQUFHLElBQUksQ0FBQyxLQUFLLENBQUM7UUFDdEMsSUFBSSxDQUFDLE9BQU8sR0FBRyxJQUFJLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQztRQUVqQyxJQUFJLFFBQVEsR0FBRyxJQUFJLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxhQUFhLENBQUMsVUFBVSxDQUFDO1FBQzFELElBQUksWUFBWSxHQUFHLE1BQU0sQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsYUFBYSxDQUFDLFVBQVUsQ0FBQyxDQUFDO1FBQzNFLHlCQUF5QjtRQUN6QixvREFBb0Q7UUFDcEQsZ0NBQWdDO1FBQ2hDLElBQUk7UUFFSixZQUFZLENBQUMsT0FBTyxDQUFDLENBQUMsR0FBUSxFQUFRLEVBQUU7WUFDcEMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxHQUFHLENBQUMsQ0FBQyxJQUFJLENBQUMsR0FBRyxRQUFRLENBQUMsR0FBRyxDQUFDLENBQUMsS0FBSyxDQUFDO1lBQy9DLElBQUksSUFBSSxDQUFDLEtBQUssR0FBRyxDQUFDLElBQUksR0FBRyxLQUFLLFFBQVEsRUFBRTtnQkFDcEMsT0FBTyxJQUFJLENBQUMsUUFBUSxDQUFDLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDO2FBQ25DO1FBQ0wsQ0FBQyxDQUFDLENBQUM7SUFDUCxDQUFDO0lBRUQsV0FBVyxDQUFDLGNBQTZCO1FBQ3JDLElBQUksY0FBYyxDQUFDLGNBQWMsQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLGNBQWMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxXQUFXLEVBQUU7WUFDOUUsSUFBSSxDQUFDLGlCQUFpQixDQUFDLFlBQVksQ0FBQyxNQUFNLENBQUMsQ0FBQztTQUMvQztRQUNELElBQUksY0FBYyxDQUFDLGNBQWMsQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLGNBQWMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxXQUFXLEVBQUU7WUFDNUUsSUFBSSxDQUFDLGlCQUFpQixDQUFDLFlBQVksQ0FBQyxLQUFLLENBQUMsQ0FBQztTQUM5QztRQUNELElBQUksY0FBYyxDQUFDLGNBQWMsQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLGNBQWMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxXQUFXLEVBQUU7WUFDNUUsSUFBSSxDQUFDLGlCQUFpQixDQUFDLFlBQVksQ0FBQyxLQUFLLENBQUMsQ0FBQztTQUM5QztJQUNMLENBQUM7SUFFRCxlQUFlO1FBQ1gscUNBQXFDO1FBQ3JDLDZDQUE2QztJQUVqRCxDQUFDOzs7WUExREosU0FBUyxTQUFDO2dCQUNQLFFBQVEsRUFBRSxTQUFTO2dCQUNuQixpRkFBaUY7Z0JBQ2pGLHdDQUF3QztnQkFDeEMsUUFBUSxFQUFFLDJCQUEyQjthQUN4Qzs7O1lBUlEsVUFBVTtZQVZmLGdCQUFnQjs7O3NCQXNCZixXQUFXLFNBQUMsT0FBTzttQkFJbkIsS0FBSztrQkFDTCxLQUFLO2tCQUNMLEtBQUs7bUJBQ0wsS0FBSyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7XHJcbiAgICBDb21wb25lbnQsXHJcbiAgICBIb3N0QmluZGluZyxcclxuICAgIFZpZXdDb250YWluZXJSZWYsXHJcbiAgICBFbGVtZW50UmVmLFxyXG4gICAgLy8gQ29udGVudENoaWxkcmVuLFxyXG4gICAgLy8gUXVlcnlMaXN0LFxyXG4gICAgQWZ0ZXJWaWV3SW5pdCxcclxuICAgIE9uQ2hhbmdlcyxcclxuICAgIFNpbXBsZUNoYW5nZXMsXHJcbiAgICBJbnB1dFxyXG59IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xyXG5cclxuaW1wb3J0IHsgS2RTcGxpdHRlciB9IGZyb20gJy4va2Qtc3BsaXR0ZXInO1xyXG5cclxuXHJcbkBDb21wb25lbnQoe1xyXG4gICAgc2VsZWN0b3I6ICdrZC1wYW5lJyxcclxuICAgIC8vIHRlbXBsYXRlOiBgPGRpdiAqbmdJZj0naW5kZXggPiAxJyBjbGFzcz0nc3BsaXR0ZXItaGFuZGxlciBzaC17e2luZGV4fX0nPjwvZGl2PlxyXG4gICAgLy8gICAgICAgICAgIDxuZy1jb250ZW50PjwvbmctY29udGVudD5gLFxyXG4gICAgdGVtcGxhdGU6IGA8bmctY29udGVudD48L25nLWNvbnRlbnQ+YCxcclxufSlcclxuXHJcbmV4cG9ydCBjbGFzcyBLZFBhbmUgaW1wbGVtZW50cyBPbkNoYW5nZXMsIEFmdGVyVmlld0luaXQge1xyXG4gICAgLy8gQElucHV0KCkgc2l6ZTogU3RyaW5nO1xyXG4gICAgQEhvc3RCaW5kaW5nKCdjbGFzcycpIGNsYXNzZXMgPSAncGFuZSc7XHJcbiAgICAvLyBAQ29udGVudENoaWxkcmVuKEtkU3BsaXR0ZXIpIGNoaWxkcmVuU3BsaXR0ZXI6IFF1ZXJ5TGlzdDxLZFNwbGl0dGVyPjtcclxuXHJcbiAgICBpbmRleDogbnVtYmVyO1xyXG4gICAgQElucHV0KCkgc2l6ZTogc3RyaW5nO1xyXG4gICAgQElucHV0KCkgbWF4OiBzdHJpbmc7XHJcbiAgICBASW5wdXQoKSBtaW46IHN0cmluZztcclxuICAgIEBJbnB1dCgpIHNob3c6IHN0cmluZztcclxuICAgIC8vICAgICBzaXplOiBzdHJpbmc7XHJcbiAgICAvLyBtYXg6IHN0cmluZztcclxuICAgIC8vIG1pbjogc3RyaW5nO1xyXG4gICAgaGlkZGVuOiBib29sZWFuO1xyXG4gICAgZWxlbWVudDogRWxlbWVudFJlZjtcclxuICAgIGNvbnN0cnVjdG9yKHByaXZhdGUgc3BsaXR0ZXJDb250YWluZXI6IEtkU3BsaXR0ZXIsIHByaXZhdGUgX3ZjcjogVmlld0NvbnRhaW5lclJlZikge1xyXG4gICAgICAgIHRoaXMuaW5kZXggPSB0aGlzLnNwbGl0dGVyQ29udGFpbmVyLmFkZEdyb3VwKHRoaXMpO1xyXG4gICAgICAgIHRoaXMuY2xhc3NlcyArPSAnIHBhbmUtJyArIHRoaXMuaW5kZXg7XHJcbiAgICAgICAgdGhpcy5lbGVtZW50ID0gdGhpcy5fdmNyLmVsZW1lbnQ7XHJcblxyXG4gICAgICAgIGxldCBlbGVtQXR0ciA9IHRoaXMuX3Zjci5lbGVtZW50Lm5hdGl2ZUVsZW1lbnQuYXR0cmlidXRlcztcclxuICAgICAgICBsZXQgZWxlbUF0dHJLZXlzID0gT2JqZWN0LmtleXModGhpcy5fdmNyLmVsZW1lbnQubmF0aXZlRWxlbWVudC5hdHRyaWJ1dGVzKTtcclxuICAgICAgICAvLyBjb25zb2xlLmxvZyhlbGVtQXR0cik7XHJcbiAgICAgICAgLy8gZm9yKGxldCBpOiBudW1iZXIgPSAwOyBpIDwgZWxlbUF0dHIubGVuZ3RoOyBpKyspe1xyXG4gICAgICAgIC8vICAgICBjb25zb2xlLmxvZyhlbGVtQXR0cltpXSk7XHJcbiAgICAgICAgLy8gfVxyXG5cclxuICAgICAgICBlbGVtQXR0cktleXMuZm9yRWFjaCgoa2V5OiBhbnkpOiB2b2lkID0+IHtcclxuICAgICAgICAgICAgdGhpc1tlbGVtQXR0cltrZXldLm5hbWVdID0gZWxlbUF0dHJba2V5XS52YWx1ZTtcclxuICAgICAgICAgICAgaWYgKHRoaXMuaW5kZXggPCAxICYmIGtleSA9PT0gJ2hpZGRlbicpIHtcclxuICAgICAgICAgICAgICAgIGRlbGV0ZSB0aGlzW2VsZW1BdHRyW2tleV0ubmFtZV07XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9KTtcclxuICAgIH1cclxuXHJcbiAgICBuZ09uQ2hhbmdlcyhfc2ltcGxlQ2hhbmdlczogU2ltcGxlQ2hhbmdlcykge1xyXG4gICAgICAgIGlmIChfc2ltcGxlQ2hhbmdlcy5oYXNPd25Qcm9wZXJ0eSgnc2l6ZScpICYmICFfc2ltcGxlQ2hhbmdlc1snc2l6ZSddLmZpcnN0Q2hhbmdlKSB7XHJcbiAgICAgICAgICAgIHRoaXMuc3BsaXR0ZXJDb250YWluZXIucGFuZU9uQ2hhbmdlKCdzaXplJyk7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGlmIChfc2ltcGxlQ2hhbmdlcy5oYXNPd25Qcm9wZXJ0eSgnbWF4JykgJiYgIV9zaW1wbGVDaGFuZ2VzWydtYXgnXS5maXJzdENoYW5nZSkge1xyXG4gICAgICAgICAgICB0aGlzLnNwbGl0dGVyQ29udGFpbmVyLnBhbmVPbkNoYW5nZSgnbWF4Jyk7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGlmIChfc2ltcGxlQ2hhbmdlcy5oYXNPd25Qcm9wZXJ0eSgnbWluJykgJiYgIV9zaW1wbGVDaGFuZ2VzWydtaW4nXS5maXJzdENoYW5nZSkge1xyXG4gICAgICAgICAgICB0aGlzLnNwbGl0dGVyQ29udGFpbmVyLnBhbmVPbkNoYW5nZSgnbWluJyk7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIG5nQWZ0ZXJWaWV3SW5pdCgpOiB2b2lkIHtcclxuICAgICAgICAvLyBjb25zb2xlLmxvZygnb24gYWZ0ZXIgdmlldyBpbml0Jyk7XHJcbiAgICAgICAgLy8gICAgICAgIGNvbnNvbGUubG9nKHRoaXMuY2hpbGRyZW5TcGxpdHRlcik7XHJcblxyXG4gICAgfVxyXG59XHJcbiJdfQ==