import { Component, ViewEncapsulation, Input } from '@angular/core';
export class KdGridsterToolbar {
    constructor() {
        this.leftButtons = [];
    }
    ngOnInit() {
        let buttonList = (this.item.buttons && this.item.buttons.length > 0) ? this.item.buttons : this.config.buttons;
        this.getGridItemToolbarButtons(buttonList);
    }
    getGridItemToolbarButtons(_buttonList) {
        this.rightButtons = _buttonList.filter((button, index) => {
            if (button.position === 'left') {
                this.leftButtons.push(button);
                return false;
            }
            return true;
        });
    }
}
KdGridsterToolbar.decorators = [
    { type: Component, args: [{
                selector: 'kd-gridster-toolbar',
                providers: [],
                encapsulation: ViewEncapsulation.None,
                template: "<div class=\"kdx-item-buttons-right\" [ngClass]=\"{'no-drag': !item.enableContentDrag}\" *ngIf=\"!config.hideCustomButton\">\r\n    <button *ngFor=\"let button of rightButtons\" (mousedown)=\"button.callback(button, item)\" class=\"kdx-item-buttons kdx-item-edit btn-outline rounded-circle {{button.position}}\" [ngClass]=\"{'btn hidden': !button.visible, 'btn disabled': button.disabled}\" [kd-tooltip-dir]=\"button.name\" tooltipPosition=\"bottom\" tooltipStyleClass=\"kdx-tooltip-default\" [tooltipDisabled]=\"button.disabled\" [disabled]=\"button.disabled\">\r\n        <i class=\"{{button.icon}}\"></i>\r\n    </button>\r\n</div>\r\n<div class=\"kdx-item-buttons-left\" [ngClass]=\"{'no-drag': !item.enableContentDrag}\" *ngIf=\"!config.hideCustomButton\">\r\n    <button *ngFor=\"let button of leftButtons\" (mousedown)=\"button.callback(button, item)\" class=\"kdx-item-buttons kdx-item-edit btn-outline rounded-circle {{button.position}}\" [ngClass]=\"{'btn hidden': !button.visible, 'btn disabled': button.disabled}\" [kd-tooltip-dir]=\"button.name\" tooltipPosition=\"bottom\" tooltipStyleClass=\"kdx-tooltip-default\" [tooltipDisabled]=\"button.disabled\" [disabled]=\"button.disabled\">\r\n        <i class=\"{{button.icon}}\"></i>\r\n    </button>\r\n</div>\r\n<button  *ngIf=\"(!config.hideDragButton && config.draggable.enabled) || (config.hideDragButton && config.draggable.enabled && !item.enableContentDrag)\" class=\"kdx-item-buttons kdx-item-drag btn-outline rounded-circle drag-handler\" [kd-tooltip-dir]=\"'Drag'\" tooltipPosition=\"bottom\" tooltipStyleClass=\"kdx-tooltip-default\">\r\n        <i class=\"fa fa-arrows\"></i>\r\n    </button>",
                host: { 'class': 'kdx-gridster-toolbar' }
            },] }
];
KdGridsterToolbar.ctorParameters = () => [];
KdGridsterToolbar.propDecorators = {
    item: [{ type: Input }],
    config: [{ type: Input }]
};
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoia2QtZ3JpZHN0ZXItdG9vbGJhci5qcyIsInNvdXJjZVJvb3QiOiJEOi9vcGVuRU1JUy9zdHlsZWd1aWRlL2lvc3RnLW9wZW5lbWlzLXN0eWxlZ3VpZGUvcHJvamVjdHMvb3BlbmVtaXMtc3R5bGVndWlkZS1saWIvc3JjLyIsInNvdXJjZXMiOlsia2QtY29tcG9uZW50cy9rZC1hbmd1bGFyLWdyaWRzdGVyL2tkLWFuZ3VsYXItZ3JpZHN0ZXItdG9vbGJhci9rZC1ncmlkc3Rlci10b29sYmFyLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBLE9BQU8sRUFDSCxTQUFTLEVBQ1QsaUJBQWlCLEVBRWpCLEtBQUssRUFDUixNQUFNLGVBQWUsQ0FBQztBQWdCdkIsTUFBTSxPQUFPLGlCQUFpQjtJQVExQjtRQUhPLGdCQUFXLEdBQTJCLEVBQUUsQ0FBQztJQUk1QyxDQUFDO0lBRUwsUUFBUTtRQUNKLElBQUksVUFBVSxHQUEyQixDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsT0FBTyxJQUFJLElBQUksQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLE1BQU0sR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDO1FBQ3ZJLElBQUksQ0FBQyx5QkFBeUIsQ0FBQyxVQUFVLENBQUMsQ0FBQztJQUMvQyxDQUFDO0lBRU8seUJBQXlCLENBQUMsV0FBbUM7UUFDakUsSUFBSSxDQUFDLFlBQVksR0FBRyxXQUFXLENBQUMsTUFBTSxDQUFDLENBQUMsTUFBTSxFQUFFLEtBQUssRUFBRSxFQUFFO1lBQ3JELElBQUksTUFBTSxDQUFDLFFBQVEsS0FBSyxNQUFNLEVBQUU7Z0JBQzVCLElBQUksQ0FBQyxXQUFXLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDO2dCQUM5QixPQUFPLEtBQUssQ0FBQzthQUNoQjtZQUNELE9BQU8sSUFBSSxDQUFDO1FBQ2hCLENBQUMsQ0FBQyxDQUFDO0lBQ1AsQ0FBQzs7O1lBaENKLFNBQVMsU0FBQztnQkFDUCxRQUFRLEVBQUUscUJBQXFCO2dCQUMvQixTQUFTLEVBQUUsRUFBRTtnQkFDYixhQUFhLEVBQUUsaUJBQWlCLENBQUMsSUFBSTtnQkFDckMsNm9EQUF5QztnQkFDekMsSUFBSSxFQUFFLEVBQUUsT0FBTyxFQUFFLHNCQUFzQixFQUFFO2FBQzVDOzs7O21CQUlJLEtBQUs7cUJBQ0wsS0FBSyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7XHJcbiAgICBDb21wb25lbnQsXHJcbiAgICBWaWV3RW5jYXBzdWxhdGlvbixcclxuICAgIE9uSW5pdCxcclxuICAgIElucHV0XHJcbn0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XHJcblxyXG5pbXBvcnQge1xyXG4gICAgSUdyaWRzdGVySXRlbSxcclxuICAgIElHcmlkc3RlckNvbmZpZyxcclxuICAgIElHcmlkc3RlckJ1dHRvblxyXG59IGZyb20gJy4uL2tkLWdyaWRzdGVyLWludGVyZmFjZSc7XHJcblxyXG5AQ29tcG9uZW50KHtcclxuICAgIHNlbGVjdG9yOiAna2QtZ3JpZHN0ZXItdG9vbGJhcicsXHJcbiAgICBwcm92aWRlcnM6IFtdLFxyXG4gICAgZW5jYXBzdWxhdGlvbjogVmlld0VuY2Fwc3VsYXRpb24uTm9uZSxcclxuICAgIHRlbXBsYXRlVXJsOiAnLi9rZC1ncmlkc3Rlci10b29sYmFyLmh0bWwnLFxyXG4gICAgaG9zdDogeyAnY2xhc3MnOiAna2R4LWdyaWRzdGVyLXRvb2xiYXInIH1cclxufSlcclxuXHJcbmV4cG9ydCBjbGFzcyBLZEdyaWRzdGVyVG9vbGJhciBpbXBsZW1lbnRzIE9uSW5pdCB7XHJcblxyXG4gICAgQElucHV0KCkgaXRlbTogSUdyaWRzdGVySXRlbTtcclxuICAgIEBJbnB1dCgpIGNvbmZpZzogSUdyaWRzdGVyQ29uZmlnO1xyXG5cclxuICAgIHB1YmxpYyBsZWZ0QnV0dG9uczogQXJyYXk8SUdyaWRzdGVyQnV0dG9uPiA9IFtdO1xyXG4gICAgcHVibGljIHJpZ2h0QnV0dG9uczogQXJyYXk8SUdyaWRzdGVyQnV0dG9uPjtcclxuXHJcbiAgICBjb25zdHJ1Y3RvcihcclxuICAgICkgeyB9XHJcblxyXG4gICAgbmdPbkluaXQoKTogdm9pZCB7XHJcbiAgICAgICAgbGV0IGJ1dHRvbkxpc3Q6IEFycmF5PElHcmlkc3RlckJ1dHRvbj4gPSAodGhpcy5pdGVtLmJ1dHRvbnMgJiYgdGhpcy5pdGVtLmJ1dHRvbnMubGVuZ3RoID4gMCkgPyB0aGlzLml0ZW0uYnV0dG9ucyA6IHRoaXMuY29uZmlnLmJ1dHRvbnM7XHJcbiAgICAgICAgdGhpcy5nZXRHcmlkSXRlbVRvb2xiYXJCdXR0b25zKGJ1dHRvbkxpc3QpO1xyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgZ2V0R3JpZEl0ZW1Ub29sYmFyQnV0dG9ucyhfYnV0dG9uTGlzdDogQXJyYXk8SUdyaWRzdGVyQnV0dG9uPik6IHZvaWQge1xyXG4gICAgICAgIHRoaXMucmlnaHRCdXR0b25zID0gX2J1dHRvbkxpc3QuZmlsdGVyKChidXR0b24sIGluZGV4KSA9PiB7XHJcbiAgICAgICAgICAgIGlmIChidXR0b24ucG9zaXRpb24gPT09ICdsZWZ0Jykge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5sZWZ0QnV0dG9ucy5wdXNoKGJ1dHRvbik7XHJcbiAgICAgICAgICAgICAgICByZXR1cm4gZmFsc2U7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgcmV0dXJuIHRydWU7XHJcbiAgICAgICAgfSk7XHJcbiAgICB9XHJcbn1cclxuIl19