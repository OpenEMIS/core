import { Injectable } from '@angular/core';
import { KdBroadcaster } from '../kd-common/index';
export class KdGridsterSvc {
    constructor(broadcaster) {
        this.broadcaster = broadcaster;
    }
    setEmitter(gridsterItemResizeEmitter, getGridsterItemEmitter) {
        this.gridsterItemResizeEmitter = gridsterItemResizeEmitter;
        this.getGridsterItem = getGridsterItemEmitter;
    }
    /**
     * generate default gridster config
     *  default gridster config
     */
    getDefaultGridsterConfig() {
        return {
            // gridster plugin property
            gridType: 'scrollVertical',
            mobileBreakpoint: 0,
            defaultItemCols: 20,
            defaultItemRows: 10,
            draggable: {
                enabled: true,
                ignoreContentClass: 'no-drag',
            },
            resizable: {
                enabled: true,
            },
            pushItems: false,
            disablePushOnDrag: true,
            disablePushOnResize: true,
            pushResizeItems: false,
            pushDirections: { north: false, east: false, south: false, west: false },
            displayGrid: 'onDrag&Resize',
            scrollToNewItems: true,
            disableAutoPositionOnConflict: true,
            setGridSize: false,
            minCols: 100,
            maxCols: 100,
            maxRows: 100,
            // add-on property
            border: false,
            enableEditMode: false,
            hideDragButtons: false,
            hideCustomButtons: false,
            setFixCenter: false,
            enableDowngrade: false,
            buttons: []
        };
    }
    /**
     * return combination of default gridster config and user define config
     *    _config  config from user/application
     *             [description]
     */
    getConfig(_config) {
        if (typeof _config === 'undefined')
            _config = {};
        let gridsterDefaultConfig = this.getDefaultGridsterConfig();
        gridsterDefaultConfig.itemInitCallback = (item, itemComponent) => this._onItemInit(item, itemComponent);
        gridsterDefaultConfig.itemResizeCallback = (item, itemComponent) => this._onItemResize(item, itemComponent);
        return Object.assign({}, gridsterDefaultConfig, _config);
    }
    _onItemInit(_item, _itemComponent) {
        // console.log('_onItemInit', JSON.stringify(_item));
        _itemComponent.el.className += ' kdx-display-box';
        _item.isDoneInit = true;
        this.getGridsterItem.emit(_item);
        this._gridsterItemInit(_item);
    }
    _onItemResize(_item, _itemComponent) {
        if (!_item.isDoneInit) {
            this._gridsterItemResize(_item);
            this.gridsterItemResizeEmitter.emit(_item);
        }
        else {
            _item.isDoneInit = false;
        }
    }
    onGridsterItemInit() {
        return this.broadcaster.on('KdGridsterEvent_onItemInit');
    }
    _gridsterItemInit(_item) {
        this.broadcaster.broadcast('KdGridsterEvent_onItemInit', _item);
    }
    onGridsterItemResize() {
        return this.broadcaster.on('KdGridsterEvent_onItemResize');
    }
    _gridsterItemResize(_item) {
        this.broadcaster.broadcast('KdGridsterEvent_onItemResize', _item);
    }
    onGridsterRemoved() {
        return this.broadcaster.on('KdGridsterEvent_onRemoved');
    }
    gridsterRemoved() {
        this.broadcaster.broadcast('KdGridsterEvent_onRemoved');
    }
}
KdGridsterSvc.decorators = [
    { type: Injectable }
];
KdGridsterSvc.ctorParameters = () => [
    { type: KdBroadcaster }
];
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoia2QtZ3JpZHN0ZXItc3ZjLmpzIiwic291cmNlUm9vdCI6IkQ6L29wZW5FTUlTL3N0eWxlZ3VpZGUvaW9zdGctb3BlbmVtaXMtc3R5bGVndWlkZS9wcm9qZWN0cy9vcGVuZW1pcy1zdHlsZWd1aWRlLWxpYi9zcmMvIiwic291cmNlcyI6WyJrZC1jb21wb25lbnRzL2tkLWFuZ3VsYXItZ3JpZHN0ZXIva2QtZ3JpZHN0ZXItc3ZjLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBLE9BQU8sRUFBRSxVQUFVLEVBQWdCLE1BQU0sZUFBZSxDQUFDO0FBT3pELE9BQU8sRUFBRSxhQUFhLEVBQUUsTUFBTSxvQkFBb0IsQ0FBQztBQUluRCxNQUFNLE9BQU8sYUFBYTtJQUt0QixZQUFvQixXQUEwQjtRQUExQixnQkFBVyxHQUFYLFdBQVcsQ0FBZTtJQUFJLENBQUM7SUFFNUMsVUFBVSxDQUFDLHlCQUFxRCxFQUFFLHNCQUFrRDtRQUN2SCxJQUFJLENBQUMseUJBQXlCLEdBQUcseUJBQXlCLENBQUM7UUFDM0QsSUFBSSxDQUFDLGVBQWUsR0FBRyxzQkFBc0IsQ0FBQztJQUNsRCxDQUFDO0lBRUQ7OztPQUdHO0lBQ0ssd0JBQXdCO1FBQzVCLE9BQU87WUFDSCwyQkFBMkI7WUFDM0IsUUFBUSxFQUFFLGdCQUFnQjtZQUMxQixnQkFBZ0IsRUFBRSxDQUFDO1lBQ25CLGVBQWUsRUFBRSxFQUFFO1lBQ25CLGVBQWUsRUFBRSxFQUFFO1lBQ25CLFNBQVMsRUFBRTtnQkFDUCxPQUFPLEVBQUUsSUFBSTtnQkFDYixrQkFBa0IsRUFBRSxTQUFTO2FBQ2hDO1lBQ0QsU0FBUyxFQUFFO2dCQUNQLE9BQU8sRUFBRSxJQUFJO2FBQ2hCO1lBQ0QsU0FBUyxFQUFFLEtBQUs7WUFDaEIsaUJBQWlCLEVBQUUsSUFBSTtZQUN2QixtQkFBbUIsRUFBRSxJQUFJO1lBQ3pCLGVBQWUsRUFBRSxLQUFLO1lBQ3RCLGNBQWMsRUFBRSxFQUFFLEtBQUssRUFBRSxLQUFLLEVBQUUsSUFBSSxFQUFFLEtBQUssRUFBRSxLQUFLLEVBQUUsS0FBSyxFQUFFLElBQUksRUFBRSxLQUFLLEVBQUU7WUFDeEUsV0FBVyxFQUFFLGVBQWU7WUFDNUIsZ0JBQWdCLEVBQUUsSUFBSTtZQUN0Qiw2QkFBNkIsRUFBRSxJQUFJO1lBQ25DLFdBQVcsRUFBRSxLQUFLO1lBQ2xCLE9BQU8sRUFBRSxHQUFHO1lBQ1osT0FBTyxFQUFFLEdBQUc7WUFDWixPQUFPLEVBQUUsR0FBRztZQUVaLGtCQUFrQjtZQUNsQixNQUFNLEVBQUUsS0FBSztZQUNiLGNBQWMsRUFBRSxLQUFLO1lBQ3JCLGVBQWUsRUFBRSxLQUFLO1lBQ3RCLGlCQUFpQixFQUFFLEtBQUs7WUFDeEIsWUFBWSxFQUFFLEtBQUs7WUFDbkIsZUFBZSxFQUFFLEtBQUs7WUFDdEIsT0FBTyxFQUFFLEVBQUU7U0FDZCxDQUFDO0lBQ04sQ0FBQztJQUVEOzs7O09BSUc7SUFDSSxTQUFTLENBQUMsT0FBd0I7UUFDckMsSUFBSSxPQUFPLE9BQU8sS0FBSyxXQUFXO1lBQUUsT0FBTyxHQUFHLEVBQUUsQ0FBQztRQUVqRCxJQUFJLHFCQUFxQixHQUFtQixJQUFJLENBQUMsd0JBQXdCLEVBQUUsQ0FBQztRQUU1RSxxQkFBcUIsQ0FBQyxnQkFBZ0IsR0FBRyxDQUFDLElBQWtCLEVBQUUsYUFBNkMsRUFBRSxFQUFFLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxJQUFJLEVBQUUsYUFBYSxDQUFDLENBQUM7UUFFdEoscUJBQXFCLENBQUMsa0JBQWtCLEdBQUcsQ0FBQyxJQUFrQixFQUFFLGFBQTZDLEVBQUUsRUFBRSxDQUFDLElBQUksQ0FBQyxhQUFhLENBQUMsSUFBSSxFQUFFLGFBQWEsQ0FBQyxDQUFDO1FBRTFKLE9BQXlCLE1BQU8sQ0FBQyxNQUFNLENBQUMsRUFBRSxFQUFFLHFCQUFxQixFQUFFLE9BQU8sQ0FBQyxDQUFDO0lBQ2hGLENBQUM7SUFFTyxXQUFXLENBQUMsS0FBbUIsRUFBRSxjQUE4QztRQUNuRixxREFBcUQ7UUFDckQsY0FBYyxDQUFDLEVBQUUsQ0FBQyxTQUFTLElBQUksa0JBQWtCLENBQUM7UUFDbEQsS0FBSyxDQUFDLFVBQVUsR0FBRyxJQUFJLENBQUM7UUFDeEIsSUFBSSxDQUFDLGVBQWUsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLENBQUM7UUFDakMsSUFBSSxDQUFDLGlCQUFpQixDQUFDLEtBQUssQ0FBQyxDQUFDO0lBQ2xDLENBQUM7SUFFTyxhQUFhLENBQUMsS0FBbUIsRUFBRSxjQUE4QztRQUNyRixJQUFJLENBQUMsS0FBSyxDQUFDLFVBQVUsRUFBRTtZQUNuQixJQUFJLENBQUMsbUJBQW1CLENBQUMsS0FBSyxDQUFDLENBQUM7WUFDaEMsSUFBSSxDQUFDLHlCQUF5QixDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQztTQUM5QzthQUNJO1lBQ0QsS0FBSyxDQUFDLFVBQVUsR0FBRyxLQUFLLENBQUM7U0FDNUI7SUFDTCxDQUFDO0lBRU0sa0JBQWtCO1FBQ3JCLE9BQU8sSUFBSSxDQUFDLFdBQVcsQ0FBQyxFQUFFLENBQU0sNEJBQTRCLENBQUMsQ0FBQztJQUNsRSxDQUFDO0lBRU8saUJBQWlCLENBQUMsS0FBVTtRQUNoQyxJQUFJLENBQUMsV0FBVyxDQUFDLFNBQVMsQ0FBQyw0QkFBNEIsRUFBRSxLQUFLLENBQUMsQ0FBQztJQUNwRSxDQUFDO0lBRU0sb0JBQW9CO1FBQ3ZCLE9BQU8sSUFBSSxDQUFDLFdBQVcsQ0FBQyxFQUFFLENBQU0sOEJBQThCLENBQUMsQ0FBQztJQUNwRSxDQUFDO0lBRU8sbUJBQW1CLENBQUMsS0FBVTtRQUNsQyxJQUFJLENBQUMsV0FBVyxDQUFDLFNBQVMsQ0FBQyw4QkFBOEIsRUFBRSxLQUFLLENBQUMsQ0FBQztJQUN0RSxDQUFDO0lBRU0saUJBQWlCO1FBQ3BCLE9BQU8sSUFBSSxDQUFDLFdBQVcsQ0FBQyxFQUFFLENBQU0sMkJBQTJCLENBQUMsQ0FBQztJQUNqRSxDQUFDO0lBRU0sZUFBZTtRQUNsQixJQUFJLENBQUMsV0FBVyxDQUFDLFNBQVMsQ0FBQywyQkFBMkIsQ0FBQyxDQUFDO0lBQzVELENBQUM7OztZQWhISixVQUFVOzs7WUFIRixhQUFhIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgSW5qZWN0YWJsZSwgRXZlbnRFbWl0dGVyIH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XHJcbmltcG9ydCB7IElHcmlkc3RlckNvbmZpZyB9IGZyb20gJy4va2QtZ3JpZHN0ZXItaW50ZXJmYWNlJztcclxuaW1wb3J0IHtcclxuICAgIEdyaWRzdGVyQ29uZmlnLFxyXG4gICAgR3JpZHN0ZXJJdGVtLFxyXG4gICAgR3JpZHN0ZXJJdGVtQ29tcG9uZW50SW50ZXJmYWNlXHJcbn0gZnJvbSAnYW5ndWxhci1ncmlkc3RlcjInO1xyXG5pbXBvcnQgeyBLZEJyb2FkY2FzdGVyIH0gZnJvbSAnLi4va2QtY29tbW9uL2luZGV4JztcclxuaW1wb3J0IHsgT2JzZXJ2YWJsZSB9IGZyb20gJ3J4anMnO1xyXG5cclxuQEluamVjdGFibGUoKVxyXG5leHBvcnQgY2xhc3MgS2RHcmlkc3RlclN2YyB7XHJcblxyXG4gICAgcHJpdmF0ZSBnZXRHcmlkc3Rlckl0ZW06IEV2ZW50RW1pdHRlcjxHcmlkc3Rlckl0ZW0+O1xyXG4gICAgcHJpdmF0ZSBncmlkc3Rlckl0ZW1SZXNpemVFbWl0dGVyOiBFdmVudEVtaXR0ZXI8R3JpZHN0ZXJJdGVtPjtcclxuXHJcbiAgICBjb25zdHJ1Y3Rvcihwcml2YXRlIGJyb2FkY2FzdGVyOiBLZEJyb2FkY2FzdGVyKSB7IH1cclxuXHJcbiAgICBwdWJsaWMgc2V0RW1pdHRlcihncmlkc3Rlckl0ZW1SZXNpemVFbWl0dGVyOiBFdmVudEVtaXR0ZXI8R3JpZHN0ZXJJdGVtPiwgZ2V0R3JpZHN0ZXJJdGVtRW1pdHRlcjogRXZlbnRFbWl0dGVyPEdyaWRzdGVySXRlbT4pIHtcclxuICAgICAgICB0aGlzLmdyaWRzdGVySXRlbVJlc2l6ZUVtaXR0ZXIgPSBncmlkc3Rlckl0ZW1SZXNpemVFbWl0dGVyO1xyXG4gICAgICAgIHRoaXMuZ2V0R3JpZHN0ZXJJdGVtID0gZ2V0R3JpZHN0ZXJJdGVtRW1pdHRlcjtcclxuICAgIH1cclxuXHJcbiAgICAvKipcclxuICAgICAqIGdlbmVyYXRlIGRlZmF1bHQgZ3JpZHN0ZXIgY29uZmlnXHJcbiAgICAgKiAgZGVmYXVsdCBncmlkc3RlciBjb25maWdcclxuICAgICAqL1xyXG4gICAgcHJpdmF0ZSBnZXREZWZhdWx0R3JpZHN0ZXJDb25maWcoKTogR3JpZHN0ZXJDb25maWcge1xyXG4gICAgICAgIHJldHVybiB7XHJcbiAgICAgICAgICAgIC8vIGdyaWRzdGVyIHBsdWdpbiBwcm9wZXJ0eVxyXG4gICAgICAgICAgICBncmlkVHlwZTogJ3Njcm9sbFZlcnRpY2FsJyxcclxuICAgICAgICAgICAgbW9iaWxlQnJlYWtwb2ludDogMCxcclxuICAgICAgICAgICAgZGVmYXVsdEl0ZW1Db2xzOiAyMCxcclxuICAgICAgICAgICAgZGVmYXVsdEl0ZW1Sb3dzOiAxMCxcclxuICAgICAgICAgICAgZHJhZ2dhYmxlOiB7XHJcbiAgICAgICAgICAgICAgICBlbmFibGVkOiB0cnVlLFxyXG4gICAgICAgICAgICAgICAgaWdub3JlQ29udGVudENsYXNzOiAnbm8tZHJhZycsXHJcbiAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgIHJlc2l6YWJsZToge1xyXG4gICAgICAgICAgICAgICAgZW5hYmxlZDogdHJ1ZSxcclxuICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgcHVzaEl0ZW1zOiBmYWxzZSxcclxuICAgICAgICAgICAgZGlzYWJsZVB1c2hPbkRyYWc6IHRydWUsXHJcbiAgICAgICAgICAgIGRpc2FibGVQdXNoT25SZXNpemU6IHRydWUsXHJcbiAgICAgICAgICAgIHB1c2hSZXNpemVJdGVtczogZmFsc2UsXHJcbiAgICAgICAgICAgIHB1c2hEaXJlY3Rpb25zOiB7IG5vcnRoOiBmYWxzZSwgZWFzdDogZmFsc2UsIHNvdXRoOiBmYWxzZSwgd2VzdDogZmFsc2UgfSxcclxuICAgICAgICAgICAgZGlzcGxheUdyaWQ6ICdvbkRyYWcmUmVzaXplJyxcclxuICAgICAgICAgICAgc2Nyb2xsVG9OZXdJdGVtczogdHJ1ZSxcclxuICAgICAgICAgICAgZGlzYWJsZUF1dG9Qb3NpdGlvbk9uQ29uZmxpY3Q6IHRydWUsXHJcbiAgICAgICAgICAgIHNldEdyaWRTaXplOiBmYWxzZSxcclxuICAgICAgICAgICAgbWluQ29sczogMTAwLFxyXG4gICAgICAgICAgICBtYXhDb2xzOiAxMDAsXHJcbiAgICAgICAgICAgIG1heFJvd3M6IDEwMCxcclxuXHJcbiAgICAgICAgICAgIC8vIGFkZC1vbiBwcm9wZXJ0eVxyXG4gICAgICAgICAgICBib3JkZXI6IGZhbHNlLFxyXG4gICAgICAgICAgICBlbmFibGVFZGl0TW9kZTogZmFsc2UsXHJcbiAgICAgICAgICAgIGhpZGVEcmFnQnV0dG9uczogZmFsc2UsXHJcbiAgICAgICAgICAgIGhpZGVDdXN0b21CdXR0b25zOiBmYWxzZSxcclxuICAgICAgICAgICAgc2V0Rml4Q2VudGVyOiBmYWxzZSxcclxuICAgICAgICAgICAgZW5hYmxlRG93bmdyYWRlOiBmYWxzZSxcclxuICAgICAgICAgICAgYnV0dG9uczogW11cclxuICAgICAgICB9O1xyXG4gICAgfVxyXG5cclxuICAgIC8qKlxyXG4gICAgICogcmV0dXJuIGNvbWJpbmF0aW9uIG9mIGRlZmF1bHQgZ3JpZHN0ZXIgY29uZmlnIGFuZCB1c2VyIGRlZmluZSBjb25maWdcclxuICAgICAqICAgIF9jb25maWcgIGNvbmZpZyBmcm9tIHVzZXIvYXBwbGljYXRpb25cclxuICAgICAqICAgICAgICAgICAgIFtkZXNjcmlwdGlvbl1cclxuICAgICAqL1xyXG4gICAgcHVibGljIGdldENvbmZpZyhfY29uZmlnOiBJR3JpZHN0ZXJDb25maWcpOiBJR3JpZHN0ZXJDb25maWcge1xyXG4gICAgICAgIGlmICh0eXBlb2YgX2NvbmZpZyA9PT0gJ3VuZGVmaW5lZCcpIF9jb25maWcgPSB7fTtcclxuXHJcbiAgICAgICAgbGV0IGdyaWRzdGVyRGVmYXVsdENvbmZpZzogR3JpZHN0ZXJDb25maWcgPSB0aGlzLmdldERlZmF1bHRHcmlkc3RlckNvbmZpZygpO1xyXG5cclxuICAgICAgICBncmlkc3RlckRlZmF1bHRDb25maWcuaXRlbUluaXRDYWxsYmFjayA9IChpdGVtOiBHcmlkc3Rlckl0ZW0sIGl0ZW1Db21wb25lbnQ6IEdyaWRzdGVySXRlbUNvbXBvbmVudEludGVyZmFjZSkgPT4gdGhpcy5fb25JdGVtSW5pdChpdGVtLCBpdGVtQ29tcG9uZW50KTtcclxuXHJcbiAgICAgICAgZ3JpZHN0ZXJEZWZhdWx0Q29uZmlnLml0ZW1SZXNpemVDYWxsYmFjayA9IChpdGVtOiBHcmlkc3Rlckl0ZW0sIGl0ZW1Db21wb25lbnQ6IEdyaWRzdGVySXRlbUNvbXBvbmVudEludGVyZmFjZSkgPT4gdGhpcy5fb25JdGVtUmVzaXplKGl0ZW0sIGl0ZW1Db21wb25lbnQpO1xyXG5cclxuICAgICAgICByZXR1cm4gKDxJR3JpZHN0ZXJDb25maWc+T2JqZWN0KS5hc3NpZ24oe30sIGdyaWRzdGVyRGVmYXVsdENvbmZpZywgX2NvbmZpZyk7XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfb25JdGVtSW5pdChfaXRlbTogR3JpZHN0ZXJJdGVtLCBfaXRlbUNvbXBvbmVudDogR3JpZHN0ZXJJdGVtQ29tcG9uZW50SW50ZXJmYWNlKTogdm9pZCB7XHJcbiAgICAgICAgLy8gY29uc29sZS5sb2coJ19vbkl0ZW1Jbml0JywgSlNPTi5zdHJpbmdpZnkoX2l0ZW0pKTtcclxuICAgICAgICBfaXRlbUNvbXBvbmVudC5lbC5jbGFzc05hbWUgKz0gJyBrZHgtZGlzcGxheS1ib3gnO1xyXG4gICAgICAgIF9pdGVtLmlzRG9uZUluaXQgPSB0cnVlO1xyXG4gICAgICAgIHRoaXMuZ2V0R3JpZHN0ZXJJdGVtLmVtaXQoX2l0ZW0pO1xyXG4gICAgICAgIHRoaXMuX2dyaWRzdGVySXRlbUluaXQoX2l0ZW0pO1xyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX29uSXRlbVJlc2l6ZShfaXRlbTogR3JpZHN0ZXJJdGVtLCBfaXRlbUNvbXBvbmVudDogR3JpZHN0ZXJJdGVtQ29tcG9uZW50SW50ZXJmYWNlKTogdm9pZCB7XHJcbiAgICAgICAgaWYgKCFfaXRlbS5pc0RvbmVJbml0KSB7XHJcbiAgICAgICAgICAgIHRoaXMuX2dyaWRzdGVySXRlbVJlc2l6ZShfaXRlbSk7XHJcbiAgICAgICAgICAgIHRoaXMuZ3JpZHN0ZXJJdGVtUmVzaXplRW1pdHRlci5lbWl0KF9pdGVtKTtcclxuICAgICAgICB9XHJcbiAgICAgICAgZWxzZSB7XHJcbiAgICAgICAgICAgIF9pdGVtLmlzRG9uZUluaXQgPSBmYWxzZTtcclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgcHVibGljIG9uR3JpZHN0ZXJJdGVtSW5pdCgpOiBPYnNlcnZhYmxlPGFueT4ge1xyXG4gICAgICAgIHJldHVybiB0aGlzLmJyb2FkY2FzdGVyLm9uPGFueT4oJ0tkR3JpZHN0ZXJFdmVudF9vbkl0ZW1Jbml0Jyk7XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfZ3JpZHN0ZXJJdGVtSW5pdChfaXRlbTogYW55KTogdm9pZCB7XHJcbiAgICAgICAgdGhpcy5icm9hZGNhc3Rlci5icm9hZGNhc3QoJ0tkR3JpZHN0ZXJFdmVudF9vbkl0ZW1Jbml0JywgX2l0ZW0pO1xyXG4gICAgfVxyXG5cclxuICAgIHB1YmxpYyBvbkdyaWRzdGVySXRlbVJlc2l6ZSgpOiBPYnNlcnZhYmxlPGFueT4ge1xyXG4gICAgICAgIHJldHVybiB0aGlzLmJyb2FkY2FzdGVyLm9uPGFueT4oJ0tkR3JpZHN0ZXJFdmVudF9vbkl0ZW1SZXNpemUnKTtcclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF9ncmlkc3Rlckl0ZW1SZXNpemUoX2l0ZW06IGFueSk6IHZvaWQge1xyXG4gICAgICAgIHRoaXMuYnJvYWRjYXN0ZXIuYnJvYWRjYXN0KCdLZEdyaWRzdGVyRXZlbnRfb25JdGVtUmVzaXplJywgX2l0ZW0pO1xyXG4gICAgfVxyXG5cclxuICAgIHB1YmxpYyBvbkdyaWRzdGVyUmVtb3ZlZCgpOiBPYnNlcnZhYmxlPGFueT4ge1xyXG4gICAgICAgIHJldHVybiB0aGlzLmJyb2FkY2FzdGVyLm9uPGFueT4oJ0tkR3JpZHN0ZXJFdmVudF9vblJlbW92ZWQnKTtcclxuICAgIH1cclxuXHJcbiAgICBwdWJsaWMgZ3JpZHN0ZXJSZW1vdmVkKCk6IHZvaWQge1xyXG4gICAgICAgIHRoaXMuYnJvYWRjYXN0ZXIuYnJvYWRjYXN0KCdLZEdyaWRzdGVyRXZlbnRfb25SZW1vdmVkJyk7XHJcbiAgICB9XHJcbn1cclxuIl19