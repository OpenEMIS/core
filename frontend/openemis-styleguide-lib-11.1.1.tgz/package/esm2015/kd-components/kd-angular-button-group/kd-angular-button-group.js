import { Component, Input, Output, EventEmitter, ViewEncapsulation } from '@angular/core';
import { KdDomElemSvc } from '../kd-common/index';
export class KdButtonGroup {
    constructor(_domElmSvc) {
        this._domElmSvc = _domElmSvc;
        this.buttons = [];
        this.disableToolTip = true;
        this.isIconOnly = false;
        this.name = 'kdbuttongroup';
        this.updatedValue = new EventEmitter();
    }
    ngOnChanges(_simpleChanges) {
        if (_simpleChanges.hasOwnProperty('data')) {
            this.buttons = this._buttonSizeValidation(this.data);
        }
        if (_simpleChanges.hasOwnProperty('type') && typeof _simpleChanges.type.currentValue !== 'undefined') {
            this.config['type'] = this.type;
        }
        if (_simpleChanges.hasOwnProperty('value') && typeof _simpleChanges.value.currentValue !== 'undefined') {
            this._validateValueType();
        }
        if (_simpleChanges.hasOwnProperty('config')) {
            if (this.config.hasOwnProperty('iconOnly') && typeof this.config.iconOnly === 'boolean') {
                this.isIconOnly = this.config.iconOnly;
                this.disableToolTip = !this.isIconOnly;
            }
        }
    }
    emitValue() {
        this.updatedValue.emit(this.modalValue);
    }
    isButtonDisabled(_btnCond) {
        let btnDisabled;
        if (typeof this.disabled !== 'undefined' && this.disabled)
            btnDisabled = true;
        else
            btnDisabled = _btnCond ? _btnCond : false;
        return btnDisabled;
    }
    _validateValueType() {
        if (this.config.type === 'radio' &&
            this.buttons.length > 0 &&
            typeof this.buttons[0]['value'] !== typeof this.value) {
            console.warn('Value data type mismatch! ' + typeof this.buttons[0]['value'] + ' !== ' + typeof this.value);
        }
        this.modalValue = this.value;
    }
    _buttonSizeValidation(_buttons) {
        let btnList = [];
        let maxSize = 6;
        if (typeof _buttons === 'undefined')
            return [];
        this._validateValueType();
        for (let i = 0; i < _buttons.length; i++) {
            if (i < maxSize) {
                let button = _buttons[i];
                if (button.icon)
                    button.icon = this._domElmSvc.setIconClass(button.icon);
                btnList.push(button);
            }
            else {
                break;
            }
        }
        return btnList;
    }
}
KdButtonGroup.decorators = [
    { type: Component, args: [{
                selector: 'kd-button-group',
                template: `
        <ng-container [ngSwitch]="config.type">
            <ng-container  *ngSwitchCase="'radio'" >
                <div ngbRadioGroup class="btn-group btn-group-toggle" name="{{name}}" [(ngModel)]="modalValue" (ngModelChange)="emitValue()">
                    <label ngbButtonLabel class="btn-outline" [class.btn-icon]="isIconOnly" *ngFor="let button of buttons" [kd-tooltip-dir]="button.key" tooltipPosition="bottom" tooltipStyleClass="kdx-tooltip-default" [tooltipDisabled]="disableToolTip">
                        <i *ngIf="button.icon" class="{{button.icon}}"></i>
                        <span *ngIf="button.key && !isIconOnly" >{{button.key}}</span>
                        <input ngbButton type="radio" [value]="button.value" [disabled]="isButtonDisabled(button.disabled)" >
                    </label>
                </div>
            </ng-container>

            <div *ngSwitchDefault class="btn-group btn-group-toggle btn-group-checkbox">
                <label ngbButtonLabel class="btn-outline" [class.btn-icon]="isIconOnly" *ngFor="let button of buttons" [kd-tooltip-dir]="button.key" tooltipPosition="bottom" tooltipStyleClass="kdx-tooltip-default" [tooltipDisabled]="disableToolTip">
                    <i *ngIf="button.icon" class="{{button.icon}}"></i>
                    <span *ngIf="button.key && !isIconOnly" >{{button.key}}</span>
                    <input ngbButton type="checkbox" [(ngModel)]="modalValue[button.value]" (ngModelChange)="emitValue()" [disabled]="isButtonDisabled(button.disabled)">
                </label>
            </div>
        </ng-container>
    `,
                encapsulation: ViewEncapsulation.None,
                host: { 'class': 'kdx-button-group' }
            },] }
];
KdButtonGroup.ctorParameters = () => [
    { type: KdDomElemSvc }
];
KdButtonGroup.propDecorators = {
    data: [{ type: Input }],
    name: [{ type: Input }],
    value: [{ type: Input }],
    disabled: [{ type: Input }],
    config: [{ type: Input }],
    type: [{ type: Input }],
    updatedValue: [{ type: Output }]
};
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoia2QtYW5ndWxhci1idXR0b24tZ3JvdXAuanMiLCJzb3VyY2VSb290IjoiRDovb3BlbkVNSVMvc3R5bGVndWlkZS9pb3N0Zy1vcGVuZW1pcy1zdHlsZWd1aWRlL3Byb2plY3RzL29wZW5lbWlzLXN0eWxlZ3VpZGUtbGliL3NyYy8iLCJzb3VyY2VzIjpbImtkLWNvbXBvbmVudHMva2QtYW5ndWxhci1idXR0b24tZ3JvdXAva2QtYW5ndWxhci1idXR0b24tZ3JvdXAudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsT0FBTyxFQUNILFNBQVMsRUFDVCxLQUFLLEVBQ0wsTUFBTSxFQUNOLFlBQVksRUFDWixpQkFBaUIsRUFHcEIsTUFBTSxlQUFlLENBQUM7QUFDdkIsT0FBTyxFQUFFLFlBQVksRUFBRSxNQUFNLG9CQUFvQixDQUFDO0FBOEJsRCxNQUFNLE9BQU8sYUFBYTtJQWdCdEIsWUFBb0IsVUFBd0I7UUFBeEIsZUFBVSxHQUFWLFVBQVUsQ0FBYztRQWZyQyxZQUFPLEdBQWMsRUFBRSxDQUFDO1FBQ3hCLG1CQUFjLEdBQVksSUFBSSxDQUFDO1FBRS9CLGVBQVUsR0FBWSxLQUFLLENBQUM7UUFLMUIsU0FBSSxHQUFZLGVBQWUsQ0FBQztRQUsvQixpQkFBWSxHQUFzQixJQUFJLFlBQVksRUFBRSxDQUFDO0lBRWYsQ0FBQztJQUVqRCxXQUFXLENBQUMsY0FBNkI7UUFFckMsSUFBSSxjQUFjLENBQUMsY0FBYyxDQUFDLE1BQU0sQ0FBQyxFQUFFO1lBQ3ZDLElBQUksQ0FBQyxPQUFPLEdBQUcsSUFBSSxDQUFDLHFCQUFxQixDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQztTQUN4RDtRQUVELElBQUksY0FBYyxDQUFDLGNBQWMsQ0FBQyxNQUFNLENBQUMsSUFBSSxPQUFPLGNBQWMsQ0FBQyxJQUFJLENBQUMsWUFBWSxLQUFLLFdBQVcsRUFBRTtZQUNsRyxJQUFJLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxHQUFHLElBQUksQ0FBQyxJQUFJLENBQUM7U0FDbkM7UUFFRCxJQUFJLGNBQWMsQ0FBQyxjQUFjLENBQUMsT0FBTyxDQUFDLElBQUksT0FBTyxjQUFjLENBQUMsS0FBSyxDQUFDLFlBQVksS0FBSyxXQUFXLEVBQUU7WUFDcEcsSUFBSSxDQUFDLGtCQUFrQixFQUFFLENBQUM7U0FDN0I7UUFFRCxJQUFJLGNBQWMsQ0FBQyxjQUFjLENBQUMsUUFBUSxDQUFDLEVBQUU7WUFDekMsSUFBSSxJQUFJLENBQUMsTUFBTSxDQUFDLGNBQWMsQ0FBQyxVQUFVLENBQUMsSUFBSSxPQUFPLElBQUksQ0FBQyxNQUFNLENBQUMsUUFBUSxLQUFLLFNBQVMsRUFBRTtnQkFDckYsSUFBSSxDQUFDLFVBQVUsR0FBRyxJQUFJLENBQUMsTUFBTSxDQUFDLFFBQVEsQ0FBQztnQkFDdkMsSUFBSSxDQUFDLGNBQWMsR0FBRyxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUM7YUFDMUM7U0FDSjtJQUNMLENBQUM7SUFFTSxTQUFTO1FBQ1osSUFBSSxDQUFDLFlBQVksQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxDQUFDO0lBQzVDLENBQUM7SUFFTSxnQkFBZ0IsQ0FBQyxRQUF3QjtRQUM1QyxJQUFJLFdBQW9CLENBQUM7UUFFekIsSUFBSSxPQUFPLElBQUksQ0FBQyxRQUFRLEtBQUssV0FBVyxJQUFJLElBQUksQ0FBQyxRQUFRO1lBQUUsV0FBVyxHQUFHLElBQUksQ0FBQzs7WUFDekUsV0FBVyxHQUFHLFFBQVEsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUM7UUFFL0MsT0FBTyxXQUFXLENBQUM7SUFDdkIsQ0FBQztJQUVPLGtCQUFrQjtRQUN0QixJQUFJLElBQUksQ0FBQyxNQUFNLENBQUMsSUFBSSxLQUFLLE9BQU87WUFDNUIsSUFBSSxDQUFDLE9BQU8sQ0FBQyxNQUFNLEdBQUcsQ0FBQztZQUN2QixPQUFPLElBQUksQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLEtBQUssT0FBTyxJQUFJLENBQUMsS0FBSyxFQUN2RDtZQUNFLE9BQU8sQ0FBQyxJQUFJLENBQUMsNEJBQTRCLEdBQUcsT0FBTyxJQUFJLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxHQUFHLE9BQU8sR0FBRyxPQUFPLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQztTQUM5RztRQUVELElBQUksQ0FBQyxVQUFVLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQztJQUNqQyxDQUFDO0lBRU8scUJBQXFCLENBQUMsUUFBbUI7UUFDN0MsSUFBSSxPQUFPLEdBQWMsRUFBRSxDQUFDO1FBQzVCLElBQUksT0FBTyxHQUFXLENBQUMsQ0FBQztRQUV4QixJQUFJLE9BQU8sUUFBUSxLQUFLLFdBQVc7WUFBRSxPQUFPLEVBQUUsQ0FBQztRQUMvQyxJQUFJLENBQUMsa0JBQWtCLEVBQUUsQ0FBQztRQUUxQixLQUFLLElBQUksQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLEdBQUcsUUFBUSxDQUFDLE1BQU0sRUFBRSxDQUFDLEVBQUUsRUFBRTtZQUN0QyxJQUFJLENBQUMsR0FBRyxPQUFPLEVBQUU7Z0JBQ2IsSUFBSSxNQUFNLEdBQVEsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDO2dCQUM5QixJQUFJLE1BQU0sQ0FBQyxJQUFJO29CQUFFLE1BQU0sQ0FBQyxJQUFJLEdBQUcsSUFBSSxDQUFDLFVBQVUsQ0FBQyxZQUFZLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxDQUFDO2dCQUN6RSxPQUFPLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDO2FBQ3hCO2lCQUNJO2dCQUNELE1BQU07YUFDVDtTQUNKO1FBRUQsT0FBTyxPQUFPLENBQUM7SUFDbkIsQ0FBQzs7O1lBOUdKLFNBQVMsU0FBQztnQkFDUCxRQUFRLEVBQUUsaUJBQWlCO2dCQUMzQixRQUFRLEVBQUU7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0tBb0JUO2dCQUNELGFBQWEsRUFBRSxpQkFBaUIsQ0FBQyxJQUFJO2dCQUNyQyxJQUFJLEVBQUUsRUFBRSxPQUFPLEVBQUUsa0JBQWtCLEVBQUU7YUFDeEM7OztZQTVCUSxZQUFZOzs7bUJBc0NoQixLQUFLO21CQUNMLEtBQUs7b0JBQ0wsS0FBSzt1QkFDTCxLQUFLO3FCQUNMLEtBQUs7bUJBQ0wsS0FBSzsyQkFDTCxNQUFNIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHtcclxuICAgIENvbXBvbmVudCxcclxuICAgIElucHV0LFxyXG4gICAgT3V0cHV0LFxyXG4gICAgRXZlbnRFbWl0dGVyLFxyXG4gICAgVmlld0VuY2Fwc3VsYXRpb24sXHJcbiAgICBPbkNoYW5nZXMsXHJcbiAgICBTaW1wbGVDaGFuZ2VzXHJcbn0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XHJcbmltcG9ydCB7IEtkRG9tRWxlbVN2YyB9IGZyb20gJy4uL2tkLWNvbW1vbi9pbmRleCc7XHJcbmltcG9ydCB7IElCdG5Hcm91cENvbmZpZywgSUJ0bkdyb3VwRGF0YSB9IGZyb20gJy4va2QtYW5ndWxhci1idXR0b24tZ3JvdXAtaW50ZXJmYWNlJztcclxuXHJcbkBDb21wb25lbnQoe1xyXG4gICAgc2VsZWN0b3I6ICdrZC1idXR0b24tZ3JvdXAnLFxyXG4gICAgdGVtcGxhdGU6IGBcclxuICAgICAgICA8bmctY29udGFpbmVyIFtuZ1N3aXRjaF09XCJjb25maWcudHlwZVwiPlxyXG4gICAgICAgICAgICA8bmctY29udGFpbmVyICAqbmdTd2l0Y2hDYXNlPVwiJ3JhZGlvJ1wiID5cclxuICAgICAgICAgICAgICAgIDxkaXYgbmdiUmFkaW9Hcm91cCBjbGFzcz1cImJ0bi1ncm91cCBidG4tZ3JvdXAtdG9nZ2xlXCIgbmFtZT1cInt7bmFtZX19XCIgWyhuZ01vZGVsKV09XCJtb2RhbFZhbHVlXCIgKG5nTW9kZWxDaGFuZ2UpPVwiZW1pdFZhbHVlKClcIj5cclxuICAgICAgICAgICAgICAgICAgICA8bGFiZWwgbmdiQnV0dG9uTGFiZWwgY2xhc3M9XCJidG4tb3V0bGluZVwiIFtjbGFzcy5idG4taWNvbl09XCJpc0ljb25Pbmx5XCIgKm5nRm9yPVwibGV0IGJ1dHRvbiBvZiBidXR0b25zXCIgW2tkLXRvb2x0aXAtZGlyXT1cImJ1dHRvbi5rZXlcIiB0b29sdGlwUG9zaXRpb249XCJib3R0b21cIiB0b29sdGlwU3R5bGVDbGFzcz1cImtkeC10b29sdGlwLWRlZmF1bHRcIiBbdG9vbHRpcERpc2FibGVkXT1cImRpc2FibGVUb29sVGlwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxpICpuZ0lmPVwiYnV0dG9uLmljb25cIiBjbGFzcz1cInt7YnV0dG9uLmljb259fVwiPjwvaT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gKm5nSWY9XCJidXR0b24ua2V5ICYmICFpc0ljb25Pbmx5XCIgPnt7YnV0dG9uLmtleX19PC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8aW5wdXQgbmdiQnV0dG9uIHR5cGU9XCJyYWRpb1wiIFt2YWx1ZV09XCJidXR0b24udmFsdWVcIiBbZGlzYWJsZWRdPVwiaXNCdXR0b25EaXNhYmxlZChidXR0b24uZGlzYWJsZWQpXCIgPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPC9uZy1jb250YWluZXI+XHJcblxyXG4gICAgICAgICAgICA8ZGl2ICpuZ1N3aXRjaERlZmF1bHQgY2xhc3M9XCJidG4tZ3JvdXAgYnRuLWdyb3VwLXRvZ2dsZSBidG4tZ3JvdXAtY2hlY2tib3hcIj5cclxuICAgICAgICAgICAgICAgIDxsYWJlbCBuZ2JCdXR0b25MYWJlbCBjbGFzcz1cImJ0bi1vdXRsaW5lXCIgW2NsYXNzLmJ0bi1pY29uXT1cImlzSWNvbk9ubHlcIiAqbmdGb3I9XCJsZXQgYnV0dG9uIG9mIGJ1dHRvbnNcIiBba2QtdG9vbHRpcC1kaXJdPVwiYnV0dG9uLmtleVwiIHRvb2x0aXBQb3NpdGlvbj1cImJvdHRvbVwiIHRvb2x0aXBTdHlsZUNsYXNzPVwia2R4LXRvb2x0aXAtZGVmYXVsdFwiIFt0b29sdGlwRGlzYWJsZWRdPVwiZGlzYWJsZVRvb2xUaXBcIj5cclxuICAgICAgICAgICAgICAgICAgICA8aSAqbmdJZj1cImJ1dHRvbi5pY29uXCIgY2xhc3M9XCJ7e2J1dHRvbi5pY29ufX1cIj48L2k+XHJcbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gKm5nSWY9XCJidXR0b24ua2V5ICYmICFpc0ljb25Pbmx5XCIgPnt7YnV0dG9uLmtleX19PC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgIDxpbnB1dCBuZ2JCdXR0b24gdHlwZT1cImNoZWNrYm94XCIgWyhuZ01vZGVsKV09XCJtb2RhbFZhbHVlW2J1dHRvbi52YWx1ZV1cIiAobmdNb2RlbENoYW5nZSk9XCJlbWl0VmFsdWUoKVwiIFtkaXNhYmxlZF09XCJpc0J1dHRvbkRpc2FibGVkKGJ1dHRvbi5kaXNhYmxlZClcIj5cclxuICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDwvbmctY29udGFpbmVyPlxyXG4gICAgYCxcclxuICAgIGVuY2Fwc3VsYXRpb246IFZpZXdFbmNhcHN1bGF0aW9uLk5vbmUsXHJcbiAgICBob3N0OiB7ICdjbGFzcyc6ICdrZHgtYnV0dG9uLWdyb3VwJyB9XHJcbn0pXHJcblxyXG5leHBvcnQgY2xhc3MgS2RCdXR0b25Hcm91cCBpbXBsZW1lbnRzIE9uQ2hhbmdlcyB7XHJcbiAgICBwdWJsaWMgYnV0dG9uczogQXJyYXk8e30+ID0gW107XHJcbiAgICBwdWJsaWMgZGlzYWJsZVRvb2xUaXA6IGJvb2xlYW4gPSB0cnVlO1xyXG4gICAgcHVibGljIGlzU3RyaW5nTW9kZTogYm9vbGVhbjtcclxuICAgIHB1YmxpYyBpc0ljb25Pbmx5OiBib29sZWFuID0gZmFsc2U7XHJcblxyXG4gICAgcHVibGljIG1vZGFsVmFsdWU6IGFueTtcclxuXHJcbiAgICBASW5wdXQoKSBkYXRhOiBBcnJheTxJQnRuR3JvdXBEYXRhPjtcclxuICAgIEBJbnB1dCgpIG5hbWU/OiBzdHJpbmcgPSAna2RidXR0b25ncm91cCc7XHJcbiAgICBASW5wdXQoKSB2YWx1ZTogYW55O1xyXG4gICAgQElucHV0KCkgZGlzYWJsZWQ/OiBib29sZWFuO1xyXG4gICAgQElucHV0KCkgY29uZmlnPzogSUJ0bkdyb3VwQ29uZmlnO1xyXG4gICAgQElucHV0KCkgdHlwZT86ICdjaGVja2JveCd8J3JhZGlvJztcclxuICAgIEBPdXRwdXQoKSB1cGRhdGVkVmFsdWU6IEV2ZW50RW1pdHRlcjxhbnk+ID0gbmV3IEV2ZW50RW1pdHRlcigpO1xyXG5cclxuICAgIGNvbnN0cnVjdG9yKHByaXZhdGUgX2RvbUVsbVN2YzogS2REb21FbGVtU3ZjKSB7IH1cclxuXHJcbiAgICBuZ09uQ2hhbmdlcyhfc2ltcGxlQ2hhbmdlczogU2ltcGxlQ2hhbmdlcyk6IHZvaWQge1xyXG5cclxuICAgICAgICBpZiAoX3NpbXBsZUNoYW5nZXMuaGFzT3duUHJvcGVydHkoJ2RhdGEnKSkge1xyXG4gICAgICAgICAgICB0aGlzLmJ1dHRvbnMgPSB0aGlzLl9idXR0b25TaXplVmFsaWRhdGlvbih0aGlzLmRhdGEpO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgaWYgKF9zaW1wbGVDaGFuZ2VzLmhhc093blByb3BlcnR5KCd0eXBlJykgJiYgdHlwZW9mIF9zaW1wbGVDaGFuZ2VzLnR5cGUuY3VycmVudFZhbHVlICE9PSAndW5kZWZpbmVkJykge1xyXG4gICAgICAgICAgICB0aGlzLmNvbmZpZ1sndHlwZSddID0gdGhpcy50eXBlO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgaWYgKF9zaW1wbGVDaGFuZ2VzLmhhc093blByb3BlcnR5KCd2YWx1ZScpICYmIHR5cGVvZiBfc2ltcGxlQ2hhbmdlcy52YWx1ZS5jdXJyZW50VmFsdWUgIT09ICd1bmRlZmluZWQnKSB7XHJcbiAgICAgICAgICAgIHRoaXMuX3ZhbGlkYXRlVmFsdWVUeXBlKCk7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICBpZiAoX3NpbXBsZUNoYW5nZXMuaGFzT3duUHJvcGVydHkoJ2NvbmZpZycpKSB7XHJcbiAgICAgICAgICAgIGlmICh0aGlzLmNvbmZpZy5oYXNPd25Qcm9wZXJ0eSgnaWNvbk9ubHknKSAmJiB0eXBlb2YgdGhpcy5jb25maWcuaWNvbk9ubHkgPT09ICdib29sZWFuJykge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5pc0ljb25Pbmx5ID0gdGhpcy5jb25maWcuaWNvbk9ubHk7XHJcbiAgICAgICAgICAgICAgICB0aGlzLmRpc2FibGVUb29sVGlwID0gIXRoaXMuaXNJY29uT25seTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICBwdWJsaWMgZW1pdFZhbHVlKCk6IHZvaWQge1xyXG4gICAgICAgIHRoaXMudXBkYXRlZFZhbHVlLmVtaXQodGhpcy5tb2RhbFZhbHVlKTtcclxuICAgIH1cclxuXHJcbiAgICBwdWJsaWMgaXNCdXR0b25EaXNhYmxlZChfYnRuQ29uZDogYm9vbGVhbiB8IG51bGwpOiBib29sZWFuIHtcclxuICAgICAgICBsZXQgYnRuRGlzYWJsZWQ6IGJvb2xlYW47XHJcblxyXG4gICAgICAgIGlmICh0eXBlb2YgdGhpcy5kaXNhYmxlZCAhPT0gJ3VuZGVmaW5lZCcgJiYgdGhpcy5kaXNhYmxlZCkgYnRuRGlzYWJsZWQgPSB0cnVlO1xyXG4gICAgICAgIGVsc2UgYnRuRGlzYWJsZWQgPSBfYnRuQ29uZCA/IF9idG5Db25kIDogZmFsc2U7XHJcblxyXG4gICAgICAgIHJldHVybiBidG5EaXNhYmxlZDtcclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF92YWxpZGF0ZVZhbHVlVHlwZSgpOiB2b2lkIHtcclxuICAgICAgICBpZiAodGhpcy5jb25maWcudHlwZSA9PT0gJ3JhZGlvJyAmJlxyXG4gICAgICAgICAgICB0aGlzLmJ1dHRvbnMubGVuZ3RoID4gMCAmJlxyXG4gICAgICAgICAgICB0eXBlb2YgdGhpcy5idXR0b25zWzBdWyd2YWx1ZSddICE9PSB0eXBlb2YgdGhpcy52YWx1ZVxyXG4gICAgICAgICkge1xyXG4gICAgICAgICAgICBjb25zb2xlLndhcm4oJ1ZhbHVlIGRhdGEgdHlwZSBtaXNtYXRjaCEgJyArIHR5cGVvZiB0aGlzLmJ1dHRvbnNbMF1bJ3ZhbHVlJ10gKyAnICE9PSAnICsgdHlwZW9mIHRoaXMudmFsdWUpO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgdGhpcy5tb2RhbFZhbHVlID0gdGhpcy52YWx1ZTtcclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF9idXR0b25TaXplVmFsaWRhdGlvbihfYnV0dG9uczogQXJyYXk8e30+KTogQXJyYXk8e30+IHtcclxuICAgICAgICBsZXQgYnRuTGlzdDogQXJyYXk8e30+ID0gW107XHJcbiAgICAgICAgbGV0IG1heFNpemU6IG51bWJlciA9IDY7XHJcblxyXG4gICAgICAgIGlmICh0eXBlb2YgX2J1dHRvbnMgPT09ICd1bmRlZmluZWQnKSByZXR1cm4gW107XHJcbiAgICAgICAgdGhpcy5fdmFsaWRhdGVWYWx1ZVR5cGUoKTtcclxuXHJcbiAgICAgICAgZm9yIChsZXQgaSA9IDA7IGkgPCBfYnV0dG9ucy5sZW5ndGg7IGkrKykge1xyXG4gICAgICAgICAgICBpZiAoaSA8IG1heFNpemUpIHtcclxuICAgICAgICAgICAgICAgIGxldCBidXR0b246IGFueSA9IF9idXR0b25zW2ldO1xyXG4gICAgICAgICAgICAgICAgaWYgKGJ1dHRvbi5pY29uKSBidXR0b24uaWNvbiA9IHRoaXMuX2RvbUVsbVN2Yy5zZXRJY29uQ2xhc3MoYnV0dG9uLmljb24pO1xyXG4gICAgICAgICAgICAgICAgYnRuTGlzdC5wdXNoKGJ1dHRvbik7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgZWxzZSB7XHJcbiAgICAgICAgICAgICAgICBicmVhaztcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgcmV0dXJuIGJ0bkxpc3Q7XHJcbiAgICB9XHJcbn1cclxuIl19