import { Injectable } from '@angular/core';
import { KdBroadcaster } from '../kd-common/index';
import * as i0 from "@angular/core";
import * as i1 from "../kd-common/kd-broadcaster-svc";
export class KdIntSearchEvent {
    constructor(_broadcaster) {
        this._broadcaster = _broadcaster;
    }
    onDisableButton() {
        return this._broadcaster.on('KdDisableButton');
    }
}
KdIntSearchEvent.decorators = [
    { type: Injectable }
];
KdIntSearchEvent.ctorParameters = () => [
    { type: KdBroadcaster }
];
export class KdSearchEvent {
    constructor(_broadcaster) {
        this._broadcaster = _broadcaster;
    }
    disableButton(data) {
        this._broadcaster.broadcast('KdDisableButton', data);
    }
}
KdSearchEvent.ɵprov = i0.ɵɵdefineInjectable({ factory: function KdSearchEvent_Factory() { return new KdSearchEvent(i0.ɵɵinject(i1.KdBroadcaster)); }, token: KdSearchEvent, providedIn: "root" });
KdSearchEvent.decorators = [
    { type: Injectable, args: [{
                providedIn: 'root'
            },] }
];
KdSearchEvent.ctorParameters = () => [
    { type: KdBroadcaster }
];
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoia2Qtc2VhcmNoLWV2ZW50LmpzIiwic291cmNlUm9vdCI6IkQ6L29wZW5FTUlTL3N0eWxlZ3VpZGUvaW9zdGctb3BlbmVtaXMtc3R5bGVndWlkZS9wcm9qZWN0cy9vcGVuZW1pcy1zdHlsZWd1aWRlLWxpYi9zcmMvIiwic291cmNlcyI6WyJrZC1jb21wb25lbnRzL2tkLWFuZ3VsYXItc2VhcmNoL2tkLXNlYXJjaC1ldmVudC50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQSxPQUFPLEVBQUUsVUFBVSxFQUFFLE1BQU0sZUFBZSxDQUFDO0FBRTNDLE9BQU8sRUFBRSxhQUFhLEVBQUUsTUFBTSxvQkFBb0IsQ0FBQzs7O0FBR25ELE1BQU0sT0FBTyxnQkFBZ0I7SUFDekIsWUFBb0IsWUFBMkI7UUFBM0IsaUJBQVksR0FBWixZQUFZLENBQWU7SUFBSSxDQUFDO0lBRXBELGVBQWU7UUFDWCxPQUFPLElBQUksQ0FBQyxZQUFZLENBQUMsRUFBRSxDQUFNLGlCQUFpQixDQUFDLENBQUM7SUFDeEQsQ0FBQzs7O1lBTkosVUFBVTs7O1lBRkYsYUFBYTs7QUFjdEIsTUFBTSxPQUFPLGFBQWE7SUFDdEIsWUFBb0IsWUFBMkI7UUFBM0IsaUJBQVksR0FBWixZQUFZLENBQWU7SUFBSSxDQUFDO0lBRXBELGFBQWEsQ0FBQyxJQUFVO1FBQ3BCLElBQUksQ0FBQyxZQUFZLENBQUMsU0FBUyxDQUFDLGlCQUFpQixFQUFFLElBQUksQ0FBQyxDQUFDO0lBQ3pELENBQUM7Ozs7WUFSSixVQUFVLFNBQUM7Z0JBQ1IsVUFBVSxFQUFFLE1BQU07YUFDckI7OztZQWJRLGFBQWEiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBJbmplY3RhYmxlIH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XHJcbmltcG9ydCB7IE9ic2VydmFibGUgfSBmcm9tICdyeGpzJztcclxuaW1wb3J0IHsgS2RCcm9hZGNhc3RlciB9IGZyb20gJy4uL2tkLWNvbW1vbi9pbmRleCc7XHJcblxyXG5ASW5qZWN0YWJsZSgpXHJcbmV4cG9ydCBjbGFzcyBLZEludFNlYXJjaEV2ZW50IHtcclxuICAgIGNvbnN0cnVjdG9yKHByaXZhdGUgX2Jyb2FkY2FzdGVyOiBLZEJyb2FkY2FzdGVyKSB7IH1cclxuXHJcbiAgICBvbkRpc2FibGVCdXR0b24oKTogT2JzZXJ2YWJsZTxhbnk+IHtcclxuICAgICAgICByZXR1cm4gdGhpcy5fYnJvYWRjYXN0ZXIub248YW55PignS2REaXNhYmxlQnV0dG9uJyk7XHJcbiAgICB9XHJcbn1cclxuXHJcbkBJbmplY3RhYmxlKHtcclxuICAgIHByb3ZpZGVkSW46ICdyb290J1xyXG59KVxyXG5leHBvcnQgY2xhc3MgS2RTZWFyY2hFdmVudCB7XHJcbiAgICBjb25zdHJ1Y3Rvcihwcml2YXRlIF9icm9hZGNhc3RlcjogS2RCcm9hZGNhc3RlcikgeyB9XHJcblxyXG4gICAgZGlzYWJsZUJ1dHRvbihkYXRhPzogYW55KTogdm9pZCB7XHJcbiAgICAgICAgdGhpcy5fYnJvYWRjYXN0ZXIuYnJvYWRjYXN0KCdLZERpc2FibGVCdXR0b24nLCBkYXRhKTtcclxuICAgIH1cclxufVxyXG4iXX0=