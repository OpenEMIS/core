import { Component, ViewEncapsulation, Input, Output, EventEmitter } from '@angular/core';
import { KdIntSearchEvent } from './kd-search-event';
export { KdSearchEvent } from './kd-search-event';
export class KdSearch {
    constructor(_searchEvent) {
        this._searchEvent = _searchEvent;
        this._result = {};
        this._searchSettings = {};
        this._disable = false;
        this._defaultSettings = {
            title: 'Directory',
            searchPlaceholder: 'Search',
            description: 'Search Directory',
            filter: false,
            options: []
        };
        this.searchBtnClicked = new EventEmitter();
        this.advSearchBtnClicked = new EventEmitter();
    }
    ngOnInit() {
        this._searchSettings = Object.assign({}, this._defaultSettings, this.config);
        if (this._searchSettings.filter)
            this._result.optionVal = '';
        this._searchSub = this._searchEvent.onDisableButton().subscribe(data => {
            if (typeof data !== 'undefined')
                this._disable = data;
            else
                this._disable = !this._disable;
        });
    }
    ngOnDestroy() {
        this._searchSub.unsubscribe();
    }
    searchClicked(isSearch) {
        if (isSearch)
            this.searchBtnClicked.emit(this._result);
        else
            this.advSearchBtnClicked.emit(this._result);
    }
}
KdSearch.decorators = [
    { type: Component, args: [{
                selector: 'kd-search',
                template: `
        <div class="search-page-wrapper">
            <div class="search-page-box">
                <div class="search-title">
                    <h1>{{_searchSettings.title}}</h1>
                    <p *ngIf="_searchSettings.description">{{_searchSettings.description}}</p>
                </div>
                <div class="search-body">
                    <input type="text" [(ngModel)]="_result.searchText" placeholder="{{_searchSettings.searchPlaceholder}}"/>
                    <div *ngIf="_searchSettings.filter" class="kdx-input-select-wrapper">
                        <select [(ngModel)]="_result.optionVal">
                            <option *ngFor="let item of _searchSettings.options" [value]="item.key">{{item.value}}</option>
                        </select>
                    </div>
                </div>
                <div class="search-buttons">
                    <button class="btn btn-text" [disabled]="_disable" (click)="searchClicked(true)">Search </button>
                    <button class="btn btn-text" [disabled]="_disable" (click)="searchClicked(false)">Advance Search</button>
                </div>
            </div>
        </div>
    `,
                encapsulation: ViewEncapsulation.None,
                providers: [KdIntSearchEvent],
                host: { 'class': 'kdx kdx-search' }
            },] }
];
KdSearch.ctorParameters = () => [
    { type: KdIntSearchEvent }
];
KdSearch.propDecorators = {
    config: [{ type: Input }],
    searchBtnClicked: [{ type: Output }],
    advSearchBtnClicked: [{ type: Output }]
};
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoia2QtYW5ndWxhci1zZWFyY2guanMiLCJzb3VyY2VSb290IjoiRDovb3BlbkVNSVMvc3R5bGVndWlkZS9pb3N0Zy1vcGVuZW1pcy1zdHlsZWd1aWRlL3Byb2plY3RzL29wZW5lbWlzLXN0eWxlZ3VpZGUtbGliL3NyYy8iLCJzb3VyY2VzIjpbImtkLWNvbXBvbmVudHMva2QtYW5ndWxhci1zZWFyY2gva2QtYW5ndWxhci1zZWFyY2gudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsT0FBTyxFQUNILFNBQVMsRUFHVCxpQkFBaUIsRUFDakIsS0FBSyxFQUNMLE1BQU0sRUFDTixZQUFZLEVBQ2YsTUFBTSxlQUFlLENBQUM7QUFFdkIsT0FBTyxFQUFFLGdCQUFnQixFQUFFLE1BQU0sbUJBQW1CLENBQUM7QUFDckQsT0FBTyxFQUFFLGFBQWEsRUFBRSxNQUFNLG1CQUFtQixDQUFDO0FBK0JsRCxNQUFNLE9BQU8sUUFBUTtJQWtCakIsWUFDWSxZQUE4QjtRQUE5QixpQkFBWSxHQUFaLFlBQVksQ0FBa0I7UUFsQm5DLFlBQU8sR0FBUSxFQUFFLENBQUM7UUFDbEIsb0JBQWUsR0FBUSxFQUFFLENBQUM7UUFDMUIsYUFBUSxHQUFZLEtBQUssQ0FBQztRQUV6QixxQkFBZ0IsR0FBUTtZQUM1QixLQUFLLEVBQUUsV0FBVztZQUNsQixpQkFBaUIsRUFBRSxRQUFRO1lBQzNCLFdBQVcsRUFBRSxrQkFBa0I7WUFDL0IsTUFBTSxFQUFFLEtBQUs7WUFDYixPQUFPLEVBQUUsRUFBRTtTQUNkLENBQUM7UUFJUSxxQkFBZ0IsR0FBc0IsSUFBSSxZQUFZLEVBQUUsQ0FBQztRQUN6RCx3QkFBbUIsR0FBc0IsSUFBSSxZQUFZLEVBQUUsQ0FBQztJQUlsRSxDQUFDO0lBRUwsUUFBUTtRQUNKLElBQUksQ0FBQyxlQUFlLEdBQUcsTUFBTSxDQUFDLE1BQU0sQ0FBQyxFQUFFLEVBQUUsSUFBSSxDQUFDLGdCQUFnQixFQUFFLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQztRQUM3RSxJQUFJLElBQUksQ0FBQyxlQUFlLENBQUMsTUFBTTtZQUFFLElBQUksQ0FBQyxPQUFPLENBQUMsU0FBUyxHQUFHLEVBQUUsQ0FBQztRQUU3RCxJQUFJLENBQUMsVUFBVSxHQUFHLElBQUksQ0FBQyxZQUFZLENBQUMsZUFBZSxFQUFFLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQyxFQUFFO1lBQ25FLElBQUksT0FBTyxJQUFJLEtBQUssV0FBVztnQkFBRSxJQUFJLENBQUMsUUFBUSxHQUFHLElBQUksQ0FBQzs7Z0JBQ2pELElBQUksQ0FBQyxRQUFRLEdBQUcsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDO1FBQ3hDLENBQUMsQ0FBQyxDQUFDO0lBQ1AsQ0FBQztJQUVELFdBQVc7UUFDUCxJQUFJLENBQUMsVUFBVSxDQUFDLFdBQVcsRUFBRSxDQUFDO0lBQ2xDLENBQUM7SUFFTSxhQUFhLENBQUMsUUFBaUI7UUFDbEMsSUFBSSxRQUFRO1lBQUUsSUFBSSxDQUFDLGdCQUFnQixDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLENBQUM7O1lBQ2xELElBQUksQ0FBQyxtQkFBbUIsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxDQUFDO0lBQ3JELENBQUM7OztZQXBFSixTQUFTLFNBQUM7Z0JBQ1AsUUFBUSxFQUFFLFdBQVc7Z0JBQ3JCLFFBQVEsRUFBRTs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0tBcUJUO2dCQUNELGFBQWEsRUFBRSxpQkFBaUIsQ0FBQyxJQUFJO2dCQUNyQyxTQUFTLEVBQUUsQ0FBQyxnQkFBZ0IsQ0FBQztnQkFDN0IsSUFBSSxFQUFFLEVBQUUsT0FBTyxFQUFHLGdCQUFnQixFQUFFO2FBQ3ZDOzs7WUE5QlEsZ0JBQWdCOzs7cUJBOENwQixLQUFLOytCQUNMLE1BQU07a0NBQ04sTUFBTSIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7XHJcbiAgICBDb21wb25lbnQsXHJcbiAgICBPbkluaXQsXHJcbiAgICBPbkRlc3Ryb3ksXHJcbiAgICBWaWV3RW5jYXBzdWxhdGlvbixcclxuICAgIElucHV0LFxyXG4gICAgT3V0cHV0LFxyXG4gICAgRXZlbnRFbWl0dGVyXHJcbn0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XHJcbmltcG9ydCB7IFN1YnNjcmlwdGlvbiB9IGZyb20gJ3J4anMnO1xyXG5pbXBvcnQgeyBLZEludFNlYXJjaEV2ZW50IH0gZnJvbSAnLi9rZC1zZWFyY2gtZXZlbnQnO1xyXG5leHBvcnQgeyBLZFNlYXJjaEV2ZW50IH0gZnJvbSAnLi9rZC1zZWFyY2gtZXZlbnQnO1xyXG5cclxuQENvbXBvbmVudCh7XHJcbiAgICBzZWxlY3RvcjogJ2tkLXNlYXJjaCcsXHJcbiAgICB0ZW1wbGF0ZTogYFxyXG4gICAgICAgIDxkaXYgY2xhc3M9XCJzZWFyY2gtcGFnZS13cmFwcGVyXCI+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJzZWFyY2gtcGFnZS1ib3hcIj5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJzZWFyY2gtdGl0bGVcIj5cclxuICAgICAgICAgICAgICAgICAgICA8aDE+e3tfc2VhcmNoU2V0dGluZ3MudGl0bGV9fTwvaDE+XHJcbiAgICAgICAgICAgICAgICAgICAgPHAgKm5nSWY9XCJfc2VhcmNoU2V0dGluZ3MuZGVzY3JpcHRpb25cIj57e19zZWFyY2hTZXR0aW5ncy5kZXNjcmlwdGlvbn19PC9wPlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwic2VhcmNoLWJvZHlcIj5cclxuICAgICAgICAgICAgICAgICAgICA8aW5wdXQgdHlwZT1cInRleHRcIiBbKG5nTW9kZWwpXT1cIl9yZXN1bHQuc2VhcmNoVGV4dFwiIHBsYWNlaG9sZGVyPVwie3tfc2VhcmNoU2V0dGluZ3Muc2VhcmNoUGxhY2Vob2xkZXJ9fVwiLz5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2ICpuZ0lmPVwiX3NlYXJjaFNldHRpbmdzLmZpbHRlclwiIGNsYXNzPVwia2R4LWlucHV0LXNlbGVjdC13cmFwcGVyXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxzZWxlY3QgWyhuZ01vZGVsKV09XCJfcmVzdWx0Lm9wdGlvblZhbFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiAqbmdGb3I9XCJsZXQgaXRlbSBvZiBfc2VhcmNoU2V0dGluZ3Mub3B0aW9uc1wiIFt2YWx1ZV09XCJpdGVtLmtleVwiPnt7aXRlbS52YWx1ZX19PC9vcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvc2VsZWN0PlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwic2VhcmNoLWJ1dHRvbnNcIj5cclxuICAgICAgICAgICAgICAgICAgICA8YnV0dG9uIGNsYXNzPVwiYnRuIGJ0bi10ZXh0XCIgW2Rpc2FibGVkXT1cIl9kaXNhYmxlXCIgKGNsaWNrKT1cInNlYXJjaENsaWNrZWQodHJ1ZSlcIj5TZWFyY2ggPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgICAgICAgPGJ1dHRvbiBjbGFzcz1cImJ0biBidG4tdGV4dFwiIFtkaXNhYmxlZF09XCJfZGlzYWJsZVwiIChjbGljayk9XCJzZWFyY2hDbGlja2VkKGZhbHNlKVwiPkFkdmFuY2UgU2VhcmNoPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICBgLFxyXG4gICAgZW5jYXBzdWxhdGlvbjogVmlld0VuY2Fwc3VsYXRpb24uTm9uZSxcclxuICAgIHByb3ZpZGVyczogW0tkSW50U2VhcmNoRXZlbnRdLFxyXG4gICAgaG9zdDogeyAnY2xhc3MnIDogJ2tkeCBrZHgtc2VhcmNoJyB9XHJcbn0pXHJcblxyXG5leHBvcnQgY2xhc3MgS2RTZWFyY2ggaW1wbGVtZW50cyBPbkluaXQsIE9uRGVzdHJveSB7XHJcbiAgICBwdWJsaWMgX3Jlc3VsdDogYW55ID0ge307XHJcbiAgICBwdWJsaWMgX3NlYXJjaFNldHRpbmdzOiBhbnkgPSB7fTtcclxuICAgIHB1YmxpYyBfZGlzYWJsZTogYm9vbGVhbiA9IGZhbHNlO1xyXG5cclxuICAgIHByaXZhdGUgX2RlZmF1bHRTZXR0aW5nczogYW55ID0ge1xyXG4gICAgICAgIHRpdGxlOiAnRGlyZWN0b3J5JyxcclxuICAgICAgICBzZWFyY2hQbGFjZWhvbGRlcjogJ1NlYXJjaCcsXHJcbiAgICAgICAgZGVzY3JpcHRpb246ICdTZWFyY2ggRGlyZWN0b3J5JyxcclxuICAgICAgICBmaWx0ZXI6IGZhbHNlLFxyXG4gICAgICAgIG9wdGlvbnM6IFtdXHJcbiAgICB9O1xyXG4gICAgcHJpdmF0ZSBfc2VhcmNoU3ViOiBTdWJzY3JpcHRpb247XHJcblxyXG4gICAgQElucHV0KCkgY29uZmlnOiBhbnk7XHJcbiAgICBAT3V0cHV0KCkgc2VhcmNoQnRuQ2xpY2tlZDogRXZlbnRFbWl0dGVyPGFueT4gPSBuZXcgRXZlbnRFbWl0dGVyKCk7XHJcbiAgICBAT3V0cHV0KCkgYWR2U2VhcmNoQnRuQ2xpY2tlZDogRXZlbnRFbWl0dGVyPGFueT4gPSBuZXcgRXZlbnRFbWl0dGVyKCk7XHJcblxyXG4gICAgY29uc3RydWN0b3IoXHJcbiAgICAgICAgcHJpdmF0ZSBfc2VhcmNoRXZlbnQ6IEtkSW50U2VhcmNoRXZlbnRcclxuICAgICkgeyB9XHJcblxyXG4gICAgbmdPbkluaXQoKTogdm9pZCB7XHJcbiAgICAgICAgdGhpcy5fc2VhcmNoU2V0dGluZ3MgPSBPYmplY3QuYXNzaWduKHt9LCB0aGlzLl9kZWZhdWx0U2V0dGluZ3MsIHRoaXMuY29uZmlnKTtcclxuICAgICAgICBpZiAodGhpcy5fc2VhcmNoU2V0dGluZ3MuZmlsdGVyKSB0aGlzLl9yZXN1bHQub3B0aW9uVmFsID0gJyc7XHJcblxyXG4gICAgICAgIHRoaXMuX3NlYXJjaFN1YiA9IHRoaXMuX3NlYXJjaEV2ZW50Lm9uRGlzYWJsZUJ1dHRvbigpLnN1YnNjcmliZShkYXRhID0+IHtcclxuICAgICAgICAgICAgaWYgKHR5cGVvZiBkYXRhICE9PSAndW5kZWZpbmVkJykgdGhpcy5fZGlzYWJsZSA9IGRhdGE7XHJcbiAgICAgICAgICAgIGVsc2UgdGhpcy5fZGlzYWJsZSA9ICF0aGlzLl9kaXNhYmxlO1xyXG4gICAgICAgIH0pO1xyXG4gICAgfVxyXG5cclxuICAgIG5nT25EZXN0cm95KCk6IHZvaWQge1xyXG4gICAgICAgIHRoaXMuX3NlYXJjaFN1Yi51bnN1YnNjcmliZSgpO1xyXG4gICAgfVxyXG5cclxuICAgIHB1YmxpYyBzZWFyY2hDbGlja2VkKGlzU2VhcmNoOiBib29sZWFuKTogdm9pZCB7XHJcbiAgICAgICAgaWYgKGlzU2VhcmNoKSB0aGlzLnNlYXJjaEJ0bkNsaWNrZWQuZW1pdCh0aGlzLl9yZXN1bHQpO1xyXG4gICAgICAgIGVsc2UgdGhpcy5hZHZTZWFyY2hCdG5DbGlja2VkLmVtaXQodGhpcy5fcmVzdWx0KTtcclxuICAgIH1cclxufVxyXG4iXX0=