import { Component, Input, Output, EventEmitter, ViewContainerRef } from '@angular/core';
export class KdFileInput {
    constructor(_vcr) {
        this._vcr = _vcr;
        this._fileResult = {
            src: '',
            filename: '',
            extension: '',
            data: ''
        };
        this.result = new EventEmitter();
    }
    ngOnInit() {
        this._setFileType();
        this._setLeftBtn();
        this._checkInitFile();
    }
    handleFileSelect(event) {
        let files = event.target.files;
        let file = files[0];
        if (typeof this.config.fileName === 'undefined' || this.config.fileName === '') {
            this.config.fileName = file.name;
        }
        // if (files && file) {
        if (typeof files !== 'undefined' && typeof file !== 'undefined') {
            let reader = new FileReader();
            reader.onload = () => {
                let dataUrl = reader.result;
                // console.log('dataUrl - ', dataUrl);
                let findExtension = file.name.split('.');
                this._fileResult = {
                    src: dataUrl,
                    data: file,
                    filename: file.name,
                    extension: findExtension[findExtension.length - 1]
                };
                this.result.emit(this._fileResult.data);
            };
            reader.readAsDataURL(file);
        }
    }
    // public handleFileSelect(event: any): void {
    //     let files = event.target.files;
    //     let file = files[0];
    //     if (typeof this.config.fileName === 'undefined' || this.config.fileName === '') {
    //         this.config.fileName = file.name;
    //     }
    //     // if (files && file) {
    //     if (typeof files !== 'undefined' && typeof file !== 'undefined') {
    //         let reader = new FileReader();
    //         reader.onload = (): void => {
    //             // check the file type in format --> data:image/png;base64,
    //             // this._dataUri = 'data:' + file.type + ';base64,';
    //             let binaryString: string = reader.result;
    //             this._fileResult = this._getResult(binaryString, file);
    //             this.result.emit(this._fileResult);
    //         }
    //         reader.readAsBinaryString(file);
    //     }
    // }
    removeFile(_event) {
        _event.preventDefault();
        let fileinput = this._vcr.element.nativeElement.querySelector('#filePicker');
        fileinput.value = '';
        this._fileResult = {
            data: '',
            extension: '',
            filename: '',
            src: ''
        };
        // this._fileResult.data = '';
        // this._fileResult.extension = '';
        // this._fileResult.filename = '';
        // this._fileResult.src = '';
        this.result.emit(this._fileResult);
    }
    buttonCallback(_event, _button) {
        _event.preventDefault();
        if (typeof _button.callback === 'function') {
            _button.callback(_event, _button);
        }
    }
    _checkInitFile() {
        if (typeof this.value !== 'undefined') {
            this._fileResult.data = this.value.data;
            this._fileResult.extension = this.value.extension;
            this._fileResult.filename = this.value.filename;
            this._fileResult.src = this.value.src;
        }
    }
    // private _getResult(binaryString: string, file: any): IFileResult {
    //     let dataUri: string = 'data:' + file.type + ';base64,';
    //     let base64String: string = btoa(binaryString);
    //     let findExtension: Array<string> = file.name.split('.');
    //     // let newResult: IFileResult =
    //     // newResult.data = base64String;
    //     // newResult.src = dataUri + base64String;
    //     // newResult.filename = file.name;
    //     // newResult.extension = findExtension[findExtension.length - 1];
    //     return {
    //         data: base64String,
    //         src: dataUri + base64String,
    //         filename: file.name,
    //         extension: findExtension[findExtension.length - 1],
    //     };
    // }
    _setFileType() {
        if (typeof this.config !== 'undefined' && typeof this.config.fileType === 'undefined') {
            this.config['fileType'] = 'file_extension, media_type';
        }
        else if (this.config.fileType === 'image') {
            this.config.fileType = 'image/*';
        }
        else if (this.config.fileType === 'media') {
            this.config.fileType = 'audio/*, video/*';
        }
        else if (this.config.fileType === 'text') {
            this.config.fileType = '.csv, .pdf, .xl, .xla, .xlb, .xlc, .xld, .xlk, .xll, .xlm, .xls, .xlt, .xlv, .xlw, .doc, .dot';
        }
    }
    _setLeftBtn() {
        if (typeof this.config.leftButton !== 'undefined' && this.config.leftToolbar === true) {
            if (this.config.leftButton.length === 1) {
                this._leftButton = 'input-single-btn';
            }
            else {
                this._leftButton = 'input-double-btn';
            }
        }
    }
}
KdFileInput.decorators = [
    { type: Component, args: [{
                selector: 'kd-fileinput',
                template: "<div class=\"kdx-fileinput-wrapper\">\r\n    <div class=\"kdx-file-preview\" *ngIf=\"config.preview\">\r\n        <kd-placeholder [config]='config.imageConfig' [value]='_fileResult'></kd-placeholder>\r\n    </div>\r\n\r\n    <label class=\"kdx-wrapper\">\r\n        <input type=\"file\" class=\"hidden\" id=\"filePicker\" accept=\"{{config.fileType}}\" (change)=\"handleFileSelect($event)\">\r\n        <ng-content></ng-content>\r\n        <div class=\"btn btn-icon btn-browse\" placement=\"bottom\" ngbTooltip=\"Browse\">\r\n            <i class=\"fa fa-folder\"></i>\r\n        </div>\r\n        <div *ngIf=\"config.leftToolbar\" class=\"{{_leftButton}}\">\r\n            <button *ngFor=\"let button of config.leftButton | slice:0:2;\" class=\"btn btn-icon\" placement=\"bottom\" ngbTooltip=\"{{button.label}}\" (click)=\"buttonCallback($event, button)\" type=\"button\">\r\n                <i class=\"fa {{button.icon}}\"></i>\r\n            </button>\r\n        </div>\r\n         <div *ngIf=\"_fileResult.filename\" class=\"kdx-input-text\">\r\n            <i class=\"fa fa-file-o\"></i>\r\n            <p>{{_fileResult.filename}}</p>\r\n        </div>\r\n        <button *ngIf=\"_fileResult.filename\" class=\"btn btn-remove\" (click)=\"removeFile($event)\" placement=\"bottom\" ngbTooltip=\"Remove\" type=\"button\">\r\n            <i class=\"kd-close-round\"></i>\r\n        </button>\r\n    </label>\r\n        \r\n    <div *ngIf=\"config.infoText\" class=\"kdx-fileinput-text\">\r\n    \t<div *ngFor=\"let list of config.infoText | slice:0:3;\">* {{list.text}}</div>\r\n    </div>\r\n</div>"
            },] }
];
KdFileInput.ctorParameters = () => [
    { type: ViewContainerRef }
];
KdFileInput.propDecorators = {
    config: [{ type: Input }],
    value: [{ type: Input }],
    result: [{ type: Output }]
};
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoia2QtYW5ndWxhci1maWxlaW5wdXQuanMiLCJzb3VyY2VSb290IjoiRDovb3BlbkVNSVMvc3R5bGVndWlkZS9pb3N0Zy1vcGVuZW1pcy1zdHlsZWd1aWRlL3Byb2plY3RzL29wZW5lbWlzLXN0eWxlZ3VpZGUtbGliL3NyYy8iLCJzb3VyY2VzIjpbImtkLWNvbXBvbmVudHMva2QtYW5ndWxhci1maWxlaW5wdXQva2QtYW5ndWxhci1maWxlaW5wdXQudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsT0FBTyxFQUNILFNBQVMsRUFFVCxLQUFLLEVBQ0wsTUFBTSxFQUNOLFlBQVksRUFDWixnQkFBZ0IsRUFDbkIsTUFBTSxlQUFlLENBQUM7QUFTdkIsTUFBTSxPQUFPLFdBQVc7SUFjcEIsWUFDWSxJQUFzQjtRQUF0QixTQUFJLEdBQUosSUFBSSxDQUFrQjtRQWIzQixnQkFBVyxHQUFnQjtZQUM5QixHQUFHLEVBQUUsRUFBRTtZQUNQLFFBQVEsRUFBRSxFQUFFO1lBQ1osU0FBUyxFQUFFLEVBQUU7WUFDYixJQUFJLEVBQUUsRUFBRTtTQUNYLENBQUM7UUFLUSxXQUFNLEdBQUcsSUFBSSxZQUFZLEVBQUUsQ0FBQztJQUlsQyxDQUFDO0lBRUwsUUFBUTtRQUNKLElBQUksQ0FBQyxZQUFZLEVBQUUsQ0FBQztRQUNwQixJQUFJLENBQUMsV0FBVyxFQUFFLENBQUM7UUFDbkIsSUFBSSxDQUFDLGNBQWMsRUFBRSxDQUFDO0lBQzFCLENBQUM7SUFFTSxnQkFBZ0IsQ0FBQyxLQUFVO1FBQzlCLElBQUksS0FBSyxHQUFhLEtBQUssQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDO1FBQ3pDLElBQUksSUFBSSxHQUFTLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQztRQUUxQixJQUFJLE9BQU8sSUFBSSxDQUFDLE1BQU0sQ0FBQyxRQUFRLEtBQUssV0FBVyxJQUFJLElBQUksQ0FBQyxNQUFNLENBQUMsUUFBUSxLQUFLLEVBQUUsRUFBRTtZQUM1RSxJQUFJLENBQUMsTUFBTSxDQUFDLFFBQVEsR0FBRyxJQUFJLENBQUMsSUFBSSxDQUFDO1NBQ3BDO1FBRUQsdUJBQXVCO1FBQ3ZCLElBQUksT0FBTyxLQUFLLEtBQUssV0FBVyxJQUFJLE9BQU8sSUFBSSxLQUFLLFdBQVcsRUFBRTtZQUM3RCxJQUFJLE1BQU0sR0FBZSxJQUFJLFVBQVUsRUFBRSxDQUFDO1lBRTFDLE1BQU0sQ0FBQyxNQUFNLEdBQUcsR0FBRyxFQUFFO2dCQUNqQixJQUFJLE9BQU8sR0FBVyxNQUFNLENBQUMsTUFBZ0IsQ0FBQztnQkFDOUMsc0NBQXNDO2dCQUN0QyxJQUFJLGFBQWEsR0FBa0IsSUFBSSxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLENBQUM7Z0JBQ3hELElBQUksQ0FBQyxXQUFXLEdBQUc7b0JBQ2YsR0FBRyxFQUFFLE9BQU87b0JBQ1osSUFBSSxFQUFFLElBQUk7b0JBQ1YsUUFBUSxFQUFFLElBQUksQ0FBQyxJQUFJO29CQUNuQixTQUFTLEVBQUUsYUFBYSxDQUFDLGFBQWEsQ0FBQyxNQUFNLEdBQUcsQ0FBQyxDQUFDO2lCQUNyRCxDQUFDO2dCQUNGLElBQUksQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxXQUFXLENBQUMsSUFBSSxDQUFDLENBQUM7WUFDNUMsQ0FBQyxDQUFDO1lBRUYsTUFBTSxDQUFDLGFBQWEsQ0FBQyxJQUFJLENBQUMsQ0FBQztTQUM5QjtJQUNMLENBQUM7SUFFRCw4Q0FBOEM7SUFDOUMsc0NBQXNDO0lBQ3RDLDJCQUEyQjtJQUUzQix3RkFBd0Y7SUFDeEYsNENBQTRDO0lBQzVDLFFBQVE7SUFFUiw4QkFBOEI7SUFDOUIseUVBQXlFO0lBQ3pFLHlDQUF5QztJQUV6Qyx3Q0FBd0M7SUFDeEMsMEVBQTBFO0lBQzFFLG1FQUFtRTtJQUVuRSx3REFBd0Q7SUFDeEQsc0VBQXNFO0lBQ3RFLGtEQUFrRDtJQUNsRCxZQUFZO0lBRVosMkNBQTJDO0lBQzNDLFFBQVE7SUFDUixJQUFJO0lBRUcsVUFBVSxDQUFDLE1BQWE7UUFDM0IsTUFBTSxDQUFDLGNBQWMsRUFBRSxDQUFDO1FBRXhCLElBQUksU0FBUyxHQUFHLElBQUksQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLGFBQWEsQ0FBQyxhQUFhLENBQUMsYUFBYSxDQUFDLENBQUM7UUFDN0UsU0FBUyxDQUFDLEtBQUssR0FBRyxFQUFFLENBQUM7UUFFckIsSUFBSSxDQUFDLFdBQVcsR0FBRztZQUNmLElBQUksRUFBRSxFQUFFO1lBQ1IsU0FBUyxFQUFFLEVBQUU7WUFDYixRQUFRLEVBQUUsRUFBRTtZQUNaLEdBQUcsRUFBRSxFQUFFO1NBQ1YsQ0FBQztRQUVGLDhCQUE4QjtRQUM5QixtQ0FBbUM7UUFDbkMsa0NBQWtDO1FBQ2xDLDZCQUE2QjtRQUM3QixJQUFJLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFDLENBQUM7SUFDdkMsQ0FBQztJQUVNLGNBQWMsQ0FBQyxNQUFhLEVBQUUsT0FBWTtRQUM3QyxNQUFNLENBQUMsY0FBYyxFQUFFLENBQUM7UUFDeEIsSUFBSSxPQUFPLE9BQU8sQ0FBQyxRQUFRLEtBQUssVUFBVSxFQUFFO1lBQ3hDLE9BQU8sQ0FBQyxRQUFRLENBQUMsTUFBTSxFQUFFLE9BQU8sQ0FBQyxDQUFDO1NBQ3JDO0lBQ0wsQ0FBQztJQUVPLGNBQWM7UUFDbEIsSUFBSSxPQUFPLElBQUksQ0FBQyxLQUFLLEtBQUssV0FBVyxFQUFFO1lBQ25DLElBQUksQ0FBQyxXQUFXLENBQUMsSUFBSSxHQUFHLElBQUksQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDO1lBQ3hDLElBQUksQ0FBQyxXQUFXLENBQUMsU0FBUyxHQUFHLElBQUksQ0FBQyxLQUFLLENBQUMsU0FBUyxDQUFDO1lBQ2xELElBQUksQ0FBQyxXQUFXLENBQUMsUUFBUSxHQUFHLElBQUksQ0FBQyxLQUFLLENBQUMsUUFBUSxDQUFDO1lBQ2hELElBQUksQ0FBQyxXQUFXLENBQUMsR0FBRyxHQUFHLElBQUksQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDO1NBQ3pDO0lBQ0wsQ0FBQztJQUVELHFFQUFxRTtJQUNyRSw4REFBOEQ7SUFDOUQscURBQXFEO0lBQ3JELCtEQUErRDtJQUUvRCxzQ0FBc0M7SUFFdEMsd0NBQXdDO0lBQ3hDLGlEQUFpRDtJQUNqRCx5Q0FBeUM7SUFDekMsd0VBQXdFO0lBQ3hFLGVBQWU7SUFDZiw4QkFBOEI7SUFDOUIsdUNBQXVDO0lBQ3ZDLCtCQUErQjtJQUMvQiw4REFBOEQ7SUFDOUQsU0FBUztJQUNULElBQUk7SUFFSSxZQUFZO1FBQ2hCLElBQUksT0FBTyxJQUFJLENBQUMsTUFBTSxLQUFLLFdBQVcsSUFBSSxPQUFPLElBQUksQ0FBQyxNQUFNLENBQUMsUUFBUSxLQUFLLFdBQVcsRUFBRTtZQUNuRixJQUFJLENBQUMsTUFBTSxDQUFDLFVBQVUsQ0FBQyxHQUFHLDRCQUE0QixDQUFDO1NBQzFEO2FBQ0ksSUFBSSxJQUFJLENBQUMsTUFBTSxDQUFDLFFBQVEsS0FBSyxPQUFPLEVBQUU7WUFDdkMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxRQUFRLEdBQUcsU0FBUyxDQUFDO1NBQ3BDO2FBQ0ksSUFBSSxJQUFJLENBQUMsTUFBTSxDQUFDLFFBQVEsS0FBSyxPQUFPLEVBQUU7WUFDdkMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxRQUFRLEdBQUcsa0JBQWtCLENBQUM7U0FDN0M7YUFDSSxJQUFJLElBQUksQ0FBQyxNQUFNLENBQUMsUUFBUSxLQUFLLE1BQU0sRUFBRTtZQUN0QyxJQUFJLENBQUMsTUFBTSxDQUFDLFFBQVEsR0FBRywrRkFBK0YsQ0FBQztTQUMxSDtJQUNMLENBQUM7SUFFTyxXQUFXO1FBQ2YsSUFBSSxPQUFPLElBQUksQ0FBQyxNQUFNLENBQUMsVUFBVSxLQUFLLFdBQVcsSUFBSSxJQUFJLENBQUMsTUFBTSxDQUFDLFdBQVcsS0FBSyxJQUFJLEVBQUU7WUFDbkYsSUFBSSxJQUFJLENBQUMsTUFBTSxDQUFDLFVBQVUsQ0FBQyxNQUFNLEtBQUssQ0FBQyxFQUFFO2dCQUNyQyxJQUFJLENBQUMsV0FBVyxHQUFHLGtCQUFrQixDQUFDO2FBQ3pDO2lCQUNJO2dCQUNELElBQUksQ0FBQyxXQUFXLEdBQUcsa0JBQWtCLENBQUM7YUFDekM7U0FDSjtJQUNMLENBQUM7OztZQWxLSixTQUFTLFNBQUM7Z0JBQ1AsUUFBUSxFQUFFLGNBQWM7Z0JBQ3hCLDRrREFBMEM7YUFDN0M7OztZQVJHLGdCQUFnQjs7O3FCQW9CZixLQUFLO29CQUNMLEtBQUs7cUJBQ0wsTUFBTSIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7XHJcbiAgICBDb21wb25lbnQsXHJcbiAgICBPbkluaXQsXHJcbiAgICBJbnB1dCxcclxuICAgIE91dHB1dCxcclxuICAgIEV2ZW50RW1pdHRlcixcclxuICAgIFZpZXdDb250YWluZXJSZWZcclxufSBmcm9tICdAYW5ndWxhci9jb3JlJztcclxuXHJcbmltcG9ydCB7IElGaWxlUmVzdWx0IH0gZnJvbSAnLi9rZC1maWxlaW5wdXQtaW50ZXJmYWNlJztcclxuXHJcbkBDb21wb25lbnQoe1xyXG4gICAgc2VsZWN0b3I6ICdrZC1maWxlaW5wdXQnLFxyXG4gICAgdGVtcGxhdGVVcmw6ICcuL2tkLWFuZ3VsYXItZmlsZWlucHV0Lmh0bWwnXHJcbn0pXHJcblxyXG5leHBvcnQgY2xhc3MgS2RGaWxlSW5wdXQgaW1wbGVtZW50cyBPbkluaXQge1xyXG4gICAgcHVibGljIF9sZWZ0QnV0dG9uOiBzdHJpbmc7XHJcbiAgICBwdWJsaWMgX2ZpbGVSZXN1bHQ6IElGaWxlUmVzdWx0ID0ge1xyXG4gICAgICAgIHNyYzogJycsXHJcbiAgICAgICAgZmlsZW5hbWU6ICcnLFxyXG4gICAgICAgIGV4dGVuc2lvbjogJycsXHJcbiAgICAgICAgZGF0YTogJydcclxuICAgIH07XHJcblxyXG5cclxuICAgIEBJbnB1dCgpIGNvbmZpZzogYW55O1xyXG4gICAgQElucHV0KCkgdmFsdWU6IGFueTtcclxuICAgIEBPdXRwdXQoKSByZXN1bHQgPSBuZXcgRXZlbnRFbWl0dGVyKCk7XHJcblxyXG4gICAgY29uc3RydWN0b3IoXHJcbiAgICAgICAgcHJpdmF0ZSBfdmNyOiBWaWV3Q29udGFpbmVyUmVmXHJcbiAgICApIHsgfVxyXG5cclxuICAgIG5nT25Jbml0KCk6IHZvaWQge1xyXG4gICAgICAgIHRoaXMuX3NldEZpbGVUeXBlKCk7XHJcbiAgICAgICAgdGhpcy5fc2V0TGVmdEJ0bigpO1xyXG4gICAgICAgIHRoaXMuX2NoZWNrSW5pdEZpbGUoKTtcclxuICAgIH1cclxuXHJcbiAgICBwdWJsaWMgaGFuZGxlRmlsZVNlbGVjdChldmVudDogYW55KTogdm9pZCB7XHJcbiAgICAgICAgbGV0IGZpbGVzOiBGaWxlTGlzdCA9IGV2ZW50LnRhcmdldC5maWxlcztcclxuICAgICAgICBsZXQgZmlsZTogRmlsZSA9IGZpbGVzWzBdO1xyXG5cclxuICAgICAgICBpZiAodHlwZW9mIHRoaXMuY29uZmlnLmZpbGVOYW1lID09PSAndW5kZWZpbmVkJyB8fCB0aGlzLmNvbmZpZy5maWxlTmFtZSA9PT0gJycpIHtcclxuICAgICAgICAgICAgdGhpcy5jb25maWcuZmlsZU5hbWUgPSBmaWxlLm5hbWU7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICAvLyBpZiAoZmlsZXMgJiYgZmlsZSkge1xyXG4gICAgICAgIGlmICh0eXBlb2YgZmlsZXMgIT09ICd1bmRlZmluZWQnICYmIHR5cGVvZiBmaWxlICE9PSAndW5kZWZpbmVkJykge1xyXG4gICAgICAgICAgICBsZXQgcmVhZGVyOiBGaWxlUmVhZGVyID0gbmV3IEZpbGVSZWFkZXIoKTtcclxuXHJcbiAgICAgICAgICAgIHJlYWRlci5vbmxvYWQgPSAoKSA9PiB7XHJcbiAgICAgICAgICAgICAgICBsZXQgZGF0YVVybDogc3RyaW5nID0gcmVhZGVyLnJlc3VsdCBhcyBzdHJpbmc7XHJcbiAgICAgICAgICAgICAgICAvLyBjb25zb2xlLmxvZygnZGF0YVVybCAtICcsIGRhdGFVcmwpO1xyXG4gICAgICAgICAgICAgICAgbGV0IGZpbmRFeHRlbnNpb246IEFycmF5PHN0cmluZz4gPSBmaWxlLm5hbWUuc3BsaXQoJy4nKTtcclxuICAgICAgICAgICAgICAgIHRoaXMuX2ZpbGVSZXN1bHQgPSB7XHJcbiAgICAgICAgICAgICAgICAgICAgc3JjOiBkYXRhVXJsLFxyXG4gICAgICAgICAgICAgICAgICAgIGRhdGE6IGZpbGUsXHJcbiAgICAgICAgICAgICAgICAgICAgZmlsZW5hbWU6IGZpbGUubmFtZSxcclxuICAgICAgICAgICAgICAgICAgICBleHRlbnNpb246IGZpbmRFeHRlbnNpb25bZmluZEV4dGVuc2lvbi5sZW5ndGggLSAxXVxyXG4gICAgICAgICAgICAgICAgfTtcclxuICAgICAgICAgICAgICAgIHRoaXMucmVzdWx0LmVtaXQodGhpcy5fZmlsZVJlc3VsdC5kYXRhKTtcclxuICAgICAgICAgICAgfTtcclxuXHJcbiAgICAgICAgICAgIHJlYWRlci5yZWFkQXNEYXRhVVJMKGZpbGUpO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICAvLyBwdWJsaWMgaGFuZGxlRmlsZVNlbGVjdChldmVudDogYW55KTogdm9pZCB7XHJcbiAgICAvLyAgICAgbGV0IGZpbGVzID0gZXZlbnQudGFyZ2V0LmZpbGVzO1xyXG4gICAgLy8gICAgIGxldCBmaWxlID0gZmlsZXNbMF07XHJcblxyXG4gICAgLy8gICAgIGlmICh0eXBlb2YgdGhpcy5jb25maWcuZmlsZU5hbWUgPT09ICd1bmRlZmluZWQnIHx8IHRoaXMuY29uZmlnLmZpbGVOYW1lID09PSAnJykge1xyXG4gICAgLy8gICAgICAgICB0aGlzLmNvbmZpZy5maWxlTmFtZSA9IGZpbGUubmFtZTtcclxuICAgIC8vICAgICB9XHJcblxyXG4gICAgLy8gICAgIC8vIGlmIChmaWxlcyAmJiBmaWxlKSB7XHJcbiAgICAvLyAgICAgaWYgKHR5cGVvZiBmaWxlcyAhPT0gJ3VuZGVmaW5lZCcgJiYgdHlwZW9mIGZpbGUgIT09ICd1bmRlZmluZWQnKSB7XHJcbiAgICAvLyAgICAgICAgIGxldCByZWFkZXIgPSBuZXcgRmlsZVJlYWRlcigpO1xyXG5cclxuICAgIC8vICAgICAgICAgcmVhZGVyLm9ubG9hZCA9ICgpOiB2b2lkID0+IHtcclxuICAgIC8vICAgICAgICAgICAgIC8vIGNoZWNrIHRoZSBmaWxlIHR5cGUgaW4gZm9ybWF0IC0tPiBkYXRhOmltYWdlL3BuZztiYXNlNjQsXHJcbiAgICAvLyAgICAgICAgICAgICAvLyB0aGlzLl9kYXRhVXJpID0gJ2RhdGE6JyArIGZpbGUudHlwZSArICc7YmFzZTY0LCc7XHJcblxyXG4gICAgLy8gICAgICAgICAgICAgbGV0IGJpbmFyeVN0cmluZzogc3RyaW5nID0gcmVhZGVyLnJlc3VsdDtcclxuICAgIC8vICAgICAgICAgICAgIHRoaXMuX2ZpbGVSZXN1bHQgPSB0aGlzLl9nZXRSZXN1bHQoYmluYXJ5U3RyaW5nLCBmaWxlKTtcclxuICAgIC8vICAgICAgICAgICAgIHRoaXMucmVzdWx0LmVtaXQodGhpcy5fZmlsZVJlc3VsdCk7XHJcbiAgICAvLyAgICAgICAgIH1cclxuXHJcbiAgICAvLyAgICAgICAgIHJlYWRlci5yZWFkQXNCaW5hcnlTdHJpbmcoZmlsZSk7XHJcbiAgICAvLyAgICAgfVxyXG4gICAgLy8gfVxyXG5cclxuICAgIHB1YmxpYyByZW1vdmVGaWxlKF9ldmVudDogRXZlbnQpOiB2b2lkIHtcclxuICAgICAgICBfZXZlbnQucHJldmVudERlZmF1bHQoKTtcclxuXHJcbiAgICAgICAgbGV0IGZpbGVpbnB1dCA9IHRoaXMuX3Zjci5lbGVtZW50Lm5hdGl2ZUVsZW1lbnQucXVlcnlTZWxlY3RvcignI2ZpbGVQaWNrZXInKTtcclxuICAgICAgICBmaWxlaW5wdXQudmFsdWUgPSAnJztcclxuXHJcbiAgICAgICAgdGhpcy5fZmlsZVJlc3VsdCA9IHtcclxuICAgICAgICAgICAgZGF0YTogJycsXHJcbiAgICAgICAgICAgIGV4dGVuc2lvbjogJycsXHJcbiAgICAgICAgICAgIGZpbGVuYW1lOiAnJyxcclxuICAgICAgICAgICAgc3JjOiAnJ1xyXG4gICAgICAgIH07XHJcblxyXG4gICAgICAgIC8vIHRoaXMuX2ZpbGVSZXN1bHQuZGF0YSA9ICcnO1xyXG4gICAgICAgIC8vIHRoaXMuX2ZpbGVSZXN1bHQuZXh0ZW5zaW9uID0gJyc7XHJcbiAgICAgICAgLy8gdGhpcy5fZmlsZVJlc3VsdC5maWxlbmFtZSA9ICcnO1xyXG4gICAgICAgIC8vIHRoaXMuX2ZpbGVSZXN1bHQuc3JjID0gJyc7XHJcbiAgICAgICAgdGhpcy5yZXN1bHQuZW1pdCh0aGlzLl9maWxlUmVzdWx0KTtcclxuICAgIH1cclxuXHJcbiAgICBwdWJsaWMgYnV0dG9uQ2FsbGJhY2soX2V2ZW50OiBFdmVudCwgX2J1dHRvbjogYW55KTogdm9pZCB7XHJcbiAgICAgICAgX2V2ZW50LnByZXZlbnREZWZhdWx0KCk7XHJcbiAgICAgICAgaWYgKHR5cGVvZiBfYnV0dG9uLmNhbGxiYWNrID09PSAnZnVuY3Rpb24nKSB7XHJcbiAgICAgICAgICAgIF9idXR0b24uY2FsbGJhY2soX2V2ZW50LCBfYnV0dG9uKTtcclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfY2hlY2tJbml0RmlsZSgpOiB2b2lkIHtcclxuICAgICAgICBpZiAodHlwZW9mIHRoaXMudmFsdWUgIT09ICd1bmRlZmluZWQnKSB7XHJcbiAgICAgICAgICAgIHRoaXMuX2ZpbGVSZXN1bHQuZGF0YSA9IHRoaXMudmFsdWUuZGF0YTtcclxuICAgICAgICAgICAgdGhpcy5fZmlsZVJlc3VsdC5leHRlbnNpb24gPSB0aGlzLnZhbHVlLmV4dGVuc2lvbjtcclxuICAgICAgICAgICAgdGhpcy5fZmlsZVJlc3VsdC5maWxlbmFtZSA9IHRoaXMudmFsdWUuZmlsZW5hbWU7XHJcbiAgICAgICAgICAgIHRoaXMuX2ZpbGVSZXN1bHQuc3JjID0gdGhpcy52YWx1ZS5zcmM7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIC8vIHByaXZhdGUgX2dldFJlc3VsdChiaW5hcnlTdHJpbmc6IHN0cmluZywgZmlsZTogYW55KTogSUZpbGVSZXN1bHQge1xyXG4gICAgLy8gICAgIGxldCBkYXRhVXJpOiBzdHJpbmcgPSAnZGF0YTonICsgZmlsZS50eXBlICsgJztiYXNlNjQsJztcclxuICAgIC8vICAgICBsZXQgYmFzZTY0U3RyaW5nOiBzdHJpbmcgPSBidG9hKGJpbmFyeVN0cmluZyk7XHJcbiAgICAvLyAgICAgbGV0IGZpbmRFeHRlbnNpb246IEFycmF5PHN0cmluZz4gPSBmaWxlLm5hbWUuc3BsaXQoJy4nKTtcclxuXHJcbiAgICAvLyAgICAgLy8gbGV0IG5ld1Jlc3VsdDogSUZpbGVSZXN1bHQgPVxyXG5cclxuICAgIC8vICAgICAvLyBuZXdSZXN1bHQuZGF0YSA9IGJhc2U2NFN0cmluZztcclxuICAgIC8vICAgICAvLyBuZXdSZXN1bHQuc3JjID0gZGF0YVVyaSArIGJhc2U2NFN0cmluZztcclxuICAgIC8vICAgICAvLyBuZXdSZXN1bHQuZmlsZW5hbWUgPSBmaWxlLm5hbWU7XHJcbiAgICAvLyAgICAgLy8gbmV3UmVzdWx0LmV4dGVuc2lvbiA9IGZpbmRFeHRlbnNpb25bZmluZEV4dGVuc2lvbi5sZW5ndGggLSAxXTtcclxuICAgIC8vICAgICByZXR1cm4ge1xyXG4gICAgLy8gICAgICAgICBkYXRhOiBiYXNlNjRTdHJpbmcsXHJcbiAgICAvLyAgICAgICAgIHNyYzogZGF0YVVyaSArIGJhc2U2NFN0cmluZyxcclxuICAgIC8vICAgICAgICAgZmlsZW5hbWU6IGZpbGUubmFtZSxcclxuICAgIC8vICAgICAgICAgZXh0ZW5zaW9uOiBmaW5kRXh0ZW5zaW9uW2ZpbmRFeHRlbnNpb24ubGVuZ3RoIC0gMV0sXHJcbiAgICAvLyAgICAgfTtcclxuICAgIC8vIH1cclxuXHJcbiAgICBwcml2YXRlIF9zZXRGaWxlVHlwZSgpIHtcclxuICAgICAgICBpZiAodHlwZW9mIHRoaXMuY29uZmlnICE9PSAndW5kZWZpbmVkJyAmJiB0eXBlb2YgdGhpcy5jb25maWcuZmlsZVR5cGUgPT09ICd1bmRlZmluZWQnKSB7XHJcbiAgICAgICAgICAgIHRoaXMuY29uZmlnWydmaWxlVHlwZSddID0gJ2ZpbGVfZXh0ZW5zaW9uLCBtZWRpYV90eXBlJztcclxuICAgICAgICB9XHJcbiAgICAgICAgZWxzZSBpZiAodGhpcy5jb25maWcuZmlsZVR5cGUgPT09ICdpbWFnZScpIHtcclxuICAgICAgICAgICAgdGhpcy5jb25maWcuZmlsZVR5cGUgPSAnaW1hZ2UvKic7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGVsc2UgaWYgKHRoaXMuY29uZmlnLmZpbGVUeXBlID09PSAnbWVkaWEnKSB7XHJcbiAgICAgICAgICAgIHRoaXMuY29uZmlnLmZpbGVUeXBlID0gJ2F1ZGlvLyosIHZpZGVvLyonO1xyXG4gICAgICAgIH1cclxuICAgICAgICBlbHNlIGlmICh0aGlzLmNvbmZpZy5maWxlVHlwZSA9PT0gJ3RleHQnKSB7XHJcbiAgICAgICAgICAgIHRoaXMuY29uZmlnLmZpbGVUeXBlID0gJy5jc3YsIC5wZGYsIC54bCwgLnhsYSwgLnhsYiwgLnhsYywgLnhsZCwgLnhsaywgLnhsbCwgLnhsbSwgLnhscywgLnhsdCwgLnhsdiwgLnhsdywgLmRvYywgLmRvdCc7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX3NldExlZnRCdG4oKSB7XHJcbiAgICAgICAgaWYgKHR5cGVvZiB0aGlzLmNvbmZpZy5sZWZ0QnV0dG9uICE9PSAndW5kZWZpbmVkJyAmJiB0aGlzLmNvbmZpZy5sZWZ0VG9vbGJhciA9PT0gdHJ1ZSkge1xyXG4gICAgICAgICAgICBpZiAodGhpcy5jb25maWcubGVmdEJ1dHRvbi5sZW5ndGggPT09IDEpIHtcclxuICAgICAgICAgICAgICAgIHRoaXMuX2xlZnRCdXR0b24gPSAnaW5wdXQtc2luZ2xlLWJ0bic7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgZWxzZSB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLl9sZWZ0QnV0dG9uID0gJ2lucHV0LWRvdWJsZS1idG4nO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG59XHJcbiJdfQ==