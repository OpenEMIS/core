import { Component, ViewEncapsulation, Input, HostListener, Output, EventEmitter, } from '@angular/core';
import { timer } from 'rxjs';
import { debounceTime } from 'rxjs/operators';
import { Router } from '@angular/router';
import { KdWizardEvent } from './kd-angular-wizard-event';
import { KdWizardSvc } from './kd-angular-wizard-svc';
import { KdDomElemSvc } from '../kd-common/index';
import { KdSplitterEvent } from '../kd-angular-splitter/index';
export class KdWizard {
    constructor(_router, _kdWizardEvent, _kdWizardSvc, _kdDomSvc, _kdSplitterEvent) {
        this._router = _router;
        this._kdWizardEvent = _kdWizardEvent;
        this._kdWizardSvc = _kdWizardSvc;
        this._kdDomSvc = _kdDomSvc;
        this.steps = [];
        this.isButtonHidden = false;
        this.isPreviousDisabled = true;
        this.isNextDisabled = false;
        this.tooltipDisabled = false;
        this._tooltipNotDisplayed = false;
        this.activeStepEmitter = new EventEmitter();
        this._dragMenuSub = _kdSplitterEvent.onDrag()
            .pipe(debounceTime(100))
            .subscribe(() => {
            this._handleTranslateAndTooltip();
        });
        this._toggleMenuSub = _kdSplitterEvent.onToggleMenu().subscribe(() => {
            timer(500).subscribe(() => {
                this._handleTranslateAndTooltip();
            });
        });
    }
    onResize(event) {
        timer(200).subscribe(() => {
            this._handleTranslateAndTooltip();
        });
    }
    ngOnInit() {
        this.id = typeof this.wizardId === 'undefined' ? 'wizard' : this.wizardId;
        this.steps = this._kdWizardSvc.setItem(this.config.steps);
        this._initApi();
        this.nextButtonText = this.config.next || 'Next';
        this.activeStep = this.steps[0];
        this._emitStep(this.steps[0].content);
        this.isMobileDevice = this._kdDomSvc.isMobileDevice();
        if (this.isMobileDevice || window.innerWidth < 481) {
            this.tooltipDisabled = true;
            this._tooltipNotDisplayed = true;
        }
    }
    ngAfterViewInit() {
        this._kdWizardSvc.direction = this._kdDomSvc.getDocumentDirection(true) || 'left';
        this._kdWizardSvc.totalSteps = this.steps.length;
        this._kdWizardSvc.setContainerAndStepElement(this.id);
    }
    ngOnDestroy() {
        this._dragMenuSub.unsubscribe();
        this._toggleMenuSub.unsubscribe();
    }
    /* user clicks and goes back to past steps */
    selectedStep(_step, e) {
        e.preventDefault();
        // if (!_step.isDisabled) {
        //     // make clicked step active
        //     this.steps[_step.id].isActive = true;
        //     // disable all future steps
        //     for (let i = _step.id + 1; i < this.steps.length; ++i) {
        //         this.steps[i].isDisabled = true;
        //         if (this.steps[i].isActive) this.steps[i].isActive = false;
        //     }
        //     this.activeStep = _step;
        //     this._kdWizardSvc.translateViewToClickedElem(this.activeStep);
        //     // update button's text. disable 'previous' button if first step, and change text of 'next' button for last step
        //     this._updateButton();
        //     // emit current step to parent component's DOM to render required content
        //     this._emitStep(_step.content);
        // }
    }
    actionClicked(_action, e) {
        e.preventDefault();
        // emit click event to outside of component, provides action type (next or previous), current step and whether this is last step
        this._kdWizardEvent.actionClicked(this.id, {
            action: _action,
            step: this.activeStep,
            isLast: this.activeStep.id === this.steps.length - 1
        });
    }
    openToottip(e) {
        e.preventDefault();
        if (this._tooltipNotDisplayed)
            return;
        if (this._kdWizardSvc.isStepOutOfBounds(e)) {
            this.tooltipDisabled = true;
        }
        else {
            this.tooltipDisabled = false;
        }
    }
    _initApi() {
        if (typeof this.api !== 'undefined') {
            this.api.updateSteps = (_action) => this._updateSteps(_action);
            this.api.enableButton = (_type) => this._enableButton(_type);
            this.api.disableButton = (_type) => this._disableButton(_type);
            this.api.getActiveStep = () => this.activeStep;
            this.api.hideButton = () => { this.isButtonHidden = true; };
            this.api.showButton = () => { this.isButtonHidden = false; };
        }
    }
    /* update Steps when validation (done by application via api) is done */
    _updateSteps(_action) {
        // broadcast 'next' button is clicked when at last step and when validation (done by application) is done
        if (this.activeStep.id === this.steps.length - 1 && _action === 'next') {
            this._kdWizardEvent.nextClickedWhenLastStep(this.id);
            return;
        }
        let index = this.activeStep.id;
        switch (_action) {
            case 'previous':
                if (index !== 0) {
                    this.steps[index - 1].isActive = true;
                    this.steps[index].isDisabled = true;
                    this.steps[index].isActive = false;
                    this.activeStep = this.steps[this.activeStep.id - 1];
                }
                break;
            case 'next':
                if (index !== this.steps.length - 1) {
                    this.steps[index].isActive = false;
                    this.steps[index + 1].isActive = true;
                    this.steps[index + 1].isDisabled = false;
                    this.activeStep = this.steps[this.activeStep.id + 1];
                }
                break;
            default:
                break;
        }
        this._kdWizardSvc.translateViewToClickedElem(this.activeStep);
        this._updateButton();
        this._emitStep(this.activeStep.content);
    }
    _emitStep(_content) {
        if (this.contentType === 'html')
            this.activeStepEmitter.emit(_content);
        if (this.contentType === 'router')
            this._router.navigateByUrl(_content);
    }
    _handleTranslateAndTooltip() {
        this._kdWizardSvc.translateViewToClickedElem(this.activeStep);
        if (!this.isMobileDevice) {
            this.tooltipDisabled = window.innerWidth > 480 ? false : true;
            this._tooltipNotDisplayed = this.tooltipDisabled;
        }
    }
    /* set the text of next and previous buttons depending on which step */
    _updateButton() {
        // disable first step's previous button
        this.isPreviousDisabled = this.activeStep.id === 0 ? true : false;
        // change text of last step's next button to 'complete'
        this.nextButtonText = this.activeStep.id === this.steps.length - 1 ? this.config.complete || 'Complete' : this.config.next || 'Next';
    }
    /* enable external components to enable or disable next and previous buttons */
    _enableButton(_type) {
        if (_type === 'previous')
            this.isPreviousDisabled = false;
        if (_type === 'next')
            this.isNextDisabled = false;
    }
    _disableButton(_type) {
        if (_type === 'previous')
            this.isPreviousDisabled = true;
        if (_type === 'next')
            this.isNextDisabled = true;
    }
}
KdWizard.decorators = [
    { type: Component, args: [{
                selector: 'kd-wizard',
                template: "<div class=\"kdx kdx-wizard\" [id]=\"id\">\r\n    <div class=\"kdx-wizard-steps-container\">\r\n        <div class=\"steps-bottom\">\r\n            <div class=\"actions-bottom\" [ngClass]='{\"actions-hide\": isButtonHidden}'>\r\n                <button class=\"btn previous-button\" [disabled]=\"isPreviousDisabled\" (click)=\"actionClicked('previous', $event)\">\r\n                    <i class=\"fa fa-caret-left previous-icon icon\"></i>\r\n                    {{config.previous || 'Previous'}}\r\n                </button>\r\n                <button class=\"btn next-button\" [disabled]=\"isNextDisabled\" (click)=\"actionClicked('next', $event)\">\r\n                    <i class=\"fa fa-caret-right next-icon icon\"></i>\r\n                    {{nextButtonText}}\r\n                </button>\r\n            </div>\r\n        </div>\r\n        \r\n        <div class=\"kdx-wizard-inner-wrapper\">\r\n            <ul>\r\n                <li [ngClass]='{\"kdx-wizard-step-selected\": step.isActive, \"step-disabled\": step.isDisabled, \"step-enabled\": !step.isDisabled}' *ngFor=\"let step of steps; let isFirst = first; let isLast = last; \">\r\n                    <a (click)='selectedStep(step, $event)' class='kdx-step-container' data-step=\"i\">\r\n                        <div class=\"kdx-step-progress-and-icon\" [ngClass]='{\"kdx-bar-hide-first\": isFirst, \"kdx-bar-hide-last\": isLast }'>\r\n                            <div class=\"kdx-step-icon\">\r\n                                <i class=\"{{step.icon}}\" *ngIf=\"step.iconType === 'icon'\"></i>\r\n                                <div class=\"kdx-step-icon-string\" *ngIf=\"step.iconType === 'number'\">{{step.icon}}</div>\r\n                            </div>\r\n                        </div>\r\n                        <div class=\"kdx-step-text\" [kd-tooltip-dir]=\"step.tooltipString\" tooltipPosition=\"bottom\" tooltipStyleClass=\"tooltip-wizard\" tooltipEvent=\"hover\" [tooltipDisabled]=\"tooltipDisabled\" [escape]=\"false\" (mouseenter)='openToottip($event)'>\r\n                            <div class=\"step-label ellipsis-wizard\" >\r\n                                {{step.label}}\r\n                            </div>\r\n                            <div class=\"step-description ellipsis-wizard\" *ngIf=\"step.description && !isMobileDevice\">\r\n                                {{step.description}}\r\n                            </div>\r\n                        </div>\r\n                    </a>\r\n                </li>\r\n            </ul>\r\n        </div>\r\n    </div>\r\n    <div class=\"steps-content\">\r\n        <div class=\"step-text-mobile\">\r\n            <div class=\"step-label-mobile\" >\r\n                {{activeStep.label}}\r\n            </div>\r\n            <div class=\"step-description-mobile\" *ngIf=\"activeStep.description\">\r\n                {{activeStep.description}}\r\n            </div>\r\n        </div>\r\n        <ng-template [ngIf]='contentType === \"text\"'>\r\n            <div class='step-content'>\r\n                <div class='step-pane'>{{activeStep.content}}</div>\r\n            </div>\r\n        </ng-template>\r\n        <ng-template [ngIf]='contentType === \"html\"'>\r\n            <ng-content></ng-content>\r\n        </ng-template>\r\n        <ng-template [ngIf]='contentType === \"router\"'>\r\n            <router-outlet></router-outlet>\r\n        </ng-template>\r\n    </div>\r\n</div>",
                encapsulation: ViewEncapsulation.None,
                providers: [KdWizardSvc, KdDomElemSvc]
            },] }
];
KdWizard.ctorParameters = () => [
    { type: Router },
    { type: KdWizardEvent },
    { type: KdWizardSvc },
    { type: KdDomElemSvc },
    { type: KdSplitterEvent }
];
KdWizard.propDecorators = {
    wizardId: [{ type: Input, args: ['id',] }],
    config: [{ type: Input }],
    contentType: [{ type: Input, args: ['type',] }],
    api: [{ type: Input }],
    activeStepEmitter: [{ type: Output }],
    onResize: [{ type: HostListener, args: ['window:resize', ['$event'],] }]
};
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoia2QtYW5ndWxhci13aXphcmQuanMiLCJzb3VyY2VSb290IjoiRDovb3BlbkVNSVMvc3R5bGVndWlkZS9pb3N0Zy1vcGVuZW1pcy1zdHlsZWd1aWRlL3Byb2plY3RzL29wZW5lbWlzLXN0eWxlZ3VpZGUtbGliL3NyYy8iLCJzb3VyY2VzIjpbImtkLWNvbXBvbmVudHMva2QtYW5ndWxhci13aXphcmQva2QtYW5ndWxhci13aXphcmQudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsT0FBTyxFQUNILFNBQVMsRUFDVCxpQkFBaUIsRUFDakIsS0FBSyxFQUdMLFlBQVksRUFDWixNQUFNLEVBQ04sWUFBWSxHQUVmLE1BQU0sZUFBZSxDQUFDO0FBQ3ZCLE9BQU8sRUFBa0IsS0FBSyxFQUFFLE1BQU0sTUFBTSxDQUFDO0FBQzdDLE9BQU8sRUFBRSxZQUFZLEVBQUUsTUFBTSxnQkFBZ0IsQ0FBQztBQUM5QyxPQUFPLEVBQUUsTUFBTSxFQUFFLE1BQU0saUJBQWlCLENBQUM7QUFDekMsT0FBTyxFQUFFLGFBQWEsRUFBRSxNQUFNLDJCQUEyQixDQUFDO0FBQzFELE9BQU8sRUFBRSxXQUFXLEVBQUUsTUFBTSx5QkFBeUIsQ0FBQztBQUN0RCxPQUFPLEVBQUUsWUFBWSxFQUFFLE1BQU0sb0JBQW9CLENBQUM7QUFDbEQsT0FBTyxFQUFFLGVBQWUsRUFBRSxNQUFNLDhCQUE4QixDQUFDO0FBOEIvRCxNQUFNLE9BQU8sUUFBUTtJQXFCakIsWUFDWSxPQUFlLEVBQ2YsY0FBNkIsRUFDN0IsWUFBeUIsRUFDekIsU0FBdUIsRUFDL0IsZ0JBQWlDO1FBSnpCLFlBQU8sR0FBUCxPQUFPLENBQVE7UUFDZixtQkFBYyxHQUFkLGNBQWMsQ0FBZTtRQUM3QixpQkFBWSxHQUFaLFlBQVksQ0FBYTtRQUN6QixjQUFTLEdBQVQsU0FBUyxDQUFjO1FBdkI1QixVQUFLLEdBQWlCLEVBQUUsQ0FBQztRQUN6QixtQkFBYyxHQUFZLEtBQUssQ0FBQztRQUNoQyx1QkFBa0IsR0FBWSxJQUFJLENBQUM7UUFDbkMsbUJBQWMsR0FBWSxLQUFLLENBQUM7UUFHaEMsb0JBQWUsR0FBWSxLQUFLLENBQUM7UUFLaEMseUJBQW9CLEdBQVksS0FBSyxDQUFDO1FBTXBDLHNCQUFpQixHQUFxQixJQUFJLFlBQVksRUFBRSxDQUFDO1FBUy9ELElBQUksQ0FBQyxZQUFZLEdBQUcsZ0JBQWdCLENBQUMsTUFBTSxFQUFFO2FBQ3hDLElBQUksQ0FDRCxZQUFZLENBQUMsR0FBRyxDQUFDLENBQ3BCO2FBQ0EsU0FBUyxDQUFDLEdBQVMsRUFBRTtZQUNsQixJQUFJLENBQUMsMEJBQTBCLEVBQUUsQ0FBQztRQUN0QyxDQUFDLENBQUMsQ0FBQztRQUVQLElBQUksQ0FBQyxjQUFjLEdBQUcsZ0JBQWdCLENBQUMsWUFBWSxFQUFFLENBQUMsU0FBUyxDQUFDLEdBQVMsRUFBRTtZQUN2RSxLQUFLLENBQUMsR0FBRyxDQUFDLENBQUMsU0FBUyxDQUFDLEdBQVMsRUFBRTtnQkFDNUIsSUFBSSxDQUFDLDBCQUEwQixFQUFFLENBQUM7WUFDdEMsQ0FBQyxDQUFDLENBQUM7UUFDUCxDQUFDLENBQUMsQ0FBQztJQUNQLENBQUM7SUFHRCxRQUFRLENBQUMsS0FBVTtRQUNmLEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FBQyxTQUFTLENBQUMsR0FBUyxFQUFFO1lBQzVCLElBQUksQ0FBQywwQkFBMEIsRUFBRSxDQUFDO1FBQ3RDLENBQUMsQ0FBQyxDQUFDO0lBQ1AsQ0FBQztJQUVELFFBQVE7UUFDSixJQUFJLENBQUMsRUFBRSxHQUFHLE9BQU8sSUFBSSxDQUFDLFFBQVEsS0FBSyxXQUFXLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQztRQUMxRSxJQUFJLENBQUMsS0FBSyxHQUFHLElBQUksQ0FBQyxZQUFZLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLENBQUM7UUFDMUQsSUFBSSxDQUFDLFFBQVEsRUFBRSxDQUFDO1FBQ2hCLElBQUksQ0FBQyxjQUFjLEdBQUcsSUFBSSxDQUFDLE1BQU0sQ0FBQyxJQUFJLElBQUksTUFBTSxDQUFDO1FBQ2pELElBQUksQ0FBQyxVQUFVLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQztRQUNoQyxJQUFJLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUM7UUFDdEMsSUFBSSxDQUFDLGNBQWMsR0FBRyxJQUFJLENBQUMsU0FBUyxDQUFDLGNBQWMsRUFBRSxDQUFDO1FBQ3RELElBQUksSUFBSSxDQUFDLGNBQWMsSUFBSSxNQUFNLENBQUMsVUFBVSxHQUFHLEdBQUcsRUFBRTtZQUNoRCxJQUFJLENBQUMsZUFBZSxHQUFHLElBQUksQ0FBQztZQUM1QixJQUFJLENBQUMsb0JBQW9CLEdBQUcsSUFBSSxDQUFDO1NBQ3BDO0lBQ0wsQ0FBQztJQUVELGVBQWU7UUFDWCxJQUFJLENBQUMsWUFBWSxDQUFDLFNBQVMsR0FBRyxJQUFJLENBQUMsU0FBUyxDQUFDLG9CQUFvQixDQUFDLElBQUksQ0FBQyxJQUFJLE1BQU0sQ0FBQztRQUNsRixJQUFJLENBQUMsWUFBWSxDQUFDLFVBQVUsR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQztRQUNqRCxJQUFJLENBQUMsWUFBWSxDQUFDLDBCQUEwQixDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsQ0FBQztJQUMxRCxDQUFDO0lBRUQsV0FBVztRQUNQLElBQUksQ0FBQyxZQUFZLENBQUMsV0FBVyxFQUFFLENBQUM7UUFDaEMsSUFBSSxDQUFDLGNBQWMsQ0FBQyxXQUFXLEVBQUUsQ0FBQztJQUN0QyxDQUFDO0lBRUQsNkNBQTZDO0lBQ3RDLFlBQVksQ0FBQyxLQUFZLEVBQUUsQ0FBUTtRQUN0QyxDQUFDLENBQUMsY0FBYyxFQUFFLENBQUM7UUFFbkIsMkJBQTJCO1FBQzNCLGtDQUFrQztRQUNsQyw0Q0FBNEM7UUFDNUMsa0NBQWtDO1FBQ2xDLCtEQUErRDtRQUMvRCwyQ0FBMkM7UUFDM0Msc0VBQXNFO1FBQ3RFLFFBQVE7UUFDUiwrQkFBK0I7UUFDL0IscUVBQXFFO1FBQ3JFLHVIQUF1SDtRQUN2SCw0QkFBNEI7UUFDNUIsZ0ZBQWdGO1FBQ2hGLHFDQUFxQztRQUNyQyxJQUFJO0lBQ1IsQ0FBQztJQUVNLGFBQWEsQ0FBQyxPQUFlLEVBQUUsQ0FBUTtRQUMxQyxDQUFDLENBQUMsY0FBYyxFQUFFLENBQUM7UUFDbkIsZ0lBQWdJO1FBQ2hJLElBQUksQ0FBQyxjQUFjLENBQUMsYUFBYSxDQUM3QixJQUFJLENBQUMsRUFBRSxFQUNQO1lBQ0ksTUFBTSxFQUFFLE9BQU87WUFDZixJQUFJLEVBQUUsSUFBSSxDQUFDLFVBQVU7WUFDckIsTUFBTSxFQUFFLElBQUksQ0FBQyxVQUFVLENBQUMsRUFBRSxLQUFLLElBQUksQ0FBQyxLQUFLLENBQUMsTUFBTSxHQUFHLENBQUM7U0FDdkQsQ0FDSixDQUFDO0lBQ04sQ0FBQztJQUVNLFdBQVcsQ0FBQyxDQUFRO1FBQ3ZCLENBQUMsQ0FBQyxjQUFjLEVBQUUsQ0FBQztRQUNuQixJQUFJLElBQUksQ0FBQyxvQkFBb0I7WUFBRSxPQUFPO1FBQ3RDLElBQUksSUFBSSxDQUFDLFlBQVksQ0FBQyxpQkFBaUIsQ0FBQyxDQUFDLENBQUMsRUFBRTtZQUN4QyxJQUFJLENBQUMsZUFBZSxHQUFHLElBQUksQ0FBQztTQUMvQjthQUFNO1lBQ0gsSUFBSSxDQUFDLGVBQWUsR0FBRyxLQUFLLENBQUM7U0FDaEM7SUFDTCxDQUFDO0lBRU8sUUFBUTtRQUNaLElBQUksT0FBTyxJQUFJLENBQUMsR0FBRyxLQUFLLFdBQVcsRUFBRTtZQUNqQyxJQUFJLENBQUMsR0FBRyxDQUFDLFdBQVcsR0FBRyxDQUFDLE9BQWUsRUFBUSxFQUFFLENBQUMsSUFBSSxDQUFDLFlBQVksQ0FBQyxPQUFPLENBQUMsQ0FBQztZQUM3RSxJQUFJLENBQUMsR0FBRyxDQUFDLFlBQVksR0FBRyxDQUFDLEtBQWEsRUFBUSxFQUFFLENBQUMsSUFBSSxDQUFDLGFBQWEsQ0FBQyxLQUFLLENBQUMsQ0FBQztZQUMzRSxJQUFJLENBQUMsR0FBRyxDQUFDLGFBQWEsR0FBRyxDQUFDLEtBQWEsRUFBUSxFQUFFLENBQUMsSUFBSSxDQUFDLGNBQWMsQ0FBQyxLQUFLLENBQUMsQ0FBQztZQUM3RSxJQUFJLENBQUMsR0FBRyxDQUFDLGFBQWEsR0FBRyxHQUFVLEVBQUUsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDO1lBQ3RELElBQUksQ0FBQyxHQUFHLENBQUMsVUFBVSxHQUFHLEdBQVMsRUFBRSxHQUFHLElBQUksQ0FBQyxjQUFjLEdBQUcsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDO1lBQ2xFLElBQUksQ0FBQyxHQUFHLENBQUMsVUFBVSxHQUFHLEdBQVMsRUFBRSxHQUFHLElBQUksQ0FBQyxjQUFjLEdBQUcsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDO1NBQ3RFO0lBQ0wsQ0FBQztJQUVELHdFQUF3RTtJQUNoRSxZQUFZLENBQUMsT0FBZTtRQUNoQyx5R0FBeUc7UUFDekcsSUFBSSxJQUFJLENBQUMsVUFBVSxDQUFDLEVBQUUsS0FBSyxJQUFJLENBQUMsS0FBSyxDQUFDLE1BQU0sR0FBRyxDQUFDLElBQUksT0FBTyxLQUFLLE1BQU0sRUFBRTtZQUNwRSxJQUFJLENBQUMsY0FBYyxDQUFDLHVCQUF1QixDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsQ0FBQztZQUNyRCxPQUFPO1NBQ1Y7UUFDRCxJQUFJLEtBQUssR0FBVyxJQUFJLENBQUMsVUFBVSxDQUFDLEVBQUUsQ0FBQztRQUN2QyxRQUFRLE9BQU8sRUFBRTtZQUNiLEtBQUssVUFBVTtnQkFDWCxJQUFJLEtBQUssS0FBSyxDQUFDLEVBQUU7b0JBQ2IsSUFBSSxDQUFDLEtBQUssQ0FBQyxLQUFLLEdBQUcsQ0FBQyxDQUFDLENBQUMsUUFBUSxHQUFHLElBQUksQ0FBQztvQkFDdEMsSUFBSSxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsQ0FBQyxVQUFVLEdBQUcsSUFBSSxDQUFDO29CQUNwQyxJQUFJLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxDQUFDLFFBQVEsR0FBRyxLQUFLLENBQUM7b0JBQ25DLElBQUksQ0FBQyxVQUFVLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLEVBQUUsR0FBRyxDQUFDLENBQUMsQ0FBQztpQkFDeEQ7Z0JBQ0QsTUFBTTtZQUNWLEtBQUssTUFBTTtnQkFDUCxJQUFJLEtBQUssS0FBSyxJQUFJLENBQUMsS0FBSyxDQUFDLE1BQU0sR0FBRyxDQUFDLEVBQUU7b0JBQ2pDLElBQUksQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLENBQUMsUUFBUSxHQUFHLEtBQUssQ0FBQztvQkFDbkMsSUFBSSxDQUFDLEtBQUssQ0FBQyxLQUFLLEdBQUcsQ0FBQyxDQUFDLENBQUMsUUFBUSxHQUFHLElBQUksQ0FBQztvQkFDdEMsSUFBSSxDQUFDLEtBQUssQ0FBQyxLQUFLLEdBQUcsQ0FBQyxDQUFDLENBQUMsVUFBVSxHQUFHLEtBQUssQ0FBQztvQkFDekMsSUFBSSxDQUFDLFVBQVUsR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsRUFBRSxHQUFHLENBQUMsQ0FBQyxDQUFDO2lCQUN4RDtnQkFDRCxNQUFNO1lBQ1Y7Z0JBQ0ksTUFBTTtTQUNiO1FBQ0QsSUFBSSxDQUFDLFlBQVksQ0FBQywwQkFBMEIsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLENBQUM7UUFDOUQsSUFBSSxDQUFDLGFBQWEsRUFBRSxDQUFDO1FBQ3JCLElBQUksQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxPQUFPLENBQUMsQ0FBQztJQUM1QyxDQUFDO0lBRU8sU0FBUyxDQUFDLFFBQVE7UUFDdEIsSUFBSSxJQUFJLENBQUMsV0FBVyxLQUFLLE1BQU07WUFBRSxJQUFJLENBQUMsaUJBQWlCLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxDQUFDO1FBQ3ZFLElBQUksSUFBSSxDQUFDLFdBQVcsS0FBSyxRQUFRO1lBQUUsSUFBSSxDQUFDLE9BQU8sQ0FBQyxhQUFhLENBQUMsUUFBUSxDQUFDLENBQUM7SUFDNUUsQ0FBQztJQUVPLDBCQUEwQjtRQUM5QixJQUFJLENBQUMsWUFBWSxDQUFDLDBCQUEwQixDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsQ0FBQztRQUM5RCxJQUFJLENBQUMsSUFBSSxDQUFDLGNBQWMsRUFBRTtZQUN0QixJQUFJLENBQUMsZUFBZSxHQUFHLE1BQU0sQ0FBQyxVQUFVLEdBQUcsR0FBRyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQztZQUM5RCxJQUFJLENBQUMsb0JBQW9CLEdBQUcsSUFBSSxDQUFDLGVBQWUsQ0FBQztTQUNwRDtJQUNMLENBQUM7SUFFRCx1RUFBdUU7SUFDL0QsYUFBYTtRQUNqQix1Q0FBdUM7UUFDdkMsSUFBSSxDQUFDLGtCQUFrQixHQUFHLElBQUksQ0FBQyxVQUFVLENBQUMsRUFBRSxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUM7UUFFbEUsdURBQXVEO1FBQ3ZELElBQUksQ0FBQyxjQUFjLEdBQUcsSUFBSSxDQUFDLFVBQVUsQ0FBQyxFQUFFLEtBQUssSUFBSSxDQUFDLEtBQUssQ0FBQyxNQUFNLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLFFBQVEsSUFBSSxVQUFVLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsSUFBSSxJQUFJLE1BQU0sQ0FBQztJQUN6SSxDQUFDO0lBRUQsK0VBQStFO0lBQ3ZFLGFBQWEsQ0FBQyxLQUFhO1FBQy9CLElBQUksS0FBSyxLQUFLLFVBQVU7WUFBRSxJQUFJLENBQUMsa0JBQWtCLEdBQUcsS0FBSyxDQUFDO1FBQzFELElBQUksS0FBSyxLQUFLLE1BQU07WUFBRSxJQUFJLENBQUMsY0FBYyxHQUFHLEtBQUssQ0FBQztJQUN0RCxDQUFDO0lBRU8sY0FBYyxDQUFDLEtBQWE7UUFDaEMsSUFBSSxLQUFLLEtBQUssVUFBVTtZQUFFLElBQUksQ0FBQyxrQkFBa0IsR0FBRyxJQUFJLENBQUM7UUFDekQsSUFBSSxLQUFLLEtBQUssTUFBTTtZQUFFLElBQUksQ0FBQyxjQUFjLEdBQUcsSUFBSSxDQUFDO0lBQ3JELENBQUM7OztZQXpNSixTQUFTLFNBQUM7Z0JBQ1AsUUFBUSxFQUFFLFdBQVc7Z0JBQ3JCLHMzR0FBdUM7Z0JBQ3ZDLGFBQWEsRUFBRSxpQkFBaUIsQ0FBQyxJQUFJO2dCQUNyQyxTQUFTLEVBQUUsQ0FBQyxXQUFXLEVBQUUsWUFBWSxDQUFDO2FBQ3pDOzs7WUFoQ1EsTUFBTTtZQUNOLGFBQWE7WUFDYixXQUFXO1lBQ1gsWUFBWTtZQUNaLGVBQWU7Ozt1QkE2Q25CLEtBQUssU0FBQyxJQUFJO3FCQUNWLEtBQUs7MEJBQ0wsS0FBSyxTQUFDLE1BQU07a0JBQ1osS0FBSztnQ0FDTCxNQUFNO3VCQXdCTixZQUFZLFNBQUMsZUFBZSxFQUFFLENBQUMsUUFBUSxDQUFDIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHtcclxuICAgIENvbXBvbmVudCxcclxuICAgIFZpZXdFbmNhcHN1bGF0aW9uLFxyXG4gICAgSW5wdXQsXHJcbiAgICBPbkluaXQsXHJcbiAgICBPbkRlc3Ryb3ksXHJcbiAgICBIb3N0TGlzdGVuZXIsXHJcbiAgICBPdXRwdXQsXHJcbiAgICBFdmVudEVtaXR0ZXIsXHJcbiAgICBBZnRlclZpZXdJbml0LFxyXG59IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xyXG5pbXBvcnQgeyBTdWJzY3JpcHRpb24gLCAgdGltZXIgfSBmcm9tICdyeGpzJztcclxuaW1wb3J0IHsgZGVib3VuY2VUaW1lIH0gZnJvbSAncnhqcy9vcGVyYXRvcnMnO1xyXG5pbXBvcnQgeyBSb3V0ZXIgfSBmcm9tICdAYW5ndWxhci9yb3V0ZXInO1xyXG5pbXBvcnQgeyBLZFdpemFyZEV2ZW50IH0gZnJvbSAnLi9rZC1hbmd1bGFyLXdpemFyZC1ldmVudCc7XHJcbmltcG9ydCB7IEtkV2l6YXJkU3ZjIH0gZnJvbSAnLi9rZC1hbmd1bGFyLXdpemFyZC1zdmMnO1xyXG5pbXBvcnQgeyBLZERvbUVsZW1TdmMgfSBmcm9tICcuLi9rZC1jb21tb24vaW5kZXgnO1xyXG5pbXBvcnQgeyBLZFNwbGl0dGVyRXZlbnQgfSBmcm9tICcuLi9rZC1hbmd1bGFyLXNwbGl0dGVyL2luZGV4JztcclxuXHJcbmV4cG9ydCBpbnRlcmZhY2UgSVN0ZXAge1xyXG4gICAgaWQ6IG51bWJlcjtcclxuICAgIGxhYmVsOiBzdHJpbmc7XHJcbiAgICBjb250ZW50OiBzdHJpbmc7XHJcbiAgICBkZXNjcmlwdGlvbj86IHN0cmluZztcclxuICAgIGljb246IHN0cmluZztcclxuICAgIGljb25UeXBlOiBzdHJpbmc7XHJcbiAgICBpc0FjdGl2ZTogYm9vbGVhbjtcclxuICAgIGlzRGlzYWJsZWQ6IGJvb2xlYW47XHJcbiAgICB0b29sdGlwU3RyaW5nOiBzdHJpbmc7XHJcbn1cclxuXHJcbmV4cG9ydCBpbnRlcmZhY2UgSVdpemFyZEFwaSB7XHJcbiAgICB1cGRhdGVTdGVwcz86IChfYWN0aW9uOiBzdHJpbmcpID0+IHZvaWQ7XHJcbiAgICBlbmFibGVCdXR0b24/OiAoX3R5cGU6IHN0cmluZykgPT4gdm9pZDtcclxuICAgIGRpc2FibGVCdXR0b24/OiAoX3R5cGU6IHN0cmluZykgPT4gdm9pZDtcclxuICAgIGdldEFjdGl2ZVN0ZXA/OiAoKSA9PiBJU3RlcDtcclxuICAgIGhpZGVCdXR0b24/OiAoKSA9PiB2b2lkO1xyXG4gICAgc2hvd0J1dHRvbj86ICgpID0+IHZvaWQ7XHJcbn1cclxuXHJcbkBDb21wb25lbnQoe1xyXG4gICAgc2VsZWN0b3I6ICdrZC13aXphcmQnLFxyXG4gICAgdGVtcGxhdGVVcmw6ICcuL2tkLWFuZ3VsYXItd2l6YXJkLmh0bWwnLFxyXG4gICAgZW5jYXBzdWxhdGlvbjogVmlld0VuY2Fwc3VsYXRpb24uTm9uZSxcclxuICAgIHByb3ZpZGVyczogW0tkV2l6YXJkU3ZjLCBLZERvbUVsZW1TdmNdXHJcbn0pXHJcblxyXG5leHBvcnQgY2xhc3MgS2RXaXphcmQgaW1wbGVtZW50cyBPbkluaXQsIEFmdGVyVmlld0luaXQsIE9uRGVzdHJveSB7XHJcbiAgICBwdWJsaWMgaWQ6IHN0cmluZztcclxuICAgIHB1YmxpYyBzdGVwczogQXJyYXk8SVN0ZXA+ID0gW107XHJcbiAgICBwdWJsaWMgaXNCdXR0b25IaWRkZW46IGJvb2xlYW4gPSBmYWxzZTtcclxuICAgIHB1YmxpYyBpc1ByZXZpb3VzRGlzYWJsZWQ6IGJvb2xlYW4gPSB0cnVlO1xyXG4gICAgcHVibGljIGlzTmV4dERpc2FibGVkOiBib29sZWFuID0gZmFsc2U7XHJcbiAgICBwdWJsaWMgbmV4dEJ1dHRvblRleHQ6IHN0cmluZztcclxuICAgIHB1YmxpYyBhY3RpdmVTdGVwOiBJU3RlcDtcclxuICAgIHB1YmxpYyB0b29sdGlwRGlzYWJsZWQ6IGJvb2xlYW4gPSBmYWxzZTtcclxuICAgIHB1YmxpYyBpc01vYmlsZURldmljZTogYm9vbGVhbjtcclxuXHJcbiAgICBwcml2YXRlIF9kcmFnTWVudVN1YjogU3Vic2NyaXB0aW9uO1xyXG4gICAgcHJpdmF0ZSBfdG9nZ2xlTWVudVN1YjogU3Vic2NyaXB0aW9uO1xyXG4gICAgcHJpdmF0ZSBfdG9vbHRpcE5vdERpc3BsYXllZDogYm9vbGVhbiA9IGZhbHNlO1xyXG5cclxuICAgIEBJbnB1dCgnaWQnKSB3aXphcmRJZDogc3RyaW5nO1xyXG4gICAgQElucHV0KCkgY29uZmlnOiBhbnk7XHJcbiAgICBASW5wdXQoJ3R5cGUnKSBjb250ZW50VHlwZTogc3RyaW5nO1xyXG4gICAgQElucHV0KCkgYXBpOiBJV2l6YXJkQXBpO1xyXG4gICAgQE91dHB1dCgpIGFjdGl2ZVN0ZXBFbWl0dGVyOiBFdmVudEVtaXR0ZXI8e30+ID0gbmV3IEV2ZW50RW1pdHRlcigpO1xyXG5cclxuICAgIGNvbnN0cnVjdG9yKFxyXG4gICAgICAgIHByaXZhdGUgX3JvdXRlcjogUm91dGVyLFxyXG4gICAgICAgIHByaXZhdGUgX2tkV2l6YXJkRXZlbnQ6IEtkV2l6YXJkRXZlbnQsXHJcbiAgICAgICAgcHJpdmF0ZSBfa2RXaXphcmRTdmM6IEtkV2l6YXJkU3ZjLFxyXG4gICAgICAgIHByaXZhdGUgX2tkRG9tU3ZjOiBLZERvbUVsZW1TdmMsXHJcbiAgICAgICAgX2tkU3BsaXR0ZXJFdmVudDogS2RTcGxpdHRlckV2ZW50LFxyXG4gICAgKSB7XHJcbiAgICAgICAgdGhpcy5fZHJhZ01lbnVTdWIgPSBfa2RTcGxpdHRlckV2ZW50Lm9uRHJhZygpXHJcbiAgICAgICAgICAgIC5waXBlKFxyXG4gICAgICAgICAgICAgICAgZGVib3VuY2VUaW1lKDEwMClcclxuICAgICAgICAgICAgKVxyXG4gICAgICAgICAgICAuc3Vic2NyaWJlKCgpOiB2b2lkID0+IHtcclxuICAgICAgICAgICAgICAgIHRoaXMuX2hhbmRsZVRyYW5zbGF0ZUFuZFRvb2x0aXAoKTtcclxuICAgICAgICAgICAgfSk7XHJcblxyXG4gICAgICAgIHRoaXMuX3RvZ2dsZU1lbnVTdWIgPSBfa2RTcGxpdHRlckV2ZW50Lm9uVG9nZ2xlTWVudSgpLnN1YnNjcmliZSgoKTogdm9pZCA9PiB7XHJcbiAgICAgICAgICAgIHRpbWVyKDUwMCkuc3Vic2NyaWJlKCgpOiB2b2lkID0+IHtcclxuICAgICAgICAgICAgICAgIHRoaXMuX2hhbmRsZVRyYW5zbGF0ZUFuZFRvb2x0aXAoKTtcclxuICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgfSk7XHJcbiAgICB9XHJcblxyXG4gICAgQEhvc3RMaXN0ZW5lcignd2luZG93OnJlc2l6ZScsIFsnJGV2ZW50J10pXHJcbiAgICBvblJlc2l6ZShldmVudDogYW55KTogdm9pZCB7XHJcbiAgICAgICAgdGltZXIoMjAwKS5zdWJzY3JpYmUoKCk6IHZvaWQgPT4ge1xyXG4gICAgICAgICAgICB0aGlzLl9oYW5kbGVUcmFuc2xhdGVBbmRUb29sdGlwKCk7XHJcbiAgICAgICAgfSk7XHJcbiAgICB9XHJcblxyXG4gICAgbmdPbkluaXQoKTogdm9pZCB7XHJcbiAgICAgICAgdGhpcy5pZCA9IHR5cGVvZiB0aGlzLndpemFyZElkID09PSAndW5kZWZpbmVkJyA/ICd3aXphcmQnIDogdGhpcy53aXphcmRJZDtcclxuICAgICAgICB0aGlzLnN0ZXBzID0gdGhpcy5fa2RXaXphcmRTdmMuc2V0SXRlbSh0aGlzLmNvbmZpZy5zdGVwcyk7XHJcbiAgICAgICAgdGhpcy5faW5pdEFwaSgpO1xyXG4gICAgICAgIHRoaXMubmV4dEJ1dHRvblRleHQgPSB0aGlzLmNvbmZpZy5uZXh0IHx8ICdOZXh0JztcclxuICAgICAgICB0aGlzLmFjdGl2ZVN0ZXAgPSB0aGlzLnN0ZXBzWzBdO1xyXG4gICAgICAgIHRoaXMuX2VtaXRTdGVwKHRoaXMuc3RlcHNbMF0uY29udGVudCk7XHJcbiAgICAgICAgdGhpcy5pc01vYmlsZURldmljZSA9IHRoaXMuX2tkRG9tU3ZjLmlzTW9iaWxlRGV2aWNlKCk7XHJcbiAgICAgICAgaWYgKHRoaXMuaXNNb2JpbGVEZXZpY2UgfHwgd2luZG93LmlubmVyV2lkdGggPCA0ODEpIHtcclxuICAgICAgICAgICAgdGhpcy50b29sdGlwRGlzYWJsZWQgPSB0cnVlO1xyXG4gICAgICAgICAgICB0aGlzLl90b29sdGlwTm90RGlzcGxheWVkID0gdHJ1ZTtcclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgbmdBZnRlclZpZXdJbml0KCk6IHZvaWQge1xyXG4gICAgICAgIHRoaXMuX2tkV2l6YXJkU3ZjLmRpcmVjdGlvbiA9IHRoaXMuX2tkRG9tU3ZjLmdldERvY3VtZW50RGlyZWN0aW9uKHRydWUpIHx8ICdsZWZ0JztcclxuICAgICAgICB0aGlzLl9rZFdpemFyZFN2Yy50b3RhbFN0ZXBzID0gdGhpcy5zdGVwcy5sZW5ndGg7XHJcbiAgICAgICAgdGhpcy5fa2RXaXphcmRTdmMuc2V0Q29udGFpbmVyQW5kU3RlcEVsZW1lbnQodGhpcy5pZCk7XHJcbiAgICB9XHJcblxyXG4gICAgbmdPbkRlc3Ryb3koKTogdm9pZCB7XHJcbiAgICAgICAgdGhpcy5fZHJhZ01lbnVTdWIudW5zdWJzY3JpYmUoKTtcclxuICAgICAgICB0aGlzLl90b2dnbGVNZW51U3ViLnVuc3Vic2NyaWJlKCk7XHJcbiAgICB9XHJcblxyXG4gICAgLyogdXNlciBjbGlja3MgYW5kIGdvZXMgYmFjayB0byBwYXN0IHN0ZXBzICovXHJcbiAgICBwdWJsaWMgc2VsZWN0ZWRTdGVwKF9zdGVwOiBJU3RlcCwgZTogRXZlbnQpOiB2b2lkIHtcclxuICAgICAgICBlLnByZXZlbnREZWZhdWx0KCk7XHJcbiAgICAgICAgXHJcbiAgICAgICAgLy8gaWYgKCFfc3RlcC5pc0Rpc2FibGVkKSB7XHJcbiAgICAgICAgLy8gICAgIC8vIG1ha2UgY2xpY2tlZCBzdGVwIGFjdGl2ZVxyXG4gICAgICAgIC8vICAgICB0aGlzLnN0ZXBzW19zdGVwLmlkXS5pc0FjdGl2ZSA9IHRydWU7XHJcbiAgICAgICAgLy8gICAgIC8vIGRpc2FibGUgYWxsIGZ1dHVyZSBzdGVwc1xyXG4gICAgICAgIC8vICAgICBmb3IgKGxldCBpID0gX3N0ZXAuaWQgKyAxOyBpIDwgdGhpcy5zdGVwcy5sZW5ndGg7ICsraSkge1xyXG4gICAgICAgIC8vICAgICAgICAgdGhpcy5zdGVwc1tpXS5pc0Rpc2FibGVkID0gdHJ1ZTtcclxuICAgICAgICAvLyAgICAgICAgIGlmICh0aGlzLnN0ZXBzW2ldLmlzQWN0aXZlKSB0aGlzLnN0ZXBzW2ldLmlzQWN0aXZlID0gZmFsc2U7XHJcbiAgICAgICAgLy8gICAgIH1cclxuICAgICAgICAvLyAgICAgdGhpcy5hY3RpdmVTdGVwID0gX3N0ZXA7XHJcbiAgICAgICAgLy8gICAgIHRoaXMuX2tkV2l6YXJkU3ZjLnRyYW5zbGF0ZVZpZXdUb0NsaWNrZWRFbGVtKHRoaXMuYWN0aXZlU3RlcCk7XHJcbiAgICAgICAgLy8gICAgIC8vIHVwZGF0ZSBidXR0b24ncyB0ZXh0LiBkaXNhYmxlICdwcmV2aW91cycgYnV0dG9uIGlmIGZpcnN0IHN0ZXAsIGFuZCBjaGFuZ2UgdGV4dCBvZiAnbmV4dCcgYnV0dG9uIGZvciBsYXN0IHN0ZXBcclxuICAgICAgICAvLyAgICAgdGhpcy5fdXBkYXRlQnV0dG9uKCk7XHJcbiAgICAgICAgLy8gICAgIC8vIGVtaXQgY3VycmVudCBzdGVwIHRvIHBhcmVudCBjb21wb25lbnQncyBET00gdG8gcmVuZGVyIHJlcXVpcmVkIGNvbnRlbnRcclxuICAgICAgICAvLyAgICAgdGhpcy5fZW1pdFN0ZXAoX3N0ZXAuY29udGVudCk7XHJcbiAgICAgICAgLy8gfVxyXG4gICAgfVxyXG5cclxuICAgIHB1YmxpYyBhY3Rpb25DbGlja2VkKF9hY3Rpb246IHN0cmluZywgZTogRXZlbnQpOiB2b2lkIHtcclxuICAgICAgICBlLnByZXZlbnREZWZhdWx0KCk7XHJcbiAgICAgICAgLy8gZW1pdCBjbGljayBldmVudCB0byBvdXRzaWRlIG9mIGNvbXBvbmVudCwgcHJvdmlkZXMgYWN0aW9uIHR5cGUgKG5leHQgb3IgcHJldmlvdXMpLCBjdXJyZW50IHN0ZXAgYW5kIHdoZXRoZXIgdGhpcyBpcyBsYXN0IHN0ZXBcclxuICAgICAgICB0aGlzLl9rZFdpemFyZEV2ZW50LmFjdGlvbkNsaWNrZWQoXHJcbiAgICAgICAgICAgIHRoaXMuaWQsXHJcbiAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICAgIGFjdGlvbjogX2FjdGlvbixcclxuICAgICAgICAgICAgICAgIHN0ZXA6IHRoaXMuYWN0aXZlU3RlcCxcclxuICAgICAgICAgICAgICAgIGlzTGFzdDogdGhpcy5hY3RpdmVTdGVwLmlkID09PSB0aGlzLnN0ZXBzLmxlbmd0aCAtIDFcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICk7XHJcbiAgICB9XHJcblxyXG4gICAgcHVibGljIG9wZW5Ub290dGlwKGU6IEV2ZW50KTogdm9pZCB7XHJcbiAgICAgICAgZS5wcmV2ZW50RGVmYXVsdCgpO1xyXG4gICAgICAgIGlmICh0aGlzLl90b29sdGlwTm90RGlzcGxheWVkKSByZXR1cm47XHJcbiAgICAgICAgaWYgKHRoaXMuX2tkV2l6YXJkU3ZjLmlzU3RlcE91dE9mQm91bmRzKGUpKSB7XHJcbiAgICAgICAgICAgIHRoaXMudG9vbHRpcERpc2FibGVkID0gdHJ1ZTtcclxuICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICB0aGlzLnRvb2x0aXBEaXNhYmxlZCA9IGZhbHNlO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF9pbml0QXBpKCk6IHZvaWQge1xyXG4gICAgICAgIGlmICh0eXBlb2YgdGhpcy5hcGkgIT09ICd1bmRlZmluZWQnKSB7XHJcbiAgICAgICAgICAgIHRoaXMuYXBpLnVwZGF0ZVN0ZXBzID0gKF9hY3Rpb246IHN0cmluZyk6IHZvaWQgPT4gdGhpcy5fdXBkYXRlU3RlcHMoX2FjdGlvbik7XHJcbiAgICAgICAgICAgIHRoaXMuYXBpLmVuYWJsZUJ1dHRvbiA9IChfdHlwZTogc3RyaW5nKTogdm9pZCA9PiB0aGlzLl9lbmFibGVCdXR0b24oX3R5cGUpO1xyXG4gICAgICAgICAgICB0aGlzLmFwaS5kaXNhYmxlQnV0dG9uID0gKF90eXBlOiBzdHJpbmcpOiB2b2lkID0+IHRoaXMuX2Rpc2FibGVCdXR0b24oX3R5cGUpO1xyXG4gICAgICAgICAgICB0aGlzLmFwaS5nZXRBY3RpdmVTdGVwID0gKCk6IElTdGVwID0+IHRoaXMuYWN0aXZlU3RlcDtcclxuICAgICAgICAgICAgdGhpcy5hcGkuaGlkZUJ1dHRvbiA9ICgpOiB2b2lkID0+IHsgdGhpcy5pc0J1dHRvbkhpZGRlbiA9IHRydWU7IH07XHJcbiAgICAgICAgICAgIHRoaXMuYXBpLnNob3dCdXR0b24gPSAoKTogdm9pZCA9PiB7IHRoaXMuaXNCdXR0b25IaWRkZW4gPSBmYWxzZTsgfTtcclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgLyogdXBkYXRlIFN0ZXBzIHdoZW4gdmFsaWRhdGlvbiAoZG9uZSBieSBhcHBsaWNhdGlvbiB2aWEgYXBpKSBpcyBkb25lICovXHJcbiAgICBwcml2YXRlIF91cGRhdGVTdGVwcyhfYWN0aW9uOiBzdHJpbmcpOiB2b2lkIHtcclxuICAgICAgICAvLyBicm9hZGNhc3QgJ25leHQnIGJ1dHRvbiBpcyBjbGlja2VkIHdoZW4gYXQgbGFzdCBzdGVwIGFuZCB3aGVuIHZhbGlkYXRpb24gKGRvbmUgYnkgYXBwbGljYXRpb24pIGlzIGRvbmVcclxuICAgICAgICBpZiAodGhpcy5hY3RpdmVTdGVwLmlkID09PSB0aGlzLnN0ZXBzLmxlbmd0aCAtIDEgJiYgX2FjdGlvbiA9PT0gJ25leHQnKSB7XHJcbiAgICAgICAgICAgIHRoaXMuX2tkV2l6YXJkRXZlbnQubmV4dENsaWNrZWRXaGVuTGFzdFN0ZXAodGhpcy5pZCk7XHJcbiAgICAgICAgICAgIHJldHVybjtcclxuICAgICAgICB9XHJcbiAgICAgICAgbGV0IGluZGV4OiBudW1iZXIgPSB0aGlzLmFjdGl2ZVN0ZXAuaWQ7XHJcbiAgICAgICAgc3dpdGNoIChfYWN0aW9uKSB7XHJcbiAgICAgICAgICAgIGNhc2UgJ3ByZXZpb3VzJzpcclxuICAgICAgICAgICAgICAgIGlmIChpbmRleCAhPT0gMCkge1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuc3RlcHNbaW5kZXggLSAxXS5pc0FjdGl2ZSA9IHRydWU7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5zdGVwc1tpbmRleF0uaXNEaXNhYmxlZCA9IHRydWU7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5zdGVwc1tpbmRleF0uaXNBY3RpdmUgPSBmYWxzZTtcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLmFjdGl2ZVN0ZXAgPSB0aGlzLnN0ZXBzW3RoaXMuYWN0aXZlU3RlcC5pZCAtIDFdO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgICAgIGNhc2UgJ25leHQnOlxyXG4gICAgICAgICAgICAgICAgaWYgKGluZGV4ICE9PSB0aGlzLnN0ZXBzLmxlbmd0aCAtIDEpIHtcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLnN0ZXBzW2luZGV4XS5pc0FjdGl2ZSA9IGZhbHNlO1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuc3RlcHNbaW5kZXggKyAxXS5pc0FjdGl2ZSA9IHRydWU7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5zdGVwc1tpbmRleCArIDFdLmlzRGlzYWJsZWQgPSBmYWxzZTtcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLmFjdGl2ZVN0ZXAgPSB0aGlzLnN0ZXBzW3RoaXMuYWN0aXZlU3RlcC5pZCArIDFdO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgICAgIGRlZmF1bHQ6XHJcbiAgICAgICAgICAgICAgICBicmVhaztcclxuICAgICAgICB9XHJcbiAgICAgICAgdGhpcy5fa2RXaXphcmRTdmMudHJhbnNsYXRlVmlld1RvQ2xpY2tlZEVsZW0odGhpcy5hY3RpdmVTdGVwKTtcclxuICAgICAgICB0aGlzLl91cGRhdGVCdXR0b24oKTtcclxuICAgICAgICB0aGlzLl9lbWl0U3RlcCh0aGlzLmFjdGl2ZVN0ZXAuY29udGVudCk7XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfZW1pdFN0ZXAoX2NvbnRlbnQpOiB2b2lkIHtcclxuICAgICAgICBpZiAodGhpcy5jb250ZW50VHlwZSA9PT0gJ2h0bWwnKSB0aGlzLmFjdGl2ZVN0ZXBFbWl0dGVyLmVtaXQoX2NvbnRlbnQpO1xyXG4gICAgICAgIGlmICh0aGlzLmNvbnRlbnRUeXBlID09PSAncm91dGVyJykgdGhpcy5fcm91dGVyLm5hdmlnYXRlQnlVcmwoX2NvbnRlbnQpO1xyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX2hhbmRsZVRyYW5zbGF0ZUFuZFRvb2x0aXAoKTogdm9pZCB7XHJcbiAgICAgICAgdGhpcy5fa2RXaXphcmRTdmMudHJhbnNsYXRlVmlld1RvQ2xpY2tlZEVsZW0odGhpcy5hY3RpdmVTdGVwKTtcclxuICAgICAgICBpZiAoIXRoaXMuaXNNb2JpbGVEZXZpY2UpIHtcclxuICAgICAgICAgICAgdGhpcy50b29sdGlwRGlzYWJsZWQgPSB3aW5kb3cuaW5uZXJXaWR0aCA+IDQ4MCA/IGZhbHNlIDogdHJ1ZTtcclxuICAgICAgICAgICAgdGhpcy5fdG9vbHRpcE5vdERpc3BsYXllZCA9IHRoaXMudG9vbHRpcERpc2FibGVkO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICAvKiBzZXQgdGhlIHRleHQgb2YgbmV4dCBhbmQgcHJldmlvdXMgYnV0dG9ucyBkZXBlbmRpbmcgb24gd2hpY2ggc3RlcCAqL1xyXG4gICAgcHJpdmF0ZSBfdXBkYXRlQnV0dG9uKCk6IHZvaWQge1xyXG4gICAgICAgIC8vIGRpc2FibGUgZmlyc3Qgc3RlcCdzIHByZXZpb3VzIGJ1dHRvblxyXG4gICAgICAgIHRoaXMuaXNQcmV2aW91c0Rpc2FibGVkID0gdGhpcy5hY3RpdmVTdGVwLmlkID09PSAwID8gdHJ1ZSA6IGZhbHNlO1xyXG5cclxuICAgICAgICAvLyBjaGFuZ2UgdGV4dCBvZiBsYXN0IHN0ZXAncyBuZXh0IGJ1dHRvbiB0byAnY29tcGxldGUnXHJcbiAgICAgICAgdGhpcy5uZXh0QnV0dG9uVGV4dCA9IHRoaXMuYWN0aXZlU3RlcC5pZCA9PT0gdGhpcy5zdGVwcy5sZW5ndGggLSAxID8gdGhpcy5jb25maWcuY29tcGxldGUgfHwgJ0NvbXBsZXRlJyA6IHRoaXMuY29uZmlnLm5leHQgfHwgJ05leHQnO1xyXG4gICAgfVxyXG5cclxuICAgIC8qIGVuYWJsZSBleHRlcm5hbCBjb21wb25lbnRzIHRvIGVuYWJsZSBvciBkaXNhYmxlIG5leHQgYW5kIHByZXZpb3VzIGJ1dHRvbnMgKi9cclxuICAgIHByaXZhdGUgX2VuYWJsZUJ1dHRvbihfdHlwZTogc3RyaW5nKTogdm9pZCB7XHJcbiAgICAgICAgaWYgKF90eXBlID09PSAncHJldmlvdXMnKSB0aGlzLmlzUHJldmlvdXNEaXNhYmxlZCA9IGZhbHNlO1xyXG4gICAgICAgIGlmIChfdHlwZSA9PT0gJ25leHQnKSB0aGlzLmlzTmV4dERpc2FibGVkID0gZmFsc2U7XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfZGlzYWJsZUJ1dHRvbihfdHlwZTogc3RyaW5nKTogdm9pZCB7XHJcbiAgICAgICAgaWYgKF90eXBlID09PSAncHJldmlvdXMnKSB0aGlzLmlzUHJldmlvdXNEaXNhYmxlZCA9IHRydWU7XHJcbiAgICAgICAgaWYgKF90eXBlID09PSAnbmV4dCcpIHRoaXMuaXNOZXh0RGlzYWJsZWQgPSB0cnVlO1xyXG4gICAgfVxyXG59XHJcbiJdfQ==