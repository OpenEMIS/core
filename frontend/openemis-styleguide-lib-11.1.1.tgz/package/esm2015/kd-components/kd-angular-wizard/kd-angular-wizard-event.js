import { Injectable } from '@angular/core';
import { KdBroadcaster } from '../kd-common/index';
import * as i0 from "@angular/core";
import * as i1 from "../kd-common/kd-broadcaster-svc";
export class KdWizardEvent {
    constructor(_broadcaster) {
        this._broadcaster = _broadcaster;
    }
    actionClicked(_wizardId, _event) {
        this._broadcaster.broadcast(_wizardId + 'KdWizardActionClicked', _event);
    }
    onActionClicked(_wizardId) {
        return this._broadcaster.on(_wizardId + 'KdWizardActionClicked');
    }
    nextClickedWhenLastStep(_wizardId, _event) {
        this._broadcaster.broadcast(_wizardId + 'KdWizardLastStepReached', _event);
    }
    onNextClickedWhenLastStep(_wizardId) {
        return this._broadcaster.on(_wizardId + 'KdWizardLastStepReached');
    }
}
KdWizardEvent.ɵprov = i0.ɵɵdefineInjectable({ factory: function KdWizardEvent_Factory() { return new KdWizardEvent(i0.ɵɵinject(i1.KdBroadcaster)); }, token: KdWizardEvent, providedIn: "root" });
KdWizardEvent.decorators = [
    { type: Injectable, args: [{
                providedIn: 'root'
            },] }
];
KdWizardEvent.ctorParameters = () => [
    { type: KdBroadcaster }
];
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoia2QtYW5ndWxhci13aXphcmQtZXZlbnQuanMiLCJzb3VyY2VSb290IjoiRDovb3BlbkVNSVMvc3R5bGVndWlkZS9pb3N0Zy1vcGVuZW1pcy1zdHlsZWd1aWRlL3Byb2plY3RzL29wZW5lbWlzLXN0eWxlZ3VpZGUtbGliL3NyYy8iLCJzb3VyY2VzIjpbImtkLWNvbXBvbmVudHMva2QtYW5ndWxhci13aXphcmQva2QtYW5ndWxhci13aXphcmQtZXZlbnQudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsT0FBTyxFQUFFLFVBQVUsRUFBRSxNQUFNLGVBQWUsQ0FBQztBQUczQyxPQUFPLEVBQUUsYUFBYSxFQUFFLE1BQU0sb0JBQW9CLENBQUM7OztBQUtuRCxNQUFNLE9BQU8sYUFBYTtJQUN0QixZQUNZLFlBQTJCO1FBQTNCLGlCQUFZLEdBQVosWUFBWSxDQUFlO0lBQ25DLENBQUM7SUFFRSxhQUFhLENBQUMsU0FBaUIsRUFBRSxNQUFZO1FBQ2hELElBQUksQ0FBQyxZQUFZLENBQUMsU0FBUyxDQUFDLFNBQVMsR0FBRyx1QkFBdUIsRUFBRSxNQUFNLENBQUMsQ0FBQztJQUM3RSxDQUFDO0lBRU0sZUFBZSxDQUFDLFNBQWlCO1FBQ3BDLE9BQU8sSUFBSSxDQUFDLFlBQVksQ0FBQyxFQUFFLENBQU0sU0FBUyxHQUFHLHVCQUF1QixDQUFDLENBQUM7SUFDMUUsQ0FBQztJQUVNLHVCQUF1QixDQUFDLFNBQWlCLEVBQUUsTUFBWTtRQUMxRCxJQUFJLENBQUMsWUFBWSxDQUFDLFNBQVMsQ0FBQyxTQUFTLEdBQUcseUJBQXlCLEVBQUUsTUFBTSxDQUFDLENBQUM7SUFDL0UsQ0FBQztJQUVNLHlCQUF5QixDQUFDLFNBQWlCO1FBQzlDLE9BQU8sSUFBSSxDQUFDLFlBQVksQ0FBQyxFQUFFLENBQU0sU0FBUyxHQUFHLHlCQUF5QixDQUFDLENBQUM7SUFDNUUsQ0FBQzs7OztZQXRCSixVQUFVLFNBQUM7Z0JBQ1IsVUFBVSxFQUFFLE1BQU07YUFDckI7OztZQUpRLGFBQWEiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBJbmplY3RhYmxlIH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XHJcbmltcG9ydCB7IE9ic2VydmFibGUgfSBmcm9tICdyeGpzJztcclxuXHJcbmltcG9ydCB7IEtkQnJvYWRjYXN0ZXIgfSBmcm9tICcuLi9rZC1jb21tb24vaW5kZXgnO1xyXG5cclxuQEluamVjdGFibGUoe1xyXG4gICAgcHJvdmlkZWRJbjogJ3Jvb3QnXHJcbn0pXHJcbmV4cG9ydCBjbGFzcyBLZFdpemFyZEV2ZW50IHtcclxuICAgIGNvbnN0cnVjdG9yKFxyXG4gICAgICAgIHByaXZhdGUgX2Jyb2FkY2FzdGVyOiBLZEJyb2FkY2FzdGVyXHJcbiAgICApIHsgfVxyXG5cclxuICAgIHB1YmxpYyBhY3Rpb25DbGlja2VkKF93aXphcmRJZDogc3RyaW5nLCBfZXZlbnQ/OiBhbnkpOiB2b2lkIHtcclxuICAgICAgICB0aGlzLl9icm9hZGNhc3Rlci5icm9hZGNhc3QoX3dpemFyZElkICsgJ0tkV2l6YXJkQWN0aW9uQ2xpY2tlZCcsIF9ldmVudCk7XHJcbiAgICB9XHJcblxyXG4gICAgcHVibGljIG9uQWN0aW9uQ2xpY2tlZChfd2l6YXJkSWQ6IHN0cmluZyk6IE9ic2VydmFibGU8YW55PiB7XHJcbiAgICAgICAgcmV0dXJuIHRoaXMuX2Jyb2FkY2FzdGVyLm9uPGFueT4oX3dpemFyZElkICsgJ0tkV2l6YXJkQWN0aW9uQ2xpY2tlZCcpO1xyXG4gICAgfVxyXG5cclxuICAgIHB1YmxpYyBuZXh0Q2xpY2tlZFdoZW5MYXN0U3RlcChfd2l6YXJkSWQ6IHN0cmluZywgX2V2ZW50PzogYW55KTogdm9pZCB7XHJcbiAgICAgICAgdGhpcy5fYnJvYWRjYXN0ZXIuYnJvYWRjYXN0KF93aXphcmRJZCArICdLZFdpemFyZExhc3RTdGVwUmVhY2hlZCcsIF9ldmVudCk7XHJcbiAgICB9XHJcblxyXG4gICAgcHVibGljIG9uTmV4dENsaWNrZWRXaGVuTGFzdFN0ZXAoX3dpemFyZElkOiBzdHJpbmcpOiBPYnNlcnZhYmxlPGFueT4ge1xyXG4gICAgICAgIHJldHVybiB0aGlzLl9icm9hZGNhc3Rlci5vbjxhbnk+KF93aXphcmRJZCArICdLZFdpemFyZExhc3RTdGVwUmVhY2hlZCcpO1xyXG4gICAgfVxyXG59XHJcbiJdfQ==