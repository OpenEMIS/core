import { Component, ViewEncapsulation, Input, Output, EventEmitter, ElementRef } from '@angular/core';
import { DomSanitizer } from '@angular/platform-browser';
import { KdSplitterEvent } from '../kd-angular-splitter/index';
import { KdConvertionSvc, KdDomElemSvc, KdDataSvc } from '../kd-common/index';
import { KdChartsSvc } from './kd-angular-charts-svc';
import { DEFAULT_CONFIG } from './kd-angular-charts-config';
export class KdCharts {
    constructor(_sanitizer, _elementRef, _chartSvc, 
    // public _kdSplitterEvent: KdSplitterEvent,
    _convertionSvc, _dataSvc) {
        this._sanitizer = _sanitizer;
        this._elementRef = _elementRef;
        this._chartSvc = _chartSvc;
        this._convertionSvc = _convertionSvc;
        this._dataSvc = _dataSvc;
        this.isLayerLoading = true;
        this.smallLoaderValue = null;
        this.pieData = [];
        this.pieColor = [];
        this.backgroundColor = '#FFFFFF';
        this.checkMapScale = false;
        this.isAxisChart = false;
        this.isNegativeStack = false;
        this.chartType = [''];
        this.rotateTitleX = false;
        this.rotateTitleY = false;
        this.chartHide = false;
        this.haveAxisPadding = false;
        this.haveAxisSpecialPadding = false;
        this.xAxisOpposite = false;
        this.havekdChartNoBorderClass = false;
        this.htmlClassObj = {
            'chartsWrapper': '',
            'legendContainer': ''
        };
        this.api = {};
        this.icons = {};
        this.markersLegend = [];
        this.shapes = {
            triangle: 'M 4 0 L 4 0 L 0 8 L 8 8 z',
            triangleR: 'M 0 0 L 8 0 L 4 8 L 4 8 z',
            diamond: 'M 4 0 L 8 4 L 4 8 L 0 4 z',
            circle: 'M 4 0 A 4 4 0 1 0 4 8 A 4 4 0 1 0 4 0 Z',
            square: 'M 0 0 L 8 0 L 8 8 L 0 8 z'
        };
        this.legendInactive = [];
        this._colorListPosition = 0;
        this._pieDoneFlag = false;
        this.seriesThreshold = 1000;
        this.outputLegendData = new EventEmitter();
        this.outputData = new EventEmitter();
        this.outputArea = new EventEmitter();
        // this._splitterSubscriptionArr = this._initSplitterSubscriptions(_kdSplitterEvent);
    }
    ngOnInit() {
        // console.log('kd-chart init');
        this._setConfig(this.chartConfig, true);
        if (!this.chartData || !this.chartConfig)
            return;
        this._setData(this.chartData);
        this.initApi();
        // this._resizeListener = () => this._onResize();
        // this._initListener();
        // console.log('kd-chart data ', this.chartData);
        // console.log('kd-chart config ', this.chartConfig);
    }
    ngOnChanges(_simpleChanges) {
        if (_simpleChanges.hasOwnProperty('chartConfig') && !_simpleChanges['chartConfig'].firstChange) {
            if (_simpleChanges['chartConfig'].currentValue === this.config)
                return;
            this._setConfig(_simpleChanges.chartConfig.currentValue);
        }
        if (_simpleChanges.hasOwnProperty('chartData') && !_simpleChanges['chartData'].firstChange) {
            if (_simpleChanges['chartData'].currentValue === this.data)
                return;
            this._setData(Object.assign({}, _simpleChanges.chartData.currentValue));
        }
    }
    ngOnDestroy() {
        if (!this.chartData || !this.chartConfig)
            return;
        // this._unsubscribe(this._splitterSubscriptionArr);
        // this._removeListener();
    }
    /**
     * For EXPORT. export skips data massage and generateLegendData, hence need to setLegendData separately
     * (accurate as of v3.7.0) as legendData is for internal use, we do not put in Input. this function is accessed via ViewChild from KdVisualization
     * param {ILegendData }} _legendData
     */
    setLegendData(_legendData) {
        this.legendData = Object.assign({}, _legendData);
    }
    /**
     * initiate api from outside kd charts component
     */
    initApi() {
        if (typeof this.chartApi === 'undefined')
            return;
        this.chartApi.changeSeriesColor = (legendId, color, index) => {
            if (typeof index === 'number')
                this._setDataColorShape(index, color);
            this.legendData[legendId].color = color;
            this._updateLegendIconWithIndex(legendId, index);
            this.api.redraw();
        };
        this.chartApi.redraw = () => this.api.redraw();
        // this.chartApi.enableListener = (_haveListener: boolean) => {
        //     if (_haveListener) {
        //         this._initListener();
        //         if (this._splitterSubscriptionArr.length === 0) {
        //             this._splitterSubscriptionArr = this._initSplitterSubscriptions(this._kdSplitterEvent);
        //         }
        //     } else {
        //         this._removeListener();
        //         this._unsubscribe(this._splitterSubscriptionArr);
        //         this._splitterSubscriptionArr = [];
        //     }
        // };
    }
    // ================================= Listener ==================================
    // private _initListener() {
    //     window.addEventListener('resize', this._resizeListener);
    // }
    // private _removeListener() {
    //     window.removeEventListener('resize', this._resizeListener);
    // }
    // private _onResize(): void {
    //     clearTimeout(this._resizeTimeout);
    //     this._resizeTimeout = setTimeout(() => {
    //         this.api.redraw();
    //     }, 500);
    // }
    // ================================= Splitter Subscription ==================================
    // private _initSplitterSubscriptions(_splitterEvent): Subscription[] {
    //     if (!_splitterEvent) return;
    //     let subscriptionArr: Subscription[] = [];
    //     let toggleMenuSub = _splitterEvent.onToggleMenu().subscribe((): void => {
    //         timer(500).subscribe((): void => {
    //             this.api.redraw();
    //         });
    //     });
    //     let toggleSubPane = _splitterEvent.onToggleSubPane().subscribe((): void => {
    //         timer(500).subscribe((): void => {
    //             this.api.redraw();
    //         });
    //     });
    //     let dragMenuSub = _splitterEvent.onDrag()
    //         .pipe(
    //             debounceTime(100)
    //         )
    //         .subscribe((): void => {
    //             this.api.redraw();
    //         });
    //     subscriptionArr.push(toggleMenuSub);
    //     subscriptionArr.push(toggleSubPane);
    //     subscriptionArr.push(dragMenuSub);
    //     return subscriptionArr;
    // }
    // private _unsubscribe(_subscriptionArr: Subscription[] = []): void {
    //     if (_subscriptionArr.length === 0) return;
    //     _subscriptionArr.forEach(subscription => {
    //         if (subscription) subscription.unsubscribe();
    //     });
    // }
    // ================================= Config and Data ==================================
    _setConfig(_config, _isFirstChange) {
        // storing config in this component
        this.config = JSON.parse(JSON.stringify(DEFAULT_CONFIG));
        this._dataSvc.deepCombineObject(this.config, _config || {});
        // set config is called twice, to improve performance, only call the following once (after data massage)
        if (_isFirstChange)
            return;
        this.setChartStyle(_config);
        this.checkMapScale = false;
        this._setClassNames();
        this._populateLegendIcon();
        this._setLabelStyle();
        // storing config into chart service
        this._chartSvc.config = _config;
    }
    setChartStyle(_config) {
        this.havekdChartNoBorderClass = !_config.chart.mainArea.style["borderWidth"];
        if (_config.chart.mainArea.style["borderWidth"] && _config.chart.mainArea.style["borderWidth"] === '0px') {
            this.havekdChartNoBorderClass = true;
        }
    }
    /* To be revisit. Hot fix for downgrade component as ngclass value doesn't change.*/
    _setClassNames() {
        // htmlClassObj is a workaround for downgrade method
        this.htmlClassObj['chartsWrapper'] = '';
        this.htmlClassObj['legendContainer'] = '';
        if (typeof this.config.legend.float !== undefined && this.config.legend.float) {
            this.htmlClassObj.chartsWrapper += 'legend-float ';
            this.htmlClassObj.legendContainer += 'legend-float ';
        }
        if (typeof this.config.legend.verticalAlign !== undefined) {
            this.htmlClassObj.chartsWrapper += this.config.legend.verticalAlign + ' ';
            this.htmlClassObj.legendContainer += this.config.legend.verticalAlign + ' ';
        }
        if (typeof this.config.legend.align !== undefined) {
            this.htmlClassObj.chartsWrapper += this.config.legend.align + ' ';
            this.htmlClassObj.legendContainer += this.config.legend.align + ' ';
        }
        if (this.chartCategory === 'pie' || this.chartCategory === 'map')
            return;
        this.xAxisOpposite = this.config.xAxis.opposite;
        // setting class name for vertical axis title to rotate
        this.rotateTitleX = this.chartType[0] === 'bar' && this._chartSvc.checkRotateTitleEnabled(this.chartType, this.config);
        this.rotateTitleY = this.chartType[0] !== 'bar' && this._chartSvc.checkRotateTitleEnabled(this.chartType, this.config);
        // this flag is for all axisCharts except for bar. Bar do not need paddin
        this.haveAxisPadding = this.chartType[0] !== 'bar';
        this.haveAxisSpecialPadding = this.chartType[this.chartType.length - 1] === 'type2';
        this.isNegativeStack = (this.chartCategory === 'bar' || this.chartCategory === 'column') && this.chartType[1] === 'stack' && this.chartType[2] === 'negative';
    }
    _updateLegendIconWithIndex(_legendId, _index) {
        let legendId = _legendId, legendConfig;
        // if legendId is given, we should follow legendId
        if (!legendId) {
            // if no legendId, follow _index
            if (_index === null || _index === undefined)
                return;
            legendId = this.legendList[_index];
        }
        legendConfig = this.legendData[legendId];
        this._updateLegendIcon(legendId, legendConfig);
    }
    _populateLegendIcon(index) {
        if (!this.legendData)
            return;
        this.legendList = Object.keys(this.legendData);
        for (let i = 0; i < this.legendList.length; i++) {
            let legendId = this.legendList[i];
            let legendConfig = this.legendData[legendId];
            // let eachSvg = this.renderer.createElement('svg');
            // this.renderer.setAttribute(eachSvg, 'fill', this.config.legendData[legendId].color);
            // this.renderer.setAttribute(eachSvg, 'width', 8);
            // this.renderer.setAttribute(eachSvg, 'height', 8);
            // let eachSvgPath = this.renderer.createElement('path');
            // this.renderer.setAttribute(eachSvgPath, 'd', this.config.legendData[legendId].shape);
            // this.renderer.appendChild(eachSvg, eachSvgPath);
            // let xml = new XMLSerializer().serializeToString(eachSvg);ARI
            // let data = "data:image/svg+xml;base64," + btoa(xml);
            // this.icons[legendId] = this._sanitizer.bypassSecurityTrustResourceUrl('data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" fill="' + legendConfig.color + '" width="8" height="8"><path d="' + this.shapes[legendConfig.shape] + '"/></svg>');
            // this.icons[legendId] = this._sanitizer.bypassSecurityTrustResourceUrl(data);
            // legend is set based on whether there is deactive
            this._updateLegendIcon(legendId, legendConfig);
        }
    }
    _setLabelStyle() {
        if (this.config.chart.labels.enabled) {
            let labelStyle = this._chartSvc.getStyle(this.config.chart.labels.style);
            this._applyLabelStyle(labelStyle, ' span', true);
        }
    }
    _setData(_data) {
        this.legendInactive = [];
        this.markersLegend = [];
        this._setChartType(_data);
        if (this.config.skipMassage) {
            this.data = _data;
            this._setConfig(this.config);
            return;
        }
        if (this.chartCategory === 'pie' || this.chartCategory === 'map') {
            if (this.chartCategory === 'pie')
                this._dataMassageForPie(_data);
            else if (this.chartCategory === 'map')
                this._dataMassageForMap(_data);
            // else if (this.chartCategory === 'map') this.data = _data;
            this._setConfig(this.config);
        }
        else
            this._dataMassage(_data);
        // emit data to kd-visualization to prepare for export
        this.outputData.emit(this.data);
        // emit current config to kd-visualization to prepare for export
        this.outputLegendData.emit(this.legendData);
    }
    _setChartType(_data) {
        let dataToUse = _data;
        if (!this.config.skipMassage || (_data.chart && _data.chart.type == 'map')) {
            dataToUse = _data.chart;
        }
        this.chartCategory = dataToUse.type;
        this.chartType = dataToUse.layout.split('-');
        this.isAxisChart = dataToUse.type !== 'pie' && dataToUse.type !== 'map';
    }
    _setDataColorShape(_index, _color) {
        if (_index < 0) {
            return;
        }
        // let changeSeries: boolean = this.config.chart.hasOwnProperty('persistentSeriesChange') ? this.config.chart.persistentSeriesChange : true;
        let legendIds = Object.keys(this.legendData);
        if (this.chartCategory != 'map') {
            for (let xIndex = this.data.data.length - 1; xIndex >= 0; xIndex--) {
                for (let yIndex = this.data.data[xIndex].y.length - 1; yIndex >= 0; yIndex--) {
                    if (this.data.data[xIndex].y[yIndex].id === legendIds[_index]) {
                        this._changeSeries(xIndex, yIndex, 'color');
                        this._changeSeries(xIndex, yIndex, 'shape');
                    }
                }
            }
        }
    }
    _changeSeries(_xIndex, _yIndex, _element) {
        let legendId = this.data.data[_xIndex].y[_yIndex].id;
        let output = this.legendData[legendId][_element];
        if (_element === 'shape') {
            output = this.shapes[output];
        }
        if (this._isChangeSeries(_xIndex, _yIndex, _element)) {
            this.data.data[_xIndex].y[_yIndex][_element] = output;
        }
    }
    _isChangeSeries(_xIndex, _yIndex, _element) {
        let changeSeries = this.config.chart.hasOwnProperty('persistentSeriesChange') ? this.config.chart.persistentSeriesChange : true;
        if (changeSeries) {
            return true;
        }
        else {
            if (this.chartData.series[_yIndex].data[_xIndex].hasOwnProperty(_element)) {
                if (this.chartData.series[_yIndex].data[_xIndex][_element] !== null || this.chartData.series[_yIndex].data[_xIndex][_element].length > 0) {
                    return false;
                }
            }
        }
        return true;
    }
    onLegendClick(_id) {
        let legendConfig = this.legendData[_id];
        legendConfig.deactive = !legendConfig.deactive || false;
        this._updateLegendItem(_id, legendConfig);
        if (legendConfig.deactive) {
            this.legendInactive.push(_id);
        }
        else {
            let idIndex = this.legendInactive.indexOf(_id);
            if (idIndex !== -1) {
                this.legendInactive.splice(idIndex, 1);
            }
        }
        if (this.chartCategory != 'map') {
            let legendData = this.updateConfig();
            let data = this.updateData(legendData);
            this.api.legendClick(data, legendData);
            this._toggleDataLabel(_id, legendConfig.deactive);
            // update data to kd-visualization to prepare for exporting
            this.outputData.emit(data);
        }
        else {
            this.api.legendClick(_id, legendConfig.deactive);
        }
    }
    onClusterClick(_id) {
        let legendItemMarker = this._elementRef.nativeElement.querySelector('#kdli-' + _id.id + ' .awesome-marker');
        let legendItemLabel = this._elementRef.nativeElement.querySelector('#kdli-' + _id.id + ' .kdx-legend-label');
        this.api.clusterClick(_id, { 'legendItemMarker': legendItemMarker, 'legendItemLabel': legendItemLabel });
    }
    getOutputLegend(_legendData) {
        if (this.chartCategory == 'map' && Object.keys(_legendData).length == 0) {
            this.checkMapScale = true;
        }
        else {
            this.legendData = _legendData;
            this.checkMapScale = false;
            this._pieDoneFlag = true;
            this.outputLegendData.emit(this.legendData);
            this._populateLegendIcon(undefined);
        }
    }
    getOutputData(_data) {
        // this.outputData.emit(_data);
        this.outputArea.emit(_data);
    }
    getReady(_value) {
        this.isLayerLoading = _value;
    }
    _updateLegendItem(_id, _legendConfig) {
        this._updateLegendIcon(_id, _legendConfig);
        let textColor = (_legendConfig.deactive) ? this.config.legend.item.inactiveColor || '#CCCCCC' : this.config.legend.item.style.color || this.config.legend.item.activeColor || '#000000';
        this._elementRef.nativeElement.querySelector('#kdli-' + _id).style.color = textColor;
    }
    _updateLegendIcon(_id, _legendConfig) {
        let iconColor = (_legendConfig.deactive) ? this.config.legend.item.inactiveColor || '#CCCCCC' : _legendConfig.color || '#000000';
        let rgbColor = this._convertionSvc.colorToRgb(iconColor);
        this.icons[_id] = this._sanitizer.bypassSecurityTrustResourceUrl('data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" fill="' + rgbColor + '" width="8" height="8"><path d="' + this.shapes[_legendConfig.shape] + '"/></svg>');
    }
    _toggleDataLabel(id, deactive) {
        let displayState = (deactive) ? 'none' : 'flex';
        this._applyLabelStyle(displayState, '.y-' + id);
        if (!deactive)
            this._applyLabelStyle('display:' + displayState, '.y-' + id + ' span', true);
    }
    _applyLabelStyle(_style, target, isRepositioning) {
        target = target || '';
        let allLabel = this._elementRef.nativeElement.querySelectorAll('#' + this.config.id + ' .kdx-charts-data-label' + target);
        for (let i in allLabel) {
            if (allLabel[i].style) {
                if (isRepositioning) {
                    let labelWidth = allLabel[i].offsetWidth;
                    let labelCenter = (labelWidth - labelWidth / allLabel[i].innerText.toString().length) / 2;
                    let shiftPosition = 0 - labelCenter;
                    _style += 'left:' + shiftPosition + 'px;';
                    allLabel[i].style = _style;
                }
                else {
                    allLabel[i].style.display = _style;
                }
            }
        }
    }
    updateConfig() {
        let legendData = Object.assign({}, this.legendData);
        let legendInactive = this.legendInactive;
        legendData = Object.keys(legendData)
            .filter(key => !legendInactive.includes(key))
            .reduce((obj, key) => {
            obj[key] = legendData[key];
            return obj;
        }, {});
        return legendData;
    }
    updateData(_legendData) {
        let thisData = JSON.parse(JSON.stringify(this.data));
        let legendInactive = this.legendInactive;
        if (this.chartCategory === 'pie') {
            let legendData = _legendData;
            // piedata uses legendData instead of data
            thisData.data = Object.keys(legendData).map(key => legendData[key]).filter((value) => value.y && value.y > 0);
            return thisData;
        }
        else if (this.chartType[1] === '100' && this.chartType[0] === 'area') {
            for (let i = thisData.data.length - 1; i >= 0; i--) {
                let newYArr = thisData.data[i].y.filter(d => !legendInactive.includes(d.id));
                thisData.data[i] = Object.assign({}, thisData.data[i], { y: newYArr });
            }
        }
        let originalData = JSON.parse(JSON.stringify(thisData));
        let allSumArrMax = [0];
        let allSumArrMin = [0];
        let haveNegative = false;
        for (let i = 0; i < originalData.data.length; i++) {
            let totalSum = 1;
            if (this.chartType[1] === '100') {
                totalSum = thisData.data[i].y.reduce((acc, curr, yIndex) => {
                    if (legendInactive.includes(curr.id))
                        return acc;
                    return acc + curr.value;
                }, 0);
            }
            let newYArr = [];
            let sumArr = [];
            let sum = 0;
            let sumNegative = 0;
            for (let yIndex = 0; yIndex < originalData.data[i].y.length; yIndex++) {
                let currY = Object.assign({}, originalData.data[i].y[yIndex]);
                if (legendInactive.includes(currY.id))
                    continue;
                let currentVal = currY.value === null ? 0 : currY.value;
                let currSign = Math.sign(currentVal);
                if (currSign < 0 && !haveNegative) {
                    haveNegative = true;
                    if (this.chartType[1] === '100') {
                        this.chartHide = true;
                        break;
                    }
                }
                if (this.chartType[1] !== '100' && this.chartType[1] === 'stack') {
                    if (currSign >= 0) {
                        sum = (currentVal === null) ? sum : sum + currentVal;
                    }
                    else {
                        sumNegative = (currentVal === null) ? sumNegative : sumNegative + currentVal;
                    }
                }
                else if (this.chartType[1] === '100') {
                    if (currentVal !== null && totalSum !== 0) {
                        currentVal = currentVal / totalSum * 100;
                        sum = sum + currentVal;
                    }
                    else {
                        sum = sum;
                    }
                }
                else {
                    if (currSign >= 0) {
                        sum = (currentVal === null) ? 0 : currentVal;
                    }
                    else {
                        sumNegative = (currentVal === null) ? 0 : currentVal;
                    }
                }
                currY.sum = currentVal >= 0 ? sum : sumNegative;
                // value is used to display data-label and tooltip, renderVal is the acutal percentage to pass to d3 for rendering
                if (this.chartType[1] === '100')
                    currY['renderVal'] = currentVal;
                sumArr.push(Math.sign(currentVal) < 0 ? sumNegative : sum);
                newYArr.push(currY);
            }
            allSumArrMax.push(this._chartSvc.getD3MaxOrMin(sumArr, 'max'));
            allSumArrMin.push(this._chartSvc.getD3MaxOrMin(sumArr, 'min'));
            thisData.data[i] = Object.assign({}, originalData.data[i], { y: newYArr });
        }
        thisData['range'] = {
            max: this._chartSvc.getD3MaxOrMin(allSumArrMax, 'max'),
            min: this._chartSvc.getD3MaxOrMin(allSumArrMin, 'min')
        };
        thisData['haveNegative'] = haveNegative;
        return thisData;
    }
    _generateLegendData(_data, maxSeriesLength) {
        // empty out variables before regenerating
        this.legendData = {};
        // this.legendList = null;
        let legendIdSearch = {};
        let legendId, legendDataObj;
        let legendData = {};
        for (let i = 0; i < maxSeriesLength; i++) {
            legendId = (_data.series[i] && _data.series[i].length > 0) ? _data.series[i].id : 'id' + i;
            legendDataObj = {
                'name': _data.series[i].name,
                'id': legendId,
                'color': _data.series[i].color || this._getDefaultConfig('color', i),
                'shape': _data.series[i].shape || this._getDefaultConfig('shape', i)
            };
            if (this.chartCategory === 'line' || this.chartCategory === 'spline' || this.chartCategory === 'area' || this.chartCategory === 'dot') {
                legendDataObj['dotEnabled'] = (typeof _data.series[i].dotEnabled !== 'undefined') ? _data.series[i].dotEnabled : true;
                legendDataObj['dotBorderWidth'] = (typeof _data.series[i].dotBorderWidth !== 'undefined') ? _data.series[i].dotBorderWidth : 0;
                legendDataObj['dotBorderColor'] = (typeof _data.series[i].dotBorderColor !== 'undefined') ? _data.series[i].dotBorderColor : '#FFFFFF';
                if (this.chartCategory !== 'dot')
                    legendDataObj['lineStyle'] = (typeof _data.series[i].lineStyle !== 'undefined') ? _data.series[i].lineStyle : 'solid';
            }
            legendData[legendId] = legendDataObj;
            legendIdSearch[i] = legendId;
        }
        this.legendData = legendData;
        return legendIdSearch;
    }
    _dataMassage(_data) {
        let seriesLength = this._chartSvc.getD3MaxOrMin([_data.series.length, this.seriesThreshold], 'min');
        let chartDataObj, chartDataSeriesObj;
        let chartData = {
            'type': _data.chart['type'] ? _data.chart['type'] : null,
            'layout': _data.chart['layout'] ? _data.chart['layout'] : null,
            'config': this.config.plotOptions && this.config.plotOptions.hasOwnProperty(_data.chart['type']) ? this.config.plotOptions[_data.chart['type']] : {},
            'data': []
        };
        if (!this.config.hasOwnProperty('id')) {
            this.config['id'] = _data.chart['type'] ? _data.chart['type'] + '-1' : 'Default-1';
        }
        let categories = this._chartSvc.getLimitedCategories(_data.xAxis.categories, this.xThreshold);
        let legendIdSearch = this._generateLegendData(_data, seriesLength);
        let totalSumArr = this._getTotalSum(_data, seriesLength);
        let allSumArrMax = [0];
        let allSumArrMin = [0];
        let haveNegative = false;
        for (let i = 0; i < categories.length; i++) {
            chartDataObj = {
                'x': {
                    value: i.toString(),
                    label: categories[i]
                },
                'y': [],
            };
            let sumArr = [];
            let sum = 0;
            let sumNegative = 0;
            let forLoopInfo = this._chartSvc.getForLoopInfo(this._chartSvc.getForLoopSequence(this.chartType), seriesLength);
            // for (let j: number = 0; j < seriesLength; j++) {
            for (let j = forLoopInfo.start; forLoopInfo.check(j, forLoopInfo.end); j = forLoopInfo.iterate(j)) {
                if (typeof _data.series[j].data[i] === 'undefined')
                    continue;
                let currentVal = _data.series[j].data[i].value;
                let currSign = Math.sign(currentVal);
                if (typeof currentVal === 'undefined')
                    continue;
                if (currSign < 0 && !haveNegative) {
                    haveNegative = true;
                    if (this.chartType[1] === '100')
                        break;
                }
                if (this.chartType[1] !== '100' && this.chartType[1] === 'stack') {
                    if (currSign >= 0) {
                        sum = (currentVal === null) ? sum : sum + currentVal;
                    }
                    else {
                        sumNegative = (currentVal === null) ? sumNegative : sumNegative + currentVal;
                    }
                }
                else if (this.chartType[1] === '100') {
                    if (currentVal !== null && totalSumArr[i] !== 0) {
                        currentVal = currentVal / totalSumArr[i] * 100;
                    }
                    else {
                        currentVal = 0;
                    }
                    sum = sum + currentVal;
                }
                else {
                    if (currSign >= 0) {
                        sum = (currentVal === null) ? 0 : currentVal;
                    }
                    else {
                        sumNegative = (currentVal === null) ? 0 : currentVal;
                    }
                }
                chartDataSeriesObj = {
                    'sum': currentVal >= 0 ? sum : sumNegative,
                    'value': _data.series[j].data[i].value,
                    'color': this._getConfig('color', j, _data.series[j].data[i]),
                    'shape': this.shapes[this._getConfig('shape', j, _data.series[j].data[i])],
                    'id': legendIdSearch[j]
                };
                // value is used to display data-label and tooltip, renderVal is the acutal percentage to pass to d3 for rendering
                if (this.chartType[1] === '100')
                    chartDataSeriesObj['renderVal'] = currentVal;
                sumArr.push(Math.sign(currentVal) < 0 ? sumNegative : sum);
                chartDataObj.y.push(chartDataSeriesObj);
            }
            allSumArrMax.push(this._chartSvc.getD3MaxOrMin(sumArr, 'max'));
            allSumArrMin.push(this._chartSvc.getD3MaxOrMin(sumArr, 'min'));
            chartData.data.push(chartDataObj);
        }
        if (_data.chart.type !== 'pie') {
            chartData['range'] = {
                max: this._chartSvc.getD3MaxOrMin(allSumArrMax, 'max'),
                min: this._chartSvc.getD3MaxOrMin(allSumArrMin, 'min')
            };
            chartData['haveNegative'] = haveNegative;
        }
        this.data = chartData;
        this.chartHide = this.chartType[1] === '100' && haveNegative;
        this._setConfig(this.config);
    }
    _dataMassageForPie(_data) {
        if (_data !== undefined && _data !== null) {
            let chartData = {
                'type': _data.chart['type'] ? _data.chart['type'] : null,
                'layout': _data.chart['layout'] ? _data.chart['layout'] : null,
                'config': this.config.plotOptions && this.config.plotOptions.hasOwnProperty(_data.chart['type']) ? this.config.plotOptions[_data.chart['type']] : {},
                'data': []
            };
            let returnParams = this._chartSvc.singlePieDataMassage(this.legendData, _data, this.config, this.seriesThreshold);
            chartData['piedata'] = returnParams.pieData;
            this.data = chartData;
            this.config['pieColor'] = returnParams.pieColor;
            this.legendData = returnParams.legendData;
            // this.outputData.emit(this.data);
        }
    }
    _dataMassageForMap(_data) {
        this.data = _data;
        this._setLegendForMap();
    }
    _setLegendForMap() {
        let seriesData;
        if (this.data['mapSeriesData'] && this.config.skipMassage) {
            seriesData = JSON.parse(JSON.stringify(this.data['mapSeriesData']));
        }
        else {
            seriesData = JSON.parse(JSON.stringify(this.data['series']));
            for (let i = 0; i < seriesData.length; i++) {
                seriesData[i]['deactive'] = false;
            }
        }
        this.checkMapScale = false;
        if (!this.config.skipMassage) {
            if (this.config.colorAxis != undefined) {
                if (this.config.colorAxis.dataClasses && this.config.colorAxis.dataClasses.length != 0) {
                    this.legendData = this._chartSvc.setSingleLegendLevels(this.config.colorAxis.dataClasses, this.config.legend.valueDecimals, this.config.legend.valueSuffix);
                }
                else {
                    this.checkMapScale = true;
                }
            }
            else {
                this.legendData = this._chartSvc.setMapLegendData(this.legendData, seriesData, this.config);
            }
        }
        else {
            // output legend only for exporting
            if (this.config.colorAxis != undefined) {
                if (this.config.colorAxis.dataClasses && this.config.colorAxis.dataClasses.length != 0) {
                    this.legendData = this._chartSvc.setMapLegendData(this.legendData, seriesData, this.config);
                }
                else {
                    this.checkMapScale = true;
                }
            }
            else {
                this.legendData = this._chartSvc.setMapLegendData(this.legendData, seriesData, this.config);
            }
        }
    }
    _getTotalSum(_data, seriesLength) {
        if (this.chartType[1] === '100') {
            return this._chartSvc.getTotalSumArrFromSeries(_data.series, _data.xAxis.categories, seriesLength);
        }
    }
    _getConfig(_element, _seriesIndex, _data) {
        if (!this._chartSvc.isExist(_data))
            return;
        if (_data.hasOwnProperty(_element) && _data[_element] !== undefined) {
            return _data[_element];
        }
        let config = this._getLegendConfig(_element, _seriesIndex);
        return config;
    }
    _getLegendConfig(_element, _seriesIndex) {
        if (_element === 'shape' &&
            (this.chartData.chart.type === 'pie' || this.chartData.chart.type === 'bar')) {
            return 'circle';
        }
        let defaultConfig = this._getDefaultConfig(_element, _seriesIndex);
        let config;
        if (this.chartCategory == 'pie') {
            config = defaultConfig;
        }
        else {
            config = this.chartData.series[_seriesIndex][_element] || defaultConfig;
        }
        return config;
    }
    _getDefaultConfig(_element, _seriesIndex) {
        if (_element === 'shape')
            return 'circle';
        if (_seriesIndex || _seriesIndex === 0) {
            return this.config.colors[_seriesIndex];
        }
        else {
            this._colorListPosition++;
            return this.config.colors[this._colorListPosition - 1];
        }
    }
    getOutputMarker(_data) {
        this.markersLegend = _data;
    }
}
KdCharts.decorators = [
    { type: Component, args: [{
                selector: 'kd-charts',
                template: "<!-- <div class=\"kdx-charts-wrapper {{config.legend.verticalAlign}} {{config.legend.align}}\" [ngClass]=\"{'legend-float': config.legend.float}\"> -->\r\n\r\n<div class=\"kdx-charts-wrapper {{htmlClassObj.chartsWrapper}}\">\r\n    <div class=\"kdx-charts-main\">\r\n        <div class=\"kdx-header-container\" *ngIf=\"(config.title && config.title.enabled && config.title.text && config.title.text !== '') || (config.subtitle.enabled && config.subtitle.text && config.subtitle.text !== '')\">\r\n            <div *ngIf=\"config.title.enabled && config.title.text && config.title.text !== ''\" class=\"kdx-chart-title  {{config.title.align}}\" [ngStyle]=\"config.title.style\">\r\n                {{config.title.text}}\r\n            </div>\r\n            <div *ngIf=\"config.subtitle && config.subtitle.enabled && config.subtitle.text && config.subtitle.text !== ''\" class=\"kdx-chart-subtitle {{config.subtitle.align}}\" [ngStyle]=\"config.subtitle.style\">\r\n                {{config.subtitle.text}}\r\n            </div>\r\n        </div>\r\n\r\n        <div class=\"kdx-charts-dummy kdx-charts-invisible-axis-label\" [ngClass]=\"{'kdx-charts-child-padding-both': haveAxisPadding, 'kdx-charts-child-special-padding': haveAxisSpecialPadding, 'kdx-charts-axis-x-opposite': xAxisOpposite}\" [ngStyle]=\"config.xAxis.labels.style\"></div>\r\n        <div class=\"kdx-chart-container\" [ngStyle]=\"config.chart.plotArea.style\">\r\n            <div class=\"kdx-charts-axis-title kdx-charts-axis-title-x\" *ngIf=\"config.xAxis && config.xAxis.enabled && !chartHide && isAxisChart && config.xAxis.title.text !== ''\" [ngStyle]=\"config.xAxis.title.style\">\r\n                <div class=\"kdx-charts-axis-title-text\">{{config.xAxis.title.text}}</div>\r\n            </div>\r\n            <div class=\"kdx-charts-axis-label-container\" *ngIf=\"config.xAxis.enabled && config.xAxis.labels && config.xAxis.labels.enabled && !chartHide && isAxisChart\" [ngClass]=\"{'kdx-charts-child-padding-both': haveAxisPadding, 'kdx-charts-child-special-padding': haveAxisSpecialPadding, 'kdx-charts-axis-x-opposite': xAxisOpposite}\" [ngStyle]=\"config.xAxis.labels.style\">\r\n            </div>\r\n            <div *ngIf=\"config.chart.labels\" class=\"kdx-charts-data-label-container\" [ngStyle]=\"{'z-index': config.chart.labels.enabled ? 1 : -1}\"></div>\r\n            <div class=\"kdx-charts-svg-wrapper\">\r\n                <div id=\"{{config.id}}Leaflet\" class=\"kdx-charts-svg-container\">\r\n                    <svg width=\"0px\" height=\"0px\"></svg>\r\n                </div>\r\n                <div class=\"kdx-charts-axis-title kdx-charts-axis-title-y\" *ngIf=\"config.yAxis && config.yAxis.enabled && !chartHide && isAxisChart && config.yAxis.title && config.yAxis.title.text !== ''\" [ngStyle]=\"config.yAxis.title.style\">\r\n                    <div class=\"kdx-charts-axis-title-text\">{{config.yAxis.title.text}}</div>\r\n                </div>\r\n                <ng-container *ngIf=\"data\" [ngSwitch]=\"chartCategory\">\r\n                    <kd-bar-chart *ngSwitchCase=\"'bar'\" [data]=\"data\" [config]=\"config\" [api]=\"api\" [legend]=\"legendData\"></kd-bar-chart>\r\n                    <kd-bar-chart *ngSwitchCase=\"'column'\" [data]=\"data\" [config]=\"config\" [api]=\"api\" [legend]=\"legendData\"></kd-bar-chart>\r\n                    <kd-pie-chart *ngSwitchCase=\"'pie'\" [data]=\"data\" [config]=\"config\" [api]=\"api\" [legend]=\"legendData\" [seriesThreshold]=\"seriesThreshold\" (outputLegend)=\"getOutputLegend($event)\" (outputData)=\"getOutputData($event)\"></kd-pie-chart>\r\n                    <kd-line-chart *ngSwitchCase=\"'line'\" [data]=\"data\" [config]=\"config\" [api]=\"api\" [legend]=\"legendData\"></kd-line-chart>\r\n                    <kd-line-chart *ngSwitchCase=\"'dot'\" [data]=\"data\" [config]=\"config\" [api]=\"api\" [legend]=\"legendData\"></kd-line-chart>\r\n                    <kd-line-chart *ngSwitchCase=\"'spline'\" [data]=\"data\" [config]=\"config\" [api]=\"api\" [legend]=\"legendData\"></kd-line-chart>\r\n                    <kd-line-chart *ngSwitchCase=\"'area'\" [data]=\"data\" [config]=\"config\" [api]=\"api\" [legend]=\"legendData\"></kd-line-chart>\r\n                    <kd-map-chart *ngSwitchCase=\"'map'\" [data]=\"data\" [config]=\"config\" [api]=\"api\" [legend]=\"legendData\" (outputLegend)=\"getOutputLegend($event)\" (outputData)=\"getOutputData($event)\" (outputMarker)=\"getOutputMarker($event)\" (outputReady)=\"getReady($event)\"></kd-map-chart>\r\n                </ng-container>\r\n            </div>\r\n            <div class=\"kdx-charts-axis-label-container kdx-charts-double-axis-x\" *ngIf=\"config.xAxis.enabled && config.xAxis.labels && config.xAxis.labels.enabled && !chartHide && isAxisChart && isNegativeStack\" [ngClass]=\"{'kdx-charts-child-padding-both': haveAxisPadding, 'kdx-charts-child-special-padding': haveAxisSpecialPadding, 'kdx-charts-axis-x-opposite': !xAxisOpposite}\" [ngStyle]=\"config.xAxis.labels.style\">\r\n            </div>\r\n            <div class=\"kdx-charts-axis-title kdx-charts-axis-title-x kdx-charts-double-axis-x\" *ngIf=\"config.xAxis && config.xAxis.enabled && !chartHide && isAxisChart && config.xAxis.title.text !== '' && isNegativeStack\" [ngStyle]=\"config.xAxis.title.style\">\r\n                <div class=\"kdx-charts-axis-title-text\">{{config.xAxis.title.text}}</div>\r\n            </div>\r\n        </div>\r\n    </div>\r\n\r\n    <!-- <div *ngIf=\"config.legend.enabled && !chartHide\" [ngClass]=\"{'legend-float': config.legend.float}\" class=\"kdx-legend-container {{config.legend.verticalAlign}} {{config.legend.align}}\"> -->\r\n\r\n    <div class=\"kdx-legend-main-container {{htmlClassObj.chartsWrapper}}\" [ngClass]=\"{clusterChartMap: markersLegend.length > 0}\">\r\n        <div class=\"kdx-legend-container\" *ngIf=\"config.legend.enabled && !chartHide && markersLegend.length > 0\" [ngStyle]=\"{'flex': markersLegend.length > 0 ? '0 1 50%' : null}\">\r\n            <div class=\"kdx-legends\" [ngStyle]=\"config.clusterLegend.style\">\r\n                <div class=\"kdx-legend-title-container  {{config.clusterLegend.title.align}}\" *ngIf=\"config.clusterLegend.title && config.clusterLegend.title.text\" [ngStyle]=\"config.clusterLegend.title.style\">\r\n                    <div class=\"kdx-legend-title\">{{config.clusterLegend.title.text}}</div>\r\n                </div>\r\n                <div class=\"kdx-legend\">\r\n                    <div class=\"kdx-legend-item\" id=\"kdli-{{legendItem.id}}\" *ngFor=\"let legendItem of markersLegend\" (click)=\"onClusterClick(legendItem)\">\r\n                        <div class=\"kdx-legend-marker\" [innerHTML]=\"legendItem.icon.outerHTML\" ></div>\r\n                        <div class=\"kdx-legend-label\" [ngStyle]=\"config.clusterLegend.item.style\">\r\n                            <div class=\"kdx-label-text\">{{legendItem.label}}</div>\r\n                        </div>\r\n                    </div>\r\n                </div>\r\n            </div>\r\n        </div>\r\n        <div *ngIf=\"config.legend.enabled && !chartHide && !(chartCategory === 'map' && chartType[1] === 'cluster')\" class=\"kdx-legend-container\">\r\n            <div class=\"kdx-legends\" [ngStyle]=\"config.legend.style\">\r\n                <div *ngIf=\"config.legend.title && config.legend.title.text\" class=\"kdx-legend-title-container {{config.legend.title.align}}\" [ngStyle]=\"config.legend.title.style\">\r\n                    <div class=\"kdx-legend-title\">{{config.legend.title.text}}</div>\r\n                </div>\r\n                <div class=\"kdx-legend legend-scroll {{config.legend.layout}}\" *ngIf=\"legendList && !checkMapScale\" [ngClass]=\"{'legend-scroll': !config.legend.enableScroll}\">\r\n                    <div class=\"kdx-legend-item\" id=\"kdli-{{legendId}}\" [ngStyle]=\"{'color': config.legend.item.activeColor}\" *ngFor=\"let legendId of legendList\" (click)=\"onLegendClick(legendId)\">\r\n                        <div class=\"kdx-legend-marker\">\r\n                            <img id=\"legend-icon-{{legendId}}\" [src]=\"icons[legendId]\" />\r\n                        </div>\r\n                        <div class=\"kdx-legend-label\" [ngStyle]=\"config.legend.item.style\">\r\n                            <div class=\"kdx-label-text\" *ngIf=\"legendData[legendId]\" [ngClass]=\"{'kdx-label-lightgray': legendData[legendId].deactive}\" >{{legendData[legendId].name}}</div>\r\n                        </div>\r\n                    </div>\r\n                </div>\r\n              <!--   <div class=\"kdx-legend\"> [ngClass]=\"{'kdx-legend-main-container': markersLegend.length > 0}\"\r\n                    <div class=\"kdx-legend-item\" id=\"kdli-{{legendItem.id}}\" *ngFor=\"let legendItem of markersLegend\" (click)=\"onClusterClick(legendItem)\">\r\n                        <div class=\"kdx-legend-marker\" [innerHTML]=\"legendItem.icon.outerHTML\" ></div>\r\n                        <div class=\"kdx-legend-label\"><div class=\"kdx-label-text\">{{legendItem.label}}</div></div>\r\n                    </div>\r\n                </div> -->\r\n                <div class=\"kdx-legend legend-scroll {{config.legend.layout}}\" *ngIf=\"checkMapScale\">\r\n                    <div class=\"kdx-map-scale-wrapper\">\r\n                        <i class=\"fa fa-caret-down kdx-map-scale-triangle\"></i>\r\n                        <div class=\"kdx-map-scale-container\">\r\n                            <div id=\"mapScale\" class=\"kdx-map-scale\"></div>\r\n                            <div class=\"kdx-map-scale-text-container\"></div>\r\n                        </div>\r\n                    </div>\r\n                </div>\r\n            </div>\r\n        </div>\r\n    </div>\r\n</div>\r\n<div *ngIf=\"config.footer && config.footer.enabled\" class=\"kdx-charts-footer\" [ngClass]=\"{clusterChartMapFooter: markersLegend.length > 0}\">\r\n    <div *ngIf=\"config.footer.bottomLabel && config.footer.bottomLabel.enabled && config.footer.bottomLabel.text && config.footer.bottomLabel.text !== ''\" class=\"kdx-charts-bottom-label {{config.footer.bottomLabel.align}}\" [ngStyle]=\"config.footer.bottomLabel.style\">\r\n        {{config.footer.bottomLabel.text}}\r\n    </div>\r\n    <div *ngIf=\"config.footer.footNote && config.footer.footNote.enabled && config.footer.footNote.text && config.footer.footNote.text !== ''\" class=\"kdx-charts-foot-note {{config.footer.footNote.align}}\" [ngStyle]=\"config.footer.footNote.style\">\r\n        {{config.footer.footNote.text}}\r\n    </div>\r\n</div>\r\n<kd-progressloader *ngIf=\"((chartCategory === 'map' && chartType[1] === 'full') || (chartCategory === 'map' && chartType[1] === 'cluster')) && isLayerLoading\" configtype=\"small-spinner\" [configvalue]=\"smallLoaderValue\"></kd-progressloader>",
                encapsulation: ViewEncapsulation.None,
                providers: [KdChartsSvc, KdSplitterEvent, KdConvertionSvc, KdDomElemSvc, KdDataSvc],
                host: {
                    'class': 'kdx-charts',
                    '[attr.id]': 'config.id',
                    '[class.kdx-charts-axis-invert]': 'chartType[0] === "bar"',
                    '[class.kdx-charts-rotate-title-x]': 'rotateTitleX',
                    '[class.kdx-charts-rotate-title-y]': 'rotateTitleY',
                    '[class.kdx-charts-yAxis-opposite]': 'config.yAxis.opposite',
                    '[class.kdx-charts-xAxis-opposite]': 'config.xAxis.opposite',
                    '[class.kdx-charts-no-border]': 'havekdChartNoBorderClass',
                    '[style.background-color]': 'config.chart.mainArea.style["backgroundColor"]',
                    '[style.border-color]': 'config.chart.mainArea.style["borderColor"]',
                    '[style.border-width]': 'config.chart.mainArea.style["borderWidth"]',
                    '[style.border-radius]': 'config.chart.mainArea.style["borderRadius"]',
                    '[style.border-style]': 'config.chart.mainArea.style["borderStyle"]',
                    '[style.font-family]': 'config.chart.style.fontFamily',
                    '[style.opacity]': 'config.chart.mainArea.style.opacity',
                }
            },] }
];
KdCharts.ctorParameters = () => [
    { type: DomSanitizer },
    { type: ElementRef },
    { type: KdChartsSvc },
    { type: KdConvertionSvc },
    { type: KdDataSvc }
];
KdCharts.propDecorators = {
    chartData: [{ type: Input, args: ['data',] }],
    chartConfig: [{ type: Input, args: ['config',] }],
    chartApi: [{ type: Input, args: ['api',] }],
    xThreshold: [{ type: Input }],
    seriesThreshold: [{ type: Input }],
    outputLegendData: [{ type: Output }],
    outputData: [{ type: Output }],
    outputArea: [{ type: Output }]
};
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoia2QtYW5ndWxhci1jaGFydHMuanMiLCJzb3VyY2VSb290IjoiRDovb3BlbkVNSVMvc3R5bGVndWlkZS9pb3N0Zy1vcGVuZW1pcy1zdHlsZWd1aWRlL3Byb2plY3RzL29wZW5lbWlzLXN0eWxlZ3VpZGUtbGliL3NyYy8iLCJzb3VyY2VzIjpbImtkLWNvbXBvbmVudHMva2QtYW5ndWxhci1jaGFydHMva2QtYW5ndWxhci1jaGFydHMudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsT0FBTyxFQUNILFNBQVMsRUFDVCxpQkFBaUIsRUFDakIsS0FBSyxFQUNMLE1BQU0sRUFDTixZQUFZLEVBSVosVUFBVSxFQUViLE1BQU0sZUFBZSxDQUFDO0FBQ3ZCLE9BQU8sRUFBRSxZQUFZLEVBQUUsTUFBTSwyQkFBMkIsQ0FBQztBQUd6RCxPQUFPLEVBQUUsZUFBZSxFQUFFLE1BQU0sOEJBQThCLENBQUM7QUFDL0QsT0FBTyxFQUFFLGVBQWUsRUFBRSxZQUFZLEVBQUUsU0FBUyxFQUFFLE1BQU0sb0JBQW9CLENBQUM7QUFDOUUsT0FBTyxFQUFFLFdBQVcsRUFBRSxNQUFNLHlCQUF5QixDQUFDO0FBQ3RELE9BQU8sRUFBRSxjQUFjLEVBQUUsTUFBTSw0QkFBNEIsQ0FBQztBQXNDNUQsTUFBTSxPQUFPLFFBQVE7SUE2RGpCLFlBQ1ksVUFBd0IsRUFDeEIsV0FBdUIsRUFDdkIsU0FBc0I7SUFDOUIsNENBQTRDO0lBQ3JDLGNBQStCLEVBQy9CLFFBQW1CO1FBTGxCLGVBQVUsR0FBVixVQUFVLENBQWM7UUFDeEIsZ0JBQVcsR0FBWCxXQUFXLENBQVk7UUFDdkIsY0FBUyxHQUFULFNBQVMsQ0FBYTtRQUV2QixtQkFBYyxHQUFkLGNBQWMsQ0FBaUI7UUFDL0IsYUFBUSxHQUFSLFFBQVEsQ0FBVztRQWxFdkIsbUJBQWMsR0FBWSxJQUFJLENBQUM7UUFDL0IscUJBQWdCLEdBQVEsSUFBSSxDQUFDO1FBQzdCLFlBQU8sR0FBZSxFQUFFLENBQUM7UUFDekIsYUFBUSxHQUFlLEVBQUUsQ0FBQztRQUMxQixvQkFBZSxHQUFXLFNBQVMsQ0FBQztRQUlwQyxrQkFBYSxHQUFZLEtBQUssQ0FBQztRQUUvQixnQkFBVyxHQUFZLEtBQUssQ0FBQztRQUM3QixvQkFBZSxHQUFZLEtBQUssQ0FBQztRQUNqQyxjQUFTLEdBQWtCLENBQUMsRUFBRSxDQUFDLENBQUM7UUFDaEMsaUJBQVksR0FBWSxLQUFLLENBQUM7UUFDOUIsaUJBQVksR0FBWSxLQUFLLENBQUM7UUFDOUIsY0FBUyxHQUFZLEtBQUssQ0FBQztRQUMzQixvQkFBZSxHQUFZLEtBQUssQ0FBQztRQUNqQywyQkFBc0IsR0FBWSxLQUFLLENBQUM7UUFDeEMsa0JBQWEsR0FBWSxLQUFLLENBQUM7UUFDL0IsNkJBQXdCLEdBQVksS0FBSyxDQUFDO1FBRTFDLGlCQUFZLEdBQVE7WUFDdkIsZUFBZSxFQUFFLEVBQUU7WUFDbkIsaUJBQWlCLEVBQUUsRUFBRTtTQUN4QixDQUFDO1FBRUssUUFBRyxHQUFzQixFQUFFLENBQUM7UUFFNUIsVUFBSyxHQUFXLEVBQUUsQ0FBQztRQUduQixrQkFBYSxHQUFlLEVBQUUsQ0FBQztRQUU5QixXQUFNLEdBQVc7WUFDckIsUUFBUSxFQUFFLDJCQUEyQjtZQUNyQyxTQUFTLEVBQUUsMkJBQTJCO1lBQ3RDLE9BQU8sRUFBRSwyQkFBMkI7WUFDcEMsTUFBTSxFQUFFLHlDQUF5QztZQUNqRCxNQUFNLEVBQUUsMkJBQTJCO1NBQ3RDLENBQUM7UUFFTSxtQkFBYyxHQUFrQixFQUFFLENBQUM7UUFDbkMsdUJBQWtCLEdBQVcsQ0FBQyxDQUFDO1FBTy9CLGlCQUFZLEdBQVksS0FBSyxDQUFDO1FBTTdCLG9CQUFlLEdBQVcsSUFBSSxDQUFDO1FBQzlCLHFCQUFnQixHQUFpRCxJQUFJLFlBQVksRUFBRSxDQUFDO1FBQ3BGLGVBQVUsR0FBMEIsSUFBSSxZQUFZLEVBQUUsQ0FBQztRQUN2RCxlQUFVLEdBQTBCLElBQUksWUFBWSxFQUFFLENBQUM7UUFVN0QscUZBQXFGO0lBQ3pGLENBQUM7SUFFRCxRQUFRO1FBQ0osZ0NBQWdDO1FBQ2hDLElBQUksQ0FBQyxVQUFVLENBQUMsSUFBSSxDQUFDLFdBQVcsRUFBRSxJQUFJLENBQUMsQ0FBQztRQUN4QyxJQUFJLENBQUMsSUFBSSxDQUFDLFNBQVMsSUFBSSxDQUFDLElBQUksQ0FBQyxXQUFXO1lBQUUsT0FBTztRQUNqRCxJQUFJLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsQ0FBQztRQUM5QixJQUFJLENBQUMsT0FBTyxFQUFFLENBQUM7UUFDZixpREFBaUQ7UUFDakQsd0JBQXdCO1FBQ3hCLGlEQUFpRDtRQUNqRCxxREFBcUQ7SUFDekQsQ0FBQztJQUVELFdBQVcsQ0FBQyxjQUE2QjtRQUNyQyxJQUFJLGNBQWMsQ0FBQyxjQUFjLENBQUMsYUFBYSxDQUFDLElBQUksQ0FBQyxjQUFjLENBQUMsYUFBYSxDQUFDLENBQUMsV0FBVyxFQUFFO1lBQzVGLElBQUksY0FBYyxDQUFDLGFBQWEsQ0FBQyxDQUFDLFlBQVksS0FBSyxJQUFJLENBQUMsTUFBTTtnQkFBRSxPQUFPO1lBQ3ZFLElBQUksQ0FBQyxVQUFVLENBQUMsY0FBYyxDQUFDLFdBQVcsQ0FBQyxZQUFZLENBQUMsQ0FBQztTQUM1RDtRQUNELElBQUksY0FBYyxDQUFDLGNBQWMsQ0FBQyxXQUFXLENBQUMsSUFBSSxDQUFDLGNBQWMsQ0FBQyxXQUFXLENBQUMsQ0FBQyxXQUFXLEVBQUU7WUFDeEYsSUFBSSxjQUFjLENBQUMsV0FBVyxDQUFDLENBQUMsWUFBWSxLQUFLLElBQUksQ0FBQyxJQUFJO2dCQUFFLE9BQU87WUFDbkUsSUFBSSxDQUFDLFFBQVEsQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLEVBQUUsRUFBRSxjQUFjLENBQUMsU0FBUyxDQUFDLFlBQVksQ0FBQyxDQUFDLENBQUM7U0FDM0U7SUFDTCxDQUFDO0lBRUQsV0FBVztRQUNQLElBQUksQ0FBQyxJQUFJLENBQUMsU0FBUyxJQUFJLENBQUMsSUFBSSxDQUFDLFdBQVc7WUFBRSxPQUFPO1FBQ2pELG9EQUFvRDtRQUNwRCwwQkFBMEI7SUFDOUIsQ0FBQztJQUVEOzs7O09BSUc7SUFDSSxhQUFhLENBQUMsV0FBMkM7UUFDNUQsSUFBSSxDQUFDLFVBQVUsR0FBRyxNQUFNLENBQUMsTUFBTSxDQUFDLEVBQUUsRUFBRSxXQUFXLENBQUMsQ0FBQztJQUNyRCxDQUFDO0lBRUQ7O09BRUc7SUFDSyxPQUFPO1FBQ1gsSUFBSSxPQUFPLElBQUksQ0FBQyxRQUFRLEtBQUssV0FBVztZQUFFLE9BQU87UUFFakQsSUFBSSxDQUFDLFFBQVEsQ0FBQyxpQkFBaUIsR0FBRyxDQUFDLFFBQWdCLEVBQUUsS0FBYSxFQUFFLEtBQWMsRUFBRSxFQUFFO1lBQ2xGLElBQUksT0FBTyxLQUFLLEtBQUssUUFBUTtnQkFBRSxJQUFJLENBQUMsa0JBQWtCLENBQUMsS0FBSyxFQUFFLEtBQUssQ0FBQyxDQUFDO1lBQ3JFLElBQUksQ0FBQyxVQUFVLENBQUMsUUFBUSxDQUFDLENBQUMsS0FBSyxHQUFHLEtBQUssQ0FBQztZQUN4QyxJQUFJLENBQUMsMEJBQTBCLENBQUMsUUFBUSxFQUFFLEtBQUssQ0FBQyxDQUFDO1lBQ2pELElBQUksQ0FBQyxHQUFHLENBQUMsTUFBTSxFQUFFLENBQUM7UUFDdEIsQ0FBQyxDQUFDO1FBRUYsSUFBSSxDQUFDLFFBQVEsQ0FBQyxNQUFNLEdBQUcsR0FBRyxFQUFFLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxNQUFNLEVBQUUsQ0FBQztRQUUvQywrREFBK0Q7UUFDL0QsMkJBQTJCO1FBQzNCLGdDQUFnQztRQUNoQyw0REFBNEQ7UUFDNUQsc0dBQXNHO1FBQ3RHLFlBQVk7UUFDWixlQUFlO1FBQ2Ysa0NBQWtDO1FBQ2xDLDREQUE0RDtRQUM1RCw4Q0FBOEM7UUFDOUMsUUFBUTtRQUNSLEtBQUs7SUFDVCxDQUFDO0lBRUQsZ0ZBQWdGO0lBRWhGLDRCQUE0QjtJQUM1QiwrREFBK0Q7SUFDL0QsSUFBSTtJQUVKLDhCQUE4QjtJQUM5QixrRUFBa0U7SUFDbEUsSUFBSTtJQUVKLDhCQUE4QjtJQUM5Qix5Q0FBeUM7SUFDekMsK0NBQStDO0lBQy9DLDZCQUE2QjtJQUM3QixlQUFlO0lBQ2YsSUFBSTtJQUVKLDZGQUE2RjtJQUU3Rix1RUFBdUU7SUFDdkUsbUNBQW1DO0lBRW5DLGdEQUFnRDtJQUVoRCxnRkFBZ0Y7SUFDaEYsNkNBQTZDO0lBQzdDLGlDQUFpQztJQUNqQyxjQUFjO0lBQ2QsVUFBVTtJQUNWLG1GQUFtRjtJQUNuRiw2Q0FBNkM7SUFDN0MsaUNBQWlDO0lBQ2pDLGNBQWM7SUFDZCxVQUFVO0lBQ1YsZ0RBQWdEO0lBQ2hELGlCQUFpQjtJQUNqQixnQ0FBZ0M7SUFDaEMsWUFBWTtJQUNaLG1DQUFtQztJQUNuQyxpQ0FBaUM7SUFDakMsY0FBYztJQUVkLDJDQUEyQztJQUMzQywyQ0FBMkM7SUFDM0MseUNBQXlDO0lBRXpDLDhCQUE4QjtJQUM5QixJQUFJO0lBRUosc0VBQXNFO0lBQ3RFLGlEQUFpRDtJQUNqRCxpREFBaUQ7SUFDakQsd0RBQXdEO0lBQ3hELFVBQVU7SUFDVixJQUFJO0lBRUosdUZBQXVGO0lBRS9FLFVBQVUsQ0FBQyxPQUFxQixFQUFFLGNBQXdCO1FBQzlELG1DQUFtQztRQUNuQyxJQUFJLENBQUMsTUFBTSxHQUFHLElBQUksQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxjQUFjLENBQUMsQ0FBQyxDQUFDO1FBQ3pELElBQUksQ0FBQyxRQUFRLENBQUMsaUJBQWlCLENBQUMsSUFBSSxDQUFDLE1BQU0sRUFBRSxPQUFPLElBQUksRUFBRSxDQUFDLENBQUM7UUFFNUQsd0dBQXdHO1FBQ3hHLElBQUksY0FBYztZQUFFLE9BQU87UUFFM0IsSUFBSSxDQUFDLGFBQWEsQ0FBQyxPQUFPLENBQUMsQ0FBQztRQUU1QixJQUFJLENBQUMsYUFBYSxHQUFHLEtBQUssQ0FBQztRQUUzQixJQUFJLENBQUMsY0FBYyxFQUFFLENBQUM7UUFFdEIsSUFBSSxDQUFDLG1CQUFtQixFQUFFLENBQUM7UUFFM0IsSUFBSSxDQUFDLGNBQWMsRUFBRSxDQUFDO1FBR3RCLG9DQUFvQztRQUNwQyxJQUFJLENBQUMsU0FBUyxDQUFDLE1BQU0sR0FBRyxPQUFPLENBQUM7SUFDcEMsQ0FBQztJQUVNLGFBQWEsQ0FBQyxPQUFxQjtRQUN0QyxJQUFJLENBQUMsd0JBQXdCLEdBQUcsQ0FBQyxPQUFPLENBQUMsS0FBSyxDQUFDLFFBQVEsQ0FBQyxLQUFLLENBQUMsYUFBYSxDQUFDLENBQUM7UUFDN0UsSUFBSSxPQUFPLENBQUMsS0FBSyxDQUFDLFFBQVEsQ0FBQyxLQUFLLENBQUMsYUFBYSxDQUFDLElBQUksT0FBTyxDQUFDLEtBQUssQ0FBQyxRQUFRLENBQUMsS0FBSyxDQUFDLGFBQWEsQ0FBQyxLQUFLLEtBQUssRUFBRTtZQUN0RyxJQUFJLENBQUMsd0JBQXdCLEdBQUcsSUFBSSxDQUFDO1NBQ3hDO0lBQ0wsQ0FBQztJQUVELG9GQUFvRjtJQUM1RSxjQUFjO1FBRWxCLG9EQUFvRDtRQUNwRCxJQUFJLENBQUMsWUFBWSxDQUFDLGVBQWUsQ0FBQyxHQUFHLEVBQUUsQ0FBQztRQUN4QyxJQUFJLENBQUMsWUFBWSxDQUFDLGlCQUFpQixDQUFDLEdBQUcsRUFBRSxDQUFDO1FBRTFDLElBQUksT0FBTyxJQUFJLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxLQUFLLEtBQUssU0FBUyxJQUFJLElBQUksQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLEtBQUssRUFBRTtZQUMzRSxJQUFJLENBQUMsWUFBWSxDQUFDLGFBQWEsSUFBSSxlQUFlLENBQUM7WUFDbkQsSUFBSSxDQUFDLFlBQVksQ0FBQyxlQUFlLElBQUksZUFBZSxDQUFDO1NBQ3hEO1FBRUQsSUFBSSxPQUFPLElBQUksQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLGFBQWEsS0FBSyxTQUFTLEVBQUU7WUFDdkQsSUFBSSxDQUFDLFlBQVksQ0FBQyxhQUFhLElBQUksSUFBSSxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsYUFBYSxHQUFHLEdBQUcsQ0FBQztZQUMxRSxJQUFJLENBQUMsWUFBWSxDQUFDLGVBQWUsSUFBSSxJQUFJLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxhQUFhLEdBQUcsR0FBRyxDQUFDO1NBQy9FO1FBRUQsSUFBSSxPQUFPLElBQUksQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLEtBQUssS0FBSyxTQUFTLEVBQUU7WUFDL0MsSUFBSSxDQUFDLFlBQVksQ0FBQyxhQUFhLElBQUksSUFBSSxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsS0FBSyxHQUFHLEdBQUcsQ0FBQztZQUNsRSxJQUFJLENBQUMsWUFBWSxDQUFDLGVBQWUsSUFBSSxJQUFJLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxLQUFLLEdBQUcsR0FBRyxDQUFDO1NBQ3ZFO1FBRUQsSUFBSSxJQUFJLENBQUMsYUFBYSxLQUFLLEtBQUssSUFBSSxJQUFJLENBQUMsYUFBYSxLQUFLLEtBQUs7WUFBRSxPQUFPO1FBQ3pFLElBQUksQ0FBQyxhQUFhLEdBQUcsSUFBSSxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsUUFBUSxDQUFDO1FBRWhELHVEQUF1RDtRQUN2RCxJQUFJLENBQUMsWUFBWSxHQUFHLElBQUksQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLEtBQUssS0FBSyxJQUFJLElBQUksQ0FBQyxTQUFTLENBQUMsdUJBQXVCLENBQUMsSUFBSSxDQUFDLFNBQVMsRUFBRSxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUM7UUFDdkgsSUFBSSxDQUFDLFlBQVksR0FBRyxJQUFJLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxLQUFLLEtBQUssSUFBSSxJQUFJLENBQUMsU0FBUyxDQUFDLHVCQUF1QixDQUFDLElBQUksQ0FBQyxTQUFTLEVBQUUsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDO1FBRXZILHlFQUF5RTtRQUN6RSxJQUFJLENBQUMsZUFBZSxHQUFHLElBQUksQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLEtBQUssS0FBSyxDQUFDO1FBQ25ELElBQUksQ0FBQyxzQkFBc0IsR0FBRyxJQUFJLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsTUFBTSxHQUFHLENBQUMsQ0FBQyxLQUFLLE9BQU8sQ0FBQztRQUNwRixJQUFJLENBQUMsZUFBZSxHQUFHLENBQUMsSUFBSSxDQUFDLGFBQWEsS0FBSyxLQUFLLElBQUksSUFBSSxDQUFDLGFBQWEsS0FBSyxRQUFRLENBQUUsSUFBSSxJQUFJLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxLQUFLLE9BQU8sSUFBSSxJQUFJLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxLQUFLLFVBQVUsQ0FBQztJQUNuSyxDQUFDO0lBRU8sMEJBQTBCLENBQUMsU0FBUyxFQUFFLE1BQWU7UUFDekQsSUFBSSxRQUFRLEdBQVcsU0FBUyxFQUFFLFlBQXlCLENBQUM7UUFDNUQsa0RBQWtEO1FBQ2xELElBQUksQ0FBQyxRQUFRLEVBQUU7WUFDWCxnQ0FBZ0M7WUFDaEMsSUFBSSxNQUFNLEtBQUssSUFBSSxJQUFJLE1BQU0sS0FBSyxTQUFTO2dCQUFFLE9BQU87WUFDcEQsUUFBUSxHQUFHLElBQUksQ0FBQyxVQUFVLENBQUMsTUFBTSxDQUFDLENBQUM7U0FDdEM7UUFDRCxZQUFZLEdBQUcsSUFBSSxDQUFDLFVBQVUsQ0FBQyxRQUFRLENBQUMsQ0FBQztRQUN6QyxJQUFJLENBQUMsaUJBQWlCLENBQUMsUUFBUSxFQUFFLFlBQVksQ0FBQyxDQUFDO0lBQ25ELENBQUM7SUFHTyxtQkFBbUIsQ0FBQyxLQUFjO1FBQ3RDLElBQUksQ0FBQyxJQUFJLENBQUMsVUFBVTtZQUFFLE9BQU87UUFFN0IsSUFBSSxDQUFDLFVBQVUsR0FBRyxNQUFNLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsQ0FBQztRQUUvQyxLQUFLLElBQUksQ0FBQyxHQUFXLENBQUMsRUFBRSxDQUFDLEdBQUcsSUFBSSxDQUFDLFVBQVUsQ0FBQyxNQUFNLEVBQUUsQ0FBQyxFQUFFLEVBQUU7WUFDckQsSUFBSSxRQUFRLEdBQVcsSUFBSSxDQUFDLFVBQVUsQ0FBQyxDQUFDLENBQUMsQ0FBQztZQUMxQyxJQUFJLFlBQVksR0FBZ0IsSUFBSSxDQUFDLFVBQVUsQ0FBQyxRQUFRLENBQUMsQ0FBQztZQUUxRCxvREFBb0Q7WUFDcEQsdUZBQXVGO1lBQ3ZGLG1EQUFtRDtZQUNuRCxvREFBb0Q7WUFDcEQseURBQXlEO1lBQ3pELHdGQUF3RjtZQUN4RixtREFBbUQ7WUFFbkQsK0RBQStEO1lBQy9ELHVEQUF1RDtZQUV2RCw2UEFBNlA7WUFDN1AsK0VBQStFO1lBRS9FLG1EQUFtRDtZQUNuRCxJQUFJLENBQUMsaUJBQWlCLENBQUMsUUFBUSxFQUFFLFlBQVksQ0FBQyxDQUFDO1NBQ2xEO0lBQ0wsQ0FBQztJQUVPLGNBQWM7UUFDbEIsSUFBSSxJQUFJLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsT0FBTyxFQUFFO1lBQ2xDLElBQUksVUFBVSxHQUFXLElBQUksQ0FBQyxTQUFTLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsQ0FBQztZQUVqRixJQUFJLENBQUMsZ0JBQWdCLENBQUMsVUFBVSxFQUFFLE9BQU8sRUFBRSxJQUFJLENBQUMsQ0FBQztTQUNwRDtJQUNMLENBQUM7SUFFTyxRQUFRLENBQUMsS0FBVTtRQUN2QixJQUFJLENBQUMsY0FBYyxHQUFHLEVBQUUsQ0FBQztRQUN6QixJQUFJLENBQUMsYUFBYSxHQUFHLEVBQUUsQ0FBQztRQUN4QixJQUFJLENBQUMsYUFBYSxDQUFDLEtBQUssQ0FBQyxDQUFDO1FBRTFCLElBQUksSUFBSSxDQUFDLE1BQU0sQ0FBQyxXQUFXLEVBQUU7WUFDekIsSUFBSSxDQUFDLElBQUksR0FBRyxLQUFLLENBQUM7WUFDbEIsSUFBSSxDQUFDLFVBQVUsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUM7WUFDN0IsT0FBTztTQUNWO1FBRUQsSUFBSSxJQUFJLENBQUMsYUFBYSxLQUFLLEtBQUssSUFBSSxJQUFJLENBQUMsYUFBYSxLQUFLLEtBQUssRUFBRTtZQUM5RCxJQUFJLElBQUksQ0FBQyxhQUFhLEtBQUssS0FBSztnQkFBRSxJQUFJLENBQUMsa0JBQWtCLENBQUMsS0FBSyxDQUFDLENBQUM7aUJBQzVELElBQUksSUFBSSxDQUFDLGFBQWEsS0FBSyxLQUFLO2dCQUFFLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxLQUFLLENBQUMsQ0FBQztZQUN0RSw0REFBNEQ7WUFDNUQsSUFBSSxDQUFDLFVBQVUsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUM7U0FDaEM7O1lBQU0sSUFBSSxDQUFDLFlBQVksQ0FBQyxLQUFLLENBQUMsQ0FBQztRQUVoQyxzREFBc0Q7UUFDdEQsSUFBSSxDQUFDLFVBQVUsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDO1FBRWhDLGdFQUFnRTtRQUNoRSxJQUFJLENBQUMsZ0JBQWdCLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsQ0FBQztJQUNoRCxDQUFDO0lBRU8sYUFBYSxDQUFDLEtBQUs7UUFDdkIsSUFBSSxTQUFTLEdBQVEsS0FBSyxDQUFDO1FBQzNCLElBQUksQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLFdBQVcsSUFBSSxDQUFDLEtBQUssQ0FBQyxLQUFLLElBQUksS0FBSyxDQUFDLEtBQUssQ0FBQyxJQUFJLElBQUksS0FBSyxDQUFDLEVBQUU7WUFDeEUsU0FBUyxHQUFHLEtBQUssQ0FBQyxLQUFLLENBQUM7U0FDM0I7UUFDRCxJQUFJLENBQUMsYUFBYSxHQUFHLFNBQVMsQ0FBQyxJQUFJLENBQUM7UUFDcEMsSUFBSSxDQUFDLFNBQVMsR0FBRyxTQUFTLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FBQztRQUM3QyxJQUFJLENBQUMsV0FBVyxHQUFHLFNBQVMsQ0FBQyxJQUFJLEtBQUssS0FBSyxJQUFJLFNBQVMsQ0FBQyxJQUFJLEtBQUssS0FBSyxDQUFDO0lBQzVFLENBQUM7SUFFTyxrQkFBa0IsQ0FBQyxNQUFjLEVBQUUsTUFBYztRQUNyRCxJQUFJLE1BQU0sR0FBRyxDQUFDLEVBQUU7WUFBRSxPQUFPO1NBQUU7UUFDM0IsNElBQTRJO1FBQzVJLElBQUksU0FBUyxHQUFrQixNQUFNLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsQ0FBQztRQUM1RCxJQUFJLElBQUksQ0FBQyxhQUFhLElBQUksS0FBSyxFQUFFO1lBQzdCLEtBQUssSUFBSSxNQUFNLEdBQVcsSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsTUFBTSxHQUFHLENBQUMsRUFBRSxNQUFNLElBQUksQ0FBQyxFQUFFLE1BQU0sRUFBRSxFQUFFO2dCQUN4RSxLQUFLLElBQUksTUFBTSxHQUFXLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLEdBQUcsQ0FBQyxFQUFFLE1BQU0sSUFBSSxDQUFDLEVBQUUsTUFBTSxFQUFFLEVBQUU7b0JBQ2xGLElBQUksSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLEVBQUUsS0FBSyxTQUFTLENBQUMsTUFBTSxDQUFDLEVBQUU7d0JBQzNELElBQUksQ0FBQyxhQUFhLENBQUMsTUFBTSxFQUFFLE1BQU0sRUFBRSxPQUFPLENBQUMsQ0FBQzt3QkFDNUMsSUFBSSxDQUFDLGFBQWEsQ0FBQyxNQUFNLEVBQUUsTUFBTSxFQUFFLE9BQU8sQ0FBQyxDQUFDO3FCQUMvQztpQkFDSjthQUNKO1NBQ0o7SUFDTCxDQUFDO0lBRU8sYUFBYSxDQUFDLE9BQWUsRUFBRSxPQUFlLEVBQUUsUUFBMkI7UUFDL0UsSUFBSSxRQUFRLEdBQVcsSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLEVBQUUsQ0FBQztRQUM3RCxJQUFJLE1BQU0sR0FBUSxJQUFJLENBQUMsVUFBVSxDQUFDLFFBQVEsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDO1FBQ3RELElBQUksUUFBUSxLQUFLLE9BQU8sRUFBRTtZQUN0QixNQUFNLEdBQUcsSUFBSSxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsQ0FBQztTQUNoQztRQUNELElBQUksSUFBSSxDQUFDLGVBQWUsQ0FBQyxPQUFPLEVBQUUsT0FBTyxFQUFFLFFBQVEsQ0FBQyxFQUFFO1lBQ2xELElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxRQUFRLENBQUMsR0FBRyxNQUFNLENBQUM7U0FDekQ7SUFDTCxDQUFDO0lBRU8sZUFBZSxDQUFDLE9BQWUsRUFBRSxPQUFlLEVBQUUsUUFBMkI7UUFDakYsSUFBSSxZQUFZLEdBQVksSUFBSSxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsY0FBYyxDQUFDLHdCQUF3QixDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLHNCQUFzQixDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUM7UUFDekksSUFBSSxZQUFZLEVBQUU7WUFDZCxPQUFPLElBQUksQ0FBQztTQUNmO2FBQU07WUFDSCxJQUFJLElBQUksQ0FBQyxTQUFTLENBQUMsTUFBTSxDQUFDLE9BQU8sQ0FBQyxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsQ0FBQyxjQUFjLENBQUMsUUFBUSxDQUFDLEVBQUU7Z0JBQ3ZFLElBQUksSUFBSSxDQUFDLFNBQVMsQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxDQUFDLFFBQVEsQ0FBQyxLQUFLLElBQUksSUFBSSxJQUFJLENBQUMsU0FBUyxDQUFDLE1BQU0sQ0FBQyxPQUFPLENBQUMsQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsTUFBTSxHQUFHLENBQUMsRUFBRTtvQkFDdEksT0FBTyxLQUFLLENBQUM7aUJBQ2hCO2FBQ0o7U0FDSjtRQUNELE9BQU8sSUFBSSxDQUFDO0lBQ2hCLENBQUM7SUFFTSxhQUFhLENBQUMsR0FBVztRQUM1QixJQUFJLFlBQVksR0FBZ0IsSUFBSSxDQUFDLFVBQVUsQ0FBQyxHQUFHLENBQUMsQ0FBQztRQUVyRCxZQUFZLENBQUMsUUFBUSxHQUFHLENBQUMsWUFBWSxDQUFDLFFBQVEsSUFBSSxLQUFLLENBQUM7UUFFeEQsSUFBSSxDQUFDLGlCQUFpQixDQUFDLEdBQUcsRUFBRSxZQUFZLENBQUMsQ0FBQztRQUUxQyxJQUFJLFlBQVksQ0FBQyxRQUFRLEVBQUU7WUFDdkIsSUFBSSxDQUFDLGNBQWMsQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUM7U0FDakM7YUFBTTtZQUNILElBQUksT0FBTyxHQUFXLElBQUksQ0FBQyxjQUFjLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxDQUFDO1lBQ3ZELElBQUksT0FBTyxLQUFLLENBQUMsQ0FBQyxFQUFFO2dCQUNoQixJQUFJLENBQUMsY0FBYyxDQUFDLE1BQU0sQ0FBQyxPQUFPLEVBQUUsQ0FBQyxDQUFDLENBQUM7YUFDMUM7U0FDSjtRQUVELElBQUksSUFBSSxDQUFDLGFBQWEsSUFBSSxLQUFLLEVBQUU7WUFDN0IsSUFBSSxVQUFVLEdBQW1DLElBQUksQ0FBQyxZQUFZLEVBQUUsQ0FBQztZQUNyRSxJQUFJLElBQUksR0FBWSxJQUFJLENBQUMsVUFBVSxDQUFDLFVBQVUsQ0FBQyxDQUFDO1lBRWhELElBQUksQ0FBQyxHQUFHLENBQUMsV0FBVyxDQUFDLElBQUksRUFBRSxVQUFVLENBQUMsQ0FBQztZQUN2QyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsR0FBRyxFQUFFLFlBQVksQ0FBQyxRQUFRLENBQUMsQ0FBQztZQUNsRCwyREFBMkQ7WUFDM0QsSUFBSSxDQUFDLFVBQVUsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUM7U0FDOUI7YUFBTTtZQUNILElBQUksQ0FBQyxHQUFHLENBQUMsV0FBVyxDQUFDLEdBQUcsRUFBRSxZQUFZLENBQUMsUUFBUSxDQUFDLENBQUM7U0FDcEQ7SUFFTCxDQUFDO0lBRU0sY0FBYyxDQUFDLEdBQVE7UUFDMUIsSUFBSSxnQkFBZ0IsR0FBZ0IsSUFBSSxDQUFDLFdBQVcsQ0FBQyxhQUFhLENBQUMsYUFBYSxDQUFDLFFBQVEsR0FBRyxHQUFHLENBQUMsRUFBRSxHQUFHLGtCQUFrQixDQUFDLENBQUM7UUFDekgsSUFBSSxlQUFlLEdBQWdCLElBQUksQ0FBQyxXQUFXLENBQUMsYUFBYSxDQUFDLGFBQWEsQ0FBQyxRQUFRLEdBQUcsR0FBRyxDQUFDLEVBQUUsR0FBRyxvQkFBb0IsQ0FBQyxDQUFDO1FBRTFILElBQUksQ0FBQyxHQUFHLENBQUMsWUFBWSxDQUFDLEdBQUcsRUFBRSxFQUFDLGtCQUFrQixFQUFFLGdCQUFnQixFQUFFLGlCQUFpQixFQUFFLGVBQWUsRUFBQyxDQUFDLENBQUM7SUFDM0csQ0FBQztJQUVNLGVBQWUsQ0FBQyxXQUEyQztRQUM5RCxJQUFJLElBQUksQ0FBQyxhQUFhLElBQUksS0FBSyxJQUFJLE1BQU0sQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFDLENBQUMsTUFBTSxJQUFJLENBQUMsRUFBRTtZQUNyRSxJQUFJLENBQUMsYUFBYSxHQUFHLElBQUksQ0FBQztTQUM3QjthQUFNO1lBQ0gsSUFBSSxDQUFDLFVBQVUsR0FBRyxXQUFXLENBQUM7WUFDOUIsSUFBSSxDQUFDLGFBQWEsR0FBRyxLQUFLLENBQUM7WUFDM0IsSUFBSSxDQUFDLFlBQVksR0FBRyxJQUFJLENBQUM7WUFDekIsSUFBSSxDQUFDLGdCQUFnQixDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLENBQUM7WUFDNUMsSUFBSSxDQUFDLG1CQUFtQixDQUFDLFNBQVMsQ0FBQyxDQUFDO1NBQ3ZDO0lBQ0wsQ0FBQztJQUVNLGFBQWEsQ0FBQyxLQUFVO1FBQzNCLCtCQUErQjtRQUMvQixJQUFJLENBQUMsVUFBVSxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQztJQUNoQyxDQUFDO0lBRU0sUUFBUSxDQUFDLE1BQWU7UUFDM0IsSUFBSSxDQUFDLGNBQWMsR0FBRyxNQUFNLENBQUM7SUFDakMsQ0FBQztJQUVPLGlCQUFpQixDQUFDLEdBQUcsRUFBRSxhQUFhO1FBQ3hDLElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxHQUFHLEVBQUUsYUFBYSxDQUFDLENBQUM7UUFDM0MsSUFBSSxTQUFTLEdBQVcsQ0FBQyxhQUFhLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxhQUFhLElBQUksU0FBUyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLEtBQUssSUFBSSxJQUFJLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsV0FBVyxJQUFJLFNBQVMsQ0FBQztRQUNoTSxJQUFJLENBQUMsV0FBVyxDQUFDLGFBQWEsQ0FBQyxhQUFhLENBQUMsUUFBUSxHQUFHLEdBQUcsQ0FBQyxDQUFDLEtBQUssQ0FBQyxLQUFLLEdBQUcsU0FBUyxDQUFDO0lBQ3pGLENBQUM7SUFFTyxpQkFBaUIsQ0FBQyxHQUFHLEVBQUUsYUFBYTtRQUN4QyxJQUFJLFNBQVMsR0FBVyxDQUFDLGFBQWEsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLGFBQWEsSUFBSSxTQUFTLENBQUMsQ0FBQyxDQUFDLGFBQWEsQ0FBQyxLQUFLLElBQUksU0FBUyxDQUFDO1FBQ3pJLElBQUksUUFBUSxHQUFXLElBQUksQ0FBQyxjQUFjLENBQUMsVUFBVSxDQUFDLFNBQVMsQ0FBQyxDQUFDO1FBQ2pFLElBQUksQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLEdBQUcsSUFBSSxDQUFDLFVBQVUsQ0FBQyw4QkFBOEIsQ0FBQyx3RUFBd0UsR0FBRyxRQUFRLEdBQUcsa0NBQWtDLEdBQUcsSUFBSSxDQUFDLE1BQU0sQ0FBQyxhQUFhLENBQUMsS0FBSyxDQUFDLEdBQUcsV0FBVyxDQUFDLENBQUM7SUFDaFAsQ0FBQztJQUVPLGdCQUFnQixDQUFDLEVBQVUsRUFBRSxRQUFpQjtRQUNsRCxJQUFJLFlBQVksR0FBVyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQztRQUN4RCxJQUFJLENBQUMsZ0JBQWdCLENBQUMsWUFBWSxFQUFFLEtBQUssR0FBRyxFQUFFLENBQUMsQ0FBQztRQUNoRCxJQUFJLENBQUMsUUFBUTtZQUFFLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxVQUFVLEdBQUcsWUFBWSxFQUFFLEtBQUssR0FBRyxFQUFFLEdBQUcsT0FBTyxFQUFFLElBQUksQ0FBQyxDQUFDO0lBQ2hHLENBQUM7SUFFTyxnQkFBZ0IsQ0FBQyxNQUFjLEVBQUUsTUFBYyxFQUFFLGVBQXlCO1FBQzlFLE1BQU0sR0FBRyxNQUFNLElBQUksRUFBRSxDQUFDO1FBQ3RCLElBQUksUUFBUSxHQUFnQixJQUFJLENBQUMsV0FBVyxDQUFDLGFBQWEsQ0FBQyxnQkFBZ0IsQ0FBQyxHQUFHLEdBQUcsSUFBSSxDQUFDLE1BQU0sQ0FBQyxFQUFFLEdBQUcseUJBQXlCLEdBQUcsTUFBTSxDQUFDLENBQUM7UUFDdkksS0FBSyxJQUFJLENBQUMsSUFBSSxRQUFRLEVBQUU7WUFDcEIsSUFBSSxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxFQUFFO2dCQUVuQixJQUFJLGVBQWUsRUFBRTtvQkFDakIsSUFBSSxVQUFVLEdBQVcsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLFdBQVcsQ0FBQztvQkFDakQsSUFBSSxXQUFXLEdBQVcsQ0FBQyxVQUFVLEdBQUcsVUFBVSxHQUFHLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUMsUUFBUSxFQUFFLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDO29CQUNsRyxJQUFJLGFBQWEsR0FBVyxDQUFDLEdBQUcsV0FBVyxDQUFDO29CQUU1QyxNQUFNLElBQUksT0FBTyxHQUFHLGFBQWEsR0FBRyxLQUFLLENBQUM7b0JBQzFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLEdBQUcsTUFBTSxDQUFDO2lCQUM5QjtxQkFBTTtvQkFDSCxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLE9BQU8sR0FBRyxNQUFNLENBQUM7aUJBQ3RDO2FBQ0o7U0FDSjtJQUNMLENBQUM7SUFFTyxZQUFZO1FBQ2hCLElBQUksVUFBVSxHQUFtQyxNQUFNLENBQUMsTUFBTSxDQUFDLEVBQUUsRUFBRSxJQUFJLENBQUMsVUFBVSxDQUFDLENBQUM7UUFDcEYsSUFBSSxjQUFjLEdBQWtCLElBQUksQ0FBQyxjQUFjLENBQUM7UUFDeEQsVUFBVSxHQUFHLE1BQU0sQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDO2FBQy9CLE1BQU0sQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLENBQUMsY0FBYyxDQUFDLFFBQVEsQ0FBQyxHQUFHLENBQUMsQ0FBQzthQUM1QyxNQUFNLENBQUMsQ0FBQyxHQUFHLEVBQUUsR0FBRyxFQUFFLEVBQUU7WUFDakIsR0FBRyxDQUFDLEdBQUcsQ0FBQyxHQUFHLFVBQVUsQ0FBQyxHQUFHLENBQUMsQ0FBQztZQUMzQixPQUFPLEdBQUcsQ0FBQztRQUNmLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQztRQUNYLE9BQU8sVUFBVSxDQUFDO0lBQ3RCLENBQUM7SUFFTyxVQUFVLENBQUMsV0FBNEM7UUFDM0QsSUFBSSxRQUFRLEdBQVksSUFBSSxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDO1FBQzlELElBQUksY0FBYyxHQUFrQixJQUFJLENBQUMsY0FBYyxDQUFDO1FBRXhELElBQUksSUFBSSxDQUFDLGFBQWEsS0FBSyxLQUFLLEVBQUU7WUFDOUIsSUFBSSxVQUFVLEdBQVEsV0FBVyxDQUFDO1lBQ2xDLDBDQUEwQztZQUMxQyxRQUFRLENBQUMsSUFBSSxHQUFHLE1BQU0sQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsVUFBVSxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsS0FBSyxFQUFFLEVBQUUsQ0FBQyxLQUFLLENBQUMsQ0FBQyxJQUFJLEtBQUssQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUM7WUFDOUcsT0FBTyxRQUFRLENBQUM7U0FDbkI7YUFBTSxJQUFJLElBQUksQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLEtBQUssS0FBSyxJQUFJLElBQUksQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLEtBQUssTUFBTSxFQUFFO1lBQ3BFLEtBQUssSUFBSSxDQUFDLEdBQVcsUUFBUSxDQUFDLElBQUksQ0FBQyxNQUFNLEdBQUcsQ0FBQyxFQUFFLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxFQUFFLEVBQUU7Z0JBQ3hELElBQUksT0FBTyxHQUFvQixRQUFRLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLGNBQWMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUM7Z0JBQzlGLFFBQVEsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLEdBQUcsTUFBTSxDQUFDLE1BQU0sQ0FBQyxFQUFFLEVBQUUsUUFBUSxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsRUFBRSxFQUFFLENBQUMsRUFBRSxPQUFPLEVBQUUsQ0FBQyxDQUFDO2FBQzFFO1NBQ0o7UUFFRCxJQUFJLFlBQVksR0FBWSxJQUFJLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQztRQUVqRSxJQUFJLFlBQVksR0FBa0IsQ0FBQyxDQUFDLENBQUMsQ0FBQztRQUN0QyxJQUFJLFlBQVksR0FBa0IsQ0FBQyxDQUFDLENBQUMsQ0FBQztRQUN0QyxJQUFJLFlBQVksR0FBWSxLQUFLLENBQUM7UUFFbEMsS0FBSyxJQUFJLENBQUMsR0FBVyxDQUFDLEVBQUUsQ0FBQyxHQUFHLFlBQVksQ0FBQyxJQUFJLENBQUMsTUFBTSxFQUFFLENBQUMsRUFBRSxFQUFFO1lBQ3ZELElBQUksUUFBUSxHQUFXLENBQUMsQ0FBQztZQUN6QixJQUFJLElBQUksQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLEtBQUssS0FBSyxFQUFFO2dCQUM3QixRQUFRLEdBQUcsUUFBUSxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsR0FBRyxFQUFFLElBQUksRUFBRSxNQUFNLEVBQUUsRUFBRTtvQkFDdkQsSUFBSSxjQUFjLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUM7d0JBQUUsT0FBTyxHQUFHLENBQUM7b0JBQ2pELE9BQU8sR0FBRyxHQUFHLElBQUksQ0FBQyxLQUFLLENBQUM7Z0JBQzVCLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQzthQUNUO1lBRUQsSUFBSSxPQUFPLEdBQWUsRUFBRSxDQUFDO1lBQzdCLElBQUksTUFBTSxHQUFrQixFQUFFLENBQUM7WUFDL0IsSUFBSSxHQUFHLEdBQVcsQ0FBQyxDQUFDO1lBQ3BCLElBQUksV0FBVyxHQUFXLENBQUMsQ0FBQztZQUU1QixLQUFLLElBQUksTUFBTSxHQUFXLENBQUMsRUFBRSxNQUFNLEdBQUcsWUFBWSxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxFQUFFLE1BQU0sRUFBRSxFQUFFO2dCQUMzRSxJQUFJLEtBQUssR0FBYSxNQUFNLENBQUMsTUFBTSxDQUFDLEVBQUUsRUFBRSxZQUFZLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDO2dCQUN4RSxJQUFJLGNBQWMsQ0FBQyxRQUFRLENBQUMsS0FBSyxDQUFDLEVBQUUsQ0FBQztvQkFBRSxTQUFTO2dCQUNoRCxJQUFJLFVBQVUsR0FBVyxLQUFLLENBQUMsS0FBSyxLQUFLLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDO2dCQUNoRSxJQUFJLFFBQVEsR0FBVyxJQUFJLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxDQUFDO2dCQUU3QyxJQUFJLFFBQVEsR0FBRyxDQUFDLElBQUksQ0FBQyxZQUFZLEVBQUU7b0JBQy9CLFlBQVksR0FBRyxJQUFJLENBQUM7b0JBQ3BCLElBQUksSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsS0FBSyxLQUFLLEVBQUU7d0JBQzdCLElBQUksQ0FBQyxTQUFTLEdBQUcsSUFBSSxDQUFDO3dCQUN0QixNQUFNO3FCQUNUO2lCQUNKO2dCQUVELElBQUksSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsS0FBSyxLQUFLLElBQUksSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsS0FBSyxPQUFPLEVBQUU7b0JBQzlELElBQUksUUFBUSxJQUFJLENBQUMsRUFBRTt3QkFDZixHQUFHLEdBQUcsQ0FBQyxVQUFVLEtBQUssSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsR0FBRyxHQUFHLFVBQVUsQ0FBQztxQkFDeEQ7eUJBQU07d0JBQ0gsV0FBVyxHQUFHLENBQUMsVUFBVSxLQUFLLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDLFdBQVcsR0FBRyxVQUFVLENBQUM7cUJBQ2hGO2lCQUNKO3FCQUFNLElBQUksSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsS0FBSyxLQUFLLEVBQUU7b0JBQ3BDLElBQUksVUFBVSxLQUFLLElBQUksSUFBSSxRQUFRLEtBQUssQ0FBQyxFQUFFO3dCQUN2QyxVQUFVLEdBQUcsVUFBVSxHQUFHLFFBQVEsR0FBRyxHQUFHLENBQUM7d0JBQ3pDLEdBQUcsR0FBRyxHQUFHLEdBQUcsVUFBVSxDQUFDO3FCQUMxQjt5QkFBTTt3QkFDSCxHQUFHLEdBQUcsR0FBRyxDQUFDO3FCQUNiO2lCQUNKO3FCQUFNO29CQUNILElBQUksUUFBUSxJQUFJLENBQUMsRUFBRTt3QkFDZixHQUFHLEdBQUcsQ0FBQyxVQUFVLEtBQUssSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsVUFBVSxDQUFDO3FCQUNoRDt5QkFBTTt3QkFDSCxXQUFXLEdBQUcsQ0FBQyxVQUFVLEtBQUssSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsVUFBVSxDQUFDO3FCQUN4RDtpQkFDSjtnQkFDRCxLQUFLLENBQUMsR0FBRyxHQUFHLFVBQVUsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsV0FBVyxDQUFDO2dCQUVoRCxrSEFBa0g7Z0JBQ2xILElBQUksSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsS0FBSyxLQUFLO29CQUFFLEtBQUssQ0FBQyxXQUFXLENBQUMsR0FBRyxVQUFVLENBQUM7Z0JBRWpFLE1BQU0sQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUM7Z0JBQzNELE9BQU8sQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLENBQUM7YUFDdkI7WUFDRCxZQUFZLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsYUFBYSxDQUFDLE1BQU0sRUFBRSxLQUFLLENBQUMsQ0FBQyxDQUFDO1lBQy9ELFlBQVksQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxhQUFhLENBQUMsTUFBTSxFQUFFLEtBQUssQ0FBQyxDQUFDLENBQUM7WUFDL0QsUUFBUSxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsR0FBRyxNQUFNLENBQUMsTUFBTSxDQUFDLEVBQUUsRUFBRSxZQUFZLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxFQUFFLE9BQU8sRUFBRSxDQUFDLENBQUM7U0FDOUU7UUFFRCxRQUFRLENBQUMsT0FBTyxDQUFDLEdBQUc7WUFDaEIsR0FBRyxFQUFFLElBQUksQ0FBQyxTQUFTLENBQUMsYUFBYSxDQUFDLFlBQVksRUFBRSxLQUFLLENBQUM7WUFDdEQsR0FBRyxFQUFFLElBQUksQ0FBQyxTQUFTLENBQUMsYUFBYSxDQUFDLFlBQVksRUFBRSxLQUFLLENBQUM7U0FDekQsQ0FBQztRQUNGLFFBQVEsQ0FBQyxjQUFjLENBQUMsR0FBRyxZQUFZLENBQUM7UUFFeEMsT0FBTyxRQUFRLENBQUM7SUFDcEIsQ0FBQztJQUVPLG1CQUFtQixDQUFDLEtBQWlCLEVBQUUsZUFBdUI7UUFDbEUsMENBQTBDO1FBQzFDLElBQUksQ0FBQyxVQUFVLEdBQUcsRUFBRSxDQUFDO1FBQ3JCLDBCQUEwQjtRQUUxQixJQUFJLGNBQWMsR0FBVyxFQUFFLENBQUM7UUFDaEMsSUFBSSxRQUFnQixFQUFFLGFBQTBCLENBQUM7UUFDakQsSUFBSSxVQUFVLEdBQW1DLEVBQUUsQ0FBQztRQUNwRCxLQUFLLElBQUksQ0FBQyxHQUFXLENBQUMsRUFBRSxDQUFDLEdBQUcsZUFBZSxFQUFFLENBQUMsRUFBRSxFQUFFO1lBQzlDLFFBQVEsR0FBRyxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLElBQUksS0FBSyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxJQUFJLEdBQUcsQ0FBQyxDQUFDO1lBQzNGLGFBQWEsR0FBRztnQkFDWixNQUFNLEVBQUUsS0FBSyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJO2dCQUM1QixJQUFJLEVBQUUsUUFBUTtnQkFDZCxPQUFPLEVBQUUsS0FBSyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLElBQUksSUFBSSxDQUFDLGlCQUFpQixDQUFDLE9BQU8sRUFBRSxDQUFDLENBQUM7Z0JBQ3BFLE9BQU8sRUFBRSxLQUFLLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssSUFBSSxJQUFJLENBQUMsaUJBQWlCLENBQUMsT0FBTyxFQUFFLENBQUMsQ0FBQzthQUN2RSxDQUFDO1lBQ0YsSUFBSSxJQUFJLENBQUMsYUFBYSxLQUFLLE1BQU0sSUFBSSxJQUFJLENBQUMsYUFBYSxLQUFLLFFBQVEsSUFBSSxJQUFJLENBQUMsYUFBYSxLQUFLLE1BQU0sSUFBSSxJQUFJLENBQUMsYUFBYSxLQUFLLEtBQUssRUFBRTtnQkFDbkksYUFBYSxDQUFDLFlBQVksQ0FBQyxHQUFHLENBQUMsT0FBTyxLQUFLLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLFVBQVUsS0FBSyxXQUFXLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxVQUFVLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQztnQkFDdEgsYUFBYSxDQUFDLGdCQUFnQixDQUFDLEdBQUcsQ0FBQyxPQUFPLEtBQUssQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsY0FBYyxLQUFLLFdBQVcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLGNBQWMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO2dCQUMvSCxhQUFhLENBQUMsZ0JBQWdCLENBQUMsR0FBRyxDQUFDLE9BQU8sS0FBSyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxjQUFjLEtBQUssV0FBVyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsY0FBYyxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUM7Z0JBQ3ZJLElBQUksSUFBSSxDQUFDLGFBQWEsS0FBSyxLQUFLO29CQUFFLGFBQWEsQ0FBQyxXQUFXLENBQUMsR0FBRyxDQUFDLE9BQU8sS0FBSyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxTQUFTLEtBQUssV0FBVyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUM7YUFDM0o7WUFDRCxVQUFVLENBQUMsUUFBUSxDQUFDLEdBQUcsYUFBYSxDQUFDO1lBQ3JDLGNBQWMsQ0FBQyxDQUFDLENBQUMsR0FBRyxRQUFRLENBQUM7U0FDaEM7UUFDRCxJQUFJLENBQUMsVUFBVSxHQUFHLFVBQVUsQ0FBQztRQUM3QixPQUFPLGNBQWMsQ0FBQztJQUMxQixDQUFDO0lBRU8sWUFBWSxDQUFDLEtBQWlCO1FBQ2xDLElBQUksWUFBWSxHQUFXLElBQUksQ0FBQyxTQUFTLENBQUMsYUFBYSxDQUFDLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxNQUFNLEVBQUUsSUFBSSxDQUFDLGVBQWUsQ0FBQyxFQUFFLEtBQUssQ0FBQyxDQUFDO1FBQzVHLElBQUksWUFBeUIsRUFBRSxrQkFBNEIsQ0FBQztRQUM1RCxJQUFJLFNBQVMsR0FBWTtZQUNyQixNQUFNLEVBQUUsS0FBSyxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSTtZQUN4RCxRQUFRLEVBQUUsS0FBSyxDQUFDLEtBQUssQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSTtZQUM5RCxRQUFRLEVBQUUsSUFBSSxDQUFDLE1BQU0sQ0FBQyxXQUFXLElBQUksSUFBSSxDQUFDLE1BQU0sQ0FBQyxXQUFXLENBQUMsY0FBYyxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxXQUFXLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFO1lBQ3BKLE1BQU0sRUFBRSxFQUFFO1NBQ2IsQ0FBQztRQUNGLElBQUksQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLGNBQWMsQ0FBQyxJQUFJLENBQUMsRUFBRTtZQUNuQyxJQUFJLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxHQUFHLEtBQUssQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLEdBQUcsSUFBSSxDQUFDLENBQUMsQ0FBQyxXQUFXLENBQUM7U0FDdEY7UUFFRCxJQUFJLFVBQVUsR0FBa0IsSUFBSSxDQUFDLFNBQVMsQ0FBQyxvQkFBb0IsQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLFVBQVUsRUFBRSxJQUFJLENBQUMsVUFBVSxDQUFDLENBQUM7UUFFN0csSUFBSSxjQUFjLEdBQVcsSUFBSSxDQUFDLG1CQUFtQixDQUFDLEtBQUssRUFBRSxZQUFZLENBQUMsQ0FBQztRQUUzRSxJQUFJLFdBQVcsR0FBMkIsSUFBSSxDQUFDLFlBQVksQ0FBQyxLQUFLLEVBQUUsWUFBWSxDQUFDLENBQUM7UUFDakYsSUFBSSxZQUFZLEdBQWtCLENBQUMsQ0FBQyxDQUFDLENBQUM7UUFDdEMsSUFBSSxZQUFZLEdBQWtCLENBQUMsQ0FBQyxDQUFDLENBQUM7UUFDdEMsSUFBSSxZQUFZLEdBQVksS0FBSyxDQUFDO1FBRWxDLEtBQUssSUFBSSxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsR0FBRyxVQUFVLENBQUMsTUFBTSxFQUFFLENBQUMsRUFBRSxFQUFFO1lBQ3hDLFlBQVksR0FBRztnQkFDWCxHQUFHLEVBQUU7b0JBQ0QsS0FBSyxFQUFFLENBQUMsQ0FBQyxRQUFRLEVBQUU7b0JBQ25CLEtBQUssRUFBRSxVQUFVLENBQUMsQ0FBQyxDQUFDO2lCQUN2QjtnQkFDRCxHQUFHLEVBQUUsRUFBRTthQUVWLENBQUM7WUFFRixJQUFJLE1BQU0sR0FBa0IsRUFBRSxDQUFDO1lBQy9CLElBQUksR0FBRyxHQUFXLENBQUMsQ0FBQztZQUNwQixJQUFJLFdBQVcsR0FBVyxDQUFDLENBQUM7WUFFNUIsSUFBSSxXQUFXLEdBQWlCLElBQUksQ0FBQyxTQUFTLENBQUMsY0FBYyxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsa0JBQWtCLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxFQUFFLFlBQVksQ0FBQyxDQUFDO1lBRS9ILG1EQUFtRDtZQUNuRCxLQUFLLElBQUksQ0FBQyxHQUFXLFdBQVcsQ0FBQyxLQUFLLEVBQUUsV0FBVyxDQUFDLEtBQUssQ0FBQyxDQUFDLEVBQUUsV0FBVyxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsR0FBRyxXQUFXLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxFQUFFO2dCQUN2RyxJQUFJLE9BQU8sS0FBSyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLEtBQUssV0FBVztvQkFBRSxTQUFTO2dCQUU3RCxJQUFJLFVBQVUsR0FBa0IsS0FBSyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDO2dCQUM5RCxJQUFJLFFBQVEsR0FBVyxJQUFJLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxDQUFDO2dCQUU3QyxJQUFJLE9BQU8sVUFBVSxLQUFLLFdBQVc7b0JBQUUsU0FBUztnQkFFaEQsSUFBSSxRQUFRLEdBQUcsQ0FBQyxJQUFJLENBQUMsWUFBWSxFQUFFO29CQUMvQixZQUFZLEdBQUcsSUFBSSxDQUFDO29CQUNwQixJQUFJLElBQUksQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLEtBQUssS0FBSzt3QkFBRSxNQUFNO2lCQUMxQztnQkFFRCxJQUFJLElBQUksQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLEtBQUssS0FBSyxJQUFJLElBQUksQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLEtBQUssT0FBTyxFQUFFO29CQUM5RCxJQUFJLFFBQVEsSUFBSSxDQUFDLEVBQUU7d0JBQ2YsR0FBRyxHQUFHLENBQUMsVUFBVSxLQUFLLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLEdBQUcsR0FBRyxVQUFVLENBQUM7cUJBQ3hEO3lCQUFNO3dCQUNILFdBQVcsR0FBRyxDQUFDLFVBQVUsS0FBSyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQyxXQUFXLEdBQUcsVUFBVSxDQUFDO3FCQUNoRjtpQkFDSjtxQkFBTSxJQUFJLElBQUksQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLEtBQUssS0FBSyxFQUFFO29CQUNwQyxJQUFJLFVBQVUsS0FBSyxJQUFJLElBQUksV0FBVyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsRUFBRTt3QkFDN0MsVUFBVSxHQUFHLFVBQVUsR0FBRyxXQUFXLENBQUMsQ0FBQyxDQUFDLEdBQUcsR0FBRyxDQUFDO3FCQUNsRDt5QkFBTTt3QkFDSCxVQUFVLEdBQUcsQ0FBQyxDQUFDO3FCQUNsQjtvQkFDRCxHQUFHLEdBQUcsR0FBRyxHQUFHLFVBQVUsQ0FBQztpQkFDMUI7cUJBQU07b0JBQ0gsSUFBSSxRQUFRLElBQUksQ0FBQyxFQUFFO3dCQUNmLEdBQUcsR0FBRyxDQUFDLFVBQVUsS0FBSyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxVQUFVLENBQUM7cUJBQ2hEO3lCQUFNO3dCQUNILFdBQVcsR0FBRyxDQUFDLFVBQVUsS0FBSyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxVQUFVLENBQUM7cUJBQ3hEO2lCQUNKO2dCQUVELGtCQUFrQixHQUFHO29CQUNqQixLQUFLLEVBQUUsVUFBVSxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxXQUFXO29CQUMxQyxPQUFPLEVBQUUsS0FBSyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSztvQkFDdEMsT0FBTyxFQUFFLElBQUksQ0FBQyxVQUFVLENBQUMsT0FBTyxFQUFFLENBQUMsRUFBRSxLQUFLLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQztvQkFDN0QsT0FBTyxFQUFFLElBQUksQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxPQUFPLEVBQUUsQ0FBQyxFQUFFLEtBQUssQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7b0JBQzFFLElBQUksRUFBRSxjQUFjLENBQUMsQ0FBQyxDQUFDO2lCQUMxQixDQUFDO2dCQUVGLGtIQUFrSDtnQkFDbEgsSUFBSSxJQUFJLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxLQUFLLEtBQUs7b0JBQUUsa0JBQWtCLENBQUMsV0FBVyxDQUFDLEdBQUcsVUFBVSxDQUFDO2dCQUU5RSxNQUFNLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDO2dCQUMzRCxZQUFZLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxDQUFDO2FBQzNDO1lBRUQsWUFBWSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLGFBQWEsQ0FBQyxNQUFNLEVBQUUsS0FBSyxDQUFDLENBQUMsQ0FBQztZQUMvRCxZQUFZLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsYUFBYSxDQUFDLE1BQU0sRUFBRSxLQUFLLENBQUMsQ0FBQyxDQUFDO1lBRS9ELFNBQVMsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLFlBQVksQ0FBQyxDQUFDO1NBQ3JDO1FBRUQsSUFBSSxLQUFLLENBQUMsS0FBSyxDQUFDLElBQUksS0FBSyxLQUFLLEVBQUU7WUFDNUIsU0FBUyxDQUFDLE9BQU8sQ0FBQyxHQUFHO2dCQUNqQixHQUFHLEVBQUUsSUFBSSxDQUFDLFNBQVMsQ0FBQyxhQUFhLENBQUMsWUFBWSxFQUFFLEtBQUssQ0FBQztnQkFDdEQsR0FBRyxFQUFFLElBQUksQ0FBQyxTQUFTLENBQUMsYUFBYSxDQUFDLFlBQVksRUFBRSxLQUFLLENBQUM7YUFDekQsQ0FBQztZQUNGLFNBQVMsQ0FBQyxjQUFjLENBQUMsR0FBRyxZQUFZLENBQUM7U0FDNUM7UUFFRCxJQUFJLENBQUMsSUFBSSxHQUFHLFNBQVMsQ0FBQztRQUN0QixJQUFJLENBQUMsU0FBUyxHQUFHLElBQUksQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLEtBQUssS0FBSyxJQUFJLFlBQVksQ0FBQztRQUM3RCxJQUFJLENBQUMsVUFBVSxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQztJQUNqQyxDQUFDO0lBRU8sa0JBQWtCLENBQUMsS0FBSztRQUM1QixJQUFJLEtBQUssS0FBSyxTQUFTLElBQUksS0FBSyxLQUFLLElBQUksRUFBRTtZQUN2QyxJQUFJLFNBQVMsR0FBWTtnQkFDckIsTUFBTSxFQUFFLEtBQUssQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUk7Z0JBQ3hELFFBQVEsRUFBRSxLQUFLLENBQUMsS0FBSyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJO2dCQUM5RCxRQUFRLEVBQUUsSUFBSSxDQUFDLE1BQU0sQ0FBQyxXQUFXLElBQUksSUFBSSxDQUFDLE1BQU0sQ0FBQyxXQUFXLENBQUMsY0FBYyxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxXQUFXLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFO2dCQUNwSixNQUFNLEVBQUUsRUFBRTthQUNiLENBQUM7WUFDRixJQUFJLFlBQVksR0FBRyxJQUFJLENBQUMsU0FBUyxDQUFDLG9CQUFvQixDQUFDLElBQUksQ0FBQyxVQUFVLEVBQUUsS0FBSyxFQUFFLElBQUksQ0FBQyxNQUFNLEVBQUUsSUFBSSxDQUFDLGVBQWUsQ0FBQyxDQUFDO1lBQ2xILFNBQVMsQ0FBQyxTQUFTLENBQUMsR0FBRyxZQUFZLENBQUMsT0FBTyxDQUFDO1lBQzVDLElBQUksQ0FBQyxJQUFJLEdBQUcsU0FBUyxDQUFDO1lBQ3RCLElBQUksQ0FBQyxNQUFNLENBQUMsVUFBVSxDQUFDLEdBQUcsWUFBWSxDQUFDLFFBQVEsQ0FBQztZQUNoRCxJQUFJLENBQUMsVUFBVSxHQUFHLFlBQVksQ0FBQyxVQUFVLENBQUM7WUFDMUMsbUNBQW1DO1NBQ3RDO0lBQ0wsQ0FBQztJQUVPLGtCQUFrQixDQUFDLEtBQUs7UUFDNUIsSUFBSSxDQUFDLElBQUksR0FBRyxLQUFLLENBQUM7UUFDbEIsSUFBSSxDQUFDLGdCQUFnQixFQUFFLENBQUM7SUFDNUIsQ0FBQztJQUVPLGdCQUFnQjtRQUNwQixJQUFJLFVBQWUsQ0FBQztRQUNwQixJQUFJLElBQUksQ0FBQyxJQUFJLENBQUMsZUFBZSxDQUFDLElBQUksSUFBSSxDQUFDLE1BQU0sQ0FBQyxXQUFXLEVBQUU7WUFDdkQsVUFBVSxHQUFHLElBQUksQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLGVBQWUsQ0FBQyxDQUFDLENBQUMsQ0FBQztTQUN2RTthQUFNO1lBQ0gsVUFBVSxHQUFHLElBQUksQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQztZQUM3RCxLQUFLLElBQUksQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLEdBQUcsVUFBVSxDQUFDLE1BQU0sRUFBRSxDQUFDLEVBQUUsRUFBRTtnQkFDeEMsVUFBVSxDQUFDLENBQUMsQ0FBQyxDQUFDLFVBQVUsQ0FBQyxHQUFHLEtBQUssQ0FBQzthQUNyQztTQUNKO1FBQ0QsSUFBSSxDQUFDLGFBQWEsR0FBRyxLQUFLLENBQUM7UUFDM0IsSUFBSSxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsV0FBVyxFQUFFO1lBQzFCLElBQUksSUFBSSxDQUFDLE1BQU0sQ0FBQyxTQUFTLElBQUksU0FBUyxFQUFFO2dCQUNwQyxJQUFJLElBQUksQ0FBQyxNQUFNLENBQUMsU0FBUyxDQUFDLFdBQVcsSUFBSSxJQUFJLENBQUMsTUFBTSxDQUFDLFNBQVMsQ0FBQyxXQUFXLENBQUMsTUFBTSxJQUFJLENBQUMsRUFBRTtvQkFDcEYsSUFBSSxDQUFDLFVBQVUsR0FBRyxJQUFJLENBQUMsU0FBUyxDQUFDLHFCQUFxQixDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsU0FBUyxDQUFDLFdBQVcsRUFBRSxJQUFJLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxhQUFhLEVBQUUsSUFBSSxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsV0FBVyxDQUFDLENBQUM7aUJBQy9KO3FCQUFNO29CQUNILElBQUksQ0FBQyxhQUFhLEdBQUcsSUFBSSxDQUFDO2lCQUM3QjthQUNKO2lCQUFNO2dCQUNILElBQUksQ0FBQyxVQUFVLEdBQUcsSUFBSSxDQUFDLFNBQVMsQ0FBQyxnQkFBZ0IsQ0FBQyxJQUFJLENBQUMsVUFBVSxFQUFFLFVBQVUsRUFBRSxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUM7YUFDL0Y7U0FDSjthQUFNO1lBQ0gsbUNBQW1DO1lBQ25DLElBQUksSUFBSSxDQUFDLE1BQU0sQ0FBQyxTQUFTLElBQUksU0FBUyxFQUFFO2dCQUNwQyxJQUFJLElBQUksQ0FBQyxNQUFNLENBQUMsU0FBUyxDQUFDLFdBQVcsSUFBSSxJQUFJLENBQUMsTUFBTSxDQUFDLFNBQVMsQ0FBQyxXQUFXLENBQUMsTUFBTSxJQUFJLENBQUMsRUFBRTtvQkFDcEYsSUFBSSxDQUFDLFVBQVUsR0FBRyxJQUFJLENBQUMsU0FBUyxDQUFDLGdCQUFnQixDQUFDLElBQUksQ0FBQyxVQUFVLEVBQUUsVUFBVSxFQUFFLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQztpQkFDL0Y7cUJBQU07b0JBQ0gsSUFBSSxDQUFDLGFBQWEsR0FBRyxJQUFJLENBQUM7aUJBQzdCO2FBQ0o7aUJBQU07Z0JBQ0gsSUFBSSxDQUFDLFVBQVUsR0FBRyxJQUFJLENBQUMsU0FBUyxDQUFDLGdCQUFnQixDQUFDLElBQUksQ0FBQyxVQUFVLEVBQUUsVUFBVSxFQUFFLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQzthQUMvRjtTQUNKO0lBQ0wsQ0FBQztJQUVPLFlBQVksQ0FBQyxLQUFpQixFQUFFLFlBQW9CO1FBQ3hELElBQUksSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsS0FBSyxLQUFLLEVBQUU7WUFDN0IsT0FBTyxJQUFJLENBQUMsU0FBUyxDQUFDLHdCQUF3QixDQUFDLEtBQUssQ0FBQyxNQUFNLEVBQUUsS0FBSyxDQUFDLEtBQUssQ0FBQyxVQUFVLEVBQUUsWUFBWSxDQUFDLENBQUM7U0FDdEc7SUFDTCxDQUFDO0lBRU8sVUFBVSxDQUFDLFFBQWEsRUFBRSxZQUFvQixFQUFFLEtBQWtCO1FBRXRFLElBQUksQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLE9BQU8sQ0FBQyxLQUFLLENBQUM7WUFBRSxPQUFPO1FBRTNDLElBQUksS0FBSyxDQUFDLGNBQWMsQ0FBQyxRQUFRLENBQUMsSUFBSSxLQUFLLENBQUMsUUFBUSxDQUFDLEtBQUssU0FBUyxFQUFFO1lBQ2pFLE9BQU8sS0FBSyxDQUFDLFFBQVEsQ0FBQyxDQUFDO1NBQzFCO1FBRUQsSUFBSSxNQUFNLEdBQVcsSUFBSSxDQUFDLGdCQUFnQixDQUFDLFFBQVEsRUFBRSxZQUFZLENBQUMsQ0FBQztRQUNuRSxPQUFPLE1BQU0sQ0FBQztJQUNsQixDQUFDO0lBRU8sZ0JBQWdCLENBQUMsUUFBYSxFQUFFLFlBQW9CO1FBQ3hELElBQUksUUFBUSxLQUFLLE9BQU87WUFDcEIsQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLEtBQUssQ0FBQyxJQUFJLEtBQUssS0FBSyxJQUFJLElBQUksQ0FBQyxTQUFTLENBQUMsS0FBSyxDQUFDLElBQUksS0FBSyxLQUFLLENBQUMsRUFBRTtZQUM5RSxPQUFPLFFBQVEsQ0FBQztTQUNuQjtRQUVELElBQUksYUFBYSxHQUFXLElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxRQUFRLEVBQUUsWUFBWSxDQUFDLENBQUM7UUFDM0UsSUFBSSxNQUFjLENBQUM7UUFDbkIsSUFBSSxJQUFJLENBQUMsYUFBYSxJQUFJLEtBQUssRUFBRTtZQUM3QixNQUFNLEdBQUcsYUFBYSxDQUFDO1NBQzFCO2FBQU07WUFDSCxNQUFNLEdBQUcsSUFBSSxDQUFDLFNBQVMsQ0FBQyxNQUFNLENBQUMsWUFBWSxDQUFDLENBQUMsUUFBUSxDQUFDLElBQUksYUFBYSxDQUFDO1NBQzNFO1FBQ0QsT0FBTyxNQUFNLENBQUM7SUFDbEIsQ0FBQztJQUVNLGlCQUFpQixDQUFDLFFBQWEsRUFBRSxZQUFxQjtRQUN6RCxJQUFJLFFBQVEsS0FBSyxPQUFPO1lBQUUsT0FBTyxRQUFRLENBQUM7UUFFMUMsSUFBSSxZQUFZLElBQUksWUFBWSxLQUFLLENBQUMsRUFBRTtZQUNwQyxPQUFPLElBQUksQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLFlBQVksQ0FBQyxDQUFDO1NBQzNDO2FBQU07WUFDSCxJQUFJLENBQUMsa0JBQWtCLEVBQUUsQ0FBQztZQUMxQixPQUFPLElBQUksQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxrQkFBa0IsR0FBRyxDQUFDLENBQUMsQ0FBQztTQUMxRDtJQUNMLENBQUM7SUFFTSxlQUFlLENBQUMsS0FBVTtRQUM3QixJQUFJLENBQUMsYUFBYSxHQUFHLEtBQUssQ0FBQztJQUMvQixDQUFDOzs7WUFuMUJKLFNBQVMsU0FBQztnQkFDUCxRQUFRLEVBQUUsV0FBVztnQkFDckIsb29WQUF1QztnQkFDdkMsYUFBYSxFQUFFLGlCQUFpQixDQUFDLElBQUk7Z0JBQ3JDLFNBQVMsRUFBRSxDQUFDLFdBQVcsRUFBRSxlQUFlLEVBQUUsZUFBZSxFQUFFLFlBQVksRUFBRSxTQUFTLENBQUM7Z0JBQ25GLElBQUksRUFBRTtvQkFDRixPQUFPLEVBQUUsWUFBWTtvQkFDckIsV0FBVyxFQUFFLFdBQVc7b0JBQ3hCLGdDQUFnQyxFQUFFLHdCQUF3QjtvQkFDMUQsbUNBQW1DLEVBQUUsY0FBYztvQkFDbkQsbUNBQW1DLEVBQUUsY0FBYztvQkFDbkQsbUNBQW1DLEVBQUUsdUJBQXVCO29CQUM1RCxtQ0FBbUMsRUFBRSx1QkFBdUI7b0JBQzVELDhCQUE4QixFQUFFLDBCQUEwQjtvQkFDMUQsMEJBQTBCLEVBQUUsZ0RBQWdEO29CQUM1RSxzQkFBc0IsRUFBRSw0Q0FBNEM7b0JBQ3BFLHNCQUFzQixFQUFFLDRDQUE0QztvQkFDcEUsdUJBQXVCLEVBQUUsNkNBQTZDO29CQUN0RSxzQkFBc0IsRUFBRSw0Q0FBNEM7b0JBQ3BFLHFCQUFxQixFQUFFLCtCQUErQjtvQkFDdEQsaUJBQWlCLEVBQUUscUNBQXFDO2lCQUMzRDthQUNKOzs7WUExQ1EsWUFBWTtZQUhqQixVQUFVO1lBUUwsV0FBVztZQURYLGVBQWU7WUFBZ0IsU0FBUzs7O3dCQTRGNUMsS0FBSyxTQUFDLE1BQU07MEJBQ1osS0FBSyxTQUFDLFFBQVE7dUJBQ2QsS0FBSyxTQUFDLEtBQUs7eUJBQ1gsS0FBSzs4QkFDTCxLQUFLOytCQUNMLE1BQU07eUJBQ04sTUFBTTt5QkFDTixNQUFNIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHtcclxuICAgIENvbXBvbmVudCxcclxuICAgIFZpZXdFbmNhcHN1bGF0aW9uLFxyXG4gICAgSW5wdXQsXHJcbiAgICBPdXRwdXQsXHJcbiAgICBFdmVudEVtaXR0ZXIsXHJcbiAgICBPbkluaXQsXHJcbiAgICBPbkNoYW5nZXMsXHJcbiAgICBTaW1wbGVDaGFuZ2VzLFxyXG4gICAgRWxlbWVudFJlZixcclxuICAgIE9uRGVzdHJveVxyXG59IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xyXG5pbXBvcnQgeyBEb21TYW5pdGl6ZXIgfSBmcm9tICdAYW5ndWxhci9wbGF0Zm9ybS1icm93c2VyJztcclxuaW1wb3J0IHsgU3Vic2NyaXB0aW9uLCAgdGltZXIgfSBmcm9tICdyeGpzJztcclxuaW1wb3J0IHsgZGVib3VuY2VUaW1lIH0gZnJvbSAncnhqcy9vcGVyYXRvcnMnO1xyXG5pbXBvcnQgeyBLZFNwbGl0dGVyRXZlbnQgfSBmcm9tICcuLi9rZC1hbmd1bGFyLXNwbGl0dGVyL2luZGV4JztcclxuaW1wb3J0IHsgS2RDb252ZXJ0aW9uU3ZjLCBLZERvbUVsZW1TdmMsIEtkRGF0YVN2YyB9IGZyb20gJy4uL2tkLWNvbW1vbi9pbmRleCc7XHJcbmltcG9ydCB7IEtkQ2hhcnRzU3ZjIH0gZnJvbSAnLi9rZC1hbmd1bGFyLWNoYXJ0cy1zdmMnO1xyXG5pbXBvcnQgeyBERUZBVUxUX0NPTkZJRyB9IGZyb20gJy4va2QtYW5ndWxhci1jaGFydHMtY29uZmlnJztcclxuaW1wb3J0IHtcclxuICAgIElDaGFydERhdGEsXHJcbiAgICBJQ2hhcnRDb25maWcsXHJcbiAgICBJU2VyaWVzRGF0YSxcclxuICAgIElMZWdlbmREYXRhLFxyXG4gICAgSUQzRGF0YSxcclxuICAgIElEM1lEYXRhLFxyXG4gICAgSUQzRGF0YURhdGEsXHJcbiAgICBJQ2hhcnRBcGksXHJcbiAgICBJQ2hhcnRJbnRlcm5hbEFwaSxcclxuICAgIElGb3JMb29wSW5mb1xyXG59IGZyb20gJy4va2QtYW5ndWxhci1jaGFydHMtaW50ZXJmYWNlJztcclxuXHJcbkBDb21wb25lbnQoe1xyXG4gICAgc2VsZWN0b3I6ICdrZC1jaGFydHMnLFxyXG4gICAgdGVtcGxhdGVVcmw6ICcuL2tkLWFuZ3VsYXItY2hhcnRzLmh0bWwnLFxyXG4gICAgZW5jYXBzdWxhdGlvbjogVmlld0VuY2Fwc3VsYXRpb24uTm9uZSxcclxuICAgIHByb3ZpZGVyczogW0tkQ2hhcnRzU3ZjLCBLZFNwbGl0dGVyRXZlbnQsIEtkQ29udmVydGlvblN2YywgS2REb21FbGVtU3ZjLCBLZERhdGFTdmNdLFxyXG4gICAgaG9zdDoge1xyXG4gICAgICAgICdjbGFzcyc6ICdrZHgtY2hhcnRzJyxcclxuICAgICAgICAnW2F0dHIuaWRdJzogJ2NvbmZpZy5pZCcsXHJcbiAgICAgICAgJ1tjbGFzcy5rZHgtY2hhcnRzLWF4aXMtaW52ZXJ0XSc6ICdjaGFydFR5cGVbMF0gPT09IFwiYmFyXCInLFxyXG4gICAgICAgICdbY2xhc3Mua2R4LWNoYXJ0cy1yb3RhdGUtdGl0bGUteF0nOiAncm90YXRlVGl0bGVYJyxcclxuICAgICAgICAnW2NsYXNzLmtkeC1jaGFydHMtcm90YXRlLXRpdGxlLXldJzogJ3JvdGF0ZVRpdGxlWScsXHJcbiAgICAgICAgJ1tjbGFzcy5rZHgtY2hhcnRzLXlBeGlzLW9wcG9zaXRlXSc6ICdjb25maWcueUF4aXMub3Bwb3NpdGUnLFxyXG4gICAgICAgICdbY2xhc3Mua2R4LWNoYXJ0cy14QXhpcy1vcHBvc2l0ZV0nOiAnY29uZmlnLnhBeGlzLm9wcG9zaXRlJyxcclxuICAgICAgICAnW2NsYXNzLmtkeC1jaGFydHMtbm8tYm9yZGVyXSc6ICdoYXZla2RDaGFydE5vQm9yZGVyQ2xhc3MnLFxyXG4gICAgICAgICdbc3R5bGUuYmFja2dyb3VuZC1jb2xvcl0nOiAnY29uZmlnLmNoYXJ0Lm1haW5BcmVhLnN0eWxlW1wiYmFja2dyb3VuZENvbG9yXCJdJyxcclxuICAgICAgICAnW3N0eWxlLmJvcmRlci1jb2xvcl0nOiAnY29uZmlnLmNoYXJ0Lm1haW5BcmVhLnN0eWxlW1wiYm9yZGVyQ29sb3JcIl0nLFxyXG4gICAgICAgICdbc3R5bGUuYm9yZGVyLXdpZHRoXSc6ICdjb25maWcuY2hhcnQubWFpbkFyZWEuc3R5bGVbXCJib3JkZXJXaWR0aFwiXScsXHJcbiAgICAgICAgJ1tzdHlsZS5ib3JkZXItcmFkaXVzXSc6ICdjb25maWcuY2hhcnQubWFpbkFyZWEuc3R5bGVbXCJib3JkZXJSYWRpdXNcIl0nLFxyXG4gICAgICAgICdbc3R5bGUuYm9yZGVyLXN0eWxlXSc6ICdjb25maWcuY2hhcnQubWFpbkFyZWEuc3R5bGVbXCJib3JkZXJTdHlsZVwiXScsXHJcbiAgICAgICAgJ1tzdHlsZS5mb250LWZhbWlseV0nOiAnY29uZmlnLmNoYXJ0LnN0eWxlLmZvbnRGYW1pbHknLFxyXG4gICAgICAgICdbc3R5bGUub3BhY2l0eV0nOiAnY29uZmlnLmNoYXJ0Lm1haW5BcmVhLnN0eWxlLm9wYWNpdHknLFxyXG4gICAgfVxyXG59KVxyXG5cclxuZXhwb3J0IGNsYXNzIEtkQ2hhcnRzIGltcGxlbWVudHMgT25Jbml0LCBPbkNoYW5nZXMsIE9uRGVzdHJveSB7XHJcbiAgICBwdWJsaWMgaXNMYXllckxvYWRpbmc6IGJvb2xlYW4gPSB0cnVlO1xyXG4gICAgcHVibGljIHNtYWxsTG9hZGVyVmFsdWU6IGFueSA9IG51bGw7XHJcbiAgICBwdWJsaWMgcGllRGF0YTogQXJyYXk8YW55PiA9IFtdO1xyXG4gICAgcHVibGljIHBpZUNvbG9yOiBBcnJheTxhbnk+ID0gW107XHJcbiAgICBwdWJsaWMgYmFja2dyb3VuZENvbG9yOiBzdHJpbmcgPSAnI0ZGRkZGRic7XHJcbiAgICBwdWJsaWMgY29uZmlnOiBJQ2hhcnRDb25maWc7XHJcbiAgICBwdWJsaWMgZGF0YTogSUQzRGF0YTtcclxuICAgIHB1YmxpYyBsZWdlbmRMaXN0OiBBcnJheTxzdHJpbmc+O1xyXG4gICAgcHVibGljIGNoZWNrTWFwU2NhbGU6IGJvb2xlYW4gPSBmYWxzZTtcclxuICAgIHB1YmxpYyBjaGFydENhdGVnb3J5OiAncGllJyB8ICdiYXInIHwgJ2NvbHVtbicgfCAnbGluZScgfCAnYXJlYScgfCAnZG90JyB8ICdzcGxpbmUnIHwgJ21hcCc7XHJcbiAgICBwdWJsaWMgaXNBeGlzQ2hhcnQ6IGJvb2xlYW4gPSBmYWxzZTtcclxuICAgIHB1YmxpYyBpc05lZ2F0aXZlU3RhY2s6IGJvb2xlYW4gPSBmYWxzZTtcclxuICAgIHB1YmxpYyBjaGFydFR5cGU6IEFycmF5PHN0cmluZz4gPSBbJyddO1xyXG4gICAgcHVibGljIHJvdGF0ZVRpdGxlWDogYm9vbGVhbiA9IGZhbHNlO1xyXG4gICAgcHVibGljIHJvdGF0ZVRpdGxlWTogYm9vbGVhbiA9IGZhbHNlO1xyXG4gICAgcHVibGljIGNoYXJ0SGlkZTogYm9vbGVhbiA9IGZhbHNlO1xyXG4gICAgcHVibGljIGhhdmVBeGlzUGFkZGluZzogYm9vbGVhbiA9IGZhbHNlO1xyXG4gICAgcHVibGljIGhhdmVBeGlzU3BlY2lhbFBhZGRpbmc6IGJvb2xlYW4gPSBmYWxzZTtcclxuICAgIHB1YmxpYyB4QXhpc09wcG9zaXRlOiBib29sZWFuID0gZmFsc2U7XHJcbiAgICBwdWJsaWMgaGF2ZWtkQ2hhcnROb0JvcmRlckNsYXNzOiBib29sZWFuID0gZmFsc2U7XHJcblxyXG4gICAgcHVibGljIGh0bWxDbGFzc09iajogYW55ID0ge1xyXG4gICAgICAgICdjaGFydHNXcmFwcGVyJzogJycsXHJcbiAgICAgICAgJ2xlZ2VuZENvbnRhaW5lcic6ICcnXHJcbiAgICB9O1xyXG5cclxuICAgIHB1YmxpYyBhcGk6IElDaGFydEludGVybmFsQXBpID0ge307XHJcblxyXG4gICAgcHVibGljIGljb25zOiBvYmplY3QgPSB7fTtcclxuXHJcbiAgICBwdWJsaWMgbGVnZW5kRGF0YTogeyBba2V5OiBzdHJpbmddOiBJTGVnZW5kRGF0YSB9O1xyXG4gICAgcHVibGljIG1hcmtlcnNMZWdlbmQ6IEFycmF5PGFueT4gPSBbXTtcclxuXHJcbiAgICBwcml2YXRlIHNoYXBlczogb2JqZWN0ID0ge1xyXG4gICAgICAgIHRyaWFuZ2xlOiAnTSA0IDAgTCA0IDAgTCAwIDggTCA4IDggeicsXHJcbiAgICAgICAgdHJpYW5nbGVSOiAnTSAwIDAgTCA4IDAgTCA0IDggTCA0IDggeicsXHJcbiAgICAgICAgZGlhbW9uZDogJ00gNCAwIEwgOCA0IEwgNCA4IEwgMCA0IHonLFxyXG4gICAgICAgIGNpcmNsZTogJ00gNCAwIEEgNCA0IDAgMSAwIDQgOCBBIDQgNCAwIDEgMCA0IDAgWicsXHJcbiAgICAgICAgc3F1YXJlOiAnTSAwIDAgTCA4IDAgTCA4IDggTCAwIDggeidcclxuICAgIH07XHJcblxyXG4gICAgcHJpdmF0ZSBsZWdlbmRJbmFjdGl2ZTogQXJyYXk8c3RyaW5nPiA9IFtdO1xyXG4gICAgcHJpdmF0ZSBfY29sb3JMaXN0UG9zaXRpb246IG51bWJlciA9IDA7XHJcblxyXG4gICAgcHJpdmF0ZSBfcmVzaXplVGltZW91dDogYW55O1xyXG5cclxuICAgIC8vIHByaXZhdGUgX3NwbGl0dGVyU3Vic2NyaXB0aW9uQXJyOiBTdWJzY3JpcHRpb25bXSA9IFtdO1xyXG5cclxuICAgIHByaXZhdGUgX3Jlc2l6ZUxpc3RlbmVyOiBhbnk7XHJcbiAgICBwcml2YXRlIF9waWVEb25lRmxhZzogYm9vbGVhbiA9IGZhbHNlO1xyXG5cclxuICAgIEBJbnB1dCgnZGF0YScpIGNoYXJ0RGF0YTogSUNoYXJ0RGF0YTtcclxuICAgIEBJbnB1dCgnY29uZmlnJykgY2hhcnRDb25maWc6IElDaGFydENvbmZpZztcclxuICAgIEBJbnB1dCgnYXBpJykgY2hhcnRBcGk6IElDaGFydEFwaTtcclxuICAgIEBJbnB1dCgpIHhUaHJlc2hvbGQ6IG51bWJlcjtcclxuICAgIEBJbnB1dCgpIHNlcmllc1RocmVzaG9sZDogbnVtYmVyID0gMTAwMDtcclxuICAgIEBPdXRwdXQoKSBvdXRwdXRMZWdlbmREYXRhOiBFdmVudEVtaXR0ZXI8eyBba2V5OiBzdHJpbmddOiBJTGVnZW5kRGF0YSB9PiA9IG5ldyBFdmVudEVtaXR0ZXIoKTtcclxuICAgIEBPdXRwdXQoKSBvdXRwdXREYXRhOiBFdmVudEVtaXR0ZXI8SUQzRGF0YT4gPSBuZXcgRXZlbnRFbWl0dGVyKCk7XHJcbiAgICBAT3V0cHV0KCkgb3V0cHV0QXJlYTogRXZlbnRFbWl0dGVyPElEM0RhdGE+ID0gbmV3IEV2ZW50RW1pdHRlcigpO1xyXG5cclxuICAgIGNvbnN0cnVjdG9yKFxyXG4gICAgICAgIHByaXZhdGUgX3Nhbml0aXplcjogRG9tU2FuaXRpemVyLFxyXG4gICAgICAgIHByaXZhdGUgX2VsZW1lbnRSZWY6IEVsZW1lbnRSZWYsXHJcbiAgICAgICAgcHJpdmF0ZSBfY2hhcnRTdmM6IEtkQ2hhcnRzU3ZjLFxyXG4gICAgICAgIC8vIHB1YmxpYyBfa2RTcGxpdHRlckV2ZW50OiBLZFNwbGl0dGVyRXZlbnQsXHJcbiAgICAgICAgcHVibGljIF9jb252ZXJ0aW9uU3ZjOiBLZENvbnZlcnRpb25TdmMsXHJcbiAgICAgICAgcHVibGljIF9kYXRhU3ZjOiBLZERhdGFTdmNcclxuICAgICkge1xyXG4gICAgICAgIC8vIHRoaXMuX3NwbGl0dGVyU3Vic2NyaXB0aW9uQXJyID0gdGhpcy5faW5pdFNwbGl0dGVyU3Vic2NyaXB0aW9ucyhfa2RTcGxpdHRlckV2ZW50KTtcclxuICAgIH1cclxuXHJcbiAgICBuZ09uSW5pdCgpOiB2b2lkIHtcclxuICAgICAgICAvLyBjb25zb2xlLmxvZygna2QtY2hhcnQgaW5pdCcpO1xyXG4gICAgICAgIHRoaXMuX3NldENvbmZpZyh0aGlzLmNoYXJ0Q29uZmlnLCB0cnVlKTtcclxuICAgICAgICBpZiAoIXRoaXMuY2hhcnREYXRhIHx8ICF0aGlzLmNoYXJ0Q29uZmlnKSByZXR1cm47XHJcbiAgICAgICAgdGhpcy5fc2V0RGF0YSh0aGlzLmNoYXJ0RGF0YSk7XHJcbiAgICAgICAgdGhpcy5pbml0QXBpKCk7XHJcbiAgICAgICAgLy8gdGhpcy5fcmVzaXplTGlzdGVuZXIgPSAoKSA9PiB0aGlzLl9vblJlc2l6ZSgpO1xyXG4gICAgICAgIC8vIHRoaXMuX2luaXRMaXN0ZW5lcigpO1xyXG4gICAgICAgIC8vIGNvbnNvbGUubG9nKCdrZC1jaGFydCBkYXRhICcsIHRoaXMuY2hhcnREYXRhKTtcclxuICAgICAgICAvLyBjb25zb2xlLmxvZygna2QtY2hhcnQgY29uZmlnICcsIHRoaXMuY2hhcnRDb25maWcpO1xyXG4gICAgfVxyXG5cclxuICAgIG5nT25DaGFuZ2VzKF9zaW1wbGVDaGFuZ2VzOiBTaW1wbGVDaGFuZ2VzKTogdm9pZCB7XHJcbiAgICAgICAgaWYgKF9zaW1wbGVDaGFuZ2VzLmhhc093blByb3BlcnR5KCdjaGFydENvbmZpZycpICYmICFfc2ltcGxlQ2hhbmdlc1snY2hhcnRDb25maWcnXS5maXJzdENoYW5nZSkge1xyXG4gICAgICAgICAgICBpZiAoX3NpbXBsZUNoYW5nZXNbJ2NoYXJ0Q29uZmlnJ10uY3VycmVudFZhbHVlID09PSB0aGlzLmNvbmZpZykgcmV0dXJuO1xyXG4gICAgICAgICAgICB0aGlzLl9zZXRDb25maWcoX3NpbXBsZUNoYW5nZXMuY2hhcnRDb25maWcuY3VycmVudFZhbHVlKTtcclxuICAgICAgICB9XHJcbiAgICAgICAgaWYgKF9zaW1wbGVDaGFuZ2VzLmhhc093blByb3BlcnR5KCdjaGFydERhdGEnKSAmJiAhX3NpbXBsZUNoYW5nZXNbJ2NoYXJ0RGF0YSddLmZpcnN0Q2hhbmdlKSB7XHJcbiAgICAgICAgICAgIGlmIChfc2ltcGxlQ2hhbmdlc1snY2hhcnREYXRhJ10uY3VycmVudFZhbHVlID09PSB0aGlzLmRhdGEpIHJldHVybjtcclxuICAgICAgICAgICAgdGhpcy5fc2V0RGF0YShPYmplY3QuYXNzaWduKHt9LCBfc2ltcGxlQ2hhbmdlcy5jaGFydERhdGEuY3VycmVudFZhbHVlKSk7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIG5nT25EZXN0cm95KCk6IHZvaWQge1xyXG4gICAgICAgIGlmICghdGhpcy5jaGFydERhdGEgfHwgIXRoaXMuY2hhcnRDb25maWcpIHJldHVybjtcclxuICAgICAgICAvLyB0aGlzLl91bnN1YnNjcmliZSh0aGlzLl9zcGxpdHRlclN1YnNjcmlwdGlvbkFycik7XHJcbiAgICAgICAgLy8gdGhpcy5fcmVtb3ZlTGlzdGVuZXIoKTtcclxuICAgIH1cclxuXHJcbiAgICAvKipcclxuICAgICAqIEZvciBFWFBPUlQuIGV4cG9ydCBza2lwcyBkYXRhIG1hc3NhZ2UgYW5kIGdlbmVyYXRlTGVnZW5kRGF0YSwgaGVuY2UgbmVlZCB0byBzZXRMZWdlbmREYXRhIHNlcGFyYXRlbHlcclxuICAgICAqIChhY2N1cmF0ZSBhcyBvZiB2My43LjApIGFzIGxlZ2VuZERhdGEgaXMgZm9yIGludGVybmFsIHVzZSwgd2UgZG8gbm90IHB1dCBpbiBJbnB1dC4gdGhpcyBmdW5jdGlvbiBpcyBhY2Nlc3NlZCB2aWEgVmlld0NoaWxkIGZyb20gS2RWaXN1YWxpemF0aW9uXHJcbiAgICAgKiBwYXJhbSB7SUxlZ2VuZERhdGEgfX0gX2xlZ2VuZERhdGFcclxuICAgICAqL1xyXG4gICAgcHVibGljIHNldExlZ2VuZERhdGEoX2xlZ2VuZERhdGE6IHsgW2tleTogc3RyaW5nXTogSUxlZ2VuZERhdGEgfSkge1xyXG4gICAgICAgIHRoaXMubGVnZW5kRGF0YSA9IE9iamVjdC5hc3NpZ24oe30sIF9sZWdlbmREYXRhKTtcclxuICAgIH1cclxuXHJcbiAgICAvKipcclxuICAgICAqIGluaXRpYXRlIGFwaSBmcm9tIG91dHNpZGUga2QgY2hhcnRzIGNvbXBvbmVudFxyXG4gICAgICovXHJcbiAgICBwcml2YXRlIGluaXRBcGkoKTogdm9pZCB7XHJcbiAgICAgICAgaWYgKHR5cGVvZiB0aGlzLmNoYXJ0QXBpID09PSAndW5kZWZpbmVkJykgcmV0dXJuO1xyXG5cclxuICAgICAgICB0aGlzLmNoYXJ0QXBpLmNoYW5nZVNlcmllc0NvbG9yID0gKGxlZ2VuZElkOiBzdHJpbmcsIGNvbG9yOiBzdHJpbmcsIGluZGV4PzogbnVtYmVyKSA9PiB7XHJcbiAgICAgICAgICAgIGlmICh0eXBlb2YgaW5kZXggPT09ICdudW1iZXInKSB0aGlzLl9zZXREYXRhQ29sb3JTaGFwZShpbmRleCwgY29sb3IpO1xyXG4gICAgICAgICAgICB0aGlzLmxlZ2VuZERhdGFbbGVnZW5kSWRdLmNvbG9yID0gY29sb3I7XHJcbiAgICAgICAgICAgIHRoaXMuX3VwZGF0ZUxlZ2VuZEljb25XaXRoSW5kZXgobGVnZW5kSWQsIGluZGV4KTtcclxuICAgICAgICAgICAgdGhpcy5hcGkucmVkcmF3KCk7XHJcbiAgICAgICAgfTtcclxuXHJcbiAgICAgICAgdGhpcy5jaGFydEFwaS5yZWRyYXcgPSAoKSA9PiB0aGlzLmFwaS5yZWRyYXcoKTtcclxuXHJcbiAgICAgICAgLy8gdGhpcy5jaGFydEFwaS5lbmFibGVMaXN0ZW5lciA9IChfaGF2ZUxpc3RlbmVyOiBib29sZWFuKSA9PiB7XHJcbiAgICAgICAgLy8gICAgIGlmIChfaGF2ZUxpc3RlbmVyKSB7XHJcbiAgICAgICAgLy8gICAgICAgICB0aGlzLl9pbml0TGlzdGVuZXIoKTtcclxuICAgICAgICAvLyAgICAgICAgIGlmICh0aGlzLl9zcGxpdHRlclN1YnNjcmlwdGlvbkFyci5sZW5ndGggPT09IDApIHtcclxuICAgICAgICAvLyAgICAgICAgICAgICB0aGlzLl9zcGxpdHRlclN1YnNjcmlwdGlvbkFyciA9IHRoaXMuX2luaXRTcGxpdHRlclN1YnNjcmlwdGlvbnModGhpcy5fa2RTcGxpdHRlckV2ZW50KTtcclxuICAgICAgICAvLyAgICAgICAgIH1cclxuICAgICAgICAvLyAgICAgfSBlbHNlIHtcclxuICAgICAgICAvLyAgICAgICAgIHRoaXMuX3JlbW92ZUxpc3RlbmVyKCk7XHJcbiAgICAgICAgLy8gICAgICAgICB0aGlzLl91bnN1YnNjcmliZSh0aGlzLl9zcGxpdHRlclN1YnNjcmlwdGlvbkFycik7XHJcbiAgICAgICAgLy8gICAgICAgICB0aGlzLl9zcGxpdHRlclN1YnNjcmlwdGlvbkFyciA9IFtdO1xyXG4gICAgICAgIC8vICAgICB9XHJcbiAgICAgICAgLy8gfTtcclxuICAgIH1cclxuXHJcbiAgICAvLyA9PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT0gTGlzdGVuZXIgPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PVxyXG5cclxuICAgIC8vIHByaXZhdGUgX2luaXRMaXN0ZW5lcigpIHtcclxuICAgIC8vICAgICB3aW5kb3cuYWRkRXZlbnRMaXN0ZW5lcigncmVzaXplJywgdGhpcy5fcmVzaXplTGlzdGVuZXIpO1xyXG4gICAgLy8gfVxyXG5cclxuICAgIC8vIHByaXZhdGUgX3JlbW92ZUxpc3RlbmVyKCkge1xyXG4gICAgLy8gICAgIHdpbmRvdy5yZW1vdmVFdmVudExpc3RlbmVyKCdyZXNpemUnLCB0aGlzLl9yZXNpemVMaXN0ZW5lcik7XHJcbiAgICAvLyB9XHJcblxyXG4gICAgLy8gcHJpdmF0ZSBfb25SZXNpemUoKTogdm9pZCB7XHJcbiAgICAvLyAgICAgY2xlYXJUaW1lb3V0KHRoaXMuX3Jlc2l6ZVRpbWVvdXQpO1xyXG4gICAgLy8gICAgIHRoaXMuX3Jlc2l6ZVRpbWVvdXQgPSBzZXRUaW1lb3V0KCgpID0+IHtcclxuICAgIC8vICAgICAgICAgdGhpcy5hcGkucmVkcmF3KCk7XHJcbiAgICAvLyAgICAgfSwgNTAwKTtcclxuICAgIC8vIH1cclxuXHJcbiAgICAvLyA9PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT0gU3BsaXR0ZXIgU3Vic2NyaXB0aW9uID09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT1cclxuXHJcbiAgICAvLyBwcml2YXRlIF9pbml0U3BsaXR0ZXJTdWJzY3JpcHRpb25zKF9zcGxpdHRlckV2ZW50KTogU3Vic2NyaXB0aW9uW10ge1xyXG4gICAgLy8gICAgIGlmICghX3NwbGl0dGVyRXZlbnQpIHJldHVybjtcclxuXHJcbiAgICAvLyAgICAgbGV0IHN1YnNjcmlwdGlvbkFycjogU3Vic2NyaXB0aW9uW10gPSBbXTtcclxuXHJcbiAgICAvLyAgICAgbGV0IHRvZ2dsZU1lbnVTdWIgPSBfc3BsaXR0ZXJFdmVudC5vblRvZ2dsZU1lbnUoKS5zdWJzY3JpYmUoKCk6IHZvaWQgPT4ge1xyXG4gICAgLy8gICAgICAgICB0aW1lcig1MDApLnN1YnNjcmliZSgoKTogdm9pZCA9PiB7XHJcbiAgICAvLyAgICAgICAgICAgICB0aGlzLmFwaS5yZWRyYXcoKTtcclxuICAgIC8vICAgICAgICAgfSk7XHJcbiAgICAvLyAgICAgfSk7XHJcbiAgICAvLyAgICAgbGV0IHRvZ2dsZVN1YlBhbmUgPSBfc3BsaXR0ZXJFdmVudC5vblRvZ2dsZVN1YlBhbmUoKS5zdWJzY3JpYmUoKCk6IHZvaWQgPT4ge1xyXG4gICAgLy8gICAgICAgICB0aW1lcig1MDApLnN1YnNjcmliZSgoKTogdm9pZCA9PiB7XHJcbiAgICAvLyAgICAgICAgICAgICB0aGlzLmFwaS5yZWRyYXcoKTtcclxuICAgIC8vICAgICAgICAgfSk7XHJcbiAgICAvLyAgICAgfSk7XHJcbiAgICAvLyAgICAgbGV0IGRyYWdNZW51U3ViID0gX3NwbGl0dGVyRXZlbnQub25EcmFnKClcclxuICAgIC8vICAgICAgICAgLnBpcGUoXHJcbiAgICAvLyAgICAgICAgICAgICBkZWJvdW5jZVRpbWUoMTAwKVxyXG4gICAgLy8gICAgICAgICApXHJcbiAgICAvLyAgICAgICAgIC5zdWJzY3JpYmUoKCk6IHZvaWQgPT4ge1xyXG4gICAgLy8gICAgICAgICAgICAgdGhpcy5hcGkucmVkcmF3KCk7XHJcbiAgICAvLyAgICAgICAgIH0pO1xyXG5cclxuICAgIC8vICAgICBzdWJzY3JpcHRpb25BcnIucHVzaCh0b2dnbGVNZW51U3ViKTtcclxuICAgIC8vICAgICBzdWJzY3JpcHRpb25BcnIucHVzaCh0b2dnbGVTdWJQYW5lKTtcclxuICAgIC8vICAgICBzdWJzY3JpcHRpb25BcnIucHVzaChkcmFnTWVudVN1Yik7XHJcblxyXG4gICAgLy8gICAgIHJldHVybiBzdWJzY3JpcHRpb25BcnI7XHJcbiAgICAvLyB9XHJcblxyXG4gICAgLy8gcHJpdmF0ZSBfdW5zdWJzY3JpYmUoX3N1YnNjcmlwdGlvbkFycjogU3Vic2NyaXB0aW9uW10gPSBbXSk6IHZvaWQge1xyXG4gICAgLy8gICAgIGlmIChfc3Vic2NyaXB0aW9uQXJyLmxlbmd0aCA9PT0gMCkgcmV0dXJuO1xyXG4gICAgLy8gICAgIF9zdWJzY3JpcHRpb25BcnIuZm9yRWFjaChzdWJzY3JpcHRpb24gPT4ge1xyXG4gICAgLy8gICAgICAgICBpZiAoc3Vic2NyaXB0aW9uKSBzdWJzY3JpcHRpb24udW5zdWJzY3JpYmUoKTtcclxuICAgIC8vICAgICB9KTtcclxuICAgIC8vIH1cclxuXHJcbiAgICAvLyA9PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT0gQ29uZmlnIGFuZCBEYXRhID09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT1cclxuXHJcbiAgICBwcml2YXRlIF9zZXRDb25maWcoX2NvbmZpZzogSUNoYXJ0Q29uZmlnLCBfaXNGaXJzdENoYW5nZT86IGJvb2xlYW4pOiB2b2lkIHtcclxuICAgICAgICAvLyBzdG9yaW5nIGNvbmZpZyBpbiB0aGlzIGNvbXBvbmVudFxyXG4gICAgICAgIHRoaXMuY29uZmlnID0gSlNPTi5wYXJzZShKU09OLnN0cmluZ2lmeShERUZBVUxUX0NPTkZJRykpO1xyXG4gICAgICAgIHRoaXMuX2RhdGFTdmMuZGVlcENvbWJpbmVPYmplY3QodGhpcy5jb25maWcsIF9jb25maWcgfHwge30pO1xyXG5cclxuICAgICAgICAvLyBzZXQgY29uZmlnIGlzIGNhbGxlZCB0d2ljZSwgdG8gaW1wcm92ZSBwZXJmb3JtYW5jZSwgb25seSBjYWxsIHRoZSBmb2xsb3dpbmcgb25jZSAoYWZ0ZXIgZGF0YSBtYXNzYWdlKVxyXG4gICAgICAgIGlmIChfaXNGaXJzdENoYW5nZSkgcmV0dXJuO1xyXG5cclxuICAgICAgICB0aGlzLnNldENoYXJ0U3R5bGUoX2NvbmZpZyk7XHJcbiAgICAgICAgXHJcbiAgICAgICAgdGhpcy5jaGVja01hcFNjYWxlID0gZmFsc2U7XHJcblxyXG4gICAgICAgIHRoaXMuX3NldENsYXNzTmFtZXMoKTtcclxuXHJcbiAgICAgICAgdGhpcy5fcG9wdWxhdGVMZWdlbmRJY29uKCk7XHJcblxyXG4gICAgICAgIHRoaXMuX3NldExhYmVsU3R5bGUoKTtcclxuXHJcblxyXG4gICAgICAgIC8vIHN0b3JpbmcgY29uZmlnIGludG8gY2hhcnQgc2VydmljZVxyXG4gICAgICAgIHRoaXMuX2NoYXJ0U3ZjLmNvbmZpZyA9IF9jb25maWc7XHJcbiAgICB9XHJcblxyXG4gICAgcHVibGljIHNldENoYXJ0U3R5bGUoX2NvbmZpZzogSUNoYXJ0Q29uZmlnKTogdm9pZCB7XHJcbiAgICAgICAgdGhpcy5oYXZla2RDaGFydE5vQm9yZGVyQ2xhc3MgPSAhX2NvbmZpZy5jaGFydC5tYWluQXJlYS5zdHlsZVtcImJvcmRlcldpZHRoXCJdO1xyXG4gICAgICAgIGlmIChfY29uZmlnLmNoYXJ0Lm1haW5BcmVhLnN0eWxlW1wiYm9yZGVyV2lkdGhcIl0gJiYgX2NvbmZpZy5jaGFydC5tYWluQXJlYS5zdHlsZVtcImJvcmRlcldpZHRoXCJdID09PSAnMHB4Jykge1xyXG4gICAgICAgICAgICB0aGlzLmhhdmVrZENoYXJ0Tm9Cb3JkZXJDbGFzcyA9IHRydWU7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIC8qIFRvIGJlIHJldmlzaXQuIEhvdCBmaXggZm9yIGRvd25ncmFkZSBjb21wb25lbnQgYXMgbmdjbGFzcyB2YWx1ZSBkb2Vzbid0IGNoYW5nZS4qL1xyXG4gICAgcHJpdmF0ZSBfc2V0Q2xhc3NOYW1lcygpIHtcclxuXHJcbiAgICAgICAgLy8gaHRtbENsYXNzT2JqIGlzIGEgd29ya2Fyb3VuZCBmb3IgZG93bmdyYWRlIG1ldGhvZFxyXG4gICAgICAgIHRoaXMuaHRtbENsYXNzT2JqWydjaGFydHNXcmFwcGVyJ10gPSAnJztcclxuICAgICAgICB0aGlzLmh0bWxDbGFzc09ialsnbGVnZW5kQ29udGFpbmVyJ10gPSAnJztcclxuICAgICAgICBcclxuICAgICAgICBpZiAodHlwZW9mIHRoaXMuY29uZmlnLmxlZ2VuZC5mbG9hdCAhPT0gdW5kZWZpbmVkICYmIHRoaXMuY29uZmlnLmxlZ2VuZC5mbG9hdCkge1xyXG4gICAgICAgICAgICB0aGlzLmh0bWxDbGFzc09iai5jaGFydHNXcmFwcGVyICs9ICdsZWdlbmQtZmxvYXQgJztcclxuICAgICAgICAgICAgdGhpcy5odG1sQ2xhc3NPYmoubGVnZW5kQ29udGFpbmVyICs9ICdsZWdlbmQtZmxvYXQgJztcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIGlmICh0eXBlb2YgdGhpcy5jb25maWcubGVnZW5kLnZlcnRpY2FsQWxpZ24gIT09IHVuZGVmaW5lZCkge1xyXG4gICAgICAgICAgICB0aGlzLmh0bWxDbGFzc09iai5jaGFydHNXcmFwcGVyICs9IHRoaXMuY29uZmlnLmxlZ2VuZC52ZXJ0aWNhbEFsaWduICsgJyAnO1xyXG4gICAgICAgICAgICB0aGlzLmh0bWxDbGFzc09iai5sZWdlbmRDb250YWluZXIgKz0gdGhpcy5jb25maWcubGVnZW5kLnZlcnRpY2FsQWxpZ24gKyAnICc7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICBpZiAodHlwZW9mIHRoaXMuY29uZmlnLmxlZ2VuZC5hbGlnbiAhPT0gdW5kZWZpbmVkKSB7XHJcbiAgICAgICAgICAgIHRoaXMuaHRtbENsYXNzT2JqLmNoYXJ0c1dyYXBwZXIgKz0gdGhpcy5jb25maWcubGVnZW5kLmFsaWduICsgJyAnO1xyXG4gICAgICAgICAgICB0aGlzLmh0bWxDbGFzc09iai5sZWdlbmRDb250YWluZXIgKz0gdGhpcy5jb25maWcubGVnZW5kLmFsaWduICsgJyAnO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgaWYgKHRoaXMuY2hhcnRDYXRlZ29yeSA9PT0gJ3BpZScgfHwgdGhpcy5jaGFydENhdGVnb3J5ID09PSAnbWFwJykgcmV0dXJuO1xyXG4gICAgICAgIHRoaXMueEF4aXNPcHBvc2l0ZSA9IHRoaXMuY29uZmlnLnhBeGlzLm9wcG9zaXRlO1xyXG5cclxuICAgICAgICAvLyBzZXR0aW5nIGNsYXNzIG5hbWUgZm9yIHZlcnRpY2FsIGF4aXMgdGl0bGUgdG8gcm90YXRlXHJcbiAgICAgICAgdGhpcy5yb3RhdGVUaXRsZVggPSB0aGlzLmNoYXJ0VHlwZVswXSA9PT0gJ2JhcicgJiYgdGhpcy5fY2hhcnRTdmMuY2hlY2tSb3RhdGVUaXRsZUVuYWJsZWQodGhpcy5jaGFydFR5cGUsIHRoaXMuY29uZmlnKTtcclxuICAgICAgICB0aGlzLnJvdGF0ZVRpdGxlWSA9IHRoaXMuY2hhcnRUeXBlWzBdICE9PSAnYmFyJyAmJiB0aGlzLl9jaGFydFN2Yy5jaGVja1JvdGF0ZVRpdGxlRW5hYmxlZCh0aGlzLmNoYXJ0VHlwZSwgdGhpcy5jb25maWcpO1xyXG5cclxuICAgICAgICAvLyB0aGlzIGZsYWcgaXMgZm9yIGFsbCBheGlzQ2hhcnRzIGV4Y2VwdCBmb3IgYmFyLiBCYXIgZG8gbm90IG5lZWQgcGFkZGluXHJcbiAgICAgICAgdGhpcy5oYXZlQXhpc1BhZGRpbmcgPSB0aGlzLmNoYXJ0VHlwZVswXSAhPT0gJ2Jhcic7XHJcbiAgICAgICAgdGhpcy5oYXZlQXhpc1NwZWNpYWxQYWRkaW5nID0gdGhpcy5jaGFydFR5cGVbdGhpcy5jaGFydFR5cGUubGVuZ3RoIC0gMV0gPT09ICd0eXBlMic7XHJcbiAgICAgICAgdGhpcy5pc05lZ2F0aXZlU3RhY2sgPSAodGhpcy5jaGFydENhdGVnb3J5ID09PSAnYmFyJyB8fCB0aGlzLmNoYXJ0Q2F0ZWdvcnkgPT09ICdjb2x1bW4nICkgJiYgdGhpcy5jaGFydFR5cGVbMV0gPT09ICdzdGFjaycgJiYgdGhpcy5jaGFydFR5cGVbMl0gPT09ICduZWdhdGl2ZSc7XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfdXBkYXRlTGVnZW5kSWNvbldpdGhJbmRleChfbGVnZW5kSWQsIF9pbmRleD86IG51bWJlcikge1xyXG4gICAgICAgIGxldCBsZWdlbmRJZDogc3RyaW5nID0gX2xlZ2VuZElkLCBsZWdlbmRDb25maWc6IElMZWdlbmREYXRhO1xyXG4gICAgICAgIC8vIGlmIGxlZ2VuZElkIGlzIGdpdmVuLCB3ZSBzaG91bGQgZm9sbG93IGxlZ2VuZElkXHJcbiAgICAgICAgaWYgKCFsZWdlbmRJZCkge1xyXG4gICAgICAgICAgICAvLyBpZiBubyBsZWdlbmRJZCwgZm9sbG93IF9pbmRleFxyXG4gICAgICAgICAgICBpZiAoX2luZGV4ID09PSBudWxsIHx8IF9pbmRleCA9PT0gdW5kZWZpbmVkKSByZXR1cm47XHJcbiAgICAgICAgICAgIGxlZ2VuZElkID0gdGhpcy5sZWdlbmRMaXN0W19pbmRleF07XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGxlZ2VuZENvbmZpZyA9IHRoaXMubGVnZW5kRGF0YVtsZWdlbmRJZF07XHJcbiAgICAgICAgdGhpcy5fdXBkYXRlTGVnZW5kSWNvbihsZWdlbmRJZCwgbGVnZW5kQ29uZmlnKTtcclxuICAgIH1cclxuXHJcblxyXG4gICAgcHJpdmF0ZSBfcG9wdWxhdGVMZWdlbmRJY29uKGluZGV4PzogbnVtYmVyKTogdm9pZCB7XHJcbiAgICAgICAgaWYgKCF0aGlzLmxlZ2VuZERhdGEpIHJldHVybjtcclxuXHJcbiAgICAgICAgdGhpcy5sZWdlbmRMaXN0ID0gT2JqZWN0LmtleXModGhpcy5sZWdlbmREYXRhKTtcclxuXHJcbiAgICAgICAgZm9yIChsZXQgaTogbnVtYmVyID0gMDsgaSA8IHRoaXMubGVnZW5kTGlzdC5sZW5ndGg7IGkrKykge1xyXG4gICAgICAgICAgICBsZXQgbGVnZW5kSWQ6IHN0cmluZyA9IHRoaXMubGVnZW5kTGlzdFtpXTtcclxuICAgICAgICAgICAgbGV0IGxlZ2VuZENvbmZpZzogSUxlZ2VuZERhdGEgPSB0aGlzLmxlZ2VuZERhdGFbbGVnZW5kSWRdO1xyXG5cclxuICAgICAgICAgICAgLy8gbGV0IGVhY2hTdmcgPSB0aGlzLnJlbmRlcmVyLmNyZWF0ZUVsZW1lbnQoJ3N2ZycpO1xyXG4gICAgICAgICAgICAvLyB0aGlzLnJlbmRlcmVyLnNldEF0dHJpYnV0ZShlYWNoU3ZnLCAnZmlsbCcsIHRoaXMuY29uZmlnLmxlZ2VuZERhdGFbbGVnZW5kSWRdLmNvbG9yKTtcclxuICAgICAgICAgICAgLy8gdGhpcy5yZW5kZXJlci5zZXRBdHRyaWJ1dGUoZWFjaFN2ZywgJ3dpZHRoJywgOCk7XHJcbiAgICAgICAgICAgIC8vIHRoaXMucmVuZGVyZXIuc2V0QXR0cmlidXRlKGVhY2hTdmcsICdoZWlnaHQnLCA4KTtcclxuICAgICAgICAgICAgLy8gbGV0IGVhY2hTdmdQYXRoID0gdGhpcy5yZW5kZXJlci5jcmVhdGVFbGVtZW50KCdwYXRoJyk7XHJcbiAgICAgICAgICAgIC8vIHRoaXMucmVuZGVyZXIuc2V0QXR0cmlidXRlKGVhY2hTdmdQYXRoLCAnZCcsIHRoaXMuY29uZmlnLmxlZ2VuZERhdGFbbGVnZW5kSWRdLnNoYXBlKTtcclxuICAgICAgICAgICAgLy8gdGhpcy5yZW5kZXJlci5hcHBlbmRDaGlsZChlYWNoU3ZnLCBlYWNoU3ZnUGF0aCk7XHJcblxyXG4gICAgICAgICAgICAvLyBsZXQgeG1sID0gbmV3IFhNTFNlcmlhbGl6ZXIoKS5zZXJpYWxpemVUb1N0cmluZyhlYWNoU3ZnKTtBUklcclxuICAgICAgICAgICAgLy8gbGV0IGRhdGEgPSBcImRhdGE6aW1hZ2Uvc3ZnK3htbDtiYXNlNjQsXCIgKyBidG9hKHhtbCk7XHJcblxyXG4gICAgICAgICAgICAvLyB0aGlzLmljb25zW2xlZ2VuZElkXSA9IHRoaXMuX3Nhbml0aXplci5ieXBhc3NTZWN1cml0eVRydXN0UmVzb3VyY2VVcmwoJ2RhdGE6aW1hZ2Uvc3ZnK3htbDt1dGY4LDxzdmcgeG1sbnM9XCJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2Z1wiIGZpbGw9XCInICsgbGVnZW5kQ29uZmlnLmNvbG9yICsgJ1wiIHdpZHRoPVwiOFwiIGhlaWdodD1cIjhcIj48cGF0aCBkPVwiJyArIHRoaXMuc2hhcGVzW2xlZ2VuZENvbmZpZy5zaGFwZV0gKyAnXCIvPjwvc3ZnPicpO1xyXG4gICAgICAgICAgICAvLyB0aGlzLmljb25zW2xlZ2VuZElkXSA9IHRoaXMuX3Nhbml0aXplci5ieXBhc3NTZWN1cml0eVRydXN0UmVzb3VyY2VVcmwoZGF0YSk7XHJcblxyXG4gICAgICAgICAgICAvLyBsZWdlbmQgaXMgc2V0IGJhc2VkIG9uIHdoZXRoZXIgdGhlcmUgaXMgZGVhY3RpdmVcclxuICAgICAgICAgICAgdGhpcy5fdXBkYXRlTGVnZW5kSWNvbihsZWdlbmRJZCwgbGVnZW5kQ29uZmlnKTtcclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfc2V0TGFiZWxTdHlsZSgpOiB2b2lkIHtcclxuICAgICAgICBpZiAodGhpcy5jb25maWcuY2hhcnQubGFiZWxzLmVuYWJsZWQpIHtcclxuICAgICAgICAgICAgbGV0IGxhYmVsU3R5bGU6IHN0cmluZyA9IHRoaXMuX2NoYXJ0U3ZjLmdldFN0eWxlKHRoaXMuY29uZmlnLmNoYXJ0LmxhYmVscy5zdHlsZSk7XHJcblxyXG4gICAgICAgICAgICB0aGlzLl9hcHBseUxhYmVsU3R5bGUobGFiZWxTdHlsZSwgJyBzcGFuJywgdHJ1ZSk7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX3NldERhdGEoX2RhdGE6IGFueSk6IHZvaWQge1xyXG4gICAgICAgIHRoaXMubGVnZW5kSW5hY3RpdmUgPSBbXTtcclxuICAgICAgICB0aGlzLm1hcmtlcnNMZWdlbmQgPSBbXTsgICAgICAgIFxyXG4gICAgICAgIHRoaXMuX3NldENoYXJ0VHlwZShfZGF0YSk7XHJcblxyXG4gICAgICAgIGlmICh0aGlzLmNvbmZpZy5za2lwTWFzc2FnZSkge1xyXG4gICAgICAgICAgICB0aGlzLmRhdGEgPSBfZGF0YTtcclxuICAgICAgICAgICAgdGhpcy5fc2V0Q29uZmlnKHRoaXMuY29uZmlnKTtcclxuICAgICAgICAgICAgcmV0dXJuO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgaWYgKHRoaXMuY2hhcnRDYXRlZ29yeSA9PT0gJ3BpZScgfHwgdGhpcy5jaGFydENhdGVnb3J5ID09PSAnbWFwJykge1xyXG4gICAgICAgICAgICBpZiAodGhpcy5jaGFydENhdGVnb3J5ID09PSAncGllJykgdGhpcy5fZGF0YU1hc3NhZ2VGb3JQaWUoX2RhdGEpO1xyXG4gICAgICAgICAgICBlbHNlIGlmICh0aGlzLmNoYXJ0Q2F0ZWdvcnkgPT09ICdtYXAnKSB0aGlzLl9kYXRhTWFzc2FnZUZvck1hcChfZGF0YSk7XHJcbiAgICAgICAgICAgIC8vIGVsc2UgaWYgKHRoaXMuY2hhcnRDYXRlZ29yeSA9PT0gJ21hcCcpIHRoaXMuZGF0YSA9IF9kYXRhO1xyXG4gICAgICAgICAgICB0aGlzLl9zZXRDb25maWcodGhpcy5jb25maWcpO1xyXG4gICAgICAgIH0gZWxzZSB0aGlzLl9kYXRhTWFzc2FnZShfZGF0YSk7XHJcblxyXG4gICAgICAgIC8vIGVtaXQgZGF0YSB0byBrZC12aXN1YWxpemF0aW9uIHRvIHByZXBhcmUgZm9yIGV4cG9ydFxyXG4gICAgICAgIHRoaXMub3V0cHV0RGF0YS5lbWl0KHRoaXMuZGF0YSk7XHJcblxyXG4gICAgICAgIC8vIGVtaXQgY3VycmVudCBjb25maWcgdG8ga2QtdmlzdWFsaXphdGlvbiB0byBwcmVwYXJlIGZvciBleHBvcnRcclxuICAgICAgICB0aGlzLm91dHB1dExlZ2VuZERhdGEuZW1pdCh0aGlzLmxlZ2VuZERhdGEpO1xyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX3NldENoYXJ0VHlwZShfZGF0YSkge1xyXG4gICAgICAgIGxldCBkYXRhVG9Vc2U6IGFueSA9IF9kYXRhO1xyXG4gICAgICAgIGlmICghdGhpcy5jb25maWcuc2tpcE1hc3NhZ2UgfHwgKF9kYXRhLmNoYXJ0ICYmIF9kYXRhLmNoYXJ0LnR5cGUgPT0gJ21hcCcpKSB7XHJcbiAgICAgICAgICAgIGRhdGFUb1VzZSA9IF9kYXRhLmNoYXJ0O1xyXG4gICAgICAgIH1cclxuICAgICAgICB0aGlzLmNoYXJ0Q2F0ZWdvcnkgPSBkYXRhVG9Vc2UudHlwZTtcclxuICAgICAgICB0aGlzLmNoYXJ0VHlwZSA9IGRhdGFUb1VzZS5sYXlvdXQuc3BsaXQoJy0nKTtcclxuICAgICAgICB0aGlzLmlzQXhpc0NoYXJ0ID0gZGF0YVRvVXNlLnR5cGUgIT09ICdwaWUnICYmIGRhdGFUb1VzZS50eXBlICE9PSAnbWFwJztcclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF9zZXREYXRhQ29sb3JTaGFwZShfaW5kZXg6IG51bWJlciwgX2NvbG9yOiBzdHJpbmcpOiB2b2lkIHtcclxuICAgICAgICBpZiAoX2luZGV4IDwgMCkgeyByZXR1cm47IH1cclxuICAgICAgICAvLyBsZXQgY2hhbmdlU2VyaWVzOiBib29sZWFuID0gdGhpcy5jb25maWcuY2hhcnQuaGFzT3duUHJvcGVydHkoJ3BlcnNpc3RlbnRTZXJpZXNDaGFuZ2UnKSA/IHRoaXMuY29uZmlnLmNoYXJ0LnBlcnNpc3RlbnRTZXJpZXNDaGFuZ2UgOiB0cnVlO1xyXG4gICAgICAgIGxldCBsZWdlbmRJZHM6IEFycmF5PHN0cmluZz4gPSBPYmplY3Qua2V5cyh0aGlzLmxlZ2VuZERhdGEpO1xyXG4gICAgICAgIGlmICh0aGlzLmNoYXJ0Q2F0ZWdvcnkgIT0gJ21hcCcpIHtcclxuICAgICAgICAgICAgZm9yIChsZXQgeEluZGV4OiBudW1iZXIgPSB0aGlzLmRhdGEuZGF0YS5sZW5ndGggLSAxOyB4SW5kZXggPj0gMDsgeEluZGV4LS0pIHtcclxuICAgICAgICAgICAgICAgIGZvciAobGV0IHlJbmRleDogbnVtYmVyID0gdGhpcy5kYXRhLmRhdGFbeEluZGV4XS55Lmxlbmd0aCAtIDE7IHlJbmRleCA+PSAwOyB5SW5kZXgtLSkge1xyXG4gICAgICAgICAgICAgICAgICAgIGlmICh0aGlzLmRhdGEuZGF0YVt4SW5kZXhdLnlbeUluZGV4XS5pZCA9PT0gbGVnZW5kSWRzW19pbmRleF0pIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5fY2hhbmdlU2VyaWVzKHhJbmRleCwgeUluZGV4LCAnY29sb3InKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5fY2hhbmdlU2VyaWVzKHhJbmRleCwgeUluZGV4LCAnc2hhcGUnKTtcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfY2hhbmdlU2VyaWVzKF94SW5kZXg6IG51bWJlciwgX3lJbmRleDogbnVtYmVyLCBfZWxlbWVudDogJ2NvbG9yJyB8ICdzaGFwZScpOiB2b2lkIHtcclxuICAgICAgICBsZXQgbGVnZW5kSWQ6IHN0cmluZyA9IHRoaXMuZGF0YS5kYXRhW194SW5kZXhdLnlbX3lJbmRleF0uaWQ7XHJcbiAgICAgICAgbGV0IG91dHB1dDogYW55ID0gdGhpcy5sZWdlbmREYXRhW2xlZ2VuZElkXVtfZWxlbWVudF07XHJcbiAgICAgICAgaWYgKF9lbGVtZW50ID09PSAnc2hhcGUnKSB7XHJcbiAgICAgICAgICAgIG91dHB1dCA9IHRoaXMuc2hhcGVzW291dHB1dF07XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGlmICh0aGlzLl9pc0NoYW5nZVNlcmllcyhfeEluZGV4LCBfeUluZGV4LCBfZWxlbWVudCkpIHtcclxuICAgICAgICAgICAgdGhpcy5kYXRhLmRhdGFbX3hJbmRleF0ueVtfeUluZGV4XVtfZWxlbWVudF0gPSBvdXRwdXQ7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX2lzQ2hhbmdlU2VyaWVzKF94SW5kZXg6IG51bWJlciwgX3lJbmRleDogbnVtYmVyLCBfZWxlbWVudDogJ2NvbG9yJyB8ICdzaGFwZScpOiBib29sZWFuIHtcclxuICAgICAgICBsZXQgY2hhbmdlU2VyaWVzOiBib29sZWFuID0gdGhpcy5jb25maWcuY2hhcnQuaGFzT3duUHJvcGVydHkoJ3BlcnNpc3RlbnRTZXJpZXNDaGFuZ2UnKSA/IHRoaXMuY29uZmlnLmNoYXJ0LnBlcnNpc3RlbnRTZXJpZXNDaGFuZ2UgOiB0cnVlO1xyXG4gICAgICAgIGlmIChjaGFuZ2VTZXJpZXMpIHtcclxuICAgICAgICAgICAgcmV0dXJuIHRydWU7XHJcbiAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgaWYgKHRoaXMuY2hhcnREYXRhLnNlcmllc1tfeUluZGV4XS5kYXRhW194SW5kZXhdLmhhc093blByb3BlcnR5KF9lbGVtZW50KSkge1xyXG4gICAgICAgICAgICAgICAgaWYgKHRoaXMuY2hhcnREYXRhLnNlcmllc1tfeUluZGV4XS5kYXRhW194SW5kZXhdW19lbGVtZW50XSAhPT0gbnVsbCB8fCB0aGlzLmNoYXJ0RGF0YS5zZXJpZXNbX3lJbmRleF0uZGF0YVtfeEluZGV4XVtfZWxlbWVudF0ubGVuZ3RoID4gMCkge1xyXG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBmYWxzZTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgICAgICByZXR1cm4gdHJ1ZTtcclxuICAgIH1cclxuXHJcbiAgICBwdWJsaWMgb25MZWdlbmRDbGljayhfaWQ6IHN0cmluZyk6IHZvaWQge1xyXG4gICAgICAgIGxldCBsZWdlbmRDb25maWc6IElMZWdlbmREYXRhID0gdGhpcy5sZWdlbmREYXRhW19pZF07XHJcblxyXG4gICAgICAgIGxlZ2VuZENvbmZpZy5kZWFjdGl2ZSA9ICFsZWdlbmRDb25maWcuZGVhY3RpdmUgfHwgZmFsc2U7XHJcblxyXG4gICAgICAgIHRoaXMuX3VwZGF0ZUxlZ2VuZEl0ZW0oX2lkLCBsZWdlbmRDb25maWcpO1xyXG5cclxuICAgICAgICBpZiAobGVnZW5kQ29uZmlnLmRlYWN0aXZlKSB7XHJcbiAgICAgICAgICAgIHRoaXMubGVnZW5kSW5hY3RpdmUucHVzaChfaWQpO1xyXG4gICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgIGxldCBpZEluZGV4OiBudW1iZXIgPSB0aGlzLmxlZ2VuZEluYWN0aXZlLmluZGV4T2YoX2lkKTtcclxuICAgICAgICAgICAgaWYgKGlkSW5kZXggIT09IC0xKSB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLmxlZ2VuZEluYWN0aXZlLnNwbGljZShpZEluZGV4LCAxKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgaWYgKHRoaXMuY2hhcnRDYXRlZ29yeSAhPSAnbWFwJykge1xyXG4gICAgICAgICAgICBsZXQgbGVnZW5kRGF0YTogeyBba2V5OiBzdHJpbmddOiBJTGVnZW5kRGF0YSB9ID0gdGhpcy51cGRhdGVDb25maWcoKTtcclxuICAgICAgICAgICAgbGV0IGRhdGE6IElEM0RhdGEgPSB0aGlzLnVwZGF0ZURhdGEobGVnZW5kRGF0YSk7XHJcblxyXG4gICAgICAgICAgICB0aGlzLmFwaS5sZWdlbmRDbGljayhkYXRhLCBsZWdlbmREYXRhKTtcclxuICAgICAgICAgICAgdGhpcy5fdG9nZ2xlRGF0YUxhYmVsKF9pZCwgbGVnZW5kQ29uZmlnLmRlYWN0aXZlKTtcclxuICAgICAgICAgICAgLy8gdXBkYXRlIGRhdGEgdG8ga2QtdmlzdWFsaXphdGlvbiB0byBwcmVwYXJlIGZvciBleHBvcnRpbmdcclxuICAgICAgICAgICAgdGhpcy5vdXRwdXREYXRhLmVtaXQoZGF0YSk7XHJcbiAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgdGhpcy5hcGkubGVnZW5kQ2xpY2soX2lkLCBsZWdlbmRDb25maWcuZGVhY3RpdmUpO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICB9XHJcblxyXG4gICAgcHVibGljIG9uQ2x1c3RlckNsaWNrKF9pZDogYW55KTogdm9pZCB7XHJcbiAgICAgICAgbGV0IGxlZ2VuZEl0ZW1NYXJrZXI6IEhUTUxFbGVtZW50ID0gdGhpcy5fZWxlbWVudFJlZi5uYXRpdmVFbGVtZW50LnF1ZXJ5U2VsZWN0b3IoJyNrZGxpLScgKyBfaWQuaWQgKyAnIC5hd2Vzb21lLW1hcmtlcicpO1xyXG4gICAgICAgIGxldCBsZWdlbmRJdGVtTGFiZWw6IEhUTUxFbGVtZW50ID0gdGhpcy5fZWxlbWVudFJlZi5uYXRpdmVFbGVtZW50LnF1ZXJ5U2VsZWN0b3IoJyNrZGxpLScgKyBfaWQuaWQgKyAnIC5rZHgtbGVnZW5kLWxhYmVsJyk7XHJcblxyXG4gICAgICAgIHRoaXMuYXBpLmNsdXN0ZXJDbGljayhfaWQsIHsnbGVnZW5kSXRlbU1hcmtlcic6IGxlZ2VuZEl0ZW1NYXJrZXIsICdsZWdlbmRJdGVtTGFiZWwnOiBsZWdlbmRJdGVtTGFiZWx9KTtcclxuICAgIH1cclxuXHJcbiAgICBwdWJsaWMgZ2V0T3V0cHV0TGVnZW5kKF9sZWdlbmREYXRhOiB7IFtrZXk6IHN0cmluZ106IElMZWdlbmREYXRhIH0pOiB2b2lkIHtcclxuICAgICAgICBpZiAodGhpcy5jaGFydENhdGVnb3J5ID09ICdtYXAnICYmIE9iamVjdC5rZXlzKF9sZWdlbmREYXRhKS5sZW5ndGggPT0gMCkge1xyXG4gICAgICAgICAgICB0aGlzLmNoZWNrTWFwU2NhbGUgPSB0cnVlO1xyXG4gICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgIHRoaXMubGVnZW5kRGF0YSA9IF9sZWdlbmREYXRhO1xyXG4gICAgICAgICAgICB0aGlzLmNoZWNrTWFwU2NhbGUgPSBmYWxzZTtcclxuICAgICAgICAgICAgdGhpcy5fcGllRG9uZUZsYWcgPSB0cnVlO1xyXG4gICAgICAgICAgICB0aGlzLm91dHB1dExlZ2VuZERhdGEuZW1pdCh0aGlzLmxlZ2VuZERhdGEpO1xyXG4gICAgICAgICAgICB0aGlzLl9wb3B1bGF0ZUxlZ2VuZEljb24odW5kZWZpbmVkKTtcclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgcHVibGljIGdldE91dHB1dERhdGEoX2RhdGE6IGFueSk6IHZvaWQge1xyXG4gICAgICAgIC8vIHRoaXMub3V0cHV0RGF0YS5lbWl0KF9kYXRhKTtcclxuICAgICAgICB0aGlzLm91dHB1dEFyZWEuZW1pdChfZGF0YSk7XHJcbiAgICB9XHJcblxyXG4gICAgcHVibGljIGdldFJlYWR5KF92YWx1ZTogYm9vbGVhbikgOiB2b2lkIHtcclxuICAgICAgICB0aGlzLmlzTGF5ZXJMb2FkaW5nID0gX3ZhbHVlO1xyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX3VwZGF0ZUxlZ2VuZEl0ZW0oX2lkLCBfbGVnZW5kQ29uZmlnKTogdm9pZCB7XHJcbiAgICAgICAgdGhpcy5fdXBkYXRlTGVnZW5kSWNvbihfaWQsIF9sZWdlbmRDb25maWcpO1xyXG4gICAgICAgIGxldCB0ZXh0Q29sb3I6IHN0cmluZyA9IChfbGVnZW5kQ29uZmlnLmRlYWN0aXZlKSA/IHRoaXMuY29uZmlnLmxlZ2VuZC5pdGVtLmluYWN0aXZlQ29sb3IgfHwgJyNDQ0NDQ0MnIDogdGhpcy5jb25maWcubGVnZW5kLml0ZW0uc3R5bGUuY29sb3IgfHwgdGhpcy5jb25maWcubGVnZW5kLml0ZW0uYWN0aXZlQ29sb3IgfHwgJyMwMDAwMDAnO1xyXG4gICAgICAgIHRoaXMuX2VsZW1lbnRSZWYubmF0aXZlRWxlbWVudC5xdWVyeVNlbGVjdG9yKCcja2RsaS0nICsgX2lkKS5zdHlsZS5jb2xvciA9IHRleHRDb2xvcjtcclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF91cGRhdGVMZWdlbmRJY29uKF9pZCwgX2xlZ2VuZENvbmZpZyk6IHZvaWQge1xyXG4gICAgICAgIGxldCBpY29uQ29sb3I6IHN0cmluZyA9IChfbGVnZW5kQ29uZmlnLmRlYWN0aXZlKSA/IHRoaXMuY29uZmlnLmxlZ2VuZC5pdGVtLmluYWN0aXZlQ29sb3IgfHwgJyNDQ0NDQ0MnIDogX2xlZ2VuZENvbmZpZy5jb2xvciB8fCAnIzAwMDAwMCc7XHJcbiAgICAgICAgbGV0IHJnYkNvbG9yOiBzdHJpbmcgPSB0aGlzLl9jb252ZXJ0aW9uU3ZjLmNvbG9yVG9SZ2IoaWNvbkNvbG9yKTtcclxuICAgICAgICB0aGlzLmljb25zW19pZF0gPSB0aGlzLl9zYW5pdGl6ZXIuYnlwYXNzU2VjdXJpdHlUcnVzdFJlc291cmNlVXJsKCdkYXRhOmltYWdlL3N2Zyt4bWw7dXRmOCw8c3ZnIHhtbG5zPVwiaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmdcIiBmaWxsPVwiJyArIHJnYkNvbG9yICsgJ1wiIHdpZHRoPVwiOFwiIGhlaWdodD1cIjhcIj48cGF0aCBkPVwiJyArIHRoaXMuc2hhcGVzW19sZWdlbmRDb25maWcuc2hhcGVdICsgJ1wiLz48L3N2Zz4nKTtcclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF90b2dnbGVEYXRhTGFiZWwoaWQ6IHN0cmluZywgZGVhY3RpdmU6IGJvb2xlYW4pOiB2b2lkIHtcclxuICAgICAgICBsZXQgZGlzcGxheVN0YXRlOiBzdHJpbmcgPSAoZGVhY3RpdmUpID8gJ25vbmUnIDogJ2ZsZXgnO1xyXG4gICAgICAgIHRoaXMuX2FwcGx5TGFiZWxTdHlsZShkaXNwbGF5U3RhdGUsICcueS0nICsgaWQpO1xyXG4gICAgICAgIGlmICghZGVhY3RpdmUpIHRoaXMuX2FwcGx5TGFiZWxTdHlsZSgnZGlzcGxheTonICsgZGlzcGxheVN0YXRlLCAnLnktJyArIGlkICsgJyBzcGFuJywgdHJ1ZSk7XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfYXBwbHlMYWJlbFN0eWxlKF9zdHlsZTogc3RyaW5nLCB0YXJnZXQ6IHN0cmluZywgaXNSZXBvc2l0aW9uaW5nPzogYm9vbGVhbik6IHZvaWQge1xyXG4gICAgICAgIHRhcmdldCA9IHRhcmdldCB8fCAnJztcclxuICAgICAgICBsZXQgYWxsTGFiZWw6IEhUTUxFbGVtZW50ID0gdGhpcy5fZWxlbWVudFJlZi5uYXRpdmVFbGVtZW50LnF1ZXJ5U2VsZWN0b3JBbGwoJyMnICsgdGhpcy5jb25maWcuaWQgKyAnIC5rZHgtY2hhcnRzLWRhdGEtbGFiZWwnICsgdGFyZ2V0KTtcclxuICAgICAgICBmb3IgKGxldCBpIGluIGFsbExhYmVsKSB7XHJcbiAgICAgICAgICAgIGlmIChhbGxMYWJlbFtpXS5zdHlsZSkge1xyXG5cclxuICAgICAgICAgICAgICAgIGlmIChpc1JlcG9zaXRpb25pbmcpIHtcclxuICAgICAgICAgICAgICAgICAgICBsZXQgbGFiZWxXaWR0aDogbnVtYmVyID0gYWxsTGFiZWxbaV0ub2Zmc2V0V2lkdGg7XHJcbiAgICAgICAgICAgICAgICAgICAgbGV0IGxhYmVsQ2VudGVyOiBudW1iZXIgPSAobGFiZWxXaWR0aCAtIGxhYmVsV2lkdGggLyBhbGxMYWJlbFtpXS5pbm5lclRleHQudG9TdHJpbmcoKS5sZW5ndGgpIC8gMjtcclxuICAgICAgICAgICAgICAgICAgICBsZXQgc2hpZnRQb3NpdGlvbjogbnVtYmVyID0gMCAtIGxhYmVsQ2VudGVyO1xyXG5cclxuICAgICAgICAgICAgICAgICAgICBfc3R5bGUgKz0gJ2xlZnQ6JyArIHNoaWZ0UG9zaXRpb24gKyAncHg7JztcclxuICAgICAgICAgICAgICAgICAgICBhbGxMYWJlbFtpXS5zdHlsZSA9IF9zdHlsZTtcclxuICAgICAgICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgICAgICAgICAgYWxsTGFiZWxbaV0uc3R5bGUuZGlzcGxheSA9IF9zdHlsZTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIHVwZGF0ZUNvbmZpZygpOiB7IFtrZXk6IHN0cmluZ106IElMZWdlbmREYXRhIH0ge1xyXG4gICAgICAgIGxldCBsZWdlbmREYXRhOiB7IFtrZXk6IHN0cmluZ106IElMZWdlbmREYXRhIH0gPSBPYmplY3QuYXNzaWduKHt9LCB0aGlzLmxlZ2VuZERhdGEpO1xyXG4gICAgICAgIGxldCBsZWdlbmRJbmFjdGl2ZTogQXJyYXk8c3RyaW5nPiA9IHRoaXMubGVnZW5kSW5hY3RpdmU7XHJcbiAgICAgICAgbGVnZW5kRGF0YSA9IE9iamVjdC5rZXlzKGxlZ2VuZERhdGEpXHJcbiAgICAgICAgICAgIC5maWx0ZXIoa2V5ID0+ICFsZWdlbmRJbmFjdGl2ZS5pbmNsdWRlcyhrZXkpKVxyXG4gICAgICAgICAgICAucmVkdWNlKChvYmosIGtleSkgPT4ge1xyXG4gICAgICAgICAgICAgICAgb2JqW2tleV0gPSBsZWdlbmREYXRhW2tleV07XHJcbiAgICAgICAgICAgICAgICByZXR1cm4gb2JqO1xyXG4gICAgICAgICAgICB9LCB7fSk7XHJcbiAgICAgICAgcmV0dXJuIGxlZ2VuZERhdGE7XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSB1cGRhdGVEYXRhKF9sZWdlbmREYXRhPzogeyBba2V5OiBzdHJpbmddOiBJTGVnZW5kRGF0YSB9KTogSUQzRGF0YSB7XHJcbiAgICAgICAgbGV0IHRoaXNEYXRhOiBJRDNEYXRhID0gSlNPTi5wYXJzZShKU09OLnN0cmluZ2lmeSh0aGlzLmRhdGEpKTtcclxuICAgICAgICBsZXQgbGVnZW5kSW5hY3RpdmU6IEFycmF5PHN0cmluZz4gPSB0aGlzLmxlZ2VuZEluYWN0aXZlO1xyXG5cclxuICAgICAgICBpZiAodGhpcy5jaGFydENhdGVnb3J5ID09PSAncGllJykge1xyXG4gICAgICAgICAgICBsZXQgbGVnZW5kRGF0YTogYW55ID0gX2xlZ2VuZERhdGE7XHJcbiAgICAgICAgICAgIC8vIHBpZWRhdGEgdXNlcyBsZWdlbmREYXRhIGluc3RlYWQgb2YgZGF0YVxyXG4gICAgICAgICAgICB0aGlzRGF0YS5kYXRhID0gT2JqZWN0LmtleXMobGVnZW5kRGF0YSkubWFwKGtleSA9PiBsZWdlbmREYXRhW2tleV0pLmZpbHRlcigodmFsdWUpID0+IHZhbHVlLnkgJiYgdmFsdWUueSA+IDApO1xyXG4gICAgICAgICAgICByZXR1cm4gdGhpc0RhdGE7XHJcbiAgICAgICAgfSBlbHNlIGlmICh0aGlzLmNoYXJ0VHlwZVsxXSA9PT0gJzEwMCcgJiYgdGhpcy5jaGFydFR5cGVbMF0gPT09ICdhcmVhJykge1xyXG4gICAgICAgICAgICBmb3IgKGxldCBpOiBudW1iZXIgPSB0aGlzRGF0YS5kYXRhLmxlbmd0aCAtIDE7IGkgPj0gMDsgaS0tKSB7XHJcbiAgICAgICAgICAgICAgICBsZXQgbmV3WUFycjogQXJyYXk8SUQzWURhdGE+ID0gdGhpc0RhdGEuZGF0YVtpXS55LmZpbHRlcihkID0+ICFsZWdlbmRJbmFjdGl2ZS5pbmNsdWRlcyhkLmlkKSk7XHJcbiAgICAgICAgICAgICAgICB0aGlzRGF0YS5kYXRhW2ldID0gT2JqZWN0LmFzc2lnbih7fSwgdGhpc0RhdGEuZGF0YVtpXSwgeyB5OiBuZXdZQXJyIH0pO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICBsZXQgb3JpZ2luYWxEYXRhOiBJRDNEYXRhID0gSlNPTi5wYXJzZShKU09OLnN0cmluZ2lmeSh0aGlzRGF0YSkpO1xyXG5cclxuICAgICAgICBsZXQgYWxsU3VtQXJyTWF4OiBBcnJheTxudW1iZXI+ID0gWzBdO1xyXG4gICAgICAgIGxldCBhbGxTdW1BcnJNaW46IEFycmF5PG51bWJlcj4gPSBbMF07XHJcbiAgICAgICAgbGV0IGhhdmVOZWdhdGl2ZTogYm9vbGVhbiA9IGZhbHNlO1xyXG5cclxuICAgICAgICBmb3IgKGxldCBpOiBudW1iZXIgPSAwOyBpIDwgb3JpZ2luYWxEYXRhLmRhdGEubGVuZ3RoOyBpKyspIHtcclxuICAgICAgICAgICAgbGV0IHRvdGFsU3VtOiBudW1iZXIgPSAxO1xyXG4gICAgICAgICAgICBpZiAodGhpcy5jaGFydFR5cGVbMV0gPT09ICcxMDAnKSB7XHJcbiAgICAgICAgICAgICAgICB0b3RhbFN1bSA9IHRoaXNEYXRhLmRhdGFbaV0ueS5yZWR1Y2UoKGFjYywgY3VyciwgeUluZGV4KSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKGxlZ2VuZEluYWN0aXZlLmluY2x1ZGVzKGN1cnIuaWQpKSByZXR1cm4gYWNjO1xyXG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBhY2MgKyBjdXJyLnZhbHVlO1xyXG4gICAgICAgICAgICAgICAgfSwgMCk7XHJcbiAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgIGxldCBuZXdZQXJyOiBBcnJheTxhbnk+ID0gW107XHJcbiAgICAgICAgICAgIGxldCBzdW1BcnI6IEFycmF5PG51bWJlcj4gPSBbXTtcclxuICAgICAgICAgICAgbGV0IHN1bTogbnVtYmVyID0gMDtcclxuICAgICAgICAgICAgbGV0IHN1bU5lZ2F0aXZlOiBudW1iZXIgPSAwO1xyXG5cclxuICAgICAgICAgICAgZm9yIChsZXQgeUluZGV4OiBudW1iZXIgPSAwOyB5SW5kZXggPCBvcmlnaW5hbERhdGEuZGF0YVtpXS55Lmxlbmd0aDsgeUluZGV4KyspIHtcclxuICAgICAgICAgICAgICAgIGxldCBjdXJyWTogSUQzWURhdGEgPSBPYmplY3QuYXNzaWduKHt9LCBvcmlnaW5hbERhdGEuZGF0YVtpXS55W3lJbmRleF0pO1xyXG4gICAgICAgICAgICAgICAgaWYgKGxlZ2VuZEluYWN0aXZlLmluY2x1ZGVzKGN1cnJZLmlkKSkgY29udGludWU7XHJcbiAgICAgICAgICAgICAgICBsZXQgY3VycmVudFZhbDogbnVtYmVyID0gY3VyclkudmFsdWUgPT09IG51bGwgPyAwIDogY3VyclkudmFsdWU7XHJcbiAgICAgICAgICAgICAgICBsZXQgY3VyclNpZ246IG51bWJlciA9IE1hdGguc2lnbihjdXJyZW50VmFsKTtcclxuXHJcbiAgICAgICAgICAgICAgICBpZiAoY3VyclNpZ24gPCAwICYmICFoYXZlTmVnYXRpdmUpIHtcclxuICAgICAgICAgICAgICAgICAgICBoYXZlTmVnYXRpdmUgPSB0cnVlO1xyXG4gICAgICAgICAgICAgICAgICAgIGlmICh0aGlzLmNoYXJ0VHlwZVsxXSA9PT0gJzEwMCcpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5jaGFydEhpZGUgPSB0cnVlO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBicmVhaztcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICAgICAgaWYgKHRoaXMuY2hhcnRUeXBlWzFdICE9PSAnMTAwJyAmJiB0aGlzLmNoYXJ0VHlwZVsxXSA9PT0gJ3N0YWNrJykge1xyXG4gICAgICAgICAgICAgICAgICAgIGlmIChjdXJyU2lnbiA+PSAwKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHN1bSA9IChjdXJyZW50VmFsID09PSBudWxsKSA/IHN1bSA6IHN1bSArIGN1cnJlbnRWYWw7XHJcbiAgICAgICAgICAgICAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgc3VtTmVnYXRpdmUgPSAoY3VycmVudFZhbCA9PT0gbnVsbCkgPyBzdW1OZWdhdGl2ZSA6IHN1bU5lZ2F0aXZlICsgY3VycmVudFZhbDtcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICB9IGVsc2UgaWYgKHRoaXMuY2hhcnRUeXBlWzFdID09PSAnMTAwJykge1xyXG4gICAgICAgICAgICAgICAgICAgIGlmIChjdXJyZW50VmFsICE9PSBudWxsICYmIHRvdGFsU3VtICE9PSAwKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGN1cnJlbnRWYWwgPSBjdXJyZW50VmFsIC8gdG90YWxTdW0gKiAxMDA7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHN1bSA9IHN1bSArIGN1cnJlbnRWYWw7XHJcbiAgICAgICAgICAgICAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgc3VtID0gc3VtO1xyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKGN1cnJTaWduID49IDApIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgc3VtID0gKGN1cnJlbnRWYWwgPT09IG51bGwpID8gMCA6IGN1cnJlbnRWYWw7XHJcbiAgICAgICAgICAgICAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgc3VtTmVnYXRpdmUgPSAoY3VycmVudFZhbCA9PT0gbnVsbCkgPyAwIDogY3VycmVudFZhbDtcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICBjdXJyWS5zdW0gPSBjdXJyZW50VmFsID49IDAgPyBzdW0gOiBzdW1OZWdhdGl2ZTtcclxuXHJcbiAgICAgICAgICAgICAgICAvLyB2YWx1ZSBpcyB1c2VkIHRvIGRpc3BsYXkgZGF0YS1sYWJlbCBhbmQgdG9vbHRpcCwgcmVuZGVyVmFsIGlzIHRoZSBhY3V0YWwgcGVyY2VudGFnZSB0byBwYXNzIHRvIGQzIGZvciByZW5kZXJpbmdcclxuICAgICAgICAgICAgICAgIGlmICh0aGlzLmNoYXJ0VHlwZVsxXSA9PT0gJzEwMCcpIGN1cnJZWydyZW5kZXJWYWwnXSA9IGN1cnJlbnRWYWw7XHJcblxyXG4gICAgICAgICAgICAgICAgc3VtQXJyLnB1c2goTWF0aC5zaWduKGN1cnJlbnRWYWwpIDwgMCA/IHN1bU5lZ2F0aXZlIDogc3VtKTtcclxuICAgICAgICAgICAgICAgIG5ld1lBcnIucHVzaChjdXJyWSk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgYWxsU3VtQXJyTWF4LnB1c2godGhpcy5fY2hhcnRTdmMuZ2V0RDNNYXhPck1pbihzdW1BcnIsICdtYXgnKSk7XHJcbiAgICAgICAgICAgIGFsbFN1bUFyck1pbi5wdXNoKHRoaXMuX2NoYXJ0U3ZjLmdldEQzTWF4T3JNaW4oc3VtQXJyLCAnbWluJykpO1xyXG4gICAgICAgICAgICB0aGlzRGF0YS5kYXRhW2ldID0gT2JqZWN0LmFzc2lnbih7fSwgb3JpZ2luYWxEYXRhLmRhdGFbaV0sIHsgeTogbmV3WUFyciB9KTtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIHRoaXNEYXRhWydyYW5nZSddID0ge1xyXG4gICAgICAgICAgICBtYXg6IHRoaXMuX2NoYXJ0U3ZjLmdldEQzTWF4T3JNaW4oYWxsU3VtQXJyTWF4LCAnbWF4JyksXHJcbiAgICAgICAgICAgIG1pbjogdGhpcy5fY2hhcnRTdmMuZ2V0RDNNYXhPck1pbihhbGxTdW1BcnJNaW4sICdtaW4nKVxyXG4gICAgICAgIH07XHJcbiAgICAgICAgdGhpc0RhdGFbJ2hhdmVOZWdhdGl2ZSddID0gaGF2ZU5lZ2F0aXZlO1xyXG5cclxuICAgICAgICByZXR1cm4gdGhpc0RhdGE7XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfZ2VuZXJhdGVMZWdlbmREYXRhKF9kYXRhOiBJQ2hhcnREYXRhLCBtYXhTZXJpZXNMZW5ndGg6IG51bWJlcik6IG9iamVjdCB7XHJcbiAgICAgICAgLy8gZW1wdHkgb3V0IHZhcmlhYmxlcyBiZWZvcmUgcmVnZW5lcmF0aW5nXHJcbiAgICAgICAgdGhpcy5sZWdlbmREYXRhID0ge307XHJcbiAgICAgICAgLy8gdGhpcy5sZWdlbmRMaXN0ID0gbnVsbDtcclxuXHJcbiAgICAgICAgbGV0IGxlZ2VuZElkU2VhcmNoOiBvYmplY3QgPSB7fTtcclxuICAgICAgICBsZXQgbGVnZW5kSWQ6IHN0cmluZywgbGVnZW5kRGF0YU9iajogSUxlZ2VuZERhdGE7XHJcbiAgICAgICAgbGV0IGxlZ2VuZERhdGE6IHsgW2tleTogc3RyaW5nXTogSUxlZ2VuZERhdGEgfSA9IHt9O1xyXG4gICAgICAgIGZvciAobGV0IGk6IG51bWJlciA9IDA7IGkgPCBtYXhTZXJpZXNMZW5ndGg7IGkrKykge1xyXG4gICAgICAgICAgICBsZWdlbmRJZCA9IChfZGF0YS5zZXJpZXNbaV0gJiYgX2RhdGEuc2VyaWVzW2ldLmxlbmd0aCA+IDApID8gX2RhdGEuc2VyaWVzW2ldLmlkIDogJ2lkJyArIGk7XHJcbiAgICAgICAgICAgIGxlZ2VuZERhdGFPYmogPSB7XHJcbiAgICAgICAgICAgICAgICAnbmFtZSc6IF9kYXRhLnNlcmllc1tpXS5uYW1lLFxyXG4gICAgICAgICAgICAgICAgJ2lkJzogbGVnZW5kSWQsXHJcbiAgICAgICAgICAgICAgICAnY29sb3InOiBfZGF0YS5zZXJpZXNbaV0uY29sb3IgfHwgdGhpcy5fZ2V0RGVmYXVsdENvbmZpZygnY29sb3InLCBpKSxcclxuICAgICAgICAgICAgICAgICdzaGFwZSc6IF9kYXRhLnNlcmllc1tpXS5zaGFwZSB8fCB0aGlzLl9nZXREZWZhdWx0Q29uZmlnKCdzaGFwZScsIGkpXHJcbiAgICAgICAgICAgIH07XHJcbiAgICAgICAgICAgIGlmICh0aGlzLmNoYXJ0Q2F0ZWdvcnkgPT09ICdsaW5lJyB8fCB0aGlzLmNoYXJ0Q2F0ZWdvcnkgPT09ICdzcGxpbmUnIHx8IHRoaXMuY2hhcnRDYXRlZ29yeSA9PT0gJ2FyZWEnIHx8IHRoaXMuY2hhcnRDYXRlZ29yeSA9PT0gJ2RvdCcpIHtcclxuICAgICAgICAgICAgICAgIGxlZ2VuZERhdGFPYmpbJ2RvdEVuYWJsZWQnXSA9ICh0eXBlb2YgX2RhdGEuc2VyaWVzW2ldLmRvdEVuYWJsZWQgIT09ICd1bmRlZmluZWQnKSA/IF9kYXRhLnNlcmllc1tpXS5kb3RFbmFibGVkIDogdHJ1ZTtcclxuICAgICAgICAgICAgICAgIGxlZ2VuZERhdGFPYmpbJ2RvdEJvcmRlcldpZHRoJ10gPSAodHlwZW9mIF9kYXRhLnNlcmllc1tpXS5kb3RCb3JkZXJXaWR0aCAhPT0gJ3VuZGVmaW5lZCcpID8gX2RhdGEuc2VyaWVzW2ldLmRvdEJvcmRlcldpZHRoIDogMDtcclxuICAgICAgICAgICAgICAgIGxlZ2VuZERhdGFPYmpbJ2RvdEJvcmRlckNvbG9yJ10gPSAodHlwZW9mIF9kYXRhLnNlcmllc1tpXS5kb3RCb3JkZXJDb2xvciAhPT0gJ3VuZGVmaW5lZCcpID8gX2RhdGEuc2VyaWVzW2ldLmRvdEJvcmRlckNvbG9yIDogJyNGRkZGRkYnO1xyXG4gICAgICAgICAgICAgICAgaWYgKHRoaXMuY2hhcnRDYXRlZ29yeSAhPT0gJ2RvdCcpIGxlZ2VuZERhdGFPYmpbJ2xpbmVTdHlsZSddID0gKHR5cGVvZiBfZGF0YS5zZXJpZXNbaV0ubGluZVN0eWxlICE9PSAndW5kZWZpbmVkJykgPyBfZGF0YS5zZXJpZXNbaV0ubGluZVN0eWxlIDogJ3NvbGlkJztcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBsZWdlbmREYXRhW2xlZ2VuZElkXSA9IGxlZ2VuZERhdGFPYmo7XHJcbiAgICAgICAgICAgIGxlZ2VuZElkU2VhcmNoW2ldID0gbGVnZW5kSWQ7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIHRoaXMubGVnZW5kRGF0YSA9IGxlZ2VuZERhdGE7XHJcbiAgICAgICAgcmV0dXJuIGxlZ2VuZElkU2VhcmNoO1xyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX2RhdGFNYXNzYWdlKF9kYXRhOiBJQ2hhcnREYXRhKTogdm9pZCB7XHJcbiAgICAgICAgbGV0IHNlcmllc0xlbmd0aDogbnVtYmVyID0gdGhpcy5fY2hhcnRTdmMuZ2V0RDNNYXhPck1pbihbX2RhdGEuc2VyaWVzLmxlbmd0aCwgdGhpcy5zZXJpZXNUaHJlc2hvbGRdLCAnbWluJyk7XHJcbiAgICAgICAgbGV0IGNoYXJ0RGF0YU9iajogSUQzRGF0YURhdGEsIGNoYXJ0RGF0YVNlcmllc09iajogSUQzWURhdGE7XHJcbiAgICAgICAgbGV0IGNoYXJ0RGF0YTogSUQzRGF0YSA9IHtcclxuICAgICAgICAgICAgJ3R5cGUnOiBfZGF0YS5jaGFydFsndHlwZSddID8gX2RhdGEuY2hhcnRbJ3R5cGUnXSA6IG51bGwsXHJcbiAgICAgICAgICAgICdsYXlvdXQnOiBfZGF0YS5jaGFydFsnbGF5b3V0J10gPyBfZGF0YS5jaGFydFsnbGF5b3V0J10gOiBudWxsLFxyXG4gICAgICAgICAgICAnY29uZmlnJzogdGhpcy5jb25maWcucGxvdE9wdGlvbnMgJiYgdGhpcy5jb25maWcucGxvdE9wdGlvbnMuaGFzT3duUHJvcGVydHkoX2RhdGEuY2hhcnRbJ3R5cGUnXSkgPyB0aGlzLmNvbmZpZy5wbG90T3B0aW9uc1tfZGF0YS5jaGFydFsndHlwZSddXSA6IHt9LFxyXG4gICAgICAgICAgICAnZGF0YSc6IFtdXHJcbiAgICAgICAgfTtcclxuICAgICAgICBpZiAoIXRoaXMuY29uZmlnLmhhc093blByb3BlcnR5KCdpZCcpKSB7XHJcbiAgICAgICAgICAgIHRoaXMuY29uZmlnWydpZCddID0gX2RhdGEuY2hhcnRbJ3R5cGUnXSA/IF9kYXRhLmNoYXJ0Wyd0eXBlJ10gKyAnLTEnIDogJ0RlZmF1bHQtMSc7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICBsZXQgY2F0ZWdvcmllczogQXJyYXk8c3RyaW5nPiA9IHRoaXMuX2NoYXJ0U3ZjLmdldExpbWl0ZWRDYXRlZ29yaWVzKF9kYXRhLnhBeGlzLmNhdGVnb3JpZXMsIHRoaXMueFRocmVzaG9sZCk7XHJcblxyXG4gICAgICAgIGxldCBsZWdlbmRJZFNlYXJjaDogb2JqZWN0ID0gdGhpcy5fZ2VuZXJhdGVMZWdlbmREYXRhKF9kYXRhLCBzZXJpZXNMZW5ndGgpO1xyXG5cclxuICAgICAgICBsZXQgdG90YWxTdW1BcnI6IEFycmF5PG51bWJlcj4gfCBvYmplY3QgPSB0aGlzLl9nZXRUb3RhbFN1bShfZGF0YSwgc2VyaWVzTGVuZ3RoKTtcclxuICAgICAgICBsZXQgYWxsU3VtQXJyTWF4OiBBcnJheTxudW1iZXI+ID0gWzBdO1xyXG4gICAgICAgIGxldCBhbGxTdW1BcnJNaW46IEFycmF5PG51bWJlcj4gPSBbMF07XHJcbiAgICAgICAgbGV0IGhhdmVOZWdhdGl2ZTogYm9vbGVhbiA9IGZhbHNlO1xyXG5cclxuICAgICAgICBmb3IgKGxldCBpID0gMDsgaSA8IGNhdGVnb3JpZXMubGVuZ3RoOyBpKyspIHtcclxuICAgICAgICAgICAgY2hhcnREYXRhT2JqID0ge1xyXG4gICAgICAgICAgICAgICAgJ3gnOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgdmFsdWU6IGkudG9TdHJpbmcoKSxcclxuICAgICAgICAgICAgICAgICAgICBsYWJlbDogY2F0ZWdvcmllc1tpXVxyXG4gICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICAgICd5JzogW10sXHJcbiAgICAgICAgICAgICAgICAvLyAneic6ICdTaW5nYXBvcmUnXHJcbiAgICAgICAgICAgIH07XHJcblxyXG4gICAgICAgICAgICBsZXQgc3VtQXJyOiBBcnJheTxudW1iZXI+ID0gW107XHJcbiAgICAgICAgICAgIGxldCBzdW06IG51bWJlciA9IDA7XHJcbiAgICAgICAgICAgIGxldCBzdW1OZWdhdGl2ZTogbnVtYmVyID0gMDtcclxuXHJcbiAgICAgICAgICAgIGxldCBmb3JMb29wSW5mbzogSUZvckxvb3BJbmZvID0gdGhpcy5fY2hhcnRTdmMuZ2V0Rm9yTG9vcEluZm8odGhpcy5fY2hhcnRTdmMuZ2V0Rm9yTG9vcFNlcXVlbmNlKHRoaXMuY2hhcnRUeXBlKSwgc2VyaWVzTGVuZ3RoKTtcclxuXHJcbiAgICAgICAgICAgIC8vIGZvciAobGV0IGo6IG51bWJlciA9IDA7IGogPCBzZXJpZXNMZW5ndGg7IGorKykge1xyXG4gICAgICAgICAgICBmb3IgKGxldCBqOiBudW1iZXIgPSBmb3JMb29wSW5mby5zdGFydDsgZm9yTG9vcEluZm8uY2hlY2soaiwgZm9yTG9vcEluZm8uZW5kKTsgaiA9IGZvckxvb3BJbmZvLml0ZXJhdGUoaikpIHtcclxuICAgICAgICAgICAgICAgIGlmICh0eXBlb2YgX2RhdGEuc2VyaWVzW2pdLmRhdGFbaV0gPT09ICd1bmRlZmluZWQnKSBjb250aW51ZTtcclxuXHJcbiAgICAgICAgICAgICAgICBsZXQgY3VycmVudFZhbDogbnVtYmVyIHwgbnVsbCA9IF9kYXRhLnNlcmllc1tqXS5kYXRhW2ldLnZhbHVlO1xyXG4gICAgICAgICAgICAgICAgbGV0IGN1cnJTaWduOiBudW1iZXIgPSBNYXRoLnNpZ24oY3VycmVudFZhbCk7XHJcblxyXG4gICAgICAgICAgICAgICAgaWYgKHR5cGVvZiBjdXJyZW50VmFsID09PSAndW5kZWZpbmVkJykgY29udGludWU7XHJcblxyXG4gICAgICAgICAgICAgICAgaWYgKGN1cnJTaWduIDwgMCAmJiAhaGF2ZU5lZ2F0aXZlKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgaGF2ZU5lZ2F0aXZlID0gdHJ1ZTtcclxuICAgICAgICAgICAgICAgICAgICBpZiAodGhpcy5jaGFydFR5cGVbMV0gPT09ICcxMDAnKSBicmVhaztcclxuICAgICAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgICAgICBpZiAodGhpcy5jaGFydFR5cGVbMV0gIT09ICcxMDAnICYmIHRoaXMuY2hhcnRUeXBlWzFdID09PSAnc3RhY2snKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKGN1cnJTaWduID49IDApIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgc3VtID0gKGN1cnJlbnRWYWwgPT09IG51bGwpID8gc3VtIDogc3VtICsgY3VycmVudFZhbDtcclxuICAgICAgICAgICAgICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBzdW1OZWdhdGl2ZSA9IChjdXJyZW50VmFsID09PSBudWxsKSA/IHN1bU5lZ2F0aXZlIDogc3VtTmVnYXRpdmUgKyBjdXJyZW50VmFsO1xyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIH0gZWxzZSBpZiAodGhpcy5jaGFydFR5cGVbMV0gPT09ICcxMDAnKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKGN1cnJlbnRWYWwgIT09IG51bGwgJiYgdG90YWxTdW1BcnJbaV0gIT09IDApIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgY3VycmVudFZhbCA9IGN1cnJlbnRWYWwgLyB0b3RhbFN1bUFycltpXSAqIDEwMDtcclxuICAgICAgICAgICAgICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBjdXJyZW50VmFsID0gMDtcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgc3VtID0gc3VtICsgY3VycmVudFZhbDtcclxuICAgICAgICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKGN1cnJTaWduID49IDApIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgc3VtID0gKGN1cnJlbnRWYWwgPT09IG51bGwpID8gMCA6IGN1cnJlbnRWYWw7XHJcbiAgICAgICAgICAgICAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgc3VtTmVnYXRpdmUgPSAoY3VycmVudFZhbCA9PT0gbnVsbCkgPyAwIDogY3VycmVudFZhbDtcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICAgICAgY2hhcnREYXRhU2VyaWVzT2JqID0ge1xyXG4gICAgICAgICAgICAgICAgICAgICdzdW0nOiBjdXJyZW50VmFsID49IDAgPyBzdW0gOiBzdW1OZWdhdGl2ZSxcclxuICAgICAgICAgICAgICAgICAgICAndmFsdWUnOiBfZGF0YS5zZXJpZXNbal0uZGF0YVtpXS52YWx1ZSxcclxuICAgICAgICAgICAgICAgICAgICAnY29sb3InOiB0aGlzLl9nZXRDb25maWcoJ2NvbG9yJywgaiwgX2RhdGEuc2VyaWVzW2pdLmRhdGFbaV0pLFxyXG4gICAgICAgICAgICAgICAgICAgICdzaGFwZSc6IHRoaXMuc2hhcGVzW3RoaXMuX2dldENvbmZpZygnc2hhcGUnLCBqLCBfZGF0YS5zZXJpZXNbal0uZGF0YVtpXSldLFxyXG4gICAgICAgICAgICAgICAgICAgICdpZCc6IGxlZ2VuZElkU2VhcmNoW2pdXHJcbiAgICAgICAgICAgICAgICB9O1xyXG5cclxuICAgICAgICAgICAgICAgIC8vIHZhbHVlIGlzIHVzZWQgdG8gZGlzcGxheSBkYXRhLWxhYmVsIGFuZCB0b29sdGlwLCByZW5kZXJWYWwgaXMgdGhlIGFjdXRhbCBwZXJjZW50YWdlIHRvIHBhc3MgdG8gZDMgZm9yIHJlbmRlcmluZ1xyXG4gICAgICAgICAgICAgICAgaWYgKHRoaXMuY2hhcnRUeXBlWzFdID09PSAnMTAwJykgY2hhcnREYXRhU2VyaWVzT2JqWydyZW5kZXJWYWwnXSA9IGN1cnJlbnRWYWw7XHJcblxyXG4gICAgICAgICAgICAgICAgc3VtQXJyLnB1c2goTWF0aC5zaWduKGN1cnJlbnRWYWwpIDwgMCA/IHN1bU5lZ2F0aXZlIDogc3VtKTtcclxuICAgICAgICAgICAgICAgIGNoYXJ0RGF0YU9iai55LnB1c2goY2hhcnREYXRhU2VyaWVzT2JqKTtcclxuICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgYWxsU3VtQXJyTWF4LnB1c2godGhpcy5fY2hhcnRTdmMuZ2V0RDNNYXhPck1pbihzdW1BcnIsICdtYXgnKSk7XHJcbiAgICAgICAgICAgIGFsbFN1bUFyck1pbi5wdXNoKHRoaXMuX2NoYXJ0U3ZjLmdldEQzTWF4T3JNaW4oc3VtQXJyLCAnbWluJykpO1xyXG5cclxuICAgICAgICAgICAgY2hhcnREYXRhLmRhdGEucHVzaChjaGFydERhdGFPYmopO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgaWYgKF9kYXRhLmNoYXJ0LnR5cGUgIT09ICdwaWUnKSB7XHJcbiAgICAgICAgICAgIGNoYXJ0RGF0YVsncmFuZ2UnXSA9IHtcclxuICAgICAgICAgICAgICAgIG1heDogdGhpcy5fY2hhcnRTdmMuZ2V0RDNNYXhPck1pbihhbGxTdW1BcnJNYXgsICdtYXgnKSxcclxuICAgICAgICAgICAgICAgIG1pbjogdGhpcy5fY2hhcnRTdmMuZ2V0RDNNYXhPck1pbihhbGxTdW1BcnJNaW4sICdtaW4nKVxyXG4gICAgICAgICAgICB9O1xyXG4gICAgICAgICAgICBjaGFydERhdGFbJ2hhdmVOZWdhdGl2ZSddID0gaGF2ZU5lZ2F0aXZlO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgdGhpcy5kYXRhID0gY2hhcnREYXRhO1xyXG4gICAgICAgIHRoaXMuY2hhcnRIaWRlID0gdGhpcy5jaGFydFR5cGVbMV0gPT09ICcxMDAnICYmIGhhdmVOZWdhdGl2ZTtcclxuICAgICAgICB0aGlzLl9zZXRDb25maWcodGhpcy5jb25maWcpO1xyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX2RhdGFNYXNzYWdlRm9yUGllKF9kYXRhKSB7XHJcbiAgICAgICAgaWYgKF9kYXRhICE9PSB1bmRlZmluZWQgJiYgX2RhdGEgIT09IG51bGwpIHtcclxuICAgICAgICAgICAgbGV0IGNoYXJ0RGF0YTogSUQzRGF0YSA9IHtcclxuICAgICAgICAgICAgICAgICd0eXBlJzogX2RhdGEuY2hhcnRbJ3R5cGUnXSA/IF9kYXRhLmNoYXJ0Wyd0eXBlJ10gOiBudWxsLFxyXG4gICAgICAgICAgICAgICAgJ2xheW91dCc6IF9kYXRhLmNoYXJ0WydsYXlvdXQnXSA/IF9kYXRhLmNoYXJ0WydsYXlvdXQnXSA6IG51bGwsXHJcbiAgICAgICAgICAgICAgICAnY29uZmlnJzogdGhpcy5jb25maWcucGxvdE9wdGlvbnMgJiYgdGhpcy5jb25maWcucGxvdE9wdGlvbnMuaGFzT3duUHJvcGVydHkoX2RhdGEuY2hhcnRbJ3R5cGUnXSkgPyB0aGlzLmNvbmZpZy5wbG90T3B0aW9uc1tfZGF0YS5jaGFydFsndHlwZSddXSA6IHt9LFxyXG4gICAgICAgICAgICAgICAgJ2RhdGEnOiBbXVxyXG4gICAgICAgICAgICB9O1xyXG4gICAgICAgICAgICBsZXQgcmV0dXJuUGFyYW1zID0gdGhpcy5fY2hhcnRTdmMuc2luZ2xlUGllRGF0YU1hc3NhZ2UodGhpcy5sZWdlbmREYXRhLCBfZGF0YSwgdGhpcy5jb25maWcsIHRoaXMuc2VyaWVzVGhyZXNob2xkKTtcclxuICAgICAgICAgICAgY2hhcnREYXRhWydwaWVkYXRhJ10gPSByZXR1cm5QYXJhbXMucGllRGF0YTtcclxuICAgICAgICAgICAgdGhpcy5kYXRhID0gY2hhcnREYXRhO1xyXG4gICAgICAgICAgICB0aGlzLmNvbmZpZ1sncGllQ29sb3InXSA9IHJldHVyblBhcmFtcy5waWVDb2xvcjtcclxuICAgICAgICAgICAgdGhpcy5sZWdlbmREYXRhID0gcmV0dXJuUGFyYW1zLmxlZ2VuZERhdGE7XHJcbiAgICAgICAgICAgIC8vIHRoaXMub3V0cHV0RGF0YS5lbWl0KHRoaXMuZGF0YSk7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX2RhdGFNYXNzYWdlRm9yTWFwKF9kYXRhKTogdm9pZCB7XHJcbiAgICAgICAgdGhpcy5kYXRhID0gX2RhdGE7XHJcbiAgICAgICAgdGhpcy5fc2V0TGVnZW5kRm9yTWFwKCk7XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfc2V0TGVnZW5kRm9yTWFwKCk6IHZvaWQge1xyXG4gICAgICAgIGxldCBzZXJpZXNEYXRhOiBhbnk7XHJcbiAgICAgICAgaWYgKHRoaXMuZGF0YVsnbWFwU2VyaWVzRGF0YSddICYmIHRoaXMuY29uZmlnLnNraXBNYXNzYWdlKSB7XHJcbiAgICAgICAgICAgIHNlcmllc0RhdGEgPSBKU09OLnBhcnNlKEpTT04uc3RyaW5naWZ5KHRoaXMuZGF0YVsnbWFwU2VyaWVzRGF0YSddKSk7XHJcbiAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgc2VyaWVzRGF0YSA9IEpTT04ucGFyc2UoSlNPTi5zdHJpbmdpZnkodGhpcy5kYXRhWydzZXJpZXMnXSkpO1xyXG4gICAgICAgICAgICBmb3IgKGxldCBpID0gMDsgaSA8IHNlcmllc0RhdGEubGVuZ3RoOyBpKyspIHtcclxuICAgICAgICAgICAgICAgIHNlcmllc0RhdGFbaV1bJ2RlYWN0aXZlJ10gPSBmYWxzZTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgICAgICB0aGlzLmNoZWNrTWFwU2NhbGUgPSBmYWxzZTtcclxuICAgICAgICBpZiAoIXRoaXMuY29uZmlnLnNraXBNYXNzYWdlKSB7XHJcbiAgICAgICAgICAgIGlmICh0aGlzLmNvbmZpZy5jb2xvckF4aXMgIT0gdW5kZWZpbmVkKSB7XHJcbiAgICAgICAgICAgICAgICBpZiAodGhpcy5jb25maWcuY29sb3JBeGlzLmRhdGFDbGFzc2VzICYmIHRoaXMuY29uZmlnLmNvbG9yQXhpcy5kYXRhQ2xhc3Nlcy5sZW5ndGggIT0gMCkge1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMubGVnZW5kRGF0YSA9IHRoaXMuX2NoYXJ0U3ZjLnNldFNpbmdsZUxlZ2VuZExldmVscyh0aGlzLmNvbmZpZy5jb2xvckF4aXMuZGF0YUNsYXNzZXMsIHRoaXMuY29uZmlnLmxlZ2VuZC52YWx1ZURlY2ltYWxzLCB0aGlzLmNvbmZpZy5sZWdlbmQudmFsdWVTdWZmaXgpO1xyXG4gICAgICAgICAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLmNoZWNrTWFwU2NhbGUgPSB0cnVlO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5sZWdlbmREYXRhID0gdGhpcy5fY2hhcnRTdmMuc2V0TWFwTGVnZW5kRGF0YSh0aGlzLmxlZ2VuZERhdGEsIHNlcmllc0RhdGEsIHRoaXMuY29uZmlnKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgIC8vIG91dHB1dCBsZWdlbmQgb25seSBmb3IgZXhwb3J0aW5nXHJcbiAgICAgICAgICAgIGlmICh0aGlzLmNvbmZpZy5jb2xvckF4aXMgIT0gdW5kZWZpbmVkKSB7XHJcbiAgICAgICAgICAgICAgICBpZiAodGhpcy5jb25maWcuY29sb3JBeGlzLmRhdGFDbGFzc2VzICYmIHRoaXMuY29uZmlnLmNvbG9yQXhpcy5kYXRhQ2xhc3Nlcy5sZW5ndGggIT0gMCkge1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMubGVnZW5kRGF0YSA9IHRoaXMuX2NoYXJ0U3ZjLnNldE1hcExlZ2VuZERhdGEodGhpcy5sZWdlbmREYXRhLCBzZXJpZXNEYXRhLCB0aGlzLmNvbmZpZyk7XHJcbiAgICAgICAgICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuY2hlY2tNYXBTY2FsZSA9IHRydWU7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLmxlZ2VuZERhdGEgPSB0aGlzLl9jaGFydFN2Yy5zZXRNYXBMZWdlbmREYXRhKHRoaXMubGVnZW5kRGF0YSwgc2VyaWVzRGF0YSwgdGhpcy5jb25maWcpO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX2dldFRvdGFsU3VtKF9kYXRhOiBJQ2hhcnREYXRhLCBzZXJpZXNMZW5ndGg6IG51bWJlcik6IEFycmF5PG51bWJlcj4gfCBvYmplY3Qge1xyXG4gICAgICAgIGlmICh0aGlzLmNoYXJ0VHlwZVsxXSA9PT0gJzEwMCcpIHtcclxuICAgICAgICAgICAgcmV0dXJuIHRoaXMuX2NoYXJ0U3ZjLmdldFRvdGFsU3VtQXJyRnJvbVNlcmllcyhfZGF0YS5zZXJpZXMsIF9kYXRhLnhBeGlzLmNhdGVnb3JpZXMsIHNlcmllc0xlbmd0aCk7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX2dldENvbmZpZyhfZWxlbWVudDogYW55LCBfc2VyaWVzSW5kZXg6IG51bWJlciwgX2RhdGE6IElTZXJpZXNEYXRhKTogc3RyaW5nIHtcclxuXHJcbiAgICAgICAgaWYgKCF0aGlzLl9jaGFydFN2Yy5pc0V4aXN0KF9kYXRhKSkgcmV0dXJuO1xyXG5cclxuICAgICAgICBpZiAoX2RhdGEuaGFzT3duUHJvcGVydHkoX2VsZW1lbnQpICYmIF9kYXRhW19lbGVtZW50XSAhPT0gdW5kZWZpbmVkKSB7XHJcbiAgICAgICAgICAgIHJldHVybiBfZGF0YVtfZWxlbWVudF07XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICBsZXQgY29uZmlnOiBzdHJpbmcgPSB0aGlzLl9nZXRMZWdlbmRDb25maWcoX2VsZW1lbnQsIF9zZXJpZXNJbmRleCk7XHJcbiAgICAgICAgcmV0dXJuIGNvbmZpZztcclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF9nZXRMZWdlbmRDb25maWcoX2VsZW1lbnQ6IGFueSwgX3Nlcmllc0luZGV4OiBudW1iZXIpOiBzdHJpbmcge1xyXG4gICAgICAgIGlmIChfZWxlbWVudCA9PT0gJ3NoYXBlJyAmJlxyXG4gICAgICAgICAgICAodGhpcy5jaGFydERhdGEuY2hhcnQudHlwZSA9PT0gJ3BpZScgfHwgdGhpcy5jaGFydERhdGEuY2hhcnQudHlwZSA9PT0gJ2JhcicpKSB7XHJcbiAgICAgICAgICAgIHJldHVybiAnY2lyY2xlJztcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIGxldCBkZWZhdWx0Q29uZmlnOiBzdHJpbmcgPSB0aGlzLl9nZXREZWZhdWx0Q29uZmlnKF9lbGVtZW50LCBfc2VyaWVzSW5kZXgpO1xyXG4gICAgICAgIGxldCBjb25maWc6IHN0cmluZztcclxuICAgICAgICBpZiAodGhpcy5jaGFydENhdGVnb3J5ID09ICdwaWUnKSB7XHJcbiAgICAgICAgICAgIGNvbmZpZyA9IGRlZmF1bHRDb25maWc7XHJcbiAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgY29uZmlnID0gdGhpcy5jaGFydERhdGEuc2VyaWVzW19zZXJpZXNJbmRleF1bX2VsZW1lbnRdIHx8IGRlZmF1bHRDb25maWc7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIHJldHVybiBjb25maWc7XHJcbiAgICB9XHJcblxyXG4gICAgcHVibGljIF9nZXREZWZhdWx0Q29uZmlnKF9lbGVtZW50OiBhbnksIF9zZXJpZXNJbmRleD86IG51bWJlcik6IHN0cmluZyB7XHJcbiAgICAgICAgaWYgKF9lbGVtZW50ID09PSAnc2hhcGUnKSByZXR1cm4gJ2NpcmNsZSc7XHJcblxyXG4gICAgICAgIGlmIChfc2VyaWVzSW5kZXggfHwgX3Nlcmllc0luZGV4ID09PSAwKSB7XHJcbiAgICAgICAgICAgIHJldHVybiB0aGlzLmNvbmZpZy5jb2xvcnNbX3Nlcmllc0luZGV4XTtcclxuICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICB0aGlzLl9jb2xvckxpc3RQb3NpdGlvbisrO1xyXG4gICAgICAgICAgICByZXR1cm4gdGhpcy5jb25maWcuY29sb3JzW3RoaXMuX2NvbG9yTGlzdFBvc2l0aW9uIC0gMV07XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIHB1YmxpYyBnZXRPdXRwdXRNYXJrZXIoX2RhdGE6IGFueSk6IHZvaWQge1xyXG4gICAgICAgIHRoaXMubWFya2Vyc0xlZ2VuZCA9IF9kYXRhO1xyXG4gICAgfVxyXG59XHJcbiJdfQ==