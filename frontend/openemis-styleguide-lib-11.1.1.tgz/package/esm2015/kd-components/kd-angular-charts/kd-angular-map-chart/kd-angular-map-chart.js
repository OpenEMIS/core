import { Component, ViewEncapsulation, Input, Output, EventEmitter, ElementRef } from '@angular/core';
import { KdChartBaseClass } from '../kd-angular-chart-base-class';
import { KdChartsSvc } from '../kd-angular-charts-svc';
import { KdDomElemSvc } from '../../kd-common/index';
import { KdMapChartSvc } from './kd-angular-map-chart-svc';
import * as d3 from 'd3';
import * as L from 'leaflet';
import 'leaflet.markercluster';
import 'leaflet.awesome-markers/dist/leaflet.awesome-markers';
export class KdMapChart extends KdChartBaseClass {
    constructor(_elementRef, _chartSvc, _domSvc, _mapSvc) {
        super(_chartSvc, _domSvc);
        this._elementRef = _elementRef;
        this._chartSvc = _chartSvc;
        this._domSvc = _domSvc;
        this._mapSvc = _mapSvc;
        this._outputSeriesData = [];
        this._seriesData = [];
        this._emptySeries = false;
        this._singleLevelDimension = false;
        this._tileloadIndex = 0;
        this._isLayerError = false;
        this._layerReloadTimes = 0;
        this._isMapSelected = {};
        this.outputLegend = new EventEmitter(true);
        this.outputData = new EventEmitter(true);
        this.outputMarker = new EventEmitter(true);
        this.outputReady = new EventEmitter(true);
    }
    ngOnInit() {
        this.config = Object.assign({}, this.mapConfig);
        this.legendData = Object.assign({}, this.legend);
        this._setData();
        super.chartTimeout(() => this._setChart());
        this.api.redraw = () => {
            setTimeout(() => {
                this._overWriteSeries();
                this._resetChart();
                this._setChart();
                // if (!this.config.skipMassage) {
                //     this.legend = this._chartSvc.setMapLegendData(this.legend, this._seriesData, this.config);
                // }
                this._getLegendByType();
            });
        };
        this.api.legendClick = (_id, _legendActive) => {
            this.legend[_id].deactive = _legendActive;
            for (let i = 0; i < this._seriesData.length; i++) {
                if (this._seriesData[i].id && this._seriesData[i].id == this.legend[_id].mapSeriesId) {
                    this._seriesData[i].deactive = _legendActive;
                }
            }
            this.data['mapSeriesData'] = this._seriesData;
            if (this._singleLevelDimension == false)
                this._getNewSeries();
            this._resetChart();
            this._setChart();
        };
        this.api.clusterClick = (_id, _legendItem) => {
            let selectedMarkerGroup;
            selectedMarkerGroup = this._clusterData.clusterMarkers[_id.id];
            if (this._leafletMap.hasLayer(selectedMarkerGroup)) {
                this._leafletMap.removeLayer(selectedMarkerGroup);
                this._domSvc.addClass(_legendItem.legendItemMarker, 'awesome-marker-icon-lightgray');
                this._domSvc.addClass(_legendItem.legendItemLabel, 'kdx-label-lightgray');
            }
            else {
                this._leafletMap.addLayer(selectedMarkerGroup);
                this._domSvc.removeClass(_legendItem.legendItemMarker, 'awesome-marker-icon-lightgray');
                this._domSvc.removeClass(_legendItem.legendItemLabel, 'kdx-label-lightgray');
            }
        };
    }
    ngOnChanges(_simpleChanges) {
        if (_simpleChanges.hasOwnProperty('data') && !_simpleChanges['data'].firstChange) {
            this.data = _simpleChanges.data.currentValue;
            this._redrawChart('data');
        }
        if (_simpleChanges.hasOwnProperty('mapConfig') && !_simpleChanges['mapConfig'].firstChange) {
            if (this.mapConfig.plotOptions.map.zoom) {
                this._checkZoomConfig(this.mapConfig.plotOptions.map.zoom);
                if (this.mapConfig.plotOptions.map.zoom.value) {
                    if (typeof this._leafletMap !== 'undefined')
                        this._leafletMap.setZoom(this.mapConfig.plotOptions.map.zoom.value);
                }
                // need to check why legend keep gone
                // if (this.chartType[1] === 'full' || this.chartType[1] === 'cluster') this._setMarkers();
            }
            this.mapConfig = _simpleChanges.mapConfig.currentValue;
            this._redrawChart('config');
        }
    }
    ngAfterViewInit() {
        if (typeof this._leafletMap !== 'undefined')
            this._leafletMap.invalidateSize({});
    }
    ngOnDestroy() {
        this._resetChart();
    }
    _redrawChart(_changes) {
        this._resetChart();
        if (_changes === 'data') {
            this._seriesData = [];
        }
        else {
            this.config = Object.assign({}, this.mapConfig);
        }
        this.legendData = Object.assign({}, this.legend);
        this._setData();
        super.chartTimeout(() => this._setChart());
    }
    _setChart() {
        this.chartType = this.data.chart.layout.split('-');
        if (this._level !== undefined && this._level !== null) {
        }
        else if ((this.data['mapLevel'] && this.config.skipMassage) || (this.data['mapLevel'] && this._singleLevelDimension == true)) {
            // if ((this.data['mapLevel'] && this.config.skipMassage) || (this.data['mapLevel'] && this._singleLevelDimension == true)) {
            let tmpLevelArr = Object.keys(this.data.mapData);
            this._defaultLevel = tmpLevelArr.length > 0 ? tmpLevelArr[0] : this.data['mapLevel'];
            this._level = this.data['mapLevel'];
            // checking if map got area filter
        }
        else if (this.data.series[this.data.series.length - 1].data && this.data.series[this.data.series.length - 1].data.length == 1) {
            this._defaultLevel = this._mapSvc.getMapLevelWithAreaFilter(this.data.series[this.data.series.length - 1].data[0].ID_, this.data.mapData);
            this._level = this._defaultLevel;
        }
        else {
            let tmpLevelArr = Object.keys(this.data.mapData);
            this._defaultLevel = tmpLevelArr.length > 0 ? tmpLevelArr[0] : 'l_1';
            this._level = this._defaultLevel;
        }
        this._getColorPointer();
        // instead of legend, draw the map color scale. must be completed before svg dimension is fixed
        if (this.config.colorAxis != undefined && this.config.colorAxis.dataClasses == undefined) {
            this._drawMapScale();
        }
        super.setSvg();
        super.setSvgDimension('x');
        super.setSvgDimension('y');
        this._height = this.svgContainer.node().getBoundingClientRect().height;
        this._width = this.svgContainer.node().getBoundingClientRect().width;
        if (this.chartType[1] === 'polygon' || this.chartType[1] === 'thematic') {
            this._drawPolygonMap();
        }
        else if (this.chartType[1] === 'full' || this.chartType[1] === 'cluster' || this.chartType[1] === 'filter') {
            this._drawLeaftlet();
            setTimeout(() => {
                if (typeof this._leafletMap !== 'undefined')
                    this._leafletMap.invalidateSize({});
            });
            if (this.chartType[1] !== 'cluster')
                this._drawFullMap();
        }
        // console.log('data ', this.data)
        // console.log('config ', this.config)
    }
    _setData() {
        this.chartCategory = 'map';
        if (this.data['mapSeriesData'] && this.config.skipMassage) {
            // export mode
            this._seriesData = JSON.parse(JSON.stringify(this.data['mapSeriesData']));
            if (this.config.colorAxis != undefined) {
                // single dimension
                this._seriesPointer = this._mapSvc.getSeriesPointer(this._seriesData);
            }
            else {
                this._getNewSeries();
            }
        }
        else {
            this._seriesData = JSON.parse(JSON.stringify(this.data.series));
            for (let i = 0; i < this._seriesData.length; i++) {
                this._seriesData[i]['deactive'] = false;
            }
            if (this.config.colorAxis != undefined) {
                // single dimension
                this._seriesPointer = this._mapSvc.getSeriesPointer(this._seriesData);
            }
            else {
                // multi dimension
                if (this._seriesData && this._seriesData.length != 0) {
                    this._seriesPointer = this._seriesData[this._seriesData.length - 1];
                }
            }
            this._emptySeries = this._seriesPointer == undefined ? true : false;
        }
        // if (!this.config.skipMassage) {
        //     this.legend = this._chartSvc.setMapLegendData(this.legend, this._seriesData, this.config);
        // }
        this._getColorPointer();
        this._getLegendByType();
    }
    _resetChart() {
        if (typeof this._zoomBtns !== 'undefined') {
            this._zoomBtns.remove();
            this._zoomBtns = undefined;
        }
        if (this._leafletMap !== undefined && this._leafletMap !== null && !this.config.skipMassage) {
            this._leafletMap.remove();
            this._leafletMap = undefined;
            let leaftletId = '#' + this.config.id + 'Leaflet';
            document.querySelector(leaftletId).setAttribute('class', 'kdx-charts-svg-container');
        }
        if (typeof this._mapLayer !== 'undefined') {
            this._mapLayer.remove();
            this._mapLayer = undefined;
        }
        if (typeof this._fullGraph !== 'undefined') {
            this._fullGraph.remove();
            this._fullGraph = undefined;
        }
        if (typeof this._backBtn !== 'undefined') {
            this._backBtn.remove();
            this._backBtn = undefined;
        }
        this._level = undefined;
        this._outputSeriesData = [];
        this._isMapSelected = {};
        super.removeChart();
    }
    _drawLeaftlet() {
        if (this._leafletMap !== undefined && this._leafletMap !== null)
            this._leafletMap.remove();
        let zoomValue = 6;
        if (this.chartType[1] === 'filter' && this.data.position && this.data.position.zoom) {
            zoomValue = this.data.position.zoom;
        }
        else if (this.config.plotOptions.map.zoom && this.config.plotOptions.map.zoom.value) {
            zoomValue = this.config.plotOptions.map.zoom.value;
        }
        let leaftletId = this.config.id + 'Leaflet';
        this._leafletMap = L.map(leaftletId).setView([this.data.position.latitude, this.data.position.longitude], zoomValue);
        this._setLayer();
        this._removeDefaultAttribution('OpenEMIS');
        if (this.chartType[1] === 'full' || this.chartType[1] === 'cluster')
            this._setMarkers();
    }
    _drawFullMap() {
        this._outputSeriesData = [];
        if (typeof this._fullGraph === 'undefined')
            this._fullGraph = d3.select(this._leafletMap.getPanes().overlayPane).append("svg");
        // this._fullGraph = d3.select(this._leafletMap.getPanes().overlayPane).append("svg");
        this._mapLayer = this._fullGraph.append("g").attr("class", "leaflet-zoom-hide");
        let map = this._leafletMap;
        let svg = this._fullGraph;
        let currentChartId = this.config.id;
        let mapLayer = this._mapLayer;
        let width = this._width;
        let height = this._height;
        let transform = d3.geoTransform({
            point: function (x, y) {
                let point = map.latLngToLayerPoint(new L.LatLng(y, x));
                this.stream.point(point.x, point.y);
            }
        }), path = d3.geoPath().projection(transform);
        let valueKey, filterValueObj;
        if (this.chartType[1] === 'filter' && this.data.hasOwnProperty('value') && (this.data.value !== undefined || this.data.value !== null)) {
            valueKey = Object.keys(this.data.value)[0];
            filterValueObj = this.data.value[valueKey];
        }
        // this._mapLayer = this._path.append('g').classed('map-layer', true);
        // allow user to define or change the level of the map
        if (this.config.plotOptions.map.level && (this.config.plotOptions.map.level !== '' || this.config.plotOptions.map.level !== undefined || this.config.plotOptions.map.level !== null) && this._mapSvc.checkMapLevelExist(this.config.plotOptions.map.level, this.data.mapData)) {
            if ((this.chartType[1] === 'full' && this.config.plotOptions.map.mapFullChangeLevelDefault === true) || this.chartType[1] !== 'full') {
                this._level = this.config.plotOptions.map.level;
            }
            else {
                this._checkBackBtn();
            }
        }
        else {
            this._checkBackBtn();
        }
        let data = this.data.mapData.hasOwnProperty(this._level) ? this.data.mapData[this._level] : this.data.mapData;
        let projection = d3.geoMercator().fitSize([this._width, this._height - 50], data);
        // let path = d3.geoPath().projection(projection);
        let features = this.data.mapData.hasOwnProperty('features') ? this.data.mapData.features : this.data.mapData[this._level].features;
        let mapPath = this._mapLayer.selectAll('path')
            .data(features)
            .enter().append('path')
            // .attr('d', path)
            .attr('id', (d) => { return this._mapSvc.pathIdPrefix + d.properties.ID_; })
            .attr('class', (d) => {
            if (this._emptySeries == false && this._seriesPointer && this._seriesPointer.data != undefined) {
                let seriesValue = this._getSeriesValue(d.properties.ID_);
                this._outputSeriesData.push({ 'name': seriesValue.name, 'value': seriesValue.value, 'id': d.properties.ID_ });
                return 'id-' + seriesValue.id + ', name-' + seriesValue.name + ', drilldown-' + seriesValue.drilldown + ', value-' + seriesValue.value;
            }
        })
            .attr('vector-effect', 'non-scaling-stroke')
            .style('fill', (d) => {
            if (this.chartType[1] === 'filter' && this.data.hasOwnProperty('value') && (this.data.value !== undefined || this.data.value !== null)) {
                if (d.hasOwnProperty('properties') && d.properties.ID_ === filterValueObj.id && d.properties.NAME1_ === filterValueObj.name) {
                    this._isMapSelected = {};
                    this._isMapSelected[d.properties.ID_] = d.properties.ID_;
                    return this.config.plotOptions.map.states.select.color;
                }
                else {
                    return this._getMapFillColor(d);
                }
            }
            else {
                return this._getMapFillColor(d);
            }
        })
            .style('stroke-width', (d) => {
            if (this.chartType[1] === 'filter' && this.data.hasOwnProperty('value') && (this.data.value !== undefined || this.data.value !== null)) {
                if (d.hasOwnProperty('properties') && d.properties.ID_ === filterValueObj.id && d.properties.NAME1_ === filterValueObj.name) {
                    return this.config.plotOptions.map.filter.borderSelected ? this.config.plotOptions.map.filter.borderSelected : this.config.plotOptions.map.borderWidth;
                }
                else {
                    return (this.chartType[1] === 'filter' && this.config.plotOptions.map.filter.border) ? this.config.plotOptions.map.filter.border : this.config.plotOptions.map.borderWidth;
                }
            }
            else {
                return (this.chartType[1] === 'filter' && this.config.plotOptions.map.filter.border) ? this.config.plotOptions.map.filter.border : this.config.plotOptions.map.borderWidth;
            }
        })
            .style('stroke', this.config.plotOptions.map.borderColor)
            //due to leaflet blocking pointer events
            .style('pointer-events', 'visible')
            .style('opacity', 0.6);
        this._leafletMap.on("viewreset", reset);
        this._leafletMap.on("zoom", reset);
        let mapLevel = this.data.mapData[this._level];
        reset();
        let elements = Array.from(document.querySelectorAll('#' + this.config.id + '.kdx-charts svg .leaflet-zoom-hide'));
        elements.forEach((el) => {
            el.addEventListener('mouseover', (d) => {
                let targetElement = d.target;
                let targetGeojsonId = this._mapSvc.getTargetGeojsonId(targetElement);
                let currentSelection = this._mapSvc.getCurrentSelection(this.svgContainer, targetElement.getAttribute('id'));
                if (this._checkEmptyDataValue(targetGeojsonId)) {
                    if (this.chartType[1] !== 'filter' || (this.chartType[1] === 'filter' && !this._checkMapSelected(targetGeojsonId))) {
                        currentSelection.style('fill', this.config.plotOptions.map.states.hover.color);
                    }
                    if (this.chartType[1] === 'filter' && this.config.plotOptions.map.filter && this.config.plotOptions.map.filter.borderHover && !this._checkMapSelected(targetGeojsonId)) {
                        currentSelection.style('stroke-width', this.config.plotOptions.map.filter.borderHover);
                    }
                }
            });
            el.addEventListener('mouseout', (d) => {
                let targetElement = d.target;
                let targetGeojsonId = this._mapSvc.getTargetGeojsonId(targetElement);
                let currentSelection = this._mapSvc.getCurrentSelection(this.svgContainer, targetElement.getAttribute('id'));
                if (this._checkEmptyDataValue(targetGeojsonId)) {
                    if (this.chartType[1] !== 'filter' || (this.chartType[1] === 'filter' && !this._checkMapSelected(targetGeojsonId))) {
                        currentSelection.style('fill', (d2) => {
                            return this._getMapFillColor(d2);
                        });
                    }
                    if (this.chartType[1] === 'filter' && this.config.plotOptions.map.filter && this.config.plotOptions.map.filter.border && !this._checkMapSelected(targetElement.getAttribute('id'))) {
                        currentSelection.style('stroke-width', this.config.plotOptions.map.filter.border);
                    }
                }
            });
            el.addEventListener('click', (d) => {
                let targetElement = d.target;
                let targetGeojsonId = this._mapSvc.getTargetGeojsonId(targetElement);
                let currentSelection = this._mapSvc.getCurrentSelection(this.svgContainer, targetElement.getAttribute('id'));
                if ((this.chartType[1] === 'full' && this.config.plotOptions.map.mapFullChangeLevelDefault === true) || this.chartType[1] !== 'full') {
                    this.outputData.emit(currentSelection.attr('class'));
                    if (this.chartType[1] === 'filter') {
                        let setClickBorderCondition = (this.config.plotOptions.map.filter && this.config.plotOptions.map.filter.borderSelected && this.config.plotOptions.map.filter.borderSelected != undefined);
                        //change the color for the area selected
                        if (this.config.plotOptions.map.states && this.config.plotOptions.map.states.select && this.config.plotOptions.map.states.select.color && this.config.plotOptions.map.states.select.color !== '') {
                            if (Object.keys(this._isMapSelected).length !== 0) {
                                let previousAreaId = Object.keys(this._isMapSelected)[0];
                                d3.select('#' + this.config.id + '.kdx-charts svg .leaflet-zoom-hide').select('#' + this._mapSvc.pathIdPrefix + previousAreaId).style('fill', (d2) => {
                                    return this._getMapFillColor(d2);
                                });
                                if (setClickBorderCondition)
                                    d3.select('#' + this.config.id + '.kdx-charts svg .leaflet-zoom-hide').select('#' + this._mapSvc.pathIdPrefix + previousAreaId).style('stroke-width', this.config.plotOptions.map.filter.border);
                                this._isMapSelected = {};
                                if (previousAreaId !== targetGeojsonId) {
                                    this._isMapSelected[targetGeojsonId] = targetGeojsonId;
                                    currentSelection.style('fill', this.config.plotOptions.map.states.select.color);
                                    if (setClickBorderCondition)
                                        currentSelection.style('stroke-width', this.config.plotOptions.map.filter.borderSelected);
                                }
                            }
                            else {
                                this._isMapSelected = {};
                                this._isMapSelected[targetGeojsonId] = targetGeojsonId;
                                currentSelection.style('fill', this.config.plotOptions.map.states.select.color);
                                if (setClickBorderCondition)
                                    currentSelection.style('stroke-width', this.config.plotOptions.map.filter.borderSelected);
                            }
                        }
                    }
                }
                else {
                    if (this._checkEmptyDataValue(targetGeojsonId)) {
                        this._changeLevel(this._level, 'add');
                    }
                }
            });
        });
        // Reposition the SVG to cover the features.
        function reset() {
            let bounds = path.bounds(mapLevel), topLeft = bounds[0], bottomRight = bounds[1];
            // console.log('width ', JSON.parse(JSON.stringify(bottomRight[0] - topLeft[0])))
            svg.attr("width", bottomRight[0] - topLeft[0])
                .attr("height", bottomRight[1] - topLeft[1])
                .style("left", topLeft[0] + "px")
                .style("top", topLeft[1] + "px");
            if (!d3.select('#' + currentChartId + '.kdx-charts svg .leaflet-zoom-hide').select('#backBtn').empty()) {
                d3.select('#' + currentChartId + '.kdx-charts svg .leaflet-zoom-hide').select('#backBtn').attr('transform', function () {
                    return 'translate(' + (width - 100 - parseInt(topLeft[0])) + ',' + (height / 3 - parseInt(topLeft[1])) + ')';
                });
            }
            mapLayer.attr("transform", "translate(" + -topLeft[0] + "," + -topLeft[1] + ")");
            mapPath.attr("d", path);
        }
        let eventsParam = {
            'seriesData': this._outputSeriesData,
            'seriesName': this._seriesPointer.name,
            'tooltipLayer': d3.select(this._leafletMap.getPanes().overlayPane),
            'fullGraph': this._fullGraph
        };
        if (this.config.colorAxis != undefined && this.config.colorAxis.dataClasses == undefined) {
            eventsParam['callbacks'] = {
                'mouseover': (d) => this._setMapScaleTriangle(d),
                'mouseout': () => this._removeMapScaleTriangle()
            };
        }
        // add tooltop
        if (this._seriesPointer.data != undefined) {
            super._initMouseEvents(mapPath, eventsParam);
        }
    }
    _drawPolygonMap() {
        this._outputSeriesData = [];
        this._path = this.graph.attr('width', this._width).attr('height', this._height);
        this._mapLayer = this._path.append('g').classed('map-layer', true);
        if (this.config.mapNavigation && this.config.mapNavigation.enabled == true) {
            if (typeof this._zoomBtns === 'undefined')
                this._initZoomBtn();
        }
        // this._checkBackBtn();
        if (this.config.plotOptions.map.level && (this.config.plotOptions.map.level !== '' || this.config.plotOptions.map.level !== undefined || this.config.plotOptions.map.level !== null) && this._mapSvc.checkMapLevelExist(this.config.plotOptions.map.level, this.data.mapData)) {
            if (this.chartType[1] === 'thematic') {
                this._level = this.config.plotOptions.map.level;
            }
            else {
                this._checkBackBtn();
            }
        }
        else if (this.chartType[1] === 'polygon') {
            this._checkBackBtn();
        }
        let data = this.data.mapData.hasOwnProperty(this._level) ? this.data.mapData[this._level] : this.data.mapData;
        let projection = d3.geoMercator().fitSize([this._width, this._height - 50], data);
        let path = d3.geoPath().projection(projection);
        let features = this.data.mapData.hasOwnProperty('features') ? this.data.mapData.features : this.data.mapData[this._level].features;
        let mapPath = this._mapLayer.selectAll('path')
            .data(features)
            .enter().append('path')
            .attr('d', path)
            .attr('id', (d) => { return this._mapSvc.pathIdPrefix + d.properties.ID_; })
            .attr('class', (d) => {
            if (this._emptySeries == false && this._seriesPointer && this._seriesPointer.data != undefined) {
                let seriesValue = this._getSeriesValue(d.properties.ID_);
                this._outputSeriesData.push({ 'name': seriesValue.name, 'value': seriesValue.value, 'id': d.properties.ID_ });
                return 'id-' + seriesValue.id + ', name-' + seriesValue.name + ', drilldown-' + seriesValue.drilldown + ', value-' + seriesValue.value;
            }
        })
            .attr('vector-effect', 'non-scaling-stroke')
            .style('fill', (d) => {
            return this._getMapFillColor(d);
        })
            .style('stroke-width', this.config.plotOptions.map.borderWidth)
            .style('stroke', this.config.plotOptions.map.borderColor);
        // adding mouse events, hover color, change level
        if (this._emptySeries == false) {
            let elements = Array.from(document.querySelectorAll('#' + this.config.id + '.kdx-charts svg .map-layer'));
            elements.forEach((el) => {
                el.addEventListener('mouseover', (d) => {
                    let targetElement = d.target;
                    let targetElementId = targetElement.getAttribute('id').indexOf('id-') != -1 ? targetElement.getAttribute('id').split('id-')[1] : targetElement.getAttribute('id');
                    let currentSelection = this._mapSvc.getCurrentSelection(this.svgContainer, targetElement.getAttribute('id'), 'd3');
                    if (this._checkEmptyDataValue(targetElementId)) {
                        currentSelection.style('fill', this.config.plotOptions.map.states.hover.color);
                    }
                });
                el.addEventListener('mouseout', (d) => {
                    let targetElement = d.target;
                    let targetElementId = targetElement.getAttribute('id').indexOf('id-') != -1 ? targetElement.getAttribute('id').split('id-')[1] : targetElement.getAttribute('id');
                    let currentSelection = this._mapSvc.getCurrentSelection(this.svgContainer, targetElement.getAttribute('id'), 'd3');
                    if (this._checkEmptyDataValue(targetElementId)) {
                        currentSelection.style('fill', (d2) => {
                            return this._getMapFillColor(d2);
                        });
                    }
                });
                el.addEventListener('click', (d) => {
                    if (this.chartType[1] === 'polygon') {
                        let targetElement = d.target;
                        let targetGeojsonId = this._mapSvc.getTargetGeojsonId(targetElement);
                        if (this._checkEmptyDataValue(targetGeojsonId)) {
                            this._changeLevel(this._level, 'add');
                        }
                    }
                });
            });
            let eventsParam = {
                'seriesData': this._outputSeriesData,
                'seriesName': this._seriesPointer.name,
            };
            if (this.config.colorAxis != undefined && this.config.colorAxis.dataClasses == undefined) {
                eventsParam['callbacks'] = {
                    'mouseover': (d) => this._setMapScaleTriangle(d),
                    'mouseout': () => this._removeMapScaleTriangle()
                };
            }
            // add tooltop
            if (this._seriesPointer.data != undefined) {
                super._initMouseEvents(mapPath, eventsParam);
            }
        }
    }
    _getMapFillColor(_value) {
        if (this._seriesPointer == undefined || this._seriesPointer.data == undefined)
            return '#F2F2F2';
        let dataValue = this._getSeriesValue(_value.properties.ID_).value;
        if (this.chartType[1] === 'filter' && this.config.colorAxis && this.config.colorAxis.minColor) {
            return this.config.colorAxis.minColor;
        }
        if (dataValue == null || dataValue == '')
            return this.config.plotOptions.map.nullColor || 'rgb(0,0,0,0)';
        if (this.config.colorAxis != undefined && this.config.colorAxis.dataClasses == undefined) {
            return this._mapScaleColorScale(dataValue);
        }
        if (this._singleLevelDimension == true) {
            for (let i = 0; i < this.config.colorAxis.dataClasses.length; i++) {
                if (this._mapSvc.checkValueInBetween(Number(dataValue), this.config.colorAxis.dataClasses[i].from, this.config.colorAxis.dataClasses[i].to)) {
                    if (this.legend['id' + i] && this.legend['id' + i].deactive == true) {
                        return '#F2F2F2';
                    }
                    return this.config.colorAxis.dataClasses[i].color;
                }
                else if (i == this.config.colorAxis.dataClasses.length) {
                    return this.config.colorAxis.minColor;
                }
            }
        }
        if (this._emptySeries == false)
            return this._colorPointer.color;
        return '#F2F2F2';
    }
    _changeLevel(_level, _type) {
        let mapArr = Object.keys(this.data.mapData);
        let levelIndex = 0, newIndex;
        let newLevel;
        for (let i = 0; i < mapArr.length; i++) {
            if (mapArr[i] === _level)
                levelIndex = i;
        }
        if (_type === 'add') {
            if (levelIndex + 1 <= mapArr.length)
                newIndex = levelIndex + 1;
        }
        else {
            if (levelIndex - 1 >= 0)
                newIndex = levelIndex - 1;
        }
        if (newIndex !== undefined) {
            newLevel = mapArr[newIndex];
            if (this.data.mapData[newLevel] != undefined) {
                if (typeof this._mapLayer !== 'undefined') {
                    this._mapLayer.remove();
                }
                this._level = newLevel;
                this.data['mapLevel'] = this._level;
                if (this.config.colorAxis == undefined)
                    this._getDrillDownLegendForMultipleDimension();
                this._getColorPointer();
                if (this.chartType[1] === 'full') {
                    this._drawFullMap();
                }
                else
                    this._drawPolygonMap();
            }
        }
        // let op = _type == 'add' ? '+' : '-';
        // let operators = {
        //     '+': function(a, b) { return a + b; },
        //     '-': function(a, b) { return a - b; }
        // };
        // let newLevelPointer: string | string[] = _level.indexOf('_') != -1 ? _level.split('_') : _level;
        // let newLevel: string = _level.indexOf('_') != -1 ? newLevelPointer[0] + '_' + (operators[op](parseInt(newLevelPointer[1]), 1)) : (operators[op](parseInt(_level), 1)).toString();
    }
    _initZoomBtn() {
        // inserting the zoom buttons
        let zoomed = () => {
            const transform = d3.event.transform;
            this._mapLayer.attr('transform', 'translate(' + transform.x + ',' + transform.y + ') scale(' + transform.k + ')');
        };
        let zoom = d3.zoom().scaleExtent([1, 4]).on('zoom', zoomed);
        this._zoomBtns = this.graph.append('g').classed('zoom-layer', true);
        let zoomBtn = this._zoomBtns.selectAll('g')
            .data(['zoomIn', 'zoomOut'])
            .enter().append('g')
            .attr('id', function (d) { return d; })
            // .attr('transform', (d, i) => { return 'translate(10,' + ((this._height / 3) + (i * 28)) + ')'; })
            .attr('transform', (d, i) => { return 'translate(10,' + (10 + (i * 30)) + ')'; })
            .style('cursor', 'pointer')
            .on('click', (d, i) => { this._zoomClick(d, zoom); });
        zoomBtn.append('rect')
            .attr('width', '30px')
            .attr('height', '30px')
            .attr('rx', 1)
            .attr('ry', 1)
            .style('z-index', 1)
            .style('fill', '#fff')
            .style('stroke', '#ccc')
            .style('stroke-width', '2');
        zoomBtn.append('text')
            .attr('x', 14)
            .attr('y', 14)
            .attr('dy', '.35em')
            .attr('text-anchor', 'middle')
            .style('font-size', '22px')
            .style('font-weight', 'bold')
            .text(function (d, i) { return i == 0 ? '+' : '−'; });
        this._mapLayer.call(zoom);
    }
    _zoomClick(_zoomBtnId, _zoom) {
        let factor = _zoomBtnId == 'zoomIn' ? 1.2 : 0.8;
        _zoom.scaleBy(this._mapLayer, factor);
    }
    _initBackBtn() {
        // inserting the back button
        if (typeof this._backBtn !== 'undefined') {
            this._backBtn.remove();
            this._backBtn = undefined;
        }
        setTimeout(() => {
            if (this.chartType[1] !== 'full') {
                this._backBtn = this.graph.append('g').classed('btn-layer', true);
                let backBtnTranslatePosition = '';
                if (this.chartType[1] !== 'full') {
                    backBtnTranslatePosition = 'translate(' + (this._width - 100) + ',' + (this._height / 3) + ')';
                }
                else {
                    backBtnTranslatePosition = 'translate(' + (this._width - 100 - parseInt(this._fullGraph.node().style.left)) + ',' + (this._height / 3 - parseInt(this._fullGraph.node().style.top)) + ')';
                }
                let backBtn = this._backBtn.selectAll('g')
                    .data(['backBtn'])
                    .enter().append('g')
                    .attr('id', function (d) { return d; })
                    .attr('transform', (d, i) => { return backBtnTranslatePosition; })
                    .style('cursor', 'pointer')
                    .style('pointer-events', 'visible')
                    .on('click', (d) => { this._changeLevel(this._level, 'minus'); });
                backBtn.append('rect')
                    .attr('width', '56px')
                    .attr('height', '30px')
                    .style('fill', 'rgb(247, 247, 247)')
                    .style('stroke', 'rgb(204, 204, 204)')
                    .style('stroke-width', '1');
                backBtn.append('text')
                    .attr('x', 28)
                    .attr('y', 15)
                    .attr('dy', '.35em')
                    .attr('text-anchor', 'middle')
                    .style('font-size', '12px')
                    .style('font-weight', 'normal')
                    .text(function (d, i) { return this.isRtl ? 'Back ▷' : '◁ Back'; });
            }
            else {
                this._backBtn = this.svgContainer.append('div');
                this._backBtn.attr('class', 'kdx-map-chart-backbutton');
                this._backBtn.text(function (d, i) { return this.isRtl ? 'Back ▷' : '◁ Back'; });
                this._backBtn.on('click', (d) => { this._changeLevel(this._level, 'minus'); });
            }
        });
    }
    _checkBackBtn() {
        let checkDefaultLevel = this._checkDefaultLevel();
        if (checkDefaultLevel == true) {
            if (typeof this._backBtn === 'undefined')
                this._initBackBtn();
        }
        else {
            if (typeof this._backBtn !== 'undefined') {
                this._backBtn.remove();
                this._backBtn = undefined;
            }
        }
    }
    _checkDefaultLevel() {
        let checkDefault;
        let defaultLevel = this._defaultLevel.indexOf('_') != -1 ? this._defaultLevel.split('_')[1] : this._defaultLevel;
        if (this._level.indexOf('_') != -1) {
            checkDefault = parseInt(this._level.split('_')[1]) == defaultLevel ? false : true;
        }
        else {
            checkDefault = parseInt(this._level) == defaultLevel ? false : true;
        }
        return checkDefault;
    }
    _getSeriesValue(_seriesId) {
        let returnObj = {
            'id': '',
            'name': '',
            'drilldown': '',
            'value': ''
        };
        for (let i = 0; i < this._seriesPointer.data.length; i++) {
            if (this._seriesPointer.data[i].ID_ == _seriesId) {
                returnObj.id = this._seriesPointer.data[i].ID_;
                returnObj.name = this._seriesPointer.data[i].NAME1_;
                returnObj.drilldown = this._seriesPointer.data[i].drilldown;
                returnObj.value = this._seriesPointer.data[i].value;
                break;
            }
        }
        return returnObj;
    }
    _getNewSeries(_newLegend) {
        let legendPointer = _newLegend ? _newLegend : this.legend;
        let tempLegendArr = Object.keys(legendPointer).map(key => { return legendPointer[key]; });
        let newTempSeries = [];
        for (let i = 0; i < tempLegendArr.length; i++) {
            for (let j = 0; j < this._seriesData.length; j++) {
                if (tempLegendArr[i].deactive == false && this._seriesData[j].id == tempLegendArr[i].mapSeriesId) {
                    newTempSeries.push(this._seriesData[j]);
                    break;
                }
            }
        }
        this._emptySeries = newTempSeries.length != 0 ? false : true;
        if (newTempSeries.length != 0) {
            this._seriesPointer = newTempSeries[newTempSeries.length - 1];
        }
    }
    _getDrillDownLegendForMultipleDimension() {
        let tempLegend;
        if (this._checkDefaultLevel() == true) {
            tempLegend = this._chartSvc.setMapLegendData(this.legend, [this._seriesPointer], this.config);
        }
        else {
            tempLegend = this._chartSvc.setMapLegendData(this.legend, this._seriesData, this.config);
            this._getNewSeries(tempLegend);
        }
        this.outputLegend.emit(tempLegend);
    }
    _getColorPointer() {
        // let tempLegendArr = Object.keys(this.legend).map(item => this.legend[item]);
        let tempLegendArr = Object.keys(this.legendData).map(item => this.legendData[item]);
        if (this._seriesPointer != undefined) {
            for (let i = 0; i < tempLegendArr.length; i++) {
                if (this._seriesPointer.id == tempLegendArr[i].mapSeriesId) {
                    this._colorPointer = this.legendData[tempLegendArr[i].id];
                    // this._colorPointer = this.legend[tempLegendArr[i].id];
                    break;
                }
            }
        }
    }
    _overWriteSeries() {
        // change series color
        let tempLegendArr = Object.keys(this.legendData).map(item => this.legendData[item]);
        // let tempLegendArr = Object.keys(this.legend).map(item => this.legend[item]);
        for (let i = 0; i < tempLegendArr.length; i++) {
            for (let j = 0; j < this._seriesData.length; j++) {
                if (this._seriesData[j].id == tempLegendArr[i].mapSeriesId) {
                    this._seriesData[j].color = tempLegendArr[i].color;
                    break;
                }
            }
        }
    }
    _getLegendByType() {
        // check type of dimensions whether is single or multiple
        if (!this.config.skipMassage) {
            this._singleLevelDimension = false;
            if (this.config.colorAxis != undefined) {
                if (this.config.colorAxis.dataClasses && this.config.colorAxis.dataClasses.length !== 0) {
                    this._singleLevelDimension = true;
                    this.legend = this._chartSvc.setSingleLegendLevels(this.config.colorAxis.dataClasses, this.config.legend.valueDecimals, this.config.legend.valueSuffix, this.legend);
                    this.outputLegend.emit(this.legend);
                }
                else {
                    this.outputLegend.emit({});
                }
            }
            else {
                // multi dimension legend
                this.legend = this._chartSvc.setMapLegendData(this.legend, this._seriesData, this.config);
                this.outputLegend.emit(this.legend);
            }
        }
        else {
            // output legend only for exporting
            this._singleLevelDimension = false;
            if (this.config.colorAxis != undefined) {
                if (this.config.colorAxis.dataClasses && this.config.colorAxis.dataClasses.length !== 0) {
                    this._singleLevelDimension = true;
                    this.outputLegend.emit(this.legend);
                }
                else {
                    this.outputLegend.emit({});
                }
            }
            else {
                this.outputLegend.emit(this.legend);
            }
        }
    }
    _setMapScaleTriangle(_value) {
        let sign = this.isRtl ? -1 : 1;
        this._mapSvc.translateMapScaleTriangle(sign * this._mapSvc.valueScale(_value));
    }
    _removeMapScaleTriangle() {
        let triangleInitPoistion = this.isRtl ? 999 : -999;
        this._mapSvc.translateMapScaleTriangle(triangleInitPoistion);
    }
    _checkEmptyDataValue(_value) {
        if (this._seriesPointer.data == undefined) {
            return false;
        }
        else {
            let dataValue = this._getSeriesValue(_value).value;
            if (dataValue == undefined)
                return false;
            else if (dataValue != null && dataValue != '')
                return true;
            else
                return false;
        }
    }
    /**
     * drawing color scale of map
     */
    _drawMapScale() {
        // max and min colors
        let colorRange = [this.config.colorAxis.minColor, this.config.colorAxis.maxColor];
        // the actual length of bar in px. currently hardset to 200;
        let lengthRange = [0, 200];
        // array of tick intervals
        let tickArr = this._mapSvc.getLegendIntervals(this.config.colorAxis.min, this.config.colorAxis.max);
        let noOfInterval = tickArr.length - 1;
        let scaleDomain = [tickArr[0], tickArr[noOfInterval]];
        let arr = d3.range(noOfInterval);
        let linearGradientDirection = this.isRtl ? 'to left' : 'to right';
        // color scale according to tickArr, can be used to color the map. to use just call colorScale(value)
        this._mapScaleColorScale = this._mapSvc.setScale(scaleDomain, colorRange);
        // value scale according to tickArr, used to position triangle when hovered, save the valueScale in map service class
        this._mapSvc.valueScale = this._mapSvc.setScale(scaleDomain, lengthRange);
        let mapScaleWrapper = d3.select('#' + this.config.id + '.kdx-charts .kdx-map-scale-wrapper');
        let mapScale = mapScaleWrapper.select('#mapScale');
        mapScale.style('background', 'linear-gradient(' + linearGradientDirection + ',' + colorRange[0] + ',' + colorRange[1] + ')');
        this._mapSvc.mapScaleTriangle = mapScaleWrapper.select('.kdx-map-scale-triangle');
        mapScale.selectAll('.kdx-map-scale-rect')
            .data(arr)
            .enter().append('div')
            .attr('class', 'kdx-map-scale-rect')
            .attr('id', (d) => 'rect-' + d)
            .style('width', 100 / noOfInterval + '%');
        mapScaleWrapper.select('.kdx-map-scale-text-container')
            .selectAll('.kdx-map-scale-text')
            .data(tickArr)
            .enter().append('div')
            .attr('class', 'kdx-map-scale-text')
            .attr('id', (d) => 'text-' + d)
            .html(d => d);
    }
    _setMarkers() {
        if (this.chartType[1] === 'cluster')
            this.outputLegend.emit({});
        let clusterType = this.config.plotOptions.map.clusterType ? this.config.plotOptions.map.clusterType : 'cluster';
        this._clusterData = this._mapSvc.populateMarkers(this.data.pointData, this._leafletMap, clusterType);
        this.outputMarker.emit(this._clusterData.markersLegend);
        // this._isMarkerLoaded = true;
        // }
    }
    _setLayer() {
        if (this._layer)
            this._layer.remove();
        if (this.mapConfig.plotOptions.map.zoom)
            this._checkZoomConfig(this.mapConfig.plotOptions.map.zoom);
        this._layer = L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
            attribution: '&copy; <a href="http://www.openstreetmap.org/copyright">OpenStreetMap</a>',
            maxZoom: 18,
        }).addTo(this._leafletMap);
        this._attachTileListener();
    }
    _checkZoomConfig(_config) {
        if (typeof this._leafletMap !== 'undefined') {
            _config.isZoomButton ? this._leafletMap.addControl(this._leafletMap.zoomControl) : this._leafletMap.removeControl(this._leafletMap.zoomControl);
            _config.isScrollZoom ? this._leafletMap.scrollWheelZoom.enable() : this._leafletMap.scrollWheelZoom.disable();
            _config.isTouchZoom ? this._leafletMap.touchZoom.enable() : this._leafletMap.touchZoom.disable();
            _config.isDoubleClickZoom ? this._leafletMap.doubleClickZoom.enable() : this._leafletMap.doubleClickZoom.disable();
        }
    }
    _removeDefaultAttribution(_attribution) {
        let attributionElement = document.querySelector('.leaflet-control-attribution');
        if (attributionElement !== null) {
            let newAttributionElement = this._domSvc.createElement(attributionElement, 'custom-attribution');
            newAttributionElement.innerText = _attribution || 'OpenEMIS';
            attributionElement.replaceChild(newAttributionElement, attributionElement.firstChild);
        }
    }
    _attachTileListener() {
        /* Checks every tile. Only called when some tile load has failed. */
        this._layer.on('tileerror', (error) => {
            // only execute the following for the first tile error
            if (!this._isLayerError) {
                this._isLayerError = true;
                this._layerReloadTimes++;
                if (this._layerReloadTimes < 1 || this._layerReloadTimes === 1) {
                    this._setLayer();
                }
                if (this._layerReloadTimes > 5) {
                    // this.isMapShown = false;
                    // this.errorMessage = 'Max retry reached. Map cannot be loaded now. Please check your internet connection or try again later.';
                }
            }
        });
        /* Checks every tile. Only called when each tile load is successful. */
        this._layer.on('tileload', () => {
            this._tileloadIndex++;
            if (this._tileloadIndex === Object.keys(this._layer._tiles).length) {
                // only stop progress loader when last tile loaded successfully
                // this.isLayerLoading = false;
                // this._isTilesLoaded = true;
                this.outputReady.emit(false);
                // reset counters
                // this._layerReloadTimes = 0;
                this._tileloadIndex = 0;
            }
        });
    }
    _checkMapSelected(_areaId) {
        return this._isMapSelected.hasOwnProperty(_areaId);
    }
}
KdMapChart.decorators = [
    { type: Component, args: [{
                selector: 'kd-map-chart',
                template: `
        <div>
        </div>
    `,
                encapsulation: ViewEncapsulation.None,
                providers: [KdChartsSvc, KdDomElemSvc, KdMapChartSvc],
                host: {
                    'class': 'kdx-map-chart',
                }
            },] }
];
KdMapChart.ctorParameters = () => [
    { type: ElementRef },
    { type: KdChartsSvc },
    { type: KdDomElemSvc },
    { type: KdMapChartSvc }
];
KdMapChart.propDecorators = {
    data: [{ type: Input }],
    mapConfig: [{ type: Input, args: ['config',] }],
    legend: [{ type: Input }],
    api: [{ type: Input }],
    outputLegend: [{ type: Output }],
    outputData: [{ type: Output }],
    outputMarker: [{ type: Output }],
    outputReady: [{ type: Output }]
};
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoia2QtYW5ndWxhci1tYXAtY2hhcnQuanMiLCJzb3VyY2VSb290IjoiRDovb3BlbkVNSVMvc3R5bGVndWlkZS9pb3N0Zy1vcGVuZW1pcy1zdHlsZWd1aWRlL3Byb2plY3RzL29wZW5lbWlzLXN0eWxlZ3VpZGUtbGliL3NyYy8iLCJzb3VyY2VzIjpbImtkLWNvbXBvbmVudHMva2QtYW5ndWxhci1jaGFydHMva2QtYW5ndWxhci1tYXAtY2hhcnQva2QtYW5ndWxhci1tYXAtY2hhcnQudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsT0FBTyxFQUNILFNBQVMsRUFDVCxpQkFBaUIsRUFDakIsS0FBSyxFQUNMLE1BQU0sRUFDTixZQUFZLEVBS1osVUFBVSxFQUViLE1BQU0sZUFBZSxDQUFDO0FBQ3ZCLE9BQU8sRUFBRSxnQkFBZ0IsRUFBRSxNQUFNLGdDQUFnQyxDQUFDO0FBQ2xFLE9BQU8sRUFBRSxXQUFXLEVBQUUsTUFBTSwwQkFBMEIsQ0FBQztBQUN2RCxPQUFPLEVBQUUsWUFBWSxFQUFFLE1BQU0sdUJBQXVCLENBQUM7QUFDckQsT0FBTyxFQUFFLGFBQWEsRUFBRSxNQUFNLDRCQUE0QixDQUFDO0FBRTNELE9BQU8sS0FBSyxFQUFFLE1BQU0sSUFBSSxDQUFDO0FBQ3pCLE9BQU8sS0FBSyxDQUFDLE1BQU0sU0FBUyxDQUFDO0FBQzdCLE9BQU8sdUJBQXVCLENBQUM7QUFDL0IsT0FBTyxzREFBc0QsQ0FBQztBQWdCOUQsTUFBTSxPQUFPLFVBQVcsU0FBUSxnQkFBZ0I7SUFvQzVDLFlBQ1ksV0FBdUIsRUFDeEIsU0FBc0IsRUFDdEIsT0FBcUIsRUFDcEIsT0FBc0I7UUFFOUIsS0FBSyxDQUFDLFNBQVMsRUFBRSxPQUFPLENBQUMsQ0FBQztRQUxsQixnQkFBVyxHQUFYLFdBQVcsQ0FBWTtRQUN4QixjQUFTLEdBQVQsU0FBUyxDQUFhO1FBQ3RCLFlBQU8sR0FBUCxPQUFPLENBQWM7UUFDcEIsWUFBTyxHQUFQLE9BQU8sQ0FBZTtRQXZCMUIsc0JBQWlCLEdBQTZELEVBQUUsQ0FBQztRQUNqRixnQkFBVyxHQUFlLEVBQUUsQ0FBQztRQUM3QixpQkFBWSxHQUFZLEtBQUssQ0FBQztRQUM5QiwwQkFBcUIsR0FBWSxLQUFLLENBQUM7UUFDdkMsbUJBQWMsR0FBVyxDQUFDLENBQUM7UUFDM0Isa0JBQWEsR0FBWSxLQUFLLENBQUM7UUFDL0Isc0JBQWlCLEdBQVcsQ0FBQyxDQUFDO1FBQzlCLG1CQUFjLEdBQVEsRUFBRSxDQUFDO1FBT3ZCLGlCQUFZLEdBQWlELElBQUksWUFBWSxDQUFDLElBQUksQ0FBQyxDQUFDO1FBQ3BGLGVBQVUsR0FBc0IsSUFBSSxZQUFZLENBQUMsSUFBSSxDQUFDLENBQUM7UUFDdkQsaUJBQVksR0FBc0IsSUFBSSxZQUFZLENBQUMsSUFBSSxDQUFDLENBQUM7UUFDekQsZ0JBQVcsR0FBc0IsSUFBSSxZQUFZLENBQUMsSUFBSSxDQUFDLENBQUM7SUFTbEUsQ0FBQztJQUVELFFBQVE7UUFDSixJQUFJLENBQUMsTUFBTSxHQUFHLE1BQU0sQ0FBQyxNQUFNLENBQUMsRUFBRSxFQUFFLElBQUksQ0FBQyxTQUFTLENBQUMsQ0FBQztRQUNoRCxJQUFJLENBQUMsVUFBVSxHQUFHLE1BQU0sQ0FBQyxNQUFNLENBQUMsRUFBRSxFQUFFLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQztRQUNqRCxJQUFJLENBQUMsUUFBUSxFQUFFLENBQUM7UUFDaEIsS0FBSyxDQUFDLFlBQVksQ0FBQyxHQUFHLEVBQUUsQ0FBQyxJQUFJLENBQUMsU0FBUyxFQUFFLENBQUMsQ0FBQztRQUMzQyxJQUFJLENBQUMsR0FBRyxDQUFDLE1BQU0sR0FBRyxHQUFHLEVBQUU7WUFDbkIsVUFBVSxDQUFDLEdBQUcsRUFBRTtnQkFDWixJQUFJLENBQUMsZ0JBQWdCLEVBQUUsQ0FBQztnQkFDeEIsSUFBSSxDQUFDLFdBQVcsRUFBRSxDQUFDO2dCQUNuQixJQUFJLENBQUMsU0FBUyxFQUFFLENBQUM7Z0JBQ2pCLGtDQUFrQztnQkFDbEMsaUdBQWlHO2dCQUNqRyxJQUFJO2dCQUNKLElBQUksQ0FBQyxnQkFBZ0IsRUFBRSxDQUFDO1lBQzVCLENBQUMsQ0FBQyxDQUFDO1FBQ1AsQ0FBQyxDQUFDO1FBQ0YsSUFBSSxDQUFDLEdBQUcsQ0FBQyxXQUFXLEdBQUcsQ0FBQyxHQUFRLEVBQUUsYUFBYSxFQUFFLEVBQUU7WUFDL0MsSUFBSSxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsQ0FBQyxRQUFRLEdBQUcsYUFBYSxDQUFDO1lBQzFDLEtBQUssSUFBSSxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsR0FBRyxJQUFJLENBQUMsV0FBVyxDQUFDLE1BQU0sRUFBRSxDQUFDLEVBQUUsRUFBRTtnQkFDOUMsSUFBSSxJQUFJLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsSUFBSSxJQUFJLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsSUFBSSxJQUFJLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDLFdBQVcsRUFBRTtvQkFDbEYsSUFBSSxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLEdBQUcsYUFBYSxDQUFDO2lCQUNoRDthQUNKO1lBQ0QsSUFBSSxDQUFDLElBQUksQ0FBQyxlQUFlLENBQUMsR0FBRyxJQUFJLENBQUMsV0FBVyxDQUFDO1lBQzlDLElBQUksSUFBSSxDQUFDLHFCQUFxQixJQUFJLEtBQUs7Z0JBQUUsSUFBSSxDQUFDLGFBQWEsRUFBRSxDQUFDO1lBQzlELElBQUksQ0FBQyxXQUFXLEVBQUUsQ0FBQztZQUNuQixJQUFJLENBQUMsU0FBUyxFQUFFLENBQUM7UUFDckIsQ0FBQyxDQUFDO1FBQ0YsSUFBSSxDQUFDLEdBQUcsQ0FBQyxZQUFZLEdBQUcsQ0FBQyxHQUFRLEVBQUUsV0FBZ0YsRUFBRSxFQUFFO1lBQ25ILElBQUksbUJBQW9ELENBQUM7WUFDekQsbUJBQW1CLEdBQUcsSUFBSSxDQUFDLFlBQVksQ0FBQyxjQUFjLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxDQUFDO1lBRS9ELElBQUksSUFBSSxDQUFDLFdBQVcsQ0FBQyxRQUFRLENBQUMsbUJBQW1CLENBQUMsRUFBRTtnQkFDaEQsSUFBSSxDQUFDLFdBQVcsQ0FBQyxXQUFXLENBQUMsbUJBQW1CLENBQUMsQ0FBQztnQkFDbEQsSUFBSSxDQUFDLE9BQU8sQ0FBQyxRQUFRLENBQUMsV0FBVyxDQUFDLGdCQUFnQixFQUFFLCtCQUErQixDQUFDLENBQUM7Z0JBQ3JGLElBQUksQ0FBQyxPQUFPLENBQUMsUUFBUSxDQUFDLFdBQVcsQ0FBQyxlQUFlLEVBQUUscUJBQXFCLENBQUMsQ0FBQzthQUM3RTtpQkFDSTtnQkFDRCxJQUFJLENBQUMsV0FBVyxDQUFDLFFBQVEsQ0FBQyxtQkFBbUIsQ0FBQyxDQUFDO2dCQUMvQyxJQUFJLENBQUMsT0FBTyxDQUFDLFdBQVcsQ0FBQyxXQUFXLENBQUMsZ0JBQWdCLEVBQUUsK0JBQStCLENBQUMsQ0FBQztnQkFDeEYsSUFBSSxDQUFDLE9BQU8sQ0FBQyxXQUFXLENBQUMsV0FBVyxDQUFDLGVBQWUsRUFBRSxxQkFBcUIsQ0FBQyxDQUFDO2FBQ2hGO1FBQ0wsQ0FBQyxDQUFBO0lBQ0wsQ0FBQztJQUVELFdBQVcsQ0FBQyxjQUE2QjtRQUNyQyxJQUFJLGNBQWMsQ0FBQyxjQUFjLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxjQUFjLENBQUMsTUFBTSxDQUFDLENBQUMsV0FBVyxFQUFFO1lBQzlFLElBQUksQ0FBQyxJQUFJLEdBQUcsY0FBYyxDQUFDLElBQUksQ0FBQyxZQUFZLENBQUM7WUFDN0MsSUFBSSxDQUFDLFlBQVksQ0FBQyxNQUFNLENBQUMsQ0FBQztTQUM3QjtRQUNELElBQUksY0FBYyxDQUFDLGNBQWMsQ0FBQyxXQUFXLENBQUMsSUFBSSxDQUFDLGNBQWMsQ0FBQyxXQUFXLENBQUMsQ0FBQyxXQUFXLEVBQUU7WUFDeEYsSUFBSSxJQUFJLENBQUMsU0FBUyxDQUFDLFdBQVcsQ0FBQyxHQUFHLENBQUMsSUFBSSxFQUFFO2dCQUNyQyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxXQUFXLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxDQUFDO2dCQUMzRCxJQUFJLElBQUksQ0FBQyxTQUFTLENBQUMsV0FBVyxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsS0FBSyxFQUFFO29CQUMzQyxJQUFJLE9BQU8sSUFBSSxDQUFDLFdBQVcsS0FBSyxXQUFXO3dCQUFFLElBQUksQ0FBQyxXQUFXLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsV0FBVyxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLENBQUM7aUJBQ3BIO2dCQUNELHFDQUFxQztnQkFDckMsMkZBQTJGO2FBQzlGO1lBQ0QsSUFBSSxDQUFDLFNBQVMsR0FBRyxjQUFjLENBQUMsU0FBUyxDQUFDLFlBQVksQ0FBQztZQUN2RCxJQUFJLENBQUMsWUFBWSxDQUFDLFFBQVEsQ0FBQyxDQUFDO1NBQy9CO0lBQ0wsQ0FBQztJQUVELGVBQWU7UUFDWCxJQUFJLE9BQU8sSUFBSSxDQUFDLFdBQVcsS0FBSyxXQUFXO1lBQUUsSUFBSSxDQUFDLFdBQVcsQ0FBQyxjQUFjLENBQUMsRUFBRSxDQUFDLENBQUM7SUFDckYsQ0FBQztJQUVELFdBQVc7UUFDUCxJQUFJLENBQUMsV0FBVyxFQUFFLENBQUM7SUFDdkIsQ0FBQztJQUVPLFlBQVksQ0FBQyxRQUE0QjtRQUM3QyxJQUFJLENBQUMsV0FBVyxFQUFFLENBQUM7UUFFbkIsSUFBSSxRQUFRLEtBQUssTUFBTSxFQUFFO1lBQ3JCLElBQUksQ0FBQyxXQUFXLEdBQUcsRUFBRSxDQUFDO1NBQ3pCO2FBQU07WUFDSCxJQUFJLENBQUMsTUFBTSxHQUFHLE1BQU0sQ0FBQyxNQUFNLENBQUMsRUFBRSxFQUFFLElBQUksQ0FBQyxTQUFTLENBQUMsQ0FBQztTQUNuRDtRQUNELElBQUksQ0FBQyxVQUFVLEdBQUcsTUFBTSxDQUFDLE1BQU0sQ0FBQyxFQUFFLEVBQUUsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDO1FBRWpELElBQUksQ0FBQyxRQUFRLEVBQUUsQ0FBQztRQUNoQixLQUFLLENBQUMsWUFBWSxDQUFDLEdBQUcsRUFBRSxDQUFDLElBQUksQ0FBQyxTQUFTLEVBQUUsQ0FBQyxDQUFDO0lBQy9DLENBQUM7SUFFTyxTQUFTO1FBQ2IsSUFBSSxDQUFDLFNBQVMsR0FBRyxJQUFJLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDO1FBQ25ELElBQUksSUFBSSxDQUFDLE1BQU0sS0FBSyxTQUFTLElBQUksSUFBSSxDQUFDLE1BQU0sS0FBSyxJQUFJLEVBQUU7U0FDdEQ7YUFBTSxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsSUFBSSxJQUFJLENBQUMsTUFBTSxDQUFDLFdBQVcsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsSUFBSSxJQUFJLENBQUMscUJBQXFCLElBQUksSUFBSSxDQUFDLEVBQUU7WUFDNUgsNkhBQTZIO1lBQzdILElBQUksV0FBVyxHQUFrQixNQUFNLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLENBQUM7WUFDaEUsSUFBSSxDQUFDLGFBQWEsR0FBRyxXQUFXLENBQUMsTUFBTSxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxDQUFDO1lBQ3JGLElBQUksQ0FBQyxNQUFNLEdBQUcsSUFBSSxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsQ0FBQztZQUNwQyxrQ0FBa0M7U0FDckM7YUFBTSxJQUFJLElBQUksQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLE1BQU0sR0FBRyxDQUFDLENBQUMsQ0FBQyxJQUFJLElBQUksSUFBSSxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsTUFBTSxHQUFHLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxNQUFNLElBQUksQ0FBQyxFQUFFO1lBQzdILElBQUksQ0FBQyxhQUFhLEdBQUcsSUFBSSxDQUFDLE9BQU8sQ0FBQyx5QkFBeUIsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxNQUFNLEdBQUcsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsRUFBRSxJQUFJLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxDQUFDO1lBQzFJLElBQUksQ0FBQyxNQUFNLEdBQUcsSUFBSSxDQUFDLGFBQWEsQ0FBQztTQUNwQzthQUFNO1lBQ0gsSUFBSSxXQUFXLEdBQWtCLE1BQU0sQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsQ0FBQztZQUNoRSxJQUFJLENBQUMsYUFBYSxHQUFHLFdBQVcsQ0FBQyxNQUFNLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQztZQUNyRSxJQUFJLENBQUMsTUFBTSxHQUFHLElBQUksQ0FBQyxhQUFhLENBQUM7U0FDcEM7UUFDRCxJQUFJLENBQUMsZ0JBQWdCLEVBQUUsQ0FBQztRQUV4QiwrRkFBK0Y7UUFDL0YsSUFBSSxJQUFJLENBQUMsTUFBTSxDQUFDLFNBQVMsSUFBSSxTQUFTLElBQUksSUFBSSxDQUFDLE1BQU0sQ0FBQyxTQUFTLENBQUMsV0FBVyxJQUFJLFNBQVMsRUFBRTtZQUN0RixJQUFJLENBQUMsYUFBYSxFQUFFLENBQUM7U0FDeEI7UUFDRCxLQUFLLENBQUMsTUFBTSxFQUFFLENBQUM7UUFDZixLQUFLLENBQUMsZUFBZSxDQUFDLEdBQUcsQ0FBQyxDQUFDO1FBQzNCLEtBQUssQ0FBQyxlQUFlLENBQUMsR0FBRyxDQUFDLENBQUM7UUFFM0IsSUFBSSxDQUFDLE9BQU8sR0FBRyxJQUFJLENBQUMsWUFBWSxDQUFDLElBQUksRUFBRSxDQUFDLHFCQUFxQixFQUFFLENBQUMsTUFBTSxDQUFDO1FBQ3ZFLElBQUksQ0FBQyxNQUFNLEdBQUcsSUFBSSxDQUFDLFlBQVksQ0FBQyxJQUFJLEVBQUUsQ0FBQyxxQkFBcUIsRUFBRSxDQUFDLEtBQUssQ0FBQztRQUVyRSxJQUFJLElBQUksQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLEtBQUssU0FBUyxJQUFJLElBQUksQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLEtBQUssVUFBVSxFQUFFO1lBQ3JFLElBQUksQ0FBQyxlQUFlLEVBQUUsQ0FBQztTQUMxQjthQUFNLElBQUksSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsS0FBSyxNQUFNLElBQUksSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsS0FBSyxTQUFTLElBQUksSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsS0FBSyxRQUFRLEVBQUU7WUFDMUcsSUFBSSxDQUFDLGFBQWEsRUFBRSxDQUFDO1lBQ3JCLFVBQVUsQ0FBQyxHQUFHLEVBQUU7Z0JBQ1osSUFBSSxPQUFPLElBQUksQ0FBQyxXQUFXLEtBQUssV0FBVztvQkFBRSxJQUFJLENBQUMsV0FBVyxDQUFDLGNBQWMsQ0FBQyxFQUFFLENBQUMsQ0FBQztZQUNyRixDQUFDLENBQUMsQ0FBQTtZQUNGLElBQUksSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsS0FBSyxTQUFTO2dCQUFFLElBQUksQ0FBQyxZQUFZLEVBQUUsQ0FBQztTQUM1RDtRQUNELGtDQUFrQztRQUNsQyxzQ0FBc0M7SUFDMUMsQ0FBQztJQUVPLFFBQVE7UUFDWixJQUFJLENBQUMsYUFBYSxHQUFHLEtBQUssQ0FBQztRQUMzQixJQUFJLElBQUksQ0FBQyxJQUFJLENBQUMsZUFBZSxDQUFDLElBQUksSUFBSSxDQUFDLE1BQU0sQ0FBQyxXQUFXLEVBQUU7WUFDdkQsY0FBYztZQUNkLElBQUksQ0FBQyxXQUFXLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsZUFBZSxDQUFDLENBQUMsQ0FBQyxDQUFDO1lBQzFFLElBQUksSUFBSSxDQUFDLE1BQU0sQ0FBQyxTQUFTLElBQUksU0FBUyxFQUFFO2dCQUNwQyxtQkFBbUI7Z0JBQ25CLElBQUksQ0FBQyxjQUFjLEdBQUcsSUFBSSxDQUFDLE9BQU8sQ0FBQyxnQkFBZ0IsQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFDLENBQUM7YUFDekU7aUJBQ0k7Z0JBQ0QsSUFBSSxDQUFDLGFBQWEsRUFBRSxDQUFDO2FBQ3hCO1NBQ0o7YUFBTTtZQUNILElBQUksQ0FBQyxXQUFXLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQztZQUNoRSxLQUFLLElBQUksQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLEdBQUcsSUFBSSxDQUFDLFdBQVcsQ0FBQyxNQUFNLEVBQUUsQ0FBQyxFQUFFLEVBQUU7Z0JBQzlDLElBQUksQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDLENBQUMsVUFBVSxDQUFDLEdBQUcsS0FBSyxDQUFDO2FBQzNDO1lBQ0QsSUFBSSxJQUFJLENBQUMsTUFBTSxDQUFDLFNBQVMsSUFBSSxTQUFTLEVBQUU7Z0JBQ3BDLG1CQUFtQjtnQkFDbkIsSUFBSSxDQUFDLGNBQWMsR0FBRyxJQUFJLENBQUMsT0FBTyxDQUFDLGdCQUFnQixDQUFDLElBQUksQ0FBQyxXQUFXLENBQUMsQ0FBQzthQUN6RTtpQkFBTTtnQkFDSCxrQkFBa0I7Z0JBQ2xCLElBQUksSUFBSSxDQUFDLFdBQVcsSUFBSSxJQUFJLENBQUMsV0FBVyxDQUFDLE1BQU0sSUFBSSxDQUFDLEVBQUU7b0JBQ2xELElBQUksQ0FBQyxjQUFjLEdBQUcsSUFBSSxDQUFDLFdBQVcsQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFDLE1BQU0sR0FBRyxDQUFDLENBQUMsQ0FBQztpQkFDdkU7YUFDSjtZQUNELElBQUksQ0FBQyxZQUFZLEdBQUcsSUFBSSxDQUFDLGNBQWMsSUFBSSxTQUFTLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDO1NBQ3ZFO1FBRUQsa0NBQWtDO1FBQ2xDLGlHQUFpRztRQUNqRyxJQUFJO1FBQ0osSUFBSSxDQUFDLGdCQUFnQixFQUFFLENBQUM7UUFDeEIsSUFBSSxDQUFDLGdCQUFnQixFQUFFLENBQUM7SUFDNUIsQ0FBQztJQUVPLFdBQVc7UUFDZixJQUFJLE9BQU8sSUFBSSxDQUFDLFNBQVMsS0FBSyxXQUFXLEVBQUU7WUFDdkMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxNQUFNLEVBQUUsQ0FBQztZQUN4QixJQUFJLENBQUMsU0FBUyxHQUFHLFNBQVMsQ0FBQztTQUM5QjtRQUNELElBQUksSUFBSSxDQUFDLFdBQVcsS0FBSyxTQUFTLElBQUksSUFBSSxDQUFDLFdBQVcsS0FBSyxJQUFJLElBQUksQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLFdBQVcsRUFBRTtZQUN6RixJQUFJLENBQUMsV0FBVyxDQUFDLE1BQU0sRUFBRSxDQUFDO1lBQzFCLElBQUksQ0FBQyxXQUFXLEdBQUcsU0FBUyxDQUFDO1lBQzdCLElBQUksVUFBVSxHQUFHLEdBQUcsR0FBRyxJQUFJLENBQUMsTUFBTSxDQUFDLEVBQUUsR0FBRyxTQUFTLENBQUM7WUFDbEQsUUFBUSxDQUFDLGFBQWEsQ0FBQyxVQUFVLENBQUMsQ0FBQyxZQUFZLENBQUMsT0FBTyxFQUFFLDBCQUEwQixDQUFDLENBQUM7U0FDeEY7UUFDRCxJQUFJLE9BQU8sSUFBSSxDQUFDLFNBQVMsS0FBSyxXQUFXLEVBQUU7WUFDdkMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxNQUFNLEVBQUUsQ0FBQztZQUN4QixJQUFJLENBQUMsU0FBUyxHQUFHLFNBQVMsQ0FBQztTQUU5QjtRQUNELElBQUksT0FBTyxJQUFJLENBQUMsVUFBVSxLQUFLLFdBQVcsRUFBRTtZQUN4QyxJQUFJLENBQUMsVUFBVSxDQUFDLE1BQU0sRUFBRSxDQUFDO1lBQ3pCLElBQUksQ0FBQyxVQUFVLEdBQUcsU0FBUyxDQUFDO1NBQy9CO1FBQ0QsSUFBSSxPQUFPLElBQUksQ0FBQyxRQUFRLEtBQUssV0FBVyxFQUFFO1lBQ3RDLElBQUksQ0FBQyxRQUFRLENBQUMsTUFBTSxFQUFFLENBQUM7WUFDdkIsSUFBSSxDQUFDLFFBQVEsR0FBRyxTQUFTLENBQUM7U0FDN0I7UUFDRCxJQUFJLENBQUMsTUFBTSxHQUFHLFNBQVMsQ0FBQztRQUN4QixJQUFJLENBQUMsaUJBQWlCLEdBQUcsRUFBRSxDQUFDO1FBQzVCLElBQUksQ0FBQyxjQUFjLEdBQUcsRUFBRSxDQUFDO1FBQ3pCLEtBQUssQ0FBQyxXQUFXLEVBQUUsQ0FBQztJQUN4QixDQUFDO0lBRU8sYUFBYTtRQUNqQixJQUFJLElBQUksQ0FBQyxXQUFXLEtBQUssU0FBUyxJQUFJLElBQUksQ0FBQyxXQUFXLEtBQUssSUFBSTtZQUFFLElBQUksQ0FBQyxXQUFXLENBQUMsTUFBTSxFQUFFLENBQUM7UUFDM0YsSUFBSSxTQUFTLEdBQVcsQ0FBQyxDQUFDO1FBQzFCLElBQUksSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsS0FBSyxRQUFRLElBQUksSUFBSSxDQUFDLElBQUksQ0FBQyxRQUFRLElBQUksSUFBSSxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsSUFBSSxFQUFFO1lBQ2pGLFNBQVMsR0FBRyxJQUFJLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUM7U0FDdkM7YUFBTSxJQUFJLElBQUksQ0FBQyxNQUFNLENBQUMsV0FBVyxDQUFDLEdBQUcsQ0FBQyxJQUFJLElBQUksSUFBSSxDQUFDLE1BQU0sQ0FBQyxXQUFXLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxLQUFLLEVBQUU7WUFDbkYsU0FBUyxHQUFHLElBQUksQ0FBQyxNQUFNLENBQUMsV0FBVyxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDO1NBQ3REO1FBQ0QsSUFBSSxVQUFVLEdBQUcsSUFBSSxDQUFDLE1BQU0sQ0FBQyxFQUFFLEdBQUcsU0FBUyxDQUFDO1FBQzVDLElBQUksQ0FBQyxXQUFXLEdBQUcsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxVQUFVLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxRQUFRLEVBQUUsSUFBSSxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsU0FBUyxDQUFDLEVBQUUsU0FBUyxDQUFDLENBQUM7UUFDckgsSUFBSSxDQUFDLFNBQVMsRUFBRSxDQUFDO1FBQ2pCLElBQUksQ0FBQyx5QkFBeUIsQ0FBQyxVQUFVLENBQUMsQ0FBQztRQUMzQyxJQUFJLElBQUksQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLEtBQUssTUFBTSxJQUFJLElBQUksQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLEtBQUssU0FBUztZQUFFLElBQUksQ0FBQyxXQUFXLEVBQUUsQ0FBQztJQUM1RixDQUFDO0lBRU8sWUFBWTtRQUNoQixJQUFJLENBQUMsaUJBQWlCLEdBQUcsRUFBRSxDQUFDO1FBQzVCLElBQUksT0FBTyxJQUFJLENBQUMsVUFBVSxLQUFLLFdBQVc7WUFBRSxJQUFJLENBQUMsVUFBVSxHQUFHLEVBQUUsQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxRQUFRLEVBQUUsQ0FBQyxXQUFXLENBQUMsQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLENBQUM7UUFDL0gsc0ZBQXNGO1FBRXRGLElBQUksQ0FBQyxTQUFTLEdBQUcsSUFBSSxDQUFDLFVBQVUsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDLE9BQU8sRUFBRSxtQkFBbUIsQ0FBQyxDQUFDO1FBQ2hGLElBQUksR0FBRyxHQUFHLElBQUksQ0FBQyxXQUFXLENBQUM7UUFDM0IsSUFBSSxHQUFHLEdBQUcsSUFBSSxDQUFDLFVBQVUsQ0FBQztRQUMxQixJQUFJLGNBQWMsR0FBRyxJQUFJLENBQUMsTUFBTSxDQUFDLEVBQUUsQ0FBQztRQUNwQyxJQUFJLFFBQVEsR0FBRyxJQUFJLENBQUMsU0FBUyxDQUFDO1FBQzlCLElBQUksS0FBSyxHQUFHLElBQUksQ0FBQyxNQUFNLENBQUM7UUFDeEIsSUFBSSxNQUFNLEdBQUcsSUFBSSxDQUFDLE9BQU8sQ0FBQztRQUMxQixJQUFJLFNBQVMsR0FBRyxFQUFFLENBQUMsWUFBWSxDQUFDO1lBQzVCLEtBQUssRUFBRSxVQUFTLENBQUMsRUFBRSxDQUFDO2dCQUNoQixJQUFJLEtBQUssR0FBRyxHQUFHLENBQUMsa0JBQWtCLENBQUMsSUFBSSxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDO2dCQUN2RCxJQUFJLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsQ0FBQyxFQUFFLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQztZQUN4QyxDQUFDO1NBQ0osQ0FBQyxFQUNFLElBQUksR0FBRyxFQUFFLENBQUMsT0FBTyxFQUFFLENBQUMsVUFBVSxDQUFDLFNBQVMsQ0FBQyxDQUFDO1FBQzlDLElBQUksUUFBUSxFQUFFLGNBQW1CLENBQUM7UUFDbEMsSUFBSSxJQUFJLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxLQUFLLFFBQVEsSUFBSSxJQUFJLENBQUMsSUFBSSxDQUFDLGNBQWMsQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsS0FBSyxLQUFLLFNBQVMsSUFBSSxJQUFJLENBQUMsSUFBSSxDQUFDLEtBQUssS0FBSyxJQUFJLENBQUMsRUFBRTtZQUNwSSxRQUFRLEdBQUcsTUFBTSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO1lBQzNDLGNBQWMsR0FBRyxJQUFJLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxRQUFRLENBQUMsQ0FBQztTQUM5QztRQUNELHNFQUFzRTtRQUN0RSxzREFBc0Q7UUFDdEQsSUFBSSxJQUFJLENBQUMsTUFBTSxDQUFDLFdBQVcsQ0FBQyxHQUFHLENBQUMsS0FBSyxJQUFJLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxXQUFXLENBQUMsR0FBRyxDQUFDLEtBQUssS0FBSyxFQUFFLElBQUksSUFBSSxDQUFDLE1BQU0sQ0FBQyxXQUFXLENBQUMsR0FBRyxDQUFDLEtBQUssS0FBSyxTQUFTLElBQUksSUFBSSxDQUFDLE1BQU0sQ0FBQyxXQUFXLENBQUMsR0FBRyxDQUFDLEtBQUssS0FBSyxJQUFJLENBQUMsSUFBSSxJQUFJLENBQUMsT0FBTyxDQUFDLGtCQUFrQixDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsV0FBVyxDQUFDLEdBQUcsQ0FBQyxLQUFLLEVBQUUsSUFBSSxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsRUFBRTtZQUMzUSxJQUFJLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsS0FBSyxNQUFNLElBQUksSUFBSSxDQUFDLE1BQU0sQ0FBQyxXQUFXLENBQUMsR0FBRyxDQUFDLHlCQUF5QixLQUFLLElBQUksQ0FBQyxJQUFJLElBQUksQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLEtBQUssTUFBTSxFQUFFO2dCQUNsSSxJQUFJLENBQUMsTUFBTSxHQUFHLElBQUksQ0FBQyxNQUFNLENBQUMsV0FBVyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUM7YUFDbkQ7aUJBQU07Z0JBQ0gsSUFBSSxDQUFDLGFBQWEsRUFBRSxDQUFDO2FBQ3hCO1NBQ0o7YUFBTTtZQUNILElBQUksQ0FBQyxhQUFhLEVBQUUsQ0FBQztTQUN4QjtRQUVELElBQUksSUFBSSxHQUFHLElBQUksQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLGNBQWMsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUM7UUFDOUcsSUFBSSxVQUFVLEdBQUcsRUFBRSxDQUFDLFdBQVcsRUFBRSxDQUFDLE9BQU8sQ0FBQyxDQUFDLElBQUksQ0FBQyxNQUFNLEVBQUUsSUFBSSxDQUFDLE9BQU8sR0FBRyxFQUFFLENBQUMsRUFBRSxJQUFJLENBQUMsQ0FBQztRQUNsRixrREFBa0Q7UUFDbEQsSUFBSSxRQUFRLEdBQUcsSUFBSSxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsY0FBYyxDQUFDLFVBQVUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQyxRQUFRLENBQUM7UUFFbkksSUFBSSxPQUFPLEdBQUcsSUFBSSxDQUFDLFNBQVMsQ0FBQyxTQUFTLENBQUMsTUFBTSxDQUFDO2FBQ3pDLElBQUksQ0FBQyxRQUFRLENBQUM7YUFDZCxLQUFLLEVBQUUsQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDO1lBQ3ZCLG1CQUFtQjthQUNsQixJQUFJLENBQUMsSUFBSSxFQUFFLENBQUMsQ0FBQyxFQUFFLEVBQUUsR0FBRyxPQUFPLElBQUksQ0FBQyxPQUFPLENBQUMsWUFBWSxHQUFHLENBQUMsQ0FBQyxVQUFVLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDO2FBQzNFLElBQUksQ0FBQyxPQUFPLEVBQUUsQ0FBQyxDQUFDLEVBQUUsRUFBRTtZQUNqQixJQUFJLElBQUksQ0FBQyxZQUFZLElBQUksS0FBSyxJQUFJLElBQUksQ0FBQyxjQUFjLElBQUksSUFBSSxDQUFDLGNBQWMsQ0FBQyxJQUFJLElBQUksU0FBUyxFQUFFO2dCQUM1RixJQUFJLFdBQVcsR0FBRyxJQUFJLENBQUMsZUFBZSxDQUFDLENBQUMsQ0FBQyxVQUFVLENBQUMsR0FBRyxDQUFDLENBQUM7Z0JBQ3pELElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxJQUFJLENBQUMsRUFBRSxNQUFNLEVBQUUsV0FBVyxDQUFDLElBQUksRUFBRSxPQUFPLEVBQUUsV0FBVyxDQUFDLEtBQUssRUFBRSxJQUFJLEVBQUUsQ0FBQyxDQUFDLFVBQVUsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxDQUFDO2dCQUM5RyxPQUFPLEtBQUssR0FBRyxXQUFXLENBQUMsRUFBRSxHQUFHLFNBQVMsR0FBRyxXQUFXLENBQUMsSUFBSSxHQUFHLGNBQWMsR0FBRyxXQUFXLENBQUMsU0FBUyxHQUFHLFVBQVUsR0FBRyxXQUFXLENBQUMsS0FBSyxDQUFDO2FBQzFJO1FBQ0wsQ0FBQyxDQUFDO2FBQ0QsSUFBSSxDQUFDLGVBQWUsRUFBRSxvQkFBb0IsQ0FBQzthQUMzQyxLQUFLLENBQUMsTUFBTSxFQUFFLENBQUMsQ0FBQyxFQUFFLEVBQUU7WUFDakIsSUFBSSxJQUFJLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxLQUFLLFFBQVEsSUFBSSxJQUFJLENBQUMsSUFBSSxDQUFDLGNBQWMsQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsS0FBSyxLQUFLLFNBQVMsSUFBSSxJQUFJLENBQUMsSUFBSSxDQUFDLEtBQUssS0FBSyxJQUFJLENBQUMsRUFBRTtnQkFDcEksSUFBSSxDQUFDLENBQUMsY0FBYyxDQUFDLFlBQVksQ0FBQyxJQUFJLENBQUMsQ0FBQyxVQUFVLENBQUMsR0FBRyxLQUFLLGNBQWMsQ0FBQyxFQUFFLElBQUksQ0FBQyxDQUFDLFVBQVUsQ0FBQyxNQUFNLEtBQUssY0FBYyxDQUFDLElBQUksRUFBRTtvQkFDekgsSUFBSSxDQUFDLGNBQWMsR0FBRyxFQUFFLENBQUM7b0JBQ3pCLElBQUksQ0FBQyxjQUFjLENBQUMsQ0FBQyxDQUFDLFVBQVUsQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDLENBQUMsVUFBVSxDQUFDLEdBQUcsQ0FBQztvQkFDekQsT0FBTyxJQUFJLENBQUMsTUFBTSxDQUFDLFdBQVcsQ0FBQyxHQUFHLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUM7aUJBQzFEO3FCQUFNO29CQUNILE9BQU8sSUFBSSxDQUFDLGdCQUFnQixDQUFDLENBQUMsQ0FBQyxDQUFDO2lCQUNuQzthQUNKO2lCQUFNO2dCQUNILE9BQU8sSUFBSSxDQUFDLGdCQUFnQixDQUFDLENBQUMsQ0FBQyxDQUFDO2FBQ25DO1FBQ0wsQ0FBQyxDQUFDO2FBQ0QsS0FBSyxDQUFDLGNBQWMsRUFBRSxDQUFDLENBQUMsRUFBRSxFQUFFO1lBQ3pCLElBQUksSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsS0FBSyxRQUFRLElBQUksSUFBSSxDQUFDLElBQUksQ0FBQyxjQUFjLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLEtBQUssS0FBSyxTQUFTLElBQUksSUFBSSxDQUFDLElBQUksQ0FBQyxLQUFLLEtBQUssSUFBSSxDQUFDLEVBQUU7Z0JBQ3BJLElBQUksQ0FBQyxDQUFDLGNBQWMsQ0FBQyxZQUFZLENBQUMsSUFBSSxDQUFDLENBQUMsVUFBVSxDQUFDLEdBQUcsS0FBSyxjQUFjLENBQUMsRUFBRSxJQUFJLENBQUMsQ0FBQyxVQUFVLENBQUMsTUFBTSxLQUFLLGNBQWMsQ0FBQyxJQUFJLEVBQUU7b0JBQ3pILE9BQU8sSUFBSSxDQUFDLE1BQU0sQ0FBQyxXQUFXLENBQUMsR0FBRyxDQUFDLE1BQU0sQ0FBQyxjQUFjLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsV0FBVyxDQUFDLEdBQUcsQ0FBQyxNQUFNLENBQUMsY0FBYyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLFdBQVcsQ0FBQyxHQUFHLENBQUMsV0FBVyxDQUFDO2lCQUMxSjtxQkFBTTtvQkFDSCxPQUFPLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsS0FBSyxRQUFRLElBQUksSUFBSSxDQUFDLE1BQU0sQ0FBQyxXQUFXLENBQUMsR0FBRyxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxXQUFXLENBQUMsR0FBRyxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsV0FBVyxDQUFDLEdBQUcsQ0FBQyxXQUFXLENBQUM7aUJBQzlLO2FBQ0o7aUJBQU07Z0JBQ0gsT0FBTyxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLEtBQUssUUFBUSxJQUFJLElBQUksQ0FBQyxNQUFNLENBQUMsV0FBVyxDQUFDLEdBQUcsQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsV0FBVyxDQUFDLEdBQUcsQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLFdBQVcsQ0FBQyxHQUFHLENBQUMsV0FBVyxDQUFDO2FBQzlLO1FBQ0wsQ0FBQyxDQUFDO2FBQ0QsS0FBSyxDQUFDLFFBQVEsRUFBRSxJQUFJLENBQUMsTUFBTSxDQUFDLFdBQVcsQ0FBQyxHQUFHLENBQUMsV0FBVyxDQUFDO1lBQ3pELHdDQUF3QzthQUN2QyxLQUFLLENBQUMsZ0JBQWdCLEVBQUUsU0FBUyxDQUFDO2FBQ2xDLEtBQUssQ0FBQyxTQUFTLEVBQUUsR0FBRyxDQUFDLENBQUM7UUFFM0IsSUFBSSxDQUFDLFdBQVcsQ0FBQyxFQUFFLENBQUMsV0FBVyxFQUFFLEtBQUssQ0FBQyxDQUFDO1FBQ3hDLElBQUksQ0FBQyxXQUFXLENBQUMsRUFBRSxDQUFDLE1BQU0sRUFBRSxLQUFLLENBQUMsQ0FBQztRQUVuQyxJQUFJLFFBQVEsR0FBRyxJQUFJLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUM7UUFDOUMsS0FBSyxFQUFFLENBQUM7UUFFUixJQUFJLFFBQVEsR0FBRyxLQUFLLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxnQkFBZ0IsQ0FBQyxHQUFHLEdBQUcsSUFBSSxDQUFDLE1BQU0sQ0FBQyxFQUFFLEdBQUcsb0NBQW9DLENBQUMsQ0FBQyxDQUFDO1FBQ2xILFFBQVEsQ0FBQyxPQUFPLENBQUMsQ0FBQyxFQUFFLEVBQUUsRUFBRTtZQUNwQixFQUFFLENBQUMsZ0JBQWdCLENBQUMsV0FBVyxFQUFFLENBQUMsQ0FBQyxFQUFFLEVBQUU7Z0JBQ25DLElBQUksYUFBYSxHQUE2QixDQUFDLENBQUMsTUFBTSxDQUFDO2dCQUN2RCxJQUFJLGVBQWUsR0FBVyxJQUFJLENBQUMsT0FBTyxDQUFDLGtCQUFrQixDQUFDLGFBQWEsQ0FBQyxDQUFDO2dCQUM3RSxJQUFJLGdCQUFnQixHQUFHLElBQUksQ0FBQyxPQUFPLENBQUMsbUJBQW1CLENBQUMsSUFBSSxDQUFDLFlBQVksRUFBRSxhQUFhLENBQUMsWUFBWSxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUM7Z0JBQzdHLElBQUksSUFBSSxDQUFDLG9CQUFvQixDQUFDLGVBQWUsQ0FBQyxFQUFFO29CQUM1QyxJQUFJLElBQUksQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLEtBQUssUUFBUSxJQUFJLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsS0FBSyxRQUFRLElBQUksQ0FBQyxJQUFJLENBQUMsaUJBQWlCLENBQUMsZUFBZSxDQUFDLENBQUMsRUFBRTt3QkFDaEgsZ0JBQWdCLENBQUMsS0FBSyxDQUFDLE1BQU0sRUFBRSxJQUFJLENBQUMsTUFBTSxDQUFDLFdBQVcsQ0FBQyxHQUFHLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsQ0FBQztxQkFDbEY7b0JBQ0QsSUFBSSxJQUFJLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxLQUFLLFFBQVEsSUFBSSxJQUFJLENBQUMsTUFBTSxDQUFDLFdBQVcsQ0FBQyxHQUFHLENBQUMsTUFBTSxJQUFJLElBQUksQ0FBQyxNQUFNLENBQUMsV0FBVyxDQUFDLEdBQUcsQ0FBQyxNQUFNLENBQUMsV0FBVyxJQUFJLENBQUMsSUFBSSxDQUFDLGlCQUFpQixDQUFDLGVBQWUsQ0FBQyxFQUFFO3dCQUNwSyxnQkFBZ0IsQ0FBQyxLQUFLLENBQUMsY0FBYyxFQUFFLElBQUksQ0FBQyxNQUFNLENBQUMsV0FBVyxDQUFDLEdBQUcsQ0FBQyxNQUFNLENBQUMsV0FBVyxDQUFDLENBQUM7cUJBQzFGO2lCQUNKO1lBQ0wsQ0FBQyxDQUFDLENBQUM7WUFDSCxFQUFFLENBQUMsZ0JBQWdCLENBQUMsVUFBVSxFQUFFLENBQUMsQ0FBQyxFQUFFLEVBQUU7Z0JBQ2xDLElBQUksYUFBYSxHQUE2QixDQUFDLENBQUMsTUFBTSxDQUFDO2dCQUN2RCxJQUFJLGVBQWUsR0FBVyxJQUFJLENBQUMsT0FBTyxDQUFDLGtCQUFrQixDQUFDLGFBQWEsQ0FBQyxDQUFDO2dCQUM3RSxJQUFJLGdCQUFnQixHQUFHLElBQUksQ0FBQyxPQUFPLENBQUMsbUJBQW1CLENBQUMsSUFBSSxDQUFDLFlBQVksRUFBRSxhQUFhLENBQUMsWUFBWSxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUM7Z0JBQzdHLElBQUksSUFBSSxDQUFDLG9CQUFvQixDQUFDLGVBQWUsQ0FBQyxFQUFFO29CQUM1QyxJQUFJLElBQUksQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLEtBQUssUUFBUSxJQUFJLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsS0FBSyxRQUFRLElBQUksQ0FBQyxJQUFJLENBQUMsaUJBQWlCLENBQUMsZUFBZSxDQUFDLENBQUMsRUFBRTt3QkFDaEgsZ0JBQWdCLENBQUMsS0FBSyxDQUFDLE1BQU0sRUFBRSxDQUFDLEVBQUUsRUFBRSxFQUFFOzRCQUNsQyxPQUFPLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxFQUFFLENBQUMsQ0FBQzt3QkFDckMsQ0FBQyxDQUFDLENBQUM7cUJBQ047b0JBQ0QsSUFBSSxJQUFJLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxLQUFLLFFBQVEsSUFBSSxJQUFJLENBQUMsTUFBTSxDQUFDLFdBQVcsQ0FBQyxHQUFHLENBQUMsTUFBTSxJQUFJLElBQUksQ0FBQyxNQUFNLENBQUMsV0FBVyxDQUFDLEdBQUcsQ0FBQyxNQUFNLENBQUMsTUFBTSxJQUFJLENBQUMsSUFBSSxDQUFDLGlCQUFpQixDQUFDLGFBQWEsQ0FBQyxZQUFZLENBQUMsSUFBSSxDQUFDLENBQUMsRUFBRTt3QkFDaEwsZ0JBQWdCLENBQUMsS0FBSyxDQUFDLGNBQWMsRUFBRSxJQUFJLENBQUMsTUFBTSxDQUFDLFdBQVcsQ0FBQyxHQUFHLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxDQUFDO3FCQUNyRjtpQkFDSjtZQUNMLENBQUMsQ0FBQyxDQUFDO1lBQ0gsRUFBRSxDQUFDLGdCQUFnQixDQUFDLE9BQU8sRUFBRSxDQUFDLENBQUMsRUFBRSxFQUFFO2dCQUMvQixJQUFJLGFBQWEsR0FBNkIsQ0FBQyxDQUFDLE1BQU0sQ0FBQztnQkFDdkQsSUFBSSxlQUFlLEdBQVcsSUFBSSxDQUFDLE9BQU8sQ0FBQyxrQkFBa0IsQ0FBQyxhQUFhLENBQUMsQ0FBQztnQkFDN0UsSUFBSSxnQkFBZ0IsR0FBRyxJQUFJLENBQUMsT0FBTyxDQUFDLG1CQUFtQixDQUFDLElBQUksQ0FBQyxZQUFZLEVBQUUsYUFBYSxDQUFDLFlBQVksQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDO2dCQUM3RyxJQUFJLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsS0FBSyxNQUFNLElBQUksSUFBSSxDQUFDLE1BQU0sQ0FBQyxXQUFXLENBQUMsR0FBRyxDQUFDLHlCQUF5QixLQUFLLElBQUksQ0FBQyxJQUFJLElBQUksQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLEtBQUssTUFBTSxFQUFFO29CQUNsSSxJQUFJLENBQUMsVUFBVSxDQUFDLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQztvQkFDckQsSUFBSSxJQUFJLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxLQUFLLFFBQVEsRUFBRTt3QkFDaEMsSUFBSSx1QkFBdUIsR0FBWSxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsV0FBVyxDQUFDLEdBQUcsQ0FBQyxNQUFNLElBQUksSUFBSSxDQUFDLE1BQU0sQ0FBQyxXQUFXLENBQUMsR0FBRyxDQUFDLE1BQU0sQ0FBQyxjQUFjLElBQUksSUFBSSxDQUFDLE1BQU0sQ0FBQyxXQUFXLENBQUMsR0FBRyxDQUFDLE1BQU0sQ0FBQyxjQUFjLElBQUksU0FBUyxDQUFDLENBQUM7d0JBQ25NLHdDQUF3Qzt3QkFDeEMsSUFBSSxJQUFJLENBQUMsTUFBTSxDQUFDLFdBQVcsQ0FBQyxHQUFHLENBQUMsTUFBTSxJQUFJLElBQUksQ0FBQyxNQUFNLENBQUMsV0FBVyxDQUFDLEdBQUcsQ0FBQyxNQUFNLENBQUMsTUFBTSxJQUFJLElBQUksQ0FBQyxNQUFNLENBQUMsV0FBVyxDQUFDLEdBQUcsQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLEtBQUssSUFBSSxJQUFJLENBQUMsTUFBTSxDQUFDLFdBQVcsQ0FBQyxHQUFHLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxLQUFLLEtBQUssRUFBRSxFQUFFOzRCQUM5TCxJQUFJLE1BQU0sQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLGNBQWMsQ0FBQyxDQUFDLE1BQU0sS0FBSyxDQUFDLEVBQUU7Z0NBQy9DLElBQUksY0FBYyxHQUFHLE1BQU0sQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLGNBQWMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO2dDQUN6RCxFQUFFLENBQUMsTUFBTSxDQUFDLEdBQUcsR0FBRyxJQUFJLENBQUMsTUFBTSxDQUFDLEVBQUUsR0FBRyxvQ0FBb0MsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxHQUFHLEdBQUcsSUFBSSxDQUFDLE9BQU8sQ0FBQyxZQUFZLEdBQUcsY0FBYyxDQUFDLENBQUMsS0FBSyxDQUFDLE1BQU0sRUFBRSxDQUFDLEVBQUUsRUFBRSxFQUFFO29DQUNqSixPQUFPLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxFQUFFLENBQUMsQ0FBQztnQ0FDckMsQ0FBQyxDQUFDLENBQUM7Z0NBQ0gsSUFBSSx1QkFBdUI7b0NBQUUsRUFBRSxDQUFDLE1BQU0sQ0FBQyxHQUFHLEdBQUcsSUFBSSxDQUFDLE1BQU0sQ0FBQyxFQUFFLEdBQUcsb0NBQW9DLENBQUMsQ0FBQyxNQUFNLENBQUMsR0FBRyxHQUFHLElBQUksQ0FBQyxPQUFPLENBQUMsWUFBWSxHQUFHLGNBQWMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxjQUFjLEVBQUUsSUFBSSxDQUFDLE1BQU0sQ0FBQyxXQUFXLENBQUMsR0FBRyxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsQ0FBQztnQ0FDOU4sSUFBSSxDQUFDLGNBQWMsR0FBRyxFQUFFLENBQUM7Z0NBQ3pCLElBQUksY0FBYyxLQUFLLGVBQWUsRUFBRTtvQ0FDcEMsSUFBSSxDQUFDLGNBQWMsQ0FBQyxlQUFlLENBQUMsR0FBRyxlQUFlLENBQUM7b0NBQ3ZELGdCQUFnQixDQUFDLEtBQUssQ0FBQyxNQUFNLEVBQUUsSUFBSSxDQUFDLE1BQU0sQ0FBQyxXQUFXLENBQUMsR0FBRyxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLENBQUM7b0NBQ2hGLElBQUksdUJBQXVCO3dDQUFFLGdCQUFnQixDQUFDLEtBQUssQ0FBQyxjQUFjLEVBQUUsSUFBSSxDQUFDLE1BQU0sQ0FBQyxXQUFXLENBQUMsR0FBRyxDQUFDLE1BQU0sQ0FBQyxjQUFjLENBQUMsQ0FBQztpQ0FDMUg7NkJBQ0o7aUNBQU07Z0NBQ0gsSUFBSSxDQUFDLGNBQWMsR0FBRyxFQUFFLENBQUM7Z0NBQ3pCLElBQUksQ0FBQyxjQUFjLENBQUMsZUFBZSxDQUFDLEdBQUcsZUFBZSxDQUFDO2dDQUN2RCxnQkFBZ0IsQ0FBQyxLQUFLLENBQUMsTUFBTSxFQUFFLElBQUksQ0FBQyxNQUFNLENBQUMsV0FBVyxDQUFDLEdBQUcsQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxDQUFDO2dDQUNoRixJQUFJLHVCQUF1QjtvQ0FBRSxnQkFBZ0IsQ0FBQyxLQUFLLENBQUMsY0FBYyxFQUFFLElBQUksQ0FBQyxNQUFNLENBQUMsV0FBVyxDQUFDLEdBQUcsQ0FBQyxNQUFNLENBQUMsY0FBYyxDQUFDLENBQUM7NkJBQzFIO3lCQUNKO3FCQUNKO2lCQUNKO3FCQUFNO29CQUNILElBQUksSUFBSSxDQUFDLG9CQUFvQixDQUFDLGVBQWUsQ0FBQyxFQUFFO3dCQUM1QyxJQUFJLENBQUMsWUFBWSxDQUFDLElBQUksQ0FBQyxNQUFNLEVBQUUsS0FBSyxDQUFDLENBQUM7cUJBQ3pDO2lCQUNKO1lBQ0wsQ0FBQyxDQUFDLENBQUM7UUFDUCxDQUFDLENBQUMsQ0FBQztRQUNILDRDQUE0QztRQUM1QyxTQUFTLEtBQUs7WUFDVixJQUFJLE1BQU0sR0FBRyxJQUFJLENBQUMsTUFBTSxDQUFDLFFBQVEsQ0FBQyxFQUM5QixPQUFPLEdBQUcsTUFBTSxDQUFDLENBQUMsQ0FBQyxFQUNuQixXQUFXLEdBQUcsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDO1lBQzVCLGlGQUFpRjtZQUNqRixHQUFHLENBQUMsSUFBSSxDQUFDLE9BQU8sRUFBRSxXQUFXLENBQUMsQ0FBQyxDQUFDLEdBQUcsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDO2lCQUN6QyxJQUFJLENBQUMsUUFBUSxFQUFFLFdBQVcsQ0FBQyxDQUFDLENBQUMsR0FBRyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUM7aUJBQzNDLEtBQUssQ0FBQyxNQUFNLEVBQUUsT0FBTyxDQUFDLENBQUMsQ0FBQyxHQUFHLElBQUksQ0FBQztpQkFDaEMsS0FBSyxDQUFDLEtBQUssRUFBRSxPQUFPLENBQUMsQ0FBQyxDQUFDLEdBQUcsSUFBSSxDQUFDLENBQUM7WUFFckMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxNQUFNLENBQUMsR0FBRyxHQUFHLGNBQWMsR0FBRyxvQ0FBb0MsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxVQUFVLENBQUMsQ0FBQyxLQUFLLEVBQUUsRUFBRTtnQkFDcEcsRUFBRSxDQUFDLE1BQU0sQ0FBQyxHQUFHLEdBQUcsY0FBYyxHQUFHLG9DQUFvQyxDQUFDLENBQUMsTUFBTSxDQUFDLFVBQVUsQ0FBQyxDQUFDLElBQUksQ0FBQyxXQUFXLEVBQUU7b0JBQ3hHLE9BQU8sWUFBWSxHQUFHLENBQUMsS0FBSyxHQUFHLEdBQUcsR0FBRyxRQUFRLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxHQUFHLEdBQUcsQ0FBQyxNQUFNLEdBQUcsQ0FBQyxHQUFHLFFBQVEsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLEdBQUcsQ0FBQztnQkFDakgsQ0FBQyxDQUFDLENBQUE7YUFDTDtZQUNELFFBQVEsQ0FBQyxJQUFJLENBQUMsV0FBVyxFQUFFLFlBQVksR0FBRyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsR0FBRyxHQUFHLEdBQUcsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLEdBQUcsR0FBRyxDQUFDLENBQUM7WUFDakYsT0FBTyxDQUFDLElBQUksQ0FBQyxHQUFHLEVBQUUsSUFBSSxDQUFDLENBQUM7UUFDNUIsQ0FBQztRQUVELElBQUksV0FBVyxHQUFHO1lBQ2QsWUFBWSxFQUFFLElBQUksQ0FBQyxpQkFBaUI7WUFDcEMsWUFBWSxFQUFFLElBQUksQ0FBQyxjQUFjLENBQUMsSUFBSTtZQUN0QyxjQUFjLEVBQUUsRUFBRSxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFDLFFBQVEsRUFBRSxDQUFDLFdBQVcsQ0FBQztZQUNsRSxXQUFXLEVBQUUsSUFBSSxDQUFDLFVBQVU7U0FDL0IsQ0FBQztRQUNGLElBQUksSUFBSSxDQUFDLE1BQU0sQ0FBQyxTQUFTLElBQUksU0FBUyxJQUFJLElBQUksQ0FBQyxNQUFNLENBQUMsU0FBUyxDQUFDLFdBQVcsSUFBSSxTQUFTLEVBQUU7WUFDdEYsV0FBVyxDQUFDLFdBQVcsQ0FBQyxHQUFHO2dCQUN2QixXQUFXLEVBQUUsQ0FBQyxDQUFDLEVBQUUsRUFBRSxDQUFDLElBQUksQ0FBQyxvQkFBb0IsQ0FBQyxDQUFDLENBQUM7Z0JBQ2hELFVBQVUsRUFBRSxHQUFHLEVBQUUsQ0FBQyxJQUFJLENBQUMsdUJBQXVCLEVBQUU7YUFDbkQsQ0FBQztTQUNMO1FBQ0QsY0FBYztRQUNkLElBQUksSUFBSSxDQUFDLGNBQWMsQ0FBQyxJQUFJLElBQUksU0FBUyxFQUFFO1lBQ3ZDLEtBQUssQ0FBQyxnQkFBZ0IsQ0FBQyxPQUFPLEVBQUUsV0FBVyxDQUFDLENBQUM7U0FDaEQ7SUFHTCxDQUFDO0lBRU8sZUFBZTtRQUNuQixJQUFJLENBQUMsaUJBQWlCLEdBQUcsRUFBRSxDQUFDO1FBQzVCLElBQUksQ0FBQyxLQUFLLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsT0FBTyxFQUFFLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQyxJQUFJLENBQUMsUUFBUSxFQUFFLElBQUksQ0FBQyxPQUFPLENBQUMsQ0FBQztRQUVoRixJQUFJLENBQUMsU0FBUyxHQUFHLElBQUksQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxXQUFXLEVBQUUsSUFBSSxDQUFDLENBQUM7UUFDbkUsSUFBSSxJQUFJLENBQUMsTUFBTSxDQUFDLGFBQWEsSUFBSSxJQUFJLENBQUMsTUFBTSxDQUFDLGFBQWEsQ0FBQyxPQUFPLElBQUksSUFBSSxFQUFFO1lBQ3hFLElBQUksT0FBTyxJQUFJLENBQUMsU0FBUyxLQUFLLFdBQVc7Z0JBQUUsSUFBSSxDQUFDLFlBQVksRUFBRSxDQUFDO1NBQ2xFO1FBQ0Qsd0JBQXdCO1FBQ3hCLElBQUksSUFBSSxDQUFDLE1BQU0sQ0FBQyxXQUFXLENBQUMsR0FBRyxDQUFDLEtBQUssSUFBSSxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsV0FBVyxDQUFDLEdBQUcsQ0FBQyxLQUFLLEtBQUssRUFBRSxJQUFJLElBQUksQ0FBQyxNQUFNLENBQUMsV0FBVyxDQUFDLEdBQUcsQ0FBQyxLQUFLLEtBQUssU0FBUyxJQUFJLElBQUksQ0FBQyxNQUFNLENBQUMsV0FBVyxDQUFDLEdBQUcsQ0FBQyxLQUFLLEtBQUssSUFBSSxDQUFDLElBQUksSUFBSSxDQUFDLE9BQU8sQ0FBQyxrQkFBa0IsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLFdBQVcsQ0FBQyxHQUFHLENBQUMsS0FBSyxFQUFFLElBQUksQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLEVBQUU7WUFDM1EsSUFBSSxJQUFJLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxLQUFLLFVBQVUsRUFBRTtnQkFDbEMsSUFBSSxDQUFDLE1BQU0sR0FBRyxJQUFJLENBQUMsTUFBTSxDQUFDLFdBQVcsQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDO2FBQ25EO2lCQUFNO2dCQUNILElBQUksQ0FBQyxhQUFhLEVBQUUsQ0FBQzthQUN4QjtTQUNKO2FBQU0sSUFBSSxJQUFJLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxLQUFLLFNBQVMsRUFBRTtZQUN4QyxJQUFJLENBQUMsYUFBYSxFQUFFLENBQUM7U0FDeEI7UUFDRCxJQUFJLElBQUksR0FBRyxJQUFJLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxjQUFjLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDO1FBQzlHLElBQUksVUFBVSxHQUFHLEVBQUUsQ0FBQyxXQUFXLEVBQUUsQ0FBQyxPQUFPLENBQUMsQ0FBQyxJQUFJLENBQUMsTUFBTSxFQUFFLElBQUksQ0FBQyxPQUFPLEdBQUcsRUFBRSxDQUFDLEVBQUUsSUFBSSxDQUFDLENBQUM7UUFDbEYsSUFBSSxJQUFJLEdBQUcsRUFBRSxDQUFDLE9BQU8sRUFBRSxDQUFDLFVBQVUsQ0FBQyxVQUFVLENBQUMsQ0FBQztRQUMvQyxJQUFJLFFBQVEsR0FBRyxJQUFJLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxjQUFjLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDLFFBQVEsQ0FBQztRQUNuSSxJQUFJLE9BQU8sR0FBRyxJQUFJLENBQUMsU0FBUyxDQUFDLFNBQVMsQ0FBQyxNQUFNLENBQUM7YUFDekMsSUFBSSxDQUFDLFFBQVEsQ0FBQzthQUNkLEtBQUssRUFBRSxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUM7YUFDdEIsSUFBSSxDQUFDLEdBQUcsRUFBRSxJQUFJLENBQUM7YUFDZixJQUFJLENBQUMsSUFBSSxFQUFFLENBQUMsQ0FBQyxFQUFFLEVBQUUsR0FBRyxPQUFPLElBQUksQ0FBQyxPQUFPLENBQUMsWUFBWSxHQUFHLENBQUMsQ0FBQyxVQUFVLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDO2FBQzNFLElBQUksQ0FBQyxPQUFPLEVBQUUsQ0FBQyxDQUFDLEVBQUUsRUFBRTtZQUNqQixJQUFJLElBQUksQ0FBQyxZQUFZLElBQUksS0FBSyxJQUFJLElBQUksQ0FBQyxjQUFjLElBQUksSUFBSSxDQUFDLGNBQWMsQ0FBQyxJQUFJLElBQUksU0FBUyxFQUFFO2dCQUM1RixJQUFJLFdBQVcsR0FBRyxJQUFJLENBQUMsZUFBZSxDQUFDLENBQUMsQ0FBQyxVQUFVLENBQUMsR0FBRyxDQUFDLENBQUM7Z0JBQ3pELElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxJQUFJLENBQUMsRUFBRSxNQUFNLEVBQUUsV0FBVyxDQUFDLElBQUksRUFBRSxPQUFPLEVBQUUsV0FBVyxDQUFDLEtBQUssRUFBRSxJQUFJLEVBQUUsQ0FBQyxDQUFDLFVBQVUsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxDQUFDO2dCQUM5RyxPQUFPLEtBQUssR0FBRyxXQUFXLENBQUMsRUFBRSxHQUFHLFNBQVMsR0FBRyxXQUFXLENBQUMsSUFBSSxHQUFHLGNBQWMsR0FBRyxXQUFXLENBQUMsU0FBUyxHQUFHLFVBQVUsR0FBRyxXQUFXLENBQUMsS0FBSyxDQUFDO2FBQzFJO1FBQ0wsQ0FBQyxDQUFDO2FBQ0QsSUFBSSxDQUFDLGVBQWUsRUFBRSxvQkFBb0IsQ0FBQzthQUMzQyxLQUFLLENBQUMsTUFBTSxFQUFFLENBQUMsQ0FBQyxFQUFFLEVBQUU7WUFDakIsT0FBTyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsQ0FBQyxDQUFDLENBQUM7UUFDcEMsQ0FBQyxDQUFDO2FBQ0QsS0FBSyxDQUFDLGNBQWMsRUFBRSxJQUFJLENBQUMsTUFBTSxDQUFDLFdBQVcsQ0FBQyxHQUFHLENBQUMsV0FBVyxDQUFDO2FBQzlELEtBQUssQ0FBQyxRQUFRLEVBQUUsSUFBSSxDQUFDLE1BQU0sQ0FBQyxXQUFXLENBQUMsR0FBRyxDQUFDLFdBQVcsQ0FBQyxDQUFDO1FBRTlELGlEQUFpRDtRQUNqRCxJQUFJLElBQUksQ0FBQyxZQUFZLElBQUksS0FBSyxFQUFFO1lBQzVCLElBQUksUUFBUSxHQUFHLEtBQUssQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLGdCQUFnQixDQUFDLEdBQUcsR0FBRyxJQUFJLENBQUMsTUFBTSxDQUFDLEVBQUUsR0FBRyw0QkFBNEIsQ0FBQyxDQUFDLENBQUM7WUFDMUcsUUFBUSxDQUFDLE9BQU8sQ0FBQyxDQUFDLEVBQUUsRUFBRSxFQUFFO2dCQUNwQixFQUFFLENBQUMsZ0JBQWdCLENBQUMsV0FBVyxFQUFFLENBQUMsQ0FBQyxFQUFFLEVBQUU7b0JBQ25DLElBQUksYUFBYSxHQUE2QixDQUFDLENBQUMsTUFBTSxDQUFDO29CQUN2RCxJQUFJLGVBQWUsR0FBVyxhQUFhLENBQUMsWUFBWSxDQUFDLElBQUksQ0FBQyxDQUFDLE9BQU8sQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsYUFBYSxDQUFDLFlBQVksQ0FBQyxJQUFJLENBQUMsQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLGFBQWEsQ0FBQyxZQUFZLENBQUMsSUFBSSxDQUFDLENBQUM7b0JBQzFLLElBQUksZ0JBQWdCLEdBQUcsSUFBSSxDQUFDLE9BQU8sQ0FBQyxtQkFBbUIsQ0FBQyxJQUFJLENBQUMsWUFBWSxFQUFFLGFBQWEsQ0FBQyxZQUFZLENBQUMsSUFBSSxDQUFDLEVBQUUsSUFBSSxDQUFDLENBQUM7b0JBQ25ILElBQUksSUFBSSxDQUFDLG9CQUFvQixDQUFDLGVBQWUsQ0FBQyxFQUFFO3dCQUM1QyxnQkFBZ0IsQ0FBQyxLQUFLLENBQUMsTUFBTSxFQUFFLElBQUksQ0FBQyxNQUFNLENBQUMsV0FBVyxDQUFDLEdBQUcsQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxDQUFDO3FCQUNsRjtnQkFDTCxDQUFDLENBQUMsQ0FBQztnQkFDSCxFQUFFLENBQUMsZ0JBQWdCLENBQUMsVUFBVSxFQUFFLENBQUMsQ0FBQyxFQUFFLEVBQUU7b0JBQ2xDLElBQUksYUFBYSxHQUE2QixDQUFDLENBQUMsTUFBTSxDQUFDO29CQUN2RCxJQUFJLGVBQWUsR0FBVyxhQUFhLENBQUMsWUFBWSxDQUFDLElBQUksQ0FBQyxDQUFDLE9BQU8sQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsYUFBYSxDQUFDLFlBQVksQ0FBQyxJQUFJLENBQUMsQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLGFBQWEsQ0FBQyxZQUFZLENBQUMsSUFBSSxDQUFDLENBQUM7b0JBQzFLLElBQUksZ0JBQWdCLEdBQUcsSUFBSSxDQUFDLE9BQU8sQ0FBQyxtQkFBbUIsQ0FBQyxJQUFJLENBQUMsWUFBWSxFQUFFLGFBQWEsQ0FBQyxZQUFZLENBQUMsSUFBSSxDQUFDLEVBQUUsSUFBSSxDQUFDLENBQUM7b0JBQ25ILElBQUksSUFBSSxDQUFDLG9CQUFvQixDQUFDLGVBQWUsQ0FBQyxFQUFFO3dCQUM1QyxnQkFBZ0IsQ0FBQyxLQUFLLENBQUMsTUFBTSxFQUFFLENBQUMsRUFBRSxFQUFFLEVBQUU7NEJBQ2xDLE9BQU8sSUFBSSxDQUFDLGdCQUFnQixDQUFDLEVBQUUsQ0FBQyxDQUFDO3dCQUNyQyxDQUFDLENBQUMsQ0FBQztxQkFDTjtnQkFDTCxDQUFDLENBQUMsQ0FBQztnQkFDSCxFQUFFLENBQUMsZ0JBQWdCLENBQUMsT0FBTyxFQUFFLENBQUMsQ0FBQyxFQUFFLEVBQUU7b0JBQy9CLElBQUksSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsS0FBSyxTQUFTLEVBQUU7d0JBQ2pDLElBQUksYUFBYSxHQUE2QixDQUFDLENBQUMsTUFBTSxDQUFDO3dCQUN2RCxJQUFJLGVBQWUsR0FBVyxJQUFJLENBQUMsT0FBTyxDQUFDLGtCQUFrQixDQUFDLGFBQWEsQ0FBQyxDQUFDO3dCQUM3RSxJQUFJLElBQUksQ0FBQyxvQkFBb0IsQ0FBQyxlQUFlLENBQUMsRUFBRTs0QkFDNUMsSUFBSSxDQUFDLFlBQVksQ0FBQyxJQUFJLENBQUMsTUFBTSxFQUFFLEtBQUssQ0FBQyxDQUFDO3lCQUN6QztxQkFDSjtnQkFDTCxDQUFDLENBQUMsQ0FBQztZQUNQLENBQUMsQ0FBQyxDQUFDO1lBRUgsSUFBSSxXQUFXLEdBQUc7Z0JBQ2QsWUFBWSxFQUFFLElBQUksQ0FBQyxpQkFBaUI7Z0JBQ3BDLFlBQVksRUFBRSxJQUFJLENBQUMsY0FBYyxDQUFDLElBQUk7YUFDekMsQ0FBQztZQUNGLElBQUksSUFBSSxDQUFDLE1BQU0sQ0FBQyxTQUFTLElBQUksU0FBUyxJQUFJLElBQUksQ0FBQyxNQUFNLENBQUMsU0FBUyxDQUFDLFdBQVcsSUFBSSxTQUFTLEVBQUU7Z0JBQ3RGLFdBQVcsQ0FBQyxXQUFXLENBQUMsR0FBRztvQkFDdkIsV0FBVyxFQUFFLENBQUMsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxJQUFJLENBQUMsb0JBQW9CLENBQUMsQ0FBQyxDQUFDO29CQUNoRCxVQUFVLEVBQUUsR0FBRyxFQUFFLENBQUMsSUFBSSxDQUFDLHVCQUF1QixFQUFFO2lCQUNuRCxDQUFDO2FBQ0w7WUFDRCxjQUFjO1lBQ2QsSUFBSSxJQUFJLENBQUMsY0FBYyxDQUFDLElBQUksSUFBSSxTQUFTLEVBQUU7Z0JBQ3ZDLEtBQUssQ0FBQyxnQkFBZ0IsQ0FBQyxPQUFPLEVBQUUsV0FBVyxDQUFDLENBQUM7YUFDaEQ7U0FDSjtJQUNMLENBQUM7SUFFTyxnQkFBZ0IsQ0FBQyxNQUFXO1FBQ2hDLElBQUksSUFBSSxDQUFDLGNBQWMsSUFBSSxTQUFTLElBQUksSUFBSSxDQUFDLGNBQWMsQ0FBQyxJQUFJLElBQUksU0FBUztZQUFFLE9BQU8sU0FBUyxDQUFDO1FBRWhHLElBQUksU0FBUyxHQUFHLElBQUksQ0FBQyxlQUFlLENBQUMsTUFBTSxDQUFDLFVBQVUsQ0FBQyxHQUFHLENBQUMsQ0FBQyxLQUFLLENBQUM7UUFFbEUsSUFBSSxJQUFJLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxLQUFLLFFBQVEsSUFBSSxJQUFJLENBQUMsTUFBTSxDQUFDLFNBQVMsSUFBSSxJQUFJLENBQUMsTUFBTSxDQUFDLFNBQVMsQ0FBQyxRQUFRLEVBQUU7WUFDM0YsT0FBTyxJQUFJLENBQUMsTUFBTSxDQUFDLFNBQVMsQ0FBQyxRQUFRLENBQUM7U0FDekM7UUFFRCxJQUFJLFNBQVMsSUFBSSxJQUFJLElBQUksU0FBUyxJQUFJLEVBQUU7WUFBRSxPQUFPLElBQUksQ0FBQyxNQUFNLENBQUMsV0FBVyxDQUFDLEdBQUcsQ0FBQyxTQUFTLElBQUksY0FBYyxDQUFDO1FBRXpHLElBQUksSUFBSSxDQUFDLE1BQU0sQ0FBQyxTQUFTLElBQUksU0FBUyxJQUFJLElBQUksQ0FBQyxNQUFNLENBQUMsU0FBUyxDQUFDLFdBQVcsSUFBSSxTQUFTLEVBQUU7WUFDdEYsT0FBTyxJQUFJLENBQUMsbUJBQW1CLENBQUMsU0FBUyxDQUFDLENBQUM7U0FDOUM7UUFFRCxJQUFJLElBQUksQ0FBQyxxQkFBcUIsSUFBSSxJQUFJLEVBQUU7WUFDcEMsS0FBSyxJQUFJLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxHQUFHLElBQUksQ0FBQyxNQUFNLENBQUMsU0FBUyxDQUFDLFdBQVcsQ0FBQyxNQUFNLEVBQUUsQ0FBQyxFQUFFLEVBQUU7Z0JBQy9ELElBQUksSUFBSSxDQUFDLE9BQU8sQ0FBQyxtQkFBbUIsQ0FBQyxNQUFNLENBQUMsU0FBUyxDQUFDLEVBQUUsSUFBSSxDQUFDLE1BQU0sQ0FBQyxTQUFTLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksRUFBRSxJQUFJLENBQUMsTUFBTSxDQUFDLFNBQVMsQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUU7b0JBQ3pJLElBQUksSUFBSSxDQUFDLE1BQU0sQ0FBQyxJQUFJLEdBQUcsQ0FBQyxDQUFDLElBQUksSUFBSSxDQUFDLE1BQU0sQ0FBQyxJQUFJLEdBQUcsQ0FBQyxDQUFDLENBQUMsUUFBUSxJQUFJLElBQUksRUFBRTt3QkFDakUsT0FBTyxTQUFTLENBQUM7cUJBQ3BCO29CQUNELE9BQU8sSUFBSSxDQUFDLE1BQU0sQ0FBQyxTQUFTLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQztpQkFDckQ7cUJBQU0sSUFBSSxDQUFDLElBQUksSUFBSSxDQUFDLE1BQU0sQ0FBQyxTQUFTLENBQUMsV0FBVyxDQUFDLE1BQU0sRUFBRTtvQkFDdEQsT0FBTyxJQUFJLENBQUMsTUFBTSxDQUFDLFNBQVMsQ0FBQyxRQUFRLENBQUM7aUJBQ3pDO2FBQ0o7U0FDSjtRQUVELElBQUksSUFBSSxDQUFDLFlBQVksSUFBSSxLQUFLO1lBQUUsT0FBTyxJQUFJLENBQUMsYUFBYSxDQUFDLEtBQUssQ0FBQztRQUVoRSxPQUFPLFNBQVMsQ0FBQztJQUNyQixDQUFDO0lBRU8sWUFBWSxDQUFDLE1BQWMsRUFBRSxLQUFhO1FBQzlDLElBQUksTUFBTSxHQUFHLE1BQU0sQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsQ0FBQztRQUM1QyxJQUFJLFVBQVUsR0FBVyxDQUFDLEVBQUUsUUFBZ0IsQ0FBQztRQUM3QyxJQUFJLFFBQWdCLENBQUM7UUFDckIsS0FBSyxJQUFJLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxHQUFHLE1BQU0sQ0FBQyxNQUFNLEVBQUUsQ0FBQyxFQUFFLEVBQUU7WUFDcEMsSUFBSSxNQUFNLENBQUMsQ0FBQyxDQUFDLEtBQUssTUFBTTtnQkFBRSxVQUFVLEdBQUcsQ0FBQyxDQUFDO1NBQzVDO1FBQ0QsSUFBSSxLQUFLLEtBQUssS0FBSyxFQUFFO1lBQ2pCLElBQUksVUFBVSxHQUFHLENBQUMsSUFBSSxNQUFNLENBQUMsTUFBTTtnQkFBRSxRQUFRLEdBQUcsVUFBVSxHQUFHLENBQUMsQ0FBQztTQUNsRTthQUFNO1lBQ0gsSUFBSSxVQUFVLEdBQUcsQ0FBQyxJQUFJLENBQUM7Z0JBQUUsUUFBUSxHQUFHLFVBQVUsR0FBRyxDQUFDLENBQUM7U0FDdEQ7UUFDRCxJQUFJLFFBQVEsS0FBSyxTQUFTLEVBQUU7WUFDeEIsUUFBUSxHQUFHLE1BQU0sQ0FBQyxRQUFRLENBQUMsQ0FBQztZQUM1QixJQUFJLElBQUksQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLFFBQVEsQ0FBQyxJQUFJLFNBQVMsRUFBRTtnQkFDMUMsSUFBSSxPQUFPLElBQUksQ0FBQyxTQUFTLEtBQUssV0FBVyxFQUFFO29CQUFFLElBQUksQ0FBQyxTQUFTLENBQUMsTUFBTSxFQUFFLENBQUM7aUJBQUU7Z0JBQ3ZFLElBQUksQ0FBQyxNQUFNLEdBQUcsUUFBUSxDQUFDO2dCQUN2QixJQUFJLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxHQUFHLElBQUksQ0FBQyxNQUFNLENBQUM7Z0JBQ3BDLElBQUksSUFBSSxDQUFDLE1BQU0sQ0FBQyxTQUFTLElBQUksU0FBUztvQkFBRSxJQUFJLENBQUMsdUNBQXVDLEVBQUUsQ0FBQztnQkFDdkYsSUFBSSxDQUFDLGdCQUFnQixFQUFFLENBQUM7Z0JBQ3hCLElBQUksSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsS0FBSyxNQUFNLEVBQUU7b0JBQzlCLElBQUksQ0FBQyxZQUFZLEVBQUUsQ0FBQztpQkFDdkI7O29CQUNJLElBQUksQ0FBQyxlQUFlLEVBQUUsQ0FBQzthQUMvQjtTQUNKO1FBQ0QsdUNBQXVDO1FBQ3ZDLG9CQUFvQjtRQUNwQiw2Q0FBNkM7UUFDN0MsNENBQTRDO1FBQzVDLEtBQUs7UUFDTCxtR0FBbUc7UUFDbkcsb0xBQW9MO0lBRXhMLENBQUM7SUFFTyxZQUFZO1FBQ2hCLDZCQUE2QjtRQUM3QixJQUFJLE1BQU0sR0FBYSxHQUFHLEVBQUU7WUFDeEIsTUFBTSxTQUFTLEdBQUcsRUFBRSxDQUFDLEtBQUssQ0FBQyxTQUFTLENBQUM7WUFDckMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsV0FBVyxFQUFFLFlBQVksR0FBRyxTQUFTLENBQUMsQ0FBQyxHQUFHLEdBQUcsR0FBRyxTQUFTLENBQUMsQ0FBQyxHQUFHLFVBQVUsR0FBRyxTQUFTLENBQUMsQ0FBQyxHQUFHLEdBQUcsQ0FBQyxDQUFDO1FBQ3RILENBQUMsQ0FBQztRQUNGLElBQUksSUFBSSxHQUFHLEVBQUUsQ0FBQyxJQUFJLEVBQUUsQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsTUFBTSxFQUFFLE1BQU0sQ0FBQyxDQUFDO1FBRTVELElBQUksQ0FBQyxTQUFTLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLENBQUMsT0FBTyxDQUFDLFlBQVksRUFBRSxJQUFJLENBQUMsQ0FBQztRQUNwRSxJQUFJLE9BQU8sR0FBRyxJQUFJLENBQUMsU0FBUyxDQUFDLFNBQVMsQ0FBQyxHQUFHLENBQUM7YUFDdEMsSUFBSSxDQUFDLENBQUMsUUFBUSxFQUFFLFNBQVMsQ0FBQyxDQUFDO2FBQzNCLEtBQUssRUFBRSxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUM7YUFDbkIsSUFBSSxDQUFDLElBQUksRUFBRSxVQUFTLENBQUMsSUFBSSxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztZQUN0QyxvR0FBb0c7YUFDbkcsSUFBSSxDQUFDLFdBQVcsRUFBRSxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRSxHQUFHLE9BQU8sZUFBZSxHQUFHLENBQUMsRUFBRSxHQUFHLENBQUMsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxDQUFDLEdBQUcsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDO2FBQ2hGLEtBQUssQ0FBQyxRQUFRLEVBQUUsU0FBUyxDQUFDO2FBQzFCLEVBQUUsQ0FBQyxPQUFPLEVBQUUsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLEVBQUUsR0FBRyxJQUFJLENBQUMsVUFBVSxDQUFDLENBQUMsRUFBRSxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO1FBQzFELE9BQU8sQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDO2FBQ2pCLElBQUksQ0FBQyxPQUFPLEVBQUUsTUFBTSxDQUFDO2FBQ3JCLElBQUksQ0FBQyxRQUFRLEVBQUUsTUFBTSxDQUFDO2FBQ3RCLElBQUksQ0FBQyxJQUFJLEVBQUUsQ0FBQyxDQUFDO2FBQ2IsSUFBSSxDQUFDLElBQUksRUFBRSxDQUFDLENBQUM7YUFDYixLQUFLLENBQUMsU0FBUyxFQUFFLENBQUMsQ0FBQzthQUNuQixLQUFLLENBQUMsTUFBTSxFQUFFLE1BQU0sQ0FBQzthQUNyQixLQUFLLENBQUMsUUFBUSxFQUFFLE1BQU0sQ0FBQzthQUN2QixLQUFLLENBQUMsY0FBYyxFQUFFLEdBQUcsQ0FBQyxDQUFDO1FBQ2hDLE9BQU8sQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDO2FBQ2pCLElBQUksQ0FBQyxHQUFHLEVBQUUsRUFBRSxDQUFDO2FBQ2IsSUFBSSxDQUFDLEdBQUcsRUFBRSxFQUFFLENBQUM7YUFDYixJQUFJLENBQUMsSUFBSSxFQUFFLE9BQU8sQ0FBQzthQUNuQixJQUFJLENBQUMsYUFBYSxFQUFFLFFBQVEsQ0FBQzthQUM3QixLQUFLLENBQUMsV0FBVyxFQUFFLE1BQU0sQ0FBQzthQUMxQixLQUFLLENBQUMsYUFBYSxFQUFFLE1BQU0sQ0FBQzthQUM1QixJQUFJLENBQUMsVUFBUyxDQUFDLEVBQUUsQ0FBQyxJQUFJLE9BQU8sQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztRQUV6RCxJQUFJLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQztJQUM5QixDQUFDO0lBRU8sVUFBVSxDQUFDLFVBQWtCLEVBQUUsS0FBSztRQUN4QyxJQUFJLE1BQU0sR0FBRyxVQUFVLElBQUksUUFBUSxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQztRQUNoRCxLQUFLLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxTQUFTLEVBQUUsTUFBTSxDQUFDLENBQUM7SUFDMUMsQ0FBQztJQUVPLFlBQVk7UUFDaEIsNEJBQTRCO1FBQzVCLElBQUksT0FBTyxJQUFJLENBQUMsUUFBUSxLQUFLLFdBQVcsRUFBRTtZQUN0QyxJQUFJLENBQUMsUUFBUSxDQUFDLE1BQU0sRUFBRSxDQUFDO1lBQ3ZCLElBQUksQ0FBQyxRQUFRLEdBQUcsU0FBUyxDQUFDO1NBQzdCO1FBQ0QsVUFBVSxDQUFDLEdBQUcsRUFBRTtZQUNaLElBQUksSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsS0FBSyxNQUFNLEVBQUU7Z0JBQzlCLElBQUksQ0FBQyxRQUFRLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLENBQUMsT0FBTyxDQUFDLFdBQVcsRUFBRSxJQUFJLENBQUMsQ0FBQztnQkFDbEUsSUFBSSx3QkFBd0IsR0FBVyxFQUFFLENBQUM7Z0JBQzFDLElBQUksSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsS0FBSyxNQUFNLEVBQUU7b0JBQzlCLHdCQUF3QixHQUFHLFlBQVksR0FBRyxDQUFDLElBQUksQ0FBQyxNQUFNLEdBQUcsR0FBRyxDQUFDLEdBQUcsR0FBRyxHQUFHLENBQUMsSUFBSSxDQUFDLE9BQU8sR0FBRyxDQUFDLENBQUMsR0FBRyxHQUFHLENBQUM7aUJBQ2xHO3FCQUFNO29CQUNILHdCQUF3QixHQUFHLFlBQVksR0FBRyxDQUFDLElBQUksQ0FBQyxNQUFNLEdBQUcsR0FBRyxHQUFHLFFBQVEsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLElBQUksRUFBRSxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsQ0FBQyxHQUFHLEdBQUcsR0FBRyxDQUFDLElBQUksQ0FBQyxPQUFPLEdBQUcsQ0FBQyxHQUFHLFFBQVEsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLElBQUksRUFBRSxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FBQyxHQUFHLEdBQUcsQ0FBQztpQkFDN0w7Z0JBQ0QsSUFBSSxPQUFPLEdBQUcsSUFBSSxDQUFDLFFBQVEsQ0FBQyxTQUFTLENBQUMsR0FBRyxDQUFDO3FCQUNyQyxJQUFJLENBQUMsQ0FBQyxTQUFTLENBQUMsQ0FBQztxQkFDakIsS0FBSyxFQUFFLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQztxQkFDbkIsSUFBSSxDQUFDLElBQUksRUFBRSxVQUFTLENBQUMsSUFBSSxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztxQkFDckMsSUFBSSxDQUFDLFdBQVcsRUFBRSxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRSxHQUFHLE9BQU8sd0JBQXdCLENBQUMsQ0FBQyxDQUFDLENBQUM7cUJBQ2pFLEtBQUssQ0FBQyxRQUFRLEVBQUUsU0FBUyxDQUFDO3FCQUMxQixLQUFLLENBQUMsZ0JBQWdCLEVBQUUsU0FBUyxDQUFDO3FCQUNsQyxFQUFFLENBQUMsT0FBTyxFQUFFLENBQUMsQ0FBQyxFQUFFLEVBQUUsR0FBRyxJQUFJLENBQUMsWUFBWSxDQUFDLElBQUksQ0FBQyxNQUFNLEVBQUUsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztnQkFDdEUsT0FBTyxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUM7cUJBQ2pCLElBQUksQ0FBQyxPQUFPLEVBQUUsTUFBTSxDQUFDO3FCQUNyQixJQUFJLENBQUMsUUFBUSxFQUFFLE1BQU0sQ0FBQztxQkFDdEIsS0FBSyxDQUFDLE1BQU0sRUFBRSxvQkFBb0IsQ0FBQztxQkFDbkMsS0FBSyxDQUFDLFFBQVEsRUFBRSxvQkFBb0IsQ0FBQztxQkFDckMsS0FBSyxDQUFDLGNBQWMsRUFBRSxHQUFHLENBQUMsQ0FBQztnQkFDaEMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUM7cUJBQ2pCLElBQUksQ0FBQyxHQUFHLEVBQUUsRUFBRSxDQUFDO3FCQUNiLElBQUksQ0FBQyxHQUFHLEVBQUUsRUFBRSxDQUFDO3FCQUNiLElBQUksQ0FBQyxJQUFJLEVBQUUsT0FBTyxDQUFDO3FCQUNuQixJQUFJLENBQUMsYUFBYSxFQUFFLFFBQVEsQ0FBQztxQkFDN0IsS0FBSyxDQUFDLFdBQVcsRUFBRSxNQUFNLENBQUM7cUJBQzFCLEtBQUssQ0FBQyxhQUFhLEVBQUUsUUFBUSxDQUFDO3FCQUM5QixJQUFJLENBQUMsVUFBUyxDQUFDLEVBQUUsQ0FBQyxJQUFJLE9BQU8sSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQzthQUMxRTtpQkFBTTtnQkFDSCxJQUFJLENBQUMsUUFBUSxHQUFHLElBQUksQ0FBQyxZQUFZLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxDQUFBO2dCQUMvQyxJQUFJLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxPQUFPLEVBQUUsMEJBQTBCLENBQUMsQ0FBQTtnQkFDdkQsSUFBSSxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsVUFBUyxDQUFDLEVBQUUsQ0FBQyxJQUFJLE9BQU8sSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQTtnQkFDL0UsSUFBSSxDQUFDLFFBQVEsQ0FBQyxFQUFFLENBQUMsT0FBTyxFQUFFLENBQUMsQ0FBQyxFQUFFLEVBQUUsR0FBRyxJQUFJLENBQUMsWUFBWSxDQUFDLElBQUksQ0FBQyxNQUFNLEVBQUUsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQzthQUNsRjtRQUNMLENBQUMsQ0FBQyxDQUFBO0lBQ04sQ0FBQztJQUVPLGFBQWE7UUFDakIsSUFBSSxpQkFBaUIsR0FBRyxJQUFJLENBQUMsa0JBQWtCLEVBQUUsQ0FBQztRQUNsRCxJQUFJLGlCQUFpQixJQUFJLElBQUksRUFBRTtZQUMzQixJQUFJLE9BQU8sSUFBSSxDQUFDLFFBQVEsS0FBSyxXQUFXO2dCQUFFLElBQUksQ0FBQyxZQUFZLEVBQUUsQ0FBQztTQUNqRTthQUNJO1lBQ0QsSUFBSSxPQUFPLElBQUksQ0FBQyxRQUFRLEtBQUssV0FBVyxFQUFFO2dCQUN0QyxJQUFJLENBQUMsUUFBUSxDQUFDLE1BQU0sRUFBRSxDQUFDO2dCQUN2QixJQUFJLENBQUMsUUFBUSxHQUFHLFNBQVMsQ0FBQzthQUM3QjtTQUNKO0lBQ0wsQ0FBQztJQUVPLGtCQUFrQjtRQUN0QixJQUFJLFlBQXFCLENBQUM7UUFDMUIsSUFBSSxZQUFZLEdBQUcsSUFBSSxDQUFDLGFBQWEsQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxhQUFhLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsYUFBYSxDQUFDO1FBQ2pILElBQUksSUFBSSxDQUFDLE1BQU0sQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxDQUFDLEVBQUU7WUFDaEMsWUFBWSxHQUFHLFFBQVEsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLFlBQVksQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUM7U0FDckY7YUFBTTtZQUNILFlBQVksR0FBRyxRQUFRLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxJQUFJLFlBQVksQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUM7U0FDdkU7UUFDRCxPQUFPLFlBQVksQ0FBQztJQUN4QixDQUFDO0lBSU8sZUFBZSxDQUFDLFNBQVM7UUFDN0IsSUFBSSxTQUFTLEdBQUc7WUFDWixJQUFJLEVBQUUsRUFBRTtZQUNSLE1BQU0sRUFBRSxFQUFFO1lBQ1YsV0FBVyxFQUFFLEVBQUU7WUFDZixPQUFPLEVBQUUsRUFBRTtTQUNkLENBQUM7UUFDRixLQUFLLElBQUksQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLEdBQUcsSUFBSSxDQUFDLGNBQWMsQ0FBQyxJQUFJLENBQUMsTUFBTSxFQUFFLENBQUMsRUFBRSxFQUFFO1lBQ3RELElBQUksSUFBSSxDQUFDLGNBQWMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxJQUFJLFNBQVMsRUFBRTtnQkFDOUMsU0FBUyxDQUFDLEVBQUUsR0FBRyxJQUFJLENBQUMsY0FBYyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUM7Z0JBQy9DLFNBQVMsQ0FBQyxJQUFJLEdBQUcsSUFBSSxDQUFDLGNBQWMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDO2dCQUNwRCxTQUFTLENBQUMsU0FBUyxHQUFHLElBQUksQ0FBQyxjQUFjLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQztnQkFDNUQsU0FBUyxDQUFDLEtBQUssR0FBRyxJQUFJLENBQUMsY0FBYyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUM7Z0JBQ3BELE1BQU07YUFDVDtTQUNKO1FBQ0QsT0FBTyxTQUFTLENBQUM7SUFDckIsQ0FBQztJQUVPLGFBQWEsQ0FBQyxVQUFnQjtRQUNsQyxJQUFJLGFBQWEsR0FBRyxVQUFVLENBQUMsQ0FBQyxDQUFDLFVBQVUsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQztRQUMxRCxJQUFJLGFBQWEsR0FBRyxNQUFNLENBQUMsSUFBSSxDQUFDLGFBQWEsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUMsRUFBRSxHQUFHLE9BQU8sYUFBYSxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7UUFDMUYsSUFBSSxhQUFhLEdBQUcsRUFBRSxDQUFDO1FBQ3ZCLEtBQUssSUFBSSxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsR0FBRyxhQUFhLENBQUMsTUFBTSxFQUFFLENBQUMsRUFBRSxFQUFFO1lBQzNDLEtBQUssSUFBSSxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsR0FBRyxJQUFJLENBQUMsV0FBVyxDQUFDLE1BQU0sRUFBRSxDQUFDLEVBQUUsRUFBRTtnQkFDOUMsSUFBSSxhQUFhLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxJQUFJLEtBQUssSUFBSSxJQUFJLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsSUFBSSxhQUFhLENBQUMsQ0FBQyxDQUFDLENBQUMsV0FBVyxFQUFFO29CQUM5RixhQUFhLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztvQkFDeEMsTUFBTTtpQkFDVDthQUNKO1NBQ0o7UUFDRCxJQUFJLENBQUMsWUFBWSxHQUFHLGFBQWEsQ0FBQyxNQUFNLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQztRQUM3RCxJQUFJLGFBQWEsQ0FBQyxNQUFNLElBQUksQ0FBQyxFQUFFO1lBQUUsSUFBSSxDQUFDLGNBQWMsR0FBRyxhQUFhLENBQUMsYUFBYSxDQUFDLE1BQU0sR0FBRyxDQUFDLENBQUMsQ0FBQztTQUFFO0lBQ3JHLENBQUM7SUFFTyx1Q0FBdUM7UUFDM0MsSUFBSSxVQUFVLENBQUM7UUFDZixJQUFJLElBQUksQ0FBQyxrQkFBa0IsRUFBRSxJQUFJLElBQUksRUFBRTtZQUNuQyxVQUFVLEdBQUcsSUFBSSxDQUFDLFNBQVMsQ0FBQyxnQkFBZ0IsQ0FBQyxJQUFJLENBQUMsTUFBTSxFQUFFLENBQUMsSUFBSSxDQUFDLGNBQWMsQ0FBQyxFQUFFLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQztTQUNqRzthQUFNO1lBQ0gsVUFBVSxHQUFHLElBQUksQ0FBQyxTQUFTLENBQUMsZ0JBQWdCLENBQUMsSUFBSSxDQUFDLE1BQU0sRUFBRSxJQUFJLENBQUMsV0FBVyxFQUFFLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQztZQUN6RixJQUFJLENBQUMsYUFBYSxDQUFDLFVBQVUsQ0FBQyxDQUFDO1NBQ2xDO1FBQ0QsSUFBSSxDQUFDLFlBQVksQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLENBQUM7SUFDdkMsQ0FBQztJQUVPLGdCQUFnQjtRQUNwQiwrRUFBK0U7UUFDL0UsSUFBSSxhQUFhLEdBQUcsTUFBTSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDO1FBQ3BGLElBQUksSUFBSSxDQUFDLGNBQWMsSUFBSSxTQUFTLEVBQUU7WUFDbEMsS0FBSyxJQUFJLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxHQUFHLGFBQWEsQ0FBQyxNQUFNLEVBQUUsQ0FBQyxFQUFFLEVBQUU7Z0JBQzNDLElBQUksSUFBSSxDQUFDLGNBQWMsQ0FBQyxFQUFFLElBQUksYUFBYSxDQUFDLENBQUMsQ0FBQyxDQUFDLFdBQVcsRUFBRTtvQkFDeEQsSUFBSSxDQUFDLGFBQWEsR0FBRyxJQUFJLENBQUMsVUFBVSxDQUFDLGFBQWEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQztvQkFDMUQseURBQXlEO29CQUN6RCxNQUFNO2lCQUNUO2FBQ0o7U0FDSjtJQUNMLENBQUM7SUFFTyxnQkFBZ0I7UUFDcEIsc0JBQXNCO1FBQ3RCLElBQUksYUFBYSxHQUFHLE1BQU0sQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQztRQUNwRiwrRUFBK0U7UUFDL0UsS0FBSyxJQUFJLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxHQUFHLGFBQWEsQ0FBQyxNQUFNLEVBQUUsQ0FBQyxFQUFFLEVBQUU7WUFDM0MsS0FBSyxJQUFJLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxHQUFHLElBQUksQ0FBQyxXQUFXLENBQUMsTUFBTSxFQUFFLENBQUMsRUFBRSxFQUFFO2dCQUM5QyxJQUFJLElBQUksQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxJQUFJLGFBQWEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxXQUFXLEVBQUU7b0JBQ3hELElBQUksQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxHQUFHLGFBQWEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUM7b0JBQ25ELE1BQU07aUJBQ1Q7YUFDSjtTQUNKO0lBQ0wsQ0FBQztJQUVPLGdCQUFnQjtRQUNwQix5REFBeUQ7UUFDekQsSUFBSSxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsV0FBVyxFQUFFO1lBQzFCLElBQUksQ0FBQyxxQkFBcUIsR0FBRyxLQUFLLENBQUM7WUFDbkMsSUFBSSxJQUFJLENBQUMsTUFBTSxDQUFDLFNBQVMsSUFBSSxTQUFTLEVBQUU7Z0JBQ3BDLElBQUksSUFBSSxDQUFDLE1BQU0sQ0FBQyxTQUFTLENBQUMsV0FBVyxJQUFJLElBQUksQ0FBQyxNQUFNLENBQUMsU0FBUyxDQUFDLFdBQVcsQ0FBQyxNQUFNLEtBQUssQ0FBQyxFQUFFO29CQUNyRixJQUFJLENBQUMscUJBQXFCLEdBQUcsSUFBSSxDQUFDO29CQUNsQyxJQUFJLENBQUMsTUFBTSxHQUFHLElBQUksQ0FBQyxTQUFTLENBQUMscUJBQXFCLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxTQUFTLENBQUMsV0FBVyxFQUFFLElBQUksQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLGFBQWEsRUFBRSxJQUFJLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxXQUFXLEVBQUUsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDO29CQUNySyxJQUFJLENBQUMsWUFBWSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUM7aUJBQ3ZDO3FCQUFNO29CQUNILElBQUksQ0FBQyxZQUFZLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxDQUFDO2lCQUM5QjthQUNKO2lCQUFNO2dCQUNILHlCQUF5QjtnQkFDekIsSUFBSSxDQUFDLE1BQU0sR0FBRyxJQUFJLENBQUMsU0FBUyxDQUFDLGdCQUFnQixDQUFDLElBQUksQ0FBQyxNQUFNLEVBQUUsSUFBSSxDQUFDLFdBQVcsRUFBRSxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUM7Z0JBQzFGLElBQUksQ0FBQyxZQUFZLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQzthQUN2QztTQUNKO2FBQU07WUFDSCxtQ0FBbUM7WUFDbkMsSUFBSSxDQUFDLHFCQUFxQixHQUFHLEtBQUssQ0FBQztZQUNuQyxJQUFJLElBQUksQ0FBQyxNQUFNLENBQUMsU0FBUyxJQUFJLFNBQVMsRUFBRTtnQkFDcEMsSUFBSSxJQUFJLENBQUMsTUFBTSxDQUFDLFNBQVMsQ0FBQyxXQUFXLElBQUksSUFBSSxDQUFDLE1BQU0sQ0FBQyxTQUFTLENBQUMsV0FBVyxDQUFDLE1BQU0sS0FBSyxDQUFDLEVBQUU7b0JBQ3JGLElBQUksQ0FBQyxxQkFBcUIsR0FBRyxJQUFJLENBQUM7b0JBQ2xDLElBQUksQ0FBQyxZQUFZLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQztpQkFDdkM7cUJBQU07b0JBQ0gsSUFBSSxDQUFDLFlBQVksQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDLENBQUM7aUJBQzlCO2FBQ0o7aUJBQU07Z0JBQ0gsSUFBSSxDQUFDLFlBQVksQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDO2FBQ3ZDO1NBQ0o7SUFDTCxDQUFDO0lBRU8sb0JBQW9CLENBQUMsTUFBYztRQUN2QyxJQUFJLElBQUksR0FBVyxJQUFJLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO1FBQ3ZDLElBQUksQ0FBQyxPQUFPLENBQUMseUJBQXlCLENBQUMsSUFBSSxHQUFHLElBQUksQ0FBQyxPQUFPLENBQUMsVUFBVSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUM7SUFDbkYsQ0FBQztJQUVPLHVCQUF1QjtRQUMzQixJQUFJLG9CQUFvQixHQUFXLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUM7UUFDM0QsSUFBSSxDQUFDLE9BQU8sQ0FBQyx5QkFBeUIsQ0FBQyxvQkFBb0IsQ0FBQyxDQUFDO0lBQ2pFLENBQUM7SUFFTyxvQkFBb0IsQ0FBQyxNQUFXO1FBQ3BDLElBQUksSUFBSSxDQUFDLGNBQWMsQ0FBQyxJQUFJLElBQUksU0FBUyxFQUFFO1lBQ3ZDLE9BQU8sS0FBSyxDQUFDO1NBQ2hCO2FBQU07WUFDSCxJQUFJLFNBQVMsR0FBRyxJQUFJLENBQUMsZUFBZSxDQUFDLE1BQU0sQ0FBQyxDQUFDLEtBQUssQ0FBQztZQUNuRCxJQUFJLFNBQVMsSUFBSSxTQUFTO2dCQUFFLE9BQU8sS0FBSyxDQUFDO2lCQUNwQyxJQUFJLFNBQVMsSUFBSSxJQUFJLElBQUksU0FBUyxJQUFJLEVBQUU7Z0JBQUUsT0FBTyxJQUFJLENBQUM7O2dCQUN0RCxPQUFPLEtBQUssQ0FBQztTQUNyQjtJQUNMLENBQUM7SUFFRDs7T0FFRztJQUNLLGFBQWE7UUFDakIscUJBQXFCO1FBQ3JCLElBQUksVUFBVSxHQUFhLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxTQUFTLENBQUMsUUFBUSxFQUFFLElBQUksQ0FBQyxNQUFNLENBQUMsU0FBUyxDQUFDLFFBQVEsQ0FBQyxDQUFDO1FBQzVGLDREQUE0RDtRQUM1RCxJQUFJLFdBQVcsR0FBYSxDQUFDLENBQUMsRUFBRSxHQUFHLENBQUMsQ0FBQztRQUNyQywwQkFBMEI7UUFDMUIsSUFBSSxPQUFPLEdBQWEsSUFBSSxDQUFDLE9BQU8sQ0FBQyxrQkFBa0IsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLFNBQVMsQ0FBQyxHQUFHLEVBQUUsSUFBSSxDQUFDLE1BQU0sQ0FBQyxTQUFTLENBQUMsR0FBRyxDQUFDLENBQUM7UUFDOUcsSUFBSSxZQUFZLEdBQVcsT0FBTyxDQUFDLE1BQU0sR0FBRyxDQUFDLENBQUM7UUFDOUMsSUFBSSxXQUFXLEdBQWEsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLEVBQUUsT0FBTyxDQUFDLFlBQVksQ0FBQyxDQUFDLENBQUM7UUFDaEUsSUFBSSxHQUFHLEdBQUcsRUFBRSxDQUFDLEtBQUssQ0FBQyxZQUFZLENBQUMsQ0FBQztRQUNqQyxJQUFJLHVCQUF1QixHQUEyQixJQUFJLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLFVBQVUsQ0FBQztRQUUxRixxR0FBcUc7UUFDckcsSUFBSSxDQUFDLG1CQUFtQixHQUFHLElBQUksQ0FBQyxPQUFPLENBQUMsUUFBUSxDQUFDLFdBQVcsRUFBRSxVQUFVLENBQUMsQ0FBQztRQUMxRSxxSEFBcUg7UUFDckgsSUFBSSxDQUFDLE9BQU8sQ0FBQyxVQUFVLEdBQUcsSUFBSSxDQUFDLE9BQU8sQ0FBQyxRQUFRLENBQUMsV0FBVyxFQUFFLFdBQVcsQ0FBQyxDQUFDO1FBRTFFLElBQUksZUFBZSxHQUFHLEVBQUUsQ0FBQyxNQUFNLENBQUMsR0FBRyxHQUFHLElBQUksQ0FBQyxNQUFNLENBQUMsRUFBRSxHQUFHLG9DQUFvQyxDQUFDLENBQUM7UUFFN0YsSUFBSSxRQUFRLEdBQUcsZUFBZSxDQUFDLE1BQU0sQ0FBQyxXQUFXLENBQUMsQ0FBQztRQUNuRCxRQUFRLENBQUMsS0FBSyxDQUFDLFlBQVksRUFBRSxrQkFBa0IsR0FBRyx1QkFBdUIsR0FBRyxHQUFHLEdBQUcsVUFBVSxDQUFDLENBQUMsQ0FBQyxHQUFHLEdBQUcsR0FBRyxVQUFVLENBQUMsQ0FBQyxDQUFDLEdBQUcsR0FBRyxDQUFDLENBQUM7UUFFN0gsSUFBSSxDQUFDLE9BQU8sQ0FBQyxnQkFBZ0IsR0FBRyxlQUFlLENBQUMsTUFBTSxDQUFDLHlCQUF5QixDQUFDLENBQUM7UUFFbEYsUUFBUSxDQUFDLFNBQVMsQ0FBQyxxQkFBcUIsQ0FBQzthQUNwQyxJQUFJLENBQUMsR0FBRyxDQUFDO2FBQ1QsS0FBSyxFQUFFLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQzthQUNyQixJQUFJLENBQUMsT0FBTyxFQUFFLG9CQUFvQixDQUFDO2FBQ25DLElBQUksQ0FBQyxJQUFJLEVBQUUsQ0FBQyxDQUFDLEVBQUUsRUFBRSxDQUFDLE9BQU8sR0FBRyxDQUFDLENBQUM7YUFDOUIsS0FBSyxDQUFDLE9BQU8sRUFBRSxHQUFHLEdBQUcsWUFBWSxHQUFHLEdBQUcsQ0FBQyxDQUFDO1FBRTlDLGVBQWUsQ0FBQyxNQUFNLENBQUMsK0JBQStCLENBQUM7YUFDbEQsU0FBUyxDQUFDLHFCQUFxQixDQUFDO2FBQ2hDLElBQUksQ0FBQyxPQUFPLENBQUM7YUFDYixLQUFLLEVBQUUsQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDO2FBQ3JCLElBQUksQ0FBQyxPQUFPLEVBQUUsb0JBQW9CLENBQUM7YUFDbkMsSUFBSSxDQUFDLElBQUksRUFBRSxDQUFDLENBQUMsRUFBRSxFQUFFLENBQUMsT0FBTyxHQUFHLENBQUMsQ0FBQzthQUM5QixJQUFJLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQztJQUN0QixDQUFDO0lBRU8sV0FBVztRQUNmLElBQUksSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsS0FBSyxTQUFTO1lBQUUsSUFBSSxDQUFDLFlBQVksQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDLENBQUM7UUFDaEUsSUFBSSxXQUFXLEdBQVcsSUFBSSxDQUFDLE1BQU0sQ0FBQyxXQUFXLENBQUMsR0FBRyxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxXQUFXLENBQUMsR0FBRyxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDO1FBQ3hILElBQUksQ0FBQyxZQUFZLEdBQUcsSUFBSSxDQUFDLE9BQU8sQ0FBQyxlQUFlLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxTQUFTLEVBQUUsSUFBSSxDQUFDLFdBQVcsRUFBRSxXQUFXLENBQUMsQ0FBQztRQUNyRyxJQUFJLENBQUMsWUFBWSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsWUFBWSxDQUFDLGFBQWEsQ0FBQyxDQUFDO1FBQ3hELCtCQUErQjtRQUMvQixJQUFJO0lBQ1IsQ0FBQztJQUVPLFNBQVM7UUFDYixJQUFJLElBQUksQ0FBQyxNQUFNO1lBQUUsSUFBSSxDQUFDLE1BQU0sQ0FBQyxNQUFNLEVBQUUsQ0FBQztRQUN0QyxJQUFJLElBQUksQ0FBQyxTQUFTLENBQUMsV0FBVyxDQUFDLEdBQUcsQ0FBQyxJQUFJO1lBQUUsSUFBSSxDQUFDLGdCQUFnQixDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsV0FBVyxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsQ0FBQztRQUNwRyxJQUFJLENBQUMsTUFBTSxHQUFHLENBQUMsQ0FBQyxTQUFTLENBQUMsb0RBQW9ELEVBQUU7WUFDNUUsV0FBVyxFQUFFLDJFQUEyRTtZQUN4RixPQUFPLEVBQUUsRUFBRTtTQUNkLENBQUMsQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxDQUFDO1FBQzNCLElBQUksQ0FBQyxtQkFBbUIsRUFBRSxDQUFDO0lBQy9CLENBQUM7SUFFTyxnQkFBZ0IsQ0FBQyxPQUFZO1FBQ2pDLElBQUksT0FBTyxJQUFJLENBQUMsV0FBVyxLQUFLLFdBQVcsRUFBRTtZQUN6QyxPQUFPLENBQUMsWUFBWSxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFDLFVBQVUsQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFDLGFBQWEsQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFDLFdBQVcsQ0FBQyxDQUFDO1lBQ2hKLE9BQU8sQ0FBQyxZQUFZLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxXQUFXLENBQUMsZUFBZSxDQUFDLE1BQU0sRUFBRSxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFDLGVBQWUsQ0FBQyxPQUFPLEVBQUUsQ0FBQztZQUM5RyxPQUFPLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFDLFNBQVMsQ0FBQyxNQUFNLEVBQUUsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxTQUFTLENBQUMsT0FBTyxFQUFFLENBQUM7WUFDakcsT0FBTyxDQUFDLGlCQUFpQixDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFDLGVBQWUsQ0FBQyxNQUFNLEVBQUUsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxlQUFlLENBQUMsT0FBTyxFQUFFLENBQUM7U0FDdEg7SUFDTCxDQUFDO0lBRU8seUJBQXlCLENBQUMsWUFBb0I7UUFDbEQsSUFBSSxrQkFBa0IsR0FBWSxRQUFRLENBQUMsYUFBYSxDQUFDLDhCQUE4QixDQUFDLENBQUM7UUFDekYsSUFBSSxrQkFBa0IsS0FBSyxJQUFJLEVBQUU7WUFDN0IsSUFBSSxxQkFBcUIsR0FBZ0IsSUFBSSxDQUFDLE9BQU8sQ0FBQyxhQUFhLENBQUMsa0JBQWtCLEVBQUUsb0JBQW9CLENBQUMsQ0FBQztZQUM5RyxxQkFBcUIsQ0FBQyxTQUFTLEdBQUcsWUFBWSxJQUFJLFVBQVUsQ0FBQztZQUM3RCxrQkFBa0IsQ0FBQyxZQUFZLENBQUMscUJBQXFCLEVBQUUsa0JBQWtCLENBQUMsVUFBVSxDQUFDLENBQUM7U0FDekY7SUFDTCxDQUFDO0lBRU8sbUJBQW1CO1FBQ3ZCLG9FQUFvRTtRQUNwRSxJQUFJLENBQUMsTUFBTSxDQUFDLEVBQUUsQ0FBQyxXQUFXLEVBQUUsQ0FBQyxLQUFLLEVBQVEsRUFBRTtZQUN4QyxzREFBc0Q7WUFDdEQsSUFBSSxDQUFDLElBQUksQ0FBQyxhQUFhLEVBQUU7Z0JBQ3JCLElBQUksQ0FBQyxhQUFhLEdBQUcsSUFBSSxDQUFDO2dCQUMxQixJQUFJLENBQUMsaUJBQWlCLEVBQUUsQ0FBQztnQkFDekIsSUFBSSxJQUFJLENBQUMsaUJBQWlCLEdBQUcsQ0FBQyxJQUFJLElBQUksQ0FBQyxpQkFBaUIsS0FBSyxDQUFDLEVBQUU7b0JBQzVELElBQUksQ0FBQyxTQUFTLEVBQUUsQ0FBQztpQkFDcEI7Z0JBQ0QsSUFBSSxJQUFJLENBQUMsaUJBQWlCLEdBQUcsQ0FBQyxFQUFFO29CQUM1QiwyQkFBMkI7b0JBQzNCLGdJQUFnSTtpQkFDbkk7YUFDSjtRQUNMLENBQUMsQ0FBQyxDQUFDO1FBRUgsdUVBQXVFO1FBQ3ZFLElBQUksQ0FBQyxNQUFNLENBQUMsRUFBRSxDQUFDLFVBQVUsRUFBRSxHQUFTLEVBQUU7WUFDbEMsSUFBSSxDQUFDLGNBQWMsRUFBRSxDQUFDO1lBQ3RCLElBQUksSUFBSSxDQUFDLGNBQWMsS0FBSyxNQUFNLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLENBQUMsTUFBTSxFQUFFO2dCQUNoRSwrREFBK0Q7Z0JBQy9ELCtCQUErQjtnQkFDL0IsOEJBQThCO2dCQUM5QixJQUFJLENBQUMsV0FBVyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQztnQkFFN0IsaUJBQWlCO2dCQUNqQiw4QkFBOEI7Z0JBQzlCLElBQUksQ0FBQyxjQUFjLEdBQUcsQ0FBQyxDQUFDO2FBQzNCO1FBQ0wsQ0FBQyxDQUFDLENBQUM7SUFDUCxDQUFDO0lBRU8saUJBQWlCLENBQUMsT0FBZTtRQUNyQyxPQUFPLElBQUksQ0FBQyxjQUFjLENBQUMsY0FBYyxDQUFDLE9BQU8sQ0FBQyxDQUFDO0lBQ3ZELENBQUM7OztZQXY5QkosU0FBUyxTQUFDO2dCQUNQLFFBQVEsRUFBRSxjQUFjO2dCQUN4QixRQUFRLEVBQUU7OztLQUdUO2dCQUNELGFBQWEsRUFBRSxpQkFBaUIsQ0FBQyxJQUFJO2dCQUNyQyxTQUFTLEVBQUUsQ0FBQyxXQUFXLEVBQUUsWUFBWSxFQUFFLGFBQWEsQ0FBQztnQkFDckQsSUFBSSxFQUFFO29CQUNGLE9BQU8sRUFBRSxlQUFlO2lCQUUzQjthQUNKOzs7WUF6QkcsVUFBVTtZQUlMLFdBQVc7WUFDWCxZQUFZO1lBQ1osYUFBYTs7O21CQWdEakIsS0FBSzt3QkFDTCxLQUFLLFNBQUMsUUFBUTtxQkFDZCxLQUFLO2tCQUNMLEtBQUs7MkJBQ0wsTUFBTTt5QkFDTixNQUFNOzJCQUNOLE1BQU07MEJBQ04sTUFBTSIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7XHJcbiAgICBDb21wb25lbnQsXHJcbiAgICBWaWV3RW5jYXBzdWxhdGlvbixcclxuICAgIElucHV0LFxyXG4gICAgT3V0cHV0LFxyXG4gICAgRXZlbnRFbWl0dGVyLFxyXG4gICAgT25Jbml0LFxyXG4gICAgT25DaGFuZ2VzLFxyXG4gICAgU2ltcGxlQ2hhbmdlcyxcclxuICAgIE9uRGVzdHJveSxcclxuICAgIEVsZW1lbnRSZWYsXHJcbiAgICBBZnRlclZpZXdJbml0XHJcbn0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XHJcbmltcG9ydCB7IEtkQ2hhcnRCYXNlQ2xhc3MgfSBmcm9tICcuLi9rZC1hbmd1bGFyLWNoYXJ0LWJhc2UtY2xhc3MnO1xyXG5pbXBvcnQgeyBLZENoYXJ0c1N2YyB9IGZyb20gJy4uL2tkLWFuZ3VsYXItY2hhcnRzLXN2Yyc7XHJcbmltcG9ydCB7IEtkRG9tRWxlbVN2YyB9IGZyb20gJy4uLy4uL2tkLWNvbW1vbi9pbmRleCc7XHJcbmltcG9ydCB7IEtkTWFwQ2hhcnRTdmMgfSBmcm9tICcuL2tkLWFuZ3VsYXItbWFwLWNoYXJ0LXN2Yyc7XHJcbmltcG9ydCB7IElMZWdlbmREYXRhLCBJQ2hhcnRDb25maWcgfSBmcm9tICcuLi9rZC1hbmd1bGFyLWNoYXJ0cy1pbnRlcmZhY2UnO1xyXG5pbXBvcnQgKiBhcyBkMyBmcm9tICdkMyc7XHJcbmltcG9ydCAqIGFzIEwgZnJvbSAnbGVhZmxldCc7XHJcbmltcG9ydCAnbGVhZmxldC5tYXJrZXJjbHVzdGVyJztcclxuaW1wb3J0ICdsZWFmbGV0LmF3ZXNvbWUtbWFya2Vycy9kaXN0L2xlYWZsZXQuYXdlc29tZS1tYXJrZXJzJztcclxuXHJcbkBDb21wb25lbnQoe1xyXG4gICAgc2VsZWN0b3I6ICdrZC1tYXAtY2hhcnQnLFxyXG4gICAgdGVtcGxhdGU6IGBcclxuICAgICAgICA8ZGl2PlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgYCxcclxuICAgIGVuY2Fwc3VsYXRpb246IFZpZXdFbmNhcHN1bGF0aW9uLk5vbmUsXHJcbiAgICBwcm92aWRlcnM6IFtLZENoYXJ0c1N2YywgS2REb21FbGVtU3ZjLCBLZE1hcENoYXJ0U3ZjXSxcclxuICAgIGhvc3Q6IHtcclxuICAgICAgICAnY2xhc3MnOiAna2R4LW1hcC1jaGFydCcsXHJcbiAgICAgICAgLy8gJ1thdHRyLmlkXSc6ICdjb25maWcuaWQnLFxyXG4gICAgfVxyXG59KVxyXG5cclxuZXhwb3J0IGNsYXNzIEtkTWFwQ2hhcnQgZXh0ZW5kcyBLZENoYXJ0QmFzZUNsYXNzIGltcGxlbWVudHMgT25Jbml0LCBPbkNoYW5nZXMsIEFmdGVyVmlld0luaXQsIE9uRGVzdHJveSB7XHJcbiAgICBwcml2YXRlIF9mdWxsR3JhcGg6IGFueTtcclxuICAgIHByaXZhdGUgX21hcFBhdGg6IGFueTtcclxuICAgIHByaXZhdGUgX3BhdGg6IGFueTtcclxuICAgIHByaXZhdGUgX3pvb21CdG5zOiBhbnk7XHJcbiAgICBwcml2YXRlIF9iYWNrQnRuOiBhbnk7XHJcbiAgICBwcml2YXRlIF9tYXBMYXllcjogYW55O1xyXG4gICAgcHJpdmF0ZSBfbGV2ZWw6IGFueTtcclxuICAgIHByaXZhdGUgX2RlZmF1bHRMZXZlbDogYW55O1xyXG4gICAgcHJpdmF0ZSBfaGVpZ2h0OiBudW1iZXI7XHJcbiAgICBwcml2YXRlIF93aWR0aDogbnVtYmVyO1xyXG4gICAgcHJpdmF0ZSBfbGVhZmxldE1hcDogTC5NYXA7XHJcbiAgICBwcml2YXRlIF9sYXllcjogYW55O1xyXG4gICAgcHJpdmF0ZSBfY2x1c3RlckRhdGE6IGFueTtcclxuICAgIHByaXZhdGUgX3Nlcmllc1BvaW50ZXI6IGFueTtcclxuICAgIHByaXZhdGUgX2NvbG9yUG9pbnRlcjogYW55O1xyXG4gICAgcHJpdmF0ZSBfbWFwU2NhbGVDb2xvclNjYWxlOiBhbnk7XHJcbiAgICBwcml2YXRlIF9vdXRwdXRTZXJpZXNEYXRhOiBBcnJheTx7ICduYW1lJzogc3RyaW5nLCAndmFsdWUnOiBzdHJpbmcsICdpZCc6IHN0cmluZyB9PiA9IFtdO1xyXG4gICAgcHJpdmF0ZSBfc2VyaWVzRGF0YTogQXJyYXk8YW55PiA9IFtdO1xyXG4gICAgcHJpdmF0ZSBfZW1wdHlTZXJpZXM6IGJvb2xlYW4gPSBmYWxzZTtcclxuICAgIHByaXZhdGUgX3NpbmdsZUxldmVsRGltZW5zaW9uOiBib29sZWFuID0gZmFsc2U7XHJcbiAgICBwcml2YXRlIF90aWxlbG9hZEluZGV4OiBudW1iZXIgPSAwO1xyXG4gICAgcHJpdmF0ZSBfaXNMYXllckVycm9yOiBib29sZWFuID0gZmFsc2U7XHJcbiAgICBwcml2YXRlIF9sYXllclJlbG9hZFRpbWVzOiBudW1iZXIgPSAwO1xyXG4gICAgcHJpdmF0ZSBfaXNNYXBTZWxlY3RlZDogYW55ID0ge307XHJcblxyXG5cclxuICAgIEBJbnB1dCgpIGRhdGE6IGFueTtcclxuICAgIEBJbnB1dCgnY29uZmlnJykgbWFwQ29uZmlnOiBJQ2hhcnRDb25maWc7XHJcbiAgICBASW5wdXQoKSBsZWdlbmQ6IHsgW2tleTogc3RyaW5nXTogSUxlZ2VuZERhdGEgfTtcclxuICAgIEBJbnB1dCgpIGFwaTogYW55O1xyXG4gICAgQE91dHB1dCgpIG91dHB1dExlZ2VuZDogRXZlbnRFbWl0dGVyPHsgW2tleTogc3RyaW5nXTogSUxlZ2VuZERhdGEgfT4gPSBuZXcgRXZlbnRFbWl0dGVyKHRydWUpO1xyXG4gICAgQE91dHB1dCgpIG91dHB1dERhdGE6IEV2ZW50RW1pdHRlcjxhbnk+ID0gbmV3IEV2ZW50RW1pdHRlcih0cnVlKTtcclxuICAgIEBPdXRwdXQoKSBvdXRwdXRNYXJrZXI6IEV2ZW50RW1pdHRlcjxhbnk+ID0gbmV3IEV2ZW50RW1pdHRlcih0cnVlKTtcclxuICAgIEBPdXRwdXQoKSBvdXRwdXRSZWFkeTogRXZlbnRFbWl0dGVyPGFueT4gPSBuZXcgRXZlbnRFbWl0dGVyKHRydWUpO1xyXG5cclxuICAgIGNvbnN0cnVjdG9yKFxyXG4gICAgICAgIHByaXZhdGUgX2VsZW1lbnRSZWY6IEVsZW1lbnRSZWYsXHJcbiAgICAgICAgcHVibGljIF9jaGFydFN2YzogS2RDaGFydHNTdmMsXHJcbiAgICAgICAgcHVibGljIF9kb21TdmM6IEtkRG9tRWxlbVN2YyxcclxuICAgICAgICBwcml2YXRlIF9tYXBTdmM6IEtkTWFwQ2hhcnRTdmNcclxuICAgICkge1xyXG4gICAgICAgIHN1cGVyKF9jaGFydFN2YywgX2RvbVN2Yyk7XHJcbiAgICB9XHJcblxyXG4gICAgbmdPbkluaXQoKTogdm9pZCB7XHJcbiAgICAgICAgdGhpcy5jb25maWcgPSBPYmplY3QuYXNzaWduKHt9LCB0aGlzLm1hcENvbmZpZyk7XHJcbiAgICAgICAgdGhpcy5sZWdlbmREYXRhID0gT2JqZWN0LmFzc2lnbih7fSwgdGhpcy5sZWdlbmQpO1xyXG4gICAgICAgIHRoaXMuX3NldERhdGEoKTtcclxuICAgICAgICBzdXBlci5jaGFydFRpbWVvdXQoKCkgPT4gdGhpcy5fc2V0Q2hhcnQoKSk7XHJcbiAgICAgICAgdGhpcy5hcGkucmVkcmF3ID0gKCkgPT4ge1xyXG4gICAgICAgICAgICBzZXRUaW1lb3V0KCgpID0+IHtcclxuICAgICAgICAgICAgICAgIHRoaXMuX292ZXJXcml0ZVNlcmllcygpO1xyXG4gICAgICAgICAgICAgICAgdGhpcy5fcmVzZXRDaGFydCgpO1xyXG4gICAgICAgICAgICAgICAgdGhpcy5fc2V0Q2hhcnQoKTtcclxuICAgICAgICAgICAgICAgIC8vIGlmICghdGhpcy5jb25maWcuc2tpcE1hc3NhZ2UpIHtcclxuICAgICAgICAgICAgICAgIC8vICAgICB0aGlzLmxlZ2VuZCA9IHRoaXMuX2NoYXJ0U3ZjLnNldE1hcExlZ2VuZERhdGEodGhpcy5sZWdlbmQsIHRoaXMuX3Nlcmllc0RhdGEsIHRoaXMuY29uZmlnKTtcclxuICAgICAgICAgICAgICAgIC8vIH1cclxuICAgICAgICAgICAgICAgIHRoaXMuX2dldExlZ2VuZEJ5VHlwZSgpO1xyXG4gICAgICAgICAgICB9KTtcclxuICAgICAgICB9O1xyXG4gICAgICAgIHRoaXMuYXBpLmxlZ2VuZENsaWNrID0gKF9pZDogYW55LCBfbGVnZW5kQWN0aXZlKSA9PiB7XHJcbiAgICAgICAgICAgIHRoaXMubGVnZW5kW19pZF0uZGVhY3RpdmUgPSBfbGVnZW5kQWN0aXZlO1xyXG4gICAgICAgICAgICBmb3IgKGxldCBpID0gMDsgaSA8IHRoaXMuX3Nlcmllc0RhdGEubGVuZ3RoOyBpKyspIHtcclxuICAgICAgICAgICAgICAgIGlmICh0aGlzLl9zZXJpZXNEYXRhW2ldLmlkICYmIHRoaXMuX3Nlcmllc0RhdGFbaV0uaWQgPT0gdGhpcy5sZWdlbmRbX2lkXS5tYXBTZXJpZXNJZCkge1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuX3Nlcmllc0RhdGFbaV0uZGVhY3RpdmUgPSBfbGVnZW5kQWN0aXZlO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIHRoaXMuZGF0YVsnbWFwU2VyaWVzRGF0YSddID0gdGhpcy5fc2VyaWVzRGF0YTtcclxuICAgICAgICAgICAgaWYgKHRoaXMuX3NpbmdsZUxldmVsRGltZW5zaW9uID09IGZhbHNlKSB0aGlzLl9nZXROZXdTZXJpZXMoKTtcclxuICAgICAgICAgICAgdGhpcy5fcmVzZXRDaGFydCgpO1xyXG4gICAgICAgICAgICB0aGlzLl9zZXRDaGFydCgpO1xyXG4gICAgICAgIH07XHJcbiAgICAgICAgdGhpcy5hcGkuY2x1c3RlckNsaWNrID0gKF9pZDogYW55LCBfbGVnZW5kSXRlbTogeyAnbGVnZW5kSXRlbU1hcmtlcic6IEhUTUxFbGVtZW50LCAnbGVnZW5kSXRlbUxhYmVsJzogSFRNTEVsZW1lbnQgfSkgPT4ge1xyXG4gICAgICAgICAgICBsZXQgc2VsZWN0ZWRNYXJrZXJHcm91cDogTC5NYXJrZXJDbHVzdGVyR3JvdXAgfCBMLm1hcmtlcjtcclxuICAgICAgICAgICAgc2VsZWN0ZWRNYXJrZXJHcm91cCA9IHRoaXMuX2NsdXN0ZXJEYXRhLmNsdXN0ZXJNYXJrZXJzW19pZC5pZF07XHJcblxyXG4gICAgICAgICAgICBpZiAodGhpcy5fbGVhZmxldE1hcC5oYXNMYXllcihzZWxlY3RlZE1hcmtlckdyb3VwKSkge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5fbGVhZmxldE1hcC5yZW1vdmVMYXllcihzZWxlY3RlZE1hcmtlckdyb3VwKTtcclxuICAgICAgICAgICAgICAgIHRoaXMuX2RvbVN2Yy5hZGRDbGFzcyhfbGVnZW5kSXRlbS5sZWdlbmRJdGVtTWFya2VyLCAnYXdlc29tZS1tYXJrZXItaWNvbi1saWdodGdyYXknKTtcclxuICAgICAgICAgICAgICAgIHRoaXMuX2RvbVN2Yy5hZGRDbGFzcyhfbGVnZW5kSXRlbS5sZWdlbmRJdGVtTGFiZWwsICdrZHgtbGFiZWwtbGlnaHRncmF5Jyk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgZWxzZSB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLl9sZWFmbGV0TWFwLmFkZExheWVyKHNlbGVjdGVkTWFya2VyR3JvdXApO1xyXG4gICAgICAgICAgICAgICAgdGhpcy5fZG9tU3ZjLnJlbW92ZUNsYXNzKF9sZWdlbmRJdGVtLmxlZ2VuZEl0ZW1NYXJrZXIsICdhd2Vzb21lLW1hcmtlci1pY29uLWxpZ2h0Z3JheScpO1xyXG4gICAgICAgICAgICAgICAgdGhpcy5fZG9tU3ZjLnJlbW92ZUNsYXNzKF9sZWdlbmRJdGVtLmxlZ2VuZEl0ZW1MYWJlbCwgJ2tkeC1sYWJlbC1saWdodGdyYXknKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICBuZ09uQ2hhbmdlcyhfc2ltcGxlQ2hhbmdlczogU2ltcGxlQ2hhbmdlcyk6IHZvaWQge1xyXG4gICAgICAgIGlmIChfc2ltcGxlQ2hhbmdlcy5oYXNPd25Qcm9wZXJ0eSgnZGF0YScpICYmICFfc2ltcGxlQ2hhbmdlc1snZGF0YSddLmZpcnN0Q2hhbmdlKSB7XHJcbiAgICAgICAgICAgIHRoaXMuZGF0YSA9IF9zaW1wbGVDaGFuZ2VzLmRhdGEuY3VycmVudFZhbHVlO1xyXG4gICAgICAgICAgICB0aGlzLl9yZWRyYXdDaGFydCgnZGF0YScpO1xyXG4gICAgICAgIH1cclxuICAgICAgICBpZiAoX3NpbXBsZUNoYW5nZXMuaGFzT3duUHJvcGVydHkoJ21hcENvbmZpZycpICYmICFfc2ltcGxlQ2hhbmdlc1snbWFwQ29uZmlnJ10uZmlyc3RDaGFuZ2UpIHtcclxuICAgICAgICAgICAgaWYgKHRoaXMubWFwQ29uZmlnLnBsb3RPcHRpb25zLm1hcC56b29tKSB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLl9jaGVja1pvb21Db25maWcodGhpcy5tYXBDb25maWcucGxvdE9wdGlvbnMubWFwLnpvb20pO1xyXG4gICAgICAgICAgICAgICAgaWYgKHRoaXMubWFwQ29uZmlnLnBsb3RPcHRpb25zLm1hcC56b29tLnZhbHVlKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKHR5cGVvZiB0aGlzLl9sZWFmbGV0TWFwICE9PSAndW5kZWZpbmVkJykgdGhpcy5fbGVhZmxldE1hcC5zZXRab29tKHRoaXMubWFwQ29uZmlnLnBsb3RPcHRpb25zLm1hcC56b29tLnZhbHVlKTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIC8vIG5lZWQgdG8gY2hlY2sgd2h5IGxlZ2VuZCBrZWVwIGdvbmVcclxuICAgICAgICAgICAgICAgIC8vIGlmICh0aGlzLmNoYXJ0VHlwZVsxXSA9PT0gJ2Z1bGwnIHx8IHRoaXMuY2hhcnRUeXBlWzFdID09PSAnY2x1c3RlcicpIHRoaXMuX3NldE1hcmtlcnMoKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB0aGlzLm1hcENvbmZpZyA9IF9zaW1wbGVDaGFuZ2VzLm1hcENvbmZpZy5jdXJyZW50VmFsdWU7XHJcbiAgICAgICAgICAgIHRoaXMuX3JlZHJhd0NoYXJ0KCdjb25maWcnKTtcclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgbmdBZnRlclZpZXdJbml0KCkge1xyXG4gICAgICAgIGlmICh0eXBlb2YgdGhpcy5fbGVhZmxldE1hcCAhPT0gJ3VuZGVmaW5lZCcpIHRoaXMuX2xlYWZsZXRNYXAuaW52YWxpZGF0ZVNpemUoe30pO1xyXG4gICAgfVxyXG5cclxuICAgIG5nT25EZXN0cm95KCk6IHZvaWQge1xyXG4gICAgICAgIHRoaXMuX3Jlc2V0Q2hhcnQoKTtcclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF9yZWRyYXdDaGFydChfY2hhbmdlcz86ICdkYXRhJyB8ICdjb25maWcnKSB7XHJcbiAgICAgICAgdGhpcy5fcmVzZXRDaGFydCgpO1xyXG5cclxuICAgICAgICBpZiAoX2NoYW5nZXMgPT09ICdkYXRhJykge1xyXG4gICAgICAgICAgICB0aGlzLl9zZXJpZXNEYXRhID0gW107XHJcbiAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgdGhpcy5jb25maWcgPSBPYmplY3QuYXNzaWduKHt9LCB0aGlzLm1hcENvbmZpZyk7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIHRoaXMubGVnZW5kRGF0YSA9IE9iamVjdC5hc3NpZ24oe30sIHRoaXMubGVnZW5kKTtcclxuXHJcbiAgICAgICAgdGhpcy5fc2V0RGF0YSgpO1xyXG4gICAgICAgIHN1cGVyLmNoYXJ0VGltZW91dCgoKSA9PiB0aGlzLl9zZXRDaGFydCgpKTtcclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF9zZXRDaGFydCgpOiB2b2lkIHtcclxuICAgICAgICB0aGlzLmNoYXJ0VHlwZSA9IHRoaXMuZGF0YS5jaGFydC5sYXlvdXQuc3BsaXQoJy0nKTtcclxuICAgICAgICBpZiAodGhpcy5fbGV2ZWwgIT09IHVuZGVmaW5lZCAmJiB0aGlzLl9sZXZlbCAhPT0gbnVsbCkge1xyXG4gICAgICAgIH0gZWxzZSBpZiAoKHRoaXMuZGF0YVsnbWFwTGV2ZWwnXSAmJiB0aGlzLmNvbmZpZy5za2lwTWFzc2FnZSkgfHwgKHRoaXMuZGF0YVsnbWFwTGV2ZWwnXSAmJiB0aGlzLl9zaW5nbGVMZXZlbERpbWVuc2lvbiA9PSB0cnVlKSkge1xyXG4gICAgICAgICAgICAvLyBpZiAoKHRoaXMuZGF0YVsnbWFwTGV2ZWwnXSAmJiB0aGlzLmNvbmZpZy5za2lwTWFzc2FnZSkgfHwgKHRoaXMuZGF0YVsnbWFwTGV2ZWwnXSAmJiB0aGlzLl9zaW5nbGVMZXZlbERpbWVuc2lvbiA9PSB0cnVlKSkge1xyXG4gICAgICAgICAgICBsZXQgdG1wTGV2ZWxBcnI6IEFycmF5PHN0cmluZz4gPSBPYmplY3Qua2V5cyh0aGlzLmRhdGEubWFwRGF0YSk7XHJcbiAgICAgICAgICAgIHRoaXMuX2RlZmF1bHRMZXZlbCA9IHRtcExldmVsQXJyLmxlbmd0aCA+IDAgPyB0bXBMZXZlbEFyclswXSA6IHRoaXMuZGF0YVsnbWFwTGV2ZWwnXTtcclxuICAgICAgICAgICAgdGhpcy5fbGV2ZWwgPSB0aGlzLmRhdGFbJ21hcExldmVsJ107XHJcbiAgICAgICAgICAgIC8vIGNoZWNraW5nIGlmIG1hcCBnb3QgYXJlYSBmaWx0ZXJcclxuICAgICAgICB9IGVsc2UgaWYgKHRoaXMuZGF0YS5zZXJpZXNbdGhpcy5kYXRhLnNlcmllcy5sZW5ndGggLSAxXS5kYXRhICYmIHRoaXMuZGF0YS5zZXJpZXNbdGhpcy5kYXRhLnNlcmllcy5sZW5ndGggLSAxXS5kYXRhLmxlbmd0aCA9PSAxKSB7XHJcbiAgICAgICAgICAgIHRoaXMuX2RlZmF1bHRMZXZlbCA9IHRoaXMuX21hcFN2Yy5nZXRNYXBMZXZlbFdpdGhBcmVhRmlsdGVyKHRoaXMuZGF0YS5zZXJpZXNbdGhpcy5kYXRhLnNlcmllcy5sZW5ndGggLSAxXS5kYXRhWzBdLklEXywgdGhpcy5kYXRhLm1hcERhdGEpO1xyXG4gICAgICAgICAgICB0aGlzLl9sZXZlbCA9IHRoaXMuX2RlZmF1bHRMZXZlbDtcclxuICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICBsZXQgdG1wTGV2ZWxBcnI6IEFycmF5PHN0cmluZz4gPSBPYmplY3Qua2V5cyh0aGlzLmRhdGEubWFwRGF0YSk7XHJcbiAgICAgICAgICAgIHRoaXMuX2RlZmF1bHRMZXZlbCA9IHRtcExldmVsQXJyLmxlbmd0aCA+IDAgPyB0bXBMZXZlbEFyclswXSA6ICdsXzEnO1xyXG4gICAgICAgICAgICB0aGlzLl9sZXZlbCA9IHRoaXMuX2RlZmF1bHRMZXZlbDtcclxuICAgICAgICB9XHJcbiAgICAgICAgdGhpcy5fZ2V0Q29sb3JQb2ludGVyKCk7XHJcblxyXG4gICAgICAgIC8vIGluc3RlYWQgb2YgbGVnZW5kLCBkcmF3IHRoZSBtYXAgY29sb3Igc2NhbGUuIG11c3QgYmUgY29tcGxldGVkIGJlZm9yZSBzdmcgZGltZW5zaW9uIGlzIGZpeGVkXHJcbiAgICAgICAgaWYgKHRoaXMuY29uZmlnLmNvbG9yQXhpcyAhPSB1bmRlZmluZWQgJiYgdGhpcy5jb25maWcuY29sb3JBeGlzLmRhdGFDbGFzc2VzID09IHVuZGVmaW5lZCkge1xyXG4gICAgICAgICAgICB0aGlzLl9kcmF3TWFwU2NhbGUoKTtcclxuICAgICAgICB9XHJcbiAgICAgICAgc3VwZXIuc2V0U3ZnKCk7XHJcbiAgICAgICAgc3VwZXIuc2V0U3ZnRGltZW5zaW9uKCd4Jyk7XHJcbiAgICAgICAgc3VwZXIuc2V0U3ZnRGltZW5zaW9uKCd5Jyk7XHJcblxyXG4gICAgICAgIHRoaXMuX2hlaWdodCA9IHRoaXMuc3ZnQ29udGFpbmVyLm5vZGUoKS5nZXRCb3VuZGluZ0NsaWVudFJlY3QoKS5oZWlnaHQ7XHJcbiAgICAgICAgdGhpcy5fd2lkdGggPSB0aGlzLnN2Z0NvbnRhaW5lci5ub2RlKCkuZ2V0Qm91bmRpbmdDbGllbnRSZWN0KCkud2lkdGg7XHJcblxyXG4gICAgICAgIGlmICh0aGlzLmNoYXJ0VHlwZVsxXSA9PT0gJ3BvbHlnb24nIHx8IHRoaXMuY2hhcnRUeXBlWzFdID09PSAndGhlbWF0aWMnKSB7XHJcbiAgICAgICAgICAgIHRoaXMuX2RyYXdQb2x5Z29uTWFwKCk7XHJcbiAgICAgICAgfSBlbHNlIGlmICh0aGlzLmNoYXJ0VHlwZVsxXSA9PT0gJ2Z1bGwnIHx8IHRoaXMuY2hhcnRUeXBlWzFdID09PSAnY2x1c3RlcicgfHwgdGhpcy5jaGFydFR5cGVbMV0gPT09ICdmaWx0ZXInKSB7XHJcbiAgICAgICAgICAgIHRoaXMuX2RyYXdMZWFmdGxldCgpO1xyXG4gICAgICAgICAgICBzZXRUaW1lb3V0KCgpID0+IHtcclxuICAgICAgICAgICAgICAgIGlmICh0eXBlb2YgdGhpcy5fbGVhZmxldE1hcCAhPT0gJ3VuZGVmaW5lZCcpIHRoaXMuX2xlYWZsZXRNYXAuaW52YWxpZGF0ZVNpemUoe30pO1xyXG4gICAgICAgICAgICB9KVxyXG4gICAgICAgICAgICBpZiAodGhpcy5jaGFydFR5cGVbMV0gIT09ICdjbHVzdGVyJykgdGhpcy5fZHJhd0Z1bGxNYXAoKTtcclxuICAgICAgICB9XHJcbiAgICAgICAgLy8gY29uc29sZS5sb2coJ2RhdGEgJywgdGhpcy5kYXRhKVxyXG4gICAgICAgIC8vIGNvbnNvbGUubG9nKCdjb25maWcgJywgdGhpcy5jb25maWcpXHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfc2V0RGF0YSgpOiB2b2lkIHtcclxuICAgICAgICB0aGlzLmNoYXJ0Q2F0ZWdvcnkgPSAnbWFwJztcclxuICAgICAgICBpZiAodGhpcy5kYXRhWydtYXBTZXJpZXNEYXRhJ10gJiYgdGhpcy5jb25maWcuc2tpcE1hc3NhZ2UpIHtcclxuICAgICAgICAgICAgLy8gZXhwb3J0IG1vZGVcclxuICAgICAgICAgICAgdGhpcy5fc2VyaWVzRGF0YSA9IEpTT04ucGFyc2UoSlNPTi5zdHJpbmdpZnkodGhpcy5kYXRhWydtYXBTZXJpZXNEYXRhJ10pKTtcclxuICAgICAgICAgICAgaWYgKHRoaXMuY29uZmlnLmNvbG9yQXhpcyAhPSB1bmRlZmluZWQpIHtcclxuICAgICAgICAgICAgICAgIC8vIHNpbmdsZSBkaW1lbnNpb25cclxuICAgICAgICAgICAgICAgIHRoaXMuX3Nlcmllc1BvaW50ZXIgPSB0aGlzLl9tYXBTdmMuZ2V0U2VyaWVzUG9pbnRlcih0aGlzLl9zZXJpZXNEYXRhKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgICAgIHRoaXMuX2dldE5ld1NlcmllcygpO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgdGhpcy5fc2VyaWVzRGF0YSA9IEpTT04ucGFyc2UoSlNPTi5zdHJpbmdpZnkodGhpcy5kYXRhLnNlcmllcykpO1xyXG4gICAgICAgICAgICBmb3IgKGxldCBpID0gMDsgaSA8IHRoaXMuX3Nlcmllc0RhdGEubGVuZ3RoOyBpKyspIHtcclxuICAgICAgICAgICAgICAgIHRoaXMuX3Nlcmllc0RhdGFbaV1bJ2RlYWN0aXZlJ10gPSBmYWxzZTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBpZiAodGhpcy5jb25maWcuY29sb3JBeGlzICE9IHVuZGVmaW5lZCkge1xyXG4gICAgICAgICAgICAgICAgLy8gc2luZ2xlIGRpbWVuc2lvblxyXG4gICAgICAgICAgICAgICAgdGhpcy5fc2VyaWVzUG9pbnRlciA9IHRoaXMuX21hcFN2Yy5nZXRTZXJpZXNQb2ludGVyKHRoaXMuX3Nlcmllc0RhdGEpO1xyXG4gICAgICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgLy8gbXVsdGkgZGltZW5zaW9uXHJcbiAgICAgICAgICAgICAgICBpZiAodGhpcy5fc2VyaWVzRGF0YSAmJiB0aGlzLl9zZXJpZXNEYXRhLmxlbmd0aCAhPSAwKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5fc2VyaWVzUG9pbnRlciA9IHRoaXMuX3Nlcmllc0RhdGFbdGhpcy5fc2VyaWVzRGF0YS5sZW5ndGggLSAxXTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB0aGlzLl9lbXB0eVNlcmllcyA9IHRoaXMuX3Nlcmllc1BvaW50ZXIgPT0gdW5kZWZpbmVkID8gdHJ1ZSA6IGZhbHNlO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgLy8gaWYgKCF0aGlzLmNvbmZpZy5za2lwTWFzc2FnZSkge1xyXG4gICAgICAgIC8vICAgICB0aGlzLmxlZ2VuZCA9IHRoaXMuX2NoYXJ0U3ZjLnNldE1hcExlZ2VuZERhdGEodGhpcy5sZWdlbmQsIHRoaXMuX3Nlcmllc0RhdGEsIHRoaXMuY29uZmlnKTtcclxuICAgICAgICAvLyB9XHJcbiAgICAgICAgdGhpcy5fZ2V0Q29sb3JQb2ludGVyKCk7XHJcbiAgICAgICAgdGhpcy5fZ2V0TGVnZW5kQnlUeXBlKCk7XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfcmVzZXRDaGFydCgpOiB2b2lkIHtcclxuICAgICAgICBpZiAodHlwZW9mIHRoaXMuX3pvb21CdG5zICE9PSAndW5kZWZpbmVkJykge1xyXG4gICAgICAgICAgICB0aGlzLl96b29tQnRucy5yZW1vdmUoKTtcclxuICAgICAgICAgICAgdGhpcy5fem9vbUJ0bnMgPSB1bmRlZmluZWQ7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGlmICh0aGlzLl9sZWFmbGV0TWFwICE9PSB1bmRlZmluZWQgJiYgdGhpcy5fbGVhZmxldE1hcCAhPT0gbnVsbCAmJiAhdGhpcy5jb25maWcuc2tpcE1hc3NhZ2UpIHtcclxuICAgICAgICAgICAgdGhpcy5fbGVhZmxldE1hcC5yZW1vdmUoKTtcclxuICAgICAgICAgICAgdGhpcy5fbGVhZmxldE1hcCA9IHVuZGVmaW5lZDtcclxuICAgICAgICAgICAgbGV0IGxlYWZ0bGV0SWQgPSAnIycgKyB0aGlzLmNvbmZpZy5pZCArICdMZWFmbGV0JztcclxuICAgICAgICAgICAgZG9jdW1lbnQucXVlcnlTZWxlY3RvcihsZWFmdGxldElkKS5zZXRBdHRyaWJ1dGUoJ2NsYXNzJywgJ2tkeC1jaGFydHMtc3ZnLWNvbnRhaW5lcicpO1xyXG4gICAgICAgIH1cclxuICAgICAgICBpZiAodHlwZW9mIHRoaXMuX21hcExheWVyICE9PSAndW5kZWZpbmVkJykge1xyXG4gICAgICAgICAgICB0aGlzLl9tYXBMYXllci5yZW1vdmUoKTtcclxuICAgICAgICAgICAgdGhpcy5fbWFwTGF5ZXIgPSB1bmRlZmluZWQ7XHJcblxyXG4gICAgICAgIH1cclxuICAgICAgICBpZiAodHlwZW9mIHRoaXMuX2Z1bGxHcmFwaCAhPT0gJ3VuZGVmaW5lZCcpIHtcclxuICAgICAgICAgICAgdGhpcy5fZnVsbEdyYXBoLnJlbW92ZSgpO1xyXG4gICAgICAgICAgICB0aGlzLl9mdWxsR3JhcGggPSB1bmRlZmluZWQ7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGlmICh0eXBlb2YgdGhpcy5fYmFja0J0biAhPT0gJ3VuZGVmaW5lZCcpIHtcclxuICAgICAgICAgICAgdGhpcy5fYmFja0J0bi5yZW1vdmUoKTtcclxuICAgICAgICAgICAgdGhpcy5fYmFja0J0biA9IHVuZGVmaW5lZDtcclxuICAgICAgICB9XHJcbiAgICAgICAgdGhpcy5fbGV2ZWwgPSB1bmRlZmluZWQ7XHJcbiAgICAgICAgdGhpcy5fb3V0cHV0U2VyaWVzRGF0YSA9IFtdO1xyXG4gICAgICAgIHRoaXMuX2lzTWFwU2VsZWN0ZWQgPSB7fTtcclxuICAgICAgICBzdXBlci5yZW1vdmVDaGFydCgpO1xyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX2RyYXdMZWFmdGxldCgpOiB2b2lkIHtcclxuICAgICAgICBpZiAodGhpcy5fbGVhZmxldE1hcCAhPT0gdW5kZWZpbmVkICYmIHRoaXMuX2xlYWZsZXRNYXAgIT09IG51bGwpIHRoaXMuX2xlYWZsZXRNYXAucmVtb3ZlKCk7XHJcbiAgICAgICAgbGV0IHpvb21WYWx1ZTogbnVtYmVyID0gNjtcclxuICAgICAgICBpZiAodGhpcy5jaGFydFR5cGVbMV0gPT09ICdmaWx0ZXInICYmIHRoaXMuZGF0YS5wb3NpdGlvbiAmJiB0aGlzLmRhdGEucG9zaXRpb24uem9vbSkge1xyXG4gICAgICAgICAgICB6b29tVmFsdWUgPSB0aGlzLmRhdGEucG9zaXRpb24uem9vbTtcclxuICAgICAgICB9IGVsc2UgaWYgKHRoaXMuY29uZmlnLnBsb3RPcHRpb25zLm1hcC56b29tICYmIHRoaXMuY29uZmlnLnBsb3RPcHRpb25zLm1hcC56b29tLnZhbHVlKSB7XHJcbiAgICAgICAgICAgIHpvb21WYWx1ZSA9IHRoaXMuY29uZmlnLnBsb3RPcHRpb25zLm1hcC56b29tLnZhbHVlO1xyXG4gICAgICAgIH1cclxuICAgICAgICBsZXQgbGVhZnRsZXRJZCA9IHRoaXMuY29uZmlnLmlkICsgJ0xlYWZsZXQnO1xyXG4gICAgICAgIHRoaXMuX2xlYWZsZXRNYXAgPSBMLm1hcChsZWFmdGxldElkKS5zZXRWaWV3KFt0aGlzLmRhdGEucG9zaXRpb24ubGF0aXR1ZGUsIHRoaXMuZGF0YS5wb3NpdGlvbi5sb25naXR1ZGVdLCB6b29tVmFsdWUpO1xyXG4gICAgICAgIHRoaXMuX3NldExheWVyKCk7XHJcbiAgICAgICAgdGhpcy5fcmVtb3ZlRGVmYXVsdEF0dHJpYnV0aW9uKCdPcGVuRU1JUycpO1xyXG4gICAgICAgIGlmICh0aGlzLmNoYXJ0VHlwZVsxXSA9PT0gJ2Z1bGwnIHx8IHRoaXMuY2hhcnRUeXBlWzFdID09PSAnY2x1c3RlcicpIHRoaXMuX3NldE1hcmtlcnMoKTtcclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF9kcmF3RnVsbE1hcCgpOiB2b2lkIHtcclxuICAgICAgICB0aGlzLl9vdXRwdXRTZXJpZXNEYXRhID0gW107XHJcbiAgICAgICAgaWYgKHR5cGVvZiB0aGlzLl9mdWxsR3JhcGggPT09ICd1bmRlZmluZWQnKSB0aGlzLl9mdWxsR3JhcGggPSBkMy5zZWxlY3QodGhpcy5fbGVhZmxldE1hcC5nZXRQYW5lcygpLm92ZXJsYXlQYW5lKS5hcHBlbmQoXCJzdmdcIik7XHJcbiAgICAgICAgLy8gdGhpcy5fZnVsbEdyYXBoID0gZDMuc2VsZWN0KHRoaXMuX2xlYWZsZXRNYXAuZ2V0UGFuZXMoKS5vdmVybGF5UGFuZSkuYXBwZW5kKFwic3ZnXCIpO1xyXG5cclxuICAgICAgICB0aGlzLl9tYXBMYXllciA9IHRoaXMuX2Z1bGxHcmFwaC5hcHBlbmQoXCJnXCIpLmF0dHIoXCJjbGFzc1wiLCBcImxlYWZsZXQtem9vbS1oaWRlXCIpO1xyXG4gICAgICAgIGxldCBtYXAgPSB0aGlzLl9sZWFmbGV0TWFwO1xyXG4gICAgICAgIGxldCBzdmcgPSB0aGlzLl9mdWxsR3JhcGg7XHJcbiAgICAgICAgbGV0IGN1cnJlbnRDaGFydElkID0gdGhpcy5jb25maWcuaWQ7XHJcbiAgICAgICAgbGV0IG1hcExheWVyID0gdGhpcy5fbWFwTGF5ZXI7XHJcbiAgICAgICAgbGV0IHdpZHRoID0gdGhpcy5fd2lkdGg7XHJcbiAgICAgICAgbGV0IGhlaWdodCA9IHRoaXMuX2hlaWdodDtcclxuICAgICAgICBsZXQgdHJhbnNmb3JtID0gZDMuZ2VvVHJhbnNmb3JtKHtcclxuICAgICAgICAgICAgcG9pbnQ6IGZ1bmN0aW9uKHgsIHkpIHtcclxuICAgICAgICAgICAgICAgIGxldCBwb2ludCA9IG1hcC5sYXRMbmdUb0xheWVyUG9pbnQobmV3IEwuTGF0TG5nKHksIHgpKTtcclxuICAgICAgICAgICAgICAgIHRoaXMuc3RyZWFtLnBvaW50KHBvaW50LngsIHBvaW50LnkpO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfSksXHJcbiAgICAgICAgICAgIHBhdGggPSBkMy5nZW9QYXRoKCkucHJvamVjdGlvbih0cmFuc2Zvcm0pO1xyXG4gICAgICAgIGxldCB2YWx1ZUtleSwgZmlsdGVyVmFsdWVPYmo6IGFueTtcclxuICAgICAgICBpZiAodGhpcy5jaGFydFR5cGVbMV0gPT09ICdmaWx0ZXInICYmIHRoaXMuZGF0YS5oYXNPd25Qcm9wZXJ0eSgndmFsdWUnKSAmJiAodGhpcy5kYXRhLnZhbHVlICE9PSB1bmRlZmluZWQgfHwgdGhpcy5kYXRhLnZhbHVlICE9PSBudWxsKSkge1xyXG4gICAgICAgICAgICB2YWx1ZUtleSA9IE9iamVjdC5rZXlzKHRoaXMuZGF0YS52YWx1ZSlbMF07XHJcbiAgICAgICAgICAgIGZpbHRlclZhbHVlT2JqID0gdGhpcy5kYXRhLnZhbHVlW3ZhbHVlS2V5XTtcclxuICAgICAgICB9XHJcbiAgICAgICAgLy8gdGhpcy5fbWFwTGF5ZXIgPSB0aGlzLl9wYXRoLmFwcGVuZCgnZycpLmNsYXNzZWQoJ21hcC1sYXllcicsIHRydWUpO1xyXG4gICAgICAgIC8vIGFsbG93IHVzZXIgdG8gZGVmaW5lIG9yIGNoYW5nZSB0aGUgbGV2ZWwgb2YgdGhlIG1hcFxyXG4gICAgICAgIGlmICh0aGlzLmNvbmZpZy5wbG90T3B0aW9ucy5tYXAubGV2ZWwgJiYgKHRoaXMuY29uZmlnLnBsb3RPcHRpb25zLm1hcC5sZXZlbCAhPT0gJycgfHwgdGhpcy5jb25maWcucGxvdE9wdGlvbnMubWFwLmxldmVsICE9PSB1bmRlZmluZWQgfHwgdGhpcy5jb25maWcucGxvdE9wdGlvbnMubWFwLmxldmVsICE9PSBudWxsKSAmJiB0aGlzLl9tYXBTdmMuY2hlY2tNYXBMZXZlbEV4aXN0KHRoaXMuY29uZmlnLnBsb3RPcHRpb25zLm1hcC5sZXZlbCwgdGhpcy5kYXRhLm1hcERhdGEpKSB7XHJcbiAgICAgICAgICAgIGlmICgodGhpcy5jaGFydFR5cGVbMV0gPT09ICdmdWxsJyAmJiB0aGlzLmNvbmZpZy5wbG90T3B0aW9ucy5tYXAubWFwRnVsbENoYW5nZUxldmVsRGVmYXVsdCA9PT0gdHJ1ZSkgfHwgdGhpcy5jaGFydFR5cGVbMV0gIT09ICdmdWxsJykge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5fbGV2ZWwgPSB0aGlzLmNvbmZpZy5wbG90T3B0aW9ucy5tYXAubGV2ZWw7XHJcbiAgICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLl9jaGVja0JhY2tCdG4oKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgIHRoaXMuX2NoZWNrQmFja0J0bigpO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgbGV0IGRhdGEgPSB0aGlzLmRhdGEubWFwRGF0YS5oYXNPd25Qcm9wZXJ0eSh0aGlzLl9sZXZlbCkgPyB0aGlzLmRhdGEubWFwRGF0YVt0aGlzLl9sZXZlbF0gOiB0aGlzLmRhdGEubWFwRGF0YTtcclxuICAgICAgICBsZXQgcHJvamVjdGlvbiA9IGQzLmdlb01lcmNhdG9yKCkuZml0U2l6ZShbdGhpcy5fd2lkdGgsIHRoaXMuX2hlaWdodCAtIDUwXSwgZGF0YSk7XHJcbiAgICAgICAgLy8gbGV0IHBhdGggPSBkMy5nZW9QYXRoKCkucHJvamVjdGlvbihwcm9qZWN0aW9uKTtcclxuICAgICAgICBsZXQgZmVhdHVyZXMgPSB0aGlzLmRhdGEubWFwRGF0YS5oYXNPd25Qcm9wZXJ0eSgnZmVhdHVyZXMnKSA/IHRoaXMuZGF0YS5tYXBEYXRhLmZlYXR1cmVzIDogdGhpcy5kYXRhLm1hcERhdGFbdGhpcy5fbGV2ZWxdLmZlYXR1cmVzO1xyXG5cclxuICAgICAgICBsZXQgbWFwUGF0aCA9IHRoaXMuX21hcExheWVyLnNlbGVjdEFsbCgncGF0aCcpXHJcbiAgICAgICAgICAgIC5kYXRhKGZlYXR1cmVzKVxyXG4gICAgICAgICAgICAuZW50ZXIoKS5hcHBlbmQoJ3BhdGgnKVxyXG4gICAgICAgICAgICAvLyAuYXR0cignZCcsIHBhdGgpXHJcbiAgICAgICAgICAgIC5hdHRyKCdpZCcsIChkKSA9PiB7IHJldHVybiB0aGlzLl9tYXBTdmMucGF0aElkUHJlZml4ICsgZC5wcm9wZXJ0aWVzLklEXzsgfSlcclxuICAgICAgICAgICAgLmF0dHIoJ2NsYXNzJywgKGQpID0+IHtcclxuICAgICAgICAgICAgICAgIGlmICh0aGlzLl9lbXB0eVNlcmllcyA9PSBmYWxzZSAmJiB0aGlzLl9zZXJpZXNQb2ludGVyICYmIHRoaXMuX3Nlcmllc1BvaW50ZXIuZGF0YSAhPSB1bmRlZmluZWQpIHtcclxuICAgICAgICAgICAgICAgICAgICBsZXQgc2VyaWVzVmFsdWUgPSB0aGlzLl9nZXRTZXJpZXNWYWx1ZShkLnByb3BlcnRpZXMuSURfKTtcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLl9vdXRwdXRTZXJpZXNEYXRhLnB1c2goeyAnbmFtZSc6IHNlcmllc1ZhbHVlLm5hbWUsICd2YWx1ZSc6IHNlcmllc1ZhbHVlLnZhbHVlLCAnaWQnOiBkLnByb3BlcnRpZXMuSURfIH0pO1xyXG4gICAgICAgICAgICAgICAgICAgIHJldHVybiAnaWQtJyArIHNlcmllc1ZhbHVlLmlkICsgJywgbmFtZS0nICsgc2VyaWVzVmFsdWUubmFtZSArICcsIGRyaWxsZG93bi0nICsgc2VyaWVzVmFsdWUuZHJpbGxkb3duICsgJywgdmFsdWUtJyArIHNlcmllc1ZhbHVlLnZhbHVlO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9KVxyXG4gICAgICAgICAgICAuYXR0cigndmVjdG9yLWVmZmVjdCcsICdub24tc2NhbGluZy1zdHJva2UnKVxyXG4gICAgICAgICAgICAuc3R5bGUoJ2ZpbGwnLCAoZCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgaWYgKHRoaXMuY2hhcnRUeXBlWzFdID09PSAnZmlsdGVyJyAmJiB0aGlzLmRhdGEuaGFzT3duUHJvcGVydHkoJ3ZhbHVlJykgJiYgKHRoaXMuZGF0YS52YWx1ZSAhPT0gdW5kZWZpbmVkIHx8IHRoaXMuZGF0YS52YWx1ZSAhPT0gbnVsbCkpIHtcclxuICAgICAgICAgICAgICAgICAgICBpZiAoZC5oYXNPd25Qcm9wZXJ0eSgncHJvcGVydGllcycpICYmIGQucHJvcGVydGllcy5JRF8gPT09IGZpbHRlclZhbHVlT2JqLmlkICYmIGQucHJvcGVydGllcy5OQU1FMV8gPT09IGZpbHRlclZhbHVlT2JqLm5hbWUpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5faXNNYXBTZWxlY3RlZCA9IHt9O1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLl9pc01hcFNlbGVjdGVkW2QucHJvcGVydGllcy5JRF9dID0gZC5wcm9wZXJ0aWVzLklEXztcclxuICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIHRoaXMuY29uZmlnLnBsb3RPcHRpb25zLm1hcC5zdGF0ZXMuc2VsZWN0LmNvbG9yO1xyXG4gICAgICAgICAgICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiB0aGlzLl9nZXRNYXBGaWxsQ29sb3IoZCk7XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgICAgICAgICByZXR1cm4gdGhpcy5fZ2V0TWFwRmlsbENvbG9yKGQpO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9KVxyXG4gICAgICAgICAgICAuc3R5bGUoJ3N0cm9rZS13aWR0aCcsIChkKSA9PiB7XHJcbiAgICAgICAgICAgICAgICBpZiAodGhpcy5jaGFydFR5cGVbMV0gPT09ICdmaWx0ZXInICYmIHRoaXMuZGF0YS5oYXNPd25Qcm9wZXJ0eSgndmFsdWUnKSAmJiAodGhpcy5kYXRhLnZhbHVlICE9PSB1bmRlZmluZWQgfHwgdGhpcy5kYXRhLnZhbHVlICE9PSBudWxsKSkge1xyXG4gICAgICAgICAgICAgICAgICAgIGlmIChkLmhhc093blByb3BlcnR5KCdwcm9wZXJ0aWVzJykgJiYgZC5wcm9wZXJ0aWVzLklEXyA9PT0gZmlsdGVyVmFsdWVPYmouaWQgJiYgZC5wcm9wZXJ0aWVzLk5BTUUxXyA9PT0gZmlsdGVyVmFsdWVPYmoubmFtZSkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gdGhpcy5jb25maWcucGxvdE9wdGlvbnMubWFwLmZpbHRlci5ib3JkZXJTZWxlY3RlZCA/IHRoaXMuY29uZmlnLnBsb3RPcHRpb25zLm1hcC5maWx0ZXIuYm9yZGVyU2VsZWN0ZWQgOiB0aGlzLmNvbmZpZy5wbG90T3B0aW9ucy5tYXAuYm9yZGVyV2lkdGg7XHJcbiAgICAgICAgICAgICAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuICh0aGlzLmNoYXJ0VHlwZVsxXSA9PT0gJ2ZpbHRlcicgJiYgdGhpcy5jb25maWcucGxvdE9wdGlvbnMubWFwLmZpbHRlci5ib3JkZXIpID8gdGhpcy5jb25maWcucGxvdE9wdGlvbnMubWFwLmZpbHRlci5ib3JkZXIgOiB0aGlzLmNvbmZpZy5wbG90T3B0aW9ucy5tYXAuYm9yZGVyV2lkdGg7XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgICAgICAgICByZXR1cm4gKHRoaXMuY2hhcnRUeXBlWzFdID09PSAnZmlsdGVyJyAmJiB0aGlzLmNvbmZpZy5wbG90T3B0aW9ucy5tYXAuZmlsdGVyLmJvcmRlcikgPyB0aGlzLmNvbmZpZy5wbG90T3B0aW9ucy5tYXAuZmlsdGVyLmJvcmRlciA6IHRoaXMuY29uZmlnLnBsb3RPcHRpb25zLm1hcC5ib3JkZXJXaWR0aDtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfSlcclxuICAgICAgICAgICAgLnN0eWxlKCdzdHJva2UnLCB0aGlzLmNvbmZpZy5wbG90T3B0aW9ucy5tYXAuYm9yZGVyQ29sb3IpXHJcbiAgICAgICAgICAgIC8vZHVlIHRvIGxlYWZsZXQgYmxvY2tpbmcgcG9pbnRlciBldmVudHNcclxuICAgICAgICAgICAgLnN0eWxlKCdwb2ludGVyLWV2ZW50cycsICd2aXNpYmxlJylcclxuICAgICAgICAgICAgLnN0eWxlKCdvcGFjaXR5JywgMC42KTtcclxuXHJcbiAgICAgICAgdGhpcy5fbGVhZmxldE1hcC5vbihcInZpZXdyZXNldFwiLCByZXNldCk7XHJcbiAgICAgICAgdGhpcy5fbGVhZmxldE1hcC5vbihcInpvb21cIiwgcmVzZXQpO1xyXG5cclxuICAgICAgICBsZXQgbWFwTGV2ZWwgPSB0aGlzLmRhdGEubWFwRGF0YVt0aGlzLl9sZXZlbF07XHJcbiAgICAgICAgcmVzZXQoKTtcclxuXHJcbiAgICAgICAgbGV0IGVsZW1lbnRzID0gQXJyYXkuZnJvbShkb2N1bWVudC5xdWVyeVNlbGVjdG9yQWxsKCcjJyArIHRoaXMuY29uZmlnLmlkICsgJy5rZHgtY2hhcnRzIHN2ZyAubGVhZmxldC16b29tLWhpZGUnKSk7XHJcbiAgICAgICAgZWxlbWVudHMuZm9yRWFjaCgoZWwpID0+IHtcclxuICAgICAgICAgICAgZWwuYWRkRXZlbnRMaXN0ZW5lcignbW91c2VvdmVyJywgKGQpID0+IHtcclxuICAgICAgICAgICAgICAgIGxldCB0YXJnZXRFbGVtZW50OiBIVE1MRWxlbWVudCA9IDxIVE1MRWxlbWVudD5kLnRhcmdldDtcclxuICAgICAgICAgICAgICAgIGxldCB0YXJnZXRHZW9qc29uSWQ6IHN0cmluZyA9IHRoaXMuX21hcFN2Yy5nZXRUYXJnZXRHZW9qc29uSWQodGFyZ2V0RWxlbWVudCk7XHJcbiAgICAgICAgICAgICAgICBsZXQgY3VycmVudFNlbGVjdGlvbiA9IHRoaXMuX21hcFN2Yy5nZXRDdXJyZW50U2VsZWN0aW9uKHRoaXMuc3ZnQ29udGFpbmVyLCB0YXJnZXRFbGVtZW50LmdldEF0dHJpYnV0ZSgnaWQnKSk7XHJcbiAgICAgICAgICAgICAgICBpZiAodGhpcy5fY2hlY2tFbXB0eURhdGFWYWx1ZSh0YXJnZXRHZW9qc29uSWQpKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKHRoaXMuY2hhcnRUeXBlWzFdICE9PSAnZmlsdGVyJyB8fCAodGhpcy5jaGFydFR5cGVbMV0gPT09ICdmaWx0ZXInICYmICF0aGlzLl9jaGVja01hcFNlbGVjdGVkKHRhcmdldEdlb2pzb25JZCkpKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGN1cnJlbnRTZWxlY3Rpb24uc3R5bGUoJ2ZpbGwnLCB0aGlzLmNvbmZpZy5wbG90T3B0aW9ucy5tYXAuc3RhdGVzLmhvdmVyLmNvbG9yKTtcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKHRoaXMuY2hhcnRUeXBlWzFdID09PSAnZmlsdGVyJyAmJiB0aGlzLmNvbmZpZy5wbG90T3B0aW9ucy5tYXAuZmlsdGVyICYmIHRoaXMuY29uZmlnLnBsb3RPcHRpb25zLm1hcC5maWx0ZXIuYm9yZGVySG92ZXIgJiYgIXRoaXMuX2NoZWNrTWFwU2VsZWN0ZWQodGFyZ2V0R2VvanNvbklkKSkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBjdXJyZW50U2VsZWN0aW9uLnN0eWxlKCdzdHJva2Utd2lkdGgnLCB0aGlzLmNvbmZpZy5wbG90T3B0aW9ucy5tYXAuZmlsdGVyLmJvcmRlckhvdmVyKTtcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICBlbC5hZGRFdmVudExpc3RlbmVyKCdtb3VzZW91dCcsIChkKSA9PiB7XHJcbiAgICAgICAgICAgICAgICBsZXQgdGFyZ2V0RWxlbWVudDogSFRNTEVsZW1lbnQgPSA8SFRNTEVsZW1lbnQ+ZC50YXJnZXQ7XHJcbiAgICAgICAgICAgICAgICBsZXQgdGFyZ2V0R2VvanNvbklkOiBzdHJpbmcgPSB0aGlzLl9tYXBTdmMuZ2V0VGFyZ2V0R2VvanNvbklkKHRhcmdldEVsZW1lbnQpO1xyXG4gICAgICAgICAgICAgICAgbGV0IGN1cnJlbnRTZWxlY3Rpb24gPSB0aGlzLl9tYXBTdmMuZ2V0Q3VycmVudFNlbGVjdGlvbih0aGlzLnN2Z0NvbnRhaW5lciwgdGFyZ2V0RWxlbWVudC5nZXRBdHRyaWJ1dGUoJ2lkJykpO1xyXG4gICAgICAgICAgICAgICAgaWYgKHRoaXMuX2NoZWNrRW1wdHlEYXRhVmFsdWUodGFyZ2V0R2VvanNvbklkKSkge1xyXG4gICAgICAgICAgICAgICAgICAgIGlmICh0aGlzLmNoYXJ0VHlwZVsxXSAhPT0gJ2ZpbHRlcicgfHwgKHRoaXMuY2hhcnRUeXBlWzFdID09PSAnZmlsdGVyJyAmJiAhdGhpcy5fY2hlY2tNYXBTZWxlY3RlZCh0YXJnZXRHZW9qc29uSWQpKSkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBjdXJyZW50U2VsZWN0aW9uLnN0eWxlKCdmaWxsJywgKGQyKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gdGhpcy5fZ2V0TWFwRmlsbENvbG9yKGQyKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIGlmICh0aGlzLmNoYXJ0VHlwZVsxXSA9PT0gJ2ZpbHRlcicgJiYgdGhpcy5jb25maWcucGxvdE9wdGlvbnMubWFwLmZpbHRlciAmJiB0aGlzLmNvbmZpZy5wbG90T3B0aW9ucy5tYXAuZmlsdGVyLmJvcmRlciAmJiAhdGhpcy5fY2hlY2tNYXBTZWxlY3RlZCh0YXJnZXRFbGVtZW50LmdldEF0dHJpYnV0ZSgnaWQnKSkpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgY3VycmVudFNlbGVjdGlvbi5zdHlsZSgnc3Ryb2tlLXdpZHRoJywgdGhpcy5jb25maWcucGxvdE9wdGlvbnMubWFwLmZpbHRlci5ib3JkZXIpO1xyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgIGVsLmFkZEV2ZW50TGlzdGVuZXIoJ2NsaWNrJywgKGQpID0+IHtcclxuICAgICAgICAgICAgICAgIGxldCB0YXJnZXRFbGVtZW50OiBIVE1MRWxlbWVudCA9IDxIVE1MRWxlbWVudD5kLnRhcmdldDtcclxuICAgICAgICAgICAgICAgIGxldCB0YXJnZXRHZW9qc29uSWQ6IHN0cmluZyA9IHRoaXMuX21hcFN2Yy5nZXRUYXJnZXRHZW9qc29uSWQodGFyZ2V0RWxlbWVudCk7XHJcbiAgICAgICAgICAgICAgICBsZXQgY3VycmVudFNlbGVjdGlvbiA9IHRoaXMuX21hcFN2Yy5nZXRDdXJyZW50U2VsZWN0aW9uKHRoaXMuc3ZnQ29udGFpbmVyLCB0YXJnZXRFbGVtZW50LmdldEF0dHJpYnV0ZSgnaWQnKSk7XHJcbiAgICAgICAgICAgICAgICBpZiAoKHRoaXMuY2hhcnRUeXBlWzFdID09PSAnZnVsbCcgJiYgdGhpcy5jb25maWcucGxvdE9wdGlvbnMubWFwLm1hcEZ1bGxDaGFuZ2VMZXZlbERlZmF1bHQgPT09IHRydWUpIHx8IHRoaXMuY2hhcnRUeXBlWzFdICE9PSAnZnVsbCcpIHtcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLm91dHB1dERhdGEuZW1pdChjdXJyZW50U2VsZWN0aW9uLmF0dHIoJ2NsYXNzJykpO1xyXG4gICAgICAgICAgICAgICAgICAgIGlmICh0aGlzLmNoYXJ0VHlwZVsxXSA9PT0gJ2ZpbHRlcicpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgbGV0IHNldENsaWNrQm9yZGVyQ29uZGl0aW9uOiBib29sZWFuID0gKHRoaXMuY29uZmlnLnBsb3RPcHRpb25zLm1hcC5maWx0ZXIgJiYgdGhpcy5jb25maWcucGxvdE9wdGlvbnMubWFwLmZpbHRlci5ib3JkZXJTZWxlY3RlZCAmJiB0aGlzLmNvbmZpZy5wbG90T3B0aW9ucy5tYXAuZmlsdGVyLmJvcmRlclNlbGVjdGVkICE9IHVuZGVmaW5lZCk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC8vY2hhbmdlIHRoZSBjb2xvciBmb3IgdGhlIGFyZWEgc2VsZWN0ZWRcclxuICAgICAgICAgICAgICAgICAgICAgICAgaWYgKHRoaXMuY29uZmlnLnBsb3RPcHRpb25zLm1hcC5zdGF0ZXMgJiYgdGhpcy5jb25maWcucGxvdE9wdGlvbnMubWFwLnN0YXRlcy5zZWxlY3QgJiYgdGhpcy5jb25maWcucGxvdE9wdGlvbnMubWFwLnN0YXRlcy5zZWxlY3QuY29sb3IgJiYgdGhpcy5jb25maWcucGxvdE9wdGlvbnMubWFwLnN0YXRlcy5zZWxlY3QuY29sb3IgIT09ICcnKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAoT2JqZWN0LmtleXModGhpcy5faXNNYXBTZWxlY3RlZCkubGVuZ3RoICE9PSAwKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbGV0IHByZXZpb3VzQXJlYUlkID0gT2JqZWN0LmtleXModGhpcy5faXNNYXBTZWxlY3RlZClbMF07XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZDMuc2VsZWN0KCcjJyArIHRoaXMuY29uZmlnLmlkICsgJy5rZHgtY2hhcnRzIHN2ZyAubGVhZmxldC16b29tLWhpZGUnKS5zZWxlY3QoJyMnICsgdGhpcy5fbWFwU3ZjLnBhdGhJZFByZWZpeCArIHByZXZpb3VzQXJlYUlkKS5zdHlsZSgnZmlsbCcsIChkMikgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gdGhpcy5fZ2V0TWFwRmlsbENvbG9yKGQyKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAoc2V0Q2xpY2tCb3JkZXJDb25kaXRpb24pIGQzLnNlbGVjdCgnIycgKyB0aGlzLmNvbmZpZy5pZCArICcua2R4LWNoYXJ0cyBzdmcgLmxlYWZsZXQtem9vbS1oaWRlJykuc2VsZWN0KCcjJyArIHRoaXMuX21hcFN2Yy5wYXRoSWRQcmVmaXggKyBwcmV2aW91c0FyZWFJZCkuc3R5bGUoJ3N0cm9rZS13aWR0aCcsIHRoaXMuY29uZmlnLnBsb3RPcHRpb25zLm1hcC5maWx0ZXIuYm9yZGVyKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0aGlzLl9pc01hcFNlbGVjdGVkID0ge307XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKHByZXZpb3VzQXJlYUlkICE9PSB0YXJnZXRHZW9qc29uSWQpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5faXNNYXBTZWxlY3RlZFt0YXJnZXRHZW9qc29uSWRdID0gdGFyZ2V0R2VvanNvbklkO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjdXJyZW50U2VsZWN0aW9uLnN0eWxlKCdmaWxsJywgdGhpcy5jb25maWcucGxvdE9wdGlvbnMubWFwLnN0YXRlcy5zZWxlY3QuY29sb3IpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAoc2V0Q2xpY2tCb3JkZXJDb25kaXRpb24pIGN1cnJlbnRTZWxlY3Rpb24uc3R5bGUoJ3N0cm9rZS13aWR0aCcsIHRoaXMuY29uZmlnLnBsb3RPcHRpb25zLm1hcC5maWx0ZXIuYm9yZGVyU2VsZWN0ZWQpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5faXNNYXBTZWxlY3RlZCA9IHt9O1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuX2lzTWFwU2VsZWN0ZWRbdGFyZ2V0R2VvanNvbklkXSA9IHRhcmdldEdlb2pzb25JZDtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjdXJyZW50U2VsZWN0aW9uLnN0eWxlKCdmaWxsJywgdGhpcy5jb25maWcucGxvdE9wdGlvbnMubWFwLnN0YXRlcy5zZWxlY3QuY29sb3IpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmIChzZXRDbGlja0JvcmRlckNvbmRpdGlvbikgY3VycmVudFNlbGVjdGlvbi5zdHlsZSgnc3Ryb2tlLXdpZHRoJywgdGhpcy5jb25maWcucGxvdE9wdGlvbnMubWFwLmZpbHRlci5ib3JkZXJTZWxlY3RlZCk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgICAgIGlmICh0aGlzLl9jaGVja0VtcHR5RGF0YVZhbHVlKHRhcmdldEdlb2pzb25JZCkpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5fY2hhbmdlTGV2ZWwodGhpcy5fbGV2ZWwsICdhZGQnKTtcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH0pO1xyXG4gICAgICAgIH0pO1xyXG4gICAgICAgIC8vIFJlcG9zaXRpb24gdGhlIFNWRyB0byBjb3ZlciB0aGUgZmVhdHVyZXMuXHJcbiAgICAgICAgZnVuY3Rpb24gcmVzZXQoKSB7XHJcbiAgICAgICAgICAgIGxldCBib3VuZHMgPSBwYXRoLmJvdW5kcyhtYXBMZXZlbCksXHJcbiAgICAgICAgICAgICAgICB0b3BMZWZ0ID0gYm91bmRzWzBdLFxyXG4gICAgICAgICAgICAgICAgYm90dG9tUmlnaHQgPSBib3VuZHNbMV07XHJcbiAgICAgICAgICAgIC8vIGNvbnNvbGUubG9nKCd3aWR0aCAnLCBKU09OLnBhcnNlKEpTT04uc3RyaW5naWZ5KGJvdHRvbVJpZ2h0WzBdIC0gdG9wTGVmdFswXSkpKVxyXG4gICAgICAgICAgICBzdmcuYXR0cihcIndpZHRoXCIsIGJvdHRvbVJpZ2h0WzBdIC0gdG9wTGVmdFswXSlcclxuICAgICAgICAgICAgICAgIC5hdHRyKFwiaGVpZ2h0XCIsIGJvdHRvbVJpZ2h0WzFdIC0gdG9wTGVmdFsxXSlcclxuICAgICAgICAgICAgICAgIC5zdHlsZShcImxlZnRcIiwgdG9wTGVmdFswXSArIFwicHhcIilcclxuICAgICAgICAgICAgICAgIC5zdHlsZShcInRvcFwiLCB0b3BMZWZ0WzFdICsgXCJweFwiKTtcclxuXHJcbiAgICAgICAgICAgIGlmICghZDMuc2VsZWN0KCcjJyArIGN1cnJlbnRDaGFydElkICsgJy5rZHgtY2hhcnRzIHN2ZyAubGVhZmxldC16b29tLWhpZGUnKS5zZWxlY3QoJyNiYWNrQnRuJykuZW1wdHkoKSkge1xyXG4gICAgICAgICAgICAgICAgZDMuc2VsZWN0KCcjJyArIGN1cnJlbnRDaGFydElkICsgJy5rZHgtY2hhcnRzIHN2ZyAubGVhZmxldC16b29tLWhpZGUnKS5zZWxlY3QoJyNiYWNrQnRuJykuYXR0cigndHJhbnNmb3JtJywgZnVuY3Rpb24oKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuICd0cmFuc2xhdGUoJyArICh3aWR0aCAtIDEwMCAtIHBhcnNlSW50KHRvcExlZnRbMF0pKSArICcsJyArIChoZWlnaHQgLyAzIC0gcGFyc2VJbnQodG9wTGVmdFsxXSkpICsgJyknO1xyXG4gICAgICAgICAgICAgICAgfSlcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBtYXBMYXllci5hdHRyKFwidHJhbnNmb3JtXCIsIFwidHJhbnNsYXRlKFwiICsgLXRvcExlZnRbMF0gKyBcIixcIiArIC10b3BMZWZ0WzFdICsgXCIpXCIpO1xyXG4gICAgICAgICAgICBtYXBQYXRoLmF0dHIoXCJkXCIsIHBhdGgpO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgbGV0IGV2ZW50c1BhcmFtID0ge1xyXG4gICAgICAgICAgICAnc2VyaWVzRGF0YSc6IHRoaXMuX291dHB1dFNlcmllc0RhdGEsXHJcbiAgICAgICAgICAgICdzZXJpZXNOYW1lJzogdGhpcy5fc2VyaWVzUG9pbnRlci5uYW1lLFxyXG4gICAgICAgICAgICAndG9vbHRpcExheWVyJzogZDMuc2VsZWN0KHRoaXMuX2xlYWZsZXRNYXAuZ2V0UGFuZXMoKS5vdmVybGF5UGFuZSksXHJcbiAgICAgICAgICAgICdmdWxsR3JhcGgnOiB0aGlzLl9mdWxsR3JhcGhcclxuICAgICAgICB9O1xyXG4gICAgICAgIGlmICh0aGlzLmNvbmZpZy5jb2xvckF4aXMgIT0gdW5kZWZpbmVkICYmIHRoaXMuY29uZmlnLmNvbG9yQXhpcy5kYXRhQ2xhc3NlcyA9PSB1bmRlZmluZWQpIHtcclxuICAgICAgICAgICAgZXZlbnRzUGFyYW1bJ2NhbGxiYWNrcyddID0ge1xyXG4gICAgICAgICAgICAgICAgJ21vdXNlb3Zlcic6IChkKSA9PiB0aGlzLl9zZXRNYXBTY2FsZVRyaWFuZ2xlKGQpLFxyXG4gICAgICAgICAgICAgICAgJ21vdXNlb3V0JzogKCkgPT4gdGhpcy5fcmVtb3ZlTWFwU2NhbGVUcmlhbmdsZSgpXHJcbiAgICAgICAgICAgIH07XHJcbiAgICAgICAgfVxyXG4gICAgICAgIC8vIGFkZCB0b29sdG9wXHJcbiAgICAgICAgaWYgKHRoaXMuX3Nlcmllc1BvaW50ZXIuZGF0YSAhPSB1bmRlZmluZWQpIHtcclxuICAgICAgICAgICAgc3VwZXIuX2luaXRNb3VzZUV2ZW50cyhtYXBQYXRoLCBldmVudHNQYXJhbSk7XHJcbiAgICAgICAgfVxyXG5cclxuXHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfZHJhd1BvbHlnb25NYXAoKTogdm9pZCB7XHJcbiAgICAgICAgdGhpcy5fb3V0cHV0U2VyaWVzRGF0YSA9IFtdO1xyXG4gICAgICAgIHRoaXMuX3BhdGggPSB0aGlzLmdyYXBoLmF0dHIoJ3dpZHRoJywgdGhpcy5fd2lkdGgpLmF0dHIoJ2hlaWdodCcsIHRoaXMuX2hlaWdodCk7XHJcblxyXG4gICAgICAgIHRoaXMuX21hcExheWVyID0gdGhpcy5fcGF0aC5hcHBlbmQoJ2cnKS5jbGFzc2VkKCdtYXAtbGF5ZXInLCB0cnVlKTtcclxuICAgICAgICBpZiAodGhpcy5jb25maWcubWFwTmF2aWdhdGlvbiAmJiB0aGlzLmNvbmZpZy5tYXBOYXZpZ2F0aW9uLmVuYWJsZWQgPT0gdHJ1ZSkge1xyXG4gICAgICAgICAgICBpZiAodHlwZW9mIHRoaXMuX3pvb21CdG5zID09PSAndW5kZWZpbmVkJykgdGhpcy5faW5pdFpvb21CdG4oKTtcclxuICAgICAgICB9XHJcbiAgICAgICAgLy8gdGhpcy5fY2hlY2tCYWNrQnRuKCk7XHJcbiAgICAgICAgaWYgKHRoaXMuY29uZmlnLnBsb3RPcHRpb25zLm1hcC5sZXZlbCAmJiAodGhpcy5jb25maWcucGxvdE9wdGlvbnMubWFwLmxldmVsICE9PSAnJyB8fCB0aGlzLmNvbmZpZy5wbG90T3B0aW9ucy5tYXAubGV2ZWwgIT09IHVuZGVmaW5lZCB8fCB0aGlzLmNvbmZpZy5wbG90T3B0aW9ucy5tYXAubGV2ZWwgIT09IG51bGwpICYmIHRoaXMuX21hcFN2Yy5jaGVja01hcExldmVsRXhpc3QodGhpcy5jb25maWcucGxvdE9wdGlvbnMubWFwLmxldmVsLCB0aGlzLmRhdGEubWFwRGF0YSkpIHtcclxuICAgICAgICAgICAgaWYgKHRoaXMuY2hhcnRUeXBlWzFdID09PSAndGhlbWF0aWMnKSB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLl9sZXZlbCA9IHRoaXMuY29uZmlnLnBsb3RPcHRpb25zLm1hcC5sZXZlbDtcclxuICAgICAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgICAgIHRoaXMuX2NoZWNrQmFja0J0bigpO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfSBlbHNlIGlmICh0aGlzLmNoYXJ0VHlwZVsxXSA9PT0gJ3BvbHlnb24nKSB7XHJcbiAgICAgICAgICAgIHRoaXMuX2NoZWNrQmFja0J0bigpO1xyXG4gICAgICAgIH1cclxuICAgICAgICBsZXQgZGF0YSA9IHRoaXMuZGF0YS5tYXBEYXRhLmhhc093blByb3BlcnR5KHRoaXMuX2xldmVsKSA/IHRoaXMuZGF0YS5tYXBEYXRhW3RoaXMuX2xldmVsXSA6IHRoaXMuZGF0YS5tYXBEYXRhO1xyXG4gICAgICAgIGxldCBwcm9qZWN0aW9uID0gZDMuZ2VvTWVyY2F0b3IoKS5maXRTaXplKFt0aGlzLl93aWR0aCwgdGhpcy5faGVpZ2h0IC0gNTBdLCBkYXRhKTtcclxuICAgICAgICBsZXQgcGF0aCA9IGQzLmdlb1BhdGgoKS5wcm9qZWN0aW9uKHByb2plY3Rpb24pO1xyXG4gICAgICAgIGxldCBmZWF0dXJlcyA9IHRoaXMuZGF0YS5tYXBEYXRhLmhhc093blByb3BlcnR5KCdmZWF0dXJlcycpID8gdGhpcy5kYXRhLm1hcERhdGEuZmVhdHVyZXMgOiB0aGlzLmRhdGEubWFwRGF0YVt0aGlzLl9sZXZlbF0uZmVhdHVyZXM7XHJcbiAgICAgICAgbGV0IG1hcFBhdGggPSB0aGlzLl9tYXBMYXllci5zZWxlY3RBbGwoJ3BhdGgnKVxyXG4gICAgICAgICAgICAuZGF0YShmZWF0dXJlcylcclxuICAgICAgICAgICAgLmVudGVyKCkuYXBwZW5kKCdwYXRoJylcclxuICAgICAgICAgICAgLmF0dHIoJ2QnLCBwYXRoKVxyXG4gICAgICAgICAgICAuYXR0cignaWQnLCAoZCkgPT4geyByZXR1cm4gdGhpcy5fbWFwU3ZjLnBhdGhJZFByZWZpeCArIGQucHJvcGVydGllcy5JRF87IH0pXHJcbiAgICAgICAgICAgIC5hdHRyKCdjbGFzcycsIChkKSA9PiB7XHJcbiAgICAgICAgICAgICAgICBpZiAodGhpcy5fZW1wdHlTZXJpZXMgPT0gZmFsc2UgJiYgdGhpcy5fc2VyaWVzUG9pbnRlciAmJiB0aGlzLl9zZXJpZXNQb2ludGVyLmRhdGEgIT0gdW5kZWZpbmVkKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgbGV0IHNlcmllc1ZhbHVlID0gdGhpcy5fZ2V0U2VyaWVzVmFsdWUoZC5wcm9wZXJ0aWVzLklEXyk7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5fb3V0cHV0U2VyaWVzRGF0YS5wdXNoKHsgJ25hbWUnOiBzZXJpZXNWYWx1ZS5uYW1lLCAndmFsdWUnOiBzZXJpZXNWYWx1ZS52YWx1ZSwgJ2lkJzogZC5wcm9wZXJ0aWVzLklEXyB9KTtcclxuICAgICAgICAgICAgICAgICAgICByZXR1cm4gJ2lkLScgKyBzZXJpZXNWYWx1ZS5pZCArICcsIG5hbWUtJyArIHNlcmllc1ZhbHVlLm5hbWUgKyAnLCBkcmlsbGRvd24tJyArIHNlcmllc1ZhbHVlLmRyaWxsZG93biArICcsIHZhbHVlLScgKyBzZXJpZXNWYWx1ZS52YWx1ZTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfSlcclxuICAgICAgICAgICAgLmF0dHIoJ3ZlY3Rvci1lZmZlY3QnLCAnbm9uLXNjYWxpbmctc3Ryb2tlJylcclxuICAgICAgICAgICAgLnN0eWxlKCdmaWxsJywgKGQpID0+IHtcclxuICAgICAgICAgICAgICAgIHJldHVybiB0aGlzLl9nZXRNYXBGaWxsQ29sb3IoZCk7XHJcbiAgICAgICAgICAgIH0pXHJcbiAgICAgICAgICAgIC5zdHlsZSgnc3Ryb2tlLXdpZHRoJywgdGhpcy5jb25maWcucGxvdE9wdGlvbnMubWFwLmJvcmRlcldpZHRoKVxyXG4gICAgICAgICAgICAuc3R5bGUoJ3N0cm9rZScsIHRoaXMuY29uZmlnLnBsb3RPcHRpb25zLm1hcC5ib3JkZXJDb2xvcik7XHJcblxyXG4gICAgICAgIC8vIGFkZGluZyBtb3VzZSBldmVudHMsIGhvdmVyIGNvbG9yLCBjaGFuZ2UgbGV2ZWxcclxuICAgICAgICBpZiAodGhpcy5fZW1wdHlTZXJpZXMgPT0gZmFsc2UpIHtcclxuICAgICAgICAgICAgbGV0IGVsZW1lbnRzID0gQXJyYXkuZnJvbShkb2N1bWVudC5xdWVyeVNlbGVjdG9yQWxsKCcjJyArIHRoaXMuY29uZmlnLmlkICsgJy5rZHgtY2hhcnRzIHN2ZyAubWFwLWxheWVyJykpO1xyXG4gICAgICAgICAgICBlbGVtZW50cy5mb3JFYWNoKChlbCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgZWwuYWRkRXZlbnRMaXN0ZW5lcignbW91c2VvdmVyJywgKGQpID0+IHtcclxuICAgICAgICAgICAgICAgICAgICBsZXQgdGFyZ2V0RWxlbWVudDogSFRNTEVsZW1lbnQgPSA8SFRNTEVsZW1lbnQ+ZC50YXJnZXQ7XHJcbiAgICAgICAgICAgICAgICAgICAgbGV0IHRhcmdldEVsZW1lbnRJZDogc3RyaW5nID0gdGFyZ2V0RWxlbWVudC5nZXRBdHRyaWJ1dGUoJ2lkJykuaW5kZXhPZignaWQtJykgIT0gLTEgPyB0YXJnZXRFbGVtZW50LmdldEF0dHJpYnV0ZSgnaWQnKS5zcGxpdCgnaWQtJylbMV0gOiB0YXJnZXRFbGVtZW50LmdldEF0dHJpYnV0ZSgnaWQnKTtcclxuICAgICAgICAgICAgICAgICAgICBsZXQgY3VycmVudFNlbGVjdGlvbiA9IHRoaXMuX21hcFN2Yy5nZXRDdXJyZW50U2VsZWN0aW9uKHRoaXMuc3ZnQ29udGFpbmVyLCB0YXJnZXRFbGVtZW50LmdldEF0dHJpYnV0ZSgnaWQnKSwgJ2QzJyk7XHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKHRoaXMuX2NoZWNrRW1wdHlEYXRhVmFsdWUodGFyZ2V0RWxlbWVudElkKSkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBjdXJyZW50U2VsZWN0aW9uLnN0eWxlKCdmaWxsJywgdGhpcy5jb25maWcucGxvdE9wdGlvbnMubWFwLnN0YXRlcy5ob3Zlci5jb2xvcik7XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgICAgICBlbC5hZGRFdmVudExpc3RlbmVyKCdtb3VzZW91dCcsIChkKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgbGV0IHRhcmdldEVsZW1lbnQ6IEhUTUxFbGVtZW50ID0gPEhUTUxFbGVtZW50PmQudGFyZ2V0O1xyXG4gICAgICAgICAgICAgICAgICAgIGxldCB0YXJnZXRFbGVtZW50SWQ6IHN0cmluZyA9IHRhcmdldEVsZW1lbnQuZ2V0QXR0cmlidXRlKCdpZCcpLmluZGV4T2YoJ2lkLScpICE9IC0xID8gdGFyZ2V0RWxlbWVudC5nZXRBdHRyaWJ1dGUoJ2lkJykuc3BsaXQoJ2lkLScpWzFdIDogdGFyZ2V0RWxlbWVudC5nZXRBdHRyaWJ1dGUoJ2lkJyk7XHJcbiAgICAgICAgICAgICAgICAgICAgbGV0IGN1cnJlbnRTZWxlY3Rpb24gPSB0aGlzLl9tYXBTdmMuZ2V0Q3VycmVudFNlbGVjdGlvbih0aGlzLnN2Z0NvbnRhaW5lciwgdGFyZ2V0RWxlbWVudC5nZXRBdHRyaWJ1dGUoJ2lkJyksICdkMycpO1xyXG4gICAgICAgICAgICAgICAgICAgIGlmICh0aGlzLl9jaGVja0VtcHR5RGF0YVZhbHVlKHRhcmdldEVsZW1lbnRJZCkpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgY3VycmVudFNlbGVjdGlvbi5zdHlsZSgnZmlsbCcsIChkMikgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIHRoaXMuX2dldE1hcEZpbGxDb2xvcihkMik7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICAgICAgZWwuYWRkRXZlbnRMaXN0ZW5lcignY2xpY2snLCAoZCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgIGlmICh0aGlzLmNoYXJ0VHlwZVsxXSA9PT0gJ3BvbHlnb24nKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGxldCB0YXJnZXRFbGVtZW50OiBIVE1MRWxlbWVudCA9IDxIVE1MRWxlbWVudD5kLnRhcmdldDtcclxuICAgICAgICAgICAgICAgICAgICAgICAgbGV0IHRhcmdldEdlb2pzb25JZDogc3RyaW5nID0gdGhpcy5fbWFwU3ZjLmdldFRhcmdldEdlb2pzb25JZCh0YXJnZXRFbGVtZW50KTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgaWYgKHRoaXMuX2NoZWNrRW1wdHlEYXRhVmFsdWUodGFyZ2V0R2VvanNvbklkKSkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5fY2hhbmdlTGV2ZWwodGhpcy5fbGV2ZWwsICdhZGQnKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICB9KTtcclxuXHJcbiAgICAgICAgICAgIGxldCBldmVudHNQYXJhbSA9IHtcclxuICAgICAgICAgICAgICAgICdzZXJpZXNEYXRhJzogdGhpcy5fb3V0cHV0U2VyaWVzRGF0YSxcclxuICAgICAgICAgICAgICAgICdzZXJpZXNOYW1lJzogdGhpcy5fc2VyaWVzUG9pbnRlci5uYW1lLFxyXG4gICAgICAgICAgICB9O1xyXG4gICAgICAgICAgICBpZiAodGhpcy5jb25maWcuY29sb3JBeGlzICE9IHVuZGVmaW5lZCAmJiB0aGlzLmNvbmZpZy5jb2xvckF4aXMuZGF0YUNsYXNzZXMgPT0gdW5kZWZpbmVkKSB7XHJcbiAgICAgICAgICAgICAgICBldmVudHNQYXJhbVsnY2FsbGJhY2tzJ10gPSB7XHJcbiAgICAgICAgICAgICAgICAgICAgJ21vdXNlb3Zlcic6IChkKSA9PiB0aGlzLl9zZXRNYXBTY2FsZVRyaWFuZ2xlKGQpLFxyXG4gICAgICAgICAgICAgICAgICAgICdtb3VzZW91dCc6ICgpID0+IHRoaXMuX3JlbW92ZU1hcFNjYWxlVHJpYW5nbGUoKVxyXG4gICAgICAgICAgICAgICAgfTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAvLyBhZGQgdG9vbHRvcFxyXG4gICAgICAgICAgICBpZiAodGhpcy5fc2VyaWVzUG9pbnRlci5kYXRhICE9IHVuZGVmaW5lZCkge1xyXG4gICAgICAgICAgICAgICAgc3VwZXIuX2luaXRNb3VzZUV2ZW50cyhtYXBQYXRoLCBldmVudHNQYXJhbSk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfZ2V0TWFwRmlsbENvbG9yKF92YWx1ZTogYW55KTogc3RyaW5nIHtcclxuICAgICAgICBpZiAodGhpcy5fc2VyaWVzUG9pbnRlciA9PSB1bmRlZmluZWQgfHwgdGhpcy5fc2VyaWVzUG9pbnRlci5kYXRhID09IHVuZGVmaW5lZCkgcmV0dXJuICcjRjJGMkYyJztcclxuXHJcbiAgICAgICAgbGV0IGRhdGFWYWx1ZSA9IHRoaXMuX2dldFNlcmllc1ZhbHVlKF92YWx1ZS5wcm9wZXJ0aWVzLklEXykudmFsdWU7XHJcblxyXG4gICAgICAgIGlmICh0aGlzLmNoYXJ0VHlwZVsxXSA9PT0gJ2ZpbHRlcicgJiYgdGhpcy5jb25maWcuY29sb3JBeGlzICYmIHRoaXMuY29uZmlnLmNvbG9yQXhpcy5taW5Db2xvcikge1xyXG4gICAgICAgICAgICByZXR1cm4gdGhpcy5jb25maWcuY29sb3JBeGlzLm1pbkNvbG9yO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgaWYgKGRhdGFWYWx1ZSA9PSBudWxsIHx8IGRhdGFWYWx1ZSA9PSAnJykgcmV0dXJuIHRoaXMuY29uZmlnLnBsb3RPcHRpb25zLm1hcC5udWxsQ29sb3IgfHwgJ3JnYigwLDAsMCwwKSc7XHJcblxyXG4gICAgICAgIGlmICh0aGlzLmNvbmZpZy5jb2xvckF4aXMgIT0gdW5kZWZpbmVkICYmIHRoaXMuY29uZmlnLmNvbG9yQXhpcy5kYXRhQ2xhc3NlcyA9PSB1bmRlZmluZWQpIHtcclxuICAgICAgICAgICAgcmV0dXJuIHRoaXMuX21hcFNjYWxlQ29sb3JTY2FsZShkYXRhVmFsdWUpO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgaWYgKHRoaXMuX3NpbmdsZUxldmVsRGltZW5zaW9uID09IHRydWUpIHtcclxuICAgICAgICAgICAgZm9yIChsZXQgaSA9IDA7IGkgPCB0aGlzLmNvbmZpZy5jb2xvckF4aXMuZGF0YUNsYXNzZXMubGVuZ3RoOyBpKyspIHtcclxuICAgICAgICAgICAgICAgIGlmICh0aGlzLl9tYXBTdmMuY2hlY2tWYWx1ZUluQmV0d2VlbihOdW1iZXIoZGF0YVZhbHVlKSwgdGhpcy5jb25maWcuY29sb3JBeGlzLmRhdGFDbGFzc2VzW2ldLmZyb20sIHRoaXMuY29uZmlnLmNvbG9yQXhpcy5kYXRhQ2xhc3Nlc1tpXS50bykpIHtcclxuICAgICAgICAgICAgICAgICAgICBpZiAodGhpcy5sZWdlbmRbJ2lkJyArIGldICYmIHRoaXMubGVnZW5kWydpZCcgKyBpXS5kZWFjdGl2ZSA9PSB0cnVlKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiAnI0YyRjJGMic7XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIHJldHVybiB0aGlzLmNvbmZpZy5jb2xvckF4aXMuZGF0YUNsYXNzZXNbaV0uY29sb3I7XHJcbiAgICAgICAgICAgICAgICB9IGVsc2UgaWYgKGkgPT0gdGhpcy5jb25maWcuY29sb3JBeGlzLmRhdGFDbGFzc2VzLmxlbmd0aCkge1xyXG4gICAgICAgICAgICAgICAgICAgIHJldHVybiB0aGlzLmNvbmZpZy5jb2xvckF4aXMubWluQ29sb3I7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIGlmICh0aGlzLl9lbXB0eVNlcmllcyA9PSBmYWxzZSkgcmV0dXJuIHRoaXMuX2NvbG9yUG9pbnRlci5jb2xvcjtcclxuXHJcbiAgICAgICAgcmV0dXJuICcjRjJGMkYyJztcclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF9jaGFuZ2VMZXZlbChfbGV2ZWw6IHN0cmluZywgX3R5cGU6IHN0cmluZyk6IHZvaWQge1xyXG4gICAgICAgIGxldCBtYXBBcnIgPSBPYmplY3Qua2V5cyh0aGlzLmRhdGEubWFwRGF0YSk7XHJcbiAgICAgICAgbGV0IGxldmVsSW5kZXg6IG51bWJlciA9IDAsIG5ld0luZGV4OiBudW1iZXI7XHJcbiAgICAgICAgbGV0IG5ld0xldmVsOiBzdHJpbmc7XHJcbiAgICAgICAgZm9yIChsZXQgaSA9IDA7IGkgPCBtYXBBcnIubGVuZ3RoOyBpKyspIHtcclxuICAgICAgICAgICAgaWYgKG1hcEFycltpXSA9PT0gX2xldmVsKSBsZXZlbEluZGV4ID0gaTtcclxuICAgICAgICB9XHJcbiAgICAgICAgaWYgKF90eXBlID09PSAnYWRkJykge1xyXG4gICAgICAgICAgICBpZiAobGV2ZWxJbmRleCArIDEgPD0gbWFwQXJyLmxlbmd0aCkgbmV3SW5kZXggPSBsZXZlbEluZGV4ICsgMTtcclxuICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICBpZiAobGV2ZWxJbmRleCAtIDEgPj0gMCkgbmV3SW5kZXggPSBsZXZlbEluZGV4IC0gMTtcclxuICAgICAgICB9XHJcbiAgICAgICAgaWYgKG5ld0luZGV4ICE9PSB1bmRlZmluZWQpIHtcclxuICAgICAgICAgICAgbmV3TGV2ZWwgPSBtYXBBcnJbbmV3SW5kZXhdO1xyXG4gICAgICAgICAgICBpZiAodGhpcy5kYXRhLm1hcERhdGFbbmV3TGV2ZWxdICE9IHVuZGVmaW5lZCkge1xyXG4gICAgICAgICAgICAgICAgaWYgKHR5cGVvZiB0aGlzLl9tYXBMYXllciAhPT0gJ3VuZGVmaW5lZCcpIHsgdGhpcy5fbWFwTGF5ZXIucmVtb3ZlKCk7IH1cclxuICAgICAgICAgICAgICAgIHRoaXMuX2xldmVsID0gbmV3TGV2ZWw7XHJcbiAgICAgICAgICAgICAgICB0aGlzLmRhdGFbJ21hcExldmVsJ10gPSB0aGlzLl9sZXZlbDtcclxuICAgICAgICAgICAgICAgIGlmICh0aGlzLmNvbmZpZy5jb2xvckF4aXMgPT0gdW5kZWZpbmVkKSB0aGlzLl9nZXREcmlsbERvd25MZWdlbmRGb3JNdWx0aXBsZURpbWVuc2lvbigpO1xyXG4gICAgICAgICAgICAgICAgdGhpcy5fZ2V0Q29sb3JQb2ludGVyKCk7XHJcbiAgICAgICAgICAgICAgICBpZiAodGhpcy5jaGFydFR5cGVbMV0gPT09ICdmdWxsJykge1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuX2RyYXdGdWxsTWFwKCk7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICBlbHNlIHRoaXMuX2RyYXdQb2x5Z29uTWFwKCk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICAgICAgLy8gbGV0IG9wID0gX3R5cGUgPT0gJ2FkZCcgPyAnKycgOiAnLSc7XHJcbiAgICAgICAgLy8gbGV0IG9wZXJhdG9ycyA9IHtcclxuICAgICAgICAvLyAgICAgJysnOiBmdW5jdGlvbihhLCBiKSB7IHJldHVybiBhICsgYjsgfSxcclxuICAgICAgICAvLyAgICAgJy0nOiBmdW5jdGlvbihhLCBiKSB7IHJldHVybiBhIC0gYjsgfVxyXG4gICAgICAgIC8vIH07XHJcbiAgICAgICAgLy8gbGV0IG5ld0xldmVsUG9pbnRlcjogc3RyaW5nIHwgc3RyaW5nW10gPSBfbGV2ZWwuaW5kZXhPZignXycpICE9IC0xID8gX2xldmVsLnNwbGl0KCdfJykgOiBfbGV2ZWw7XHJcbiAgICAgICAgLy8gbGV0IG5ld0xldmVsOiBzdHJpbmcgPSBfbGV2ZWwuaW5kZXhPZignXycpICE9IC0xID8gbmV3TGV2ZWxQb2ludGVyWzBdICsgJ18nICsgKG9wZXJhdG9yc1tvcF0ocGFyc2VJbnQobmV3TGV2ZWxQb2ludGVyWzFdKSwgMSkpIDogKG9wZXJhdG9yc1tvcF0ocGFyc2VJbnQoX2xldmVsKSwgMSkpLnRvU3RyaW5nKCk7XHJcblxyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX2luaXRab29tQnRuKCk6IHZvaWQge1xyXG4gICAgICAgIC8vIGluc2VydGluZyB0aGUgem9vbSBidXR0b25zXHJcbiAgICAgICAgbGV0IHpvb21lZDogRnVuY3Rpb24gPSAoKSA9PiB7XHJcbiAgICAgICAgICAgIGNvbnN0IHRyYW5zZm9ybSA9IGQzLmV2ZW50LnRyYW5zZm9ybTtcclxuICAgICAgICAgICAgdGhpcy5fbWFwTGF5ZXIuYXR0cigndHJhbnNmb3JtJywgJ3RyYW5zbGF0ZSgnICsgdHJhbnNmb3JtLnggKyAnLCcgKyB0cmFuc2Zvcm0ueSArICcpIHNjYWxlKCcgKyB0cmFuc2Zvcm0uayArICcpJyk7XHJcbiAgICAgICAgfTtcclxuICAgICAgICBsZXQgem9vbSA9IGQzLnpvb20oKS5zY2FsZUV4dGVudChbMSwgNF0pLm9uKCd6b29tJywgem9vbWVkKTtcclxuXHJcbiAgICAgICAgdGhpcy5fem9vbUJ0bnMgPSB0aGlzLmdyYXBoLmFwcGVuZCgnZycpLmNsYXNzZWQoJ3pvb20tbGF5ZXInLCB0cnVlKTtcclxuICAgICAgICBsZXQgem9vbUJ0biA9IHRoaXMuX3pvb21CdG5zLnNlbGVjdEFsbCgnZycpXHJcbiAgICAgICAgICAgIC5kYXRhKFsnem9vbUluJywgJ3pvb21PdXQnXSlcclxuICAgICAgICAgICAgLmVudGVyKCkuYXBwZW5kKCdnJylcclxuICAgICAgICAgICAgLmF0dHIoJ2lkJywgZnVuY3Rpb24oZCkgeyByZXR1cm4gZDsgfSlcclxuICAgICAgICAgICAgLy8gLmF0dHIoJ3RyYW5zZm9ybScsIChkLCBpKSA9PiB7IHJldHVybiAndHJhbnNsYXRlKDEwLCcgKyAoKHRoaXMuX2hlaWdodCAvIDMpICsgKGkgKiAyOCkpICsgJyknOyB9KVxyXG4gICAgICAgICAgICAuYXR0cigndHJhbnNmb3JtJywgKGQsIGkpID0+IHsgcmV0dXJuICd0cmFuc2xhdGUoMTAsJyArICgxMCArIChpICogMzApKSArICcpJzsgfSlcclxuICAgICAgICAgICAgLnN0eWxlKCdjdXJzb3InLCAncG9pbnRlcicpXHJcbiAgICAgICAgICAgIC5vbignY2xpY2snLCAoZCwgaSkgPT4geyB0aGlzLl96b29tQ2xpY2soZCwgem9vbSk7IH0pO1xyXG4gICAgICAgIHpvb21CdG4uYXBwZW5kKCdyZWN0JylcclxuICAgICAgICAgICAgLmF0dHIoJ3dpZHRoJywgJzMwcHgnKVxyXG4gICAgICAgICAgICAuYXR0cignaGVpZ2h0JywgJzMwcHgnKVxyXG4gICAgICAgICAgICAuYXR0cigncngnLCAxKVxyXG4gICAgICAgICAgICAuYXR0cigncnknLCAxKVxyXG4gICAgICAgICAgICAuc3R5bGUoJ3otaW5kZXgnLCAxKVxyXG4gICAgICAgICAgICAuc3R5bGUoJ2ZpbGwnLCAnI2ZmZicpXHJcbiAgICAgICAgICAgIC5zdHlsZSgnc3Ryb2tlJywgJyNjY2MnKVxyXG4gICAgICAgICAgICAuc3R5bGUoJ3N0cm9rZS13aWR0aCcsICcyJyk7XHJcbiAgICAgICAgem9vbUJ0bi5hcHBlbmQoJ3RleHQnKVxyXG4gICAgICAgICAgICAuYXR0cigneCcsIDE0KVxyXG4gICAgICAgICAgICAuYXR0cigneScsIDE0KVxyXG4gICAgICAgICAgICAuYXR0cignZHknLCAnLjM1ZW0nKVxyXG4gICAgICAgICAgICAuYXR0cigndGV4dC1hbmNob3InLCAnbWlkZGxlJylcclxuICAgICAgICAgICAgLnN0eWxlKCdmb250LXNpemUnLCAnMjJweCcpXHJcbiAgICAgICAgICAgIC5zdHlsZSgnZm9udC13ZWlnaHQnLCAnYm9sZCcpXHJcbiAgICAgICAgICAgIC50ZXh0KGZ1bmN0aW9uKGQsIGkpIHsgcmV0dXJuIGkgPT0gMCA/ICcrJyA6ICfiiJInOyB9KTtcclxuXHJcbiAgICAgICAgdGhpcy5fbWFwTGF5ZXIuY2FsbCh6b29tKTtcclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF96b29tQ2xpY2soX3pvb21CdG5JZDogc3RyaW5nLCBfem9vbSk6IHZvaWQge1xyXG4gICAgICAgIGxldCBmYWN0b3IgPSBfem9vbUJ0bklkID09ICd6b29tSW4nID8gMS4yIDogMC44O1xyXG4gICAgICAgIF96b29tLnNjYWxlQnkodGhpcy5fbWFwTGF5ZXIsIGZhY3Rvcik7XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfaW5pdEJhY2tCdG4oKTogdm9pZCB7XHJcbiAgICAgICAgLy8gaW5zZXJ0aW5nIHRoZSBiYWNrIGJ1dHRvblxyXG4gICAgICAgIGlmICh0eXBlb2YgdGhpcy5fYmFja0J0biAhPT0gJ3VuZGVmaW5lZCcpIHtcclxuICAgICAgICAgICAgdGhpcy5fYmFja0J0bi5yZW1vdmUoKTtcclxuICAgICAgICAgICAgdGhpcy5fYmFja0J0biA9IHVuZGVmaW5lZDtcclxuICAgICAgICB9XHJcbiAgICAgICAgc2V0VGltZW91dCgoKSA9PiB7XHJcbiAgICAgICAgICAgIGlmICh0aGlzLmNoYXJ0VHlwZVsxXSAhPT0gJ2Z1bGwnKSB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLl9iYWNrQnRuID0gdGhpcy5ncmFwaC5hcHBlbmQoJ2cnKS5jbGFzc2VkKCdidG4tbGF5ZXInLCB0cnVlKTtcclxuICAgICAgICAgICAgICAgIGxldCBiYWNrQnRuVHJhbnNsYXRlUG9zaXRpb246IHN0cmluZyA9ICcnO1xyXG4gICAgICAgICAgICAgICAgaWYgKHRoaXMuY2hhcnRUeXBlWzFdICE9PSAnZnVsbCcpIHtcclxuICAgICAgICAgICAgICAgICAgICBiYWNrQnRuVHJhbnNsYXRlUG9zaXRpb24gPSAndHJhbnNsYXRlKCcgKyAodGhpcy5fd2lkdGggLSAxMDApICsgJywnICsgKHRoaXMuX2hlaWdodCAvIDMpICsgJyknO1xyXG4gICAgICAgICAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgICAgICAgICBiYWNrQnRuVHJhbnNsYXRlUG9zaXRpb24gPSAndHJhbnNsYXRlKCcgKyAodGhpcy5fd2lkdGggLSAxMDAgLSBwYXJzZUludCh0aGlzLl9mdWxsR3JhcGgubm9kZSgpLnN0eWxlLmxlZnQpKSArICcsJyArICh0aGlzLl9oZWlnaHQgLyAzIC0gcGFyc2VJbnQodGhpcy5fZnVsbEdyYXBoLm5vZGUoKS5zdHlsZS50b3ApKSArICcpJztcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIGxldCBiYWNrQnRuID0gdGhpcy5fYmFja0J0bi5zZWxlY3RBbGwoJ2cnKVxyXG4gICAgICAgICAgICAgICAgICAgIC5kYXRhKFsnYmFja0J0biddKVxyXG4gICAgICAgICAgICAgICAgICAgIC5lbnRlcigpLmFwcGVuZCgnZycpXHJcbiAgICAgICAgICAgICAgICAgICAgLmF0dHIoJ2lkJywgZnVuY3Rpb24oZCkgeyByZXR1cm4gZDsgfSlcclxuICAgICAgICAgICAgICAgICAgICAuYXR0cigndHJhbnNmb3JtJywgKGQsIGkpID0+IHsgcmV0dXJuIGJhY2tCdG5UcmFuc2xhdGVQb3NpdGlvbjsgfSlcclxuICAgICAgICAgICAgICAgICAgICAuc3R5bGUoJ2N1cnNvcicsICdwb2ludGVyJylcclxuICAgICAgICAgICAgICAgICAgICAuc3R5bGUoJ3BvaW50ZXItZXZlbnRzJywgJ3Zpc2libGUnKVxyXG4gICAgICAgICAgICAgICAgICAgIC5vbignY2xpY2snLCAoZCkgPT4geyB0aGlzLl9jaGFuZ2VMZXZlbCh0aGlzLl9sZXZlbCwgJ21pbnVzJyk7IH0pO1xyXG4gICAgICAgICAgICAgICAgYmFja0J0bi5hcHBlbmQoJ3JlY3QnKVxyXG4gICAgICAgICAgICAgICAgICAgIC5hdHRyKCd3aWR0aCcsICc1NnB4JylcclxuICAgICAgICAgICAgICAgICAgICAuYXR0cignaGVpZ2h0JywgJzMwcHgnKVxyXG4gICAgICAgICAgICAgICAgICAgIC5zdHlsZSgnZmlsbCcsICdyZ2IoMjQ3LCAyNDcsIDI0NyknKVxyXG4gICAgICAgICAgICAgICAgICAgIC5zdHlsZSgnc3Ryb2tlJywgJ3JnYigyMDQsIDIwNCwgMjA0KScpXHJcbiAgICAgICAgICAgICAgICAgICAgLnN0eWxlKCdzdHJva2Utd2lkdGgnLCAnMScpO1xyXG4gICAgICAgICAgICAgICAgYmFja0J0bi5hcHBlbmQoJ3RleHQnKVxyXG4gICAgICAgICAgICAgICAgICAgIC5hdHRyKCd4JywgMjgpXHJcbiAgICAgICAgICAgICAgICAgICAgLmF0dHIoJ3knLCAxNSlcclxuICAgICAgICAgICAgICAgICAgICAuYXR0cignZHknLCAnLjM1ZW0nKVxyXG4gICAgICAgICAgICAgICAgICAgIC5hdHRyKCd0ZXh0LWFuY2hvcicsICdtaWRkbGUnKVxyXG4gICAgICAgICAgICAgICAgICAgIC5zdHlsZSgnZm9udC1zaXplJywgJzEycHgnKVxyXG4gICAgICAgICAgICAgICAgICAgIC5zdHlsZSgnZm9udC13ZWlnaHQnLCAnbm9ybWFsJylcclxuICAgICAgICAgICAgICAgICAgICAudGV4dChmdW5jdGlvbihkLCBpKSB7IHJldHVybiB0aGlzLmlzUnRsID8gJ0JhY2sg4pa3JyA6ICfil4EgQmFjayc7IH0pO1xyXG4gICAgICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5fYmFja0J0biA9IHRoaXMuc3ZnQ29udGFpbmVyLmFwcGVuZCgnZGl2JylcclxuICAgICAgICAgICAgICAgIHRoaXMuX2JhY2tCdG4uYXR0cignY2xhc3MnLCAna2R4LW1hcC1jaGFydC1iYWNrYnV0dG9uJylcclxuICAgICAgICAgICAgICAgIHRoaXMuX2JhY2tCdG4udGV4dChmdW5jdGlvbihkLCBpKSB7IHJldHVybiB0aGlzLmlzUnRsID8gJ0JhY2sg4pa3JyA6ICfil4EgQmFjayc7IH0pXHJcbiAgICAgICAgICAgICAgICB0aGlzLl9iYWNrQnRuLm9uKCdjbGljaycsIChkKSA9PiB7IHRoaXMuX2NoYW5nZUxldmVsKHRoaXMuX2xldmVsLCAnbWludXMnKTsgfSk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9KVxyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX2NoZWNrQmFja0J0bigpOiB2b2lkIHtcclxuICAgICAgICBsZXQgY2hlY2tEZWZhdWx0TGV2ZWwgPSB0aGlzLl9jaGVja0RlZmF1bHRMZXZlbCgpO1xyXG4gICAgICAgIGlmIChjaGVja0RlZmF1bHRMZXZlbCA9PSB0cnVlKSB7XHJcbiAgICAgICAgICAgIGlmICh0eXBlb2YgdGhpcy5fYmFja0J0biA9PT0gJ3VuZGVmaW5lZCcpIHRoaXMuX2luaXRCYWNrQnRuKCk7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICBpZiAodHlwZW9mIHRoaXMuX2JhY2tCdG4gIT09ICd1bmRlZmluZWQnKSB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLl9iYWNrQnRuLnJlbW92ZSgpO1xyXG4gICAgICAgICAgICAgICAgdGhpcy5fYmFja0J0biA9IHVuZGVmaW5lZDtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF9jaGVja0RlZmF1bHRMZXZlbCgpOiBib29sZWFuIHtcclxuICAgICAgICBsZXQgY2hlY2tEZWZhdWx0OiBib29sZWFuO1xyXG4gICAgICAgIGxldCBkZWZhdWx0TGV2ZWwgPSB0aGlzLl9kZWZhdWx0TGV2ZWwuaW5kZXhPZignXycpICE9IC0xID8gdGhpcy5fZGVmYXVsdExldmVsLnNwbGl0KCdfJylbMV0gOiB0aGlzLl9kZWZhdWx0TGV2ZWw7XHJcbiAgICAgICAgaWYgKHRoaXMuX2xldmVsLmluZGV4T2YoJ18nKSAhPSAtMSkge1xyXG4gICAgICAgICAgICBjaGVja0RlZmF1bHQgPSBwYXJzZUludCh0aGlzLl9sZXZlbC5zcGxpdCgnXycpWzFdKSA9PSBkZWZhdWx0TGV2ZWwgPyBmYWxzZSA6IHRydWU7XHJcbiAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgY2hlY2tEZWZhdWx0ID0gcGFyc2VJbnQodGhpcy5fbGV2ZWwpID09IGRlZmF1bHRMZXZlbCA/IGZhbHNlIDogdHJ1ZTtcclxuICAgICAgICB9XHJcbiAgICAgICAgcmV0dXJuIGNoZWNrRGVmYXVsdDtcclxuICAgIH1cclxuXHJcblxyXG5cclxuICAgIHByaXZhdGUgX2dldFNlcmllc1ZhbHVlKF9zZXJpZXNJZCkge1xyXG4gICAgICAgIGxldCByZXR1cm5PYmogPSB7XHJcbiAgICAgICAgICAgICdpZCc6ICcnLFxyXG4gICAgICAgICAgICAnbmFtZSc6ICcnLFxyXG4gICAgICAgICAgICAnZHJpbGxkb3duJzogJycsXHJcbiAgICAgICAgICAgICd2YWx1ZSc6ICcnXHJcbiAgICAgICAgfTtcclxuICAgICAgICBmb3IgKGxldCBpID0gMDsgaSA8IHRoaXMuX3Nlcmllc1BvaW50ZXIuZGF0YS5sZW5ndGg7IGkrKykge1xyXG4gICAgICAgICAgICBpZiAodGhpcy5fc2VyaWVzUG9pbnRlci5kYXRhW2ldLklEXyA9PSBfc2VyaWVzSWQpIHtcclxuICAgICAgICAgICAgICAgIHJldHVybk9iai5pZCA9IHRoaXMuX3Nlcmllc1BvaW50ZXIuZGF0YVtpXS5JRF87XHJcbiAgICAgICAgICAgICAgICByZXR1cm5PYmoubmFtZSA9IHRoaXMuX3Nlcmllc1BvaW50ZXIuZGF0YVtpXS5OQU1FMV87XHJcbiAgICAgICAgICAgICAgICByZXR1cm5PYmouZHJpbGxkb3duID0gdGhpcy5fc2VyaWVzUG9pbnRlci5kYXRhW2ldLmRyaWxsZG93bjtcclxuICAgICAgICAgICAgICAgIHJldHVybk9iai52YWx1ZSA9IHRoaXMuX3Nlcmllc1BvaW50ZXIuZGF0YVtpXS52YWx1ZTtcclxuICAgICAgICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgICAgIHJldHVybiByZXR1cm5PYmo7XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfZ2V0TmV3U2VyaWVzKF9uZXdMZWdlbmQ/OiBhbnkpOiB2b2lkIHtcclxuICAgICAgICBsZXQgbGVnZW5kUG9pbnRlciA9IF9uZXdMZWdlbmQgPyBfbmV3TGVnZW5kIDogdGhpcy5sZWdlbmQ7XHJcbiAgICAgICAgbGV0IHRlbXBMZWdlbmRBcnIgPSBPYmplY3Qua2V5cyhsZWdlbmRQb2ludGVyKS5tYXAoa2V5ID0+IHsgcmV0dXJuIGxlZ2VuZFBvaW50ZXJba2V5XTsgfSk7XHJcbiAgICAgICAgbGV0IG5ld1RlbXBTZXJpZXMgPSBbXTtcclxuICAgICAgICBmb3IgKGxldCBpID0gMDsgaSA8IHRlbXBMZWdlbmRBcnIubGVuZ3RoOyBpKyspIHtcclxuICAgICAgICAgICAgZm9yIChsZXQgaiA9IDA7IGogPCB0aGlzLl9zZXJpZXNEYXRhLmxlbmd0aDsgaisrKSB7XHJcbiAgICAgICAgICAgICAgICBpZiAodGVtcExlZ2VuZEFycltpXS5kZWFjdGl2ZSA9PSBmYWxzZSAmJiB0aGlzLl9zZXJpZXNEYXRhW2pdLmlkID09IHRlbXBMZWdlbmRBcnJbaV0ubWFwU2VyaWVzSWQpIHtcclxuICAgICAgICAgICAgICAgICAgICBuZXdUZW1wU2VyaWVzLnB1c2godGhpcy5fc2VyaWVzRGF0YVtqXSk7XHJcbiAgICAgICAgICAgICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICAgICAgdGhpcy5fZW1wdHlTZXJpZXMgPSBuZXdUZW1wU2VyaWVzLmxlbmd0aCAhPSAwID8gZmFsc2UgOiB0cnVlO1xyXG4gICAgICAgIGlmIChuZXdUZW1wU2VyaWVzLmxlbmd0aCAhPSAwKSB7IHRoaXMuX3Nlcmllc1BvaW50ZXIgPSBuZXdUZW1wU2VyaWVzW25ld1RlbXBTZXJpZXMubGVuZ3RoIC0gMV07IH1cclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF9nZXREcmlsbERvd25MZWdlbmRGb3JNdWx0aXBsZURpbWVuc2lvbigpOiB2b2lkIHtcclxuICAgICAgICBsZXQgdGVtcExlZ2VuZDtcclxuICAgICAgICBpZiAodGhpcy5fY2hlY2tEZWZhdWx0TGV2ZWwoKSA9PSB0cnVlKSB7XHJcbiAgICAgICAgICAgIHRlbXBMZWdlbmQgPSB0aGlzLl9jaGFydFN2Yy5zZXRNYXBMZWdlbmREYXRhKHRoaXMubGVnZW5kLCBbdGhpcy5fc2VyaWVzUG9pbnRlcl0sIHRoaXMuY29uZmlnKTtcclxuICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICB0ZW1wTGVnZW5kID0gdGhpcy5fY2hhcnRTdmMuc2V0TWFwTGVnZW5kRGF0YSh0aGlzLmxlZ2VuZCwgdGhpcy5fc2VyaWVzRGF0YSwgdGhpcy5jb25maWcpO1xyXG4gICAgICAgICAgICB0aGlzLl9nZXROZXdTZXJpZXModGVtcExlZ2VuZCk7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIHRoaXMub3V0cHV0TGVnZW5kLmVtaXQodGVtcExlZ2VuZCk7XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfZ2V0Q29sb3JQb2ludGVyKCk6IHZvaWQge1xyXG4gICAgICAgIC8vIGxldCB0ZW1wTGVnZW5kQXJyID0gT2JqZWN0LmtleXModGhpcy5sZWdlbmQpLm1hcChpdGVtID0+IHRoaXMubGVnZW5kW2l0ZW1dKTtcclxuICAgICAgICBsZXQgdGVtcExlZ2VuZEFyciA9IE9iamVjdC5rZXlzKHRoaXMubGVnZW5kRGF0YSkubWFwKGl0ZW0gPT4gdGhpcy5sZWdlbmREYXRhW2l0ZW1dKTtcclxuICAgICAgICBpZiAodGhpcy5fc2VyaWVzUG9pbnRlciAhPSB1bmRlZmluZWQpIHtcclxuICAgICAgICAgICAgZm9yIChsZXQgaSA9IDA7IGkgPCB0ZW1wTGVnZW5kQXJyLmxlbmd0aDsgaSsrKSB7XHJcbiAgICAgICAgICAgICAgICBpZiAodGhpcy5fc2VyaWVzUG9pbnRlci5pZCA9PSB0ZW1wTGVnZW5kQXJyW2ldLm1hcFNlcmllc0lkKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5fY29sb3JQb2ludGVyID0gdGhpcy5sZWdlbmREYXRhW3RlbXBMZWdlbmRBcnJbaV0uaWRdO1xyXG4gICAgICAgICAgICAgICAgICAgIC8vIHRoaXMuX2NvbG9yUG9pbnRlciA9IHRoaXMubGVnZW5kW3RlbXBMZWdlbmRBcnJbaV0uaWRdO1xyXG4gICAgICAgICAgICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX292ZXJXcml0ZVNlcmllcygpOiB2b2lkIHtcclxuICAgICAgICAvLyBjaGFuZ2Ugc2VyaWVzIGNvbG9yXHJcbiAgICAgICAgbGV0IHRlbXBMZWdlbmRBcnIgPSBPYmplY3Qua2V5cyh0aGlzLmxlZ2VuZERhdGEpLm1hcChpdGVtID0+IHRoaXMubGVnZW5kRGF0YVtpdGVtXSk7XHJcbiAgICAgICAgLy8gbGV0IHRlbXBMZWdlbmRBcnIgPSBPYmplY3Qua2V5cyh0aGlzLmxlZ2VuZCkubWFwKGl0ZW0gPT4gdGhpcy5sZWdlbmRbaXRlbV0pO1xyXG4gICAgICAgIGZvciAobGV0IGkgPSAwOyBpIDwgdGVtcExlZ2VuZEFyci5sZW5ndGg7IGkrKykge1xyXG4gICAgICAgICAgICBmb3IgKGxldCBqID0gMDsgaiA8IHRoaXMuX3Nlcmllc0RhdGEubGVuZ3RoOyBqKyspIHtcclxuICAgICAgICAgICAgICAgIGlmICh0aGlzLl9zZXJpZXNEYXRhW2pdLmlkID09IHRlbXBMZWdlbmRBcnJbaV0ubWFwU2VyaWVzSWQpIHtcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLl9zZXJpZXNEYXRhW2pdLmNvbG9yID0gdGVtcExlZ2VuZEFycltpXS5jb2xvcjtcclxuICAgICAgICAgICAgICAgICAgICBicmVhaztcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF9nZXRMZWdlbmRCeVR5cGUoKTogdm9pZCB7XHJcbiAgICAgICAgLy8gY2hlY2sgdHlwZSBvZiBkaW1lbnNpb25zIHdoZXRoZXIgaXMgc2luZ2xlIG9yIG11bHRpcGxlXHJcbiAgICAgICAgaWYgKCF0aGlzLmNvbmZpZy5za2lwTWFzc2FnZSkge1xyXG4gICAgICAgICAgICB0aGlzLl9zaW5nbGVMZXZlbERpbWVuc2lvbiA9IGZhbHNlO1xyXG4gICAgICAgICAgICBpZiAodGhpcy5jb25maWcuY29sb3JBeGlzICE9IHVuZGVmaW5lZCkge1xyXG4gICAgICAgICAgICAgICAgaWYgKHRoaXMuY29uZmlnLmNvbG9yQXhpcy5kYXRhQ2xhc3NlcyAmJiB0aGlzLmNvbmZpZy5jb2xvckF4aXMuZGF0YUNsYXNzZXMubGVuZ3RoICE9PSAwKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5fc2luZ2xlTGV2ZWxEaW1lbnNpb24gPSB0cnVlO1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMubGVnZW5kID0gdGhpcy5fY2hhcnRTdmMuc2V0U2luZ2xlTGVnZW5kTGV2ZWxzKHRoaXMuY29uZmlnLmNvbG9yQXhpcy5kYXRhQ2xhc3NlcywgdGhpcy5jb25maWcubGVnZW5kLnZhbHVlRGVjaW1hbHMsIHRoaXMuY29uZmlnLmxlZ2VuZC52YWx1ZVN1ZmZpeCwgdGhpcy5sZWdlbmQpO1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMub3V0cHV0TGVnZW5kLmVtaXQodGhpcy5sZWdlbmQpO1xyXG4gICAgICAgICAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLm91dHB1dExlZ2VuZC5lbWl0KHt9KTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgICAgIC8vIG11bHRpIGRpbWVuc2lvbiBsZWdlbmRcclxuICAgICAgICAgICAgICAgIHRoaXMubGVnZW5kID0gdGhpcy5fY2hhcnRTdmMuc2V0TWFwTGVnZW5kRGF0YSh0aGlzLmxlZ2VuZCwgdGhpcy5fc2VyaWVzRGF0YSwgdGhpcy5jb25maWcpO1xyXG4gICAgICAgICAgICAgICAgdGhpcy5vdXRwdXRMZWdlbmQuZW1pdCh0aGlzLmxlZ2VuZCk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICAvLyBvdXRwdXQgbGVnZW5kIG9ubHkgZm9yIGV4cG9ydGluZ1xyXG4gICAgICAgICAgICB0aGlzLl9zaW5nbGVMZXZlbERpbWVuc2lvbiA9IGZhbHNlO1xyXG4gICAgICAgICAgICBpZiAodGhpcy5jb25maWcuY29sb3JBeGlzICE9IHVuZGVmaW5lZCkge1xyXG4gICAgICAgICAgICAgICAgaWYgKHRoaXMuY29uZmlnLmNvbG9yQXhpcy5kYXRhQ2xhc3NlcyAmJiB0aGlzLmNvbmZpZy5jb2xvckF4aXMuZGF0YUNsYXNzZXMubGVuZ3RoICE9PSAwKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5fc2luZ2xlTGV2ZWxEaW1lbnNpb24gPSB0cnVlO1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMub3V0cHV0TGVnZW5kLmVtaXQodGhpcy5sZWdlbmQpO1xyXG4gICAgICAgICAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLm91dHB1dExlZ2VuZC5lbWl0KHt9KTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgICAgIHRoaXMub3V0cHV0TGVnZW5kLmVtaXQodGhpcy5sZWdlbmQpO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX3NldE1hcFNjYWxlVHJpYW5nbGUoX3ZhbHVlOiBudW1iZXIpOiB2b2lkIHtcclxuICAgICAgICBsZXQgc2lnbjogbnVtYmVyID0gdGhpcy5pc1J0bCA/IC0xIDogMTtcclxuICAgICAgICB0aGlzLl9tYXBTdmMudHJhbnNsYXRlTWFwU2NhbGVUcmlhbmdsZShzaWduICogdGhpcy5fbWFwU3ZjLnZhbHVlU2NhbGUoX3ZhbHVlKSk7XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfcmVtb3ZlTWFwU2NhbGVUcmlhbmdsZSgpOiB2b2lkIHtcclxuICAgICAgICBsZXQgdHJpYW5nbGVJbml0UG9pc3Rpb246IG51bWJlciA9IHRoaXMuaXNSdGwgPyA5OTkgOiAtOTk5O1xyXG4gICAgICAgIHRoaXMuX21hcFN2Yy50cmFuc2xhdGVNYXBTY2FsZVRyaWFuZ2xlKHRyaWFuZ2xlSW5pdFBvaXN0aW9uKTtcclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF9jaGVja0VtcHR5RGF0YVZhbHVlKF92YWx1ZTogYW55KTogYm9vbGVhbiB7XHJcbiAgICAgICAgaWYgKHRoaXMuX3Nlcmllc1BvaW50ZXIuZGF0YSA9PSB1bmRlZmluZWQpIHtcclxuICAgICAgICAgICAgcmV0dXJuIGZhbHNlO1xyXG4gICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgIGxldCBkYXRhVmFsdWUgPSB0aGlzLl9nZXRTZXJpZXNWYWx1ZShfdmFsdWUpLnZhbHVlO1xyXG4gICAgICAgICAgICBpZiAoZGF0YVZhbHVlID09IHVuZGVmaW5lZCkgcmV0dXJuIGZhbHNlO1xyXG4gICAgICAgICAgICBlbHNlIGlmIChkYXRhVmFsdWUgIT0gbnVsbCAmJiBkYXRhVmFsdWUgIT0gJycpIHJldHVybiB0cnVlO1xyXG4gICAgICAgICAgICBlbHNlIHJldHVybiBmYWxzZTtcclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgLyoqXHJcbiAgICAgKiBkcmF3aW5nIGNvbG9yIHNjYWxlIG9mIG1hcFxyXG4gICAgICovXHJcbiAgICBwcml2YXRlIF9kcmF3TWFwU2NhbGUoKTogdm9pZCB7XHJcbiAgICAgICAgLy8gbWF4IGFuZCBtaW4gY29sb3JzXHJcbiAgICAgICAgbGV0IGNvbG9yUmFuZ2U6IHN0cmluZ1tdID0gW3RoaXMuY29uZmlnLmNvbG9yQXhpcy5taW5Db2xvciwgdGhpcy5jb25maWcuY29sb3JBeGlzLm1heENvbG9yXTtcclxuICAgICAgICAvLyB0aGUgYWN0dWFsIGxlbmd0aCBvZiBiYXIgaW4gcHguIGN1cnJlbnRseSBoYXJkc2V0IHRvIDIwMDtcclxuICAgICAgICBsZXQgbGVuZ3RoUmFuZ2U6IG51bWJlcltdID0gWzAsIDIwMF07XHJcbiAgICAgICAgLy8gYXJyYXkgb2YgdGljayBpbnRlcnZhbHNcclxuICAgICAgICBsZXQgdGlja0FycjogbnVtYmVyW10gPSB0aGlzLl9tYXBTdmMuZ2V0TGVnZW5kSW50ZXJ2YWxzKHRoaXMuY29uZmlnLmNvbG9yQXhpcy5taW4sIHRoaXMuY29uZmlnLmNvbG9yQXhpcy5tYXgpO1xyXG4gICAgICAgIGxldCBub09mSW50ZXJ2YWw6IG51bWJlciA9IHRpY2tBcnIubGVuZ3RoIC0gMTtcclxuICAgICAgICBsZXQgc2NhbGVEb21haW46IG51bWJlcltdID0gW3RpY2tBcnJbMF0sIHRpY2tBcnJbbm9PZkludGVydmFsXV07XHJcbiAgICAgICAgbGV0IGFyciA9IGQzLnJhbmdlKG5vT2ZJbnRlcnZhbCk7XHJcbiAgICAgICAgbGV0IGxpbmVhckdyYWRpZW50RGlyZWN0aW9uOiAndG8gbGVmdCcgfCAndG8gcmlnaHQnID0gdGhpcy5pc1J0bCA/ICd0byBsZWZ0JyA6ICd0byByaWdodCc7XHJcblxyXG4gICAgICAgIC8vIGNvbG9yIHNjYWxlIGFjY29yZGluZyB0byB0aWNrQXJyLCBjYW4gYmUgdXNlZCB0byBjb2xvciB0aGUgbWFwLiB0byB1c2UganVzdCBjYWxsIGNvbG9yU2NhbGUodmFsdWUpXHJcbiAgICAgICAgdGhpcy5fbWFwU2NhbGVDb2xvclNjYWxlID0gdGhpcy5fbWFwU3ZjLnNldFNjYWxlKHNjYWxlRG9tYWluLCBjb2xvclJhbmdlKTtcclxuICAgICAgICAvLyB2YWx1ZSBzY2FsZSBhY2NvcmRpbmcgdG8gdGlja0FyciwgdXNlZCB0byBwb3NpdGlvbiB0cmlhbmdsZSB3aGVuIGhvdmVyZWQsIHNhdmUgdGhlIHZhbHVlU2NhbGUgaW4gbWFwIHNlcnZpY2UgY2xhc3NcclxuICAgICAgICB0aGlzLl9tYXBTdmMudmFsdWVTY2FsZSA9IHRoaXMuX21hcFN2Yy5zZXRTY2FsZShzY2FsZURvbWFpbiwgbGVuZ3RoUmFuZ2UpO1xyXG5cclxuICAgICAgICBsZXQgbWFwU2NhbGVXcmFwcGVyID0gZDMuc2VsZWN0KCcjJyArIHRoaXMuY29uZmlnLmlkICsgJy5rZHgtY2hhcnRzIC5rZHgtbWFwLXNjYWxlLXdyYXBwZXInKTtcclxuXHJcbiAgICAgICAgbGV0IG1hcFNjYWxlID0gbWFwU2NhbGVXcmFwcGVyLnNlbGVjdCgnI21hcFNjYWxlJyk7XHJcbiAgICAgICAgbWFwU2NhbGUuc3R5bGUoJ2JhY2tncm91bmQnLCAnbGluZWFyLWdyYWRpZW50KCcgKyBsaW5lYXJHcmFkaWVudERpcmVjdGlvbiArICcsJyArIGNvbG9yUmFuZ2VbMF0gKyAnLCcgKyBjb2xvclJhbmdlWzFdICsgJyknKTtcclxuXHJcbiAgICAgICAgdGhpcy5fbWFwU3ZjLm1hcFNjYWxlVHJpYW5nbGUgPSBtYXBTY2FsZVdyYXBwZXIuc2VsZWN0KCcua2R4LW1hcC1zY2FsZS10cmlhbmdsZScpO1xyXG5cclxuICAgICAgICBtYXBTY2FsZS5zZWxlY3RBbGwoJy5rZHgtbWFwLXNjYWxlLXJlY3QnKVxyXG4gICAgICAgICAgICAuZGF0YShhcnIpXHJcbiAgICAgICAgICAgIC5lbnRlcigpLmFwcGVuZCgnZGl2JylcclxuICAgICAgICAgICAgLmF0dHIoJ2NsYXNzJywgJ2tkeC1tYXAtc2NhbGUtcmVjdCcpXHJcbiAgICAgICAgICAgIC5hdHRyKCdpZCcsIChkKSA9PiAncmVjdC0nICsgZClcclxuICAgICAgICAgICAgLnN0eWxlKCd3aWR0aCcsIDEwMCAvIG5vT2ZJbnRlcnZhbCArICclJyk7XHJcblxyXG4gICAgICAgIG1hcFNjYWxlV3JhcHBlci5zZWxlY3QoJy5rZHgtbWFwLXNjYWxlLXRleHQtY29udGFpbmVyJylcclxuICAgICAgICAgICAgLnNlbGVjdEFsbCgnLmtkeC1tYXAtc2NhbGUtdGV4dCcpXHJcbiAgICAgICAgICAgIC5kYXRhKHRpY2tBcnIpXHJcbiAgICAgICAgICAgIC5lbnRlcigpLmFwcGVuZCgnZGl2JylcclxuICAgICAgICAgICAgLmF0dHIoJ2NsYXNzJywgJ2tkeC1tYXAtc2NhbGUtdGV4dCcpXHJcbiAgICAgICAgICAgIC5hdHRyKCdpZCcsIChkKSA9PiAndGV4dC0nICsgZClcclxuICAgICAgICAgICAgLmh0bWwoZCA9PiBkKTtcclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF9zZXRNYXJrZXJzKCk6IHZvaWQge1xyXG4gICAgICAgIGlmICh0aGlzLmNoYXJ0VHlwZVsxXSA9PT0gJ2NsdXN0ZXInKSB0aGlzLm91dHB1dExlZ2VuZC5lbWl0KHt9KTtcclxuICAgICAgICBsZXQgY2x1c3RlclR5cGU6IHN0cmluZyA9IHRoaXMuY29uZmlnLnBsb3RPcHRpb25zLm1hcC5jbHVzdGVyVHlwZSA/IHRoaXMuY29uZmlnLnBsb3RPcHRpb25zLm1hcC5jbHVzdGVyVHlwZSA6ICdjbHVzdGVyJztcclxuICAgICAgICB0aGlzLl9jbHVzdGVyRGF0YSA9IHRoaXMuX21hcFN2Yy5wb3B1bGF0ZU1hcmtlcnModGhpcy5kYXRhLnBvaW50RGF0YSwgdGhpcy5fbGVhZmxldE1hcCwgY2x1c3RlclR5cGUpO1xyXG4gICAgICAgIHRoaXMub3V0cHV0TWFya2VyLmVtaXQodGhpcy5fY2x1c3RlckRhdGEubWFya2Vyc0xlZ2VuZCk7XHJcbiAgICAgICAgLy8gdGhpcy5faXNNYXJrZXJMb2FkZWQgPSB0cnVlO1xyXG4gICAgICAgIC8vIH1cclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF9zZXRMYXllcigpOiB2b2lkIHtcclxuICAgICAgICBpZiAodGhpcy5fbGF5ZXIpIHRoaXMuX2xheWVyLnJlbW92ZSgpO1xyXG4gICAgICAgIGlmICh0aGlzLm1hcENvbmZpZy5wbG90T3B0aW9ucy5tYXAuem9vbSkgdGhpcy5fY2hlY2tab29tQ29uZmlnKHRoaXMubWFwQ29uZmlnLnBsb3RPcHRpb25zLm1hcC56b29tKTtcclxuICAgICAgICB0aGlzLl9sYXllciA9IEwudGlsZUxheWVyKCdodHRwczovL3tzfS50aWxlLm9wZW5zdHJlZXRtYXAub3JnL3t6fS97eH0ve3l9LnBuZycsIHtcclxuICAgICAgICAgICAgYXR0cmlidXRpb246ICcmY29weTsgPGEgaHJlZj1cImh0dHA6Ly93d3cub3BlbnN0cmVldG1hcC5vcmcvY29weXJpZ2h0XCI+T3BlblN0cmVldE1hcDwvYT4nLFxyXG4gICAgICAgICAgICBtYXhab29tOiAxOCxcclxuICAgICAgICB9KS5hZGRUbyh0aGlzLl9sZWFmbGV0TWFwKTtcclxuICAgICAgICB0aGlzLl9hdHRhY2hUaWxlTGlzdGVuZXIoKTtcclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF9jaGVja1pvb21Db25maWcoX2NvbmZpZzogYW55KTogdm9pZCB7XHJcbiAgICAgICAgaWYgKHR5cGVvZiB0aGlzLl9sZWFmbGV0TWFwICE9PSAndW5kZWZpbmVkJykge1xyXG4gICAgICAgICAgICBfY29uZmlnLmlzWm9vbUJ1dHRvbiA/IHRoaXMuX2xlYWZsZXRNYXAuYWRkQ29udHJvbCh0aGlzLl9sZWFmbGV0TWFwLnpvb21Db250cm9sKSA6IHRoaXMuX2xlYWZsZXRNYXAucmVtb3ZlQ29udHJvbCh0aGlzLl9sZWFmbGV0TWFwLnpvb21Db250cm9sKTtcclxuICAgICAgICAgICAgX2NvbmZpZy5pc1Njcm9sbFpvb20gPyB0aGlzLl9sZWFmbGV0TWFwLnNjcm9sbFdoZWVsWm9vbS5lbmFibGUoKSA6IHRoaXMuX2xlYWZsZXRNYXAuc2Nyb2xsV2hlZWxab29tLmRpc2FibGUoKTtcclxuICAgICAgICAgICAgX2NvbmZpZy5pc1RvdWNoWm9vbSA/IHRoaXMuX2xlYWZsZXRNYXAudG91Y2hab29tLmVuYWJsZSgpIDogdGhpcy5fbGVhZmxldE1hcC50b3VjaFpvb20uZGlzYWJsZSgpO1xyXG4gICAgICAgICAgICBfY29uZmlnLmlzRG91YmxlQ2xpY2tab29tID8gdGhpcy5fbGVhZmxldE1hcC5kb3VibGVDbGlja1pvb20uZW5hYmxlKCkgOiB0aGlzLl9sZWFmbGV0TWFwLmRvdWJsZUNsaWNrWm9vbS5kaXNhYmxlKCk7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX3JlbW92ZURlZmF1bHRBdHRyaWJ1dGlvbihfYXR0cmlidXRpb246IHN0cmluZyk6IHZvaWQge1xyXG4gICAgICAgIGxldCBhdHRyaWJ1dGlvbkVsZW1lbnQ6IEVsZW1lbnQgPSBkb2N1bWVudC5xdWVyeVNlbGVjdG9yKCcubGVhZmxldC1jb250cm9sLWF0dHJpYnV0aW9uJyk7XHJcbiAgICAgICAgaWYgKGF0dHJpYnV0aW9uRWxlbWVudCAhPT0gbnVsbCkge1xyXG4gICAgICAgICAgICBsZXQgbmV3QXR0cmlidXRpb25FbGVtZW50OiBIVE1MRWxlbWVudCA9IHRoaXMuX2RvbVN2Yy5jcmVhdGVFbGVtZW50KGF0dHJpYnV0aW9uRWxlbWVudCwgJ2N1c3RvbS1hdHRyaWJ1dGlvbicpO1xyXG4gICAgICAgICAgICBuZXdBdHRyaWJ1dGlvbkVsZW1lbnQuaW5uZXJUZXh0ID0gX2F0dHJpYnV0aW9uIHx8ICdPcGVuRU1JUyc7XHJcbiAgICAgICAgICAgIGF0dHJpYnV0aW9uRWxlbWVudC5yZXBsYWNlQ2hpbGQobmV3QXR0cmlidXRpb25FbGVtZW50LCBhdHRyaWJ1dGlvbkVsZW1lbnQuZmlyc3RDaGlsZCk7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX2F0dGFjaFRpbGVMaXN0ZW5lcigpOiB2b2lkIHtcclxuICAgICAgICAvKiBDaGVja3MgZXZlcnkgdGlsZS4gT25seSBjYWxsZWQgd2hlbiBzb21lIHRpbGUgbG9hZCBoYXMgZmFpbGVkLiAqL1xyXG4gICAgICAgIHRoaXMuX2xheWVyLm9uKCd0aWxlZXJyb3InLCAoZXJyb3IpOiB2b2lkID0+IHtcclxuICAgICAgICAgICAgLy8gb25seSBleGVjdXRlIHRoZSBmb2xsb3dpbmcgZm9yIHRoZSBmaXJzdCB0aWxlIGVycm9yXHJcbiAgICAgICAgICAgIGlmICghdGhpcy5faXNMYXllckVycm9yKSB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLl9pc0xheWVyRXJyb3IgPSB0cnVlO1xyXG4gICAgICAgICAgICAgICAgdGhpcy5fbGF5ZXJSZWxvYWRUaW1lcysrO1xyXG4gICAgICAgICAgICAgICAgaWYgKHRoaXMuX2xheWVyUmVsb2FkVGltZXMgPCAxIHx8IHRoaXMuX2xheWVyUmVsb2FkVGltZXMgPT09IDEpIHtcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLl9zZXRMYXllcigpO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgaWYgKHRoaXMuX2xheWVyUmVsb2FkVGltZXMgPiA1KSB7XHJcbiAgICAgICAgICAgICAgICAgICAgLy8gdGhpcy5pc01hcFNob3duID0gZmFsc2U7XHJcbiAgICAgICAgICAgICAgICAgICAgLy8gdGhpcy5lcnJvck1lc3NhZ2UgPSAnTWF4IHJldHJ5IHJlYWNoZWQuIE1hcCBjYW5ub3QgYmUgbG9hZGVkIG5vdy4gUGxlYXNlIGNoZWNrIHlvdXIgaW50ZXJuZXQgY29ubmVjdGlvbiBvciB0cnkgYWdhaW4gbGF0ZXIuJztcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH0pO1xyXG5cclxuICAgICAgICAvKiBDaGVja3MgZXZlcnkgdGlsZS4gT25seSBjYWxsZWQgd2hlbiBlYWNoIHRpbGUgbG9hZCBpcyBzdWNjZXNzZnVsLiAqL1xyXG4gICAgICAgIHRoaXMuX2xheWVyLm9uKCd0aWxlbG9hZCcsICgpOiB2b2lkID0+IHtcclxuICAgICAgICAgICAgdGhpcy5fdGlsZWxvYWRJbmRleCsrO1xyXG4gICAgICAgICAgICBpZiAodGhpcy5fdGlsZWxvYWRJbmRleCA9PT0gT2JqZWN0LmtleXModGhpcy5fbGF5ZXIuX3RpbGVzKS5sZW5ndGgpIHtcclxuICAgICAgICAgICAgICAgIC8vIG9ubHkgc3RvcCBwcm9ncmVzcyBsb2FkZXIgd2hlbiBsYXN0IHRpbGUgbG9hZGVkIHN1Y2Nlc3NmdWxseVxyXG4gICAgICAgICAgICAgICAgLy8gdGhpcy5pc0xheWVyTG9hZGluZyA9IGZhbHNlO1xyXG4gICAgICAgICAgICAgICAgLy8gdGhpcy5faXNUaWxlc0xvYWRlZCA9IHRydWU7XHJcbiAgICAgICAgICAgICAgICB0aGlzLm91dHB1dFJlYWR5LmVtaXQoZmFsc2UpO1xyXG5cclxuICAgICAgICAgICAgICAgIC8vIHJlc2V0IGNvdW50ZXJzXHJcbiAgICAgICAgICAgICAgICAvLyB0aGlzLl9sYXllclJlbG9hZFRpbWVzID0gMDtcclxuICAgICAgICAgICAgICAgIHRoaXMuX3RpbGVsb2FkSW5kZXggPSAwO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfSk7XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfY2hlY2tNYXBTZWxlY3RlZChfYXJlYUlkOiBzdHJpbmcpIHtcclxuICAgICAgICByZXR1cm4gdGhpcy5faXNNYXBTZWxlY3RlZC5oYXNPd25Qcm9wZXJ0eShfYXJlYUlkKTtcclxuICAgIH1cclxufSJdfQ==