import { Component, ViewEncapsulation, Input } from '@angular/core';
import * as d3 from 'd3';
import { KdChartBaseClass } from '../kd-angular-chart-base-class';
import { KdChartsSvc } from '../kd-angular-charts-svc';
import { KdDomElemSvc } from '../../kd-common/index';
export class KdLineChart extends KdChartBaseClass {
    constructor(_chartSvc, _domSvc) {
        super(_chartSvc, _domSvc);
        this._chartSvc = _chartSvc;
        this._domSvc = _domSvc;
        this._seriesList = [];
        // Dot Setting
        this._hoverBackground = 'M 10, 10 m -10, 0 a 10,10 0 1,0 20,0 a 10,10 0 1,0 -20,0';
        this._shapes = {
            'M 4 0 L 4 0 L 0 8 L 8 8 z': 'M 6 0 L 6 0 L 0 12 L 12 12 z',
            'M 0 0 L 8 0 L 4 8 L 4 8 z': 'M 0 0 L 12 0 L 6 12 L 6 12 z',
            'M 4 0 L 8 4 L 4 8 L 0 4 z': 'M 6 0 L 12 6 L 6 12 L 0 6 z',
            'M 4 0 A 4 4 0 1 0 4 8 A 4 4 0 1 0 4 0 Z': 'M 6 0 A 6 6 0 1 0 6 12 A 6 6 0 1 0 6 0 Z',
            'M 0 0 L 8 0 L 8 8 L 0 8 z': 'M 0 0 L 12 0 L 12 12 L 0 12 z'
        };
        this._dotData = {};
        this._biggestDotSize = 12;
        this._defaultDotPos = { x: -999, y: -999 };
        this._lineStyle = {
            solid: 'none',
            shortDash: '6,2',
            shortDot: '2,2',
            shortDashDot: '6,2,2,2',
            shortDashDotDot: '6,2,2,2,2,2',
            dot: '2,6',
            dash: '8,6',
            longDash: '16,6',
            dashDot: '8,6,2,6',
            longDashDot: '16,6,2,6',
            longDashDotDot: '16,6,2,6,2,6'
        };
    }
    ngOnInit() {
        this.api.legendClick = (_data) => {
            this._redrawChart(false, _data);
        };
        this.api.redraw = () => {
            clearTimeout(this._resizeTimeout);
            this._resizeTimeout = setTimeout(() => {
                this._redrawChart(false);
            });
        };
    }
    ngOnChanges(_changes) {
        if (_changes.hasOwnProperty('data')) {
            this._redrawChart(_changes.data.isFirstChange(), _changes.data.currentValue);
        }
        if (_changes.hasOwnProperty('config') && !_changes.config.isFirstChange()) {
            this._redrawChart(_changes.config.isFirstChange());
        }
    }
    ngOnDestroy() { this.removeLineChart(); }
    _redrawChart(_isFirstChange, _data) {
        if (!_isFirstChange) {
            this.lineChart = d3.select('#line-' + this.config.id);
            this.removeLineChart();
        }
        if (_data)
            this._setData(_data);
        super.chartTimeout(() => this._setChart());
    }
    _setData(_data) {
        this.chartType = _data.layout.split('-');
        this.chartCategory = 'line';
        this.dataRange = _data.range;
        this.haveNegative = _data.haveNegative;
        this.data = Object.assign([], _data.data);
        this.initData = JSON.parse(JSON.stringify(this.data));
        this._seriesList = Object.keys(this.legendData).filter(key => !this.legendData[key].deactive);
        if (this.chartType[1] === 'stack' || this.chartType[1] === '100') {
            this._seriesList = this._seriesList.reverse();
        }
    }
    removeLineChart() {
        super.removeChart();
        if (this.lineChart) {
            this.lineChart.remove();
            this.lineChart = null;
        }
    }
    _setChart() {
        if (this.chartType[1] === '100' && this.haveNegative)
            return;
        super.setSvg();
        this._setAxisDomain();
        this._createHoverDot();
        this._createChart();
        this._drawChart(this.data);
    }
    _setAxisDomain() {
        if (this.chartType[this.chartType.length - 1] === 'type1') {
            super.setDomain('band');
        }
        else {
            super.setDomain('string');
        }
    }
    _createChart() {
        if (!this.lineChart) {
            this.lineChart = this.graph.append('g')
                .attr('class', 'kdx-charts-line-chart')
                .attr('id', 'line-' + this.config.id);
        }
        if (this.config.animation)
            this._setChartAnimation();
    }
    _createSeriesContainer() {
        let lineSvg = this.lineChart.selectAll('.kdx-chart-wrapper')
            .data(this._seriesList, function (d) { return d; });
        // key function for object consistency so d3 does not remove base on index
        lineSvg.exit().remove();
        let seriesContainer;
        if (this.chartType[1] !== 'stack' && this.chartType[1] !== '100') {
            seriesContainer = lineSvg.enter()
                .append('g')
                .attr('class', (d, i) => 'kdx-charts-series-container' + ' y-' + this._seriesList[i]);
        }
        else {
            seriesContainer = lineSvg.enter();
        }
        let lineContainer = seriesContainer.append('g')
            .attr('class', (d, i) => 'kdx-charts-line-container' + ' y-' + this._seriesList[i])
            .attr('clip-path', 'url(#kd-charts-clip-path-' + this.config.id + ')');
        let dotContainer = seriesContainer.append('g')
            .attr('class', (d, i) => 'kdx-charts-dot-container' + ' y-' + this._seriesList[i])
            .attr('id', (d, i) => 'kdx-charts-dot-container' + '_y-' + this._seriesList[i].replace(/\s/g, ''));
        return { lineContainer: lineContainer, dotContainer: dotContainer };
    }
    _createHoverDot() {
        d3.select('#' + this.config.id + '.kdx-charts .kdx-charts-hover-dot').remove();
        this.graph
            .append('path')
            .attr('class', 'kdx-charts-hover-dot')
            .attr('d', this._hoverBackground)
            .attr('transform', super.transformPosition(this._defaultDotPos.x, this._defaultDotPos.y, true));
    }
    _drawChart(_data) {
        // super.removeChart();
        // this._setAxisDomain();
        let seriesContainer = this._createSeriesContainer();
        this._drawPath(_data, seriesContainer.lineContainer);
        this._addDot(_data, seriesContainer.dotContainer);
        for (let xIndex = 0; xIndex < _data.length; xIndex++) {
            this._setLabelAnimation(xIndex, _data[xIndex]);
        }
    }
    // Line & Area
    _drawPath(_chartData, _lineSvg) {
        let data = _chartData;
        if (this.chartType[1] === 'stack')
            data = this._dataMassage(_chartData);
        if (this.chartType[0] !== 'dot') {
            if (this.chartType[0] === 'area') {
                _lineSvg.append('path')
                    .attr('d', (d, i) => this._setPathValue(i, data))
                    .attr('class', (d, i) => 'kdx-charts-line-area y-' + d)
                    .attr('fill', (d, i) => this.legendData[d].color)
                    .attr('fill-opacity', 0.75);
            }
            _lineSvg.append('path')
                .attr('d', (d, i) => {
                if (this.chartType[0] === 'area') {
                    return this._setPathValue(i, data, true);
                }
                return this._setPathValue(i, data);
            })
                .attr('class', (d, i) => 'kdx-charts-line-path y-' + d)
                .attr('stroke', (d, i) => this.legendData[d].color)
                .attr('stroke-dasharray', (d, i) => this._lineStyle[this.legendData[d].lineStyle])
                .style('fill', 'none');
        }
    }
    /**
     * [return path data value. depends on chart type, this function will return line or area path data
     *
     * for _chartData, we need unique data type to return because we are doing a different way of stack area.
     * natural way of line chart is 1 line, 1 series.
     * what we are doing is cut the line/split the stack area into 2 to cater for null value.
     * the data structure that we have coupled strictly to 1 x axis/category match with 1 y data value.
     * for splitting of stack area, we will need 1 x category match with 2 y data value.
     *
     * ]
     * param  {number}                                        _yIndex          [series index as line is drawn per series]
     * param  {Array<ID3DataData> | Array<Array<IDataValue>>} _chartData       [either line data or area data]
     * param  {boolean}                                       _byPassAreaCheck [skip chart type check and draw line. useful for area to draw area and line]
     * return {string}                                                         [return path data value]
     */
    _setPathValue(_yIndex, _chartData, _byPassAreaCheck) {
        _byPassAreaCheck = _byPassAreaCheck || false;
        let chartValue = { x: null, y: null, valid: false }, curveShape = (this.chartType[0] === 'spline' || this.chartType[this.chartType.length - 2] === 'spline') ? d3.curveCardinal : d3.curveLinear, chart = (this.chartType[0] !== 'area' || _byPassAreaCheck) ? d3.line() : d3.area(), data;
        data = (this._isUsingChartData(_chartData)) ? _chartData : _chartData[_yIndex];
        let valueLine = chart.curve(curveShape);
        chart.defined((item, xIndex) => {
            chartValue = this._validateChartValue(data[xIndex], _yIndex);
            return chartValue.valid;
        });
        chart.x(() => this.rangeList[chartValue.x.value]);
        if (this.chartType[0] !== 'area' || _byPassAreaCheck) {
            chart.y(() => this.y(chartValue.y));
        }
        else {
            chart.y1(() => this.y(chartValue.y))
                .y0((item) => (this.chartType[1] === '100' || this.chartType[1] === 'stack') ? this.y(chartValue.y0) : this.y(0));
        }
        return valueLine(data);
    }
    _isUsingChartData(_arrayObject) {
        return this.chartType[1] !== 'stack';
    }
    _isIDataValue(_object) {
        return this.chartType[1] === 'stack';
    }
    _validateChartValue(_item, _yIndex) {
        if (this._isIDataValue(_item)) { // stack
            return _item;
        }
        let yValue = _item.y[_yIndex].sum;
        let valid = true;
        let y0 = 0;
        if (this.chartType[1] === '100') {
            y0 = _item.y[_yIndex].sum - _item.y[_yIndex].renderVal;
        }
        else {
            valid = super.isDataExist(_item, _yIndex);
        }
        return { x: _item.x, y: yValue, y0: y0, valid: valid };
    }
    // Dot
    _addDot(_data, _dotContainer) {
        for (let xIndex = 0; xIndex < _data.length; xIndex++) {
            let item = _data[xIndex];
            if (this.chartType[1] !== 'stack' && !Array.isArray(item.y) ||
                (Array.isArray(item.y) && item.y.length <= 0))
                continue;
            let dataPoint = _dotContainer.append('path')
                .attr('class', (d, i) => this._populateDotData(item, i, xIndex))
                .attr('d', (d, i) => this._getDotId(xIndex, i, item, 'shape'))
                .attr('fill', (d, i) => this._getDotId(xIndex, i, item, 'colour'))
                .attr('stroke', (d, i) => this._getDotId(xIndex, i, item, 'borderColor'))
                .attr('stroke-width', (d, i) => this._getDotId(xIndex, i, item, 'borderWidth'))
                .attr('transform', (d, i) => this._getDotId(xIndex, i, item, 'position'))
                .style('display', 'block');
            let dotHoverFunc = this.triggerHoverFunction(this);
            super._initMouseEvents(dataPoint, { data: item, xIndex: xIndex, dotHover: dotHoverFunc });
        }
    }
    _getDotId(_xIndex, _yIndex, _data, _element) {
        if (!(super.isDataExist(_data, _yIndex) && this.legendData[_data.y[_yIndex].id].dotEnabled))
            return '';
        let id = super.getDotId(_xIndex, _data.y[_yIndex].id).replace(/\s/g, '');
        let value = '';
        if (_element === 'position') {
            let x = (this._dotData[id] && typeof this._dotData[id].x !== 'undefined') ? this._dotData[id].x : this._defaultDotPos.x;
            let y = (this._dotData[id] && typeof this._dotData[id].y !== 'undefined') ? this._dotData[id].y : this._defaultDotPos.y;
            value = super.transformPosition(x, y, true);
        }
        else {
            value = (this._dotData[id] && this._dotData[id][_element]) ? this._dotData[id][_element].toString() : '';
        }
        return value;
    }
    _populateDotData(_data, _yIndex, _xIndex) {
        if (!super.isDataExist(_data, _yIndex))
            return '';
        let id = super.getDotId(_xIndex, _data.y[_yIndex].id).replace(/\s/g, '');
        let colour = _data.y[_yIndex].color;
        let shape = _data.y[_yIndex].shape;
        let position = this._getDotPosition(_data.x.value, _xIndex, _data.y[_yIndex].sum);
        let borderColor = this.legendData[_data.y[_yIndex].id].dotBorderColor;
        let borderWidth = this.legendData[_data.y[_yIndex].id].dotBorderWidth;
        this._setLabel(_data.y[_yIndex], _xIndex, position.x, borderWidth);
        if (_data.y[_yIndex].value === this.domainMin || _data.y[_yIndex].value === this.domainMax) {
            let currentDotSize = 12 + borderWidth;
            if (this._biggestDotSize < currentDotSize)
                this._biggestDotSize = currentDotSize;
        }
        if ((this.config.yAxis.minValue !== null &&
            _data.y[_yIndex].value < this.config.yAxis.minValue) ||
            (this.config.yAxis.maxValue !== null &&
                _data.y[_yIndex].value > this.config.yAxis.maxValue)) {
            delete this._dotData[id];
            return id;
        }
        this._dotData[id] = {
            colour: colour,
            shape: shape,
            x: position.x,
            y: position.y,
            borderColor: borderColor,
            borderWidth: borderWidth
        };
        return id;
    }
    _getDotPosition(_xValue, _xIndex, _yValue) {
        let xPos = 0;
        let yPos = 0;
        xPos = (this.rangeList[_xValue] - 4);
        yPos = (this.y(_yValue) - 4);
        return { x: xPos, y: yPos };
    }
    // hover function
    triggerHoverFunction(_kdLineChart) {
        return function (dotId, isHovering) {
            isHovering = isHovering || false;
            _kdLineChart.dotHover(_kdLineChart, dotId, isHovering);
        };
    }
    dotHover(_kdLineChart, _dotId, _isHovering) {
        _dotId = _dotId.replace(/\s/g, '');
        if (!this._dotData.hasOwnProperty(_dotId) || !this._dotData[_dotId].shape)
            return;
        let shape = (_isHovering) ? this._shapes[this._dotData[_dotId].shape] : this._dotData[_dotId].shape;
        let position = this._dotHoverPosition(_dotId, _isHovering, false);
        let borderWidth = this._dotData[_dotId].borderWidth;
        if (borderWidth === 0 && _isHovering)
            borderWidth = 1;
        this._setHoverBackground(_dotId, _isHovering);
        d3.select('#' + this.config.id + '.kdx-charts .' + _dotId)
            .attr('d', shape)
            .attr('transform', super.transformPosition(position.x, position.y, true))
            .attr('stroke-width', borderWidth);
    }
    _setHoverBackground(_dotId, _isHovering) {
        let colour = this._dotData[_dotId].colour;
        let position = _isHovering ? this._dotHoverPosition(_dotId, _isHovering, true) : this._defaultDotPos;
        d3.select('#' + this.config.id + '.kdx-charts .kdx-charts-hover-dot')
            // .style('display', display)
            .attr('fill', colour)
            .attr('transform', this.transformPosition(position.x, position.y, true))
            .attr('stroke-width', 1)
            .attr('stroke', colour);
    }
    _dotHoverPosition(_dotId, _isHovering, _isBackground) {
        let xPos = this._dotData[_dotId].x;
        let yPos = this._dotData[_dotId].y;
        if (!_isHovering)
            return { x: xPos, y: yPos };
        if (_isBackground) {
            xPos -= 6;
            yPos -= 6;
        }
        else {
            xPos -= 2;
            yPos -= 2;
        }
        return { x: xPos, y: yPos };
    }
    // label
    _setLabel(_yData, _xIndex, _xPosition, _dotWidth) {
        if (!this.config.chart.labels.enabled)
            return;
        _xPosition -= _dotWidth / 2;
        let label = super.setLabel(_yData, _xIndex, _xPosition, this.y(_yData.sum));
        // label.style('display', 'flex');
        let spanElm = label.select('.kdx-charts-data-label-text');
        let dataLabelLength = this._getLabelTextLength(_yData);
        let dotSize = 10 + _dotWidth; // add 10px for spacing between dot and label
        super.setLabelTextPosition(spanElm, this.y(_yData.sum), { dotSize: dotSize, labelLength: dataLabelLength });
        // shift text to the horizontally center to the dot
        // if (this._chartSvc.isExist(_yData) && dataLabelLength > 1) {
        //     let shiftPosition: number = this._getCenterPosition(dataLabelLength, spanElm);
        //     spanElm.style('left', shiftPosition + 'px').style('display', 'none');
        // }
    }
    _getLabelTextLength(_yData) {
        let dataLabel = this.config.chart.labels.format.replace('{value}', this._chartSvc.getD3Format(_yData.value));
        return dataLabel.toString().length;
    }
    // private _getCenterPosition(_dataLabelLength: number, _spanElm: any) {
    //     let labelElm: any = _spanElm.node().getBoundingClientRect();
    //     let labelWidth: number = labelElm.width;
    //     let labelCenter: number = (labelWidth - labelWidth / _dataLabelLength) / 2;
    //     let shiftPosition: number = 0 - labelCenter;
    //     if (document.dir === 'rtl') return labelCenter;
    //     return shiftPosition;
    // }
    // animation
    _setChartAnimation() {
        let halfDot = this._biggestDotSize / 2;
        let offsetStart = 0 - halfDot;
        let clip = this.lineChart.append('clipPath')
            .attr('id', 'line-clip' + this.config.id);
        let clipRect = clip.append('rect')
            .attr('fill', 'white')
            .attr('x', offsetStart)
            .attr('y', offsetStart)
            .attr('fill', 'none')
            .attr('width', 0)
            .attr('height', this.height + this._biggestDotSize);
        this.lineChart.attr('clip-path', 'url(#line-clip' + this.config.id + ')');
        let transitionFunc = d3.transition()
            .duration(this.lengthOfTransition)
            .ease(d3.easeLinear);
        clipRect.transition(transitionFunc)
            .attr('width', this.width + this._biggestDotSize);
    }
    _setLabelAnimation(_xIndex, _data) {
        if (this.config.chart !== undefined && this.config.chart.labels !== undefined) {
            if (!this.config.chart.labels.enabled)
                return;
            let labelDelay = 1.5;
            let animationDelay = _xIndex * this.lengthOfTransition / _data.y.length * labelDelay;
            let transitionTime = this.config.animation ? this.lengthOfTransition : 0;
            animationDelay = this.config.animation ? animationDelay : 0;
            d3.selectAll('#' + this.config.id + '.kdx-charts .kdx-charts-data-label.x-' + _xIndex)
                .transition() // Transition from old to new
                .duration(transitionTime) // Length of animation
                .delay(animationDelay)
                .on('start', function (d, i) {
                d3.select(this) // 'this' means the current element
                    .style('visibility', 'visible');
                // .style('display', 'block');
            });
        }
    }
    // Stack Area recalculate
    /**
     * for area stack (not the 100% stack. 100% data massage is the same as bar which
     * the data masssage is done in kd charts).
     *
     * this cannot be done through kd chart data massage because the dot position has to
     * be on the correct sum (same as bar). we will take bar after massage value for dot
     * and remassage for line area.
     *
     * this data massage is catering unique line behaviour when handling null value.
     *
     * line behaviour on null: when a null appear, the line for previous and after current
     * x axis will not be drawn. causing the previous and after x axis to be intepreted as 0
     *
     * as the whole area of this current x axis will be 0 for current series, any series after
     * has to be brought down.
     *
     * we need unique data type to return because we are doing a different way of stack area.
     * natural way of line chart is 1 line, 1 series.
     * what we are doing is cut the line/split the stack area into 2 to cater for null value.
     * the data structure that we have coupled strictly to 1 x axis/category match with 1 y data value.
     * for splitting of stack area, we will need 1 x category match with 2 y data value.
     *
     * param  {Array<ID3DataData>} data after massage data
     * return {Array}                   return as {x, y, y0, valid} as d3 required.
     */
    _dataMassage(_data) {
        // console.log(_data);
        let dataArr = [];
        let adjustPosition = {};
        for (let i = 0; i < this._seriesList.length; ++i) {
            let dataDetails = [];
            let x = null;
            let y = 0;
            let y0 = 0;
            let valid = true;
            for (let xIndex = 0; xIndex < _data.length; ++xIndex) {
                let xValue = _data[xIndex].x.value;
                for (let yIndex = 0; yIndex < _data[xIndex].y.length; ++yIndex) {
                    let id = _data[xIndex].y[yIndex].id;
                    x = xValue;
                    valid = _data[xIndex].y[yIndex].value !== null ? true : false;
                    if (this.chartType[1] === 'stack' && id === this._seriesList[i]) {
                        let nullValue = this._getNullHeightValue(_data, xIndex, yIndex);
                        let adjustValue = (typeof adjustPosition[xIndex] === 'undefined') ? 0 : adjustPosition[xIndex];
                        adjustPosition[xIndex] = adjustValue - nullValue;
                        let adjust = adjustPosition[xIndex] || 0;
                        let currentValue = _data[xIndex].y[yIndex].value;
                        y = _data[xIndex].y[yIndex].sum + adjust;
                        y0 = y - currentValue;
                        dataDetails.push({ x: { value: x, label: x }, y: y, y0: y0, id: id, valid: valid });
                        let splitPathData = this._getSplitPathData(_data, xIndex, yIndex, adjustPosition);
                        if (splitPathData.valid === true) {
                            dataDetails.push({ x: splitPathData.x, y: splitPathData.y, y0: splitPathData.y0, id: id, valid: false });
                            dataDetails.push({ x: splitPathData.x, y: splitPathData.y, y0: splitPathData.y0, id: id, valid: true });
                        }
                        break;
                    }
                }
            }
            dataArr.push(dataDetails);
        }
        // console.log(dataArr);
        return dataArr;
    }
    /**
     * if the previous series is null, area height calculation start from the series that exist.
     * param  {Array<ID3DataData>} data   [data after massage]
     * param  {number}             xIndex [index of data]
     * param  {number}             yIndex [index of series]
     * param  {number}             adjust [how much point to be bring down (previous)]
     * return {number}                    [return accumulate adjustment point]
     */
    _getNullHeightValue(_data, _xIndex, _yIndex) {
        let currentVal = _data[_xIndex].y[_yIndex].value;
        let isDisappearing = false;
        let isSeriesNull = this._chartSvc.isSeriesNull(_data, _xIndex, _yIndex);
        let isPrevNull = isSeriesNull['isPrevNull'];
        let isSidesNull = isSeriesNull['isNextNull'] && (_xIndex < 1 || isPrevNull);
        if (_xIndex > 0) {
            let checkSeries = this._chartSvc.isSeriesNull(_data, (_xIndex - 1), _yIndex);
            isDisappearing = checkSeries['isDisappearing'];
        }
        if (currentVal === null || isSidesNull || isPrevNull || isDisappearing) {
            return currentVal;
        }
        return 0;
    }
    /**
     * check if the series appearing or disappearing, adjust the position of the line area (stage up/down)
     *
     * appearing is referring to: there is a null on previous x axis but not null on current and after
     *
     * disappering is referring to: there is a value on previous and current x axis but null after
     *
     * param  {Array<ID3DataData>} data   [data after massage]
     * param  {number}             xIndex [index of data]
     * param  {number}             yIndex [index of series]
     * param  {object}             adjust [height to pull down series (if previous series has null) or bring up]
     * return {IDataValue}                [d3 draw path data structure: {x, y, y0, valid}]
     */
    _getSplitPathData(_data, _xIndex, _yIndex, _adjust) {
        let currentValue = _data[_xIndex].y[_yIndex].value;
        let split = false;
        let y = _data[_xIndex].y[_yIndex].sum + (_adjust[_xIndex] || 0);
        let x = _data[_xIndex].x.value;
        let y0 = 0 - currentValue;
        if (currentValue === null) {
            return { x: { value: x, label: x }, y: y, y0: y0, valid: split };
        }
        let isDisappearing = _xIndex > 0 && _xIndex < _data.length - 1 &&
            _data[_xIndex + 1].y[_yIndex].value === null &&
            currentValue !== null && _data[_xIndex - 1].y[_yIndex].value !== null;
        let isReappearing = _xIndex > 0 && _xIndex < _data.length - 1 &&
            _data[_xIndex - 1].y[_yIndex].value === null &&
            currentValue !== null && _data[_xIndex + 1].y[_yIndex].value !== null;
        if (isReappearing) {
            _adjust['adjust' + _xIndex] = (_adjust['adjust' + _xIndex] || 0) + currentValue;
        }
        if (isDisappearing) {
            _adjust['adjust' + _xIndex] = (_adjust['adjust' + _xIndex] || 0) - currentValue;
        }
        if (currentValue !== null && _adjust['adjust' + _xIndex]) {
            y = y + _adjust['adjust' + _xIndex];
            y0 = y0 + y;
            split = true;
        }
        return { x: { value: x, label: x }, y: y, y0: y0, valid: split };
    }
}
KdLineChart.decorators = [
    { type: Component, args: [{
                selector: 'kd-line-chart',
                template: `
        <div *ngIf="chartType[1] === '100' && haveNegative" class="kdx-charts-error-msg">
            {{errorMsg}}
        </div>
    `,
                encapsulation: ViewEncapsulation.None,
                providers: [KdChartsSvc, KdDomElemSvc]
            },] }
];
KdLineChart.ctorParameters = () => [
    { type: KdChartsSvc },
    { type: KdDomElemSvc }
];
KdLineChart.propDecorators = {
    data: [{ type: Input }],
    config: [{ type: Input }],
    legendData: [{ type: Input, args: ['legend',] }],
    api: [{ type: Input }]
};
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoia2QtYW5ndWxhci1saW5lLWNoYXJ0LmpzIiwic291cmNlUm9vdCI6IkQ6L29wZW5FTUlTL3N0eWxlZ3VpZGUvaW9zdGctb3BlbmVtaXMtc3R5bGVndWlkZS9wcm9qZWN0cy9vcGVuZW1pcy1zdHlsZWd1aWRlLWxpYi9zcmMvIiwic291cmNlcyI6WyJrZC1jb21wb25lbnRzL2tkLWFuZ3VsYXItY2hhcnRzL2tkLWFuZ3VsYXItbGluZS1jaGFydC9rZC1hbmd1bGFyLWxpbmUtY2hhcnQudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsT0FBTyxFQUNILFNBQVMsRUFDVCxpQkFBaUIsRUFLakIsS0FBSyxFQUNSLE1BQU0sZUFBZSxDQUFDO0FBQ3ZCLE9BQU8sS0FBSyxFQUFFLE1BQU0sSUFBSSxDQUFDO0FBQ3pCLE9BQU8sRUFBRSxnQkFBZ0IsRUFBRSxNQUFNLGdDQUFnQyxDQUFDO0FBQ2xFLE9BQU8sRUFBRSxXQUFXLEVBQUUsTUFBTSwwQkFBMEIsQ0FBQztBQVN2RCxPQUFPLEVBQUUsWUFBWSxFQUFFLE1BQU0sdUJBQXVCLENBQUM7QUErQ3JELE1BQU0sT0FBTyxXQUFZLFNBQVEsZ0JBQWdCO0lBNEM3QyxZQUFtQixTQUFzQixFQUFTLE9BQXFCO1FBQ25FLEtBQUssQ0FBQyxTQUFTLEVBQUUsT0FBTyxDQUFDLENBQUM7UUFEWCxjQUFTLEdBQVQsU0FBUyxDQUFhO1FBQVMsWUFBTyxHQUFQLE9BQU8sQ0FBYztRQXhDL0QsZ0JBQVcsR0FBa0IsRUFBRSxDQUFDO1FBSXhDLGNBQWM7UUFDTixxQkFBZ0IsR0FBVywwREFBMEQsQ0FBQztRQUV0RixZQUFPLEdBQVc7WUFDdEIsMkJBQTJCLEVBQUUsOEJBQThCO1lBQzNELDJCQUEyQixFQUFFLDhCQUE4QjtZQUMzRCwyQkFBMkIsRUFBRSw2QkFBNkI7WUFDMUQseUNBQXlDLEVBQUUsMENBQTBDO1lBQ3JGLDJCQUEyQixFQUFFLCtCQUErQjtTQUMvRCxDQUFDO1FBRU0sYUFBUSxHQUFTLEVBQUUsQ0FBQztRQUVwQixvQkFBZSxHQUFXLEVBQUUsQ0FBQztRQUU3QixtQkFBYyxHQUFjLEVBQUMsQ0FBQyxFQUFFLENBQUMsR0FBRyxFQUFFLENBQUMsRUFBRSxDQUFDLEdBQUcsRUFBQyxDQUFDO1FBRS9DLGVBQVUsR0FBVztZQUN6QixLQUFLLEVBQUUsTUFBTTtZQUNiLFNBQVMsRUFBRSxLQUFLO1lBQ2hCLFFBQVEsRUFBRSxLQUFLO1lBQ2YsWUFBWSxFQUFFLFNBQVM7WUFDdkIsZUFBZSxFQUFFLGFBQWE7WUFDOUIsR0FBRyxFQUFFLEtBQUs7WUFDVixJQUFJLEVBQUUsS0FBSztZQUNYLFFBQVEsRUFBRSxNQUFNO1lBQ2hCLE9BQU8sRUFBRSxTQUFTO1lBQ2xCLFdBQVcsRUFBRSxVQUFVO1lBQ3ZCLGNBQWMsRUFBRSxjQUFjO1NBQ2pDLENBQUM7SUFTRixDQUFDO0lBRUQsUUFBUTtRQUVKLElBQUksQ0FBQyxHQUFHLENBQUMsV0FBVyxHQUFHLENBQUMsS0FBYyxFQUFFLEVBQUU7WUFDdEMsSUFBSSxDQUFDLFlBQVksQ0FBQyxLQUFLLEVBQUUsS0FBSyxDQUFDLENBQUM7UUFDcEMsQ0FBQyxDQUFDO1FBQ0YsSUFBSSxDQUFDLEdBQUcsQ0FBQyxNQUFNLEdBQUcsR0FBRyxFQUFFO1lBQ25CLFlBQVksQ0FBQyxJQUFJLENBQUMsY0FBYyxDQUFDLENBQUM7WUFDbEMsSUFBSSxDQUFDLGNBQWMsR0FBRyxVQUFVLENBQUMsR0FBRyxFQUFFO2dCQUNsQyxJQUFJLENBQUMsWUFBWSxDQUFDLEtBQUssQ0FBQyxDQUFDO1lBQzdCLENBQUMsQ0FBQyxDQUFDO1FBQ1AsQ0FBQyxDQUFDO0lBQ04sQ0FBQztJQUVELFdBQVcsQ0FBQyxRQUF1QjtRQUMvQixJQUFJLFFBQVEsQ0FBQyxjQUFjLENBQUMsTUFBTSxDQUFDLEVBQUU7WUFDakMsSUFBSSxDQUFDLFlBQVksQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLGFBQWEsRUFBRSxFQUFFLFFBQVEsQ0FBQyxJQUFJLENBQUMsWUFBWSxDQUFDLENBQUM7U0FDaEY7UUFFRCxJQUFJLFFBQVEsQ0FBQyxjQUFjLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsTUFBTSxDQUFDLGFBQWEsRUFBRSxFQUFFO1lBQ3ZFLElBQUksQ0FBQyxZQUFZLENBQUMsUUFBUSxDQUFDLE1BQU0sQ0FBQyxhQUFhLEVBQUUsQ0FBQyxDQUFDO1NBQ3REO0lBQ0wsQ0FBQztJQUVELFdBQVcsS0FBVyxJQUFJLENBQUMsZUFBZSxFQUFFLENBQUMsQ0FBQyxDQUFDO0lBRXZDLFlBQVksQ0FBQyxjQUF1QixFQUFFLEtBQWU7UUFDekQsSUFBSSxDQUFDLGNBQWMsRUFBRTtZQUNqQixJQUFJLENBQUMsU0FBUyxHQUFHLEVBQUUsQ0FBQyxNQUFNLENBQUMsUUFBUSxHQUFHLElBQUksQ0FBQyxNQUFNLENBQUMsRUFBRSxDQUFDLENBQUM7WUFDdEQsSUFBSSxDQUFDLGVBQWUsRUFBRSxDQUFDO1NBQzFCO1FBQ0QsSUFBSSxLQUFLO1lBQUUsSUFBSSxDQUFDLFFBQVEsQ0FBQyxLQUFLLENBQUMsQ0FBQztRQUNoQyxLQUFLLENBQUMsWUFBWSxDQUFDLEdBQUcsRUFBRSxDQUFDLElBQUksQ0FBQyxTQUFTLEVBQUUsQ0FBQyxDQUFDO0lBQy9DLENBQUM7SUFFTyxRQUFRLENBQUMsS0FBYztRQUMzQixJQUFJLENBQUMsU0FBUyxHQUFHLEtBQUssQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDO1FBQ3pDLElBQUksQ0FBQyxhQUFhLEdBQUcsTUFBTSxDQUFDO1FBQzVCLElBQUksQ0FBQyxTQUFTLEdBQUcsS0FBSyxDQUFDLEtBQUssQ0FBQztRQUM3QixJQUFJLENBQUMsWUFBWSxHQUFHLEtBQUssQ0FBQyxZQUFZLENBQUM7UUFFdkMsSUFBSSxDQUFDLElBQUksR0FBRyxNQUFNLENBQUMsTUFBTSxDQUFDLEVBQUUsRUFBRSxLQUFLLENBQUMsSUFBSSxDQUFDLENBQUM7UUFDMUMsSUFBSSxDQUFDLFFBQVEsR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUM7UUFFdEQsSUFBSSxDQUFDLFdBQVcsR0FBRyxNQUFNLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsR0FBRyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUM7UUFFOUYsSUFBSSxJQUFJLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxLQUFLLE9BQU8sSUFBSSxJQUFJLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxLQUFLLEtBQUssRUFBRTtZQUM5RCxJQUFJLENBQUMsV0FBVyxHQUFHLElBQUksQ0FBQyxXQUFXLENBQUMsT0FBTyxFQUFFLENBQUM7U0FDakQ7SUFDTCxDQUFDO0lBRU8sZUFBZTtRQUNuQixLQUFLLENBQUMsV0FBVyxFQUFFLENBQUM7UUFDcEIsSUFBSSxJQUFJLENBQUMsU0FBUyxFQUFFO1lBQ2hCLElBQUksQ0FBQyxTQUFTLENBQUMsTUFBTSxFQUFFLENBQUM7WUFDeEIsSUFBSSxDQUFDLFNBQVMsR0FBRyxJQUFJLENBQUM7U0FDekI7SUFDTCxDQUFDO0lBRU8sU0FBUztRQUNiLElBQUksSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsS0FBSyxLQUFLLElBQUksSUFBSSxDQUFDLFlBQVk7WUFBRSxPQUFPO1FBQzdELEtBQUssQ0FBQyxNQUFNLEVBQUUsQ0FBQztRQUVmLElBQUksQ0FBQyxjQUFjLEVBQUUsQ0FBQztRQUV0QixJQUFJLENBQUMsZUFBZSxFQUFFLENBQUM7UUFFdkIsSUFBSSxDQUFDLFlBQVksRUFBRSxDQUFDO1FBRXBCLElBQUksQ0FBQyxVQUFVLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDO0lBQy9CLENBQUM7SUFFTyxjQUFjO1FBRWxCLElBQUksSUFBSSxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLE1BQU0sR0FBRyxDQUFDLENBQUMsS0FBSyxPQUFPLEVBQUU7WUFDdkQsS0FBSyxDQUFDLFNBQVMsQ0FBQyxNQUFNLENBQUMsQ0FBQztTQUMzQjthQUFNO1lBQ0gsS0FBSyxDQUFDLFNBQVMsQ0FBQyxRQUFRLENBQUMsQ0FBQztTQUM3QjtJQUNMLENBQUM7SUFFTyxZQUFZO1FBQ2hCLElBQUksQ0FBQyxJQUFJLENBQUMsU0FBUyxFQUFFO1lBQ2pCLElBQUksQ0FBQyxTQUFTLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDO2lCQUNsQyxJQUFJLENBQUMsT0FBTyxFQUFFLHVCQUF1QixDQUFDO2lCQUN0QyxJQUFJLENBQUMsSUFBSSxFQUFFLE9BQU8sR0FBRyxJQUFJLENBQUMsTUFBTSxDQUFDLEVBQUUsQ0FBQyxDQUFDO1NBQzdDO1FBRUQsSUFBSSxJQUFJLENBQUMsTUFBTSxDQUFDLFNBQVM7WUFBRSxJQUFJLENBQUMsa0JBQWtCLEVBQUUsQ0FBQztJQUN6RCxDQUFDO0lBRU8sc0JBQXNCO1FBQzFCLElBQUksT0FBTyxHQUFRLElBQUksQ0FBQyxTQUFTLENBQUMsU0FBUyxDQUFDLG9CQUFvQixDQUFDO2FBQzVELElBQUksQ0FBQyxJQUFJLENBQUMsV0FBVyxFQUFFLFVBQVMsQ0FBQyxJQUFJLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7UUFDdkQsMEVBQTBFO1FBRTFFLE9BQU8sQ0FBQyxJQUFJLEVBQUUsQ0FBQyxNQUFNLEVBQUUsQ0FBQztRQUV4QixJQUFJLGVBQW9CLENBQUM7UUFFekIsSUFBSSxJQUFJLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxLQUFLLE9BQU8sSUFBSSxJQUFJLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxLQUFLLEtBQUssRUFBRTtZQUM5RCxlQUFlLEdBQUcsT0FBTyxDQUFDLEtBQUssRUFBRTtpQkFDNUIsTUFBTSxDQUFDLEdBQUcsQ0FBQztpQkFDWCxJQUFJLENBQUMsT0FBTyxFQUFFLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFLENBQUMsNkJBQTZCLEdBQUcsS0FBSyxHQUFHLElBQUksQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztTQUM3RjthQUFNO1lBQ0gsZUFBZSxHQUFHLE9BQU8sQ0FBQyxLQUFLLEVBQUUsQ0FBQztTQUNyQztRQUVELElBQUksYUFBYSxHQUFRLGVBQWUsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDO2FBQy9DLElBQUksQ0FBQyxPQUFPLEVBQUUsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLEVBQUUsQ0FBQywyQkFBMkIsR0FBRyxLQUFLLEdBQUcsSUFBSSxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUMsQ0FBQzthQUNsRixJQUFJLENBQUMsV0FBVyxFQUFFLDJCQUEyQixHQUFHLElBQUksQ0FBQyxNQUFNLENBQUMsRUFBRSxHQUFHLEdBQUcsQ0FBQyxDQUFDO1FBRTNFLElBQUksWUFBWSxHQUFRLGVBQWUsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDO2FBQzlDLElBQUksQ0FBQyxPQUFPLEVBQUUsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLEVBQUUsQ0FBQywwQkFBMEIsR0FBRyxLQUFLLEdBQUcsSUFBSSxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUMsQ0FBQzthQUNqRixJQUFJLENBQUMsSUFBSSxFQUFFLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFLENBQUMsMEJBQTBCLEdBQUcsS0FBSyxHQUFHLElBQUksQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLEtBQUssRUFBRSxFQUFFLENBQUMsQ0FBQyxDQUFDO1FBRXZHLE9BQU8sRUFBRSxhQUFhLEVBQUUsYUFBYSxFQUFFLFlBQVksRUFBRSxZQUFZLEVBQUUsQ0FBQztJQUN4RSxDQUFDO0lBRU8sZUFBZTtRQUNuQixFQUFFLENBQUMsTUFBTSxDQUFDLEdBQUcsR0FBRyxJQUFJLENBQUMsTUFBTSxDQUFDLEVBQUUsR0FBRyxtQ0FBbUMsQ0FBQyxDQUFDLE1BQU0sRUFBRSxDQUFDO1FBRS9FLElBQUksQ0FBQyxLQUFLO2FBQ0wsTUFBTSxDQUFDLE1BQU0sQ0FBQzthQUNkLElBQUksQ0FBQyxPQUFPLEVBQUUsc0JBQXNCLENBQUM7YUFDckMsSUFBSSxDQUFDLEdBQUcsRUFBRSxJQUFJLENBQUMsZ0JBQWdCLENBQUM7YUFDaEMsSUFBSSxDQUFDLFdBQVcsRUFBRSxLQUFLLENBQUMsaUJBQWlCLENBQUMsSUFBSSxDQUFDLGNBQWMsQ0FBQyxDQUFDLEVBQUUsSUFBSSxDQUFDLGNBQWMsQ0FBQyxDQUFDLEVBQUUsSUFBSSxDQUFDLENBQUMsQ0FBQztJQUN4RyxDQUFDO0lBRU8sVUFBVSxDQUFDLEtBQXlCO1FBQ3hDLHVCQUF1QjtRQUN2Qix5QkFBeUI7UUFFekIsSUFBSSxlQUFlLEdBQVEsSUFBSSxDQUFDLHNCQUFzQixFQUFFLENBQUM7UUFFekQsSUFBSSxDQUFDLFNBQVMsQ0FBQyxLQUFLLEVBQUUsZUFBZSxDQUFDLGFBQWEsQ0FBQyxDQUFDO1FBRXJELElBQUksQ0FBQyxPQUFPLENBQUMsS0FBSyxFQUFFLGVBQWUsQ0FBQyxZQUFZLENBQUMsQ0FBQztRQUVsRCxLQUFLLElBQUksTUFBTSxHQUFXLENBQUMsRUFBRSxNQUFNLEdBQUcsS0FBSyxDQUFDLE1BQU0sRUFBRSxNQUFNLEVBQUUsRUFBRTtZQUMxRCxJQUFJLENBQUMsa0JBQWtCLENBQUMsTUFBTSxFQUFFLEtBQUssQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDO1NBQ2xEO0lBQ0wsQ0FBQztJQUVELGNBQWM7SUFDTixTQUFTLENBQUMsVUFBOEIsRUFBRSxRQUFhO1FBRTNELElBQUksSUFBSSxHQUFrRCxVQUFVLENBQUM7UUFFckUsSUFBSSxJQUFJLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxLQUFLLE9BQU87WUFBRSxJQUFJLEdBQUcsSUFBSSxDQUFDLFlBQVksQ0FBQyxVQUFVLENBQUMsQ0FBQztRQUV4RSxJQUFJLElBQUksQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLEtBQUssS0FBSyxFQUFFO1lBRTdCLElBQUksSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsS0FBSyxNQUFNLEVBQUU7Z0JBQzlCLFFBQVEsQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDO3FCQUNsQixJQUFJLENBQUMsR0FBRyxFQUFFLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFLENBQUMsSUFBSSxDQUFDLGFBQWEsQ0FBQyxDQUFDLEVBQUUsSUFBSSxDQUFDLENBQUM7cUJBQ2hELElBQUksQ0FBQyxPQUFPLEVBQUUsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLEVBQUUsQ0FBQyx5QkFBeUIsR0FBRyxDQUFDLENBQUM7cUJBQ3RELElBQUksQ0FBQyxNQUFNLEVBQUUsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQztxQkFDaEQsSUFBSSxDQUFDLGNBQWMsRUFBRSxJQUFJLENBQUMsQ0FBQzthQUNuQztZQUVELFFBQVEsQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDO2lCQUNsQixJQUFJLENBQUMsR0FBRyxFQUFFLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFO2dCQUNoQixJQUFJLElBQUksQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLEtBQUssTUFBTSxFQUFFO29CQUM5QixPQUFPLElBQUksQ0FBQyxhQUFhLENBQUMsQ0FBQyxFQUFFLElBQUksRUFBRSxJQUFJLENBQUMsQ0FBQztpQkFDNUM7Z0JBQ0QsT0FBTyxJQUFJLENBQUMsYUFBYSxDQUFDLENBQUMsRUFBRSxJQUFJLENBQUMsQ0FBQztZQUN2QyxDQUFDLENBQUM7aUJBQ0QsSUFBSSxDQUFDLE9BQU8sRUFBRSxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRSxDQUFDLHlCQUF5QixHQUFHLENBQUMsQ0FBQztpQkFDdEQsSUFBSSxDQUFDLFFBQVEsRUFBRSxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRSxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDO2lCQUNsRCxJQUFJLENBQUMsa0JBQWtCLEVBQUUsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDLENBQUM7aUJBQ2pGLEtBQUssQ0FBQyxNQUFNLEVBQUUsTUFBTSxDQUFDLENBQUM7U0FDOUI7SUFDTCxDQUFDO0lBRUQ7Ozs7Ozs7Ozs7Ozs7O09BY0c7SUFDSyxhQUFhLENBQUMsT0FBZSxFQUFFLFVBQXlELEVBQUUsZ0JBQTBCO1FBQ3hILGdCQUFnQixHQUFHLGdCQUFnQixJQUFJLEtBQUssQ0FBQztRQUU3QyxJQUFJLFVBQVUsR0FBZSxFQUFFLENBQUMsRUFBRSxJQUFJLEVBQUUsQ0FBQyxFQUFFLElBQUksRUFBRSxLQUFLLEVBQUUsS0FBSyxFQUFFLEVBQzNELFVBQVUsR0FBUSxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLEtBQUssUUFBUSxJQUFJLElBQUksQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxNQUFNLEdBQUcsQ0FBQyxDQUFDLEtBQUssUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxhQUFhLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxXQUFXLEVBQ2hKLEtBQUssR0FBUSxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLEtBQUssTUFBTSxJQUFJLGdCQUFnQixDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxJQUFJLEVBQUUsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLElBQUksRUFBRSxFQUN2RixJQUE0QyxDQUFDO1FBRWpELElBQUksR0FBRyxDQUFDLElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxVQUFVLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxVQUFVLENBQUMsQ0FBQyxDQUFDLFVBQVUsQ0FBQyxPQUFPLENBQUMsQ0FBQztRQUUvRSxJQUFJLFNBQVMsR0FBYSxLQUFLLENBQUMsS0FBSyxDQUFDLFVBQVUsQ0FBQyxDQUFDO1FBRWxELEtBQUssQ0FBQyxPQUFPLENBQUMsQ0FBQyxJQUE4QixFQUFFLE1BQWMsRUFBRSxFQUFFO1lBQzdELFVBQVUsR0FBRyxJQUFJLENBQUMsbUJBQW1CLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxFQUFFLE9BQU8sQ0FBQyxDQUFDO1lBQzdELE9BQU8sVUFBVSxDQUFDLEtBQUssQ0FBQztRQUM1QixDQUFDLENBQUMsQ0FBQztRQUVILEtBQUssQ0FBQyxDQUFDLENBQUMsR0FBRyxFQUFFLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxVQUFVLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUM7UUFFbEQsSUFBSSxJQUFJLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxLQUFLLE1BQU0sSUFBSSxnQkFBZ0IsRUFBRTtZQUNsRCxLQUFLLENBQUMsQ0FBQyxDQUFDLEdBQUcsRUFBRSxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7U0FDdkM7YUFBTTtZQUNILEtBQUssQ0FBQyxFQUFFLENBQUMsR0FBRyxFQUFFLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxVQUFVLENBQUMsQ0FBQyxDQUFDLENBQUM7aUJBQy9CLEVBQUUsQ0FBQyxDQUFDLElBQUksRUFBRSxFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxLQUFLLEtBQUssSUFBSSxJQUFJLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxLQUFLLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLFVBQVUsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO1NBQ3pIO1FBRUQsT0FBTyxTQUFTLENBQUMsSUFBSSxDQUFDLENBQUM7SUFDM0IsQ0FBQztJQUVPLGlCQUFpQixDQUFDLFlBQWlCO1FBQ3ZDLE9BQU8sSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsS0FBSyxPQUFPLENBQUM7SUFDekMsQ0FBQztJQUVPLGFBQWEsQ0FBQyxPQUFpQztRQUNuRCxPQUFPLElBQUksQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLEtBQUssT0FBTyxDQUFDO0lBQ3pDLENBQUM7SUFFTyxtQkFBbUIsQ0FBQyxLQUErQixFQUFFLE9BQWU7UUFDeEUsSUFBSSxJQUFJLENBQUMsYUFBYSxDQUFDLEtBQUssQ0FBQyxFQUFFLEVBQUUsUUFBUTtZQUNyQyxPQUFPLEtBQUssQ0FBQztTQUNoQjtRQUVELElBQUksTUFBTSxHQUFXLEtBQUssQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsR0FBRyxDQUFDO1FBQzFDLElBQUksS0FBSyxHQUFZLElBQUksQ0FBQztRQUMxQixJQUFJLEVBQUUsR0FBVyxDQUFDLENBQUM7UUFFbkIsSUFBSSxJQUFJLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxLQUFLLEtBQUssRUFBRTtZQUM3QixFQUFFLEdBQUcsS0FBSyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxHQUFHLEdBQUcsS0FBSyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxTQUFTLENBQUM7U0FDMUQ7YUFBTTtZQUNILEtBQUssR0FBRyxLQUFLLENBQUMsV0FBVyxDQUFDLEtBQUssRUFBRSxPQUFPLENBQUMsQ0FBQztTQUM3QztRQUNELE9BQU8sRUFBRSxDQUFDLEVBQUUsS0FBSyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsTUFBTSxFQUFFLEVBQUUsRUFBRSxFQUFFLEVBQUUsS0FBSyxFQUFFLEtBQUssRUFBRSxDQUFDO0lBQzNELENBQUM7SUFFRCxNQUFNO0lBQ0UsT0FBTyxDQUFDLEtBQXlCLEVBQUUsYUFBa0I7UUFDekQsS0FBSyxJQUFJLE1BQU0sR0FBVyxDQUFDLEVBQUUsTUFBTSxHQUFHLEtBQUssQ0FBQyxNQUFNLEVBQUUsTUFBTSxFQUFFLEVBQUU7WUFDMUQsSUFBSSxJQUFJLEdBQWdCLEtBQUssQ0FBQyxNQUFNLENBQUMsQ0FBQztZQUV0QyxJQUFJLElBQUksQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLEtBQUssT0FBTyxJQUFJLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDO2dCQUN2RCxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxJQUFJLElBQUksQ0FBQyxDQUFDLENBQUMsTUFBTSxJQUFJLENBQUMsQ0FBQztnQkFBRSxTQUFTO1lBRTVELElBQUksU0FBUyxHQUFRLGFBQWEsQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDO2lCQUM1QyxJQUFJLENBQUMsT0FBTyxFQUFFLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFLENBQUMsSUFBSSxDQUFDLGdCQUFnQixDQUFDLElBQUksRUFBRSxDQUFDLEVBQUUsTUFBTSxDQUFDLENBQUM7aUJBQy9ELElBQUksQ0FBQyxHQUFHLEVBQUUsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLE1BQU0sRUFBRSxDQUFDLEVBQUUsSUFBSSxFQUFFLE9BQU8sQ0FBQyxDQUFDO2lCQUM3RCxJQUFJLENBQUMsTUFBTSxFQUFFLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxNQUFNLEVBQUUsQ0FBQyxFQUFFLElBQUksRUFBRSxRQUFRLENBQUMsQ0FBQztpQkFDakUsSUFBSSxDQUFDLFFBQVEsRUFBRSxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRSxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsTUFBTSxFQUFFLENBQUMsRUFBRSxJQUFJLEVBQUUsYUFBYSxDQUFDLENBQUM7aUJBQ3hFLElBQUksQ0FBQyxjQUFjLEVBQUUsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLE1BQU0sRUFBRSxDQUFDLEVBQUUsSUFBSSxFQUFFLGFBQWEsQ0FBQyxDQUFDO2lCQUM5RSxJQUFJLENBQUMsV0FBVyxFQUFFLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxNQUFNLEVBQUUsQ0FBQyxFQUFFLElBQUksRUFBRSxVQUFVLENBQUMsQ0FBQztpQkFDeEUsS0FBSyxDQUFDLFNBQVMsRUFBRSxPQUFPLENBQUMsQ0FBQztZQUUvQixJQUFJLFlBQVksR0FBYSxJQUFJLENBQUMsb0JBQW9CLENBQUMsSUFBSSxDQUFDLENBQUM7WUFFN0QsS0FBSyxDQUFDLGdCQUFnQixDQUFDLFNBQVMsRUFBRSxFQUFFLElBQUksRUFBRSxJQUFJLEVBQUUsTUFBTSxFQUFFLE1BQU0sRUFBRSxRQUFRLEVBQUUsWUFBWSxFQUFFLENBQUMsQ0FBQztTQUM3RjtJQUNMLENBQUM7SUFFTyxTQUFTLENBQUMsT0FBZSxFQUFFLE9BQWUsRUFBRSxLQUFrQixFQUFFLFFBQXlFO1FBQzdJLElBQUksQ0FBQyxDQUFDLEtBQUssQ0FBQyxXQUFXLENBQUMsS0FBSyxFQUFFLE9BQU8sQ0FBQyxJQUFJLElBQUksQ0FBQyxVQUFVLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxVQUFVLENBQUM7WUFBRSxPQUFPLEVBQUUsQ0FBQztRQUN2RyxJQUFJLEVBQUUsR0FBRyxLQUFLLENBQUMsUUFBUSxDQUFDLE9BQU8sRUFBRSxLQUFLLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxLQUFLLEVBQUUsRUFBRSxDQUFDLENBQUM7UUFDekUsSUFBSSxLQUFLLEdBQW9CLEVBQUUsQ0FBQztRQUNoQyxJQUFJLFFBQVEsS0FBSyxVQUFVLEVBQUU7WUFDekIsSUFBSSxDQUFDLEdBQVcsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLEVBQUUsQ0FBQyxJQUFJLE9BQU8sSUFBSSxDQUFDLFFBQVEsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLEtBQUssV0FBVyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsY0FBYyxDQUFDLENBQUMsQ0FBQztZQUNoSSxJQUFJLENBQUMsR0FBVyxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsRUFBRSxDQUFDLElBQUksT0FBTyxJQUFJLENBQUMsUUFBUSxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsS0FBSyxXQUFXLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxjQUFjLENBQUMsQ0FBQyxDQUFDO1lBQ2hJLEtBQUssR0FBRyxLQUFLLENBQUMsaUJBQWlCLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxJQUFJLENBQUMsQ0FBQztTQUMvQzthQUFNO1lBQ0gsS0FBSyxHQUFHLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxFQUFFLENBQUMsSUFBSSxJQUFJLENBQUMsUUFBUSxDQUFDLEVBQUUsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsRUFBRSxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsUUFBUSxFQUFFLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQztTQUM1RztRQUNELE9BQU8sS0FBSyxDQUFDO0lBQ2pCLENBQUM7SUFFTyxnQkFBZ0IsQ0FBQyxLQUFrQixFQUFFLE9BQWUsRUFBRSxPQUFlO1FBQ3pFLElBQUksQ0FBQyxLQUFLLENBQUMsV0FBVyxDQUFDLEtBQUssRUFBRSxPQUFPLENBQUM7WUFBRSxPQUFPLEVBQUUsQ0FBQztRQUNsRCxJQUFJLEVBQUUsR0FBVyxLQUFLLENBQUMsUUFBUSxDQUFDLE9BQU8sRUFBRSxLQUFLLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxLQUFLLEVBQUUsRUFBRSxDQUFDLENBQUM7UUFDakYsSUFBSSxNQUFNLEdBQVcsS0FBSyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxLQUFLLENBQUM7UUFDNUMsSUFBSSxLQUFLLEdBQVcsS0FBSyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxLQUFLLENBQUM7UUFDM0MsSUFBSSxRQUFRLEdBQWMsSUFBSSxDQUFDLGVBQWUsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLEtBQUssRUFBRSxPQUFPLEVBQUUsS0FBSyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQztRQUM3RixJQUFJLFdBQVcsR0FBVyxJQUFJLENBQUMsVUFBVSxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsY0FBYyxDQUFDO1FBQzlFLElBQUksV0FBVyxHQUFXLElBQUksQ0FBQyxVQUFVLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxjQUFjLENBQUM7UUFFOUUsSUFBSSxDQUFDLFNBQVMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxFQUFFLE9BQU8sRUFBRSxRQUFRLENBQUMsQ0FBQyxFQUFFLFdBQVcsQ0FBQyxDQUFDO1FBRW5FLElBQUksS0FBSyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxLQUFLLEtBQUssSUFBSSxDQUFDLFNBQVMsSUFBSSxLQUFLLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLEtBQUssS0FBSyxJQUFJLENBQUMsU0FBUyxFQUFFO1lBQ3hGLElBQUksY0FBYyxHQUFHLEVBQUUsR0FBRyxXQUFXLENBQUM7WUFFdEMsSUFBSSxJQUFJLENBQUMsZUFBZSxHQUFHLGNBQWM7Z0JBQUUsSUFBSSxDQUFDLGVBQWUsR0FBRyxjQUFjLENBQUM7U0FDcEY7UUFFRCxJQUFJLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsUUFBUSxLQUFLLElBQUk7WUFDcEMsS0FBSyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxLQUFLLEdBQUcsSUFBSSxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsUUFBUSxDQUFDO1lBQ3BELENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsUUFBUSxLQUFLLElBQUk7Z0JBQ3BDLEtBQUssQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsS0FBSyxHQUFHLElBQUksQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLFFBQVEsQ0FBQyxFQUFFO1lBQ3RELE9BQU8sSUFBSSxDQUFDLFFBQVEsQ0FBQyxFQUFFLENBQUMsQ0FBQztZQUN6QixPQUFPLEVBQUUsQ0FBQztTQUNiO1FBRUQsSUFBSSxDQUFDLFFBQVEsQ0FBQyxFQUFFLENBQUMsR0FBRztZQUNoQixNQUFNLEVBQUUsTUFBTTtZQUNkLEtBQUssRUFBRSxLQUFLO1lBQ1osQ0FBQyxFQUFFLFFBQVEsQ0FBQyxDQUFDO1lBQ2IsQ0FBQyxFQUFFLFFBQVEsQ0FBQyxDQUFDO1lBQ2IsV0FBVyxFQUFFLFdBQVc7WUFDeEIsV0FBVyxFQUFFLFdBQVc7U0FDM0IsQ0FBQztRQUVGLE9BQU8sRUFBRSxDQUFDO0lBQ2QsQ0FBQztJQUVPLGVBQWUsQ0FBQyxPQUFlLEVBQUUsT0FBZSxFQUFFLE9BQWU7UUFDckUsSUFBSSxJQUFJLEdBQVcsQ0FBQyxDQUFDO1FBQ3JCLElBQUksSUFBSSxHQUFXLENBQUMsQ0FBQztRQUVyQixJQUFJLEdBQUcsQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDO1FBQ3JDLElBQUksR0FBRyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUM7UUFFN0IsT0FBTyxFQUFFLENBQUMsRUFBRSxJQUFJLEVBQUUsQ0FBQyxFQUFFLElBQUksRUFBRSxDQUFDO0lBQ2hDLENBQUM7SUFFRCxpQkFBaUI7SUFDVCxvQkFBb0IsQ0FBQyxZQUF5QjtRQUNsRCxPQUFPLFVBQVMsS0FBYSxFQUFFLFVBQW9CO1lBQy9DLFVBQVUsR0FBRyxVQUFVLElBQUksS0FBSyxDQUFDO1lBQ2pDLFlBQVksQ0FBQyxRQUFRLENBQUMsWUFBWSxFQUFFLEtBQUssRUFBRSxVQUFVLENBQUMsQ0FBQztRQUMzRCxDQUFDLENBQUM7SUFDTixDQUFDO0lBRU8sUUFBUSxDQUFDLFlBQXlCLEVBQUUsTUFBYyxFQUFFLFdBQW9CO1FBQzVFLE1BQU0sR0FBRyxNQUFNLENBQUMsT0FBTyxDQUFDLEtBQUssRUFBRSxFQUFFLENBQUMsQ0FBQztRQUNuQyxJQUFHLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxjQUFjLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLE1BQU0sQ0FBQyxDQUFDLEtBQUs7WUFBRSxPQUFPO1FBQ2pGLElBQUksS0FBSyxHQUFXLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxNQUFNLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxNQUFNLENBQUMsQ0FBQyxLQUFLLENBQUM7UUFDNUcsSUFBSSxRQUFRLEdBQWMsSUFBSSxDQUFDLGlCQUFpQixDQUFDLE1BQU0sRUFBRSxXQUFXLEVBQUUsS0FBSyxDQUFDLENBQUM7UUFDN0UsSUFBSSxXQUFXLEdBQVcsSUFBSSxDQUFDLFFBQVEsQ0FBQyxNQUFNLENBQUMsQ0FBQyxXQUFXLENBQUM7UUFFNUQsSUFBSSxXQUFXLEtBQUssQ0FBQyxJQUFJLFdBQVc7WUFBRSxXQUFXLEdBQUcsQ0FBQyxDQUFDO1FBRXRELElBQUksQ0FBQyxtQkFBbUIsQ0FBQyxNQUFNLEVBQUUsV0FBVyxDQUFDLENBQUM7UUFDOUMsRUFBRSxDQUFDLE1BQU0sQ0FBQyxHQUFHLEdBQUcsSUFBSSxDQUFDLE1BQU0sQ0FBQyxFQUFFLEdBQUcsZUFBZSxHQUFHLE1BQU0sQ0FBQzthQUNyRCxJQUFJLENBQUMsR0FBRyxFQUFFLEtBQUssQ0FBQzthQUNoQixJQUFJLENBQUMsV0FBVyxFQUFFLEtBQUssQ0FBQyxpQkFBaUIsQ0FBQyxRQUFRLENBQUMsQ0FBQyxFQUFFLFFBQVEsQ0FBQyxDQUFDLEVBQUUsSUFBSSxDQUFDLENBQUM7YUFDeEUsSUFBSSxDQUFDLGNBQWMsRUFBRSxXQUFXLENBQUMsQ0FBQztJQUMzQyxDQUFDO0lBRU8sbUJBQW1CLENBQUMsTUFBYyxFQUFFLFdBQW9CO1FBQzVELElBQUksTUFBTSxHQUFXLElBQUksQ0FBQyxRQUFRLENBQUMsTUFBTSxDQUFDLENBQUMsTUFBTSxDQUFDO1FBRWxELElBQUksUUFBUSxHQUFjLFdBQVcsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLGlCQUFpQixDQUFDLE1BQU0sRUFBRSxXQUFXLEVBQUUsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxjQUFjLENBQUM7UUFFaEgsRUFBRSxDQUFDLE1BQU0sQ0FBQyxHQUFHLEdBQUcsSUFBSSxDQUFDLE1BQU0sQ0FBQyxFQUFFLEdBQUcsbUNBQW1DLENBQUM7WUFDakUsNkJBQTZCO2FBQzVCLElBQUksQ0FBQyxNQUFNLEVBQUUsTUFBTSxDQUFDO2FBQ3BCLElBQUksQ0FBQyxXQUFXLEVBQUUsSUFBSSxDQUFDLGlCQUFpQixDQUFDLFFBQVEsQ0FBQyxDQUFDLEVBQUUsUUFBUSxDQUFDLENBQUMsRUFBRSxJQUFJLENBQUMsQ0FBQzthQUN2RSxJQUFJLENBQUMsY0FBYyxFQUFFLENBQUMsQ0FBQzthQUN2QixJQUFJLENBQUMsUUFBUSxFQUFFLE1BQU0sQ0FBQyxDQUFDO0lBQ2hDLENBQUM7SUFFTyxpQkFBaUIsQ0FBQyxNQUFjLEVBQUUsV0FBb0IsRUFBRSxhQUFzQjtRQUNsRixJQUFJLElBQUksR0FBVyxJQUFJLENBQUMsUUFBUSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQztRQUMzQyxJQUFJLElBQUksR0FBVyxJQUFJLENBQUMsUUFBUSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQztRQUUzQyxJQUFJLENBQUMsV0FBVztZQUFFLE9BQU8sRUFBRSxDQUFDLEVBQUUsSUFBSSxFQUFFLENBQUMsRUFBRSxJQUFJLEVBQUUsQ0FBQztRQUU5QyxJQUFJLGFBQWEsRUFBRTtZQUNmLElBQUksSUFBSSxDQUFDLENBQUM7WUFDVixJQUFJLElBQUksQ0FBQyxDQUFDO1NBQ2I7YUFBTTtZQUNILElBQUksSUFBSSxDQUFDLENBQUM7WUFDVixJQUFJLElBQUksQ0FBQyxDQUFDO1NBQ2I7UUFFRCxPQUFPLEVBQUUsQ0FBQyxFQUFFLElBQUksRUFBRSxDQUFDLEVBQUUsSUFBSSxFQUFFLENBQUM7SUFDaEMsQ0FBQztJQUVELFFBQVE7SUFDQSxTQUFTLENBQUMsTUFBZ0IsRUFBRSxPQUFlLEVBQUUsVUFBa0IsRUFBRSxTQUFpQjtRQUN0RixJQUFJLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLE9BQU87WUFBRSxPQUFPO1FBRTlDLFVBQVUsSUFBSSxTQUFTLEdBQUcsQ0FBQyxDQUFDO1FBRTVCLElBQUksS0FBSyxHQUFRLEtBQUssQ0FBQyxRQUFRLENBQUMsTUFBTSxFQUFFLE9BQU8sRUFBRSxVQUFVLEVBQUUsSUFBSSxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQztRQUNqRixrQ0FBa0M7UUFFbEMsSUFBSSxPQUFPLEdBQVEsS0FBSyxDQUFDLE1BQU0sQ0FBQyw2QkFBNkIsQ0FBQyxDQUFDO1FBRS9ELElBQUksZUFBZSxHQUFXLElBQUksQ0FBQyxtQkFBbUIsQ0FBQyxNQUFNLENBQUMsQ0FBQztRQUUvRCxJQUFJLE9BQU8sR0FBRyxFQUFFLEdBQUcsU0FBUyxDQUFDLENBQUMsNkNBQTZDO1FBQzNFLEtBQUssQ0FBQyxvQkFBb0IsQ0FBQyxPQUFPLEVBQUUsSUFBSSxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLEVBQUUsRUFBRSxPQUFPLEVBQUUsT0FBTyxFQUFFLFdBQVcsRUFBRSxlQUFlLEVBQUUsQ0FBQyxDQUFDO1FBRTVHLG1EQUFtRDtRQUNuRCwrREFBK0Q7UUFDL0QscUZBQXFGO1FBQ3JGLDRFQUE0RTtRQUM1RSxJQUFJO0lBQ1IsQ0FBQztJQUVPLG1CQUFtQixDQUFDLE1BQWdCO1FBQ3hDLElBQUksU0FBUyxHQUFHLElBQUksQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDLFNBQVMsRUFBRSxJQUFJLENBQUMsU0FBUyxDQUFDLFdBQVcsQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQztRQUU3RyxPQUFPLFNBQVMsQ0FBQyxRQUFRLEVBQUUsQ0FBQyxNQUFNLENBQUM7SUFDdkMsQ0FBQztJQUVELHdFQUF3RTtJQUV4RSxtRUFBbUU7SUFFbkUsK0NBQStDO0lBQy9DLGtGQUFrRjtJQUNsRixtREFBbUQ7SUFFbkQsc0RBQXNEO0lBRXRELDRCQUE0QjtJQUM1QixJQUFJO0lBRUosWUFBWTtJQUNKLGtCQUFrQjtRQUV0QixJQUFJLE9BQU8sR0FBVyxJQUFJLENBQUMsZUFBZSxHQUFHLENBQUMsQ0FBQztRQUMvQyxJQUFJLFdBQVcsR0FBVyxDQUFDLEdBQUcsT0FBTyxDQUFDO1FBRXRDLElBQUksSUFBSSxHQUFRLElBQUksQ0FBQyxTQUFTLENBQUMsTUFBTSxDQUFDLFVBQVUsQ0FBQzthQUM1QyxJQUFJLENBQUMsSUFBSSxFQUFFLFdBQVcsR0FBRyxJQUFJLENBQUMsTUFBTSxDQUFDLEVBQUUsQ0FBQyxDQUFDO1FBQzlDLElBQUksUUFBUSxHQUFRLElBQUksQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDO2FBQ2xDLElBQUksQ0FBQyxNQUFNLEVBQUUsT0FBTyxDQUFDO2FBQ3JCLElBQUksQ0FBQyxHQUFHLEVBQUUsV0FBVyxDQUFDO2FBQ3RCLElBQUksQ0FBQyxHQUFHLEVBQUUsV0FBVyxDQUFDO2FBQ3RCLElBQUksQ0FBQyxNQUFNLEVBQUUsTUFBTSxDQUFDO2FBQ3BCLElBQUksQ0FBQyxPQUFPLEVBQUUsQ0FBQyxDQUFDO2FBQ2hCLElBQUksQ0FBQyxRQUFRLEVBQUUsSUFBSSxDQUFDLE1BQU0sR0FBRyxJQUFJLENBQUMsZUFBZSxDQUFDLENBQUM7UUFFeEQsSUFBSSxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsV0FBVyxFQUFFLGdCQUFnQixHQUFHLElBQUksQ0FBQyxNQUFNLENBQUMsRUFBRSxHQUFHLEdBQUcsQ0FBQyxDQUFDO1FBRTFFLElBQUksY0FBYyxHQUFhLEVBQUUsQ0FBQyxVQUFVLEVBQUU7YUFDekMsUUFBUSxDQUFDLElBQUksQ0FBQyxrQkFBa0IsQ0FBQzthQUNqQyxJQUFJLENBQUMsRUFBRSxDQUFDLFVBQVUsQ0FBQyxDQUFDO1FBRXpCLFFBQVEsQ0FBQyxVQUFVLENBQUMsY0FBYyxDQUFDO2FBQzlCLElBQUksQ0FBQyxPQUFPLEVBQUUsSUFBSSxDQUFDLEtBQUssR0FBRyxJQUFJLENBQUMsZUFBZSxDQUFDLENBQUM7SUFDMUQsQ0FBQztJQUVPLGtCQUFrQixDQUFDLE9BQWUsRUFBRSxLQUFrQjtRQUMxRCxJQUFJLElBQUksQ0FBQyxNQUFNLENBQUMsS0FBSyxLQUFLLFNBQVMsSUFBSSxJQUFJLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxNQUFNLEtBQUssU0FBUyxFQUFFO1lBQzNFLElBQUksQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsT0FBTztnQkFBRSxPQUFPO1lBQzlDLElBQUksVUFBVSxHQUFXLEdBQUcsQ0FBQztZQUM3QixJQUFJLGNBQWMsR0FBVyxPQUFPLEdBQUcsSUFBSSxDQUFDLGtCQUFrQixHQUFHLEtBQUssQ0FBQyxDQUFDLENBQUMsTUFBTSxHQUFHLFVBQVUsQ0FBQztZQUM3RixJQUFJLGNBQWMsR0FBVyxJQUFJLENBQUMsTUFBTSxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLGtCQUFrQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7WUFDakYsY0FBYyxHQUFHLElBQUksQ0FBQyxNQUFNLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxjQUFjLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztZQUU1RCxFQUFFLENBQUMsU0FBUyxDQUFDLEdBQUcsR0FBRyxJQUFJLENBQUMsTUFBTSxDQUFDLEVBQUUsR0FBRyx1Q0FBdUMsR0FBRyxPQUFPLENBQUM7aUJBQ2pGLFVBQVUsRUFBRSxDQUFFLDZCQUE2QjtpQkFDM0MsUUFBUSxDQUFDLGNBQWMsQ0FBQyxDQUFFLHNCQUFzQjtpQkFDaEQsS0FBSyxDQUFDLGNBQWMsQ0FBQztpQkFDckIsRUFBRSxDQUFDLE9BQU8sRUFBRSxVQUFTLENBQUMsRUFBRSxDQUFDO2dCQUN0QixFQUFFLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxDQUFFLG1DQUFtQztxQkFDL0MsS0FBSyxDQUFDLFlBQVksRUFBRSxTQUFTLENBQUMsQ0FBQztnQkFDcEMsOEJBQThCO1lBQ2xDLENBQUMsQ0FBQyxDQUFDO1NBQ1Y7SUFDTCxDQUFDO0lBRUQseUJBQXlCO0lBRXpCOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7T0F3Qkc7SUFDSyxZQUFZLENBQUMsS0FBeUI7UUFDMUMsc0JBQXNCO1FBQ3RCLElBQUksT0FBTyxHQUE2QixFQUFFLENBQUM7UUFDM0MsSUFBSSxjQUFjLEdBQVksRUFBRSxDQUFDO1FBRWpDLEtBQUssSUFBSSxDQUFDLEdBQVcsQ0FBQyxFQUFFLENBQUMsR0FBRyxJQUFJLENBQUMsV0FBVyxDQUFDLE1BQU0sRUFBRSxFQUFFLENBQUMsRUFBRTtZQUV0RCxJQUFJLFdBQVcsR0FBc0IsRUFBRSxDQUFDO1lBRXhDLElBQUksQ0FBQyxHQUFXLElBQUksQ0FBQztZQUNyQixJQUFJLENBQUMsR0FBVyxDQUFDLENBQUM7WUFDbEIsSUFBSSxFQUFFLEdBQVcsQ0FBQyxDQUFDO1lBQ25CLElBQUksS0FBSyxHQUFZLElBQUksQ0FBQztZQUUxQixLQUFLLElBQUksTUFBTSxHQUFXLENBQUMsRUFBRSxNQUFNLEdBQUcsS0FBSyxDQUFDLE1BQU0sRUFBRSxFQUFFLE1BQU0sRUFBRTtnQkFDMUQsSUFBSSxNQUFNLEdBQVcsS0FBSyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUM7Z0JBRTNDLEtBQUssSUFBSSxNQUFNLEdBQVcsQ0FBQyxFQUFFLE1BQU0sR0FBRyxLQUFLLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sRUFBRSxFQUFFLE1BQU0sRUFBRTtvQkFDcEUsSUFBSSxFQUFFLEdBQVcsS0FBSyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxFQUFFLENBQUM7b0JBQzVDLENBQUMsR0FBRyxNQUFNLENBQUM7b0JBRVgsS0FBSyxHQUFHLEtBQUssQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsS0FBSyxLQUFLLElBQUksQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUM7b0JBRTlELElBQUksSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsS0FBSyxPQUFPLElBQUksRUFBRSxLQUFLLElBQUksQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDLEVBQUU7d0JBRTdELElBQUksU0FBUyxHQUFXLElBQUksQ0FBQyxtQkFBbUIsQ0FBQyxLQUFLLEVBQUUsTUFBTSxFQUFFLE1BQU0sQ0FBQyxDQUFDO3dCQUN4RSxJQUFJLFdBQVcsR0FBRyxDQUFDLE9BQU8sY0FBYyxDQUFDLE1BQU0sQ0FBQyxLQUFLLFdBQVcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLGNBQWMsQ0FBQyxNQUFNLENBQUMsQ0FBQzt3QkFDL0YsY0FBYyxDQUFDLE1BQU0sQ0FBQyxHQUFHLFdBQVcsR0FBRyxTQUFTLENBQUM7d0JBRWpELElBQUksTUFBTSxHQUFXLGNBQWMsQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLENBQUM7d0JBQ2pELElBQUksWUFBWSxHQUFXLEtBQUssQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsS0FBSyxDQUFDO3dCQUV6RCxDQUFDLEdBQUcsS0FBSyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxHQUFHLEdBQUcsTUFBTSxDQUFDO3dCQUN6QyxFQUFFLEdBQUcsQ0FBQyxHQUFHLFlBQVksQ0FBQzt3QkFFdEIsV0FBVyxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFLEtBQUssRUFBRSxDQUFDLEVBQUUsS0FBSyxFQUFFLENBQUMsRUFBRSxFQUFFLENBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRSxFQUFFLEVBQUUsRUFBRSxFQUFFLEVBQUUsRUFBRSxFQUFFLEtBQUssRUFBRSxLQUFLLEVBQUUsQ0FBQyxDQUFDO3dCQUVwRixJQUFJLGFBQWEsR0FBZSxJQUFJLENBQUMsaUJBQWlCLENBQUMsS0FBSyxFQUFFLE1BQU0sRUFBRSxNQUFNLEVBQUUsY0FBYyxDQUFDLENBQUM7d0JBRTlGLElBQUksYUFBYSxDQUFDLEtBQUssS0FBSyxJQUFJLEVBQUU7NEJBQzlCLFdBQVcsQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDLEVBQUUsYUFBYSxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsYUFBYSxDQUFDLENBQUMsRUFBRSxFQUFFLEVBQUUsYUFBYSxDQUFDLEVBQUUsRUFBRSxFQUFFLEVBQUUsRUFBRSxFQUFFLEtBQUssRUFBRSxLQUFLLEVBQUUsQ0FBQyxDQUFDOzRCQUN6RyxXQUFXLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxFQUFFLGFBQWEsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLGFBQWEsQ0FBQyxDQUFDLEVBQUUsRUFBRSxFQUFFLGFBQWEsQ0FBQyxFQUFFLEVBQUUsRUFBRSxFQUFFLEVBQUUsRUFBRSxLQUFLLEVBQUUsSUFBSSxFQUFFLENBQUMsQ0FBQzt5QkFDM0c7d0JBRUQsTUFBTTtxQkFDVDtpQkFDSjthQUNKO1lBQ0QsT0FBTyxDQUFDLElBQUksQ0FBQyxXQUFXLENBQUMsQ0FBQztTQUM3QjtRQUNELHdCQUF3QjtRQUN4QixPQUFPLE9BQU8sQ0FBQztJQUNuQixDQUFDO0lBRUQ7Ozs7Ozs7T0FPRztJQUNLLG1CQUFtQixDQUFDLEtBQXlCLEVBQUUsT0FBZSxFQUFFLE9BQWU7UUFDbkYsSUFBSSxVQUFVLEdBQVcsS0FBSyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxLQUFLLENBQUM7UUFFekQsSUFBSSxjQUFjLEdBQVksS0FBSyxDQUFDO1FBRXBDLElBQUksWUFBWSxHQUFXLElBQUksQ0FBQyxTQUFTLENBQUMsWUFBWSxDQUFDLEtBQUssRUFBRSxPQUFPLEVBQUUsT0FBTyxDQUFDLENBQUM7UUFDaEYsSUFBSSxVQUFVLEdBQVksWUFBWSxDQUFDLFlBQVksQ0FBQyxDQUFDO1FBQ3JELElBQUksV0FBVyxHQUFZLFlBQVksQ0FBQyxZQUFZLENBQUMsSUFBSSxDQUFDLE9BQU8sR0FBRyxDQUFDLElBQUksVUFBVSxDQUFDLENBQUM7UUFDckYsSUFBSSxPQUFPLEdBQUcsQ0FBQyxFQUFFO1lBQ2IsSUFBSSxXQUFXLEdBQVcsSUFBSSxDQUFDLFNBQVMsQ0FBQyxZQUFZLENBQUMsS0FBSyxFQUFFLENBQUMsT0FBTyxHQUFHLENBQUMsQ0FBQyxFQUFFLE9BQU8sQ0FBQyxDQUFDO1lBQ3JGLGNBQWMsR0FBRyxXQUFXLENBQUMsZ0JBQWdCLENBQUMsQ0FBQztTQUNsRDtRQUVELElBQUksVUFBVSxLQUFLLElBQUksSUFBSSxXQUFXLElBQUksVUFBVSxJQUFJLGNBQWMsRUFBRTtZQUNwRSxPQUFPLFVBQVUsQ0FBQztTQUNyQjtRQUNELE9BQU8sQ0FBQyxDQUFDO0lBQ2IsQ0FBQztJQUVEOzs7Ozs7Ozs7Ozs7T0FZRztJQUNLLGlCQUFpQixDQUFDLEtBQXlCLEVBQUUsT0FBZSxFQUFFLE9BQWUsRUFBRSxPQUFnQjtRQUVuRyxJQUFJLFlBQVksR0FBVyxLQUFLLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLEtBQUssQ0FBQztRQUUzRCxJQUFJLEtBQUssR0FBWSxLQUFLLENBQUM7UUFDM0IsSUFBSSxDQUFDLEdBQVcsS0FBSyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxHQUFHLEdBQUcsQ0FBQyxPQUFPLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUM7UUFDeEUsSUFBSSxDQUFDLEdBQVcsS0FBSyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUM7UUFDdkMsSUFBSSxFQUFFLEdBQVcsQ0FBQyxHQUFHLFlBQVksQ0FBQztRQUVsQyxJQUFJLFlBQVksS0FBSyxJQUFJLEVBQUU7WUFDdkIsT0FBTyxFQUFFLENBQUMsRUFBRSxFQUFFLEtBQUssRUFBRSxDQUFDLEVBQUUsS0FBSyxFQUFFLENBQUMsRUFBRSxFQUFFLENBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRSxFQUFFLEVBQUUsRUFBRSxLQUFLLEVBQUUsS0FBSyxFQUFFLENBQUM7U0FDcEU7UUFFRCxJQUFJLGNBQWMsR0FBRyxPQUFPLEdBQUcsQ0FBQyxJQUFJLE9BQU8sR0FBRyxLQUFLLENBQUMsTUFBTSxHQUFHLENBQUM7WUFDMUQsS0FBSyxDQUFDLE9BQU8sR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsS0FBSyxLQUFLLElBQUk7WUFDNUMsWUFBWSxLQUFLLElBQUksSUFBSSxLQUFLLENBQUMsT0FBTyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxLQUFLLEtBQUssSUFBSSxDQUFDO1FBRTFFLElBQUksYUFBYSxHQUFHLE9BQU8sR0FBRyxDQUFDLElBQUksT0FBTyxHQUFHLEtBQUssQ0FBQyxNQUFNLEdBQUcsQ0FBQztZQUN6RCxLQUFLLENBQUMsT0FBTyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxLQUFLLEtBQUssSUFBSTtZQUM1QyxZQUFZLEtBQUssSUFBSSxJQUFJLEtBQUssQ0FBQyxPQUFPLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLEtBQUssS0FBSyxJQUFJLENBQUM7UUFFMUUsSUFBSSxhQUFhLEVBQUU7WUFDZixPQUFPLENBQUMsUUFBUSxHQUFHLE9BQU8sQ0FBQyxHQUFHLENBQUMsT0FBTyxDQUFDLFFBQVEsR0FBRyxPQUFPLENBQUMsSUFBSSxDQUFDLENBQUMsR0FBRyxZQUFZLENBQUM7U0FDbkY7UUFFRCxJQUFJLGNBQWMsRUFBRTtZQUNoQixPQUFPLENBQUMsUUFBUSxHQUFHLE9BQU8sQ0FBQyxHQUFHLENBQUMsT0FBTyxDQUFDLFFBQVEsR0FBRyxPQUFPLENBQUMsSUFBSSxDQUFDLENBQUMsR0FBRyxZQUFZLENBQUM7U0FDbkY7UUFFRCxJQUFJLFlBQVksS0FBSyxJQUFJLElBQUksT0FBTyxDQUFDLFFBQVEsR0FBRyxPQUFPLENBQUMsRUFBRTtZQUN0RCxDQUFDLEdBQUcsQ0FBQyxHQUFHLE9BQU8sQ0FBQyxRQUFRLEdBQUcsT0FBTyxDQUFDLENBQUM7WUFDcEMsRUFBRSxHQUFHLEVBQUUsR0FBRyxDQUFDLENBQUM7WUFDWixLQUFLLEdBQUcsSUFBSSxDQUFDO1NBQ2hCO1FBRUQsT0FBTyxFQUFFLENBQUMsRUFBRSxFQUFFLEtBQUssRUFBRSxDQUFDLEVBQUUsS0FBSyxFQUFFLENBQUMsRUFBRSxFQUFFLENBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRSxFQUFFLEVBQUUsRUFBRSxLQUFLLEVBQUUsS0FBSyxFQUFFLENBQUM7SUFDckUsQ0FBQzs7O1lBN3FCSixTQUFTLFNBQUM7Z0JBQ1AsUUFBUSxFQUFFLGVBQWU7Z0JBQ3pCLFFBQVEsRUFBRTs7OztLQUlUO2dCQUNELGFBQWEsRUFBRSxpQkFBaUIsQ0FBQyxJQUFJO2dCQUNyQyxTQUFTLEVBQUUsQ0FBQyxXQUFXLEVBQUUsWUFBWSxDQUFDO2FBQ3pDOzs7WUF0RFEsV0FBVztZQVNYLFlBQVk7OzttQkFzRmhCLEtBQUs7cUJBQ0wsS0FBSzt5QkFDTCxLQUFLLFNBQUMsUUFBUTtrQkFDZCxLQUFLIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHtcclxuICAgIENvbXBvbmVudCxcclxuICAgIFZpZXdFbmNhcHN1bGF0aW9uLFxyXG4gICAgT25Jbml0LFxyXG4gICAgT25DaGFuZ2VzLFxyXG4gICAgU2ltcGxlQ2hhbmdlcyxcclxuICAgIE9uRGVzdHJveSxcclxuICAgIElucHV0XHJcbn0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XHJcbmltcG9ydCAqIGFzIGQzIGZyb20gJ2QzJztcclxuaW1wb3J0IHsgS2RDaGFydEJhc2VDbGFzcyB9IGZyb20gJy4uL2tkLWFuZ3VsYXItY2hhcnQtYmFzZS1jbGFzcyc7XHJcbmltcG9ydCB7IEtkQ2hhcnRzU3ZjIH0gZnJvbSAnLi4va2QtYW5ndWxhci1jaGFydHMtc3ZjJztcclxuaW1wb3J0IHtcclxuICAgIElDaGFydENvbmZpZyxcclxuICAgIElEM0RhdGEsXHJcbiAgICBJRDNEYXRhRGF0YSxcclxuICAgIElEM1lEYXRhLFxyXG4gICAgSUxlZ2VuZERhdGEsXHJcbiAgICBJQ2hhcnRJbnRlcm5hbEFwaVxyXG59IGZyb20gJy4uL2tkLWFuZ3VsYXItY2hhcnRzLWludGVyZmFjZSc7XHJcbmltcG9ydCB7IEtkRG9tRWxlbVN2YyB9IGZyb20gJy4uLy4uL2tkLWNvbW1vbi9pbmRleCc7XHJcblxyXG5pbnRlcmZhY2UgSURhdGFWYWx1ZSB7XHJcbiAgICB4OiB7XHJcbiAgICAgICAgdmFsdWU6IHN0cmluZyB8IG51bWJlcjtcclxuICAgICAgICBsYWJlbDogc3RyaW5nIHwgbnVtYmVyO1xyXG4gICAgfTtcclxuICAgIHk6IG51bWJlcjtcclxuICAgIHZhbGlkPzogYm9vbGVhbjtcclxuICAgIHkwPzogbnVtYmVyO1xyXG4gICAgYWRqdXN0Pzogb2JqZWN0O1xyXG4gICAgaWQ/OiBzdHJpbmc7XHJcbn1cclxuXHJcbmludGVyZmFjZSBJQWRqdXN0IHtcclxuICAgIFtrZXk6IG51bWJlcl06IG51bWJlcjtcclxufVxyXG5cclxuaW50ZXJmYWNlIElEb3REYXRhIHtcclxuICAgIGNvbG91cj86IHN0cmluZztcclxuICAgIHNoYXBlPzogc3RyaW5nO1xyXG4gICAgeD86IG51bWJlcjtcclxuICAgIHk/OiBudW1iZXI7XHJcbiAgICBib3JkZXJDb2xvcj86IHN0cmluZztcclxuICAgIGJvcmRlcldpZHRoPzogbnVtYmVyO1xyXG59XHJcblxyXG5pbnRlcmZhY2UgSURvdCB7XHJcbiAgICBba2V5OiBzdHJpbmddOiBJRG90RGF0YTtcclxufVxyXG5cclxuaW50ZXJmYWNlIElQb3NpdGlvbiB7XHJcbiAgICB4OiBudW1iZXI7XHJcbiAgICB5OiBudW1iZXI7XHJcbn1cclxuXHJcbkBDb21wb25lbnQoe1xyXG4gICAgc2VsZWN0b3I6ICdrZC1saW5lLWNoYXJ0JyxcclxuICAgIHRlbXBsYXRlOiBgXHJcbiAgICAgICAgPGRpdiAqbmdJZj1cImNoYXJ0VHlwZVsxXSA9PT0gJzEwMCcgJiYgaGF2ZU5lZ2F0aXZlXCIgY2xhc3M9XCJrZHgtY2hhcnRzLWVycm9yLW1zZ1wiPlxyXG4gICAgICAgICAgICB7e2Vycm9yTXNnfX1cclxuICAgICAgICA8L2Rpdj5cclxuICAgIGAsXHJcbiAgICBlbmNhcHN1bGF0aW9uOiBWaWV3RW5jYXBzdWxhdGlvbi5Ob25lLFxyXG4gICAgcHJvdmlkZXJzOiBbS2RDaGFydHNTdmMsIEtkRG9tRWxlbVN2Y11cclxufSlcclxuXHJcbmV4cG9ydCBjbGFzcyBLZExpbmVDaGFydCBleHRlbmRzIEtkQ2hhcnRCYXNlQ2xhc3MgaW1wbGVtZW50cyBPbkluaXQsIE9uQ2hhbmdlcywgT25EZXN0cm95IHtcclxuXHJcbiAgICBwcml2YXRlIGxpbmVDaGFydDogYW55O1xyXG5cclxuICAgIHByaXZhdGUgX3Nlcmllc0xpc3Q6IEFycmF5PHN0cmluZz4gPSBbXTtcclxuXHJcbiAgICBwcml2YXRlIF9yZXNpemVUaW1lb3V0OiBudW1iZXI7XHJcblxyXG4gICAgLy8gRG90IFNldHRpbmdcclxuICAgIHByaXZhdGUgX2hvdmVyQmFja2dyb3VuZDogc3RyaW5nID0gJ00gMTAsIDEwIG0gLTEwLCAwIGEgMTAsMTAgMCAxLDAgMjAsMCBhIDEwLDEwIDAgMSwwIC0yMCwwJztcclxuXHJcbiAgICBwcml2YXRlIF9zaGFwZXM6IG9iamVjdCA9IHtcclxuICAgICAgICAnTSA0IDAgTCA0IDAgTCAwIDggTCA4IDggeic6ICdNIDYgMCBMIDYgMCBMIDAgMTIgTCAxMiAxMiB6JyxcclxuICAgICAgICAnTSAwIDAgTCA4IDAgTCA0IDggTCA0IDggeic6ICdNIDAgMCBMIDEyIDAgTCA2IDEyIEwgNiAxMiB6JyxcclxuICAgICAgICAnTSA0IDAgTCA4IDQgTCA0IDggTCAwIDQgeic6ICdNIDYgMCBMIDEyIDYgTCA2IDEyIEwgMCA2IHonLFxyXG4gICAgICAgICdNIDQgMCBBIDQgNCAwIDEgMCA0IDggQSA0IDQgMCAxIDAgNCAwIFonOiAnTSA2IDAgQSA2IDYgMCAxIDAgNiAxMiBBIDYgNiAwIDEgMCA2IDAgWicsXHJcbiAgICAgICAgJ00gMCAwIEwgOCAwIEwgOCA4IEwgMCA4IHonOiAnTSAwIDAgTCAxMiAwIEwgMTIgMTIgTCAwIDEyIHonXHJcbiAgICB9O1xyXG5cclxuICAgIHByaXZhdGUgX2RvdERhdGE6IElEb3QgPSB7fTtcclxuXHJcbiAgICBwcml2YXRlIF9iaWdnZXN0RG90U2l6ZTogbnVtYmVyID0gMTI7XHJcblxyXG4gICAgcHJpdmF0ZSBfZGVmYXVsdERvdFBvczogSVBvc2l0aW9uID0ge3g6IC05OTksIHk6IC05OTl9O1xyXG5cclxuICAgIHByaXZhdGUgX2xpbmVTdHlsZTogb2JqZWN0ID0ge1xyXG4gICAgICAgIHNvbGlkOiAnbm9uZScsXHJcbiAgICAgICAgc2hvcnREYXNoOiAnNiwyJyxcclxuICAgICAgICBzaG9ydERvdDogJzIsMicsXHJcbiAgICAgICAgc2hvcnREYXNoRG90OiAnNiwyLDIsMicsXHJcbiAgICAgICAgc2hvcnREYXNoRG90RG90OiAnNiwyLDIsMiwyLDInLFxyXG4gICAgICAgIGRvdDogJzIsNicsXHJcbiAgICAgICAgZGFzaDogJzgsNicsXHJcbiAgICAgICAgbG9uZ0Rhc2g6ICcxNiw2JyxcclxuICAgICAgICBkYXNoRG90OiAnOCw2LDIsNicsXHJcbiAgICAgICAgbG9uZ0Rhc2hEb3Q6ICcxNiw2LDIsNicsXHJcbiAgICAgICAgbG9uZ0Rhc2hEb3REb3Q6ICcxNiw2LDIsNiwyLDYnXHJcbiAgICB9O1xyXG5cclxuICAgIEBJbnB1dCgpIGRhdGE6IEFycmF5PElEM0RhdGFEYXRhPjtcclxuICAgIEBJbnB1dCgpIGNvbmZpZzogSUNoYXJ0Q29uZmlnO1xyXG4gICAgQElucHV0KCdsZWdlbmQnKSBsZWdlbmREYXRhOiB7IFtrZXk6IHN0cmluZ106IElMZWdlbmREYXRhIH07XHJcbiAgICBASW5wdXQoKSBhcGk6IElDaGFydEludGVybmFsQXBpO1xyXG5cclxuICAgIGNvbnN0cnVjdG9yKHB1YmxpYyBfY2hhcnRTdmM6IEtkQ2hhcnRzU3ZjLCBwdWJsaWMgX2RvbVN2YzogS2REb21FbGVtU3ZjKSB7XHJcbiAgICAgICAgc3VwZXIoX2NoYXJ0U3ZjLCBfZG9tU3ZjKTtcclxuICAgIH1cclxuXHJcbiAgICBuZ09uSW5pdCgpOiB2b2lkIHtcclxuXHJcbiAgICAgICAgdGhpcy5hcGkubGVnZW5kQ2xpY2sgPSAoX2RhdGE6IElEM0RhdGEpID0+IHtcclxuICAgICAgICAgICAgdGhpcy5fcmVkcmF3Q2hhcnQoZmFsc2UsIF9kYXRhKTtcclxuICAgICAgICB9O1xyXG4gICAgICAgIHRoaXMuYXBpLnJlZHJhdyA9ICgpID0+IHtcclxuICAgICAgICAgICAgY2xlYXJUaW1lb3V0KHRoaXMuX3Jlc2l6ZVRpbWVvdXQpO1xyXG4gICAgICAgICAgICB0aGlzLl9yZXNpemVUaW1lb3V0ID0gc2V0VGltZW91dCgoKSA9PiB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLl9yZWRyYXdDaGFydChmYWxzZSk7XHJcbiAgICAgICAgICAgIH0pO1xyXG4gICAgICAgIH07XHJcbiAgICB9XHJcblxyXG4gICAgbmdPbkNoYW5nZXMoX2NoYW5nZXM6IFNpbXBsZUNoYW5nZXMpOiB2b2lkIHtcclxuICAgICAgICBpZiAoX2NoYW5nZXMuaGFzT3duUHJvcGVydHkoJ2RhdGEnKSkge1xyXG4gICAgICAgICAgICB0aGlzLl9yZWRyYXdDaGFydChfY2hhbmdlcy5kYXRhLmlzRmlyc3RDaGFuZ2UoKSwgX2NoYW5nZXMuZGF0YS5jdXJyZW50VmFsdWUpO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgaWYgKF9jaGFuZ2VzLmhhc093blByb3BlcnR5KCdjb25maWcnKSAmJiAhX2NoYW5nZXMuY29uZmlnLmlzRmlyc3RDaGFuZ2UoKSkge1xyXG4gICAgICAgICAgICB0aGlzLl9yZWRyYXdDaGFydChfY2hhbmdlcy5jb25maWcuaXNGaXJzdENoYW5nZSgpKTtcclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgbmdPbkRlc3Ryb3koKTogdm9pZCB7IHRoaXMucmVtb3ZlTGluZUNoYXJ0KCk7IH1cclxuXHJcbiAgICBwcml2YXRlIF9yZWRyYXdDaGFydChfaXNGaXJzdENoYW5nZTogYm9vbGVhbiwgX2RhdGE/OiBJRDNEYXRhKSB7XHJcbiAgICAgICAgaWYgKCFfaXNGaXJzdENoYW5nZSkge1xyXG4gICAgICAgICAgICB0aGlzLmxpbmVDaGFydCA9IGQzLnNlbGVjdCgnI2xpbmUtJyArIHRoaXMuY29uZmlnLmlkKTtcclxuICAgICAgICAgICAgdGhpcy5yZW1vdmVMaW5lQ2hhcnQoKTtcclxuICAgICAgICB9XHJcbiAgICAgICAgaWYgKF9kYXRhKSB0aGlzLl9zZXREYXRhKF9kYXRhKTtcclxuICAgICAgICBzdXBlci5jaGFydFRpbWVvdXQoKCkgPT4gdGhpcy5fc2V0Q2hhcnQoKSk7XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfc2V0RGF0YShfZGF0YTogSUQzRGF0YSk6IHZvaWQge1xyXG4gICAgICAgIHRoaXMuY2hhcnRUeXBlID0gX2RhdGEubGF5b3V0LnNwbGl0KCctJyk7XHJcbiAgICAgICAgdGhpcy5jaGFydENhdGVnb3J5ID0gJ2xpbmUnO1xyXG4gICAgICAgIHRoaXMuZGF0YVJhbmdlID0gX2RhdGEucmFuZ2U7XHJcbiAgICAgICAgdGhpcy5oYXZlTmVnYXRpdmUgPSBfZGF0YS5oYXZlTmVnYXRpdmU7XHJcblxyXG4gICAgICAgIHRoaXMuZGF0YSA9IE9iamVjdC5hc3NpZ24oW10sIF9kYXRhLmRhdGEpO1xyXG4gICAgICAgIHRoaXMuaW5pdERhdGEgPSBKU09OLnBhcnNlKEpTT04uc3RyaW5naWZ5KHRoaXMuZGF0YSkpO1xyXG5cclxuICAgICAgICB0aGlzLl9zZXJpZXNMaXN0ID0gT2JqZWN0LmtleXModGhpcy5sZWdlbmREYXRhKS5maWx0ZXIoa2V5ID0+ICF0aGlzLmxlZ2VuZERhdGFba2V5XS5kZWFjdGl2ZSk7XHJcblxyXG4gICAgICAgIGlmICh0aGlzLmNoYXJ0VHlwZVsxXSA9PT0gJ3N0YWNrJyB8fCB0aGlzLmNoYXJ0VHlwZVsxXSA9PT0gJzEwMCcpIHtcclxuICAgICAgICAgICAgdGhpcy5fc2VyaWVzTGlzdCA9IHRoaXMuX3Nlcmllc0xpc3QucmV2ZXJzZSgpO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIHJlbW92ZUxpbmVDaGFydCgpOiB2b2lkIHtcclxuICAgICAgICBzdXBlci5yZW1vdmVDaGFydCgpO1xyXG4gICAgICAgIGlmICh0aGlzLmxpbmVDaGFydCkge1xyXG4gICAgICAgICAgICB0aGlzLmxpbmVDaGFydC5yZW1vdmUoKTtcclxuICAgICAgICAgICAgdGhpcy5saW5lQ2hhcnQgPSBudWxsO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF9zZXRDaGFydCgpOiB2b2lkIHtcclxuICAgICAgICBpZiAodGhpcy5jaGFydFR5cGVbMV0gPT09ICcxMDAnICYmIHRoaXMuaGF2ZU5lZ2F0aXZlKSByZXR1cm47XHJcbiAgICAgICAgc3VwZXIuc2V0U3ZnKCk7XHJcblxyXG4gICAgICAgIHRoaXMuX3NldEF4aXNEb21haW4oKTtcclxuXHJcbiAgICAgICAgdGhpcy5fY3JlYXRlSG92ZXJEb3QoKTtcclxuXHJcbiAgICAgICAgdGhpcy5fY3JlYXRlQ2hhcnQoKTtcclxuXHJcbiAgICAgICAgdGhpcy5fZHJhd0NoYXJ0KHRoaXMuZGF0YSk7XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfc2V0QXhpc0RvbWFpbigpOiB2b2lkIHtcclxuXHJcbiAgICAgICAgaWYgKHRoaXMuY2hhcnRUeXBlW3RoaXMuY2hhcnRUeXBlLmxlbmd0aCAtIDFdID09PSAndHlwZTEnKSB7XHJcbiAgICAgICAgICAgIHN1cGVyLnNldERvbWFpbignYmFuZCcpO1xyXG4gICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgIHN1cGVyLnNldERvbWFpbignc3RyaW5nJyk7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX2NyZWF0ZUNoYXJ0KCk6IHZvaWQge1xyXG4gICAgICAgIGlmICghdGhpcy5saW5lQ2hhcnQpIHtcclxuICAgICAgICAgICAgdGhpcy5saW5lQ2hhcnQgPSB0aGlzLmdyYXBoLmFwcGVuZCgnZycpXHJcbiAgICAgICAgICAgICAgICAuYXR0cignY2xhc3MnLCAna2R4LWNoYXJ0cy1saW5lLWNoYXJ0JylcclxuICAgICAgICAgICAgICAgIC5hdHRyKCdpZCcsICdsaW5lLScgKyB0aGlzLmNvbmZpZy5pZCk7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICBpZiAodGhpcy5jb25maWcuYW5pbWF0aW9uKSB0aGlzLl9zZXRDaGFydEFuaW1hdGlvbigpO1xyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX2NyZWF0ZVNlcmllc0NvbnRhaW5lcigpOiB7IGxpbmVDb250YWluZXI6IGFueSwgZG90Q29udGFpbmVyOiBhbnkgfSB7XHJcbiAgICAgICAgbGV0IGxpbmVTdmc6IGFueSA9IHRoaXMubGluZUNoYXJ0LnNlbGVjdEFsbCgnLmtkeC1jaGFydC13cmFwcGVyJylcclxuICAgICAgICAgICAgLmRhdGEodGhpcy5fc2VyaWVzTGlzdCwgZnVuY3Rpb24oZCkgeyByZXR1cm4gZDsgfSk7XHJcbiAgICAgICAgLy8ga2V5IGZ1bmN0aW9uIGZvciBvYmplY3QgY29uc2lzdGVuY3kgc28gZDMgZG9lcyBub3QgcmVtb3ZlIGJhc2Ugb24gaW5kZXhcclxuXHJcbiAgICAgICAgbGluZVN2Zy5leGl0KCkucmVtb3ZlKCk7XHJcblxyXG4gICAgICAgIGxldCBzZXJpZXNDb250YWluZXI6IGFueTtcclxuXHJcbiAgICAgICAgaWYgKHRoaXMuY2hhcnRUeXBlWzFdICE9PSAnc3RhY2snICYmIHRoaXMuY2hhcnRUeXBlWzFdICE9PSAnMTAwJykge1xyXG4gICAgICAgICAgICBzZXJpZXNDb250YWluZXIgPSBsaW5lU3ZnLmVudGVyKClcclxuICAgICAgICAgICAgICAgIC5hcHBlbmQoJ2cnKVxyXG4gICAgICAgICAgICAgICAgLmF0dHIoJ2NsYXNzJywgKGQsIGkpID0+ICdrZHgtY2hhcnRzLXNlcmllcy1jb250YWluZXInICsgJyB5LScgKyB0aGlzLl9zZXJpZXNMaXN0W2ldKTtcclxuICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICBzZXJpZXNDb250YWluZXIgPSBsaW5lU3ZnLmVudGVyKCk7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICBsZXQgbGluZUNvbnRhaW5lcjogYW55ID0gc2VyaWVzQ29udGFpbmVyLmFwcGVuZCgnZycpXHJcbiAgICAgICAgICAgIC5hdHRyKCdjbGFzcycsIChkLCBpKSA9PiAna2R4LWNoYXJ0cy1saW5lLWNvbnRhaW5lcicgKyAnIHktJyArIHRoaXMuX3Nlcmllc0xpc3RbaV0pXHJcbiAgICAgICAgICAgIC5hdHRyKCdjbGlwLXBhdGgnLCAndXJsKCNrZC1jaGFydHMtY2xpcC1wYXRoLScgKyB0aGlzLmNvbmZpZy5pZCArICcpJyk7XHJcblxyXG4gICAgICAgIGxldCBkb3RDb250YWluZXI6IGFueSA9IHNlcmllc0NvbnRhaW5lci5hcHBlbmQoJ2cnKVxyXG4gICAgICAgICAgICAuYXR0cignY2xhc3MnLCAoZCwgaSkgPT4gJ2tkeC1jaGFydHMtZG90LWNvbnRhaW5lcicgKyAnIHktJyArIHRoaXMuX3Nlcmllc0xpc3RbaV0pXHJcbiAgICAgICAgICAgIC5hdHRyKCdpZCcsIChkLCBpKSA9PiAna2R4LWNoYXJ0cy1kb3QtY29udGFpbmVyJyArICdfeS0nICsgdGhpcy5fc2VyaWVzTGlzdFtpXS5yZXBsYWNlKC9cXHMvZywgJycpKTtcclxuXHJcbiAgICAgICAgcmV0dXJuIHsgbGluZUNvbnRhaW5lcjogbGluZUNvbnRhaW5lciwgZG90Q29udGFpbmVyOiBkb3RDb250YWluZXIgfTtcclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF9jcmVhdGVIb3ZlckRvdCgpOiB2b2lkIHtcclxuICAgICAgICBkMy5zZWxlY3QoJyMnICsgdGhpcy5jb25maWcuaWQgKyAnLmtkeC1jaGFydHMgLmtkeC1jaGFydHMtaG92ZXItZG90JykucmVtb3ZlKCk7XHJcblxyXG4gICAgICAgIHRoaXMuZ3JhcGhcclxuICAgICAgICAgICAgLmFwcGVuZCgncGF0aCcpXHJcbiAgICAgICAgICAgIC5hdHRyKCdjbGFzcycsICdrZHgtY2hhcnRzLWhvdmVyLWRvdCcpXHJcbiAgICAgICAgICAgIC5hdHRyKCdkJywgdGhpcy5faG92ZXJCYWNrZ3JvdW5kKVxyXG4gICAgICAgICAgICAuYXR0cigndHJhbnNmb3JtJywgc3VwZXIudHJhbnNmb3JtUG9zaXRpb24odGhpcy5fZGVmYXVsdERvdFBvcy54LCB0aGlzLl9kZWZhdWx0RG90UG9zLnksIHRydWUpKTtcclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF9kcmF3Q2hhcnQoX2RhdGE6IEFycmF5PElEM0RhdGFEYXRhPik6IHZvaWQge1xyXG4gICAgICAgIC8vIHN1cGVyLnJlbW92ZUNoYXJ0KCk7XHJcbiAgICAgICAgLy8gdGhpcy5fc2V0QXhpc0RvbWFpbigpO1xyXG5cclxuICAgICAgICBsZXQgc2VyaWVzQ29udGFpbmVyOiBhbnkgPSB0aGlzLl9jcmVhdGVTZXJpZXNDb250YWluZXIoKTtcclxuXHJcbiAgICAgICAgdGhpcy5fZHJhd1BhdGgoX2RhdGEsIHNlcmllc0NvbnRhaW5lci5saW5lQ29udGFpbmVyKTtcclxuXHJcbiAgICAgICAgdGhpcy5fYWRkRG90KF9kYXRhLCBzZXJpZXNDb250YWluZXIuZG90Q29udGFpbmVyKTtcclxuXHJcbiAgICAgICAgZm9yIChsZXQgeEluZGV4OiBudW1iZXIgPSAwOyB4SW5kZXggPCBfZGF0YS5sZW5ndGg7IHhJbmRleCsrKSB7XHJcbiAgICAgICAgICAgIHRoaXMuX3NldExhYmVsQW5pbWF0aW9uKHhJbmRleCwgX2RhdGFbeEluZGV4XSk7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIC8vIExpbmUgJiBBcmVhXHJcbiAgICBwcml2YXRlIF9kcmF3UGF0aChfY2hhcnREYXRhOiBBcnJheTxJRDNEYXRhRGF0YT4sIF9saW5lU3ZnOiBhbnkpOiB2b2lkIHtcclxuXHJcbiAgICAgICAgbGV0IGRhdGE6IEFycmF5PElEM0RhdGFEYXRhPiB8IEFycmF5PEFycmF5PElEYXRhVmFsdWU+PiA9IF9jaGFydERhdGE7XHJcblxyXG4gICAgICAgIGlmICh0aGlzLmNoYXJ0VHlwZVsxXSA9PT0gJ3N0YWNrJykgZGF0YSA9IHRoaXMuX2RhdGFNYXNzYWdlKF9jaGFydERhdGEpO1xyXG5cclxuICAgICAgICBpZiAodGhpcy5jaGFydFR5cGVbMF0gIT09ICdkb3QnKSB7XHJcblxyXG4gICAgICAgICAgICBpZiAodGhpcy5jaGFydFR5cGVbMF0gPT09ICdhcmVhJykge1xyXG4gICAgICAgICAgICAgICAgX2xpbmVTdmcuYXBwZW5kKCdwYXRoJylcclxuICAgICAgICAgICAgICAgICAgICAuYXR0cignZCcsIChkLCBpKSA9PiB0aGlzLl9zZXRQYXRoVmFsdWUoaSwgZGF0YSkpXHJcbiAgICAgICAgICAgICAgICAgICAgLmF0dHIoJ2NsYXNzJywgKGQsIGkpID0+ICdrZHgtY2hhcnRzLWxpbmUtYXJlYSB5LScgKyBkKVxyXG4gICAgICAgICAgICAgICAgICAgIC5hdHRyKCdmaWxsJywgKGQsIGkpID0+IHRoaXMubGVnZW5kRGF0YVtkXS5jb2xvcilcclxuICAgICAgICAgICAgICAgICAgICAuYXR0cignZmlsbC1vcGFjaXR5JywgMC43NSk7XHJcbiAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgIF9saW5lU3ZnLmFwcGVuZCgncGF0aCcpXHJcbiAgICAgICAgICAgICAgICAuYXR0cignZCcsIChkLCBpKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKHRoaXMuY2hhcnRUeXBlWzBdID09PSAnYXJlYScpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIHRoaXMuX3NldFBhdGhWYWx1ZShpLCBkYXRhLCB0cnVlKTtcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIHRoaXMuX3NldFBhdGhWYWx1ZShpLCBkYXRhKTtcclxuICAgICAgICAgICAgICAgIH0pXHJcbiAgICAgICAgICAgICAgICAuYXR0cignY2xhc3MnLCAoZCwgaSkgPT4gJ2tkeC1jaGFydHMtbGluZS1wYXRoIHktJyArIGQpXHJcbiAgICAgICAgICAgICAgICAuYXR0cignc3Ryb2tlJywgKGQsIGkpID0+IHRoaXMubGVnZW5kRGF0YVtkXS5jb2xvcilcclxuICAgICAgICAgICAgICAgIC5hdHRyKCdzdHJva2UtZGFzaGFycmF5JywgKGQsIGkpID0+IHRoaXMuX2xpbmVTdHlsZVt0aGlzLmxlZ2VuZERhdGFbZF0ubGluZVN0eWxlXSlcclxuICAgICAgICAgICAgICAgIC5zdHlsZSgnZmlsbCcsICdub25lJyk7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIC8qKlxyXG4gICAgICogW3JldHVybiBwYXRoIGRhdGEgdmFsdWUuIGRlcGVuZHMgb24gY2hhcnQgdHlwZSwgdGhpcyBmdW5jdGlvbiB3aWxsIHJldHVybiBsaW5lIG9yIGFyZWEgcGF0aCBkYXRhXHJcbiAgICAgKlxyXG4gICAgICogZm9yIF9jaGFydERhdGEsIHdlIG5lZWQgdW5pcXVlIGRhdGEgdHlwZSB0byByZXR1cm4gYmVjYXVzZSB3ZSBhcmUgZG9pbmcgYSBkaWZmZXJlbnQgd2F5IG9mIHN0YWNrIGFyZWEuXHJcbiAgICAgKiBuYXR1cmFsIHdheSBvZiBsaW5lIGNoYXJ0IGlzIDEgbGluZSwgMSBzZXJpZXMuXHJcbiAgICAgKiB3aGF0IHdlIGFyZSBkb2luZyBpcyBjdXQgdGhlIGxpbmUvc3BsaXQgdGhlIHN0YWNrIGFyZWEgaW50byAyIHRvIGNhdGVyIGZvciBudWxsIHZhbHVlLlxyXG4gICAgICogdGhlIGRhdGEgc3RydWN0dXJlIHRoYXQgd2UgaGF2ZSBjb3VwbGVkIHN0cmljdGx5IHRvIDEgeCBheGlzL2NhdGVnb3J5IG1hdGNoIHdpdGggMSB5IGRhdGEgdmFsdWUuXHJcbiAgICAgKiBmb3Igc3BsaXR0aW5nIG9mIHN0YWNrIGFyZWEsIHdlIHdpbGwgbmVlZCAxIHggY2F0ZWdvcnkgbWF0Y2ggd2l0aCAyIHkgZGF0YSB2YWx1ZS5cclxuICAgICAqXHJcbiAgICAgKiBdXHJcbiAgICAgKiBwYXJhbSAge251bWJlcn0gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgX3lJbmRleCAgICAgICAgICBbc2VyaWVzIGluZGV4IGFzIGxpbmUgaXMgZHJhd24gcGVyIHNlcmllc11cclxuICAgICAqIHBhcmFtICB7QXJyYXk8SUQzRGF0YURhdGE+IHwgQXJyYXk8QXJyYXk8SURhdGFWYWx1ZT4+fSBfY2hhcnREYXRhICAgICAgIFtlaXRoZXIgbGluZSBkYXRhIG9yIGFyZWEgZGF0YV1cclxuICAgICAqIHBhcmFtICB7Ym9vbGVhbn0gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBfYnlQYXNzQXJlYUNoZWNrIFtza2lwIGNoYXJ0IHR5cGUgY2hlY2sgYW5kIGRyYXcgbGluZS4gdXNlZnVsIGZvciBhcmVhIHRvIGRyYXcgYXJlYSBhbmQgbGluZV1cclxuICAgICAqIHJldHVybiB7c3RyaW5nfSAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFtyZXR1cm4gcGF0aCBkYXRhIHZhbHVlXVxyXG4gICAgICovXHJcbiAgICBwcml2YXRlIF9zZXRQYXRoVmFsdWUoX3lJbmRleDogbnVtYmVyLCBfY2hhcnREYXRhOiBBcnJheTxJRDNEYXRhRGF0YT4gfCBBcnJheTxBcnJheTxJRGF0YVZhbHVlPj4sIF9ieVBhc3NBcmVhQ2hlY2s/OiBib29sZWFuKTogc3RyaW5nIHtcclxuICAgICAgICBfYnlQYXNzQXJlYUNoZWNrID0gX2J5UGFzc0FyZWFDaGVjayB8fCBmYWxzZTtcclxuXHJcbiAgICAgICAgbGV0IGNoYXJ0VmFsdWU6IElEYXRhVmFsdWUgPSB7IHg6IG51bGwsIHk6IG51bGwsIHZhbGlkOiBmYWxzZSB9LFxyXG4gICAgICAgICAgICBjdXJ2ZVNoYXBlOiBhbnkgPSAodGhpcy5jaGFydFR5cGVbMF0gPT09ICdzcGxpbmUnIHx8IHRoaXMuY2hhcnRUeXBlW3RoaXMuY2hhcnRUeXBlLmxlbmd0aCAtIDJdID09PSAnc3BsaW5lJykgPyBkMy5jdXJ2ZUNhcmRpbmFsIDogZDMuY3VydmVMaW5lYXIsXHJcbiAgICAgICAgICAgIGNoYXJ0OiBhbnkgPSAodGhpcy5jaGFydFR5cGVbMF0gIT09ICdhcmVhJyB8fCBfYnlQYXNzQXJlYUNoZWNrKSA/IGQzLmxpbmUoKSA6IGQzLmFyZWEoKSxcclxuICAgICAgICAgICAgZGF0YTogQXJyYXk8SUQzRGF0YURhdGE+IHwgQXJyYXk8SURhdGFWYWx1ZT47XHJcblxyXG4gICAgICAgIGRhdGEgPSAodGhpcy5faXNVc2luZ0NoYXJ0RGF0YShfY2hhcnREYXRhKSkgPyBfY2hhcnREYXRhIDogX2NoYXJ0RGF0YVtfeUluZGV4XTtcclxuXHJcbiAgICAgICAgbGV0IHZhbHVlTGluZTogRnVuY3Rpb24gPSBjaGFydC5jdXJ2ZShjdXJ2ZVNoYXBlKTtcclxuXHJcbiAgICAgICAgY2hhcnQuZGVmaW5lZCgoaXRlbTogSUQzRGF0YURhdGEgfCBJRGF0YVZhbHVlLCB4SW5kZXg6IG51bWJlcikgPT4ge1xyXG4gICAgICAgICAgICBjaGFydFZhbHVlID0gdGhpcy5fdmFsaWRhdGVDaGFydFZhbHVlKGRhdGFbeEluZGV4XSwgX3lJbmRleCk7XHJcbiAgICAgICAgICAgIHJldHVybiBjaGFydFZhbHVlLnZhbGlkO1xyXG4gICAgICAgIH0pO1xyXG5cclxuICAgICAgICBjaGFydC54KCgpID0+IHRoaXMucmFuZ2VMaXN0W2NoYXJ0VmFsdWUueC52YWx1ZV0pO1xyXG5cclxuICAgICAgICBpZiAodGhpcy5jaGFydFR5cGVbMF0gIT09ICdhcmVhJyB8fCBfYnlQYXNzQXJlYUNoZWNrKSB7XHJcbiAgICAgICAgICAgIGNoYXJ0LnkoKCkgPT4gdGhpcy55KGNoYXJ0VmFsdWUueSkpO1xyXG4gICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgIGNoYXJ0LnkxKCgpID0+IHRoaXMueShjaGFydFZhbHVlLnkpKVxyXG4gICAgICAgICAgICAgICAgLnkwKChpdGVtKSA9PiAodGhpcy5jaGFydFR5cGVbMV0gPT09ICcxMDAnIHx8IHRoaXMuY2hhcnRUeXBlWzFdID09PSAnc3RhY2snKSA/IHRoaXMueShjaGFydFZhbHVlLnkwKSA6IHRoaXMueSgwKSk7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICByZXR1cm4gdmFsdWVMaW5lKGRhdGEpO1xyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX2lzVXNpbmdDaGFydERhdGEoX2FycmF5T2JqZWN0OiBhbnkpOiBfYXJyYXlPYmplY3QgaXMgQXJyYXk8SUQzRGF0YURhdGE+IHtcclxuICAgICAgICByZXR1cm4gdGhpcy5jaGFydFR5cGVbMV0gIT09ICdzdGFjayc7XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfaXNJRGF0YVZhbHVlKF9vYmplY3Q6IElEM0RhdGFEYXRhIHwgSURhdGFWYWx1ZSk6IF9vYmplY3QgaXMgSURhdGFWYWx1ZSB7XHJcbiAgICAgICAgcmV0dXJuIHRoaXMuY2hhcnRUeXBlWzFdID09PSAnc3RhY2snO1xyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX3ZhbGlkYXRlQ2hhcnRWYWx1ZShfaXRlbTogSUQzRGF0YURhdGEgfCBJRGF0YVZhbHVlLCBfeUluZGV4OiBudW1iZXIpOiBJRGF0YVZhbHVlIHtcclxuICAgICAgICBpZiAodGhpcy5faXNJRGF0YVZhbHVlKF9pdGVtKSkgeyAvLyBzdGFja1xyXG4gICAgICAgICAgICByZXR1cm4gX2l0ZW07XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICBsZXQgeVZhbHVlOiBudW1iZXIgPSBfaXRlbS55W195SW5kZXhdLnN1bTtcclxuICAgICAgICBsZXQgdmFsaWQ6IGJvb2xlYW4gPSB0cnVlO1xyXG4gICAgICAgIGxldCB5MDogbnVtYmVyID0gMDtcclxuXHJcbiAgICAgICAgaWYgKHRoaXMuY2hhcnRUeXBlWzFdID09PSAnMTAwJykge1xyXG4gICAgICAgICAgICB5MCA9IF9pdGVtLnlbX3lJbmRleF0uc3VtIC0gX2l0ZW0ueVtfeUluZGV4XS5yZW5kZXJWYWw7XHJcbiAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgdmFsaWQgPSBzdXBlci5pc0RhdGFFeGlzdChfaXRlbSwgX3lJbmRleCk7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIHJldHVybiB7IHg6IF9pdGVtLngsIHk6IHlWYWx1ZSwgeTA6IHkwLCB2YWxpZDogdmFsaWQgfTtcclxuICAgIH1cclxuXHJcbiAgICAvLyBEb3RcclxuICAgIHByaXZhdGUgX2FkZERvdChfZGF0YTogQXJyYXk8SUQzRGF0YURhdGE+LCBfZG90Q29udGFpbmVyOiBhbnkpOiB2b2lkIHtcclxuICAgICAgICBmb3IgKGxldCB4SW5kZXg6IG51bWJlciA9IDA7IHhJbmRleCA8IF9kYXRhLmxlbmd0aDsgeEluZGV4KyspIHtcclxuICAgICAgICAgICAgbGV0IGl0ZW06IElEM0RhdGFEYXRhID0gX2RhdGFbeEluZGV4XTtcclxuXHJcbiAgICAgICAgICAgIGlmICh0aGlzLmNoYXJ0VHlwZVsxXSAhPT0gJ3N0YWNrJyAmJiAhQXJyYXkuaXNBcnJheShpdGVtLnkpIHx8XHJcbiAgICAgICAgICAgICAgICAoQXJyYXkuaXNBcnJheShpdGVtLnkpICYmIGl0ZW0ueS5sZW5ndGggPD0gMCkpIGNvbnRpbnVlO1xyXG5cclxuICAgICAgICAgICAgbGV0IGRhdGFQb2ludDogYW55ID0gX2RvdENvbnRhaW5lci5hcHBlbmQoJ3BhdGgnKVxyXG4gICAgICAgICAgICAgICAgLmF0dHIoJ2NsYXNzJywgKGQsIGkpID0+IHRoaXMuX3BvcHVsYXRlRG90RGF0YShpdGVtLCBpLCB4SW5kZXgpKVxyXG4gICAgICAgICAgICAgICAgLmF0dHIoJ2QnLCAoZCwgaSkgPT4gdGhpcy5fZ2V0RG90SWQoeEluZGV4LCBpLCBpdGVtLCAnc2hhcGUnKSlcclxuICAgICAgICAgICAgICAgIC5hdHRyKCdmaWxsJywgKGQsIGkpID0+IHRoaXMuX2dldERvdElkKHhJbmRleCwgaSwgaXRlbSwgJ2NvbG91cicpKVxyXG4gICAgICAgICAgICAgICAgLmF0dHIoJ3N0cm9rZScsIChkLCBpKSA9PiB0aGlzLl9nZXREb3RJZCh4SW5kZXgsIGksIGl0ZW0sICdib3JkZXJDb2xvcicpKVxyXG4gICAgICAgICAgICAgICAgLmF0dHIoJ3N0cm9rZS13aWR0aCcsIChkLCBpKSA9PiB0aGlzLl9nZXREb3RJZCh4SW5kZXgsIGksIGl0ZW0sICdib3JkZXJXaWR0aCcpKVxyXG4gICAgICAgICAgICAgICAgLmF0dHIoJ3RyYW5zZm9ybScsIChkLCBpKSA9PiB0aGlzLl9nZXREb3RJZCh4SW5kZXgsIGksIGl0ZW0sICdwb3NpdGlvbicpKVxyXG4gICAgICAgICAgICAgICAgLnN0eWxlKCdkaXNwbGF5JywgJ2Jsb2NrJyk7XHJcblxyXG4gICAgICAgICAgICBsZXQgZG90SG92ZXJGdW5jOiBGdW5jdGlvbiA9IHRoaXMudHJpZ2dlckhvdmVyRnVuY3Rpb24odGhpcyk7XHJcblxyXG4gICAgICAgICAgICBzdXBlci5faW5pdE1vdXNlRXZlbnRzKGRhdGFQb2ludCwgeyBkYXRhOiBpdGVtLCB4SW5kZXg6IHhJbmRleCwgZG90SG92ZXI6IGRvdEhvdmVyRnVuYyB9KTtcclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfZ2V0RG90SWQoX3hJbmRleDogbnVtYmVyLCBfeUluZGV4OiBudW1iZXIsIF9kYXRhOiBJRDNEYXRhRGF0YSwgX2VsZW1lbnQ6ICdzaGFwZScgfCAnY29sb3VyJyB8ICdib3JkZXJDb2xvcicgfCAnYm9yZGVyV2lkdGgnIHwgJ3Bvc2l0aW9uJykge1xyXG4gICAgICAgIGlmICghKHN1cGVyLmlzRGF0YUV4aXN0KF9kYXRhLCBfeUluZGV4KSAmJiB0aGlzLmxlZ2VuZERhdGFbX2RhdGEueVtfeUluZGV4XS5pZF0uZG90RW5hYmxlZCkpIHJldHVybiAnJztcclxuICAgICAgICBsZXQgaWQgPSBzdXBlci5nZXREb3RJZChfeEluZGV4LCBfZGF0YS55W195SW5kZXhdLmlkKS5yZXBsYWNlKC9cXHMvZywgJycpO1xyXG4gICAgICAgIGxldCB2YWx1ZTogc3RyaW5nIHwgbnVtYmVyID0gJyc7XHJcbiAgICAgICAgaWYgKF9lbGVtZW50ID09PSAncG9zaXRpb24nKSB7XHJcbiAgICAgICAgICAgIGxldCB4OiBudW1iZXIgPSAodGhpcy5fZG90RGF0YVtpZF0gJiYgdHlwZW9mIHRoaXMuX2RvdERhdGFbaWRdLnggIT09ICd1bmRlZmluZWQnKSA/IHRoaXMuX2RvdERhdGFbaWRdLnggOiB0aGlzLl9kZWZhdWx0RG90UG9zLng7XHJcbiAgICAgICAgICAgIGxldCB5OiBudW1iZXIgPSAodGhpcy5fZG90RGF0YVtpZF0gJiYgdHlwZW9mIHRoaXMuX2RvdERhdGFbaWRdLnkgIT09ICd1bmRlZmluZWQnKSA/IHRoaXMuX2RvdERhdGFbaWRdLnkgOiB0aGlzLl9kZWZhdWx0RG90UG9zLnk7XHJcbiAgICAgICAgICAgIHZhbHVlID0gc3VwZXIudHJhbnNmb3JtUG9zaXRpb24oeCwgeSwgdHJ1ZSk7XHJcbiAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgdmFsdWUgPSAodGhpcy5fZG90RGF0YVtpZF0gJiYgdGhpcy5fZG90RGF0YVtpZF1bX2VsZW1lbnRdKSA/IHRoaXMuX2RvdERhdGFbaWRdW19lbGVtZW50XS50b1N0cmluZygpIDogJyc7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIHJldHVybiB2YWx1ZTtcclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF9wb3B1bGF0ZURvdERhdGEoX2RhdGE6IElEM0RhdGFEYXRhLCBfeUluZGV4OiBudW1iZXIsIF94SW5kZXg6IG51bWJlcik6IHN0cmluZyB7XHJcbiAgICAgICAgaWYgKCFzdXBlci5pc0RhdGFFeGlzdChfZGF0YSwgX3lJbmRleCkpIHJldHVybiAnJztcclxuICAgICAgICBsZXQgaWQ6IHN0cmluZyA9IHN1cGVyLmdldERvdElkKF94SW5kZXgsIF9kYXRhLnlbX3lJbmRleF0uaWQpLnJlcGxhY2UoL1xccy9nLCAnJyk7XHJcbiAgICAgICAgbGV0IGNvbG91cjogc3RyaW5nID0gX2RhdGEueVtfeUluZGV4XS5jb2xvcjtcclxuICAgICAgICBsZXQgc2hhcGU6IHN0cmluZyA9IF9kYXRhLnlbX3lJbmRleF0uc2hhcGU7XHJcbiAgICAgICAgbGV0IHBvc2l0aW9uOiBJUG9zaXRpb24gPSB0aGlzLl9nZXREb3RQb3NpdGlvbihfZGF0YS54LnZhbHVlLCBfeEluZGV4LCBfZGF0YS55W195SW5kZXhdLnN1bSk7XHJcbiAgICAgICAgbGV0IGJvcmRlckNvbG9yOiBzdHJpbmcgPSB0aGlzLmxlZ2VuZERhdGFbX2RhdGEueVtfeUluZGV4XS5pZF0uZG90Qm9yZGVyQ29sb3I7XHJcbiAgICAgICAgbGV0IGJvcmRlcldpZHRoOiBudW1iZXIgPSB0aGlzLmxlZ2VuZERhdGFbX2RhdGEueVtfeUluZGV4XS5pZF0uZG90Qm9yZGVyV2lkdGg7XHJcblxyXG4gICAgICAgIHRoaXMuX3NldExhYmVsKF9kYXRhLnlbX3lJbmRleF0sIF94SW5kZXgsIHBvc2l0aW9uLngsIGJvcmRlcldpZHRoKTtcclxuXHJcbiAgICAgICAgaWYgKF9kYXRhLnlbX3lJbmRleF0udmFsdWUgPT09IHRoaXMuZG9tYWluTWluIHx8IF9kYXRhLnlbX3lJbmRleF0udmFsdWUgPT09IHRoaXMuZG9tYWluTWF4KSB7XHJcbiAgICAgICAgICAgIGxldCBjdXJyZW50RG90U2l6ZSA9IDEyICsgYm9yZGVyV2lkdGg7XHJcblxyXG4gICAgICAgICAgICBpZiAodGhpcy5fYmlnZ2VzdERvdFNpemUgPCBjdXJyZW50RG90U2l6ZSkgdGhpcy5fYmlnZ2VzdERvdFNpemUgPSBjdXJyZW50RG90U2l6ZTtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIGlmICgodGhpcy5jb25maWcueUF4aXMubWluVmFsdWUgIT09IG51bGwgJiZcclxuICAgICAgICAgICAgX2RhdGEueVtfeUluZGV4XS52YWx1ZSA8IHRoaXMuY29uZmlnLnlBeGlzLm1pblZhbHVlKSB8fFxyXG4gICAgICAgICAgICAodGhpcy5jb25maWcueUF4aXMubWF4VmFsdWUgIT09IG51bGwgJiZcclxuICAgICAgICAgICAgX2RhdGEueVtfeUluZGV4XS52YWx1ZSA+IHRoaXMuY29uZmlnLnlBeGlzLm1heFZhbHVlKSkge1xyXG4gICAgICAgICAgICBkZWxldGUgdGhpcy5fZG90RGF0YVtpZF07XHJcbiAgICAgICAgICAgIHJldHVybiBpZDtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIHRoaXMuX2RvdERhdGFbaWRdID0ge1xyXG4gICAgICAgICAgICBjb2xvdXI6IGNvbG91cixcclxuICAgICAgICAgICAgc2hhcGU6IHNoYXBlLFxyXG4gICAgICAgICAgICB4OiBwb3NpdGlvbi54LFxyXG4gICAgICAgICAgICB5OiBwb3NpdGlvbi55LFxyXG4gICAgICAgICAgICBib3JkZXJDb2xvcjogYm9yZGVyQ29sb3IsXHJcbiAgICAgICAgICAgIGJvcmRlcldpZHRoOiBib3JkZXJXaWR0aFxyXG4gICAgICAgIH07XHJcblxyXG4gICAgICAgIHJldHVybiBpZDtcclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF9nZXREb3RQb3NpdGlvbihfeFZhbHVlOiBzdHJpbmcsIF94SW5kZXg6IG51bWJlciwgX3lWYWx1ZTogbnVtYmVyKTogSVBvc2l0aW9uIHtcclxuICAgICAgICBsZXQgeFBvczogbnVtYmVyID0gMDtcclxuICAgICAgICBsZXQgeVBvczogbnVtYmVyID0gMDtcclxuXHJcbiAgICAgICAgeFBvcyA9ICh0aGlzLnJhbmdlTGlzdFtfeFZhbHVlXSAtIDQpO1xyXG4gICAgICAgIHlQb3MgPSAodGhpcy55KF95VmFsdWUpIC0gNCk7XHJcblxyXG4gICAgICAgIHJldHVybiB7IHg6IHhQb3MsIHk6IHlQb3MgfTtcclxuICAgIH1cclxuXHJcbiAgICAvLyBob3ZlciBmdW5jdGlvblxyXG4gICAgcHJpdmF0ZSB0cmlnZ2VySG92ZXJGdW5jdGlvbihfa2RMaW5lQ2hhcnQ6IEtkTGluZUNoYXJ0KTogRnVuY3Rpb24ge1xyXG4gICAgICAgIHJldHVybiBmdW5jdGlvbihkb3RJZDogc3RyaW5nLCBpc0hvdmVyaW5nPzogYm9vbGVhbik6IHZvaWQge1xyXG4gICAgICAgICAgICBpc0hvdmVyaW5nID0gaXNIb3ZlcmluZyB8fCBmYWxzZTtcclxuICAgICAgICAgICAgX2tkTGluZUNoYXJ0LmRvdEhvdmVyKF9rZExpbmVDaGFydCwgZG90SWQsIGlzSG92ZXJpbmcpO1xyXG4gICAgICAgIH07XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBkb3RIb3Zlcihfa2RMaW5lQ2hhcnQ6IEtkTGluZUNoYXJ0LCBfZG90SWQ6IHN0cmluZywgX2lzSG92ZXJpbmc6IGJvb2xlYW4pOiB2b2lkIHtcclxuICAgICAgICBfZG90SWQgPSBfZG90SWQucmVwbGFjZSgvXFxzL2csICcnKTtcclxuICAgICAgICBpZighdGhpcy5fZG90RGF0YS5oYXNPd25Qcm9wZXJ0eShfZG90SWQpIHx8ICF0aGlzLl9kb3REYXRhW19kb3RJZF0uc2hhcGUpIHJldHVybjtcclxuICAgICAgICBsZXQgc2hhcGU6IHN0cmluZyA9IChfaXNIb3ZlcmluZykgPyB0aGlzLl9zaGFwZXNbdGhpcy5fZG90RGF0YVtfZG90SWRdLnNoYXBlXSA6IHRoaXMuX2RvdERhdGFbX2RvdElkXS5zaGFwZTtcclxuICAgICAgICBsZXQgcG9zaXRpb246IElQb3NpdGlvbiA9IHRoaXMuX2RvdEhvdmVyUG9zaXRpb24oX2RvdElkLCBfaXNIb3ZlcmluZywgZmFsc2UpO1xyXG4gICAgICAgIGxldCBib3JkZXJXaWR0aDogbnVtYmVyID0gdGhpcy5fZG90RGF0YVtfZG90SWRdLmJvcmRlcldpZHRoO1xyXG5cclxuICAgICAgICBpZiAoYm9yZGVyV2lkdGggPT09IDAgJiYgX2lzSG92ZXJpbmcpIGJvcmRlcldpZHRoID0gMTtcclxuXHJcbiAgICAgICAgdGhpcy5fc2V0SG92ZXJCYWNrZ3JvdW5kKF9kb3RJZCwgX2lzSG92ZXJpbmcpO1xyXG4gICAgICAgIGQzLnNlbGVjdCgnIycgKyB0aGlzLmNvbmZpZy5pZCArICcua2R4LWNoYXJ0cyAuJyArIF9kb3RJZClcclxuICAgICAgICAgICAgLmF0dHIoJ2QnLCBzaGFwZSlcclxuICAgICAgICAgICAgLmF0dHIoJ3RyYW5zZm9ybScsIHN1cGVyLnRyYW5zZm9ybVBvc2l0aW9uKHBvc2l0aW9uLngsIHBvc2l0aW9uLnksIHRydWUpKVxyXG4gICAgICAgICAgICAuYXR0cignc3Ryb2tlLXdpZHRoJywgYm9yZGVyV2lkdGgpO1xyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX3NldEhvdmVyQmFja2dyb3VuZChfZG90SWQ6IHN0cmluZywgX2lzSG92ZXJpbmc6IGJvb2xlYW4pOiB2b2lkIHtcclxuICAgICAgICBsZXQgY29sb3VyOiBzdHJpbmcgPSB0aGlzLl9kb3REYXRhW19kb3RJZF0uY29sb3VyO1xyXG5cclxuICAgICAgICBsZXQgcG9zaXRpb246IElQb3NpdGlvbiA9IF9pc0hvdmVyaW5nID8gdGhpcy5fZG90SG92ZXJQb3NpdGlvbihfZG90SWQsIF9pc0hvdmVyaW5nLCB0cnVlKSA6IHRoaXMuX2RlZmF1bHREb3RQb3M7XHJcblxyXG4gICAgICAgIGQzLnNlbGVjdCgnIycgKyB0aGlzLmNvbmZpZy5pZCArICcua2R4LWNoYXJ0cyAua2R4LWNoYXJ0cy1ob3Zlci1kb3QnKVxyXG4gICAgICAgICAgICAvLyAuc3R5bGUoJ2Rpc3BsYXknLCBkaXNwbGF5KVxyXG4gICAgICAgICAgICAuYXR0cignZmlsbCcsIGNvbG91cilcclxuICAgICAgICAgICAgLmF0dHIoJ3RyYW5zZm9ybScsIHRoaXMudHJhbnNmb3JtUG9zaXRpb24ocG9zaXRpb24ueCwgcG9zaXRpb24ueSwgdHJ1ZSkpXHJcbiAgICAgICAgICAgIC5hdHRyKCdzdHJva2Utd2lkdGgnLCAxKVxyXG4gICAgICAgICAgICAuYXR0cignc3Ryb2tlJywgY29sb3VyKTtcclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF9kb3RIb3ZlclBvc2l0aW9uKF9kb3RJZDogc3RyaW5nLCBfaXNIb3ZlcmluZzogYm9vbGVhbiwgX2lzQmFja2dyb3VuZDogYm9vbGVhbik6IElQb3NpdGlvbiB7XHJcbiAgICAgICAgbGV0IHhQb3M6IG51bWJlciA9IHRoaXMuX2RvdERhdGFbX2RvdElkXS54O1xyXG4gICAgICAgIGxldCB5UG9zOiBudW1iZXIgPSB0aGlzLl9kb3REYXRhW19kb3RJZF0ueTtcclxuXHJcbiAgICAgICAgaWYgKCFfaXNIb3ZlcmluZykgcmV0dXJuIHsgeDogeFBvcywgeTogeVBvcyB9O1xyXG5cclxuICAgICAgICBpZiAoX2lzQmFja2dyb3VuZCkge1xyXG4gICAgICAgICAgICB4UG9zIC09IDY7XHJcbiAgICAgICAgICAgIHlQb3MgLT0gNjtcclxuICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICB4UG9zIC09IDI7XHJcbiAgICAgICAgICAgIHlQb3MgLT0gMjtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIHJldHVybiB7IHg6IHhQb3MsIHk6IHlQb3MgfTtcclxuICAgIH1cclxuXHJcbiAgICAvLyBsYWJlbFxyXG4gICAgcHJpdmF0ZSBfc2V0TGFiZWwoX3lEYXRhOiBJRDNZRGF0YSwgX3hJbmRleDogbnVtYmVyLCBfeFBvc2l0aW9uOiBudW1iZXIsIF9kb3RXaWR0aDogbnVtYmVyKTogdm9pZCB7XHJcbiAgICAgICAgaWYgKCF0aGlzLmNvbmZpZy5jaGFydC5sYWJlbHMuZW5hYmxlZCkgcmV0dXJuO1xyXG5cclxuICAgICAgICBfeFBvc2l0aW9uIC09IF9kb3RXaWR0aCAvIDI7XHJcblxyXG4gICAgICAgIGxldCBsYWJlbDogYW55ID0gc3VwZXIuc2V0TGFiZWwoX3lEYXRhLCBfeEluZGV4LCBfeFBvc2l0aW9uLCB0aGlzLnkoX3lEYXRhLnN1bSkpO1xyXG4gICAgICAgIC8vIGxhYmVsLnN0eWxlKCdkaXNwbGF5JywgJ2ZsZXgnKTtcclxuXHJcbiAgICAgICAgbGV0IHNwYW5FbG06IGFueSA9IGxhYmVsLnNlbGVjdCgnLmtkeC1jaGFydHMtZGF0YS1sYWJlbC10ZXh0Jyk7XHJcblxyXG4gICAgICAgIGxldCBkYXRhTGFiZWxMZW5ndGg6IG51bWJlciA9IHRoaXMuX2dldExhYmVsVGV4dExlbmd0aChfeURhdGEpO1xyXG5cclxuICAgICAgICBsZXQgZG90U2l6ZSA9IDEwICsgX2RvdFdpZHRoOyAvLyBhZGQgMTBweCBmb3Igc3BhY2luZyBiZXR3ZWVuIGRvdCBhbmQgbGFiZWxcclxuICAgICAgICBzdXBlci5zZXRMYWJlbFRleHRQb3NpdGlvbihzcGFuRWxtLCB0aGlzLnkoX3lEYXRhLnN1bSksIHsgZG90U2l6ZTogZG90U2l6ZSwgbGFiZWxMZW5ndGg6IGRhdGFMYWJlbExlbmd0aCB9KTtcclxuXHJcbiAgICAgICAgLy8gc2hpZnQgdGV4dCB0byB0aGUgaG9yaXpvbnRhbGx5IGNlbnRlciB0byB0aGUgZG90XHJcbiAgICAgICAgLy8gaWYgKHRoaXMuX2NoYXJ0U3ZjLmlzRXhpc3QoX3lEYXRhKSAmJiBkYXRhTGFiZWxMZW5ndGggPiAxKSB7XHJcbiAgICAgICAgLy8gICAgIGxldCBzaGlmdFBvc2l0aW9uOiBudW1iZXIgPSB0aGlzLl9nZXRDZW50ZXJQb3NpdGlvbihkYXRhTGFiZWxMZW5ndGgsIHNwYW5FbG0pO1xyXG4gICAgICAgIC8vICAgICBzcGFuRWxtLnN0eWxlKCdsZWZ0Jywgc2hpZnRQb3NpdGlvbiArICdweCcpLnN0eWxlKCdkaXNwbGF5JywgJ25vbmUnKTtcclxuICAgICAgICAvLyB9XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfZ2V0TGFiZWxUZXh0TGVuZ3RoKF95RGF0YTogSUQzWURhdGEpOiBudW1iZXIge1xyXG4gICAgICAgIGxldCBkYXRhTGFiZWwgPSB0aGlzLmNvbmZpZy5jaGFydC5sYWJlbHMuZm9ybWF0LnJlcGxhY2UoJ3t2YWx1ZX0nLCB0aGlzLl9jaGFydFN2Yy5nZXREM0Zvcm1hdChfeURhdGEudmFsdWUpKTtcclxuXHJcbiAgICAgICAgcmV0dXJuIGRhdGFMYWJlbC50b1N0cmluZygpLmxlbmd0aDtcclxuICAgIH1cclxuXHJcbiAgICAvLyBwcml2YXRlIF9nZXRDZW50ZXJQb3NpdGlvbihfZGF0YUxhYmVsTGVuZ3RoOiBudW1iZXIsIF9zcGFuRWxtOiBhbnkpIHtcclxuXHJcbiAgICAvLyAgICAgbGV0IGxhYmVsRWxtOiBhbnkgPSBfc3BhbkVsbS5ub2RlKCkuZ2V0Qm91bmRpbmdDbGllbnRSZWN0KCk7XHJcblxyXG4gICAgLy8gICAgIGxldCBsYWJlbFdpZHRoOiBudW1iZXIgPSBsYWJlbEVsbS53aWR0aDtcclxuICAgIC8vICAgICBsZXQgbGFiZWxDZW50ZXI6IG51bWJlciA9IChsYWJlbFdpZHRoIC0gbGFiZWxXaWR0aCAvIF9kYXRhTGFiZWxMZW5ndGgpIC8gMjtcclxuICAgIC8vICAgICBsZXQgc2hpZnRQb3NpdGlvbjogbnVtYmVyID0gMCAtIGxhYmVsQ2VudGVyO1xyXG5cclxuICAgIC8vICAgICBpZiAoZG9jdW1lbnQuZGlyID09PSAncnRsJykgcmV0dXJuIGxhYmVsQ2VudGVyO1xyXG5cclxuICAgIC8vICAgICByZXR1cm4gc2hpZnRQb3NpdGlvbjtcclxuICAgIC8vIH1cclxuXHJcbiAgICAvLyBhbmltYXRpb25cclxuICAgIHByaXZhdGUgX3NldENoYXJ0QW5pbWF0aW9uKCk6IHZvaWQge1xyXG5cclxuICAgICAgICBsZXQgaGFsZkRvdDogbnVtYmVyID0gdGhpcy5fYmlnZ2VzdERvdFNpemUgLyAyO1xyXG4gICAgICAgIGxldCBvZmZzZXRTdGFydDogbnVtYmVyID0gMCAtIGhhbGZEb3Q7XHJcblxyXG4gICAgICAgIGxldCBjbGlwOiBhbnkgPSB0aGlzLmxpbmVDaGFydC5hcHBlbmQoJ2NsaXBQYXRoJylcclxuICAgICAgICAgICAgLmF0dHIoJ2lkJywgJ2xpbmUtY2xpcCcgKyB0aGlzLmNvbmZpZy5pZCk7XHJcbiAgICAgICAgbGV0IGNsaXBSZWN0OiBhbnkgPSBjbGlwLmFwcGVuZCgncmVjdCcpXHJcbiAgICAgICAgICAgIC5hdHRyKCdmaWxsJywgJ3doaXRlJylcclxuICAgICAgICAgICAgLmF0dHIoJ3gnLCBvZmZzZXRTdGFydClcclxuICAgICAgICAgICAgLmF0dHIoJ3knLCBvZmZzZXRTdGFydClcclxuICAgICAgICAgICAgLmF0dHIoJ2ZpbGwnLCAnbm9uZScpXHJcbiAgICAgICAgICAgIC5hdHRyKCd3aWR0aCcsIDApXHJcbiAgICAgICAgICAgIC5hdHRyKCdoZWlnaHQnLCB0aGlzLmhlaWdodCArIHRoaXMuX2JpZ2dlc3REb3RTaXplKTtcclxuXHJcbiAgICAgICAgdGhpcy5saW5lQ2hhcnQuYXR0cignY2xpcC1wYXRoJywgJ3VybCgjbGluZS1jbGlwJyArIHRoaXMuY29uZmlnLmlkICsgJyknKTtcclxuXHJcbiAgICAgICAgbGV0IHRyYW5zaXRpb25GdW5jOiBGdW5jdGlvbiA9IGQzLnRyYW5zaXRpb24oKVxyXG4gICAgICAgICAgICAuZHVyYXRpb24odGhpcy5sZW5ndGhPZlRyYW5zaXRpb24pXHJcbiAgICAgICAgICAgIC5lYXNlKGQzLmVhc2VMaW5lYXIpO1xyXG5cclxuICAgICAgICBjbGlwUmVjdC50cmFuc2l0aW9uKHRyYW5zaXRpb25GdW5jKVxyXG4gICAgICAgICAgICAuYXR0cignd2lkdGgnLCB0aGlzLndpZHRoICsgdGhpcy5fYmlnZ2VzdERvdFNpemUpO1xyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX3NldExhYmVsQW5pbWF0aW9uKF94SW5kZXg6IG51bWJlciwgX2RhdGE6IElEM0RhdGFEYXRhKTogdm9pZCB7XHJcbiAgICAgICAgaWYgKHRoaXMuY29uZmlnLmNoYXJ0ICE9PSB1bmRlZmluZWQgJiYgdGhpcy5jb25maWcuY2hhcnQubGFiZWxzICE9PSB1bmRlZmluZWQpIHtcclxuICAgICAgICAgICAgaWYgKCF0aGlzLmNvbmZpZy5jaGFydC5sYWJlbHMuZW5hYmxlZCkgcmV0dXJuO1xyXG4gICAgICAgICAgICBsZXQgbGFiZWxEZWxheTogbnVtYmVyID0gMS41O1xyXG4gICAgICAgICAgICBsZXQgYW5pbWF0aW9uRGVsYXk6IG51bWJlciA9IF94SW5kZXggKiB0aGlzLmxlbmd0aE9mVHJhbnNpdGlvbiAvIF9kYXRhLnkubGVuZ3RoICogbGFiZWxEZWxheTtcclxuICAgICAgICAgICAgbGV0IHRyYW5zaXRpb25UaW1lOiBudW1iZXIgPSB0aGlzLmNvbmZpZy5hbmltYXRpb24gPyB0aGlzLmxlbmd0aE9mVHJhbnNpdGlvbiA6IDA7XHJcbiAgICAgICAgICAgIGFuaW1hdGlvbkRlbGF5ID0gdGhpcy5jb25maWcuYW5pbWF0aW9uID8gYW5pbWF0aW9uRGVsYXkgOiAwO1xyXG5cclxuICAgICAgICAgICAgZDMuc2VsZWN0QWxsKCcjJyArIHRoaXMuY29uZmlnLmlkICsgJy5rZHgtY2hhcnRzIC5rZHgtY2hhcnRzLWRhdGEtbGFiZWwueC0nICsgX3hJbmRleClcclxuICAgICAgICAgICAgICAgIC50cmFuc2l0aW9uKCkgIC8vIFRyYW5zaXRpb24gZnJvbSBvbGQgdG8gbmV3XHJcbiAgICAgICAgICAgICAgICAuZHVyYXRpb24odHJhbnNpdGlvblRpbWUpICAvLyBMZW5ndGggb2YgYW5pbWF0aW9uXHJcbiAgICAgICAgICAgICAgICAuZGVsYXkoYW5pbWF0aW9uRGVsYXkpXHJcbiAgICAgICAgICAgICAgICAub24oJ3N0YXJ0JywgZnVuY3Rpb24oZCwgaSkgeyAgLy8gU3RhcnQgYW5pbWF0aW9uXHJcbiAgICAgICAgICAgICAgICAgICAgZDMuc2VsZWN0KHRoaXMpICAvLyAndGhpcycgbWVhbnMgdGhlIGN1cnJlbnQgZWxlbWVudFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAuc3R5bGUoJ3Zpc2liaWxpdHknLCAndmlzaWJsZScpO1xyXG4gICAgICAgICAgICAgICAgICAgIC8vIC5zdHlsZSgnZGlzcGxheScsICdibG9jaycpO1xyXG4gICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIC8vIFN0YWNrIEFyZWEgcmVjYWxjdWxhdGVcclxuXHJcbiAgICAvKipcclxuICAgICAqIGZvciBhcmVhIHN0YWNrIChub3QgdGhlIDEwMCUgc3RhY2suIDEwMCUgZGF0YSBtYXNzYWdlIGlzIHRoZSBzYW1lIGFzIGJhciB3aGljaFxyXG4gICAgICogdGhlIGRhdGEgbWFzc3NhZ2UgaXMgZG9uZSBpbiBrZCBjaGFydHMpLlxyXG4gICAgICpcclxuICAgICAqIHRoaXMgY2Fubm90IGJlIGRvbmUgdGhyb3VnaCBrZCBjaGFydCBkYXRhIG1hc3NhZ2UgYmVjYXVzZSB0aGUgZG90IHBvc2l0aW9uIGhhcyB0b1xyXG4gICAgICogYmUgb24gdGhlIGNvcnJlY3Qgc3VtIChzYW1lIGFzIGJhcikuIHdlIHdpbGwgdGFrZSBiYXIgYWZ0ZXIgbWFzc2FnZSB2YWx1ZSBmb3IgZG90XHJcbiAgICAgKiBhbmQgcmVtYXNzYWdlIGZvciBsaW5lIGFyZWEuXHJcbiAgICAgKlxyXG4gICAgICogdGhpcyBkYXRhIG1hc3NhZ2UgaXMgY2F0ZXJpbmcgdW5pcXVlIGxpbmUgYmVoYXZpb3VyIHdoZW4gaGFuZGxpbmcgbnVsbCB2YWx1ZS5cclxuICAgICAqXHJcbiAgICAgKiBsaW5lIGJlaGF2aW91ciBvbiBudWxsOiB3aGVuIGEgbnVsbCBhcHBlYXIsIHRoZSBsaW5lIGZvciBwcmV2aW91cyBhbmQgYWZ0ZXIgY3VycmVudFxyXG4gICAgICogeCBheGlzIHdpbGwgbm90IGJlIGRyYXduLiBjYXVzaW5nIHRoZSBwcmV2aW91cyBhbmQgYWZ0ZXIgeCBheGlzIHRvIGJlIGludGVwcmV0ZWQgYXMgMFxyXG4gICAgICpcclxuICAgICAqIGFzIHRoZSB3aG9sZSBhcmVhIG9mIHRoaXMgY3VycmVudCB4IGF4aXMgd2lsbCBiZSAwIGZvciBjdXJyZW50IHNlcmllcywgYW55IHNlcmllcyBhZnRlclxyXG4gICAgICogaGFzIHRvIGJlIGJyb3VnaHQgZG93bi5cclxuICAgICAqXHJcbiAgICAgKiB3ZSBuZWVkIHVuaXF1ZSBkYXRhIHR5cGUgdG8gcmV0dXJuIGJlY2F1c2Ugd2UgYXJlIGRvaW5nIGEgZGlmZmVyZW50IHdheSBvZiBzdGFjayBhcmVhLlxyXG4gICAgICogbmF0dXJhbCB3YXkgb2YgbGluZSBjaGFydCBpcyAxIGxpbmUsIDEgc2VyaWVzLlxyXG4gICAgICogd2hhdCB3ZSBhcmUgZG9pbmcgaXMgY3V0IHRoZSBsaW5lL3NwbGl0IHRoZSBzdGFjayBhcmVhIGludG8gMiB0byBjYXRlciBmb3IgbnVsbCB2YWx1ZS5cclxuICAgICAqIHRoZSBkYXRhIHN0cnVjdHVyZSB0aGF0IHdlIGhhdmUgY291cGxlZCBzdHJpY3RseSB0byAxIHggYXhpcy9jYXRlZ29yeSBtYXRjaCB3aXRoIDEgeSBkYXRhIHZhbHVlLlxyXG4gICAgICogZm9yIHNwbGl0dGluZyBvZiBzdGFjayBhcmVhLCB3ZSB3aWxsIG5lZWQgMSB4IGNhdGVnb3J5IG1hdGNoIHdpdGggMiB5IGRhdGEgdmFsdWUuXHJcbiAgICAgKlxyXG4gICAgICogcGFyYW0gIHtBcnJheTxJRDNEYXRhRGF0YT59IGRhdGEgYWZ0ZXIgbWFzc2FnZSBkYXRhXHJcbiAgICAgKiByZXR1cm4ge0FycmF5fSAgICAgICAgICAgICAgICAgICByZXR1cm4gYXMge3gsIHksIHkwLCB2YWxpZH0gYXMgZDMgcmVxdWlyZWQuXHJcbiAgICAgKi9cclxuICAgIHByaXZhdGUgX2RhdGFNYXNzYWdlKF9kYXRhOiBBcnJheTxJRDNEYXRhRGF0YT4pOiBBcnJheTxBcnJheTxJRGF0YVZhbHVlPj4ge1xyXG4gICAgICAgIC8vIGNvbnNvbGUubG9nKF9kYXRhKTtcclxuICAgICAgICBsZXQgZGF0YUFycjogQXJyYXk8QXJyYXk8SURhdGFWYWx1ZT4+ID0gW107XHJcbiAgICAgICAgbGV0IGFkanVzdFBvc2l0aW9uOiBJQWRqdXN0ID0ge307XHJcblxyXG4gICAgICAgIGZvciAobGV0IGk6IG51bWJlciA9IDA7IGkgPCB0aGlzLl9zZXJpZXNMaXN0Lmxlbmd0aDsgKytpKSB7XHJcblxyXG4gICAgICAgICAgICBsZXQgZGF0YURldGFpbHM6IEFycmF5PElEYXRhVmFsdWU+ID0gW107XHJcblxyXG4gICAgICAgICAgICBsZXQgeDogc3RyaW5nID0gbnVsbDtcclxuICAgICAgICAgICAgbGV0IHk6IG51bWJlciA9IDA7XHJcbiAgICAgICAgICAgIGxldCB5MDogbnVtYmVyID0gMDtcclxuICAgICAgICAgICAgbGV0IHZhbGlkOiBib29sZWFuID0gdHJ1ZTtcclxuXHJcbiAgICAgICAgICAgIGZvciAobGV0IHhJbmRleDogbnVtYmVyID0gMDsgeEluZGV4IDwgX2RhdGEubGVuZ3RoOyArK3hJbmRleCkge1xyXG4gICAgICAgICAgICAgICAgbGV0IHhWYWx1ZTogc3RyaW5nID0gX2RhdGFbeEluZGV4XS54LnZhbHVlO1xyXG5cclxuICAgICAgICAgICAgICAgIGZvciAobGV0IHlJbmRleDogbnVtYmVyID0gMDsgeUluZGV4IDwgX2RhdGFbeEluZGV4XS55Lmxlbmd0aDsgKyt5SW5kZXgpIHtcclxuICAgICAgICAgICAgICAgICAgICBsZXQgaWQ6IHN0cmluZyA9IF9kYXRhW3hJbmRleF0ueVt5SW5kZXhdLmlkO1xyXG4gICAgICAgICAgICAgICAgICAgIHggPSB4VmFsdWU7XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIHZhbGlkID0gX2RhdGFbeEluZGV4XS55W3lJbmRleF0udmFsdWUgIT09IG51bGwgPyB0cnVlIDogZmFsc2U7XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIGlmICh0aGlzLmNoYXJ0VHlwZVsxXSA9PT0gJ3N0YWNrJyAmJiBpZCA9PT0gdGhpcy5fc2VyaWVzTGlzdFtpXSkge1xyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgbGV0IG51bGxWYWx1ZTogbnVtYmVyID0gdGhpcy5fZ2V0TnVsbEhlaWdodFZhbHVlKF9kYXRhLCB4SW5kZXgsIHlJbmRleCk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGxldCBhZGp1c3RWYWx1ZSA9ICh0eXBlb2YgYWRqdXN0UG9zaXRpb25beEluZGV4XSA9PT0gJ3VuZGVmaW5lZCcpID8gMCA6IGFkanVzdFBvc2l0aW9uW3hJbmRleF07XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGFkanVzdFBvc2l0aW9uW3hJbmRleF0gPSBhZGp1c3RWYWx1ZSAtIG51bGxWYWx1ZTtcclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGxldCBhZGp1c3Q6IG51bWJlciA9IGFkanVzdFBvc2l0aW9uW3hJbmRleF0gfHwgMDtcclxuICAgICAgICAgICAgICAgICAgICAgICAgbGV0IGN1cnJlbnRWYWx1ZTogbnVtYmVyID0gX2RhdGFbeEluZGV4XS55W3lJbmRleF0udmFsdWU7XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICB5ID0gX2RhdGFbeEluZGV4XS55W3lJbmRleF0uc3VtICsgYWRqdXN0O1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB5MCA9IHkgLSBjdXJyZW50VmFsdWU7XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICBkYXRhRGV0YWlscy5wdXNoKHsgeDogeyB2YWx1ZTogeCwgbGFiZWw6IHggfSwgeTogeSwgeTA6IHkwLCBpZDogaWQsIHZhbGlkOiB2YWxpZCB9KTtcclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGxldCBzcGxpdFBhdGhEYXRhOiBJRGF0YVZhbHVlID0gdGhpcy5fZ2V0U3BsaXRQYXRoRGF0YShfZGF0YSwgeEluZGV4LCB5SW5kZXgsIGFkanVzdFBvc2l0aW9uKTtcclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGlmIChzcGxpdFBhdGhEYXRhLnZhbGlkID09PSB0cnVlKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBkYXRhRGV0YWlscy5wdXNoKHsgeDogc3BsaXRQYXRoRGF0YS54LCB5OiBzcGxpdFBhdGhEYXRhLnksIHkwOiBzcGxpdFBhdGhEYXRhLnkwLCBpZDogaWQsIHZhbGlkOiBmYWxzZSB9KTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRhdGFEZXRhaWxzLnB1c2goeyB4OiBzcGxpdFBhdGhEYXRhLngsIHk6IHNwbGl0UGF0aERhdGEueSwgeTA6IHNwbGl0UGF0aERhdGEueTAsIGlkOiBpZCwgdmFsaWQ6IHRydWUgfSk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBkYXRhQXJyLnB1c2goZGF0YURldGFpbHMpO1xyXG4gICAgICAgIH1cclxuICAgICAgICAvLyBjb25zb2xlLmxvZyhkYXRhQXJyKTtcclxuICAgICAgICByZXR1cm4gZGF0YUFycjtcclxuICAgIH1cclxuXHJcbiAgICAvKipcclxuICAgICAqIGlmIHRoZSBwcmV2aW91cyBzZXJpZXMgaXMgbnVsbCwgYXJlYSBoZWlnaHQgY2FsY3VsYXRpb24gc3RhcnQgZnJvbSB0aGUgc2VyaWVzIHRoYXQgZXhpc3QuXHJcbiAgICAgKiBwYXJhbSAge0FycmF5PElEM0RhdGFEYXRhPn0gZGF0YSAgIFtkYXRhIGFmdGVyIG1hc3NhZ2VdXHJcbiAgICAgKiBwYXJhbSAge251bWJlcn0gICAgICAgICAgICAgeEluZGV4IFtpbmRleCBvZiBkYXRhXVxyXG4gICAgICogcGFyYW0gIHtudW1iZXJ9ICAgICAgICAgICAgIHlJbmRleCBbaW5kZXggb2Ygc2VyaWVzXVxyXG4gICAgICogcGFyYW0gIHtudW1iZXJ9ICAgICAgICAgICAgIGFkanVzdCBbaG93IG11Y2ggcG9pbnQgdG8gYmUgYnJpbmcgZG93biAocHJldmlvdXMpXVxyXG4gICAgICogcmV0dXJuIHtudW1iZXJ9ICAgICAgICAgICAgICAgICAgICBbcmV0dXJuIGFjY3VtdWxhdGUgYWRqdXN0bWVudCBwb2ludF1cclxuICAgICAqL1xyXG4gICAgcHJpdmF0ZSBfZ2V0TnVsbEhlaWdodFZhbHVlKF9kYXRhOiBBcnJheTxJRDNEYXRhRGF0YT4sIF94SW5kZXg6IG51bWJlciwgX3lJbmRleDogbnVtYmVyKTogbnVtYmVyIHtcclxuICAgICAgICBsZXQgY3VycmVudFZhbDogbnVtYmVyID0gX2RhdGFbX3hJbmRleF0ueVtfeUluZGV4XS52YWx1ZTtcclxuXHJcbiAgICAgICAgbGV0IGlzRGlzYXBwZWFyaW5nOiBib29sZWFuID0gZmFsc2U7XHJcblxyXG4gICAgICAgIGxldCBpc1Nlcmllc051bGw6IG9iamVjdCA9IHRoaXMuX2NoYXJ0U3ZjLmlzU2VyaWVzTnVsbChfZGF0YSwgX3hJbmRleCwgX3lJbmRleCk7XHJcbiAgICAgICAgbGV0IGlzUHJldk51bGw6IGJvb2xlYW4gPSBpc1Nlcmllc051bGxbJ2lzUHJldk51bGwnXTtcclxuICAgICAgICBsZXQgaXNTaWRlc051bGw6IGJvb2xlYW4gPSBpc1Nlcmllc051bGxbJ2lzTmV4dE51bGwnXSAmJiAoX3hJbmRleCA8IDEgfHwgaXNQcmV2TnVsbCk7XHJcbiAgICAgICAgaWYgKF94SW5kZXggPiAwKSB7XHJcbiAgICAgICAgICAgIGxldCBjaGVja1Nlcmllczogb2JqZWN0ID0gdGhpcy5fY2hhcnRTdmMuaXNTZXJpZXNOdWxsKF9kYXRhLCAoX3hJbmRleCAtIDEpLCBfeUluZGV4KTtcclxuICAgICAgICAgICAgaXNEaXNhcHBlYXJpbmcgPSBjaGVja1Nlcmllc1snaXNEaXNhcHBlYXJpbmcnXTtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIGlmIChjdXJyZW50VmFsID09PSBudWxsIHx8IGlzU2lkZXNOdWxsIHx8IGlzUHJldk51bGwgfHwgaXNEaXNhcHBlYXJpbmcpIHtcclxuICAgICAgICAgICAgcmV0dXJuIGN1cnJlbnRWYWw7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIHJldHVybiAwO1xyXG4gICAgfVxyXG5cclxuICAgIC8qKlxyXG4gICAgICogY2hlY2sgaWYgdGhlIHNlcmllcyBhcHBlYXJpbmcgb3IgZGlzYXBwZWFyaW5nLCBhZGp1c3QgdGhlIHBvc2l0aW9uIG9mIHRoZSBsaW5lIGFyZWEgKHN0YWdlIHVwL2Rvd24pXHJcbiAgICAgKlxyXG4gICAgICogYXBwZWFyaW5nIGlzIHJlZmVycmluZyB0bzogdGhlcmUgaXMgYSBudWxsIG9uIHByZXZpb3VzIHggYXhpcyBidXQgbm90IG51bGwgb24gY3VycmVudCBhbmQgYWZ0ZXJcclxuICAgICAqXHJcbiAgICAgKiBkaXNhcHBlcmluZyBpcyByZWZlcnJpbmcgdG86IHRoZXJlIGlzIGEgdmFsdWUgb24gcHJldmlvdXMgYW5kIGN1cnJlbnQgeCBheGlzIGJ1dCBudWxsIGFmdGVyXHJcbiAgICAgKlxyXG4gICAgICogcGFyYW0gIHtBcnJheTxJRDNEYXRhRGF0YT59IGRhdGEgICBbZGF0YSBhZnRlciBtYXNzYWdlXVxyXG4gICAgICogcGFyYW0gIHtudW1iZXJ9ICAgICAgICAgICAgIHhJbmRleCBbaW5kZXggb2YgZGF0YV1cclxuICAgICAqIHBhcmFtICB7bnVtYmVyfSAgICAgICAgICAgICB5SW5kZXggW2luZGV4IG9mIHNlcmllc11cclxuICAgICAqIHBhcmFtICB7b2JqZWN0fSAgICAgICAgICAgICBhZGp1c3QgW2hlaWdodCB0byBwdWxsIGRvd24gc2VyaWVzIChpZiBwcmV2aW91cyBzZXJpZXMgaGFzIG51bGwpIG9yIGJyaW5nIHVwXVxyXG4gICAgICogcmV0dXJuIHtJRGF0YVZhbHVlfSAgICAgICAgICAgICAgICBbZDMgZHJhdyBwYXRoIGRhdGEgc3RydWN0dXJlOiB7eCwgeSwgeTAsIHZhbGlkfV1cclxuICAgICAqL1xyXG4gICAgcHJpdmF0ZSBfZ2V0U3BsaXRQYXRoRGF0YShfZGF0YTogQXJyYXk8SUQzRGF0YURhdGE+LCBfeEluZGV4OiBudW1iZXIsIF95SW5kZXg6IG51bWJlciwgX2FkanVzdDogSUFkanVzdCk6IElEYXRhVmFsdWUge1xyXG5cclxuICAgICAgICBsZXQgY3VycmVudFZhbHVlOiBudW1iZXIgPSBfZGF0YVtfeEluZGV4XS55W195SW5kZXhdLnZhbHVlO1xyXG5cclxuICAgICAgICBsZXQgc3BsaXQ6IGJvb2xlYW4gPSBmYWxzZTtcclxuICAgICAgICBsZXQgeTogbnVtYmVyID0gX2RhdGFbX3hJbmRleF0ueVtfeUluZGV4XS5zdW0gKyAoX2FkanVzdFtfeEluZGV4XSB8fCAwKTtcclxuICAgICAgICBsZXQgeDogc3RyaW5nID0gX2RhdGFbX3hJbmRleF0ueC52YWx1ZTtcclxuICAgICAgICBsZXQgeTA6IG51bWJlciA9IDAgLSBjdXJyZW50VmFsdWU7XHJcblxyXG4gICAgICAgIGlmIChjdXJyZW50VmFsdWUgPT09IG51bGwpIHtcclxuICAgICAgICAgICAgcmV0dXJuIHsgeDogeyB2YWx1ZTogeCwgbGFiZWw6IHggfSwgeTogeSwgeTA6IHkwLCB2YWxpZDogc3BsaXQgfTtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIGxldCBpc0Rpc2FwcGVhcmluZyA9IF94SW5kZXggPiAwICYmIF94SW5kZXggPCBfZGF0YS5sZW5ndGggLSAxICYmXHJcbiAgICAgICAgICAgIF9kYXRhW194SW5kZXggKyAxXS55W195SW5kZXhdLnZhbHVlID09PSBudWxsICYmXHJcbiAgICAgICAgICAgIGN1cnJlbnRWYWx1ZSAhPT0gbnVsbCAmJiBfZGF0YVtfeEluZGV4IC0gMV0ueVtfeUluZGV4XS52YWx1ZSAhPT0gbnVsbDtcclxuXHJcbiAgICAgICAgbGV0IGlzUmVhcHBlYXJpbmcgPSBfeEluZGV4ID4gMCAmJiBfeEluZGV4IDwgX2RhdGEubGVuZ3RoIC0gMSAmJlxyXG4gICAgICAgICAgICBfZGF0YVtfeEluZGV4IC0gMV0ueVtfeUluZGV4XS52YWx1ZSA9PT0gbnVsbCAmJlxyXG4gICAgICAgICAgICBjdXJyZW50VmFsdWUgIT09IG51bGwgJiYgX2RhdGFbX3hJbmRleCArIDFdLnlbX3lJbmRleF0udmFsdWUgIT09IG51bGw7XHJcblxyXG4gICAgICAgIGlmIChpc1JlYXBwZWFyaW5nKSB7XHJcbiAgICAgICAgICAgIF9hZGp1c3RbJ2FkanVzdCcgKyBfeEluZGV4XSA9IChfYWRqdXN0WydhZGp1c3QnICsgX3hJbmRleF0gfHwgMCkgKyBjdXJyZW50VmFsdWU7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICBpZiAoaXNEaXNhcHBlYXJpbmcpIHtcclxuICAgICAgICAgICAgX2FkanVzdFsnYWRqdXN0JyArIF94SW5kZXhdID0gKF9hZGp1c3RbJ2FkanVzdCcgKyBfeEluZGV4XSB8fCAwKSAtIGN1cnJlbnRWYWx1ZTtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIGlmIChjdXJyZW50VmFsdWUgIT09IG51bGwgJiYgX2FkanVzdFsnYWRqdXN0JyArIF94SW5kZXhdKSB7XHJcbiAgICAgICAgICAgIHkgPSB5ICsgX2FkanVzdFsnYWRqdXN0JyArIF94SW5kZXhdO1xyXG4gICAgICAgICAgICB5MCA9IHkwICsgeTtcclxuICAgICAgICAgICAgc3BsaXQgPSB0cnVlO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgcmV0dXJuIHsgeDogeyB2YWx1ZTogeCwgbGFiZWw6IHggfSwgeTogeSwgeTA6IHkwLCB2YWxpZDogc3BsaXQgfTtcclxuICAgIH1cclxufVxyXG4iXX0=