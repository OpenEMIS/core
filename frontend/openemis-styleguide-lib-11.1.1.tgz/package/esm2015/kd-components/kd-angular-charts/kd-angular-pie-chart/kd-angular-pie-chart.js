import { Component, ViewEncapsulation, Input, Output, EventEmitter } from '@angular/core';
import { KdChartBaseClass } from '../kd-angular-chart-base-class';
import { KdChartsSvc } from '../kd-angular-charts-svc';
import { KdDomElemSvc } from '../../kd-common/index';
import * as d3 from 'd3';
const PI = Math.PI, arcMinRadius = 10, arcPadding = 10, labelPadding = -5, numTicks = 10;
export class KdPieChart extends KdChartBaseClass {
    constructor(_chartSvc, _domSvc) {
        super(_chartSvc, _domSvc);
        this._chartSvc = _chartSvc;
        this._domSvc = _domSvc;
        this.pieData = [];
        this._posArray = [];
        this.outputLegend = new EventEmitter(true);
        this.outputData = new EventEmitter(true);
    }
    ngOnInit() {
        this.config = Object.assign({}, this.pieConfig);
        this._setData();
        super.chartTimeout(() => this._setChart());
        this.api.legendClick = (_data, legendData) => {
            this.pieData = [];
            if (this.dataLabelContainer)
                this.dataLabelContainer.selectAll('*').remove();
            // if (_config) this.config = _config;
            this.data = _data;
            if (legendData) {
                // let newColor = [];
                this.pieData = this.data.data;
                // this.pieData = Object.keys(_config.legendData).map(key => _config.legendData[key]).map((value) => (value));
                // for (let i = 0; i < this.pieData.length; i++) {
                //     newColor.push(this.pieData[i].color);
                // }
                // this.pieConfig['pieColor'] = newColor;
                this._redrawChart();
            }
            else {
                // fail-safe in case data massage haven't create legendData
                this._setData();
                this._setChart();
            }
        };
        this.api.redraw = () => {
            this._redrawChart();
        };
    }
    ngOnChanges(_simpleChanges) {
        if (_simpleChanges.hasOwnProperty('data') && !_simpleChanges['data'].firstChange) {
            this.data = _simpleChanges.data.currentValue;
            this._redrawChart('data');
        }
        if (_simpleChanges.hasOwnProperty('pieConfig') && !_simpleChanges['pieConfig'].firstChange) {
            this.pieConfig = _simpleChanges.pieConfig.currentValue;
            this._redrawChart('config');
        }
    }
    ngOnDestroy() {
        this._resetChart();
    }
    _redrawChart(_changes) {
        this._resetChart();
        if (_changes === 'data') {
            this.pieData = [];
            this._setData();
        }
        else {
            this.pieConfig['legendData'] = this.config['legendData'];
            this.config = Object.assign({}, this.pieConfig);
        }
        super.chartTimeout(() => this._setChart());
    }
    _setChart() {
        super.setSvg();
        super.setSvgDimension('x');
        super.setSvgDimension('y');
        this.chartType = this.data.layout.split('-');
        this.chartCategory = this.data.type;
        // moving pie chart to center of svg
        let height = this.svgContainer.node().getBoundingClientRect().height;
        let width = this.svgContainer.node().getBoundingClientRect().width;
        this.width = width;
        this.graph.attr('transform', 'translate(' + (width / 2) + ',' + (height / 2) + ')');
        // let color = this.pieConfig['pieColor'] ? d3.scaleOrdinal().range(this.pieConfig['pieColor']) : d3.scaleOrdinal().range(this.config.colors);
        // let chartParams = {
        //     'color': color
        // };
        this.dataLabelContainer.style('top', 0);
        this.dataLabelContainer.style('left', 0);
        if (this.chartType[0] === 'radial') {
            this._drawRadial({ height: height });
        }
        else if (this.chartType[0] === 'gauge') {
            this._drawGauge({ height: height });
        }
        else {
            this._drawPieDonut({ height: height, width: width });
        }
    }
    /**
     * when receiving data and legend, the structure is customise to for line/area and bar. pie needs to recalculate the legend
     * _setData generate pieData and new legend from the previous legend
     *
     * Note: this.pieData is used for rendering.
     * Note2: data.pieData it will not be changed onLegendClick
     * (onLegendClick affects data.data which is stored into this.pieData via api)
     */
    _setData() {
        if (!this.config.skipMassage) {
            if (this.data['piedata']) {
                this.pieData = this.data.piedata;
                // saving massaged piedata to this.data for export
                this.data.data = this.data.piedata;
            }
        }
        else {
            // when skip massage, no generation of pieData needed.
            this.pieData = this.data.data;
        }
    }
    _resetChart() {
        if (typeof this._path !== 'undefined')
            this._path.remove();
        if (typeof this._radialAxis !== 'undefined')
            this._radialAxis.remove();
        if (typeof this._axialAxis !== 'undefined')
            this._axialAxis.remove();
        if (typeof this._text !== 'undefined')
            this._text.remove();
        if (typeof this._polyline !== 'undefined')
            this._polyline.remove();
        if (typeof this._pointer !== 'undefined')
            this._pointer.remove();
        if (typeof this._percentageText !== 'undefined')
            this._percentageText.remove();
        if (this.dataLabelContainer)
            this.dataLabelContainer.selectAll('*').remove();
        this._posArray = [];
        clearInterval(this._interval);
        super.removeChart();
    }
    _drawPieDonut(_params) {
        let radius = Math.min(_params.width, _params.height) / 2;
        if (this.chartType[1] && this.chartType[1] === 'half') {
            radius = (Math.min(_params.width, _params.height) / 5) * 3;
            this.graph.attr('transform', 'translate(' + (_params.width / 2) + ',' + ((_params.height / 4) * 3) + ')');
        }
        let innerRadius = this.chartType[0] === 'pie' ? 0 : (this.config.plotOptions.pie.innerRadius / 100) * radius * 0.8;
        let arc = d3.arc().innerRadius(innerRadius).outerRadius(radius * 0.8);
        let outerarc = d3.arc().innerRadius(radius * 0.9).outerRadius(radius * 0.9);
        // let arc = d3.arc().innerRadius(innerRadius).outerRadius(radius);
        let pie = d3.pie().sort(null).value((d) => { return d.y; });
        let dataLabelCheck = this.chartType[1] === 'full' ? Math.PI : 0;
        pie = this.chartType[1] === 'full' ? pie.startAngle(0).endAngle(Math.PI * 2) : pie.startAngle(-90 * (Math.PI / 180)).endAngle(90 * (Math.PI / 180));
        this._path = this.graph.selectAll('path')
            .data(pie(this.pieData))
            .enter()
            .append('path')
            .attr('aria-value', (d) => d.data.y)
            .attr('aria-series-name', (d) => this.legend[d.data.id].name)
            .attr('class', (d) => {
            this._posArray.push({ 'x': d.data.index, 'value': d.data.y, 'id': d.data.index });
            return 'x-' + d.data.index + ' y-' + d.data.index;
            // return 'x-' + (d.data.xBase).replace(/ /g,'') + ' y-' + seriesId;
        })
            .attr('id', (d) => {
            return d.data.index;
            // return (d.data.x).replace(/ /g,'');
        })
            .attr('fill', (d, i) => {
            return this.legend[d.data.id].color; // color should follow legendData
        })
            // .attr('d', arc)
            .style('stroke', this.config.plotOptions.pie.borderColor)
            .style('stroke-width', this.config.plotOptions.pie.borderWidth || 0);
        let labelParams = {
            'pie': pie,
            'arc': arc,
            'outerarc': outerarc,
            'radius': radius,
            'dataLabelCheck': dataLabelCheck,
        };
        if (!this.config.animation) {
            this._path
                .attr('d', d => arc(d))
                .attr('pos', d => getPos(d, this.chartType[1]));
            this._setDataLabel(labelParams);
        }
        else {
            this._path.transition()
                .delay((d, i) => {
                return i * 20;
            })
                .attrTween('d', (d) => {
                let i = d3.interpolate(d.startAngle, d.endAngle);
                return (t) => {
                    d.endAngle = i(t);
                    return arc(d);
                };
            })
                .attrTween('pos', (d) => {
                let current;
                current = current || d;
                let interpolate = d3.interpolate(current, d);
                current = interpolate(0);
                return (t) => {
                    let d2 = interpolate(t);
                    return getPos(d2, this.chartType[1]);
                };
            })
                .on('end', (d, i) => {
                if (i === (this.pieData.length - 1)) {
                    setTimeout(() => {
                        this._setDataLabel(labelParams);
                    });
                }
            });
        }
        this._path.exit().remove();
        function getPos(_d2, _chartType) {
            let pos = outerarc.centroid(_d2);
            if (_chartType && _chartType === 'half') {
                pos[0] = radius * (midAngle(_d2) < dataLabelCheck ? -1 : 1);
            }
            else {
                pos[0] = radius * (midAngle(_d2) < dataLabelCheck ? 1 : -1);
            }
            return pos;
        }
        function midAngle(_d) {
            return _d.startAngle + (_d.endAngle - _d.startAngle) / 2;
        }
        let eventsParam = {
            'innerRadius': innerRadius,
            'outerRadius': radius * 0.8,
            'pathAnim': this._pathAnim,
        };
        super._initMouseEvents(this._path, eventsParam);
    }
    _drawRadial(_params) {
        // let height = document.querySelector('#' + this.config.id + '.kdx-charts .svg-container').getBoundingClientRect().height;
        let chartRadius = _params.height / 2 - 40;
        let scale = d3.scaleLinear()
            .domain([0, d3.max(this.pieData, d => d.y) * 1.1])
            .range([0, 2 * PI]);
        let ticks = scale.ticks(numTicks).slice(0, -1);
        let keys = this.pieData.map((d, i) => d.x);
        // number of arcs
        const numArcs = keys.length;
        const arcWidth = (chartRadius - arcMinRadius - numArcs * arcPadding) / numArcs;
        let arc = d3.arc()
            .innerRadius((d, i) => this._getInnerRadius(i, numArcs, arcWidth))
            .outerRadius((d, i) => this._getOuterRadius(i, numArcs, arcWidth))
            .startAngle(0)
            .endAngle((d, i) => scale(d));
        this._radialAxis = this.graph.append('g')
            .attr('class', 'kdx-charts-r kdx-charts-axis-radial')
            .selectAll('g')
            .data(this.pieData)
            .enter().append('g');
        this._radialAxis.append('circle')
            .attr('r', (d, i) => this._getOuterRadius(i, numArcs, arcWidth) + arcPadding);
        this._radialAxis.append('text')
            .attr('x', labelPadding)
            .attr('y', (d, i) => -this._getOuterRadius(i, numArcs, arcWidth) + arcPadding)
            .style('font-size', '10px')
            .text(d => d.x);
        this._axialAxis = this.graph.append('g')
            .attr('class', 'kdx-charts-a kdx-charts-axis-radial')
            .selectAll('g')
            .data(ticks)
            .enter().append('g')
            .attr('transform', d => 'rotate(' + (this._rad2deg(scale(d)) - 90) + ')');
        this._axialAxis.append('line')
            .attr('x2', chartRadius);
        this._axialAxis.append('text')
            .attr('x', chartRadius + 10)
            .style('text-anchor', d => (scale(d) >= PI && scale(d) < 2 * PI ? 'end' : null))
            .style('font-size', '10px')
            .attr('transform', d => 'rotate(' + (90 - this._rad2deg(scale(d))) + ',' + (chartRadius + 10) + ',0)')
            .text(d => d);
        // data arcs
        this._path = this.graph.append('g')
            .selectAll('path')
            .data(this.pieData)
            .enter().append('path')
            .attr('class', (d) => {
            return 'x-' + d.xBase + ' y-' + d.x;
        })
            .style('fill', (d, i) => this.legend[d.id].color);
        if (!this.config.animation) {
            this._path.attr('d', (d, i) => arc(d.y, i));
        }
        else {
            this._path.transition()
                .delay((d, i) => i * 100)
                .duration(200)
                // .attrTween('d', arcTween);
                .attrTween('d', (d, i) => {
                let interpolate = d3.interpolate(0, d.y);
                return t => arc(interpolate(t), i);
            });
        }
        super._initMouseEvents(this._path);
    }
    _drawGauge(_params) {
        // let percent = 100.00;
        let percent = Math.floor(Math.random() * 100);
        let endAngle = this.chartType[1] === 'full' ? Math.PI * 2 : Math.PI;
        let outerRadius = _params.height / 3;
        let innerRadius = (outerRadius / 3) * 2;
        let fontSize = innerRadius * 0.8;
        let arc = d3.arc()
            .innerRadius(innerRadius)
            .outerRadius(outerRadius)
            .startAngle(0)
            .endAngle(endAngle);
        let arcLine = d3.arc()
            .innerRadius(innerRadius)
            .outerRadius(outerRadius)
            .startAngle(0);
        this._path = this.graph.append('path')
            .attr('d', arc)
            .attr('transform', 'rotate(-90)')
            .attr('stroke-width', 1)
            .attr('stroke', '#666666')
            .style('fill', '#FFFFFF');
        this._pointer = this.graph.append('path')
            // let pathForeground = this.graph.append('path')
            .datum({ endAngle: 0 })
            .attr('d', arcLine)
            .attr('transform', 'rotate(-90)');
        this._percentageText = this.graph.append('text')
            .datum(0)
            .text(function (d) {
            return d;
        })
            .attr('class', 'kdx-charts-middleText')
            .attr('text-anchor', 'middle')
            .attr('dy', this.chartType[1] === 'full' ? fontSize * 0.45 : 0)
            .style('fill', d3.rgb('#000000'))
            .style('font-size', fontSize + 'px');
        if (!this.config.animation) {
            this._pointer
                .attr('d', d => arcLine(d))
                .style('fill', d3.rgb('#FF0000'));
            return;
        }
        let arcTween = function (transition, newValue, test) {
            transition.attrTween('d', (d) => {
                let interpolate = d3.interpolate(d.endAngle, ((endAngle)) * (newValue / 100));
                let interpolateCount = d3.interpolate(0, newValue);
                return (t) => {
                    d.endAngle = interpolate(t);
                    test._percentageText.text(Math.floor(interpolateCount(t)) + '%');
                    return arcLine(d);
                };
            });
        };
        this._pointer.transition()
            .duration(750)
            .ease(d3.easeCubicIn)
            .call(arcTween, percent, this)
            .style('fill', d3.rgb('#FF0000'));
    }
    _setDataLabel(_params) {
        if (!this.config.chart.labels.enabled)
            return;
        if (this.chartCategory !== 'pie')
            return;
        if (this._posArray.length === 0)
            return;
        let line = Array.from(document.querySelectorAll('#' + this.config.id + '.kdx-charts .kdx-charts-lines'));
        line.forEach(e => e.parentNode.removeChild(e));
        let key = (d) => { return d.data.y; };
        function midAngle(_d) {
            return _d.startAngle + (_d.endAngle - _d.startAngle) / 2;
        }
        let height = this.svgContainer.node().getBoundingClientRect().height;
        let width = this.svgContainer.node().getBoundingClientRect().width;
        height = (this.chartType[1] && this.chartType[1] === 'half') ? ((height / 4) * 3) - 8 : height / 2 - 8;
        for (let i = 0; i < this._path._groups[0].length; i++) {
            if (this._posArray[i] && this._posArray[i].id !== undefined) {
                let posPointer = document.querySelector('#' + this.config.id + ' #' + this._posArray[i].id).getAttribute('pos');
                if (this._posArray.length !== 0 && document.querySelector('#' + this.config.id + ' #' + this._posArray[i].id) !== null && posPointer !== null) {
                    let yData = {
                        'id': this._posArray[i].id,
                        'value': this._posArray[i].value
                    };
                    let xvalue = parseInt(posPointer.split(',')[0]) + width / 2;
                    let yvalue = parseInt(posPointer.split(',')[1]) + height;
                    let tempCondition = parseInt(posPointer.split(',')[0]);
                    let rtlCondition = this.isRtl === false ? tempCondition < 0 : tempCondition > 0;
                    let checkFlexEndStyle = rtlCondition ? 'flex-end' : 'flex-start';
                    let dataLabelClass = '#' + this.config.id + ' .kdx-charts-data-label.x-' + this._posArray[i].x + '.y-' + yData.id;
                    if (document.querySelector(dataLabelClass) == null) {
                        super.setLabel(yData, this._posArray[i].x, xvalue, yvalue).style('visibility', 'visible').style('width', '0px').style('justify-content', checkFlexEndStyle);
                    }
                }
            }
        }
        this._polyline = this.graph.append('g')
            .attr('class', 'kdx-charts-lines')
            .selectAll('polyline')
            .data(_params.pie(this.pieData), key)
            .enter()
            .append('polyline')
            .style('stroke', (d, i) => {
            return this.legend[d.data.id].color;
        }).attr('points', (d) => {
            return getPos(d, this.chartType[1]);
        }).style('fill', 'none');
        // if (!this.config.animation) {
        //     this._polyline.attr('points', (d) => {
        //         return getPos(d, this.chartType[1]);
        //     });
        //     return;
        // }
        // this._polyline.transition().duration(1000)
        //     .attrTween('points', (d) => {
        //         this._current = this._current || d;
        //         let interpolate = d3.interpolate(this._current, d);
        //         this._current = interpolate(0);
        //         return (t) => {
        //             let d2 = interpolate(t);
        //             return getPos(d2, this.chartType[1]);
        //         };
        //     });
        function getPos(_d2, _chartType) {
            let pos = _params.outerarc.centroid(_d2);
            if (_chartType && _chartType === 'half') {
                pos[0] = _params.radius * 0.95 * (midAngle(_d2) < _params.dataLabelCheck ? -1 : 1);
            }
            else {
                pos[0] = _params.radius * 0.95 * (midAngle(_d2) < _params.dataLabelCheck ? 1 : -1);
            }
            return [_params.arc.centroid(_d2), _params.outerarc.centroid(_d2), pos];
        }
    }
    _getInnerRadius(_index, _numArcs, _arcWidth) {
        return arcMinRadius + (_numArcs - (_index + 1)) * (_arcWidth + arcPadding);
    }
    _getOuterRadius(_index, _numArcs, _arcWidth) {
        return this._getInnerRadius(_index, _numArcs, _arcWidth) + _arcWidth;
    }
    _rad2deg(_angle) {
        return _angle * 180 / PI;
    }
    _pathAnim(_path, dir, _innerRadius, _outerRadius) {
        switch (dir) {
            case false:
                _path.transition()
                    .duration(500)
                    // .ease('bounce')
                    .attr('d', d3.arc()
                    .innerRadius(_innerRadius)
                    .outerRadius(_outerRadius)).attr('stroke', 'none');
                break;
            case true:
                _path.transition()
                    .attr('d', d3.arc()
                    .innerRadius(_innerRadius)
                    .outerRadius(_outerRadius * 1.1)).attr('stroke', 'white').attr('stroke-width', 2);
                break;
        }
    }
}
KdPieChart.decorators = [
    { type: Component, args: [{
                selector: 'kd-pie-chart',
                template: '',
                encapsulation: ViewEncapsulation.None,
                providers: [KdChartsSvc, KdDomElemSvc],
                host: {
                    'class': 'kdx-pie-chart',
                }
            },] }
];
KdPieChart.ctorParameters = () => [
    { type: KdChartsSvc },
    { type: KdDomElemSvc }
];
KdPieChart.propDecorators = {
    data: [{ type: Input }],
    pieConfig: [{ type: Input, args: ['config',] }],
    legend: [{ type: Input }],
    api: [{ type: Input }],
    seriesThreshold: [{ type: Input }],
    outputLegend: [{ type: Output }],
    outputData: [{ type: Output }]
};
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoia2QtYW5ndWxhci1waWUtY2hhcnQuanMiLCJzb3VyY2VSb290IjoiRDovb3BlbkVNSVMvc3R5bGVndWlkZS9pb3N0Zy1vcGVuZW1pcy1zdHlsZWd1aWRlL3Byb2plY3RzL29wZW5lbWlzLXN0eWxlZ3VpZGUtbGliL3NyYy8iLCJzb3VyY2VzIjpbImtkLWNvbXBvbmVudHMva2QtYW5ndWxhci1jaGFydHMva2QtYW5ndWxhci1waWUtY2hhcnQva2QtYW5ndWxhci1waWUtY2hhcnQudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsT0FBTyxFQUNILFNBQVMsRUFDVCxpQkFBaUIsRUFDakIsS0FBSyxFQUNMLE1BQU0sRUFDTixZQUFZLEVBS2YsTUFBTSxlQUFlLENBQUM7QUFDdkIsT0FBTyxFQUFFLGdCQUFnQixFQUFFLE1BQU0sZ0NBQWdDLENBQUM7QUFDbEUsT0FBTyxFQUFFLFdBQVcsRUFBRSxNQUFNLDBCQUEwQixDQUFDO0FBQ3ZELE9BQU8sRUFBRSxZQUFZLEVBQUUsTUFBTSx1QkFBdUIsQ0FBQztBQUVyRCxPQUFPLEtBQUssRUFBRSxNQUFNLElBQUksQ0FBQztBQUV6QixNQUFNLEVBQUUsR0FBRyxJQUFJLENBQUMsRUFBRSxFQUNkLFlBQVksR0FBRyxFQUFFLEVBQ2pCLFVBQVUsR0FBRyxFQUFFLEVBQ2YsWUFBWSxHQUFHLENBQUMsQ0FBQyxFQUNqQixRQUFRLEdBQUcsRUFBRSxDQUFDO0FBWWxCLE1BQU0sT0FBTyxVQUFXLFNBQVEsZ0JBQWdCO0lBc0I1QyxZQUFtQixTQUFzQixFQUFTLE9BQXFCO1FBQ25FLEtBQUssQ0FBQyxTQUFTLEVBQUUsT0FBTyxDQUFDLENBQUM7UUFEWCxjQUFTLEdBQVQsU0FBUyxDQUFhO1FBQVMsWUFBTyxHQUFQLE9BQU8sQ0FBYztRQXJCaEUsWUFBTyxHQUFlLEVBQUUsQ0FBQztRQVV4QixjQUFTLEdBQUcsRUFBRSxDQUFDO1FBUWIsaUJBQVksR0FBaUQsSUFBSSxZQUFZLENBQUMsSUFBSSxDQUFDLENBQUM7UUFDcEYsZUFBVSxHQUFzQixJQUFJLFlBQVksQ0FBQyxJQUFJLENBQUMsQ0FBQztJQUlqRSxDQUFDO0lBRUQsUUFBUTtRQUNKLElBQUksQ0FBQyxNQUFNLEdBQUcsTUFBTSxDQUFDLE1BQU0sQ0FBQyxFQUFFLEVBQUUsSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDO1FBQ2hELElBQUksQ0FBQyxRQUFRLEVBQUUsQ0FBQztRQUNoQixLQUFLLENBQUMsWUFBWSxDQUFDLEdBQUcsRUFBRSxDQUFDLElBQUksQ0FBQyxTQUFTLEVBQUUsQ0FBQyxDQUFDO1FBRTNDLElBQUksQ0FBQyxHQUFHLENBQUMsV0FBVyxHQUFHLENBQUMsS0FBVSxFQUFFLFVBQWdCLEVBQUUsRUFBRTtZQUNwRCxJQUFJLENBQUMsT0FBTyxHQUFHLEVBQUUsQ0FBQztZQUNsQixJQUFJLElBQUksQ0FBQyxrQkFBa0I7Z0JBQUUsSUFBSSxDQUFDLGtCQUFrQixDQUFDLFNBQVMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxNQUFNLEVBQUUsQ0FBQztZQUM3RSxzQ0FBc0M7WUFDdEMsSUFBSSxDQUFDLElBQUksR0FBRyxLQUFLLENBQUM7WUFDbEIsSUFBSSxVQUFVLEVBQUU7Z0JBQ1oscUJBQXFCO2dCQUNyQixJQUFJLENBQUMsT0FBTyxHQUFHLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDO2dCQUM5Qiw4R0FBOEc7Z0JBQzlHLGtEQUFrRDtnQkFDbEQsNENBQTRDO2dCQUM1QyxJQUFJO2dCQUNKLHlDQUF5QztnQkFFekMsSUFBSSxDQUFDLFlBQVksRUFBRSxDQUFDO2FBRXZCO2lCQUFNO2dCQUNILDJEQUEyRDtnQkFDM0QsSUFBSSxDQUFDLFFBQVEsRUFBRSxDQUFDO2dCQUNoQixJQUFJLENBQUMsU0FBUyxFQUFFLENBQUM7YUFDcEI7UUFDTCxDQUFDLENBQUM7UUFDRixJQUFJLENBQUMsR0FBRyxDQUFDLE1BQU0sR0FBRyxHQUFHLEVBQUU7WUFDbkIsSUFBSSxDQUFDLFlBQVksRUFBRSxDQUFDO1FBQ3hCLENBQUMsQ0FBQztJQUNOLENBQUM7SUFFRCxXQUFXLENBQUMsY0FBNkI7UUFDckMsSUFBSSxjQUFjLENBQUMsY0FBYyxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsY0FBYyxDQUFDLE1BQU0sQ0FBQyxDQUFDLFdBQVcsRUFBRTtZQUM5RSxJQUFJLENBQUMsSUFBSSxHQUFHLGNBQWMsQ0FBQyxJQUFJLENBQUMsWUFBWSxDQUFDO1lBQzdDLElBQUksQ0FBQyxZQUFZLENBQUMsTUFBTSxDQUFDLENBQUM7U0FDN0I7UUFDRCxJQUFJLGNBQWMsQ0FBQyxjQUFjLENBQUMsV0FBVyxDQUFDLElBQUksQ0FBQyxjQUFjLENBQUMsV0FBVyxDQUFDLENBQUMsV0FBVyxFQUFFO1lBQ3hGLElBQUksQ0FBQyxTQUFTLEdBQUcsY0FBYyxDQUFDLFNBQVMsQ0FBQyxZQUFZLENBQUM7WUFDdkQsSUFBSSxDQUFDLFlBQVksQ0FBQyxRQUFRLENBQUMsQ0FBQztTQUMvQjtJQUNMLENBQUM7SUFFRCxXQUFXO1FBQ1AsSUFBSSxDQUFDLFdBQVcsRUFBRSxDQUFDO0lBQ3ZCLENBQUM7SUFFTyxZQUFZLENBQUMsUUFBNEI7UUFDN0MsSUFBSSxDQUFDLFdBQVcsRUFBRSxDQUFDO1FBRW5CLElBQUksUUFBUSxLQUFLLE1BQU0sRUFBRTtZQUNyQixJQUFJLENBQUMsT0FBTyxHQUFHLEVBQUUsQ0FBQztZQUNsQixJQUFJLENBQUMsUUFBUSxFQUFFLENBQUM7U0FDbkI7YUFBTTtZQUNILElBQUksQ0FBQyxTQUFTLENBQUMsWUFBWSxDQUFDLEdBQUcsSUFBSSxDQUFDLE1BQU0sQ0FBQyxZQUFZLENBQUMsQ0FBQztZQUN6RCxJQUFJLENBQUMsTUFBTSxHQUFHLE1BQU0sQ0FBQyxNQUFNLENBQUMsRUFBRSxFQUFFLElBQUksQ0FBQyxTQUFTLENBQUMsQ0FBQztTQUNuRDtRQUVELEtBQUssQ0FBQyxZQUFZLENBQUMsR0FBRyxFQUFFLENBQUMsSUFBSSxDQUFDLFNBQVMsRUFBRSxDQUFDLENBQUM7SUFDL0MsQ0FBQztJQUVPLFNBQVM7UUFDYixLQUFLLENBQUMsTUFBTSxFQUFFLENBQUM7UUFDZixLQUFLLENBQUMsZUFBZSxDQUFDLEdBQUcsQ0FBQyxDQUFDO1FBQzNCLEtBQUssQ0FBQyxlQUFlLENBQUMsR0FBRyxDQUFDLENBQUM7UUFFM0IsSUFBSSxDQUFDLFNBQVMsR0FBRyxJQUFJLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLENBQUM7UUFDN0MsSUFBSSxDQUFDLGFBQWEsR0FBRyxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQztRQUNwQyxvQ0FBb0M7UUFDcEMsSUFBSSxNQUFNLEdBQUcsSUFBSSxDQUFDLFlBQVksQ0FBQyxJQUFJLEVBQUUsQ0FBQyxxQkFBcUIsRUFBRSxDQUFDLE1BQU0sQ0FBQztRQUNyRSxJQUFJLEtBQUssR0FBRyxJQUFJLENBQUMsWUFBWSxDQUFDLElBQUksRUFBRSxDQUFDLHFCQUFxQixFQUFFLENBQUMsS0FBSyxDQUFDO1FBQ25FLElBQUksQ0FBQyxLQUFLLEdBQUcsS0FBSyxDQUFDO1FBQ25CLElBQUksQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLFdBQVcsRUFBRSxZQUFZLEdBQUcsQ0FBQyxLQUFLLEdBQUcsQ0FBQyxDQUFDLEdBQUcsR0FBRyxHQUFHLENBQUMsTUFBTSxHQUFHLENBQUMsQ0FBQyxHQUFHLEdBQUcsQ0FBQyxDQUFDO1FBRXBGLDhJQUE4STtRQUM5SSxzQkFBc0I7UUFDdEIscUJBQXFCO1FBQ3JCLEtBQUs7UUFDTCxJQUFJLENBQUMsa0JBQWtCLENBQUMsS0FBSyxDQUFDLEtBQUssRUFBRSxDQUFDLENBQUMsQ0FBQztRQUN4QyxJQUFJLENBQUMsa0JBQWtCLENBQUMsS0FBSyxDQUFDLE1BQU0sRUFBRSxDQUFDLENBQUMsQ0FBQztRQUV6QyxJQUFJLElBQUksQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLEtBQUssUUFBUSxFQUFFO1lBQ2hDLElBQUksQ0FBQyxXQUFXLENBQUMsRUFBRSxNQUFNLEVBQUUsTUFBTSxFQUFFLENBQUMsQ0FBQztTQUN4QzthQUFNLElBQUksSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsS0FBSyxPQUFPLEVBQUU7WUFDdEMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxFQUFFLE1BQU0sRUFBRSxNQUFNLEVBQUUsQ0FBQyxDQUFDO1NBQ3ZDO2FBQU07WUFDSCxJQUFJLENBQUMsYUFBYSxDQUFDLEVBQUUsTUFBTSxFQUFFLE1BQU0sRUFBRSxLQUFLLEVBQUUsS0FBSyxFQUFFLENBQUMsQ0FBQztTQUN4RDtJQUNMLENBQUM7SUFFRDs7Ozs7OztPQU9HO0lBQ0ssUUFBUTtRQUNaLElBQUksQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLFdBQVcsRUFBRTtZQUMxQixJQUFJLElBQUksQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLEVBQUU7Z0JBQ3RCLElBQUksQ0FBQyxPQUFPLEdBQUcsSUFBSSxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUM7Z0JBQ2pDLGtEQUFrRDtnQkFDbEQsSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLEdBQUcsSUFBSSxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUM7YUFDdEM7U0FDSjthQUFNO1lBQ0gsc0RBQXNEO1lBQ3RELElBQUksQ0FBQyxPQUFPLEdBQUcsSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUM7U0FDakM7SUFDTCxDQUFDO0lBRU8sV0FBVztRQUNmLElBQUksT0FBTyxJQUFJLENBQUMsS0FBSyxLQUFLLFdBQVc7WUFBRSxJQUFJLENBQUMsS0FBSyxDQUFDLE1BQU0sRUFBRSxDQUFDO1FBQzNELElBQUksT0FBTyxJQUFJLENBQUMsV0FBVyxLQUFLLFdBQVc7WUFBRSxJQUFJLENBQUMsV0FBVyxDQUFDLE1BQU0sRUFBRSxDQUFDO1FBQ3ZFLElBQUksT0FBTyxJQUFJLENBQUMsVUFBVSxLQUFLLFdBQVc7WUFBRSxJQUFJLENBQUMsVUFBVSxDQUFDLE1BQU0sRUFBRSxDQUFDO1FBQ3JFLElBQUksT0FBTyxJQUFJLENBQUMsS0FBSyxLQUFLLFdBQVc7WUFBRSxJQUFJLENBQUMsS0FBSyxDQUFDLE1BQU0sRUFBRSxDQUFDO1FBQzNELElBQUksT0FBTyxJQUFJLENBQUMsU0FBUyxLQUFLLFdBQVc7WUFBRSxJQUFJLENBQUMsU0FBUyxDQUFDLE1BQU0sRUFBRSxDQUFDO1FBQ25FLElBQUksT0FBTyxJQUFJLENBQUMsUUFBUSxLQUFLLFdBQVc7WUFBRSxJQUFJLENBQUMsUUFBUSxDQUFDLE1BQU0sRUFBRSxDQUFDO1FBQ2pFLElBQUksT0FBTyxJQUFJLENBQUMsZUFBZSxLQUFLLFdBQVc7WUFBRSxJQUFJLENBQUMsZUFBZSxDQUFDLE1BQU0sRUFBRSxDQUFDO1FBQy9FLElBQUksSUFBSSxDQUFDLGtCQUFrQjtZQUFFLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxTQUFTLENBQUMsR0FBRyxDQUFDLENBQUMsTUFBTSxFQUFFLENBQUM7UUFDN0UsSUFBSSxDQUFDLFNBQVMsR0FBRyxFQUFFLENBQUM7UUFDcEIsYUFBYSxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsQ0FBQztRQUM5QixLQUFLLENBQUMsV0FBVyxFQUFFLENBQUM7SUFDeEIsQ0FBQztJQUVPLGFBQWEsQ0FBQyxPQUEwQztRQUM1RCxJQUFJLE1BQU0sR0FBRyxJQUFJLENBQUMsR0FBRyxDQUFDLE9BQU8sQ0FBQyxLQUFLLEVBQUUsT0FBTyxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsQ0FBQztRQUN6RCxJQUFJLElBQUksQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLElBQUksSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsS0FBSyxNQUFNLEVBQUU7WUFDbkQsTUFBTSxHQUFHLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxPQUFPLENBQUMsS0FBSyxFQUFFLE9BQU8sQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUM7WUFDM0QsSUFBSSxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsV0FBVyxFQUFFLFlBQVksR0FBRyxDQUFDLE9BQU8sQ0FBQyxLQUFLLEdBQUcsQ0FBQyxDQUFDLEdBQUcsR0FBRyxHQUFHLENBQUMsQ0FBQyxPQUFPLENBQUMsTUFBTSxHQUFHLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxHQUFHLEdBQUcsQ0FBQyxDQUFDO1NBQzdHO1FBQ0QsSUFBSSxXQUFXLEdBQUcsSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsS0FBSyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLFdBQVcsQ0FBQyxHQUFHLENBQUMsV0FBVyxHQUFHLEdBQUcsQ0FBQyxHQUFHLE1BQU0sR0FBRyxHQUFHLENBQUM7UUFDbkgsSUFBSSxHQUFHLEdBQUcsRUFBRSxDQUFDLEdBQUcsRUFBRSxDQUFDLFdBQVcsQ0FBQyxXQUFXLENBQUMsQ0FBQyxXQUFXLENBQUMsTUFBTSxHQUFHLEdBQUcsQ0FBQyxDQUFDO1FBQ3RFLElBQUksUUFBUSxHQUFHLEVBQUUsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxXQUFXLENBQUMsTUFBTSxHQUFHLEdBQUcsQ0FBQyxDQUFDLFdBQVcsQ0FBQyxNQUFNLEdBQUcsR0FBRyxDQUFDLENBQUM7UUFDNUUsbUVBQW1FO1FBQ25FLElBQUksR0FBRyxHQUFHLEVBQUUsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxFQUFFLEVBQUUsR0FBRyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztRQUM1RCxJQUFJLGNBQWMsR0FBRyxJQUFJLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxLQUFLLE1BQU0sQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO1FBQ2hFLEdBQUcsR0FBRyxJQUFJLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxLQUFLLE1BQU0sQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLFVBQVUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLEVBQUUsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLFVBQVUsQ0FBQyxDQUFDLEVBQUUsR0FBRyxDQUFDLElBQUksQ0FBQyxFQUFFLEdBQUcsR0FBRyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsRUFBRSxHQUFHLENBQUMsSUFBSSxDQUFDLEVBQUUsR0FBRyxHQUFHLENBQUMsQ0FBQyxDQUFDO1FBRXBKLElBQUksQ0FBQyxLQUFLLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQyxTQUFTLENBQUMsTUFBTSxDQUFDO2FBQ3BDLElBQUksQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxDQUFDO2FBQ3ZCLEtBQUssRUFBRTthQUNQLE1BQU0sQ0FBQyxNQUFNLENBQUM7YUFDZCxJQUFJLENBQUMsWUFBWSxFQUFFLENBQUMsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQzthQUNuQyxJQUFJLENBQUMsa0JBQWtCLEVBQUUsQ0FBQyxDQUFDLEVBQUUsRUFBRSxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUM7YUFDNUQsSUFBSSxDQUFDLE9BQU8sRUFBRSxDQUFDLENBQUMsRUFBRSxFQUFFO1lBQ2pCLElBQUksQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDLEVBQUUsR0FBRyxFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsS0FBSyxFQUFFLE9BQU8sRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsRUFBRSxJQUFJLEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxLQUFLLEVBQUUsQ0FBQyxDQUFDO1lBQ2xGLE9BQU8sSUFBSSxHQUFHLENBQUMsQ0FBQyxJQUFJLENBQUMsS0FBSyxHQUFHLEtBQUssR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQztZQUNsRCxvRUFBb0U7UUFDeEUsQ0FBQyxDQUFDO2FBQ0QsSUFBSSxDQUFDLElBQUksRUFBRSxDQUFDLENBQUMsRUFBRSxFQUFFO1lBQ2QsT0FBTyxDQUFDLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQztZQUNwQixzQ0FBc0M7UUFDMUMsQ0FBQyxDQUFDO2FBQ0QsSUFBSSxDQUFDLE1BQU0sRUFBRSxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRTtZQUNuQixPQUFPLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxpQ0FBaUM7UUFDMUUsQ0FBQyxDQUFDO1lBQ0Ysa0JBQWtCO2FBQ2pCLEtBQUssQ0FBQyxRQUFRLEVBQUUsSUFBSSxDQUFDLE1BQU0sQ0FBQyxXQUFXLENBQUMsR0FBRyxDQUFDLFdBQVcsQ0FBQzthQUN4RCxLQUFLLENBQUMsY0FBYyxFQUFFLElBQUksQ0FBQyxNQUFNLENBQUMsV0FBVyxDQUFDLEdBQUcsQ0FBQyxXQUFXLElBQUksQ0FBQyxDQUFDLENBQUM7UUFFekUsSUFBSSxXQUFXLEdBQUc7WUFDZCxLQUFLLEVBQUUsR0FBRztZQUNWLEtBQUssRUFBRSxHQUFHO1lBQ1YsVUFBVSxFQUFFLFFBQVE7WUFDcEIsUUFBUSxFQUFFLE1BQU07WUFDaEIsZ0JBQWdCLEVBQUUsY0FBYztTQUVuQyxDQUFDO1FBRUYsSUFBSSxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsU0FBUyxFQUFFO1lBQ3hCLElBQUksQ0FBQyxLQUFLO2lCQUNMLElBQUksQ0FBQyxHQUFHLEVBQUUsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUM7aUJBQ3RCLElBQUksQ0FBQyxLQUFLLEVBQUUsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxNQUFNLENBQUMsQ0FBQyxFQUFFLElBQUksQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO1lBRXBELElBQUksQ0FBQyxhQUFhLENBQUMsV0FBVyxDQUFDLENBQUM7U0FFbkM7YUFBTTtZQUNILElBQUksQ0FBQyxLQUFLLENBQUMsVUFBVSxFQUFFO2lCQUNsQixLQUFLLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLEVBQUU7Z0JBQ1osT0FBTyxDQUFDLEdBQUcsRUFBRSxDQUFDO1lBQ2xCLENBQUMsQ0FBQztpQkFDRCxTQUFTLENBQUMsR0FBRyxFQUFFLENBQUMsQ0FBQyxFQUFFLEVBQUU7Z0JBQ2xCLElBQUksQ0FBQyxHQUFHLEVBQUUsQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDLFVBQVUsRUFBRSxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUM7Z0JBQ2pELE9BQU8sQ0FBQyxDQUFDLEVBQUUsRUFBRTtvQkFDVCxDQUFDLENBQUMsUUFBUSxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztvQkFDbEIsT0FBTyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUM7Z0JBQ2xCLENBQUMsQ0FBQztZQUNOLENBQUMsQ0FBQztpQkFDRCxTQUFTLENBQUMsS0FBSyxFQUFFLENBQUMsQ0FBQyxFQUFFLEVBQUU7Z0JBQ3BCLElBQUksT0FBTyxDQUFDO2dCQUNaLE9BQU8sR0FBRyxPQUFPLElBQUksQ0FBQyxDQUFDO2dCQUN2QixJQUFJLFdBQVcsR0FBRyxFQUFFLENBQUMsV0FBVyxDQUFDLE9BQU8sRUFBRSxDQUFDLENBQUMsQ0FBQztnQkFDN0MsT0FBTyxHQUFHLFdBQVcsQ0FBQyxDQUFDLENBQUMsQ0FBQztnQkFDekIsT0FBTyxDQUFDLENBQUMsRUFBRSxFQUFFO29CQUNULElBQUksRUFBRSxHQUFHLFdBQVcsQ0FBQyxDQUFDLENBQUMsQ0FBQztvQkFDeEIsT0FBTyxNQUFNLENBQUMsRUFBRSxFQUFFLElBQUksQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztnQkFDekMsQ0FBQyxDQUFDO1lBQ04sQ0FBQyxDQUFDO2lCQUNELEVBQUUsQ0FBQyxLQUFLLEVBQUUsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLEVBQUU7Z0JBQ2hCLElBQUksQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxNQUFNLEdBQUcsQ0FBQyxDQUFDLEVBQUU7b0JBQ2pDLFVBQVUsQ0FBQyxHQUFHLEVBQUU7d0JBQ1osSUFBSSxDQUFDLGFBQWEsQ0FBQyxXQUFXLENBQUMsQ0FBQztvQkFDcEMsQ0FBQyxDQUFDLENBQUM7aUJBQ047WUFDTCxDQUFDLENBQUMsQ0FBQztTQUNWO1FBRUQsSUFBSSxDQUFDLEtBQUssQ0FBQyxJQUFJLEVBQUUsQ0FBQyxNQUFNLEVBQUUsQ0FBQztRQUUzQixTQUFTLE1BQU0sQ0FBQyxHQUFHLEVBQUUsVUFBVTtZQUMzQixJQUFJLEdBQUcsR0FBRyxRQUFRLENBQUMsUUFBUSxDQUFDLEdBQUcsQ0FBQyxDQUFDO1lBQ2pDLElBQUksVUFBVSxJQUFJLFVBQVUsS0FBSyxNQUFNLEVBQUU7Z0JBQ3JDLEdBQUcsQ0FBQyxDQUFDLENBQUMsR0FBRyxNQUFNLEdBQUcsQ0FBQyxRQUFRLENBQUMsR0FBRyxDQUFDLEdBQUcsY0FBYyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7YUFDL0Q7aUJBQU07Z0JBQ0gsR0FBRyxDQUFDLENBQUMsQ0FBQyxHQUFHLE1BQU0sR0FBRyxDQUFDLFFBQVEsQ0FBQyxHQUFHLENBQUMsR0FBRyxjQUFjLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQzthQUMvRDtZQUNELE9BQU8sR0FBRyxDQUFDO1FBQ2YsQ0FBQztRQUVELFNBQVMsUUFBUSxDQUFDLEVBQUU7WUFDaEIsT0FBTyxFQUFFLENBQUMsVUFBVSxHQUFHLENBQUMsRUFBRSxDQUFDLFFBQVEsR0FBRyxFQUFFLENBQUMsVUFBVSxDQUFDLEdBQUcsQ0FBQyxDQUFDO1FBQzdELENBQUM7UUFDRCxJQUFJLFdBQVcsR0FBRztZQUNkLGFBQWEsRUFBRSxXQUFXO1lBQzFCLGFBQWEsRUFBRSxNQUFNLEdBQUcsR0FBRztZQUMzQixVQUFVLEVBQUUsSUFBSSxDQUFDLFNBQVM7U0FDN0IsQ0FBQztRQUNGLEtBQUssQ0FBQyxnQkFBZ0IsQ0FBQyxJQUFJLENBQUMsS0FBSyxFQUFFLFdBQVcsQ0FBQyxDQUFDO0lBQ3BELENBQUM7SUFFTyxXQUFXLENBQUMsT0FBMkM7UUFDM0QsMkhBQTJIO1FBQzNILElBQUksV0FBVyxHQUFHLE9BQU8sQ0FBQyxNQUFNLEdBQUcsQ0FBQyxHQUFHLEVBQUUsQ0FBQztRQUMxQyxJQUFJLEtBQUssR0FBRyxFQUFFLENBQUMsV0FBVyxFQUFFO2FBQ3ZCLE1BQU0sQ0FBQyxDQUFDLENBQUMsRUFBRSxFQUFFLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxPQUFPLEVBQUUsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsR0FBRyxDQUFDLENBQUM7YUFDakQsS0FBSyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsR0FBRyxFQUFFLENBQUMsQ0FBQyxDQUFDO1FBQ3hCLElBQUksS0FBSyxHQUFHLEtBQUssQ0FBQyxLQUFLLENBQUMsUUFBUSxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDO1FBQy9DLElBQUksSUFBSSxHQUFHLElBQUksQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO1FBQzNDLGlCQUFpQjtRQUNqQixNQUFNLE9BQU8sR0FBRyxJQUFJLENBQUMsTUFBTSxDQUFDO1FBQzVCLE1BQU0sUUFBUSxHQUFHLENBQUMsV0FBVyxHQUFHLFlBQVksR0FBRyxPQUFPLEdBQUcsVUFBVSxDQUFDLEdBQUcsT0FBTyxDQUFDO1FBRS9FLElBQUksR0FBRyxHQUFHLEVBQUUsQ0FBQyxHQUFHLEVBQUU7YUFDYixXQUFXLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxJQUFJLENBQUMsZUFBZSxDQUFDLENBQUMsRUFBRSxPQUFPLEVBQUUsUUFBUSxDQUFDLENBQUM7YUFDakUsV0FBVyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFLENBQUMsSUFBSSxDQUFDLGVBQWUsQ0FBQyxDQUFDLEVBQUUsT0FBTyxFQUFFLFFBQVEsQ0FBQyxDQUFDO2FBQ2pFLFVBQVUsQ0FBQyxDQUFDLENBQUM7YUFDYixRQUFRLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztRQUVsQyxJQUFJLENBQUMsV0FBVyxHQUFHLElBQUksQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQzthQUNwQyxJQUFJLENBQUMsT0FBTyxFQUFFLHFDQUFxQyxDQUFDO2FBQ3BELFNBQVMsQ0FBQyxHQUFHLENBQUM7YUFDZCxJQUFJLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQzthQUNsQixLQUFLLEVBQUUsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLENBQUM7UUFFekIsSUFBSSxDQUFDLFdBQVcsQ0FBQyxNQUFNLENBQUMsUUFBUSxDQUFDO2FBQzVCLElBQUksQ0FBQyxHQUFHLEVBQUUsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxJQUFJLENBQUMsZUFBZSxDQUFDLENBQUMsRUFBRSxPQUFPLEVBQUUsUUFBUSxDQUFDLEdBQUcsVUFBVSxDQUFDLENBQUM7UUFFbEYsSUFBSSxDQUFDLFdBQVcsQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDO2FBQzFCLElBQUksQ0FBQyxHQUFHLEVBQUUsWUFBWSxDQUFDO2FBQ3ZCLElBQUksQ0FBQyxHQUFHLEVBQUUsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxlQUFlLENBQUMsQ0FBQyxFQUFFLE9BQU8sRUFBRSxRQUFRLENBQUMsR0FBRyxVQUFVLENBQUM7YUFDN0UsS0FBSyxDQUFDLFdBQVcsRUFBRSxNQUFNLENBQUM7YUFDMUIsSUFBSSxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO1FBRXBCLElBQUksQ0FBQyxVQUFVLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDO2FBQ25DLElBQUksQ0FBQyxPQUFPLEVBQUUscUNBQXFDLENBQUM7YUFDcEQsU0FBUyxDQUFDLEdBQUcsQ0FBQzthQUNkLElBQUksQ0FBQyxLQUFLLENBQUM7YUFDWCxLQUFLLEVBQUUsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDO2FBQ25CLElBQUksQ0FBQyxXQUFXLEVBQUUsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxTQUFTLEdBQUcsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxHQUFHLEdBQUcsQ0FBQyxDQUFDO1FBRTlFLElBQUksQ0FBQyxVQUFVLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQzthQUN6QixJQUFJLENBQUMsSUFBSSxFQUFFLFdBQVcsQ0FBQyxDQUFDO1FBRTdCLElBQUksQ0FBQyxVQUFVLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQzthQUN6QixJQUFJLENBQUMsR0FBRyxFQUFFLFdBQVcsR0FBRyxFQUFFLENBQUM7YUFDM0IsS0FBSyxDQUFDLGFBQWEsRUFBRSxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxJQUFJLEVBQUUsSUFBSSxLQUFLLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQzthQUMvRSxLQUFLLENBQUMsV0FBVyxFQUFFLE1BQU0sQ0FBQzthQUMxQixJQUFJLENBQUMsV0FBVyxFQUFFLENBQUMsQ0FBQyxFQUFFLENBQUMsU0FBUyxHQUFHLENBQUMsRUFBRSxHQUFHLElBQUksQ0FBQyxRQUFRLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxHQUFHLEdBQUcsQ0FBQyxXQUFXLEdBQUcsRUFBRSxDQUFDLEdBQUcsS0FBSyxDQUFDO2FBQ3JHLElBQUksQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDO1FBRWxCLFlBQVk7UUFDWixJQUFJLENBQUMsS0FBSyxHQUFHLElBQUksQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQzthQUM5QixTQUFTLENBQUMsTUFBTSxDQUFDO2FBQ2pCLElBQUksQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDO2FBQ2xCLEtBQUssRUFBRSxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUM7YUFDdEIsSUFBSSxDQUFDLE9BQU8sRUFBRSxDQUFDLENBQUMsRUFBRSxFQUFFO1lBQ2pCLE9BQU8sSUFBSSxHQUFHLENBQUMsQ0FBQyxLQUFLLEdBQUcsS0FBSyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUM7UUFDeEMsQ0FBQyxDQUFDO2FBQ0QsS0FBSyxDQUFDLE1BQU0sRUFBRSxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRSxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDO1FBRXRELElBQUksQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLFNBQVMsRUFBRTtZQUN4QixJQUFJLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxHQUFHLEVBQUUsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDO1NBQy9DO2FBQU07WUFDSCxJQUFJLENBQUMsS0FBSyxDQUFDLFVBQVUsRUFBRTtpQkFDbEIsS0FBSyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQyxHQUFHLEdBQUcsQ0FBQztpQkFDeEIsUUFBUSxDQUFDLEdBQUcsQ0FBQztnQkFDZCw2QkFBNkI7aUJBQzVCLFNBQVMsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLEVBQUU7Z0JBQ3JCLElBQUksV0FBVyxHQUFHLEVBQUUsQ0FBQyxXQUFXLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztnQkFDekMsT0FBTyxDQUFDLENBQUMsRUFBRSxDQUFDLEdBQUcsQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUM7WUFDdkMsQ0FBQyxDQUFDLENBQUM7U0FDVjtRQUVELEtBQUssQ0FBQyxnQkFBZ0IsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLENBQUM7SUFDdkMsQ0FBQztJQUVPLFVBQVUsQ0FBQyxPQUEyQjtRQUMxQyx3QkFBd0I7UUFDeEIsSUFBSSxPQUFPLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsTUFBTSxFQUFFLEdBQUcsR0FBRyxDQUFDLENBQUM7UUFDOUMsSUFBSSxRQUFRLEdBQUcsSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsS0FBSyxNQUFNLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxFQUFFLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDO1FBQ3BFLElBQUksV0FBVyxHQUFHLE9BQU8sQ0FBQyxNQUFNLEdBQUcsQ0FBQyxDQUFDO1FBQ3JDLElBQUksV0FBVyxHQUFHLENBQUMsV0FBVyxHQUFHLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQztRQUN4QyxJQUFJLFFBQVEsR0FBRyxXQUFXLEdBQUcsR0FBRyxDQUFDO1FBRWpDLElBQUksR0FBRyxHQUFHLEVBQUUsQ0FBQyxHQUFHLEVBQUU7YUFDYixXQUFXLENBQUMsV0FBVyxDQUFDO2FBQ3hCLFdBQVcsQ0FBQyxXQUFXLENBQUM7YUFDeEIsVUFBVSxDQUFDLENBQUMsQ0FBQzthQUNiLFFBQVEsQ0FBQyxRQUFRLENBQUMsQ0FBQztRQUV4QixJQUFJLE9BQU8sR0FBRyxFQUFFLENBQUMsR0FBRyxFQUFFO2FBQ2pCLFdBQVcsQ0FBQyxXQUFXLENBQUM7YUFDeEIsV0FBVyxDQUFDLFdBQVcsQ0FBQzthQUN4QixVQUFVLENBQUMsQ0FBQyxDQUFDLENBQUM7UUFFbkIsSUFBSSxDQUFDLEtBQUssR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUM7YUFDakMsSUFBSSxDQUFDLEdBQUcsRUFBRSxHQUFHLENBQUM7YUFDZCxJQUFJLENBQUMsV0FBVyxFQUFFLGFBQWEsQ0FBQzthQUNoQyxJQUFJLENBQUMsY0FBYyxFQUFFLENBQUMsQ0FBQzthQUN2QixJQUFJLENBQUMsUUFBUSxFQUFFLFNBQVMsQ0FBQzthQUN6QixLQUFLLENBQUMsTUFBTSxFQUFFLFNBQVMsQ0FBQyxDQUFDO1FBRzlCLElBQUksQ0FBQyxRQUFRLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDO1lBQ3JDLGlEQUFpRDthQUNoRCxLQUFLLENBQUMsRUFBRSxRQUFRLEVBQUUsQ0FBQyxFQUFFLENBQUM7YUFDdEIsSUFBSSxDQUFDLEdBQUcsRUFBRSxPQUFPLENBQUM7YUFDbEIsSUFBSSxDQUFDLFdBQVcsRUFBRSxhQUFhLENBQUMsQ0FBQztRQUd0QyxJQUFJLENBQUMsZUFBZSxHQUFHLElBQUksQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQzthQUMzQyxLQUFLLENBQUMsQ0FBQyxDQUFDO2FBQ1IsSUFBSSxDQUFDLFVBQVMsQ0FBQztZQUNaLE9BQU8sQ0FBQyxDQUFDO1FBQ2IsQ0FBQyxDQUFDO2FBQ0QsSUFBSSxDQUFDLE9BQU8sRUFBRSx1QkFBdUIsQ0FBQzthQUN0QyxJQUFJLENBQUMsYUFBYSxFQUFFLFFBQVEsQ0FBQzthQUM3QixJQUFJLENBQUMsSUFBSSxFQUFFLElBQUksQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLEtBQUssTUFBTSxDQUFDLENBQUMsQ0FBQyxRQUFRLEdBQUcsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7YUFDOUQsS0FBSyxDQUFDLE1BQU0sRUFBRSxFQUFFLENBQUMsR0FBRyxDQUFDLFNBQVMsQ0FBQyxDQUFDO2FBQ2hDLEtBQUssQ0FBQyxXQUFXLEVBQUUsUUFBUSxHQUFHLElBQUksQ0FBQyxDQUFDO1FBRXpDLElBQUksQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLFNBQVMsRUFBRTtZQUN4QixJQUFJLENBQUMsUUFBUTtpQkFDUixJQUFJLENBQUMsR0FBRyxFQUFFLENBQUMsQ0FBQyxFQUFFLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDO2lCQUMxQixLQUFLLENBQUMsTUFBTSxFQUFFLEVBQUUsQ0FBQyxHQUFHLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQztZQUN0QyxPQUFPO1NBQ1Y7UUFFRCxJQUFJLFFBQVEsR0FBRyxVQUFTLFVBQVUsRUFBRSxRQUFRLEVBQUUsSUFBSTtZQUM5QyxVQUFVLENBQUMsU0FBUyxDQUFDLEdBQUcsRUFBRSxDQUFDLENBQUMsRUFBRSxFQUFFO2dCQUM1QixJQUFJLFdBQVcsR0FBRyxFQUFFLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQyxRQUFRLEVBQUUsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxRQUFRLEdBQUcsR0FBRyxDQUFDLENBQUMsQ0FBQztnQkFDOUUsSUFBSSxnQkFBZ0IsR0FBRyxFQUFFLENBQUMsV0FBVyxDQUFDLENBQUMsRUFBRSxRQUFRLENBQUMsQ0FBQztnQkFFbkQsT0FBTyxDQUFDLENBQUMsRUFBRSxFQUFFO29CQUNULENBQUMsQ0FBQyxRQUFRLEdBQUcsV0FBVyxDQUFDLENBQUMsQ0FBQyxDQUFDO29CQUM1QixJQUFJLENBQUMsZUFBZSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLGdCQUFnQixDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsR0FBRyxDQUFDLENBQUM7b0JBQ2pFLE9BQU8sT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDO2dCQUN0QixDQUFDLENBQUM7WUFDTixDQUFDLENBQUMsQ0FBQztRQUNQLENBQUMsQ0FBQztRQUVGLElBQUksQ0FBQyxRQUFRLENBQUMsVUFBVSxFQUFFO2FBQ3JCLFFBQVEsQ0FBQyxHQUFHLENBQUM7YUFDYixJQUFJLENBQUMsRUFBRSxDQUFDLFdBQVcsQ0FBQzthQUNwQixJQUFJLENBQUMsUUFBUSxFQUFFLE9BQU8sRUFBRSxJQUFJLENBQUM7YUFDN0IsS0FBSyxDQUFDLE1BQU0sRUFBRSxFQUFFLENBQUMsR0FBRyxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUM7SUFDMUMsQ0FBQztJQUVPLGFBQWEsQ0FBQyxPQUFZO1FBQzlCLElBQUksQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsT0FBTztZQUFFLE9BQU87UUFDOUMsSUFBSSxJQUFJLENBQUMsYUFBYSxLQUFLLEtBQUs7WUFBRSxPQUFPO1FBQ3pDLElBQUksSUFBSSxDQUFDLFNBQVMsQ0FBQyxNQUFNLEtBQUssQ0FBQztZQUFFLE9BQU87UUFDeEMsSUFBSSxJQUFJLEdBQUcsS0FBSyxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsZ0JBQWdCLENBQUMsR0FBRyxHQUFHLElBQUksQ0FBQyxNQUFNLENBQUMsRUFBRSxHQUFHLCtCQUErQixDQUFDLENBQUMsQ0FBQztRQUN6RyxJQUFJLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLFVBQVUsQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztRQUUvQyxJQUFJLEdBQUcsR0FBRyxDQUFDLENBQUMsRUFBRSxFQUFFLEdBQUcsT0FBTyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztRQUV0QyxTQUFTLFFBQVEsQ0FBQyxFQUFFO1lBQ2hCLE9BQU8sRUFBRSxDQUFDLFVBQVUsR0FBRyxDQUFDLEVBQUUsQ0FBQyxRQUFRLEdBQUcsRUFBRSxDQUFDLFVBQVUsQ0FBQyxHQUFHLENBQUMsQ0FBQztRQUM3RCxDQUFDO1FBRUQsSUFBSSxNQUFNLEdBQUcsSUFBSSxDQUFDLFlBQVksQ0FBQyxJQUFJLEVBQUUsQ0FBQyxxQkFBcUIsRUFBRSxDQUFDLE1BQU0sQ0FBQztRQUNyRSxJQUFJLEtBQUssR0FBRyxJQUFJLENBQUMsWUFBWSxDQUFDLElBQUksRUFBRSxDQUFDLHFCQUFxQixFQUFFLENBQUMsS0FBSyxDQUFDO1FBQ25FLE1BQU0sR0FBRyxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLElBQUksSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsS0FBSyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sR0FBRyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sR0FBRyxDQUFDLEdBQUcsQ0FBQyxDQUFDO1FBQ3ZHLEtBQUssSUFBSSxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLEVBQUUsQ0FBQyxFQUFFLEVBQUU7WUFDbkQsSUFBSSxJQUFJLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxJQUFJLElBQUksQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxLQUFLLFNBQVMsRUFBRTtnQkFDekQsSUFBSSxVQUFVLEdBQUcsUUFBUSxDQUFDLGFBQWEsQ0FBQyxHQUFHLEdBQUcsSUFBSSxDQUFDLE1BQU0sQ0FBQyxFQUFFLEdBQUcsSUFBSSxHQUFHLElBQUksQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsWUFBWSxDQUFDLEtBQUssQ0FBQyxDQUFDO2dCQUNoSCxJQUFJLElBQUksQ0FBQyxTQUFTLENBQUMsTUFBTSxLQUFLLENBQUMsSUFBSSxRQUFRLENBQUMsYUFBYSxDQUFDLEdBQUcsR0FBRyxJQUFJLENBQUMsTUFBTSxDQUFDLEVBQUUsR0FBRyxJQUFJLEdBQUcsSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsS0FBSyxJQUFJLElBQUksVUFBVSxLQUFLLElBQUksRUFBRTtvQkFDM0ksSUFBSSxLQUFLLEdBQUc7d0JBQ1IsSUFBSSxFQUFFLElBQUksQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRTt3QkFDMUIsT0FBTyxFQUFFLElBQUksQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSztxQkFDbkMsQ0FBQztvQkFDRixJQUFJLE1BQU0sR0FBVyxRQUFRLENBQUMsVUFBVSxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLEtBQUssR0FBRyxDQUFDLENBQUM7b0JBQ3BFLElBQUksTUFBTSxHQUFXLFFBQVEsQ0FBQyxVQUFVLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsTUFBTSxDQUFDO29CQUNqRSxJQUFJLGFBQWEsR0FBVyxRQUFRLENBQUMsVUFBVSxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO29CQUMvRCxJQUFJLFlBQVksR0FBWSxJQUFJLENBQUMsS0FBSyxLQUFLLEtBQUssQ0FBQyxDQUFDLENBQUMsYUFBYSxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsYUFBYSxHQUFHLENBQUMsQ0FBQztvQkFDekYsSUFBSSxpQkFBaUIsR0FBVyxZQUFZLENBQUMsQ0FBQyxDQUFDLFVBQVUsQ0FBQyxDQUFDLENBQUMsWUFBWSxDQUFDO29CQUN6RSxJQUFJLGNBQWMsR0FBRyxHQUFHLEdBQUcsSUFBSSxDQUFDLE1BQU0sQ0FBQyxFQUFFLEdBQUcsNEJBQTRCLEdBQUcsSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsS0FBSyxHQUFHLEtBQUssQ0FBQyxFQUFFLENBQUM7b0JBQ2xILElBQUksUUFBUSxDQUFDLGFBQWEsQ0FBQyxjQUFjLENBQUMsSUFBSSxJQUFJLEVBQUU7d0JBQ2hELEtBQUssQ0FBQyxRQUFRLENBQUMsS0FBSyxFQUFFLElBQUksQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLE1BQU0sRUFBRSxNQUFNLENBQUMsQ0FBQyxLQUFLLENBQUMsWUFBWSxFQUFFLFNBQVMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxPQUFPLEVBQUUsS0FBSyxDQUFDLENBQUMsS0FBSyxDQUFDLGlCQUFpQixFQUFFLGlCQUFpQixDQUFDLENBQUM7cUJBQy9KO2lCQUNKO2FBQ0o7U0FDSjtRQUVELElBQUksQ0FBQyxTQUFTLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDO2FBQ2xDLElBQUksQ0FBQyxPQUFPLEVBQUUsa0JBQWtCLENBQUM7YUFDakMsU0FBUyxDQUFDLFVBQVUsQ0FBQzthQUNyQixJQUFJLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLEVBQUUsR0FBRyxDQUFDO2FBQ3BDLEtBQUssRUFBRTthQUNQLE1BQU0sQ0FBQyxVQUFVLENBQUM7YUFDbEIsS0FBSyxDQUFDLFFBQVEsRUFBRSxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRTtZQUN0QixPQUFPLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsQ0FBQyxLQUFLLENBQUM7UUFDeEMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLFFBQVEsRUFBRSxDQUFDLENBQUMsRUFBRSxFQUFFO1lBQ3BCLE9BQU8sTUFBTSxDQUFDLENBQUMsRUFBRSxJQUFJLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7UUFDeEMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLE1BQU0sRUFBRSxNQUFNLENBQUMsQ0FBQztRQUU3QixnQ0FBZ0M7UUFDaEMsNkNBQTZDO1FBQzdDLCtDQUErQztRQUMvQyxVQUFVO1FBQ1YsY0FBYztRQUNkLElBQUk7UUFFSiw2Q0FBNkM7UUFDN0Msb0NBQW9DO1FBQ3BDLDhDQUE4QztRQUM5Qyw4REFBOEQ7UUFDOUQsMENBQTBDO1FBQzFDLDBCQUEwQjtRQUMxQix1Q0FBdUM7UUFDdkMsb0RBQW9EO1FBQ3BELGFBQWE7UUFDYixVQUFVO1FBRVYsU0FBUyxNQUFNLENBQUMsR0FBRyxFQUFFLFVBQVU7WUFDM0IsSUFBSSxHQUFHLEdBQUcsT0FBTyxDQUFDLFFBQVEsQ0FBQyxRQUFRLENBQUMsR0FBRyxDQUFDLENBQUM7WUFDekMsSUFBSSxVQUFVLElBQUksVUFBVSxLQUFLLE1BQU0sRUFBRTtnQkFDckMsR0FBRyxDQUFDLENBQUMsQ0FBQyxHQUFHLE9BQU8sQ0FBQyxNQUFNLEdBQUcsSUFBSSxHQUFHLENBQUMsUUFBUSxDQUFDLEdBQUcsQ0FBQyxHQUFHLE9BQU8sQ0FBQyxjQUFjLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQzthQUN0RjtpQkFBTTtnQkFDSCxHQUFHLENBQUMsQ0FBQyxDQUFDLEdBQUcsT0FBTyxDQUFDLE1BQU0sR0FBRyxJQUFJLEdBQUcsQ0FBQyxRQUFRLENBQUMsR0FBRyxDQUFDLEdBQUcsT0FBTyxDQUFDLGNBQWMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO2FBQ3RGO1lBQ0QsT0FBTyxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsUUFBUSxDQUFDLEdBQUcsQ0FBQyxFQUFFLE9BQU8sQ0FBQyxRQUFRLENBQUMsUUFBUSxDQUFDLEdBQUcsQ0FBQyxFQUFFLEdBQUcsQ0FBQyxDQUFDO1FBQzVFLENBQUM7SUFDTCxDQUFDO0lBR08sZUFBZSxDQUFDLE1BQWMsRUFBRSxRQUFnQixFQUFFLFNBQWlCO1FBQ3ZFLE9BQU8sWUFBWSxHQUFHLENBQUMsUUFBUSxHQUFHLENBQUMsTUFBTSxHQUFHLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxTQUFTLEdBQUcsVUFBVSxDQUFDLENBQUM7SUFDL0UsQ0FBQztJQUVPLGVBQWUsQ0FBQyxNQUFjLEVBQUUsUUFBZ0IsRUFBRSxTQUFpQjtRQUN2RSxPQUFPLElBQUksQ0FBQyxlQUFlLENBQUMsTUFBTSxFQUFFLFFBQVEsRUFBRSxTQUFTLENBQUMsR0FBRyxTQUFTLENBQUM7SUFDekUsQ0FBQztJQUVPLFFBQVEsQ0FBQyxNQUFjO1FBQzNCLE9BQU8sTUFBTSxHQUFHLEdBQUcsR0FBRyxFQUFFLENBQUM7SUFDN0IsQ0FBQztJQUVPLFNBQVMsQ0FBQyxLQUFVLEVBQUUsR0FBUSxFQUFFLFlBQWlCLEVBQUUsWUFBaUI7UUFDeEUsUUFBUSxHQUFHLEVBQUU7WUFDVCxLQUFLLEtBQUs7Z0JBQ04sS0FBSyxDQUFDLFVBQVUsRUFBRTtxQkFDYixRQUFRLENBQUMsR0FBRyxDQUFDO29CQUNkLGtCQUFrQjtxQkFDakIsSUFBSSxDQUFDLEdBQUcsRUFBRSxFQUFFLENBQUMsR0FBRyxFQUFFO3FCQUNkLFdBQVcsQ0FBQyxZQUFZLENBQUM7cUJBQ3pCLFdBQVcsQ0FBQyxZQUFZLENBQUMsQ0FDN0IsQ0FBQyxJQUFJLENBQUMsUUFBUSxFQUFFLE1BQU0sQ0FBQyxDQUFDO2dCQUM3QixNQUFNO1lBRVYsS0FBSyxJQUFJO2dCQUNMLEtBQUssQ0FBQyxVQUFVLEVBQUU7cUJBQ2IsSUFBSSxDQUFDLEdBQUcsRUFBRSxFQUFFLENBQUMsR0FBRyxFQUFFO3FCQUNkLFdBQVcsQ0FBQyxZQUFZLENBQUM7cUJBQ3pCLFdBQVcsQ0FBQyxZQUFZLEdBQUcsR0FBRyxDQUFDLENBQ25DLENBQUMsSUFBSSxDQUFDLFFBQVEsRUFBRSxPQUFPLENBQUMsQ0FBQyxJQUFJLENBQUMsY0FBYyxFQUFFLENBQUMsQ0FBQyxDQUFDO2dCQUN0RCxNQUFNO1NBQ2I7SUFDTCxDQUFDOzs7WUE5Z0JKLFNBQVMsU0FBQztnQkFDUCxRQUFRLEVBQUUsY0FBYztnQkFDeEIsUUFBUSxFQUFFLEVBQUU7Z0JBQ1osYUFBYSxFQUFFLGlCQUFpQixDQUFDLElBQUk7Z0JBQ3JDLFNBQVMsRUFBRSxDQUFDLFdBQVcsRUFBRSxZQUFZLENBQUM7Z0JBQ3RDLElBQUksRUFBRTtvQkFDRixPQUFPLEVBQUUsZUFBZTtpQkFDM0I7YUFDSjs7O1lBbkJRLFdBQVc7WUFDWCxZQUFZOzs7bUJBa0NoQixLQUFLO3dCQUNMLEtBQUssU0FBQyxRQUFRO3FCQUNkLEtBQUs7a0JBQ0wsS0FBSzs4QkFDTCxLQUFLOzJCQUNMLE1BQU07eUJBQ04sTUFBTSIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7XHJcbiAgICBDb21wb25lbnQsXHJcbiAgICBWaWV3RW5jYXBzdWxhdGlvbixcclxuICAgIElucHV0LFxyXG4gICAgT3V0cHV0LFxyXG4gICAgRXZlbnRFbWl0dGVyLFxyXG4gICAgT25Jbml0LFxyXG4gICAgT25DaGFuZ2VzLFxyXG4gICAgU2ltcGxlQ2hhbmdlcyxcclxuICAgIE9uRGVzdHJveVxyXG59IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xyXG5pbXBvcnQgeyBLZENoYXJ0QmFzZUNsYXNzIH0gZnJvbSAnLi4va2QtYW5ndWxhci1jaGFydC1iYXNlLWNsYXNzJztcclxuaW1wb3J0IHsgS2RDaGFydHNTdmMgfSBmcm9tICcuLi9rZC1hbmd1bGFyLWNoYXJ0cy1zdmMnO1xyXG5pbXBvcnQgeyBLZERvbUVsZW1TdmMgfSBmcm9tICcuLi8uLi9rZC1jb21tb24vaW5kZXgnO1xyXG5pbXBvcnQgeyBJTGVnZW5kRGF0YSwgSUNoYXJ0Q29uZmlnIH0gZnJvbSAnLi4va2QtYW5ndWxhci1jaGFydHMtaW50ZXJmYWNlJztcclxuaW1wb3J0ICogYXMgZDMgZnJvbSAnZDMnO1xyXG5cclxuY29uc3QgUEkgPSBNYXRoLlBJLFxyXG4gICAgYXJjTWluUmFkaXVzID0gMTAsXHJcbiAgICBhcmNQYWRkaW5nID0gMTAsXHJcbiAgICBsYWJlbFBhZGRpbmcgPSAtNSxcclxuICAgIG51bVRpY2tzID0gMTA7XHJcblxyXG5AQ29tcG9uZW50KHtcclxuICAgIHNlbGVjdG9yOiAna2QtcGllLWNoYXJ0JyxcclxuICAgIHRlbXBsYXRlOiAnJyxcclxuICAgIGVuY2Fwc3VsYXRpb246IFZpZXdFbmNhcHN1bGF0aW9uLk5vbmUsXHJcbiAgICBwcm92aWRlcnM6IFtLZENoYXJ0c1N2YywgS2REb21FbGVtU3ZjXSxcclxuICAgIGhvc3Q6IHtcclxuICAgICAgICAnY2xhc3MnOiAna2R4LXBpZS1jaGFydCcsXHJcbiAgICB9XHJcbn0pXHJcblxyXG5leHBvcnQgY2xhc3MgS2RQaWVDaGFydCBleHRlbmRzIEtkQ2hhcnRCYXNlQ2xhc3MgaW1wbGVtZW50cyBPbkluaXQsIE9uQ2hhbmdlcywgT25EZXN0cm95IHtcclxuICAgIHB1YmxpYyBwaWVEYXRhOiBBcnJheTxhbnk+ID0gW107XHJcbiAgICBwdWJsaWMgbGF5b3V0O1xyXG4gICAgcHJpdmF0ZSBfcGF0aDtcclxuICAgIHByaXZhdGUgX3JhZGlhbEF4aXM7XHJcbiAgICBwcml2YXRlIF9heGlhbEF4aXM7XHJcbiAgICBwcml2YXRlIF90ZXh0O1xyXG4gICAgcHJpdmF0ZSBfcG9seWxpbmU7XHJcbiAgICBwcml2YXRlIF9wb2ludGVyO1xyXG4gICAgcHJpdmF0ZSBfaW50ZXJ2YWw7XHJcbiAgICBwcml2YXRlIF9wZXJjZW50YWdlVGV4dDtcclxuICAgIHByaXZhdGUgX3Bvc0FycmF5ID0gW107XHJcblxyXG5cclxuICAgIEBJbnB1dCgpIGRhdGE6IGFueTtcclxuICAgIEBJbnB1dCgnY29uZmlnJykgcGllQ29uZmlnOiBJQ2hhcnRDb25maWc7XHJcbiAgICBASW5wdXQoKSBsZWdlbmQ6IHsgW2tleTogc3RyaW5nXTogSUxlZ2VuZERhdGEgfTtcclxuICAgIEBJbnB1dCgpIGFwaTogYW55O1xyXG4gICAgQElucHV0KCkgc2VyaWVzVGhyZXNob2xkOiBudW1iZXI7XHJcbiAgICBAT3V0cHV0KCkgb3V0cHV0TGVnZW5kOiBFdmVudEVtaXR0ZXI8eyBba2V5OiBzdHJpbmddOiBJTGVnZW5kRGF0YSB9PiA9IG5ldyBFdmVudEVtaXR0ZXIodHJ1ZSk7XHJcbiAgICBAT3V0cHV0KCkgb3V0cHV0RGF0YTogRXZlbnRFbWl0dGVyPGFueT4gPSBuZXcgRXZlbnRFbWl0dGVyKHRydWUpO1xyXG5cclxuICAgIGNvbnN0cnVjdG9yKHB1YmxpYyBfY2hhcnRTdmM6IEtkQ2hhcnRzU3ZjLCBwdWJsaWMgX2RvbVN2YzogS2REb21FbGVtU3ZjKSB7XHJcbiAgICAgICAgc3VwZXIoX2NoYXJ0U3ZjLCBfZG9tU3ZjKTtcclxuICAgIH1cclxuXHJcbiAgICBuZ09uSW5pdCgpOiB2b2lkIHtcclxuICAgICAgICB0aGlzLmNvbmZpZyA9IE9iamVjdC5hc3NpZ24oe30sIHRoaXMucGllQ29uZmlnKTtcclxuICAgICAgICB0aGlzLl9zZXREYXRhKCk7XHJcbiAgICAgICAgc3VwZXIuY2hhcnRUaW1lb3V0KCgpID0+IHRoaXMuX3NldENoYXJ0KCkpO1xyXG5cclxuICAgICAgICB0aGlzLmFwaS5sZWdlbmRDbGljayA9IChfZGF0YTogYW55LCBsZWdlbmREYXRhPzogYW55KSA9PiB7XHJcbiAgICAgICAgICAgIHRoaXMucGllRGF0YSA9IFtdO1xyXG4gICAgICAgICAgICBpZiAodGhpcy5kYXRhTGFiZWxDb250YWluZXIpIHRoaXMuZGF0YUxhYmVsQ29udGFpbmVyLnNlbGVjdEFsbCgnKicpLnJlbW92ZSgpO1xyXG4gICAgICAgICAgICAvLyBpZiAoX2NvbmZpZykgdGhpcy5jb25maWcgPSBfY29uZmlnO1xyXG4gICAgICAgICAgICB0aGlzLmRhdGEgPSBfZGF0YTtcclxuICAgICAgICAgICAgaWYgKGxlZ2VuZERhdGEpIHtcclxuICAgICAgICAgICAgICAgIC8vIGxldCBuZXdDb2xvciA9IFtdO1xyXG4gICAgICAgICAgICAgICAgdGhpcy5waWVEYXRhID0gdGhpcy5kYXRhLmRhdGE7XHJcbiAgICAgICAgICAgICAgICAvLyB0aGlzLnBpZURhdGEgPSBPYmplY3Qua2V5cyhfY29uZmlnLmxlZ2VuZERhdGEpLm1hcChrZXkgPT4gX2NvbmZpZy5sZWdlbmREYXRhW2tleV0pLm1hcCgodmFsdWUpID0+ICh2YWx1ZSkpO1xyXG4gICAgICAgICAgICAgICAgLy8gZm9yIChsZXQgaSA9IDA7IGkgPCB0aGlzLnBpZURhdGEubGVuZ3RoOyBpKyspIHtcclxuICAgICAgICAgICAgICAgIC8vICAgICBuZXdDb2xvci5wdXNoKHRoaXMucGllRGF0YVtpXS5jb2xvcik7XHJcbiAgICAgICAgICAgICAgICAvLyB9XHJcbiAgICAgICAgICAgICAgICAvLyB0aGlzLnBpZUNvbmZpZ1sncGllQ29sb3InXSA9IG5ld0NvbG9yO1xyXG5cclxuICAgICAgICAgICAgICAgIHRoaXMuX3JlZHJhd0NoYXJ0KCk7XHJcblxyXG4gICAgICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgLy8gZmFpbC1zYWZlIGluIGNhc2UgZGF0YSBtYXNzYWdlIGhhdmVuJ3QgY3JlYXRlIGxlZ2VuZERhdGFcclxuICAgICAgICAgICAgICAgIHRoaXMuX3NldERhdGEoKTtcclxuICAgICAgICAgICAgICAgIHRoaXMuX3NldENoYXJ0KCk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9O1xyXG4gICAgICAgIHRoaXMuYXBpLnJlZHJhdyA9ICgpID0+IHtcclxuICAgICAgICAgICAgdGhpcy5fcmVkcmF3Q2hhcnQoKTtcclxuICAgICAgICB9O1xyXG4gICAgfVxyXG5cclxuICAgIG5nT25DaGFuZ2VzKF9zaW1wbGVDaGFuZ2VzOiBTaW1wbGVDaGFuZ2VzKTogdm9pZCB7XHJcbiAgICAgICAgaWYgKF9zaW1wbGVDaGFuZ2VzLmhhc093blByb3BlcnR5KCdkYXRhJykgJiYgIV9zaW1wbGVDaGFuZ2VzWydkYXRhJ10uZmlyc3RDaGFuZ2UpIHtcclxuICAgICAgICAgICAgdGhpcy5kYXRhID0gX3NpbXBsZUNoYW5nZXMuZGF0YS5jdXJyZW50VmFsdWU7XHJcbiAgICAgICAgICAgIHRoaXMuX3JlZHJhd0NoYXJ0KCdkYXRhJyk7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGlmIChfc2ltcGxlQ2hhbmdlcy5oYXNPd25Qcm9wZXJ0eSgncGllQ29uZmlnJykgJiYgIV9zaW1wbGVDaGFuZ2VzWydwaWVDb25maWcnXS5maXJzdENoYW5nZSkge1xyXG4gICAgICAgICAgICB0aGlzLnBpZUNvbmZpZyA9IF9zaW1wbGVDaGFuZ2VzLnBpZUNvbmZpZy5jdXJyZW50VmFsdWU7XHJcbiAgICAgICAgICAgIHRoaXMuX3JlZHJhd0NoYXJ0KCdjb25maWcnKTtcclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgbmdPbkRlc3Ryb3koKTogdm9pZCB7XHJcbiAgICAgICAgdGhpcy5fcmVzZXRDaGFydCgpO1xyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX3JlZHJhd0NoYXJ0KF9jaGFuZ2VzPzogJ2RhdGEnIHwgJ2NvbmZpZycpIHtcclxuICAgICAgICB0aGlzLl9yZXNldENoYXJ0KCk7XHJcblxyXG4gICAgICAgIGlmIChfY2hhbmdlcyA9PT0gJ2RhdGEnKSB7XHJcbiAgICAgICAgICAgIHRoaXMucGllRGF0YSA9IFtdO1xyXG4gICAgICAgICAgICB0aGlzLl9zZXREYXRhKCk7XHJcbiAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgdGhpcy5waWVDb25maWdbJ2xlZ2VuZERhdGEnXSA9IHRoaXMuY29uZmlnWydsZWdlbmREYXRhJ107XHJcbiAgICAgICAgICAgIHRoaXMuY29uZmlnID0gT2JqZWN0LmFzc2lnbih7fSwgdGhpcy5waWVDb25maWcpO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgc3VwZXIuY2hhcnRUaW1lb3V0KCgpID0+IHRoaXMuX3NldENoYXJ0KCkpO1xyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX3NldENoYXJ0KCk6IHZvaWQge1xyXG4gICAgICAgIHN1cGVyLnNldFN2ZygpO1xyXG4gICAgICAgIHN1cGVyLnNldFN2Z0RpbWVuc2lvbigneCcpO1xyXG4gICAgICAgIHN1cGVyLnNldFN2Z0RpbWVuc2lvbigneScpO1xyXG5cclxuICAgICAgICB0aGlzLmNoYXJ0VHlwZSA9IHRoaXMuZGF0YS5sYXlvdXQuc3BsaXQoJy0nKTtcclxuICAgICAgICB0aGlzLmNoYXJ0Q2F0ZWdvcnkgPSB0aGlzLmRhdGEudHlwZTtcclxuICAgICAgICAvLyBtb3ZpbmcgcGllIGNoYXJ0IHRvIGNlbnRlciBvZiBzdmdcclxuICAgICAgICBsZXQgaGVpZ2h0ID0gdGhpcy5zdmdDb250YWluZXIubm9kZSgpLmdldEJvdW5kaW5nQ2xpZW50UmVjdCgpLmhlaWdodDtcclxuICAgICAgICBsZXQgd2lkdGggPSB0aGlzLnN2Z0NvbnRhaW5lci5ub2RlKCkuZ2V0Qm91bmRpbmdDbGllbnRSZWN0KCkud2lkdGg7XHJcbiAgICAgICAgdGhpcy53aWR0aCA9IHdpZHRoO1xyXG4gICAgICAgIHRoaXMuZ3JhcGguYXR0cigndHJhbnNmb3JtJywgJ3RyYW5zbGF0ZSgnICsgKHdpZHRoIC8gMikgKyAnLCcgKyAoaGVpZ2h0IC8gMikgKyAnKScpO1xyXG5cclxuICAgICAgICAvLyBsZXQgY29sb3IgPSB0aGlzLnBpZUNvbmZpZ1sncGllQ29sb3InXSA/IGQzLnNjYWxlT3JkaW5hbCgpLnJhbmdlKHRoaXMucGllQ29uZmlnWydwaWVDb2xvciddKSA6IGQzLnNjYWxlT3JkaW5hbCgpLnJhbmdlKHRoaXMuY29uZmlnLmNvbG9ycyk7XHJcbiAgICAgICAgLy8gbGV0IGNoYXJ0UGFyYW1zID0ge1xyXG4gICAgICAgIC8vICAgICAnY29sb3InOiBjb2xvclxyXG4gICAgICAgIC8vIH07XHJcbiAgICAgICAgdGhpcy5kYXRhTGFiZWxDb250YWluZXIuc3R5bGUoJ3RvcCcsIDApO1xyXG4gICAgICAgIHRoaXMuZGF0YUxhYmVsQ29udGFpbmVyLnN0eWxlKCdsZWZ0JywgMCk7XHJcblxyXG4gICAgICAgIGlmICh0aGlzLmNoYXJ0VHlwZVswXSA9PT0gJ3JhZGlhbCcpIHtcclxuICAgICAgICAgICAgdGhpcy5fZHJhd1JhZGlhbCh7IGhlaWdodDogaGVpZ2h0IH0pO1xyXG4gICAgICAgIH0gZWxzZSBpZiAodGhpcy5jaGFydFR5cGVbMF0gPT09ICdnYXVnZScpIHtcclxuICAgICAgICAgICAgdGhpcy5fZHJhd0dhdWdlKHsgaGVpZ2h0OiBoZWlnaHQgfSk7XHJcbiAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgdGhpcy5fZHJhd1BpZURvbnV0KHsgaGVpZ2h0OiBoZWlnaHQsIHdpZHRoOiB3aWR0aCB9KTtcclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgLyoqXHJcbiAgICAgKiB3aGVuIHJlY2VpdmluZyBkYXRhIGFuZCBsZWdlbmQsIHRoZSBzdHJ1Y3R1cmUgaXMgY3VzdG9taXNlIHRvIGZvciBsaW5lL2FyZWEgYW5kIGJhci4gcGllIG5lZWRzIHRvIHJlY2FsY3VsYXRlIHRoZSBsZWdlbmRcclxuICAgICAqIF9zZXREYXRhIGdlbmVyYXRlIHBpZURhdGEgYW5kIG5ldyBsZWdlbmQgZnJvbSB0aGUgcHJldmlvdXMgbGVnZW5kXHJcbiAgICAgKlxyXG4gICAgICogTm90ZTogdGhpcy5waWVEYXRhIGlzIHVzZWQgZm9yIHJlbmRlcmluZy5cclxuICAgICAqIE5vdGUyOiBkYXRhLnBpZURhdGEgaXQgd2lsbCBub3QgYmUgY2hhbmdlZCBvbkxlZ2VuZENsaWNrXHJcbiAgICAgKiAob25MZWdlbmRDbGljayBhZmZlY3RzIGRhdGEuZGF0YSB3aGljaCBpcyBzdG9yZWQgaW50byB0aGlzLnBpZURhdGEgdmlhIGFwaSlcclxuICAgICAqL1xyXG4gICAgcHJpdmF0ZSBfc2V0RGF0YSgpOiB2b2lkIHtcclxuICAgICAgICBpZiAoIXRoaXMuY29uZmlnLnNraXBNYXNzYWdlKSB7XHJcbiAgICAgICAgICAgIGlmICh0aGlzLmRhdGFbJ3BpZWRhdGEnXSkge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5waWVEYXRhID0gdGhpcy5kYXRhLnBpZWRhdGE7XHJcbiAgICAgICAgICAgICAgICAvLyBzYXZpbmcgbWFzc2FnZWQgcGllZGF0YSB0byB0aGlzLmRhdGEgZm9yIGV4cG9ydFxyXG4gICAgICAgICAgICAgICAgdGhpcy5kYXRhLmRhdGEgPSB0aGlzLmRhdGEucGllZGF0YTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgIC8vIHdoZW4gc2tpcCBtYXNzYWdlLCBubyBnZW5lcmF0aW9uIG9mIHBpZURhdGEgbmVlZGVkLlxyXG4gICAgICAgICAgICB0aGlzLnBpZURhdGEgPSB0aGlzLmRhdGEuZGF0YTtcclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfcmVzZXRDaGFydCgpOiB2b2lkIHtcclxuICAgICAgICBpZiAodHlwZW9mIHRoaXMuX3BhdGggIT09ICd1bmRlZmluZWQnKSB0aGlzLl9wYXRoLnJlbW92ZSgpO1xyXG4gICAgICAgIGlmICh0eXBlb2YgdGhpcy5fcmFkaWFsQXhpcyAhPT0gJ3VuZGVmaW5lZCcpIHRoaXMuX3JhZGlhbEF4aXMucmVtb3ZlKCk7XHJcbiAgICAgICAgaWYgKHR5cGVvZiB0aGlzLl9heGlhbEF4aXMgIT09ICd1bmRlZmluZWQnKSB0aGlzLl9heGlhbEF4aXMucmVtb3ZlKCk7XHJcbiAgICAgICAgaWYgKHR5cGVvZiB0aGlzLl90ZXh0ICE9PSAndW5kZWZpbmVkJykgdGhpcy5fdGV4dC5yZW1vdmUoKTtcclxuICAgICAgICBpZiAodHlwZW9mIHRoaXMuX3BvbHlsaW5lICE9PSAndW5kZWZpbmVkJykgdGhpcy5fcG9seWxpbmUucmVtb3ZlKCk7XHJcbiAgICAgICAgaWYgKHR5cGVvZiB0aGlzLl9wb2ludGVyICE9PSAndW5kZWZpbmVkJykgdGhpcy5fcG9pbnRlci5yZW1vdmUoKTtcclxuICAgICAgICBpZiAodHlwZW9mIHRoaXMuX3BlcmNlbnRhZ2VUZXh0ICE9PSAndW5kZWZpbmVkJykgdGhpcy5fcGVyY2VudGFnZVRleHQucmVtb3ZlKCk7XHJcbiAgICAgICAgaWYgKHRoaXMuZGF0YUxhYmVsQ29udGFpbmVyKSB0aGlzLmRhdGFMYWJlbENvbnRhaW5lci5zZWxlY3RBbGwoJyonKS5yZW1vdmUoKTtcclxuICAgICAgICB0aGlzLl9wb3NBcnJheSA9IFtdO1xyXG4gICAgICAgIGNsZWFySW50ZXJ2YWwodGhpcy5faW50ZXJ2YWwpO1xyXG4gICAgICAgIHN1cGVyLnJlbW92ZUNoYXJ0KCk7XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfZHJhd1BpZURvbnV0KF9wYXJhbXM6IHsgd2lkdGg6IG51bWJlciwgaGVpZ2h0OiBudW1iZXIgfSk6IHZvaWQge1xyXG4gICAgICAgIGxldCByYWRpdXMgPSBNYXRoLm1pbihfcGFyYW1zLndpZHRoLCBfcGFyYW1zLmhlaWdodCkgLyAyO1xyXG4gICAgICAgIGlmICh0aGlzLmNoYXJ0VHlwZVsxXSAmJiB0aGlzLmNoYXJ0VHlwZVsxXSA9PT0gJ2hhbGYnKSB7XHJcbiAgICAgICAgICAgIHJhZGl1cyA9IChNYXRoLm1pbihfcGFyYW1zLndpZHRoLCBfcGFyYW1zLmhlaWdodCkgLyA1KSAqIDM7XHJcbiAgICAgICAgICAgIHRoaXMuZ3JhcGguYXR0cigndHJhbnNmb3JtJywgJ3RyYW5zbGF0ZSgnICsgKF9wYXJhbXMud2lkdGggLyAyKSArICcsJyArICgoX3BhcmFtcy5oZWlnaHQgLyA0KSAqIDMpICsgJyknKTtcclxuICAgICAgICB9XHJcbiAgICAgICAgbGV0IGlubmVyUmFkaXVzID0gdGhpcy5jaGFydFR5cGVbMF0gPT09ICdwaWUnID8gMCA6ICh0aGlzLmNvbmZpZy5wbG90T3B0aW9ucy5waWUuaW5uZXJSYWRpdXMgLyAxMDApICogcmFkaXVzICogMC44O1xyXG4gICAgICAgIGxldCBhcmMgPSBkMy5hcmMoKS5pbm5lclJhZGl1cyhpbm5lclJhZGl1cykub3V0ZXJSYWRpdXMocmFkaXVzICogMC44KTtcclxuICAgICAgICBsZXQgb3V0ZXJhcmMgPSBkMy5hcmMoKS5pbm5lclJhZGl1cyhyYWRpdXMgKiAwLjkpLm91dGVyUmFkaXVzKHJhZGl1cyAqIDAuOSk7XHJcbiAgICAgICAgLy8gbGV0IGFyYyA9IGQzLmFyYygpLmlubmVyUmFkaXVzKGlubmVyUmFkaXVzKS5vdXRlclJhZGl1cyhyYWRpdXMpO1xyXG4gICAgICAgIGxldCBwaWUgPSBkMy5waWUoKS5zb3J0KG51bGwpLnZhbHVlKChkKSA9PiB7IHJldHVybiBkLnk7IH0pO1xyXG4gICAgICAgIGxldCBkYXRhTGFiZWxDaGVjayA9IHRoaXMuY2hhcnRUeXBlWzFdID09PSAnZnVsbCcgPyBNYXRoLlBJIDogMDtcclxuICAgICAgICBwaWUgPSB0aGlzLmNoYXJ0VHlwZVsxXSA9PT0gJ2Z1bGwnID8gcGllLnN0YXJ0QW5nbGUoMCkuZW5kQW5nbGUoTWF0aC5QSSAqIDIpIDogcGllLnN0YXJ0QW5nbGUoLTkwICogKE1hdGguUEkgLyAxODApKS5lbmRBbmdsZSg5MCAqIChNYXRoLlBJIC8gMTgwKSk7XHJcblxyXG4gICAgICAgIHRoaXMuX3BhdGggPSB0aGlzLmdyYXBoLnNlbGVjdEFsbCgncGF0aCcpXHJcbiAgICAgICAgICAgIC5kYXRhKHBpZSh0aGlzLnBpZURhdGEpKVxyXG4gICAgICAgICAgICAuZW50ZXIoKVxyXG4gICAgICAgICAgICAuYXBwZW5kKCdwYXRoJylcclxuICAgICAgICAgICAgLmF0dHIoJ2FyaWEtdmFsdWUnLCAoZCkgPT4gZC5kYXRhLnkpXHJcbiAgICAgICAgICAgIC5hdHRyKCdhcmlhLXNlcmllcy1uYW1lJywgKGQpID0+IHRoaXMubGVnZW5kW2QuZGF0YS5pZF0ubmFtZSlcclxuICAgICAgICAgICAgLmF0dHIoJ2NsYXNzJywgKGQpID0+IHtcclxuICAgICAgICAgICAgICAgIHRoaXMuX3Bvc0FycmF5LnB1c2goeyAneCc6IGQuZGF0YS5pbmRleCwgJ3ZhbHVlJzogZC5kYXRhLnksICdpZCc6IGQuZGF0YS5pbmRleCB9KTtcclxuICAgICAgICAgICAgICAgIHJldHVybiAneC0nICsgZC5kYXRhLmluZGV4ICsgJyB5LScgKyBkLmRhdGEuaW5kZXg7XHJcbiAgICAgICAgICAgICAgICAvLyByZXR1cm4gJ3gtJyArIChkLmRhdGEueEJhc2UpLnJlcGxhY2UoLyAvZywnJykgKyAnIHktJyArIHNlcmllc0lkO1xyXG4gICAgICAgICAgICB9KVxyXG4gICAgICAgICAgICAuYXR0cignaWQnLCAoZCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgcmV0dXJuIGQuZGF0YS5pbmRleDtcclxuICAgICAgICAgICAgICAgIC8vIHJldHVybiAoZC5kYXRhLngpLnJlcGxhY2UoLyAvZywnJyk7XHJcbiAgICAgICAgICAgIH0pXHJcbiAgICAgICAgICAgIC5hdHRyKCdmaWxsJywgKGQsIGkpID0+IHtcclxuICAgICAgICAgICAgICAgIHJldHVybiB0aGlzLmxlZ2VuZFtkLmRhdGEuaWRdLmNvbG9yOyAvLyBjb2xvciBzaG91bGQgZm9sbG93IGxlZ2VuZERhdGFcclxuICAgICAgICAgICAgfSlcclxuICAgICAgICAgICAgLy8gLmF0dHIoJ2QnLCBhcmMpXHJcbiAgICAgICAgICAgIC5zdHlsZSgnc3Ryb2tlJywgdGhpcy5jb25maWcucGxvdE9wdGlvbnMucGllLmJvcmRlckNvbG9yKVxyXG4gICAgICAgICAgICAuc3R5bGUoJ3N0cm9rZS13aWR0aCcsIHRoaXMuY29uZmlnLnBsb3RPcHRpb25zLnBpZS5ib3JkZXJXaWR0aCB8fCAwKTtcclxuXHJcbiAgICAgICAgbGV0IGxhYmVsUGFyYW1zID0ge1xyXG4gICAgICAgICAgICAncGllJzogcGllLFxyXG4gICAgICAgICAgICAnYXJjJzogYXJjLFxyXG4gICAgICAgICAgICAnb3V0ZXJhcmMnOiBvdXRlcmFyYyxcclxuICAgICAgICAgICAgJ3JhZGl1cyc6IHJhZGl1cyxcclxuICAgICAgICAgICAgJ2RhdGFMYWJlbENoZWNrJzogZGF0YUxhYmVsQ2hlY2ssXHJcbiAgICAgICAgICAgIC8vICdjb2xvcic6IF9wYXJhbXMuY29sb3JcclxuICAgICAgICB9O1xyXG5cclxuICAgICAgICBpZiAoIXRoaXMuY29uZmlnLmFuaW1hdGlvbikge1xyXG4gICAgICAgICAgICB0aGlzLl9wYXRoXHJcbiAgICAgICAgICAgICAgICAuYXR0cignZCcsIGQgPT4gYXJjKGQpKVxyXG4gICAgICAgICAgICAgICAgLmF0dHIoJ3BvcycsIGQgPT4gZ2V0UG9zKGQsIHRoaXMuY2hhcnRUeXBlWzFdKSk7XHJcblxyXG4gICAgICAgICAgICB0aGlzLl9zZXREYXRhTGFiZWwobGFiZWxQYXJhbXMpO1xyXG5cclxuICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICB0aGlzLl9wYXRoLnRyYW5zaXRpb24oKVxyXG4gICAgICAgICAgICAgICAgLmRlbGF5KChkLCBpKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIGkgKiAyMDtcclxuICAgICAgICAgICAgICAgIH0pXHJcbiAgICAgICAgICAgICAgICAuYXR0clR3ZWVuKCdkJywgKGQpID0+IHtcclxuICAgICAgICAgICAgICAgICAgICBsZXQgaSA9IGQzLmludGVycG9sYXRlKGQuc3RhcnRBbmdsZSwgZC5lbmRBbmdsZSk7XHJcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuICh0KSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGQuZW5kQW5nbGUgPSBpKHQpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gYXJjKGQpO1xyXG4gICAgICAgICAgICAgICAgICAgIH07XHJcbiAgICAgICAgICAgICAgICB9KVxyXG4gICAgICAgICAgICAgICAgLmF0dHJUd2VlbigncG9zJywgKGQpID0+IHtcclxuICAgICAgICAgICAgICAgICAgICBsZXQgY3VycmVudDtcclxuICAgICAgICAgICAgICAgICAgICBjdXJyZW50ID0gY3VycmVudCB8fCBkO1xyXG4gICAgICAgICAgICAgICAgICAgIGxldCBpbnRlcnBvbGF0ZSA9IGQzLmludGVycG9sYXRlKGN1cnJlbnQsIGQpO1xyXG4gICAgICAgICAgICAgICAgICAgIGN1cnJlbnQgPSBpbnRlcnBvbGF0ZSgwKTtcclxuICAgICAgICAgICAgICAgICAgICByZXR1cm4gKHQpID0+IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgbGV0IGQyID0gaW50ZXJwb2xhdGUodCk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiBnZXRQb3MoZDIsIHRoaXMuY2hhcnRUeXBlWzFdKTtcclxuICAgICAgICAgICAgICAgICAgICB9O1xyXG4gICAgICAgICAgICAgICAgfSlcclxuICAgICAgICAgICAgICAgIC5vbignZW5kJywgKGQsIGkpID0+IHtcclxuICAgICAgICAgICAgICAgICAgICBpZiAoaSA9PT0gKHRoaXMucGllRGF0YS5sZW5ndGggLSAxKSkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBzZXRUaW1lb3V0KCgpID0+IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuX3NldERhdGFMYWJlbChsYWJlbFBhcmFtcyk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgdGhpcy5fcGF0aC5leGl0KCkucmVtb3ZlKCk7XHJcblxyXG4gICAgICAgIGZ1bmN0aW9uIGdldFBvcyhfZDIsIF9jaGFydFR5cGUpIHtcclxuICAgICAgICAgICAgbGV0IHBvcyA9IG91dGVyYXJjLmNlbnRyb2lkKF9kMik7XHJcbiAgICAgICAgICAgIGlmIChfY2hhcnRUeXBlICYmIF9jaGFydFR5cGUgPT09ICdoYWxmJykge1xyXG4gICAgICAgICAgICAgICAgcG9zWzBdID0gcmFkaXVzICogKG1pZEFuZ2xlKF9kMikgPCBkYXRhTGFiZWxDaGVjayA/IC0xIDogMSk7XHJcbiAgICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgICAgICBwb3NbMF0gPSByYWRpdXMgKiAobWlkQW5nbGUoX2QyKSA8IGRhdGFMYWJlbENoZWNrID8gMSA6IC0xKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICByZXR1cm4gcG9zO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgZnVuY3Rpb24gbWlkQW5nbGUoX2QpIHtcclxuICAgICAgICAgICAgcmV0dXJuIF9kLnN0YXJ0QW5nbGUgKyAoX2QuZW5kQW5nbGUgLSBfZC5zdGFydEFuZ2xlKSAvIDI7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGxldCBldmVudHNQYXJhbSA9IHtcclxuICAgICAgICAgICAgJ2lubmVyUmFkaXVzJzogaW5uZXJSYWRpdXMsXHJcbiAgICAgICAgICAgICdvdXRlclJhZGl1cyc6IHJhZGl1cyAqIDAuOCxcclxuICAgICAgICAgICAgJ3BhdGhBbmltJzogdGhpcy5fcGF0aEFuaW0sXHJcbiAgICAgICAgfTtcclxuICAgICAgICBzdXBlci5faW5pdE1vdXNlRXZlbnRzKHRoaXMuX3BhdGgsIGV2ZW50c1BhcmFtKTtcclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF9kcmF3UmFkaWFsKF9wYXJhbXM6IHsgd2lkdGg/OiBudW1iZXIsIGhlaWdodDogbnVtYmVyIH0pOiB2b2lkIHtcclxuICAgICAgICAvLyBsZXQgaGVpZ2h0ID0gZG9jdW1lbnQucXVlcnlTZWxlY3RvcignIycgKyB0aGlzLmNvbmZpZy5pZCArICcua2R4LWNoYXJ0cyAuc3ZnLWNvbnRhaW5lcicpLmdldEJvdW5kaW5nQ2xpZW50UmVjdCgpLmhlaWdodDtcclxuICAgICAgICBsZXQgY2hhcnRSYWRpdXMgPSBfcGFyYW1zLmhlaWdodCAvIDIgLSA0MDtcclxuICAgICAgICBsZXQgc2NhbGUgPSBkMy5zY2FsZUxpbmVhcigpXHJcbiAgICAgICAgICAgIC5kb21haW4oWzAsIGQzLm1heCh0aGlzLnBpZURhdGEsIGQgPT4gZC55KSAqIDEuMV0pXHJcbiAgICAgICAgICAgIC5yYW5nZShbMCwgMiAqIFBJXSk7XHJcbiAgICAgICAgbGV0IHRpY2tzID0gc2NhbGUudGlja3MobnVtVGlja3MpLnNsaWNlKDAsIC0xKTtcclxuICAgICAgICBsZXQga2V5cyA9IHRoaXMucGllRGF0YS5tYXAoKGQsIGkpID0+IGQueCk7XHJcbiAgICAgICAgLy8gbnVtYmVyIG9mIGFyY3NcclxuICAgICAgICBjb25zdCBudW1BcmNzID0ga2V5cy5sZW5ndGg7XHJcbiAgICAgICAgY29uc3QgYXJjV2lkdGggPSAoY2hhcnRSYWRpdXMgLSBhcmNNaW5SYWRpdXMgLSBudW1BcmNzICogYXJjUGFkZGluZykgLyBudW1BcmNzO1xyXG5cclxuICAgICAgICBsZXQgYXJjID0gZDMuYXJjKClcclxuICAgICAgICAgICAgLmlubmVyUmFkaXVzKChkLCBpKSA9PiB0aGlzLl9nZXRJbm5lclJhZGl1cyhpLCBudW1BcmNzLCBhcmNXaWR0aCkpXHJcbiAgICAgICAgICAgIC5vdXRlclJhZGl1cygoZCwgaSkgPT4gdGhpcy5fZ2V0T3V0ZXJSYWRpdXMoaSwgbnVtQXJjcywgYXJjV2lkdGgpKVxyXG4gICAgICAgICAgICAuc3RhcnRBbmdsZSgwKVxyXG4gICAgICAgICAgICAuZW5kQW5nbGUoKGQsIGkpID0+IHNjYWxlKGQpKTtcclxuXHJcbiAgICAgICAgdGhpcy5fcmFkaWFsQXhpcyA9IHRoaXMuZ3JhcGguYXBwZW5kKCdnJylcclxuICAgICAgICAgICAgLmF0dHIoJ2NsYXNzJywgJ2tkeC1jaGFydHMtciBrZHgtY2hhcnRzLWF4aXMtcmFkaWFsJylcclxuICAgICAgICAgICAgLnNlbGVjdEFsbCgnZycpXHJcbiAgICAgICAgICAgIC5kYXRhKHRoaXMucGllRGF0YSlcclxuICAgICAgICAgICAgLmVudGVyKCkuYXBwZW5kKCdnJyk7XHJcblxyXG4gICAgICAgIHRoaXMuX3JhZGlhbEF4aXMuYXBwZW5kKCdjaXJjbGUnKVxyXG4gICAgICAgICAgICAuYXR0cigncicsIChkLCBpKSA9PiB0aGlzLl9nZXRPdXRlclJhZGl1cyhpLCBudW1BcmNzLCBhcmNXaWR0aCkgKyBhcmNQYWRkaW5nKTtcclxuXHJcbiAgICAgICAgdGhpcy5fcmFkaWFsQXhpcy5hcHBlbmQoJ3RleHQnKVxyXG4gICAgICAgICAgICAuYXR0cigneCcsIGxhYmVsUGFkZGluZylcclxuICAgICAgICAgICAgLmF0dHIoJ3knLCAoZCwgaSkgPT4gLXRoaXMuX2dldE91dGVyUmFkaXVzKGksIG51bUFyY3MsIGFyY1dpZHRoKSArIGFyY1BhZGRpbmcpXHJcbiAgICAgICAgICAgIC5zdHlsZSgnZm9udC1zaXplJywgJzEwcHgnKVxyXG4gICAgICAgICAgICAudGV4dChkID0+IGQueCk7XHJcblxyXG4gICAgICAgIHRoaXMuX2F4aWFsQXhpcyA9IHRoaXMuZ3JhcGguYXBwZW5kKCdnJylcclxuICAgICAgICAgICAgLmF0dHIoJ2NsYXNzJywgJ2tkeC1jaGFydHMtYSBrZHgtY2hhcnRzLWF4aXMtcmFkaWFsJylcclxuICAgICAgICAgICAgLnNlbGVjdEFsbCgnZycpXHJcbiAgICAgICAgICAgIC5kYXRhKHRpY2tzKVxyXG4gICAgICAgICAgICAuZW50ZXIoKS5hcHBlbmQoJ2cnKVxyXG4gICAgICAgICAgICAuYXR0cigndHJhbnNmb3JtJywgZCA9PiAncm90YXRlKCcgKyAodGhpcy5fcmFkMmRlZyhzY2FsZShkKSkgLSA5MCkgKyAnKScpO1xyXG5cclxuICAgICAgICB0aGlzLl9heGlhbEF4aXMuYXBwZW5kKCdsaW5lJylcclxuICAgICAgICAgICAgLmF0dHIoJ3gyJywgY2hhcnRSYWRpdXMpO1xyXG5cclxuICAgICAgICB0aGlzLl9heGlhbEF4aXMuYXBwZW5kKCd0ZXh0JylcclxuICAgICAgICAgICAgLmF0dHIoJ3gnLCBjaGFydFJhZGl1cyArIDEwKVxyXG4gICAgICAgICAgICAuc3R5bGUoJ3RleHQtYW5jaG9yJywgZCA9PiAoc2NhbGUoZCkgPj0gUEkgJiYgc2NhbGUoZCkgPCAyICogUEkgPyAnZW5kJyA6IG51bGwpKVxyXG4gICAgICAgICAgICAuc3R5bGUoJ2ZvbnQtc2l6ZScsICcxMHB4JylcclxuICAgICAgICAgICAgLmF0dHIoJ3RyYW5zZm9ybScsIGQgPT4gJ3JvdGF0ZSgnICsgKDkwIC0gdGhpcy5fcmFkMmRlZyhzY2FsZShkKSkpICsgJywnICsgKGNoYXJ0UmFkaXVzICsgMTApICsgJywwKScpXHJcbiAgICAgICAgICAgIC50ZXh0KGQgPT4gZCk7XHJcblxyXG4gICAgICAgIC8vIGRhdGEgYXJjc1xyXG4gICAgICAgIHRoaXMuX3BhdGggPSB0aGlzLmdyYXBoLmFwcGVuZCgnZycpXHJcbiAgICAgICAgICAgIC5zZWxlY3RBbGwoJ3BhdGgnKVxyXG4gICAgICAgICAgICAuZGF0YSh0aGlzLnBpZURhdGEpXHJcbiAgICAgICAgICAgIC5lbnRlcigpLmFwcGVuZCgncGF0aCcpXHJcbiAgICAgICAgICAgIC5hdHRyKCdjbGFzcycsIChkKSA9PiB7XHJcbiAgICAgICAgICAgICAgICByZXR1cm4gJ3gtJyArIGQueEJhc2UgKyAnIHktJyArIGQueDtcclxuICAgICAgICAgICAgfSlcclxuICAgICAgICAgICAgLnN0eWxlKCdmaWxsJywgKGQsIGkpID0+IHRoaXMubGVnZW5kW2QuaWRdLmNvbG9yKTtcclxuXHJcbiAgICAgICAgaWYgKCF0aGlzLmNvbmZpZy5hbmltYXRpb24pIHtcclxuICAgICAgICAgICAgdGhpcy5fcGF0aC5hdHRyKCdkJywgKGQsIGkpID0+IGFyYyhkLnksIGkpKTtcclxuICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICB0aGlzLl9wYXRoLnRyYW5zaXRpb24oKVxyXG4gICAgICAgICAgICAgICAgLmRlbGF5KChkLCBpKSA9PiBpICogMTAwKVxyXG4gICAgICAgICAgICAgICAgLmR1cmF0aW9uKDIwMClcclxuICAgICAgICAgICAgICAgIC8vIC5hdHRyVHdlZW4oJ2QnLCBhcmNUd2Vlbik7XHJcbiAgICAgICAgICAgICAgICAuYXR0clR3ZWVuKCdkJywgKGQsIGkpID0+IHtcclxuICAgICAgICAgICAgICAgICAgICBsZXQgaW50ZXJwb2xhdGUgPSBkMy5pbnRlcnBvbGF0ZSgwLCBkLnkpO1xyXG4gICAgICAgICAgICAgICAgICAgIHJldHVybiB0ID0+IGFyYyhpbnRlcnBvbGF0ZSh0KSwgaSk7XHJcbiAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIHN1cGVyLl9pbml0TW91c2VFdmVudHModGhpcy5fcGF0aCk7XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfZHJhd0dhdWdlKF9wYXJhbXM6IHsgaGVpZ2h0OiBudW1iZXIgfSk6IHZvaWQge1xyXG4gICAgICAgIC8vIGxldCBwZXJjZW50ID0gMTAwLjAwO1xyXG4gICAgICAgIGxldCBwZXJjZW50ID0gTWF0aC5mbG9vcihNYXRoLnJhbmRvbSgpICogMTAwKTtcclxuICAgICAgICBsZXQgZW5kQW5nbGUgPSB0aGlzLmNoYXJ0VHlwZVsxXSA9PT0gJ2Z1bGwnID8gTWF0aC5QSSAqIDIgOiBNYXRoLlBJO1xyXG4gICAgICAgIGxldCBvdXRlclJhZGl1cyA9IF9wYXJhbXMuaGVpZ2h0IC8gMztcclxuICAgICAgICBsZXQgaW5uZXJSYWRpdXMgPSAob3V0ZXJSYWRpdXMgLyAzKSAqIDI7XHJcbiAgICAgICAgbGV0IGZvbnRTaXplID0gaW5uZXJSYWRpdXMgKiAwLjg7XHJcblxyXG4gICAgICAgIGxldCBhcmMgPSBkMy5hcmMoKVxyXG4gICAgICAgICAgICAuaW5uZXJSYWRpdXMoaW5uZXJSYWRpdXMpXHJcbiAgICAgICAgICAgIC5vdXRlclJhZGl1cyhvdXRlclJhZGl1cylcclxuICAgICAgICAgICAgLnN0YXJ0QW5nbGUoMClcclxuICAgICAgICAgICAgLmVuZEFuZ2xlKGVuZEFuZ2xlKTtcclxuXHJcbiAgICAgICAgbGV0IGFyY0xpbmUgPSBkMy5hcmMoKVxyXG4gICAgICAgICAgICAuaW5uZXJSYWRpdXMoaW5uZXJSYWRpdXMpXHJcbiAgICAgICAgICAgIC5vdXRlclJhZGl1cyhvdXRlclJhZGl1cylcclxuICAgICAgICAgICAgLnN0YXJ0QW5nbGUoMCk7XHJcblxyXG4gICAgICAgIHRoaXMuX3BhdGggPSB0aGlzLmdyYXBoLmFwcGVuZCgncGF0aCcpXHJcbiAgICAgICAgICAgIC5hdHRyKCdkJywgYXJjKVxyXG4gICAgICAgICAgICAuYXR0cigndHJhbnNmb3JtJywgJ3JvdGF0ZSgtOTApJylcclxuICAgICAgICAgICAgLmF0dHIoJ3N0cm9rZS13aWR0aCcsIDEpXHJcbiAgICAgICAgICAgIC5hdHRyKCdzdHJva2UnLCAnIzY2NjY2NicpXHJcbiAgICAgICAgICAgIC5zdHlsZSgnZmlsbCcsICcjRkZGRkZGJyk7XHJcblxyXG5cclxuICAgICAgICB0aGlzLl9wb2ludGVyID0gdGhpcy5ncmFwaC5hcHBlbmQoJ3BhdGgnKVxyXG4gICAgICAgICAgICAvLyBsZXQgcGF0aEZvcmVncm91bmQgPSB0aGlzLmdyYXBoLmFwcGVuZCgncGF0aCcpXHJcbiAgICAgICAgICAgIC5kYXR1bSh7IGVuZEFuZ2xlOiAwIH0pXHJcbiAgICAgICAgICAgIC5hdHRyKCdkJywgYXJjTGluZSlcclxuICAgICAgICAgICAgLmF0dHIoJ3RyYW5zZm9ybScsICdyb3RhdGUoLTkwKScpO1xyXG5cclxuXHJcbiAgICAgICAgdGhpcy5fcGVyY2VudGFnZVRleHQgPSB0aGlzLmdyYXBoLmFwcGVuZCgndGV4dCcpXHJcbiAgICAgICAgICAgIC5kYXR1bSgwKVxyXG4gICAgICAgICAgICAudGV4dChmdW5jdGlvbihkKSB7XHJcbiAgICAgICAgICAgICAgICByZXR1cm4gZDtcclxuICAgICAgICAgICAgfSlcclxuICAgICAgICAgICAgLmF0dHIoJ2NsYXNzJywgJ2tkeC1jaGFydHMtbWlkZGxlVGV4dCcpXHJcbiAgICAgICAgICAgIC5hdHRyKCd0ZXh0LWFuY2hvcicsICdtaWRkbGUnKVxyXG4gICAgICAgICAgICAuYXR0cignZHknLCB0aGlzLmNoYXJ0VHlwZVsxXSA9PT0gJ2Z1bGwnID8gZm9udFNpemUgKiAwLjQ1IDogMClcclxuICAgICAgICAgICAgLnN0eWxlKCdmaWxsJywgZDMucmdiKCcjMDAwMDAwJykpXHJcbiAgICAgICAgICAgIC5zdHlsZSgnZm9udC1zaXplJywgZm9udFNpemUgKyAncHgnKTtcclxuXHJcbiAgICAgICAgaWYgKCF0aGlzLmNvbmZpZy5hbmltYXRpb24pIHtcclxuICAgICAgICAgICAgdGhpcy5fcG9pbnRlclxyXG4gICAgICAgICAgICAgICAgLmF0dHIoJ2QnLCBkID0+IGFyY0xpbmUoZCkpXHJcbiAgICAgICAgICAgICAgICAuc3R5bGUoJ2ZpbGwnLCBkMy5yZ2IoJyNGRjAwMDAnKSk7XHJcbiAgICAgICAgICAgIHJldHVybjtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIGxldCBhcmNUd2VlbiA9IGZ1bmN0aW9uKHRyYW5zaXRpb24sIG5ld1ZhbHVlLCB0ZXN0KSB7XHJcbiAgICAgICAgICAgIHRyYW5zaXRpb24uYXR0clR3ZWVuKCdkJywgKGQpID0+IHtcclxuICAgICAgICAgICAgICAgIGxldCBpbnRlcnBvbGF0ZSA9IGQzLmludGVycG9sYXRlKGQuZW5kQW5nbGUsICgoZW5kQW5nbGUpKSAqIChuZXdWYWx1ZSAvIDEwMCkpO1xyXG4gICAgICAgICAgICAgICAgbGV0IGludGVycG9sYXRlQ291bnQgPSBkMy5pbnRlcnBvbGF0ZSgwLCBuZXdWYWx1ZSk7XHJcblxyXG4gICAgICAgICAgICAgICAgcmV0dXJuICh0KSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgZC5lbmRBbmdsZSA9IGludGVycG9sYXRlKHQpO1xyXG4gICAgICAgICAgICAgICAgICAgIHRlc3QuX3BlcmNlbnRhZ2VUZXh0LnRleHQoTWF0aC5mbG9vcihpbnRlcnBvbGF0ZUNvdW50KHQpKSArICclJyk7XHJcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIGFyY0xpbmUoZCk7XHJcbiAgICAgICAgICAgICAgICB9O1xyXG4gICAgICAgICAgICB9KTtcclxuICAgICAgICB9O1xyXG5cclxuICAgICAgICB0aGlzLl9wb2ludGVyLnRyYW5zaXRpb24oKVxyXG4gICAgICAgICAgICAuZHVyYXRpb24oNzUwKVxyXG4gICAgICAgICAgICAuZWFzZShkMy5lYXNlQ3ViaWNJbilcclxuICAgICAgICAgICAgLmNhbGwoYXJjVHdlZW4sIHBlcmNlbnQsIHRoaXMpXHJcbiAgICAgICAgICAgIC5zdHlsZSgnZmlsbCcsIGQzLnJnYignI0ZGMDAwMCcpKTtcclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF9zZXREYXRhTGFiZWwoX3BhcmFtczogYW55KTogdm9pZCB7XHJcbiAgICAgICAgaWYgKCF0aGlzLmNvbmZpZy5jaGFydC5sYWJlbHMuZW5hYmxlZCkgcmV0dXJuO1xyXG4gICAgICAgIGlmICh0aGlzLmNoYXJ0Q2F0ZWdvcnkgIT09ICdwaWUnKSByZXR1cm47XHJcbiAgICAgICAgaWYgKHRoaXMuX3Bvc0FycmF5Lmxlbmd0aCA9PT0gMCkgcmV0dXJuO1xyXG4gICAgICAgIGxldCBsaW5lID0gQXJyYXkuZnJvbShkb2N1bWVudC5xdWVyeVNlbGVjdG9yQWxsKCcjJyArIHRoaXMuY29uZmlnLmlkICsgJy5rZHgtY2hhcnRzIC5rZHgtY2hhcnRzLWxpbmVzJykpO1xyXG4gICAgICAgIGxpbmUuZm9yRWFjaChlID0+IGUucGFyZW50Tm9kZS5yZW1vdmVDaGlsZChlKSk7XHJcblxyXG4gICAgICAgIGxldCBrZXkgPSAoZCkgPT4geyByZXR1cm4gZC5kYXRhLnk7IH07XHJcblxyXG4gICAgICAgIGZ1bmN0aW9uIG1pZEFuZ2xlKF9kKSB7XHJcbiAgICAgICAgICAgIHJldHVybiBfZC5zdGFydEFuZ2xlICsgKF9kLmVuZEFuZ2xlIC0gX2Quc3RhcnRBbmdsZSkgLyAyO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgbGV0IGhlaWdodCA9IHRoaXMuc3ZnQ29udGFpbmVyLm5vZGUoKS5nZXRCb3VuZGluZ0NsaWVudFJlY3QoKS5oZWlnaHQ7XHJcbiAgICAgICAgbGV0IHdpZHRoID0gdGhpcy5zdmdDb250YWluZXIubm9kZSgpLmdldEJvdW5kaW5nQ2xpZW50UmVjdCgpLndpZHRoO1xyXG4gICAgICAgIGhlaWdodCA9ICh0aGlzLmNoYXJ0VHlwZVsxXSAmJiB0aGlzLmNoYXJ0VHlwZVsxXSA9PT0gJ2hhbGYnKSA/ICgoaGVpZ2h0IC8gNCkgKiAzKSAtIDggOiBoZWlnaHQgLyAyIC0gODtcclxuICAgICAgICBmb3IgKGxldCBpID0gMDsgaSA8IHRoaXMuX3BhdGguX2dyb3Vwc1swXS5sZW5ndGg7IGkrKykge1xyXG4gICAgICAgICAgICBpZiAodGhpcy5fcG9zQXJyYXlbaV0gJiYgdGhpcy5fcG9zQXJyYXlbaV0uaWQgIT09IHVuZGVmaW5lZCkge1xyXG4gICAgICAgICAgICAgICAgbGV0IHBvc1BvaW50ZXIgPSBkb2N1bWVudC5xdWVyeVNlbGVjdG9yKCcjJyArIHRoaXMuY29uZmlnLmlkICsgJyAjJyArIHRoaXMuX3Bvc0FycmF5W2ldLmlkKS5nZXRBdHRyaWJ1dGUoJ3BvcycpO1xyXG4gICAgICAgICAgICAgICAgaWYgKHRoaXMuX3Bvc0FycmF5Lmxlbmd0aCAhPT0gMCAmJiBkb2N1bWVudC5xdWVyeVNlbGVjdG9yKCcjJyArIHRoaXMuY29uZmlnLmlkICsgJyAjJyArIHRoaXMuX3Bvc0FycmF5W2ldLmlkKSAhPT0gbnVsbCAmJiBwb3NQb2ludGVyICE9PSBudWxsKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgbGV0IHlEYXRhID0ge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAnaWQnOiB0aGlzLl9wb3NBcnJheVtpXS5pZCxcclxuICAgICAgICAgICAgICAgICAgICAgICAgJ3ZhbHVlJzogdGhpcy5fcG9zQXJyYXlbaV0udmFsdWVcclxuICAgICAgICAgICAgICAgICAgICB9O1xyXG4gICAgICAgICAgICAgICAgICAgIGxldCB4dmFsdWU6IG51bWJlciA9IHBhcnNlSW50KHBvc1BvaW50ZXIuc3BsaXQoJywnKVswXSkgKyB3aWR0aCAvIDI7XHJcbiAgICAgICAgICAgICAgICAgICAgbGV0IHl2YWx1ZTogbnVtYmVyID0gcGFyc2VJbnQocG9zUG9pbnRlci5zcGxpdCgnLCcpWzFdKSArIGhlaWdodDtcclxuICAgICAgICAgICAgICAgICAgICBsZXQgdGVtcENvbmRpdGlvbjogbnVtYmVyID0gcGFyc2VJbnQocG9zUG9pbnRlci5zcGxpdCgnLCcpWzBdKTtcclxuICAgICAgICAgICAgICAgICAgICBsZXQgcnRsQ29uZGl0aW9uOiBib29sZWFuID0gdGhpcy5pc1J0bCA9PT0gZmFsc2UgPyB0ZW1wQ29uZGl0aW9uIDwgMCA6IHRlbXBDb25kaXRpb24gPiAwO1xyXG4gICAgICAgICAgICAgICAgICAgIGxldCBjaGVja0ZsZXhFbmRTdHlsZTogc3RyaW5nID0gcnRsQ29uZGl0aW9uID8gJ2ZsZXgtZW5kJyA6ICdmbGV4LXN0YXJ0JztcclxuICAgICAgICAgICAgICAgICAgICBsZXQgZGF0YUxhYmVsQ2xhc3MgPSAnIycgKyB0aGlzLmNvbmZpZy5pZCArICcgLmtkeC1jaGFydHMtZGF0YS1sYWJlbC54LScgKyB0aGlzLl9wb3NBcnJheVtpXS54ICsgJy55LScgKyB5RGF0YS5pZDtcclxuICAgICAgICAgICAgICAgICAgICBpZiAoZG9jdW1lbnQucXVlcnlTZWxlY3RvcihkYXRhTGFiZWxDbGFzcykgPT0gbnVsbCkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBzdXBlci5zZXRMYWJlbCh5RGF0YSwgdGhpcy5fcG9zQXJyYXlbaV0ueCwgeHZhbHVlLCB5dmFsdWUpLnN0eWxlKCd2aXNpYmlsaXR5JywgJ3Zpc2libGUnKS5zdHlsZSgnd2lkdGgnLCAnMHB4Jykuc3R5bGUoJ2p1c3RpZnktY29udGVudCcsIGNoZWNrRmxleEVuZFN0eWxlKTtcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIHRoaXMuX3BvbHlsaW5lID0gdGhpcy5ncmFwaC5hcHBlbmQoJ2cnKVxyXG4gICAgICAgICAgICAuYXR0cignY2xhc3MnLCAna2R4LWNoYXJ0cy1saW5lcycpXHJcbiAgICAgICAgICAgIC5zZWxlY3RBbGwoJ3BvbHlsaW5lJylcclxuICAgICAgICAgICAgLmRhdGEoX3BhcmFtcy5waWUodGhpcy5waWVEYXRhKSwga2V5KVxyXG4gICAgICAgICAgICAuZW50ZXIoKVxyXG4gICAgICAgICAgICAuYXBwZW5kKCdwb2x5bGluZScpXHJcbiAgICAgICAgICAgIC5zdHlsZSgnc3Ryb2tlJywgKGQsIGkpID0+IHtcclxuICAgICAgICAgICAgICAgIHJldHVybiB0aGlzLmxlZ2VuZFtkLmRhdGEuaWRdLmNvbG9yO1xyXG4gICAgICAgICAgICB9KS5hdHRyKCdwb2ludHMnLCAoZCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgcmV0dXJuIGdldFBvcyhkLCB0aGlzLmNoYXJ0VHlwZVsxXSk7XHJcbiAgICAgICAgICAgIH0pLnN0eWxlKCdmaWxsJywgJ25vbmUnKTtcclxuXHJcbiAgICAgICAgLy8gaWYgKCF0aGlzLmNvbmZpZy5hbmltYXRpb24pIHtcclxuICAgICAgICAvLyAgICAgdGhpcy5fcG9seWxpbmUuYXR0cigncG9pbnRzJywgKGQpID0+IHtcclxuICAgICAgICAvLyAgICAgICAgIHJldHVybiBnZXRQb3MoZCwgdGhpcy5jaGFydFR5cGVbMV0pO1xyXG4gICAgICAgIC8vICAgICB9KTtcclxuICAgICAgICAvLyAgICAgcmV0dXJuO1xyXG4gICAgICAgIC8vIH1cclxuXHJcbiAgICAgICAgLy8gdGhpcy5fcG9seWxpbmUudHJhbnNpdGlvbigpLmR1cmF0aW9uKDEwMDApXHJcbiAgICAgICAgLy8gICAgIC5hdHRyVHdlZW4oJ3BvaW50cycsIChkKSA9PiB7XHJcbiAgICAgICAgLy8gICAgICAgICB0aGlzLl9jdXJyZW50ID0gdGhpcy5fY3VycmVudCB8fCBkO1xyXG4gICAgICAgIC8vICAgICAgICAgbGV0IGludGVycG9sYXRlID0gZDMuaW50ZXJwb2xhdGUodGhpcy5fY3VycmVudCwgZCk7XHJcbiAgICAgICAgLy8gICAgICAgICB0aGlzLl9jdXJyZW50ID0gaW50ZXJwb2xhdGUoMCk7XHJcbiAgICAgICAgLy8gICAgICAgICByZXR1cm4gKHQpID0+IHtcclxuICAgICAgICAvLyAgICAgICAgICAgICBsZXQgZDIgPSBpbnRlcnBvbGF0ZSh0KTtcclxuICAgICAgICAvLyAgICAgICAgICAgICByZXR1cm4gZ2V0UG9zKGQyLCB0aGlzLmNoYXJ0VHlwZVsxXSk7XHJcbiAgICAgICAgLy8gICAgICAgICB9O1xyXG4gICAgICAgIC8vICAgICB9KTtcclxuXHJcbiAgICAgICAgZnVuY3Rpb24gZ2V0UG9zKF9kMiwgX2NoYXJ0VHlwZSkge1xyXG4gICAgICAgICAgICBsZXQgcG9zID0gX3BhcmFtcy5vdXRlcmFyYy5jZW50cm9pZChfZDIpO1xyXG4gICAgICAgICAgICBpZiAoX2NoYXJ0VHlwZSAmJiBfY2hhcnRUeXBlID09PSAnaGFsZicpIHtcclxuICAgICAgICAgICAgICAgIHBvc1swXSA9IF9wYXJhbXMucmFkaXVzICogMC45NSAqIChtaWRBbmdsZShfZDIpIDwgX3BhcmFtcy5kYXRhTGFiZWxDaGVjayA/IC0xIDogMSk7XHJcbiAgICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgICAgICBwb3NbMF0gPSBfcGFyYW1zLnJhZGl1cyAqIDAuOTUgKiAobWlkQW5nbGUoX2QyKSA8IF9wYXJhbXMuZGF0YUxhYmVsQ2hlY2sgPyAxIDogLTEpO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIHJldHVybiBbX3BhcmFtcy5hcmMuY2VudHJvaWQoX2QyKSwgX3BhcmFtcy5vdXRlcmFyYy5jZW50cm9pZChfZDIpLCBwb3NdO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcblxyXG4gICAgcHJpdmF0ZSBfZ2V0SW5uZXJSYWRpdXMoX2luZGV4OiBudW1iZXIsIF9udW1BcmNzOiBudW1iZXIsIF9hcmNXaWR0aDogbnVtYmVyKTogbnVtYmVyIHtcclxuICAgICAgICByZXR1cm4gYXJjTWluUmFkaXVzICsgKF9udW1BcmNzIC0gKF9pbmRleCArIDEpKSAqIChfYXJjV2lkdGggKyBhcmNQYWRkaW5nKTtcclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF9nZXRPdXRlclJhZGl1cyhfaW5kZXg6IG51bWJlciwgX251bUFyY3M6IG51bWJlciwgX2FyY1dpZHRoOiBudW1iZXIpOiBudW1iZXIge1xyXG4gICAgICAgIHJldHVybiB0aGlzLl9nZXRJbm5lclJhZGl1cyhfaW5kZXgsIF9udW1BcmNzLCBfYXJjV2lkdGgpICsgX2FyY1dpZHRoO1xyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX3JhZDJkZWcoX2FuZ2xlOiBudW1iZXIpOiBudW1iZXIge1xyXG4gICAgICAgIHJldHVybiBfYW5nbGUgKiAxODAgLyBQSTtcclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF9wYXRoQW5pbShfcGF0aDogYW55LCBkaXI6IGFueSwgX2lubmVyUmFkaXVzOiBhbnksIF9vdXRlclJhZGl1czogYW55KTogdm9pZCB7XHJcbiAgICAgICAgc3dpdGNoIChkaXIpIHtcclxuICAgICAgICAgICAgY2FzZSBmYWxzZTpcclxuICAgICAgICAgICAgICAgIF9wYXRoLnRyYW5zaXRpb24oKVxyXG4gICAgICAgICAgICAgICAgICAgIC5kdXJhdGlvbig1MDApXHJcbiAgICAgICAgICAgICAgICAgICAgLy8gLmVhc2UoJ2JvdW5jZScpXHJcbiAgICAgICAgICAgICAgICAgICAgLmF0dHIoJ2QnLCBkMy5hcmMoKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAuaW5uZXJSYWRpdXMoX2lubmVyUmFkaXVzKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAub3V0ZXJSYWRpdXMoX291dGVyUmFkaXVzKVxyXG4gICAgICAgICAgICAgICAgICAgICkuYXR0cignc3Ryb2tlJywgJ25vbmUnKTtcclxuICAgICAgICAgICAgICAgIGJyZWFrO1xyXG5cclxuICAgICAgICAgICAgY2FzZSB0cnVlOlxyXG4gICAgICAgICAgICAgICAgX3BhdGgudHJhbnNpdGlvbigpXHJcbiAgICAgICAgICAgICAgICAgICAgLmF0dHIoJ2QnLCBkMy5hcmMoKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAuaW5uZXJSYWRpdXMoX2lubmVyUmFkaXVzKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAub3V0ZXJSYWRpdXMoX291dGVyUmFkaXVzICogMS4xKVxyXG4gICAgICAgICAgICAgICAgICAgICkuYXR0cignc3Ryb2tlJywgJ3doaXRlJykuYXR0cignc3Ryb2tlLXdpZHRoJywgMik7XHJcbiAgICAgICAgICAgICAgICBicmVhaztcclxuICAgICAgICB9XHJcbiAgICB9XHJcbn1cclxuIl19