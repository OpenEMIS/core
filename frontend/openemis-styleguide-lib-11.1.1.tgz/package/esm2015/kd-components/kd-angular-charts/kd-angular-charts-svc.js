import { Injectable } from '@angular/core';
import { KdDomElemSvc } from '../kd-common/index';
import * as d3 from 'd3';
import * as helper from './helper-svc/index';
export class KdChartsSvc {
    constructor(_domSvc) {
        this._domSvc = _domSvc;
        this._isInvert = false;
        this._isRotate = false;
        this._isRtl = false;
        this._defaultSvgMargin = {
            top: 20,
            x: 9,
            y: 12,
            oppVert: 20
        };
        this._svgMargin = {
            top: 0,
            right: 0,
            bottom: 0,
            left: 0
        };
        this._yAxisLabelWidth = {
            axisMax: 0,
            axisMin: 0
        };
        this._minXSpacing = 50;
        this._axisD3Format = '';
        this._isXReversed = false;
        this._isYReversed = false;
        this.dataLabelPushDownRange = 0;
        this._isNegativeStack = false;
        this.gridSvc = new helper.KdChartsGridSvc(this._config);
        this.tooltipSvc = new helper.KdChartsTooltipSvc();
    }
    set config(_config) {
        this._config = _config;
        this.gridSvc.config = _config;
    }
    get config() { return this._config; }
    set svg(_svg) { this._svg = _svg; }
    set svgRect(_svgRect) { this._svgRect = _svgRect; }
    set chartType(_chartType) { this._chartType = _chartType; }
    set chartCategory(_chartCategory) { this._chartCategory = _chartCategory; }
    set isInvert(_isInvert) {
        this._isInvert = _isInvert;
        this.gridSvc.isInvert = _isInvert;
    }
    set svgParentRect(_svgParentRect) { this._svgParentRect = _svgParentRect; }
    set isRotate(_isRotate) { this._isRotate = _isRotate; }
    get isRotate() { return this._isRotate; }
    set labelLength(_labelLength) { this._labelLength = _labelLength; }
    get labelLength() { return this._labelLength; }
    get svgMargin() { return this._svgMargin; }
    set xScaleType(_xScaleType) { this._xScaleType = _xScaleType; }
    get xScaleType() { return this._xScaleType; }
    get xSpacing() { return this._xSpacing; }
    get axisD3Format() { return this._axisD3Format; }
    get yAxisLabelWidth() { return this._yAxisLabelWidth; }
    set isRtl(_isRtl) { this._isRtl = _isRtl; }
    set isXReversed(_isXReversed) {
        if (!this._isInvert) {
            this._isXReversed = _isXReversed !== this._isRtl;
        }
        else {
            this._isXReversed = _isXReversed;
        }
    }
    get isXReversed() { return this._isXReversed; }
    set isYReversed(_isYReversed) {
        if (this._isInvert) {
            this._isYReversed = _isYReversed !== this._isRtl;
        }
        else {
            this._isYReversed = _isYReversed;
        }
    }
    get isYReversed() { return this._isYReversed; }
    set isNegativeStack(_isNegativeStack) { this._isNegativeStack = _isNegativeStack; }
    get isNegativeStack() { return this._isNegativeStack; }
    // ================================= Vertical Axis ==================================
    /**
     * for rotating vertical axis. if axis is enabled, appends class-name 'rotate-title' to kd charts.
     * param  {Array<string>} _type   chart type: if horizontal bar, use xAxis's(the vertical axis) config
     * param  {any}           _config
     * return {boolean}
     */
    checkRotateTitleEnabled(_type, _config) {
        let axisConfig = _type[0] === 'bar' ? _config.xAxis : _config.yAxis;
        return axisConfig.enabled && axisConfig.title.text !== '';
    }
    setVertAxisAndChartMargin(_id) {
        let chartContainer = document.querySelector('#' + _id + '.kdx-charts .kdx-chart-container');
        let axisConfig = this._isInvert ? this._config.xAxis : this._config.yAxis;
        // setting css for vertical axis
        if (axisConfig.enabled && axisConfig.title.text !== '') {
            let currAxisTitleClass = this._isInvert ? '.kdx-charts-axis-title-x' : '.kdx-charts-axis-title-y';
            this._currVertAxisTitle = document.querySelector('#' + _id + '.kdx-charts ' + currAxisTitleClass + '.kdx-charts-axis-title');
        }
        else {
            this._currVertAxisTitle = null;
        }
        this.setChartContainerMargin(chartContainer);
    }
    repositionVerticalAxisTitle() {
        if (!this.isValueExist(this._currVertAxisTitle))
            return;
        let axisTitleClass = this._isInvert ? '.kdx-charts-axis-title-x' : '.kdx-charts-axis-title-y';
        let axisTitleTextArr = document.querySelectorAll('#' + this._config.id + '.kdx-charts ' + axisTitleClass + ' .kdx-charts-axis-title-text');
        axisTitleTextArr.forEach(axisTitleText => {
            axisTitleText.style.top = this._currVertAxisTitle.getBoundingClientRect().height / 2 + axisTitleText.getBoundingClientRect().height / 2 + 'px';
            axisTitleText.style.visibility = 'unset';
        });
    }
    // ================================= Y Axis Label ==================================
    setMaxAndMin(_yAxisConfig, _dataRange) {
        let maxValue = this.isValueExist(_yAxisConfig.maxValue) ? _yAxisConfig.maxValue : _dataRange.max;
        let minValue = this.isValueExist(_yAxisConfig.minValue) ? _yAxisConfig.minValue : _dataRange.min;
        // ensure that min value will not exceed max, vice verse
        maxValue = Math.max(maxValue, minValue);
        minValue = Math.min(maxValue, minValue);
        let interval = d3.max([_yAxisConfig.tickInterval, _yAxisConfig.minorTickInterval]);
        if (!interval || interval <= 0)
            interval = 1;
        // to prevent tick calculation causing stop-script, only allow at most around 1000 ticks (excluding first tick)
        let smallestPossibleInterval = (maxValue - minValue) / 1000;
        if (smallestPossibleInterval > interval) {
            interval = this.isInterger(interval) ? Math.floor(smallestPossibleInterval) : smallestPossibleInterval;
        }
        return {
            maxValue: maxValue,
            minValue: minValue,
            interval: interval
        };
    }
    setAxisD3Format(_interval) {
        let decimalPlace = this.findDecimalPlace(_interval);
        this._axisD3Format = this.getD3Format(_interval, decimalPlace);
    }
    getYAxisLabelText(_yAxisConfig, _value) {
        return this.getLabelText(_yAxisConfig.labels.format, _value, false, this._axisD3Format);
    }
    /**
     * Y axis label dummy. appends text element to svg and returns the width of label
     * param  {number |      string}      _value: label's value
     * param  {string}                    _class: class name for dummy
     * return {number}                    returns actual rendered width of label
     */
    setDummyAxisLabel(_value, _class) {
        // if (!this._config.yAxis.enabled) return 0;
        let yAxisConfig = this._config.yAxis;
        // if axis is enabled, draw axisMax string and axisMin string to compute this.width/height
        let textSelection = this._svg.selectAll('.dummy-' + _class);
        let text = this.getYAxisLabelText(yAxisConfig, _value);
        // element should only be appended once
        if (textSelection.empty())
            textSelection = this._svg.append('text');
        this.setSvgAttribute(textSelection, Object.assign({}, yAxisConfig.labels.style, { class: 'kdx-charts-dummy dummy-' + _class, opacity: 0 }));
        textSelection.text(text);
        return textSelection.node().getBBox().width;
    }
    /**
     * chart width and height have to be calculated based on how long y axis labels are (eg: a lot of space allocated for 1,000,000 as compared to 10)
     * returns this.width or this.height depending on _axis given
     * param  {'x'|'y'}         _axis
     * param  { axisMax: number, axisMin: number } _axisVal
     * return {number}
     */
    getSvgOffset(_axis, _axisVal) {
        let axisOpposite = _axis === 'x' ? this._config.yAxis.opposite : this._config.xAxis.opposite;
        let opposite = axisOpposite !== this._isRtl;
        let yAxisLabelsNotVisible = !this._config.yAxis.enabled || !this._config.yAxis.labels.enabled;
        if (_axis === 'x')
            this._yAxisLabelWidth = this.getYAxisMaxAndMinLabelWidth(_axisVal);
        let internalYAxisLabelWidth = this._yAxisLabelWidth;
        if (yAxisLabelsNotVisible)
            internalYAxisLabelWidth = { axisMax: 0, axisMin: 0 };
        if (!this._isInvert) {
            if (_axis === 'x') {
                let start = opposite ? 'right' : 'left';
                let end = opposite ? 'left' : 'right';
                this._svgMargin[start] = this._defaultSvgMargin.y + Math.max(internalYAxisLabelWidth.axisMax, internalYAxisLabelWidth.axisMin);
                this._svgMargin[end] = this._defaultSvgMargin.oppVert;
                return this._svgRect.width - this._svgMargin[start] - this._svgMargin[end];
            }
            else {
                let start = axisOpposite ? 'bottom' : 'top';
                let end = axisOpposite ? 'top' : 'bottom';
                let labelFontSize = yAxisLabelsNotVisible ? 0 : this.replaceStringWithNumber(this._config.yAxis.labels.style.fontSize);
                this._svgMargin[end] = Math.max(this._defaultSvgMargin.x, 0.5 * labelFontSize);
                this._svgMargin[start] = this.isNegativeStack ? this._svgMargin[end] : this._defaultSvgMargin.top;
                return this._svgRect.height - this._svgMargin[start] - this._svgMargin[end];
            }
        }
        else {
            if (_axis === 'x') {
                let start = axisOpposite ? 'bottom' : 'top';
                let end = axisOpposite ? 'top' : 'bottom';
                let labelFontSize = yAxisLabelsNotVisible ? 0 : this.replaceStringWithNumber(this._config.yAxis.labels.style.fontSize);
                this._svgMargin[start] = this._defaultSvgMargin.top;
                this._svgMargin[end] = this._defaultSvgMargin.y + labelFontSize;
                return this._svgRect.height - this._svgMargin[start] - this._svgMargin[end];
            }
            else {
                let start = opposite ? 'right' : 'left';
                let end = opposite ? 'left' : 'right';
                let startLabelWidth = opposite === this.isYReversed ? internalYAxisLabelWidth.axisMin : internalYAxisLabelWidth.axisMax;
                let endLabelWidth = opposite === this.isYReversed ? internalYAxisLabelWidth.axisMax : internalYAxisLabelWidth.axisMin;
                this._svgMargin[start] = Math.max(this._defaultSvgMargin.x, startLabelWidth / 2);
                this._svgMargin[end] = this.isNegativeStack ? Math.max(this._defaultSvgMargin.x, endLabelWidth / 2) : endLabelWidth / 2 + this._defaultSvgMargin.oppVert;
                return this._svgRect.width - this._svgMargin[start] - this._svgMargin[end];
            }
        }
    }
    /**
     * round axisMax/Min value to interval (eg: Max value is 10 but interval is 3, so max value will be rounded to either 9 or 12)
     * _isAutoRoundToNextInterval is enabled, round to 12
     * _isAutoRoundToNextInterval is disabled, round to 9
     *
     * param  {number}  _value
     * param  {number}  _interval
     * param  {boolean} _isAutoRoundToNextInterval
     * param  {'up' | 'down'}      _roundDir
     * return {number}
     */
    setAxisRoundValue(_value, _interval, _isAutoRoundToNextInterval, _roundDir) {
        // if value is 0, don't round
        if (_value === 0)
            return _value;
        let decimalPlaces = Math.max(this.findDecimalPlace(_value), this.findDecimalPlace(_interval));
        if (decimalPlaces !== 0) {
            // if _value or _interval have decimal, convert them to whole numbers
            _value = _value * Math.pow(10, decimalPlaces);
            _interval = _interval * Math.pow(10, decimalPlaces);
        }
        let sign = Math.sign(_value);
        let newValue = _value - _value % _interval;
        if (_roundDir === 'up') {
            if (sign < 0) {
                if (!_isAutoRoundToNextInterval)
                    newValue = newValue - _interval;
            }
            else {
                if (_isAutoRoundToNextInterval)
                    newValue = newValue + _interval;
            }
        }
        else {
            if (sign < 0) {
                if (_isAutoRoundToNextInterval)
                    newValue = newValue - _interval;
            }
            else {
                if (!_isAutoRoundToNextInterval)
                    newValue = newValue + _interval;
            }
        }
        if (decimalPlaces !== 0)
            newValue = newValue / Math.pow(10, decimalPlaces);
        return newValue;
    }
    getTickValues(_min, _max, _interval) {
        if (!_interval || typeof _min === 'undefined' || typeof _max === 'undefined')
            return [];
        _max = this._getUpperBoundForTickValues(_max, _interval);
        return d3.range(_min, _max, _interval);
    }
    /**
     * set Y axis Label Config
     * param {any}        _axis is Element/d3-selection
     * param {'xAxis' | 'yAxis'}     _direction
     */
    setAxisLabelConfig(_axis, _direction) {
        let axisDir = _direction + 'Axis';
        if (!this._config[axisDir])
            return;
        let axisConfig = this._config[axisDir];
        _axis.selectAll('path')
            .attr('stroke-width', axisConfig.lineWidth)
            .attr('stroke', axisConfig.lineColor);
        _axis.selectAll('line')
            .attr('stroke-width', axisConfig.lineWidth)
            .attr('stroke', axisConfig.lineColor);
        if (_direction === 'x' || !axisConfig.enabled || !this._config[axisDir].labels.enabled) {
            this.setSvgAttribute(_axis.selectAll('text'), { display: 'none' });
        }
        else {
            this.setSvgAttribute(_axis.selectAll('text'), axisConfig.labels.style);
            this.setSvgAttribute(_axis.selectAll('text'), { class: 'kdx-charts-display-number-inside-svg kdx-charts-display-number' });
        }
    }
    getYAxisMaxAndMinLabelWidth(_axisVal) {
        let widthObj = { axisMax: 0, axisMin: 0 };
        // if (this._config.yAxis.labels.enabled) {
        widthObj.axisMax = this.setDummyAxisLabel(_axisVal.axisMax, 'axisMax');
        widthObj.axisMin = this.setDummyAxisLabel(_axisVal.axisMin, 'axisMin');
        // }
        return widthObj;
    }
    _getUpperBoundForTickValues(_max, _interval) {
        let decimalPlaces = Math.max(this.findDecimalPlace(_max), this.findDecimalPlace(_interval));
        _max = _max * Math.pow(10, decimalPlaces);
        _interval = _interval * Math.pow(10, decimalPlaces);
        return (_max + _interval) / Math.pow(10, decimalPlaces);
    }
    // ================================= X Axis Label ==================================
    /**
     * set axis Label Container (currently only used for X axis)
     * param  {number} _xSpacing
     * param  {string} _extraClassName [same level as .kdx-charts-axis-label-container. Additional className in case of doubleAxis]
     * return {any}
     */
    setAxisLabelContainer(_extraClassName = '') {
        this._axisLabelContainer = d3.select('#' + this._config.id + '.kdx-charts .kdx-charts-axis-label-container' + _extraClassName);
        if (!this.isValueExist(this._axisLabelContainer.node()))
            return;
        return this._axisLabelContainer;
    }
    /**** Axis Label Dummy *******/
    setAxisLabelDummy(_id, _xSpacing, _longestText) {
        this._setAxisLabelDummyElement(_id);
        this.setAxisLabelDummyText(_longestText);
        this.isRotate = this._checkRotate(this._isInvert, _xSpacing, this._minXSpacing);
        this._setAxisLabelDummyStyle(_xSpacing);
    }
    setAxisLabelDummyText(_longestText) {
        if (!this._axisLabelDummy)
            return;
        _longestText = this.getLabelFormatReplace(this.config.xAxis.labels.format, _longestText);
        this._setAxisLabelDummyHtml(_longestText);
    }
    getAxisLabelDummyRect() {
        if (!this._axisLabelDummy)
            return 0;
        return this._axisLabelDummy.getBoundingClientRect();
    }
    _setAxisLabelDummyElement(_id) {
        if (typeof this._axisLabelDummy === 'undefined') {
            this._axisLabelDummy = document.querySelector('#' + _id + '.kdx-charts .kdx-charts-invisible-axis-label');
        }
    }
    _setAxisLabelDummyHtml(_text) {
        if (!this._axisLabelDummy)
            return;
        this._axisLabelDummy.innerHTML = _text;
    }
    _setAxisLabelDummyStyle(_xSpacing) {
        if (!this._isInvert && !this.isRotate) {
            this._axisLabelDummy.style.maxWidth = _xSpacing + 'px';
        }
    }
    /**** Others *******/
    _checkRotate(_isInvert, _xSpacing, _minXSpacing) {
        // if each bar/xSpacing has at least 50 px, do not rotate, let the label word-wrap
        if (_xSpacing >= _minXSpacing || _isInvert)
            return false;
        // rotate only if xSpacing < 50px AND the actual text(with paddding) length > each bar/xSpacing
        return this.getAxisLabelDummyRect().width > _xSpacing;
    }
    _setAxisLabelLength() {
        let longestLength = this.getAxisLabelDummyRect().width || 0, svgParentRect = this._svgParentRect, svgLength = (this._isInvert ? svgParentRect.width : svgParentRect.height) || 0, labelLength = Math.min(longestLength, 0.3 * svgLength);
        this._labelLength = labelLength;
    }
    _getAxisMargin(_isInvert, _isRotate) {
        let axisMargin = { top: 0, left: 0, right: 0 };
        let opposite = this._config.yAxis.opposite || false;
        if (!_isInvert) {
            let titleWidth = 0;
            let side = this._isRtl ? 'right' : 'left';
            let sign = this._isRtl ? -1 : 1;
            opposite = opposite !== this._isRtl;
            if (!opposite && this.isValueExist(this._currVertAxisTitle)) {
                titleWidth = this._currVertAxisTitle.getBoundingClientRect().width;
            }
            axisMargin[side] = sign * (this._svgMargin.left + titleWidth);
        }
        else {
            axisMargin.top = this._svgMargin.top;
            if (opposite)
                axisMargin.top += this._getHorizTitleHeight();
            axisMargin.right = 2;
        }
        return axisMargin;
    }
    setAxisLabelContainerStyle(_container) {
        let styleType = this._isInvert ? 'width' : 'height';
        let styleVal = this.labelLength;
        if (!this._isInvert && !this.isRotate) {
            styleVal = this.getAxisLabelDummyRect().height;
        }
        _container.style(styleType, styleVal + 'px');
        if (!this._isInvert)
            _container.style('width', '100%');
        this._axisLabelDummy.style.maxWidth = '100%';
        let margin = this._getAxisMargin(this._isInvert, this.isRotate);
        _container
            .style('margin-top', margin.top + 'px')
            .style('margin-right', margin.right + 'px')
            .style('margin-left', margin.left + 'px');
        this._axisLabelContainerMarginLeft = margin.left;
    }
    /**
     * set X axis Label Position
     * param {any}     _labelContainer
     * param {number}  _tickPos
     * param {IAxisLabelBooleanChecks} _booleanChecks
     */
    setAxisLabelPosition(_labelContainer, _tickPos, _booleanChecks) {
        if (this._isInvert || _booleanChecks.isRotate || (_booleanChecks.isLast && this._xScaleType === 'string')) {
            this._domSvc.addClass(_labelContainer.node(), 'ellipsis');
        }
        // when rotating, there shouldn't be any padding(.kdx-charts-child-padding-both) or 'special' padding (.kdx-charts-child-special-padding)
        // must execute before offset position
        if (_booleanChecks.isRotate)
            _labelContainer.style('padding', 0);
        let labelRect = _labelContainer.node().getBoundingClientRect(), offset = !this._isInvert && !_booleanChecks.isRotate ? labelRect.width / 2 : labelRect.height / 2, offSetSign = _booleanChecks.isRotate && _booleanChecks.opposite ? -1 : 1, position = _tickPos - offset * offSetSign;
        // for horizontal bar
        if (this._isInvert) {
            let horizDir = this._isRtl !== _booleanChecks.opposite ? 'left' : 'right';
            _labelContainer
                .style('top', position + 'px')
                .style(horizDir, 0 + 'px');
            return;
        }
        let vertDir = _booleanChecks.opposite ? 'bottom' : 'top';
        // for all other axis charts
        if (_booleanChecks.isRotate) {
            let vertDist = _booleanChecks.isRotate && !_booleanChecks.opposite ? labelRect.width : 0;
            _labelContainer
                .style(vertDir, vertDist + 'px')
                .style('transform', 'rotate(-90deg)');
        }
        else {
            if (this._xScaleType === 'string') {
                // when position is negative and it's absolute value is more than the margin of axisLabelContainer
                if (position + this._axisLabelContainerMarginLeft < 0) {
                    let diff = Math.abs(position) - this._axisLabelContainerMarginLeft;
                    _labelContainer.style('max-width', (labelRect.width - 2 * diff) + 'px');
                    position = -1 * this._axisLabelContainerMarginLeft;
                }
                if (_booleanChecks.isLast)
                    _labelContainer.style('max-width', (labelRect.width / 2 + this._svgMargin.right) + 'px');
            }
            _labelContainer.style(vertDir, 0 + 'px');
        }
        _labelContainer.style('left', position + 'px');
    }
    // ================================= Data Labels ==================================
    /**
     * data labels have to be repositioned according to title and axis Labels's width and position
     * param {any} _dataLabelContainer d3-selection
     * param {any} _axisLabelContainer d3-selection
     */
    repositionDataLabel(_dataLabelContainer, _axisLabelContainer) {
        let axisLabelContainerRect = this.isValueExist(_axisLabelContainer) ? _axisLabelContainer.node().getBoundingClientRect() : { width: 0, height: 0 };
        let left = this._calculateDataLabelLeft(axisLabelContainerRect.width);
        let top = this._calculateDataLabelTop(axisLabelContainerRect.height);
        _dataLabelContainer
            .style('left', left + 'px')
            .style('top', top + 'px');
    }
    _calculateDataLabelLeft(_labelWidth) {
        let opposite = this._isInvert ? this._config.xAxis.opposite : this._config.yAxis.opposite;
        let chartMarginLeft = this._config.chart.margin.left;
        // when vertical axis on right (only one axis), left side have no axis
        // NOTE: do not run this step when column/bar-stack-negative, since both left and right side have vertical axis
        if (opposite !== this._isRtl && !this.isNegativeStack) {
            return this._svgMargin.left + this.replaceStringWithNumber(chartMarginLeft);
        }
        // when vertical axis on left
        let titleWidth = this.isValueExist(this._currVertAxisTitle) ? this._currVertAxisTitle.getBoundingClientRect().width : 0;
        let left = this.replaceStringWithNumber(chartMarginLeft);
        left += this._isInvert ? titleWidth + _labelWidth + this._svgMargin.left + 2 : titleWidth + this._svgMargin.left;
        return left;
    }
    _calculateDataLabelTop(_labelHeight) {
        let opposite = this._isInvert ? this._config.yAxis.opposite : this._config.xAxis.opposite;
        // when horizontal axis is at bottom
        // NOTE: do not run this step when column/bar-stack-negative, since both above and below have horizontal axis
        if (!opposite && !this.isNegativeStack) {
            return this._svgMargin.top + this.replaceStringWithNumber(this._config.chart.margin.top);
        }
        // when horizontal axis on top
        let horizTitleHeight = this._getHorizTitleHeight();
        let top = this.replaceStringWithNumber(this._config.chart.margin.top);
        top += this._isInvert ? horizTitleHeight + this._svgMargin.top : horizTitleHeight + this._svgMargin.top + _labelHeight;
        return top;
    }
    _getHorizTitleHeight() {
        let className = '#' + this._config.id + '.kdx-charts .kdx-charts-axis-title';
        className += this._isInvert ? '-y' : '-x';
        let horizTitleElement = document.querySelector(className);
        return this.isValueExist(horizTitleElement) ? horizTitleElement.getBoundingClientRect().height : 0;
    }
    /****Vertical Align*****/
    _getLabelTextHeight() {
        let labelStyle = this._config.chart.labels.style;
        let fontSize = this.replaceStringWithNumber(labelStyle.fontSize);
        let borderWidth = this.replaceStringWithNumber(labelStyle.borderWidth);
        return fontSize * 1.3 + borderWidth * 2;
    }
    _checkBoundary(_type, _yPosition, _chartHeight, _dotSize = 0) {
        let textSize = this._getLabelTextHeight() + _dotSize / 2;
        if (_type === 'max') {
            return _yPosition - textSize < this.dataLabelPushDownRange;
        }
        else {
            return _yPosition + textSize > _chartHeight - this.dataLabelPushDownRange;
        }
    }
    needOffsetForColumn(_verticalAlign, _params = {}) {
        if (!_params.dimensions)
            return false;
        if (_params.valueSign < 0) {
            if (_verticalAlign === 'top')
                return -1; // needs offset, returning true condition
        }
        else {
            if (_verticalAlign === 'bottom')
                return 1; // needs offset, returning true condition
        }
        return false;
    }
    // NOTE: data label vertical align is not defined in default config (as of v3.7.0 becos behaviour changes with different chart types)
    getDefaultVerticalAlign(_config, _params) {
        if (_config.chart.labels.verticalAlign)
            return _config.chart.labels.verticalAlign;
        let defaultValue = 'top';
        // for column, negative values need to be placed on bottom
        if (_params.valueSign < 0)
            defaultValue = 'bottom';
        return defaultValue;
    }
    // ================================= General ==================================
    /**
     * in arabic, numbers are in ltr mode (eg: negative sign is typed first)
     * Hence wrapping a div around number (only) with className '.kdx-charts-display-number' to force direction: ltr
     * param  {number} _number
     * return {string}
     */
    wrapNumberInInlineDiv(_number) {
        return '<div class="kdx-charts-display-number" style="display: inline-block;" dir="ltr">' + _number + '</div>';
    }
    replaceStringWithNumber(_value) {
        if (typeof _value === 'number')
            return _value;
        return parseFloat(_value.replace(/[^0-9.]/g, ''));
    }
    getForLoopSequence(_chartType) {
        return _chartType[0] !== 'bar' && (_chartType[1] === 'stack' || _chartType[1] === '100') ? 'descending' : 'ascending';
    }
    getForLoopInfo(_type, arrLength) {
        return {
            start: _type === 'ascending' ? 0 : arrLength - 1,
            end: _type === 'ascending' ? arrLength : -1,
            check: _type === 'ascending' ? (i, end) => i < end : (i, end) => i > end,
            iterate: _type === 'ascending' ? (i) => i + 1 : (i) => i - 1,
        };
    }
    getXInfo(_data, _config) {
        let xInfo = {
            value: [],
            longestText: ''
        };
        let longestTextWidth = 0;
        let showValueInLabel = _config.xAxis.labels.format.indexOf('{value}') > -1 && _config.xAxis.enabled && _config.xAxis.labels.enabled;
        if (showValueInLabel)
            this._setAxisLabelDummyElement(_config.id);
        _data.forEach(d => {
            xInfo.value.push(d.x.value);
            // if no value needs to be showed in label, then no need check longest text
            if (showValueInLabel) {
                this._setAxisLabelDummyHtml(d.x.label);
                let currentWidth = this.getAxisLabelDummyRect().width;
                if (currentWidth > longestTextWidth) {
                    longestTextWidth = currentWidth;
                    xInfo.longestText = d.x.label;
                }
            }
        });
        return xInfo;
    }
    checkAndReturnLabelsPositive(_value) {
        if (this.isNegativeStack) {
            let plotOptions = this.config.plotOptions;
            if (plotOptions && plotOptions.bar && typeof plotOptions.bar.allLabelsPositive !== 'undefined') {
                return this.config.plotOptions.bar.allLabelsPositive ? Math.abs(_value) : _value;
            }
            return Math.abs(_value);
        }
        return _value;
    }
    findDecimalPlace(_number) {
        if (parseInt(_number.toString()) === _number)
            return 0;
        let result = 0;
        let stringForm = Math.abs(_number).toString();
        let splitByDot = stringForm.split('.');
        if (stringForm.indexOf('e') < 0) {
            result = splitByDot[1].length;
        }
        else {
            result = parseInt(stringForm.split('e-')[1]);
            if (typeof splitByDot[1] !== 'undefined')
                result += splitByDot[1].length;
        }
        return result;
    }
    getLabelText(_format, _value, _isHTML = true, _d3Format) {
        let d3Format = typeof _d3Format === 'undefined' ? this.getD3Format(_value) : _d3Format;
        let text = this.changeValueToD3Format(_value, d3Format);
        if (_isHTML)
            text = this.wrapNumberInInlineDiv(text);
        return this.getLabelFormatReplace(_format, text);
    }
    getLabelFormatReplace(_format, _text) {
        return _format.replace(/{value}/g, _text);
    }
    isInterger(_value) {
        return typeof _value === 'number' && (_value % 1) === 0;
    }
    getD3Format(_value, _toDecimalPlace) {
        if (typeof _value === 'string')
            return '';
        if (Math.abs(_value) > 10000000)
            return '.2e';
        if (this.isInterger(_value)) {
            return ',';
        }
        else {
            // is decimal
            if (Math.abs(_value) < 0.00000001)
                return '.2e';
            if (typeof _toDecimalPlace !== 'undefined' && _toDecimalPlace !== 0) {
                // if precision is given
                return '.' + _toDecimalPlace.toString() + 'f';
            }
        }
        return '';
    }
    changeValueToD3Format(_value, _format) {
        if (typeof _value === 'string')
            return _value;
        return d3.format(_format)(_value);
    }
    getLongerNumber(_num1, _num2) {
        return _num1.toString().length > _num2.toString().length ? _num1 : _num2;
    }
    setChartContainerMargin(_chartContainer) {
        let margin = this._config.chart.margin;
        _chartContainer.style.padding = margin.top + ' ' + margin.right + ' ' + margin.bottom + ' ' + margin.left;
    }
    transformGraphContainer(_container) {
        _container.attr('transform', 'translate(' + this._svgMargin.left + ',' + this._svgMargin.top + ')');
    }
    setSvgAttribute(_element, _config) {
        for (let key in _config) {
            if (!this.isValueExist(_config[key]))
                continue;
            let attributeStr = key === 'color' ? 'fill' : key.replace(/([a-zA-Z])(?=[A-Z])/g, '$1-').toLowerCase();
            _element.attr(attributeStr, _config[key]);
        }
    }
    isExist(_yElem) {
        return (typeof _yElem !== 'undefined' && _yElem !== null && _yElem.value !== null);
    }
    isValueExist(_val) {
        return (typeof _val !== 'undefined' && _val !== null && _val !== '');
    }
    getD3MaxOrMin(_arr, _type) {
        if (_type === 'max')
            return d3.max(_arr);
        if (_type === 'min')
            return d3.min(_arr);
    }
    getAxisTransformPos(_axis, _opposite, _transformPos) {
        if (this._isInvert) {
            if (_axis === 'x') {
                if (_opposite)
                    return _transformPos.right;
                return _transformPos.left;
            }
            if (_axis === 'y') {
                if (_opposite)
                    return _transformPos.top;
                return _transformPos.bottom;
            }
        }
        else {
            if (_axis === 'x') {
                if (_opposite)
                    return _transformPos.top;
                return _transformPos.bottom;
            }
            if (_axis === 'y') {
                if (_opposite)
                    return _transformPos.right;
                return _transformPos.left;
            }
        }
    }
    getLimitedCategories(_initCategories, _xThreshold) {
        if (!_initCategories)
            return [];
        return _xThreshold && _initCategories.length > _xThreshold ? _initCategories.slice(0, _xThreshold) : _initCategories;
    }
    /**
     * return config into css string so can be added into element
     * param  {object}  defaultConfig config
     * param  {boolean} isForTooltip  if tooltip, compare default config with config pass from user
     * return {string}                css styling
     */
    getStyle(defaultConfig, isForTooltip) {
        let config = {};
        if (isForTooltip) {
            config = this._config.tooltip.style;
        }
        let styling = '';
        if (defaultConfig) {
            for (let defaultKey of Object.keys(defaultConfig)) {
                styling += defaultKey.replace(/([a-zA-Z])(?=[A-Z])/g, '$1-').toLowerCase();
                styling += ':';
                styling += (config && config.hasOwnProperty(defaultKey)) ? config[defaultKey] : defaultConfig[defaultKey];
                styling += ';';
            }
        }
        return styling;
    }
    // ================================= Line only ==================================
    /**
     * check if line missing
     * param {[type]} _data        data
     * param {[type]} _dataIndex   xIndex
     * param {[type]} _seriesIndex yIndex / yValueIndex
     */
    isSeriesNull(_data, _dataIndex, _seriesIndex) {
        let currentVal = 0;
        let dataLength = 0;
        let isIChartData = this._isChartData;
        if (isIChartData(_data)) {
            currentVal = _data.series[_seriesIndex].data[_dataIndex].value;
            dataLength = _data.xAxis.categories.length;
        }
        else {
            currentVal = _data[_dataIndex].y[_seriesIndex].value;
            dataLength = _data.length;
        }
        function getValue(when, isNull) {
            let index = 0;
            if (when === 'prev') {
                if (_dataIndex > 0) {
                    index = _dataIndex - 1;
                }
                else {
                    return false;
                }
            }
            else {
                if (_dataIndex < dataLength - 1) {
                    index = _dataIndex + 1;
                }
                else {
                    return false;
                }
            }
            let value = (isIChartData(_data) ? _data.series[_seriesIndex].data[index].value : _data[index].y[_seriesIndex].value);
            if (isNull) {
                return value === null;
            }
            return value !== null;
        }
        let isPrevNull = getValue('prev', true);
        let isPrevNotNull = getValue('prev', false);
        let isNextNull = getValue('next', true);
        let isNextNotNull = getValue('next', false);
        let isAppearing = isNextNotNull && currentVal !== null && isPrevNull;
        let isDisappearing = isNextNull && currentVal !== null && isPrevNotNull;
        return {
            isPrevNull: isPrevNull,
            isPrevNotNull: isPrevNotNull,
            isNextNull: isNextNull,
            isNextNotNull: isNextNotNull,
            isAppearing: isAppearing,
            isDisappearing: isDisappearing
        };
    }
    _isChartData(object) {
        return 'series' in object;
    }
    // ================================= Kd Chart only ==================================
    /**
     * required for percentage calculation of 100 stack. returns a array of total sum of data value of each categories.
     * param  {Array<ISeries>} _seriesArr
     * param  {Array<string>}  _categories
     * return {Array<number>}
     */
    getTotalSumArrFromSeries(_seriesArr, _categories, seriesLength) {
        let sumArr = [];
        for (let i = 0; i < _categories.length; ++i) {
            let sum = 0;
            for (let j = 0; j < seriesLength; ++j) {
                if (typeof _seriesArr[j].data[i] === 'undefined')
                    continue;
                let currentVal = _seriesArr[j].data[i].value;
                if (typeof currentVal === 'undefined')
                    continue;
                sum = (currentVal === null) ? sum : sum + currentVal;
            }
            sumArr.push(sum);
        }
        return sumArr;
    }
    // ================================= Pie only ==================================
    /**
     * check if line missing
     * param {[key: string]: ILegendData} _legendData pie chart legend data
     * param {any} _data pie chart data
     * param {IChartConfig} _config pie chart legend config
     */
    setPieData(_legendData, _data, _config, _seriesThreshold) {
        let pieData = [];
        let pieColor = [];
        let legendId;
        let pieDataArrayLength = 0;
        let configDataArray = Object.keys(_legendData).map(key => _legendData[key]);
        _legendData = {};
        for (let i = 0; i < _data.data.length; i++) {
            for (let j = 0; j < _data.data[i].y.length; j++) {
                for (let k = 0; k < configDataArray.length; k++) {
                    if (_data.data[i].y[j]['id'] === configDataArray[k].id) {
                        if (typeof _data.series[0].data[i].y !== 'undefined') {
                            if ((_seriesThreshold !== undefined && _seriesThreshold !== null && pieDataArrayLength < _seriesThreshold) || _seriesThreshold === undefined || _seriesThreshold === null) {
                                let colorPointer = _data.data[i].y[j]['color'];
                                let colorValue = (colorPointer && colorPointer != null && colorPointer != null) ? colorPointer : this.getDefaultConfig('color', pieDataArrayLength, _config);
                                legendId = 'id' + pieDataArrayLength;
                                _legendData[legendId] = {
                                    'name': _data.data[i].x + ' ' + configDataArray[k].name,
                                    'id': legendId,
                                    'shape': 'circle',
                                    'x': _data.data[i].x + ' ' + configDataArray[k].name,
                                    'y': _data.data[i].y[j]['value'],
                                    'xBase': _data.data[i].x,
                                    'index': 'pie' + pieDataArrayLength,
                                    'color': colorValue,
                                    'seriesIndex': j,
                                    'dataIndex': i
                                };
                                pieColor.push(colorValue);
                                pieData.push({
                                    'id': legendId,
                                    'x': _data.data[i].x + ' ' + configDataArray[k].name,
                                    'y': _data.data[i].y[j]['value'],
                                    'xBase': _data.data[i].x,
                                    'index': 'pie' + pieDataArrayLength,
                                    'color': colorValue,
                                    'seriesIndex': j,
                                    'dataIndex': i
                                });
                                pieDataArrayLength++;
                                break;
                            }
                        }
                    }
                }
            }
        }
        let returnParams = {
            'pieData': pieData,
            'pieColor': pieColor,
            'legendData': _legendData
        };
        return returnParams;
    }
    singlePieDataMassage(_legendData, _data, _config, _seriesThreshold) {
        let pieData = [];
        let pieColor = [];
        let legendId;
        let pieDataArrayLength = 0;
        _legendData = {};
        if (_data.series && _data.series[0] && _data.series[0].data) {
            for (let i = 0; i < _data.series[0].data.length; i++) {
                if (typeof _data.series[0].data[i].y !== 'undefined') {
                    if ((_seriesThreshold != undefined && _seriesThreshold != null && pieDataArrayLength < _seriesThreshold) || _seriesThreshold == undefined || _seriesThreshold == null) {
                        let colorPointer = _data.series[0].data[i]['color'];
                        let colorValue = (colorPointer && colorPointer != null && colorPointer != null) ? colorPointer : this.getDefaultConfig('color', pieDataArrayLength, _config);
                        legendId = 'id' + pieDataArrayLength;
                        _legendData[legendId] = {
                            'name': _data.series[0].data[i].name.replace(/¬/g, ' '),
                            'id': legendId,
                            'shape': 'circle',
                            'x': _data.series[0].data[i].name,
                            'y': _data.series[0].data[i].y,
                            'xBase': _data.series[0].data[i].name,
                            'index': 'pie' + pieDataArrayLength,
                            'color': colorValue,
                        };
                        pieColor.push(colorValue);
                        if (_data.series[0].data[i].y && _data.series[0].data[i].y > 0) {
                            pieData.push({
                                'id': legendId,
                                'x': _data.series[0].data[i].name,
                                'y': _data.series[0].data[i].y,
                                'xBase': _data.series[0].data[i].name,
                                'index': 'pie' + pieDataArrayLength,
                                'color': colorValue,
                            });
                        }
                        pieDataArrayLength++;
                    }
                }
            }
        }
        let returnParams = {
            'pieData': pieData,
            'pieColor': pieColor,
            'legendData': _legendData
        };
        return returnParams;
    }
    setMapLegendData(_legendData, _data, _config) {
        let legendId;
        _legendData = {};
        for (let i = 0; i < _data.length; i++) {
            if (_data[i].name != undefined) {
                let colorPointer = _data[i].color;
                legendId = 'id' + i;
                _legendData[legendId] = {
                    'name': _data[i].name,
                    'id': legendId,
                    'shape': 'circle',
                    'x': _data[i].name,
                    'y': _data[i].data[0].value,
                    'xBase': _data[i].name,
                    'color': (colorPointer && colorPointer != null && colorPointer != undefined) ? colorPointer : this.getDefaultConfig('color', i, _config),
                    'mapSeriesId': _data[i].id,
                    'deactive': _data[i].deactive
                };
            }
        }
        return _legendData;
    }
    getDefaultConfig(_element, _seriesIndex, _config) {
        if (_element === 'shape')
            return 'circle';
        if (_seriesIndex || _seriesIndex === 0) {
            return _config.colors[_seriesIndex % _config.colors.length];
        }
    }
    setSingleLegendLevels(_dataClasses, _decimalPrecison, _valueSuffix, _originalLegend) {
        let _legendData = {};
        for (let i = 0; i < _dataClasses.length; i++) {
            let legendId = 'id' + i;
            _legendData[legendId] = {
                'name': _dataClasses[i].from.toFixed(_decimalPrecison) + _valueSuffix + ' - ' + _dataClasses[i].to.toFixed(_decimalPrecison) + _valueSuffix,
                'id': legendId,
                'shape': 'circle',
                'color': _dataClasses[i].color,
                'deactive': _originalLegend && _originalLegend[legendId] ? _originalLegend[legendId].deactive : false
            };
        }
        return _legendData;
    }
}
KdChartsSvc.decorators = [
    { type: Injectable }
];
KdChartsSvc.ctorParameters = () => [
    { type: KdDomElemSvc }
];
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoia2QtYW5ndWxhci1jaGFydHMtc3ZjLmpzIiwic291cmNlUm9vdCI6IkQ6L29wZW5FTUlTL3N0eWxlZ3VpZGUvaW9zdGctb3BlbmVtaXMtc3R5bGVndWlkZS9wcm9qZWN0cy9vcGVuZW1pcy1zdHlsZWd1aWRlLWxpYi9zcmMvIiwic291cmNlcyI6WyJrZC1jb21wb25lbnRzL2tkLWFuZ3VsYXItY2hhcnRzL2tkLWFuZ3VsYXItY2hhcnRzLXN2Yy50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQSxPQUFPLEVBQUUsVUFBVSxFQUFFLE1BQU0sZUFBZSxDQUFDO0FBQzNDLE9BQU8sRUFBRSxZQUFZLEVBQUUsTUFBTSxvQkFBb0IsQ0FBQztBQUNsRCxPQUFPLEtBQUssRUFBRSxNQUFNLElBQUksQ0FBQztBQUN6QixPQUFPLEtBQUssTUFBTSxNQUFNLG9CQUFvQixDQUFDO0FBb0I3QyxNQUFNLE9BQU8sV0FBVztJQTRDcEIsWUFBb0IsT0FBcUI7UUFBckIsWUFBTyxHQUFQLE9BQU8sQ0FBYztRQXRDakMsY0FBUyxHQUFZLEtBQUssQ0FBQztRQUczQixjQUFTLEdBQVksS0FBSyxDQUFDO1FBRzNCLFdBQU0sR0FBWSxLQUFLLENBQUM7UUFDeEIsc0JBQWlCLEdBQTREO1lBQ2pGLEdBQUcsRUFBRSxFQUFFO1lBQ1AsQ0FBQyxFQUFFLENBQUM7WUFDSixDQUFDLEVBQUUsRUFBRTtZQUNMLE9BQU8sRUFBRSxFQUFFO1NBQ2QsQ0FBQztRQUNNLGVBQVUsR0FBa0U7WUFDaEYsR0FBRyxFQUFFLENBQUM7WUFDTixLQUFLLEVBQUUsQ0FBQztZQUNSLE1BQU0sRUFBRSxDQUFDO1lBQ1QsSUFBSSxFQUFFLENBQUM7U0FDVixDQUFDO1FBQ00scUJBQWdCLEdBQXFCO1lBQ3pDLE9BQU8sRUFBRSxDQUFDO1lBQ1YsT0FBTyxFQUFFLENBQUM7U0FDYixDQUFDO1FBSU0saUJBQVksR0FBVyxFQUFFLENBQUM7UUFHMUIsa0JBQWEsR0FBVyxFQUFFLENBQUM7UUFDM0IsaUJBQVksR0FBWSxLQUFLLENBQUM7UUFDOUIsaUJBQVksR0FBWSxLQUFLLENBQUM7UUFDOUIsMkJBQXNCLEdBQVcsQ0FBQyxDQUFDO1FBQ25DLHFCQUFnQixHQUFZLEtBQUssQ0FBQztRQU10QyxJQUFJLENBQUMsT0FBTyxHQUFHLElBQUksTUFBTSxDQUFDLGVBQWUsQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLENBQUM7UUFDeEQsSUFBSSxDQUFDLFVBQVUsR0FBRyxJQUFJLE1BQU0sQ0FBQyxrQkFBa0IsRUFBRSxDQUFDO0lBQ3RELENBQUM7SUFFRCxJQUFJLE1BQU0sQ0FBQyxPQUFPO1FBQ2QsSUFBSSxDQUFDLE9BQU8sR0FBRyxPQUFPLENBQUM7UUFDdkIsSUFBSSxDQUFDLE9BQU8sQ0FBQyxNQUFNLEdBQUcsT0FBTyxDQUFDO0lBQ2xDLENBQUM7SUFDRCxJQUFJLE1BQU0sS0FBbUIsT0FBTyxJQUFJLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQztJQUVuRCxJQUFJLEdBQUcsQ0FBQyxJQUFJLElBQUksSUFBSSxDQUFDLElBQUksR0FBRyxJQUFJLENBQUMsQ0FBQyxDQUFDO0lBRW5DLElBQUksT0FBTyxDQUFDLFFBQVEsSUFBSSxJQUFJLENBQUMsUUFBUSxHQUFHLFFBQVEsQ0FBQyxDQUFDLENBQUM7SUFFbkQsSUFBSSxTQUFTLENBQUMsVUFBVSxJQUFJLElBQUksQ0FBQyxVQUFVLEdBQUcsVUFBVSxDQUFDLENBQUMsQ0FBQztJQUMzRCxJQUFJLGFBQWEsQ0FBQyxjQUFjLElBQUksSUFBSSxDQUFDLGNBQWMsR0FBRyxjQUFjLENBQUMsQ0FBQyxDQUFDO0lBRTNFLElBQUksUUFBUSxDQUFDLFNBQVM7UUFDbEIsSUFBSSxDQUFDLFNBQVMsR0FBRyxTQUFTLENBQUM7UUFDM0IsSUFBSSxDQUFDLE9BQU8sQ0FBQyxRQUFRLEdBQUcsU0FBUyxDQUFDO0lBQ3RDLENBQUM7SUFFRCxJQUFJLGFBQWEsQ0FBQyxjQUFjLElBQUksSUFBSSxDQUFDLGNBQWMsR0FBRyxjQUFjLENBQUMsQ0FBQyxDQUFDO0lBRTNFLElBQUksUUFBUSxDQUFDLFNBQVMsSUFBSSxJQUFJLENBQUMsU0FBUyxHQUFHLFNBQVMsQ0FBQyxDQUFDLENBQUM7SUFDdkQsSUFBSSxRQUFRLEtBQWMsT0FBTyxJQUFJLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQztJQUVsRCxJQUFJLFdBQVcsQ0FBQyxZQUFZLElBQUksSUFBSSxDQUFDLFlBQVksR0FBRyxZQUFZLENBQUMsQ0FBQyxDQUFDO0lBQ25FLElBQUksV0FBVyxLQUFhLE9BQU8sSUFBSSxDQUFDLFlBQVksQ0FBQyxDQUFDLENBQUM7SUFFdkQsSUFBSSxTQUFTLEtBQUssT0FBTyxJQUFJLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQztJQUUzQyxJQUFJLFVBQVUsQ0FBQyxXQUFXLElBQUksSUFBSSxDQUFDLFdBQVcsR0FBRyxXQUFXLENBQUMsQ0FBQyxDQUFDO0lBQy9ELElBQUksVUFBVSxLQUFLLE9BQU8sSUFBSSxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUM7SUFFN0MsSUFBSSxRQUFRLEtBQUssT0FBTyxJQUFJLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQztJQUV6QyxJQUFJLFlBQVksS0FBSyxPQUFPLElBQUksQ0FBQyxhQUFhLENBQUMsQ0FBQyxDQUFDO0lBRWpELElBQUksZUFBZSxLQUFLLE9BQU8sSUFBSSxDQUFDLGdCQUFnQixDQUFDLENBQUMsQ0FBQztJQUV2RCxJQUFJLEtBQUssQ0FBQyxNQUFNLElBQUksSUFBSSxDQUFDLE1BQU0sR0FBRyxNQUFNLENBQUMsQ0FBQyxDQUFDO0lBRTNDLElBQUksV0FBVyxDQUFDLFlBQVk7UUFDeEIsSUFBSSxDQUFDLElBQUksQ0FBQyxTQUFTLEVBQUU7WUFDakIsSUFBSSxDQUFDLFlBQVksR0FBRyxZQUFZLEtBQUssSUFBSSxDQUFDLE1BQU0sQ0FBQztTQUNwRDthQUFNO1lBQ0gsSUFBSSxDQUFDLFlBQVksR0FBRyxZQUFZLENBQUM7U0FDcEM7SUFDTCxDQUFDO0lBQ0QsSUFBSSxXQUFXLEtBQUssT0FBTyxJQUFJLENBQUMsWUFBWSxDQUFDLENBQUMsQ0FBQztJQUUvQyxJQUFJLFdBQVcsQ0FBQyxZQUFZO1FBQ3hCLElBQUksSUFBSSxDQUFDLFNBQVMsRUFBRTtZQUNoQixJQUFJLENBQUMsWUFBWSxHQUFHLFlBQVksS0FBSyxJQUFJLENBQUMsTUFBTSxDQUFDO1NBQ3BEO2FBQU07WUFDSCxJQUFJLENBQUMsWUFBWSxHQUFHLFlBQVksQ0FBQztTQUNwQztJQUNMLENBQUM7SUFDRCxJQUFJLFdBQVcsS0FBSyxPQUFPLElBQUksQ0FBQyxZQUFZLENBQUMsQ0FBQyxDQUFDO0lBRS9DLElBQUksZUFBZSxDQUFDLGdCQUF5QixJQUFJLElBQUksQ0FBQyxnQkFBZ0IsR0FBRyxnQkFBZ0IsQ0FBQyxDQUFDLENBQUM7SUFDNUYsSUFBSSxlQUFlLEtBQWMsT0FBTyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsQ0FBQyxDQUFDO0lBRWhFLHFGQUFxRjtJQUVyRjs7Ozs7T0FLRztJQUNJLHVCQUF1QixDQUFDLEtBQW9CLEVBQUUsT0FBWTtRQUM3RCxJQUFJLFVBQVUsR0FBUSxLQUFLLENBQUMsQ0FBQyxDQUFDLEtBQUssS0FBSyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsS0FBSyxDQUFDO1FBQ3pFLE9BQU8sVUFBVSxDQUFDLE9BQU8sSUFBSSxVQUFVLENBQUMsS0FBSyxDQUFDLElBQUksS0FBSyxFQUFFLENBQUM7SUFDOUQsQ0FBQztJQUVNLHlCQUF5QixDQUFDLEdBQVc7UUFDeEMsSUFBSSxjQUFjLEdBQVksUUFBUSxDQUFDLGFBQWEsQ0FBQyxHQUFHLEdBQUcsR0FBRyxHQUFHLGtDQUFrQyxDQUFDLENBQUM7UUFDckcsSUFBSSxVQUFVLEdBQVEsSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsS0FBSyxDQUFDO1FBRS9FLGdDQUFnQztRQUNoQyxJQUFJLFVBQVUsQ0FBQyxPQUFPLElBQUksVUFBVSxDQUFDLEtBQUssQ0FBQyxJQUFJLEtBQUssRUFBRSxFQUFFO1lBQ3BELElBQUksa0JBQWtCLEdBQVcsSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsMEJBQTBCLENBQUMsQ0FBQyxDQUFDLDBCQUEwQixDQUFDO1lBQzFHLElBQUksQ0FBQyxrQkFBa0IsR0FBRyxRQUFRLENBQUMsYUFBYSxDQUFDLEdBQUcsR0FBRyxHQUFHLEdBQUcsY0FBYyxHQUFHLGtCQUFrQixHQUFHLHdCQUF3QixDQUFDLENBQUM7U0FDaEk7YUFBTTtZQUNILElBQUksQ0FBQyxrQkFBa0IsR0FBRyxJQUFJLENBQUM7U0FDbEM7UUFFRCxJQUFJLENBQUMsdUJBQXVCLENBQUMsY0FBYyxDQUFDLENBQUM7SUFDakQsQ0FBQztJQUVNLDJCQUEyQjtRQUM5QixJQUFJLENBQUMsSUFBSSxDQUFDLFlBQVksQ0FBQyxJQUFJLENBQUMsa0JBQWtCLENBQUM7WUFBRSxPQUFPO1FBRXhELElBQUksY0FBYyxHQUFXLElBQUksQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLDBCQUEwQixDQUFDLENBQUMsQ0FBQywwQkFBMEIsQ0FBQztRQUN0RyxJQUFJLGdCQUFnQixHQUFRLFFBQVEsQ0FBQyxnQkFBZ0IsQ0FBQyxHQUFHLEdBQUcsSUFBSSxDQUFDLE9BQU8sQ0FBQyxFQUFFLEdBQUcsY0FBYyxHQUFHLGNBQWMsR0FBRyw4QkFBOEIsQ0FBQyxDQUFDO1FBQ2hKLGdCQUFnQixDQUFDLE9BQU8sQ0FBQyxhQUFhLENBQUMsRUFBRTtZQUNyQyxhQUFhLENBQUMsS0FBSyxDQUFDLEdBQUcsR0FBRyxJQUFJLENBQUMsa0JBQWtCLENBQUMscUJBQXFCLEVBQUUsQ0FBQyxNQUFNLEdBQUcsQ0FBQyxHQUFHLGFBQWEsQ0FBQyxxQkFBcUIsRUFBRSxDQUFDLE1BQU0sR0FBRyxDQUFDLEdBQUcsSUFBSSxDQUFDO1lBQy9JLGFBQWEsQ0FBQyxLQUFLLENBQUMsVUFBVSxHQUFHLE9BQU8sQ0FBQztRQUM3QyxDQUFDLENBQUMsQ0FBQztJQUNQLENBQUM7SUFFRCxvRkFBb0Y7SUFFN0UsWUFBWSxDQUFDLFlBQTBCLEVBQUUsVUFBd0I7UUFDcEUsSUFBSSxRQUFRLEdBQVcsSUFBSSxDQUFDLFlBQVksQ0FBQyxZQUFZLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLFlBQVksQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLFVBQVUsQ0FBQyxHQUFHLENBQUM7UUFDekcsSUFBSSxRQUFRLEdBQVcsSUFBSSxDQUFDLFlBQVksQ0FBQyxZQUFZLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLFlBQVksQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLFVBQVUsQ0FBQyxHQUFHLENBQUM7UUFFekcsd0RBQXdEO1FBQ3hELFFBQVEsR0FBRyxJQUFJLENBQUMsR0FBRyxDQUFDLFFBQVEsRUFBRSxRQUFRLENBQUMsQ0FBQztRQUN4QyxRQUFRLEdBQUcsSUFBSSxDQUFDLEdBQUcsQ0FBQyxRQUFRLEVBQUUsUUFBUSxDQUFDLENBQUM7UUFFeEMsSUFBSSxRQUFRLEdBQVcsRUFBRSxDQUFDLEdBQUcsQ0FBQyxDQUFDLFlBQVksQ0FBQyxZQUFZLEVBQUUsWUFBWSxDQUFDLGlCQUFpQixDQUFDLENBQUMsQ0FBQztRQUUzRixJQUFJLENBQUMsUUFBUSxJQUFJLFFBQVEsSUFBSSxDQUFDO1lBQUUsUUFBUSxHQUFHLENBQUMsQ0FBQztRQUU3QywrR0FBK0c7UUFDL0csSUFBSSx3QkFBd0IsR0FBVyxDQUFDLFFBQVEsR0FBRyxRQUFRLENBQUMsR0FBRyxJQUFJLENBQUM7UUFDcEUsSUFBSSx3QkFBd0IsR0FBRyxRQUFRLEVBQUU7WUFDckMsUUFBUSxHQUFHLElBQUksQ0FBQyxVQUFVLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsd0JBQXdCLENBQUMsQ0FBQyxDQUFDLENBQUMsd0JBQXdCLENBQUM7U0FDMUc7UUFFRCxPQUFPO1lBQ0gsUUFBUSxFQUFFLFFBQVE7WUFDbEIsUUFBUSxFQUFFLFFBQVE7WUFDbEIsUUFBUSxFQUFFLFFBQVE7U0FDckIsQ0FBQztJQUNOLENBQUM7SUFFTSxlQUFlLENBQUMsU0FBaUI7UUFDcEMsSUFBSSxZQUFZLEdBQVcsSUFBSSxDQUFDLGdCQUFnQixDQUFDLFNBQVMsQ0FBQyxDQUFDO1FBQzVELElBQUksQ0FBQyxhQUFhLEdBQUcsSUFBSSxDQUFDLFdBQVcsQ0FBQyxTQUFTLEVBQUUsWUFBWSxDQUFDLENBQUM7SUFDbkUsQ0FBQztJQUVNLGlCQUFpQixDQUFDLFlBQTBCLEVBQUUsTUFBYztRQUMvRCxPQUFPLElBQUksQ0FBQyxZQUFZLENBQUMsWUFBWSxDQUFDLE1BQU0sQ0FBQyxNQUFNLEVBQUUsTUFBTSxFQUFFLEtBQUssRUFBRSxJQUFJLENBQUMsYUFBYSxDQUFDLENBQUM7SUFDNUYsQ0FBQztJQUVEOzs7OztPQUtHO0lBQ0ksaUJBQWlCLENBQUMsTUFBYyxFQUFFLE1BQWM7UUFDbkQsNkNBQTZDO1FBRTdDLElBQUksV0FBVyxHQUFpQixJQUFJLENBQUMsT0FBTyxDQUFDLEtBQUssQ0FBQztRQUVuRCwwRkFBMEY7UUFDMUYsSUFBSSxhQUFhLEdBQVEsSUFBSSxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsU0FBUyxHQUFHLE1BQU0sQ0FBQyxDQUFDO1FBQ2pFLElBQUksSUFBSSxHQUFXLElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxXQUFXLEVBQUUsTUFBTSxDQUFDLENBQUM7UUFFL0QsdUNBQXVDO1FBQ3ZDLElBQUksYUFBYSxDQUFDLEtBQUssRUFBRTtZQUFFLGFBQWEsR0FBRyxJQUFJLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsQ0FBQztRQUVwRSxJQUFJLENBQUMsZUFBZSxDQUFDLGFBQWEsRUFBRSxNQUFNLENBQUMsTUFBTSxDQUFDLEVBQUUsRUFBRSxXQUFXLENBQUMsTUFBTSxDQUFDLEtBQUssRUFBRSxFQUFFLEtBQUssRUFBRSx5QkFBeUIsR0FBRyxNQUFNLEVBQUUsT0FBTyxFQUFFLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQztRQUU1SSxhQUFhLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDO1FBRXpCLE9BQU8sYUFBYSxDQUFDLElBQUksRUFBRSxDQUFDLE9BQU8sRUFBRSxDQUFDLEtBQUssQ0FBQztJQUNoRCxDQUFDO0lBRUQ7Ozs7OztPQU1HO0lBQ0ksWUFBWSxDQUFDLEtBQWdCLEVBQUUsUUFBMEI7UUFDNUQsSUFBSSxZQUFZLEdBQVksS0FBSyxLQUFLLEdBQUcsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxLQUFLLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLEtBQUssQ0FBQyxRQUFRLENBQUM7UUFDdEcsSUFBSSxRQUFRLEdBQVksWUFBWSxLQUFLLElBQUksQ0FBQyxNQUFNLENBQUM7UUFDckQsSUFBSSxxQkFBcUIsR0FBWSxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsS0FBSyxDQUFDLE9BQU8sSUFBSSxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxPQUFPLENBQUM7UUFFdkcsSUFBSSxLQUFLLEtBQUssR0FBRztZQUFFLElBQUksQ0FBQyxnQkFBZ0IsR0FBRyxJQUFJLENBQUMsMkJBQTJCLENBQUMsUUFBUSxDQUFDLENBQUM7UUFFdEYsSUFBSSx1QkFBdUIsR0FBeUMsSUFBSSxDQUFDLGdCQUFnQixDQUFDO1FBQzFGLElBQUkscUJBQXFCO1lBQUUsdUJBQXVCLEdBQUcsRUFBRSxPQUFPLEVBQUUsQ0FBQyxFQUFFLE9BQU8sRUFBRSxDQUFDLEVBQUUsQ0FBQztRQUVoRixJQUFJLENBQUMsSUFBSSxDQUFDLFNBQVMsRUFBRTtZQUNqQixJQUFJLEtBQUssS0FBSyxHQUFHLEVBQUU7Z0JBQ2YsSUFBSSxLQUFLLEdBQXFCLFFBQVEsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUM7Z0JBQzFELElBQUksR0FBRyxHQUFxQixRQUFRLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDO2dCQUN4RCxJQUFJLENBQUMsVUFBVSxDQUFDLEtBQUssQ0FBQyxHQUFHLElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxDQUFDLEdBQUcsSUFBSSxDQUFDLEdBQUcsQ0FBQyx1QkFBdUIsQ0FBQyxPQUFPLEVBQUUsdUJBQXVCLENBQUMsT0FBTyxDQUFDLENBQUM7Z0JBQy9ILElBQUksQ0FBQyxVQUFVLENBQUMsR0FBRyxDQUFDLEdBQUcsSUFBSSxDQUFDLGlCQUFpQixDQUFDLE9BQU8sQ0FBQztnQkFDdEQsT0FBTyxJQUFJLENBQUMsUUFBUSxDQUFDLEtBQUssR0FBRyxJQUFJLENBQUMsVUFBVSxDQUFDLEtBQUssQ0FBQyxHQUFHLElBQUksQ0FBQyxVQUFVLENBQUMsR0FBRyxDQUFDLENBQUM7YUFDOUU7aUJBQU07Z0JBQ0gsSUFBSSxLQUFLLEdBQXFCLFlBQVksQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUM7Z0JBQzlELElBQUksR0FBRyxHQUFxQixZQUFZLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDO2dCQUM1RCxJQUFJLGFBQWEsR0FBVyxxQkFBcUIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsdUJBQXVCLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxRQUFRLENBQUMsQ0FBQztnQkFDL0gsSUFBSSxDQUFDLFVBQVUsQ0FBQyxHQUFHLENBQUMsR0FBRyxJQUFJLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxDQUFDLEVBQUUsR0FBRyxHQUFHLGFBQWEsQ0FBQyxDQUFDO2dCQUMvRSxJQUFJLENBQUMsVUFBVSxDQUFDLEtBQUssQ0FBQyxHQUFHLElBQUksQ0FBQyxlQUFlLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxHQUFHLENBQUM7Z0JBQ2xHLE9BQU8sSUFBSSxDQUFDLFFBQVEsQ0FBQyxNQUFNLEdBQUcsSUFBSSxDQUFDLFVBQVUsQ0FBQyxLQUFLLENBQUMsR0FBRyxJQUFJLENBQUMsVUFBVSxDQUFDLEdBQUcsQ0FBQyxDQUFDO2FBQy9FO1NBQ0o7YUFBTTtZQUNILElBQUksS0FBSyxLQUFLLEdBQUcsRUFBRTtnQkFDZixJQUFJLEtBQUssR0FBcUIsWUFBWSxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQztnQkFDOUQsSUFBSSxHQUFHLEdBQXFCLFlBQVksQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUM7Z0JBQzVELElBQUksYUFBYSxHQUFXLHFCQUFxQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyx1QkFBdUIsQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLFFBQVEsQ0FBQyxDQUFDO2dCQUMvSCxJQUFJLENBQUMsVUFBVSxDQUFDLEtBQUssQ0FBQyxHQUFHLElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxHQUFHLENBQUM7Z0JBQ3BELElBQUksQ0FBQyxVQUFVLENBQUMsR0FBRyxDQUFDLEdBQUcsSUFBSSxDQUFDLGlCQUFpQixDQUFDLENBQUMsR0FBRyxhQUFhLENBQUM7Z0JBQ2hFLE9BQU8sSUFBSSxDQUFDLFFBQVEsQ0FBQyxNQUFNLEdBQUcsSUFBSSxDQUFDLFVBQVUsQ0FBQyxLQUFLLENBQUMsR0FBRyxJQUFJLENBQUMsVUFBVSxDQUFDLEdBQUcsQ0FBQyxDQUFDO2FBQy9FO2lCQUFNO2dCQUNILElBQUksS0FBSyxHQUFxQixRQUFRLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDO2dCQUMxRCxJQUFJLEdBQUcsR0FBcUIsUUFBUSxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQztnQkFDeEQsSUFBSSxlQUFlLEdBQVcsUUFBUSxLQUFLLElBQUksQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDLHVCQUF1QixDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsdUJBQXVCLENBQUMsT0FBTyxDQUFDO2dCQUNoSSxJQUFJLGFBQWEsR0FBVyxRQUFRLEtBQUssSUFBSSxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUMsdUJBQXVCLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyx1QkFBdUIsQ0FBQyxPQUFPLENBQUM7Z0JBQzlILElBQUksQ0FBQyxVQUFVLENBQUMsS0FBSyxDQUFDLEdBQUcsSUFBSSxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsaUJBQWlCLENBQUMsQ0FBQyxFQUFFLGVBQWUsR0FBRyxDQUFDLENBQUMsQ0FBQztnQkFDakYsSUFBSSxDQUFDLFVBQVUsQ0FBQyxHQUFHLENBQUMsR0FBRyxJQUFJLENBQUMsZUFBZSxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxDQUFDLEVBQUUsYUFBYSxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxhQUFhLEdBQUcsQ0FBQyxHQUFHLElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxPQUFPLENBQUM7Z0JBQ3pKLE9BQU8sSUFBSSxDQUFDLFFBQVEsQ0FBQyxLQUFLLEdBQUcsSUFBSSxDQUFDLFVBQVUsQ0FBQyxLQUFLLENBQUMsR0FBRyxJQUFJLENBQUMsVUFBVSxDQUFDLEdBQUcsQ0FBQyxDQUFDO2FBQzlFO1NBQ0o7SUFDTCxDQUFDO0lBRUQ7Ozs7Ozs7Ozs7T0FVRztJQUNJLGlCQUFpQixDQUFDLE1BQWMsRUFBRSxTQUFpQixFQUFFLDBCQUFtQyxFQUFFLFNBQXdCO1FBQ3JILDZCQUE2QjtRQUM3QixJQUFJLE1BQU0sS0FBSyxDQUFDO1lBQUUsT0FBTyxNQUFNLENBQUM7UUFFaEMsSUFBSSxhQUFhLEdBQVcsSUFBSSxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsTUFBTSxDQUFDLEVBQUUsSUFBSSxDQUFDLGdCQUFnQixDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUM7UUFFdEcsSUFBSSxhQUFhLEtBQUssQ0FBQyxFQUFFO1lBQ3JCLHFFQUFxRTtZQUNyRSxNQUFNLEdBQUcsTUFBTSxHQUFHLElBQUksQ0FBQyxHQUFHLENBQUMsRUFBRSxFQUFFLGFBQWEsQ0FBQyxDQUFDO1lBQzlDLFNBQVMsR0FBRyxTQUFTLEdBQUcsSUFBSSxDQUFDLEdBQUcsQ0FBQyxFQUFFLEVBQUUsYUFBYSxDQUFDLENBQUM7U0FDdkQ7UUFFRCxJQUFJLElBQUksR0FBVyxJQUFJLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDO1FBQ3JDLElBQUksUUFBUSxHQUFXLE1BQU0sR0FBRyxNQUFNLEdBQUcsU0FBUyxDQUFDO1FBRW5ELElBQUksU0FBUyxLQUFLLElBQUksRUFBRTtZQUNwQixJQUFJLElBQUksR0FBRyxDQUFDLEVBQUU7Z0JBQ1YsSUFBSSxDQUFDLDBCQUEwQjtvQkFBRSxRQUFRLEdBQUcsUUFBUSxHQUFHLFNBQVMsQ0FBQzthQUNwRTtpQkFBTTtnQkFDSCxJQUFJLDBCQUEwQjtvQkFBRSxRQUFRLEdBQUcsUUFBUSxHQUFHLFNBQVMsQ0FBQzthQUNuRTtTQUNKO2FBQU07WUFDSCxJQUFJLElBQUksR0FBRyxDQUFDLEVBQUU7Z0JBQ1YsSUFBSSwwQkFBMEI7b0JBQUUsUUFBUSxHQUFHLFFBQVEsR0FBRyxTQUFTLENBQUM7YUFDbkU7aUJBQU07Z0JBQ0gsSUFBSSxDQUFDLDBCQUEwQjtvQkFBRSxRQUFRLEdBQUcsUUFBUSxHQUFHLFNBQVMsQ0FBQzthQUNwRTtTQUNKO1FBRUQsSUFBSSxhQUFhLEtBQUssQ0FBQztZQUFFLFFBQVEsR0FBRyxRQUFRLEdBQUcsSUFBSSxDQUFDLEdBQUcsQ0FBQyxFQUFFLEVBQUUsYUFBYSxDQUFDLENBQUM7UUFFM0UsT0FBTyxRQUFRLENBQUM7SUFDcEIsQ0FBQztJQUVNLGFBQWEsQ0FBQyxJQUFZLEVBQUUsSUFBWSxFQUFFLFNBQWlCO1FBQzlELElBQUksQ0FBQyxTQUFTLElBQUksT0FBTyxJQUFJLEtBQUssV0FBVyxJQUFJLE9BQU8sSUFBSSxLQUFLLFdBQVc7WUFBRSxPQUFPLEVBQUUsQ0FBQztRQUV4RixJQUFJLEdBQUcsSUFBSSxDQUFDLDJCQUEyQixDQUFDLElBQUksRUFBRSxTQUFTLENBQUMsQ0FBQztRQUV6RCxPQUFPLEVBQUUsQ0FBQyxLQUFLLENBQUMsSUFBSSxFQUFFLElBQUksRUFBRSxTQUFTLENBQUMsQ0FBQztJQUMzQyxDQUFDO0lBRUQ7Ozs7T0FJRztJQUNJLGtCQUFrQixDQUFDLEtBQVUsRUFBRSxVQUFxQjtRQUN2RCxJQUFJLE9BQU8sR0FBVyxVQUFVLEdBQUcsTUFBTSxDQUFDO1FBQzFDLElBQUksQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLE9BQU8sQ0FBQztZQUFFLE9BQU87UUFDbkMsSUFBSSxVQUFVLEdBQUcsSUFBSSxDQUFDLE9BQU8sQ0FBQyxPQUFPLENBQUMsQ0FBQztRQUV2QyxLQUFLLENBQUMsU0FBUyxDQUFDLE1BQU0sQ0FBQzthQUNsQixJQUFJLENBQUMsY0FBYyxFQUFFLFVBQVUsQ0FBQyxTQUFTLENBQUM7YUFDMUMsSUFBSSxDQUFDLFFBQVEsRUFBRSxVQUFVLENBQUMsU0FBUyxDQUFDLENBQUM7UUFFMUMsS0FBSyxDQUFDLFNBQVMsQ0FBQyxNQUFNLENBQUM7YUFDbEIsSUFBSSxDQUFDLGNBQWMsRUFBRSxVQUFVLENBQUMsU0FBUyxDQUFDO2FBQzFDLElBQUksQ0FBQyxRQUFRLEVBQUUsVUFBVSxDQUFDLFNBQVMsQ0FBQyxDQUFDO1FBRTFDLElBQUksVUFBVSxLQUFLLEdBQUcsSUFBSSxDQUFDLFVBQVUsQ0FBQyxPQUFPLElBQUksQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLE9BQU8sQ0FBQyxDQUFDLE1BQU0sQ0FBQyxPQUFPLEVBQUU7WUFDcEYsSUFBSSxDQUFDLGVBQWUsQ0FBQyxLQUFLLENBQUMsU0FBUyxDQUFDLE1BQU0sQ0FBQyxFQUFFLEVBQUUsT0FBTyxFQUFFLE1BQU0sRUFBRSxDQUFDLENBQUM7U0FDdEU7YUFBTTtZQUNILElBQUksQ0FBQyxlQUFlLENBQUMsS0FBSyxDQUFDLFNBQVMsQ0FBQyxNQUFNLENBQUMsRUFBRSxVQUFVLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxDQUFDO1lBQ3ZFLElBQUksQ0FBQyxlQUFlLENBQUMsS0FBSyxDQUFDLFNBQVMsQ0FBQyxNQUFNLENBQUMsRUFBRSxFQUFFLEtBQUssRUFBRSxnRUFBZ0UsRUFBRSxDQUFDLENBQUM7U0FDOUg7SUFDTCxDQUFDO0lBRU0sMkJBQTJCLENBQUMsUUFBMEI7UUFDekQsSUFBSSxRQUFRLEdBQXFCLEVBQUUsT0FBTyxFQUFFLENBQUMsRUFBRSxPQUFPLEVBQUUsQ0FBQyxFQUFFLENBQUM7UUFFNUQsMkNBQTJDO1FBQzNDLFFBQVEsQ0FBQyxPQUFPLEdBQUcsSUFBSSxDQUFDLGlCQUFpQixDQUFDLFFBQVEsQ0FBQyxPQUFPLEVBQUUsU0FBUyxDQUFDLENBQUM7UUFDdkUsUUFBUSxDQUFDLE9BQU8sR0FBRyxJQUFJLENBQUMsaUJBQWlCLENBQUMsUUFBUSxDQUFDLE9BQU8sRUFBRSxTQUFTLENBQUMsQ0FBQztRQUN2RSxJQUFJO1FBRUosT0FBTyxRQUFRLENBQUM7SUFDcEIsQ0FBQztJQUVPLDJCQUEyQixDQUFDLElBQVksRUFBRSxTQUFpQjtRQUMvRCxJQUFJLGFBQWEsR0FBVyxJQUFJLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxJQUFJLENBQUMsRUFBRSxJQUFJLENBQUMsZ0JBQWdCLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQztRQUVwRyxJQUFJLEdBQUcsSUFBSSxHQUFHLElBQUksQ0FBQyxHQUFHLENBQUMsRUFBRSxFQUFFLGFBQWEsQ0FBQyxDQUFDO1FBQzFDLFNBQVMsR0FBRyxTQUFTLEdBQUcsSUFBSSxDQUFDLEdBQUcsQ0FBQyxFQUFFLEVBQUUsYUFBYSxDQUFDLENBQUM7UUFFcEQsT0FBTyxDQUFDLElBQUksR0FBRyxTQUFTLENBQUMsR0FBRyxJQUFJLENBQUMsR0FBRyxDQUFDLEVBQUUsRUFBRSxhQUFhLENBQUMsQ0FBQztJQUM1RCxDQUFDO0lBRUQsb0ZBQW9GO0lBRXBGOzs7OztPQUtHO0lBQ0kscUJBQXFCLENBQUMsa0JBQTBCLEVBQUU7UUFDckQsSUFBSSxDQUFDLG1CQUFtQixHQUFHLEVBQUUsQ0FBQyxNQUFNLENBQUMsR0FBRyxHQUFHLElBQUksQ0FBQyxPQUFPLENBQUMsRUFBRSxHQUFHLDhDQUE4QyxHQUFHLGVBQWUsQ0FBQyxDQUFDO1FBQy9ILElBQUksQ0FBQyxJQUFJLENBQUMsWUFBWSxDQUFDLElBQUksQ0FBQyxtQkFBbUIsQ0FBQyxJQUFJLEVBQUUsQ0FBQztZQUFFLE9BQU87UUFFaEUsT0FBTyxJQUFJLENBQUMsbUJBQW1CLENBQUM7SUFDcEMsQ0FBQztJQUVELCtCQUErQjtJQUV4QixpQkFBaUIsQ0FBQyxHQUFXLEVBQUUsU0FBaUIsRUFBRSxZQUFvQjtRQUN6RSxJQUFJLENBQUMseUJBQXlCLENBQUMsR0FBRyxDQUFDLENBQUM7UUFDcEMsSUFBSSxDQUFDLHFCQUFxQixDQUFDLFlBQVksQ0FBQyxDQUFDO1FBQ3pDLElBQUksQ0FBQyxRQUFRLEdBQUcsSUFBSSxDQUFDLFlBQVksQ0FBQyxJQUFJLENBQUMsU0FBUyxFQUFFLFNBQVMsRUFBRSxJQUFJLENBQUMsWUFBWSxDQUFDLENBQUM7UUFDaEYsSUFBSSxDQUFDLHVCQUF1QixDQUFDLFNBQVMsQ0FBQyxDQUFDO0lBQzVDLENBQUM7SUFFTSxxQkFBcUIsQ0FBQyxZQUFvQjtRQUM3QyxJQUFJLENBQUMsSUFBSSxDQUFDLGVBQWU7WUFBRSxPQUFPO1FBQ2xDLFlBQVksR0FBRyxJQUFJLENBQUMscUJBQXFCLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLE1BQU0sRUFBRSxZQUFZLENBQUMsQ0FBQztRQUN6RixJQUFJLENBQUMsc0JBQXNCLENBQUMsWUFBWSxDQUFDLENBQUM7SUFDOUMsQ0FBQztJQUVNLHFCQUFxQjtRQUN4QixJQUFJLENBQUMsSUFBSSxDQUFDLGVBQWU7WUFBRSxPQUFPLENBQUMsQ0FBQztRQUNwQyxPQUFPLElBQUksQ0FBQyxlQUFlLENBQUMscUJBQXFCLEVBQUUsQ0FBQztJQUN4RCxDQUFDO0lBRU8seUJBQXlCLENBQUMsR0FBVztRQUN6QyxJQUFJLE9BQU8sSUFBSSxDQUFDLGVBQWUsS0FBSyxXQUFXLEVBQUU7WUFDN0MsSUFBSSxDQUFDLGVBQWUsR0FBRyxRQUFRLENBQUMsYUFBYSxDQUFDLEdBQUcsR0FBRyxHQUFHLEdBQUcsOENBQThDLENBQUMsQ0FBQztTQUM3RztJQUNMLENBQUM7SUFFTyxzQkFBc0IsQ0FBQyxLQUFhO1FBQ3hDLElBQUksQ0FBQyxJQUFJLENBQUMsZUFBZTtZQUFFLE9BQU87UUFDbEMsSUFBSSxDQUFDLGVBQWUsQ0FBQyxTQUFTLEdBQUcsS0FBSyxDQUFDO0lBQzNDLENBQUM7SUFFTyx1QkFBdUIsQ0FBQyxTQUFpQjtRQUM3QyxJQUFJLENBQUMsSUFBSSxDQUFDLFNBQVMsSUFBSSxDQUFDLElBQUksQ0FBQyxRQUFRLEVBQUU7WUFDbkMsSUFBSSxDQUFDLGVBQWUsQ0FBQyxLQUFLLENBQUMsUUFBUSxHQUFHLFNBQVMsR0FBRyxJQUFJLENBQUM7U0FDMUQ7SUFDTCxDQUFDO0lBRUQscUJBQXFCO0lBRWIsWUFBWSxDQUFDLFNBQWtCLEVBQUUsU0FBaUIsRUFBRSxZQUFvQjtRQUM1RSxrRkFBa0Y7UUFDbEYsSUFBSSxTQUFTLElBQUksWUFBWSxJQUFJLFNBQVM7WUFBRSxPQUFPLEtBQUssQ0FBQztRQUN6RCwrRkFBK0Y7UUFDL0YsT0FBTyxJQUFJLENBQUMscUJBQXFCLEVBQUUsQ0FBQyxLQUFLLEdBQUcsU0FBUyxDQUFDO0lBQzFELENBQUM7SUFFTSxtQkFBbUI7UUFDdEIsSUFBSSxhQUFhLEdBQVcsSUFBSSxDQUFDLHFCQUFxQixFQUFFLENBQUMsS0FBSyxJQUFJLENBQUMsRUFDL0QsYUFBYSxHQUFRLElBQUksQ0FBQyxjQUFjLEVBQ3hDLFNBQVMsR0FBVyxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLGFBQWEsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLGFBQWEsQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLEVBQ3RGLFdBQVcsR0FBVyxJQUFJLENBQUMsR0FBRyxDQUFDLGFBQWEsRUFBRSxHQUFHLEdBQUcsU0FBUyxDQUFDLENBQUM7UUFFbkUsSUFBSSxDQUFDLFlBQVksR0FBRyxXQUFXLENBQUM7SUFDcEMsQ0FBQztJQUVPLGNBQWMsQ0FBQyxTQUFrQixFQUFFLFNBQWtCO1FBQ3pELElBQUksVUFBVSxHQUFrRCxFQUFFLEdBQUcsRUFBRSxDQUFDLEVBQUUsSUFBSSxFQUFFLENBQUMsRUFBRSxLQUFLLEVBQUUsQ0FBQyxFQUFFLENBQUM7UUFDOUYsSUFBSSxRQUFRLEdBQVksSUFBSSxDQUFDLE9BQU8sQ0FBQyxLQUFLLENBQUMsUUFBUSxJQUFJLEtBQUssQ0FBQztRQUU3RCxJQUFJLENBQUMsU0FBUyxFQUFFO1lBQ1osSUFBSSxVQUFVLEdBQVcsQ0FBQyxDQUFDO1lBQzNCLElBQUksSUFBSSxHQUFxQixJQUFJLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQztZQUM1RCxJQUFJLElBQUksR0FBVyxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO1lBQ3hDLFFBQVEsR0FBRyxRQUFRLEtBQUssSUFBSSxDQUFDLE1BQU0sQ0FBQztZQUVwQyxJQUFJLENBQUMsUUFBUSxJQUFJLElBQUksQ0FBQyxZQUFZLENBQUMsSUFBSSxDQUFDLGtCQUFrQixDQUFDLEVBQUU7Z0JBQ3pELFVBQVUsR0FBRyxJQUFJLENBQUMsa0JBQWtCLENBQUMscUJBQXFCLEVBQUUsQ0FBQyxLQUFLLENBQUM7YUFDdEU7WUFFRCxVQUFVLENBQUMsSUFBSSxDQUFDLEdBQUcsSUFBSSxHQUFHLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxJQUFJLEdBQUcsVUFBVSxDQUFDLENBQUM7U0FDakU7YUFBTTtZQUNILFVBQVUsQ0FBQyxHQUFHLEdBQUcsSUFBSSxDQUFDLFVBQVUsQ0FBQyxHQUFHLENBQUM7WUFDckMsSUFBSSxRQUFRO2dCQUFFLFVBQVUsQ0FBQyxHQUFHLElBQUksSUFBSSxDQUFDLG9CQUFvQixFQUFFLENBQUM7WUFFNUQsVUFBVSxDQUFDLEtBQUssR0FBRyxDQUFDLENBQUM7U0FDeEI7UUFDRCxPQUFPLFVBQVUsQ0FBQztJQUN0QixDQUFDO0lBRU0sMEJBQTBCLENBQUMsVUFBZTtRQUM3QyxJQUFJLFNBQVMsR0FBdUIsSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUM7UUFDeEUsSUFBSSxRQUFRLEdBQVcsSUFBSSxDQUFDLFdBQVcsQ0FBQztRQUV4QyxJQUFJLENBQUMsSUFBSSxDQUFDLFNBQVMsSUFBSSxDQUFDLElBQUksQ0FBQyxRQUFRLEVBQUU7WUFDbkMsUUFBUSxHQUFHLElBQUksQ0FBQyxxQkFBcUIsRUFBRSxDQUFDLE1BQU0sQ0FBQztTQUNsRDtRQUVELFVBQVUsQ0FBQyxLQUFLLENBQUMsU0FBUyxFQUFFLFFBQVEsR0FBRyxJQUFJLENBQUMsQ0FBQztRQUM3QyxJQUFJLENBQUMsSUFBSSxDQUFDLFNBQVM7WUFBRSxVQUFVLENBQUMsS0FBSyxDQUFDLE9BQU8sRUFBRSxNQUFNLENBQUMsQ0FBQztRQUV2RCxJQUFJLENBQUMsZUFBZSxDQUFDLEtBQUssQ0FBQyxRQUFRLEdBQUcsTUFBTSxDQUFDO1FBRzdDLElBQUksTUFBTSxHQUFrRCxJQUFJLENBQUMsY0FBYyxDQUFDLElBQUksQ0FBQyxTQUFTLEVBQUUsSUFBSSxDQUFDLFFBQVEsQ0FBQyxDQUFDO1FBRS9HLFVBQVU7YUFDTCxLQUFLLENBQUMsWUFBWSxFQUFFLE1BQU0sQ0FBQyxHQUFHLEdBQUcsSUFBSSxDQUFDO2FBQ3RDLEtBQUssQ0FBQyxjQUFjLEVBQUUsTUFBTSxDQUFDLEtBQUssR0FBRyxJQUFJLENBQUM7YUFDMUMsS0FBSyxDQUFDLGFBQWEsRUFBRSxNQUFNLENBQUMsSUFBSSxHQUFHLElBQUksQ0FBQyxDQUFDO1FBRTlDLElBQUksQ0FBQyw2QkFBNkIsR0FBRyxNQUFNLENBQUMsSUFBSSxDQUFDO0lBQ3JELENBQUM7SUFFRDs7Ozs7T0FLRztJQUNJLG9CQUFvQixDQUFDLGVBQW9CLEVBQUUsUUFBZ0IsRUFBRSxjQUF1QztRQUN2RyxJQUFJLElBQUksQ0FBQyxTQUFTLElBQUksY0FBYyxDQUFDLFFBQVEsSUFBSSxDQUFDLGNBQWMsQ0FBQyxNQUFNLElBQUksSUFBSSxDQUFDLFdBQVcsS0FBSyxRQUFRLENBQUMsRUFBRTtZQUN2RyxJQUFJLENBQUMsT0FBTyxDQUFDLFFBQVEsQ0FBQyxlQUFlLENBQUMsSUFBSSxFQUFFLEVBQUUsVUFBVSxDQUFDLENBQUM7U0FDN0Q7UUFFRCx5SUFBeUk7UUFDekksc0NBQXNDO1FBQ3RDLElBQUksY0FBYyxDQUFDLFFBQVE7WUFBRSxlQUFlLENBQUMsS0FBSyxDQUFDLFNBQVMsRUFBRSxDQUFDLENBQUMsQ0FBQztRQUVqRSxJQUFJLFNBQVMsR0FBUSxlQUFlLENBQUMsSUFBSSxFQUFFLENBQUMscUJBQXFCLEVBQUUsRUFDL0QsTUFBTSxHQUFXLENBQUMsSUFBSSxDQUFDLFNBQVMsSUFBSSxDQUFDLGNBQWMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxLQUFLLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUMsTUFBTSxHQUFHLENBQUMsRUFDekcsVUFBVSxHQUFXLGNBQWMsQ0FBQyxRQUFRLElBQUksY0FBYyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFDaEYsUUFBUSxHQUFXLFFBQVEsR0FBRyxNQUFNLEdBQUcsVUFBVSxDQUFDO1FBRXRELHFCQUFxQjtRQUNyQixJQUFJLElBQUksQ0FBQyxTQUFTLEVBQUU7WUFDaEIsSUFBSSxRQUFRLEdBQVcsSUFBSSxDQUFDLE1BQU0sS0FBSyxjQUFjLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQztZQUNsRixlQUFlO2lCQUNWLEtBQUssQ0FBQyxLQUFLLEVBQUUsUUFBUSxHQUFHLElBQUksQ0FBQztpQkFDN0IsS0FBSyxDQUFDLFFBQVEsRUFBRSxDQUFDLEdBQUcsSUFBSSxDQUFDLENBQUM7WUFDL0IsT0FBTztTQUNWO1FBRUQsSUFBSSxPQUFPLEdBQVcsY0FBYyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUM7UUFFakUsNEJBQTRCO1FBQzVCLElBQUksY0FBYyxDQUFDLFFBQVEsRUFBRTtZQUN6QixJQUFJLFFBQVEsR0FBVyxjQUFjLENBQUMsUUFBUSxJQUFJLENBQUMsY0FBYyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO1lBRWpHLGVBQWU7aUJBQ1YsS0FBSyxDQUFDLE9BQU8sRUFBRSxRQUFRLEdBQUcsSUFBSSxDQUFDO2lCQUMvQixLQUFLLENBQUMsV0FBVyxFQUFFLGdCQUFnQixDQUFDLENBQUM7U0FFN0M7YUFBTTtZQUNILElBQUksSUFBSSxDQUFDLFdBQVcsS0FBSyxRQUFRLEVBQUU7Z0JBQy9CLGtHQUFrRztnQkFDbEcsSUFBSSxRQUFRLEdBQUcsSUFBSSxDQUFDLDZCQUE2QixHQUFHLENBQUMsRUFBRTtvQkFDbkQsSUFBSSxJQUFJLEdBQVcsSUFBSSxDQUFDLEdBQUcsQ0FBQyxRQUFRLENBQUMsR0FBRyxJQUFJLENBQUMsNkJBQTZCLENBQUM7b0JBQzNFLGVBQWUsQ0FBQyxLQUFLLENBQUMsV0FBVyxFQUFFLENBQUMsU0FBUyxDQUFDLEtBQUssR0FBRyxDQUFDLEdBQUcsSUFBSSxDQUFDLEdBQUcsSUFBSSxDQUFDLENBQUM7b0JBQ3hFLFFBQVEsR0FBRyxDQUFDLENBQUMsR0FBRyxJQUFJLENBQUMsNkJBQTZCLENBQUM7aUJBQ3REO2dCQUNELElBQUksY0FBYyxDQUFDLE1BQU07b0JBQUUsZUFBZSxDQUFDLEtBQUssQ0FBQyxXQUFXLEVBQUUsQ0FBQyxTQUFTLENBQUMsS0FBSyxHQUFHLENBQUMsR0FBRyxJQUFJLENBQUMsVUFBVSxDQUFDLEtBQUssQ0FBQyxHQUFHLElBQUksQ0FBQyxDQUFDO2FBQ3ZIO1lBRUQsZUFBZSxDQUFDLEtBQUssQ0FBQyxPQUFPLEVBQUUsQ0FBQyxHQUFHLElBQUksQ0FBQyxDQUFDO1NBQzVDO1FBRUQsZUFBZSxDQUFDLEtBQUssQ0FBQyxNQUFNLEVBQUUsUUFBUSxHQUFHLElBQUksQ0FBQyxDQUFDO0lBQ25ELENBQUM7SUFFRCxtRkFBbUY7SUFFbkY7Ozs7T0FJRztJQUNJLG1CQUFtQixDQUFDLG1CQUF3QixFQUFFLG1CQUF5QjtRQUMxRSxJQUFJLHNCQUFzQixHQUFHLElBQUksQ0FBQyxZQUFZLENBQUMsbUJBQW1CLENBQUMsQ0FBQyxDQUFDLENBQUMsbUJBQW1CLENBQUMsSUFBSSxFQUFFLENBQUMscUJBQXFCLEVBQUUsQ0FBQyxDQUFDLENBQUMsRUFBRSxLQUFLLEVBQUUsQ0FBQyxFQUFFLE1BQU0sRUFBRSxDQUFDLEVBQUUsQ0FBQztRQUVuSixJQUFJLElBQUksR0FBVyxJQUFJLENBQUMsdUJBQXVCLENBQUMsc0JBQXNCLENBQUMsS0FBSyxDQUFDLENBQUM7UUFDOUUsSUFBSSxHQUFHLEdBQVcsSUFBSSxDQUFDLHNCQUFzQixDQUFDLHNCQUFzQixDQUFDLE1BQU0sQ0FBQyxDQUFDO1FBRTdFLG1CQUFtQjthQUNkLEtBQUssQ0FBQyxNQUFNLEVBQUUsSUFBSSxHQUFHLElBQUksQ0FBQzthQUMxQixLQUFLLENBQUMsS0FBSyxFQUFFLEdBQUcsR0FBRyxJQUFJLENBQUMsQ0FBQztJQUNsQyxDQUFDO0lBRU8sdUJBQXVCLENBQUMsV0FBVztRQUN2QyxJQUFJLFFBQVEsR0FBWSxJQUFJLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLEtBQUssQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsS0FBSyxDQUFDLFFBQVEsQ0FBQztRQUNuRyxJQUFJLGVBQWUsR0FBVyxJQUFJLENBQUMsT0FBTyxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDO1FBRTdELHNFQUFzRTtRQUN0RSwrR0FBK0c7UUFDL0csSUFBSSxRQUFRLEtBQUssSUFBSSxDQUFDLE1BQU0sSUFBSSxDQUFDLElBQUksQ0FBQyxlQUFlLEVBQUU7WUFDbkQsT0FBTyxJQUFJLENBQUMsVUFBVSxDQUFDLElBQUksR0FBRyxJQUFJLENBQUMsdUJBQXVCLENBQUMsZUFBZSxDQUFDLENBQUM7U0FDL0U7UUFFRCw2QkFBNkI7UUFDN0IsSUFBSSxVQUFVLEdBQVcsSUFBSSxDQUFDLFlBQVksQ0FBQyxJQUFJLENBQUMsa0JBQWtCLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLGtCQUFrQixDQUFDLHFCQUFxQixFQUFFLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7UUFDaEksSUFBSSxJQUFJLEdBQVcsSUFBSSxDQUFDLHVCQUF1QixDQUFDLGVBQWUsQ0FBQyxDQUFDO1FBRWpFLElBQUksSUFBSSxJQUFJLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxVQUFVLEdBQUcsV0FBVyxHQUFHLElBQUksQ0FBQyxVQUFVLENBQUMsSUFBSSxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsVUFBVSxHQUFHLElBQUksQ0FBQyxVQUFVLENBQUMsSUFBSSxDQUFDO1FBRWpILE9BQU8sSUFBSSxDQUFDO0lBQ2hCLENBQUM7SUFFTyxzQkFBc0IsQ0FBQyxZQUFZO1FBQ3ZDLElBQUksUUFBUSxHQUFZLElBQUksQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsS0FBSyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxLQUFLLENBQUMsUUFBUSxDQUFDO1FBRW5HLG9DQUFvQztRQUNwQyw2R0FBNkc7UUFDN0csSUFBSSxDQUFDLFFBQVEsSUFBSSxDQUFDLElBQUksQ0FBQyxlQUFlLEVBQUU7WUFDcEMsT0FBTyxJQUFJLENBQUMsVUFBVSxDQUFDLEdBQUcsR0FBRyxJQUFJLENBQUMsdUJBQXVCLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDO1NBQzVGO1FBRUQsOEJBQThCO1FBQzlCLElBQUksZ0JBQWdCLEdBQVcsSUFBSSxDQUFDLG9CQUFvQixFQUFFLENBQUM7UUFDM0QsSUFBSSxHQUFHLEdBQVcsSUFBSSxDQUFDLHVCQUF1QixDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsQ0FBQztRQUU5RSxHQUFHLElBQUksSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsZ0JBQWdCLEdBQUcsSUFBSSxDQUFDLFVBQVUsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLGdCQUFnQixHQUFHLElBQUksQ0FBQyxVQUFVLENBQUMsR0FBRyxHQUFHLFlBQVksQ0FBQztRQUV2SCxPQUFPLEdBQUcsQ0FBQztJQUNmLENBQUM7SUFFTyxvQkFBb0I7UUFDeEIsSUFBSSxTQUFTLEdBQVcsR0FBRyxHQUFHLElBQUksQ0FBQyxPQUFPLENBQUMsRUFBRSxHQUFHLG9DQUFvQyxDQUFDO1FBQ3JGLFNBQVMsSUFBSSxJQUFJLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQztRQUMxQyxJQUFJLGlCQUFpQixHQUFHLFFBQVEsQ0FBQyxhQUFhLENBQUMsU0FBUyxDQUFDLENBQUM7UUFFMUQsT0FBTyxJQUFJLENBQUMsWUFBWSxDQUFDLGlCQUFpQixDQUFDLENBQUMsQ0FBQyxDQUFDLGlCQUFpQixDQUFDLHFCQUFxQixFQUFFLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7SUFDdkcsQ0FBQztJQUVELHlCQUF5QjtJQUVsQixtQkFBbUI7UUFDdEIsSUFBSSxVQUFVLEdBQThCLElBQUksQ0FBQyxPQUFPLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUM7UUFDNUUsSUFBSSxRQUFRLEdBQVcsSUFBSSxDQUFDLHVCQUF1QixDQUFDLFVBQVUsQ0FBQyxRQUFRLENBQUMsQ0FBQztRQUN6RSxJQUFJLFdBQVcsR0FBVyxJQUFJLENBQUMsdUJBQXVCLENBQUMsVUFBVSxDQUFDLFdBQVcsQ0FBQyxDQUFDO1FBQy9FLE9BQU8sUUFBUSxHQUFHLEdBQUcsR0FBRyxXQUFXLEdBQUcsQ0FBQyxDQUFDO0lBQzVDLENBQUM7SUFFTSxjQUFjLENBQUMsS0FBVSxFQUFFLFVBQWtCLEVBQUUsWUFBb0IsRUFBRSxXQUFtQixDQUFDO1FBQzVGLElBQUksUUFBUSxHQUFXLElBQUksQ0FBQyxtQkFBbUIsRUFBRSxHQUFHLFFBQVEsR0FBRyxDQUFDLENBQUM7UUFFakUsSUFBSSxLQUFLLEtBQUssS0FBSyxFQUFFO1lBQ2pCLE9BQU8sVUFBVSxHQUFHLFFBQVEsR0FBRyxJQUFJLENBQUMsc0JBQXNCLENBQUM7U0FDOUQ7YUFBTTtZQUNILE9BQU8sVUFBVSxHQUFHLFFBQVEsR0FBRyxZQUFZLEdBQUcsSUFBSSxDQUFDLHNCQUFzQixDQUFDO1NBQzdFO0lBQ0wsQ0FBQztJQUVNLG1CQUFtQixDQUFDLGNBQTJDLEVBQUUsVUFBa0MsRUFBRTtRQUN4RyxJQUFJLENBQUMsT0FBTyxDQUFDLFVBQVU7WUFBRSxPQUFPLEtBQUssQ0FBQztRQUN0QyxJQUFJLE9BQU8sQ0FBQyxTQUFTLEdBQUcsQ0FBQyxFQUFFO1lBQ3ZCLElBQUksY0FBYyxLQUFLLEtBQUs7Z0JBQUUsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLHlDQUF5QztTQUNyRjthQUFNO1lBQ0gsSUFBSSxjQUFjLEtBQUssUUFBUTtnQkFBRSxPQUFPLENBQUMsQ0FBQyxDQUFDLHlDQUF5QztTQUN2RjtRQUNELE9BQU8sS0FBSyxDQUFDO0lBQ2pCLENBQUM7SUFFRCxxSUFBcUk7SUFDOUgsdUJBQXVCLENBQUMsT0FBTyxFQUFFLE9BQU87UUFDM0MsSUFBSSxPQUFPLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxhQUFhO1lBQUUsT0FBTyxPQUFPLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxhQUFhLENBQUM7UUFDbEYsSUFBSSxZQUFZLEdBQWdDLEtBQUssQ0FBQztRQUN0RCwwREFBMEQ7UUFDMUQsSUFBSSxPQUFPLENBQUMsU0FBUyxHQUFHLENBQUM7WUFBRSxZQUFZLEdBQUcsUUFBUSxDQUFDO1FBQ25ELE9BQU8sWUFBWSxDQUFDO0lBQ3hCLENBQUM7SUFFRCwrRUFBK0U7SUFFL0U7Ozs7O09BS0c7SUFDSSxxQkFBcUIsQ0FBQyxPQUF3QjtRQUNqRCxPQUFPLGtGQUFrRixHQUFHLE9BQU8sR0FBRyxRQUFRLENBQUM7SUFDbkgsQ0FBQztJQUVNLHVCQUF1QixDQUFDLE1BQXVCO1FBQ2xELElBQUksT0FBTyxNQUFNLEtBQUssUUFBUTtZQUFFLE9BQU8sTUFBTSxDQUFDO1FBQzlDLE9BQU8sVUFBVSxDQUFDLE1BQU0sQ0FBQyxPQUFPLENBQUMsVUFBVSxFQUFFLEVBQUUsQ0FBQyxDQUFDLENBQUM7SUFDdEQsQ0FBQztJQUVNLGtCQUFrQixDQUFDLFVBQW9CO1FBQzFDLE9BQU8sVUFBVSxDQUFDLENBQUMsQ0FBQyxLQUFLLEtBQUssSUFBSSxDQUFDLFVBQVUsQ0FBQyxDQUFDLENBQUMsS0FBSyxPQUFPLElBQUksVUFBVSxDQUFDLENBQUMsQ0FBQyxLQUFLLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxZQUFZLENBQUMsQ0FBQyxDQUFDLFdBQVcsQ0FBQztJQUMxSCxDQUFDO0lBRU0sY0FBYyxDQUFDLEtBQWlDLEVBQUUsU0FBaUI7UUFDdEUsT0FBTztZQUNILEtBQUssRUFBRSxLQUFLLEtBQUssV0FBVyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFNBQVMsR0FBRyxDQUFDO1lBQ2hELEdBQUcsRUFBRSxLQUFLLEtBQUssV0FBVyxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztZQUMzQyxLQUFLLEVBQUUsS0FBSyxLQUFLLFdBQVcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsR0FBRyxFQUFFLEVBQUUsQ0FBQyxDQUFDLEdBQUcsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxHQUFHLEVBQUUsRUFBRSxDQUFDLENBQUMsR0FBRyxHQUFHO1lBQ3hFLE9BQU8sRUFBRSxLQUFLLEtBQUssV0FBVyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUMsR0FBRyxDQUFDO1NBQy9ELENBQUM7SUFDTixDQUFDO0lBRU0sUUFBUSxDQUFDLEtBQXlCLEVBQUUsT0FBcUI7UUFDNUQsSUFBSSxLQUFLLEdBQVc7WUFDaEIsS0FBSyxFQUFFLEVBQUU7WUFDVCxXQUFXLEVBQUUsRUFBRTtTQUNsQixDQUFDO1FBQ0YsSUFBSSxnQkFBZ0IsR0FBVyxDQUFDLENBQUM7UUFDakMsSUFBSSxnQkFBZ0IsR0FBWSxPQUFPLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDLFNBQVMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxJQUFJLE9BQU8sQ0FBQyxLQUFLLENBQUMsT0FBTyxJQUFJLE9BQU8sQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLE9BQU8sQ0FBQztRQUM3SSxJQUFJLGdCQUFnQjtZQUFFLElBQUksQ0FBQyx5QkFBeUIsQ0FBQyxPQUFPLENBQUMsRUFBRSxDQUFDLENBQUM7UUFFakUsS0FBSyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsRUFBRTtZQUNkLEtBQUssQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUM7WUFFNUIsMkVBQTJFO1lBQzNFLElBQUksZ0JBQWdCLEVBQUU7Z0JBQ2xCLElBQUksQ0FBQyxzQkFBc0IsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDO2dCQUN2QyxJQUFJLFlBQVksR0FBVyxJQUFJLENBQUMscUJBQXFCLEVBQUUsQ0FBQyxLQUFLLENBQUM7Z0JBQzlELElBQUksWUFBWSxHQUFHLGdCQUFnQixFQUFFO29CQUNqQyxnQkFBZ0IsR0FBRyxZQUFZLENBQUM7b0JBQ2hDLEtBQUssQ0FBQyxXQUFXLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUM7aUJBQ2pDO2FBQ0o7UUFDTCxDQUFDLENBQUMsQ0FBQztRQUVILE9BQU8sS0FBSyxDQUFDO0lBQ2pCLENBQUM7SUFFTSw0QkFBNEIsQ0FBQyxNQUFjO1FBQzlDLElBQUksSUFBSSxDQUFDLGVBQWUsRUFBRTtZQUN0QixJQUFJLFdBQVcsR0FBaUIsSUFBSSxDQUFDLE1BQU0sQ0FBQyxXQUFXLENBQUM7WUFDeEQsSUFBSSxXQUFXLElBQUksV0FBVyxDQUFDLEdBQUcsSUFBSSxPQUFPLFdBQVcsQ0FBQyxHQUFHLENBQUMsaUJBQWlCLEtBQUssV0FBVyxFQUFFO2dCQUM1RixPQUFPLElBQUksQ0FBQyxNQUFNLENBQUMsV0FBVyxDQUFDLEdBQUcsQ0FBQyxpQkFBaUIsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDO2FBQ3BGO1lBQ0QsT0FBTyxJQUFJLENBQUMsR0FBRyxDQUFDLE1BQU0sQ0FBQyxDQUFDO1NBQzNCO1FBQ0QsT0FBTyxNQUFNLENBQUM7SUFDbEIsQ0FBQztJQUVNLGdCQUFnQixDQUFDLE9BQWU7UUFDbkMsSUFBSSxRQUFRLENBQUMsT0FBTyxDQUFDLFFBQVEsRUFBRSxDQUFDLEtBQUssT0FBTztZQUFFLE9BQU8sQ0FBQyxDQUFDO1FBQ3ZELElBQUksTUFBTSxHQUFXLENBQUMsQ0FBQztRQUN2QixJQUFJLFVBQVUsR0FBVyxJQUFJLENBQUMsR0FBRyxDQUFDLE9BQU8sQ0FBQyxDQUFDLFFBQVEsRUFBRSxDQUFDO1FBQ3RELElBQUksVUFBVSxHQUFrQixVQUFVLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDO1FBRXRELElBQUksVUFBVSxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDLEVBQUU7WUFDN0IsTUFBTSxHQUFHLFVBQVUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUM7U0FDakM7YUFBTTtZQUNILE1BQU0sR0FBRyxRQUFRLENBQUMsVUFBVSxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO1lBQzdDLElBQUksT0FBTyxVQUFVLENBQUMsQ0FBQyxDQUFDLEtBQUssV0FBVztnQkFBRSxNQUFNLElBQUksVUFBVSxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQztTQUM1RTtRQUVELE9BQU8sTUFBTSxDQUFDO0lBQ2xCLENBQUM7SUFFTSxZQUFZLENBQUMsT0FBZSxFQUFFLE1BQXVCLEVBQUUsVUFBbUIsSUFBSSxFQUFFLFNBQWtCO1FBQ3JHLElBQUksUUFBUSxHQUFXLE9BQU8sU0FBUyxLQUFLLFdBQVcsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDO1FBQy9GLElBQUksSUFBSSxHQUFXLElBQUksQ0FBQyxxQkFBcUIsQ0FBQyxNQUFNLEVBQUUsUUFBUSxDQUFDLENBQUM7UUFFaEUsSUFBSSxPQUFPO1lBQUUsSUFBSSxHQUFHLElBQUksQ0FBQyxxQkFBcUIsQ0FBQyxJQUFJLENBQUMsQ0FBQztRQUVyRCxPQUFPLElBQUksQ0FBQyxxQkFBcUIsQ0FBQyxPQUFPLEVBQUUsSUFBSSxDQUFDLENBQUM7SUFDckQsQ0FBQztJQUVNLHFCQUFxQixDQUFDLE9BQWUsRUFBRSxLQUFhO1FBQ3ZELE9BQU8sT0FBTyxDQUFDLE9BQU8sQ0FBQyxVQUFVLEVBQUUsS0FBSyxDQUFDLENBQUM7SUFDOUMsQ0FBQztJQUVNLFVBQVUsQ0FBQyxNQUF1QjtRQUNyQyxPQUFPLE9BQU8sTUFBTSxLQUFLLFFBQVEsSUFBSSxDQUFDLE1BQU0sR0FBRyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUM7SUFDNUQsQ0FBQztJQUVNLFdBQVcsQ0FBQyxNQUF1QixFQUFFLGVBQXdCO1FBQ2hFLElBQUksT0FBTyxNQUFNLEtBQUssUUFBUTtZQUFFLE9BQU8sRUFBRSxDQUFDO1FBRTFDLElBQUksSUFBSSxDQUFDLEdBQUcsQ0FBQyxNQUFNLENBQUMsR0FBRyxRQUFRO1lBQUUsT0FBTyxLQUFLLENBQUM7UUFFOUMsSUFBSSxJQUFJLENBQUMsVUFBVSxDQUFDLE1BQU0sQ0FBQyxFQUFFO1lBQ3pCLE9BQU8sR0FBRyxDQUFDO1NBQ2Q7YUFBTTtZQUNILGFBQWE7WUFDYixJQUFJLElBQUksQ0FBQyxHQUFHLENBQUMsTUFBTSxDQUFDLEdBQUcsVUFBVTtnQkFBRSxPQUFPLEtBQUssQ0FBQztZQUVoRCxJQUFJLE9BQU8sZUFBZSxLQUFLLFdBQVcsSUFBSSxlQUFlLEtBQUssQ0FBQyxFQUFFO2dCQUNqRSx3QkFBd0I7Z0JBQ3hCLE9BQU8sR0FBRyxHQUFHLGVBQWUsQ0FBQyxRQUFRLEVBQUUsR0FBRyxHQUFHLENBQUM7YUFDakQ7U0FDSjtRQUVELE9BQU8sRUFBRSxDQUFDO0lBQ2QsQ0FBQztJQUVNLHFCQUFxQixDQUFDLE1BQXVCLEVBQUUsT0FBZTtRQUNqRSxJQUFJLE9BQU8sTUFBTSxLQUFLLFFBQVE7WUFBRSxPQUFPLE1BQU0sQ0FBQztRQUM5QyxPQUFPLEVBQUUsQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUM7SUFDdEMsQ0FBQztJQUVNLGVBQWUsQ0FBQyxLQUFhLEVBQUUsS0FBYTtRQUMvQyxPQUFPLEtBQUssQ0FBQyxRQUFRLEVBQUUsQ0FBQyxNQUFNLEdBQUcsS0FBSyxDQUFDLFFBQVEsRUFBRSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUM7SUFDN0UsQ0FBQztJQUVNLHVCQUF1QixDQUFDLGVBQW9CO1FBQy9DLElBQUksTUFBTSxHQUFpQixJQUFJLENBQUMsT0FBTyxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUM7UUFDckQsZUFBZSxDQUFDLEtBQUssQ0FBQyxPQUFPLEdBQUcsTUFBTSxDQUFDLEdBQUcsR0FBRyxHQUFHLEdBQUcsTUFBTSxDQUFDLEtBQUssR0FBRyxHQUFHLEdBQUcsTUFBTSxDQUFDLE1BQU0sR0FBRyxHQUFHLEdBQUcsTUFBTSxDQUFDLElBQUksQ0FBQztJQUM5RyxDQUFDO0lBRU0sdUJBQXVCLENBQUMsVUFBZTtRQUMxQyxVQUFVLENBQUMsSUFBSSxDQUFDLFdBQVcsRUFBRSxZQUFZLEdBQUcsSUFBSSxDQUFDLFVBQVUsQ0FBQyxJQUFJLEdBQUcsR0FBRyxHQUFHLElBQUksQ0FBQyxVQUFVLENBQUMsR0FBRyxHQUFHLEdBQUcsQ0FBQyxDQUFDO0lBQ3hHLENBQUM7SUFFTSxlQUFlLENBQUMsUUFBYSxFQUFFLE9BQTJDO1FBQzdFLEtBQUssSUFBSSxHQUFHLElBQUksT0FBTyxFQUFFO1lBQ3JCLElBQUksQ0FBQyxJQUFJLENBQUMsWUFBWSxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsQ0FBQztnQkFBRSxTQUFTO1lBQy9DLElBQUksWUFBWSxHQUFXLEdBQUcsS0FBSyxPQUFPLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLE9BQU8sQ0FBQyxzQkFBc0IsRUFBRSxLQUFLLENBQUMsQ0FBQyxXQUFXLEVBQUUsQ0FBQztZQUMvRyxRQUFRLENBQUMsSUFBSSxDQUFDLFlBQVksRUFBRSxPQUFPLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQztTQUM3QztJQUNMLENBQUM7SUFFTSxPQUFPLENBQUMsTUFBVztRQUN0QixPQUFPLENBQUMsT0FBTyxNQUFNLEtBQUssV0FBVyxJQUFJLE1BQU0sS0FBSyxJQUFJLElBQUksTUFBTSxDQUFDLEtBQUssS0FBSyxJQUFJLENBQUMsQ0FBQztJQUN2RixDQUFDO0lBRU0sWUFBWSxDQUFDLElBQVM7UUFDekIsT0FBTyxDQUFDLE9BQU8sSUFBSSxLQUFLLFdBQVcsSUFBSSxJQUFJLEtBQUssSUFBSSxJQUFJLElBQUksS0FBSyxFQUFFLENBQUMsQ0FBQztJQUN6RSxDQUFDO0lBRU0sYUFBYSxDQUFDLElBQW1CLEVBQUUsS0FBb0I7UUFDMUQsSUFBSSxLQUFLLEtBQUssS0FBSztZQUFFLE9BQU8sRUFBRSxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsQ0FBQztRQUN6QyxJQUFJLEtBQUssS0FBSyxLQUFLO1lBQUUsT0FBTyxFQUFFLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxDQUFDO0lBQzdDLENBQUM7SUFFTSxtQkFBbUIsQ0FBQyxLQUFnQixFQUFFLFNBQWtCLEVBQUUsYUFBZ0M7UUFDN0YsSUFBSSxJQUFJLENBQUMsU0FBUyxFQUFFO1lBQ2hCLElBQUksS0FBSyxLQUFLLEdBQUcsRUFBRTtnQkFDZixJQUFJLFNBQVM7b0JBQUUsT0FBTyxhQUFhLENBQUMsS0FBSyxDQUFDO2dCQUMxQyxPQUFPLGFBQWEsQ0FBQyxJQUFJLENBQUM7YUFDN0I7WUFDRCxJQUFJLEtBQUssS0FBSyxHQUFHLEVBQUU7Z0JBQ2YsSUFBSSxTQUFTO29CQUFFLE9BQU8sYUFBYSxDQUFDLEdBQUcsQ0FBQztnQkFDeEMsT0FBTyxhQUFhLENBQUMsTUFBTSxDQUFDO2FBQy9CO1NBQ0o7YUFBTTtZQUNILElBQUksS0FBSyxLQUFLLEdBQUcsRUFBRTtnQkFDZixJQUFJLFNBQVM7b0JBQUUsT0FBTyxhQUFhLENBQUMsR0FBRyxDQUFDO2dCQUN4QyxPQUFPLGFBQWEsQ0FBQyxNQUFNLENBQUM7YUFDL0I7WUFDRCxJQUFJLEtBQUssS0FBSyxHQUFHLEVBQUU7Z0JBQ2YsSUFBSSxTQUFTO29CQUFFLE9BQU8sYUFBYSxDQUFDLEtBQUssQ0FBQztnQkFDMUMsT0FBTyxhQUFhLENBQUMsSUFBSSxDQUFDO2FBQzdCO1NBQ0o7SUFDTCxDQUFDO0lBRU0sb0JBQW9CLENBQUMsZUFBOEIsRUFBRSxXQUFtQjtRQUMzRSxJQUFJLENBQUMsZUFBZTtZQUFFLE9BQU8sRUFBRSxDQUFDO1FBQ2hDLE9BQU8sV0FBVyxJQUFJLGVBQWUsQ0FBQyxNQUFNLEdBQUcsV0FBVyxDQUFDLENBQUMsQ0FBQyxlQUFlLENBQUMsS0FBSyxDQUFDLENBQUMsRUFBRSxXQUFXLENBQUMsQ0FBQyxDQUFDLENBQUMsZUFBZSxDQUFDO0lBQ3pILENBQUM7SUFFRDs7Ozs7T0FLRztJQUNJLFFBQVEsQ0FBQyxhQUFxQixFQUFFLFlBQXNCO1FBQ3pELElBQUksTUFBTSxHQUFXLEVBQUUsQ0FBQztRQUN4QixJQUFJLFlBQVksRUFBRTtZQUNkLE1BQU0sR0FBRyxJQUFJLENBQUMsT0FBTyxDQUFDLE9BQU8sQ0FBQyxLQUFLLENBQUM7U0FDdkM7UUFDRCxJQUFJLE9BQU8sR0FBVyxFQUFFLENBQUM7UUFFekIsSUFBSSxhQUFhLEVBQUU7WUFDZixLQUFLLElBQUksVUFBVSxJQUFJLE1BQU0sQ0FBQyxJQUFJLENBQUMsYUFBYSxDQUFDLEVBQUU7Z0JBQy9DLE9BQU8sSUFBSSxVQUFVLENBQUMsT0FBTyxDQUFDLHNCQUFzQixFQUFFLEtBQUssQ0FBQyxDQUFDLFdBQVcsRUFBRSxDQUFDO2dCQUMzRSxPQUFPLElBQUksR0FBRyxDQUFDO2dCQUNmLE9BQU8sSUFBSSxDQUFDLE1BQU0sSUFBSSxNQUFNLENBQUMsY0FBYyxDQUFDLFVBQVUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxVQUFVLENBQUMsQ0FBQyxDQUFDLENBQUMsYUFBYSxDQUFDLFVBQVUsQ0FBQyxDQUFDO2dCQUMxRyxPQUFPLElBQUksR0FBRyxDQUFDO2FBQ2xCO1NBQ0o7UUFDRCxPQUFPLE9BQU8sQ0FBQztJQUNuQixDQUFDO0lBRUQsaUZBQWlGO0lBRWpGOzs7OztPQUtHO0lBQ0ksWUFBWSxDQUFDLEtBQXNDLEVBQUUsVUFBa0IsRUFBRSxZQUFvQjtRQVNoRyxJQUFJLFVBQVUsR0FBVyxDQUFDLENBQUM7UUFDM0IsSUFBSSxVQUFVLEdBQVcsQ0FBQyxDQUFDO1FBQzNCLElBQUksWUFBWSxHQUFHLElBQUksQ0FBQyxZQUFZLENBQUM7UUFFckMsSUFBSSxZQUFZLENBQUMsS0FBSyxDQUFDLEVBQUU7WUFDckIsVUFBVSxHQUFHLEtBQUssQ0FBQyxNQUFNLENBQUMsWUFBWSxDQUFDLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxDQUFDLEtBQUssQ0FBQztZQUMvRCxVQUFVLEdBQUcsS0FBSyxDQUFDLEtBQUssQ0FBQyxVQUFVLENBQUMsTUFBTSxDQUFDO1NBQzlDO2FBQU07WUFDSCxVQUFVLEdBQUcsS0FBSyxDQUFDLFVBQVUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxZQUFZLENBQUMsQ0FBQyxLQUFLLENBQUM7WUFDckQsVUFBVSxHQUFHLEtBQUssQ0FBQyxNQUFNLENBQUM7U0FDN0I7UUFFRCxTQUFTLFFBQVEsQ0FBQyxJQUFZLEVBQUUsTUFBZTtZQUMzQyxJQUFJLEtBQUssR0FBVyxDQUFDLENBQUM7WUFDdEIsSUFBSSxJQUFJLEtBQUssTUFBTSxFQUFFO2dCQUNqQixJQUFJLFVBQVUsR0FBRyxDQUFDLEVBQUU7b0JBQ2hCLEtBQUssR0FBRyxVQUFVLEdBQUcsQ0FBQyxDQUFDO2lCQUMxQjtxQkFBTTtvQkFDSCxPQUFPLEtBQUssQ0FBQztpQkFDaEI7YUFDSjtpQkFBTTtnQkFDSCxJQUFJLFVBQVUsR0FBRyxVQUFVLEdBQUcsQ0FBQyxFQUFFO29CQUM3QixLQUFLLEdBQUcsVUFBVSxHQUFHLENBQUMsQ0FBQztpQkFDMUI7cUJBQU07b0JBQ0gsT0FBTyxLQUFLLENBQUM7aUJBQ2hCO2FBQ0o7WUFFRCxJQUFJLEtBQUssR0FBVyxDQUFDLFlBQVksQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxZQUFZLENBQUMsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLFlBQVksQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDO1lBRTlILElBQUksTUFBTSxFQUFFO2dCQUNSLE9BQU8sS0FBSyxLQUFLLElBQUksQ0FBQzthQUN6QjtZQUNELE9BQU8sS0FBSyxLQUFLLElBQUksQ0FBQztRQUMxQixDQUFDO1FBRUQsSUFBSSxVQUFVLEdBQVksUUFBUSxDQUFDLE1BQU0sRUFBRSxJQUFJLENBQUMsQ0FBQztRQUNqRCxJQUFJLGFBQWEsR0FBWSxRQUFRLENBQUMsTUFBTSxFQUFFLEtBQUssQ0FBQyxDQUFDO1FBQ3JELElBQUksVUFBVSxHQUFZLFFBQVEsQ0FBQyxNQUFNLEVBQUUsSUFBSSxDQUFDLENBQUM7UUFDakQsSUFBSSxhQUFhLEdBQVksUUFBUSxDQUFDLE1BQU0sRUFBRSxLQUFLLENBQUMsQ0FBQztRQUVyRCxJQUFJLFdBQVcsR0FBWSxhQUFhLElBQUksVUFBVSxLQUFLLElBQUksSUFBSSxVQUFVLENBQUM7UUFFOUUsSUFBSSxjQUFjLEdBQVksVUFBVSxJQUFJLFVBQVUsS0FBSyxJQUFJLElBQUksYUFBYSxDQUFDO1FBRWpGLE9BQU87WUFDSCxVQUFVLEVBQUUsVUFBVTtZQUN0QixhQUFhLEVBQUUsYUFBYTtZQUM1QixVQUFVLEVBQUUsVUFBVTtZQUN0QixhQUFhLEVBQUUsYUFBYTtZQUM1QixXQUFXLEVBQUUsV0FBVztZQUN4QixjQUFjLEVBQUUsY0FBYztTQUNqQyxDQUFDO0lBQ04sQ0FBQztJQUVNLFlBQVksQ0FBQyxNQUFXO1FBQzNCLE9BQU8sUUFBUSxJQUFJLE1BQU0sQ0FBQztJQUM5QixDQUFDO0lBRUQscUZBQXFGO0lBRXJGOzs7OztPQUtHO0lBQ0ksd0JBQXdCLENBQUMsVUFBMEIsRUFBRSxXQUEwQixFQUFFLFlBQW9CO1FBQ3hHLElBQUksTUFBTSxHQUFrQixFQUFFLENBQUM7UUFDL0IsS0FBSyxJQUFJLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxHQUFHLFdBQVcsQ0FBQyxNQUFNLEVBQUUsRUFBRSxDQUFDLEVBQUU7WUFDekMsSUFBSSxHQUFHLEdBQVcsQ0FBQyxDQUFDO1lBQ3BCLEtBQUssSUFBSSxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsR0FBRyxZQUFZLEVBQUUsRUFBRSxDQUFDLEVBQUU7Z0JBQ25DLElBQUksT0FBTyxVQUFVLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxLQUFLLFdBQVc7b0JBQUUsU0FBUztnQkFDM0QsSUFBSSxVQUFVLEdBQWtCLFVBQVUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDO2dCQUM1RCxJQUFJLE9BQU8sVUFBVSxLQUFLLFdBQVc7b0JBQUUsU0FBUztnQkFDaEQsR0FBRyxHQUFHLENBQUMsVUFBVSxLQUFLLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLEdBQUcsR0FBRyxVQUFVLENBQUM7YUFDeEQ7WUFDRCxNQUFNLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFDO1NBQ3BCO1FBQ0QsT0FBTyxNQUFNLENBQUM7SUFDbEIsQ0FBQztJQUVELGdGQUFnRjtJQUNoRjs7Ozs7T0FLRztJQUNJLFVBQVUsQ0FBQyxXQUEyQyxFQUFFLEtBQVUsRUFBRSxPQUFxQixFQUFFLGdCQUF3QjtRQUt0SCxJQUFJLE9BQU8sR0FBZSxFQUFFLENBQUM7UUFDN0IsSUFBSSxRQUFRLEdBQWtCLEVBQUUsQ0FBQztRQUNqQyxJQUFJLFFBQWdCLENBQUM7UUFDckIsSUFBSSxrQkFBa0IsR0FBVyxDQUFDLENBQUM7UUFDbkMsSUFBSSxlQUFlLEdBQXVCLE1BQU0sQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFDLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsV0FBVyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUM7UUFDaEcsV0FBVyxHQUFHLEVBQUUsQ0FBQztRQUNqQixLQUFLLElBQUksQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLEdBQUcsS0FBSyxDQUFDLElBQUksQ0FBQyxNQUFNLEVBQUUsQ0FBQyxFQUFFLEVBQUU7WUFDeEMsS0FBSyxJQUFJLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxHQUFHLEtBQUssQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sRUFBRSxDQUFDLEVBQUUsRUFBRTtnQkFDN0MsS0FBSyxJQUFJLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxHQUFHLGVBQWUsQ0FBQyxNQUFNLEVBQUUsQ0FBQyxFQUFFLEVBQUU7b0JBQzdDLElBQUksS0FBSyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLEtBQUssZUFBZSxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsRUFBRTt3QkFDcEQsSUFBSSxPQUFPLEtBQUssQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxXQUFXLEVBQUU7NEJBQ2xELElBQUksQ0FBQyxnQkFBZ0IsS0FBSyxTQUFTLElBQUksZ0JBQWdCLEtBQUssSUFBSSxJQUFJLGtCQUFrQixHQUFHLGdCQUFnQixDQUFDLElBQUksZ0JBQWdCLEtBQUssU0FBUyxJQUFJLGdCQUFnQixLQUFLLElBQUksRUFBRTtnQ0FDdkssSUFBSSxZQUFZLEdBQUcsS0FBSyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUM7Z0NBQy9DLElBQUksVUFBVSxHQUFHLENBQUMsWUFBWSxJQUFJLFlBQVksSUFBSSxJQUFJLElBQUksWUFBWSxJQUFJLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxZQUFZLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxPQUFPLEVBQUUsa0JBQWtCLEVBQUUsT0FBTyxDQUFDLENBQUM7Z0NBQzdKLFFBQVEsR0FBRyxJQUFJLEdBQUcsa0JBQWtCLENBQUM7Z0NBQ3JDLFdBQVcsQ0FBQyxRQUFRLENBQUMsR0FBRztvQ0FDcEIsTUFBTSxFQUFFLEtBQUssQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLEdBQUcsR0FBRyxlQUFlLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSTtvQ0FDdkQsSUFBSSxFQUFFLFFBQVE7b0NBQ2QsT0FBTyxFQUFFLFFBQVE7b0NBQ2pCLEdBQUcsRUFBRSxLQUFLLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxHQUFHLEdBQUcsZUFBZSxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUk7b0NBQ3BELEdBQUcsRUFBRSxLQUFLLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUM7b0NBQ2hDLE9BQU8sRUFBRSxLQUFLLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7b0NBQ3hCLE9BQU8sRUFBRSxLQUFLLEdBQUcsa0JBQWtCO29DQUNuQyxPQUFPLEVBQUUsVUFBVTtvQ0FDbkIsYUFBYSxFQUFFLENBQUM7b0NBQ2hCLFdBQVcsRUFBRSxDQUFDO2lDQUNqQixDQUFDO2dDQUNGLFFBQVEsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLENBQUM7Z0NBQzFCLE9BQU8sQ0FBQyxJQUFJLENBQUM7b0NBQ1QsSUFBSSxFQUFFLFFBQVE7b0NBQ2QsR0FBRyxFQUFFLEtBQUssQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLEdBQUcsR0FBRyxlQUFlLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSTtvQ0FDcEQsR0FBRyxFQUFFLEtBQUssQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQztvQ0FDaEMsT0FBTyxFQUFFLEtBQUssQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztvQ0FDeEIsT0FBTyxFQUFFLEtBQUssR0FBRyxrQkFBa0I7b0NBQ25DLE9BQU8sRUFBRSxVQUFVO29DQUNuQixhQUFhLEVBQUUsQ0FBQztvQ0FDaEIsV0FBVyxFQUFFLENBQUM7aUNBQ2pCLENBQUMsQ0FBQztnQ0FDSCxrQkFBa0IsRUFBRSxDQUFDO2dDQUNyQixNQUFNOzZCQUNUO3lCQUNKO3FCQUNKO2lCQUNKO2FBQ0o7U0FDSjtRQUNELElBQUksWUFBWSxHQUFHO1lBQ2YsU0FBUyxFQUFFLE9BQU87WUFDbEIsVUFBVSxFQUFFLFFBQVE7WUFDcEIsWUFBWSxFQUFFLFdBQVc7U0FDNUIsQ0FBQztRQUNGLE9BQU8sWUFBWSxDQUFDO0lBQ3hCLENBQUM7SUFFTSxvQkFBb0IsQ0FBQyxXQUEyQyxFQUFFLEtBQVUsRUFBRSxPQUFxQixFQUFFLGdCQUF3QjtRQUNoSSxJQUFJLE9BQU8sR0FBZSxFQUFFLENBQUM7UUFDN0IsSUFBSSxRQUFRLEdBQWtCLEVBQUUsQ0FBQztRQUNqQyxJQUFJLFFBQWdCLENBQUM7UUFDckIsSUFBSSxrQkFBa0IsR0FBVyxDQUFDLENBQUM7UUFDbkMsV0FBVyxHQUFHLEVBQUUsQ0FBQztRQUNqQixJQUFJLEtBQUssQ0FBQyxNQUFNLElBQUksS0FBSyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsSUFBSSxLQUFLLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksRUFBRTtZQUN6RCxLQUFLLElBQUksQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLEdBQUcsS0FBSyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsTUFBTSxFQUFFLENBQUMsRUFBRSxFQUFFO2dCQUNsRCxJQUFJLE9BQU8sS0FBSyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLFdBQVcsRUFBRTtvQkFDbEQsSUFBSSxDQUFDLGdCQUFnQixJQUFJLFNBQVMsSUFBSSxnQkFBZ0IsSUFBSSxJQUFJLElBQUksa0JBQWtCLEdBQUcsZ0JBQWdCLENBQUMsSUFBSSxnQkFBZ0IsSUFBSSxTQUFTLElBQUksZ0JBQWdCLElBQUksSUFBSSxFQUFFO3dCQUNuSyxJQUFJLFlBQVksR0FBRyxLQUFLLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQzt3QkFDcEQsSUFBSSxVQUFVLEdBQUcsQ0FBQyxZQUFZLElBQUksWUFBWSxJQUFJLElBQUksSUFBSSxZQUFZLElBQUksSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLFlBQVksQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLGdCQUFnQixDQUFDLE9BQU8sRUFBRSxrQkFBa0IsRUFBRSxPQUFPLENBQUMsQ0FBQzt3QkFDN0osUUFBUSxHQUFHLElBQUksR0FBRyxrQkFBa0IsQ0FBQzt3QkFDckMsV0FBVyxDQUFDLFFBQVEsQ0FBQyxHQUFHOzRCQUNwQixNQUFNLEVBQUUsS0FBSyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxJQUFJLEVBQUUsR0FBRyxDQUFDOzRCQUN2RCxJQUFJLEVBQUUsUUFBUTs0QkFDZCxPQUFPLEVBQUUsUUFBUTs0QkFDakIsR0FBRyxFQUFFLEtBQUssQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUk7NEJBQ2pDLEdBQUcsRUFBRSxLQUFLLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDOzRCQUM5QixPQUFPLEVBQUUsS0FBSyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSTs0QkFDckMsT0FBTyxFQUFFLEtBQUssR0FBRyxrQkFBa0I7NEJBQ25DLE9BQU8sRUFBRSxVQUFVO3lCQUN0QixDQUFDO3dCQUNGLFFBQVEsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLENBQUM7d0JBQzFCLElBQUksS0FBSyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLEtBQUssQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLEVBQUU7NEJBQzVELE9BQU8sQ0FBQyxJQUFJLENBQUM7Z0NBQ1QsSUFBSSxFQUFFLFFBQVE7Z0NBQ2QsR0FBRyxFQUFFLEtBQUssQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUk7Z0NBQ2pDLEdBQUcsRUFBRSxLQUFLLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO2dDQUM5QixPQUFPLEVBQUUsS0FBSyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSTtnQ0FDckMsT0FBTyxFQUFFLEtBQUssR0FBRyxrQkFBa0I7Z0NBQ25DLE9BQU8sRUFBRSxVQUFVOzZCQUN0QixDQUFDLENBQUM7eUJBQ047d0JBRUQsa0JBQWtCLEVBQUUsQ0FBQztxQkFDeEI7aUJBQ0o7YUFDSjtTQUNKO1FBQ0QsSUFBSSxZQUFZLEdBQUc7WUFDZixTQUFTLEVBQUUsT0FBTztZQUNsQixVQUFVLEVBQUUsUUFBUTtZQUNwQixZQUFZLEVBQUUsV0FBVztTQUM1QixDQUFDO1FBQ0YsT0FBTyxZQUFZLENBQUM7SUFDeEIsQ0FBQztJQUVNLGdCQUFnQixDQUFDLFdBQTJDLEVBQUUsS0FBVSxFQUFFLE9BQXFCO1FBQ2xHLElBQUksUUFBZ0IsQ0FBQztRQUNyQixXQUFXLEdBQUcsRUFBRSxDQUFDO1FBQ2pCLEtBQUssSUFBSSxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsR0FBRyxLQUFLLENBQUMsTUFBTSxFQUFFLENBQUMsRUFBRSxFQUFFO1lBQ25DLElBQUksS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksSUFBSSxTQUFTLEVBQUU7Z0JBQzVCLElBQUksWUFBWSxHQUFHLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUM7Z0JBQ2xDLFFBQVEsR0FBRyxJQUFJLEdBQUcsQ0FBQyxDQUFDO2dCQUNwQixXQUFXLENBQUMsUUFBUSxDQUFDLEdBQUc7b0JBQ3BCLE1BQU0sRUFBRSxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSTtvQkFDckIsSUFBSSxFQUFFLFFBQVE7b0JBQ2QsT0FBTyxFQUFFLFFBQVE7b0JBQ2pCLEdBQUcsRUFBRSxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSTtvQkFDbEIsR0FBRyxFQUFFLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSztvQkFDM0IsT0FBTyxFQUFFLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJO29CQUN0QixPQUFPLEVBQUUsQ0FBQyxZQUFZLElBQUksWUFBWSxJQUFJLElBQUksSUFBSSxZQUFZLElBQUksU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLFlBQVksQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLGdCQUFnQixDQUFDLE9BQU8sRUFBRSxDQUFDLEVBQUUsT0FBTyxDQUFDO29CQUN4SSxhQUFhLEVBQUUsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUU7b0JBQzFCLFVBQVUsRUFBRSxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUTtpQkFDaEMsQ0FBQzthQUNMO1NBQ0o7UUFDRCxPQUFPLFdBQVcsQ0FBQztJQUN2QixDQUFDO0lBRU0sZ0JBQWdCLENBQUMsUUFBYSxFQUFFLFlBQW9CLEVBQUUsT0FBcUI7UUFDOUUsSUFBSSxRQUFRLEtBQUssT0FBTztZQUFFLE9BQU8sUUFBUSxDQUFDO1FBRTFDLElBQUksWUFBWSxJQUFJLFlBQVksS0FBSyxDQUFDLEVBQUU7WUFDcEMsT0FBTyxPQUFPLENBQUMsTUFBTSxDQUFDLFlBQVksR0FBRyxPQUFPLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxDQUFDO1NBQy9EO0lBQ0wsQ0FBQztJQUVNLHFCQUFxQixDQUFDLFlBQXdCLEVBQUUsZ0JBQXdCLEVBQUUsWUFBb0IsRUFBRSxlQUFnRDtRQUNuSixJQUFJLFdBQVcsR0FBbUMsRUFBRSxDQUFDO1FBQ3JELEtBQUssSUFBSSxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsR0FBRyxZQUFZLENBQUMsTUFBTSxFQUFFLENBQUMsRUFBRSxFQUFFO1lBQzFDLElBQUksUUFBUSxHQUFXLElBQUksR0FBRyxDQUFDLENBQUM7WUFDaEMsV0FBVyxDQUFDLFFBQVEsQ0FBQyxHQUFHO2dCQUNwQixNQUFNLEVBQUUsWUFBWSxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsZ0JBQWdCLENBQUMsR0FBRyxZQUFZLEdBQUcsS0FBSyxHQUFHLFlBQVksQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsT0FBTyxDQUFDLGdCQUFnQixDQUFDLEdBQUcsWUFBWTtnQkFDM0ksSUFBSSxFQUFFLFFBQVE7Z0JBQ2QsT0FBTyxFQUFFLFFBQVE7Z0JBQ2pCLE9BQU8sRUFBRSxZQUFZLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSztnQkFDOUIsVUFBVSxFQUFFLGVBQWUsSUFBSSxlQUFlLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLGVBQWUsQ0FBQyxRQUFRLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLEtBQUs7YUFDeEcsQ0FBQztTQUVMO1FBQ0QsT0FBTyxXQUFXLENBQUM7SUFDdkIsQ0FBQzs7O1lBaGxDSixVQUFVOzs7WUFyQkYsWUFBWSIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IEluamVjdGFibGUgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcclxuaW1wb3J0IHsgS2REb21FbGVtU3ZjIH0gZnJvbSAnLi4va2QtY29tbW9uL2luZGV4JztcclxuaW1wb3J0ICogYXMgZDMgZnJvbSAnZDMnO1xyXG5pbXBvcnQgKiBhcyBoZWxwZXIgZnJvbSAnLi9oZWxwZXItc3ZjL2luZGV4JztcclxuaW1wb3J0IHtcclxuICAgIElTZXJpZXMsXHJcbiAgICBJQ2hhcnRDb25maWcsXHJcbiAgICBJQ2hhcnRNYXJnaW4sXHJcbiAgICBJWUF4aXNDb25maWcsXHJcbiAgICBJQ2hhcnREYXRhLFxyXG4gICAgSUQzRGF0YURhdGEsXHJcbiAgICBJTWF4TWluSW50ZXJ2YWwsXHJcbiAgICBJRDNEYXRhUmFuZ2UsXHJcbiAgICBJTGVnZW5kRGF0YSxcclxuICAgIElGb3JMb29wSW5mbyxcclxuICAgIElBeGlzTGFiZWxCb29sZWFuQ2hlY2tzLFxyXG4gICAgSVBsb3RPcHRpb25zLFxyXG4gICAgSUF4aXNUcmFuc2Zvcm1Qb3MsXHJcbiAgICBJWEluZm8sXHJcbiAgICBJWUF4aXNMYWJlbFJhbmdlXHJcbn0gZnJvbSAnLi9rZC1hbmd1bGFyLWNoYXJ0cy1pbnRlcmZhY2UnO1xyXG5cclxuQEluamVjdGFibGUoKVxyXG5leHBvcnQgY2xhc3MgS2RDaGFydHNTdmMge1xyXG5cclxuICAgIHByaXZhdGUgX2NvbmZpZzogSUNoYXJ0Q29uZmlnO1xyXG4gICAgcHJpdmF0ZSBfc3ZnOiBhbnk7XHJcbiAgICBwcml2YXRlIF9zdmdSZWN0OiBhbnk7XHJcbiAgICBwcml2YXRlIF9zdmdQYXJlbnRSZWN0OiBhbnk7XHJcbiAgICBwcml2YXRlIF9pc0ludmVydDogYm9vbGVhbiA9IGZhbHNlO1xyXG4gICAgcHJpdmF0ZSBfY2hhcnRUeXBlOiBBcnJheTxzdHJpbmc+O1xyXG4gICAgcHJpdmF0ZSBfY2hhcnRDYXRlZ29yeTogJ3BpZScgfCAnYmFyJyB8ICdjb2x1bW4nIHwgJ2xpbmUnIHwgJ2FyZWEnIHwgJ2RvdCcgfCAnc3BsaW5lJyB8ICdtYXAnO1xyXG4gICAgcHJpdmF0ZSBfaXNSb3RhdGU6IGJvb2xlYW4gPSBmYWxzZTtcclxuICAgIHByaXZhdGUgX2xhYmVsTGVuZ3RoOiBudW1iZXI7XHJcbiAgICBwcml2YXRlIF9jdXJyVmVydEF4aXNUaXRsZTogRWxlbWVudDtcclxuICAgIHByaXZhdGUgX2lzUnRsOiBib29sZWFuID0gZmFsc2U7XHJcbiAgICBwcml2YXRlIF9kZWZhdWx0U3ZnTWFyZ2luOiB7IHRvcDogbnVtYmVyOyB4OiBudW1iZXI7IHk6IG51bWJlcjsgb3BwVmVydDogbnVtYmVyOyB9ID0ge1xyXG4gICAgICAgIHRvcDogMjAsXHJcbiAgICAgICAgeDogOSxcclxuICAgICAgICB5OiAxMixcclxuICAgICAgICBvcHBWZXJ0OiAyMFxyXG4gICAgfTtcclxuICAgIHByaXZhdGUgX3N2Z01hcmdpbjogeyB0b3A6IG51bWJlcjsgcmlnaHQ6IG51bWJlcjsgYm90dG9tOiBudW1iZXI7IGxlZnQ6IG51bWJlcjsgfSA9IHtcclxuICAgICAgICB0b3A6IDAsXHJcbiAgICAgICAgcmlnaHQ6IDAsXHJcbiAgICAgICAgYm90dG9tOiAwLFxyXG4gICAgICAgIGxlZnQ6IDBcclxuICAgIH07XHJcbiAgICBwcml2YXRlIF95QXhpc0xhYmVsV2lkdGg6IElZQXhpc0xhYmVsUmFuZ2UgPSB7XHJcbiAgICAgICAgYXhpc01heDogMCxcclxuICAgICAgICBheGlzTWluOiAwXHJcbiAgICB9O1xyXG4gICAgcHJpdmF0ZSBfYXhpc0xhYmVsQ29udGFpbmVyOiBhbnk7XHJcbiAgICBwcml2YXRlIF9heGlzTGFiZWxEdW1teTogYW55O1xyXG4gICAgcHJpdmF0ZSBfYXhpc0xhYmVsQ29udGFpbmVyTWFyZ2luTGVmdDogbnVtYmVyO1xyXG4gICAgcHJpdmF0ZSBfbWluWFNwYWNpbmc6IG51bWJlciA9IDUwO1xyXG4gICAgcHJpdmF0ZSBfeFNwYWNpbmc6IG51bWJlcjtcclxuICAgIHByaXZhdGUgX3hTY2FsZVR5cGU6ICdzdHJpbmcnIHwgJ2JhbmQnO1xyXG4gICAgcHJpdmF0ZSBfYXhpc0QzRm9ybWF0OiBzdHJpbmcgPSAnJztcclxuICAgIHByaXZhdGUgX2lzWFJldmVyc2VkOiBib29sZWFuID0gZmFsc2U7XHJcbiAgICBwcml2YXRlIF9pc1lSZXZlcnNlZDogYm9vbGVhbiA9IGZhbHNlO1xyXG4gICAgcHJpdmF0ZSBkYXRhTGFiZWxQdXNoRG93blJhbmdlOiBudW1iZXIgPSAwO1xyXG4gICAgcHJpdmF0ZSBfaXNOZWdhdGl2ZVN0YWNrOiBib29sZWFuID0gZmFsc2U7XHJcblxyXG4gICAgcHVibGljIGdyaWRTdmM6IGhlbHBlci5LZENoYXJ0c0dyaWRTdmM7XHJcbiAgICBwdWJsaWMgdG9vbHRpcFN2YzogaGVscGVyLktkQ2hhcnRzVG9vbHRpcFN2YztcclxuXHJcbiAgICBjb25zdHJ1Y3Rvcihwcml2YXRlIF9kb21TdmM6IEtkRG9tRWxlbVN2Yykge1xyXG4gICAgICAgIHRoaXMuZ3JpZFN2YyA9IG5ldyBoZWxwZXIuS2RDaGFydHNHcmlkU3ZjKHRoaXMuX2NvbmZpZyk7XHJcbiAgICAgICAgdGhpcy50b29sdGlwU3ZjID0gbmV3IGhlbHBlci5LZENoYXJ0c1Rvb2x0aXBTdmMoKTtcclxuICAgIH1cclxuXHJcbiAgICBzZXQgY29uZmlnKF9jb25maWcpIHtcclxuICAgICAgICB0aGlzLl9jb25maWcgPSBfY29uZmlnO1xyXG4gICAgICAgIHRoaXMuZ3JpZFN2Yy5jb25maWcgPSBfY29uZmlnO1xyXG4gICAgfVxyXG4gICAgZ2V0IGNvbmZpZygpOiBJQ2hhcnRDb25maWcgeyByZXR1cm4gdGhpcy5fY29uZmlnOyB9XHJcblxyXG4gICAgc2V0IHN2Zyhfc3ZnKSB7IHRoaXMuX3N2ZyA9IF9zdmc7IH1cclxuXHJcbiAgICBzZXQgc3ZnUmVjdChfc3ZnUmVjdCkgeyB0aGlzLl9zdmdSZWN0ID0gX3N2Z1JlY3Q7IH1cclxuXHJcbiAgICBzZXQgY2hhcnRUeXBlKF9jaGFydFR5cGUpIHsgdGhpcy5fY2hhcnRUeXBlID0gX2NoYXJ0VHlwZTsgfVxyXG4gICAgc2V0IGNoYXJ0Q2F0ZWdvcnkoX2NoYXJ0Q2F0ZWdvcnkpIHsgdGhpcy5fY2hhcnRDYXRlZ29yeSA9IF9jaGFydENhdGVnb3J5OyB9XHJcblxyXG4gICAgc2V0IGlzSW52ZXJ0KF9pc0ludmVydCkge1xyXG4gICAgICAgIHRoaXMuX2lzSW52ZXJ0ID0gX2lzSW52ZXJ0O1xyXG4gICAgICAgIHRoaXMuZ3JpZFN2Yy5pc0ludmVydCA9IF9pc0ludmVydDtcclxuICAgIH1cclxuXHJcbiAgICBzZXQgc3ZnUGFyZW50UmVjdChfc3ZnUGFyZW50UmVjdCkgeyB0aGlzLl9zdmdQYXJlbnRSZWN0ID0gX3N2Z1BhcmVudFJlY3Q7IH1cclxuXHJcbiAgICBzZXQgaXNSb3RhdGUoX2lzUm90YXRlKSB7IHRoaXMuX2lzUm90YXRlID0gX2lzUm90YXRlOyB9XHJcbiAgICBnZXQgaXNSb3RhdGUoKTogYm9vbGVhbiB7IHJldHVybiB0aGlzLl9pc1JvdGF0ZTsgfVxyXG5cclxuICAgIHNldCBsYWJlbExlbmd0aChfbGFiZWxMZW5ndGgpIHsgdGhpcy5fbGFiZWxMZW5ndGggPSBfbGFiZWxMZW5ndGg7IH1cclxuICAgIGdldCBsYWJlbExlbmd0aCgpOiBudW1iZXIgeyByZXR1cm4gdGhpcy5fbGFiZWxMZW5ndGg7IH1cclxuXHJcbiAgICBnZXQgc3ZnTWFyZ2luKCkgeyByZXR1cm4gdGhpcy5fc3ZnTWFyZ2luOyB9XHJcblxyXG4gICAgc2V0IHhTY2FsZVR5cGUoX3hTY2FsZVR5cGUpIHsgdGhpcy5feFNjYWxlVHlwZSA9IF94U2NhbGVUeXBlOyB9XHJcbiAgICBnZXQgeFNjYWxlVHlwZSgpIHsgcmV0dXJuIHRoaXMuX3hTY2FsZVR5cGU7IH1cclxuXHJcbiAgICBnZXQgeFNwYWNpbmcoKSB7IHJldHVybiB0aGlzLl94U3BhY2luZzsgfVxyXG5cclxuICAgIGdldCBheGlzRDNGb3JtYXQoKSB7IHJldHVybiB0aGlzLl9heGlzRDNGb3JtYXQ7IH1cclxuXHJcbiAgICBnZXQgeUF4aXNMYWJlbFdpZHRoKCkgeyByZXR1cm4gdGhpcy5feUF4aXNMYWJlbFdpZHRoOyB9XHJcblxyXG4gICAgc2V0IGlzUnRsKF9pc1J0bCkgeyB0aGlzLl9pc1J0bCA9IF9pc1J0bDsgfVxyXG5cclxuICAgIHNldCBpc1hSZXZlcnNlZChfaXNYUmV2ZXJzZWQpIHtcclxuICAgICAgICBpZiAoIXRoaXMuX2lzSW52ZXJ0KSB7XHJcbiAgICAgICAgICAgIHRoaXMuX2lzWFJldmVyc2VkID0gX2lzWFJldmVyc2VkICE9PSB0aGlzLl9pc1J0bDtcclxuICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICB0aGlzLl9pc1hSZXZlcnNlZCA9IF9pc1hSZXZlcnNlZDtcclxuICAgICAgICB9XHJcbiAgICB9XHJcbiAgICBnZXQgaXNYUmV2ZXJzZWQoKSB7IHJldHVybiB0aGlzLl9pc1hSZXZlcnNlZDsgfVxyXG5cclxuICAgIHNldCBpc1lSZXZlcnNlZChfaXNZUmV2ZXJzZWQpIHtcclxuICAgICAgICBpZiAodGhpcy5faXNJbnZlcnQpIHtcclxuICAgICAgICAgICAgdGhpcy5faXNZUmV2ZXJzZWQgPSBfaXNZUmV2ZXJzZWQgIT09IHRoaXMuX2lzUnRsO1xyXG4gICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgIHRoaXMuX2lzWVJldmVyc2VkID0gX2lzWVJldmVyc2VkO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuICAgIGdldCBpc1lSZXZlcnNlZCgpIHsgcmV0dXJuIHRoaXMuX2lzWVJldmVyc2VkOyB9XHJcblxyXG4gICAgc2V0IGlzTmVnYXRpdmVTdGFjayhfaXNOZWdhdGl2ZVN0YWNrOiBib29sZWFuKSB7IHRoaXMuX2lzTmVnYXRpdmVTdGFjayA9IF9pc05lZ2F0aXZlU3RhY2s7IH1cclxuICAgIGdldCBpc05lZ2F0aXZlU3RhY2soKTogYm9vbGVhbiB7IHJldHVybiB0aGlzLl9pc05lZ2F0aXZlU3RhY2s7IH1cclxuXHJcbiAgICAvLyA9PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT0gVmVydGljYWwgQXhpcyA9PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09XHJcblxyXG4gICAgLyoqXHJcbiAgICAgKiBmb3Igcm90YXRpbmcgdmVydGljYWwgYXhpcy4gaWYgYXhpcyBpcyBlbmFibGVkLCBhcHBlbmRzIGNsYXNzLW5hbWUgJ3JvdGF0ZS10aXRsZScgdG8ga2QgY2hhcnRzLlxyXG4gICAgICogcGFyYW0gIHtBcnJheTxzdHJpbmc+fSBfdHlwZSAgIGNoYXJ0IHR5cGU6IGlmIGhvcml6b250YWwgYmFyLCB1c2UgeEF4aXMncyh0aGUgdmVydGljYWwgYXhpcykgY29uZmlnXHJcbiAgICAgKiBwYXJhbSAge2FueX0gICAgICAgICAgIF9jb25maWdcclxuICAgICAqIHJldHVybiB7Ym9vbGVhbn1cclxuICAgICAqL1xyXG4gICAgcHVibGljIGNoZWNrUm90YXRlVGl0bGVFbmFibGVkKF90eXBlOiBBcnJheTxzdHJpbmc+LCBfY29uZmlnOiBhbnkpOiBib29sZWFuIHtcclxuICAgICAgICBsZXQgYXhpc0NvbmZpZzogYW55ID0gX3R5cGVbMF0gPT09ICdiYXInID8gX2NvbmZpZy54QXhpcyA6IF9jb25maWcueUF4aXM7XHJcbiAgICAgICAgcmV0dXJuIGF4aXNDb25maWcuZW5hYmxlZCAmJiBheGlzQ29uZmlnLnRpdGxlLnRleHQgIT09ICcnO1xyXG4gICAgfVxyXG5cclxuICAgIHB1YmxpYyBzZXRWZXJ0QXhpc0FuZENoYXJ0TWFyZ2luKF9pZDogc3RyaW5nKTogdm9pZCB7XHJcbiAgICAgICAgbGV0IGNoYXJ0Q29udGFpbmVyOiBFbGVtZW50ID0gZG9jdW1lbnQucXVlcnlTZWxlY3RvcignIycgKyBfaWQgKyAnLmtkeC1jaGFydHMgLmtkeC1jaGFydC1jb250YWluZXInKTtcclxuICAgICAgICBsZXQgYXhpc0NvbmZpZzogYW55ID0gdGhpcy5faXNJbnZlcnQgPyB0aGlzLl9jb25maWcueEF4aXMgOiB0aGlzLl9jb25maWcueUF4aXM7XHJcblxyXG4gICAgICAgIC8vIHNldHRpbmcgY3NzIGZvciB2ZXJ0aWNhbCBheGlzXHJcbiAgICAgICAgaWYgKGF4aXNDb25maWcuZW5hYmxlZCAmJiBheGlzQ29uZmlnLnRpdGxlLnRleHQgIT09ICcnKSB7XHJcbiAgICAgICAgICAgIGxldCBjdXJyQXhpc1RpdGxlQ2xhc3M6IHN0cmluZyA9IHRoaXMuX2lzSW52ZXJ0ID8gJy5rZHgtY2hhcnRzLWF4aXMtdGl0bGUteCcgOiAnLmtkeC1jaGFydHMtYXhpcy10aXRsZS15JztcclxuICAgICAgICAgICAgdGhpcy5fY3VyclZlcnRBeGlzVGl0bGUgPSBkb2N1bWVudC5xdWVyeVNlbGVjdG9yKCcjJyArIF9pZCArICcua2R4LWNoYXJ0cyAnICsgY3VyckF4aXNUaXRsZUNsYXNzICsgJy5rZHgtY2hhcnRzLWF4aXMtdGl0bGUnKTtcclxuICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICB0aGlzLl9jdXJyVmVydEF4aXNUaXRsZSA9IG51bGw7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICB0aGlzLnNldENoYXJ0Q29udGFpbmVyTWFyZ2luKGNoYXJ0Q29udGFpbmVyKTtcclxuICAgIH1cclxuXHJcbiAgICBwdWJsaWMgcmVwb3NpdGlvblZlcnRpY2FsQXhpc1RpdGxlKCk6IHZvaWQge1xyXG4gICAgICAgIGlmICghdGhpcy5pc1ZhbHVlRXhpc3QodGhpcy5fY3VyclZlcnRBeGlzVGl0bGUpKSByZXR1cm47XHJcblxyXG4gICAgICAgIGxldCBheGlzVGl0bGVDbGFzczogc3RyaW5nID0gdGhpcy5faXNJbnZlcnQgPyAnLmtkeC1jaGFydHMtYXhpcy10aXRsZS14JyA6ICcua2R4LWNoYXJ0cy1heGlzLXRpdGxlLXknO1xyXG4gICAgICAgIGxldCBheGlzVGl0bGVUZXh0QXJyOiBhbnkgPSBkb2N1bWVudC5xdWVyeVNlbGVjdG9yQWxsKCcjJyArIHRoaXMuX2NvbmZpZy5pZCArICcua2R4LWNoYXJ0cyAnICsgYXhpc1RpdGxlQ2xhc3MgKyAnIC5rZHgtY2hhcnRzLWF4aXMtdGl0bGUtdGV4dCcpO1xyXG4gICAgICAgIGF4aXNUaXRsZVRleHRBcnIuZm9yRWFjaChheGlzVGl0bGVUZXh0ID0+IHtcclxuICAgICAgICAgICAgYXhpc1RpdGxlVGV4dC5zdHlsZS50b3AgPSB0aGlzLl9jdXJyVmVydEF4aXNUaXRsZS5nZXRCb3VuZGluZ0NsaWVudFJlY3QoKS5oZWlnaHQgLyAyICsgYXhpc1RpdGxlVGV4dC5nZXRCb3VuZGluZ0NsaWVudFJlY3QoKS5oZWlnaHQgLyAyICsgJ3B4JztcclxuICAgICAgICAgICAgYXhpc1RpdGxlVGV4dC5zdHlsZS52aXNpYmlsaXR5ID0gJ3Vuc2V0JztcclxuICAgICAgICB9KTtcclxuICAgIH1cclxuXHJcbiAgICAvLyA9PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT0gWSBBeGlzIExhYmVsID09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT1cclxuXHJcbiAgICBwdWJsaWMgc2V0TWF4QW5kTWluKF95QXhpc0NvbmZpZzogSVlBeGlzQ29uZmlnLCBfZGF0YVJhbmdlOiBJRDNEYXRhUmFuZ2UpOiBJTWF4TWluSW50ZXJ2YWwge1xyXG4gICAgICAgIGxldCBtYXhWYWx1ZTogbnVtYmVyID0gdGhpcy5pc1ZhbHVlRXhpc3QoX3lBeGlzQ29uZmlnLm1heFZhbHVlKSA/IF95QXhpc0NvbmZpZy5tYXhWYWx1ZSA6IF9kYXRhUmFuZ2UubWF4O1xyXG4gICAgICAgIGxldCBtaW5WYWx1ZTogbnVtYmVyID0gdGhpcy5pc1ZhbHVlRXhpc3QoX3lBeGlzQ29uZmlnLm1pblZhbHVlKSA/IF95QXhpc0NvbmZpZy5taW5WYWx1ZSA6IF9kYXRhUmFuZ2UubWluO1xyXG5cclxuICAgICAgICAvLyBlbnN1cmUgdGhhdCBtaW4gdmFsdWUgd2lsbCBub3QgZXhjZWVkIG1heCwgdmljZSB2ZXJzZVxyXG4gICAgICAgIG1heFZhbHVlID0gTWF0aC5tYXgobWF4VmFsdWUsIG1pblZhbHVlKTtcclxuICAgICAgICBtaW5WYWx1ZSA9IE1hdGgubWluKG1heFZhbHVlLCBtaW5WYWx1ZSk7XHJcblxyXG4gICAgICAgIGxldCBpbnRlcnZhbDogbnVtYmVyID0gZDMubWF4KFtfeUF4aXNDb25maWcudGlja0ludGVydmFsLCBfeUF4aXNDb25maWcubWlub3JUaWNrSW50ZXJ2YWxdKTtcclxuXHJcbiAgICAgICAgaWYgKCFpbnRlcnZhbCB8fCBpbnRlcnZhbCA8PSAwKSBpbnRlcnZhbCA9IDE7XHJcblxyXG4gICAgICAgIC8vIHRvIHByZXZlbnQgdGljayBjYWxjdWxhdGlvbiBjYXVzaW5nIHN0b3Atc2NyaXB0LCBvbmx5IGFsbG93IGF0IG1vc3QgYXJvdW5kIDEwMDAgdGlja3MgKGV4Y2x1ZGluZyBmaXJzdCB0aWNrKVxyXG4gICAgICAgIGxldCBzbWFsbGVzdFBvc3NpYmxlSW50ZXJ2YWw6IG51bWJlciA9IChtYXhWYWx1ZSAtIG1pblZhbHVlKSAvIDEwMDA7XHJcbiAgICAgICAgaWYgKHNtYWxsZXN0UG9zc2libGVJbnRlcnZhbCA+IGludGVydmFsKSB7XHJcbiAgICAgICAgICAgIGludGVydmFsID0gdGhpcy5pc0ludGVyZ2VyKGludGVydmFsKSA/IE1hdGguZmxvb3Ioc21hbGxlc3RQb3NzaWJsZUludGVydmFsKSA6IHNtYWxsZXN0UG9zc2libGVJbnRlcnZhbDtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIHJldHVybiB7XHJcbiAgICAgICAgICAgIG1heFZhbHVlOiBtYXhWYWx1ZSxcclxuICAgICAgICAgICAgbWluVmFsdWU6IG1pblZhbHVlLFxyXG4gICAgICAgICAgICBpbnRlcnZhbDogaW50ZXJ2YWxcclxuICAgICAgICB9O1xyXG4gICAgfVxyXG5cclxuICAgIHB1YmxpYyBzZXRBeGlzRDNGb3JtYXQoX2ludGVydmFsOiBudW1iZXIpOiB2b2lkIHtcclxuICAgICAgICBsZXQgZGVjaW1hbFBsYWNlOiBudW1iZXIgPSB0aGlzLmZpbmREZWNpbWFsUGxhY2UoX2ludGVydmFsKTtcclxuICAgICAgICB0aGlzLl9heGlzRDNGb3JtYXQgPSB0aGlzLmdldEQzRm9ybWF0KF9pbnRlcnZhbCwgZGVjaW1hbFBsYWNlKTtcclxuICAgIH1cclxuXHJcbiAgICBwdWJsaWMgZ2V0WUF4aXNMYWJlbFRleHQoX3lBeGlzQ29uZmlnOiBJWUF4aXNDb25maWcsIF92YWx1ZTogbnVtYmVyKTogc3RyaW5nIHtcclxuICAgICAgICByZXR1cm4gdGhpcy5nZXRMYWJlbFRleHQoX3lBeGlzQ29uZmlnLmxhYmVscy5mb3JtYXQsIF92YWx1ZSwgZmFsc2UsIHRoaXMuX2F4aXNEM0Zvcm1hdCk7XHJcbiAgICB9XHJcblxyXG4gICAgLyoqXHJcbiAgICAgKiBZIGF4aXMgbGFiZWwgZHVtbXkuIGFwcGVuZHMgdGV4dCBlbGVtZW50IHRvIHN2ZyBhbmQgcmV0dXJucyB0aGUgd2lkdGggb2YgbGFiZWxcclxuICAgICAqIHBhcmFtICB7bnVtYmVyIHwgICAgICBzdHJpbmd9ICAgICAgX3ZhbHVlOiBsYWJlbCdzIHZhbHVlXHJcbiAgICAgKiBwYXJhbSAge3N0cmluZ30gICAgICAgICAgICAgICAgICAgIF9jbGFzczogY2xhc3MgbmFtZSBmb3IgZHVtbXlcclxuICAgICAqIHJldHVybiB7bnVtYmVyfSAgICAgICAgICAgICAgICAgICAgcmV0dXJucyBhY3R1YWwgcmVuZGVyZWQgd2lkdGggb2YgbGFiZWxcclxuICAgICAqL1xyXG4gICAgcHVibGljIHNldER1bW15QXhpc0xhYmVsKF92YWx1ZTogbnVtYmVyLCBfY2xhc3M6IHN0cmluZyk6IG51bWJlciB7XHJcbiAgICAgICAgLy8gaWYgKCF0aGlzLl9jb25maWcueUF4aXMuZW5hYmxlZCkgcmV0dXJuIDA7XHJcblxyXG4gICAgICAgIGxldCB5QXhpc0NvbmZpZzogSVlBeGlzQ29uZmlnID0gdGhpcy5fY29uZmlnLnlBeGlzO1xyXG5cclxuICAgICAgICAvLyBpZiBheGlzIGlzIGVuYWJsZWQsIGRyYXcgYXhpc01heCBzdHJpbmcgYW5kIGF4aXNNaW4gc3RyaW5nIHRvIGNvbXB1dGUgdGhpcy53aWR0aC9oZWlnaHRcclxuICAgICAgICBsZXQgdGV4dFNlbGVjdGlvbjogYW55ID0gdGhpcy5fc3ZnLnNlbGVjdEFsbCgnLmR1bW15LScgKyBfY2xhc3MpO1xyXG4gICAgICAgIGxldCB0ZXh0OiBzdHJpbmcgPSB0aGlzLmdldFlBeGlzTGFiZWxUZXh0KHlBeGlzQ29uZmlnLCBfdmFsdWUpO1xyXG5cclxuICAgICAgICAvLyBlbGVtZW50IHNob3VsZCBvbmx5IGJlIGFwcGVuZGVkIG9uY2VcclxuICAgICAgICBpZiAodGV4dFNlbGVjdGlvbi5lbXB0eSgpKSB0ZXh0U2VsZWN0aW9uID0gdGhpcy5fc3ZnLmFwcGVuZCgndGV4dCcpO1xyXG5cclxuICAgICAgICB0aGlzLnNldFN2Z0F0dHJpYnV0ZSh0ZXh0U2VsZWN0aW9uLCBPYmplY3QuYXNzaWduKHt9LCB5QXhpc0NvbmZpZy5sYWJlbHMuc3R5bGUsIHsgY2xhc3M6ICdrZHgtY2hhcnRzLWR1bW15IGR1bW15LScgKyBfY2xhc3MsIG9wYWNpdHk6IDAgfSkpO1xyXG5cclxuICAgICAgICB0ZXh0U2VsZWN0aW9uLnRleHQodGV4dCk7XHJcblxyXG4gICAgICAgIHJldHVybiB0ZXh0U2VsZWN0aW9uLm5vZGUoKS5nZXRCQm94KCkud2lkdGg7XHJcbiAgICB9XHJcblxyXG4gICAgLyoqXHJcbiAgICAgKiBjaGFydCB3aWR0aCBhbmQgaGVpZ2h0IGhhdmUgdG8gYmUgY2FsY3VsYXRlZCBiYXNlZCBvbiBob3cgbG9uZyB5IGF4aXMgbGFiZWxzIGFyZSAoZWc6IGEgbG90IG9mIHNwYWNlIGFsbG9jYXRlZCBmb3IgMSwwMDAsMDAwIGFzIGNvbXBhcmVkIHRvIDEwKVxyXG4gICAgICogcmV0dXJucyB0aGlzLndpZHRoIG9yIHRoaXMuaGVpZ2h0IGRlcGVuZGluZyBvbiBfYXhpcyBnaXZlblxyXG4gICAgICogcGFyYW0gIHsneCd8J3knfSAgICAgICAgIF9heGlzXHJcbiAgICAgKiBwYXJhbSAgeyBheGlzTWF4OiBudW1iZXIsIGF4aXNNaW46IG51bWJlciB9IF9heGlzVmFsXHJcbiAgICAgKiByZXR1cm4ge251bWJlcn1cclxuICAgICAqL1xyXG4gICAgcHVibGljIGdldFN2Z09mZnNldChfYXhpczogJ3gnIHwgJ3knLCBfYXhpc1ZhbDogSVlBeGlzTGFiZWxSYW5nZSk6IG51bWJlciB7XHJcbiAgICAgICAgbGV0IGF4aXNPcHBvc2l0ZTogYm9vbGVhbiA9IF9heGlzID09PSAneCcgPyB0aGlzLl9jb25maWcueUF4aXMub3Bwb3NpdGUgOiB0aGlzLl9jb25maWcueEF4aXMub3Bwb3NpdGU7XHJcbiAgICAgICAgbGV0IG9wcG9zaXRlOiBib29sZWFuID0gYXhpc09wcG9zaXRlICE9PSB0aGlzLl9pc1J0bDtcclxuICAgICAgICBsZXQgeUF4aXNMYWJlbHNOb3RWaXNpYmxlOiBib29sZWFuID0gIXRoaXMuX2NvbmZpZy55QXhpcy5lbmFibGVkIHx8ICF0aGlzLl9jb25maWcueUF4aXMubGFiZWxzLmVuYWJsZWQ7XHJcblxyXG4gICAgICAgIGlmIChfYXhpcyA9PT0gJ3gnKSB0aGlzLl95QXhpc0xhYmVsV2lkdGggPSB0aGlzLmdldFlBeGlzTWF4QW5kTWluTGFiZWxXaWR0aChfYXhpc1ZhbCk7XHJcblxyXG4gICAgICAgIGxldCBpbnRlcm5hbFlBeGlzTGFiZWxXaWR0aDogeyBheGlzTWF4OiBudW1iZXIsIGF4aXNNaW46IG51bWJlciB9ID0gdGhpcy5feUF4aXNMYWJlbFdpZHRoO1xyXG4gICAgICAgIGlmICh5QXhpc0xhYmVsc05vdFZpc2libGUpIGludGVybmFsWUF4aXNMYWJlbFdpZHRoID0geyBheGlzTWF4OiAwLCBheGlzTWluOiAwIH07XHJcblxyXG4gICAgICAgIGlmICghdGhpcy5faXNJbnZlcnQpIHtcclxuICAgICAgICAgICAgaWYgKF9heGlzID09PSAneCcpIHtcclxuICAgICAgICAgICAgICAgIGxldCBzdGFydDogJ3JpZ2h0JyB8ICdsZWZ0JyA9IG9wcG9zaXRlID8gJ3JpZ2h0JyA6ICdsZWZ0JztcclxuICAgICAgICAgICAgICAgIGxldCBlbmQ6ICdyaWdodCcgfCAnbGVmdCcgPSBvcHBvc2l0ZSA/ICdsZWZ0JyA6ICdyaWdodCc7XHJcbiAgICAgICAgICAgICAgICB0aGlzLl9zdmdNYXJnaW5bc3RhcnRdID0gdGhpcy5fZGVmYXVsdFN2Z01hcmdpbi55ICsgTWF0aC5tYXgoaW50ZXJuYWxZQXhpc0xhYmVsV2lkdGguYXhpc01heCwgaW50ZXJuYWxZQXhpc0xhYmVsV2lkdGguYXhpc01pbik7XHJcbiAgICAgICAgICAgICAgICB0aGlzLl9zdmdNYXJnaW5bZW5kXSA9IHRoaXMuX2RlZmF1bHRTdmdNYXJnaW4ub3BwVmVydDtcclxuICAgICAgICAgICAgICAgIHJldHVybiB0aGlzLl9zdmdSZWN0LndpZHRoIC0gdGhpcy5fc3ZnTWFyZ2luW3N0YXJ0XSAtIHRoaXMuX3N2Z01hcmdpbltlbmRdO1xyXG4gICAgICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgbGV0IHN0YXJ0OiAndG9wJyB8ICdib3R0b20nID0gYXhpc09wcG9zaXRlID8gJ2JvdHRvbScgOiAndG9wJztcclxuICAgICAgICAgICAgICAgIGxldCBlbmQ6ICd0b3AnIHwgJ2JvdHRvbScgPSBheGlzT3Bwb3NpdGUgPyAndG9wJyA6ICdib3R0b20nO1xyXG4gICAgICAgICAgICAgICAgbGV0IGxhYmVsRm9udFNpemU6IG51bWJlciA9IHlBeGlzTGFiZWxzTm90VmlzaWJsZSA/IDAgOiB0aGlzLnJlcGxhY2VTdHJpbmdXaXRoTnVtYmVyKHRoaXMuX2NvbmZpZy55QXhpcy5sYWJlbHMuc3R5bGUuZm9udFNpemUpO1xyXG4gICAgICAgICAgICAgICAgdGhpcy5fc3ZnTWFyZ2luW2VuZF0gPSBNYXRoLm1heCh0aGlzLl9kZWZhdWx0U3ZnTWFyZ2luLngsIDAuNSAqIGxhYmVsRm9udFNpemUpO1xyXG4gICAgICAgICAgICAgICAgdGhpcy5fc3ZnTWFyZ2luW3N0YXJ0XSA9IHRoaXMuaXNOZWdhdGl2ZVN0YWNrID8gdGhpcy5fc3ZnTWFyZ2luW2VuZF0gOiB0aGlzLl9kZWZhdWx0U3ZnTWFyZ2luLnRvcDtcclxuICAgICAgICAgICAgICAgIHJldHVybiB0aGlzLl9zdmdSZWN0LmhlaWdodCAtIHRoaXMuX3N2Z01hcmdpbltzdGFydF0gLSB0aGlzLl9zdmdNYXJnaW5bZW5kXTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgIGlmIChfYXhpcyA9PT0gJ3gnKSB7XHJcbiAgICAgICAgICAgICAgICBsZXQgc3RhcnQ6ICd0b3AnIHwgJ2JvdHRvbScgPSBheGlzT3Bwb3NpdGUgPyAnYm90dG9tJyA6ICd0b3AnO1xyXG4gICAgICAgICAgICAgICAgbGV0IGVuZDogJ3RvcCcgfCAnYm90dG9tJyA9IGF4aXNPcHBvc2l0ZSA/ICd0b3AnIDogJ2JvdHRvbSc7XHJcbiAgICAgICAgICAgICAgICBsZXQgbGFiZWxGb250U2l6ZTogbnVtYmVyID0geUF4aXNMYWJlbHNOb3RWaXNpYmxlID8gMCA6IHRoaXMucmVwbGFjZVN0cmluZ1dpdGhOdW1iZXIodGhpcy5fY29uZmlnLnlBeGlzLmxhYmVscy5zdHlsZS5mb250U2l6ZSk7XHJcbiAgICAgICAgICAgICAgICB0aGlzLl9zdmdNYXJnaW5bc3RhcnRdID0gdGhpcy5fZGVmYXVsdFN2Z01hcmdpbi50b3A7XHJcbiAgICAgICAgICAgICAgICB0aGlzLl9zdmdNYXJnaW5bZW5kXSA9IHRoaXMuX2RlZmF1bHRTdmdNYXJnaW4ueSArIGxhYmVsRm9udFNpemU7XHJcbiAgICAgICAgICAgICAgICByZXR1cm4gdGhpcy5fc3ZnUmVjdC5oZWlnaHQgLSB0aGlzLl9zdmdNYXJnaW5bc3RhcnRdIC0gdGhpcy5fc3ZnTWFyZ2luW2VuZF07XHJcbiAgICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgICAgICBsZXQgc3RhcnQ6ICdyaWdodCcgfCAnbGVmdCcgPSBvcHBvc2l0ZSA/ICdyaWdodCcgOiAnbGVmdCc7XHJcbiAgICAgICAgICAgICAgICBsZXQgZW5kOiAncmlnaHQnIHwgJ2xlZnQnID0gb3Bwb3NpdGUgPyAnbGVmdCcgOiAncmlnaHQnO1xyXG4gICAgICAgICAgICAgICAgbGV0IHN0YXJ0TGFiZWxXaWR0aDogbnVtYmVyID0gb3Bwb3NpdGUgPT09IHRoaXMuaXNZUmV2ZXJzZWQgPyBpbnRlcm5hbFlBeGlzTGFiZWxXaWR0aC5heGlzTWluIDogaW50ZXJuYWxZQXhpc0xhYmVsV2lkdGguYXhpc01heDtcclxuICAgICAgICAgICAgICAgIGxldCBlbmRMYWJlbFdpZHRoOiBudW1iZXIgPSBvcHBvc2l0ZSA9PT0gdGhpcy5pc1lSZXZlcnNlZCA/IGludGVybmFsWUF4aXNMYWJlbFdpZHRoLmF4aXNNYXggOiBpbnRlcm5hbFlBeGlzTGFiZWxXaWR0aC5heGlzTWluO1xyXG4gICAgICAgICAgICAgICAgdGhpcy5fc3ZnTWFyZ2luW3N0YXJ0XSA9IE1hdGgubWF4KHRoaXMuX2RlZmF1bHRTdmdNYXJnaW4ueCwgc3RhcnRMYWJlbFdpZHRoIC8gMik7XHJcbiAgICAgICAgICAgICAgICB0aGlzLl9zdmdNYXJnaW5bZW5kXSA9IHRoaXMuaXNOZWdhdGl2ZVN0YWNrID8gTWF0aC5tYXgodGhpcy5fZGVmYXVsdFN2Z01hcmdpbi54LCBlbmRMYWJlbFdpZHRoIC8gMikgOiBlbmRMYWJlbFdpZHRoIC8gMiArIHRoaXMuX2RlZmF1bHRTdmdNYXJnaW4ub3BwVmVydDtcclxuICAgICAgICAgICAgICAgIHJldHVybiB0aGlzLl9zdmdSZWN0LndpZHRoIC0gdGhpcy5fc3ZnTWFyZ2luW3N0YXJ0XSAtIHRoaXMuX3N2Z01hcmdpbltlbmRdO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIC8qKlxyXG4gICAgICogcm91bmQgYXhpc01heC9NaW4gdmFsdWUgdG8gaW50ZXJ2YWwgKGVnOiBNYXggdmFsdWUgaXMgMTAgYnV0IGludGVydmFsIGlzIDMsIHNvIG1heCB2YWx1ZSB3aWxsIGJlIHJvdW5kZWQgdG8gZWl0aGVyIDkgb3IgMTIpXHJcbiAgICAgKiBfaXNBdXRvUm91bmRUb05leHRJbnRlcnZhbCBpcyBlbmFibGVkLCByb3VuZCB0byAxMlxyXG4gICAgICogX2lzQXV0b1JvdW5kVG9OZXh0SW50ZXJ2YWwgaXMgZGlzYWJsZWQsIHJvdW5kIHRvIDlcclxuICAgICAqXHJcbiAgICAgKiBwYXJhbSAge251bWJlcn0gIF92YWx1ZVxyXG4gICAgICogcGFyYW0gIHtudW1iZXJ9ICBfaW50ZXJ2YWxcclxuICAgICAqIHBhcmFtICB7Ym9vbGVhbn0gX2lzQXV0b1JvdW5kVG9OZXh0SW50ZXJ2YWxcclxuICAgICAqIHBhcmFtICB7J3VwJyB8ICdkb3duJ30gICAgICBfcm91bmREaXJcclxuICAgICAqIHJldHVybiB7bnVtYmVyfVxyXG4gICAgICovXHJcbiAgICBwdWJsaWMgc2V0QXhpc1JvdW5kVmFsdWUoX3ZhbHVlOiBudW1iZXIsIF9pbnRlcnZhbDogbnVtYmVyLCBfaXNBdXRvUm91bmRUb05leHRJbnRlcnZhbDogYm9vbGVhbiwgX3JvdW5kRGlyOiAndXAnIHwgJ2Rvd24nKTogbnVtYmVyIHtcclxuICAgICAgICAvLyBpZiB2YWx1ZSBpcyAwLCBkb24ndCByb3VuZFxyXG4gICAgICAgIGlmIChfdmFsdWUgPT09IDApIHJldHVybiBfdmFsdWU7XHJcblxyXG4gICAgICAgIGxldCBkZWNpbWFsUGxhY2VzOiBudW1iZXIgPSBNYXRoLm1heCh0aGlzLmZpbmREZWNpbWFsUGxhY2UoX3ZhbHVlKSwgdGhpcy5maW5kRGVjaW1hbFBsYWNlKF9pbnRlcnZhbCkpO1xyXG5cclxuICAgICAgICBpZiAoZGVjaW1hbFBsYWNlcyAhPT0gMCkge1xyXG4gICAgICAgICAgICAvLyBpZiBfdmFsdWUgb3IgX2ludGVydmFsIGhhdmUgZGVjaW1hbCwgY29udmVydCB0aGVtIHRvIHdob2xlIG51bWJlcnNcclxuICAgICAgICAgICAgX3ZhbHVlID0gX3ZhbHVlICogTWF0aC5wb3coMTAsIGRlY2ltYWxQbGFjZXMpO1xyXG4gICAgICAgICAgICBfaW50ZXJ2YWwgPSBfaW50ZXJ2YWwgKiBNYXRoLnBvdygxMCwgZGVjaW1hbFBsYWNlcyk7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICBsZXQgc2lnbjogbnVtYmVyID0gTWF0aC5zaWduKF92YWx1ZSk7XHJcbiAgICAgICAgbGV0IG5ld1ZhbHVlOiBudW1iZXIgPSBfdmFsdWUgLSBfdmFsdWUgJSBfaW50ZXJ2YWw7XHJcblxyXG4gICAgICAgIGlmIChfcm91bmREaXIgPT09ICd1cCcpIHtcclxuICAgICAgICAgICAgaWYgKHNpZ24gPCAwKSB7XHJcbiAgICAgICAgICAgICAgICBpZiAoIV9pc0F1dG9Sb3VuZFRvTmV4dEludGVydmFsKSBuZXdWYWx1ZSA9IG5ld1ZhbHVlIC0gX2ludGVydmFsO1xyXG4gICAgICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgaWYgKF9pc0F1dG9Sb3VuZFRvTmV4dEludGVydmFsKSBuZXdWYWx1ZSA9IG5ld1ZhbHVlICsgX2ludGVydmFsO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgaWYgKHNpZ24gPCAwKSB7XHJcbiAgICAgICAgICAgICAgICBpZiAoX2lzQXV0b1JvdW5kVG9OZXh0SW50ZXJ2YWwpIG5ld1ZhbHVlID0gbmV3VmFsdWUgLSBfaW50ZXJ2YWw7XHJcbiAgICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgICAgICBpZiAoIV9pc0F1dG9Sb3VuZFRvTmV4dEludGVydmFsKSBuZXdWYWx1ZSA9IG5ld1ZhbHVlICsgX2ludGVydmFsO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICBpZiAoZGVjaW1hbFBsYWNlcyAhPT0gMCkgbmV3VmFsdWUgPSBuZXdWYWx1ZSAvIE1hdGgucG93KDEwLCBkZWNpbWFsUGxhY2VzKTtcclxuXHJcbiAgICAgICAgcmV0dXJuIG5ld1ZhbHVlO1xyXG4gICAgfVxyXG5cclxuICAgIHB1YmxpYyBnZXRUaWNrVmFsdWVzKF9taW46IG51bWJlciwgX21heDogbnVtYmVyLCBfaW50ZXJ2YWw6IG51bWJlcik6IEFycmF5PG51bWJlcj4ge1xyXG4gICAgICAgIGlmICghX2ludGVydmFsIHx8IHR5cGVvZiBfbWluID09PSAndW5kZWZpbmVkJyB8fCB0eXBlb2YgX21heCA9PT0gJ3VuZGVmaW5lZCcpIHJldHVybiBbXTtcclxuXHJcbiAgICAgICAgX21heCA9IHRoaXMuX2dldFVwcGVyQm91bmRGb3JUaWNrVmFsdWVzKF9tYXgsIF9pbnRlcnZhbCk7XHJcblxyXG4gICAgICAgIHJldHVybiBkMy5yYW5nZShfbWluLCBfbWF4LCBfaW50ZXJ2YWwpO1xyXG4gICAgfVxyXG5cclxuICAgIC8qKlxyXG4gICAgICogc2V0IFkgYXhpcyBMYWJlbCBDb25maWdcclxuICAgICAqIHBhcmFtIHthbnl9ICAgICAgICBfYXhpcyBpcyBFbGVtZW50L2QzLXNlbGVjdGlvblxyXG4gICAgICogcGFyYW0geyd4QXhpcycgfCAneUF4aXMnfSAgICAgX2RpcmVjdGlvblxyXG4gICAgICovXHJcbiAgICBwdWJsaWMgc2V0QXhpc0xhYmVsQ29uZmlnKF9heGlzOiBhbnksIF9kaXJlY3Rpb246ICd4JyB8ICd5Jyk6IHZvaWQge1xyXG4gICAgICAgIGxldCBheGlzRGlyOiBzdHJpbmcgPSBfZGlyZWN0aW9uICsgJ0F4aXMnO1xyXG4gICAgICAgIGlmICghdGhpcy5fY29uZmlnW2F4aXNEaXJdKSByZXR1cm47XHJcbiAgICAgICAgbGV0IGF4aXNDb25maWcgPSB0aGlzLl9jb25maWdbYXhpc0Rpcl07XHJcblxyXG4gICAgICAgIF9heGlzLnNlbGVjdEFsbCgncGF0aCcpXHJcbiAgICAgICAgICAgIC5hdHRyKCdzdHJva2Utd2lkdGgnLCBheGlzQ29uZmlnLmxpbmVXaWR0aClcclxuICAgICAgICAgICAgLmF0dHIoJ3N0cm9rZScsIGF4aXNDb25maWcubGluZUNvbG9yKTtcclxuXHJcbiAgICAgICAgX2F4aXMuc2VsZWN0QWxsKCdsaW5lJylcclxuICAgICAgICAgICAgLmF0dHIoJ3N0cm9rZS13aWR0aCcsIGF4aXNDb25maWcubGluZVdpZHRoKVxyXG4gICAgICAgICAgICAuYXR0cignc3Ryb2tlJywgYXhpc0NvbmZpZy5saW5lQ29sb3IpO1xyXG5cclxuICAgICAgICBpZiAoX2RpcmVjdGlvbiA9PT0gJ3gnIHx8ICFheGlzQ29uZmlnLmVuYWJsZWQgfHwgIXRoaXMuX2NvbmZpZ1theGlzRGlyXS5sYWJlbHMuZW5hYmxlZCkge1xyXG4gICAgICAgICAgICB0aGlzLnNldFN2Z0F0dHJpYnV0ZShfYXhpcy5zZWxlY3RBbGwoJ3RleHQnKSwgeyBkaXNwbGF5OiAnbm9uZScgfSk7XHJcbiAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgdGhpcy5zZXRTdmdBdHRyaWJ1dGUoX2F4aXMuc2VsZWN0QWxsKCd0ZXh0JyksIGF4aXNDb25maWcubGFiZWxzLnN0eWxlKTtcclxuICAgICAgICAgICAgdGhpcy5zZXRTdmdBdHRyaWJ1dGUoX2F4aXMuc2VsZWN0QWxsKCd0ZXh0JyksIHsgY2xhc3M6ICdrZHgtY2hhcnRzLWRpc3BsYXktbnVtYmVyLWluc2lkZS1zdmcga2R4LWNoYXJ0cy1kaXNwbGF5LW51bWJlcicgfSk7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIHB1YmxpYyBnZXRZQXhpc01heEFuZE1pbkxhYmVsV2lkdGgoX2F4aXNWYWw6IElZQXhpc0xhYmVsUmFuZ2UpOiBJWUF4aXNMYWJlbFJhbmdlIHtcclxuICAgICAgICBsZXQgd2lkdGhPYmo6IElZQXhpc0xhYmVsUmFuZ2UgPSB7IGF4aXNNYXg6IDAsIGF4aXNNaW46IDAgfTtcclxuXHJcbiAgICAgICAgLy8gaWYgKHRoaXMuX2NvbmZpZy55QXhpcy5sYWJlbHMuZW5hYmxlZCkge1xyXG4gICAgICAgIHdpZHRoT2JqLmF4aXNNYXggPSB0aGlzLnNldER1bW15QXhpc0xhYmVsKF9heGlzVmFsLmF4aXNNYXgsICdheGlzTWF4Jyk7XHJcbiAgICAgICAgd2lkdGhPYmouYXhpc01pbiA9IHRoaXMuc2V0RHVtbXlBeGlzTGFiZWwoX2F4aXNWYWwuYXhpc01pbiwgJ2F4aXNNaW4nKTtcclxuICAgICAgICAvLyB9XHJcblxyXG4gICAgICAgIHJldHVybiB3aWR0aE9iajtcclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF9nZXRVcHBlckJvdW5kRm9yVGlja1ZhbHVlcyhfbWF4OiBudW1iZXIsIF9pbnRlcnZhbDogbnVtYmVyKTogbnVtYmVyIHtcclxuICAgICAgICBsZXQgZGVjaW1hbFBsYWNlczogbnVtYmVyID0gTWF0aC5tYXgodGhpcy5maW5kRGVjaW1hbFBsYWNlKF9tYXgpLCB0aGlzLmZpbmREZWNpbWFsUGxhY2UoX2ludGVydmFsKSk7XHJcblxyXG4gICAgICAgIF9tYXggPSBfbWF4ICogTWF0aC5wb3coMTAsIGRlY2ltYWxQbGFjZXMpO1xyXG4gICAgICAgIF9pbnRlcnZhbCA9IF9pbnRlcnZhbCAqIE1hdGgucG93KDEwLCBkZWNpbWFsUGxhY2VzKTtcclxuXHJcbiAgICAgICAgcmV0dXJuIChfbWF4ICsgX2ludGVydmFsKSAvIE1hdGgucG93KDEwLCBkZWNpbWFsUGxhY2VzKTtcclxuICAgIH1cclxuXHJcbiAgICAvLyA9PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT0gWCBBeGlzIExhYmVsID09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT1cclxuXHJcbiAgICAvKipcclxuICAgICAqIHNldCBheGlzIExhYmVsIENvbnRhaW5lciAoY3VycmVudGx5IG9ubHkgdXNlZCBmb3IgWCBheGlzKVxyXG4gICAgICogcGFyYW0gIHtudW1iZXJ9IF94U3BhY2luZ1xyXG4gICAgICogcGFyYW0gIHtzdHJpbmd9IF9leHRyYUNsYXNzTmFtZSBbc2FtZSBsZXZlbCBhcyAua2R4LWNoYXJ0cy1heGlzLWxhYmVsLWNvbnRhaW5lci4gQWRkaXRpb25hbCBjbGFzc05hbWUgaW4gY2FzZSBvZiBkb3VibGVBeGlzXVxyXG4gICAgICogcmV0dXJuIHthbnl9XHJcbiAgICAgKi9cclxuICAgIHB1YmxpYyBzZXRBeGlzTGFiZWxDb250YWluZXIoX2V4dHJhQ2xhc3NOYW1lOiBzdHJpbmcgPSAnJyk6IGFueSB7XHJcbiAgICAgICAgdGhpcy5fYXhpc0xhYmVsQ29udGFpbmVyID0gZDMuc2VsZWN0KCcjJyArIHRoaXMuX2NvbmZpZy5pZCArICcua2R4LWNoYXJ0cyAua2R4LWNoYXJ0cy1heGlzLWxhYmVsLWNvbnRhaW5lcicgKyBfZXh0cmFDbGFzc05hbWUpO1xyXG4gICAgICAgIGlmICghdGhpcy5pc1ZhbHVlRXhpc3QodGhpcy5fYXhpc0xhYmVsQ29udGFpbmVyLm5vZGUoKSkpIHJldHVybjtcclxuXHJcbiAgICAgICAgcmV0dXJuIHRoaXMuX2F4aXNMYWJlbENvbnRhaW5lcjtcclxuICAgIH1cclxuXHJcbiAgICAvKioqKiBBeGlzIExhYmVsIER1bW15ICoqKioqKiovXHJcblxyXG4gICAgcHVibGljIHNldEF4aXNMYWJlbER1bW15KF9pZDogc3RyaW5nLCBfeFNwYWNpbmc6IG51bWJlciwgX2xvbmdlc3RUZXh0OiBzdHJpbmcpOiB2b2lkIHtcclxuICAgICAgICB0aGlzLl9zZXRBeGlzTGFiZWxEdW1teUVsZW1lbnQoX2lkKTtcclxuICAgICAgICB0aGlzLnNldEF4aXNMYWJlbER1bW15VGV4dChfbG9uZ2VzdFRleHQpO1xyXG4gICAgICAgIHRoaXMuaXNSb3RhdGUgPSB0aGlzLl9jaGVja1JvdGF0ZSh0aGlzLl9pc0ludmVydCwgX3hTcGFjaW5nLCB0aGlzLl9taW5YU3BhY2luZyk7XHJcbiAgICAgICAgdGhpcy5fc2V0QXhpc0xhYmVsRHVtbXlTdHlsZShfeFNwYWNpbmcpO1xyXG4gICAgfVxyXG5cclxuICAgIHB1YmxpYyBzZXRBeGlzTGFiZWxEdW1teVRleHQoX2xvbmdlc3RUZXh0OiBzdHJpbmcpOiB2b2lkIHtcclxuICAgICAgICBpZiAoIXRoaXMuX2F4aXNMYWJlbER1bW15KSByZXR1cm47XHJcbiAgICAgICAgX2xvbmdlc3RUZXh0ID0gdGhpcy5nZXRMYWJlbEZvcm1hdFJlcGxhY2UodGhpcy5jb25maWcueEF4aXMubGFiZWxzLmZvcm1hdCwgX2xvbmdlc3RUZXh0KTtcclxuICAgICAgICB0aGlzLl9zZXRBeGlzTGFiZWxEdW1teUh0bWwoX2xvbmdlc3RUZXh0KTtcclxuICAgIH1cclxuXHJcbiAgICBwdWJsaWMgZ2V0QXhpc0xhYmVsRHVtbXlSZWN0KCk6IGFueSB7XHJcbiAgICAgICAgaWYgKCF0aGlzLl9heGlzTGFiZWxEdW1teSkgcmV0dXJuIDA7XHJcbiAgICAgICAgcmV0dXJuIHRoaXMuX2F4aXNMYWJlbER1bW15LmdldEJvdW5kaW5nQ2xpZW50UmVjdCgpO1xyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX3NldEF4aXNMYWJlbER1bW15RWxlbWVudChfaWQ6IHN0cmluZyk6IHZvaWQge1xyXG4gICAgICAgIGlmICh0eXBlb2YgdGhpcy5fYXhpc0xhYmVsRHVtbXkgPT09ICd1bmRlZmluZWQnKSB7XHJcbiAgICAgICAgICAgIHRoaXMuX2F4aXNMYWJlbER1bW15ID0gZG9jdW1lbnQucXVlcnlTZWxlY3RvcignIycgKyBfaWQgKyAnLmtkeC1jaGFydHMgLmtkeC1jaGFydHMtaW52aXNpYmxlLWF4aXMtbGFiZWwnKTtcclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfc2V0QXhpc0xhYmVsRHVtbXlIdG1sKF90ZXh0OiBzdHJpbmcpOiB2b2lkIHtcclxuICAgICAgICBpZiAoIXRoaXMuX2F4aXNMYWJlbER1bW15KSByZXR1cm47XHJcbiAgICAgICAgdGhpcy5fYXhpc0xhYmVsRHVtbXkuaW5uZXJIVE1MID0gX3RleHQ7XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfc2V0QXhpc0xhYmVsRHVtbXlTdHlsZShfeFNwYWNpbmc6IG51bWJlcik6IHZvaWQge1xyXG4gICAgICAgIGlmICghdGhpcy5faXNJbnZlcnQgJiYgIXRoaXMuaXNSb3RhdGUpIHtcclxuICAgICAgICAgICAgdGhpcy5fYXhpc0xhYmVsRHVtbXkuc3R5bGUubWF4V2lkdGggPSBfeFNwYWNpbmcgKyAncHgnO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICAvKioqKiBPdGhlcnMgKioqKioqKi9cclxuXHJcbiAgICBwcml2YXRlIF9jaGVja1JvdGF0ZShfaXNJbnZlcnQ6IGJvb2xlYW4sIF94U3BhY2luZzogbnVtYmVyLCBfbWluWFNwYWNpbmc6IG51bWJlcik6IGJvb2xlYW4ge1xyXG4gICAgICAgIC8vIGlmIGVhY2ggYmFyL3hTcGFjaW5nIGhhcyBhdCBsZWFzdCA1MCBweCwgZG8gbm90IHJvdGF0ZSwgbGV0IHRoZSBsYWJlbCB3b3JkLXdyYXBcclxuICAgICAgICBpZiAoX3hTcGFjaW5nID49IF9taW5YU3BhY2luZyB8fCBfaXNJbnZlcnQpIHJldHVybiBmYWxzZTtcclxuICAgICAgICAvLyByb3RhdGUgb25seSBpZiB4U3BhY2luZyA8IDUwcHggQU5EIHRoZSBhY3R1YWwgdGV4dCh3aXRoIHBhZGRkaW5nKSBsZW5ndGggPiBlYWNoIGJhci94U3BhY2luZ1xyXG4gICAgICAgIHJldHVybiB0aGlzLmdldEF4aXNMYWJlbER1bW15UmVjdCgpLndpZHRoID4gX3hTcGFjaW5nO1xyXG4gICAgfVxyXG5cclxuICAgIHB1YmxpYyBfc2V0QXhpc0xhYmVsTGVuZ3RoKCk6IHZvaWQge1xyXG4gICAgICAgIGxldCBsb25nZXN0TGVuZ3RoOiBudW1iZXIgPSB0aGlzLmdldEF4aXNMYWJlbER1bW15UmVjdCgpLndpZHRoIHx8IDAsXHJcbiAgICAgICAgICAgIHN2Z1BhcmVudFJlY3Q6IGFueSA9IHRoaXMuX3N2Z1BhcmVudFJlY3QsXHJcbiAgICAgICAgICAgIHN2Z0xlbmd0aDogbnVtYmVyID0gKHRoaXMuX2lzSW52ZXJ0ID8gc3ZnUGFyZW50UmVjdC53aWR0aCA6IHN2Z1BhcmVudFJlY3QuaGVpZ2h0KSB8fCAwLFxyXG4gICAgICAgICAgICBsYWJlbExlbmd0aDogbnVtYmVyID0gTWF0aC5taW4obG9uZ2VzdExlbmd0aCwgMC4zICogc3ZnTGVuZ3RoKTtcclxuXHJcbiAgICAgICAgdGhpcy5fbGFiZWxMZW5ndGggPSBsYWJlbExlbmd0aDtcclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF9nZXRBeGlzTWFyZ2luKF9pc0ludmVydDogYm9vbGVhbiwgX2lzUm90YXRlOiBib29sZWFuKTogeyB0b3A6IG51bWJlcjsgbGVmdDogbnVtYmVyOyByaWdodDogbnVtYmVyOyB9IHtcclxuICAgICAgICBsZXQgYXhpc01hcmdpbjogeyB0b3A6IG51bWJlcjsgbGVmdDogbnVtYmVyOyByaWdodDogbnVtYmVyOyB9ID0geyB0b3A6IDAsIGxlZnQ6IDAsIHJpZ2h0OiAwIH07XHJcbiAgICAgICAgbGV0IG9wcG9zaXRlOiBib29sZWFuID0gdGhpcy5fY29uZmlnLnlBeGlzLm9wcG9zaXRlIHx8IGZhbHNlO1xyXG5cclxuICAgICAgICBpZiAoIV9pc0ludmVydCkge1xyXG4gICAgICAgICAgICBsZXQgdGl0bGVXaWR0aDogbnVtYmVyID0gMDtcclxuICAgICAgICAgICAgbGV0IHNpZGU6ICdyaWdodCcgfCAnbGVmdCcgPSB0aGlzLl9pc1J0bCA/ICdyaWdodCcgOiAnbGVmdCc7XHJcbiAgICAgICAgICAgIGxldCBzaWduOiBudW1iZXIgPSB0aGlzLl9pc1J0bCA/IC0xIDogMTtcclxuICAgICAgICAgICAgb3Bwb3NpdGUgPSBvcHBvc2l0ZSAhPT0gdGhpcy5faXNSdGw7XHJcblxyXG4gICAgICAgICAgICBpZiAoIW9wcG9zaXRlICYmIHRoaXMuaXNWYWx1ZUV4aXN0KHRoaXMuX2N1cnJWZXJ0QXhpc1RpdGxlKSkge1xyXG4gICAgICAgICAgICAgICAgdGl0bGVXaWR0aCA9IHRoaXMuX2N1cnJWZXJ0QXhpc1RpdGxlLmdldEJvdW5kaW5nQ2xpZW50UmVjdCgpLndpZHRoO1xyXG4gICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICBheGlzTWFyZ2luW3NpZGVdID0gc2lnbiAqICh0aGlzLl9zdmdNYXJnaW4ubGVmdCArIHRpdGxlV2lkdGgpO1xyXG4gICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgIGF4aXNNYXJnaW4udG9wID0gdGhpcy5fc3ZnTWFyZ2luLnRvcDtcclxuICAgICAgICAgICAgaWYgKG9wcG9zaXRlKSBheGlzTWFyZ2luLnRvcCArPSB0aGlzLl9nZXRIb3JpelRpdGxlSGVpZ2h0KCk7XHJcblxyXG4gICAgICAgICAgICBheGlzTWFyZ2luLnJpZ2h0ID0gMjtcclxuICAgICAgICB9XHJcbiAgICAgICAgcmV0dXJuIGF4aXNNYXJnaW47XHJcbiAgICB9XHJcblxyXG4gICAgcHVibGljIHNldEF4aXNMYWJlbENvbnRhaW5lclN0eWxlKF9jb250YWluZXI6IGFueSk6IHZvaWQge1xyXG4gICAgICAgIGxldCBzdHlsZVR5cGU6ICd3aWR0aCcgfCAnaGVpZ2h0JyA9IHRoaXMuX2lzSW52ZXJ0ID8gJ3dpZHRoJyA6ICdoZWlnaHQnO1xyXG4gICAgICAgIGxldCBzdHlsZVZhbDogbnVtYmVyID0gdGhpcy5sYWJlbExlbmd0aDtcclxuXHJcbiAgICAgICAgaWYgKCF0aGlzLl9pc0ludmVydCAmJiAhdGhpcy5pc1JvdGF0ZSkge1xyXG4gICAgICAgICAgICBzdHlsZVZhbCA9IHRoaXMuZ2V0QXhpc0xhYmVsRHVtbXlSZWN0KCkuaGVpZ2h0O1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgX2NvbnRhaW5lci5zdHlsZShzdHlsZVR5cGUsIHN0eWxlVmFsICsgJ3B4Jyk7XHJcbiAgICAgICAgaWYgKCF0aGlzLl9pc0ludmVydCkgX2NvbnRhaW5lci5zdHlsZSgnd2lkdGgnLCAnMTAwJScpO1xyXG5cclxuICAgICAgICB0aGlzLl9heGlzTGFiZWxEdW1teS5zdHlsZS5tYXhXaWR0aCA9ICcxMDAlJztcclxuXHJcblxyXG4gICAgICAgIGxldCBtYXJnaW46IHsgdG9wOiBudW1iZXI7IGxlZnQ6IG51bWJlcjsgcmlnaHQ6IG51bWJlcjsgfSA9IHRoaXMuX2dldEF4aXNNYXJnaW4odGhpcy5faXNJbnZlcnQsIHRoaXMuaXNSb3RhdGUpO1xyXG5cclxuICAgICAgICBfY29udGFpbmVyXHJcbiAgICAgICAgICAgIC5zdHlsZSgnbWFyZ2luLXRvcCcsIG1hcmdpbi50b3AgKyAncHgnKVxyXG4gICAgICAgICAgICAuc3R5bGUoJ21hcmdpbi1yaWdodCcsIG1hcmdpbi5yaWdodCArICdweCcpXHJcbiAgICAgICAgICAgIC5zdHlsZSgnbWFyZ2luLWxlZnQnLCBtYXJnaW4ubGVmdCArICdweCcpO1xyXG5cclxuICAgICAgICB0aGlzLl9heGlzTGFiZWxDb250YWluZXJNYXJnaW5MZWZ0ID0gbWFyZ2luLmxlZnQ7XHJcbiAgICB9XHJcblxyXG4gICAgLyoqXHJcbiAgICAgKiBzZXQgWCBheGlzIExhYmVsIFBvc2l0aW9uXHJcbiAgICAgKiBwYXJhbSB7YW55fSAgICAgX2xhYmVsQ29udGFpbmVyXHJcbiAgICAgKiBwYXJhbSB7bnVtYmVyfSAgX3RpY2tQb3NcclxuICAgICAqIHBhcmFtIHtJQXhpc0xhYmVsQm9vbGVhbkNoZWNrc30gX2Jvb2xlYW5DaGVja3NcclxuICAgICAqL1xyXG4gICAgcHVibGljIHNldEF4aXNMYWJlbFBvc2l0aW9uKF9sYWJlbENvbnRhaW5lcjogYW55LCBfdGlja1BvczogbnVtYmVyLCBfYm9vbGVhbkNoZWNrczogSUF4aXNMYWJlbEJvb2xlYW5DaGVja3MpOiB2b2lkIHtcclxuICAgICAgICBpZiAodGhpcy5faXNJbnZlcnQgfHwgX2Jvb2xlYW5DaGVja3MuaXNSb3RhdGUgfHwgKF9ib29sZWFuQ2hlY2tzLmlzTGFzdCAmJiB0aGlzLl94U2NhbGVUeXBlID09PSAnc3RyaW5nJykpIHtcclxuICAgICAgICAgICAgdGhpcy5fZG9tU3ZjLmFkZENsYXNzKF9sYWJlbENvbnRhaW5lci5ub2RlKCksICdlbGxpcHNpcycpO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgLy8gd2hlbiByb3RhdGluZywgdGhlcmUgc2hvdWxkbid0IGJlIGFueSBwYWRkaW5nKC5rZHgtY2hhcnRzLWNoaWxkLXBhZGRpbmctYm90aCkgb3IgJ3NwZWNpYWwnIHBhZGRpbmcgKC5rZHgtY2hhcnRzLWNoaWxkLXNwZWNpYWwtcGFkZGluZylcclxuICAgICAgICAvLyBtdXN0IGV4ZWN1dGUgYmVmb3JlIG9mZnNldCBwb3NpdGlvblxyXG4gICAgICAgIGlmIChfYm9vbGVhbkNoZWNrcy5pc1JvdGF0ZSkgX2xhYmVsQ29udGFpbmVyLnN0eWxlKCdwYWRkaW5nJywgMCk7XHJcblxyXG4gICAgICAgIGxldCBsYWJlbFJlY3Q6IGFueSA9IF9sYWJlbENvbnRhaW5lci5ub2RlKCkuZ2V0Qm91bmRpbmdDbGllbnRSZWN0KCksXHJcbiAgICAgICAgICAgIG9mZnNldDogbnVtYmVyID0gIXRoaXMuX2lzSW52ZXJ0ICYmICFfYm9vbGVhbkNoZWNrcy5pc1JvdGF0ZSA/IGxhYmVsUmVjdC53aWR0aCAvIDIgOiBsYWJlbFJlY3QuaGVpZ2h0IC8gMixcclxuICAgICAgICAgICAgb2ZmU2V0U2lnbjogbnVtYmVyID0gX2Jvb2xlYW5DaGVja3MuaXNSb3RhdGUgJiYgX2Jvb2xlYW5DaGVja3Mub3Bwb3NpdGUgPyAtMSA6IDEsXHJcbiAgICAgICAgICAgIHBvc2l0aW9uOiBudW1iZXIgPSBfdGlja1BvcyAtIG9mZnNldCAqIG9mZlNldFNpZ247XHJcblxyXG4gICAgICAgIC8vIGZvciBob3Jpem9udGFsIGJhclxyXG4gICAgICAgIGlmICh0aGlzLl9pc0ludmVydCkge1xyXG4gICAgICAgICAgICBsZXQgaG9yaXpEaXI6IHN0cmluZyA9IHRoaXMuX2lzUnRsICE9PSBfYm9vbGVhbkNoZWNrcy5vcHBvc2l0ZSA/ICdsZWZ0JyA6ICdyaWdodCc7XHJcbiAgICAgICAgICAgIF9sYWJlbENvbnRhaW5lclxyXG4gICAgICAgICAgICAgICAgLnN0eWxlKCd0b3AnLCBwb3NpdGlvbiArICdweCcpXHJcbiAgICAgICAgICAgICAgICAuc3R5bGUoaG9yaXpEaXIsIDAgKyAncHgnKTtcclxuICAgICAgICAgICAgcmV0dXJuO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgbGV0IHZlcnREaXI6IHN0cmluZyA9IF9ib29sZWFuQ2hlY2tzLm9wcG9zaXRlID8gJ2JvdHRvbScgOiAndG9wJztcclxuXHJcbiAgICAgICAgLy8gZm9yIGFsbCBvdGhlciBheGlzIGNoYXJ0c1xyXG4gICAgICAgIGlmIChfYm9vbGVhbkNoZWNrcy5pc1JvdGF0ZSkge1xyXG4gICAgICAgICAgICBsZXQgdmVydERpc3Q6IG51bWJlciA9IF9ib29sZWFuQ2hlY2tzLmlzUm90YXRlICYmICFfYm9vbGVhbkNoZWNrcy5vcHBvc2l0ZSA/IGxhYmVsUmVjdC53aWR0aCA6IDA7XHJcblxyXG4gICAgICAgICAgICBfbGFiZWxDb250YWluZXJcclxuICAgICAgICAgICAgICAgIC5zdHlsZSh2ZXJ0RGlyLCB2ZXJ0RGlzdCArICdweCcpXHJcbiAgICAgICAgICAgICAgICAuc3R5bGUoJ3RyYW5zZm9ybScsICdyb3RhdGUoLTkwZGVnKScpO1xyXG5cclxuICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICBpZiAodGhpcy5feFNjYWxlVHlwZSA9PT0gJ3N0cmluZycpIHtcclxuICAgICAgICAgICAgICAgIC8vIHdoZW4gcG9zaXRpb24gaXMgbmVnYXRpdmUgYW5kIGl0J3MgYWJzb2x1dGUgdmFsdWUgaXMgbW9yZSB0aGFuIHRoZSBtYXJnaW4gb2YgYXhpc0xhYmVsQ29udGFpbmVyXHJcbiAgICAgICAgICAgICAgICBpZiAocG9zaXRpb24gKyB0aGlzLl9heGlzTGFiZWxDb250YWluZXJNYXJnaW5MZWZ0IDwgMCkge1xyXG4gICAgICAgICAgICAgICAgICAgIGxldCBkaWZmOiBudW1iZXIgPSBNYXRoLmFicyhwb3NpdGlvbikgLSB0aGlzLl9heGlzTGFiZWxDb250YWluZXJNYXJnaW5MZWZ0O1xyXG4gICAgICAgICAgICAgICAgICAgIF9sYWJlbENvbnRhaW5lci5zdHlsZSgnbWF4LXdpZHRoJywgKGxhYmVsUmVjdC53aWR0aCAtIDIgKiBkaWZmKSArICdweCcpO1xyXG4gICAgICAgICAgICAgICAgICAgIHBvc2l0aW9uID0gLTEgKiB0aGlzLl9heGlzTGFiZWxDb250YWluZXJNYXJnaW5MZWZ0O1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgaWYgKF9ib29sZWFuQ2hlY2tzLmlzTGFzdCkgX2xhYmVsQ29udGFpbmVyLnN0eWxlKCdtYXgtd2lkdGgnLCAobGFiZWxSZWN0LndpZHRoIC8gMiArIHRoaXMuX3N2Z01hcmdpbi5yaWdodCkgKyAncHgnKTtcclxuICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgX2xhYmVsQ29udGFpbmVyLnN0eWxlKHZlcnREaXIsIDAgKyAncHgnKTtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIF9sYWJlbENvbnRhaW5lci5zdHlsZSgnbGVmdCcsIHBvc2l0aW9uICsgJ3B4Jyk7XHJcbiAgICB9XHJcblxyXG4gICAgLy8gPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09IERhdGEgTGFiZWxzID09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT1cclxuXHJcbiAgICAvKipcclxuICAgICAqIGRhdGEgbGFiZWxzIGhhdmUgdG8gYmUgcmVwb3NpdGlvbmVkIGFjY29yZGluZyB0byB0aXRsZSBhbmQgYXhpcyBMYWJlbHMncyB3aWR0aCBhbmQgcG9zaXRpb25cclxuICAgICAqIHBhcmFtIHthbnl9IF9kYXRhTGFiZWxDb250YWluZXIgZDMtc2VsZWN0aW9uXHJcbiAgICAgKiBwYXJhbSB7YW55fSBfYXhpc0xhYmVsQ29udGFpbmVyIGQzLXNlbGVjdGlvblxyXG4gICAgICovXHJcbiAgICBwdWJsaWMgcmVwb3NpdGlvbkRhdGFMYWJlbChfZGF0YUxhYmVsQ29udGFpbmVyOiBhbnksIF9heGlzTGFiZWxDb250YWluZXI/OiBhbnkpOiB2b2lkIHtcclxuICAgICAgICBsZXQgYXhpc0xhYmVsQ29udGFpbmVyUmVjdCA9IHRoaXMuaXNWYWx1ZUV4aXN0KF9heGlzTGFiZWxDb250YWluZXIpID8gX2F4aXNMYWJlbENvbnRhaW5lci5ub2RlKCkuZ2V0Qm91bmRpbmdDbGllbnRSZWN0KCkgOiB7IHdpZHRoOiAwLCBoZWlnaHQ6IDAgfTtcclxuXHJcbiAgICAgICAgbGV0IGxlZnQ6IG51bWJlciA9IHRoaXMuX2NhbGN1bGF0ZURhdGFMYWJlbExlZnQoYXhpc0xhYmVsQ29udGFpbmVyUmVjdC53aWR0aCk7XHJcbiAgICAgICAgbGV0IHRvcDogbnVtYmVyID0gdGhpcy5fY2FsY3VsYXRlRGF0YUxhYmVsVG9wKGF4aXNMYWJlbENvbnRhaW5lclJlY3QuaGVpZ2h0KTtcclxuXHJcbiAgICAgICAgX2RhdGFMYWJlbENvbnRhaW5lclxyXG4gICAgICAgICAgICAuc3R5bGUoJ2xlZnQnLCBsZWZ0ICsgJ3B4JylcclxuICAgICAgICAgICAgLnN0eWxlKCd0b3AnLCB0b3AgKyAncHgnKTtcclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF9jYWxjdWxhdGVEYXRhTGFiZWxMZWZ0KF9sYWJlbFdpZHRoKTogbnVtYmVyIHtcclxuICAgICAgICBsZXQgb3Bwb3NpdGU6IGJvb2xlYW4gPSB0aGlzLl9pc0ludmVydCA/IHRoaXMuX2NvbmZpZy54QXhpcy5vcHBvc2l0ZSA6IHRoaXMuX2NvbmZpZy55QXhpcy5vcHBvc2l0ZTtcclxuICAgICAgICBsZXQgY2hhcnRNYXJnaW5MZWZ0OiBzdHJpbmcgPSB0aGlzLl9jb25maWcuY2hhcnQubWFyZ2luLmxlZnQ7XHJcblxyXG4gICAgICAgIC8vIHdoZW4gdmVydGljYWwgYXhpcyBvbiByaWdodCAob25seSBvbmUgYXhpcyksIGxlZnQgc2lkZSBoYXZlIG5vIGF4aXNcclxuICAgICAgICAvLyBOT1RFOiBkbyBub3QgcnVuIHRoaXMgc3RlcCB3aGVuIGNvbHVtbi9iYXItc3RhY2stbmVnYXRpdmUsIHNpbmNlIGJvdGggbGVmdCBhbmQgcmlnaHQgc2lkZSBoYXZlIHZlcnRpY2FsIGF4aXNcclxuICAgICAgICBpZiAob3Bwb3NpdGUgIT09IHRoaXMuX2lzUnRsICYmICF0aGlzLmlzTmVnYXRpdmVTdGFjaykge1xyXG4gICAgICAgICAgICByZXR1cm4gdGhpcy5fc3ZnTWFyZ2luLmxlZnQgKyB0aGlzLnJlcGxhY2VTdHJpbmdXaXRoTnVtYmVyKGNoYXJ0TWFyZ2luTGVmdCk7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICAvLyB3aGVuIHZlcnRpY2FsIGF4aXMgb24gbGVmdFxyXG4gICAgICAgIGxldCB0aXRsZVdpZHRoOiBudW1iZXIgPSB0aGlzLmlzVmFsdWVFeGlzdCh0aGlzLl9jdXJyVmVydEF4aXNUaXRsZSkgPyB0aGlzLl9jdXJyVmVydEF4aXNUaXRsZS5nZXRCb3VuZGluZ0NsaWVudFJlY3QoKS53aWR0aCA6IDA7XHJcbiAgICAgICAgbGV0IGxlZnQ6IG51bWJlciA9IHRoaXMucmVwbGFjZVN0cmluZ1dpdGhOdW1iZXIoY2hhcnRNYXJnaW5MZWZ0KTtcclxuXHJcbiAgICAgICAgbGVmdCArPSB0aGlzLl9pc0ludmVydCA/IHRpdGxlV2lkdGggKyBfbGFiZWxXaWR0aCArIHRoaXMuX3N2Z01hcmdpbi5sZWZ0ICsgMiA6IHRpdGxlV2lkdGggKyB0aGlzLl9zdmdNYXJnaW4ubGVmdDtcclxuXHJcbiAgICAgICAgcmV0dXJuIGxlZnQ7XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfY2FsY3VsYXRlRGF0YUxhYmVsVG9wKF9sYWJlbEhlaWdodCk6IG51bWJlciB7XHJcbiAgICAgICAgbGV0IG9wcG9zaXRlOiBib29sZWFuID0gdGhpcy5faXNJbnZlcnQgPyB0aGlzLl9jb25maWcueUF4aXMub3Bwb3NpdGUgOiB0aGlzLl9jb25maWcueEF4aXMub3Bwb3NpdGU7XHJcblxyXG4gICAgICAgIC8vIHdoZW4gaG9yaXpvbnRhbCBheGlzIGlzIGF0IGJvdHRvbVxyXG4gICAgICAgIC8vIE5PVEU6IGRvIG5vdCBydW4gdGhpcyBzdGVwIHdoZW4gY29sdW1uL2Jhci1zdGFjay1uZWdhdGl2ZSwgc2luY2UgYm90aCBhYm92ZSBhbmQgYmVsb3cgaGF2ZSBob3Jpem9udGFsIGF4aXNcclxuICAgICAgICBpZiAoIW9wcG9zaXRlICYmICF0aGlzLmlzTmVnYXRpdmVTdGFjaykge1xyXG4gICAgICAgICAgICByZXR1cm4gdGhpcy5fc3ZnTWFyZ2luLnRvcCArIHRoaXMucmVwbGFjZVN0cmluZ1dpdGhOdW1iZXIodGhpcy5fY29uZmlnLmNoYXJ0Lm1hcmdpbi50b3ApO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgLy8gd2hlbiBob3Jpem9udGFsIGF4aXMgb24gdG9wXHJcbiAgICAgICAgbGV0IGhvcml6VGl0bGVIZWlnaHQ6IG51bWJlciA9IHRoaXMuX2dldEhvcml6VGl0bGVIZWlnaHQoKTtcclxuICAgICAgICBsZXQgdG9wOiBudW1iZXIgPSB0aGlzLnJlcGxhY2VTdHJpbmdXaXRoTnVtYmVyKHRoaXMuX2NvbmZpZy5jaGFydC5tYXJnaW4udG9wKTtcclxuXHJcbiAgICAgICAgdG9wICs9IHRoaXMuX2lzSW52ZXJ0ID8gaG9yaXpUaXRsZUhlaWdodCArIHRoaXMuX3N2Z01hcmdpbi50b3AgOiBob3JpelRpdGxlSGVpZ2h0ICsgdGhpcy5fc3ZnTWFyZ2luLnRvcCArIF9sYWJlbEhlaWdodDtcclxuXHJcbiAgICAgICAgcmV0dXJuIHRvcDtcclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF9nZXRIb3JpelRpdGxlSGVpZ2h0KCk6IG51bWJlciB7XHJcbiAgICAgICAgbGV0IGNsYXNzTmFtZTogc3RyaW5nID0gJyMnICsgdGhpcy5fY29uZmlnLmlkICsgJy5rZHgtY2hhcnRzIC5rZHgtY2hhcnRzLWF4aXMtdGl0bGUnO1xyXG4gICAgICAgIGNsYXNzTmFtZSArPSB0aGlzLl9pc0ludmVydCA/ICcteScgOiAnLXgnO1xyXG4gICAgICAgIGxldCBob3JpelRpdGxlRWxlbWVudCA9IGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3IoY2xhc3NOYW1lKTtcclxuXHJcbiAgICAgICAgcmV0dXJuIHRoaXMuaXNWYWx1ZUV4aXN0KGhvcml6VGl0bGVFbGVtZW50KSA/IGhvcml6VGl0bGVFbGVtZW50LmdldEJvdW5kaW5nQ2xpZW50UmVjdCgpLmhlaWdodCA6IDA7XHJcbiAgICB9XHJcblxyXG4gICAgLyoqKipWZXJ0aWNhbCBBbGlnbioqKioqL1xyXG5cclxuICAgIHB1YmxpYyBfZ2V0TGFiZWxUZXh0SGVpZ2h0KCk6IG51bWJlciB7XHJcbiAgICAgICAgbGV0IGxhYmVsU3R5bGU6IHsgW2tleTogc3RyaW5nXTogc3RyaW5nIH0gPSB0aGlzLl9jb25maWcuY2hhcnQubGFiZWxzLnN0eWxlO1xyXG4gICAgICAgIGxldCBmb250U2l6ZTogbnVtYmVyID0gdGhpcy5yZXBsYWNlU3RyaW5nV2l0aE51bWJlcihsYWJlbFN0eWxlLmZvbnRTaXplKTtcclxuICAgICAgICBsZXQgYm9yZGVyV2lkdGg6IG51bWJlciA9IHRoaXMucmVwbGFjZVN0cmluZ1dpdGhOdW1iZXIobGFiZWxTdHlsZS5ib3JkZXJXaWR0aCk7XHJcbiAgICAgICAgcmV0dXJuIGZvbnRTaXplICogMS4zICsgYm9yZGVyV2lkdGggKiAyO1xyXG4gICAgfVxyXG5cclxuICAgIHB1YmxpYyBfY2hlY2tCb3VuZGFyeShfdHlwZTogYW55LCBfeVBvc2l0aW9uOiBudW1iZXIsIF9jaGFydEhlaWdodDogbnVtYmVyLCBfZG90U2l6ZTogbnVtYmVyID0gMCk6IGJvb2xlYW4ge1xyXG4gICAgICAgIGxldCB0ZXh0U2l6ZTogbnVtYmVyID0gdGhpcy5fZ2V0TGFiZWxUZXh0SGVpZ2h0KCkgKyBfZG90U2l6ZSAvIDI7XHJcblxyXG4gICAgICAgIGlmIChfdHlwZSA9PT0gJ21heCcpIHtcclxuICAgICAgICAgICAgcmV0dXJuIF95UG9zaXRpb24gLSB0ZXh0U2l6ZSA8IHRoaXMuZGF0YUxhYmVsUHVzaERvd25SYW5nZTtcclxuICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICByZXR1cm4gX3lQb3NpdGlvbiArIHRleHRTaXplID4gX2NoYXJ0SGVpZ2h0IC0gdGhpcy5kYXRhTGFiZWxQdXNoRG93blJhbmdlO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICBwdWJsaWMgbmVlZE9mZnNldEZvckNvbHVtbihfdmVydGljYWxBbGlnbjogJ3RvcCcgfCAnbWlkZGxlJyB8ICdib3R0b20nLCBfcGFyYW1zOiB7IFtrZXk6IHN0cmluZ106IGFueSB9ID0ge30pOiBib29sZWFuIHwgbnVtYmVyIHtcclxuICAgICAgICBpZiAoIV9wYXJhbXMuZGltZW5zaW9ucykgcmV0dXJuIGZhbHNlO1xyXG4gICAgICAgIGlmIChfcGFyYW1zLnZhbHVlU2lnbiA8IDApIHtcclxuICAgICAgICAgICAgaWYgKF92ZXJ0aWNhbEFsaWduID09PSAndG9wJykgcmV0dXJuIC0xOyAvLyBuZWVkcyBvZmZzZXQsIHJldHVybmluZyB0cnVlIGNvbmRpdGlvblxyXG4gICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgIGlmIChfdmVydGljYWxBbGlnbiA9PT0gJ2JvdHRvbScpIHJldHVybiAxOyAvLyBuZWVkcyBvZmZzZXQsIHJldHVybmluZyB0cnVlIGNvbmRpdGlvblxyXG4gICAgICAgIH1cclxuICAgICAgICByZXR1cm4gZmFsc2U7XHJcbiAgICB9XHJcblxyXG4gICAgLy8gTk9URTogZGF0YSBsYWJlbCB2ZXJ0aWNhbCBhbGlnbiBpcyBub3QgZGVmaW5lZCBpbiBkZWZhdWx0IGNvbmZpZyAoYXMgb2YgdjMuNy4wIGJlY29zIGJlaGF2aW91ciBjaGFuZ2VzIHdpdGggZGlmZmVyZW50IGNoYXJ0IHR5cGVzKVxyXG4gICAgcHVibGljIGdldERlZmF1bHRWZXJ0aWNhbEFsaWduKF9jb25maWcsIF9wYXJhbXMpOiAndG9wJyB8ICdtaWRkbGUnIHwgJ2JvdHRvbScge1xyXG4gICAgICAgIGlmIChfY29uZmlnLmNoYXJ0LmxhYmVscy52ZXJ0aWNhbEFsaWduKSByZXR1cm4gX2NvbmZpZy5jaGFydC5sYWJlbHMudmVydGljYWxBbGlnbjtcclxuICAgICAgICBsZXQgZGVmYXVsdFZhbHVlOiAndG9wJyB8ICdtaWRkbGUnIHwgJ2JvdHRvbScgPSAndG9wJztcclxuICAgICAgICAvLyBmb3IgY29sdW1uLCBuZWdhdGl2ZSB2YWx1ZXMgbmVlZCB0byBiZSBwbGFjZWQgb24gYm90dG9tXHJcbiAgICAgICAgaWYgKF9wYXJhbXMudmFsdWVTaWduIDwgMCkgZGVmYXVsdFZhbHVlID0gJ2JvdHRvbSc7XHJcbiAgICAgICAgcmV0dXJuIGRlZmF1bHRWYWx1ZTtcclxuICAgIH1cclxuXHJcbiAgICAvLyA9PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT0gR2VuZXJhbCA9PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09XHJcblxyXG4gICAgLyoqXHJcbiAgICAgKiBpbiBhcmFiaWMsIG51bWJlcnMgYXJlIGluIGx0ciBtb2RlIChlZzogbmVnYXRpdmUgc2lnbiBpcyB0eXBlZCBmaXJzdClcclxuICAgICAqIEhlbmNlIHdyYXBwaW5nIGEgZGl2IGFyb3VuZCBudW1iZXIgKG9ubHkpIHdpdGggY2xhc3NOYW1lICcua2R4LWNoYXJ0cy1kaXNwbGF5LW51bWJlcicgdG8gZm9yY2UgZGlyZWN0aW9uOiBsdHJcclxuICAgICAqIHBhcmFtICB7bnVtYmVyfSBfbnVtYmVyXHJcbiAgICAgKiByZXR1cm4ge3N0cmluZ31cclxuICAgICAqL1xyXG4gICAgcHVibGljIHdyYXBOdW1iZXJJbklubGluZURpdihfbnVtYmVyOiBudW1iZXIgfCBzdHJpbmcpOiBzdHJpbmcge1xyXG4gICAgICAgIHJldHVybiAnPGRpdiBjbGFzcz1cImtkeC1jaGFydHMtZGlzcGxheS1udW1iZXJcIiBzdHlsZT1cImRpc3BsYXk6IGlubGluZS1ibG9jaztcIiBkaXI9XCJsdHJcIj4nICsgX251bWJlciArICc8L2Rpdj4nO1xyXG4gICAgfVxyXG5cclxuICAgIHB1YmxpYyByZXBsYWNlU3RyaW5nV2l0aE51bWJlcihfdmFsdWU6IHN0cmluZyB8IG51bWJlcik6IG51bWJlciB7XHJcbiAgICAgICAgaWYgKHR5cGVvZiBfdmFsdWUgPT09ICdudW1iZXInKSByZXR1cm4gX3ZhbHVlO1xyXG4gICAgICAgIHJldHVybiBwYXJzZUZsb2F0KF92YWx1ZS5yZXBsYWNlKC9bXjAtOS5dL2csICcnKSk7XHJcbiAgICB9XHJcblxyXG4gICAgcHVibGljIGdldEZvckxvb3BTZXF1ZW5jZShfY2hhcnRUeXBlOiBzdHJpbmdbXSk6ICdhc2NlbmRpbmcnIHwgJ2Rlc2NlbmRpbmcnIHtcclxuICAgICAgICByZXR1cm4gX2NoYXJ0VHlwZVswXSAhPT0gJ2JhcicgJiYgKF9jaGFydFR5cGVbMV0gPT09ICdzdGFjaycgfHwgX2NoYXJ0VHlwZVsxXSA9PT0gJzEwMCcpID8gJ2Rlc2NlbmRpbmcnIDogJ2FzY2VuZGluZyc7XHJcbiAgICB9XHJcblxyXG4gICAgcHVibGljIGdldEZvckxvb3BJbmZvKF90eXBlOiAnYXNjZW5kaW5nJyB8ICdkZXNjZW5kaW5nJywgYXJyTGVuZ3RoOiBudW1iZXIpOiBJRm9yTG9vcEluZm8ge1xyXG4gICAgICAgIHJldHVybiB7XHJcbiAgICAgICAgICAgIHN0YXJ0OiBfdHlwZSA9PT0gJ2FzY2VuZGluZycgPyAwIDogYXJyTGVuZ3RoIC0gMSxcclxuICAgICAgICAgICAgZW5kOiBfdHlwZSA9PT0gJ2FzY2VuZGluZycgPyBhcnJMZW5ndGggOiAtMSxcclxuICAgICAgICAgICAgY2hlY2s6IF90eXBlID09PSAnYXNjZW5kaW5nJyA/IChpLCBlbmQpID0+IGkgPCBlbmQgOiAoaSwgZW5kKSA9PiBpID4gZW5kLFxyXG4gICAgICAgICAgICBpdGVyYXRlOiBfdHlwZSA9PT0gJ2FzY2VuZGluZycgPyAoaSkgPT4gaSArIDEgOiAoaSkgPT4gaSAtIDEsXHJcbiAgICAgICAgfTtcclxuICAgIH1cclxuXHJcbiAgICBwdWJsaWMgZ2V0WEluZm8oX2RhdGE6IEFycmF5PElEM0RhdGFEYXRhPiwgX2NvbmZpZzogSUNoYXJ0Q29uZmlnKTogSVhJbmZvIHtcclxuICAgICAgICBsZXQgeEluZm86IElYSW5mbyA9IHtcclxuICAgICAgICAgICAgdmFsdWU6IFtdLFxyXG4gICAgICAgICAgICBsb25nZXN0VGV4dDogJydcclxuICAgICAgICB9O1xyXG4gICAgICAgIGxldCBsb25nZXN0VGV4dFdpZHRoOiBudW1iZXIgPSAwO1xyXG4gICAgICAgIGxldCBzaG93VmFsdWVJbkxhYmVsOiBib29sZWFuID0gX2NvbmZpZy54QXhpcy5sYWJlbHMuZm9ybWF0LmluZGV4T2YoJ3t2YWx1ZX0nKSA+IC0xICYmIF9jb25maWcueEF4aXMuZW5hYmxlZCAmJiBfY29uZmlnLnhBeGlzLmxhYmVscy5lbmFibGVkO1xyXG4gICAgICAgIGlmIChzaG93VmFsdWVJbkxhYmVsKSB0aGlzLl9zZXRBeGlzTGFiZWxEdW1teUVsZW1lbnQoX2NvbmZpZy5pZCk7XHJcblxyXG4gICAgICAgIF9kYXRhLmZvckVhY2goZCA9PiB7XHJcbiAgICAgICAgICAgIHhJbmZvLnZhbHVlLnB1c2goZC54LnZhbHVlKTtcclxuXHJcbiAgICAgICAgICAgIC8vIGlmIG5vIHZhbHVlIG5lZWRzIHRvIGJlIHNob3dlZCBpbiBsYWJlbCwgdGhlbiBubyBuZWVkIGNoZWNrIGxvbmdlc3QgdGV4dFxyXG4gICAgICAgICAgICBpZiAoc2hvd1ZhbHVlSW5MYWJlbCkge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5fc2V0QXhpc0xhYmVsRHVtbXlIdG1sKGQueC5sYWJlbCk7XHJcbiAgICAgICAgICAgICAgICBsZXQgY3VycmVudFdpZHRoOiBudW1iZXIgPSB0aGlzLmdldEF4aXNMYWJlbER1bW15UmVjdCgpLndpZHRoO1xyXG4gICAgICAgICAgICAgICAgaWYgKGN1cnJlbnRXaWR0aCA+IGxvbmdlc3RUZXh0V2lkdGgpIHtcclxuICAgICAgICAgICAgICAgICAgICBsb25nZXN0VGV4dFdpZHRoID0gY3VycmVudFdpZHRoO1xyXG4gICAgICAgICAgICAgICAgICAgIHhJbmZvLmxvbmdlc3RUZXh0ID0gZC54LmxhYmVsO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfSk7XHJcblxyXG4gICAgICAgIHJldHVybiB4SW5mbztcclxuICAgIH1cclxuXHJcbiAgICBwdWJsaWMgY2hlY2tBbmRSZXR1cm5MYWJlbHNQb3NpdGl2ZShfdmFsdWU6IG51bWJlcik6IG51bWJlciB7XHJcbiAgICAgICAgaWYgKHRoaXMuaXNOZWdhdGl2ZVN0YWNrKSB7XHJcbiAgICAgICAgICAgIGxldCBwbG90T3B0aW9uczogSVBsb3RPcHRpb25zID0gdGhpcy5jb25maWcucGxvdE9wdGlvbnM7XHJcbiAgICAgICAgICAgIGlmIChwbG90T3B0aW9ucyAmJiBwbG90T3B0aW9ucy5iYXIgJiYgdHlwZW9mIHBsb3RPcHRpb25zLmJhci5hbGxMYWJlbHNQb3NpdGl2ZSAhPT0gJ3VuZGVmaW5lZCcpIHtcclxuICAgICAgICAgICAgICAgIHJldHVybiB0aGlzLmNvbmZpZy5wbG90T3B0aW9ucy5iYXIuYWxsTGFiZWxzUG9zaXRpdmUgPyBNYXRoLmFicyhfdmFsdWUpIDogX3ZhbHVlO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIHJldHVybiBNYXRoLmFicyhfdmFsdWUpO1xyXG4gICAgICAgIH1cclxuICAgICAgICByZXR1cm4gX3ZhbHVlO1xyXG4gICAgfVxyXG5cclxuICAgIHB1YmxpYyBmaW5kRGVjaW1hbFBsYWNlKF9udW1iZXI6IG51bWJlcik6IG51bWJlciB7XHJcbiAgICAgICAgaWYgKHBhcnNlSW50KF9udW1iZXIudG9TdHJpbmcoKSkgPT09IF9udW1iZXIpIHJldHVybiAwO1xyXG4gICAgICAgIGxldCByZXN1bHQ6IG51bWJlciA9IDA7XHJcbiAgICAgICAgbGV0IHN0cmluZ0Zvcm06IHN0cmluZyA9IE1hdGguYWJzKF9udW1iZXIpLnRvU3RyaW5nKCk7XHJcbiAgICAgICAgbGV0IHNwbGl0QnlEb3Q6IEFycmF5PHN0cmluZz4gPSBzdHJpbmdGb3JtLnNwbGl0KCcuJyk7XHJcblxyXG4gICAgICAgIGlmIChzdHJpbmdGb3JtLmluZGV4T2YoJ2UnKSA8IDApIHtcclxuICAgICAgICAgICAgcmVzdWx0ID0gc3BsaXRCeURvdFsxXS5sZW5ndGg7XHJcbiAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgcmVzdWx0ID0gcGFyc2VJbnQoc3RyaW5nRm9ybS5zcGxpdCgnZS0nKVsxXSk7XHJcbiAgICAgICAgICAgIGlmICh0eXBlb2Ygc3BsaXRCeURvdFsxXSAhPT0gJ3VuZGVmaW5lZCcpIHJlc3VsdCArPSBzcGxpdEJ5RG90WzFdLmxlbmd0aDtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIHJldHVybiByZXN1bHQ7XHJcbiAgICB9XHJcblxyXG4gICAgcHVibGljIGdldExhYmVsVGV4dChfZm9ybWF0OiBzdHJpbmcsIF92YWx1ZTogbnVtYmVyIHwgc3RyaW5nLCBfaXNIVE1MOiBib29sZWFuID0gdHJ1ZSwgX2QzRm9ybWF0Pzogc3RyaW5nKTogc3RyaW5nIHtcclxuICAgICAgICBsZXQgZDNGb3JtYXQ6IHN0cmluZyA9IHR5cGVvZiBfZDNGb3JtYXQgPT09ICd1bmRlZmluZWQnID8gdGhpcy5nZXREM0Zvcm1hdChfdmFsdWUpIDogX2QzRm9ybWF0O1xyXG4gICAgICAgIGxldCB0ZXh0OiBzdHJpbmcgPSB0aGlzLmNoYW5nZVZhbHVlVG9EM0Zvcm1hdChfdmFsdWUsIGQzRm9ybWF0KTtcclxuXHJcbiAgICAgICAgaWYgKF9pc0hUTUwpIHRleHQgPSB0aGlzLndyYXBOdW1iZXJJbklubGluZURpdih0ZXh0KTtcclxuXHJcbiAgICAgICAgcmV0dXJuIHRoaXMuZ2V0TGFiZWxGb3JtYXRSZXBsYWNlKF9mb3JtYXQsIHRleHQpO1xyXG4gICAgfVxyXG5cclxuICAgIHB1YmxpYyBnZXRMYWJlbEZvcm1hdFJlcGxhY2UoX2Zvcm1hdDogc3RyaW5nLCBfdGV4dDogc3RyaW5nKTogc3RyaW5nIHtcclxuICAgICAgICByZXR1cm4gX2Zvcm1hdC5yZXBsYWNlKC97dmFsdWV9L2csIF90ZXh0KTtcclxuICAgIH1cclxuXHJcbiAgICBwdWJsaWMgaXNJbnRlcmdlcihfdmFsdWU6IG51bWJlciB8IHN0cmluZyk6IGJvb2xlYW4ge1xyXG4gICAgICAgIHJldHVybiB0eXBlb2YgX3ZhbHVlID09PSAnbnVtYmVyJyAmJiAoX3ZhbHVlICUgMSkgPT09IDA7XHJcbiAgICB9XHJcblxyXG4gICAgcHVibGljIGdldEQzRm9ybWF0KF92YWx1ZTogc3RyaW5nIHwgbnVtYmVyLCBfdG9EZWNpbWFsUGxhY2U/OiBudW1iZXIpOiBzdHJpbmcge1xyXG4gICAgICAgIGlmICh0eXBlb2YgX3ZhbHVlID09PSAnc3RyaW5nJykgcmV0dXJuICcnO1xyXG5cclxuICAgICAgICBpZiAoTWF0aC5hYnMoX3ZhbHVlKSA+IDEwMDAwMDAwKSByZXR1cm4gJy4yZSc7XHJcblxyXG4gICAgICAgIGlmICh0aGlzLmlzSW50ZXJnZXIoX3ZhbHVlKSkge1xyXG4gICAgICAgICAgICByZXR1cm4gJywnO1xyXG4gICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgIC8vIGlzIGRlY2ltYWxcclxuICAgICAgICAgICAgaWYgKE1hdGguYWJzKF92YWx1ZSkgPCAwLjAwMDAwMDAxKSByZXR1cm4gJy4yZSc7XHJcblxyXG4gICAgICAgICAgICBpZiAodHlwZW9mIF90b0RlY2ltYWxQbGFjZSAhPT0gJ3VuZGVmaW5lZCcgJiYgX3RvRGVjaW1hbFBsYWNlICE9PSAwKSB7XHJcbiAgICAgICAgICAgICAgICAvLyBpZiBwcmVjaXNpb24gaXMgZ2l2ZW5cclxuICAgICAgICAgICAgICAgIHJldHVybiAnLicgKyBfdG9EZWNpbWFsUGxhY2UudG9TdHJpbmcoKSArICdmJztcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgcmV0dXJuICcnO1xyXG4gICAgfVxyXG5cclxuICAgIHB1YmxpYyBjaGFuZ2VWYWx1ZVRvRDNGb3JtYXQoX3ZhbHVlOiBzdHJpbmcgfCBudW1iZXIsIF9mb3JtYXQ6IHN0cmluZyk6IHN0cmluZyB7XHJcbiAgICAgICAgaWYgKHR5cGVvZiBfdmFsdWUgPT09ICdzdHJpbmcnKSByZXR1cm4gX3ZhbHVlO1xyXG4gICAgICAgIHJldHVybiBkMy5mb3JtYXQoX2Zvcm1hdCkoX3ZhbHVlKTtcclxuICAgIH1cclxuXHJcbiAgICBwdWJsaWMgZ2V0TG9uZ2VyTnVtYmVyKF9udW0xOiBudW1iZXIsIF9udW0yOiBudW1iZXIpOiBudW1iZXIge1xyXG4gICAgICAgIHJldHVybiBfbnVtMS50b1N0cmluZygpLmxlbmd0aCA+IF9udW0yLnRvU3RyaW5nKCkubGVuZ3RoID8gX251bTEgOiBfbnVtMjtcclxuICAgIH1cclxuXHJcbiAgICBwdWJsaWMgc2V0Q2hhcnRDb250YWluZXJNYXJnaW4oX2NoYXJ0Q29udGFpbmVyOiBhbnkpOiB2b2lkIHtcclxuICAgICAgICBsZXQgbWFyZ2luOiBJQ2hhcnRNYXJnaW4gPSB0aGlzLl9jb25maWcuY2hhcnQubWFyZ2luO1xyXG4gICAgICAgIF9jaGFydENvbnRhaW5lci5zdHlsZS5wYWRkaW5nID0gbWFyZ2luLnRvcCArICcgJyArIG1hcmdpbi5yaWdodCArICcgJyArIG1hcmdpbi5ib3R0b20gKyAnICcgKyBtYXJnaW4ubGVmdDtcclxuICAgIH1cclxuXHJcbiAgICBwdWJsaWMgdHJhbnNmb3JtR3JhcGhDb250YWluZXIoX2NvbnRhaW5lcjogYW55KTogdm9pZCB7XHJcbiAgICAgICAgX2NvbnRhaW5lci5hdHRyKCd0cmFuc2Zvcm0nLCAndHJhbnNsYXRlKCcgKyB0aGlzLl9zdmdNYXJnaW4ubGVmdCArICcsJyArIHRoaXMuX3N2Z01hcmdpbi50b3AgKyAnKScpO1xyXG4gICAgfVxyXG5cclxuICAgIHB1YmxpYyBzZXRTdmdBdHRyaWJ1dGUoX2VsZW1lbnQ6IGFueSwgX2NvbmZpZzogeyBba2V5OiBzdHJpbmddOiBzdHJpbmcgfCBudW1iZXIgfSk6IHZvaWQge1xyXG4gICAgICAgIGZvciAobGV0IGtleSBpbiBfY29uZmlnKSB7XHJcbiAgICAgICAgICAgIGlmICghdGhpcy5pc1ZhbHVlRXhpc3QoX2NvbmZpZ1trZXldKSkgY29udGludWU7XHJcbiAgICAgICAgICAgIGxldCBhdHRyaWJ1dGVTdHI6IHN0cmluZyA9IGtleSA9PT0gJ2NvbG9yJyA/ICdmaWxsJyA6IGtleS5yZXBsYWNlKC8oW2EtekEtWl0pKD89W0EtWl0pL2csICckMS0nKS50b0xvd2VyQ2FzZSgpO1xyXG4gICAgICAgICAgICBfZWxlbWVudC5hdHRyKGF0dHJpYnV0ZVN0ciwgX2NvbmZpZ1trZXldKTtcclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgcHVibGljIGlzRXhpc3QoX3lFbGVtOiBhbnkpOiBib29sZWFuIHtcclxuICAgICAgICByZXR1cm4gKHR5cGVvZiBfeUVsZW0gIT09ICd1bmRlZmluZWQnICYmIF95RWxlbSAhPT0gbnVsbCAmJiBfeUVsZW0udmFsdWUgIT09IG51bGwpO1xyXG4gICAgfVxyXG5cclxuICAgIHB1YmxpYyBpc1ZhbHVlRXhpc3QoX3ZhbDogYW55KTogYm9vbGVhbiB7XHJcbiAgICAgICAgcmV0dXJuICh0eXBlb2YgX3ZhbCAhPT0gJ3VuZGVmaW5lZCcgJiYgX3ZhbCAhPT0gbnVsbCAmJiBfdmFsICE9PSAnJyk7XHJcbiAgICB9XHJcblxyXG4gICAgcHVibGljIGdldEQzTWF4T3JNaW4oX2FycjogQXJyYXk8bnVtYmVyPiwgX3R5cGU6ICdtYXgnIHwgJ21pbicpOiBudW1iZXIge1xyXG4gICAgICAgIGlmIChfdHlwZSA9PT0gJ21heCcpIHJldHVybiBkMy5tYXgoX2Fycik7XHJcbiAgICAgICAgaWYgKF90eXBlID09PSAnbWluJykgcmV0dXJuIGQzLm1pbihfYXJyKTtcclxuICAgIH1cclxuXHJcbiAgICBwdWJsaWMgZ2V0QXhpc1RyYW5zZm9ybVBvcyhfYXhpczogJ3gnIHwgJ3knLCBfb3Bwb3NpdGU6IGJvb2xlYW4sIF90cmFuc2Zvcm1Qb3M6IElBeGlzVHJhbnNmb3JtUG9zKTogc3RyaW5nIHtcclxuICAgICAgICBpZiAodGhpcy5faXNJbnZlcnQpIHtcclxuICAgICAgICAgICAgaWYgKF9heGlzID09PSAneCcpIHtcclxuICAgICAgICAgICAgICAgIGlmIChfb3Bwb3NpdGUpIHJldHVybiBfdHJhbnNmb3JtUG9zLnJpZ2h0O1xyXG4gICAgICAgICAgICAgICAgcmV0dXJuIF90cmFuc2Zvcm1Qb3MubGVmdDtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBpZiAoX2F4aXMgPT09ICd5Jykge1xyXG4gICAgICAgICAgICAgICAgaWYgKF9vcHBvc2l0ZSkgcmV0dXJuIF90cmFuc2Zvcm1Qb3MudG9wO1xyXG4gICAgICAgICAgICAgICAgcmV0dXJuIF90cmFuc2Zvcm1Qb3MuYm90dG9tO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgaWYgKF9heGlzID09PSAneCcpIHtcclxuICAgICAgICAgICAgICAgIGlmIChfb3Bwb3NpdGUpIHJldHVybiBfdHJhbnNmb3JtUG9zLnRvcDtcclxuICAgICAgICAgICAgICAgIHJldHVybiBfdHJhbnNmb3JtUG9zLmJvdHRvbTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBpZiAoX2F4aXMgPT09ICd5Jykge1xyXG4gICAgICAgICAgICAgICAgaWYgKF9vcHBvc2l0ZSkgcmV0dXJuIF90cmFuc2Zvcm1Qb3MucmlnaHQ7XHJcbiAgICAgICAgICAgICAgICByZXR1cm4gX3RyYW5zZm9ybVBvcy5sZWZ0O1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIHB1YmxpYyBnZXRMaW1pdGVkQ2F0ZWdvcmllcyhfaW5pdENhdGVnb3JpZXM6IEFycmF5PHN0cmluZz4sIF94VGhyZXNob2xkOiBudW1iZXIpOiBBcnJheTxzdHJpbmc+IHtcclxuICAgICAgICBpZiAoIV9pbml0Q2F0ZWdvcmllcykgcmV0dXJuIFtdO1xyXG4gICAgICAgIHJldHVybiBfeFRocmVzaG9sZCAmJiBfaW5pdENhdGVnb3JpZXMubGVuZ3RoID4gX3hUaHJlc2hvbGQgPyBfaW5pdENhdGVnb3JpZXMuc2xpY2UoMCwgX3hUaHJlc2hvbGQpIDogX2luaXRDYXRlZ29yaWVzO1xyXG4gICAgfVxyXG5cclxuICAgIC8qKlxyXG4gICAgICogcmV0dXJuIGNvbmZpZyBpbnRvIGNzcyBzdHJpbmcgc28gY2FuIGJlIGFkZGVkIGludG8gZWxlbWVudFxyXG4gICAgICogcGFyYW0gIHtvYmplY3R9ICBkZWZhdWx0Q29uZmlnIGNvbmZpZ1xyXG4gICAgICogcGFyYW0gIHtib29sZWFufSBpc0ZvclRvb2x0aXAgIGlmIHRvb2x0aXAsIGNvbXBhcmUgZGVmYXVsdCBjb25maWcgd2l0aCBjb25maWcgcGFzcyBmcm9tIHVzZXJcclxuICAgICAqIHJldHVybiB7c3RyaW5nfSAgICAgICAgICAgICAgICBjc3Mgc3R5bGluZ1xyXG4gICAgICovXHJcbiAgICBwdWJsaWMgZ2V0U3R5bGUoZGVmYXVsdENvbmZpZzogb2JqZWN0LCBpc0ZvclRvb2x0aXA/OiBib29sZWFuKTogc3RyaW5nIHtcclxuICAgICAgICBsZXQgY29uZmlnOiBvYmplY3QgPSB7fTtcclxuICAgICAgICBpZiAoaXNGb3JUb29sdGlwKSB7XHJcbiAgICAgICAgICAgIGNvbmZpZyA9IHRoaXMuX2NvbmZpZy50b29sdGlwLnN0eWxlO1xyXG4gICAgICAgIH1cclxuICAgICAgICBsZXQgc3R5bGluZzogc3RyaW5nID0gJyc7XHJcblxyXG4gICAgICAgIGlmIChkZWZhdWx0Q29uZmlnKSB7XHJcbiAgICAgICAgICAgIGZvciAobGV0IGRlZmF1bHRLZXkgb2YgT2JqZWN0LmtleXMoZGVmYXVsdENvbmZpZykpIHtcclxuICAgICAgICAgICAgICAgIHN0eWxpbmcgKz0gZGVmYXVsdEtleS5yZXBsYWNlKC8oW2EtekEtWl0pKD89W0EtWl0pL2csICckMS0nKS50b0xvd2VyQ2FzZSgpO1xyXG4gICAgICAgICAgICAgICAgc3R5bGluZyArPSAnOic7XHJcbiAgICAgICAgICAgICAgICBzdHlsaW5nICs9IChjb25maWcgJiYgY29uZmlnLmhhc093blByb3BlcnR5KGRlZmF1bHRLZXkpKSA/IGNvbmZpZ1tkZWZhdWx0S2V5XSA6IGRlZmF1bHRDb25maWdbZGVmYXVsdEtleV07XHJcbiAgICAgICAgICAgICAgICBzdHlsaW5nICs9ICc7JztcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgICAgICByZXR1cm4gc3R5bGluZztcclxuICAgIH1cclxuXHJcbiAgICAvLyA9PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT0gTGluZSBvbmx5ID09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT1cclxuXHJcbiAgICAvKipcclxuICAgICAqIGNoZWNrIGlmIGxpbmUgbWlzc2luZ1xyXG4gICAgICogcGFyYW0ge1t0eXBlXX0gX2RhdGEgICAgICAgIGRhdGFcclxuICAgICAqIHBhcmFtIHtbdHlwZV19IF9kYXRhSW5kZXggICB4SW5kZXhcclxuICAgICAqIHBhcmFtIHtbdHlwZV19IF9zZXJpZXNJbmRleCB5SW5kZXggLyB5VmFsdWVJbmRleFxyXG4gICAgICovXHJcbiAgICBwdWJsaWMgaXNTZXJpZXNOdWxsKF9kYXRhOiBJQ2hhcnREYXRhIHwgQXJyYXk8SUQzRGF0YURhdGE+LCBfZGF0YUluZGV4OiBudW1iZXIsIF9zZXJpZXNJbmRleDogbnVtYmVyKToge1xyXG4gICAgICAgIGlzUHJldk51bGw6IGJvb2xlYW4sXHJcbiAgICAgICAgaXNQcmV2Tm90TnVsbDogYm9vbGVhbixcclxuICAgICAgICBpc05leHROdWxsOiBib29sZWFuLFxyXG4gICAgICAgIGlzTmV4dE5vdE51bGw6IGJvb2xlYW4sXHJcbiAgICAgICAgaXNBcHBlYXJpbmc6IGJvb2xlYW4sXHJcbiAgICAgICAgaXNEaXNhcHBlYXJpbmc6IGJvb2xlYW5cclxuICAgIH0ge1xyXG5cclxuICAgICAgICBsZXQgY3VycmVudFZhbDogbnVtYmVyID0gMDtcclxuICAgICAgICBsZXQgZGF0YUxlbmd0aDogbnVtYmVyID0gMDtcclxuICAgICAgICBsZXQgaXNJQ2hhcnREYXRhID0gdGhpcy5faXNDaGFydERhdGE7XHJcblxyXG4gICAgICAgIGlmIChpc0lDaGFydERhdGEoX2RhdGEpKSB7XHJcbiAgICAgICAgICAgIGN1cnJlbnRWYWwgPSBfZGF0YS5zZXJpZXNbX3Nlcmllc0luZGV4XS5kYXRhW19kYXRhSW5kZXhdLnZhbHVlO1xyXG4gICAgICAgICAgICBkYXRhTGVuZ3RoID0gX2RhdGEueEF4aXMuY2F0ZWdvcmllcy5sZW5ndGg7XHJcbiAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgY3VycmVudFZhbCA9IF9kYXRhW19kYXRhSW5kZXhdLnlbX3Nlcmllc0luZGV4XS52YWx1ZTtcclxuICAgICAgICAgICAgZGF0YUxlbmd0aCA9IF9kYXRhLmxlbmd0aDtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIGZ1bmN0aW9uIGdldFZhbHVlKHdoZW46IHN0cmluZywgaXNOdWxsOiBib29sZWFuKTogYm9vbGVhbiB7XHJcbiAgICAgICAgICAgIGxldCBpbmRleDogbnVtYmVyID0gMDtcclxuICAgICAgICAgICAgaWYgKHdoZW4gPT09ICdwcmV2Jykge1xyXG4gICAgICAgICAgICAgICAgaWYgKF9kYXRhSW5kZXggPiAwKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgaW5kZXggPSBfZGF0YUluZGV4IC0gMTtcclxuICAgICAgICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIGZhbHNlO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgaWYgKF9kYXRhSW5kZXggPCBkYXRhTGVuZ3RoIC0gMSkge1xyXG4gICAgICAgICAgICAgICAgICAgIGluZGV4ID0gX2RhdGFJbmRleCArIDE7XHJcbiAgICAgICAgICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBmYWxzZTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgbGV0IHZhbHVlOiBudW1iZXIgPSAoaXNJQ2hhcnREYXRhKF9kYXRhKSA/IF9kYXRhLnNlcmllc1tfc2VyaWVzSW5kZXhdLmRhdGFbaW5kZXhdLnZhbHVlIDogX2RhdGFbaW5kZXhdLnlbX3Nlcmllc0luZGV4XS52YWx1ZSk7XHJcblxyXG4gICAgICAgICAgICBpZiAoaXNOdWxsKSB7XHJcbiAgICAgICAgICAgICAgICByZXR1cm4gdmFsdWUgPT09IG51bGw7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgcmV0dXJuIHZhbHVlICE9PSBudWxsO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgbGV0IGlzUHJldk51bGw6IGJvb2xlYW4gPSBnZXRWYWx1ZSgncHJldicsIHRydWUpO1xyXG4gICAgICAgIGxldCBpc1ByZXZOb3ROdWxsOiBib29sZWFuID0gZ2V0VmFsdWUoJ3ByZXYnLCBmYWxzZSk7XHJcbiAgICAgICAgbGV0IGlzTmV4dE51bGw6IGJvb2xlYW4gPSBnZXRWYWx1ZSgnbmV4dCcsIHRydWUpO1xyXG4gICAgICAgIGxldCBpc05leHROb3ROdWxsOiBib29sZWFuID0gZ2V0VmFsdWUoJ25leHQnLCBmYWxzZSk7XHJcblxyXG4gICAgICAgIGxldCBpc0FwcGVhcmluZzogYm9vbGVhbiA9IGlzTmV4dE5vdE51bGwgJiYgY3VycmVudFZhbCAhPT0gbnVsbCAmJiBpc1ByZXZOdWxsO1xyXG5cclxuICAgICAgICBsZXQgaXNEaXNhcHBlYXJpbmc6IGJvb2xlYW4gPSBpc05leHROdWxsICYmIGN1cnJlbnRWYWwgIT09IG51bGwgJiYgaXNQcmV2Tm90TnVsbDtcclxuXHJcbiAgICAgICAgcmV0dXJuIHtcclxuICAgICAgICAgICAgaXNQcmV2TnVsbDogaXNQcmV2TnVsbCxcclxuICAgICAgICAgICAgaXNQcmV2Tm90TnVsbDogaXNQcmV2Tm90TnVsbCxcclxuICAgICAgICAgICAgaXNOZXh0TnVsbDogaXNOZXh0TnVsbCxcclxuICAgICAgICAgICAgaXNOZXh0Tm90TnVsbDogaXNOZXh0Tm90TnVsbCxcclxuICAgICAgICAgICAgaXNBcHBlYXJpbmc6IGlzQXBwZWFyaW5nLFxyXG4gICAgICAgICAgICBpc0Rpc2FwcGVhcmluZzogaXNEaXNhcHBlYXJpbmdcclxuICAgICAgICB9O1xyXG4gICAgfVxyXG5cclxuICAgIHB1YmxpYyBfaXNDaGFydERhdGEob2JqZWN0OiBhbnkpOiBvYmplY3QgaXMgSUNoYXJ0RGF0YSB7XHJcbiAgICAgICAgcmV0dXJuICdzZXJpZXMnIGluIG9iamVjdDtcclxuICAgIH1cclxuXHJcbiAgICAvLyA9PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT0gS2QgQ2hhcnQgb25seSA9PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09XHJcblxyXG4gICAgLyoqXHJcbiAgICAgKiByZXF1aXJlZCBmb3IgcGVyY2VudGFnZSBjYWxjdWxhdGlvbiBvZiAxMDAgc3RhY2suIHJldHVybnMgYSBhcnJheSBvZiB0b3RhbCBzdW0gb2YgZGF0YSB2YWx1ZSBvZiBlYWNoIGNhdGVnb3JpZXMuXHJcbiAgICAgKiBwYXJhbSAge0FycmF5PElTZXJpZXM+fSBfc2VyaWVzQXJyXHJcbiAgICAgKiBwYXJhbSAge0FycmF5PHN0cmluZz59ICBfY2F0ZWdvcmllc1xyXG4gICAgICogcmV0dXJuIHtBcnJheTxudW1iZXI+fVxyXG4gICAgICovXHJcbiAgICBwdWJsaWMgZ2V0VG90YWxTdW1BcnJGcm9tU2VyaWVzKF9zZXJpZXNBcnI6IEFycmF5PElTZXJpZXM+LCBfY2F0ZWdvcmllczogQXJyYXk8c3RyaW5nPiwgc2VyaWVzTGVuZ3RoOiBudW1iZXIpOiBBcnJheTxudW1iZXI+IHtcclxuICAgICAgICBsZXQgc3VtQXJyOiBBcnJheTxudW1iZXI+ID0gW107XHJcbiAgICAgICAgZm9yIChsZXQgaSA9IDA7IGkgPCBfY2F0ZWdvcmllcy5sZW5ndGg7ICsraSkge1xyXG4gICAgICAgICAgICBsZXQgc3VtOiBudW1iZXIgPSAwO1xyXG4gICAgICAgICAgICBmb3IgKGxldCBqID0gMDsgaiA8IHNlcmllc0xlbmd0aDsgKytqKSB7XHJcbiAgICAgICAgICAgICAgICBpZiAodHlwZW9mIF9zZXJpZXNBcnJbal0uZGF0YVtpXSA9PT0gJ3VuZGVmaW5lZCcpIGNvbnRpbnVlO1xyXG4gICAgICAgICAgICAgICAgbGV0IGN1cnJlbnRWYWw6IG51bWJlciB8IG51bGwgPSBfc2VyaWVzQXJyW2pdLmRhdGFbaV0udmFsdWU7XHJcbiAgICAgICAgICAgICAgICBpZiAodHlwZW9mIGN1cnJlbnRWYWwgPT09ICd1bmRlZmluZWQnKSBjb250aW51ZTtcclxuICAgICAgICAgICAgICAgIHN1bSA9IChjdXJyZW50VmFsID09PSBudWxsKSA/IHN1bSA6IHN1bSArIGN1cnJlbnRWYWw7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgc3VtQXJyLnB1c2goc3VtKTtcclxuICAgICAgICB9XHJcbiAgICAgICAgcmV0dXJuIHN1bUFycjtcclxuICAgIH1cclxuXHJcbiAgICAvLyA9PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT0gUGllIG9ubHkgPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PVxyXG4gICAgLyoqXHJcbiAgICAgKiBjaGVjayBpZiBsaW5lIG1pc3NpbmdcclxuICAgICAqIHBhcmFtIHtba2V5OiBzdHJpbmddOiBJTGVnZW5kRGF0YX0gX2xlZ2VuZERhdGEgcGllIGNoYXJ0IGxlZ2VuZCBkYXRhXHJcbiAgICAgKiBwYXJhbSB7YW55fSBfZGF0YSBwaWUgY2hhcnQgZGF0YVxyXG4gICAgICogcGFyYW0ge0lDaGFydENvbmZpZ30gX2NvbmZpZyBwaWUgY2hhcnQgbGVnZW5kIGNvbmZpZ1xyXG4gICAgICovXHJcbiAgICBwdWJsaWMgc2V0UGllRGF0YShfbGVnZW5kRGF0YTogeyBba2V5OiBzdHJpbmddOiBJTGVnZW5kRGF0YSB9LCBfZGF0YTogYW55LCBfY29uZmlnOiBJQ2hhcnRDb25maWcsIF9zZXJpZXNUaHJlc2hvbGQ6IG51bWJlcik6IHtcclxuICAgICAgICBwaWVEYXRhOiBBcnJheTxhbnk+LFxyXG4gICAgICAgIHBpZUNvbG9yOiBBcnJheTxzdHJpbmc+LFxyXG4gICAgICAgIGxlZ2VuZERhdGE6IHsgW2tleTogc3RyaW5nXTogSUxlZ2VuZERhdGEgfSxcclxuICAgIH0ge1xyXG4gICAgICAgIGxldCBwaWVEYXRhOiBBcnJheTxhbnk+ID0gW107XHJcbiAgICAgICAgbGV0IHBpZUNvbG9yOiBBcnJheTxzdHJpbmc+ID0gW107XHJcbiAgICAgICAgbGV0IGxlZ2VuZElkOiBzdHJpbmc7XHJcbiAgICAgICAgbGV0IHBpZURhdGFBcnJheUxlbmd0aDogbnVtYmVyID0gMDtcclxuICAgICAgICBsZXQgY29uZmlnRGF0YUFycmF5OiBBcnJheTxJTGVnZW5kRGF0YT4gPSBPYmplY3Qua2V5cyhfbGVnZW5kRGF0YSkubWFwKGtleSA9PiBfbGVnZW5kRGF0YVtrZXldKTtcclxuICAgICAgICBfbGVnZW5kRGF0YSA9IHt9O1xyXG4gICAgICAgIGZvciAobGV0IGkgPSAwOyBpIDwgX2RhdGEuZGF0YS5sZW5ndGg7IGkrKykge1xyXG4gICAgICAgICAgICBmb3IgKGxldCBqID0gMDsgaiA8IF9kYXRhLmRhdGFbaV0ueS5sZW5ndGg7IGorKykge1xyXG4gICAgICAgICAgICAgICAgZm9yIChsZXQgayA9IDA7IGsgPCBjb25maWdEYXRhQXJyYXkubGVuZ3RoOyBrKyspIHtcclxuICAgICAgICAgICAgICAgICAgICBpZiAoX2RhdGEuZGF0YVtpXS55W2pdWydpZCddID09PSBjb25maWdEYXRhQXJyYXlba10uaWQpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgaWYgKHR5cGVvZiBfZGF0YS5zZXJpZXNbMF0uZGF0YVtpXS55ICE9PSAndW5kZWZpbmVkJykge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKChfc2VyaWVzVGhyZXNob2xkICE9PSB1bmRlZmluZWQgJiYgX3Nlcmllc1RocmVzaG9sZCAhPT0gbnVsbCAmJiBwaWVEYXRhQXJyYXlMZW5ndGggPCBfc2VyaWVzVGhyZXNob2xkKSB8fCBfc2VyaWVzVGhyZXNob2xkID09PSB1bmRlZmluZWQgfHwgX3Nlcmllc1RocmVzaG9sZCA9PT0gbnVsbCkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxldCBjb2xvclBvaW50ZXIgPSBfZGF0YS5kYXRhW2ldLnlbal1bJ2NvbG9yJ107XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbGV0IGNvbG9yVmFsdWUgPSAoY29sb3JQb2ludGVyICYmIGNvbG9yUG9pbnRlciAhPSBudWxsICYmIGNvbG9yUG9pbnRlciAhPSBudWxsKSA/IGNvbG9yUG9pbnRlciA6IHRoaXMuZ2V0RGVmYXVsdENvbmZpZygnY29sb3InLCBwaWVEYXRhQXJyYXlMZW5ndGgsIF9jb25maWcpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxlZ2VuZElkID0gJ2lkJyArIHBpZURhdGFBcnJheUxlbmd0aDtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBfbGVnZW5kRGF0YVtsZWdlbmRJZF0gPSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICduYW1lJzogX2RhdGEuZGF0YVtpXS54ICsgJyAnICsgY29uZmlnRGF0YUFycmF5W2tdLm5hbWUsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICdpZCc6IGxlZ2VuZElkLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAnc2hhcGUnOiAnY2lyY2xlJyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgJ3gnOiBfZGF0YS5kYXRhW2ldLnggKyAnICcgKyBjb25maWdEYXRhQXJyYXlba10ubmFtZSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgJ3knOiBfZGF0YS5kYXRhW2ldLnlbal1bJ3ZhbHVlJ10sXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICd4QmFzZSc6IF9kYXRhLmRhdGFbaV0ueCxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgJ2luZGV4JzogJ3BpZScgKyBwaWVEYXRhQXJyYXlMZW5ndGgsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICdjb2xvcic6IGNvbG9yVmFsdWUsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICdzZXJpZXNJbmRleCc6IGosXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICdkYXRhSW5kZXgnOiBpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBwaWVDb2xvci5wdXNoKGNvbG9yVmFsdWUpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHBpZURhdGEucHVzaCh7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICdpZCc6IGxlZ2VuZElkLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAneCc6IF9kYXRhLmRhdGFbaV0ueCArICcgJyArIGNvbmZpZ0RhdGFBcnJheVtrXS5uYW1lLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAneSc6IF9kYXRhLmRhdGFbaV0ueVtqXVsndmFsdWUnXSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgJ3hCYXNlJzogX2RhdGEuZGF0YVtpXS54LFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAnaW5kZXgnOiAncGllJyArIHBpZURhdGFBcnJheUxlbmd0aCxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgJ2NvbG9yJzogY29sb3JWYWx1ZSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgJ3Nlcmllc0luZGV4JzogaixcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgJ2RhdGFJbmRleCc6IGlcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBwaWVEYXRhQXJyYXlMZW5ndGgrKztcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBicmVhaztcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgICAgICBsZXQgcmV0dXJuUGFyYW1zID0ge1xyXG4gICAgICAgICAgICAncGllRGF0YSc6IHBpZURhdGEsXHJcbiAgICAgICAgICAgICdwaWVDb2xvcic6IHBpZUNvbG9yLFxyXG4gICAgICAgICAgICAnbGVnZW5kRGF0YSc6IF9sZWdlbmREYXRhXHJcbiAgICAgICAgfTtcclxuICAgICAgICByZXR1cm4gcmV0dXJuUGFyYW1zO1xyXG4gICAgfVxyXG5cclxuICAgIHB1YmxpYyBzaW5nbGVQaWVEYXRhTWFzc2FnZShfbGVnZW5kRGF0YTogeyBba2V5OiBzdHJpbmddOiBJTGVnZW5kRGF0YSB9LCBfZGF0YTogYW55LCBfY29uZmlnOiBJQ2hhcnRDb25maWcsIF9zZXJpZXNUaHJlc2hvbGQ6IG51bWJlcikge1xyXG4gICAgICAgIGxldCBwaWVEYXRhOiBBcnJheTxhbnk+ID0gW107XHJcbiAgICAgICAgbGV0IHBpZUNvbG9yOiBBcnJheTxzdHJpbmc+ID0gW107XHJcbiAgICAgICAgbGV0IGxlZ2VuZElkOiBzdHJpbmc7XHJcbiAgICAgICAgbGV0IHBpZURhdGFBcnJheUxlbmd0aDogbnVtYmVyID0gMDtcclxuICAgICAgICBfbGVnZW5kRGF0YSA9IHt9O1xyXG4gICAgICAgIGlmIChfZGF0YS5zZXJpZXMgJiYgX2RhdGEuc2VyaWVzWzBdICYmIF9kYXRhLnNlcmllc1swXS5kYXRhKSB7XHJcbiAgICAgICAgICAgIGZvciAobGV0IGkgPSAwOyBpIDwgX2RhdGEuc2VyaWVzWzBdLmRhdGEubGVuZ3RoOyBpKyspIHtcclxuICAgICAgICAgICAgICAgIGlmICh0eXBlb2YgX2RhdGEuc2VyaWVzWzBdLmRhdGFbaV0ueSAhPT0gJ3VuZGVmaW5lZCcpIHtcclxuICAgICAgICAgICAgICAgICAgICBpZiAoKF9zZXJpZXNUaHJlc2hvbGQgIT0gdW5kZWZpbmVkICYmIF9zZXJpZXNUaHJlc2hvbGQgIT0gbnVsbCAmJiBwaWVEYXRhQXJyYXlMZW5ndGggPCBfc2VyaWVzVGhyZXNob2xkKSB8fCBfc2VyaWVzVGhyZXNob2xkID09IHVuZGVmaW5lZCB8fCBfc2VyaWVzVGhyZXNob2xkID09IG51bGwpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgbGV0IGNvbG9yUG9pbnRlciA9IF9kYXRhLnNlcmllc1swXS5kYXRhW2ldWydjb2xvciddO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBsZXQgY29sb3JWYWx1ZSA9IChjb2xvclBvaW50ZXIgJiYgY29sb3JQb2ludGVyICE9IG51bGwgJiYgY29sb3JQb2ludGVyICE9IG51bGwpID8gY29sb3JQb2ludGVyIDogdGhpcy5nZXREZWZhdWx0Q29uZmlnKCdjb2xvcicsIHBpZURhdGFBcnJheUxlbmd0aCwgX2NvbmZpZyk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGxlZ2VuZElkID0gJ2lkJyArIHBpZURhdGFBcnJheUxlbmd0aDtcclxuICAgICAgICAgICAgICAgICAgICAgICAgX2xlZ2VuZERhdGFbbGVnZW5kSWRdID0ge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgJ25hbWUnOiBfZGF0YS5zZXJpZXNbMF0uZGF0YVtpXS5uYW1lLnJlcGxhY2UoL8KsL2csICcgJyksXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAnaWQnOiBsZWdlbmRJZCxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICdzaGFwZSc6ICdjaXJjbGUnLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgJ3gnOiBfZGF0YS5zZXJpZXNbMF0uZGF0YVtpXS5uYW1lLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgJ3knOiBfZGF0YS5zZXJpZXNbMF0uZGF0YVtpXS55LFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgJ3hCYXNlJzogX2RhdGEuc2VyaWVzWzBdLmRhdGFbaV0ubmFtZSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICdpbmRleCc6ICdwaWUnICsgcGllRGF0YUFycmF5TGVuZ3RoLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgJ2NvbG9yJzogY29sb3JWYWx1ZSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgfTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgcGllQ29sb3IucHVzaChjb2xvclZhbHVlKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgaWYgKF9kYXRhLnNlcmllc1swXS5kYXRhW2ldLnkgJiYgX2RhdGEuc2VyaWVzWzBdLmRhdGFbaV0ueSA+IDApIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHBpZURhdGEucHVzaCh7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgJ2lkJzogbGVnZW5kSWQsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgJ3gnOiBfZGF0YS5zZXJpZXNbMF0uZGF0YVtpXS5uYW1lLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICd5JzogX2RhdGEuc2VyaWVzWzBdLmRhdGFbaV0ueSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAneEJhc2UnOiBfZGF0YS5zZXJpZXNbMF0uZGF0YVtpXS5uYW1lLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICdpbmRleCc6ICdwaWUnICsgcGllRGF0YUFycmF5TGVuZ3RoLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICdjb2xvcic6IGNvbG9yVmFsdWUsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgcGllRGF0YUFycmF5TGVuZ3RoKys7XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGxldCByZXR1cm5QYXJhbXMgPSB7XHJcbiAgICAgICAgICAgICdwaWVEYXRhJzogcGllRGF0YSxcclxuICAgICAgICAgICAgJ3BpZUNvbG9yJzogcGllQ29sb3IsXHJcbiAgICAgICAgICAgICdsZWdlbmREYXRhJzogX2xlZ2VuZERhdGFcclxuICAgICAgICB9O1xyXG4gICAgICAgIHJldHVybiByZXR1cm5QYXJhbXM7XHJcbiAgICB9XHJcblxyXG4gICAgcHVibGljIHNldE1hcExlZ2VuZERhdGEoX2xlZ2VuZERhdGE6IHsgW2tleTogc3RyaW5nXTogSUxlZ2VuZERhdGEgfSwgX2RhdGE6IGFueSwgX2NvbmZpZzogSUNoYXJ0Q29uZmlnKSB7XHJcbiAgICAgICAgbGV0IGxlZ2VuZElkOiBzdHJpbmc7XHJcbiAgICAgICAgX2xlZ2VuZERhdGEgPSB7fTtcclxuICAgICAgICBmb3IgKGxldCBpID0gMDsgaSA8IF9kYXRhLmxlbmd0aDsgaSsrKSB7XHJcbiAgICAgICAgICAgIGlmIChfZGF0YVtpXS5uYW1lICE9IHVuZGVmaW5lZCkge1xyXG4gICAgICAgICAgICAgICAgbGV0IGNvbG9yUG9pbnRlciA9IF9kYXRhW2ldLmNvbG9yO1xyXG4gICAgICAgICAgICAgICAgbGVnZW5kSWQgPSAnaWQnICsgaTtcclxuICAgICAgICAgICAgICAgIF9sZWdlbmREYXRhW2xlZ2VuZElkXSA9IHtcclxuICAgICAgICAgICAgICAgICAgICAnbmFtZSc6IF9kYXRhW2ldLm5hbWUsXHJcbiAgICAgICAgICAgICAgICAgICAgJ2lkJzogbGVnZW5kSWQsXHJcbiAgICAgICAgICAgICAgICAgICAgJ3NoYXBlJzogJ2NpcmNsZScsXHJcbiAgICAgICAgICAgICAgICAgICAgJ3gnOiBfZGF0YVtpXS5uYW1lLFxyXG4gICAgICAgICAgICAgICAgICAgICd5JzogX2RhdGFbaV0uZGF0YVswXS52YWx1ZSxcclxuICAgICAgICAgICAgICAgICAgICAneEJhc2UnOiBfZGF0YVtpXS5uYW1lLFxyXG4gICAgICAgICAgICAgICAgICAgICdjb2xvcic6IChjb2xvclBvaW50ZXIgJiYgY29sb3JQb2ludGVyICE9IG51bGwgJiYgY29sb3JQb2ludGVyICE9IHVuZGVmaW5lZCkgPyBjb2xvclBvaW50ZXIgOiB0aGlzLmdldERlZmF1bHRDb25maWcoJ2NvbG9yJywgaSwgX2NvbmZpZyksXHJcbiAgICAgICAgICAgICAgICAgICAgJ21hcFNlcmllc0lkJzogX2RhdGFbaV0uaWQsXHJcbiAgICAgICAgICAgICAgICAgICAgJ2RlYWN0aXZlJzogX2RhdGFbaV0uZGVhY3RpdmVcclxuICAgICAgICAgICAgICAgIH07XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICAgICAgcmV0dXJuIF9sZWdlbmREYXRhO1xyXG4gICAgfVxyXG5cclxuICAgIHB1YmxpYyBnZXREZWZhdWx0Q29uZmlnKF9lbGVtZW50OiBhbnksIF9zZXJpZXNJbmRleDogbnVtYmVyLCBfY29uZmlnOiBJQ2hhcnRDb25maWcpOiBzdHJpbmcge1xyXG4gICAgICAgIGlmIChfZWxlbWVudCA9PT0gJ3NoYXBlJykgcmV0dXJuICdjaXJjbGUnO1xyXG5cclxuICAgICAgICBpZiAoX3Nlcmllc0luZGV4IHx8IF9zZXJpZXNJbmRleCA9PT0gMCkge1xyXG4gICAgICAgICAgICByZXR1cm4gX2NvbmZpZy5jb2xvcnNbX3Nlcmllc0luZGV4ICUgX2NvbmZpZy5jb2xvcnMubGVuZ3RoXTtcclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgcHVibGljIHNldFNpbmdsZUxlZ2VuZExldmVscyhfZGF0YUNsYXNzZXM6IEFycmF5PGFueT4sIF9kZWNpbWFsUHJlY2lzb246IG51bWJlciwgX3ZhbHVlU3VmZml4OiBzdHJpbmcsIF9vcmlnaW5hbExlZ2VuZD86IHsgW2tleTogc3RyaW5nXTogSUxlZ2VuZERhdGEgfSk6IHsgW2tleTogc3RyaW5nXTogSUxlZ2VuZERhdGEgfSB7XHJcbiAgICAgICAgbGV0IF9sZWdlbmREYXRhOiB7IFtrZXk6IHN0cmluZ106IElMZWdlbmREYXRhIH0gPSB7fTtcclxuICAgICAgICBmb3IgKGxldCBpID0gMDsgaSA8IF9kYXRhQ2xhc3Nlcy5sZW5ndGg7IGkrKykge1xyXG4gICAgICAgICAgICBsZXQgbGVnZW5kSWQ6IHN0cmluZyA9ICdpZCcgKyBpO1xyXG4gICAgICAgICAgICBfbGVnZW5kRGF0YVtsZWdlbmRJZF0gPSB7XHJcbiAgICAgICAgICAgICAgICAnbmFtZSc6IF9kYXRhQ2xhc3Nlc1tpXS5mcm9tLnRvRml4ZWQoX2RlY2ltYWxQcmVjaXNvbikgKyBfdmFsdWVTdWZmaXggKyAnIC0gJyArIF9kYXRhQ2xhc3Nlc1tpXS50by50b0ZpeGVkKF9kZWNpbWFsUHJlY2lzb24pICsgX3ZhbHVlU3VmZml4LFxyXG4gICAgICAgICAgICAgICAgJ2lkJzogbGVnZW5kSWQsXHJcbiAgICAgICAgICAgICAgICAnc2hhcGUnOiAnY2lyY2xlJyxcclxuICAgICAgICAgICAgICAgICdjb2xvcic6IF9kYXRhQ2xhc3Nlc1tpXS5jb2xvcixcclxuICAgICAgICAgICAgICAgICdkZWFjdGl2ZSc6IF9vcmlnaW5hbExlZ2VuZCAmJiBfb3JpZ2luYWxMZWdlbmRbbGVnZW5kSWRdID8gX29yaWdpbmFsTGVnZW5kW2xlZ2VuZElkXS5kZWFjdGl2ZSA6IGZhbHNlXHJcbiAgICAgICAgICAgIH07XHJcblxyXG4gICAgICAgIH1cclxuICAgICAgICByZXR1cm4gX2xlZ2VuZERhdGE7XHJcbiAgICB9XHJcbn1cclxuIl19