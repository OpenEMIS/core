import * as d3 from 'd3';
import { LABEL_TEXT_VERTICAL_ALIGN_STORE, TOOLTIP_DEFAULT_STYLE } from './kd-angular-charts-config';
export class KdChartBaseClass {
    constructor(_chartSvc, _domSvc) {
        this._chartSvc = _chartSvc;
        this._domSvc = _domSvc;
        // Chart Setting
        this.isRtl = false;
        this.config = {};
        this.data = [];
        this.initData = [];
        this.xAxisArr = [];
        this.axisMin = 0;
        this.axisLabelContainerArr = [];
        this.haveNegative = false;
        /**
         * used only by bar.
         * barGroupPadding is used only for cluster --> the padding between each rect in a category
         * bandPadding is given to d3 --> the padding between each category
         * type {IBaseClassBarObj}
         */
        this.bar = {
            isInvert: false,
            clusterPaddingPercent: 0.1,
            bandPadding: 0.2,
        };
        this.lengthOfTransition = 1000;
        this.errorMsg = '100% stack does not support negative values.';
        this.isRtl = _domSvc.getDocumentDirection(true) === 'right';
    }
    // ================================= Chart ==================================
    setSvg() {
        this.svg = d3.select('#' + this.config.id + '.kdx-charts svg');
        if (!this.graph)
            this.graph = this.svg.append('g').attr('class', 'graph');
        // if (this.svg.select('.graph').empty()) this.graph = this.svg.append('g').attr('class', 'graph');
        this.svgParent = d3.select('#' + this.config.id + '.kdx-charts .kdx-chart-container');
        this.svgContainer = d3.select('#' + this.config.id + '.kdx-charts .kdx-charts-svg-container');
        this._setLabelContainer();
        this._setChartSvc();
        this.rangeList = {};
    }
    /**
     * set svg width and height. this function is becos of export feature, the export plugins requires svg width and height to be inline attributes with definite number
     * have to be called by all charts
     * param {'x' | 'y'} _axis
     */
    setSvgDimension(_axis) {
        let svgContainerRect = this.svgContainer.node().getBoundingClientRect();
        let type = _axis === 'x' ? (this.bar.isInvert ? 'height' : 'width') : (this.bar.isInvert ? 'width' : 'height');
        this.svg.attr(type, svgContainerRect[type]);
    }
    _clearSvgDimension() {
        if (!this.svg)
            return;
        this.svg
            .attr('width', 0)
            .attr('height', 0);
    }
    /**
     * set this.width and this.height for axis scales. only called by charts with axis
     * param {'x' |'y'}         _axis
     * param {boolean} _skipCal : skip getSvgOffset calculations
     */
    _setGraphDimension(_axis) {
        this.svgRect = this.svg.node().getBoundingClientRect();
        this._chartSvc.svgRect = this.svgRect;
        let type = _axis === 'x' ? (this.bar.isInvert ? 'height' : 'width') : (this.bar.isInvert ? 'width' : 'height');
        let value = this._chartSvc.getSvgOffset(_axis, { axisMax: this.axisMax, axisMin: this.axisMin });
        this[type] = value < 0 ? 0 : value;
    }
    /**
     * set Chart Service variables
     */
    _setChartSvc() {
        this._chartSvc.config = this.config;
        this._chartSvc.chartType = this.chartType;
        this._chartSvc.chartCategory = this.chartCategory;
        this._chartSvc.svgParentRect = this.svgParent.node().getBoundingClientRect();
        this._chartSvc.svg = this.svg;
        this._chartSvc.isRtl = this.isRtl;
        this._chartSvc.isXReversed = this.config.xAxis.reversed;
        this._chartSvc.isYReversed = this.config.yAxis.reversed;
    }
    _setLinearScale() {
        let rangeRoundVal = this._getRangeVal('y');
        this.y = d3.scaleLinear().rangeRound(rangeRoundVal);
    }
    _setBandScale() {
        let rangeVal = this._getRangeVal('x');
        this.x = d3.scaleBand().range(rangeVal);
        if (this.chartCategory === 'bar') {
            this.x.paddingInner(this.bar.bandPadding).paddingOuter(this.bar.bandPadding / 2);
        }
    }
    _getRangeVal(_axis) {
        let rangeVal;
        let reversed = _axis === 'x' ? 'isXReversed' : 'isYReversed';
        if (this.bar.isInvert) {
            rangeVal = _axis === 'x' ? [0, this.height] : [0, this.width];
        }
        else {
            rangeVal = _axis === 'x' ? [0, this.width] : [this.height, 0];
        }
        return this._chartSvc[reversed] ? rangeVal.reverse() : rangeVal;
    }
    _setRange(isBand) {
        let chartWidth = this.width;
        if (!isBand && this.data.length <= 0) {
            this.rangeList[0] = chartWidth;
            return [0, chartWidth];
        }
        let xPosition = 0;
        let rangeArray = [];
        let bandWidth = chartWidth / this.data.length;
        for (let i = 0; i < this.data.length; i++) {
            if (isBand) {
                xPosition = this._getCenterBandPosition(bandWidth, i);
            }
            else {
                xPosition = chartWidth / (this.data.length - 1) * i;
            }
            if (this._chartSvc.isXReversed)
                xPosition = chartWidth - xPosition;
            rangeArray.push(xPosition);
            this.rangeList[this.data[i].x.value] = xPosition;
        }
        return rangeArray;
    }
    _getCenterBandPosition(_bandWidth, _position) {
        return (_bandWidth / 2) + (_bandWidth * _position);
    }
    _setScaleByDirection(_axis, _xScaleType) {
        if (_axis === 'x') {
            if (_xScaleType !== 'string')
                this._setBandScale();
            if (this.chartCategory === 'line')
                this._setLineScaleX(_xScaleType);
        }
        else {
            this._setLinearScale();
        }
    }
    /**
     * (for line only)
     * happens at first load and on change and may happen if data is sliced during trimX()
     */
    _setLineScaleX(_xScaleType) {
        if (_xScaleType === 'string') {
            this.x = d3.scaleOrdinal().range(this._setRange(false));
        }
        else {
            this._setRange(true);
        }
    }
    // ================================= Domain ==================================
    setDomain(_xScaleType) {
        this._chartSvc.xScaleType = _xScaleType;
        this.svg.attr('visibility', 'hidden');
        // setting the class name of chart-wrapper (for flex-reverse)
        this._chartSvc.setVertAxisAndChartMargin(this.config.id);
        // everytime the graph resets, if trimming have occured before (ie: this.data and initData length differs), reset this.data so that the trimming calculation uses full dataset
        if (this.initData && this.data.length !== this.initData.length) {
            this.data = JSON.parse(JSON.stringify(this.initData));
            // this._chartSvc.setAxisLabelDummyText(this.categories, this.config.xAxis.labels.format);
        }
        // set this.width,height, scale, domain and tickValues
        this._setDomain(_xScaleType);
        this.svg.attr('visibility', 'visible');
        // set major and minor grid lines
        this._setGridLines();
        // set y and x axis lines
        this.setAxis();
        // transform graph according to width of vertical axis
        this._chartSvc.transformGraphContainer(this.graph);
        // reposition Data Label according to width of vertical axis
        if (this.config.chart.labels.enabled) {
            this.dataLabelContainer.style('width', this.width + 'px');
            this._chartSvc.repositionDataLabel(this.dataLabelContainer, this.axisLabelContainerArr[0]);
        }
        // reposition vertical axis
        this._chartSvc.repositionVerticalAxisTitle();
        // set clip path to this.width and this.height to make sure graph will not be drawn out of graphing region
        this._setClipPath();
    }
    _setDomain(_xScaleType) {
        // finding the max/min value and axisMax/axisMin
        let axisLabelConfig = this.config.yAxis;
        let result = this._chartSvc.setMaxAndMin(axisLabelConfig, this.dataRange);
        this._chartSvc.setAxisD3Format(result.interval);
        this._setAxisMaxAndMin(result.maxValue, result.minValue, result.interval);
        let xInfo = this._chartSvc.getXInfo(this.data, this.config);
        this._setWidthHeightScale('x', _xScaleType);
        this.x.domain(xInfo.value);
        this._setXAxisLabel(_xScaleType, xInfo.longestText);
        this._setWidthHeightScale('y', _xScaleType);
        let tickValueReturn = this._findIntervalForNoOverlap(result);
        if (tickValueReturn && tickValueReturn.needRedraw) {
            this._setWidthHeightScale('x', _xScaleType);
            this.x.domain(xInfo.value);
            this._setXAxisLabel(_xScaleType, xInfo.longestText);
            this._setWidthHeightScale('y', _xScaleType);
        }
        // only generate range arr when interval is stablized
        this.tickValues = this._chartSvc.getTickValues(this.axisMin, this.axisMax, tickValueReturn.interval);
        // set Y domain
        this.domainMax = axisLabelConfig.autoRoundToMax ? this.axisMax : result.maxValue;
        this.domainMin = axisLabelConfig.autoRoundToMin ? this.axisMin : result.minValue;
        this.y.domain([this.domainMin, this.domainMax]);
    }
    _setWidthHeightScale(_axis, _xScaleType) {
        this.setSvgDimension(_axis);
        this._setGraphDimension(_axis);
        this._setScaleByDirection(_axis, _xScaleType);
    }
    /**
     * set clip path to this.width and this.height to make sure graph will not be drawn out of graphing region
     */
    _setClipPath() {
        let clipPathRect = this.svg.selectAll('defs #kd-charts-clip-path-' + this.config.id + ' rect');
        if (clipPathRect.empty()) {
            clipPathRect = this.svg.insert('defs').append('clipPath').attr('id', 'kd-charts-clip-path-' + this.config.id).append('rect');
            clipPathRect
                .attr('x', 0)
                .attr('y', 0)
                .attr('fill', 'none');
        }
        clipPathRect
            .attr('width', this.width)
            .attr('height', this.height);
    }
    _setAxisMaxAndMin(_maxValue, _minValue, _interval) {
        let yAxisConfig = this.config.yAxis;
        this.axisMax = this._chartSvc.setAxisRoundValue(_maxValue, _interval, yAxisConfig.autoRoundToMax, 'up');
        this.axisMin = this._chartSvc.setAxisRoundValue(_minValue, _interval, yAxisConfig.autoRoundToMin, 'down');
    }
    /**
   * will return an object with following properties
   * needRedraw: to determine whether to redraw the axis (and reset the domain)
   * interval: pass out the lastest interval (that have no overlap) for performance reasons, so that the while loop will only run once on needRedraw
   */
    _findIntervalForNoOverlap(_initInfo) {
        let length = this.bar.isInvert ? this.width : this.height;
        if (length <= 0)
            return { needRedraw: false, interval: 0 };
        let tickLength;
        let initYAxisLabelWidth = Object.assign({}, this._chartSvc.yAxisLabelWidth);
        if (this.bar.isInvert) {
            // axisMax and axisMin is already appended as dummy to svg when calculating for this.width and this.height
            // we can direct access to the actual width instead of doing approximation calculation based on font-size (error as high as 1/2 of actual width)
            tickLength = Math.max(initYAxisLabelWidth.axisMax, initYAxisLabelWidth.axisMin);
        }
        else {
            tickLength = this._chartSvc.replaceStringWithNumber(this.config.yAxis.labels.style.fontSize);
        }
        let initInterval = _initInfo.interval;
        let interval = initInterval;
        let noOfTicks = Math.round((this.axisMax + interval - this.axisMin) / interval);
        if (length < tickLength || noOfTicks === 0)
            return { needRedraw: false, interval: 0 };
        let initLongerNum = this._chartSvc.getLongerNumber(this.axisMax, this.axisMin).toString().length;
        while ((length / noOfTicks) < tickLength && noOfTicks > 2) {
            interval = interval * 2;
            this._setAxisMaxAndMin(_initInfo.maxValue, _initInfo.minValue, interval);
            // when the interval changes, axisMax or axisMin does not change significantly (changes at most 1 digits place)
            // check that the current axisMax/Min is indeed longer than the initial axisMax/Min
            if (this.bar.isInvert && this._chartSvc.getLongerNumber(this.axisMax, this.axisMin).toString().length > initLongerNum) {
                tickLength = this._chartSvc.setDummyAxisLabel(this._chartSvc.getLongerNumber(this.axisMax, this.axisMin), 'axisMax');
            }
            noOfTicks = Math.round((this.axisMax + interval - this.axisMin) / interval);
        }
        // when overlap finishes, interval and axisMax/Min is changed compared to when getSvgOffset()
        // check that current interval results in same max label length, if not, redraw the axis and run getSvgOffset() again
        if (initInterval !== interval) {
            this._chartSvc.setAxisD3Format(interval);
            let newYAxisLabelWidth = this._chartSvc.getYAxisMaxAndMinLabelWidth({ axisMin: this.axisMin, axisMax: this.axisMax });
            if (newYAxisLabelWidth.axisMax !== initYAxisLabelWidth.axisMax || newYAxisLabelWidth.axisMin !== initYAxisLabelWidth.axisMin) {
                return { needRedraw: true, interval: interval };
            }
        }
        return { needRedraw: false, interval: interval };
    }
    // ================================= Grid Lines ==================================
    _setGridLines() {
        if (!this.gridLinesContainer)
            this.gridLinesContainer = this.graph.append('g').attr('class', 'kdx-charts-grid-line-container');
        this._chartSvc.gridSvc.graphDimension = { width: this.width, height: this.height };
        if (this._chartSvc.gridSvc.haveGrid(this.config, 'xAxis', 'gridLine'))
            this._setXAxisGrid();
        if (this._chartSvc.gridSvc.haveGrid(this.config, 'yAxis', 'minorGridLine'))
            this._setYAxisMinorGrid();
        if (this._chartSvc.gridSvc.haveGrid(this.config, 'yAxis', 'gridLine'))
            this._setYAxisGrid();
    }
    _setXAxisGrid() {
        // wrapper function around this.x so that grid will be drawn in center of paddingInner
        let scale = this._chartSvc.gridSvc.xAxisGridScale(this.x);
        // concat space to draw first grid line, Note: this.data may have been spliced by trimX
        let xData = [''].concat(this.data.map(data => data.x.value));
        // let xData: Array<string> = [''].concat(_categories);
        this._chartSvc.gridSvc.drawGridLine(this.gridLinesContainer, xData, 'xAxis', 'gridLine', scale);
    }
    // draw major grid line
    _setYAxisGrid() {
        this._chartSvc.gridSvc.drawGridLine(this.gridLinesContainer, this.tickValues, 'yAxis', 'gridLine', this.y);
    }
    _setYAxisMinorGrid() {
        let yAxisConfig = this.config.yAxis;
        if (yAxisConfig.minorTickInterval >= yAxisConfig.tickInterval || !yAxisConfig.minorTickInterval)
            return;
        let upperbound = this._chartSvc.setAxisRoundValue(this.domainMax, yAxisConfig.minorTickInterval, false, 'up');
        let lowerbound = this._chartSvc.setAxisRoundValue(this.domainMin, yAxisConfig.minorTickInterval, false, 'down');
        let minorTickValues = this._chartSvc.getTickValues(lowerbound, upperbound, yAxisConfig.minorTickInterval);
        this._chartSvc.gridSvc.drawGridLine(this.gridLinesContainer, minorTickValues, 'yAxis', 'minorGridLine', this.y);
    }
    // ================================= Axis ==================================
    setAxis() {
        let transformPos = {
            right: 'translate(' + this.width + ',0)',
            left: 'translate(0,0)',
            top: 'translate(0,0)',
            bottom: 'translate(0,' + this.height + ')'
        };
        let xAxisConfig = this.config.xAxis;
        let yAxisConfig = this.config.yAxis;
        let invert = this.bar.isInvert;
        let opposite = {
            x: invert ? xAxisConfig.opposite !== this.isRtl : xAxisConfig.opposite,
            y: invert ? yAxisConfig.opposite : yAxisConfig.opposite !== this.isRtl
        };
        let xAxis = this._getEachAxisFunc('x', opposite.x, invert);
        this.xAxisArr.push(xAxis);
        this.yAxis = this._getEachAxisFunc('y', opposite.y, invert);
        xAxis.attr('transform', this._chartSvc.getAxisTransformPos('x', opposite.x, transformPos));
        this.yAxis.attr('transform', this._chartSvc.getAxisTransformPos('y', opposite.y, transformPos));
        this._chartSvc.setAxisLabelConfig(xAxis, 'x');
        this._chartSvc.setAxisLabelConfig(this.yAxis, 'y');
        if (this._chartSvc.isNegativeStack) {
            let secondXAxis = this._getEachAxisFunc('x', !opposite.x, this.bar.isInvert);
            secondXAxis.attr('transform', this._chartSvc.getAxisTransformPos('x', !opposite.x, transformPos));
            this._chartSvc.setAxisLabelConfig(secondXAxis, 'x');
            this.xAxisArr.push(secondXAxis);
        }
    }
    _getEachAxisFunc(_axis, _opposite, _invert) {
        let axisFunc = getAxisFunc(_axis, this[_axis]);
        let axisClass = 'kdx-charts-axis axis-' + _axis;
        if ((_invert && _axis === 'x') || (!_invert && _axis === 'y')) {
            axisClass += ' kdx-charts-axis-vertical';
        }
        if (_opposite)
            axisClass += ' kdx-charts-axis-opposite';
        if (_axis === 'y') {
            axisFunc
                .tickValues(this.tickValues)
                .tickFormat((d) => {
                // note: only usecase is negative stack bar (in v3.7.0). will affect both yAxis label and tooltip and dataLabels
                let value = this._chartSvc.checkAndReturnLabelsPositive(d);
                return this._chartSvc.getYAxisLabelText(this.config.yAxis, value);
            });
        }
        let axisElem = this.graph.append('g').attr('class', axisClass).call(axisFunc);
        return axisElem;
        function getAxisFunc(_type, _scale) {
            if (_invert) {
                if (_type === 'x') {
                    if (_opposite)
                        return d3.axisRight(_scale);
                    return d3.axisLeft(_scale);
                }
                if (_type === 'y') {
                    if (_opposite)
                        return d3.axisTop(_scale);
                    return d3.axisBottom(_scale);
                }
            }
            else {
                if (_type === 'x') {
                    if (_opposite)
                        return d3.axisTop(_scale);
                    return d3.axisBottom(_scale);
                }
                if (_type === 'y') {
                    if (_opposite)
                        return d3.axisRight(_scale);
                    return d3.axisLeft(_scale);
                }
            }
        }
    }
    // ================================= Remove Chart ==================================
    chartTimeout(_callback) {
        // let delay = this.config.legend.enabled && this.chartCategory === 'pie'? 500 : 10;
        clearTimeout(this._setChartTimeout);
        this._setChartTimeout = setTimeout(() => {
            _callback();
        });
    }
    removeChart() {
        clearTimeout(this._setChartTimeout);
        this._removeElemInArrayForm('xAxisArr', (axis) => axis.remove());
        if (this.yAxis)
            this.yAxis.remove();
        if (this.dataLabelContainer)
            this.dataLabelContainer.selectAll('*').remove();
        this._removeElemInArrayForm('axisLabelContainerArr', (container) => container.selectAll('*').remove());
        if (this.gridLinesContainer)
            this.gridLinesContainer.selectAll('*').remove();
        this._clearSvgDimension();
    }
    _removeElemInArrayForm(_key, callback) {
        if (this[_key].length !== 0) {
            this[_key].forEach(element => callback(element));
            this[_key] = [];
        }
    }
    // ================================= Axis Label ==================================
    _setXAxisLabel(_xScaleType, _longestText) {
        if (!this.config.xAxis.enabled || !this.config.xAxis.labels.enabled)
            return;
        if (this.axisLabelContainerArr.length !== 0) {
            this._removeElemInArrayForm('axisLabelContainerArr', (container) => container.selectAll('*').remove());
        }
        let xSpacing = this._calculateXSpacing(_xScaleType);
        this._chartSvc.setAxisLabelDummy(this.config.id, xSpacing, _longestText);
        this._chartSvc._setAxisLabelLength();
        this._setAxisLabelContainer();
        if (this._chartSvc.labelLength !== 0)
            this._trimX(_xScaleType);
        this.axisLabelContainerArr.forEach((_axisLabelContainer, index) => {
            this._chartSvc.setAxisLabelContainerStyle(_axisLabelContainer);
            // if drawing 2nd axis, set to complement of opposite of 1st axis
            if (this._chartSvc.labelLength !== 0) {
                let opposite = index === 1 ? !this.config.xAxis.opposite : this.config.xAxis.opposite;
                this._drawAxisLabel(_axisLabelContainer, { labelHeight: this._chartSvc.labelLength, labelWidth: xSpacing }, { isRotate: this._chartSvc.isRotate, opposite: opposite });
            }
        });
    }
    _setAxisLabelContainer() {
        this.axisLabelContainerArr.push(this._chartSvc.setAxisLabelContainer());
        // render 2nd axis
        if (this._chartSvc.isNegativeStack) {
            this.axisLabelContainerArr.push(this._chartSvc.setAxisLabelContainer('.kdx-charts-double-axis-x'));
        }
    }
    _calculateXSpacing(_xScaleType) {
        return (_xScaleType === 'band') ? this.x.bandwidth() + this.x.paddingInner() * this.x.step() : this.width / (this.data.length - 1);
    }
    _trimX(_xScaleType) {
        let maxNoOfX = this._calculateMaxNoOfX(this._chartSvc.isRotate, _xScaleType);
        if (maxNoOfX === this.initData.length)
            return;
        // if the inital data cannot fit into maxSpace, slice and save to this.data
        this.data = this.initData.slice(0, maxNoOfX);
        let xInfo = this._chartSvc.getXInfo(this.data, this.config);
        // update domain with the updated this.data
        if (this.chartCategory === 'line')
            this._setLineScaleX(_xScaleType);
        this.x.domain(xInfo.value);
        // after trimming, the longest axis label may not be same. hence recalculate the axis label container height
        this._chartSvc.setAxisLabelDummyText(xInfo.longestText);
        this._chartSvc._setAxisLabelLength();
    }
    // this.data will be changed/trimed according to space given
    _calculateMaxNoOfX(_isRotate, _xScaleType) {
        if (!_isRotate && !this.bar.isInvert)
            return this.initData.length;
        let offset = this.chartCategory === 'bar' ? (this.x.paddingOuter()) * 2 : 0;
        let maxSpace = (this.bar.isInvert ? this.height : this.width) - offset;
        // note: when rotating or when chartType == 'bar', axisLAbelDummy will not text-wrap
        let eachItemSize = this._chartSvc.getAxisLabelDummyRect().height;
        let maxNoOfX = Math.floor(maxSpace / eachItemSize);
        if (_xScaleType === 'string')
            maxNoOfX += 1;
        return Math.min(this.initData.length, maxNoOfX);
    }
    _drawAxisLabel(_container, _labelDimenstion, _booleanChecks) {
        let firstTick = 0, xAxisLabelConfig = this.config.xAxis.labels;
        if (this.chartCategory === 'bar')
            firstTick = this.x.paddingOuter() * this.x.step() + this.x.bandwidth() / 2;
        this.data.forEach((d, xIndex) => {
            let labelContainer, tickPos;
            labelContainer = _container.append('div')
                .attr('class', 'kdx-charts-axis-label x-' + xIndex)
                .html(this._chartSvc.getLabelFormatReplace(xAxisLabelConfig.format, d.x.label));
            if (_booleanChecks.isRotate) {
                labelContainer.style('max-width', _labelDimenstion.labelHeight + 'px');
            }
            else {
                if (!this.bar.isInvert)
                    labelContainer.style('max-width', _labelDimenstion.labelWidth + 'px');
            }
            if (this.chartCategory === 'bar') {
                let orderFromLeft = this._chartSvc.isXReversed ? this.data.length - xIndex - 1 : xIndex;
                tickPos = firstTick + this.x.step() * orderFromLeft;
            }
            else {
                tickPos = this.rangeList[this.data[xIndex].x.value];
            }
            this._chartSvc.setAxisLabelPosition(labelContainer, tickPos, Object.assign(_booleanChecks, { isLast: xIndex === this.data.length - 1 }));
        });
    }
    // ================================= Capture Hover Event ==================================
    /**
     * _params can be ID3DataData or can contain callbacks
     * {
     *     ...
     *     callbacks: {
     *         'mouseover': Function,
     *         'mouseout': Function
     *     }
     * }
     */
    _initMouseEvents(_path, _params) {
        let mapCondition = (this.chartType[0] === 'map' && (this.chartType[1] === 'full' || this.chartType[1] === 'filter'));
        if (!this.config.tooltip.enabled)
            return;
        let tooltip;
        _path.on('mouseover', (d, index) => {
            let top = mapCondition ? parseInt(_params.fullGraph.node().style.top) + d3.event.layerY : d3.event.layerY;
            let left = mapCondition ? parseInt(_params.fullGraph.node().style.left) + d3.event.layerX : d3.event.layerX;
            let graphPointer = (mapCondition && _params.tooltipLayer) ? _params.tooltipLayer : this.svgParent;
            tooltip = graphPointer.select('.kdx-charts-tooltip');
            // if tooltip already exist (in case mouseout did not happen), don't append anymore.
            if (tooltip.empty()) {
                tooltip = graphPointer.append('div').attr('class', 'kdx-charts-tooltip');
                tooltip.append('div').attr('class', 'kdx-charts-tooltip-label');
                tooltip.append('div').attr('class', 'kdx-charts-tooltip-count');
            }
            let label;
            let count;
            // let config: IChartConfig = this._chartSvc.config;
            let value;
            if (this.chartType && (this.chartType[0] === 'pie' || this.chartType[0] === 'donut')) {
                label = d.data.x.replace(/¬/g, ' ');
                count = d.data.y;
                _params.pathAnim(d3.select(_path._groups[0][index]), true, _params.innerRadius, _params.outerRadius);
                d3.select(_path._groups[0][index]).style('opacity', '0.7');
            }
            else if (this.chartType && this.chartType[0] === 'radial') {
                label = d.x.replace(/¬/g, ' ');
                count = d.y;
                d3.select(_path._groups[0][index]).style('opacity', '0.7');
            }
            else if (this.chartCategory === 'bar') {
                label = _params.data.x.label;
                count = this._chartSvc.checkAndReturnLabelsPositive(d.value || 0);
                label = label.toString() + ' ' + this.legendData[d.id].name;
                d3.select(_path._groups[0][index]).style('opacity', '0.7');
            }
            else if (this.chartCategory === 'line') {
                label = _params.data.x.label;
                count = _params.data.y[index].value;
                label = label.toString() + ' ' + this.legendData[d].name;
            }
            else if (this.chartCategory === 'map') {
                for (let i = 0; i < _params.seriesData.length; i++) {
                    if (d.properties.ID_ == _params.seriesData[i].id) {
                        label = _params.seriesData[i].name;
                        count = _params.seriesName + ': ' + _params.seriesData[i].value;
                        value = _params.seriesData[i].value;
                        break;
                    }
                }
            }
            count = this._chartSvc.getLabelText(this.config.tooltip.format, count);
            tooltip.select('.kdx-charts-tooltip-label').html(label.toUpperCase());
            if (this.chartType[1] !== 'filter')
                tooltip.select('.kdx-charts-tooltip-count').html(count).style('font-weight', 'bold');
            tooltip.attr('style', this._chartSvc.getStyle(Object.assign({}, TOOLTIP_DEFAULT_STYLE), true));
            tooltip.style('display', 'block');
            tooltip.style('opacity', 2);
            tooltip.style('z-index', 403);
            if (this.chartCategory === 'line') {
                _params.dotHover(this.getDotId(_params.xIndex, d), true);
            }
            if (_params && _params.callbacks && _params.callbacks.mouseover)
                _params.callbacks.mouseover(value);
            // in case mousemove did not trigger, position tooltip once tooltip is created
            if (this.chartCategory !== 'map') {
                this._chartSvc.tooltipSvc.positionTooltip(tooltip, { top: d3.event.layerY, left: d3.event.layerX });
            }
            else {
                if (value || value === 0)
                    this._chartSvc.tooltipSvc.positionTooltip(tooltip, { top: top, left: left });
                else
                    tooltip.remove();
            }
        });
        _path.on('mousemove', (d) => {
            let top = mapCondition ? parseInt(_params.fullGraph.node().style.top) + d3.event.layerY : d3.event.layerY;
            let left = mapCondition ? parseInt(_params.fullGraph.node().style.left) + d3.event.layerX : d3.event.layerX;
            // position the tooltip to the cursor
            this._chartSvc.tooltipSvc.positionTooltip(tooltip, { top: top, left: left });
        });
        _path.on('mouseout', (d, index) => {
            if (this.chartType && (this.chartType[0] === 'pie' || this.chartType[0] === 'donut' || this.chartType[0] === 'radial' || this.chartCategory === 'bar')) {
                if (this.chartType[0] === 'pie' || this.chartType[0] === 'donut') {
                    let thisPath = d3.select(_path._groups[0][index]);
                    if (!thisPath.classed('clicked')) {
                        _params.pathAnim(thisPath, false, _params.innerRadius, _params.outerRadius);
                    }
                }
                d3.select(_path._groups[0][index]).style('opacity', '1');
            }
            // tooltip.style('display', 'none');
            // tooltip.style('opacity', 0);
            tooltip.remove();
            if (this.chartCategory === 'line') {
                _params.dotHover(this.getDotId(_params.xIndex, d));
            }
            if (_params && _params.callbacks && _params.callbacks.mouseout)
                _params.callbacks.mouseout();
        });
        _path.on('click', (d, index) => {
            if (this.chartType && (this.chartType[0] === 'pie' || this.chartType[0] === 'donut')) {
                let thisPath = d3.select(_path._groups[0][index]);
                let clicked = thisPath.classed('clicked');
                _params.pathAnim(thisPath, !clicked, _params.innerRadius, _params.outerRadius);
                thisPath.classed('clicked', !clicked);
            }
        });
    }
    // ================================= LABEL ==================================
    setLabel(_yData, _xData, _xPosition, _yPosition) {
        if (!this.config.chart.labels.enabled)
            return;
        let labelConfig = this.config.chart.labels;
        let labelContainer = this.dataLabelContainer.append('div')
            .attr('class', 'kdx-charts-data-label x-' + _xData + ' y-' + _yData.id);
        let labelText = this._chartSvc.getLabelText(labelConfig.format, _yData.value);
        labelContainer
            .append('div')
            .attr('class', 'kdx-charts-data-label-text')
            .html(labelText)
            .attr('style', this._chartSvc.getStyle(labelConfig.style));
        this._setLabelPosition(labelContainer, _yData.sum || _yData.value, _xPosition, _yPosition);
        return labelContainer;
    }
    transformPosition(x, y, isAttribute) {
        return 'translate(' + x + ((isAttribute) ? ',' : 'px,') + y + ((isAttribute) ? ')' : 'px)');
    }
    getDotId(xData, yId) {
        return 'kdx-charts-point-dot x-' + xData + ' y-' + yId;
    }
    isDataExist(_item, _yIndex) {
        return this._chartSvc.isExist(_item.y[_yIndex]);
    }
    _setLabelContainer() {
        this.dataLabelContainer = d3.select('#' + this.config.id + '.kdx-charts ' + '.kdx-charts-data-label-container');
    }
    /**
     * _params for bar: { valueSign: -1 or 0 or 1, dimensions: width, height, xPos, yPos}
     * _params for line: { dotSize: number, labelLength: number}
     */
    // affects all charts except pie, map, horizontal bar (which uses flex for vertical align, refer to kd-bar-chart)
    setLabelTextPosition(labelText, _yPosition, _params = {}) {
        let store = LABEL_TEXT_VERTICAL_ALIGN_STORE;
        let verticalAlign = this._chartSvc.getDefaultVerticalAlign(this.config, _params);
        let dotSize = _params.dotSize ? _params.dotSize : 0;
        let offset = dotSize / 2;
        if (verticalAlign === 'middle') {
            let checks = ['top', 'bottom'];
            checks.forEach(key => {
                if (this._chartSvc._checkBoundary(store[key].check, _yPosition, this.height, dotSize)) {
                    verticalAlign = store[key].changeTo;
                }
            });
        }
        else if (this._chartSvc._checkBoundary(store[verticalAlign].check, _yPosition, this.height, dotSize)) {
            verticalAlign = store[verticalAlign].changeTo;
        }
        let yPos = '';
        if (verticalAlign === 'middle') {
            yPos = store[verticalAlign].percent;
        }
        else {
            let sign = verticalAlign === 'top' ? ' - ' : ' + ';
            if (this.chartCategory === 'bar' && this._chartSvc.needOffsetForColumn(verticalAlign, _params))
                offset += _params.dimensions.height;
            yPos = 'calc(' + store[verticalAlign].percent + sign + offset.toString() + 'px)';
        }
        let xPos = (_params.labelLength && _params.labelLength > 1) ? 'calc(-50% + ' + dotSize / 2 + 'px)' : '0%';
        let translate = this.chartCategory === 'line' ? this.transformPosition(xPos, yPos, true) : 'translateY(' + yPos + ')';
        labelText.style('transform', translate);
    }
    _setLabelPosition(labelContainer, _yValue, _xPosition, _yPosition) {
        let defaultPosition = {
            x: ((this.bar.isInvert) ? this.height : 0),
            y: ((this.bar.isInvert) ? this.width : 0)
        };
        let x = (typeof _xPosition === 'number') ? _xPosition : defaultPosition.x;
        let y = (typeof _yPosition === 'number') ? _yPosition : defaultPosition.y;
        // if (_yPosition < this.dataLabelPushDownRange) {
        //     y = 5;
        // }
        if (this.isRtl)
            x = (this.width * -1) + x;
        if (_yValue && (_yValue > this.domainMax || _yValue < this.domainMin)) {
            labelContainer.style('display', 'none');
        }
        this._applyLabelPosition(labelContainer, x, y);
    }
    _applyLabelPosition(labelContainer, _xPosition, _yPosition) {
        let rotate = '';
        let labelStyle = this.config.chart.labels.style;
        // this.config.chart.labels.rotation cannot be '' or null or other non-value
        if (labelStyle.hasOwnProperty('rotation') && labelStyle.rotation) {
            rotate = ' rotate(' + labelStyle.rotation + 'deg)';
        }
        labelContainer
            .style('transform', this.transformPosition(_xPosition, _yPosition) + rotate);
        if (this.isRtl)
            labelContainer.style('text-align', 'right');
    }
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoia2QtYW5ndWxhci1jaGFydC1iYXNlLWNsYXNzLmpzIiwic291cmNlUm9vdCI6IkQ6L29wZW5FTUlTL3N0eWxlZ3VpZGUvaW9zdGctb3BlbmVtaXMtc3R5bGVndWlkZS9wcm9qZWN0cy9vcGVuZW1pcy1zdHlsZWd1aWRlLWxpYi9zcmMvIiwic291cmNlcyI6WyJrZC1jb21wb25lbnRzL2tkLWFuZ3VsYXItY2hhcnRzL2tkLWFuZ3VsYXItY2hhcnQtYmFzZS1jbGFzcy50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQSxPQUFPLEtBQUssRUFBRSxNQUFNLElBQUksQ0FBQztBQW1CekIsT0FBTyxFQUFFLCtCQUErQixFQUFFLHFCQUFxQixFQUFFLE1BQU0sNEJBQTRCLENBQUM7QUFHcEcsTUFBTSxPQUFPLGdCQUFnQjtJQWdFekIsWUFBbUIsU0FBc0IsRUFBUyxPQUFxQjtRQUFwRCxjQUFTLEdBQVQsU0FBUyxDQUFhO1FBQVMsWUFBTyxHQUFQLE9BQU8sQ0FBYztRQTlEdkUsZ0JBQWdCO1FBQ1QsVUFBSyxHQUFZLEtBQUssQ0FBQztRQUN2QixXQUFNLEdBQWlCLEVBQUUsQ0FBQztRQUMxQixTQUFJLEdBQXVCLEVBQUUsQ0FBQztRQUM5QixhQUFRLEdBQXVCLEVBQUUsQ0FBQztRQW9CbEMsYUFBUSxHQUFlLEVBQUUsQ0FBQztRQU0xQixZQUFPLEdBQVcsQ0FBQyxDQUFDO1FBS3BCLDBCQUFxQixHQUFlLEVBQUUsQ0FBQztRQUV2QyxpQkFBWSxHQUFZLEtBQUssQ0FBQztRQUNyQzs7Ozs7V0FLRztRQUNJLFFBQUcsR0FBOEU7WUFDcEYsUUFBUSxFQUFFLEtBQUs7WUFDZixxQkFBcUIsRUFBRSxHQUFHO1lBQzFCLFdBQVcsRUFBRSxHQUFHO1NBQ25CLENBQUM7UUFHSyx1QkFBa0IsR0FBVyxJQUFJLENBQUM7UUFPbEMsYUFBUSxHQUFXLDhDQUE4QyxDQUFDO1FBS3JFLElBQUksQ0FBQyxLQUFLLEdBQUcsT0FBTyxDQUFDLG9CQUFvQixDQUFDLElBQUksQ0FBQyxLQUFLLE9BQU8sQ0FBQztJQUNoRSxDQUFDO0lBRUQsNkVBQTZFO0lBRXRFLE1BQU07UUFDVCxJQUFJLENBQUMsR0FBRyxHQUFHLEVBQUUsQ0FBQyxNQUFNLENBQUMsR0FBRyxHQUFHLElBQUksQ0FBQyxNQUFNLENBQUMsRUFBRSxHQUFHLGlCQUFpQixDQUFDLENBQUM7UUFDL0QsSUFBSSxDQUFDLElBQUksQ0FBQyxLQUFLO1lBQUUsSUFBSSxDQUFDLEtBQUssR0FBRyxJQUFJLENBQUMsR0FBRyxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsQ0FBQyxJQUFJLENBQUMsT0FBTyxFQUFFLE9BQU8sQ0FBQyxDQUFDO1FBQzFFLG1HQUFtRztRQUNuRyxJQUFJLENBQUMsU0FBUyxHQUFHLEVBQUUsQ0FBQyxNQUFNLENBQUMsR0FBRyxHQUFHLElBQUksQ0FBQyxNQUFNLENBQUMsRUFBRSxHQUFHLGtDQUFrQyxDQUFDLENBQUM7UUFDdEYsSUFBSSxDQUFDLFlBQVksR0FBRyxFQUFFLENBQUMsTUFBTSxDQUFDLEdBQUcsR0FBRyxJQUFJLENBQUMsTUFBTSxDQUFDLEVBQUUsR0FBRyx1Q0FBdUMsQ0FBQyxDQUFDO1FBRTlGLElBQUksQ0FBQyxrQkFBa0IsRUFBRSxDQUFDO1FBQzFCLElBQUksQ0FBQyxZQUFZLEVBQUUsQ0FBQztRQUNwQixJQUFJLENBQUMsU0FBUyxHQUFHLEVBQUUsQ0FBQztJQUN4QixDQUFDO0lBRUQ7Ozs7T0FJRztJQUNJLGVBQWUsQ0FBQyxLQUFnQjtRQUNuQyxJQUFJLGdCQUFnQixHQUFRLElBQUksQ0FBQyxZQUFZLENBQUMsSUFBSSxFQUFFLENBQUMscUJBQXFCLEVBQUUsQ0FBQztRQUM3RSxJQUFJLElBQUksR0FBdUIsS0FBSyxLQUFLLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQztRQUVuSSxJQUFJLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxJQUFJLEVBQUUsZ0JBQWdCLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQztJQUNoRCxDQUFDO0lBRU8sa0JBQWtCO1FBQ3RCLElBQUksQ0FBQyxJQUFJLENBQUMsR0FBRztZQUFFLE9BQU87UUFDdEIsSUFBSSxDQUFDLEdBQUc7YUFDSCxJQUFJLENBQUMsT0FBTyxFQUFFLENBQUMsQ0FBQzthQUNoQixJQUFJLENBQUMsUUFBUSxFQUFFLENBQUMsQ0FBQyxDQUFDO0lBQzNCLENBQUM7SUFFRDs7OztPQUlHO0lBQ0ssa0JBQWtCLENBQUMsS0FBZ0I7UUFDdkMsSUFBSSxDQUFDLE9BQU8sR0FBRyxJQUFJLENBQUMsR0FBRyxDQUFDLElBQUksRUFBRSxDQUFDLHFCQUFxQixFQUFFLENBQUM7UUFDdkQsSUFBSSxDQUFDLFNBQVMsQ0FBQyxPQUFPLEdBQUcsSUFBSSxDQUFDLE9BQU8sQ0FBQztRQUV0QyxJQUFJLElBQUksR0FBdUIsS0FBSyxLQUFLLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQztRQUVuSSxJQUFJLEtBQUssR0FBVyxJQUFJLENBQUMsU0FBUyxDQUFDLFlBQVksQ0FBQyxLQUFLLEVBQUUsRUFBRSxPQUFPLEVBQUUsSUFBSSxDQUFDLE9BQU8sRUFBRSxPQUFPLEVBQUUsSUFBSSxDQUFDLE9BQU8sRUFBRSxDQUFDLENBQUM7UUFFekcsSUFBSSxDQUFDLElBQUksQ0FBQyxHQUFHLEtBQUssR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDO0lBQ3ZDLENBQUM7SUFFRDs7T0FFRztJQUNLLFlBQVk7UUFDaEIsSUFBSSxDQUFDLFNBQVMsQ0FBQyxNQUFNLEdBQUcsSUFBSSxDQUFDLE1BQU0sQ0FBQztRQUNwQyxJQUFJLENBQUMsU0FBUyxDQUFDLFNBQVMsR0FBRyxJQUFJLENBQUMsU0FBUyxDQUFDO1FBQzFDLElBQUksQ0FBQyxTQUFTLENBQUMsYUFBYSxHQUFHLElBQUksQ0FBQyxhQUFhLENBQUM7UUFDbEQsSUFBSSxDQUFDLFNBQVMsQ0FBQyxhQUFhLEdBQUcsSUFBSSxDQUFDLFNBQVMsQ0FBQyxJQUFJLEVBQUUsQ0FBQyxxQkFBcUIsRUFBRSxDQUFDO1FBQzdFLElBQUksQ0FBQyxTQUFTLENBQUMsR0FBRyxHQUFHLElBQUksQ0FBQyxHQUFHLENBQUM7UUFDOUIsSUFBSSxDQUFDLFNBQVMsQ0FBQyxLQUFLLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQztRQUNsQyxJQUFJLENBQUMsU0FBUyxDQUFDLFdBQVcsR0FBRyxJQUFJLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxRQUFRLENBQUM7UUFDeEQsSUFBSSxDQUFDLFNBQVMsQ0FBQyxXQUFXLEdBQUcsSUFBSSxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsUUFBUSxDQUFDO0lBQzVELENBQUM7SUFFTyxlQUFlO1FBQ25CLElBQUksYUFBYSxHQUFrQixJQUFJLENBQUMsWUFBWSxDQUFDLEdBQUcsQ0FBQyxDQUFDO1FBQzFELElBQUksQ0FBQyxDQUFDLEdBQUcsRUFBRSxDQUFDLFdBQVcsRUFBRSxDQUFDLFVBQVUsQ0FBQyxhQUFhLENBQUMsQ0FBQztJQUN4RCxDQUFDO0lBRU8sYUFBYTtRQUNqQixJQUFJLFFBQVEsR0FBa0IsSUFBSSxDQUFDLFlBQVksQ0FBQyxHQUFHLENBQUMsQ0FBQztRQUVyRCxJQUFJLENBQUMsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxTQUFTLEVBQUUsQ0FBQyxLQUFLLENBQUMsUUFBUSxDQUFDLENBQUM7UUFFeEMsSUFBSSxJQUFJLENBQUMsYUFBYSxLQUFLLEtBQUssRUFBRTtZQUM5QixJQUFJLENBQUMsQ0FBQyxDQUFDLFlBQVksQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLFdBQVcsQ0FBQyxDQUFDLFlBQVksQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLFdBQVcsR0FBRyxDQUFDLENBQUMsQ0FBQztTQUNwRjtJQUNMLENBQUM7SUFFTyxZQUFZLENBQUMsS0FBZ0I7UUFDakMsSUFBSSxRQUFrQixDQUFDO1FBQ3ZCLElBQUksUUFBUSxHQUFrQyxLQUFLLEtBQUssR0FBRyxDQUFDLENBQUMsQ0FBQyxhQUFhLENBQUMsQ0FBQyxDQUFDLGFBQWEsQ0FBQztRQUU1RixJQUFJLElBQUksQ0FBQyxHQUFHLENBQUMsUUFBUSxFQUFFO1lBQ25CLFFBQVEsR0FBRyxLQUFLLEtBQUssR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQztTQUNqRTthQUFNO1lBQ0gsUUFBUSxHQUFHLEtBQUssS0FBSyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsTUFBTSxFQUFFLENBQUMsQ0FBQyxDQUFDO1NBQ2pFO1FBRUQsT0FBTyxJQUFJLENBQUMsU0FBUyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsT0FBTyxFQUFFLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQztJQUNwRSxDQUFDO0lBRU8sU0FBUyxDQUFDLE1BQWdCO1FBQzlCLElBQUksVUFBVSxHQUFXLElBQUksQ0FBQyxLQUFLLENBQUM7UUFFcEMsSUFBSSxDQUFDLE1BQU0sSUFBSSxJQUFJLENBQUMsSUFBSSxDQUFDLE1BQU0sSUFBSSxDQUFDLEVBQUU7WUFDbEMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsR0FBRyxVQUFVLENBQUM7WUFDL0IsT0FBTyxDQUFDLENBQUMsRUFBRSxVQUFVLENBQUMsQ0FBQztTQUMxQjtRQUVELElBQUksU0FBUyxHQUFXLENBQUMsQ0FBQztRQUMxQixJQUFJLFVBQVUsR0FBa0IsRUFBRSxDQUFDO1FBQ25DLElBQUksU0FBUyxHQUFXLFVBQVUsR0FBRyxJQUFJLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQztRQUV0RCxLQUFLLElBQUksQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLEdBQUcsSUFBSSxDQUFDLElBQUksQ0FBQyxNQUFNLEVBQUUsQ0FBQyxFQUFFLEVBQUU7WUFFdkMsSUFBSSxNQUFNLEVBQUU7Z0JBQ1IsU0FBUyxHQUFHLElBQUksQ0FBQyxzQkFBc0IsQ0FBQyxTQUFTLEVBQUUsQ0FBQyxDQUFDLENBQUM7YUFDekQ7aUJBQU07Z0JBQ0gsU0FBUyxHQUFHLFVBQVUsR0FBRyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsTUFBTSxHQUFHLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQzthQUN2RDtZQUVELElBQUksSUFBSSxDQUFDLFNBQVMsQ0FBQyxXQUFXO2dCQUFFLFNBQVMsR0FBRyxVQUFVLEdBQUcsU0FBUyxDQUFDO1lBRW5FLFVBQVUsQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLENBQUM7WUFDM0IsSUFBSSxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsR0FBRyxTQUFTLENBQUM7U0FDcEQ7UUFFRCxPQUFPLFVBQVUsQ0FBQztJQUN0QixDQUFDO0lBRU8sc0JBQXNCLENBQUMsVUFBa0IsRUFBRSxTQUFpQjtRQUNoRSxPQUFPLENBQUMsVUFBVSxHQUFHLENBQUMsQ0FBQyxHQUFHLENBQUMsVUFBVSxHQUFHLFNBQVMsQ0FBQyxDQUFDO0lBQ3ZELENBQUM7SUFFTyxvQkFBb0IsQ0FBQyxLQUFnQixFQUFFLFdBQStCO1FBQzFFLElBQUksS0FBSyxLQUFLLEdBQUcsRUFBRTtZQUNmLElBQUksV0FBVyxLQUFLLFFBQVE7Z0JBQUUsSUFBSSxDQUFDLGFBQWEsRUFBRSxDQUFDO1lBQ25ELElBQUksSUFBSSxDQUFDLGFBQWEsS0FBSyxNQUFNO2dCQUFFLElBQUksQ0FBQyxjQUFjLENBQUMsV0FBVyxDQUFDLENBQUM7U0FDdkU7YUFBTTtZQUNILElBQUksQ0FBQyxlQUFlLEVBQUUsQ0FBQztTQUMxQjtJQUNMLENBQUM7SUFFRDs7O09BR0c7SUFDSyxjQUFjLENBQUMsV0FBOEI7UUFDakQsSUFBSSxXQUFXLEtBQUssUUFBUSxFQUFFO1lBQzFCLElBQUksQ0FBQyxDQUFDLEdBQUcsRUFBRSxDQUFDLFlBQVksRUFBRSxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUM7U0FDM0Q7YUFBTTtZQUNILElBQUksQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDLENBQUM7U0FDeEI7SUFDTCxDQUFDO0lBRUQsOEVBQThFO0lBRXZFLFNBQVMsQ0FBQyxXQUE4QjtRQUUzQyxJQUFJLENBQUMsU0FBUyxDQUFDLFVBQVUsR0FBRyxXQUFXLENBQUM7UUFFeEMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsWUFBWSxFQUFFLFFBQVEsQ0FBQyxDQUFDO1FBRXRDLDZEQUE2RDtRQUM3RCxJQUFJLENBQUMsU0FBUyxDQUFDLHlCQUF5QixDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsRUFBRSxDQUFDLENBQUM7UUFFekQsOEtBQThLO1FBQzlLLElBQUksSUFBSSxDQUFDLFFBQVEsSUFBSSxJQUFJLENBQUMsSUFBSSxDQUFDLE1BQU0sS0FBSyxJQUFJLENBQUMsUUFBUSxDQUFDLE1BQU0sRUFBRTtZQUM1RCxJQUFJLENBQUMsSUFBSSxHQUFHLElBQUksQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQztZQUN0RCwwRkFBMEY7U0FDN0Y7UUFFRCxzREFBc0Q7UUFDdEQsSUFBSSxDQUFDLFVBQVUsQ0FBQyxXQUFXLENBQUMsQ0FBQztRQUU3QixJQUFJLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxZQUFZLEVBQUUsU0FBUyxDQUFDLENBQUM7UUFFdkMsaUNBQWlDO1FBQ2pDLElBQUksQ0FBQyxhQUFhLEVBQUUsQ0FBQztRQUVyQix5QkFBeUI7UUFDekIsSUFBSSxDQUFDLE9BQU8sRUFBRSxDQUFDO1FBRWYsc0RBQXNEO1FBQ3RELElBQUksQ0FBQyxTQUFTLENBQUMsdUJBQXVCLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFDO1FBRW5ELDREQUE0RDtRQUM1RCxJQUFJLElBQUksQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxPQUFPLEVBQUU7WUFDbEMsSUFBSSxDQUFDLGtCQUFrQixDQUFDLEtBQUssQ0FBQyxPQUFPLEVBQUUsSUFBSSxDQUFDLEtBQUssR0FBRyxJQUFJLENBQUMsQ0FBQztZQUMxRCxJQUFJLENBQUMsU0FBUyxDQUFDLG1CQUFtQixDQUFDLElBQUksQ0FBQyxrQkFBa0IsRUFBRSxJQUFJLENBQUMscUJBQXFCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztTQUM5RjtRQUVELDJCQUEyQjtRQUMzQixJQUFJLENBQUMsU0FBUyxDQUFDLDJCQUEyQixFQUFFLENBQUM7UUFFN0MsMEdBQTBHO1FBQzFHLElBQUksQ0FBQyxZQUFZLEVBQUUsQ0FBQztJQUN4QixDQUFDO0lBRU8sVUFBVSxDQUFDLFdBQThCO1FBQzdDLGdEQUFnRDtRQUNoRCxJQUFJLGVBQWUsR0FBaUIsSUFBSSxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUM7UUFDdEQsSUFBSSxNQUFNLEdBQW9CLElBQUksQ0FBQyxTQUFTLENBQUMsWUFBWSxDQUFDLGVBQWUsRUFBRSxJQUFJLENBQUMsU0FBUyxDQUFDLENBQUM7UUFDM0YsSUFBSSxDQUFDLFNBQVMsQ0FBQyxlQUFlLENBQUMsTUFBTSxDQUFDLFFBQVEsQ0FBQyxDQUFDO1FBRWhELElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxNQUFNLENBQUMsUUFBUSxFQUFFLE1BQU0sQ0FBQyxRQUFRLEVBQUUsTUFBTSxDQUFDLFFBQVEsQ0FBQyxDQUFDO1FBRTFFLElBQUksS0FBSyxHQUFXLElBQUksQ0FBQyxTQUFTLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxJQUFJLEVBQUUsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDO1FBQ3BFLElBQUksQ0FBQyxvQkFBb0IsQ0FBQyxHQUFHLEVBQUUsV0FBVyxDQUFDLENBQUM7UUFDNUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxDQUFDO1FBQzNCLElBQUksQ0FBQyxjQUFjLENBQUMsV0FBVyxFQUFFLEtBQUssQ0FBQyxXQUFXLENBQUMsQ0FBQztRQUVwRCxJQUFJLENBQUMsb0JBQW9CLENBQUMsR0FBRyxFQUFFLFdBQVcsQ0FBQyxDQUFDO1FBRTVDLElBQUksZUFBZSxHQUF3QixJQUFJLENBQUMseUJBQXlCLENBQUMsTUFBTSxDQUFDLENBQUM7UUFFbEYsSUFBSSxlQUFlLElBQUksZUFBZSxDQUFDLFVBQVUsRUFBRTtZQUMvQyxJQUFJLENBQUMsb0JBQW9CLENBQUMsR0FBRyxFQUFFLFdBQVcsQ0FBQyxDQUFDO1lBQzVDLElBQUksQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsQ0FBQztZQUMzQixJQUFJLENBQUMsY0FBYyxDQUFDLFdBQVcsRUFBRSxLQUFLLENBQUMsV0FBVyxDQUFDLENBQUM7WUFFcEQsSUFBSSxDQUFDLG9CQUFvQixDQUFDLEdBQUcsRUFBRSxXQUFXLENBQUMsQ0FBQztTQUMvQztRQUVELHFEQUFxRDtRQUNyRCxJQUFJLENBQUMsVUFBVSxHQUFHLElBQUksQ0FBQyxTQUFTLENBQUMsYUFBYSxDQUFDLElBQUksQ0FBQyxPQUFPLEVBQUUsSUFBSSxDQUFDLE9BQU8sRUFBRSxlQUFlLENBQUMsUUFBUSxDQUFDLENBQUM7UUFFckcsZUFBZTtRQUNmLElBQUksQ0FBQyxTQUFTLEdBQUcsZUFBZSxDQUFDLGNBQWMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLFFBQVEsQ0FBQztRQUNqRixJQUFJLENBQUMsU0FBUyxHQUFHLGVBQWUsQ0FBQyxjQUFjLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxRQUFRLENBQUM7UUFDakYsSUFBSSxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxJQUFJLENBQUMsU0FBUyxFQUFFLElBQUksQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDO0lBQ3BELENBQUM7SUFHTyxvQkFBb0IsQ0FBQyxLQUFnQixFQUFFLFdBQThCO1FBQ3pFLElBQUksQ0FBQyxlQUFlLENBQUMsS0FBSyxDQUFDLENBQUM7UUFDNUIsSUFBSSxDQUFDLGtCQUFrQixDQUFDLEtBQUssQ0FBQyxDQUFDO1FBQy9CLElBQUksQ0FBQyxvQkFBb0IsQ0FBQyxLQUFLLEVBQUUsV0FBVyxDQUFDLENBQUM7SUFDbEQsQ0FBQztJQUVEOztPQUVHO0lBQ0ssWUFBWTtRQUNoQixJQUFJLFlBQVksR0FBUSxJQUFJLENBQUMsR0FBRyxDQUFDLFNBQVMsQ0FBQyw0QkFBNEIsR0FBRyxJQUFJLENBQUMsTUFBTSxDQUFDLEVBQUUsR0FBRyxPQUFPLENBQUMsQ0FBQztRQUNwRyxJQUFJLFlBQVksQ0FBQyxLQUFLLEVBQUUsRUFBRTtZQUN0QixZQUFZLEdBQUcsSUFBSSxDQUFDLEdBQUcsQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLENBQUMsTUFBTSxDQUFDLFVBQVUsQ0FBQyxDQUFDLElBQUksQ0FBQyxJQUFJLEVBQUUsc0JBQXNCLEdBQUcsSUFBSSxDQUFDLE1BQU0sQ0FBQyxFQUFFLENBQUMsQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLENBQUM7WUFDN0gsWUFBWTtpQkFDUCxJQUFJLENBQUMsR0FBRyxFQUFFLENBQUMsQ0FBQztpQkFDWixJQUFJLENBQUMsR0FBRyxFQUFFLENBQUMsQ0FBQztpQkFDWixJQUFJLENBQUMsTUFBTSxFQUFFLE1BQU0sQ0FBQyxDQUFDO1NBQzdCO1FBQ0QsWUFBWTthQUNQLElBQUksQ0FBQyxPQUFPLEVBQUUsSUFBSSxDQUFDLEtBQUssQ0FBQzthQUN6QixJQUFJLENBQUMsUUFBUSxFQUFFLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQztJQUNyQyxDQUFDO0lBRU8saUJBQWlCLENBQUMsU0FBaUIsRUFBRSxTQUFpQixFQUFFLFNBQWlCO1FBQzdFLElBQUksV0FBVyxHQUFpQixJQUFJLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQztRQUNsRCxJQUFJLENBQUMsT0FBTyxHQUFHLElBQUksQ0FBQyxTQUFTLENBQUMsaUJBQWlCLENBQUMsU0FBUyxFQUFFLFNBQVMsRUFBRSxXQUFXLENBQUMsY0FBYyxFQUFFLElBQUksQ0FBQyxDQUFDO1FBQ3hHLElBQUksQ0FBQyxPQUFPLEdBQUcsSUFBSSxDQUFDLFNBQVMsQ0FBQyxpQkFBaUIsQ0FBQyxTQUFTLEVBQUUsU0FBUyxFQUFFLFdBQVcsQ0FBQyxjQUFjLEVBQUUsTUFBTSxDQUFDLENBQUM7SUFDOUcsQ0FBQztJQUVEOzs7O0tBSUM7SUFDTyx5QkFBeUIsQ0FBQyxTQUEwQjtRQUN4RCxJQUFJLE1BQU0sR0FBVyxJQUFJLENBQUMsR0FBRyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQztRQUNsRSxJQUFJLE1BQU0sSUFBSSxDQUFDO1lBQUUsT0FBTyxFQUFFLFVBQVUsRUFBRSxLQUFLLEVBQUUsUUFBUSxFQUFFLENBQUMsRUFBRSxDQUFDO1FBRTNELElBQUksVUFBa0IsQ0FBQztRQUN2QixJQUFJLG1CQUFtQixHQUFxQixNQUFNLENBQUMsTUFBTSxDQUFDLEVBQUUsRUFBRSxJQUFJLENBQUMsU0FBUyxDQUFDLGVBQWUsQ0FBQyxDQUFDO1FBRTlGLElBQUksSUFBSSxDQUFDLEdBQUcsQ0FBQyxRQUFRLEVBQUU7WUFDbkIsMEdBQTBHO1lBQzFHLGdKQUFnSjtZQUNoSixVQUFVLEdBQUcsSUFBSSxDQUFDLEdBQUcsQ0FBQyxtQkFBbUIsQ0FBQyxPQUFPLEVBQUUsbUJBQW1CLENBQUMsT0FBTyxDQUFDLENBQUM7U0FDbkY7YUFBTTtZQUNILFVBQVUsR0FBRyxJQUFJLENBQUMsU0FBUyxDQUFDLHVCQUF1QixDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsUUFBUSxDQUFDLENBQUM7U0FDaEc7UUFFRCxJQUFJLFlBQVksR0FBVyxTQUFTLENBQUMsUUFBUSxDQUFDO1FBQzlDLElBQUksUUFBUSxHQUFXLFlBQVksQ0FBQztRQUNwQyxJQUFJLFNBQVMsR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDLENBQUMsSUFBSSxDQUFDLE9BQU8sR0FBRyxRQUFRLEdBQUcsSUFBSSxDQUFDLE9BQU8sQ0FBQyxHQUFHLFFBQVEsQ0FBQyxDQUFDO1FBRWhGLElBQUksTUFBTSxHQUFHLFVBQVUsSUFBSSxTQUFTLEtBQUssQ0FBQztZQUFFLE9BQU8sRUFBRSxVQUFVLEVBQUUsS0FBSyxFQUFFLFFBQVEsRUFBRSxDQUFDLEVBQUUsQ0FBQztRQUV0RixJQUFJLGFBQWEsR0FBVyxJQUFJLENBQUMsU0FBUyxDQUFDLGVBQWUsQ0FBQyxJQUFJLENBQUMsT0FBTyxFQUFFLElBQUksQ0FBQyxPQUFPLENBQUMsQ0FBQyxRQUFRLEVBQUUsQ0FBQyxNQUFNLENBQUM7UUFFekcsT0FBTyxDQUFDLE1BQU0sR0FBRyxTQUFTLENBQUMsR0FBRyxVQUFVLElBQUksU0FBUyxHQUFHLENBQUMsRUFBRTtZQUN2RCxRQUFRLEdBQUcsUUFBUSxHQUFHLENBQUMsQ0FBQztZQUN4QixJQUFJLENBQUMsaUJBQWlCLENBQUMsU0FBUyxDQUFDLFFBQVEsRUFBRSxTQUFTLENBQUMsUUFBUSxFQUFFLFFBQVEsQ0FBQyxDQUFDO1lBRXpFLCtHQUErRztZQUMvRyxtRkFBbUY7WUFDbkYsSUFBSSxJQUFJLENBQUMsR0FBRyxDQUFDLFFBQVEsSUFBSSxJQUFJLENBQUMsU0FBUyxDQUFDLGVBQWUsQ0FBQyxJQUFJLENBQUMsT0FBTyxFQUFFLElBQUksQ0FBQyxPQUFPLENBQUMsQ0FBQyxRQUFRLEVBQUUsQ0FBQyxNQUFNLEdBQUcsYUFBYSxFQUFFO2dCQUNuSCxVQUFVLEdBQUcsSUFBSSxDQUFDLFNBQVMsQ0FBQyxpQkFBaUIsQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLGVBQWUsQ0FBQyxJQUFJLENBQUMsT0FBTyxFQUFFLElBQUksQ0FBQyxPQUFPLENBQUMsRUFBRSxTQUFTLENBQUMsQ0FBQzthQUN4SDtZQUVELFNBQVMsR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDLENBQUMsSUFBSSxDQUFDLE9BQU8sR0FBRyxRQUFRLEdBQUcsSUFBSSxDQUFDLE9BQU8sQ0FBQyxHQUFHLFFBQVEsQ0FBQyxDQUFDO1NBQy9FO1FBRUQsNkZBQTZGO1FBQzdGLHFIQUFxSDtRQUNySCxJQUFJLFlBQVksS0FBSyxRQUFRLEVBQUU7WUFDM0IsSUFBSSxDQUFDLFNBQVMsQ0FBQyxlQUFlLENBQUMsUUFBUSxDQUFDLENBQUM7WUFDekMsSUFBSSxrQkFBa0IsR0FBcUIsSUFBSSxDQUFDLFNBQVMsQ0FBQywyQkFBMkIsQ0FBQyxFQUFFLE9BQU8sRUFBRSxJQUFJLENBQUMsT0FBTyxFQUFFLE9BQU8sRUFBRSxJQUFJLENBQUMsT0FBTyxFQUFFLENBQUMsQ0FBQztZQUN4SSxJQUFJLGtCQUFrQixDQUFDLE9BQU8sS0FBSyxtQkFBbUIsQ0FBQyxPQUFPLElBQUksa0JBQWtCLENBQUMsT0FBTyxLQUFLLG1CQUFtQixDQUFDLE9BQU8sRUFBRTtnQkFDMUgsT0FBTyxFQUFFLFVBQVUsRUFBRSxJQUFJLEVBQUUsUUFBUSxFQUFFLFFBQVEsRUFBRSxDQUFDO2FBQ25EO1NBQ0o7UUFFRCxPQUFPLEVBQUUsVUFBVSxFQUFFLEtBQUssRUFBRSxRQUFRLEVBQUUsUUFBUSxFQUFFLENBQUM7SUFDckQsQ0FBQztJQUVELGtGQUFrRjtJQUUxRSxhQUFhO1FBQ2pCLElBQUksQ0FBQyxJQUFJLENBQUMsa0JBQWtCO1lBQUUsSUFBSSxDQUFDLGtCQUFrQixHQUFHLElBQUksQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQyxPQUFPLEVBQUUsZ0NBQWdDLENBQUMsQ0FBQztRQUMvSCxJQUFJLENBQUMsU0FBUyxDQUFDLE9BQU8sQ0FBQyxjQUFjLEdBQUcsRUFBRSxLQUFLLEVBQUUsSUFBSSxDQUFDLEtBQUssRUFBRSxNQUFNLEVBQUUsSUFBSSxDQUFDLE1BQU0sRUFBRSxDQUFDO1FBQ25GLElBQUksSUFBSSxDQUFDLFNBQVMsQ0FBQyxPQUFPLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxNQUFNLEVBQUUsT0FBTyxFQUFFLFVBQVUsQ0FBQztZQUFFLElBQUksQ0FBQyxhQUFhLEVBQUUsQ0FBQztRQUM1RixJQUFJLElBQUksQ0FBQyxTQUFTLENBQUMsT0FBTyxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsTUFBTSxFQUFFLE9BQU8sRUFBRSxlQUFlLENBQUM7WUFBRSxJQUFJLENBQUMsa0JBQWtCLEVBQUUsQ0FBQztRQUN0RyxJQUFJLElBQUksQ0FBQyxTQUFTLENBQUMsT0FBTyxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsTUFBTSxFQUFFLE9BQU8sRUFBRSxVQUFVLENBQUM7WUFBRSxJQUFJLENBQUMsYUFBYSxFQUFFLENBQUM7SUFDaEcsQ0FBQztJQUVPLGFBQWE7UUFDakIsc0ZBQXNGO1FBQ3RGLElBQUksS0FBSyxHQUFHLElBQUksQ0FBQyxTQUFTLENBQUMsT0FBTyxDQUFDLGNBQWMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUM7UUFDMUQsdUZBQXVGO1FBQ3ZGLElBQUksS0FBSyxHQUFrQixDQUFDLEVBQUUsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQztRQUM1RSx1REFBdUQ7UUFDdkQsSUFBSSxDQUFDLFNBQVMsQ0FBQyxPQUFPLENBQUMsWUFBWSxDQUFDLElBQUksQ0FBQyxrQkFBa0IsRUFBRSxLQUFLLEVBQUUsT0FBTyxFQUFFLFVBQVUsRUFBRSxLQUFLLENBQUMsQ0FBQztJQUNwRyxDQUFDO0lBRUQsdUJBQXVCO0lBQ2YsYUFBYTtRQUNqQixJQUFJLENBQUMsU0FBUyxDQUFDLE9BQU8sQ0FBQyxZQUFZLENBQUMsSUFBSSxDQUFDLGtCQUFrQixFQUFFLElBQUksQ0FBQyxVQUFVLEVBQUUsT0FBTyxFQUFFLFVBQVUsRUFBRSxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUM7SUFDL0csQ0FBQztJQUVPLGtCQUFrQjtRQUN0QixJQUFJLFdBQVcsR0FBaUIsSUFBSSxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUM7UUFDbEQsSUFBSSxXQUFXLENBQUMsaUJBQWlCLElBQUksV0FBVyxDQUFDLFlBQVksSUFBSSxDQUFDLFdBQVcsQ0FBQyxpQkFBaUI7WUFBRSxPQUFPO1FBRXhHLElBQUksVUFBVSxHQUFXLElBQUksQ0FBQyxTQUFTLENBQUMsaUJBQWlCLENBQUMsSUFBSSxDQUFDLFNBQVMsRUFBRSxXQUFXLENBQUMsaUJBQWlCLEVBQUUsS0FBSyxFQUFFLElBQUksQ0FBQyxDQUFDO1FBQ3RILElBQUksVUFBVSxHQUFXLElBQUksQ0FBQyxTQUFTLENBQUMsaUJBQWlCLENBQUMsSUFBSSxDQUFDLFNBQVMsRUFBRSxXQUFXLENBQUMsaUJBQWlCLEVBQUUsS0FBSyxFQUFFLE1BQU0sQ0FBQyxDQUFDO1FBQ3hILElBQUksZUFBZSxHQUFrQixJQUFJLENBQUMsU0FBUyxDQUFDLGFBQWEsQ0FBQyxVQUFVLEVBQUUsVUFBVSxFQUFFLFdBQVcsQ0FBQyxpQkFBaUIsQ0FBQyxDQUFDO1FBRXpILElBQUksQ0FBQyxTQUFTLENBQUMsT0FBTyxDQUFDLFlBQVksQ0FBQyxJQUFJLENBQUMsa0JBQWtCLEVBQUUsZUFBZSxFQUFFLE9BQU8sRUFBRSxlQUFlLEVBQUUsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDO0lBQ3BILENBQUM7SUFFRCw0RUFBNEU7SUFFckUsT0FBTztRQUNWLElBQUksWUFBWSxHQUFzQjtZQUNsQyxLQUFLLEVBQUUsWUFBWSxHQUFHLElBQUksQ0FBQyxLQUFLLEdBQUcsS0FBSztZQUN4QyxJQUFJLEVBQUUsZ0JBQWdCO1lBQ3RCLEdBQUcsRUFBRSxnQkFBZ0I7WUFDckIsTUFBTSxFQUFFLGNBQWMsR0FBRyxJQUFJLENBQUMsTUFBTSxHQUFHLEdBQUc7U0FDN0MsQ0FBQztRQUVGLElBQUksV0FBVyxHQUFpQixJQUFJLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQztRQUNsRCxJQUFJLFdBQVcsR0FBaUIsSUFBSSxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUM7UUFDbEQsSUFBSSxNQUFNLEdBQVksSUFBSSxDQUFDLEdBQUcsQ0FBQyxRQUFRLENBQUM7UUFDeEMsSUFBSSxRQUFRLEdBQStCO1lBQ3ZDLENBQUMsRUFBRSxNQUFNLENBQUMsQ0FBQyxDQUFDLFdBQVcsQ0FBQyxRQUFRLEtBQUssSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsV0FBVyxDQUFDLFFBQVE7WUFDdEUsQ0FBQyxFQUFFLE1BQU0sQ0FBQyxDQUFDLENBQUMsV0FBVyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsV0FBVyxDQUFDLFFBQVEsS0FBSyxJQUFJLENBQUMsS0FBSztTQUN6RSxDQUFDO1FBRUYsSUFBSSxLQUFLLEdBQUcsSUFBSSxDQUFDLGdCQUFnQixDQUFDLEdBQUcsRUFBRSxRQUFRLENBQUMsQ0FBQyxFQUFFLE1BQU0sQ0FBQyxDQUFDO1FBQzNELElBQUksQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFDO1FBQzFCLElBQUksQ0FBQyxLQUFLLEdBQUcsSUFBSSxDQUFDLGdCQUFnQixDQUFDLEdBQUcsRUFBRSxRQUFRLENBQUMsQ0FBQyxFQUFFLE1BQU0sQ0FBQyxDQUFDO1FBRTVELEtBQUssQ0FBQyxJQUFJLENBQUMsV0FBVyxFQUFFLElBQUksQ0FBQyxTQUFTLENBQUMsbUJBQW1CLENBQUMsR0FBRyxFQUFFLFFBQVEsQ0FBQyxDQUFDLEVBQUUsWUFBWSxDQUFDLENBQUMsQ0FBQztRQUMzRixJQUFJLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxXQUFXLEVBQUUsSUFBSSxDQUFDLFNBQVMsQ0FBQyxtQkFBbUIsQ0FBQyxHQUFHLEVBQUUsUUFBUSxDQUFDLENBQUMsRUFBRSxZQUFZLENBQUMsQ0FBQyxDQUFDO1FBRWhHLElBQUksQ0FBQyxTQUFTLENBQUMsa0JBQWtCLENBQUMsS0FBSyxFQUFFLEdBQUcsQ0FBQyxDQUFDO1FBQzlDLElBQUksQ0FBQyxTQUFTLENBQUMsa0JBQWtCLENBQUMsSUFBSSxDQUFDLEtBQUssRUFBRSxHQUFHLENBQUMsQ0FBQztRQUVuRCxJQUFJLElBQUksQ0FBQyxTQUFTLENBQUMsZUFBZSxFQUFFO1lBQ2hDLElBQUksV0FBVyxHQUFHLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxRQUFRLENBQUMsQ0FBQyxFQUFFLElBQUksQ0FBQyxHQUFHLENBQUMsUUFBUSxDQUFDLENBQUM7WUFDN0UsV0FBVyxDQUFDLElBQUksQ0FBQyxXQUFXLEVBQUUsSUFBSSxDQUFDLFNBQVMsQ0FBQyxtQkFBbUIsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxRQUFRLENBQUMsQ0FBQyxFQUFFLFlBQVksQ0FBQyxDQUFDLENBQUM7WUFDbEcsSUFBSSxDQUFDLFNBQVMsQ0FBQyxrQkFBa0IsQ0FBQyxXQUFXLEVBQUUsR0FBRyxDQUFDLENBQUM7WUFDcEQsSUFBSSxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFDLENBQUM7U0FDbkM7SUFDTCxDQUFDO0lBRU8sZ0JBQWdCLENBQUMsS0FBZ0IsRUFBRSxTQUFrQixFQUFFLE9BQWdCO1FBQzNFLElBQUksUUFBUSxHQUFHLFdBQVcsQ0FBQyxLQUFLLEVBQUUsSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUM7UUFDL0MsSUFBSSxTQUFTLEdBQVcsdUJBQXVCLEdBQUcsS0FBSyxDQUFDO1FBRXhELElBQUksQ0FBQyxPQUFPLElBQUksS0FBSyxLQUFLLEdBQUcsQ0FBQyxJQUFJLENBQUMsQ0FBQyxPQUFPLElBQUksS0FBSyxLQUFLLEdBQUcsQ0FBQyxFQUFFO1lBQzNELFNBQVMsSUFBSSwyQkFBMkIsQ0FBQztTQUM1QztRQUVELElBQUksU0FBUztZQUFFLFNBQVMsSUFBSSwyQkFBMkIsQ0FBQztRQUV4RCxJQUFJLEtBQUssS0FBSyxHQUFHLEVBQUU7WUFDZixRQUFRO2lCQUNILFVBQVUsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDO2lCQUMzQixVQUFVLENBQUMsQ0FBQyxDQUFDLEVBQUUsRUFBRTtnQkFDZCxnSEFBZ0g7Z0JBQ2hILElBQUksS0FBSyxHQUFHLElBQUksQ0FBQyxTQUFTLENBQUMsNEJBQTRCLENBQUMsQ0FBQyxDQUFDLENBQUM7Z0JBQzNELE9BQU8sSUFBSSxDQUFDLFNBQVMsQ0FBQyxpQkFBaUIsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLEtBQUssRUFBRSxLQUFLLENBQUMsQ0FBQztZQUN0RSxDQUFDLENBQUMsQ0FBQztTQUNWO1FBRUQsSUFBSSxRQUFRLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDLE9BQU8sRUFBRSxTQUFTLENBQUMsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLENBQUM7UUFFOUUsT0FBTyxRQUFRLENBQUM7UUFFaEIsU0FBUyxXQUFXLENBQUMsS0FBZ0IsRUFBRSxNQUFNO1lBQ3pDLElBQUksT0FBTyxFQUFFO2dCQUNULElBQUksS0FBSyxLQUFLLEdBQUcsRUFBRTtvQkFDZixJQUFJLFNBQVM7d0JBQUUsT0FBTyxFQUFFLENBQUMsU0FBUyxDQUFDLE1BQU0sQ0FBQyxDQUFDO29CQUMzQyxPQUFPLEVBQUUsQ0FBQyxRQUFRLENBQUMsTUFBTSxDQUFDLENBQUM7aUJBQzlCO2dCQUNELElBQUksS0FBSyxLQUFLLEdBQUcsRUFBRTtvQkFDZixJQUFJLFNBQVM7d0JBQUUsT0FBTyxFQUFFLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxDQUFDO29CQUN6QyxPQUFPLEVBQUUsQ0FBQyxVQUFVLENBQUMsTUFBTSxDQUFDLENBQUM7aUJBQ2hDO2FBQ0o7aUJBQU07Z0JBQ0gsSUFBSSxLQUFLLEtBQUssR0FBRyxFQUFFO29CQUNmLElBQUksU0FBUzt3QkFBRSxPQUFPLEVBQUUsQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLENBQUM7b0JBQ3pDLE9BQU8sRUFBRSxDQUFDLFVBQVUsQ0FBQyxNQUFNLENBQUMsQ0FBQztpQkFDaEM7Z0JBQ0QsSUFBSSxLQUFLLEtBQUssR0FBRyxFQUFFO29CQUNmLElBQUksU0FBUzt3QkFBRSxPQUFPLEVBQUUsQ0FBQyxTQUFTLENBQUMsTUFBTSxDQUFDLENBQUM7b0JBQzNDLE9BQU8sRUFBRSxDQUFDLFFBQVEsQ0FBQyxNQUFNLENBQUMsQ0FBQztpQkFDOUI7YUFDSjtRQUNMLENBQUM7SUFFTCxDQUFDO0lBRUQsb0ZBQW9GO0lBRTdFLFlBQVksQ0FBQyxTQUFtQjtRQUNuQyxvRkFBb0Y7UUFDcEYsWUFBWSxDQUFDLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDO1FBQ3BDLElBQUksQ0FBQyxnQkFBZ0IsR0FBRyxVQUFVLENBQUMsR0FBUyxFQUFFO1lBQzFDLFNBQVMsRUFBRSxDQUFDO1FBQ2hCLENBQUMsQ0FBQyxDQUFDO0lBQ1AsQ0FBQztJQUdNLFdBQVc7UUFDZCxZQUFZLENBQUMsSUFBSSxDQUFDLGdCQUFnQixDQUFDLENBQUM7UUFDcEMsSUFBSSxDQUFDLHNCQUFzQixDQUFDLFVBQVUsRUFBRSxDQUFDLElBQUksRUFBRSxFQUFFLENBQUMsSUFBSSxDQUFDLE1BQU0sRUFBRSxDQUFDLENBQUM7UUFDakUsSUFBSSxJQUFJLENBQUMsS0FBSztZQUFFLElBQUksQ0FBQyxLQUFLLENBQUMsTUFBTSxFQUFFLENBQUM7UUFDcEMsSUFBSSxJQUFJLENBQUMsa0JBQWtCO1lBQUUsSUFBSSxDQUFDLGtCQUFrQixDQUFDLFNBQVMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxNQUFNLEVBQUUsQ0FBQztRQUM3RSxJQUFJLENBQUMsc0JBQXNCLENBQUMsdUJBQXVCLEVBQUUsQ0FBQyxTQUFTLEVBQUUsRUFBRSxDQUFDLFNBQVMsQ0FBQyxTQUFTLENBQUMsR0FBRyxDQUFDLENBQUMsTUFBTSxFQUFFLENBQUMsQ0FBQztRQUN2RyxJQUFJLElBQUksQ0FBQyxrQkFBa0I7WUFBRSxJQUFJLENBQUMsa0JBQWtCLENBQUMsU0FBUyxDQUFDLEdBQUcsQ0FBQyxDQUFDLE1BQU0sRUFBRSxDQUFDO1FBQzdFLElBQUksQ0FBQyxrQkFBa0IsRUFBRSxDQUFDO0lBQzlCLENBQUM7SUFFTyxzQkFBc0IsQ0FBQyxJQUFZLEVBQUUsUUFBa0I7UUFDM0QsSUFBSSxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUMsTUFBTSxLQUFLLENBQUMsRUFBRTtZQUN6QixJQUFJLENBQUMsSUFBSSxDQUFDLENBQUMsT0FBTyxDQUFDLE9BQU8sQ0FBQyxFQUFFLENBQUMsUUFBUSxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUM7WUFDakQsSUFBSSxDQUFDLElBQUksQ0FBQyxHQUFHLEVBQUUsQ0FBQztTQUNuQjtJQUNMLENBQUM7SUFFRCxrRkFBa0Y7SUFFMUUsY0FBYyxDQUFDLFdBQThCLEVBQUUsWUFBb0I7UUFDdkUsSUFBSSxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLE9BQU8sSUFBSSxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxPQUFPO1lBQUUsT0FBTztRQUU1RSxJQUFJLElBQUksQ0FBQyxxQkFBcUIsQ0FBQyxNQUFNLEtBQUssQ0FBQyxFQUFFO1lBQ3pDLElBQUksQ0FBQyxzQkFBc0IsQ0FBQyx1QkFBdUIsRUFBRSxDQUFDLFNBQVMsRUFBRSxFQUFFLENBQUMsU0FBUyxDQUFDLFNBQVMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxNQUFNLEVBQUUsQ0FBQyxDQUFDO1NBQzFHO1FBRUQsSUFBSSxRQUFRLEdBQVcsSUFBSSxDQUFDLGtCQUFrQixDQUFDLFdBQVcsQ0FBQyxDQUFDO1FBRTVELElBQUksQ0FBQyxTQUFTLENBQUMsaUJBQWlCLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxFQUFFLEVBQUUsUUFBUSxFQUFFLFlBQVksQ0FBQyxDQUFDO1FBQ3pFLElBQUksQ0FBQyxTQUFTLENBQUMsbUJBQW1CLEVBQUUsQ0FBQztRQUVyQyxJQUFJLENBQUMsc0JBQXNCLEVBQUUsQ0FBQztRQUU5QixJQUFJLElBQUksQ0FBQyxTQUFTLENBQUMsV0FBVyxLQUFLLENBQUM7WUFBRSxJQUFJLENBQUMsTUFBTSxDQUFDLFdBQVcsQ0FBQyxDQUFDO1FBRS9ELElBQUksQ0FBQyxxQkFBcUIsQ0FBQyxPQUFPLENBQUMsQ0FBQyxtQkFBbUIsRUFBRSxLQUFLLEVBQUUsRUFBRTtZQUM5RCxJQUFJLENBQUMsU0FBUyxDQUFDLDBCQUEwQixDQUFDLG1CQUFtQixDQUFDLENBQUM7WUFDL0QsaUVBQWlFO1lBQ2pFLElBQUksSUFBSSxDQUFDLFNBQVMsQ0FBQyxXQUFXLEtBQUssQ0FBQyxFQUFFO2dCQUNsQyxJQUFJLFFBQVEsR0FBRyxLQUFLLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsUUFBUSxDQUFDO2dCQUN0RixJQUFJLENBQUMsY0FBYyxDQUNmLG1CQUFtQixFQUNuQixFQUFFLFdBQVcsRUFBRSxJQUFJLENBQUMsU0FBUyxDQUFDLFdBQVcsRUFBRSxVQUFVLEVBQUUsUUFBUSxFQUFFLEVBQ2pFLEVBQUUsUUFBUSxFQUFFLElBQUksQ0FBQyxTQUFTLENBQUMsUUFBUSxFQUFFLFFBQVEsRUFBRSxRQUFRLEVBQUUsQ0FDNUQsQ0FBQzthQUNMO1FBQ0wsQ0FBQyxDQUFDLENBQUM7SUFDUCxDQUFDO0lBRU8sc0JBQXNCO1FBQzFCLElBQUksQ0FBQyxxQkFBcUIsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxxQkFBcUIsRUFBRSxDQUFDLENBQUM7UUFFeEUsa0JBQWtCO1FBQ2xCLElBQUksSUFBSSxDQUFDLFNBQVMsQ0FBQyxlQUFlLEVBQUU7WUFDaEMsSUFBSSxDQUFDLHFCQUFxQixDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLHFCQUFxQixDQUFDLDJCQUEyQixDQUFDLENBQUMsQ0FBQztTQUN0RztJQUNMLENBQUM7SUFFTyxrQkFBa0IsQ0FBQyxXQUE4QjtRQUNyRCxPQUFPLENBQUMsV0FBVyxLQUFLLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLFNBQVMsRUFBRSxHQUFHLElBQUksQ0FBQyxDQUFDLENBQUMsWUFBWSxFQUFFLEdBQUcsSUFBSSxDQUFDLENBQUMsQ0FBQyxJQUFJLEVBQUUsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLEtBQUssR0FBRyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsTUFBTSxHQUFHLENBQUMsQ0FBQyxDQUFDO0lBQ3ZJLENBQUM7SUFFTyxNQUFNLENBQUMsV0FBOEI7UUFDekMsSUFBSSxRQUFRLEdBQVcsSUFBSSxDQUFDLGtCQUFrQixDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsUUFBUSxFQUFFLFdBQVcsQ0FBQyxDQUFDO1FBRXJGLElBQUksUUFBUSxLQUFLLElBQUksQ0FBQyxRQUFRLENBQUMsTUFBTTtZQUFFLE9BQU87UUFFOUMsMkVBQTJFO1FBQzNFLElBQUksQ0FBQyxJQUFJLEdBQUcsSUFBSSxDQUFDLFFBQVEsQ0FBQyxLQUFLLENBQUMsQ0FBQyxFQUFFLFFBQVEsQ0FBQyxDQUFDO1FBQzdDLElBQUksS0FBSyxHQUFXLElBQUksQ0FBQyxTQUFTLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxJQUFJLEVBQUUsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDO1FBRXBFLDJDQUEyQztRQUMzQyxJQUFJLElBQUksQ0FBQyxhQUFhLEtBQUssTUFBTTtZQUFFLElBQUksQ0FBQyxjQUFjLENBQUMsV0FBVyxDQUFDLENBQUM7UUFDcEUsSUFBSSxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxDQUFDO1FBRTNCLDRHQUE0RztRQUM1RyxJQUFJLENBQUMsU0FBUyxDQUFDLHFCQUFxQixDQUFDLEtBQUssQ0FBQyxXQUFXLENBQUMsQ0FBQztRQUN4RCxJQUFJLENBQUMsU0FBUyxDQUFDLG1CQUFtQixFQUFFLENBQUM7SUFDekMsQ0FBQztJQUVELDREQUE0RDtJQUNwRCxrQkFBa0IsQ0FBQyxTQUFrQixFQUFFLFdBQThCO1FBQ3pFLElBQUksQ0FBQyxTQUFTLElBQUksQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLFFBQVE7WUFBRSxPQUFPLElBQUksQ0FBQyxRQUFRLENBQUMsTUFBTSxDQUFDO1FBRWxFLElBQUksTUFBTSxHQUFXLElBQUksQ0FBQyxhQUFhLEtBQUssS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsWUFBWSxFQUFFLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztRQUNwRixJQUFJLFFBQVEsR0FBVyxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLEdBQUcsTUFBTSxDQUFDO1FBQy9FLG9GQUFvRjtRQUNwRixJQUFJLFlBQVksR0FBVyxJQUFJLENBQUMsU0FBUyxDQUFDLHFCQUFxQixFQUFFLENBQUMsTUFBTSxDQUFDO1FBQ3pFLElBQUksUUFBUSxHQUFXLElBQUksQ0FBQyxLQUFLLENBQUMsUUFBUSxHQUFHLFlBQVksQ0FBQyxDQUFDO1FBRTNELElBQUksV0FBVyxLQUFLLFFBQVE7WUFBRSxRQUFRLElBQUksQ0FBQyxDQUFDO1FBRTVDLE9BQU8sSUFBSSxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLE1BQU0sRUFBRSxRQUFRLENBQUMsQ0FBQztJQUNwRCxDQUFDO0lBRU8sY0FBYyxDQUFDLFVBQWUsRUFBRSxnQkFBNkQsRUFBRSxjQUF1QztRQUMxSSxJQUFJLFNBQVMsR0FBVyxDQUFDLEVBQUUsZ0JBQWdCLEdBQUcsSUFBSSxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDO1FBQ3ZFLElBQUksSUFBSSxDQUFDLGFBQWEsS0FBSyxLQUFLO1lBQUUsU0FBUyxHQUFHLElBQUksQ0FBQyxDQUFDLENBQUMsWUFBWSxFQUFFLEdBQUcsSUFBSSxDQUFDLENBQUMsQ0FBQyxJQUFJLEVBQUUsR0FBRyxJQUFJLENBQUMsQ0FBQyxDQUFDLFNBQVMsRUFBRSxHQUFHLENBQUMsQ0FBQztRQUU3RyxJQUFJLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsRUFBRSxNQUFNLEVBQUUsRUFBRTtZQUM1QixJQUFJLGNBQW1CLEVBQUUsT0FBZSxDQUFDO1lBQ3pDLGNBQWMsR0FBRyxVQUFVLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQztpQkFDcEMsSUFBSSxDQUFDLE9BQU8sRUFBRSwwQkFBMEIsR0FBRyxNQUFNLENBQUM7aUJBQ2xELElBQUksQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLHFCQUFxQixDQUFDLGdCQUFnQixDQUFDLE1BQU0sRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUM7WUFFcEYsSUFBSSxjQUFjLENBQUMsUUFBUSxFQUFFO2dCQUN6QixjQUFjLENBQUMsS0FBSyxDQUFDLFdBQVcsRUFBRSxnQkFBZ0IsQ0FBQyxXQUFXLEdBQUcsSUFBSSxDQUFDLENBQUM7YUFDMUU7aUJBQU07Z0JBQ0gsSUFBSSxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsUUFBUTtvQkFBRSxjQUFjLENBQUMsS0FBSyxDQUFDLFdBQVcsRUFBRSxnQkFBZ0IsQ0FBQyxVQUFVLEdBQUcsSUFBSSxDQUFDLENBQUM7YUFDakc7WUFFRCxJQUFJLElBQUksQ0FBQyxhQUFhLEtBQUssS0FBSyxFQUFFO2dCQUM5QixJQUFJLGFBQWEsR0FBRyxJQUFJLENBQUMsU0FBUyxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxNQUFNLEdBQUcsTUFBTSxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDO2dCQUN4RixPQUFPLEdBQUcsU0FBUyxHQUFHLElBQUksQ0FBQyxDQUFDLENBQUMsSUFBSSxFQUFFLEdBQUcsYUFBYSxDQUFDO2FBQ3ZEO2lCQUFNO2dCQUNILE9BQU8sR0FBRyxJQUFJLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDO2FBQ3ZEO1lBRUQsSUFBSSxDQUFDLFNBQVMsQ0FBQyxvQkFBb0IsQ0FBQyxjQUFjLEVBQUUsT0FBTyxFQUFFLE1BQU0sQ0FBQyxNQUFNLENBQUMsY0FBYyxFQUFFLEVBQUUsTUFBTSxFQUFFLE1BQU0sS0FBSyxJQUFJLENBQUMsSUFBSSxDQUFDLE1BQU0sR0FBRyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUM7UUFDN0ksQ0FBQyxDQUFDLENBQUM7SUFDUCxDQUFDO0lBRUQsMkZBQTJGO0lBRTNGOzs7Ozs7Ozs7T0FTRztJQUVJLGdCQUFnQixDQUFDLEtBQVUsRUFBRSxPQUFhO1FBQzlDLElBQUksWUFBWSxHQUFZLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsS0FBSyxLQUFLLElBQUksQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxLQUFLLE1BQU0sSUFBSSxJQUFJLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxLQUFLLFFBQVEsQ0FBQyxDQUFDLENBQUM7UUFDN0gsSUFBSSxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDLE9BQU87WUFBRSxPQUFPO1FBRXpDLElBQUksT0FBWSxDQUFDO1FBQ2pCLEtBQUssQ0FBQyxFQUFFLENBQUMsV0FBVyxFQUFFLENBQUMsQ0FBQyxFQUFFLEtBQUssRUFBRSxFQUFFO1lBQy9CLElBQUksR0FBRyxHQUFXLFlBQVksQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLE9BQU8sQ0FBQyxTQUFTLENBQUMsSUFBSSxFQUFFLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQztZQUNsSCxJQUFJLElBQUksR0FBVyxZQUFZLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxPQUFPLENBQUMsU0FBUyxDQUFDLElBQUksRUFBRSxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsR0FBRyxFQUFFLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUM7WUFDcEgsSUFBSSxZQUFZLEdBQVEsQ0FBQyxZQUFZLElBQUksT0FBTyxDQUFDLFlBQVksQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsWUFBWSxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDO1lBQ3ZHLE9BQU8sR0FBRyxZQUFZLENBQUMsTUFBTSxDQUFDLHFCQUFxQixDQUFDLENBQUM7WUFFckQsb0ZBQW9GO1lBQ3BGLElBQUksT0FBTyxDQUFDLEtBQUssRUFBRSxFQUFFO2dCQUNqQixPQUFPLEdBQUcsWUFBWSxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsQ0FBQyxJQUFJLENBQUMsT0FBTyxFQUFFLG9CQUFvQixDQUFDLENBQUM7Z0JBQ3pFLE9BQU8sQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLENBQUMsSUFBSSxDQUFDLE9BQU8sRUFBRSwwQkFBMEIsQ0FBQyxDQUFDO2dCQUNoRSxPQUFPLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxDQUFDLElBQUksQ0FBQyxPQUFPLEVBQUUsMEJBQTBCLENBQUMsQ0FBQzthQUNuRTtZQUVELElBQUksS0FBYSxDQUFDO1lBQ2xCLElBQUksS0FBc0IsQ0FBQztZQUMzQixvREFBb0Q7WUFDcEQsSUFBSSxLQUFhLENBQUM7WUFFbEIsSUFBSSxJQUFJLENBQUMsU0FBUyxJQUFJLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsS0FBSyxLQUFLLElBQUksSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsS0FBSyxPQUFPLENBQUMsRUFBRTtnQkFDbEYsS0FBSyxHQUFHLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxJQUFJLEVBQUUsR0FBRyxDQUFDLENBQUM7Z0JBQ3BDLEtBQUssR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQztnQkFDakIsT0FBTyxDQUFDLFFBQVEsQ0FBQyxFQUFFLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsRUFBRSxJQUFJLEVBQUUsT0FBTyxDQUFDLFdBQVcsRUFBRSxPQUFPLENBQUMsV0FBVyxDQUFDLENBQUM7Z0JBQ3JHLEVBQUUsQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxTQUFTLEVBQUUsS0FBSyxDQUFDLENBQUM7YUFDOUQ7aUJBQU0sSUFBSSxJQUFJLENBQUMsU0FBUyxJQUFJLElBQUksQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLEtBQUssUUFBUSxFQUFFO2dCQUN6RCxLQUFLLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsSUFBSSxFQUFFLEdBQUcsQ0FBQyxDQUFDO2dCQUMvQixLQUFLLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQztnQkFDWixFQUFFLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsU0FBUyxFQUFFLEtBQUssQ0FBQyxDQUFDO2FBQzlEO2lCQUFNLElBQUksSUFBSSxDQUFDLGFBQWEsS0FBSyxLQUFLLEVBQUU7Z0JBQ3JDLEtBQUssR0FBRyxPQUFPLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUM7Z0JBQzdCLEtBQUssR0FBRyxJQUFJLENBQUMsU0FBUyxDQUFDLDRCQUE0QixDQUFDLENBQUMsQ0FBQyxLQUFLLElBQUksQ0FBQyxDQUFDLENBQUM7Z0JBQ2xFLEtBQUssR0FBRyxLQUFLLENBQUMsUUFBUSxFQUFFLEdBQUcsR0FBRyxHQUFHLElBQUksQ0FBQyxVQUFVLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQztnQkFDNUQsRUFBRSxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLFNBQVMsRUFBRSxLQUFLLENBQUMsQ0FBQzthQUM5RDtpQkFBTSxJQUFJLElBQUksQ0FBQyxhQUFhLEtBQUssTUFBTSxFQUFFO2dCQUN0QyxLQUFLLEdBQUcsT0FBTyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDO2dCQUM3QixLQUFLLEdBQUcsT0FBTyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsS0FBSyxDQUFDO2dCQUNwQyxLQUFLLEdBQUcsS0FBSyxDQUFDLFFBQVEsRUFBRSxHQUFHLEdBQUcsR0FBRyxJQUFJLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQzthQUM1RDtpQkFBTSxJQUFJLElBQUksQ0FBQyxhQUFhLEtBQUssS0FBSyxFQUFFO2dCQUNyQyxLQUFLLElBQUksQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLEdBQUcsT0FBTyxDQUFDLFVBQVUsQ0FBQyxNQUFNLEVBQUUsQ0FBQyxFQUFFLEVBQUU7b0JBQ2hELElBQUksQ0FBQyxDQUFDLFVBQVUsQ0FBQyxHQUFHLElBQUksT0FBTyxDQUFDLFVBQVUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLEVBQUU7d0JBQzlDLEtBQUssR0FBRyxPQUFPLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQzt3QkFDbkMsS0FBSyxHQUFHLE9BQU8sQ0FBQyxVQUFVLEdBQUcsSUFBSSxHQUFHLE9BQU8sQ0FBQyxVQUFVLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDO3dCQUNoRSxLQUFLLEdBQUcsT0FBTyxDQUFDLFVBQVUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUM7d0JBQ3BDLE1BQU07cUJBQ1Q7aUJBQ0o7YUFDSjtZQUVELEtBQUssR0FBRyxJQUFJLENBQUMsU0FBUyxDQUFDLFlBQVksQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLE9BQU8sQ0FBQyxNQUFNLEVBQUUsS0FBSyxDQUFDLENBQUM7WUFDdkUsT0FBTyxDQUFDLE1BQU0sQ0FBQywyQkFBMkIsQ0FBQyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsV0FBVyxFQUFFLENBQUMsQ0FBQztZQUN0RSxJQUFJLElBQUksQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLEtBQUssUUFBUTtnQkFBRSxPQUFPLENBQUMsTUFBTSxDQUFDLDJCQUEyQixDQUFDLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFDLEtBQUssQ0FBQyxhQUFhLEVBQUUsTUFBTSxDQUFDLENBQUM7WUFFekgsT0FBTyxDQUFDLElBQUksQ0FBQyxPQUFPLEVBQUUsSUFBSSxDQUFDLFNBQVMsQ0FBQyxRQUFRLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxFQUFFLEVBQUUscUJBQXFCLENBQUMsRUFBRSxJQUFJLENBQUMsQ0FBQyxDQUFDO1lBQy9GLE9BQU8sQ0FBQyxLQUFLLENBQUMsU0FBUyxFQUFFLE9BQU8sQ0FBQyxDQUFDO1lBQ2xDLE9BQU8sQ0FBQyxLQUFLLENBQUMsU0FBUyxFQUFFLENBQUMsQ0FBQyxDQUFDO1lBQzVCLE9BQU8sQ0FBQyxLQUFLLENBQUMsU0FBUyxFQUFFLEdBQUcsQ0FBQyxDQUFDO1lBRTlCLElBQUksSUFBSSxDQUFDLGFBQWEsS0FBSyxNQUFNLEVBQUU7Z0JBQy9CLE9BQU8sQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxPQUFPLENBQUMsTUFBTSxFQUFFLENBQUMsQ0FBQyxFQUFFLElBQUksQ0FBQyxDQUFDO2FBQzVEO1lBRUQsSUFBSSxPQUFPLElBQUksT0FBTyxDQUFDLFNBQVMsSUFBSSxPQUFPLENBQUMsU0FBUyxDQUFDLFNBQVM7Z0JBQUUsT0FBTyxDQUFDLFNBQVMsQ0FBQyxTQUFTLENBQUMsS0FBSyxDQUFDLENBQUM7WUFFcEcsOEVBQThFO1lBQzlFLElBQUksSUFBSSxDQUFDLGFBQWEsS0FBSyxLQUFLLEVBQUU7Z0JBQzlCLElBQUksQ0FBQyxTQUFTLENBQUMsVUFBVSxDQUFDLGVBQWUsQ0FBQyxPQUFPLEVBQUUsRUFBRSxHQUFHLEVBQUUsRUFBRSxDQUFDLEtBQUssQ0FBQyxNQUFNLEVBQUUsSUFBSSxFQUFFLEVBQUUsQ0FBQyxLQUFLLENBQUMsTUFBTSxFQUFFLENBQUMsQ0FBQzthQUN2RztpQkFBTTtnQkFDSCxJQUFJLEtBQUssSUFBSSxLQUFLLEtBQUssQ0FBQztvQkFBRSxJQUFJLENBQUMsU0FBUyxDQUFDLFVBQVUsQ0FBQyxlQUFlLENBQUMsT0FBTyxFQUFFLEVBQUUsR0FBRyxFQUFFLEdBQUcsRUFBRSxJQUFJLEVBQUUsSUFBSSxFQUFFLENBQUMsQ0FBQzs7b0JBQ2xHLE9BQU8sQ0FBQyxNQUFNLEVBQUUsQ0FBQzthQUN6QjtRQUNMLENBQUMsQ0FBQyxDQUFDO1FBRUgsS0FBSyxDQUFDLEVBQUUsQ0FBQyxXQUFXLEVBQUUsQ0FBQyxDQUFDLEVBQUUsRUFBRTtZQUN4QixJQUFJLEdBQUcsR0FBVyxZQUFZLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxPQUFPLENBQUMsU0FBUyxDQUFDLElBQUksRUFBRSxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsR0FBRyxFQUFFLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUM7WUFDbEgsSUFBSSxJQUFJLEdBQVcsWUFBWSxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsT0FBTyxDQUFDLFNBQVMsQ0FBQyxJQUFJLEVBQUUsQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLEdBQUcsRUFBRSxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDO1lBQ3BILHFDQUFxQztZQUNyQyxJQUFJLENBQUMsU0FBUyxDQUFDLFVBQVUsQ0FBQyxlQUFlLENBQUMsT0FBTyxFQUFFLEVBQUUsR0FBRyxFQUFFLEdBQUcsRUFBRSxJQUFJLEVBQUUsSUFBSSxFQUFFLENBQUMsQ0FBQztRQUNqRixDQUFDLENBQUMsQ0FBQztRQUVILEtBQUssQ0FBQyxFQUFFLENBQUMsVUFBVSxFQUFFLENBQUMsQ0FBQyxFQUFFLEtBQUssRUFBRSxFQUFFO1lBQzlCLElBQUksSUFBSSxDQUFDLFNBQVMsSUFBSSxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLEtBQUssS0FBSyxJQUFJLElBQUksQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLEtBQUssT0FBTyxJQUFJLElBQUksQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLEtBQUssUUFBUSxJQUFJLElBQUksQ0FBQyxhQUFhLEtBQUssS0FBSyxDQUFDLEVBQUU7Z0JBQ3BKLElBQUksSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsS0FBSyxLQUFLLElBQUksSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsS0FBSyxPQUFPLEVBQUU7b0JBQzlELElBQUksUUFBUSxHQUFRLEVBQUUsQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDO29CQUN2RCxJQUFJLENBQUMsUUFBUSxDQUFDLE9BQU8sQ0FBQyxTQUFTLENBQUMsRUFBRTt3QkFDOUIsT0FBTyxDQUFDLFFBQVEsQ0FBQyxRQUFRLEVBQUUsS0FBSyxFQUFFLE9BQU8sQ0FBQyxXQUFXLEVBQUUsT0FBTyxDQUFDLFdBQVcsQ0FBQyxDQUFDO3FCQUMvRTtpQkFDSjtnQkFDRCxFQUFFLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsU0FBUyxFQUFFLEdBQUcsQ0FBQyxDQUFDO2FBQzVEO1lBQ0Qsb0NBQW9DO1lBQ3BDLCtCQUErQjtZQUMvQixPQUFPLENBQUMsTUFBTSxFQUFFLENBQUM7WUFFakIsSUFBSSxJQUFJLENBQUMsYUFBYSxLQUFLLE1BQU0sRUFBRTtnQkFDL0IsT0FBTyxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLE9BQU8sQ0FBQyxNQUFNLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQzthQUN0RDtZQUNELElBQUksT0FBTyxJQUFJLE9BQU8sQ0FBQyxTQUFTLElBQUksT0FBTyxDQUFDLFNBQVMsQ0FBQyxRQUFRO2dCQUFFLE9BQU8sQ0FBQyxTQUFTLENBQUMsUUFBUSxFQUFFLENBQUM7UUFDakcsQ0FBQyxDQUFDLENBQUM7UUFFSCxLQUFLLENBQUMsRUFBRSxDQUFDLE9BQU8sRUFBRSxDQUFDLENBQUMsRUFBRSxLQUFLLEVBQUUsRUFBRTtZQUMzQixJQUFJLElBQUksQ0FBQyxTQUFTLElBQUksQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxLQUFLLEtBQUssSUFBSSxJQUFJLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxLQUFLLE9BQU8sQ0FBQyxFQUFFO2dCQUNsRixJQUFJLFFBQVEsR0FBUSxFQUFFLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQztnQkFDdkQsSUFBSSxPQUFPLEdBQVksUUFBUSxDQUFDLE9BQU8sQ0FBQyxTQUFTLENBQUMsQ0FBQztnQkFDbkQsT0FBTyxDQUFDLFFBQVEsQ0FBQyxRQUFRLEVBQUUsQ0FBQyxPQUFPLEVBQUUsT0FBTyxDQUFDLFdBQVcsRUFBRSxPQUFPLENBQUMsV0FBVyxDQUFDLENBQUM7Z0JBQy9FLFFBQVEsQ0FBQyxPQUFPLENBQUMsU0FBUyxFQUFFLENBQUMsT0FBTyxDQUFDLENBQUM7YUFDekM7UUFDTCxDQUFDLENBQUMsQ0FBQztJQUNQLENBQUM7SUFFRCw2RUFBNkU7SUFFdEUsUUFBUSxDQUFDLE1BQWdCLEVBQUUsTUFBdUIsRUFBRSxVQUFrQixFQUFFLFVBQWtCO1FBQzdGLElBQUksQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsT0FBTztZQUFFLE9BQU87UUFFOUMsSUFBSSxXQUFXLEdBQWUsSUFBSSxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDO1FBRXZELElBQUksY0FBYyxHQUFRLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDO2FBQzFELElBQUksQ0FBQyxPQUFPLEVBQUUsMEJBQTBCLEdBQUcsTUFBTSxHQUFHLEtBQUssR0FBRyxNQUFNLENBQUMsRUFBRSxDQUFDLENBQUM7UUFFNUUsSUFBSSxTQUFTLEdBQVcsSUFBSSxDQUFDLFNBQVMsQ0FBQyxZQUFZLENBQUMsV0FBVyxDQUFDLE1BQU0sRUFBRSxNQUFNLENBQUMsS0FBSyxDQUFDLENBQUM7UUFFdEYsY0FBYzthQUNULE1BQU0sQ0FBQyxLQUFLLENBQUM7YUFDYixJQUFJLENBQUMsT0FBTyxFQUFFLDRCQUE0QixDQUFDO2FBQzNDLElBQUksQ0FBQyxTQUFTLENBQUM7YUFDZixJQUFJLENBQUMsT0FBTyxFQUFFLElBQUksQ0FBQyxTQUFTLENBQUMsUUFBUSxDQUFDLFdBQVcsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDO1FBRS9ELElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxjQUFjLEVBQUUsTUFBTSxDQUFDLEdBQUcsSUFBSSxNQUFNLENBQUMsS0FBSyxFQUFFLFVBQVUsRUFBRSxVQUFVLENBQUMsQ0FBQztRQUUzRixPQUFPLGNBQWMsQ0FBQztJQUMxQixDQUFDO0lBRU0saUJBQWlCLENBQUMsQ0FBa0IsRUFBRSxDQUFrQixFQUFFLFdBQXFCO1FBQ2xGLE9BQU8sWUFBWSxHQUFHLENBQUMsR0FBRyxDQUFDLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUMsQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQztJQUNoRyxDQUFDO0lBRU0sUUFBUSxDQUFDLEtBQXNCLEVBQUUsR0FBVztRQUMvQyxPQUFPLHlCQUF5QixHQUFHLEtBQUssR0FBRyxLQUFLLEdBQUcsR0FBRyxDQUFDO0lBQzNELENBQUM7SUFFTSxXQUFXLENBQUMsS0FBVSxFQUFFLE9BQWU7UUFDMUMsT0FBTyxJQUFJLENBQUMsU0FBUyxDQUFDLE9BQU8sQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUM7SUFDcEQsQ0FBQztJQUVPLGtCQUFrQjtRQUN0QixJQUFJLENBQUMsa0JBQWtCLEdBQUcsRUFBRSxDQUFDLE1BQU0sQ0FBQyxHQUFHLEdBQUcsSUFBSSxDQUFDLE1BQU0sQ0FBQyxFQUFFLEdBQUcsY0FBYyxHQUFHLGtDQUFrQyxDQUFDLENBQUM7SUFDcEgsQ0FBQztJQUVEOzs7T0FHRztJQUNILGlIQUFpSDtJQUMxRyxvQkFBb0IsQ0FBQyxTQUFTLEVBQUUsVUFBa0IsRUFBRSxVQUFrQyxFQUFFO1FBQzNGLElBQUksS0FBSyxHQUFpQywrQkFBK0IsQ0FBQztRQUMxRSxJQUFJLGFBQWEsR0FBZ0MsSUFBSSxDQUFDLFNBQVMsQ0FBQyx1QkFBdUIsQ0FBQyxJQUFJLENBQUMsTUFBTSxFQUFFLE9BQU8sQ0FBQyxDQUFDO1FBQzlHLElBQUksT0FBTyxHQUFXLE9BQU8sQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztRQUM1RCxJQUFJLE1BQU0sR0FBVyxPQUFPLEdBQUcsQ0FBQyxDQUFDO1FBRWpDLElBQUksYUFBYSxLQUFLLFFBQVEsRUFBRTtZQUM1QixJQUFJLE1BQU0sR0FBRyxDQUFDLEtBQUssRUFBRSxRQUFRLENBQUMsQ0FBQztZQUMvQixNQUFNLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxFQUFFO2dCQUNqQixJQUFJLElBQUksQ0FBQyxTQUFTLENBQUMsY0FBYyxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FBQyxLQUFLLEVBQUUsVUFBVSxFQUFFLElBQUksQ0FBQyxNQUFNLEVBQUUsT0FBTyxDQUFDLEVBQUU7b0JBQ25GLGFBQWEsR0FBRyxLQUFLLENBQUMsR0FBRyxDQUFDLENBQUMsUUFBUSxDQUFDO2lCQUN2QztZQUNMLENBQUMsQ0FBQyxDQUFDO1NBQ047YUFBTSxJQUFJLElBQUksQ0FBQyxTQUFTLENBQUMsY0FBYyxDQUFDLEtBQUssQ0FBQyxhQUFhLENBQUMsQ0FBQyxLQUFLLEVBQUUsVUFBVSxFQUFFLElBQUksQ0FBQyxNQUFNLEVBQUUsT0FBTyxDQUFDLEVBQUU7WUFDcEcsYUFBYSxHQUFHLEtBQUssQ0FBQyxhQUFhLENBQUMsQ0FBQyxRQUFRLENBQUM7U0FDakQ7UUFFRCxJQUFJLElBQUksR0FBVyxFQUFFLENBQUM7UUFDdEIsSUFBSSxhQUFhLEtBQUssUUFBUSxFQUFFO1lBQzVCLElBQUksR0FBRyxLQUFLLENBQUMsYUFBYSxDQUFDLENBQUMsT0FBTyxDQUFDO1NBQ3ZDO2FBQU07WUFDSCxJQUFJLElBQUksR0FBVyxhQUFhLEtBQUssS0FBSyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQztZQUMzRCxJQUFJLElBQUksQ0FBQyxhQUFhLEtBQUssS0FBSyxJQUFJLElBQUksQ0FBQyxTQUFTLENBQUMsbUJBQW1CLENBQUMsYUFBYSxFQUFFLE9BQU8sQ0FBQztnQkFBRSxNQUFNLElBQUksT0FBTyxDQUFDLFVBQVUsQ0FBQyxNQUFNLENBQUM7WUFDcEksSUFBSSxHQUFHLE9BQU8sR0FBRyxLQUFLLENBQUMsYUFBYSxDQUFDLENBQUMsT0FBTyxHQUFHLElBQUksR0FBRyxNQUFNLENBQUMsUUFBUSxFQUFFLEdBQUcsS0FBSyxDQUFDO1NBQ3BGO1FBRUQsSUFBSSxJQUFJLEdBQVcsQ0FBQyxPQUFPLENBQUMsV0FBVyxJQUFJLE9BQU8sQ0FBQyxXQUFXLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLGNBQWMsR0FBRyxPQUFPLEdBQUcsQ0FBQyxHQUFHLEtBQUssQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDO1FBRWxILElBQUksU0FBUyxHQUFXLElBQUksQ0FBQyxhQUFhLEtBQUssTUFBTSxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsaUJBQWlCLENBQUMsSUFBSSxFQUFFLElBQUksRUFBRSxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsYUFBYSxHQUFHLElBQUksR0FBRyxHQUFHLENBQUM7UUFDOUgsU0FBUyxDQUFDLEtBQUssQ0FBQyxXQUFXLEVBQUUsU0FBUyxDQUFDLENBQUM7SUFDNUMsQ0FBQztJQUVPLGlCQUFpQixDQUFDLGNBQW1CLEVBQUUsT0FBZSxFQUFFLFVBQWtCLEVBQUUsVUFBa0I7UUFDbEcsSUFBSSxlQUFlLEdBQTZCO1lBQzVDLENBQUMsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO1lBQzFDLENBQUMsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO1NBQzVDLENBQUM7UUFDRixJQUFJLENBQUMsR0FBVyxDQUFDLE9BQU8sVUFBVSxLQUFLLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxVQUFVLENBQUMsQ0FBQyxDQUFDLGVBQWUsQ0FBQyxDQUFDLENBQUM7UUFDbEYsSUFBSSxDQUFDLEdBQVcsQ0FBQyxPQUFPLFVBQVUsS0FBSyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQyxlQUFlLENBQUMsQ0FBQyxDQUFDO1FBRWxGLGtEQUFrRDtRQUNsRCxhQUFhO1FBQ2IsSUFBSTtRQUVKLElBQUksSUFBSSxDQUFDLEtBQUs7WUFBRSxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsS0FBSyxHQUFHLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDO1FBRTFDLElBQUksT0FBTyxJQUFJLENBQUMsT0FBTyxHQUFHLElBQUksQ0FBQyxTQUFTLElBQUksT0FBTyxHQUFHLElBQUksQ0FBQyxTQUFTLENBQUMsRUFBRTtZQUNuRSxjQUFjLENBQUMsS0FBSyxDQUFDLFNBQVMsRUFBRSxNQUFNLENBQUMsQ0FBQztTQUMzQztRQUVELElBQUksQ0FBQyxtQkFBbUIsQ0FBQyxjQUFjLEVBQUUsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDO0lBQ25ELENBQUM7SUFFTyxtQkFBbUIsQ0FBQyxjQUFtQixFQUFFLFVBQWtCLEVBQUUsVUFBa0I7UUFDbkYsSUFBSSxNQUFNLEdBQVcsRUFBRSxDQUFDO1FBQ3hCLElBQUksVUFBVSxHQUE4QixJQUFJLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDO1FBRTNFLDRFQUE0RTtRQUM1RSxJQUFJLFVBQVUsQ0FBQyxjQUFjLENBQUMsVUFBVSxDQUFDLElBQUksVUFBVSxDQUFDLFFBQVEsRUFBRTtZQUM5RCxNQUFNLEdBQUcsVUFBVSxHQUFHLFVBQVUsQ0FBQyxRQUFRLEdBQUcsTUFBTSxDQUFDO1NBQ3REO1FBRUQsY0FBYzthQUNULEtBQUssQ0FBQyxXQUFXLEVBQUUsSUFBSSxDQUFDLGlCQUFpQixDQUFDLFVBQVUsRUFBRSxVQUFVLENBQUMsR0FBRyxNQUFNLENBQUMsQ0FBQztRQUVqRixJQUFJLElBQUksQ0FBQyxLQUFLO1lBQUUsY0FBYyxDQUFDLEtBQUssQ0FBQyxZQUFZLEVBQUUsT0FBTyxDQUFDLENBQUM7SUFDaEUsQ0FBQztDQUNKIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0ICogYXMgZDMgZnJvbSAnZDMnO1xyXG5pbXBvcnQgeyBLZENoYXJ0c1N2YyB9IGZyb20gJy4va2QtYW5ndWxhci1jaGFydHMtc3ZjJztcclxuaW1wb3J0IHtcclxuICAgIElDaGFydENvbmZpZyxcclxuICAgIElEM0RhdGFEYXRhLFxyXG4gICAgSUQzRGF0YVJhbmdlLFxyXG4gICAgSUQzWURhdGEsXHJcbiAgICBJWUF4aXNDb25maWcsXHJcbiAgICBJWEF4aXNDb25maWcsXHJcbiAgICBJTWF4TWluSW50ZXJ2YWwsXHJcbiAgICBJTGVnZW5kRGF0YSxcclxuICAgIElEYXRhTGFiZWwsXHJcbiAgICBJQXhpc0xhYmVsQm9vbGVhbkNoZWNrcyxcclxuICAgIElMYWJlbFRleHRWZXJ0aWNhbEFsaWduU3RvcmUsXHJcbiAgICBJU2V0VGlja1ZhbHVlUmV0dXJuLFxyXG4gICAgSUF4aXNUcmFuc2Zvcm1Qb3MsXHJcbiAgICBJWEluZm8sXHJcbiAgICBJWUF4aXNMYWJlbFJhbmdlXHJcbn0gZnJvbSAnLi9rZC1hbmd1bGFyLWNoYXJ0cy1pbnRlcmZhY2UnO1xyXG5pbXBvcnQgeyBMQUJFTF9URVhUX1ZFUlRJQ0FMX0FMSUdOX1NUT1JFLCBUT09MVElQX0RFRkFVTFRfU1RZTEUgfSBmcm9tICcuL2tkLWFuZ3VsYXItY2hhcnRzLWNvbmZpZyc7XHJcbmltcG9ydCB7IEtkRG9tRWxlbVN2YyB9IGZyb20gJy4uL2tkLWNvbW1vbi9pbmRleCc7XHJcblxyXG5leHBvcnQgY2xhc3MgS2RDaGFydEJhc2VDbGFzcyB7XHJcblxyXG4gICAgLy8gQ2hhcnQgU2V0dGluZ1xyXG4gICAgcHVibGljIGlzUnRsOiBib29sZWFuID0gZmFsc2U7XHJcbiAgICBwdWJsaWMgY29uZmlnOiBJQ2hhcnRDb25maWcgPSB7fTtcclxuICAgIHB1YmxpYyBkYXRhOiBBcnJheTxJRDNEYXRhRGF0YT4gPSBbXTtcclxuICAgIHB1YmxpYyBpbml0RGF0YTogQXJyYXk8SUQzRGF0YURhdGE+ID0gW107XHJcbiAgICBwdWJsaWMgY2hhcnRUeXBlOiBBcnJheTxzdHJpbmc+O1xyXG4gICAgcHVibGljIGNoYXJ0Q2F0ZWdvcnk6ICdwaWUnIHwgJ2JhcicgfCAnY29sdW1uJyB8ICdsaW5lJyB8ICdhcmVhJyB8ICdkb3QnIHwgJ3NwbGluZScgfCAnbWFwJztcclxuICAgIC8qKlxyXG4gICAgICogbWF4IGFuZCBtaW4gdmFsdWUgb2YgYWNyb3NzIGFsbCBzZXJpZXNcclxuICAgICAqIHR5cGUge0lEM0RhdGFSYW5nZX1cclxuICAgICAqL1xyXG4gICAgcHVibGljIGRhdGFSYW5nZTogSUQzRGF0YVJhbmdlO1xyXG4gICAgcHVibGljIHN2ZzogYW55O1xyXG4gICAgLy8gdGhpcyBpcyBjaGFydC1jb250YWluZXIgKGNsYXNzTmFtZSlcclxuICAgIHB1YmxpYyBzdmdQYXJlbnQ6IGFueTtcclxuICAgIC8vIHRoaXMgaXMgdGhlIGltbWVkaWF0ZSBkaXYgcGFyZW50IG9mIHN2Z1xyXG4gICAgcHVibGljIHN2Z0NvbnRhaW5lcjogYW55O1xyXG4gICAgcHVibGljIHN2Z1JlY3Q6IGFueTtcclxuICAgIHB1YmxpYyBncmFwaDogYW55O1xyXG4gICAgcHVibGljIHdpZHRoOiBudW1iZXI7XHJcbiAgICBwdWJsaWMgaGVpZ2h0OiBudW1iZXI7XHJcbiAgICAvLyBkMyBzY2FsZXMuIERlZmluaXRpb246IGdpdmUgZG9tYWluIGFuZCByYW5nZS4gVXNhZ2U6IHRoaXMueCh2YWx1ZSkgd2lsbCBvdXRwdXQgYSB2YWx1ZSBpbiB0aGUgcmFuZ2VcclxuICAgIHB1YmxpYyB4OiBhbnk7XHJcbiAgICBwdWJsaWMgeTogYW55O1xyXG4gICAgcHVibGljIHhBeGlzQXJyOiBBcnJheTxhbnk+ID0gW107XHJcbiAgICBwdWJsaWMgeUF4aXM6IGFueTtcclxuICAgIHB1YmxpYyB4QXhpc0Z1bmM6IGFueTtcclxuICAgIHB1YmxpYyB5QXhpc0Z1bmM6IGFueTtcclxuICAgIC8vIGF4aXNNYXgvTWluIGlzIHVzZWQgb25seSB3aGVuIGF1dG9Sb3VuZFRvTWF4LCBldmVudHVhbGx5IHN0b3JlZCBpbnRvIGRvbWFpbk1heC9NaW5cclxuICAgIHB1YmxpYyBheGlzTWF4OiBudW1iZXI7XHJcbiAgICBwdWJsaWMgYXhpc01pbjogbnVtYmVyID0gMDtcclxuICAgIC8vIGZpbmFsIGF4aXMgdmFsdWVzIHBhc3NlZCB0byBkMy5zY2FsZVxyXG4gICAgcHVibGljIGRvbWFpbk1heDogbnVtYmVyO1xyXG4gICAgcHVibGljIGRvbWFpbk1pbjogbnVtYmVyO1xyXG4gICAgcHVibGljIGdyaWRMaW5lc0NvbnRhaW5lcjogYW55O1xyXG4gICAgcHVibGljIGF4aXNMYWJlbENvbnRhaW5lckFycjogQXJyYXk8YW55PiA9IFtdO1xyXG4gICAgcHVibGljIHRpY2tWYWx1ZXM6IEFycmF5PG51bWJlcj47XHJcbiAgICBwdWJsaWMgaGF2ZU5lZ2F0aXZlOiBib29sZWFuID0gZmFsc2U7XHJcbiAgICAvKipcclxuICAgICAqIHVzZWQgb25seSBieSBiYXIuXHJcbiAgICAgKiBiYXJHcm91cFBhZGRpbmcgaXMgdXNlZCBvbmx5IGZvciBjbHVzdGVyIC0tPiB0aGUgcGFkZGluZyBiZXR3ZWVuIGVhY2ggcmVjdCBpbiBhIGNhdGVnb3J5XHJcbiAgICAgKiBiYW5kUGFkZGluZyBpcyBnaXZlbiB0byBkMyAtLT4gdGhlIHBhZGRpbmcgYmV0d2VlbiBlYWNoIGNhdGVnb3J5XHJcbiAgICAgKiB0eXBlIHtJQmFzZUNsYXNzQmFyT2JqfVxyXG4gICAgICovXHJcbiAgICBwdWJsaWMgYmFyOiB7IGlzSW52ZXJ0OiBib29sZWFuOyBjbHVzdGVyUGFkZGluZ1BlcmNlbnQ6IG51bWJlcjsgYmFuZFBhZGRpbmc6IG51bWJlciB9ID0ge1xyXG4gICAgICAgIGlzSW52ZXJ0OiBmYWxzZSxcclxuICAgICAgICBjbHVzdGVyUGFkZGluZ1BlcmNlbnQ6IDAuMSxcclxuICAgICAgICBiYW5kUGFkZGluZzogMC4yLFxyXG4gICAgfTtcclxuXHJcbiAgICBwdWJsaWMgcmFuZ2VMaXN0OiBvYmplY3Q7XHJcbiAgICBwdWJsaWMgbGVuZ3RoT2ZUcmFuc2l0aW9uOiBudW1iZXIgPSAxMDAwO1xyXG5cclxuICAgIC8vIERhdGEgbGFiZWwgU2V0dGluZ1xyXG4gICAgcHVibGljIGRhdGFMYWJlbENvbnRhaW5lcjtcclxuXHJcbiAgICBwdWJsaWMgbGVnZW5kRGF0YTogeyBba2V5OiBzdHJpbmddOiBJTGVnZW5kRGF0YSB9O1xyXG5cclxuICAgIHB1YmxpYyBlcnJvck1zZzogc3RyaW5nID0gJzEwMCUgc3RhY2sgZG9lcyBub3Qgc3VwcG9ydCBuZWdhdGl2ZSB2YWx1ZXMuJztcclxuXHJcbiAgICBwcml2YXRlIF9zZXRDaGFydFRpbWVvdXQ6IGFueTtcclxuXHJcbiAgICBjb25zdHJ1Y3RvcihwdWJsaWMgX2NoYXJ0U3ZjOiBLZENoYXJ0c1N2YywgcHVibGljIF9kb21TdmM6IEtkRG9tRWxlbVN2Yykge1xyXG4gICAgICAgIHRoaXMuaXNSdGwgPSBfZG9tU3ZjLmdldERvY3VtZW50RGlyZWN0aW9uKHRydWUpID09PSAncmlnaHQnO1xyXG4gICAgfVxyXG5cclxuICAgIC8vID09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PSBDaGFydCA9PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09XHJcblxyXG4gICAgcHVibGljIHNldFN2ZygpOiB2b2lkIHtcclxuICAgICAgICB0aGlzLnN2ZyA9IGQzLnNlbGVjdCgnIycgKyB0aGlzLmNvbmZpZy5pZCArICcua2R4LWNoYXJ0cyBzdmcnKTtcclxuICAgICAgICBpZiAoIXRoaXMuZ3JhcGgpIHRoaXMuZ3JhcGggPSB0aGlzLnN2Zy5hcHBlbmQoJ2cnKS5hdHRyKCdjbGFzcycsICdncmFwaCcpO1xyXG4gICAgICAgIC8vIGlmICh0aGlzLnN2Zy5zZWxlY3QoJy5ncmFwaCcpLmVtcHR5KCkpIHRoaXMuZ3JhcGggPSB0aGlzLnN2Zy5hcHBlbmQoJ2cnKS5hdHRyKCdjbGFzcycsICdncmFwaCcpO1xyXG4gICAgICAgIHRoaXMuc3ZnUGFyZW50ID0gZDMuc2VsZWN0KCcjJyArIHRoaXMuY29uZmlnLmlkICsgJy5rZHgtY2hhcnRzIC5rZHgtY2hhcnQtY29udGFpbmVyJyk7XHJcbiAgICAgICAgdGhpcy5zdmdDb250YWluZXIgPSBkMy5zZWxlY3QoJyMnICsgdGhpcy5jb25maWcuaWQgKyAnLmtkeC1jaGFydHMgLmtkeC1jaGFydHMtc3ZnLWNvbnRhaW5lcicpO1xyXG5cclxuICAgICAgICB0aGlzLl9zZXRMYWJlbENvbnRhaW5lcigpO1xyXG4gICAgICAgIHRoaXMuX3NldENoYXJ0U3ZjKCk7XHJcbiAgICAgICAgdGhpcy5yYW5nZUxpc3QgPSB7fTtcclxuICAgIH1cclxuXHJcbiAgICAvKipcclxuICAgICAqIHNldCBzdmcgd2lkdGggYW5kIGhlaWdodC4gdGhpcyBmdW5jdGlvbiBpcyBiZWNvcyBvZiBleHBvcnQgZmVhdHVyZSwgdGhlIGV4cG9ydCBwbHVnaW5zIHJlcXVpcmVzIHN2ZyB3aWR0aCBhbmQgaGVpZ2h0IHRvIGJlIGlubGluZSBhdHRyaWJ1dGVzIHdpdGggZGVmaW5pdGUgbnVtYmVyXHJcbiAgICAgKiBoYXZlIHRvIGJlIGNhbGxlZCBieSBhbGwgY2hhcnRzXHJcbiAgICAgKiBwYXJhbSB7J3gnIHwgJ3knfSBfYXhpc1xyXG4gICAgICovXHJcbiAgICBwdWJsaWMgc2V0U3ZnRGltZW5zaW9uKF9heGlzOiAneCcgfCAneScpOiB2b2lkIHtcclxuICAgICAgICBsZXQgc3ZnQ29udGFpbmVyUmVjdDogYW55ID0gdGhpcy5zdmdDb250YWluZXIubm9kZSgpLmdldEJvdW5kaW5nQ2xpZW50UmVjdCgpO1xyXG4gICAgICAgIGxldCB0eXBlOiAnd2lkdGgnIHwgJ2hlaWdodCcgPSBfYXhpcyA9PT0gJ3gnID8gKHRoaXMuYmFyLmlzSW52ZXJ0ID8gJ2hlaWdodCcgOiAnd2lkdGgnKSA6ICh0aGlzLmJhci5pc0ludmVydCA/ICd3aWR0aCcgOiAnaGVpZ2h0Jyk7XHJcblxyXG4gICAgICAgIHRoaXMuc3ZnLmF0dHIodHlwZSwgc3ZnQ29udGFpbmVyUmVjdFt0eXBlXSk7XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfY2xlYXJTdmdEaW1lbnNpb24oKTogdm9pZCB7XHJcbiAgICAgICAgaWYgKCF0aGlzLnN2ZykgcmV0dXJuO1xyXG4gICAgICAgIHRoaXMuc3ZnXHJcbiAgICAgICAgICAgIC5hdHRyKCd3aWR0aCcsIDApXHJcbiAgICAgICAgICAgIC5hdHRyKCdoZWlnaHQnLCAwKTtcclxuICAgIH1cclxuXHJcbiAgICAvKipcclxuICAgICAqIHNldCB0aGlzLndpZHRoIGFuZCB0aGlzLmhlaWdodCBmb3IgYXhpcyBzY2FsZXMuIG9ubHkgY2FsbGVkIGJ5IGNoYXJ0cyB3aXRoIGF4aXNcclxuICAgICAqIHBhcmFtIHsneCcgfCd5J30gICAgICAgICBfYXhpc1xyXG4gICAgICogcGFyYW0ge2Jvb2xlYW59IF9za2lwQ2FsIDogc2tpcCBnZXRTdmdPZmZzZXQgY2FsY3VsYXRpb25zXHJcbiAgICAgKi9cclxuICAgIHByaXZhdGUgX3NldEdyYXBoRGltZW5zaW9uKF9heGlzOiAneCcgfCAneScpOiB2b2lkIHtcclxuICAgICAgICB0aGlzLnN2Z1JlY3QgPSB0aGlzLnN2Zy5ub2RlKCkuZ2V0Qm91bmRpbmdDbGllbnRSZWN0KCk7XHJcbiAgICAgICAgdGhpcy5fY2hhcnRTdmMuc3ZnUmVjdCA9IHRoaXMuc3ZnUmVjdDtcclxuXHJcbiAgICAgICAgbGV0IHR5cGU6ICd3aWR0aCcgfCAnaGVpZ2h0JyA9IF9heGlzID09PSAneCcgPyAodGhpcy5iYXIuaXNJbnZlcnQgPyAnaGVpZ2h0JyA6ICd3aWR0aCcpIDogKHRoaXMuYmFyLmlzSW52ZXJ0ID8gJ3dpZHRoJyA6ICdoZWlnaHQnKTtcclxuXHJcbiAgICAgICAgbGV0IHZhbHVlOiBudW1iZXIgPSB0aGlzLl9jaGFydFN2Yy5nZXRTdmdPZmZzZXQoX2F4aXMsIHsgYXhpc01heDogdGhpcy5heGlzTWF4LCBheGlzTWluOiB0aGlzLmF4aXNNaW4gfSk7XHJcblxyXG4gICAgICAgIHRoaXNbdHlwZV0gPSB2YWx1ZSA8IDAgPyAwIDogdmFsdWU7XHJcbiAgICB9XHJcblxyXG4gICAgLyoqXHJcbiAgICAgKiBzZXQgQ2hhcnQgU2VydmljZSB2YXJpYWJsZXNcclxuICAgICAqL1xyXG4gICAgcHJpdmF0ZSBfc2V0Q2hhcnRTdmMoKTogdm9pZCB7XHJcbiAgICAgICAgdGhpcy5fY2hhcnRTdmMuY29uZmlnID0gdGhpcy5jb25maWc7XHJcbiAgICAgICAgdGhpcy5fY2hhcnRTdmMuY2hhcnRUeXBlID0gdGhpcy5jaGFydFR5cGU7XHJcbiAgICAgICAgdGhpcy5fY2hhcnRTdmMuY2hhcnRDYXRlZ29yeSA9IHRoaXMuY2hhcnRDYXRlZ29yeTtcclxuICAgICAgICB0aGlzLl9jaGFydFN2Yy5zdmdQYXJlbnRSZWN0ID0gdGhpcy5zdmdQYXJlbnQubm9kZSgpLmdldEJvdW5kaW5nQ2xpZW50UmVjdCgpO1xyXG4gICAgICAgIHRoaXMuX2NoYXJ0U3ZjLnN2ZyA9IHRoaXMuc3ZnO1xyXG4gICAgICAgIHRoaXMuX2NoYXJ0U3ZjLmlzUnRsID0gdGhpcy5pc1J0bDtcclxuICAgICAgICB0aGlzLl9jaGFydFN2Yy5pc1hSZXZlcnNlZCA9IHRoaXMuY29uZmlnLnhBeGlzLnJldmVyc2VkO1xyXG4gICAgICAgIHRoaXMuX2NoYXJ0U3ZjLmlzWVJldmVyc2VkID0gdGhpcy5jb25maWcueUF4aXMucmV2ZXJzZWQ7XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfc2V0TGluZWFyU2NhbGUoKTogdm9pZCB7XHJcbiAgICAgICAgbGV0IHJhbmdlUm91bmRWYWw6IEFycmF5PG51bWJlcj4gPSB0aGlzLl9nZXRSYW5nZVZhbCgneScpO1xyXG4gICAgICAgIHRoaXMueSA9IGQzLnNjYWxlTGluZWFyKCkucmFuZ2VSb3VuZChyYW5nZVJvdW5kVmFsKTtcclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF9zZXRCYW5kU2NhbGUoKTogdm9pZCB7XHJcbiAgICAgICAgbGV0IHJhbmdlVmFsOiBBcnJheTxudW1iZXI+ID0gdGhpcy5fZ2V0UmFuZ2VWYWwoJ3gnKTtcclxuXHJcbiAgICAgICAgdGhpcy54ID0gZDMuc2NhbGVCYW5kKCkucmFuZ2UocmFuZ2VWYWwpO1xyXG5cclxuICAgICAgICBpZiAodGhpcy5jaGFydENhdGVnb3J5ID09PSAnYmFyJykge1xyXG4gICAgICAgICAgICB0aGlzLngucGFkZGluZ0lubmVyKHRoaXMuYmFyLmJhbmRQYWRkaW5nKS5wYWRkaW5nT3V0ZXIodGhpcy5iYXIuYmFuZFBhZGRpbmcgLyAyKTtcclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfZ2V0UmFuZ2VWYWwoX2F4aXM6ICd4JyB8ICd5Jyk6IG51bWJlcltdIHtcclxuICAgICAgICBsZXQgcmFuZ2VWYWw6IG51bWJlcltdO1xyXG4gICAgICAgIGxldCByZXZlcnNlZDogJ2lzWFJldmVyc2VkJyB8ICdpc1lSZXZlcnNlZCcgPSBfYXhpcyA9PT0gJ3gnID8gJ2lzWFJldmVyc2VkJyA6ICdpc1lSZXZlcnNlZCc7XHJcblxyXG4gICAgICAgIGlmICh0aGlzLmJhci5pc0ludmVydCkge1xyXG4gICAgICAgICAgICByYW5nZVZhbCA9IF9heGlzID09PSAneCcgPyBbMCwgdGhpcy5oZWlnaHRdIDogWzAsIHRoaXMud2lkdGhdO1xyXG4gICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgIHJhbmdlVmFsID0gX2F4aXMgPT09ICd4JyA/IFswLCB0aGlzLndpZHRoXSA6IFt0aGlzLmhlaWdodCwgMF07XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICByZXR1cm4gdGhpcy5fY2hhcnRTdmNbcmV2ZXJzZWRdID8gcmFuZ2VWYWwucmV2ZXJzZSgpIDogcmFuZ2VWYWw7XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfc2V0UmFuZ2UoaXNCYW5kPzogYm9vbGVhbik6IEFycmF5PG51bWJlcj4ge1xyXG4gICAgICAgIGxldCBjaGFydFdpZHRoOiBudW1iZXIgPSB0aGlzLndpZHRoO1xyXG5cclxuICAgICAgICBpZiAoIWlzQmFuZCAmJiB0aGlzLmRhdGEubGVuZ3RoIDw9IDApIHtcclxuICAgICAgICAgICAgdGhpcy5yYW5nZUxpc3RbMF0gPSBjaGFydFdpZHRoO1xyXG4gICAgICAgICAgICByZXR1cm4gWzAsIGNoYXJ0V2lkdGhdO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgbGV0IHhQb3NpdGlvbjogbnVtYmVyID0gMDtcclxuICAgICAgICBsZXQgcmFuZ2VBcnJheTogQXJyYXk8bnVtYmVyPiA9IFtdO1xyXG4gICAgICAgIGxldCBiYW5kV2lkdGg6IG51bWJlciA9IGNoYXJ0V2lkdGggLyB0aGlzLmRhdGEubGVuZ3RoO1xyXG5cclxuICAgICAgICBmb3IgKGxldCBpID0gMDsgaSA8IHRoaXMuZGF0YS5sZW5ndGg7IGkrKykge1xyXG5cclxuICAgICAgICAgICAgaWYgKGlzQmFuZCkge1xyXG4gICAgICAgICAgICAgICAgeFBvc2l0aW9uID0gdGhpcy5fZ2V0Q2VudGVyQmFuZFBvc2l0aW9uKGJhbmRXaWR0aCwgaSk7XHJcbiAgICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgICAgICB4UG9zaXRpb24gPSBjaGFydFdpZHRoIC8gKHRoaXMuZGF0YS5sZW5ndGggLSAxKSAqIGk7XHJcbiAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgIGlmICh0aGlzLl9jaGFydFN2Yy5pc1hSZXZlcnNlZCkgeFBvc2l0aW9uID0gY2hhcnRXaWR0aCAtIHhQb3NpdGlvbjtcclxuXHJcbiAgICAgICAgICAgIHJhbmdlQXJyYXkucHVzaCh4UG9zaXRpb24pO1xyXG4gICAgICAgICAgICB0aGlzLnJhbmdlTGlzdFt0aGlzLmRhdGFbaV0ueC52YWx1ZV0gPSB4UG9zaXRpb247XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICByZXR1cm4gcmFuZ2VBcnJheTtcclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF9nZXRDZW50ZXJCYW5kUG9zaXRpb24oX2JhbmRXaWR0aDogbnVtYmVyLCBfcG9zaXRpb246IG51bWJlcik6IG51bWJlciB7XHJcbiAgICAgICAgcmV0dXJuIChfYmFuZFdpZHRoIC8gMikgKyAoX2JhbmRXaWR0aCAqIF9wb3NpdGlvbik7XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfc2V0U2NhbGVCeURpcmVjdGlvbihfYXhpczogJ3gnIHwgJ3knLCBfeFNjYWxlVHlwZT86ICdiYW5kJyB8ICdzdHJpbmcnKTogdm9pZCB7XHJcbiAgICAgICAgaWYgKF9heGlzID09PSAneCcpIHtcclxuICAgICAgICAgICAgaWYgKF94U2NhbGVUeXBlICE9PSAnc3RyaW5nJykgdGhpcy5fc2V0QmFuZFNjYWxlKCk7XHJcbiAgICAgICAgICAgIGlmICh0aGlzLmNoYXJ0Q2F0ZWdvcnkgPT09ICdsaW5lJykgdGhpcy5fc2V0TGluZVNjYWxlWChfeFNjYWxlVHlwZSk7XHJcbiAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgdGhpcy5fc2V0TGluZWFyU2NhbGUoKTtcclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgLyoqXHJcbiAgICAgKiAoZm9yIGxpbmUgb25seSlcclxuICAgICAqIGhhcHBlbnMgYXQgZmlyc3QgbG9hZCBhbmQgb24gY2hhbmdlIGFuZCBtYXkgaGFwcGVuIGlmIGRhdGEgaXMgc2xpY2VkIGR1cmluZyB0cmltWCgpXHJcbiAgICAgKi9cclxuICAgIHByaXZhdGUgX3NldExpbmVTY2FsZVgoX3hTY2FsZVR5cGU6ICdzdHJpbmcnIHwgJ2JhbmQnKTogdm9pZCB7XHJcbiAgICAgICAgaWYgKF94U2NhbGVUeXBlID09PSAnc3RyaW5nJykge1xyXG4gICAgICAgICAgICB0aGlzLnggPSBkMy5zY2FsZU9yZGluYWwoKS5yYW5nZSh0aGlzLl9zZXRSYW5nZShmYWxzZSkpO1xyXG4gICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgIHRoaXMuX3NldFJhbmdlKHRydWUpO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICAvLyA9PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT0gRG9tYWluID09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT1cclxuXHJcbiAgICBwdWJsaWMgc2V0RG9tYWluKF94U2NhbGVUeXBlOiAnc3RyaW5nJyB8ICdiYW5kJyk6IHZvaWQge1xyXG5cclxuICAgICAgICB0aGlzLl9jaGFydFN2Yy54U2NhbGVUeXBlID0gX3hTY2FsZVR5cGU7XHJcblxyXG4gICAgICAgIHRoaXMuc3ZnLmF0dHIoJ3Zpc2liaWxpdHknLCAnaGlkZGVuJyk7XHJcblxyXG4gICAgICAgIC8vIHNldHRpbmcgdGhlIGNsYXNzIG5hbWUgb2YgY2hhcnQtd3JhcHBlciAoZm9yIGZsZXgtcmV2ZXJzZSlcclxuICAgICAgICB0aGlzLl9jaGFydFN2Yy5zZXRWZXJ0QXhpc0FuZENoYXJ0TWFyZ2luKHRoaXMuY29uZmlnLmlkKTtcclxuXHJcbiAgICAgICAgLy8gZXZlcnl0aW1lIHRoZSBncmFwaCByZXNldHMsIGlmIHRyaW1taW5nIGhhdmUgb2NjdXJlZCBiZWZvcmUgKGllOiB0aGlzLmRhdGEgYW5kIGluaXREYXRhIGxlbmd0aCBkaWZmZXJzKSwgcmVzZXQgdGhpcy5kYXRhIHNvIHRoYXQgdGhlIHRyaW1taW5nIGNhbGN1bGF0aW9uIHVzZXMgZnVsbCBkYXRhc2V0XHJcbiAgICAgICAgaWYgKHRoaXMuaW5pdERhdGEgJiYgdGhpcy5kYXRhLmxlbmd0aCAhPT0gdGhpcy5pbml0RGF0YS5sZW5ndGgpIHtcclxuICAgICAgICAgICAgdGhpcy5kYXRhID0gSlNPTi5wYXJzZShKU09OLnN0cmluZ2lmeSh0aGlzLmluaXREYXRhKSk7XHJcbiAgICAgICAgICAgIC8vIHRoaXMuX2NoYXJ0U3ZjLnNldEF4aXNMYWJlbER1bW15VGV4dCh0aGlzLmNhdGVnb3JpZXMsIHRoaXMuY29uZmlnLnhBeGlzLmxhYmVscy5mb3JtYXQpO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgLy8gc2V0IHRoaXMud2lkdGgsaGVpZ2h0LCBzY2FsZSwgZG9tYWluIGFuZCB0aWNrVmFsdWVzXHJcbiAgICAgICAgdGhpcy5fc2V0RG9tYWluKF94U2NhbGVUeXBlKTtcclxuXHJcbiAgICAgICAgdGhpcy5zdmcuYXR0cigndmlzaWJpbGl0eScsICd2aXNpYmxlJyk7XHJcblxyXG4gICAgICAgIC8vIHNldCBtYWpvciBhbmQgbWlub3IgZ3JpZCBsaW5lc1xyXG4gICAgICAgIHRoaXMuX3NldEdyaWRMaW5lcygpO1xyXG5cclxuICAgICAgICAvLyBzZXQgeSBhbmQgeCBheGlzIGxpbmVzXHJcbiAgICAgICAgdGhpcy5zZXRBeGlzKCk7XHJcblxyXG4gICAgICAgIC8vIHRyYW5zZm9ybSBncmFwaCBhY2NvcmRpbmcgdG8gd2lkdGggb2YgdmVydGljYWwgYXhpc1xyXG4gICAgICAgIHRoaXMuX2NoYXJ0U3ZjLnRyYW5zZm9ybUdyYXBoQ29udGFpbmVyKHRoaXMuZ3JhcGgpO1xyXG5cclxuICAgICAgICAvLyByZXBvc2l0aW9uIERhdGEgTGFiZWwgYWNjb3JkaW5nIHRvIHdpZHRoIG9mIHZlcnRpY2FsIGF4aXNcclxuICAgICAgICBpZiAodGhpcy5jb25maWcuY2hhcnQubGFiZWxzLmVuYWJsZWQpIHtcclxuICAgICAgICAgICAgdGhpcy5kYXRhTGFiZWxDb250YWluZXIuc3R5bGUoJ3dpZHRoJywgdGhpcy53aWR0aCArICdweCcpO1xyXG4gICAgICAgICAgICB0aGlzLl9jaGFydFN2Yy5yZXBvc2l0aW9uRGF0YUxhYmVsKHRoaXMuZGF0YUxhYmVsQ29udGFpbmVyLCB0aGlzLmF4aXNMYWJlbENvbnRhaW5lckFyclswXSk7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICAvLyByZXBvc2l0aW9uIHZlcnRpY2FsIGF4aXNcclxuICAgICAgICB0aGlzLl9jaGFydFN2Yy5yZXBvc2l0aW9uVmVydGljYWxBeGlzVGl0bGUoKTtcclxuXHJcbiAgICAgICAgLy8gc2V0IGNsaXAgcGF0aCB0byB0aGlzLndpZHRoIGFuZCB0aGlzLmhlaWdodCB0byBtYWtlIHN1cmUgZ3JhcGggd2lsbCBub3QgYmUgZHJhd24gb3V0IG9mIGdyYXBoaW5nIHJlZ2lvblxyXG4gICAgICAgIHRoaXMuX3NldENsaXBQYXRoKCk7XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfc2V0RG9tYWluKF94U2NhbGVUeXBlOiAnc3RyaW5nJyB8ICdiYW5kJyk6IHZvaWQge1xyXG4gICAgICAgIC8vIGZpbmRpbmcgdGhlIG1heC9taW4gdmFsdWUgYW5kIGF4aXNNYXgvYXhpc01pblxyXG4gICAgICAgIGxldCBheGlzTGFiZWxDb25maWc6IElZQXhpc0NvbmZpZyA9IHRoaXMuY29uZmlnLnlBeGlzO1xyXG4gICAgICAgIGxldCByZXN1bHQ6IElNYXhNaW5JbnRlcnZhbCA9IHRoaXMuX2NoYXJ0U3ZjLnNldE1heEFuZE1pbihheGlzTGFiZWxDb25maWcsIHRoaXMuZGF0YVJhbmdlKTtcclxuICAgICAgICB0aGlzLl9jaGFydFN2Yy5zZXRBeGlzRDNGb3JtYXQocmVzdWx0LmludGVydmFsKTtcclxuXHJcbiAgICAgICAgdGhpcy5fc2V0QXhpc01heEFuZE1pbihyZXN1bHQubWF4VmFsdWUsIHJlc3VsdC5taW5WYWx1ZSwgcmVzdWx0LmludGVydmFsKTtcclxuXHJcbiAgICAgICAgbGV0IHhJbmZvOiBJWEluZm8gPSB0aGlzLl9jaGFydFN2Yy5nZXRYSW5mbyh0aGlzLmRhdGEsIHRoaXMuY29uZmlnKTtcclxuICAgICAgICB0aGlzLl9zZXRXaWR0aEhlaWdodFNjYWxlKCd4JywgX3hTY2FsZVR5cGUpO1xyXG4gICAgICAgIHRoaXMueC5kb21haW4oeEluZm8udmFsdWUpO1xyXG4gICAgICAgIHRoaXMuX3NldFhBeGlzTGFiZWwoX3hTY2FsZVR5cGUsIHhJbmZvLmxvbmdlc3RUZXh0KTtcclxuXHJcbiAgICAgICAgdGhpcy5fc2V0V2lkdGhIZWlnaHRTY2FsZSgneScsIF94U2NhbGVUeXBlKTtcclxuXHJcbiAgICAgICAgbGV0IHRpY2tWYWx1ZVJldHVybjogSVNldFRpY2tWYWx1ZVJldHVybiA9IHRoaXMuX2ZpbmRJbnRlcnZhbEZvck5vT3ZlcmxhcChyZXN1bHQpO1xyXG5cclxuICAgICAgICBpZiAodGlja1ZhbHVlUmV0dXJuICYmIHRpY2tWYWx1ZVJldHVybi5uZWVkUmVkcmF3KSB7XHJcbiAgICAgICAgICAgIHRoaXMuX3NldFdpZHRoSGVpZ2h0U2NhbGUoJ3gnLCBfeFNjYWxlVHlwZSk7XHJcbiAgICAgICAgICAgIHRoaXMueC5kb21haW4oeEluZm8udmFsdWUpO1xyXG4gICAgICAgICAgICB0aGlzLl9zZXRYQXhpc0xhYmVsKF94U2NhbGVUeXBlLCB4SW5mby5sb25nZXN0VGV4dCk7XHJcblxyXG4gICAgICAgICAgICB0aGlzLl9zZXRXaWR0aEhlaWdodFNjYWxlKCd5JywgX3hTY2FsZVR5cGUpO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgLy8gb25seSBnZW5lcmF0ZSByYW5nZSBhcnIgd2hlbiBpbnRlcnZhbCBpcyBzdGFibGl6ZWRcclxuICAgICAgICB0aGlzLnRpY2tWYWx1ZXMgPSB0aGlzLl9jaGFydFN2Yy5nZXRUaWNrVmFsdWVzKHRoaXMuYXhpc01pbiwgdGhpcy5heGlzTWF4LCB0aWNrVmFsdWVSZXR1cm4uaW50ZXJ2YWwpO1xyXG5cclxuICAgICAgICAvLyBzZXQgWSBkb21haW5cclxuICAgICAgICB0aGlzLmRvbWFpbk1heCA9IGF4aXNMYWJlbENvbmZpZy5hdXRvUm91bmRUb01heCA/IHRoaXMuYXhpc01heCA6IHJlc3VsdC5tYXhWYWx1ZTtcclxuICAgICAgICB0aGlzLmRvbWFpbk1pbiA9IGF4aXNMYWJlbENvbmZpZy5hdXRvUm91bmRUb01pbiA/IHRoaXMuYXhpc01pbiA6IHJlc3VsdC5taW5WYWx1ZTtcclxuICAgICAgICB0aGlzLnkuZG9tYWluKFt0aGlzLmRvbWFpbk1pbiwgdGhpcy5kb21haW5NYXhdKTtcclxuICAgIH1cclxuXHJcblxyXG4gICAgcHJpdmF0ZSBfc2V0V2lkdGhIZWlnaHRTY2FsZShfYXhpczogJ3gnIHwgJ3knLCBfeFNjYWxlVHlwZTogJ3N0cmluZycgfCAnYmFuZCcpOiB2b2lkIHtcclxuICAgICAgICB0aGlzLnNldFN2Z0RpbWVuc2lvbihfYXhpcyk7XHJcbiAgICAgICAgdGhpcy5fc2V0R3JhcGhEaW1lbnNpb24oX2F4aXMpO1xyXG4gICAgICAgIHRoaXMuX3NldFNjYWxlQnlEaXJlY3Rpb24oX2F4aXMsIF94U2NhbGVUeXBlKTtcclxuICAgIH1cclxuXHJcbiAgICAvKipcclxuICAgICAqIHNldCBjbGlwIHBhdGggdG8gdGhpcy53aWR0aCBhbmQgdGhpcy5oZWlnaHQgdG8gbWFrZSBzdXJlIGdyYXBoIHdpbGwgbm90IGJlIGRyYXduIG91dCBvZiBncmFwaGluZyByZWdpb25cclxuICAgICAqL1xyXG4gICAgcHJpdmF0ZSBfc2V0Q2xpcFBhdGgoKTogdm9pZCB7XHJcbiAgICAgICAgbGV0IGNsaXBQYXRoUmVjdDogYW55ID0gdGhpcy5zdmcuc2VsZWN0QWxsKCdkZWZzICNrZC1jaGFydHMtY2xpcC1wYXRoLScgKyB0aGlzLmNvbmZpZy5pZCArICcgcmVjdCcpO1xyXG4gICAgICAgIGlmIChjbGlwUGF0aFJlY3QuZW1wdHkoKSkge1xyXG4gICAgICAgICAgICBjbGlwUGF0aFJlY3QgPSB0aGlzLnN2Zy5pbnNlcnQoJ2RlZnMnKS5hcHBlbmQoJ2NsaXBQYXRoJykuYXR0cignaWQnLCAna2QtY2hhcnRzLWNsaXAtcGF0aC0nICsgdGhpcy5jb25maWcuaWQpLmFwcGVuZCgncmVjdCcpO1xyXG4gICAgICAgICAgICBjbGlwUGF0aFJlY3RcclxuICAgICAgICAgICAgICAgIC5hdHRyKCd4JywgMClcclxuICAgICAgICAgICAgICAgIC5hdHRyKCd5JywgMClcclxuICAgICAgICAgICAgICAgIC5hdHRyKCdmaWxsJywgJ25vbmUnKTtcclxuICAgICAgICB9XHJcbiAgICAgICAgY2xpcFBhdGhSZWN0XHJcbiAgICAgICAgICAgIC5hdHRyKCd3aWR0aCcsIHRoaXMud2lkdGgpXHJcbiAgICAgICAgICAgIC5hdHRyKCdoZWlnaHQnLCB0aGlzLmhlaWdodCk7XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfc2V0QXhpc01heEFuZE1pbihfbWF4VmFsdWU6IG51bWJlciwgX21pblZhbHVlOiBudW1iZXIsIF9pbnRlcnZhbDogbnVtYmVyKTogdm9pZCB7XHJcbiAgICAgICAgbGV0IHlBeGlzQ29uZmlnOiBJWUF4aXNDb25maWcgPSB0aGlzLmNvbmZpZy55QXhpcztcclxuICAgICAgICB0aGlzLmF4aXNNYXggPSB0aGlzLl9jaGFydFN2Yy5zZXRBeGlzUm91bmRWYWx1ZShfbWF4VmFsdWUsIF9pbnRlcnZhbCwgeUF4aXNDb25maWcuYXV0b1JvdW5kVG9NYXgsICd1cCcpO1xyXG4gICAgICAgIHRoaXMuYXhpc01pbiA9IHRoaXMuX2NoYXJ0U3ZjLnNldEF4aXNSb3VuZFZhbHVlKF9taW5WYWx1ZSwgX2ludGVydmFsLCB5QXhpc0NvbmZpZy5hdXRvUm91bmRUb01pbiwgJ2Rvd24nKTtcclxuICAgIH1cclxuXHJcbiAgICAvKipcclxuICAgKiB3aWxsIHJldHVybiBhbiBvYmplY3Qgd2l0aCBmb2xsb3dpbmcgcHJvcGVydGllc1xyXG4gICAqIG5lZWRSZWRyYXc6IHRvIGRldGVybWluZSB3aGV0aGVyIHRvIHJlZHJhdyB0aGUgYXhpcyAoYW5kIHJlc2V0IHRoZSBkb21haW4pXHJcbiAgICogaW50ZXJ2YWw6IHBhc3Mgb3V0IHRoZSBsYXN0ZXN0IGludGVydmFsICh0aGF0IGhhdmUgbm8gb3ZlcmxhcCkgZm9yIHBlcmZvcm1hbmNlIHJlYXNvbnMsIHNvIHRoYXQgdGhlIHdoaWxlIGxvb3Agd2lsbCBvbmx5IHJ1biBvbmNlIG9uIG5lZWRSZWRyYXdcclxuICAgKi9cclxuICAgIHByaXZhdGUgX2ZpbmRJbnRlcnZhbEZvck5vT3ZlcmxhcChfaW5pdEluZm86IElNYXhNaW5JbnRlcnZhbCk6IElTZXRUaWNrVmFsdWVSZXR1cm4ge1xyXG4gICAgICAgIGxldCBsZW5ndGg6IG51bWJlciA9IHRoaXMuYmFyLmlzSW52ZXJ0ID8gdGhpcy53aWR0aCA6IHRoaXMuaGVpZ2h0O1xyXG4gICAgICAgIGlmIChsZW5ndGggPD0gMCkgcmV0dXJuIHsgbmVlZFJlZHJhdzogZmFsc2UsIGludGVydmFsOiAwIH07XHJcblxyXG4gICAgICAgIGxldCB0aWNrTGVuZ3RoOiBudW1iZXI7XHJcbiAgICAgICAgbGV0IGluaXRZQXhpc0xhYmVsV2lkdGg6IElZQXhpc0xhYmVsUmFuZ2UgPSBPYmplY3QuYXNzaWduKHt9LCB0aGlzLl9jaGFydFN2Yy55QXhpc0xhYmVsV2lkdGgpO1xyXG5cclxuICAgICAgICBpZiAodGhpcy5iYXIuaXNJbnZlcnQpIHtcclxuICAgICAgICAgICAgLy8gYXhpc01heCBhbmQgYXhpc01pbiBpcyBhbHJlYWR5IGFwcGVuZGVkIGFzIGR1bW15IHRvIHN2ZyB3aGVuIGNhbGN1bGF0aW5nIGZvciB0aGlzLndpZHRoIGFuZCB0aGlzLmhlaWdodFxyXG4gICAgICAgICAgICAvLyB3ZSBjYW4gZGlyZWN0IGFjY2VzcyB0byB0aGUgYWN0dWFsIHdpZHRoIGluc3RlYWQgb2YgZG9pbmcgYXBwcm94aW1hdGlvbiBjYWxjdWxhdGlvbiBiYXNlZCBvbiBmb250LXNpemUgKGVycm9yIGFzIGhpZ2ggYXMgMS8yIG9mIGFjdHVhbCB3aWR0aClcclxuICAgICAgICAgICAgdGlja0xlbmd0aCA9IE1hdGgubWF4KGluaXRZQXhpc0xhYmVsV2lkdGguYXhpc01heCwgaW5pdFlBeGlzTGFiZWxXaWR0aC5heGlzTWluKTtcclxuICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICB0aWNrTGVuZ3RoID0gdGhpcy5fY2hhcnRTdmMucmVwbGFjZVN0cmluZ1dpdGhOdW1iZXIodGhpcy5jb25maWcueUF4aXMubGFiZWxzLnN0eWxlLmZvbnRTaXplKTtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIGxldCBpbml0SW50ZXJ2YWw6IG51bWJlciA9IF9pbml0SW5mby5pbnRlcnZhbDtcclxuICAgICAgICBsZXQgaW50ZXJ2YWw6IG51bWJlciA9IGluaXRJbnRlcnZhbDtcclxuICAgICAgICBsZXQgbm9PZlRpY2tzID0gTWF0aC5yb3VuZCgodGhpcy5heGlzTWF4ICsgaW50ZXJ2YWwgLSB0aGlzLmF4aXNNaW4pIC8gaW50ZXJ2YWwpO1xyXG5cclxuICAgICAgICBpZiAobGVuZ3RoIDwgdGlja0xlbmd0aCB8fCBub09mVGlja3MgPT09IDApIHJldHVybiB7IG5lZWRSZWRyYXc6IGZhbHNlLCBpbnRlcnZhbDogMCB9O1xyXG5cclxuICAgICAgICBsZXQgaW5pdExvbmdlck51bTogbnVtYmVyID0gdGhpcy5fY2hhcnRTdmMuZ2V0TG9uZ2VyTnVtYmVyKHRoaXMuYXhpc01heCwgdGhpcy5heGlzTWluKS50b1N0cmluZygpLmxlbmd0aDtcclxuXHJcbiAgICAgICAgd2hpbGUgKChsZW5ndGggLyBub09mVGlja3MpIDwgdGlja0xlbmd0aCAmJiBub09mVGlja3MgPiAyKSB7XHJcbiAgICAgICAgICAgIGludGVydmFsID0gaW50ZXJ2YWwgKiAyO1xyXG4gICAgICAgICAgICB0aGlzLl9zZXRBeGlzTWF4QW5kTWluKF9pbml0SW5mby5tYXhWYWx1ZSwgX2luaXRJbmZvLm1pblZhbHVlLCBpbnRlcnZhbCk7XHJcblxyXG4gICAgICAgICAgICAvLyB3aGVuIHRoZSBpbnRlcnZhbCBjaGFuZ2VzLCBheGlzTWF4IG9yIGF4aXNNaW4gZG9lcyBub3QgY2hhbmdlIHNpZ25pZmljYW50bHkgKGNoYW5nZXMgYXQgbW9zdCAxIGRpZ2l0cyBwbGFjZSlcclxuICAgICAgICAgICAgLy8gY2hlY2sgdGhhdCB0aGUgY3VycmVudCBheGlzTWF4L01pbiBpcyBpbmRlZWQgbG9uZ2VyIHRoYW4gdGhlIGluaXRpYWwgYXhpc01heC9NaW5cclxuICAgICAgICAgICAgaWYgKHRoaXMuYmFyLmlzSW52ZXJ0ICYmIHRoaXMuX2NoYXJ0U3ZjLmdldExvbmdlck51bWJlcih0aGlzLmF4aXNNYXgsIHRoaXMuYXhpc01pbikudG9TdHJpbmcoKS5sZW5ndGggPiBpbml0TG9uZ2VyTnVtKSB7XHJcbiAgICAgICAgICAgICAgICB0aWNrTGVuZ3RoID0gdGhpcy5fY2hhcnRTdmMuc2V0RHVtbXlBeGlzTGFiZWwodGhpcy5fY2hhcnRTdmMuZ2V0TG9uZ2VyTnVtYmVyKHRoaXMuYXhpc01heCwgdGhpcy5heGlzTWluKSwgJ2F4aXNNYXgnKTtcclxuICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgbm9PZlRpY2tzID0gTWF0aC5yb3VuZCgodGhpcy5heGlzTWF4ICsgaW50ZXJ2YWwgLSB0aGlzLmF4aXNNaW4pIC8gaW50ZXJ2YWwpO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgLy8gd2hlbiBvdmVybGFwIGZpbmlzaGVzLCBpbnRlcnZhbCBhbmQgYXhpc01heC9NaW4gaXMgY2hhbmdlZCBjb21wYXJlZCB0byB3aGVuIGdldFN2Z09mZnNldCgpXHJcbiAgICAgICAgLy8gY2hlY2sgdGhhdCBjdXJyZW50IGludGVydmFsIHJlc3VsdHMgaW4gc2FtZSBtYXggbGFiZWwgbGVuZ3RoLCBpZiBub3QsIHJlZHJhdyB0aGUgYXhpcyBhbmQgcnVuIGdldFN2Z09mZnNldCgpIGFnYWluXHJcbiAgICAgICAgaWYgKGluaXRJbnRlcnZhbCAhPT0gaW50ZXJ2YWwpIHtcclxuICAgICAgICAgICAgdGhpcy5fY2hhcnRTdmMuc2V0QXhpc0QzRm9ybWF0KGludGVydmFsKTtcclxuICAgICAgICAgICAgbGV0IG5ld1lBeGlzTGFiZWxXaWR0aDogSVlBeGlzTGFiZWxSYW5nZSA9IHRoaXMuX2NoYXJ0U3ZjLmdldFlBeGlzTWF4QW5kTWluTGFiZWxXaWR0aCh7IGF4aXNNaW46IHRoaXMuYXhpc01pbiwgYXhpc01heDogdGhpcy5heGlzTWF4IH0pO1xyXG4gICAgICAgICAgICBpZiAobmV3WUF4aXNMYWJlbFdpZHRoLmF4aXNNYXggIT09IGluaXRZQXhpc0xhYmVsV2lkdGguYXhpc01heCB8fCBuZXdZQXhpc0xhYmVsV2lkdGguYXhpc01pbiAhPT0gaW5pdFlBeGlzTGFiZWxXaWR0aC5heGlzTWluKSB7XHJcbiAgICAgICAgICAgICAgICByZXR1cm4geyBuZWVkUmVkcmF3OiB0cnVlLCBpbnRlcnZhbDogaW50ZXJ2YWwgfTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgcmV0dXJuIHsgbmVlZFJlZHJhdzogZmFsc2UsIGludGVydmFsOiBpbnRlcnZhbCB9O1xyXG4gICAgfVxyXG5cclxuICAgIC8vID09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PSBHcmlkIExpbmVzID09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT1cclxuXHJcbiAgICBwcml2YXRlIF9zZXRHcmlkTGluZXMoKTogdm9pZCB7XHJcbiAgICAgICAgaWYgKCF0aGlzLmdyaWRMaW5lc0NvbnRhaW5lcikgdGhpcy5ncmlkTGluZXNDb250YWluZXIgPSB0aGlzLmdyYXBoLmFwcGVuZCgnZycpLmF0dHIoJ2NsYXNzJywgJ2tkeC1jaGFydHMtZ3JpZC1saW5lLWNvbnRhaW5lcicpO1xyXG4gICAgICAgIHRoaXMuX2NoYXJ0U3ZjLmdyaWRTdmMuZ3JhcGhEaW1lbnNpb24gPSB7IHdpZHRoOiB0aGlzLndpZHRoLCBoZWlnaHQ6IHRoaXMuaGVpZ2h0IH07XHJcbiAgICAgICAgaWYgKHRoaXMuX2NoYXJ0U3ZjLmdyaWRTdmMuaGF2ZUdyaWQodGhpcy5jb25maWcsICd4QXhpcycsICdncmlkTGluZScpKSB0aGlzLl9zZXRYQXhpc0dyaWQoKTtcclxuICAgICAgICBpZiAodGhpcy5fY2hhcnRTdmMuZ3JpZFN2Yy5oYXZlR3JpZCh0aGlzLmNvbmZpZywgJ3lBeGlzJywgJ21pbm9yR3JpZExpbmUnKSkgdGhpcy5fc2V0WUF4aXNNaW5vckdyaWQoKTtcclxuICAgICAgICBpZiAodGhpcy5fY2hhcnRTdmMuZ3JpZFN2Yy5oYXZlR3JpZCh0aGlzLmNvbmZpZywgJ3lBeGlzJywgJ2dyaWRMaW5lJykpIHRoaXMuX3NldFlBeGlzR3JpZCgpO1xyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX3NldFhBeGlzR3JpZCgpIHtcclxuICAgICAgICAvLyB3cmFwcGVyIGZ1bmN0aW9uIGFyb3VuZCB0aGlzLnggc28gdGhhdCBncmlkIHdpbGwgYmUgZHJhd24gaW4gY2VudGVyIG9mIHBhZGRpbmdJbm5lclxyXG4gICAgICAgIGxldCBzY2FsZSA9IHRoaXMuX2NoYXJ0U3ZjLmdyaWRTdmMueEF4aXNHcmlkU2NhbGUodGhpcy54KTtcclxuICAgICAgICAvLyBjb25jYXQgc3BhY2UgdG8gZHJhdyBmaXJzdCBncmlkIGxpbmUsIE5vdGU6IHRoaXMuZGF0YSBtYXkgaGF2ZSBiZWVuIHNwbGljZWQgYnkgdHJpbVhcclxuICAgICAgICBsZXQgeERhdGE6IEFycmF5PHN0cmluZz4gPSBbJyddLmNvbmNhdCh0aGlzLmRhdGEubWFwKGRhdGEgPT4gZGF0YS54LnZhbHVlKSk7XHJcbiAgICAgICAgLy8gbGV0IHhEYXRhOiBBcnJheTxzdHJpbmc+ID0gWycnXS5jb25jYXQoX2NhdGVnb3JpZXMpO1xyXG4gICAgICAgIHRoaXMuX2NoYXJ0U3ZjLmdyaWRTdmMuZHJhd0dyaWRMaW5lKHRoaXMuZ3JpZExpbmVzQ29udGFpbmVyLCB4RGF0YSwgJ3hBeGlzJywgJ2dyaWRMaW5lJywgc2NhbGUpO1xyXG4gICAgfVxyXG5cclxuICAgIC8vIGRyYXcgbWFqb3IgZ3JpZCBsaW5lXHJcbiAgICBwcml2YXRlIF9zZXRZQXhpc0dyaWQoKSB7XHJcbiAgICAgICAgdGhpcy5fY2hhcnRTdmMuZ3JpZFN2Yy5kcmF3R3JpZExpbmUodGhpcy5ncmlkTGluZXNDb250YWluZXIsIHRoaXMudGlja1ZhbHVlcywgJ3lBeGlzJywgJ2dyaWRMaW5lJywgdGhpcy55KTtcclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF9zZXRZQXhpc01pbm9yR3JpZCgpIHtcclxuICAgICAgICBsZXQgeUF4aXNDb25maWc6IElZQXhpc0NvbmZpZyA9IHRoaXMuY29uZmlnLnlBeGlzO1xyXG4gICAgICAgIGlmICh5QXhpc0NvbmZpZy5taW5vclRpY2tJbnRlcnZhbCA+PSB5QXhpc0NvbmZpZy50aWNrSW50ZXJ2YWwgfHwgIXlBeGlzQ29uZmlnLm1pbm9yVGlja0ludGVydmFsKSByZXR1cm47XHJcblxyXG4gICAgICAgIGxldCB1cHBlcmJvdW5kOiBudW1iZXIgPSB0aGlzLl9jaGFydFN2Yy5zZXRBeGlzUm91bmRWYWx1ZSh0aGlzLmRvbWFpbk1heCwgeUF4aXNDb25maWcubWlub3JUaWNrSW50ZXJ2YWwsIGZhbHNlLCAndXAnKTtcclxuICAgICAgICBsZXQgbG93ZXJib3VuZDogbnVtYmVyID0gdGhpcy5fY2hhcnRTdmMuc2V0QXhpc1JvdW5kVmFsdWUodGhpcy5kb21haW5NaW4sIHlBeGlzQ29uZmlnLm1pbm9yVGlja0ludGVydmFsLCBmYWxzZSwgJ2Rvd24nKTtcclxuICAgICAgICBsZXQgbWlub3JUaWNrVmFsdWVzOiBBcnJheTxudW1iZXI+ID0gdGhpcy5fY2hhcnRTdmMuZ2V0VGlja1ZhbHVlcyhsb3dlcmJvdW5kLCB1cHBlcmJvdW5kLCB5QXhpc0NvbmZpZy5taW5vclRpY2tJbnRlcnZhbCk7XHJcblxyXG4gICAgICAgIHRoaXMuX2NoYXJ0U3ZjLmdyaWRTdmMuZHJhd0dyaWRMaW5lKHRoaXMuZ3JpZExpbmVzQ29udGFpbmVyLCBtaW5vclRpY2tWYWx1ZXMsICd5QXhpcycsICdtaW5vckdyaWRMaW5lJywgdGhpcy55KTtcclxuICAgIH1cclxuXHJcbiAgICAvLyA9PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT0gQXhpcyA9PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09XHJcblxyXG4gICAgcHVibGljIHNldEF4aXMoKTogdm9pZCB7XHJcbiAgICAgICAgbGV0IHRyYW5zZm9ybVBvczogSUF4aXNUcmFuc2Zvcm1Qb3MgPSB7XHJcbiAgICAgICAgICAgIHJpZ2h0OiAndHJhbnNsYXRlKCcgKyB0aGlzLndpZHRoICsgJywwKScsXHJcbiAgICAgICAgICAgIGxlZnQ6ICd0cmFuc2xhdGUoMCwwKScsXHJcbiAgICAgICAgICAgIHRvcDogJ3RyYW5zbGF0ZSgwLDApJyxcclxuICAgICAgICAgICAgYm90dG9tOiAndHJhbnNsYXRlKDAsJyArIHRoaXMuaGVpZ2h0ICsgJyknXHJcbiAgICAgICAgfTtcclxuXHJcbiAgICAgICAgbGV0IHhBeGlzQ29uZmlnOiBJWEF4aXNDb25maWcgPSB0aGlzLmNvbmZpZy54QXhpcztcclxuICAgICAgICBsZXQgeUF4aXNDb25maWc6IElZQXhpc0NvbmZpZyA9IHRoaXMuY29uZmlnLnlBeGlzO1xyXG4gICAgICAgIGxldCBpbnZlcnQ6IGJvb2xlYW4gPSB0aGlzLmJhci5pc0ludmVydDtcclxuICAgICAgICBsZXQgb3Bwb3NpdGU6IHsgeDogYm9vbGVhbiwgeTogYm9vbGVhbiB9ID0ge1xyXG4gICAgICAgICAgICB4OiBpbnZlcnQgPyB4QXhpc0NvbmZpZy5vcHBvc2l0ZSAhPT0gdGhpcy5pc1J0bCA6IHhBeGlzQ29uZmlnLm9wcG9zaXRlLFxyXG4gICAgICAgICAgICB5OiBpbnZlcnQgPyB5QXhpc0NvbmZpZy5vcHBvc2l0ZSA6IHlBeGlzQ29uZmlnLm9wcG9zaXRlICE9PSB0aGlzLmlzUnRsXHJcbiAgICAgICAgfTtcclxuXHJcbiAgICAgICAgbGV0IHhBeGlzID0gdGhpcy5fZ2V0RWFjaEF4aXNGdW5jKCd4Jywgb3Bwb3NpdGUueCwgaW52ZXJ0KTtcclxuICAgICAgICB0aGlzLnhBeGlzQXJyLnB1c2goeEF4aXMpO1xyXG4gICAgICAgIHRoaXMueUF4aXMgPSB0aGlzLl9nZXRFYWNoQXhpc0Z1bmMoJ3knLCBvcHBvc2l0ZS55LCBpbnZlcnQpO1xyXG5cclxuICAgICAgICB4QXhpcy5hdHRyKCd0cmFuc2Zvcm0nLCB0aGlzLl9jaGFydFN2Yy5nZXRBeGlzVHJhbnNmb3JtUG9zKCd4Jywgb3Bwb3NpdGUueCwgdHJhbnNmb3JtUG9zKSk7XHJcbiAgICAgICAgdGhpcy55QXhpcy5hdHRyKCd0cmFuc2Zvcm0nLCB0aGlzLl9jaGFydFN2Yy5nZXRBeGlzVHJhbnNmb3JtUG9zKCd5Jywgb3Bwb3NpdGUueSwgdHJhbnNmb3JtUG9zKSk7XHJcblxyXG4gICAgICAgIHRoaXMuX2NoYXJ0U3ZjLnNldEF4aXNMYWJlbENvbmZpZyh4QXhpcywgJ3gnKTtcclxuICAgICAgICB0aGlzLl9jaGFydFN2Yy5zZXRBeGlzTGFiZWxDb25maWcodGhpcy55QXhpcywgJ3knKTtcclxuXHJcbiAgICAgICAgaWYgKHRoaXMuX2NoYXJ0U3ZjLmlzTmVnYXRpdmVTdGFjaykge1xyXG4gICAgICAgICAgICBsZXQgc2Vjb25kWEF4aXMgPSB0aGlzLl9nZXRFYWNoQXhpc0Z1bmMoJ3gnLCAhb3Bwb3NpdGUueCwgdGhpcy5iYXIuaXNJbnZlcnQpO1xyXG4gICAgICAgICAgICBzZWNvbmRYQXhpcy5hdHRyKCd0cmFuc2Zvcm0nLCB0aGlzLl9jaGFydFN2Yy5nZXRBeGlzVHJhbnNmb3JtUG9zKCd4JywgIW9wcG9zaXRlLngsIHRyYW5zZm9ybVBvcykpO1xyXG4gICAgICAgICAgICB0aGlzLl9jaGFydFN2Yy5zZXRBeGlzTGFiZWxDb25maWcoc2Vjb25kWEF4aXMsICd4Jyk7XHJcbiAgICAgICAgICAgIHRoaXMueEF4aXNBcnIucHVzaChzZWNvbmRYQXhpcyk7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX2dldEVhY2hBeGlzRnVuYyhfYXhpczogJ3gnIHwgJ3knLCBfb3Bwb3NpdGU6IGJvb2xlYW4sIF9pbnZlcnQ6IGJvb2xlYW4pOiBhbnkge1xyXG4gICAgICAgIGxldCBheGlzRnVuYyA9IGdldEF4aXNGdW5jKF9heGlzLCB0aGlzW19heGlzXSk7XHJcbiAgICAgICAgbGV0IGF4aXNDbGFzczogc3RyaW5nID0gJ2tkeC1jaGFydHMtYXhpcyBheGlzLScgKyBfYXhpcztcclxuXHJcbiAgICAgICAgaWYgKChfaW52ZXJ0ICYmIF9heGlzID09PSAneCcpIHx8ICghX2ludmVydCAmJiBfYXhpcyA9PT0gJ3knKSkge1xyXG4gICAgICAgICAgICBheGlzQ2xhc3MgKz0gJyBrZHgtY2hhcnRzLWF4aXMtdmVydGljYWwnO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgaWYgKF9vcHBvc2l0ZSkgYXhpc0NsYXNzICs9ICcga2R4LWNoYXJ0cy1heGlzLW9wcG9zaXRlJztcclxuXHJcbiAgICAgICAgaWYgKF9heGlzID09PSAneScpIHtcclxuICAgICAgICAgICAgYXhpc0Z1bmNcclxuICAgICAgICAgICAgICAgIC50aWNrVmFsdWVzKHRoaXMudGlja1ZhbHVlcylcclxuICAgICAgICAgICAgICAgIC50aWNrRm9ybWF0KChkKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgLy8gbm90ZTogb25seSB1c2VjYXNlIGlzIG5lZ2F0aXZlIHN0YWNrIGJhciAoaW4gdjMuNy4wKS4gd2lsbCBhZmZlY3QgYm90aCB5QXhpcyBsYWJlbCBhbmQgdG9vbHRpcCBhbmQgZGF0YUxhYmVsc1xyXG4gICAgICAgICAgICAgICAgICAgIGxldCB2YWx1ZSA9IHRoaXMuX2NoYXJ0U3ZjLmNoZWNrQW5kUmV0dXJuTGFiZWxzUG9zaXRpdmUoZCk7XHJcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIHRoaXMuX2NoYXJ0U3ZjLmdldFlBeGlzTGFiZWxUZXh0KHRoaXMuY29uZmlnLnlBeGlzLCB2YWx1ZSk7XHJcbiAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIGxldCBheGlzRWxlbSA9IHRoaXMuZ3JhcGguYXBwZW5kKCdnJykuYXR0cignY2xhc3MnLCBheGlzQ2xhc3MpLmNhbGwoYXhpc0Z1bmMpO1xyXG5cclxuICAgICAgICByZXR1cm4gYXhpc0VsZW07XHJcblxyXG4gICAgICAgIGZ1bmN0aW9uIGdldEF4aXNGdW5jKF90eXBlOiAneCcgfCAneScsIF9zY2FsZSk6IGFueSB7XHJcbiAgICAgICAgICAgIGlmIChfaW52ZXJ0KSB7XHJcbiAgICAgICAgICAgICAgICBpZiAoX3R5cGUgPT09ICd4Jykge1xyXG4gICAgICAgICAgICAgICAgICAgIGlmIChfb3Bwb3NpdGUpIHJldHVybiBkMy5heGlzUmlnaHQoX3NjYWxlKTtcclxuICAgICAgICAgICAgICAgICAgICByZXR1cm4gZDMuYXhpc0xlZnQoX3NjYWxlKTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIGlmIChfdHlwZSA9PT0gJ3knKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKF9vcHBvc2l0ZSkgcmV0dXJuIGQzLmF4aXNUb3AoX3NjYWxlKTtcclxuICAgICAgICAgICAgICAgICAgICByZXR1cm4gZDMuYXhpc0JvdHRvbShfc2NhbGUpO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgaWYgKF90eXBlID09PSAneCcpIHtcclxuICAgICAgICAgICAgICAgICAgICBpZiAoX29wcG9zaXRlKSByZXR1cm4gZDMuYXhpc1RvcChfc2NhbGUpO1xyXG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBkMy5heGlzQm90dG9tKF9zY2FsZSk7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICBpZiAoX3R5cGUgPT09ICd5Jykge1xyXG4gICAgICAgICAgICAgICAgICAgIGlmIChfb3Bwb3NpdGUpIHJldHVybiBkMy5heGlzUmlnaHQoX3NjYWxlKTtcclxuICAgICAgICAgICAgICAgICAgICByZXR1cm4gZDMuYXhpc0xlZnQoX3NjYWxlKTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuXHJcbiAgICB9XHJcblxyXG4gICAgLy8gPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09IFJlbW92ZSBDaGFydCA9PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09XHJcblxyXG4gICAgcHVibGljIGNoYXJ0VGltZW91dChfY2FsbGJhY2s6IEZ1bmN0aW9uKTogdm9pZCB7XHJcbiAgICAgICAgLy8gbGV0IGRlbGF5ID0gdGhpcy5jb25maWcubGVnZW5kLmVuYWJsZWQgJiYgdGhpcy5jaGFydENhdGVnb3J5ID09PSAncGllJz8gNTAwIDogMTA7XHJcbiAgICAgICAgY2xlYXJUaW1lb3V0KHRoaXMuX3NldENoYXJ0VGltZW91dCk7XHJcbiAgICAgICAgdGhpcy5fc2V0Q2hhcnRUaW1lb3V0ID0gc2V0VGltZW91dCgoKTogdm9pZCA9PiB7XHJcbiAgICAgICAgICAgIF9jYWxsYmFjaygpO1xyXG4gICAgICAgIH0pO1xyXG4gICAgfVxyXG5cclxuXHJcbiAgICBwdWJsaWMgcmVtb3ZlQ2hhcnQoKTogdm9pZCB7XHJcbiAgICAgICAgY2xlYXJUaW1lb3V0KHRoaXMuX3NldENoYXJ0VGltZW91dCk7XHJcbiAgICAgICAgdGhpcy5fcmVtb3ZlRWxlbUluQXJyYXlGb3JtKCd4QXhpc0FycicsIChheGlzKSA9PiBheGlzLnJlbW92ZSgpKTtcclxuICAgICAgICBpZiAodGhpcy55QXhpcykgdGhpcy55QXhpcy5yZW1vdmUoKTtcclxuICAgICAgICBpZiAodGhpcy5kYXRhTGFiZWxDb250YWluZXIpIHRoaXMuZGF0YUxhYmVsQ29udGFpbmVyLnNlbGVjdEFsbCgnKicpLnJlbW92ZSgpO1xyXG4gICAgICAgIHRoaXMuX3JlbW92ZUVsZW1JbkFycmF5Rm9ybSgnYXhpc0xhYmVsQ29udGFpbmVyQXJyJywgKGNvbnRhaW5lcikgPT4gY29udGFpbmVyLnNlbGVjdEFsbCgnKicpLnJlbW92ZSgpKTtcclxuICAgICAgICBpZiAodGhpcy5ncmlkTGluZXNDb250YWluZXIpIHRoaXMuZ3JpZExpbmVzQ29udGFpbmVyLnNlbGVjdEFsbCgnKicpLnJlbW92ZSgpO1xyXG4gICAgICAgIHRoaXMuX2NsZWFyU3ZnRGltZW5zaW9uKCk7XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfcmVtb3ZlRWxlbUluQXJyYXlGb3JtKF9rZXk6IHN0cmluZywgY2FsbGJhY2s6IEZ1bmN0aW9uKTogdm9pZCB7XHJcbiAgICAgICAgaWYgKHRoaXNbX2tleV0ubGVuZ3RoICE9PSAwKSB7XHJcbiAgICAgICAgICAgIHRoaXNbX2tleV0uZm9yRWFjaChlbGVtZW50ID0+IGNhbGxiYWNrKGVsZW1lbnQpKTtcclxuICAgICAgICAgICAgdGhpc1tfa2V5XSA9IFtdO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICAvLyA9PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT0gQXhpcyBMYWJlbCA9PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09XHJcblxyXG4gICAgcHJpdmF0ZSBfc2V0WEF4aXNMYWJlbChfeFNjYWxlVHlwZTogJ3N0cmluZycgfCAnYmFuZCcsIF9sb25nZXN0VGV4dDogc3RyaW5nKTogdm9pZCB7XHJcbiAgICAgICAgaWYgKCF0aGlzLmNvbmZpZy54QXhpcy5lbmFibGVkIHx8ICF0aGlzLmNvbmZpZy54QXhpcy5sYWJlbHMuZW5hYmxlZCkgcmV0dXJuO1xyXG5cclxuICAgICAgICBpZiAodGhpcy5heGlzTGFiZWxDb250YWluZXJBcnIubGVuZ3RoICE9PSAwKSB7XHJcbiAgICAgICAgICAgIHRoaXMuX3JlbW92ZUVsZW1JbkFycmF5Rm9ybSgnYXhpc0xhYmVsQ29udGFpbmVyQXJyJywgKGNvbnRhaW5lcikgPT4gY29udGFpbmVyLnNlbGVjdEFsbCgnKicpLnJlbW92ZSgpKTtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIGxldCB4U3BhY2luZzogbnVtYmVyID0gdGhpcy5fY2FsY3VsYXRlWFNwYWNpbmcoX3hTY2FsZVR5cGUpO1xyXG5cclxuICAgICAgICB0aGlzLl9jaGFydFN2Yy5zZXRBeGlzTGFiZWxEdW1teSh0aGlzLmNvbmZpZy5pZCwgeFNwYWNpbmcsIF9sb25nZXN0VGV4dCk7XHJcbiAgICAgICAgdGhpcy5fY2hhcnRTdmMuX3NldEF4aXNMYWJlbExlbmd0aCgpO1xyXG5cclxuICAgICAgICB0aGlzLl9zZXRBeGlzTGFiZWxDb250YWluZXIoKTtcclxuXHJcbiAgICAgICAgaWYgKHRoaXMuX2NoYXJ0U3ZjLmxhYmVsTGVuZ3RoICE9PSAwKSB0aGlzLl90cmltWChfeFNjYWxlVHlwZSk7XHJcblxyXG4gICAgICAgIHRoaXMuYXhpc0xhYmVsQ29udGFpbmVyQXJyLmZvckVhY2goKF9heGlzTGFiZWxDb250YWluZXIsIGluZGV4KSA9PiB7XHJcbiAgICAgICAgICAgIHRoaXMuX2NoYXJ0U3ZjLnNldEF4aXNMYWJlbENvbnRhaW5lclN0eWxlKF9heGlzTGFiZWxDb250YWluZXIpO1xyXG4gICAgICAgICAgICAvLyBpZiBkcmF3aW5nIDJuZCBheGlzLCBzZXQgdG8gY29tcGxlbWVudCBvZiBvcHBvc2l0ZSBvZiAxc3QgYXhpc1xyXG4gICAgICAgICAgICBpZiAodGhpcy5fY2hhcnRTdmMubGFiZWxMZW5ndGggIT09IDApIHtcclxuICAgICAgICAgICAgICAgIGxldCBvcHBvc2l0ZSA9IGluZGV4ID09PSAxID8gIXRoaXMuY29uZmlnLnhBeGlzLm9wcG9zaXRlIDogdGhpcy5jb25maWcueEF4aXMub3Bwb3NpdGU7XHJcbiAgICAgICAgICAgICAgICB0aGlzLl9kcmF3QXhpc0xhYmVsKFxyXG4gICAgICAgICAgICAgICAgICAgIF9heGlzTGFiZWxDb250YWluZXIsXHJcbiAgICAgICAgICAgICAgICAgICAgeyBsYWJlbEhlaWdodDogdGhpcy5fY2hhcnRTdmMubGFiZWxMZW5ndGgsIGxhYmVsV2lkdGg6IHhTcGFjaW5nIH0sXHJcbiAgICAgICAgICAgICAgICAgICAgeyBpc1JvdGF0ZTogdGhpcy5fY2hhcnRTdmMuaXNSb3RhdGUsIG9wcG9zaXRlOiBvcHBvc2l0ZSB9XHJcbiAgICAgICAgICAgICAgICApO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfSk7XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfc2V0QXhpc0xhYmVsQ29udGFpbmVyKCk6IHZvaWQge1xyXG4gICAgICAgIHRoaXMuYXhpc0xhYmVsQ29udGFpbmVyQXJyLnB1c2godGhpcy5fY2hhcnRTdmMuc2V0QXhpc0xhYmVsQ29udGFpbmVyKCkpO1xyXG5cclxuICAgICAgICAvLyByZW5kZXIgMm5kIGF4aXNcclxuICAgICAgICBpZiAodGhpcy5fY2hhcnRTdmMuaXNOZWdhdGl2ZVN0YWNrKSB7XHJcbiAgICAgICAgICAgIHRoaXMuYXhpc0xhYmVsQ29udGFpbmVyQXJyLnB1c2godGhpcy5fY2hhcnRTdmMuc2V0QXhpc0xhYmVsQ29udGFpbmVyKCcua2R4LWNoYXJ0cy1kb3VibGUtYXhpcy14JykpO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF9jYWxjdWxhdGVYU3BhY2luZyhfeFNjYWxlVHlwZTogJ3N0cmluZycgfCAnYmFuZCcpOiBudW1iZXIge1xyXG4gICAgICAgIHJldHVybiAoX3hTY2FsZVR5cGUgPT09ICdiYW5kJykgPyB0aGlzLnguYmFuZHdpZHRoKCkgKyB0aGlzLngucGFkZGluZ0lubmVyKCkgKiB0aGlzLnguc3RlcCgpIDogdGhpcy53aWR0aCAvICh0aGlzLmRhdGEubGVuZ3RoIC0gMSk7XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfdHJpbVgoX3hTY2FsZVR5cGU6ICdzdHJpbmcnIHwgJ2JhbmQnKTogdm9pZCB7XHJcbiAgICAgICAgbGV0IG1heE5vT2ZYOiBudW1iZXIgPSB0aGlzLl9jYWxjdWxhdGVNYXhOb09mWCh0aGlzLl9jaGFydFN2Yy5pc1JvdGF0ZSwgX3hTY2FsZVR5cGUpO1xyXG5cclxuICAgICAgICBpZiAobWF4Tm9PZlggPT09IHRoaXMuaW5pdERhdGEubGVuZ3RoKSByZXR1cm47XHJcblxyXG4gICAgICAgIC8vIGlmIHRoZSBpbml0YWwgZGF0YSBjYW5ub3QgZml0IGludG8gbWF4U3BhY2UsIHNsaWNlIGFuZCBzYXZlIHRvIHRoaXMuZGF0YVxyXG4gICAgICAgIHRoaXMuZGF0YSA9IHRoaXMuaW5pdERhdGEuc2xpY2UoMCwgbWF4Tm9PZlgpO1xyXG4gICAgICAgIGxldCB4SW5mbzogSVhJbmZvID0gdGhpcy5fY2hhcnRTdmMuZ2V0WEluZm8odGhpcy5kYXRhLCB0aGlzLmNvbmZpZyk7XHJcblxyXG4gICAgICAgIC8vIHVwZGF0ZSBkb21haW4gd2l0aCB0aGUgdXBkYXRlZCB0aGlzLmRhdGFcclxuICAgICAgICBpZiAodGhpcy5jaGFydENhdGVnb3J5ID09PSAnbGluZScpIHRoaXMuX3NldExpbmVTY2FsZVgoX3hTY2FsZVR5cGUpO1xyXG4gICAgICAgIHRoaXMueC5kb21haW4oeEluZm8udmFsdWUpO1xyXG5cclxuICAgICAgICAvLyBhZnRlciB0cmltbWluZywgdGhlIGxvbmdlc3QgYXhpcyBsYWJlbCBtYXkgbm90IGJlIHNhbWUuIGhlbmNlIHJlY2FsY3VsYXRlIHRoZSBheGlzIGxhYmVsIGNvbnRhaW5lciBoZWlnaHRcclxuICAgICAgICB0aGlzLl9jaGFydFN2Yy5zZXRBeGlzTGFiZWxEdW1teVRleHQoeEluZm8ubG9uZ2VzdFRleHQpO1xyXG4gICAgICAgIHRoaXMuX2NoYXJ0U3ZjLl9zZXRBeGlzTGFiZWxMZW5ndGgoKTtcclxuICAgIH1cclxuXHJcbiAgICAvLyB0aGlzLmRhdGEgd2lsbCBiZSBjaGFuZ2VkL3RyaW1lZCBhY2NvcmRpbmcgdG8gc3BhY2UgZ2l2ZW5cclxuICAgIHByaXZhdGUgX2NhbGN1bGF0ZU1heE5vT2ZYKF9pc1JvdGF0ZTogYm9vbGVhbiwgX3hTY2FsZVR5cGU6ICdzdHJpbmcnIHwgJ2JhbmQnKTogbnVtYmVyIHtcclxuICAgICAgICBpZiAoIV9pc1JvdGF0ZSAmJiAhdGhpcy5iYXIuaXNJbnZlcnQpIHJldHVybiB0aGlzLmluaXREYXRhLmxlbmd0aDtcclxuXHJcbiAgICAgICAgbGV0IG9mZnNldDogbnVtYmVyID0gdGhpcy5jaGFydENhdGVnb3J5ID09PSAnYmFyJyA/ICh0aGlzLngucGFkZGluZ091dGVyKCkpICogMiA6IDA7XHJcbiAgICAgICAgbGV0IG1heFNwYWNlOiBudW1iZXIgPSAodGhpcy5iYXIuaXNJbnZlcnQgPyB0aGlzLmhlaWdodCA6IHRoaXMud2lkdGgpIC0gb2Zmc2V0O1xyXG4gICAgICAgIC8vIG5vdGU6IHdoZW4gcm90YXRpbmcgb3Igd2hlbiBjaGFydFR5cGUgPT0gJ2JhcicsIGF4aXNMQWJlbER1bW15IHdpbGwgbm90IHRleHQtd3JhcFxyXG4gICAgICAgIGxldCBlYWNoSXRlbVNpemU6IG51bWJlciA9IHRoaXMuX2NoYXJ0U3ZjLmdldEF4aXNMYWJlbER1bW15UmVjdCgpLmhlaWdodDtcclxuICAgICAgICBsZXQgbWF4Tm9PZlg6IG51bWJlciA9IE1hdGguZmxvb3IobWF4U3BhY2UgLyBlYWNoSXRlbVNpemUpO1xyXG5cclxuICAgICAgICBpZiAoX3hTY2FsZVR5cGUgPT09ICdzdHJpbmcnKSBtYXhOb09mWCArPSAxO1xyXG5cclxuICAgICAgICByZXR1cm4gTWF0aC5taW4odGhpcy5pbml0RGF0YS5sZW5ndGgsIG1heE5vT2ZYKTtcclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF9kcmF3QXhpc0xhYmVsKF9jb250YWluZXI6IGFueSwgX2xhYmVsRGltZW5zdGlvbjogeyBsYWJlbEhlaWdodDogbnVtYmVyLCBsYWJlbFdpZHRoOiBudW1iZXIgfSwgX2Jvb2xlYW5DaGVja3M6IElBeGlzTGFiZWxCb29sZWFuQ2hlY2tzKTogdm9pZCB7XHJcbiAgICAgICAgbGV0IGZpcnN0VGljazogbnVtYmVyID0gMCwgeEF4aXNMYWJlbENvbmZpZyA9IHRoaXMuY29uZmlnLnhBeGlzLmxhYmVscztcclxuICAgICAgICBpZiAodGhpcy5jaGFydENhdGVnb3J5ID09PSAnYmFyJykgZmlyc3RUaWNrID0gdGhpcy54LnBhZGRpbmdPdXRlcigpICogdGhpcy54LnN0ZXAoKSArIHRoaXMueC5iYW5kd2lkdGgoKSAvIDI7XHJcblxyXG4gICAgICAgIHRoaXMuZGF0YS5mb3JFYWNoKChkLCB4SW5kZXgpID0+IHtcclxuICAgICAgICAgICAgbGV0IGxhYmVsQ29udGFpbmVyOiBhbnksIHRpY2tQb3M6IG51bWJlcjtcclxuICAgICAgICAgICAgbGFiZWxDb250YWluZXIgPSBfY29udGFpbmVyLmFwcGVuZCgnZGl2JylcclxuICAgICAgICAgICAgICAgIC5hdHRyKCdjbGFzcycsICdrZHgtY2hhcnRzLWF4aXMtbGFiZWwgeC0nICsgeEluZGV4KVxyXG4gICAgICAgICAgICAgICAgLmh0bWwodGhpcy5fY2hhcnRTdmMuZ2V0TGFiZWxGb3JtYXRSZXBsYWNlKHhBeGlzTGFiZWxDb25maWcuZm9ybWF0LCBkLngubGFiZWwpKTtcclxuXHJcbiAgICAgICAgICAgIGlmIChfYm9vbGVhbkNoZWNrcy5pc1JvdGF0ZSkge1xyXG4gICAgICAgICAgICAgICAgbGFiZWxDb250YWluZXIuc3R5bGUoJ21heC13aWR0aCcsIF9sYWJlbERpbWVuc3Rpb24ubGFiZWxIZWlnaHQgKyAncHgnKTtcclxuICAgICAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgICAgIGlmICghdGhpcy5iYXIuaXNJbnZlcnQpIGxhYmVsQ29udGFpbmVyLnN0eWxlKCdtYXgtd2lkdGgnLCBfbGFiZWxEaW1lbnN0aW9uLmxhYmVsV2lkdGggKyAncHgnKTtcclxuICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgaWYgKHRoaXMuY2hhcnRDYXRlZ29yeSA9PT0gJ2JhcicpIHtcclxuICAgICAgICAgICAgICAgIGxldCBvcmRlckZyb21MZWZ0ID0gdGhpcy5fY2hhcnRTdmMuaXNYUmV2ZXJzZWQgPyB0aGlzLmRhdGEubGVuZ3RoIC0geEluZGV4IC0gMSA6IHhJbmRleDtcclxuICAgICAgICAgICAgICAgIHRpY2tQb3MgPSBmaXJzdFRpY2sgKyB0aGlzLnguc3RlcCgpICogb3JkZXJGcm9tTGVmdDtcclxuICAgICAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgICAgIHRpY2tQb3MgPSB0aGlzLnJhbmdlTGlzdFt0aGlzLmRhdGFbeEluZGV4XS54LnZhbHVlXTtcclxuICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgdGhpcy5fY2hhcnRTdmMuc2V0QXhpc0xhYmVsUG9zaXRpb24obGFiZWxDb250YWluZXIsIHRpY2tQb3MsIE9iamVjdC5hc3NpZ24oX2Jvb2xlYW5DaGVja3MsIHsgaXNMYXN0OiB4SW5kZXggPT09IHRoaXMuZGF0YS5sZW5ndGggLSAxIH0pKTtcclxuICAgICAgICB9KTtcclxuICAgIH1cclxuXHJcbiAgICAvLyA9PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT0gQ2FwdHVyZSBIb3ZlciBFdmVudCA9PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09XHJcblxyXG4gICAgLyoqXHJcbiAgICAgKiBfcGFyYW1zIGNhbiBiZSBJRDNEYXRhRGF0YSBvciBjYW4gY29udGFpbiBjYWxsYmFja3NcclxuICAgICAqIHtcclxuICAgICAqICAgICAuLi5cclxuICAgICAqICAgICBjYWxsYmFja3M6IHtcclxuICAgICAqICAgICAgICAgJ21vdXNlb3Zlcic6IEZ1bmN0aW9uLFxyXG4gICAgICogICAgICAgICAnbW91c2VvdXQnOiBGdW5jdGlvblxyXG4gICAgICogICAgIH1cclxuICAgICAqIH1cclxuICAgICAqL1xyXG5cclxuICAgIHB1YmxpYyBfaW5pdE1vdXNlRXZlbnRzKF9wYXRoOiBhbnksIF9wYXJhbXM/OiBhbnkpOiB2b2lkIHsgICAgICAgXHJcbiAgICAgICBsZXQgbWFwQ29uZGl0aW9uOiBib29sZWFuID0gKHRoaXMuY2hhcnRUeXBlWzBdID09PSAnbWFwJyAmJiAodGhpcy5jaGFydFR5cGVbMV0gPT09ICdmdWxsJyB8fCB0aGlzLmNoYXJ0VHlwZVsxXSA9PT0gJ2ZpbHRlcicpKTtcclxuICAgICAgICBpZiAoIXRoaXMuY29uZmlnLnRvb2x0aXAuZW5hYmxlZCkgcmV0dXJuO1xyXG5cclxuICAgICAgICBsZXQgdG9vbHRpcDogYW55O1xyXG4gICAgICAgIF9wYXRoLm9uKCdtb3VzZW92ZXInLCAoZCwgaW5kZXgpID0+IHtcclxuICAgICAgICAgICAgbGV0IHRvcDogbnVtYmVyID0gbWFwQ29uZGl0aW9uID8gcGFyc2VJbnQoX3BhcmFtcy5mdWxsR3JhcGgubm9kZSgpLnN0eWxlLnRvcCkgKyBkMy5ldmVudC5sYXllclkgOiBkMy5ldmVudC5sYXllclk7XHJcbiAgICAgICAgICAgIGxldCBsZWZ0OiBudW1iZXIgPSBtYXBDb25kaXRpb24gPyBwYXJzZUludChfcGFyYW1zLmZ1bGxHcmFwaC5ub2RlKCkuc3R5bGUubGVmdCkgKyBkMy5ldmVudC5sYXllclggOiBkMy5ldmVudC5sYXllclg7XHJcbiAgICAgICAgICAgIGxldCBncmFwaFBvaW50ZXI6IGFueSA9IChtYXBDb25kaXRpb24gJiYgX3BhcmFtcy50b29sdGlwTGF5ZXIpID8gX3BhcmFtcy50b29sdGlwTGF5ZXIgOiB0aGlzLnN2Z1BhcmVudDtcclxuICAgICAgICAgICAgdG9vbHRpcCA9IGdyYXBoUG9pbnRlci5zZWxlY3QoJy5rZHgtY2hhcnRzLXRvb2x0aXAnKTtcclxuXHJcbiAgICAgICAgICAgIC8vIGlmIHRvb2x0aXAgYWxyZWFkeSBleGlzdCAoaW4gY2FzZSBtb3VzZW91dCBkaWQgbm90IGhhcHBlbiksIGRvbid0IGFwcGVuZCBhbnltb3JlLlxyXG4gICAgICAgICAgICBpZiAodG9vbHRpcC5lbXB0eSgpKSB7XHJcbiAgICAgICAgICAgICAgICB0b29sdGlwID0gZ3JhcGhQb2ludGVyLmFwcGVuZCgnZGl2JykuYXR0cignY2xhc3MnLCAna2R4LWNoYXJ0cy10b29sdGlwJyk7XHJcbiAgICAgICAgICAgICAgICB0b29sdGlwLmFwcGVuZCgnZGl2JykuYXR0cignY2xhc3MnLCAna2R4LWNoYXJ0cy10b29sdGlwLWxhYmVsJyk7XHJcbiAgICAgICAgICAgICAgICB0b29sdGlwLmFwcGVuZCgnZGl2JykuYXR0cignY2xhc3MnLCAna2R4LWNoYXJ0cy10b29sdGlwLWNvdW50Jyk7XHJcbiAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgIGxldCBsYWJlbDogc3RyaW5nO1xyXG4gICAgICAgICAgICBsZXQgY291bnQ6IG51bWJlciB8IHN0cmluZztcclxuICAgICAgICAgICAgLy8gbGV0IGNvbmZpZzogSUNoYXJ0Q29uZmlnID0gdGhpcy5fY2hhcnRTdmMuY29uZmlnO1xyXG4gICAgICAgICAgICBsZXQgdmFsdWU6IG51bWJlcjtcclxuXHJcbiAgICAgICAgICAgIGlmICh0aGlzLmNoYXJ0VHlwZSAmJiAodGhpcy5jaGFydFR5cGVbMF0gPT09ICdwaWUnIHx8IHRoaXMuY2hhcnRUeXBlWzBdID09PSAnZG9udXQnKSkge1xyXG4gICAgICAgICAgICAgICAgbGFiZWwgPSBkLmRhdGEueC5yZXBsYWNlKC/CrC9nLCAnICcpO1xyXG4gICAgICAgICAgICAgICAgY291bnQgPSBkLmRhdGEueTtcclxuICAgICAgICAgICAgICAgIF9wYXJhbXMucGF0aEFuaW0oZDMuc2VsZWN0KF9wYXRoLl9ncm91cHNbMF1baW5kZXhdKSwgdHJ1ZSwgX3BhcmFtcy5pbm5lclJhZGl1cywgX3BhcmFtcy5vdXRlclJhZGl1cyk7XHJcbiAgICAgICAgICAgICAgICBkMy5zZWxlY3QoX3BhdGguX2dyb3Vwc1swXVtpbmRleF0pLnN0eWxlKCdvcGFjaXR5JywgJzAuNycpO1xyXG4gICAgICAgICAgICB9IGVsc2UgaWYgKHRoaXMuY2hhcnRUeXBlICYmIHRoaXMuY2hhcnRUeXBlWzBdID09PSAncmFkaWFsJykge1xyXG4gICAgICAgICAgICAgICAgbGFiZWwgPSBkLngucmVwbGFjZSgvwqwvZywgJyAnKTtcclxuICAgICAgICAgICAgICAgIGNvdW50ID0gZC55O1xyXG4gICAgICAgICAgICAgICAgZDMuc2VsZWN0KF9wYXRoLl9ncm91cHNbMF1baW5kZXhdKS5zdHlsZSgnb3BhY2l0eScsICcwLjcnKTtcclxuICAgICAgICAgICAgfSBlbHNlIGlmICh0aGlzLmNoYXJ0Q2F0ZWdvcnkgPT09ICdiYXInKSB7XHJcbiAgICAgICAgICAgICAgICBsYWJlbCA9IF9wYXJhbXMuZGF0YS54LmxhYmVsO1xyXG4gICAgICAgICAgICAgICAgY291bnQgPSB0aGlzLl9jaGFydFN2Yy5jaGVja0FuZFJldHVybkxhYmVsc1Bvc2l0aXZlKGQudmFsdWUgfHwgMCk7XHJcbiAgICAgICAgICAgICAgICBsYWJlbCA9IGxhYmVsLnRvU3RyaW5nKCkgKyAnICcgKyB0aGlzLmxlZ2VuZERhdGFbZC5pZF0ubmFtZTtcclxuICAgICAgICAgICAgICAgIGQzLnNlbGVjdChfcGF0aC5fZ3JvdXBzWzBdW2luZGV4XSkuc3R5bGUoJ29wYWNpdHknLCAnMC43Jyk7XHJcbiAgICAgICAgICAgIH0gZWxzZSBpZiAodGhpcy5jaGFydENhdGVnb3J5ID09PSAnbGluZScpIHtcclxuICAgICAgICAgICAgICAgIGxhYmVsID0gX3BhcmFtcy5kYXRhLngubGFiZWw7XHJcbiAgICAgICAgICAgICAgICBjb3VudCA9IF9wYXJhbXMuZGF0YS55W2luZGV4XS52YWx1ZTtcclxuICAgICAgICAgICAgICAgIGxhYmVsID0gbGFiZWwudG9TdHJpbmcoKSArICcgJyArIHRoaXMubGVnZW5kRGF0YVtkXS5uYW1lO1xyXG4gICAgICAgICAgICB9IGVsc2UgaWYgKHRoaXMuY2hhcnRDYXRlZ29yeSA9PT0gJ21hcCcpIHtcclxuICAgICAgICAgICAgICAgIGZvciAobGV0IGkgPSAwOyBpIDwgX3BhcmFtcy5zZXJpZXNEYXRhLmxlbmd0aDsgaSsrKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKGQucHJvcGVydGllcy5JRF8gPT0gX3BhcmFtcy5zZXJpZXNEYXRhW2ldLmlkKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGxhYmVsID0gX3BhcmFtcy5zZXJpZXNEYXRhW2ldLm5hbWU7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvdW50ID0gX3BhcmFtcy5zZXJpZXNOYW1lICsgJzogJyArIF9wYXJhbXMuc2VyaWVzRGF0YVtpXS52YWx1ZTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWUgPSBfcGFyYW1zLnNlcmllc0RhdGFbaV0udmFsdWU7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgY291bnQgPSB0aGlzLl9jaGFydFN2Yy5nZXRMYWJlbFRleHQodGhpcy5jb25maWcudG9vbHRpcC5mb3JtYXQsIGNvdW50KTtcclxuICAgICAgICAgICAgdG9vbHRpcC5zZWxlY3QoJy5rZHgtY2hhcnRzLXRvb2x0aXAtbGFiZWwnKS5odG1sKGxhYmVsLnRvVXBwZXJDYXNlKCkpO1xyXG4gICAgICAgICAgICBpZiAodGhpcy5jaGFydFR5cGVbMV0gIT09ICdmaWx0ZXInKSB0b29sdGlwLnNlbGVjdCgnLmtkeC1jaGFydHMtdG9vbHRpcC1jb3VudCcpLmh0bWwoY291bnQpLnN0eWxlKCdmb250LXdlaWdodCcsICdib2xkJyk7XHJcblxyXG4gICAgICAgICAgICB0b29sdGlwLmF0dHIoJ3N0eWxlJywgdGhpcy5fY2hhcnRTdmMuZ2V0U3R5bGUoT2JqZWN0LmFzc2lnbih7fSwgVE9PTFRJUF9ERUZBVUxUX1NUWUxFKSwgdHJ1ZSkpO1xyXG4gICAgICAgICAgICB0b29sdGlwLnN0eWxlKCdkaXNwbGF5JywgJ2Jsb2NrJyk7XHJcbiAgICAgICAgICAgIHRvb2x0aXAuc3R5bGUoJ29wYWNpdHknLCAyKTtcclxuICAgICAgICAgICAgdG9vbHRpcC5zdHlsZSgnei1pbmRleCcsIDQwMyk7XHJcblxyXG4gICAgICAgICAgICBpZiAodGhpcy5jaGFydENhdGVnb3J5ID09PSAnbGluZScpIHtcclxuICAgICAgICAgICAgICAgIF9wYXJhbXMuZG90SG92ZXIodGhpcy5nZXREb3RJZChfcGFyYW1zLnhJbmRleCwgZCksIHRydWUpO1xyXG4gICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICBpZiAoX3BhcmFtcyAmJiBfcGFyYW1zLmNhbGxiYWNrcyAmJiBfcGFyYW1zLmNhbGxiYWNrcy5tb3VzZW92ZXIpIF9wYXJhbXMuY2FsbGJhY2tzLm1vdXNlb3Zlcih2YWx1ZSk7XHJcblxyXG4gICAgICAgICAgICAvLyBpbiBjYXNlIG1vdXNlbW92ZSBkaWQgbm90IHRyaWdnZXIsIHBvc2l0aW9uIHRvb2x0aXAgb25jZSB0b29sdGlwIGlzIGNyZWF0ZWRcclxuICAgICAgICAgICAgaWYgKHRoaXMuY2hhcnRDYXRlZ29yeSAhPT0gJ21hcCcpIHtcclxuICAgICAgICAgICAgICAgIHRoaXMuX2NoYXJ0U3ZjLnRvb2x0aXBTdmMucG9zaXRpb25Ub29sdGlwKHRvb2x0aXAsIHsgdG9wOiBkMy5ldmVudC5sYXllclksIGxlZnQ6IGQzLmV2ZW50LmxheWVyWCB9KTtcclxuICAgICAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgICAgIGlmICh2YWx1ZSB8fCB2YWx1ZSA9PT0gMCkgdGhpcy5fY2hhcnRTdmMudG9vbHRpcFN2Yy5wb3NpdGlvblRvb2x0aXAodG9vbHRpcCwgeyB0b3A6IHRvcCwgbGVmdDogbGVmdCB9KTtcclxuICAgICAgICAgICAgICAgIGVsc2UgdG9vbHRpcC5yZW1vdmUoKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH0pO1xyXG5cclxuICAgICAgICBfcGF0aC5vbignbW91c2Vtb3ZlJywgKGQpID0+IHtcclxuICAgICAgICAgICAgbGV0IHRvcDogbnVtYmVyID0gbWFwQ29uZGl0aW9uID8gcGFyc2VJbnQoX3BhcmFtcy5mdWxsR3JhcGgubm9kZSgpLnN0eWxlLnRvcCkgKyBkMy5ldmVudC5sYXllclkgOiBkMy5ldmVudC5sYXllclk7XHJcbiAgICAgICAgICAgIGxldCBsZWZ0OiBudW1iZXIgPSBtYXBDb25kaXRpb24gPyBwYXJzZUludChfcGFyYW1zLmZ1bGxHcmFwaC5ub2RlKCkuc3R5bGUubGVmdCkgKyBkMy5ldmVudC5sYXllclggOiBkMy5ldmVudC5sYXllclg7XHJcbiAgICAgICAgICAgIC8vIHBvc2l0aW9uIHRoZSB0b29sdGlwIHRvIHRoZSBjdXJzb3JcclxuICAgICAgICAgICAgdGhpcy5fY2hhcnRTdmMudG9vbHRpcFN2Yy5wb3NpdGlvblRvb2x0aXAodG9vbHRpcCwgeyB0b3A6IHRvcCwgbGVmdDogbGVmdCB9KTtcclxuICAgICAgICB9KTtcclxuXHJcbiAgICAgICAgX3BhdGgub24oJ21vdXNlb3V0JywgKGQsIGluZGV4KSA9PiB7XHJcbiAgICAgICAgICAgIGlmICh0aGlzLmNoYXJ0VHlwZSAmJiAodGhpcy5jaGFydFR5cGVbMF0gPT09ICdwaWUnIHx8IHRoaXMuY2hhcnRUeXBlWzBdID09PSAnZG9udXQnIHx8IHRoaXMuY2hhcnRUeXBlWzBdID09PSAncmFkaWFsJyB8fCB0aGlzLmNoYXJ0Q2F0ZWdvcnkgPT09ICdiYXInKSkge1xyXG4gICAgICAgICAgICAgICAgaWYgKHRoaXMuY2hhcnRUeXBlWzBdID09PSAncGllJyB8fCB0aGlzLmNoYXJ0VHlwZVswXSA9PT0gJ2RvbnV0Jykge1xyXG4gICAgICAgICAgICAgICAgICAgIGxldCB0aGlzUGF0aDogYW55ID0gZDMuc2VsZWN0KF9wYXRoLl9ncm91cHNbMF1baW5kZXhdKTtcclxuICAgICAgICAgICAgICAgICAgICBpZiAoIXRoaXNQYXRoLmNsYXNzZWQoJ2NsaWNrZWQnKSkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBfcGFyYW1zLnBhdGhBbmltKHRoaXNQYXRoLCBmYWxzZSwgX3BhcmFtcy5pbm5lclJhZGl1cywgX3BhcmFtcy5vdXRlclJhZGl1cyk7XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgZDMuc2VsZWN0KF9wYXRoLl9ncm91cHNbMF1baW5kZXhdKS5zdHlsZSgnb3BhY2l0eScsICcxJyk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgLy8gdG9vbHRpcC5zdHlsZSgnZGlzcGxheScsICdub25lJyk7XHJcbiAgICAgICAgICAgIC8vIHRvb2x0aXAuc3R5bGUoJ29wYWNpdHknLCAwKTtcclxuICAgICAgICAgICAgdG9vbHRpcC5yZW1vdmUoKTtcclxuXHJcbiAgICAgICAgICAgIGlmICh0aGlzLmNoYXJ0Q2F0ZWdvcnkgPT09ICdsaW5lJykge1xyXG4gICAgICAgICAgICAgICAgX3BhcmFtcy5kb3RIb3Zlcih0aGlzLmdldERvdElkKF9wYXJhbXMueEluZGV4LCBkKSk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgaWYgKF9wYXJhbXMgJiYgX3BhcmFtcy5jYWxsYmFja3MgJiYgX3BhcmFtcy5jYWxsYmFja3MubW91c2VvdXQpIF9wYXJhbXMuY2FsbGJhY2tzLm1vdXNlb3V0KCk7XHJcbiAgICAgICAgfSk7XHJcblxyXG4gICAgICAgIF9wYXRoLm9uKCdjbGljaycsIChkLCBpbmRleCkgPT4ge1xyXG4gICAgICAgICAgICBpZiAodGhpcy5jaGFydFR5cGUgJiYgKHRoaXMuY2hhcnRUeXBlWzBdID09PSAncGllJyB8fCB0aGlzLmNoYXJ0VHlwZVswXSA9PT0gJ2RvbnV0JykpIHtcclxuICAgICAgICAgICAgICAgIGxldCB0aGlzUGF0aDogYW55ID0gZDMuc2VsZWN0KF9wYXRoLl9ncm91cHNbMF1baW5kZXhdKTtcclxuICAgICAgICAgICAgICAgIGxldCBjbGlja2VkOiBib29sZWFuID0gdGhpc1BhdGguY2xhc3NlZCgnY2xpY2tlZCcpO1xyXG4gICAgICAgICAgICAgICAgX3BhcmFtcy5wYXRoQW5pbSh0aGlzUGF0aCwgIWNsaWNrZWQsIF9wYXJhbXMuaW5uZXJSYWRpdXMsIF9wYXJhbXMub3V0ZXJSYWRpdXMpO1xyXG4gICAgICAgICAgICAgICAgdGhpc1BhdGguY2xhc3NlZCgnY2xpY2tlZCcsICFjbGlja2VkKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH0pO1xyXG4gICAgfVxyXG5cclxuICAgIC8vID09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PSBMQUJFTCA9PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09XHJcblxyXG4gICAgcHVibGljIHNldExhYmVsKF95RGF0YTogSUQzWURhdGEsIF94RGF0YTogc3RyaW5nIHwgbnVtYmVyLCBfeFBvc2l0aW9uOiBudW1iZXIsIF95UG9zaXRpb246IG51bWJlcik6IGFueSB7XHJcbiAgICAgICAgaWYgKCF0aGlzLmNvbmZpZy5jaGFydC5sYWJlbHMuZW5hYmxlZCkgcmV0dXJuO1xyXG5cclxuICAgICAgICBsZXQgbGFiZWxDb25maWc6IElEYXRhTGFiZWwgPSB0aGlzLmNvbmZpZy5jaGFydC5sYWJlbHM7XHJcblxyXG4gICAgICAgIGxldCBsYWJlbENvbnRhaW5lcjogYW55ID0gdGhpcy5kYXRhTGFiZWxDb250YWluZXIuYXBwZW5kKCdkaXYnKVxyXG4gICAgICAgICAgICAuYXR0cignY2xhc3MnLCAna2R4LWNoYXJ0cy1kYXRhLWxhYmVsIHgtJyArIF94RGF0YSArICcgeS0nICsgX3lEYXRhLmlkKTtcclxuXHJcbiAgICAgICAgbGV0IGxhYmVsVGV4dDogc3RyaW5nID0gdGhpcy5fY2hhcnRTdmMuZ2V0TGFiZWxUZXh0KGxhYmVsQ29uZmlnLmZvcm1hdCwgX3lEYXRhLnZhbHVlKTtcclxuXHJcbiAgICAgICAgbGFiZWxDb250YWluZXJcclxuICAgICAgICAgICAgLmFwcGVuZCgnZGl2JylcclxuICAgICAgICAgICAgLmF0dHIoJ2NsYXNzJywgJ2tkeC1jaGFydHMtZGF0YS1sYWJlbC10ZXh0JylcclxuICAgICAgICAgICAgLmh0bWwobGFiZWxUZXh0KVxyXG4gICAgICAgICAgICAuYXR0cignc3R5bGUnLCB0aGlzLl9jaGFydFN2Yy5nZXRTdHlsZShsYWJlbENvbmZpZy5zdHlsZSkpO1xyXG5cclxuICAgICAgICB0aGlzLl9zZXRMYWJlbFBvc2l0aW9uKGxhYmVsQ29udGFpbmVyLCBfeURhdGEuc3VtIHx8IF95RGF0YS52YWx1ZSwgX3hQb3NpdGlvbiwgX3lQb3NpdGlvbik7XHJcblxyXG4gICAgICAgIHJldHVybiBsYWJlbENvbnRhaW5lcjtcclxuICAgIH1cclxuXHJcbiAgICBwdWJsaWMgdHJhbnNmb3JtUG9zaXRpb24oeDogbnVtYmVyIHwgc3RyaW5nLCB5OiBudW1iZXIgfCBzdHJpbmcsIGlzQXR0cmlidXRlPzogYm9vbGVhbik6IHN0cmluZyB7XHJcbiAgICAgICAgcmV0dXJuICd0cmFuc2xhdGUoJyArIHggKyAoKGlzQXR0cmlidXRlKSA/ICcsJyA6ICdweCwnKSArIHkgKyAoKGlzQXR0cmlidXRlKSA/ICcpJyA6ICdweCknKTtcclxuICAgIH1cclxuXHJcbiAgICBwdWJsaWMgZ2V0RG90SWQoeERhdGE6IHN0cmluZyB8IG51bWJlciwgeUlkOiBzdHJpbmcpOiBzdHJpbmcge1xyXG4gICAgICAgIHJldHVybiAna2R4LWNoYXJ0cy1wb2ludC1kb3QgeC0nICsgeERhdGEgKyAnIHktJyArIHlJZDtcclxuICAgIH1cclxuXHJcbiAgICBwdWJsaWMgaXNEYXRhRXhpc3QoX2l0ZW06IGFueSwgX3lJbmRleDogbnVtYmVyKTogYm9vbGVhbiB7XHJcbiAgICAgICAgcmV0dXJuIHRoaXMuX2NoYXJ0U3ZjLmlzRXhpc3QoX2l0ZW0ueVtfeUluZGV4XSk7XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfc2V0TGFiZWxDb250YWluZXIoKTogdm9pZCB7XHJcbiAgICAgICAgdGhpcy5kYXRhTGFiZWxDb250YWluZXIgPSBkMy5zZWxlY3QoJyMnICsgdGhpcy5jb25maWcuaWQgKyAnLmtkeC1jaGFydHMgJyArICcua2R4LWNoYXJ0cy1kYXRhLWxhYmVsLWNvbnRhaW5lcicpO1xyXG4gICAgfVxyXG5cclxuICAgIC8qKlxyXG4gICAgICogX3BhcmFtcyBmb3IgYmFyOiB7IHZhbHVlU2lnbjogLTEgb3IgMCBvciAxLCBkaW1lbnNpb25zOiB3aWR0aCwgaGVpZ2h0LCB4UG9zLCB5UG9zfVxyXG4gICAgICogX3BhcmFtcyBmb3IgbGluZTogeyBkb3RTaXplOiBudW1iZXIsIGxhYmVsTGVuZ3RoOiBudW1iZXJ9XHJcbiAgICAgKi9cclxuICAgIC8vIGFmZmVjdHMgYWxsIGNoYXJ0cyBleGNlcHQgcGllLCBtYXAsIGhvcml6b250YWwgYmFyICh3aGljaCB1c2VzIGZsZXggZm9yIHZlcnRpY2FsIGFsaWduLCByZWZlciB0byBrZC1iYXItY2hhcnQpXHJcbiAgICBwdWJsaWMgc2V0TGFiZWxUZXh0UG9zaXRpb24obGFiZWxUZXh0LCBfeVBvc2l0aW9uOiBudW1iZXIsIF9wYXJhbXM6IHsgW2tleTogc3RyaW5nXTogYW55IH0gPSB7fSk6IHZvaWQge1xyXG4gICAgICAgIGxldCBzdG9yZTogSUxhYmVsVGV4dFZlcnRpY2FsQWxpZ25TdG9yZSA9IExBQkVMX1RFWFRfVkVSVElDQUxfQUxJR05fU1RPUkU7XHJcbiAgICAgICAgbGV0IHZlcnRpY2FsQWxpZ246ICd0b3AnIHwgJ21pZGRsZScgfCAnYm90dG9tJyA9IHRoaXMuX2NoYXJ0U3ZjLmdldERlZmF1bHRWZXJ0aWNhbEFsaWduKHRoaXMuY29uZmlnLCBfcGFyYW1zKTtcclxuICAgICAgICBsZXQgZG90U2l6ZTogbnVtYmVyID0gX3BhcmFtcy5kb3RTaXplID8gX3BhcmFtcy5kb3RTaXplIDogMDtcclxuICAgICAgICBsZXQgb2Zmc2V0OiBudW1iZXIgPSBkb3RTaXplIC8gMjtcclxuXHJcbiAgICAgICAgaWYgKHZlcnRpY2FsQWxpZ24gPT09ICdtaWRkbGUnKSB7XHJcbiAgICAgICAgICAgIGxldCBjaGVja3MgPSBbJ3RvcCcsICdib3R0b20nXTtcclxuICAgICAgICAgICAgY2hlY2tzLmZvckVhY2goa2V5ID0+IHtcclxuICAgICAgICAgICAgICAgIGlmICh0aGlzLl9jaGFydFN2Yy5fY2hlY2tCb3VuZGFyeShzdG9yZVtrZXldLmNoZWNrLCBfeVBvc2l0aW9uLCB0aGlzLmhlaWdodCwgZG90U2l6ZSkpIHtcclxuICAgICAgICAgICAgICAgICAgICB2ZXJ0aWNhbEFsaWduID0gc3RvcmVba2V5XS5jaGFuZ2VUbztcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgfSBlbHNlIGlmICh0aGlzLl9jaGFydFN2Yy5fY2hlY2tCb3VuZGFyeShzdG9yZVt2ZXJ0aWNhbEFsaWduXS5jaGVjaywgX3lQb3NpdGlvbiwgdGhpcy5oZWlnaHQsIGRvdFNpemUpKSB7XHJcbiAgICAgICAgICAgIHZlcnRpY2FsQWxpZ24gPSBzdG9yZVt2ZXJ0aWNhbEFsaWduXS5jaGFuZ2VUbztcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIGxldCB5UG9zOiBzdHJpbmcgPSAnJztcclxuICAgICAgICBpZiAodmVydGljYWxBbGlnbiA9PT0gJ21pZGRsZScpIHtcclxuICAgICAgICAgICAgeVBvcyA9IHN0b3JlW3ZlcnRpY2FsQWxpZ25dLnBlcmNlbnQ7XHJcbiAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgbGV0IHNpZ246IHN0cmluZyA9IHZlcnRpY2FsQWxpZ24gPT09ICd0b3AnID8gJyAtICcgOiAnICsgJztcclxuICAgICAgICAgICAgaWYgKHRoaXMuY2hhcnRDYXRlZ29yeSA9PT0gJ2JhcicgJiYgdGhpcy5fY2hhcnRTdmMubmVlZE9mZnNldEZvckNvbHVtbih2ZXJ0aWNhbEFsaWduLCBfcGFyYW1zKSkgb2Zmc2V0ICs9IF9wYXJhbXMuZGltZW5zaW9ucy5oZWlnaHQ7XHJcbiAgICAgICAgICAgIHlQb3MgPSAnY2FsYygnICsgc3RvcmVbdmVydGljYWxBbGlnbl0ucGVyY2VudCArIHNpZ24gKyBvZmZzZXQudG9TdHJpbmcoKSArICdweCknO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgbGV0IHhQb3M6IHN0cmluZyA9IChfcGFyYW1zLmxhYmVsTGVuZ3RoICYmIF9wYXJhbXMubGFiZWxMZW5ndGggPiAxKSA/ICdjYWxjKC01MCUgKyAnICsgZG90U2l6ZSAvIDIgKyAncHgpJyA6ICcwJSc7XHJcblxyXG4gICAgICAgIGxldCB0cmFuc2xhdGU6IHN0cmluZyA9IHRoaXMuY2hhcnRDYXRlZ29yeSA9PT0gJ2xpbmUnID8gdGhpcy50cmFuc2Zvcm1Qb3NpdGlvbih4UG9zLCB5UG9zLCB0cnVlKSA6ICd0cmFuc2xhdGVZKCcgKyB5UG9zICsgJyknO1xyXG4gICAgICAgIGxhYmVsVGV4dC5zdHlsZSgndHJhbnNmb3JtJywgdHJhbnNsYXRlKTtcclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF9zZXRMYWJlbFBvc2l0aW9uKGxhYmVsQ29udGFpbmVyOiBhbnksIF95VmFsdWU6IG51bWJlciwgX3hQb3NpdGlvbjogbnVtYmVyLCBfeVBvc2l0aW9uOiBudW1iZXIpOiB2b2lkIHtcclxuICAgICAgICBsZXQgZGVmYXVsdFBvc2l0aW9uOiB7IHg6IG51bWJlciwgeTogbnVtYmVyIH0gPSB7XHJcbiAgICAgICAgICAgIHg6ICgodGhpcy5iYXIuaXNJbnZlcnQpID8gdGhpcy5oZWlnaHQgOiAwKSxcclxuICAgICAgICAgICAgeTogKCh0aGlzLmJhci5pc0ludmVydCkgPyB0aGlzLndpZHRoIDogMClcclxuICAgICAgICB9O1xyXG4gICAgICAgIGxldCB4OiBudW1iZXIgPSAodHlwZW9mIF94UG9zaXRpb24gPT09ICdudW1iZXInKSA/IF94UG9zaXRpb24gOiBkZWZhdWx0UG9zaXRpb24ueDtcclxuICAgICAgICBsZXQgeTogbnVtYmVyID0gKHR5cGVvZiBfeVBvc2l0aW9uID09PSAnbnVtYmVyJykgPyBfeVBvc2l0aW9uIDogZGVmYXVsdFBvc2l0aW9uLnk7XHJcblxyXG4gICAgICAgIC8vIGlmIChfeVBvc2l0aW9uIDwgdGhpcy5kYXRhTGFiZWxQdXNoRG93blJhbmdlKSB7XHJcbiAgICAgICAgLy8gICAgIHkgPSA1O1xyXG4gICAgICAgIC8vIH1cclxuXHJcbiAgICAgICAgaWYgKHRoaXMuaXNSdGwpIHggPSAodGhpcy53aWR0aCAqIC0xKSArIHg7XHJcblxyXG4gICAgICAgIGlmIChfeVZhbHVlICYmIChfeVZhbHVlID4gdGhpcy5kb21haW5NYXggfHwgX3lWYWx1ZSA8IHRoaXMuZG9tYWluTWluKSkge1xyXG4gICAgICAgICAgICBsYWJlbENvbnRhaW5lci5zdHlsZSgnZGlzcGxheScsICdub25lJyk7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICB0aGlzLl9hcHBseUxhYmVsUG9zaXRpb24obGFiZWxDb250YWluZXIsIHgsIHkpO1xyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX2FwcGx5TGFiZWxQb3NpdGlvbihsYWJlbENvbnRhaW5lcjogYW55LCBfeFBvc2l0aW9uOiBudW1iZXIsIF95UG9zaXRpb246IG51bWJlcik6IHZvaWQge1xyXG4gICAgICAgIGxldCByb3RhdGU6IHN0cmluZyA9ICcnO1xyXG4gICAgICAgIGxldCBsYWJlbFN0eWxlOiB7IFtrZXk6IHN0cmluZ106IHN0cmluZyB9ID0gdGhpcy5jb25maWcuY2hhcnQubGFiZWxzLnN0eWxlO1xyXG5cclxuICAgICAgICAvLyB0aGlzLmNvbmZpZy5jaGFydC5sYWJlbHMucm90YXRpb24gY2Fubm90IGJlICcnIG9yIG51bGwgb3Igb3RoZXIgbm9uLXZhbHVlXHJcbiAgICAgICAgaWYgKGxhYmVsU3R5bGUuaGFzT3duUHJvcGVydHkoJ3JvdGF0aW9uJykgJiYgbGFiZWxTdHlsZS5yb3RhdGlvbikge1xyXG4gICAgICAgICAgICByb3RhdGUgPSAnIHJvdGF0ZSgnICsgbGFiZWxTdHlsZS5yb3RhdGlvbiArICdkZWcpJztcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIGxhYmVsQ29udGFpbmVyXHJcbiAgICAgICAgICAgIC5zdHlsZSgndHJhbnNmb3JtJywgdGhpcy50cmFuc2Zvcm1Qb3NpdGlvbihfeFBvc2l0aW9uLCBfeVBvc2l0aW9uKSArIHJvdGF0ZSk7XHJcblxyXG4gICAgICAgIGlmICh0aGlzLmlzUnRsKSBsYWJlbENvbnRhaW5lci5zdHlsZSgndGV4dC1hbGlnbicsICdyaWdodCcpO1xyXG4gICAgfVxyXG59XHJcbiJdfQ==