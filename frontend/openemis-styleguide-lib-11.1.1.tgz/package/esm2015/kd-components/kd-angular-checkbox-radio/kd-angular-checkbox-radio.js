import { Directive, Input, ViewContainerRef, } from '@angular/core';
export class KdCheckboxRadio {
    constructor(_vcr) {
        this._vcr = _vcr;
    }
    ngOnInit() {
        let currentEle = this._vcr.element.nativeElement;
        let warpper = document.createElement('div');
        warpper.className = 'selection-wrapper';
        currentEle.parentNode.insertBefore(warpper, currentEle);
        warpper.appendChild(currentEle);
        let label = document.createElement('label');
        if (typeof this.inputText !== 'undefined' && this.inputText !== '') {
            label.innerHTML = this.inputText;
        }
        warpper.appendChild(label);
    }
}
KdCheckboxRadio.decorators = [
    { type: Directive, args: [{
                selector: '[kd-checkbox-radio]'
            },] }
];
KdCheckboxRadio.ctorParameters = () => [
    { type: ViewContainerRef }
];
KdCheckboxRadio.propDecorators = {
    inputText: [{ type: Input, args: ['kd-checkbox-radio',] }]
};
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoia2QtYW5ndWxhci1jaGVja2JveC1yYWRpby5qcyIsInNvdXJjZVJvb3QiOiJEOi9vcGVuRU1JUy9zdHlsZWd1aWRlL2lvc3RnLW9wZW5lbWlzLXN0eWxlZ3VpZGUvcHJvamVjdHMvb3BlbmVtaXMtc3R5bGVndWlkZS1saWIvc3JjLyIsInNvdXJjZXMiOlsia2QtY29tcG9uZW50cy9rZC1hbmd1bGFyLWNoZWNrYm94LXJhZGlvL2tkLWFuZ3VsYXItY2hlY2tib3gtcmFkaW8udHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsT0FBTyxFQUNILFNBQVMsRUFFVCxLQUFLLEVBQ0wsZ0JBQWdCLEdBQ25CLE1BQU0sZUFBZSxDQUFDO0FBTXZCLE1BQU0sT0FBTyxlQUFlO0lBR3hCLFlBQW9CLElBQXNCO1FBQXRCLFNBQUksR0FBSixJQUFJLENBQWtCO0lBQUksQ0FBQztJQUUvQyxRQUFRO1FBQ0osSUFBSSxVQUFVLEdBQUcsSUFBSSxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsYUFBYSxDQUFDO1FBQ2pELElBQUksT0FBTyxHQUFHLFFBQVEsQ0FBQyxhQUFhLENBQUMsS0FBSyxDQUFDLENBQUM7UUFDNUMsT0FBTyxDQUFDLFNBQVMsR0FBRyxtQkFBbUIsQ0FBQztRQUN4QyxVQUFVLENBQUMsVUFBVSxDQUFDLFlBQVksQ0FBQyxPQUFPLEVBQUUsVUFBVSxDQUFDLENBQUM7UUFDeEQsT0FBTyxDQUFDLFdBQVcsQ0FBQyxVQUFVLENBQUMsQ0FBQztRQUNoQyxJQUFJLEtBQUssR0FBRyxRQUFRLENBQUMsYUFBYSxDQUFDLE9BQU8sQ0FBQyxDQUFDO1FBQzVDLElBQUksT0FBTyxJQUFJLENBQUMsU0FBUyxLQUFLLFdBQVcsSUFBSSxJQUFJLENBQUMsU0FBUyxLQUFLLEVBQUUsRUFBRTtZQUNoRSxLQUFLLENBQUMsU0FBUyxHQUFHLElBQUksQ0FBQyxTQUFTLENBQUM7U0FDcEM7UUFDRCxPQUFPLENBQUMsV0FBVyxDQUFDLEtBQUssQ0FBQyxDQUFDO0lBQy9CLENBQUM7OztZQXBCSixTQUFTLFNBQUM7Z0JBQ1AsUUFBUSxFQUFFLHFCQUFxQjthQUNsQzs7O1lBTEcsZ0JBQWdCOzs7d0JBUWYsS0FBSyxTQUFDLG1CQUFtQiIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7XHJcbiAgICBEaXJlY3RpdmUsXHJcbiAgICBPbkluaXQsXHJcbiAgICBJbnB1dCxcclxuICAgIFZpZXdDb250YWluZXJSZWYsXHJcbn0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XHJcblxyXG5ARGlyZWN0aXZlKHtcclxuICAgIHNlbGVjdG9yOiAnW2tkLWNoZWNrYm94LXJhZGlvXSdcclxufSlcclxuXHJcbmV4cG9ydCBjbGFzcyBLZENoZWNrYm94UmFkaW8gaW1wbGVtZW50cyBPbkluaXQge1xyXG4gICAgQElucHV0KCdrZC1jaGVja2JveC1yYWRpbycpIGlucHV0VGV4dDogc3RyaW5nO1xyXG5cclxuICAgIGNvbnN0cnVjdG9yKHByaXZhdGUgX3ZjcjogVmlld0NvbnRhaW5lclJlZikgeyB9XHJcblxyXG4gICAgbmdPbkluaXQoKTogdm9pZCB7XHJcbiAgICAgICAgbGV0IGN1cnJlbnRFbGUgPSB0aGlzLl92Y3IuZWxlbWVudC5uYXRpdmVFbGVtZW50O1xyXG4gICAgICAgIGxldCB3YXJwcGVyID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnZGl2Jyk7XHJcbiAgICAgICAgd2FycHBlci5jbGFzc05hbWUgPSAnc2VsZWN0aW9uLXdyYXBwZXInO1xyXG4gICAgICAgIGN1cnJlbnRFbGUucGFyZW50Tm9kZS5pbnNlcnRCZWZvcmUod2FycHBlciwgY3VycmVudEVsZSk7XHJcbiAgICAgICAgd2FycHBlci5hcHBlbmRDaGlsZChjdXJyZW50RWxlKTtcclxuICAgICAgICBsZXQgbGFiZWwgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdsYWJlbCcpO1xyXG4gICAgICAgIGlmICh0eXBlb2YgdGhpcy5pbnB1dFRleHQgIT09ICd1bmRlZmluZWQnICYmIHRoaXMuaW5wdXRUZXh0ICE9PSAnJykge1xyXG4gICAgICAgICAgICBsYWJlbC5pbm5lckhUTUwgPSB0aGlzLmlucHV0VGV4dDtcclxuICAgICAgICB9XHJcbiAgICAgICAgd2FycHBlci5hcHBlbmRDaGlsZChsYWJlbCk7XHJcbiAgICB9XHJcbn1cclxuIl19