import { Injectable } from '@angular/core';
export class KdMultiSelectTableSvc {
    getBothOptions(_config, _masterData, _slaveData) {
        // let masterData = (typeof config.masterData != "undefined") ? config.masterData.slice() : [];
        // let slaveData = (typeof config.slaveData != "undefined") ? config.slaveData.slice() : [];
        // console.log(_config);
        // console.log(_masterData);
        // console.log(_slaveData);
        let updatedOptions = {
            masterGridOption: this._getGridOptions('master', _masterData),
            slaveGridOption: this._getGridOptions('slave', _slaveData)
        };
        return updatedOptions;
    }
    getPrimarykey(config) {
        // if user set more than one primary key, only the first one will be used.
        if (typeof config.colDef !== 'undefined') {
            for (let i in config.colDef) {
                if (config.colDef[i].primaryKey) {
                    return i;
                }
            }
            return 'id';
        }
    }
    getColDefs(_colDef) {
        let updatedColDef = [];
        for (let i in _colDef) {
            if (typeof _colDef[i] !== 'undefined') {
                let tableColumn = {
                    headerName: _colDef[i].headerName,
                    field: i,
                    colId: i,
                    cellClass: 'ag-default',
                    menuTabs: []
                };
                updatedColDef.push(tableColumn);
            }
        }
        return updatedColDef;
    }
    getPlaceholder(config, grid) {
        // grid is either top or bottom
        let query = grid + 'Placeholder';
        if (typeof config.gridSetting !== 'undefined' && typeof config.gridSetting[query] !== 'undefined')
            return config.gridSetting[query];
        return 'Undefined';
    }
    getButton(config, grid) {
        // grid is either toTopBtn or toBottomBtn
        let updatedBtn = {};
        if (typeof config.gridSetting !== 'undefined' && typeof config.gridSetting[grid].icon !== 'undefined')
            updatedBtn.icon = config.gridSetting[grid].icon;
        else
            updatedBtn.icon = '';
        if (typeof config.gridSetting[grid] !== 'undefined' && typeof config.gridSetting[grid].text !== 'undefined')
            updatedBtn.text = config.gridSetting[grid].text;
        else
            updatedBtn.text = 'Undefined';
        return updatedBtn;
    }
    getCheckboxDefault() {
        return {
            width: 50,
            minWidth: 50,
            maxWidth: 50,
            colId: 'checkbox',
            headerName: '',
            suppressMenu: true,
            suppressSorting: true,
            suppressSizeToFit: true,
            cellClass: 'ag-checkbox-radio'
        };
    }
    calcMobileHeight(masterGrid, slaveGrid, vcr) {
        let topData = masterGrid.api.getModel().getRowCount();
        let bottomData = slaveGrid.api.getModel().getRowCount();
        let topHeight = (typeof topData !== 'undefined' && topData > 0) ? this._getGridHeight(topData, 'top') : 150;
        let bottomHeight = (typeof bottomData !== 'undefined' && bottomData > 0) ? this._getGridHeight(bottomData, 'bottom') : 150;
        let result = {
            top: topHeight,
            bottom: bottomHeight
        };
        return result;
    }
    calcWebHeight(height) {
        let separator = 65;
        let checkedHeight = ((typeof height !== 'number') ? 600 : height) - separator;
        let bottomHeight = (checkedHeight - 38) / 2;
        let webHeight = {
            top: bottomHeight + 38,
            bottom: bottomHeight
        };
        return webHeight;
    }
    // getColDefWidth(_gridOptions: GridOptions): Array<any> {
    //     let column: Array<Column> = _gridOptions.columnApi.getAllColumns();
    //     let colWidth: Array<number> = [];
    //     for(let i: number = 0; i < column.length; i++){
    //         if(column[i].getColId() !== 'checkbox') {
    //             colWidth.push(column[i].getActualWidth() + 30);
    //         }
    //         else{
    //             colWidth.push(50);
    //         }
    //     }
    //     // console.log(colWidth);
    //     return colWidth;
    // }
    // getColTotalWidth(_colArray: Array<number>): number {
    //     let total: number = 0;
    //     for (let i: number = 0; i < _colArray.length; i++) {
    //         total += _colArray[i];
    //     }
    //     return total;
    // }
    // getUsableWidth(_vcr: ViewContainerRef): number {
    //     let agGridEle: HTMLElement = _vcr.element.nativeElement.querySelector('.stg-theme');
    //     let parentWidth: number = Math.round(agGridEle.getBoundingClientRect().width);
    //     let computedStyle: CSSStyleDeclaration = window.getComputedStyle(agGridEle);
    //     let borderLeft: number = (computedStyle.borderLeft !== '') ? parseInt(computedStyle.borderLeft) : 0;
    //     let borderRight: number = (computedStyle.borderRight !== '') ? parseInt(computedStyle.borderRight) : 0;
    //     let borderLeftRight = borderLeft + borderRight
    //     return parentWidth - borderLeftRight;
    // }
    checkSelection(topOptions, bottomOptions) {
        let updateDisabled = { top: true, bottom: true };
        updateDisabled.top = (topOptions.api.getSelectedNodes().length > 0) ? false : true;
        updateDisabled.bottom = (bottomOptions.api.getSelectedNodes().length > 0) ? false : true;
        return updateDisabled;
    }
    checkOverlay(topOptions, bottomOptions) {
        let topOverlay = (topOptions.api.getModel().getRowCount() > 0) ? false : true;
        let bottomOverlay = (bottomOptions.api.getModel().getRowCount() > 0) ? false : true;
        if (topOverlay)
            topOptions.api.showNoRowsOverlay();
        else
            topOptions.api.hideOverlay();
        if (bottomOverlay)
            bottomOptions.api.showNoRowsOverlay();
        else
            bottomOptions.api.hideOverlay();
    }
    // setRtlView(_gridOptions: GridOptions): void {
    //     let colDefLength: number = _gridOptions.columnDefs.length;
    //     for (let i: number = 0; i < colDefLength; i++) {
    //         _gridOptions.columnApi.moveColumn(0, colDefLength - (i + 1));
    //     }
    //     // _gridOptions.api.setColumnDefs(_gridOptions.columnDefs);
    //     _gridOptions.api.refreshView();
    // }
    setCheckboxFalseAfterUpdate(vcr) {
        let selectAllCheckbox = vcr.element.nativeElement.querySelectorAll('.selection-wrapper input.select-all');
        for (let i = 0; i < selectAllCheckbox.length; i++) {
            selectAllCheckbox[i].checked = false;
        }
    }
    setCheckboxFalse(removedElement) {
        for (let i = 0; i < removedElement.length; i++) {
            removedElement[i].checked = false;
        }
    }
    _getGridHeight(dataCount, grid) {
        let floatingHeight = 38;
        let headerHeight = (grid === 'top') ? 38 : 0;
        let dataHeight = 38 * dataCount;
        return (floatingHeight + headerHeight + dataHeight + 8);
        /*   height calculation based on vcr
            let totalHeight: number = 0;
            let queryEleString: string = '#' + grid;
            let nativeEle: Element = vcr.element.nativeElement.querySelector(queryEleString);
            console.log(nativeEle);
            totalHeight += Math.ceil(nativeEle.querySelector('.ag-header-container').getBoundingClientRect().height);
            totalHeight += Math.ceil(nativeEle.querySelector('.ag-body-container').getBoundingClientRect().height);
            totalHeight += Math.ceil(nativeEle.querySelector('.ag-floating-top-full-width-container').getBoundingClientRect().height);
            let paginationBottom: Element = nativeEle.querySelector('#south')
            if(paginationBottom !== null) {
                totalHeight += Math.ceil(paginationBottom.getBoundingClientRect().height);
            }

            totalHeight += 8;
            return totalHeight;
            */
    }
    _getGridOptions(grid, rowData) {
        let options = {
            // rowData: [],
            rowData: rowData,
            columnDefs: [],
            // debug: true,
            headerHeight: (grid === 'slave') ? 0 : 38,
            rowHeight: 38,
            suppressContextMenu: true,
            // suppressMenuMainPanel: true,
            // suppressMenuColumnPanel: true,
            // suppressMenuFilterPanel: true,
            suppressMovableColumns: true,
            suppressMenuHide: true,
            suppressColumnVirtualisation: true,
            enableFilter: true,
            enableSorting: true,
            enableColResize: false,
            unSortIcon: true,
            icons: {
                // use font awesome for menu icons
                // menu: '<i class='fa fa-bars'/>',
                filter: '<i class="fa fa-filter"/>',
                sortAscending: '<i class="fa fa-caret-down"/>',
                sortDescending: '<i class="fa fa-caret-up"/>',
                sortUnSort: '<i class="fa fa-sort"/>',
                groupExpanded: '<i class="fa fa-minus-circle"/>',
                groupContracted: '<i class="fa fa-plus-circle"/>'
            },
            // onGridSizeChanged: function(e) {
            //     this.api.sizeColumnsToFit();
            // },
            getRowClass: function (params) {
                if (params.data.hasOwnProperty('newRow')) {
                    delete params.data.newRow;
                    return 'new-row-highlight';
                }
                return;
            },
            alignedGrids: [],
            overlayNoRowsTemplate: '<span class="ag-custom-overlay"><i class="fa fa-info-circle fa-lg margin-right10"></i>No student record found</span>'
        };
        return options;
    }
}
KdMultiSelectTableSvc.decorators = [
    { type: Injectable }
];
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoia2QtbXVsdGlzZWxlY3QtdGFibGUtc3ZjLmpzIiwic291cmNlUm9vdCI6IkQ6L29wZW5FTUlTL3N0eWxlZ3VpZGUvaW9zdGctb3BlbmVtaXMtc3R5bGVndWlkZS9wcm9qZWN0cy9vcGVuZW1pcy1zdHlsZWd1aWRlLWxpYi9zcmMvIiwic291cmNlcyI6WyJrZC1jb21wb25lbnRzL2tkLWFuZ3VsYXItbXVsdGlzZWxlY3QtdGFibGUva2QtbXVsdGlzZWxlY3QtdGFibGUtc3ZjLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBLE9BQU8sRUFBRSxVQUFVLEVBQW9CLE1BQU0sZUFBZSxDQUFDO0FBSTdELE1BQU0sT0FBTyxxQkFBcUI7SUFDOUIsY0FBYyxDQUFDLE9BQVksRUFBRSxXQUF1QixFQUFFLFVBQXNCO1FBQ3hFLCtGQUErRjtRQUMvRiw0RkFBNEY7UUFDNUYsd0JBQXdCO1FBQ3hCLDRCQUE0QjtRQUM1QiwyQkFBMkI7UUFFM0IsSUFBSSxjQUFjLEdBQVE7WUFDdEIsZ0JBQWdCLEVBQUUsSUFBSSxDQUFDLGVBQWUsQ0FBQyxRQUFRLEVBQUUsV0FBVyxDQUFDO1lBQzdELGVBQWUsRUFBRSxJQUFJLENBQUMsZUFBZSxDQUFDLE9BQU8sRUFBRSxVQUFVLENBQUM7U0FDN0QsQ0FBQztRQUVGLE9BQU8sY0FBYyxDQUFDO0lBQzFCLENBQUM7SUFFRCxhQUFhLENBQUMsTUFBVztRQUNyQiwwRUFBMEU7UUFDMUUsSUFBSSxPQUFPLE1BQU0sQ0FBQyxNQUFNLEtBQUssV0FBVyxFQUFFO1lBQ3RDLEtBQUssSUFBSSxDQUFDLElBQUksTUFBTSxDQUFDLE1BQU0sRUFBRTtnQkFDekIsSUFBSSxNQUFNLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLFVBQVUsRUFBRTtvQkFDN0IsT0FBTyxDQUFDLENBQUM7aUJBQ1o7YUFDSjtZQUNELE9BQU8sSUFBSSxDQUFDO1NBQ2Y7SUFDTCxDQUFDO0lBRUQsVUFBVSxDQUFDLE9BQVk7UUFDbkIsSUFBSSxhQUFhLEdBQWUsRUFBRSxDQUFDO1FBQ25DLEtBQUssSUFBSSxDQUFDLElBQUksT0FBTyxFQUFFO1lBQ25CLElBQUksT0FBTyxPQUFPLENBQUMsQ0FBQyxDQUFDLEtBQUssV0FBVyxFQUFFO2dCQUNuQyxJQUFJLFdBQVcsR0FBUTtvQkFDbkIsVUFBVSxFQUFFLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxVQUFVO29CQUNqQyxLQUFLLEVBQUUsQ0FBQztvQkFDUixLQUFLLEVBQUUsQ0FBQztvQkFDUixTQUFTLEVBQUUsWUFBWTtvQkFDdkIsUUFBUSxFQUFFLEVBQUU7aUJBQ2YsQ0FBQztnQkFFRixhQUFhLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxDQUFDO2FBQ25DO1NBQ0o7UUFDRCxPQUFPLGFBQWEsQ0FBQztJQUN6QixDQUFDO0lBRUQsY0FBYyxDQUFDLE1BQVcsRUFBRSxJQUFZO1FBQ3BDLCtCQUErQjtRQUMvQixJQUFJLEtBQUssR0FBRyxJQUFJLEdBQUcsYUFBYSxDQUFDO1FBQ2pDLElBQUksT0FBTyxNQUFNLENBQUMsV0FBVyxLQUFLLFdBQVcsSUFBSSxPQUFPLE1BQU0sQ0FBQyxXQUFXLENBQUMsS0FBSyxDQUFDLEtBQUssV0FBVztZQUFFLE9BQU8sTUFBTSxDQUFDLFdBQVcsQ0FBQyxLQUFLLENBQUMsQ0FBQztRQUNwSSxPQUFPLFdBQVcsQ0FBQztJQUN2QixDQUFDO0lBRUQsU0FBUyxDQUFDLE1BQVcsRUFBRSxJQUFTO1FBQzVCLHlDQUF5QztRQUN6QyxJQUFJLFVBQVUsR0FBUSxFQUFFLENBQUM7UUFFekIsSUFBSSxPQUFPLE1BQU0sQ0FBQyxXQUFXLEtBQUssV0FBVyxJQUFJLE9BQU8sTUFBTSxDQUFDLFdBQVcsQ0FBQyxJQUFJLENBQUMsQ0FBQyxJQUFJLEtBQUssV0FBVztZQUFFLFVBQVUsQ0FBQyxJQUFJLEdBQUcsTUFBTSxDQUFDLFdBQVcsQ0FBQyxJQUFJLENBQUMsQ0FBQyxJQUFJLENBQUM7O1lBQ2xKLFVBQVUsQ0FBQyxJQUFJLEdBQUcsRUFBRSxDQUFDO1FBRTFCLElBQUksT0FBTyxNQUFNLENBQUMsV0FBVyxDQUFDLElBQUksQ0FBQyxLQUFLLFdBQVcsSUFBSSxPQUFPLE1BQU0sQ0FBQyxXQUFXLENBQUMsSUFBSSxDQUFDLENBQUMsSUFBSSxLQUFLLFdBQVc7WUFBRSxVQUFVLENBQUMsSUFBSSxHQUFHLE1BQU0sQ0FBQyxXQUFXLENBQUMsSUFBSSxDQUFDLENBQUMsSUFBSSxDQUFDOztZQUN4SixVQUFVLENBQUMsSUFBSSxHQUFHLFdBQVcsQ0FBQztRQUVuQyxPQUFPLFVBQVUsQ0FBQztJQUN0QixDQUFDO0lBRUQsa0JBQWtCO1FBQ2QsT0FBTztZQUNILEtBQUssRUFBRSxFQUFFO1lBQ1QsUUFBUSxFQUFFLEVBQUU7WUFDWixRQUFRLEVBQUUsRUFBRTtZQUNaLEtBQUssRUFBRSxVQUFVO1lBQ2pCLFVBQVUsRUFBRSxFQUFFO1lBQ2QsWUFBWSxFQUFFLElBQUk7WUFDbEIsZUFBZSxFQUFFLElBQUk7WUFDckIsaUJBQWlCLEVBQUUsSUFBSTtZQUN2QixTQUFTLEVBQUUsbUJBQW1CO1NBQ2pDLENBQUM7SUFDTixDQUFDO0lBRUQsZ0JBQWdCLENBQUMsVUFBdUIsRUFBRSxTQUFzQixFQUFFLEdBQXFCO1FBQ25GLElBQUksT0FBTyxHQUFXLFVBQVUsQ0FBQyxHQUFHLENBQUMsUUFBUSxFQUFFLENBQUMsV0FBVyxFQUFFLENBQUM7UUFDOUQsSUFBSSxVQUFVLEdBQVcsU0FBUyxDQUFDLEdBQUcsQ0FBQyxRQUFRLEVBQUUsQ0FBQyxXQUFXLEVBQUUsQ0FBQztRQUNoRSxJQUFJLFNBQVMsR0FBRyxDQUFDLE9BQU8sT0FBTyxLQUFLLFdBQVcsSUFBSSxPQUFPLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxjQUFjLENBQUMsT0FBTyxFQUFFLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUM7UUFDNUcsSUFBSSxZQUFZLEdBQUcsQ0FBQyxPQUFPLFVBQVUsS0FBSyxXQUFXLElBQUksVUFBVSxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsY0FBYyxDQUFDLFVBQVUsRUFBRSxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDO1FBQzNILElBQUksTUFBTSxHQUFRO1lBQ2QsR0FBRyxFQUFFLFNBQVM7WUFDZCxNQUFNLEVBQUUsWUFBWTtTQUN2QixDQUFDO1FBQ0YsT0FBTyxNQUFNLENBQUM7SUFDbEIsQ0FBQztJQUVELGFBQWEsQ0FBQyxNQUFjO1FBQ3hCLElBQUksU0FBUyxHQUFXLEVBQUUsQ0FBQztRQUMzQixJQUFJLGFBQWEsR0FBVyxDQUFDLENBQUMsT0FBTyxNQUFNLEtBQUssUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLEdBQUcsU0FBUyxDQUFDO1FBQ3RGLElBQUksWUFBWSxHQUFXLENBQUMsYUFBYSxHQUFHLEVBQUUsQ0FBQyxHQUFHLENBQUMsQ0FBQztRQUNwRCxJQUFJLFNBQVMsR0FBUTtZQUNqQixHQUFHLEVBQUUsWUFBWSxHQUFHLEVBQUU7WUFDdEIsTUFBTSxFQUFFLFlBQVk7U0FDdkIsQ0FBQztRQUVGLE9BQU8sU0FBUyxDQUFDO0lBQ3JCLENBQUM7SUFFRCwwREFBMEQ7SUFDMUQsMEVBQTBFO0lBQzFFLHdDQUF3QztJQUN4QyxzREFBc0Q7SUFDdEQsb0RBQW9EO0lBQ3BELDhEQUE4RDtJQUM5RCxZQUFZO0lBQ1osZ0JBQWdCO0lBQ2hCLGlDQUFpQztJQUNqQyxZQUFZO0lBQ1osUUFBUTtJQUVSLGdDQUFnQztJQUNoQyx1QkFBdUI7SUFDdkIsSUFBSTtJQUVKLHVEQUF1RDtJQUN2RCw2QkFBNkI7SUFFN0IsMkRBQTJEO0lBQzNELGlDQUFpQztJQUNqQyxRQUFRO0lBRVIsb0JBQW9CO0lBQ3BCLElBQUk7SUFFSixtREFBbUQ7SUFDbkQsMkZBQTJGO0lBQzNGLHFGQUFxRjtJQUNyRixtRkFBbUY7SUFDbkYsMkdBQTJHO0lBQzNHLDhHQUE4RztJQUM5RyxxREFBcUQ7SUFDckQsNENBQTRDO0lBQzVDLElBQUk7SUFFSixjQUFjLENBQUMsVUFBdUIsRUFBRSxhQUEwQjtRQUM5RCxJQUFJLGNBQWMsR0FBUSxFQUFFLEdBQUcsRUFBRSxJQUFJLEVBQUUsTUFBTSxFQUFFLElBQUksRUFBRSxDQUFDO1FBRXRELGNBQWMsQ0FBQyxHQUFHLEdBQUcsQ0FBQyxVQUFVLENBQUMsR0FBRyxDQUFDLGdCQUFnQixFQUFFLENBQUMsTUFBTSxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQztRQUNuRixjQUFjLENBQUMsTUFBTSxHQUFHLENBQUMsYUFBYSxDQUFDLEdBQUcsQ0FBQyxnQkFBZ0IsRUFBRSxDQUFDLE1BQU0sR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUM7UUFFekYsT0FBTyxjQUFjLENBQUM7SUFDMUIsQ0FBQztJQUVELFlBQVksQ0FBQyxVQUF1QixFQUFFLGFBQTBCO1FBQzVELElBQUksVUFBVSxHQUFZLENBQUMsVUFBVSxDQUFDLEdBQUcsQ0FBQyxRQUFRLEVBQUUsQ0FBQyxXQUFXLEVBQUUsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUM7UUFDdkYsSUFBSSxhQUFhLEdBQVksQ0FBQyxhQUFhLENBQUMsR0FBRyxDQUFDLFFBQVEsRUFBRSxDQUFDLFdBQVcsRUFBRSxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQztRQUU3RixJQUFJLFVBQVU7WUFBRSxVQUFVLENBQUMsR0FBRyxDQUFDLGlCQUFpQixFQUFFLENBQUM7O1lBQzlDLFVBQVUsQ0FBQyxHQUFHLENBQUMsV0FBVyxFQUFFLENBQUM7UUFDbEMsSUFBSSxhQUFhO1lBQUUsYUFBYSxDQUFDLEdBQUcsQ0FBQyxpQkFBaUIsRUFBRSxDQUFDOztZQUNwRCxhQUFhLENBQUMsR0FBRyxDQUFDLFdBQVcsRUFBRSxDQUFDO0lBQ3pDLENBQUM7SUFFRCxnREFBZ0Q7SUFDaEQsaUVBQWlFO0lBQ2pFLHVEQUF1RDtJQUN2RCx3RUFBd0U7SUFDeEUsUUFBUTtJQUNSLGtFQUFrRTtJQUNsRSxzQ0FBc0M7SUFDdEMsSUFBSTtJQUVKLDJCQUEyQixDQUFDLEdBQXFCO1FBQzdDLElBQUksaUJBQWlCLEdBQWUsR0FBRyxDQUFDLE9BQU8sQ0FBQyxhQUFhLENBQUMsZ0JBQWdCLENBQUMscUNBQXFDLENBQUMsQ0FBQztRQUN0SCxLQUFLLElBQUksQ0FBQyxHQUFXLENBQUMsRUFBRSxDQUFDLEdBQUcsaUJBQWlCLENBQUMsTUFBTSxFQUFFLENBQUMsRUFBRSxFQUFFO1lBQ3ZELGlCQUFpQixDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sR0FBRyxLQUFLLENBQUM7U0FDeEM7SUFDTCxDQUFDO0lBRUQsZ0JBQWdCLENBQUMsY0FBdUM7UUFDcEQsS0FBSyxJQUFJLENBQUMsR0FBVyxDQUFDLEVBQUUsQ0FBQyxHQUFHLGNBQWMsQ0FBQyxNQUFNLEVBQUUsQ0FBQyxFQUFFLEVBQUU7WUFDcEQsY0FBYyxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sR0FBRyxLQUFLLENBQUM7U0FDckM7SUFDTCxDQUFDO0lBRU8sY0FBYyxDQUFDLFNBQWlCLEVBQUUsSUFBWTtRQUNsRCxJQUFJLGNBQWMsR0FBRyxFQUFFLENBQUM7UUFDeEIsSUFBSSxZQUFZLEdBQUcsQ0FBQyxJQUFJLEtBQUssS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO1FBQzdDLElBQUksVUFBVSxHQUFHLEVBQUUsR0FBRyxTQUFTLENBQUM7UUFFaEMsT0FBTyxDQUFDLGNBQWMsR0FBRyxZQUFZLEdBQUcsVUFBVSxHQUFHLENBQUMsQ0FBQyxDQUFDO1FBRXhEOzs7Ozs7Ozs7Ozs7Ozs7Y0FlTTtJQUNWLENBQUM7SUFFTyxlQUFlLENBQUMsSUFBWSxFQUFFLE9BQW1CO1FBQ3JELElBQUksT0FBTyxHQUFRO1lBQ2YsZUFBZTtZQUNmLE9BQU8sRUFBRSxPQUFPO1lBQ2hCLFVBQVUsRUFBRSxFQUFFO1lBQ2QsZUFBZTtZQUVmLFlBQVksRUFBRSxDQUFDLElBQUksS0FBSyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFO1lBQ3pDLFNBQVMsRUFBRSxFQUFFO1lBRWIsbUJBQW1CLEVBQUUsSUFBSTtZQUN6QiwrQkFBK0I7WUFDL0IsaUNBQWlDO1lBQ2pDLGlDQUFpQztZQUNqQyxzQkFBc0IsRUFBRSxJQUFJO1lBQzVCLGdCQUFnQixFQUFFLElBQUk7WUFDdEIsNEJBQTRCLEVBQUUsSUFBSTtZQUNsQyxZQUFZLEVBQUUsSUFBSTtZQUNsQixhQUFhLEVBQUUsSUFBSTtZQUNuQixlQUFlLEVBQUUsS0FBSztZQUV0QixVQUFVLEVBQUUsSUFBSTtZQUNoQixLQUFLLEVBQUU7Z0JBQ0gsa0NBQWtDO2dCQUNsQyxtQ0FBbUM7Z0JBQ25DLE1BQU0sRUFBRSwyQkFBMkI7Z0JBQ25DLGFBQWEsRUFBRSwrQkFBK0I7Z0JBQzlDLGNBQWMsRUFBRSw2QkFBNkI7Z0JBQzdDLFVBQVUsRUFBRSx5QkFBeUI7Z0JBQ3JDLGFBQWEsRUFBRSxpQ0FBaUM7Z0JBQ2hELGVBQWUsRUFBRSxnQ0FBZ0M7YUFDcEQ7WUFDRCxtQ0FBbUM7WUFDbkMsbUNBQW1DO1lBQ25DLEtBQUs7WUFDTCxXQUFXLEVBQUUsVUFBUyxNQUFlO2dCQUNqQyxJQUFJLE1BQU0sQ0FBQyxJQUFJLENBQUMsY0FBYyxDQUFDLFFBQVEsQ0FBQyxFQUFFO29CQUN0QyxPQUFPLE1BQU0sQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDO29CQUMxQixPQUFPLG1CQUFtQixDQUFDO2lCQUM5QjtnQkFDRCxPQUFPO1lBQ1gsQ0FBQztZQUNELFlBQVksRUFBRSxFQUFFO1lBQ2hCLHFCQUFxQixFQUFFLHNIQUFzSDtTQUNoSixDQUFDO1FBR0YsT0FBTyxPQUFPLENBQUM7SUFDbkIsQ0FBQzs7O1lBL1BKLFVBQVUiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBJbmplY3RhYmxlLCBWaWV3Q29udGFpbmVyUmVmIH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XHJcbmltcG9ydCB7IFJvd05vZGUsIEdyaWRPcHRpb25zIH0gZnJvbSAnYWctZ3JpZC1jb21tdW5pdHknO1xyXG5cclxuQEluamVjdGFibGUoKVxyXG5leHBvcnQgY2xhc3MgS2RNdWx0aVNlbGVjdFRhYmxlU3ZjIHtcclxuICAgIGdldEJvdGhPcHRpb25zKF9jb25maWc6IGFueSwgX21hc3RlckRhdGE6IEFycmF5PGFueT4sIF9zbGF2ZURhdGE6IEFycmF5PGFueT4pOiBhbnkge1xyXG4gICAgICAgIC8vIGxldCBtYXN0ZXJEYXRhID0gKHR5cGVvZiBjb25maWcubWFzdGVyRGF0YSAhPSBcInVuZGVmaW5lZFwiKSA/IGNvbmZpZy5tYXN0ZXJEYXRhLnNsaWNlKCkgOiBbXTtcclxuICAgICAgICAvLyBsZXQgc2xhdmVEYXRhID0gKHR5cGVvZiBjb25maWcuc2xhdmVEYXRhICE9IFwidW5kZWZpbmVkXCIpID8gY29uZmlnLnNsYXZlRGF0YS5zbGljZSgpIDogW107XHJcbiAgICAgICAgLy8gY29uc29sZS5sb2coX2NvbmZpZyk7XHJcbiAgICAgICAgLy8gY29uc29sZS5sb2coX21hc3RlckRhdGEpO1xyXG4gICAgICAgIC8vIGNvbnNvbGUubG9nKF9zbGF2ZURhdGEpO1xyXG5cclxuICAgICAgICBsZXQgdXBkYXRlZE9wdGlvbnM6IGFueSA9IHtcclxuICAgICAgICAgICAgbWFzdGVyR3JpZE9wdGlvbjogdGhpcy5fZ2V0R3JpZE9wdGlvbnMoJ21hc3RlcicsIF9tYXN0ZXJEYXRhKSxcclxuICAgICAgICAgICAgc2xhdmVHcmlkT3B0aW9uOiB0aGlzLl9nZXRHcmlkT3B0aW9ucygnc2xhdmUnLCBfc2xhdmVEYXRhKVxyXG4gICAgICAgIH07XHJcblxyXG4gICAgICAgIHJldHVybiB1cGRhdGVkT3B0aW9ucztcclxuICAgIH1cclxuXHJcbiAgICBnZXRQcmltYXJ5a2V5KGNvbmZpZzogYW55KTogYW55IHtcclxuICAgICAgICAvLyBpZiB1c2VyIHNldCBtb3JlIHRoYW4gb25lIHByaW1hcnkga2V5LCBvbmx5IHRoZSBmaXJzdCBvbmUgd2lsbCBiZSB1c2VkLlxyXG4gICAgICAgIGlmICh0eXBlb2YgY29uZmlnLmNvbERlZiAhPT0gJ3VuZGVmaW5lZCcpIHtcclxuICAgICAgICAgICAgZm9yIChsZXQgaSBpbiBjb25maWcuY29sRGVmKSB7XHJcbiAgICAgICAgICAgICAgICBpZiAoY29uZmlnLmNvbERlZltpXS5wcmltYXJ5S2V5KSB7XHJcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIGk7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgcmV0dXJuICdpZCc7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIGdldENvbERlZnMoX2NvbERlZjogYW55KTogQXJyYXk8YW55PiB7XHJcbiAgICAgICAgbGV0IHVwZGF0ZWRDb2xEZWY6IEFycmF5PGFueT4gPSBbXTtcclxuICAgICAgICBmb3IgKGxldCBpIGluIF9jb2xEZWYpIHtcclxuICAgICAgICAgICAgaWYgKHR5cGVvZiBfY29sRGVmW2ldICE9PSAndW5kZWZpbmVkJykge1xyXG4gICAgICAgICAgICAgICAgbGV0IHRhYmxlQ29sdW1uOiBhbnkgPSB7XHJcbiAgICAgICAgICAgICAgICAgICAgaGVhZGVyTmFtZTogX2NvbERlZltpXS5oZWFkZXJOYW1lLFxyXG4gICAgICAgICAgICAgICAgICAgIGZpZWxkOiBpLFxyXG4gICAgICAgICAgICAgICAgICAgIGNvbElkOiBpLFxyXG4gICAgICAgICAgICAgICAgICAgIGNlbGxDbGFzczogJ2FnLWRlZmF1bHQnLFxyXG4gICAgICAgICAgICAgICAgICAgIG1lbnVUYWJzOiBbXVxyXG4gICAgICAgICAgICAgICAgfTtcclxuXHJcbiAgICAgICAgICAgICAgICB1cGRhdGVkQ29sRGVmLnB1c2godGFibGVDb2x1bW4pO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgICAgIHJldHVybiB1cGRhdGVkQ29sRGVmO1xyXG4gICAgfVxyXG5cclxuICAgIGdldFBsYWNlaG9sZGVyKGNvbmZpZzogYW55LCBncmlkOiBzdHJpbmcpOiBzdHJpbmcge1xyXG4gICAgICAgIC8vIGdyaWQgaXMgZWl0aGVyIHRvcCBvciBib3R0b21cclxuICAgICAgICBsZXQgcXVlcnkgPSBncmlkICsgJ1BsYWNlaG9sZGVyJztcclxuICAgICAgICBpZiAodHlwZW9mIGNvbmZpZy5ncmlkU2V0dGluZyAhPT0gJ3VuZGVmaW5lZCcgJiYgdHlwZW9mIGNvbmZpZy5ncmlkU2V0dGluZ1txdWVyeV0gIT09ICd1bmRlZmluZWQnKSByZXR1cm4gY29uZmlnLmdyaWRTZXR0aW5nW3F1ZXJ5XTtcclxuICAgICAgICByZXR1cm4gJ1VuZGVmaW5lZCc7XHJcbiAgICB9XHJcblxyXG4gICAgZ2V0QnV0dG9uKGNvbmZpZzogYW55LCBncmlkOiBhbnkpOiBhbnkge1xyXG4gICAgICAgIC8vIGdyaWQgaXMgZWl0aGVyIHRvVG9wQnRuIG9yIHRvQm90dG9tQnRuXHJcbiAgICAgICAgbGV0IHVwZGF0ZWRCdG46IGFueSA9IHt9O1xyXG5cclxuICAgICAgICBpZiAodHlwZW9mIGNvbmZpZy5ncmlkU2V0dGluZyAhPT0gJ3VuZGVmaW5lZCcgJiYgdHlwZW9mIGNvbmZpZy5ncmlkU2V0dGluZ1tncmlkXS5pY29uICE9PSAndW5kZWZpbmVkJykgdXBkYXRlZEJ0bi5pY29uID0gY29uZmlnLmdyaWRTZXR0aW5nW2dyaWRdLmljb247XHJcbiAgICAgICAgZWxzZSB1cGRhdGVkQnRuLmljb24gPSAnJztcclxuXHJcbiAgICAgICAgaWYgKHR5cGVvZiBjb25maWcuZ3JpZFNldHRpbmdbZ3JpZF0gIT09ICd1bmRlZmluZWQnICYmIHR5cGVvZiBjb25maWcuZ3JpZFNldHRpbmdbZ3JpZF0udGV4dCAhPT0gJ3VuZGVmaW5lZCcpIHVwZGF0ZWRCdG4udGV4dCA9IGNvbmZpZy5ncmlkU2V0dGluZ1tncmlkXS50ZXh0O1xyXG4gICAgICAgIGVsc2UgdXBkYXRlZEJ0bi50ZXh0ID0gJ1VuZGVmaW5lZCc7XHJcblxyXG4gICAgICAgIHJldHVybiB1cGRhdGVkQnRuO1xyXG4gICAgfVxyXG5cclxuICAgIGdldENoZWNrYm94RGVmYXVsdCgpOiBhbnkge1xyXG4gICAgICAgIHJldHVybiB7XHJcbiAgICAgICAgICAgIHdpZHRoOiA1MCxcclxuICAgICAgICAgICAgbWluV2lkdGg6IDUwLFxyXG4gICAgICAgICAgICBtYXhXaWR0aDogNTAsXHJcbiAgICAgICAgICAgIGNvbElkOiAnY2hlY2tib3gnLFxyXG4gICAgICAgICAgICBoZWFkZXJOYW1lOiAnJyxcclxuICAgICAgICAgICAgc3VwcHJlc3NNZW51OiB0cnVlLFxyXG4gICAgICAgICAgICBzdXBwcmVzc1NvcnRpbmc6IHRydWUsXHJcbiAgICAgICAgICAgIHN1cHByZXNzU2l6ZVRvRml0OiB0cnVlLFxyXG4gICAgICAgICAgICBjZWxsQ2xhc3M6ICdhZy1jaGVja2JveC1yYWRpbydcclxuICAgICAgICB9O1xyXG4gICAgfVxyXG5cclxuICAgIGNhbGNNb2JpbGVIZWlnaHQobWFzdGVyR3JpZDogR3JpZE9wdGlvbnMsIHNsYXZlR3JpZDogR3JpZE9wdGlvbnMsIHZjcjogVmlld0NvbnRhaW5lclJlZik6IGFueSB7XHJcbiAgICAgICAgbGV0IHRvcERhdGE6IG51bWJlciA9IG1hc3RlckdyaWQuYXBpLmdldE1vZGVsKCkuZ2V0Um93Q291bnQoKTtcclxuICAgICAgICBsZXQgYm90dG9tRGF0YTogbnVtYmVyID0gc2xhdmVHcmlkLmFwaS5nZXRNb2RlbCgpLmdldFJvd0NvdW50KCk7XHJcbiAgICAgICAgbGV0IHRvcEhlaWdodCA9ICh0eXBlb2YgdG9wRGF0YSAhPT0gJ3VuZGVmaW5lZCcgJiYgdG9wRGF0YSA+IDApID8gdGhpcy5fZ2V0R3JpZEhlaWdodCh0b3BEYXRhLCAndG9wJykgOiAxNTA7XHJcbiAgICAgICAgbGV0IGJvdHRvbUhlaWdodCA9ICh0eXBlb2YgYm90dG9tRGF0YSAhPT0gJ3VuZGVmaW5lZCcgJiYgYm90dG9tRGF0YSA+IDApID8gdGhpcy5fZ2V0R3JpZEhlaWdodChib3R0b21EYXRhLCAnYm90dG9tJykgOiAxNTA7XHJcbiAgICAgICAgbGV0IHJlc3VsdDogYW55ID0ge1xyXG4gICAgICAgICAgICB0b3A6IHRvcEhlaWdodCxcclxuICAgICAgICAgICAgYm90dG9tOiBib3R0b21IZWlnaHRcclxuICAgICAgICB9O1xyXG4gICAgICAgIHJldHVybiByZXN1bHQ7XHJcbiAgICB9XHJcblxyXG4gICAgY2FsY1dlYkhlaWdodChoZWlnaHQ6IG51bWJlcik6IGFueSB7XHJcbiAgICAgICAgbGV0IHNlcGFyYXRvcjogbnVtYmVyID0gNjU7XHJcbiAgICAgICAgbGV0IGNoZWNrZWRIZWlnaHQ6IG51bWJlciA9ICgodHlwZW9mIGhlaWdodCAhPT0gJ251bWJlcicpID8gNjAwIDogaGVpZ2h0KSAtIHNlcGFyYXRvcjtcclxuICAgICAgICBsZXQgYm90dG9tSGVpZ2h0OiBudW1iZXIgPSAoY2hlY2tlZEhlaWdodCAtIDM4KSAvIDI7XHJcbiAgICAgICAgbGV0IHdlYkhlaWdodDogYW55ID0ge1xyXG4gICAgICAgICAgICB0b3A6IGJvdHRvbUhlaWdodCArIDM4LFxyXG4gICAgICAgICAgICBib3R0b206IGJvdHRvbUhlaWdodFxyXG4gICAgICAgIH07XHJcblxyXG4gICAgICAgIHJldHVybiB3ZWJIZWlnaHQ7XHJcbiAgICB9XHJcblxyXG4gICAgLy8gZ2V0Q29sRGVmV2lkdGgoX2dyaWRPcHRpb25zOiBHcmlkT3B0aW9ucyk6IEFycmF5PGFueT4ge1xyXG4gICAgLy8gICAgIGxldCBjb2x1bW46IEFycmF5PENvbHVtbj4gPSBfZ3JpZE9wdGlvbnMuY29sdW1uQXBpLmdldEFsbENvbHVtbnMoKTtcclxuICAgIC8vICAgICBsZXQgY29sV2lkdGg6IEFycmF5PG51bWJlcj4gPSBbXTtcclxuICAgIC8vICAgICBmb3IobGV0IGk6IG51bWJlciA9IDA7IGkgPCBjb2x1bW4ubGVuZ3RoOyBpKyspe1xyXG4gICAgLy8gICAgICAgICBpZihjb2x1bW5baV0uZ2V0Q29sSWQoKSAhPT0gJ2NoZWNrYm94Jykge1xyXG4gICAgLy8gICAgICAgICAgICAgY29sV2lkdGgucHVzaChjb2x1bW5baV0uZ2V0QWN0dWFsV2lkdGgoKSArIDMwKTtcclxuICAgIC8vICAgICAgICAgfVxyXG4gICAgLy8gICAgICAgICBlbHNle1xyXG4gICAgLy8gICAgICAgICAgICAgY29sV2lkdGgucHVzaCg1MCk7XHJcbiAgICAvLyAgICAgICAgIH1cclxuICAgIC8vICAgICB9XHJcblxyXG4gICAgLy8gICAgIC8vIGNvbnNvbGUubG9nKGNvbFdpZHRoKTtcclxuICAgIC8vICAgICByZXR1cm4gY29sV2lkdGg7XHJcbiAgICAvLyB9XHJcblxyXG4gICAgLy8gZ2V0Q29sVG90YWxXaWR0aChfY29sQXJyYXk6IEFycmF5PG51bWJlcj4pOiBudW1iZXIge1xyXG4gICAgLy8gICAgIGxldCB0b3RhbDogbnVtYmVyID0gMDtcclxuXHJcbiAgICAvLyAgICAgZm9yIChsZXQgaTogbnVtYmVyID0gMDsgaSA8IF9jb2xBcnJheS5sZW5ndGg7IGkrKykge1xyXG4gICAgLy8gICAgICAgICB0b3RhbCArPSBfY29sQXJyYXlbaV07XHJcbiAgICAvLyAgICAgfVxyXG5cclxuICAgIC8vICAgICByZXR1cm4gdG90YWw7XHJcbiAgICAvLyB9XHJcblxyXG4gICAgLy8gZ2V0VXNhYmxlV2lkdGgoX3ZjcjogVmlld0NvbnRhaW5lclJlZik6IG51bWJlciB7XHJcbiAgICAvLyAgICAgbGV0IGFnR3JpZEVsZTogSFRNTEVsZW1lbnQgPSBfdmNyLmVsZW1lbnQubmF0aXZlRWxlbWVudC5xdWVyeVNlbGVjdG9yKCcuc3RnLXRoZW1lJyk7XHJcbiAgICAvLyAgICAgbGV0IHBhcmVudFdpZHRoOiBudW1iZXIgPSBNYXRoLnJvdW5kKGFnR3JpZEVsZS5nZXRCb3VuZGluZ0NsaWVudFJlY3QoKS53aWR0aCk7XHJcbiAgICAvLyAgICAgbGV0IGNvbXB1dGVkU3R5bGU6IENTU1N0eWxlRGVjbGFyYXRpb24gPSB3aW5kb3cuZ2V0Q29tcHV0ZWRTdHlsZShhZ0dyaWRFbGUpO1xyXG4gICAgLy8gICAgIGxldCBib3JkZXJMZWZ0OiBudW1iZXIgPSAoY29tcHV0ZWRTdHlsZS5ib3JkZXJMZWZ0ICE9PSAnJykgPyBwYXJzZUludChjb21wdXRlZFN0eWxlLmJvcmRlckxlZnQpIDogMDtcclxuICAgIC8vICAgICBsZXQgYm9yZGVyUmlnaHQ6IG51bWJlciA9IChjb21wdXRlZFN0eWxlLmJvcmRlclJpZ2h0ICE9PSAnJykgPyBwYXJzZUludChjb21wdXRlZFN0eWxlLmJvcmRlclJpZ2h0KSA6IDA7XHJcbiAgICAvLyAgICAgbGV0IGJvcmRlckxlZnRSaWdodCA9IGJvcmRlckxlZnQgKyBib3JkZXJSaWdodFxyXG4gICAgLy8gICAgIHJldHVybiBwYXJlbnRXaWR0aCAtIGJvcmRlckxlZnRSaWdodDtcclxuICAgIC8vIH1cclxuXHJcbiAgICBjaGVja1NlbGVjdGlvbih0b3BPcHRpb25zOiBHcmlkT3B0aW9ucywgYm90dG9tT3B0aW9uczogR3JpZE9wdGlvbnMpOiBhbnkge1xyXG4gICAgICAgIGxldCB1cGRhdGVEaXNhYmxlZDogYW55ID0geyB0b3A6IHRydWUsIGJvdHRvbTogdHJ1ZSB9O1xyXG5cclxuICAgICAgICB1cGRhdGVEaXNhYmxlZC50b3AgPSAodG9wT3B0aW9ucy5hcGkuZ2V0U2VsZWN0ZWROb2RlcygpLmxlbmd0aCA+IDApID8gZmFsc2UgOiB0cnVlO1xyXG4gICAgICAgIHVwZGF0ZURpc2FibGVkLmJvdHRvbSA9IChib3R0b21PcHRpb25zLmFwaS5nZXRTZWxlY3RlZE5vZGVzKCkubGVuZ3RoID4gMCkgPyBmYWxzZSA6IHRydWU7XHJcblxyXG4gICAgICAgIHJldHVybiB1cGRhdGVEaXNhYmxlZDtcclxuICAgIH1cclxuXHJcbiAgICBjaGVja092ZXJsYXkodG9wT3B0aW9uczogR3JpZE9wdGlvbnMsIGJvdHRvbU9wdGlvbnM6IEdyaWRPcHRpb25zKTogdm9pZCB7XHJcbiAgICAgICAgbGV0IHRvcE92ZXJsYXk6IGJvb2xlYW4gPSAodG9wT3B0aW9ucy5hcGkuZ2V0TW9kZWwoKS5nZXRSb3dDb3VudCgpID4gMCkgPyBmYWxzZSA6IHRydWU7XHJcbiAgICAgICAgbGV0IGJvdHRvbU92ZXJsYXk6IGJvb2xlYW4gPSAoYm90dG9tT3B0aW9ucy5hcGkuZ2V0TW9kZWwoKS5nZXRSb3dDb3VudCgpID4gMCkgPyBmYWxzZSA6IHRydWU7XHJcblxyXG4gICAgICAgIGlmICh0b3BPdmVybGF5KSB0b3BPcHRpb25zLmFwaS5zaG93Tm9Sb3dzT3ZlcmxheSgpO1xyXG4gICAgICAgIGVsc2UgdG9wT3B0aW9ucy5hcGkuaGlkZU92ZXJsYXkoKTtcclxuICAgICAgICBpZiAoYm90dG9tT3ZlcmxheSkgYm90dG9tT3B0aW9ucy5hcGkuc2hvd05vUm93c092ZXJsYXkoKTtcclxuICAgICAgICBlbHNlIGJvdHRvbU9wdGlvbnMuYXBpLmhpZGVPdmVybGF5KCk7XHJcbiAgICB9XHJcblxyXG4gICAgLy8gc2V0UnRsVmlldyhfZ3JpZE9wdGlvbnM6IEdyaWRPcHRpb25zKTogdm9pZCB7XHJcbiAgICAvLyAgICAgbGV0IGNvbERlZkxlbmd0aDogbnVtYmVyID0gX2dyaWRPcHRpb25zLmNvbHVtbkRlZnMubGVuZ3RoO1xyXG4gICAgLy8gICAgIGZvciAobGV0IGk6IG51bWJlciA9IDA7IGkgPCBjb2xEZWZMZW5ndGg7IGkrKykge1xyXG4gICAgLy8gICAgICAgICBfZ3JpZE9wdGlvbnMuY29sdW1uQXBpLm1vdmVDb2x1bW4oMCwgY29sRGVmTGVuZ3RoIC0gKGkgKyAxKSk7XHJcbiAgICAvLyAgICAgfVxyXG4gICAgLy8gICAgIC8vIF9ncmlkT3B0aW9ucy5hcGkuc2V0Q29sdW1uRGVmcyhfZ3JpZE9wdGlvbnMuY29sdW1uRGVmcyk7XHJcbiAgICAvLyAgICAgX2dyaWRPcHRpb25zLmFwaS5yZWZyZXNoVmlldygpO1xyXG4gICAgLy8gfVxyXG5cclxuICAgIHNldENoZWNrYm94RmFsc2VBZnRlclVwZGF0ZSh2Y3I6IFZpZXdDb250YWluZXJSZWYpOiB2b2lkIHtcclxuICAgICAgICBsZXQgc2VsZWN0QWxsQ2hlY2tib3g6IEFycmF5PGFueT4gPSB2Y3IuZWxlbWVudC5uYXRpdmVFbGVtZW50LnF1ZXJ5U2VsZWN0b3JBbGwoJy5zZWxlY3Rpb24td3JhcHBlciBpbnB1dC5zZWxlY3QtYWxsJyk7XHJcbiAgICAgICAgZm9yIChsZXQgaTogbnVtYmVyID0gMDsgaSA8IHNlbGVjdEFsbENoZWNrYm94Lmxlbmd0aDsgaSsrKSB7XHJcbiAgICAgICAgICAgIHNlbGVjdEFsbENoZWNrYm94W2ldLmNoZWNrZWQgPSBmYWxzZTtcclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgc2V0Q2hlY2tib3hGYWxzZShyZW1vdmVkRWxlbWVudDogQXJyYXk8SFRNTElucHV0RWxlbWVudD4pOiB2b2lkIHtcclxuICAgICAgICBmb3IgKGxldCBpOiBudW1iZXIgPSAwOyBpIDwgcmVtb3ZlZEVsZW1lbnQubGVuZ3RoOyBpKyspIHtcclxuICAgICAgICAgICAgcmVtb3ZlZEVsZW1lbnRbaV0uY2hlY2tlZCA9IGZhbHNlO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF9nZXRHcmlkSGVpZ2h0KGRhdGFDb3VudDogbnVtYmVyLCBncmlkOiBzdHJpbmcpOiBudW1iZXIge1xyXG4gICAgICAgIGxldCBmbG9hdGluZ0hlaWdodCA9IDM4O1xyXG4gICAgICAgIGxldCBoZWFkZXJIZWlnaHQgPSAoZ3JpZCA9PT0gJ3RvcCcpID8gMzggOiAwO1xyXG4gICAgICAgIGxldCBkYXRhSGVpZ2h0ID0gMzggKiBkYXRhQ291bnQ7XHJcblxyXG4gICAgICAgIHJldHVybiAoZmxvYXRpbmdIZWlnaHQgKyBoZWFkZXJIZWlnaHQgKyBkYXRhSGVpZ2h0ICsgOCk7XHJcblxyXG4gICAgICAgIC8qICAgaGVpZ2h0IGNhbGN1bGF0aW9uIGJhc2VkIG9uIHZjclxyXG4gICAgICAgICAgICBsZXQgdG90YWxIZWlnaHQ6IG51bWJlciA9IDA7XHJcbiAgICAgICAgICAgIGxldCBxdWVyeUVsZVN0cmluZzogc3RyaW5nID0gJyMnICsgZ3JpZDtcclxuICAgICAgICAgICAgbGV0IG5hdGl2ZUVsZTogRWxlbWVudCA9IHZjci5lbGVtZW50Lm5hdGl2ZUVsZW1lbnQucXVlcnlTZWxlY3RvcihxdWVyeUVsZVN0cmluZyk7XHJcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKG5hdGl2ZUVsZSk7XHJcbiAgICAgICAgICAgIHRvdGFsSGVpZ2h0ICs9IE1hdGguY2VpbChuYXRpdmVFbGUucXVlcnlTZWxlY3RvcignLmFnLWhlYWRlci1jb250YWluZXInKS5nZXRCb3VuZGluZ0NsaWVudFJlY3QoKS5oZWlnaHQpO1xyXG4gICAgICAgICAgICB0b3RhbEhlaWdodCArPSBNYXRoLmNlaWwobmF0aXZlRWxlLnF1ZXJ5U2VsZWN0b3IoJy5hZy1ib2R5LWNvbnRhaW5lcicpLmdldEJvdW5kaW5nQ2xpZW50UmVjdCgpLmhlaWdodCk7XHJcbiAgICAgICAgICAgIHRvdGFsSGVpZ2h0ICs9IE1hdGguY2VpbChuYXRpdmVFbGUucXVlcnlTZWxlY3RvcignLmFnLWZsb2F0aW5nLXRvcC1mdWxsLXdpZHRoLWNvbnRhaW5lcicpLmdldEJvdW5kaW5nQ2xpZW50UmVjdCgpLmhlaWdodCk7XHJcbiAgICAgICAgICAgIGxldCBwYWdpbmF0aW9uQm90dG9tOiBFbGVtZW50ID0gbmF0aXZlRWxlLnF1ZXJ5U2VsZWN0b3IoJyNzb3V0aCcpXHJcbiAgICAgICAgICAgIGlmKHBhZ2luYXRpb25Cb3R0b20gIT09IG51bGwpIHtcclxuICAgICAgICAgICAgICAgIHRvdGFsSGVpZ2h0ICs9IE1hdGguY2VpbChwYWdpbmF0aW9uQm90dG9tLmdldEJvdW5kaW5nQ2xpZW50UmVjdCgpLmhlaWdodCk7XHJcbiAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgIHRvdGFsSGVpZ2h0ICs9IDg7XHJcbiAgICAgICAgICAgIHJldHVybiB0b3RhbEhlaWdodDtcclxuICAgICAgICAgICAgKi9cclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF9nZXRHcmlkT3B0aW9ucyhncmlkOiBzdHJpbmcsIHJvd0RhdGE6IEFycmF5PGFueT4pOiBhbnkge1xyXG4gICAgICAgIGxldCBvcHRpb25zOiBhbnkgPSB7XHJcbiAgICAgICAgICAgIC8vIHJvd0RhdGE6IFtdLFxyXG4gICAgICAgICAgICByb3dEYXRhOiByb3dEYXRhLFxyXG4gICAgICAgICAgICBjb2x1bW5EZWZzOiBbXSxcclxuICAgICAgICAgICAgLy8gZGVidWc6IHRydWUsXHJcblxyXG4gICAgICAgICAgICBoZWFkZXJIZWlnaHQ6IChncmlkID09PSAnc2xhdmUnKSA/IDAgOiAzOCxcclxuICAgICAgICAgICAgcm93SGVpZ2h0OiAzOCxcclxuXHJcbiAgICAgICAgICAgIHN1cHByZXNzQ29udGV4dE1lbnU6IHRydWUsXHJcbiAgICAgICAgICAgIC8vIHN1cHByZXNzTWVudU1haW5QYW5lbDogdHJ1ZSxcclxuICAgICAgICAgICAgLy8gc3VwcHJlc3NNZW51Q29sdW1uUGFuZWw6IHRydWUsXHJcbiAgICAgICAgICAgIC8vIHN1cHByZXNzTWVudUZpbHRlclBhbmVsOiB0cnVlLFxyXG4gICAgICAgICAgICBzdXBwcmVzc01vdmFibGVDb2x1bW5zOiB0cnVlLFxyXG4gICAgICAgICAgICBzdXBwcmVzc01lbnVIaWRlOiB0cnVlLFxyXG4gICAgICAgICAgICBzdXBwcmVzc0NvbHVtblZpcnR1YWxpc2F0aW9uOiB0cnVlLFxyXG4gICAgICAgICAgICBlbmFibGVGaWx0ZXI6IHRydWUsXHJcbiAgICAgICAgICAgIGVuYWJsZVNvcnRpbmc6IHRydWUsXHJcbiAgICAgICAgICAgIGVuYWJsZUNvbFJlc2l6ZTogZmFsc2UsXHJcblxyXG4gICAgICAgICAgICB1blNvcnRJY29uOiB0cnVlLFxyXG4gICAgICAgICAgICBpY29uczoge1xyXG4gICAgICAgICAgICAgICAgLy8gdXNlIGZvbnQgYXdlc29tZSBmb3IgbWVudSBpY29uc1xyXG4gICAgICAgICAgICAgICAgLy8gbWVudTogJzxpIGNsYXNzPSdmYSBmYS1iYXJzJy8+JyxcclxuICAgICAgICAgICAgICAgIGZpbHRlcjogJzxpIGNsYXNzPVwiZmEgZmEtZmlsdGVyXCIvPicsXHJcbiAgICAgICAgICAgICAgICBzb3J0QXNjZW5kaW5nOiAnPGkgY2xhc3M9XCJmYSBmYS1jYXJldC1kb3duXCIvPicsXHJcbiAgICAgICAgICAgICAgICBzb3J0RGVzY2VuZGluZzogJzxpIGNsYXNzPVwiZmEgZmEtY2FyZXQtdXBcIi8+JyxcclxuICAgICAgICAgICAgICAgIHNvcnRVblNvcnQ6ICc8aSBjbGFzcz1cImZhIGZhLXNvcnRcIi8+JyxcclxuICAgICAgICAgICAgICAgIGdyb3VwRXhwYW5kZWQ6ICc8aSBjbGFzcz1cImZhIGZhLW1pbnVzLWNpcmNsZVwiLz4nLFxyXG4gICAgICAgICAgICAgICAgZ3JvdXBDb250cmFjdGVkOiAnPGkgY2xhc3M9XCJmYSBmYS1wbHVzLWNpcmNsZVwiLz4nXHJcbiAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgIC8vIG9uR3JpZFNpemVDaGFuZ2VkOiBmdW5jdGlvbihlKSB7XHJcbiAgICAgICAgICAgIC8vICAgICB0aGlzLmFwaS5zaXplQ29sdW1uc1RvRml0KCk7XHJcbiAgICAgICAgICAgIC8vIH0sXHJcbiAgICAgICAgICAgIGdldFJvd0NsYXNzOiBmdW5jdGlvbihwYXJhbXM6IFJvd05vZGUpOiBhbnkge1xyXG4gICAgICAgICAgICAgICAgaWYgKHBhcmFtcy5kYXRhLmhhc093blByb3BlcnR5KCduZXdSb3cnKSkge1xyXG4gICAgICAgICAgICAgICAgICAgIGRlbGV0ZSBwYXJhbXMuZGF0YS5uZXdSb3c7XHJcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuICduZXctcm93LWhpZ2hsaWdodCc7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICByZXR1cm47XHJcbiAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgIGFsaWduZWRHcmlkczogW10sXHJcbiAgICAgICAgICAgIG92ZXJsYXlOb1Jvd3NUZW1wbGF0ZTogJzxzcGFuIGNsYXNzPVwiYWctY3VzdG9tLW92ZXJsYXlcIj48aSBjbGFzcz1cImZhIGZhLWluZm8tY2lyY2xlIGZhLWxnIG1hcmdpbi1yaWdodDEwXCI+PC9pPk5vIHN0dWRlbnQgcmVjb3JkIGZvdW5kPC9zcGFuPidcclxuICAgICAgICB9O1xyXG5cclxuXHJcbiAgICAgICAgcmV0dXJuIG9wdGlvbnM7XHJcbiAgICB9XHJcbn1cclxuIl19