import { Component, ViewEncapsulation, Input, ElementRef, ViewChild, HostBinding, ChangeDetectorRef } from '@angular/core';
// import { Subscription } from 'rxjs/Subscription';
import { timer } from 'rxjs';
// import { debounceTime } from 'rxjs/operators';
import * as L from 'leaflet';
import 'leaflet.markercluster';
import 'leaflet.awesome-markers/dist/leaflet.awesome-markers';
import { KdSplitterEvent } from '../kd-angular-splitter/index';
import { KdDomElemSvc } from '../kd-common/index';
import { KdMapSvc } from './kd-angular-map-svc';
import { KdDataSvc } from '../kd-common/index';
export class KdMap {
    constructor(_elementRef, _kdSplitterEvent, _kdDomElemSvc, _kdMapSvc, _cd, _dataSvc) {
        this._elementRef = _elementRef;
        this._kdDomElemSvc = _kdDomElemSvc;
        this._kdMapSvc = _kdMapSvc;
        this._cd = _cd;
        this._dataSvc = _dataSvc;
        // private static mapPinImage: string = 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABkAAAApCAYAAADAk4LOAAAFgUlEQVR4Aa1XA5BjWRTN2oW17d3YaZtr2962HUzbDNpjszW24mRt28p47v7zq/bXZtrp/lWnXr337j3nPCe85NcypgSFdugCpW5YoDAMRaIMqRi6aKq5E3YqDQO3qAwjVWrD8Ncq/RBpykd8oZUb/kaJutow8r1aP9II0WmLKLIsJyv1w/kqw9Ch2MYdB++12Onxee/QMwvf4/Dk/Lfp/i4nxTXtOoQ4pW5Aj7wpici1A9erdAN2OH64x8OSP9j3Ft3b7aWkTg/Fm91siTra0f9on5sQr9INejH6CUUUpavjFNq1B+Oadhxmnfa8RfEmN8VNAsQhPqF55xHkMzz3jSmChWU6f7/XZKNH+9+hBLOHYozuKQPxyMPUKkrX/K0uWnfFaJGS1QPRtZsOPtr3NsW0uyh6NNCOkU3Yz+bXbT3I8G3xE5EXLXtCXbbqwCO9zPQYPRTZ5vIDXD7U+w7rFDEoUUf7ibHIR4y6bLVPXrz8JVZEql13trxwue/uDivd3fkWRbS6/IA2bID4uk0UpF1N8qLlbBlXs4Ee7HLTfV1j54APvODnSfOWBqtKVvjgLKzF5YdEk5ewRkGlK0i33Eofffc7HT56jD7/6U+qH3Cx7SBLNntH5YIPvODnyfIXZYRVDPqgHtLs5ABHD3YzLuespb7t79FY34DjMwrVrcTuwlT55YMPvOBnRrJ4VXTdNnYug5ucHLBjEpt30701A3Ts+HEa73u6dT3FNWwflY86eMHPk+Yu+i6pzUpRrW7SNDg5JHR4KapmM5Wv2E8Tfcb1HoqqHMHU+uWDD7zg54mz5/2BSnizi9T1Dg4QQXLToGNCkb6tb1NU+QAlGr1++eADrzhn/u8Q2YZhQVlZ5+CAOtqfbhmaUCS1ezNFVm2imDbPmPng5wmz+gwh+oHDce0eUtQ6OGDIyR0uUhUsoO3vfDmmgOezH0mZN59x7MBi++WDL1g/eEiU3avlidO671bkLfwbw5XV2P8Pzo0ydy4t2/0eu33xYSOMOD8hTf4CrBtGMSoXfPLchX+J0ruSePw3LZeK0juPJbYzrhkH0io7B3k164hiGvawhOKMLkrQLyVpZg8rHFW7E2uHOL888IBPlNZ1FPzstSJM694fWr6RwpvcJK60+0HCILTBzZLFNdtAzJaohze60T8qBzyh5ZuOg5e7uwQppofEmf2++DYvmySqGBuKaicF1blQjhuHdvCIMvp8whTTfZzI7RldpwtSzL+F1+wkdZ2TBOW2gIF88PBTzD/gpeREAMEbxnJcaJHNHrpzji0gQCS6hdkEeYt9DF/2qPcEC8RM28Hwmr3sdNyht00byAut2k3gufWNtgtOEOFGUwcXWNDbdNbpgBGxEvKkOQsxivJx33iow0Vw5S6SVTrpVq11ysA2Rp7gTfPfktc6zhtXBBC+adRLshf6sG2RfHPZ5EAc4sVZ83yCN00Fk/4kggu40ZTvIEm5g24qtU4KjBrx/BTTH8ifVASAG7gKrnWxJDcU7x8X6Ecczhm3o6YicvsLXWfh3Ch1W0k8x0nXF+0fFxgt4phz8QvypiwCCFKMqXCnqXExjq10beH+UUA7+nG6mdG/Pu0f3LgFcGrl2s0kNNjpmoJ9o4B29CMO8dMT4Q5ox8uitF6fqsrJOr8qnwNbRzv6hSnG5wP+64C7h9lp30hKNtKdWjtdkbuPA19nJ7Tz3zR/ibgARbhb4AlhavcBebmTHcFl2fvYEnW0ox9xMxKBS8btJ+KiEbq9zA4RthQXDhPa0T9TEe69gWupwc6uBUphquXgf+/FrIjweHQS4/pduMe5ERUMHUd9xv8ZR98CxkS4F2n3EUrUZ10EYNw7BWm9x1GiPssi3GgiGRDKWRYZfXlON+dfNbM+GgIwYdwAAAAASUVORK5CYII=';
        // private static mapPinShadowImage: string = 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACkAAAApCAQAAAACach9AAACMUlEQVR4Ae3ShY7jQBAE0Aoz/f9/HTMzhg1zrdKUrJbdx+Kd2nD8VNudfsL/Th///dyQN2TH6f3y/BGpC379rV+S+qqetBOxImNQXL8JCAr2V4iMQXHGNJxeCfZXhSRBcQMfvkOWUdtfzlLgAENmZDcmo2TVmt8OSM2eXxBp3DjHSMFutqS7SbmemzBiR+xpKCNUIRkdkkYxhAkyGoBvyQFEJEefwSmmvBfJuJ6aKqKWnAkvGZOaZXTUgFqYULWNSHUckZuR1HIIimUExutRxwzOLROIG4vKmCKQt364mIlhSyzAf1m9lHZHJZrlAOMMztRRiKimp/rpdJDc9Awry5xTZCte7FHtuS8wJgeYGrex28xNTd086Dik7vUMscQOa8y4DoGtCCSkAKlNwpgNtphjrC6MIHUkR6YWxxs6Sc5xqn222mmCRFzIt8lEdKx+ikCtg91qS2WpwVfBelJCiQJwvzixfI9cxZQWgiSJelKnwBElKYtDOb2MFbhmUigbReQBV0Cg4+qMXSxXSyGUn4UbF8l+7qdSGnTC0XLCmahIgUHLhLOhpVCtw4CzYXvLQWQbJNmxoCsOKAxSgBJno75avolkRw8iIAFcsdc02e9iyCd8tHwmeSSoKTowIgvscSGZUOA7PuCN5b2BX9mQM7S0wYhMNU74zgsPBj3HU7wguAfnxxjFQGBE6pwN+GjME9zHY7zGp8wVxMShYX9NXvEWD3HbwJf4giO4CFIQxXScH1/TM+04kkBiAAAAAElFTkSuQmCC';
        this.smallLoaderValue = null;
        this.isMapShown = true;
        this.isLayerLoading = true;
        this.isLinkToGoogle = false;
        this.googleLink = '';
        this.errorMessage = '';
        this.googleImage = 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADIAAAAyCAYAAAAeP4ixAAAABHNCSVQICAgIfAhkiAAAAAlwSFlzAAAOawAADmsBVP4NBgAAABl0RVh0U29mdHdhcmUAd3d3Lmlua3NjYXBlLm9yZ5vuPBoAAAatSURBVGiB7ZlbbBzVGcd/Z2Zn7L34Hmyyu97cHIfEjdNYMXUwRLaSUtJC1YoQqw1tKVIpyUPVclFLLyqR0zxUlYJUKYIIqQ/lhVDoRS2NiiEuIIpJ0lxMGyAbAontpNSX2PF6vbc5fXDH8WVmdtZeK63k/9PZ75zzne+335lvzp6FRf1vSdzoAAC6tzRWe4T4EshtQDVQAgwDl6SUf9EU9ferO7t6nHzcUJD3mjcG8Xj2SngA8DgMTQG/kobx5Lo3Tly2GnDDQP7R2rhVMTgMlOcwbUBIsfOW1995bWbHDQF5r3VTszTEq0DBHKaPS6G0ruvsenuq0REk+Mx9EUUojwlokFIUzmHRWaqKpbSDR3rWFScMp62UTVcMwca6zmNXTIOts+Az90UUlFNIyiQAch7rXtfXu4coThjzdXOzKmkHvmUabEEUxKNA2Uz7Em8xX1x1G+uXrERVFM4N9fLnC11Er/ZlXb0ylmbrhWuOYyQwljHwqYrjdpHwjXMtn9lrVjOH9Iq6mZZ7V9/BvtsfJKB5p9kf27STX578Lb84ftgxyC0XY6g2iZXAu7E4Z66Nk5AGBYqgPuClzleIIiyRtBSZHcBTAIo9B+pMiAOtewhoXuLpBH/r+yevXjxJf3yEjMxw+t/nHSEANv4rbtt3ejTOsZExEnJi2yUMybGRMc7E7OcIKbaabVcPXEmBn/bmbyIQnPwkyu6Op+gd7QfArxVSUxpyBVIZS1vazWxYqXt0nPqAz+YblxGzZZ+RKfrCiiaKdB9j6QQPdxyYhACIpcZdQQAUpawf8rhhkDSs91xKSuIZu+IgKsyWq4ysq1gGwKlPovSNDkzaT9z/NJW+0mljD535I+1vP2fpZ0wVVFjYvYqCrghLGE0IvKpNPpAjZttVRsyHLWNkL5uaYv/dfFyqW9oF8OmA17KvochuW4FAvGu2XWUkerUXgA2VKykp8DOciAFw/8v78SgedNXDc9ufIKB76Zmy7WaqM+Ln9ksxy746vxfJxEOfNCS6ItgQ8LLWZ//yF0JOlklXGfnTh13E0wmKdT8HWvZMlt+zgxfp7v+Qu5Y3EtC9SCSdl07Z+nkzEqDfq1r2CWC938uuqnLaKsvYVVXOer/XrvQC9Fwm8Dvzg7VXoPieTz0ALIeJBzqeTtJSvYFVpUF21G5hTXmYpmAdjzfu5O6VTQD8IfoWvz7bYQsiBfg12NDrUFIBXRFZD4FSyh/e+te3uszPrs87z3a/TJHu47sN93Kzv5y2Na3T+jsvneYHbz7r6KNKz/BgWxJ9WCH2/ryOKa+sff34wamGnA5uB078hiMX3qHtllZqy8KkMmn6YgMcuXCMN3rPYEj781iVnuH5+gFW+dIkv6rx0f4kRmJO57drhsjsETMOf7YZDB9qO4qkZS4rzdRUiMlo/p6h91Aqd2eK3LH26PEXZ5nnFaELVVpAABQ1qPg3l+Tka6ihPmkFAQsMUqlnOGwBARAzIgx8+QmMpUFXvoxgkJ577h6z618wkGwQH4w/RFoNkGjbBUqWMFSV8bavYXhsi+zCgDhCyGV8MP4QGTnxgzNTvYxUy9ZZ46Yq2boNI1ztOCbvIE4QGX0N8Yp9oPin2ROf3Y5RbnUKA6NiCaltd2VdN68g2SBGy/bi0UsIh6pR1SnbRNdJ3bnd0mfyc59HalrWtfMG4gZCCh8AmqYTXBqaBpNqaMQomV7FjJJS0hs3uVo/LyBOEO8PruF08jqEqYKCQsKhyHUYVSXd1DxtTGpzc/ZC8F/NG8QJ4mx/Ld/raOfHLwQ4d2X2XE3TpsGkGpvAPCQqCulbb3Mdx7xAskE8+to+YkkfsQT89AUlK4wsK8cIhQEwwhFkifsX5pxB3EKYcguTrqkFIFOzOqd45gSSK4QpNzCsWAlMvF9yUc4gc4UwlQ2matNmYGJr5aKcQOYLYcoJpiAUpvhHexE33ZRLaO5B8gVhygnG17h59kszi1yB5BvClPM20wnlAJMVZKEgTDnB6DnAOILY/SiC/ECYygeMLUh1YUZ/vn6AmgWGMJUNZmkwRIFHt43XtuPnNVdrrCCiQyv4/tEn8wphKpaA9pcUPra44yvUCwlXhWzvGGxB4oaY9e9pdGg5j3T8jOFE8VxjzarhMfjJYWuYnvHBqN08W5Bo3PPwSEZMXrmcvxrhkY79CwphyoT5qP/63ddIckxGB/t2281xvNA7+Mr2plpf+mk9VbVqf9fu1NB4ID9/JLpUmU8V37lT0xKey+ejg5e//fgdX+nKPmtRi1rUov4f9B+IBMnVIJV2nAAAAABJRU5ErkJggg==';
        this.markersLegend = [];
        this.htmlClass = '';
        this._clusterMarkers = {};
        this._isLayerError = false;
        this._isMarkerLoaded = false;
        this._isTilesLoaded = false;
        this._layerReloadTimes = 0;
        this._tileloadIndex = 0;
    }
    ngOnInit() {
        window.addEventListener('resize', this._resizeMap);
        if (typeof this.config.id === 'undefined') {
            this.config.id = 'kdx-map-01';
        }
    }
    ngOnChanges(_simpleChanges) {
        if (_simpleChanges.hasOwnProperty('api')) {
            this._initApi();
        }
        if (_simpleChanges.hasOwnProperty('position')) {
            this._validateLatLng(_simpleChanges.position.currentValue);
            if (!_simpleChanges['position'].firstChange && this.isMapShown) {
                if (typeof this._myMap === 'undefined') {
                    timer(200).subscribe(() => { this._reinitMap(); });
                }
                else
                    this._myMap.panTo(this.position);
            }
        }
        if (_simpleChanges.hasOwnProperty('config')) {
            this.errorMessage = _simpleChanges.config.currentValue.errorMessage || 'Invalid latitude/longitude value';
            if (_simpleChanges.hasOwnProperty('position')) {
                if (_simpleChanges.config.currentValue.googleLink && _simpleChanges.config.currentValue.googleLink.display && this.isMapShown) {
                    this._setGoogleLink(_simpleChanges.position.currentValue);
                }
            }
            if (!_simpleChanges['config'].firstChange) {
                if (this.config.zoom) {
                    this._checkZoomConfig(this.config.zoom);
                    if (this.config.zoom.value) {
                        if (typeof this._myMap !== 'undefined')
                            this._myMap.setZoom(this.config.zoom.value);
                    }
                }
                if (this.config.attribution)
                    this._removeDefaultAttribution(this.config.attribution);
                if (this.config.type !== 'basic') {
                    this._removeAllMarkerLayers();
                    this._setMarkers();
                }
            }
            this._setDefaultConfig();
        }
        if (_simpleChanges.hasOwnProperty('data') && !_simpleChanges['data'].firstChange && this.config.type !== 'basic') {
            this._removeAllMarkerLayers();
            this._setMarkers();
        }
    }
    ngAfterViewInit() {
        if (this.isMapShown) {
            this._initMap();
            this._cd.detectChanges();
            this._resizeMap();
        }
    }
    ngOnDestroy() {
        window.removeEventListener('resize', this._resizeMap);
    }
    onLegendClick(_legendItem) {
        let legendItemMarker = this._elementRef.nativeElement.querySelector('#kdli-' + _legendItem.id + ' .awesome-marker');
        let legendItemLabel = this._elementRef.nativeElement.querySelector('#kdli-' + _legendItem.id + ' .kdx-legend-label');
        let selectedMarkerGroup;
        switch (this.config.type) {
            case 'cluster':
            case 'group-cluster':
                selectedMarkerGroup = this._clusterMarkers[_legendItem.id];
                break;
            default:
                selectedMarkerGroup = this._marker;
                break;
        }
        if (this._myMap.hasLayer(selectedMarkerGroup)) {
            this._myMap.removeLayer(selectedMarkerGroup);
            this._kdDomElemSvc.addClass(legendItemMarker, 'awesome-marker-icon-lightgray');
            this._kdDomElemSvc.addClass(legendItemLabel, 'kdx-label-lightgray');
        }
        else {
            this._myMap.addLayer(selectedMarkerGroup);
            this._kdDomElemSvc.removeClass(legendItemMarker, 'awesome-marker-icon-lightgray');
            this._kdDomElemSvc.removeClass(legendItemLabel, 'kdx-label-lightgray');
        }
    }
    _validateLatLng(_position) {
        if (!_position) {
            this.isMapShown = false;
            this.isMapError = !this.isMapShown;
        }
        else {
            let _lat = _position.lat;
            let _lng = _position.lng;
            this.isMapShown = (typeof _lat === 'undefined') || (typeof _lng === 'undefined') || (_lng < -180 || _lng > 180) || (_lat < -90 || _lat > 90) ? false : true;
            this.isMapError = !this.isMapShown;
        }
        if (!this.isMapShown && this._myMap) {
            delete this._myMap;
            delete this._layer;
            delete this._marker;
            delete this._clusterMarkers;
            delete this.markersLegend;
        }
    }
    _initMap() {
        this._myMap = L.map(this.myMap.nativeElement, {
            center: this.position,
            zoom: (this.config.zoom && this.config.zoom.value) || 14,
        });
        if (this.config.zoom)
            this._checkZoomConfig(this.config.zoom);
        this._setLayer();
        this._setMarkers();
        this._removeDefaultAttribution(this.config.attribution);
        if (this.config.googleLink && this.config.googleLink.display && this.config.type === 'basic')
            this._setLinkStyle(this.config.zoom, this.config.googleLink.position);
    }
    _reinitMap() {
        timer(50).subscribe(() => {
            if (typeof this.myMap === 'undefined')
                this._reinitMap();
            else
                this._initMap();
        });
    }
    _initApi() {
        if (typeof this.api !== 'undefined' && Object.keys(this.api).length === 0) {
            this.api.resizeMap = () => this._resizeMap();
            this.api.getZoom = () => this._myMap.getZoom();
        }
    }
    _checkZoomConfig(_config) {
        if (typeof this._myMap !== 'undefined') {
            _config.isZoomButton ? this._myMap.addControl(this._myMap.zoomControl) : this._myMap.removeControl(this._myMap.zoomControl);
            _config.isScrollZoom ? this._myMap.scrollWheelZoom.enable() : this._myMap.scrollWheelZoom.disable();
            _config.isTouchZoom ? this._myMap.touchZoom.enable() : this._myMap.touchZoom.disable();
            _config.isDoubleClickZoom ? this._myMap.doubleClickZoom.enable() : this._myMap.doubleClickZoom.disable();
        }
    }
    _setLayer() {
        if (this._layer)
            this._layer.remove();
        this._isLayerError = false;
        this.isLayerLoading = true;
        this._layer = L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
            attribution: '&copy; <a href="http://www.openstreetmap.org/copyright">OpenStreetMap</a>',
            maxZoom: 18,
        });
        this._layer.addTo(this._myMap);
        this._attachTileListener();
    }
    _removeDefaultAttribution(_attribution) {
        let attributionElement = this._elementRef.nativeElement.querySelector('.leaflet-control-attribution');
        if (attributionElement !== null) {
            let newAttributionElement = this._kdDomElemSvc.createElement(attributionElement, 'custom-attribution');
            newAttributionElement.innerText = _attribution || 'OpenEMIS';
            attributionElement.replaceChild(newAttributionElement, attributionElement.firstChild);
        }
    }
    _attachTileListener() {
        /* Checks every tile. Only called when some tile load has failed. */
        this._layer.on('tileerror', (error) => {
            // only execute the following for the first tile error
            if (!this._isLayerError) {
                this._isLayerError = true;
                this._layerReloadTimes++;
                if (this._layerReloadTimes < 5 || this._layerReloadTimes === 5) {
                    this._setLayer();
                }
                if (this._layerReloadTimes > 5) {
                    this.isMapShown = false;
                    this.errorMessage = 'Max retry reached. Map cannot be loaded now. Please check your internet connection or try again later.';
                }
            }
        });
        /* Checks every tile. Only called when each tile load is successful. */
        this._layer.on('tileload', () => {
            this._tileloadIndex++;
            if (this.isLayerLoading && this._tileloadIndex === Object.keys(this._layer._tiles).length) {
                // only stop progress loader when last tile loaded successfully
                // this.isLayerLoading = false;
                this._isTilesLoaded = true;
                this._hideLoadingScreen();
                // reset counters
                this._layerReloadTimes = 0;
                this._tileloadIndex = 0;
            }
        });
    }
    _resizeMap() {
        if (this.isMapShown) {
            timer().subscribe(() => {
                this._myMap.invalidateSize({});
            });
        }
    }
    _setGoogleLink(_position) {
        if (this.config.type === 'basic') {
            this.isLinkToGoogle = true;
            this.googleLink = 'https://www.google.com/maps/?q=' + _position.lat.toString() + ',' + _position.lng.toString();
        }
        else {
            this.isLinkToGoogle = false;
        }
    }
    _setLinkStyle(_zoomConfig, _linkPosition) {
        let linkElement = this._elementRef.nativeElement.querySelector('.kdx-map .link-wrapper');
        switch (_linkPosition) {
            case 'top-left':
            default:
                // only when Zoom Buttons are removed then we put googleLink at the position of the Zoom Buttons
                let newClass = _zoomConfig && _zoomConfig.isZoomButton === false ? '' : ' below-zoom';
                this._kdDomElemSvc.addClass(linkElement, 'leaflet-top leaflet-left' + newClass);
                break;
            case 'top-right':
                this._kdDomElemSvc.addClass(linkElement, 'leaflet-top leaflet-right');
                break;
            case 'bottom-left':
                this._kdDomElemSvc.addClass(linkElement, 'leaflet-bottom leaflet-left');
                break;
            case 'bottom-right':
                this._kdDomElemSvc.addClass(linkElement, 'leaflet-bottom leaflet-right above-attribution');
                break;
        }
    }
    _setMarkers() {
        if (typeof this._myMap !== 'undefined') {
            switch (this.config.type) {
                case 'cluster':
                case 'group-cluster':
                    if (typeof this.data !== 'undefined' && Object.keys(this.data).length !== 0) {
                        let clusterData = this._kdMapSvc.populateMarkers(this.data, this._myMap, this.config.type);
                        this.markersLegend = clusterData.markersLegend;
                        this._clusterMarkers = clusterData.clusterMarkers;
                        this._isMarkerLoaded = true;
                    }
                    break;
                default:
                    let defaultIcon = {
                        markerColor: 'purple',
                        title: this.config.marker.title
                    };
                    let iconMarker = this._kdMapSvc.setIcon(defaultIcon);
                    this._marker = L.marker(this.position, { icon: iconMarker }).addTo(this._myMap);
                    this._isMarkerLoaded = true;
                    if (this.config.hasOwnProperty('content')) {
                        this._marker.bindPopup(this.config.content);
                    }
                    if (this.config.hasOwnProperty('legend')) {
                        this.markersLegend = [{
                                icon: iconMarker.createIcon(),
                                label: this.config.marker.title,
                                id: this.config.marker.hasOwnProperty('id') ? this.config.marker.id : 'kdx-single-marker'
                            }];
                    }
                    break;
            }
        }
        this._hideLoadingScreen();
    }
    _hideLoadingScreen() {
        if (this._isMarkerLoaded && this._isTilesLoaded) {
            this.isLayerLoading = false;
        }
    }
    _removeAllMarkerLayers() {
        for (let legendItemId in this._clusterMarkers) {
            if (this._clusterMarkers[legendItemId])
                this._myMap.removeLayer(this._clusterMarkers[legendItemId]);
        }
        this.markersLegend = [];
    }
    _setDefaultConfig() {
        this.mapConfig = this._kdMapSvc.getDefaultConfig();
        this._dataSvc.deepMergeObject(this.mapConfig, this.config, false);
        this.mapConfig.legend.enabled = this._setEnabled('legend', ['title']);
        if (this.mapConfig.footer)
            this.mapConfig.footer.enabled = this._setEnabled('footer', ['bottomLabel', 'footNote']);
        this._setClassNames();
    }
    _setEnabled(_objKey, _textKeys) {
        if (this.mapConfig[_objKey] && typeof this.mapConfig[_objKey].enabled !== 'undefined') {
            return this.mapConfig[_objKey].enabled;
        }
        for (let i = _textKeys.length - 1; i >= 0; i--) {
            if (this.mapConfig[_objKey][_textKeys[i]] && this.mapConfig[_objKey][_textKeys[i]].text !== '') {
                return true;
            }
        }
        if (_objKey === 'legend' && this.markersLegend.length === 0) {
            return false;
        }
        return false;
    }
    /* To be revisit. Hot fix for downgrade component as ngclass value doesn't change.*/
    _setClassNames() {
        // htmlClassObj is a workaround for downgrade method
        this.htmlClass = '';
        if (typeof this.config.legend.float !== 'undefined' && this.config.legend.float) {
            this.htmlClass += 'legend-float ';
        }
        if (typeof this.config.legend.verticalAlign !== 'undefined') {
            this.htmlClass += this.config.legend.verticalAlign + ' ';
        }
        if (typeof this.config.legend.align !== 'undefined') {
            this.htmlClass += this.config.legend.align;
        }
    }
}
KdMap.decorators = [
    { type: Component, args: [{
                selector: 'kd-map',
                template: "<div class=\"kdx-charts-wrapper {{htmlClass}}\" id=\"{{config.id}}\">\r\n    <div class=\"kdx-charts-main\">\r\n        <div class=\"kdx-header-container\" *ngIf=\"mapConfig.title && mapConfig.title.text && mapConfig.title.text !== '' || mapConfig.subtitle && mapConfig.subtitle.text && mapConfig.subtitle.text !== ''\">\r\n            <div class=\"kdx-chart-title {{mapConfig.title.align}}\" *ngIf=\"mapConfig.title && mapConfig.title.text && mapConfig.title.text !== ''\" [ngStyle]=\"mapConfig.title.style\">\r\n                {{mapConfig.title.text}}\r\n            </div>\r\n            <div class=\"kdx-chart-subtitle {{mapConfig.subtitle.align}}\" *ngIf=\"mapConfig.subtitle && mapConfig.subtitle.text && mapConfig.subtitle.text !== ''\" [ngStyle]=\"mapConfig.subtitle.style\">\r\n                {{mapConfig.subtitle.text}}\r\n            </div>\r\n        </div>\r\n        <div class=\"kdx-chart-container\" *ngIf=\"isMapShown\" #myMap>\r\n            <div class=\"link-wrapper\" *ngIf=\"isLinkToGoogle\">\r\n                <a class=\"google-link leaflet-bar leaflet-control\" [attr.href]=\"googleLink\" target=\"_blank\">\r\n                    <img class=\"google-image\" [src]=\"googleImage\">\r\n                </a>\r\n            </div>\r\n        </div>\r\n        <div class=\"kdx-error-map\" *ngIf=\"!isMapShown\">\r\n            <div class=\"kdx-error-icon\"><i class=\"fa fa-map-o\"></i></div>\r\n            <div class=\"kdx-error-message\">{{errorMessage}}</div>\r\n        </div>\r\n    </div>\r\n    <div class=\"kdx-legend-container {{htmlClass}}\" *ngIf=\"mapConfig.legend.enabled && isMapShown\">\r\n        <div class=\"kdx-legends\" *ngIf=\"mapConfig.legend\" [ngStyle]=\"mapConfig.legend.style\">\r\n            <div class=\"kdx-legend-title-container {{mapConfig.legend.title.align}}\" *ngIf=\"mapConfig.legend.title && mapConfig.legend.title.text && mapConfig.legend.title.text !== ''\" [ngStyle]=\"mapConfig.legend.title.style\">\r\n                <div class=\"kdx-legend-title\">{{mapConfig.legend.title.text}}</div>\r\n            </div>\r\n            <div class=\"kdx-legend legend-scroll {{mapConfig.legend.layout}}\">\r\n                <div class=\"kdx-legend-item\" id=\"kdli-{{legendItem.id}}\" *ngFor=\"let legendItem of markersLegend\" (click)=\"onLegendClick(legendItem)\">\r\n                    <div class=\"kdx-legend-marker\" [innerHTML]=\"legendItem.icon.outerHTML\"></div>\r\n                    <div class=\"kdx-legend-label\" [ngStyle]=\"mapConfig.legend.item.style\">\r\n                        <div class=\"kdx-label-text\">{{legendItem.label}}</div>\r\n                    </div>\r\n                </div>\r\n            </div>\r\n        </div>\r\n    </div>\r\n    <kd-progressloader *ngIf=\"isLayerLoading && isMapShown\" configtype=\"small-spinner\" [configvalue]=\"smallLoaderValue\"></kd-progressloader>\r\n</div>\r\n<div class=\"kdx-charts-footer\" *ngIf=\"mapConfig.footer && mapConfig.footer.enabled\">\r\n    <div class=\"kdx-charts-bottom-label {{mapConfig.footer.bottomLabel.align}}\" *ngIf=\"mapConfig.footer && mapConfig.footer.bottomLabel && mapConfig.footer.bottomLabel.text && mapConfig.footer.bottomLabel.text !== ''\" [ngStyle]=\"mapConfig.footer.bottomLabel.style\">\r\n        {{mapConfig.footer.bottomLabel.text}}\r\n    </div>\r\n    <div class=\"kdx-charts-foot-note {{mapConfig.footer.footNote.align}}\" *ngIf=\"mapConfig.footer && mapConfig.footer.footNote && mapConfig.footer.footNote.text && mapConfig.footer.footNote.text !== ''\" [ngStyle]=\"mapConfig.footer.footNote.style\">\r\n        {{mapConfig.footer.footNote.text}}\r\n    </div>\r\n</div>",
                /*template: `
                        <div class="header-container">
                            <div class="chart-title left">{{config.legend.title.text}}</div>
                            <div class="chart-subtitle right">{{config.legend.title.text}}</div>
                        </div>
                        <div *ngIf="isMapShown" class="chart-container"  #myMap>
                            <div class="link-wrapper" *ngIf="isLinkToGoogle">
                                <a [attr.href]="googleLink" target="_blank" class="google-link leaflet-bar leaflet-control">
                                    <img class="google-image" [src]="googleImage">
                                </a>
                            </div>
                        </div>
                        <div class="legend-container center" *ngIf="config.legend && isMapShown">
                            <div class="legends">
                                <div class="legend-title-container right" *ngIf="config.legend.title.text">
                                    <div class="title">{{config.legend.title.text}}</div>
                                </div>
                                <div class="legend">
                                    <div class="legend-item" id="kdli-{{legendItem.id}}" *ngFor="let legendItem of markersLegend" (click)="onLegendClick(legendItem)">
                                        <div class="legend-marker" [innerHTML]="legendItem.icon.outerHTML" ></div>
                                        <div class="legend-label"><div class="label-text">{{legendItem.label}}</div></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div *ngIf="!isMapShown" class="error-map">
                            <div class="error-icon"><i class="fa fa-map-o"></i></div>
                            <div class="error-message">{{errorMessage}}</div>
                        </div>
                        <kd-progressloader *ngIf="isLayerLoading && isMapShown" configtype="small-spinner" [configvalue]="smallLoaderValue"></kd-progressloader>
            
                `,*/
                encapsulation: ViewEncapsulation.None,
                host: {
                    'class': 'kdx-map',
                    '[style.background-color]': 'mapConfig.mapArea.style.backgroundColor',
                    '[style.font-family]': 'mapConfig.mapArea.style.fontFamily'
                },
                providers: [KdDomElemSvc, KdMapSvc, KdDataSvc]
            },] }
];
KdMap.ctorParameters = () => [
    { type: ElementRef },
    { type: KdSplitterEvent },
    { type: KdDomElemSvc },
    { type: KdMapSvc },
    { type: ChangeDetectorRef },
    { type: KdDataSvc }
];
KdMap.propDecorators = {
    position: [{ type: Input }],
    config: [{ type: Input }],
    data: [{ type: Input }],
    api: [{ type: Input }],
    myMap: [{ type: ViewChild, args: ['myMap',] }],
    isMapError: [{ type: HostBinding, args: ['class.error',] }]
};
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoia2QtYW5ndWxhci1tYXAuanMiLCJzb3VyY2VSb290IjoiRDovb3BlbkVNSVMvc3R5bGVndWlkZS9pb3N0Zy1vcGVuZW1pcy1zdHlsZWd1aWRlL3Byb2plY3RzL29wZW5lbWlzLXN0eWxlZ3VpZGUtbGliL3NyYy8iLCJzb3VyY2VzIjpbImtkLWNvbXBvbmVudHMva2QtYW5ndWxhci1tYXAva2QtYW5ndWxhci1tYXAudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsT0FBTyxFQUNILFNBQVMsRUFDVCxpQkFBaUIsRUFDakIsS0FBSyxFQUtMLFVBQVUsRUFFVixTQUFTLEVBRVQsV0FBVyxFQUNYLGlCQUFpQixFQUNwQixNQUFNLGVBQWUsQ0FBQztBQUN2QixvREFBb0Q7QUFDcEQsT0FBTyxFQUFFLEtBQUssRUFBRSxNQUFNLE1BQU0sQ0FBQztBQUM3QixpREFBaUQ7QUFDakQsT0FBTyxLQUFLLENBQUMsTUFBTSxTQUFTLENBQUM7QUFDN0IsT0FBTyx1QkFBdUIsQ0FBQztBQUMvQixPQUFPLHNEQUFzRCxDQUFDO0FBQzlELE9BQU8sRUFBRSxlQUFlLEVBQUUsTUFBTSw4QkFBOEIsQ0FBQztBQUMvRCxPQUFPLEVBQUUsWUFBWSxFQUFFLE1BQU0sb0JBQW9CLENBQUM7QUFDbEQsT0FBTyxFQUFFLFFBQVEsRUFBMkIsTUFBTSxzQkFBc0IsQ0FBQztBQVN6RSxPQUFPLEVBQUUsU0FBUyxFQUFFLE1BQU0sb0JBQW9CLENBQUM7QUE4Qy9DLE1BQU0sT0FBTyxLQUFLO0lBd0NkLFlBQ1ksV0FBdUIsRUFDL0IsZ0JBQWlDLEVBQ3pCLGFBQTJCLEVBQzNCLFNBQW1CLEVBQ25CLEdBQXNCLEVBQ3RCLFFBQW1CO1FBTG5CLGdCQUFXLEdBQVgsV0FBVyxDQUFZO1FBRXZCLGtCQUFhLEdBQWIsYUFBYSxDQUFjO1FBQzNCLGNBQVMsR0FBVCxTQUFTLENBQVU7UUFDbkIsUUFBRyxHQUFILEdBQUcsQ0FBbUI7UUFDdEIsYUFBUSxHQUFSLFFBQVEsQ0FBVztRQTVDL0IscStEQUFxK0Q7UUFDcitELCszQkFBKzNCO1FBRXgzQixxQkFBZ0IsR0FBUSxJQUFJLENBQUM7UUFDN0IsZUFBVSxHQUFZLElBQUksQ0FBQztRQUMzQixtQkFBYyxHQUFZLElBQUksQ0FBQztRQUMvQixtQkFBYyxHQUFZLEtBQUssQ0FBQztRQUNoQyxlQUFVLEdBQVcsRUFBRSxDQUFDO1FBQ3hCLGlCQUFZLEdBQVcsRUFBRSxDQUFDO1FBQzFCLGdCQUFXLEdBQVcsZzdFQUFnN0UsQ0FBQztRQUV2OEUsa0JBQWEsR0FBZSxFQUFFLENBQUM7UUFFL0IsY0FBUyxHQUFXLEVBQUUsQ0FBQztRQVF0QixvQkFBZSxHQUE0QyxFQUFFLENBQUM7UUFFOUQsa0JBQWEsR0FBWSxLQUFLLENBQUM7UUFDL0Isb0JBQWUsR0FBWSxLQUFLLENBQUM7UUFDakMsbUJBQWMsR0FBWSxLQUFLLENBQUM7UUFDaEMsc0JBQWlCLEdBQVcsQ0FBQyxDQUFDO1FBQzlCLG1CQUFjLEdBQVcsQ0FBQyxDQUFDO0lBa0IvQixDQUFDO0lBRUwsUUFBUTtRQUNKLE1BQU0sQ0FBQyxnQkFBZ0IsQ0FBQyxRQUFRLEVBQUUsSUFBSSxDQUFDLFVBQVUsQ0FBQyxDQUFDO1FBRW5ELElBQUksT0FBTyxJQUFJLENBQUMsTUFBTSxDQUFDLEVBQUUsS0FBSyxXQUFXLEVBQUU7WUFDdkMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxFQUFFLEdBQUcsWUFBWSxDQUFDO1NBQ2pDO0lBQ0wsQ0FBQztJQUVELFdBQVcsQ0FBQyxjQUE2QjtRQUNyQyxJQUFJLGNBQWMsQ0FBQyxjQUFjLENBQUMsS0FBSyxDQUFDLEVBQUU7WUFDdEMsSUFBSSxDQUFDLFFBQVEsRUFBRSxDQUFDO1NBQ25CO1FBRUQsSUFBSSxjQUFjLENBQUMsY0FBYyxDQUFDLFVBQVUsQ0FBQyxFQUFFO1lBQzNDLElBQUksQ0FBQyxlQUFlLENBQUMsY0FBYyxDQUFDLFFBQVEsQ0FBQyxZQUFZLENBQUMsQ0FBQztZQUUzRCxJQUFJLENBQUMsY0FBYyxDQUFDLFVBQVUsQ0FBQyxDQUFDLFdBQVcsSUFBSSxJQUFJLENBQUMsVUFBVSxFQUFFO2dCQUU1RCxJQUFJLE9BQU8sSUFBSSxDQUFDLE1BQU0sS0FBSyxXQUFXLEVBQUU7b0JBQ3BDLEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FBQyxTQUFTLENBQUMsR0FBUyxFQUFFLEdBQUcsSUFBSSxDQUFDLFVBQVUsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7aUJBQzVEOztvQkFDSSxJQUFJLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLENBQUM7YUFDekM7U0FDSjtRQUdELElBQUksY0FBYyxDQUFDLGNBQWMsQ0FBQyxRQUFRLENBQUMsRUFBRTtZQUN6QyxJQUFJLENBQUMsWUFBWSxHQUFHLGNBQWMsQ0FBQyxNQUFNLENBQUMsWUFBWSxDQUFDLFlBQVksSUFBSSxrQ0FBa0MsQ0FBQztZQUUxRyxJQUFJLGNBQWMsQ0FBQyxjQUFjLENBQUMsVUFBVSxDQUFDLEVBQUU7Z0JBQzNDLElBQUksY0FBYyxDQUFDLE1BQU0sQ0FBQyxZQUFZLENBQUMsVUFBVSxJQUFJLGNBQWMsQ0FBQyxNQUFNLENBQUMsWUFBWSxDQUFDLFVBQVUsQ0FBQyxPQUFPLElBQUksSUFBSSxDQUFDLFVBQVUsRUFBRTtvQkFDM0gsSUFBSSxDQUFDLGNBQWMsQ0FBQyxjQUFjLENBQUMsUUFBUSxDQUFDLFlBQVksQ0FBQyxDQUFDO2lCQUM3RDthQUNKO1lBQ0QsSUFBSSxDQUFDLGNBQWMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxXQUFXLEVBQUU7Z0JBQ3ZDLElBQUksSUFBSSxDQUFDLE1BQU0sQ0FBQyxJQUFJLEVBQUU7b0JBQ2xCLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxDQUFDO29CQUV4QyxJQUFJLElBQUksQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLEtBQUssRUFBRTt3QkFDeEIsSUFBSSxPQUFPLElBQUksQ0FBQyxNQUFNLEtBQUssV0FBVzs0QkFBRSxJQUFJLENBQUMsTUFBTSxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQztxQkFDdkY7aUJBQ0o7Z0JBRUQsSUFBSSxJQUFJLENBQUMsTUFBTSxDQUFDLFdBQVc7b0JBQUUsSUFBSSxDQUFDLHlCQUF5QixDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsV0FBVyxDQUFDLENBQUM7Z0JBRXJGLElBQUksSUFBSSxDQUFDLE1BQU0sQ0FBQyxJQUFJLEtBQUssT0FBTyxFQUFFO29CQUM5QixJQUFJLENBQUMsc0JBQXNCLEVBQUUsQ0FBQztvQkFDOUIsSUFBSSxDQUFDLFdBQVcsRUFBRSxDQUFDO2lCQUN0QjthQUNKO1lBRUQsSUFBSSxDQUFDLGlCQUFpQixFQUFFLENBQUM7U0FDNUI7UUFFRCxJQUFJLGNBQWMsQ0FBQyxjQUFjLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxjQUFjLENBQUMsTUFBTSxDQUFDLENBQUMsV0FBVyxJQUFJLElBQUksQ0FBQyxNQUFNLENBQUMsSUFBSSxLQUFLLE9BQU8sRUFBRTtZQUM5RyxJQUFJLENBQUMsc0JBQXNCLEVBQUUsQ0FBQztZQUM5QixJQUFJLENBQUMsV0FBVyxFQUFFLENBQUM7U0FDdEI7SUFDTCxDQUFDO0lBRUQsZUFBZTtRQUNYLElBQUksSUFBSSxDQUFDLFVBQVUsRUFBRTtZQUNqQixJQUFJLENBQUMsUUFBUSxFQUFFLENBQUM7WUFDaEIsSUFBSSxDQUFDLEdBQUcsQ0FBQyxhQUFhLEVBQUUsQ0FBQztZQUV6QixJQUFJLENBQUMsVUFBVSxFQUFFLENBQUM7U0FDckI7SUFDTCxDQUFDO0lBRUQsV0FBVztRQUNQLE1BQU0sQ0FBQyxtQkFBbUIsQ0FBQyxRQUFRLEVBQUUsSUFBSSxDQUFDLFVBQVUsQ0FBQyxDQUFDO0lBQzFELENBQUM7SUFFTSxhQUFhLENBQUMsV0FBZ0I7UUFDakMsSUFBSSxnQkFBZ0IsR0FBZ0IsSUFBSSxDQUFDLFdBQVcsQ0FBQyxhQUFhLENBQUMsYUFBYSxDQUFDLFFBQVEsR0FBRyxXQUFXLENBQUMsRUFBRSxHQUFHLGtCQUFrQixDQUFDLENBQUM7UUFDakksSUFBSSxlQUFlLEdBQWdCLElBQUksQ0FBQyxXQUFXLENBQUMsYUFBYSxDQUFDLGFBQWEsQ0FBQyxRQUFRLEdBQUcsV0FBVyxDQUFDLEVBQUUsR0FBRyxvQkFBb0IsQ0FBQyxDQUFDO1FBQ2xJLElBQUksbUJBQW9ELENBQUM7UUFFekQsUUFBUSxJQUFJLENBQUMsTUFBTSxDQUFDLElBQUksRUFBRTtZQUN0QixLQUFLLFNBQVMsQ0FBQztZQUNmLEtBQUssZUFBZTtnQkFDaEIsbUJBQW1CLEdBQUcsSUFBSSxDQUFDLGVBQWUsQ0FBQyxXQUFXLENBQUMsRUFBRSxDQUFDLENBQUM7Z0JBQzNELE1BQU07WUFDVjtnQkFDSSxtQkFBbUIsR0FBRyxJQUFJLENBQUMsT0FBTyxDQUFDO2dCQUNuQyxNQUFNO1NBQ2I7UUFFRCxJQUFJLElBQUksQ0FBQyxNQUFNLENBQUMsUUFBUSxDQUFDLG1CQUFtQixDQUFDLEVBQUU7WUFDM0MsSUFBSSxDQUFDLE1BQU0sQ0FBQyxXQUFXLENBQUMsbUJBQW1CLENBQUMsQ0FBQztZQUM3QyxJQUFJLENBQUMsYUFBYSxDQUFDLFFBQVEsQ0FBQyxnQkFBZ0IsRUFBRSwrQkFBK0IsQ0FBQyxDQUFDO1lBQy9FLElBQUksQ0FBQyxhQUFhLENBQUMsUUFBUSxDQUFDLGVBQWUsRUFBRSxxQkFBcUIsQ0FBQyxDQUFDO1NBQ3ZFO2FBQ0k7WUFDRCxJQUFJLENBQUMsTUFBTSxDQUFDLFFBQVEsQ0FBQyxtQkFBbUIsQ0FBQyxDQUFDO1lBQzFDLElBQUksQ0FBQyxhQUFhLENBQUMsV0FBVyxDQUFDLGdCQUFnQixFQUFFLCtCQUErQixDQUFDLENBQUM7WUFDbEYsSUFBSSxDQUFDLGFBQWEsQ0FBQyxXQUFXLENBQUMsZUFBZSxFQUFFLHFCQUFxQixDQUFDLENBQUM7U0FDMUU7SUFDTCxDQUFDO0lBRU8sZUFBZSxDQUFDLFNBQXVCO1FBQzNDLElBQUksQ0FBQyxTQUFTLEVBQUU7WUFDWixJQUFJLENBQUMsVUFBVSxHQUFHLEtBQUssQ0FBQztZQUN4QixJQUFJLENBQUMsVUFBVSxHQUFHLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQztTQUN0QzthQUFNO1lBQ0gsSUFBSSxJQUFJLEdBQVcsU0FBUyxDQUFDLEdBQUcsQ0FBQztZQUNqQyxJQUFJLElBQUksR0FBVyxTQUFTLENBQUMsR0FBRyxDQUFDO1lBQ2pDLElBQUksQ0FBQyxVQUFVLEdBQUcsQ0FBQyxPQUFPLElBQUksS0FBSyxXQUFXLENBQUMsSUFBSSxDQUFDLE9BQU8sSUFBSSxLQUFLLFdBQVcsQ0FBQyxJQUFJLENBQUMsSUFBSSxHQUFHLENBQUMsR0FBRyxJQUFJLElBQUksR0FBRyxHQUFHLENBQUMsSUFBSSxDQUFDLElBQUksR0FBRyxDQUFDLEVBQUUsSUFBSSxJQUFJLEdBQUcsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDO1lBQzVKLElBQUksQ0FBQyxVQUFVLEdBQUcsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDO1NBQ3RDO1FBQ0QsSUFBSSxDQUFDLElBQUksQ0FBQyxVQUFVLElBQUksSUFBSSxDQUFDLE1BQU0sRUFBRTtZQUNqQyxPQUFPLElBQUksQ0FBQyxNQUFNLENBQUM7WUFDbkIsT0FBTyxJQUFJLENBQUMsTUFBTSxDQUFDO1lBQ25CLE9BQU8sSUFBSSxDQUFDLE9BQU8sQ0FBQztZQUNwQixPQUFPLElBQUksQ0FBQyxlQUFlLENBQUM7WUFDNUIsT0FBTyxJQUFJLENBQUMsYUFBYSxDQUFDO1NBQzdCO0lBQ0wsQ0FBQztJQUVPLFFBQVE7UUFFWixJQUFJLENBQUMsTUFBTSxHQUFHLENBQUMsQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxhQUFhLEVBQUU7WUFDMUMsTUFBTSxFQUFFLElBQUksQ0FBQyxRQUFRO1lBQ3JCLElBQUksRUFBRSxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsSUFBSSxJQUFJLElBQUksQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxJQUFJLEVBQUU7U0FDM0QsQ0FBQyxDQUFDO1FBRUgsSUFBSSxJQUFJLENBQUMsTUFBTSxDQUFDLElBQUk7WUFBRSxJQUFJLENBQUMsZ0JBQWdCLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsQ0FBQztRQUU5RCxJQUFJLENBQUMsU0FBUyxFQUFFLENBQUM7UUFDakIsSUFBSSxDQUFDLFdBQVcsRUFBRSxDQUFDO1FBRW5CLElBQUksQ0FBQyx5QkFBeUIsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLFdBQVcsQ0FBQyxDQUFDO1FBQ3hELElBQUksSUFBSSxDQUFDLE1BQU0sQ0FBQyxVQUFVLElBQUksSUFBSSxDQUFDLE1BQU0sQ0FBQyxVQUFVLENBQUMsT0FBTyxJQUFJLElBQUksQ0FBQyxNQUFNLENBQUMsSUFBSSxLQUFLLE9BQU87WUFBRSxJQUFJLENBQUMsYUFBYSxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsSUFBSSxFQUFFLElBQUksQ0FBQyxNQUFNLENBQUMsVUFBVSxDQUFDLFFBQVEsQ0FBQyxDQUFDO0lBQ3hLLENBQUM7SUFFTyxVQUFVO1FBQ2QsS0FBSyxDQUFDLEVBQUUsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxHQUFTLEVBQUU7WUFDM0IsSUFBSSxPQUFPLElBQUksQ0FBQyxLQUFLLEtBQUssV0FBVztnQkFBRSxJQUFJLENBQUMsVUFBVSxFQUFFLENBQUM7O2dCQUNwRCxJQUFJLENBQUMsUUFBUSxFQUFFLENBQUM7UUFDekIsQ0FBQyxDQUFDLENBQUM7SUFDUCxDQUFDO0lBRU8sUUFBUTtRQUNaLElBQUksT0FBTyxJQUFJLENBQUMsR0FBRyxLQUFLLFdBQVcsSUFBSSxNQUFNLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQyxNQUFNLEtBQUssQ0FBQyxFQUFFO1lBQ3ZFLElBQUksQ0FBQyxHQUFHLENBQUMsU0FBUyxHQUFHLEdBQVMsRUFBRSxDQUFDLElBQUksQ0FBQyxVQUFVLEVBQUUsQ0FBQztZQUNuRCxJQUFJLENBQUMsR0FBRyxDQUFDLE9BQU8sR0FBRyxHQUFXLEVBQUUsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLE9BQU8sRUFBRSxDQUFDO1NBQzFEO0lBQ0wsQ0FBQztJQUVPLGdCQUFnQixDQUFDLE9BQXVCO1FBQzVDLElBQUksT0FBTyxJQUFJLENBQUMsTUFBTSxLQUFLLFdBQVcsRUFBRTtZQUNwQyxPQUFPLENBQUMsWUFBWSxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLFVBQVUsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLGFBQWEsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLFdBQVcsQ0FBQyxDQUFDO1lBQzVILE9BQU8sQ0FBQyxZQUFZLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsZUFBZSxDQUFDLE1BQU0sRUFBRSxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLGVBQWUsQ0FBQyxPQUFPLEVBQUUsQ0FBQztZQUNwRyxPQUFPLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLFNBQVMsQ0FBQyxNQUFNLEVBQUUsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxTQUFTLENBQUMsT0FBTyxFQUFFLENBQUM7WUFDdkYsT0FBTyxDQUFDLGlCQUFpQixDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLGVBQWUsQ0FBQyxNQUFNLEVBQUUsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxlQUFlLENBQUMsT0FBTyxFQUFFLENBQUM7U0FDNUc7SUFDTCxDQUFDO0lBRU8sU0FBUztRQUNiLElBQUksSUFBSSxDQUFDLE1BQU07WUFBRSxJQUFJLENBQUMsTUFBTSxDQUFDLE1BQU0sRUFBRSxDQUFDO1FBQ3RDLElBQUksQ0FBQyxhQUFhLEdBQUcsS0FBSyxDQUFDO1FBQzNCLElBQUksQ0FBQyxjQUFjLEdBQUcsSUFBSSxDQUFDO1FBQzNCLElBQUksQ0FBQyxNQUFNLEdBQUcsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxvREFBb0QsRUFBRTtZQUM1RSxXQUFXLEVBQUUsMkVBQTJFO1lBQ3hGLE9BQU8sRUFBRSxFQUFFO1NBQ2QsQ0FBQyxDQUFDO1FBQ0gsSUFBSSxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDO1FBQy9CLElBQUksQ0FBQyxtQkFBbUIsRUFBRSxDQUFDO0lBQy9CLENBQUM7SUFFTyx5QkFBeUIsQ0FBQyxZQUFvQjtRQUNsRCxJQUFJLGtCQUFrQixHQUFZLElBQUksQ0FBQyxXQUFXLENBQUMsYUFBYSxDQUFDLGFBQWEsQ0FBQyw4QkFBOEIsQ0FBQyxDQUFDO1FBQy9HLElBQUksa0JBQWtCLEtBQUssSUFBSSxFQUFFO1lBQzdCLElBQUkscUJBQXFCLEdBQWdCLElBQUksQ0FBQyxhQUFhLENBQUMsYUFBYSxDQUFDLGtCQUFrQixFQUFFLG9CQUFvQixDQUFDLENBQUM7WUFDcEgscUJBQXFCLENBQUMsU0FBUyxHQUFHLFlBQVksSUFBSSxVQUFVLENBQUM7WUFDN0Qsa0JBQWtCLENBQUMsWUFBWSxDQUFDLHFCQUFxQixFQUFFLGtCQUFrQixDQUFDLFVBQVUsQ0FBQyxDQUFDO1NBQ3pGO0lBQ0wsQ0FBQztJQUVPLG1CQUFtQjtRQUN2QixvRUFBb0U7UUFDcEUsSUFBSSxDQUFDLE1BQU0sQ0FBQyxFQUFFLENBQUMsV0FBVyxFQUFFLENBQUMsS0FBSyxFQUFRLEVBQUU7WUFDeEMsc0RBQXNEO1lBQ3RELElBQUksQ0FBQyxJQUFJLENBQUMsYUFBYSxFQUFFO2dCQUNyQixJQUFJLENBQUMsYUFBYSxHQUFHLElBQUksQ0FBQztnQkFDMUIsSUFBSSxDQUFDLGlCQUFpQixFQUFFLENBQUM7Z0JBQ3pCLElBQUksSUFBSSxDQUFDLGlCQUFpQixHQUFHLENBQUMsSUFBSSxJQUFJLENBQUMsaUJBQWlCLEtBQUssQ0FBQyxFQUFFO29CQUM1RCxJQUFJLENBQUMsU0FBUyxFQUFFLENBQUM7aUJBQ3BCO2dCQUNELElBQUksSUFBSSxDQUFDLGlCQUFpQixHQUFHLENBQUMsRUFBRTtvQkFDNUIsSUFBSSxDQUFDLFVBQVUsR0FBRyxLQUFLLENBQUM7b0JBQ3hCLElBQUksQ0FBQyxZQUFZLEdBQUcsd0dBQXdHLENBQUM7aUJBQ2hJO2FBQ0o7UUFDTCxDQUFDLENBQUMsQ0FBQztRQUVILHVFQUF1RTtRQUN2RSxJQUFJLENBQUMsTUFBTSxDQUFDLEVBQUUsQ0FBQyxVQUFVLEVBQUUsR0FBUyxFQUFFO1lBQ2xDLElBQUksQ0FBQyxjQUFjLEVBQUUsQ0FBQztZQUN0QixJQUFJLElBQUksQ0FBQyxjQUFjLElBQUksSUFBSSxDQUFDLGNBQWMsS0FBSyxNQUFNLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLENBQUMsTUFBTSxFQUFFO2dCQUN2RiwrREFBK0Q7Z0JBQy9ELCtCQUErQjtnQkFDL0IsSUFBSSxDQUFDLGNBQWMsR0FBRyxJQUFJLENBQUM7Z0JBQzNCLElBQUksQ0FBQyxrQkFBa0IsRUFBRSxDQUFDO2dCQUMxQixpQkFBaUI7Z0JBQ2pCLElBQUksQ0FBQyxpQkFBaUIsR0FBRyxDQUFDLENBQUM7Z0JBQzNCLElBQUksQ0FBQyxjQUFjLEdBQUcsQ0FBQyxDQUFDO2FBQzNCO1FBQ0wsQ0FBQyxDQUFDLENBQUM7SUFDUCxDQUFDO0lBRU8sVUFBVTtRQUNkLElBQUksSUFBSSxDQUFDLFVBQVUsRUFBRTtZQUNqQixLQUFLLEVBQUUsQ0FBQyxTQUFTLENBQUMsR0FBUyxFQUFFO2dCQUN6QixJQUFJLENBQUMsTUFBTSxDQUFDLGNBQWMsQ0FBQyxFQUFFLENBQUMsQ0FBQztZQUNuQyxDQUFDLENBQUMsQ0FBQztTQUNOO0lBQ0wsQ0FBQztJQUVPLGNBQWMsQ0FBQyxTQUF1QjtRQUMxQyxJQUFJLElBQUksQ0FBQyxNQUFNLENBQUMsSUFBSSxLQUFLLE9BQU8sRUFBRTtZQUM5QixJQUFJLENBQUMsY0FBYyxHQUFHLElBQUksQ0FBQztZQUMzQixJQUFJLENBQUMsVUFBVSxHQUFHLGlDQUFpQyxHQUFHLFNBQVMsQ0FBQyxHQUFHLENBQUMsUUFBUSxFQUFFLEdBQUcsR0FBRyxHQUFHLFNBQVMsQ0FBQyxHQUFHLENBQUMsUUFBUSxFQUFFLENBQUM7U0FDbkg7YUFDSTtZQUNELElBQUksQ0FBQyxjQUFjLEdBQUcsS0FBSyxDQUFDO1NBQy9CO0lBQ0wsQ0FBQztJQUVPLGFBQWEsQ0FBQyxXQUEyQixFQUFFLGFBQXFCO1FBQ3BFLElBQUksV0FBVyxHQUFnQixJQUFJLENBQUMsV0FBVyxDQUFDLGFBQWEsQ0FBQyxhQUFhLENBQUMsd0JBQXdCLENBQUMsQ0FBQztRQUN0RyxRQUFRLGFBQWEsRUFBRTtZQUNuQixLQUFLLFVBQVUsQ0FBQztZQUNoQjtnQkFDSSxnR0FBZ0c7Z0JBQ2hHLElBQUksUUFBUSxHQUFXLFdBQVcsSUFBSSxXQUFXLENBQUMsWUFBWSxLQUFLLEtBQUssQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxhQUFhLENBQUM7Z0JBQzlGLElBQUksQ0FBQyxhQUFhLENBQUMsUUFBUSxDQUFDLFdBQVcsRUFBRSwwQkFBMEIsR0FBRyxRQUFRLENBQUMsQ0FBQztnQkFDaEYsTUFBTTtZQUNWLEtBQUssV0FBVztnQkFDWixJQUFJLENBQUMsYUFBYSxDQUFDLFFBQVEsQ0FBQyxXQUFXLEVBQUUsMkJBQTJCLENBQUMsQ0FBQztnQkFDdEUsTUFBTTtZQUNWLEtBQUssYUFBYTtnQkFDZCxJQUFJLENBQUMsYUFBYSxDQUFDLFFBQVEsQ0FBQyxXQUFXLEVBQUUsNkJBQTZCLENBQUMsQ0FBQztnQkFDeEUsTUFBTTtZQUNWLEtBQUssY0FBYztnQkFDZixJQUFJLENBQUMsYUFBYSxDQUFDLFFBQVEsQ0FBQyxXQUFXLEVBQUUsZ0RBQWdELENBQUMsQ0FBQztnQkFDM0YsTUFBTTtTQUNiO0lBQ0wsQ0FBQztJQUVPLFdBQVc7UUFDZixJQUFJLE9BQU8sSUFBSSxDQUFDLE1BQU0sS0FBSyxXQUFXLEVBQUU7WUFDcEMsUUFBUSxJQUFJLENBQUMsTUFBTSxDQUFDLElBQUksRUFBRTtnQkFDdEIsS0FBSyxTQUFTLENBQUM7Z0JBQ2YsS0FBSyxlQUFlO29CQUNoQixJQUFJLE9BQU8sSUFBSSxDQUFDLElBQUksS0FBSyxXQUFXLElBQUksTUFBTSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUMsTUFBTSxLQUFLLENBQUMsRUFBRTt3QkFDekUsSUFBSSxXQUFXLEdBQTRCLElBQUksQ0FBQyxTQUFTLENBQUMsZUFBZSxDQUFDLElBQUksQ0FBQyxJQUFJLEVBQUUsSUFBSSxDQUFDLE1BQU0sRUFBRSxJQUFJLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxDQUFDO3dCQUVwSCxJQUFJLENBQUMsYUFBYSxHQUFHLFdBQVcsQ0FBQyxhQUFhLENBQUM7d0JBQy9DLElBQUksQ0FBQyxlQUFlLEdBQUcsV0FBVyxDQUFDLGNBQWMsQ0FBQzt3QkFDbEQsSUFBSSxDQUFDLGVBQWUsR0FBRyxJQUFJLENBQUM7cUJBQy9CO29CQUNELE1BQU07Z0JBQ1Y7b0JBQ0ksSUFBSSxXQUFXLEdBQWU7d0JBQzFCLFdBQVcsRUFBRSxRQUFRO3dCQUNyQixLQUFLLEVBQUUsSUFBSSxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsS0FBSztxQkFDbEMsQ0FBQztvQkFDRixJQUFJLFVBQVUsR0FBVyxJQUFJLENBQUMsU0FBUyxDQUFDLE9BQU8sQ0FBQyxXQUFXLENBQUMsQ0FBQztvQkFDN0QsSUFBSSxDQUFDLE9BQU8sR0FBRyxDQUFDLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxRQUFRLEVBQUUsRUFBRSxJQUFJLEVBQUUsVUFBVSxFQUFFLENBQUMsQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDO29CQUNoRixJQUFJLENBQUMsZUFBZSxHQUFHLElBQUksQ0FBQztvQkFDNUIsSUFBSSxJQUFJLENBQUMsTUFBTSxDQUFDLGNBQWMsQ0FBQyxTQUFTLENBQUMsRUFBRTt3QkFDdkMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxPQUFPLENBQUMsQ0FBQztxQkFDL0M7b0JBRUQsSUFBSSxJQUFJLENBQUMsTUFBTSxDQUFDLGNBQWMsQ0FBQyxRQUFRLENBQUMsRUFBRTt3QkFDdEMsSUFBSSxDQUFDLGFBQWEsR0FBRyxDQUFDO2dDQUNsQixJQUFJLEVBQUUsVUFBVSxDQUFDLFVBQVUsRUFBRTtnQ0FDN0IsS0FBSyxFQUFFLElBQUksQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLEtBQUs7Z0NBQy9CLEVBQUUsRUFBRSxJQUFJLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxjQUFjLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsbUJBQW1COzZCQUM1RixDQUFDLENBQUM7cUJBQ047b0JBQ0QsTUFBTTthQUNiO1NBRUo7UUFFRCxJQUFJLENBQUMsa0JBQWtCLEVBQUUsQ0FBQztJQUM5QixDQUFDO0lBRU8sa0JBQWtCO1FBQ3RCLElBQUksSUFBSSxDQUFDLGVBQWUsSUFBSSxJQUFJLENBQUMsY0FBYyxFQUFFO1lBQzdDLElBQUksQ0FBQyxjQUFjLEdBQUcsS0FBSyxDQUFDO1NBQy9CO0lBQ0wsQ0FBQztJQUVPLHNCQUFzQjtRQUMxQixLQUFLLElBQUksWUFBWSxJQUFJLElBQUksQ0FBQyxlQUFlLEVBQUU7WUFDM0MsSUFBSSxJQUFJLENBQUMsZUFBZSxDQUFDLFlBQVksQ0FBQztnQkFBRSxJQUFJLENBQUMsTUFBTSxDQUFDLFdBQVcsQ0FBQyxJQUFJLENBQUMsZUFBZSxDQUFDLFlBQVksQ0FBQyxDQUFDLENBQUM7U0FDdkc7UUFFRCxJQUFJLENBQUMsYUFBYSxHQUFHLEVBQUUsQ0FBQztJQUM1QixDQUFDO0lBRU8saUJBQWlCO1FBQ3JCLElBQUksQ0FBQyxTQUFTLEdBQUcsSUFBSSxDQUFDLFNBQVMsQ0FBQyxnQkFBZ0IsRUFBRSxDQUFDO1FBQ25ELElBQUksQ0FBQyxRQUFRLENBQUMsZUFBZSxDQUFDLElBQUksQ0FBQyxTQUFTLEVBQUUsSUFBSSxDQUFDLE1BQU0sRUFBRSxLQUFLLENBQUMsQ0FBQztRQUVsRSxJQUFJLENBQUMsU0FBUyxDQUFDLE1BQU0sQ0FBQyxPQUFPLEdBQUcsSUFBSSxDQUFDLFdBQVcsQ0FBQyxRQUFRLEVBQUUsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDO1FBQ3RFLElBQUksSUFBSSxDQUFDLFNBQVMsQ0FBQyxNQUFNO1lBQUUsSUFBSSxDQUFDLFNBQVMsQ0FBQyxNQUFNLENBQUMsT0FBTyxHQUFHLElBQUksQ0FBQyxXQUFXLENBQUMsUUFBUSxFQUFFLENBQUMsYUFBYSxFQUFFLFVBQVUsQ0FBQyxDQUFDLENBQUM7UUFFbkgsSUFBSSxDQUFDLGNBQWMsRUFBRSxDQUFDO0lBQzFCLENBQUM7SUFFTyxXQUFXLENBQUMsT0FBZSxFQUFFLFNBQXdCO1FBQ3pELElBQUksSUFBSSxDQUFDLFNBQVMsQ0FBQyxPQUFPLENBQUMsSUFBSSxPQUFPLElBQUksQ0FBQyxTQUFTLENBQUMsT0FBTyxDQUFDLENBQUMsT0FBTyxLQUFLLFdBQVcsRUFBRTtZQUNuRixPQUFPLElBQUksQ0FBQyxTQUFTLENBQUMsT0FBTyxDQUFDLENBQUMsT0FBTyxDQUFDO1NBQzFDO1FBRUQsS0FBSyxJQUFJLENBQUMsR0FBVyxTQUFTLENBQUMsTUFBTSxHQUFHLENBQUMsRUFBRSxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFO1lBQ3BELElBQUksSUFBSSxDQUFDLFNBQVMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxJQUFJLENBQUMsU0FBUyxDQUFDLE9BQU8sQ0FBQyxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksS0FBSyxFQUFFLEVBQUU7Z0JBQzVGLE9BQU8sSUFBSSxDQUFDO2FBQ2Y7U0FDSjtRQUVELElBQUksT0FBTyxLQUFLLFFBQVEsSUFBSSxJQUFJLENBQUMsYUFBYSxDQUFDLE1BQU0sS0FBSyxDQUFDLEVBQUU7WUFDekQsT0FBTyxLQUFLLENBQUM7U0FDaEI7UUFFRCxPQUFPLEtBQUssQ0FBQTtJQUNoQixDQUFDO0lBRUQsb0ZBQW9GO0lBQzVFLGNBQWM7UUFFbEIsb0RBQW9EO1FBQ3BELElBQUksQ0FBQyxTQUFTLEdBQUcsRUFBRSxDQUFDO1FBRXBCLElBQUksT0FBTyxJQUFJLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxLQUFLLEtBQUssV0FBVyxJQUFJLElBQUksQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLEtBQUssRUFBRTtZQUM3RSxJQUFJLENBQUMsU0FBUyxJQUFJLGVBQWUsQ0FBQztTQUNyQztRQUVELElBQUksT0FBTyxJQUFJLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxhQUFhLEtBQUssV0FBVyxFQUFFO1lBQ3pELElBQUksQ0FBQyxTQUFTLElBQUksSUFBSSxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsYUFBYSxHQUFHLEdBQUcsQ0FBQztTQUM1RDtRQUVELElBQUksT0FBTyxJQUFJLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxLQUFLLEtBQUssV0FBVyxFQUFFO1lBQ2pELElBQUksQ0FBQyxTQUFTLElBQUksSUFBSSxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDO1NBQzlDO0lBQ0wsQ0FBQzs7O1lBMWJKLFNBQVMsU0FBQztnQkFDUCxRQUFRLEVBQUUsUUFBUTtnQkFDbEIsK2pIQUFvQztnQkFDcEM7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7b0JBK0JJO2dCQUNKLGFBQWEsRUFBRSxpQkFBaUIsQ0FBQyxJQUFJO2dCQUNyQyxJQUFJLEVBQUU7b0JBQ0YsT0FBTyxFQUFFLFNBQVM7b0JBQ2xCLDBCQUEwQixFQUFFLHlDQUF5QztvQkFDckUscUJBQXFCLEVBQUUsb0NBQW9DO2lCQUM5RDtnQkFDRCxTQUFTLEVBQUUsQ0FBQyxZQUFZLEVBQUUsUUFBUSxFQUFFLFNBQVMsQ0FBQzthQUNqRDs7O1lBcEVHLFVBQVU7WUFhTCxlQUFlO1lBQ2YsWUFBWTtZQUNaLFFBQVE7WUFWYixpQkFBaUI7WUFtQlosU0FBUzs7O3VCQThFYixLQUFLO3FCQUNMLEtBQUs7bUJBQ0wsS0FBSztrQkFDTCxLQUFLO29CQUVMLFNBQVMsU0FBQyxPQUFPO3lCQUNqQixXQUFXLFNBQUMsYUFBYSIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7XHJcbiAgICBDb21wb25lbnQsXHJcbiAgICBWaWV3RW5jYXBzdWxhdGlvbixcclxuICAgIElucHV0LFxyXG4gICAgT25Jbml0LFxyXG4gICAgT25DaGFuZ2VzLFxyXG4gICAgU2ltcGxlQ2hhbmdlcyxcclxuICAgIE9uRGVzdHJveSxcclxuICAgIEVsZW1lbnRSZWYsXHJcbiAgICBBZnRlclZpZXdJbml0LFxyXG4gICAgVmlld0NoaWxkLFxyXG4gICAgSG9zdExpc3RlbmVyLFxyXG4gICAgSG9zdEJpbmRpbmcsXHJcbiAgICBDaGFuZ2VEZXRlY3RvclJlZlxyXG59IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xyXG4vLyBpbXBvcnQgeyBTdWJzY3JpcHRpb24gfSBmcm9tICdyeGpzL1N1YnNjcmlwdGlvbic7XHJcbmltcG9ydCB7IHRpbWVyIH0gZnJvbSAncnhqcyc7XHJcbi8vIGltcG9ydCB7IGRlYm91bmNlVGltZSB9IGZyb20gJ3J4anMvb3BlcmF0b3JzJztcclxuaW1wb3J0ICogYXMgTCBmcm9tICdsZWFmbGV0JztcclxuaW1wb3J0ICdsZWFmbGV0Lm1hcmtlcmNsdXN0ZXInO1xyXG5pbXBvcnQgJ2xlYWZsZXQuYXdlc29tZS1tYXJrZXJzL2Rpc3QvbGVhZmxldC5hd2Vzb21lLW1hcmtlcnMnO1xyXG5pbXBvcnQgeyBLZFNwbGl0dGVyRXZlbnQgfSBmcm9tICcuLi9rZC1hbmd1bGFyLXNwbGl0dGVyL2luZGV4JztcclxuaW1wb3J0IHsgS2REb21FbGVtU3ZjIH0gZnJvbSAnLi4va2QtY29tbW9uL2luZGV4JztcclxuaW1wb3J0IHsgS2RNYXBTdmMsIElNYXBQb3B1bGF0ZUNsdXN0ZXJEYXRhIH0gZnJvbSAnLi9rZC1hbmd1bGFyLW1hcC1zdmMnO1xyXG5pbXBvcnQge1xyXG4gICAgSU1hcENvbmZpZyxcclxuICAgIElNYXBQb3NpdGlvbixcclxuICAgIElNYXBDbHVzdGVyRGF0YSxcclxuICAgIElNYXBab29tQ29uZmlnLFxyXG4gICAgSU1hcEFwaSxcclxuICAgIElNYXBNYXJrZXIsXHJcbn0gZnJvbSAnLi9rZC1hbmd1bGFyLW1hcC1pbnRlcmZhY2UnO1xyXG5pbXBvcnQgeyBLZERhdGFTdmMgfSBmcm9tICcuLi9rZC1jb21tb24vaW5kZXgnO1xyXG5cclxuQENvbXBvbmVudCh7XHJcbiAgICBzZWxlY3RvcjogJ2tkLW1hcCcsXHJcbiAgICB0ZW1wbGF0ZVVybDogJy4va2QtYW5ndWxhci1tYXAuaHRtbCcsXHJcbiAgICAvKnRlbXBsYXRlOiBgXHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJoZWFkZXItY29udGFpbmVyXCI+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwiY2hhcnQtdGl0bGUgbGVmdFwiPnt7Y29uZmlnLmxlZ2VuZC50aXRsZS50ZXh0fX08L2Rpdj5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJjaGFydC1zdWJ0aXRsZSByaWdodFwiPnt7Y29uZmlnLmxlZ2VuZC50aXRsZS50ZXh0fX08L2Rpdj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDxkaXYgKm5nSWY9XCJpc01hcFNob3duXCIgY2xhc3M9XCJjaGFydC1jb250YWluZXJcIiAgI215TWFwPlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cImxpbmstd3JhcHBlclwiICpuZ0lmPVwiaXNMaW5rVG9Hb29nbGVcIj5cclxuICAgICAgICAgICAgICAgICAgICA8YSBbYXR0ci5ocmVmXT1cImdvb2dsZUxpbmtcIiB0YXJnZXQ9XCJfYmxhbmtcIiBjbGFzcz1cImdvb2dsZS1saW5rIGxlYWZsZXQtYmFyIGxlYWZsZXQtY29udHJvbFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8aW1nIGNsYXNzPVwiZ29vZ2xlLWltYWdlXCIgW3NyY109XCJnb29nbGVJbWFnZVwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvYT5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPGRpdiBjbGFzcz1cImxlZ2VuZC1jb250YWluZXIgY2VudGVyXCIgKm5nSWY9XCJjb25maWcubGVnZW5kICYmIGlzTWFwU2hvd25cIj5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJsZWdlbmRzXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cImxlZ2VuZC10aXRsZS1jb250YWluZXIgcmlnaHRcIiAqbmdJZj1cImNvbmZpZy5sZWdlbmQudGl0bGUudGV4dFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwidGl0bGVcIj57e2NvbmZpZy5sZWdlbmQudGl0bGUudGV4dH19PC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cImxlZ2VuZFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwibGVnZW5kLWl0ZW1cIiBpZD1cImtkbGkte3tsZWdlbmRJdGVtLmlkfX1cIiAqbmdGb3I9XCJsZXQgbGVnZW5kSXRlbSBvZiBtYXJrZXJzTGVnZW5kXCIgKGNsaWNrKT1cIm9uTGVnZW5kQ2xpY2sobGVnZW5kSXRlbSlcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJsZWdlbmQtbWFya2VyXCIgW2lubmVySFRNTF09XCJsZWdlbmRJdGVtLmljb24ub3V0ZXJIVE1MXCIgPjwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cImxlZ2VuZC1sYWJlbFwiPjxkaXYgY2xhc3M9XCJsYWJlbC10ZXh0XCI+e3tsZWdlbmRJdGVtLmxhYmVsfX08L2Rpdj48L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDxkaXYgKm5nSWY9XCIhaXNNYXBTaG93blwiIGNsYXNzPVwiZXJyb3ItbWFwXCI+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwiZXJyb3ItaWNvblwiPjxpIGNsYXNzPVwiZmEgZmEtbWFwLW9cIj48L2k+PC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwiZXJyb3ItbWVzc2FnZVwiPnt7ZXJyb3JNZXNzYWdlfX08L2Rpdj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDxrZC1wcm9ncmVzc2xvYWRlciAqbmdJZj1cImlzTGF5ZXJMb2FkaW5nICYmIGlzTWFwU2hvd25cIiBjb25maWd0eXBlPVwic21hbGwtc3Bpbm5lclwiIFtjb25maWd2YWx1ZV09XCJzbWFsbExvYWRlclZhbHVlXCI+PC9rZC1wcm9ncmVzc2xvYWRlcj5cclxuXHJcbiAgICBgLCovXHJcbiAgICBlbmNhcHN1bGF0aW9uOiBWaWV3RW5jYXBzdWxhdGlvbi5Ob25lLFxyXG4gICAgaG9zdDoge1xyXG4gICAgICAgICdjbGFzcyc6ICdrZHgtbWFwJyxcclxuICAgICAgICAnW3N0eWxlLmJhY2tncm91bmQtY29sb3JdJzogJ21hcENvbmZpZy5tYXBBcmVhLnN0eWxlLmJhY2tncm91bmRDb2xvcicsXHJcbiAgICAgICAgJ1tzdHlsZS5mb250LWZhbWlseV0nOiAnbWFwQ29uZmlnLm1hcEFyZWEuc3R5bGUuZm9udEZhbWlseSdcclxuICAgIH0sXHJcbiAgICBwcm92aWRlcnM6IFtLZERvbUVsZW1TdmMsIEtkTWFwU3ZjLCBLZERhdGFTdmNdXHJcbn0pXHJcblxyXG5leHBvcnQgY2xhc3MgS2RNYXAgaW1wbGVtZW50cyBPbkluaXQsIE9uQ2hhbmdlcywgQWZ0ZXJWaWV3SW5pdCwgT25EZXN0cm95IHtcclxuXHJcbiAgICAvLyBwcml2YXRlIHN0YXRpYyBtYXBQaW5JbWFnZTogc3RyaW5nID0gJ2RhdGE6aW1hZ2UvcG5nO2Jhc2U2NCxpVkJPUncwS0dnb0FBQUFOU1VoRVVnQUFBQmtBQUFBcENBWUFBQURBazRMT0FBQUZnVWxFUVZSNEFhMVhBNUJqV1JUTjJvVzE3ZDNZYVp0cjI5NjJIVXpiRE5wanN6VzI0bVJ0MjhwNDd2N3pxL2JYWnRycC9sV25YcjMzN2ozblBDZTg1TmN5cGdTRmR1Z0NwVzVZb0RBTVJhSU1xUmk2YUtxNUUzWXFEUU8zcUF3alZXckQ4TmNxL1JCcHlrZDhvWlViL2thSnV0b3c4cjFhUDlJSTBXbUxLTElzSnl2MXcva3F3OUNoMk1ZZEIrKzEyT254ZWUvUU13dmY0L0RrL0xmcC9pNG54VFh0T29RNHBXNUFqN3dwaWNpMUE5ZXJkQU4yT0g2NHg4T1NQOWozRnQzYjdhV2tUZy9GbTkxc2lUcmEwZjlvbjVzUXI5SU5lakg2Q1VVVXBhdmpGTnExQitPYWRoeG1uZmE4UmZFbU44Vk5Bc1FoUHFGNTV4SGtNenozalNtQ2hXVTZmNy9YWktOSCs5K2hCTE9IWW96dUtRUHh5TVBVS2tyWC9LMHVXbmZGYUpHUzFRUFJ0WnNPUHRyM05zVzB1eWg2Tk5DT2tVM1l6K2JYYlQzSThHM3hFNUVYTFh0Q1hiYnF3Q085elBRWVBSVFo1dklEWEQ3VSt3N3JGREVvVVVmN2liSElSNHk2YkxWUFhyejhKVlpFcWwxM3RyeHd1ZS91RGl2ZDNma1dSYlM2L0lBMmJJRDR1azBVcEYxTjhxTGxiQmxYczRFZTdITFRmVjFqNTRBUHZPRG5TZk9XQnF0S1Z2amdMS3pGNVlkRWs1ZXdSa0dsSzBpMzNFb2ZmZmM3SFQ1NmpENy82VStxSDNDeDdTQkxObnRINVlJUHZPRG55ZklYWllSVkRQcWdIdExzNUFCSEQzWXpMdWVzcGI3dDc5RlkzNERqTXdyVnJjVHV3bFQ1NVlNUHZPQm5Scko0VlhUZE5uWXVnNXVjSExCakVwdDMwNzAxQTNUcytIRWE3M3U2ZFQzRk5Xd2ZsWTg2ZU1IUGsrWXUraTZwelVwUnJXN1NORGc1SkhSNEthcG1NNVd2MkU4VGZjYjFIb3FxSE1IVSt1V0REN3pnNTRtejUvMkJTbml6aTlUMURnNFFRWExUb0dOQ2tiNnRiMU5VK1FBbEdyMSsrZUFEcnpobi91OFEyWVpoUVZsWjUrQ0FPdHFmYmhtYVVDUzFlek5GVm0yaW1EYlBtUG5nNXdteitnd2grb0hEY2UwZVV0UTZPR0RJeVIwdVVoVXNvTzN2ZkRtbWdPZXpIMG1aTjU5eDdNQmkrK1dETDFnL2VFaVUzYXZsaWRPNjcxYmtMZndidzVYVjJQOFB6bzB5ZHk0dDIvMGV1MzN4WVNPTU9EOGhUZjRDckJ0R01Tb1hmUExjaFgrSjBydVNlUHczTFplSzBqdVBKYll6cmhrSDBpbzdCM2sxNjRoaUd2YXdoT0tNTGtyUUx5VnBaZzhySEZXN0UydUhPTDg4OElCUGxOWjFGUHpzdFNKTTY5NGZXcjZSd3B2Y0pLNjArMEhDSUxUQnpaTEZOZHRBekphb2h6ZTYwVDhxQnp5aDVadU9nNWU3dXdRcHBvZkVtZjIrK0RZdm15U3FHQnVLYWljRjFibFFqaHVIZHZDSU12cDh3aFRUZlp6STdSbGRwd3RTekwrRjErd2tkWjJUQk9XMmdJRjg4UEJUekQvZ3BlUkVBTUVieG5KY2FKSE5IcnB6amkwZ1FDUzZoZGtFZVl0OURGLzJxUGNFQzhSTTI4SHdtcjNzZE55aHQwMGJ5QXV0MmszZ3VmV050Z3RPRU9GR1V3Y1hXTkRiZE5icGdCR3hFdktrT1FzeGl2SngzM2lvdzBWdzVTNlNWVHJwVnExMXlzQTJScDdnVGZQZmt0YzZ6aHRYQkJDK2FkUkxzaGY2c0cyUmZIUFo1RUFjNHNWWjgzeUNOMDBGay80a2dndTQwWlR2SUVtNWcyNHF0VTRLakJyeC9CVFRIOGlmVkFTQUc3Z0tybld4SkRjVTd4OFg2RWNjemhtM282WWljdnNMWFdmaDNDaDFXMGs4eDBuWEYrMGZGeGd0NHBoejhRdnlwaXdDQ0ZLTXFYQ25xWEV4anExMGJlSCtVVUE3K25HNm1kRy9QdTBmM0xnRmNHcmwyczBrTk5qcG1vSjlvNEIyOUNNTzhkTVQ0UTVveDh1aXRGNmZxc3JKT3I4cW53TmJSenY2aFNuRzV3UCs2NEM3aDlscDMwaEtOdEtkV2p0ZGtidVBBMTluSjdUejN6Ui9pYmdBUmJoYjRBbGhhdmNCZWJtVEhjRmwyZnZZRW5XMG94OXhNeEtCUzhidEorS2lFYnE5ekE0UnRoUVhEaFBhMFQ5VEVlNjlnV3Vwd2M2dUJVcGhxdVhnZisvRnJJandlSFFTNC9wZHVNZTVFUlVNSFVkOXh2OFpSOThDeGtTNEYybjNFVXJVWjEwRVlOdzdCV205eDFHaVBzc2kzR2dpR1JES1dSWVpmWGxPTitkZk5iTStHZ0l3WWR3QUFBQUFTVVZPUks1Q1lJST0nO1xyXG4gICAgLy8gcHJpdmF0ZSBzdGF0aWMgbWFwUGluU2hhZG93SW1hZ2U6IHN0cmluZyA9ICdkYXRhOmltYWdlL3BuZztiYXNlNjQsaVZCT1J3MEtHZ29BQUFBTlNVaEVVZ0FBQUNrQUFBQXBDQVFBQUFBQ2FjaDlBQUFDTVVsRVFWUjRBZTNTaFk3alFCQUUwQW96L2Y5L0hUTXpoZzF6cmRLVXJKYmR4K0tkMm5EOFZOdWRmc0wvVGgvLy9keVFOMlRINmYzeS9CR3BDMzc5clYrUytxcWV0Qk94SW1OUVhMOEpDQXIyVjRpTVFYSEdOSnhlQ2ZaWGhTUkJjUU1mdmtPV1VkdGZ6bExnQUVObVpEY21vMlRWbXQ4T1NNMmVYeEJwM0RqSFNNRnV0cVM3U2JtZW16QmlSK3hwS0NOVUlSa2Rra1l4aEFreUdvQnZ5UUZFSkVlZndTbW12QmZKdUo2YUtxS1duQWt2R1pPYVpYVFVnRnFZVUxXTlNIVWNrWnVSMUhJSWltVUV4dXRSeHd6T0xST0lHNHZLbUNLUXQzNjRtSWxoU3l6QWYxbTlsSFpISlpybEFPTU16dFJSaUtpbXAvcnBkSkRjOUF3cnk1eFRaQ3RlN0ZIdHVTOHdKZ2VZR3JleDI4eE5UZDA4NkRpazd2VU1zY1FPYTh5NERvR3RDQ1NrQUtsTndwZ050cGhqckM2TUlIVWtSNllXeHhzNlNjNXhxbjIyMm1tQ1JGekl0OGxFZEt4K2lrQ3RnOTFxUzJXcHdWZkJlbEpDaVFKd3Z6aXhmSTljeFpRV2dpU0plbEtud0JFbEtZdERPYjJNRmJobVVpZ2JSZVFCVjBDZzQrcU1YU3hYU3lHVW40VWJGOGwrN3FkU0duVEMwWExDbWFoSWdVSExoTE9ocFZDdHc0Q3pZWHZMUVdRYkpObXhvQ3NPS0F4U2dCSm5vNzVhdm9sa1J3OGlJQUZjc2RjMDJlOWl5Q2Q4dEh3bWVTU29LVG93SWd2c2NTR1pVT0E3UHVDTjViMkJYOW1RTTdTMHdZaE1OVTc0emdzUEJqM0hVN3dndUFmbnh4akZRR0JFNnB3TitHak1FOXpIWTd6R3A4d1Z4TVNoWVg5Tlh2RVdEM0hid0pmNGdpTzRDRklReFhTY0gxL1RNKzA0a2tCaUFBQUFBRWxGVGtTdVFtQ0MnO1xyXG5cclxuICAgIHB1YmxpYyBzbWFsbExvYWRlclZhbHVlOiBhbnkgPSBudWxsO1xyXG4gICAgcHVibGljIGlzTWFwU2hvd246IGJvb2xlYW4gPSB0cnVlO1xyXG4gICAgcHVibGljIGlzTGF5ZXJMb2FkaW5nOiBib29sZWFuID0gdHJ1ZTtcclxuICAgIHB1YmxpYyBpc0xpbmtUb0dvb2dsZTogYm9vbGVhbiA9IGZhbHNlO1xyXG4gICAgcHVibGljIGdvb2dsZUxpbms6IHN0cmluZyA9ICcnO1xyXG4gICAgcHVibGljIGVycm9yTWVzc2FnZTogc3RyaW5nID0gJyc7XHJcbiAgICBwdWJsaWMgZ29vZ2xlSW1hZ2U6IHN0cmluZyA9ICdkYXRhOmltYWdlL3BuZztiYXNlNjQsaVZCT1J3MEtHZ29BQUFBTlNVaEVVZ0FBQURJQUFBQXlDQVlBQUFBZVA0aXhBQUFBQkhOQ1NWUUlDQWdJZkFoa2lBQUFBQWx3U0ZsekFBQU9hd0FBRG1zQlZQNE5CZ0FBQUJsMFJWaDBVMjltZEhkaGNtVUFkM2QzTG1sdWEzTmpZWEJsTG05eVo1dnVQQm9BQUFhdFNVUkJWR2lCN1psYmJCelZHY2QvWjJabjdMMzRIbXl5dTk3Y0hJZkVqZE5ZTVhVd1JMYVNVdEpDMVlvUXF3MXRLVklweVVQVmNsRkxMeXFSMHp4VWxZSlVLWUlJcVEvbGhWRG9SUzJOaWlFdUlJcEowbHhNR3lBYkFvbnRwTlNYMlBGNnZiYzVmWERIOFdWbWR0WmVLNjNrLzlQWjc1enpuZSszMzVsdnpwNkZSZjF2U2R6b0FBQzZ0elJXZTRUNEVzaHRRRFZRQWd3RGw2U1VmOUVVOWZlck83dDZuSHpjVUpEM21qY0c4WGoyU25nQThEZ01UUUcva29ieDVMbzNUbHkyR25ERFFQN1IycmhWTVRnTWxPY3diVUJJc2ZPVzE5OTViV2JIRFFGNXIzVlRzelRFcTBEQkhLYVBTNkcwcnV2c2VudXEwUkVrK014OUVVVW9qd2xva0ZJVXptSFJXYXFLcGJTRFIzcldGU2NNcDYyVVRWY013Y2E2em1OWFRJT3RzK0F6OTBVVWxGTkl5aVFBY2g3clh0Zlh1NGNvVGhqemRYT3pLbWtIdm1VYWJFRVV4S05BMlV6N0VtOHhYMXgxRyt1WHJFUlZGTTROOWZMbkMxMUVyL1psWGIweWxtYnJoV3VPWXlRd2xqSHdxWXJqZHBId2pYTXRuOWxyVmpPSDlJcTZtWlo3VjkvQnZ0c2ZKS0I1cDlrZjI3U1RYNTc4TGI4NGZ0Z3h5QzBYWTZnMmlaWEF1N0U0WjY2Tms1QUdCWXFnUHVDbHpsZUlJaXlSdEJTWkhjQlRBSW85QitwTWlBT3Rld2hvWHVMcEJIL3IreWV2WGp4SmYzeUVqTXh3K3QvbkhTRUFOdjRyYnR0M2VqVE9zWkV4RW5KaTJ5VU15YkdSTWM3RTdPY0lLYmFhYlZjUFhFbUJuL2JtYnlJUW5Qd2t5dTZPcCtnZDdRZkFyeFZTVXhweUJWSVpTMXZheld4WXFYdDBuUHFBeitZYmx4R3paWitSS2ZyQ2lpYUtkQjlqNlFRUGR4eVloQUNJcGNaZFFRQVVwYXdmOHJoaGtEU3M5MXhLU3VJWnUrSWdLc3lXcTR5c3ExZ0d3S2xQb3ZTTkRremFUOXovTkpXKzBtbGpENTM1SSsxdlAyZnBaMHdWVkZqWXZZcUNyZ2hMR0UwSXZLcE5QcEFqWnR0VlJzeUhMV05rTDV1YVl2L2RmRnlxVzlvRjhPbUExN0t2b2NodVc0RkF2R3UyWFdVa2VyVVhnQTJWS3lrcDhET2NpQUZ3Lzh2NzhTZ2VkTlhEYzl1ZklLQjc2Wm15N1dhcU0rTG45a3N4eTc0NnZ4Zkp4RU9mTkNTNkl0Z1E4TExXWi8veUYwSk9sa2xYR2ZuVGgxM0Uwd21LZFQ4SFd2Wk1sdCt6Z3hmcDd2K1F1NVkzRXRDOVNDU2RsMDdaK25rekVxRGZxMXIyQ1dDOTM4dXVxbkxhS3N2WVZWWE9lci9YcnZRQzlGd204RHZ6ZzdWWG9QaWVUejBBTEllSkJ6cWVUdEpTdllGVnBVRjIxRzVoVFhtWXBtQWRqemZ1NU82VlRRRDhJZm9Xdno3YllRc2lCZmcxMk5EclVGSUJYUkZaRDRGU3loL2UrdGUzdXN6UHJzODd6M2EvVEpIdTQ3c045M0t6djV5Mk5hM1QranN2bmVZSGJ6N3I2S05Lei9CZ1d4SjlXQ0gyL3J5T0thK3NmZjM0d2FtR25BNXVCMDc4aGlNWDNxSHRsbFpxeThLa01tbjZZZ01jdVhDTU4zclBZRWo3ODFpVm51SDUrZ0ZXK2RJa3Y2cngwZjRrUm1KTzU3ZHJoc2pzRVRNT2Y3WVpEQjlxTzRxa1pTNHJ6ZFJVaU1sby9wNmg5MUFxZDJlSzNMSDI2UEVYWjVubkZhRUxWVnBBQUJRMXFQZzNsK1RrYTZpaFBta0ZBUXNNVXFsbk9Hd0JBUkF6SWd4OCtRbU1wVUZYdm94Z2tKNTc3aDZ6NjE4d2tHd1FINHcvUkZvTmtHamJCVXFXTUZTVjhiYXZZWGhzaSt6Q2dEaEN5R1Y4TVA0UUdUbnhnek5Udll4VXk5Wlo0NllxMmJvTkkxenRPQ2J2SUU0UUdYME44WXA5b1BpbjJST2YzWTVSYm5VS0E2TmlDYWx0ZDJWZE42OGcyU0JHeS9iaTBVc0loNnBSMVNuYlJOZEozYm5kMG1meWM1OUhhbHJXdGZNRzRnWkNDaDhBbXFZVFhCcWFCcE5xYU1Rb21WN0ZqSkpTMGhzM3VWby9MeUJPRU84UHJ1RjA4anFFcVlLQ1FzS2h5SFVZVlNYZDFEeHRUR3B6Yy9aQzhGL05HOFFKNG14L0xkL3JhT2ZITHdRNGQyWDJYRTNUcHNHa0dwdkFQQ1FxQ3VsYmIzTWR4N3hBc2tFOCt0bytZa2tmc1FUODlBVWxLNHdzSzhjSWhRRXd3aEZraWZzWDVweEIzRUtZY2d1VHJxa0ZJRk96T3FkNDVnU1NLNFFwTnpDc1dBbE12Rjl5VWM0Z2M0VXdsUTJtYXRObVlHSnI1YUtjUU9ZTFljb0pwaUFVcHZoSGV4RTMzWlJMYU81QjhnVmh5Z25HMTdoNTlrc3ppMXlCNUJ2Q2xQTTIwd25sQUpNVlpLRWdURG5CNkRuQU9JTFkvU2lDL0VDWXlnZU1MVWgxWVVaL3ZuNkFtZ1dHTUpVTlpta3dSSUZIdDQzWHR1UG5OVmRyckNDaVF5djQvdEVuOHdwaEtwYUE5cGNVUHJhNDR5dlVDd2xYaFd6dkdHeEI0b2FZOWU5cGRHZzVqM1Q4ak9GRThWeGp6YXJoTWZqSllXdVludkhCcU4wOFc1Qm8zUFB3U0VaTVhybWN2eHJoa1k3OUN3cGh5b1Q1cVAvNjNkZElja3hHQi90MjI4MXh2TkE3K01yMnBscGYrbWs5VmJWcWY5ZnUxTkI0SUQ5L0pMcFVtVThWMzdsVDB4S2V5K2VqZzVlLy9mZ2RYK25LUG10UmkxclVvdjRmOUIrSUJNblZJSlYybkFBQUFBQkpSVTVFcmtKZ2dnPT0nO1xyXG5cclxuICAgIHB1YmxpYyBtYXJrZXJzTGVnZW5kOiBBcnJheTxhbnk+ID0gW107XHJcblxyXG4gICAgcHVibGljIGh0bWxDbGFzczogc3RyaW5nID0gJyc7XHJcblxyXG4gICAgcHVibGljIG1hcENvbmZpZzogSU1hcENvbmZpZztcclxuXHJcbiAgICBwcml2YXRlIF9teU1hcDogTC5NYXA7XHJcbiAgICBwcml2YXRlIF9tYXJrZXI6IEwuTWFya2VyO1xyXG4gICAgcHJpdmF0ZSBfbGF5ZXI6IEwuVGlsZWxheWVyO1xyXG5cclxuICAgIHByaXZhdGUgX2NsdXN0ZXJNYXJrZXJzOiB7IFtrZXk6IHN0cmluZ106IEwuTWFya2VyQ2x1c3Rlckdyb3VwIH0gPSB7fTtcclxuXHJcbiAgICBwcml2YXRlIF9pc0xheWVyRXJyb3I6IGJvb2xlYW4gPSBmYWxzZTtcclxuICAgIHByaXZhdGUgX2lzTWFya2VyTG9hZGVkOiBib29sZWFuID0gZmFsc2U7XHJcbiAgICBwcml2YXRlIF9pc1RpbGVzTG9hZGVkOiBib29sZWFuID0gZmFsc2U7XHJcbiAgICBwcml2YXRlIF9sYXllclJlbG9hZFRpbWVzOiBudW1iZXIgPSAwO1xyXG4gICAgcHJpdmF0ZSBfdGlsZWxvYWRJbmRleDogbnVtYmVyID0gMDtcclxuXHJcblxyXG4gICAgQElucHV0KCkgcG9zaXRpb246IElNYXBQb3NpdGlvbjtcclxuICAgIEBJbnB1dCgpIGNvbmZpZzogSU1hcENvbmZpZztcclxuICAgIEBJbnB1dCgpIGRhdGE6IElNYXBDbHVzdGVyRGF0YTtcclxuICAgIEBJbnB1dCgpIGFwaTogSU1hcEFwaTtcclxuXHJcbiAgICBAVmlld0NoaWxkKCdteU1hcCcpIG15TWFwOiBFbGVtZW50UmVmO1xyXG4gICAgQEhvc3RCaW5kaW5nKCdjbGFzcy5lcnJvcicpIGlzTWFwRXJyb3I6IGJvb2xlYW47XHJcblxyXG4gICAgY29uc3RydWN0b3IoXHJcbiAgICAgICAgcHJpdmF0ZSBfZWxlbWVudFJlZjogRWxlbWVudFJlZixcclxuICAgICAgICBfa2RTcGxpdHRlckV2ZW50OiBLZFNwbGl0dGVyRXZlbnQsXHJcbiAgICAgICAgcHJpdmF0ZSBfa2REb21FbGVtU3ZjOiBLZERvbUVsZW1TdmMsXHJcbiAgICAgICAgcHJpdmF0ZSBfa2RNYXBTdmM6IEtkTWFwU3ZjLFxyXG4gICAgICAgIHByaXZhdGUgX2NkOiBDaGFuZ2VEZXRlY3RvclJlZixcclxuICAgICAgICBwcml2YXRlIF9kYXRhU3ZjOiBLZERhdGFTdmNcclxuICAgICkgeyB9XHJcblxyXG4gICAgbmdPbkluaXQoKTogdm9pZCB7XHJcbiAgICAgICAgd2luZG93LmFkZEV2ZW50TGlzdGVuZXIoJ3Jlc2l6ZScsIHRoaXMuX3Jlc2l6ZU1hcCk7XHJcblxyXG4gICAgICAgIGlmICh0eXBlb2YgdGhpcy5jb25maWcuaWQgPT09ICd1bmRlZmluZWQnKSB7XHJcbiAgICAgICAgICAgIHRoaXMuY29uZmlnLmlkID0gJ2tkeC1tYXAtMDEnO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICBuZ09uQ2hhbmdlcyhfc2ltcGxlQ2hhbmdlczogU2ltcGxlQ2hhbmdlcyk6IHZvaWQge1xyXG4gICAgICAgIGlmIChfc2ltcGxlQ2hhbmdlcy5oYXNPd25Qcm9wZXJ0eSgnYXBpJykpIHtcclxuICAgICAgICAgICAgdGhpcy5faW5pdEFwaSgpO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgaWYgKF9zaW1wbGVDaGFuZ2VzLmhhc093blByb3BlcnR5KCdwb3NpdGlvbicpKSB7XHJcbiAgICAgICAgICAgIHRoaXMuX3ZhbGlkYXRlTGF0TG5nKF9zaW1wbGVDaGFuZ2VzLnBvc2l0aW9uLmN1cnJlbnRWYWx1ZSk7XHJcblxyXG4gICAgICAgICAgICBpZiAoIV9zaW1wbGVDaGFuZ2VzWydwb3NpdGlvbiddLmZpcnN0Q2hhbmdlICYmIHRoaXMuaXNNYXBTaG93bikge1xyXG5cclxuICAgICAgICAgICAgICAgIGlmICh0eXBlb2YgdGhpcy5fbXlNYXAgPT09ICd1bmRlZmluZWQnKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgdGltZXIoMjAwKS5zdWJzY3JpYmUoKCk6IHZvaWQgPT4geyB0aGlzLl9yZWluaXRNYXAoKTsgfSk7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICBlbHNlIHRoaXMuX215TWFwLnBhblRvKHRoaXMucG9zaXRpb24pO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG5cclxuXHJcbiAgICAgICAgaWYgKF9zaW1wbGVDaGFuZ2VzLmhhc093blByb3BlcnR5KCdjb25maWcnKSkge1xyXG4gICAgICAgICAgICB0aGlzLmVycm9yTWVzc2FnZSA9IF9zaW1wbGVDaGFuZ2VzLmNvbmZpZy5jdXJyZW50VmFsdWUuZXJyb3JNZXNzYWdlIHx8ICdJbnZhbGlkIGxhdGl0dWRlL2xvbmdpdHVkZSB2YWx1ZSc7XHJcblxyXG4gICAgICAgICAgICBpZiAoX3NpbXBsZUNoYW5nZXMuaGFzT3duUHJvcGVydHkoJ3Bvc2l0aW9uJykpIHtcclxuICAgICAgICAgICAgICAgIGlmIChfc2ltcGxlQ2hhbmdlcy5jb25maWcuY3VycmVudFZhbHVlLmdvb2dsZUxpbmsgJiYgX3NpbXBsZUNoYW5nZXMuY29uZmlnLmN1cnJlbnRWYWx1ZS5nb29nbGVMaW5rLmRpc3BsYXkgJiYgdGhpcy5pc01hcFNob3duKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5fc2V0R29vZ2xlTGluayhfc2ltcGxlQ2hhbmdlcy5wb3NpdGlvbi5jdXJyZW50VmFsdWUpO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIGlmICghX3NpbXBsZUNoYW5nZXNbJ2NvbmZpZyddLmZpcnN0Q2hhbmdlKSB7XHJcbiAgICAgICAgICAgICAgICBpZiAodGhpcy5jb25maWcuem9vbSkge1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuX2NoZWNrWm9vbUNvbmZpZyh0aGlzLmNvbmZpZy56b29tKTtcclxuXHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKHRoaXMuY29uZmlnLnpvb20udmFsdWUpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgaWYgKHR5cGVvZiB0aGlzLl9teU1hcCAhPT0gJ3VuZGVmaW5lZCcpIHRoaXMuX215TWFwLnNldFpvb20odGhpcy5jb25maWcuem9vbS52YWx1ZSk7XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgICAgIGlmICh0aGlzLmNvbmZpZy5hdHRyaWJ1dGlvbikgdGhpcy5fcmVtb3ZlRGVmYXVsdEF0dHJpYnV0aW9uKHRoaXMuY29uZmlnLmF0dHJpYnV0aW9uKTtcclxuXHJcbiAgICAgICAgICAgICAgICBpZiAodGhpcy5jb25maWcudHlwZSAhPT0gJ2Jhc2ljJykge1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuX3JlbW92ZUFsbE1hcmtlckxheWVycygpO1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuX3NldE1hcmtlcnMoKTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgdGhpcy5fc2V0RGVmYXVsdENvbmZpZygpO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgaWYgKF9zaW1wbGVDaGFuZ2VzLmhhc093blByb3BlcnR5KCdkYXRhJykgJiYgIV9zaW1wbGVDaGFuZ2VzWydkYXRhJ10uZmlyc3RDaGFuZ2UgJiYgdGhpcy5jb25maWcudHlwZSAhPT0gJ2Jhc2ljJykge1xyXG4gICAgICAgICAgICB0aGlzLl9yZW1vdmVBbGxNYXJrZXJMYXllcnMoKTtcclxuICAgICAgICAgICAgdGhpcy5fc2V0TWFya2VycygpO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICBuZ0FmdGVyVmlld0luaXQoKTogdm9pZCB7XHJcbiAgICAgICAgaWYgKHRoaXMuaXNNYXBTaG93bikge1xyXG4gICAgICAgICAgICB0aGlzLl9pbml0TWFwKCk7XHJcbiAgICAgICAgICAgIHRoaXMuX2NkLmRldGVjdENoYW5nZXMoKTtcclxuXHJcbiAgICAgICAgICAgIHRoaXMuX3Jlc2l6ZU1hcCgpO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICBuZ09uRGVzdHJveSgpOiB2b2lkIHtcclxuICAgICAgICB3aW5kb3cucmVtb3ZlRXZlbnRMaXN0ZW5lcigncmVzaXplJywgdGhpcy5fcmVzaXplTWFwKTtcclxuICAgIH1cclxuXHJcbiAgICBwdWJsaWMgb25MZWdlbmRDbGljayhfbGVnZW5kSXRlbTogYW55KSB7XHJcbiAgICAgICAgbGV0IGxlZ2VuZEl0ZW1NYXJrZXI6IEhUTUxFbGVtZW50ID0gdGhpcy5fZWxlbWVudFJlZi5uYXRpdmVFbGVtZW50LnF1ZXJ5U2VsZWN0b3IoJyNrZGxpLScgKyBfbGVnZW5kSXRlbS5pZCArICcgLmF3ZXNvbWUtbWFya2VyJyk7XHJcbiAgICAgICAgbGV0IGxlZ2VuZEl0ZW1MYWJlbDogSFRNTEVsZW1lbnQgPSB0aGlzLl9lbGVtZW50UmVmLm5hdGl2ZUVsZW1lbnQucXVlcnlTZWxlY3RvcignI2tkbGktJyArIF9sZWdlbmRJdGVtLmlkICsgJyAua2R4LWxlZ2VuZC1sYWJlbCcpO1xyXG4gICAgICAgIGxldCBzZWxlY3RlZE1hcmtlckdyb3VwOiBMLk1hcmtlckNsdXN0ZXJHcm91cCB8IEwubWFya2VyO1xyXG5cclxuICAgICAgICBzd2l0Y2ggKHRoaXMuY29uZmlnLnR5cGUpIHtcclxuICAgICAgICAgICAgY2FzZSAnY2x1c3Rlcic6XHJcbiAgICAgICAgICAgIGNhc2UgJ2dyb3VwLWNsdXN0ZXInOlxyXG4gICAgICAgICAgICAgICAgc2VsZWN0ZWRNYXJrZXJHcm91cCA9IHRoaXMuX2NsdXN0ZXJNYXJrZXJzW19sZWdlbmRJdGVtLmlkXTtcclxuICAgICAgICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgICAgICBkZWZhdWx0OlxyXG4gICAgICAgICAgICAgICAgc2VsZWN0ZWRNYXJrZXJHcm91cCA9IHRoaXMuX21hcmtlcjtcclxuICAgICAgICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgaWYgKHRoaXMuX215TWFwLmhhc0xheWVyKHNlbGVjdGVkTWFya2VyR3JvdXApKSB7XHJcbiAgICAgICAgICAgIHRoaXMuX215TWFwLnJlbW92ZUxheWVyKHNlbGVjdGVkTWFya2VyR3JvdXApO1xyXG4gICAgICAgICAgICB0aGlzLl9rZERvbUVsZW1TdmMuYWRkQ2xhc3MobGVnZW5kSXRlbU1hcmtlciwgJ2F3ZXNvbWUtbWFya2VyLWljb24tbGlnaHRncmF5Jyk7XHJcbiAgICAgICAgICAgIHRoaXMuX2tkRG9tRWxlbVN2Yy5hZGRDbGFzcyhsZWdlbmRJdGVtTGFiZWwsICdrZHgtbGFiZWwtbGlnaHRncmF5Jyk7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICB0aGlzLl9teU1hcC5hZGRMYXllcihzZWxlY3RlZE1hcmtlckdyb3VwKTtcclxuICAgICAgICAgICAgdGhpcy5fa2REb21FbGVtU3ZjLnJlbW92ZUNsYXNzKGxlZ2VuZEl0ZW1NYXJrZXIsICdhd2Vzb21lLW1hcmtlci1pY29uLWxpZ2h0Z3JheScpO1xyXG4gICAgICAgICAgICB0aGlzLl9rZERvbUVsZW1TdmMucmVtb3ZlQ2xhc3MobGVnZW5kSXRlbUxhYmVsLCAna2R4LWxhYmVsLWxpZ2h0Z3JheScpO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF92YWxpZGF0ZUxhdExuZyhfcG9zaXRpb246IElNYXBQb3NpdGlvbik6IHZvaWQge1xyXG4gICAgICAgIGlmICghX3Bvc2l0aW9uKSB7XHJcbiAgICAgICAgICAgIHRoaXMuaXNNYXBTaG93biA9IGZhbHNlO1xyXG4gICAgICAgICAgICB0aGlzLmlzTWFwRXJyb3IgPSAhdGhpcy5pc01hcFNob3duO1xyXG4gICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgIGxldCBfbGF0OiBudW1iZXIgPSBfcG9zaXRpb24ubGF0O1xyXG4gICAgICAgICAgICBsZXQgX2xuZzogbnVtYmVyID0gX3Bvc2l0aW9uLmxuZztcclxuICAgICAgICAgICAgdGhpcy5pc01hcFNob3duID0gKHR5cGVvZiBfbGF0ID09PSAndW5kZWZpbmVkJykgfHwgKHR5cGVvZiBfbG5nID09PSAndW5kZWZpbmVkJykgfHwgKF9sbmcgPCAtMTgwIHx8IF9sbmcgPiAxODApIHx8IChfbGF0IDwgLTkwIHx8IF9sYXQgPiA5MCkgPyBmYWxzZSA6IHRydWU7XHJcbiAgICAgICAgICAgIHRoaXMuaXNNYXBFcnJvciA9ICF0aGlzLmlzTWFwU2hvd247XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGlmICghdGhpcy5pc01hcFNob3duICYmIHRoaXMuX215TWFwKSB7XHJcbiAgICAgICAgICAgIGRlbGV0ZSB0aGlzLl9teU1hcDtcclxuICAgICAgICAgICAgZGVsZXRlIHRoaXMuX2xheWVyO1xyXG4gICAgICAgICAgICBkZWxldGUgdGhpcy5fbWFya2VyO1xyXG4gICAgICAgICAgICBkZWxldGUgdGhpcy5fY2x1c3Rlck1hcmtlcnM7XHJcbiAgICAgICAgICAgIGRlbGV0ZSB0aGlzLm1hcmtlcnNMZWdlbmQ7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX2luaXRNYXAoKTogdm9pZCB7XHJcblxyXG4gICAgICAgIHRoaXMuX215TWFwID0gTC5tYXAodGhpcy5teU1hcC5uYXRpdmVFbGVtZW50LCB7XHJcbiAgICAgICAgICAgIGNlbnRlcjogdGhpcy5wb3NpdGlvbixcclxuICAgICAgICAgICAgem9vbTogKHRoaXMuY29uZmlnLnpvb20gJiYgdGhpcy5jb25maWcuem9vbS52YWx1ZSkgfHwgMTQsXHJcbiAgICAgICAgfSk7XHJcblxyXG4gICAgICAgIGlmICh0aGlzLmNvbmZpZy56b29tKSB0aGlzLl9jaGVja1pvb21Db25maWcodGhpcy5jb25maWcuem9vbSk7XHJcblxyXG4gICAgICAgIHRoaXMuX3NldExheWVyKCk7XHJcbiAgICAgICAgdGhpcy5fc2V0TWFya2VycygpO1xyXG5cclxuICAgICAgICB0aGlzLl9yZW1vdmVEZWZhdWx0QXR0cmlidXRpb24odGhpcy5jb25maWcuYXR0cmlidXRpb24pO1xyXG4gICAgICAgIGlmICh0aGlzLmNvbmZpZy5nb29nbGVMaW5rICYmIHRoaXMuY29uZmlnLmdvb2dsZUxpbmsuZGlzcGxheSAmJiB0aGlzLmNvbmZpZy50eXBlID09PSAnYmFzaWMnKSB0aGlzLl9zZXRMaW5rU3R5bGUodGhpcy5jb25maWcuem9vbSwgdGhpcy5jb25maWcuZ29vZ2xlTGluay5wb3NpdGlvbik7XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfcmVpbml0TWFwKCk6IHZvaWQge1xyXG4gICAgICAgIHRpbWVyKDUwKS5zdWJzY3JpYmUoKCk6IHZvaWQgPT4ge1xyXG4gICAgICAgICAgICBpZiAodHlwZW9mIHRoaXMubXlNYXAgPT09ICd1bmRlZmluZWQnKSB0aGlzLl9yZWluaXRNYXAoKTtcclxuICAgICAgICAgICAgZWxzZSB0aGlzLl9pbml0TWFwKCk7XHJcbiAgICAgICAgfSk7XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfaW5pdEFwaSgpOiB2b2lkIHtcclxuICAgICAgICBpZiAodHlwZW9mIHRoaXMuYXBpICE9PSAndW5kZWZpbmVkJyAmJiBPYmplY3Qua2V5cyh0aGlzLmFwaSkubGVuZ3RoID09PSAwKSB7XHJcbiAgICAgICAgICAgIHRoaXMuYXBpLnJlc2l6ZU1hcCA9ICgpOiB2b2lkID0+IHRoaXMuX3Jlc2l6ZU1hcCgpO1xyXG4gICAgICAgICAgICB0aGlzLmFwaS5nZXRab29tID0gKCk6IG51bWJlciA9PiB0aGlzLl9teU1hcC5nZXRab29tKCk7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX2NoZWNrWm9vbUNvbmZpZyhfY29uZmlnOiBJTWFwWm9vbUNvbmZpZyk6IHZvaWQge1xyXG4gICAgICAgIGlmICh0eXBlb2YgdGhpcy5fbXlNYXAgIT09ICd1bmRlZmluZWQnKSB7XHJcbiAgICAgICAgICAgIF9jb25maWcuaXNab29tQnV0dG9uID8gdGhpcy5fbXlNYXAuYWRkQ29udHJvbCh0aGlzLl9teU1hcC56b29tQ29udHJvbCkgOiB0aGlzLl9teU1hcC5yZW1vdmVDb250cm9sKHRoaXMuX215TWFwLnpvb21Db250cm9sKTtcclxuICAgICAgICAgICAgX2NvbmZpZy5pc1Njcm9sbFpvb20gPyB0aGlzLl9teU1hcC5zY3JvbGxXaGVlbFpvb20uZW5hYmxlKCkgOiB0aGlzLl9teU1hcC5zY3JvbGxXaGVlbFpvb20uZGlzYWJsZSgpO1xyXG4gICAgICAgICAgICBfY29uZmlnLmlzVG91Y2hab29tID8gdGhpcy5fbXlNYXAudG91Y2hab29tLmVuYWJsZSgpIDogdGhpcy5fbXlNYXAudG91Y2hab29tLmRpc2FibGUoKTtcclxuICAgICAgICAgICAgX2NvbmZpZy5pc0RvdWJsZUNsaWNrWm9vbSA/IHRoaXMuX215TWFwLmRvdWJsZUNsaWNrWm9vbS5lbmFibGUoKSA6IHRoaXMuX215TWFwLmRvdWJsZUNsaWNrWm9vbS5kaXNhYmxlKCk7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX3NldExheWVyKCk6IHZvaWQge1xyXG4gICAgICAgIGlmICh0aGlzLl9sYXllcikgdGhpcy5fbGF5ZXIucmVtb3ZlKCk7XHJcbiAgICAgICAgdGhpcy5faXNMYXllckVycm9yID0gZmFsc2U7XHJcbiAgICAgICAgdGhpcy5pc0xheWVyTG9hZGluZyA9IHRydWU7XHJcbiAgICAgICAgdGhpcy5fbGF5ZXIgPSBMLnRpbGVMYXllcignaHR0cHM6Ly97c30udGlsZS5vcGVuc3RyZWV0bWFwLm9yZy97en0ve3h9L3t5fS5wbmcnLCB7XHJcbiAgICAgICAgICAgIGF0dHJpYnV0aW9uOiAnJmNvcHk7IDxhIGhyZWY9XCJodHRwOi8vd3d3Lm9wZW5zdHJlZXRtYXAub3JnL2NvcHlyaWdodFwiPk9wZW5TdHJlZXRNYXA8L2E+JyxcclxuICAgICAgICAgICAgbWF4Wm9vbTogMTgsXHJcbiAgICAgICAgfSk7XHJcbiAgICAgICAgdGhpcy5fbGF5ZXIuYWRkVG8odGhpcy5fbXlNYXApO1xyXG4gICAgICAgIHRoaXMuX2F0dGFjaFRpbGVMaXN0ZW5lcigpO1xyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX3JlbW92ZURlZmF1bHRBdHRyaWJ1dGlvbihfYXR0cmlidXRpb246IHN0cmluZyk6IHZvaWQge1xyXG4gICAgICAgIGxldCBhdHRyaWJ1dGlvbkVsZW1lbnQ6IEVsZW1lbnQgPSB0aGlzLl9lbGVtZW50UmVmLm5hdGl2ZUVsZW1lbnQucXVlcnlTZWxlY3RvcignLmxlYWZsZXQtY29udHJvbC1hdHRyaWJ1dGlvbicpO1xyXG4gICAgICAgIGlmIChhdHRyaWJ1dGlvbkVsZW1lbnQgIT09IG51bGwpIHtcclxuICAgICAgICAgICAgbGV0IG5ld0F0dHJpYnV0aW9uRWxlbWVudDogSFRNTEVsZW1lbnQgPSB0aGlzLl9rZERvbUVsZW1TdmMuY3JlYXRlRWxlbWVudChhdHRyaWJ1dGlvbkVsZW1lbnQsICdjdXN0b20tYXR0cmlidXRpb24nKTtcclxuICAgICAgICAgICAgbmV3QXR0cmlidXRpb25FbGVtZW50LmlubmVyVGV4dCA9IF9hdHRyaWJ1dGlvbiB8fCAnT3BlbkVNSVMnO1xyXG4gICAgICAgICAgICBhdHRyaWJ1dGlvbkVsZW1lbnQucmVwbGFjZUNoaWxkKG5ld0F0dHJpYnV0aW9uRWxlbWVudCwgYXR0cmlidXRpb25FbGVtZW50LmZpcnN0Q2hpbGQpO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF9hdHRhY2hUaWxlTGlzdGVuZXIoKTogdm9pZCB7XHJcbiAgICAgICAgLyogQ2hlY2tzIGV2ZXJ5IHRpbGUuIE9ubHkgY2FsbGVkIHdoZW4gc29tZSB0aWxlIGxvYWQgaGFzIGZhaWxlZC4gKi9cclxuICAgICAgICB0aGlzLl9sYXllci5vbigndGlsZWVycm9yJywgKGVycm9yKTogdm9pZCA9PiB7XHJcbiAgICAgICAgICAgIC8vIG9ubHkgZXhlY3V0ZSB0aGUgZm9sbG93aW5nIGZvciB0aGUgZmlyc3QgdGlsZSBlcnJvclxyXG4gICAgICAgICAgICBpZiAoIXRoaXMuX2lzTGF5ZXJFcnJvcikge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5faXNMYXllckVycm9yID0gdHJ1ZTtcclxuICAgICAgICAgICAgICAgIHRoaXMuX2xheWVyUmVsb2FkVGltZXMrKztcclxuICAgICAgICAgICAgICAgIGlmICh0aGlzLl9sYXllclJlbG9hZFRpbWVzIDwgNSB8fCB0aGlzLl9sYXllclJlbG9hZFRpbWVzID09PSA1KSB7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5fc2V0TGF5ZXIoKTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIGlmICh0aGlzLl9sYXllclJlbG9hZFRpbWVzID4gNSkge1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuaXNNYXBTaG93biA9IGZhbHNlO1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuZXJyb3JNZXNzYWdlID0gJ01heCByZXRyeSByZWFjaGVkLiBNYXAgY2Fubm90IGJlIGxvYWRlZCBub3cuIFBsZWFzZSBjaGVjayB5b3VyIGludGVybmV0IGNvbm5lY3Rpb24gb3IgdHJ5IGFnYWluIGxhdGVyLic7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9KTtcclxuXHJcbiAgICAgICAgLyogQ2hlY2tzIGV2ZXJ5IHRpbGUuIE9ubHkgY2FsbGVkIHdoZW4gZWFjaCB0aWxlIGxvYWQgaXMgc3VjY2Vzc2Z1bC4gKi9cclxuICAgICAgICB0aGlzLl9sYXllci5vbigndGlsZWxvYWQnLCAoKTogdm9pZCA9PiB7XHJcbiAgICAgICAgICAgIHRoaXMuX3RpbGVsb2FkSW5kZXgrKztcclxuICAgICAgICAgICAgaWYgKHRoaXMuaXNMYXllckxvYWRpbmcgJiYgdGhpcy5fdGlsZWxvYWRJbmRleCA9PT0gT2JqZWN0LmtleXModGhpcy5fbGF5ZXIuX3RpbGVzKS5sZW5ndGgpIHtcclxuICAgICAgICAgICAgICAgIC8vIG9ubHkgc3RvcCBwcm9ncmVzcyBsb2FkZXIgd2hlbiBsYXN0IHRpbGUgbG9hZGVkIHN1Y2Nlc3NmdWxseVxyXG4gICAgICAgICAgICAgICAgLy8gdGhpcy5pc0xheWVyTG9hZGluZyA9IGZhbHNlO1xyXG4gICAgICAgICAgICAgICAgdGhpcy5faXNUaWxlc0xvYWRlZCA9IHRydWU7XHJcbiAgICAgICAgICAgICAgICB0aGlzLl9oaWRlTG9hZGluZ1NjcmVlbigpO1xyXG4gICAgICAgICAgICAgICAgLy8gcmVzZXQgY291bnRlcnNcclxuICAgICAgICAgICAgICAgIHRoaXMuX2xheWVyUmVsb2FkVGltZXMgPSAwO1xyXG4gICAgICAgICAgICAgICAgdGhpcy5fdGlsZWxvYWRJbmRleCA9IDA7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9KTtcclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF9yZXNpemVNYXAoKTogdm9pZCB7XHJcbiAgICAgICAgaWYgKHRoaXMuaXNNYXBTaG93bikge1xyXG4gICAgICAgICAgICB0aW1lcigpLnN1YnNjcmliZSgoKTogdm9pZCA9PiB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLl9teU1hcC5pbnZhbGlkYXRlU2l6ZSh7fSk7XHJcbiAgICAgICAgICAgIH0pO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF9zZXRHb29nbGVMaW5rKF9wb3NpdGlvbjogSU1hcFBvc2l0aW9uKTogdm9pZCB7XHJcbiAgICAgICAgaWYgKHRoaXMuY29uZmlnLnR5cGUgPT09ICdiYXNpYycpIHtcclxuICAgICAgICAgICAgdGhpcy5pc0xpbmtUb0dvb2dsZSA9IHRydWU7XHJcbiAgICAgICAgICAgIHRoaXMuZ29vZ2xlTGluayA9ICdodHRwczovL3d3dy5nb29nbGUuY29tL21hcHMvP3E9JyArIF9wb3NpdGlvbi5sYXQudG9TdHJpbmcoKSArICcsJyArIF9wb3NpdGlvbi5sbmcudG9TdHJpbmcoKTtcclxuICAgICAgICB9XHJcbiAgICAgICAgZWxzZSB7XHJcbiAgICAgICAgICAgIHRoaXMuaXNMaW5rVG9Hb29nbGUgPSBmYWxzZTtcclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfc2V0TGlua1N0eWxlKF96b29tQ29uZmlnOiBJTWFwWm9vbUNvbmZpZywgX2xpbmtQb3NpdGlvbjogc3RyaW5nKTogdm9pZCB7XHJcbiAgICAgICAgbGV0IGxpbmtFbGVtZW50OiBIVE1MRWxlbWVudCA9IHRoaXMuX2VsZW1lbnRSZWYubmF0aXZlRWxlbWVudC5xdWVyeVNlbGVjdG9yKCcua2R4LW1hcCAubGluay13cmFwcGVyJyk7XHJcbiAgICAgICAgc3dpdGNoIChfbGlua1Bvc2l0aW9uKSB7XHJcbiAgICAgICAgICAgIGNhc2UgJ3RvcC1sZWZ0JzpcclxuICAgICAgICAgICAgZGVmYXVsdDpcclxuICAgICAgICAgICAgICAgIC8vIG9ubHkgd2hlbiBab29tIEJ1dHRvbnMgYXJlIHJlbW92ZWQgdGhlbiB3ZSBwdXQgZ29vZ2xlTGluayBhdCB0aGUgcG9zaXRpb24gb2YgdGhlIFpvb20gQnV0dG9uc1xyXG4gICAgICAgICAgICAgICAgbGV0IG5ld0NsYXNzOiBzdHJpbmcgPSBfem9vbUNvbmZpZyAmJiBfem9vbUNvbmZpZy5pc1pvb21CdXR0b24gPT09IGZhbHNlID8gJycgOiAnIGJlbG93LXpvb20nO1xyXG4gICAgICAgICAgICAgICAgdGhpcy5fa2REb21FbGVtU3ZjLmFkZENsYXNzKGxpbmtFbGVtZW50LCAnbGVhZmxldC10b3AgbGVhZmxldC1sZWZ0JyArIG5ld0NsYXNzKTtcclxuICAgICAgICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgICAgICBjYXNlICd0b3AtcmlnaHQnOlxyXG4gICAgICAgICAgICAgICAgdGhpcy5fa2REb21FbGVtU3ZjLmFkZENsYXNzKGxpbmtFbGVtZW50LCAnbGVhZmxldC10b3AgbGVhZmxldC1yaWdodCcpO1xyXG4gICAgICAgICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgICAgIGNhc2UgJ2JvdHRvbS1sZWZ0JzpcclxuICAgICAgICAgICAgICAgIHRoaXMuX2tkRG9tRWxlbVN2Yy5hZGRDbGFzcyhsaW5rRWxlbWVudCwgJ2xlYWZsZXQtYm90dG9tIGxlYWZsZXQtbGVmdCcpO1xyXG4gICAgICAgICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgICAgIGNhc2UgJ2JvdHRvbS1yaWdodCc6XHJcbiAgICAgICAgICAgICAgICB0aGlzLl9rZERvbUVsZW1TdmMuYWRkQ2xhc3MobGlua0VsZW1lbnQsICdsZWFmbGV0LWJvdHRvbSBsZWFmbGV0LXJpZ2h0IGFib3ZlLWF0dHJpYnV0aW9uJyk7XHJcbiAgICAgICAgICAgICAgICBicmVhaztcclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfc2V0TWFya2VycygpOiB2b2lkIHtcclxuICAgICAgICBpZiAodHlwZW9mIHRoaXMuX215TWFwICE9PSAndW5kZWZpbmVkJykge1xyXG4gICAgICAgICAgICBzd2l0Y2ggKHRoaXMuY29uZmlnLnR5cGUpIHtcclxuICAgICAgICAgICAgICAgIGNhc2UgJ2NsdXN0ZXInOlxyXG4gICAgICAgICAgICAgICAgY2FzZSAnZ3JvdXAtY2x1c3Rlcic6XHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKHR5cGVvZiB0aGlzLmRhdGEgIT09ICd1bmRlZmluZWQnICYmIE9iamVjdC5rZXlzKHRoaXMuZGF0YSkubGVuZ3RoICE9PSAwKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGxldCBjbHVzdGVyRGF0YTogSU1hcFBvcHVsYXRlQ2x1c3RlckRhdGEgPSB0aGlzLl9rZE1hcFN2Yy5wb3B1bGF0ZU1hcmtlcnModGhpcy5kYXRhLCB0aGlzLl9teU1hcCwgdGhpcy5jb25maWcudHlwZSk7XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLm1hcmtlcnNMZWdlbmQgPSBjbHVzdGVyRGF0YS5tYXJrZXJzTGVnZW5kO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLl9jbHVzdGVyTWFya2VycyA9IGNsdXN0ZXJEYXRhLmNsdXN0ZXJNYXJrZXJzO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLl9pc01hcmtlckxvYWRlZCA9IHRydWU7XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgICAgICAgICAgZGVmYXVsdDpcclxuICAgICAgICAgICAgICAgICAgICBsZXQgZGVmYXVsdEljb246IElNYXBNYXJrZXIgPSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG1hcmtlckNvbG9yOiAncHVycGxlJyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgdGl0bGU6IHRoaXMuY29uZmlnLm1hcmtlci50aXRsZVxyXG4gICAgICAgICAgICAgICAgICAgIH07XHJcbiAgICAgICAgICAgICAgICAgICAgbGV0IGljb25NYXJrZXI6IEwuSWNvbiA9IHRoaXMuX2tkTWFwU3ZjLnNldEljb24oZGVmYXVsdEljb24pO1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuX21hcmtlciA9IEwubWFya2VyKHRoaXMucG9zaXRpb24sIHsgaWNvbjogaWNvbk1hcmtlciB9KS5hZGRUbyh0aGlzLl9teU1hcCk7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5faXNNYXJrZXJMb2FkZWQgPSB0cnVlO1xyXG4gICAgICAgICAgICAgICAgICAgIGlmICh0aGlzLmNvbmZpZy5oYXNPd25Qcm9wZXJ0eSgnY29udGVudCcpKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuX21hcmtlci5iaW5kUG9wdXAodGhpcy5jb25maWcuY29udGVudCk7XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgICAgICAgICBpZiAodGhpcy5jb25maWcuaGFzT3duUHJvcGVydHkoJ2xlZ2VuZCcpKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMubWFya2Vyc0xlZ2VuZCA9IFt7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpY29uOiBpY29uTWFya2VyLmNyZWF0ZUljb24oKSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxhYmVsOiB0aGlzLmNvbmZpZy5tYXJrZXIudGl0bGUsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZDogdGhpcy5jb25maWcubWFya2VyLmhhc093blByb3BlcnR5KCdpZCcpID8gdGhpcy5jb25maWcubWFya2VyLmlkIDogJ2tkeC1zaW5nbGUtbWFya2VyJ1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB9XTtcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICB0aGlzLl9oaWRlTG9hZGluZ1NjcmVlbigpO1xyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX2hpZGVMb2FkaW5nU2NyZWVuKCk6IHZvaWQge1xyXG4gICAgICAgIGlmICh0aGlzLl9pc01hcmtlckxvYWRlZCAmJiB0aGlzLl9pc1RpbGVzTG9hZGVkKSB7XHJcbiAgICAgICAgICAgIHRoaXMuaXNMYXllckxvYWRpbmcgPSBmYWxzZTtcclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfcmVtb3ZlQWxsTWFya2VyTGF5ZXJzKCk6IHZvaWQge1xyXG4gICAgICAgIGZvciAobGV0IGxlZ2VuZEl0ZW1JZCBpbiB0aGlzLl9jbHVzdGVyTWFya2Vycykge1xyXG4gICAgICAgICAgICBpZiAodGhpcy5fY2x1c3Rlck1hcmtlcnNbbGVnZW5kSXRlbUlkXSkgdGhpcy5fbXlNYXAucmVtb3ZlTGF5ZXIodGhpcy5fY2x1c3Rlck1hcmtlcnNbbGVnZW5kSXRlbUlkXSk7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICB0aGlzLm1hcmtlcnNMZWdlbmQgPSBbXTtcclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF9zZXREZWZhdWx0Q29uZmlnKCk6IHZvaWQge1xyXG4gICAgICAgIHRoaXMubWFwQ29uZmlnID0gdGhpcy5fa2RNYXBTdmMuZ2V0RGVmYXVsdENvbmZpZygpO1xyXG4gICAgICAgIHRoaXMuX2RhdGFTdmMuZGVlcE1lcmdlT2JqZWN0KHRoaXMubWFwQ29uZmlnLCB0aGlzLmNvbmZpZywgZmFsc2UpO1xyXG5cclxuICAgICAgICB0aGlzLm1hcENvbmZpZy5sZWdlbmQuZW5hYmxlZCA9IHRoaXMuX3NldEVuYWJsZWQoJ2xlZ2VuZCcsIFsndGl0bGUnXSk7XHJcbiAgICAgICAgaWYgKHRoaXMubWFwQ29uZmlnLmZvb3RlcikgdGhpcy5tYXBDb25maWcuZm9vdGVyLmVuYWJsZWQgPSB0aGlzLl9zZXRFbmFibGVkKCdmb290ZXInLCBbJ2JvdHRvbUxhYmVsJywgJ2Zvb3ROb3RlJ10pO1xyXG5cclxuICAgICAgICB0aGlzLl9zZXRDbGFzc05hbWVzKCk7XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfc2V0RW5hYmxlZChfb2JqS2V5OiBzdHJpbmcsIF90ZXh0S2V5czogQXJyYXk8c3RyaW5nPik6IGJvb2xlYW4ge1xyXG4gICAgICAgIGlmICh0aGlzLm1hcENvbmZpZ1tfb2JqS2V5XSAmJiB0eXBlb2YgdGhpcy5tYXBDb25maWdbX29iaktleV0uZW5hYmxlZCAhPT0gJ3VuZGVmaW5lZCcpIHtcclxuICAgICAgICAgICAgcmV0dXJuIHRoaXMubWFwQ29uZmlnW19vYmpLZXldLmVuYWJsZWQ7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICBmb3IgKGxldCBpOiBudW1iZXIgPSBfdGV4dEtleXMubGVuZ3RoIC0gMTsgaSA+PSAwOyBpLS0pIHtcclxuICAgICAgICAgICAgaWYgKHRoaXMubWFwQ29uZmlnW19vYmpLZXldW190ZXh0S2V5c1tpXV0gJiYgdGhpcy5tYXBDb25maWdbX29iaktleV1bX3RleHRLZXlzW2ldXS50ZXh0ICE9PSAnJykge1xyXG4gICAgICAgICAgICAgICAgcmV0dXJuIHRydWU7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIGlmIChfb2JqS2V5ID09PSAnbGVnZW5kJyAmJiB0aGlzLm1hcmtlcnNMZWdlbmQubGVuZ3RoID09PSAwKSB7XHJcbiAgICAgICAgICAgIHJldHVybiBmYWxzZTtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIHJldHVybiBmYWxzZVxyXG4gICAgfVxyXG5cclxuICAgIC8qIFRvIGJlIHJldmlzaXQuIEhvdCBmaXggZm9yIGRvd25ncmFkZSBjb21wb25lbnQgYXMgbmdjbGFzcyB2YWx1ZSBkb2Vzbid0IGNoYW5nZS4qL1xyXG4gICAgcHJpdmF0ZSBfc2V0Q2xhc3NOYW1lcygpOiB2b2lkIHtcclxuXHJcbiAgICAgICAgLy8gaHRtbENsYXNzT2JqIGlzIGEgd29ya2Fyb3VuZCBmb3IgZG93bmdyYWRlIG1ldGhvZFxyXG4gICAgICAgIHRoaXMuaHRtbENsYXNzID0gJyc7XHJcblxyXG4gICAgICAgIGlmICh0eXBlb2YgdGhpcy5jb25maWcubGVnZW5kLmZsb2F0ICE9PSAndW5kZWZpbmVkJyAmJiB0aGlzLmNvbmZpZy5sZWdlbmQuZmxvYXQpIHtcclxuICAgICAgICAgICAgdGhpcy5odG1sQ2xhc3MgKz0gJ2xlZ2VuZC1mbG9hdCAnO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgaWYgKHR5cGVvZiB0aGlzLmNvbmZpZy5sZWdlbmQudmVydGljYWxBbGlnbiAhPT0gJ3VuZGVmaW5lZCcpIHtcclxuICAgICAgICAgICAgdGhpcy5odG1sQ2xhc3MgKz0gdGhpcy5jb25maWcubGVnZW5kLnZlcnRpY2FsQWxpZ24gKyAnICc7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICBpZiAodHlwZW9mIHRoaXMuY29uZmlnLmxlZ2VuZC5hbGlnbiAhPT0gJ3VuZGVmaW5lZCcpIHtcclxuICAgICAgICAgICAgdGhpcy5odG1sQ2xhc3MgKz0gdGhpcy5jb25maWcubGVnZW5kLmFsaWduO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbn1cclxuIl19