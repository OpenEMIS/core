import { Injectable } from '@angular/core';
import { KdBroadcaster } from '../kd-common/index';
import * as i0 from "@angular/core";
import * as i1 from "../kd-common/kd-broadcaster-svc";
export class KdModalEvent {
    constructor(_broadcaster) {
        this._broadcaster = _broadcaster;
    }
    toggleOpen(data) {
        this._broadcaster.broadcast('ModalOpen', data);
    }
    onToggleOpen() {
        return this._broadcaster.on('ModalOpen');
    }
    toggleClose(data) {
        this._broadcaster.broadcast('ModalClose', data);
    }
    onToggleClose() {
        return this._broadcaster.on('ModalClose');
    }
}
KdModalEvent.ɵprov = i0.ɵɵdefineInjectable({ factory: function KdModalEvent_Factory() { return new KdModalEvent(i0.ɵɵinject(i1.KdBroadcaster)); }, token: KdModalEvent, providedIn: "root" });
KdModalEvent.decorators = [
    { type: Injectable, args: [{
                providedIn: 'root'
            },] }
];
KdModalEvent.ctorParameters = () => [
    { type: KdBroadcaster }
];
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoia2QtbW9kYWwtZXZlbnQuanMiLCJzb3VyY2VSb290IjoiRDovb3BlbkVNSVMvc3R5bGVndWlkZS9pb3N0Zy1vcGVuZW1pcy1zdHlsZWd1aWRlL3Byb2plY3RzL29wZW5lbWlzLXN0eWxlZ3VpZGUtbGliL3NyYy8iLCJzb3VyY2VzIjpbImtkLWNvbXBvbmVudHMva2QtYW5ndWxhci1tb2RhbC9rZC1tb2RhbC1ldmVudC50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQSxPQUFPLEVBQUUsVUFBVSxFQUFFLE1BQU0sZUFBZSxDQUFDO0FBRTNDLE9BQU8sRUFBRSxhQUFhLEVBQUUsTUFBTSxvQkFBb0IsQ0FBQzs7O0FBS25ELE1BQU0sT0FBTyxZQUFZO0lBQ3JCLFlBQW9CLFlBQTJCO1FBQTNCLGlCQUFZLEdBQVosWUFBWSxDQUFlO0lBQUksQ0FBQztJQUVwRCxVQUFVLENBQUMsSUFBVTtRQUNqQixJQUFJLENBQUMsWUFBWSxDQUFDLFNBQVMsQ0FBQyxXQUFXLEVBQUUsSUFBSSxDQUFDLENBQUM7SUFDbkQsQ0FBQztJQUVELFlBQVk7UUFDUixPQUFPLElBQUksQ0FBQyxZQUFZLENBQUMsRUFBRSxDQUFNLFdBQVcsQ0FBQyxDQUFDO0lBQ2xELENBQUM7SUFFRCxXQUFXLENBQUMsSUFBVTtRQUNsQixJQUFJLENBQUMsWUFBWSxDQUFDLFNBQVMsQ0FBQyxZQUFZLEVBQUUsSUFBSSxDQUFDLENBQUM7SUFDcEQsQ0FBQztJQUVELGFBQWE7UUFDVCxPQUFPLElBQUksQ0FBQyxZQUFZLENBQUMsRUFBRSxDQUFNLFlBQVksQ0FBQyxDQUFDO0lBQ25ELENBQUM7Ozs7WUFwQkosVUFBVSxTQUFDO2dCQUNSLFVBQVUsRUFBRSxNQUFNO2FBQ3JCOzs7WUFKUSxhQUFhIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgSW5qZWN0YWJsZSB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xyXG5pbXBvcnQgeyBPYnNlcnZhYmxlIH0gZnJvbSAncnhqcyc7XHJcbmltcG9ydCB7IEtkQnJvYWRjYXN0ZXIgfSBmcm9tICcuLi9rZC1jb21tb24vaW5kZXgnO1xyXG5cclxuQEluamVjdGFibGUoe1xyXG4gICAgcHJvdmlkZWRJbjogJ3Jvb3QnXHJcbn0pXHJcbmV4cG9ydCBjbGFzcyBLZE1vZGFsRXZlbnQge1xyXG4gICAgY29uc3RydWN0b3IocHJpdmF0ZSBfYnJvYWRjYXN0ZXI6IEtkQnJvYWRjYXN0ZXIpIHsgfVxyXG5cclxuICAgIHRvZ2dsZU9wZW4oZGF0YT86IGFueSk6IHZvaWQge1xyXG4gICAgICAgIHRoaXMuX2Jyb2FkY2FzdGVyLmJyb2FkY2FzdCgnTW9kYWxPcGVuJywgZGF0YSk7XHJcbiAgICB9XHJcblxyXG4gICAgb25Ub2dnbGVPcGVuKCk6IE9ic2VydmFibGU8YW55PiB7XHJcbiAgICAgICAgcmV0dXJuIHRoaXMuX2Jyb2FkY2FzdGVyLm9uPGFueT4oJ01vZGFsT3BlbicpO1xyXG4gICAgfVxyXG5cclxuICAgIHRvZ2dsZUNsb3NlKGRhdGE/OiBhbnkpOiB2b2lkIHtcclxuICAgICAgICB0aGlzLl9icm9hZGNhc3Rlci5icm9hZGNhc3QoJ01vZGFsQ2xvc2UnLCBkYXRhKTtcclxuICAgIH1cclxuXHJcbiAgICBvblRvZ2dsZUNsb3NlKCk6IE9ic2VydmFibGU8YW55PiB7XHJcbiAgICAgICAgcmV0dXJuIHRoaXMuX2Jyb2FkY2FzdGVyLm9uPGFueT4oJ01vZGFsQ2xvc2UnKTtcclxuICAgIH1cclxufVxyXG4iXX0=