import { Component, Input, ViewChild } from '@angular/core';
import { NgbModal, ModalDismissReasons, NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { KdModalEvent } from './kd-modal-event';
export { KdModalEvent } from './kd-modal-event';
export class KdModal {
    constructor(_ngbModal, _modalEvent) {
        this._ngbModal = _ngbModal;
        this._modalEvent = _modalEvent;
        this._isBodyExist = false;
        this._modalDefault = {
            suspendClose: false,
            title: 'Modal Title',
            body: 'Modal Body Text.',
            button: [
                {
                    text: 'Cancel',
                    class: 'btn-outline',
                    callback: () => { }
                }
            ]
        };
    }
    ngOnInit() {
        this.defaultConfig();
        this._modalOpenSub = this._modalEvent.onToggleOpen().subscribe(val => {
            if (typeof val === 'undefined' || this.config.id === val) {
                this._curModal = this._ngbModal.open(this.contentRef);
                // console.log(this._curModal.close);
                // console.log('am i modal loaded', val);
                // if (typeof this.config.id === 'undefined') this.open(this.contentRef);
                // else if (val === this.config.id) this.open(this.contentRef);
                this._curModal.result.then((_result) => {
                    this.closeResult = `Closed with: ${_result}`;
                    // console.log('_result : ', this.closeResult);
                }, (_reason) => {
                    this.closeResult = `Dismissed ${this._getDismissReason(_reason)}`;
                    // console.log('_reason : ', this.closeResult);
                });
            }
        });
        this._modalCloseSub = this._modalEvent.onToggleClose().subscribe(val => {
            if (typeof val === 'undefined' || this.config.id === val) {
                this._curModal.close();
            }
        });
    }
    ngOnChanges() {
        this.defaultConfig();
    }
    ngOnDestroy() {
        this._modalOpenSub.unsubscribe();
    }
    defaultConfig() {
        if (typeof this.config !== 'undefined') {
            this._modalDefault = this.config;
            if (typeof this._modalDefault.button !== 'undefined') {
                for (let i = 0; i < this._modalDefault.button.length; i++) {
                    if (typeof this.config !== 'undefined')
                        this._modalDefault.button[i] = this.config.button[i];
                }
            }
            if (typeof this.config.body !== 'undefined' && this.config.body !== '')
                this._isBodyExist = true;
        }
    }
    callback(event, btn) {
        if (typeof btn.callback === 'function')
            btn.callback(event, btn);
    }
    _getDismissReason(reason) {
        if (reason === ModalDismissReasons.ESC)
            return 'by pressing ESC';
        else if (reason === ModalDismissReasons.BACKDROP_CLICK)
            return 'by clicking on a backdrop';
        else
            return `with: ${reason}`;
    }
}
KdModal.decorators = [
    { type: Component, args: [{
                selector: 'kd-modal',
                template: "<ng-template ngbModalContainer #content let-c=\"close\" let-d=\"dismiss\">\r\n    <div class=\"kdx-modal-dialog-wrapper\">\r\n        <div class=\"modal-header\">\r\n            <h4 class=\"modal-title\">{{_modalDefault.title}}</h4>\r\n            <button  *ngIf=\"!_modalDefault.suspendClose\" type=\"button\" class=\"close\" aria-label=\"Close\" (click)=\"d('Cross click')\">\r\n              <i class=\"kd-close-round\" aria-hidden=\"true\"></i>\r\n            </button>\r\n        </div>\r\n        <div class=\"modal-body\">\r\n            <p *ngIf=\"_isBodyExist\">{{_modalDefault.body}}</p>\r\n            <ng-content *ngIf=\"!_isBodyExist\"></ng-content>\r\n        </div>\r\n        <div class=\"modal-footer\">\r\n            <button type=\"button\" class=\"btn\" ngClass=\"{{btn.class}}\" *ngFor=\"let btn of _modalDefault.button\" (click)=\"callback($event, btn)\">\r\n                {{btn.text}}\r\n            </button>\r\n            <!-- <button type=\"button\" class=\"btn {{btn.class}}\" (click)=\"c('Close click')\">{{btn.text}}</button> -->\r\n        </div>\r\n    </div>\r\n</ng-template>\r\n<!-- <pre>{{closeResult}}</pre> -->\r\n",
                providers: [KdModalEvent, NgbActiveModal]
            },] }
];
KdModal.ctorParameters = () => [
    { type: NgbModal },
    { type: KdModalEvent }
];
KdModal.propDecorators = {
    config: [{ type: Input }],
    contentRef: [{ type: ViewChild, args: ['content', { static: true },] }]
};
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoia2QtYW5ndWxhci1tb2RhbC5qcyIsInNvdXJjZVJvb3QiOiJEOi9vcGVuRU1JUy9zdHlsZWd1aWRlL2lvc3RnLW9wZW5lbWlzLXN0eWxlZ3VpZGUvcHJvamVjdHMvb3BlbmVtaXMtc3R5bGVndWlkZS1saWIvc3JjLyIsInNvdXJjZXMiOlsia2QtY29tcG9uZW50cy9rZC1hbmd1bGFyLW1vZGFsL2tkLWFuZ3VsYXItbW9kYWwudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsT0FBTyxFQUNILFNBQVMsRUFDVCxLQUFLLEVBRUwsU0FBUyxFQUVaLE1BQU0sZUFBZSxDQUFDO0FBRXZCLE9BQU8sRUFBRSxRQUFRLEVBQUUsbUJBQW1CLEVBQUUsY0FBYyxFQUFlLE1BQU0sNEJBQTRCLENBQUM7QUFDeEcsT0FBTyxFQUFFLFlBQVksRUFBRSxNQUFNLGtCQUFrQixDQUFDO0FBR2hELE9BQU8sRUFBRSxZQUFZLEVBQUUsTUFBTSxrQkFBa0IsQ0FBQztBQVFoRCxNQUFNLE9BQU8sT0FBTztJQXNCaEIsWUFDWSxTQUFtQixFQUNuQixXQUF5QjtRQUR6QixjQUFTLEdBQVQsU0FBUyxDQUFVO1FBQ25CLGdCQUFXLEdBQVgsV0FBVyxDQUFjO1FBdEI5QixpQkFBWSxHQUFZLEtBQUssQ0FBQztRQUtyQyxrQkFBYSxHQUFRO1lBQ2pCLFlBQVksRUFBRSxLQUFLO1lBQ25CLEtBQUssRUFBRSxhQUFhO1lBQ3BCLElBQUksRUFBRSxrQkFBa0I7WUFDeEIsTUFBTSxFQUFFO2dCQUNKO29CQUNJLElBQUksRUFBRSxRQUFRO29CQUNkLEtBQUssRUFBRSxhQUFhO29CQUNwQixRQUFRLEVBQUUsR0FBUyxFQUFFLEdBQUcsQ0FBQztpQkFDNUI7YUFBQztTQUNULENBQUM7SUFRRSxDQUFDO0lBRUwsUUFBUTtRQUNKLElBQUksQ0FBQyxhQUFhLEVBQUUsQ0FBQztRQUNyQixJQUFJLENBQUMsYUFBYSxHQUFHLElBQUksQ0FBQyxXQUFXLENBQUMsWUFBWSxFQUFFLENBQUMsU0FBUyxDQUFDLEdBQUcsQ0FBQyxFQUFFO1lBQ2pFLElBQUksT0FBTyxHQUFHLEtBQUssV0FBVyxJQUFJLElBQUksQ0FBQyxNQUFNLENBQUMsRUFBRSxLQUFLLEdBQUcsRUFBRTtnQkFDdEQsSUFBSSxDQUFDLFNBQVMsR0FBRyxJQUFJLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLENBQUM7Z0JBQ3RELHFDQUFxQztnQkFDckMseUNBQXlDO2dCQUN6Qyx5RUFBeUU7Z0JBQ3pFLCtEQUErRDtnQkFDL0QsSUFBSSxDQUFDLFNBQVMsQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLENBQUMsT0FBTyxFQUFRLEVBQUU7b0JBQ3pDLElBQUksQ0FBQyxXQUFXLEdBQUcsZ0JBQWdCLE9BQU8sRUFBRSxDQUFDO29CQUM3QywrQ0FBK0M7Z0JBQ25ELENBQUMsRUFBRSxDQUFDLE9BQU8sRUFBUSxFQUFFO29CQUNqQixJQUFJLENBQUMsV0FBVyxHQUFHLGFBQWEsSUFBSSxDQUFDLGlCQUFpQixDQUFDLE9BQU8sQ0FBQyxFQUFFLENBQUM7b0JBQ2xFLCtDQUErQztnQkFDbkQsQ0FBQyxDQUFDLENBQUM7YUFDTjtRQUNMLENBQUMsQ0FBQyxDQUFDO1FBRUgsSUFBSSxDQUFDLGNBQWMsR0FBRyxJQUFJLENBQUMsV0FBVyxDQUFDLGFBQWEsRUFBRSxDQUFDLFNBQVMsQ0FBQyxHQUFHLENBQUMsRUFBRTtZQUNuRSxJQUFJLE9BQU8sR0FBRyxLQUFLLFdBQVcsSUFBSSxJQUFJLENBQUMsTUFBTSxDQUFDLEVBQUUsS0FBSyxHQUFHLEVBQUU7Z0JBQ3RELElBQUksQ0FBQyxTQUFTLENBQUMsS0FBSyxFQUFFLENBQUM7YUFDMUI7UUFDTCxDQUFDLENBQUMsQ0FBQztJQUNQLENBQUM7SUFFRCxXQUFXO1FBQ1AsSUFBSSxDQUFDLGFBQWEsRUFBRSxDQUFDO0lBQ3pCLENBQUM7SUFFRCxXQUFXO1FBQ1AsSUFBSSxDQUFDLGFBQWEsQ0FBQyxXQUFXLEVBQUUsQ0FBQztJQUNyQyxDQUFDO0lBRUQsYUFBYTtRQUNULElBQUksT0FBTyxJQUFJLENBQUMsTUFBTSxLQUFLLFdBQVcsRUFBRTtZQUNwQyxJQUFJLENBQUMsYUFBYSxHQUFHLElBQUksQ0FBQyxNQUFNLENBQUM7WUFDakMsSUFBSSxPQUFPLElBQUksQ0FBQyxhQUFhLENBQUMsTUFBTSxLQUFLLFdBQVcsRUFBRTtnQkFDbEQsS0FBSyxJQUFJLENBQUMsR0FBVyxDQUFDLEVBQUUsQ0FBQyxHQUFHLElBQUksQ0FBQyxhQUFhLENBQUMsTUFBTSxDQUFDLE1BQU0sRUFBRSxDQUFDLEVBQUUsRUFBRTtvQkFDL0QsSUFBSSxPQUFPLElBQUksQ0FBQyxNQUFNLEtBQUssV0FBVzt3QkFBRSxJQUFJLENBQUMsYUFBYSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsR0FBRyxJQUFJLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQztpQkFDaEc7YUFDSjtZQUNELElBQUksT0FBTyxJQUFJLENBQUMsTUFBTSxDQUFDLElBQUksS0FBSyxXQUFXLElBQUksSUFBSSxDQUFDLE1BQU0sQ0FBQyxJQUFJLEtBQUssRUFBRTtnQkFBRSxJQUFJLENBQUMsWUFBWSxHQUFHLElBQUksQ0FBQztTQUNwRztJQUNMLENBQUM7SUFFTSxRQUFRLENBQUMsS0FBVSxFQUFFLEdBQVE7UUFDaEMsSUFBSSxPQUFPLEdBQUcsQ0FBQyxRQUFRLEtBQUssVUFBVTtZQUFFLEdBQUcsQ0FBQyxRQUFRLENBQUMsS0FBSyxFQUFFLEdBQUcsQ0FBQyxDQUFDO0lBQ3JFLENBQUM7SUFFTyxpQkFBaUIsQ0FBQyxNQUFXO1FBQ2pDLElBQUksTUFBTSxLQUFLLG1CQUFtQixDQUFDLEdBQUc7WUFBRSxPQUFPLGlCQUFpQixDQUFDO2FBQzVELElBQUksTUFBTSxLQUFLLG1CQUFtQixDQUFDLGNBQWM7WUFBRSxPQUFPLDJCQUEyQixDQUFDOztZQUN0RixPQUFPLFNBQVMsTUFBTSxFQUFFLENBQUM7SUFDbEMsQ0FBQzs7O1lBdkZKLFNBQVMsU0FBQztnQkFDUCxRQUFRLEVBQUUsVUFBVTtnQkFDcEIsOG9DQUFzQztnQkFDdEMsU0FBUyxFQUFFLENBQUMsWUFBWSxFQUFFLGNBQWMsQ0FBQzthQUM1Qzs7O1lBVlEsUUFBUTtZQUNSLFlBQVk7OztxQkE4QmhCLEtBQUs7eUJBQ0wsU0FBUyxTQUFDLFNBQVMsRUFBRSxFQUFFLE1BQU0sRUFBRSxJQUFJLEVBQUUiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQge1xyXG4gICAgQ29tcG9uZW50LFxyXG4gICAgSW5wdXQsXHJcbiAgICBPbkluaXQsXHJcbiAgICBWaWV3Q2hpbGQsXHJcbiAgICBPbkRlc3Ryb3lcclxufSBmcm9tICdAYW5ndWxhci9jb3JlJztcclxuXHJcbmltcG9ydCB7IE5nYk1vZGFsLCBNb2RhbERpc21pc3NSZWFzb25zLCBOZ2JBY3RpdmVNb2RhbCwgTmdiTW9kYWxSZWYgfSBmcm9tICdAbmctYm9vdHN0cmFwL25nLWJvb3RzdHJhcCc7XHJcbmltcG9ydCB7IEtkTW9kYWxFdmVudCB9IGZyb20gJy4va2QtbW9kYWwtZXZlbnQnO1xyXG5pbXBvcnQgeyBTdWJzY3JpcHRpb24gfSBmcm9tICdyeGpzJztcclxuXHJcbmV4cG9ydCB7IEtkTW9kYWxFdmVudCB9IGZyb20gJy4va2QtbW9kYWwtZXZlbnQnO1xyXG5cclxuQENvbXBvbmVudCh7XHJcbiAgICBzZWxlY3RvcjogJ2tkLW1vZGFsJyxcclxuICAgIHRlbXBsYXRlVXJsOiAnLi9rZC1hbmd1bGFyLW1vZGFsLmh0bWwnLFxyXG4gICAgcHJvdmlkZXJzOiBbS2RNb2RhbEV2ZW50LCBOZ2JBY3RpdmVNb2RhbF1cclxufSlcclxuXHJcbmV4cG9ydCBjbGFzcyBLZE1vZGFsIGltcGxlbWVudHMgT25Jbml0LCBPbkRlc3Ryb3kge1xyXG4gICAgcHJpdmF0ZSBfY3VyTW9kYWw6IE5nYk1vZGFsUmVmO1xyXG4gICAgcHVibGljIF9pc0JvZHlFeGlzdDogYm9vbGVhbiA9IGZhbHNlO1xyXG4gICAgcHJpdmF0ZSBfbW9kYWxPcGVuU3ViOiBTdWJzY3JpcHRpb247XHJcbiAgICBwcml2YXRlIF9tb2RhbENsb3NlU3ViOiBTdWJzY3JpcHRpb247XHJcbiAgICBjbG9zZVJlc3VsdDogc3RyaW5nO1xyXG5cclxuICAgIF9tb2RhbERlZmF1bHQ6IGFueSA9IHtcclxuICAgICAgICBzdXNwZW5kQ2xvc2U6IGZhbHNlLFxyXG4gICAgICAgIHRpdGxlOiAnTW9kYWwgVGl0bGUnLFxyXG4gICAgICAgIGJvZHk6ICdNb2RhbCBCb2R5IFRleHQuJyxcclxuICAgICAgICBidXR0b246IFtcclxuICAgICAgICAgICAge1xyXG4gICAgICAgICAgICAgICAgdGV4dDogJ0NhbmNlbCcsXHJcbiAgICAgICAgICAgICAgICBjbGFzczogJ2J0bi1vdXRsaW5lJyxcclxuICAgICAgICAgICAgICAgIGNhbGxiYWNrOiAoKTogdm9pZCA9PiB7IH1cclxuICAgICAgICAgICAgfV1cclxuICAgIH07XHJcblxyXG4gICAgQElucHV0KCkgY29uZmlnOiBhbnk7XHJcbiAgICBAVmlld0NoaWxkKCdjb250ZW50JywgeyBzdGF0aWM6IHRydWUgfSkgY29udGVudFJlZjogYW55O1xyXG5cclxuICAgIGNvbnN0cnVjdG9yKFxyXG4gICAgICAgIHByaXZhdGUgX25nYk1vZGFsOiBOZ2JNb2RhbCxcclxuICAgICAgICBwcml2YXRlIF9tb2RhbEV2ZW50OiBLZE1vZGFsRXZlbnRcclxuICAgICkgeyB9XHJcblxyXG4gICAgbmdPbkluaXQoKTogdm9pZCB7XHJcbiAgICAgICAgdGhpcy5kZWZhdWx0Q29uZmlnKCk7XHJcbiAgICAgICAgdGhpcy5fbW9kYWxPcGVuU3ViID0gdGhpcy5fbW9kYWxFdmVudC5vblRvZ2dsZU9wZW4oKS5zdWJzY3JpYmUodmFsID0+IHtcclxuICAgICAgICAgICAgaWYgKHR5cGVvZiB2YWwgPT09ICd1bmRlZmluZWQnIHx8IHRoaXMuY29uZmlnLmlkID09PSB2YWwpIHtcclxuICAgICAgICAgICAgICAgIHRoaXMuX2N1ck1vZGFsID0gdGhpcy5fbmdiTW9kYWwub3Blbih0aGlzLmNvbnRlbnRSZWYpO1xyXG4gICAgICAgICAgICAgICAgLy8gY29uc29sZS5sb2codGhpcy5fY3VyTW9kYWwuY2xvc2UpO1xyXG4gICAgICAgICAgICAgICAgLy8gY29uc29sZS5sb2coJ2FtIGkgbW9kYWwgbG9hZGVkJywgdmFsKTtcclxuICAgICAgICAgICAgICAgIC8vIGlmICh0eXBlb2YgdGhpcy5jb25maWcuaWQgPT09ICd1bmRlZmluZWQnKSB0aGlzLm9wZW4odGhpcy5jb250ZW50UmVmKTtcclxuICAgICAgICAgICAgICAgIC8vIGVsc2UgaWYgKHZhbCA9PT0gdGhpcy5jb25maWcuaWQpIHRoaXMub3Blbih0aGlzLmNvbnRlbnRSZWYpO1xyXG4gICAgICAgICAgICAgICAgdGhpcy5fY3VyTW9kYWwucmVzdWx0LnRoZW4oKF9yZXN1bHQpOiB2b2lkID0+IHtcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLmNsb3NlUmVzdWx0ID0gYENsb3NlZCB3aXRoOiAke19yZXN1bHR9YDtcclxuICAgICAgICAgICAgICAgICAgICAvLyBjb25zb2xlLmxvZygnX3Jlc3VsdCA6ICcsIHRoaXMuY2xvc2VSZXN1bHQpO1xyXG4gICAgICAgICAgICAgICAgfSwgKF9yZWFzb24pOiB2b2lkID0+IHtcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLmNsb3NlUmVzdWx0ID0gYERpc21pc3NlZCAke3RoaXMuX2dldERpc21pc3NSZWFzb24oX3JlYXNvbil9YDtcclxuICAgICAgICAgICAgICAgICAgICAvLyBjb25zb2xlLmxvZygnX3JlYXNvbiA6ICcsIHRoaXMuY2xvc2VSZXN1bHQpO1xyXG4gICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9KTtcclxuXHJcbiAgICAgICAgdGhpcy5fbW9kYWxDbG9zZVN1YiA9IHRoaXMuX21vZGFsRXZlbnQub25Ub2dnbGVDbG9zZSgpLnN1YnNjcmliZSh2YWwgPT4ge1xyXG4gICAgICAgICAgICBpZiAodHlwZW9mIHZhbCA9PT0gJ3VuZGVmaW5lZCcgfHwgdGhpcy5jb25maWcuaWQgPT09IHZhbCkge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5fY3VyTW9kYWwuY2xvc2UoKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH0pO1xyXG4gICAgfVxyXG5cclxuICAgIG5nT25DaGFuZ2VzKCk6IHZvaWQge1xyXG4gICAgICAgIHRoaXMuZGVmYXVsdENvbmZpZygpO1xyXG4gICAgfVxyXG5cclxuICAgIG5nT25EZXN0cm95KCk6IHZvaWQge1xyXG4gICAgICAgIHRoaXMuX21vZGFsT3BlblN1Yi51bnN1YnNjcmliZSgpO1xyXG4gICAgfVxyXG5cclxuICAgIGRlZmF1bHRDb25maWcoKSB7XHJcbiAgICAgICAgaWYgKHR5cGVvZiB0aGlzLmNvbmZpZyAhPT0gJ3VuZGVmaW5lZCcpIHtcclxuICAgICAgICAgICAgdGhpcy5fbW9kYWxEZWZhdWx0ID0gdGhpcy5jb25maWc7XHJcbiAgICAgICAgICAgIGlmICh0eXBlb2YgdGhpcy5fbW9kYWxEZWZhdWx0LmJ1dHRvbiAhPT0gJ3VuZGVmaW5lZCcpIHtcclxuICAgICAgICAgICAgICAgIGZvciAobGV0IGk6IG51bWJlciA9IDA7IGkgPCB0aGlzLl9tb2RhbERlZmF1bHQuYnV0dG9uLmxlbmd0aDsgaSsrKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKHR5cGVvZiB0aGlzLmNvbmZpZyAhPT0gJ3VuZGVmaW5lZCcpIHRoaXMuX21vZGFsRGVmYXVsdC5idXR0b25baV0gPSB0aGlzLmNvbmZpZy5idXR0b25baV07XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgaWYgKHR5cGVvZiB0aGlzLmNvbmZpZy5ib2R5ICE9PSAndW5kZWZpbmVkJyAmJiB0aGlzLmNvbmZpZy5ib2R5ICE9PSAnJykgdGhpcy5faXNCb2R5RXhpc3QgPSB0cnVlO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICBwdWJsaWMgY2FsbGJhY2soZXZlbnQ6IGFueSwgYnRuOiBhbnkpOiB2b2lkIHtcclxuICAgICAgICBpZiAodHlwZW9mIGJ0bi5jYWxsYmFjayA9PT0gJ2Z1bmN0aW9uJykgYnRuLmNhbGxiYWNrKGV2ZW50LCBidG4pO1xyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX2dldERpc21pc3NSZWFzb24ocmVhc29uOiBhbnkpOiBzdHJpbmcge1xyXG4gICAgICAgIGlmIChyZWFzb24gPT09IE1vZGFsRGlzbWlzc1JlYXNvbnMuRVNDKSByZXR1cm4gJ2J5IHByZXNzaW5nIEVTQyc7XHJcbiAgICAgICAgZWxzZSBpZiAocmVhc29uID09PSBNb2RhbERpc21pc3NSZWFzb25zLkJBQ0tEUk9QX0NMSUNLKSByZXR1cm4gJ2J5IGNsaWNraW5nIG9uIGEgYmFja2Ryb3AnO1xyXG4gICAgICAgIGVsc2UgcmV0dXJuIGB3aXRoOiAke3JlYXNvbn1gO1xyXG4gICAgfVxyXG59XHJcbiJdfQ==