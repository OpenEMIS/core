import { Component, Input, Output, EventEmitter, ViewChildren, ElementRef } from '@angular/core';
import { timer } from 'rxjs';
import { KdInput } from '../kd-angular-input/kd-angular-input';
import { KdInputControlService } from '../kd-angular-input/src/kd-angular-form.control';
import { KdFormEvent } from './src/kd-form-event';
import { KdDomElemSvc, KdConvertionSvc } from '../kd-common/index';
import { KdViewSvc } from './kd-angular-view-svc';
export class KdView {
    constructor(_dfControl, _formEvent, _domSvc, _kdViewSvc, _convertSvc, _elementRef) {
        this._dfControl = _dfControl;
        this._formEvent = _formEvent;
        this._domSvc = _domSvc;
        this._kdViewSvc = _kdViewSvc;
        this._convertSvc = _convertSvc;
        this._elementRef = _elementRef;
        this._dfQuestions = [];
        this._formBtn = [];
        this._firstLoad = true;
        this.detectFrom = new EventEmitter();
        this.detectGridQuestion = new EventEmitter();
        this.submitEvent = new EventEmitter();
        this.resetEvent = new EventEmitter();
        this.buttonEvent = new EventEmitter();
        this.gridCellChanged = new EventEmitter();
        this.gridButtonClicked = new EventEmitter();
    }
    ngOnInit() {
        this._displayType = this.displayType; // (typeof this.displayType !== 'undefined') ? this.displayType : 'view';
        this.isStackedFrom = this._displayType === 'stacked-form';
        this._setQuestions();
        this._setButtons();
        this._updateFormApi();
        this._formVisibleSub = this._formEvent.onSetVisiableInput().subscribe(val => {
            for (let i = 0; i < this._dfQuestions.length; i++) {
                if (this._dfQuestions[i].key === val.key) {
                    this._dfQuestions[i].setVisible(val.visible);
                    break;
                }
            }
        });
        this._formDropdownSub = this._formEvent.onSetDropdownList().subscribe(val => {
            for (let i = 0; i < this._dfQuestions.length; i++) {
                if (this._dfQuestions[i].key === val.key) {
                    this._dfQuestions[i].setOptions(val.options);
                    break;
                }
            }
        });
        this._firstLoad = false;
        // console.log('KdView - this is the view just initialized', this.inputData);
    }
    ngOnChanges() {
        if (!this._firstLoad) {
            // console.log('KdView - this is the view change event', this.inputData);
            this._displayType = (typeof this.displayType !== 'undefined') ? this.displayType : 'view';
            this._setQuestions();
            this._setButtons();
        }
    }
    ngOnDestroy() {
        if (this._formVisibleSub)
            this._formVisibleSub.unsubscribe();
        if (this._formDropdownSub)
            this._formDropdownSub.unsubscribe();
    }
    getInputProperty(key, propertyName) {
        for (let i = 0; i < this._dfQuestions.length; i++) {
            if (this._dfQuestions[i].getProperty('key') === key)
                return this._dfQuestions[i].getProperty(propertyName);
        }
    }
    setInputProperty(key, propertyName, data) {
        for (let i = 0; i < this._dfQuestions.length; i++) {
            if (this._dfQuestions[i].getProperty('key') === key) {
                if (propertyName !== 'visible') {
                    this._dfQuestions[i].setProperty(propertyName, data);
                }
                else {
                    this._dfQuestions[i].setVisible(data);
                }
                break;
            }
        }
    }
    resetGridHeight(_gridId) {
        this.inputComponent.forEach((item) => {
            if (_gridId === item.question.getProperty('key')) {
                item.resetHeight();
            }
        });
    }
    ///// Table controltype
    updateTableCell(_questionKey, _cellParams) {
        this.inputComponent.forEach((item) => {
            if (_questionKey === item.question.getProperty('key')) {
                item.setTableCellData(_cellParams);
            }
        });
    }
    updateTableCellProperty(_questionKey, _cellParams) {
        this.inputComponent.forEach((item) => {
            if (_questionKey === item.question.getProperty('key')) {
                item.setTableCellQuestionProperty(_cellParams);
            }
        });
    }
    //////// till here
    setButtonDisabled(_type, _disabled) {
        for (let i = 0; i < this._formBtn.length; i++) {
            if (_type === this._formBtn[i].type) {
                this._formBtn[i].disabled = _disabled;
                this._formBtn = this._formBtn.slice();
            }
        }
    }
    isFormOrStackedForm() {
        if (this._displayType === 'form' || this._displayType === 'stacked-form') {
            return this._displayType;
        }
        else {
            return '-';
        }
    }
    // change to public due to lint
    changeDetectForm(_question) {
        this.detectFrom.emit(_question);
    }
    // change to public due to lint
    changeDetectFromGrid(_gridCellQuestion) {
        this.detectGridQuestion.emit(_gridCellQuestion);
    }
    /************************ Dynamic Form API updates *************************/
    _updateFormApi() {
        if (typeof this.api === 'undefined') {
            console.warn('KdView warning: No api object is passed in. No API will be initialize');
            return;
        }
        this.api.submitForm = () => {
            this._submitClick();
        };
        this.api.setProperty = (_questionKey, _property, _data) => {
            for (let i = 0; i < this._dfQuestions.length; i++) {
                if (this._dfQuestions[i].getProperty('key') === _questionKey) {
                    this._dfQuestions[i].setProperty(_property, _data);
                    break;
                }
            }
        };
        this.api.getProperty = (_questionKey, _property) => {
            for (let i = 0; i < this._dfQuestions.length; i++) {
                if (this._dfQuestions[i].getProperty('key') === _questionKey) {
                    return this._dfQuestions[i].getProperty(_property);
                }
            }
        };
        this.api.table = (_questionKey) => {
            let tableApi;
            for (let i = 0; i < this._dfQuestions.length; ++i) {
                if (this._dfQuestions[i].getProperty('key') === _questionKey) {
                    tableApi = this._dfQuestions[i].getProperty('api');
                    break;
                }
            }
            return {
                setTableCellInputProperty: (_formParams) => {
                    tableApi.dynamicForm.setProperty(_formParams);
                },
                updateTableCellProperty: (_cellParams) => {
                    tableApi.general.updateCell(_cellParams);
                },
                getTableCellInputProperty: (_formParams) => {
                    tableApi.dynamicForm.getProperty(_formParams);
                },
                addRow: (_rows, _scrollToVisible = false) => {
                    tableApi.general.addRows(_rows, _scrollToVisible);
                },
                deleteRows: (_id) => {
                    tableApi.general.deleteRows(_id);
                },
                clearError: () => {
                    tableApi.dynamicForm.clearAllError();
                },
                setButtonDisabled: (_buttonType, _toDisabled) => {
                    tableApi.general.setButtonDisabled(_buttonType, _toDisabled);
                }
            };
        };
        this.api.treedropdown = (_questionKey) => {
            let treeApi;
            for (let i = 0; i < this._dfQuestions.length; ++i) {
                if (this._dfQuestions[i].getProperty('key') === _questionKey) {
                    treeApi = this._dfQuestions[i].getProperty('api');
                    break;
                }
            }
            return treeApi;
        };
        this.api.sliderApi = (_questionKey) => {
            let sliderApi;
            for (let i = 0; i < this._dfQuestions.length; ++i) {
                if (this._dfQuestions[i].getProperty('key') === _questionKey) {
                    sliderApi = this._dfQuestions[i].getProperty('api');
                    break;
                }
            }
            return sliderApi;
        };
    }
    _btnClick(_btn) {
        if (_btn.type === 'reset')
            this._resetForm();
        else if (_btn.type !== 'submit')
            this.buttonEvent.emit(_btn);
        // if(typeof _btn.callback === 'function') _btn.callback(this._form.value);
        // else if(typeof _btn.callback === 'undefined' && _btn.type !== 'submit') console.error('Please provide callback');
    }
    _resetError() {
        for (let i = 0; i < this._dfQuestions.length; ++i) {
            this._dfQuestions[i].setProperty('errors', []);
        }
    }
    _getFormValidationError() {
        for (let i = 0; i < this._dfQuestions.length; ++i) {
            this._dfQuestions[i].setProperty('errors', []);
            let errorArr = [];
            const errors = this._form.get(this._dfQuestions[i].getProperty('key')).errors;
            if (errors !== null) {
                for (let key in errors) {
                    if (errors.hasOwnProperty(key)) {
                        errorArr.push(errors[key]);
                    }
                }
                this._dfQuestions[i].setProperty('errors', errorArr);
            }
        }
    }
    _submitClick() {
        let updatedForm = this._updateFormValue(this._dfQuestions, this._form.value);
        if (this._form.valid) {
            this.submitEvent.emit(updatedForm);
            this._resetError();
        }
        else {
            this._getFormValidationError();
        }
    }
    // private _submitClick(): void {
    //     let updatedForm: any = this._updateFormValue(this._dfQuestions, this._form.value);
    //     this.submitEvent.emit(updatedForm);
    // }
    _resetForm() {
        this._setQuestions();
        let contentBody = (this._domSvc.isMobile()) ? document.body.querySelector('.main-wrapper') : document.body.querySelector('.content-area');
        contentBody.scrollTop = 0;
        this.resetEvent.emit();
    }
    _setQuestions() {
        this._form = this._dfControl.emptyFormGroup();
        timer(50).subscribe(() => {
            this._dfQuestions = this._kdViewSvc.convertDataType(this.inputData, this._convertSvc);
            this._form = this._dfControl.toFormGroup(this._dfQuestions);
        });
    }
    _setButtons() {
        this._formBtn = (typeof this.button === 'undefined') ? this._setDefaultBtn() : this._setCustomBtn(this.button);
    }
    _setDefaultBtn() {
        let defaultBtn = [{
                type: 'submit',
                name: 'Submit',
                icon: 'kd-check',
                class: 'btn-text',
                disabled: false
            }, {
                type: 'reset',
                name: 'Reset',
                class: 'btn-outline',
                icon: 'kd-cross',
                disabled: false
            }];
        return defaultBtn;
    }
    _setCustomBtn(_btn) {
        let updatedBtn = [];
        let buttonLength = (this.button.length > 4) ? 4 : this.button.length;
        for (let i = 0; i < buttonLength; i++) {
            let item = _btn[i];
            if (typeof item.name === 'undefined')
                item.name = 'Undefined';
            if (typeof item.class === 'undefined')
                item.class = 'btn btn-text';
            if (typeof item.type === 'undefined')
                item.type = 'button';
            if (typeof item.disabled === 'undefined')
                item.disabled = false;
            if (item.type === 'reset') {
                item.callback = () => {
                    this._resetForm();
                };
            }
            updatedBtn.push(item);
        }
        return updatedBtn;
    }
    _updateFormValue(_question, _formValue) {
        let updatedFormVal = Object.assign({}, _formValue);
        for (let i = 0; i < _question.length; i++) {
            if (_question[i].controlType === 'section' && updatedFormVal && typeof updatedFormVal[_question[i].key] !== 'undefined') {
                delete updatedFormVal[_question[i].key];
            }
            else if (typeof _question[i].disabled !== 'undefined' && _question[i].disabled) {
                delete updatedFormVal[_question[i].key];
            }
        }
        return updatedFormVal;
    }
    /// table controltype
    _gridCellValueChanged(_emitParams) {
        this.gridCellChanged.emit(_emitParams);
    }
    _gridButtonClicked(_emitParams) {
        this.gridButtonClicked.emit(_emitParams);
    }
}
KdView.decorators = [
    { type: Component, args: [{
                selector: 'kd-view',
                template: "<div class='section-header'>{{_displayType}}</div>\r\n<ng-container [ngSwitch]=\"_displayType\">\r\n\r\n    <ng-container *ngSwitchCase=\"isFormOrStackedForm()\" >\r\n        <form class=\"form-vertical kdx\" [class.stacked]='isStackedFrom' *ngIf=\"_dfQuestions.length>0\" [formGroup]=\"_form\" (ngSubmit)=\"_submitClick()\">\r\n            <div *ngFor=\"let question of _dfQuestions\" class=\"form-row\" [class.section-header]=\"question.controlType == 'section'\">\r\n\r\n                <kd-input \r\n                    [question]=\"question\" \r\n                    [form]=\"_form\" \r\n                    (changeDetectFromQuestion)=\"changeDetectForm($event)\" \r\n                    (changeDetectFromGrid)=\"changeDetectFromGrid($event)\" \r\n                    (gridCellValueChanged)=\"_gridCellValueChanged($event)\"\r\n                    (gridButtonClicked)=\"_gridButtonClicked($event)\"\r\n                ></kd-input>\r\n            </div>\r\n            <div *ngIf=\"_formBtn.length>0\" class=\"form-buttons\">\r\n                <div class=\"button-label\"></div>\r\n                <button *ngFor=\"let btn of _formBtn\" [type]=\"(btn.type=='submit')?'submit':'button'\" class=\"btn btn-icon\" [ngClass]=\"btn.class\" (click)=\"_btnClick(btn)\" [disabled]=\"btn.disabled\">\r\n                    <i [class]=\"btn.icon\"></i>\r\n                    <span>{{btn.name}}</span>\r\n                </button>\r\n            </div>\r\n        </form>\r\n    </ng-container>\r\n\r\n    <ng-container *ngSwitchCase=\"'horizontal-form'\">\r\n        <div *ngIf=\"_dfQuestions.length>0\" class=\"form-horizontal-wrapper\">\r\n            <form class=\"form-horizontal\" [formGroup]=\"_form\">\r\n                <div *ngFor=\"let question of _dfQuestions\" class=\"form-row\">\r\n                    <kd-input [question]=\"question\" [form]=\"_form\" [horizontal]=\"true\" (changeDetectFromQuestion)=\"changeDetectForm($event)\"></kd-input>\r\n                </div>\r\n            </form>\r\n        </div>\r\n    </ng-container>\r\n\r\n    <ng-container *ngSwitchDefault> \r\n        <!-- View -->\r\n        <div [ngClass]=\"item.controlType!='section' ? 'kdx-view-list':'section-header' \" *ngFor=\"let item of _dfQuestions\">\r\n    <!-- <div class=\"view-list\" *ngFor=\"let item of _dfQuestions\"> -->\r\n            <h6 *ngIf=\"item.controlType=='section'\" >{{item.label}}</h6>\r\n            \r\n            <div *ngIf=\"item.visible && item.controlType!='section'\">\r\n                <div class=\"kdx-view-label\">{{item.label}}</div>\r\n                <div class=\"view-data\"  [ngSwitch]=\"item.controlType\">\r\n                    <div *ngSwitchCase=\"'file-input'\">\r\n                        <kd-placeholder \r\n                            *ngIf=\"item.config.fileType == 'image' && item.config.preview\"\r\n                            [config]='item.config.imageConfig'\r\n                            [value]='item.value'\r\n                        ></kd-placeholder>\r\n                        <div *ngIf=\"item.config.fileType != 'image' || !item.config.preview\">\r\n                            <a [href]=\"item.value.src\" style=\"text-decoration: none;\" placement=\"right\" ngbTooltip=\"Download\" container=\"body\" target=\"_blank\"> \r\n                                <i class=\"fa fa-paperclip\"></i>\r\n                                {{item.value.filename}}\r\n                            </a>\r\n                        </div>\r\n                    </div>\r\n                    <div *ngSwitchCase=\"'table'\" class=\"kdx-input-table-wrapper\">\r\n                        <kd-table [config]='item.config' [row]='item.row' [column]='item.column'></kd-table>\r\n                    </div>\r\n                    <div *ngSwitchCase=\"'symbol'\">\r\n                        <i [ngClass]=\"item.value\"></i>\r\n                    </div>\r\n                    <div *ngSwitchDefault [class]=\"item.class\">{{item.value}}</div>\r\n                    <i [class]=\"item.class\"></i>\r\n                </div>\r\n            </div>\r\n        </div>\r\n    </ng-container>\r\n\r\n</ng-container>\r\n\r\n<!-- \r\n<div *ngIf=\"_displayType!='form' && _displayType !='horizontal-form'\">\r\n    <div [ngClass]=\"item.controlType!='section' ? 'kdx-view-list':'section-header' \" *ngFor=\"let item of _dfQuestions\">\r\n        <h6 *ngIf=\"item.controlType=='section'\" >{{item.label}}</h6>\r\n        \r\n        <div *ngIf=\"item.visible && item.controlType!='section'\">\r\n            <div class=\"kdx-view-label\">{{item.label}}</div>\r\n            <div class=\"view-data\"  [ngSwitch]=\"item.controlType\">\r\n                <div *ngSwitchCase=\"'file-input'\">\r\n                    <kd-placeholder \r\n                        *ngIf=\"item.config.fileType == 'image' && item.config.preview\"\r\n                        [config]='item.config.imageConfig'\r\n                        [value]='item.value'\r\n                    ></kd-placeholder>\r\n                    <div *ngIf=\"item.config.fileType != 'image' || !item.config.preview\">\r\n                        <a [href]=\"item.value.src\" style=\"text-decoration: none;\" placement=\"right\" ngbTooltip=\"Download\" container=\"body\" target=\"_blank\"> \r\n                            <i class=\"fa fa-paperclip\"></i>\r\n                            {{item.value.filename}}\r\n                        </a>\r\n                    </div>\r\n                </div>\r\n                <div *ngSwitchCase=\"'table'\" class=\"kdx-input-table-wrapper\">\r\n                    <kd-table [config]='item.config' [row]='item.row' [column]='item.column'></kd-table>\r\n                </div>\r\n                <div *ngSwitchCase=\"'symbol'\">\r\n                    <i [ngClass]=\"item.value\"></i>\r\n                </div>\r\n                <div *ngSwitchDefault [class]=\"item.class\">{{item.value}}</div>\r\n                <i [class]=\"item.class\"></i>\r\n            </div>\r\n        </div>\r\n    </div>\r\n</div>\r\n\r\n<form class=\"form-vertical kdx\" *ngIf=\"_displayType=='form' && _dfQuestions.length>0\" [formGroup]=\"_form\" (ngSubmit)=\"_submitClick()\">\r\n    <div *ngFor=\"let question of _dfQuestions\" class=\"form-row\" [class.section-header]=\"question.controlType == 'section'\">\r\n\r\n        <kd-input \r\n            [question]=\"question\" \r\n            [form]=\"_form\" \r\n            (changeDetectFromQuestion)=\"changeDetectForm($event)\" \r\n            (changeDetectFromGrid)=\"changeDetectFromGrid($event)\" \r\n            (gridCellValueChanged)=\"_gridCellValueChanged($event)\"\r\n            (gridButtonClicked)=\"_gridButtonClicked($event)\"\r\n        ></kd-input>\r\n    </div>\r\n    <div *ngIf=\"_formBtn.length>0\" class=\"form-buttons\">\r\n        <div class=\"button-label\"></div>\r\n        <button *ngFor=\"let btn of _formBtn\" [type]=\"(btn.type=='submit')?'submit':'button'\" class=\"btn btn-icon\" [ngClass]=\"btn.class\" (click)=\"_btnClick(btn)\" [disabled]=\"btn.disabled\">\r\n            <i [class]=\"btn.icon\"></i>\r\n            <span>{{btn.name}}</span>\r\n        </button>\r\n    </div>\r\n</form>\r\n\r\n<div *ngIf=\"_displayType=='horizontal-form' && _dfQuestions.length>0\" class=\"form-horizontal-wrapper\">\r\n    <form class=\"form-horizontal\" [formGroup]=\"_form\">\r\n        <div *ngFor=\"let question of _dfQuestions\" class=\"form-row\">\r\n            <kd-input [question]=\"question\" [form]=\"_form\" [horizontal]=\"true\" (changeDetectFromQuestion)=\"changeDetectForm($event)\"></kd-input>\r\n        </div>\r\n    </form>\r\n</div>\r\n -->",
                providers: [KdInputControlService, KdFormEvent, KdDomElemSvc, KdViewSvc, KdConvertionSvc],
                host: {
                    'class': 'kdx-view'
                }
            },] }
];
KdView.ctorParameters = () => [
    { type: KdInputControlService },
    { type: KdFormEvent },
    { type: KdDomElemSvc },
    { type: KdViewSvc },
    { type: KdConvertionSvc },
    { type: ElementRef }
];
KdView.propDecorators = {
    inputData: [{ type: Input }],
    button: [{ type: Input }],
    displayType: [{ type: Input }],
    api: [{ type: Input }],
    detectFrom: [{ type: Output }],
    detectGridQuestion: [{ type: Output }],
    submitEvent: [{ type: Output }],
    resetEvent: [{ type: Output }],
    buttonEvent: [{ type: Output }],
    inputComponent: [{ type: ViewChildren, args: [KdInput,] }],
    gridCellChanged: [{ type: Output }],
    gridButtonClicked: [{ type: Output }]
};
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoia2QtYW5ndWxhci12aWV3LmpzIiwic291cmNlUm9vdCI6IkQ6L29wZW5FTUlTL3N0eWxlZ3VpZGUvaW9zdGctb3BlbmVtaXMtc3R5bGVndWlkZS9wcm9qZWN0cy9vcGVuZW1pcy1zdHlsZWd1aWRlLWxpYi9zcmMvIiwic291cmNlcyI6WyJrZC1jb21wb25lbnRzL2tkLWFuZ3VsYXItdmlldy9rZC1hbmd1bGFyLXZpZXcudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsT0FBTyxFQUNILFNBQVMsRUFDVCxLQUFLLEVBQ0wsTUFBTSxFQUNOLFlBQVksRUFJWixZQUFZLEVBQ1osVUFBVSxFQUNiLE1BQU0sZUFBZSxDQUFDO0FBQ3ZCLE9BQU8sRUFBRSxLQUFLLEVBQWtCLE1BQU0sTUFBTSxDQUFDO0FBRTdDLE9BQU8sRUFBRSxPQUFPLEVBQUUsTUFBTSxzQ0FBc0MsQ0FBQztBQUUvRCxPQUFPLEVBQUUscUJBQXFCLEVBQUUsTUFBTSxpREFBaUQsQ0FBQztBQUN4RixPQUFPLEVBQUUsV0FBVyxFQUFFLE1BQU0scUJBQXFCLENBQUM7QUFDbEQsT0FBTyxFQUFFLFlBQVksRUFBRSxlQUFlLEVBQUUsTUFBTSxvQkFBb0IsQ0FBQztBQUNuRSxPQUFPLEVBQUUsU0FBUyxFQUFFLE1BQU0sdUJBQXVCLENBQUM7QUF1QmxELE1BQU0sT0FBTyxNQUFNO0lBeUJmLFlBQ1ksVUFBaUMsRUFDakMsVUFBdUIsRUFDdkIsT0FBcUIsRUFDckIsVUFBcUIsRUFDckIsV0FBNEIsRUFDNUIsV0FBdUI7UUFMdkIsZUFBVSxHQUFWLFVBQVUsQ0FBdUI7UUFDakMsZUFBVSxHQUFWLFVBQVUsQ0FBYTtRQUN2QixZQUFPLEdBQVAsT0FBTyxDQUFjO1FBQ3JCLGVBQVUsR0FBVixVQUFVLENBQVc7UUFDckIsZ0JBQVcsR0FBWCxXQUFXLENBQWlCO1FBQzVCLGdCQUFXLEdBQVgsV0FBVyxDQUFZO1FBOUI1QixpQkFBWSxHQUFlLEVBQUUsQ0FBQztRQUs5QixhQUFRLEdBQWUsRUFBRSxDQUFDO1FBQ3pCLGVBQVUsR0FBWSxJQUFJLENBQUM7UUFRekIsZUFBVSxHQUFzQixJQUFJLFlBQVksRUFBRSxDQUFDO1FBQ25ELHVCQUFrQixHQUFzQixJQUFJLFlBQVksRUFBRSxDQUFDO1FBQzNELGdCQUFXLEdBQXNCLElBQUksWUFBWSxFQUFFLENBQUM7UUFDcEQsZUFBVSxHQUFzQixJQUFJLFlBQVksRUFBRSxDQUFDO1FBQ25ELGdCQUFXLEdBQXNCLElBQUksWUFBWSxFQUFFLENBQUM7UUFHcEQsb0JBQWUsR0FBdUUsSUFBSSxZQUFZLEVBQUUsQ0FBQztRQUN6RyxzQkFBaUIsR0FBa0UsSUFBSSxZQUFZLEVBQUUsQ0FBQztJQVM1RyxDQUFDO0lBRUwsUUFBUTtRQUVKLElBQUksQ0FBQyxZQUFZLEdBQUcsSUFBSSxDQUFDLFdBQVcsQ0FBQyxDQUFDLHlFQUF5RTtRQUMvRyxJQUFJLENBQUMsYUFBYSxHQUFHLElBQUksQ0FBQyxZQUFZLEtBQUssY0FBYyxDQUFDO1FBRTFELElBQUksQ0FBQyxhQUFhLEVBQUUsQ0FBQztRQUNyQixJQUFJLENBQUMsV0FBVyxFQUFFLENBQUM7UUFDbkIsSUFBSSxDQUFDLGNBQWMsRUFBRSxDQUFDO1FBRXRCLElBQUksQ0FBQyxlQUFlLEdBQUcsSUFBSSxDQUFDLFVBQVUsQ0FBQyxrQkFBa0IsRUFBRSxDQUFDLFNBQVMsQ0FBQyxHQUFHLENBQUMsRUFBRTtZQUN4RSxLQUFLLElBQUksQ0FBQyxHQUFXLENBQUMsRUFBRSxDQUFDLEdBQUcsSUFBSSxDQUFDLFlBQVksQ0FBQyxNQUFNLEVBQUUsQ0FBQyxFQUFFLEVBQUU7Z0JBQ3ZELElBQUksSUFBSSxDQUFDLFlBQVksQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLEtBQUssR0FBRyxDQUFDLEdBQUcsRUFBRTtvQkFDdEMsSUFBSSxDQUFDLFlBQVksQ0FBQyxDQUFDLENBQUMsQ0FBQyxVQUFVLENBQUMsR0FBRyxDQUFDLE9BQU8sQ0FBQyxDQUFDO29CQUM3QyxNQUFNO2lCQUNUO2FBQ0o7UUFDTCxDQUFDLENBQUMsQ0FBQztRQUVILElBQUksQ0FBQyxnQkFBZ0IsR0FBRyxJQUFJLENBQUMsVUFBVSxDQUFDLGlCQUFpQixFQUFFLENBQUMsU0FBUyxDQUFDLEdBQUcsQ0FBQyxFQUFFO1lBQ3hFLEtBQUssSUFBSSxDQUFDLEdBQVcsQ0FBQyxFQUFFLENBQUMsR0FBRyxJQUFJLENBQUMsWUFBWSxDQUFDLE1BQU0sRUFBRSxDQUFDLEVBQUUsRUFBRTtnQkFDdkQsSUFBSSxJQUFJLENBQUMsWUFBWSxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsS0FBSyxHQUFHLENBQUMsR0FBRyxFQUFFO29CQUN0QyxJQUFJLENBQUMsWUFBWSxDQUFDLENBQUMsQ0FBQyxDQUFDLFVBQVUsQ0FBQyxHQUFHLENBQUMsT0FBTyxDQUFDLENBQUM7b0JBQzdDLE1BQU07aUJBQ1Q7YUFDSjtRQUNMLENBQUMsQ0FBQyxDQUFDO1FBRUgsSUFBSSxDQUFDLFVBQVUsR0FBRyxLQUFLLENBQUM7UUFDeEIsNkVBQTZFO0lBQ2pGLENBQUM7SUFFRCxXQUFXO1FBQ1AsSUFBSSxDQUFDLElBQUksQ0FBQyxVQUFVLEVBQUU7WUFDbEIseUVBQXlFO1lBQ3pFLElBQUksQ0FBQyxZQUFZLEdBQUcsQ0FBQyxPQUFPLElBQUksQ0FBQyxXQUFXLEtBQUssV0FBVyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQztZQUMxRixJQUFJLENBQUMsYUFBYSxFQUFFLENBQUM7WUFDckIsSUFBSSxDQUFDLFdBQVcsRUFBRSxDQUFDO1NBQ3RCO0lBQ0wsQ0FBQztJQUVELFdBQVc7UUFDUCxJQUFHLElBQUksQ0FBQyxlQUFlO1lBQUUsSUFBSSxDQUFDLGVBQWUsQ0FBQyxXQUFXLEVBQUUsQ0FBQztRQUM1RCxJQUFHLElBQUksQ0FBQyxnQkFBZ0I7WUFBRSxJQUFJLENBQUMsZ0JBQWdCLENBQUMsV0FBVyxFQUFFLENBQUM7SUFDbEUsQ0FBQztJQUVNLGdCQUFnQixDQUFDLEdBQVcsRUFBRSxZQUFvQjtRQUNyRCxLQUFLLElBQUksQ0FBQyxHQUFXLENBQUMsRUFBRSxDQUFDLEdBQUcsSUFBSSxDQUFDLFlBQVksQ0FBQyxNQUFNLEVBQUUsQ0FBQyxFQUFFLEVBQUU7WUFDdkQsSUFBSSxJQUFJLENBQUMsWUFBWSxDQUFDLENBQUMsQ0FBQyxDQUFDLFdBQVcsQ0FBQyxLQUFLLENBQUMsS0FBSyxHQUFHO2dCQUFFLE9BQU8sSUFBSSxDQUFDLFlBQVksQ0FBQyxDQUFDLENBQUMsQ0FBQyxXQUFXLENBQUMsWUFBWSxDQUFDLENBQUM7U0FDOUc7SUFDTCxDQUFDO0lBRU0sZ0JBQWdCLENBQUMsR0FBVyxFQUFFLFlBQW9CLEVBQUUsSUFBUztRQUNoRSxLQUFLLElBQUksQ0FBQyxHQUFXLENBQUMsRUFBRSxDQUFDLEdBQUcsSUFBSSxDQUFDLFlBQVksQ0FBQyxNQUFNLEVBQUUsQ0FBQyxFQUFFLEVBQUU7WUFDdkQsSUFBSSxJQUFJLENBQUMsWUFBWSxDQUFDLENBQUMsQ0FBQyxDQUFDLFdBQVcsQ0FBQyxLQUFLLENBQUMsS0FBSyxHQUFHLEVBQUU7Z0JBQ2pELElBQUksWUFBWSxLQUFLLFNBQVMsRUFBRTtvQkFDNUIsSUFBSSxDQUFDLFlBQVksQ0FBQyxDQUFDLENBQUMsQ0FBQyxXQUFXLENBQUMsWUFBWSxFQUFFLElBQUksQ0FBQyxDQUFDO2lCQUN4RDtxQkFDSTtvQkFDRCxJQUFJLENBQUMsWUFBWSxDQUFDLENBQUMsQ0FBQyxDQUFDLFVBQVUsQ0FBQyxJQUFJLENBQUMsQ0FBQztpQkFDekM7Z0JBQ0QsTUFBTTthQUNUO1NBQ0o7SUFDTCxDQUFDO0lBRU0sZUFBZSxDQUFDLE9BQWU7UUFDbEMsSUFBSSxDQUFDLGNBQWMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxJQUFhLEVBQVEsRUFBRTtZQUNoRCxJQUFJLE9BQU8sS0FBSyxJQUFJLENBQUMsUUFBUSxDQUFDLFdBQVcsQ0FBQyxLQUFLLENBQUMsRUFBRTtnQkFDOUMsSUFBSSxDQUFDLFdBQVcsRUFBRSxDQUFDO2FBQ3RCO1FBQ0wsQ0FBQyxDQUFDLENBQUM7SUFDUCxDQUFDO0lBRUQsdUJBQXVCO0lBQ2hCLGVBQWUsQ0FBQyxZQUFvQixFQUFFLFdBQTZCO1FBQ3RFLElBQUksQ0FBQyxjQUFjLENBQUMsT0FBTyxDQUFDLENBQUMsSUFBYSxFQUFRLEVBQUU7WUFDaEQsSUFBSSxZQUFZLEtBQUssSUFBSSxDQUFDLFFBQVEsQ0FBQyxXQUFXLENBQUMsS0FBSyxDQUFDLEVBQUU7Z0JBQ25ELElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxXQUFXLENBQUMsQ0FBQzthQUN0QztRQUNMLENBQUMsQ0FBQyxDQUFDO0lBQ1AsQ0FBQztJQUVNLHVCQUF1QixDQUFDLFlBQW9CLEVBQUUsV0FBbUM7UUFDcEYsSUFBSSxDQUFDLGNBQWMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxJQUFhLEVBQVEsRUFBRTtZQUNoRCxJQUFJLFlBQVksS0FBSyxJQUFJLENBQUMsUUFBUSxDQUFDLFdBQVcsQ0FBQyxLQUFLLENBQUMsRUFBRTtnQkFDbkQsSUFBSSxDQUFDLDRCQUE0QixDQUFDLFdBQVcsQ0FBQyxDQUFDO2FBQ2xEO1FBQ0wsQ0FBQyxDQUFDLENBQUM7SUFDUCxDQUFDO0lBQ0Qsa0JBQWtCO0lBRVgsaUJBQWlCLENBQUMsS0FBYSxFQUFFLFNBQWtCO1FBQ3RELEtBQUssSUFBSSxDQUFDLEdBQVcsQ0FBQyxFQUFFLENBQUMsR0FBRyxJQUFJLENBQUMsUUFBUSxDQUFDLE1BQU0sRUFBRSxDQUFDLEVBQUUsRUFBRTtZQUNuRCxJQUFJLEtBQUssS0FBSyxJQUFJLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksRUFBRTtnQkFDakMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLEdBQUcsU0FBUyxDQUFDO2dCQUN0QyxJQUFJLENBQUMsUUFBUSxHQUFHLElBQUksQ0FBQyxRQUFRLENBQUMsS0FBSyxFQUFFLENBQUM7YUFDekM7U0FDSjtJQUNMLENBQUM7SUFFTSxtQkFBbUI7UUFDdEIsSUFBSSxJQUFJLENBQUMsWUFBWSxLQUFLLE1BQU0sSUFBSSxJQUFJLENBQUMsWUFBWSxLQUFLLGNBQWMsRUFBRTtZQUN0RSxPQUFPLElBQUksQ0FBQyxZQUFZLENBQUM7U0FDNUI7YUFBTTtZQUNILE9BQU8sR0FBRyxDQUFDO1NBQ2Q7SUFDTCxDQUFDO0lBRUQsK0JBQStCO0lBQ3hCLGdCQUFnQixDQUFDLFNBQXlCO1FBQzdDLElBQUksQ0FBQyxVQUFVLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDO0lBQ3BDLENBQUM7SUFFRCwrQkFBK0I7SUFDeEIsb0JBQW9CLENBQUMsaUJBQXNCO1FBQzlDLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxJQUFJLENBQUMsaUJBQWlCLENBQUMsQ0FBQztJQUNwRCxDQUFDO0lBRUQsNkVBQTZFO0lBQ3JFLGNBQWM7UUFDbEIsSUFBSSxPQUFPLElBQUksQ0FBQyxHQUFHLEtBQUssV0FBVyxFQUFFO1lBQ2pDLE9BQU8sQ0FBQyxJQUFJLENBQUMsdUVBQXVFLENBQUMsQ0FBQztZQUN0RixPQUFPO1NBQ1Y7UUFFRCxJQUFJLENBQUMsR0FBRyxDQUFDLFVBQVUsR0FBRyxHQUFTLEVBQUU7WUFDN0IsSUFBSSxDQUFDLFlBQVksRUFBRSxDQUFDO1FBQ3hCLENBQUMsQ0FBQztRQUVGLElBQUksQ0FBQyxHQUFHLENBQUMsV0FBVyxHQUFHLENBQUMsWUFBb0IsRUFBRSxTQUFpQixFQUFFLEtBQVUsRUFBUSxFQUFFO1lBQ2pGLEtBQUssSUFBSSxDQUFDLEdBQVcsQ0FBQyxFQUFFLENBQUMsR0FBRyxJQUFJLENBQUMsWUFBWSxDQUFDLE1BQU0sRUFBRSxDQUFDLEVBQUUsRUFBRTtnQkFDdkQsSUFBSSxJQUFJLENBQUMsWUFBWSxDQUFDLENBQUMsQ0FBQyxDQUFDLFdBQVcsQ0FBQyxLQUFLLENBQUMsS0FBSyxZQUFZLEVBQUU7b0JBQzFELElBQUksQ0FBQyxZQUFZLENBQUMsQ0FBQyxDQUFDLENBQUMsV0FBVyxDQUFDLFNBQVMsRUFBRSxLQUFLLENBQUMsQ0FBQztvQkFDbkQsTUFBTTtpQkFDVDthQUNKO1FBQ0wsQ0FBQyxDQUFDO1FBRUYsSUFBSSxDQUFDLEdBQUcsQ0FBQyxXQUFXLEdBQUcsQ0FBQyxZQUFvQixFQUFFLFNBQWlCLEVBQU8sRUFBRTtZQUNwRSxLQUFLLElBQUksQ0FBQyxHQUFXLENBQUMsRUFBRSxDQUFDLEdBQUcsSUFBSSxDQUFDLFlBQVksQ0FBQyxNQUFNLEVBQUUsQ0FBQyxFQUFFLEVBQUU7Z0JBQ3ZELElBQUksSUFBSSxDQUFDLFlBQVksQ0FBQyxDQUFDLENBQUMsQ0FBQyxXQUFXLENBQUMsS0FBSyxDQUFDLEtBQUssWUFBWSxFQUFFO29CQUMxRCxPQUFPLElBQUksQ0FBQyxZQUFZLENBQUMsQ0FBQyxDQUFDLENBQUMsV0FBVyxDQUFDLFNBQVMsQ0FBQyxDQUFDO2lCQUN0RDthQUNKO1FBQ0wsQ0FBQyxDQUFDO1FBRUYsSUFBSSxDQUFDLEdBQUcsQ0FBQyxLQUFLLEdBQUcsQ0FBQyxZQUFvQixFQUF3QixFQUFFO1lBQzVELElBQUksUUFBbUIsQ0FBQztZQUV4QixLQUFLLElBQUksQ0FBQyxHQUFXLENBQUMsRUFBRSxDQUFDLEdBQUcsSUFBSSxDQUFDLFlBQVksQ0FBQyxNQUFNLEVBQUUsRUFBRSxDQUFDLEVBQUU7Z0JBQ3ZELElBQUksSUFBSSxDQUFDLFlBQVksQ0FBQyxDQUFDLENBQUMsQ0FBQyxXQUFXLENBQUMsS0FBSyxDQUFDLEtBQUssWUFBWSxFQUFFO29CQUMxRCxRQUFRLEdBQUcsSUFBSSxDQUFDLFlBQVksQ0FBQyxDQUFDLENBQUMsQ0FBQyxXQUFXLENBQUMsS0FBSyxDQUFDLENBQUM7b0JBQ25ELE1BQU07aUJBQ1Q7YUFDSjtZQUVELE9BQU87Z0JBQ0gseUJBQXlCLEVBQUUsQ0FBQyxXQUFtQyxFQUFRLEVBQUU7b0JBQ3JFLFFBQVEsQ0FBQyxXQUFXLENBQUMsV0FBVyxDQUFDLFdBQVcsQ0FBQyxDQUFDO2dCQUNsRCxDQUFDO2dCQUNELHVCQUF1QixFQUFFLENBQUMsV0FBNkIsRUFBUSxFQUFFO29CQUM3RCxRQUFRLENBQUMsT0FBTyxDQUFDLFVBQVUsQ0FBQyxXQUFXLENBQUMsQ0FBQztnQkFDN0MsQ0FBQztnQkFDRCx5QkFBeUIsRUFBRSxDQUFDLFdBQW1DLEVBQVEsRUFBRTtvQkFDckUsUUFBUSxDQUFDLFdBQVcsQ0FBQyxXQUFXLENBQUMsV0FBVyxDQUFDLENBQUM7Z0JBQ2xELENBQUM7Z0JBQ0QsTUFBTSxFQUFFLENBQUMsS0FBaUIsRUFBRSxtQkFBNEIsS0FBSyxFQUFRLEVBQUU7b0JBQ25FLFFBQVEsQ0FBQyxPQUFPLENBQUMsT0FBTyxDQUFDLEtBQUssRUFBRSxnQkFBZ0IsQ0FBQyxDQUFDO2dCQUN0RCxDQUFDO2dCQUNELFVBQVUsRUFBRSxDQUFDLEdBQTZDLEVBQVEsRUFBRTtvQkFDaEUsUUFBUSxDQUFDLE9BQU8sQ0FBQyxVQUFVLENBQUMsR0FBRyxDQUFDLENBQUM7Z0JBQ3JDLENBQUM7Z0JBQ0QsVUFBVSxFQUFFLEdBQVMsRUFBRTtvQkFDbkIsUUFBUSxDQUFDLFdBQVcsQ0FBQyxhQUFhLEVBQUUsQ0FBQztnQkFDekMsQ0FBQztnQkFDRCxpQkFBaUIsRUFBRSxDQUFDLFdBQW1CLEVBQUUsV0FBb0IsRUFBUSxFQUFFO29CQUNuRSxRQUFRLENBQUMsT0FBTyxDQUFDLGlCQUFpQixDQUFDLFdBQVcsRUFBRSxXQUFXLENBQUMsQ0FBQztnQkFDakUsQ0FBQzthQUNKLENBQUM7UUFDTixDQUFDLENBQUM7UUFFRixJQUFJLENBQUMsR0FBRyxDQUFDLFlBQVksR0FBRyxDQUFDLFlBQW9CLEVBQVksRUFBRTtZQUN2RCxJQUFJLE9BQWlCLENBQUM7WUFDdEIsS0FBSyxJQUFJLENBQUMsR0FBVyxDQUFDLEVBQUUsQ0FBQyxHQUFHLElBQUksQ0FBQyxZQUFZLENBQUMsTUFBTSxFQUFFLEVBQUUsQ0FBQyxFQUFFO2dCQUN2RCxJQUFJLElBQUksQ0FBQyxZQUFZLENBQUMsQ0FBQyxDQUFDLENBQUMsV0FBVyxDQUFDLEtBQUssQ0FBQyxLQUFLLFlBQVksRUFBRTtvQkFDMUQsT0FBTyxHQUFHLElBQUksQ0FBQyxZQUFZLENBQUMsQ0FBQyxDQUFDLENBQUMsV0FBVyxDQUFDLEtBQUssQ0FBQyxDQUFDO29CQUNsRCxNQUFNO2lCQUNUO2FBQ0o7WUFDRCxPQUFPLE9BQU8sQ0FBQztRQUNuQixDQUFDLENBQUM7UUFFRixJQUFJLENBQUMsR0FBRyxDQUFDLFNBQVMsR0FBRyxDQUFDLFlBQW9CLEVBQWMsRUFBRTtZQUN0RCxJQUFJLFNBQXFCLENBQUM7WUFFMUIsS0FBSyxJQUFJLENBQUMsR0FBVyxDQUFDLEVBQUUsQ0FBQyxHQUFHLElBQUksQ0FBQyxZQUFZLENBQUMsTUFBTSxFQUFFLEVBQUUsQ0FBQyxFQUFFO2dCQUN2RCxJQUFJLElBQUksQ0FBQyxZQUFZLENBQUMsQ0FBQyxDQUFDLENBQUMsV0FBVyxDQUFDLEtBQUssQ0FBQyxLQUFLLFlBQVksRUFBRTtvQkFDMUQsU0FBUyxHQUFHLElBQUksQ0FBQyxZQUFZLENBQUMsQ0FBQyxDQUFDLENBQUMsV0FBVyxDQUFDLEtBQUssQ0FBQyxDQUFDO29CQUNwRCxNQUFNO2lCQUNUO2FBQ0o7WUFFRCxPQUFPLFNBQVMsQ0FBQztRQUNyQixDQUFDLENBQUM7SUFDTixDQUFDO0lBR00sU0FBUyxDQUFDLElBQVM7UUFDdEIsSUFBSSxJQUFJLENBQUMsSUFBSSxLQUFLLE9BQU87WUFBRSxJQUFJLENBQUMsVUFBVSxFQUFFLENBQUM7YUFDeEMsSUFBSSxJQUFJLENBQUMsSUFBSSxLQUFLLFFBQVE7WUFBRSxJQUFJLENBQUMsV0FBVyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQztRQUM3RCwyRUFBMkU7UUFDM0Usb0hBQW9IO0lBQ3hILENBQUM7SUFFTyxXQUFXO1FBQ2YsS0FBSyxJQUFJLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxHQUFHLElBQUksQ0FBQyxZQUFZLENBQUMsTUFBTSxFQUFFLEVBQUUsQ0FBQyxFQUFFO1lBQy9DLElBQUksQ0FBQyxZQUFZLENBQUMsQ0FBQyxDQUFDLENBQUMsV0FBVyxDQUFDLFFBQVEsRUFBRSxFQUFFLENBQUMsQ0FBQztTQUNsRDtJQUNMLENBQUM7SUFFTyx1QkFBdUI7UUFDM0IsS0FBSyxJQUFJLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxHQUFHLElBQUksQ0FBQyxZQUFZLENBQUMsTUFBTSxFQUFFLEVBQUUsQ0FBQyxFQUFFO1lBQy9DLElBQUksQ0FBQyxZQUFZLENBQUMsQ0FBQyxDQUFDLENBQUMsV0FBVyxDQUFDLFFBQVEsRUFBRSxFQUFFLENBQUMsQ0FBQztZQUMvQyxJQUFJLFFBQVEsR0FBa0IsRUFBRSxDQUFDO1lBQ2pDLE1BQU0sTUFBTSxHQUFPLElBQUksQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxZQUFZLENBQUMsQ0FBQyxDQUFDLENBQUMsV0FBVyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDO1lBQ2xGLElBQUksTUFBTSxLQUFLLElBQUksRUFBRTtnQkFDakIsS0FBSyxJQUFJLEdBQUcsSUFBSSxNQUFNLEVBQUU7b0JBQ3BCLElBQUksTUFBTSxDQUFDLGNBQWMsQ0FBQyxHQUFHLENBQUMsRUFBRTt3QkFDNUIsUUFBUSxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQztxQkFDOUI7aUJBQ0o7Z0JBQ0QsSUFBSSxDQUFDLFlBQVksQ0FBQyxDQUFDLENBQUMsQ0FBQyxXQUFXLENBQUMsUUFBUSxFQUFFLFFBQVEsQ0FBQyxDQUFDO2FBQ3hEO1NBQ0o7SUFDTCxDQUFDO0lBRU0sWUFBWTtRQUNmLElBQUksV0FBVyxHQUFRLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxJQUFJLENBQUMsWUFBWSxFQUFFLElBQUksQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLENBQUM7UUFDbEYsSUFBSSxJQUFJLENBQUMsS0FBSyxDQUFDLEtBQUssRUFBRTtZQUNsQixJQUFJLENBQUMsV0FBVyxDQUFDLElBQUksQ0FBQyxXQUFXLENBQUMsQ0FBQztZQUNuQyxJQUFJLENBQUMsV0FBVyxFQUFFLENBQUM7U0FDdEI7YUFBTTtZQUNILElBQUksQ0FBQyx1QkFBdUIsRUFBRSxDQUFDO1NBQ2xDO0lBQ0wsQ0FBQztJQUVELGlDQUFpQztJQUNqQyx5RkFBeUY7SUFDekYsMENBQTBDO0lBQzFDLElBQUk7SUFFSSxVQUFVO1FBQ2QsSUFBSSxDQUFDLGFBQWEsRUFBRSxDQUFDO1FBQ3JCLElBQUksV0FBVyxHQUFZLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxRQUFRLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLGFBQWEsQ0FBQyxlQUFlLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxhQUFhLENBQUMsZUFBZSxDQUFDLENBQUM7UUFDbkosV0FBVyxDQUFDLFNBQVMsR0FBRyxDQUFDLENBQUM7UUFDMUIsSUFBSSxDQUFDLFVBQVUsQ0FBQyxJQUFJLEVBQUUsQ0FBQztJQUMzQixDQUFDO0lBRU8sYUFBYTtRQUNqQixJQUFJLENBQUMsS0FBSyxHQUFHLElBQUksQ0FBQyxVQUFVLENBQUMsY0FBYyxFQUFFLENBQUM7UUFDOUMsS0FBSyxDQUFDLEVBQUUsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxHQUFTLEVBQUU7WUFDM0IsSUFBSSxDQUFDLFlBQVksR0FBRyxJQUFJLENBQUMsVUFBVSxDQUFDLGVBQWUsQ0FBQyxJQUFJLENBQUMsU0FBUyxFQUFFLElBQUksQ0FBQyxXQUFXLENBQUMsQ0FBQztZQUN0RixJQUFJLENBQUMsS0FBSyxHQUFHLElBQUksQ0FBQyxVQUFVLENBQUMsV0FBVyxDQUFDLElBQUksQ0FBQyxZQUFZLENBQUMsQ0FBQztRQUNoRSxDQUFDLENBQUMsQ0FBQztJQUNQLENBQUM7SUFFTyxXQUFXO1FBQ2YsSUFBSSxDQUFDLFFBQVEsR0FBRyxDQUFDLE9BQU8sSUFBSSxDQUFDLE1BQU0sS0FBSyxXQUFXLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLGNBQWMsRUFBRSxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsYUFBYSxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQztJQUNuSCxDQUFDO0lBRU8sY0FBYztRQUNsQixJQUFJLFVBQVUsR0FBZSxDQUFDO2dCQUMxQixJQUFJLEVBQUUsUUFBUTtnQkFDZCxJQUFJLEVBQUUsUUFBUTtnQkFDZCxJQUFJLEVBQUUsVUFBVTtnQkFDaEIsS0FBSyxFQUFFLFVBQVU7Z0JBQ2pCLFFBQVEsRUFBRSxLQUFLO2FBQ2xCLEVBQUU7Z0JBQ0MsSUFBSSxFQUFFLE9BQU87Z0JBQ2IsSUFBSSxFQUFFLE9BQU87Z0JBQ2IsS0FBSyxFQUFFLGFBQWE7Z0JBQ3BCLElBQUksRUFBRSxVQUFVO2dCQUNoQixRQUFRLEVBQUUsS0FBSzthQUNsQixDQUFDLENBQUM7UUFDSCxPQUFPLFVBQVUsQ0FBQztJQUN0QixDQUFDO0lBRU8sYUFBYSxDQUFDLElBQWdCO1FBQ2xDLElBQUksVUFBVSxHQUFlLEVBQUUsQ0FBQztRQUNoQyxJQUFJLFlBQVksR0FBVyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsTUFBTSxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDO1FBQzdFLEtBQUssSUFBSSxDQUFDLEdBQVcsQ0FBQyxFQUFFLENBQUMsR0FBRyxZQUFZLEVBQUUsQ0FBQyxFQUFFLEVBQUU7WUFDM0MsSUFBSSxJQUFJLEdBQVEsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDO1lBQ3hCLElBQUksT0FBTyxJQUFJLENBQUMsSUFBSSxLQUFLLFdBQVc7Z0JBQUUsSUFBSSxDQUFDLElBQUksR0FBRyxXQUFXLENBQUM7WUFDOUQsSUFBSSxPQUFPLElBQUksQ0FBQyxLQUFLLEtBQUssV0FBVztnQkFBRSxJQUFJLENBQUMsS0FBSyxHQUFHLGNBQWMsQ0FBQztZQUNuRSxJQUFJLE9BQU8sSUFBSSxDQUFDLElBQUksS0FBSyxXQUFXO2dCQUFFLElBQUksQ0FBQyxJQUFJLEdBQUcsUUFBUSxDQUFDO1lBQzNELElBQUksT0FBTyxJQUFJLENBQUMsUUFBUSxLQUFLLFdBQVc7Z0JBQUUsSUFBSSxDQUFDLFFBQVEsR0FBRyxLQUFLLENBQUM7WUFDaEUsSUFBSSxJQUFJLENBQUMsSUFBSSxLQUFLLE9BQU8sRUFBRTtnQkFDdkIsSUFBSSxDQUFDLFFBQVEsR0FBRyxHQUFTLEVBQUU7b0JBQ3ZCLElBQUksQ0FBQyxVQUFVLEVBQUUsQ0FBQztnQkFDdEIsQ0FBQyxDQUFDO2FBQ0w7WUFDRCxVQUFVLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDO1NBQ3pCO1FBQ0QsT0FBTyxVQUFVLENBQUM7SUFDdEIsQ0FBQztJQUVPLGdCQUFnQixDQUFDLFNBQXFCLEVBQUUsVUFBZTtRQUMzRCxJQUFJLGNBQWMsR0FBUSxNQUFNLENBQUMsTUFBTSxDQUFDLEVBQUUsRUFBRSxVQUFVLENBQUMsQ0FBQztRQUN4RCxLQUFLLElBQUksQ0FBQyxHQUFXLENBQUMsRUFBRSxDQUFDLEdBQUcsU0FBUyxDQUFDLE1BQU0sRUFBRSxDQUFDLEVBQUUsRUFBRTtZQUMvQyxJQUFJLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxXQUFXLEtBQUssU0FBUyxJQUFJLGNBQWMsSUFBSSxPQUFPLGNBQWMsQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLEtBQUssV0FBVyxFQUFFO2dCQUNySCxPQUFPLGNBQWMsQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUM7YUFDM0M7aUJBQ0ksSUFBSSxPQUFPLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLEtBQUssV0FBVyxJQUFJLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLEVBQUU7Z0JBQzVFLE9BQU8sY0FBYyxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQzthQUMzQztTQUNKO1FBQ0QsT0FBTyxjQUFjLENBQUM7SUFDMUIsQ0FBQztJQUVELHFCQUFxQjtJQUNkLHFCQUFxQixDQUFDLFdBQWdCO1FBQ3pDLElBQUksQ0FBQyxlQUFlLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxDQUFDO0lBQzNDLENBQUM7SUFFTSxrQkFBa0IsQ0FBQyxXQUFnQjtRQUN0QyxJQUFJLENBQUMsaUJBQWlCLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxDQUFDO0lBQzdDLENBQUM7OztZQWpYSixTQUFTLFNBQUM7Z0JBQ1AsUUFBUSxFQUFFLFNBQVM7Z0JBQ25CLGc5T0FBcUM7Z0JBQ3JDLFNBQVMsRUFBRSxDQUFDLHFCQUFxQixFQUFFLFdBQVcsRUFBRSxZQUFZLEVBQUUsU0FBUyxFQUFFLGVBQWUsQ0FBQztnQkFDekYsSUFBSSxFQUFFO29CQUNGLE9BQU8sRUFBRSxVQUFVO2lCQUN0QjthQUNKOzs7WUF4QlEscUJBQXFCO1lBQ3JCLFdBQVc7WUFDWCxZQUFZO1lBQ1osU0FBUztZQURLLGVBQWU7WUFSbEMsVUFBVTs7O3dCQTJDVCxLQUFLO3FCQUNMLEtBQUs7MEJBQ0wsS0FBSztrQkFDTCxLQUFLO3lCQUNMLE1BQU07aUNBQ04sTUFBTTswQkFDTixNQUFNO3lCQUNOLE1BQU07MEJBQ04sTUFBTTs2QkFDTixZQUFZLFNBQUMsT0FBTzs4QkFFcEIsTUFBTTtnQ0FDTixNQUFNIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHtcclxuICAgIENvbXBvbmVudCxcclxuICAgIElucHV0LFxyXG4gICAgT3V0cHV0LFxyXG4gICAgRXZlbnRFbWl0dGVyLFxyXG4gICAgT25Jbml0LFxyXG4gICAgT25EZXN0cm95LFxyXG4gICAgT25DaGFuZ2VzLFxyXG4gICAgVmlld0NoaWxkcmVuLFxyXG4gICAgRWxlbWVudFJlZlxyXG59IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xyXG5pbXBvcnQgeyB0aW1lciAsICBTdWJzY3JpcHRpb24gfSBmcm9tICdyeGpzJztcclxuaW1wb3J0IHsgRm9ybUdyb3VwIH0gZnJvbSAnQGFuZ3VsYXIvZm9ybXMnO1xyXG5pbXBvcnQgeyBLZElucHV0IH0gZnJvbSAnLi4va2QtYW5ndWxhci1pbnB1dC9rZC1hbmd1bGFyLWlucHV0JztcclxuaW1wb3J0IHsgSW5wdXRCYXNlIH0gZnJvbSAnLi4va2QtYW5ndWxhci1pbnB1dC9zcmMva2QtaW5wdXQtYmFzZSc7XHJcbmltcG9ydCB7IEtkSW5wdXRDb250cm9sU2VydmljZSB9IGZyb20gJy4uL2tkLWFuZ3VsYXItaW5wdXQvc3JjL2tkLWFuZ3VsYXItZm9ybS5jb250cm9sJztcclxuaW1wb3J0IHsgS2RGb3JtRXZlbnQgfSBmcm9tICcuL3NyYy9rZC1mb3JtLWV2ZW50JztcclxuaW1wb3J0IHsgS2REb21FbGVtU3ZjLCBLZENvbnZlcnRpb25TdmMgfSBmcm9tICcuLi9rZC1jb21tb24vaW5kZXgnO1xyXG5pbXBvcnQgeyBLZFZpZXdTdmMgfSBmcm9tICcuL2tkLWFuZ3VsYXItdmlldy1zdmMnO1xyXG5pbXBvcnQgeyBJVHJlZUFwaSB9IGZyb20gJy4uL2tkLWFuZ3VsYXItdHJlZWRyb3Bkb3duL2tkLXRyZWVkcm9wZG93bi1pbnRlcmZhY2UnO1xyXG5pbXBvcnQgeyBJRHluYW1pY0Zvcm1BcGksIElEeW5hbWljRm9ybVRhYmxlQXBpIH0gZnJvbSAnLi9rZC1hbmd1bGFyLXZpZXctaW50ZXJmYWNlJztcclxuXHJcbmltcG9ydCB7XHJcbiAgICBJVGFibGVBcGksXHJcbiAgICBJVGFibGVDZWxsUGFyYW1zLFxyXG4gICAgS2RUYWJsZUlucHV0VXBkYXRlRXZlbnQsXHJcbiAgICBLZFRhYmxlQnV0dG9uRXZlbnQsXHJcbiAgICBJVGFibGVGb3JtVXBkYXRlUGFyYW1zLFxyXG59IGZyb20gJy4uL2tkLWFuZ3VsYXItdGFibGUvaW5kZXgnO1xyXG5cclxuaW1wb3J0IHsgSVNsaWRlckFwaSB9IGZyb20gJy4uL2tkLWFuZ3VsYXItc2xpZGVyL2luZGV4JztcclxuXHJcbkBDb21wb25lbnQoe1xyXG4gICAgc2VsZWN0b3I6ICdrZC12aWV3JyxcclxuICAgIHRlbXBsYXRlVXJsOiAnLi9rZC1hbmd1bGFyLXZpZXcuaHRtbCcsXHJcbiAgICBwcm92aWRlcnM6IFtLZElucHV0Q29udHJvbFNlcnZpY2UsIEtkRm9ybUV2ZW50LCBLZERvbUVsZW1TdmMsIEtkVmlld1N2YywgS2RDb252ZXJ0aW9uU3ZjXSxcclxuICAgIGhvc3Q6IHtcclxuICAgICAgICAnY2xhc3MnOiAna2R4LXZpZXcnXHJcbiAgICB9XHJcbn0pXHJcblxyXG5leHBvcnQgY2xhc3MgS2RWaWV3IGltcGxlbWVudHMgT25Jbml0LCBPbkRlc3Ryb3ksIE9uQ2hhbmdlcyB7XHJcbiAgICBwdWJsaWMgX2RmUXVlc3Rpb25zOiBBcnJheTxhbnk+ID0gW107XHJcbiAgICBwdWJsaWMgX2Rpc3BsYXlUeXBlOiBzdHJpbmc7XHJcbiAgICBwdWJsaWMgaXNTdGFja2VkRnJvbTogYm9vbGVhbjtcclxuXHJcbiAgICBwdWJsaWMgX2Zvcm06IEZvcm1Hcm91cDtcclxuICAgIHB1YmxpYyBfZm9ybUJ0bjogQXJyYXk8YW55PiA9IFtdO1xyXG4gICAgcHJpdmF0ZSBfZmlyc3RMb2FkOiBib29sZWFuID0gdHJ1ZTtcclxuICAgIHByaXZhdGUgX2Zvcm1Ecm9wZG93blN1YjogU3Vic2NyaXB0aW9uO1xyXG4gICAgcHJpdmF0ZSBfZm9ybVZpc2libGVTdWI6IFN1YnNjcmlwdGlvbjtcclxuXHJcbiAgICBASW5wdXQoKSBpbnB1dERhdGE6IEFycmF5PGFueT47XHJcbiAgICBASW5wdXQoKSBidXR0b246IEFycmF5PGFueT47XHJcbiAgICBASW5wdXQoKSBkaXNwbGF5VHlwZTogc3RyaW5nO1xyXG4gICAgQElucHV0KCkgYXBpOiBJRHluYW1pY0Zvcm1BcGk7XHJcbiAgICBAT3V0cHV0KCkgZGV0ZWN0RnJvbTogRXZlbnRFbWl0dGVyPGFueT4gPSBuZXcgRXZlbnRFbWl0dGVyKCk7XHJcbiAgICBAT3V0cHV0KCkgZGV0ZWN0R3JpZFF1ZXN0aW9uOiBFdmVudEVtaXR0ZXI8YW55PiA9IG5ldyBFdmVudEVtaXR0ZXIoKTtcclxuICAgIEBPdXRwdXQoKSBzdWJtaXRFdmVudDogRXZlbnRFbWl0dGVyPGFueT4gPSBuZXcgRXZlbnRFbWl0dGVyKCk7XHJcbiAgICBAT3V0cHV0KCkgcmVzZXRFdmVudDogRXZlbnRFbWl0dGVyPGFueT4gPSBuZXcgRXZlbnRFbWl0dGVyKCk7XHJcbiAgICBAT3V0cHV0KCkgYnV0dG9uRXZlbnQ6IEV2ZW50RW1pdHRlcjxhbnk+ID0gbmV3IEV2ZW50RW1pdHRlcigpO1xyXG4gICAgQFZpZXdDaGlsZHJlbihLZElucHV0KSBpbnB1dENvbXBvbmVudDogQXJyYXk8S2RJbnB1dD47XHJcblxyXG4gICAgQE91dHB1dCgpIGdyaWRDZWxsQ2hhbmdlZDogRXZlbnRFbWl0dGVyPHsgZm9ybUtleTogc3RyaW5nLCBwYXJhbXM6IEtkVGFibGVJbnB1dFVwZGF0ZUV2ZW50IH0+ID0gbmV3IEV2ZW50RW1pdHRlcigpO1xyXG4gICAgQE91dHB1dCgpIGdyaWRCdXR0b25DbGlja2VkOiBFdmVudEVtaXR0ZXI8eyBmb3JtS2V5OiBzdHJpbmcsIHBhcmFtczogS2RUYWJsZUJ1dHRvbkV2ZW50IH0+ID0gbmV3IEV2ZW50RW1pdHRlcigpO1xyXG5cclxuICAgIGNvbnN0cnVjdG9yKFxyXG4gICAgICAgIHByaXZhdGUgX2RmQ29udHJvbDogS2RJbnB1dENvbnRyb2xTZXJ2aWNlLFxyXG4gICAgICAgIHByaXZhdGUgX2Zvcm1FdmVudDogS2RGb3JtRXZlbnQsXHJcbiAgICAgICAgcHJpdmF0ZSBfZG9tU3ZjOiBLZERvbUVsZW1TdmMsXHJcbiAgICAgICAgcHJpdmF0ZSBfa2RWaWV3U3ZjOiBLZFZpZXdTdmMsXHJcbiAgICAgICAgcHJpdmF0ZSBfY29udmVydFN2YzogS2RDb252ZXJ0aW9uU3ZjLFxyXG4gICAgICAgIHByaXZhdGUgX2VsZW1lbnRSZWY6IEVsZW1lbnRSZWZcclxuICAgICkgeyB9XHJcblxyXG4gICAgbmdPbkluaXQoKTogdm9pZCB7XHJcblxyXG4gICAgICAgIHRoaXMuX2Rpc3BsYXlUeXBlID0gdGhpcy5kaXNwbGF5VHlwZTsgLy8gKHR5cGVvZiB0aGlzLmRpc3BsYXlUeXBlICE9PSAndW5kZWZpbmVkJykgPyB0aGlzLmRpc3BsYXlUeXBlIDogJ3ZpZXcnO1xyXG4gICAgICAgIHRoaXMuaXNTdGFja2VkRnJvbSA9IHRoaXMuX2Rpc3BsYXlUeXBlID09PSAnc3RhY2tlZC1mb3JtJztcclxuXHJcbiAgICAgICAgdGhpcy5fc2V0UXVlc3Rpb25zKCk7XHJcbiAgICAgICAgdGhpcy5fc2V0QnV0dG9ucygpO1xyXG4gICAgICAgIHRoaXMuX3VwZGF0ZUZvcm1BcGkoKTtcclxuXHJcbiAgICAgICAgdGhpcy5fZm9ybVZpc2libGVTdWIgPSB0aGlzLl9mb3JtRXZlbnQub25TZXRWaXNpYWJsZUlucHV0KCkuc3Vic2NyaWJlKHZhbCA9PiB7XHJcbiAgICAgICAgICAgIGZvciAobGV0IGk6IG51bWJlciA9IDA7IGkgPCB0aGlzLl9kZlF1ZXN0aW9ucy5sZW5ndGg7IGkrKykge1xyXG4gICAgICAgICAgICAgICAgaWYgKHRoaXMuX2RmUXVlc3Rpb25zW2ldLmtleSA9PT0gdmFsLmtleSkge1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuX2RmUXVlc3Rpb25zW2ldLnNldFZpc2libGUodmFsLnZpc2libGUpO1xyXG4gICAgICAgICAgICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfSk7XHJcblxyXG4gICAgICAgIHRoaXMuX2Zvcm1Ecm9wZG93blN1YiA9IHRoaXMuX2Zvcm1FdmVudC5vblNldERyb3Bkb3duTGlzdCgpLnN1YnNjcmliZSh2YWwgPT4ge1xyXG4gICAgICAgICAgICBmb3IgKGxldCBpOiBudW1iZXIgPSAwOyBpIDwgdGhpcy5fZGZRdWVzdGlvbnMubGVuZ3RoOyBpKyspIHtcclxuICAgICAgICAgICAgICAgIGlmICh0aGlzLl9kZlF1ZXN0aW9uc1tpXS5rZXkgPT09IHZhbC5rZXkpIHtcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLl9kZlF1ZXN0aW9uc1tpXS5zZXRPcHRpb25zKHZhbC5vcHRpb25zKTtcclxuICAgICAgICAgICAgICAgICAgICBicmVhaztcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH0pO1xyXG5cclxuICAgICAgICB0aGlzLl9maXJzdExvYWQgPSBmYWxzZTtcclxuICAgICAgICAvLyBjb25zb2xlLmxvZygnS2RWaWV3IC0gdGhpcyBpcyB0aGUgdmlldyBqdXN0IGluaXRpYWxpemVkJywgdGhpcy5pbnB1dERhdGEpO1xyXG4gICAgfVxyXG5cclxuICAgIG5nT25DaGFuZ2VzKCk6IHZvaWQge1xyXG4gICAgICAgIGlmICghdGhpcy5fZmlyc3RMb2FkKSB7XHJcbiAgICAgICAgICAgIC8vIGNvbnNvbGUubG9nKCdLZFZpZXcgLSB0aGlzIGlzIHRoZSB2aWV3IGNoYW5nZSBldmVudCcsIHRoaXMuaW5wdXREYXRhKTtcclxuICAgICAgICAgICAgdGhpcy5fZGlzcGxheVR5cGUgPSAodHlwZW9mIHRoaXMuZGlzcGxheVR5cGUgIT09ICd1bmRlZmluZWQnKSA/IHRoaXMuZGlzcGxheVR5cGUgOiAndmlldyc7XHJcbiAgICAgICAgICAgIHRoaXMuX3NldFF1ZXN0aW9ucygpO1xyXG4gICAgICAgICAgICB0aGlzLl9zZXRCdXR0b25zKCk7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIG5nT25EZXN0cm95KCk6IHZvaWQge1xyXG4gICAgICAgIGlmKHRoaXMuX2Zvcm1WaXNpYmxlU3ViKSB0aGlzLl9mb3JtVmlzaWJsZVN1Yi51bnN1YnNjcmliZSgpO1xyXG4gICAgICAgIGlmKHRoaXMuX2Zvcm1Ecm9wZG93blN1YikgdGhpcy5fZm9ybURyb3Bkb3duU3ViLnVuc3Vic2NyaWJlKCk7XHJcbiAgICB9XHJcblxyXG4gICAgcHVibGljIGdldElucHV0UHJvcGVydHkoa2V5OiBzdHJpbmcsIHByb3BlcnR5TmFtZTogc3RyaW5nKTogYW55IHtcclxuICAgICAgICBmb3IgKGxldCBpOiBudW1iZXIgPSAwOyBpIDwgdGhpcy5fZGZRdWVzdGlvbnMubGVuZ3RoOyBpKyspIHtcclxuICAgICAgICAgICAgaWYgKHRoaXMuX2RmUXVlc3Rpb25zW2ldLmdldFByb3BlcnR5KCdrZXknKSA9PT0ga2V5KSByZXR1cm4gdGhpcy5fZGZRdWVzdGlvbnNbaV0uZ2V0UHJvcGVydHkocHJvcGVydHlOYW1lKTtcclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgcHVibGljIHNldElucHV0UHJvcGVydHkoa2V5OiBzdHJpbmcsIHByb3BlcnR5TmFtZTogc3RyaW5nLCBkYXRhOiBhbnkpOiB2b2lkIHtcclxuICAgICAgICBmb3IgKGxldCBpOiBudW1iZXIgPSAwOyBpIDwgdGhpcy5fZGZRdWVzdGlvbnMubGVuZ3RoOyBpKyspIHtcclxuICAgICAgICAgICAgaWYgKHRoaXMuX2RmUXVlc3Rpb25zW2ldLmdldFByb3BlcnR5KCdrZXknKSA9PT0ga2V5KSB7XHJcbiAgICAgICAgICAgICAgICBpZiAocHJvcGVydHlOYW1lICE9PSAndmlzaWJsZScpIHtcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLl9kZlF1ZXN0aW9uc1tpXS5zZXRQcm9wZXJ0eShwcm9wZXJ0eU5hbWUsIGRhdGEpO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgZWxzZSB7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5fZGZRdWVzdGlvbnNbaV0uc2V0VmlzaWJsZShkYXRhKTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIHB1YmxpYyByZXNldEdyaWRIZWlnaHQoX2dyaWRJZDogc3RyaW5nKTogdm9pZCB7XHJcbiAgICAgICAgdGhpcy5pbnB1dENvbXBvbmVudC5mb3JFYWNoKChpdGVtOiBLZElucHV0KTogdm9pZCA9PiB7XHJcbiAgICAgICAgICAgIGlmIChfZ3JpZElkID09PSBpdGVtLnF1ZXN0aW9uLmdldFByb3BlcnR5KCdrZXknKSkge1xyXG4gICAgICAgICAgICAgICAgaXRlbS5yZXNldEhlaWdodCgpO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfSk7XHJcbiAgICB9XHJcblxyXG4gICAgLy8vLy8gVGFibGUgY29udHJvbHR5cGVcclxuICAgIHB1YmxpYyB1cGRhdGVUYWJsZUNlbGwoX3F1ZXN0aW9uS2V5OiBzdHJpbmcsIF9jZWxsUGFyYW1zOiBJVGFibGVDZWxsUGFyYW1zKTogdm9pZCB7XHJcbiAgICAgICAgdGhpcy5pbnB1dENvbXBvbmVudC5mb3JFYWNoKChpdGVtOiBLZElucHV0KTogdm9pZCA9PiB7XHJcbiAgICAgICAgICAgIGlmIChfcXVlc3Rpb25LZXkgPT09IGl0ZW0ucXVlc3Rpb24uZ2V0UHJvcGVydHkoJ2tleScpKSB7XHJcbiAgICAgICAgICAgICAgICBpdGVtLnNldFRhYmxlQ2VsbERhdGEoX2NlbGxQYXJhbXMpO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfSk7XHJcbiAgICB9XHJcblxyXG4gICAgcHVibGljIHVwZGF0ZVRhYmxlQ2VsbFByb3BlcnR5KF9xdWVzdGlvbktleTogc3RyaW5nLCBfY2VsbFBhcmFtczogSVRhYmxlRm9ybVVwZGF0ZVBhcmFtcyk6IHZvaWQge1xyXG4gICAgICAgIHRoaXMuaW5wdXRDb21wb25lbnQuZm9yRWFjaCgoaXRlbTogS2RJbnB1dCk6IHZvaWQgPT4ge1xyXG4gICAgICAgICAgICBpZiAoX3F1ZXN0aW9uS2V5ID09PSBpdGVtLnF1ZXN0aW9uLmdldFByb3BlcnR5KCdrZXknKSkge1xyXG4gICAgICAgICAgICAgICAgaXRlbS5zZXRUYWJsZUNlbGxRdWVzdGlvblByb3BlcnR5KF9jZWxsUGFyYW1zKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH0pO1xyXG4gICAgfVxyXG4gICAgLy8vLy8vLy8gdGlsbCBoZXJlXHJcblxyXG4gICAgcHVibGljIHNldEJ1dHRvbkRpc2FibGVkKF90eXBlOiBzdHJpbmcsIF9kaXNhYmxlZDogYm9vbGVhbik6IHZvaWQge1xyXG4gICAgICAgIGZvciAobGV0IGk6IG51bWJlciA9IDA7IGkgPCB0aGlzLl9mb3JtQnRuLmxlbmd0aDsgaSsrKSB7XHJcbiAgICAgICAgICAgIGlmIChfdHlwZSA9PT0gdGhpcy5fZm9ybUJ0bltpXS50eXBlKSB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLl9mb3JtQnRuW2ldLmRpc2FibGVkID0gX2Rpc2FibGVkO1xyXG4gICAgICAgICAgICAgICAgdGhpcy5fZm9ybUJ0biA9IHRoaXMuX2Zvcm1CdG4uc2xpY2UoKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICBwdWJsaWMgaXNGb3JtT3JTdGFja2VkRm9ybSgpOiBzdHJpbmcge1xyXG4gICAgICAgIGlmICh0aGlzLl9kaXNwbGF5VHlwZSA9PT0gJ2Zvcm0nIHx8IHRoaXMuX2Rpc3BsYXlUeXBlID09PSAnc3RhY2tlZC1mb3JtJykge1xyXG4gICAgICAgICAgICByZXR1cm4gdGhpcy5fZGlzcGxheVR5cGU7XHJcbiAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgcmV0dXJuICctJztcclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgLy8gY2hhbmdlIHRvIHB1YmxpYyBkdWUgdG8gbGludFxyXG4gICAgcHVibGljIGNoYW5nZURldGVjdEZvcm0oX3F1ZXN0aW9uOiBJbnB1dEJhc2U8YW55Pik6IHZvaWQge1xyXG4gICAgICAgIHRoaXMuZGV0ZWN0RnJvbS5lbWl0KF9xdWVzdGlvbik7XHJcbiAgICB9XHJcblxyXG4gICAgLy8gY2hhbmdlIHRvIHB1YmxpYyBkdWUgdG8gbGludFxyXG4gICAgcHVibGljIGNoYW5nZURldGVjdEZyb21HcmlkKF9ncmlkQ2VsbFF1ZXN0aW9uOiBhbnkpOiB2b2lkIHtcclxuICAgICAgICB0aGlzLmRldGVjdEdyaWRRdWVzdGlvbi5lbWl0KF9ncmlkQ2VsbFF1ZXN0aW9uKTtcclxuICAgIH1cclxuXHJcbiAgICAvKioqKioqKioqKioqKioqKioqKioqKioqIER5bmFtaWMgRm9ybSBBUEkgdXBkYXRlcyAqKioqKioqKioqKioqKioqKioqKioqKioqL1xyXG4gICAgcHJpdmF0ZSBfdXBkYXRlRm9ybUFwaSgpOiB2b2lkIHtcclxuICAgICAgICBpZiAodHlwZW9mIHRoaXMuYXBpID09PSAndW5kZWZpbmVkJykge1xyXG4gICAgICAgICAgICBjb25zb2xlLndhcm4oJ0tkVmlldyB3YXJuaW5nOiBObyBhcGkgb2JqZWN0IGlzIHBhc3NlZCBpbi4gTm8gQVBJIHdpbGwgYmUgaW5pdGlhbGl6ZScpO1xyXG4gICAgICAgICAgICByZXR1cm47XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICB0aGlzLmFwaS5zdWJtaXRGb3JtID0gKCk6IHZvaWQgPT4ge1xyXG4gICAgICAgICAgICB0aGlzLl9zdWJtaXRDbGljaygpO1xyXG4gICAgICAgIH07XHJcblxyXG4gICAgICAgIHRoaXMuYXBpLnNldFByb3BlcnR5ID0gKF9xdWVzdGlvbktleTogc3RyaW5nLCBfcHJvcGVydHk6IHN0cmluZywgX2RhdGE6IGFueSk6IHZvaWQgPT4ge1xyXG4gICAgICAgICAgICBmb3IgKGxldCBpOiBudW1iZXIgPSAwOyBpIDwgdGhpcy5fZGZRdWVzdGlvbnMubGVuZ3RoOyBpKyspIHtcclxuICAgICAgICAgICAgICAgIGlmICh0aGlzLl9kZlF1ZXN0aW9uc1tpXS5nZXRQcm9wZXJ0eSgna2V5JykgPT09IF9xdWVzdGlvbktleSkge1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuX2RmUXVlc3Rpb25zW2ldLnNldFByb3BlcnR5KF9wcm9wZXJ0eSwgX2RhdGEpO1xyXG4gICAgICAgICAgICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfTtcclxuXHJcbiAgICAgICAgdGhpcy5hcGkuZ2V0UHJvcGVydHkgPSAoX3F1ZXN0aW9uS2V5OiBzdHJpbmcsIF9wcm9wZXJ0eTogc3RyaW5nKTogYW55ID0+IHtcclxuICAgICAgICAgICAgZm9yIChsZXQgaTogbnVtYmVyID0gMDsgaSA8IHRoaXMuX2RmUXVlc3Rpb25zLmxlbmd0aDsgaSsrKSB7XHJcbiAgICAgICAgICAgICAgICBpZiAodGhpcy5fZGZRdWVzdGlvbnNbaV0uZ2V0UHJvcGVydHkoJ2tleScpID09PSBfcXVlc3Rpb25LZXkpIHtcclxuICAgICAgICAgICAgICAgICAgICByZXR1cm4gdGhpcy5fZGZRdWVzdGlvbnNbaV0uZ2V0UHJvcGVydHkoX3Byb3BlcnR5KTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH07XHJcblxyXG4gICAgICAgIHRoaXMuYXBpLnRhYmxlID0gKF9xdWVzdGlvbktleTogc3RyaW5nKTogSUR5bmFtaWNGb3JtVGFibGVBcGkgPT4ge1xyXG4gICAgICAgICAgICBsZXQgdGFibGVBcGk6IElUYWJsZUFwaTtcclxuXHJcbiAgICAgICAgICAgIGZvciAobGV0IGk6IG51bWJlciA9IDA7IGkgPCB0aGlzLl9kZlF1ZXN0aW9ucy5sZW5ndGg7ICsraSkge1xyXG4gICAgICAgICAgICAgICAgaWYgKHRoaXMuX2RmUXVlc3Rpb25zW2ldLmdldFByb3BlcnR5KCdrZXknKSA9PT0gX3F1ZXN0aW9uS2V5KSB7XHJcbiAgICAgICAgICAgICAgICAgICAgdGFibGVBcGkgPSB0aGlzLl9kZlF1ZXN0aW9uc1tpXS5nZXRQcm9wZXJ0eSgnYXBpJyk7XHJcbiAgICAgICAgICAgICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgIHJldHVybiB7XHJcbiAgICAgICAgICAgICAgICBzZXRUYWJsZUNlbGxJbnB1dFByb3BlcnR5OiAoX2Zvcm1QYXJhbXM6IElUYWJsZUZvcm1VcGRhdGVQYXJhbXMpOiB2b2lkID0+IHtcclxuICAgICAgICAgICAgICAgICAgICB0YWJsZUFwaS5keW5hbWljRm9ybS5zZXRQcm9wZXJ0eShfZm9ybVBhcmFtcyk7XHJcbiAgICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgICAgdXBkYXRlVGFibGVDZWxsUHJvcGVydHk6IChfY2VsbFBhcmFtczogSVRhYmxlQ2VsbFBhcmFtcyk6IHZvaWQgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgIHRhYmxlQXBpLmdlbmVyYWwudXBkYXRlQ2VsbChfY2VsbFBhcmFtcyk7XHJcbiAgICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgICAgZ2V0VGFibGVDZWxsSW5wdXRQcm9wZXJ0eTogKF9mb3JtUGFyYW1zOiBJVGFibGVGb3JtVXBkYXRlUGFyYW1zKTogdm9pZCA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgdGFibGVBcGkuZHluYW1pY0Zvcm0uZ2V0UHJvcGVydHkoX2Zvcm1QYXJhbXMpO1xyXG4gICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICAgIGFkZFJvdzogKF9yb3dzOiBBcnJheTxhbnk+LCBfc2Nyb2xsVG9WaXNpYmxlOiBib29sZWFuID0gZmFsc2UpOiB2b2lkID0+IHtcclxuICAgICAgICAgICAgICAgICAgICB0YWJsZUFwaS5nZW5lcmFsLmFkZFJvd3MoX3Jvd3MsIF9zY3JvbGxUb1Zpc2libGUpO1xyXG4gICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICAgIGRlbGV0ZVJvd3M6IChfaWQ6IEFycmF5PHN0cmluZyB8IG51bWJlcj4gfCBudW1iZXIgfCBzdHJpbmcpOiB2b2lkID0+IHtcclxuICAgICAgICAgICAgICAgICAgICB0YWJsZUFwaS5nZW5lcmFsLmRlbGV0ZVJvd3MoX2lkKTtcclxuICAgICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICAgICBjbGVhckVycm9yOiAoKTogdm9pZCA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgdGFibGVBcGkuZHluYW1pY0Zvcm0uY2xlYXJBbGxFcnJvcigpO1xyXG4gICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICAgIHNldEJ1dHRvbkRpc2FibGVkOiAoX2J1dHRvblR5cGU6IHN0cmluZywgX3RvRGlzYWJsZWQ6IGJvb2xlYW4pOiB2b2lkID0+IHtcclxuICAgICAgICAgICAgICAgICAgICB0YWJsZUFwaS5nZW5lcmFsLnNldEJ1dHRvbkRpc2FibGVkKF9idXR0b25UeXBlLCBfdG9EaXNhYmxlZCk7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH07XHJcbiAgICAgICAgfTtcclxuXHJcbiAgICAgICAgdGhpcy5hcGkudHJlZWRyb3Bkb3duID0gKF9xdWVzdGlvbktleTogc3RyaW5nKTogSVRyZWVBcGkgPT4ge1xyXG4gICAgICAgICAgICBsZXQgdHJlZUFwaTogSVRyZWVBcGk7XHJcbiAgICAgICAgICAgIGZvciAobGV0IGk6IG51bWJlciA9IDA7IGkgPCB0aGlzLl9kZlF1ZXN0aW9ucy5sZW5ndGg7ICsraSkge1xyXG4gICAgICAgICAgICAgICAgaWYgKHRoaXMuX2RmUXVlc3Rpb25zW2ldLmdldFByb3BlcnR5KCdrZXknKSA9PT0gX3F1ZXN0aW9uS2V5KSB7XHJcbiAgICAgICAgICAgICAgICAgICAgdHJlZUFwaSA9IHRoaXMuX2RmUXVlc3Rpb25zW2ldLmdldFByb3BlcnR5KCdhcGknKTtcclxuICAgICAgICAgICAgICAgICAgICBicmVhaztcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICByZXR1cm4gdHJlZUFwaTtcclxuICAgICAgICB9O1xyXG5cclxuICAgICAgICB0aGlzLmFwaS5zbGlkZXJBcGkgPSAoX3F1ZXN0aW9uS2V5OiBzdHJpbmcpOiBJU2xpZGVyQXBpID0+IHtcclxuICAgICAgICAgICAgbGV0IHNsaWRlckFwaTogSVNsaWRlckFwaTtcclxuXHJcbiAgICAgICAgICAgIGZvciAobGV0IGk6IG51bWJlciA9IDA7IGkgPCB0aGlzLl9kZlF1ZXN0aW9ucy5sZW5ndGg7ICsraSkge1xyXG4gICAgICAgICAgICAgICAgaWYgKHRoaXMuX2RmUXVlc3Rpb25zW2ldLmdldFByb3BlcnR5KCdrZXknKSA9PT0gX3F1ZXN0aW9uS2V5KSB7XHJcbiAgICAgICAgICAgICAgICAgICAgc2xpZGVyQXBpID0gdGhpcy5fZGZRdWVzdGlvbnNbaV0uZ2V0UHJvcGVydHkoJ2FwaScpO1xyXG4gICAgICAgICAgICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICByZXR1cm4gc2xpZGVyQXBpO1xyXG4gICAgICAgIH07XHJcbiAgICB9XHJcblxyXG5cclxuICAgIHB1YmxpYyBfYnRuQ2xpY2soX2J0bjogYW55KTogdm9pZCB7XHJcbiAgICAgICAgaWYgKF9idG4udHlwZSA9PT0gJ3Jlc2V0JykgdGhpcy5fcmVzZXRGb3JtKCk7XHJcbiAgICAgICAgZWxzZSBpZiAoX2J0bi50eXBlICE9PSAnc3VibWl0JykgdGhpcy5idXR0b25FdmVudC5lbWl0KF9idG4pO1xyXG4gICAgICAgIC8vIGlmKHR5cGVvZiBfYnRuLmNhbGxiYWNrID09PSAnZnVuY3Rpb24nKSBfYnRuLmNhbGxiYWNrKHRoaXMuX2Zvcm0udmFsdWUpO1xyXG4gICAgICAgIC8vIGVsc2UgaWYodHlwZW9mIF9idG4uY2FsbGJhY2sgPT09ICd1bmRlZmluZWQnICYmIF9idG4udHlwZSAhPT0gJ3N1Ym1pdCcpIGNvbnNvbGUuZXJyb3IoJ1BsZWFzZSBwcm92aWRlIGNhbGxiYWNrJyk7XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfcmVzZXRFcnJvcigpOiB2b2lkIHtcclxuICAgICAgICBmb3IgKGxldCBpID0gMDsgaSA8IHRoaXMuX2RmUXVlc3Rpb25zLmxlbmd0aDsgKytpKSB7XHJcbiAgICAgICAgICAgIHRoaXMuX2RmUXVlc3Rpb25zW2ldLnNldFByb3BlcnR5KCdlcnJvcnMnLCBbXSk7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX2dldEZvcm1WYWxpZGF0aW9uRXJyb3IoKTogdm9pZCB7XHJcbiAgICAgICAgZm9yIChsZXQgaSA9IDA7IGkgPCB0aGlzLl9kZlF1ZXN0aW9ucy5sZW5ndGg7ICsraSkge1xyXG4gICAgICAgICAgICB0aGlzLl9kZlF1ZXN0aW9uc1tpXS5zZXRQcm9wZXJ0eSgnZXJyb3JzJywgW10pO1xyXG4gICAgICAgICAgICBsZXQgZXJyb3JBcnI6IEFycmF5PHN0cmluZz4gPSBbXTtcclxuICAgICAgICAgICAgY29uc3QgZXJyb3JzOiB7fSA9IHRoaXMuX2Zvcm0uZ2V0KHRoaXMuX2RmUXVlc3Rpb25zW2ldLmdldFByb3BlcnR5KCdrZXknKSkuZXJyb3JzO1xyXG4gICAgICAgICAgICBpZiAoZXJyb3JzICE9PSBudWxsKSB7XHJcbiAgICAgICAgICAgICAgICBmb3IgKGxldCBrZXkgaW4gZXJyb3JzKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKGVycm9ycy5oYXNPd25Qcm9wZXJ0eShrZXkpKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGVycm9yQXJyLnB1c2goZXJyb3JzW2tleV0pO1xyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIHRoaXMuX2RmUXVlc3Rpb25zW2ldLnNldFByb3BlcnR5KCdlcnJvcnMnLCBlcnJvckFycik7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgcHVibGljIF9zdWJtaXRDbGljaygpOiB2b2lkIHtcclxuICAgICAgICBsZXQgdXBkYXRlZEZvcm06IGFueSA9IHRoaXMuX3VwZGF0ZUZvcm1WYWx1ZSh0aGlzLl9kZlF1ZXN0aW9ucywgdGhpcy5fZm9ybS52YWx1ZSk7XHJcbiAgICAgICAgaWYgKHRoaXMuX2Zvcm0udmFsaWQpIHtcclxuICAgICAgICAgICAgdGhpcy5zdWJtaXRFdmVudC5lbWl0KHVwZGF0ZWRGb3JtKTtcclxuICAgICAgICAgICAgdGhpcy5fcmVzZXRFcnJvcigpO1xyXG4gICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgIHRoaXMuX2dldEZvcm1WYWxpZGF0aW9uRXJyb3IoKTtcclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgLy8gcHJpdmF0ZSBfc3VibWl0Q2xpY2soKTogdm9pZCB7XHJcbiAgICAvLyAgICAgbGV0IHVwZGF0ZWRGb3JtOiBhbnkgPSB0aGlzLl91cGRhdGVGb3JtVmFsdWUodGhpcy5fZGZRdWVzdGlvbnMsIHRoaXMuX2Zvcm0udmFsdWUpO1xyXG4gICAgLy8gICAgIHRoaXMuc3VibWl0RXZlbnQuZW1pdCh1cGRhdGVkRm9ybSk7XHJcbiAgICAvLyB9XHJcblxyXG4gICAgcHJpdmF0ZSBfcmVzZXRGb3JtKCk6IHZvaWQge1xyXG4gICAgICAgIHRoaXMuX3NldFF1ZXN0aW9ucygpO1xyXG4gICAgICAgIGxldCBjb250ZW50Qm9keTogRWxlbWVudCA9ICh0aGlzLl9kb21TdmMuaXNNb2JpbGUoKSkgPyBkb2N1bWVudC5ib2R5LnF1ZXJ5U2VsZWN0b3IoJy5tYWluLXdyYXBwZXInKSA6IGRvY3VtZW50LmJvZHkucXVlcnlTZWxlY3RvcignLmNvbnRlbnQtYXJlYScpO1xyXG4gICAgICAgIGNvbnRlbnRCb2R5LnNjcm9sbFRvcCA9IDA7XHJcbiAgICAgICAgdGhpcy5yZXNldEV2ZW50LmVtaXQoKTtcclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF9zZXRRdWVzdGlvbnMoKTogdm9pZCB7XHJcbiAgICAgICAgdGhpcy5fZm9ybSA9IHRoaXMuX2RmQ29udHJvbC5lbXB0eUZvcm1Hcm91cCgpO1xyXG4gICAgICAgIHRpbWVyKDUwKS5zdWJzY3JpYmUoKCk6IHZvaWQgPT4ge1xyXG4gICAgICAgICAgICB0aGlzLl9kZlF1ZXN0aW9ucyA9IHRoaXMuX2tkVmlld1N2Yy5jb252ZXJ0RGF0YVR5cGUodGhpcy5pbnB1dERhdGEsIHRoaXMuX2NvbnZlcnRTdmMpO1xyXG4gICAgICAgICAgICB0aGlzLl9mb3JtID0gdGhpcy5fZGZDb250cm9sLnRvRm9ybUdyb3VwKHRoaXMuX2RmUXVlc3Rpb25zKTtcclxuICAgICAgICB9KTtcclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF9zZXRCdXR0b25zKCk6IHZvaWQge1xyXG4gICAgICAgIHRoaXMuX2Zvcm1CdG4gPSAodHlwZW9mIHRoaXMuYnV0dG9uID09PSAndW5kZWZpbmVkJykgPyB0aGlzLl9zZXREZWZhdWx0QnRuKCkgOiB0aGlzLl9zZXRDdXN0b21CdG4odGhpcy5idXR0b24pO1xyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX3NldERlZmF1bHRCdG4oKTogQXJyYXk8YW55PiB7XHJcbiAgICAgICAgbGV0IGRlZmF1bHRCdG46IEFycmF5PGFueT4gPSBbe1xyXG4gICAgICAgICAgICB0eXBlOiAnc3VibWl0JyxcclxuICAgICAgICAgICAgbmFtZTogJ1N1Ym1pdCcsXHJcbiAgICAgICAgICAgIGljb246ICdrZC1jaGVjaycsXHJcbiAgICAgICAgICAgIGNsYXNzOiAnYnRuLXRleHQnLFxyXG4gICAgICAgICAgICBkaXNhYmxlZDogZmFsc2VcclxuICAgICAgICB9LCB7XHJcbiAgICAgICAgICAgIHR5cGU6ICdyZXNldCcsXHJcbiAgICAgICAgICAgIG5hbWU6ICdSZXNldCcsXHJcbiAgICAgICAgICAgIGNsYXNzOiAnYnRuLW91dGxpbmUnLFxyXG4gICAgICAgICAgICBpY29uOiAna2QtY3Jvc3MnLFxyXG4gICAgICAgICAgICBkaXNhYmxlZDogZmFsc2VcclxuICAgICAgICB9XTtcclxuICAgICAgICByZXR1cm4gZGVmYXVsdEJ0bjtcclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF9zZXRDdXN0b21CdG4oX2J0bjogQXJyYXk8YW55Pik6IEFycmF5PGFueT4ge1xyXG4gICAgICAgIGxldCB1cGRhdGVkQnRuOiBBcnJheTxhbnk+ID0gW107XHJcbiAgICAgICAgbGV0IGJ1dHRvbkxlbmd0aDogbnVtYmVyID0gKHRoaXMuYnV0dG9uLmxlbmd0aCA+IDQpID8gNCA6IHRoaXMuYnV0dG9uLmxlbmd0aDtcclxuICAgICAgICBmb3IgKGxldCBpOiBudW1iZXIgPSAwOyBpIDwgYnV0dG9uTGVuZ3RoOyBpKyspIHtcclxuICAgICAgICAgICAgbGV0IGl0ZW06IGFueSA9IF9idG5baV07XHJcbiAgICAgICAgICAgIGlmICh0eXBlb2YgaXRlbS5uYW1lID09PSAndW5kZWZpbmVkJykgaXRlbS5uYW1lID0gJ1VuZGVmaW5lZCc7XHJcbiAgICAgICAgICAgIGlmICh0eXBlb2YgaXRlbS5jbGFzcyA9PT0gJ3VuZGVmaW5lZCcpIGl0ZW0uY2xhc3MgPSAnYnRuIGJ0bi10ZXh0JztcclxuICAgICAgICAgICAgaWYgKHR5cGVvZiBpdGVtLnR5cGUgPT09ICd1bmRlZmluZWQnKSBpdGVtLnR5cGUgPSAnYnV0dG9uJztcclxuICAgICAgICAgICAgaWYgKHR5cGVvZiBpdGVtLmRpc2FibGVkID09PSAndW5kZWZpbmVkJykgaXRlbS5kaXNhYmxlZCA9IGZhbHNlO1xyXG4gICAgICAgICAgICBpZiAoaXRlbS50eXBlID09PSAncmVzZXQnKSB7XHJcbiAgICAgICAgICAgICAgICBpdGVtLmNhbGxiYWNrID0gKCk6IHZvaWQgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuX3Jlc2V0Rm9ybSgpO1xyXG4gICAgICAgICAgICAgICAgfTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB1cGRhdGVkQnRuLnB1c2goaXRlbSk7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIHJldHVybiB1cGRhdGVkQnRuO1xyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX3VwZGF0ZUZvcm1WYWx1ZShfcXVlc3Rpb246IEFycmF5PGFueT4sIF9mb3JtVmFsdWU6IGFueSk6IGFueSB7XHJcbiAgICAgICAgbGV0IHVwZGF0ZWRGb3JtVmFsOiBhbnkgPSBPYmplY3QuYXNzaWduKHt9LCBfZm9ybVZhbHVlKTtcclxuICAgICAgICBmb3IgKGxldCBpOiBudW1iZXIgPSAwOyBpIDwgX3F1ZXN0aW9uLmxlbmd0aDsgaSsrKSB7XHJcbiAgICAgICAgICAgIGlmIChfcXVlc3Rpb25baV0uY29udHJvbFR5cGUgPT09ICdzZWN0aW9uJyAmJiB1cGRhdGVkRm9ybVZhbCAmJiB0eXBlb2YgdXBkYXRlZEZvcm1WYWxbX3F1ZXN0aW9uW2ldLmtleV0gIT09ICd1bmRlZmluZWQnKSB7XHJcbiAgICAgICAgICAgICAgICBkZWxldGUgdXBkYXRlZEZvcm1WYWxbX3F1ZXN0aW9uW2ldLmtleV07XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgZWxzZSBpZiAodHlwZW9mIF9xdWVzdGlvbltpXS5kaXNhYmxlZCAhPT0gJ3VuZGVmaW5lZCcgJiYgX3F1ZXN0aW9uW2ldLmRpc2FibGVkKSB7XHJcbiAgICAgICAgICAgICAgICBkZWxldGUgdXBkYXRlZEZvcm1WYWxbX3F1ZXN0aW9uW2ldLmtleV07XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICAgICAgcmV0dXJuIHVwZGF0ZWRGb3JtVmFsO1xyXG4gICAgfVxyXG5cclxuICAgIC8vLyB0YWJsZSBjb250cm9sdHlwZVxyXG4gICAgcHVibGljIF9ncmlkQ2VsbFZhbHVlQ2hhbmdlZChfZW1pdFBhcmFtczogYW55KTogdm9pZCB7XHJcbiAgICAgICAgdGhpcy5ncmlkQ2VsbENoYW5nZWQuZW1pdChfZW1pdFBhcmFtcyk7XHJcbiAgICB9XHJcblxyXG4gICAgcHVibGljIF9ncmlkQnV0dG9uQ2xpY2tlZChfZW1pdFBhcmFtczogYW55KTogdm9pZCB7XHJcbiAgICAgICAgdGhpcy5ncmlkQnV0dG9uQ2xpY2tlZC5lbWl0KF9lbWl0UGFyYW1zKTtcclxuICAgIH1cclxufVxyXG4iXX0=