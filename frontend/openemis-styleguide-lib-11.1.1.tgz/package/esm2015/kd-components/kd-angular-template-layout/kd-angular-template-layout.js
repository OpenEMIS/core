import { Component, Input } from '@angular/core';
import { KdDataSvc } from '../kd-common/index';
export class KdTemplateLayout {
    constructor(
    // private _pageEvent: KdPageBaseEvent,
    // private _router: Router,
    _dataSvc) {
        this._dataSvc = _dataSvc;
        this.localApi = {
            header: {},
            pageHeader: {},
            breadcrumbs: {},
            navigation: {}
        };
    }
    ngOnInit() {
        this._initApi();
    }
    ngOnDestroy() {
    }
    changeDetectFrom(question) {
        // console.log('Adv search component change detect from: ', question);
    }
    submittedFormValue(formVal) {
        // console.log('Adv search form submit data: ', formVal);
    }
    _initApi() {
        if (!this.api)
            return;
        // this.api = this.localApi;
        this._dataSvc.deepCombineObject(this.api, this.localApi);
        // this._cdr.detectChanges();
        // console.log('set to api', this.api);
    }
}
KdTemplateLayout.decorators = [
    { type: Component, args: [{
                selector: 'kd-template-layout',
                template: `
        <kd-splitter class='has-header has-footer main'>
            <kd-pane size='10%' max='30%' min='2%'>
                <kd-leftmenu [config]='leftNavConfig' [api]='localApi.navigation'></kd-leftmenu>
            </kd-pane>
            <kd-pane>
                <ng-template ngbModalContainer></ng-template>
                <kd-alert></kd-alert>
                <kd-header [config]='headerConfig' [api]='localApi.header'></kd-header>
                <div class='main-wrapper'>
                    <div class='content-wrapper'>
                        <kd-breadcrumb [config]='breadcrumbConfig' [api]='localApi.breadcrumbs'></kd-breadcrumb>
                        <kd-pageheader [config]='pageHeaderConfig' [api]='localApi.pageHeader'></kd-pageheader>
                        <div class='content-area'>
                            <div class='content'>
                                <router-outlet></router-outlet>
                            </div>
                            <kd-footer enableFloat='true'></kd-footer>
                        </div>
                        <!-- <kd-adv-search [formData]='searchFormData' (fieldValue)='changeDetectFrom($event)' (formValue)='submittedFormValue($event)'></kd-adv-search> -->
                    </div>
                </div>
            </kd-pane>
        </kd-splitter>
    `,
                providers: [
                    KdDataSvc
                    // KdPageBaseEvent
                ]
            },] }
];
KdTemplateLayout.ctorParameters = () => [
    { type: KdDataSvc }
];
KdTemplateLayout.propDecorators = {
    leftNavConfig: [{ type: Input, args: ['navigation',] }],
    headerConfig: [{ type: Input, args: ['header',] }],
    pageHeaderConfig: [{ type: Input, args: ['pageheader',] }],
    breadcrumbConfig: [{ type: Input, args: ['breadcrumbs',] }],
    searchFormData: [{ type: Input, args: ['search',] }],
    api: [{ type: Input }]
};
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoia2QtYW5ndWxhci10ZW1wbGF0ZS1sYXlvdXQuanMiLCJzb3VyY2VSb290IjoiRDovb3BlbkVNSVMvc3R5bGVndWlkZS9pb3N0Zy1vcGVuZW1pcy1zdHlsZWd1aWRlL3Byb2plY3RzL29wZW5lbWlzLXN0eWxlZ3VpZGUtbGliL3NyYy8iLCJzb3VyY2VzIjpbImtkLWNvbXBvbmVudHMva2QtYW5ndWxhci10ZW1wbGF0ZS1sYXlvdXQva2QtYW5ndWxhci10ZW1wbGF0ZS1sYXlvdXQudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsT0FBTyxFQUNILFNBQVMsRUFHVCxLQUFLLEVBQ1IsTUFBTSxlQUFlLENBQUM7QUFPdkIsT0FBTyxFQUFFLFNBQVMsRUFBRSxNQUFNLG9CQUFvQixDQUFDO0FBdUMvQyxNQUFNLE9BQU8sZ0JBQWdCO0lBa0J6QjtJQUNJLHVDQUF1QztJQUN2QywyQkFBMkI7SUFDbkIsUUFBbUI7UUFBbkIsYUFBUSxHQUFSLFFBQVEsQ0FBVztRQXBCeEIsYUFBUSxHQUF1QjtZQUNsQyxNQUFNLEVBQUUsRUFBRTtZQUNWLFVBQVUsRUFBRSxFQUFFO1lBQ2QsV0FBVyxFQUFFLEVBQUU7WUFDZixVQUFVLEVBQUUsRUFBRTtTQUNqQixDQUFDO0lBa0JGLENBQUM7SUFFRCxRQUFRO1FBQ0osSUFBSSxDQUFDLFFBQVEsRUFBRSxDQUFDO0lBQ3BCLENBQUM7SUFFRCxXQUFXO0lBRVgsQ0FBQztJQUVNLGdCQUFnQixDQUFDLFFBQWE7UUFDakMsc0VBQXNFO0lBQzFFLENBQUM7SUFFTSxrQkFBa0IsQ0FBQyxPQUFZO1FBQ2xDLHlEQUF5RDtJQUM3RCxDQUFDO0lBRU8sUUFBUTtRQUNaLElBQUksQ0FBQyxJQUFJLENBQUMsR0FBRztZQUFFLE9BQU87UUFFdEIsNEJBQTRCO1FBQzVCLElBQUksQ0FBQyxRQUFRLENBQUMsaUJBQWlCLENBQUMsSUFBSSxDQUFDLEdBQUcsRUFBRSxJQUFJLENBQUMsUUFBUSxDQUFDLENBQUM7UUFFekQsNkJBQTZCO1FBQzdCLHVDQUF1QztJQUMzQyxDQUFDOzs7WUFwRkosU0FBUyxTQUFDO2dCQUNQLFFBQVEsRUFBRSxvQkFBb0I7Z0JBQzlCLFFBQVEsRUFBRTs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0tBd0JUO2dCQUNELFNBQVMsRUFBRTtvQkFDUCxTQUFTO29CQUNULGtCQUFrQjtpQkFDckI7YUFDSjs7O1lBcENRLFNBQVM7Ozs0QkFrRGIsS0FBSyxTQUFDLFlBQVk7MkJBQ2xCLEtBQUssU0FBQyxRQUFROytCQUNkLEtBQUssU0FBQyxZQUFZOytCQUNsQixLQUFLLFNBQUMsYUFBYTs2QkFDbkIsS0FBSyxTQUFDLFFBQVE7a0JBQ2QsS0FBSyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7XHJcbiAgICBDb21wb25lbnQsXHJcbiAgICBPbkluaXQsXHJcbiAgICBPbkRlc3Ryb3ksXHJcbiAgICBJbnB1dFxyXG59IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xyXG4vLyBpbXBvcnQgeyBTdWJzY3JpcHRpb24gfSBmcm9tICdyeGpzL1N1YnNjcmlwdGlvbic7XHJcbi8vIGltcG9ydCB7IFJvdXRlciB9IGZyb20gJ0Bhbmd1bGFyL3JvdXRlcic7XHJcbi8vIGltcG9ydCB7IEtkVGVtcGxhdGVMYXlvdXRTdmMgfSBmcm9tICcuL2tkLWFuZ3VsYXItdGVtcGxhdGUtbGF5b3V0LXN2Yyc7XHJcbmltcG9ydCB7IElUZW1wbGF0ZUxheW91dEFQSSB9IGZyb20gJy4va2QtYW5ndWxhci10ZW1wbGF0ZS1sYXlvdXQtaW50ZXJmYWNlJztcclxuaW1wb3J0IHsgLypJSGVhZGVyQVBJLCovIElIZWFkZXJDb25maWcgfSBmcm9tICcuLi9rZC1hbmd1bGFyLWhlYWRlci9pbmRleCc7XHJcbmltcG9ydCB7IElCcmVhZGNydW1iQ29uZmlnIH0gZnJvbSAnLi4va2QtYW5ndWxhci1icmVhZGNydW1iL2luZGV4JztcclxuaW1wb3J0IHsgS2REYXRhU3ZjIH0gZnJvbSAnLi4va2QtY29tbW9uL2luZGV4JztcclxuXHJcbmltcG9ydCB7IC8qSVBhZ2VoZWFkZXJBcGksKi8gSVBhZ2VoZWFkZXJDb25maWcgfSBmcm9tICcuLi9rZC1hbmd1bGFyLXBhZ2VoZWFkZXIvaW5kZXgnO1xyXG5cclxuXHJcbkBDb21wb25lbnQoe1xyXG4gICAgc2VsZWN0b3I6ICdrZC10ZW1wbGF0ZS1sYXlvdXQnLFxyXG4gICAgdGVtcGxhdGU6IGBcclxuICAgICAgICA8a2Qtc3BsaXR0ZXIgY2xhc3M9J2hhcy1oZWFkZXIgaGFzLWZvb3RlciBtYWluJz5cclxuICAgICAgICAgICAgPGtkLXBhbmUgc2l6ZT0nMTAlJyBtYXg9JzMwJScgbWluPScyJSc+XHJcbiAgICAgICAgICAgICAgICA8a2QtbGVmdG1lbnUgW2NvbmZpZ109J2xlZnROYXZDb25maWcnIFthcGldPSdsb2NhbEFwaS5uYXZpZ2F0aW9uJz48L2tkLWxlZnRtZW51PlxyXG4gICAgICAgICAgICA8L2tkLXBhbmU+XHJcbiAgICAgICAgICAgIDxrZC1wYW5lPlxyXG4gICAgICAgICAgICAgICAgPG5nLXRlbXBsYXRlIG5nYk1vZGFsQ29udGFpbmVyPjwvbmctdGVtcGxhdGU+XHJcbiAgICAgICAgICAgICAgICA8a2QtYWxlcnQ+PC9rZC1hbGVydD5cclxuICAgICAgICAgICAgICAgIDxrZC1oZWFkZXIgW2NvbmZpZ109J2hlYWRlckNvbmZpZycgW2FwaV09J2xvY2FsQXBpLmhlYWRlcic+PC9rZC1oZWFkZXI+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzPSdtYWluLXdyYXBwZXInPlxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3M9J2NvbnRlbnQtd3JhcHBlcic+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxrZC1icmVhZGNydW1iIFtjb25maWddPSdicmVhZGNydW1iQ29uZmlnJyBbYXBpXT0nbG9jYWxBcGkuYnJlYWRjcnVtYnMnPjwva2QtYnJlYWRjcnVtYj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGtkLXBhZ2VoZWFkZXIgW2NvbmZpZ109J3BhZ2VIZWFkZXJDb25maWcnIFthcGldPSdsb2NhbEFwaS5wYWdlSGVhZGVyJz48L2tkLXBhZ2VoZWFkZXI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3M9J2NvbnRlbnQtYXJlYSc+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzPSdjb250ZW50Jz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8cm91dGVyLW91dGxldD48L3JvdXRlci1vdXRsZXQ+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxrZC1mb290ZXIgZW5hYmxlRmxvYXQ9J3RydWUnPjwva2QtZm9vdGVyPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPCEtLSA8a2QtYWR2LXNlYXJjaCBbZm9ybURhdGFdPSdzZWFyY2hGb3JtRGF0YScgKGZpZWxkVmFsdWUpPSdjaGFuZ2VEZXRlY3RGcm9tKCRldmVudCknIChmb3JtVmFsdWUpPSdzdWJtaXR0ZWRGb3JtVmFsdWUoJGV2ZW50KSc+PC9rZC1hZHYtc2VhcmNoPiAtLT5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8L2tkLXBhbmU+XHJcbiAgICAgICAgPC9rZC1zcGxpdHRlcj5cclxuICAgIGAsXHJcbiAgICBwcm92aWRlcnM6IFtcclxuICAgICAgICBLZERhdGFTdmNcclxuICAgICAgICAvLyBLZFBhZ2VCYXNlRXZlbnRcclxuICAgIF1cclxufSlcclxuXHJcblxyXG5leHBvcnQgY2xhc3MgS2RUZW1wbGF0ZUxheW91dCBpbXBsZW1lbnRzIE9uSW5pdCwgT25EZXN0cm95IHtcclxuICAgIHB1YmxpYyBsb2NhbEFwaTogSVRlbXBsYXRlTGF5b3V0QVBJID0ge1xyXG4gICAgICAgIGhlYWRlcjoge30sXHJcbiAgICAgICAgcGFnZUhlYWRlcjoge30sXHJcbiAgICAgICAgYnJlYWRjcnVtYnM6IHt9LFxyXG4gICAgICAgIG5hdmlnYXRpb246IHt9XHJcbiAgICB9O1xyXG5cclxuICAgIC8vIHByaXZhdGUgX3BhZ2VoZWFkZXJTdWI6IFN1YnNjcmlwdGlvbjtcclxuICAgIC8vIHByaXZhdGUgX2JyZWFkY3J1bWJTdWI6IFN1YnNjcmlwdGlvbjtcclxuXHJcbiAgICBASW5wdXQoJ25hdmlnYXRpb24nKSBsZWZ0TmF2Q29uZmlnOiBhbnk7XHJcbiAgICBASW5wdXQoJ2hlYWRlcicpIGhlYWRlckNvbmZpZzogSUhlYWRlckNvbmZpZztcclxuICAgIEBJbnB1dCgncGFnZWhlYWRlcicpIHBhZ2VIZWFkZXJDb25maWc6IElQYWdlaGVhZGVyQ29uZmlnO1xyXG4gICAgQElucHV0KCdicmVhZGNydW1icycpIGJyZWFkY3J1bWJDb25maWc6IElCcmVhZGNydW1iQ29uZmlnO1xyXG4gICAgQElucHV0KCdzZWFyY2gnKSBzZWFyY2hGb3JtRGF0YTogYW55O1xyXG4gICAgQElucHV0KCkgYXBpOiBhbnk7XHJcblxyXG4gICAgY29uc3RydWN0b3IoXHJcbiAgICAgICAgLy8gcHJpdmF0ZSBfcGFnZUV2ZW50OiBLZFBhZ2VCYXNlRXZlbnQsXHJcbiAgICAgICAgLy8gcHJpdmF0ZSBfcm91dGVyOiBSb3V0ZXIsXHJcbiAgICAgICAgcHJpdmF0ZSBfZGF0YVN2YzogS2REYXRhU3ZjLFxyXG4gICAgKSB7XHJcblxyXG4gICAgfVxyXG5cclxuICAgIG5nT25Jbml0KCk6IHZvaWQge1xyXG4gICAgICAgIHRoaXMuX2luaXRBcGkoKTtcclxuICAgIH1cclxuXHJcbiAgICBuZ09uRGVzdHJveSgpOiB2b2lkIHtcclxuXHJcbiAgICB9XHJcblxyXG4gICAgcHVibGljIGNoYW5nZURldGVjdEZyb20ocXVlc3Rpb246IGFueSk6IHZvaWQge1xyXG4gICAgICAgIC8vIGNvbnNvbGUubG9nKCdBZHYgc2VhcmNoIGNvbXBvbmVudCBjaGFuZ2UgZGV0ZWN0IGZyb206ICcsIHF1ZXN0aW9uKTtcclxuICAgIH1cclxuXHJcbiAgICBwdWJsaWMgc3VibWl0dGVkRm9ybVZhbHVlKGZvcm1WYWw6IGFueSk6IHZvaWQge1xyXG4gICAgICAgIC8vIGNvbnNvbGUubG9nKCdBZHYgc2VhcmNoIGZvcm0gc3VibWl0IGRhdGE6ICcsIGZvcm1WYWwpO1xyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX2luaXRBcGkoKSB7XHJcbiAgICAgICAgaWYgKCF0aGlzLmFwaSkgcmV0dXJuO1xyXG5cclxuICAgICAgICAvLyB0aGlzLmFwaSA9IHRoaXMubG9jYWxBcGk7XHJcbiAgICAgICAgdGhpcy5fZGF0YVN2Yy5kZWVwQ29tYmluZU9iamVjdCh0aGlzLmFwaSwgdGhpcy5sb2NhbEFwaSk7XHJcblxyXG4gICAgICAgIC8vIHRoaXMuX2Nkci5kZXRlY3RDaGFuZ2VzKCk7XHJcbiAgICAgICAgLy8gY29uc29sZS5sb2coJ3NldCB0byBhcGknLCB0aGlzLmFwaSk7XHJcbiAgICB9XHJcbn1cclxuIl19