import { Injectable } from '@angular/core';
import * as i0 from "@angular/core";
export class KdTemplateLayoutSvc {
    constructor() {
        this._api = {};
    }
    setApi(_name, _api) {
        if (typeof _name !== undefined && _name !== '' && typeof _api !== undefined) {
            this._api[_name] = _api;
        }
    }
    getApi(_name) {
        if (typeof _name === undefined || _name === '' || !this._api.hasOwnProperty(_name))
            return undefined;
        return this._api[_name];
    }
}
KdTemplateLayoutSvc.ɵprov = i0.ɵɵdefineInjectable({ factory: function KdTemplateLayoutSvc_Factory() { return new KdTemplateLayoutSvc(); }, token: KdTemplateLayoutSvc, providedIn: "root" });
KdTemplateLayoutSvc.decorators = [
    { type: Injectable, args: [{
                providedIn: 'root'
            },] }
];
KdTemplateLayoutSvc.ctorParameters = () => [];
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoia2QtYW5ndWxhci10ZW1wbGF0ZS1sYXlvdXQtc3ZjLmpzIiwic291cmNlUm9vdCI6IkQ6L29wZW5FTUlTL3N0eWxlZ3VpZGUvaW9zdGctb3BlbmVtaXMtc3R5bGVndWlkZS9wcm9qZWN0cy9vcGVuZW1pcy1zdHlsZWd1aWRlLWxpYi9zcmMvIiwic291cmNlcyI6WyJrZC1jb21wb25lbnRzL2tkLWFuZ3VsYXItdGVtcGxhdGUtbGF5b3V0L2tkLWFuZ3VsYXItdGVtcGxhdGUtbGF5b3V0LXN2Yy50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQSxPQUFPLEVBQUUsVUFBVSxFQUFFLE1BQU0sZUFBZSxDQUFDOztBQUszQyxNQUFNLE9BQU8sbUJBQW1CO0lBRzVCO1FBRlEsU0FBSSxHQUFRLEVBQUUsQ0FBQztJQUVQLENBQUM7SUFFVixNQUFNLENBQUMsS0FBYSxFQUFFLElBQVM7UUFDbEMsSUFBSSxPQUFPLEtBQUssS0FBSyxTQUFTLElBQUksS0FBSyxLQUFLLEVBQUUsSUFBSSxPQUFPLElBQUksS0FBSyxTQUFTLEVBQUU7WUFDekUsSUFBSSxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsR0FBRyxJQUFJLENBQUM7U0FDM0I7SUFDTCxDQUFDO0lBRU0sTUFBTSxDQUFDLEtBQWE7UUFDdkIsSUFBSSxPQUFPLEtBQUssS0FBSyxTQUFTLElBQUksS0FBSyxLQUFLLEVBQUUsSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsY0FBYyxDQUFDLEtBQUssQ0FBQztZQUFFLE9BQU8sU0FBUyxDQUFDO1FBQ3JHLE9BQU8sSUFBSSxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQztJQUM1QixDQUFDOzs7O1lBakJKLFVBQVUsU0FBQztnQkFDUixVQUFVLEVBQUUsTUFBTTthQUNyQiIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IEluamVjdGFibGUgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcclxuXHJcbkBJbmplY3RhYmxlKHtcclxuICAgIHByb3ZpZGVkSW46ICdyb290J1xyXG59KVxyXG5leHBvcnQgY2xhc3MgS2RUZW1wbGF0ZUxheW91dFN2YyB7XHJcbiAgICBwcml2YXRlIF9hcGk6IGFueSA9IHt9O1xyXG5cclxuICAgIGNvbnN0cnVjdG9yKCkgeyB9XHJcblxyXG4gICAgcHVibGljIHNldEFwaShfbmFtZTogc3RyaW5nLCBfYXBpOiBhbnkpOiB2b2lkIHtcclxuICAgICAgICBpZiAodHlwZW9mIF9uYW1lICE9PSB1bmRlZmluZWQgJiYgX25hbWUgIT09ICcnICYmIHR5cGVvZiBfYXBpICE9PSB1bmRlZmluZWQpIHtcclxuICAgICAgICAgICAgdGhpcy5fYXBpW19uYW1lXSA9IF9hcGk7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIHB1YmxpYyBnZXRBcGkoX25hbWU6IHN0cmluZyk6IGFueSB7XHJcbiAgICAgICAgaWYgKHR5cGVvZiBfbmFtZSA9PT0gdW5kZWZpbmVkIHx8IF9uYW1lID09PSAnJyB8fCAhdGhpcy5fYXBpLmhhc093blByb3BlcnR5KF9uYW1lKSkgcmV0dXJuIHVuZGVmaW5lZDtcclxuICAgICAgICByZXR1cm4gdGhpcy5fYXBpW19uYW1lXTtcclxuICAgIH1cclxufVxyXG4iXX0=