import { timer as observableTimer, fromEvent } from 'rxjs';
import { debounceTime } from 'rxjs/operators';
/*******************************************************************************
    Component file     : kd-angular-pageheader.ts
    Service file       : kd-angular-pageheader-svc.ts
    Event file         : -
    Interface file     : kd-angular-pageheader-interface.ts
    Version            : 2.0
    Created by         : Cheng Kok Keong
    Purpose            : Show the title of the current page in the template area under breadcrumb

    Behaviour           :
        - Behaviour for page title element:
            --------------------------------------------------------------------------
            | Case | Left buttons | Search button | More button | Width              |
            --------------------------------------------------------------------------
            |  Left buttons                                                          |
            |      | (/)          | (/)           | (/)         | 200px              |
            |      | (/)          | (/)           | (x)         | 200px              |
            |      | (/)          | (x)           | (/)         | 200px              |
            |      | (/)          | (x)           | (x)         | 200px              |
            --------------------------------------------------------------------------
            |  Search buttons                                                        |
            |      | (x)          | (/)           | (/)         | calc(100% - 340px) |
            |      | (x)          | (/)           | (x)         | calc(100% - 300px) |
            --------------------------------------------------------------------------
            |  More buttons                                                          |
            |      | (x)          | (x)           | (/)         | calc(100% - 40px)  |
            --------------------------------------------------------------------------
            |  No buttons                                                            |
            |      | (x)          | (x)           | (x)         | 100%               |
            --------------------------------------------------------------------------

    Last change         :
        - Rewrite component and service

 *******************************************************************************/
import { Component, Input, ViewEncapsulation, HostBinding, ViewContainerRef, } from '@angular/core';
import { KdPageheaderSvc } from './kd-angular-pageheader-svc';
import { DELAY_TIME } from '../kd-common/index';
export class KdPageheader {
    constructor(_vcr, _pageheaderSvc) {
        this._vcr = _vcr;
        this._pageheaderSvc = _pageheaderSvc;
        this.toolbarExist = false;
        this.expendTitle = false;
        this.toggleTransition = false;
        this.titleClickable = false;
        this.checkTitleComplete = false;
        this.hideToolbar = false;
        this._subscriptionObj = {};
        this.hasLeftBtns = false;
        this.hasSearchBtn = false;
        this.hasMoreBtn = false;
        this.mobileView = false;
    }
    /************************* Life cycles functions *****************************/
    ngOnInit() {
        // console.log('-- Pageheader Component: OnInit --', this.config);
        this._setTransitionTo(false);
        this._setupObservableEvents();
        this._processConfigCycle();
        this._generateApi(this.api, this.config);
    }
    ngOnChanges(_simpleChanges) {
        // console.log('-- Pageheader Component: OnChanges --', _simpleChanges);
        if (_simpleChanges.hasOwnProperty('config') && !_simpleChanges['config'].firstChange) {
            this._processConfigCycle();
            this._updateDOMCycle(DELAY_TIME);
        }
    }
    ngAfterViewInit() {
        // console.log('-- Pageheader Component: AfterViewInit --');
        this._updateDOMCycle();
    }
    ngOnDestroy() {
        // console.log('-- Pageheader Component: OnDestroy --');
        for (let subObject in this._subscriptionObj) {
            if (this._subscriptionObj.hasOwnProperty(subObject)) {
                this._subscriptionObj[subObject].unsubscribe();
            }
        }
    }
    /**************************** Events functions *******************************/
    titleClicked(_event) {
        if (this.mobileView || !this.titleClickable)
            return;
        this.expendTitle = !this.expendTitle;
    }
    updateSearchText(_searchText) {
        this.config.searchText = _searchText;
    }
    /**************************** Private functions ******************************/
    ///////////////////////////////////////////////////////
    /// Cycle events
    ///////////////////////////////////////////////////////
    _processConfigCycle() {
        if (typeof this.config === 'undefined') {
            this.config = {};
        }
        this.toolbarConfig = this._pageheaderSvc.updateToolbarConfig(this.config);
        this._updateToolbarExist();
        this._updateHostBinding();
    }
    _updateDOMCycle(_delayTime = 1) {
        observableTimer().subscribe(() => {
            this._updateViewClass();
            this._updateClickableCycle(_delayTime);
        });
    }
    _updateClickableCycle(_delayTime = 1) {
        if (this._subscriptionObj.hasOwnProperty('timer')) {
            this._subscriptionObj['timer'].unsubscribe();
        }
        this.checkTitleComplete = false;
        this._setTitleClickable(_delayTime);
    }
    ///////////////////////////////////////////////////////
    /// DOM Cycle function
    ///////////////////////////////////////////////////////
    _setupObservableEvents() {
        this._subscriptionObj['resize'] = fromEvent(window, 'resize')
            .pipe(debounceTime(DELAY_TIME))
            .subscribe((_event) => {
            this._updateDOMCycle();
        });
    }
    _updateViewClass() {
        this.mobileView = window.innerWidth <= 1024;
        if (this.mobileView) {
            this.expendTitle = false;
        }
    }
    _setTransitionTo(_toggle) {
        this.toggleTransition = _toggle;
    }
    _setTitleClickable(_delay) {
        this._subscriptionObj['timer'] = observableTimer(_delay)
            .subscribe(() => {
            let titleElement = this._vcr.element.nativeElement.querySelector('.title');
            let actualElement = this._vcr.element.nativeElement.querySelector('#heightCheck');
            if (titleElement !== null && actualElement !== null) {
                this.titleClickable = titleElement.getBoundingClientRect().width < actualElement.getBoundingClientRect().width;
            }
            else {
                this.titleClickable = false;
            }
            this._setTransitionTo(true);
            this.checkTitleComplete = true;
        });
    }
    _updateHostBinding() {
        this.hasLeftBtns = this.toolbarConfig.leftBtn.length > 0;
        this.hasMoreBtn = this.toolbarConfig.moreAction.length > 0;
        this.hasSearchBtn = this.toolbarConfig.searchBtn;
    }
    ///////////////////////////////////////////////////////
    /// API Generation
    ///////////////////////////////////////////////////////
    _generateApi(_api, _config) {
        if (typeof _api !== 'undefined') {
            _api.updateTitle = (_newTitle = '') => {
                _config.pageheaderText = _newTitle;
                this._updateClickableCycle();
            };
            _api.updateLeftButton = (_newLeftBtn) => {
                this._setTransitionTo(false);
                this.config.leftBtn = _newLeftBtn;
                this._processConfigCycle();
                this._updateClickableCycle(DELAY_TIME);
            };
            _api.updateMoreButton = (_enabled, _list) => {
                this._setTransitionTo(false);
                this.config.moreBtn = _enabled;
                this.config.moreAction = _list;
                this._processConfigCycle();
                this._updateClickableCycle(DELAY_TIME);
            };
            _api.updateSearchButton = (_searchConfig) => {
                this._setTransitionTo(false);
                this.config = Object.assign(this.config, _searchConfig);
                this._processConfigCycle();
                this._updateClickableCycle(DELAY_TIME);
            };
        }
        else {
            console.warn('KdPageheader warning: No api is passed in.');
        }
    }
    ///////////////////////////////////////////////////////
    /// Config functions
    ///////////////////////////////////////////////////////
    _updateToolbarExist() {
        this.toolbarExist = this._pageheaderSvc.isToolbarExist(this.config);
    }
}
KdPageheader.decorators = [
    { type: Component, args: [{
                selector: 'kd-pageheader',
                template: "<div class='kdx-page-header'>\r\n    <div class='title' \r\n        [ngClass]=\" {\r\n            'expend-title': expendTitle && titleClickable,\r\n            'collapse-title': !expendTitle && titleClickable,\r\n            'animation': toggleTransition \r\n        }\" (click)='titleClicked($event)'>\r\n            <h2 class='page-title'>{{config.pageheaderText}}</h2>\r\n            <i class=\"arrow-icon\"></i>\r\n    </div>\r\n    <ng-template [ngIf]='toolbarExist'>\r\n        <kd-toolbar \r\n            class='page-toolbar'\r\n            [ngClass]=\"{'hide-toolbar': hideToolbar}\"\r\n            [config]='toolbarConfig'\r\n            [mobileView]='mobileView'\r\n            (searchTextChanged)='updateSearchText($event)'\r\n        ></kd-toolbar>\r\n    </ng-template>\r\n</div>\r\n<h2 *ngIf=\"!checkTitleComplete\" id='heightCheck' style=\"position: absolute; z-index: -1;\">{{config.pageheaderText}}</h2>\r\n",
                encapsulation: ViewEncapsulation.None,
                providers: [KdPageheaderSvc]
            },] }
];
KdPageheader.ctorParameters = () => [
    { type: ViewContainerRef },
    { type: KdPageheaderSvc }
];
KdPageheader.propDecorators = {
    config: [{ type: Input }],
    api: [{ type: Input }],
    hasLeftBtns: [{ type: HostBinding, args: ['class.has-left-btn',] }],
    hasSearchBtn: [{ type: HostBinding, args: ['class.has-search-btn',] }],
    hasMoreBtn: [{ type: HostBinding, args: ['class.has-more-btn',] }],
    mobileView: [{ type: HostBinding, args: ['class.pageheader-mobile',] }]
};
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoia2QtYW5ndWxhci1wYWdlaGVhZGVyLmpzIiwic291cmNlUm9vdCI6IkQ6L29wZW5FTUlTL3N0eWxlZ3VpZGUvaW9zdGctb3BlbmVtaXMtc3R5bGVndWlkZS9wcm9qZWN0cy9vcGVuZW1pcy1zdHlsZWd1aWRlLWxpYi9zcmMvIiwic291cmNlcyI6WyJrZC1jb21wb25lbnRzL2tkLWFuZ3VsYXItcGFnZWhlYWRlci9rZC1hbmd1bGFyLXBhZ2VoZWFkZXIudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQ0EsT0FBTyxFQUFFLEtBQUssSUFBSSxlQUFlLEVBQWdCLFNBQVMsRUFBRSxNQUFNLE1BQU0sQ0FBQztBQUN6RSxPQUFPLEVBQUUsWUFBWSxFQUFFLE1BQU0sZ0JBQWdCLENBQUM7QUFDOUM7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7aUZBa0NpRjtBQUlqRixPQUFPLEVBQ0gsU0FBUyxFQU1ULEtBQUssRUFDTCxpQkFBaUIsRUFDakIsV0FBVyxFQUNYLGdCQUFnQixHQUNuQixNQUFNLGVBQWUsQ0FBQztBQUN2QixPQUFPLEVBQUUsZUFBZSxFQUFFLE1BQU0sNkJBQTZCLENBQUM7QUFTOUQsT0FBTyxFQUFFLFVBQVUsRUFBRSxNQUFNLG9CQUFvQixDQUFDO0FBU2hELE1BQU0sT0FBTyxZQUFZO0lBa0JyQixZQUNZLElBQXNCLEVBQ3RCLGNBQStCO1FBRC9CLFNBQUksR0FBSixJQUFJLENBQWtCO1FBQ3RCLG1CQUFjLEdBQWQsY0FBYyxDQUFpQjtRQWxCcEMsaUJBQVksR0FBWSxLQUFLLENBQUM7UUFDOUIsZ0JBQVcsR0FBWSxLQUFLLENBQUM7UUFDN0IscUJBQWdCLEdBQVksS0FBSyxDQUFDO1FBQ2xDLG1CQUFjLEdBQVksS0FBSyxDQUFDO1FBQ2hDLHVCQUFrQixHQUFZLEtBQUssQ0FBQztRQUNwQyxnQkFBVyxHQUFZLEtBQUssQ0FBQztRQUU1QixxQkFBZ0IsR0FBb0MsRUFBRSxDQUFDO1FBSTVCLGdCQUFXLEdBQVksS0FBSyxDQUFDO1FBQzNCLGlCQUFZLEdBQVksS0FBSyxDQUFDO1FBQ2hDLGVBQVUsR0FBWSxLQUFLLENBQUM7UUFDdkIsZUFBVSxHQUFZLEtBQUssQ0FBQztJQUtoRSxDQUFDO0lBRUwsK0VBQStFO0lBQy9FLFFBQVE7UUFDSixrRUFBa0U7UUFDbEUsSUFBSSxDQUFDLGdCQUFnQixDQUFDLEtBQUssQ0FBQyxDQUFDO1FBQzdCLElBQUksQ0FBQyxzQkFBc0IsRUFBRSxDQUFDO1FBQzlCLElBQUksQ0FBQyxtQkFBbUIsRUFBRSxDQUFDO1FBQzNCLElBQUksQ0FBQyxZQUFZLENBQUMsSUFBSSxDQUFDLEdBQUcsRUFBRSxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUM7SUFDN0MsQ0FBQztJQUVELFdBQVcsQ0FBQyxjQUE2QjtRQUNyQyx3RUFBd0U7UUFDeEUsSUFBSSxjQUFjLENBQUMsY0FBYyxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsY0FBYyxDQUFDLFFBQVEsQ0FBQyxDQUFDLFdBQVcsRUFBRTtZQUNsRixJQUFJLENBQUMsbUJBQW1CLEVBQUUsQ0FBQztZQUMzQixJQUFJLENBQUMsZUFBZSxDQUFDLFVBQVUsQ0FBQyxDQUFDO1NBQ3BDO0lBQ0wsQ0FBQztJQUVELGVBQWU7UUFDWCw0REFBNEQ7UUFDNUQsSUFBSSxDQUFDLGVBQWUsRUFBRSxDQUFDO0lBQzNCLENBQUM7SUFFRCxXQUFXO1FBQ1Asd0RBQXdEO1FBQ3hELEtBQUssSUFBSSxTQUFTLElBQUksSUFBSSxDQUFDLGdCQUFnQixFQUFFO1lBQ3pDLElBQUksSUFBSSxDQUFDLGdCQUFnQixDQUFDLGNBQWMsQ0FBQyxTQUFTLENBQUMsRUFBRTtnQkFDakQsSUFBSSxDQUFDLGdCQUFnQixDQUFDLFNBQVMsQ0FBQyxDQUFDLFdBQVcsRUFBRSxDQUFDO2FBQ2xEO1NBQ0o7SUFDTCxDQUFDO0lBRUQsK0VBQStFO0lBQ3hFLFlBQVksQ0FBQyxNQUFhO1FBQzdCLElBQUksSUFBSSxDQUFDLFVBQVUsSUFBSSxDQUFDLElBQUksQ0FBQyxjQUFjO1lBQUUsT0FBTztRQUVwRCxJQUFJLENBQUMsV0FBVyxHQUFHLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQztJQUN6QyxDQUFDO0lBRU0sZ0JBQWdCLENBQUMsV0FBbUI7UUFDdkMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxVQUFVLEdBQUcsV0FBVyxDQUFDO0lBQ3pDLENBQUM7SUFFRCwrRUFBK0U7SUFDL0UsdURBQXVEO0lBQ3ZELGdCQUFnQjtJQUNoQix1REFBdUQ7SUFDL0MsbUJBQW1CO1FBQ3ZCLElBQUksT0FBTyxJQUFJLENBQUMsTUFBTSxLQUFLLFdBQVcsRUFBRTtZQUNwQyxJQUFJLENBQUMsTUFBTSxHQUFHLEVBQUUsQ0FBQztTQUNwQjtRQUVELElBQUksQ0FBQyxhQUFhLEdBQUcsSUFBSSxDQUFDLGNBQWMsQ0FBQyxtQkFBbUIsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUM7UUFDMUUsSUFBSSxDQUFDLG1CQUFtQixFQUFFLENBQUM7UUFDM0IsSUFBSSxDQUFDLGtCQUFrQixFQUFFLENBQUM7SUFDOUIsQ0FBQztJQUVPLGVBQWUsQ0FBQyxhQUFxQixDQUFDO1FBQzFDLGVBQWUsRUFBRSxDQUFDLFNBQVMsQ0FBQyxHQUFTLEVBQUU7WUFDbkMsSUFBSSxDQUFDLGdCQUFnQixFQUFFLENBQUM7WUFDeEIsSUFBSSxDQUFDLHFCQUFxQixDQUFDLFVBQVUsQ0FBQyxDQUFDO1FBQzNDLENBQUMsQ0FBQyxDQUFDO0lBQ1AsQ0FBQztJQUVPLHFCQUFxQixDQUFDLGFBQXFCLENBQUM7UUFDaEQsSUFBSSxJQUFJLENBQUMsZ0JBQWdCLENBQUMsY0FBYyxDQUFDLE9BQU8sQ0FBQyxFQUFFO1lBQy9DLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxPQUFPLENBQUMsQ0FBQyxXQUFXLEVBQUUsQ0FBQztTQUNoRDtRQUVELElBQUksQ0FBQyxrQkFBa0IsR0FBRyxLQUFLLENBQUM7UUFDaEMsSUFBSSxDQUFDLGtCQUFrQixDQUFDLFVBQVUsQ0FBQyxDQUFDO0lBQ3hDLENBQUM7SUFFRCx1REFBdUQ7SUFDdkQsc0JBQXNCO0lBQ3RCLHVEQUF1RDtJQUMvQyxzQkFBc0I7UUFDMUIsSUFBSSxDQUFDLGdCQUFnQixDQUFDLFFBQVEsQ0FBQyxHQUFHLFNBQVMsQ0FBQyxNQUFNLEVBQUUsUUFBUSxDQUFDO2FBQ3hELElBQUksQ0FDRCxZQUFZLENBQUMsVUFBVSxDQUFDLENBQzNCO2FBQ0EsU0FBUyxDQUNOLENBQUMsTUFBYSxFQUFRLEVBQUU7WUFDcEIsSUFBSSxDQUFDLGVBQWUsRUFBRSxDQUFDO1FBQzNCLENBQUMsQ0FDSixDQUFDO0lBQ1YsQ0FBQztJQUVPLGdCQUFnQjtRQUNwQixJQUFJLENBQUMsVUFBVSxHQUFHLE1BQU0sQ0FBQyxVQUFVLElBQUksSUFBSSxDQUFDO1FBRTVDLElBQUksSUFBSSxDQUFDLFVBQVUsRUFBRTtZQUNqQixJQUFJLENBQUMsV0FBVyxHQUFHLEtBQUssQ0FBQztTQUM1QjtJQUNMLENBQUM7SUFFTyxnQkFBZ0IsQ0FBQyxPQUFnQjtRQUNyQyxJQUFJLENBQUMsZ0JBQWdCLEdBQUcsT0FBTyxDQUFDO0lBQ3BDLENBQUM7SUFFTyxrQkFBa0IsQ0FBQyxNQUFjO1FBQ3JDLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxPQUFPLENBQUMsR0FBRyxlQUFlLENBQUMsTUFBTSxDQUFDO2FBQ25ELFNBQVMsQ0FDTixHQUFTLEVBQUU7WUFDUCxJQUFJLFlBQVksR0FBWSxJQUFJLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxhQUFhLENBQUMsYUFBYSxDQUFDLFFBQVEsQ0FBQyxDQUFDO1lBQ3BGLElBQUksYUFBYSxHQUFZLElBQUksQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLGFBQWEsQ0FBQyxhQUFhLENBQUMsY0FBYyxDQUFDLENBQUM7WUFFM0YsSUFBSSxZQUFZLEtBQUssSUFBSSxJQUFJLGFBQWEsS0FBSyxJQUFJLEVBQUU7Z0JBQ2pELElBQUksQ0FBQyxjQUFjLEdBQUcsWUFBWSxDQUFDLHFCQUFxQixFQUFFLENBQUMsS0FBSyxHQUFHLGFBQWEsQ0FBQyxxQkFBcUIsRUFBRSxDQUFDLEtBQUssQ0FBQzthQUNsSDtpQkFDSTtnQkFDRCxJQUFJLENBQUMsY0FBYyxHQUFHLEtBQUssQ0FBQzthQUMvQjtZQUVELElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxJQUFJLENBQUMsQ0FBQztZQUM1QixJQUFJLENBQUMsa0JBQWtCLEdBQUcsSUFBSSxDQUFDO1FBQ25DLENBQUMsQ0FDSixDQUFDO0lBQ1YsQ0FBQztJQUVPLGtCQUFrQjtRQUN0QixJQUFJLENBQUMsV0FBVyxHQUFHLElBQUksQ0FBQyxhQUFhLENBQUMsT0FBTyxDQUFDLE1BQU0sR0FBRyxDQUFDLENBQUM7UUFDekQsSUFBSSxDQUFDLFVBQVUsR0FBRyxJQUFJLENBQUMsYUFBYSxDQUFDLFVBQVUsQ0FBQyxNQUFNLEdBQUcsQ0FBQyxDQUFDO1FBQzNELElBQUksQ0FBQyxZQUFZLEdBQUcsSUFBSSxDQUFDLGFBQWEsQ0FBQyxTQUFTLENBQUM7SUFDckQsQ0FBQztJQUVELHVEQUF1RDtJQUN2RCxrQkFBa0I7SUFDbEIsdURBQXVEO0lBQy9DLFlBQVksQ0FBQyxJQUFvQixFQUFFLE9BQTBCO1FBQ2pFLElBQUksT0FBTyxJQUFJLEtBQUssV0FBVyxFQUFFO1lBQzdCLElBQUksQ0FBQyxXQUFXLEdBQUcsQ0FBQyxZQUFvQixFQUFFLEVBQVEsRUFBRTtnQkFDaEQsT0FBTyxDQUFDLGNBQWMsR0FBRyxTQUFTLENBQUM7Z0JBQ25DLElBQUksQ0FBQyxxQkFBcUIsRUFBRSxDQUFDO1lBQ2pDLENBQUMsQ0FBQztZQUVGLElBQUksQ0FBQyxnQkFBZ0IsR0FBRyxDQUFDLFdBQW1DLEVBQVEsRUFBRTtnQkFDbEUsSUFBSSxDQUFDLGdCQUFnQixDQUFDLEtBQUssQ0FBQyxDQUFDO2dCQUM3QixJQUFJLENBQUMsTUFBTSxDQUFDLE9BQU8sR0FBRyxXQUFXLENBQUM7Z0JBQ2xDLElBQUksQ0FBQyxtQkFBbUIsRUFBRSxDQUFDO2dCQUMzQixJQUFJLENBQUMscUJBQXFCLENBQUMsVUFBVSxDQUFDLENBQUM7WUFDM0MsQ0FBQyxDQUFDO1lBRUYsSUFBSSxDQUFDLGdCQUFnQixHQUFHLENBQUMsUUFBaUIsRUFBRSxLQUFnQyxFQUFRLEVBQUU7Z0JBQ2xGLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxLQUFLLENBQUMsQ0FBQztnQkFDN0IsSUFBSSxDQUFDLE1BQU0sQ0FBQyxPQUFPLEdBQUcsUUFBUSxDQUFDO2dCQUMvQixJQUFJLENBQUMsTUFBTSxDQUFDLFVBQVUsR0FBRyxLQUFLLENBQUM7Z0JBQy9CLElBQUksQ0FBQyxtQkFBbUIsRUFBRSxDQUFDO2dCQUMzQixJQUFJLENBQUMscUJBQXFCLENBQUMsVUFBVSxDQUFDLENBQUM7WUFDM0MsQ0FBQyxDQUFDO1lBRUYsSUFBSSxDQUFDLGtCQUFrQixHQUFHLENBQUMsYUFBb0MsRUFBUSxFQUFFO2dCQUNyRSxJQUFJLENBQUMsZ0JBQWdCLENBQUMsS0FBSyxDQUFDLENBQUM7Z0JBQzdCLElBQUksQ0FBQyxNQUFNLEdBQUcsTUFBTSxDQUFDLE1BQU0sQ0FBNkMsSUFBSSxDQUFDLE1BQU0sRUFBRSxhQUFhLENBQUMsQ0FBQztnQkFDcEcsSUFBSSxDQUFDLG1CQUFtQixFQUFFLENBQUM7Z0JBQzNCLElBQUksQ0FBQyxxQkFBcUIsQ0FBQyxVQUFVLENBQUMsQ0FBQztZQUMzQyxDQUFDLENBQUM7U0FDTDthQUNJO1lBQ0QsT0FBTyxDQUFDLElBQUksQ0FBQyw0Q0FBNEMsQ0FBQyxDQUFDO1NBQzlEO0lBQ0wsQ0FBQztJQUVELHVEQUF1RDtJQUN2RCxvQkFBb0I7SUFDcEIsdURBQXVEO0lBQy9DLG1CQUFtQjtRQUN2QixJQUFJLENBQUMsWUFBWSxHQUFHLElBQUksQ0FBQyxjQUFjLENBQUMsY0FBYyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQztJQUN4RSxDQUFDOzs7WUFyTUosU0FBUyxTQUFDO2dCQUNQLFFBQVEsRUFBRSxlQUFlO2dCQUN6Qix3NkJBQTJDO2dCQUMzQyxhQUFhLEVBQUUsaUJBQWlCLENBQUMsSUFBSTtnQkFDckMsU0FBUyxFQUFFLENBQUMsZUFBZSxDQUFDO2FBQy9COzs7WUFsQkcsZ0JBQWdCO1lBRVgsZUFBZTs7O3FCQTZCbkIsS0FBSztrQkFDTCxLQUFLOzBCQUNMLFdBQVcsU0FBQyxvQkFBb0I7MkJBQ2hDLFdBQVcsU0FBQyxzQkFBc0I7eUJBQ2xDLFdBQVcsU0FBQyxvQkFBb0I7eUJBQ2hDLFdBQVcsU0FBQyx5QkFBeUIiLCJzb3VyY2VzQ29udGVudCI6WyJcclxuaW1wb3J0IHsgdGltZXIgYXMgb2JzZXJ2YWJsZVRpbWVyLCBTdWJzY3JpcHRpb24sIGZyb21FdmVudCB9IGZyb20gJ3J4anMnO1xyXG5pbXBvcnQgeyBkZWJvdW5jZVRpbWUgfSBmcm9tICdyeGpzL29wZXJhdG9ycyc7XHJcbi8qKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqXHJcbiAgICBDb21wb25lbnQgZmlsZSAgICAgOiBrZC1hbmd1bGFyLXBhZ2VoZWFkZXIudHNcclxuICAgIFNlcnZpY2UgZmlsZSAgICAgICA6IGtkLWFuZ3VsYXItcGFnZWhlYWRlci1zdmMudHNcclxuICAgIEV2ZW50IGZpbGUgICAgICAgICA6IC1cclxuICAgIEludGVyZmFjZSBmaWxlICAgICA6IGtkLWFuZ3VsYXItcGFnZWhlYWRlci1pbnRlcmZhY2UudHNcclxuICAgIFZlcnNpb24gICAgICAgICAgICA6IDIuMFxyXG4gICAgQ3JlYXRlZCBieSAgICAgICAgIDogQ2hlbmcgS29rIEtlb25nXHJcbiAgICBQdXJwb3NlICAgICAgICAgICAgOiBTaG93IHRoZSB0aXRsZSBvZiB0aGUgY3VycmVudCBwYWdlIGluIHRoZSB0ZW1wbGF0ZSBhcmVhIHVuZGVyIGJyZWFkY3J1bWJcclxuXHJcbiAgICBCZWhhdmlvdXIgICAgICAgICAgIDpcclxuICAgICAgICAtIEJlaGF2aW91ciBmb3IgcGFnZSB0aXRsZSBlbGVtZW50OlxyXG4gICAgICAgICAgICAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxyXG4gICAgICAgICAgICB8IENhc2UgfCBMZWZ0IGJ1dHRvbnMgfCBTZWFyY2ggYnV0dG9uIHwgTW9yZSBidXR0b24gfCBXaWR0aCAgICAgICAgICAgICAgfFxyXG4gICAgICAgICAgICAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxyXG4gICAgICAgICAgICB8ICBMZWZ0IGJ1dHRvbnMgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfFxyXG4gICAgICAgICAgICB8ICAgICAgfCAoLykgICAgICAgICAgfCAoLykgICAgICAgICAgIHwgKC8pICAgICAgICAgfCAyMDBweCAgICAgICAgICAgICAgfFxyXG4gICAgICAgICAgICB8ICAgICAgfCAoLykgICAgICAgICAgfCAoLykgICAgICAgICAgIHwgKHgpICAgICAgICAgfCAyMDBweCAgICAgICAgICAgICAgfFxyXG4gICAgICAgICAgICB8ICAgICAgfCAoLykgICAgICAgICAgfCAoeCkgICAgICAgICAgIHwgKC8pICAgICAgICAgfCAyMDBweCAgICAgICAgICAgICAgfFxyXG4gICAgICAgICAgICB8ICAgICAgfCAoLykgICAgICAgICAgfCAoeCkgICAgICAgICAgIHwgKHgpICAgICAgICAgfCAyMDBweCAgICAgICAgICAgICAgfFxyXG4gICAgICAgICAgICAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxyXG4gICAgICAgICAgICB8ICBTZWFyY2ggYnV0dG9ucyAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfFxyXG4gICAgICAgICAgICB8ICAgICAgfCAoeCkgICAgICAgICAgfCAoLykgICAgICAgICAgIHwgKC8pICAgICAgICAgfCBjYWxjKDEwMCUgLSAzNDBweCkgfFxyXG4gICAgICAgICAgICB8ICAgICAgfCAoeCkgICAgICAgICAgfCAoLykgICAgICAgICAgIHwgKHgpICAgICAgICAgfCBjYWxjKDEwMCUgLSAzMDBweCkgfFxyXG4gICAgICAgICAgICAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxyXG4gICAgICAgICAgICB8ICBNb3JlIGJ1dHRvbnMgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfFxyXG4gICAgICAgICAgICB8ICAgICAgfCAoeCkgICAgICAgICAgfCAoeCkgICAgICAgICAgIHwgKC8pICAgICAgICAgfCBjYWxjKDEwMCUgLSA0MHB4KSAgfFxyXG4gICAgICAgICAgICAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxyXG4gICAgICAgICAgICB8ICBObyBidXR0b25zICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfFxyXG4gICAgICAgICAgICB8ICAgICAgfCAoeCkgICAgICAgICAgfCAoeCkgICAgICAgICAgIHwgKHgpICAgICAgICAgfCAxMDAlICAgICAgICAgICAgICAgfFxyXG4gICAgICAgICAgICAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxyXG5cclxuICAgIExhc3QgY2hhbmdlICAgICAgICAgOlxyXG4gICAgICAgIC0gUmV3cml0ZSBjb21wb25lbnQgYW5kIHNlcnZpY2VcclxuXHJcbiAqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqL1xyXG5cclxuXHJcblxyXG5pbXBvcnQge1xyXG4gICAgQ29tcG9uZW50LFxyXG4gICAgT25Jbml0LFxyXG4gICAgQWZ0ZXJWaWV3SW5pdCxcclxuICAgIE9uQ2hhbmdlcyxcclxuICAgIFNpbXBsZUNoYW5nZXMsXHJcbiAgICBPbkRlc3Ryb3ksXHJcbiAgICBJbnB1dCxcclxuICAgIFZpZXdFbmNhcHN1bGF0aW9uLFxyXG4gICAgSG9zdEJpbmRpbmcsXHJcbiAgICBWaWV3Q29udGFpbmVyUmVmLFxyXG59IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xyXG5pbXBvcnQgeyBLZFBhZ2VoZWFkZXJTdmMgfSBmcm9tICcuL2tkLWFuZ3VsYXItcGFnZWhlYWRlci1zdmMnO1xyXG5pbXBvcnQge1xyXG4gICAgSVRvb2xiYXJTZWFyY2hDb25maWcsXHJcbiAgICBJVG9vbGJhckNvbmZpZyxcclxuICAgIElUb29sYmFyTW9yZUJ1dHRvbixcclxuICAgIElUb29sYmFyQnV0dG9uLFxyXG4gICAgSVBhZ2VoZWFkZXJDb25maWcsXHJcbiAgICBJUGFnZWhlYWRlckFwaVxyXG59IGZyb20gJy4va2QtYW5ndWxhci1wYWdlaGVhZGVyLWludGVyZmFjZSc7XHJcbmltcG9ydCB7IERFTEFZX1RJTUUgfSBmcm9tICcuLi9rZC1jb21tb24vaW5kZXgnO1xyXG5cclxuQENvbXBvbmVudCh7XHJcbiAgICBzZWxlY3RvcjogJ2tkLXBhZ2VoZWFkZXInLFxyXG4gICAgdGVtcGxhdGVVcmw6ICcuL2tkLWFuZ3VsYXItcGFnZWhlYWRlci5odG1sJyxcclxuICAgIGVuY2Fwc3VsYXRpb246IFZpZXdFbmNhcHN1bGF0aW9uLk5vbmUsXHJcbiAgICBwcm92aWRlcnM6IFtLZFBhZ2VoZWFkZXJTdmNdXHJcbn0pXHJcblxyXG5leHBvcnQgY2xhc3MgS2RQYWdlaGVhZGVyIGltcGxlbWVudHMgT25Jbml0LCBPbkNoYW5nZXMsIEFmdGVyVmlld0luaXQsIE9uRGVzdHJveSB7XHJcbiAgICBwdWJsaWMgdG9vbGJhckNvbmZpZzogSVRvb2xiYXJDb25maWc7XHJcbiAgICBwdWJsaWMgdG9vbGJhckV4aXN0OiBib29sZWFuID0gZmFsc2U7XHJcbiAgICBwdWJsaWMgZXhwZW5kVGl0bGU6IGJvb2xlYW4gPSBmYWxzZTtcclxuICAgIHB1YmxpYyB0b2dnbGVUcmFuc2l0aW9uOiBib29sZWFuID0gZmFsc2U7XHJcbiAgICBwdWJsaWMgdGl0bGVDbGlja2FibGU6IGJvb2xlYW4gPSBmYWxzZTtcclxuICAgIHB1YmxpYyBjaGVja1RpdGxlQ29tcGxldGU6IGJvb2xlYW4gPSBmYWxzZTtcclxuICAgIHB1YmxpYyBoaWRlVG9vbGJhcjogYm9vbGVhbiA9IGZhbHNlO1xyXG5cclxuICAgIHByaXZhdGUgX3N1YnNjcmlwdGlvbk9iajogeyBba2V5OiBzdHJpbmddOiBTdWJzY3JpcHRpb24gfSA9IHt9O1xyXG5cclxuICAgIEBJbnB1dCgpIGNvbmZpZzogSVBhZ2VoZWFkZXJDb25maWc7XHJcbiAgICBASW5wdXQoKSBhcGk6IElQYWdlaGVhZGVyQXBpO1xyXG4gICAgQEhvc3RCaW5kaW5nKCdjbGFzcy5oYXMtbGVmdC1idG4nKSBoYXNMZWZ0QnRuczogYm9vbGVhbiA9IGZhbHNlO1xyXG4gICAgQEhvc3RCaW5kaW5nKCdjbGFzcy5oYXMtc2VhcmNoLWJ0bicpIGhhc1NlYXJjaEJ0bjogYm9vbGVhbiA9IGZhbHNlO1xyXG4gICAgQEhvc3RCaW5kaW5nKCdjbGFzcy5oYXMtbW9yZS1idG4nKSBoYXNNb3JlQnRuOiBib29sZWFuID0gZmFsc2U7XHJcbiAgICBASG9zdEJpbmRpbmcoJ2NsYXNzLnBhZ2VoZWFkZXItbW9iaWxlJykgbW9iaWxlVmlldzogYm9vbGVhbiA9IGZhbHNlO1xyXG5cclxuICAgIGNvbnN0cnVjdG9yKFxyXG4gICAgICAgIHByaXZhdGUgX3ZjcjogVmlld0NvbnRhaW5lclJlZixcclxuICAgICAgICBwcml2YXRlIF9wYWdlaGVhZGVyU3ZjOiBLZFBhZ2VoZWFkZXJTdmNcclxuICAgICkgeyB9XHJcblxyXG4gICAgLyoqKioqKioqKioqKioqKioqKioqKioqKiogTGlmZSBjeWNsZXMgZnVuY3Rpb25zICoqKioqKioqKioqKioqKioqKioqKioqKioqKioqL1xyXG4gICAgbmdPbkluaXQoKTogdm9pZCB7XHJcbiAgICAgICAgLy8gY29uc29sZS5sb2coJy0tIFBhZ2VoZWFkZXIgQ29tcG9uZW50OiBPbkluaXQgLS0nLCB0aGlzLmNvbmZpZyk7XHJcbiAgICAgICAgdGhpcy5fc2V0VHJhbnNpdGlvblRvKGZhbHNlKTtcclxuICAgICAgICB0aGlzLl9zZXR1cE9ic2VydmFibGVFdmVudHMoKTtcclxuICAgICAgICB0aGlzLl9wcm9jZXNzQ29uZmlnQ3ljbGUoKTtcclxuICAgICAgICB0aGlzLl9nZW5lcmF0ZUFwaSh0aGlzLmFwaSwgdGhpcy5jb25maWcpO1xyXG4gICAgfVxyXG5cclxuICAgIG5nT25DaGFuZ2VzKF9zaW1wbGVDaGFuZ2VzOiBTaW1wbGVDaGFuZ2VzKTogdm9pZCB7XHJcbiAgICAgICAgLy8gY29uc29sZS5sb2coJy0tIFBhZ2VoZWFkZXIgQ29tcG9uZW50OiBPbkNoYW5nZXMgLS0nLCBfc2ltcGxlQ2hhbmdlcyk7XHJcbiAgICAgICAgaWYgKF9zaW1wbGVDaGFuZ2VzLmhhc093blByb3BlcnR5KCdjb25maWcnKSAmJiAhX3NpbXBsZUNoYW5nZXNbJ2NvbmZpZyddLmZpcnN0Q2hhbmdlKSB7XHJcbiAgICAgICAgICAgIHRoaXMuX3Byb2Nlc3NDb25maWdDeWNsZSgpO1xyXG4gICAgICAgICAgICB0aGlzLl91cGRhdGVET01DeWNsZShERUxBWV9USU1FKTtcclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgbmdBZnRlclZpZXdJbml0KCk6IHZvaWQge1xyXG4gICAgICAgIC8vIGNvbnNvbGUubG9nKCctLSBQYWdlaGVhZGVyIENvbXBvbmVudDogQWZ0ZXJWaWV3SW5pdCAtLScpO1xyXG4gICAgICAgIHRoaXMuX3VwZGF0ZURPTUN5Y2xlKCk7XHJcbiAgICB9XHJcblxyXG4gICAgbmdPbkRlc3Ryb3koKTogdm9pZCB7XHJcbiAgICAgICAgLy8gY29uc29sZS5sb2coJy0tIFBhZ2VoZWFkZXIgQ29tcG9uZW50OiBPbkRlc3Ryb3kgLS0nKTtcclxuICAgICAgICBmb3IgKGxldCBzdWJPYmplY3QgaW4gdGhpcy5fc3Vic2NyaXB0aW9uT2JqKSB7XHJcbiAgICAgICAgICAgIGlmICh0aGlzLl9zdWJzY3JpcHRpb25PYmouaGFzT3duUHJvcGVydHkoc3ViT2JqZWN0KSkge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5fc3Vic2NyaXB0aW9uT2JqW3N1Yk9iamVjdF0udW5zdWJzY3JpYmUoKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICAvKioqKioqKioqKioqKioqKioqKioqKioqKioqKiBFdmVudHMgZnVuY3Rpb25zICoqKioqKioqKioqKioqKioqKioqKioqKioqKioqKiovXHJcbiAgICBwdWJsaWMgdGl0bGVDbGlja2VkKF9ldmVudDogRXZlbnQpOiB2b2lkIHtcclxuICAgICAgICBpZiAodGhpcy5tb2JpbGVWaWV3IHx8ICF0aGlzLnRpdGxlQ2xpY2thYmxlKSByZXR1cm47XHJcblxyXG4gICAgICAgIHRoaXMuZXhwZW5kVGl0bGUgPSAhdGhpcy5leHBlbmRUaXRsZTtcclxuICAgIH1cclxuXHJcbiAgICBwdWJsaWMgdXBkYXRlU2VhcmNoVGV4dChfc2VhcmNoVGV4dDogc3RyaW5nKTogdm9pZCB7XHJcbiAgICAgICAgdGhpcy5jb25maWcuc2VhcmNoVGV4dCA9IF9zZWFyY2hUZXh0O1xyXG4gICAgfVxyXG5cclxuICAgIC8qKioqKioqKioqKioqKioqKioqKioqKioqKioqIFByaXZhdGUgZnVuY3Rpb25zICoqKioqKioqKioqKioqKioqKioqKioqKioqKioqKi9cclxuICAgIC8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy9cclxuICAgIC8vLyBDeWNsZSBldmVudHNcclxuICAgIC8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy9cclxuICAgIHByaXZhdGUgX3Byb2Nlc3NDb25maWdDeWNsZSgpOiB2b2lkIHtcclxuICAgICAgICBpZiAodHlwZW9mIHRoaXMuY29uZmlnID09PSAndW5kZWZpbmVkJykge1xyXG4gICAgICAgICAgICB0aGlzLmNvbmZpZyA9IHt9O1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgdGhpcy50b29sYmFyQ29uZmlnID0gdGhpcy5fcGFnZWhlYWRlclN2Yy51cGRhdGVUb29sYmFyQ29uZmlnKHRoaXMuY29uZmlnKTtcclxuICAgICAgICB0aGlzLl91cGRhdGVUb29sYmFyRXhpc3QoKTtcclxuICAgICAgICB0aGlzLl91cGRhdGVIb3N0QmluZGluZygpO1xyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX3VwZGF0ZURPTUN5Y2xlKF9kZWxheVRpbWU6IG51bWJlciA9IDEpOiB2b2lkIHtcclxuICAgICAgICBvYnNlcnZhYmxlVGltZXIoKS5zdWJzY3JpYmUoKCk6IHZvaWQgPT4ge1xyXG4gICAgICAgICAgICB0aGlzLl91cGRhdGVWaWV3Q2xhc3MoKTtcclxuICAgICAgICAgICAgdGhpcy5fdXBkYXRlQ2xpY2thYmxlQ3ljbGUoX2RlbGF5VGltZSk7XHJcbiAgICAgICAgfSk7XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfdXBkYXRlQ2xpY2thYmxlQ3ljbGUoX2RlbGF5VGltZTogbnVtYmVyID0gMSk6IHZvaWQge1xyXG4gICAgICAgIGlmICh0aGlzLl9zdWJzY3JpcHRpb25PYmouaGFzT3duUHJvcGVydHkoJ3RpbWVyJykpIHtcclxuICAgICAgICAgICAgdGhpcy5fc3Vic2NyaXB0aW9uT2JqWyd0aW1lciddLnVuc3Vic2NyaWJlKCk7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICB0aGlzLmNoZWNrVGl0bGVDb21wbGV0ZSA9IGZhbHNlO1xyXG4gICAgICAgIHRoaXMuX3NldFRpdGxlQ2xpY2thYmxlKF9kZWxheVRpbWUpO1xyXG4gICAgfVxyXG5cclxuICAgIC8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy9cclxuICAgIC8vLyBET00gQ3ljbGUgZnVuY3Rpb25cclxuICAgIC8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy9cclxuICAgIHByaXZhdGUgX3NldHVwT2JzZXJ2YWJsZUV2ZW50cygpOiB2b2lkIHtcclxuICAgICAgICB0aGlzLl9zdWJzY3JpcHRpb25PYmpbJ3Jlc2l6ZSddID0gZnJvbUV2ZW50KHdpbmRvdywgJ3Jlc2l6ZScpXHJcbiAgICAgICAgICAgIC5waXBlKFxyXG4gICAgICAgICAgICAgICAgZGVib3VuY2VUaW1lKERFTEFZX1RJTUUpXHJcbiAgICAgICAgICAgIClcclxuICAgICAgICAgICAgLnN1YnNjcmliZShcclxuICAgICAgICAgICAgICAgIChfZXZlbnQ6IEV2ZW50KTogdm9pZCA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5fdXBkYXRlRE9NQ3ljbGUoKTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgKTtcclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF91cGRhdGVWaWV3Q2xhc3MoKTogdm9pZCB7XHJcbiAgICAgICAgdGhpcy5tb2JpbGVWaWV3ID0gd2luZG93LmlubmVyV2lkdGggPD0gMTAyNDtcclxuXHJcbiAgICAgICAgaWYgKHRoaXMubW9iaWxlVmlldykge1xyXG4gICAgICAgICAgICB0aGlzLmV4cGVuZFRpdGxlID0gZmFsc2U7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX3NldFRyYW5zaXRpb25UbyhfdG9nZ2xlOiBib29sZWFuKTogdm9pZCB7XHJcbiAgICAgICAgdGhpcy50b2dnbGVUcmFuc2l0aW9uID0gX3RvZ2dsZTtcclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF9zZXRUaXRsZUNsaWNrYWJsZShfZGVsYXk6IG51bWJlcik6IHZvaWQge1xyXG4gICAgICAgIHRoaXMuX3N1YnNjcmlwdGlvbk9ialsndGltZXInXSA9IG9ic2VydmFibGVUaW1lcihfZGVsYXkpXHJcbiAgICAgICAgICAgIC5zdWJzY3JpYmUoXHJcbiAgICAgICAgICAgICAgICAoKTogdm9pZCA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgbGV0IHRpdGxlRWxlbWVudDogRWxlbWVudCA9IHRoaXMuX3Zjci5lbGVtZW50Lm5hdGl2ZUVsZW1lbnQucXVlcnlTZWxlY3RvcignLnRpdGxlJyk7XHJcbiAgICAgICAgICAgICAgICAgICAgbGV0IGFjdHVhbEVsZW1lbnQ6IEVsZW1lbnQgPSB0aGlzLl92Y3IuZWxlbWVudC5uYXRpdmVFbGVtZW50LnF1ZXJ5U2VsZWN0b3IoJyNoZWlnaHRDaGVjaycpO1xyXG5cclxuICAgICAgICAgICAgICAgICAgICBpZiAodGl0bGVFbGVtZW50ICE9PSBudWxsICYmIGFjdHVhbEVsZW1lbnQgIT09IG51bGwpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy50aXRsZUNsaWNrYWJsZSA9IHRpdGxlRWxlbWVudC5nZXRCb3VuZGluZ0NsaWVudFJlY3QoKS53aWR0aCA8IGFjdHVhbEVsZW1lbnQuZ2V0Qm91bmRpbmdDbGllbnRSZWN0KCkud2lkdGg7XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLnRpdGxlQ2xpY2thYmxlID0gZmFsc2U7XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgICAgICAgICB0aGlzLl9zZXRUcmFuc2l0aW9uVG8odHJ1ZSk7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5jaGVja1RpdGxlQ29tcGxldGUgPSB0cnVlO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICApO1xyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX3VwZGF0ZUhvc3RCaW5kaW5nKCk6IHZvaWQge1xyXG4gICAgICAgIHRoaXMuaGFzTGVmdEJ0bnMgPSB0aGlzLnRvb2xiYXJDb25maWcubGVmdEJ0bi5sZW5ndGggPiAwO1xyXG4gICAgICAgIHRoaXMuaGFzTW9yZUJ0biA9IHRoaXMudG9vbGJhckNvbmZpZy5tb3JlQWN0aW9uLmxlbmd0aCA+IDA7XHJcbiAgICAgICAgdGhpcy5oYXNTZWFyY2hCdG4gPSB0aGlzLnRvb2xiYXJDb25maWcuc2VhcmNoQnRuO1xyXG4gICAgfVxyXG5cclxuICAgIC8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy9cclxuICAgIC8vLyBBUEkgR2VuZXJhdGlvblxyXG4gICAgLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vL1xyXG4gICAgcHJpdmF0ZSBfZ2VuZXJhdGVBcGkoX2FwaTogSVBhZ2VoZWFkZXJBcGksIF9jb25maWc6IElQYWdlaGVhZGVyQ29uZmlnKTogdm9pZCB7XHJcbiAgICAgICAgaWYgKHR5cGVvZiBfYXBpICE9PSAndW5kZWZpbmVkJykge1xyXG4gICAgICAgICAgICBfYXBpLnVwZGF0ZVRpdGxlID0gKF9uZXdUaXRsZTogc3RyaW5nID0gJycpOiB2b2lkID0+IHtcclxuICAgICAgICAgICAgICAgIF9jb25maWcucGFnZWhlYWRlclRleHQgPSBfbmV3VGl0bGU7XHJcbiAgICAgICAgICAgICAgICB0aGlzLl91cGRhdGVDbGlja2FibGVDeWNsZSgpO1xyXG4gICAgICAgICAgICB9O1xyXG5cclxuICAgICAgICAgICAgX2FwaS51cGRhdGVMZWZ0QnV0dG9uID0gKF9uZXdMZWZ0QnRuPzogQXJyYXk8SVRvb2xiYXJCdXR0b24+KTogdm9pZCA9PiB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLl9zZXRUcmFuc2l0aW9uVG8oZmFsc2UpO1xyXG4gICAgICAgICAgICAgICAgdGhpcy5jb25maWcubGVmdEJ0biA9IF9uZXdMZWZ0QnRuO1xyXG4gICAgICAgICAgICAgICAgdGhpcy5fcHJvY2Vzc0NvbmZpZ0N5Y2xlKCk7XHJcbiAgICAgICAgICAgICAgICB0aGlzLl91cGRhdGVDbGlja2FibGVDeWNsZShERUxBWV9USU1FKTtcclxuICAgICAgICAgICAgfTtcclxuXHJcbiAgICAgICAgICAgIF9hcGkudXBkYXRlTW9yZUJ1dHRvbiA9IChfZW5hYmxlZDogYm9vbGVhbiwgX2xpc3Q6IEFycmF5PElUb29sYmFyTW9yZUJ1dHRvbj4pOiB2b2lkID0+IHtcclxuICAgICAgICAgICAgICAgIHRoaXMuX3NldFRyYW5zaXRpb25UbyhmYWxzZSk7XHJcbiAgICAgICAgICAgICAgICB0aGlzLmNvbmZpZy5tb3JlQnRuID0gX2VuYWJsZWQ7XHJcbiAgICAgICAgICAgICAgICB0aGlzLmNvbmZpZy5tb3JlQWN0aW9uID0gX2xpc3Q7XHJcbiAgICAgICAgICAgICAgICB0aGlzLl9wcm9jZXNzQ29uZmlnQ3ljbGUoKTtcclxuICAgICAgICAgICAgICAgIHRoaXMuX3VwZGF0ZUNsaWNrYWJsZUN5Y2xlKERFTEFZX1RJTUUpO1xyXG4gICAgICAgICAgICB9O1xyXG5cclxuICAgICAgICAgICAgX2FwaS51cGRhdGVTZWFyY2hCdXR0b24gPSAoX3NlYXJjaENvbmZpZz86IElUb29sYmFyU2VhcmNoQ29uZmlnKTogdm9pZCA9PiB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLl9zZXRUcmFuc2l0aW9uVG8oZmFsc2UpO1xyXG4gICAgICAgICAgICAgICAgdGhpcy5jb25maWcgPSBPYmplY3QuYXNzaWduPElUb29sYmFyU2VhcmNoQ29uZmlnLCBJVG9vbGJhclNlYXJjaENvbmZpZz4odGhpcy5jb25maWcsIF9zZWFyY2hDb25maWcpO1xyXG4gICAgICAgICAgICAgICAgdGhpcy5fcHJvY2Vzc0NvbmZpZ0N5Y2xlKCk7XHJcbiAgICAgICAgICAgICAgICB0aGlzLl91cGRhdGVDbGlja2FibGVDeWNsZShERUxBWV9USU1FKTtcclxuICAgICAgICAgICAgfTtcclxuICAgICAgICB9XHJcbiAgICAgICAgZWxzZSB7XHJcbiAgICAgICAgICAgIGNvbnNvbGUud2FybignS2RQYWdlaGVhZGVyIHdhcm5pbmc6IE5vIGFwaSBpcyBwYXNzZWQgaW4uJyk7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIC8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy9cclxuICAgIC8vLyBDb25maWcgZnVuY3Rpb25zXHJcbiAgICAvLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vXHJcbiAgICBwcml2YXRlIF91cGRhdGVUb29sYmFyRXhpc3QoKTogdm9pZCB7XHJcbiAgICAgICAgdGhpcy50b29sYmFyRXhpc3QgPSB0aGlzLl9wYWdlaGVhZGVyU3ZjLmlzVG9vbGJhckV4aXN0KHRoaXMuY29uZmlnKTtcclxuICAgIH1cclxufVxyXG4iXX0=