/****************************************************************************************
    File               : kd-angular-pageheader-svc.ts
    Version            : 2.0
    Created by         : Cheng Kok Keong
    Purpose            : Service file for kd-angular-pageheader.ts

    Functions          :
        - Variables:
            - PLACEHOLDER_DEFAULT - Default text for placeholder

        - Public functions:
            - isToolbarExist - Check if there is any configurations for toolbar and renders accordingly.
            - updateToolbarConfig - Update defaults and undefines for placeholder

        - Private functions:
            - _isLeftButtonExist
            - _isMoreBtnExist
            - _isSearchBtnExist

    Last changes       :
        - Rewrite component and service

 ****************************************************************************************/
import { Injectable } from '@angular/core';
export class KdPageheaderSvc {
    constructor() {
        /*********************** Variables ************************/
        this.PLACEHOLDER_DEFAULT = 'Search';
    }
    /******************* Public function **********************/
    isToolbarExist(_config) {
        return (this._isLeftButtonExist(_config.leftBtn) ||
            this._isMoreBtnExist(_config.moreBtn) ||
            this._isSearchBtnExist(_config.searchBtn));
    }
    updateToolbarConfig(_config) {
        let toolbarConfig = {};
        let searchConfig = {};
        /// Title checks
        if (typeof _config.pageheaderText === 'undefined') {
            _config.pageheaderText = '';
        }
        /// More button checks
        if (typeof _config.moreAction === 'undefined' || (typeof _config.moreBtn === 'undefined' || !_config.moreBtn)) {
            _config.moreAction = [];
        }
        /// Left button checks
        if (typeof _config.leftBtn === 'undefined') {
            _config.leftBtn = [];
        }
        if (_config.leftBtn.length > 6) {
            console.warn('KdToolbar warning: Left buttons only take up to 6 buttons. Slicing to 6 buttons');
            _config.leftBtn.splice(6);
        }
        /// Search checks
        if (typeof _config.searchEvent === 'undefined') {
            _config.searchEvent = [];
        }
        if (typeof _config.searchPlaceholder === 'undefined') {
            _config.searchPlaceholder = this.PLACEHOLDER_DEFAULT;
        }
        if (typeof _config.searchText === 'undefined') {
            _config.searchText = '';
        }
        if (typeof _config.searchBtn === 'undefined') {
            _config.searchBtn = false;
        }
        if (_config.searchBtn) {
            searchConfig = {
                searchPlaceholder: _config.searchPlaceholder,
                searchCallback: _config.searchCallback,
                searchEvent: _config.searchEvent,
                searchText: _config.searchText
            };
        }
        toolbarConfig = {
            leftBtn: _config.leftBtn,
            moreAction: _config.moreAction,
            searchBtn: _config.searchBtn
        };
        return Object.assign(Object.assign({}, toolbarConfig), searchConfig);
    }
    /****************** Private function **********************/
    ///////////////////////////////////////////////////////
    /// Checking function
    ///////////////////////////////////////////////////////
    _isLeftButtonExist(_leftBtn) {
        return (typeof _leftBtn !== 'undefined' && _leftBtn.length > 0);
    }
    _isMoreBtnExist(_moreBtn) {
        return (typeof _moreBtn !== 'undefined' && _moreBtn);
    }
    _isSearchBtnExist(_searchBtn) {
        return (typeof _searchBtn !== 'undefined' && _searchBtn);
    }
}
KdPageheaderSvc.decorators = [
    { type: Injectable }
];
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoia2QtYW5ndWxhci1wYWdlaGVhZGVyLXN2Yy5qcyIsInNvdXJjZVJvb3QiOiJEOi9vcGVuRU1JUy9zdHlsZWd1aWRlL2lvc3RnLW9wZW5lbWlzLXN0eWxlZ3VpZGUvcHJvamVjdHMvb3BlbmVtaXMtc3R5bGVndWlkZS1saWIvc3JjLyIsInNvdXJjZXMiOlsia2QtY29tcG9uZW50cy9rZC1hbmd1bGFyLXBhZ2VoZWFkZXIva2QtYW5ndWxhci1wYWdlaGVhZGVyLXN2Yy50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OzswRkFzQjBGO0FBRTFGLE9BQU8sRUFBRSxVQUFVLEVBQUUsTUFBTSxlQUFlLENBQUM7QUFJM0MsTUFBTSxPQUFPLGVBQWU7SUFENUI7UUFFSSw0REFBNEQ7UUFDbkQsd0JBQW1CLEdBQVcsUUFBUSxDQUFDO0lBcUZwRCxDQUFDO0lBbkZHLDREQUE0RDtJQUNyRCxjQUFjLENBQUMsT0FBMEI7UUFDNUMsT0FBTyxDQUNILElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxPQUFPLENBQUMsT0FBTyxDQUFDO1lBQ3hDLElBQUksQ0FBQyxlQUFlLENBQUMsT0FBTyxDQUFDLE9BQU8sQ0FBQztZQUNyQyxJQUFJLENBQUMsaUJBQWlCLENBQUMsT0FBTyxDQUFDLFNBQVMsQ0FBQyxDQUM1QyxDQUFDO0lBQ04sQ0FBQztJQUVNLG1CQUFtQixDQUFFLE9BQTBCO1FBQ2xELElBQUksYUFBYSxHQUFtQixFQUFFLENBQUM7UUFDdkMsSUFBSSxZQUFZLEdBQW1CLEVBQUUsQ0FBQztRQUV0QyxnQkFBZ0I7UUFDaEIsSUFBSSxPQUFPLE9BQU8sQ0FBQyxjQUFjLEtBQUssV0FBVyxFQUFFO1lBQy9DLE9BQU8sQ0FBQyxjQUFjLEdBQUcsRUFBRSxDQUFDO1NBQy9CO1FBRUQsc0JBQXNCO1FBQ3RCLElBQUksT0FBTyxPQUFPLENBQUMsVUFBVSxLQUFLLFdBQVcsSUFBSSxDQUFDLE9BQU8sT0FBTyxDQUFDLE9BQU8sS0FBSyxXQUFXLElBQUksQ0FBQyxPQUFPLENBQUMsT0FBTyxDQUFDLEVBQUU7WUFDM0csT0FBTyxDQUFDLFVBQVUsR0FBRyxFQUFFLENBQUM7U0FDM0I7UUFFRCxzQkFBc0I7UUFDdEIsSUFBSSxPQUFPLE9BQU8sQ0FBQyxPQUFPLEtBQUssV0FBVyxFQUFFO1lBQ3hDLE9BQU8sQ0FBQyxPQUFPLEdBQUcsRUFBRSxDQUFDO1NBQ3hCO1FBRUQsSUFBSSxPQUFPLENBQUMsT0FBTyxDQUFDLE1BQU0sR0FBRyxDQUFDLEVBQUU7WUFDNUIsT0FBTyxDQUFDLElBQUksQ0FBQyxpRkFBaUYsQ0FBQyxDQUFDO1lBQ2hHLE9BQU8sQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDO1NBQzdCO1FBRUQsaUJBQWlCO1FBQ2pCLElBQUksT0FBTyxPQUFPLENBQUMsV0FBVyxLQUFLLFdBQVcsRUFBRTtZQUM1QyxPQUFPLENBQUMsV0FBVyxHQUFHLEVBQUUsQ0FBQztTQUM1QjtRQUVELElBQUksT0FBTyxPQUFPLENBQUMsaUJBQWlCLEtBQUssV0FBVyxFQUFFO1lBQ2xELE9BQU8sQ0FBQyxpQkFBaUIsR0FBRyxJQUFJLENBQUMsbUJBQW1CLENBQUM7U0FDeEQ7UUFFRCxJQUFJLE9BQU8sT0FBTyxDQUFDLFVBQVUsS0FBSyxXQUFXLEVBQUU7WUFDM0MsT0FBTyxDQUFDLFVBQVUsR0FBRyxFQUFFLENBQUM7U0FDM0I7UUFFRCxJQUFJLE9BQU8sT0FBTyxDQUFDLFNBQVMsS0FBSyxXQUFXLEVBQUU7WUFDMUMsT0FBTyxDQUFDLFNBQVMsR0FBRyxLQUFLLENBQUM7U0FDN0I7UUFFRCxJQUFJLE9BQU8sQ0FBQyxTQUFTLEVBQUU7WUFDbkIsWUFBWSxHQUFHO2dCQUNYLGlCQUFpQixFQUFFLE9BQU8sQ0FBQyxpQkFBaUI7Z0JBQzVDLGNBQWMsRUFBRSxPQUFPLENBQUMsY0FBYztnQkFDdEMsV0FBVyxFQUFFLE9BQU8sQ0FBQyxXQUFXO2dCQUNoQyxVQUFVLEVBQUUsT0FBTyxDQUFDLFVBQVU7YUFDakMsQ0FBQztTQUNMO1FBRUQsYUFBYSxHQUFHO1lBQ1osT0FBTyxFQUFFLE9BQU8sQ0FBQyxPQUFPO1lBQ3hCLFVBQVUsRUFBRSxPQUFPLENBQUMsVUFBVTtZQUM5QixTQUFTLEVBQUUsT0FBTyxDQUFDLFNBQVM7U0FDL0IsQ0FBQztRQUVGLHVDQUFXLGFBQWEsR0FBSyxZQUFZLEVBQUU7SUFDL0MsQ0FBQztJQUVELDREQUE0RDtJQUM1RCx1REFBdUQ7SUFDdkQscUJBQXFCO0lBQ3JCLHVEQUF1RDtJQUMvQyxrQkFBa0IsQ0FBQyxRQUErQjtRQUN0RCxPQUFPLENBQUMsT0FBTyxRQUFRLEtBQUssV0FBVyxJQUFJLFFBQVEsQ0FBQyxNQUFNLEdBQUcsQ0FBQyxDQUFDLENBQUM7SUFDcEUsQ0FBQztJQUVPLGVBQWUsQ0FBQyxRQUFpQjtRQUNyQyxPQUFPLENBQUMsT0FBTyxRQUFRLEtBQUssV0FBVyxJQUFJLFFBQVEsQ0FBQyxDQUFDO0lBQ3pELENBQUM7SUFFTyxpQkFBaUIsQ0FBQyxVQUFtQjtRQUN6QyxPQUFPLENBQUMsT0FBTyxVQUFVLEtBQUssV0FBVyxJQUFJLFVBQVUsQ0FBQyxDQUFDO0lBQzdELENBQUM7OztZQXZGSixVQUFVIiwic291cmNlc0NvbnRlbnQiOlsiLyoqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKipcclxuICAgIEZpbGUgICAgICAgICAgICAgICA6IGtkLWFuZ3VsYXItcGFnZWhlYWRlci1zdmMudHNcclxuICAgIFZlcnNpb24gICAgICAgICAgICA6IDIuMFxyXG4gICAgQ3JlYXRlZCBieSAgICAgICAgIDogQ2hlbmcgS29rIEtlb25nXHJcbiAgICBQdXJwb3NlICAgICAgICAgICAgOiBTZXJ2aWNlIGZpbGUgZm9yIGtkLWFuZ3VsYXItcGFnZWhlYWRlci50c1xyXG5cclxuICAgIEZ1bmN0aW9ucyAgICAgICAgICA6XHJcbiAgICAgICAgLSBWYXJpYWJsZXM6XHJcbiAgICAgICAgICAgIC0gUExBQ0VIT0xERVJfREVGQVVMVCAtIERlZmF1bHQgdGV4dCBmb3IgcGxhY2Vob2xkZXJcclxuXHJcbiAgICAgICAgLSBQdWJsaWMgZnVuY3Rpb25zOlxyXG4gICAgICAgICAgICAtIGlzVG9vbGJhckV4aXN0IC0gQ2hlY2sgaWYgdGhlcmUgaXMgYW55IGNvbmZpZ3VyYXRpb25zIGZvciB0b29sYmFyIGFuZCByZW5kZXJzIGFjY29yZGluZ2x5LlxyXG4gICAgICAgICAgICAtIHVwZGF0ZVRvb2xiYXJDb25maWcgLSBVcGRhdGUgZGVmYXVsdHMgYW5kIHVuZGVmaW5lcyBmb3IgcGxhY2Vob2xkZXJcclxuXHJcbiAgICAgICAgLSBQcml2YXRlIGZ1bmN0aW9uczpcclxuICAgICAgICAgICAgLSBfaXNMZWZ0QnV0dG9uRXhpc3RcclxuICAgICAgICAgICAgLSBfaXNNb3JlQnRuRXhpc3RcclxuICAgICAgICAgICAgLSBfaXNTZWFyY2hCdG5FeGlzdFxyXG5cclxuICAgIExhc3QgY2hhbmdlcyAgICAgICA6XHJcbiAgICAgICAgLSBSZXdyaXRlIGNvbXBvbmVudCBhbmQgc2VydmljZVxyXG5cclxuICoqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKiovXHJcblxyXG5pbXBvcnQgeyBJbmplY3RhYmxlIH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XHJcbmltcG9ydCB7IElQYWdlaGVhZGVyQ29uZmlnLCBJVG9vbGJhckJ1dHRvbiwgSVRvb2xiYXJDb25maWcgfSBmcm9tICcuL2tkLWFuZ3VsYXItcGFnZWhlYWRlci1pbnRlcmZhY2UnO1xyXG5cclxuQEluamVjdGFibGUoKVxyXG5leHBvcnQgY2xhc3MgS2RQYWdlaGVhZGVyU3ZjIHtcclxuICAgIC8qKioqKioqKioqKioqKioqKioqKioqKiBWYXJpYWJsZXMgKioqKioqKioqKioqKioqKioqKioqKioqL1xyXG4gICAgcmVhZG9ubHkgUExBQ0VIT0xERVJfREVGQVVMVDogc3RyaW5nID0gJ1NlYXJjaCc7XHJcblxyXG4gICAgLyoqKioqKioqKioqKioqKioqKiogUHVibGljIGZ1bmN0aW9uICoqKioqKioqKioqKioqKioqKioqKiovXHJcbiAgICBwdWJsaWMgaXNUb29sYmFyRXhpc3QoX2NvbmZpZzogSVBhZ2VoZWFkZXJDb25maWcpOiBib29sZWFuIHtcclxuICAgICAgICByZXR1cm4gKFxyXG4gICAgICAgICAgICB0aGlzLl9pc0xlZnRCdXR0b25FeGlzdChfY29uZmlnLmxlZnRCdG4pIHx8XHJcbiAgICAgICAgICAgIHRoaXMuX2lzTW9yZUJ0bkV4aXN0KF9jb25maWcubW9yZUJ0bikgfHxcclxuICAgICAgICAgICAgdGhpcy5faXNTZWFyY2hCdG5FeGlzdChfY29uZmlnLnNlYXJjaEJ0bilcclxuICAgICAgICApO1xyXG4gICAgfVxyXG5cclxuICAgIHB1YmxpYyB1cGRhdGVUb29sYmFyQ29uZmlnIChfY29uZmlnOiBJUGFnZWhlYWRlckNvbmZpZyk6IElUb29sYmFyQ29uZmlnIHtcclxuICAgICAgICBsZXQgdG9vbGJhckNvbmZpZzogSVRvb2xiYXJDb25maWcgPSB7fTtcclxuICAgICAgICBsZXQgc2VhcmNoQ29uZmlnOiBJVG9vbGJhckNvbmZpZyA9IHt9O1xyXG5cclxuICAgICAgICAvLy8gVGl0bGUgY2hlY2tzXHJcbiAgICAgICAgaWYgKHR5cGVvZiBfY29uZmlnLnBhZ2VoZWFkZXJUZXh0ID09PSAndW5kZWZpbmVkJykge1xyXG4gICAgICAgICAgICBfY29uZmlnLnBhZ2VoZWFkZXJUZXh0ID0gJyc7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICAvLy8gTW9yZSBidXR0b24gY2hlY2tzXHJcbiAgICAgICAgaWYgKHR5cGVvZiBfY29uZmlnLm1vcmVBY3Rpb24gPT09ICd1bmRlZmluZWQnIHx8ICh0eXBlb2YgX2NvbmZpZy5tb3JlQnRuID09PSAndW5kZWZpbmVkJyB8fCAhX2NvbmZpZy5tb3JlQnRuKSkge1xyXG4gICAgICAgICAgICBfY29uZmlnLm1vcmVBY3Rpb24gPSBbXTtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIC8vLyBMZWZ0IGJ1dHRvbiBjaGVja3NcclxuICAgICAgICBpZiAodHlwZW9mIF9jb25maWcubGVmdEJ0biA9PT0gJ3VuZGVmaW5lZCcpIHtcclxuICAgICAgICAgICAgX2NvbmZpZy5sZWZ0QnRuID0gW107XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICBpZiAoX2NvbmZpZy5sZWZ0QnRuLmxlbmd0aCA+IDYpIHtcclxuICAgICAgICAgICAgY29uc29sZS53YXJuKCdLZFRvb2xiYXIgd2FybmluZzogTGVmdCBidXR0b25zIG9ubHkgdGFrZSB1cCB0byA2IGJ1dHRvbnMuIFNsaWNpbmcgdG8gNiBidXR0b25zJyk7XHJcbiAgICAgICAgICAgIF9jb25maWcubGVmdEJ0bi5zcGxpY2UoNik7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICAvLy8gU2VhcmNoIGNoZWNrc1xyXG4gICAgICAgIGlmICh0eXBlb2YgX2NvbmZpZy5zZWFyY2hFdmVudCA9PT0gJ3VuZGVmaW5lZCcpIHtcclxuICAgICAgICAgICAgX2NvbmZpZy5zZWFyY2hFdmVudCA9IFtdO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgaWYgKHR5cGVvZiBfY29uZmlnLnNlYXJjaFBsYWNlaG9sZGVyID09PSAndW5kZWZpbmVkJykge1xyXG4gICAgICAgICAgICBfY29uZmlnLnNlYXJjaFBsYWNlaG9sZGVyID0gdGhpcy5QTEFDRUhPTERFUl9ERUZBVUxUO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgaWYgKHR5cGVvZiBfY29uZmlnLnNlYXJjaFRleHQgPT09ICd1bmRlZmluZWQnKSB7XHJcbiAgICAgICAgICAgIF9jb25maWcuc2VhcmNoVGV4dCA9ICcnO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgaWYgKHR5cGVvZiBfY29uZmlnLnNlYXJjaEJ0biA9PT0gJ3VuZGVmaW5lZCcpIHtcclxuICAgICAgICAgICAgX2NvbmZpZy5zZWFyY2hCdG4gPSBmYWxzZTtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIGlmIChfY29uZmlnLnNlYXJjaEJ0bikge1xyXG4gICAgICAgICAgICBzZWFyY2hDb25maWcgPSB7XHJcbiAgICAgICAgICAgICAgICBzZWFyY2hQbGFjZWhvbGRlcjogX2NvbmZpZy5zZWFyY2hQbGFjZWhvbGRlcixcclxuICAgICAgICAgICAgICAgIHNlYXJjaENhbGxiYWNrOiBfY29uZmlnLnNlYXJjaENhbGxiYWNrLFxyXG4gICAgICAgICAgICAgICAgc2VhcmNoRXZlbnQ6IF9jb25maWcuc2VhcmNoRXZlbnQsXHJcbiAgICAgICAgICAgICAgICBzZWFyY2hUZXh0OiBfY29uZmlnLnNlYXJjaFRleHRcclxuICAgICAgICAgICAgfTtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIHRvb2xiYXJDb25maWcgPSB7XHJcbiAgICAgICAgICAgIGxlZnRCdG46IF9jb25maWcubGVmdEJ0bixcclxuICAgICAgICAgICAgbW9yZUFjdGlvbjogX2NvbmZpZy5tb3JlQWN0aW9uLFxyXG4gICAgICAgICAgICBzZWFyY2hCdG46IF9jb25maWcuc2VhcmNoQnRuXHJcbiAgICAgICAgfTtcclxuXHJcbiAgICAgICAgcmV0dXJuIHsuLi50b29sYmFyQ29uZmlnLCAuLi5zZWFyY2hDb25maWd9O1xyXG4gICAgfVxyXG5cclxuICAgIC8qKioqKioqKioqKioqKioqKiogUHJpdmF0ZSBmdW5jdGlvbiAqKioqKioqKioqKioqKioqKioqKioqL1xyXG4gICAgLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vL1xyXG4gICAgLy8vIENoZWNraW5nIGZ1bmN0aW9uXHJcbiAgICAvLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vXHJcbiAgICBwcml2YXRlIF9pc0xlZnRCdXR0b25FeGlzdChfbGVmdEJ0bjogQXJyYXk8SVRvb2xiYXJCdXR0b24+KTogYm9vbGVhbiB7XHJcbiAgICAgICAgcmV0dXJuICh0eXBlb2YgX2xlZnRCdG4gIT09ICd1bmRlZmluZWQnICYmIF9sZWZ0QnRuLmxlbmd0aCA+IDApO1xyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX2lzTW9yZUJ0bkV4aXN0KF9tb3JlQnRuOiBib29sZWFuKTogYm9vbGVhbiB7XHJcbiAgICAgICAgcmV0dXJuICh0eXBlb2YgX21vcmVCdG4gIT09ICd1bmRlZmluZWQnICYmIF9tb3JlQnRuKTtcclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF9pc1NlYXJjaEJ0bkV4aXN0KF9zZWFyY2hCdG46IGJvb2xlYW4pIHtcclxuICAgICAgICByZXR1cm4gKHR5cGVvZiBfc2VhcmNoQnRuICE9PSAndW5kZWZpbmVkJyAmJiBfc2VhcmNoQnRuKTtcclxuICAgIH1cclxufVxyXG4iXX0=