/****************************************************************************************
    File               : kd-angular-toolbar-svc.ts
    Version            : 2.0
    Created by         : Cheng Kok Keong
    Purpose            : Service file for kd-angular-toolbar.ts

    Functions          :
        - Variables:
            - DEFAULT_TYPE - Default non-custom type buttons supported for the left buttons

        - Public functions:
            - updateLeftToolbar

        - Private functions:
            - _isCustomType - Checks if the button is a custom type

    Last changes       :
        - Rewrite component and service

 ****************************************************************************************/
import { Injectable } from '@angular/core';
export class KdToolbarSvc {
    constructor() {
        /******************************* Variables ***********************************/
        this.DEFAULT_TYPE = {
            'more': {
                tooltip: 'More',
                icon: 'fa kd-ellipsis fa-rotate-90',
            },
            'add': {
                tooltip: 'Add',
                icon: 'kd-add'
            },
            'back': {
                tooltip: 'Back',
                icon: 'fa fa-chevron-left'
            },
            'import': {
                tooltip: 'Import',
                icon: 'kd-import'
            },
            'export': {
                tooltip: 'Export',
                icon: 'kd-export'
            },
            'graduate': {
                tooltip: 'Graduate',
                icon: 'kd-graduate'
            },
            'transfer': {
                tooltip: 'Transfer',
                icon: 'kd-transfer'
            },
            'dropdown': {
                tooltip: 'Dropout',
                icon: 'kd-dropout'
            },
            'undo': {
                tooltip: 'Undo',
                icon: 'kd-undo'
            },
            'edit': {
                tooltip: 'Edit',
                icon: 'kd-edit'
            },
            'delete': {
                tooltip: 'Delete',
                icon: 'fa fa-trash'
            },
            'list': {
                tooltip: 'List',
                icon: 'fa fa-list'
            }
        };
    }
    /**************************** Public functions *******************************/
    ///////////////////////////////////////////////////////
    /// Left toolbar buttons function
    ///////////////////////////////////////////////////////
    updateLeftToolbar(_leftConfig) {
        let leftToolbar = [];
        for (let i = 0; i < _leftConfig.length; ++i) {
            if (!this._isCustomType(_leftConfig[i])) {
                leftToolbar.push(Object.assign({}, _leftConfig[i], this.DEFAULT_TYPE[_leftConfig[i].type]));
            }
            else {
                leftToolbar.push(_leftConfig[i]);
            }
        }
        return leftToolbar;
    }
    /**************************** Private functions *******************************/
    ///////////////////////////////////////////////////////
    /// Checking function
    ///////////////////////////////////////////////////////
    _isCustomType(_button) {
        return (typeof _button.custom !== 'undefined' && _button.custom);
    }
}
KdToolbarSvc.decorators = [
    { type: Injectable }
];
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoia2QtYW5ndWxhci10b29sYmFyLXN2Yy5qcyIsInNvdXJjZVJvb3QiOiJEOi9vcGVuRU1JUy9zdHlsZWd1aWRlL2lvc3RnLW9wZW5lbWlzLXN0eWxlZ3VpZGUvcHJvamVjdHMvb3BlbmVtaXMtc3R5bGVndWlkZS1saWIvc3JjLyIsInNvdXJjZXMiOlsia2QtY29tcG9uZW50cy9rZC1hbmd1bGFyLXBhZ2VoZWFkZXIvc3JjL2tkLWFuZ3VsYXItdG9vbGJhci1zdmMudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7MEZBbUIwRjtBQUcxRixPQUFPLEVBQUUsVUFBVSxFQUFFLE1BQU0sZUFBZSxDQUFDO0FBSTNDLE1BQU0sT0FBTyxZQUFZO0lBRHpCO1FBRUksK0VBQStFO1FBQ3RFLGlCQUFZLEdBQW9DO1lBQ3JELE1BQU0sRUFBRTtnQkFDSixPQUFPLEVBQUUsTUFBTTtnQkFDZixJQUFJLEVBQUUsNkJBQTZCO2FBQ3RDO1lBQ0QsS0FBSyxFQUFFO2dCQUNILE9BQU8sRUFBRSxLQUFLO2dCQUNkLElBQUksRUFBRSxRQUFRO2FBQ2pCO1lBQ0QsTUFBTSxFQUFFO2dCQUNKLE9BQU8sRUFBRSxNQUFNO2dCQUNmLElBQUksRUFBRSxvQkFBb0I7YUFDN0I7WUFDRCxRQUFRLEVBQUU7Z0JBQ04sT0FBTyxFQUFFLFFBQVE7Z0JBQ2pCLElBQUksRUFBRSxXQUFXO2FBQ3BCO1lBQ0QsUUFBUSxFQUFFO2dCQUNOLE9BQU8sRUFBRSxRQUFRO2dCQUNqQixJQUFJLEVBQUUsV0FBVzthQUNwQjtZQUNELFVBQVUsRUFBRTtnQkFDUixPQUFPLEVBQUUsVUFBVTtnQkFDbkIsSUFBSSxFQUFFLGFBQWE7YUFDdEI7WUFDRCxVQUFVLEVBQUU7Z0JBQ1IsT0FBTyxFQUFFLFVBQVU7Z0JBQ25CLElBQUksRUFBRSxhQUFhO2FBQ3RCO1lBQ0QsVUFBVSxFQUFFO2dCQUNSLE9BQU8sRUFBRSxTQUFTO2dCQUNsQixJQUFJLEVBQUUsWUFBWTthQUNyQjtZQUNELE1BQU0sRUFBRTtnQkFDSixPQUFPLEVBQUUsTUFBTTtnQkFDZixJQUFJLEVBQUUsU0FBUzthQUNsQjtZQUNELE1BQU0sRUFBRTtnQkFDSixPQUFPLEVBQUUsTUFBTTtnQkFDZixJQUFJLEVBQUUsU0FBUzthQUNsQjtZQUNELFFBQVEsRUFBRTtnQkFDTixPQUFPLEVBQUUsUUFBUTtnQkFDakIsSUFBSSxFQUFFLGFBQWE7YUFDdEI7WUFDRCxNQUFNLEVBQUU7Z0JBQ0osT0FBTyxFQUFFLE1BQU07Z0JBQ2YsSUFBSSxFQUFFLFlBQVk7YUFDckI7U0FDSixDQUFDO0lBNEJOLENBQUM7SUExQkcsK0VBQStFO0lBQy9FLHVEQUF1RDtJQUN2RCxpQ0FBaUM7SUFDakMsdURBQXVEO0lBQ2hELGlCQUFpQixDQUFDLFdBQWtDO1FBQ3ZELElBQUksV0FBVyxHQUEwQixFQUFFLENBQUM7UUFFNUMsS0FBSyxJQUFJLENBQUMsR0FBVyxDQUFDLEVBQUUsQ0FBQyxHQUFHLFdBQVcsQ0FBQyxNQUFNLEVBQUUsRUFBRSxDQUFDLEVBQUU7WUFDakQsSUFBSSxDQUFDLElBQUksQ0FBQyxhQUFhLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUU7Z0JBQ3JDLFdBQVcsQ0FBQyxJQUFJLENBQU8sTUFBTyxDQUFDLE1BQU0sQ0FBQyxFQUFFLEVBQUUsV0FBVyxDQUFDLENBQUMsQ0FBQyxFQUFFLElBQUksQ0FBQyxZQUFZLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQzthQUN0RztpQkFDSTtnQkFDRCxXQUFXLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO2FBQ3BDO1NBQ0o7UUFFRCxPQUFPLFdBQVcsQ0FBQztJQUN2QixDQUFDO0lBRUQsZ0ZBQWdGO0lBQ2hGLHVEQUF1RDtJQUN2RCxxQkFBcUI7SUFDckIsdURBQXVEO0lBQy9DLGFBQWEsQ0FBQyxPQUF1QjtRQUN6QyxPQUFPLENBQUMsT0FBTyxPQUFPLENBQUMsTUFBTSxLQUFLLFdBQVcsSUFBSSxPQUFPLENBQUMsTUFBTSxDQUFDLENBQUM7SUFDckUsQ0FBQzs7O1lBL0VKLFVBQVUiLCJzb3VyY2VzQ29udGVudCI6WyIvKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKlxyXG4gICAgRmlsZSAgICAgICAgICAgICAgIDoga2QtYW5ndWxhci10b29sYmFyLXN2Yy50c1xyXG4gICAgVmVyc2lvbiAgICAgICAgICAgIDogMi4wXHJcbiAgICBDcmVhdGVkIGJ5ICAgICAgICAgOiBDaGVuZyBLb2sgS2VvbmdcclxuICAgIFB1cnBvc2UgICAgICAgICAgICA6IFNlcnZpY2UgZmlsZSBmb3Iga2QtYW5ndWxhci10b29sYmFyLnRzXHJcblxyXG4gICAgRnVuY3Rpb25zICAgICAgICAgIDpcclxuICAgICAgICAtIFZhcmlhYmxlczpcclxuICAgICAgICAgICAgLSBERUZBVUxUX1RZUEUgLSBEZWZhdWx0IG5vbi1jdXN0b20gdHlwZSBidXR0b25zIHN1cHBvcnRlZCBmb3IgdGhlIGxlZnQgYnV0dG9uc1xyXG5cclxuICAgICAgICAtIFB1YmxpYyBmdW5jdGlvbnM6XHJcbiAgICAgICAgICAgIC0gdXBkYXRlTGVmdFRvb2xiYXJcclxuXHJcbiAgICAgICAgLSBQcml2YXRlIGZ1bmN0aW9uczpcclxuICAgICAgICAgICAgLSBfaXNDdXN0b21UeXBlIC0gQ2hlY2tzIGlmIHRoZSBidXR0b24gaXMgYSBjdXN0b20gdHlwZVxyXG5cclxuICAgIExhc3QgY2hhbmdlcyAgICAgICA6XHJcbiAgICAgICAgLSBSZXdyaXRlIGNvbXBvbmVudCBhbmQgc2VydmljZVxyXG5cclxuICoqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKiovXHJcblxyXG5cclxuaW1wb3J0IHsgSW5qZWN0YWJsZSB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xyXG5pbXBvcnQgeyBJVG9vbGJhckJ1dHRvbiB9IGZyb20gJy4uL2tkLWFuZ3VsYXItcGFnZWhlYWRlci1pbnRlcmZhY2UnO1xyXG5cclxuQEluamVjdGFibGUoKVxyXG5leHBvcnQgY2xhc3MgS2RUb29sYmFyU3ZjIHtcclxuICAgIC8qKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqIFZhcmlhYmxlcyAqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKi9cclxuICAgIHJlYWRvbmx5IERFRkFVTFRfVFlQRToge1trZXk6IHN0cmluZ106IElUb29sYmFyQnV0dG9ufSA9IHtcclxuICAgICAgICAnbW9yZSc6IHtcclxuICAgICAgICAgICAgdG9vbHRpcDogJ01vcmUnLFxyXG4gICAgICAgICAgICBpY29uOiAnZmEga2QtZWxsaXBzaXMgZmEtcm90YXRlLTkwJyxcclxuICAgICAgICB9LFxyXG4gICAgICAgICdhZGQnOiB7XHJcbiAgICAgICAgICAgIHRvb2x0aXA6ICdBZGQnLFxyXG4gICAgICAgICAgICBpY29uOiAna2QtYWRkJ1xyXG4gICAgICAgIH0sXHJcbiAgICAgICAgJ2JhY2snOiB7XHJcbiAgICAgICAgICAgIHRvb2x0aXA6ICdCYWNrJyxcclxuICAgICAgICAgICAgaWNvbjogJ2ZhIGZhLWNoZXZyb24tbGVmdCdcclxuICAgICAgICB9LFxyXG4gICAgICAgICdpbXBvcnQnOiB7XHJcbiAgICAgICAgICAgIHRvb2x0aXA6ICdJbXBvcnQnLFxyXG4gICAgICAgICAgICBpY29uOiAna2QtaW1wb3J0J1xyXG4gICAgICAgIH0sXHJcbiAgICAgICAgJ2V4cG9ydCc6IHtcclxuICAgICAgICAgICAgdG9vbHRpcDogJ0V4cG9ydCcsXHJcbiAgICAgICAgICAgIGljb246ICdrZC1leHBvcnQnXHJcbiAgICAgICAgfSxcclxuICAgICAgICAnZ3JhZHVhdGUnOiB7XHJcbiAgICAgICAgICAgIHRvb2x0aXA6ICdHcmFkdWF0ZScsXHJcbiAgICAgICAgICAgIGljb246ICdrZC1ncmFkdWF0ZSdcclxuICAgICAgICB9LFxyXG4gICAgICAgICd0cmFuc2Zlcic6IHtcclxuICAgICAgICAgICAgdG9vbHRpcDogJ1RyYW5zZmVyJyxcclxuICAgICAgICAgICAgaWNvbjogJ2tkLXRyYW5zZmVyJ1xyXG4gICAgICAgIH0sXHJcbiAgICAgICAgJ2Ryb3Bkb3duJzoge1xyXG4gICAgICAgICAgICB0b29sdGlwOiAnRHJvcG91dCcsXHJcbiAgICAgICAgICAgIGljb246ICdrZC1kcm9wb3V0J1xyXG4gICAgICAgIH0sXHJcbiAgICAgICAgJ3VuZG8nOiB7XHJcbiAgICAgICAgICAgIHRvb2x0aXA6ICdVbmRvJyxcclxuICAgICAgICAgICAgaWNvbjogJ2tkLXVuZG8nXHJcbiAgICAgICAgfSxcclxuICAgICAgICAnZWRpdCc6IHtcclxuICAgICAgICAgICAgdG9vbHRpcDogJ0VkaXQnLFxyXG4gICAgICAgICAgICBpY29uOiAna2QtZWRpdCdcclxuICAgICAgICB9LFxyXG4gICAgICAgICdkZWxldGUnOiB7XHJcbiAgICAgICAgICAgIHRvb2x0aXA6ICdEZWxldGUnLFxyXG4gICAgICAgICAgICBpY29uOiAnZmEgZmEtdHJhc2gnXHJcbiAgICAgICAgfSxcclxuICAgICAgICAnbGlzdCc6IHtcclxuICAgICAgICAgICAgdG9vbHRpcDogJ0xpc3QnLFxyXG4gICAgICAgICAgICBpY29uOiAnZmEgZmEtbGlzdCdcclxuICAgICAgICB9XHJcbiAgICB9O1xyXG5cclxuICAgIC8qKioqKioqKioqKioqKioqKioqKioqKioqKioqIFB1YmxpYyBmdW5jdGlvbnMgKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKi9cclxuICAgIC8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy9cclxuICAgIC8vLyBMZWZ0IHRvb2xiYXIgYnV0dG9ucyBmdW5jdGlvblxyXG4gICAgLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vL1xyXG4gICAgcHVibGljIHVwZGF0ZUxlZnRUb29sYmFyKF9sZWZ0Q29uZmlnOiBBcnJheTxJVG9vbGJhckJ1dHRvbj4pOiBBcnJheTxJVG9vbGJhckJ1dHRvbj4ge1xyXG4gICAgICAgIGxldCBsZWZ0VG9vbGJhcjogQXJyYXk8SVRvb2xiYXJCdXR0b24+ID0gW107XHJcblxyXG4gICAgICAgIGZvciAobGV0IGk6IG51bWJlciA9IDA7IGkgPCBfbGVmdENvbmZpZy5sZW5ndGg7ICsraSkge1xyXG4gICAgICAgICAgICBpZiAoIXRoaXMuX2lzQ3VzdG9tVHlwZShfbGVmdENvbmZpZ1tpXSkpIHtcclxuICAgICAgICAgICAgICAgIGxlZnRUb29sYmFyLnB1c2goKDxhbnk+T2JqZWN0KS5hc3NpZ24oe30sIF9sZWZ0Q29uZmlnW2ldLCB0aGlzLkRFRkFVTFRfVFlQRVtfbGVmdENvbmZpZ1tpXS50eXBlXSkpO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgbGVmdFRvb2xiYXIucHVzaChfbGVmdENvbmZpZ1tpXSk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIHJldHVybiBsZWZ0VG9vbGJhcjtcclxuICAgIH1cclxuXHJcbiAgICAvKioqKioqKioqKioqKioqKioqKioqKioqKioqKiBQcml2YXRlIGZ1bmN0aW9ucyAqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqL1xyXG4gICAgLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vL1xyXG4gICAgLy8vIENoZWNraW5nIGZ1bmN0aW9uXHJcbiAgICAvLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vXHJcbiAgICBwcml2YXRlIF9pc0N1c3RvbVR5cGUoX2J1dHRvbjogSVRvb2xiYXJCdXR0b24pOiBib29sZWFuIHtcclxuICAgICAgICByZXR1cm4gKHR5cGVvZiBfYnV0dG9uLmN1c3RvbSAhPT0gJ3VuZGVmaW5lZCcgJiYgX2J1dHRvbi5jdXN0b20pO1xyXG4gICAgfVxyXG59XHJcbiJdfQ==