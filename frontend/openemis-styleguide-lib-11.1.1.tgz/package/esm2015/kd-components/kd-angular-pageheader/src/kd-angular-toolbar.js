import { timer as observableTimer } from 'rxjs';
/****************************************************************************************
    Component file     : kd-angular-toolbar.ts
    Service file       : kd-angular-toolbar-svc.ts
    Event file         : kd-toolbar-event.ts
    Interface file     : kd-angular-pageheader-interface.ts
    Version            : 2.0
    Created by         : Cheng Kok Keong
    Purpose            : Show the toolbars and search input in the template area under breadcrumb

    Behaviour           :
        - Search button in web view is able to see the search box and able to
          search straight in the input field
        - Search button in mobile view is a button with the input field hidden.
          Only when clicked, the input field will takes up 100% width for search

        - Behaviour for search button element (cross icon):
            -----------------------------------------------------------------------------
            | View Type   | Search Text exist  | Behaviour                              |
            -----------------------------------------------------------------------------
            | Windows     | (/)                | Cross icon will show, when clicked,    |
            |             |                    | remove search text and hide cross icon.|
            |             |                    |                                        |
            |             | (x)                | Cross icon is hidden.                  |
            -----------------------------------------------------------------------------
            | Mobile      | (/)                | Cross icon will show, when clicked,    |
            |             |                    | remove search text, and behaves like   |
            |             |                    | Mobile - No search text                |
            |             |                    |                                        |
            |             | (x)                | Cross icon will show, when clicked     |
            |             |                    | close the search input.                |
            -----------------------------------------------------------------------------


    Last changes       :
        - Rewrite component and service

 ****************************************************************************************/
import { Component, ViewEncapsulation, Input, Output, EventEmitter } from '@angular/core';
import { Router } from '@angular/router';
import { KdToolbarSvc } from './kd-angular-toolbar-svc';
import { KdToolbarEvent } from './kd-toolbar-event';
export class KdToolbar {
    constructor(_router, _toolbarSvc, _toolbarEvent) {
        this._router = _router;
        this._toolbarSvc = _toolbarSvc;
        this._toolbarEvent = _toolbarEvent;
        this.searchExpend = false;
        this.showSearchCloseBtn = false;
        this.searchTextChanged = new EventEmitter();
    }
    /************************* Life cycles functions *****************************/
    ngOnInit() {
        // console.log('-- KdToolbar: OnInit -- ', this.config);
        if (typeof this.config !== 'undefined') {
            this._updateLeftToolbar(this.config);
            this._updateSearchCloseBtn();
        }
    }
    ngOnChanges(_simpleChanges) {
        // console.log('-- KdToolbar: OnChanges -- ', _simpleChanges);
        if (_simpleChanges.hasOwnProperty('config') && typeof _simpleChanges['config'].currentValue !== 'undefined') {
            this._updateLeftToolbar(this.config);
            this._updateSearchCloseBtn();
        }
        if (_simpleChanges.hasOwnProperty('mobileView')) {
            this._checkToShowSearchClose();
            if (!this.mobileView) {
                this.searchExpend = false;
            }
        }
    }
    ngAfterViewInit() {
        // console.log('-- KdToolbar: AfterViewInit -- ');
        observableTimer().subscribe(() => {
            this._checkToShowSearchClose();
        });
    }
    ngOnDestroy() {
        // console.log('-- KdToolbar: OnDestroy -- ');
    }
    /**************************** Events functions *******************************/
    ///////////////////////////////////////////////////////
    /// Button events
    ///////////////////////////////////////////////////////
    buttonClick(_e, _button) {
        // console.log('-- KdToolbar: Button clicked -- ', _button);
        if (typeof _button.path !== 'undefined') {
            this._router.navigate([_button.path]);
        }
        else if (typeof _button.callback !== 'undefined') {
            _button.callback();
        }
        else {
            console.error('KdToolbar: Button is clicked but no path or callback is specified.');
        }
    }
    ///////////////////////////////////////////////////////
    /// Search functions
    ///////////////////////////////////////////////////////
    searchClicked() {
        if (!this.mobileView)
            return;
        this.searchExpend = !this.searchExpend;
        this._checkToShowSearchClose();
    }
    searchChanged(_event) {
        // console.log('-- KdToolbar: Search text changed -- ', _event);
        if (typeof this.config.searchCallback !== 'undefined') {
            this.config.searchCallback(_event);
        }
        this._updateSearchCloseBtn();
        this._emitSearchTextChanged();
    }
    searchCloseClicked() {
        // console.log('-- KdToolbar: Search close clicked -- ');
        if (this.mobileView) {
            if (this.config.searchText !== '') {
                this._clearSearch();
            }
            else {
                this.searchExpend = false;
                this.showSearchCloseBtn = false;
            }
        }
        else {
            this._clearSearch();
            this.showSearchCloseBtn = false;
        }
    }
    /**************************** Private functions ******************************/
    ///////////////////////////////////////////////////////
    /// DOM function
    ///////////////////////////////////////////////////////
    _checkToShowSearchClose() {
        if (this.mobileView) {
            this.showSearchCloseBtn = this.searchExpend;
        }
        else {
            this.showSearchCloseBtn = this.config.searchText !== '';
        }
    }
    _clearSearch() {
        this.config.searchText = '';
        this._emitSearchTextChanged();
    }
    _updateSearchCloseBtn() {
        if (!this.mobileView) {
            this.showSearchCloseBtn = this.config.searchText !== '';
        }
    }
    ///////////////////////////////////////////////////////
    /// Update Toolbar buttons function
    ///////////////////////////////////////////////////////
    _updateLeftToolbar(_config) {
        _config.leftBtn = this._toolbarSvc.updateLeftToolbar(_config.leftBtn);
    }
    ///////////////////////////////////////////////////////
    /// Emitter function
    ///////////////////////////////////////////////////////
    _emitSearchTextChanged() {
        this.searchTextChanged.emit(this.config.searchText);
        this._toolbarEvent.sendSearchText(this.config.searchText);
    }
}
KdToolbar.decorators = [
    { type: Component, args: [{
                selector: 'kd-toolbar',
                template: "<div class='kdx-toolbar'>\r\n\r\n    <!-- Left toolbar -->\r\n    <div *ngIf='config.leftBtn.length > 0' class='kdx-toolbar-left'>\r\n        <ng-template ngFor let-item [ngForOf]='config.leftBtn'>\r\n\r\n            <!-- Normal button -->\r\n            <button *ngIf='item.type != \"more\"' type='button' (click)='buttonClick($event, item)' class='btn btn-icon btn-xs' placement='bottom' ngbTooltip='{{item.tooltip}}'>\r\n                <i class='{{item.icon}}'></i>\r\n            </button>\r\n\r\n            <!-- More button -->\r\n            <div *ngIf='item.type == \"more\"' ngbDropdown class=\"d-inline-block more-btn\">\r\n                <button class=\"btn btn-outline-primary\" id=\"moreDropdown\" ngbDropdownToggle  placement=\"bottom\"  ngbTooltip=\"{{item.tooltip}}\">\r\n                    <i class=\"{{item.icon}}\"></i>\r\n                </button>\r\n                <div ngbDropdownMenu class=\"dropdown-menu\" aria-labelledby=\"moreDropdown\">\r\n                    <ng-template ngFor let-item [ngForOf]=\"item.dropdown\">\r\n                        <button type='button' class='dropdown-item' (click)='buttonClick($event, item)'>{{item.text}}</button>\r\n                    </ng-template>\r\n                </div>\r\n            </div>\r\n\r\n        </ng-template>\r\n    </div>\r\n\r\n    <!-- Right toolbar -->\r\n    <div class='kdx-toolbar-right' [ngClass]=\"{'has-more-btn': config.moreAction.length > 0, 'full-width': mobileView && searchExpend}\">\r\n\r\n        <!-- Search -->\r\n        <div *ngIf=\"config.searchBtn\" class=\"kdx-search-wrapper\" [ngClass]=\"{ 'collapsed': !searchExpend && mobileView, 'expend': searchExpend && mobileView }\">\r\n            <div class=\"kdx-search-icon\" [ngClass]=\"{ 'btn btn-icon': mobileView }\" (click)=\"searchClicked()\">\r\n                <i class=\"fa fa-search\"></i>\r\n            </div>\r\n            <input type=\"text\" [hidden]=\"mobileView && !searchExpend\" class=\"form-control search-input\" [(ngModel)]=\"config.searchText\" (ngModelChange)=\"searchChanged($event)\" placeholder=\"{{config.searchPlaceholder}}\">\r\n            <button class=\"btn btn-icon close-btn\" *ngIf=\"showSearchCloseBtn\" (click)=\"searchCloseClicked()\" type=\"button\">\r\n                <i class=\"kd-close-round\"></i>\r\n           </button>\r\n        </div>\r\n\r\n        <!-- More action -->\r\n        <div *ngIf='config.moreAction.length > 0' class='btn-dropdown' ngbDropdown>\r\n            <button type=\"button\" class=\"btn btn-icon btn-xs\" placement=\"bottom\" ngbTooltip=\"More\" id=\"moreActionMenu\" ngbDropdownToggle>\r\n                <i class=\"kd-ellipsis\"></i>\r\n            </button>\r\n            <div ngbDropdownMenu class=\"dropdown-menu\" aria-labelledby=\"moreActionMenu\">\r\n                <ng-template ngFor let-item [ngForOf]=\"config.moreAction\">\r\n                    <button (click)='buttonClick($event, item)' class='dropdown-item'>{{item.text}}</button>\r\n                </ng-template>\r\n            </div>\r\n        </div>\r\n\r\n    </div>\r\n</div>",
                encapsulation: ViewEncapsulation.None,
                providers: [KdToolbarSvc]
            },] }
];
KdToolbar.ctorParameters = () => [
    { type: Router },
    { type: KdToolbarSvc },
    { type: KdToolbarEvent }
];
KdToolbar.propDecorators = {
    config: [{ type: Input }],
    mobileView: [{ type: Input }],
    searchTextChanged: [{ type: Output }]
};
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoia2QtYW5ndWxhci10b29sYmFyLmpzIiwic291cmNlUm9vdCI6IkQ6L29wZW5FTUlTL3N0eWxlZ3VpZGUvaW9zdGctb3BlbmVtaXMtc3R5bGVndWlkZS9wcm9qZWN0cy9vcGVuZW1pcy1zdHlsZWd1aWRlLWxpYi9zcmMvIiwic291cmNlcyI6WyJrZC1jb21wb25lbnRzL2tkLWFuZ3VsYXItcGFnZWhlYWRlci9zcmMva2QtYW5ndWxhci10b29sYmFyLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUNBLE9BQU8sRUFBQyxLQUFLLElBQUksZUFBZSxFQUFFLE1BQU0sTUFBTSxDQUFDO0FBQy9DOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7MEZBb0MwRjtBQUkxRixPQUFPLEVBQ0gsU0FBUyxFQUNULGlCQUFpQixFQUNqQixLQUFLLEVBQ0wsTUFBTSxFQUNOLFlBQVksRUFNZixNQUFNLGVBQWUsQ0FBQztBQUN2QixPQUFPLEVBQUUsTUFBTSxFQUFFLE1BQU0saUJBQWlCLENBQUM7QUFDekMsT0FBTyxFQUFFLFlBQVksRUFBRSxNQUFNLDBCQUEwQixDQUFDO0FBQ3hELE9BQU8sRUFBRSxjQUFjLEVBQUUsTUFBTSxvQkFBb0IsQ0FBQztBQVVwRCxNQUFNLE9BQU8sU0FBUztJQVFsQixZQUNZLE9BQWUsRUFDZixXQUF5QixFQUN6QixhQUE2QjtRQUY3QixZQUFPLEdBQVAsT0FBTyxDQUFRO1FBQ2YsZ0JBQVcsR0FBWCxXQUFXLENBQWM7UUFDekIsa0JBQWEsR0FBYixhQUFhLENBQWdCO1FBVmxDLGlCQUFZLEdBQVksS0FBSyxDQUFDO1FBQzlCLHVCQUFrQixHQUFZLEtBQUssQ0FBQztRQUlqQyxzQkFBaUIsR0FBeUIsSUFBSSxZQUFZLEVBQVUsQ0FBQztJQU0zRSxDQUFDO0lBRUwsK0VBQStFO0lBQy9FLFFBQVE7UUFDSix3REFBd0Q7UUFDeEQsSUFBSSxPQUFPLElBQUksQ0FBQyxNQUFNLEtBQUssV0FBVyxFQUFFO1lBQ3BDLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUM7WUFDckMsSUFBSSxDQUFDLHFCQUFxQixFQUFFLENBQUM7U0FDaEM7SUFDTCxDQUFDO0lBRUQsV0FBVyxDQUFDLGNBQTZCO1FBQ3JDLDhEQUE4RDtRQUM5RCxJQUFJLGNBQWMsQ0FBQyxjQUFjLENBQUMsUUFBUSxDQUFDLElBQUksT0FBTyxjQUFjLENBQUMsUUFBUSxDQUFDLENBQUMsWUFBWSxLQUFLLFdBQVcsRUFBRTtZQUN6RyxJQUFJLENBQUMsa0JBQWtCLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDO1lBQ3JDLElBQUksQ0FBQyxxQkFBcUIsRUFBRSxDQUFDO1NBQ2hDO1FBRUQsSUFBSSxjQUFjLENBQUMsY0FBYyxDQUFDLFlBQVksQ0FBQyxFQUFFO1lBQzdDLElBQUksQ0FBQyx1QkFBdUIsRUFBRSxDQUFDO1lBRS9CLElBQUksQ0FBQyxJQUFJLENBQUMsVUFBVSxFQUFFO2dCQUNsQixJQUFJLENBQUMsWUFBWSxHQUFHLEtBQUssQ0FBQzthQUM3QjtTQUNKO0lBQ0wsQ0FBQztJQUVELGVBQWU7UUFDWCxrREFBa0Q7UUFDbEQsZUFBZSxFQUFFLENBQUMsU0FBUyxDQUFDLEdBQVMsRUFBRTtZQUNuQyxJQUFJLENBQUMsdUJBQXVCLEVBQUUsQ0FBQztRQUNuQyxDQUFDLENBQUMsQ0FBQztJQUNQLENBQUM7SUFFRCxXQUFXO1FBQ1AsOENBQThDO0lBQ2xELENBQUM7SUFFRCwrRUFBK0U7SUFDL0UsdURBQXVEO0lBQ3ZELGlCQUFpQjtJQUNqQix1REFBdUQ7SUFDaEQsV0FBVyxDQUFDLEVBQVMsRUFBRSxPQUF1QjtRQUNqRCw0REFBNEQ7UUFDNUQsSUFBSSxPQUFPLE9BQU8sQ0FBQyxJQUFJLEtBQUssV0FBVyxFQUFFO1lBQ3JDLElBQUksQ0FBQyxPQUFPLENBQUMsUUFBUSxDQUFDLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUM7U0FDekM7YUFDSSxJQUFJLE9BQU8sT0FBTyxDQUFDLFFBQVEsS0FBSyxXQUFXLEVBQUU7WUFDOUMsT0FBTyxDQUFDLFFBQVEsRUFBRSxDQUFDO1NBQ3RCO2FBQ0k7WUFDRCxPQUFPLENBQUMsS0FBSyxDQUFDLG9FQUFvRSxDQUFDLENBQUM7U0FDdkY7SUFDTCxDQUFDO0lBRUQsdURBQXVEO0lBQ3ZELG9CQUFvQjtJQUNwQix1REFBdUQ7SUFDaEQsYUFBYTtRQUNoQixJQUFJLENBQUMsSUFBSSxDQUFDLFVBQVU7WUFBRSxPQUFPO1FBRTdCLElBQUksQ0FBQyxZQUFZLEdBQUcsQ0FBQyxJQUFJLENBQUMsWUFBWSxDQUFDO1FBQ3ZDLElBQUksQ0FBQyx1QkFBdUIsRUFBRSxDQUFDO0lBQ25DLENBQUM7SUFFTSxhQUFhLENBQUMsTUFBYztRQUMvQixnRUFBZ0U7UUFDaEUsSUFBSSxPQUFPLElBQUksQ0FBQyxNQUFNLENBQUMsY0FBYyxLQUFLLFdBQVcsRUFBRTtZQUNuRCxJQUFJLENBQUMsTUFBTSxDQUFDLGNBQWMsQ0FBQyxNQUFNLENBQUMsQ0FBQztTQUN0QztRQUVELElBQUksQ0FBQyxxQkFBcUIsRUFBRSxDQUFDO1FBQzdCLElBQUksQ0FBQyxzQkFBc0IsRUFBRSxDQUFDO0lBQ2xDLENBQUM7SUFFTSxrQkFBa0I7UUFDckIseURBQXlEO1FBQ3pELElBQUksSUFBSSxDQUFDLFVBQVUsRUFBRTtZQUNqQixJQUFJLElBQUksQ0FBQyxNQUFNLENBQUMsVUFBVSxLQUFLLEVBQUUsRUFBRTtnQkFDL0IsSUFBSSxDQUFDLFlBQVksRUFBRSxDQUFDO2FBQ3ZCO2lCQUNJO2dCQUNELElBQUksQ0FBQyxZQUFZLEdBQUcsS0FBSyxDQUFDO2dCQUMxQixJQUFJLENBQUMsa0JBQWtCLEdBQUcsS0FBSyxDQUFDO2FBQ25DO1NBQ0o7YUFDSTtZQUNELElBQUksQ0FBQyxZQUFZLEVBQUUsQ0FBQztZQUNwQixJQUFJLENBQUMsa0JBQWtCLEdBQUcsS0FBSyxDQUFDO1NBQ25DO0lBQ0wsQ0FBQztJQUVELCtFQUErRTtJQUMvRSx1REFBdUQ7SUFDdkQsZ0JBQWdCO0lBQ2hCLHVEQUF1RDtJQUMvQyx1QkFBdUI7UUFDM0IsSUFBSSxJQUFJLENBQUMsVUFBVSxFQUFFO1lBQ2pCLElBQUksQ0FBQyxrQkFBa0IsR0FBRyxJQUFJLENBQUMsWUFBWSxDQUFDO1NBQy9DO2FBQ0k7WUFDRCxJQUFJLENBQUMsa0JBQWtCLEdBQUcsSUFBSSxDQUFDLE1BQU0sQ0FBQyxVQUFVLEtBQUssRUFBRSxDQUFDO1NBQzNEO0lBQ0wsQ0FBQztJQUVPLFlBQVk7UUFDaEIsSUFBSSxDQUFDLE1BQU0sQ0FBQyxVQUFVLEdBQUcsRUFBRSxDQUFDO1FBQzVCLElBQUksQ0FBQyxzQkFBc0IsRUFBRSxDQUFDO0lBQ2xDLENBQUM7SUFFTyxxQkFBcUI7UUFDekIsSUFBSSxDQUFDLElBQUksQ0FBQyxVQUFVLEVBQUU7WUFDbEIsSUFBSSxDQUFDLGtCQUFrQixHQUFHLElBQUksQ0FBQyxNQUFNLENBQUMsVUFBVSxLQUFLLEVBQUUsQ0FBQztTQUMzRDtJQUNMLENBQUM7SUFFRCx1REFBdUQ7SUFDdkQsbUNBQW1DO0lBQ25DLHVEQUF1RDtJQUMvQyxrQkFBa0IsQ0FBQyxPQUF1QjtRQUM5QyxPQUFPLENBQUMsT0FBTyxHQUFHLElBQUksQ0FBQyxXQUFXLENBQUMsaUJBQWlCLENBQUMsT0FBTyxDQUFDLE9BQU8sQ0FBQyxDQUFDO0lBQzFFLENBQUM7SUFFRCx1REFBdUQ7SUFDdkQsb0JBQW9CO0lBQ3BCLHVEQUF1RDtJQUMvQyxzQkFBc0I7UUFDMUIsSUFBSSxDQUFDLGlCQUFpQixDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLFVBQVUsQ0FBQyxDQUFDO1FBQ3BELElBQUksQ0FBQyxhQUFhLENBQUMsY0FBYyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsVUFBVSxDQUFDLENBQUM7SUFDOUQsQ0FBQzs7O1lBcEpKLFNBQVMsU0FBQztnQkFDUCxRQUFRLEVBQUUsWUFBWTtnQkFDdEIsbWhHQUF3QztnQkFDeEMsYUFBYSxFQUFFLGlCQUFpQixDQUFDLElBQUk7Z0JBQ3JDLFNBQVMsRUFBRSxDQUFDLFlBQVksQ0FBQzthQUM1Qjs7O1lBVlEsTUFBTTtZQUNOLFlBQVk7WUFDWixjQUFjOzs7cUJBY2xCLEtBQUs7eUJBQ0wsS0FBSztnQ0FDTCxNQUFNIiwic291cmNlc0NvbnRlbnQiOlsiXHJcbmltcG9ydCB7dGltZXIgYXMgb2JzZXJ2YWJsZVRpbWVyIH0gZnJvbSAncnhqcyc7XHJcbi8qKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqXHJcbiAgICBDb21wb25lbnQgZmlsZSAgICAgOiBrZC1hbmd1bGFyLXRvb2xiYXIudHNcclxuICAgIFNlcnZpY2UgZmlsZSAgICAgICA6IGtkLWFuZ3VsYXItdG9vbGJhci1zdmMudHNcclxuICAgIEV2ZW50IGZpbGUgICAgICAgICA6IGtkLXRvb2xiYXItZXZlbnQudHNcclxuICAgIEludGVyZmFjZSBmaWxlICAgICA6IGtkLWFuZ3VsYXItcGFnZWhlYWRlci1pbnRlcmZhY2UudHNcclxuICAgIFZlcnNpb24gICAgICAgICAgICA6IDIuMFxyXG4gICAgQ3JlYXRlZCBieSAgICAgICAgIDogQ2hlbmcgS29rIEtlb25nXHJcbiAgICBQdXJwb3NlICAgICAgICAgICAgOiBTaG93IHRoZSB0b29sYmFycyBhbmQgc2VhcmNoIGlucHV0IGluIHRoZSB0ZW1wbGF0ZSBhcmVhIHVuZGVyIGJyZWFkY3J1bWJcclxuXHJcbiAgICBCZWhhdmlvdXIgICAgICAgICAgIDpcclxuICAgICAgICAtIFNlYXJjaCBidXR0b24gaW4gd2ViIHZpZXcgaXMgYWJsZSB0byBzZWUgdGhlIHNlYXJjaCBib3ggYW5kIGFibGUgdG9cclxuICAgICAgICAgIHNlYXJjaCBzdHJhaWdodCBpbiB0aGUgaW5wdXQgZmllbGRcclxuICAgICAgICAtIFNlYXJjaCBidXR0b24gaW4gbW9iaWxlIHZpZXcgaXMgYSBidXR0b24gd2l0aCB0aGUgaW5wdXQgZmllbGQgaGlkZGVuLlxyXG4gICAgICAgICAgT25seSB3aGVuIGNsaWNrZWQsIHRoZSBpbnB1dCBmaWVsZCB3aWxsIHRha2VzIHVwIDEwMCUgd2lkdGggZm9yIHNlYXJjaFxyXG5cclxuICAgICAgICAtIEJlaGF2aW91ciBmb3Igc2VhcmNoIGJ1dHRvbiBlbGVtZW50IChjcm9zcyBpY29uKTpcclxuICAgICAgICAgICAgLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cclxuICAgICAgICAgICAgfCBWaWV3IFR5cGUgICB8IFNlYXJjaCBUZXh0IGV4aXN0ICB8IEJlaGF2aW91ciAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHxcclxuICAgICAgICAgICAgLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cclxuICAgICAgICAgICAgfCBXaW5kb3dzICAgICB8ICgvKSAgICAgICAgICAgICAgICB8IENyb3NzIGljb24gd2lsbCBzaG93LCB3aGVuIGNsaWNrZWQsICAgIHxcclxuICAgICAgICAgICAgfCAgICAgICAgICAgICB8ICAgICAgICAgICAgICAgICAgICB8IHJlbW92ZSBzZWFyY2ggdGV4dCBhbmQgaGlkZSBjcm9zcyBpY29uLnxcclxuICAgICAgICAgICAgfCAgICAgICAgICAgICB8ICAgICAgICAgICAgICAgICAgICB8ICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHxcclxuICAgICAgICAgICAgfCAgICAgICAgICAgICB8ICh4KSAgICAgICAgICAgICAgICB8IENyb3NzIGljb24gaXMgaGlkZGVuLiAgICAgICAgICAgICAgICAgIHxcclxuICAgICAgICAgICAgLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cclxuICAgICAgICAgICAgfCBNb2JpbGUgICAgICB8ICgvKSAgICAgICAgICAgICAgICB8IENyb3NzIGljb24gd2lsbCBzaG93LCB3aGVuIGNsaWNrZWQsICAgIHxcclxuICAgICAgICAgICAgfCAgICAgICAgICAgICB8ICAgICAgICAgICAgICAgICAgICB8IHJlbW92ZSBzZWFyY2ggdGV4dCwgYW5kIGJlaGF2ZXMgbGlrZSAgIHxcclxuICAgICAgICAgICAgfCAgICAgICAgICAgICB8ICAgICAgICAgICAgICAgICAgICB8IE1vYmlsZSAtIE5vIHNlYXJjaCB0ZXh0ICAgICAgICAgICAgICAgIHxcclxuICAgICAgICAgICAgfCAgICAgICAgICAgICB8ICAgICAgICAgICAgICAgICAgICB8ICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHxcclxuICAgICAgICAgICAgfCAgICAgICAgICAgICB8ICh4KSAgICAgICAgICAgICAgICB8IENyb3NzIGljb24gd2lsbCBzaG93LCB3aGVuIGNsaWNrZWQgICAgIHxcclxuICAgICAgICAgICAgfCAgICAgICAgICAgICB8ICAgICAgICAgICAgICAgICAgICB8IGNsb3NlIHRoZSBzZWFyY2ggaW5wdXQuICAgICAgICAgICAgICAgIHxcclxuICAgICAgICAgICAgLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cclxuXHJcblxyXG4gICAgTGFzdCBjaGFuZ2VzICAgICAgIDpcclxuICAgICAgICAtIFJld3JpdGUgY29tcG9uZW50IGFuZCBzZXJ2aWNlXHJcblxyXG4gKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKi9cclxuXHJcblxyXG5cclxuaW1wb3J0IHtcclxuICAgIENvbXBvbmVudCxcclxuICAgIFZpZXdFbmNhcHN1bGF0aW9uLFxyXG4gICAgSW5wdXQsXHJcbiAgICBPdXRwdXQsXHJcbiAgICBFdmVudEVtaXR0ZXIsXHJcbiAgICBPbkluaXQsXHJcbiAgICBPbkNoYW5nZXMsXHJcbiAgICBTaW1wbGVDaGFuZ2VzLFxyXG4gICAgQWZ0ZXJWaWV3SW5pdCxcclxuICAgIE9uRGVzdHJveVxyXG59IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xyXG5pbXBvcnQgeyBSb3V0ZXIgfSBmcm9tICdAYW5ndWxhci9yb3V0ZXInO1xyXG5pbXBvcnQgeyBLZFRvb2xiYXJTdmMgfSBmcm9tICcuL2tkLWFuZ3VsYXItdG9vbGJhci1zdmMnO1xyXG5pbXBvcnQgeyBLZFRvb2xiYXJFdmVudCB9IGZyb20gJy4va2QtdG9vbGJhci1ldmVudCc7XHJcbmltcG9ydCB7IElUb29sYmFyQ29uZmlnLCBJVG9vbGJhckJ1dHRvbiB9IGZyb20gJy4uL2tkLWFuZ3VsYXItcGFnZWhlYWRlci1pbnRlcmZhY2UnO1xyXG5cclxuQENvbXBvbmVudCh7XHJcbiAgICBzZWxlY3RvcjogJ2tkLXRvb2xiYXInLFxyXG4gICAgdGVtcGxhdGVVcmw6ICcuL2tkLWFuZ3VsYXItdG9vbGJhci5odG1sJyxcclxuICAgIGVuY2Fwc3VsYXRpb246IFZpZXdFbmNhcHN1bGF0aW9uLk5vbmUsXHJcbiAgICBwcm92aWRlcnM6IFtLZFRvb2xiYXJTdmNdXHJcbn0pXHJcblxyXG5leHBvcnQgY2xhc3MgS2RUb29sYmFyIGltcGxlbWVudHMgT25Jbml0LCBPbkNoYW5nZXMsIEFmdGVyVmlld0luaXQsIE9uRGVzdHJveSB7XHJcbiAgICBwdWJsaWMgc2VhcmNoRXhwZW5kOiBib29sZWFuID0gZmFsc2U7XHJcbiAgICBwdWJsaWMgc2hvd1NlYXJjaENsb3NlQnRuOiBib29sZWFuID0gZmFsc2U7XHJcblxyXG4gICAgQElucHV0KCkgY29uZmlnOiBJVG9vbGJhckNvbmZpZztcclxuICAgIEBJbnB1dCgpIG1vYmlsZVZpZXc6IGJvb2xlYW47XHJcbiAgICBAT3V0cHV0KCkgc2VhcmNoVGV4dENoYW5nZWQ6IEV2ZW50RW1pdHRlcjxzdHJpbmc+ID0gbmV3IEV2ZW50RW1pdHRlcjxzdHJpbmc+KCk7XHJcblxyXG4gICAgY29uc3RydWN0b3IoXHJcbiAgICAgICAgcHJpdmF0ZSBfcm91dGVyOiBSb3V0ZXIsXHJcbiAgICAgICAgcHJpdmF0ZSBfdG9vbGJhclN2YzogS2RUb29sYmFyU3ZjLFxyXG4gICAgICAgIHByaXZhdGUgX3Rvb2xiYXJFdmVudDogS2RUb29sYmFyRXZlbnRcclxuICAgICkgeyB9XHJcblxyXG4gICAgLyoqKioqKioqKioqKioqKioqKioqKioqKiogTGlmZSBjeWNsZXMgZnVuY3Rpb25zICoqKioqKioqKioqKioqKioqKioqKioqKioqKioqL1xyXG4gICAgbmdPbkluaXQoKTogdm9pZCB7XHJcbiAgICAgICAgLy8gY29uc29sZS5sb2coJy0tIEtkVG9vbGJhcjogT25Jbml0IC0tICcsIHRoaXMuY29uZmlnKTtcclxuICAgICAgICBpZiAodHlwZW9mIHRoaXMuY29uZmlnICE9PSAndW5kZWZpbmVkJykge1xyXG4gICAgICAgICAgICB0aGlzLl91cGRhdGVMZWZ0VG9vbGJhcih0aGlzLmNvbmZpZyk7XHJcbiAgICAgICAgICAgIHRoaXMuX3VwZGF0ZVNlYXJjaENsb3NlQnRuKCk7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIG5nT25DaGFuZ2VzKF9zaW1wbGVDaGFuZ2VzOiBTaW1wbGVDaGFuZ2VzKTogdm9pZCB7XHJcbiAgICAgICAgLy8gY29uc29sZS5sb2coJy0tIEtkVG9vbGJhcjogT25DaGFuZ2VzIC0tICcsIF9zaW1wbGVDaGFuZ2VzKTtcclxuICAgICAgICBpZiAoX3NpbXBsZUNoYW5nZXMuaGFzT3duUHJvcGVydHkoJ2NvbmZpZycpICYmIHR5cGVvZiBfc2ltcGxlQ2hhbmdlc1snY29uZmlnJ10uY3VycmVudFZhbHVlICE9PSAndW5kZWZpbmVkJykge1xyXG4gICAgICAgICAgICB0aGlzLl91cGRhdGVMZWZ0VG9vbGJhcih0aGlzLmNvbmZpZyk7XHJcbiAgICAgICAgICAgIHRoaXMuX3VwZGF0ZVNlYXJjaENsb3NlQnRuKCk7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICBpZiAoX3NpbXBsZUNoYW5nZXMuaGFzT3duUHJvcGVydHkoJ21vYmlsZVZpZXcnKSkge1xyXG4gICAgICAgICAgICB0aGlzLl9jaGVja1RvU2hvd1NlYXJjaENsb3NlKCk7XHJcblxyXG4gICAgICAgICAgICBpZiAoIXRoaXMubW9iaWxlVmlldykge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5zZWFyY2hFeHBlbmQgPSBmYWxzZTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICBuZ0FmdGVyVmlld0luaXQoKTogdm9pZCB7XHJcbiAgICAgICAgLy8gY29uc29sZS5sb2coJy0tIEtkVG9vbGJhcjogQWZ0ZXJWaWV3SW5pdCAtLSAnKTtcclxuICAgICAgICBvYnNlcnZhYmxlVGltZXIoKS5zdWJzY3JpYmUoKCk6IHZvaWQgPT4ge1xyXG4gICAgICAgICAgICB0aGlzLl9jaGVja1RvU2hvd1NlYXJjaENsb3NlKCk7XHJcbiAgICAgICAgfSk7XHJcbiAgICB9XHJcblxyXG4gICAgbmdPbkRlc3Ryb3koKTogdm9pZCB7XHJcbiAgICAgICAgLy8gY29uc29sZS5sb2coJy0tIEtkVG9vbGJhcjogT25EZXN0cm95IC0tICcpO1xyXG4gICAgfVxyXG5cclxuICAgIC8qKioqKioqKioqKioqKioqKioqKioqKioqKioqIEV2ZW50cyBmdW5jdGlvbnMgKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKi9cclxuICAgIC8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy9cclxuICAgIC8vLyBCdXR0b24gZXZlbnRzXHJcbiAgICAvLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vXHJcbiAgICBwdWJsaWMgYnV0dG9uQ2xpY2soX2U6IEV2ZW50LCBfYnV0dG9uOiBJVG9vbGJhckJ1dHRvbik6IHZvaWQge1xyXG4gICAgICAgIC8vIGNvbnNvbGUubG9nKCctLSBLZFRvb2xiYXI6IEJ1dHRvbiBjbGlja2VkIC0tICcsIF9idXR0b24pO1xyXG4gICAgICAgIGlmICh0eXBlb2YgX2J1dHRvbi5wYXRoICE9PSAndW5kZWZpbmVkJykge1xyXG4gICAgICAgICAgICB0aGlzLl9yb3V0ZXIubmF2aWdhdGUoW19idXR0b24ucGF0aF0pO1xyXG4gICAgICAgIH1cclxuICAgICAgICBlbHNlIGlmICh0eXBlb2YgX2J1dHRvbi5jYWxsYmFjayAhPT0gJ3VuZGVmaW5lZCcpIHtcclxuICAgICAgICAgICAgX2J1dHRvbi5jYWxsYmFjaygpO1xyXG4gICAgICAgIH1cclxuICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgY29uc29sZS5lcnJvcignS2RUb29sYmFyOiBCdXR0b24gaXMgY2xpY2tlZCBidXQgbm8gcGF0aCBvciBjYWxsYmFjayBpcyBzcGVjaWZpZWQuJyk7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIC8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy9cclxuICAgIC8vLyBTZWFyY2ggZnVuY3Rpb25zXHJcbiAgICAvLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vXHJcbiAgICBwdWJsaWMgc2VhcmNoQ2xpY2tlZCgpOiB2b2lkIHtcclxuICAgICAgICBpZiAoIXRoaXMubW9iaWxlVmlldykgcmV0dXJuO1xyXG5cclxuICAgICAgICB0aGlzLnNlYXJjaEV4cGVuZCA9ICF0aGlzLnNlYXJjaEV4cGVuZDtcclxuICAgICAgICB0aGlzLl9jaGVja1RvU2hvd1NlYXJjaENsb3NlKCk7XHJcbiAgICB9XHJcblxyXG4gICAgcHVibGljIHNlYXJjaENoYW5nZWQoX2V2ZW50OiBzdHJpbmcpOiB2b2lkIHtcclxuICAgICAgICAvLyBjb25zb2xlLmxvZygnLS0gS2RUb29sYmFyOiBTZWFyY2ggdGV4dCBjaGFuZ2VkIC0tICcsIF9ldmVudCk7XHJcbiAgICAgICAgaWYgKHR5cGVvZiB0aGlzLmNvbmZpZy5zZWFyY2hDYWxsYmFjayAhPT0gJ3VuZGVmaW5lZCcpIHtcclxuICAgICAgICAgICAgdGhpcy5jb25maWcuc2VhcmNoQ2FsbGJhY2soX2V2ZW50KTtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIHRoaXMuX3VwZGF0ZVNlYXJjaENsb3NlQnRuKCk7XHJcbiAgICAgICAgdGhpcy5fZW1pdFNlYXJjaFRleHRDaGFuZ2VkKCk7XHJcbiAgICB9XHJcblxyXG4gICAgcHVibGljIHNlYXJjaENsb3NlQ2xpY2tlZCgpOiB2b2lkIHtcclxuICAgICAgICAvLyBjb25zb2xlLmxvZygnLS0gS2RUb29sYmFyOiBTZWFyY2ggY2xvc2UgY2xpY2tlZCAtLSAnKTtcclxuICAgICAgICBpZiAodGhpcy5tb2JpbGVWaWV3KSB7XHJcbiAgICAgICAgICAgIGlmICh0aGlzLmNvbmZpZy5zZWFyY2hUZXh0ICE9PSAnJykge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5fY2xlYXJTZWFyY2goKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgICAgIHRoaXMuc2VhcmNoRXhwZW5kID0gZmFsc2U7XHJcbiAgICAgICAgICAgICAgICB0aGlzLnNob3dTZWFyY2hDbG9zZUJ0biA9IGZhbHNlO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICB0aGlzLl9jbGVhclNlYXJjaCgpO1xyXG4gICAgICAgICAgICB0aGlzLnNob3dTZWFyY2hDbG9zZUJ0biA9IGZhbHNlO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICAvKioqKioqKioqKioqKioqKioqKioqKioqKioqKiBQcml2YXRlIGZ1bmN0aW9ucyAqKioqKioqKioqKioqKioqKioqKioqKioqKioqKiovXHJcbiAgICAvLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vXHJcbiAgICAvLy8gRE9NIGZ1bmN0aW9uXHJcbiAgICAvLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vXHJcbiAgICBwcml2YXRlIF9jaGVja1RvU2hvd1NlYXJjaENsb3NlKCk6IHZvaWQge1xyXG4gICAgICAgIGlmICh0aGlzLm1vYmlsZVZpZXcpIHtcclxuICAgICAgICAgICAgdGhpcy5zaG93U2VhcmNoQ2xvc2VCdG4gPSB0aGlzLnNlYXJjaEV4cGVuZDtcclxuICAgICAgICB9XHJcbiAgICAgICAgZWxzZSB7XHJcbiAgICAgICAgICAgIHRoaXMuc2hvd1NlYXJjaENsb3NlQnRuID0gdGhpcy5jb25maWcuc2VhcmNoVGV4dCAhPT0gJyc7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgX2NsZWFyU2VhcmNoKCk6IHZvaWQge1xyXG4gICAgICAgIHRoaXMuY29uZmlnLnNlYXJjaFRleHQgPSAnJztcclxuICAgICAgICB0aGlzLl9lbWl0U2VhcmNoVGV4dENoYW5nZWQoKTtcclxuICAgIH1cclxuXHJcbiAgICBwcml2YXRlIF91cGRhdGVTZWFyY2hDbG9zZUJ0bigpOiB2b2lkIHtcclxuICAgICAgICBpZiAoIXRoaXMubW9iaWxlVmlldykge1xyXG4gICAgICAgICAgICB0aGlzLnNob3dTZWFyY2hDbG9zZUJ0biA9IHRoaXMuY29uZmlnLnNlYXJjaFRleHQgIT09ICcnO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICAvLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vXHJcbiAgICAvLy8gVXBkYXRlIFRvb2xiYXIgYnV0dG9ucyBmdW5jdGlvblxyXG4gICAgLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vL1xyXG4gICAgcHJpdmF0ZSBfdXBkYXRlTGVmdFRvb2xiYXIoX2NvbmZpZzogSVRvb2xiYXJDb25maWcpOiB2b2lkIHtcclxuICAgICAgICBfY29uZmlnLmxlZnRCdG4gPSB0aGlzLl90b29sYmFyU3ZjLnVwZGF0ZUxlZnRUb29sYmFyKF9jb25maWcubGVmdEJ0bik7XHJcbiAgICB9XHJcblxyXG4gICAgLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vL1xyXG4gICAgLy8vIEVtaXR0ZXIgZnVuY3Rpb25cclxuICAgIC8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy9cclxuICAgIHByaXZhdGUgX2VtaXRTZWFyY2hUZXh0Q2hhbmdlZCgpOiB2b2lkIHtcclxuICAgICAgICB0aGlzLnNlYXJjaFRleHRDaGFuZ2VkLmVtaXQodGhpcy5jb25maWcuc2VhcmNoVGV4dCk7XHJcbiAgICAgICAgdGhpcy5fdG9vbGJhckV2ZW50LnNlbmRTZWFyY2hUZXh0KHRoaXMuY29uZmlnLnNlYXJjaFRleHQpO1xyXG4gICAgfVxyXG59XHJcbiJdfQ==