import { Injectable } from '@angular/core';
import { KdBroadcaster } from '../../kd-common/index';
import * as i0 from "@angular/core";
import * as i1 from "../../kd-common/kd-broadcaster-svc";
export class KdToolbarEvent {
    constructor(_broadcaster) {
        this._broadcaster = _broadcaster;
    }
    sendSearchText(data) {
        this._broadcaster.broadcast('sendSearchText', data);
    }
    onSendSearchText() {
        return this._broadcaster.on('sendSearchText');
    }
}
KdToolbarEvent.ɵprov = i0.ɵɵdefineInjectable({ factory: function KdToolbarEvent_Factory() { return new KdToolbarEvent(i0.ɵɵinject(i1.KdBroadcaster)); }, token: KdToolbarEvent, providedIn: "root" });
KdToolbarEvent.decorators = [
    { type: Injectable, args: [{
                providedIn: 'root'
            },] }
];
KdToolbarEvent.ctorParameters = () => [
    { type: KdBroadcaster }
];
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoia2QtdG9vbGJhci1ldmVudC5qcyIsInNvdXJjZVJvb3QiOiJEOi9vcGVuRU1JUy9zdHlsZWd1aWRlL2lvc3RnLW9wZW5lbWlzLXN0eWxlZ3VpZGUvcHJvamVjdHMvb3BlbmVtaXMtc3R5bGVndWlkZS1saWIvc3JjLyIsInNvdXJjZXMiOlsia2QtY29tcG9uZW50cy9rZC1hbmd1bGFyLXBhZ2VoZWFkZXIvc3JjL2tkLXRvb2xiYXItZXZlbnQudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsT0FBTyxFQUFFLFVBQVUsRUFBRSxNQUFNLGVBQWUsQ0FBQztBQUUzQyxPQUFPLEVBQUUsYUFBYSxFQUFFLE1BQU0sdUJBQXVCLENBQUM7OztBQUt0RCxNQUFNLE9BQU8sY0FBYztJQUN2QixZQUFvQixZQUEyQjtRQUEzQixpQkFBWSxHQUFaLFlBQVksQ0FBZTtJQUFJLENBQUM7SUFFcEQsY0FBYyxDQUFDLElBQWE7UUFDeEIsSUFBSSxDQUFDLFlBQVksQ0FBQyxTQUFTLENBQUMsZ0JBQWdCLEVBQUUsSUFBSSxDQUFDLENBQUM7SUFDeEQsQ0FBQztJQUVELGdCQUFnQjtRQUNaLE9BQU8sSUFBSSxDQUFDLFlBQVksQ0FBQyxFQUFFLENBQVMsZ0JBQWdCLENBQUMsQ0FBQztJQUMxRCxDQUFDOzs7O1lBWkosVUFBVSxTQUFDO2dCQUNSLFVBQVUsRUFBRSxNQUFNO2FBQ3JCOzs7WUFKUSxhQUFhIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgSW5qZWN0YWJsZSB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xyXG5pbXBvcnQgeyBPYnNlcnZhYmxlIH0gZnJvbSAncnhqcyc7XHJcbmltcG9ydCB7IEtkQnJvYWRjYXN0ZXIgfSBmcm9tICcuLi8uLi9rZC1jb21tb24vaW5kZXgnO1xyXG5cclxuQEluamVjdGFibGUoe1xyXG4gICAgcHJvdmlkZWRJbjogJ3Jvb3QnXHJcbn0pXHJcbmV4cG9ydCBjbGFzcyBLZFRvb2xiYXJFdmVudCB7XHJcbiAgICBjb25zdHJ1Y3Rvcihwcml2YXRlIF9icm9hZGNhc3RlcjogS2RCcm9hZGNhc3RlcikgeyB9XHJcblxyXG4gICAgc2VuZFNlYXJjaFRleHQoZGF0YT86IHN0cmluZyk6IHZvaWQge1xyXG4gICAgICAgIHRoaXMuX2Jyb2FkY2FzdGVyLmJyb2FkY2FzdCgnc2VuZFNlYXJjaFRleHQnLCBkYXRhKTtcclxuICAgIH1cclxuXHJcbiAgICBvblNlbmRTZWFyY2hUZXh0KCk6IE9ic2VydmFibGU8c3RyaW5nPiB7XHJcbiAgICAgICAgcmV0dXJuIHRoaXMuX2Jyb2FkY2FzdGVyLm9uPHN0cmluZz4oJ3NlbmRTZWFyY2hUZXh0Jyk7XHJcbiAgICB9XHJcbn1cclxuIl19