export interface ILoginConfig {
    header: IHeaderConfig;
    footer?: string;
    button: IFormButtonConfig;
    alert?: IFormAlertConfig;
    formLinks?: {
        forgetPassword?: IFormLinkConfig;
        forgetUser?: IFormLinkConfig;
        back?: IFormLinkConfig;
    };
    language?: ILanguageConfig;
    selectedLangIndex?: string;
    type: 'login' | 'reset-password' | 'forget-username' | 'forget-password' | 'only-otp';
}
export interface ILoginApi {
    setAlertMessage?: (_type: string, _msg: string) => void;
}
export interface IHeaderConfig {
    icon?: string;
    img?: string;
    imgSize?: 'none' | 'small' | 'medium' | 'large';
    title?: string;
    headerMsg?: string;
}
export interface ILanguageConfig {
    options?: Array<ILanguageOptionsConfig>;
    value: string;
}
export interface ILanguageOptionsConfig {
    key?: string;
    value?: string;
    dir?: string;
}
export interface IFormAlertConfig {
    successMsg?: string;
    errorMsg: string;
}
export interface IFormButtonConfig {
    label?: string;
    callback: (_param: any) => void;
}
export interface IFormLinkConfig {
    path: string;
    label?: string;
}
